# -*- coding: utf-8 -*-
import sys as CfgZ0zWP5XBpoGQwLUY
D5DpyO2wPg7oL = CfgZ0zWP5XBpoGQwLUY.version_info [0] == 2
ccK5HIyfUgvOdQpWSXZtaBJ = 2048
W8WuBTGQg1Zwqy5F6xSe = 7
def zmQcCUZlPKBITW5bqx1 (rR5FPU8VhJQ):
	global Jfz4wMWSZb0BYV
	EEr5teuZbc = ord (rR5FPU8VhJQ [-1])
	ZZd5W9FVUhzu31NQyComxv = rR5FPU8VhJQ [:-1]
	sJYFyd6mZHev1IXEaMj0b = EEr5teuZbc % len (ZZd5W9FVUhzu31NQyComxv)
	qPJ7pUnt5rcm6NMaFYLSkHsGxI = ZZd5W9FVUhzu31NQyComxv [:sJYFyd6mZHev1IXEaMj0b] + ZZd5W9FVUhzu31NQyComxv [sJYFyd6mZHev1IXEaMj0b:]
	if D5DpyO2wPg7oL:
		Vv1b9fdEckNepm7 = unicode () .join ([unichr (ord (QdqoKlFn4yZUOJp1xYrNTaBSmt69hc) - ccK5HIyfUgvOdQpWSXZtaBJ - (hrazDC5q4oB + EEr5teuZbc) % W8WuBTGQg1Zwqy5F6xSe) for hrazDC5q4oB, QdqoKlFn4yZUOJp1xYrNTaBSmt69hc in enumerate (qPJ7pUnt5rcm6NMaFYLSkHsGxI)])
	else:
		Vv1b9fdEckNepm7 = str () .join ([chr (ord (QdqoKlFn4yZUOJp1xYrNTaBSmt69hc) - ccK5HIyfUgvOdQpWSXZtaBJ - (hrazDC5q4oB + EEr5teuZbc) % W8WuBTGQg1Zwqy5F6xSe) for hrazDC5q4oB, QdqoKlFn4yZUOJp1xYrNTaBSmt69hc in enumerate (qPJ7pUnt5rcm6NMaFYLSkHsGxI)])
	return eval (Vv1b9fdEckNepm7)
V3z5t4JAqyXk2fLsW1juoZ0BEp6,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye,wdftVMyzF17cYETHu=zmQcCUZlPKBITW5bqx1,zmQcCUZlPKBITW5bqx1,zmQcCUZlPKBITW5bqx1
Hr25gta6XcqO,FmYoGejTnwKME7d9zPc,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9=wdftVMyzF17cYETHu,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye,V3z5t4JAqyXk2fLsW1juoZ0BEp6
KfHAW8VGbrxi,aOQTKXFL54Nl60Zhp3MbE,jL5CrsRwebpyDVXUc1EQP=Dco0w1e5VM3YP7hLXTHBS8GtaCrO9,FmYoGejTnwKME7d9zPc,Hr25gta6XcqO
oRJAfwD957WkUyBM1Ehu8m,vU6DxuzPwMpg,I18uSKaWhgTBeYUPD4sr=jL5CrsRwebpyDVXUc1EQP,aOQTKXFL54Nl60Zhp3MbE,KfHAW8VGbrxi
o1INZ3ViQqS0Uw5z6kMjbv,s5WMHyQN4mpie,N6NGJ4vpmidqMCh7yo=I18uSKaWhgTBeYUPD4sr,vU6DxuzPwMpg,oRJAfwD957WkUyBM1Ehu8m
Gcw2nelTR864XCVruO3mAFqI5a,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7,OO9YiAQHGrLo0qpW2M3jDeXd1kx=N6NGJ4vpmidqMCh7yo,s5WMHyQN4mpie,o1INZ3ViQqS0Uw5z6kMjbv
O3OVuapf0YFjbm5oUQDg,sJw9QWiq1Kr0xfeVRI,SnhLjmfeJC=OO9YiAQHGrLo0qpW2M3jDeXd1kx,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7,Gcw2nelTR864XCVruO3mAFqI5a
QjAINyUC7MDRq5d8e4vl9,AAbvaXV2DQzfNHdm4U3tT,ggjO5CrKVRPITaesWkxD=SnhLjmfeJC,sJw9QWiq1Kr0xfeVRI,O3OVuapf0YFjbm5oUQDg
FgXzMs0YSDt,uulNDCPyef78,EQxFuqjw95WvaMm8Hnlt47XVihJ=ggjO5CrKVRPITaesWkxD,AAbvaXV2DQzfNHdm4U3tT,QjAINyUC7MDRq5d8e4vl9
ssynAg0zhSkoCpOMDV9,sIzDXlTHYUC5L3xZGnr,PlpyFa9QMKXxOD1cvHzmI=EQxFuqjw95WvaMm8Hnlt47XVihJ,uulNDCPyef78,FgXzMs0YSDt
CsDcLqQUVK4YBvHFW1,EE1jeHnIoad,LYIgTBeSmZWotDh4bnyQkvM50siu=PlpyFa9QMKXxOD1cvHzmI,sIzDXlTHYUC5L3xZGnr,ssynAg0zhSkoCpOMDV9
from PuEbpwSj7y import *
import base64 as JNfHYgOdP9aR
BfWYUAnyg6eONLjiuE = Hr25gta6XcqO(u"ࠪࡐࡎࡈࡓࡕ࡙ࡒࠫฦ")
if jTDWgftK7NEmx0JAkOn2aRIvweq:
	uh7IyG2XsL9DKZOlYQ03jWpbq8Hm = F0xz4A8lgTSNVnk.translatePath(Hr25gta6XcqO(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡹࡤࡰࡧࠬว"))
	ywEBSl6zHMFsO4Qmh3TJP8itgj = F0xz4A8lgTSNVnk.translatePath(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡪࡲࡱࡪ࠭ศ"))
	ihFXL4gb36G1U5rWSCKEMp29 = F0xz4A8lgTSNVnk.translatePath(jL5CrsRwebpyDVXUc1EQP(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡯ࡳ࡬ࡶࡡࡵࡪࠪษ"))
	al4SYe7CV19g = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(ywEBSl6zHMFsO4Qmh3TJP8itgj,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩส"),FmYoGejTnwKME7d9zPc(u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪห"),aOQTKXFL54Nl60Zhp3MbE(u"ࠩࡄࡨࡩࡵ࡮ࡴ࠵࠶࠲ࡩࡨࠧฬ"))
	tNcZsyep9Og0Dz85aknTw = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(ywEBSl6zHMFsO4Qmh3TJP8itgj,sJw9QWiq1Kr0xfeVRI(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬอ"),aOQTKXFL54Nl60Zhp3MbE(u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭ฮ"),KfHAW8VGbrxi(u"ࠬ࡜ࡩࡦࡹࡐࡳࡩ࡫ࡳ࠷࠰ࡧࡦࠬฯ"))
	luwjTO0m9SMhLE3Fe4KXxb = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(ywEBSl6zHMFsO4Qmh3TJP8itgj,PlpyFa9QMKXxOD1cvHzmI(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨะ"),Gcw2nelTR864XCVruO3mAFqI5a(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩั"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨࡖࡨࡼࡹࡻࡲࡦࡵ࠴࠷࠳ࡪࡢࠨา"))
	gTMA6jrcU03JNv1 = FgXzMs0YSDt(u"ࡷࠪࡠࡺ࠶࠲ࡥ࠳ࠪำ")
	from urllib.parse import quote as _KSjY2bJ73pQ0hqvVtZT
else:
	uh7IyG2XsL9DKZOlYQ03jWpbq8Hm = bEWpDHXjCBqd7aOiN6UG5k.translatePath(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡸࡣ࡯ࡦࠫิ"))
	ywEBSl6zHMFsO4Qmh3TJP8itgj = bEWpDHXjCBqd7aOiN6UG5k.translatePath(vU6DxuzPwMpg(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩࠬี"))
	ihFXL4gb36G1U5rWSCKEMp29 = bEWpDHXjCBqd7aOiN6UG5k.translatePath(sIzDXlTHYUC5L3xZGnr(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩึ"))
	al4SYe7CV19g = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(ywEBSl6zHMFsO4Qmh3TJP8itgj,Hr25gta6XcqO(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨื"),ssynAg0zhSkoCpOMDV9(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦุࠩ"),I18uSKaWhgTBeYUPD4sr(u"ࠨࡃࡧࡨࡴࡴࡳ࠳࠹࠱ࡨࡧู࠭"))
	tNcZsyep9Og0Dz85aknTw = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(ywEBSl6zHMFsO4Qmh3TJP8itgj,vU6DxuzPwMpg(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤฺࠫ"),I18uSKaWhgTBeYUPD4sr(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬ฻"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"࡛ࠫ࡯ࡥࡸࡏࡲࡨࡪࡹ࠶࠯ࡦࡥࠫ฼"))
	luwjTO0m9SMhLE3Fe4KXxb = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(ywEBSl6zHMFsO4Qmh3TJP8itgj,QjAINyUC7MDRq5d8e4vl9(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ฽"),s5WMHyQN4mpie(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ฾"),ssynAg0zhSkoCpOMDV9(u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧ฿"))
	gTMA6jrcU03JNv1 = N6NGJ4vpmidqMCh7yo(u"ࡶࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩเ").encode(Tk9eH2qw6Brsuhj)
	from urllib import quote as _KSjY2bJ73pQ0hqvVtZT
Z3WAPsTKBgHV5uSfGitDNL4 = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(ihFXL4gb36G1U5rWSCKEMp29,QjAINyUC7MDRq5d8e4vl9(u"ࠩ࡮ࡳࡩ࡯࠮࡭ࡱࡪࠫแ"))
gs6a8pwU4xMn9JjPkKNm0Xv = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(ihFXL4gb36G1U5rWSCKEMp29,SnhLjmfeJC(u"ࠪ࡯ࡴࡪࡩ࠯ࡱ࡯ࡨ࠳ࡲ࡯ࡨࠩโ"))
yUzj2dEPVteHo = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(Xsc4lqOhdziToWvunbRNSQZKIY8E,Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫ࡮ࡶࡴࡷ࠳ࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭ใ"))
Sr15bgZMlKCpcmWn7 = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(Xsc4lqOhdziToWvunbRNSQZKIY8E,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬ࡯ࡰࡵࡸ࠵ࡨࡦࡺࡡࡠࡡࡢ࠲ࡩࡨࠧไ"))
XW2achsgu8UljFobiyBevJk5IrpxH = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(Xsc4lqOhdziToWvunbRNSQZKIY8E,LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠭࡭࠴ࡷࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭ๅ"))
mmFzNZYEJpdqUro7sKMj6W2 = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(Xsc4lqOhdziToWvunbRNSQZKIY8E,CsDcLqQUVK4YBvHFW1(u"ࠧࡧࡣࡹࡳࡺࡸࡩࡵࡧࡶ࠲ࡩࡧࡴࠨๆ"))
Dj12X736KbeGrVtUORkncSY = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(Xsc4lqOhdziToWvunbRNSQZKIY8E,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠨ࡫ࡳࡸࡻ࡬ࡩ࡭ࡧࡢࡣࡤ࠴ࡤࡢࡶࠪ็"))
gIzb6JN9UW0MnAVB = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(Xsc4lqOhdziToWvunbRNSQZKIY8E,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠩࡰ࠷ࡺ࡬ࡩ࡭ࡧࡢࡣࡤ࠴ࡤࡢࡶ่ࠪ"))
P8F6NtJD5ridLmglTbWpzMo4 = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(Xsc4lqOhdziToWvunbRNSQZKIY8E,Hr25gta6XcqO(u"ࠪ࡭ࡲࡧࡧࡦࡵ้ࠪ"))
qZlHNwLgcXn1D = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(P8F6NtJD5ridLmglTbWpzMo4,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡷ๊ࠬ"))
hcqdaSHI6RONPbomY7K1w = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(P8F6NtJD5ridLmglTbWpzMo4,vU6DxuzPwMpg(u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡷ๋ࠬ"))
bJfZTNHCW9D8i4qxcEgstzBjwYL1 = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(qZlHNwLgcXn1D,Gcw2nelTR864XCVruO3mAFqI5a(u"࠭ࡤࡪࡣ࡯ࡳ࡬ࡥ࠰࠱࠲࠳ࡣ࠳ࡶ࡮ࡨࠩ์"))
uugoLac4UGZztBeijxW1k0 = Qb7hIE2DTM59KS41o.Addon().getAddonInfo(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧࡱࡣࡷ࡬ࠬํ"))
bQJXOAx1wmNU8IkDKs = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(uugoLac4UGZztBeijxW1k0,QjAINyUC7MDRq5d8e4vl9(u"ࠨ࡫ࡦࡳࡳ࠴ࡰ࡯ࡩࠪ๎"))
EE1ZnFHIYUgL5BVemPNR = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(uugoLac4UGZztBeijxW1k0,uulNDCPyef78(u"ࠩࡷ࡬ࡺࡳࡢ࠯ࡲࡱ࡫ࠬ๏"))
uypUCZWfs64gTR9bQlV = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(uugoLac4UGZztBeijxW1k0,sJw9QWiq1Kr0xfeVRI(u"ࠪࡪࡦࡴࡡࡳࡶ࠱ࡴࡳ࡭ࠧ๐"))
absiWR8VGEywYfXHp = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(uugoLac4UGZztBeijxW1k0,aOQTKXFL54Nl60Zhp3MbE(u"ࠫࡧࡧ࡮࡯ࡧࡵ࠲ࡵࡴࡧࠨ๑"))
R20yfGALCugQOHSdTUpms = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(uugoLac4UGZztBeijxW1k0,s5WMHyQN4mpie(u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥ࠯ࡲࡱ࡫ࠬ๒"))
MANmaDnltxTiwH6p32kSsvuPjOFZ = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(uugoLac4UGZztBeijxW1k0,PlpyFa9QMKXxOD1cvHzmI(u"࠭ࡰࡰࡵࡷࡩࡷ࠴ࡰ࡯ࡩࠪ๓"))
MvZfwqFTSy = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(uugoLac4UGZztBeijxW1k0,Gcw2nelTR864XCVruO3mAFqI5a(u"ࠧࡤ࡮ࡨࡥࡷࡲ࡯ࡨࡱ࠱ࡴࡳ࡭ࠧ๔"))
efUCvKA1BXOhkY = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(uugoLac4UGZztBeijxW1k0,I18uSKaWhgTBeYUPD4sr(u"ࠨࡥ࡯ࡩࡦࡸࡡࡳࡶ࠱ࡴࡳ࡭ࠧ๕"))
iZQGOpLhl4f = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(uugoLac4UGZztBeijxW1k0,PlpyFa9QMKXxOD1cvHzmI(u"ࠩࡰࡩࡳࡻ࡟ࡳࡧࡧࡣ࠷࠶࠰ࡹ࠴࠸࠴࠳ࡶ࡮ࡨࠩ๖"))
VVYNwt2Jf9lsvGQcWo = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(uugoLac4UGZztBeijxW1k0,ggjO5CrKVRPITaesWkxD(u"ࠪࡧ࡭ࡧ࡮ࡨࡧ࡯ࡳ࡬࠴ࡴࡹࡶࠪ๗"))
cRwuEXGWxj = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(ywEBSl6zHMFsO4Qmh3TJP8itgj,jL5CrsRwebpyDVXUc1EQP(u"ࠫࡦࡪࡤࡰࡰࡶࠫ๘"))
SgAZiTqCvErp50WHNz7Rb = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(ywEBSl6zHMFsO4Qmh3TJP8itgj,QjAINyUC7MDRq5d8e4vl9(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ๙"),KfHAW8VGbrxi(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ๚"),SZvQ0Jre4BHyGVFxoPYM2IU6)
M9MFNdZq3PuBkCsytJ = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(SgAZiTqCvErp50WHNz7Rb,CsDcLqQUVK4YBvHFW1(u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭๛"))
nBM8FATasf6jo = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(uh7IyG2XsL9DKZOlYQ03jWpbq8Hm,s5WMHyQN4mpie(u"ࠨ࡯ࡨࡨ࡮ࡧࠧ๜"),jL5CrsRwebpyDVXUc1EQP(u"ࠩࡉࡳࡳࡺࡳࠨ๝"),sJw9QWiq1Kr0xfeVRI(u"ࠪࡥࡷ࡯ࡡ࡭࠰ࡷࡸ࡫࠭๞"))
class o7tTZByhsMOjpwN(Y4csmkeFLyGVDC):
	def __init__(ev9HtagLfQl12E,*aargs,**kkwargs):
		ev9HtagLfQl12E.choiceID = -BkM54Kr7Qbqn
	def onClick(ev9HtagLfQl12E,aprSs38okPbOJI4V):
		if aprSs38okPbOJI4V>=vU6DxuzPwMpg(u"࠽࠵࠷࠰᎑"): ev9HtagLfQl12E.choiceID = aprSs38okPbOJI4V-vU6DxuzPwMpg(u"࠽࠵࠷࠰᎑")
		ev9HtagLfQl12E.aRHPtf3Q9XqvOpNw0Z1xBLWlhIzU()
	def qqeM0LJVu2xIFOGtzwR8rdB(ev9HtagLfQl12E,*aargs):
		ev9HtagLfQl12E.button0,ev9HtagLfQl12E.button1,ev9HtagLfQl12E.button2 = aargs[D2D96X5NGamBhrFwvL8VEbqiSfZIl],aargs[BkM54Kr7Qbqn],aargs[teaC5j4HuGDqpwcmUzJ]
		ev9HtagLfQl12E.header,ev9HtagLfQl12E.text = aargs[XW57OCeGnFTLQbaqdrD9zM],aargs[vD4Fh6ictZ7wME]
		ev9HtagLfQl12E.profile,ev9HtagLfQl12E.direction = aargs[vU6DxuzPwMpg(u"࠺᎒")],aargs[LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠼᎓")]
		ev9HtagLfQl12E.buttonstimeout,ev9HtagLfQl12E.closetimeout = aargs[AAbvaXV2DQzfNHdm4U3tT(u"࠸᎕")],aargs[jL5CrsRwebpyDVXUc1EQP(u"࠸᎔")]
		if ev9HtagLfQl12E.buttonstimeout>D2D96X5NGamBhrFwvL8VEbqiSfZIl or ev9HtagLfQl12E.closetimeout>KfHAW8VGbrxi(u"࠲᎖"): ev9HtagLfQl12E.enable_progressbar = EsCplGc5N4mBuYW0RVQt6b
		else: ev9HtagLfQl12E.enable_progressbar = LhFAGlQ19zr
		ev9HtagLfQl12E.image_filename = bJfZTNHCW9D8i4qxcEgstzBjwYL1.replace(QjAINyUC7MDRq5d8e4vl9(u"ࠫࡤ࠶࠰࠱࠲ࡢࠫ๟"),wdftVMyzF17cYETHu(u"ࠬࡥࠧ๠")+str(uUqrNPcXKBoQ0slv.time())+I18uSKaWhgTBeYUPD4sr(u"࠭࡟ࠨ๡"))
		ev9HtagLfQl12E.image_filename = ev9HtagLfQl12E.image_filename.replace(s5WMHyQN4mpie(u"ࠧ࡝࡞ࠪ๢"),oRJAfwD957WkUyBM1Ehu8m(u"ࠨ࡞࡟ࡠࡡ࠭๣")).replace(wdftVMyzF17cYETHu(u"ࠩ࠲࠳ࠬ๤"),FmYoGejTnwKME7d9zPc(u"ࠪ࠳࠴࠵࠯ࠨ๥"))
		ev9HtagLfQl12E.image_height = TatKxLsejrR2oud(ev9HtagLfQl12E.button0,ev9HtagLfQl12E.button1,ev9HtagLfQl12E.button2,ev9HtagLfQl12E.header,ev9HtagLfQl12E.text,ev9HtagLfQl12E.profile,ev9HtagLfQl12E.direction,ev9HtagLfQl12E.enable_progressbar,ev9HtagLfQl12E.image_filename)
		ev9HtagLfQl12E.show()
		ev9HtagLfQl12E.getControl(LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠼࠴࠺࠶᎗")).setImage(ev9HtagLfQl12E.image_filename)
		ev9HtagLfQl12E.getControl(EE1jeHnIoad(u"࠽࠵࠻࠰᎘")).setHeight(ev9HtagLfQl12E.image_height)
		if not ev9HtagLfQl12E.button1 and ev9HtagLfQl12E.button0 and ev9HtagLfQl12E.button2: ev9HtagLfQl12E.getControl(ssynAg0zhSkoCpOMDV9(u"࠿࠰࠲࠴᎚")).setPosition(-wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠲࠳࠲᎛"),oRJAfwD957WkUyBM1Ehu8m(u"࠵᎙"))
		return ev9HtagLfQl12E.image_filename,ev9HtagLfQl12E.image_height
	def zXY3aol5d8b(ev9HtagLfQl12E):
		if ev9HtagLfQl12E.buttonstimeout:
			ev9HtagLfQl12E.th1 = YMsWIfu7ojp2t4XJyZN05aC3l(daemon=EsCplGc5N4mBuYW0RVQt6b,target=ev9HtagLfQl12E.mTiZxPVcJtYNpy5qsC2Gheb3Q64v)
			ev9HtagLfQl12E.th1.start()
		else: ev9HtagLfQl12E.qaO8xwcBEmGI4dtseoubTjWz7C()
	def mTiZxPVcJtYNpy5qsC2Gheb3Q64v(ev9HtagLfQl12E):
		ev9HtagLfQl12E.getControl(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠺࠲࠵࠴᎜")).setEnabled(EsCplGc5N4mBuYW0RVQt6b)
		for b3b24XZTV7gW9mhcqLoCnftO in range(BkM54Kr7Qbqn,ev9HtagLfQl12E.buttonstimeout+BkM54Kr7Qbqn):
			uUqrNPcXKBoQ0slv.sleep(BkM54Kr7Qbqn)
			g2jVnAkPZNrJt97e3qcbBQIyXdT = int(aOQTKXFL54Nl60Zhp3MbE(u"࠳࠳࠴᎝")*b3b24XZTV7gW9mhcqLoCnftO/ev9HtagLfQl12E.buttonstimeout)
			ev9HtagLfQl12E.j0TiB1wYeMmPAJnQ2GXNZWl8Hv3(g2jVnAkPZNrJt97e3qcbBQIyXdT)
			if ev9HtagLfQl12E.choiceID>SnhLjmfeJC(u"࠳᎞"): break
		ev9HtagLfQl12E.qaO8xwcBEmGI4dtseoubTjWz7C()
	def jQS4VGxF2afg(ev9HtagLfQl12E):
		if ev9HtagLfQl12E.closetimeout:
			ev9HtagLfQl12E.th2 = YMsWIfu7ojp2t4XJyZN05aC3l(daemon=EsCplGc5N4mBuYW0RVQt6b,target=ev9HtagLfQl12E.vKJxNg8OCnqzS45rXWHPBbdf6DGE9)
			ev9HtagLfQl12E.th2.start()
		else: ev9HtagLfQl12E.qaO8xwcBEmGI4dtseoubTjWz7C()
	def vKJxNg8OCnqzS45rXWHPBbdf6DGE9(ev9HtagLfQl12E):
		ev9HtagLfQl12E.getControl(sIzDXlTHYUC5L3xZGnr(u"࠽࠵࠸࠰᎟")).setEnabled(EsCplGc5N4mBuYW0RVQt6b)
		uUqrNPcXKBoQ0slv.sleep(ev9HtagLfQl12E.buttonstimeout)
		for b3b24XZTV7gW9mhcqLoCnftO in range(ev9HtagLfQl12E.closetimeout-BkM54Kr7Qbqn,-BkM54Kr7Qbqn,-BkM54Kr7Qbqn):
			uUqrNPcXKBoQ0slv.sleep(BkM54Kr7Qbqn)
			g2jVnAkPZNrJt97e3qcbBQIyXdT = int(KfHAW8VGbrxi(u"࠶࠶࠰Ꭰ")*b3b24XZTV7gW9mhcqLoCnftO/ev9HtagLfQl12E.closetimeout)
			ev9HtagLfQl12E.j0TiB1wYeMmPAJnQ2GXNZWl8Hv3(g2jVnAkPZNrJt97e3qcbBQIyXdT)
			if ev9HtagLfQl12E.choiceID>D2D96X5NGamBhrFwvL8VEbqiSfZIl: break
		if ev9HtagLfQl12E.closetimeout>D2D96X5NGamBhrFwvL8VEbqiSfZIl: ev9HtagLfQl12E.choiceID = C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠷࠰Ꭱ")
		ev9HtagLfQl12E.aRHPtf3Q9XqvOpNw0Z1xBLWlhIzU()
	def j0TiB1wYeMmPAJnQ2GXNZWl8Hv3(ev9HtagLfQl12E,g2jVnAkPZNrJt97e3qcbBQIyXdT):
		ev9HtagLfQl12E.precent = g2jVnAkPZNrJt97e3qcbBQIyXdT
		ev9HtagLfQl12E.getControl(uulNDCPyef78(u"࠹࠱࠴࠳Ꭲ")).setPercent(ev9HtagLfQl12E.precent)
	def qaO8xwcBEmGI4dtseoubTjWz7C(ev9HtagLfQl12E):
		if ev9HtagLfQl12E.button0: ev9HtagLfQl12E.getControl(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠺࠲࠴࠴Ꭳ")).setEnabled(EsCplGc5N4mBuYW0RVQt6b)
		if ev9HtagLfQl12E.button1: ev9HtagLfQl12E.getControl(jL5CrsRwebpyDVXUc1EQP(u"࠻࠳࠵࠶Ꭴ")).setEnabled(EsCplGc5N4mBuYW0RVQt6b)
		if ev9HtagLfQl12E.button2: ev9HtagLfQl12E.getControl(FmYoGejTnwKME7d9zPc(u"࠼࠴࠶࠸Ꭵ")).setEnabled(EsCplGc5N4mBuYW0RVQt6b)
	def aRHPtf3Q9XqvOpNw0Z1xBLWlhIzU(ev9HtagLfQl12E):
		ev9HtagLfQl12E.close()
		try: HoxKENAey2MdTt9kDUrVnWGLS0CPa.remove(ev9HtagLfQl12E.image_filename)
		except: pass
class Ui7X2Awte6o8J9QRV4kdsPmb():
	def __init__(ev9HtagLfQl12E,showDialogs=LhFAGlQ19zr,logErrors=EsCplGc5N4mBuYW0RVQt6b):
		ev9HtagLfQl12E.showDialogs = showDialogs
		ev9HtagLfQl12E.logErrors = logErrors
		ev9HtagLfQl12E.finishedLIST,ev9HtagLfQl12E.failedLIST = [],[]
		ev9HtagLfQl12E.statusDICT,ev9HtagLfQl12E.resultsDICT = {},{}
		ev9HtagLfQl12E.processesLIST = []
		ev9HtagLfQl12E.starttimeDICT,ev9HtagLfQl12E.finishtimeDICT,ev9HtagLfQl12E.elpasedtimeDICT = {},{},{}
	def nSC4a3oWvwIyfd(ev9HtagLfQl12E,SXIxbZBW2zHeAV,z4cgF603iZXLOvVCtYj,*aargs):
		SXIxbZBW2zHeAV = str(SXIxbZBW2zHeAV)
		ev9HtagLfQl12E.statusDICT[SXIxbZBW2zHeAV] = PlpyFa9QMKXxOD1cvHzmI(u"ࠫࡷࡻ࡮࡯࡫ࡱ࡫ࠬ๦")
		if ev9HtagLfQl12E.showDialogs: a6rVSjDMF87KyYINcuOP1l40Hbp(fy8iFgEkrO12NR9TWBI35sjY6qHvV,SXIxbZBW2zHeAV)
		NvoyFmqZb67 = YMsWIfu7ojp2t4XJyZN05aC3l(daemon=EsCplGc5N4mBuYW0RVQt6b,target=ev9HtagLfQl12E.TBVUjat0XR3o4Ik,args=(SXIxbZBW2zHeAV,z4cgF603iZXLOvVCtYj,aargs))
		ev9HtagLfQl12E.processesLIST.append(NvoyFmqZb67)
		return NvoyFmqZb67
	def hN0H7wlzTkjUr(ev9HtagLfQl12E,SXIxbZBW2zHeAV,z4cgF603iZXLOvVCtYj,*aargs):
		NvoyFmqZb67 = ev9HtagLfQl12E.nSC4a3oWvwIyfd(SXIxbZBW2zHeAV,z4cgF603iZXLOvVCtYj,*aargs)
		NvoyFmqZb67.start()
	def TBVUjat0XR3o4Ik(ev9HtagLfQl12E,SXIxbZBW2zHeAV,z4cgF603iZXLOvVCtYj,aargs):
		SXIxbZBW2zHeAV = str(SXIxbZBW2zHeAV)
		ev9HtagLfQl12E.starttimeDICT[SXIxbZBW2zHeAV] = uUqrNPcXKBoQ0slv.time()
		try:
			ev9HtagLfQl12E.resultsDICT[SXIxbZBW2zHeAV] = z4cgF603iZXLOvVCtYj(*aargs)
			if V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠬࡕࡐࡆࡐࡘࡖࡑ࠭๧") in str(z4cgF603iZXLOvVCtYj) and not ev9HtagLfQl12E.resultsDICT[SXIxbZBW2zHeAV].succeeded: n9grXGiQYD2wl8UjSRe3HcKhE()
			ev9HtagLfQl12E.finishedLIST.append(SXIxbZBW2zHeAV)
			ev9HtagLfQl12E.statusDICT[SXIxbZBW2zHeAV] = CsDcLqQUVK4YBvHFW1(u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࠨ๨")
		except Exception as NYtXLZDyeiqPSgGO:
			if ev9HtagLfQl12E.logErrors:
				Okwr0yDIL1oVF9AlWRbduUtnzp = NFtwAhXgZB9u.format_exc()
				if Okwr0yDIL1oVF9AlWRbduUtnzp!=FgXzMs0YSDt(u"ࠧࡏࡱࡱࡩ࡙ࡿࡰࡦ࠼ࠣࡒࡴࡴࡥ࡝ࡰࠪ๩"): CfgZ0zWP5XBpoGQwLUY.stderr.write(Okwr0yDIL1oVF9AlWRbduUtnzp)
			ev9HtagLfQl12E.failedLIST.append(SXIxbZBW2zHeAV)
			ev9HtagLfQl12E.statusDICT[SXIxbZBW2zHeAV] = ssynAg0zhSkoCpOMDV9(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ๪")
		ev9HtagLfQl12E.finishtimeDICT[SXIxbZBW2zHeAV] = uUqrNPcXKBoQ0slv.time()
		ev9HtagLfQl12E.elpasedtimeDICT[SXIxbZBW2zHeAV] = ev9HtagLfQl12E.finishtimeDICT[SXIxbZBW2zHeAV] - ev9HtagLfQl12E.starttimeDICT[SXIxbZBW2zHeAV]
	def prR37bKVMsueglqzY6hGfdSaEIcQUX(ev9HtagLfQl12E):
		for IuQBU9rnN65wlhebpa4og in ev9HtagLfQl12E.processesLIST:
			IuQBU9rnN65wlhebpa4og.start()
	def hi8G5ZRcxNadr4elILUoqy3(ev9HtagLfQl12E):
		while FmYoGejTnwKME7d9zPc(u"ࠩࡵࡹࡳࡴࡩ࡯ࡩࠪ๫") in list(ev9HtagLfQl12E.statusDICT.values()): uUqrNPcXKBoQ0slv.sleep(o1INZ3ViQqS0Uw5z6kMjbv(u"࠵Ꭶ"))
def iABjF6nbRfWk89pyc():
	if not VrXZUMQwAoOIg1D8Bjk4s2hfC7EGPv: return wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠪࡒࡔࡥࡕࡑࡆࡄࡘࡊ࠭๬")
	M701MW5zx8vKEq4OtLVdBuFcIegY = CsDcLqQUVK4YBvHFW1(u"ࠫࡋ࡛ࡌࡍࡡࡘࡔࡉࡇࡔࡆࠩ๭")
	XryiY0C1E6U7dPHAvmSq3Vu4G = [Hr25gta6XcqO(u"ࠬ࠾࠮࠶࠰࠳ࠫ๮"),CsDcLqQUVK4YBvHFW1(u"࠭࠲࠱࠴࠴࠲࠶࠶࠮࠲࠻ࠪ๯"),sJw9QWiq1Kr0xfeVRI(u"ࠧ࠳࠲࠵࠵࠳࠷࠱࠯࠴࠷ࡥࠬ๰"),sJw9QWiq1Kr0xfeVRI(u"ࠨ࠴࠳࠶࠶࠴࠱࠳࠰࠶࠴ࠬ๱"),ssynAg0zhSkoCpOMDV9(u"ࠩ࠵࠴࠷࠸࠮࠱࠴࠱࠴࠷࠭๲"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪ࠶࠵࠸࠲࠯࠳࠳࠲࠷࠸ࠧ๳"),Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫ࠷࠶࠲࠴࠰࠳࠷࠳࠶࠶ࠨ๴"),jL5CrsRwebpyDVXUc1EQP(u"ࠬ࠸࠰࠳࠵࠱࠴࠺࠴࠱࠷ࠩ๵"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭࠲࠱࠴࠶࠲࠵࠼࠮࠱࠸ࠪ๶"),KfHAW8VGbrxi(u"ࠧ࠳࠲࠵࠷࠳࠷࠰࠯࠴࠻ࠫ๷"),Hr25gta6XcqO(u"ࠨ࠴࠳࠶࠹࠴࠰࠲࠰࠴࠸ࠬ๸"),aOQTKXFL54Nl60Zhp3MbE(u"ࠩ࠵࠴࠷࠺࠮࠱࠹࠱࠶࠵࠭๹")]
	E9PFvIw3cthuXyHOLkQ4r7Rp = XryiY0C1E6U7dPHAvmSq3Vu4G[-BkM54Kr7Qbqn]
	NxFsk0Htf2C = szWVcgPdT2CYH4Nka153hb(E9PFvIw3cthuXyHOLkQ4r7Rp)
	llRq6FLEz7aoidKCOxJr9up = szWVcgPdT2CYH4Nka153hb(KoxvjArhL1TdInDmN9s)
	if llRq6FLEz7aoidKCOxJr9up>NxFsk0Htf2C:
		M701MW5zx8vKEq4OtLVdBuFcIegY = s5WMHyQN4mpie(u"ࠪࡗࡎࡓࡐࡍࡇࡢ࡙ࡕࡊࡁࡕࡇࠪ๺")
	return M701MW5zx8vKEq4OtLVdBuFcIegY
def FpJlg5HtRh0wqA1():
	try: HoxKENAey2MdTt9kDUrVnWGLS0CPa.makedirs(Xsc4lqOhdziToWvunbRNSQZKIY8E)
	except: pass
	Idq2tNrFfYhk3VOK5LeuwD9BCRnpW = iABjF6nbRfWk89pyc()
	if Idq2tNrFfYhk3VOK5LeuwD9BCRnpW==V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠫࡘࡏࡍࡑࡎࡈࡣ࡚ࡖࡄࡂࡖࡈࠫ๻"): Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,SnhLjmfeJC(u"ࠬ࠴࡜ࡵࡃࡵࡥࡧ࡯ࡣࡗ࡫ࡧࡩࡴࡹࠠࡖࡲࡧࡥࡹ࡫ࠠࡕࡻࡳࡩ࠿ࠦࠠࡔࡋࡐࡔࡑࡋࠠࡖࡒࡇࡅ࡙ࡋࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫ๼")+LVXc6WJ3eAoz5hgnyrut1+wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭ࠠ࡞ࠩ๽"))
	else: Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧ࠯࡞ࡷࡅࡷࡧࡢࡪࡥ࡙࡭ࡩ࡫࡯ࡴࠢࡘࡴࡩࡧࡴࡦࠢࡗࡽࡵ࡫࠺ࠡࠢࡉ࡙ࡑࡒࠠࡖࡒࡇࡅ࡙ࡋࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫ๾")+LVXc6WJ3eAoz5hgnyrut1+C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨࠢࡠࠫ๿"))
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,N6NGJ4vpmidqMCh7yo(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ຀"),O3OVuapf0YFjbm5oUQDg(u"ࠪฮ๊ࠦสฮัํฯࠥอไษำ้ห๊าࠠโ์ࠣะ์อาไ࡞ࡱษ้๏ࠠศๆศูิอัࠡำๅ้࠿ࡢ࡮࡝ࡰࠪກ")+KoxvjArhL1TdInDmN9s)
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧຂ"),o1INZ3ViQqS0Uw5z6kMjbv(u"ࠬะๅࠡฬฮฬ๏ะࠠฤ๊ࠣฮาี๊ฬࠢส่ส฻ฯศำࠣห้าฯ๋ั่ࠣอืๆศ็ฯࠤฬ๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠢ࠱ࠤศ๎ࠠห็ุ้ࠣำࠠไษืࠤฬ๊ศา่ส้ัࠦ࡜࡯࡞ࡱࠤุ๐โ้็ࠣห้ศๆࠡษ็ฬึ์วๆฮࠣฬอ฿ึࠡษ็ๅา๎ีศฬ่ࠣ฻๋ว็ࠢ฼้้ࠦวๅสิ๊ฬ๋ฬࠡสุ์ึฯࠠึฯํัฮ่ࠦๆฬๆห๊๊ษࠨ຃"))
	gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩຄ"),uulNDCPyef78(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ຅"))
	gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,FgXzMs0YSDt(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫຆ"),I18uSKaWhgTBeYUPD4sr(u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪງ"))
	gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,oRJAfwD957WkUyBM1Ehu8m(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ຈ"),jL5CrsRwebpyDVXUc1EQP(u"ࠫࡋࡕࡒࡘࡃࡕࡈࡘ࠭ຉ"))
	gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,oRJAfwD957WkUyBM1Ehu8m(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨຊ"),s5WMHyQN4mpie(u"࠭ࡓࡊࡖࡈࡗࡤࡔࡁࡎࡇࡖࠫ຋"))
	gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,CsDcLqQUVK4YBvHFW1(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪຌ"),I18uSKaWhgTBeYUPD4sr(u"ࠨࡕࡌࡘࡊ࡙࡟ࡄࡊࡈࡇࡐ࠭ຍ"))
	gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,O3OVuapf0YFjbm5oUQDg(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬຎ"),oRJAfwD957WkUyBM1Ehu8m(u"ࠪࡗࡎ࡚ࡅࡔࡡ࡙ࡉࡗࡏࡆ࡚ࠩຏ"))
	OdiZIyCfDUsW3JBGR2VAb.setSetting(oRJAfwD957WkUyBM1Ehu8m(u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࡬࡯ࡴࡶࡤࠫຐ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	OdiZIyCfDUsW3JBGR2VAb.setSetting(KfHAW8VGbrxi(u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࡦࡢࡤࡵࡥࡰࡧࠧຑ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	OdiZIyCfDUsW3JBGR2VAb.setSetting(FgXzMs0YSDt(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩຒ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	OdiZIyCfDUsW3JBGR2VAb.setSetting(sIzDXlTHYUC5L3xZGnr(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡨࡤࡷࡪࡲࡨࡥ࠳ࠪຓ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	OdiZIyCfDUsW3JBGR2VAb.setSetting(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠨࡣࡹ࠲ࡵࡸࡩࡷࡵ࠴ࠫດ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	OdiZIyCfDUsW3JBGR2VAb.setSetting(o1INZ3ViQqS0Uw5z6kMjbv(u"ࠩࡤࡺ࠳ࡶࡥࡳ࡫ࡲࡨ࠳࡯࡮ࡧࡱࡶࠫຕ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	OdiZIyCfDUsW3JBGR2VAb.setSetting(FmYoGejTnwKME7d9zPc(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡶ࡬ࡴࡸࡴࠨຖ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	OdiZIyCfDUsW3JBGR2VAb.setSetting(ssynAg0zhSkoCpOMDV9(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡶࡪ࡭ࡵ࡭ࡣࡵࠫທ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	OdiZIyCfDUsW3JBGR2VAb.setSetting(KfHAW8VGbrxi(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡱࡵ࡮ࡨࠩຘ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	OdiZIyCfDUsW3JBGR2VAb.setSetting(sJw9QWiq1Kr0xfeVRI(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧນ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	OdiZIyCfDUsW3JBGR2VAb.setSetting(Hr25gta6XcqO(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩບ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡗࡎ࡚ࡅࡔࠩປ"))
	gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,O3OVuapf0YFjbm5oUQDg(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࠩຜ"))
	gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,s5WMHyQN4mpie(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࠩຝ"))
	gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,I18uSKaWhgTBeYUPD4sr(u"ࠫࡘࡉࡒࡂࡒࡈࡖࡘࡥࡓࡕࡃࡗ࡙ࡘ࠭ພ"))
	ZL2gHRX194IrVYoqcjnT(LhFAGlQ19zr)
	uj8SWIk2fcadGNFs67ZLp0(oWMrx7zvedHY0UiS48XbOqVTJ)
	siEZBCaT9n8GXfLSx70j21yDoQ5VR3 = m6TaK8E5yuk(EsCplGc5N4mBuYW0RVQt6b)
	import XbdWsnBA9G
	XbdWsnBA9G.wwntyGQz2YbhoXNfMFm(s5WMHyQN4mpie(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬຟ"),LhFAGlQ19zr)
	XbdWsnBA9G.wwntyGQz2YbhoXNfMFm(FgXzMs0YSDt(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡷࡺ࡭ࡱࠩຠ"),LhFAGlQ19zr)
	XbdWsnBA9G.wwntyGQz2YbhoXNfMFm(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳࡬ࡦ࡮ࡲࡨ࡫ࡩ࡯ࡲࡦࡥࡷࠫມ"),LhFAGlQ19zr)
	XbdWsnBA9G.mcPDrqAL95GBTaZfUtgvF0WM(EsCplGc5N4mBuYW0RVQt6b)
	if Idq2tNrFfYhk3VOK5LeuwD9BCRnpW==C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨࡕࡌࡑࡕࡒࡅࡠࡗࡓࡈࡆ࡚ࡅࠨຢ"):
		eegO4os7SYNkhv(EsCplGc5N4mBuYW0RVQt6b,[jUCABmLYMf0G])
	else:
		eegO4os7SYNkhv(LhFAGlQ19zr,[])
		XbdWsnBA9G.btfGBPRgIAskW7T3()
		try:
			mme3HjlhGXbTMcNrVdWKgy2 = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(ywEBSl6zHMFsO4Qmh3TJP8itgj,N6NGJ4vpmidqMCh7yo(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫຣ"),FmYoGejTnwKME7d9zPc(u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧ຤"),vU6DxuzPwMpg(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡷ࡫ࡳࡰ࡮ࡹࡩࡺࡸ࡬ࠨລ"),o1INZ3ViQqS0Uw5z6kMjbv(u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫ຦"))
			wvyQnsic9VzRWjf7u2rGPL = Qb7hIE2DTM59KS41o.Addon(id=C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪວ"))
			wvyQnsic9VzRWjf7u2rGPL.setSetting(KfHAW8VGbrxi(u"ࠧࡢࡸ࠱ࡥࡺࡺ࡯ࡠࡲ࡬ࡧࡰ࠭ຨ"),o1INZ3ViQqS0Uw5z6kMjbv(u"ࠨࡈࡤࡰࡸ࡫ࠧຩ"))
		except: pass
		try:
			mme3HjlhGXbTMcNrVdWKgy2 = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(ywEBSl6zHMFsO4Qmh3TJP8itgj,uulNDCPyef78(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫສ"),s5WMHyQN4mpie(u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧຫ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡾࡺ࠭ࡥ࡮ࡳࠫຬ"),O3OVuapf0YFjbm5oUQDg(u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫອ"))
			wvyQnsic9VzRWjf7u2rGPL = Qb7hIE2DTM59KS41o.Addon(id=C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡵ࠯ࡧࡰࡵ࠭ຮ"))
			wvyQnsic9VzRWjf7u2rGPL.setSetting(SnhLjmfeJC(u"ࠧࡢࡸ࠱ࡺ࡮ࡪࡥࡰࡡࡴࡹࡦࡲࡩࡵࡻࠪຯ"),QjAINyUC7MDRq5d8e4vl9(u"ࠨ࠵ࠪະ"))
		except: pass
		try:
			mme3HjlhGXbTMcNrVdWKgy2 = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(ywEBSl6zHMFsO4Qmh3TJP8itgj,PlpyFa9QMKXxOD1cvHzmI(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫັ"),AAbvaXV2DQzfNHdm4U3tT(u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧາ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫຳ"),sJw9QWiq1Kr0xfeVRI(u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫິ"))
			wvyQnsic9VzRWjf7u2rGPL = Qb7hIE2DTM59KS41o.Addon(id=ggjO5CrKVRPITaesWkxD(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭ີ"))
			wvyQnsic9VzRWjf7u2rGPL.setSetting(s5WMHyQN4mpie(u"ࠧࡢࡸ࠱ࡗ࡙ࡘࡅࡂࡏࡖࡉࡑࡋࡃࡕࡋࡒࡒࠬຶ"),o1INZ3ViQqS0Uw5z6kMjbv(u"ࠨ࠴ࠪື"))
		except: pass
	O6N8nhyYTD12KRApqkLzVi = mJE8eLQqtMC9Io6sfHnBKjiDzPwvy(bVeH60CmPM)
	O6N8nhyYTD12KRApqkLzVi = mJE8eLQqtMC9Io6sfHnBKjiDzPwvy(mmFzNZYEJpdqUro7sKMj6W2)
	XbdWsnBA9G.flAMmhjDV5ISOU46xibGekvq(LhFAGlQ19zr)
	OdiZIyCfDUsW3JBGR2VAb.setSetting(PlpyFa9QMKXxOD1cvHzmI(u"ࠩࡤࡺ࠳ࡼࡥࡳࡵ࡬ࡳࡳຸ࠭"),KoxvjArhL1TdInDmN9s)
	ejX7kGtQ4hcYUHW9b31vriuZLM6Sp(LhFAGlQ19zr)
	return
def HDTAWUgLVv8xZP3BI6O2F(XsDQkAWCEMaxHV28w1iO):
	RdvzsjKYupa0yB5I3MUCAqmtZPO = RKYsragFJfoQlEU1Mj5HPAnIDTS(EsCplGc5N4mBuYW0RVQt6b)
	if RdvzsjKYupa0yB5I3MUCAqmtZPO:
		return
	GGBktSOHZQaAeg8flFCYhsu = GGjBAkoVdze0hyCFK8v5L7(OdiZIyCfDUsW3JBGR2VAb.getSetting(s5WMHyQN4mpie(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡶ࡬ࡴࡸࡴࠨູ")))
	GGBktSOHZQaAeg8flFCYhsu = D2D96X5NGamBhrFwvL8VEbqiSfZIl if not GGBktSOHZQaAeg8flFCYhsu else int(GGBktSOHZQaAeg8flFCYhsu)
	if not GGBktSOHZQaAeg8flFCYhsu or not D2D96X5NGamBhrFwvL8VEbqiSfZIl<=VySKdWnH3vNq6klQ-GGBktSOHZQaAeg8flFCYhsu<=d9vcuo3Hy7RhAk2:
		OdiZIyCfDUsW3JBGR2VAb.setSetting(QjAINyUC7MDRq5d8e4vl9(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡷ࡭ࡵࡲࡵ຺ࠩ"),UAIXp7GJvrH64(VySKdWnH3vNq6klQ))
		uj8SWIk2fcadGNFs67ZLp0(oWMrx7zvedHY0UiS48XbOqVTJ)
		return
	QFI7KAeL1j2Ex0Ml = GGjBAkoVdze0hyCFK8v5L7(OdiZIyCfDUsW3JBGR2VAb.getSetting(CsDcLqQUVK4YBvHFW1(u"ࠬࡧࡶ࠯ࡲࡨࡶ࡮ࡵࡤ࠯࡫ࡱࡪࡴࡹࠧົ")))
	QFI7KAeL1j2Ex0Ml = D2D96X5NGamBhrFwvL8VEbqiSfZIl if not QFI7KAeL1j2Ex0Ml else int(QFI7KAeL1j2Ex0Ml)
	gNWEMcZLqXPjKRAxkd70o = GGjBAkoVdze0hyCFK8v5L7(OdiZIyCfDUsW3JBGR2VAb.getSetting(sIzDXlTHYUC5L3xZGnr(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨຼ")))
	gNWEMcZLqXPjKRAxkd70o = D2D96X5NGamBhrFwvL8VEbqiSfZIl if not gNWEMcZLqXPjKRAxkd70o else int(gNWEMcZLqXPjKRAxkd70o)
	if not QFI7KAeL1j2Ex0Ml or not gNWEMcZLqXPjKRAxkd70o or not D2D96X5NGamBhrFwvL8VEbqiSfZIl<=VySKdWnH3vNq6klQ-gNWEMcZLqXPjKRAxkd70o<=QFI7KAeL1j2Ex0Ml:
		iUdqzTacIxh1jlXQwLWbMA2Oy(EsCplGc5N4mBuYW0RVQt6b,QFI7KAeL1j2Ex0Ml)
		return
	v0N9MeCd5AqgVyYSZUL = GGjBAkoVdze0hyCFK8v5L7(OdiZIyCfDUsW3JBGR2VAb.getSetting(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡲࡦࡩࡸࡰࡦࡸࠧຽ")))
	v0N9MeCd5AqgVyYSZUL = D2D96X5NGamBhrFwvL8VEbqiSfZIl if not v0N9MeCd5AqgVyYSZUL else int(v0N9MeCd5AqgVyYSZUL)
	if not v0N9MeCd5AqgVyYSZUL or not D2D96X5NGamBhrFwvL8VEbqiSfZIl<=VySKdWnH3vNq6klQ-v0N9MeCd5AqgVyYSZUL<=CQOaFUrZJHwKRxIj4yXEYs5V:
		OdiZIyCfDUsW3JBGR2VAb.setSetting(s5WMHyQN4mpie(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡳࡧࡪࡹࡱࡧࡲࠨ຾"),UAIXp7GJvrH64(VySKdWnH3vNq6klQ))
		RKYsragFJfoQlEU1Mj5HPAnIDTS(LhFAGlQ19zr)
		return
	if XsDQkAWCEMaxHV28w1iO==o1INZ3ViQqS0Uw5z6kMjbv(u"࠷࠼࠰Ꭷ"):
		rTFWXgVHvEcAjD8S = OdiZIyCfDUsW3JBGR2VAb.getSetting(N6NGJ4vpmidqMCh7yo(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡰࡥࡣࡷࡩࠬ຿"))
		if N6NGJ4vpmidqMCh7yo(u"࡚ࠪࡊࡘࡉࡇࡋࡈࡈࠬເ") not in rTFWXgVHvEcAjD8S:
			import ZJYHCK5167
			AAkZvIgX4hcfMWtbK = ZJYHCK5167.WWDonUzRls5Z3dOgQhM(LhFAGlQ19zr)
			return
	OdiZIyCfDUsW3JBGR2VAb.setSetting(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡲࡧࡥࡹ࡫ࠧແ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	GAy2zDmrfnjCh56gQXFb = GGjBAkoVdze0hyCFK8v5L7(OdiZIyCfDUsW3JBGR2VAb.getSetting(QjAINyUC7MDRq5d8e4vl9(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡱࡵ࡮ࡨࠩໂ")))
	GAy2zDmrfnjCh56gQXFb = D2D96X5NGamBhrFwvL8VEbqiSfZIl if not GAy2zDmrfnjCh56gQXFb else int(GAy2zDmrfnjCh56gQXFb)
	if not GAy2zDmrfnjCh56gQXFb or not D2D96X5NGamBhrFwvL8VEbqiSfZIl<=VySKdWnH3vNq6klQ-GAy2zDmrfnjCh56gQXFb<=rrux12tcwQl5:
		OdiZIyCfDUsW3JBGR2VAb.setSetting(SnhLjmfeJC(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡲ࡯࡯ࡩࠪໃ"),UAIXp7GJvrH64(VySKdWnH3vNq6klQ))
		siEZBCaT9n8GXfLSx70j21yDoQ5VR3 = m6TaK8E5yuk(EsCplGc5N4mBuYW0RVQt6b)
	return
def m6TaK8E5yuk(showDialogs):
	J4NbqW35lrQnFhDZ0w = o1INZ3ViQqS0Uw5z6kMjbv(u"࠷࠰࠳࠶Ꭸ")*o1INZ3ViQqS0Uw5z6kMjbv(u"࠷࠰࠳࠶Ꭸ")
	LEpfGOn1wWiyI0eVZNklgR4 = au4qM5fhJ3lC()//J4NbqW35lrQnFhDZ0w
	siEZBCaT9n8GXfLSx70j21yDoQ5VR3 = LEpfGOn1wWiyI0eVZNklgR4<vU6DxuzPwMpg(u"࠵࠱Ꭹ")
	if siEZBCaT9n8GXfLSx70j21yDoQ5VR3:
		Clc8sIj97ZrThF(P3PazFblmtN,CsDcLqQUVK4YBvHFW1(u"ࠧࡄࡊࡈࡇࡐࡥࡄࡊࡕࡎࡣࡘࡖࡁࡄࡇࠣࠤ࡙ࠥࡔࡐࡔࡄࡋࡊࠦࡉࡔࠢࡉ࡙ࡑࡒࠠࠡࠢࠪໄ")+str(LEpfGOn1wWiyI0eVZNklgR4)+LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨࠢࡐࡆࠥࠧࠡࠡࠢࠣࠫ໅"))
		if showDialogs:
			size = n0nFOd4yR97fQzNLSW+jL5CrsRwebpyDVXUc1EQP(u"ࠩ็ำ๏้ࠠๆีสัฮࠦแศำ฽อࠥࠦࠧໆ")+str(LEpfGOn1wWiyI0eVZNklgR4)+N6NGJ4vpmidqMCh7yo(u"ࠪࠤ๋๊ࠥอษหห๏ะࠧ໇")+T7ASIp1ZYwio9HQ8cObJK
			Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,vU6DxuzPwMpg(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊า່ࠧ"),oRJAfwD957WkUyBM1Ehu8m(u"๋ࠬำศฯฬࠤฬ๊สฯิํ๊ࠥ็๊ࠡฮ๊หื้ࠠฤืหัฯࠦๅๆฬ็สฮࠦ࠮࠯๋๋ࠢีอ๋ࠠีหฬ๋ࠥิศๅ็ࠤ่ั๊าหࠣๅ๏ࠦสี฼ํ่ࠥอไอ้สึࠥ๎สี฼ํ่้่ࠥะ์ࠣ์ฯฺฺ๋ๆࠣฬึ์วๆฮࠣ฽๊อฯࠡ࠰࠱ࠤฬ์สࠡสะหัฯࠠฦๆ์ࠤฯ์ุ๋ใࠣะ์อาไ๋ࠢฮ๋฽๊โࠢๆ์ิ๐้ࠠฬ้฼๏็่ࠠาสࠤฬ๊ศา่ส้ัࠦ࠮࠯๊่ࠢࠥะั๋ัࠣห้ศๆࠡษ็ิ์อศࠡว็ํ่ࠥวว็ฬࠤฬ๊ส็ฺํๅࠥลࠡ࡝ࡰ࡟ࡲ້ࠬ")+size)
			if Scj7zgGFVA83otMpwUkxhm0BLN1==BkM54Kr7Qbqn:
				import ZJYHCK5167
				ZJYHCK5167.CLEANING_MENU()
	return siEZBCaT9n8GXfLSx70j21yDoQ5VR3
def iUdqzTacIxh1jlXQwLWbMA2Oy(vUTCBmuRD025KJ,QFI7KAeL1j2Ex0Ml):
	CzdVQEy6IjWi7LnBGAv = BkM54Kr7Qbqn
	UyMhfYkRQmqpXHzjdcE = LhFAGlQ19zr if I4t9qonjrm.g7OiLZfAHNlPJEUQCyx2pIrj else EsCplGc5N4mBuYW0RVQt6b
	if UyMhfYkRQmqpXHzjdcE:
		if not QFI7KAeL1j2Ex0Ml: vUTCBmuRD025KJ = LhFAGlQ19zr
		jERlJUwChexAXYk7yI = F0gSC4DoBWkRZvxJAperQqwO15df9y(vUTCBmuRD025KJ)
		if len(jERlJUwChexAXYk7yI)>BkM54Kr7Qbqn:
			Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,N6NGJ4vpmidqMCh7yo(u"࠭࠮࡝ࡶࡖ࡬ࡴࡽࡩ࡯ࡩࠣࡕࡺ࡫ࡳࡵ࡫ࡲࡲࠥࠦࠠࡑࡣࡷ࡬࠿໊࡛ࠦࠡࠩ")+LVXc6WJ3eAoz5hgnyrut1+C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧࠡ࡟໋ࠪ"))
			SXIxbZBW2zHeAV,jewzZuNFibTO,XZCwxtYWEcl8yqr9SHnG7,bb0r3L7XGeVihn,h3H4reNL8l26yPRtdKWg,iLXSma92HFtwhBKU = jERlJUwChexAXYk7yI[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			m5tbarSDPZ71xIMocU,ZkCs9oAl2bgw5LV0OGryB = bb0r3L7XGeVihn.split(LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨ࡞ࡱ࠿ࡀ࠭໌"))
			del jERlJUwChexAXYk7yI[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			LOq9nESWbt5YfDPz2smxej = yiTBYwps2mCrb4jGPux0cIJ.sample(jERlJUwChexAXYk7yI,BkM54Kr7Qbqn)
			SXIxbZBW2zHeAV,jewzZuNFibTO,XZCwxtYWEcl8yqr9SHnG7,bb0r3L7XGeVihn,h3H4reNL8l26yPRtdKWg,iLXSma92HFtwhBKU = LOq9nESWbt5YfDPz2smxej[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			XZCwxtYWEcl8yqr9SHnG7 = oRJAfwD957WkUyBM1Ehu8m(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨໍ")+WydpaVx5YmLoCiIgA34eEBlb+ssynAg0zhSkoCpOMDV9(u"ࠪࠤ࠿ࠦࠧ໎")+SXIxbZBW2zHeAV+T7ASIp1ZYwio9HQ8cObJK+XZCwxtYWEcl8yqr9SHnG7
			h3H4reNL8l26yPRtdKWg = EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠫสืำศๆࠣีุอไสࠢ็่๊ฮัๆฮࠪ໏")
			YVrybIQe0mvpAalF9 = V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠬอไหสิ฽ฬะࠧ໐")
			button0,button1 = bb0r3L7XGeVihn,h3H4reNL8l26yPRtdKWg
			cF7ZvJgUs4Yn81zuXto6xlEjV = [button0,button1,YVrybIQe0mvpAalF9]
			CD6ticV2rq9A = BkM54Kr7Qbqn if I4t9qonjrm.mzAtNn5gGow2Z else vU6DxuzPwMpg(u"࠲࠲Ꭺ")
			p7uvjbV1ftxo8yS6PNkH = -vU6DxuzPwMpg(u"࠻Ꭻ")
			while p7uvjbV1ftxo8yS6PNkH<D2D96X5NGamBhrFwvL8VEbqiSfZIl:
				bvq7dJHhlw8sFYa = yiTBYwps2mCrb4jGPux0cIJ.sample(cF7ZvJgUs4Yn81zuXto6xlEjV,XW57OCeGnFTLQbaqdrD9zM)
				p7uvjbV1ftxo8yS6PNkH = jPRJMOhT415yvioG8rN9m0Q3b(fy8iFgEkrO12NR9TWBI35sjY6qHvV,bvq7dJHhlw8sFYa[D2D96X5NGamBhrFwvL8VEbqiSfZIl],bvq7dJHhlw8sFYa[BkM54Kr7Qbqn],bvq7dJHhlw8sFYa[teaC5j4HuGDqpwcmUzJ],m5tbarSDPZ71xIMocU,XZCwxtYWEcl8yqr9SHnG7,aOQTKXFL54Nl60Zhp3MbE(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ໑"),CD6ticV2rq9A,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠹࠴Ꭼ"))
				if p7uvjbV1ftxo8yS6PNkH==C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠵࠵Ꭽ"): break
				import XbdWsnBA9G
				if p7uvjbV1ftxo8yS6PNkH>=D2D96X5NGamBhrFwvL8VEbqiSfZIl and bvq7dJHhlw8sFYa[p7uvjbV1ftxo8yS6PNkH]==cF7ZvJgUs4Yn81zuXto6xlEjV[BkM54Kr7Qbqn]:
					XbdWsnBA9G.YYuBnksbtX4WTE7ipPQmNgaZvy9U()
					if p7uvjbV1ftxo8yS6PNkH>=D2D96X5NGamBhrFwvL8VEbqiSfZIl: p7uvjbV1ftxo8yS6PNkH = -ssynAg0zhSkoCpOMDV9(u"࠾Ꭾ")
				elif p7uvjbV1ftxo8yS6PNkH>=D2D96X5NGamBhrFwvL8VEbqiSfZIl and bvq7dJHhlw8sFYa[p7uvjbV1ftxo8yS6PNkH]==cF7ZvJgUs4Yn81zuXto6xlEjV[teaC5j4HuGDqpwcmUzJ]:
					XbdWsnBA9G.ozs7B5fWTKAjX4gylCmviZpbL(LhFAGlQ19zr)
				if p7uvjbV1ftxo8yS6PNkH==-BkM54Kr7Qbqn: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,uulNDCPyef78(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ໒"),WydpaVx5YmLoCiIgA34eEBlb+N6NGJ4vpmidqMCh7yo(u"ࠨะิ์ัࠦฮุลࠪ໓")+T7ASIp1ZYwio9HQ8cObJK+N6NGJ4vpmidqMCh7yo(u"ࠩ࡟ࡲ๊ࠥไฯำ๋ะࠥอไึฯํัࠥษฮหำࠣ์ฬำฯࠡ็้ࠤฬ๊รอ๊หอࠥอไๆฬ๋ๅึฯࠧ໔"))
			CzdVQEy6IjWi7LnBGAv = BkM54Kr7Qbqn
		else: CzdVQEy6IjWi7LnBGAv = D2D96X5NGamBhrFwvL8VEbqiSfZIl
	OdiZIyCfDUsW3JBGR2VAb.setSetting(wdftVMyzF17cYETHu(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ໕"),UAIXp7GJvrH64(VySKdWnH3vNq6klQ))
	tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,N6NGJ4vpmidqMCh7yo(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ໖"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࡙ࠬࡉࡕࡇࡖࡣࡓࡇࡍࡆࡕࠪ໗"),CzdVQEy6IjWi7LnBGAv,zz2tnLhI1QHV7GwFCrv5)
	return
def kbyrd9iN4MIKYuJX2ZcOljBTmpzx(ZJqDh4ByGPQn13tlzMOTLCNdcugx,ekV6UX5gBZsaLHvOMCPF,zzekZcWL1sBgnoxN8f3vdQ0r,mmocwN1frQJ5ST3xa,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW,XsDQkAWCEMaxHV28w1iO,YadnQGoc0KNA8tiyrBx5ebCf2wPLM,bfGhu9m4HyY):
	if YadnQGoc0KNA8tiyrBx5ebCf2wPLM in [C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠭࠱ࠨ໘"),EE1jeHnIoad(u"ࠧ࠳ࠩ໙"),sJw9QWiq1Kr0xfeVRI(u"ࠨ࠵ࠪ໚"),AAbvaXV2DQzfNHdm4U3tT(u"ࠩ࠷ࠫ໛"),vU6DxuzPwMpg(u"ࠪ࠹ࠬໜ"),sIzDXlTHYUC5L3xZGnr(u"ࠫ࠶࠷ࠧໝ"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠬ࠷࠲ࠨໞ"),O3OVuapf0YFjbm5oUQDg(u"࠭࠱࠴ࠩໟ")] and bfGhu9m4HyY:
		import kxdqilYRPe
		kxdqilYRPe.UUV61NDj9xlkwbHqiYJzZ7BAWO(vBs70HtgMbzd6n3NwUpxe,YadnQGoc0KNA8tiyrBx5ebCf2wPLM,bfGhu9m4HyY)
		ejX7kGtQ4hcYUHW9b31vriuZLM6Sp(LhFAGlQ19zr,LVXc6WJ3eAoz5hgnyrut1)
	elif YadnQGoc0KNA8tiyrBx5ebCf2wPLM==FgXzMs0YSDt(u"ࠧ࠷ࠩ໠"):
		import i8zOgXMb2I
		if bfGhu9m4HyY==sIzDXlTHYUC5L3xZGnr(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ໡"): i8zOgXMb2I.a6rVSjDMF87KyYINcuOP1l40Hbp(EE1jeHnIoad(u"ࠩํีั๏ࠠศๆส๊ฯ฾วาࠩ໢"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠪะฬื๊ࠡใะู๋ࠥไโࠢส่ฯำๅ๋ๆࠪ໣"),uUqrNPcXKBoQ0slv=V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠸࠰࠱࠲Ꭿ"))
		elif bfGhu9m4HyY==FgXzMs0YSDt(u"ࠫࡉࡋࡌࡆࡖࡈࠫ໤"): VuEbh9TjOx2w1d7DcfX50(eEncXMVB2rNg4JObl3utYfj,LhFAGlQ19zr)
		OmsWt89dSA5HyCZ4wL = i8zOgXMb2I.KYAmF1b4205(ZJqDh4ByGPQn13tlzMOTLCNdcugx,ekV6UX5gBZsaLHvOMCPF,zzekZcWL1sBgnoxN8f3vdQ0r,XsDQkAWCEMaxHV28w1iO,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW)
		if bfGhu9m4HyY==wdftVMyzF17cYETHu(u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ໥"): n9grXGiQYD2wl8UjSRe3HcKhE()
	elif vBs70HtgMbzd6n3NwUpxe==oRJAfwD957WkUyBM1Ehu8m(u"࠭࠷ࠨ໦"):
		import msb3A1OhNH
		msb3A1OhNH.oz4MhAk6qid0lFcROXx1bV7(O3OVuapf0YFjbm5oUQDg(u"ࠧࡠࡃࡏࡐࠬ໧"))
		ejX7kGtQ4hcYUHW9b31vriuZLM6Sp(LhFAGlQ19zr)
	elif vBs70HtgMbzd6n3NwUpxe==oRJAfwD957WkUyBM1Ehu8m(u"ࠨ࠺ࠪ໨"): bEWpDHXjCBqd7aOiN6UG5k.executebuiltin(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ໩")+SZvQ0Jre4BHyGVFxoPYM2IU6+EE1jeHnIoad(u"ࠪࡃࡲࡵࡤࡦ࠿ࠪ໪")+str(mmocwN1frQJ5ST3xa)+I18uSKaWhgTBeYUPD4sr(u"ࠫࠫࡺࡹࡱࡧࡀࡪࡴࡲࡤࡦࡴࠬࠫ໫"))
	elif vBs70HtgMbzd6n3NwUpxe==vU6DxuzPwMpg(u"ࠬ࠿ࠧ໬"):
		ejX7kGtQ4hcYUHW9b31vriuZLM6Sp(EsCplGc5N4mBuYW0RVQt6b)
	elif vBs70HtgMbzd6n3NwUpxe==QjAINyUC7MDRq5d8e4vl9(u"࠭࠱࠱ࠩ໭"):
		import msb3A1OhNH
		msb3A1OhNH.oz4MhAk6qid0lFcROXx1bV7(oRJAfwD957WkUyBM1Ehu8m(u"ࠧࡠࡉࡒࡓࡌࡒࡅࠨ໮"))
		ejX7kGtQ4hcYUHW9b31vriuZLM6Sp(LhFAGlQ19zr)
	elif vBs70HtgMbzd6n3NwUpxe==wdftVMyzF17cYETHu(u"ࠨ࠳࠷ࠫ໯"): ejX7kGtQ4hcYUHW9b31vriuZLM6Sp(EsCplGc5N4mBuYW0RVQt6b,Hr25gta6XcqO(u"ࠩࡐࡉࡓ࡛࡟ࡓࡇ࡙ࡉࡗ࡙ࡅࡅࡡࡗࡉࡒࡖࠧ໰"))
	elif vBs70HtgMbzd6n3NwUpxe==uulNDCPyef78(u"ࠪ࠵࠺࠭໱"): ejX7kGtQ4hcYUHW9b31vriuZLM6Sp(EsCplGc5N4mBuYW0RVQt6b,vU6DxuzPwMpg(u"ࠫࡒࡋࡎࡖࡡࡄࡗࡈࡋࡎࡅࡇࡇࡣ࡙ࡋࡍࡑࠩ໲"))
	elif vBs70HtgMbzd6n3NwUpxe==I18uSKaWhgTBeYUPD4sr(u"ࠬ࠷࠶ࠨ໳"): ejX7kGtQ4hcYUHW9b31vriuZLM6Sp(EsCplGc5N4mBuYW0RVQt6b,CsDcLqQUVK4YBvHFW1(u"࠭ࡍࡆࡐࡘࡣࡉࡋࡓࡄࡇࡑࡈࡊࡊ࡟ࡕࡇࡐࡔࠬ໴"))
	elif vBs70HtgMbzd6n3NwUpxe==jL5CrsRwebpyDVXUc1EQP(u"ࠧ࠲࠹ࠪ໵"): ejX7kGtQ4hcYUHW9b31vriuZLM6Sp(EsCplGc5N4mBuYW0RVQt6b,oRJAfwD957WkUyBM1Ehu8m(u"ࠨࡏࡈࡒ࡚ࡥࡒࡂࡐࡇࡓࡒࡏ࡚ࡆࡆࡢࡘࡊࡓࡐࠨ໶"))
	elif vBs70HtgMbzd6n3NwUpxe==QjAINyUC7MDRq5d8e4vl9(u"ࠩ࠴࠼ࠬ໷"):
		gn2DUcWhvjpC4ZR0lr3bJO61GPVX = OdiZIyCfDUsW3JBGR2VAb.getSetting(EE1jeHnIoad(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡢࡪࡶࡵࡥࡹ࡫ࠧ໸"))
		OdiZIyCfDUsW3JBGR2VAb.setSetting(aOQTKXFL54Nl60Zhp3MbE(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡣ࡫ࡷࡶࡦࡺࡥࠨ໹"),ggjO5CrKVRPITaesWkxD(u"ࠬ࠳ࠧ໺")+gn2DUcWhvjpC4ZR0lr3bJO61GPVX)
	if vBs70HtgMbzd6n3NwUpxe in [o1INZ3ViQqS0Uw5z6kMjbv(u"࠭࠹ࠨ໻"),QjAINyUC7MDRq5d8e4vl9(u"ࠧ࠲࠶ࠪ໼"),aOQTKXFL54Nl60Zhp3MbE(u"ࠨ࠳࠸ࠫ໽"),uulNDCPyef78(u"ࠩ࠴࠺ࠬ໾"),PlpyFa9QMKXxOD1cvHzmI(u"ࠪ࠵࠼࠭໿")]: n9grXGiQYD2wl8UjSRe3HcKhE()
	return
def DWPvwMbjUs71TlHAezRtSkdNGZFu(ZJqDh4ByGPQn13tlzMOTLCNdcugx,ekV6UX5gBZsaLHvOMCPF,zzekZcWL1sBgnoxN8f3vdQ0r,mmocwN1frQJ5ST3xa,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW,XsDQkAWCEMaxHV28w1iO,YadnQGoc0KNA8tiyrBx5ebCf2wPLM,bfGhu9m4HyY,ffWgMXo20Hb5xurkdNqa):
	if VrXZUMQwAoOIg1D8Bjk4s2hfC7EGPv: FpJlg5HtRh0wqA1()
	if vBs70HtgMbzd6n3NwUpxe: kbyrd9iN4MIKYuJX2ZcOljBTmpzx(ZJqDh4ByGPQn13tlzMOTLCNdcugx,ekV6UX5gBZsaLHvOMCPF,zzekZcWL1sBgnoxN8f3vdQ0r,mmocwN1frQJ5ST3xa,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW,XsDQkAWCEMaxHV28w1iO,YadnQGoc0KNA8tiyrBx5ebCf2wPLM,bfGhu9m4HyY)
	HDTAWUgLVv8xZP3BI6O2F(XsDQkAWCEMaxHV28w1iO)
	global cFTiOCdrXfgnKx0vh948jU7pSEb,TwR9dnEiDPblt6Nzs8QMrX0VqO2om4,Yc24yz3S6stmNI
	for C0C4kdG53sPAbNq8OBMpitLThHl in I4t9qonjrm.BADWEBSITES:
		if C0C4kdG53sPAbNq8OBMpitLThHl in cFTiOCdrXfgnKx0vh948jU7pSEb: cFTiOCdrXfgnKx0vh948jU7pSEb.remove(C0C4kdG53sPAbNq8OBMpitLThHl)
		if C0C4kdG53sPAbNq8OBMpitLThHl in TwR9dnEiDPblt6Nzs8QMrX0VqO2om4: TwR9dnEiDPblt6Nzs8QMrX0VqO2om4.remove(C0C4kdG53sPAbNq8OBMpitLThHl)
		if C0C4kdG53sPAbNq8OBMpitLThHl in Yc24yz3S6stmNI: Yc24yz3S6stmNI.remove(C0C4kdG53sPAbNq8OBMpitLThHl)
	ddecO3Tb9U5k,fgVdURyLzPjI,fSRzdU79pPieXuFngrAwE5BovZa = EsCplGc5N4mBuYW0RVQt6b,LhFAGlQ19zr,LhFAGlQ19zr
	A4w79VioRZcdJkbGaf5QuWPv = R1Nd6hUaBrtXDnwGxHv30QqA7MF(ZJqDh4ByGPQn13tlzMOTLCNdcugx,ekV6UX5gBZsaLHvOMCPF,zzekZcWL1sBgnoxN8f3vdQ0r,mmocwN1frQJ5ST3xa,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW,XsDQkAWCEMaxHV28w1iO,ffWgMXo20Hb5xurkdNqa,ddecO3Tb9U5k,fgVdURyLzPjI,fSRzdU79pPieXuFngrAwE5BovZa)
	JVgroCaZ8cKm6PyWk,gYT79cyvtiJkrDNOH,dO2WUXLbsnI4w,DDVFlXjdHQsc5nfigO1wPReZSU46,cINfX4hoOEB3mzwGVkR5J0v97PxM6,I9JxgXfkoRy2FL6M5VO,D4nbjOcvH0RsW3,nGtrZ31ym5 = A4w79VioRZcdJkbGaf5QuWPv
	if JVgroCaZ8cKm6PyWk: return
	if gYT79cyvtiJkrDNOH==oRJAfwD957WkUyBM1Ehu8m(u"ࠫࡗࡋࡆࡓࡇࡖࡌࡤࡉࡁࡄࡊࡈࠫༀ"): uj8SWIk2fcadGNFs67ZLp0(oWMrx7zvedHY0UiS48XbOqVTJ)
	X0FQnRaH9WyrEJcl7dj6w4kuDL(s5WMHyQN4mpie(u"ࠬࡹࡴࡢࡴࡷࠫ༁"))
	if OdiZIyCfDUsW3JBGR2VAb.getSetting(wdftVMyzF17cYETHu(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬ༂")) not in [Gcw2nelTR864XCVruO3mAFqI5a(u"ࠧࡂࡗࡗࡓࠬ༃"),Hr25gta6XcqO(u"ࠨࡕࡗࡓࡕ࠭༄"),O3OVuapf0YFjbm5oUQDg(u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪ༅")]:
		OdiZIyCfDUsW3JBGR2VAb.setSetting(aOQTKXFL54Nl60Zhp3MbE(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡨࡵࡶࡳࡧࡦࡩࡨࡦࠩ༆"),aOQTKXFL54Nl60Zhp3MbE(u"ࠫࡆ࡛ࡔࡐࠩ༇"))
	if not OdiZIyCfDUsW3JBGR2VAb.getSetting(I18uSKaWhgTBeYUPD4sr(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡦࡱࡷࠬ༈")): OdiZIyCfDUsW3JBGR2VAb.setSetting(AAbvaXV2DQzfNHdm4U3tT(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡧࡲࡸ࠭༉"),I4t9qonjrm.DNS_SERVERS[D2D96X5NGamBhrFwvL8VEbqiSfZIl])
	OmsWt89dSA5HyCZ4wL = KYAmF1b4205(ZJqDh4ByGPQn13tlzMOTLCNdcugx,ekV6UX5gBZsaLHvOMCPF,zzekZcWL1sBgnoxN8f3vdQ0r,mmocwN1frQJ5ST3xa,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW)
	if o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ༊") in YQDmGRx3CWc2HX9V0wa4O: fgVdURyLzPjI = EsCplGc5N4mBuYW0RVQt6b
	if ZJqDh4ByGPQn13tlzMOTLCNdcugx==oRJAfwD957WkUyBM1Ehu8m(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ་"):
		if DDVFlXjdHQsc5nfigO1wPReZSU46!=wdftVMyzF17cYETHu(u"ࠩ࠱࠲ࠬ༌") and cINfX4hoOEB3mzwGVkR5J0v97PxM6: l6ZKMsbVcHhp5rmQ34wG()
		if oqnaT0F83OCGAY5jute6rJ2U>-BkM54Kr7Qbqn:
			SMWuTja2BCYArvctFV8wo = [D2D96X5NGamBhrFwvL8VEbqiSfZIl,EE1jeHnIoad(u"࠲࠷Ꮁ"),PlpyFa9QMKXxOD1cvHzmI(u"࠳࠺Ꮂ"),ggjO5CrKVRPITaesWkxD(u"࠴࠽Ꮃ"),oRJAfwD957WkUyBM1Ehu8m(u"࠲࠷Ꮀ"),I18uSKaWhgTBeYUPD4sr(u"࠹࠴Ꮆ"),jL5CrsRwebpyDVXUc1EQP(u"࠹࠵Ꮄ"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠺࠹Ꮅ")]
			if (rIhXWK91vRuC(jUCABmLYMf0G,SnhLjmfeJC(u"ࠪ࡭ࡳࡺࠧ།"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ༎"),KfHAW8VGbrxi(u"࡙ࠬࡉࡕࡇࡖࡣࡓࡇࡍࡆࡕࠪ༏")) or XsDQkAWCEMaxHV28w1iO not in SMWuTja2BCYArvctFV8wo) and not I4t9qonjrm.tFkvuaLGpKHMI2l5J:
				from ZJYHCK5167 import ebc0OIJdzPhDw
				OOZEpmK56arPzeQlix8GqFL9ko = CCiE567eoLhA4Vq(ebc0OIJdzPhDw)
				JVgroCaZ8cKm6PyWk = KKxbu3MCGsd2YE8p(dO2WUXLbsnI4w,OOZEpmK56arPzeQlix8GqFL9ko,ddecO3Tb9U5k,fgVdURyLzPjI,fSRzdU79pPieXuFngrAwE5BovZa)
				if OOZEpmK56arPzeQlix8GqFL9ko and I9JxgXfkoRy2FL6M5VO:
					tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠭ࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࡣࠬ༐")+D4nbjOcvH0RsW3+FmYoGejTnwKME7d9zPc(u"ࠧࡠࠩ༑")+nGtrZ31ym5,dO2WUXLbsnI4w,OOZEpmK56arPzeQlix8GqFL9ko,CQOaFUrZJHwKRxIj4yXEYs5V)
			else:
				ySNqmb2Ih3.addDirectoryItem(oqnaT0F83OCGAY5jute6rJ2U,SnhLjmfeJC(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫ༒")+SZvQ0Jre4BHyGVFxoPYM2IU6+PlpyFa9QMKXxOD1cvHzmI(u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿࡯࡭ࡳࡱࠦ࡮ࡱࡧࡩࡂ࠻࠰࠱ࠩ༓"),nn19vN7ifGslVJODZWzCSudBK8.ListItem(SnhLjmfeJC(u"่ࠪิ๐ใࠡ็ื็้ฯࠠๆ่ࠣะ์อาไࠩ༔")))
				ySNqmb2Ih3.addDirectoryItem(oqnaT0F83OCGAY5jute6rJ2U,FmYoGejTnwKME7d9zPc(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧ༕")+SZvQ0Jre4BHyGVFxoPYM2IU6+ggjO5CrKVRPITaesWkxD(u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡲࡩ࡯࡭ࠩࡱࡴࡪࡥ࠾࠷࠳࠴ࠬ༖"),nn19vN7ifGslVJODZWzCSudBK8.ListItem(o1INZ3ViQqS0Uw5z6kMjbv(u"࠭รโฬะࠤ้ะโาลࠣห้ะแศืํ่ࠬ༗")))
			ySNqmb2Ih3.endOfDirectory(oqnaT0F83OCGAY5jute6rJ2U,ddecO3Tb9U5k,fgVdURyLzPjI,fSRzdU79pPieXuFngrAwE5BovZa)
	return
def uj8SWIk2fcadGNFs67ZLp0(zeQGm0x2kyo4DR93JhFAp6TdrlWY):
	if LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔ༘ࠩ") in str(I4t9qonjrm.SEND_THESE_EVENTS): return
	RM83xUCLyI0SehGwukDaiA1n = LhFAGlQ19zr if zeQGm0x2kyo4DR93JhFAp6TdrlWY else EsCplGc5N4mBuYW0RVQt6b
	if not RM83xUCLyI0SehGwukDaiA1n:
		EtHn4ryqFPvoR7Agl0CBspuab32V = GGjBAkoVdze0hyCFK8v5L7(OdiZIyCfDUsW3JBGR2VAb.getSetting(AAbvaXV2DQzfNHdm4U3tT(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴ༙ࠩ")))
		EtHn4ryqFPvoR7Agl0CBspuab32V = D2D96X5NGamBhrFwvL8VEbqiSfZIl if not EtHn4ryqFPvoR7Agl0CBspuab32V else int(EtHn4ryqFPvoR7Agl0CBspuab32V)
		if not EtHn4ryqFPvoR7Agl0CBspuab32V or not D2D96X5NGamBhrFwvL8VEbqiSfZIl<=VySKdWnH3vNq6klQ-EtHn4ryqFPvoR7Agl0CBspuab32V<=zeQGm0x2kyo4DR93JhFAp6TdrlWY: RM83xUCLyI0SehGwukDaiA1n = EsCplGc5N4mBuYW0RVQt6b
	if not RM83xUCLyI0SehGwukDaiA1n:
		czSpy6MGP9kTFhI1B37lHjJ4RAf5 = OdiZIyCfDUsW3JBGR2VAb.getSetting(oRJAfwD957WkUyBM1Ehu8m(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ༚"))
		if czSpy6MGP9kTFhI1B37lHjJ4RAf5 in [fy8iFgEkrO12NR9TWBI35sjY6qHvV,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪࡓࡑࡊ࡟ࡕࡑࡢࡉࡗࡘࡏࡓࠩ༛"),Hr25gta6XcqO(u"ࠫࡓࡋࡗࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪ༜")]: RM83xUCLyI0SehGwukDaiA1n = EsCplGc5N4mBuYW0RVQt6b
	if not RM83xUCLyI0SehGwukDaiA1n:
		hKWEVD8TYl7rsjn0qcAN = OdiZIyCfDUsW3JBGR2VAb.getSetting(EE1jeHnIoad(u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹ࠱ࠨ༝"))
		vvPmnHekOc7qrjidMwxf134VD,aaLcdPtZmTG4ir = zjBDwxSgrTZkle0N1WPFEUq5d9y3(jUCABmLYMf0G)
		aaLcdPtZmTG4ir.execute(CsDcLqQUVK4YBvHFW1(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱࡣ࡮ࡪ࠻ࠨ༞"))
		FG0eAEdZ9gaUJ8Xmv2xs = str(aaLcdPtZmTG4ir.fetchall()[PlpyFa9QMKXxOD1cvHzmI(u"࠰Ꮇ")][PlpyFa9QMKXxOD1cvHzmI(u"࠰Ꮇ")])
		vvPmnHekOc7qrjidMwxf134VD.close()
		YMFiErscPW2Z = bSyIhTmVdu8sDCPHiU5pXQ1OK.md5(uulNDCPyef78(u"࠶Ꮈ")*hKWEVD8TYl7rsjn0qcAN.encode(Tk9eH2qw6Brsuhj)).hexdigest()
		YMFiErscPW2Z = bSyIhTmVdu8sDCPHiU5pXQ1OK.md5(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠳࠷Ꮉ")*YMFiErscPW2Z.encode(Tk9eH2qw6Brsuhj)).hexdigest()
		YMFiErscPW2Z = bSyIhTmVdu8sDCPHiU5pXQ1OK.md5(oRJAfwD957WkUyBM1Ehu8m(u"࠴࠽Ꮊ")*YMFiErscPW2Z.encode(Tk9eH2qw6Brsuhj)).hexdigest()
		YMFiErscPW2Z = str(int(YMFiErscPW2Z[sJw9QWiq1Kr0xfeVRI(u"࠸Ꮌ"):oRJAfwD957WkUyBM1Ehu8m(u"࠷࠲Ꮍ")],I18uSKaWhgTBeYUPD4sr(u"࠱࠷Ꮎ")))[:vU6DxuzPwMpg(u"࠽Ꮋ")]
		if YMFiErscPW2Z!=FG0eAEdZ9gaUJ8Xmv2xs: RM83xUCLyI0SehGwukDaiA1n = EsCplGc5N4mBuYW0RVQt6b
	if RM83xUCLyI0SehGwukDaiA1n: dBRZV0CzgA8EXuFhrqfl(LhFAGlQ19zr)
	return
def ppWjXFHqhOrlMzRf2N7vL6(Wsv5B14O6xFLqJ,iLXSma92HFtwhBKU,mE7D5fBQZOKJdhtVUkHaIgRWpx,showDialogs):
	C0C4kdG53sPAbNq8OBMpitLThHl = mE7D5fBQZOKJdhtVUkHaIgRWpx.split(oRJAfwD957WkUyBM1Ehu8m(u"ࠧ࠮ࠩ༟"),BkM54Kr7Qbqn)[D2D96X5NGamBhrFwvL8VEbqiSfZIl] if PlpyFa9QMKXxOD1cvHzmI(u"ࠨ࠯ࠪ༠") in mE7D5fBQZOKJdhtVUkHaIgRWpx else mE7D5fBQZOKJdhtVUkHaIgRWpx
	if not showDialogs or mE7D5fBQZOKJdhtVUkHaIgRWpx in UUSxo7uMnZIWd0kcyi1Gz: return LhFAGlQ19zr
	VKqdbyfFj47OH1XLADpt6 = OdiZIyCfDUsW3JBGR2VAb.getSetting(N6NGJ4vpmidqMCh7yo(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ༡"))
	OdiZIyCfDUsW3JBGR2VAb.setSetting(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫ༢"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	k3D5usGaJWCY87 = Wsv5B14O6xFLqJ in [LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠻Ꮒ"),I18uSKaWhgTBeYUPD4sr(u"࠳࠴࠴࠵࠷Ꮐ"),o1INZ3ViQqS0Uw5z6kMjbv(u"࠲࠳࠳࠴࠷Ꮏ"),ggjO5CrKVRPITaesWkxD(u"࠴࠴࠵࠻࠴Ꮑ")]
	wckKyi048Fl = iLXSma92HFtwhBKU.lower()
	XX9yWhkMcRof3Cj2EF0 = Wsv5B14O6xFLqJ in [D2D96X5NGamBhrFwvL8VEbqiSfZIl,CsDcLqQUVK4YBvHFW1(u"࠱࠱࠶Ꮕ"),I18uSKaWhgTBeYUPD4sr(u"࠶࠶࠰࠷࠳Ꮓ"),CsDcLqQUVK4YBvHFW1(u"࠷࠱࠲Ꮔ")]
	BFxsaGOTPqt = FgXzMs0YSDt(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠬ༣") in wckKyi048Fl
	aCE6AZFrcfB = aOQTKXFL54Nl60Zhp3MbE(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢ࠸ࠤࡸ࡫ࡣࡰࡰࡧࡷࠥࡨࡲࡰࡹࡶࡩࡷࠦࡣࡩࡧࡦ࡯ࠬ༤") in wckKyi048Fl
	mK0f9e7CtqWA = ssynAg0zhSkoCpOMDV9(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠭༥") in wckKyi048Fl
	KcMQzXZ9qRPk6 = FgXzMs0YSDt(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠡࡵࡨࡧࡺࡸࡩࡵࡻࠣࡧ࡭࡫ࡣ࡬ࠩ༦") in wckKyi048Fl
	l7K2Xo9Rei3 = OdiZIyCfDUsW3JBGR2VAb.getSetting(N6NGJ4vpmidqMCh7yo(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭༧"))
	DZ4Xco30UIJB7KR = OdiZIyCfDUsW3JBGR2VAb.getSetting(oRJAfwD957WkUyBM1Ehu8m(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬ༨"))
	u3moYGV69X = Hr25gta6XcqO(u"ࠪๅู๊ࠠโ์ࠣืาฮࠠศๆุๅาฯࠠๆ่ࠣห้หๆหำ้ฮࠬ༩")
	xrZQ0I8cagLbSO = EE1jeHnIoad(u"ࠫࡊࡸࡲࡰࡴࠣࠫ༪")+str(Wsv5B14O6xFLqJ)+FmYoGejTnwKME7d9zPc(u"ࠬࡀࠠࠨ༫")+iLXSma92HFtwhBKU
	xrZQ0I8cagLbSO = U2Z7CVFftTmLeK3nzEbQPGga(xrZQ0I8cagLbSO)
	if XX9yWhkMcRof3Cj2EF0 or BFxsaGOTPqt or aCE6AZFrcfB or mK0f9e7CtqWA or KcMQzXZ9qRPk6: u3moYGV69X += ggjO5CrKVRPITaesWkxD(u"࠭ࠠ࠯ࠢส่๊๎โฺࠢไ๎์ࠦออสฺࠣิࠦใ้ัํࠤ๊฻ฯา้ࠣห้หๆหำ้ฮࠥอไฯษุࠤอ้ࠠฤ๊ࠣฬฬ๊ๅ้ไ฼ࡠࡳ࠭༬")
	if k3D5usGaJWCY87: u3moYGV69X += oRJAfwD957WkUyBM1Ehu8m(u"ࠧࠡ࠰่ࠣิ๐ใࠡะฺวࠥࡊࡎࡔ๋้ࠢ฾์ว่ࠢอ฽ีืࠠหำฯ้ฮࠦวิ็ࠣห้๋่ใ฻ࠣษ้๏ࠠาไ่๋ࡡࡴࠧ༭")
	xrZQ0I8cagLbSO = C0qrknitpM4Z+n0nFOd4yR97fQzNLSW+xrZQ0I8cagLbSO+T7ASIp1ZYwio9HQ8cObJK
	if l7K2Xo9Rei3==ggjO5CrKVRPITaesWkxD(u"ࠨࡃࡖࡏࠬ༮") or DZ4Xco30UIJB7KR==ggjO5CrKVRPITaesWkxD(u"ࠩࡄࡗࡐ࠭༯"):
		u3moYGV69X += C0qrknitpM4Z+WydpaVx5YmLoCiIgA34eEBlb+N6NGJ4vpmidqMCh7yo(u"๋้ࠪࠦสา์าࠤศ์๋ࠠฯส์้ࠦวๅสิ๊ฬ๋ฬࠡวุ่ฬำࠠศๆุ่่๊ษࠡ࠰࠱ࠤศ๋ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣวํࠦฮุลࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡมࠤࠥࠬ༰")+T7ASIp1ZYwio9HQ8cObJK
	Tlnfx1FoiQUXh6dGueYL2mIsB7KM = LhFAGlQ19zr
	if l7K2Xo9Rei3==N6NGJ4vpmidqMCh7yo(u"ࠫࡆ࡙ࡋࠨ༱") or DZ4Xco30UIJB7KR==s5WMHyQN4mpie(u"ࠬࡇࡓࡌࠩ༲"):
		p7uvjbV1ftxo8yS6PNkH = jPRJMOhT415yvioG8rN9m0Q3b(uulNDCPyef78(u"࠭ࡣࡦࡰࡷࡩࡷ࠭༳"),s5WMHyQN4mpie(u"ࠧฯำ๋ะࠬ༴"),QjAINyUC7MDRq5d8e4vl9(u"ࠨวิืฬ๊ࠠๅๆ่ฬึ๋ฬࠨ༵"),CsDcLqQUVK4YBvHFW1(u"ࠩอู้๐อࠡษ็ู้้ไสࠩ༶"),C0C4kdG53sPAbNq8OBMpitLThHl+yU7COAbsNJ916v5L0oew2n+eJYnofQG4mc8aFiN(C0C4kdG53sPAbNq8OBMpitLThHl),u3moYGV69X+C0qrknitpM4Z+xrZQ0I8cagLbSO)
		if p7uvjbV1ftxo8yS6PNkH==BkM54Kr7Qbqn:
			from XbdWsnBA9G import YYuBnksbtX4WTE7ipPQmNgaZvy9U
			YYuBnksbtX4WTE7ipPQmNgaZvy9U()
		elif p7uvjbV1ftxo8yS6PNkH==teaC5j4HuGDqpwcmUzJ: Tlnfx1FoiQUXh6dGueYL2mIsB7KM = EsCplGc5N4mBuYW0RVQt6b
	else: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,C0C4kdG53sPAbNq8OBMpitLThHl+yU7COAbsNJ916v5L0oew2n+eJYnofQG4mc8aFiN(C0C4kdG53sPAbNq8OBMpitLThHl),u3moYGV69X,xrZQ0I8cagLbSO)
	OdiZIyCfDUsW3JBGR2VAb.setSetting(EE1jeHnIoad(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨ༷ࠫ"),VKqdbyfFj47OH1XLADpt6)
	return Tlnfx1FoiQUXh6dGueYL2mIsB7KM
def eegO4os7SYNkhv(TN1e4p9jbnQBLUy=LhFAGlQ19zr,NJ1nCTi5jF4uGsPkI=[]):
	cclWvgP9mIdzT4anjKSHUfs = [bVeH60CmPM,mmFzNZYEJpdqUro7sKMj6W2]+NJ1nCTi5jF4uGsPkI
	for lDmQVa3oFnhqWcbSX in HoxKENAey2MdTt9kDUrVnWGLS0CPa.listdir(Xsc4lqOhdziToWvunbRNSQZKIY8E):
		if TN1e4p9jbnQBLUy and (lDmQVa3oFnhqWcbSX.startswith(ssynAg0zhSkoCpOMDV9(u"ࠫ࡮ࡶࡴࡷࠩ༸")) or lDmQVa3oFnhqWcbSX.startswith(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬࡳ࠳ࡶ༹ࠩ"))): continue
		if lDmQVa3oFnhqWcbSX.startswith(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠭ࡦࡪ࡮ࡨࡣࠬ༺")): continue
		tLpdG24bzu6RCaX0 = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(Xsc4lqOhdziToWvunbRNSQZKIY8E,lDmQVa3oFnhqWcbSX)
		if tLpdG24bzu6RCaX0 in cclWvgP9mIdzT4anjKSHUfs: continue
		try: HoxKENAey2MdTt9kDUrVnWGLS0CPa.remove(tLpdG24bzu6RCaX0)
		except: pass
	if P8F6NtJD5ridLmglTbWpzMo4 not in cclWvgP9mIdzT4anjKSHUfs: rSOlpJAWb8Vh(P8F6NtJD5ridLmglTbWpzMo4,EsCplGc5N4mBuYW0RVQt6b,LhFAGlQ19zr)
	uUqrNPcXKBoQ0slv.sleep(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠲Ꮖ"))
	return
def wFMo6RkqpIhBGOvnKiYQmf(kD0FgO3GoQv6xH,iXYEGvtThUqFPJ4pHLZSnNRr29Ako,zzekZcWL1sBgnoxN8f3vdQ0r,O6N8nhyYTD12KRApqkLzVi,GAwfpnzSiJEcHtQjDul1LsPN2YT0x9,dvFPH1zieGquOp9X7xf,showDialogs,mE7D5fBQZOKJdhtVUkHaIgRWpx,XTvQLmPSpkysbtg6wO3z4=EsCplGc5N4mBuYW0RVQt6b,ds7kBa05cXn8oy9gAxmNKvV3TIp4=EsCplGc5N4mBuYW0RVQt6b):
	zzekZcWL1sBgnoxN8f3vdQ0r = zzekZcWL1sBgnoxN8f3vdQ0r+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧ༻")+kD0FgO3GoQv6xH
	ND4YsIrucC = TBPcjsyOYoM82pm(rrux12tcwQl5,iXYEGvtThUqFPJ4pHLZSnNRr29Ako,zzekZcWL1sBgnoxN8f3vdQ0r,O6N8nhyYTD12KRApqkLzVi,GAwfpnzSiJEcHtQjDul1LsPN2YT0x9,dvFPH1zieGquOp9X7xf,showDialogs,mE7D5fBQZOKJdhtVUkHaIgRWpx,XTvQLmPSpkysbtg6wO3z4,ds7kBa05cXn8oy9gAxmNKvV3TIp4)
	if zzekZcWL1sBgnoxN8f3vdQ0r in ND4YsIrucC.content: ND4YsIrucC.succeeded = LhFAGlQ19zr
	if not ND4YsIrucC.succeeded:
		n9grXGiQYD2wl8UjSRe3HcKhE()
	return ND4YsIrucC
def XMGbIjCUc4iRl(zzekZcWL1sBgnoxN8f3vdQ0r):
	ND4YsIrucC = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,EE1jeHnIoad(u"ࠨࡉࡈࡘࠬ༼"),zzekZcWL1sBgnoxN8f3vdQ0r,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EsCplGc5N4mBuYW0RVQt6b,fy8iFgEkrO12NR9TWBI35sjY6qHvV,SnhLjmfeJC(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡑࡔࡒ࡜ࡎࡋࡓࡠࡎࡌࡗ࡙࠳࠱ࡴࡶࠪ༽"),EsCplGc5N4mBuYW0RVQt6b,LhFAGlQ19zr)
	XHDxRIfJq8ohTPpnA6jOd = []
	if ND4YsIrucC.succeeded:
		Vpnd4wgPqAO1j6z8N = ND4YsIrucC.content
		ruOZkjftmMDxywTvKNSY = EcQxOa3RJm86WjTKA.findall(vU6DxuzPwMpg(u"ࠪࠤ࠭࠴ࠪࡀࠫࠣࡠࡩࢁ࠱࠭࠵ࢀࡱࡸ࠭༾"),Vpnd4wgPqAO1j6z8N)
		if ruOZkjftmMDxywTvKNSY: Vpnd4wgPqAO1j6z8N = C0qrknitpM4Z.join(ruOZkjftmMDxywTvKNSY)
		PN5tzsvxSBd2iUg = Vpnd4wgPqAO1j6z8N.replace(FFkml6ZbgXD,fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(C0qrknitpM4Z).split(C0qrknitpM4Z)
		XHDxRIfJq8ohTPpnA6jOd = []
		for kD0FgO3GoQv6xH in PN5tzsvxSBd2iUg:
			if kD0FgO3GoQv6xH.count(s5WMHyQN4mpie(u"ࠫ࠳࠭༿"))==XW57OCeGnFTLQbaqdrD9zM: XHDxRIfJq8ohTPpnA6jOd.append(kD0FgO3GoQv6xH)
	return XHDxRIfJq8ohTPpnA6jOd
def T6TLaoxJnD0RlOZhiXGk7U1y3SK2(*aargs):
	f9fjQlHeduSC = Hr25gta6XcqO(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡱ࡫࠱ࡴࡷࡵࡸࡺࡵࡦࡶࡦࡶࡥ࠯ࡥࡲࡱ࠴ࡼ࠲࠰ࡁࡵࡩࡶࡻࡥࡴࡶࡀࡨ࡮ࡹࡰ࡭ࡣࡼࡴࡷࡵࡸࡪࡧࡶࠪࡵࡸ࡯ࡹࡻࡷࡽࡵ࡫࠽ࡩࡶࡷࡴࠫࡺࡩ࡮ࡧࡲࡹࡹࡃ࠱࠱࠲࠳࠴ࠫࡹࡳ࡭࠿ࡼࡩࡸࠬ࡬ࡪ࡯࡬ࡸࡂ࠷࠰ࠧࡥࡲࡹࡳࡺࡲࡺ࠿ࡑࡐ࠱ࡈࡅ࠭ࡆࡈ࠰ࡋࡘࠬࡈࡄ࠯ࡘࡗ࠭ཀ")
	FTn5LvDKXx6zphHqPUA3lZ0c2OaNES = AAbvaXV2DQzfNHdm4U3tT(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡳࡣࡺ࠲࡬࡯ࡴࡩࡷࡥࡹࡸ࡫ࡲࡤࡱࡱࡸࡪࡴࡴ࠯ࡥࡲࡱ࠴ࡸ࡯ࡰࡵࡷࡩࡷࡱࡩࡥ࠱ࡲࡴࡪࡴࡰࡳࡱࡻࡽࡱ࡯ࡳࡵ࠱ࡰࡥ࡮ࡴ࠯ࡉࡖࡗࡔࡘ࠴ࡴࡹࡶࠪཁ")
	r26DcXpZMWmehPoKSk8lLy03xYf = XMGbIjCUc4iRl(FTn5LvDKXx6zphHqPUA3lZ0c2OaNES)
	XHDxRIfJq8ohTPpnA6jOd = XMGbIjCUc4iRl(f9fjQlHeduSC)
	zRVyIYt2qkFm3TDXpaE = r26DcXpZMWmehPoKSk8lLy03xYf+XHDxRIfJq8ohTPpnA6jOd
	Clc8sIj97ZrThF(wVhZ6bfkpSre95EFu,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+sIzDXlTHYUC5L3xZGnr(u"ࠧࠡࠢࠣࡋࡴࡺࠠࡱࡴࡲࡼ࡮࡫ࡳࠡ࡮࡬ࡷࡹࠦࠠࠡ࠳ࡶࡸ࠰࠸࡮ࡥ࠼ࠣ࡟ࠥ࠭ག")+str(len(r26DcXpZMWmehPoKSk8lLy03xYf))+vU6DxuzPwMpg(u"ࠨ࠭ࠪགྷ")+str(len(XHDxRIfJq8ohTPpnA6jOd))+CsDcLqQUVK4YBvHFW1(u"ࠩࠣࡡࠬང"))
	kD0FgO3GoQv6xH = OdiZIyCfDUsW3JBGR2VAb.getSetting(FgXzMs0YSDt(u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡲࡡࡴࡶࠪཅ"))
	ND4YsIrucC = coFM7huzDdQ2()
	OdiZIyCfDUsW3JBGR2VAb.setSetting(SnhLjmfeJC(u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴࡬ࡢࡵࡷࠫཆ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	if kD0FgO3GoQv6xH or zRVyIYt2qkFm3TDXpaE:
		SXIxbZBW2zHeAV,TqNMvyzBUxolbKhdcRku2L74F8e = D2D96X5NGamBhrFwvL8VEbqiSfZIl,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠳࠳Ꮗ")
		ojey56LfbSxkJEUTsawNA = len(zRVyIYt2qkFm3TDXpaE)
		yjkI08CqfLbtZ1PoxnTvDucKW = TqNMvyzBUxolbKhdcRku2L74F8e
		if ojey56LfbSxkJEUTsawNA>yjkI08CqfLbtZ1PoxnTvDucKW: AVbgG1r3z7shPaTloLvJyXY = yjkI08CqfLbtZ1PoxnTvDucKW
		else: AVbgG1r3z7shPaTloLvJyXY = ojey56LfbSxkJEUTsawNA
		iZaJD7r6je4fculBktgT5EzX = yiTBYwps2mCrb4jGPux0cIJ.sample(zRVyIYt2qkFm3TDXpaE,AVbgG1r3z7shPaTloLvJyXY)
		if kD0FgO3GoQv6xH: iZaJD7r6je4fculBktgT5EzX = [kD0FgO3GoQv6xH]+iZaJD7r6je4fculBktgT5EzX
		t0yk8os9q7Jj3 = Ui7X2Awte6o8J9QRV4kdsPmb(LhFAGlQ19zr,LhFAGlQ19zr)
		TYfRSPL2HA3GuXIbgjyzBN69Wms = uUqrNPcXKBoQ0slv.time()
		while uUqrNPcXKBoQ0slv.time()-TYfRSPL2HA3GuXIbgjyzBN69Wms<=TqNMvyzBUxolbKhdcRku2L74F8e and not t0yk8os9q7Jj3.finishedLIST:
			if SXIxbZBW2zHeAV<AVbgG1r3z7shPaTloLvJyXY:
				kD0FgO3GoQv6xH = iZaJD7r6je4fculBktgT5EzX[SXIxbZBW2zHeAV]
				t0yk8os9q7Jj3.hN0H7wlzTkjUr(SXIxbZBW2zHeAV,wFMo6RkqpIhBGOvnKiYQmf,kD0FgO3GoQv6xH,*aargs)
			uUqrNPcXKBoQ0slv.sleep(sIzDXlTHYUC5L3xZGnr(u"࠳࠲࠼࠻Ꮘ"))
			SXIxbZBW2zHeAV += BkM54Kr7Qbqn
			Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+wdftVMyzF17cYETHu(u"ࠬࠦࠠࠡࡖࡵࡽ࡮ࡴࡧ࠻ࠢࠣࠤࡕࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧཇ")+kD0FgO3GoQv6xH+SnhLjmfeJC(u"࠭ࠠ࡞ࠩ཈"))
		finishedLIST = t0yk8os9q7Jj3.finishedLIST
		if finishedLIST:
			resultsDICT = t0yk8os9q7Jj3.resultsDICT
			R9PYKuaB0fDib65LzS = finishedLIST[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			ND4YsIrucC = resultsDICT[R9PYKuaB0fDib65LzS]
			kD0FgO3GoQv6xH = iZaJD7r6je4fculBktgT5EzX[int(R9PYKuaB0fDib65LzS)]
			OdiZIyCfDUsW3JBGR2VAb.setSetting(oRJAfwD957WkUyBM1Ehu8m(u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺࠧཉ"),kD0FgO3GoQv6xH)
			if R9PYKuaB0fDib65LzS!=D2D96X5NGamBhrFwvL8VEbqiSfZIl: Clc8sIj97ZrThF(wVhZ6bfkpSre95EFu,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+sIzDXlTHYUC5L3xZGnr(u"ࠨࠢࠣࠤࡘࡻࡣࡤࡧࡶࡷ࠿ࠦࠠࠡࡒࡵࡳࡽࡿ࠺ࠡ࡝ࠣࠫཊ")+kD0FgO3GoQv6xH+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠩࠣࡡࠬཋ"))
			else: Clc8sIj97ZrThF(wVhZ6bfkpSre95EFu,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+CsDcLqQUVK4YBvHFW1(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺ࠡࠢࠣࡗࡦࡼࡥࡥࠢࡳࡶࡴࡾࡹ࠻ࠢ࡞ࠤࠬཌ")+kD0FgO3GoQv6xH+ssynAg0zhSkoCpOMDV9(u"ࠫࠥࡣࠧཌྷ"))
	return ND4YsIrucC
def VvNhnQ7H0lqzc(MmQWjxS8uFLeJvT2c7w,DcM0yofjWm3SzQC4BNiE85bgkF2,zU6i9IV2OHt5ydblFEk=EsCplGc5N4mBuYW0RVQt6b):
	jMbz5AJR2IkYCfVQpat8UT1HXl = MmQWjxS8uFLeJvT2c7w.create_connection
	def IBARQPmrqKl(j5qQTYSpkyotVwP0iHUc2mDurE1ax,*aargs,**kkwargs):
		DDbf73rFVszUJBeWHuQ,UgWO9XDKlE7MVbw = j5qQTYSpkyotVwP0iHUc2mDurE1ax
		ip = xuEgXlQW2PYy1MC7dAq3zIn69sKVN(DDbf73rFVszUJBeWHuQ,DcM0yofjWm3SzQC4BNiE85bgkF2)
		if ip: DDbf73rFVszUJBeWHuQ = ip[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		elif zU6i9IV2OHt5ydblFEk:
			if DcM0yofjWm3SzQC4BNiE85bgkF2 in I4t9qonjrm.DNS_SERVERS: I4t9qonjrm.DNS_SERVERS.remove(DcM0yofjWm3SzQC4BNiE85bgkF2)
			if I4t9qonjrm.DNS_SERVERS:
				rQKHjoL4wOpYt9Sd7cFRkI1e = I4t9qonjrm.DNS_SERVERS[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
				ip = xuEgXlQW2PYy1MC7dAq3zIn69sKVN(DDbf73rFVszUJBeWHuQ,rQKHjoL4wOpYt9Sd7cFRkI1e)
				if ip: DDbf73rFVszUJBeWHuQ = ip[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		if ip: I4t9qonjrm.dns_succeeded_urls.append(DDbf73rFVszUJBeWHuQ)
		j5qQTYSpkyotVwP0iHUc2mDurE1ax = (DDbf73rFVszUJBeWHuQ,UgWO9XDKlE7MVbw)
		return jMbz5AJR2IkYCfVQpat8UT1HXl(j5qQTYSpkyotVwP0iHUc2mDurE1ax,*aargs,**kkwargs)
	MmQWjxS8uFLeJvT2c7w.create_connection = IBARQPmrqKl
	return jMbz5AJR2IkYCfVQpat8UT1HXl
def TXbClBJYH0MPIWhj3tL7SZQVxe(zzekZcWL1sBgnoxN8f3vdQ0r):
	kM9Z5FS6X8Osw3vVigNWpQL0d,kuY8psoFrl4QSaXg9Jt0Gd2 = zzekZcWL1sBgnoxN8f3vdQ0r.split(oRJAfwD957WkUyBM1Ehu8m(u"ࠬ࠵ࠧཎ"))[teaC5j4HuGDqpwcmUzJ],FmYoGejTnwKME7d9zPc(u"࠼࠵Ꮙ")
	if KfHAW8VGbrxi(u"࠭࠺ࠨཏ") in kM9Z5FS6X8Osw3vVigNWpQL0d: kM9Z5FS6X8Osw3vVigNWpQL0d,kuY8psoFrl4QSaXg9Jt0Gd2 = kM9Z5FS6X8Osw3vVigNWpQL0d.split(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠧ࠻ࠩཐ"))
	cUpvNXTqu3w0j214rd6B = o1INZ3ViQqS0Uw5z6kMjbv(u"ࠨ࠱ࠪད")+uulNDCPyef78(u"ࠩ࠲ࠫདྷ").join(zzekZcWL1sBgnoxN8f3vdQ0r.split(O3OVuapf0YFjbm5oUQDg(u"ࠪ࠳ࠬན"))[oRJAfwD957WkUyBM1Ehu8m(u"࠸Ꮚ"):])
	Bc7G3ur2Tw5QK1fPSkyJ = oRJAfwD957WkUyBM1Ehu8m(u"ࠫࡌࡋࡔࠡࠩཔ")+cUpvNXTqu3w0j214rd6B+sJw9QWiq1Kr0xfeVRI(u"ࠬࠦࡈࡕࡖࡓ࠳࠶࠴࠱࡝ࡴ࡟ࡲࠬཕ")
	Bc7G3ur2Tw5QK1fPSkyJ += Hr25gta6XcqO(u"࠭ࡈࡰࡵࡷ࠾ࠥ࠭བ")+kM9Z5FS6X8Osw3vVigNWpQL0d+I18uSKaWhgTBeYUPD4sr(u"ࠧ࡝ࡴ࡟ࡲࠬབྷ")
	Bc7G3ur2Tw5QK1fPSkyJ += O3OVuapf0YFjbm5oUQDg(u"ࠨ࡞ࡵࡠࡳ࠭མ")
	from socket import socket as AA872c56aHvzhydmTfCSw0tlDxoZeK,AF_INET as pVB317Nv06HPyi8OFRkJElYo,SOCK_STREAM as SeQkx1wz6Ty7nAv
	try:
		WWMSVaATty08wr4Dx7s = AA872c56aHvzhydmTfCSw0tlDxoZeK(pVB317Nv06HPyi8OFRkJElYo,SeQkx1wz6Ty7nAv)
		WWMSVaATty08wr4Dx7s.connect((kM9Z5FS6X8Osw3vVigNWpQL0d,kuY8psoFrl4QSaXg9Jt0Gd2))
		WWMSVaATty08wr4Dx7s.send(Bc7G3ur2Tw5QK1fPSkyJ.encode(Tk9eH2qw6Brsuhj))
		BaLD5m6U8bCVytsHSxIQKiYO = WWMSVaATty08wr4Dx7s.recv(ggjO5CrKVRPITaesWkxD(u"࠴࠱࠻࠹Ꮜ")*oRJAfwD957WkUyBM1Ehu8m(u"࠷࠰࠳࠶Ꮛ"))
		Vpnd4wgPqAO1j6z8N = repr(BaLD5m6U8bCVytsHSxIQKiYO)
	except: Vpnd4wgPqAO1j6z8N = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	return Vpnd4wgPqAO1j6z8N
def VbHeOuU1ilzSp2ZRXwBD(XgiRnyU12TL8xocCIPK5DE,ZJqDh4ByGPQn13tlzMOTLCNdcugx):
	if FmYoGejTnwKME7d9zPc(u"ࠩ࠱ࠫཙ") not in XgiRnyU12TL8xocCIPK5DE: return XgiRnyU12TL8xocCIPK5DE
	XgiRnyU12TL8xocCIPK5DE = XgiRnyU12TL8xocCIPK5DE+ssynAg0zhSkoCpOMDV9(u"ࠪ࠳ࠬཚ")
	IIKENnVXf1uU,Xd8u924Rmk6p = XgiRnyU12TL8xocCIPK5DE.split(ssynAg0zhSkoCpOMDV9(u"ࠫ࠳࠭ཛ"),Hr25gta6XcqO(u"࠲Ꮝ"))
	HHDmWvqnXgC1RUTEb,d5zQ7asUxg1 = Xd8u924Rmk6p.split(AAbvaXV2DQzfNHdm4U3tT(u"ࠬ࠵ࠧཛྷ"),KfHAW8VGbrxi(u"࠳Ꮞ"))
	i5AjLYP2FMsJZDSwhQzEqmy = IIKENnVXf1uU+aOQTKXFL54Nl60Zhp3MbE(u"࠭࠮ࠨཝ")+HHDmWvqnXgC1RUTEb
	if ZJqDh4ByGPQn13tlzMOTLCNdcugx in [wdftVMyzF17cYETHu(u"ࠧࡩࡱࡶࡸࠬཞ"),CsDcLqQUVK4YBvHFW1(u"ࠨࡰࡤࡱࡪ࠭ཟ")] and o1INZ3ViQqS0Uw5z6kMjbv(u"ࠩ࠲ࠫའ") in i5AjLYP2FMsJZDSwhQzEqmy: i5AjLYP2FMsJZDSwhQzEqmy = i5AjLYP2FMsJZDSwhQzEqmy.rsplit(aOQTKXFL54Nl60Zhp3MbE(u"ࠪ࠳ࠬཡ"),o1INZ3ViQqS0Uw5z6kMjbv(u"࠴Ꮟ"))[BkM54Kr7Qbqn]
	if ZJqDh4ByGPQn13tlzMOTLCNdcugx==EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠫࡳࡧ࡭ࡦࠩར") and Hr25gta6XcqO(u"ࠬ࠴ࠧལ") in i5AjLYP2FMsJZDSwhQzEqmy:
		E86r9BkjnbIFeGZ = i5AjLYP2FMsJZDSwhQzEqmy.split(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠭࠮ࠨཤ"))
		E54tJlkzYXay6UjCD7Tu2sPofNc83 = len(E86r9BkjnbIFeGZ)
		if FgXzMs0YSDt(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬཥ") in i5AjLYP2FMsJZDSwhQzEqmy: E86r9BkjnbIFeGZ = Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭ས")
		elif E54tJlkzYXay6UjCD7Tu2sPofNc83<=teaC5j4HuGDqpwcmUzJ: E86r9BkjnbIFeGZ = E86r9BkjnbIFeGZ[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		elif E54tJlkzYXay6UjCD7Tu2sPofNc83>=XW57OCeGnFTLQbaqdrD9zM: E86r9BkjnbIFeGZ = E86r9BkjnbIFeGZ[BkM54Kr7Qbqn]
		if len(E86r9BkjnbIFeGZ)>BkM54Kr7Qbqn: i5AjLYP2FMsJZDSwhQzEqmy = E86r9BkjnbIFeGZ
	return i5AjLYP2FMsJZDSwhQzEqmy
def bL7jBNOF9MK(HH6IAdWnyvmf3QTMN):
	W7KRFfLecIvlq = repr(HH6IAdWnyvmf3QTMN.encode(Tk9eH2qw6Brsuhj)).replace(AAbvaXV2DQzfNHdm4U3tT(u"ࠤࠪࠦཧ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	return W7KRFfLecIvlq
def RRS3fV9tw8o5WGdQanhEH2(NgPAlwYrve3qzy48GKTQCDdo7X):
	sygUhSHiNG6qYefTu = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if gZlSEJaXO9F461AL3sR7rWNpqf: NgPAlwYrve3qzy48GKTQCDdo7X = NgPAlwYrve3qzy48GKTQCDdo7X.decode(Tk9eH2qw6Brsuhj)
	from unicodedata import decomposition as VfeG4QI1uNXFMDpjrWgn
	for b7gzsRIJuP in NgPAlwYrve3qzy48GKTQCDdo7X:
		if   b7gzsRIJuP==vU6DxuzPwMpg(u"ࡸࠫว࠭ཨ"): hZYPHLMtp0UOAcs1RVra9WyND = V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠫࡡࡢࡵ࠱࠸࠵࠶ࠬཀྵ")
		elif b7gzsRIJuP==CsDcLqQUVK4YBvHFW1(u"ࡺ࠭รࠨཪ"): hZYPHLMtp0UOAcs1RVra9WyND = Gcw2nelTR864XCVruO3mAFqI5a(u"࠭࡜࡝ࡷ࠳࠺࠷࠹ࠧཫ")
		elif b7gzsRIJuP==V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࡵࠨฦࠪཬ"): hZYPHLMtp0UOAcs1RVra9WyND = I18uSKaWhgTBeYUPD4sr(u"ࠨ࡞࡟ࡹ࠵࠼࠲࠵ࠩ཭")
		elif b7gzsRIJuP==KfHAW8VGbrxi(u"ࡷࠪษࠬ཮"): hZYPHLMtp0UOAcs1RVra9WyND = PlpyFa9QMKXxOD1cvHzmI(u"ࠪࡠࡡࡻ࠰࠷࠴࠸ࠫ཯")
		elif b7gzsRIJuP==OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࡹࠬฬࠧ཰"): hZYPHLMtp0UOAcs1RVra9WyND = ssynAg0zhSkoCpOMDV9(u"ࠬࡢ࡜ࡶ࠲࠹࠶࠻ཱ࠭")
		else:
			l07z9TCnjaedRktfBKgOh1UuQ = VfeG4QI1uNXFMDpjrWgn(b7gzsRIJuP)
			if ksJdoFWhxTz8Y2N7bOZE in l07z9TCnjaedRktfBKgOh1UuQ: hZYPHLMtp0UOAcs1RVra9WyND = wdftVMyzF17cYETHu(u"࠭࡜࡝ࡷིࠪ")+l07z9TCnjaedRktfBKgOh1UuQ.split(ksJdoFWhxTz8Y2N7bOZE,BkM54Kr7Qbqn)[BkM54Kr7Qbqn]
			else:
				hZYPHLMtp0UOAcs1RVra9WyND = LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠧ࠱࠲࠳࠴ཱིࠬ")+hex(ord(b7gzsRIJuP)).replace(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠨ࠲ࡻུࠫ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
				hZYPHLMtp0UOAcs1RVra9WyND = aOQTKXFL54Nl60Zhp3MbE(u"ࠩ࡟ࡠࡺཱུ࠭")+hZYPHLMtp0UOAcs1RVra9WyND[-vD4Fh6ictZ7wME:]
		sygUhSHiNG6qYefTu += hZYPHLMtp0UOAcs1RVra9WyND
	sygUhSHiNG6qYefTu = sygUhSHiNG6qYefTu.replace(I18uSKaWhgTBeYUPD4sr(u"ࠪࡠࡡࡻ࠰࠷ࡅࡆࠫྲྀ"),FgXzMs0YSDt(u"ࠫࡡࡢࡵ࠱࠸࠷࠽ࠬཷ"))
	if gZlSEJaXO9F461AL3sR7rWNpqf: sygUhSHiNG6qYefTu = sygUhSHiNG6qYefTu.decode(QjAINyUC7MDRq5d8e4vl9(u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭ླྀ")).encode(Tk9eH2qw6Brsuhj)
	else: sygUhSHiNG6qYefTu = sygUhSHiNG6qYefTu.encode(Tk9eH2qw6Brsuhj).decode(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧཹ"))
	return sygUhSHiNG6qYefTu
def GFYl1tsoOkHC0Ajeur8JQiMx(header=oRJAfwD957WkUyBM1Ehu8m(u"ࠧๅ๊ะอࠥอไๆใสฮ๏ำེࠧ"),BgDNz7JOZr69oC5wvbGFl4anypKquA=fy8iFgEkrO12NR9TWBI35sjY6qHvV,pzJ4wmaNFRPAlG=LhFAGlQ19zr,source=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	YQDmGRx3CWc2HX9V0wa4O = zRtIL7jDZHGJ2XWQc8OkgPCborpK0(header,BgDNz7JOZr69oC5wvbGFl4anypKquA,type=nn19vN7ifGslVJODZWzCSudBK8.INPUT_ALPHANUM)
	YQDmGRx3CWc2HX9V0wa4O = YQDmGRx3CWc2HX9V0wa4O.strip(ksJdoFWhxTz8Y2N7bOZE).replace(zz5wETpjWKMNb6JiLRndGhV9,ksJdoFWhxTz8Y2N7bOZE).replace(yU7COAbsNJ916v5L0oew2n,ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE)
	if not YQDmGRx3CWc2HX9V0wa4O and not pzJ4wmaNFRPAlG:
		Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,uulNDCPyef78(u"ࠨ࠰࡟ࡸࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡩࡡ࡯ࡥࡨࡰࡪࡪ࠺ཻࠡࠢࠣࠦࠬ")+YQDmGRx3CWc2HX9V0wa4O+Hr25gta6XcqO(u"ོࠩࠥࠫ"))
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ัཽ࠭"),I18uSKaWhgTBeYUPD4sr(u"ࠫฯ๋ࠠฦๆ฽หฦࠦวๅวาาฬ๊ࠧཾ"))
		return fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if YQDmGRx3CWc2HX9V0wa4O not in [fy8iFgEkrO12NR9TWBI35sjY6qHvV,ksJdoFWhxTz8Y2N7bOZE]:
		YQDmGRx3CWc2HX9V0wa4O = YQDmGRx3CWc2HX9V0wa4O.strip(ksJdoFWhxTz8Y2N7bOZE)
		YQDmGRx3CWc2HX9V0wa4O = RRS3fV9tw8o5WGdQanhEH2(YQDmGRx3CWc2HX9V0wa4O)
	if source!=s5WMHyQN4mpie(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙ࠧཿ") and SYJvigbI3fts(oRJAfwD957WkUyBM1Ehu8m(u"࠭ࡋࡆ࡛ࡅࡓࡆࡘࡄࠨྀ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,[YQDmGRx3CWc2HX9V0wa4O],LhFAGlQ19zr):
		Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,EE1jeHnIoad(u"ࠧ࠯࡞ࡷࡏࡪࡿࡢࡰࡣࡵࡨࠥ࡫࡮ࡵࡴࡼࠤࡧࡲ࡯ࡤ࡭ࡨࡨ࠿ࠦࠠࠡࠤཱྀࠪ")+YQDmGRx3CWc2HX9V0wa4O+KfHAW8VGbrxi(u"ࠨࠤࠪྂ"))
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬྃ"),FmYoGejTnwKME7d9zPc(u"ࠪห๋ะࠠไฬหฮ้ࠥไๆหࠣวํࠦัใ็่ࠣ์ูࠦๅษๅอࠥฮรโๆส้๊ࠥไไสสีࠥ็โุࠢ࠱࠲ࠥ๎็ัษࠣห้ฮั็ษ่ะ๊ࠥวࠡ์ึ้าࠦศศีอาิอๅ้ࠡๆิฬࠦใๅ็สฮ྄ࠬ"))
		return fy8iFgEkrO12NR9TWBI35sjY6qHvV
	Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠫ࠳ࡢࡴࡌࡧࡼࡦࡴࡧࡲࡥࠢࡨࡲࡹࡸࡹࠡࡣ࡯ࡰࡴࡽࡥࡥ࠼ࠣࠤࠥࠨࠧ྅")+YQDmGRx3CWc2HX9V0wa4O+sIzDXlTHYUC5L3xZGnr(u"ࠬࠨࠧ྆"))
	return YQDmGRx3CWc2HX9V0wa4O
def kDKwn73e02jNdRLG8U4HxTgpVQqI(BfWYUAnyg6eONLjiuE,YLKFRH6sSIrznXBg,naBFTDfp6lmKjeOywg87IAcb={}):
	zzekZcWL1sBgnoxN8f3vdQ0r,jnyZou1dbzLJtfRUSmBM2l,fVyzUAKh6sbjE,LL8DeS7jy4snIK3wW0 = YLKFRH6sSIrznXBg,{},{},fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if CsDcLqQUVK4YBvHFW1(u"࠭ࡼࠨ྇") in YLKFRH6sSIrznXBg: zzekZcWL1sBgnoxN8f3vdQ0r,jnyZou1dbzLJtfRUSmBM2l = lNyxXsMAcYHBUDh4dJbfTWR(YLKFRH6sSIrznXBg,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠧࡽࠩྈ"))
	umpz32jb0IKaQZ6BTOCGg = list(set(list(naBFTDfp6lmKjeOywg87IAcb.keys())+list(jnyZou1dbzLJtfRUSmBM2l.keys())))
	for tLsNIYkDoSAcp6wrq in umpz32jb0IKaQZ6BTOCGg:
		if tLsNIYkDoSAcp6wrq in list(jnyZou1dbzLJtfRUSmBM2l.keys()): fVyzUAKh6sbjE[tLsNIYkDoSAcp6wrq] = jnyZou1dbzLJtfRUSmBM2l[tLsNIYkDoSAcp6wrq]
		else: fVyzUAKh6sbjE[tLsNIYkDoSAcp6wrq] = naBFTDfp6lmKjeOywg87IAcb[tLsNIYkDoSAcp6wrq]
	if I18uSKaWhgTBeYUPD4sr(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬྉ") not in umpz32jb0IKaQZ6BTOCGg: fVyzUAKh6sbjE[sIzDXlTHYUC5L3xZGnr(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ྊ")] = j4lUV5BzHDI6EN()
	if uulNDCPyef78(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫྋ") not in umpz32jb0IKaQZ6BTOCGg: fVyzUAKh6sbjE[ssynAg0zhSkoCpOMDV9(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬྌ")] = VbHeOuU1ilzSp2ZRXwBD(zzekZcWL1sBgnoxN8f3vdQ0r,SnhLjmfeJC(u"ࠬࡻࡲ࡭ࠩྍ"))
	if uulNDCPyef78(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡌࡢࡰࡪࡹࡦ࡭ࡥࠨྎ") not in umpz32jb0IKaQZ6BTOCGg: fVyzUAKh6sbjE[N6NGJ4vpmidqMCh7yo(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡍࡣࡱ࡫ࡺࡧࡧࡦࠩྏ")] = sJw9QWiq1Kr0xfeVRI(u"ࠨࡧࡱ࠱࡚࡙ࠬࡦࡰ࠾ࡵࡂ࠶࠮࠺ࠩྐ")
	for tLsNIYkDoSAcp6wrq in list(fVyzUAKh6sbjE.keys()): LL8DeS7jy4snIK3wW0 += aOQTKXFL54Nl60Zhp3MbE(u"ࠩࠩࠫྑ")+tLsNIYkDoSAcp6wrq+o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪࡁࠬྒ")+fVyzUAKh6sbjE[tLsNIYkDoSAcp6wrq]
	if LL8DeS7jy4snIK3wW0: LL8DeS7jy4snIK3wW0 = PlpyFa9QMKXxOD1cvHzmI(u"ࠫࢁ࠭ྒྷ")+LL8DeS7jy4snIK3wW0[BkM54Kr7Qbqn:]
	ND4YsIrucC = TBPcjsyOYoM82pm(D1KfvmcCjGYbgSoyX,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬࡍࡅࡕࠩྔ"),zzekZcWL1sBgnoxN8f3vdQ0r,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fVyzUAKh6sbjE,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,aOQTKXFL54Nl60Zhp3MbE(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡆ࡚ࡗࡖࡆࡉࡔࡠࡏ࠶࡙࠽࠳࠱ࡴࡶࠪྕ"),LhFAGlQ19zr,LhFAGlQ19zr)
	Vpnd4wgPqAO1j6z8N = ND4YsIrucC.content
	if EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧࡔࡖࡕࡉࡆࡓ࠭ࡊࡐࡉࠫྖ") not in Vpnd4wgPqAO1j6z8N: return [uulNDCPyef78(u"ࠨ࠯࠴ࠫྗ")],[zzekZcWL1sBgnoxN8f3vdQ0r+LL8DeS7jy4snIK3wW0]
	if KfHAW8VGbrxi(u"ࠩࡗ࡝ࡕࡋ࠽ࡂࡗࡇࡍࡔ࠭྘") in Vpnd4wgPqAO1j6z8N: return [ggjO5CrKVRPITaesWkxD(u"ࠪ࠱࠶࠭ྙ")],[zzekZcWL1sBgnoxN8f3vdQ0r+LL8DeS7jy4snIK3wW0]
	if AAbvaXV2DQzfNHdm4U3tT(u"࡙ࠫ࡟ࡐࡆ࠿࡙ࡍࡉࡋࡏࠨྚ") in Vpnd4wgPqAO1j6z8N: return [EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬ࠳࠱ࠨྛ")],[zzekZcWL1sBgnoxN8f3vdQ0r+LL8DeS7jy4snIK3wW0]
	WFlpmsYGKNy,XoSyx7p6dqZ1CF8,ZxaBFPmMRsW3ce70f6qD,RKLeF0HOS9D = [],[],[],[]
	KkS426yjbo8xFvBMVig5YcLCH = EcQxOa3RJm86WjTKA.findall(I18uSKaWhgTBeYUPD4sr(u"࠭ࠣࡆ࡚ࡗ࠱࡝࠳ࡓࡕࡔࡈࡅࡒ࠳ࡉࡏࡈ࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱ࠧྜ"),Vpnd4wgPqAO1j6z8N+C0qrknitpM4Z,EcQxOa3RJm86WjTKA.DOTALL)
	if not KkS426yjbo8xFvBMVig5YcLCH: return [PlpyFa9QMKXxOD1cvHzmI(u"ࠧ࠮࠳ࠪྜྷ")],[zzekZcWL1sBgnoxN8f3vdQ0r+LL8DeS7jy4snIK3wW0]
	for cjUwESlPvXV3btCHfWzFqn7o5a,XgiRnyU12TL8xocCIPK5DE in KkS426yjbo8xFvBMVig5YcLCH:
		J3lqTO6Y5vjw0spXSAafntKIu1ED,gn2DUcWhvjpC4ZR0lr3bJO61GPVX,OOnVxtP0TNWsci6HrEGqBm9boKF7g = {},-EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠵Ꮠ"),-EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠵Ꮠ")
		zYubnrZ9h8q4QEaIkp1 = fy8iFgEkrO12NR9TWBI35sjY6qHvV
		B602U3dLlJYcm = cjUwESlPvXV3btCHfWzFqn7o5a.split(QjAINyUC7MDRq5d8e4vl9(u"ࠨ࠮ࠪྞ"))
		for Uuqa3wD8CR1G6 in B602U3dLlJYcm:
			if wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠩࡀࠫྟ") in Uuqa3wD8CR1G6:
				tLsNIYkDoSAcp6wrq,iwCJYxc0mrqTLhkRfd = Uuqa3wD8CR1G6.split(AAbvaXV2DQzfNHdm4U3tT(u"ࠪࡁࠬྠ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠶Ꮡ"))
				J3lqTO6Y5vjw0spXSAafntKIu1ED[tLsNIYkDoSAcp6wrq.lower()] = iwCJYxc0mrqTLhkRfd
		if KfHAW8VGbrxi(u"ࠫࡦࡼࡥࡳࡣࡪࡩ࠲ࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨࠨྡ") in cjUwESlPvXV3btCHfWzFqn7o5a.lower():
			gn2DUcWhvjpC4ZR0lr3bJO61GPVX = int(J3lqTO6Y5vjw0spXSAafntKIu1ED[wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠬࡧࡶࡦࡴࡤ࡫ࡪ࠳ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩྡྷ")])//C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠷࠰࠳࠶Ꮢ")
			zYubnrZ9h8q4QEaIkp1 += str(gn2DUcWhvjpC4ZR0lr3bJO61GPVX)+SnhLjmfeJC(u"࠭࡫ࡣࡲࡶࠤࠥ࠭ྣ")
		elif N6NGJ4vpmidqMCh7yo(u"ࠧࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪྤ") in cjUwESlPvXV3btCHfWzFqn7o5a.lower():
			gn2DUcWhvjpC4ZR0lr3bJO61GPVX = int(J3lqTO6Y5vjw0spXSAafntKIu1ED[ggjO5CrKVRPITaesWkxD(u"ࠨࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫྥ")])//EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠱࠱࠴࠷Ꮣ")
			zYubnrZ9h8q4QEaIkp1 += str(gn2DUcWhvjpC4ZR0lr3bJO61GPVX)+AAbvaXV2DQzfNHdm4U3tT(u"ࠩ࡮ࡦࡵࡹࠠࠡࠩྦ")
		if O3OVuapf0YFjbm5oUQDg(u"ࠪࡶࡪࡹ࡯࡭ࡷࡷ࡭ࡴࡴࠧྦྷ") in cjUwESlPvXV3btCHfWzFqn7o5a.lower():
			OOnVxtP0TNWsci6HrEGqBm9boKF7g = int(J3lqTO6Y5vjw0spXSAafntKIu1ED[KfHAW8VGbrxi(u"ࠫࡷ࡫ࡳࡰ࡮ࡸࡸ࡮ࡵ࡮ࠨྨ")].split(SnhLjmfeJC(u"ࠬࡾࠧྩ"))[BkM54Kr7Qbqn])
			zYubnrZ9h8q4QEaIkp1 += str(OOnVxtP0TNWsci6HrEGqBm9boKF7g)+OOiSqkBcMPptI
		zYubnrZ9h8q4QEaIkp1 = zYubnrZ9h8q4QEaIkp1.strip(OOiSqkBcMPptI)
		if not zYubnrZ9h8q4QEaIkp1: zYubnrZ9h8q4QEaIkp1 = I18uSKaWhgTBeYUPD4sr(u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠧྪ")
		if not XgiRnyU12TL8xocCIPK5DE.startswith(O3OVuapf0YFjbm5oUQDg(u"ࠧࡩࡶࡷࡴࠬྫ")):
			if XgiRnyU12TL8xocCIPK5DE.startswith(aOQTKXFL54Nl60Zhp3MbE(u"ࠨ࠱࠲ࠫྫྷ")): XgiRnyU12TL8xocCIPK5DE = zzekZcWL1sBgnoxN8f3vdQ0r.split(QjAINyUC7MDRq5d8e4vl9(u"ࠩ࠽ࠫྭ"),BkM54Kr7Qbqn)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]+uulNDCPyef78(u"ࠪ࠾ࠬྮ")+XgiRnyU12TL8xocCIPK5DE
			elif XgiRnyU12TL8xocCIPK5DE.startswith(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠫ࠴࠭ྯ")): XgiRnyU12TL8xocCIPK5DE = VbHeOuU1ilzSp2ZRXwBD(zzekZcWL1sBgnoxN8f3vdQ0r,FmYoGejTnwKME7d9zPc(u"ࠬࡻࡲ࡭ࠩྰ"))+XgiRnyU12TL8xocCIPK5DE
			else: XgiRnyU12TL8xocCIPK5DE = zzekZcWL1sBgnoxN8f3vdQ0r.rsplit(aOQTKXFL54Nl60Zhp3MbE(u"࠭࠯ࠨྱ"),BkM54Kr7Qbqn)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]+o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧ࠰ࠩྲ")+XgiRnyU12TL8xocCIPK5DE
		if Hr25gta6XcqO(u"ࠨࡲࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠳ࡵࡳ࡫ࠪླ") in list(J3lqTO6Y5vjw0spXSAafntKIu1ED.keys()):
			R9b8gUvoB4wOfkTIjlEsZrM5LtinpS = J3lqTO6Y5vjw0spXSAafntKIu1ED[QjAINyUC7MDRq5d8e4vl9(u"ࠩࡳࡶࡴ࡭ࡲࡦࡵࡶ࡭ࡻ࡫࠭ࡶࡴ࡬ࠫྴ")]
			R9b8gUvoB4wOfkTIjlEsZrM5LtinpS = R9b8gUvoB4wOfkTIjlEsZrM5LtinpS.replace(jL5CrsRwebpyDVXUc1EQP(u"ࠪࠦࠬྵ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(ssynAg0zhSkoCpOMDV9(u"ࠦࠬࠨྶ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).split(I18uSKaWhgTBeYUPD4sr(u"ࠬࠩࠧྷ"),BkM54Kr7Qbqn)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			f5t4sb7BER = ml1bXR85BJyhPAVvQY(R9b8gUvoB4wOfkTIjlEsZrM5LtinpS)
			if f5t4sb7BER: D4DQ6k0oS39GKbZrthnsTB = zYubnrZ9h8q4QEaIkp1+OOiSqkBcMPptI+f5t4sb7BER
			else: D4DQ6k0oS39GKbZrthnsTB = zYubnrZ9h8q4QEaIkp1
			D4DQ6k0oS39GKbZrthnsTB = D4DQ6k0oS39GKbZrthnsTB+jL5CrsRwebpyDVXUc1EQP(u"࠭ࠠࠡࡒࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠭ྸ")
			D4DQ6k0oS39GKbZrthnsTB = D4DQ6k0oS39GKbZrthnsTB+OOiSqkBcMPptI+VbHeOuU1ilzSp2ZRXwBD(R9b8gUvoB4wOfkTIjlEsZrM5LtinpS,oRJAfwD957WkUyBM1Ehu8m(u"ࠧ࡯ࡣࡰࡩࠬྐྵ"))
			WFlpmsYGKNy.append(D4DQ6k0oS39GKbZrthnsTB)
			XoSyx7p6dqZ1CF8.append(R9b8gUvoB4wOfkTIjlEsZrM5LtinpS)
			ZxaBFPmMRsW3ce70f6qD.append(OOnVxtP0TNWsci6HrEGqBm9boKF7g)
			RKLeF0HOS9D.append(gn2DUcWhvjpC4ZR0lr3bJO61GPVX)
		XgiRnyU12TL8xocCIPK5DE = XgiRnyU12TL8xocCIPK5DE.split(ssynAg0zhSkoCpOMDV9(u"ࠨࠥࠪྺ"),BkM54Kr7Qbqn)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		f5t4sb7BER = ml1bXR85BJyhPAVvQY(XgiRnyU12TL8xocCIPK5DE)
		if f5t4sb7BER: zYubnrZ9h8q4QEaIkp1 = zYubnrZ9h8q4QEaIkp1+OOiSqkBcMPptI+f5t4sb7BER
		zYubnrZ9h8q4QEaIkp1 = zYubnrZ9h8q4QEaIkp1+OOiSqkBcMPptI+VbHeOuU1ilzSp2ZRXwBD(XgiRnyU12TL8xocCIPK5DE,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠩࡱࡥࡲ࡫ࠧྻ"))
		WFlpmsYGKNy.append(zYubnrZ9h8q4QEaIkp1)
		XoSyx7p6dqZ1CF8.append(XgiRnyU12TL8xocCIPK5DE)
		ZxaBFPmMRsW3ce70f6qD.append(OOnVxtP0TNWsci6HrEGqBm9boKF7g)
		RKLeF0HOS9D.append(gn2DUcWhvjpC4ZR0lr3bJO61GPVX)
	fCv8TGZdqry = list(zip(WFlpmsYGKNy,XoSyx7p6dqZ1CF8,ZxaBFPmMRsW3ce70f6qD,RKLeF0HOS9D))
	fCv8TGZdqry = sorted(fCv8TGZdqry, reverse=EsCplGc5N4mBuYW0RVQt6b, key=lambda key: key[XW57OCeGnFTLQbaqdrD9zM])
	WFlpmsYGKNy,XoSyx7p6dqZ1CF8,ZxaBFPmMRsW3ce70f6qD,RKLeF0HOS9D = list(zip(*fCv8TGZdqry))
	WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = list(WFlpmsYGKNy),list(XoSyx7p6dqZ1CF8)
	TCGZwKs43fSniQe6EqctNuW = []
	for XgiRnyU12TL8xocCIPK5DE in XoSyx7p6dqZ1CF8: TCGZwKs43fSniQe6EqctNuW.append(XgiRnyU12TL8xocCIPK5DE+LL8DeS7jy4snIK3wW0)
	qOXr0CTou75sSvjFUJl = list(zip(TCGZwKs43fSniQe6EqctNuW,[EE1jeHnIoad(u"ࠪࡨࡺࡳ࡭ࡺࠩྼ")]*len(TCGZwKs43fSniQe6EqctNuW),RKLeF0HOS9D))
	IodASrtD4CbVqjvTmf9 = ngpwf5MVySAe8caPsWmD6GlNuvJb(BfWYUAnyg6eONLjiuE,qOXr0CTou75sSvjFUJl)
	if IodASrtD4CbVqjvTmf9:
		bigdh7fpZYl4aT2keV,O4On5rLamD7q1zKBo6WfF3eEbS98,gn2DUcWhvjpC4ZR0lr3bJO61GPVX = IodASrtD4CbVqjvTmf9[s5WMHyQN4mpie(u"࠱Ꮤ")]
		index = TCGZwKs43fSniQe6EqctNuW.index(bigdh7fpZYl4aT2keV)
		title = WFlpmsYGKNy[index]
		WFlpmsYGKNy,TCGZwKs43fSniQe6EqctNuW = [title],[bigdh7fpZYl4aT2keV]
	return WFlpmsYGKNy,TCGZwKs43fSniQe6EqctNuW
def xuEgXlQW2PYy1MC7dAq3zIn69sKVN(DDbf73rFVszUJBeWHuQ,DcM0yofjWm3SzQC4BNiE85bgkF2=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if not DcM0yofjWm3SzQC4BNiE85bgkF2: DcM0yofjWm3SzQC4BNiE85bgkF2 = I4t9qonjrm.DNS_SERVERS[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	if DDbf73rFVszUJBeWHuQ.replace(Hr25gta6XcqO(u"ࠫ࠳࠭྽"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).isdigit(): return [DDbf73rFVszUJBeWHuQ]
	from struct import pack as BBXrmw59KEQCZcdtSN4IbvnOYW,unpack_from as VAaXtgfou3OH2JrvmT
	from socket import socket as AA872c56aHvzhydmTfCSw0tlDxoZeK,AF_INET as pVB317Nv06HPyi8OFRkJElYo,SOCK_DGRAM as SasAci4bYhGTtwPL5lIB7yzDJ8pk6
	try:
		OrSVED6yaZIxJ = BBXrmw59KEQCZcdtSN4IbvnOYW(EE1jeHnIoad(u"ࠧࡄࡈࠣ྾"), wdftVMyzF17cYETHu(u"࠳࠵࠴࠹࠿Ꮥ"))
		OrSVED6yaZIxJ += BBXrmw59KEQCZcdtSN4IbvnOYW(s5WMHyQN4mpie(u"ࠨ࠾ࡉࠤ྿"), ssynAg0zhSkoCpOMDV9(u"࠵࠹࠻Ꮦ"))
		OrSVED6yaZIxJ += BBXrmw59KEQCZcdtSN4IbvnOYW(sIzDXlTHYUC5L3xZGnr(u"ࠢ࠿ࡊࠥ࿀"), BkM54Kr7Qbqn)
		OrSVED6yaZIxJ += BBXrmw59KEQCZcdtSN4IbvnOYW(N6NGJ4vpmidqMCh7yo(u"ࠣࡀࡋࠦ࿁"), D2D96X5NGamBhrFwvL8VEbqiSfZIl)
		OrSVED6yaZIxJ += BBXrmw59KEQCZcdtSN4IbvnOYW(ssynAg0zhSkoCpOMDV9(u"ࠤࡁࡌࠧ࿂"), D2D96X5NGamBhrFwvL8VEbqiSfZIl)
		OrSVED6yaZIxJ += BBXrmw59KEQCZcdtSN4IbvnOYW(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠥࡂࡍࠨ࿃"), D2D96X5NGamBhrFwvL8VEbqiSfZIl)
		if jTDWgftK7NEmx0JAkOn2aRIvweq: d3XYnHKPvi0mzcS = DDbf73rFVszUJBeWHuQ.split(oRJAfwD957WkUyBM1Ehu8m(u"ࠫ࠳࠭࿄"))
		else: d3XYnHKPvi0mzcS = DDbf73rFVszUJBeWHuQ.decode(Tk9eH2qw6Brsuhj).split(SnhLjmfeJC(u"ࠬ࠴ࠧ࿅"))
		for MMKrRf1ceTabkOu0 in d3XYnHKPvi0mzcS:
			hK8O6JCilepk9Rw0z5VGFPQ = MMKrRf1ceTabkOu0.encode(Tk9eH2qw6Brsuhj)
			OrSVED6yaZIxJ += BBXrmw59KEQCZcdtSN4IbvnOYW(FgXzMs0YSDt(u"ࠨࡂ࿆ࠣ"), len(MMKrRf1ceTabkOu0))
			for rzov4aKjF6J8g in MMKrRf1ceTabkOu0:
				OrSVED6yaZIxJ += BBXrmw59KEQCZcdtSN4IbvnOYW(sJw9QWiq1Kr0xfeVRI(u"ࠢࡤࠤ࿇"), rzov4aKjF6J8g.encode(Tk9eH2qw6Brsuhj))
		OrSVED6yaZIxJ += BBXrmw59KEQCZcdtSN4IbvnOYW(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠣࡄࠥ࿈"), D2D96X5NGamBhrFwvL8VEbqiSfZIl)
		OrSVED6yaZIxJ += BBXrmw59KEQCZcdtSN4IbvnOYW(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠤࡁࡌࠧ࿉"), BkM54Kr7Qbqn)
		OrSVED6yaZIxJ += BBXrmw59KEQCZcdtSN4IbvnOYW(vU6DxuzPwMpg(u"ࠥࡂࡍࠨ࿊"), BkM54Kr7Qbqn)
		sflmcK9GUWTFbZNiSgLC8EyP7XYt6D = AA872c56aHvzhydmTfCSw0tlDxoZeK(pVB317Nv06HPyi8OFRkJElYo,SasAci4bYhGTtwPL5lIB7yzDJ8pk6)
		sflmcK9GUWTFbZNiSgLC8EyP7XYt6D.sendto(bytes(OrSVED6yaZIxJ),(DcM0yofjWm3SzQC4BNiE85bgkF2,SnhLjmfeJC(u"࠹࠸Ꮧ")))
		sflmcK9GUWTFbZNiSgLC8EyP7XYt6D.settimeout(o1INZ3ViQqS0Uw5z6kMjbv(u"࠻Ꮨ"))
		O6N8nhyYTD12KRApqkLzVi, oYT7Lzgib1mu5 = sflmcK9GUWTFbZNiSgLC8EyP7XYt6D.recvfrom(jL5CrsRwebpyDVXUc1EQP(u"࠷࠰࠳࠶Ꮩ"))
		sflmcK9GUWTFbZNiSgLC8EyP7XYt6D.close()
		x5xf9OjnqNE3kHBiYmPGd = VAaXtgfou3OH2JrvmT(QjAINyUC7MDRq5d8e4vl9(u"ࠦࡃࡎࡈࡉࡊࡋࡌࠧ࿋"), O6N8nhyYTD12KRApqkLzVi, D2D96X5NGamBhrFwvL8VEbqiSfZIl)
		pFq9wt21jOomx5TAng = x5xf9OjnqNE3kHBiYmPGd[XW57OCeGnFTLQbaqdrD9zM]
		tigMR8LvrSB3Iufn = len(DDbf73rFVszUJBeWHuQ)+AAbvaXV2DQzfNHdm4U3tT(u"࠱࠹Ꮪ")
		bb0r3L7XGeVihn = []
		for _w1CqHyuMD0aN6 in range(pFq9wt21jOomx5TAng):
			j6PLUvCEDJwtxIHhN5B87lqrTQY3 = tigMR8LvrSB3Iufn
			uAD3aCqL5w0Ro2f = BkM54Kr7Qbqn
			j7XRFUYhQtSNOWazx3cCVpBAEI = LhFAGlQ19zr
			while EsCplGc5N4mBuYW0RVQt6b:
				rzov4aKjF6J8g = VAaXtgfou3OH2JrvmT(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠧࡄࡂࠣ࿌"), O6N8nhyYTD12KRApqkLzVi, j6PLUvCEDJwtxIHhN5B87lqrTQY3)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
				if rzov4aKjF6J8g == D2D96X5NGamBhrFwvL8VEbqiSfZIl:
					j6PLUvCEDJwtxIHhN5B87lqrTQY3 += BkM54Kr7Qbqn
					break
				if rzov4aKjF6J8g >= jL5CrsRwebpyDVXUc1EQP(u"࠲࠻࠵Ꮫ"):
					xwiqcFEaUOrb2eN8IndkJ4CothW = VAaXtgfou3OH2JrvmT(sIzDXlTHYUC5L3xZGnr(u"ࠨ࠾ࡃࠤ࿍"), O6N8nhyYTD12KRApqkLzVi, j6PLUvCEDJwtxIHhN5B87lqrTQY3 + BkM54Kr7Qbqn)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
					j6PLUvCEDJwtxIHhN5B87lqrTQY3 = ((rzov4aKjF6J8g << FgXzMs0YSDt(u"࠺Ꮬ")) + xwiqcFEaUOrb2eN8IndkJ4CothW - 0xc000) - BkM54Kr7Qbqn
					j7XRFUYhQtSNOWazx3cCVpBAEI = EsCplGc5N4mBuYW0RVQt6b
				j6PLUvCEDJwtxIHhN5B87lqrTQY3 += BkM54Kr7Qbqn
				if j7XRFUYhQtSNOWazx3cCVpBAEI == LhFAGlQ19zr: uAD3aCqL5w0Ro2f += BkM54Kr7Qbqn
			if j7XRFUYhQtSNOWazx3cCVpBAEI == EsCplGc5N4mBuYW0RVQt6b: uAD3aCqL5w0Ro2f += BkM54Kr7Qbqn
			tigMR8LvrSB3Iufn = tigMR8LvrSB3Iufn + uAD3aCqL5w0Ro2f
			VOxbIvrCghRQNDf = VAaXtgfou3OH2JrvmT(vU6DxuzPwMpg(u"ࠢ࠿ࡊࡋࡍࡍࠨ࿎"), O6N8nhyYTD12KRApqkLzVi, tigMR8LvrSB3Iufn)
			tigMR8LvrSB3Iufn = tigMR8LvrSB3Iufn + wdftVMyzF17cYETHu(u"࠴࠴Ꮭ")
			Kf1gzL4ePHARawJvMiChybmxpsdk = VOxbIvrCghRQNDf[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			qskDKje7BSZXAc329uLCdTJw = VOxbIvrCghRQNDf[XW57OCeGnFTLQbaqdrD9zM]
			if Kf1gzL4ePHARawJvMiChybmxpsdk == BkM54Kr7Qbqn:
				gopZzuxsGU7NiAbBY2L1qEXV = VAaXtgfou3OH2JrvmT(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠣࡀࠥ࿏")+uulNDCPyef78(u"ࠤࡅࠦ࿐")*qskDKje7BSZXAc329uLCdTJw, O6N8nhyYTD12KRApqkLzVi, tigMR8LvrSB3Iufn)
				ip = fy8iFgEkrO12NR9TWBI35sjY6qHvV
				for rzov4aKjF6J8g in gopZzuxsGU7NiAbBY2L1qEXV: ip += str(rzov4aKjF6J8g) + V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪ࠲ࠬ࿑")
				ip = ip[D2D96X5NGamBhrFwvL8VEbqiSfZIl:-BkM54Kr7Qbqn]
				bb0r3L7XGeVihn.append(ip)
			if Kf1gzL4ePHARawJvMiChybmxpsdk in [BkM54Kr7Qbqn,teaC5j4HuGDqpwcmUzJ,sIzDXlTHYUC5L3xZGnr(u"࠻Ꮰ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠶Ꮱ"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠶࠻Ꮯ"),oRJAfwD957WkUyBM1Ehu8m(u"࠶࠽Ꮮ")]: tigMR8LvrSB3Iufn = tigMR8LvrSB3Iufn + qskDKje7BSZXAc329uLCdTJw
	except: bb0r3L7XGeVihn = []
	if not bb0r3L7XGeVihn: Clc8sIj97ZrThF(P3PazFblmtN,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+ggjO5CrKVRPITaesWkxD(u"ࠫࠥࠦࠠࡅࡐࡖࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡊࡲࡷࡹࡀࠠ࡜ࠢࠪ࿒")+DDbf73rFVszUJBeWHuQ+FgXzMs0YSDt(u"ࠬࠦ࡝ࠨ࿓"))
	return bb0r3L7XGeVihn
def SYJvigbI3fts(BfWYUAnyg6eONLjiuE,zzekZcWL1sBgnoxN8f3vdQ0r,uuigJsvIZQ3tprnhxG,showDialogs=EsCplGc5N4mBuYW0RVQt6b):
	if uuigJsvIZQ3tprnhxG:
		nLowR07fik9WOUKVHPxGYMrbuaFp1 = [V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠭ใษษิࠫ࿔"),vU6DxuzPwMpg(u"ࠧษษ็฾ࠬ࿕"),FmYoGejTnwKME7d9zPc(u"ࠨࡣࡧࡹࡱࡺࠧ࿖"),EE1jeHnIoad(u"ࠩࡻࡼࠬ࿗"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠪࡷࡪࡾࠧ࿘")]
		if BfWYUAnyg6eONLjiuE!=vU6DxuzPwMpg(u"ࠫࡇࡕࡋࡓࡃࠪ࿙"):
			nLowR07fik9WOUKVHPxGYMrbuaFp1 += [aOQTKXFL54Nl60Zhp3MbE(u"ࠬࡸ࠺ࠨ࿚"),KfHAW8VGbrxi(u"࠭ࡲ࠮ࠩ࿛"),Hr25gta6XcqO(u"ࠧ࠮࡯ࡤࠫ࿜")]
			nLowR07fik9WOUKVHPxGYMrbuaFp1 += [uulNDCPyef78(u"ࠨ࠼ࡵࠫ࿝"),FgXzMs0YSDt(u"ࠩ࠰ࡶࠬ࿞"),N6NGJ4vpmidqMCh7yo(u"ࠪࡱࡦ࠳ࠧ࿟")]
		for UU0LTHijNAh4SEyw6BO5sCY3Zo in uuigJsvIZQ3tprnhxG:
			if O3OVuapf0YFjbm5oUQDg(u"ࠫ࡬࡫ࡴ࠯ࡲ࡫ࡴࡄ࠭࿠") in UU0LTHijNAh4SEyw6BO5sCY3Zo: continue
			if wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠬำไใหࠪ࿡") in UU0LTHijNAh4SEyw6BO5sCY3Zo: continue
			UU0LTHijNAh4SEyw6BO5sCY3Zo = UU0LTHijNAh4SEyw6BO5sCY3Zo.lower()
			if gZlSEJaXO9F461AL3sR7rWNpqf: UU0LTHijNAh4SEyw6BO5sCY3Zo = UU0LTHijNAh4SEyw6BO5sCY3Zo.decode(Tk9eH2qw6Brsuhj).encode(Tk9eH2qw6Brsuhj)
			UU0LTHijNAh4SEyw6BO5sCY3Zo = UU0LTHijNAh4SEyw6BO5sCY3Zo.replace(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠭࠺ࠨ࿢"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			T4CzXDEOJNHB30FwdM5lmihP18ktgU = EcQxOa3RJm86WjTKA.findall(oRJAfwD957WkUyBM1Ehu8m(u"ࠧࠩ࠳࡞࠹࠲࠿࡝ࠬࡾ࠵࡟࠵࠳࠳࡞࠭ࠬࠫ࿣"),UU0LTHijNAh4SEyw6BO5sCY3Zo,EcQxOa3RJm86WjTKA.DOTALL)
			G5GYSyguR1EA24UVIXKs8fLtHzrq7B = LhFAGlQ19zr
			for YudBWJptx2jVFAISQDkr in T4CzXDEOJNHB30FwdM5lmihP18ktgU:
				if len(YudBWJptx2jVFAISQDkr)==teaC5j4HuGDqpwcmUzJ:
					G5GYSyguR1EA24UVIXKs8fLtHzrq7B = EsCplGc5N4mBuYW0RVQt6b
					break
			if OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠨࡰࡲࡸࠥࡸࡡࡵࡧࡧࠫ࿤") in UU0LTHijNAh4SEyw6BO5sCY3Zo: continue
			elif CsDcLqQUVK4YBvHFW1(u"ࠩࡸࡲࡷࡧࡴࡦࡦࠪ࿥") in UU0LTHijNAh4SEyw6BO5sCY3Zo: continue
			elif Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠪ฾๏ืࠠๆื้ๅࠬ࿦") in UU0LTHijNAh4SEyw6BO5sCY3Zo: continue
			elif AANCp8tEGTLriQgjB([vU6DxuzPwMpg(u"ࠫࡇ࡚ࡅࡹࡒ࡙࠵࠾࡙ࡒࡗࡐࡘ࡙ࡱ࡜ࡄࡗࡇ࡙ࡉ࡝࠭࿧")])[D2D96X5NGamBhrFwvL8VEbqiSfZIl]: continue
			elif UU0LTHijNAh4SEyw6BO5sCY3Zo in [Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠬࡸࠧ࿨")] or G5GYSyguR1EA24UVIXKs8fLtHzrq7B or any(value in UU0LTHijNAh4SEyw6BO5sCY3Zo for value in nLowR07fik9WOUKVHPxGYMrbuaFp1):
				Clc8sIj97ZrThF(P3PazFblmtN,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+Gcw2nelTR864XCVruO3mAFqI5a(u"࠭ࠠࠡࠢࡅࡰࡴࡩ࡫ࡦࡦࠣࡥࡩࡻ࡬ࡵࡵࠣࡺ࡮ࡪࡥࡰࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ࿩")+zzekZcWL1sBgnoxN8f3vdQ0r+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧࠡ࡟ࠪ࿪"))
				if showDialogs: a6rVSjDMF87KyYINcuOP1l40Hbp(AAbvaXV2DQzfNHdm4U3tT(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ࿫"),sJw9QWiq1Kr0xfeVRI(u"ࠩส่ๆ๐ฯ๋๊่้้ࠣศศำࠣๅ็฽้ࠠล้ห๋ࠥๆฺฬ๊ࠫ࿬"))
				return EsCplGc5N4mBuYW0RVQt6b
	return LhFAGlQ19zr
def GOnZYxartRwkPqMJFub(*aargs,**kkwargs):
	if aargs:
		direction = aargs[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		lPutL0Q6UiykHZAE = aargs[BkM54Kr7Qbqn]
		if not direction: direction = jL5CrsRwebpyDVXUc1EQP(u"ࠪࡧࡪࡴࡴࡦࡴࠪ࿭")
		if not lPutL0Q6UiykHZAE: lPutL0Q6UiykHZAE = ssynAg0zhSkoCpOMDV9(u"ࠫฬูสๆำสีࠬ࿮")
		ZfbBg9NLkAc = aargs[teaC5j4HuGDqpwcmUzJ]
		YQDmGRx3CWc2HX9V0wa4O = C0qrknitpM4Z.join(aargs[wdftVMyzF17cYETHu(u"࠴Ꮲ"):])
	else: direction,lPutL0Q6UiykHZAE,ZfbBg9NLkAc,YQDmGRx3CWc2HX9V0wa4O = fy8iFgEkrO12NR9TWBI35sjY6qHvV,oRJAfwD957WkUyBM1Ehu8m(u"ࠬࡕࡋࠨ࿯"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	jPRJMOhT415yvioG8rN9m0Q3b(direction,fy8iFgEkrO12NR9TWBI35sjY6qHvV,lPutL0Q6UiykHZAE,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ZfbBg9NLkAc,YQDmGRx3CWc2HX9V0wa4O,**kkwargs)
	return
def vv7siKgM9IfbCjPNqxXD(*aargs,**kkwargs):
	direction = aargs[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	oYEtZAlgMOD9TrfVvIxdp2J5C4Q = aargs[BkM54Kr7Qbqn]
	fcU6tIv0QJNz = aargs[teaC5j4HuGDqpwcmUzJ]
	if fcU6tIv0QJNz or oYEtZAlgMOD9TrfVvIxdp2J5C4Q: Wz6sV4JBXLKpRyAFUg = EsCplGc5N4mBuYW0RVQt6b
	else: Wz6sV4JBXLKpRyAFUg = LhFAGlQ19zr
	ZfbBg9NLkAc = aargs[XW57OCeGnFTLQbaqdrD9zM]
	YQDmGRx3CWc2HX9V0wa4O = aargs[vD4Fh6ictZ7wME]
	if not direction: direction = EE1jeHnIoad(u"࠭ࡣࡦࡰࡷࡩࡷ࠭࿰")
	if not oYEtZAlgMOD9TrfVvIxdp2J5C4Q: oYEtZAlgMOD9TrfVvIxdp2J5C4Q = N6NGJ4vpmidqMCh7yo(u"ࠧไๆสࠤࠥࡔ࡯ࠨ࿱")
	if not fcU6tIv0QJNz: fcU6tIv0QJNz = jL5CrsRwebpyDVXUc1EQP(u"ࠨ่฼้࡙ࠥࠦࡦࡵࠪ࿲")
	if len(aargs)>=vU6DxuzPwMpg(u"࠹Ꮴ"): YQDmGRx3CWc2HX9V0wa4O += C0qrknitpM4Z+aargs[LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠷Ꮳ")]
	if len(aargs)>=V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠻Ꮵ"): YQDmGRx3CWc2HX9V0wa4O += C0qrknitpM4Z+aargs[LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠻Ꮶ")]
	p7uvjbV1ftxo8yS6PNkH = jPRJMOhT415yvioG8rN9m0Q3b(direction,oYEtZAlgMOD9TrfVvIxdp2J5C4Q,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fcU6tIv0QJNz,ZfbBg9NLkAc,YQDmGRx3CWc2HX9V0wa4O,**kkwargs)
	if p7uvjbV1ftxo8yS6PNkH==-Gcw2nelTR864XCVruO3mAFqI5a(u"࠷Ꮷ") and Wz6sV4JBXLKpRyAFUg: p7uvjbV1ftxo8yS6PNkH = -BkM54Kr7Qbqn
	elif p7uvjbV1ftxo8yS6PNkH==-BkM54Kr7Qbqn and not Wz6sV4JBXLKpRyAFUg: p7uvjbV1ftxo8yS6PNkH = LhFAGlQ19zr
	elif p7uvjbV1ftxo8yS6PNkH==D2D96X5NGamBhrFwvL8VEbqiSfZIl: p7uvjbV1ftxo8yS6PNkH = LhFAGlQ19zr
	elif p7uvjbV1ftxo8yS6PNkH==teaC5j4HuGDqpwcmUzJ: p7uvjbV1ftxo8yS6PNkH = EsCplGc5N4mBuYW0RVQt6b
	return p7uvjbV1ftxo8yS6PNkH
def qYUPXpmOCTk9byoAGKieDQZ8u41J3S(*aargs,**kkwargs):
	return nn19vN7ifGslVJODZWzCSudBK8.Dialog().select(*aargs,**kkwargs)
def a6rVSjDMF87KyYINcuOP1l40Hbp(*aargs,**kkwargs):
	ZfbBg9NLkAc = aargs[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	YQDmGRx3CWc2HX9V0wa4O = aargs[BkM54Kr7Qbqn]
	kegKnbrCa4O8v = kkwargs[KfHAW8VGbrxi(u"ࠩࡷ࡭ࡲ࡫ࠧ࿳")] if uulNDCPyef78(u"ࠪࡸ࡮ࡳࡥࠨ࿴") in list(kkwargs.keys()) else jL5CrsRwebpyDVXUc1EQP(u"࠱࠱࠲࠳Ꮸ")
	BBCIp4fz6rQjTKwS = aargs[teaC5j4HuGDqpwcmUzJ] if len(aargs)>teaC5j4HuGDqpwcmUzJ and PlpyFa9QMKXxOD1cvHzmI(u"ࠫࡹ࡯࡭ࡦࠩ࿵") not in aargs[teaC5j4HuGDqpwcmUzJ] else sIzDXlTHYUC5L3xZGnr(u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡣࡷ࡫ࡧࡶ࡮ࡤࡶࠬ࿶")
	NvoyFmqZb67 = YMsWIfu7ojp2t4XJyZN05aC3l(daemon=EsCplGc5N4mBuYW0RVQt6b,target=ZJ4zhiV9pRGjac7B,args=(ZfbBg9NLkAc,YQDmGRx3CWc2HX9V0wa4O,BBCIp4fz6rQjTKwS,kegKnbrCa4O8v))
	NvoyFmqZb67.start()
	return
def ZJ4zhiV9pRGjac7B(ZfbBg9NLkAc,YQDmGRx3CWc2HX9V0wa4O,BBCIp4fz6rQjTKwS,kegKnbrCa4O8v):
	M5MDCe9ORnrg36I = BBCIp4fz6rQjTKwS.replace(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤ࠭࿷"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	name = bNHEp28wg51k(EsCplGc5N4mBuYW0RVQt6b,M5MDCe9ORnrg36I+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠧࠡ࠯ࠣࠫ࿸")+ZfbBg9NLkAc+wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠨࠢ࠰ࠤࠬ࿹")+YQDmGRx3CWc2HX9V0wa4O)
	name = KaUrpGJVDF470YloiwbH69tqmXyuOT(name)
	image_filename = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(hcqdaSHI6RONPbomY7K1w,name+SnhLjmfeJC(u"ࠩ࠱ࡴࡳ࡭ࠧ࿺"))
	if HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.exists(image_filename):
		if BBCIp4fz6rQjTKwS==o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࡵࡩ࡬ࡻ࡬ࡢࡴࠪ࿻"): image_height = o1INZ3ViQqS0Uw5z6kMjbv(u"࠲࠳࠺Ꮹ")
		elif BBCIp4fz6rQjTKwS==wdftVMyzF17cYETHu(u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡢࡥࡺࡺ࡯ࠨ࿼"): image_height = LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠴࠴࠴Ꮺ")
	else: image_height = TatKxLsejrR2oud(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ZfbBg9NLkAc,YQDmGRx3CWc2HX9V0wa4O,BBCIp4fz6rQjTKwS,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠬࡲࡥࡧࡶࠪ࿽"),LhFAGlQ19zr,image_filename)
	SKg9qcnx5iXwLDMpF = Y4csmkeFLyGVDC(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭ࡄࡪࡣ࡯ࡳ࡬ࡔ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡍࡲࡧࡧࡦ࠰ࡻࡱࡱ࠭࿾"),uugoLac4UGZztBeijxW1k0,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨ࿿"),aOQTKXFL54Nl60Zhp3MbE(u"ࠨ࠹࠵࠴ࡵ࠭က"))
	SKg9qcnx5iXwLDMpF.show()
	if BBCIp4fz6rQjTKwS==AAbvaXV2DQzfNHdm4U3tT(u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡣࡸࡸࡴ࠭ခ"):
		SKg9qcnx5iXwLDMpF.getControl(ssynAg0zhSkoCpOMDV9(u"࠽࠵࠺࠰Ꮼ")).setHeight(wdftVMyzF17cYETHu(u"࠵࠵࠺Ꮻ"))
		SKg9qcnx5iXwLDMpF.getControl(AAbvaXV2DQzfNHdm4U3tT(u"࠹࠱࠶࠳Ꮿ")).setPosition(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠺࠻Ꮽ"),-KfHAW8VGbrxi(u"࠾࠰Ꮾ"))
		SKg9qcnx5iXwLDMpF.getControl(EE1jeHnIoad(u"࠺࠲࠸࠴Ᏸ")).setPosition(AAbvaXV2DQzfNHdm4U3tT(u"࠳࠵࠴Ᏹ"),-EE1jeHnIoad(u"࠹࠴Ᏺ"))
		SKg9qcnx5iXwLDMpF.getControl(Hr25gta6XcqO(u"࠺࠰࠱Ᏽ")).setPosition(FmYoGejTnwKME7d9zPc(u"࠽࠵Ᏻ"),-ggjO5CrKVRPITaesWkxD(u"࠸࠻Ᏼ"))
	SKg9qcnx5iXwLDMpF.getControl(I18uSKaWhgTBeYUPD4sr(u"࠴࠱࠳᏶")).setVisible(LhFAGlQ19zr)
	SKg9qcnx5iXwLDMpF.getControl(jL5CrsRwebpyDVXUc1EQP(u"࠵࠲࠵᏷")).setVisible(LhFAGlQ19zr)
	SKg9qcnx5iXwLDMpF.getControl(LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠻࠳࠹࠵ᏸ")).setImage(image_filename)
	SKg9qcnx5iXwLDMpF.getControl(ggjO5CrKVRPITaesWkxD(u"࠼࠴࠺࠶ᏹ")).setHeight(image_height)
	uUqrNPcXKBoQ0slv.sleep(kegKnbrCa4O8v//s5WMHyQN4mpie(u"࠵࠵࠶࠰࠯࠲ᏺ"))
	return
def BBUOlfYgcEFQCetXh8A04objZKG(*aargs,**kkwargs):
	ZfbBg9NLkAc,YQDmGRx3CWc2HX9V0wa4O,profile,direction = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,oRJAfwD957WkUyBM1Ehu8m(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫဂ"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠫࡱ࡫ࡦࡵࠩဃ")
	if len(aargs)>=BkM54Kr7Qbqn: ZfbBg9NLkAc = aargs[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	if len(aargs)>=teaC5j4HuGDqpwcmUzJ: YQDmGRx3CWc2HX9V0wa4O = aargs[BkM54Kr7Qbqn]
	if len(aargs)>=XW57OCeGnFTLQbaqdrD9zM: profile = aargs[teaC5j4HuGDqpwcmUzJ]
	if len(aargs)>=vD4Fh6ictZ7wME: direction = aargs[XW57OCeGnFTLQbaqdrD9zM]
	return cFjMEShi6Pp0otRBgeXq8(direction,ZfbBg9NLkAc,YQDmGRx3CWc2HX9V0wa4O,profile)
def hjaUEy4dNPCIe(*aargs,**kkwargs):
	return nn19vN7ifGslVJODZWzCSudBK8.Dialog().contextmenu(*aargs,**kkwargs)
def kkXUMFtcVYWZjDdseS(*aargs,**kkwargs):
	return nn19vN7ifGslVJODZWzCSudBK8.Dialog().browseSingle(*aargs,**kkwargs)
def zRtIL7jDZHGJ2XWQc8OkgPCborpK0(*aargs,**kkwargs):
	return nn19vN7ifGslVJODZWzCSudBK8.Dialog().input(*aargs,**kkwargs)
def hieYJByqUTsF9CH7aD3(*aargs,**kkwargs):
	return nn19vN7ifGslVJODZWzCSudBK8.DialogProgress(*aargs,**kkwargs)
def jPRJMOhT415yvioG8rN9m0Q3b(direction,button0=fy8iFgEkrO12NR9TWBI35sjY6qHvV,button1=fy8iFgEkrO12NR9TWBI35sjY6qHvV,button2=fy8iFgEkrO12NR9TWBI35sjY6qHvV,ZfbBg9NLkAc=fy8iFgEkrO12NR9TWBI35sjY6qHvV,YQDmGRx3CWc2HX9V0wa4O=fy8iFgEkrO12NR9TWBI35sjY6qHvV,profile=N6NGJ4vpmidqMCh7yo(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥࡢࡪࡩࡩࡳࡳࡺࠧင"),WtgI1vLViFs50jSqrbz=D2D96X5NGamBhrFwvL8VEbqiSfZIl,VrLUzTPGDQb=D2D96X5NGamBhrFwvL8VEbqiSfZIl):
	if not direction: direction = Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠭ࡣࡦࡰࡷࡩࡷ࠭စ")
	SKg9qcnx5iXwLDMpF = o7tTZByhsMOjpwN(FmYoGejTnwKME7d9zPc(u"ࠧࡅ࡫ࡤࡰࡴ࡭ࡃࡰࡰࡩ࡭ࡷࡳࡔࡩࡴࡨࡩࡇࡻࡴࡵࡱࡱࡷ࠳ࡾ࡭࡭ࠩဆ"),uugoLac4UGZztBeijxW1k0,aOQTKXFL54Nl60Zhp3MbE(u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩဇ"),jL5CrsRwebpyDVXUc1EQP(u"ࠩ࠺࠶࠵ࡶࠧဈ"))
	SKg9qcnx5iXwLDMpF.qqeM0LJVu2xIFOGtzwR8rdB(button0,button1,button2,ZfbBg9NLkAc,YQDmGRx3CWc2HX9V0wa4O,profile,direction,WtgI1vLViFs50jSqrbz,VrLUzTPGDQb)
	if WtgI1vLViFs50jSqrbz>D2D96X5NGamBhrFwvL8VEbqiSfZIl: SKg9qcnx5iXwLDMpF.zXY3aol5d8b()
	if VrLUzTPGDQb>D2D96X5NGamBhrFwvL8VEbqiSfZIl: SKg9qcnx5iXwLDMpF.jQS4VGxF2afg()
	if WtgI1vLViFs50jSqrbz==D2D96X5NGamBhrFwvL8VEbqiSfZIl and VrLUzTPGDQb==D2D96X5NGamBhrFwvL8VEbqiSfZIl: SKg9qcnx5iXwLDMpF.qaO8xwcBEmGI4dtseoubTjWz7C()
	SKg9qcnx5iXwLDMpF.doModal()
	p7uvjbV1ftxo8yS6PNkH = SKg9qcnx5iXwLDMpF.choiceID
	return p7uvjbV1ftxo8yS6PNkH
def cFjMEShi6Pp0otRBgeXq8(direction,ZfbBg9NLkAc,YQDmGRx3CWc2HX9V0wa4O,profile=sJw9QWiq1Kr0xfeVRI(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫဉ")):
	if not direction: direction = OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠫࡱ࡫ࡦࡵࠩည")
	SKg9qcnx5iXwLDMpF = Y4csmkeFLyGVDC(Hr25gta6XcqO(u"ࠬࡊࡩࡢ࡮ࡲ࡫࡙࡫ࡸࡵࡘ࡬ࡩࡼ࡫ࡲࡇࡷ࡯ࡰࡘࡩࡲࡦࡧࡱ࠲ࡽࡳ࡬ࠨဋ"),uugoLac4UGZztBeijxW1k0,I18uSKaWhgTBeYUPD4sr(u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧဌ"),jL5CrsRwebpyDVXUc1EQP(u"ࠧ࠸࠴࠳ࡴࠬဍ"))
	image_filename = bJfZTNHCW9D8i4qxcEgstzBjwYL1.replace(FmYoGejTnwKME7d9zPc(u"ࠨࡡ࠳࠴࠵࠶࡟ࠨဎ"),Hr25gta6XcqO(u"ࠩࡢࠫဏ")+str(uUqrNPcXKBoQ0slv.time())+KfHAW8VGbrxi(u"ࠪࡣࠬတ"))
	image_filename = image_filename.replace(oRJAfwD957WkUyBM1Ehu8m(u"ࠫࡡࡢࠧထ"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬࡢ࡜࡝࡞ࠪဒ")).replace(aOQTKXFL54Nl60Zhp3MbE(u"࠭࠯࠰ࠩဓ"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧ࠰࠱࠲࠳ࠬန"))
	image_height = TatKxLsejrR2oud(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ZfbBg9NLkAc,YQDmGRx3CWc2HX9V0wa4O,profile,direction,LhFAGlQ19zr,image_filename)
	SKg9qcnx5iXwLDMpF.show()
	SKg9qcnx5iXwLDMpF.getControl(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠾࠶࠵࠱ᏻ")).setHeight(image_height)
	SKg9qcnx5iXwLDMpF.getControl(I18uSKaWhgTBeYUPD4sr(u"࠿࠰࠶࠲ᏼ")).setImage(image_filename)
	RGboVviD0qMAf = SKg9qcnx5iXwLDMpF.doModal()
	try: HoxKENAey2MdTt9kDUrVnWGLS0CPa.remove(image_filename)
	except: pass
	return RGboVviD0qMAf
def j4lUV5BzHDI6EN(SMzTXk783NBPg6j0rUfu2YIF5Q=EsCplGc5N4mBuYW0RVQt6b):
	if SMzTXk783NBPg6j0rUfu2YIF5Q:
		ll7qCX4wJ5kQonVW6KtcMuZGSvDEs = rIhXWK91vRuC(jUCABmLYMf0G,N6NGJ4vpmidqMCh7yo(u"ࠨࡵࡷࡶࠬပ"),o1INZ3ViQqS0Uw5z6kMjbv(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬဖ"),Gcw2nelTR864XCVruO3mAFqI5a(u"࡙ࠪࡘࡋࡒࡂࡉࡈࡒ࡙࠭ဗ"))
		if ll7qCX4wJ5kQonVW6KtcMuZGSvDEs: return ll7qCX4wJ5kQonVW6KtcMuZGSvDEs
	YQDmGRx3CWc2HX9V0wa4O = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if D2D96X5NGamBhrFwvL8VEbqiSfZIl and ND4YsIrucC.succeeded:
		Vpnd4wgPqAO1j6z8N = ND4YsIrucC.content
		eKsJrCAZgnXiVEN5fx4cp0kG9TIbR = Vpnd4wgPqAO1j6z8N.count(QjAINyUC7MDRq5d8e4vl9(u"ࠫࡒࡵࡺࡪ࡮࡯ࡥࠬဘ"))
		if eKsJrCAZgnXiVEN5fx4cp0kG9TIbR>wdftVMyzF17cYETHu(u"࠸࠱ᏽ"):
			YQDmGRx3CWc2HX9V0wa4O = EcQxOa3RJm86WjTKA.findall(EE1jeHnIoad(u"ࠬ࡭ࡥࡵ࠯ࡷ࡬ࡪ࠳࡬ࡪࡵࡷ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧမ"),Vpnd4wgPqAO1j6z8N,EcQxOa3RJm86WjTKA.DOTALL)
			YQDmGRx3CWc2HX9V0wa4O = YQDmGRx3CWc2HX9V0wa4O[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	if not YQDmGRx3CWc2HX9V0wa4O:
		tPdL09WFbRujiUEDwSaAzXH = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(uugoLac4UGZztBeijxW1k0,PlpyFa9QMKXxOD1cvHzmI(u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬယ"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠧࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡶ࠲ࡹࡾࡴࠨရ"))
		YQDmGRx3CWc2HX9V0wa4O = open(tPdL09WFbRujiUEDwSaAzXH,sJw9QWiq1Kr0xfeVRI(u"ࠨࡴࡥࠫလ")).read()
		if jTDWgftK7NEmx0JAkOn2aRIvweq: YQDmGRx3CWc2HX9V0wa4O = YQDmGRx3CWc2HX9V0wa4O.decode(Tk9eH2qw6Brsuhj)
		YQDmGRx3CWc2HX9V0wa4O = YQDmGRx3CWc2HX9V0wa4O.replace(FFkml6ZbgXD,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	ZlxwjEqsXyr3tSk = EcQxOa3RJm86WjTKA.findall(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠩࠫࡑࡴࢀࡩ࡭࡮ࡤ࠲࠯ࡅࠩ࡝ࡰࠪဝ"),YQDmGRx3CWc2HX9V0wa4O,EcQxOa3RJm86WjTKA.DOTALL)
	ddmT1tMiphYUWIzsc = []
	for cjUwESlPvXV3btCHfWzFqn7o5a in ZlxwjEqsXyr3tSk:
		ruz6I79HSZiJ3p18hoQaMmkE = cjUwESlPvXV3btCHfWzFqn7o5a.lower()
		if EE1jeHnIoad(u"ࠪࡥࡳࡪࡲࡰ࡫ࡧࠫသ") in ruz6I79HSZiJ3p18hoQaMmkE: continue
		if Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫࡺࡨࡵ࡯ࡶࡸࠫဟ") in ruz6I79HSZiJ3p18hoQaMmkE: continue
		if FmYoGejTnwKME7d9zPc(u"ࠬ࡯ࡰࡩࡱࡱࡩࠬဠ") in ruz6I79HSZiJ3p18hoQaMmkE: continue
		if o1INZ3ViQqS0Uw5z6kMjbv(u"࠭ࡣࡳࡱࡶࠫအ") in ruz6I79HSZiJ3p18hoQaMmkE: continue
		ddmT1tMiphYUWIzsc.append(cjUwESlPvXV3btCHfWzFqn7o5a)
	ll7qCX4wJ5kQonVW6KtcMuZGSvDEs = yiTBYwps2mCrb4jGPux0cIJ.sample(ddmT1tMiphYUWIzsc,BkM54Kr7Qbqn)
	ll7qCX4wJ5kQonVW6KtcMuZGSvDEs = ll7qCX4wJ5kQonVW6KtcMuZGSvDEs[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪဢ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠨࡗࡖࡉࡗࡇࡇࡆࡐࡗࠫဣ"),ll7qCX4wJ5kQonVW6KtcMuZGSvDEs,CQOaFUrZJHwKRxIj4yXEYs5V)
	return ll7qCX4wJ5kQonVW6KtcMuZGSvDEs
def XX09uEmwSJvLZyYjW(Okwr0yDIL1oVF9AlWRbduUtnzp=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if I4t9qonjrm.ALLOW_SHOWDIALOGS_FIX==LhFAGlQ19zr: return
	if not Okwr0yDIL1oVF9AlWRbduUtnzp: Okwr0yDIL1oVF9AlWRbduUtnzp = NFtwAhXgZB9u.format_exc()
	if s5WMHyQN4mpie(u"ࠩࡖࡽࡸࡺࡥ࡮ࡇࡻ࡭ࡹ࠭ဤ") in Okwr0yDIL1oVF9AlWRbduUtnzp or o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪࡣࡤࡥࡆࡐࡔࡆࡉࡤࡋࡘࡊࡖࡢࡣࡤ࠭ဥ") in Okwr0yDIL1oVF9AlWRbduUtnzp: return
	if Okwr0yDIL1oVF9AlWRbduUtnzp!=Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠫࡓࡵ࡮ࡦࡖࡼࡴࡪࡀࠠࡏࡱࡱࡩࡡࡴࠧဦ"): CfgZ0zWP5XBpoGQwLUY.stderr.write(Okwr0yDIL1oVF9AlWRbduUtnzp)
	KkS426yjbo8xFvBMVig5YcLCH = Okwr0yDIL1oVF9AlWRbduUtnzp.splitlines()
	RLJCuTQqVA46r8Sx = KkS426yjbo8xFvBMVig5YcLCH[-Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠲᏾")]
	YYj6Bx3hdfmR4FUA = open(Z3WAPsTKBgHV5uSfGitDNL4,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠬࡸࡢࠨဧ")).read()
	if jTDWgftK7NEmx0JAkOn2aRIvweq: YYj6Bx3hdfmR4FUA = YYj6Bx3hdfmR4FUA.decode(Tk9eH2qw6Brsuhj)
	YYj6Bx3hdfmR4FUA = YYj6Bx3hdfmR4FUA[-EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠺࠳࠴࠵᏿"):]
	Q2l3BGZqfz7kjepvxwdWirF0DsRoC = s5WMHyQN4mpie(u"࠭࠽ࠨဨ")*Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠴࠴࠵᐀")
	if Q2l3BGZqfz7kjepvxwdWirF0DsRoC in YYj6Bx3hdfmR4FUA: YYj6Bx3hdfmR4FUA = YYj6Bx3hdfmR4FUA.rsplit(Q2l3BGZqfz7kjepvxwdWirF0DsRoC,BkM54Kr7Qbqn)[BkM54Kr7Qbqn]
	if RLJCuTQqVA46r8Sx in YYj6Bx3hdfmR4FUA: YYj6Bx3hdfmR4FUA = YYj6Bx3hdfmR4FUA.rsplit(RLJCuTQqVA46r8Sx,BkM54Kr7Qbqn)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	OxdaGKn62ICq7jF8pPWcgE901UV = EcQxOa3RJm86WjTKA.findall(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠧࠩࡕࡲࡹࡷࡩࡥࡽࡏࡲࡨࡪ࠯࠺ࠡ࡞࡞ࠤ࠭࠴ࠪࡀࠫࠣࡠࡢ࠭ဩ"),YYj6Bx3hdfmR4FUA,EcQxOa3RJm86WjTKA.DOTALL)
	for NGvIfmpjQSE,mE7D5fBQZOKJdhtVUkHaIgRWpx in reversed(OxdaGKn62ICq7jF8pPWcgE901UV):
		if mE7D5fBQZOKJdhtVUkHaIgRWpx: break
	else: mE7D5fBQZOKJdhtVUkHaIgRWpx = I18uSKaWhgTBeYUPD4sr(u"ࠨࡐࡒࡘ࡙ࠥࡐࡆࡅࡌࡊࡎࡋࡄࠨဪ")
	HEj7vrQguL8S5ydIcUwF2kNG6PJ4,cjUwESlPvXV3btCHfWzFqn7o5a,z4cgF603iZXLOvVCtYj = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	SvwODt1oKGIAQeW9PXLcgul2N8ymEM = vU6DxuzPwMpg(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨါ")+WydpaVx5YmLoCiIgA34eEBlb+wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠪห้ิืฤ࠼ࠣࠤࠬာ")+T7ASIp1ZYwio9HQ8cObJK+RLJCuTQqVA46r8Sx
	buOAHlCgTQfIWP3t7qRw8pms6Z0xYj = KfHAW8VGbrxi(u"ࠫࡠࡘࡔࡍ࡟ࠪိ")+WydpaVx5YmLoCiIgA34eEBlb+FgXzMs0YSDt(u"ࠬอไๆืาี࠿ࠦࠠࠨီ")+T7ASIp1ZYwio9HQ8cObJK+mE7D5fBQZOKJdhtVUkHaIgRWpx
	for jjXWkgZdiz0f9D6SC813OYbcw in reversed(KkS426yjbo8xFvBMVig5YcLCH):
		if sJw9QWiq1Kr0xfeVRI(u"࠭ࡆࡪ࡮ࡨࠤࠧ࠭ု") in jjXWkgZdiz0f9D6SC813OYbcw and O3OVuapf0YFjbm5oUQDg(u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ူ") in jjXWkgZdiz0f9D6SC813OYbcw: break
	jjXWkgZdiz0f9D6SC813OYbcw = EcQxOa3RJm86WjTKA.findall(PlpyFa9QMKXxOD1cvHzmI(u"ࠨࡈ࡬ࡰࡪࠦࠢࠩ࠰࠭ࡃ࠮ࠨ࡜࠭ࠢ࡯࡭ࡳ࡫ࠠࠩ࠰࠭ࡃ࠮ࡢࠬࠡ࡫ࡱࠤ࠭࠴ࠪࡀࠫࠧࠫေ"),jjXWkgZdiz0f9D6SC813OYbcw,EcQxOa3RJm86WjTKA.DOTALL)
	if jjXWkgZdiz0f9D6SC813OYbcw:
		HEj7vrQguL8S5ydIcUwF2kNG6PJ4,cjUwESlPvXV3btCHfWzFqn7o5a,z4cgF603iZXLOvVCtYj = jjXWkgZdiz0f9D6SC813OYbcw[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		if ssynAg0zhSkoCpOMDV9(u"ࠩ࠲ࠫဲ") in HEj7vrQguL8S5ydIcUwF2kNG6PJ4: HEj7vrQguL8S5ydIcUwF2kNG6PJ4 = HEj7vrQguL8S5ydIcUwF2kNG6PJ4.rsplit(SnhLjmfeJC(u"ࠪ࠳ࠬဳ"),BkM54Kr7Qbqn)[BkM54Kr7Qbqn]
		else: HEj7vrQguL8S5ydIcUwF2kNG6PJ4 = HEj7vrQguL8S5ydIcUwF2kNG6PJ4.rsplit(AAbvaXV2DQzfNHdm4U3tT(u"ࠫࡡࡢࠧဴ"),BkM54Kr7Qbqn)[BkM54Kr7Qbqn]
		fw8OBsR6aQE2Vp4zqnHG = wdftVMyzF17cYETHu(u"ࠬࡡࡒࡕࡎࡠࠫဵ")+WydpaVx5YmLoCiIgA34eEBlb+LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠭วๅ็็ๅ࠿ࠦࠠࠨံ")+T7ASIp1ZYwio9HQ8cObJK+HEj7vrQguL8S5ydIcUwF2kNG6PJ4
		ngsUmJi3pwl8uTB5PyN71 = ssynAg0zhSkoCpOMDV9(u"ࠧ࡜ࡔࡗࡐࡢ့࠭")+WydpaVx5YmLoCiIgA34eEBlb+oRJAfwD957WkUyBM1Ehu8m(u"ࠨษ็ื฼ื࠺ࠡࠢࠪး")+T7ASIp1ZYwio9HQ8cObJK+cjUwESlPvXV3btCHfWzFqn7o5a
		f5fA0dmiIyZJjkUoTR47lSXOKeMVz = wdftVMyzF17cYETHu(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨ္")+WydpaVx5YmLoCiIgA34eEBlb+O3OVuapf0YFjbm5oUQDg(u"ࠪห้๋ใศ่࠽ࠤ်ࠥ࠭")+T7ASIp1ZYwio9HQ8cObJK+z4cgF603iZXLOvVCtYj
		GTtHnFW7zVg62Bhs5icRwLb = fw8OBsR6aQE2Vp4zqnHG+C0qrknitpM4Z+ngsUmJi3pwl8uTB5PyN71+C0qrknitpM4Z+f5fA0dmiIyZJjkUoTR47lSXOKeMVz+C0qrknitpM4Z+buOAHlCgTQfIWP3t7qRw8pms6Z0xYj+C0qrknitpM4Z+SvwODt1oKGIAQeW9PXLcgul2N8ymEM
		BBDY6Pc0MhloLwS = ngsUmJi3pwl8uTB5PyN71+C0qrknitpM4Z+buOAHlCgTQfIWP3t7qRw8pms6Z0xYj+C0qrknitpM4Z+SvwODt1oKGIAQeW9PXLcgul2N8ymEM+C0qrknitpM4Z+fw8OBsR6aQE2Vp4zqnHG+C0qrknitpM4Z+f5fA0dmiIyZJjkUoTR47lSXOKeMVz
		SdtwcOhnUm = ngsUmJi3pwl8uTB5PyN71+C0qrknitpM4Z+SvwODt1oKGIAQeW9PXLcgul2N8ymEM+C0qrknitpM4Z+fw8OBsR6aQE2Vp4zqnHG+C0qrknitpM4Z+f5fA0dmiIyZJjkUoTR47lSXOKeMVz
	else:
		fw8OBsR6aQE2Vp4zqnHG,ngsUmJi3pwl8uTB5PyN71,f5fA0dmiIyZJjkUoTR47lSXOKeMVz = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
		GTtHnFW7zVg62Bhs5icRwLb = buOAHlCgTQfIWP3t7qRw8pms6Z0xYj+oRJAfwD957WkUyBM1Ehu8m(u"ࠫࡡࡴ࡜࡯ࠩျ")+SvwODt1oKGIAQeW9PXLcgul2N8ymEM
		BBDY6Pc0MhloLwS = buOAHlCgTQfIWP3t7qRw8pms6Z0xYj+Gcw2nelTR864XCVruO3mAFqI5a(u"ࠬࡢ࡮࡝ࡰࠪြ")+SvwODt1oKGIAQeW9PXLcgul2N8ymEM
		SdtwcOhnUm = SvwODt1oKGIAQeW9PXLcgul2N8ymEM
	BVh6ndvbgGwlxKcZXRCpQA0omi5 = sJw9QWiq1Kr0xfeVRI(u"࠭อะอࠣา฼ษࠠ฻์ิࠤ๊่ี้ัࠪွ")+C0qrknitpM4Z
	eCKUHdutMbwaGIgLxQDZc51Sm = XRCk507baSlQucB63W()
	pywRS0XF3NJ2 = []
	OmsWt89dSA5HyCZ4wL = eCKUHdutMbwaGIgLxQDZc51Sm[oRJAfwD957WkUyBM1Ehu8m(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬှ")]
	llRq6FLEz7aoidKCOxJr9up = szWVcgPdT2CYH4Nka153hb(KoxvjArhL1TdInDmN9s)
	if wdftVMyzF17cYETHu(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ဿ") in list(eCKUHdutMbwaGIgLxQDZc51Sm.keys()):
		for mmaAZdIzeFH84Ty1BSrcwX0p7fRNh,cRLvC0liD4bTnqN,S0bgBpkj4MEUNQ1ZxHswenLGtaidv in OmsWt89dSA5HyCZ4wL:
			pywRS0XF3NJ2 = max(pywRS0XF3NJ2,cRLvC0liD4bTnqN)
		if llRq6FLEz7aoidKCOxJr9up<pywRS0XF3NJ2:
			ZfbBg9NLkAc = KfHAW8VGbrxi(u"ࠩๅ้ࠥฮสฮัํฯࠥอไษำ้ห๊าࠠใส็ࠤสืำศๆࠣห้ษฮุษฤࠤ้๊ๅษำ่ะࠬ၀")
			p7uvjbV1ftxo8yS6PNkH = jPRJMOhT415yvioG8rN9m0Q3b(sIzDXlTHYUC5L3xZGnr(u"ࠪࡶ࡮࡭ࡨࡵࠩ၁"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠫสืำศๆࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ၂"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠬะอะ์ฮࠫ၃"),QjAINyUC7MDRq5d8e4vl9(u"࠭ฮา๊ฯࠫ၄"),BVh6ndvbgGwlxKcZXRCpQA0omi5+ZfbBg9NLkAc,GTtHnFW7zVg62Bhs5icRwLb)
			if p7uvjbV1ftxo8yS6PNkH==BkM54Kr7Qbqn:
				import XbdWsnBA9G
				XbdWsnBA9G.mcPDrqAL95GBTaZfUtgvF0WM(EsCplGc5N4mBuYW0RVQt6b)
				n9grXGiQYD2wl8UjSRe3HcKhE()
			elif p7uvjbV1ftxo8yS6PNkH==teaC5j4HuGDqpwcmUzJ: n9grXGiQYD2wl8UjSRe3HcKhE()
	pJFN7hOvyf6u4awTt9m231rjBYq = rIhXWK91vRuC(jUCABmLYMf0G,EE1jeHnIoad(u"ࠧ࡭࡫ࡶࡸࠬ၅"),ssynAg0zhSkoCpOMDV9(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ၆"),vU6DxuzPwMpg(u"ࠩࡄࡐࡑࡥࡓࡆࡐࡗࡣࡊࡘࡒࡐࡔࡖࠫ၇"))
	if not pJFN7hOvyf6u4awTt9m231rjBYq: pJFN7hOvyf6u4awTt9m231rjBYq = []
	BBDY6Pc0MhloLwS = BBDY6Pc0MhloLwS.replace(C0qrknitpM4Z,FmYoGejTnwKME7d9zPc(u"ࠪࡠࡡࡴࠧ၈")).replace(O3OVuapf0YFjbm5oUQDg(u"ࠫࡠࡘࡔࡍ࡟ࠪ၉"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(WydpaVx5YmLoCiIgA34eEBlb,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	SdtwcOhnUm = SdtwcOhnUm.replace(C0qrknitpM4Z,CsDcLqQUVK4YBvHFW1(u"ࠬࡢ࡜࡯ࠩ၊")).replace(N6NGJ4vpmidqMCh7yo(u"࡛࠭ࡓࡖࡏࡡࠬ။"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(WydpaVx5YmLoCiIgA34eEBlb,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	xivS7sdEp34e0qNOYgRHWAnwZf1LB8 = KoxvjArhL1TdInDmN9s+ssynAg0zhSkoCpOMDV9(u"ࠧ࠻࠼ࠪ၌")+SdtwcOhnUm
	if xivS7sdEp34e0qNOYgRHWAnwZf1LB8 in pJFN7hOvyf6u4awTt9m231rjBYq:
		ZfbBg9NLkAc = sJw9QWiq1Kr0xfeVRI(u"ࠨๆๅำ่ࠥๅหࠢส๊ฯࠦำศสๅหࠥฮลาีส่ࠥํะศࠢส่ำ฽รࠡว็ํࠥอไๆสิ้ั࠭၍")
		GOnZYxartRwkPqMJFub(sJw9QWiq1Kr0xfeVRI(u"ࠩࡵ࡭࡬࡮ࡴࠨ၎"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,BVh6ndvbgGwlxKcZXRCpQA0omi5+ZfbBg9NLkAc,GTtHnFW7zVg62Bhs5icRwLb)
		return
	G8gK6HckSBTCstX = str(FpjKBIUaEwbmLkxANfs).split(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠪ࠲ࠬ၏"))[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	zzekZcWL1sBgnoxN8f3vdQ0r = I4t9qonjrm.SITESURLS[jL5CrsRwebpyDVXUc1EQP(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫၐ")][O3OVuapf0YFjbm5oUQDg(u"࠺ᐁ")]
	ND4YsIrucC = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,ggjO5CrKVRPITaesWkxD(u"ࠬࡖࡏࡔࡖࠪၑ"),zzekZcWL1sBgnoxN8f3vdQ0r,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EE1jeHnIoad(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡊࡒ࡛ࡤࡋࡘࡊࡖࡢࡉࡗࡘࡏࡓࡕ࠰࠵ࡸࡺࠧၒ"),LhFAGlQ19zr,LhFAGlQ19zr)
	Vpnd4wgPqAO1j6z8N = ND4YsIrucC.content
	srU418oR6Gd3cMOS9EBhYekC7Q = EcQxOa3RJm86WjTKA.findall(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧࡔࡖࡄࡖ࡙ࡀ࠺ࡔࡖࡄࡖ࡙ࡡ࡜ࡳ࡞ࡱࡡ࠰ࡀ࠺ࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰ࡀ࠺ࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰ࡀ࠺ࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰ࡀ࠺ࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰ࡋࡎࡅ࠼࠽ࡉࡓࡊࠧၓ"),Vpnd4wgPqAO1j6z8N,EcQxOa3RJm86WjTKA.DOTALL)
	for i8dUGHmpgP2eJcot,rTDZLl5QvH7XgwS,bbTfiPKcqGO5unkLt7ZEsI,ff1xJI0pnUrOlVeumzQ5ovZ9YRSg in srU418oR6Gd3cMOS9EBhYekC7Q:
		i8dUGHmpgP2eJcot = i8dUGHmpgP2eJcot.split(FgXzMs0YSDt(u"ࠨ࠭ࠪၔ"))
		bbTfiPKcqGO5unkLt7ZEsI = bbTfiPKcqGO5unkLt7ZEsI.split(vU6DxuzPwMpg(u"ࠩ࠮ࠫၕ"))
		ff1xJI0pnUrOlVeumzQ5ovZ9YRSg = ff1xJI0pnUrOlVeumzQ5ovZ9YRSg.split(O3OVuapf0YFjbm5oUQDg(u"ࠪ࠯ࠬၖ"))
		if cjUwESlPvXV3btCHfWzFqn7o5a in i8dUGHmpgP2eJcot and RLJCuTQqVA46r8Sx==rTDZLl5QvH7XgwS and KoxvjArhL1TdInDmN9s in bbTfiPKcqGO5unkLt7ZEsI and G8gK6HckSBTCstX in ff1xJI0pnUrOlVeumzQ5ovZ9YRSg:
			ZfbBg9NLkAc = V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠫ์ึวࠡษ็า฼ษࠠๆ฻ิ์ๆ่ࠦิ์฼ห้าࠠษษ็ษฺีวาࠢส่็อฯๆࠩၗ")
			Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(CsDcLqQUVK4YBvHFW1(u"ࠬࡸࡩࡨࡪࡷࠫၘ"),Gcw2nelTR864XCVruO3mAFqI5a(u"࠭ฮา๊ฯࠫၙ"),sJw9QWiq1Kr0xfeVRI(u"ࠧฦำึห้ࠦลๅ๋ࠣห้๋ศา็ฯࠫၚ"),BVh6ndvbgGwlxKcZXRCpQA0omi5+ZfbBg9NLkAc,GTtHnFW7zVg62Bhs5icRwLb)
			if Scj7zgGFVA83otMpwUkxhm0BLN1==BkM54Kr7Qbqn: GOnZYxartRwkPqMJFub(CsDcLqQUVK4YBvHFW1(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨၛ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ZfbBg9NLkAc)
			return
	ZfbBg9NLkAc = wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠩส่ึาวยࠢศีุอไ้ࠡำหࠥอไฯูฦࠤส๊้ࠡษ็้อืๅอࠩၜ")
	TrdwtBCoInxfebSWZl5XV34aDyH = jPRJMOhT415yvioG8rN9m0Q3b(oRJAfwD957WkUyBM1Ehu8m(u"ࠪࡶ࡮࡭ࡨࡵࠩၝ"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠫสืำศๆࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨၞ"),SnhLjmfeJC(u"ࠬะอะ์ฮࠤัุฦ๋ࠩၟ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠭สฮัํฯࠥอไษำ้ห๊าࠧၠ"),BVh6ndvbgGwlxKcZXRCpQA0omi5+ZfbBg9NLkAc,GTtHnFW7zVg62Bhs5icRwLb)
	if TrdwtBCoInxfebSWZl5XV34aDyH==BkM54Kr7Qbqn:
		RKYsragFJfoQlEU1Mj5HPAnIDTS(LhFAGlQ19zr)
		a6rVSjDMF87KyYINcuOP1l40Hbp(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧ็ฮะฮࠥ฿ๅๅ์ฬࠤฬ๊สฮัํฯࠥอไอิษ๎ࠬၡ"),sIzDXlTHYUC5L3xZGnr(u"ࠨ๏ࡖࡹࡨࡩࡥࡴࡵࠪၢ"),uUqrNPcXKBoQ0slv=wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠼࠻࠰ᐂ"))
		n9grXGiQYD2wl8UjSRe3HcKhE()
	elif TrdwtBCoInxfebSWZl5XV34aDyH==teaC5j4HuGDqpwcmUzJ:
		import XbdWsnBA9G
		XbdWsnBA9G.mcPDrqAL95GBTaZfUtgvF0WM(EsCplGc5N4mBuYW0RVQt6b)
		n9grXGiQYD2wl8UjSRe3HcKhE()
	Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠩࡦࡩࡳࡺࡥࡳࠩၣ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ၤ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ุࠫ๎แࠡ์อ้ࠥหัิษ็ࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊ࠦลๅ๋ࠣห้๋ศา็ฯࠤ้้๊ࠡ์฼ีๆࠦวๅ็หี๊าࠠฤ์้ࠤํ๋ส๊๋ࠢ็๏็้ࠠๆ่หีอࠠฮื็ฮࠥํะ่ࠢสฺ่๊ใๅห่ࠣศ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศ๊ࠡ็หࠥ๐ำหูํ฽ࠥอีๅษะࠤฺ๊ใๅหࠣ์์๎ࠠๅษࠣ๎฾ืแࠡๅํๅࠥ฾็าฬࠣ์้๋วัษࠣ฼์ืส๊่ࠡฮ๎ุ่ࠦำอࠤ์ึ็ࠡษ็ู้้ไสࠢ࠱ࠤ์๊ࠠหำํำࠥษัิษ็ࠤฬ๊ำอๆࠣรࠬၥ"))
	if Scj7zgGFVA83otMpwUkxhm0BLN1==BkM54Kr7Qbqn: ogwSxkDfqmctLUiVEC7 = FgXzMs0YSDt(u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࠨၦ")
	else:
		GOnZYxartRwkPqMJFub(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ၧ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,wdftVMyzF17cYETHu(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪၨ"),WydpaVx5YmLoCiIgA34eEBlb+AAbvaXV2DQzfNHdm4U3tT(u"ࠨฬ่ࠤสฺ๊ศรࠣษึูวๅࠢส่ำ฽รࠨၩ")+T7ASIp1ZYwio9HQ8cObJK+aOQTKXFL54Nl60Zhp3MbE(u"ࠩ࡟ࡲ้ษๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษ๋่ࠢฬ๊ࠦิฬฺ๎฾ࠦลึๆสัࠥอไฯูฦࠤอี่็ࠢึะ้ࠦวๅลั฻ฬวࠠศๆำ๎๋ࠥให๊หࠤๆ๐็ࠡฮ่๎฾ࠦสโษุ๎้ࠦ็ัษࠣห้ิืฤ๋ࠢ฾๏ื็ࠡ็้ࠤฬ๊รฯูสลࠬၪ"))
		return
	nhXGUOtlzjbo = BBDY6Pc0MhloLwS
	import XbdWsnBA9G
	ddecO3Tb9U5k = XbdWsnBA9G.PkNFw8KBOny2fb9D(aOQTKXFL54Nl60Zhp3MbE(u"ࠪࡉࡷࡸ࡯ࡳࡵࠪၫ"),nhXGUOtlzjbo,EsCplGc5N4mBuYW0RVQt6b,fy8iFgEkrO12NR9TWBI35sjY6qHvV,AAbvaXV2DQzfNHdm4U3tT(u"ࠫࡊࡓࡁࡊࡎ࠰ࡊࡗࡕࡍ࠮ࡕࡋࡓ࡜ࡥࡅ࡙ࡋࡗࡣࡊࡘࡒࡐࡔࡖࠫၬ"),ogwSxkDfqmctLUiVEC7)
	if ddecO3Tb9U5k and ogwSxkDfqmctLUiVEC7:
		pJFN7hOvyf6u4awTt9m231rjBYq.append(xivS7sdEp34e0qNOYgRHWAnwZf1LB8)
		tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,CsDcLqQUVK4YBvHFW1(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨၭ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭ࡁࡍࡎࡢࡗࡊࡔࡔࡠࡇࡕࡖࡔࡘࡓࠨၮ"),pJFN7hOvyf6u4awTt9m231rjBYq,zz2tnLhI1QHV7GwFCrv5)
	return
def w9wMihtkIJ8fZQ(O6N8nhyYTD12KRApqkLzVi,filename=zA8Ry1KDvmr3w4B5xeP):
	uUqrNPcXKBoQ0slv.sleep(uulNDCPyef78(u"࠶࠮࠱࠴࠸ᐃ"))
	if jTDWgftK7NEmx0JAkOn2aRIvweq: O6N8nhyYTD12KRApqkLzVi = O6N8nhyYTD12KRApqkLzVi.encode(Tk9eH2qw6Brsuhj)
	if not filename: lDmQVa3oFnhqWcbSX = KfHAW8VGbrxi(u"ࠧࡴ࠼࡟ࡠ࠵࠶࠰࠱ࡧࡰࡥࡩࡥࠧၯ")+str(uUqrNPcXKBoQ0slv.time())+jL5CrsRwebpyDVXUc1EQP(u"ࠨ࠰ࡧࡥࡹ࠭ၰ")
	else: lDmQVa3oFnhqWcbSX = EE1jeHnIoad(u"ࠩࡶ࠾ࡡࡢ࠰࠱࠲࠳ࡩࡲࡧࡤࡠࠩၱ")+filename+vU6DxuzPwMpg(u"ࠪ࠲ࡩࡧࡴࠨၲ")
	open(lDmQVa3oFnhqWcbSX,s5WMHyQN4mpie(u"ࠫࡼࡨࠧၳ")).write(O6N8nhyYTD12KRApqkLzVi)
	return
def F0gSC4DoBWkRZvxJAperQqwO15df9y(vUTCBmuRD025KJ):
	if vUTCBmuRD025KJ:
		jERlJUwChexAXYk7yI = rIhXWK91vRuC(jUCABmLYMf0G,AAbvaXV2DQzfNHdm4U3tT(u"ࠬࡲࡩࡴࡶࠪၴ"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩၵ"),ssynAg0zhSkoCpOMDV9(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪၶ"))
		if jERlJUwChexAXYk7yI: return jERlJUwChexAXYk7yI
	zzekZcWL1sBgnoxN8f3vdQ0r = I4t9qonjrm.SITESURLS[ssynAg0zhSkoCpOMDV9(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨၷ")][KfHAW8VGbrxi(u"࠵ᐄ")]
	jewzZuNFibTO = ooNmbAs0RwxIG2ahd6(LhFAGlQ19zr) if not vUTCBmuRD025KJ else I4t9qonjrm.AV_CLIENT_IDS
	qIQCz90DuxjlYJ = YkdA7N1UeQbwfEtgV8i3ZaS6u95()
	PPf96YqGdatREx = qIQCz90DuxjlYJ.split(aOQTKXFL54Nl60Zhp3MbE(u"ࠩ࠯ࠫၸ"))[teaC5j4HuGDqpwcmUzJ]
	CXuvxyPDOl7Bwj = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(uugoLac4UGZztBeijxW1k0,sJw9QWiq1Kr0xfeVRI(u"ࠪࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩၹ"))
	RsgvFpZAzGiEh9J0Ob = wdfTiC18D4ZEpmSFNnOI()
	CfKjoYXSy1vwIBM4l9UDzb = {sJw9QWiq1Kr0xfeVRI(u"ࠫࡺࡹࡥࡳࠩၺ"):jewzZuNFibTO,FgXzMs0YSDt(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭ၻ"):KoxvjArhL1TdInDmN9s,oRJAfwD957WkUyBM1Ehu8m(u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧၼ"):PPf96YqGdatREx,oRJAfwD957WkUyBM1Ehu8m(u"ࠧࡪࡦࡶࠫၽ"):UAIXp7GJvrH64(RsgvFpZAzGiEh9J0Ob)}
	ND4YsIrucC = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠨࡒࡒࡗ࡙࠭ၾ"),zzekZcWL1sBgnoxN8f3vdQ0r,CfKjoYXSy1vwIBM4l9UDzb,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Gcw2nelTR864XCVruO3mAFqI5a(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡒࡗࡈࡗ࡙ࡏࡏࡏࡕ࠰࠵ࡸࡺࠧၿ"))
	jERlJUwChexAXYk7yI = []
	if ND4YsIrucC.succeeded:
		Vpnd4wgPqAO1j6z8N = ND4YsIrucC.content
		jERlJUwChexAXYk7yI = Vpnd4wgPqAO1j6z8N.replace(EE1jeHnIoad(u"ࠪࡠࡡࡸࠧႀ"),C0qrknitpM4Z).replace(FmYoGejTnwKME7d9zPc(u"ࠫࡡࡢ࡮ࠨႁ"),C0qrknitpM4Z).replace(ggjO5CrKVRPITaesWkxD(u"ࠬࡢࡲ࡝ࡰࠪႂ"),C0qrknitpM4Z).replace(FFkml6ZbgXD,C0qrknitpM4Z)
		jERlJUwChexAXYk7yI = EcQxOa3RJm86WjTKA.findall(s5WMHyQN4mpie(u"࠭ࡓࡕࡃࡕࡘ࠿ࡀࡓࡕࡃࡕࡘ࠿ࡀࠨ࡝ࡦ࠮࠭࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮ࡆࡐࡇ࠾࠿ࡋࡎࡅࠩႃ"),jERlJUwChexAXYk7yI,EcQxOa3RJm86WjTKA.DOTALL)
		if jERlJUwChexAXYk7yI:
			jERlJUwChexAXYk7yI = sorted(jERlJUwChexAXYk7yI,reverse=LhFAGlQ19zr,key=lambda key: int(key[D2D96X5NGamBhrFwvL8VEbqiSfZIl]))
			SXIxbZBW2zHeAV,jewzZuNFibTO,XZCwxtYWEcl8yqr9SHnG7,bb0r3L7XGeVihn,h3H4reNL8l26yPRtdKWg,iLXSma92HFtwhBKU = jERlJUwChexAXYk7yI[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			cyYeUj8I0BFL6XmMOEvitKZ = iLXSma92HFtwhBKU if AANCp8tEGTLriQgjB([s5WMHyQN4mpie(u"ࠧࡎࡖ࠳࠹ࡍ࡞࠰࡭ࡖࡗࡉࡋࡔࡓࡖࡐࡩ࡙ࡊ࡜ࡓࡔࡗ࠼ࡉ࡝࠭ႄ")])[D2D96X5NGamBhrFwvL8VEbqiSfZIl] else XZCwxtYWEcl8yqr9SHnG7
			OdiZIyCfDUsW3JBGR2VAb.setSetting(O3OVuapf0YFjbm5oUQDg(u"ࠨࡣࡹ࠲ࡵ࡫ࡲࡪࡱࡧ࠲࡮ࡴࡦࡰࡵࠪႅ"),cyYeUj8I0BFL6XmMOEvitKZ)
			tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,Hr25gta6XcqO(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬႆ"),SnhLjmfeJC(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭ႇ"),jERlJUwChexAXYk7yI,CQOaFUrZJHwKRxIj4yXEYs5V)
			OdiZIyCfDUsW3JBGR2VAb.setSetting(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ႈ"),UAIXp7GJvrH64(VySKdWnH3vNq6klQ))
	return jERlJUwChexAXYk7yI
def aBU0XMbiZA7sJ(B602U3dLlJYcm,sgFVJ9BHT4o378hvp6ARDbf=D2D96X5NGamBhrFwvL8VEbqiSfZIl,Amxjp0tr8gO3YDe1zBhMXJfiL6=D2D96X5NGamBhrFwvL8VEbqiSfZIl):
	if sgFVJ9BHT4o378hvp6ARDbf and not Amxjp0tr8gO3YDe1zBhMXJfiL6: Amxjp0tr8gO3YDe1zBhMXJfiL6 = len(B602U3dLlJYcm)//sgFVJ9BHT4o378hvp6ARDbf
	vDOEjadPJrq,b3b24XZTV7gW9mhcqLoCnftO,Cwod6vgFDhmk3QBTO7JNs25U = [],-BkM54Kr7Qbqn,D2D96X5NGamBhrFwvL8VEbqiSfZIl
	for Uuqa3wD8CR1G6 in B602U3dLlJYcm:
		if Cwod6vgFDhmk3QBTO7JNs25U%Amxjp0tr8gO3YDe1zBhMXJfiL6==D2D96X5NGamBhrFwvL8VEbqiSfZIl:
			b3b24XZTV7gW9mhcqLoCnftO += BkM54Kr7Qbqn
			vDOEjadPJrq.append([])
		vDOEjadPJrq[b3b24XZTV7gW9mhcqLoCnftO].append(Uuqa3wD8CR1G6)
		Cwod6vgFDhmk3QBTO7JNs25U += BkM54Kr7Qbqn
	return vDOEjadPJrq
def ZVvlrR4wKgdMx0z61isI(lDmQVa3oFnhqWcbSX,O6N8nhyYTD12KRApqkLzVi):
	GGCkYa7X603fZbDR = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(Xsc4lqOhdziToWvunbRNSQZKIY8E,lDmQVa3oFnhqWcbSX)
	if BkM54Kr7Qbqn or sJw9QWiq1Kr0xfeVRI(u"ࠬࡏࡐࡕࡘࡢࠫႉ") not in lDmQVa3oFnhqWcbSX or Hr25gta6XcqO(u"࠭ࡍ࠴ࡗࡢࠫႊ") not in lDmQVa3oFnhqWcbSX: YQDmGRx3CWc2HX9V0wa4O = str(O6N8nhyYTD12KRApqkLzVi)
	else:
		vDOEjadPJrq = aBU0XMbiZA7sJ(O6N8nhyYTD12KRApqkLzVi,FgXzMs0YSDt(u"࠹ᐅ"))
		YQDmGRx3CWc2HX9V0wa4O = fy8iFgEkrO12NR9TWBI35sjY6qHvV
		for rmU1G76ay8tLcPYfEHKTQlDF in vDOEjadPJrq:
			YQDmGRx3CWc2HX9V0wa4O += str(rmU1G76ay8tLcPYfEHKTQlDF)+ggjO5CrKVRPITaesWkxD(u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭ႋ")
		YQDmGRx3CWc2HX9V0wa4O = YQDmGRx3CWc2HX9V0wa4O.strip(sJw9QWiq1Kr0xfeVRI(u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧႌ"))
	E5Vtp0U1knK = iBlMjFR64kdK8IYepz2AyTs.compress(YQDmGRx3CWc2HX9V0wa4O)
	open(GGCkYa7X603fZbDR,EE1jeHnIoad(u"ࠩࡺࡦႍࠬ")).write(E5Vtp0U1knK)
	return
def P8DZUJoaHY53gl40GQm2Rz691V(T0T8IuhPj3Afl65VvRwQxFs,lDmQVa3oFnhqWcbSX):
	if T0T8IuhPj3Afl65VvRwQxFs==FmYoGejTnwKME7d9zPc(u"ࠪࡨ࡮ࡩࡴࠨႎ"): O6N8nhyYTD12KRApqkLzVi = {}
	elif T0T8IuhPj3Afl65VvRwQxFs==FmYoGejTnwKME7d9zPc(u"ࠫࡱ࡯ࡳࡵࠩႏ"): O6N8nhyYTD12KRApqkLzVi = []
	elif T0T8IuhPj3Afl65VvRwQxFs==vU6DxuzPwMpg(u"ࠬࡹࡴࡳࠩ႐"): O6N8nhyYTD12KRApqkLzVi = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	elif T0T8IuhPj3Afl65VvRwQxFs==N6NGJ4vpmidqMCh7yo(u"࠭ࡩ࡯ࡶࠪ႑"): O6N8nhyYTD12KRApqkLzVi = D2D96X5NGamBhrFwvL8VEbqiSfZIl
	else: O6N8nhyYTD12KRApqkLzVi = zA8Ry1KDvmr3w4B5xeP
	GGCkYa7X603fZbDR = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(Xsc4lqOhdziToWvunbRNSQZKIY8E,lDmQVa3oFnhqWcbSX)
	E5Vtp0U1knK = open(GGCkYa7X603fZbDR,FgXzMs0YSDt(u"ࠧࡳࡤࠪ႒")).read()
	YQDmGRx3CWc2HX9V0wa4O = iBlMjFR64kdK8IYepz2AyTs.decompress(E5Vtp0U1knK)
	if Gcw2nelTR864XCVruO3mAFqI5a(u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧ႓") not in YQDmGRx3CWc2HX9V0wa4O: O6N8nhyYTD12KRApqkLzVi = eval(YQDmGRx3CWc2HX9V0wa4O)
	else:
		vDOEjadPJrq = YQDmGRx3CWc2HX9V0wa4O.split(wdftVMyzF17cYETHu(u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨ႔"))
		del YQDmGRx3CWc2HX9V0wa4O
		O6N8nhyYTD12KRApqkLzVi = []
		JxeOgV9CEKlso0aSdbLp = Ui7X2Awte6o8J9QRV4kdsPmb()
		SXIxbZBW2zHeAV = D2D96X5NGamBhrFwvL8VEbqiSfZIl
		for rmU1G76ay8tLcPYfEHKTQlDF in vDOEjadPJrq:
			JxeOgV9CEKlso0aSdbLp.nSC4a3oWvwIyfd(str(SXIxbZBW2zHeAV),eval,rmU1G76ay8tLcPYfEHKTQlDF)
			SXIxbZBW2zHeAV += BkM54Kr7Qbqn
		del vDOEjadPJrq
		JxeOgV9CEKlso0aSdbLp.prR37bKVMsueglqzY6hGfdSaEIcQUX()
		JxeOgV9CEKlso0aSdbLp.hi8G5ZRcxNadr4elILUoqy3()
		VV9NqA6Ixd0TuMW = list(JxeOgV9CEKlso0aSdbLp.resultsDICT.keys())
		ujgh5w3oPIWQGcSsz0arUYn9yXxKHR = sorted(VV9NqA6Ixd0TuMW,reverse=LhFAGlQ19zr,key=lambda key: int(key))
		for SXIxbZBW2zHeAV in ujgh5w3oPIWQGcSsz0arUYn9yXxKHR:
			O6N8nhyYTD12KRApqkLzVi += JxeOgV9CEKlso0aSdbLp.resultsDICT[SXIxbZBW2zHeAV]
	return O6N8nhyYTD12KRApqkLzVi
def KLp8NGYrVRnZtu7CSg92(SZvQ0Jre4BHyGVFxoPYM2IU6):
	ccqysoRFVdzamENPb9O8xQgG = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(ywEBSl6zHMFsO4Qmh3TJP8itgj,aOQTKXFL54Nl60Zhp3MbE(u"ࠪࡥࡩࡪ࡯࡯ࡵࠪ႕"),SZvQ0Jre4BHyGVFxoPYM2IU6,N6NGJ4vpmidqMCh7yo(u"ࠫࡦࡪࡤࡰࡰ࠱ࡼࡲࡲࠧ႖"))
	try: YNCwFkcBA3xO = open(ccqysoRFVdzamENPb9O8xQgG,Hr25gta6XcqO(u"ࠬࡸࡢࠨ႗")).read()
	except:
		h7MxBq695sjJZyzKlAC4v = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(uh7IyG2XsL9DKZOlYQ03jWpbq8Hm,N6NGJ4vpmidqMCh7yo(u"࠭ࡡࡥࡦࡲࡲࡸ࠭႘"),SZvQ0Jre4BHyGVFxoPYM2IU6,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧࡢࡦࡧࡳࡳ࠴ࡸ࡮࡮ࠪ႙"))
		try: YNCwFkcBA3xO = open(h7MxBq695sjJZyzKlAC4v,EE1jeHnIoad(u"ࠨࡴࡥࠫႚ")).read()
		except: return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[]
	if jTDWgftK7NEmx0JAkOn2aRIvweq: YNCwFkcBA3xO = YNCwFkcBA3xO.decode(Tk9eH2qw6Brsuhj)
	fA9XCFueV0kdl6gEn5LSmcI7Ub = EcQxOa3RJm86WjTKA.findall(wdftVMyzF17cYETHu(u"ࠩ࡬ࡨࡂ࠴ࠪࡀࡸࡨࡶࡸ࡯࡯࡯࠿࡞ࡠࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࠤ࡟ࠫࡢ࠭ႛ"),YNCwFkcBA3xO,EcQxOa3RJm86WjTKA.DOTALL|EcQxOa3RJm86WjTKA.IGNORECASE)
	if not fA9XCFueV0kdl6gEn5LSmcI7Ub: return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[]
	inepCKGoM5NmfQjYxU6FqDsAw19g4,qqdwDcBZYEX = fA9XCFueV0kdl6gEn5LSmcI7Ub[D2D96X5NGamBhrFwvL8VEbqiSfZIl],szWVcgPdT2CYH4Nka153hb(fA9XCFueV0kdl6gEn5LSmcI7Ub[D2D96X5NGamBhrFwvL8VEbqiSfZIl])
	return inepCKGoM5NmfQjYxU6FqDsAw19g4,qqdwDcBZYEX
def XRCk507baSlQucB63W():
	KjcD74L6OBxGVqRnblpHPX5usYmd2y = rIhXWK91vRuC(jUCABmLYMf0G,QjAINyUC7MDRq5d8e4vl9(u"ࠪࡨ࡮ࡩࡴࠨႜ"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧႝ"),ggjO5CrKVRPITaesWkxD(u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭႞"))
	if KjcD74L6OBxGVqRnblpHPX5usYmd2y: return KjcD74L6OBxGVqRnblpHPX5usYmd2y
	eCKUHdutMbwaGIgLxQDZc51Sm,KjcD74L6OBxGVqRnblpHPX5usYmd2y = {},{}
	OxdaGKn62ICq7jF8pPWcgE901UV = [I4t9qonjrm.SITESURLS[jL5CrsRwebpyDVXUc1EQP(u"࠭ࡒࡆࡒࡒࡗࠬ႟")][D2D96X5NGamBhrFwvL8VEbqiSfZIl]]
	if FpjKBIUaEwbmLkxANfs>I18uSKaWhgTBeYUPD4sr(u"࠳࠺࠲࠾࠿ᐆ"): OxdaGKn62ICq7jF8pPWcgE901UV.append(I4t9qonjrm.SITESURLS[N6NGJ4vpmidqMCh7yo(u"ࠧࡓࡇࡓࡓࡘ࠭Ⴀ")][BkM54Kr7Qbqn])
	if jTDWgftK7NEmx0JAkOn2aRIvweq: OxdaGKn62ICq7jF8pPWcgE901UV.append(I4t9qonjrm.SITESURLS[oRJAfwD957WkUyBM1Ehu8m(u"ࠨࡔࡈࡔࡔ࡙ࠧႡ")][teaC5j4HuGDqpwcmUzJ])
	for yHejo204TuRvmr6g in OxdaGKn62ICq7jF8pPWcgE901UV:
		ND4YsIrucC = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠩࡊࡉ࡙࠭Ⴂ"),yHejo204TuRvmr6g,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,FmYoGejTnwKME7d9zPc(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡁࡅࡡࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎ࠰࠵ࡸࡺࠧႣ"))
		if ND4YsIrucC.succeeded:
			Vpnd4wgPqAO1j6z8N = ND4YsIrucC.content
			ro54Eemyaf8WX = yHejo204TuRvmr6g.rsplit(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠫ࠴࠭Ⴄ"),Gcw2nelTR864XCVruO3mAFqI5a(u"࠴ᐇ"))[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			EE7XkgHLt6qxRcIn9 = EcQxOa3RJm86WjTKA.findall(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬ࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻ࡫ࡲࡴ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭Ⴅ"),Vpnd4wgPqAO1j6z8N,EcQxOa3RJm86WjTKA.DOTALL|EcQxOa3RJm86WjTKA.IGNORECASE)
			for SZvQ0Jre4BHyGVFxoPYM2IU6,rrOF3WMqDyUHQGzXn5A0RdfgikE in EE7XkgHLt6qxRcIn9:
				sbNi2gvoHqR1GPn4KQZ = ro54Eemyaf8WX+wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭࠯ࠨႦ")+SZvQ0Jre4BHyGVFxoPYM2IU6+N6NGJ4vpmidqMCh7yo(u"ࠧ࠰ࠩႧ")+SZvQ0Jre4BHyGVFxoPYM2IU6+s5WMHyQN4mpie(u"ࠨ࠯ࠪႨ")+rrOF3WMqDyUHQGzXn5A0RdfgikE+FmYoGejTnwKME7d9zPc(u"ࠩ࠱ࡾ࡮ࡶࠧႩ")
				if SZvQ0Jre4BHyGVFxoPYM2IU6 not in list(eCKUHdutMbwaGIgLxQDZc51Sm.keys()):
					eCKUHdutMbwaGIgLxQDZc51Sm[SZvQ0Jre4BHyGVFxoPYM2IU6] = []
					KjcD74L6OBxGVqRnblpHPX5usYmd2y[SZvQ0Jre4BHyGVFxoPYM2IU6] = []
				w3YsgpJeaIQHD48c1xPrFnduk6R = szWVcgPdT2CYH4Nka153hb(rrOF3WMqDyUHQGzXn5A0RdfgikE)
				eCKUHdutMbwaGIgLxQDZc51Sm[SZvQ0Jre4BHyGVFxoPYM2IU6].append((rrOF3WMqDyUHQGzXn5A0RdfgikE,w3YsgpJeaIQHD48c1xPrFnduk6R,sbNi2gvoHqR1GPn4KQZ))
	for SZvQ0Jre4BHyGVFxoPYM2IU6 in list(eCKUHdutMbwaGIgLxQDZc51Sm.keys()):
		KjcD74L6OBxGVqRnblpHPX5usYmd2y[SZvQ0Jre4BHyGVFxoPYM2IU6] = sorted(eCKUHdutMbwaGIgLxQDZc51Sm[SZvQ0Jre4BHyGVFxoPYM2IU6],reverse=EsCplGc5N4mBuYW0RVQt6b,key=lambda key: key[BkM54Kr7Qbqn])
	tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,sIzDXlTHYUC5L3xZGnr(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭Ⴊ"),ggjO5CrKVRPITaesWkxD(u"ࠫࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐࠬႫ"),KjcD74L6OBxGVqRnblpHPX5usYmd2y,CQOaFUrZJHwKRxIj4yXEYs5V)
	return KjcD74L6OBxGVqRnblpHPX5usYmd2y
def szWVcgPdT2CYH4Nka153hb(rrOF3WMqDyUHQGzXn5A0RdfgikE):
	w3YsgpJeaIQHD48c1xPrFnduk6R = []
	jATs4xyXeEWSmrGIH = rrOF3WMqDyUHQGzXn5A0RdfgikE.split(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠬ࠴ࠧႬ"))
	for P5tnoSMIeLpiGNBDQd in jATs4xyXeEWSmrGIH:
		hK8O6JCilepk9Rw0z5VGFPQ = EcQxOa3RJm86WjTKA.findall(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠭࡜ࡥ࠭ࡿ࡟ࡡ࠱࡜࠮ࡣ࠰ࡾࡆ࠳࡚࡞࠭ࠪႭ"),P5tnoSMIeLpiGNBDQd,EcQxOa3RJm86WjTKA.DOTALL)
		I2G7Yw6VyE49uHhe8fCdvPj = []
		for MMKrRf1ceTabkOu0 in hK8O6JCilepk9Rw0z5VGFPQ:
			if MMKrRf1ceTabkOu0.isdigit(): MMKrRf1ceTabkOu0 = int(MMKrRf1ceTabkOu0)
			I2G7Yw6VyE49uHhe8fCdvPj.append(MMKrRf1ceTabkOu0)
		w3YsgpJeaIQHD48c1xPrFnduk6R.append(I2G7Yw6VyE49uHhe8fCdvPj)
	return w3YsgpJeaIQHD48c1xPrFnduk6R
def kygv0dJIZmh7TCYsAQ6D4c(w3YsgpJeaIQHD48c1xPrFnduk6R):
	rrOF3WMqDyUHQGzXn5A0RdfgikE = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	for P5tnoSMIeLpiGNBDQd in w3YsgpJeaIQHD48c1xPrFnduk6R:
		for MMKrRf1ceTabkOu0 in P5tnoSMIeLpiGNBDQd: rrOF3WMqDyUHQGzXn5A0RdfgikE += str(MMKrRf1ceTabkOu0)
		rrOF3WMqDyUHQGzXn5A0RdfgikE += N6NGJ4vpmidqMCh7yo(u"ࠧ࠯ࠩႮ")
	rrOF3WMqDyUHQGzXn5A0RdfgikE = rrOF3WMqDyUHQGzXn5A0RdfgikE.strip(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠨ࠰ࠪႯ"))
	return rrOF3WMqDyUHQGzXn5A0RdfgikE
def cDVaL376lmoAX(bG6rH7snANpDE):
	oSiV9K6kg3pRXF07Q = {}
	eCKUHdutMbwaGIgLxQDZc51Sm = XRCk507baSlQucB63W()
	acywAU3zkWCTEMf27ZYuQb50ntBi = vhV48zIDAUwyakxtndGRNj9(bG6rH7snANpDE)
	for SZvQ0Jre4BHyGVFxoPYM2IU6 in bG6rH7snANpDE:
		if SZvQ0Jre4BHyGVFxoPYM2IU6 not in list(eCKUHdutMbwaGIgLxQDZc51Sm.keys()): continue
		KjcD74L6OBxGVqRnblpHPX5usYmd2y = eCKUHdutMbwaGIgLxQDZc51Sm[SZvQ0Jre4BHyGVFxoPYM2IU6]
		RG61qOh52JP8kKIijxafHStg7Z3,Os3l9VdgEDyZamkn0HrSLW,wwA7OjHhazmqcQ6Z2DgB = KjcD74L6OBxGVqRnblpHPX5usYmd2y[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		dWkcumbLjr5AJzhIpavnowiqFZV,hhsgbw3fIeoRBELrnQucMGtTSpNXzx = KLp8NGYrVRnZtu7CSg92(SZvQ0Jre4BHyGVFxoPYM2IU6)
		uuU5dEvGBKnO2lJCtIFbxkqQi06g,XcMGsyPBSJqr35bpwke2jQY = acywAU3zkWCTEMf27ZYuQb50ntBi[SZvQ0Jre4BHyGVFxoPYM2IU6]
		oNsf8bLg9AqlOcEvSexRhCQ = Os3l9VdgEDyZamkn0HrSLW>hhsgbw3fIeoRBELrnQucMGtTSpNXzx and uuU5dEvGBKnO2lJCtIFbxkqQi06g
		AAkZvIgX4hcfMWtbK = EsCplGc5N4mBuYW0RVQt6b
		if not uuU5dEvGBKnO2lJCtIFbxkqQi06g: qscWmMdJP32fie5Hb6g47XC = PlpyFa9QMKXxOD1cvHzmI(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪႰ")
		elif not XcMGsyPBSJqr35bpwke2jQY: qscWmMdJP32fie5Hb6g47XC = uulNDCPyef78(u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬႱ")
		elif oNsf8bLg9AqlOcEvSexRhCQ: qscWmMdJP32fie5Hb6g47XC = EE1jeHnIoad(u"ࠫࡴࡲࡤࠨႲ")
		else:
			qscWmMdJP32fie5Hb6g47XC = wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠬ࡭࡯ࡰࡦࠪႳ")
			AAkZvIgX4hcfMWtbK = LhFAGlQ19zr
		oSiV9K6kg3pRXF07Q[SZvQ0Jre4BHyGVFxoPYM2IU6] = AAkZvIgX4hcfMWtbK,dWkcumbLjr5AJzhIpavnowiqFZV,hhsgbw3fIeoRBELrnQucMGtTSpNXzx,RG61qOh52JP8kKIijxafHStg7Z3,Os3l9VdgEDyZamkn0HrSLW,qscWmMdJP32fie5Hb6g47XC,wwA7OjHhazmqcQ6Z2DgB
	return oSiV9K6kg3pRXF07Q
def Hnrjh7smUIGq3RgDy19CL(ua2GNHKeh94QJSd,wDYgkQEK0Gro,fjFVYCTa9Ao2z5=fy8iFgEkrO12NR9TWBI35sjY6qHvV,ngsUmJi3pwl8uTB5PyN71=fy8iFgEkrO12NR9TWBI35sjY6qHvV,i8dUGHmpgP2eJcot=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if gZlSEJaXO9F461AL3sR7rWNpqf: ua2GNHKeh94QJSd.update(wDYgkQEK0Gro,fjFVYCTa9Ao2z5,ngsUmJi3pwl8uTB5PyN71,i8dUGHmpgP2eJcot)
	else: ua2GNHKeh94QJSd.update(wDYgkQEK0Gro,fjFVYCTa9Ao2z5+C0qrknitpM4Z+ngsUmJi3pwl8uTB5PyN71+C0qrknitpM4Z+i8dUGHmpgP2eJcot)
	return
def sO08q1xvolnpguK4CDIQ9dk3j6L(CDwfqFKj3u5s64JgANQTX2RLElkz):
	def TaNZnIDpx4MlA(M3MRzSack4h,G6A0ofqSmv4Lx7wsN8IC,BOQqcGvw5kxrJgIHf=Hr25gta6XcqO(u"ࠨ࠰࠲࠴࠶࠸࠺࠼࠷࠹࠻ࡤࡦࡨࡪࡥࡧࡩ࡫࡭࡯ࡱ࡬࡮ࡰࡲࡴࡶࡸࡳࡵࡷࡹࡻࡽࡿࡺࡂࡄࡆࡈࡊࡌࡇࡉࡋࡍࡏࡑࡓࡎࡐࡒࡔࡖࡘ࡚ࡕࡗ࡙࡛࡝࡟ࠨႴ")):
		return ((M3MRzSack4h == D2D96X5NGamBhrFwvL8VEbqiSfZIl) and BOQqcGvw5kxrJgIHf[D2D96X5NGamBhrFwvL8VEbqiSfZIl]) or (TaNZnIDpx4MlA(M3MRzSack4h // G6A0ofqSmv4Lx7wsN8IC, G6A0ofqSmv4Lx7wsN8IC, BOQqcGvw5kxrJgIHf).lstrip(BOQqcGvw5kxrJgIHf[D2D96X5NGamBhrFwvL8VEbqiSfZIl]) + BOQqcGvw5kxrJgIHf[M3MRzSack4h % G6A0ofqSmv4Lx7wsN8IC])
	def qHaXYFkn725(UnIcxpV3kti1waNrj9fol8, E92E0SJiFO3vnodyP1B, kRJ1Vcs2N9, QfX7HmPn691orZLy0VBSwsdlNGu, SSR4TApyaFD=zA8Ry1KDvmr3w4B5xeP, tDzBPWiUEAhnX5CyGKYLq=zA8Ry1KDvmr3w4B5xeP, rMiVDnQFbeC61ZgRJT32BocIjP=zA8Ry1KDvmr3w4B5xeP):
		while (kRJ1Vcs2N9):
			kRJ1Vcs2N9-=EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠵ᐈ")
			if (QfX7HmPn691orZLy0VBSwsdlNGu[kRJ1Vcs2N9]): UnIcxpV3kti1waNrj9fol8 = EcQxOa3RJm86WjTKA.sub(sJw9QWiq1Kr0xfeVRI(u"ࠢ࡝࡞ࡥࠦႵ") + TaNZnIDpx4MlA(kRJ1Vcs2N9, E92E0SJiFO3vnodyP1B) + KfHAW8VGbrxi(u"ࠣ࡞࡟ࡦࠧႶ"),  QfX7HmPn691orZLy0VBSwsdlNGu[kRJ1Vcs2N9], UnIcxpV3kti1waNrj9fol8)
		return UnIcxpV3kti1waNrj9fol8
	CDwfqFKj3u5s64JgANQTX2RLElkz = CDwfqFKj3u5s64JgANQTX2RLElkz.split(ggjO5CrKVRPITaesWkxD(u"ࠩࢀࠬࠬႷ"))[BkM54Kr7Qbqn]
	CDwfqFKj3u5s64JgANQTX2RLElkz = CDwfqFKj3u5s64JgANQTX2RLElkz.rsplit(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪࡷࡵࡲࡩࡵࠩႸ"))[D2D96X5NGamBhrFwvL8VEbqiSfZIl]+FgXzMs0YSDt(u"ࠦࡸࡶ࡬ࡪࡶࠫࠫࢁ࠭ࠩࠪࠤႹ")
	p49VlrNTy3WF = eval(CsDcLqQUVK4YBvHFW1(u"ࠬࡻ࡮ࡱࡣࡦ࡯࠭࠭Ⴚ")+CDwfqFKj3u5s64JgANQTX2RLElkz,{FgXzMs0YSDt(u"࠭ࡢࡢࡵࡨࡒࠬႻ"):TaNZnIDpx4MlA,FgXzMs0YSDt(u"ࠧࡶࡰࡳࡥࡨࡱࠧႼ"):qHaXYFkn725})
	return p49VlrNTy3WF
def NNSLyeFBOc(code):
	_AD7n53pUsi=oRJAfwD957WkUyBM1Ehu8m(u"ࠣ࠲࠴࠶࠸࠺࠵࠷࠹࠻࠽ࡦࡨࡣࡥࡧࡩ࡫࡭࡯ࡪ࡬࡮ࡰࡲࡴࡶࡱࡳࡵࡷࡹࡻࡽࡸࡺࡼࡄࡆࡈࡊࡅࡇࡉࡋࡍࡏࡑࡌࡎࡐࡒࡔࡖࡘࡓࡕࡗ࡙࡛࡝࡟࡚ࠬ࠱ࠥႽ")
	def KTUrEogdjqPh08VskWa(tDzBPWiUEAhnX5CyGKYLq,SSR4TApyaFD,tt4YjlgsEFoGIDKJpzciUkPW9T):
		IpAzTxHfZyDgYrkeubROL7oU1c5 = list(_AD7n53pUsi)
		OEknw4AvgBTx5j = IpAzTxHfZyDgYrkeubROL7oU1c5[Hr25gta6XcqO(u"࠵ᐉ"):SSR4TApyaFD]
		pk6YWixXFSrDLKCnlN39w = IpAzTxHfZyDgYrkeubROL7oU1c5[I18uSKaWhgTBeYUPD4sr(u"࠶ᐊ"):tt4YjlgsEFoGIDKJpzciUkPW9T]
		tDzBPWiUEAhnX5CyGKYLq = list(tDzBPWiUEAhnX5CyGKYLq)[::-uulNDCPyef78(u"࠱ᐋ")]
		PK4ZaDWHlivtVdBMoexgzyUTf = O3OVuapf0YFjbm5oUQDg(u"࠱ᐌ")
		for kRJ1Vcs2N9,G6A0ofqSmv4Lx7wsN8IC in enumerate(tDzBPWiUEAhnX5CyGKYLq):
			if G6A0ofqSmv4Lx7wsN8IC in OEknw4AvgBTx5j: PK4ZaDWHlivtVdBMoexgzyUTf = PK4ZaDWHlivtVdBMoexgzyUTf + OEknw4AvgBTx5j.index(G6A0ofqSmv4Lx7wsN8IC)*SSR4TApyaFD**kRJ1Vcs2N9
		QfX7HmPn691orZLy0VBSwsdlNGu = FgXzMs0YSDt(u"ࠤࠥႾ")
		while PK4ZaDWHlivtVdBMoexgzyUTf > C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠲ᐍ"):
			QfX7HmPn691orZLy0VBSwsdlNGu = pk6YWixXFSrDLKCnlN39w[PK4ZaDWHlivtVdBMoexgzyUTf%tt4YjlgsEFoGIDKJpzciUkPW9T] + QfX7HmPn691orZLy0VBSwsdlNGu
			PK4ZaDWHlivtVdBMoexgzyUTf = (PK4ZaDWHlivtVdBMoexgzyUTf - (PK4ZaDWHlivtVdBMoexgzyUTf%tt4YjlgsEFoGIDKJpzciUkPW9T))//tt4YjlgsEFoGIDKJpzciUkPW9T
		return int(QfX7HmPn691orZLy0VBSwsdlNGu) or ggjO5CrKVRPITaesWkxD(u"࠳ᐎ")
	def VCIEohm8qlLkMwdFizASG7gPJc(OEknw4AvgBTx5j,u,KYFW0Cq4HP7TXAnO2a1mL3g9s8yVk,UDP7KHbM3GJlA0z9iC,SSR4TApyaFD,rMiVDnQFbeC61ZgRJT32BocIjP):
		rMiVDnQFbeC61ZgRJT32BocIjP = OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠥࠦႿ");
		pk6YWixXFSrDLKCnlN39w = Gcw2nelTR864XCVruO3mAFqI5a(u"࠴ᐏ")
		while pk6YWixXFSrDLKCnlN39w < len(OEknw4AvgBTx5j):
			PK4ZaDWHlivtVdBMoexgzyUTf = vU6DxuzPwMpg(u"࠵ᐐ")
			LLyowdJ5jAhZu2mfcU6kS94xFnPWz = SnhLjmfeJC(u"ࠦࠧჀ")
			while OEknw4AvgBTx5j[pk6YWixXFSrDLKCnlN39w] is not KYFW0Cq4HP7TXAnO2a1mL3g9s8yVk[SSR4TApyaFD]:
				LLyowdJ5jAhZu2mfcU6kS94xFnPWz = fy8iFgEkrO12NR9TWBI35sjY6qHvV.join([LLyowdJ5jAhZu2mfcU6kS94xFnPWz,OEknw4AvgBTx5j[pk6YWixXFSrDLKCnlN39w]])
				pk6YWixXFSrDLKCnlN39w = pk6YWixXFSrDLKCnlN39w + wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠷ᐑ")
			while PK4ZaDWHlivtVdBMoexgzyUTf < len(KYFW0Cq4HP7TXAnO2a1mL3g9s8yVk):
				LLyowdJ5jAhZu2mfcU6kS94xFnPWz = LLyowdJ5jAhZu2mfcU6kS94xFnPWz.replace(KYFW0Cq4HP7TXAnO2a1mL3g9s8yVk[PK4ZaDWHlivtVdBMoexgzyUTf],str(PK4ZaDWHlivtVdBMoexgzyUTf))
				PK4ZaDWHlivtVdBMoexgzyUTf = PK4ZaDWHlivtVdBMoexgzyUTf + O3OVuapf0YFjbm5oUQDg(u"࠱ᐒ")
			rMiVDnQFbeC61ZgRJT32BocIjP = fy8iFgEkrO12NR9TWBI35sjY6qHvV.join([rMiVDnQFbeC61ZgRJT32BocIjP,fy8iFgEkrO12NR9TWBI35sjY6qHvV.join(map(chr, [KTUrEogdjqPh08VskWa(LLyowdJ5jAhZu2mfcU6kS94xFnPWz,SSR4TApyaFD,FgXzMs0YSDt(u"࠲࠲ᐓ")) - UDP7KHbM3GJlA0z9iC]))])
			pk6YWixXFSrDLKCnlN39w = pk6YWixXFSrDLKCnlN39w + Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠳ᐔ")
		return rMiVDnQFbeC61ZgRJT32BocIjP
	code = code.replace(oRJAfwD957WkUyBM1Ehu8m(u"ࠬࡢ࡮ࠨჁ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(Gcw2nelTR864XCVruO3mAFqI5a(u"࠭࡜ࡳࠩჂ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	riJRp35ysuHaqFj2 = EcQxOa3RJm86WjTKA.findall(SnhLjmfeJC(u"ࠧ࡝ࡿ࡟ࠬࠧ࠮࡜ࡸ࠭ࠬࠦ࠱࠮࡜ࡥ࠭ࠬ࠰ࠧ࠮࡜ࡸ࠭ࠬࠦ࠱࠮࡜ࡥ࠭ࠬ࠰࠭ࡢࡤࠬࠫ࠯ࠬࡡࡪࠫࠪ࡞ࠬࡠ࠮࠭Ⴣ"),code,EcQxOa3RJm86WjTKA.DOTALL)
	if riJRp35ysuHaqFj2:
		riJRp35ysuHaqFj2 = list(riJRp35ysuHaqFj2[O3OVuapf0YFjbm5oUQDg(u"࠳ᐕ")])
		for WW7YfJF9sOhl0mzDiocSQCqkAxNuU,code in enumerate(riJRp35ysuHaqFj2):
			if code.isdigit(): riJRp35ysuHaqFj2[WW7YfJF9sOhl0mzDiocSQCqkAxNuU] = int(code)
			else: riJRp35ysuHaqFj2[WW7YfJF9sOhl0mzDiocSQCqkAxNuU] = code.replace(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠨ࡞ࠥࠫჄ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		isAoIhU5LmFxGbNjw = VCIEohm8qlLkMwdFizASG7gPJc(*riJRp35ysuHaqFj2)
		return isAoIhU5LmFxGbNjw
	return fy8iFgEkrO12NR9TWBI35sjY6qHvV
def YYsrdwRtJlpCamhz6SEHibg(zzekZcWL1sBgnoxN8f3vdQ0r,bhglT28eNAQuoxiCyOMBH=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if bhglT28eNAQuoxiCyOMBH==wdftVMyzF17cYETHu(u"ࠩ࡯ࡳࡼ࡫ࡲࠨჅ"): zzekZcWL1sBgnoxN8f3vdQ0r = EcQxOa3RJm86WjTKA.sub(wdftVMyzF17cYETHu(u"ࡵࠫࠪࡡ࠰࠮࠻ࡄ࠱࡟ࡣࡻ࠳ࡿࠪ჆"),lambda tgoeb9sZ8PiDmCIu: tgoeb9sZ8PiDmCIu.group(D2D96X5NGamBhrFwvL8VEbqiSfZIl).lower(),zzekZcWL1sBgnoxN8f3vdQ0r)
	elif bhglT28eNAQuoxiCyOMBH==sIzDXlTHYUC5L3xZGnr(u"ࠫࡺࡶࡰࡦࡴࠪჇ"): zzekZcWL1sBgnoxN8f3vdQ0r = EcQxOa3RJm86WjTKA.sub(FmYoGejTnwKME7d9zPc(u"ࡷ࠭ࠥ࡜࠲࠰࠽ࡦ࠳ࡺ࡞ࡽ࠵ࢁࠬ჈"),lambda tgoeb9sZ8PiDmCIu: tgoeb9sZ8PiDmCIu.group(D2D96X5NGamBhrFwvL8VEbqiSfZIl).upper(),zzekZcWL1sBgnoxN8f3vdQ0r)
	return zzekZcWL1sBgnoxN8f3vdQ0r
def vhV48zIDAUwyakxtndGRNj9(bG6rH7snANpDE):
	SdW2EK1iCwAY67I3PJOHBX0Vg,G8pwQufXhSy = LhFAGlQ19zr,LhFAGlQ19zr
	vvPmnHekOc7qrjidMwxf134VD = GUpSgLmFJc2T5B6DRxtlN9KXHIYP.connect(al4SYe7CV19g)
	vvPmnHekOc7qrjidMwxf134VD.text_factory = str
	aaLcdPtZmTG4ir = vvPmnHekOc7qrjidMwxf134VD.cursor()
	if len(bG6rH7snANpDE)==BkM54Kr7Qbqn: ddtNfQR18qSU9zjIpa = FmYoGejTnwKME7d9zPc(u"࠭ࠨࠣࠩ჉")+bG6rH7snANpDE[D2D96X5NGamBhrFwvL8VEbqiSfZIl]+Hr25gta6XcqO(u"ࠧࠣࠫࠪ჊")
	else: ddtNfQR18qSU9zjIpa = str(tuple(bG6rH7snANpDE))
	aaLcdPtZmTG4ir.execute(KfHAW8VGbrxi(u"ࠨࡕࡈࡐࡊࡉࡔࠡࡣࡧࡨࡴࡴࡉࡅ࠮ࡨࡲࡦࡨ࡬ࡦࡦࠣࡊࡗࡕࡍࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡎࡔࠠࠨ჋")+ddtNfQR18qSU9zjIpa+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠩࠣ࠿ࠬ჌"))
	munF8zxEdJ3 = aaLcdPtZmTG4ir.fetchall()
	vvPmnHekOc7qrjidMwxf134VD.commit()
	vvPmnHekOc7qrjidMwxf134VD.close()
	acywAU3zkWCTEMf27ZYuQb50ntBi = {}
	for SZvQ0Jre4BHyGVFxoPYM2IU6 in bG6rH7snANpDE: acywAU3zkWCTEMf27ZYuQb50ntBi[SZvQ0Jre4BHyGVFxoPYM2IU6] = (LhFAGlQ19zr,LhFAGlQ19zr)
	for SZvQ0Jre4BHyGVFxoPYM2IU6,G8pwQufXhSy in munF8zxEdJ3:
		SdW2EK1iCwAY67I3PJOHBX0Vg = EsCplGc5N4mBuYW0RVQt6b
		G8pwQufXhSy = G8pwQufXhSy==BkM54Kr7Qbqn
		acywAU3zkWCTEMf27ZYuQb50ntBi[SZvQ0Jre4BHyGVFxoPYM2IU6] = (SdW2EK1iCwAY67I3PJOHBX0Vg,G8pwQufXhSy)
	return acywAU3zkWCTEMf27ZYuQb50ntBi
def mJE8eLQqtMC9Io6sfHnBKjiDzPwvy(HEj7vrQguL8S5ydIcUwF2kNG6PJ4):
	OmsWt89dSA5HyCZ4wL = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.exists(HEj7vrQguL8S5ydIcUwF2kNG6PJ4):
		Br3eWJF76pCwXcOhuL9EtdMmIN0 = open(HEj7vrQguL8S5ydIcUwF2kNG6PJ4,s5WMHyQN4mpie(u"ࠪࡶࡧ࠭Ⴭ")).read()
		if jTDWgftK7NEmx0JAkOn2aRIvweq: Br3eWJF76pCwXcOhuL9EtdMmIN0 = Br3eWJF76pCwXcOhuL9EtdMmIN0.decode(Tk9eH2qw6Brsuhj)
		ThYqLZFzacNJvCjS28 = LB7TcZnGYdfw5lWU1RH3Oztu9PyA(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠫࡩ࡯ࡣࡵࠩ჎"),Br3eWJF76pCwXcOhuL9EtdMmIN0)
		if ThYqLZFzacNJvCjS28:
			OmsWt89dSA5HyCZ4wL = {}
			for tLsNIYkDoSAcp6wrq in ThYqLZFzacNJvCjS28.keys():
				OmsWt89dSA5HyCZ4wL[tLsNIYkDoSAcp6wrq] = []
				for eeU9cCB6bJP72FojqvsT4WSZkzEgr in ThYqLZFzacNJvCjS28[tLsNIYkDoSAcp6wrq]:
					ZJqDh4ByGPQn13tlzMOTLCNdcugx,ekV6UX5gBZsaLHvOMCPF,zzekZcWL1sBgnoxN8f3vdQ0r,mmocwN1frQJ5ST3xa,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
					ZJqDh4ByGPQn13tlzMOTLCNdcugx = eeU9cCB6bJP72FojqvsT4WSZkzEgr[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
					ekV6UX5gBZsaLHvOMCPF = eeU9cCB6bJP72FojqvsT4WSZkzEgr[BkM54Kr7Qbqn]
					ekV6UX5gBZsaLHvOMCPF = zrVdcHAuj5Yak2iNQ08EMbwXCZ(ekV6UX5gBZsaLHvOMCPF)
					zzekZcWL1sBgnoxN8f3vdQ0r = eeU9cCB6bJP72FojqvsT4WSZkzEgr[teaC5j4HuGDqpwcmUzJ]
					mmocwN1frQJ5ST3xa = eeU9cCB6bJP72FojqvsT4WSZkzEgr[XW57OCeGnFTLQbaqdrD9zM]
					mmEsSwOKazXLV1MT = eeU9cCB6bJP72FojqvsT4WSZkzEgr[vD4Fh6ictZ7wME]
					jmI9qRnVJo2a3tpcH8gfYkP = eeU9cCB6bJP72FojqvsT4WSZkzEgr[OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠹ᐖ")]
					if len(eeU9cCB6bJP72FojqvsT4WSZkzEgr)>aOQTKXFL54Nl60Zhp3MbE(u"࠻ᐗ"): YQDmGRx3CWc2HX9V0wa4O = eeU9cCB6bJP72FojqvsT4WSZkzEgr[aOQTKXFL54Nl60Zhp3MbE(u"࠻ᐗ")]
					if len(eeU9cCB6bJP72FojqvsT4WSZkzEgr)>QjAINyUC7MDRq5d8e4vl9(u"࠽ᐘ"): vBs70HtgMbzd6n3NwUpxe = eeU9cCB6bJP72FojqvsT4WSZkzEgr[QjAINyUC7MDRq5d8e4vl9(u"࠽ᐘ")]
					if len(eeU9cCB6bJP72FojqvsT4WSZkzEgr)>wdftVMyzF17cYETHu(u"࠸ᐙ"): Q1q840Lz62ZxYGCEaRbjtuAFS7siW = eeU9cCB6bJP72FojqvsT4WSZkzEgr[wdftVMyzF17cYETHu(u"࠸ᐙ")]
					if HEj7vrQguL8S5ydIcUwF2kNG6PJ4==mmFzNZYEJpdqUro7sKMj6W2: dw3rhvuZUHY0IQ4Deqa6Px = ZJqDh4ByGPQn13tlzMOTLCNdcugx,ekV6UX5gBZsaLHvOMCPF,zzekZcWL1sBgnoxN8f3vdQ0r,mmocwN1frQJ5ST3xa,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Q1q840Lz62ZxYGCEaRbjtuAFS7siW
					else: dw3rhvuZUHY0IQ4Deqa6Px = ZJqDh4ByGPQn13tlzMOTLCNdcugx,ekV6UX5gBZsaLHvOMCPF,zzekZcWL1sBgnoxN8f3vdQ0r,mmocwN1frQJ5ST3xa,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW
					OmsWt89dSA5HyCZ4wL[tLsNIYkDoSAcp6wrq].append(dw3rhvuZUHY0IQ4Deqa6Px)
		SqJ47pYPIVG = str(OmsWt89dSA5HyCZ4wL)
		if jTDWgftK7NEmx0JAkOn2aRIvweq: SqJ47pYPIVG = SqJ47pYPIVG.encode(Tk9eH2qw6Brsuhj)
		open(HEj7vrQguL8S5ydIcUwF2kNG6PJ4,sIzDXlTHYUC5L3xZGnr(u"ࠬࡽࡢࠨ჏")).write(SqJ47pYPIVG)
	return OmsWt89dSA5HyCZ4wL
def vjM9sANcTkUJViCD4PpBza0lH(C0C4kdG53sPAbNq8OBMpitLThHl):
	uqCMFB7TnbOSihUcxZ5og9G = C0C4kdG53sPAbNq8OBMpitLThHl.split(uulNDCPyef78(u"࠭࠭ࠨა"),BkM54Kr7Qbqn)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	i4YeIfAFjZkScx5RXLNGd96V,DDmgX24QRqwcVnez8GyP,rk0648WzSs7byUiKvRo5I1nBYPTMd = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if   uqCMFB7TnbOSihUcxZ5og9G==EE1jeHnIoad(u"ࠧࡂࡊ࡚ࡅࡐ࠭ბ")		:	from LLaFARNgnT			import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==s5WMHyQN4mpie(u"ࠨࡃࡎࡓࡆࡓࠧგ")		:	from eSXLR24o65			import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==aOQTKXFL54Nl60Zhp3MbE(u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐࠫდ")	:	from yyT9dmoRwD		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==Hr25gta6XcqO(u"ࠪࡅࡐ࡝ࡁࡎࠩე")		:	from tt9rH5O0wE			import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==vU6DxuzPwMpg(u"ࠫࡆࡑࡗࡂࡏࡗ࡙ࡇࡋࠧვ")	:	from HHlA2yfPdD		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==PlpyFa9QMKXxOD1cvHzmI(u"ࠬࡇࡌࡂࡔࡄࡆࠬზ")	:	from WwGcIojiqf			import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==o1INZ3ViQqS0Uw5z6kMjbv(u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉࠨთ")	:	from XbagVBnzq4		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==vU6DxuzPwMpg(u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔࠪი")	: 	from bgrumjKSZo		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪკ")	:	from unGyMKi4Ya		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==PlpyFa9QMKXxOD1cvHzmI(u"ࠩࡄࡐࡒ࡙ࡔࡃࡃࠪლ")	:	from ppCYXoGzWg		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪࡅࡓࡏࡍࡆ࡜ࡌࡈࠬმ")	:	from FNT0fsBqI5		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==jL5CrsRwebpyDVXUc1EQP(u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔࠩნ"):	from R2Ev5bt8kG	import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==FmYoGejTnwKME7d9zPc(u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧო")	:	from oTXYuAvz7q		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭ࡁ࡚ࡎࡒࡐࠬპ")		:	from OvPzhuR1mE			import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==SnhLjmfeJC(u"ࠧࡃࡑࡎࡖࡆ࠭ჟ")		:	from JoD7l3kPLf			import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==vU6DxuzPwMpg(u"ࠨࡄࡕࡗ࡙ࡋࡊࠨრ")	:	from NsDQMntudz			import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==o1INZ3ViQqS0Uw5z6kMjbv(u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪს")	:	from xRILDwOGAa		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==FmYoGejTnwKME7d9zPc(u"ࠪࡇࡎࡓࡁ࠵ࡒࠪტ")	:	from QQiAkKHd5G			import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==o1INZ3ViQqS0Uw5z6kMjbv(u"ࠫࡈࡏࡍࡂ࠶ࡘࠫუ")	:	from mmSelOD8xV			import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==FgXzMs0YSDt(u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧფ")	:	from YYIUphus1F		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==ggjO5CrKVRPITaesWkxD(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨქ")	:	from rzahyA67v3		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭ღ"):	from BnMcQ5YWox	import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==CsDcLqQUVK4YBvHFW1(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒࠪყ")	:	from SSNfP6Evbj		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==EE1jeHnIoad(u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫშ")	:	from jNQZuahVSF		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==FmYoGejTnwKME7d9zPc(u"ࠪࡇࡎࡓࡁࡇࡔࡈࡉࠬჩ")	:	from uFC7nAD9my		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧც")	:	from N7YIE4aUZM		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==CsDcLqQUVK4YBvHFW1(u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭ძ")	:	from SfjApdRFxq		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==AAbvaXV2DQzfNHdm4U3tT(u"࠭ࡃࡊࡏࡄ࡛ࡇࡇࡓࠨწ")	:	from JdF7fAMgCH		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==uulNDCPyef78(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬჭ"):	from PcY8Ww2NmX	import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==uulNDCPyef78(u"ࠨࡆࡕࡅࡒࡇࡃࡂࡈࡈࠫხ")	:	from H0WuYz7U69		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==AAbvaXV2DQzfNHdm4U3tT(u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪჯ")	:	from FhfewgiORp		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫჰ")	:	from MhgF6jcSCt		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==ggjO5CrKVRPITaesWkxD(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭ჱ")	:	from TdGAwqzt94		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==ssynAg0zhSkoCpOMDV9(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸ࠧჲ")	:	from nnHoTMO4Ui		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠳ࠨჳ")	:	from xEU5ZyWqcL		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==KfHAW8VGbrxi(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵ࠩჴ")	:	from vahkltGD8L		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==Hr25gta6XcqO(u"ࠨࡇࡊ࡝ࡉࡋࡁࡅࠩჵ")	:	from PxuUJ34h6n		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==EE1jeHnIoad(u"ࠩࡈࡋ࡞ࡔࡏࡘࠩჶ")	:	from MMD01SrpIK			import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==sJw9QWiq1Kr0xfeVRI(u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅࠬჷ")	:	from kqRjFsIy5N		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==jL5CrsRwebpyDVXUc1EQP(u"ࠫࡊࡒࡉࡇࡘࡌࡈࡊࡕࠧჸ")	:	from B7CE13FNJ2		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==CsDcLqQUVK4YBvHFW1(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭ჹ")	:	from s72wqgSmtX		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==EE1jeHnIoad(u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩჺ")	:	from XgkoxRdncr		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==SnhLjmfeJC(u"ࠧࡇࡃࡕࡉࡘࡑࡏࠨ჻")	:	from OZAsF1R5Im		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪჼ")	:	from VTjvHm9N02		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==ssynAg0zhSkoCpOMDV9(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫჽ")	:	from q2H0ZY87Lf		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==jL5CrsRwebpyDVXUc1EQP(u"ࠪࡊࡔ࡙ࡔࡂࠩჾ")		:	from VfveLDZA7i			import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==I18uSKaWhgTBeYUPD4sr(u"ࠫࡋ࡛ࡎࡐࡐࡗ࡚ࠬჿ")	:	from Ooh6vs1Frc		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==FmYoGejTnwKME7d9zPc(u"ࠬࡌࡕࡔࡊࡄࡖ࡙࡜ࠧᄀ")	:	from fYaBHwnA56		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==ggjO5CrKVRPITaesWkxD(u"࠭ࡆࡖࡕࡋࡅࡗ࡜ࡉࡅࡇࡒࠫᄁ"):	from iKmjAO6Wtf	import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧࡈࡑࡒࡋࡑࡋࡓࡆࡃࡕࡇࡍ࠭ᄂ"):	from rqOfYMzdDH	import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==O3OVuapf0YFjbm5oUQDg(u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪᄃ")	:	from MMarx62L4F		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==jL5CrsRwebpyDVXUc1EQP(u"ࠩࡌࡊࡎࡒࡍࠨᄄ")		:	from dEaSvCNWkB			import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==ggjO5CrKVRPITaesWkxD(u"ࠪࡍࡕ࡚ࡖࠨᄅ")		:	from z1qJk2AYoC			import O1NaXREkVqLJtKy0H86vzSmiP as i4YeIfAFjZkScx5RXLNGd96V,G5xvzuBVrfdP7eIOAwhW8UQ6Eic4 as DDmgX24QRqwcVnez8GyP,RTUaJZyvOuDA83So7M as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==ssynAg0zhSkoCpOMDV9(u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧᄆ")	:	from yy5BVlcQmu		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧᄇ")	:	from X0YoR9bDWk		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==FmYoGejTnwKME7d9zPc(u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅࠨᄈ")	:	from llQyzAJViv		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==QjAINyUC7MDRq5d8e4vl9(u"ࠧࡌࡋࡕࡑࡆࡒࡋࠨᄉ")	:	from kkqxZpmnFj		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠨࡎࡄࡖࡔࡠࡁࠨᄊ")	:	from PcJQBUOKfk			import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==Gcw2nelTR864XCVruO3mAFqI5a(u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪᄋ")	:	from Z74q9TrC3X		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==SnhLjmfeJC(u"ࠪࡑ࠸࡛ࠧᄌ")		:	from ucJU0YkpTS			import O1NaXREkVqLJtKy0H86vzSmiP as i4YeIfAFjZkScx5RXLNGd96V,G5xvzuBVrfdP7eIOAwhW8UQ6Eic4 as DDmgX24QRqwcVnez8GyP,RTUaJZyvOuDA83So7M as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==o1INZ3ViQqS0Uw5z6kMjbv(u"ࠫࡒࡇࡓࡂࡘࡌࡈࡊࡕࠧᄍ")	:	from z0wisEYa6v		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==EE1jeHnIoad(u"ࠬࡓࡏࡗࡕ࠷࡙ࠬᄎ")	:	from s8f9q7bOx1			import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==aOQTKXFL54Nl60Zhp3MbE(u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭ᄏ")	:	from p1rgUFG2s4			import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==FgXzMs0YSDt(u"ࠧࡑࡃࡑࡉ࡙࠭ᄐ")		:	from aXW3FT7Gys			import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==sJw9QWiq1Kr0xfeVRI(u"ࠨࡓࡉࡍࡑࡓࠧᄑ")		:	from FfADpHney9			import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠩࡖࡉࡗࡏࡅࡔࡖࡌࡑࡊ࠭ᄒ"):	from II0CON7vn9		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪࡗࡍࡇࡂࡂࡍࡄࡘ࡞࠭ᄓ")	:	from G9FzbdXtPL		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭ᄔ")	:	from drEPv43i0T		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==LYIgTBeSmZWotDh4bnyQkvM50siu(u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩᄕ"):	from oeDTz7nWbL		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆࠩᄖ")	:	from Av9W2yqQtT		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==Hr25gta6XcqO(u"ࠧࡔࡊࡒࡊࡍࡇࠧᄗ")	:	from FrSp3B1LEY			import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==N6NGJ4vpmidqMCh7yo(u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪᄘ")	:	from v0NFe2JTub		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==Gcw2nelTR864XCVruO3mAFqI5a(u"ࠩࡖࡌࡔࡕࡆࡏࡇࡗࠫᄙ")	:	from J2WoEqGOnM		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓࠬᄚ")	:	from eURCisO6mN		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࡙ࠫࡏࡋࡂࡃࡗࠫᄛ")	:	from x4xLUBI9Yk			import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==oRJAfwD957WkUyBM1Ehu8m(u"࡚ࠬࡖࡇࡗࡑࠫᄜ")		:	from UUnxtcWRAf			import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==ggjO5CrKVRPITaesWkxD(u"࠭ࡖࡂࡔࡅࡓࡓ࠭ᄝ")	:	from wbiB4Ysr26			import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==s5WMHyQN4mpie(u"ࠧࡗࡋࡇࡉࡔࡔࡓࡂࡇࡐࠫᄞ"):	from Qb1t8OU3jw		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠲ࠩᄟ")	:	from M1QUuVxPJE		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࡚ࠩࡉࡈࡏࡍࡂ࠴ࠪᄠ")	:	from jj2WXmTKkx		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==sJw9QWiq1Kr0xfeVRI(u"ࠪ࡝ࡆࡗࡏࡕࠩᄡ")		:	from UtYwATChLf			import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==Hr25gta6XcqO(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬᄢ")	:	from jSZ4ngtBFd		import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	elif uqCMFB7TnbOSihUcxZ5og9G==vU6DxuzPwMpg(u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫᄣ"):	from MMVdNiZ5gA	import UeOqpYGBXiJdAatwDboErxZLyh0M as i4YeIfAFjZkScx5RXLNGd96V,dPTs3joJiGpzfcWFvQZAa as DDmgX24QRqwcVnez8GyP,K2l9rLfvoXxyZ4NYapO as rk0648WzSs7byUiKvRo5I1nBYPTMd
	return i4YeIfAFjZkScx5RXLNGd96V,DDmgX24QRqwcVnez8GyP,rk0648WzSs7byUiKvRo5I1nBYPTMd
def lxXI7yjkvd3OZ0E(nMS0qslfXh3cg9DrWK67GNmYyLBRQ,GAwfpnzSiJEcHtQjDul1LsPN2YT0x9,showDialogs):
	Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭࠮࡝ࡶࡇࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭࠺ࠡ࡝ࠣࠫᄤ")+nMS0qslfXh3cg9DrWK67GNmYyLBRQ+Gcw2nelTR864XCVruO3mAFqI5a(u"ࠧࠡ࡟ࠣࠤࠥࡎࡥࡢࡦࡨࡶࡸࡀࠠ࡜ࠢࠪᄥ")+str(GAwfpnzSiJEcHtQjDul1LsPN2YT0x9)+sIzDXlTHYUC5L3xZGnr(u"ࠨࠢࡠࠫᄦ"))
	ua2GNHKeh94QJSd = hieYJByqUTsF9CH7aD3()
	ua2GNHKeh94QJSd.create(jL5CrsRwebpyDVXUc1EQP(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᄧ"),SnhLjmfeJC(u"ࠪ๎ัื๊ࠡษ็ฦ๋ࠦแฮืࠣห้๋ไโࠢส่๊฽ไ้สࠣฮา๋๊ๅ้ࠣ์อ฿ฯ่ษࠣืํ็ࠠหสาวࠥ฿ๅๅ์ฬࠤั๊ศࠡษ็้้็ࠠๆ่ࠣห้หๆหำ้ฮࠬᄨ"))
	J4NbqW35lrQnFhDZ0w = C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠲࠲࠵࠸ᐚ")*C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠲࠲࠵࠸ᐚ")
	TT6OvqmU5bgzjhPwIEXxV9FNoJ4p = I18uSKaWhgTBeYUPD4sr(u"࠳ᐛ")*J4NbqW35lrQnFhDZ0w
	import requests as dgMhO3f7oA
	ND4YsIrucC = dgMhO3f7oA.get(nMS0qslfXh3cg9DrWK67GNmYyLBRQ,stream=EsCplGc5N4mBuYW0RVQt6b,headers=GAwfpnzSiJEcHtQjDul1LsPN2YT0x9)
	BdyqeHchJrVYgP7x9ujXlQC2OvoRMn = ND4YsIrucC.headers
	ND4YsIrucC.close()
	AO20pZSy4wvdjRxcCNX3VJ6TY = bytes()
	if not BdyqeHchJrVYgP7x9ujXlQC2OvoRMn:
		if showDialogs: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,wdftVMyzF17cYETHu(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᄩ"),FmYoGejTnwKME7d9zPc(u"ࠬอไษำ้ห๊าࠠๅ็ࠣ๎ฯ๋ใ็่๊ࠢࠥะอๆ์็ࠤฬ๊ๅๅใࠣห้๋ืๅ๊หࠤํอไิสหࠤ็ี๋ࠠๅ๋๊ࠥ฿ๆะๅู้้ࠣไสࠢไ๎ࠥอไฦ่อี๋ะࠠศๆัหฺࠦศไࠢ࠱ࠤัืศࠡฬะ้๏๊ࠠศๆ่่ๆࠦๅาหࠣวำื้ࠨᄪ"))
		ua2GNHKeh94QJSd.close()
	else:
		if CsDcLqQUVK4YBvHFW1(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡍࡧࡱ࡫ࡹ࡮ࠧᄫ") not in list(BdyqeHchJrVYgP7x9ujXlQC2OvoRMn.keys()): Uu7lb5ZEhoGgwPNDBY = D2D96X5NGamBhrFwvL8VEbqiSfZIl
		else: Uu7lb5ZEhoGgwPNDBY = int(BdyqeHchJrVYgP7x9ujXlQC2OvoRMn[ssynAg0zhSkoCpOMDV9(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨᄬ")])
		J4By1CWSu27N5vbEX6V = str(int(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠵࠵࠶࠰ᐝ")*Uu7lb5ZEhoGgwPNDBY/J4NbqW35lrQnFhDZ0w)/V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠴࠴࠵࠶࠮࠱ᐜ"))
		nJi7mefc8wVCIt3DyxHY5kTW4Gap = int(Uu7lb5ZEhoGgwPNDBY/TT6OvqmU5bgzjhPwIEXxV9FNoJ4p)+BkM54Kr7Qbqn
		if s5WMHyQN4mpie(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡕࡥࡳ࡭ࡥࠨᄭ") in list(BdyqeHchJrVYgP7x9ujXlQC2OvoRMn.keys()) and Uu7lb5ZEhoGgwPNDBY>J4NbqW35lrQnFhDZ0w:
			ss78pliM9KQehI5nSdcLfuaBT = EsCplGc5N4mBuYW0RVQt6b
			bl6vsIAaySmRB0f = []
			TT6WHgNtYR = wdftVMyzF17cYETHu(u"࠶࠶ᐞ")
			bl6vsIAaySmRB0f.append(str(D2D96X5NGamBhrFwvL8VEbqiSfZIl*Uu7lb5ZEhoGgwPNDBY//TT6WHgNtYR)+Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠩ࠰ࠫᄮ")+str(BkM54Kr7Qbqn*Uu7lb5ZEhoGgwPNDBY//TT6WHgNtYR-BkM54Kr7Qbqn))
			bl6vsIAaySmRB0f.append(str(BkM54Kr7Qbqn*Uu7lb5ZEhoGgwPNDBY//TT6WHgNtYR)+uulNDCPyef78(u"ࠪ࠱ࠬᄯ")+str(teaC5j4HuGDqpwcmUzJ*Uu7lb5ZEhoGgwPNDBY//TT6WHgNtYR-BkM54Kr7Qbqn))
			bl6vsIAaySmRB0f.append(str(teaC5j4HuGDqpwcmUzJ*Uu7lb5ZEhoGgwPNDBY//TT6WHgNtYR)+uulNDCPyef78(u"ࠫ࠲࠭ᄰ")+str(XW57OCeGnFTLQbaqdrD9zM*Uu7lb5ZEhoGgwPNDBY//TT6WHgNtYR-BkM54Kr7Qbqn))
			bl6vsIAaySmRB0f.append(str(XW57OCeGnFTLQbaqdrD9zM*Uu7lb5ZEhoGgwPNDBY//TT6WHgNtYR)+s5WMHyQN4mpie(u"ࠬ࠳ࠧᄱ")+str(vD4Fh6ictZ7wME*Uu7lb5ZEhoGgwPNDBY//TT6WHgNtYR-BkM54Kr7Qbqn))
			bl6vsIAaySmRB0f.append(str(vD4Fh6ictZ7wME*Uu7lb5ZEhoGgwPNDBY//TT6WHgNtYR)+QjAINyUC7MDRq5d8e4vl9(u"࠭࠭ࠨᄲ")+str(ggjO5CrKVRPITaesWkxD(u"࠻ᐟ")*Uu7lb5ZEhoGgwPNDBY//TT6WHgNtYR-BkM54Kr7Qbqn))
			bl6vsIAaySmRB0f.append(str(O3OVuapf0YFjbm5oUQDg(u"࠵ᐠ")*Uu7lb5ZEhoGgwPNDBY//TT6WHgNtYR)+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠧ࠮ࠩᄳ")+str(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠷ᐡ")*Uu7lb5ZEhoGgwPNDBY//TT6WHgNtYR-BkM54Kr7Qbqn))
			bl6vsIAaySmRB0f.append(str(SnhLjmfeJC(u"࠹ᐣ")*Uu7lb5ZEhoGgwPNDBY//TT6WHgNtYR)+FgXzMs0YSDt(u"ࠨ࠯ࠪᄴ")+str(ssynAg0zhSkoCpOMDV9(u"࠹ᐢ")*Uu7lb5ZEhoGgwPNDBY//TT6WHgNtYR-BkM54Kr7Qbqn))
			bl6vsIAaySmRB0f.append(str(s5WMHyQN4mpie(u"࠼ᐥ")*Uu7lb5ZEhoGgwPNDBY//TT6WHgNtYR)+PlpyFa9QMKXxOD1cvHzmI(u"ࠩ࠰ࠫᄵ")+str(jL5CrsRwebpyDVXUc1EQP(u"࠼ᐤ")*Uu7lb5ZEhoGgwPNDBY//TT6WHgNtYR-BkM54Kr7Qbqn))
			bl6vsIAaySmRB0f.append(str(oRJAfwD957WkUyBM1Ehu8m(u"࠸ᐧ")*Uu7lb5ZEhoGgwPNDBY//TT6WHgNtYR)+ssynAg0zhSkoCpOMDV9(u"ࠪ࠱ࠬᄶ")+str(PlpyFa9QMKXxOD1cvHzmI(u"࠿ᐦ")*Uu7lb5ZEhoGgwPNDBY//TT6WHgNtYR-BkM54Kr7Qbqn))
			bl6vsIAaySmRB0f.append(str(AAbvaXV2DQzfNHdm4U3tT(u"࠺ᐨ")*Uu7lb5ZEhoGgwPNDBY//TT6WHgNtYR)+oRJAfwD957WkUyBM1Ehu8m(u"ࠫ࠲࠭ᄷ"))
			aFrv8Q62C170PZoIOjzhli = float(nJi7mefc8wVCIt3DyxHY5kTW4Gap)/TT6WHgNtYR
			qIpfeyEumzT8FjHUC10kRQLVW4r = aFrv8Q62C170PZoIOjzhli/int(BkM54Kr7Qbqn+aFrv8Q62C170PZoIOjzhli)
		else:
			ss78pliM9KQehI5nSdcLfuaBT = LhFAGlQ19zr
			TT6WHgNtYR = BkM54Kr7Qbqn
			qIpfeyEumzT8FjHUC10kRQLVW4r = BkM54Kr7Qbqn
		Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,PlpyFa9QMKXxOD1cvHzmI(u"ࠬ࠴࡜ࡵࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡹࡸ࡯࡮ࡨࠢࡵࡥࡳ࡭ࡥࡴ࠼ࠣ࡟ࠥ࠭ᄸ")+str(ss78pliM9KQehI5nSdcLfuaBT)+wdftVMyzF17cYETHu(u"࠭ࠠ࡞ࠢࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨᄹ")+str(Uu7lb5ZEhoGgwPNDBY)+sIzDXlTHYUC5L3xZGnr(u"ࠧࠡ࡟ࠪᄺ"))
		b3b24XZTV7gW9mhcqLoCnftO,RVKLS9snYF6 = D2D96X5NGamBhrFwvL8VEbqiSfZIl,D2D96X5NGamBhrFwvL8VEbqiSfZIl
		for Cwod6vgFDhmk3QBTO7JNs25U in range(TT6WHgNtYR):
			naBFTDfp6lmKjeOywg87IAcb = GAwfpnzSiJEcHtQjDul1LsPN2YT0x9.copy()
			if ss78pliM9KQehI5nSdcLfuaBT: naBFTDfp6lmKjeOywg87IAcb[FgXzMs0YSDt(u"ࠨࡔࡤࡲ࡬࡫ࠧᄻ")] = vU6DxuzPwMpg(u"ࠩࡥࡽࡹ࡫ࡳ࠾ࠩᄼ")+bl6vsIAaySmRB0f[Cwod6vgFDhmk3QBTO7JNs25U]
			ND4YsIrucC = dgMhO3f7oA.get(nMS0qslfXh3cg9DrWK67GNmYyLBRQ,stream=EsCplGc5N4mBuYW0RVQt6b,headers=naBFTDfp6lmKjeOywg87IAcb,timeout=s5WMHyQN4mpie(u"࠵࠳࠴ᐩ"))
			for HtJWeIN07jYUA in ND4YsIrucC.iter_content(chunk_size=TT6OvqmU5bgzjhPwIEXxV9FNoJ4p):
				if ua2GNHKeh94QJSd.iscanceled():
					Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,AAbvaXV2DQzfNHdm4U3tT(u"ࠪ࠲ࡡࡺࡄࡰࡹࡱࡰࡴࡧࡤࠡࡅࡤࡲࡨ࡫࡬ࡦࡦࠪᄽ"))
					break
				b3b24XZTV7gW9mhcqLoCnftO += qIpfeyEumzT8FjHUC10kRQLVW4r
				AO20pZSy4wvdjRxcCNX3VJ6TY += HtJWeIN07jYUA
				if not RVKLS9snYF6: RVKLS9snYF6 = len(HtJWeIN07jYUA)
				if Uu7lb5ZEhoGgwPNDBY: Hnrjh7smUIGq3RgDy19CL(ua2GNHKeh94QJSd,s5WMHyQN4mpie(u"࠴࠴࠵ᐪ")*b3b24XZTV7gW9mhcqLoCnftO//nJi7mefc8wVCIt3DyxHY5kTW4Gap,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠫั๊ศࠡษ็้้็࠺࠮ࠢส่ัุมࠡำๅ้ࠬᄾ"),str(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠵࠵࠶࠮࠱ᐫ")*RVKLS9snYF6*b3b24XZTV7gW9mhcqLoCnftO//TT6OvqmU5bgzjhPwIEXxV9FNoJ4p//C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠵࠵࠶࠮࠱ᐫ"))+wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠬࠦ࠯ࠡࠩᄿ")+J4By1CWSu27N5vbEX6V+sIzDXlTHYUC5L3xZGnr(u"࠭ࠠࡎࡄࠪᅀ"))
				else: Hnrjh7smUIGq3RgDy19CL(ua2GNHKeh94QJSd,RVKLS9snYF6*b3b24XZTV7gW9mhcqLoCnftO//TT6OvqmU5bgzjhPwIEXxV9FNoJ4p,aOQTKXFL54Nl60Zhp3MbE(u"ࠧอๆหࠤฬ๊ๅๅใ࠽࠱ࠬᅁ"),str(aOQTKXFL54Nl60Zhp3MbE(u"࠶࠶࠰࠯࠲ᐬ")*RVKLS9snYF6*b3b24XZTV7gW9mhcqLoCnftO//TT6OvqmU5bgzjhPwIEXxV9FNoJ4p//aOQTKXFL54Nl60Zhp3MbE(u"࠶࠶࠰࠯࠲ᐬ"))+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠨࠢࡐࡆࠬᅂ"))
			ND4YsIrucC.close()
		ua2GNHKeh94QJSd.close()
		if len(AO20pZSy4wvdjRxcCNX3VJ6TY)<Uu7lb5ZEhoGgwPNDBY and Uu7lb5ZEhoGgwPNDBY>D2D96X5NGamBhrFwvL8VEbqiSfZIl:
			Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,sIzDXlTHYUC5L3xZGnr(u"ࠩ࠱ࡠࡹࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡧࡣ࡬ࡰࡪࡪࠠࡰࡴࠣࡧࡦࡴࡣࡦ࡮ࡨࡨࠥࡧࡴ࠻ࠢ࡞ࠤࠬᅃ")+str(len(AO20pZSy4wvdjRxcCNX3VJ6TY)//J4NbqW35lrQnFhDZ0w)+sJw9QWiq1Kr0xfeVRI(u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡋࡸ࡯࡮ࠢࡷࡳࡹࡧ࡬ࠡࡱࡩ࠾ࠥࡡࠠࠨᅄ")+J4By1CWSu27N5vbEX6V+OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠫࠥࡓࡂࠡ࡟ࠪᅅ"))
			p7uvjbV1ftxo8yS6PNkH = jPRJMOhT415yvioG8rN9m0Q3b(fy8iFgEkrO12NR9TWBI35sjY6qHvV,wdftVMyzF17cYETHu(u"ࠬหไ฻ษฤࠤํิั้ฮࠪᅆ"),uulNDCPyef78(u"࠭วิฬัำฬ๋ࠠศๆ่่ๆࠦวๅ่สๆฺ࠭ᅇ"),FmYoGejTnwKME7d9zPc(u"ࠧฦ฻สำฮࠦฬๅสࠣห้๋ไโࠩᅈ"),AAbvaXV2DQzfNHdm4U3tT(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᅉ"),s5WMHyQN4mpie(u"ࠩไุ้ࠦแ๋ࠢฯ่อࠦวๅ็็ๅࠥࡢ࡮ࠡๆ็วุ็ࠠฮัฮࠤำ฽รࠡใํࠤฯำๅ๋ๆࠣห้๋ไโࠢ࡟ࡲࠥะๅࠡฮ็ฬࠥ࠭ᅊ")+str(len(AO20pZSy4wvdjRxcCNX3VJ6TY)//J4NbqW35lrQnFhDZ0w)+FgXzMs0YSDt(u"ࠪࠤ๊๐ฺศสส๎ฯࠦๅ็่ࠢะ๊๎ูࠡࠩᅋ")+J4By1CWSu27N5vbEX6V+Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"๋๊ࠫࠥ฻ษหห๏ะࠠ࡝ࡰࠣะึฮࠠอๆหࠤฬ๊ๅๅใ้ࠣึฯࠠฤะิํࠥࡢ࡮้ࠡ็ࠤฯื๊ะࠢสืฯิฯศ็ࠣห้๋ไโࠢส่๋อโึࠢยࠥࠦ࠭ᅌ"))
			if p7uvjbV1ftxo8yS6PNkH==teaC5j4HuGDqpwcmUzJ: AO20pZSy4wvdjRxcCNX3VJ6TY = lxXI7yjkvd3OZ0E(nMS0qslfXh3cg9DrWK67GNmYyLBRQ,GAwfpnzSiJEcHtQjDul1LsPN2YT0x9,showDialogs)
			elif p7uvjbV1ftxo8yS6PNkH==BkM54Kr7Qbqn: Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,EE1jeHnIoad(u"ࠬ࠴࡜ࡵࡐࡲࡸࠥࡩ࡯࡮ࡲ࡯ࡩࡹ࡫ࡤࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡨࡨࠥ࡬ࡩ࡭ࡧࠣ࡭ࡸࠦࡡࡤࡥࡨࡴࡹ࡫ࡤࠡࡣࡱࡨࠥࡽࡩ࡭࡮ࠣࡦࡪࠦࡵࡴࡧࡧࠫᅍ"))
			else: return fy8iFgEkrO12NR9TWBI35sjY6qHvV
			if not AO20pZSy4wvdjRxcCNX3VJ6TY: return fy8iFgEkrO12NR9TWBI35sjY6qHvV
		else: Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,sIzDXlTHYUC5L3xZGnr(u"࠭࠮࡝ࡶࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡘࡻࡣࡤࡧࡨࡨࡪࡪ࠮ࠡࠢࠣࡊ࡮ࡲࡥࠡࡕ࡬ࡾࡪࡀࠠ࡜ࠢࠪᅎ")+J4By1CWSu27N5vbEX6V+s5WMHyQN4mpie(u"ࠧࠡࡏࡅࠤࡢ࠭ᅏ"))
	return AO20pZSy4wvdjRxcCNX3VJ6TY
def s0xLFyaHWw(BfWYUAnyg6eONLjiuE):
	return ND4YsIrucC
def YkdA7N1UeQbwfEtgV8i3ZaS6u95(ip=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if I4t9qonjrm.GEOLOCATION_DATA: return I4t9qonjrm.GEOLOCATION_DATA
	XFhdfrZvPkTDQ6pV72S4LuqcR8aCJI,PPf96YqGdatREx,xxomIP9uSQLrz,BBfoCDM9TIGPiSxz6EFNph,yaSed3OU5j1AmcxLrTi,jC9nM8ZdeDmNpHcFGa5YuAB = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	zzekZcWL1sBgnoxN8f3vdQ0r = ggjO5CrKVRPITaesWkxD(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡫ࡳࡻ࡭ࡵ࠮ࡪࡵ࠲ࠫᅐ")+ip+sJw9QWiq1Kr0xfeVRI(u"ࠩࡂࡳࡺࡺࡰࡶࡶࡀ࡮ࡸࡵ࡮ࠧࡨ࡬ࡩࡱࡪࡳ࠾࡫ࡳ࠰ࡨࡵ࡮ࡵ࡫ࡱࡩࡳࡺࠬࡤࡱࡸࡲࡹࡸࡹ࠭ࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫ࠬࡳࡧࡪ࡭ࡴࡴࠬࡤ࡫ࡷࡽ࠱ࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧᅑ")
	GAwfpnzSiJEcHtQjDul1LsPN2YT0x9 = {uulNDCPyef78(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᅒ"):fy8iFgEkrO12NR9TWBI35sjY6qHvV}
	ND4YsIrucC = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,N6NGJ4vpmidqMCh7yo(u"ࠫࡌࡋࡔࠨᅓ"),zzekZcWL1sBgnoxN8f3vdQ0r,fy8iFgEkrO12NR9TWBI35sjY6qHvV,GAwfpnzSiJEcHtQjDul1LsPN2YT0x9,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡑࡏࡓࡈࡇࡔࡊࡑࡑ࠱࠶ࡹࡴࠨᅔ"))
	if not ND4YsIrucC.succeeded:
		zzekZcWL1sBgnoxN8f3vdQ0r = Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡩࡱ࠯ࡤࡴ࡮࠴ࡣࡰ࡯࠲࡮ࡸࡵ࡮࠰ࠩᅕ")+ip+EE1jeHnIoad(u"ࠧࡀࡨ࡬ࡩࡱࡪࡳ࠾ࡳࡸࡩࡷࡿࠬࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶ࠯ࡧࡴࡻ࡮ࡵࡴࡼ࠰ࡨࡵࡵ࡯ࡶࡵࡽࡈࡵࡤࡦ࠮ࡵࡩ࡬࡯࡯࡯ࡐࡤࡱࡪ࠲ࡣࡪࡶࡼ࠰ࡴ࡬ࡦࡴࡧࡷࠫᅖ")
		ND4YsIrucC = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠨࡉࡈࡘࠬᅗ"),zzekZcWL1sBgnoxN8f3vdQ0r,fy8iFgEkrO12NR9TWBI35sjY6qHvV,GAwfpnzSiJEcHtQjDul1LsPN2YT0x9,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,s5WMHyQN4mpie(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊࡕࡌࡐࡅࡄࡘࡎࡕࡎ࠮࠴ࡱࡨࠬᅘ"))
	if ND4YsIrucC.succeeded:
		FGRX4myP68S = ND4YsIrucC.content
		H5oVy80EgeluaNk = Qra2CWgebk.loads(FGRX4myP68S)
		fIuzWl41bLTOQi0D53hZBky = list(H5oVy80EgeluaNk.keys())
		if o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪ࡭ࡵ࠭ᅙ") in fIuzWl41bLTOQi0D53hZBky: ip = H5oVy80EgeluaNk[uulNDCPyef78(u"ࠫ࡮ࡶࠧᅚ")]
		if AAbvaXV2DQzfNHdm4U3tT(u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴࠨᅛ") in fIuzWl41bLTOQi0D53hZBky: XFhdfrZvPkTDQ6pV72S4LuqcR8aCJI = H5oVy80EgeluaNk[oRJAfwD957WkUyBM1Ehu8m(u"࠭ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵࠩᅜ")]
		if Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨᅝ") in fIuzWl41bLTOQi0D53hZBky: PPf96YqGdatREx = H5oVy80EgeluaNk[FmYoGejTnwKME7d9zPc(u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩᅞ")]
		if sIzDXlTHYUC5L3xZGnr(u"ࠩࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥࠨᅟ") in fIuzWl41bLTOQi0D53hZBky: xxomIP9uSQLrz = H5oVy80EgeluaNk[uulNDCPyef78(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦࠩᅠ")]
		if QjAINyUC7MDRq5d8e4vl9(u"ࠫࡷ࡫ࡧࡪࡱࡱࠫᅡ") in fIuzWl41bLTOQi0D53hZBky: BBfoCDM9TIGPiSxz6EFNph = H5oVy80EgeluaNk[EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬࡸࡥࡨ࡫ࡲࡲࠬᅢ")]
		if SnhLjmfeJC(u"࠭ࡣࡪࡶࡼࠫᅣ") in fIuzWl41bLTOQi0D53hZBky: yaSed3OU5j1AmcxLrTi = H5oVy80EgeluaNk[EE1jeHnIoad(u"ࠧࡤ࡫ࡷࡽࠬᅤ")]
		if CsDcLqQUVK4YBvHFW1(u"ࠨࡳࡸࡩࡷࡿࠧᅥ") in fIuzWl41bLTOQi0D53hZBky: ip = H5oVy80EgeluaNk[aOQTKXFL54Nl60Zhp3MbE(u"ࠩࡴࡹࡪࡸࡹࠨᅦ")]
		if C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࡇࡴࡪࡥࠨᅧ") in fIuzWl41bLTOQi0D53hZBky: xxomIP9uSQLrz = H5oVy80EgeluaNk[vU6DxuzPwMpg(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࡈࡵࡤࡦࠩᅨ")]
		if sJw9QWiq1Kr0xfeVRI(u"ࠬࡸࡥࡨ࡫ࡲࡲࡓࡧ࡭ࡦࠩᅩ") in fIuzWl41bLTOQi0D53hZBky: BBfoCDM9TIGPiSxz6EFNph = H5oVy80EgeluaNk[ssynAg0zhSkoCpOMDV9(u"࠭ࡲࡦࡩ࡬ࡳࡳࡔࡡ࡮ࡧࠪᅪ")]
		if FmYoGejTnwKME7d9zPc(u"ࠧࡵ࡫ࡰࡩࡿࡵ࡮ࡦࠩᅫ") in fIuzWl41bLTOQi0D53hZBky:
			jC9nM8ZdeDmNpHcFGa5YuAB = H5oVy80EgeluaNk[AAbvaXV2DQzfNHdm4U3tT(u"ࠨࡶ࡬ࡱࡪࢀ࡯࡯ࡧࠪᅬ")][EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩࡸࡸࡨ࠭ᅭ")]
			if jC9nM8ZdeDmNpHcFGa5YuAB[D2D96X5NGamBhrFwvL8VEbqiSfZIl] not in [KfHAW8VGbrxi(u"ࠪ࠱ࠬᅮ"),CsDcLqQUVK4YBvHFW1(u"ࠫ࠰࠭ᅯ")]: jC9nM8ZdeDmNpHcFGa5YuAB = KfHAW8VGbrxi(u"ࠬ࠱ࠧᅰ")+jC9nM8ZdeDmNpHcFGa5YuAB
		if OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠭࡯ࡧࡨࡶࡩࡹ࠭ᅱ") in fIuzWl41bLTOQi0D53hZBky:
			jC9nM8ZdeDmNpHcFGa5YuAB = H5oVy80EgeluaNk[o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧࡰࡨࡩࡷࡪࡺࠧᅲ")]
			if jC9nM8ZdeDmNpHcFGa5YuAB>=EE1jeHnIoad(u"࠶ᐭ"): jC9nM8ZdeDmNpHcFGa5YuAB = QjAINyUC7MDRq5d8e4vl9(u"ࠨ࠭ࠪᅳ")+uUqrNPcXKBoQ0slv.strftime(SnhLjmfeJC(u"ࠤࠨࡌ࠿ࠫࡍࠣᅴ"),uUqrNPcXKBoQ0slv.gmtime(jC9nM8ZdeDmNpHcFGa5YuAB))
			else: jC9nM8ZdeDmNpHcFGa5YuAB = Hr25gta6XcqO(u"ࠪ࠱ࠬᅵ")+uUqrNPcXKBoQ0slv.strftime(s5WMHyQN4mpie(u"ࠦࠪࡎ࠺ࠦࡏࠥᅶ"),uUqrNPcXKBoQ0slv.gmtime(-jC9nM8ZdeDmNpHcFGa5YuAB))
	Fokmx1wiD4W2sHGtT97cANnPCE = ip+O3OVuapf0YFjbm5oUQDg(u"ࠬ࠲ࠧᅷ")+XFhdfrZvPkTDQ6pV72S4LuqcR8aCJI+EE1jeHnIoad(u"࠭ࠬࠨᅸ")+PPf96YqGdatREx+OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠧ࠭ࠩᅹ")+BBfoCDM9TIGPiSxz6EFNph+I18uSKaWhgTBeYUPD4sr(u"ࠨ࠮ࠪᅺ")+yaSed3OU5j1AmcxLrTi+jL5CrsRwebpyDVXUc1EQP(u"ࠩ࠯ࠫᅻ")+jC9nM8ZdeDmNpHcFGa5YuAB
	Fokmx1wiD4W2sHGtT97cANnPCE = Fokmx1wiD4W2sHGtT97cANnPCE.encode(Tk9eH2qw6Brsuhj)
	if jTDWgftK7NEmx0JAkOn2aRIvweq: Fokmx1wiD4W2sHGtT97cANnPCE = Fokmx1wiD4W2sHGtT97cANnPCE.decode(vU6DxuzPwMpg(u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫᅼ"))
	I4t9qonjrm.GEOLOCATION_DATA = XXcPiylRDh6IapYA25rwO8u(Fokmx1wiD4W2sHGtT97cANnPCE)
	return I4t9qonjrm.GEOLOCATION_DATA
def VVLsBWDuZCfakNtYAFMHd6yiGqxTe(kkmRDoruLZGJyvzExtTBeO42f):
	nXWRTCqeaGAgO1k9ZywL2z,showDialogs = fy8iFgEkrO12NR9TWBI35sjY6qHvV,EsCplGc5N4mBuYW0RVQt6b
	if kkmRDoruLZGJyvzExtTBeO42f.count(KfHAW8VGbrxi(u"ࠫࡤ࠭ᅽ"))>=teaC5j4HuGDqpwcmUzJ:
		kkmRDoruLZGJyvzExtTBeO42f,nXWRTCqeaGAgO1k9ZywL2z = kkmRDoruLZGJyvzExtTBeO42f.split(Hr25gta6XcqO(u"ࠬࡥࠧᅾ"),BkM54Kr7Qbqn)
		nXWRTCqeaGAgO1k9ZywL2z = sIzDXlTHYUC5L3xZGnr(u"࠭࡟ࠨᅿ")+nXWRTCqeaGAgO1k9ZywL2z
		if sIzDXlTHYUC5L3xZGnr(u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࠬᆀ") in nXWRTCqeaGAgO1k9ZywL2z: showDialogs = LhFAGlQ19zr
		else: showDialogs = EsCplGc5N4mBuYW0RVQt6b
	return kkmRDoruLZGJyvzExtTBeO42f,nXWRTCqeaGAgO1k9ZywL2z,showDialogs
def wdfTiC18D4ZEpmSFNnOI():
	CXuvxyPDOl7Bwj = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(uugoLac4UGZztBeijxW1k0,SnhLjmfeJC(u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧᆁ"))
	RsgvFpZAzGiEh9J0Ob = D2D96X5NGamBhrFwvL8VEbqiSfZIl
	if HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.exists(CXuvxyPDOl7Bwj):
		for lDmQVa3oFnhqWcbSX in HoxKENAey2MdTt9kDUrVnWGLS0CPa.listdir(CXuvxyPDOl7Bwj):
			if FmYoGejTnwKME7d9zPc(u"ࠩ࠱ࡴࡾࡵࠧᆂ") in lDmQVa3oFnhqWcbSX: continue
			if O3OVuapf0YFjbm5oUQDg(u"ࠪࡣࡤࡶࡹࡤࡣࡦ࡬ࡪࡥ࡟ࠨᆃ") in lDmQVa3oFnhqWcbSX: continue
			xGf4QetnVJukNBKF = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(CXuvxyPDOl7Bwj,lDmQVa3oFnhqWcbSX)
			fQ96jG2mWRU,eKsJrCAZgnXiVEN5fx4cp0kG9TIbR = ucm10ohnRLA8d5ybFKEYkNQa3e6Gr(xGf4QetnVJukNBKF)
			RsgvFpZAzGiEh9J0Ob += fQ96jG2mWRU
	return RsgvFpZAzGiEh9J0Ob
def dBRZV0CzgA8EXuFhrqfl(showDialogs):
	ddZT6IqGUCPHj1isNJA5M = OdiZIyCfDUsW3JBGR2VAb.getSetting(PlpyFa9QMKXxOD1cvHzmI(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩᆄ"))
	z93Ypj7fog1qnvCHyraAPDt5lw = rIhXWK91vRuC(jUCABmLYMf0G,oRJAfwD957WkUyBM1Ehu8m(u"ࠬࡹࡴࡳࠩᆅ"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩᆆ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩᆇ"))
	ttKIRD17v2aYVPHCOJg,a0rIMVOlAKBGZHW1N3g = ddZT6IqGUCPHj1isNJA5M,z93Ypj7fog1qnvCHyraAPDt5lw
	tPMmFrklu0eAX68Z1cqxfTa,aBiQPwVZM3y859 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪᆈ") not in str(I4t9qonjrm.SEND_THESE_EVENTS):
		zzekZcWL1sBgnoxN8f3vdQ0r = I4t9qonjrm.SITESURLS[O3OVuapf0YFjbm5oUQDg(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩᆉ")][XW57OCeGnFTLQbaqdrD9zM]
		qIQCz90DuxjlYJ = YkdA7N1UeQbwfEtgV8i3ZaS6u95()
		PPf96YqGdatREx = qIQCz90DuxjlYJ.split(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪ࠰ࠬᆊ"))[teaC5j4HuGDqpwcmUzJ]
		RsgvFpZAzGiEh9J0Ob = wdfTiC18D4ZEpmSFNnOI()
		CfKjoYXSy1vwIBM4l9UDzb = {oRJAfwD957WkUyBM1Ehu8m(u"ࠫࡺࡹࡥࡳࠩᆋ"):I4t9qonjrm.AV_CLIENT_IDS,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭ᆌ"):KoxvjArhL1TdInDmN9s,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧᆍ"):PPf96YqGdatREx,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧࡪࡦࡶࠫᆎ"):UAIXp7GJvrH64(RsgvFpZAzGiEh9J0Ob)}
		ND4YsIrucC = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,ssynAg0zhSkoCpOMDV9(u"ࠨࡒࡒࡗ࡙࠭ᆏ"),zzekZcWL1sBgnoxN8f3vdQ0r,CfKjoYXSy1vwIBM4l9UDzb,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QjAINyUC7MDRq5d8e4vl9(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡎࡇࡖࡗࡆࡍࡅࡔ࠯࠴ࡷࡹ࠭ᆐ"))
		if not ND4YsIrucC.succeeded:
			if ddZT6IqGUCPHj1isNJA5M in [fy8iFgEkrO12NR9TWBI35sjY6qHvV,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪࡒࡊ࡝ࠧᆑ")]: ttKIRD17v2aYVPHCOJg = CsDcLqQUVK4YBvHFW1(u"ࠫࡓࡋࡗࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪᆒ")
			elif ddZT6IqGUCPHj1isNJA5M==AAbvaXV2DQzfNHdm4U3tT(u"ࠬࡕࡌࡅࠩᆓ"): ttKIRD17v2aYVPHCOJg = wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭ࡏࡍࡆࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬᆔ")
		else:
			YXNosFBh0UGAO = ND4YsIrucC.content
			YXNosFBh0UGAO = LB7TcZnGYdfw5lWU1RH3Oztu9PyA(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠧ࡭࡫ࡶࡸࠬᆕ"),YXNosFBh0UGAO)
			YXNosFBh0UGAO = sorted(YXNosFBh0UGAO,reverse=EsCplGc5N4mBuYW0RVQt6b,key=lambda key: int(key[D2D96X5NGamBhrFwvL8VEbqiSfZIl]))
			aBiQPwVZM3y859,a0rIMVOlAKBGZHW1N3g = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
			for uhCR7bwZYE9JsrHVg4XUlpdy,s1S2OnBu9aDhzH5PAZE,nhXGUOtlzjbo in YXNosFBh0UGAO:
				if uhCR7bwZYE9JsrHVg4XUlpdy==FgXzMs0YSDt(u"ࠨ࠲ࠪᆖ"):
					aBiQPwVZM3y859 += nhXGUOtlzjbo+uulNDCPyef78(u"ࠩ࠽࠾ࠬᆗ")
					continue
				if a0rIMVOlAKBGZHW1N3g: a0rIMVOlAKBGZHW1N3g += C0qrknitpM4Z+n0nFOd4yR97fQzNLSW+I18uSKaWhgTBeYUPD4sr(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩᆘ")+T7ASIp1ZYwio9HQ8cObJK+QjAINyUC7MDRq5d8e4vl9(u"ࠫࡡࡴ࡜࡯ࠩᆙ")
				ZJAfbqNchkmSxWCEH1 = nhXGUOtlzjbo.split(C0qrknitpM4Z)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
				iH1XqR6GlYbe8Q0IzFUhadBk = C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬืำศๆฬࠤำอีสࠢ็็ࠥ็โุࠩᆚ") if s1S2OnBu9aDhzH5PAZE else fy8iFgEkrO12NR9TWBI35sjY6qHvV
				a0rIMVOlAKBGZHW1N3g += nhXGUOtlzjbo.replace(ZJAfbqNchkmSxWCEH1,WydpaVx5YmLoCiIgA34eEBlb+ZJAfbqNchkmSxWCEH1+iH1XqR6GlYbe8Q0IzFUhadBk+T7ASIp1ZYwio9HQ8cObJK)+C0qrknitpM4Z
			a0rIMVOlAKBGZHW1N3g = C0qrknitpM4Z+a0rIMVOlAKBGZHW1N3g+LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠭࡜࡯࡞ࡱࠫᆛ")
			aBiQPwVZM3y859 = aBiQPwVZM3y859.strip(wdftVMyzF17cYETHu(u"ࠧ࠻࠼ࠪᆜ"))
			tPMmFrklu0eAX68Z1cqxfTa = OdiZIyCfDUsW3JBGR2VAb.getSetting(aOQTKXFL54Nl60Zhp3MbE(u"ࠨࡣࡹ࠲ࡵࡸࡩࡷࡵ࠴ࠫᆝ"))
			if a0rIMVOlAKBGZHW1N3g==z93Ypj7fog1qnvCHyraAPDt5lw and ddZT6IqGUCPHj1isNJA5M in [SnhLjmfeJC(u"ࠩࡒࡐࡉ࠭ᆞ"),oRJAfwD957WkUyBM1Ehu8m(u"ࠪࡓࡑࡊ࡟ࡕࡑࡢࡉࡗࡘࡏࡓࠩᆟ")]: ttKIRD17v2aYVPHCOJg = Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫࡔࡒࡄࠨᆠ")
			else: ttKIRD17v2aYVPHCOJg = jL5CrsRwebpyDVXUc1EQP(u"ࠬࡔࡅࡘࠩᆡ")
			tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩᆢ"),Gcw2nelTR864XCVruO3mAFqI5a(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩᆣ"),a0rIMVOlAKBGZHW1N3g,zz2tnLhI1QHV7GwFCrv5)
			OdiZIyCfDUsW3JBGR2VAb.setSetting(Hr25gta6XcqO(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩᆤ"),UAIXp7GJvrH64(VySKdWnH3vNq6klQ))
			OdiZIyCfDUsW3JBGR2VAb.setSetting(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ࠵ࠬᆥ"),aBiQPwVZM3y859)
			YMFiErscPW2Z = bSyIhTmVdu8sDCPHiU5pXQ1OK.md5(PlpyFa9QMKXxOD1cvHzmI(u"࠵ᐮ")*aBiQPwVZM3y859.encode(Tk9eH2qw6Brsuhj)).hexdigest()
			YMFiErscPW2Z = bSyIhTmVdu8sDCPHiU5pXQ1OK.md5(oRJAfwD957WkUyBM1Ehu8m(u"࠲࠶ᐯ")*YMFiErscPW2Z.encode(Tk9eH2qw6Brsuhj)).hexdigest()
			YMFiErscPW2Z = bSyIhTmVdu8sDCPHiU5pXQ1OK.md5(uulNDCPyef78(u"࠳࠼ᐰ")*YMFiErscPW2Z.encode(Tk9eH2qw6Brsuhj)).hexdigest()
			vvPmnHekOc7qrjidMwxf134VD,aaLcdPtZmTG4ir = zjBDwxSgrTZkle0N1WPFEUq5d9y3(jUCABmLYMf0G)
			FG0eAEdZ9gaUJ8Xmv2xs = aaLcdPtZmTG4ir.execute(PlpyFa9QMKXxOD1cvHzmI(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮ࡠ࡫ࡧࡁࠬᆦ")+str(int(YMFiErscPW2Z[C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠷ᐲ"):EE1jeHnIoad(u"࠶࠸ᐳ")],AAbvaXV2DQzfNHdm4U3tT(u"࠷࠶ᐴ")))[:V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠼ᐱ")]+sIzDXlTHYUC5L3xZGnr(u"ࠫࡀ࠭ᆧ"))
			vvPmnHekOc7qrjidMwxf134VD.close()
		yA24iBEd9H1oh7mkgwPQRbaSIx = EsCplGc5N4mBuYW0RVQt6b if aBiQPwVZM3y859!=tPMmFrklu0eAX68Z1cqxfTa else LhFAGlQ19zr
		if yA24iBEd9H1oh7mkgwPQRbaSIx:
			fDBFxqIc4tRPVlMA71KSXau9WNZ68 = I4t9qonjrm.mzAtNn5gGow2Z
			I4t9qonjrm.tFkvuaLGpKHMI2l5J,I4t9qonjrm.mzAtNn5gGow2Z,I4t9qonjrm.HA9kv8mRpfV,I4t9qonjrm.g7OiLZfAHNlPJEUQCyx2pIrj = AANCp8tEGTLriQgjB([N6NGJ4vpmidqMCh7yo(u"ࠬࡉࡔࡆ࠻ࡇࡗ࠶࠿ࡖࡖ࠲࡙ࡗ࡝࠭ᆨ"),N6NGJ4vpmidqMCh7yo(u"࠭ࡗࡔࡗࡕࡊ࡙࠷࠹ࡒࡖࡈࡊ࡟࡞ࠧᆩ"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧࡃࡖࡈࡼࡕ࡜࠱࠺ࡗࡕ࡚ࡓ࡛ࡓࡖ࠷ࡋ࡜ࠬᆪ"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠨࡑࡗ࠵࠾ࡐࡕ࠱ࡺࡅࡘ࡚ࡲࡄ࡙ࠩᆫ")])
			AFuRtw6XJ84C5zUWkcbHMZBs1oEhLP = I4t9qonjrm.mzAtNn5gGow2Z
			if not fDBFxqIc4tRPVlMA71KSXau9WNZ68 and AFuRtw6XJ84C5zUWkcbHMZBs1oEhLP and EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࡣ࡙࡙ࠧᆬ") in I4t9qonjrm.SEND_THESE_EVENTS:
				I4t9qonjrm.SEND_THESE_EVENTS.remove(EE1jeHnIoad(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࡤ࡚ࡓࠨᆭ"))
				I4t9qonjrm.SEND_THESE_EVENTS.append(KfHAW8VGbrxi(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭ᆮ"))
			elif fDBFxqIc4tRPVlMA71KSXau9WNZ68 and not AFuRtw6XJ84C5zUWkcbHMZBs1oEhLP and LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧᆯ") in I4t9qonjrm.SEND_THESE_EVENTS:
				I4t9qonjrm.SEND_THESE_EVENTS.remove(vU6DxuzPwMpg(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨᆰ"))
				I4t9qonjrm.SEND_THESE_EVENTS.append(Hr25gta6XcqO(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࡡࡗࡗࠬᆱ"))
			ejX7kGtQ4hcYUHW9b31vriuZLM6Sp(LhFAGlQ19zr)
	if showDialogs:
		if ttKIRD17v2aYVPHCOJg in [wdftVMyzF17cYETHu(u"ࠨࡑࡏࡈࡤ࡚ࡏࡠࡇࡕࡖࡔࡘࠧᆲ"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠩࡑࡉ࡜ࡥࡔࡐࡡࡈࡖࡗࡕࡒࠨᆳ")]:
			GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᆴ"),I18uSKaWhgTBeYUPD4sr(u"ࠫ์์วไุ่่๊ࠢษࠡใํࠤัํวำๅࠣ์์๐ࠠๅ์ึฮ๋ࠥๆࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦ็ั้ࠣห้๋ิไๆฬࠤ็ี๋ࠠๅู๋๊ࠥศษ้สࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูࠥฮใࠡล๋ࠤฬ๊ัศ๊อีࠥอไฯษุࠤอ้ࠠฤู๊้้ࠣไสࠢไ๎ࠥอไฤี็หู่ࠦ็ัๆࠫᆵ"))
		else:
			cFjMEShi6Pp0otRBgeXq8(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬࡸࡩࡨࡪࡷࠫᆶ"),FgXzMs0YSDt(u"࠭ัิษษ่๋ࠥๆࠡษ็้อืๅอࠢศ่๎ࠦๅิฬัำ๊๐ࠠศๆหี๋อๅอࠩᆷ"),a0rIMVOlAKBGZHW1N3g,AAbvaXV2DQzfNHdm4U3tT(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨᆸ"))
			ttKIRD17v2aYVPHCOJg = N6NGJ4vpmidqMCh7yo(u"ࠨࡑࡏࡈࠬᆹ")
	if ttKIRD17v2aYVPHCOJg!=ddZT6IqGUCPHj1isNJA5M:
		OdiZIyCfDUsW3JBGR2VAb.setSetting(vU6DxuzPwMpg(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧᆺ"),ttKIRD17v2aYVPHCOJg)
		ejX7kGtQ4hcYUHW9b31vriuZLM6Sp(LhFAGlQ19zr)
	return
def gn6Rhp5VIDGUAbvYL(DDbf73rFVszUJBeWHuQ,UgWO9XDKlE7MVbw):
	import socket as AA872c56aHvzhydmTfCSw0tlDxoZeK
	sflmcK9GUWTFbZNiSgLC8EyP7XYt6D = AA872c56aHvzhydmTfCSw0tlDxoZeK.socket(AA872c56aHvzhydmTfCSw0tlDxoZeK.AF_INET,AA872c56aHvzhydmTfCSw0tlDxoZeK.SOCK_STREAM)
	sflmcK9GUWTFbZNiSgLC8EyP7XYt6D.settimeout(teaC5j4HuGDqpwcmUzJ)
	try:
		TYfRSPL2HA3GuXIbgjyzBN69Wms = uUqrNPcXKBoQ0slv.time()
		sflmcK9GUWTFbZNiSgLC8EyP7XYt6D.connect((DDbf73rFVszUJBeWHuQ,UgWO9XDKlE7MVbw))
		IaMAd73b4S6 = uUqrNPcXKBoQ0slv.time()
		WTaECdm2NlD4zVwIY5vg7OiyhB = round((IaMAd73b4S6-TYfRSPL2HA3GuXIbgjyzBN69Wms)*EE1jeHnIoad(u"࠱࠱࠲࠳ᐵ"))
	except: WTaECdm2NlD4zVwIY5vg7OiyhB = -BkM54Kr7Qbqn
	sflmcK9GUWTFbZNiSgLC8EyP7XYt6D.close()
	return WTaECdm2NlD4zVwIY5vg7OiyhB
def ZL2gHRX194IrVYoqcjnT(showDialogs):
	if showDialogs:
		Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,SnhLjmfeJC(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᆻ"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ุࠫ๎แࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡษ็ฦ๋ࠦศฦื็หา่ࠦห่฻๎ๆࠦฬๆ์฼ࠤ็๎วฺัࠣห้ฮ๊ศ่สฮࠥ๎วๅๅสุࠥอไๆีอาิ๋ษࠡใํࠤฬ๊ศา่ส้ัࠦ࠮࠯๊่ࠢࠥะั๋ัࠣฮูเ๊ๅࠢ฼้้๐ษࠡษ็ฮ๋฾๊โࠢส่ว์ࠠภࠣࠪᆼ"))
	else: Scj7zgGFVA83otMpwUkxhm0BLN1 = EsCplGc5N4mBuYW0RVQt6b
	if Scj7zgGFVA83otMpwUkxhm0BLN1==BkM54Kr7Qbqn:
		for lDmQVa3oFnhqWcbSX in HoxKENAey2MdTt9kDUrVnWGLS0CPa.listdir(Xsc4lqOhdziToWvunbRNSQZKIY8E):
			if lDmQVa3oFnhqWcbSX.endswith(O3OVuapf0YFjbm5oUQDg(u"ࠬ࠴ࡤࡣࠩᆽ")) and wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭ࡤࡢࡶࡤࠫᆾ") in lDmQVa3oFnhqWcbSX:
				ccwPvtXMB3jGNCeydFIZaHziLKER = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(Xsc4lqOhdziToWvunbRNSQZKIY8E,lDmQVa3oFnhqWcbSX)
				vvPmnHekOc7qrjidMwxf134VD,aaLcdPtZmTG4ir = zjBDwxSgrTZkle0N1WPFEUq5d9y3(ccwPvtXMB3jGNCeydFIZaHziLKER)
				aaLcdPtZmTG4ir.execute(QjAINyUC7MDRq5d8e4vl9(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡧࡱࡵࡩ࡮࡭࡮ࡠ࡭ࡨࡽࡸࡃ࡮ࡰ࠽ࠪᆿ"))
				aaLcdPtZmTG4ir.execute(vU6DxuzPwMpg(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡶࡨࡱࡵࡥࡳࡵࡱࡵࡩࡂࡓࡅࡎࡑࡕ࡝ࡀ࠭ᇀ"))
				aaLcdPtZmTG4ir.execute(uulNDCPyef78(u"ࠩࡓࡖࡆࡍࡍࡂࠢ࡬ࡲࡹ࡫ࡧࡳ࡫ࡷࡽࡤࡩࡨࡦࡥ࡮࠿ࠬᇁ"))
				aaLcdPtZmTG4ir.execute(QjAINyUC7MDRq5d8e4vl9(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡳࡵࡺࡩ࡮࡫ࡽࡩࡀ࠭ᇂ"))
				aaLcdPtZmTG4ir.execute(wdftVMyzF17cYETHu(u"࡛ࠫࡇࡃࡖࡗࡐ࠿ࠬᇃ"))
				vvPmnHekOc7qrjidMwxf134VD.commit()
				vvPmnHekOc7qrjidMwxf134VD.close()
		if showDialogs: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,s5WMHyQN4mpie(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᇄ"),sJw9QWiq1Kr0xfeVRI(u"࠭สๆฬࠣฬ๋าวฮࠢ฼้้๐ษࠡวุ่ฬำ้ࠠฬ้฼๏็ࠠอ็ํ฽่่ࠥศ฻าࠤฬ๊ศ๋ษ้หฯ่ࠦศๆๆหูࠦวๅ็ึฮำีๅสࠢไ๎ࠥอไษำ้ห๊าࠧᇅ"))
	return
def ZBILqw92kAymRHD7GstV(PPIkTDwrjdL2VvmaES0u3Jg9b6poh1,Z18H2bxCPtlQizBp3,showDialogs):
	if PPIkTDwrjdL2VvmaES0u3Jg9b6poh1!=cJsR8uCmEQpkzg2AyZXo1:
		if PPIkTDwrjdL2VvmaES0u3Jg9b6poh1==DGxPh8K0bBkN5fmu2py4L: I4t9qonjrm.ALLOW_DNS_FIX = EsCplGc5N4mBuYW0RVQt6b
		elif PPIkTDwrjdL2VvmaES0u3Jg9b6poh1==DDIe1w6Gj3NMV9E08FtqxbSsh: I4t9qonjrm.ALLOW_DNS_FIX = LhFAGlQ19zr
		elif PPIkTDwrjdL2VvmaES0u3Jg9b6poh1==LLvswCIAk0tubrKgFpPW4BVf: I4t9qonjrm.ALLOW_DNS_FIX = EsCplGc5N4mBuYW0RVQt6b
	if Z18H2bxCPtlQizBp3!=cJsR8uCmEQpkzg2AyZXo1:
		if Z18H2bxCPtlQizBp3==DGxPh8K0bBkN5fmu2py4L: I4t9qonjrm.ALLOW_PROXY_FIX = EsCplGc5N4mBuYW0RVQt6b
		elif Z18H2bxCPtlQizBp3==DDIe1w6Gj3NMV9E08FtqxbSsh: I4t9qonjrm.ALLOW_PROXY_FIX = LhFAGlQ19zr
		elif Z18H2bxCPtlQizBp3==LLvswCIAk0tubrKgFpPW4BVf: I4t9qonjrm.ALLOW_PROXY_FIX = EsCplGc5N4mBuYW0RVQt6b
	if showDialogs!=cJsR8uCmEQpkzg2AyZXo1:
		if showDialogs==DGxPh8K0bBkN5fmu2py4L: I4t9qonjrm.ALLOW_SHOWDIALOGS_FIX = EsCplGc5N4mBuYW0RVQt6b
		elif showDialogs==DDIe1w6Gj3NMV9E08FtqxbSsh: I4t9qonjrm.ALLOW_SHOWDIALOGS_FIX = LhFAGlQ19zr
		elif showDialogs==LLvswCIAk0tubrKgFpPW4BVf: I4t9qonjrm.ALLOW_SHOWDIALOGS_FIX = EsCplGc5N4mBuYW0RVQt6b
	return
def oo28t7rh90aqMBsnY(website,bAomiWyI5Bdexs9nKEqVGLS2Q,OglWy8FGtiDT=zA8Ry1KDvmr3w4B5xeP):
	eeGRHTwB5iF = N6NGJ4vpmidqMCh7yo(u"࠲࠲ᐶ")
	Fsy08w9oV6Hkadlu = [KfHAW8VGbrxi(u"࠳ᐷ"),KfHAW8VGbrxi(u"࠳ᐷ"),KfHAW8VGbrxi(u"࠳ᐷ"),SnhLjmfeJC(u"࠴࠴ᐸ"),EE1jeHnIoad(u"࠹ᐹ"),SnhLjmfeJC(u"࠴࠴ᐸ"),KfHAW8VGbrxi(u"࠳ᐷ"),KfHAW8VGbrxi(u"࠳ᐷ"),KfHAW8VGbrxi(u"࠳ᐷ"),EE1jeHnIoad(u"࠹ᐹ")]
	HHBmc0EeM4J8xChrUZAlIWRyNwuqgG = []
	YHxi1ktelb3WNEqAUPDypjIgKX = [s5WMHyQN4mpie(u"࠵ᐺ")]*eeGRHTwB5iF
	RW0LV2hN7TZBEOGJQa = rIhXWK91vRuC(jUCABmLYMf0G,aOQTKXFL54Nl60Zhp3MbE(u"ࠧࡥ࡫ࡦࡸࠬᇆ"),Hr25gta6XcqO(u"ࠨࡕࡆࡖࡆࡖࡅࡓࡕࡢࡗ࡙ࡇࡔࡖࡕࠪᇇ"))
	for ggWJuLevHYtPFNmdR3Xj in list(RW0LV2hN7TZBEOGJQa.keys()):
		if website not in ggWJuLevHYtPFNmdR3Xj: continue
		C0C4kdG53sPAbNq8OBMpitLThHl,SSGA3vTkHwt1 = ggWJuLevHYtPFNmdR3Xj.split(SnhLjmfeJC(u"ࠩࡢࡣࠬᇈ"))
		YHxi1ktelb3WNEqAUPDypjIgKX[int(SSGA3vTkHwt1)] = RW0LV2hN7TZBEOGJQa[ggWJuLevHYtPFNmdR3Xj]
	for nOJQDh1rV9ZWyNzwHas6dMFml0 in range(eeGRHTwB5iF):
		if nOJQDh1rV9ZWyNzwHas6dMFml0 in I4t9qonjrm.BADSCRAPERS+bAomiWyI5Bdexs9nKEqVGLS2Q: continue
		if nOJQDh1rV9ZWyNzwHas6dMFml0==OglWy8FGtiDT: YHxi1ktelb3WNEqAUPDypjIgKX[nOJQDh1rV9ZWyNzwHas6dMFml0] = YHxi1ktelb3WNEqAUPDypjIgKX[nOJQDh1rV9ZWyNzwHas6dMFml0]+uulNDCPyef78(u"࠷ᐻ")
		if YHxi1ktelb3WNEqAUPDypjIgKX[nOJQDh1rV9ZWyNzwHas6dMFml0]<s5WMHyQN4mpie(u"࠳ᐼ"): HHBmc0EeM4J8xChrUZAlIWRyNwuqgG += [nOJQDh1rV9ZWyNzwHas6dMFml0]*Fsy08w9oV6Hkadlu[nOJQDh1rV9ZWyNzwHas6dMFml0]
	if not HHBmc0EeM4J8xChrUZAlIWRyNwuqgG:
		for nOJQDh1rV9ZWyNzwHas6dMFml0 in range(eeGRHTwB5iF):
			YHxi1ktelb3WNEqAUPDypjIgKX[nOJQDh1rV9ZWyNzwHas6dMFml0] = EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠱ᐽ")
			if nOJQDh1rV9ZWyNzwHas6dMFml0 in I4t9qonjrm.BADSCRAPERS+bAomiWyI5Bdexs9nKEqVGLS2Q: continue
			HHBmc0EeM4J8xChrUZAlIWRyNwuqgG += [nOJQDh1rV9ZWyNzwHas6dMFml0]*Fsy08w9oV6Hkadlu[nOJQDh1rV9ZWyNzwHas6dMFml0]
	for nOJQDh1rV9ZWyNzwHas6dMFml0 in I4t9qonjrm.BADSCRAPERS: YHxi1ktelb3WNEqAUPDypjIgKX[nOJQDh1rV9ZWyNzwHas6dMFml0] = OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠻࠼࠽࠾ᐾ")
	Idl73mSWenQHuXF6btYr = []
	for nOJQDh1rV9ZWyNzwHas6dMFml0 in range(eeGRHTwB5iF): Idl73mSWenQHuXF6btYr.append(website+aOQTKXFL54Nl60Zhp3MbE(u"ࠪࡣࡤ࠭ᇉ")+str(nOJQDh1rV9ZWyNzwHas6dMFml0))
	tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠫࡘࡉࡒࡂࡒࡈࡖࡘࡥࡓࡕࡃࡗ࡙ࡘ࠭ᇊ"),Idl73mSWenQHuXF6btYr,YHxi1ktelb3WNEqAUPDypjIgKX,Ogcv69NTyBVC3qFG*I18uSKaWhgTBeYUPD4sr(u"࠸ᐿ"),EsCplGc5N4mBuYW0RVQt6b)
	return HHBmc0EeM4J8xChrUZAlIWRyNwuqgG
def QfvdwXOyPiLgZ2D95VJoarn8c17zp(iXYEGvtThUqFPJ4pHLZSnNRr29Ako,YLKFRH6sSIrznXBg,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,Rs8EfockW2DUHiMbjlXVLPT47mwKrI,RRn6elHkAQU9XT3NtISJyLKM,mE7D5fBQZOKJdhtVUkHaIgRWpx,Wsv5B14O6xFLqJ=fy8iFgEkrO12NR9TWBI35sjY6qHvV,iLXSma92HFtwhBKU=fy8iFgEkrO12NR9TWBI35sjY6qHvV,bAomiWyI5Bdexs9nKEqVGLS2Q=[]):
	a6rVSjDMF87KyYINcuOP1l40Hbp(ssynAg0zhSkoCpOMDV9(u"ࠬฮฯฤฬࠣ฽๊๊๊สࠢอะฬ๎าࠡษ็ััฮࠧᇋ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,uUqrNPcXKBoQ0slv=aOQTKXFL54Nl60Zhp3MbE(u"࠻࠺࠶ᑀ"))
	Clc8sIj97ZrThF(wVhZ6bfkpSre95EFu,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+uulNDCPyef78(u"࠭ࠠࠡࠢࡗࡶࡾ࡯࡮ࡨࠢࡥࡽࡵࡧࡳࡴࠢࡥࡰࡴࡩ࡫ࡪࡰࡪࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨᇌ")+str(Wsv5B14O6xFLqJ)+Hr25gta6XcqO(u"ࠧࠡ࡟ࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨᇍ")+iLXSma92HFtwhBKU+N6NGJ4vpmidqMCh7yo(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᇎ")+mE7D5fBQZOKJdhtVUkHaIgRWpx+sIzDXlTHYUC5L3xZGnr(u"ࠩࠣࡡࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᇏ")+YLKFRH6sSIrznXBg+AAbvaXV2DQzfNHdm4U3tT(u"ࠪࠤࡢ࠭ᇐ"))
	website = mE7D5fBQZOKJdhtVUkHaIgRWpx.split(SnhLjmfeJC(u"ࠫ࠲࠭ᇑ"))[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	RXPS5CrAb01cmJB7T2ZgnQpUK8l = oo28t7rh90aqMBsnY(website,bAomiWyI5Bdexs9nKEqVGLS2Q)
	GmYolHzab0xs8F6f = []
	if website==sJw9QWiq1Kr0xfeVRI(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧᇒ"):
		if D2D96X5NGamBhrFwvL8VEbqiSfZIl in RXPS5CrAb01cmJB7T2ZgnQpUK8l: GmYolHzab0xs8F6f += [D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		if BkM54Kr7Qbqn in RXPS5CrAb01cmJB7T2ZgnQpUK8l: GmYolHzab0xs8F6f += [BkM54Kr7Qbqn]
		if teaC5j4HuGDqpwcmUzJ in RXPS5CrAb01cmJB7T2ZgnQpUK8l: GmYolHzab0xs8F6f += [teaC5j4HuGDqpwcmUzJ]
		if XW57OCeGnFTLQbaqdrD9zM in RXPS5CrAb01cmJB7T2ZgnQpUK8l: GmYolHzab0xs8F6f += [XW57OCeGnFTLQbaqdrD9zM]*sIzDXlTHYUC5L3xZGnr(u"࠶࠶ᑁ")
		if vD4Fh6ictZ7wME in RXPS5CrAb01cmJB7T2ZgnQpUK8l: GmYolHzab0xs8F6f += [vD4Fh6ictZ7wME]*hvkue2LYgiOGrtcmxszl4S8MWdnF
		if hvkue2LYgiOGrtcmxszl4S8MWdnF in RXPS5CrAb01cmJB7T2ZgnQpUK8l: GmYolHzab0xs8F6f += [hvkue2LYgiOGrtcmxszl4S8MWdnF]*EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠷࠰ᑂ")
		if C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠶ᑃ") in RXPS5CrAb01cmJB7T2ZgnQpUK8l: GmYolHzab0xs8F6f += [C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠶ᑃ")]
		if CsDcLqQUVK4YBvHFW1(u"࠸ᑄ") in RXPS5CrAb01cmJB7T2ZgnQpUK8l: GmYolHzab0xs8F6f += [CsDcLqQUVK4YBvHFW1(u"࠸ᑄ")]
	elif website==FgXzMs0YSDt(u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨᇓ"):
		if XW57OCeGnFTLQbaqdrD9zM in RXPS5CrAb01cmJB7T2ZgnQpUK8l: GmYolHzab0xs8F6f += [XW57OCeGnFTLQbaqdrD9zM]*wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠳࠳ᑅ")
	elif website==FmYoGejTnwKME7d9zPc(u"ࠧࡄࡋࡐࡅ࡜ࡈࡁࡔࠩᇔ"):
		if BkM54Kr7Qbqn in RXPS5CrAb01cmJB7T2ZgnQpUK8l: GmYolHzab0xs8F6f += [BkM54Kr7Qbqn]
		if vD4Fh6ictZ7wME in RXPS5CrAb01cmJB7T2ZgnQpUK8l: GmYolHzab0xs8F6f += [vD4Fh6ictZ7wME]*hvkue2LYgiOGrtcmxszl4S8MWdnF
		if hvkue2LYgiOGrtcmxszl4S8MWdnF in RXPS5CrAb01cmJB7T2ZgnQpUK8l: GmYolHzab0xs8F6f += [hvkue2LYgiOGrtcmxszl4S8MWdnF]*AAbvaXV2DQzfNHdm4U3tT(u"࠴࠴ᑆ")
		if LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠺ᑇ") in RXPS5CrAb01cmJB7T2ZgnQpUK8l: GmYolHzab0xs8F6f += [LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠺ᑇ")]
		if CsDcLqQUVK4YBvHFW1(u"࠼ᑈ") in RXPS5CrAb01cmJB7T2ZgnQpUK8l: GmYolHzab0xs8F6f += [CsDcLqQUVK4YBvHFW1(u"࠼ᑈ")]
	elif website==C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫᇕ"):
		if vD4Fh6ictZ7wME in RXPS5CrAb01cmJB7T2ZgnQpUK8l: GmYolHzab0xs8F6f += [vD4Fh6ictZ7wME]*hvkue2LYgiOGrtcmxszl4S8MWdnF
		if hvkue2LYgiOGrtcmxszl4S8MWdnF in RXPS5CrAb01cmJB7T2ZgnQpUK8l: GmYolHzab0xs8F6f += [hvkue2LYgiOGrtcmxszl4S8MWdnF]*wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠷࠰ᑉ")
	elif website==FmYoGejTnwKME7d9zPc(u"࡚ࠩࡉࡈࡏࡍࡂ࠳ࠪᇖ"):
		if Gcw2nelTR864XCVruO3mAFqI5a(u"࠹ᑊ") in RXPS5CrAb01cmJB7T2ZgnQpUK8l: GmYolHzab0xs8F6f += [Gcw2nelTR864XCVruO3mAFqI5a(u"࠹ᑊ")]*LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠲࠲ᑋ")
	elif website==o1INZ3ViQqS0Uw5z6kMjbv(u"࡛ࠪࡊࡉࡉࡎࡃ࠵ࠫᇗ"):
		if BkM54Kr7Qbqn in RXPS5CrAb01cmJB7T2ZgnQpUK8l: GmYolHzab0xs8F6f += [BkM54Kr7Qbqn]
		if hvkue2LYgiOGrtcmxszl4S8MWdnF in RXPS5CrAb01cmJB7T2ZgnQpUK8l: GmYolHzab0xs8F6f += [hvkue2LYgiOGrtcmxszl4S8MWdnF]*Gcw2nelTR864XCVruO3mAFqI5a(u"࠳࠳ᑌ")
	elif website==EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠫࡌࡕࡏࡈࡎࡈࡗࡊࡇࡒࡄࡊࠪᇘ"):
		if vD4Fh6ictZ7wME in RXPS5CrAb01cmJB7T2ZgnQpUK8l: GmYolHzab0xs8F6f += [vD4Fh6ictZ7wME]*hvkue2LYgiOGrtcmxszl4S8MWdnF
	if GmYolHzab0xs8F6f: RXPS5CrAb01cmJB7T2ZgnQpUK8l = GmYolHzab0xs8F6f
	if RXPS5CrAb01cmJB7T2ZgnQpUK8l:
		BVkb50EJPUy4RY1oZ7LN = yiTBYwps2mCrb4jGPux0cIJ.sample(RXPS5CrAb01cmJB7T2ZgnQpUK8l,BkM54Kr7Qbqn)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	else: BVkb50EJPUy4RY1oZ7LN = -BkM54Kr7Qbqn
	update = EsCplGc5N4mBuYW0RVQt6b
	if BVkb50EJPUy4RY1oZ7LN==D2D96X5NGamBhrFwvL8VEbqiSfZIl:
		scraperserver = EE1jeHnIoad(u"ࠬࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠲ࠩᇙ")
		KoMfdTY495ngrIyp0 = O3OVuapf0YFjbm5oUQDg(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡤࡴࡤࡴࡪࡵࡰࡴ࠰࡮ࡩࡪࡶ࡟ࡩࡧࡤࡨࡪࡸࡳ࠾ࡖࡵࡹࡪ࠴ࡣࡰࡷࡱࡸࡷࡿ࠽ࡪ࡮࠽࠵࠺࠶ࡤ࠳࠴ࡩ࠵࠲ࡩ࠵࠹ࡣ࠰࠸࠵࠸࠱࠮ࡣࡤ࠼࠹࠳ࡥ࠺࠴࠶ࡧࡦ࡬࠸࠶࠺࠶࠸ࡅࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠮ࡪࡱ࠽࠹࠸࠻࠳ࠨᇚ")
		hL4w3zgankZR75698QCyi = YLKFRH6sSIrznXBg+ggjO5CrKVRPITaesWkxD(u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧᇛ")+KoMfdTY495ngrIyp0+oRJAfwD957WkUyBM1Ehu8m(u"ࠨࡾࡿࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨᇜ")
		UWCLiFA6Yx2jEcDay = FlxDpgfQcuSWvGwtyC5d(iXYEGvtThUqFPJ4pHLZSnNRr29Ako,hL4w3zgankZR75698QCyi,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,Rs8EfockW2DUHiMbjlXVLPT47mwKrI,RRn6elHkAQU9XT3NtISJyLKM,mE7D5fBQZOKJdhtVUkHaIgRWpx,LhFAGlQ19zr,LhFAGlQ19zr)
	elif BVkb50EJPUy4RY1oZ7LN==BkM54Kr7Qbqn:
		scraperserver = FmYoGejTnwKME7d9zPc(u"ࠩࡶࡧࡷࡧࡰࡦࡱࡳࡷ࠷࠭ᇝ")
		KoMfdTY495ngrIyp0 = aOQTKXFL54Nl60Zhp3MbE(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡨࡸࡡࡱࡧࡲࡴࡸ࠴࡫ࡦࡧࡳࡣ࡭࡫ࡡࡥࡧࡵࡷࡂ࡚ࡲࡶࡧ࠱ࡧࡴࡻ࡮ࡵࡴࡼࡁ࡮ࡲ࠺࠴࠻࠼࠵ࡪ࠿ࡣ࠶࠯࠺ࡩࡪ࠹࠭࠵ࡧࡨ࠶࠲࠾࠴ࡤ࠲࠰ࡪࡩ࠽࠹࠳ࡤࡤࡨࡩ࠹ࡤ࠶ࡂࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥࡰࡲࡶ࠲࡮ࡵ࠺࠶࠵࠸࠷ࠬᇞ")
		hL4w3zgankZR75698QCyi = YLKFRH6sSIrznXBg+N6NGJ4vpmidqMCh7yo(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫᇟ")+KoMfdTY495ngrIyp0+SnhLjmfeJC(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬᇠ")
		UWCLiFA6Yx2jEcDay = FlxDpgfQcuSWvGwtyC5d(iXYEGvtThUqFPJ4pHLZSnNRr29Ako,hL4w3zgankZR75698QCyi,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,Rs8EfockW2DUHiMbjlXVLPT47mwKrI,RRn6elHkAQU9XT3NtISJyLKM,mE7D5fBQZOKJdhtVUkHaIgRWpx,LhFAGlQ19zr,LhFAGlQ19zr)
	elif BVkb50EJPUy4RY1oZ7LN==teaC5j4HuGDqpwcmUzJ:
		scraperserver = EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭ࡳࡤࡴࡤࡴࡪࡸࡡࡱ࡫ࠪᇡ")
		KoMfdTY495ngrIyp0 = wdftVMyzF17cYETHu(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡥࡵࡥࡵ࡫ࡲࡢࡲ࡬࠲ࡰ࡫ࡥࡱࡡ࡫ࡩࡦࡪࡥࡳࡵࡀࡘࡷࡻࡥ࠯ࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫࠽ࡪ࡮࠽࠻࠻ࡨ࠴ࡧࡥ࠶࠸࡫ࡩࡤ࠲࠻ࡧ࠽ࡨ࠻࠵ࡢ࠳࠸ࡪ࠸࠼࠰࠵ࡥࡧ࠽࠶࠺ࡣࡁࡲࡵࡳࡽࡿ࠭ࡴࡧࡵࡺࡪࡸ࠮ࡴࡥࡵࡥࡵ࡫ࡲࡢࡲ࡬࠲ࡨࡵ࡭࠻࠺࠳࠴࠶࠭ᇢ")
		hL4w3zgankZR75698QCyi = YLKFRH6sSIrznXBg+O3OVuapf0YFjbm5oUQDg(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨᇣ")+KoMfdTY495ngrIyp0+PlpyFa9QMKXxOD1cvHzmI(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩᇤ")
		UWCLiFA6Yx2jEcDay = FlxDpgfQcuSWvGwtyC5d(iXYEGvtThUqFPJ4pHLZSnNRr29Ako,hL4w3zgankZR75698QCyi,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,Rs8EfockW2DUHiMbjlXVLPT47mwKrI,RRn6elHkAQU9XT3NtISJyLKM,mE7D5fBQZOKJdhtVUkHaIgRWpx,LhFAGlQ19zr,LhFAGlQ19zr)
	elif BVkb50EJPUy4RY1oZ7LN==XW57OCeGnFTLQbaqdrD9zM:
		scraperserver = LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠪࡷࡨࡸࡡࡱࡧࡸࡴࠬᇥ")
		MYWwFs7XA2 = YLKFRH6sSIrznXBg.replace(PlpyFa9QMKXxOD1cvHzmI(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠭ᇦ"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠭ᇧ"))
		hL4w3zgankZR75698QCyi = vU6DxuzPwMpg(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡡࡱ࡫࠱ࡷࡨࡸࡡࡱࡧࡸࡴ࠳ࡩ࡯࡮࠱ࡂࡥࡵ࡯࡟࡬ࡧࡼࡁ࠶࡜ࡎࡴࡏࡷࡐ࠶ࡵࡂࡓ࡚࡮ࡗࡓࡉࡢࡄࡏࡍ࠵ࡐ࡞࡙ࡋ࡬࡭࠴ࡩࡰ࡚ࡸࠨ࡮ࡩࡪࡶ࡟ࡩࡧࡤࡨࡪࡸࡳ࠾ࡈࡤࡰࡸ࡫ࠦࡤࡱࡸࡲࡹࡸࡹࡠࡥࡲࡨࡪࡃࡩ࡭ࠨࡸࡶࡱࡃࠧᇨ")+DVX5GWhnIxYlSd9rEuetjk40UJ(MYWwFs7XA2)
		UWCLiFA6Yx2jEcDay = FlxDpgfQcuSWvGwtyC5d(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠧࡈࡇࡗࠫᇩ"),hL4w3zgankZR75698QCyi,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,Rs8EfockW2DUHiMbjlXVLPT47mwKrI,RRn6elHkAQU9XT3NtISJyLKM,mE7D5fBQZOKJdhtVUkHaIgRWpx,LhFAGlQ19zr,LhFAGlQ19zr)
	elif BVkb50EJPUy4RY1oZ7LN==vD4Fh6ictZ7wME:
		scraperserver = ggjO5CrKVRPITaesWkxD(u"ࠨࡵࡦࡶࡦࡶࡩ࡯ࡩࡵࡳࡧࡵࡴࠨᇪ")
		hL4w3zgankZR75698QCyi = sJw9QWiq1Kr0xfeVRI(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡴ࡮࠴ࡳࡤࡴࡤࡴ࡮ࡴࡧࡳࡱࡥࡳࡹ࠴ࡣࡰ࡯࠲ࡃࡹࡵ࡫ࡦࡰࡀࡥ࠹࡬࠷ࡧࡤ࠴࠸࠲࠸ࡤࡦࡨ࠰࠸࠵࠽࠱࠮࠺࠹࠸ࡧ࠳࠲࠳ࡧ࠶࠶࠻࠺ࡤ࠵ࡦࡧࡧࠫࡶࡲࡰࡺࡼࡇࡴࡻ࡮ࡵࡴࡼࡁࡎࡒࠦࡶࡴ࡯ࡁࠬᇫ")+DVX5GWhnIxYlSd9rEuetjk40UJ(YLKFRH6sSIrznXBg)
		UWCLiFA6Yx2jEcDay = FlxDpgfQcuSWvGwtyC5d(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪࡋࡊ࡚ࠧᇬ"),hL4w3zgankZR75698QCyi,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,Rs8EfockW2DUHiMbjlXVLPT47mwKrI,RRn6elHkAQU9XT3NtISJyLKM,mE7D5fBQZOKJdhtVUkHaIgRWpx,LhFAGlQ19zr,LhFAGlQ19zr)
		try:
			UWCLiFA6Yx2jEcDay.content = LB7TcZnGYdfw5lWU1RH3Oztu9PyA(Hr25gta6XcqO(u"ࠫࡩ࡯ࡣࡵࠩᇭ"),UWCLiFA6Yx2jEcDay.content)
			UWCLiFA6Yx2jEcDay.content = UWCLiFA6Yx2jEcDay.content[EE1jeHnIoad(u"ࠬࡸࡥࡴࡷ࡯ࡸࠬᇮ")]
		except: pass
	elif BVkb50EJPUy4RY1oZ7LN==hvkue2LYgiOGrtcmxszl4S8MWdnF:
		scraperserver = sIzDXlTHYUC5L3xZGnr(u"࠭ࡳࡤࡴࡤࡴ࡮ࡴࡧࡢࡰࡷ࠵ࠬᇯ")
		KoMfdTY495ngrIyp0 = ssynAg0zhSkoCpOMDV9(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡥࡵࡥࡵ࡯࡮ࡨࡣࡱࡸࠫࡶࡲࡰࡺࡼࡣࡨࡵࡵ࡯ࡶࡵࡽࡂࡏࡌࠧࡤࡵࡳࡼࡹࡥࡳ࠿ࡉࡥࡱࡹࡥࠧࡨࡲࡶࡼࡧࡲࡥࡡ࡫ࡩࡦࡪࡥࡳࡵࡀࡘࡷࡻࡥ࠻࠴ࡥ࠷࠹࠶ࡡ࠷࠺࠼࠴ࡦ࠻࠴࠱࠳ࡧࡦࡨ࠹࠷࠳ࡥ࠴࠵࠹࠻ࡤ࠺࠸࠵ࡩ࠽ࡆࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡡ࡯ࡶ࠱ࡧࡴࡳ࠺࠹࠲࠻࠴ࠬᇰ")
		hL4w3zgankZR75698QCyi = YLKFRH6sSIrznXBg+oRJAfwD957WkUyBM1Ehu8m(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨᇱ")+KoMfdTY495ngrIyp0+OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩᇲ")
		UWCLiFA6Yx2jEcDay = FlxDpgfQcuSWvGwtyC5d(iXYEGvtThUqFPJ4pHLZSnNRr29Ako,hL4w3zgankZR75698QCyi,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,Rs8EfockW2DUHiMbjlXVLPT47mwKrI,RRn6elHkAQU9XT3NtISJyLKM,mE7D5fBQZOKJdhtVUkHaIgRWpx,LhFAGlQ19zr,LhFAGlQ19zr)
	elif BVkb50EJPUy4RY1oZ7LN==oRJAfwD957WkUyBM1Ehu8m(u"࠹ᑍ"):
		scraperserver = jL5CrsRwebpyDVXUc1EQP(u"ࠪࡷࡨࡸࡡࡱࡧ࠱ࡨࡴ࠷ࠧᇳ")
		KoMfdTY495ngrIyp0 = CsDcLqQUVK4YBvHFW1(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡨࡩ࠲࠷࠵ࡤࡦ࠶࡫࠵࠱࠶࠷ࡨ࠷ࡩࡡ࠶ࡦ࠸ࡨ࠸࡬࠹ࡦ࠵ࡦ࠷࠽࠼ࡥࡤࡣ࠴࠵࠵࠾࠳࠹࠻ࡤ࠻࠸ࡀࡣࡶࡵࡷࡳࡲࡎࡥࡢࡦࡨࡶࡸࡃࡔࡳࡷࡨࠪ࡬࡫࡯ࡄࡱࡧࡩࡂ࡯࡬ࡁࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫࠮ࡥࡱ࠽࠼࠵࠾࠰ࠨᇴ")
		hL4w3zgankZR75698QCyi = YLKFRH6sSIrznXBg+vU6DxuzPwMpg(u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬᇵ")+KoMfdTY495ngrIyp0+ssynAg0zhSkoCpOMDV9(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭ᇶ")
		UWCLiFA6Yx2jEcDay = FlxDpgfQcuSWvGwtyC5d(iXYEGvtThUqFPJ4pHLZSnNRr29Ako,hL4w3zgankZR75698QCyi,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,Rs8EfockW2DUHiMbjlXVLPT47mwKrI,RRn6elHkAQU9XT3NtISJyLKM,mE7D5fBQZOKJdhtVUkHaIgRWpx,LhFAGlQ19zr,LhFAGlQ19zr)
	elif BVkb50EJPUy4RY1oZ7LN==KfHAW8VGbrxi(u"࠻ᑎ"):
		scraperserver = KfHAW8VGbrxi(u"ࠧࡴࡥࡵࡥࡵ࡫࠮ࡥࡱ࠵ࠫᇷ")
		KoMfdTY495ngrIyp0 = ssynAg0zhSkoCpOMDV9(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳ࡦ࠷ࡩ࠹ࡡࡦ࠳࠻࠹ࡩ࡬࠴ࡣࡨ࠹ࡥ࡫࠻࠳࠴ࡥ࠺࠴࠹࠶ࡢ࠴࠶࠺ࡧ࠾࡫࠹࠺ࡤࡨ࠸࠻࠼ࡡࡦ࠻࠽ࡧࡺࡹࡴࡰ࡯ࡋࡩࡦࡪࡥࡳࡵࡀࡘࡷࡻࡥࠧࡩࡨࡳࡈࡵࡤࡦ࠿࡬ࡰࡅࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲࡨ࠲ࡩࡵ࠺࠹࠲࠻࠴ࠬᇸ")
		hL4w3zgankZR75698QCyi = YLKFRH6sSIrznXBg+N6NGJ4vpmidqMCh7yo(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩᇹ")+KoMfdTY495ngrIyp0+N6NGJ4vpmidqMCh7yo(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪᇺ")
		UWCLiFA6Yx2jEcDay = FlxDpgfQcuSWvGwtyC5d(iXYEGvtThUqFPJ4pHLZSnNRr29Ako,hL4w3zgankZR75698QCyi,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,Rs8EfockW2DUHiMbjlXVLPT47mwKrI,RRn6elHkAQU9XT3NtISJyLKM,mE7D5fBQZOKJdhtVUkHaIgRWpx,LhFAGlQ19zr,LhFAGlQ19zr)
	elif BVkb50EJPUy4RY1oZ7LN==EE1jeHnIoad(u"࠽ᑏ"):
		scraperserver = Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠫࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠳ࠨᇻ")
		hL4w3zgankZR75698QCyi = AAbvaXV2DQzfNHdm4U3tT(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠯࡫ࡲ࠳ࡻ࠷࠯ࡀࡣࡳ࡭ࡤࡱࡥࡺ࠿࠶࠽࠾࠷ࡥ࠺ࡥ࠸࠱࠼࡫ࡥ࠴࠯࠷ࡩࡪ࠸࠭࠹࠶ࡦ࠴࠲࡬ࡤ࠸࠻࠵ࡦࡦࡪࡤ࠴ࡦ࠸ࠪࡨࡵࡵ࡯ࡶࡵࡽࡂ࡯࡬ࠧࡷࡵࡰࡂ࠭ᇼ")+DVX5GWhnIxYlSd9rEuetjk40UJ(YLKFRH6sSIrznXBg)
		UWCLiFA6Yx2jEcDay = FlxDpgfQcuSWvGwtyC5d(LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠭ࡇࡆࡖࠪᇽ"),hL4w3zgankZR75698QCyi,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,Rs8EfockW2DUHiMbjlXVLPT47mwKrI,RRn6elHkAQU9XT3NtISJyLKM,mE7D5fBQZOKJdhtVUkHaIgRWpx,LhFAGlQ19zr,LhFAGlQ19zr)
	elif BVkb50EJPUy4RY1oZ7LN==oRJAfwD957WkUyBM1Ehu8m(u"࠿ᑐ"):
		scraperserver = EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧࡴࡥࡵࡥࡵ࡯࡮ࡨࡣࡱࡸ࠷࠭ᇾ")
		KoMfdTY495ngrIyp0 = CsDcLqQUVK4YBvHFW1(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹࠬࡰࡳࡱࡻࡽࡤࡩ࡯ࡶࡰࡷࡶࡾࡃࡁࡆࠨࡵࡩࡹࡻࡲ࡯ࡡࡳࡥ࡬࡫࡟ࡴࡱࡸࡶࡨ࡫࠽ࡵࡴࡸࡩࠫ࡬࡯ࡳࡹࡤࡶࡩࡥࡨࡦࡣࡧࡩࡷࡹ࠽ࡵࡴࡸࡩ࠿࠸ࡢ࠴࠶࠳ࡥ࠻࠾࠹࠱ࡣ࠸࠸࠵࠷ࡤࡣࡥ࠶࠻࠷ࡩ࠱࠲࠶࠸ࡨ࠾࠼࠲ࡦ࠺ࡃࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡪࡰࡪࡥࡳࡺ࠮ࡤࡱࡰ࠾࠽࠶࠸࠱ࠩᇿ")
		hL4w3zgankZR75698QCyi = YLKFRH6sSIrznXBg+OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩሀ")+KoMfdTY495ngrIyp0+ssynAg0zhSkoCpOMDV9(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪሁ")
		UWCLiFA6Yx2jEcDay = FlxDpgfQcuSWvGwtyC5d(iXYEGvtThUqFPJ4pHLZSnNRr29Ako,hL4w3zgankZR75698QCyi,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,Rs8EfockW2DUHiMbjlXVLPT47mwKrI,RRn6elHkAQU9XT3NtISJyLKM,mE7D5fBQZOKJdhtVUkHaIgRWpx,LhFAGlQ19zr,LhFAGlQ19zr)
	else:
		scraperserver,hL4w3zgankZR75698QCyi = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
		UWCLiFA6Yx2jEcDay = coFM7huzDdQ2()
		update = LhFAGlQ19zr
	if update and not UWCLiFA6Yx2jEcDay.succeeded:
		oo28t7rh90aqMBsnY(website,[],BVkb50EJPUy4RY1oZ7LN)
		if len(list(set(RXPS5CrAb01cmJB7T2ZgnQpUK8l)))>BkM54Kr7Qbqn:
			Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,O3OVuapf0YFjbm5oUQDg(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧሂ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"๊ࠬไฤีไࠤุ๐ัโำ้ࠣ฾อไอหࠣห้ำฬษࠢิๆ๊ࠦࠧሃ")+str(BVkb50EJPUy4RY1oZ7LN)+uulNDCPyef78(u"࠭ࠠโึ็ࠤๆ๐ฺࠠ็็๎ฮࠦสอษ๋ึࠥอไฮฮหࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡ็ะหํ๊ษࠡฬฯหํุࠠศๆะะอࠦๅาหࠣวำื้ࠡสสืฯิฯศ็ࠣื๏ืแา่ࠢาฯ๊แࠡมࠤࠫሄ"))
			if Scj7zgGFVA83otMpwUkxhm0BLN1==BkM54Kr7Qbqn:
				bAomiWyI5Bdexs9nKEqVGLS2Q.append(BVkb50EJPUy4RY1oZ7LN)
				UWCLiFA6Yx2jEcDay = QfvdwXOyPiLgZ2D95VJoarn8c17zp(iXYEGvtThUqFPJ4pHLZSnNRr29Ako,YLKFRH6sSIrznXBg,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,Rs8EfockW2DUHiMbjlXVLPT47mwKrI,RRn6elHkAQU9XT3NtISJyLKM,mE7D5fBQZOKJdhtVUkHaIgRWpx,Wsv5B14O6xFLqJ,iLXSma92HFtwhBKU,bAomiWyI5Bdexs9nKEqVGLS2Q)
				return UWCLiFA6Yx2jEcDay
	UWCLiFA6Yx2jEcDay.scrapernumber = str(BVkb50EJPUy4RY1oZ7LN)
	scraperserver = scraperserver+I18uSKaWhgTBeYUPD4sr(u"ࠧࠡ࠼ࠣࠫህ")+str(BVkb50EJPUy4RY1oZ7LN)
	UWCLiFA6Yx2jEcDay.scraperserver = scraperserver
	UWCLiFA6Yx2jEcDay.scraperurl = hL4w3zgankZR75698QCyi
	BwJdz71HqZNCGyOfj0lSPXL3R = QjAINyUC7MDRq5d8e4vl9(u"ࠨีํีๆืࠠาไ่ࠤࠬሆ")+UWCLiFA6Yx2jEcDay.scrapernumber
	if UWCLiFA6Yx2jEcDay.succeeded:
		Clc8sIj97ZrThF(wVhZ6bfkpSre95EFu,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+wdftVMyzF17cYETHu(u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡩࡩ࡫ࡤࠡࡤࡼࡴࡦࡹࡳࠡࡤ࡯ࡳࡨࡱࡩ࡯ࡩࠣࠤ࡙ࠥࡥࡳࡸࡨࡶ࠿࡛ࠦࠡࠩሇ")+scraperserver+AAbvaXV2DQzfNHdm4U3tT(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬለ")+mE7D5fBQZOKJdhtVUkHaIgRWpx+AAbvaXV2DQzfNHdm4U3tT(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪሉ")+YLKFRH6sSIrznXBg+C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬࠦ࡝ࠨሊ"))
		a6rVSjDMF87KyYINcuOP1l40Hbp(KfHAW8VGbrxi(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣฮัอ่ำࠢส่าาศࠨላ"),BwJdz71HqZNCGyOfj0lSPXL3R,uUqrNPcXKBoQ0slv=FgXzMs0YSDt(u"࠷࠶࠲ᑑ"))
	else:
		Clc8sIj97ZrThF(P3PazFblmtN,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+I18uSKaWhgTBeYUPD4sr(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡦࡾࡶࡡࡴࡵࠣࡦࡱࡵࡣ࡬࡫ࡱ࡫ࠥࠦࠠࡔࡧࡵࡺࡪࡸ࠺ࠡ࡝ࠣࠫሌ")+scraperserver+C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨࠢࡠࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨል")+str(UWCLiFA6Yx2jEcDay.code)+O3OVuapf0YFjbm5oUQDg(u"ࠩࠣࡡࠥࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫሎ")+UWCLiFA6Yx2jEcDay.reason+CsDcLqQUVK4YBvHFW1(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬሏ")+mE7D5fBQZOKJdhtVUkHaIgRWpx+uulNDCPyef78(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪሐ")+YLKFRH6sSIrznXBg+KfHAW8VGbrxi(u"ࠬࠦ࡝ࠨሑ"))
		a6rVSjDMF87KyYINcuOP1l40Hbp(ssynAg0zhSkoCpOMDV9(u"࠭แีๆอࠤ฾๋ไ๋หࠣฮัอ่ำࠢส่าาศࠨሒ"),BwJdz71HqZNCGyOfj0lSPXL3R,uUqrNPcXKBoQ0slv=EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠸࠷࠳ᑒ"))
	return UWCLiFA6Yx2jEcDay
def OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(NfMYGx1L4SW8FnC2uOzkP,zzekZcWL1sBgnoxN8f3vdQ0r,O6N8nhyYTD12KRApqkLzVi,GAwfpnzSiJEcHtQjDul1LsPN2YT0x9,showDialogs,mE7D5fBQZOKJdhtVUkHaIgRWpx):
	if not O6N8nhyYTD12KRApqkLzVi or isinstance(O6N8nhyYTD12KRApqkLzVi,dict): iXYEGvtThUqFPJ4pHLZSnNRr29Ako = FgXzMs0YSDt(u"ࠧࡈࡇࡗࠫሓ")
	else:
		iXYEGvtThUqFPJ4pHLZSnNRr29Ako = V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠨࡒࡒࡗ࡙࠭ሔ")
		O6N8nhyYTD12KRApqkLzVi = U2Z7CVFftTmLeK3nzEbQPGga(O6N8nhyYTD12KRApqkLzVi)
		VaZuxfQsH8BowcU5MkjLOn1,O6N8nhyYTD12KRApqkLzVi = lNyxXsMAcYHBUDh4dJbfTWR(O6N8nhyYTD12KRApqkLzVi)
	ND4YsIrucC = TBPcjsyOYoM82pm(NfMYGx1L4SW8FnC2uOzkP,iXYEGvtThUqFPJ4pHLZSnNRr29Ako,zzekZcWL1sBgnoxN8f3vdQ0r,O6N8nhyYTD12KRApqkLzVi,GAwfpnzSiJEcHtQjDul1LsPN2YT0x9,EsCplGc5N4mBuYW0RVQt6b,showDialogs,mE7D5fBQZOKJdhtVUkHaIgRWpx)
	Vpnd4wgPqAO1j6z8N = ND4YsIrucC.content
	Vpnd4wgPqAO1j6z8N = str(Vpnd4wgPqAO1j6z8N)
	return Vpnd4wgPqAO1j6z8N
def tQy9PbSu2EB4HVIa0n(zzekZcWL1sBgnoxN8f3vdQ0r):
	ZkF8gUeViBIJ4GhO0o1bLEl = zzekZcWL1sBgnoxN8f3vdQ0r.split(SnhLjmfeJC(u"ࠩࡿࢀࠬሕ"))
	YLKFRH6sSIrznXBg,aNqQDLfOzTK6,Ne7jpQSVGgR,AhqmcZCJOQ2jBsfEizgSaoXGT6b = ZkF8gUeViBIJ4GhO0o1bLEl[D2D96X5NGamBhrFwvL8VEbqiSfZIl],zA8Ry1KDvmr3w4B5xeP,zA8Ry1KDvmr3w4B5xeP,EsCplGc5N4mBuYW0RVQt6b
	for Uuqa3wD8CR1G6 in ZkF8gUeViBIJ4GhO0o1bLEl:
		if ggjO5CrKVRPITaesWkxD(u"ࠪࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨሖ") in Uuqa3wD8CR1G6: aNqQDLfOzTK6 = Uuqa3wD8CR1G6[o1INZ3ViQqS0Uw5z6kMjbv(u"࠳࠴ᑓ"):]
		elif V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠫࡒࡿࡄࡏࡕࡘࡶࡱࡃࠧሗ") in Uuqa3wD8CR1G6: Ne7jpQSVGgR = Uuqa3wD8CR1G6[V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠼ᑔ"):]
		elif OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠬࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪመ") in Uuqa3wD8CR1G6: AhqmcZCJOQ2jBsfEizgSaoXGT6b = LhFAGlQ19zr
	return YLKFRH6sSIrznXBg,aNqQDLfOzTK6,Ne7jpQSVGgR,AhqmcZCJOQ2jBsfEizgSaoXGT6b
def KKtUMZ1dwAavD(NfMYGx1L4SW8FnC2uOzkP,iXYEGvtThUqFPJ4pHLZSnNRr29Ako,zzekZcWL1sBgnoxN8f3vdQ0r,GhNuMU4kfygavDZSrAVB9IHqtJ8,xcXefk9DjoQtsu,GtPeH3Q9lk6C,GAwfpnzSiJEcHtQjDul1LsPN2YT0x9=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	kqsf4KGQ6dIz58 = VbHeOuU1ilzSp2ZRXwBD(zzekZcWL1sBgnoxN8f3vdQ0r,jL5CrsRwebpyDVXUc1EQP(u"࠭ࡵࡳ࡮ࠪሙ"))
	ILpKAdnzjeTQvi8HEcMDslBS4auCN = OdiZIyCfDUsW3JBGR2VAb.getSetting(N6NGJ4vpmidqMCh7yo(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩሚ")+GhNuMU4kfygavDZSrAVB9IHqtJ8)
	if kqsf4KGQ6dIz58==ILpKAdnzjeTQvi8HEcMDslBS4auCN: OdiZIyCfDUsW3JBGR2VAb.setSetting(O3OVuapf0YFjbm5oUQDg(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࠪማ")+GhNuMU4kfygavDZSrAVB9IHqtJ8,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	if ILpKAdnzjeTQvi8HEcMDslBS4auCN: MYWwFs7XA2 = zzekZcWL1sBgnoxN8f3vdQ0r.replace(kqsf4KGQ6dIz58,ILpKAdnzjeTQvi8HEcMDslBS4auCN)
	else:
		MYWwFs7XA2 = zzekZcWL1sBgnoxN8f3vdQ0r
		ILpKAdnzjeTQvi8HEcMDslBS4auCN = kqsf4KGQ6dIz58
	xmsOVkodWQ9ECanvR073l8 = TBPcjsyOYoM82pm(NfMYGx1L4SW8FnC2uOzkP,iXYEGvtThUqFPJ4pHLZSnNRr29Ako,MYWwFs7XA2,fy8iFgEkrO12NR9TWBI35sjY6qHvV,GAwfpnzSiJEcHtQjDul1LsPN2YT0x9,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,SnhLjmfeJC(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠴ࡷࡹ࠭ሜ"))
	Vpnd4wgPqAO1j6z8N = xmsOVkodWQ9ECanvR073l8.content
	if jTDWgftK7NEmx0JAkOn2aRIvweq:
		try: Vpnd4wgPqAO1j6z8N = Vpnd4wgPqAO1j6z8N.decode(Tk9eH2qw6Brsuhj,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪም"))
		except: pass
	if not xmsOVkodWQ9ECanvR073l8.succeeded or GtPeH3Q9lk6C not in Vpnd4wgPqAO1j6z8N:
		xcXefk9DjoQtsu = xcXefk9DjoQtsu.replace(ksJdoFWhxTz8Y2N7bOZE,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠫ࠰࠭ሞ"))
		YLKFRH6sSIrznXBg = AAbvaXV2DQzfNHdm4U3tT(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱࡫ࡴࡵࡧ࡭ࡧ࠱ࡧࡴࡳ࠯ࡴࡧࡤࡶࡨ࡮࠿ࡲ࠿ࠪሟ")+xcXefk9DjoQtsu
		naBFTDfp6lmKjeOywg87IAcb = {jL5CrsRwebpyDVXUc1EQP(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪሠ"):fy8iFgEkrO12NR9TWBI35sjY6qHvV}
		JOB9NFKAlRSW8eyTQDPaG7 = TBPcjsyOYoM82pm(NfMYGx1L4SW8FnC2uOzkP,iXYEGvtThUqFPJ4pHLZSnNRr29Ako,YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,naBFTDfp6lmKjeOywg87IAcb,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,AAbvaXV2DQzfNHdm4U3tT(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠳ࡰࡧࠫሡ"))
		if JOB9NFKAlRSW8eyTQDPaG7.succeeded:
			Vpnd4wgPqAO1j6z8N = JOB9NFKAlRSW8eyTQDPaG7.content
			if jTDWgftK7NEmx0JAkOn2aRIvweq:
				try: Vpnd4wgPqAO1j6z8N = Vpnd4wgPqAO1j6z8N.decode(Tk9eH2qw6Brsuhj,PlpyFa9QMKXxOD1cvHzmI(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨሢ"))
				except: pass
			zzECVswWcGAIXhrQlZ7jMokugnv = EcQxOa3RJm86WjTKA.findall(oRJAfwD957WkUyBM1Ehu8m(u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠴ࡢࡷࠫ࡞ࡂ࠲࠯ࡅࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤࠪሣ"),Vpnd4wgPqAO1j6z8N,EcQxOa3RJm86WjTKA.DOTALL)
			kMv4uEIwOrAbhJ2XlgeKUW9CjR = [ILpKAdnzjeTQvi8HEcMDslBS4auCN]
			D9kEcuhrItQ53jwaxFfzSoY = [EE1jeHnIoad(u"ࠪࡥࡵࡱࠧሤ"),AAbvaXV2DQzfNHdm4U3tT(u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࠫሥ"),sJw9QWiq1Kr0xfeVRI(u"ࠬࡺࡷࡪࡶࡷࡩࡷ࠭ሦ"),Hr25gta6XcqO(u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧሧ"),CsDcLqQUVK4YBvHFW1(u"ࠧࡧࡣࡦࡩࡧࡵ࡯࡬ࠩረ"),SnhLjmfeJC(u"ࠨࡲ࡫ࡴࠬሩ"),O3OVuapf0YFjbm5oUQDg(u"ࠩࡤࡸࡱࡧࡱࠨሪ"),Hr25gta6XcqO(u"ࠪࡷ࡮ࡺࡥࡪࡰࡧ࡭ࡨ࡫ࡳࠨራ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠫࡸࡻࡲ࠯࡮ࡼࠫሬ"),o1INZ3ViQqS0Uw5z6kMjbv(u"ࠬࡨ࡬ࡰࡩࡶࡴࡴࡺࠧር"),uulNDCPyef78(u"࠭ࡩ࡯ࡨࡲࡶࡲ࡫ࡲࠨሮ"),sIzDXlTHYUC5L3xZGnr(u"ࠧࡴ࡫ࡷࡩࡱ࡯࡫ࡦࠩሯ"),wdftVMyzF17cYETHu(u"ࠨ࡫ࡱࡷࡹࡧࡧࡳࡣࡰࠫሰ"),s5WMHyQN4mpie(u"ࠩࡶࡲࡦࡶࡣࡩࡣࡷࠫሱ"),ssynAg0zhSkoCpOMDV9(u"ࠪ࡬ࡹࡺࡰ࠮ࡧࡴࡹ࡮ࡼࠧሲ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠫ࡫ࡧࡳࡦ࡮ࡳࡰࡺࡹࠧሳ")]
			for XgiRnyU12TL8xocCIPK5DE in zzECVswWcGAIXhrQlZ7jMokugnv:
				if any(value in XgiRnyU12TL8xocCIPK5DE for value in D9kEcuhrItQ53jwaxFfzSoY): continue
				ILpKAdnzjeTQvi8HEcMDslBS4auCN = VbHeOuU1ilzSp2ZRXwBD(XgiRnyU12TL8xocCIPK5DE,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠬࡻࡲ࡭ࠩሴ"))
				if ILpKAdnzjeTQvi8HEcMDslBS4auCN in kMv4uEIwOrAbhJ2XlgeKUW9CjR: continue
				if len(kMv4uEIwOrAbhJ2XlgeKUW9CjR)==uulNDCPyef78(u"࠽ᑕ"):
					Clc8sIj97ZrThF(P3PazFblmtN,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+Hr25gta6XcqO(u"࠭ࠠࠡࠢࡊࡳࡴ࡭࡬ࡦࠢࡧ࡭ࡩࠦ࡮ࡰࡶࠣࡪ࡮ࡴࡤࠡࡣࠣࡲࡪࡽࠠࡩࡱࡶࡸࡳࡧ࡭ࡦࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭ስ")+GhNuMU4kfygavDZSrAVB9IHqtJ8+KfHAW8VGbrxi(u"ࠧࠡ࡟ࠣࠤࡔࡲࡤ࠻ࠢ࡞ࠤࠬሶ")+kqsf4KGQ6dIz58+KfHAW8VGbrxi(u"ࠨࠢࡠࠫሷ"))
					OdiZIyCfDUsW3JBGR2VAb.setSetting(AAbvaXV2DQzfNHdm4U3tT(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫሸ")+GhNuMU4kfygavDZSrAVB9IHqtJ8,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
					break
				kMv4uEIwOrAbhJ2XlgeKUW9CjR.append(ILpKAdnzjeTQvi8HEcMDslBS4auCN)
				MYWwFs7XA2 = zzekZcWL1sBgnoxN8f3vdQ0r.replace(kqsf4KGQ6dIz58,ILpKAdnzjeTQvi8HEcMDslBS4auCN)
				xmsOVkodWQ9ECanvR073l8 = TBPcjsyOYoM82pm(NfMYGx1L4SW8FnC2uOzkP,iXYEGvtThUqFPJ4pHLZSnNRr29Ako,MYWwFs7XA2,fy8iFgEkrO12NR9TWBI35sjY6qHvV,GAwfpnzSiJEcHtQjDul1LsPN2YT0x9,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Hr25gta6XcqO(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠷ࡷࡪࠧሹ"))
				Vpnd4wgPqAO1j6z8N = xmsOVkodWQ9ECanvR073l8.content
				if xmsOVkodWQ9ECanvR073l8.succeeded and GtPeH3Q9lk6C in Vpnd4wgPqAO1j6z8N:
					Clc8sIj97ZrThF(wVhZ6bfkpSre95EFu,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+sIzDXlTHYUC5L3xZGnr(u"ࠫࠥࠦࠠࡈࡱࡲ࡫ࡱ࡫ࠠࡧࡱࡸࡲࡩࠦࡡࠡࡰࡨࡻࠥ࡮࡯ࡴࡶࡱࡥࡲ࡫ࠠࠡࠢࡖ࡭ࡹ࡫࠺ࠡ࡝ࠣࠫሺ")+GhNuMU4kfygavDZSrAVB9IHqtJ8+I18uSKaWhgTBeYUPD4sr(u"ࠬࠦ࡝ࠡࠢࠣࡒࡪࡽ࠺ࠡ࡝ࠣࠫሻ")+ILpKAdnzjeTQvi8HEcMDslBS4auCN+Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠭ࠠ࡞ࠢࠣࡓࡱࡪ࠺ࠡ࡝ࠣࠫሼ")+kqsf4KGQ6dIz58+O3OVuapf0YFjbm5oUQDg(u"ࠧࠡ࡟ࠪሽ"))
					OdiZIyCfDUsW3JBGR2VAb.setSetting(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࠪሾ")+GhNuMU4kfygavDZSrAVB9IHqtJ8,ILpKAdnzjeTQvi8HEcMDslBS4auCN)
					break
	return ILpKAdnzjeTQvi8HEcMDslBS4auCN,MYWwFs7XA2,xmsOVkodWQ9ECanvR073l8
def eJYnofQG4mc8aFiN(YQDmGRx3CWc2HX9V0wa4O):
	Jw2cSxVMqt = {
	 SnhLjmfeJC(u"ࠩࡤ࡬ࡼࡧ࡫ࠨሿ")				:ssynAg0zhSkoCpOMDV9(u"้ࠪํู่ࠡล๊์ฬ้ࠠห์ไ๎ࠬቀ")
	,Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫࡦࡱ࡯ࡢ࡯ࠪቁ")				:Gcw2nelTR864XCVruO3mAFqI5a(u"๋่ࠬใ฻ࠣว่๎วๆࠢส่็ี๊ๆࠩቂ")
	,Hr25gta6XcqO(u"࠭ࡡ࡬ࡱࡤࡱࡨࡧ࡭ࠨቃ")				:Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠧๆ๊ๅ฽ࠥษใ้ษ่ࠤ่อๅࠨቄ")
	,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠨࡣ࡮ࡻࡦࡳࠧቅ")				:ggjO5CrKVRPITaesWkxD(u"่ࠩ์็฿ࠠฤๅ๋ห๊ࠦวๅฮา๎ิ࠭ቆ")
	,CsDcLqQUVK4YBvHFW1(u"ࠪࡥࡰࡽࡡ࡮ࡶࡸࡦࡪ࠭ቇ")			:wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"๊ࠫ๎โฺࠢส็ํอๅࠡฬํ์อ࠭ቈ")
	,Gcw2nelTR864XCVruO3mAFqI5a(u"ࠬࡧ࡬ࡢࡴࡤࡦࠬ቉")				:sIzDXlTHYUC5L3xZGnr(u"࠭ๅ้ไ฼ࠤ่๊ࠠศๆ฼ีอ࠭ቊ")
	,jL5CrsRwebpyDVXUc1EQP(u"ࠧࡢ࡮ࡩࡥࡹ࡯࡭ࡪࠩቋ")				:CsDcLqQUVK4YBvHFW1(u"ࠨ็๋ๆ฾ࠦวๅ็้ฬึࠦวๅใส฻๊๐ࠧቌ")
	,FmYoGejTnwKME7d9zPc(u"ࠩࡤࡰࡰࡧࡷࡵࡪࡤࡶࠬቍ")			:O3OVuapf0YFjbm5oUQDg(u"้ࠪํู่ࠡไ้หฮࠦวๅๅ๋ฯึ࠭቎")
	,oRJAfwD957WkUyBM1Ehu8m(u"ࠫࡦࡲ࡭ࡢࡣࡵࡩ࡫࠭቏")				:EQxFuqjw95WvaMm8Hnlt47XVihJ(u"๋่ࠬใ฻ࠣๆ๋อษࠡษ็้฾อัโࠩቐ")
	,sJw9QWiq1Kr0xfeVRI(u"࠭ࡡ࡭࡯ࡶࡸࡧࡧࠧቑ")				:AAbvaXV2DQzfNHdm4U3tT(u"ࠧๆ๊ๅ฽ࠥอไๆืฺฬฮ࠭ቒ")
	,SnhLjmfeJC(u"ࠨࡣࡱ࡭ࡲ࡫ࡺࡪࡦࠪቓ")				:oRJAfwD957WkUyBM1Ehu8m(u"่ࠩ์็฿ࠠศ่่๎ุࠥฯࠨቔ")
	,FmYoGejTnwKME7d9zPc(u"ࠪࡥࡷࡧࡢࡪࡥࡷࡳࡴࡴࡳࠨቕ")			:sIzDXlTHYUC5L3xZGnr(u"๊ࠫ๎โฺࠢอ์ฺุ๋ࠠำห๎ฮ࠭ቖ")
	,ggjO5CrKVRPITaesWkxD(u"ࠬࡧࡲࡢࡤࡶࡩࡪࡪࠧ቗")				:jL5CrsRwebpyDVXUc1EQP(u"࠭ๅ้ไ฼ࠤ฾ืศࠡีํ๎ิ࠭ቘ")
	,I18uSKaWhgTBeYUPD4sr(u"ࠧࡢࡴࡥࡰ࡮ࡵ࡮ࡻࠩ቙")				:FmYoGejTnwKME7d9zPc(u"ࠨ็๋ๆ฾ูࠦาส่ࠣ๏๎ๆำࠩቚ")
	,LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠩࡤࡽࡱࡵ࡬ࠨቛ")				:wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"้ࠪํู่ࠡลํ่ํ๊ࠧቜ")
	,Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫࡧࡵ࡫ࡳࡣࠪቝ")				:N6NGJ4vpmidqMCh7yo(u"๋่ࠬใ฻ࠣฬ่ืวࠨ቞")
	,KfHAW8VGbrxi(u"࠭ࡢࡳࡵࡷࡩ࡯࠭቟")				:uulNDCPyef78(u"ࠧๆ๊ๅ฽ࠥฮัิฬํะࠬበ")
	,LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨࡥ࡬ࡱࡦ࠺࠰࠱ࠩቡ")				:LYIgTBeSmZWotDh4bnyQkvM50siu(u"่ࠩ์็฿ࠠิ์่หࠥ࠺࠰࠱ࠩቢ")
	,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠪࡧ࡮ࡳࡡ࠵ࡲࠪባ")				:FgXzMs0YSDt(u"๊ࠫ๎โฺࠢึ๎๊อࠠโ๊ิࠤอ๐ࠧቤ")
	,ggjO5CrKVRPITaesWkxD(u"ࠬࡩࡩ࡮ࡣ࠷ࡹࠬብ")				:Gcw2nelTR864XCVruO3mAFqI5a(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢไ์ึ๐่ࠨቦ")
	,uulNDCPyef78(u"ࠧࡤ࡫ࡰࡥࡦࡨࡤࡰࠩቧ")				:sIzDXlTHYUC5L3xZGnr(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ฾ฮฯ้ࠩቨ")
	,aOQTKXFL54Nl60Zhp3MbE(u"ࠩࡦ࡭ࡲࡧࡣ࡭ࡷࡥࠫቩ")				:PlpyFa9QMKXxOD1cvHzmI(u"้ࠪํู่ࠡีํ้ฬࠦใๅ๊หࠫቪ")
	,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠫࡨ࡯࡭ࡢࡥ࡯ࡹࡧࡽ࡯ࡳ࡭ࠪቫ")			:EE1jeHnIoad(u"๋่ࠬใ฻ࠣื๏๋วࠡๅ็์อูࠦๆๆࠪቬ")
	,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠭ࡣࡪ࡯ࡤࡧࡱࡻࡰࠨቭ")				:aOQTKXFL54Nl60Zhp3MbE(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ็้๎ศࠨቮ")
	,oRJAfwD957WkUyBM1Ehu8m(u"ࠨࡥ࡬ࡱࡦ࡬ࡡ࡯ࡵࠪቯ")				:uulNDCPyef78(u"่ࠩ์็฿ࠠิ์่หࠥ็ว็ิࠪተ")
	,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠪࡧ࡮ࡳࡡࡧࡴࡨࡩࠬቱ")				:OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"๊ࠫ๎โฺࠢึ๎๊อࠠโำํࠫቲ")
	,I18uSKaWhgTBeYUPD4sr(u"ࠬࡩࡩ࡮ࡣ࡯࡭࡬࡮ࡴࠨታ")			:C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢ็ห๏ะࠧቴ")
	,ssynAg0zhSkoCpOMDV9(u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨት")				:EE1jeHnIoad(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ๋อ่ࠨቶ")
	,AAbvaXV2DQzfNHdm4U3tT(u"ࠩࡦ࡭ࡲࡧࡷࡣࡣࡶࠫቷ")				:Gcw2nelTR864XCVruO3mAFqI5a(u"้ࠪํู่ࠡีํ้ฬ่ࠦษีࠪቸ")
	,sIzDXlTHYUC5L3xZGnr(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩቹ")			:aOQTKXFL54Nl60Zhp3MbE(u"๋่ࠬใ฻ࠣำฬ๐ไ๋่ࠢ์ู์ࠧቺ")
	,AAbvaXV2DQzfNHdm4U3tT(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ቻ")	:wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧๆ๊ๅ฽ࠥีว๋ๆํࠤ๊๎ิ็่ࠢืฯิฯๆ์้ࠫቼ")
	,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡨࡢࡵ࡫ࡸࡦ࡭ࡳࠨች")	:PlpyFa9QMKXxOD1cvHzmI(u"่ࠩ์็฿ࠠะษํ่๏ࠦๅ้ึ้ࠤ์อิหษๆࠫቾ")
	,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮࡮࡬ࡺࡪࡹࠧቿ")	:wdftVMyzF17cYETHu(u"๊ࠫ๎โฺࠢาห๏๊๊ࠡ็ุ๋๋ࠦๅษษืีࠬኀ")
	,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭ኁ"):aOQTKXFL54Nl60Zhp3MbE(u"࠭ๅ้ไ฼ࠤิอ๊ๅ์้ࠣํฺๆࠡไ๋หห๋ࠧኂ")
	,sJw9QWiq1Kr0xfeVRI(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡺ࡯ࡱ࡫ࡦࡷࠬኃ")	:jL5CrsRwebpyDVXUc1EQP(u"ࠨ็๋ๆ฾ࠦฯศ์็๎๋่ࠥี่้ࠣํอึ๋฻ࠪኄ")
	,N6NGJ4vpmidqMCh7yo(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡷ࡫ࡧࡩࡴࡹࠧኅ")	:N6NGJ4vpmidqMCh7yo(u"้ࠪํู่ࠡัส๎้๐ࠠๆ๊ื๊ࠥ็๊ะ์๋๋ฬะࠧኆ")
	,LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠭ኇ")				:ssynAg0zhSkoCpOMDV9(u"๋ࠬส้ไไࠫኈ")
	,o1INZ3ViQqS0Uw5z6kMjbv(u"࠭ࡤࡳࡣࡰࡥࡨࡧࡦࡦࠩ኉")			:o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧๆ๊ๅ฽ࠥีัศ็สࠤ่อแ๋้ࠪኊ")
	,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠨࡦࡵࡥࡲࡧࡳ࠸ࠩኋ")				:EQxFuqjw95WvaMm8Hnlt47XVihJ(u"่ࠩ์็฿ࠠะำส้ฬࠦีฮࠩኌ")
	,wdftVMyzF17cYETHu(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࠫኍ")				:FmYoGejTnwKME7d9zPc(u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠬ኎")
	,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠷ࠧ኏")				:V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠲ࠩነ")
	,CsDcLqQUVK4YBvHFW1(u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠳ࠩኑ")				:uulNDCPyef78(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠵ࠫኒ")
	,KfHAW8VGbrxi(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠶ࠫና")				:EQxFuqjw95WvaMm8Hnlt47XVihJ(u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠸࠭ኔ")
	,N6NGJ4vpmidqMCh7yo(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠹࠭ን")				:KfHAW8VGbrxi(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠴ࠨኖ")
	,aOQTKXFL54Nl60Zhp3MbE(u"࠭ࡥࡨࡻࡥࡩࡸࡺࡶࡪࡲࠪኗ")			:C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡࡸ࡬ࡴࠬኘ")
	,oRJAfwD957WkUyBM1Ehu8m(u"ࠨࡧࡪࡽࡩ࡫ࡡࡥࠩኙ")				:O3OVuapf0YFjbm5oUQDg(u"่ࠩ์็฿ࠠฦ์ฯ๎ࠥี๊ะࠩኚ")
	,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠪࡩ࡬ࡿ࡮ࡰࡹࠪኛ")				:uulNDCPyef78(u"๊ࠫ๎โฺࠢศ๎ั๐ࠠ็ษ๋ࠫኜ")
	,sJw9QWiq1Kr0xfeVRI(u"ࠬ࡫࡬ࡤ࡫ࡱࡩࡲࡧࠧኝ")				:FmYoGejTnwKME7d9zPc(u"࠭ๅ้ไ฼ࠤ๊๎ำ้฻ฬࠤฬ๊ำ๋่่หࠬኞ")
	,SnhLjmfeJC(u"ࠧࡦ࡮࡬ࡪࡻ࡯ࡤࡦࡱࠪኟ")			:LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨ็๋ๆ฾ࠦรๅ์ไࠤๆ๐ฯ๋๊ࠪአ")
	,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠩࡩࡥࡧࡸࡡ࡬ࡣࠪኡ")				:wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"้ࠪํู่ࠡใหี่ฯࠧኢ")
	,FgXzMs0YSDt(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫኣ")				:Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠬ็ิๅࠩኤ")
	,I18uSKaWhgTBeYUPD4sr(u"࠭ࡦࡢ࡬ࡨࡶࡸ࡮࡯ࡸࠩእ")			:wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧๆ๊ๅ฽ࠥ็ฬาࠢื์ࠬኦ")
	,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠨࡨࡤࡶࡪࡹ࡫ࡰࠩኧ")				:I18uSKaWhgTBeYUPD4sr(u"่ࠩ์็฿ࠠโษิื่๎ࠧከ")
	,Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪࡪࡦࡹࡥ࡭ࡪࡧ࠵ࠬኩ")				:PlpyFa9QMKXxOD1cvHzmI(u"๊ࠫ๎โฺࠢไหฺ๊ࠠศๆฦ์้࠭ኪ")
	,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠸ࠧካ")				:FmYoGejTnwKME7d9zPc(u"࠭ๅ้ไ฼ࠤๆอีๅࠢส่ะอๆ๋ࠩኬ")
	,aOQTKXFL54Nl60Zhp3MbE(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧክ")				:QjAINyUC7MDRq5d8e4vl9(u"ࠨ็ฯ่ิ࠭ኮ")
	,O3OVuapf0YFjbm5oUQDg(u"ࠩࡩࡳࡸࡺࡡࠨኯ")				:Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"้ࠪํู่ࠡใ๋ืฯอࠧኰ")
	,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠫ࡫ࡻ࡮ࡰࡰࡷࡺࠬ኱")				:wdftVMyzF17cYETHu(u"๋่ࠬใ฻ࠣๅ๋๎ๆࠡฬํๅ๏࠭ኲ")
	,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠭ࡦࡶࡵ࡫ࡥࡷࡺࡶࠨኳ")				:Gcw2nelTR864XCVruO3mAFqI5a(u"ࠧๆ๊ๅ฽ࠥ็่ีษิࠤฯ๐แ๋ࠩኴ")
	,wdftVMyzF17cYETHu(u"ࠨࡨࡸࡷ࡭ࡧࡲࡷ࡫ࡧࡩࡴ࠭ኵ")			:sIzDXlTHYUC5L3xZGnr(u"่ࠩ์็฿ࠠโ๊ืหึࠦแ๋ัํ์ࠬ኶")
	,SnhLjmfeJC(u"ࠪ࡫ࡴࡵࡤࠨ኷")					:jL5CrsRwebpyDVXUc1EQP(u"ࠫั๐ฯࠨኸ")
	,oRJAfwD957WkUyBM1Ehu8m(u"ࠬ࡮ࡡ࡭ࡣࡦ࡭ࡲࡧࠧኹ")				:SnhLjmfeJC(u"࠭ๅ้ไ฼ࠤ์๊วࠡีํ้ฬ࠭ኺ")
	,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠧࡩࡧ࡯ࡥࡱ࠭ኻ")				:uulNDCPyef78(u"ࠨ็๋ๆ฾ࠦ็ๅษ็ࠤ๏๎ส๋๊หࠫኼ")
	,Hr25gta6XcqO(u"ࠩ࡬ࡪ࡮ࡲ࡭ࠨኽ")				:I18uSKaWhgTBeYUPD4sr(u"้ࠪํู่ࠡไ้หฮࠦย๋ࠢไ๎้๋ࠧኾ")
	,aOQTKXFL54Nl60Zhp3MbE(u"ࠫ࡮࡬ࡩ࡭࡯࠰ࡥࡷࡧࡢࡪࡥࠪ኿")			:FgXzMs0YSDt(u"๋่ࠬใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠢ฼ีอ๐ࠧዀ")
	,aOQTKXFL54Nl60Zhp3MbE(u"࠭ࡩࡧ࡫࡯ࡱ࠲࡫࡮ࡨ࡮࡬ࡷ࡭࠭዁")		:sJw9QWiq1Kr0xfeVRI(u"ࠧๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠤฬ์ฬๅ์ี๎ࠬዂ")
	,vU6DxuzPwMpg(u"ࠨ࡫ࡳࡸࡻ࠭ዃ")					:QjAINyUC7MDRq5d8e4vl9(u"ࠩࡌࡔ࡙࡜ࠧዄ")
	,ggjO5CrKVRPITaesWkxD(u"ࠪ࡭ࡵࡺࡶ࠮࡮࡬ࡺࡪ࠭ዅ")			:aOQTKXFL54Nl60Zhp3MbE(u"ࠫࡎࡖࡔࡗࠢๅ๊ํอสࠨ዆")
	,sJw9QWiq1Kr0xfeVRI(u"ࠬ࡯ࡰࡵࡸ࠰ࡱࡴࡼࡩࡦࡵࠪ዇")			:oRJAfwD957WkUyBM1Ehu8m(u"࠭ࡉࡑࡖ࡙ࠤศ็ไศ็ࠪወ")
	,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧࡪࡲࡷࡺ࠲ࡹࡥࡳ࡫ࡨࡷࠬዉ")			:s5WMHyQN4mpie(u"ࠨࡋࡓࡘ࡛ࠦๅิๆึ่ฬะࠧዊ")
	,QjAINyUC7MDRq5d8e4vl9(u"ࠩ࡮ࡥࡷࡨࡡ࡭ࡣࡷࡺࠬዋ")			:uulNDCPyef78(u"้ࠪํู่ࠡไ้หฮࠦใาส็หฦ࠭ዌ")
	,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠫࡰࡧࡴ࡬ࡱࡷࡸࡻ࠭ው")				:N6NGJ4vpmidqMCh7yo(u"๋่ࠬใ฻ࠣ็ฯ้่หࠢอ๎ๆ๐ࠧዎ")
	,LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥࠨዏ")				:oRJAfwD957WkUyBM1Ehu8m(u"ࠧๆ๊ๅ฽้ࠥสไ๊อࠫዐ")
	,uulNDCPyef78(u"ࠨ࡭࡬ࡶࡲࡧ࡬࡬ࠩዑ")				:SnhLjmfeJC(u"่ࠩ์็฿ࠠไำ่ห้้ࠧዒ")
	,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪࡰࡦࡸ࡯ࡻࡣࠪዓ")				:vU6DxuzPwMpg(u"๊ࠫ๎โฺࠢ็หึ๎าศࠩዔ")
	,Hr25gta6XcqO(u"ࠬࡲࡩࡣࡴࡤࡶࡾ࠭ዕ")				:oRJAfwD957WkUyBM1Ehu8m(u"࠭ๅๅใࠪዖ")
	,jL5CrsRwebpyDVXUc1EQP(u"ࠧ࡭࡫ࡹࡩࠬ዗")					:Hr25gta6XcqO(u"ࠨไ้หฮ࠭ዘ")
	,vU6DxuzPwMpg(u"ࠩ࡯࡭ࡻ࡫ࡴࡷࠩዙ")				:ggjO5CrKVRPITaesWkxD(u"้้ࠪ็ࠧዚ")
	,sJw9QWiq1Kr0xfeVRI(u"ࠫࡱࡵࡤࡺࡰࡨࡸࠬዛ")				:wdftVMyzF17cYETHu(u"๋่ࠬใ฻่ࠣํี๊่ࠡอࠫዜ")
	,AAbvaXV2DQzfNHdm4U3tT(u"࠭࡭࠴ࡷࠪዝ")					:oRJAfwD957WkUyBM1Ehu8m(u"ࠧࡎ࠵ࡘࠫዞ")
	,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠨ࡯࠶ࡹ࠲ࡲࡩࡷࡧࠪዟ")				:uulNDCPyef78(u"ࠩࡐ࠷࡚ࠦโ็๊สฮࠬዠ")
	,s5WMHyQN4mpie(u"ࠪࡱ࠸ࡻ࠭࡮ࡱࡹ࡭ࡪࡹࠧዡ")			:C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠫࡒ࠹ࡕࠡลไ่ฬ๋ࠧዢ")
	,Hr25gta6XcqO(u"ࠬࡳ࠳ࡶ࠯ࡶࡩࡷ࡯ࡥࡴࠩዣ")			:N6NGJ4vpmidqMCh7yo(u"࠭ࡍ࠴ࡗุ้๊ࠣำๅษอࠫዤ")
	,wdftVMyzF17cYETHu(u"ࠧ࡮ࡣࡶࡥࡻ࡯ࡤࡦࡱࠪዥ")			:Hr25gta6XcqO(u"ࠨ็๋ๆ฾ࠦๅศีสࠤๆ๐ฯ๋๊ࠪዦ")
	,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪዧ")				:V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"้ࠪๆ่่ะࠩየ")
	,sJw9QWiq1Kr0xfeVRI(u"ࠫࡲࡵࡶࡴ࠶ࡸࠫዩ")				:o1INZ3ViQqS0Uw5z6kMjbv(u"๋่ࠬใ฻้ࠣํ็าࠡใ๋ี๏๎ࠧዪ")
	,sJw9QWiq1Kr0xfeVRI(u"࠭࡭ࡺࡥ࡬ࡱࡦ࠭ያ")				:uulNDCPyef78(u"ࠧๆ๊ๅ฽๋ࠥว๋ࠢึ๎๊อࠧዬ")
	,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨࡱ࡯ࡨࠬይ")					:oRJAfwD957WkUyBM1Ehu8m(u"ࠩๅำ๏๋ࠧዮ")
	,SnhLjmfeJC(u"ࠪࡴࡦࡴࡥࡵࠩዯ")				:sIzDXlTHYUC5L3xZGnr(u"๊ࠫ๎โฺࠢหห๋๐สࠨደ")
	,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡲࡵࡶࡪࡧࡶࠫዱ")			:KfHAW8VGbrxi(u"࠭ๅ้ไ฼ࠤออๆ๋ฬࠣหๆ๊วๆࠩዲ")
	,AAbvaXV2DQzfNHdm4U3tT(u"ࠧࡱࡣࡱࡩࡹ࠳ࡳࡦࡴ࡬ࡩࡸ࠭ዳ")			:ssynAg0zhSkoCpOMDV9(u"ࠨ็๋ๆ฾ࠦศศ่ํฮ๋ࠥำๅี็หฯ࠭ዴ")
	,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠩࡴࡪ࡮ࡲ࡭ࠨድ")				:O3OVuapf0YFjbm5oUQDg(u"้ࠪํู่ࠡๅํ์ࠥ็๊ๅ็ࠪዶ")
	,aOQTKXFL54Nl60Zhp3MbE(u"ࠫࡸ࡫ࡲࡪࡧࡶࡸ࡮ࡳࡥࠨዷ")			:C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"๋่ࠬใ฻ࠣื๏ื๊ิࠢอห๏๋ࠧዸ")
	,CsDcLqQUVK4YBvHFW1(u"࠭ࡳࡩࡣࡥࡥࡰࡧࡴࡺࠩዹ")			:EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧๆ๊ๅ฽ฺࠥศไฬํࠫዺ")
	,aOQTKXFL54Nl60Zhp3MbE(u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪዻ")				:wdftVMyzF17cYETHu(u"่ࠩ์็฿ࠠีษ๊ำࠥ็่า์๋ࠫዼ")
	,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪࡷ࡭ࡧࡨࡪࡦࡱࡩࡼࡹࠧዽ")			:QjAINyUC7MDRq5d8e4vl9(u"๊ࠫ๎โฺࠢืห์ีࠠ็์๋ึࠬዾ")
	,aOQTKXFL54Nl60Zhp3MbE(u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥࠨዿ")			:CsDcLqQUVK4YBvHFW1(u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠨጀ")
	,EE1jeHnIoad(u"ࠧࡴࡪ࡬ࡥࡻࡵࡩࡤࡧ࠰ࡥࡱࡨࡵ࡮ࡵࠪጁ")		:sIzDXlTHYUC5L3xZGnr(u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠣห้ฮ่ๆࠩጂ")
	,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩࡶ࡬࡮ࡧࡶࡰ࡫ࡦࡩ࠲ࡧࡵࡥ࡫ࡲࡷࠬጃ")		:C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠥ฻่ห์สฮࠬጄ")
	,sIzDXlTHYUC5L3xZGnr(u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫࠭ࡱࡧࡵࡷࡴࡴࡳࠨጅ")	:o1INZ3ViQqS0Uw5z6kMjbv(u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠠใษิสࠬጆ")
	,jL5CrsRwebpyDVXUc1EQP(u"࠭ࡳࡩࡱࡩ࡬ࡦ࠭ጇ")				:oRJAfwD957WkUyBM1Ehu8m(u"ࠧๆ๊ๅ฽ฺ่ࠥโ้สࠤฯ๐แ๋ࠩገ")
	,QjAINyUC7MDRq5d8e4vl9(u"ࠨࡵ࡫ࡳࡴ࡬࡭ࡢࡺࠪጉ")				:LYIgTBeSmZWotDh4bnyQkvM50siu(u"่ࠩ์็฿ࠠี๊ไࠤ๊อใิࠩጊ")
	,s5WMHyQN4mpie(u"ࠪࡷ࡭ࡵ࡯ࡧࡰࡨࡸࠬጋ")				:sJw9QWiq1Kr0xfeVRI(u"๊ࠫ๎โฺࠢื์ๆࠦๆหࠩጌ")
	,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬࡹࡨࡰࡱࡩࡴࡷࡵࠧግ")				:s5WMHyQN4mpie(u"࠭ๅ้ไ฼ࠤู๎แࠡสิ์ࠬጎ")
	,vU6DxuzPwMpg(u"ࠧࡵ࡫࡮ࡥࡦࡺࠧጏ")				:Gcw2nelTR864XCVruO3mAFqI5a(u"ࠨ็๋ๆ฾ࠦสไษอࠫጐ")
	,QjAINyUC7MDRq5d8e4vl9(u"ࠩࡷࡺ࡫ࡻ࡮ࠨ጑")				:V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"้ࠪํู่ࠡฬํๅ๏ࠦแศ่ࠪጒ")
	,oRJAfwD957WkUyBM1Ehu8m(u"ࠫࡻࡧࡲࡣࡱࡱࠫጓ")				:SnhLjmfeJC(u"๋่ࠬใ฻ࠣๅฬืศ้่ࠪጔ")
	,jL5CrsRwebpyDVXUc1EQP(u"࠭ࡶࡪࡦࡨࡳࠬጕ")				:PlpyFa9QMKXxOD1cvHzmI(u"ࠧโ์า๎ํ࠭጖")
	,oRJAfwD957WkUyBM1Ehu8m(u"ࠨࡸ࡬ࡨࡪࡵ࡮ࡴࡣࡨࡱࠬ጗")			:Hr25gta6XcqO(u"่ࠩ์็฿ࠠโ์า๎ํࠦๆิษษ้ࠬጘ")
	,AAbvaXV2DQzfNHdm4U3tT(u"ࠪࡻࡪࡩࡩ࡮ࡣ࠴ࠫጙ")				:O3OVuapf0YFjbm5oUQDg(u"๊ࠫ๎โฺ๋ࠢ๎ู๊ࠥๆษࠣ࠵ࠬጚ")
	,oRJAfwD957WkUyBM1Ehu8m(u"ࠬࡽࡥࡤ࡫ࡰࡥ࠷࠭ጛ")				:vU6DxuzPwMpg(u"࠭ๅ้ไ฼ࠤํ๐ࠠิ์่หࠥ࠸ࠧጜ")
	,SnhLjmfeJC(u"ࠧࡺࡣࡴࡳࡹ࠭ጝ")				:AAbvaXV2DQzfNHdm4U3tT(u"ࠨ็๋ๆ฾๊ࠦศไ๋ฮࠬጞ")
	,sJw9QWiq1Kr0xfeVRI(u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪጟ")				:FmYoGejTnwKME7d9zPc(u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠨጠ")
	,sIzDXlTHYUC5L3xZGnr(u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠲ࡩࡨࡢࡰࡱࡩࡱࡹࠧጡ")		:sJw9QWiq1Kr0xfeVRI(u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣๆ๋๎วหࠩጢ")
	,ggjO5CrKVRPITaesWkxD(u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠭ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪጣ")	:OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬ่่ࠥศศ่ࠫጤ")
	,QjAINyUC7MDRq5d8e4vl9(u"ࠨࡻࡲࡹࡹࡻࡢࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠩጥ")		:FmYoGejTnwKME7d9zPc(u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠโ์า๎ํํวหࠩጦ")
	,QjAINyUC7MDRq5d8e4vl9(u"ࠪࡽࡹࡨ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩጧ")			:oRJAfwD957WkUyBM1Ehu8m(u"๊ࠫ๎วใ฻้๋๊้ࠣࠦฬํ์อ࠭ጨ")
	}
	xqEX4NC2hpWf8SVBi3DlP51n9gtFK = YQDmGRx3CWc2HX9V0wa4O.lower()
	for key in list(Jw2cSxVMqt.keys()):
		h4spaDm7xLTHOi5RXP0 = key.lower()
		if xqEX4NC2hpWf8SVBi3DlP51n9gtFK==h4spaDm7xLTHOi5RXP0:
			YQDmGRx3CWc2HX9V0wa4O = Jw2cSxVMqt[key]
			break
	return YQDmGRx3CWc2HX9V0wa4O
def n9grXGiQYD2wl8UjSRe3HcKhE():
	lgLp2rPtWsycxonO3jk = bEWpDHXjCBqd7aOiN6UG5k.executeJSONRPC(LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡕࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡃ࡭ࡧࡤࡶࠧ࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡴࡱࡧࡹ࡭࡫ࡶࡸ࡮ࡪࠢ࠻࠳ࢀࢁࠬጩ"))
	raise ValueError(sJw9QWiq1Kr0xfeVRI(u"࠭࡟ࡠࡡࡉࡓࡗࡉࡅࡠࡇ࡛ࡍ࡙ࡥ࡟ࡠࠩጪ"))
def ejX7kGtQ4hcYUHW9b31vriuZLM6Sp(edUlRNCvFSsBpLWV,mFbhI5Ouv8qDs=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	I4t9qonjrm.g503yRKdMjBLnGw2E4SuOvVH9t = EsCplGc5N4mBuYW0RVQt6b
	if not mFbhI5Ouv8qDs and edUlRNCvFSsBpLWV: mFbhI5Ouv8qDs = jL5CrsRwebpyDVXUc1EQP(u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡠࡔࡈࡊࡗࡋࡓࡉࡡࡆࡅࡈࡎࡅࠨጫ")
	OdiZIyCfDUsW3JBGR2VAb.setSetting(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬጬ"),mFbhI5Ouv8qDs)
	return
def DVX5GWhnIxYlSd9rEuetjk40UJ(zzekZcWL1sBgnoxN8f3vdQ0r,mWojnYXIlP09cKdZ3k1ep2sMy=PlpyFa9QMKXxOD1cvHzmI(u"ࠩ࠽࠳ࠬጭ")):
	return _KSjY2bJ73pQ0hqvVtZT(zzekZcWL1sBgnoxN8f3vdQ0r,mWojnYXIlP09cKdZ3k1ep2sMy)
def lyTJS23j0FZCGHQuRM6s7nrIL5aXBz(smjRidwEPl):
	if smjRidwEPl in [fy8iFgEkrO12NR9TWBI35sjY6qHvV,oRJAfwD957WkUyBM1Ehu8m(u"ࠪ࠴ࠬጮ"),D2D96X5NGamBhrFwvL8VEbqiSfZIl]: return fy8iFgEkrO12NR9TWBI35sjY6qHvV
	smjRidwEPl = int(smjRidwEPl)
	TWN4rX37HFjLuOMEdUvnYsZ6G5BxJ = smjRidwEPl^rrux12tcwQl5
	hE0D9VWZrNQGp4Yan3 = smjRidwEPl^CQOaFUrZJHwKRxIj4yXEYs5V
	ee0jbsxfaiNQgtp9HnALcUqYD3vMdK = smjRidwEPl^d9vcuo3Hy7RhAk2
	RGboVviD0qMAf = str(TWN4rX37HFjLuOMEdUvnYsZ6G5BxJ)+str(hE0D9VWZrNQGp4Yan3)+str(ee0jbsxfaiNQgtp9HnALcUqYD3vMdK)
	return RGboVviD0qMAf
def llbhCFwkMPBgX68H(smjRidwEPl):
	if smjRidwEPl in [fy8iFgEkrO12NR9TWBI35sjY6qHvV,sJw9QWiq1Kr0xfeVRI(u"ࠫ࠵࠭ጯ"),D2D96X5NGamBhrFwvL8VEbqiSfZIl]: return fy8iFgEkrO12NR9TWBI35sjY6qHvV
	smjRidwEPl = str(smjRidwEPl)
	RGboVviD0qMAf = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if len(smjRidwEPl)==EE1jeHnIoad(u"࠶࠻ᑖ"):
		TWN4rX37HFjLuOMEdUvnYsZ6G5BxJ,hE0D9VWZrNQGp4Yan3,ee0jbsxfaiNQgtp9HnALcUqYD3vMdK = smjRidwEPl[D2D96X5NGamBhrFwvL8VEbqiSfZIl:vD4Fh6ictZ7wME],smjRidwEPl[vD4Fh6ictZ7wME:vU6DxuzPwMpg(u"࠿ᑗ")],smjRidwEPl[vU6DxuzPwMpg(u"࠿ᑗ"):]
		TWN4rX37HFjLuOMEdUvnYsZ6G5BxJ = int(TWN4rX37HFjLuOMEdUvnYsZ6G5BxJ)^d9vcuo3Hy7RhAk2
		hE0D9VWZrNQGp4Yan3 = int(hE0D9VWZrNQGp4Yan3)^CQOaFUrZJHwKRxIj4yXEYs5V
		ee0jbsxfaiNQgtp9HnALcUqYD3vMdK = int(ee0jbsxfaiNQgtp9HnALcUqYD3vMdK)^rrux12tcwQl5
		if TWN4rX37HFjLuOMEdUvnYsZ6G5BxJ==hE0D9VWZrNQGp4Yan3==ee0jbsxfaiNQgtp9HnALcUqYD3vMdK: RGboVviD0qMAf = str(TWN4rX37HFjLuOMEdUvnYsZ6G5BxJ*sIzDXlTHYUC5L3xZGnr(u"࠶࠱ᑘ"))
	return RGboVviD0qMAf
def UAIXp7GJvrH64(smjRidwEPl,qB0YxZFbGgc8PduTKWyefCoh26=vU6DxuzPwMpg(u"ࠬ࠼࠳࠹࠶࠴࠼࠷࠹ࠧጰ")):
	if smjRidwEPl==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return fy8iFgEkrO12NR9TWBI35sjY6qHvV
	smjRidwEPl = int(smjRidwEPl)+int(qB0YxZFbGgc8PduTKWyefCoh26)
	TWN4rX37HFjLuOMEdUvnYsZ6G5BxJ = smjRidwEPl^rrux12tcwQl5
	hE0D9VWZrNQGp4Yan3 = smjRidwEPl^CQOaFUrZJHwKRxIj4yXEYs5V
	ee0jbsxfaiNQgtp9HnALcUqYD3vMdK = smjRidwEPl^d9vcuo3Hy7RhAk2
	RGboVviD0qMAf = str(TWN4rX37HFjLuOMEdUvnYsZ6G5BxJ)+str(hE0D9VWZrNQGp4Yan3)+str(ee0jbsxfaiNQgtp9HnALcUqYD3vMdK)
	return RGboVviD0qMAf
def GGjBAkoVdze0hyCFK8v5L7(smjRidwEPl,qB0YxZFbGgc8PduTKWyefCoh26=Gcw2nelTR864XCVruO3mAFqI5a(u"࠭࠶࠴࠺࠷࠵࠽࠸࠳ࠨጱ")):
	if smjRidwEPl==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return fy8iFgEkrO12NR9TWBI35sjY6qHvV
	smjRidwEPl = str(smjRidwEPl)
	E54tJlkzYXay6UjCD7Tu2sPofNc83 = int(len(smjRidwEPl)/XW57OCeGnFTLQbaqdrD9zM)
	TWN4rX37HFjLuOMEdUvnYsZ6G5BxJ = int(smjRidwEPl[D2D96X5NGamBhrFwvL8VEbqiSfZIl:E54tJlkzYXay6UjCD7Tu2sPofNc83])^rrux12tcwQl5
	hE0D9VWZrNQGp4Yan3 = int(smjRidwEPl[E54tJlkzYXay6UjCD7Tu2sPofNc83:teaC5j4HuGDqpwcmUzJ*E54tJlkzYXay6UjCD7Tu2sPofNc83])^CQOaFUrZJHwKRxIj4yXEYs5V
	ee0jbsxfaiNQgtp9HnALcUqYD3vMdK = int(smjRidwEPl[teaC5j4HuGDqpwcmUzJ*E54tJlkzYXay6UjCD7Tu2sPofNc83:XW57OCeGnFTLQbaqdrD9zM*E54tJlkzYXay6UjCD7Tu2sPofNc83])^d9vcuo3Hy7RhAk2
	RGboVviD0qMAf = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if TWN4rX37HFjLuOMEdUvnYsZ6G5BxJ==hE0D9VWZrNQGp4Yan3==ee0jbsxfaiNQgtp9HnALcUqYD3vMdK: RGboVviD0qMAf = str(int(TWN4rX37HFjLuOMEdUvnYsZ6G5BxJ)-int(qB0YxZFbGgc8PduTKWyefCoh26))
	return RGboVviD0qMAf
def A2uH73pxqFvDV1GfogEnKs(z5g9IPWO1skfHr2bjxK8vD):
	hhG9zY1XNDyFverMgSnxEW = I4t9qonjrm.SITESURLS[aOQTKXFL54Nl60Zhp3MbE(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧጲ")][I18uSKaWhgTBeYUPD4sr(u"࠹ᑙ")]
	vvkUmAixH2X9BzGTPEusYM = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(uugoLac4UGZztBeijxW1k0,ggjO5CrKVRPITaesWkxD(u"ࠨࡴࡨࡷࡴࡻࡲࡤࡧࡶࠫጳ"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠩࡶ࡯࡮ࡴࡳࠨጴ"),ggjO5CrKVRPITaesWkxD(u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫጵ"),oRJAfwD957WkUyBM1Ehu8m(u"ࠫ࠼࠸࠰ࡱࠩጶ"),EE1jeHnIoad(u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡈࡵ࡮ࡧ࡫ࡵࡱ࡙࡮ࡲࡦࡧࡅࡹࡹࡺ࡯࡯ࡵ࠱ࡼࡲࡲࠧጷ"))
	Cjd3P2hV7npqUfKTai6,Tr3ejpNs49EyAamxVXYv = ucm10ohnRLA8d5ybFKEYkNQa3e6Gr(vvkUmAixH2X9BzGTPEusYM)
	Cjd3P2hV7npqUfKTai6 = UAIXp7GJvrH64(Cjd3P2hV7npqUfKTai6,sJw9QWiq1Kr0xfeVRI(u"࠭࠱࠳࠳࠻࠷࠶࠾࠵࠴ࠩጸ"))
	ITX5YJWn9Ujo7RsfGtgFiSbMQ = {PlpyFa9QMKXxOD1cvHzmI(u"ࠧࡪࡦࡶࠫጹ"):o1INZ3ViQqS0Uw5z6kMjbv(u"ࠨࡆࡌࡅࡑࡕࡇࠨጺ"),CsDcLqQUVK4YBvHFW1(u"ࠩࡸࡷࡷ࠭ጻ"):I4t9qonjrm.AV_CLIENT_IDS,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠪࡺࡪࡸࠧጼ"):KoxvjArhL1TdInDmN9s,Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫࡸࡩࡲࠨጽ"):z5g9IPWO1skfHr2bjxK8vD,s5WMHyQN4mpie(u"ࠬࡹࡩࡻࠩጾ"):Cjd3P2hV7npqUfKTai6}
	sHqUlfmRgrQ1dYoJ6TEPXKNLtp2eC = {LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬጿ"):uulNDCPyef78(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭ፀ")}
	udeQMFs6kitf = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,KfHAW8VGbrxi(u"ࠨࡒࡒࡗ࡙࠭ፁ"),hhG9zY1XNDyFverMgSnxEW,ITX5YJWn9Ujo7RsfGtgFiSbMQ,sHqUlfmRgrQ1dYoJ6TEPXKNLtp2eC,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,wdftVMyzF17cYETHu(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡍࡕࡗࡠࡒࡏࡅ࡞ࡥࡄࡊࡃࡏࡓࡌ࠳࠱ࡴࡶࠪፂ"))
	SAom6YZbqlxwV = udeQMFs6kitf.content
	try:
		if not SAom6YZbqlxwV: V3BxekcH7n2QbPN0C94
		uHdc7Z0BQwiUe6nWbNO1sI8Ph94CaF = LB7TcZnGYdfw5lWU1RH3Oztu9PyA(N6NGJ4vpmidqMCh7yo(u"ࠪࡨ࡮ࡩࡴࠨፃ"),SAom6YZbqlxwV)
		XjeJNZQLlv8f0uc1 = uHdc7Z0BQwiUe6nWbNO1sI8Ph94CaF[o1INZ3ViQqS0Uw5z6kMjbv(u"ࠫࡲࡹࡧࠨፄ")]
		ImPDsaKpxVF = uHdc7Z0BQwiUe6nWbNO1sI8Ph94CaF[vU6DxuzPwMpg(u"ࠬࡹࡥࡤࠩፅ")]
		RwzyrWlinPmje = uHdc7Z0BQwiUe6nWbNO1sI8Ph94CaF[FgXzMs0YSDt(u"࠭ࡳࡵࡲࠪፆ")]
		ImPDsaKpxVF = int(GGjBAkoVdze0hyCFK8v5L7(ImPDsaKpxVF,N6NGJ4vpmidqMCh7yo(u"ࠧ࠲࠴࠴࠼࠸࠷࠸࠶࠵ࠪፇ")))
		RwzyrWlinPmje = int(GGjBAkoVdze0hyCFK8v5L7(RwzyrWlinPmje,wdftVMyzF17cYETHu(u"ࠨ࠳࠵࠵࠽࠹࠱࠹࠷࠶ࠫፈ")))
		for X0M9IyuYVhQJDH7dGO in range(ImPDsaKpxVF,D2D96X5NGamBhrFwvL8VEbqiSfZIl,-RwzyrWlinPmje):
			if not eval(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠩࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰࡬ࡷࡕࡲࡡࡺ࡫ࡱ࡫࠭࠯ࠧፉ"),{vU6DxuzPwMpg(u"ࠪࡼࡧࡳࡣࠨፊ"):bEWpDHXjCBqd7aOiN6UG5k}): V3BxekcH7n2QbPN0C94
			a6rVSjDMF87KyYINcuOP1l40Hbp(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫออโ๋ࠢ็่ฯาัษหࠣ์ฬ๊แฮืࠪፋ"),str(X0M9IyuYVhQJDH7dGO)+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠬࠦࠠฬษ้๎ฮ࠭ፌ"),uUqrNPcXKBoQ0slv=uulNDCPyef78(u"࠳࠳࠴ᑚ")*RwzyrWlinPmje)
			bEWpDHXjCBqd7aOiN6UG5k.sleep(QjAINyUC7MDRq5d8e4vl9(u"࠴࠴࠵࠶ᑛ")*RwzyrWlinPmje)
		if eval(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭ࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡩࡴࡒ࡯ࡥࡾ࡯࡮ࡨࠪࠬࠫፍ"),{aOQTKXFL54Nl60Zhp3MbE(u"ࠧࡹࡤࡰࡧࠬፎ"):bEWpDHXjCBqd7aOiN6UG5k}):
			XjeJNZQLlv8f0uc1 = XjeJNZQLlv8f0uc1.replace(C0qrknitpM4Z,CsDcLqQUVK4YBvHFW1(u"ࠨ࡞࡟ࡲࠬፏ")).replace(FFkml6ZbgXD,I18uSKaWhgTBeYUPD4sr(u"ࠩ࡟ࡠࡷ࠭ፐ"))
			GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,vU6DxuzPwMpg(u"ࠪาึ๎ฬࠨፑ"),wdftVMyzF17cYETHu(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧፒ"),XjeJNZQLlv8f0uc1)
		V3BxekcH7n2QbPN0C94
	except: exec(PlpyFa9QMKXxOD1cvHzmI(u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳ࡹࡴࡰࡲࠫ࠭ࠬፓ"),{PlpyFa9QMKXxOD1cvHzmI(u"࠭ࡸࡣ࡯ࡦࠫፔ"):bEWpDHXjCBqd7aOiN6UG5k})
	return
def zC3YFWniaJ():
	exec(EE1jeHnIoad(u"ࠧࠨࠩࠐࠎࡹࡸࡹ࠻ࠏࠍࠍࡼ࡯࡮ࡥࡱࡺ࠵࠷࠹ࠠ࠾ࠢࡻࡦࡲࡩࡧࡶ࡫࠱࡛࡮ࡴࡤࡰࡹࠫ࠵࠵࠶࠲࠶ࠫࠐࠎࠎࡽࡨࡪ࡮ࡨࠤ࡙ࡸࡵࡦ࠼ࠐࠎࠎࠏࡸࡣ࡯ࡦ࠲ࡸࡲࡥࡦࡲࠫ࠵࠵࠶࠰ࠪࠏࠍࠍࠎࡺࡲࡺ࠼ࠣࡻ࡮ࡴࡤࡰࡹ࠴࠶࠸࠴ࡧࡦࡶࡉࡳࡨࡻࡳࠩ࠳࠳࠴࠷࠻ࠩࠎࠌࠌࠍࡪࡾࡣࡦࡲࡷ࠾ࠥࡨࡲࡦࡣ࡮ࠑࠏࠏࡺࡤࡴࡨࡥࡹ࡫࡟ࡦࡴࡲࡶࡷࠓࠊࡦࡺࡦࡩࡵࡺ࠺ࠡࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯ࡵࡷࡳࡵ࠮ࠩࠎࠌࠪࠫࠬፕ"),{wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠨࡺࡥࡱࡨ࡭ࡵࡪࠩፖ"):nn19vN7ifGslVJODZWzCSudBK8,AAbvaXV2DQzfNHdm4U3tT(u"ࠩࡻࡦࡲࡩࠧፗ"):bEWpDHXjCBqd7aOiN6UG5k})
	return
def ucm10ohnRLA8d5ybFKEYkNQa3e6Gr(HEj7vrQguL8S5ydIcUwF2kNG6PJ4):
	fQ96jG2mWRU,eKsJrCAZgnXiVEN5fx4cp0kG9TIbR = D2D96X5NGamBhrFwvL8VEbqiSfZIl,D2D96X5NGamBhrFwvL8VEbqiSfZIl
	if HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.exists(HEj7vrQguL8S5ydIcUwF2kNG6PJ4):
		try: fQ96jG2mWRU = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.getsize(HEj7vrQguL8S5ydIcUwF2kNG6PJ4)
		except: pass
		if not fQ96jG2mWRU:
			try: fQ96jG2mWRU = HoxKENAey2MdTt9kDUrVnWGLS0CPa.stat(HEj7vrQguL8S5ydIcUwF2kNG6PJ4).st_size
			except: pass
		if not fQ96jG2mWRU:
			try:
				from pathlib import Path as qqmUHOB5ar1DebTA3zsnj9Q
				fQ96jG2mWRU = qqmUHOB5ar1DebTA3zsnj9Q(HEj7vrQguL8S5ydIcUwF2kNG6PJ4).stat().st_size
			except: pass
		if fQ96jG2mWRU: eKsJrCAZgnXiVEN5fx4cp0kG9TIbR = BkM54Kr7Qbqn
	return fQ96jG2mWRU,eKsJrCAZgnXiVEN5fx4cp0kG9TIbR
def VuEbh9TjOx2w1d7DcfX50(LIyvnX6k2aKAbB7,showDialogs):
	if showDialogs:
		Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ፘ"),LIyvnX6k2aKAbB7+EE1jeHnIoad(u"ࠫࡡࡴ࡜࡯ࠩፙ")+n0nFOd4yR97fQzNLSW+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่่ๆࠦฟࠢࠩፚ")+T7ASIp1ZYwio9HQ8cObJK)
		if Scj7zgGFVA83otMpwUkxhm0BLN1!=FgXzMs0YSDt(u"࠵ᑜ"): return LhFAGlQ19zr
	succeeded = EsCplGc5N4mBuYW0RVQt6b
	if HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.exists(LIyvnX6k2aKAbB7):
		try: HoxKENAey2MdTt9kDUrVnWGLS0CPa.remove(LIyvnX6k2aKAbB7.decode(Tk9eH2qw6Brsuhj))
		except:
			try: HoxKENAey2MdTt9kDUrVnWGLS0CPa.remove(eeKPEwWsa9SRfIuitxTNo)
			except Exception as NYtXLZDyeiqPSgGO:
				succeeded = LhFAGlQ19zr
				if showDialogs: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ggjO5CrKVRPITaesWkxD(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ፛"),str(NYtXLZDyeiqPSgGO))
	if showDialogs:
		if succeeded: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ፜"),N6NGJ4vpmidqMCh7yo(u"ࠨใื่ฯูࠦๆๆํอ๋ࠥำฮࠢส่๊๊แࠨ፝"))
		else: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ፞"),Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫ፟"))
	return succeeded
def rSOlpJAWb8Vh(UpHlMXIAGnmv9iVu,el2xC15szkTiJIdLnXgQ,showDialogs):
	if showDialogs:
		Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,AAbvaXV2DQzfNHdm4U3tT(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ፠"),UpHlMXIAGnmv9iVu+ssynAg0zhSkoCpOMDV9(u"ࠬࡢ࡮࡝ࡰࠪ፡")+n0nFOd4yR97fQzNLSW+sJw9QWiq1Kr0xfeVRI(u"࠭็ๅࠢอี๏ีࠠๆีะࠤ์ึวࠡษ็้ั๊ฯࠡมࠤࠫ።")+T7ASIp1ZYwio9HQ8cObJK)
		if Scj7zgGFVA83otMpwUkxhm0BLN1!=BkM54Kr7Qbqn: return LhFAGlQ19zr
	succeeded = EsCplGc5N4mBuYW0RVQt6b
	if HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.exists(UpHlMXIAGnmv9iVu):
		for uLb1XoWdyIvH7gJRi8G,VzLjP3Kdw05qtJT8,sTjfJ91McWaNYk7hmlDAQtIe8 in HoxKENAey2MdTt9kDUrVnWGLS0CPa.walk(UpHlMXIAGnmv9iVu,topdown=LhFAGlQ19zr):
			for HEj7vrQguL8S5ydIcUwF2kNG6PJ4 in sTjfJ91McWaNYk7hmlDAQtIe8:
				GGCkYa7X603fZbDR = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(uLb1XoWdyIvH7gJRi8G,HEj7vrQguL8S5ydIcUwF2kNG6PJ4)
				try: HoxKENAey2MdTt9kDUrVnWGLS0CPa.remove(GGCkYa7X603fZbDR)
				except Exception as NYtXLZDyeiqPSgGO:
					succeeded = LhFAGlQ19zr
					if showDialogs: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,oRJAfwD957WkUyBM1Ehu8m(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ፣"),str(NYtXLZDyeiqPSgGO))
			if el2xC15szkTiJIdLnXgQ:
				for dir in VzLjP3Kdw05qtJT8:
					i7iuDa1xCSskY = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(uLb1XoWdyIvH7gJRi8G,dir)
					try: HoxKENAey2MdTt9kDUrVnWGLS0CPa.rmdir(i7iuDa1xCSskY)
					except: pass
		if el2xC15szkTiJIdLnXgQ:
			try: HoxKENAey2MdTt9kDUrVnWGLS0CPa.rmdir(uLb1XoWdyIvH7gJRi8G)
			except: pass
	if showDialogs:
		if succeeded: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,sJw9QWiq1Kr0xfeVRI(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ፤"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪ፥"))
		else: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭፦"),Hr25gta6XcqO(u"้๊ࠫริใࠣๅู๊สࠡ฻่่๏ฯࠠศๆ่ืา࠭፧"))
	return succeeded
def GMec7YSfxPCZHv(NfMYGx1L4SW8FnC2uOzkP,iXYEGvtThUqFPJ4pHLZSnNRr29Ako,zzekZcWL1sBgnoxN8f3vdQ0r,O6N8nhyYTD12KRApqkLzVi,GAwfpnzSiJEcHtQjDul1LsPN2YT0x9,mE7D5fBQZOKJdhtVUkHaIgRWpx):
	YLKFRH6sSIrznXBg,aNqQDLfOzTK6,Ne7jpQSVGgR,AhqmcZCJOQ2jBsfEizgSaoXGT6b = tQy9PbSu2EB4HVIa0n(zzekZcWL1sBgnoxN8f3vdQ0r)
	Uuqa3wD8CR1G6 = iXYEGvtThUqFPJ4pHLZSnNRr29Ako,YLKFRH6sSIrznXBg,O6N8nhyYTD12KRApqkLzVi,GAwfpnzSiJEcHtQjDul1LsPN2YT0x9
	if NfMYGx1L4SW8FnC2uOzkP<N6NGJ4vpmidqMCh7yo(u"࠵ᑝ"):
		gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡕࡓࡎࡏࡍࡇ࠭፨"),Uuqa3wD8CR1G6)
		NfMYGx1L4SW8FnC2uOzkP = -NfMYGx1L4SW8FnC2uOzkP
	if NfMYGx1L4SW8FnC2uOzkP>N6NGJ4vpmidqMCh7yo(u"࠶ᑞ"):
		Vpnd4wgPqAO1j6z8N = rIhXWK91vRuC(jUCABmLYMf0G,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭ࡳࡵࡴࠪ፩"),AAbvaXV2DQzfNHdm4U3tT(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡗࡕࡐࡑࡏࡂࠨ፪"),Uuqa3wD8CR1G6)
		if Vpnd4wgPqAO1j6z8N:
			JfDOEvKRb1otY6kWZGXqnV(Hr25gta6XcqO(u"ࠨࡗࡕࡐࡑࡏࡂࠡࠢࡕࡉࡆࡊ࡟ࡄࡃࡆࡌࡊ࠭፫"),zzekZcWL1sBgnoxN8f3vdQ0r,O6N8nhyYTD12KRApqkLzVi,GAwfpnzSiJEcHtQjDul1LsPN2YT0x9,mE7D5fBQZOKJdhtVUkHaIgRWpx,iXYEGvtThUqFPJ4pHLZSnNRr29Ako)
			return Vpnd4wgPqAO1j6z8N
	Vpnd4wgPqAO1j6z8N = LLJ9RNzFxShH(iXYEGvtThUqFPJ4pHLZSnNRr29Ako,zzekZcWL1sBgnoxN8f3vdQ0r,O6N8nhyYTD12KRApqkLzVi,GAwfpnzSiJEcHtQjDul1LsPN2YT0x9,mE7D5fBQZOKJdhtVUkHaIgRWpx)
	if Vpnd4wgPqAO1j6z8N and NfMYGx1L4SW8FnC2uOzkP: tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,Hr25gta6XcqO(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄࠪ፬"),Uuqa3wD8CR1G6,Vpnd4wgPqAO1j6z8N,NfMYGx1L4SW8FnC2uOzkP)
	return Vpnd4wgPqAO1j6z8N
def ngpwf5MVySAe8caPsWmD6GlNuvJb(BfWYUAnyg6eONLjiuE,zAjL9CBJmsTYiX,UcdBt9AxZb24fung3NrPIXDKG0TV6=D2D96X5NGamBhrFwvL8VEbqiSfZIl):
	uYX7wSps9eMWB = OdiZIyCfDUsW3JBGR2VAb.getSetting(vU6DxuzPwMpg(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡢࡪࡶࡵࡥࡹ࡫ࠧ፭"))
	if uYX7wSps9eMWB and N6NGJ4vpmidqMCh7yo(u"ࠫ࠲࠭፮") not in uYX7wSps9eMWB: O0nkSFcZRm182p47v69tG,wdHo57USQ28bC = int(uYX7wSps9eMWB),EsCplGc5N4mBuYW0RVQt6b
	elif UcdBt9AxZb24fung3NrPIXDKG0TV6: O0nkSFcZRm182p47v69tG,wdHo57USQ28bC = UcdBt9AxZb24fung3NrPIXDKG0TV6,LhFAGlQ19zr
	else: return []
	p8pUW7t2BPFo6M5,cUSETrvCV5OaiKAuQIlj6w72YNJh = [],fy8iFgEkrO12NR9TWBI35sjY6qHvV
	SEwb3LOW9vT0lcdXxzfDtePupI,A2AMRExi7FCcIUomqKX,RRDiTprfcNaz20AtWML5Xyo,DpeYras9ujPVXiERwbZA = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,D2D96X5NGamBhrFwvL8VEbqiSfZIl,D2D96X5NGamBhrFwvL8VEbqiSfZIl
	zAjL9CBJmsTYiX = sorted(zAjL9CBJmsTYiX,reverse=EsCplGc5N4mBuYW0RVQt6b,key=lambda key: (key[BkM54Kr7Qbqn],key[teaC5j4HuGDqpwcmUzJ]))
	for stream,W9Wlfe5pMJXvu0Qxk,gn2DUcWhvjpC4ZR0lr3bJO61GPVX in zAjL9CBJmsTYiX+[[fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,D2D96X5NGamBhrFwvL8VEbqiSfZIl]]:
		if W9Wlfe5pMJXvu0Qxk==cUSETrvCV5OaiKAuQIlj6w72YNJh:
			if gn2DUcWhvjpC4ZR0lr3bJO61GPVX>O0nkSFcZRm182p47v69tG: A2AMRExi7FCcIUomqKX,DpeYras9ujPVXiERwbZA = stream,gn2DUcWhvjpC4ZR0lr3bJO61GPVX
			elif not SEwb3LOW9vT0lcdXxzfDtePupI: SEwb3LOW9vT0lcdXxzfDtePupI,RRDiTprfcNaz20AtWML5Xyo = stream,gn2DUcWhvjpC4ZR0lr3bJO61GPVX
		else:
			if A2AMRExi7FCcIUomqKX or SEwb3LOW9vT0lcdXxzfDtePupI:
				if SEwb3LOW9vT0lcdXxzfDtePupI: p8pUW7t2BPFo6M5.append([SEwb3LOW9vT0lcdXxzfDtePupI,cUSETrvCV5OaiKAuQIlj6w72YNJh,RRDiTprfcNaz20AtWML5Xyo])
				elif A2AMRExi7FCcIUomqKX: p8pUW7t2BPFo6M5.append([A2AMRExi7FCcIUomqKX,cUSETrvCV5OaiKAuQIlj6w72YNJh,DpeYras9ujPVXiERwbZA])
			if gn2DUcWhvjpC4ZR0lr3bJO61GPVX>O0nkSFcZRm182p47v69tG:
				A2AMRExi7FCcIUomqKX,DpeYras9ujPVXiERwbZA = stream,gn2DUcWhvjpC4ZR0lr3bJO61GPVX
				SEwb3LOW9vT0lcdXxzfDtePupI,RRDiTprfcNaz20AtWML5Xyo = fy8iFgEkrO12NR9TWBI35sjY6qHvV,D2D96X5NGamBhrFwvL8VEbqiSfZIl
			else:
				A2AMRExi7FCcIUomqKX,DpeYras9ujPVXiERwbZA = fy8iFgEkrO12NR9TWBI35sjY6qHvV,D2D96X5NGamBhrFwvL8VEbqiSfZIl
				SEwb3LOW9vT0lcdXxzfDtePupI,RRDiTprfcNaz20AtWML5Xyo = stream,gn2DUcWhvjpC4ZR0lr3bJO61GPVX
		cUSETrvCV5OaiKAuQIlj6w72YNJh = W9Wlfe5pMJXvu0Qxk
	if wdHo57USQ28bC:
		evUXLICSWN80MqVOarButycb6wHP,Y1Y7cULHrsQb52KqE0,GYvZIK49eTCqWX3FbASM5zB = zip(*p8pUW7t2BPFo6M5)
		EiILBRDW5xFlVbd9Oq6 = [aOQTKXFL54Nl60Zhp3MbE(u"ࠬࡳࡰ࠵ࠩ፯"),Hr25gta6XcqO(u"࠭࡭ࡱࡦࠪ፰"),jL5CrsRwebpyDVXUc1EQP(u"ࠧࡵࡵࠪ፱"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨ࡯࠶ࡹࠬ፲")]
		for W9Wlfe5pMJXvu0Qxk in EiILBRDW5xFlVbd9Oq6:
			if W9Wlfe5pMJXvu0Qxk in Y1Y7cULHrsQb52KqE0:
				index = Y1Y7cULHrsQb52KqE0.index(W9Wlfe5pMJXvu0Qxk)
				p8pUW7t2BPFo6M5 = [[evUXLICSWN80MqVOarButycb6wHP[index],Y1Y7cULHrsQb52KqE0[index],GYvZIK49eTCqWX3FbASM5zB[index]]]
				break
	return p8pUW7t2BPFo6M5
def wwC9IiN8t2epu3xHlaAPkVWjYzy(chLTgNepKwFlz6yMC39Z04En):
	i16TLa304fgPrcmnzHFtCA5JSQ2YW,BlnTkG5dwUIP = [],zA8Ry1KDvmr3w4B5xeP
	for C0C4kdG53sPAbNq8OBMpitLThHl in cFTiOCdrXfgnKx0vh948jU7pSEb:
		if C0C4kdG53sPAbNq8OBMpitLThHl==oRJAfwD957WkUyBM1Ehu8m(u"ࠩࡓࡖࡎ࡜ࡁࡕࡇࠪ፳"): BlnTkG5dwUIP = (EE1jeHnIoad(u"ࠪࡰ࡮ࡴ࡫ࠨ፴"),n0nFOd4yR97fQzNLSW+sIzDXlTHYUC5L3xZGnr(u"๊ࠫ๎วใ฻ࠣื๏ืแาษอࠤำอีสࠢ࠰ࠤ็๊๊ๅหࠣห้๋ิศๅ็ࠫ፵")+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠱࠶࠹ᑟ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		elif C0C4kdG53sPAbNq8OBMpitLThHl==CsDcLqQUVK4YBvHFW1(u"ࠬࡓࡉ࡙ࡇࡇࠫ፶"): BlnTkG5dwUIP = (O3OVuapf0YFjbm5oUQDg(u"࠭࡬ࡪࡰ࡮ࠫ፷"),n0nFOd4yR97fQzNLSW+C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧๆ๊สๆ฾ࠦำ๋ำไีฬะࠠฯษุอࠥ๎ูศ็ฬࠤ࠲ࠦใฬ์ิอࠥอไๆึส็้࠭፸")+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,jL5CrsRwebpyDVXUc1EQP(u"࠲࠷࠺ᑠ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		elif C0C4kdG53sPAbNq8OBMpitLThHl==EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠨࡒࡘࡆࡑࡏࡃࠨ፹"): BlnTkG5dwUIP = (EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩ࡯࡭ࡳࡱࠧ፺"),n0nFOd4yR97fQzNLSW+KfHAW8VGbrxi(u"้ࠪํอโฺࠢึ๎ึ็ัศฬࠣ฽ฬ๋ษࠡ࠯ࠣ็ะ๐ัสࠢสฺ่๊วไๆࠪ፻")+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,O3OVuapf0YFjbm5oUQDg(u"࠳࠸࠻ᑡ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		if C0C4kdG53sPAbNq8OBMpitLThHl not in chLTgNepKwFlz6yMC39Z04En: continue
		if BlnTkG5dwUIP:
			i16TLa304fgPrcmnzHFtCA5JSQ2YW.append(BlnTkG5dwUIP)
			BlnTkG5dwUIP = zA8Ry1KDvmr3w4B5xeP
		if C0C4kdG53sPAbNq8OBMpitLThHl not in [oRJAfwD957WkUyBM1Ehu8m(u"ࠫࡕࡘࡉࡗࡃࡗࡉࠬ፼"),CsDcLqQUVK4YBvHFW1(u"ࠬࡓࡉ࡙ࡇࡇࠫ፽"),oRJAfwD957WkUyBM1Ehu8m(u"࠭ࡐࡖࡄࡏࡍࡈ࠭፾")]: i16TLa304fgPrcmnzHFtCA5JSQ2YW.append(C0C4kdG53sPAbNq8OBMpitLThHl)
	return i16TLa304fgPrcmnzHFtCA5JSQ2YW
def jdUaoWsQxZJbuYTO1Cqey83XBnpMG(NNjZrmVQGXDwe9O,args=[]):
	sHqUlfmRgrQ1dYoJ6TEPXKNLtp2eC = {CsDcLqQUVK4YBvHFW1(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭፿"):aOQTKXFL54Nl60Zhp3MbE(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫᎀ")}
	dkThRWB8Me,qPFtWMKBpdYn1EygSQlf7AuVLU5ma,saGM17ljrfQdcvJqCRyKxNHh = C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠩࡹࡧࡧࡩ࠶࠶࠵࠷࠺࡬࡬ࡨࡣࡰࡼࡱࡺࡰ࡫ࠨᎁ"),I18uSKaWhgTBeYUPD4sr(u"ࠪ࠸࠸ࡼࡣࡷ࠵ࡧࡪ࡬ࡰ࡫ࡰ࠹࠻ࡷࡽࢀࡤ࠳ࠩᎂ"),int(uUqrNPcXKBoQ0slv.time())
	P6zT7HqmJNrog3CISVf0GQspW = dkThRWB8Me+xJzfR18FIkmZ6OPa4eGU2NgcB+str(saGM17ljrfQdcvJqCRyKxNHh)+KoxvjArhL1TdInDmN9s+qPFtWMKBpdYn1EygSQlf7AuVLU5ma
	YMFiErscPW2Z = bSyIhTmVdu8sDCPHiU5pXQ1OK.md5(P6zT7HqmJNrog3CISVf0GQspW.encode(FgXzMs0YSDt(u"ࠫࡺࡺࡦ࠹ࠩᎃ"))).hexdigest()[:s5WMHyQN4mpie(u"࠶࠶ᑢ")]
	ITX5YJWn9Ujo7RsfGtgFiSbMQ = {PlpyFa9QMKXxOD1cvHzmI(u"ࠬࡰࡳࡤࡱࡧࡩࠬᎄ"):NNjZrmVQGXDwe9O,SnhLjmfeJC(u"࠭ࡡࡳࡩࡶࠫᎅ"):args,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠧࡶࡵࡨࡶࠬᎆ"):xJzfR18FIkmZ6OPa4eGU2NgcB,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩᎇ"):KoxvjArhL1TdInDmN9s,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠩ࡬ࡨࡸ࠭ᎈ"):YMFiErscPW2Z}
	ITX5YJWn9Ujo7RsfGtgFiSbMQ = Qra2CWgebk.dumps(ITX5YJWn9Ujo7RsfGtgFiSbMQ)
	yxpijKgM3LQr9ADoNUln = I4t9qonjrm.SITESURLS[FgXzMs0YSDt(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪᎉ")][QjAINyUC7MDRq5d8e4vl9(u"࠵࠵ᑣ")]
	udeQMFs6kitf = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,SnhLjmfeJC(u"ࠫࡕࡕࡓࡕࠩᎊ"),yxpijKgM3LQr9ADoNUln,ITX5YJWn9Ujo7RsfGtgFiSbMQ,sHqUlfmRgrQ1dYoJ6TEPXKNLtp2eC,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡇࡆ࡙࡙ࡋ࡟ࡋࡕ࠰࠵ࡸࡺࠧᎋ"))
	SAom6YZbqlxwV = udeQMFs6kitf.content
	return SAom6YZbqlxwV
def kkfj6pyAalMWxoJKmnhFYutVrI9PZd(aiETVDZkRjn0qz,timeout,q8BUJu1WdIcYAaCSNi,E0QvoSragU,zoalpZKxHs2CTRgOf):
	Reb2x3SZ7MfV = LhFAGlQ19zr
	for yRPLeVvnrbxMusOa7cQkI5hJj6qYH3 in aiETVDZkRjn0qz:
		yRPLeVvnrbxMusOa7cQkI5hJj6qYH3.start()
		uUqrNPcXKBoQ0slv.sleep(q8BUJu1WdIcYAaCSNi)
		Reb2x3SZ7MfV = zoalpZKxHs2CTRgOf()
		if Reb2x3SZ7MfV: break
	else:
		timeout = int(timeout-len(aiETVDZkRjn0qz)*q8BUJu1WdIcYAaCSNi)
		if timeout>D2D96X5NGamBhrFwvL8VEbqiSfZIl:
			for O4On5rLamD7q1zKBo6WfF3eEbS98 in range(timeout//E0QvoSragU):
				uUqrNPcXKBoQ0slv.sleep(E0QvoSragU)
				Reb2x3SZ7MfV = zoalpZKxHs2CTRgOf()
				if Reb2x3SZ7MfV: break
	for yRPLeVvnrbxMusOa7cQkI5hJj6qYH3 in aiETVDZkRjn0qz:
		try: yRPLeVvnrbxMusOa7cQkI5hJj6qYH3.join(q8BUJu1WdIcYAaCSNi)
		except: pass
	return Reb2x3SZ7MfV
def au4qM5fhJ3lC():
	J4NbqW35lrQnFhDZ0w = o1INZ3ViQqS0Uw5z6kMjbv(u"࠶࠶࠲࠵ᑤ")*o1INZ3ViQqS0Uw5z6kMjbv(u"࠶࠶࠲࠵ᑤ")
	mwNfvWoUKHlLCgJ0ka65yRjGxc8e = D2D96X5NGamBhrFwvL8VEbqiSfZIl
	try:
		mwNfvWoUKHlLCgJ0ka65yRjGxc8e =	bEWpDHXjCBqd7aOiN6UG5k.getInfoLabel(uulNDCPyef78(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡆࡳࡧࡨࡗࡵࡧࡣࡦࠩᎌ"))
		mwNfvWoUKHlLCgJ0ka65yRjGxc8e = EcQxOa3RJm86WjTKA.findall(vU6DxuzPwMpg(u"ࠧ࡝ࡦ࠮ࠫᎍ"),mwNfvWoUKHlLCgJ0ka65yRjGxc8e)
		mwNfvWoUKHlLCgJ0ka65yRjGxc8e = int(mwNfvWoUKHlLCgJ0ka65yRjGxc8e[D2D96X5NGamBhrFwvL8VEbqiSfZIl])*J4NbqW35lrQnFhDZ0w
	except: pass
	if not mwNfvWoUKHlLCgJ0ka65yRjGxc8e and hasattr(HoxKENAey2MdTt9kDUrVnWGLS0CPa,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠨࡵࡷࡥࡹࡼࡦࡴࠩᎎ")):
		try:
			yy0TesASLf1HBbVUqchKtRFn7 = HoxKENAey2MdTt9kDUrVnWGLS0CPa.statvfs(bvAWytBjsO)
			mwNfvWoUKHlLCgJ0ka65yRjGxc8e = yy0TesASLf1HBbVUqchKtRFn7.f_frsize * yy0TesASLf1HBbVUqchKtRFn7.f_bavail
		except: pass
	if not mwNfvWoUKHlLCgJ0ka65yRjGxc8e and hasattr(HoxKENAey2MdTt9kDUrVnWGLS0CPa,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠩࡩࡷࡹࡧࡴࡷࡨࡶࠫᎏ")):
		try:
			yy0TesASLf1HBbVUqchKtRFn7 = HoxKENAey2MdTt9kDUrVnWGLS0CPa.fstatvfs(bvAWytBjsO)
			mwNfvWoUKHlLCgJ0ka65yRjGxc8e = yy0TesASLf1HBbVUqchKtRFn7.f_frsize * yy0TesASLf1HBbVUqchKtRFn7.f_bavail
		except: pass
	if not mwNfvWoUKHlLCgJ0ka65yRjGxc8e:
		try:
			import shutil as nxFUTNQ6pcPI
			mwNfvWoUKHlLCgJ0ka65yRjGxc8e = nxFUTNQ6pcPI.disk_usage(bvAWytBjsO).free
		except: pass
	if not mwNfvWoUKHlLCgJ0ka65yRjGxc8e:
		try:
			import psutil as GGvtZpMlmhI4uRo3X0SqQCsVPwd
			mwNfvWoUKHlLCgJ0ka65yRjGxc8e = GGvtZpMlmhI4uRo3X0SqQCsVPwd.disk_usage(bvAWytBjsO).free
		except: pass
	if not mwNfvWoUKHlLCgJ0ka65yRjGxc8e and CfgZ0zWP5XBpoGQwLUY.platform == FgXzMs0YSDt(u"ࠪࡻ࡮ࡴ࠳࠳ࠩ᎐"):
		try:
			import ctypes as XIhfEC0W5GFg1rJ9DUvQO48Lcj
			EL3USj1opJsA = XIhfEC0W5GFg1rJ9DUvQO48Lcj.c_ulonglong(D2D96X5NGamBhrFwvL8VEbqiSfZIl)
			XIhfEC0W5GFg1rJ9DUvQO48Lcj.windll.kernel32.GetDiskFreeSpaceExW(XIhfEC0W5GFg1rJ9DUvQO48Lcj.c_wchar_p(bvAWytBjsO),None,None,XIhfEC0W5GFg1rJ9DUvQO48Lcj.pointer(EL3USj1opJsA))
			mwNfvWoUKHlLCgJ0ka65yRjGxc8e = EL3USj1opJsA.value
		except: pass
	if not mwNfvWoUKHlLCgJ0ka65yRjGxc8e: mwNfvWoUKHlLCgJ0ka65yRjGxc8e = N6NGJ4vpmidqMCh7yo(u"࠿࠹࠺࠻࠼࠽࠾࠿࠹࠺ᑥ")
	return mwNfvWoUKHlLCgJ0ka65yRjGxc8e
from llk3PQSM1w import *
# -*- coding: utf-8 -*-
import sys as CfgZ0zWP5XBpoGQwLUY
D5DpyO2wPg7oL = CfgZ0zWP5XBpoGQwLUY.version_info [0] == 2
ccK5HIyfUgvOdQpWSXZtaBJ = 2048
W8WuBTGQg1Zwqy5F6xSe = 7
def zmQcCUZlPKBITW5bqx1 (rR5FPU8VhJQ):
	global Jfz4wMWSZb0BYV
	EEr5teuZbc = ord (rR5FPU8VhJQ [-1])
	ZZd5W9FVUhzu31NQyComxv = rR5FPU8VhJQ [:-1]
	sJYFyd6mZHev1IXEaMj0b = EEr5teuZbc % len (ZZd5W9FVUhzu31NQyComxv)
	qPJ7pUnt5rcm6NMaFYLSkHsGxI = ZZd5W9FVUhzu31NQyComxv [:sJYFyd6mZHev1IXEaMj0b] + ZZd5W9FVUhzu31NQyComxv [sJYFyd6mZHev1IXEaMj0b:]
	if D5DpyO2wPg7oL:
		Vv1b9fdEckNepm7 = unicode () .join ([unichr (ord (QdqoKlFn4yZUOJp1xYrNTaBSmt69hc) - ccK5HIyfUgvOdQpWSXZtaBJ - (hrazDC5q4oB + EEr5teuZbc) % W8WuBTGQg1Zwqy5F6xSe) for hrazDC5q4oB, QdqoKlFn4yZUOJp1xYrNTaBSmt69hc in enumerate (qPJ7pUnt5rcm6NMaFYLSkHsGxI)])
	else:
		Vv1b9fdEckNepm7 = str () .join ([chr (ord (QdqoKlFn4yZUOJp1xYrNTaBSmt69hc) - ccK5HIyfUgvOdQpWSXZtaBJ - (hrazDC5q4oB + EEr5teuZbc) % W8WuBTGQg1Zwqy5F6xSe) for hrazDC5q4oB, QdqoKlFn4yZUOJp1xYrNTaBSmt69hc in enumerate (qPJ7pUnt5rcm6NMaFYLSkHsGxI)])
	return eval (Vv1b9fdEckNepm7)
V3z5t4JAqyXk2fLsW1juoZ0BEp6,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye,wdftVMyzF17cYETHu=zmQcCUZlPKBITW5bqx1,zmQcCUZlPKBITW5bqx1,zmQcCUZlPKBITW5bqx1
Hr25gta6XcqO,FmYoGejTnwKME7d9zPc,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9=wdftVMyzF17cYETHu,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye,V3z5t4JAqyXk2fLsW1juoZ0BEp6
KfHAW8VGbrxi,aOQTKXFL54Nl60Zhp3MbE,jL5CrsRwebpyDVXUc1EQP=Dco0w1e5VM3YP7hLXTHBS8GtaCrO9,FmYoGejTnwKME7d9zPc,Hr25gta6XcqO
oRJAfwD957WkUyBM1Ehu8m,vU6DxuzPwMpg,I18uSKaWhgTBeYUPD4sr=jL5CrsRwebpyDVXUc1EQP,aOQTKXFL54Nl60Zhp3MbE,KfHAW8VGbrxi
o1INZ3ViQqS0Uw5z6kMjbv,s5WMHyQN4mpie,N6NGJ4vpmidqMCh7yo=I18uSKaWhgTBeYUPD4sr,vU6DxuzPwMpg,oRJAfwD957WkUyBM1Ehu8m
Gcw2nelTR864XCVruO3mAFqI5a,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7,OO9YiAQHGrLo0qpW2M3jDeXd1kx=N6NGJ4vpmidqMCh7yo,s5WMHyQN4mpie,o1INZ3ViQqS0Uw5z6kMjbv
O3OVuapf0YFjbm5oUQDg,sJw9QWiq1Kr0xfeVRI,SnhLjmfeJC=OO9YiAQHGrLo0qpW2M3jDeXd1kx,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7,Gcw2nelTR864XCVruO3mAFqI5a
QjAINyUC7MDRq5d8e4vl9,AAbvaXV2DQzfNHdm4U3tT,ggjO5CrKVRPITaesWkxD=SnhLjmfeJC,sJw9QWiq1Kr0xfeVRI,O3OVuapf0YFjbm5oUQDg
FgXzMs0YSDt,uulNDCPyef78,EQxFuqjw95WvaMm8Hnlt47XVihJ=ggjO5CrKVRPITaesWkxD,AAbvaXV2DQzfNHdm4U3tT,QjAINyUC7MDRq5d8e4vl9
ssynAg0zhSkoCpOMDV9,sIzDXlTHYUC5L3xZGnr,PlpyFa9QMKXxOD1cvHzmI=EQxFuqjw95WvaMm8Hnlt47XVihJ,uulNDCPyef78,FgXzMs0YSDt
CsDcLqQUVK4YBvHFW1,EE1jeHnIoad,LYIgTBeSmZWotDh4bnyQkvM50siu=PlpyFa9QMKXxOD1cvHzmI,sIzDXlTHYUC5L3xZGnr,ssynAg0zhSkoCpOMDV9
D2D96X5NGamBhrFwvL8VEbqiSfZIl = O3OVuapf0YFjbm5oUQDg(u"࠵ਣ")
BkM54Kr7Qbqn = SnhLjmfeJC(u"࠷ਤ")
teaC5j4HuGDqpwcmUzJ = BkM54Kr7Qbqn+BkM54Kr7Qbqn
XW57OCeGnFTLQbaqdrD9zM = teaC5j4HuGDqpwcmUzJ+BkM54Kr7Qbqn
vD4Fh6ictZ7wME = XW57OCeGnFTLQbaqdrD9zM+BkM54Kr7Qbqn
hvkue2LYgiOGrtcmxszl4S8MWdnF = vD4Fh6ictZ7wME+BkM54Kr7Qbqn
fy8iFgEkrO12NR9TWBI35sjY6qHvV = LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠭ࠧच")
ksJdoFWhxTz8Y2N7bOZE = C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧࠡࠩछ")
OOiSqkBcMPptI = ksJdoFWhxTz8Y2N7bOZE*teaC5j4HuGDqpwcmUzJ
yU7COAbsNJ916v5L0oew2n = ksJdoFWhxTz8Y2N7bOZE*XW57OCeGnFTLQbaqdrD9zM
zz5wETpjWKMNb6JiLRndGhV9 = ksJdoFWhxTz8Y2N7bOZE*vD4Fh6ictZ7wME
zA8Ry1KDvmr3w4B5xeP = None
EsCplGc5N4mBuYW0RVQt6b = KfHAW8VGbrxi(u"ࡖࡵࡹࡪ੃")
LhFAGlQ19zr = sJw9QWiq1Kr0xfeVRI(u"ࡉࡥࡱࡹࡥ੄")
DGxPh8K0bBkN5fmu2py4L = I18uSKaWhgTBeYUPD4sr(u"ࠨࡶࡵࡹࡪ࠭ज")
DDIe1w6Gj3NMV9E08FtqxbSsh = uulNDCPyef78(u"ࠩࡩࡥࡱࡹࡥࠨझ")
cJsR8uCmEQpkzg2AyZXo1 = N6NGJ4vpmidqMCh7yo(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪञ")
LLvswCIAk0tubrKgFpPW4BVf = oRJAfwD957WkUyBM1Ehu8m(u"ࠫࡩ࡫ࡦࡢࡷ࡯ࡸࠬट")
n0nFOd4yR97fQzNLSW = PlpyFa9QMKXxOD1cvHzmI(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡅ࠹࠷ࡌ࡝ࠨठ")
WydpaVx5YmLoCiIgA34eEBlb = KfHAW8VGbrxi(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩड")
ISYP5dC9xevhz0lJoV67cNfXM = AAbvaXV2DQzfNHdm4U3tT(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈ࠶࠷ࡊ࠺࠳࠴࡟ࠪढ")
wRebsz18p0FJ5BlDuU = AAbvaXV2DQzfNHdm4U3tT(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉ࠵ࡋ࠻࠱ࡇࡈࡠࠫण")
hjFvOY978VxiNa5dy = ssynAg0zhSkoCpOMDV9(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇࡈࡉࡡࠬत")
T7ASIp1ZYwio9HQ8cObJK = AAbvaXV2DQzfNHdm4U3tT(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬथ")
Tk9eH2qw6Brsuhj = o1INZ3ViQqS0Uw5z6kMjbv(u"ࠫࡺࡺࡦ࠹ࠩद")
h0fvMZUqg9SCaOYBQ = s5WMHyQN4mpie(u"ࠬࡔࡏࡕࡋࡆࡉࠬध")
wVhZ6bfkpSre95EFu = Gcw2nelTR864XCVruO3mAFqI5a(u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬन")
UEYprhQMOVN = EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧࡆࡔࡕࡓࡗ࠭ऩ")
P3PazFblmtN = ssynAg0zhSkoCpOMDV9(u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭प")
C0qrknitpM4Z = EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩ࡟ࡲࠬफ")
FFkml6ZbgXD = uulNDCPyef78(u"ࠪࡠࡷ࠭ब")
McNObUozJiyh8w9nFW = vU6DxuzPwMpg(u"࠱࠳࠲ਥ")
I21pK8eAmNMHE6OiJsYRD = PlpyFa9QMKXxOD1cvHzmI(u"࠷࠲ਦ")
bznkhxWOTcZLaF2U6A4iKd30NI = jL5CrsRwebpyDVXUc1EQP(u"࠳࠸ਧ")
As7IrxH92BnhkX5aN0OKyUdwZ = wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠴࠴ਨ")
UUSxo7uMnZIWd0kcyi1Gz = [
						 sIzDXlTHYUC5L3xZGnr(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡅࡏࡆࡢࡅࡓࡇࡌ࡚ࡖࡌࡇࡘࡥࡅࡗࡇࡑࡘࡘ࠳࠱ࡴࡶࠪभ")
						,O3OVuapf0YFjbm5oUQDg(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡖࡕࡅࡈ࡚࡟ࡎ࠵ࡘ࠼࠲࠷ࡳࡵࠩम")
						,oRJAfwD957WkUyBM1Ehu8m(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡃࡑࡈࡔࡓ࡟ࡖࡕࡈࡖࡆࡍࡅࡏࡖ࠰࠵ࡸࡺࠧय")
						,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡘࡤࡖࡒࡐ࡚ࡌࡉࡘࡥࡌࡊࡕࡗ࠱࠶ࡹࡴࠨर")
						,FmYoGejTnwKME7d9zPc(u"ࠨࡋࡓࡘ࡛࠳ࡃࡉࡇࡆࡏࡤࡇࡃࡄࡑࡘࡒ࡙࠳࠱ࡴࡶࠪऱ")
						,wdftVMyzF17cYETHu(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊࡕࡌࡐࡅࡄࡘࡎࡕࡎ࠮࠳ࡶࡸࠬल")
						,I18uSKaWhgTBeYUPD4sr(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠵ࡸࡺࠧळ")
						,FmYoGejTnwKME7d9zPc(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤࡔࡅࡘࡡࡋࡓࡘ࡚ࡎࡂࡏࡈ࠱࠸ࡸࡤࠨऴ")
						,PlpyFa9QMKXxOD1cvHzmI(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡆࡃࡇࡣࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐ࠲࠷ࡳࡵࠩव")
						,SnhLjmfeJC(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡊࡓࡔࡍࡌࡆࡗࡖࡉࡗࡉࡏࡏࡖࡈࡒ࡙࠳࠱ࡴࡶࠪश")
						,QjAINyUC7MDRq5d8e4vl9(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠷ࡷࡪࠧष")
						,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠺ࡺࡨࠨस")
						,s5WMHyQN4mpie(u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨह")
						,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡔࡊࡄࡖࡎࡔࡇ࠮࠳ࡶࡸࠬऺ")
						,PlpyFa9QMKXxOD1cvHzmI(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡕࡋࡅࡗࡏࡎࡈ࠯࠵ࡲࡩ࠭ऻ")
						]
u0HZLYVePBUomvS = UUSxo7uMnZIWd0kcyi1Gz+[
				 o1INZ3ViQqS0Uw5z6kMjbv(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡐࡓࡑ࡛࡝ࡤ࡚ࡅࡔࡖ࠰࠵ࡸࡺ़ࠧ")
				,I18uSKaWhgTBeYUPD4sr(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡊࡗࡘࡕ࡙ࡐࡓࡑ࡛ࡍࡊ࡙࠭࠲ࡵࡷࠫऽ")
				,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪा")
				,s5WMHyQN4mpie(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛ࡍࡊ࡙࠭࠳ࡰࡧࠫि")
				,aOQTKXFL54Nl60Zhp3MbE(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜࡞࡚ࡏ࠮࠳ࡶࡸࠬी")
				,oRJAfwD957WkUyBM1Ehu8m(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤ࡝ࡅࡃࡒࡕࡓ࡝࡟ࡔࡐ࠯࠵ࡲࡩ࠭ु")
				,KfHAW8VGbrxi(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡋࡑࡔࡒ࡜࡞ࡉࡏࡎ࠯࠴ࡷࡹ࠭ू")
				,PlpyFa9QMKXxOD1cvHzmI(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠶ࡳࡪࠧृ")
				,Hr25gta6XcqO(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡍࡓࡖࡔ࡞࡙ࡄࡑࡐ࠱࠸ࡸࡤࠨॄ")
				,CsDcLqQUVK4YBvHFW1(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡅࡋࡉࡈࡑ࡟ࡉࡖࡗࡔࡘࡥࡐࡓࡑ࡛ࡍࡊ࡙࠭࠲ࡵࡷࠫॅ")
				,LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡌ࡙࡚ࡐࡔࡡࡗࡉࡘ࡚࠭࠲ࡵࡷࠫॆ")
				,ggjO5CrKVRPITaesWkxD(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱࡙ࡋࡓࡕࡡࡄࡐࡑࡥࡗࡆࡄࡖࡍ࡙ࡋࡓ࠮࠳ࡶࡸࠬे")
				,FgXzMs0YSDt(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡚ࡅࡔࡖࡢࡅࡑࡒ࡟ࡘࡇࡅࡗࡎ࡚ࡅࡔ࠯࠵ࡲࡩ࠭ै")
				,FmYoGejTnwKME7d9zPc(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡕࡔࡃࡊࡉࡤࡘࡅࡑࡑࡕࡘ࠲࠷ࡳࡵࠩॉ")
				,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡔࡓࡃࡑࡗࡑࡇࡔࡆ࠯࠴ࡷࡹ࠭ॊ")
				,uulNDCPyef78(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡇ࡙ࡉࡗ࡙ࡏࡠࡖࡕࡅࡓ࡙ࡌࡂࡖࡈ࠱࠶ࡹࡴࠨो")
				]
MMXLBYhFx4vuUOSEaHqDNs = [
						 FgXzMs0YSDt(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠷ࡳࡵࠩौ")
						,aOQTKXFL54Nl60Zhp3MbE(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝࡙ࡈࡂࡔࡌࡒࡌ࠳࠲࡯ࡦ्ࠪ")
						,O3OVuapf0YFjbm5oUQDg(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡕࡍࡖࡌࡣ࡝࡙ࡈࡂࡔࡌࡒࡌ࠳࠱ࡴࡶࠪॎ")
						]
gaUFPm1MLjDJ2lVecEuYI = hvkue2LYgiOGrtcmxszl4S8MWdnF
rjileqgmIOfLEWHoMz = [FgXzMs0YSDt(u"ูࠪๆืࠧॏ"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠫศ๎ไࠨॐ"),PlpyFa9QMKXxOD1cvHzmI(u"ࠬัว็์ࠪ॑"),EE1jeHnIoad(u"࠭หศๆฮ॒ࠫ"),FmYoGejTnwKME7d9zPc(u"ࠧาษห฽ࠬ॓"),CsDcLqQUVK4YBvHFW1(u"ࠨะสุ้࠭॔"),wdftVMyzF17cYETHu(u"ࠩึหิูࠧॕ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪืฬฮูࠨॖ"),Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫะอๅ็ࠩॗ"),vU6DxuzPwMpg(u"ࠬะวิ฻ࠪक़"),KfHAW8VGbrxi(u"ู࠭ศึิࠫख़")]
NthIbLH8rscfGBD3eQlPy = SnhLjmfeJC(u"࠺࠵਩")
tpCSLxQO2swRuedhYbVB1Evri5k = LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠻࠶ਪ")*NthIbLH8rscfGBD3eQlPy
Ogcv69NTyBVC3qFG = QjAINyUC7MDRq5d8e4vl9(u"࠸࠴ਫ")*tpCSLxQO2swRuedhYbVB1Evri5k
hRSLmtPZW72H4wB = Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠳࠱ਬ")*Ogcv69NTyBVC3qFG
oWMrx7zvedHY0UiS48XbOqVTJ = D2D96X5NGamBhrFwvL8VEbqiSfZIl
D1KfvmcCjGYbgSoyX = Hr25gta6XcqO(u"࠴࠲ਭ")*NthIbLH8rscfGBD3eQlPy
d9vcuo3Hy7RhAk2 = teaC5j4HuGDqpwcmUzJ*tpCSLxQO2swRuedhYbVB1Evri5k
CQOaFUrZJHwKRxIj4yXEYs5V = SnhLjmfeJC(u"࠳࠹ਮ")*tpCSLxQO2swRuedhYbVB1Evri5k
rrux12tcwQl5 = XW57OCeGnFTLQbaqdrD9zM*Ogcv69NTyBVC3qFG
JJtWv7V436NPCf = sIzDXlTHYUC5L3xZGnr(u"࠶࠴ਯ")*Ogcv69NTyBVC3qFG
zz2tnLhI1QHV7GwFCrv5 = FgXzMs0YSDt(u"࠵࠷ਰ")*hRSLmtPZW72H4wB
zbE2LFPn8tvKmTgRB = tpCSLxQO2swRuedhYbVB1Evri5k
b7oUSdN4mCVYJnRcD = [ggjO5CrKVRPITaesWkxD(u"ࠧࡃࡑࡎࡖࡆ࠭ग़"),QjAINyUC7MDRq5d8e4vl9(u"ࠨࡒࡄࡒࡊ࡚ࠧज़"),FgXzMs0YSDt(u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧड़"),PlpyFa9QMKXxOD1cvHzmI(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭ढ़"),sJw9QWiq1Kr0xfeVRI(u"ࠫࡎࡌࡉࡍࡏࠪफ़"),uulNDCPyef78(u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫय़"),KfHAW8VGbrxi(u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭ॠ")]
b7oUSdN4mCVYJnRcD += [C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࡚ࠧࡖࡅࡣࡈࡎࡁࡏࡐࡈࡐࡘ࠭ॡ"),vU6DxuzPwMpg(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴ࠪॢ"),AAbvaXV2DQzfNHdm4U3tT(u"ࠩࡄࡏࡔࡇࡍࠨॣ"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠪࡅࡐ࡝ࡁࡎࠩ।"),Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭॥"),sJw9QWiq1Kr0xfeVRI(u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧ०")]
HLoqZTBg9OG4jRve87slbJzx1Arwa = [LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭१"),CsDcLqQUVK4YBvHFW1(u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ२"),FmYoGejTnwKME7d9zPc(u"ࠨࡖ࡙ࡊ࡚ࡔࠧ३"),AAbvaXV2DQzfNHdm4U3tT(u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪ४"),ggjO5CrKVRPITaesWkxD(u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫ५"),s5WMHyQN4mpie(u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨ६"),ggjO5CrKVRPITaesWkxD(u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧ७")]
HLoqZTBg9OG4jRve87slbJzx1Arwa += [wdftVMyzF17cYETHu(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ८"),AAbvaXV2DQzfNHdm4U3tT(u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ९"),EE1jeHnIoad(u"ࠨࡕࡋࡓࡋࡎࡁࠨ॰"),vU6DxuzPwMpg(u"࡚ࠩࡉࡈࡏࡍࡂ࠳ࠪॱ"),FgXzMs0YSDt(u"࡛ࠪࡊࡉࡉࡎࡃ࠵ࠫॲ")]
x4Tqfh8HrVD2WESzLYARMc0k7a5b = [oRJAfwD957WkUyBM1Ehu8m(u"࡙ࠫࡏࡋࡂࡃࡗࠫॳ"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠬࡇ࡙ࡍࡑࡏࠫॴ"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭ࡆࡐࡕࡗࡅࠬॵ"),o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧࡇࡃࡅࡖࡆࡑࡁࠨॶ"),FmYoGejTnwKME7d9zPc(u"ࠨ࡛ࡄࡕࡔ࡚ࠧॷ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩࡖࡌࡆࡈࡁࡌࡃࡗ࡝ࠬॸ"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࡚ࠪࡆࡘࡂࡐࡐࠪॹ"),s5WMHyQN4mpie(u"ࠫࡇࡘࡓࡕࡇࡍࠫॺ")]
x4Tqfh8HrVD2WESzLYARMc0k7a5b += [wdftVMyzF17cYETHu(u"ࠬࡑࡉࡓࡏࡄࡐࡐ࠭ॻ"),QjAINyUC7MDRq5d8e4vl9(u"࠭ࡁࡏࡋࡐࡉ࡟ࡏࡄࠨॼ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧࡇࡃࡕࡉࡘࡑࡏࠨॽ"),SnhLjmfeJC(u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪॾ"),KfHAW8VGbrxi(u"ࠩࡄࡐࡒ࡙ࡔࡃࡃࠪॿ"),SnhLjmfeJC(u"ࠪࡗࡍࡕࡏࡇࡐࡈࡘࠬঀ"),o1INZ3ViQqS0Uw5z6kMjbv(u"ࠫࡉࡘࡁࡎࡃࡖ࠻ࠬঁ")]
x4Tqfh8HrVD2WESzLYARMc0k7a5b += [wdftVMyzF17cYETHu(u"ࠬࡉࡉࡎࡃࡉࡖࡊࡋࠧং"),FgXzMs0YSDt(u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨঃ"),SnhLjmfeJC(u"ࠧࡆࡎࡌࡊ࡛ࡏࡄࡆࡑࠪ঄"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠨࡈࡘࡒࡔࡔࡔࡗࠩঅ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬআ"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫই"),o1INZ3ViQqS0Uw5z6kMjbv(u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭ঈ")]
x4Tqfh8HrVD2WESzLYARMc0k7a5b += [EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬࡇࡋࡘࡃࡐࡘ࡚ࡈࡅࠨউ"),jL5CrsRwebpyDVXUc1EQP(u"࠭ࡍࡂࡕࡄ࡚ࡎࡊࡅࡐࠩঊ"),oRJAfwD957WkUyBM1Ehu8m(u"ࠧࡅࡔࡄࡑࡆࡉࡁࡇࡇࠪঋ"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠨࡈࡘࡗࡍࡇࡒࡕࡘࠪঌ"),O3OVuapf0YFjbm5oUQDg(u"ࠩࡆࡍࡒࡇࡗࡃࡃࡖࠫ঍"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪࡅࡍ࡝ࡁࡌࠩ঎"),N6NGJ4vpmidqMCh7yo(u"࡛ࠫࡏࡄࡆࡑࡑࡗࡆࡋࡍࠨএ")]
x4Tqfh8HrVD2WESzLYARMc0k7a5b += [sJw9QWiq1Kr0xfeVRI(u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧঐ"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠭ࡓࡆࡔࡌࡉࡘ࡚ࡉࡎࡇࠪ঑"),ggjO5CrKVRPITaesWkxD(u"ࠧࡇࡗࡖࡌࡆࡘࡖࡊࡆࡈࡓࠬ঒"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠨࡅࡌࡑࡆ࠺ࡐࠨও"),QjAINyUC7MDRq5d8e4vl9(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫঔ"),o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬক"),sJw9QWiq1Kr0xfeVRI(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭খ")]
kzDO4FesBtbIZX1GRhSQLJcWi5PU0H = [Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭গ"),FgXzMs0YSDt(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧঘ"),Hr25gta6XcqO(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫঙ"),N6NGJ4vpmidqMCh7yo(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫচ")]
kzDO4FesBtbIZX1GRhSQLJcWi5PU0H += [wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧছ"),O3OVuapf0YFjbm5oUQDg(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡘࡌࡈࡊࡕࡓࠨজ"),I18uSKaWhgTBeYUPD4sr(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬঝ"),Hr25gta6XcqO(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬঞ"),s5WMHyQN4mpie(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡑࡏࡖࡆࡕࠪট"),Gcw2nelTR864XCVruO3mAFqI5a(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡎࡁࡔࡊࡗࡅࡌ࡙ࠧঠ")]
kzDO4FesBtbIZX1GRhSQLJcWi5PU0H += [o1INZ3ViQqS0Uw5z6kMjbv(u"ࠨࡋࡓࡘ࡛࠭ড"),aOQTKXFL54Nl60Zhp3MbE(u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬঢ"),QjAINyUC7MDRq5d8e4vl9(u"ࠪࡍࡕ࡚ࡖ࠮ࡏࡒ࡚ࡎࡋࡓࠨণ"),aOQTKXFL54Nl60Zhp3MbE(u"ࠫࡎࡖࡔࡗ࠯ࡖࡉࡗࡏࡅࡔࠩত")]
kzDO4FesBtbIZX1GRhSQLJcWi5PU0H += [o1INZ3ViQqS0Uw5z6kMjbv(u"ࠬࡓ࠳ࡖࠩথ"),wdftVMyzF17cYETHu(u"࠭ࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࠨদ"),sIzDXlTHYUC5L3xZGnr(u"ࠧࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫধ"),KfHAW8VGbrxi(u"ࠨࡏ࠶࡙࠲࡙ࡅࡓࡋࡈࡗࠬন")]
ohWgRN7TaPqXCrtjAyce40i = [vU6DxuzPwMpg(u"ࠩ࡜ࡘࡇࡥࡃࡉࡃࡑࡒࡊࡒࡓࠨ঩")]
MrZj4actWUgL3P2XpK6hA9z8CfoBDJ  = [C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠪࡅࡐ࡝ࡁࡎࠩপ"),aOQTKXFL54Nl60Zhp3MbE(u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭ফ"),Gcw2nelTR864XCVruO3mAFqI5a(u"ࠬࡈࡏࡌࡔࡄࠫব"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠭ࡁࡌࡑࡄࡑࠬভ"),SnhLjmfeJC(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩম"),PlpyFa9QMKXxOD1cvHzmI(u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩয"),I18uSKaWhgTBeYUPD4sr(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫর"),KfHAW8VGbrxi(u"ࠪࡇࡎࡓࡁࡇࡔࡈࡉࠬ঱"),ggjO5CrKVRPITaesWkxD(u"ࠫࡈࡏࡍࡂ࠶ࡓࠫল")]
MrZj4actWUgL3P2XpK6hA9z8CfoBDJ += [s5WMHyQN4mpie(u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧ঳"),sIzDXlTHYUC5L3xZGnr(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩ঴"),SnhLjmfeJC(u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨ঵"),Hr25gta6XcqO(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠲ࠩশ"),vU6DxuzPwMpg(u"࡚ࠩࡉࡈࡏࡍࡂ࠴ࠪষ"),sJw9QWiq1Kr0xfeVRI(u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧস"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠫࡋࡕࡓࡕࡃࠪহ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠬࡇࡈࡘࡃࡎࠫ঺"),PlpyFa9QMKXxOD1cvHzmI(u"࠭ࡓࡉࡑࡒࡊࡓࡋࡔࠨ঻")]
MrZj4actWUgL3P2XpK6hA9z8CfoBDJ += [uulNDCPyef78(u"ࠧࡔࡇࡕࡍࡊ࡙ࡔࡊࡏࡈ়ࠫ"),ssynAg0zhSkoCpOMDV9(u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫঽ"),AAbvaXV2DQzfNHdm4U3tT(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬা"),KfHAW8VGbrxi(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬি"),wdftVMyzF17cYETHu(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭ী"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧু"),aOQTKXFL54Nl60Zhp3MbE(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨূ"),ssynAg0zhSkoCpOMDV9(u"ࠧࡂࡍ࡚ࡅࡒ࡚ࡕࡃࡇࠪৃ")]
MrZj4actWUgL3P2XpK6hA9z8CfoBDJ += [Gcw2nelTR864XCVruO3mAFqI5a(u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩৄ"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ৅"),CsDcLqQUVK4YBvHFW1(u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬ৆"),EE1jeHnIoad(u"࡙ࠫ࡜ࡆࡖࡐࠪে"),FgXzMs0YSDt(u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧৈ"),uulNDCPyef78(u"࠭ࡓࡉࡑࡉࡌࡆ࠭৉"),ggjO5CrKVRPITaesWkxD(u"ࠧࡗࡃࡕࡆࡔࡔࠧ৊"),I18uSKaWhgTBeYUPD4sr(u"ࠨࡃࡏࡑࡘ࡚ࡂࡂࠩো"),KfHAW8VGbrxi(u"ࠩࡉࡅࡗࡋࡓࡌࡑࠪৌ")]
MrZj4actWUgL3P2XpK6hA9z8CfoBDJ += [Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪࡆࡗ࡙ࡔࡆࡌ্ࠪ"),QjAINyUC7MDRq5d8e4vl9(u"ࠫ࡞ࡇࡑࡐࡖࠪৎ"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠭৏"),vU6DxuzPwMpg(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧ৐"),uulNDCPyef78(u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗࠬ৑"),aOQTKXFL54Nl60Zhp3MbE(u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪ৒"),ggjO5CrKVRPITaesWkxD(u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫ৓"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠪࡐࡆࡘࡏ࡛ࡃࠪ৔"),FmYoGejTnwKME7d9zPc(u"ࠫࡈࡏࡍࡂ࡙ࡅࡅࡘ࠭৕")]
MrZj4actWUgL3P2XpK6hA9z8CfoBDJ += [C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬࡌࡕࡔࡊࡄࡖ࡛ࡏࡄࡆࡑࠪ৖"),aOQTKXFL54Nl60Zhp3MbE(u"࠭ࡆࡖࡕࡋࡅࡗ࡚ࡖࠨৗ"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠧࡌࡋࡕࡑࡆࡒࡋࠨ৘"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠨࡆࡕࡅࡒࡇࡃࡂࡈࡈࠫ৙"),I18uSKaWhgTBeYUPD4sr(u"ࠩࡗࡍࡐࡇࡁࡕࠩ৚"),KfHAW8VGbrxi(u"ࠪࡗࡍࡇࡂࡂࡍࡄࡘ࡞࠭৛"),O3OVuapf0YFjbm5oUQDg(u"ࠫࡆࡔࡉࡎࡇ࡝ࡍࡉ࠭ড়")]
tM6w03LZRPOsgXJrTnYbpiQ  = [C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࠪঢ়"),oRJAfwD957WkUyBM1Ehu8m(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ৞"),o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧয়"),EE1jeHnIoad(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡌࡊࡘࡈࡗࠬৠ"),Gcw2nelTR864XCVruO3mAFqI5a(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡉࡃࡖࡌ࡙ࡇࡇࡔࠩৡ")]
tM6w03LZRPOsgXJrTnYbpiQ += [FmYoGejTnwKME7d9zPc(u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩৢ"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫৣ")]
tM6w03LZRPOsgXJrTnYbpiQ += [I18uSKaWhgTBeYUPD4sr(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭৤"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ৥"),sIzDXlTHYUC5L3xZGnr(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪ০")]
tM6w03LZRPOsgXJrTnYbpiQ += [Hr25gta6XcqO(u"ࠨࡋࡓࡘ࡛࠳ࡌࡊࡘࡈࠫ১"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠩࡌࡔ࡙࡜࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ২"),ssynAg0zhSkoCpOMDV9(u"ࠪࡍࡕ࡚ࡖ࠮ࡕࡈࡖࡎࡋࡓࠨ৩")]
tM6w03LZRPOsgXJrTnYbpiQ += [EE1jeHnIoad(u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭৪"),sJw9QWiq1Kr0xfeVRI(u"ࠬࡓ࠳ࡖ࠯ࡐࡓ࡛ࡏࡅࡔࠩ৫"),sJw9QWiq1Kr0xfeVRI(u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪ৬")]
mZgLlGbnDTjwHE4vc2RCze = [C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧࡎ࠵ࡘࠫ৭"),vU6DxuzPwMpg(u"ࠨࡋࡓࡘ࡛࠭৮"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ৯"),EE1jeHnIoad(u"ࠪࡍࡋࡏࡌࡎࠩৰ"),SnhLjmfeJC(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬৱ")]
GgeKIqHm8XM = MrZj4actWUgL3P2XpK6hA9z8CfoBDJ+mZgLlGbnDTjwHE4vc2RCze
TwR9dnEiDPblt6Nzs8QMrX0VqO2om4 = MrZj4actWUgL3P2XpK6hA9z8CfoBDJ+tM6w03LZRPOsgXJrTnYbpiQ
Yc24yz3S6stmNI = TwR9dnEiDPblt6Nzs8QMrX0VqO2om4+ohWgRN7TaPqXCrtjAyce40i
cFTiOCdrXfgnKx0vh948jU7pSEb = [CsDcLqQUVK4YBvHFW1(u"ࠬࡖࡒࡊࡘࡄࡘࡊ࠭৲")]+b7oUSdN4mCVYJnRcD+[EE1jeHnIoad(u"࠭ࡍࡊ࡚ࡈࡈࠬ৳")]+HLoqZTBg9OG4jRve87slbJzx1Arwa+[Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠧࡑࡗࡅࡐࡎࡉࠧ৴")]+x4Tqfh8HrVD2WESzLYARMc0k7a5b+[uulNDCPyef78(u"ࠨࡒࡕࡍ࡛ࡇࡔࡆࠩ৵")]+kzDO4FesBtbIZX1GRhSQLJcWi5PU0H
zTl1tuniYCM80WApFeN3qQL4axEr = [ssynAg0zhSkoCpOMDV9(u"ࠩࡄࡏࡔࡇࡍࠨ৶"),EE1jeHnIoad(u"ࠪࡅࡐ࡝ࡁࡎࠩ৷"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠫࡎࡌࡉࡍࡏࠪ৸"),AAbvaXV2DQzfNHdm4U3tT(u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ৹"),N6NGJ4vpmidqMCh7yo(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ৺"),KfHAW8VGbrxi(u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩ৻"),uulNDCPyef78(u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫৼ"),FgXzMs0YSDt(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ৽"),KfHAW8VGbrxi(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨ৾"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠫࡒ࠹ࡕࠨ৿"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬࡏࡐࡕࡘࠪ਀"),vU6DxuzPwMpg(u"࠭ࡂࡐࡍࡕࡅࠬਁ"),uulNDCPyef78(u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࠩਂ"),vU6DxuzPwMpg(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭ਃ")]
NOT_TO_TEST_ALL_SERVERS = [AAbvaXV2DQzfNHdm4U3tT(u"ࠩࡢࡅࡐࡕ࡟ࠨ਄"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪࡣࡆࡑࡗࡠࠩਅ"),aOQTKXFL54Nl60Zhp3MbE(u"ࠫࡤࡏࡆࡍࡡࠪਆ"),aOQTKXFL54Nl60Zhp3MbE(u"ࠬࡥࡋࡓࡄࡢࠫਇ"),AAbvaXV2DQzfNHdm4U3tT(u"࠭࡟ࡎࡔࡉࡣࠬਈ"),aOQTKXFL54Nl60Zhp3MbE(u"ࠧࡠࡕࡋࡑࡤ࠭ਉ"),AAbvaXV2DQzfNHdm4U3tT(u"ࠨࡡࡖࡌ࡛ࡥࠧਊ"),sIzDXlTHYUC5L3xZGnr(u"ࠩࡢ࡝࡚࡚࡟ࠨ਋"),SnhLjmfeJC(u"ࠪࡣࡉࡒࡍࡠࠩ਌"),oRJAfwD957WkUyBM1Ehu8m(u"ࠫࡤࡓࡕࠨ਍"),EE1jeHnIoad(u"ࠬࡥࡉࡑࠩ਎"),aOQTKXFL54Nl60Zhp3MbE(u"࠭࡟ࡃࡍࡕࡣࠬਏ"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧࡠࡇࡏࡇࡤ࠭ਐ"),ggjO5CrKVRPITaesWkxD(u"ࠨࡡࡄࡖ࡙ࡥࠧ਑")]
sqfx3MXEol = [EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩࡐࡉࡓ࡛࡟ࡓࡇ࡙ࡉࡗ࡙ࡅࡅࡡࡓࡉࡗࡓࠧ਒"),wdftVMyzF17cYETHu(u"ࠪࡑࡊࡔࡕࡠࡃࡖࡇࡊࡔࡄࡆࡆࡢࡔࡊࡘࡍࠨਓ"),SnhLjmfeJC(u"ࠫࡒࡋࡎࡖࡡࡇࡉࡘࡉࡅࡏࡆࡈࡈࡤࡖࡅࡓࡏࠪਔ"),FmYoGejTnwKME7d9zPc(u"ࠬࡓࡅࡏࡗࡢࡖࡆࡔࡄࡐࡏࡌ࡞ࡊࡊ࡟ࡑࡇࡕࡑࠬਕ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠭ࡍࡆࡐࡘࡣࡗࡋࡖࡆࡔࡖࡉࡉࡥࡔࡆࡏࡓࠫਖ"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧࡎࡇࡑ࡙ࡤࡇࡓࡄࡇࡑࡈࡊࡊ࡟ࡕࡇࡐࡔࠬਗ"),I18uSKaWhgTBeYUPD4sr(u"ࠨࡏࡈࡒ࡚ࡥࡄࡆࡕࡆࡉࡓࡊࡅࡅࡡࡗࡉࡒࡖࠧਘ"),O3OVuapf0YFjbm5oUQDg(u"ࠩࡐࡉࡓ࡛࡟ࡓࡃࡑࡈࡔࡓࡉ࡛ࡇࡇࡣ࡙ࡋࡍࡑࠩਙ")]
Aa4EeTLwW15foql63y = [D2D96X5NGamBhrFwvL8VEbqiSfZIl,aOQTKXFL54Nl60Zhp3MbE(u"࠶࠻࠰਱"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠶࠼࠰ਿ"),ggjO5CrKVRPITaesWkxD(u"࠲࠹࠳ੂ"),QjAINyUC7MDRq5d8e4vl9(u"࠶࠿࠰ਸ"),FgXzMs0YSDt(u"࠳࠸࠳਻"),aOQTKXFL54Nl60Zhp3MbE(u"࠶࠽࠶ਾ"),wdftVMyzF17cYETHu(u"࠹࠳࠱ਹ"),PlpyFa9QMKXxOD1cvHzmI(u"࠵࠷࠴਼"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠺࠱࠱ਲ"),SnhLjmfeJC(u"࠵࠱࠲ੁ"),QjAINyUC7MDRq5d8e4vl9(u"࠹࠷࠶਷"),sIzDXlTHYUC5L3xZGnr(u"࠸࠷࠵਽"),N6NGJ4vpmidqMCh7yo(u"࠵࠵࠲਺"),O3OVuapf0YFjbm5oUQDg(u"࠽࠶࠱ੀ"),FgXzMs0YSDt(u"࠴࠴࠶࠶ਸ਼"),FmYoGejTnwKME7d9zPc(u"࠻࠼࠽࠵ਵ"),o1INZ3ViQqS0Uw5z6kMjbv(u"࠱࠱࠴࠳ਲ਼"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠲࠲࠻࠴਴")]
dKhwRkExMfaQXCj6rtHu0oD5sI = [sJw9QWiq1Kr0xfeVRI(u"ࠪ࠶࠺࠺ࡤࡥ࠵ࡤ࠸࠵࠿ࡤ࠹ࡤ࠹࠼࠶ࡪ࠴ࡦ࠳࠴࠻ࡪ࡫࠷࠹ࡥࡨࡦ࡫࠸࠹ࠨਚ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠫ࠶࠻࠰ࡥ࠴࠵ࡪ࠶࠳ࡣ࠶࠺ࡤ࠱࠹࠶࠲࠲࠯ࡤࡥ࠽࠺࠭ࡦ࠻࠵࠷ࡨࡧࡦ࠹࠷࠻࠷࠹࠭ਛ"),EE1jeHnIoad(u"ࠬ࠹࠹࠺࠳ࡨ࠽ࡨ࠻࠭࠸ࡧࡨ࠷࠲࠺ࡥࡦ࠴࠰࠼࠹ࡩ࠰࠮ࡨࡧ࠻࠾࠸ࡢࡢࡦࡧ࠷ࡩ࠻ࠧਜ"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠭࠷࠷ࡤ࠷ࡪࡨ࠹࠴ࡧࡥࡧ࠵࠾ࡪ࠹ࡤ࠷࠸ࡥ࠶࠻ࡦ࠴࠸࠳࠸ࡨࡪ࠹࠲࠶ࡦࠫਝ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧ࠲ࡘࡑࡷࡒࡺࡌ࠲ࡱࡅࡖ࡝ࡱࡓࡏࡅࡥࡇࡒࡐ࠱ࡌ࡚࡜ࡎ࡯ࡰ࠰ࡥ࡬࡝ࡻࠬਞ"),jL5CrsRwebpyDVXUc1EQP(u"ࠨࡣ࠷ࡪ࠼࡬ࡢ࠲࠶࠰࠶ࡩ࡫ࡦ࠮࠶࠳࠻࠶࠳࠸࠷࠶ࡥ࠱࠷࠸ࡥ࠴࠴࠹࠸ࡩ࠺ࡤࡥࡥࠪਟ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩ࠵ࡦ࠸࠺࠰ࡢ࠸࠻࠽࠵ࡧ࠵࠵࠲࠴ࡨࡧࡩ࠳࠸࠴ࡦ࠵࠶࠺࠵ࡥ࠻࠹࠶ࡪ࠾ࠧਠ"),sJw9QWiq1Kr0xfeVRI(u"ࠪࡧࡨ࠸࠶࠴ࡣࡥ࠵ࡪ࠻࠰࠵࠶ࡧ࠶ࡨࡧ࠵ࡥ࠷ࡧ࠷࡫࠿ࡥ࠴ࡥ࠶࠼࠻࡫ࡣࡢ࠳࠴࠴࠽࠹࠸࠺ࡣ࠺࠷ࠬਡ"),FmYoGejTnwKME7d9zPc(u"ࠫ࠶ࡩ࠳ࡥ࠵ࡤࡩ࠶࠾࠵ࡥࡨ࠷ࡦ࡫࠼ࡡࡧ࠷࠶࠷ࡨ࠽࠰࠵࠲ࡥ࠷࠹࠽ࡣ࠺ࡧ࠼࠽ࡧ࡫࠴࠷࠸ࡤࡩ࠾࠭ਢ")]
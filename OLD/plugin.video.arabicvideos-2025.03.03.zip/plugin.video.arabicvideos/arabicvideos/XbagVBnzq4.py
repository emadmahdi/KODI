# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'ALFATIMI'
K2l9rLfvoXxyZ4NYapO = '_FTM_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
bTnQ85HS1gMqGyt0LcEfeZkiFlAV6 = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
sXgZvu7tFxyabjkU8WA6i25P = ['3030','628']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==60: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==61: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,text)
	elif mode==62: OmsWt89dSA5HyCZ4wL = eQgbVPaIBvTn8fsjJRt241(url)
	elif mode==63: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==64: OmsWt89dSA5HyCZ4wL = dDsa9Ompxt8QPrSAkwq3eIF(text)
	elif mode==69: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,69,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'ما يتم مشاهدته الان',BOI3t1w8qfHAb0Kl4oMye7haEWS,64,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'recent_viewed_vids')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'الاكثر مشاهدة',BOI3t1w8qfHAb0Kl4oMye7haEWS,64,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'most_viewed_vids')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'اضيفت مؤخرا',BOI3t1w8qfHAb0Kl4oMye7haEWS,64,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'recently_added_vids')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'فيديو عشوائي',BOI3t1w8qfHAb0Kl4oMye7haEWS,64,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'random_vids')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'افلام ومسلسلات',BOI3t1w8qfHAb0Kl4oMye7haEWS,61,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'-1')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'البرامج الدينية',BOI3t1w8qfHAb0Kl4oMye7haEWS,61,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'-2')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'English Videos',BOI3t1w8qfHAb0Kl4oMye7haEWS,61,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'-3')
	return fy8iFgEkrO12NR9TWBI35sjY6qHvV
def HAsKeZdTbqjPI1WY(url,fnogyzNA30JCPMYqHTavG7ZKp):
	MmJTgOuqvRBkLEKt = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if fnogyzNA30JCPMYqHTavG7ZKp not in ['-1','-2','-3']: MmJTgOuqvRBkLEKt = '?cat='+fnogyzNA30JCPMYqHTavG7ZKp
	YLKFRH6sSIrznXBg = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/menu_level.php'+MmJTgOuqvRBkLEKt
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ALFATIMI-TITLES-1st')
	items = EcQxOa3RJm86WjTKA.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	VsJFRvj2Oyk5,IXlUkiwca1Yh5AQ9PNV3W2Cv4 = False,False
	for bigdh7fpZYl4aT2keV,title,count in items:
		title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
		title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
		if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = 'http:'+bigdh7fpZYl4aT2keV
		MmJTgOuqvRBkLEKt = EcQxOa3RJm86WjTKA.findall('cat=(.*?)&',bigdh7fpZYl4aT2keV,EcQxOa3RJm86WjTKA.DOTALL)[0]
		if fnogyzNA30JCPMYqHTavG7ZKp==MmJTgOuqvRBkLEKt: VsJFRvj2Oyk5 = True
		elif VsJFRvj2Oyk5 	or (fnogyzNA30JCPMYqHTavG7ZKp=='-1' and MmJTgOuqvRBkLEKt in bTnQ85HS1gMqGyt0LcEfeZkiFlAV6)  						or (fnogyzNA30JCPMYqHTavG7ZKp=='-2' and MmJTgOuqvRBkLEKt not in sXgZvu7tFxyabjkU8WA6i25P and MmJTgOuqvRBkLEKt not in bTnQ85HS1gMqGyt0LcEfeZkiFlAV6)  						or (fnogyzNA30JCPMYqHTavG7ZKp=='-3' and MmJTgOuqvRBkLEKt in sXgZvu7tFxyabjkU8WA6i25P):
							if count=='1': OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,63)
							else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,61,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,MmJTgOuqvRBkLEKt)
							IXlUkiwca1Yh5AQ9PNV3W2Cv4 = True
	if not IXlUkiwca1Yh5AQ9PNV3W2Cv4: eQgbVPaIBvTn8fsjJRt241(url)
	return
def eQgbVPaIBvTn8fsjJRt241(url):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,True,'ALFATIMI-EPISODES-1st')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('pagination(.*?)id="footer',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	items = EcQxOa3RJm86WjTKA.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	bigdh7fpZYl4aT2keV = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	for POjaBmHqzpsx1IYw7kQM4R,title,bigdh7fpZYl4aT2keV in items:
		title = title.replace('Add',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('to Quicklist',fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE)
		if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = 'http:'+bigdh7fpZYl4aT2keV
		OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,63,POjaBmHqzpsx1IYw7kQM4R)
	z6PX2p7diaskQElBOvMRNcHwqG5D=EcQxOa3RJm86WjTKA.findall('(.*?)div',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU=z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	wlJ6d8hEvpoMNSCmU=EcQxOa3RJm86WjTKA.findall('pagination(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)[0]
	items=EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	YLKFRH6sSIrznXBg = url.split('?')[0]
	for bigdh7fpZYl4aT2keV,BfYztCZvQdgx in items:
		bigdh7fpZYl4aT2keV = YLKFRH6sSIrznXBg + bigdh7fpZYl4aT2keV
		title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(BfYztCZvQdgx)
		title = 'صفحة ' + title
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,62)
	return bigdh7fpZYl4aT2keV
def rr7SfotkneX85Klup(url):
	if 'videos.php' in url: url = eQgbVPaIBvTn8fsjJRt241(url)
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,True,'ALFATIMI-PLAY-1st')
	items = EcQxOa3RJm86WjTKA.findall('playlistfile:"(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	E7HR1ZcMuzUs9XCVrNGJYi(url,BfWYUAnyg6eONLjiuE,'video')
	return
def dDsa9Ompxt8QPrSAkwq3eIF(fnogyzNA30JCPMYqHTavG7ZKp):
	B7gtJnK24RY = { 'mode' : fnogyzNA30JCPMYqHTavG7ZKp }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = YYpHcWVqImGPU4LXM(B7gtJnK24RY)
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(d9vcuo3Hy7RhAk2,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title,POjaBmHqzpsx1IYw7kQM4R in items:
		title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
		if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = 'http:'+bigdh7fpZYl4aT2keV
		OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,63,POjaBmHqzpsx1IYw7kQM4R)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	CE6HW2phYix9XvVdfqe1ObQIFl5mMj = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS + '/search_result.php?query=' + CE6HW2phYix9XvVdfqe1ObQIFl5mMj
	eQgbVPaIBvTn8fsjJRt241(url)
	return
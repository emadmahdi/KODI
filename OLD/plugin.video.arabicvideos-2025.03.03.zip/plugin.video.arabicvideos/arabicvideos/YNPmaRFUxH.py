# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'MOVIZLAND'
headers = { 'User-Agent' : fy8iFgEkrO12NR9TWBI35sjY6qHvV }
K2l9rLfvoXxyZ4NYapO = '_MVZ_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
rrkyXDFoKTYtf = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][1]
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==180: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==181: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,text)
	elif mode==182: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==183: OmsWt89dSA5HyCZ4wL = eQgbVPaIBvTn8fsjJRt241(url)
	elif mode==188: OmsWt89dSA5HyCZ4wL = Qr0OEzA7hsVTn2()
	elif mode==189: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def Qr0OEzA7hsVTn2():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج',message)
	return
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,189,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'بوكس اوفيس موفيز لاند',BOI3t1w8qfHAb0Kl4oMye7haEWS,181,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'box-office')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'أحدث الافلام',BOI3t1w8qfHAb0Kl4oMye7haEWS,181,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'latest-movies')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'تليفزيون موفيز لاند',BOI3t1w8qfHAb0Kl4oMye7haEWS,181,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'tv')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'الاكثر مشاهدة',BOI3t1w8qfHAb0Kl4oMye7haEWS,181,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'top-views')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'أقوى الافلام الحالية',BOI3t1w8qfHAb0Kl4oMye7haEWS,181,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'top-movies')
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'MOVIZLAND-MENU-1st')
	items = EcQxOa3RJm86WjTKA.findall('<h2><a href="(.*?)".*?">(.*?)<',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title in items:
		OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,181)
	return FGRX4myP68S
def HAsKeZdTbqjPI1WY(url,type=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': wlJ6d8hEvpoMNSCmU = EcQxOa3RJm86WjTKA.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)[0]
	elif type=='box-office': wlJ6d8hEvpoMNSCmU = EcQxOa3RJm86WjTKA.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)[0]
	elif type=='top-movies': wlJ6d8hEvpoMNSCmU = EcQxOa3RJm86WjTKA.findall('btn-2-overlay(.*?)<style>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)[0]
	elif type=='top-views': wlJ6d8hEvpoMNSCmU = EcQxOa3RJm86WjTKA.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)[0]
	elif type=='tv': wlJ6d8hEvpoMNSCmU = EcQxOa3RJm86WjTKA.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)[0]
	else: wlJ6d8hEvpoMNSCmU = FGRX4myP68S
	if type in ['top-views','top-movies']:
		items = EcQxOa3RJm86WjTKA.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	else: items = EcQxOa3RJm86WjTKA.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	cmDaLEqWlT7GhonIdX5k1zHQjSiupe = []
	SVzBiTcetyDnl = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for POjaBmHqzpsx1IYw7kQM4R,co5Qjlkev7zdPm,UwDjzXMGId87,afZQbHNSmXD7zJRvcBWUdL4 in items:
		if type in ['top-views','top-movies']:
			POjaBmHqzpsx1IYw7kQM4R,bigdh7fpZYl4aT2keV,R9b8gUvoB4wOfkTIjlEsZrM5LtinpS,title = POjaBmHqzpsx1IYw7kQM4R,co5Qjlkev7zdPm,UwDjzXMGId87,afZQbHNSmXD7zJRvcBWUdL4
		else: POjaBmHqzpsx1IYw7kQM4R,title,bigdh7fpZYl4aT2keV,R9b8gUvoB4wOfkTIjlEsZrM5LtinpS = POjaBmHqzpsx1IYw7kQM4R,co5Qjlkev7zdPm,UwDjzXMGId87,afZQbHNSmXD7zJRvcBWUdL4
		bigdh7fpZYl4aT2keV = U2Z7CVFftTmLeK3nzEbQPGga(bigdh7fpZYl4aT2keV)
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.replace('?view=true',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('بجوده ',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
		if 'الحلقة' in title or 'الحلقه' in title:
			RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) (الحلقة|الحلقه) \d+',title,EcQxOa3RJm86WjTKA.DOTALL)
			if RrzpbE3t9woCk7MXS0GvNdi1BcV:
				title = '_MOD_' + RrzpbE3t9woCk7MXS0GvNdi1BcV[0][0]
				if title not in cmDaLEqWlT7GhonIdX5k1zHQjSiupe:
					OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,183,POjaBmHqzpsx1IYw7kQM4R)
					cmDaLEqWlT7GhonIdX5k1zHQjSiupe.append(title)
		elif any(value in title for value in SVzBiTcetyDnl):
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV + '?servers=' + R9b8gUvoB4wOfkTIjlEsZrM5LtinpS
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,182,POjaBmHqzpsx1IYw7kQM4R)
		else:
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV + '?servers=' + R9b8gUvoB4wOfkTIjlEsZrM5LtinpS
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,183,POjaBmHqzpsx1IYw7kQM4R)
	if type==fy8iFgEkrO12NR9TWBI35sjY6qHvV:
		items = EcQxOa3RJm86WjTKA.findall('\n<li><a href="(.*?)".*?>(.*?)<',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
			title = title.replace('الصفحة ',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			if title!=fy8iFgEkrO12NR9TWBI35sjY6qHvV:
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,181)
	return
def eQgbVPaIBvTn8fsjJRt241(url):
	YLKFRH6sSIrznXBg = url.split('?servers=')[0]
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'MOVIZLAND-EPISODES-1st')
	wlJ6d8hEvpoMNSCmU = EcQxOa3RJm86WjTKA.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	title,O4On5rLamD7q1zKBo6WfF3eEbS98,POjaBmHqzpsx1IYw7kQM4R = wlJ6d8hEvpoMNSCmU[0]
	name = EcQxOa3RJm86WjTKA.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,EcQxOa3RJm86WjTKA.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="episodesNumbers"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV in items:
			bigdh7fpZYl4aT2keV = U2Z7CVFftTmLeK3nzEbQPGga(bigdh7fpZYl4aT2keV)
			title = EcQxOa3RJm86WjTKA.findall('(الحلقة|الحلقه)-([0-9]+)',bigdh7fpZYl4aT2keV.split('/')[-2],EcQxOa3RJm86WjTKA.DOTALL)
			if not title: title = EcQxOa3RJm86WjTKA.findall('()-([0-9]+)',bigdh7fpZYl4aT2keV.split('/')[-2],EcQxOa3RJm86WjTKA.DOTALL)
			if title: title = ksJdoFWhxTz8Y2N7bOZE + title[0][1]
			else: title = fy8iFgEkrO12NR9TWBI35sjY6qHvV
			title = name + ' - ' + 'الحلقة' + title
			title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,182,POjaBmHqzpsx1IYw7kQM4R)
	if not items:
		title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('بجوده ',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,url,182,POjaBmHqzpsx1IYw7kQM4R)
	return
def rr7SfotkneX85Klup(url):
	tvl3Tdjo9w = url.split('?servers=')
	YLKFRH6sSIrznXBg = tvl3Tdjo9w[0]
	del tvl3Tdjo9w[0]
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'MOVIZLAND-PLAY-1st')
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall('font-size: 25px;" href="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)[0]
	if bigdh7fpZYl4aT2keV not in tvl3Tdjo9w: tvl3Tdjo9w.append(bigdh7fpZYl4aT2keV)
	XoSyx7p6dqZ1CF8 = []
	for bigdh7fpZYl4aT2keV in tvl3Tdjo9w:
		if '://moshahda.' in bigdh7fpZYl4aT2keV:
			xP1Mq7y4woLNXF6batEUkIGYWzsZKQ = bigdh7fpZYl4aT2keV
			XoSyx7p6dqZ1CF8.append(xP1Mq7y4woLNXF6batEUkIGYWzsZKQ+'?named=Main')
	for bigdh7fpZYl4aT2keV in tvl3Tdjo9w:
		if '://vb.movizland.' in bigdh7fpZYl4aT2keV:
			FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,bigdh7fpZYl4aT2keV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'MOVIZLAND-PLAY-2nd')
			FGRX4myP68S = FGRX4myP68S.decode('windows-1256').encode(Tk9eH2qw6Brsuhj)
			FGRX4myP68S = FGRX4myP68S.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			FGRX4myP68S = FGRX4myP68S.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			FGRX4myP68S = FGRX4myP68S.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			FGRX4myP68S = FGRX4myP68S.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
			if z6PX2p7diaskQElBOvMRNcHwqG5D:
				O9nG5azDistV1c,TCGZwKs43fSniQe6EqctNuW = [],[]
				if len(z6PX2p7diaskQElBOvMRNcHwqG5D)==1:
					title = fy8iFgEkrO12NR9TWBI35sjY6qHvV
					wlJ6d8hEvpoMNSCmU = FGRX4myP68S
				else:
					for wlJ6d8hEvpoMNSCmU in z6PX2p7diaskQElBOvMRNcHwqG5D:
						OOCx0SzAcisQIJGM6DZkopvB3 = EcQxOa3RJm86WjTKA.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
						if OOCx0SzAcisQIJGM6DZkopvB3: wlJ6d8hEvpoMNSCmU = 'src="/uploads/13721411411.png"  \n  ' + OOCx0SzAcisQIJGM6DZkopvB3[0][1]
						OOCx0SzAcisQIJGM6DZkopvB3 = EcQxOa3RJm86WjTKA.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
						if OOCx0SzAcisQIJGM6DZkopvB3: wlJ6d8hEvpoMNSCmU = 'src="/uploads/13721411411.png"  \n  ' + OOCx0SzAcisQIJGM6DZkopvB3[0]
						OOCx0SzAcisQIJGM6DZkopvB3 = EcQxOa3RJm86WjTKA.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
						if OOCx0SzAcisQIJGM6DZkopvB3: wlJ6d8hEvpoMNSCmU = OOCx0SzAcisQIJGM6DZkopvB3[0] + '  \n  src="/uploads/13721411411.png"'
						QOD2YWz5dyCNBZjMtg = EcQxOa3RJm86WjTKA.findall('<(.*?)http://up.movizland.(online|com)/uploads/',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
						title = EcQxOa3RJm86WjTKA.findall('> *([^<>]+) *<',QOD2YWz5dyCNBZjMtg[0][0],EcQxOa3RJm86WjTKA.DOTALL)
						title = ksJdoFWhxTz8Y2N7bOZE.join(title)
						title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
						title = title.replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE)
						O9nG5azDistV1c.append(title)
					yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S('أختر الفيديو المطلوب:', O9nG5azDistV1c)
					if yNqzFDjKM0SrO == -1 : return
					title = O9nG5azDistV1c[yNqzFDjKM0SrO]
					wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[yNqzFDjKM0SrO]
				bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall('href="(http://moshahda\..*?/\w+.html)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
				yVikMYPmf0laszqnu = bigdh7fpZYl4aT2keV[0]
				XoSyx7p6dqZ1CF8.append(yVikMYPmf0laszqnu+'?named=Forum')
				wlJ6d8hEvpoMNSCmU = wlJ6d8hEvpoMNSCmU.replace('ـ',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
				wlJ6d8hEvpoMNSCmU = wlJ6d8hEvpoMNSCmU.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				wlJ6d8hEvpoMNSCmU = wlJ6d8hEvpoMNSCmU.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				wlJ6d8hEvpoMNSCmU = wlJ6d8hEvpoMNSCmU.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				wlJ6d8hEvpoMNSCmU = wlJ6d8hEvpoMNSCmU.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				wlJ6d8hEvpoMNSCmU = wlJ6d8hEvpoMNSCmU.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				wlJ6d8hEvpoMNSCmU = wlJ6d8hEvpoMNSCmU.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				IdKu1znxPeg28EH = EcQxOa3RJm86WjTKA.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
				for fe3m8wDioCPRvLcsY6n5jqOg in IdKu1znxPeg28EH:
					type = EcQxOa3RJm86WjTKA.findall(' typetype="(.*?)" ',fe3m8wDioCPRvLcsY6n5jqOg)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = fy8iFgEkrO12NR9TWBI35sjY6qHvV
					items = EcQxOa3RJm86WjTKA.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',fe3m8wDioCPRvLcsY6n5jqOg,EcQxOa3RJm86WjTKA.DOTALL)
					for PuOsWlzRkEGCAnJob4iUML2Kj0e,bigdh7fpZYl4aT2keV in items:
						title = EcQxOa3RJm86WjTKA.findall('(\w+[ \w]*)<',PuOsWlzRkEGCAnJob4iUML2Kj0e)
						title = title[-1]
						bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV + '?named=' + title + type
						XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	MYWwFs7XA2 = YLKFRH6sSIrznXBg.replace(BOI3t1w8qfHAb0Kl4oMye7haEWS,rrkyXDFoKTYtf)
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,MYWwFs7XA2,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'MOVIZLAND-PLAY-3rd')
	items = EcQxOa3RJm86WjTKA.findall('" href="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if items:
		f1uU4QIdLApO = items[-1]
		XoSyx7p6dqZ1CF8.append(f1uU4QIdLApO+'?named=Mobile')
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(XoSyx7p6dqZ1CF8,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'MOVIZLAND-SEARCH-1st')
	items = EcQxOa3RJm86WjTKA.findall('<option value="(.*?)">(.*?)</option>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	guMrTK2yQvC = [ fy8iFgEkrO12NR9TWBI35sjY6qHvV ]
	hGxS0TvsVkHb3te9R1YaAf2FE = [ 'الكل وبدون فلتر' ]
	for fnogyzNA30JCPMYqHTavG7ZKp,title in items:
		guMrTK2yQvC.append(fnogyzNA30JCPMYqHTavG7ZKp)
		hGxS0TvsVkHb3te9R1YaAf2FE.append(title)
	if fnogyzNA30JCPMYqHTavG7ZKp:
		yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S('اختر الفلتر المناسب:', hGxS0TvsVkHb3te9R1YaAf2FE)
		if yNqzFDjKM0SrO == -1 : return
		fnogyzNA30JCPMYqHTavG7ZKp = guMrTK2yQvC[yNqzFDjKM0SrO]
	else: fnogyzNA30JCPMYqHTavG7ZKp = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS + '/?s='+search+'&mcat='+fnogyzNA30JCPMYqHTavG7ZKp
	HAsKeZdTbqjPI1WY(url)
	return
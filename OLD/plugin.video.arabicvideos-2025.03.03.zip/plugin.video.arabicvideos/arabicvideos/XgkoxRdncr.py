# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'FAJERSHOW'
K2l9rLfvoXxyZ4NYapO = '_FJS_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['التصنيفات','انشاء حساب','طلبات الزوّار']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==390: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==391: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,text)
	elif mode==392: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==393: OmsWt89dSA5HyCZ4wL = eQgbVPaIBvTn8fsjJRt241(url)
	elif mode==399: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,399,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FAJERSHOW-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	items = EcQxOa3RJm86WjTKA.findall('<header>.*?<h2>(.*?)<',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	for iYMzQVNL2h4IRemt in range(len(items)):
		title = items[iYMzQVNL2h4IRemt]
		OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,BOI3t1w8qfHAb0Kl4oMye7haEWS,391,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'latest'+str(iYMzQVNL2h4IRemt))
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'مختارات عشوائية',BOI3t1w8qfHAb0Kl4oMye7haEWS,391,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'randoms')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'أعلى الأفلام تقييماً',BOI3t1w8qfHAb0Kl4oMye7haEWS,391,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'top_imdb_movies')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'أعلى المسلسلات تقييماً',BOI3t1w8qfHAb0Kl4oMye7haEWS,391,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'top_imdb_series')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'أفلام مميزة',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/movies',391,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'featured_movies')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'مسلسلات مميزة',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/tvshows',391,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'featured_tvshows')
	wlJ6d8hEvpoMNSCmU = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="menu"(.*?)id="contenedor"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D: wlJ6d8hEvpoMNSCmU += z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/movies',fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FAJERSHOW-MENU-2nd')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="releases"(.*?)aside',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D: wlJ6d8hEvpoMNSCmU += z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	lUT6n1NfYxdp2IscbE8oq = True
	for bigdh7fpZYl4aT2keV,title in items:
		title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
		if title=='الأعلى مشاهدة':
			if lUT6n1NfYxdp2IscbE8oq:
				title = 'الافلام '+title
				lUT6n1NfYxdp2IscbE8oq = False
			else: title = 'المسلسلات '+title
		if title not in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o:
			if title=='أفلام': OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,BOI3t1w8qfHAb0Kl4oMye7haEWS+'/movies',391,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'all_movies_tvshows')
			elif title=='مسلسلات': OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,BOI3t1w8qfHAb0Kl4oMye7haEWS+'/tvshows',391,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'all_movies_tvshows')
			else: OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,391)
	return FGRX4myP68S
def HAsKeZdTbqjPI1WY(url,type):
	wlJ6d8hEvpoMNSCmU,items = [],[]
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FAJERSHOW-TITLES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	if type in ['featured_movies','featured_tvshows']:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="content"(.*?)id="archive-content"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D: wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	elif type=='all_movies_tvshows':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('id="archive-content"(.*?)class="pagination"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D: wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	elif type=='top_imdb_movies':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall("class='top-imdb-list tleft(.*?)class='top-imdb-list tright",FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	elif type=='top_imdb_series':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall("class='top-imdb-list tright(.*?)footer",FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	elif type=='search':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="search-page"(.*?)class="sidebar',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	elif type=='sider':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="widget(.*?)class="widget',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		fCv8TGZdqry = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		XoSyx7p6dqZ1CF8,llULprvZxA9IyqF1kWaifs8g,WFlpmsYGKNy = zip(*fCv8TGZdqry)
		items = zip(llULprvZxA9IyqF1kWaifs8g,XoSyx7p6dqZ1CF8,WFlpmsYGKNy)
	elif type=='randoms':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('id="slider-movies-tvshows"(.*?)<header>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	elif 'latest' in type:
		iYMzQVNL2h4IRemt = int(type[-1:])
		FGRX4myP68S = FGRX4myP68S.replace('<header>','<end><start>')
		FGRX4myP68S = FGRX4myP68S.replace('</div></div></div>','</div></div></div><end>')
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('<start>(.*?)<end>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[iYMzQVNL2h4IRemt]
		if iYMzQVNL2h4IRemt==6:
			fCv8TGZdqry = EcQxOa3RJm86WjTKA.findall('img src="(.*?)" alt="(.*?)".*?href="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			llULprvZxA9IyqF1kWaifs8g,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = zip(*fCv8TGZdqry)
			items = zip(llULprvZxA9IyqF1kWaifs8g,XoSyx7p6dqZ1CF8,WFlpmsYGKNy)
	else:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="content"(.*?)class="(pagination|sidebar)',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0][0]
			if '/collection/' in url:
				items = EcQxOa3RJm86WjTKA.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			elif '/quality/' in url:
				items = EcQxOa3RJm86WjTKA.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	if not items and wlJ6d8hEvpoMNSCmU:
		items = EcQxOa3RJm86WjTKA.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	cmDaLEqWlT7GhonIdX5k1zHQjSiupe = []
	for POjaBmHqzpsx1IYw7kQM4R,bigdh7fpZYl4aT2keV,title in items:
		if 'src=' in title: continue
		if 'serie' in title:
			title = EcQxOa3RJm86WjTKA.findall('^(.*?)<.*?serie">(.*?)<',title,EcQxOa3RJm86WjTKA.DOTALL)
			title = title[0][1]
			if title in cmDaLEqWlT7GhonIdX5k1zHQjSiupe: continue
			cmDaLEqWlT7GhonIdX5k1zHQjSiupe.append(title)
			title = '_MOD_'+title
		D4DQ6k0oS39GKbZrthnsTB = EcQxOa3RJm86WjTKA.findall('^(.*?)<',title,EcQxOa3RJm86WjTKA.DOTALL)
		if D4DQ6k0oS39GKbZrthnsTB: title = D4DQ6k0oS39GKbZrthnsTB[0]
		title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
		if '/tvshows/' in bigdh7fpZYl4aT2keV: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,393,POjaBmHqzpsx1IYw7kQM4R)
		elif '/episodes/' in bigdh7fpZYl4aT2keV: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,393,POjaBmHqzpsx1IYw7kQM4R)
		elif '/seasons/' in bigdh7fpZYl4aT2keV: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,393,POjaBmHqzpsx1IYw7kQM4R)
		elif '/collection/' in bigdh7fpZYl4aT2keV: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,391,POjaBmHqzpsx1IYw7kQM4R)
		else: OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,392,POjaBmHqzpsx1IYw7kQM4R)
	if type not in ['featured_movies','featured_tvshows']:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"pagination"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title in items:
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,391,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,type)
	return
def eQgbVPaIBvTn8fsjJRt241(url):
	A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(url,'url')
	url = url.replace(A8ECQ0qwTRzPifOGW76FK35uUvhe,BOI3t1w8qfHAb0Kl4oMye7haEWS)
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FAJERSHOW-EPISODES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	uuigJsvIZQ3tprnhxG = EcQxOa3RJm86WjTKA.findall('class="C rated".*?>(.*?)<',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if uuigJsvIZQ3tprnhxG and SYJvigbI3fts(BfWYUAnyg6eONLjiuE,url,uuigJsvIZQ3tprnhxG): return
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('<ul class="episodios">(.*?)</ul></div></div></div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('src="(.*?)".*?href="(.*?)">(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for POjaBmHqzpsx1IYw7kQM4R,bigdh7fpZYl4aT2keV,title in items:
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,392,POjaBmHqzpsx1IYw7kQM4R)
	return
def rr7SfotkneX85Klup(url):
	FGRX4myP68S = GMec7YSfxPCZHv(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FAJERSHOW-PLAY-1st')
	uuigJsvIZQ3tprnhxG = EcQxOa3RJm86WjTKA.findall('class="C rated".*?>(.*?)<',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if uuigJsvIZQ3tprnhxG and SYJvigbI3fts(BfWYUAnyg6eONLjiuE,url,uuigJsvIZQ3tprnhxG): return
	XoSyx7p6dqZ1CF8 = []
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('id="player-option-1"(.*?)class=["|\'](sheader|pag_episodes)["|\']',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0][0]
		items = EcQxOa3RJm86WjTKA.findall('data-type="(.*?)" data-post="(.*?)" data-nume="(.*?)".*?class="vid_title">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for type,JA3FuzlcgjrGP,rZnNGC8JmQg,title in items:
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/wp-admin/admin-ajax.php?action=doo_player_ajax&post='+JA3FuzlcgjrGP+'&nume='+rZnNGC8JmQg+'&type='+type
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+title+'__watch'
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('''id=["']download["'] class(.*?)class=["']sbox["']''',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('''img src=["'](.*?)["'].*?href=["'](.*?)["'].*?["']quality["']>(.*?)<.*?<td>(.*?)<''',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for POjaBmHqzpsx1IYw7kQM4R,bigdh7fpZYl4aT2keV,OOnVxtP0TNWsci6HrEGqBm9boKF7g,PwOhx7WTAQGq8o2n in items:
			if '=' in POjaBmHqzpsx1IYw7kQM4R:
				VRobjUJBgkECGnx68019i = POjaBmHqzpsx1IYw7kQM4R.split('=')[1]
				title = VbHeOuU1ilzSp2ZRXwBD(VRobjUJBgkECGnx68019i,'host')
			else: title = fy8iFgEkrO12NR9TWBI35sjY6qHvV
			title = PwOhx7WTAQGq8o2n+ksJdoFWhxTz8Y2N7bOZE+title
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+title+'__download____'+OOnVxtP0TNWsci6HrEGqBm9boKF7g
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(XoSyx7p6dqZ1CF8,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/?s='+search
	HAsKeZdTbqjPI1WY(url,'search')
	return
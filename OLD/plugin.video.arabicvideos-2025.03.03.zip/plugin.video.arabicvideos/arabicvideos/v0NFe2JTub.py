# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'SHOOFMAX'
K2l9rLfvoXxyZ4NYapO = '_SHM_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
rrkyXDFoKTYtf = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][1]
bmYdTZFyoVtj0w2OJszHu3ilNPC = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][2]
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==50: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==51: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url)
	elif mode==52: OmsWt89dSA5HyCZ4wL = eQgbVPaIBvTn8fsjJRt241(url)
	elif mode==53: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==55: OmsWt89dSA5HyCZ4wL = dwSDG7amtUg2uB6cCp91hRfYsLXZi()
	elif mode==56: OmsWt89dSA5HyCZ4wL = UM31Sm4gHN0t2lPa()
	elif mode==57: OmsWt89dSA5HyCZ4wL = wphD0TcF1azLx7y3iWtXCqkR4sUB(url,1)
	elif mode==58: OmsWt89dSA5HyCZ4wL = wphD0TcF1azLx7y3iWtXCqkR4sUB(url,2)
	elif mode==59: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,59,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'المسلسلات',fy8iFgEkrO12NR9TWBI35sjY6qHvV,56)
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'الافلام',fy8iFgEkrO12NR9TWBI35sjY6qHvV,55)
	return fy8iFgEkrO12NR9TWBI35sjY6qHvV
def dwSDG7amtUg2uB6cCp91hRfYsLXZi():
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'أفلام مرتبة بسنة الإنتاج',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/movie/1/yop',57)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'أفلام مرتبة بالأفضل تقييم',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/movie/1/review',57)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'أفلام مرتبة بالأكثر مشاهدة',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/movie/1/views',57)
	return
def UM31Sm4gHN0t2lPa():
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مسلسلات مرتبة بسنة الإنتاج',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/series/1/yop',57)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مسلسلات مرتبة بالأفضل تقييم',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/series/1/review',57)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مسلسلات مرتبة بالأكثر مشاهدة',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/series/1/views',57)
	return
def HAsKeZdTbqjPI1WY(url):
	if '?' in url:
		V5VDwKLAYM3 = url.split('?')
		url = V5VDwKLAYM3[0]
		filter = '?' + DVX5GWhnIxYlSd9rEuetjk40UJ(V5VDwKLAYM3[1],'=&:/%')
	else: filter = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	type,jmI9qRnVJo2a3tpcH8gfYkP,sort = url.split('/')[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': zSydkVHNCriWaqT8ltOmbnuoKDI='فيلم'
		elif type=='series': zSydkVHNCriWaqT8ltOmbnuoKDI='مسلسل'
		url = BOI3t1w8qfHAb0Kl4oMye7haEWS + '/genre/filter/' + DVX5GWhnIxYlSd9rEuetjk40UJ(zSydkVHNCriWaqT8ltOmbnuoKDI) + '/' + jmI9qRnVJo2a3tpcH8gfYkP + '/' + sort + filter
		FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SHOOFMAX-TITLES-1st')
		items = EcQxOa3RJm86WjTKA.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		TU8AWL9N5h0QntyOZcbz=0
		for id,title,CDPiyFrts4wpJXGV28HLbudZQNOmv3,POjaBmHqzpsx1IYw7kQM4R in items:
			TU8AWL9N5h0QntyOZcbz += 1
			POjaBmHqzpsx1IYw7kQM4R = bmYdTZFyoVtj0w2OJszHu3ilNPC + '/v2/img/program/main/' + POjaBmHqzpsx1IYw7kQM4R + '-2.jpg'
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS + '/program/' + id
			if type=='movie': OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,53,POjaBmHqzpsx1IYw7kQM4R)
			if type=='series': OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مسلسل '+title,bigdh7fpZYl4aT2keV+'?ep='+CDPiyFrts4wpJXGV28HLbudZQNOmv3+'='+title+'='+POjaBmHqzpsx1IYw7kQM4R,52,POjaBmHqzpsx1IYw7kQM4R)
	else:
		if type=='movie': zSydkVHNCriWaqT8ltOmbnuoKDI='movies'
		elif type=='series': zSydkVHNCriWaqT8ltOmbnuoKDI='series'
		url = rrkyXDFoKTYtf + '/json/selected/' + sort + '-' + zSydkVHNCriWaqT8ltOmbnuoKDI + '-WW.json'
		FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SHOOFMAX-TITLES-2nd')
		items = EcQxOa3RJm86WjTKA.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		TU8AWL9N5h0QntyOZcbz=0
		for id,CDPiyFrts4wpJXGV28HLbudZQNOmv3,POjaBmHqzpsx1IYw7kQM4R,title in items:
			TU8AWL9N5h0QntyOZcbz += 1
			POjaBmHqzpsx1IYw7kQM4R = rrkyXDFoKTYtf + '/img/program/' + POjaBmHqzpsx1IYw7kQM4R + '-2.jpg'
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS + '/program/' + id
			if type=='movie': OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,53,POjaBmHqzpsx1IYw7kQM4R)
			elif type=='series': OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مسلسل '+title,bigdh7fpZYl4aT2keV+'?ep='+CDPiyFrts4wpJXGV28HLbudZQNOmv3+'='+title+'='+POjaBmHqzpsx1IYw7kQM4R,52,POjaBmHqzpsx1IYw7kQM4R)
	title='صفحة '
	if TU8AWL9N5h0QntyOZcbz==16:
		for ssCHhqKQeO9aVkgZ in range(1,13) :
			if not jmI9qRnVJo2a3tpcH8gfYkP==str(ssCHhqKQeO9aVkgZ):
				url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/genre/filter/'+type+'/'+str(ssCHhqKQeO9aVkgZ)+'/'+sort+filter
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title+str(ssCHhqKQeO9aVkgZ),url,51)
	return
def eQgbVPaIBvTn8fsjJRt241(url):
	V5VDwKLAYM3 = url.split('=')
	CDPiyFrts4wpJXGV28HLbudZQNOmv3 = int(V5VDwKLAYM3[1])
	name = U2Z7CVFftTmLeK3nzEbQPGga(V5VDwKLAYM3[2])
	name = name.replace('_MOD_مسلسل ',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	POjaBmHqzpsx1IYw7kQM4R = V5VDwKLAYM3[3]
	url = url.split('?')[0]
	if CDPiyFrts4wpJXGV28HLbudZQNOmv3==0:
		FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SHOOFMAX-EPISODES-1st')
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('<select(.*?)</select>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('option value="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		CDPiyFrts4wpJXGV28HLbudZQNOmv3 = int(items[-1])
	for RrzpbE3t9woCk7MXS0GvNdi1BcV in range(CDPiyFrts4wpJXGV28HLbudZQNOmv3,0,-1):
		bigdh7fpZYl4aT2keV = url + '?ep=' + str(RrzpbE3t9woCk7MXS0GvNdi1BcV)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(RrzpbE3t9woCk7MXS0GvNdi1BcV)
		OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,53,POjaBmHqzpsx1IYw7kQM4R)
	return
def rr7SfotkneX85Klup(url):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SHOOFMAX-PLAY-1st')
	vgKzN2Gn01FJMApmHWS49kacQBP3ut = EcQxOa3RJm86WjTKA.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if vgKzN2Gn01FJMApmHWS49kacQBP3ut:
		uUqrNPcXKBoQ0slv = vgKzN2Gn01FJMApmHWS49kacQBP3ut[1].replace('T',zz5wETpjWKMNb6JiLRndGhV9)
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+C0qrknitpM4Z+uUqrNPcXKBoQ0slv)
		return
	qilJZrsAzovnaNmSPO7tgBKex1YE,hWQXabzFEId0p5m3f7JgAiCeUlPR = [],[]
	gmCwvdtQJiaSfrbThoH5lAqj = EcQxOa3RJm86WjTKA.findall('var origin_link = "(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)[0]
	a4ax3zG1hjrXUHmpCMEnlN9yeou = EcQxOa3RJm86WjTKA.findall('var backup_origin_link = "(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)[0]
	zzECVswWcGAIXhrQlZ7jMokugnv = EcQxOa3RJm86WjTKA.findall('hls: (.*?)_link\+"(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	for A8ECQ0qwTRzPifOGW76FK35uUvhe,bigdh7fpZYl4aT2keV in zzECVswWcGAIXhrQlZ7jMokugnv:
		if 'backup' in A8ECQ0qwTRzPifOGW76FK35uUvhe:
			A8ECQ0qwTRzPifOGW76FK35uUvhe = 'backup server'
			url = a4ax3zG1hjrXUHmpCMEnlN9yeou + bigdh7fpZYl4aT2keV
		else:
			A8ECQ0qwTRzPifOGW76FK35uUvhe = 'main server'
			url = gmCwvdtQJiaSfrbThoH5lAqj + bigdh7fpZYl4aT2keV
		if '.m3u8' in url:
			qilJZrsAzovnaNmSPO7tgBKex1YE.append(url)
			hWQXabzFEId0p5m3f7JgAiCeUlPR.append('m3u8  '+A8ECQ0qwTRzPifOGW76FK35uUvhe)
	zzECVswWcGAIXhrQlZ7jMokugnv = EcQxOa3RJm86WjTKA.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	zzECVswWcGAIXhrQlZ7jMokugnv += EcQxOa3RJm86WjTKA.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	for A8ECQ0qwTRzPifOGW76FK35uUvhe,bigdh7fpZYl4aT2keV in zzECVswWcGAIXhrQlZ7jMokugnv:
		filename = bigdh7fpZYl4aT2keV.split('/')[-1]
		filename = filename.replace('fallback',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		filename = filename.replace('.mp4',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		filename = filename.replace('-',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		if 'backup' in A8ECQ0qwTRzPifOGW76FK35uUvhe:
			A8ECQ0qwTRzPifOGW76FK35uUvhe = 'backup server'
			url = a4ax3zG1hjrXUHmpCMEnlN9yeou + bigdh7fpZYl4aT2keV
		else:
			A8ECQ0qwTRzPifOGW76FK35uUvhe = 'main server'
			url = gmCwvdtQJiaSfrbThoH5lAqj + bigdh7fpZYl4aT2keV
		qilJZrsAzovnaNmSPO7tgBKex1YE.append(url)
		hWQXabzFEId0p5m3f7JgAiCeUlPR.append('mp4  '+A8ECQ0qwTRzPifOGW76FK35uUvhe+OOiSqkBcMPptI+filename)
	yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S('Select Video Quality:', hWQXabzFEId0p5m3f7JgAiCeUlPR)
	if yNqzFDjKM0SrO == -1 : return
	url = qilJZrsAzovnaNmSPO7tgBKex1YE[yNqzFDjKM0SrO]
	E7HR1ZcMuzUs9XCVrNGJYi(url,BfWYUAnyg6eONLjiuE,'video')
	return
def wphD0TcF1azLx7y3iWtXCqkR4sUB(url,type):
	if 'series' in url: YLKFRH6sSIrznXBg = BOI3t1w8qfHAb0Kl4oMye7haEWS + '/genre/مسلسل'
	else: YLKFRH6sSIrznXBg = BOI3t1w8qfHAb0Kl4oMye7haEWS + '/genre/فيلم'
	YLKFRH6sSIrznXBg = DVX5GWhnIxYlSd9rEuetjk40UJ(YLKFRH6sSIrznXBg)
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SHOOFMAX-FILTERS-1st')
	if type==1: z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('subgenre(.*?)div',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	elif type==2: z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('country(.*?)div',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	items = EcQxOa3RJm86WjTKA.findall('option value="(.*?)">(.*?)</option',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	if type==1:
		for Vvp5NejaMTr4O0t,title in items:
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url+'?subgenre='+Vvp5NejaMTr4O0t,58)
	elif type==2:
		url,Vvp5NejaMTr4O0t = url.split('?')
		for PPf96YqGdatREx,title in items:
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url+'?country='+PPf96YqGdatREx+'&'+Vvp5NejaMTr4O0t,51)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if not search: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if not search: return
	CE6HW2phYix9XvVdfqe1ObQIFl5mMj = search.replace(ksJdoFWhxTz8Y2N7bOZE,'%20')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/search?q='+CE6HW2phYix9XvVdfqe1ObQIFl5mMj
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,True,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SHOOFMAX-SEARCH-2nd')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('general-body(.*?)search-bottom-padding',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	if items:
		for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
			url = BOI3t1w8qfHAb0Kl4oMye7haEWS + bigdh7fpZYl4aT2keV
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+DVX5GWhnIxYlSd9rEuetjk40UJ(title)+'='+POjaBmHqzpsx1IYw7kQM4R
					OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,52,POjaBmHqzpsx1IYw7kQM4R)
				else:
					title = '_MOD_فيلم '+title
					OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,url,53,POjaBmHqzpsx1IYw7kQM4R)
	return
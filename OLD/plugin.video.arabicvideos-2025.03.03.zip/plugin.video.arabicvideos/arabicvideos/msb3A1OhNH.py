# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'GLOBALSEARCH'
K2l9rLfvoXxyZ4NYapO = '_GLS_'
def ugbnmWCrLpG9Av0xzocFaB5ew(hO3D6GVPY2qENv8bZWH,eEncXMVB2rNg4JObl3utYfj,YMaiHbnIThsP7q,jmI9qRnVJo2a3tpcH8gfYkP):
	if   hO3D6GVPY2qENv8bZWH==540: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif hO3D6GVPY2qENv8bZWH==541: OmsWt89dSA5HyCZ4wL = Q63QMHA5uBbjxSwDOdnFoNs(YMaiHbnIThsP7q)
	elif hO3D6GVPY2qENv8bZWH==542: OmsWt89dSA5HyCZ4wL = a6bynuDzsFWd0ZVYvXpiJCrhN(YMaiHbnIThsP7q,eEncXMVB2rNg4JObl3utYfj,jmI9qRnVJo2a3tpcH8gfYkP)
	elif hO3D6GVPY2qENv8bZWH==543: OmsWt89dSA5HyCZ4wL = bw2ZeBlUQ3cms4FMoN()
	elif hO3D6GVPY2qENv8bZWH==548: OmsWt89dSA5HyCZ4wL = Dn5hJoTX4u7BlfIHbYP9zRS10ZG(eEncXMVB2rNg4JObl3utYfj,YMaiHbnIThsP7q)
	elif hO3D6GVPY2qENv8bZWH==549: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(YMaiHbnIThsP7q)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH('folder','بحث جديد لجميع المواقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,549)
	OZD1l4pAMzeH('link','كيف يعمل بحث جميع المواقع','',543)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+'==== كلمات البحث المخزنة ===='+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	jdK6AMWnSaTyeYhfP3oJ9lBmkzL8r = rIhXWK91vRuC(jUCABmLYMf0G,'dict','GLOBALSEARCH_SPLITTED_ALL')
	if jdK6AMWnSaTyeYhfP3oJ9lBmkzL8r:
		jdK6AMWnSaTyeYhfP3oJ9lBmkzL8r = jdK6AMWnSaTyeYhfP3oJ9lBmkzL8r['__SEQUENCED_COLUMNS__']
		for qO85TbiBND0g6G3Iktu7fomVCc in reversed(jdK6AMWnSaTyeYhfP3oJ9lBmkzL8r):
			OZD1l4pAMzeH('folder',qO85TbiBND0g6G3Iktu7fomVCc,fy8iFgEkrO12NR9TWBI35sjY6qHvV,549,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,qO85TbiBND0g6G3Iktu7fomVCc)
	return
def dPTs3joJiGpzfcWFvQZAa(qO85TbiBND0g6G3Iktu7fomVCc):
	if not qO85TbiBND0g6G3Iktu7fomVCc:
		qO85TbiBND0g6G3Iktu7fomVCc = GFYl1tsoOkHC0Ajeur8JQiMx()
		if not qO85TbiBND0g6G3Iktu7fomVCc: return
		qO85TbiBND0g6G3Iktu7fomVCc = qO85TbiBND0g6G3Iktu7fomVCc.lower()
	EfJc6xmorP9siHGZplU02yK7 = qO85TbiBND0g6G3Iktu7fomVCc.replace(K2l9rLfvoXxyZ4NYapO,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	hUzb59PciOQrJIE0K1SfBN2(EfJc6xmorP9siHGZplU02yK7,'_ALL',True)
	OZD1l4pAMzeH('link','بحث جماعي للمواقع - '+EfJc6xmorP9siHGZplU02yK7,'search_sites_all',542,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EfJc6xmorP9siHGZplU02yK7)
	OZD1l4pAMzeH('folder','بحث منفرد للمواقع - '+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,541,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EfJc6xmorP9siHGZplU02yK7)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+'===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder','نتائج البحث مفصلة - '+EfJc6xmorP9siHGZplU02yK7,'opened_sites_all',542,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EfJc6xmorP9siHGZplU02yK7)
	OZD1l4pAMzeH('folder','نتائج البحث مقسمة - '+EfJc6xmorP9siHGZplU02yK7,'listed_sites_all',542,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EfJc6xmorP9siHGZplU02yK7)
	return
def hUzb59PciOQrJIE0K1SfBN2(UarYLCdvTwDiIfV9ASZum6Oe,GgCzNqQS9MAt,MMVftGUl63QY0Ho1EdZK):
	if GgCzNqQS9MAt=='_ALL': gxMwFmhse4vQHauUANIbXSEnKi1 = '_GLS_'
	elif GgCzNqQS9MAt=='_GOOGLE': gxMwFmhse4vQHauUANIbXSEnKi1 = '_GOS_'
	pwBLi7WMRDXzCT9PJ = rIhXWK91vRuC(jUCABmLYMf0G,'list','GLOBALSEARCH_SPLITTED'+GgCzNqQS9MAt,UarYLCdvTwDiIfV9ASZum6Oe)
	uNQk39pGrzA = rIhXWK91vRuC(jUCABmLYMf0G,'list','GLOBALSEARCH_SPLITTED'+GgCzNqQS9MAt,gxMwFmhse4vQHauUANIbXSEnKi1+UarYLCdvTwDiIfV9ASZum6Oe)
	gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,'GLOBALSEARCH_SPLITTED'+GgCzNqQS9MAt,UarYLCdvTwDiIfV9ASZum6Oe)
	gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,'GLOBALSEARCH_SPLITTED'+GgCzNqQS9MAt,gxMwFmhse4vQHauUANIbXSEnKi1+UarYLCdvTwDiIfV9ASZum6Oe)
	jtOmI3XY14LRvV5AEHZeyhWfnp = pwBLi7WMRDXzCT9PJ+uNQk39pGrzA
	if jtOmI3XY14LRvV5AEHZeyhWfnp and MMVftGUl63QY0Ho1EdZK: UarYLCdvTwDiIfV9ASZum6Oe = gxMwFmhse4vQHauUANIbXSEnKi1+UarYLCdvTwDiIfV9ASZum6Oe
	tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,'GLOBALSEARCH_SPLITTED'+GgCzNqQS9MAt,UarYLCdvTwDiIfV9ASZum6Oe,jtOmI3XY14LRvV5AEHZeyhWfnp,JJtWv7V436NPCf)
	return
def oz4MhAk6qid0lFcROXx1bV7(GgCzNqQS9MAt):
	Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if Scj7zgGFVA83otMpwUkxhm0BLN1!=1: return
	gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,'GLOBALSEARCH_SPLITTED'+GgCzNqQS9MAt)
	gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,'GLOBALSEARCH_DETAILED'+GgCzNqQS9MAt)
	gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,'GLOBALSEARCH_DIVIDED'+GgCzNqQS9MAt)
	if GgCzNqQS9MAt=='_GOOGLE': gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,'GOOGLESEARCH_RESULTS')
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def a6bynuDzsFWd0ZVYvXpiJCrhN(ULC8sDiQWMaG0glVudfXBxe7FkERwT,bcJnQkzqlsGoihXIM3dWx4N8wZ,QAhIOLraN8ZnX=fy8iFgEkrO12NR9TWBI35sjY6qHvV,RToNb2ywP5g74UEIzOxra=TwR9dnEiDPblt6Nzs8QMrX0VqO2om4,W4gYpEVBf2wOoRSxiH6={}):
	RYvcIAa0gsXZCL,Fhr4MzmJenBl2jiNWZRpDK,DiILmoPes5aqvAWZ3E02h7,Gky6bH0hvnMgqBO7Fi,FyzlktrfAVaOHRDo = [],{},{},{},{}
	if '_all' in bcJnQkzqlsGoihXIM3dWx4N8wZ: GgCzNqQS9MAt,HW24rguPyVTMBmicF,gxMwFmhse4vQHauUANIbXSEnKi1 = '_ALL','_all','_GLS_'
	elif '_google' in bcJnQkzqlsGoihXIM3dWx4N8wZ: GgCzNqQS9MAt,HW24rguPyVTMBmicF,gxMwFmhse4vQHauUANIbXSEnKi1 = '_GOOGLE','_google','_GOS_'
	if bcJnQkzqlsGoihXIM3dWx4N8wZ in ['listed_sites'+HW24rguPyVTMBmicF,'opened_sites'+HW24rguPyVTMBmicF,'closed_sites'+HW24rguPyVTMBmicF]:
		if bcJnQkzqlsGoihXIM3dWx4N8wZ=='listed_sites'+HW24rguPyVTMBmicF: RYvcIAa0gsXZCL = rIhXWK91vRuC(jUCABmLYMf0G,'list','GLOBALSEARCH_SPLITTED'+GgCzNqQS9MAt,gxMwFmhse4vQHauUANIbXSEnKi1+ULC8sDiQWMaG0glVudfXBxe7FkERwT)
		elif bcJnQkzqlsGoihXIM3dWx4N8wZ=='opened_sites'+HW24rguPyVTMBmicF: RYvcIAa0gsXZCL = rIhXWK91vRuC(jUCABmLYMf0G,'list','GLOBALSEARCH_DETAILED'+GgCzNqQS9MAt,ULC8sDiQWMaG0glVudfXBxe7FkERwT)
		elif bcJnQkzqlsGoihXIM3dWx4N8wZ=='closed_sites'+HW24rguPyVTMBmicF: RYvcIAa0gsXZCL = rIhXWK91vRuC(jUCABmLYMf0G,'list','GLOBALSEARCH_DIVIDED'+GgCzNqQS9MAt,(QAhIOLraN8ZnX,ULC8sDiQWMaG0glVudfXBxe7FkERwT))
	if not RYvcIAa0gsXZCL:
		XgbcrBleMx5LYWzKjFCHIOP = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		mmv7XkyreCIJGUqhTYi5KB6DWSn = 'هل تريد الآن البحث في جميع المواقع عن \n "'+WydpaVx5YmLoCiIgA34eEBlb+ksJdoFWhxTz8Y2N7bOZE+ULC8sDiQWMaG0glVudfXBxe7FkERwT+ksJdoFWhxTz8Y2N7bOZE+T7ASIp1ZYwio9HQ8cObJK+'" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if bcJnQkzqlsGoihXIM3dWx4N8wZ=='search_sites'+HW24rguPyVTMBmicF: kf40tulvSA7z9RqNF5dXca3seMD = mmv7XkyreCIJGUqhTYi5KB6DWSn
		else: kf40tulvSA7z9RqNF5dXca3seMD = XgbcrBleMx5LYWzKjFCHIOP+mmv7XkyreCIJGUqhTYi5KB6DWSn
		Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج',kf40tulvSA7z9RqNF5dXca3seMD)
		if Scj7zgGFVA83otMpwUkxhm0BLN1!=1: return
		ZBILqw92kAymRHD7GstV(DDIe1w6Gj3NMV9E08FtqxbSsh,DDIe1w6Gj3NMV9E08FtqxbSsh,DDIe1w6Gj3NMV9E08FtqxbSsh)
		Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+'   Search For: [ '+ULC8sDiQWMaG0glVudfXBxe7FkERwT+' ]')
		jWB9JuvGYP0N8S = 1
		for C0C4kdG53sPAbNq8OBMpitLThHl in RToNb2ywP5g74UEIzOxra:
			ftDHr7RV86nSyL0QFO5gehGaN = W4gYpEVBf2wOoRSxiH6[C0C4kdG53sPAbNq8OBMpitLThHl] if W4gYpEVBf2wOoRSxiH6 else ULC8sDiQWMaG0glVudfXBxe7FkERwT
			try: i4YeIfAFjZkScx5RXLNGd96V,DDmgX24QRqwcVnez8GyP,rk0648WzSs7byUiKvRo5I1nBYPTMd = vjM9sANcTkUJViCD4PpBza0lH(C0C4kdG53sPAbNq8OBMpitLThHl)
			except: continue
			Fhr4MzmJenBl2jiNWZRpDK[C0C4kdG53sPAbNq8OBMpitLThHl] = []
			JJnVRkiCSuK1D = '_NODIALOGS_'
			if '-' in C0C4kdG53sPAbNq8OBMpitLThHl: JJnVRkiCSuK1D = JJnVRkiCSuK1D+'_REMEMBERRESULTS__'+C0C4kdG53sPAbNq8OBMpitLThHl+'_'
			if jWB9JuvGYP0N8S:
				uUqrNPcXKBoQ0slv.sleep(0.75)
				FyzlktrfAVaOHRDo[C0C4kdG53sPAbNq8OBMpitLThHl] = YMsWIfu7ojp2t4XJyZN05aC3l(daemon=EsCplGc5N4mBuYW0RVQt6b,target=DDmgX24QRqwcVnez8GyP,args=(ftDHr7RV86nSyL0QFO5gehGaN+JJnVRkiCSuK1D,))
				FyzlktrfAVaOHRDo[C0C4kdG53sPAbNq8OBMpitLThHl].start()
			else: DDmgX24QRqwcVnez8GyP(ftDHr7RV86nSyL0QFO5gehGaN+JJnVRkiCSuK1D)
			a6rVSjDMF87KyYINcuOP1l40Hbp(eJYnofQG4mc8aFiN(C0C4kdG53sPAbNq8OBMpitLThHl),fy8iFgEkrO12NR9TWBI35sjY6qHvV,uUqrNPcXKBoQ0slv=1000)
		if jWB9JuvGYP0N8S:
			uUqrNPcXKBoQ0slv.sleep(2)
			for C0C4kdG53sPAbNq8OBMpitLThHl in RToNb2ywP5g74UEIzOxra: FyzlktrfAVaOHRDo[C0C4kdG53sPAbNq8OBMpitLThHl].join(10)
			uUqrNPcXKBoQ0slv.sleep(2)
		for C0C4kdG53sPAbNq8OBMpitLThHl in RToNb2ywP5g74UEIzOxra:
			try: i4YeIfAFjZkScx5RXLNGd96V,DDmgX24QRqwcVnez8GyP,rk0648WzSs7byUiKvRo5I1nBYPTMd = vjM9sANcTkUJViCD4PpBza0lH(C0C4kdG53sPAbNq8OBMpitLThHl)
			except: continue
			for OVDFW0TtX58j6Gznb9vUCpN in I4t9qonjrm.menuItemsLIST:
				ppi24CwDdH3YzVIK8BUyLluQJEMW,z36flodJVD9jWxip14Rh,eEncXMVB2rNg4JObl3utYfj,hO3D6GVPY2qENv8bZWH,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YMaiHbnIThsP7q,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW = OVDFW0TtX58j6Gznb9vUCpN
				if rk0648WzSs7byUiKvRo5I1nBYPTMd in z36flodJVD9jWxip14Rh:
					if 'IPTV-' in C0C4kdG53sPAbNq8OBMpitLThHl and (239>=hO3D6GVPY2qENv8bZWH>=230 or 289>=hO3D6GVPY2qENv8bZWH>=280):
						if OVDFW0TtX58j6Gznb9vUCpN in Fhr4MzmJenBl2jiNWZRpDK['IPTV-LIVE']: continue
						if OVDFW0TtX58j6Gznb9vUCpN in Fhr4MzmJenBl2jiNWZRpDK['IPTV-MOVIES']: continue
						if OVDFW0TtX58j6Gznb9vUCpN in Fhr4MzmJenBl2jiNWZRpDK['IPTV-SERIES']: continue
						if 'صفحة' not in z36flodJVD9jWxip14Rh:
							if   ppi24CwDdH3YzVIK8BUyLluQJEMW=='live': C0C4kdG53sPAbNq8OBMpitLThHl = 'IPTV-LIVE'
							elif ppi24CwDdH3YzVIK8BUyLluQJEMW=='video': C0C4kdG53sPAbNq8OBMpitLThHl = 'IPTV-MOVIES'
							elif ppi24CwDdH3YzVIK8BUyLluQJEMW=='folder': C0C4kdG53sPAbNq8OBMpitLThHl = 'IPTV-SERIES'
						else:
							if   'LIVE' in eEncXMVB2rNg4JObl3utYfj: C0C4kdG53sPAbNq8OBMpitLThHl = 'IPTV-LIVE'
							elif 'MOVIES' in eEncXMVB2rNg4JObl3utYfj: C0C4kdG53sPAbNq8OBMpitLThHl = 'IPTV-MOVIES'
							elif 'SERIES' in eEncXMVB2rNg4JObl3utYfj: C0C4kdG53sPAbNq8OBMpitLThHl = 'IPTV-SERIES'
					elif 'M3U-' in C0C4kdG53sPAbNq8OBMpitLThHl and 729>=hO3D6GVPY2qENv8bZWH>=710:
						if OVDFW0TtX58j6Gznb9vUCpN in Fhr4MzmJenBl2jiNWZRpDK['M3U-LIVE']: continue
						if OVDFW0TtX58j6Gznb9vUCpN in Fhr4MzmJenBl2jiNWZRpDK['M3U-MOVIES']: continue
						if OVDFW0TtX58j6Gznb9vUCpN in Fhr4MzmJenBl2jiNWZRpDK['M3U-SERIES']: continue
						if 'صفحة' not in z36flodJVD9jWxip14Rh:
							if   ppi24CwDdH3YzVIK8BUyLluQJEMW=='live': C0C4kdG53sPAbNq8OBMpitLThHl = 'M3U-LIVE'
							elif ppi24CwDdH3YzVIK8BUyLluQJEMW=='video': C0C4kdG53sPAbNq8OBMpitLThHl = 'M3U-MOVIES'
							elif ppi24CwDdH3YzVIK8BUyLluQJEMW=='folder': C0C4kdG53sPAbNq8OBMpitLThHl = 'M3U-SERIES'
						else:
							if   'LIVE' in eEncXMVB2rNg4JObl3utYfj: C0C4kdG53sPAbNq8OBMpitLThHl = 'M3U-LIVE'
							elif 'MOVIES' in eEncXMVB2rNg4JObl3utYfj: C0C4kdG53sPAbNq8OBMpitLThHl = 'M3U-MOVIES'
							elif 'SERIES' in eEncXMVB2rNg4JObl3utYfj: C0C4kdG53sPAbNq8OBMpitLThHl = 'M3U-SERIES'
					elif 'YOUTUBE-' in C0C4kdG53sPAbNq8OBMpitLThHl and 149>=hO3D6GVPY2qENv8bZWH>=140:
						if OVDFW0TtX58j6Gznb9vUCpN in Fhr4MzmJenBl2jiNWZRpDK['YOUTUBE-CHANNELS']: continue
						if OVDFW0TtX58j6Gznb9vUCpN in Fhr4MzmJenBl2jiNWZRpDK['YOUTUBE-PLAYLISTS']: continue
						if OVDFW0TtX58j6Gznb9vUCpN in Fhr4MzmJenBl2jiNWZRpDK['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in z36flodJVD9jWxip14Rh or ':: ' in z36flodJVD9jWxip14Rh:
							continue
						else:
							if   hO3D6GVPY2qENv8bZWH==144 and 'USER' in z36flodJVD9jWxip14Rh: C0C4kdG53sPAbNq8OBMpitLThHl = 'YOUTUBE-CHANNELS'
							elif hO3D6GVPY2qENv8bZWH==144 and 'CHNL' in z36flodJVD9jWxip14Rh: C0C4kdG53sPAbNq8OBMpitLThHl = 'YOUTUBE-CHANNELS'
							elif hO3D6GVPY2qENv8bZWH==144 and 'LIST' in z36flodJVD9jWxip14Rh: C0C4kdG53sPAbNq8OBMpitLThHl = 'YOUTUBE-PLAYLISTS'
							elif hO3D6GVPY2qENv8bZWH==143: C0C4kdG53sPAbNq8OBMpitLThHl = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in C0C4kdG53sPAbNq8OBMpitLThHl and 419>=hO3D6GVPY2qENv8bZWH>=400:
						if OVDFW0TtX58j6Gznb9vUCpN in Fhr4MzmJenBl2jiNWZRpDK['DAILYMOTION-PLAYLISTS']: continue
						if OVDFW0TtX58j6Gznb9vUCpN in Fhr4MzmJenBl2jiNWZRpDK['DAILYMOTION-CHANNELS']: continue
						if OVDFW0TtX58j6Gznb9vUCpN in Fhr4MzmJenBl2jiNWZRpDK['DAILYMOTION-VIDEOS']: continue
						if OVDFW0TtX58j6Gznb9vUCpN in Fhr4MzmJenBl2jiNWZRpDK['DAILYMOTION-LIVES']: continue
						if OVDFW0TtX58j6Gznb9vUCpN in Fhr4MzmJenBl2jiNWZRpDK['DAILYMOTION-HASHTAGS']: continue
						if   hO3D6GVPY2qENv8bZWH in [401,405]: C0C4kdG53sPAbNq8OBMpitLThHl = 'DAILYMOTION-PLAYLISTS'
						elif hO3D6GVPY2qENv8bZWH in [402,406]: C0C4kdG53sPAbNq8OBMpitLThHl = 'DAILYMOTION-CHANNELS'
						elif hO3D6GVPY2qENv8bZWH in [404]: C0C4kdG53sPAbNq8OBMpitLThHl = 'DAILYMOTION-VIDEOS'
						elif hO3D6GVPY2qENv8bZWH in [415]: C0C4kdG53sPAbNq8OBMpitLThHl = 'DAILYMOTION-LIVES'
						elif hO3D6GVPY2qENv8bZWH in [416]: C0C4kdG53sPAbNq8OBMpitLThHl = 'DAILYMOTION-HASHTAGS'
					elif 'PANET-' in C0C4kdG53sPAbNq8OBMpitLThHl and 39>=hO3D6GVPY2qENv8bZWH>=30:
						if OVDFW0TtX58j6Gznb9vUCpN in Fhr4MzmJenBl2jiNWZRpDK['PANET-SERIES']: continue
						if OVDFW0TtX58j6Gznb9vUCpN in Fhr4MzmJenBl2jiNWZRpDK['PANET-MOVIES']: continue
						if   hO3D6GVPY2qENv8bZWH in [32,39]: C0C4kdG53sPAbNq8OBMpitLThHl = 'PANET-SERIES'
						elif hO3D6GVPY2qENv8bZWH in [33,39]: C0C4kdG53sPAbNq8OBMpitLThHl = 'PANET-MOVIES'
					elif 'IFILM-' in C0C4kdG53sPAbNq8OBMpitLThHl and 29>=hO3D6GVPY2qENv8bZWH>=20:
						if OVDFW0TtX58j6Gznb9vUCpN in Fhr4MzmJenBl2jiNWZRpDK['IFILM-ARABIC']: continue
						if OVDFW0TtX58j6Gznb9vUCpN in Fhr4MzmJenBl2jiNWZRpDK['IFILM-ENGLISH']: continue
						if   '/ar.' in eEncXMVB2rNg4JObl3utYfj: C0C4kdG53sPAbNq8OBMpitLThHl = 'IFILM-ARABIC'
						elif '/en.' in eEncXMVB2rNg4JObl3utYfj: C0C4kdG53sPAbNq8OBMpitLThHl = 'IFILM-ENGLISH'
					Fhr4MzmJenBl2jiNWZRpDK[C0C4kdG53sPAbNq8OBMpitLThHl].append(OVDFW0TtX58j6Gznb9vUCpN)
		for C0C4kdG53sPAbNq8OBMpitLThHl in list(Fhr4MzmJenBl2jiNWZRpDK.keys()):
			DiILmoPes5aqvAWZ3E02h7[C0C4kdG53sPAbNq8OBMpitLThHl] = []
			Gky6bH0hvnMgqBO7Fi[C0C4kdG53sPAbNq8OBMpitLThHl] = []
			for ppi24CwDdH3YzVIK8BUyLluQJEMW,z36flodJVD9jWxip14Rh,eEncXMVB2rNg4JObl3utYfj,hO3D6GVPY2qENv8bZWH,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YMaiHbnIThsP7q,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW in Fhr4MzmJenBl2jiNWZRpDK[C0C4kdG53sPAbNq8OBMpitLThHl]:
				OVDFW0TtX58j6Gznb9vUCpN = (ppi24CwDdH3YzVIK8BUyLluQJEMW,z36flodJVD9jWxip14Rh,eEncXMVB2rNg4JObl3utYfj,hO3D6GVPY2qENv8bZWH,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YMaiHbnIThsP7q,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW)
				if 'صفحة' in z36flodJVD9jWxip14Rh and ppi24CwDdH3YzVIK8BUyLluQJEMW=='folder': Gky6bH0hvnMgqBO7Fi[C0C4kdG53sPAbNq8OBMpitLThHl].append(OVDFW0TtX58j6Gznb9vUCpN)
				else: DiILmoPes5aqvAWZ3E02h7[C0C4kdG53sPAbNq8OBMpitLThHl].append(OVDFW0TtX58j6Gznb9vUCpN)
		ceWrOd2fq7Z46IK,RAnUg36FMrkuhqNlZQEbK40O = [],[]
		chLTgNepKwFlz6yMC39Z04En = list(DiILmoPes5aqvAWZ3E02h7.keys())
		i16TLa304fgPrcmnzHFtCA5JSQ2YW = wwC9IiN8t2epu3xHlaAPkVWjYzy(chLTgNepKwFlz6yMC39Z04En)
		BlnTkG5dwUIP = []
		for C0C4kdG53sPAbNq8OBMpitLThHl in i16TLa304fgPrcmnzHFtCA5JSQ2YW:
			if 'tuple' in str(type(C0C4kdG53sPAbNq8OBMpitLThHl)):
				BlnTkG5dwUIP = [C0C4kdG53sPAbNq8OBMpitLThHl]
				continue
			if C0C4kdG53sPAbNq8OBMpitLThHl not in RToNb2ywP5g74UEIzOxra: continue
			if DiILmoPes5aqvAWZ3E02h7[C0C4kdG53sPAbNq8OBMpitLThHl]:
				jG6RTx7zyEAZJPOtY = eJYnofQG4mc8aFiN(C0C4kdG53sPAbNq8OBMpitLThHl)
				EQdqRsrI7eC = [('link',WydpaVx5YmLoCiIgA34eEBlb+'===== '+jG6RTx7zyEAZJPOtY+' ====='+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV)]
				if 0: z5byF8vHquiC0OLjpXE6RZ1 = ULC8sDiQWMaG0glVudfXBxe7FkERwT+' - '+'بحث'+ksJdoFWhxTz8Y2N7bOZE+jG6RTx7zyEAZJPOtY
				else: z5byF8vHquiC0OLjpXE6RZ1 = 'بحث'+ksJdoFWhxTz8Y2N7bOZE+jG6RTx7zyEAZJPOtY+' - '+ULC8sDiQWMaG0glVudfXBxe7FkERwT
				if len(DiILmoPes5aqvAWZ3E02h7[C0C4kdG53sPAbNq8OBMpitLThHl])<8: L42KN5BYeSd8 = []
				else:
					rjDvitpLNhTdyOK9 = n0nFOd4yR97fQzNLSW+z5byF8vHquiC0OLjpXE6RZ1+T7ASIp1ZYwio9HQ8cObJK
					L42KN5BYeSd8 = [('folder',gxMwFmhse4vQHauUANIbXSEnKi1+rjDvitpLNhTdyOK9,'closed_sites'+HW24rguPyVTMBmicF,542,fy8iFgEkrO12NR9TWBI35sjY6qHvV,C0C4kdG53sPAbNq8OBMpitLThHl,ULC8sDiQWMaG0glVudfXBxe7FkERwT,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV)]
				vsWZznQDU5PoXr0kqEfaGBA69F = DiILmoPes5aqvAWZ3E02h7[C0C4kdG53sPAbNq8OBMpitLThHl]+Gky6bH0hvnMgqBO7Fi[C0C4kdG53sPAbNq8OBMpitLThHl]
				dtEBr4OXgfFZ7j6QPV0S8I1MwJ5 = BlnTkG5dwUIP+EQdqRsrI7eC+vsWZznQDU5PoXr0kqEfaGBA69F[:7]+L42KN5BYeSd8
				ceWrOd2fq7Z46IK += dtEBr4OXgfFZ7j6QPV0S8I1MwJ5
				q4qCSRef3obwTFvAE8BD60jIgyLO = [('folder',gxMwFmhse4vQHauUANIbXSEnKi1+z5byF8vHquiC0OLjpXE6RZ1,'closed_sites'+HW24rguPyVTMBmicF,542,fy8iFgEkrO12NR9TWBI35sjY6qHvV,C0C4kdG53sPAbNq8OBMpitLThHl,ULC8sDiQWMaG0glVudfXBxe7FkERwT,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV)]
				NDVw0JyMc41 = BlnTkG5dwUIP+q4qCSRef3obwTFvAE8BD60jIgyLO
				RAnUg36FMrkuhqNlZQEbK40O += NDVw0JyMc41
				tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,'GLOBALSEARCH_DIVIDED'+GgCzNqQS9MAt,(C0C4kdG53sPAbNq8OBMpitLThHl,ULC8sDiQWMaG0glVudfXBxe7FkERwT),vsWZznQDU5PoXr0kqEfaGBA69F,JJtWv7V436NPCf)
				BlnTkG5dwUIP = []
		tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,'GLOBALSEARCH_DETAILED'+GgCzNqQS9MAt,ULC8sDiQWMaG0glVudfXBxe7FkERwT,ceWrOd2fq7Z46IK,JJtWv7V436NPCf)
		gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,'GLOBALSEARCH_SPLITTED'+GgCzNqQS9MAt,ULC8sDiQWMaG0glVudfXBxe7FkERwT)
		tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,'GLOBALSEARCH_SPLITTED'+GgCzNqQS9MAt,gxMwFmhse4vQHauUANIbXSEnKi1+ULC8sDiQWMaG0glVudfXBxe7FkERwT,RAnUg36FMrkuhqNlZQEbK40O,JJtWv7V436NPCf)
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم لكي تستطيع العودة إليها بدون عمل بحث جديد')
		RYvcIAa0gsXZCL = RAnUg36FMrkuhqNlZQEbK40O if bcJnQkzqlsGoihXIM3dWx4N8wZ=='listed_sites'+HW24rguPyVTMBmicF and RAnUg36FMrkuhqNlZQEbK40O else ceWrOd2fq7Z46IK
	if bcJnQkzqlsGoihXIM3dWx4N8wZ in ['listed_sites'+HW24rguPyVTMBmicF,'opened_sites'+HW24rguPyVTMBmicF,'closed_sites'+HW24rguPyVTMBmicF]:
		for ppi24CwDdH3YzVIK8BUyLluQJEMW,z36flodJVD9jWxip14Rh,eEncXMVB2rNg4JObl3utYfj,hO3D6GVPY2qENv8bZWH,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YMaiHbnIThsP7q,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW in RYvcIAa0gsXZCL:
			if bcJnQkzqlsGoihXIM3dWx4N8wZ in ['listed_sites'+HW24rguPyVTMBmicF,'opened_sites'+HW24rguPyVTMBmicF] and 'صفحة' in z36flodJVD9jWxip14Rh and ppi24CwDdH3YzVIK8BUyLluQJEMW=='folder': continue
			OZD1l4pAMzeH(ppi24CwDdH3YzVIK8BUyLluQJEMW,z36flodJVD9jWxip14Rh,eEncXMVB2rNg4JObl3utYfj,hO3D6GVPY2qENv8bZWH,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YMaiHbnIThsP7q,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW)
	ZBILqw92kAymRHD7GstV(LLvswCIAk0tubrKgFpPW4BVf,LLvswCIAk0tubrKgFpPW4BVf,LLvswCIAk0tubrKgFpPW4BVf)
	return
def Q63QMHA5uBbjxSwDOdnFoNs(search):
	i16TLa304fgPrcmnzHFtCA5JSQ2YW = wwC9IiN8t2epu3xHlaAPkVWjYzy(cFTiOCdrXfgnKx0vh948jU7pSEb)
	for C0C4kdG53sPAbNq8OBMpitLThHl in i16TLa304fgPrcmnzHFtCA5JSQ2YW:
		if '-' in C0C4kdG53sPAbNq8OBMpitLThHl: continue
		if 'tuple' in str(type(C0C4kdG53sPAbNq8OBMpitLThHl)):
			I4t9qonjrm.menuItemsLIST.append(C0C4kdG53sPAbNq8OBMpitLThHl)
			continue
		i4YeIfAFjZkScx5RXLNGd96V,DDmgX24QRqwcVnez8GyP,rk0648WzSs7byUiKvRo5I1nBYPTMd = vjM9sANcTkUJViCD4PpBza0lH(C0C4kdG53sPAbNq8OBMpitLThHl)
		name = eJYnofQG4mc8aFiN(C0C4kdG53sPAbNq8OBMpitLThHl)+' - '+search
		OZD1l4pAMzeH('folder',rk0648WzSs7byUiKvRo5I1nBYPTMd+name,C0C4kdG53sPAbNq8OBMpitLThHl,548,'','',search)
	return
def Dn5hJoTX4u7BlfIHbYP9zRS10ZG(C0C4kdG53sPAbNq8OBMpitLThHl,search):
	i4YeIfAFjZkScx5RXLNGd96V,DDmgX24QRqwcVnez8GyP,rk0648WzSs7byUiKvRo5I1nBYPTMd = vjM9sANcTkUJViCD4PpBza0lH(C0C4kdG53sPAbNq8OBMpitLThHl)
	DDmgX24QRqwcVnez8GyP(search)
	return
def bw2ZeBlUQ3cms4FMoN():
	GOnZYxartRwkPqMJFub('','','رسالة من المبرمج','هذا البحث يستخدم محركات البحث الصغيرة الموجودة في كل موقع من مواقع البرنامج .. ونتائج هذا البحث تعتمد على دقة وفعالية وبرمجة كل موقع منها\n\nللأسف هذه المحركات الصغيرة لا تفهم جميع تفاصيل الفيديوهات ولا تفهم طريقة تفكير البشر ولا تستطيع إصلاح الأخطاء الإملائية .. ولهذا هي تحتاج دقة كبيرة جدا في اختيار وكتابة كلمات البحث المناسبة الصحيحة الدقيقة حتى تجد لك طلبك')
	return
def CbaPe1c7NdYnEXpOTzlVf(ULC8sDiQWMaG0glVudfXBxe7FkERwT=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	qO85TbiBND0g6G3Iktu7fomVCc,JJnVRkiCSuK1D,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(ULC8sDiQWMaG0glVudfXBxe7FkERwT)
	if not qO85TbiBND0g6G3Iktu7fomVCc:
		qO85TbiBND0g6G3Iktu7fomVCc = GFYl1tsoOkHC0Ajeur8JQiMx()
		if not qO85TbiBND0g6G3Iktu7fomVCc: return
		qO85TbiBND0g6G3Iktu7fomVCc = qO85TbiBND0g6G3Iktu7fomVCc.lower()
	Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+'   Search For: [ '+qO85TbiBND0g6G3Iktu7fomVCc+' ]')
	CE6HW2phYix9XvVdfqe1ObQIFl5mMj = qO85TbiBND0g6G3Iktu7fomVCc+JJnVRkiCSuK1D
	if 0: nhMCERjoDbSTQt3LH,EfJc6xmorP9siHGZplU02yK7 = qO85TbiBND0g6G3Iktu7fomVCc+' - ',fy8iFgEkrO12NR9TWBI35sjY6qHvV
	else: nhMCERjoDbSTQt3LH,EfJc6xmorP9siHGZplU02yK7 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,' - '+qO85TbiBND0g6G3Iktu7fomVCc
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+'مواقع سيرفرات خاصة - قليلة المشاكل'+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,157)
	OZD1l4pAMzeH('folder','_M3U_'+nhMCERjoDbSTQt3LH+'بحث M3U'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,719,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_IPT_'+nhMCERjoDbSTQt3LH+'بحث IPTV'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,239,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_BKR_'+nhMCERjoDbSTQt3LH+'بحث موقع بكرا'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,379,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_ART_'+nhMCERjoDbSTQt3LH+'بحث موقع تونز عربية'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,739,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_KRB_'+nhMCERjoDbSTQt3LH+'بحث موقع قناة كربلاء'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,329,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_FH2_'+nhMCERjoDbSTQt3LH+'بحث موقع فاصل الثاني'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,599,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_KTV_'+nhMCERjoDbSTQt3LH+'بحث موقع كتكوت تيفي'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,819,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_EB1_'+nhMCERjoDbSTQt3LH+'بحث موقع ايجي بيست 1'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,779,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_EB2_'+nhMCERjoDbSTQt3LH+'بحث موقع ايجي بيست 2'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,789,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_IFL_'+nhMCERjoDbSTQt3LH+'  بحث موقع قناة آي فيلم'+EfJc6xmorP9siHGZplU02yK7+OOiSqkBcMPptI,fy8iFgEkrO12NR9TWBI35sjY6qHvV,29,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_AKO_'+nhMCERjoDbSTQt3LH+'بحث موقع أكوام القديم'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,79,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_AKW_'+nhMCERjoDbSTQt3LH+'بحث موقع أكوام الجديد'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,249,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_MRF_'+nhMCERjoDbSTQt3LH+'بحث موقع قناة المعارف'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,49,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_SHM_'+nhMCERjoDbSTQt3LH+'بحث موقع شوف ماكس'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,59,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+'مواقع سيرفرات خاصة وعامة - كثيرة المشاكل'+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,157)
	OZD1l4pAMzeH('folder','_LRZ_'+nhMCERjoDbSTQt3LH+'بحث موقع لاروزا'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,709,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_FJS_'+nhMCERjoDbSTQt3LH+' بحث موقع فجر شو'+EfJc6xmorP9siHGZplU02yK7+ksJdoFWhxTz8Y2N7bOZE,fy8iFgEkrO12NR9TWBI35sjY6qHvV,399,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_TVF_'+nhMCERjoDbSTQt3LH+'بحث موقع تيفي فان'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,469,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_LDN_'+nhMCERjoDbSTQt3LH+'بحث موقع لودي نت'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,459,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_CMN_'+nhMCERjoDbSTQt3LH+'بحث موقع سيما ناو'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,309,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_SHN_'+nhMCERjoDbSTQt3LH+'بحث موقع شاهد نيوز'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,589,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj+'_NODIALOGS_')
	OZD1l4pAMzeH('folder','_ARS_'+nhMCERjoDbSTQt3LH+'بحث موقع عرب سييد'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,259,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_CCB_'+nhMCERjoDbSTQt3LH+'بحث موقع سيما كلوب'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,829,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_SH4_'+nhMCERjoDbSTQt3LH+'بحث موقع شاهد فوريو'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,119,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj+'_NODIALOGS_')
	OZD1l4pAMzeH('folder','_SHT_'+nhMCERjoDbSTQt3LH+'بحث موقع شوفها تيفي'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,649,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_WC1_'+nhMCERjoDbSTQt3LH+'بحث موقع وي سيما 1'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,569,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_WC2_'+nhMCERjoDbSTQt3LH+'بحث موقع وي سيما 2'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,1009,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+'مواقع سيرفرات عامة - كثيرة المشاكل'+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,157)
	OZD1l4pAMzeH('folder','_TKT_'+nhMCERjoDbSTQt3LH+'بحث موقع تكات'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,949,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_FST_'+nhMCERjoDbSTQt3LH+'بحث موقع فوستا'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,609,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_FBK_'+nhMCERjoDbSTQt3LH+'بحث موقع فبركة'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,629,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_YQT_'+nhMCERjoDbSTQt3LH+'بحث موقع ياقوت'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,669,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_SHB_'+nhMCERjoDbSTQt3LH+'بحث موقع شبكتي'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,969,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_VRB_'+nhMCERjoDbSTQt3LH+'بحث موقع فاربون'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,879,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_BRS_'+nhMCERjoDbSTQt3LH+'بحث موقع برستيج'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,659,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_KRM_'+nhMCERjoDbSTQt3LH+'بحث موقع كرمالك'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,929,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_ANZ_'+nhMCERjoDbSTQt3LH+'بحث موقع انمي زد'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,979,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_FSK_'+nhMCERjoDbSTQt3LH+'بحث موقع فارسكو'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,999,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_HLC_'+nhMCERjoDbSTQt3LH+'بحث موقع هلا سيما'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,89,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_MST_'+nhMCERjoDbSTQt3LH+'بحث موقع المصطبة'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,869,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_SNT_'+nhMCERjoDbSTQt3LH+'بحث موقع شوف نت'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,849,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_DR7_'+nhMCERjoDbSTQt3LH+'بحث موقع دراما صح'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,689,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_CFR_'+nhMCERjoDbSTQt3LH+'بحث موقع سيما فري'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,839,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_CMF_'+nhMCERjoDbSTQt3LH+'بحث موقع سيما فانز'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,99,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_CML_'+nhMCERjoDbSTQt3LH+'بحث موقع سيما لايت'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,479,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_C4H_'+nhMCERjoDbSTQt3LH+'بحث موقع سيما 400'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,699,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_ABD_'+nhMCERjoDbSTQt3LH+'بحث موقع سيما عبدو'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,559,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_AKT_'+nhMCERjoDbSTQt3LH+'بحث موقع اكوام تيوب'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,859,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_DCF_'+nhMCERjoDbSTQt3LH+'بحث موقع دراما كافيه'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,939,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_FTV_'+nhMCERjoDbSTQt3LH+'بحث موقع فوشار تيفي'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,919,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_CWB_'+nhMCERjoDbSTQt3LH+'بحث موقع سيما وبس'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,989,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_AHK_'+nhMCERjoDbSTQt3LH+'بحث موقع أهواك تيفي'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,619,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_SRT_'+nhMCERjoDbSTQt3LH+'بحث موقع سيريس تايم'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,899,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_FVD_'+nhMCERjoDbSTQt3LH+'بحث موقع فوشار فيديو'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,909,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_C4P_'+nhMCERjoDbSTQt3LH+'بحث موقع سيما فور بي'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,889,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_EB4_'+nhMCERjoDbSTQt3LH+'بحث موقع ايجي بيست 4'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,809,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+'مواقع سيرفرات خاصة - قليلة المشاكل'+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,157)
	OZD1l4pAMzeH('folder','_YUT_'+nhMCERjoDbSTQt3LH+'بحث موقع يوتيوب'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,149,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	OZD1l4pAMzeH('folder','_DLM_'+nhMCERjoDbSTQt3LH+'بحث موقع دايلي موشن'+EfJc6xmorP9siHGZplU02yK7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,409,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CE6HW2phYix9XvVdfqe1ObQIFl5mMj)
	return
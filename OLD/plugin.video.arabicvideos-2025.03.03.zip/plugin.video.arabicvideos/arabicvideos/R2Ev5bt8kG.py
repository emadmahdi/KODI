# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'ARABICTOONS'
K2l9rLfvoXxyZ4NYapO = '_ART_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==730: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==731: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,text)
	elif mode==732: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==733: OmsWt89dSA5HyCZ4wL = eQgbVPaIBvTn8fsjJRt241(url)
	elif mode==734: OmsWt89dSA5HyCZ4wL = IlHGcFYjC263nOMhdi1bkuz(url)
	elif mode==735: OmsWt89dSA5HyCZ4wL = zz69gOeLAq7VmMEaZIrjbdlCcton(url)
	elif mode==739: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,739,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'افلام',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/movies.php',731)
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'مسلسلات',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/cartoon.php',734)
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'مسلسلات مميزة',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/top.php',735)
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'أحدث الأفلام المضافة',BOI3t1w8qfHAb0Kl4oMye7haEWS,731,'','','LATEST_MOVIES')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'أحدث المسلسلات المضافة',BOI3t1w8qfHAb0Kl4oMye7haEWS,731,'','','LATEST_SERIES')
	return
def IlHGcFYjC263nOMhdi1bkuz(url):
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الكل',url,731)
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ARABICTOONS-SERIES_SUBMENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('label="navigation"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall("href='(.*?)'>(.*?)</a>",wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+bigdh7fpZYl4aT2keV
			title = 'حرف '+title
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,731)
	return
def zz69gOeLAq7VmMEaZIrjbdlCcton(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ARABICTOONS-SERIES_FEATURED-2nd')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="slider"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for title,bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R in items:
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+bigdh7fpZYl4aT2keV
			POjaBmHqzpsx1IYw7kQM4R = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+POjaBmHqzpsx1IYw7kQM4R
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,733,POjaBmHqzpsx1IYw7kQM4R)
	return
def HAsKeZdTbqjPI1WY(url,Bc7G3ur2Tw5QK1fPSkyJ):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ARABICTOONS-TITLES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall("class='moviesBlocks(.*?)list-group",FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if Bc7G3ur2Tw5QK1fPSkyJ=='LATEST_SERIES': wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[1]
	else: wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	items = EcQxOa3RJm86WjTKA.findall('class="movie".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
		bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+bigdh7fpZYl4aT2keV
		POjaBmHqzpsx1IYw7kQM4R = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+POjaBmHqzpsx1IYw7kQM4R
		title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
		if 'movies.php' in url or Bc7G3ur2Tw5QK1fPSkyJ=='LATEST_MOVIES':
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,732,POjaBmHqzpsx1IYw7kQM4R)
		else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,733,POjaBmHqzpsx1IYw7kQM4R)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"pagination(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[-1]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+bigdh7fpZYl4aT2keV
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,731)
	return
def eQgbVPaIBvTn8fsjJRt241(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ARABICTOONS-EPISODES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall("class='moviesBlocks(.*?)script",FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('class="movie".*?title="(.*?)".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for title,bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,smjRidwEPl in items:
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+bigdh7fpZYl4aT2keV
			POjaBmHqzpsx1IYw7kQM4R = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+POjaBmHqzpsx1IYw7kQM4R
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			title = title+ksJdoFWhxTz8Y2N7bOZE+smjRidwEPl.strip(ksJdoFWhxTz8Y2N7bOZE)
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,732,POjaBmHqzpsx1IYw7kQM4R)
	return
def rr7SfotkneX85Klup(url):
	hFzEyHWOoRxG = []
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ARABICTOONS-PLAY-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	zzECVswWcGAIXhrQlZ7jMokugnv = EcQxOa3RJm86WjTKA.findall('source src="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if zzECVswWcGAIXhrQlZ7jMokugnv:
		bigdh7fpZYl4aT2keV = zzECVswWcGAIXhrQlZ7jMokugnv[0]
		if 'Referer=' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'|Referer=https://www.arabic-toons.com'
		hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV+'?named=__embed')
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(hFzEyHWOoRxG,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'%20')
	XoSyx7p6dqZ1CF8 = [fy8iFgEkrO12NR9TWBI35sjY6qHvV,'m']
	CfDp1wiR2P87 = ['مسلسلات','افلام']
	if showDialogs:
		yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S('اختر النوع المطلوب:', CfDp1wiR2P87)
		if yNqzFDjKM0SrO==-1: return
	else: yNqzFDjKM0SrO = 0
	type = XoSyx7p6dqZ1CF8[yNqzFDjKM0SrO]
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/livesearch.php?'+type+'&q='+search
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ARABICTOONS-SEARCH-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)<',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title in items:
		bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+bigdh7fpZYl4aT2keV
		title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
		if type=='m': OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,732)
		else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,733)
	return
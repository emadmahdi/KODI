# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'LIVETV'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS['PYTHON'][0]
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url):
	if   mode==100: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==101: OmsWt89dSA5HyCZ4wL = zY53X6dEGkqnhmUDJ20rpbR8('0',True)
	elif mode==102: OmsWt89dSA5HyCZ4wL = zY53X6dEGkqnhmUDJ20rpbR8('1',True)
	elif mode==103: OmsWt89dSA5HyCZ4wL = zY53X6dEGkqnhmUDJ20rpbR8('2',True)
	elif mode==104: OmsWt89dSA5HyCZ4wL = zY53X6dEGkqnhmUDJ20rpbR8('3',True)
	elif mode==105: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==106: OmsWt89dSA5HyCZ4wL = zY53X6dEGkqnhmUDJ20rpbR8('4',True)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH('folder','_M3U_'+'قوائم فيديوهات M3U',fy8iFgEkrO12NR9TWBI35sjY6qHvV,762)
	OZD1l4pAMzeH('folder','_IPT_'+'قوائم فيديوهات IPTV',fy8iFgEkrO12NR9TWBI35sjY6qHvV,761)
	OZD1l4pAMzeH('folder','_TV0_'+'قنوات من مواقعها الأصلية',fy8iFgEkrO12NR9TWBI35sjY6qHvV,101)
	OZD1l4pAMzeH('folder','_TV4_'+'قنوات مختارة من يوتيوب',fy8iFgEkrO12NR9TWBI35sjY6qHvV,106)
	OZD1l4pAMzeH('folder','_YUT_'+'قنوات عربية من يوتيوب',fy8iFgEkrO12NR9TWBI35sjY6qHvV,147)
	OZD1l4pAMzeH('folder','_YUT_'+'قنوات أجنبية من يوتيوب',fy8iFgEkrO12NR9TWBI35sjY6qHvV,148)
	OZD1l4pAMzeH('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ',fy8iFgEkrO12NR9TWBI35sjY6qHvV,28)
	OZD1l4pAMzeH('live','_MRF_'+'قناة المعارف من موقعهم',fy8iFgEkrO12NR9TWBI35sjY6qHvV,41)
	OZD1l4pAMzeH('live','_PNT_'+'قناة هلا من موقع بانيت',fy8iFgEkrO12NR9TWBI35sjY6qHvV,38)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder','_TV1_'+'قنوات تلفزيونية عامة',fy8iFgEkrO12NR9TWBI35sjY6qHvV,102)
	OZD1l4pAMzeH('folder','_TV2_'+'قنوات تلفزيونية خاصة',fy8iFgEkrO12NR9TWBI35sjY6qHvV,103)
	OZD1l4pAMzeH('folder','_TV3_'+'قنوات تلفزيونية للفحص',fy8iFgEkrO12NR9TWBI35sjY6qHvV,104)
	return
def zY53X6dEGkqnhmUDJ20rpbR8(ffqUAI9tudHkKSblEYv30aJjo,showDialogs=True):
	K2l9rLfvoXxyZ4NYapO = '_TV'+ffqUAI9tudHkKSblEYv30aJjo+'_'
	B7gtJnK24RY = {'id':fy8iFgEkrO12NR9TWBI35sjY6qHvV,'user':I4t9qonjrm.AV_CLIENT_IDS,'function':'list','menu':ffqUAI9tudHkKSblEYv30aJjo}
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,'POST',BOI3t1w8qfHAb0Kl4oMye7haEWS,B7gtJnK24RY,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'LIVETV-ITEMS-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	items = EcQxOa3RJm86WjTKA.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if items:
		for pk6YWixXFSrDLKCnlN39w in range(len(items)):
			name = items[pk6YWixXFSrDLKCnlN39w][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[pk6YWixXFSrDLKCnlN39w] = items[pk6YWixXFSrDLKCnlN39w][0],items[pk6YWixXFSrDLKCnlN39w][1],items[pk6YWixXFSrDLKCnlN39w][2],name,items[pk6YWixXFSrDLKCnlN39w][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for mE7D5fBQZOKJdhtVUkHaIgRWpx,A8ECQ0qwTRzPifOGW76FK35uUvhe,aiuh0XlPswEK,name,POjaBmHqzpsx1IYw7kQM4R in items:
			if '#' in mE7D5fBQZOKJdhtVUkHaIgRWpx: continue
			if mE7D5fBQZOKJdhtVUkHaIgRWpx!='URL': name = name+n0nFOd4yR97fQzNLSW+yU7COAbsNJ916v5L0oew2n+mE7D5fBQZOKJdhtVUkHaIgRWpx+T7ASIp1ZYwio9HQ8cObJK
			url = mE7D5fBQZOKJdhtVUkHaIgRWpx+';;'+A8ECQ0qwTRzPifOGW76FK35uUvhe+';;'+aiuh0XlPswEK+';;'+ffqUAI9tudHkKSblEYv30aJjo
			OZD1l4pAMzeH('live',K2l9rLfvoXxyZ4NYapO+fy8iFgEkrO12NR9TWBI35sjY6qHvV+name,url,105,POjaBmHqzpsx1IYw7kQM4R)
	else:
		if showDialogs: OZD1l4pAMzeH('link',K2l9rLfvoXxyZ4NYapO+'هذه الخدمة مخصصة للمبرمج فقط',fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	return
def rr7SfotkneX85Klup(id):
	mE7D5fBQZOKJdhtVUkHaIgRWpx,A8ECQ0qwTRzPifOGW76FK35uUvhe,aiuh0XlPswEK,ffqUAI9tudHkKSblEYv30aJjo = id.split(';;')
	url = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if mE7D5fBQZOKJdhtVUkHaIgRWpx=='URL': url = aiuh0XlPswEK
	elif mE7D5fBQZOKJdhtVUkHaIgRWpx=='YOUTUBE':
		url = I4t9qonjrm.SITESURLS['YOUTUBE'][0]+'/watch?v='+aiuh0XlPswEK
		import TT24gHhkWI
		TT24gHhkWI.F7ulLTJzOt6krWZa4([url],BfWYUAnyg6eONLjiuE,'live',url)
		return
	elif mE7D5fBQZOKJdhtVUkHaIgRWpx=='GA':
		B7gtJnK24RY = { 'id' : fy8iFgEkrO12NR9TWBI35sjY6qHvV, 'user' : I4t9qonjrm.AV_CLIENT_IDS , 'function' : 'playGA1' , 'menu' : fy8iFgEkrO12NR9TWBI35sjY6qHvV }
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,B7gtJnK24RY,fy8iFgEkrO12NR9TWBI35sjY6qHvV,False,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'LIVETV-PLAY-1st')
		if not E6ECvznP9m5sWFMu.succeeded:
			GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		cookies = E6ECvznP9m5sWFMu.cookies
		nb8KE4GmNuWzJRxAMoc = cookies['ASP.NET_SessionId']
		url = E6ECvznP9m5sWFMu.headers['Location']
		B7gtJnK24RY = { 'id' : aiuh0XlPswEK , 'user' : I4t9qonjrm.AV_CLIENT_IDS , 'function' : 'playGA2' , 'menu' : fy8iFgEkrO12NR9TWBI35sjY6qHvV }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+nb8KE4GmNuWzJRxAMoc }
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,B7gtJnK24RY,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'LIVETV-PLAY-2nd')
		if not E6ECvznP9m5sWFMu.succeeded:
			GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		url = EcQxOa3RJm86WjTKA.findall('resp":"(http.*?m3u8)(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		bigdh7fpZYl4aT2keV = url[0][0]
		kJemADzFKdl = url[0][1]
		U8dQlPCKmMbVu2fwoTR = 'http://38.'+A8ECQ0qwTRzPifOGW76FK35uUvhe+'777/'+aiuh0XlPswEK+'_HD.m3u8'+kJemADzFKdl
		y3jA4vuHMe5tL0rNYcdmEbTn8 = U8dQlPCKmMbVu2fwoTR.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		eHKfjzxTOt07YZlXQuJd8vpPABhc = U8dQlPCKmMbVu2fwoTR.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		WFlpmsYGKNy = ['HD','SD1','SD2']
		XoSyx7p6dqZ1CF8 = [U8dQlPCKmMbVu2fwoTR,y3jA4vuHMe5tL0rNYcdmEbTn8,eHKfjzxTOt07YZlXQuJd8vpPABhc]
		yNqzFDjKM0SrO = 0
		if yNqzFDjKM0SrO == -1: return
		else: url = XoSyx7p6dqZ1CF8[yNqzFDjKM0SrO]
	elif mE7D5fBQZOKJdhtVUkHaIgRWpx=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		B7gtJnK24RY = { 'id' : aiuh0XlPswEK , 'user' : I4t9qonjrm.AV_CLIENT_IDS , 'function' : 'playNT' , 'menu' : ffqUAI9tudHkKSblEYv30aJjo }
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,'POST', BOI3t1w8qfHAb0Kl4oMye7haEWS, B7gtJnK24RY, headers, False,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'LIVETV-PLAY-3rd')
		if not E6ECvznP9m5sWFMu.succeeded:
			GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		url = E6ECvznP9m5sWFMu.headers['Location']
		url = url.replace('%20',ksJdoFWhxTz8Y2N7bOZE)
		url = url.replace('%3D','=')
		if 'Learn' in aiuh0XlPswEK:
			url = url.replace('NTNNile',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			url = url.replace('learning1','Learning')
	elif mE7D5fBQZOKJdhtVUkHaIgRWpx=='PL':
		B7gtJnK24RY = { 'id' : aiuh0XlPswEK , 'user' : I4t9qonjrm.AV_CLIENT_IDS , 'function' : 'playPL' , 'menu' : ffqUAI9tudHkKSblEYv30aJjo }
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,'POST', BOI3t1w8qfHAb0Kl4oMye7haEWS, B7gtJnK24RY, fy8iFgEkrO12NR9TWBI35sjY6qHvV,False,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'LIVETV-PLAY-4th')
		if not E6ECvznP9m5sWFMu.succeeded:
			GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		url = E6ECvznP9m5sWFMu.headers['Location']
		headers = {'Referer':E6ECvznP9m5sWFMu.headers['Referer']}
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,'POST',url, fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers , fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'LIVETV-PLAY-5th')
		if not E6ECvznP9m5sWFMu.succeeded:
			GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		items = EcQxOa3RJm86WjTKA.findall('source src="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		url = items[0]
	elif mE7D5fBQZOKJdhtVUkHaIgRWpx in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if mE7D5fBQZOKJdhtVUkHaIgRWpx=='TA': aiuh0XlPswEK = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		B7gtJnK24RY = { 'id' : aiuh0XlPswEK , 'user' : I4t9qonjrm.AV_CLIENT_IDS , 'function' : 'play'+mE7D5fBQZOKJdhtVUkHaIgRWpx , 'menu' : ffqUAI9tudHkKSblEYv30aJjo }
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,'POST',BOI3t1w8qfHAb0Kl4oMye7haEWS,B7gtJnK24RY,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'LIVETV-PLAY-6th')
		if not E6ECvznP9m5sWFMu.succeeded:
			GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		url = E6ECvznP9m5sWFMu.headers['Location']
		if mE7D5fBQZOKJdhtVUkHaIgRWpx=='FM':
			E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,'GET', url, fy8iFgEkrO12NR9TWBI35sjY6qHvV, fy8iFgEkrO12NR9TWBI35sjY6qHvV, False,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'LIVETV-PLAY-7th')
			url = E6ECvznP9m5sWFMu.headers['Location']
			url = url.replace('https','http')
	E7HR1ZcMuzUs9XCVrNGJYi(url,BfWYUAnyg6eONLjiuE,'live')
	return
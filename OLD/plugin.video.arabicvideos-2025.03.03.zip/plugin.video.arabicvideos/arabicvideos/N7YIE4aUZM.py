# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'CIMALIGHT'
K2l9rLfvoXxyZ4NYapO = '_CML_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['قنوات فضائية']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==470: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==471: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,text)
	elif mode==472: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==473: OmsWt89dSA5HyCZ4wL = bv4IDSyw6zuC3pR1lYd75(url,text)
	elif mode==474: OmsWt89dSA5HyCZ4wL = vloIZHenE7imycDM2tPQ(url)
	elif mode==479: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMALIGHT-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = EcQxOa3RJm86WjTKA.findall('"url": "(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ[0].strip('/')
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = VbHeOuU1ilzSp2ZRXwBD(VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ,'url')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,479,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"content"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?</i>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title in items:
		title = title.replace(OOiSqkBcMPptI,fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE)
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.replace('cat=online-movies1','cat=online-movies')
		OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,474)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('/category.php">(.*?)"navslide-divider"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall("'dropdown-menu'(.*?)</ul>",FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title in items:
		if title in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,474)
	return
def vloIZHenE7imycDM2tPQ(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMALIGHT-TITLES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	if 'topvideos.php' in url: z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"caret"(.*?)id="pm-grid"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	else: z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"caret"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if 'topvideos.php' in bigdh7fpZYl4aT2keV:
				if 'topvideos.php?c=english-movies' in bigdh7fpZYl4aT2keV: continue
				if 'topvideos.php?c=online-movies1' in bigdh7fpZYl4aT2keV: continue
				if 'topvideos.php?c=misc' in bigdh7fpZYl4aT2keV: continue
				if 'topvideos.php?c=tv-channel' in bigdh7fpZYl4aT2keV: continue
				if 'منذ البداية' in title and 'do=rating' not in bigdh7fpZYl4aT2keV: continue
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,471)
	else: HAsKeZdTbqjPI1WY(url)
	return
def HAsKeZdTbqjPI1WY(url,Bc7G3ur2Tw5QK1fPSkyJ=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = VbHeOuU1ilzSp2ZRXwBD(url,'url')
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMALIGHT-TITLES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	items = []
	if Bc7G3ur2Tw5QK1fPSkyJ=='featured_movies':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"container-fluid"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		zzECVswWcGAIXhrQlZ7jMokugnv,p7Gkego0m6a8,KEneUI3W2OH = zip(*items)
		items = zip(KEneUI3W2OH,zzECVswWcGAIXhrQlZ7jMokugnv,p7Gkego0m6a8)
	elif Bc7G3ur2Tw5QK1fPSkyJ=='featured_series':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('المسلسلات المميزة(.*?)<style>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		zzECVswWcGAIXhrQlZ7jMokugnv,p7Gkego0m6a8,KEneUI3W2OH = zip(*items)
		items = zip(KEneUI3W2OH,zzECVswWcGAIXhrQlZ7jMokugnv,p7Gkego0m6a8)
	else:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('(data-echo=".*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if not z6PX2p7diaskQElBOvMRNcHwqG5D: z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"BlocksList"(.*?)"titleSectionCon"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if not z6PX2p7diaskQElBOvMRNcHwqG5D: z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('id="pm-grid"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if not z6PX2p7diaskQElBOvMRNcHwqG5D: z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('id="pm-related"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if not z6PX2p7diaskQElBOvMRNcHwqG5D: z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('pm-ul-browse-videos(.*?)clearfix',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if not z6PX2p7diaskQElBOvMRNcHwqG5D: return
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	if not items: items = EcQxOa3RJm86WjTKA.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	if not items: items = EcQxOa3RJm86WjTKA.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	cmDaLEqWlT7GhonIdX5k1zHQjSiupe = []
	mmO39lwp0LFUrVT = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for POjaBmHqzpsx1IYw7kQM4R,bigdh7fpZYl4aT2keV,title in items:
		bigdh7fpZYl4aT2keV = U2Z7CVFftTmLeK3nzEbQPGga(bigdh7fpZYl4aT2keV).strip('/')
		title = title.replace('ماي سيما',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('مشاهدة',fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE)
		if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/'+bigdh7fpZYl4aT2keV.strip('/')
		if 'http' not in POjaBmHqzpsx1IYw7kQM4R: POjaBmHqzpsx1IYw7kQM4R = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/'+POjaBmHqzpsx1IYw7kQM4R.strip('/')
		RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) (الحلقة|حلقة) \d+',title,EcQxOa3RJm86WjTKA.DOTALL)
		if any(value in title for value in mmO39lwp0LFUrVT):
			title = '_MOD_'+title
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,472,POjaBmHqzpsx1IYw7kQM4R)
		elif RrzpbE3t9woCk7MXS0GvNdi1BcV and 'حلقة' in title:
			title = '_MOD_'+RrzpbE3t9woCk7MXS0GvNdi1BcV[0][0]
			if title not in cmDaLEqWlT7GhonIdX5k1zHQjSiupe:
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,473,POjaBmHqzpsx1IYw7kQM4R)
				cmDaLEqWlT7GhonIdX5k1zHQjSiupe.append(title)
		elif '/movseries/' in bigdh7fpZYl4aT2keV:
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,471,POjaBmHqzpsx1IYw7kQM4R)
		else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,473,POjaBmHqzpsx1IYw7kQM4R)
	if Bc7G3ur2Tw5QK1fPSkyJ not in ['featured_movies','featured_series']:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"pagination(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title in items:
				if bigdh7fpZYl4aT2keV=='#': continue
				bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/'+bigdh7fpZYl4aT2keV.strip('/')
				title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,471)
		jFlCHGZzvXw5E = EcQxOa3RJm86WjTKA.findall('showmore" href="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if jFlCHGZzvXw5E:
			bigdh7fpZYl4aT2keV = jFlCHGZzvXw5E[0]
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مشاهدة المزيد',bigdh7fpZYl4aT2keV,471)
	return
def bv4IDSyw6zuC3pR1lYd75(url,LLMYeXiaVDT9HAnUz87FOv):
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = VbHeOuU1ilzSp2ZRXwBD(url,'url')
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMALIGHT-EPISODES-2nd')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	y4IYUHTpSs8DXEfajQLvWb0g1G = EcQxOa3RJm86WjTKA.findall('"SeasonsBox"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	items = []
	if y4IYUHTpSs8DXEfajQLvWb0g1G and not LLMYeXiaVDT9HAnUz87FOv:
		POjaBmHqzpsx1IYw7kQM4R = EcQxOa3RJm86WjTKA.findall('"series-header".*?src="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R[0] if POjaBmHqzpsx1IYw7kQM4R else fy8iFgEkrO12NR9TWBI35sjY6qHvV
		wlJ6d8hEvpoMNSCmU = y4IYUHTpSs8DXEfajQLvWb0g1G[0]
		items = EcQxOa3RJm86WjTKA.findall('openCity\(event\, \'(.*?)\'\)".*?>(.*?)</button>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if len(items)==1: LLMYeXiaVDT9HAnUz87FOv = items[0][0]
		elif len(items)>1:
			for LLMYeXiaVDT9HAnUz87FOv,title in items: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,473,POjaBmHqzpsx1IYw7kQM4R,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LLMYeXiaVDT9HAnUz87FOv)
	UgbWFLzrCA5RMo7tjwNmdyc68khBGn = EcQxOa3RJm86WjTKA.findall('id="'+LLMYeXiaVDT9HAnUz87FOv+'"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if UgbWFLzrCA5RMo7tjwNmdyc68khBGn and len(items)<2:
		POjaBmHqzpsx1IYw7kQM4R = EcQxOa3RJm86WjTKA.findall('"series-header".*?src="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R[0] if POjaBmHqzpsx1IYw7kQM4R else fy8iFgEkrO12NR9TWBI35sjY6qHvV
		wlJ6d8hEvpoMNSCmU = UgbWFLzrCA5RMo7tjwNmdyc68khBGn[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?title="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if items:
			for bigdh7fpZYl4aT2keV,title in items:
				title = title.replace('ماي سيما',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('مسلسل',fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE)
				if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/'+bigdh7fpZYl4aT2keV.strip('/')
				OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,472,POjaBmHqzpsx1IYw7kQM4R)
		else:
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title,POjaBmHqzpsx1IYw7kQM4R in items:
				if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/'+bigdh7fpZYl4aT2keV.strip('/')
				OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,472,POjaBmHqzpsx1IYw7kQM4R)
	if 'id="pm-related"' in FGRX4myP68S:
		if items: OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مواضيع ذات صلة',url,471)
	return
def rr7SfotkneX85Klup(url):
	XoSyx7p6dqZ1CF8 = []
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMALIGHT-PLAY-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('<div itemprop="description">(.*?)href=',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		uuigJsvIZQ3tprnhxG = EcQxOa3RJm86WjTKA.findall('<p>(.*?)</p>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if uuigJsvIZQ3tprnhxG and SYJvigbI3fts(BfWYUAnyg6eONLjiuE,url,uuigJsvIZQ3tprnhxG,True): return
	YLKFRH6sSIrznXBg = url.replace('/watch.php','/play.php')
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMALIGHT-PLAY-2nd')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	DTZjHKXwJNfxmrty6GPUa4B2cqL = []
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall('"embedURL" href="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if bigdh7fpZYl4aT2keV:
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[0]
		if bigdh7fpZYl4aT2keV and bigdh7fpZYl4aT2keV not in DTZjHKXwJNfxmrty6GPUa4B2cqL:
			DTZjHKXwJNfxmrty6GPUa4B2cqL.append(bigdh7fpZYl4aT2keV)
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named=__embed'
			if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = 'http:'+bigdh7fpZYl4aT2keV
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	items = EcQxOa3RJm86WjTKA.findall("<iframe src='(.*?)'.*?<strong>(.*?)</strong>",FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title in items:
		if bigdh7fpZYl4aT2keV not in DTZjHKXwJNfxmrty6GPUa4B2cqL:
			DTZjHKXwJNfxmrty6GPUa4B2cqL.append(bigdh7fpZYl4aT2keV)
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+title+'__watch'
			if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = 'http:'+bigdh7fpZYl4aT2keV
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	YLKFRH6sSIrznXBg = url.replace('/watch.php','/downloads.php')
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMALIGHT-PLAY-3rd')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"downloadlist"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?<strong>(.*?)</strong>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if bigdh7fpZYl4aT2keV not in DTZjHKXwJNfxmrty6GPUa4B2cqL:
				DTZjHKXwJNfxmrty6GPUa4B2cqL.append(bigdh7fpZYl4aT2keV)
				bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+title+'__download'
				if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = 'http:'+bigdh7fpZYl4aT2keV
				XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(XoSyx7p6dqZ1CF8,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(BOI3t1w8qfHAb0Kl4oMye7haEWS,'url')
	url = A8ECQ0qwTRzPifOGW76FK35uUvhe+'/search.php?keywords='+search
	HAsKeZdTbqjPI1WY(url,'search')
	return
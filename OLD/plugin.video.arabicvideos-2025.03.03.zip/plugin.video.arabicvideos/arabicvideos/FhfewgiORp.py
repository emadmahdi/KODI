# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'DRAMAS7'
K2l9rLfvoXxyZ4NYapO = '_DR7_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['الصفحة الرئيسية','Sign in','تسجيل']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==680: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==681: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,text)
	elif mode==682: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==683: OmsWt89dSA5HyCZ4wL = bv4IDSyw6zuC3pR1lYd75(url,text)
	elif mode==684: OmsWt89dSA5HyCZ4wL = vloIZHenE7imycDM2tPQ(url)
	elif mode==689: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'DRAMAS7-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,689,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'المميزة',BOI3t1w8qfHAb0Kl4oMye7haEWS,681,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'featured')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('/category.php">(.*?)"navslide-divider"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall("'dropdown-menu'(.*?)</ul>",FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	for OOCx0SzAcisQIJGM6DZkopvB3 in z6PX2p7diaskQElBOvMRNcHwqG5D: wlJ6d8hEvpoMNSCmU = wlJ6d8hEvpoMNSCmU.replace(OOCx0SzAcisQIJGM6DZkopvB3,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title in items:
		if title in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
		if title=='جديد الأفلام': title = 'المضاف حديثا'
		OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,684)
	return
def vloIZHenE7imycDM2tPQ(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'DRAMAS7-SUBMENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	y4IYUHTpSs8DXEfajQLvWb0g1G = EcQxOa3RJm86WjTKA.findall('"caret"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if y4IYUHTpSs8DXEfajQLvWb0g1G:
		wlJ6d8hEvpoMNSCmU = y4IYUHTpSs8DXEfajQLvWb0g1G[0]
		wlJ6d8hEvpoMNSCmU = wlJ6d8hEvpoMNSCmU.replace('"presentation"','</ul>')
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if not z6PX2p7diaskQElBOvMRNcHwqG5D: z6PX2p7diaskQElBOvMRNcHwqG5D = [(fy8iFgEkrO12NR9TWBI35sjY6qHvV,wlJ6d8hEvpoMNSCmU)]
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' فرز أو فلتر أو ترتيب '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
		for YuhpOMqmK35QwARXj6do,wlJ6d8hEvpoMNSCmU in z6PX2p7diaskQElBOvMRNcHwqG5D:
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			if YuhpOMqmK35QwARXj6do: YuhpOMqmK35QwARXj6do = YuhpOMqmK35QwARXj6do+': '
			for bigdh7fpZYl4aT2keV,title in items:
				title = YuhpOMqmK35QwARXj6do+title
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,681)
	UgbWFLzrCA5RMo7tjwNmdyc68khBGn = EcQxOa3RJm86WjTKA.findall('"pm-category-subcats"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if UgbWFLzrCA5RMo7tjwNmdyc68khBGn:
		wlJ6d8hEvpoMNSCmU = UgbWFLzrCA5RMo7tjwNmdyc68khBGn[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if len(items)<30:
			OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
			for bigdh7fpZYl4aT2keV,title in items:
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,681)
	if not y4IYUHTpSs8DXEfajQLvWb0g1G and not UgbWFLzrCA5RMo7tjwNmdyc68khBGn: HAsKeZdTbqjPI1WY(url)
	return
def HAsKeZdTbqjPI1WY(url,Bc7G3ur2Tw5QK1fPSkyJ=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if Bc7G3ur2Tw5QK1fPSkyJ=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'POST',url,data,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'DRAMAS7-TITLES-1st')
	else:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'DRAMAS7-TITLES-2nd')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	wlJ6d8hEvpoMNSCmU,items = fy8iFgEkrO12NR9TWBI35sjY6qHvV,[]
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = VbHeOuU1ilzSp2ZRXwBD(url,'url')
	if Bc7G3ur2Tw5QK1fPSkyJ=='ajax-search':
		wlJ6d8hEvpoMNSCmU = FGRX4myP68S
		w7gedkFbJvcqu0fzW43NpyUP = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in w7gedkFbJvcqu0fzW43NpyUP: items.append((fy8iFgEkrO12NR9TWBI35sjY6qHvV,bigdh7fpZYl4aT2keV,title))
	elif Bc7G3ur2Tw5QK1fPSkyJ=='featured':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('id="featured"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			if wlJ6d8hEvpoMNSCmU:
				items = EcQxOa3RJm86WjTKA.findall('''href="(.*?)" title="(.*?)".*?:url\(\'(.*?)\'''',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
				zzECVswWcGAIXhrQlZ7jMokugnv,p7Gkego0m6a8,KEneUI3W2OH = zip(*items)
				items = zip(KEneUI3W2OH,zzECVswWcGAIXhrQlZ7jMokugnv,p7Gkego0m6a8)
	elif Bc7G3ur2Tw5QK1fPSkyJ=='new_episodes':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"row pm-ul-browse-videos(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D: wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	elif Bc7G3ur2Tw5QK1fPSkyJ=='new_movies':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"row pm-ul-browse-videos(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if len(z6PX2p7diaskQElBOvMRNcHwqG5D)>1: wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[1]
	elif Bc7G3ur2Tw5QK1fPSkyJ=='featured_series':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D: wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		w7gedkFbJvcqu0fzW43NpyUP = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in w7gedkFbJvcqu0fzW43NpyUP: items.append((fy8iFgEkrO12NR9TWBI35sjY6qHvV,bigdh7fpZYl4aT2keV,title))
	else:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('(data-echo=".*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D: wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	if wlJ6d8hEvpoMNSCmU and not items: items = EcQxOa3RJm86WjTKA.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	if not items: return
	cmDaLEqWlT7GhonIdX5k1zHQjSiupe = []
	mmO39lwp0LFUrVT = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for POjaBmHqzpsx1IYw7kQM4R,bigdh7fpZYl4aT2keV,title in items:
		RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) (الحلقة|حلقة).\d+',title,EcQxOa3RJm86WjTKA.DOTALL)
		if any(value in title for value in mmO39lwp0LFUrVT):
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,682,POjaBmHqzpsx1IYw7kQM4R)
		elif Bc7G3ur2Tw5QK1fPSkyJ=='new_episodes':
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,682,POjaBmHqzpsx1IYw7kQM4R)
		elif RrzpbE3t9woCk7MXS0GvNdi1BcV:
			title = '_MOD_' + RrzpbE3t9woCk7MXS0GvNdi1BcV[0][0]
			if title not in cmDaLEqWlT7GhonIdX5k1zHQjSiupe:
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,683,POjaBmHqzpsx1IYw7kQM4R)
				cmDaLEqWlT7GhonIdX5k1zHQjSiupe.append(title)
		else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,683,POjaBmHqzpsx1IYw7kQM4R)
	if 1:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"pagination(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title in items:
				if bigdh7fpZYl4aT2keV=='#': continue
				bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/'+bigdh7fpZYl4aT2keV.strip('/')
				title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,681)
	return
def bv4IDSyw6zuC3pR1lYd75(url,LLMYeXiaVDT9HAnUz87FOv):
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = VbHeOuU1ilzSp2ZRXwBD(url,'url')
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'DRAMAS7-EPISODES-2nd')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	y4IYUHTpSs8DXEfajQLvWb0g1G = EcQxOa3RJm86WjTKA.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	mmEsSwOKazXLV1MT = EcQxOa3RJm86WjTKA.findall('"series-header".*?src="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if mmEsSwOKazXLV1MT: POjaBmHqzpsx1IYw7kQM4R = mmEsSwOKazXLV1MT[0]
	else: POjaBmHqzpsx1IYw7kQM4R = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	items = []
	LNrR4g0f1KPVGsU76QqE = False
	if y4IYUHTpSs8DXEfajQLvWb0g1G and not LLMYeXiaVDT9HAnUz87FOv:
		wlJ6d8hEvpoMNSCmU = y4IYUHTpSs8DXEfajQLvWb0g1G[0]
		items = EcQxOa3RJm86WjTKA.findall('''onclick="openCity\(event, '(.*?)'\)">(.*?)</button>''',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for LLMYeXiaVDT9HAnUz87FOv,title in items:
			LLMYeXiaVDT9HAnUz87FOv = LLMYeXiaVDT9HAnUz87FOv.strip('#')
			if len(items)>1: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,683,POjaBmHqzpsx1IYw7kQM4R,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LLMYeXiaVDT9HAnUz87FOv)
			else: LNrR4g0f1KPVGsU76QqE = True
	else: LNrR4g0f1KPVGsU76QqE = True
	UgbWFLzrCA5RMo7tjwNmdyc68khBGn = EcQxOa3RJm86WjTKA.findall('id="'+LLMYeXiaVDT9HAnUz87FOv+'"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if UgbWFLzrCA5RMo7tjwNmdyc68khBGn and LNrR4g0f1KPVGsU76QqE:
		wlJ6d8hEvpoMNSCmU = UgbWFLzrCA5RMo7tjwNmdyc68khBGn[0]
		w7gedkFbJvcqu0fzW43NpyUP = EcQxOa3RJm86WjTKA.findall('title="(.*?)" href="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		items = []
		for title,bigdh7fpZYl4aT2keV in w7gedkFbJvcqu0fzW43NpyUP: items.append((bigdh7fpZYl4aT2keV,title,POjaBmHqzpsx1IYw7kQM4R))
		if not items: items = EcQxOa3RJm86WjTKA.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title,POjaBmHqzpsx1IYw7kQM4R in items:
			bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/'+bigdh7fpZYl4aT2keV.strip('/')
			title = title.replace('</em><span>',ksJdoFWhxTz8Y2N7bOZE)
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,682,POjaBmHqzpsx1IYw7kQM4R)
	return
def rr7SfotkneX85Klup(url):
	hFzEyHWOoRxG,CXTL7NPUAE = [],[]
	YLKFRH6sSIrznXBg = url.replace('watch.php','play.php')
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'DRAMAS7-PLAY-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"WatchList"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('embed-url="(.*?)".*?<strong>(.*?)</strong>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if bigdh7fpZYl4aT2keV not in CXTL7NPUAE:
				CXTL7NPUAE.append(bigdh7fpZYl4aT2keV)
				A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,'name')
				bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+A8ECQ0qwTRzPifOGW76FK35uUvhe+'__watch'
				hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall('<iframe src="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if bigdh7fpZYl4aT2keV:
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[0]
		if bigdh7fpZYl4aT2keV not in CXTL7NPUAE:
			CXTL7NPUAE.append(bigdh7fpZYl4aT2keV)
			A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,'name')
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+A8ECQ0qwTRzPifOGW76FK35uUvhe+'__embed'
			hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"downloadlist"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('download-url="(.*?)".*?<strong>(.*?)</strong>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if bigdh7fpZYl4aT2keV not in CXTL7NPUAE:
				CXTL7NPUAE.append(bigdh7fpZYl4aT2keV)
				A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,'name')
				bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+A8ECQ0qwTRzPifOGW76FK35uUvhe+'__download'
				hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(hFzEyHWOoRxG,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/search.php?keywords='+search
	HAsKeZdTbqjPI1WY(url,'search')
	return
# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'SHIAVOICE'
K2l9rLfvoXxyZ4NYapO = '_SHV_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
headers = {'User-Agent':None}
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==310: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==311: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url)
	elif mode==312: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==313: OmsWt89dSA5HyCZ4wL = DGNtqjSOIYbfJCB(url)
	elif mode==314: OmsWt89dSA5HyCZ4wL = Voyqwkr1g8BY2LJXz3u(text)
	elif mode==319: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,319,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SHIAVOICE-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('id="menulinks"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	items = EcQxOa3RJm86WjTKA.findall('<h5>(.*?)</h5>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL|EcQxOa3RJm86WjTKA.IGNORECASE)
	for iYMzQVNL2h4IRemt in range(len(items)):
		title = items[iYMzQVNL2h4IRemt].strip(ksJdoFWhxTz8Y2N7bOZE)
		OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,BOI3t1w8qfHAb0Kl4oMye7haEWS,314,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,str(iYMzQVNL2h4IRemt+1))
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'مقاطع شهر',BOI3t1w8qfHAb0Kl4oMye7haEWS,314,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'0')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?<B>(.*?)</B>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title in items:
		bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+bigdh7fpZYl4aT2keV
		OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,311)
	return FGRX4myP68S
def Voyqwkr1g8BY2LJXz3u(iYMzQVNL2h4IRemt):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SHIAVOICE-LATEST-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	if iYMzQVNL2h4IRemt=='0':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="tab-content"(.*?)</table>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,name,title in items:
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+bigdh7fpZYl4aT2keV
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			name = name.strip(ksJdoFWhxTz8Y2N7bOZE)
			title = title+' ('+name+')'
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,312)
	elif iYMzQVNL2h4IRemt in ['1','2','3']:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('(<h5>.*?)<div class="col-lg',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		azeK9t0XcLxMiHgvrR5 = int(iYMzQVNL2h4IRemt)-1
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[azeK9t0XcLxMiHgvrR5]
		if iYMzQVNL2h4IRemt=='1': items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		else: items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title,name in items:
			POjaBmHqzpsx1IYw7kQM4R = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+POjaBmHqzpsx1IYw7kQM4R
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+bigdh7fpZYl4aT2keV
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			name = name.strip(ksJdoFWhxTz8Y2N7bOZE)
			title = title+' ('+name+')'
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,311,POjaBmHqzpsx1IYw7kQM4R)
	elif iYMzQVNL2h4IRemt in ['4','5','6']:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('(<h5>.*?)</table>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		iYMzQVNL2h4IRemt = int(iYMzQVNL2h4IRemt)-4
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[iYMzQVNL2h4IRemt]
		items = EcQxOa3RJm86WjTKA.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for POjaBmHqzpsx1IYw7kQM4R,bigdh7fpZYl4aT2keV,yNGUJ2kYzPnhDLi,title,z6FysMQJTa2IWYdrDx7BjObwN3fE in items:
			POjaBmHqzpsx1IYw7kQM4R = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+POjaBmHqzpsx1IYw7kQM4R
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+bigdh7fpZYl4aT2keV
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			yNGUJ2kYzPnhDLi = yNGUJ2kYzPnhDLi.strip(ksJdoFWhxTz8Y2N7bOZE)
			z6FysMQJTa2IWYdrDx7BjObwN3fE = z6FysMQJTa2IWYdrDx7BjObwN3fE.strip(ksJdoFWhxTz8Y2N7bOZE)
			if yNGUJ2kYzPnhDLi: name = yNGUJ2kYzPnhDLi
			else: name = z6FysMQJTa2IWYdrDx7BjObwN3fE
			title = title+' ('+name+')'
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,312,POjaBmHqzpsx1IYw7kQM4R)
	return
def HAsKeZdTbqjPI1WY(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SHIAVOICE-TITLES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('ibox-heading"(.*?)class="float-right',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	if 'catsum-mobile' in wlJ6d8hEvpoMNSCmU:
		items = EcQxOa3RJm86WjTKA.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if items:
			for POjaBmHqzpsx1IYw7kQM4R,bigdh7fpZYl4aT2keV,title,count in items:
				POjaBmHqzpsx1IYw7kQM4R = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+POjaBmHqzpsx1IYw7kQM4R
				bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+bigdh7fpZYl4aT2keV
				count = count.replace(' الصوتية: ',':')
				title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
				title = title+' ('+count+')'
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,311,POjaBmHqzpsx1IYw7kQM4R)
	else:
		items = EcQxOa3RJm86WjTKA.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title,qj5Pcg7hfx,rQ0jN7XkZPE1AYU in items:
			if title==fy8iFgEkrO12NR9TWBI35sjY6qHvV or qj5Pcg7hfx==fy8iFgEkrO12NR9TWBI35sjY6qHvV: continue
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+bigdh7fpZYl4aT2keV
			title = title+' ('+rQ0jN7XkZPE1AYU+')'
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,312)
	if not items: eQgbVPaIBvTn8fsjJRt241(FGRX4myP68S)
	return
def eQgbVPaIBvTn8fsjJRt241(FGRX4myP68S):
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="ibox-content"(.*?)class="pagination',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	items = EcQxOa3RJm86WjTKA.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title,name,count,rQ0jN7XkZPE1AYU in items:
		bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+bigdh7fpZYl4aT2keV
		title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
		name = name.strip(ksJdoFWhxTz8Y2N7bOZE)
		title = title+' ('+name+')'
		OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,312,fy8iFgEkrO12NR9TWBI35sjY6qHvV,rQ0jN7XkZPE1AYU)
	return
def DGNtqjSOIYbfJCB(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SHIAVOICE-SEARCH_ITEMS-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="ibox-content p-1"(.*?)class="ibox-content"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not z6PX2p7diaskQElBOvMRNcHwqG5D:
		HAsKeZdTbqjPI1WY(url)
		return
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?<strong>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title in items:
		bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+bigdh7fpZYl4aT2keV
		title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
		if '/play-' in bigdh7fpZYl4aT2keV: OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,312)
		else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,311)
	return
def rr7SfotkneX85Klup(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SHIAVOICE-PLAY-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall('<audio.*?src="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall('<video.*?src="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV[0]
	E7HR1ZcMuzUs9XCVrNGJYi(bigdh7fpZYl4aT2keV,BfWYUAnyg6eONLjiuE,'video')
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	Z4yQR8XGMEduwxDUA12zefPtS0T = ['&t=a','&t=c','&t=s']
	if showDialogs:
		CtkmR4BWTdaU = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S('موقع صوت الشيعة - أختر البحث', CtkmR4BWTdaU)
		if yNqzFDjKM0SrO == -1: return
	elif '_SHIAVOICE-PERSONS_' in yJWh5lC4wcNrRi3nFa: yNqzFDjKM0SrO = 0
	elif '_SHIAVOICE-ALBUMS_' in yJWh5lC4wcNrRi3nFa: yNqzFDjKM0SrO = 1
	elif '_SHIAVOICE-AUDIOS_' in yJWh5lC4wcNrRi3nFa: yNqzFDjKM0SrO = 2
	else: return
	type = Z4yQR8XGMEduwxDUA12zefPtS0T[yNqzFDjKM0SrO]
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/search.php?q='+search+type
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SHIAVOICE-SEARCH-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="ibox-content"(.*?)class="ibox-content"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		if yNqzFDjKM0SrO in [0,1]:
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title,name in items:
				title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
				name = name.strip(ksJdoFWhxTz8Y2N7bOZE)
				title = title+' ('+name+')'
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,313,POjaBmHqzpsx1IYw7kQM4R)
		elif yNqzFDjKM0SrO==2:
			items = EcQxOa3RJm86WjTKA.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title,name in items:
				title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
				name = name.strip(ksJdoFWhxTz8Y2N7bOZE)
				title = title+' ('+name+')'
				OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,312)
	return
# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'IFILM'
K2l9rLfvoXxyZ4NYapO = '_IFL_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
rrkyXDFoKTYtf = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][1]
bmYdTZFyoVtj0w2OJszHu3ilNPC = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][2]
uubahLXnFsfVwWorJM = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][3]
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,jmI9qRnVJo2a3tpcH8gfYkP,text):
	if   mode==20: OmsWt89dSA5HyCZ4wL = y03CjXkKudbSfq()
	elif mode==21: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M(url)
	elif mode==22: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,jmI9qRnVJo2a3tpcH8gfYkP)
	elif mode==23: OmsWt89dSA5HyCZ4wL = eQgbVPaIBvTn8fsjJRt241(url,jmI9qRnVJo2a3tpcH8gfYkP)
	elif mode==24: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url,text)
	elif mode==25: OmsWt89dSA5HyCZ4wL = rr0kMbKGipQ1WhOYTBoSZR8(url)
	elif mode==27: OmsWt89dSA5HyCZ4wL = uEyU2e6lv4(url)
	elif mode==28: OmsWt89dSA5HyCZ4wL = OOohvAUjqPTNa()
	elif mode==29: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def y03CjXkKudbSfq():
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'عربي',BOI3t1w8qfHAb0Kl4oMye7haEWS,21,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'101')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'English',rrkyXDFoKTYtf,21,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'101')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فارسى',bmYdTZFyoVtj0w2OJszHu3ilNPC,21,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'101')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فارسى 2',uubahLXnFsfVwWorJM,21,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'101')
	return
def OOohvAUjqPTNa():
	OZD1l4pAMzeH('live',K2l9rLfvoXxyZ4NYapO+'عربي',BOI3t1w8qfHAb0Kl4oMye7haEWS,27)
	OZD1l4pAMzeH('live',K2l9rLfvoXxyZ4NYapO+'English',rrkyXDFoKTYtf,27)
	OZD1l4pAMzeH('live',K2l9rLfvoXxyZ4NYapO+'فارسى',bmYdTZFyoVtj0w2OJszHu3ilNPC,27)
	OZD1l4pAMzeH('live',K2l9rLfvoXxyZ4NYapO+'فارسى 2',uubahLXnFsfVwWorJM,27)
	return
def UeOqpYGBXiJdAatwDboErxZLyh0M(GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1):
	BfWYUAnyg6eONLjiuE = GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1
	if GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1=='IFILM-ARABIC': GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1 = BOI3t1w8qfHAb0Kl4oMye7haEWS
	elif GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1=='IFILM-ENGLISH': GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1 = rrkyXDFoKTYtf
	else: BfWYUAnyg6eONLjiuE = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	PwOhx7WTAQGq8o2n = hUXrtA5kRpEQ7zI8V16vCfgu(GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1)
	if PwOhx7WTAQGq8o2n=='ar' or BfWYUAnyg6eONLjiuE=='IFILM-ARABIC':
		YHCL8I6NDB = 'بحث في الموقع'
		yNGUJ2kYzPnhDLi = 'مسلسلات - حالية'
		z6FysMQJTa2IWYdrDx7BjObwN3fE = 'مسلسلات - أحدث'
		dkn5TQhEapj91JfCziZ7Aby = 'مسلسلات - أبجدي'
		RdrayA19NoU5846s7vZxIg = 'بث حي آي فيلم'
		MCc9k2RopnSEXYDFIZJWTuLw6yzQ = 'أفلام'
		J2BorxtYbSmZ = 'موسيقى'
		CoHnRr5EueXIM1k6St0YDNdm = 'برامج'
	elif PwOhx7WTAQGq8o2n=='en' or BfWYUAnyg6eONLjiuE=='IFILM-ENGLISH':
		YHCL8I6NDB = 'Search in site'
		yNGUJ2kYzPnhDLi = 'Series - Current'
		z6FysMQJTa2IWYdrDx7BjObwN3fE = 'Series - Latest'
		dkn5TQhEapj91JfCziZ7Aby = 'Series - Alphabet'
		RdrayA19NoU5846s7vZxIg = 'Live iFilm channel'
		MCc9k2RopnSEXYDFIZJWTuLw6yzQ = 'Movies'
		J2BorxtYbSmZ = 'Music'
		CoHnRr5EueXIM1k6St0YDNdm = 'Shows'
	elif PwOhx7WTAQGq8o2n in ['fa','fa2']:
		YHCL8I6NDB = 'جستجو در سایت'
		yNGUJ2kYzPnhDLi = 'سريال - جاری'
		z6FysMQJTa2IWYdrDx7BjObwN3fE = 'سريال - آخرین'
		dkn5TQhEapj91JfCziZ7Aby = 'سريال - الفبا'
		RdrayA19NoU5846s7vZxIg = 'پخش زنده اي فيلم'
		MCc9k2RopnSEXYDFIZJWTuLw6yzQ = 'فيلم'
		J2BorxtYbSmZ = 'موسيقى'
		CoHnRr5EueXIM1k6St0YDNdm = 'برنامه ها'
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+YHCL8I6NDB,GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1,29,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('live',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+RdrayA19NoU5846s7vZxIg,GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1,27)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	ffqUAI9tudHkKSblEYv30aJjo = ['Series','Program','Music']
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1+'/home',fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'IFILM-MENU-1st')
	z6PX2p7diaskQElBOvMRNcHwqG5D=EcQxOa3RJm86WjTKA.findall('button-menu(.*?)/Contact',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if any(value in bigdh7fpZYl4aT2keV for value in ffqUAI9tudHkKSblEYv30aJjo):
				url = GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1+bigdh7fpZYl4aT2keV
				if 'Series' in bigdh7fpZYl4aT2keV:
					OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+yNGUJ2kYzPnhDLi,url,22,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'100')
					OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+z6FysMQJTa2IWYdrDx7BjObwN3fE,url,22,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'101')
					OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+dkn5TQhEapj91JfCziZ7Aby,url,22,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'201')
				elif 'Film' in bigdh7fpZYl4aT2keV: OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+MCc9k2RopnSEXYDFIZJWTuLw6yzQ,url,22,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'100')
				elif 'Music' in bigdh7fpZYl4aT2keV: OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+J2BorxtYbSmZ,url,25,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'101')
				elif 'Program' in bigdh7fpZYl4aT2keV: OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+CoHnRr5EueXIM1k6St0YDNdm,url,22,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'101')
	return FGRX4myP68S
def rr0kMbKGipQ1WhOYTBoSZR8(url):
	GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1 = HtDug3fE5KmcipS0IaQRoTrPOvh8(url)
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'IFILM-MUSIC_MENU-1st')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('Music-tools-header(.*?)Music-body',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	title = EcQxOa3RJm86WjTKA.findall('<p>(.*?)</p>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)[0]
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,22,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'101')
	items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title in items:
		bigdh7fpZYl4aT2keV = GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1 + bigdh7fpZYl4aT2keV
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,23,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'101')
	return
def HAsKeZdTbqjPI1WY(url,jmI9qRnVJo2a3tpcH8gfYkP):
	GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1 = HtDug3fE5KmcipS0IaQRoTrPOvh8(url)
	PwOhx7WTAQGq8o2n = hUXrtA5kRpEQ7zI8V16vCfgu(url)
	type = url.split('/')[-1]
	Y7oQbUnpi03G6mxleOV = str(int(jmI9qRnVJo2a3tpcH8gfYkP)//100)
	jmI9qRnVJo2a3tpcH8gfYkP = str(int(jmI9qRnVJo2a3tpcH8gfYkP)%100)
	if type=='Series' and jmI9qRnVJo2a3tpcH8gfYkP=='0':
		FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'IFILM-TITLES-1st')
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('serial-body(.*?)class="row',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
			title = XXcPiylRDh6IapYA25rwO8u(title)
			title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
			bigdh7fpZYl4aT2keV = GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1 + bigdh7fpZYl4aT2keV
			POjaBmHqzpsx1IYw7kQM4R = GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1 + DVX5GWhnIxYlSd9rEuetjk40UJ(POjaBmHqzpsx1IYw7kQM4R)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,23,POjaBmHqzpsx1IYw7kQM4R,Y7oQbUnpi03G6mxleOV+'01')
	TU8AWL9N5h0QntyOZcbz=0
	if type=='Series': fnogyzNA30JCPMYqHTavG7ZKp='3'
	if type=='Film': fnogyzNA30JCPMYqHTavG7ZKp='5'
	if type=='Program': fnogyzNA30JCPMYqHTavG7ZKp='7'
	if type in ['Series','Program','Film'] and jmI9qRnVJo2a3tpcH8gfYkP!='0':
		YLKFRH6sSIrznXBg = GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1+'/Home/PageingItem?category='+fnogyzNA30JCPMYqHTavG7ZKp+'&page='+jmI9qRnVJo2a3tpcH8gfYkP+'&size=30&orderby='+Y7oQbUnpi03G6mxleOV
		FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'IFILM-TITLES-2nd')
		items = EcQxOa3RJm86WjTKA.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		for id,title,POjaBmHqzpsx1IYw7kQM4R in items:
			title = XXcPiylRDh6IapYA25rwO8u(title)
			title = title.replace('\\',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			title = title.replace('"',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			TU8AWL9N5h0QntyOZcbz += 1
			bigdh7fpZYl4aT2keV = GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1 + '/' + type + '/Content/' + id
			POjaBmHqzpsx1IYw7kQM4R = GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1 + DVX5GWhnIxYlSd9rEuetjk40UJ(POjaBmHqzpsx1IYw7kQM4R)
			if type=='Film': OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,24,POjaBmHqzpsx1IYw7kQM4R,Y7oQbUnpi03G6mxleOV+'01')
			else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,23,POjaBmHqzpsx1IYw7kQM4R,Y7oQbUnpi03G6mxleOV+'01')
	if type=='Music':
		FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1+'/Music/Index?page='+jmI9qRnVJo2a3tpcH8gfYkP,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'IFILM-TITLES-3rd')
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('pagination-demo(.*?)pagination-demo',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
			TU8AWL9N5h0QntyOZcbz += 1
			POjaBmHqzpsx1IYw7kQM4R = GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1 + POjaBmHqzpsx1IYw7kQM4R
			bigdh7fpZYl4aT2keV = GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1 + bigdh7fpZYl4aT2keV
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,23,POjaBmHqzpsx1IYw7kQM4R,'101')
	if TU8AWL9N5h0QntyOZcbz>20:
		title='صفحة '
		if PwOhx7WTAQGq8o2n=='en': title = 'Page '
		if PwOhx7WTAQGq8o2n=='fa': title = 'صفحه '
		if PwOhx7WTAQGq8o2n=='fa2': title = 'صفحه '
		for ssCHhqKQeO9aVkgZ in range(1,11) :
			if not jmI9qRnVJo2a3tpcH8gfYkP==str(ssCHhqKQeO9aVkgZ):
				rraBYNEfvywcZ63UFtRVC = '0'+str(ssCHhqKQeO9aVkgZ)
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title+str(ssCHhqKQeO9aVkgZ),url,22,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Y7oQbUnpi03G6mxleOV+rraBYNEfvywcZ63UFtRVC[-2:])
	return
def eQgbVPaIBvTn8fsjJRt241(url,jmI9qRnVJo2a3tpcH8gfYkP):
	if not jmI9qRnVJo2a3tpcH8gfYkP: jmI9qRnVJo2a3tpcH8gfYkP = 0
	GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1 = HtDug3fE5KmcipS0IaQRoTrPOvh8(url)
	zzsUoyQtBx = HtDug3fE5KmcipS0IaQRoTrPOvh8(url)
	PwOhx7WTAQGq8o2n = hUXrtA5kRpEQ7zI8V16vCfgu(url)
	V5VDwKLAYM3 = url.split('/')
	id,type = V5VDwKLAYM3[-1],V5VDwKLAYM3[3]
	Y7oQbUnpi03G6mxleOV = str(int(jmI9qRnVJo2a3tpcH8gfYkP)//100)
	jmI9qRnVJo2a3tpcH8gfYkP = str(int(jmI9qRnVJo2a3tpcH8gfYkP)%100)
	TU8AWL9N5h0QntyOZcbz = 0
	if type=='Series':
		FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'IFILM-EPISODES-1st')
		items = EcQxOa3RJm86WjTKA.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		title = ' - الحلقة '
		if PwOhx7WTAQGq8o2n=='en': title = ' - Episode '
		if PwOhx7WTAQGq8o2n=='fa': title = ' - قسمت '
		if PwOhx7WTAQGq8o2n=='fa2': title = ' - قسمت '
		if PwOhx7WTAQGq8o2n=='fa': NrW4n8shgX0a1mjS9OQPp = fy8iFgEkrO12NR9TWBI35sjY6qHvV
		else: NrW4n8shgX0a1mjS9OQPp = PwOhx7WTAQGq8o2n
		EHT4c2QDftmXY0pwNkyeVjOobR8n9Z = EcQxOa3RJm86WjTKA.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		for name,count,POjaBmHqzpsx1IYw7kQM4R,bigdh7fpZYl4aT2keV in items:
			for RrzpbE3t9woCk7MXS0GvNdi1BcV in range(int(count),0,-1):
				J8XVncUH1x4lzdbpjwBOk = POjaBmHqzpsx1IYw7kQM4R + NrW4n8shgX0a1mjS9OQPp + id + '/' + str(RrzpbE3t9woCk7MXS0GvNdi1BcV) + '.png'
				yNGUJ2kYzPnhDLi = name + title + str(RrzpbE3t9woCk7MXS0GvNdi1BcV)
				yNGUJ2kYzPnhDLi = IVcCL3aAfU9wS7kWev1g2XBjZRJ(yNGUJ2kYzPnhDLi)
				OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+yNGUJ2kYzPnhDLi,url,24,J8XVncUH1x4lzdbpjwBOk,fy8iFgEkrO12NR9TWBI35sjY6qHvV,str(RrzpbE3t9woCk7MXS0GvNdi1BcV))
	elif type=='Program':
		YLKFRH6sSIrznXBg = GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+jmI9qRnVJo2a3tpcH8gfYkP+'&size=30&orderby=1'
		FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'IFILM-EPISODES-2nd')
		items = EcQxOa3RJm86WjTKA.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		title = ' - الحلقة '
		if PwOhx7WTAQGq8o2n=='en': title = ' - Episode '
		if PwOhx7WTAQGq8o2n=='fa': title = ' - قسمت '
		if PwOhx7WTAQGq8o2n=='fa2': title = ' - قسمت '
		for RrzpbE3t9woCk7MXS0GvNdi1BcV,POjaBmHqzpsx1IYw7kQM4R,bigdh7fpZYl4aT2keV,oHKb0eIOAVk,name in items:
			TU8AWL9N5h0QntyOZcbz += 1
			J8XVncUH1x4lzdbpjwBOk = zzsUoyQtBx + DVX5GWhnIxYlSd9rEuetjk40UJ(POjaBmHqzpsx1IYw7kQM4R)
			name = XXcPiylRDh6IapYA25rwO8u(name)
			yNGUJ2kYzPnhDLi = name + title + str(RrzpbE3t9woCk7MXS0GvNdi1BcV)
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+yNGUJ2kYzPnhDLi,YLKFRH6sSIrznXBg,24,J8XVncUH1x4lzdbpjwBOk,fy8iFgEkrO12NR9TWBI35sjY6qHvV,str(TU8AWL9N5h0QntyOZcbz))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			YLKFRH6sSIrznXBg = GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1+'/Music/GetTracksBy?id='+str(id)+'&page='+jmI9qRnVJo2a3tpcH8gfYkP+'&size=30&type=0'
			FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'IFILM-EPISODES-3rd')
			items = EcQxOa3RJm86WjTKA.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
			for POjaBmHqzpsx1IYw7kQM4R,bigdh7fpZYl4aT2keV,name,title in items:
				TU8AWL9N5h0QntyOZcbz += 1
				J8XVncUH1x4lzdbpjwBOk = zzsUoyQtBx + DVX5GWhnIxYlSd9rEuetjk40UJ(POjaBmHqzpsx1IYw7kQM4R)
				yNGUJ2kYzPnhDLi = name + ' - ' + title
				yNGUJ2kYzPnhDLi = yNGUJ2kYzPnhDLi.strip(ksJdoFWhxTz8Y2N7bOZE)
				yNGUJ2kYzPnhDLi = XXcPiylRDh6IapYA25rwO8u(yNGUJ2kYzPnhDLi)
				OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+yNGUJ2kYzPnhDLi,YLKFRH6sSIrznXBg,24,J8XVncUH1x4lzdbpjwBOk,fy8iFgEkrO12NR9TWBI35sjY6qHvV,str(TU8AWL9N5h0QntyOZcbz))
		elif 'Clips' in url:
			YLKFRH6sSIrznXBg = GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1+'/Music/GetTracksBy?id=0&page='+jmI9qRnVJo2a3tpcH8gfYkP+'&size=30&type=15'
			FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'IFILM-EPISODES-4th')
			items = EcQxOa3RJm86WjTKA.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
			for POjaBmHqzpsx1IYw7kQM4R,title,bigdh7fpZYl4aT2keV in items:
				TU8AWL9N5h0QntyOZcbz += 1
				J8XVncUH1x4lzdbpjwBOk = zzsUoyQtBx + DVX5GWhnIxYlSd9rEuetjk40UJ(POjaBmHqzpsx1IYw7kQM4R)
				yNGUJ2kYzPnhDLi = title.strip(ksJdoFWhxTz8Y2N7bOZE)
				yNGUJ2kYzPnhDLi = XXcPiylRDh6IapYA25rwO8u(yNGUJ2kYzPnhDLi)
				OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+yNGUJ2kYzPnhDLi,YLKFRH6sSIrznXBg,24,J8XVncUH1x4lzdbpjwBOk,fy8iFgEkrO12NR9TWBI35sjY6qHvV,str(TU8AWL9N5h0QntyOZcbz))
		elif 'category' in url:
			if 'category=6' in url:
				YLKFRH6sSIrznXBg = GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1+'/Music/GetTracksBy?id=0&page='+jmI9qRnVJo2a3tpcH8gfYkP+'&size=30&type=6'
				FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'IFILM-EPISODES-5th')
			elif 'category=4' in url:
				YLKFRH6sSIrznXBg = GVeQ7YZCW90FIJA4vDS3RfsEhmt8q1+'/Music/GetTracksBy?id=0&page='+jmI9qRnVJo2a3tpcH8gfYkP+'&size=30&type=4'
				FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'IFILM-EPISODES-6th')
			items = EcQxOa3RJm86WjTKA.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
			for POjaBmHqzpsx1IYw7kQM4R,bigdh7fpZYl4aT2keV,name,title in items:
				TU8AWL9N5h0QntyOZcbz += 1
				J8XVncUH1x4lzdbpjwBOk = zzsUoyQtBx + DVX5GWhnIxYlSd9rEuetjk40UJ(POjaBmHqzpsx1IYw7kQM4R)
				yNGUJ2kYzPnhDLi = name + ' - ' + title
				yNGUJ2kYzPnhDLi = yNGUJ2kYzPnhDLi.strip(ksJdoFWhxTz8Y2N7bOZE)
				yNGUJ2kYzPnhDLi = XXcPiylRDh6IapYA25rwO8u(yNGUJ2kYzPnhDLi)
				OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+yNGUJ2kYzPnhDLi,YLKFRH6sSIrznXBg,24,J8XVncUH1x4lzdbpjwBOk,fy8iFgEkrO12NR9TWBI35sjY6qHvV,str(TU8AWL9N5h0QntyOZcbz))
	if type=='Music' or type=='Program':
		if TU8AWL9N5h0QntyOZcbz>25:
			title='صفحة '
			if PwOhx7WTAQGq8o2n=='en': title = ' Page '
			if PwOhx7WTAQGq8o2n=='fa': title = ' صفحه '
			if PwOhx7WTAQGq8o2n=='fa2': title = ' صفحه '
			for ssCHhqKQeO9aVkgZ in range(1,11):
				if not jmI9qRnVJo2a3tpcH8gfYkP==str(ssCHhqKQeO9aVkgZ):
					rraBYNEfvywcZ63UFtRVC = '0'+str(ssCHhqKQeO9aVkgZ)
					OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title+str(ssCHhqKQeO9aVkgZ),url,23,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Y7oQbUnpi03G6mxleOV+rraBYNEfvywcZ63UFtRVC[-2:])
	return
def rr7SfotkneX85Klup(url,RrzpbE3t9woCk7MXS0GvNdi1BcV):
	zzsUoyQtBx = HtDug3fE5KmcipS0IaQRoTrPOvh8(url)
	WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = [],[]
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'IFILM-PLAY-1st')
	items = EcQxOa3RJm86WjTKA.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if items:
		PwOhx7WTAQGq8o2n = hUXrtA5kRpEQ7zI8V16vCfgu(url)
		V5VDwKLAYM3 = url.split('/')
		id,type = V5VDwKLAYM3[-1],V5VDwKLAYM3[3]
		bigdh7fpZYl4aT2keV = items[0][0]+PwOhx7WTAQGq8o2n+id+'/,'+RrzpbE3t9woCk7MXS0GvNdi1BcV+','+RrzpbE3t9woCk7MXS0GvNdi1BcV+'_'+items[0][2]
		WFlpmsYGKNy.append('m3u8')
		XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	items = EcQxOa3RJm86WjTKA.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if items:
		PwOhx7WTAQGq8o2n = hUXrtA5kRpEQ7zI8V16vCfgu(url)
		V5VDwKLAYM3 = url.split('/')
		id,type = V5VDwKLAYM3[-1],V5VDwKLAYM3[3]
		bigdh7fpZYl4aT2keV = items[0][0]+PwOhx7WTAQGq8o2n+id+'/'+RrzpbE3t9woCk7MXS0GvNdi1BcV+items[0][2]
		WFlpmsYGKNy.append('mp4 url')
		XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	items = EcQxOa3RJm86WjTKA.findall('source src="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV in items:
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.replace('//','/')
		WFlpmsYGKNy.append('mp4 src')
		XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	items = EcQxOa3RJm86WjTKA.findall('VideoAddress":"(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if items:
		bigdh7fpZYl4aT2keV = items[int(RrzpbE3t9woCk7MXS0GvNdi1BcV)-1]
		bigdh7fpZYl4aT2keV = zzsUoyQtBx+DVX5GWhnIxYlSd9rEuetjk40UJ(bigdh7fpZYl4aT2keV)
		WFlpmsYGKNy.append('mp4 address')
		XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	items = EcQxOa3RJm86WjTKA.findall('VoiceAddress":"(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if items:
		bigdh7fpZYl4aT2keV = items[int(RrzpbE3t9woCk7MXS0GvNdi1BcV)-1]
		bigdh7fpZYl4aT2keV = zzsUoyQtBx+DVX5GWhnIxYlSd9rEuetjk40UJ(bigdh7fpZYl4aT2keV)
		WFlpmsYGKNy.append('mp3 address')
		XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	if len(XoSyx7p6dqZ1CF8)==1: bigdh7fpZYl4aT2keV = XoSyx7p6dqZ1CF8[0]
	else:
		yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S('اختر الفيديو المناسب:', WFlpmsYGKNy)
		if yNqzFDjKM0SrO == -1 : return
		bigdh7fpZYl4aT2keV = XoSyx7p6dqZ1CF8[yNqzFDjKM0SrO]
	E7HR1ZcMuzUs9XCVrNGJYi(bigdh7fpZYl4aT2keV,BfWYUAnyg6eONLjiuE,'video')
	return
def HtDug3fE5KmcipS0IaQRoTrPOvh8(url):
	if BOI3t1w8qfHAb0Kl4oMye7haEWS in url: C0C4kdG53sPAbNq8OBMpitLThHl = BOI3t1w8qfHAb0Kl4oMye7haEWS
	elif rrkyXDFoKTYtf in url: C0C4kdG53sPAbNq8OBMpitLThHl = rrkyXDFoKTYtf
	elif bmYdTZFyoVtj0w2OJszHu3ilNPC in url: C0C4kdG53sPAbNq8OBMpitLThHl = bmYdTZFyoVtj0w2OJszHu3ilNPC
	elif uubahLXnFsfVwWorJM in url: C0C4kdG53sPAbNq8OBMpitLThHl = uubahLXnFsfVwWorJM
	else: C0C4kdG53sPAbNq8OBMpitLThHl = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	return C0C4kdG53sPAbNq8OBMpitLThHl
def hUXrtA5kRpEQ7zI8V16vCfgu(url):
	if   BOI3t1w8qfHAb0Kl4oMye7haEWS in url: PwOhx7WTAQGq8o2n = 'ar'
	elif rrkyXDFoKTYtf in url: PwOhx7WTAQGq8o2n = 'en'
	elif bmYdTZFyoVtj0w2OJszHu3ilNPC in url: PwOhx7WTAQGq8o2n = 'fa'
	elif uubahLXnFsfVwWorJM in url: PwOhx7WTAQGq8o2n = 'fa2'
	else: PwOhx7WTAQGq8o2n = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	return PwOhx7WTAQGq8o2n
def uEyU2e6lv4(url):
	PwOhx7WTAQGq8o2n = hUXrtA5kRpEQ7zI8V16vCfgu(url)
	YLKFRH6sSIrznXBg = url + '/Home/Live'
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'IFILM-LIVE-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	items = EcQxOa3RJm86WjTKA.findall('source src="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	MYWwFs7XA2 = items[0]
	E7HR1ZcMuzUs9XCVrNGJYi(MYWwFs7XA2,BfWYUAnyg6eONLjiuE,'live')
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if not search:
		search = GFYl1tsoOkHC0Ajeur8JQiMx()
		if not search: return
	CE6HW2phYix9XvVdfqe1ObQIFl5mMj = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	if showDialogs:
		E3aZLDksNKFUmPGV = [ BOI3t1w8qfHAb0Kl4oMye7haEWS , rrkyXDFoKTYtf , bmYdTZFyoVtj0w2OJszHu3ilNPC , uubahLXnFsfVwWorJM ]
		CfDp1wiR2P87 = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S('اختر اللغة المناسبة:', CfDp1wiR2P87)
		if yNqzFDjKM0SrO == -1 : return
		website = E3aZLDksNKFUmPGV[yNqzFDjKM0SrO]
	else:
		if '_IFILM-ARABIC_' in yJWh5lC4wcNrRi3nFa: website = BOI3t1w8qfHAb0Kl4oMye7haEWS
		elif '_IFILM-ENGLISH_' in yJWh5lC4wcNrRi3nFa: website = rrkyXDFoKTYtf
		else: website = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if not website: return
	PwOhx7WTAQGq8o2n = hUXrtA5kRpEQ7zI8V16vCfgu(website)
	YLKFRH6sSIrznXBg = website + "/Home/Search?searchstring=" + CE6HW2phYix9XvVdfqe1ObQIFl5mMj
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'IFILM-SEARCH-1st')
	items = EcQxOa3RJm86WjTKA.findall('"ImageAddress_S":"(.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if items:
		for POjaBmHqzpsx1IYw7kQM4R,fnogyzNA30JCPMYqHTavG7ZKp,id,title in items:
			if fnogyzNA30JCPMYqHTavG7ZKp in ['3','7']:
				title = title.replace('\\',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
				title = title.replace('"',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
				if fnogyzNA30JCPMYqHTavG7ZKp=='3':
					type = 'Series'
					if PwOhx7WTAQGq8o2n=='ar': name = 'مسلسل : '
					elif PwOhx7WTAQGq8o2n=='en': name = 'Series : '
					elif PwOhx7WTAQGq8o2n=='fa': name = 'سريال ها : '
					elif PwOhx7WTAQGq8o2n=='fa2': name = 'سريال ها : '
				elif fnogyzNA30JCPMYqHTavG7ZKp=='5':
					type = 'Film'
					if PwOhx7WTAQGq8o2n=='ar': name = 'فيلم : '
					elif PwOhx7WTAQGq8o2n=='en': name = 'Movie : '
					elif PwOhx7WTAQGq8o2n=='fa': name = 'فيلم : '
					elif PwOhx7WTAQGq8o2n=='fa2': name = 'فلم ها : '
				elif fnogyzNA30JCPMYqHTavG7ZKp=='7':
					type = 'Program'
					if PwOhx7WTAQGq8o2n=='ar': name = 'برنامج : '
					elif PwOhx7WTAQGq8o2n=='en': name = 'Program : '
					elif PwOhx7WTAQGq8o2n=='fa': name = 'برنامه ها : '
					elif PwOhx7WTAQGq8o2n=='fa2': name = 'برنامه ها : '
				title = name + title
				bigdh7fpZYl4aT2keV = website + '/' + type + '/Content/' + id
				POjaBmHqzpsx1IYw7kQM4R = DVX5GWhnIxYlSd9rEuetjk40UJ(POjaBmHqzpsx1IYw7kQM4R)
				POjaBmHqzpsx1IYw7kQM4R = website+POjaBmHqzpsx1IYw7kQM4R
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,23,POjaBmHqzpsx1IYw7kQM4R,'101')
	return
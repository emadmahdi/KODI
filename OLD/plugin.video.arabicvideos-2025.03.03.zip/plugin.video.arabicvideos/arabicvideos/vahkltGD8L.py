# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'EGYBEST4'
K2l9rLfvoXxyZ4NYapO = '_EB4_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['ايجي بست','اتصل بنا','ايجي بست الاصلي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,jmI9qRnVJo2a3tpcH8gfYkP,text):
	if   mode==800: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==801: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,jmI9qRnVJo2a3tpcH8gfYkP)
	elif mode==802: OmsWt89dSA5HyCZ4wL = vloIZHenE7imycDM2tPQ(url)
	elif mode==803: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==804: OmsWt89dSA5HyCZ4wL = wphD0TcF1azLx7y3iWtXCqkR4sUB(url)
	elif mode==806: OmsWt89dSA5HyCZ4wL = VNPHFcK5wvfL67Roir0Y(url,jmI9qRnVJo2a3tpcH8gfYkP)
	elif mode==809: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,809,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فلتر',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/trending',804,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBEST4-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('nav-categories(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			if any(value in title for value in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o): continue
			if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,801)
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('mainContent(.*?)<footer>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('mainTitle.*?href="(.*?)".*?title="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			if any(value in title for value in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o): continue
			if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,801,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'mainmenu')
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('main-menu(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			if any(value in title for value in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o): continue
			if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,801)
	return FGRX4myP68S
def VNPHFcK5wvfL67Roir0Y(url,type=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBEST4-SEASONS_EPISODES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('mainTitle.*?>(.*?)<(.*?)pageContent',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		CSX1FDkQOU,jbpHA8eDFYwlT,items = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,[]
		for name,wlJ6d8hEvpoMNSCmU in z6PX2p7diaskQElBOvMRNcHwqG5D:
			if 'حلقات' in name: jbpHA8eDFYwlT = wlJ6d8hEvpoMNSCmU
			if 'مواسم' in name: CSX1FDkQOU = wlJ6d8hEvpoMNSCmU
		if CSX1FDkQOU and not type:
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',CSX1FDkQOU,EcQxOa3RJm86WjTKA.DOTALL)
			if len(items)>1:
				for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
					OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,806,POjaBmHqzpsx1IYw7kQM4R,'season')
		if jbpHA8eDFYwlT and len(items)<2:
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',jbpHA8eDFYwlT,EcQxOa3RJm86WjTKA.DOTALL)
			if items:
				for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
					OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,803,POjaBmHqzpsx1IYw7kQM4R)
			else:
				items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)<',jbpHA8eDFYwlT,EcQxOa3RJm86WjTKA.DOTALL)
				for bigdh7fpZYl4aT2keV,title in items:
					OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,803)
	return
def HAsKeZdTbqjPI1WY(url,type=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	O0nkSFcZRm182p47v69tG,start,HE7eaGoC6ixPIzV93A,select,ecGZaqNkWl51i = 0,0,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if 'pagination' in type:
		E1P5aIno72p4MY,gWBLDSlZGwqxHT = url.split('?next=page&')
		naBFTDfp6lmKjeOywg87IAcb = {'Content-Type':'application/x-www-form-urlencoded'}
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'POST',E1P5aIno72p4MY,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBEST4-TITLES-1st')
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		soEymUvkt19PQXVjzKau6x5 = 'secContent'+FGRX4myP68S+'<footer>'
	else:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBEST4-TITLES-2nd')
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		soEymUvkt19PQXVjzKau6x5 = FGRX4myP68S
	items,FFvZ6iAMxpBE,p9UP6wGlC1BF7fN2 = [],False,False
	if not type and '/collections' not in url:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('mainContent(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?</i>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title in items:
				title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,801,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'submenu')
				FFvZ6iAMxpBE = True
	if not FFvZ6iAMxpBE:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('secContent(.*?)mainContent',soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
				bigdh7fpZYl4aT2keV = U2Z7CVFftTmLeK3nzEbQPGga(bigdh7fpZYl4aT2keV)
				POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R.strip(C0qrknitpM4Z)
				title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
				if '/series/' in bigdh7fpZYl4aT2keV and type=='season': OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,806,POjaBmHqzpsx1IYw7kQM4R,'season')
				elif '/series/' in bigdh7fpZYl4aT2keV: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,806,POjaBmHqzpsx1IYw7kQM4R)
				elif '/seasons/' in bigdh7fpZYl4aT2keV: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,801,POjaBmHqzpsx1IYw7kQM4R,'season')
				elif '/collections' in url: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,801,POjaBmHqzpsx1IYw7kQM4R,'collections')
				else: OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,803,POjaBmHqzpsx1IYw7kQM4R)
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('loadMoreParams = (.*?);',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			kJemADzFKdl = LB7TcZnGYdfw5lWU1RH3Oztu9PyA('dict',wlJ6d8hEvpoMNSCmU)
			ecGZaqNkWl51i = kJemADzFKdl['ajaxurl']
			RR6L0Hg8km2GPorNFwyD = int(kJemADzFKdl['current_page'])+1
			lzWPTuGKRpZtAI85d3yEmBfUYM = int(kJemADzFKdl['max_page'])
			d9d6coaYXDvRSbnE8pWGtz = kJemADzFKdl['posts'].replace('False','false').replace('True','true').replace('None','null')
			if RR6L0Hg8km2GPorNFwyD<lzWPTuGKRpZtAI85d3yEmBfUYM:
				gWBLDSlZGwqxHT = 'action=loadmore&query='+DVX5GWhnIxYlSd9rEuetjk40UJ(d9d6coaYXDvRSbnE8pWGtz,fy8iFgEkrO12NR9TWBI35sjY6qHvV)+'&page='+str(RR6L0Hg8km2GPorNFwyD)
				YLKFRH6sSIrznXBg = ecGZaqNkWl51i+'?next=page&'+gWBLDSlZGwqxHT
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'جلب المزيد',YLKFRH6sSIrznXBg,801,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'pagination_'+type)
		elif '?next=page&' in url:
			gWBLDSlZGwqxHT,BfYztCZvQdgx = gWBLDSlZGwqxHT.rsplit('=',1)
			BfYztCZvQdgx = int(BfYztCZvQdgx)+1
			YLKFRH6sSIrznXBg = E1P5aIno72p4MY+'?next=page&'+gWBLDSlZGwqxHT+'='+str(BfYztCZvQdgx)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'جلب المزيد',YLKFRH6sSIrznXBg,801,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'pagination_'+type)
	return
def wphD0TcF1azLx7y3iWtXCqkR4sUB(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBEST4-FILTERS-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('sub_nav(.*?)secContent ',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		VuGmoESTAfXlv5tD76PW1Masq0peB = EcQxOa3RJm86WjTKA.findall('"current_opt">(.*?)<(.*?)</div>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for name,wlJ6d8hEvpoMNSCmU in VuGmoESTAfXlv5tD76PW1Masq0peB:
			if 'التصنيف' in name: continue
			name = name.strip(ksJdoFWhxTz8Y2N7bOZE)
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,value in items:
				title = name+':  '+value
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,801,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filter')
	return
def rr7SfotkneX85Klup(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBEST4-PLAY-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	uuigJsvIZQ3tprnhxG = EcQxOa3RJm86WjTKA.findall('<td>التصنيف</td>.*?">(.*?)<',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if uuigJsvIZQ3tprnhxG and SYJvigbI3fts(BfWYUAnyg6eONLjiuE,url,uuigJsvIZQ3tprnhxG): return
	hFzEyHWOoRxG,jQkdt6rvnxW8 = [],[]
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall('postEmbed.*?src="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if bigdh7fpZYl4aT2keV:
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[0].replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		jQkdt6rvnxW8.append(bigdh7fpZYl4aT2keV)
		A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,'name')
		hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV+'?named='+A8ECQ0qwTRzPifOGW76FK35uUvhe+'__embed')
	eJtD9iTFz4S65QwKbG20B = EcQxOa3RJm86WjTKA.findall('vo_theme_dir.*?"(.*?)".*?"(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if eJtD9iTFz4S65QwKbG20B:
		ecGZaqNkWl51i,pl3chZdq7I = eJtD9iTFz4S65QwKbG20B[0]
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('postPlayer(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			evUXLICSWN80MqVOarButycb6wHP = EcQxOa3RJm86WjTKA.findall('<li.*?id\,(.*?)\);">(.*?)</li>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for VsX4ocOQugkCKfjISaZ,name in evUXLICSWN80MqVOarButycb6wHP:
				bigdh7fpZYl4aT2keV = ecGZaqNkWl51i+'/temp/ajax/iframe.php?id='+pl3chZdq7I+'&video='+VsX4ocOQugkCKfjISaZ
				hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV+'?named='+name+'__watch')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('pageContentDown(.*?)</table>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('<tr>.*?<td>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</td>.*?href="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for OOnVxtP0TNWsci6HrEGqBm9boKF7g,bigdh7fpZYl4aT2keV in items:
			if bigdh7fpZYl4aT2keV not in jQkdt6rvnxW8:
				if '/?url=' in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.split('/?url=')[1]
				jQkdt6rvnxW8.append(bigdh7fpZYl4aT2keV)
				A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,'name')
				hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV+'?named='+A8ECQ0qwTRzPifOGW76FK35uUvhe+'__download____'+OOnVxtP0TNWsci6HrEGqBm9boKF7g)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(hFzEyHWOoRxG,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if not search: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if not search: return
	CE6HW2phYix9XvVdfqe1ObQIFl5mMj = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/?s='+CE6HW2phYix9XvVdfqe1ObQIFl5mMj
	HAsKeZdTbqjPI1WY(url,'search')
	return
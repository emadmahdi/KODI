# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'FASELHD2'
headers = {'User-Agent':fy8iFgEkrO12NR9TWBI35sjY6qHvV}
K2l9rLfvoXxyZ4NYapO = '_FH2_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['wwe']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==590: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==591: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,text)
	elif mode==592: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==593: OmsWt89dSA5HyCZ4wL = VNPHFcK5wvfL67Roir0Y(url,text)
	elif mode==599: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = BOI3t1w8qfHAb0Kl4oMye7haEWS
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FASELHD2-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ,599,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'المميزة',VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ,591,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'featured1')
	items = EcQxOa3RJm86WjTKA.findall('<strong>(.*?)</strong>.*?href="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	for title,bigdh7fpZYl4aT2keV in items:
		OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,591,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'details1')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('main-menu"(.*?)header-social',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		acnd3zbICVLtm2JFvWhforQ = EcQxOa3RJm86WjTKA.findall('<li (.*?)</li>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for ffqUAI9tudHkKSblEYv30aJjo in acnd3zbICVLtm2JFvWhforQ:
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)<',ffqUAI9tudHkKSblEYv30aJjo,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title in items:
				if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+bigdh7fpZYl4aT2keV
				OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,591,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'details2')
	return FGRX4myP68S
def HAsKeZdTbqjPI1WY(url,type=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FASELHD2-TITLES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	SqJZbjNiXldG = 0
	UgbWFLzrCA5RMo7tjwNmdyc68khBGn = EcQxOa3RJm86WjTKA.findall('"archive-slider(.*?)<h4>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if UgbWFLzrCA5RMo7tjwNmdyc68khBGn: OOCx0SzAcisQIJGM6DZkopvB3 = UgbWFLzrCA5RMo7tjwNmdyc68khBGn[0]
	else: OOCx0SzAcisQIJGM6DZkopvB3 = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if type=='featured1':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"slider-carousel"(.*?)</container>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall(' src="(.*?)".*?"slider-title">(.*?)<.*?<a href="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		SnPHJ6yl8Yr1EwTtbpNB7QMIDmg4oz,p7Gkego0m6a8,zzECVswWcGAIXhrQlZ7jMokugnv = zip(*items)
		items = zip(zzECVswWcGAIXhrQlZ7jMokugnv,SnPHJ6yl8Yr1EwTtbpNB7QMIDmg4oz,p7Gkego0m6a8)
	elif type=='featured2':
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',OOCx0SzAcisQIJGM6DZkopvB3,EcQxOa3RJm86WjTKA.DOTALL)
	elif type=='filters':
		z6PX2p7diaskQElBOvMRNcHwqG5D = [FGRX4myP68S.replace('\\/','/').replace('\\"','"')]
	elif type=='details2' and 'href' in OOCx0SzAcisQIJGM6DZkopvB3:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('<h4>(.*?)</h4>(.*?)</container>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مميزة',url,591,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'featured2')
		title = z6PX2p7diaskQElBOvMRNcHwqG5D[0][0]
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,591,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'details3')
		return
	else:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('<h4>(.*?)</h4>(.*?)</container>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		title,wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	mmO39lwp0LFUrVT = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	cmDaLEqWlT7GhonIdX5k1zHQjSiupe = []
	for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
		if any(value in title.lower() for value in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o): continue
		title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
		title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
		RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) (الحلقة|حلقة).\d+',title,EcQxOa3RJm86WjTKA.DOTALL)
		if '/movseries/' in bigdh7fpZYl4aT2keV:
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,591,POjaBmHqzpsx1IYw7kQM4R)
		elif RrzpbE3t9woCk7MXS0GvNdi1BcV and type==fy8iFgEkrO12NR9TWBI35sjY6qHvV:
			title = '_MOD_'+RrzpbE3t9woCk7MXS0GvNdi1BcV[0][0]
			if title not in cmDaLEqWlT7GhonIdX5k1zHQjSiupe:
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,593,POjaBmHqzpsx1IYw7kQM4R)
				cmDaLEqWlT7GhonIdX5k1zHQjSiupe.append(title)
		elif any(value in title for value in mmO39lwp0LFUrVT):
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,592,POjaBmHqzpsx1IYw7kQM4R)
		else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,593,POjaBmHqzpsx1IYw7kQM4R)
	if type=='filters':
		RR6L0Hg8km2GPorNFwyD = EcQxOa3RJm86WjTKA.findall('"more_button_page":(.*?),',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if RR6L0Hg8km2GPorNFwyD:
			count = RR6L0Hg8km2GPorNFwyD[0]
			bigdh7fpZYl4aT2keV = url+'/offset/'+count
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة أخرى',bigdh7fpZYl4aT2keV,591,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filters')
	elif 'details' in type:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="pagination(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title in items:
				title = 'صفحة '+IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,591,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'details4')
	return
def VNPHFcK5wvfL67Roir0Y(url,type=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FASELHD2-SEASONS_EPISODES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	CSX1FDkQOU = False
	if not type:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('<seasons(.*?)</seasons>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3>(.*?)</h3>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			if len(items)>1:
				VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = VbHeOuU1ilzSp2ZRXwBD(url,'url')
				CSX1FDkQOU = True
				for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
					title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
					OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,593,POjaBmHqzpsx1IYw7kQM4R,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'episodes')
	if type=='episodes' or not CSX1FDkQOU:
		mmEsSwOKazXLV1MT = EcQxOa3RJm86WjTKA.findall('<bkز*?image:url\((.*?)\)"></bk>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if mmEsSwOKazXLV1MT: POjaBmHqzpsx1IYw7kQM4R = mmEsSwOKazXLV1MT[0]
		else: POjaBmHqzpsx1IYw7kQM4R = fy8iFgEkrO12NR9TWBI35sjY6qHvV
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('<all-episodes(.*?)</all-episodes>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title in items:
				title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
				title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
				OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,592,POjaBmHqzpsx1IYw7kQM4R)
	return
def rr7SfotkneX85Klup(url):
	hFzEyHWOoRxG,NRBhjC91QHlmcqp6KwgntE,kENjB56TStKh = [],[],[]
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FASELHD2-PLAY-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	AUE2IHWYJZ = EcQxOa3RJm86WjTKA.findall('العمر :.*?<strong">(.*?)</strong>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if AUE2IHWYJZ and SYJvigbI3fts(BfWYUAnyg6eONLjiuE,url,AUE2IHWYJZ): return
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall('<iframe src="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if bigdh7fpZYl4aT2keV:
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[0]
		hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV+'?named=__embed')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('<slice-title(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('data-url="(.*?)".*?</i>(.*?)</li>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,name in items:
			name = name.strip(ksJdoFWhxTz8Y2N7bOZE)
			hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV+'?named='+name+'__watch')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('<downloads(.*?)</downloads>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?</div>(.*?)</div>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,name in items:
			hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV+'?named='+name+'__download')
	for Z5Zl8LgtDFrJKOsnzXxc4f1UpN in hFzEyHWOoRxG:
		bigdh7fpZYl4aT2keV,name = Z5Zl8LgtDFrJKOsnzXxc4f1UpN.split('?named')
		if bigdh7fpZYl4aT2keV not in NRBhjC91QHlmcqp6KwgntE:
			NRBhjC91QHlmcqp6KwgntE.append(bigdh7fpZYl4aT2keV)
			kENjB56TStKh.append(Z5Zl8LgtDFrJKOsnzXxc4f1UpN)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(kENjB56TStKh,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = BOI3t1w8qfHAb0Kl4oMye7haEWS
	url = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/?s='+search
	HAsKeZdTbqjPI1WY(url,'details5')
	return
# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'ALMSTBA'
K2l9rLfvoXxyZ4NYapO = '_MST_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['الرئيسية','يلا شوت']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==860: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==861: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,text)
	elif mode==862: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==863: OmsWt89dSA5HyCZ4wL = bv4IDSyw6zuC3pR1lYd75(url,text)
	elif mode==869: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ALMSTBA-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,869,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"primary-links"(.*?)</u',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?<span>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if title in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,861)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"list-categories"(.*?)<script',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+bigdh7fpZYl4aT2keV.lstrip('/')
			if title in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,861)
	return
def HAsKeZdTbqjPI1WY(url,HE7eaGoC6ixPIzV93A=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ALMSTBA-TITLES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"home-content"(.*?)"footer"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		wlJ6d8hEvpoMNSCmU = wlJ6d8hEvpoMNSCmU.replace('"overlay"','"duration"><')
		items = EcQxOa3RJm86WjTKA.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		cmDaLEqWlT7GhonIdX5k1zHQjSiupe = []
		for POjaBmHqzpsx1IYw7kQM4R,rQ0jN7XkZPE1AYU,bigdh7fpZYl4aT2keV,title in items:
			title = title.strip(' ')
			title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
			RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) (الحلقة|حلقة).\d+',title,EcQxOa3RJm86WjTKA.DOTALL)
			if 'episodes' not in HE7eaGoC6ixPIzV93A and RrzpbE3t9woCk7MXS0GvNdi1BcV:
				title = '_MOD_' + RrzpbE3t9woCk7MXS0GvNdi1BcV[0][0]
				title = title.replace('اون لاين',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
				if title not in cmDaLEqWlT7GhonIdX5k1zHQjSiupe:
					OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,863,POjaBmHqzpsx1IYw7kQM4R)
					cmDaLEqWlT7GhonIdX5k1zHQjSiupe.append(title)
			else: OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,862,POjaBmHqzpsx1IYw7kQM4R,rQ0jN7XkZPE1AYU)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('''["']pagination["'](.*?)["']footer["']''',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		HE7eaGoC6ixPIzV93A = 'episodes_pages' if 'episodes' in HE7eaGoC6ixPIzV93A else 'pages'
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,861,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,HE7eaGoC6ixPIzV93A)
	else:
		FxeZ4OmdfyS6jLVuowUGKClJXqhat8 = EcQxOa3RJm86WjTKA.findall('class="pagination__next.*?href="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if FxeZ4OmdfyS6jLVuowUGKClJXqhat8:
			bigdh7fpZYl4aT2keV = FxeZ4OmdfyS6jLVuowUGKClJXqhat8[0]
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة لاحقة',bigdh7fpZYl4aT2keV,861,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,HE7eaGoC6ixPIzV93A)
	return
def bv4IDSyw6zuC3pR1lYd75(url,LLMYeXiaVDT9HAnUz87FOv):
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = VbHeOuU1ilzSp2ZRXwBD(url,'url')
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ALMSTBA-EPISODES_SEASONS-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	y4IYUHTpSs8DXEfajQLvWb0g1G = EcQxOa3RJm86WjTKA.findall('"episodes-container"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	mmEsSwOKazXLV1MT = EcQxOa3RJm86WjTKA.findall('"thumbnailUrl":"(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	POjaBmHqzpsx1IYw7kQM4R = mmEsSwOKazXLV1MT[0] if mmEsSwOKazXLV1MT else fy8iFgEkrO12NR9TWBI35sjY6qHvV
	POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R.replace('\/','/')
	POjaBmHqzpsx1IYw7kQM4R += '|Referer='+BOI3t1w8qfHAb0Kl4oMye7haEWS
	items = []
	LNrR4g0f1KPVGsU76QqE = False
	if y4IYUHTpSs8DXEfajQLvWb0g1G and not LLMYeXiaVDT9HAnUz87FOv:
		wlJ6d8hEvpoMNSCmU = y4IYUHTpSs8DXEfajQLvWb0g1G[0]
		items = EcQxOa3RJm86WjTKA.findall('data-tab="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for LLMYeXiaVDT9HAnUz87FOv,title in items:
			LLMYeXiaVDT9HAnUz87FOv = LLMYeXiaVDT9HAnUz87FOv.strip('#')
			if len(items)>1: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,863,POjaBmHqzpsx1IYw7kQM4R,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LLMYeXiaVDT9HAnUz87FOv)
			else: LNrR4g0f1KPVGsU76QqE = True
	else: LNrR4g0f1KPVGsU76QqE = True
	if LNrR4g0f1KPVGsU76QqE or not LLMYeXiaVDT9HAnUz87FOv:
		if not LLMYeXiaVDT9HAnUz87FOv: UgbWFLzrCA5RMo7tjwNmdyc68khBGn = EcQxOa3RJm86WjTKA.findall('"tab-content.*?id="(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		else: UgbWFLzrCA5RMo7tjwNmdyc68khBGn = EcQxOa3RJm86WjTKA.findall('"tab-content.*?id="'+LLMYeXiaVDT9HAnUz87FOv+'"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if UgbWFLzrCA5RMo7tjwNmdyc68khBGn:
			wlJ6d8hEvpoMNSCmU = UgbWFLzrCA5RMo7tjwNmdyc68khBGn[0]
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)" title="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title in items:
				if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/'+bigdh7fpZYl4aT2keV.strip('./')
				title = title.replace('</em><span>',ksJdoFWhxTz8Y2N7bOZE)
				OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,862,POjaBmHqzpsx1IYw7kQM4R)
	return
def rr7SfotkneX85Klup(url):
	hFzEyHWOoRxG,CXTL7NPUAE = [],[]
	YLKFRH6sSIrznXBg = url.strip('/')+'/?do=watch'
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ALMSTBA-PLAY-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall('iframe src="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if bigdh7fpZYl4aT2keV:
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[0]
		CXTL7NPUAE.append(bigdh7fpZYl4aT2keV)
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',bigdh7fpZYl4aT2keV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ALMSTBA-PLAY-2nd')
		soEymUvkt19PQXVjzKau6x5 = E6ECvznP9m5sWFMu.content
		R9b8gUvoB4wOfkTIjlEsZrM5LtinpS = EcQxOa3RJm86WjTKA.findall('iframe src="(.*?)"',soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
		R9b8gUvoB4wOfkTIjlEsZrM5LtinpS = R9b8gUvoB4wOfkTIjlEsZrM5LtinpS[0] if R9b8gUvoB4wOfkTIjlEsZrM5LtinpS else bigdh7fpZYl4aT2keV
		if R9b8gUvoB4wOfkTIjlEsZrM5LtinpS not in CXTL7NPUAE:
			CXTL7NPUAE.append(R9b8gUvoB4wOfkTIjlEsZrM5LtinpS)
			A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(R9b8gUvoB4wOfkTIjlEsZrM5LtinpS,'name')
			R9b8gUvoB4wOfkTIjlEsZrM5LtinpS = R9b8gUvoB4wOfkTIjlEsZrM5LtinpS+'?named='+A8ECQ0qwTRzPifOGW76FK35uUvhe+'__embed'
			hFzEyHWOoRxG.append(R9b8gUvoB4wOfkTIjlEsZrM5LtinpS)
	headers = {'Referer':url}
	zVd04D3liIfSUhNRnKgF = EcQxOa3RJm86WjTKA.findall('post_id:(\d+)',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	SSFVoALT7WtIhbRmYC6HwDuesB = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/wp-admin/admin-ajax.php?action=video_info&post_id='+zVd04D3liIfSUhNRnKgF[0]
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',SSFVoALT7WtIhbRmYC6HwDuesB,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ALMSTBA-PLAY-3rd')
	soEymUvkt19PQXVjzKau6x5 = E6ECvznP9m5sWFMu.content
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall('"src":"(.*?)"',soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
	if bigdh7fpZYl4aT2keV:
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[0]
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.replace('\/','/')
		if bigdh7fpZYl4aT2keV not in CXTL7NPUAE:
			CXTL7NPUAE.append(bigdh7fpZYl4aT2keV)
			A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,'name')
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+A8ECQ0qwTRzPifOGW76FK35uUvhe+'__watch'
			hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall('"Download" target="_blank" href="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if bigdh7fpZYl4aT2keV:
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[0]
		if bigdh7fpZYl4aT2keV not in CXTL7NPUAE:
			CXTL7NPUAE.append(bigdh7fpZYl4aT2keV)
			A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,'name')
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+A8ECQ0qwTRzPifOGW76FK35uUvhe+'__download'
			hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(hFzEyHWOoRxG,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/?s='+search
	HAsKeZdTbqjPI1WY(url,'search')
	return
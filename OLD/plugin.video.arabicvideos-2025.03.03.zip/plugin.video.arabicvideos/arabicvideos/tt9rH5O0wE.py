# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
headers = { 'User-Agent' : fy8iFgEkrO12NR9TWBI35sjY6qHvV }
BfWYUAnyg6eONLjiuE = 'AKWAM'
K2l9rLfvoXxyZ4NYapO = '_AKW_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
mVKSzuhl5wcir = fy8iFgEkrO12NR9TWBI35sjY6qHvV
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==240: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==241: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,text)
	elif mode==242: OmsWt89dSA5HyCZ4wL = eQgbVPaIBvTn8fsjJRt241(url)
	elif mode==243: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==244: OmsWt89dSA5HyCZ4wL = F4ehkvPDxXU(url,'FILTERS___'+text)
	elif mode==245: OmsWt89dSA5HyCZ4wL = F4ehkvPDxXU(url,'CATEGORIES___'+text)
	elif mode==246: OmsWt89dSA5HyCZ4wL = VxL5HJnq2MC7KW6NUEQe80BPD1T(url)
	elif mode==247: OmsWt89dSA5HyCZ4wL = NS2PVUnHopQqhfl5x(url)
	elif mode==248: OmsWt89dSA5HyCZ4wL = nWkfKMQOobz5CZrt9DlU87c0upJAj4()
	elif mode==249: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def nWkfKMQOobz5CZrt9DlU87c0upJAj4():
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'AKWAM-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	nwe7LrDGSI5FvU = EcQxOa3RJm86WjTKA.findall('home-site-btn-container.*?href="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if nwe7LrDGSI5FvU: nwe7LrDGSI5FvU = nwe7LrDGSI5FvU[0]
	else: nwe7LrDGSI5FvU = BOI3t1w8qfHAb0Kl4oMye7haEWS
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',nwe7LrDGSI5FvU,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'AKWAM-MENU-2nd')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,249,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فلتر محدد',BOI3t1w8qfHAb0Kl4oMye7haEWS,246)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فلتر كامل',BOI3t1w8qfHAb0Kl4oMye7haEWS,247)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'المميزة',nwe7LrDGSI5FvU,241,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'featured')
	recent = EcQxOa3RJm86WjTKA.findall('recently-container.*?href="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	bigdh7fpZYl4aT2keV = recent[0]
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'أضيف حديثا',bigdh7fpZYl4aT2keV,241)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,name,wlJ6d8hEvpoMNSCmU in z6PX2p7diaskQElBOvMRNcHwqG5D:
		if name in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
		OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+name,bigdh7fpZYl4aT2keV,241)
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if title in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
			title = name+ksJdoFWhxTz8Y2N7bOZE+title
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,241)
	return
def VxL5HJnq2MC7KW6NUEQe80BPD1T(website=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'AKWAM-MENU-1st')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="menu(.*?)<nav',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?text">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if title not in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o:
				title = title+' مصنفة'
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,245)
		if website==fy8iFgEkrO12NR9TWBI35sjY6qHvV: OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	return FGRX4myP68S
def NS2PVUnHopQqhfl5x(website=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'AKWAM-MENU-1st')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="menu(.*?)<nav',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?text">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if title not in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o:
				title = title+' مفلترة'
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,244)
		if website==fy8iFgEkrO12NR9TWBI35sjY6qHvV: OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	return FGRX4myP68S
def HAsKeZdTbqjPI1WY(url,type=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,True,'AKWAM-TITLES-1st')
	if type=='featured': z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('swiper-container(.*?)swiper-button-prev',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	else: z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="widget"(.*?)main-footer',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if not items:
			items = EcQxOa3RJm86WjTKA.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for POjaBmHqzpsx1IYw7kQM4R,bigdh7fpZYl4aT2keV,title in items:
			if '/series/' in bigdh7fpZYl4aT2keV or '/shows/' in bigdh7fpZYl4aT2keV:
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,242,POjaBmHqzpsx1IYw7kQM4R)
			elif '/movies/' in bigdh7fpZYl4aT2keV:
				OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,243,POjaBmHqzpsx1IYw7kQM4R)
			elif '/games/' not in bigdh7fpZYl4aT2keV:
				OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,243,POjaBmHqzpsx1IYw7kQM4R)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('pagination(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			bigdh7fpZYl4aT2keV = IVcCL3aAfU9wS7kWev1g2XBjZRJ(bigdh7fpZYl4aT2keV)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,241)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	CE6HW2phYix9XvVdfqe1ObQIFl5mMj = search.replace(ksJdoFWhxTz8Y2N7bOZE,'%20')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS + '/search?q='+CE6HW2phYix9XvVdfqe1ObQIFl5mMj
	OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url)
	return
def eQgbVPaIBvTn8fsjJRt241(url):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in FGRX4myP68S:
		POjaBmHqzpsx1IYw7kQM4R = bEWpDHXjCBqd7aOiN6UG5k.getInfoLabel('ListItem.Icon')
		OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+'رابط التشغيل',url,243,POjaBmHqzpsx1IYw7kQM4R)
	else:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('-episodes">(.*?)<div class="widget-4',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		jbpHA8eDFYwlT = EcQxOa3RJm86WjTKA.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title,POjaBmHqzpsx1IYw7kQM4R in jbpHA8eDFYwlT:
			title = title.replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE)
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in bigdh7fpZYl4aT2keV: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,242,POjaBmHqzpsx1IYw7kQM4R)
			else: OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,243,POjaBmHqzpsx1IYw7kQM4R)
	return
def rr7SfotkneX85Klup(url):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,True,'AKWAM-PLAY-1st')
	uuigJsvIZQ3tprnhxG = EcQxOa3RJm86WjTKA.findall('badge-danger.*?>(.*?)<',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if uuigJsvIZQ3tprnhxG and SYJvigbI3fts(BfWYUAnyg6eONLjiuE,url,uuigJsvIZQ3tprnhxG): return
	cF7ZvJgUs4Yn81zuXto6xlEjV = EcQxOa3RJm86WjTKA.findall('li><a href="#(.*?)".*?>(.*?)<',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	XoSyx7p6dqZ1CF8,WFlpmsYGKNy,VuGmoESTAfXlv5tD76PW1Masq0peB,UNmH69GWEsQwcFeI8RLpg = [],[],[],[]
	if cF7ZvJgUs4Yn81zuXto6xlEjV:
		BIbU1q2NrFX = 'mp4'
		for lPutL0Q6UiykHZAE,OOnVxtP0TNWsci6HrEGqBm9boKF7g in cF7ZvJgUs4Yn81zuXto6xlEjV:
			z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('tab-content quality" id="'+lPutL0Q6UiykHZAE+'".*?</div>.\s*</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			VuGmoESTAfXlv5tD76PW1Masq0peB.append(wlJ6d8hEvpoMNSCmU)
			UNmH69GWEsQwcFeI8RLpg.append(OOnVxtP0TNWsci6HrEGqBm9boKF7g)
	else:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="qualities(.*?)<h3.*?>(.*?)<',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if not z6PX2p7diaskQElBOvMRNcHwqG5D:
			GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			wlJ6d8hEvpoMNSCmU,filename = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			RQBHPosn4XjYKhvZCOJtVMm = ['zip','rar','txt','pdf','htm','tar','iso','html']
			BIbU1q2NrFX = filename.rsplit('.',1)[1].strip(ksJdoFWhxTz8Y2N7bOZE)
			if BIbU1q2NrFX in RQBHPosn4XjYKhvZCOJtVMm:
				GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','الملف ليس فيديو ولا صوت')
				return
		VuGmoESTAfXlv5tD76PW1Masq0peB.append(wlJ6d8hEvpoMNSCmU)
		UNmH69GWEsQwcFeI8RLpg.append(fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	for pk6YWixXFSrDLKCnlN39w in range(len(VuGmoESTAfXlv5tD76PW1Masq0peB)):
		zzECVswWcGAIXhrQlZ7jMokugnv = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?icon-(.*?)"',VuGmoESTAfXlv5tD76PW1Masq0peB[pk6YWixXFSrDLKCnlN39w],EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,K9jgWLioE0s5mP in zzECVswWcGAIXhrQlZ7jMokugnv:
			if 'torrent' in K9jgWLioE0s5mP: continue
			elif 'download' in K9jgWLioE0s5mP: type = 'download'
			elif 'play' in K9jgWLioE0s5mP: type = 'watch'
			else: type = 'unknown'
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named=__'+type+'____'+UNmH69GWEsQwcFeI8RLpg[pk6YWixXFSrDLKCnlN39w]+'__akwam'
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(XoSyx7p6dqZ1CF8,BfWYUAnyg6eONLjiuE,'video',url)
	return
def F4ehkvPDxXU(url,filter):
	ffJIco45MG9kFntgWDwqyR = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==fy8iFgEkrO12NR9TWBI35sjY6qHvV: NnQ1hEsTV7Zaz3HKdfu,QlOXcH07nRVPAZub8pD356xMvdk4 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	else: NnQ1hEsTV7Zaz3HKdfu,QlOXcH07nRVPAZub8pD356xMvdk4 = filter.split('___')
	if type=='CATEGORIES':
		if ffJIco45MG9kFntgWDwqyR[0]+'=' not in NnQ1hEsTV7Zaz3HKdfu: fnogyzNA30JCPMYqHTavG7ZKp = ffJIco45MG9kFntgWDwqyR[0]
		for pk6YWixXFSrDLKCnlN39w in range(len(ffJIco45MG9kFntgWDwqyR[0:-1])):
			if ffJIco45MG9kFntgWDwqyR[pk6YWixXFSrDLKCnlN39w]+'=' in NnQ1hEsTV7Zaz3HKdfu: fnogyzNA30JCPMYqHTavG7ZKp = ffJIco45MG9kFntgWDwqyR[pk6YWixXFSrDLKCnlN39w+1]
		z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&'+fnogyzNA30JCPMYqHTavG7ZKp+'=0'
		ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&'+fnogyzNA30JCPMYqHTavG7ZKp+'=0'
		HfvJenZmN3O8rPcshLux2EyzDWpQCb = z7VI1OaUPqs4lXxb.strip('&')+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq.strip('&')
		F231lsuCKnaSMdQ48W6PoL = nKT1QuLoXPc8CjyV(QlOXcH07nRVPAZub8pD356xMvdk4,'all')
		YLKFRH6sSIrznXBg = url+'?'+F231lsuCKnaSMdQ48W6PoL
	elif type=='FILTERS':
		QUFL2gEBMn63qlsmI7W = nKT1QuLoXPc8CjyV(NnQ1hEsTV7Zaz3HKdfu,'modified_values')
		QUFL2gEBMn63qlsmI7W = U2Z7CVFftTmLeK3nzEbQPGga(QUFL2gEBMn63qlsmI7W)
		if QlOXcH07nRVPAZub8pD356xMvdk4!=fy8iFgEkrO12NR9TWBI35sjY6qHvV: QlOXcH07nRVPAZub8pD356xMvdk4 = nKT1QuLoXPc8CjyV(QlOXcH07nRVPAZub8pD356xMvdk4,'all')
		if QlOXcH07nRVPAZub8pD356xMvdk4==fy8iFgEkrO12NR9TWBI35sjY6qHvV: YLKFRH6sSIrznXBg = url
		else: YLKFRH6sSIrznXBg = url+'?'+QlOXcH07nRVPAZub8pD356xMvdk4
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'أظهار قائمة الفيديو التي تم اختيارها',YLKFRH6sSIrznXBg,241,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1')
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+' [[   '+QUFL2gEBMn63qlsmI7W+'   ]]',YLKFRH6sSIrznXBg,241,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1')
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,True,'AKWAM-FILTERS_MENU-1st')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('<form id(.*?)</form>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	W1A4L5P0Zc8wHnUGjVexElz = EcQxOa3RJm86WjTKA.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	dict = {}
	for jLA9nhxoZbG,name,wlJ6d8hEvpoMNSCmU in W1A4L5P0Zc8wHnUGjVexElz:
		items = EcQxOa3RJm86WjTKA.findall('<option(.*?)>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if '=' not in YLKFRH6sSIrznXBg: YLKFRH6sSIrznXBg = url
		if type=='CATEGORIES':
			if fnogyzNA30JCPMYqHTavG7ZKp!=jLA9nhxoZbG: continue
			elif len(items)<=1:
				if jLA9nhxoZbG==ffJIco45MG9kFntgWDwqyR[-1]: HAsKeZdTbqjPI1WY(YLKFRH6sSIrznXBg)
				else: F4ehkvPDxXU(YLKFRH6sSIrznXBg,'CATEGORIES___'+HfvJenZmN3O8rPcshLux2EyzDWpQCb)
				return
			else:
				if jLA9nhxoZbG==ffJIco45MG9kFntgWDwqyR[-1]: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع',YLKFRH6sSIrznXBg,241,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1')
				else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع',YLKFRH6sSIrznXBg,245,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,HfvJenZmN3O8rPcshLux2EyzDWpQCb)
		elif type=='FILTERS':
			z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&'+jLA9nhxoZbG+'=0'
			ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&'+jLA9nhxoZbG+'=0'
			HfvJenZmN3O8rPcshLux2EyzDWpQCb = z7VI1OaUPqs4lXxb+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع : '+name,YLKFRH6sSIrznXBg,244,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,HfvJenZmN3O8rPcshLux2EyzDWpQCb)
		dict[jLA9nhxoZbG] = {}
		for value,srR9AuG6Pf8powqU4ixL5Ecl in items:
			if srR9AuG6Pf8powqU4ixL5Ecl in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
			if 'value' not in value: value = srR9AuG6Pf8powqU4ixL5Ecl
			else: value = EcQxOa3RJm86WjTKA.findall('"(.*?)"',value,EcQxOa3RJm86WjTKA.DOTALL)[0]
			dict[jLA9nhxoZbG][value] = srR9AuG6Pf8powqU4ixL5Ecl
			z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&'+jLA9nhxoZbG+'='+srR9AuG6Pf8powqU4ixL5Ecl
			ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&'+jLA9nhxoZbG+'='+value
			QdzUcX2iR5 = z7VI1OaUPqs4lXxb+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq
			title = srR9AuG6Pf8powqU4ixL5Ecl+' : '#+dict[jLA9nhxoZbG]['0']
			title = srR9AuG6Pf8powqU4ixL5Ecl+' : '+name
			if type=='FILTERS': OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,244,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QdzUcX2iR5)
			elif type=='CATEGORIES' and ffJIco45MG9kFntgWDwqyR[-2]+'=' in NnQ1hEsTV7Zaz3HKdfu:
				F231lsuCKnaSMdQ48W6PoL = nKT1QuLoXPc8CjyV(ybEUMsLp4zBVPnuAYI0cCdowekDq,'all')
				MYWwFs7XA2 = url+'?'+F231lsuCKnaSMdQ48W6PoL
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,MYWwFs7XA2,241,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1')
			else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,245,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QdzUcX2iR5)
	return
def nKT1QuLoXPc8CjyV(p9UP6wGlC1BF7fN2,mode):
	p9UP6wGlC1BF7fN2 = p9UP6wGlC1BF7fN2.strip('&')
	vpLWbVm35iM0l2TzYIN7 = {}
	if '=' in p9UP6wGlC1BF7fN2:
		items = p9UP6wGlC1BF7fN2.split('&')
		for j25T6eKhaMk3 in items:
			XJRx6urSNaOM5AfZdDsgQBYGt,value = j25T6eKhaMk3.split('=')
			vpLWbVm35iM0l2TzYIN7[XJRx6urSNaOM5AfZdDsgQBYGt] = value
	MKJaIb2sDSr4VCQGTqyX3nkWL = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	nohzWuNjPvp0MA = ['section','category','rating','year','language','formats','quality']
	for key in nohzWuNjPvp0MA:
		if key in list(vpLWbVm35iM0l2TzYIN7.keys()): value = vpLWbVm35iM0l2TzYIN7[key]
		else: value = '0'
		if mode=='modified_values' and value!='0': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+' + '+value
		elif mode=='modified_filters' and value!='0': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+'&'+key+'='+value
		elif mode=='all': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+'&'+key+'='+value
	MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL.strip(' + ')
	MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL.strip('&')
	return MKJaIb2sDSr4VCQGTqyX3nkWL
# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'WECIMA1'
K2l9rLfvoXxyZ4NYapO = '_WC1_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['مصارعة حرة','wwe']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==560: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==561: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,text)
	elif mode==562: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==563: OmsWt89dSA5HyCZ4wL = eQgbVPaIBvTn8fsjJRt241(url,text)
	elif mode==564: OmsWt89dSA5HyCZ4wL = F4ehkvPDxXU(url,'CATEGORIES___'+text)
	elif mode==565: OmsWt89dSA5HyCZ4wL = F4ehkvPDxXU(url,'FILTERS___'+text)
	elif mode==566: OmsWt89dSA5HyCZ4wL = vloIZHenE7imycDM2tPQ(url)
	elif mode==569: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text,url)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',BOI3t1w8qfHAb0Kl4oMye7haEWS,569,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فلتر محدد',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/AjaxCenter/RightBar',564)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فلتر كامل',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/AjaxCenter/RightBar',565)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'WECIMA1-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="NavigationMenu"(.*?)class="ProductionsListButton"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('class="menu-item.*?href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if title==fy8iFgEkrO12NR9TWBI35sjY6qHvV: continue
			if any(value in title.lower() for value in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o): continue
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,566)
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('hoverable activable(.*?)hoverable activable',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?url\((.*?)\).*?span>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,566,POjaBmHqzpsx1IYw7kQM4R)
	return FGRX4myP68S
def vloIZHenE7imycDM2tPQ(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'WECIMA1-SUBMENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	if 'class="Slider--Grid"' in FGRX4myP68S:
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'المميزة',url,561,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'featured')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="list--Tabsui"(.*?)div',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?i>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,561)
	return
def HAsKeZdTbqjPI1WY(bbiTzdsmeaKpv,type=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if '::' in bbiTzdsmeaKpv:
		MYWwFs7XA2,url = bbiTzdsmeaKpv.split('::')
		A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(MYWwFs7XA2,'url')
		url = A8ECQ0qwTRzPifOGW76FK35uUvhe+url
	else: url,MYWwFs7XA2 = bbiTzdsmeaKpv,bbiTzdsmeaKpv
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'WECIMA1-TITLES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	if type=='featured':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="Slider--Grid"(.*?)class="list--Tabsui"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	elif type in ['filters','search']:
		z6PX2p7diaskQElBOvMRNcHwqG5D = [FGRX4myP68S.replace('\\/','/').replace('\\"','"')]
	else:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"Grid--WecimaPosts"(.*?)"RightUI"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	cmDaLEqWlT7GhonIdX5k1zHQjSiupe = []
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('"Thumb--GridItem".*?href="(.*?)" title="(.*?)".*?url\((.*?)\)',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title,POjaBmHqzpsx1IYw7kQM4R in items:
			if any(value in title.lower() for value in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o): continue
			POjaBmHqzpsx1IYw7kQM4R = XXcPiylRDh6IapYA25rwO8u(POjaBmHqzpsx1IYw7kQM4R)
			bigdh7fpZYl4aT2keV = XXcPiylRDh6IapYA25rwO8u(bigdh7fpZYl4aT2keV)
			title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
			title = XXcPiylRDh6IapYA25rwO8u(title)
			title = title.replace('مشاهدة ',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			if '/series/' in bigdh7fpZYl4aT2keV: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,563,POjaBmHqzpsx1IYw7kQM4R)
			elif 'حلقة' in title:
				RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) +حلقة +\d+',title,EcQxOa3RJm86WjTKA.DOTALL)
				if RrzpbE3t9woCk7MXS0GvNdi1BcV: title = '_MOD_' + RrzpbE3t9woCk7MXS0GvNdi1BcV[0]
				if title not in cmDaLEqWlT7GhonIdX5k1zHQjSiupe:
					cmDaLEqWlT7GhonIdX5k1zHQjSiupe.append(title)
					OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,563,POjaBmHqzpsx1IYw7kQM4R)
			else:
				OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,562,POjaBmHqzpsx1IYw7kQM4R)
		if type=='filters':
			RR6L0Hg8km2GPorNFwyD = EcQxOa3RJm86WjTKA.findall('"more_button_page":(.*?),',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			if RR6L0Hg8km2GPorNFwyD:
				count = RR6L0Hg8km2GPorNFwyD[0]
				bigdh7fpZYl4aT2keV = url+'/offset/'+count
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة أخرى',bigdh7fpZYl4aT2keV,561,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filters')
		elif type==fy8iFgEkrO12NR9TWBI35sjY6qHvV:
			z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="pagination(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
			if z6PX2p7diaskQElBOvMRNcHwqG5D:
				wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
				items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
				for bigdh7fpZYl4aT2keV,title in items:
					if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
					title = 'صفحة '+IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
					OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,561)
	return
def eQgbVPaIBvTn8fsjJRt241(url,type=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'WECIMA1-EPISODES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	FGRX4myP68S = U2Z7CVFftTmLeK3nzEbQPGga(FGRX4myP68S)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="Seasons--Episodes"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not type and z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if len(items)>1:
			for bigdh7fpZYl4aT2keV,title in items:
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,563,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'episodes')
			return
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="Episodes--Seasons--Episodes(.*?)</singlesections>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?<episodeTitle>(.*?)</episodeTitle>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL|EcQxOa3RJm86WjTKA.IGNORECASE)
		for bigdh7fpZYl4aT2keV,title in items:
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,562)
	if not I4t9qonjrm.menuItemsLIST:
		title = EcQxOa3RJm86WjTKA.findall('<title>(.*?)<',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if title: title = title[0].replace(' - ماي سيما',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('مشاهدة ',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		else: title = 'ملف التشغيل'
		OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,url,562)
	return
def rr7SfotkneX85Klup(url):
	XoSyx7p6dqZ1CF8 = []
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'WECIMA1-PLAY-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	uuigJsvIZQ3tprnhxG = EcQxOa3RJm86WjTKA.findall('<span>التصنيف<.*?<a.*?">(.*?)<.*?">(.*?)<',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if uuigJsvIZQ3tprnhxG:
		uuigJsvIZQ3tprnhxG = [uuigJsvIZQ3tprnhxG[0][0],uuigJsvIZQ3tprnhxG[0][1]]
		if uuigJsvIZQ3tprnhxG and SYJvigbI3fts(BfWYUAnyg6eONLjiuE,url,uuigJsvIZQ3tprnhxG): return
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="WatchServersList"(.*?)class="WatchServersEmbed"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('data-url="(.*?)".*?strong>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,name in items:
			if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
			if name=='سيرفر وي سيما': name = 'wecima'
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+name+'__watch'
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(FFkml6ZbgXD,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="List--Download(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?</i>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,OOnVxtP0TNWsci6HrEGqBm9boKF7g in items:
			if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
			OOnVxtP0TNWsci6HrEGqBm9boKF7g = EcQxOa3RJm86WjTKA.findall('\d\d\d+',OOnVxtP0TNWsci6HrEGqBm9boKF7g,EcQxOa3RJm86WjTKA.DOTALL)
			if OOnVxtP0TNWsci6HrEGqBm9boKF7g: OOnVxtP0TNWsci6HrEGqBm9boKF7g = '____'+OOnVxtP0TNWsci6HrEGqBm9boKF7g[0]
			else: OOnVxtP0TNWsci6HrEGqBm9boKF7g = fy8iFgEkrO12NR9TWBI35sjY6qHvV
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named=wecima'+'__download'+OOnVxtP0TNWsci6HrEGqBm9boKF7g
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(FFkml6ZbgXD,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(XoSyx7p6dqZ1CF8,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search,hcKaMyzVPnRuIs=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	if not hcKaMyzVPnRuIs:
		hcKaMyzVPnRuIs = BOI3t1w8qfHAb0Kl4oMye7haEWS
	YLKFRH6sSIrznXBg = hcKaMyzVPnRuIs+'/AjaxCenter/Searching/'+search+'/'
	HAsKeZdTbqjPI1WY(YLKFRH6sSIrznXBg,'search')
	return
def F4ehkvPDxXU(bbiTzdsmeaKpv,filter):
	if '??' in bbiTzdsmeaKpv: url = bbiTzdsmeaKpv.split('//getposts??')[0]
	else: url = bbiTzdsmeaKpv
	filter = filter.replace('_FORGETRESULTS_',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	type,filter = filter.split('___',1)
	if filter==fy8iFgEkrO12NR9TWBI35sjY6qHvV: NnQ1hEsTV7Zaz3HKdfu,QlOXcH07nRVPAZub8pD356xMvdk4 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	else: NnQ1hEsTV7Zaz3HKdfu,QlOXcH07nRVPAZub8pD356xMvdk4 = filter.split('___')
	if type=='CATEGORIES':
		if K3KSDO9Alxe6on[0]+'==' not in NnQ1hEsTV7Zaz3HKdfu: fnogyzNA30JCPMYqHTavG7ZKp = K3KSDO9Alxe6on[0]
		for pk6YWixXFSrDLKCnlN39w in range(len(K3KSDO9Alxe6on[0:-1])):
			if K3KSDO9Alxe6on[pk6YWixXFSrDLKCnlN39w]+'==' in NnQ1hEsTV7Zaz3HKdfu: fnogyzNA30JCPMYqHTavG7ZKp = K3KSDO9Alxe6on[pk6YWixXFSrDLKCnlN39w+1]
		z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&&'+fnogyzNA30JCPMYqHTavG7ZKp+'==0'
		ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&&'+fnogyzNA30JCPMYqHTavG7ZKp+'==0'
		HfvJenZmN3O8rPcshLux2EyzDWpQCb = z7VI1OaUPqs4lXxb.strip('&&')+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq.strip('&&')
		F231lsuCKnaSMdQ48W6PoL = nKT1QuLoXPc8CjyV(QlOXcH07nRVPAZub8pD356xMvdk4,'modified_filters')
		YLKFRH6sSIrznXBg = url+'//getposts??'+F231lsuCKnaSMdQ48W6PoL
	elif type=='FILTERS':
		QUFL2gEBMn63qlsmI7W = nKT1QuLoXPc8CjyV(NnQ1hEsTV7Zaz3HKdfu,'modified_values')
		QUFL2gEBMn63qlsmI7W = U2Z7CVFftTmLeK3nzEbQPGga(QUFL2gEBMn63qlsmI7W)
		if QlOXcH07nRVPAZub8pD356xMvdk4!=fy8iFgEkrO12NR9TWBI35sjY6qHvV: QlOXcH07nRVPAZub8pD356xMvdk4 = nKT1QuLoXPc8CjyV(QlOXcH07nRVPAZub8pD356xMvdk4,'modified_filters')
		if QlOXcH07nRVPAZub8pD356xMvdk4==fy8iFgEkrO12NR9TWBI35sjY6qHvV: YLKFRH6sSIrznXBg = url
		else: YLKFRH6sSIrznXBg = url+'//getposts??'+QlOXcH07nRVPAZub8pD356xMvdk4
		hL4w3zgankZR75698QCyi = bpvKh19zQGfPY8wrkFlLD3N(YLKFRH6sSIrznXBg,bbiTzdsmeaKpv)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'أظهار قائمة الفيديو التي تم اختيارها ',hL4w3zgankZR75698QCyi,561,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filters')
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+' [[   '+QUFL2gEBMn63qlsmI7W+'   ]]',hL4w3zgankZR75698QCyi,561,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filters')
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'WECIMA1-FILTERS_MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	FGRX4myP68S = FGRX4myP68S.replace('\\"','"').replace('\\/','/')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('<wecima--filter(.*?)</wecima--filter>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not z6PX2p7diaskQElBOvMRNcHwqG5D: return
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	W1A4L5P0Zc8wHnUGjVexElz = EcQxOa3RJm86WjTKA.findall('taxonomy="(.*?)".*?<span>(.*?)<(.*?)<filterbox',wlJ6d8hEvpoMNSCmU+'<filterbox',EcQxOa3RJm86WjTKA.DOTALL)
	dict = {}
	for jLA9nhxoZbG,name,wlJ6d8hEvpoMNSCmU in W1A4L5P0Zc8wHnUGjVexElz:
		name = XXcPiylRDh6IapYA25rwO8u(name)
		if 'interest' in jLA9nhxoZbG: continue
		items = EcQxOa3RJm86WjTKA.findall('data-term="(.*?)".*?<txt>(.*?)</txt>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if '==' not in YLKFRH6sSIrznXBg: YLKFRH6sSIrznXBg = url
		if type=='CATEGORIES':
			if fnogyzNA30JCPMYqHTavG7ZKp!=jLA9nhxoZbG: continue
			elif len(items)<=1:
				if jLA9nhxoZbG==K3KSDO9Alxe6on[-1]: HAsKeZdTbqjPI1WY(YLKFRH6sSIrznXBg)
				else: F4ehkvPDxXU(YLKFRH6sSIrznXBg,'CATEGORIES___'+HfvJenZmN3O8rPcshLux2EyzDWpQCb)
				return
			else:
				hL4w3zgankZR75698QCyi = bpvKh19zQGfPY8wrkFlLD3N(YLKFRH6sSIrznXBg,bbiTzdsmeaKpv)
				if jLA9nhxoZbG==K3KSDO9Alxe6on[-1]:
					OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع',hL4w3zgankZR75698QCyi,561,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filters')
				else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع',YLKFRH6sSIrznXBg,564,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,HfvJenZmN3O8rPcshLux2EyzDWpQCb)
		elif type=='FILTERS':
			z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&&'+jLA9nhxoZbG+'==0'
			ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&&'+jLA9nhxoZbG+'==0'
			HfvJenZmN3O8rPcshLux2EyzDWpQCb = z7VI1OaUPqs4lXxb+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+name+': الجميع',YLKFRH6sSIrznXBg,565,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,HfvJenZmN3O8rPcshLux2EyzDWpQCb+'_FORGETRESULTS_')
		dict[jLA9nhxoZbG] = {}
		for value,srR9AuG6Pf8powqU4ixL5Ecl in items:
			name = XXcPiylRDh6IapYA25rwO8u(name)
			srR9AuG6Pf8powqU4ixL5Ecl = XXcPiylRDh6IapYA25rwO8u(srR9AuG6Pf8powqU4ixL5Ecl)
			if value=='r' or value=='nc-17': continue
			if any(value in srR9AuG6Pf8powqU4ixL5Ecl.lower() for value in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o): continue
			if 'http' in srR9AuG6Pf8powqU4ixL5Ecl: continue
			if 'الكل' in srR9AuG6Pf8powqU4ixL5Ecl: continue
			if 'n-a' in value: continue
			if srR9AuG6Pf8powqU4ixL5Ecl==fy8iFgEkrO12NR9TWBI35sjY6qHvV: srR9AuG6Pf8powqU4ixL5Ecl = value
			c9LD37hsJzqNi2lQVWIBwFgoYy = srR9AuG6Pf8powqU4ixL5Ecl
			yNGUJ2kYzPnhDLi = EcQxOa3RJm86WjTKA.findall('<name>(.*?)</name>',srR9AuG6Pf8powqU4ixL5Ecl,EcQxOa3RJm86WjTKA.DOTALL)
			if yNGUJ2kYzPnhDLi: c9LD37hsJzqNi2lQVWIBwFgoYy = yNGUJ2kYzPnhDLi[0]
			D4DQ6k0oS39GKbZrthnsTB = name+': '+c9LD37hsJzqNi2lQVWIBwFgoYy
			dict[jLA9nhxoZbG][value] = D4DQ6k0oS39GKbZrthnsTB
			z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&&'+jLA9nhxoZbG+'=='+c9LD37hsJzqNi2lQVWIBwFgoYy
			ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&&'+jLA9nhxoZbG+'=='+value
			QdzUcX2iR5 = z7VI1OaUPqs4lXxb+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq
			if type=='FILTERS':
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+D4DQ6k0oS39GKbZrthnsTB,url,565,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QdzUcX2iR5+'_FORGETRESULTS_')
			elif type=='CATEGORIES' and K3KSDO9Alxe6on[-2]+'==' in NnQ1hEsTV7Zaz3HKdfu:
				F231lsuCKnaSMdQ48W6PoL = nKT1QuLoXPc8CjyV(ybEUMsLp4zBVPnuAYI0cCdowekDq,'modified_filters')
				MYWwFs7XA2 = url+'//getposts??'+F231lsuCKnaSMdQ48W6PoL
				hL4w3zgankZR75698QCyi = bpvKh19zQGfPY8wrkFlLD3N(MYWwFs7XA2,bbiTzdsmeaKpv)
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+D4DQ6k0oS39GKbZrthnsTB,hL4w3zgankZR75698QCyi,561,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filters')
			else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+D4DQ6k0oS39GKbZrthnsTB,url,564,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QdzUcX2iR5)
	return
K3KSDO9Alxe6on = ['genre','release-year','nation']
xoakH1wihmQLIsMb = ['mpaa','genre','release-year','category','Quality','interest','nation','language']
def bpvKh19zQGfPY8wrkFlLD3N(YLKFRH6sSIrznXBg,MYWwFs7XA2):
	if '/AjaxCenter/RightBar' in YLKFRH6sSIrznXBg: YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg.replace('/AjaxCenter/RightBar','/AjaxCenter/Filtering')
	YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg.replace('//getposts??','::/AjaxCenter/Filtering/')
	YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg.replace('==','/')
	YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg.replace('&&','/')
	return YLKFRH6sSIrznXBg
def nKT1QuLoXPc8CjyV(p9UP6wGlC1BF7fN2,mode):
	p9UP6wGlC1BF7fN2 = p9UP6wGlC1BF7fN2.strip('&&')
	vpLWbVm35iM0l2TzYIN7,MKJaIb2sDSr4VCQGTqyX3nkWL = {},fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if '==' in p9UP6wGlC1BF7fN2:
		items = p9UP6wGlC1BF7fN2.split('&&')
		for j25T6eKhaMk3 in items:
			XJRx6urSNaOM5AfZdDsgQBYGt,value = j25T6eKhaMk3.split('==')
			vpLWbVm35iM0l2TzYIN7[XJRx6urSNaOM5AfZdDsgQBYGt] = value
	for key in xoakH1wihmQLIsMb:
		if key in list(vpLWbVm35iM0l2TzYIN7.keys()): value = vpLWbVm35iM0l2TzYIN7[key]
		else: value = '0'
		if '%' not in value: value = DVX5GWhnIxYlSd9rEuetjk40UJ(value)
		if mode=='modified_values' and value!='0': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+' + '+value
		elif mode=='modified_filters' and value!='0': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+'&&'+key+'=='+value
		elif mode=='all': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+'&&'+key+'=='+value
	MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL.strip(' + ')
	MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL.strip('&&')
	return MKJaIb2sDSr4VCQGTqyX3nkWL
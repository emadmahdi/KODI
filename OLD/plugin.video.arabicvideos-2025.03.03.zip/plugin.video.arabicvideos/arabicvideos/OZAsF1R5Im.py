# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'FARESKO'
K2l9rLfvoXxyZ4NYapO = '_FSK_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['الرئيسية','يلا شوت']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==990: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==991: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,text)
	elif mode==992: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==993: OmsWt89dSA5HyCZ4wL = XiHWZGyhu27CE(url)
	elif mode==999: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FARESKO-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,999,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"primary-links"(.*?)</u',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?<span>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if title in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,991)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"list-categories"(.*?)</u',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+bigdh7fpZYl4aT2keV.lstrip('/')
			if title in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,991)
	return
def HAsKeZdTbqjPI1WY(url,type=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FARESKO-TITLES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"home-content"(.*?)"footer"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		wlJ6d8hEvpoMNSCmU = wlJ6d8hEvpoMNSCmU.replace('"overlay"','"duration"><')
		items = EcQxOa3RJm86WjTKA.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		cmDaLEqWlT7GhonIdX5k1zHQjSiupe = []
		for POjaBmHqzpsx1IYw7kQM4R,rQ0jN7XkZPE1AYU,bigdh7fpZYl4aT2keV,title in items:
			title = title.strip(' ')
			title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
			RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) (الحلقة|حلقة).\d+',title,EcQxOa3RJm86WjTKA.DOTALL)
			if 'episodes' not in type and RrzpbE3t9woCk7MXS0GvNdi1BcV:
				title = '_MOD_' + RrzpbE3t9woCk7MXS0GvNdi1BcV[0][0]
				title = title.replace('اون لاين',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
				if title not in cmDaLEqWlT7GhonIdX5k1zHQjSiupe:
					OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,993,POjaBmHqzpsx1IYw7kQM4R)
					cmDaLEqWlT7GhonIdX5k1zHQjSiupe.append(title)
			else: OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,992,POjaBmHqzpsx1IYw7kQM4R,rQ0jN7XkZPE1AYU)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('''["']pagination["'](.*?)["']footer["']''',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,991,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,type)
	else:
		bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall('load-next-button" href="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if bigdh7fpZYl4aT2keV: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة جديدة',bigdh7fpZYl4aT2keV[0],991,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,type)
	return
def XiHWZGyhu27CE(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FARESKO-SERIES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="eplist"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		jbpHA8eDFYwlT = EcQxOa3RJm86WjTKA.findall('href="(.*?)" title="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in jbpHA8eDFYwlT:
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,992)
	else:
		bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall('"category".*?href="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if bigdh7fpZYl4aT2keV:
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[0]
			HAsKeZdTbqjPI1WY(bigdh7fpZYl4aT2keV,'episodes')
	return
def rr7SfotkneX85Klup(url):
	hFzEyHWOoRxG,CXTL7NPUAE = [],[]
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FARESKO-PLAY-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	if 'hash=' in FGRX4myP68S:
		XXUke3FncS64iaG5yD = EcQxOa3RJm86WjTKA.findall('hash=(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		XXUke3FncS64iaG5yD = list(set(XXUke3FncS64iaG5yD))
		for JA3FuzlcgjrGP in XXUke3FncS64iaG5yD:
			I2G7Yw6VyE49uHhe8fCdvPj = []
			V5VDwKLAYM3 = JA3FuzlcgjrGP.split('__')
			for E5Ewm9VTIQ6Yp2fvCdAgkFRe in V5VDwKLAYM3:
				try:
					E5Ewm9VTIQ6Yp2fvCdAgkFRe = JNfHYgOdP9aR.b64decode(E5Ewm9VTIQ6Yp2fvCdAgkFRe+'=')
					if jTDWgftK7NEmx0JAkOn2aRIvweq: E5Ewm9VTIQ6Yp2fvCdAgkFRe = E5Ewm9VTIQ6Yp2fvCdAgkFRe.decode(Tk9eH2qw6Brsuhj)
					I2G7Yw6VyE49uHhe8fCdvPj.append(E5Ewm9VTIQ6Yp2fvCdAgkFRe)
				except: pass
			zzECVswWcGAIXhrQlZ7jMokugnv = '>'.join(I2G7Yw6VyE49uHhe8fCdvPj)
			zzECVswWcGAIXhrQlZ7jMokugnv = zzECVswWcGAIXhrQlZ7jMokugnv.splitlines()
			for bigdh7fpZYl4aT2keV in zzECVswWcGAIXhrQlZ7jMokugnv:
				if ' => ' in bigdh7fpZYl4aT2keV:
					title,bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.split(' => ')
					bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+title+'__watch'
					hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
	elif 'post_id' in FGRX4myP68S:
		pl3chZdq7I = EcQxOa3RJm86WjTKA.findall("post_id = '(.*?)'",FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if pl3chZdq7I:
			pl3chZdq7I = pl3chZdq7I[0]
			headers = {'X-Requested-With':'XMLHttpRequest'}
			rPBMHQe8J3boKv7LCw9OTufz64pS5d = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/wp-admin/admin-ajax.php?action=video_info&post_id='+pl3chZdq7I
			E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',rPBMHQe8J3boKv7LCw9OTufz64pS5d,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FARESKO-PLAY-2nd')
			q9subdOJhxm0kKTLDc3UGYnN5V7M = E6ECvznP9m5sWFMu.content
			oNdlPscbkO1mi = EcQxOa3RJm86WjTKA.findall('"name":"(.*?)","src":"(.*?)"',q9subdOJhxm0kKTLDc3UGYnN5V7M,EcQxOa3RJm86WjTKA.DOTALL)
			if not oNdlPscbkO1mi:
				oNdlPscbkO1mi = EcQxOa3RJm86WjTKA.findall('"src":"(.*?)"',q9subdOJhxm0kKTLDc3UGYnN5V7M,EcQxOa3RJm86WjTKA.DOTALL)
				if oNdlPscbkO1mi:
					DDTwCHbjfIeQlJuincoUrz71SOVgM = ['']*len(oNdlPscbkO1mi)
					oNdlPscbkO1mi = list(zip(DDTwCHbjfIeQlJuincoUrz71SOVgM,oNdlPscbkO1mi))
			for name,bigdh7fpZYl4aT2keV in oNdlPscbkO1mi:
				bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.replace('\\/','/')
				bigdh7fpZYl4aT2keV = DVX5GWhnIxYlSd9rEuetjk40UJ(bigdh7fpZYl4aT2keV)
				if bigdh7fpZYl4aT2keV in CXTL7NPUAE: continue
				else: CXTL7NPUAE.append(bigdh7fpZYl4aT2keV)
				hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV+'?named='+name+'__watch')
			R9b8gUvoB4wOfkTIjlEsZrM5LtinpS = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/wp-admin/admin-ajax.php?action=mwp_generate_video_download_link&post_id='+pl3chZdq7I+'&video_id=null&video_url=null&video_source=custom'
			E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',R9b8gUvoB4wOfkTIjlEsZrM5LtinpS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FARESKO-PLAY-3rd')
			soEymUvkt19PQXVjzKau6x5 = E6ECvznP9m5sWFMu.content
			UUr86Suzdfl13PxiTweEMZyCjHcs7p = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)<',soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
			if UUr86Suzdfl13PxiTweEMZyCjHcs7p:
				BxjM457FCb1n92RlzpIHd3fySLw,N7mOTidFMbQxfHv4 = zip(*UUr86Suzdfl13PxiTweEMZyCjHcs7p)
				UUr86Suzdfl13PxiTweEMZyCjHcs7p = list(zip(N7mOTidFMbQxfHv4,BxjM457FCb1n92RlzpIHd3fySLw))
			for name,bigdh7fpZYl4aT2keV in UUr86Suzdfl13PxiTweEMZyCjHcs7p:
				bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.replace('\\/','/')
				bigdh7fpZYl4aT2keV = DVX5GWhnIxYlSd9rEuetjk40UJ(bigdh7fpZYl4aT2keV)
				if bigdh7fpZYl4aT2keV in CXTL7NPUAE: continue
				else: CXTL7NPUAE.append(bigdh7fpZYl4aT2keV)
				hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV+'?named='+name+'__download')
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(hFzEyHWOoRxG,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/?s='+search
	HAsKeZdTbqjPI1WY(url,'search')
	return
# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'SERIES4WATCH'
headers = { 'User-Agent' : fy8iFgEkrO12NR9TWBI35sjY6qHvV }
K2l9rLfvoXxyZ4NYapO = '_SFW_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==210: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==211: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url)
	elif mode==212: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==213: OmsWt89dSA5HyCZ4wL = eQgbVPaIBvTn8fsjJRt241(url)
	elif mode==214: OmsWt89dSA5HyCZ4wL = UhJEzk4sgI2YV(url)
	elif mode==215: OmsWt89dSA5HyCZ4wL = pyt1UokMHLs47I(url)
	elif mode==218: OmsWt89dSA5HyCZ4wL = Qr0OEzA7hsVTn2()
	elif mode==219: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def Qr0OEzA7hsVTn2():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','الموقع تغير بالكامل',message)
	return
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,219,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/getpostsPin?type=one&data=pin&limit=25'
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'المميزة',url,211)
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SERIES4WATCH-MENU-1st')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('FiltersButtons(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	items = EcQxOa3RJm86WjTKA.findall('data-get="(.*?)".*?</i>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title in items:
		url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/getposts?type=one&data='+bigdh7fpZYl4aT2keV
		OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,url,211)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('navigation-menu(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	items = EcQxOa3RJm86WjTKA.findall('href="(http.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['مسلسلات انمي','الرئيسية']
	for bigdh7fpZYl4aT2keV,title in items:
		title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
		if not any(value in title for value in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o):
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,211)
	return FGRX4myP68S
def HAsKeZdTbqjPI1WY(url):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: wlJ6d8hEvpoMNSCmU = FGRX4myP68S
	else:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('MediaGrid"(.*?)class="pagination"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D: wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		else: return
	items = EcQxOa3RJm86WjTKA.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	cmDaLEqWlT7GhonIdX5k1zHQjSiupe = []
	SVzBiTcetyDnl = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for POjaBmHqzpsx1IYw7kQM4R,bigdh7fpZYl4aT2keV,title in items:
		if '/series/' in bigdh7fpZYl4aT2keV: continue
		bigdh7fpZYl4aT2keV = U2Z7CVFftTmLeK3nzEbQPGga(bigdh7fpZYl4aT2keV).strip('/')
		title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
		title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
		if '/film/' in bigdh7fpZYl4aT2keV or any(value in title for value in SVzBiTcetyDnl):
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,212,POjaBmHqzpsx1IYw7kQM4R)
		elif '/episode/' in bigdh7fpZYl4aT2keV and 'الحلقة' in title:
			RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) الحلقة \d+',title,EcQxOa3RJm86WjTKA.DOTALL)
			if RrzpbE3t9woCk7MXS0GvNdi1BcV:
				title = '_MOD_' + RrzpbE3t9woCk7MXS0GvNdi1BcV[0]
				if title not in cmDaLEqWlT7GhonIdX5k1zHQjSiupe:
					OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,213,POjaBmHqzpsx1IYw7kQM4R)
					cmDaLEqWlT7GhonIdX5k1zHQjSiupe.append(title)
		else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,213,POjaBmHqzpsx1IYw7kQM4R)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="pagination(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			bigdh7fpZYl4aT2keV = IVcCL3aAfU9wS7kWev1g2XBjZRJ(bigdh7fpZYl4aT2keV)
			title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
			title = title.replace('الصفحة ',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			if title!=fy8iFgEkrO12NR9TWBI35sjY6qHvV: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,211)
	return
def eQgbVPaIBvTn8fsjJRt241(url):
	hhyWJFp3wl,items,v2vJe7KGUfi0xjhpB4Droq3s5kPF = -1,[],[]
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SERIES4WATCH-EPISODES-1st')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('ti-list-numbered(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		VuGmoESTAfXlv5tD76PW1Masq0peB = fy8iFgEkrO12NR9TWBI35sjY6qHvV.join(z6PX2p7diaskQElBOvMRNcHwqG5D)
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)"',VuGmoESTAfXlv5tD76PW1Masq0peB,EcQxOa3RJm86WjTKA.DOTALL)
	items.append(url)
	items = set(items)
	for bigdh7fpZYl4aT2keV in items:
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.strip('/')
		title = '_MOD_' + bigdh7fpZYl4aT2keV.split('/')[-1].replace('-',ksJdoFWhxTz8Y2N7bOZE)
		hdmfg3T7CarEeB6lyYGN4kxw = EcQxOa3RJm86WjTKA.findall('الحلقة-(\d+)',bigdh7fpZYl4aT2keV.split('/')[-1],EcQxOa3RJm86WjTKA.DOTALL)
		if hdmfg3T7CarEeB6lyYGN4kxw: hdmfg3T7CarEeB6lyYGN4kxw = hdmfg3T7CarEeB6lyYGN4kxw[0]
		else: hdmfg3T7CarEeB6lyYGN4kxw = '0'
		v2vJe7KGUfi0xjhpB4Droq3s5kPF.append([bigdh7fpZYl4aT2keV,title,hdmfg3T7CarEeB6lyYGN4kxw])
	items = sorted(v2vJe7KGUfi0xjhpB4Droq3s5kPF, reverse=False, key=lambda key: int(key[2]))
	js4ql3CGTdXkW5vhm = str(items).count('/season/')
	hhyWJFp3wl = str(items).count('/episode/')
	if js4ql3CGTdXkW5vhm>1 and hhyWJFp3wl>0 and '/season/' not in url:
		for bigdh7fpZYl4aT2keV,title,hdmfg3T7CarEeB6lyYGN4kxw in items:
			if '/season/' in bigdh7fpZYl4aT2keV: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,213)
	else:
		for bigdh7fpZYl4aT2keV,title,hdmfg3T7CarEeB6lyYGN4kxw in items:
			if '/season/' not in bigdh7fpZYl4aT2keV: OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,212)
	return
def rr7SfotkneX85Klup(url):
	XoSyx7p6dqZ1CF8 = []
	V5VDwKLAYM3 = url.split('/')
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SERIES4WATCH-PLAY-1st')
	if '/watch/' in FGRX4myP68S:
		YLKFRH6sSIrznXBg = url.replace(V5VDwKLAYM3[3],'watch')
		soEymUvkt19PQXVjzKau6x5 = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SERIES4WATCH-PLAY-2nd')
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="servers-list(.*?)</div>',soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			if items:
				id = EcQxOa3RJm86WjTKA.findall('post_id=(.*?)"',soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
				if id:
					aiuh0XlPswEK = id[0]
					for bigdh7fpZYl4aT2keV,title in items:
						bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/?postid='+aiuh0XlPswEK+'&serverid='+bigdh7fpZYl4aT2keV+'?named='+title+'__watch'
						XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
			else:
				items = EcQxOa3RJm86WjTKA.findall('data-embedd=".*?(http.*?)("|&quot;)',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
				for bigdh7fpZYl4aT2keV,O4On5rLamD7q1zKBo6WfF3eEbS98 in items:
					XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	if '/download/' in FGRX4myP68S:
		YLKFRH6sSIrznXBg = url.replace(V5VDwKLAYM3[3],'download')
		soEymUvkt19PQXVjzKau6x5 = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SERIES4WATCH-PLAY-3rd')
		id = EcQxOa3RJm86WjTKA.findall('postId:"(.*?)"',soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
		if id:
			aiuh0XlPswEK = id[0]
			naBFTDfp6lmKjeOywg87IAcb = { 'User-Agent':fy8iFgEkrO12NR9TWBI35sjY6qHvV , 'X-Requested-With':'XMLHttpRequest' }
			YLKFRH6sSIrznXBg = BOI3t1w8qfHAb0Kl4oMye7haEWS + '/ajaxCenter?_action=getdownloadlinks&postId='+aiuh0XlPswEK
			soEymUvkt19PQXVjzKau6x5 = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,naBFTDfp6lmKjeOywg87IAcb,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SERIES4WATCH-PLAY-4th')
			z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('<h3.*?(\d+)(.*?)</div>',soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
			if z6PX2p7diaskQElBOvMRNcHwqG5D:
				for rsptjuWoTfEn6eVxhd,wlJ6d8hEvpoMNSCmU in z6PX2p7diaskQElBOvMRNcHwqG5D:
					items = EcQxOa3RJm86WjTKA.findall('<td>(.*?)<.*?href="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
					for name,bigdh7fpZYl4aT2keV in items:
						XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV+'?named='+name+'__download'+'____'+rsptjuWoTfEn6eVxhd)
			else:
				z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('<h6(.*?)</table>',soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
				if not z6PX2p7diaskQElBOvMRNcHwqG5D: z6PX2p7diaskQElBOvMRNcHwqG5D = [soEymUvkt19PQXVjzKau6x5]
				for wlJ6d8hEvpoMNSCmU in z6PX2p7diaskQElBOvMRNcHwqG5D:
					name = fy8iFgEkrO12NR9TWBI35sjY6qHvV
					items = EcQxOa3RJm86WjTKA.findall('href="(http.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
					for bigdh7fpZYl4aT2keV in items:
						A8ECQ0qwTRzPifOGW76FK35uUvhe = '&&' + bigdh7fpZYl4aT2keV.split('/')[2].lower() + '&&'
						A8ECQ0qwTRzPifOGW76FK35uUvhe = A8ECQ0qwTRzPifOGW76FK35uUvhe.replace('.com&&',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('.co&&',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
						A8ECQ0qwTRzPifOGW76FK35uUvhe = A8ECQ0qwTRzPifOGW76FK35uUvhe.replace('.net&&',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('.org&&',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
						A8ECQ0qwTRzPifOGW76FK35uUvhe = A8ECQ0qwTRzPifOGW76FK35uUvhe.replace('.live&&',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('.online&&',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
						A8ECQ0qwTRzPifOGW76FK35uUvhe = A8ECQ0qwTRzPifOGW76FK35uUvhe.replace('&&hd.',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('&&www.',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
						A8ECQ0qwTRzPifOGW76FK35uUvhe = A8ECQ0qwTRzPifOGW76FK35uUvhe.replace('&&',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
						bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV + '?named=' + name + A8ECQ0qwTRzPifOGW76FK35uUvhe + '__download'
						XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(XoSyx7p6dqZ1CF8,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS + '/search?s='+search
	HAsKeZdTbqjPI1WY(url)
	return
# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'CIMAABDO'
K2l9rLfvoXxyZ4NYapO = '_ABD_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['الرئيسية']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==550: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==551: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,text)
	elif mode==552: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==553: OmsWt89dSA5HyCZ4wL = eQgbVPaIBvTn8fsjJRt241(url)
	elif mode==559: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/home',fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMAABDO-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = VbHeOuU1ilzSp2ZRXwBD(BOI3t1w8qfHAb0Kl4oMye7haEWS,'url')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,559,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'اخترنا لك',VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/home',551,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'featured')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('main-content(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	items = EcQxOa3RJm86WjTKA.findall('data-name="(.*?)".*?</i>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for H1yrgtivdZBUk2NOGx4LncKFSYCWX,title in items:
		bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/ajax/getItem?item='+H1yrgtivdZBUk2NOGx4LncKFSYCWX+'&Ajax=1'
		OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,551)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"nav-main"(.*?)</nav>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title in items:
		if bigdh7fpZYl4aT2keV=='#': continue
		if title in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' in title: OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,551)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	for bigdh7fpZYl4aT2keV,title in items:
		if bigdh7fpZYl4aT2keV=='#': continue
		if title in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' not in title: OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,551)
	return
def HAsKeZdTbqjPI1WY(url,H1yrgtivdZBUk2NOGx4LncKFSYCWX=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		YLKFRH6sSIrznXBg,gWBLDSlZGwqxHT = lNyxXsMAcYHBUDh4dJbfTWR(url)
		naBFTDfp6lmKjeOywg87IAcb = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'POST',YLKFRH6sSIrznXBg,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMAABDO-TITLES-1st')
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		z6PX2p7diaskQElBOvMRNcHwqG5D = [FGRX4myP68S]
	else:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMAABDO-TITLES-2nd')
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		if H1yrgtivdZBUk2NOGx4LncKFSYCWX=='featured':
			z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"container"(.*?)"container"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		elif '"section-post mb-10"' in FGRX4myP68S:
			z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"section-post mb-10"(.*?)"container"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		else:
			z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('<article(.*?)"pagination"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not z6PX2p7diaskQElBOvMRNcHwqG5D: return
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	if not items:
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if not items: items = EcQxOa3RJm86WjTKA.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	cmDaLEqWlT7GhonIdX5k1zHQjSiupe = []
	mmO39lwp0LFUrVT = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for bigdh7fpZYl4aT2keV,title,POjaBmHqzpsx1IYw7kQM4R in items:
		bigdh7fpZYl4aT2keV = U2Z7CVFftTmLeK3nzEbQPGga(bigdh7fpZYl4aT2keV).strip('/')
		RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) الحلقة \d+',title,EcQxOa3RJm86WjTKA.DOTALL)
		if 'سلاسل' not in url and any(value in title for value in mmO39lwp0LFUrVT):
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,552,POjaBmHqzpsx1IYw7kQM4R)
		elif RrzpbE3t9woCk7MXS0GvNdi1BcV and 'الحلقة' in title:
			title = '_MOD_' + RrzpbE3t9woCk7MXS0GvNdi1BcV[0]
			if title not in cmDaLEqWlT7GhonIdX5k1zHQjSiupe:
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,553,POjaBmHqzpsx1IYw7kQM4R)
				cmDaLEqWlT7GhonIdX5k1zHQjSiupe.append(title)
		elif '/movies/' in bigdh7fpZYl4aT2keV:
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,551,POjaBmHqzpsx1IYw7kQM4R)
		else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,553,POjaBmHqzpsx1IYw7kQM4R)
	if H1yrgtivdZBUk2NOGx4LncKFSYCWX==fy8iFgEkrO12NR9TWBI35sjY6qHvV:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"pagination"(.*?)<footer',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title in items:
				if bigdh7fpZYl4aT2keV=="": continue
				if title!=fy8iFgEkrO12NR9TWBI35sjY6qHvV: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,551)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'هناك المزيد',url,551)
	return
def eQgbVPaIBvTn8fsjJRt241(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMAABDO-EPISODES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	y4IYUHTpSs8DXEfajQLvWb0g1G = EcQxOa3RJm86WjTKA.findall('"getSeasonsBySeries(.*?)"container"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	UgbWFLzrCA5RMo7tjwNmdyc68khBGn = EcQxOa3RJm86WjTKA.findall('"list-episodes"(.*?)"container"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if y4IYUHTpSs8DXEfajQLvWb0g1G and '/series/' not in url:
		wlJ6d8hEvpoMNSCmU = y4IYUHTpSs8DXEfajQLvWb0g1G[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title,POjaBmHqzpsx1IYw7kQM4R in items:
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,553,POjaBmHqzpsx1IYw7kQM4R)
	elif UgbWFLzrCA5RMo7tjwNmdyc68khBGn:
		POjaBmHqzpsx1IYw7kQM4R = EcQxOa3RJm86WjTKA.findall('"image" src="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R[0]
		wlJ6d8hEvpoMNSCmU = UgbWFLzrCA5RMo7tjwNmdyc68khBGn[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)" title="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,552,POjaBmHqzpsx1IYw7kQM4R)
	return
def rr7SfotkneX85Klup(url):
	MYWwFs7XA2 = url.replace('/movies/','/watch_movies/')
	MYWwFs7XA2 = MYWwFs7XA2.replace('/episodes/','/watch_episodes/')
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',MYWwFs7XA2,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMAABDO-PLAY-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = VbHeOuU1ilzSp2ZRXwBD(MYWwFs7XA2,'url')
	hFzEyHWOoRxG = []
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall('''<iframe.*?src=["'](.*?)["']''',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if bigdh7fpZYl4aT2keV:
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[0]
		A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,'url')
		hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV+'?named='+A8ECQ0qwTRzPifOGW76FK35uUvhe+'__embed')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"servers"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		pl3chZdq7I = EcQxOa3RJm86WjTKA.findall('postID = "(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		pl3chZdq7I = pl3chZdq7I[0]
		items = EcQxOa3RJm86WjTKA.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if items:
			for A8ECQ0qwTRzPifOGW76FK35uUvhe,title in items:
				title = title.replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE)
				bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/ajax/getPlayer?server='+A8ECQ0qwTRzPifOGW76FK35uUvhe+'&postID='+pl3chZdq7I+'&Ajax=1'
				bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+title+'__watch'
				hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
		else:
			items = EcQxOa3RJm86WjTKA.findall("getPlayerByName\('(.*?)','(.*?)'.*?\"server\">(.*?)</a>",wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			if items:
				A8ECQ0qwTRzPifOGW76FK35uUvhe,vDMJeqH7soLWfFpnN5T4mUg,title = items[0]
				bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/ajax/getPlayerByName?server='+A8ECQ0qwTRzPifOGW76FK35uUvhe+'&multipleServers='+vDMJeqH7soLWfFpnN5T4mUg+'&postID='+pl3chZdq7I+'&Ajax=1'
				YLKFRH6sSIrznXBg,gWBLDSlZGwqxHT = lNyxXsMAcYHBUDh4dJbfTWR(bigdh7fpZYl4aT2keV)
				naBFTDfp6lmKjeOywg87IAcb = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
				E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'POST',YLKFRH6sSIrznXBg,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMAABDO-PLAY-2nd')
				FGRX4myP68S = E6ECvznP9m5sWFMu.content
				GmYolHzab0xs8F6f = EcQxOa3RJm86WjTKA.findall('''<iframe src=["'](.*?)["']''',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL|EcQxOa3RJm86WjTKA.IGNORECASE)
				R9b8gUvoB4wOfkTIjlEsZrM5LtinpS = GmYolHzab0xs8F6f[0] if GmYolHzab0xs8F6f else fy8iFgEkrO12NR9TWBI35sjY6qHvV
				if '/iframe/' in R9b8gUvoB4wOfkTIjlEsZrM5LtinpS:
					E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',R9b8gUvoB4wOfkTIjlEsZrM5LtinpS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMAABDO-PLAY-3rd')
					FGRX4myP68S = E6ECvznP9m5sWFMu.content
					jxdOw4gRmFl = EcQxOa3RJm86WjTKA.findall('version&quot;:&quot;(.*?)&',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
					jxdOw4gRmFl = jxdOw4gRmFl[0]
					naBFTDfp6lmKjeOywg87IAcb = {}
					naBFTDfp6lmKjeOywg87IAcb['X-Inertia-Partial-Component'] = 'files/mirror/video'
					naBFTDfp6lmKjeOywg87IAcb['X-Inertia'] = 'true'
					naBFTDfp6lmKjeOywg87IAcb['X-Inertia-Partial-Data'] = 'streams'
					naBFTDfp6lmKjeOywg87IAcb['X-Inertia-Version'] = jxdOw4gRmFl
					E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',R9b8gUvoB4wOfkTIjlEsZrM5LtinpS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,naBFTDfp6lmKjeOywg87IAcb,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMAABDO-PLAY-4th')
					FGRX4myP68S = E6ECvznP9m5sWFMu.content
					PrJUiDuq089W5 = LB7TcZnGYdfw5lWU1RH3Oztu9PyA('dict',FGRX4myP68S)
					groups = PrJUiDuq089W5['props']['streams']['data']
					for group in groups:
						OOnVxtP0TNWsci6HrEGqBm9boKF7g = group['label'].replace(' (source)',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
						J69CtxLrSqTgkXPiIEGuUV3sy4K = group['mirrors']
						for OlbVXYyNzgDkC7W8 in J69CtxLrSqTgkXPiIEGuUV3sy4K:
							A8ECQ0qwTRzPifOGW76FK35uUvhe = OlbVXYyNzgDkC7W8['driver']
							bigdh7fpZYl4aT2keV = 'http:'+OlbVXYyNzgDkC7W8['link']+'?named='+A8ECQ0qwTRzPifOGW76FK35uUvhe+'__watch____'+OOnVxtP0TNWsci6HrEGqBm9boKF7g
							hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"downs"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)" title="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,name in items:
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+name+'__download'
			if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = 'http:'+bigdh7fpZYl4aT2keV
			hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(hFzEyHWOoRxG,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'-')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/search/'+search+'.html'
	HAsKeZdTbqjPI1WY(url)
	return
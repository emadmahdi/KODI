# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'ALARAB'
headers = {'User-Agent':fy8iFgEkrO12NR9TWBI35sjY6qHvV}
K2l9rLfvoXxyZ4NYapO = '_KLA_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==10: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==11: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url)
	elif mode==12: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==13: OmsWt89dSA5HyCZ4wL = eQgbVPaIBvTn8fsjJRt241(url)
	elif mode==14: OmsWt89dSA5HyCZ4wL = Voyqwkr1g8BY2LJXz3u()
	elif mode==15: OmsWt89dSA5HyCZ4wL = PFuJMjpldvbUaWA4KgYfk()
	elif mode==16: OmsWt89dSA5HyCZ4wL = gfBmKIyDUChEH4VYNPdXs9()
	elif mode==19: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,19,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'آخر الإضافات',fy8iFgEkrO12NR9TWBI35sjY6qHvV,14)
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'مسلسلات رمضان',fy8iFgEkrO12NR9TWBI35sjY6qHvV,15)
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ALARAB-MENU-1st')
	z6PX2p7diaskQElBOvMRNcHwqG5D=EcQxOa3RJm86WjTKA.findall('id="nav-slider"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	ERKtNZxuvlnL3wz196bd2 = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)<',ERKtNZxuvlnL3wz196bd2,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title in items:
		bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
		title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
		OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,11)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('id="navbar"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	OOCx0SzAcisQIJGM6DZkopvB3 = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)<',OOCx0SzAcisQIJGM6DZkopvB3,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title in items:
		bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
		OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,11)
	return FGRX4myP68S
def PFuJMjpldvbUaWA4KgYfk():
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'جميع المسلسلات العربية',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/view-8/مسلسلات-عربية',11)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مسلسلات السنة الأخيرة',fy8iFgEkrO12NR9TWBI35sjY6qHvV,16)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مسلسلات رمضان الأخيرة 1',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/view-8/مسلسلات-رمضان-2022',11)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مسلسلات رمضان الأخيرة 2',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/view-8/مسلسلات-رمضان-2023',11)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مسلسلات رمضان 2023',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/ramadan2023/مصرية',11)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مسلسلات رمضان 2022',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/ramadan2022/مصرية',11)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مسلسلات رمضان 2021',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/ramadan2021/مصرية',11)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مسلسلات رمضان 2020',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/ramadan2020/مصرية',11)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مسلسلات رمضان 2019',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/ramadan2019/مصرية',11)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مسلسلات رمضان 2018',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/ramadan2018/مصرية',11)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مسلسلات رمضان 2017',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/ramadan2017/مصرية',11)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مسلسلات رمضان 2016',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/ramadan2016/مصرية',11)
	return
def Voyqwkr1g8BY2LJXz3u():
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,True,'ALARAB-LATEST-1st')
	z6PX2p7diaskQElBOvMRNcHwqG5D=EcQxOa3RJm86WjTKA.findall('heading-top(.*?)div class=',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]+z6PX2p7diaskQElBOvMRNcHwqG5D[1]
	items=EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
		url = BOI3t1w8qfHAb0Kl4oMye7haEWS + bigdh7fpZYl4aT2keV
		if 'series' in url: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,11,POjaBmHqzpsx1IYw7kQM4R)
		else: OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,url,12,POjaBmHqzpsx1IYw7kQM4R)
	return
def HAsKeZdTbqjPI1WY(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,True,True,'ALARAB-TITLES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('video-category(.*?)right_content',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not z6PX2p7diaskQElBOvMRNcHwqG5D: return
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	IXlUkiwca1Yh5AQ9PNV3W2Cv4 = False
	items = EcQxOa3RJm86WjTKA.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	cmDaLEqWlT7GhonIdX5k1zHQjSiupe,v2vJe7KGUfi0xjhpB4Droq3s5kPF = [],[]
	for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
		if title==fy8iFgEkrO12NR9TWBI35sjY6qHvV: title = bigdh7fpZYl4aT2keV.split('/')[-1].replace('-',ksJdoFWhxTz8Y2N7bOZE)
		hdmfg3T7CarEeB6lyYGN4kxw = EcQxOa3RJm86WjTKA.findall('(\d+)',title,EcQxOa3RJm86WjTKA.DOTALL)
		if hdmfg3T7CarEeB6lyYGN4kxw: hdmfg3T7CarEeB6lyYGN4kxw = int(hdmfg3T7CarEeB6lyYGN4kxw[0])
		else: hdmfg3T7CarEeB6lyYGN4kxw = 0
		v2vJe7KGUfi0xjhpB4Droq3s5kPF.append([POjaBmHqzpsx1IYw7kQM4R,bigdh7fpZYl4aT2keV,title,hdmfg3T7CarEeB6lyYGN4kxw])
	v2vJe7KGUfi0xjhpB4Droq3s5kPF = sorted(v2vJe7KGUfi0xjhpB4Droq3s5kPF, reverse=True, key=lambda key: key[3])
	for POjaBmHqzpsx1IYw7kQM4R,bigdh7fpZYl4aT2keV,title,hdmfg3T7CarEeB6lyYGN4kxw in v2vJe7KGUfi0xjhpB4Droq3s5kPF:
		bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS + bigdh7fpZYl4aT2keV
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		title = title.replace('عالية على العرب',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		title = title.replace('مشاهدة مباشرة',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		title = title.replace('اون لاين',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		title = title.replace('اونلاين',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		title = title.replace('بجودة عالية',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		title = title.replace('جودة عالية',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		title = title.replace('بدون تحميل',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		title = title.replace('على العرب',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		title = title.replace('مباشرة',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		title = title.strip(ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE)
		title = '_MOD_'+title
		D4DQ6k0oS39GKbZrthnsTB = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) الحلقة \d+',title,EcQxOa3RJm86WjTKA.DOTALL)
			if RrzpbE3t9woCk7MXS0GvNdi1BcV: D4DQ6k0oS39GKbZrthnsTB = RrzpbE3t9woCk7MXS0GvNdi1BcV[0]
		if D4DQ6k0oS39GKbZrthnsTB not in cmDaLEqWlT7GhonIdX5k1zHQjSiupe:
			cmDaLEqWlT7GhonIdX5k1zHQjSiupe.append(D4DQ6k0oS39GKbZrthnsTB)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+D4DQ6k0oS39GKbZrthnsTB,bigdh7fpZYl4aT2keV,13,POjaBmHqzpsx1IYw7kQM4R)
				IXlUkiwca1Yh5AQ9PNV3W2Cv4 = True
			elif 'series' in bigdh7fpZYl4aT2keV:
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,11,POjaBmHqzpsx1IYw7kQM4R)
				IXlUkiwca1Yh5AQ9PNV3W2Cv4 = True
			else:
				OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,12,POjaBmHqzpsx1IYw7kQM4R)
				IXlUkiwca1Yh5AQ9PNV3W2Cv4 = True
	if IXlUkiwca1Yh5AQ9PNV3W2Cv4:
		items = EcQxOa3RJm86WjTKA.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,jmI9qRnVJo2a3tpcH8gfYkP in items:
			url = BOI3t1w8qfHAb0Kl4oMye7haEWS + bigdh7fpZYl4aT2keV
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+jmI9qRnVJo2a3tpcH8gfYkP,url,11)
	return
def eQgbVPaIBvTn8fsjJRt241(url):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,True,'ALARAB-EPISODES-1st')
	tKWF9uPXTEifS1hmY = EcQxOa3RJm86WjTKA.findall('href="(/series.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	YLKFRH6sSIrznXBg = BOI3t1w8qfHAb0Kl4oMye7haEWS+tKWF9uPXTEifS1hmY[0]
	OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(YLKFRH6sSIrznXBg)
	return
def rr7SfotkneX85Klup(url):
	XoSyx7p6dqZ1CF8 = []
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(d9vcuo3Hy7RhAk2,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,True,'ALARAB-PLAY-1st')
	YLKFRH6sSIrznXBg = EcQxOa3RJm86WjTKA.findall('class="resp-iframe" src="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if YLKFRH6sSIrznXBg:
		YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg[0]
		zzECVswWcGAIXhrQlZ7jMokugnv = EcQxOa3RJm86WjTKA.findall('^(http.*?)(http.*?)$',YLKFRH6sSIrznXBg,EcQxOa3RJm86WjTKA.DOTALL)
		if zzECVswWcGAIXhrQlZ7jMokugnv:
			lUT6n1NfYxdp2IscbE8oq = zzECVswWcGAIXhrQlZ7jMokugnv[0][0]
			U3VsdMbJnlLSiIfOk5,ee0jbsxfaiNQgtp9HnALcUqYD3vMdK = zzECVswWcGAIXhrQlZ7jMokugnv[0][1].rsplit('/',1)
			MYWwFs7XA2 = U3VsdMbJnlLSiIfOk5+'?named=__watch'
			XoSyx7p6dqZ1CF8.append(MYWwFs7XA2)
			hL4w3zgankZR75698QCyi = lUT6n1NfYxdp2IscbE8oq+ee0jbsxfaiNQgtp9HnALcUqYD3vMdK
		else:
			soEymUvkt19PQXVjzKau6x5 = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,False,'ALARAB-PLAY-2nd')
			YLKFRH6sSIrznXBg = EcQxOa3RJm86WjTKA.findall('"src": "(.*?)"',soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
			if YLKFRH6sSIrznXBg:
				YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg[0]+'?named=__watch__m3u8'
				XoSyx7p6dqZ1CF8.append(YLKFRH6sSIrznXBg)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('searchBox(.*?)<style>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		YLKFRH6sSIrznXBg = EcQxOa3RJm86WjTKA.findall('href="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if YLKFRH6sSIrznXBg:
			YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg[0]+'?named=__watch'
			XoSyx7p6dqZ1CF8.append(YLKFRH6sSIrznXBg)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(XoSyx7p6dqZ1CF8,BfWYUAnyg6eONLjiuE,'video',url)
	return
def gfBmKIyDUChEH4VYNPdXs9():
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,True,'ALARAB-RAMADAN-1st')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('id="content_sec"(.*?)id="left_content"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	JJXBUNiwvdxOF4uck = EcQxOa3RJm86WjTKA.findall('/ramadan([0-9]+)/',str(items),EcQxOa3RJm86WjTKA.DOTALL)
	JJXBUNiwvdxOF4uck = JJXBUNiwvdxOF4uck[0]
	for bigdh7fpZYl4aT2keV,title in items:
		url = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
		title = title.strip(ksJdoFWhxTz8Y2N7bOZE)+ksJdoFWhxTz8Y2N7bOZE+JJXBUNiwvdxOF4uck
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,11)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	CE6HW2phYix9XvVdfqe1ObQIFl5mMj = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS + "/q/" + CE6HW2phYix9XvVdfqe1ObQIFl5mMj
	OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url)
	return
# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'CIMANOW'
K2l9rLfvoXxyZ4NYapO = '_CMN_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['قائمتي']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==300: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==301: OmsWt89dSA5HyCZ4wL = vloIZHenE7imycDM2tPQ(url)
	elif mode==302: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url)
	elif mode==303: OmsWt89dSA5HyCZ4wL = b2sn91A0exviPqhl65L7BQFr(url)
	elif mode==304: OmsWt89dSA5HyCZ4wL = eQgbVPaIBvTn8fsjJRt241(url)
	elif mode==305: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==306: OmsWt89dSA5HyCZ4wL = EEzGNBZSCnKkLJQa97fvqjeFoT()
	elif mode==309: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,309,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/home',fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMANOW-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('<header>(.*?)</header>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	items = EcQxOa3RJm86WjTKA.findall('<li><a href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title in items:
		title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
		if not any(value in title for value in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o):
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,301)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	vloIZHenE7imycDM2tPQ(BOI3t1w8qfHAb0Kl4oMye7haEWS+'/home',FGRX4myP68S)
	return FGRX4myP68S
def EEzGNBZSCnKkLJQa97fvqjeFoT():
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def vloIZHenE7imycDM2tPQ(url,FGRX4myP68S=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if not FGRX4myP68S:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMANOW-SUBMENU-1st')
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
	iYMzQVNL2h4IRemt = 0
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('(<section>.*?</section>)',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		for wlJ6d8hEvpoMNSCmU in z6PX2p7diaskQElBOvMRNcHwqG5D:
			iYMzQVNL2h4IRemt += 1
			items = EcQxOa3RJm86WjTKA.findall('<section>.<span>(.*?)<(.*?)href="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for title,lASFdTcr0oWRmuxj,bigdh7fpZYl4aT2keV in items:
				title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
				if title==fy8iFgEkrO12NR9TWBI35sjY6qHvV: title = 'بووووو'
				if 'em><a' not in lASFdTcr0oWRmuxj:
					if wlJ6d8hEvpoMNSCmU.count('/category/')>0:
						K7Kt5Zfpv10oNX = EcQxOa3RJm86WjTKA.findall('href="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
						for bigdh7fpZYl4aT2keV in K7Kt5Zfpv10oNX:
							title = bigdh7fpZYl4aT2keV.split('/')[-2]
							OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,301)
						continue
					else: bigdh7fpZYl4aT2keV = url+'?sequence='+str(iYMzQVNL2h4IRemt)
				if not any(value in title for value in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o):
					OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,302)
	else: HAsKeZdTbqjPI1WY(url,FGRX4myP68S)
	return
def HAsKeZdTbqjPI1WY(url,FGRX4myP68S=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if FGRX4myP68S==fy8iFgEkrO12NR9TWBI35sjY6qHvV:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMANOW-TITLES-1st')
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
	if '?sequence=' in url:
		url,iYMzQVNL2h4IRemt = url.split('?sequence=')
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('(<section>.*?</section>)',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[int(iYMzQVNL2h4IRemt)-1]
	else:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"posts"(.*?)</body>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	items = EcQxOa3RJm86WjTKA.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	cmDaLEqWlT7GhonIdX5k1zHQjSiupe = []
	for bigdh7fpZYl4aT2keV,data,POjaBmHqzpsx1IYw7kQM4R in items:
		title = EcQxOa3RJm86WjTKA.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,EcQxOa3RJm86WjTKA.DOTALL)
		if title: title = title[0][2].replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE)
		if not title or title==fy8iFgEkrO12NR9TWBI35sjY6qHvV:
			title = EcQxOa3RJm86WjTKA.findall('title">.*?</em>(.*?)<',data,EcQxOa3RJm86WjTKA.DOTALL)
			if title: title = title[0].replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE)
			if not title or title==fy8iFgEkrO12NR9TWBI35sjY6qHvV:
				title = EcQxOa3RJm86WjTKA.findall('title">(.*?)<',data,EcQxOa3RJm86WjTKA.DOTALL)
				title = title[0].replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE)
		title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
		title = title.replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE)
		if title not in cmDaLEqWlT7GhonIdX5k1zHQjSiupe:
			cmDaLEqWlT7GhonIdX5k1zHQjSiupe.append(title)
			OOCx0SzAcisQIJGM6DZkopvB3 = bigdh7fpZYl4aT2keV+data+POjaBmHqzpsx1IYw7kQM4R
			if '/selary/' in OOCx0SzAcisQIJGM6DZkopvB3 or 'مسلسل' in OOCx0SzAcisQIJGM6DZkopvB3 or '"episode"' in OOCx0SzAcisQIJGM6DZkopvB3:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,303,POjaBmHqzpsx1IYw7kQM4R)
			else: OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,305,POjaBmHqzpsx1IYw7kQM4R)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"pagination"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('<li><a href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,302)
	return
def b2sn91A0exviPqhl65L7BQFr(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMANOW-SEASONS-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	name = EcQxOa3RJm86WjTKA.findall('<title>(.*?)</title>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	name = name[0].replace('| سيما ناو',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('Cima Now',fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE)
	name = name.split('الحلقة')[0].strip(ksJdoFWhxTz8Y2N7bOZE)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('<section(.*?)</section>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if len(items)>1:
			for bigdh7fpZYl4aT2keV,title in items:
				title = name+' - '+title.replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE)
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,304)
		else: eQgbVPaIBvTn8fsjJRt241(url)
	return
def eQgbVPaIBvTn8fsjJRt241(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMANOW-EPISODES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	if '/selary/' not in url:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"episodes"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			title = title.replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE)
			title = 'الحلقة '+title
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,305)
	else:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"details"(.*?)"related"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
			title = title.replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE)
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,305,POjaBmHqzpsx1IYw7kQM4R)
	return
def rr7SfotkneX85Klup(url):
	YLKFRH6sSIrznXBg = url+'watching/'
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,'GET',YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMANOW-PLAY-5th')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	XoSyx7p6dqZ1CF8 = []
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"download"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?</i>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			title = title.replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE)
			OOnVxtP0TNWsci6HrEGqBm9boKF7g = EcQxOa3RJm86WjTKA.findall('\d\d\d+',title,EcQxOa3RJm86WjTKA.DOTALL)
			if OOnVxtP0TNWsci6HrEGqBm9boKF7g:
				OOnVxtP0TNWsci6HrEGqBm9boKF7g = '____'+OOnVxtP0TNWsci6HrEGqBm9boKF7g[0]
				title = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,'name')
			else: OOnVxtP0TNWsci6HrEGqBm9boKF7g = fy8iFgEkrO12NR9TWBI35sjY6qHvV
			R9b8gUvoB4wOfkTIjlEsZrM5LtinpS = bigdh7fpZYl4aT2keV+'?named='+title+'__download'+OOnVxtP0TNWsci6HrEGqBm9boKF7g
			XoSyx7p6dqZ1CF8.append(R9b8gUvoB4wOfkTIjlEsZrM5LtinpS)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"watch"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		zzECVswWcGAIXhrQlZ7jMokugnv = EcQxOa3RJm86WjTKA.findall('"embed".*?src="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV in zzECVswWcGAIXhrQlZ7jMokugnv:
			if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = 'http:'+bigdh7fpZYl4aT2keV
			title = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,'name')
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+title+'__embed'
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
		zzECVswWcGAIXhrQlZ7jMokugnv = [BOI3t1w8qfHAb0Kl4oMye7haEWS+'/wp-content/themes/Cima%20Now%20New/core.php']
		if zzECVswWcGAIXhrQlZ7jMokugnv:
			items = EcQxOa3RJm86WjTKA.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for KKb4FNO1DIREh,id,title in items:
				title = title.replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE)
				bigdh7fpZYl4aT2keV = zzECVswWcGAIXhrQlZ7jMokugnv[0]+'?action=switch&index='+KKb4FNO1DIREh+'&id='+id+'?named='+title+'__watch'
				XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(XoSyx7p6dqZ1CF8,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS + '/?s='+search
	HAsKeZdTbqjPI1WY(url)
	return
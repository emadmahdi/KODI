# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'ARABSEED'
headers = {'User-Agent':j4lUV5BzHDI6EN()}
K2l9rLfvoXxyZ4NYapO = '_ARS_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==250: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==251: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,text)
	elif mode==252: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==253: OmsWt89dSA5HyCZ4wL = eQgbVPaIBvTn8fsjJRt241(url)
	elif mode==254: OmsWt89dSA5HyCZ4wL = F4ehkvPDxXU(url,'CATEGORIES___'+text)
	elif mode==255: OmsWt89dSA5HyCZ4wL = F4ehkvPDxXU(url,'FILTERS___'+text)
	elif mode==256: OmsWt89dSA5HyCZ4wL = vloIZHenE7imycDM2tPQ(url,text)
	elif mode==259: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/main',fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ARABSEED-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,259,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فلتر محدد',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/category/اخرى',254)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فلتر كامل',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/category/اخرى',255)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'المميزة',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/main',251,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'featured_main')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'جديد الأفلام',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/main',251,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'new_movies')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'جديد الحلقات',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/main',251,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'new_episodes')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'المضاف حديثاً',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/latest',251,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'lastest')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	UgbWFLzrCA5RMo7tjwNmdyc68khBGn = EcQxOa3RJm86WjTKA.findall('class="MenuHeader"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	OOCx0SzAcisQIJGM6DZkopvB3 = UgbWFLzrCA5RMo7tjwNmdyc68khBGn[0]
	w7gedkFbJvcqu0fzW43NpyUP = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)<',OOCx0SzAcisQIJGM6DZkopvB3,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title in w7gedkFbJvcqu0fzW43NpyUP:
		title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
		if title not in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o and title!=fy8iFgEkrO12NR9TWBI35sjY6qHvV:
			if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,256)
	return FGRX4myP68S
def vloIZHenE7imycDM2tPQ(url,type):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ARABSEED-SUBMENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	if 'class="SliderInSection' in FGRX4myP68S: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الأكثر مشاهدة',url,251,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'most')
	if 'class="MainSlides' in FGRX4myP68S: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'المميزة',url,251,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'featured')
	if 'class="LinksList' in FGRX4myP68S:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="LinksList(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			if len(z6PX2p7diaskQElBOvMRNcHwqG5D)>1 and type=='new_episodes': wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[1]
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)"(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title in items:
				D4DQ6k0oS39GKbZrthnsTB = EcQxOa3RJm86WjTKA.findall('</i>(.*?)<span>(.*?)<',title,EcQxOa3RJm86WjTKA.DOTALL)
				try: TYfRSPL2HA3GuXIbgjyzBN69Wms = D4DQ6k0oS39GKbZrthnsTB[0][0].replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE)
				except: TYfRSPL2HA3GuXIbgjyzBN69Wms = fy8iFgEkrO12NR9TWBI35sjY6qHvV
				try: IaMAd73b4S6 = D4DQ6k0oS39GKbZrthnsTB[0][1].replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE)
				except: IaMAd73b4S6 = fy8iFgEkrO12NR9TWBI35sjY6qHvV
				D4DQ6k0oS39GKbZrthnsTB = TYfRSPL2HA3GuXIbgjyzBN69Wms+ksJdoFWhxTz8Y2N7bOZE+IaMAd73b4S6
				if '<strong>' in title:
					BuiQYKJkz8h0O9tjWD4wceR6lNm = EcQxOa3RJm86WjTKA.findall('</i>(.*?)<',title,EcQxOa3RJm86WjTKA.DOTALL)
					if BuiQYKJkz8h0O9tjWD4wceR6lNm: D4DQ6k0oS39GKbZrthnsTB = BuiQYKJkz8h0O9tjWD4wceR6lNm[0]
				if not D4DQ6k0oS39GKbZrthnsTB:
					BuiQYKJkz8h0O9tjWD4wceR6lNm = EcQxOa3RJm86WjTKA.findall('alt="(.*?)"',title,EcQxOa3RJm86WjTKA.DOTALL)
					if BuiQYKJkz8h0O9tjWD4wceR6lNm: D4DQ6k0oS39GKbZrthnsTB = BuiQYKJkz8h0O9tjWD4wceR6lNm[0]
				if D4DQ6k0oS39GKbZrthnsTB:
					if 'key=' in bigdh7fpZYl4aT2keV: type = bigdh7fpZYl4aT2keV.split('key=')[1]
					else: type = 'newest'
					D4DQ6k0oS39GKbZrthnsTB = D4DQ6k0oS39GKbZrthnsTB.strip(ksJdoFWhxTz8Y2N7bOZE)
					OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+D4DQ6k0oS39GKbZrthnsTB,bigdh7fpZYl4aT2keV,251,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,type)
	return
def HAsKeZdTbqjPI1WY(url,type):
	no84RQZzgM,data,items = 'GET',fy8iFgEkrO12NR9TWBI35sjY6qHvV,[]
	if type=='filters':
		if '?' in url:
			g7ew6IPUbjnCiX39ksDqcmR5FdHx01,gWBLDSlZGwqxHT = 'POST',{}
			YLKFRH6sSIrznXBg,LLd3n6b1OUJPCVYvtc2yMSp5 = url.split('?')
			KkS426yjbo8xFvBMVig5YcLCH = LLd3n6b1OUJPCVYvtc2yMSp5.split('&')
			for ZUcBH6T19kAxhs in KkS426yjbo8xFvBMVig5YcLCH:
				key,value = ZUcBH6T19kAxhs.split('=')
				gWBLDSlZGwqxHT[key] = value
			if KkS426yjbo8xFvBMVig5YcLCH: no84RQZzgM,url,data = g7ew6IPUbjnCiX39ksDqcmR5FdHx01,YLKFRH6sSIrznXBg,gWBLDSlZGwqxHT
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,no84RQZzgM,url,data,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ARABSEED-TITLES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	if type=='filters': z6PX2p7diaskQElBOvMRNcHwqG5D = [FGRX4myP68S]
	elif 'featured' in type: z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="MainSlides(.*?)class="LinksList',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	elif type=='new_movies': z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('جديد الافلام.*?class="SliderInSection"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	elif type=='new_episodes': z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('جديد الحلقات.*?class="SliderInSection"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	elif type=='most': z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="SliderInSection(.*?)class="LinksList',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	else: z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="Blocks-UL"(.*?)class="AboElSeed"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if 'featured' in type:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		X6HcPU541ZJN2Rk = EcQxOa3RJm86WjTKA.findall('href="(.*?)" title="(.*?)".*?data-lazy.*? (src|data-image)="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if X6HcPU541ZJN2Rk:
			XoSyx7p6dqZ1CF8,WFlpmsYGKNy,T1oRfgvV6A4Wrq2peXI,llULprvZxA9IyqF1kWaifs8g = zip(*X6HcPU541ZJN2Rk)
			items = zip(XoSyx7p6dqZ1CF8,llULprvZxA9IyqF1kWaifs8g,WFlpmsYGKNy)
	else:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('LoadingArea.*? href="(.*?)".*? data-\w{3,5}="(.*?)".*? alt="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	cmDaLEqWlT7GhonIdX5k1zHQjSiupe = []
	for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
		if 'WWE' in title: continue
		title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
		if 'الحلقة' in title:
			RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) الحلقة \d+',title,EcQxOa3RJm86WjTKA.DOTALL)
			if RrzpbE3t9woCk7MXS0GvNdi1BcV:
				title = '_MOD_' + RrzpbE3t9woCk7MXS0GvNdi1BcV[0]
				if title not in cmDaLEqWlT7GhonIdX5k1zHQjSiupe:
					cmDaLEqWlT7GhonIdX5k1zHQjSiupe.append(title)
					OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,253,POjaBmHqzpsx1IYw7kQM4R)
			else: OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,252,POjaBmHqzpsx1IYw7kQM4R)
		elif '/selary/' in bigdh7fpZYl4aT2keV or 'مسلسل' in title:
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,253,POjaBmHqzpsx1IYw7kQM4R)
		else:
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,252,POjaBmHqzpsx1IYw7kQM4R)
	if type in ['newest','best','most']:
		items = EcQxOa3RJm86WjTKA.findall('page-numbers" href="(.*?)">(.*?)<',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
			bigdh7fpZYl4aT2keV = IVcCL3aAfU9wS7kWev1g2XBjZRJ(bigdh7fpZYl4aT2keV)
			title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,251,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,type)
	return
def eQgbVPaIBvTn8fsjJRt241(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ARABSEED-EPISODES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	FGRX4myP68S = FGRX4myP68S[10000:]
	items = EcQxOa3RJm86WjTKA.findall('data-src="(.*?)".*?alt="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not items: return
	POjaBmHqzpsx1IYw7kQM4R,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(ksJdoFWhxTz8Y2N7bOZE)
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(ksJdoFWhxTz8Y2N7bOZE)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="ContainerEpisodesList"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?<em>(.*?)</em>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,RrzpbE3t9woCk7MXS0GvNdi1BcV in items:
			title = name+' - الحلقة رقم '+RrzpbE3t9woCk7MXS0GvNdi1BcV
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,252,POjaBmHqzpsx1IYw7kQM4R)
	else: OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+'ملف التشغيل',url,252,POjaBmHqzpsx1IYw7kQM4R)
	return
def ZZHeG1sBoJTNjSAaXFhI48rE2(title,bigdh7fpZYl4aT2keV):
	D4DQ6k0oS39GKbZrthnsTB = EcQxOa3RJm86WjTKA.findall('[a-zA-Z-]+',title,EcQxOa3RJm86WjTKA.DOTALL)
	if D4DQ6k0oS39GKbZrthnsTB: title = D4DQ6k0oS39GKbZrthnsTB[0]
	else: title = title+ksJdoFWhxTz8Y2N7bOZE+VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,'name')
	title = title.replace('عرب سيد',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('مباشر',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('مشاهدة',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	title = title.replace('ٍ',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	title = title.replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE)
	return title
def rr7SfotkneX85Klup(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ARABSEED-PLAY-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	YLKFRH6sSIrznXBg = E6ECvznP9m5sWFMu.url
	A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(YLKFRH6sSIrznXBg,'url')
	headers['Referer'] = A8ECQ0qwTRzPifOGW76FK35uUvhe+'/'
	HtbGfuVNYUsOqvB379PQ8XDS1,NN4AdqXOiRp1gfzns6lHmhG8Ctw,XoSyx7p6dqZ1CF8 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,[]
	cm0CBOpeNshPZLjzoWS = EcQxOa3RJm86WjTKA.findall('class="WatchButtons".*?href="(.*?)" class="(watch.*?)".*?href="(.*?)" class="(download.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if cm0CBOpeNshPZLjzoWS: HtbGfuVNYUsOqvB379PQ8XDS1,zSydkVHNCriWaqT8ltOmbnuoKDI,NN4AdqXOiRp1gfzns6lHmhG8Ctw,HE7eaGoC6ixPIzV93A = cm0CBOpeNshPZLjzoWS[0]
	else:
		cm0CBOpeNshPZLjzoWS = EcQxOa3RJm86WjTKA.findall('class="WatchButtons".*?href="(.*?)" class="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if cm0CBOpeNshPZLjzoWS:
			bigdh7fpZYl4aT2keV,zSydkVHNCriWaqT8ltOmbnuoKDI = cm0CBOpeNshPZLjzoWS[0]
			if 'watch' in zSydkVHNCriWaqT8ltOmbnuoKDI: HtbGfuVNYUsOqvB379PQ8XDS1 = bigdh7fpZYl4aT2keV
			else: NN4AdqXOiRp1gfzns6lHmhG8Ctw = bigdh7fpZYl4aT2keV
	if HtbGfuVNYUsOqvB379PQ8XDS1:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',HtbGfuVNYUsOqvB379PQ8XDS1,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ARABSEED-PLAY-2nd')
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="WatcherArea(.*?</ul>)',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			Z8mPo7yQLdXJvOrzD1CkBUVHgqWp4j = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			Z8mPo7yQLdXJvOrzD1CkBUVHgqWp4j = Z8mPo7yQLdXJvOrzD1CkBUVHgqWp4j.replace('</ul>','<h3>')
			Z8mPo7yQLdXJvOrzD1CkBUVHgqWp4j = Z8mPo7yQLdXJvOrzD1CkBUVHgqWp4j.replace('<h3>','<h3><h3>')
			VuGmoESTAfXlv5tD76PW1Masq0peB = EcQxOa3RJm86WjTKA.findall('<h3>.*?(\d+)(.*?)<h3>',Z8mPo7yQLdXJvOrzD1CkBUVHgqWp4j,EcQxOa3RJm86WjTKA.DOTALL)
			if not VuGmoESTAfXlv5tD76PW1Masq0peB: VuGmoESTAfXlv5tD76PW1Masq0peB = [(fy8iFgEkrO12NR9TWBI35sjY6qHvV,Z8mPo7yQLdXJvOrzD1CkBUVHgqWp4j)]
			for OOnVxtP0TNWsci6HrEGqBm9boKF7g,wlJ6d8hEvpoMNSCmU in VuGmoESTAfXlv5tD76PW1Masq0peB:
				if OOnVxtP0TNWsci6HrEGqBm9boKF7g: OOnVxtP0TNWsci6HrEGqBm9boKF7g = '____'+OOnVxtP0TNWsci6HrEGqBm9boKF7g
				items = EcQxOa3RJm86WjTKA.findall('data-link="(.*?)".*?<span>(.*?)</span>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
				for bigdh7fpZYl4aT2keV,name in items:
					if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = 'http:'+bigdh7fpZYl4aT2keV
					bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+name+'__watch'+OOnVxtP0TNWsci6HrEGqBm9boKF7g
					XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
		zzECVswWcGAIXhrQlZ7jMokugnv = EcQxOa3RJm86WjTKA.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if not zzECVswWcGAIXhrQlZ7jMokugnv: zzECVswWcGAIXhrQlZ7jMokugnv = EcQxOa3RJm86WjTKA.findall('class="containerIframe".*? SRC="(.*?)".*? HEIGHT="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if zzECVswWcGAIXhrQlZ7jMokugnv:
			bigdh7fpZYl4aT2keV,OOnVxtP0TNWsci6HrEGqBm9boKF7g = zzECVswWcGAIXhrQlZ7jMokugnv[0]
			name = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,'name')
			if '%' in OOnVxtP0TNWsci6HrEGqBm9boKF7g: bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+name+'__embed__'
			else: bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+name+'__embed____'+OOnVxtP0TNWsci6HrEGqBm9boKF7g
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	if NN4AdqXOiRp1gfzns6lHmhG8Ctw:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',NN4AdqXOiRp1gfzns6lHmhG8Ctw,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ARABSEED-PLAY-3rd')
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="DownloadArea(.*?)<script src=',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			Z8mPo7yQLdXJvOrzD1CkBUVHgqWp4j = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			VuGmoESTAfXlv5tD76PW1Masq0peB = EcQxOa3RJm86WjTKA.findall('class="DownloadServers(.*?)</ul>',Z8mPo7yQLdXJvOrzD1CkBUVHgqWp4j,EcQxOa3RJm86WjTKA.DOTALL)
			for wlJ6d8hEvpoMNSCmU in VuGmoESTAfXlv5tD76PW1Masq0peB:
				items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
				for bigdh7fpZYl4aT2keV,title,OOnVxtP0TNWsci6HrEGqBm9boKF7g in items:
					if not bigdh7fpZYl4aT2keV: continue
					if 'reviewstation' in bigdh7fpZYl4aT2keV: continue
					bigdh7fpZYl4aT2keV = U2Z7CVFftTmLeK3nzEbQPGga(bigdh7fpZYl4aT2keV)
					bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+title+'__download____'+OOnVxtP0TNWsci6HrEGqBm9boKF7g
					XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	NN0M3IQChd7nFLD = str(XoSyx7p6dqZ1CF8)
	RQBHPosn4XjYKhvZCOJtVMm = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(value in NN0M3IQChd7nFLD for value in RQBHPosn4XjYKhvZCOJtVMm):
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(XoSyx7p6dqZ1CF8,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if not search: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if not search: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/find/?find='+search
	HAsKeZdTbqjPI1WY(url,'search')
	return
def F4ehkvPDxXU(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter==fy8iFgEkrO12NR9TWBI35sjY6qHvV: NnQ1hEsTV7Zaz3HKdfu,QlOXcH07nRVPAZub8pD356xMvdk4 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	else: NnQ1hEsTV7Zaz3HKdfu,QlOXcH07nRVPAZub8pD356xMvdk4 = filter.split('___')
	if type=='CATEGORIES':
		if K3KSDO9Alxe6on[0]+'==' not in NnQ1hEsTV7Zaz3HKdfu: fnogyzNA30JCPMYqHTavG7ZKp = K3KSDO9Alxe6on[0]
		for pk6YWixXFSrDLKCnlN39w in range(len(K3KSDO9Alxe6on[0:-1])):
			if K3KSDO9Alxe6on[pk6YWixXFSrDLKCnlN39w]+'==' in NnQ1hEsTV7Zaz3HKdfu: fnogyzNA30JCPMYqHTavG7ZKp = K3KSDO9Alxe6on[pk6YWixXFSrDLKCnlN39w+1]
		z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&&'+fnogyzNA30JCPMYqHTavG7ZKp+'==0'
		ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&&'+fnogyzNA30JCPMYqHTavG7ZKp+'==0'
		HfvJenZmN3O8rPcshLux2EyzDWpQCb = z7VI1OaUPqs4lXxb.strip('&&')+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq.strip('&&')
		F231lsuCKnaSMdQ48W6PoL = nKT1QuLoXPc8CjyV(QlOXcH07nRVPAZub8pD356xMvdk4,'modified_filters')
		YLKFRH6sSIrznXBg = url+'//getposts??'+F231lsuCKnaSMdQ48W6PoL
	elif type=='FILTERS':
		QUFL2gEBMn63qlsmI7W = nKT1QuLoXPc8CjyV(NnQ1hEsTV7Zaz3HKdfu,'modified_values')
		QUFL2gEBMn63qlsmI7W = U2Z7CVFftTmLeK3nzEbQPGga(QUFL2gEBMn63qlsmI7W)
		if QlOXcH07nRVPAZub8pD356xMvdk4!=fy8iFgEkrO12NR9TWBI35sjY6qHvV: QlOXcH07nRVPAZub8pD356xMvdk4 = nKT1QuLoXPc8CjyV(QlOXcH07nRVPAZub8pD356xMvdk4,'modified_filters')
		if QlOXcH07nRVPAZub8pD356xMvdk4==fy8iFgEkrO12NR9TWBI35sjY6qHvV: YLKFRH6sSIrznXBg = url
		else: YLKFRH6sSIrznXBg = url+'//getposts??'+QlOXcH07nRVPAZub8pD356xMvdk4
		hL4w3zgankZR75698QCyi = bpvKh19zQGfPY8wrkFlLD3N(YLKFRH6sSIrznXBg)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'أظهار قائمة الفيديو التي تم اختيارها ',hL4w3zgankZR75698QCyi,251,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filters')
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+' [[   '+QUFL2gEBMn63qlsmI7W+'   ]]',hL4w3zgankZR75698QCyi,251,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filters')
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'POST',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ARABSEED-FILTERS_MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	wGhU3a2zlSnM = EcQxOa3RJm86WjTKA.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	mwTvf9iVZKdz2aXPjnRsFAoeGc4N5 = EcQxOa3RJm86WjTKA.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	W1A4L5P0Zc8wHnUGjVexElz = wGhU3a2zlSnM+mwTvf9iVZKdz2aXPjnRsFAoeGc4N5
	dict = {}
	for name,jLA9nhxoZbG,wlJ6d8hEvpoMNSCmU in W1A4L5P0Zc8wHnUGjVexElz:
		items = EcQxOa3RJm86WjTKA.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			w7gedkFbJvcqu0fzW43NpyUP = EcQxOa3RJm86WjTKA.findall('data-rate="(.*?)".*?<em>(.*?)</em>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			items = []
			for srR9AuG6Pf8powqU4ixL5Ecl,value in w7gedkFbJvcqu0fzW43NpyUP: items.append([srR9AuG6Pf8powqU4ixL5Ecl,fy8iFgEkrO12NR9TWBI35sjY6qHvV,value])
			jLA9nhxoZbG = 'rate'
			name = 'التقييم'
		else: jLA9nhxoZbG = items[0][1]
		if '==' not in YLKFRH6sSIrznXBg: YLKFRH6sSIrznXBg = url
		if type=='CATEGORIES':
			if fnogyzNA30JCPMYqHTavG7ZKp!=jLA9nhxoZbG: continue
			elif len(items)<=1:
				if jLA9nhxoZbG==K3KSDO9Alxe6on[-1]: HAsKeZdTbqjPI1WY(YLKFRH6sSIrznXBg)
				else: F4ehkvPDxXU(YLKFRH6sSIrznXBg,'CATEGORIES___'+HfvJenZmN3O8rPcshLux2EyzDWpQCb)
				return
			else:
				hL4w3zgankZR75698QCyi = bpvKh19zQGfPY8wrkFlLD3N(YLKFRH6sSIrznXBg)
				if jLA9nhxoZbG==K3KSDO9Alxe6on[-1]: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع ',hL4w3zgankZR75698QCyi,251,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filters')
				else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع ',YLKFRH6sSIrznXBg,254,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,HfvJenZmN3O8rPcshLux2EyzDWpQCb)
		elif type=='FILTERS':
			z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&&'+jLA9nhxoZbG+'==0'
			ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&&'+jLA9nhxoZbG+'==0'
			HfvJenZmN3O8rPcshLux2EyzDWpQCb = z7VI1OaUPqs4lXxb+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع :'+name,YLKFRH6sSIrznXBg,255,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,HfvJenZmN3O8rPcshLux2EyzDWpQCb)
		dict[jLA9nhxoZbG] = {}
		for srR9AuG6Pf8powqU4ixL5Ecl,O4On5rLamD7q1zKBo6WfF3eEbS98,value in items:
			if srR9AuG6Pf8powqU4ixL5Ecl in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
			if 'الكل' in srR9AuG6Pf8powqU4ixL5Ecl: continue
			srR9AuG6Pf8powqU4ixL5Ecl = IVcCL3aAfU9wS7kWev1g2XBjZRJ(srR9AuG6Pf8powqU4ixL5Ecl)
			c9LD37hsJzqNi2lQVWIBwFgoYy,D4DQ6k0oS39GKbZrthnsTB = srR9AuG6Pf8powqU4ixL5Ecl,srR9AuG6Pf8powqU4ixL5Ecl
			D4DQ6k0oS39GKbZrthnsTB = name+': '+c9LD37hsJzqNi2lQVWIBwFgoYy
			dict[jLA9nhxoZbG][value] = D4DQ6k0oS39GKbZrthnsTB
			z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&&'+jLA9nhxoZbG+'=='+c9LD37hsJzqNi2lQVWIBwFgoYy
			ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&&'+jLA9nhxoZbG+'=='+value
			QdzUcX2iR5 = z7VI1OaUPqs4lXxb+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq
			if type=='FILTERS':
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+D4DQ6k0oS39GKbZrthnsTB,url,255,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QdzUcX2iR5)
			elif type=='CATEGORIES' and K3KSDO9Alxe6on[-2]+'==' in NnQ1hEsTV7Zaz3HKdfu:
				F231lsuCKnaSMdQ48W6PoL = nKT1QuLoXPc8CjyV(ybEUMsLp4zBVPnuAYI0cCdowekDq,'modified_filters')
				MYWwFs7XA2 = url+'//getposts??'+F231lsuCKnaSMdQ48W6PoL
				hL4w3zgankZR75698QCyi = bpvKh19zQGfPY8wrkFlLD3N(MYWwFs7XA2)
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+D4DQ6k0oS39GKbZrthnsTB,hL4w3zgankZR75698QCyi,251,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filters')
			else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+D4DQ6k0oS39GKbZrthnsTB,url,254,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QdzUcX2iR5)
	return
K3KSDO9Alxe6on = ['category','country','release-year']
xoakH1wihmQLIsMb = ['category','country','genre','release-year','language','quality','rate']
def bpvKh19zQGfPY8wrkFlLD3N(url):
	oHQN5eWEDLPkdcz1MYtwFA8TCJjn2 = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',oHQN5eWEDLPkdcz1MYtwFA8TCJjn2)
	url = url.replace('/category/اخرى',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	if oHQN5eWEDLPkdcz1MYtwFA8TCJjn2 not in url: url = url+oHQN5eWEDLPkdcz1MYtwFA8TCJjn2
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def nKT1QuLoXPc8CjyV(p9UP6wGlC1BF7fN2,mode):
	p9UP6wGlC1BF7fN2 = p9UP6wGlC1BF7fN2.strip('&&')
	vpLWbVm35iM0l2TzYIN7,MKJaIb2sDSr4VCQGTqyX3nkWL = {},fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if '==' in p9UP6wGlC1BF7fN2:
		items = p9UP6wGlC1BF7fN2.split('&&')
		for j25T6eKhaMk3 in items:
			XJRx6urSNaOM5AfZdDsgQBYGt,value = j25T6eKhaMk3.split('==')
			vpLWbVm35iM0l2TzYIN7[XJRx6urSNaOM5AfZdDsgQBYGt] = value
	for key in xoakH1wihmQLIsMb:
		if key in list(vpLWbVm35iM0l2TzYIN7.keys()): value = vpLWbVm35iM0l2TzYIN7[key]
		else: value = '0'
		if '%' not in value: value = DVX5GWhnIxYlSd9rEuetjk40UJ(value)
		if mode=='modified_values' and value!='0': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+' + '+value
		elif mode=='modified_filters' and value!='0': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+'&&'+key+'=='+value
		elif mode=='all': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+'&&'+key+'=='+value
	MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL.strip(' + ')
	MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL.strip('&&')
	return MKJaIb2sDSr4VCQGTqyX3nkWL
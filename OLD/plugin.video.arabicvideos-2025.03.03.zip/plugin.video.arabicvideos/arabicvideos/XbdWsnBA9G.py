# -*- coding: utf-8 -*-
import sys as CfgZ0zWP5XBpoGQwLUY
D5DpyO2wPg7oL = CfgZ0zWP5XBpoGQwLUY.version_info [0] == 2
ccK5HIyfUgvOdQpWSXZtaBJ = 2048
W8WuBTGQg1Zwqy5F6xSe = 7
def zmQcCUZlPKBITW5bqx1 (rR5FPU8VhJQ):
	global Jfz4wMWSZb0BYV
	EEr5teuZbc = ord (rR5FPU8VhJQ [-1])
	ZZd5W9FVUhzu31NQyComxv = rR5FPU8VhJQ [:-1]
	sJYFyd6mZHev1IXEaMj0b = EEr5teuZbc % len (ZZd5W9FVUhzu31NQyComxv)
	qPJ7pUnt5rcm6NMaFYLSkHsGxI = ZZd5W9FVUhzu31NQyComxv [:sJYFyd6mZHev1IXEaMj0b] + ZZd5W9FVUhzu31NQyComxv [sJYFyd6mZHev1IXEaMj0b:]
	if D5DpyO2wPg7oL:
		Vv1b9fdEckNepm7 = unicode () .join ([unichr (ord (QdqoKlFn4yZUOJp1xYrNTaBSmt69hc) - ccK5HIyfUgvOdQpWSXZtaBJ - (hrazDC5q4oB + EEr5teuZbc) % W8WuBTGQg1Zwqy5F6xSe) for hrazDC5q4oB, QdqoKlFn4yZUOJp1xYrNTaBSmt69hc in enumerate (qPJ7pUnt5rcm6NMaFYLSkHsGxI)])
	else:
		Vv1b9fdEckNepm7 = str () .join ([chr (ord (QdqoKlFn4yZUOJp1xYrNTaBSmt69hc) - ccK5HIyfUgvOdQpWSXZtaBJ - (hrazDC5q4oB + EEr5teuZbc) % W8WuBTGQg1Zwqy5F6xSe) for hrazDC5q4oB, QdqoKlFn4yZUOJp1xYrNTaBSmt69hc in enumerate (qPJ7pUnt5rcm6NMaFYLSkHsGxI)])
	return eval (Vv1b9fdEckNepm7)
V3z5t4JAqyXk2fLsW1juoZ0BEp6,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye,wdftVMyzF17cYETHu=zmQcCUZlPKBITW5bqx1,zmQcCUZlPKBITW5bqx1,zmQcCUZlPKBITW5bqx1
Hr25gta6XcqO,FmYoGejTnwKME7d9zPc,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9=wdftVMyzF17cYETHu,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye,V3z5t4JAqyXk2fLsW1juoZ0BEp6
KfHAW8VGbrxi,aOQTKXFL54Nl60Zhp3MbE,jL5CrsRwebpyDVXUc1EQP=Dco0w1e5VM3YP7hLXTHBS8GtaCrO9,FmYoGejTnwKME7d9zPc,Hr25gta6XcqO
oRJAfwD957WkUyBM1Ehu8m,vU6DxuzPwMpg,I18uSKaWhgTBeYUPD4sr=jL5CrsRwebpyDVXUc1EQP,aOQTKXFL54Nl60Zhp3MbE,KfHAW8VGbrxi
o1INZ3ViQqS0Uw5z6kMjbv,s5WMHyQN4mpie,N6NGJ4vpmidqMCh7yo=I18uSKaWhgTBeYUPD4sr,vU6DxuzPwMpg,oRJAfwD957WkUyBM1Ehu8m
Gcw2nelTR864XCVruO3mAFqI5a,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7,OO9YiAQHGrLo0qpW2M3jDeXd1kx=N6NGJ4vpmidqMCh7yo,s5WMHyQN4mpie,o1INZ3ViQqS0Uw5z6kMjbv
O3OVuapf0YFjbm5oUQDg,sJw9QWiq1Kr0xfeVRI,SnhLjmfeJC=OO9YiAQHGrLo0qpW2M3jDeXd1kx,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7,Gcw2nelTR864XCVruO3mAFqI5a
QjAINyUC7MDRq5d8e4vl9,AAbvaXV2DQzfNHdm4U3tT,ggjO5CrKVRPITaesWkxD=SnhLjmfeJC,sJw9QWiq1Kr0xfeVRI,O3OVuapf0YFjbm5oUQDg
FgXzMs0YSDt,uulNDCPyef78,EQxFuqjw95WvaMm8Hnlt47XVihJ=ggjO5CrKVRPITaesWkxD,AAbvaXV2DQzfNHdm4U3tT,QjAINyUC7MDRq5d8e4vl9
ssynAg0zhSkoCpOMDV9,sIzDXlTHYUC5L3xZGnr,PlpyFa9QMKXxOD1cvHzmI=EQxFuqjw95WvaMm8Hnlt47XVihJ,uulNDCPyef78,FgXzMs0YSDt
CsDcLqQUVK4YBvHFW1,EE1jeHnIoad,LYIgTBeSmZWotDh4bnyQkvM50siu=PlpyFa9QMKXxOD1cvHzmI,sIzDXlTHYUC5L3xZGnr,ssynAg0zhSkoCpOMDV9
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = ggjO5CrKVRPITaesWkxD(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓࠨඏ")
def ugbnmWCrLpG9Av0xzocFaB5ew(hO3D6GVPY2qENv8bZWH,YMaiHbnIThsP7q=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if   hO3D6GVPY2qENv8bZWH==wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠶Ⴛ"): a57Uq6WviAyYEmVlwXzSMxh3grOHT8(YMaiHbnIThsP7q)
	elif hO3D6GVPY2qENv8bZWH==QjAINyUC7MDRq5d8e4vl9(u"࠱Ⴜ"): pass
	elif hO3D6GVPY2qENv8bZWH==QjAINyUC7MDRq5d8e4vl9(u"࠳Ⴝ"): YYuBnksbtX4WTE7ipPQmNgaZvy9U(YMaiHbnIThsP7q)
	elif hO3D6GVPY2qENv8bZWH==FgXzMs0YSDt(u"࠵Ⴞ"): dsxEzRUOf3()
	elif hO3D6GVPY2qENv8bZWH==FmYoGejTnwKME7d9zPc(u"࠷Ⴟ"): yGOXB2HjmUA1Pqgt9QIJsYNZbFp60k(YMaiHbnIThsP7q)
	elif hO3D6GVPY2qENv8bZWH==LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠹Ⴠ"): Z3Yywxf0vRcNVgeisru92KzH()
	elif hO3D6GVPY2qENv8bZWH==QjAINyUC7MDRq5d8e4vl9(u"࠻Ⴡ"): Z892VKqDTv1xsEfeoyAPG6nNWcgSm()
	elif hO3D6GVPY2qENv8bZWH==LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠽Ⴢ"): kc58wNCXd79rl1xS3ZBKfUjPm0Tby()
	elif hO3D6GVPY2qENv8bZWH==uulNDCPyef78(u"࠸Ⴣ"): sldteGVyPjbLXH4YuNhDofkZ78xr()
	elif hO3D6GVPY2qENv8bZWH==ssynAg0zhSkoCpOMDV9(u"࠲࠷࠳Ⴤ"): rQ29e5mjVKSZtGMIEAx()
	elif hO3D6GVPY2qENv8bZWH==V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠳࠸࠵Ⴥ"): XXhWcrigE1lMvTdPU39fKG()
	elif hO3D6GVPY2qENv8bZWH==ssynAg0zhSkoCpOMDV9(u"࠴࠹࠷჆"): ukWnmcTxLeJwNKz1B2GQZC()
	elif hO3D6GVPY2qENv8bZWH==Hr25gta6XcqO(u"࠵࠺࠹Ⴧ"): RDktuy08wOXv4lNoYqPHVWQ3zdsneL()
	elif hO3D6GVPY2qENv8bZWH==SnhLjmfeJC(u"࠶࠻࠴჈"): eENxRhKUkIWlV79qnJ5FTwpCOgGH()
	elif hO3D6GVPY2qENv8bZWH==wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠷࠵࠶჉"): qzv3jf2iUMoaPlOJuLgZFnQS5d()
	elif hO3D6GVPY2qENv8bZWH==AAbvaXV2DQzfNHdm4U3tT(u"࠱࠶࠸჊"): USdiZse9v1Gf547rY0n()
	elif hO3D6GVPY2qENv8bZWH==ggjO5CrKVRPITaesWkxD(u"࠲࠷࠺჋"): FncHZVQINC7lfdmitu2z1Ys0TOk6()
	elif hO3D6GVPY2qENv8bZWH==o1INZ3ViQqS0Uw5z6kMjbv(u"࠳࠸࠼჌"): PA3sqNFcRj9i5bB0gDhOvQ8ItHLz()
	elif hO3D6GVPY2qENv8bZWH==AAbvaXV2DQzfNHdm4U3tT(u"࠴࠹࠾Ⴭ"): YHKRJQq1sD6yz(EsCplGc5N4mBuYW0RVQt6b)
	elif hO3D6GVPY2qENv8bZWH==wdftVMyzF17cYETHu(u"࠵࠼࠶჎"): M70MpvtyCzk8E9jYJu()
	elif hO3D6GVPY2qENv8bZWH==oRJAfwD957WkUyBM1Ehu8m(u"࠶࠽࠱჏"): FFIXquxWtmJKDzf68()
	elif hO3D6GVPY2qENv8bZWH==Gcw2nelTR864XCVruO3mAFqI5a(u"࠷࠷࠳ა"): kzN0bPLcDgGyJfCjOWRK3pF5VqI([YMaiHbnIThsP7q],EsCplGc5N4mBuYW0RVQt6b,EsCplGc5N4mBuYW0RVQt6b,LhFAGlQ19zr)
	elif hO3D6GVPY2qENv8bZWH==Gcw2nelTR864XCVruO3mAFqI5a(u"࠱࠸࠵ბ"): wwntyGQz2YbhoXNfMFm(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧඐ"),EsCplGc5N4mBuYW0RVQt6b)
	elif hO3D6GVPY2qENv8bZWH==I18uSKaWhgTBeYUPD4sr(u"࠲࠹࠷გ"): wwntyGQz2YbhoXNfMFm(ggjO5CrKVRPITaesWkxD(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫඑ"),EsCplGc5N4mBuYW0RVQt6b)
	elif hO3D6GVPY2qENv8bZWH==C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠳࠺࠹დ"): A23jPopleNih59Xugfwts4()
	elif hO3D6GVPY2qENv8bZWH==I18uSKaWhgTBeYUPD4sr(u"࠴࠻࠻ე"): zFwJg8eaXrP1()
	elif hO3D6GVPY2qENv8bZWH==I18uSKaWhgTBeYUPD4sr(u"࠵࠼࠽ვ"): kzDcF6g7uEtSymWqbXxnQl2ipdra(sJw9QWiq1Kr0xfeVRI(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭ඒ"))
	elif hO3D6GVPY2qENv8bZWH==EE1jeHnIoad(u"࠶࠽࠹ზ"): kzDcF6g7uEtSymWqbXxnQl2ipdra(I18uSKaWhgTBeYUPD4sr(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡼࡳࡺࡺࡵࡣࡧࠪඓ"))
	elif hO3D6GVPY2qENv8bZWH==oRJAfwD957WkUyBM1Ehu8m(u"࠷࠹࠱თ"): zaSVrEi1HqZnjctTFuLsmQB7Y()
	elif hO3D6GVPY2qENv8bZWH==Gcw2nelTR864XCVruO3mAFqI5a(u"࠱࠺࠳ი"): RSV9jNkxM140qUmTl()
	elif hO3D6GVPY2qENv8bZWH==O3OVuapf0YFjbm5oUQDg(u"࠲࠻࠵კ"): b9hIe8BPDFxtm57QS1jGkr2lCH()
	elif hO3D6GVPY2qENv8bZWH==jL5CrsRwebpyDVXUc1EQP(u"࠳࠼࠷ლ"): V0VFZmTWXpLejkS32ItN9lHQ7()
	elif hO3D6GVPY2qENv8bZWH==ggjO5CrKVRPITaesWkxD(u"࠴࠽࠹მ"): w8URi7qeoOtcKZ()
	elif hO3D6GVPY2qENv8bZWH==oRJAfwD957WkUyBM1Ehu8m(u"࠵࠾࠻ნ"): NknIxsS2Bq()
	elif hO3D6GVPY2qENv8bZWH==Gcw2nelTR864XCVruO3mAFqI5a(u"࠶࠿࠶ო"): Lvp8CxloQbANerGO()
	elif hO3D6GVPY2qENv8bZWH==sJw9QWiq1Kr0xfeVRI(u"࠷࠹࠸პ"): KlHyangZspiJMwG4B6LV()
	elif hO3D6GVPY2qENv8bZWH==SnhLjmfeJC(u"࠱࠺࠺ჟ"): eiLclyGUkAh1Et682n()
	elif hO3D6GVPY2qENv8bZWH==KfHAW8VGbrxi(u"࠲࠻࠼რ"): DmH2JECZ40cuQv()
	elif hO3D6GVPY2qENv8bZWH==FgXzMs0YSDt(u"࠵࠷࠴ს"): WK35wcVTYr7Aplo(YMaiHbnIThsP7q)
	elif hO3D6GVPY2qENv8bZWH==QjAINyUC7MDRq5d8e4vl9(u"࠶࠸࠶ტ"): btfGBPRgIAskW7T3()
	elif hO3D6GVPY2qENv8bZWH==Gcw2nelTR864XCVruO3mAFqI5a(u"࠷࠹࠸უ"): FSCaWZO7sgIwkmYDt8udBX9Up()
	elif hO3D6GVPY2qENv8bZWH==FmYoGejTnwKME7d9zPc(u"࠸࠺࠳ფ"): EEKmGlgpza4tUCwxRkPoc3FATSeI9()
	elif hO3D6GVPY2qENv8bZWH==KfHAW8VGbrxi(u"࠹࠴࠶ქ"): RB65cZw0nMUp3GLWV1yxEa()
	elif hO3D6GVPY2qENv8bZWH==SnhLjmfeJC(u"࠳࠵࠸ღ"): ozs7B5fWTKAjX4gylCmviZpbL(LhFAGlQ19zr)
	elif hO3D6GVPY2qENv8bZWH==wdftVMyzF17cYETHu(u"࠴࠶࠺ყ"): mcPDrqAL95GBTaZfUtgvF0WM(EsCplGc5N4mBuYW0RVQt6b)
	elif hO3D6GVPY2qENv8bZWH==sIzDXlTHYUC5L3xZGnr(u"࠵࠷࠼შ"): h1HfXYdlKASmPvoLBb7kzD()
	elif hO3D6GVPY2qENv8bZWH==V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠶࠸࠾ჩ"): E0huTeDPIjbtcHflCxMdSqskVUX7w(jL5CrsRwebpyDVXUc1EQP(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩඔ"),EsCplGc5N4mBuYW0RVQt6b,EsCplGc5N4mBuYW0RVQt6b)
	elif hO3D6GVPY2qENv8bZWH==SnhLjmfeJC(u"࠹࠵࠶ც"): r7HMiISPDUOjLWh()
	elif hO3D6GVPY2qENv8bZWH==jL5CrsRwebpyDVXUc1EQP(u"࠺࠶࠱ძ"): qIYmtHNXPBCMG6()
	elif hO3D6GVPY2qENv8bZWH==Hr25gta6XcqO(u"࠻࠰࠳წ"): tE4opQ8FJUa5Neh1MnyKSm()
	elif hO3D6GVPY2qENv8bZWH==N6NGJ4vpmidqMCh7yo(u"࠵࠱࠵ჭ"): ffxoXPD8eFTtSpGmwdCkaJ2c(bVeH60CmPM)
	elif hO3D6GVPY2qENv8bZWH==EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠶࠲࠷ხ"): ffxoXPD8eFTtSpGmwdCkaJ2c(mmFzNZYEJpdqUro7sKMj6W2)
	elif hO3D6GVPY2qENv8bZWH==FgXzMs0YSDt(u"࠷࠳࠹ჯ"): t07U5YsNhJbPiWvG()
	elif hO3D6GVPY2qENv8bZWH==OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠸࠴࠻ჰ"): ZL2gHRX194IrVYoqcjnT(EsCplGc5N4mBuYW0RVQt6b)
	elif hO3D6GVPY2qENv8bZWH==s5WMHyQN4mpie(u"࠹࠵࠽ჱ"): nzZ2HifhoqS94yG0IMVWpB8PLJQDx()
	elif hO3D6GVPY2qENv8bZWH==C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠺࠶࠸ჲ"): W2q3wGdMhxQN()
	elif hO3D6GVPY2qENv8bZWH==ssynAg0zhSkoCpOMDV9(u"࠷࠰࠳࠲ჳ"): JFtx1C6pO5fGM()
	elif hO3D6GVPY2qENv8bZWH==O3OVuapf0YFjbm5oUQDg(u"࠱࠱࠴࠴ჴ"): Xnfl78ONgp()
	elif hO3D6GVPY2qENv8bZWH==FmYoGejTnwKME7d9zPc(u"࠲࠲࠵࠶ჵ"): kzDcF6g7uEtSymWqbXxnQl2ipdra(CsDcLqQUVK4YBvHFW1(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪඕ"))
	elif hO3D6GVPY2qENv8bZWH==EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠳࠳࠶࠸ჶ"): wOGoxyKjz2UXL6lbdESYqefDk04s()
	return
def wOGoxyKjz2UXL6lbdESYqefDk04s():
	gn2DUcWhvjpC4ZR0lr3bJO61GPVX = OdiZIyCfDUsW3JBGR2VAb.getSetting(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡥ࡭ࡹࡸࡡࡵࡧࠪඖ"))
	message = EE1jeHnIoad(u"ࠧศๆิๆ๊ࠦวๅ็ะำิࠦอศๆํหࠥํ่ࠡ࠼ࠣࠤࠥ࠭඗")+str(gn2DUcWhvjpC4ZR0lr3bJO61GPVX)+s5WMHyQN4mpie(u"ࠨࠢ࡮ࡦࡵࡹࠧ඘") if gn2DUcWhvjpC4ZR0lr3bJO61GPVX else V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠩส่ั๎ฯสࠢส่ศ๎ส้็สฮ๏้๊ส่ࠢฮํ่แสࠢะห้๐วࠨ඙")
	message = n0nFOd4yR97fQzNLSW+message+EE1jeHnIoad(u"ࠪࡠࡳํไࠡฬิ๎ิࠦวๅฤ้ࠤฯฺฺ๋ๆࠣวํࠦส฻์ํีࠥืโๆࠢส่ั๎ฯสࠢส่ศ๎ส้็สฮ๏้๊สࠩක")+T7ASIp1ZYwio9HQ8cObJK
	YYxDRTA76kwZNBqnHSdJ = jPRJMOhT415yvioG8rN9m0Q3b(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫඛ"),AAbvaXV2DQzfNHdm4U3tT(u"ࠬิั้ฮࠪග"),SnhLjmfeJC(u"࠭ล๋ไสๅࠬඝ"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧหึ฽๎้࠭ඞ"),O3OVuapf0YFjbm5oUQDg(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫඟ"),sIzDXlTHYUC5L3xZGnr(u"ࠩส่ั๎ฯสࠢส่ศ๎ส้็สฮ๏้๊ส๊ࠢ๎ࠥ฿ๅๅ์ฬࠤ๏่่ๆࠢห๋ฬࠦวๅสิ๊ฬ๋ฬࠡสสาฯ๐วาࠢฦ฽้๏ࠠอ๊าอ๋ࠥส้ใิอ๊ࠥัใ็ࠣห้า่ะหࠣห้ึ๊ࠡษ้ฮࠥะอะั๊ࠤๆ๐่ࠠา๊ࠤฬ๊ิศึฬࠤ࠳࠴้้ࠠำหู๋ࠥ็ษ๊ࠤ฾์ฯๆษࠣฮ็๎ๅࠡษ้ฮࠥฮสี฼ํ่ࠥ็๊ะ์๋ࠤๆอๆࠡษ็ฬึ์วๆฮ่๋๊ࠣࠦิล็็ࠥ฿ๆࠡษ็ะํีษࠡษ็ฮ๏ࠦสา์า๋ฬࠦไฤ่ࠣห้ฮั็ษ่ะู่ࠥโࠢําฯอัࠡษ็ะํีษࠡล๋ฮํ๋วห์ๆ๎ฬࠦ࠮࠯ࠢ฼่๊อࠠศ่๊ࠤ๏าศࠡษัฮ๏อัࠡำๅ้ࠥา่ะหูࠣ฿๐ัࠡวำห้ࠥว็ฬࠣห้หๆหำ้ฮࠥ฿ๆะๅࠣฬ฼๐ฦสࠢฦ์่ࠥไ๋ๆฬࡠࡳࡢ࡮ࠨච")+message)
	if YYxDRTA76kwZNBqnHSdJ in [-sIzDXlTHYUC5L3xZGnr(u"࠴ჷ"),Hr25gta6XcqO(u"࠴ჸ")]: return
	if YYxDRTA76kwZNBqnHSdJ==LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠶ჹ"):
		gn2DUcWhvjpC4ZR0lr3bJO61GPVX = fy8iFgEkrO12NR9TWBI35sjY6qHvV
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,N6NGJ4vpmidqMCh7yo(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ඡ"),s5WMHyQN4mpie(u"๋ࠫาอหࠢ฼้้๐ษࠡวํๆฬ็ࠠศๆฯ์ิฯࠠศๆฦ์ฯ๎ๅศฬํ็๏ฯࠧජ"))
	else:
		items = [KfHAW8VGbrxi(u"ࠬ࠸࠵࠱ࠢ࡮ࡦࡵࡹࠧඣ"),sJw9QWiq1Kr0xfeVRI(u"࠭࠵࠱࠲ࠣ࡯ࡧࡶࡳࠨඤ"),O3OVuapf0YFjbm5oUQDg(u"ࠧ࠸࠷࠳ࠤࡰࡨࡰࡴࠩඥ"),CsDcLqQUVK4YBvHFW1(u"ࠨ࠳࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫඦ"),sIzDXlTHYUC5L3xZGnr(u"ࠩ࠴࠶࠺࠶ࠠ࡬ࡤࡳࡷࠬට"),I18uSKaWhgTBeYUPD4sr(u"ࠪ࠵࠺࠶࠰ࠡ࡭ࡥࡴࡸ࠭ඨ"),Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫ࠶࠽࠵࠱ࠢ࡮ࡦࡵࡹࠧඩ"),s5WMHyQN4mpie(u"ࠬ࠸࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨඪ"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠭࠲࠶࠲࠳ࠤࡰࡨࡰࡴࠩණ"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧ࠴࠲࠳࠴ࠥࡱࡢࡱࡵࠪඬ"),FmYoGejTnwKME7d9zPc(u"ࠨ࠵࠸࠴࠵ࠦ࡫ࡣࡲࡶࠫත"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠩ࠷࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬථ"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪ࠸࠺࠶࠰ࠡ࡭ࡥࡴࡸ࠭ද"),O3OVuapf0YFjbm5oUQDg(u"ࠫ࠺࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧධ"),O3OVuapf0YFjbm5oUQDg(u"ࠬ࠼࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨන"),QjAINyUC7MDRq5d8e4vl9(u"࠭࠷࠱࠲࠳ࠤࡰࡨࡰࡴࠩ඲"),uulNDCPyef78(u"ࠧ࠹࠲࠳࠴ࠥࡱࡢࡱࡵࠪඳ"),ggjO5CrKVRPITaesWkxD(u"ࠨ࠻࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫප"),uulNDCPyef78(u"ࠩ࠴࠴࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭ඵ"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠪ࠵࠶࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧබ"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠫ࠶࠸࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨභ"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠬ࠿࠹࠺࠻࠼ࠤࡰࡨࡰࡴࠩම")]
		yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S(wdftVMyzF17cYETHu(u"࠭วฯฬิࠤฬ๊ฬ้ัฬࠤฬ๊ร้ฬ๋้ฬะ๊ไ์ฬࠤฬ๊ๅ็ษึฬฮ࠭ඹ"),items)
		if yNqzFDjKM0SrO==-EE1jeHnIoad(u"࠷ჺ"): return
		gn2DUcWhvjpC4ZR0lr3bJO61GPVX = str(items[yNqzFDjKM0SrO][:-wdftVMyzF17cYETHu(u"࠵჻")])
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,oRJAfwD957WkUyBM1Ehu8m(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪය"),N6NGJ4vpmidqMCh7yo(u"ࠨ่ฯัฯูࠦๆๆํอࠥะิ฻์็ࠤํะอะ์าࠤึ่ๅࠡษ็ะํีษࠡษ็วํะ่ๆษอ๎่๐ษ࡝ࡰ࡟ࡲࠬර")+n0nFOd4yR97fQzNLSW+gn2DUcWhvjpC4ZR0lr3bJO61GPVX+PlpyFa9QMKXxOD1cvHzmI(u"ࠩࠣ࡯ࡧࡶࡳࠨ඼")+T7ASIp1ZYwio9HQ8cObJK)
	OdiZIyCfDUsW3JBGR2VAb.setSetting(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡢࡪࡶࡵࡥࡹ࡫ࠧල"),gn2DUcWhvjpC4ZR0lr3bJO61GPVX)
	return
def Xnfl78ONgp(cEUT5Sw9lIChs08bze6jikQNFBL=LhFAGlQ19zr):
	G8pwQufXhSy = lhm1QXDRsCpfJSrA2GYu()
	nn7D6Z5AlxNQaBqpIWGVJFCROk = LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠫฬ๊สี฼ํ่ࠥอไๅษะๆࠥ๐ูๆๆࠪ඾") if G8pwQufXhSy else QjAINyUC7MDRq5d8e4vl9(u"ࠬอไหึ฽๎้ࠦวๅๆสั็ࠦๅห๊ๅๅࠬ඿")
	YYxDRTA76kwZNBqnHSdJ = jPRJMOhT415yvioG8rN9m0Q3b(AAbvaXV2DQzfNHdm4U3tT(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ව"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠧฯำ๋ะࠬශ"),KfHAW8VGbrxi(u"ࠨวํๆฬ็ࠧෂ"),O3OVuapf0YFjbm5oUQDg(u"ࠩอุ฿๐ไࠨස"),uulNDCPyef78(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭හ"),n0nFOd4yR97fQzNLSW+nn7D6Z5AlxNQaBqpIWGVJFCROk+T7ASIp1ZYwio9HQ8cObJK+C0qrknitpM4Z+o1INZ3ViQqS0Uw5z6kMjbv(u"ࠫ์ึ็ࠡษ็์฽๐แสࠢอะ฾๊ࠠไ๊า๎ࠥษ่ห๊่หฯ๐ใ๋ษࠣ๎็๎ๅࠡสอุ฿๐ไࠡษ็ๅ๏ี๊้ࠢส่้ออใࠢ࠱࠲ࠥหๅศࠢห฽ิࠦว็ฬ๊หฦࠦวๅใํำ๏๎ࠠศๆะห้๐ࠠษลๆ้้ํࠠ࠯࠰ࠣวํࠦศฺัࠣห้์โาࠢ฼่๎ࠦาาࠢࠥฮัอ่ำࠢศ่๎ࠦวๅๆสั็ࠨࠠ࠯࠰ࠣ์ศ๐ึศ่้่ࠢ์ࠠฦๆ฽หฦࠦวๅฬื฾๏๊ࠠศๆ็หา่ࠠษษ็๊็ืฺࠠๆ์ࠤืืࠠࠣวํๆฬ็ࠠศๆไ๎ิ๐่ࠣࠢ࠱࠲ࠥ๎รุ๋สࠤ๊๋ใ็ࠢส่ฬูสโษาอ๋ࠥๆࠡฬ฽๎๏ืࠠหำอ๎อࠦๅฮฬ๋๎ฬะࠠศๆๅ์ฬฬๅࠡ࠰࠱ࠤํิวึหࠣฮึะ๊ษࠢะ่็อสࠡษ็ุ้๊ำๅษอࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦสี฼ํ่ࠥํะ่ࠢส่ํ฾๊โหࠣว๊ࠦล๋ไสๅ์อࠠภࠣࠤࠫළ"))
	if YYxDRTA76kwZNBqnHSdJ==BkM54Kr7Qbqn: lgLp2rPtWsycxonO3jk = bEWpDHXjCBqd7aOiN6UG5k.executeJSONRPC(PlpyFa9QMKXxOD1cvHzmI(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡓࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤࡹ࡭ࡩ࡫࡯ࡱ࡮ࡤࡽࡪࡸ࠮ࡢࡷࡷࡳࡵࡲࡡࡺࡰࡨࡼࡹ࡯ࡴࡦ࡯ࠥ࠰ࠧࡼࡡ࡭ࡷࡨࠦ࠿ࡡ࡝ࡾࡿࠪෆ"))
	elif YYxDRTA76kwZNBqnHSdJ==teaC5j4HuGDqpwcmUzJ: lgLp2rPtWsycxonO3jk = bEWpDHXjCBqd7aOiN6UG5k.executeJSONRPC(QjAINyUC7MDRq5d8e4vl9(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡔࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡺ࡮ࡪࡥࡰࡲ࡯ࡥࡾ࡫ࡲ࠯ࡣࡸࡸࡴࡶ࡬ࡢࡻࡱࡩࡽࡺࡩࡵࡧࡰࠦ࠱ࠨࡶࡢ࡮ࡸࡩࠧࡀ࡛࠲࡟ࢀࢁࠬ෇"))
	if YYxDRTA76kwZNBqnHSdJ in [BkM54Kr7Qbqn,teaC5j4HuGDqpwcmUzJ]:
		if KfHAW8VGbrxi(u"ࠧࡵࡴࡸࡩࠬ෈") in str(lgLp2rPtWsycxonO3jk): GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,s5WMHyQN4mpie(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ෉"),EE1jeHnIoad(u"ࠩอ้ฯࠦวๅ฻่่๏ฯࠠษ่ฯหา්࠭"))
		else: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CsDcLqQUVK4YBvHFW1(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭෋"),aOQTKXFL54Nl60Zhp3MbE(u"้๊ࠫริใࠣห้฿ๅๅ์ฬࠤๆฺไหࠩ෌"))
	return
def JFtx1C6pO5fGM():
	url = I4t9qonjrm.SITESURLS[O3OVuapf0YFjbm5oUQDg(u"ࠬࡘࡅࡍࡇࡄࡗࡊ࡙ࠧ෍")][uulNDCPyef78(u"࠱ჼ")]
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭ࡇࡆࡖࠪ෎"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ggjO5CrKVRPITaesWkxD(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡌࡒࡘ࡚ࡁࡍࡎࡢࡓࡑࡊ࡟ࡓࡇࡏࡉࡆ࡙ࡅ࠮࠳ࡶࡸࠬා"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	sTjfJ91McWaNYk7hmlDAQtIe8 = EcQxOa3RJm86WjTKA.findall(AAbvaXV2DQzfNHdm4U3tT(u"ࠨࡪࡵࡩ࡫ࡃࠢࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࠨࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠴ࠪࡀࠫ࠱ࡾ࡮ࡶࠢࠨැ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	sTjfJ91McWaNYk7hmlDAQtIe8 = sorted(sTjfJ91McWaNYk7hmlDAQtIe8,reverse=EsCplGc5N4mBuYW0RVQt6b)
	yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S(O3OVuapf0YFjbm5oUQDg(u"ࠩสาฯืࠠศๆศูิอัࠡษ็ิ๏ࠦสา์าࠤฯัศ๋ฬ๊ࠫෑ"),sTjfJ91McWaNYk7hmlDAQtIe8)
	if yNqzFDjKM0SrO>=PlpyFa9QMKXxOD1cvHzmI(u"࠲ჽ"):
		kkGM49cdOiSr = url.rsplit(uulNDCPyef78(u"ࠪ࠳ࠬි"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠴ჾ"))[C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠴ჿ")]+N6NGJ4vpmidqMCh7yo(u"ࠫ࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࠬී")+sTjfJ91McWaNYk7hmlDAQtIe8[yNqzFDjKM0SrO]+Hr25gta6XcqO(u"ࠬ࠴ࡺࡪࡲࠪු")
		succeeded = gXY4KLGzRxk6VmfhM(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ෕"),kkGM49cdOiSr,EsCplGc5N4mBuYW0RVQt6b)
		if succeeded:
			OdiZIyCfDUsW3JBGR2VAb.setSetting(jL5CrsRwebpyDVXUc1EQP(u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫූ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ෗"),jL5CrsRwebpyDVXUc1EQP(u"ࠩอ้ࠥะหษ์อࠤส฻ฯศำࠣๆิ๐ๅࠡๆ็ฬึ์วๆฮࠣ࠲࠳ࠦไไ่ࠣฬึ์วๆฮࠣ็ํี๊ࠡ์ๅ์๊ࠦร้ฬ๋้ฬะ๊ไ์สࠤอะอะ์ฮࠤัฺ๋๊ࠢส่อืวๆฮࠣฬฬูสฯัส้ࠥศฮาࠢศูิอัࠡ็อ์ๆืࠠ࠯࠰๋้ࠣࠦสา์าࠤฬ๊ย็ࠢศ๎็อแࠡษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆ๊ิฬࠦวๅสิ๊ฬ๋ฬࠡมࠤࠥࠬෘ"))
			if Scj7zgGFVA83otMpwUkxhm0BLN1: E0huTeDPIjbtcHflCxMdSqskVUX7w(PlpyFa9QMKXxOD1cvHzmI(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨෙ"),EsCplGc5N4mBuYW0RVQt6b,EsCplGc5N4mBuYW0RVQt6b)
	return
def nzZ2HifhoqS94yG0IMVWpB8PLJQDx():
	Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,O3OVuapf0YFjbm5oUQDg(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧේ"),N6NGJ4vpmidqMCh7yo(u"ࠬํไࠡฬิ๎ิࠦแฺๆสࠤู๊อࠡว฼ำฬีวหࠢส่อืๆศ็ฯࠤฬ๊ฮศืฬࠤอ๎โหࠢฯ่อࠦวๅฬะำ๏ัวหࠢ࠱࠲ࠥํะศࠢสู่๊อࠡี๋ๅࠥ๐ำษสࠣฮาี๊ฬࠢไ์ึ๐ࠠๅฮ่๎฾ู่ࠦษษๅࠥอไษำ้ห๊าࠠศๆอ๎ࠥะูห็าࠤ฾๊้ࠡ็ิ์ึ่ࠦใฬ้ࠣ฾๐ๆࠨෛ"))
	if Scj7zgGFVA83otMpwUkxhm0BLN1:
		OdiZIyCfDUsW3JBGR2VAb.setSetting(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡹࡨࡰࡴࡷࠫො"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		OdiZIyCfDUsW3JBGR2VAb.setSetting(wdftVMyzF17cYETHu(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡲࡦࡩࡸࡰࡦࡸࠧෝ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		OdiZIyCfDUsW3JBGR2VAb.setSetting(uulNDCPyef78(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡭ࡱࡱ࡫ࠬෞ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		OdiZIyCfDUsW3JBGR2VAb.setSetting(EE1jeHnIoad(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪෟ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		OdiZIyCfDUsW3JBGR2VAb.setSetting(vU6DxuzPwMpg(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ෠"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EE1jeHnIoad(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ෡"),jL5CrsRwebpyDVXUc1EQP(u"ࠬะๅࠡ็ึัࠥหูะษาหฯࠦวๅสิ๊ฬ๋ฬࠡษ็าฬ฻ษࠡส๋ๆฯࠦฬๅสࠣห้ะอะ์ฮหฯࠦ࠮࠯๋ࠢืํ็๋ࠠไ๋้ࠥอไษำ้ห๊าࠠศๆล๊ࠥฮสฮัํฯࠥํะ่ࠢส่ส฿ฯศัสฮࠥ࠴࠮๊ࠡฦ๎฻อࠠหฯา๎ะู่ࠦษษๅࠥอไษำ้ห๊าࠠศๆอ๎ࠥะูห็าࠤ฾๊้ࠡษ็์็ะࠧ෢"))
		ejX7kGtQ4hcYUHW9b31vriuZLM6Sp(LhFAGlQ19zr)
	return
def t07U5YsNhJbPiWvG():
	gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,CsDcLqQUVK4YBvHFW1(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ෣"),CsDcLqQUVK4YBvHFW1(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ෤"))
	jERlJUwChexAXYk7yI = F0gSC4DoBWkRZvxJAperQqwO15df9y(LhFAGlQ19zr)
	YgZKyLVQJTePnSO2cvo = C0qrknitpM4Z
	kkSWCPU3QTvfmDyZ = WydpaVx5YmLoCiIgA34eEBlb+o1INZ3ViQqS0Uw5z6kMjbv(u"ࠨࠢ࠰࠱࠲࠳࠭ࠡ࠯࠰࠱࠲࠳ࠠ࠮࠯࠰࠱࠲ࠦ࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰ࠤࠬ෥")+T7ASIp1ZYwio9HQ8cObJK
	R6AV0GTDZQebElikPj1NKp = C0qrknitpM4Z+n0nFOd4yR97fQzNLSW+FgXzMs0YSDt(u"ࠩࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭෦")+T7ASIp1ZYwio9HQ8cObJK+jL5CrsRwebpyDVXUc1EQP(u"ࠪࡠࡳࡢ࡮ࠨ෧")
	for id,jewzZuNFibTO,XZCwxtYWEcl8yqr9SHnG7,bb0r3L7XGeVihn,h3H4reNL8l26yPRtdKWg,reason in reversed(jERlJUwChexAXYk7yI):
		if id==Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫ࠵࠭෨"):
			m5tbarSDPZ71xIMocU,ZkCs9oAl2bgw5LV0OGryB = bb0r3L7XGeVihn.split(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠬࡢ࡮࠼࠽ࠪ෩"))
			continue
		if YgZKyLVQJTePnSO2cvo!=C0qrknitpM4Z: YgZKyLVQJTePnSO2cvo += R6AV0GTDZQebElikPj1NKp
		XgbcrBleMx5LYWzKjFCHIOP = uulNDCPyef78(u"࡛࠭ࡓࡖࡏࡡࠬ෪")+WydpaVx5YmLoCiIgA34eEBlb+id+I18uSKaWhgTBeYUPD4sr(u"ࠧࠡ࠼ࠣࠫ෫")+uulNDCPyef78(u"ࠨษ็ืษอไࠡ࠼ࠣࠫ෬")+T7ASIp1ZYwio9HQ8cObJK+XZCwxtYWEcl8yqr9SHnG7
		mmv7XkyreCIJGUqhTYi5KB6DWSn = QjAINyUC7MDRq5d8e4vl9(u"ࠩ࡟ࡲࡠࡘࡔࡍ࡟ࠪ෭")+WydpaVx5YmLoCiIgA34eEBlb+FmYoGejTnwKME7d9zPc(u"ࠪห้า่ศสࠣ࠾ࠥ࠭෮")+T7ASIp1ZYwio9HQ8cObJK+bb0r3L7XGeVihn
		kQ90RuKEmXbqfP6as7pe4MIdvoG1cH = CsDcLqQUVK4YBvHFW1(u"ࠫࡠࡘࡔࡍ࡟ࠪ෯")+WydpaVx5YmLoCiIgA34eEBlb+aOQTKXFL54Nl60Zhp3MbE(u"ࠬอไฯูฦࠤ࠿ࠦࠧ෰")+T7ASIp1ZYwio9HQ8cObJK+h3H4reNL8l26yPRtdKWg
		AAiROomtT6LBXpcaWPSC = EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭࡜࡯࡝ࡕࡘࡑࡣࠧ෱")+WydpaVx5YmLoCiIgA34eEBlb+I18uSKaWhgTBeYUPD4sr(u"ࠧศๆึฬอࠦ࠺ࠡࠩෲ")+T7ASIp1ZYwio9HQ8cObJK+reason
		YgZKyLVQJTePnSO2cvo += XgbcrBleMx5LYWzKjFCHIOP+mmv7XkyreCIJGUqhTYi5KB6DWSn+C0qrknitpM4Z+kkSWCPU3QTvfmDyZ+C0qrknitpM4Z+kQ90RuKEmXbqfP6as7pe4MIdvoG1cH+AAiROomtT6LBXpcaWPSC+C0qrknitpM4Z
	cFjMEShi6Pp0otRBgeXq8(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠨࡴ࡬࡫࡭ࡺࠧෳ"),ZkCs9oAl2bgw5LV0OGryB,YgZKyLVQJTePnSO2cvo,oRJAfwD957WkUyBM1Ehu8m(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪ෴"))
	return
def ffxoXPD8eFTtSpGmwdCkaJ2c(file):
	if file==mmFzNZYEJpdqUro7sKMj6W2: dAeN2GBRjgn = OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪๆํอฦๆࠢส่๊็ึๅหࠪ෵")
	elif file==bVeH60CmPM: dAeN2GBRjgn = C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠫ็๎วว็ࠣฦำืࠠศๆไ๎ิ๐่่ษอࠫ෶")
	YYxDRTA76kwZNBqnHSdJ = jPRJMOhT415yvioG8rN9m0Q3b(sIzDXlTHYUC5L3xZGnr(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ෷"),sJw9QWiq1Kr0xfeVRI(u"࠭ๅิฯࠪ෸"),s5WMHyQN4mpie(u"ࠧฦื็หา࠭෹"),PlpyFa9QMKXxOD1cvHzmI(u"ࠨะิ์ั࠭෺"),oRJAfwD957WkUyBM1Ehu8m(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ෻"),FmYoGejTnwKME7d9zPc(u"๋้ࠪࠦสา์าࠤส฻ไศฯ้้ࠣ็ࠠࠨ෼")+dAeN2GBRjgn+I18uSKaWhgTBeYUPD4sr(u"ࠫࠥษๅࠡฬิ๎ิࠦๅิฯࠣห้๋ไโࠢยࠫ෽"))
	if YYxDRTA76kwZNBqnHSdJ==KfHAW8VGbrxi(u"࠵ᄀ"):
		if HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.exists(file):
			try: HoxKENAey2MdTt9kDUrVnWGLS0CPa.remove(file)
			except: pass
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,O3OVuapf0YFjbm5oUQDg(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ෾"),Hr25gta6XcqO(u"࠭สๆ่ࠢืาࠦๅๅใࠣࠫ෿")+dAeN2GBRjgn)
	elif YYxDRTA76kwZNBqnHSdJ==wdftVMyzF17cYETHu(u"࠷ᄁ"):
		data = mJE8eLQqtMC9Io6sfHnBKjiDzPwvy(file)
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,KfHAW8VGbrxi(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ฀"),I18uSKaWhgTBeYUPD4sr(u"ࠨฬ่ࠤส฻ไศฯ้้ࠣ็ࠠࠨก")+dAeN2GBRjgn)
	return
def qIYmtHNXPBCMG6():
	if FpjKBIUaEwbmLkxANfs<wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠱࠹ᄂ"):
		kf40tulvSA7z9RqNF5dXca3seMD = N6NGJ4vpmidqMCh7yo(u"ࠩ็่ศูแࠡล้ฮࠥะำหะา้ࠥหีะษิࠤ่๎ฯ๋ࠢๅำ๏๋ࠠาไ่ࠤࠬข")+str(FpjKBIUaEwbmLkxANfs)+CsDcLqQUVK4YBvHFW1(u"ࠪࠤํ๊็ัษࠣห้่่ศศ่ࠤฬ๊ๅึ๊ิอ๊ࠥวࠡฬ฼ู้้ࠦ็ัๆࠤ࠳ࠦ็ั้ࠣห้๋๊ำหࠣฮ๊้ๆไ่๊ࠢࠥืฤ๋หࠣๆํอฦๆࠢส่ๆ๐ฯ๋๊๊หฯࠦแ๋ࠢหี๋อๅอࠢ฼้ฬีࠠษึๆ่ࠥ฻่าࠢหำ้อࠠๆ่ࠣห้้สศสฬࠤ࠳ࠦไฦื็หาࠦวๅ็ื็้ฯࠠใ็ࠣฬฯำฯ๋อࠣฬึ์วๆฮࠣ็ํี๊ࠡว็ํࠥห๊ࠡวุำฬืࠠาไ่๋ࠥษูๅ๋้๋ࠣࠦ࠱࠹࠰࠳ࠫฃ")
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,AAbvaXV2DQzfNHdm4U3tT(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧค"),kf40tulvSA7z9RqNF5dXca3seMD)
		return
	YjXGEndQ5TZs3S4e2auCvBwtIfKix = bEWpDHXjCBqd7aOiN6UG5k.executeJSONRPC(ssynAg0zhSkoCpOMDV9(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨฅ"))
	oSiV9K6kg3pRXF07Q = cDVaL376lmoAX([sJw9QWiq1Kr0xfeVRI(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬฆ")])
	AAkZvIgX4hcfMWtbK,byDrtFW27csQ95Eme,WW53fAavStcdrH86yO2Pl,iRnQFAhHjoXqfIT7vlYP20pS3ENs,l43nKOfCektopYNLxA6Z7B8asHJ5P9,tUQ8ERKvkr,JbK3Uj7Ioux4FWcEZmTlPHOi0fh = oSiV9K6kg3pRXF07Q[LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ง")]
	if AAkZvIgX4hcfMWtbK or ssynAg0zhSkoCpOMDV9(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧจ") not in str(YjXGEndQ5TZs3S4e2auCvBwtIfKix):
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,wdftVMyzF17cYETHu(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬฉ"),N6NGJ4vpmidqMCh7yo(u"ࠪห้่่ศศ่ࠤฬ๊ๅึ๊ิอࠥะูๆๆࠣๅ็฽ࠠๆ฻ࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠯๊ࠢิ์ࠦวๅไ๋หห๋ࠠห็ๆ๊่ࠦๅ็ࠢิศ๏ฯࠠใ๊สส๊ࠦศา่ส้ัูࠦๆษาࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠨช"))
		ddecO3Tb9U5k = tE4opQ8FJUa5Neh1MnyKSm()
		if not ddecO3Tb9U5k: return
	flAMmhjDV5ISOU46xibGekvq(EsCplGc5N4mBuYW0RVQt6b)
	return
def flAMmhjDV5ISOU46xibGekvq(showDialogs=EsCplGc5N4mBuYW0RVQt6b):
	YjXGEndQ5TZs3S4e2auCvBwtIfKix = bEWpDHXjCBqd7aOiN6UG5k.executeJSONRPC(oRJAfwD957WkUyBM1Ehu8m(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧซ"))
	if s5WMHyQN4mpie(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫฌ") not in str(YjXGEndQ5TZs3S4e2auCvBwtIfKix):
		if showDialogs:
			GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,wdftVMyzF17cYETHu(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩญ"),Hr25gta6XcqO(u"ࠧๅๆฦืๆࠦฬ่ษี็๊ࠥวࠡ์ึฮำีๅࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴ࠠศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢอ฽๊๊ࠠโไฺࠤ๊฿ࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠳ࠦ็ั้ࠣห้่่ศศ่ࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠬฎ"))
		return
	vEMwN9eYBQO = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(ywEBSl6zHMFsO4Qmh3TJP8itgj,FmYoGejTnwKME7d9zPc(u"ࠨࡣࡧࡨࡴࡴࡳࠨฏ"),QjAINyUC7MDRq5d8e4vl9(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨฐ"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠪ࠻࠷࠶ࡰࠨฑ"),FgXzMs0YSDt(u"ࠫࡒࡿࡖࡪࡦࡨࡳࡓࡧࡶ࠯ࡺࡰࡰࠬฒ"))
	if not HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.exists(vEMwN9eYBQO): return
	Br3eWJF76pCwXcOhuL9EtdMmIN0 = open(vEMwN9eYBQO,FgXzMs0YSDt(u"ࠬࡸࡢࠨณ")).read()
	if jTDWgftK7NEmx0JAkOn2aRIvweq: Br3eWJF76pCwXcOhuL9EtdMmIN0 = Br3eWJF76pCwXcOhuL9EtdMmIN0.decode(Tk9eH2qw6Brsuhj)
	VSEn9Zf5Nj8Fdlahemwgt = EcQxOa3RJm86WjTKA.findall(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠭࠼ࡷ࡫ࡨࡻࡸࡄࠨ࡝ࡦ࠮࠰ࡡࡪࠫ࠭࡞ࡧ࠯࠮࠲ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡶࡪࡧࡺࡷࡃ࠭ด"),Br3eWJF76pCwXcOhuL9EtdMmIN0,EcQxOa3RJm86WjTKA.DOTALL)
	bpUeEl36xK,cVxylipUruY7Xn8WaCbkSejzwL9mG = VSEn9Zf5Nj8Fdlahemwgt[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	LmrPOVMCdu = Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠧ࠽ࡸ࡬ࡩࡼࡹ࠾ࠨต")+bpUeEl36xK+Gcw2nelTR864XCVruO3mAFqI5a(u"ࠨ࠮ࠪถ")+cVxylipUruY7Xn8WaCbkSejzwL9mG+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩ࠿࠳ࡻ࡯ࡥࡸࡵࡁࠫท")
	if showDialogs:
		HHK6wEtbyedB3YTPNn = bEWpDHXjCBqd7aOiN6UG5k.getInfoLabel(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡖࡪࡧࡺࡱࡴࡪࡥࠨธ"))
		if HHK6wEtbyedB3YTPNn==aOQTKXFL54Nl60Zhp3MbE(u"ࠫࡊࡓࡁࡅࠢࡏ࡭ࡸࡺࠧน"): WVQplft5vX3aYi = aOQTKXFL54Nl60Zhp3MbE(u"่่ࠬศศ่ࠤฬ๊ใหษหอࠬบ")
		elif HHK6wEtbyedB3YTPNn==Gcw2nelTR864XCVruO3mAFqI5a(u"࠭ࡅࡎࡃࡇࠤࡌࡧ࡬࡭ࡧࡵࡽࠬป"): WVQplft5vX3aYi = wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧใ๊สส๊ࠦวๅื๋ีࠬผ")
		else: WVQplft5vX3aYi = V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠨไ๋หห๋ࠠฤะิํࠬฝ")
		YYxDRTA76kwZNBqnHSdJ = jPRJMOhT415yvioG8rN9m0Q3b(aOQTKXFL54Nl60Zhp3MbE(u"ࠩࡦࡩࡳࡺࡥࡳࠩพ"),N6NGJ4vpmidqMCh7yo(u"ࠪๆํอฦๆࠢฦาึ๏ࠧฟ"),O3OVuapf0YFjbm5oUQDg(u"ࠫ็๎วว็ࠣห้้สศสฬࠫภ"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"่่ࠬศศ่ࠤฬ๊ี้ำࠪม"),Hr25gta6XcqO(u"࠭ว็ฬࠣัฬ๊๊ศࠢอืฯิฯๆࠢࠪย")+WVQplft5vX3aYi,FgXzMs0YSDt(u"ࠧศ่อࠤฬ๊ย็ࠢอืฯิฯๆࠢส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠰ࠣ์์ึวࠡ็฼๊ฬํࠠศ่ๆࠤฯูสุ์฼ࠤฬูสฯัส้ࠥอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠษั็ห๋ࠥๆࠡไ๋หห๋ࠠศๆๆฮฬฮษࠡ࠰ࠣ์ศ๐ึศࠢอืฯ฽ฺ๊ࠢศ๎็อแ่ษࠣๅ๏ࠦร๋๋ࠢๆฯࠦสีษฤࠤࡡࡴ࡜࡯ࠢࠪร")+WydpaVx5YmLoCiIgA34eEBlb+N6NGJ4vpmidqMCh7yo(u"ࠨࠢฦาฯืࠠศๆล๊ࠥ์ฺ่ࠢส่็๎วว็ࠣห้ะ๊ࠡฬิ๎ิࠦริฬัำฬ๋็ศࠢยࠥࠬฤ")+T7ASIp1ZYwio9HQ8cObJK)
		if YYxDRTA76kwZNBqnHSdJ==aOQTKXFL54Nl60Zhp3MbE(u"࠲ᄃ"): Z1uLrhTwiam2V0DX8Sz67RbPHnEWpv = Hr25gta6XcqO(u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬล")
		elif YYxDRTA76kwZNBqnHSdJ==FmYoGejTnwKME7d9zPc(u"࠴ᄄ"): Z1uLrhTwiam2V0DX8Sz67RbPHnEWpv = oRJAfwD957WkUyBM1Ehu8m(u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩฦ")
		else: Z1uLrhTwiam2V0DX8Sz67RbPHnEWpv = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	else:
		HHK6wEtbyedB3YTPNn = OdiZIyCfDUsW3JBGR2VAb.getSetting(Hr25gta6XcqO(u"ࠫࡦࡼ࠮࡮ࡻࡶ࡯࡮ࡴ࠮ࡷ࡫ࡨࡻࡲࡵࡤࡦࠩว"))
		if   HHK6wEtbyedB3YTPNn==fy8iFgEkrO12NR9TWBI35sjY6qHvV: YYxDRTA76kwZNBqnHSdJ = sIzDXlTHYUC5L3xZGnr(u"࠳ᄅ")
		elif HHK6wEtbyedB3YTPNn==OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠬࡋࡍࡂࡆࠣࡐ࡮ࡹࡴࠨศ"): YYxDRTA76kwZNBqnHSdJ = KfHAW8VGbrxi(u"࠵ᄆ")
		elif HHK6wEtbyedB3YTPNn==I18uSKaWhgTBeYUPD4sr(u"࠭ࡅࡎࡃࡇࠤࡌࡧ࡬࡭ࡧࡵࡽࠬษ"): YYxDRTA76kwZNBqnHSdJ = ggjO5CrKVRPITaesWkxD(u"࠷ᄇ")
		Z1uLrhTwiam2V0DX8Sz67RbPHnEWpv = HHK6wEtbyedB3YTPNn
	if   YYxDRTA76kwZNBqnHSdJ==s5WMHyQN4mpie(u"࠶ᄈ"): uinM6432dB = ssynAg0zhSkoCpOMDV9(u"ࠧ࠶࠷࠯࠹࠹࠺ࠬ࠶࠷࠸ࠫส")
	elif YYxDRTA76kwZNBqnHSdJ==wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠱ᄉ"): uinM6432dB = ssynAg0zhSkoCpOMDV9(u"ࠨ࠷࠷࠸࠱࠻࠵࠶࠮࠸࠹ࠬห")
	elif YYxDRTA76kwZNBqnHSdJ==QjAINyUC7MDRq5d8e4vl9(u"࠳ᄊ"): uinM6432dB = sJw9QWiq1Kr0xfeVRI(u"ࠩ࠸࠹࠺࠲࠵࠶࠮࠸࠸࠹࠭ฬ")
	else: return
	OdiZIyCfDUsW3JBGR2VAb.setSetting(o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪࡥࡻ࠴࡭ࡺࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨอ"),Z1uLrhTwiam2V0DX8Sz67RbPHnEWpv)
	lmZW09xtBh6d5TSP = V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠫࡁࡼࡩࡦࡹࡶࡂࠬฮ")+uinM6432dB+s5WMHyQN4mpie(u"ࠬ࠲ࠧฯ")+cVxylipUruY7Xn8WaCbkSejzwL9mG+uulNDCPyef78(u"࠭࠼࠰ࡸ࡬ࡩࡼࡹ࠾ࠨะ")
	SqJ47pYPIVG = Br3eWJF76pCwXcOhuL9EtdMmIN0.replace(LmrPOVMCdu,lmZW09xtBh6d5TSP)
	if jTDWgftK7NEmx0JAkOn2aRIvweq: SqJ47pYPIVG = SqJ47pYPIVG.encode(Tk9eH2qw6Brsuhj)
	open(vEMwN9eYBQO,KfHAW8VGbrxi(u"ࠧࡸࡤࠪั")).write(SqJ47pYPIVG)
	Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,aOQTKXFL54Nl60Zhp3MbE(u"ࠨ࠰࡟ࡸࡘࡱࡩ࡯ࠢࡇࡩ࡫ࡧࡵ࡭ࡶ࡚ࠣ࡮࡫ࡷࡴ࠼ࠣ࡟ࠥ࠭า")+uinM6432dB+N6NGJ4vpmidqMCh7yo(u"ࠩࠣࡡࠬำ"))
	if showDialogs: bEWpDHXjCBqd7aOiN6UG5k.executebuiltin(wdftVMyzF17cYETHu(u"ࠪࡖࡪࡲ࡯ࡢࡦࡖ࡯࡮ࡴࠨࠪࠩิ"))
	return
def r7HMiISPDUOjLWh():
	Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Hr25gta6XcqO(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧี"),FmYoGejTnwKME7d9zPc(u"ࠬฮั็ษ่ะࠥ฿ๅศัࠣๅ๏ํࠠๆึๆ่ฮูࠦ็ัๆࠤ࠳࠴࠮ࠡว่หࠥษไฦืาหึࠦโะ์่ࠤ࠳࠴࠮ࠡล๋ࠤฬ์สࠡ็่๊ํ฿ࠠๆ่ࠣหุะฮะษ่ࠤฬ๊ศา่ส้ัࠦ࠮࠯࠰ࠣวํࠦไะ์ๆࠤฺ๊ใๅหࠣวำื้ࠡฬัูࠥา็ศิๆࠤศ์ส๊ࠡ็หࠥะฮึࠢหๆ๏ฯࠠฯๆๅࠤฬ๊ไ่ࠢ࡟ࡲࡡࡴࠠฮษ๋่ࠥะอะ์ฮࠤฬ๊ศา่ส้ัࠦร้ࠢสฮฺ๊ࠠษษ็้อืๅอࠢ็้฾ืแสࠢึฬอࠦวๅ็ื็้ฯฺ่ࠠา็ࠥ࠴࠮࠯๊่ࠢࠥะั๋ัࠣๅา฻ࠠศๆอัิ๐หศฬࠣห้ศๆࠡมࠪึ"))
	if Scj7zgGFVA83otMpwUkxhm0BLN1==EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠳ᄋ"): kc58wNCXd79rl1xS3ZBKfUjPm0Tby()
	return
def sldteGVyPjbLXH4YuNhDofkZ78xr():
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,I18uSKaWhgTBeYUPD4sr(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩื"),oRJAfwD957WkUyBM1Ehu8m(u"่ࠧาสࠤฬ๊ๅ้ไ฼ࠤ๊เไใ่๊ࠢࠥอไๆืาีࠥ๎ฺ๋ำ้ࠣ฾ื่โ่ࠢฮ๏๊ࠦาฮ฼ࠤู้๊ๆๆุࠪ"))
	return
def h1HfXYdlKASmPvoLBb7kzD():
	XgbcrBleMx5LYWzKjFCHIOP = WydpaVx5YmLoCiIgA34eEBlb+Gcw2nelTR864XCVruO3mAFqI5a(u"ࠨฬ฼ำฬีࠠี์฼อࠥศไࠡ็ะ้ิࠦไิ่ฬࠤ࠷࠶࠲࠲ࠢ࠽ࠤูࠬ")+T7ASIp1ZYwio9HQ8cObJK
	XgbcrBleMx5LYWzKjFCHIOP += s5WMHyQN4mpie(u"ࠩส่๊๎โฺࠢฦำ๋อ็ࠡใํ๋ࠥหอึษษ๎ฮࠦไฺัาࠤฬ๊ิ๋฻ฬࠤๆ๐ࠠศๆ฼ห้๋ࠠห็ࠣะ๊฿็ศ่๊ࠢࠥาๅ๋฻ࠣห้๋ีศัิࠤฬ๊ๅห๊ไีฮࠦแ๋ࠢส่ส์สา่อࠤฬ๊โะ์่อࠥ๎วๅฮา๎ิฯࠠศๆะ็ํ๋๊ส๋ࠢห้เ๊าࠢะ็ํ๋๊ส๋้๋ࠢࠦฬๆ์฼ࠤิ๎ไࠡษ็฽ฬ๊ๅࠡอ่ࠤฯ๋ࠠห๊ะ๎ิํว๊ࠡะืฬฮࠠศๆ่฽ิ๊ࠠฮีหࠤุ้ว็ࠢา์้ࠦวๅ฻ส่๊ࠦไิ่ฬࠤ࠷࠶࠲࠲๋๋ࠢ๏ࠦวๅวะูฬฬ๊สࠢส่ศำฯฬ๋ࠢห้ษิๆๆࠣห้ะ๊ࠡฬ่ࠤ฾๋ไ่ษࠣๅ๏ࠦวๅี้์ฬะࠠศๆ฼ุึฯࠠศๆ่ห฻๐ษࠨฺ")
	XgbcrBleMx5LYWzKjFCHIOP += C0qrknitpM4Z+WydpaVx5YmLoCiIgA34eEBlb+o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹ࡯࡮ࡺ࠰ࡦࡧ࠴ࡹࡨࡪࡣࡦࡳࡺࡴࡴࠨ฻")+T7ASIp1ZYwio9HQ8cObJK
	mmv7XkyreCIJGUqhTYi5KB6DWSn = WydpaVx5YmLoCiIgA34eEBlb+sJw9QWiq1Kr0xfeVRI(u"ࠫอืๆศ็ฯࠤูืุ๊ࠢสู่๊ไๆࠢ࠽ࠤࠬ฼")+T7ASIp1ZYwio9HQ8cObJK
	mmv7XkyreCIJGUqhTYi5KB6DWSn += vU6DxuzPwMpg(u"ࠬํ่ࠡ฻หหึฯฺ่ࠠࠣฬึ์วๆฮࠣ๎ํ็ัࠡ็฼่ํ๋วหࠢะืฬฮ๊สࠢๆฯ๏ืษࠡฬ๊้ࠥาๅ๋฻ࠣห้๋ำๅ็ํ๊๋ࠥหๅࠢฦ์็อสࠡษ็ู้อษ๊ࠡฦ์็อสࠡษ็็ุ๎แ๊ࠡส่ำู่โุ๋่๊ࠢࠠศๆๅ้ึ่ࠦฤ๊ๅหฯࠦวๅไ่ีࠥ๎รุ๋สࠤ๏๎แาࠢิศ๏ฯࠠศๆ๊่ฬ๊ࠠโ์ࠣะ๊๐ูࠡั๋่ࠥอไฺษ็้ࠥ๎รุ๋สࠤๆ๐็ࠡฬๅ์๏๋ࠠๆ์็หิ๐้้ࠠฯี๏่ࠦโ์๊ࠤศ๐ึศࠢหัะ่ࠦใำสลฮࠦวๅไิฦ๋่ࠦฤ์ูหࠥ็๊่ࠢสืฯิวาหࠣ์ฯ็วลๆࠣ์ๆ๐็ࠡลๅ์ฬ๊ࠠๆ่ึ์อฯࠠๅๆฦ้ฬฺ๋ࠠๆํࠤํษๅ้ำࠣวำื้ࠡฬ๊้้ࠥไࠡ็ึ่๊ࠦ࠮ࠡษ็ฬึ์วๆฮ้่ࠣะ่ษࠢห่฿ฯࠠอษไหูࠥใาสอࠤํ๐ำหะา้ࠥ์ุศ็ࠣ์๏์ฯ้ิࠣฮาะࠠษ์ษอࠥ๎๊็ั๋ึ้ࠥวอ์อࠤํ๋ฮึืࠣๅ็฽ࠠๅลฯ๋ืฯࠠศๆ๋๎๋ี่ำࠢ࠱ࠤฬ๊ๅ้ไ฼ࠤฬ๊ัิ็ํࠤ้๊ศา่ส้ัࠦ็้ࠩ฽")
	mmv7XkyreCIJGUqhTYi5KB6DWSn += C0qrknitpM4Z+WydpaVx5YmLoCiIgA34eEBlb+uulNDCPyef78(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡵ࡫ࡱࡽ࠳ࡩࡣ࠰࡯ࡸࡷࡱ࡯࡭ࡳࡷ࡯ࡩࡷ࠭฾")+T7ASIp1ZYwio9HQ8cObJK
	kf40tulvSA7z9RqNF5dXca3seMD = vU6DxuzPwMpg(u"ࠧ࡜ࡔࡗࡐࡢ࠭฿")+XgbcrBleMx5LYWzKjFCHIOP+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠨ࡞ࡱࡠࡳࡢ࡮࡜ࡔࡗࡐࡢ࠭เ")+mmv7XkyreCIJGUqhTYi5KB6DWSn
	cFjMEShi6Pp0otRBgeXq8(CsDcLqQUVK4YBvHFW1(u"ࠩࡵ࡭࡬࡮ࡴࠨแ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,kf40tulvSA7z9RqNF5dXca3seMD)
	return
def ozs7B5fWTKAjX4gylCmviZpbL(vUTCBmuRD025KJ):
	uj8SWIk2fcadGNFs67ZLp0(oWMrx7zvedHY0UiS48XbOqVTJ)
	jERlJUwChexAXYk7yI = F0gSC4DoBWkRZvxJAperQqwO15df9y(vUTCBmuRD025KJ)
	for rZT2XOwMtxjeNnI3v in [OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬโ"),s5WMHyQN4mpie(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧใ"),I18uSKaWhgTBeYUPD4sr(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙࡟ࡕࡕࠪไ"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࡡࡗࡗࠬๅ")]:
		if rZT2XOwMtxjeNnI3v in I4t9qonjrm.SEND_THESE_EVENTS: I4t9qonjrm.SEND_THESE_EVENTS.remove(rZT2XOwMtxjeNnI3v)
	frSuovzeY8hZD(Hr25gta6XcqO(u"ࠧࡅࡑࡑࡅ࡙ࡏࡏࡏࡕࠪๆ"))
	id,jewzZuNFibTO,XZCwxtYWEcl8yqr9SHnG7,bb0r3L7XGeVihn,h3H4reNL8l26yPRtdKWg,reason = jERlJUwChexAXYk7yI[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	m5tbarSDPZ71xIMocU,ZkCs9oAl2bgw5LV0OGryB = bb0r3L7XGeVihn.split(o1INZ3ViQqS0Uw5z6kMjbv(u"ࠨ࡞ࡱ࠿ࡀ࠭็"))
	mmv7XkyreCIJGUqhTYi5KB6DWSn,kQ90RuKEmXbqfP6as7pe4MIdvoG1cH,AAiROomtT6LBXpcaWPSC = h3H4reNL8l26yPRtdKWg.split(s5WMHyQN4mpie(u"ࠩ࡟ࡲࡀࡁ่ࠧ"))
	uymvhBQ8pSEXHtcqsN9b = EsCplGc5N4mBuYW0RVQt6b
	while uymvhBQ8pSEXHtcqsN9b:
		LLfNJsm2lFz = jPRJMOhT415yvioG8rN9m0Q3b(fy8iFgEkrO12NR9TWBI35sjY6qHvV,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠪาึ๎ฬࠨ้"),sJw9QWiq1Kr0xfeVRI(u"ࠫสืำศๆࠣีุอไสࠢ็่๊ฮัๆฮ๊ࠪ"),I18uSKaWhgTBeYUPD4sr(u"่ࠬวว็ฬࠤฬ๊สษำ฼หฯ๋࠭"),aOQTKXFL54Nl60Zhp3MbE(u"࠭ไฦ์ๅหๆࠦวๅว฼่ฬ์วหࠢ࠽ࠤࠥะศา฻ࠣวํࠦวๆีะࠤฬ๊ศา่ส้ั࠭์"),mmv7XkyreCIJGUqhTYi5KB6DWSn)
		if LLfNJsm2lFz==o1INZ3ViQqS0Uw5z6kMjbv(u"࠵ᄌ"): GfQM7OFkZHuTAcgDK3Rin = jPRJMOhT415yvioG8rN9m0Q3b(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,jL5CrsRwebpyDVXUc1EQP(u"ฺ๊ࠧาอࠬํ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠨ็หำศࠦวๅฬหี฾ฺ๋ࠦำࠣๆฬฮไࠡๆ็๊็อิࠨ๎"),kQ90RuKEmXbqfP6as7pe4MIdvoG1cH,AAbvaXV2DQzfNHdm4U3tT(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡷࡲࡧ࡬࡭ࡨࡲࡲࡹ࠭๏"))
		elif LLfNJsm2lFz==s5WMHyQN4mpie(u"࠵ᄍ"): YYuBnksbtX4WTE7ipPQmNgaZvy9U()
		else: uymvhBQ8pSEXHtcqsN9b = LhFAGlQ19zr
	if vUTCBmuRD025KJ: ejX7kGtQ4hcYUHW9b31vriuZLM6Sp(LhFAGlQ19zr)
	return
def RB65cZw0nMUp3GLWV1yxEa():
	zaSVrEi1HqZnjctTFuLsmQB7Y()
	jmbLzx5WT68MBtIQonOXkpuy = OdiZIyCfDUsW3JBGR2VAb.getSetting(o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡨࡵࡶࡳࡧࡦࡩࡨࡦࠩ๐"))
	kf40tulvSA7z9RqNF5dXca3seMD = {}
	kf40tulvSA7z9RqNF5dXca3seMD[PlpyFa9QMKXxOD1cvHzmI(u"ࠫࡆ࡛ࡔࡐࠩ๑")] = O3OVuapf0YFjbm5oUQDg(u"ࠬอไไษืࠤฬ๊สๅไสส๏ฺ๊ࠦ็็ࠫ๒")
	kf40tulvSA7z9RqNF5dXca3seMD[EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭ࡓࡕࡑࡓࠫ๓")] = EE1jeHnIoad(u"ࠧศๆๆหูࠦๅห๊ๅๅࠥะๅศ็สࠤํฮวๅๅส้้࠭๔")
	kf40tulvSA7z9RqNF5dXca3seMD[PlpyFa9QMKXxOD1cvHzmI(u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩ๕")] = I18uSKaWhgTBeYUPD4sr(u"ࠩๆหูࠦฬะษࠣๆฺ๐ัࠡษ็้ิ๏ࠠ࠯ࠢࠪ๖")+str(zbE2LFPn8tvKmTgRB/wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠻࠶ᄎ"))+o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪࠤิ่๊ใหࠣๅ็฽ࠧ๗")
	AjYPLzCMReXgE04iUavqchyf6SBJ3 = kf40tulvSA7z9RqNF5dXca3seMD[jmbLzx5WT68MBtIQonOXkpuy]
	YYxDRTA76kwZNBqnHSdJ = jPRJMOhT415yvioG8rN9m0Q3b(fy8iFgEkrO12NR9TWBI35sjY6qHvV,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"่ࠫอิࠡࠩ๘")+str(zbE2LFPn8tvKmTgRB/wdftVMyzF17cYETHu(u"࠼࠰ᄏ"))+EE1jeHnIoad(u"ࠬࠦฯใ์ๅอࠬ๙"),FmYoGejTnwKME7d9zPc(u"࠭สี฼ํ่ࠥะไใษษ๎ࠬ๚"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠧฦ์ๅหๆࠦใศ็็ࠫ๛"),AjYPLzCMReXgE04iUavqchyf6SBJ3,FmYoGejTnwKME7d9zPc(u"ࠨ้็ࠤฯื๊ะࠢสืฯิฯศ็ࠣห้้วีࠢส่ี้๊ࠡษ็ฮ้่วว์ࠣว๊ࠦสา์าࠤส๐โศใࠣห้้วีࠢหห้้วๆๆࠣว๊ࠦสา์าࠤ่อิࠡ฻่ี์ࠦโึ์ิࠤัีวࠡมࠤࠫ๜"))
	if YYxDRTA76kwZNBqnHSdJ==V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠰ᄐ"): HbSihoLTc3EIV1 = KfHAW8VGbrxi(u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪ๝")
	elif YYxDRTA76kwZNBqnHSdJ==AAbvaXV2DQzfNHdm4U3tT(u"࠲ᄑ"): HbSihoLTc3EIV1 = wdftVMyzF17cYETHu(u"ࠪࡅ࡚࡚ࡏࠨ๞")
	elif YYxDRTA76kwZNBqnHSdJ==jL5CrsRwebpyDVXUc1EQP(u"࠴ᄒ"): HbSihoLTc3EIV1 = SnhLjmfeJC(u"ࠫࡘ࡚ࡏࡑࠩ๟")
	else: HbSihoLTc3EIV1 = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if HbSihoLTc3EIV1:
		OdiZIyCfDUsW3JBGR2VAb.setSetting(s5WMHyQN4mpie(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡪࡷࡸࡵࡩࡡࡤࡪࡨࠫ๠"),HbSihoLTc3EIV1)
		TTdUry26C0VK = kf40tulvSA7z9RqNF5dXca3seMD[HbSihoLTc3EIV1]
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,TTdUry26C0VK)
	return
def EEKmGlgpza4tUCwxRkPoc3FATSeI9():
	kf40tulvSA7z9RqNF5dXca3seMD = {}
	kf40tulvSA7z9RqNF5dXca3seMD[V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠭ࡁࡖࡖࡒࠫ๡")] = Gcw2nelTR864XCVruO3mAFqI5a(u"ࠧิ์ิๅึࠦࡄࡏࡕࠣห้ะไใษษ๎ࠥ๐ูๆๆ࠽ࠤࠬ๢")
	kf40tulvSA7z9RqNF5dXca3seMD[KfHAW8VGbrxi(u"ࠨࡃࡖࡏࠬ๣")] = KfHAW8VGbrxi(u"ࠩึ๎ึ็ัࠡࡆࡑࡗฺู๊ࠥ็็ࠤอ฿ฯࠡษ็ื๊ออࠡๆ๊࠾ࠥ࠭๤")
	kf40tulvSA7z9RqNF5dXca3seMD[o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪࡗ࡙ࡕࡐࠨ๥")] = sIzDXlTHYUC5L3xZGnr(u"ุࠫ๐ัโำࠣࡈࡓ࡙ࠠๆฬ๋ๆๆࠦสๆษ่หࠥ๎ศศๆๆห๊๊ࠧ๦")
	KtNEBxybqIkHnJSTpULh0vl7c = OdiZIyCfDUsW3JBGR2VAb.getSetting(PlpyFa9QMKXxOD1cvHzmI(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡦࡱࡷࠬ๧"))
	jmbLzx5WT68MBtIQonOXkpuy = OdiZIyCfDUsW3JBGR2VAb.getSetting(aOQTKXFL54Nl60Zhp3MbE(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩ๨"))
	AjYPLzCMReXgE04iUavqchyf6SBJ3 = kf40tulvSA7z9RqNF5dXca3seMD[jmbLzx5WT68MBtIQonOXkpuy]+KtNEBxybqIkHnJSTpULh0vl7c
	YYxDRTA76kwZNBqnHSdJ = jPRJMOhT415yvioG8rN9m0Q3b(fy8iFgEkrO12NR9TWBI35sjY6qHvV,oRJAfwD957WkUyBM1Ehu8m(u"ࠧหึ฽๎ู้ࠦ็ัࠣห้๋่ศใๅอࠬ๩"),s5WMHyQN4mpie(u"ࠨฬื฾๏๊ࠠหๆๅหห๐ࠧ๪"),sJw9QWiq1Kr0xfeVRI(u"ࠩศ๎็อแࠡๅส้้࠭๫"),AjYPLzCMReXgE04iUavqchyf6SBJ3,wdftVMyzF17cYETHu(u"ࠪื๏ืแาࠢࡇࡒࡘࠦ็้ࠢฯ๋ฬุࠠโ์ࠣห้หๆหำ้๎ฯ๊ࠦใ๊่ࠤอะอ้์็ࠤศูๅศรࠣห้๋่ศไ฼ࠤํอไิ์ิๅึอสࠡว็ํࠥษัใษ่ࠤํ฿ๆะࠢห฽฻ࠦวๅ่สืࠥ๐โ้็ࠣฬาาศ๊่๊ࠡ฾่ࠦฮุิࠤอ฿ึࠡษ็้ํอโฺࠢ࠱ࠤ้ะิ฻์็ࠤุ๐ัโำࠣࡈࡓ࡙ࠠใ็ࠣฬฬิส๋ษิࠤฬ๊ำ๋ำไีࠥอไๆ่สือࠦร้ࠢๅ้ࠥฮล๋ไสๅ์ࠦศศๆๆห๊๊ࠧ๬"))
	if YYxDRTA76kwZNBqnHSdJ==s5WMHyQN4mpie(u"࠳ᄓ"): HbSihoLTc3EIV1 = o1INZ3ViQqS0Uw5z6kMjbv(u"ࠫࡆ࡙ࡋࠨ๭")
	elif YYxDRTA76kwZNBqnHSdJ==CsDcLqQUVK4YBvHFW1(u"࠵ᄔ"): HbSihoLTc3EIV1 = V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠬࡇࡕࡕࡑࠪ๮")
	elif YYxDRTA76kwZNBqnHSdJ==I18uSKaWhgTBeYUPD4sr(u"࠷ᄕ"): HbSihoLTc3EIV1 = I18uSKaWhgTBeYUPD4sr(u"࠭ࡓࡕࡑࡓࠫ๯")
	if YYxDRTA76kwZNBqnHSdJ in [V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠰ᄗ"),QjAINyUC7MDRq5d8e4vl9(u"࠷ᄖ")]:
		Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(N6NGJ4vpmidqMCh7yo(u"ࠧࡤࡧࡱࡸࡪࡸࠧ๰"),ggjO5CrKVRPITaesWkxD(u"ࠨีํีๆื࠺ࠡࠩ๱")+I4t9qonjrm.DNS_SERVERS[BkM54Kr7Qbqn],sJw9QWiq1Kr0xfeVRI(u"ࠩึ๎ึ็ั࠻ࠢࠪ๲")+I4t9qonjrm.DNS_SERVERS[D2D96X5NGamBhrFwvL8VEbqiSfZIl],fy8iFgEkrO12NR9TWBI35sjY6qHvV,I18uSKaWhgTBeYUPD4sr(u"ࠪวำะวาࠢึ๎ึ็ัࠡࡆࡑࡗࠥอไๆ่สือࠦไไࠩ๳"))
		if Scj7zgGFVA83otMpwUkxhm0BLN1==Hr25gta6XcqO(u"࠲ᄘ"): ILpKAdnzjeTQvi8HEcMDslBS4auCN = I4t9qonjrm.DNS_SERVERS[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		else: ILpKAdnzjeTQvi8HEcMDslBS4auCN = I4t9qonjrm.DNS_SERVERS[BkM54Kr7Qbqn]
	elif YYxDRTA76kwZNBqnHSdJ==o1INZ3ViQqS0Uw5z6kMjbv(u"࠴ᄙ"): ILpKAdnzjeTQvi8HEcMDslBS4auCN = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	else: HbSihoLTc3EIV1 = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if HbSihoLTc3EIV1:
		OdiZIyCfDUsW3JBGR2VAb.setSetting(SnhLjmfeJC(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧ๴"),HbSihoLTc3EIV1)
		OdiZIyCfDUsW3JBGR2VAb.setSetting(KfHAW8VGbrxi(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡦࡱࡷࠬ๵"),ILpKAdnzjeTQvi8HEcMDslBS4auCN)
		TTdUry26C0VK = kf40tulvSA7z9RqNF5dXca3seMD[HbSihoLTc3EIV1]+ILpKAdnzjeTQvi8HEcMDslBS4auCN
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,TTdUry26C0VK)
	return
def FSCaWZO7sgIwkmYDt8udBX9Up():
	jmbLzx5WT68MBtIQonOXkpuy = OdiZIyCfDUsW3JBGR2VAb.getSetting(LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫ๶"))
	kf40tulvSA7z9RqNF5dXca3seMD = {}
	kf40tulvSA7z9RqNF5dXca3seMD[CsDcLqQUVK4YBvHFW1(u"ࠧࡂࡗࡗࡓࠬ๷")] = EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠨษ็ฬึ๎ใิ์ࠣห้ะไใษษ๎ࠥาว่ิ่้ࠣ฿ๅๅࠩ๸")
	kf40tulvSA7z9RqNF5dXca3seMD[Gcw2nelTR864XCVruO3mAFqI5a(u"ࠩࡄࡗࡐ࠭๹")] = vU6DxuzPwMpg(u"ࠪห้ฮั้ๅึ๎ฺู๊ࠥ็็ࠤอ฿ฯࠡษ็ื๊ออࠡๆ๊ࠫ๺")
	kf40tulvSA7z9RqNF5dXca3seMD[C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠫࡘ࡚ࡏࡑࠩ๻")] = vU6DxuzPwMpg(u"ࠬอไษำ๋็ุ๐ࠠๆฬ๋ๆๆࠦสๆษ่หࠥ๎ศศๆๆห๊๊ࠧ๼")
	AjYPLzCMReXgE04iUavqchyf6SBJ3 = kf40tulvSA7z9RqNF5dXca3seMD[jmbLzx5WT68MBtIQonOXkpuy]
	YYxDRTA76kwZNBqnHSdJ = jPRJMOhT415yvioG8rN9m0Q3b(fy8iFgEkrO12NR9TWBI35sjY6qHvV,FgXzMs0YSDt(u"࠭สี฼ํ่ࠥ฿ๆะࠢส่๊๎วโไฬࠫ๽"),vU6DxuzPwMpg(u"ࠧหึ฽๎้ࠦสๅไสส๏࠭๾"),ssynAg0zhSkoCpOMDV9(u"ࠨวํๆฬ็ࠠไษ่่ࠬ๿"),AjYPLzCMReXgE04iUavqchyf6SBJ3,N6NGJ4vpmidqMCh7yo(u"ࠩส่อื่ไีํࠤ์๎ࠠอ้สึࠥ็๊ࠡษ็ษ๋ะั็์อࠤ๏฿ๅๅ๋ࠢื๏฽ࠠษ์้ࠤัํวำๅࠣ์ฬ๊ล็ฬิ๊๏ะࠠ࠯๊ࠢ์ࠥ๐ำหๆ่ࠤ฼๊ศศฬๆࠤํ๐โ้็ࠣฬุำศ่ษࠣฬิ๊วࠡ็้็ࠥัๅࠡ์ห฽ะํวࠡๆๆࠤ࠳ࠦ็ๅࠢอี๏ีࠠหึ฽๎้ࠦรๆࠢศ๎็อแࠡษ็ฬึ๎ใิ์ࠣรࠬ຀"))
	if YYxDRTA76kwZNBqnHSdJ==AAbvaXV2DQzfNHdm4U3tT(u"࠳ᄚ"): HbSihoLTc3EIV1 = s5WMHyQN4mpie(u"ࠪࡅࡘࡑࠧກ")
	elif YYxDRTA76kwZNBqnHSdJ==CsDcLqQUVK4YBvHFW1(u"࠵ᄛ"): HbSihoLTc3EIV1 = jL5CrsRwebpyDVXUc1EQP(u"ࠫࡆ࡛ࡔࡐࠩຂ")
	elif YYxDRTA76kwZNBqnHSdJ==FmYoGejTnwKME7d9zPc(u"࠷ᄜ"): HbSihoLTc3EIV1 = OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࡙ࠬࡔࡐࡒࠪ຃")
	else: HbSihoLTc3EIV1 = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if HbSihoLTc3EIV1:
		OdiZIyCfDUsW3JBGR2VAb.setSetting(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫຄ"),HbSihoLTc3EIV1)
		TTdUry26C0VK = kf40tulvSA7z9RqNF5dXca3seMD[HbSihoLTc3EIV1]
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,TTdUry26C0VK)
	return
def W2q3wGdMhxQN():
	eJGmNyAD8O4n3 = OdiZIyCfDUsW3JBGR2VAb.getSetting(o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫ࠧ຅"))
	if eJGmNyAD8O4n3==ggjO5CrKVRPITaesWkxD(u"ࠨࡕࡗࡓࡕ࠭ຆ"): header = Gcw2nelTR864XCVruO3mAFqI5a(u"ࠩอาื๐ๆࠡษ็ๆํอฦๆ่ࠢฮํ่แࠨງ")
	else: header = Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠪฮำุ๊็ࠢส่็๎วว็้ࠣๆ฿ไࠨຈ")
	Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,FmYoGejTnwKME7d9zPc(u"ࠫส๐โศใࠪຉ"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠬะแฺ์็ࠫຊ"),header,ggjO5CrKVRPITaesWkxD(u"࠭โ้ษษ้ࠥอไษำ้ห๊า๋ࠠฬ่ࠤฯำฯ๋อ๊หࠥษ่ห๊่หฯ๐ใ๋ษࠣฬ฾ีࠠ࠲࠸ࠣืฬ฿ษࠡ็้ࠤศ๎ไࠡลึฮำีวๆࠢ࠱࠲ࠥ๎ล๋ไสๅࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠥ๐ฤะ์ࠣษ้๏ࠠหฯา๎ะํวࠡใํࠤ่๊ࠠๆำฬࠤ๏ะๅࠡษึฮำีวๆࠢส่็๎วว็ࠣ࠲࠳่่ࠦาสࠤ๏ูศษࠢห฻หࠦแ๋ࠢไฮาࠦโ้ษษ้ࠥอไษำ้ห๊า࡜࡯࡞ࡱࠤ์๊ࠠหำํำࠥะแฺ์็ࠤศ๋ࠠฦ์ๅหๆࠦสฯิํ๊ࠥอไใ๊สส๊ࠦฟࠢࠣࠪ຋"))
	if Scj7zgGFVA83otMpwUkxhm0BLN1==-vU6DxuzPwMpg(u"࠷ᄝ"): return
	elif Scj7zgGFVA83otMpwUkxhm0BLN1:
		OdiZIyCfDUsW3JBGR2VAb.setSetting(ssynAg0zhSkoCpOMDV9(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫ࠧຌ"),CsDcLqQUVK4YBvHFW1(u"ࠨࡃࡘࡘࡔ࠭ຍ"))
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,sJw9QWiq1Kr0xfeVRI(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬຎ"),uulNDCPyef78(u"ࠪฮ๊ࠦสโ฻ํ่ࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠬຏ"))
	else:
		OdiZIyCfDUsW3JBGR2VAb.setSetting(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡱࡹࡸࡩࡡࡤࡪࡨࠫຐ"),s5WMHyQN4mpie(u"࡙ࠬࡔࡐࡒࠪຑ"))
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,oRJAfwD957WkUyBM1Ehu8m(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩຒ"),PlpyFa9QMKXxOD1cvHzmI(u"ࠧห็ࠣษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠩຓ"))
	return
def a57Uq6WviAyYEmVlwXzSMxh3grOHT8(YMaiHbnIThsP7q):
	if YMaiHbnIThsP7q!=fy8iFgEkrO12NR9TWBI35sjY6qHvV:
		YMaiHbnIThsP7q = RRS3fV9tw8o5WGdQanhEH2(YMaiHbnIThsP7q)
		YMaiHbnIThsP7q = YMaiHbnIThsP7q.decode(Tk9eH2qw6Brsuhj).encode(Tk9eH2qw6Brsuhj)
		JgqxhebYEvdOi2 = sIzDXlTHYUC5L3xZGnr(u"࠱࠱࠳࠳࠷ᄞ")
		IZEyPUqTXniB9x3fcCV7NYlpLA4g = nn19vN7ifGslVJODZWzCSudBK8.Window(JgqxhebYEvdOi2)
		IZEyPUqTXniB9x3fcCV7NYlpLA4g.getControl(AAbvaXV2DQzfNHdm4U3tT(u"࠴࠳࠴ᄟ")).setLabel(YMaiHbnIThsP7q)
	return
iduMQk2x7zjYLh1XUAOepWys = [
			 LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠣࡧࡻࡸࡪࡴࡳࡪࡱࡱࠤࡦࡼࡳࡱࡣࡦࡩࡸ࠶ࠠࡪࡵࠣࡲࡴࡺࠠࡤࡷࡵࡶࡪࡴࡴ࡭ࡻࠣࡷࡺࡶࡰࡰࡴࡷࡩࡩࠨດ")
			,AAbvaXV2DQzfNHdm4U3tT(u"ࠩࡆ࡬ࡪࡩ࡫ࡪࡰࡪࠤ࡫ࡵࡲࠡࡏࡤࡰ࡮ࡩࡩࡰࡷࡶࠤࡸࡩࡲࡪࡲࡷࡷࠬຕ")
			,jL5CrsRwebpyDVXUc1EQP(u"ࠪࡔ࡛ࡘࠠࡊࡒࡗ࡚࡙ࠥࡩ࡮ࡲ࡯ࡩࠥࡉ࡬ࡪࡧࡱࡸࠬຖ")
			,vU6DxuzPwMpg(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥ࡜ࡩࡥࡧࡲࠤࡎࡴࡦࡰࠢࡎࡩࡾ࠭ທ")
			,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬࡺࡨࡪࡵࠣ࡬ࡦࡹࡨࠡࡨࡸࡲࡨࡺࡩࡰࡰࠣ࡭ࡸࠦࡢࡳࡱ࡮ࡩࡳ࠭ຘ")
			,aOQTKXFL54Nl60Zhp3MbE(u"࠭ࡵࡴࡧࡶࠤࡵࡲࡡࡪࡰࠣࡌ࡙࡚ࡐࠡࡨࡲࡶࠥࡧࡤࡥ࠯ࡲࡲࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡳࠨນ")
			,aOQTKXFL54Nl60Zhp3MbE(u"ࠧࡢࡦࡹࡥࡳࡩࡥࡥ࠯ࡸࡷࡦ࡭ࡥ࠯ࡪࡷࡱࡱ࠭ບ")+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠨࠥࠪປ")+wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠩࡶࡷࡱ࠳ࡷࡢࡴࡱ࡭ࡳ࡭ࡳࠨຜ")
			,ssynAg0zhSkoCpOMDV9(u"ࠪࡍࡳࡹࡥࡤࡷࡵࡩࡗ࡫ࡱࡶࡧࡶࡸ࡜ࡧࡲ࡯࡫ࡱ࡫࠱࠭ຝ")
			,AAbvaXV2DQzfNHdm4U3tT(u"ࠫࡊࡸࡲࡰࡴࠣ࡫ࡪࡺࡴࡪࡰࡪࠤࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈ࠴ࡅ࡭ࡰࡦࡨࡩࡂ࠶ࠦࡵࡧࡻࡸࡹࡃࠧພ")
			,s5WMHyQN4mpie(u"ࠬࡽࡡࡳࡰ࡬ࡲ࡬ࡹ࠮ࡸࡣࡵࡲ࠭࠭ຟ")
			,QjAINyUC7MDRq5d8e4vl9(u"࠭࡞࡟ࡠࡡࡢࠬຠ")
			,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠧࡍࡱࡤࡨ࡮ࡴࡧࠡࡵ࡮࡭ࡳࠦࡦࡪ࡮ࡨ࠾ࠬມ")
			]
def jnGO7l1fABTd8keuVNaMLWXFyh(ZUcBH6T19kAxhs):
	if FgXzMs0YSDt(u"ࠨࡎࡲࡥࡩ࡯࡮ࡨࠢࡶ࡯࡮ࡴࠠࡧ࡫࡯ࡩ࠿࠭ຢ") in ZUcBH6T19kAxhs and CsDcLqQUVK4YBvHFW1(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧຣ") in ZUcBH6T19kAxhs: return EsCplGc5N4mBuYW0RVQt6b
	for YMaiHbnIThsP7q in iduMQk2x7zjYLh1XUAOepWys:
		if YMaiHbnIThsP7q in ZUcBH6T19kAxhs: return EsCplGc5N4mBuYW0RVQt6b
	return LhFAGlQ19zr
def YOslAhGtq90V(data):
	JZV7j62a5st1eNDy8qOXKz = V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠺ᄡ") if jTDWgftK7NEmx0JAkOn2aRIvweq else ggjO5CrKVRPITaesWkxD(u"࠳࠸ᄠ")
	data = data.replace(SnhLjmfeJC(u"࠷࠵ᄢ")*ksJdoFWhxTz8Y2N7bOZE,JZV7j62a5st1eNDy8qOXKz*ksJdoFWhxTz8Y2N7bOZE)
	data = data.replace(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪࠤࡁ࡭ࡥ࡯ࡧࡵࡥࡱࡄ࠺ࠡࠩ຤"),FgXzMs0YSDt(u"ࠫ࠿ࠦࠧລ"))
	gWBLDSlZGwqxHT = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	for ZUcBH6T19kAxhs in data.splitlines():
		aRHPtf3Q9XqvOpNw0Z1xBLWlhIzU = EcQxOa3RJm86WjTKA.findall(oRJAfwD957WkUyBM1Ehu8m(u"ࠬࠦࠠࠡࠢࠣࡊ࡮ࡲࡥࠡࠤࠫ࠲࠯ࡅࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠲࠮ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ຦"),ZUcBH6T19kAxhs,EcQxOa3RJm86WjTKA.DOTALL)
		if aRHPtf3Q9XqvOpNw0Z1xBLWlhIzU: ZUcBH6T19kAxhs = ZUcBH6T19kAxhs.replace(aRHPtf3Q9XqvOpNw0Z1xBLWlhIzU[D2D96X5NGamBhrFwvL8VEbqiSfZIl],fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		gWBLDSlZGwqxHT += C0qrknitpM4Z+ZUcBH6T19kAxhs
	return gWBLDSlZGwqxHT
def WK35wcVTYr7Aplo(byD29pq4EHwIj87QlfPhOUCe):
	if sIzDXlTHYUC5L3xZGnr(u"࠭ࡏࡍࡆࠪວ") in byD29pq4EHwIj87QlfPhOUCe:
		Sj4FNHP2DhA9YXRUwLqoIkt = gs6a8pwU4xMn9JjPkKNm0Xv
		header = I18uSKaWhgTBeYUPD4sr(u"ࠧใำสลฮࠦวๅีฯ่ࠥอไใัํ้ࠥลࠧຨ")
	else:
		Sj4FNHP2DhA9YXRUwLqoIkt = Z3WAPsTKBgHV5uSfGitDNL4
		header = V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠨไิหฦฯࠠศๆึะ้ࠦวๅฯส่๏ࠦฟࠨຩ")
	Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,header,uulNDCPyef78(u"ࠩึะ้ࠦวๅลั฻ฬว๋ࠠฯอ์๏ࠦรุ๋สࠤ฾๊้ࠡีฯ่ࠥอไศีอาิอๅࠡ࠰ࠣ์ฬ๊วฬ่ํ๊ࠥ฼ั้ำํอ๊ࠥๅฺำไอ้๊ࠥโࠢะำะะࠠศๆุ่่๊ษ๊่ࠡหࠥํ่ࠡษ็้่อๆࠡษ็ิ๏ࠦำษสࠣัิ๎หࠡษ็ู้้ไสࠢ࠱ࠤ่๎ฯ๋ࠢํัฯ็ุࠡสึะ้๐ๆࠡ࠰ࠣห้ษ่ๅ๊ࠢ์ࠥอไิฮ็ࠤฬ๊อศๆํࠤํ็๊่่ࠢ฽้๎ๅศฬࠣฮอีรࠡ็้ิࠥฮฯศ์ฬࠤฬ๊สี฼ํ่ࠥอไฮษ็๎๊ࠥศา่ส้ัࠦใ้ัํࠤํอไ๊ࠢส่ว์ࠠ࠯ࠢฦ้ฬࠦวๅีฯ่ࠥอไใัํ้ࠥ็็้ࠢสุ่าไࠡษ็ืฬฮโࠡษ็ิ๏ࠦสๆࠢฯ้฾ํࠠๆ่ࠣฬึ์วๆฮࠣ็ํี๊ࠡไห่ࠥศฮาࠢศ฻ๆอมࠡๆ๊ࠤ࠳ࠦ็ๅࠢอี๏ีࠠศๆสืฯ๋ัศำࠣรࠬສ"))
	if Scj7zgGFVA83otMpwUkxhm0BLN1!=I18uSKaWhgTBeYUPD4sr(u"࠶ᄣ"): return
	NpxIYgtLq4CHVfUw0b8,FdM76PmREvS0tYfyZx3eTgQw8o5I = [],oRJAfwD957WkUyBM1Ehu8m(u"࠶ᄤ")
	size,count = ucm10ohnRLA8d5ybFKEYkNQa3e6Gr(Sj4FNHP2DhA9YXRUwLqoIkt)
	file = open(Sj4FNHP2DhA9YXRUwLqoIkt,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠪࡶࡧ࠭ຫ"))
	if size>C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠲࠲࠳࠶࠵࠶ᄦ"): file.seek(-Gcw2nelTR864XCVruO3mAFqI5a(u"࠱࠱࠲࠴࠴࠵ᄥ"),HoxKENAey2MdTt9kDUrVnWGLS0CPa.SEEK_END)
	data = file.read()
	file.close()
	if jTDWgftK7NEmx0JAkOn2aRIvweq: data = data.decode(Tk9eH2qw6Brsuhj)
	data = YOslAhGtq90V(data)
	KkS426yjbo8xFvBMVig5YcLCH = data.split(C0qrknitpM4Z)
	for ZUcBH6T19kAxhs in reversed(KkS426yjbo8xFvBMVig5YcLCH):
		aISU7ykZepKDidr = jnGO7l1fABTd8keuVNaMLWXFyh(ZUcBH6T19kAxhs)
		if aISU7ykZepKDidr: continue
		ZUcBH6T19kAxhs = ZUcBH6T19kAxhs.replace(SnhLjmfeJC(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡤ࠭ຬ"),WydpaVx5YmLoCiIgA34eEBlb+KfHAW8VGbrxi(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨອ")+T7ASIp1ZYwio9HQ8cObJK)
		ZUcBH6T19kAxhs = ZUcBH6T19kAxhs.replace(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠭ࡅࡓࡔࡒࡖ࠿࠭ຮ"),QjAINyUC7MDRq5d8e4vl9(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊ࠵࠶࠰࠱࡟ࠪຯ")+wdftVMyzF17cYETHu(u"ࠨࡇࡕࡖࡔࡘ࠺ࠨະ")+T7ASIp1ZYwio9HQ8cObJK)
		FFw9eEQqvOgfWr = fy8iFgEkrO12NR9TWBI35sjY6qHvV
		hx7rKJYDNCn4m0LGdp = EcQxOa3RJm86WjTKA.findall(FmYoGejTnwKME7d9zPc(u"ࠩࡡࠬࡡࡪࠫ࠮ࠪ࡟ࡨ࠰࠳࡜ࡥ࠭ࠣࡠࡩ࠱࠺࡝ࡦ࠮࠾ࡡࡪࠫ࡝࠰࡟ࡨ࠰࠯ࠩࠩࠢࡗ࠾ࡡࡪࠫࠪࠩັ"),ZUcBH6T19kAxhs,EcQxOa3RJm86WjTKA.DOTALL)
		if hx7rKJYDNCn4m0LGdp:
			ZUcBH6T19kAxhs = ZUcBH6T19kAxhs.replace(hx7rKJYDNCn4m0LGdp[D2D96X5NGamBhrFwvL8VEbqiSfZIl][D2D96X5NGamBhrFwvL8VEbqiSfZIl],hx7rKJYDNCn4m0LGdp[D2D96X5NGamBhrFwvL8VEbqiSfZIl][BkM54Kr7Qbqn]).replace(hx7rKJYDNCn4m0LGdp[D2D96X5NGamBhrFwvL8VEbqiSfZIl][teaC5j4HuGDqpwcmUzJ],fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			FFw9eEQqvOgfWr = hx7rKJYDNCn4m0LGdp[D2D96X5NGamBhrFwvL8VEbqiSfZIl][BkM54Kr7Qbqn]
		else:
			hx7rKJYDNCn4m0LGdp = EcQxOa3RJm86WjTKA.findall(AAbvaXV2DQzfNHdm4U3tT(u"ࠪࡢ࠭ࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪາ"),ZUcBH6T19kAxhs,EcQxOa3RJm86WjTKA.DOTALL)
			if hx7rKJYDNCn4m0LGdp:
				ZUcBH6T19kAxhs = ZUcBH6T19kAxhs.replace(hx7rKJYDNCn4m0LGdp[D2D96X5NGamBhrFwvL8VEbqiSfZIl][BkM54Kr7Qbqn],fy8iFgEkrO12NR9TWBI35sjY6qHvV)
				FFw9eEQqvOgfWr = hx7rKJYDNCn4m0LGdp[D2D96X5NGamBhrFwvL8VEbqiSfZIl][D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		if FFw9eEQqvOgfWr: ZUcBH6T19kAxhs = ZUcBH6T19kAxhs.replace(FFw9eEQqvOgfWr,n0nFOd4yR97fQzNLSW+FFw9eEQqvOgfWr+T7ASIp1ZYwio9HQ8cObJK)
		NpxIYgtLq4CHVfUw0b8.append(ZUcBH6T19kAxhs)
		if len(str(NpxIYgtLq4CHVfUw0b8))>s5WMHyQN4mpie(u"࠷࠳࠵࠵࠶ᄧ"): break
	NpxIYgtLq4CHVfUw0b8 = reversed(NpxIYgtLq4CHVfUw0b8)
	UMa2Vu3mRfq7Nwj6y8Aeo0 = C0qrknitpM4Z.join(NpxIYgtLq4CHVfUw0b8)
	cFjMEShi6Pp0otRBgeXq8(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫࡱ࡫ࡦࡵࠩຳ"),uulNDCPyef78(u"ࠬศฮาࠢฦื฼ืࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠩິ"),UMa2Vu3mRfq7Nwj6y8Aeo0,aOQTKXFL54Nl60Zhp3MbE(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩີ"))
	return
def DmH2JECZ40cuQv():
	kqf1CTQWtAhX8 = open(VVYNwt2Jf9lsvGQcWo,aOQTKXFL54Nl60Zhp3MbE(u"ࠧࡳࡤࠪຶ")).read()
	if jTDWgftK7NEmx0JAkOn2aRIvweq: kqf1CTQWtAhX8 = kqf1CTQWtAhX8.decode(Tk9eH2qw6Brsuhj)
	kqf1CTQWtAhX8 = kqf1CTQWtAhX8.replace(EE1jeHnIoad(u"ࠨ࡞ࡷࠫື"),I18uSKaWhgTBeYUPD4sr(u"ࠩࠣࠤຸࠥࠦࠠࠡࠢࠣࠫ"))
	oSiV9K6kg3pRXF07Q = EcQxOa3RJm86WjTKA.findall(PlpyFa9QMKXxOD1cvHzmI(u"ࠪࠬࡻࡢࡤ࠯ࠬࡂ࠭ࡠࡢ࡮࡝ࡴࡠູࠫ"),kqf1CTQWtAhX8,EcQxOa3RJm86WjTKA.DOTALL)
	for ZUcBH6T19kAxhs in oSiV9K6kg3pRXF07Q:
		kqf1CTQWtAhX8 = kqf1CTQWtAhX8.replace(ZUcBH6T19kAxhs,WydpaVx5YmLoCiIgA34eEBlb+ZUcBH6T19kAxhs+T7ASIp1ZYwio9HQ8cObJK)
	BBUOlfYgcEFQCetXh8A04objZKG(oRJAfwD957WkUyBM1Ehu8m(u"ࠫฬ๊ส฻์ํีฬะࠠศๆฦา๏ืษࠡใํࠤฬ๊ศาษ่ะ຺ࠬ"),kqf1CTQWtAhX8)
	return
def eiLclyGUkAh1Et682n():
	XgbcrBleMx5LYWzKjFCHIOP = sIzDXlTHYUC5L3xZGnr(u"ࠬฮูืࠢส่ศุัศำࠣ฽้๏ࠠศๆิ๎๊๎สࠡๅ๋๊ฯื่ๅࠢอ์ๆืࠠฦ็ๆห๋๐ษࠡฬๅำ๏๋้ࠠฬฦา๏ืࠠศๆไ๎ิ๐่๊๊ࠡิ์ࠦวๅลีีฬื่ࠠ์ࠣห้ษำ่็ࠣ์ฬ๊ราไสู้๋ࠥࠡส฼ฺࠥ๎ใศๆอห้๐ࠧົ")
	mmv7XkyreCIJGUqhTYi5KB6DWSn = Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠭ไหไา๎๊ࠦวๅใํำ๏๎ࠠศีอาิ๋ࠠศๆึ๋๊ࠦวๅ์่๎๋่ࠦๅฬฦา๏ื็ࠡษึฮำีๅࠡษ็ื์๋ࠠศๆํืฬืࠠ࠯ࠢฦ้ฬูࠦะหࠣหุํๅࠡ็อฮฬ๊๊สࠢไ๋ีํࠠหไ๋้ࠥฮสฮำํ็ࠥอไโ์า๎ํࠦศ้ไอࠤฬ้ศา่๊ࠢࠥ๎โหࠢสุ่ํๅࠡษ็์ฬำฯࠡ࠰ࠣว๊อࠠศๆึ๋๊ࠦวๅล฼่๎่ࠦศๆฦืๆ๊ࠠโ้๋ࠤ๏ำัไࠢส่ๆ๐ฯ๋๊ࠣษ้๏ࠠศๆฦ้ฬ๋ࠠฤ๊ࠣษ้๏ࠠศๆ๋ีฬว้ࠠๆๆ๊ࠥฮโโิฬࠤ่ฮ๊าหࠪຼ")
	kQ90RuKEmXbqfP6as7pe4MIdvoG1cH = C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧฤ็สࠤฬ๊ราไส้ࠥ็็๋ࠢอืฯิฯๆࠢ็่ฯ่ฯ๋็ࠣ์ฬ๊สฤะํีࠥ๎ไไ่ࠣฬ๊่ฯศำࠣ฽ิีࠠศๆฮ์ฬ์๊๊ࠡส่ิ่ววไࠣ࠲๋ࠥหๅษࠣี็๋ࠠ࠶࠶࠷ࠤฯ฿ๆ๋ࠢ࠸ࠤิ่ววไࠣ์ࠥ࠺࠴ࠡอส๊๏ฯࠠฦๆ์ࠤฬ๊รๆษ่ࠤศ๎ࠠฦๆ์ࠤฬ๊่าษฤࠤอำำษࠢสืฯิฯศ็ๆࠤ้๊ำ่็ࠣห้๐ๅ๋่ࠣวํࠦำ่็ࠣห้๐ำศำࠪຽ")
	kf40tulvSA7z9RqNF5dXca3seMD = XgbcrBleMx5LYWzKjFCHIOP+sIzDXlTHYUC5L3xZGnr(u"ࠨ࠼ࠣࠫ຾")+mmv7XkyreCIJGUqhTYi5KB6DWSn+aOQTKXFL54Nl60Zhp3MbE(u"ࠩࠣ࠲ࠥ࠭຿")+kQ90RuKEmXbqfP6as7pe4MIdvoG1cH
	cFjMEShi6Pp0otRBgeXq8(O3OVuapf0YFjbm5oUQDg(u"ࠪࡧࡪࡴࡴࡦࡴࠪເ"),QjAINyUC7MDRq5d8e4vl9(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧແ"),kf40tulvSA7z9RqNF5dXca3seMD,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨໂ"))
	return
def PkNFw8KBOny2fb9D(type,kf40tulvSA7z9RqNF5dXca3seMD,showDialogs=EsCplGc5N4mBuYW0RVQt6b,url=fy8iFgEkrO12NR9TWBI35sjY6qHvV,mE7D5fBQZOKJdhtVUkHaIgRWpx=fy8iFgEkrO12NR9TWBI35sjY6qHvV,YMaiHbnIThsP7q=fy8iFgEkrO12NR9TWBI35sjY6qHvV,Re3Tm1AxD4hLc2EOPYzqZn=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	tDY4i21S96LvcKAmVaORdf = EsCplGc5N4mBuYW0RVQt6b
	if not I4t9qonjrm.tFkvuaLGpKHMI2l5J:
		if showDialogs:
			IfCQEwBA2HrL76m8JKzxkGFtd = (N6NGJ4vpmidqMCh7yo(u"࠭วๅีฺี࠿࠭ໃ") in kf40tulvSA7z9RqNF5dXca3seMD and CsDcLqQUVK4YBvHFW1(u"ࠧศๆ่็ฬ์࠺ࠨໄ") in kf40tulvSA7z9RqNF5dXca3seMD and FgXzMs0YSDt(u"ࠨษ็้้็࠺ࠨ໅") in kf40tulvSA7z9RqNF5dXca3seMD and ggjO5CrKVRPITaesWkxD(u"ࠩส่ำ฽รࠨໆ") in kf40tulvSA7z9RqNF5dXca3seMD and AAbvaXV2DQzfNHdm4U3tT(u"ࠪห้๋ีะำ࠽ࠫ໇") in kf40tulvSA7z9RqNF5dXca3seMD)
			if not IfCQEwBA2HrL76m8JKzxkGFtd: tDY4i21S96LvcKAmVaORdf = vv7siKgM9IfbCjPNqxXD(I18uSKaWhgTBeYUPD4sr(u"ࠫࡨ࡫࡮ࡵࡧࡵ່ࠫ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,O3OVuapf0YFjbm5oUQDg(u"ࠬํไࠡฬิื้ࠦ็ั้ࠣห้ืำศๆฬࠤส๊้ࠡษ็้อืๅอ້ࠩ"),kf40tulvSA7z9RqNF5dXca3seMD.replace(ggjO5CrKVRPITaesWkxD(u"࠭࡜࡝ࡰ໊ࠪ"),C0qrknitpM4Z))
	elif showDialogs:
		kf40tulvSA7z9RqNF5dXca3seMD = wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧ࡝࡞ࡱฮ๊ࠦๅิฯࠣห้ืำศๆฬࡠࡡࡴสๆ่ࠢืาࠦัิษ็อࡡࡢ࡮ห็ุ้ࠣำࠠศๆิืฬ๊ษ࡝࡞ࡱฮ๊ࠦๅิฯࠣห้ืำศๆฬࡠࡡࡴสๆ่ࠢืาࠦวๅำึห้ฯ໋ࠧ")
		eVQYlWPpcqjx2LaJwkv = vv7siKgM9IfbCjPNqxXD(ssynAg0zhSkoCpOMDV9(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ໌"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,s5WMHyQN4mpie(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩໍ")+O3OVuapf0YFjbm5oUQDg(u"ࠪࠤࠥ࠷࠯࠶ࠩ໎"),aOQTKXFL54Nl60Zhp3MbE(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩ໏"))
		AqFj61a98brC7s23YpULIV = vv7siKgM9IfbCjPNqxXD(N6NGJ4vpmidqMCh7yo(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ໐"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭໑")+QjAINyUC7MDRq5d8e4vl9(u"ࠧࠡࠢ࠵࠳࠺࠭໒"),aOQTKXFL54Nl60Zhp3MbE(u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭໓"))
		aDAGR1Hxz56Pf0wZY7mrNbOL3 = vv7siKgM9IfbCjPNqxXD(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩࡦࡩࡳࡺࡥࡳࠩ໔"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,oRJAfwD957WkUyBM1Ehu8m(u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪ໕")+N6NGJ4vpmidqMCh7yo(u"ࠫࠥࠦ࠳࠰࠷ࠪ໖"),FgXzMs0YSDt(u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪ໗"))
		xuWlFOj5GA = vv7siKgM9IfbCjPNqxXD(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭ࡣࡦࡰࡷࡩࡷ࠭໘"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧ໙")+C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨࠢࠣ࠸࠴࠻ࠧ໚"),QjAINyUC7MDRq5d8e4vl9(u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧ໛"))
		tDY4i21S96LvcKAmVaORdf = vv7siKgM9IfbCjPNqxXD(QjAINyUC7MDRq5d8e4vl9(u"ࠪࡧࡪࡴࡴࡦࡴࠪໜ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,sJw9QWiq1Kr0xfeVRI(u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫໝ")+oRJAfwD957WkUyBM1Ehu8m(u"ࠬࠦࠠ࠶࠱࠸ࠫໞ"),sJw9QWiq1Kr0xfeVRI(u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫໟ"))
	jewzZuNFibTO = ooNmbAs0RwxIG2ahd6(LhFAGlQ19zr)
	tkQLPWIgKNG5B6cO = I18uSKaWhgTBeYUPD4sr(u"ࠧࡂࡘ࠽ࠤࠬ໠")+jewzZuNFibTO+wdftVMyzF17cYETHu(u"ࠨ࠯ࠪ໡")+type
	ogwSxkDfqmctLUiVEC7 = EsCplGc5N4mBuYW0RVQt6b if jL5CrsRwebpyDVXUc1EQP(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬ໢") in YMaiHbnIThsP7q else LhFAGlQ19zr
	if not tDY4i21S96LvcKAmVaORdf:
		if showDialogs: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ggjO5CrKVRPITaesWkxD(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭໣"),CsDcLqQUVK4YBvHFW1(u"ࠫฯ๋ࠠฦๆ฽หฦࠦวๅวิืฬ๊ࠠษ่สลࠥ฿ไฺ๊่ࠢอ้ࠧ໤"))
		return LhFAGlQ19zr
	K1QZRLwB89hi7I0m2GAaYPOFCWUd = bEWpDHXjCBqd7aOiN6UG5k.getInfoLabel(QjAINyUC7MDRq5d8e4vl9(u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡌࡲࡪࡧࡱࡨࡱࡿࡎࡢ࡯ࡨࠫ໥"))
	kf40tulvSA7z9RqNF5dXca3seMD += FmYoGejTnwKME7d9zPc(u"࠭ࠠ࡝࡞ࡱࡠࡡࡴ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾ࠢࡀࡁࡂࡃࠠ࡝࡞ࡱࡅࡩࡪ࡯࡯࡙ࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࠬ໦")+KoxvjArhL1TdInDmN9s+sJw9QWiq1Kr0xfeVRI(u"ࠧࠡ࠼࡟ࡠࡳ࠭໧")
	kf40tulvSA7z9RqNF5dXca3seMD += OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠨࡇࡰࡥ࡮ࡲࠠࡔࡧࡱࡨࡪࡸ࠺ࠡࠩ໨")+jewzZuNFibTO+ssynAg0zhSkoCpOMDV9(u"ࠩࠣ࠾ࡡࡢ࡮ࡌࡱࡧ࡭ࠥ࡜ࡥࡳࡵ࡬ࡳࡳࡀࠠࠨ໩")+dxpe1RLMQHSazAFU+C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠪࠤ࠿ࡢ࡜࡯ࠩ໪")
	kf40tulvSA7z9RqNF5dXca3seMD += OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠫࡐࡵࡤࡪࠢࡑࡥࡲ࡫࠺ࠡࠩ໫")+K1QZRLwB89hi7I0m2GAaYPOFCWUd
	qIQCz90DuxjlYJ = YkdA7N1UeQbwfEtgV8i3ZaS6u95()
	qIQCz90DuxjlYJ = DVX5GWhnIxYlSd9rEuetjk40UJ(qIQCz90DuxjlYJ)
	if qIQCz90DuxjlYJ: kf40tulvSA7z9RqNF5dXca3seMD += Hr25gta6XcqO(u"ࠬࠦ࠺࡝࡞ࡱࡐࡴࡩࡡࡵ࡫ࡲࡲ࠿ࠦࠧ໬")+qIQCz90DuxjlYJ
	if url: kf40tulvSA7z9RqNF5dXca3seMD += CsDcLqQUVK4YBvHFW1(u"࠭ࠠ࠻࡞࡟ࡲ࡚ࡘࡌ࠻ࠢࠪ໭")+url
	if mE7D5fBQZOKJdhtVUkHaIgRWpx: kf40tulvSA7z9RqNF5dXca3seMD += uulNDCPyef78(u"ࠧࠡ࠼࡟ࡠࡳ࡙࡯ࡶࡴࡦࡩ࠿ࠦࠧ໮")+mE7D5fBQZOKJdhtVUkHaIgRWpx
	kf40tulvSA7z9RqNF5dXca3seMD += KfHAW8VGbrxi(u"ࠨࠢ࠽ࡠࡡࡴࠧ໯")
	if showDialogs: a6rVSjDMF87KyYINcuOP1l40Hbp(EE1jeHnIoad(u"ࠩฯหึ๐ࠠศๆศีุอไࠨ໰"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪห้ืฬศรࠣห้อๆหฺสีࠬ໱"))
	if Re3Tm1AxD4hLc2EOPYzqZn:
		UMa2Vu3mRfq7Nwj6y8Aeo0 = Re3Tm1AxD4hLc2EOPYzqZn
		if jTDWgftK7NEmx0JAkOn2aRIvweq: UMa2Vu3mRfq7Nwj6y8Aeo0 = UMa2Vu3mRfq7Nwj6y8Aeo0.encode(Tk9eH2qw6Brsuhj)
		UMa2Vu3mRfq7Nwj6y8Aeo0 = JNfHYgOdP9aR.b64encode(UMa2Vu3mRfq7Nwj6y8Aeo0)
	elif ogwSxkDfqmctLUiVEC7:
		if sJw9QWiq1Kr0xfeVRI(u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࡏࡍࡆࡢࠫ໲") in YMaiHbnIThsP7q: M7PywXKQJdqcW = gs6a8pwU4xMn9JjPkKNm0Xv
		else: M7PywXKQJdqcW = Z3WAPsTKBgHV5uSfGitDNL4
		if not HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.exists(M7PywXKQJdqcW):
			GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,PlpyFa9QMKXxOD1cvHzmI(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ໳"),FgXzMs0YSDt(u"࠭ำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡ฼ํี๋่ࠥอ๊าࠫ໴"))
			return LhFAGlQ19zr
		Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,I18uSKaWhgTBeYUPD4sr(u"ࠧ࠯࡞ࡷࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡶࡩࡳࡪࠠࡵࡪࡨࠤࡱࡵࡧࡧ࡫࡯ࡩࠬ໵"))
		NpxIYgtLq4CHVfUw0b8,FdM76PmREvS0tYfyZx3eTgQw8o5I = [],sIzDXlTHYUC5L3xZGnr(u"࠳ᄨ")
		file = open(M7PywXKQJdqcW,O3OVuapf0YFjbm5oUQDg(u"ࠨࡴࡥࠫ໶"))
		size,count = ucm10ohnRLA8d5ybFKEYkNQa3e6Gr(M7PywXKQJdqcW)
		if size>oRJAfwD957WkUyBM1Ehu8m(u"࠷࠵࠷࠰࠱࠲ᄩ"): file.seek(-oRJAfwD957WkUyBM1Ehu8m(u"࠷࠵࠷࠰࠱࠲ᄩ"),HoxKENAey2MdTt9kDUrVnWGLS0CPa.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(Tk9eH2qw6Brsuhj)
		data = YOslAhGtq90V(data)
		KkS426yjbo8xFvBMVig5YcLCH = data.splitlines()
		for ZUcBH6T19kAxhs in reversed(KkS426yjbo8xFvBMVig5YcLCH):
			aISU7ykZepKDidr = jnGO7l1fABTd8keuVNaMLWXFyh(ZUcBH6T19kAxhs)
			if aISU7ykZepKDidr: continue
			hx7rKJYDNCn4m0LGdp = EcQxOa3RJm86WjTKA.findall(ssynAg0zhSkoCpOMDV9(u"ࠩࡡࠬࡡࡪࠫ࠮ࠪ࡟ࡨ࠰࠳࡜ࡥ࠭ࠣࡠࡩ࠱࠺࡝ࡦ࠮࠾ࡡࡪࠫ࡝࠰࡟ࡨ࠰࠯ࠩࠩࠢࡗ࠾ࡡࡪࠫࠪࠩ໷"),ZUcBH6T19kAxhs,EcQxOa3RJm86WjTKA.DOTALL)
			if hx7rKJYDNCn4m0LGdp:
				ZUcBH6T19kAxhs = ZUcBH6T19kAxhs.replace(hx7rKJYDNCn4m0LGdp[D2D96X5NGamBhrFwvL8VEbqiSfZIl][D2D96X5NGamBhrFwvL8VEbqiSfZIl],hx7rKJYDNCn4m0LGdp[D2D96X5NGamBhrFwvL8VEbqiSfZIl][BkM54Kr7Qbqn]).replace(hx7rKJYDNCn4m0LGdp[D2D96X5NGamBhrFwvL8VEbqiSfZIl][teaC5j4HuGDqpwcmUzJ],fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			else:
				hx7rKJYDNCn4m0LGdp = EcQxOa3RJm86WjTKA.findall(o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪࡢ࠭ࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪ໸"),ZUcBH6T19kAxhs,EcQxOa3RJm86WjTKA.DOTALL)
				if hx7rKJYDNCn4m0LGdp: ZUcBH6T19kAxhs = ZUcBH6T19kAxhs.replace(hx7rKJYDNCn4m0LGdp[D2D96X5NGamBhrFwvL8VEbqiSfZIl][BkM54Kr7Qbqn],fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			NpxIYgtLq4CHVfUw0b8.append(ZUcBH6T19kAxhs)
			if len(str(NpxIYgtLq4CHVfUw0b8))>CsDcLqQUVK4YBvHFW1(u"࠷࠻࠱࠱࠲࠳ᄪ"): break
		NpxIYgtLq4CHVfUw0b8 = reversed(NpxIYgtLq4CHVfUw0b8)
		UMa2Vu3mRfq7Nwj6y8Aeo0 = QjAINyUC7MDRq5d8e4vl9(u"ࠫࡡࡸ࡜࡯ࠩ໹").join(NpxIYgtLq4CHVfUw0b8)
		UMa2Vu3mRfq7Nwj6y8Aeo0 = UMa2Vu3mRfq7Nwj6y8Aeo0.encode(Tk9eH2qw6Brsuhj)
		UMa2Vu3mRfq7Nwj6y8Aeo0 = JNfHYgOdP9aR.b64encode(UMa2Vu3mRfq7Nwj6y8Aeo0)
	else: UMa2Vu3mRfq7Nwj6y8Aeo0 = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	url = I4t9qonjrm.SITESURLS[QjAINyUC7MDRq5d8e4vl9(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ໺")][teaC5j4HuGDqpwcmUzJ]
	B7gtJnK24RY = {uulNDCPyef78(u"࠭ࡳࡶࡤ࡭ࡩࡨࡺࠧ໻"):tkQLPWIgKNG5B6cO,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨ໼"):kf40tulvSA7z9RqNF5dXca3seMD,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠨ࡮ࡲ࡫࡫࡯࡬ࡦࠩ໽"):UMa2Vu3mRfq7Nwj6y8Aeo0}
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,FgXzMs0YSDt(u"ࠩࡓࡓࡘ࡚ࠧ໾"),url,B7gtJnK24RY,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡙ࡅࡏࡆࡢࡉࡒࡇࡉࡍ࠯࠴ࡷࡹ࠭໿"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	if OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠫࠧࡹࡵࡤࡥࡨࡩࡩ࡫ࡤࠣ࠼ࠣ࠵࠱࠭ༀ") in FGRX4myP68S: ddecO3Tb9U5k = EsCplGc5N4mBuYW0RVQt6b
	else: ddecO3Tb9U5k = LhFAGlQ19zr
	if showDialogs:
		if ddecO3Tb9U5k:
			a6rVSjDMF87KyYINcuOP1l40Hbp(s5WMHyQN4mpie(u"ࠬะๅࠡษ็ษึูวๅࠢห๊ัออࠨ༁"),sJw9QWiq1Kr0xfeVRI(u"࠭ࡓࡶࡥࡦࡩࡸࡹࠧ༂"))
			GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,s5WMHyQN4mpie(u"ࠧࡎࡧࡶࡷࡦ࡭ࡥࠡࡵࡨࡲࡹ࠭༃"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠨฬ่ࠤสืำศๆࠣห้ืำศๆฬࠤอ์ฬศฯࠪ༄"))
		else:
			a6rVSjDMF87KyYINcuOP1l40Hbp(uulNDCPyef78(u"ࠩ็่ศูแࠡใื่ࠥอไฦำึห้࠭༅"),I18uSKaWhgTBeYUPD4sr(u"ࠪࡊࡦ࡯࡬ࡶࡴࡨࠫ༆"))
			GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,SnhLjmfeJC(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ༇"),PlpyFa9QMKXxOD1cvHzmI(u"ࠬิืฤ๋ࠢๅู๊ࠠโ์ࠣษึูวๅࠢส่ึูวๅหࠪ༈"))
	return ddecO3Tb9U5k
def XXhWcrigE1lMvTdPU39fKG():
	XgbcrBleMx5LYWzKjFCHIOP = CsDcLqQUVK4YBvHFW1(u"࠭ࡄࡰࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡵࡴࡤࡲࡸࡲࡡࡵࡧࠣࡱࡪࡴࡵࠡ࡫ࡷࡩࡲࡹࠠࡵࡱࠣࡥࠥࡲࡡ࡯ࡩࡸࡥ࡬࡫ࠠࡰࡶ࡫ࡩࡷࠦࡴࡩࡣࡱࠤࡆࡸࡡࡣ࡫ࡦࠤ࠳࠴ࠠࡐࡴࠣࡽࡴࡻࠠࡸࡣࡱࡸࠥࡺ࡯ࠡࡵ࡫ࡳࡼࠦࡁࡳࡣࡥ࡭ࡨࠦ࡬ࡦࡶࡷࡩࡷࡹࠠࡢࡰࡧࠤࡹ࡫ࡸࡵࠢࡂࠥࠬ༉")
	mmv7XkyreCIJGUqhTYi5KB6DWSn = sJw9QWiq1Kr0xfeVRI(u"่ࠧๆࠣฮึ๐ฯࠡฬิะ๊ฯࠠใ๊สส๊ࠦวๅสิ๊ฬ๋ฬࠡว็ํฺ๊ࠥสࠢฦาึ๏ࠠ฻์ิࠤฬู๊าสํอࠥ࠴࠮ࠡล่ࠤฯื๊ะࠢศ฼์อัࠡษ็วาืแ๊ࠡส่่ะวษหࠣห้฿ัษ์ฬࠤฤࠧࠧ༊")
	TrdwtBCoInxfebSWZl5XV34aDyH = jPRJMOhT415yvioG8rN9m0Q3b(Hr25gta6XcqO(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ་"),aOQTKXFL54Nl60Zhp3MbE(u"ࠩัีําࠠࡆࡺ࡬ࡸࠬ༌"),Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪࡘࡷࡧ࡮ࡴ࡮ࡤࡸࡪࠦสาฮ่อࠬ།"),Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫ฾ืศ๋ࠢࡄࡶࡦࡨࡩࡤࠩ༎"),QjAINyUC7MDRq5d8e4vl9(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ༏"),XgbcrBleMx5LYWzKjFCHIOP+FgXzMs0YSDt(u"࠭࡜࡯࡞ࡱࠫ༐")+mmv7XkyreCIJGUqhTYi5KB6DWSn)
	if TrdwtBCoInxfebSWZl5XV34aDyH in [-EE1jeHnIoad(u"࠷ᄫ"),jL5CrsRwebpyDVXUc1EQP(u"࠰ᄬ")]: return
	elif TrdwtBCoInxfebSWZl5XV34aDyH==ggjO5CrKVRPITaesWkxD(u"࠲ᄭ"):
		import ZJYHCK5167
		ZJYHCK5167.TOgpyXDmL840cz2wYFA()
		return
	XUs2MSIe5PFtckKA9JaEZOlB1u6 = EsCplGc5N4mBuYW0RVQt6b
	while XUs2MSIe5PFtckKA9JaEZOlB1u6:
		XUs2MSIe5PFtckKA9JaEZOlB1u6 = LhFAGlQ19zr
		message = ssynAg0zhSkoCpOMDV9(u"ࠧฦาสࠤ฾์ฯไุ่่๊ࠢษࠡใํࠤฬ๊รฮำไࠤฬู๊าสํอࠥ็วั้หࠤส๊้ࠡࠤศ฽ิอฯศฬࠣ์ฬา็สࠢๆ์ิ๐ࠢࠡอ่ࠤ฿๐ัࠡษ็า฼ࠦลๅ๋ࠣࠦࡆࡸࡩࡢ࡮ࠥࠤ࠳࠴ࠠฦาสࠤ้๋ࠠหฮาࠤฬ๊ฮุࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠣๅ฿๐ัࠡษ็ะ้ีࠠฦๆ์ࠤศ๐ࠠอๆาࠤะอๆ๋ࠢไ๎์ࠦวๅะฺࠤࠧࡇࡲࡪࡣ࡯ࠦࠥ࠴࠮ࠡอ่ࠤอ฿ฯ่ษࠣ฾๏ืࠠศๆั฻ࠥหไ๊ࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠣࡠࡳࠦลัษ่ࠣํำษࠡษ็้ๆอส๋ฯࠣห้฿ัษ์ฬࠤ้อࠠหฺ๊ี๊ࠥใࠡ࠰࠱ࠤฬึ็ษࠢศ่๎ࠦࠢฦ฻าหิอส๊ࠡสะ์ฯࠠไ๊า๎ࠧࠦ࠮࠯ࠢฮ้ࠥเ๊าࠢศ฽ิอฯศฬࠣห้๋่ใ฻ࠣห้าฺาษไ๎ࠥࡢ࡮࡝ࡰ๋้ࠣࠦสา์าࠤฬ๊ย็ࠢไฮาࠦࠢฦ฻าหิอส๊ࠡสะ์ฯࠠไ๊า๎ࠧࠦฟࠢࠩ༑")
		TrdwtBCoInxfebSWZl5XV34aDyH = jPRJMOhT415yvioG8rN9m0Q3b(Hr25gta6XcqO(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ༒"),Gcw2nelTR864XCVruO3mAFqI5a(u"ࠩࡈࡼ࡮ࡺࠠฯำ๋ะࠬ༓"),sIzDXlTHYUC5L3xZGnr(u"ࠪ࡝ࡪࡹࠠ็฻่ࠫ༔"),QjAINyUC7MDRq5d8e4vl9(u"ࠫࡊࡴࡧ࡭࡫ࡶ࡬ࠥหๆอๆํึ๏࠭༕"),ggjO5CrKVRPITaesWkxD(u"ࠬ฿ฯๆࠢ฻๋ํืࠠศๆฦัึ็้ࠠษ็็ฯอศสࠢส่฾ืศ๋หࠪ༖"),message,profile=FgXzMs0YSDt(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟࡮ࡧࡧ࡭ࡺࡳࡦࡰࡰࡷࠫ༗"))
		if TrdwtBCoInxfebSWZl5XV34aDyH==o1INZ3ViQqS0Uw5z6kMjbv(u"࠴ᄮ"):
			message = wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧࡊࡨࠣࡽࡴࡻࠠࡩࡣࡹࡩࠥࡶࡲࡰࡤ࡯ࡩࡲࠦࡷࡪࡶ࡫ࠤࡆࡸࡡࡣ࡫ࡦࠤࡱ࡫ࡴࡵࡧࡵࡷࠥࡺࡨࡦࡰࠣࡳࡵ࡫࡮ࠡࠤࡎࡳࡩ࡯ࠠࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡗࡪࡺࡴࡪࡰࡪࡷࠧࠦࡡ࡯ࡦࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡧࡱࡱࡸࠥࡺ࡯ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢ࠱࠲ࠥࡏࡦࠡࡻࡲࡹࠥࡩࡡ࡯࡞ࠪࡸࠥ࡬ࡩ࡯ࡦࠣࠦࡆࡸࡩࡢ࡮ࠥࠤ࡫ࡵ࡮ࡵࠢࡷ࡬ࡪࡴࠠࡤࡪࡤࡲ࡬࡫ࠠࡵࡪࡨࠤࡸࡱࡩ࡯ࠢࡷࡳࠥࡧ࡮ࡺࠢࡲࡸ࡭࡫ࡲࠡࡵ࡮࡭ࡳࠦࡴࡩࡣࡷࠤ࡭ࡧࡶࡦࠢ࡟ࠦࡆࡸࡩࡢ࡮࡟ࠦࠥ࡬࡯࡯ࡶࠣ࠲࠳ࠦࡁ࡯ࡦࠣࡸ࡭࡫࡮ࠡࡥ࡫ࡥࡳ࡭ࡥࠡࡶ࡫ࡩࠥ࡬࡯࡯ࡶࠣࡸࡴࠦࠢࡂࡴ࡬ࡥࡱࠨࠠ࡝ࡰࠣࡍ࡫ࠦࡁࡳࡣࡥ࡭ࡨࠦࡋࡦࡻࡥࡳࡦࡸࡤࠡ࡫ࡶࠤࡳࡵࡴࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠤ࠳࠴ࠠࡕࡪࡨࡲࠥࡵࡰࡦࡰࠣࠦࡐࡵࡤࡪࠢࡌࡲࡹ࡫ࡲࡧࡣࡦࡩ࡙ࠥࡥࡵࡶ࡬ࡲ࡬ࡹࠢࠡࡣࡱࡨࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡵࡩ࡬࡯࡯࡯ࡣ࡯ࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸࠦ࡜࡯࡞ࡱࠤࡉࡵࠠࡺࡱࡸࠤࡼࡧ࡮ࡵࠢࡱࡳࡼࠦࡴࡰࠢࡲࡴࡪࡴࠠࡵࡪࡨࠤࠧࡑ࡯ࡥ࡫ࠣࡍࡳࡺࡥࡳࡨࡤࡧࡪࠦࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠣࠢࡂ༘ࠥࠬ")
			TrdwtBCoInxfebSWZl5XV34aDyH = jPRJMOhT415yvioG8rN9m0Q3b(uulNDCPyef78(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ༙"),sIzDXlTHYUC5L3xZGnr(u"ࠩࡈࡼ࡮ࡺࠠฯำ๋ะࠬ༚"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪ࡝ࡪࡹࠠ็฻่ࠫ༛"),CsDcLqQUVK4YBvHFW1(u"ࠫࡆࡸࡡࡣ࡫ࡦࠤ฾ืศ๋ࠩ༜"),CsDcLqQUVK4YBvHFW1(u"ࠬࡓࡩࡴࡵ࡬ࡲ࡬ࠦࡁࡳࡣࡥ࡭ࡨࠦࡆࡰࡰࡷࠤࠫࠦࡔࡦࡺࡷࠫ༝"),message,profile=KfHAW8VGbrxi(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟࡮ࡧࡧ࡭ࡺࡳࡦࡰࡰࡷࠫ༞"))
			if TrdwtBCoInxfebSWZl5XV34aDyH==O3OVuapf0YFjbm5oUQDg(u"࠵ᄯ"): XUs2MSIe5PFtckKA9JaEZOlB1u6 = EsCplGc5N4mBuYW0RVQt6b
		if TrdwtBCoInxfebSWZl5XV34aDyH==PlpyFa9QMKXxOD1cvHzmI(u"࠵ᄰ"): Z892VKqDTv1xsEfeoyAPG6nNWcgSm()
	return
def RDktuy08wOXv4lNoYqPHVWQ3zdsneL():
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,N6NGJ4vpmidqMCh7yo(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ༟"),I18uSKaWhgTBeYUPD4sr(u"ࠨ฼ส่ออࠠศๆึฬอࠦ็้่๊ࠢࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥอไๆ฼ำ๎๊ࠥไษำ้ห๊า้ࠠๆ็ฮศ้ฯࠡไ่ࠤอะิ฻์็ࠤฬ๊ัศสฺࠤฬ๊ะ๋ࠢ็หࠥ๐ูๆๆࠣฯ๊ࠦโๆࠢหษึูวๅุ่่๊ࠢษࠡว็ํࠥอไๆสิ้ัࠦๅ็ࠢส่็อฦๆหࠣห้ืฦ๋ีํอ๊ࠥไษำ้ห๊าࠧ༠"))
	return
def eENxRhKUkIWlV79qnJ5FTwpCOgGH():
	kf40tulvSA7z9RqNF5dXca3seMD = N6NGJ4vpmidqMCh7yo(u"๊ࠩิฬࠦวๅสิ๊ฬ๋ฬࠡ็ัฺูࠦแใู่้ࠣเษࠡษ็฽ึฮ๊ส๋่่ࠢ์่ࠠาสࠤ้อ๋ࠠ็้฽ࠥ๎ฬ้ั้ࠣํอโฺࠢไ๎์อࠠฤใ็ห๊่ࠦๆี็ื้อสࠡ็อีั๋ษࠡล๋ࠤ๊ีศๅฮฬࠤส๊้ࠡษ็่฿ฯࠠศๆ฼ีอ๐ษ๊ࠡส่๎ࠦไ฻ษอࠤฬิั๊๋่ࠢฬ๊้ࠦฮาࠤุฮศࠡๆ็ฮ่ืวาࠩ༡")
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭༢"),kf40tulvSA7z9RqNF5dXca3seMD)
	return
def qzv3jf2iUMoaPlOJuLgZFnQS5d():
	kf40tulvSA7z9RqNF5dXca3seMD = Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫฬ๊ั้ษห฻ࠥอไษูํสฮࠦไศࠢ฼่ฬ่ษࠡๆ๊หࠥฮวๅสิ๊ฬ๋ฬ๊ࠡ฽ห้ฮวࠡษ็ือฮ่๊้๋ࠠࠣࠦวๅ็๋ๆ฾ࠦวๅลุ่๏ࠦวๅ็฽ิ๏ࠦไๅสิ๊ฬ๋ฬࠨ༣")
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ༤"),kf40tulvSA7z9RqNF5dXca3seMD)
	return
def USdiZse9v1Gf547rY0n():
	kf40tulvSA7z9RqNF5dXca3seMD = CsDcLqQUVK4YBvHFW1(u"࠭็๋ࠢึ๎ึ็ัศฬ่ࠣฬ๊ࠦิฬฺ๎฾ࠦวๅสิ๊ฬ๋ฬࠡษึฮำีวๆ้สࠤอูศษࠢๆ์๋ํวࠡ็ะ้๏ฯࠠๆ่ࠣห้๋ีะำࠣวํࠦศฮษฯอࠥหไ๊ࠢสุฯืวไࠢิื๊๐ࠠฤ๊ࠣะิ๐ฯสࠢฦ์๊ࠥวࠡ์฼ีๆํวࠡษ็ฬึ์วๆฮࠪ༥")
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,FmYoGejTnwKME7d9zPc(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ༦"),N6NGJ4vpmidqMCh7yo(u"ࠨีํีๆืวหࠢึ๎หฯࠠฤ๊้ࠣัํ่ๅหࠪ༧"),kf40tulvSA7z9RqNF5dXca3seMD)
	return
def FncHZVQINC7lfdmitu2z1Ys0TOk6():
	kf40tulvSA7z9RqNF5dXca3seMD = I18uSKaWhgTBeYUPD4sr(u"ࠩสุ่๐ัโำสฮࠥอไฺษ่อࠥํ๊ࠡีํีๆืวหࠢัหึา๊ส๋ࠢ฾๏ืࠠหษห฽ฮࠦไๅ็๋ๆ฾ࠦวๅลุ่๏่ࠦอ็ํ฽ࠥอไๆ๊สๆ฾ࠦสิฬัำ๊ํว๊ࠡ฼หิฯࠠหๅ๋๊๋ࠥฬศ่ํอࠥ๎ๅีษๆ่์อࠠไอํีฮࠦไศ่ࠣห้็๊ะ์๋๋ฬะࠠโ์๊หࠥหๅศࠢห฻๏ฬษࠡล๋ࠤ๊๋ๆ้฻ฬࠤศ๎ࠠๆฯำ์ๆฯࠠฤ๊ࠣๅ๏ํวࠡ็ื็้ฯࠠฮไ๋ๆࠥอไๆๆๆ๎ฮࡢ࡮࡝ࡰ࡟ࡲฬ๊ำ๋ำไีฬะࠠศๆัหฺฯ่ࠠ์ࠣื๏ืแาษอࠤฯอศฺห่้๋่ࠣใ฻ࠣห้ษีๅ์ࠣ์ู๊สฯั่อࠥ็๊ࠡ็๋ห็฿ࠠใๆํ่ฮࠦฬะษࠣ์฾อฯสࠢอ็ํ์ࠠๆัไ์฾ฯࠠศๆฦะึࠦร้ࠢํ้้้็ศࠢส่๊๎โฺࠢส่ศ฻ไ๋๋่ࠢ์ึวࠡใ๊๎ࠥา๊ะหุ๊ࠣฮ๊ศ๋ࠢืึ๐ูสู๋้ࠢอใๅ้สࠤ็๊๊ๅหࠣะิอࠧ༨")
	cFjMEShi6Pp0otRBgeXq8(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪࡧࡪࡴࡴࡦࡴࠪ༩"),FgXzMs0YSDt(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ༪"),kf40tulvSA7z9RqNF5dXca3seMD,QjAINyUC7MDRq5d8e4vl9(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ༫"))
	return
def PA3sqNFcRj9i5bB0gDhOvQ8ItHLz():
	XgbcrBleMx5LYWzKjFCHIOP = aOQTKXFL54Nl60Zhp3MbE(u"࠭วษฬ฼ำࠥ฿ๆࠡ็็ๅฬะࠠศๆาๆฮࠦวๅ฻ส่๏ฯࠧ༬")
	mmv7XkyreCIJGUqhTYi5KB6DWSn = OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠧศสอ฽ิูࠦ็่่ࠢๆอสࠡล็ࠤࡲ࠹ࡵ࠹ࠩ༭")
	kQ90RuKEmXbqfP6as7pe4MIdvoG1cH = Hr25gta6XcqO(u"ࠨษหฮ฾ีฺ่้้ࠠࠣ็วหࠢส่ฯำๅ๋ๆࠣ์ฬ๊ฯศ๊้่ํีࠠࡥࡱࡺࡲࡱࡵࡡࡥࠩ༮")
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,SnhLjmfeJC(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ༯"),XgbcrBleMx5LYWzKjFCHIOP,mmv7XkyreCIJGUqhTYi5KB6DWSn,kQ90RuKEmXbqfP6as7pe4MIdvoG1cH)
	return
def zaSVrEi1HqZnjctTFuLsmQB7Y():
	mmv7XkyreCIJGUqhTYi5KB6DWSn = O3OVuapf0YFjbm5oUQDg(u"ࠪห้้วี๊ࠢ์๋ࠥฮำ่้ࠣษ่สࠡๆ็้฾๊่ๆษอࠤ๏ูสฯั่๋ࠥอไษำ้ห๊าࠠๅะี๊ࠥ฻แฮษอࠤฬ๊ล็ฬิ๊๏ะ้ࠠำ๋หอ฽ࠠศๆไ๎ิ๐่่ษอࠤ้๊่ึ๊็ࠤส๊๊่ษࠣฬุืูส๋ࠢฬิ๎ๆࠡว้ฮึ์๊ห๋ࠢห้ฮั็ษ่ะࠥ๐ๅิฯ๊หࠥะไใษษ๎ฬࠦศฺัࠣห๋ะ็ศรࠣ฽๊ื็ศ๋ࠢว๏฼วࠡ฻้ำࠥะอะ์ฮࠤฬ๊ศา่ส้ัࠦ࠮๊๊ࠡิฬࠦวๅสิ๊ฬ๋ฬࠡ์ึฮำีๅࠡีห฽ฮࠦร็๊ส฽ู๊ࠥๆำࠣห้้วีࠢ࠽ࠫ༰")
	mmv7XkyreCIJGUqhTYi5KB6DWSn += Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫࡡࡴ࡜࡯ࠩ༱") + oRJAfwD957WkUyBM1Ehu8m(u"ࠬ࠷࠮ࠡอสฬฯࠦไๅืไัฬะࠠศๆอ๎ู๋ࠥา๊ไࠤศ์็ศࠢ็หࠥะส฻์ิࠤ๋ํวว์สࠤํ๋ฯห้ࠣࠫ༲") + str(zz2tnLhI1QHV7GwFCrv5/FmYoGejTnwKME7d9zPc(u"࠻࠶ᄱ")/FmYoGejTnwKME7d9zPc(u"࠻࠶ᄱ")/CsDcLqQUVK4YBvHFW1(u"࠸࠴ᄲ")/ggjO5CrKVRPITaesWkxD(u"࠳࠱ᄳ")) + O3OVuapf0YFjbm5oUQDg(u"࠭ࠠี้ิࠫ༳")
	mmv7XkyreCIJGUqhTYi5KB6DWSn += C0qrknitpM4Z + vU6DxuzPwMpg(u"ࠧ࠳࠰ࠣะิอุ๊ࠠํ่ࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไๆใิ์฻ࠦร็้สࠤ้อࠠหฬ฽๎ึ่ࠦๆัอ๋ࠥ࠭༴") + str(JJtWv7V436NPCf/N6NGJ4vpmidqMCh7yo(u"࠷࠲ᄴ")/N6NGJ4vpmidqMCh7yo(u"࠷࠲ᄴ")/FgXzMs0YSDt(u"࠴࠷ᄵ")) + jL5CrsRwebpyDVXUc1EQP(u"ࠨࠢํ์๊༵࠭")
	mmv7XkyreCIJGUqhTYi5KB6DWSn += C0qrknitpM4Z + sJw9QWiq1Kr0xfeVRI(u"ࠩ࠶࠲ࠥ฽่๋ๆࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้ะ๊่ࠡสำึอࠠหฬ฽๎ึ่ࠦๆัอ๋ࠥ࠭༶") + str(rrux12tcwQl5/KfHAW8VGbrxi(u"࠹࠴ᄶ")/KfHAW8VGbrxi(u"࠹࠴ᄶ")/sIzDXlTHYUC5L3xZGnr(u"࠶࠹ᄷ")) + o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪࠤ๏๎ๅࠨ༷")
	mmv7XkyreCIJGUqhTYi5KB6DWSn += C0qrknitpM4Z + vU6DxuzPwMpg(u"ࠫ࠹࠴ࠠๆฬ๋ื฼ࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅฬํࠤ็ีࠠหฬ฽๎ึ่ࠦๆัอ๋ࠥ࠭༸") + str(CQOaFUrZJHwKRxIj4yXEYs5V/o1INZ3ViQqS0Uw5z6kMjbv(u"࠻࠶ᄸ")/o1INZ3ViQqS0Uw5z6kMjbv(u"࠻࠶ᄸ")) + V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠬࠦำศ฻ฬ༹ࠫ")
	mmv7XkyreCIJGUqhTYi5KB6DWSn += C0qrknitpM4Z + LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠭࠵࠯ࠢๅู๏ืࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎ࠥะส฻์ิࠤิอฦๆษࠣ์๊ีส่ࠢࠪ༺") + str(d9vcuo3Hy7RhAk2/jL5CrsRwebpyDVXUc1EQP(u"࠼࠰ᄹ")/jL5CrsRwebpyDVXUc1EQP(u"࠼࠰ᄹ")) + AAbvaXV2DQzfNHdm4U3tT(u"ࠧࠡีส฽ฮ࠭༻")
	mmv7XkyreCIJGUqhTYi5KB6DWSn += C0qrknitpM4Z + sIzDXlTHYUC5L3xZGnr(u"ࠨ࠸࠱ࠤัีวࠡไุ๎ึࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅฬํࠤฯะฺ๋ำࠣ็ะ๐ัศ๋้ࠢิะ็ࠡࠩ༼") + str(D1KfvmcCjGYbgSoyX/uulNDCPyef78(u"࠶࠱ᄺ")) + Hr25gta6XcqO(u"ࠩࠣำ็๐โสࠩ༽")
	mmv7XkyreCIJGUqhTYi5KB6DWSn += C0qrknitpM4Z + o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪ࠻࠳ࠦศะ๊้ࠤ่อิࠡๆ็ูๆำวหࠢส่ฯ๐ࠠหฬ฽๎ึࠦศิำ฼อࠥ๎ๅะฬ๊ࠤࠬ༾") + str(oWMrx7zvedHY0UiS48XbOqVTJ) + OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠫࠥีโ๋ไฬࠫ༿")
	mmv7XkyreCIJGUqhTYi5KB6DWSn += EE1jeHnIoad(u"ࠬࡢ࡮࡝ࡰࠪཀ") + wdftVMyzF17cYETHu(u"࠭ๅฬๆส࠾ࠥ฻แฮษอࠤ็๎วว็ࠣห้ษแๅษ่ࠤํอไๆี็ื้อส๊ࠡส่า๊โศฬࠣ฽๊ื็ศࠢࠪཁ") + str(CQOaFUrZJHwKRxIj4yXEYs5V/EE1jeHnIoad(u"࠷࠲ᄻ")/EE1jeHnIoad(u"࠷࠲ᄻ")) + sJw9QWiq1Kr0xfeVRI(u"ࠧࠡีส฽ฮࠦ࠮ࠡล่ห่่ࠥศศ่ࠤศ์่ศ฻ࠣห้็๊ะ์๋๋ฬะࠠโ฻่ี์อࠠࠨག") + str(rrux12tcwQl5/EE1jeHnIoad(u"࠷࠲ᄻ")/EE1jeHnIoad(u"࠷࠲ᄻ")/N6NGJ4vpmidqMCh7yo(u"࠴࠷ᄼ")) + Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠨࠢฦ๎ฬ๋ࠠ࠯ࠢฦ้ฬࠦๅๅใสฮࠥอไโ์า๎ํࠦแฺ็ิ๋ฬࠦࠧགྷ") + str(d9vcuo3Hy7RhAk2/EE1jeHnIoad(u"࠷࠲ᄻ")/EE1jeHnIoad(u"࠷࠲ᄻ")) + FgXzMs0YSDt(u"ࠩࠣืฬ฿ษࠡใๅ฻ࠥ࠴ࠠฤ็สࠤๆำีࠡำๅ้ࠥอไฦืาหึࠦแฺ็ิ๋ࠥ࠭ང") + str(D1KfvmcCjGYbgSoyX/EE1jeHnIoad(u"࠷࠲ᄻ")) + Hr25gta6XcqO(u"ࠪࠤิ่๊ใหࠣ࠲ࠥษๅศࠢไัฺࠦวีฬิห่ࠦเࡊࡒࡗ࡚ࠥ็ูๆำ๊ࠤࠬཅ") + str(oWMrx7zvedHY0UiS48XbOqVTJ) + C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠫࠥีโ๋ไฬࠫཆ")
	cFjMEShi6Pp0otRBgeXq8(sJw9QWiq1Kr0xfeVRI(u"ࠬࡸࡩࡨࡪࡷࠫཇ"),PlpyFa9QMKXxOD1cvHzmI(u"࠭ๅศ๊ࠢ์ࠥอไไษืࠤฬ๊ๅิฬัำ๊ࠦแ๋ࠢส่อืๆศ็ฯࠫ཈"),mmv7XkyreCIJGUqhTYi5KB6DWSn,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪཉ"))
	return
def RSV9jNkxM140qUmTl():
	kf40tulvSA7z9RqNF5dXca3seMD = o1INZ3ViQqS0Uw5z6kMjbv(u"ࠨษ็ๅฬ฻ไสࠢอ฽๋๐ࠠๆฮ็ำࠥฮๆโีࠣหุ๋็ࠡษ็วฺ๊๊๊ࠡส่๋่ืสࠢอ฽๋๐ࠠฤ่ࠣห้อำๆࠢส่ศ฻ไ๋ࠢอ้ࠥะูะ์็๋ࠥ๎แศื็อࠥ๎ๆใูฬࠤฯ฿ๆ๊่ࠢะ้ี้ࠠฬ่ࠤฯ฿ฯ๋ๆࠣหุ๋็๊ࠡหำํ์ฺࠠๆส้ฮࠦสฺ่ํࠤ๊๊แࠡส้ๅุࠦวิ็๊ࠤฬ๊รึๆํࠫཊ")
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,vU6DxuzPwMpg(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬཋ"),kf40tulvSA7z9RqNF5dXca3seMD)
	return
def b9hIe8BPDFxtm57QS1jGkr2lCH():
	kf40tulvSA7z9RqNF5dXca3seMD = C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠪษีอ้ࠠษฯ๋ฯ้ࠠๆึๆ่ฮࠦแ๋ࠢสู่ฮใส๋ࠢฮ๊ࠦอๅ้สࠤ࠳࠴࠮ࠡล๋ࠤฬ์ใࠡฬ฻๊ࠥษๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡๅส๊ࠥ็ุ๊่่่๊ࠢษࠡ็วๆฯํ้ࠠฬ่ࠤา๊็ศࠢ࠱࠲࠳ࠦแฦา้ࠤัืศࠡ็ึั้ࠥวีࠢส่อืๆศ็ฯࠤ้้๊ࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡสฺ่อࠦวๅืไัฮࠦวๅืะ๎าฯ้ࠠฬัึ๏์็ศࠢหำ้อࠠๆ่ࠣห้฻แฮหࠣห้่ฯ๋็ฬࠫཌ")
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,wdftVMyzF17cYETHu(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧཌྷ"),kf40tulvSA7z9RqNF5dXca3seMD)
	return
def V0VFZmTWXpLejkS32ItN9lHQ7():
	kf40tulvSA7z9RqNF5dXca3seMD = LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠬอไ฻ำูࠤ๊์ࠠี้สำฮࠦวๅฬืๅ๏ืฺ่๊๊ࠠࠣอๆࠡืะอࠥ๎ำา์ฬࠤฬ๊ๅฺๆ๋้ฬะࠠศๆ่ฮออฯๅหࠣฬ๏์ࠠศๆหี๋อๅอ๋ࠢห้๋่ใ฻ࠣห้๋ิโำࠣ์์ึวࠡษ็ฺ๊อๆࠡ฼ํี๋ࠥืๅ๊หࠤํ๊วࠡฯสะฮࠦไ่ࠢ฼๊ิࠦวๅษอูฬ๊ࠠศ๊ࠣห้ืศุ่ࠢ฽๋่ࠥศไ฼ࠤฬ๊แ๋ัํ์์อสࠡษ็ู้็ัสࠩཎ")
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,FgXzMs0YSDt(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩཏ"),kf40tulvSA7z9RqNF5dXca3seMD)
	return
def w8URi7qeoOtcKZ():
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,sJw9QWiq1Kr0xfeVRI(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪཐ"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠨๆๆ๎ࠥ๐ูๆๆ๋ࠣีอࠠศๆ้์฾ࠦๅ็ࠢส่ๆ๐ฯ๋๊๊หฯࠦ࡜࡯ࠢํะอࠦสโ฻ํ่ࠥหึศใฬࠤฬูๅ่ษࠣࡠࡳࠦࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭ད"))
	wwntyGQz2YbhoXNfMFm(CsDcLqQUVK4YBvHFW1(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩདྷ"),EsCplGc5N4mBuYW0RVQt6b)
	return
def NknIxsS2Bq():
	kf40tulvSA7z9RqNF5dXca3seMD  = wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"้ࠪษิัศࠢๅห๊ะࠠษ฻ูࠤูืใศฬࠣห้หๆหำ้ฮࠥอไะ๊็๎ࠥฮ่ื฻ࠣ฽ฬฬโุࠡาࠤฬ๊ศาษ่ะ๋ࠥหๅࠢๆ์ิ๐ࠠๅฬึ้าࠦแใู่ࠣอ฿ึࠡ็ึฮำีๅ๋ࠢส่๊ะีโฯࠣฬฬ๊ฯฯ๊็ࠤ้๋่ศไ฼ࠤฬ๊แ๋ัํ์ࠬན")
	kf40tulvSA7z9RqNF5dXca3seMD += N6NGJ4vpmidqMCh7yo(u"ࠫࠥ๎ๆห์ฯอ๊ࠥ็ัษࠣห้฿ววไࠣๅฬ์็ࠡฬๅี๏ฮวࠡฮ่๎฾ࠦๅิฬัำ๊๐ࠠษำ้ห๊าࠠไ๊า๎๊ࠥวࠡ์ึฮ฼๐ู้่ࠣห้ีฮ้ๆ่ࠣัฺ๋๊่ࠢ์ฬู่ࠡษ็ฬึ์วๆฮࠣัฯ๏ࠠๆ฻ࠣหุะฮะษ่ࠫཔ")
	kf40tulvSA7z9RqNF5dXca3seMD += C0qrknitpM4Z+n0nFOd4yR97fQzNLSW+wdftVMyzF17cYETHu(u"ࠬๆࠠࠡࡘࡓࡒࠥࠦร้ࠢࠣࡔࡷࡵࡸࡺࠢࠣวํࠦࠠࡅࡐࡖࠤࠥษ่ࠡลํࠤา๊ࠠษีํ฻ࠥศฮาࠩཕ")+T7ASIp1ZYwio9HQ8cObJK+C0qrknitpM4Z
	kf40tulvSA7z9RqNF5dXca3seMD += o1INZ3ViQqS0Uw5z6kMjbv(u"࠭࡜࡯ๆส๊ࠥํะศࠢ็๊ࠥ๐อๅࠢสฺ่๊ใๅหࠣ์ส์ๅศࠢไๆ฼ࠦำ๋ไ๋้ࠥฮลึๆสัࠥฮูืࠢส่๊๎วใ฻ࠣ์ส฿วให้ࠣํอโฺࠢสาึ๏ࠠไษ้ฮࠥะูๆๆࠣืฬฮโศࠢหำํ์ࠠๆึส็้࠭བ")
	cFjMEShi6Pp0otRBgeXq8(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭བྷ"),Hr25gta6XcqO(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫམ"),kf40tulvSA7z9RqNF5dXca3seMD,uulNDCPyef78(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬཙ"))
	kf40tulvSA7z9RqNF5dXca3seMD = FmYoGejTnwKME7d9zPc(u"ࠪห้๋่ศไ฼ࠤฬ๊ส๋ࠢอวะืสࠡสส่฾อฦใࠢ฼๊ิࠦศฺุࠣห้์วิ๊ࠢ๎࠿࠭ཚ")
	kf40tulvSA7z9RqNF5dXca3seMD += C0qrknitpM4Z+n0nFOd4yR97fQzNLSW+OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠫࡦࡱ࡯ࡢ࡯ࠣࠤࡪ࡭ࡹࡣࡧࡶࡸࠥࠦࡥࡨࡻࡥࡩࡸࡺࡶࡪࡲࠣࠤࡲࡵࡶࡪࡼ࡯ࡥࡳࡪࠠࠡࡵࡨࡶ࡮࡫ࡳ࠵ࡹࡤࡸࡨ࡮ࠠࠡࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪཛ")+T7ASIp1ZYwio9HQ8cObJK
	kf40tulvSA7z9RqNF5dXca3seMD += sIzDXlTHYUC5L3xZGnr(u"ࠬࡢ࡮࡝ࡰࠪཛྷ")+OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠭วๅั๋่ࠥอไห์ࠣฮศััหࠢหห้฿ววไࠣ฽๋ีࠠษ฻ูࠤฬ๊ๆศี๋ࠣ๏ࡀࠧཝ")
	kf40tulvSA7z9RqNF5dXca3seMD += C0qrknitpM4Z+n0nFOd4yR97fQzNLSW+FmYoGejTnwKME7d9zPc(u"ࠧๆืิࠤࠥอไไ๊ํฮࠥࠦรๆ์ิ็ฬࠦࠠไ่าหࠥࠦแา่ึหࠥࠦวๅ์๋๊ฬ์ࠠࠡสิ๎฼อๆ๋ษࠣห้หๅศำสฮࠥษไๆษ้๎ฬࠦั้ีํหࠥอไ๋ษหห๋ࠦวๅี฼์ิ๐ษࠡำ๋้ฬ์๊ศ๊ࠢ์้์ฯศࠩཞ")+T7ASIp1ZYwio9HQ8cObJK
	kf40tulvSA7z9RqNF5dXca3seMD += jL5CrsRwebpyDVXUc1EQP(u"ࠨ࡞ࡱࡠࡳ࠭ཟ")+ssynAg0zhSkoCpOMDV9(u"ࠩส่๊ฮัๆฮࠣ์ัีุࠠำํๆฮࠦไหฮส์ืࠦวๅ฻สส็่ࠦๅๅ้๋ฬࠦสฮฬสะࠥา็ะࠢๆฬ๏ื้ࠠษ็้อืๅอࠢํ฼๋ࠦวๅ็ื็้ฯࠠึ฼ํีฮ่ࠦๅษࠣฮุะอใࠢส่ฯ฿ศࠡใศิฬࠦไะ์ๆࠤฺ๊ใๅหࠣฬฬ๊ฯฯ๊็ࠤ้ฮูืࠢส่๊๎วใ฻ࠣ์ศ๐ึศࠢ็็๏๊ࠦหุะࠤาาๅࠡษ็ู้้ไสࠢࠪའ")
	kf40tulvSA7z9RqNF5dXca3seMD += n0nFOd4yR97fQzNLSW+CsDcLqQUVK4YBvHFW1(u"ࠪหึูไࠡำึห้ฯࠠๆฦาฬฮࠦลๅ๋ࠣห้๋ศา็ฯࠤํอใหสࠣๅ๏ํวࠡษึ้ࠥฮไะๅࠣ์ศูๅศรࠣห้๋่ศไ฼ࠤฬ๊ส๋ࠢ็หࠥะำหูํ฽ࠥีฮ้ๆ๊หࠬཡ")+T7ASIp1ZYwio9HQ8cObJK
	cFjMEShi6Pp0otRBgeXq8(QjAINyUC7MDRq5d8e4vl9(u"ࠫࡷ࡯ࡧࡩࡶࠪར"),ssynAg0zhSkoCpOMDV9(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨལ"),kf40tulvSA7z9RqNF5dXca3seMD,s5WMHyQN4mpie(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩཤ"))
	return
def Lvp8CxloQbANerGO():
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ggjO5CrKVRPITaesWkxD(u"ࠧฬๆสฯࠥ฽ัใࠢ็่ฯ๎วึๆ้ࠣ฾ࠦวๅ็หี๊าࠧཥ"),s5WMHyQN4mpie(u"ࠨลิื้ࠦัิษ็อࠥษ่ࠡ็ื็้ฯࠠๆ่ࠣๆฬฬๅสࠢัำ๊อส้ࠡำหࠥอไษำ้ห๊า࡜࡯࡞ࡱวํࠦศศีอาิอๅࠡษ็ๅ๏ูศ้ๅࠣวิ์ว่࡞ࡱࠫས")+n0nFOd4yR97fQzNLSW+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡩࡥࡨ࡫ࡢࡰࡱ࡮࠲ࡨࡵ࡭࠰ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠲࠱࠳࠻ࠫཧ")+T7ASIp1ZYwio9HQ8cObJK+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪࡠࡳࡢ࡮ฤ๊ࠣฬฬืำศๆࠣห๏๋๊ๅࠢส่๎ࠦระ่ส๋ࠥࠦ࡜࡯ࠢࠪཨ")+n0nFOd4yR97fQzNLSW+O3OVuapf0YFjbm5oUQDg(u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠵࠴࠶࠾ࡀࡨ࡯ࡤ࡭ࡱ࠴ࡣࡰ࡯ࠪཀྵ")+T7ASIp1ZYwio9HQ8cObJK)
	return
def yGOXB2HjmUA1Pqgt9QIJsYNZbFp60k(showDialogs=EsCplGc5N4mBuYW0RVQt6b):
	if not showDialogs: showDialogs = EsCplGc5N4mBuYW0RVQt6b
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,FgXzMs0YSDt(u"ࠬࡍࡅࡕࠩཪ"),Hr25gta6XcqO(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡺࡤࡱࡵࡲࡥ࠯ࡥࡲࡱࠬཫ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LhFAGlQ19zr,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Gcw2nelTR864XCVruO3mAFqI5a(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡋࡘ࡙ࡖࡓࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪཬ"))
	if not E6ECvznP9m5sWFMu.succeeded:
		y27Hqwlg3V = LhFAGlQ19zr
		DDVFlXjdHQsc5nfigO1wPReZSU46 = bNHEp28wg51k(LhFAGlQ19zr)
		Clc8sIj97ZrThF(P3PazFblmtN,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+CsDcLqQUVK4YBvHFW1(u"ࠨࠢࠣࠤࡍ࡚ࡔࡑࡕࠣࡊࡦ࡯࡬ࡦࡦࠣࠤࠥࡒࡡࡣࡧ࡯࠾ࡠ࠭཭")+DDVFlXjdHQsc5nfigO1wPReZSU46+vU6DxuzPwMpg(u"ࠩࡠࠫ཮"))
		if showDialogs: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,uulNDCPyef78(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭཯"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠫๆำีࠡษ็หฯ฻วๅࠢสฺ่๊แาࠢ࠱࠲࠳ࠦๅีๅ็อࠥ࠴࠮࠯ࠢส่ฬะีศๆࠣห้๋ิโำࠣࠬฬ๊ัษูࠣห้๋ิโำࠬࠤ้อ๋ࠠ฻่่ࠥ฿ๆะๅࠣ฽้๏ࠠไ๊า๎ࠥ࠴࠮࠯๋ࠢ฽๋ีใࠡๅ๋ำ๏ฺ๋ࠦำࠣๆฬีัࠡ฻็ํࠥอำหะาห๊ࠦวๅ็๋ห็฿ࠠศๆุ่ๆืษࠨ཰"))
	else:
		y27Hqwlg3V = EsCplGc5N4mBuYW0RVQt6b
		if showDialogs: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,sIzDXlTHYUC5L3xZGnr(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨཱ"),O3OVuapf0YFjbm5oUQDg(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰࠱ࠤฬ๊วหืส่ࠥอไๆึไีࠥ࠮วๅำห฻ࠥอไๆึไี࠮ฺ๊ࠦ็็ࠤ฾์ฯไ๋ࠢห้ฮั็ษ่ะ่ࠥวะำࠣ฽้๏ࠠศีอาิอๅࠡษ็้ํอโฺࠢสฺ่๊แาหིࠪ"))
	if not y27Hqwlg3V and showDialogs: ukWnmcTxLeJwNKz1B2GQZC()
	return y27Hqwlg3V
def ukWnmcTxLeJwNKz1B2GQZC():
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,FmYoGejTnwKME7d9zPc(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮཱིࠪ"),FgXzMs0YSDt(u"ࠨส฼ฺࠥอไๆ๊สๆ฾ࠦสฮฬสะࠥืศุุ่ࠢๆื้ࠠไาࠤ๏้่็ࠢฯ๋ฬุใࠡ฼ํี่ࠥวะำࠣ฽้๏ࠠศๆิฬ฼ࠦวๅ็ืๅึࠦร้๊๊ࠢฬ้ࠠๆึๆ่ฮࠦแ๋ࠢื๋ฬีษࠡษ็ฮู็๊าࠢส่ำอีสࠢห็ํี๊ࠡ฻้ำู่ࠦๅ็สࠤฬ์็ࠡฬ่ࠤๆำีࠡษ็ฬึ์วๆฮࠣ฽้๏ࠠไ๊า๎ࠥอไฦืาหึอสࠡ࡞ࡱࠤ࠶࠽࠮࠷ࠢࠣࠪࠥࠦ࠱࠹࠰࡞࠴࠲࠿࡝ࠡࠢࠩࠤࠥ࠷࠹࠯࡝࠳࠱࠸ࡣུࠧ"))
	kkx4hCedgWn2lI15bTzHaD()
	return
def YYuBnksbtX4WTE7ipPQmNgaZvy9U(YMaiHbnIThsP7q=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	ogwSxkDfqmctLUiVEC7 = EsCplGc5N4mBuYW0RVQt6b
	if LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣཱུࠬ") not in YMaiHbnIThsP7q:
		ogwSxkDfqmctLUiVEC7 = LhFAGlQ19zr
		YYxDRTA76kwZNBqnHSdJ = jPRJMOhT415yvioG8rN9m0Q3b(PlpyFa9QMKXxOD1cvHzmI(u"ࠪࡧࡪࡴࡴࡦࡴࠪྲྀ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠫำื่อࠩཷ"),O3OVuapf0YFjbm5oUQDg(u"ࠬหัิษ็ࠤฺ๊ใๅหࠪླྀ"),wdftVMyzF17cYETHu(u"࠭ลาีส่ࠥืำศๆฬࠫཹ"),wdftVMyzF17cYETHu(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮེࠪ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠨ้็ࠤฯื๊ะࠢฦ๊ࠥะัิๆࠣีุอไสࠢศ่๎ࠦวๅ็หี๊าࠠ࠯࠰ࠣว๊ࠦสา์าࠤศ์ࠠหำึ่๋ࠥิไๆฬࠤ๊๎ฬ้ัฬࠤๆ๐ࠠศๆหี๋อๅอࠢยཻࠫ"))
		if YYxDRTA76kwZNBqnHSdJ in [-OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠴ᄽ"),ggjO5CrKVRPITaesWkxD(u"࠴ᄾ")]: return
		elif YYxDRTA76kwZNBqnHSdJ==Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠶ᄿ"):
			ogwSxkDfqmctLUiVEC7 = EsCplGc5N4mBuYW0RVQt6b
			YMaiHbnIThsP7q = PlpyFa9QMKXxOD1cvHzmI(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣོࠬ")
	if ogwSxkDfqmctLUiVEC7:
		if EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤࡕࡌࡅࡡཽࠪ") not in YMaiHbnIThsP7q:
			Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(PlpyFa9QMKXxOD1cvHzmI(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫཾ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠬ๎ึฺࠢสฺ่๊ใๅหࠣๅ๏ࠦวๅีฯ่ࠬཿ"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭โษๆࠣษึูวๅࠢสุ่าไࠡ฻็๎่ࠦร็ࠢอ็ึื่ࠠࠡไืࠥอไโ฻็ࠤฬ๊ะ๋ࠢฦ฽฼อใࠡษ็ู้้ไสࠢ࠱ࠤ้้๊ࠡ์อ้ࠥะำอ์็ࠤ์ึ็ࠡษ็ู้้ไสࠢไ๎ูࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠ࠯๋ࠢฬิ๎ๆ้ࠡำหࠥอไหีฯ๎้ࠦำ้ใࠣฮึูไࠡ็็ๅ๊ࠥวࠡใสสิฯࠠๆ่๊ࠤ้หๆ่ࠢ็หࠥ๐อห๊ํࠤ฾๊้ࠡษ็ู้้ไสࠢส่ฯ๐ࠠหำํำࠥอๆหࠢส่สฮไศ฼ࠣ฽๋ํวࠡ࠰๋้ࠣࠦโๆฬࠣฬฯ้ัศำࠣห้๋ิไๆฬࠤฤྀ࠭"))
			if Scj7zgGFVA83otMpwUkxhm0BLN1!=oRJAfwD957WkUyBM1Ehu8m(u"࠷ᅀ"):
				GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,N6NGJ4vpmidqMCh7yo(u"ࠧห็ࠣษ้เวยࠢส่สืำศๆཱྀࠪ"),jL5CrsRwebpyDVXUc1EQP(u"ࠨๆ็วุ็ࠠษั๋๊ࠥะำอ์็ࠤฬ๊ๅีๅ็อࠥ็๊ࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣๅฬ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏ูสุ์฼ࠤ๊฿ัโหࠣห้๋ิไๆฬࠤํ๊วࠡฯ็๋ฬࠦไศ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠫྂ"))
				return
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ggjO5CrKVRPITaesWkxD(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬྃ"),FgXzMs0YSDt(u"ࠪๅ๏ࠦวๅึสุฮࠦวๅไสำ๊ฯࠠฮษ๋่ࠥษๆࠡฬๆฮอࠦัิษ็อࠥหไ๊ࠢส่๊ฮัๆฮࠣ์ฬฺัฮࠢไ๎์อࠠศๆุ่่๊ษࠡล๋ࠤฬ๊ๅุ้๋฽ࠥ๎ลัษࠣวึีสࠡฮ๋หอࠦๅ็ࠢส่๊ฮัๆฮࠣๅสึๆࠡลๆฮอูࠦ็๊ส๊ࠥฮั๋ัๆࠤศ๊ลๅๅอีํ์๊ࠡษ็ษ๏๋๊ๅ๋ࠢฮี้ั๊ࠡ็หࠥะๆิ๋ࠣว๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮ྄ࠧ"))
	search = GFYl1tsoOkHC0Ajeur8JQiMx(header=uulNDCPyef78(u"ࠫ࡜ࡸࡩࡵࡧࠣࡥࠥࡳࡥࡴࡵࡤ࡫ࡪ࡫ࠠࠡࠢส็ฯฮࠠาีส่ฮ࠭྅"),source=BfWYUAnyg6eONLjiuE)
	if not search: return
	kf40tulvSA7z9RqNF5dXca3seMD = search
	if ogwSxkDfqmctLUiVEC7: type = CsDcLqQUVK4YBvHFW1(u"ࠬࡖࡲࡰࡤ࡯ࡩࡲ࠭྆")
	else: type = EE1jeHnIoad(u"࠭ࡍࡦࡵࡶࡥ࡬࡫ࠧ྇")
	ddecO3Tb9U5k = PkNFw8KBOny2fb9D(type,kf40tulvSA7z9RqNF5dXca3seMD,EsCplGc5N4mBuYW0RVQt6b,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QjAINyUC7MDRq5d8e4vl9(u"ࠧࡆࡏࡄࡍࡑ࠳ࡆࡓࡑࡐ࠱࡚࡙ࡅࡓࡕࠪྈ"),YMaiHbnIThsP7q)
	return
def dsxEzRUOf3():
	YMaiHbnIThsP7q = ggjO5CrKVRPITaesWkxD(u"ࠨ้ำหࠥอไษำ้ห๊าࠠๅษࠣ๎ําฯࠡๆ๊ࠤศ๐ࠠิ์ิๅึ๊ࠦิฬู๎ๆࠦร๋่ࠢัฯ๎๊ศฬ࠱ࠤฬ๊ศา่ส้ั๊ࠦิฬัำ๊ࠦั้ษห฻ࠥ๎สื็ํ๊๊ࠥๅฮฬ๋๎ฬะࠠๆำไ์฾ฯฺࠠๆ์ࠤุ๐ัโำสฮࠥิวาฮํอ࠳ࠦวๅสิ๊ฬ๋ฬࠡ฼ํี๋ࠥำล๊็ࠤ฾์ࠠฤ์้ࠣาะ่๋ษอࠤฯ๋ࠠหฯ่๎้ํวࠡ฻็ํู๊ࠥาใิหฯ่ࠦๆ๊สๆ฾ࠦฮศำฯ๎ฮࠦࠢๆ๊สๆ฾ࠦืาใࠣฯฬ๊หࠣ࠰ࠣะ๊๐ูࠡษ็วุ๋วย๋ࠢห้๋วาๅสฮࠥ๎วๅื๋ีࠥ๎วๅ็ุ้ํืวห๊ࠢ๎ࠥิวึหࠣฬฬ฻อศส๊ห࠳ࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏์ส่ๅࠣั็๎โࠡษ็฻อ฿้ࠠษ็ู๊ื้ࠠไส๊ํ์ࠠศๆฦ่ๆ๐ษࠡๆ็้้้๊สࠢส่ึ่ๅ๋หࠣࡈࡒࡉࡁࠡวำห้ࠥว็ࠢ็ำ๏้ࠠีๅ๋ํࠥิวึหࠣฬฬ๊ั้ษห฻ࠥ๎วๅฬูห๊๐ๆࠡษ็าฬืฬ๋หࠣๅฬ๊ัอษฤࠤฬ๊ส้ษุู่๋ࠥࠡวาหึฯ่ࠠา๊ࠤฬ๊ำ๋ำไีฬะ้ࠠษ็้ํอโฺࠢส่ำอัอ์ฬ࠲ࠥํะศࠢส่อืๆศ็ฯࠤ์๎ࠠษสึห฼ฯࠠๆฬุๅาࠦไๆ๊สๆ฾ࠦวๅ๊ํฬࠬྉ")
	cFjMEShi6Pp0otRBgeXq8(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩࡵ࡭࡬࡮ࡴࠨྊ"),N6NGJ4vpmidqMCh7yo(u"ࠪั็๎โࠡษ็฻อ฿้ࠠษ็ู๊ื้ࠠไส๊ํ์ࠠศๆฦ่ๆ๐ษࠡๆ็้้้๊สࠢส่ึ่ๅ๋หࠪྋ"),YMaiHbnIThsP7q,N6NGJ4vpmidqMCh7yo(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧྌ"))
	YMaiHbnIThsP7q = FmYoGejTnwKME7d9zPc(u"࡚ࠬࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤࡩࡵࡥࡴࠢࡱࡳࡹࠦࡨࡰࡵࡷࠤࡦࡴࡹࠡࡥࡲࡲࡹ࡫࡮ࡵࠢࡲࡲࠥࡧ࡮ࡺࠢࡶࡩࡷࡼࡥࡳ࠰ࠣࡍࡹࠦ࡯࡯࡮ࡼࠤࡺࡹࡥࡴࠢ࡯࡭ࡳࡱࡳࠡࡶࡲࠤࡪࡳࡢࡦࡦࡧࡩࡩࠦࡣࡰࡰࡷࡩࡳࡺࠠࡵࡪࡤࡸࠥࡽࡡࡴࠢࡸࡴࡱࡵࡡࡥࡧࡧࠤࡹࡵࠠࡱࡱࡳࡹࡱࡧࡲࠡࡱࡱࡰ࡮ࡴࡥࠡࡸ࡬ࡨࡪࡵࠠࡩࡱࡶࡸ࡮ࡴࡧࠡࡵ࡬ࡸࡪࡹ࠮ࠡࡃ࡯ࡰࠥࡺࡲࡢࡦࡨࡱࡦࡸ࡫ࡴ࠮ࠣࡺ࡮ࡪࡥࡰࡵ࠯ࠤࡹࡸࡡࡥࡧࠣࡲࡦࡳࡥࡴ࠮ࠣࡷࡪࡸࡶࡪࡥࡨࠤࡲࡧࡲ࡬ࡵ࠯ࠤࡨࡵࡰࡺࡴ࡬࡫࡭ࡺࡥࡥࠢࡺࡳࡷࡱࠬࠡ࡮ࡲ࡫ࡴࡹࠠࡳࡧࡩࡩࡷ࡫࡮ࡤࡧࡧࠤ࡭࡫ࡲࡦ࡫ࡱࠤࡧ࡫࡬ࡰࡰࡪࠤࡹࡵࠠࡵࡪࡨ࡭ࡷࠦࡲࡦࡵࡳࡩࡨࡺࡩࡷࡧࠣࡳࡼࡴࡥࡳࡵࠣ࠳ࠥࡩ࡯࡮ࡲࡤࡲ࡮࡫ࡳ࠯ࠢࡗ࡬ࡪࠦࡰࡳࡱࡪࡶࡦࡳࠠࡪࡵࠣࡲࡴࡺࠠࡳࡧࡶࡴࡴࡴࡳࡪࡤ࡯ࡩࠥ࡬࡯ࡳࠢࡺ࡬ࡦࡺࠠࡰࡶ࡫ࡩࡷࠦࡰࡦࡱࡳࡰࡪࠦࡵࡱ࡮ࡲࡥࡩࠦࡴࡰࠢ࠶ࡶࡩࠦࡰࡢࡴࡷࡽࠥࡹࡩࡵࡧࡶ࠲ࠥ࡝ࡥࠡࡷࡵ࡫ࡪࠦࡡ࡭࡮ࠣࡧࡴࡶࡹࡳ࡫ࡪ࡬ࡹࠦ࡯ࡸࡰࡨࡶࡸ࠲ࠠࡵࡱࠣࡶࡪࡩ࡯ࡨࡰ࡬ࡾࡪࠦࡴࡩࡣࡷࠤࡹ࡮ࡥࠡ࡮࡬ࡲࡰࡹࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡦࠣࡻ࡮ࡺࡨࡪࡰࠣࡸ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢࡤࡶࡪࠦ࡬ࡰࡥࡤࡸࡪࡪࠠࡴࡱࡰࡩࡼ࡮ࡥࡳࡧࠣࡩࡱࡹࡥࠡࡱࡱࠤࡹ࡮ࡥࠡࡹࡨࡦࠥࡵࡲࠡࡸ࡬ࡨࡪࡵࠠࡦ࡯ࡥࡩࡩࡪࡥࡥࠢࡤࡶࡪࠦࡦࡳࡱࡰࠤࡴࡺࡨࡦࡴࠣࡺࡦࡸࡩࡰࡷࡶࠤࡸ࡯ࡴࡦࡵ࠱ࠤࡎ࡬ࠠࡺࡱࡸࠤ࡭ࡧࡶࡦࠢࡤࡲࡾࠦ࡬ࡦࡩࡤࡰࠥ࡯ࡳࡴࡷࡨࡷࠥࡶ࡬ࡦࡣࡶࡩࠥࡩ࡯࡯ࡶࡤࡧࡹࠦࡡࡱࡲࡵࡳࡵࡸࡩࡢࡶࡨࠤࡲ࡫ࡤࡪࡣࠣࡪ࡮ࡲࡥࠡࡱࡺࡲࡪࡸࡳࠡ࠱ࠣ࡬ࡴࡹࡴࡦࡴࡶ࠲࡚ࠥࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤ࡮ࡹࠠࡴ࡫ࡰࡴࡱࡿࠠࡢࠢࡺࡩࡧࠦࡢࡳࡱࡺࡷࡪࡸ࠮ࠨྍ")
	cFjMEShi6Pp0otRBgeXq8(wdftVMyzF17cYETHu(u"࠭࡬ࡦࡨࡷࠫྎ"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠧࡅ࡫ࡪ࡭ࡹࡧ࡬ࠡࡏ࡬ࡰࡱ࡫࡮࡯࡫ࡸࡱࠥࡉ࡯ࡱࡻࡵ࡭࡬࡮ࡴࠡࡃࡦࡸࠥ࠮ࡄࡎࡅࡄ࠭ࠬྏ"),YMaiHbnIThsP7q,ggjO5CrKVRPITaesWkxD(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫྐ"))
	return
def FFIXquxWtmJKDzf68():
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,jL5CrsRwebpyDVXUc1EQP(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬྑ"),FgXzMs0YSDt(u"ࠪห้ฮั็ษ่ะ๊ࠥวࠡ์ไัฺࠦิ่ษาอࠥอไหึไ๎ึูࠦ็ัࠣห้อสึษ็ࠤออไๆ๊สๆ฾ࠦวๅ็ืๅึฯ้ࠠๆ๊ิฬࠦแ๋ࠢะห้่ࠦอ๊าࠤูํวะหࠣ฾๏ืࠠึฯํัฮࠦร้่๊ࠢฯํ๊สࠢสฺ่๊วฮ์ฬࠤศ๎ࠠๆิํๅฮࠦแศ่๋ࠣีอࠠๅ่ࠣ๎ํ่แࠡษ็ีอ฽ࠠศๆุ่ๆื้ࠠๆ้ࠤ๏๎โโࠢ฼้้ࠦวๅสิ๊ฬ๋ฬࠨྒ"))
	V0VFZmTWXpLejkS32ItN9lHQ7()
	return
def zFwJg8eaXrP1():
	XgbcrBleMx5LYWzKjFCHIOP,mmv7XkyreCIJGUqhTYi5KB6DWSn,kQ90RuKEmXbqfP6as7pe4MIdvoG1cH,AAiROomtT6LBXpcaWPSC,OKpomTIlxzynRwt4VMCrjANSX80,M0DdaCj5Gk79mtBTAw,JD8PUBM7IAkL = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	B7gtJnK24RY,VnhIq7s8FNLTi916b,CUMLr4kyB7tKulj9edqZbin,B5VubYgEyAM6xjDmSfKOsL1P2ehkC = {QjAINyUC7MDRq5d8e4vl9(u"ࠫࡦ࠭ྒྷ"):C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬࡧࠧྔ")},{},[],{}
	url = I4t9qonjrm.SITESURLS[oRJAfwD957WkUyBM1Ehu8m(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ྕ")][BkM54Kr7Qbqn]
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(D1KfvmcCjGYbgSoyX,PlpyFa9QMKXxOD1cvHzmI(u"ࠧࡑࡑࡖࡘࠬྖ"),url,B7gtJnK24RY,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,SnhLjmfeJC(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰࡙ࡘࡇࡇࡆࡡࡕࡉࡕࡕࡒࡕ࠯࠴ࡷࡹ࠭ྗ"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	FGRX4myP68S = FGRX4myP68S.replace(aOQTKXFL54Nl60Zhp3MbE(u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡖࡸࡦࡺࡥࡴࠩ྘"),vU6DxuzPwMpg(u"࡙ࠪࡘࡇࠧྙ"))
	FGRX4myP68S = FGRX4myP68S.replace(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࡚ࠫࡴࡩࡵࡧࡧࠤࡐ࡯࡮ࡨࡦࡲࡱࠬྚ"),sIzDXlTHYUC5L3xZGnr(u"࡛ࠬࡋࠨྛ"))
	FGRX4myP68S = FGRX4myP68S.replace(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠭ࡕ࡯࡫ࡷࡩࡩࠦࡁࡳࡣࡥࠤࡊࡳࡩࡳࡣࡷࡩࡸ࠭ྜ"),PlpyFa9QMKXxOD1cvHzmI(u"ࠧࡖࡃࡈࠫྜྷ"))
	FGRX4myP68S = FGRX4myP68S.replace(Hr25gta6XcqO(u"ࠨࡕࡤࡹࡩ࡯ࠠࡂࡴࡤࡦ࡮ࡧࠧྞ"),oRJAfwD957WkUyBM1Ehu8m(u"ࠩࡎࡗࡆ࠭ྟ"))
	FGRX4myP68S = FGRX4myP68S.replace(vU6DxuzPwMpg(u"ࠪࡒࡴࡸࡴࡩࠢࡐࡥࡨ࡫ࡤࡰࡰ࡬ࡥࠬྠ"),CsDcLqQUVK4YBvHFW1(u"ࠫࡓ࠴ࡍࡢࡥࡨࡨࡴࡴࡩࡢࠩྡ"))
	FGRX4myP68S = FGRX4myP68S.replace(SnhLjmfeJC(u"ࠬ࡝ࡥࡴࡶࡨࡶࡳࠦࡓࡢࡪࡤࡶࡦ࠭ྡྷ"),FmYoGejTnwKME7d9zPc(u"࠭ࡗ࠯ࡕࡤ࡬ࡦࡸࡡࠨྣ"))
	FGRX4myP68S = FGRX4myP68S.replace(I18uSKaWhgTBeYUPD4sr(u"ࠧࡠࡡࡢࠫྤ"),OOiSqkBcMPptI)
	try: woWObmzl4PKqXJcgG9ItNn = LB7TcZnGYdfw5lWU1RH3Oztu9PyA(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨ࡮࡬ࡷࡹ࠭ྥ"),FGRX4myP68S)
	except:
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬྦ"),o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪๅู๊ࠠโ์ࠣะ้ฮࠠๆฯอ์๏อสࠡฬๅี๏ืࠠศๆสืฯิฯศ็ࠪྦྷ"))
		return
	JeKIP9C24hAOVu8,Oo8yxTp20r7Db65mjRAJIX9nUPGHN,iiP7jkzGK0O3QX95FZEgbAwc8n = woWObmzl4PKqXJcgG9ItNn
	B5VubYgEyAM6xjDmSfKOsL1P2ehkC = {}
	DNSisFfj6V = [QjAINyUC7MDRq5d8e4vl9(u"ࠫࡈࡇࡐࡕࡅࡋࡅࡎࡊࠧྨ"),aOQTKXFL54Nl60Zhp3MbE(u"ࠬࡉࡁࡑࡖࡆࡌࡆ࡚ࡏࡌࡇࡑࠫྩ")]
	ttne8YqXUaHiKZMjLvbV56uI3 = [KfHAW8VGbrxi(u"࠭ࡁࡍࡎࠪྪ"),KfHAW8VGbrxi(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧྫ"),I18uSKaWhgTBeYUPD4sr(u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩྫྷ"),AAbvaXV2DQzfNHdm4U3tT(u"ࠩࡐࡉ࡙ࡘࡏࡑࡑࡏࡍࡘ࠭ྭ"),Hr25gta6XcqO(u"ࠪࡖࡊࡖࡏࡔࠩྮ")]+DNSisFfj6V+I4t9qonjrm.api_python_actions+I4t9qonjrm.api_repos_actions
	for C0C4kdG53sPAbNq8OBMpitLThHl,cPIAYCSt7e,ftNkeYHIUsTzCVopG8iFMaj42W5 in Oo8yxTp20r7Db65mjRAJIX9nUPGHN:
		ftNkeYHIUsTzCVopG8iFMaj42W5 = XXcPiylRDh6IapYA25rwO8u(ftNkeYHIUsTzCVopG8iFMaj42W5)
		ftNkeYHIUsTzCVopG8iFMaj42W5 = ftNkeYHIUsTzCVopG8iFMaj42W5.strip(ksJdoFWhxTz8Y2N7bOZE).strip(QjAINyUC7MDRq5d8e4vl9(u"ࠫࠥ࠴ࠧྯ"))
		AAiROomtT6LBXpcaWPSC += C0qrknitpM4Z+WydpaVx5YmLoCiIgA34eEBlb+C0C4kdG53sPAbNq8OBMpitLThHl+FmYoGejTnwKME7d9zPc(u"ࠬࡀࠠࠨྰ")+T7ASIp1ZYwio9HQ8cObJK+ftNkeYHIUsTzCVopG8iFMaj42W5+C0qrknitpM4Z
		if cPIAYCSt7e.isdigit():
			B5VubYgEyAM6xjDmSfKOsL1P2ehkC[C0C4kdG53sPAbNq8OBMpitLThHl] = int(cPIAYCSt7e)
			if int(cPIAYCSt7e)>PlpyFa9QMKXxOD1cvHzmI(u"࠱࠱࠲ᅁ"): cPIAYCSt7e = CsDcLqQUVK4YBvHFW1(u"࠭ࡨࡪࡩ࡫ࡹࡸࡧࡧࡦࠩྱ")
			else: cPIAYCSt7e = Gcw2nelTR864XCVruO3mAFqI5a(u"ࠧ࡭ࡱࡺࡹࡸࡧࡧࡦࠩྲ")
		if C0C4kdG53sPAbNq8OBMpitLThHl not in ttne8YqXUaHiKZMjLvbV56uI3:
			if   cPIAYCSt7e==LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨࡪ࡬࡫࡭ࡻࡳࡢࡩࡨࠫླ"): XgbcrBleMx5LYWzKjFCHIOP += OOiSqkBcMPptI+C0C4kdG53sPAbNq8OBMpitLThHl
			elif cPIAYCSt7e==SnhLjmfeJC(u"ࠩ࡯ࡳࡼࡻࡳࡢࡩࡨࠫྴ"): mmv7XkyreCIJGUqhTYi5KB6DWSn += OOiSqkBcMPptI+C0C4kdG53sPAbNq8OBMpitLThHl
	pBfnISQvKX7VikaszR0bmqT,LlJbKCaVSxy5Inc7w1uYgk8tj9,gGoDyKYP1Rhjk = list(zip(*Oo8yxTp20r7Db65mjRAJIX9nUPGHN))
	for C0C4kdG53sPAbNq8OBMpitLThHl in sorted(GgeKIqHm8XM):
		if C0C4kdG53sPAbNq8OBMpitLThHl not in pBfnISQvKX7VikaszR0bmqT:
			AAiROomtT6LBXpcaWPSC += C0qrknitpM4Z+WydpaVx5YmLoCiIgA34eEBlb+C0C4kdG53sPAbNq8OBMpitLThHl+aOQTKXFL54Nl60Zhp3MbE(u"ࠪ࠾ࠥ࠭ྵ")+T7ASIp1ZYwio9HQ8cObJK+C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"้ࠫอ๋๊ࠠฯำࠬྶ")+OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠬࡢ࡮࡝ࡰࠪྷ")
			if C0C4kdG53sPAbNq8OBMpitLThHl not in ttne8YqXUaHiKZMjLvbV56uI3: kQ90RuKEmXbqfP6as7pe4MIdvoG1cH += OOiSqkBcMPptI+C0C4kdG53sPAbNq8OBMpitLThHl
	for ftNkeYHIUsTzCVopG8iFMaj42W5,FdM76PmREvS0tYfyZx3eTgQw8o5I in JeKIP9C24hAOVu8:
		ftNkeYHIUsTzCVopG8iFMaj42W5 = XXcPiylRDh6IapYA25rwO8u(ftNkeYHIUsTzCVopG8iFMaj42W5)
		OKpomTIlxzynRwt4VMCrjANSX80 += ftNkeYHIUsTzCVopG8iFMaj42W5+ssynAg0zhSkoCpOMDV9(u"࠭࠺ࠡࠩྸ")+n0nFOd4yR97fQzNLSW+str(FdM76PmREvS0tYfyZx3eTgQw8o5I)+T7ASIp1ZYwio9HQ8cObJK+O3OVuapf0YFjbm5oUQDg(u"ࠧࠡࠢࠣࠫྐྵ")
	XgbcrBleMx5LYWzKjFCHIOP = XgbcrBleMx5LYWzKjFCHIOP.strip(ksJdoFWhxTz8Y2N7bOZE)
	mmv7XkyreCIJGUqhTYi5KB6DWSn = mmv7XkyreCIJGUqhTYi5KB6DWSn.strip(ksJdoFWhxTz8Y2N7bOZE)
	kQ90RuKEmXbqfP6as7pe4MIdvoG1cH = kQ90RuKEmXbqfP6as7pe4MIdvoG1cH.strip(ksJdoFWhxTz8Y2N7bOZE)
	SqAcjxamEseGnNKvRrOTZ8oF15IiLW = XgbcrBleMx5LYWzKjFCHIOP+OOiSqkBcMPptI+mmv7XkyreCIJGUqhTYi5KB6DWSn
	yNHtZ2UL56qRM3vYxi  = Gcw2nelTR864XCVruO3mAFqI5a(u"ࠨ็๋ห็฿ࠠ็ฮะࠤฬ๊ศา่ส้ัࠦศหึ฽๎้ࠦแ๋ัํ์์อสࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠬྺ")+C0qrknitpM4Z+Gcw2nelTR864XCVruO3mAFqI5a(u"๋๋ࠩีอࠠๆ฻้ห์ࠦลัษ่ࠣิ๐ใࠡ็ื็้ฯࠠโ้ํࠤ้๐ำห่๊ࠢࠥอไษำ้ห๊าࠧྻ")+C0qrknitpM4Z
	yNHtZ2UL56qRM3vYxi += n0nFOd4yR97fQzNLSW+SqAcjxamEseGnNKvRrOTZ8oF15IiLW+T7ASIp1ZYwio9HQ8cObJK+s5WMHyQN4mpie(u"ࠪࡠࡳࡢ࡮ࠨྼ")
	yNHtZ2UL56qRM3vYxi += vU6DxuzPwMpg(u"๊ࠫ๎วใ฻่๊๊ࠣࠦี฼็ࠤฬ๊ศา่ส้ัࠦๅ็้สࠤๆ๐ฯ๋๊๊หฯࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠪ྽")+C0qrknitpM4Z+wdftVMyzF17cYETHu(u"ࠬ๎็ัษ้ࠣ฾์ว่ࠢสัฯ๋วๅࠢๆฬ๏ื้ࠠฮ๋ำ๋ࠥิไๆฬࠤๆ๐ࠠศๆหี๋อๅอࠩ྾")+C0qrknitpM4Z
	yNHtZ2UL56qRM3vYxi += n0nFOd4yR97fQzNLSW+kQ90RuKEmXbqfP6as7pe4MIdvoG1cH+T7ASIp1ZYwio9HQ8cObJK
	sBobj9vF8YRlT2dc,RNUdXJM3BVPAH8vaxoWF4wlquIsTLE,nvFyC6Nr8SA4JQl9wTt1L,ug1m9hkZBioCU8A = KfHAW8VGbrxi(u"࠱ᅂ"),KfHAW8VGbrxi(u"࠱ᅂ"),KfHAW8VGbrxi(u"࠱ᅂ"),KfHAW8VGbrxi(u"࠱ᅂ")
	all = B5VubYgEyAM6xjDmSfKOsL1P2ehkC[FgXzMs0YSDt(u"࠭ࡁࡍࡎࠪ྿")]
	if O3OVuapf0YFjbm5oUQDg(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ࿀") in list(B5VubYgEyAM6xjDmSfKOsL1P2ehkC.keys()): sBobj9vF8YRlT2dc = B5VubYgEyAM6xjDmSfKOsL1P2ehkC[SnhLjmfeJC(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ࿁")]
	if V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠩࡌࡒࡘ࡚ࡁࡍࡎࠪ࿂") in list(B5VubYgEyAM6xjDmSfKOsL1P2ehkC.keys()): RNUdXJM3BVPAH8vaxoWF4wlquIsTLE = B5VubYgEyAM6xjDmSfKOsL1P2ehkC[O3OVuapf0YFjbm5oUQDg(u"ࠪࡍࡓ࡙ࡔࡂࡎࡏࠫ࿃")]
	if ggjO5CrKVRPITaesWkxD(u"ࠫࡒࡋࡔࡓࡑࡓࡓࡑࡏࡓࠨ࿄") in list(B5VubYgEyAM6xjDmSfKOsL1P2ehkC.keys()): nvFyC6Nr8SA4JQl9wTt1L = B5VubYgEyAM6xjDmSfKOsL1P2ehkC[FgXzMs0YSDt(u"ࠬࡓࡅࡕࡔࡒࡔࡔࡒࡉࡔࠩ࿅")]
	if N6NGJ4vpmidqMCh7yo(u"࠭ࡒࡆࡒࡒࡗ࿆ࠬ") in list(B5VubYgEyAM6xjDmSfKOsL1P2ehkC.keys()): ug1m9hkZBioCU8A = B5VubYgEyAM6xjDmSfKOsL1P2ehkC[o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧࡓࡇࡓࡓࡘ࠭࿇")]
	hhNxKRF4sgcz = all-sBobj9vF8YRlT2dc-RNUdXJM3BVPAH8vaxoWF4wlquIsTLE-nvFyC6Nr8SA4JQl9wTt1L-ug1m9hkZBioCU8A
	O4On5rLamD7q1zKBo6WfF3eEbS98,HitwDOJVZ5zeKFl6jWBgXGdo = iiP7jkzGK0O3QX95FZEgbAwc8n[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	O4On5rLamD7q1zKBo6WfF3eEbS98,Z2lbOERTDyI4ohCLvWzrA = iiP7jkzGK0O3QX95FZEgbAwc8n[BkM54Kr7Qbqn]
	JPSKge5oRqOXpwjMdBci = HitwDOJVZ5zeKFl6jWBgXGdo-Z2lbOERTDyI4ohCLvWzrA
	JD8PUBM7IAkL += WydpaVx5YmLoCiIgA34eEBlb+str(Z2lbOERTDyI4ohCLvWzrA)+T7ASIp1ZYwio9HQ8cObJK+vU6DxuzPwMpg(u"ࠨษ็฽ิีࠠศๆะๆ๏่๊ࠡๆ็วัําสࠢ࠽ࠤࠬ࿈")
	JD8PUBM7IAkL += C0qrknitpM4Z+WydpaVx5YmLoCiIgA34eEBlb+str(JPSKge5oRqOXpwjMdBci)+T7ASIp1ZYwio9HQ8cObJK+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩหหุะฮะษ่ࠤࡵࡸ࡯ࡹࡻࠣวํࠦࡶࡱࡰࠣ࠾ࠥ࠭࿉")
	JD8PUBM7IAkL += C0qrknitpM4Z+WydpaVx5YmLoCiIgA34eEBlb+str(HitwDOJVZ5zeKFl6jWBgXGdo)+T7ASIp1ZYwio9HQ8cObJK+vU6DxuzPwMpg(u"ࠪห้฿ฯะࠢส่่๊๊ࠡๆฯ้๏฿ࠠศๆฦะ์ุษࠡ࠼ࠣࠫ࿊")
	JD8PUBM7IAkL += C0qrknitpM4Z+WydpaVx5YmLoCiIgA34eEBlb+str(len(iiP7jkzGK0O3QX95FZEgbAwc8n[PlpyFa9QMKXxOD1cvHzmI(u"࠴ᅃ"):]))+T7ASIp1ZYwio9HQ8cObJK+s5WMHyQN4mpie(u"ࠫ฾ีฯࠡษ็ำํ๊ࠠศๆอ๎ࠥ็๊่ษࠣวัําสࠢ࠽ࠤࡡࡴ࡜࡯ࠩ࿋")
	for PPf96YqGdatREx,jewzZuNFibTO in iiP7jkzGK0O3QX95FZEgbAwc8n[O3OVuapf0YFjbm5oUQDg(u"࠵ᅄ"):]:
		PPf96YqGdatREx = XXcPiylRDh6IapYA25rwO8u(PPf96YqGdatREx)
		PPf96YqGdatREx = PPf96YqGdatREx.strip(ksJdoFWhxTz8Y2N7bOZE).strip(o1INZ3ViQqS0Uw5z6kMjbv(u"ࠬࠦ࠮ࠨ࿌"))
		JD8PUBM7IAkL += PPf96YqGdatREx+FgXzMs0YSDt(u"࠭࠺ࠡࠩ࿍")+n0nFOd4yR97fQzNLSW+str(jewzZuNFibTO)+T7ASIp1ZYwio9HQ8cObJK+oRJAfwD957WkUyBM1Ehu8m(u"ࠧࠡࠢࠣࠫ࿎")
	M0DdaCj5Gk79mtBTAw += WydpaVx5YmLoCiIgA34eEBlb+str(hhNxKRF4sgcz)+T7ASIp1ZYwio9HQ8cObJK+PlpyFa9QMKXxOD1cvHzmI(u"ࠨใํำ๏๎็ศฬࠣหูะฺๅฬࠣ࠾ࠥ࠭࿏")
	M0DdaCj5Gk79mtBTAw += C0qrknitpM4Z+WydpaVx5YmLoCiIgA34eEBlb+str(sBobj9vF8YRlT2dc)+T7ASIp1ZYwio9HQ8cObJK+N6NGJ4vpmidqMCh7yo(u"ฺ่ࠩออสࠡีํีๆืࠠษษํฯํ์ࠠ࠻ࠢࠪ࿐")
	M0DdaCj5Gk79mtBTAw += C0qrknitpM4Z+WydpaVx5YmLoCiIgA34eEBlb+str(ug1m9hkZBioCU8A)+T7ASIp1ZYwio9HQ8cObJK+o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪ฻้ฮวหࠢึ๎ึ็ัࠡษ็ุ้ะ่ะ฻ࠣ࠾ࠥ࠭࿑")
	M0DdaCj5Gk79mtBTAw += C0qrknitpM4Z+WydpaVx5YmLoCiIgA34eEBlb+str(RNUdXJM3BVPAH8vaxoWF4wlquIsTLE)+T7ASIp1ZYwio9HQ8cObJK+Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠫฯัศ๋ฬࠣฮ฼ฮ๊ใࠢๆ์ิ๐ฺࠠ็สำࠥࡀࠠࠨ࿒")
	M0DdaCj5Gk79mtBTAw += C0qrknitpM4Z+WydpaVx5YmLoCiIgA34eEBlb+str(nvFyC6Nr8SA4JQl9wTt1L)+T7ASIp1ZYwio9HQ8cObJK+wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠬะหษ์อࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠼ࠣࠫ࿓")
	M0DdaCj5Gk79mtBTAw += C0qrknitpM4Z+WydpaVx5YmLoCiIgA34eEBlb+str(len(JeKIP9C24hAOVu8))+T7ASIp1ZYwio9HQ8cObJK+uulNDCPyef78(u"࠭ฯ้ๆุࠣ฿๊สࠡใํำ๏๎็ศฬࠣ࠾ࠥ࠭࿔")
	M0DdaCj5Gk79mtBTAw += CsDcLqQUVK4YBvHFW1(u"ࠧ࡝ࡰ࡟ࡲࠬ࿕")+OKpomTIlxzynRwt4VMCrjANSX80
	cFjMEShi6Pp0otRBgeXq8(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ࿖"),KfHAW8VGbrxi(u"ࠩ฼ำิࠦวๅลฯ๋ืฯࠠศๆอ๎ࠥอำหะา้ฯࠦ็ัษࠣห้ฮั็ษ่ะࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠢไ๎ࠥอไฺษ็้้ࠥไ่ࠩ࿗"),JD8PUBM7IAkL,Hr25gta6XcqO(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭࿘"))
	cFjMEShi6Pp0otRBgeXq8(uulNDCPyef78(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ࿙"),FmYoGejTnwKME7d9zPc(u"ࠬ฿ฯะࠢส่ๆ๐ฯ๋๊๊หฯࠦวๅฬํࠤูเไ่ษ๋ࠣีอࠠศๆหี๋อๅอࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮࠦแ๋ࠢส่฾อไๆࠢๆ่์࠭࿚"),M0DdaCj5Gk79mtBTAw,AAbvaXV2DQzfNHdm4U3tT(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ࿛"))
	cFjMEShi6Pp0otRBgeXq8(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠧࡤࡧࡱࡸࡪࡸࠧ࿜"),oRJAfwD957WkUyBM1Ehu8m(u"ࠨ็๋ห็฿ࠠศึอ฾้ะࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠤๆ๐ࠠศๆ฼ห้๋ࠠไๆ๊ࠫ࿝"),yNHtZ2UL56qRM3vYxi,LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ࿞"))
	cFjMEShi6Pp0otRBgeXq8(O3OVuapf0YFjbm5oUQDg(u"ࠪࡰࡪ࡬ࡴࠨ࿟"),aOQTKXFL54Nl60Zhp3MbE(u"ࠫศ฿ไ๊ࠢส่ิ๎ไࠡษ็ฮ๏ࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠣหุะฮะ็อࠤฬ๊ศา่ส้ั࠭࿠"),AAiROomtT6LBXpcaWPSC,s5WMHyQN4mpie(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭࿡"))
	return
def KlHyangZspiJMwG4B6LV():
	kf40tulvSA7z9RqNF5dXca3seMD = sJw9QWiq1Kr0xfeVRI(u"࠭็ัษࠣห้ฮั็ษ่ะࠥ๐ูๆๆࠣหๆ฼ไࠡสสืฯิฯศ็ࠣะ้ีࠠไ๊า๎ࠥ࠮ࡋࡰࡦ࡬ࠤࡘࡱࡩ࡯ࠫࠣห้ึ๊ࠡษึ้์ࡢ࡮ࠨ࿢")+WydpaVx5YmLoCiIgA34eEBlb+wdftVMyzF17cYETHu(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭࿣")+T7ASIp1ZYwio9HQ8cObJK+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠨ࡞ࡱࡠࡳࡢ࡮๊่้่ࠡ์ࠠหอห๎ฯํࠠษษึฮำีวๆ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠࡆࡏࡄࡈࠥࡘࡥࡱࡱࡶ࡭ࡹࡵࡲࡺࠢฦ์ࠥะอๆ์็๋๋ࠥๆ࡝ࡰࠪ࿤")+WydpaVx5YmLoCiIgA34eEBlb+LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱࠪ࿥")+T7ASIp1ZYwio9HQ8cObJK+uulNDCPyef78(u"ࠪࡠࡳࡢ࡮࡝ࡰ๋ࠣีํࠠศๆิืฬ๊ษ๊ࠡ฽๎ึํวࠡๅฮ๎ึࠦๅ้ฮ๋ำฮࠦแ๋ࠢๅหห๋ษࠡะา้ฬะࠠศๆหี๋อๅอ๋ࠢห้๋า๋ัࠣว๏฼วࠡ็๋ะํีࠠโ์ࠣๆฬฬๅสࠢฦะํฮษࠡษ็ฬึ์วๆฮࠪ࿦")
	cFjMEShi6Pp0otRBgeXq8(SnhLjmfeJC(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ࿧"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࿨"),kf40tulvSA7z9RqNF5dXca3seMD,EE1jeHnIoad(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ࿩"))
	return
def btfGBPRgIAskW7T3():
	kf40tulvSA7z9RqNF5dXca3seMD = sIzDXlTHYUC5L3xZGnr(u"ࠧศๆิหอ฽๊็ࠢฦำ๋อ็ࠡใํ๋๊อࠠหูห๎็ࠦใ้ัํࠤ฾๋วะ๋๋ࠢํูࠦษษิอࠥ฿ๆࠡฬฮฬ๏ะࠠไษ่่ࠥอ่ห๊่หฯ๐ใ๋ࠢ็ฬึ์วๆฮࠣ็ํี๊๊่ࠡ฽์ࠦวืษไอࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษ๊่ࠡ฽์ࠦวืษไอࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะ๋้ࠢ฾ํࠠศุสๅฮࠦๅิฬ๋ำ฾ูࠦๆษาࠤํ็๊่ࠢฦ๎฻อࠠอ็ํ฽ࠥอูะษาฮ้่ࠥะ์ࠣห้๋ืๅ๊หอู๊ࠥๆๆࠣฬึ์วๆฮࠣ฽๊อฯ๊ࠡๆ่์อࠠหฬ่ࠤฬ๎ส้็สฮ๏้๊ศ๋่ࠢฬࠦสฮฬสะࠥษ๊่๋ࠡ฽๋ࠥๆࠡษ็าอืษࠡใํࠤ่๎ฯ๋ࠢฦ์ࠥอไฯสิอࠥ็๊ࠡฬฮฬ๏ะࠠฤุสๅฬะࠠไ๊า๎ࠬ࿪")+C0qrknitpM4Z+n0nFOd4yR97fQzNLSW+I4t9qonjrm.SITESURLS[sIzDXlTHYUC5L3xZGnr(u"ࠨࡍࡒࡈࡎࡋࡍࡂࡆࡢࡅࡕࡖࠧ࿫")][D2D96X5NGamBhrFwvL8VEbqiSfZIl]+T7ASIp1ZYwio9HQ8cObJK+aOQTKXFL54Nl60Zhp3MbE(u"ࠩࠣࠤࠥࠦร้ࠢࠣࠤࠥ࠭࿬")+n0nFOd4yR97fQzNLSW+I4t9qonjrm.SITESURLS[vU6DxuzPwMpg(u"ࠪࡏࡔࡊࡉࡆࡏࡄࡈࡤࡇࡐࡑࠩ࿭")][BkM54Kr7Qbqn]+T7ASIp1ZYwio9HQ8cObJK
	kf40tulvSA7z9RqNF5dXca3seMD += aOQTKXFL54Nl60Zhp3MbE(u"ࠫࡡࡴ࡜࡯࡞ࡱห้ืวษูࠣวิ์ว่๊ࠢ์ࠥอไิ๊ิืࠥอไั์ࠣ๎าะวอ้้ࠣิ๐ัࠡ็็ๅฬะࠠไ๊า๎๊ࠥสฬสํฮࠥฮั็ษ่ะࠥ฿ๅศัࠣฬฬ๊ืา์ๅอࠥอไหไ็๎ิ๐ษࠡษ็ๆิ๐ๅส࡞ࡱࠫ࿮")+n0nFOd4yR97fQzNLSW+I4t9qonjrm.SITESURLS[V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠬࡑࡏࡅࡋࡢࡗࡔ࡛ࡒࡄࡇࡖࠫ࿯")][D2D96X5NGamBhrFwvL8VEbqiSfZIl]+T7ASIp1ZYwio9HQ8cObJK+vU6DxuzPwMpg(u"࠭ࠠࠡࠢࠣวํࠦࠠࠡࠢࠪ࿰")+n0nFOd4yR97fQzNLSW+I4t9qonjrm.SITESURLS[AAbvaXV2DQzfNHdm4U3tT(u"ࠧࡌࡑࡇࡍࡤ࡙ࡏࡖࡔࡆࡉࡘ࠭࿱")][BkM54Kr7Qbqn]+T7ASIp1ZYwio9HQ8cObJK
	kf40tulvSA7z9RqNF5dXca3seMD += oRJAfwD957WkUyBM1Ehu8m(u"ࠨ࡞ࡱࡠࡳࡢ࡮อ็ํ฽๋ࠥไโษอࠤ฾๋วะ่ࠢ์ั๎ฯสࠢไ๎ࠥอไๆ๊ๅ฽ࠥษฯ็ษ๊ࠫ࿲")+C0qrknitpM4Z+n0nFOd4yR97fQzNLSW+I4t9qonjrm.SITESURLS[oRJAfwD957WkUyBM1Ehu8m(u"ࠩࡉࡍࡑࡋࡓࡠࡕࡒ࡙ࡗࡉࡅࡔࠩ࿳")][D2D96X5NGamBhrFwvL8VEbqiSfZIl]+T7ASIp1ZYwio9HQ8cObJK
	cFjMEShi6Pp0otRBgeXq8(KfHAW8VGbrxi(u"ࠪࡧࡪࡴࡴࡦࡴࠪ࿴"),oRJAfwD957WkUyBM1Ehu8m(u"ࠫฬ๊ๅ้ษๅ฽ࠥอไาี่๎ฮࠦไษำ้ห๊าฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠪ࿵"),kf40tulvSA7z9RqNF5dXca3seMD,EE1jeHnIoad(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ࿶"))
	return
def kzDcF6g7uEtSymWqbXxnQl2ipdra(qlXvLYJOZdCuRb1PsfIo2VwpcE):
	bEWpDHXjCBqd7aOiN6UG5k.executebuiltin(SnhLjmfeJC(u"࠭ࡁࡥࡦࡲࡲ࠳ࡕࡰࡦࡰࡖࡩࡹࡺࡩ࡯ࡩࡶࠬࠬ࿷")+qlXvLYJOZdCuRb1PsfIo2VwpcE+oRJAfwD957WkUyBM1Ehu8m(u"ࠧࠪࠩ࿸"), EsCplGc5N4mBuYW0RVQt6b)
	return
def Z892VKqDTv1xsEfeoyAPG6nNWcgSm():
	X0FQnRaH9WyrEJcl7dj6w4kuDL(LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨࡵࡷࡳࡵ࠭࿹"))
	bEWpDHXjCBqd7aOiN6UG5k.executebuiltin(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠤࡄࡧࡹ࡯ࡶࡢࡶࡨ࡛࡮ࡴࡤࡰࡹࠫࡍࡳࡺࡥࡳࡨࡤࡧࡪ࡙ࡥࡵࡶ࡬ࡲ࡬ࡹࠩࠣ࿺"))
	return
def Z3Yywxf0vRcNVgeisru92KzH():
	bEWpDHXjCBqd7aOiN6UG5k.executebuiltin(I18uSKaWhgTBeYUPD4sr(u"ࠪࡅࡩࡪ࡯࡯࠰ࡒࡴࡪࡴࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠩ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠪࠩ࿻"), EsCplGc5N4mBuYW0RVQt6b)
	return
def M70MpvtyCzk8E9jYJu():
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,N6NGJ4vpmidqMCh7yo(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ࿼"),sIzDXlTHYUC5L3xZGnr(u"๊ࠬๅิฯ้ࠣาะ่๋ษอࠤ็อฦๆหࠣ࠲ࠥอะ่สࠣษ้๏ࠠศๆๅหห๋ษࠡษ็ฮ๏ࠦสา์าࠤู๊อ่ษࠣ์้อࠠหัั่ࠥหไ๋้สࠤํ๊ใ็ࠢหหุะฮะษ่ࠤࠧอไๆษ๋ืࠧࠦร้ࠢࠥห้ื๊ๆ๊อࠦࠥอึ฻ูࠣ฽้๏ࠠศๆีีࠥา็สࠢส่๏๋๊็ࠢฦ์ࠥอำหะา้ࠥࠨวๅๅํฬํืฯ๋ࠣࠢห฻เืࠡ฻็ํࠥำัโࠢࠥࡇࠧࠦร้ࠢ฼่๎ࠦวื฼ฺࠤ฾๊้ࠡิิࠤࠧอไใษษ้ฮࠨࠠศๆำ๎ࠥ็๊ࠡฮ๊อࠥอไ๋็ํ๊ࠬ࿽"))
	return
def rQ29e5mjVKSZtGMIEAx():
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,aOQTKXFL54Nl60Zhp3MbE(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ࿾"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠧๅๆอ฽ฬ๋ไࠡ็฼ࠤฬ๊ๅโุ็อࠥ࠴ࠠศา๊ฬࠥหไ๊ࠢส่ึอศุࠢส่ี๐ࠠหำํำࠥหึศใอ๋ࠥษ่ࠡ็ึั์ࠦๅ็ࠢࠣๆฬฬๅสࠢส่๊็ึๅหࠣ์้้ๆࠡๆสࠤฯ์โาࠢ฼่๏ํ้ࠠๆสࠤฯฺฺๅ้ࠣ࠲ࠥ๎ศศีอาิอๅࠡࠤส่๊อ่ิࠤࠣวํࠦࠢศๆิ๎๊๎สࠣࠢสฺ฿฽ฺࠠๆ์ࠤฬ๊าาࠢฯ๋ฮࠦวๅ์่๎๋ࠦ࠮๊ࠡฦ้ฬࠦศศีอาิอๅࠡࠤส่่๐ศ้ำาࠦࠥ็วื฼ฺࠤ฾๊้ࠡฯิๅࠥࠨࡃࠣࠢฦ์ࠥ฿ไ๊ࠢีีࠥࠨวๅไสส๊ฯࠢࠡษ็ิ๏ࠦแ๋ࠢฯ๋ฮࠦวๅ์่๎๋ࠦ࠮๊้ࠡๅุࠦวๅๅ็ห๊่ࠦศๆฺี๏่ษࠡ฻้ำࠥอไห฻ส้้ࠦๅฺ่ࠢัฯ๎๊ศฬࠣๆํอฦๆࠢส่๊็ึๅหࠪ࿿"))
	return
def tE4opQ8FJUa5Neh1MnyKSm(p069BCUer1IskxHvTd8OL=FgXzMs0YSDt(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧက"),showDialogs=EsCplGc5N4mBuYW0RVQt6b):
	YjXGEndQ5TZs3S4e2auCvBwtIfKix = bEWpDHXjCBqd7aOiN6UG5k.executeJSONRPC(PlpyFa9QMKXxOD1cvHzmI(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤࢀࢁࠬခ"))
	data = Qra2CWgebk.loads(YjXGEndQ5TZs3S4e2auCvBwtIfKix)
	MRz4UWYajI = data[jL5CrsRwebpyDVXUc1EQP(u"ࠪࡶࡪࡹࡵ࡭ࡶࠪဂ")][EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠫࡻࡧ࡬ࡶࡧࠪဃ")]
	if gZlSEJaXO9F461AL3sR7rWNpqf: MRz4UWYajI = MRz4UWYajI.encode(Tk9eH2qw6Brsuhj)
	if showDialogs:
		Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,PlpyFa9QMKXxOD1cvHzmI(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨင"),ssynAg0zhSkoCpOMDV9(u"࠭็ๅࠢอี๏ีࠠห฼ํ๎ึࠦฬๅัࠣࠫစ")+MRz4UWYajI+wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧࠡษ็ิ๏ࠦๅิฬัำ๊ࠦวๅฤ้ࠤๆ๐ࠠไ๊า๎ࠥหไ๊ࠢส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣั๊ฯࠡࠩဆ")+p069BCUer1IskxHvTd8OL+aOQTKXFL54Nl60Zhp3MbE(u"ࠨࠢยࠥࠬဇ"))
		if Scj7zgGFVA83otMpwUkxhm0BLN1!=Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠵ᅅ"): return LhFAGlQ19zr
	ddecO3Tb9U5k,H9DQpd06Of,Xa6dHU8PZeswyTtM = ElFY9uVGWzyB4TZ6dpjg3shv(p069BCUer1IskxHvTd8OL,LhFAGlQ19zr,LhFAGlQ19zr)
	if ddecO3Tb9U5k:
		if showDialogs: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,oRJAfwD957WkUyBM1Ehu8m(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬဈ"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠪฮ๊ะฺࠠ็็๎ฮࠦสฬสํฮࠥอไอๆาࠤฬ๊ฬะ์าࠤํํ่ࠡฮส๋ืࠦไๅษึฮำีวๆࠢ࠱ࠤุ๎แࠡ์อ้ࠥอไร่ࠣฮ฿๐๊าࠢศ฽ิอฯศฬࠣ็ํี๊ࠡๆๆ๎ࠥ๐ำห฻่่ࠥอไอๆาࠤฬ๊ฬะ์าࠤอีไศ่๊ࠢࠥอไใัํ้ࠬဉ"))
		s9qgDT8oclCrdXK6EUO = bEWpDHXjCBqd7aOiN6UG5k.executeJSONRPC(jL5CrsRwebpyDVXUc1EQP(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳࡙ࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦ࠱ࠨࡶࡢ࡮ࡸࡩࠧࡀࠢࠨည")+p069BCUer1IskxHvTd8OL+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠬࠨࡽࡾࠩဋ"))
		ddecO3Tb9U5k = EsCplGc5N4mBuYW0RVQt6b if Gcw2nelTR864XCVruO3mAFqI5a(u"࠭ࡏࡌࠩဌ") in s9qgDT8oclCrdXK6EUO else LhFAGlQ19zr
		uUqrNPcXKBoQ0slv.sleep(oRJAfwD957WkUyBM1Ehu8m(u"࠶ᅆ"))
		bEWpDHXjCBqd7aOiN6UG5k.executebuiltin(aOQTKXFL54Nl60Zhp3MbE(u"ࠧࡔࡧࡱࡨࡈࡲࡩࡤ࡭ࠫ࠵࠶࠯ࠧဍ"))
	elif showDialogs: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,oRJAfwD957WkUyBM1Ehu8m(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫဎ"),jL5CrsRwebpyDVXUc1EQP(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥะหษ์อࠤํะแฺ์็ࠤฬ๊ฬๅัࠣห้๋ืๅ๊หࠫဏ"))
	return ddecO3Tb9U5k
def kkx4hCedgWn2lI15bTzHaD():
	url = s5WMHyQN4mpie(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱ࡮ࡸࡲࡰࡴࡶ࠲ࡰࡵࡤࡪ࠰ࡷࡺ࠴ࡸࡥ࡭ࡧࡤࡷࡪࡹ࠯ࡸ࡫ࡱࡨࡴࡽࡳ࠰ࡹ࡬ࡲ࠻࠺࠯ࠨတ")
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,vU6DxuzPwMpg(u"ࠫࡌࡋࡔࠨထ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,oRJAfwD957WkUyBM1Ehu8m(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡔࡊࡒ࡛ࡤࡒࡁࡕࡇࡖࡘࡤࡑࡏࡅࡋࡢ࡚ࡊࡘࡓࡊࡑࡑ࠱࠶ࡹࡴࠨဒ"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	rrqlpsSCOhLHn4FM1x = EcQxOa3RJm86WjTKA.findall(I18uSKaWhgTBeYUPD4sr(u"࠭ࡴࡪࡶ࡯ࡩࡂࠨ࡫ࡰࡦ࡬࠱࠭ࡢࡤࠬ࡞࠱ࡠࡩ࠱࠭࡜ࡣ࠰ࡾࡆ࠳࡚࡞࠭ࠬ࠱ࠬဓ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	rrqlpsSCOhLHn4FM1x = rrqlpsSCOhLHn4FM1x[D2D96X5NGamBhrFwvL8VEbqiSfZIl].split(jL5CrsRwebpyDVXUc1EQP(u"ࠧ࠮ࠩန"))[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	MFLrboQuq72jtmOaTz8gvhD = str(FpjKBIUaEwbmLkxANfs)
	AAiROomtT6LBXpcaWPSC = sIzDXlTHYUC5L3xZGnr(u"ࠨ࡝ࡕࡘࡑࡣลึัสี้่ࠥะ์ࠣห้ษฮ๋ำࠣห้๋ส้ใิࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠢࠪပ")+WydpaVx5YmLoCiIgA34eEBlb+rrqlpsSCOhLHn4FM1x+T7ASIp1ZYwio9HQ8cObJK
	AAiROomtT6LBXpcaWPSC += vU6DxuzPwMpg(u"ࠩ࡟ࡲࡡࡴࠧဖ")+SnhLjmfeJC(u"ࠪ࡟ࡗ࡚ࡌ࡞วุำฬืࠠไ๊า๎ࠥอไั์ࠣห๋ะࠠหีอาิ๋็้๋ࠡࠤ࠿ࠦࠠࠡࠩဗ")+WydpaVx5YmLoCiIgA34eEBlb+MFLrboQuq72jtmOaTz8gvhD+T7ASIp1ZYwio9HQ8cObJK
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,KfHAW8VGbrxi(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧဘ"),AAiROomtT6LBXpcaWPSC)
	return
def QA7EfDU9MclJi():
	EExKjfVXz95AoM0Rqdv26yucBtr71Q,dh2r7D3eBYqaCTlAypRuFMSbGsE5t,NN9DqzCIAL = LhFAGlQ19zr,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	Wlf3Dw6TPrM0Ysad9I4,cgoGdPQwxjMKWC1eztVlqi,wlImCedxMXcy1NDYHvkg7qoaQA2 = LhFAGlQ19zr,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	bG6rH7snANpDE = [OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪမ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨယ"),N6NGJ4vpmidqMCh7yo(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ရ")]
	oSiV9K6kg3pRXF07Q = cDVaL376lmoAX(bG6rH7snANpDE)
	for SZvQ0Jre4BHyGVFxoPYM2IU6 in bG6rH7snANpDE:
		if SZvQ0Jre4BHyGVFxoPYM2IU6 not in list(oSiV9K6kg3pRXF07Q.keys()): continue
		AAkZvIgX4hcfMWtbK,dWkcumbLjr5AJzhIpavnowiqFZV,hhsgbw3fIeoRBELrnQucMGtTSpNXzx,RG61qOh52JP8kKIijxafHStg7Z3,Os3l9VdgEDyZamkn0HrSLW,GP1bwSUEA0H8,wwA7OjHhazmqcQ6Z2DgB = oSiV9K6kg3pRXF07Q[SZvQ0Jre4BHyGVFxoPYM2IU6]
		if SZvQ0Jre4BHyGVFxoPYM2IU6==I18uSKaWhgTBeYUPD4sr(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭လ"):
			Wlf3Dw6TPrM0Ysad9I4 = AAkZvIgX4hcfMWtbK
			cgoGdPQwxjMKWC1eztVlqi = dWkcumbLjr5AJzhIpavnowiqFZV+o1INZ3ViQqS0Uw5z6kMjbv(u"ࠩࠣࠤࠥࠦࠨࠡࠩဝ")+eJYnofQG4mc8aFiN(GP1bwSUEA0H8)+oRJAfwD957WkUyBM1Ehu8m(u"ࠪࠤ࠮࠭သ")
			wlImCedxMXcy1NDYHvkg7qoaQA2 = RG61qOh52JP8kKIijxafHStg7Z3
		elif SZvQ0Jre4BHyGVFxoPYM2IU6==QjAINyUC7MDRq5d8e4vl9(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭ဟ"):
			EExKjfVXz95AoM0Rqdv26yucBtr71Q = EExKjfVXz95AoM0Rqdv26yucBtr71Q or AAkZvIgX4hcfMWtbK
			dh2r7D3eBYqaCTlAypRuFMSbGsE5t += LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠬࠦࠠ࠭ࠢࠣࠫဠ")+dWkcumbLjr5AJzhIpavnowiqFZV+I18uSKaWhgTBeYUPD4sr(u"࠭ࠠࠡࠢࠣࠬࠥ࠭အ")+eJYnofQG4mc8aFiN(GP1bwSUEA0H8)+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧࠡࠫࠪဢ")
			NN9DqzCIAL += ssynAg0zhSkoCpOMDV9(u"ࠨࠢࠣ࠰ࠥࠦࠧဣ")+RG61qOh52JP8kKIijxafHStg7Z3
		elif SZvQ0Jre4BHyGVFxoPYM2IU6==V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨဤ"):
			kFYpDoMVu4iEzyP3jmUrRd = AAkZvIgX4hcfMWtbK
			LLN6fYdeZbIkQWS2RpP7qhrDACijc = dWkcumbLjr5AJzhIpavnowiqFZV+N6NGJ4vpmidqMCh7yo(u"ࠪࠤࠥࠦࠠࠩࠢࠪဥ")+eJYnofQG4mc8aFiN(GP1bwSUEA0H8)+ggjO5CrKVRPITaesWkxD(u"ࠫࠥ࠯ࠧဦ")
			eeczlFR9TistZ8nrxK2 = RG61qOh52JP8kKIijxafHStg7Z3
	dh2r7D3eBYqaCTlAypRuFMSbGsE5t = dh2r7D3eBYqaCTlAypRuFMSbGsE5t.strip(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠬࠦࠠ࠭ࠢࠣࠫဧ"))
	NN9DqzCIAL = NN9DqzCIAL.strip(EE1jeHnIoad(u"࠭ࠠࠡ࠮ࠣࠤࠬဨ"))
	XEA2DbhGpcl7  = PlpyFa9QMKXxOD1cvHzmI(u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅลั๎ึࠦไษำ้ห๊าฺࠠ็สำࠥอไๆฬ๋ๅึࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠤࠬဩ")+WydpaVx5YmLoCiIgA34eEBlb+wlImCedxMXcy1NDYHvkg7qoaQA2+T7ASIp1ZYwio9HQ8cObJK
	XEA2DbhGpcl7 += C0qrknitpM4Z+Gcw2nelTR864XCVruO3mAFqI5a(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆ้่ࠣอืๆศ็ฯࠤ฾๋วะ๊ࠢ์ࠥࡀࠠࠡࠢࠪဪ")+WydpaVx5YmLoCiIgA34eEBlb+cgoGdPQwxjMKWC1eztVlqi+T7ASIp1ZYwio9HQ8cObJK
	XEA2DbhGpcl7 += Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠩ࡟ࡲࡡࡴࠧါ")+OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ศิ๊าࠢ็ุ้ะ่ะ฻ࠣ฽๊อฯࠡษ็้ฯ๎แาࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠠࠨာ")+WydpaVx5YmLoCiIgA34eEBlb+NN9DqzCIAL+T7ASIp1ZYwio9HQ8cObJK
	XEA2DbhGpcl7 += C0qrknitpM4Z+Hr25gta6XcqO(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦไๆีอ์ิ฿ฺࠠ็สำࠥํ่ࠡ࠼ࠣࠤࠥ࠭ိ")+WydpaVx5YmLoCiIgA34eEBlb+dh2r7D3eBYqaCTlAypRuFMSbGsE5t+T7ASIp1ZYwio9HQ8cObJK
	XEA2DbhGpcl7 += uulNDCPyef78(u"ࠬࡢ࡮࡝ࡰࠪီ")+wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไฤะํี๊ࠥฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣห้๋ส้ใิࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠢࠪု")+WydpaVx5YmLoCiIgA34eEBlb+eeczlFR9TistZ8nrxK2+T7ASIp1ZYwio9HQ8cObJK
	XEA2DbhGpcl7 += C0qrknitpM4Z+oRJAfwD957WkUyBM1Ehu8m(u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅาํࠤฬ์สࠡฬึฮำีๅ่ࠢ็ะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬี่๊ࠠࠣ࠾ࠥࠦࠠࠨူ")+WydpaVx5YmLoCiIgA34eEBlb+LLN6fYdeZbIkQWS2RpP7qhrDACijc+T7ASIp1ZYwio9HQ8cObJK
	AAkZvIgX4hcfMWtbK = Wlf3Dw6TPrM0Ysad9I4 or EExKjfVXz95AoM0Rqdv26yucBtr71Q
	if AAkZvIgX4hcfMWtbK:
		header = wdftVMyzF17cYETHu(u"ࠨษ็ีัอมࠡฬะำ๏ัࠠฦุสๅฬะࠠไ๊า๎๊ࠥอๅࠢสฺ่๊วไๆࠪေ")
		HiguZF3b5pS4XeOMYDsTxk7QPVLUh = vU6DxuzPwMpg(u"ࠩส๊ฯࠦศฮษฯอ๊ࠥสฮัํฯࠥฮั็ษ่ะࠥ฿ๅศัࠣวํࠦสฮัํฯ๋ࠥำห๊า฽ࠥ฿ๅศัࠪဲ")
	else:
		header = ggjO5CrKVRPITaesWkxD(u"ࠪัฬ๊๊ศࠢ็หࠥ๐่อัࠣฮาี๊ฬษอࠤ้ฮั็ษ่ะࠥ฿ๅศัࠣวํࠦๅิฬ๋ำ฾ูࠦๆษาࠫဳ")
		HiguZF3b5pS4XeOMYDsTxk7QPVLUh = Hr25gta6XcqO(u"ࠫฬ๊ัอษฤࠤสฮไศ฼ࠣห้๋ศา็ฯࠤ฾์ࠠศๆุ่่๊ษࠡษ็ฮ๏ࠦส้ษฯ๋่࠭ဴ")
	jKDJaPnXqs35lhHdvwOSL = KfHAW8VGbrxi(u"๊ࠬใ๋ࠢํ฽ฺ๊๊่ࠠา็ࠥอไหฯา๎ะࠦวๅฬ็ๆฬฬ๊ࠡ์ฯฬࠥษๆࠡ์ๆ์๋ࠦไะ์ๆࠤๆ๐ࠠไ๊า๎ࡡࡴๅิฬ๋ำ฾ูࠦๆษาࠤࡊࡓࡁࡅࠢࡕࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠭ဵ")
	Swsqv2N01iQnITgrbC = XEA2DbhGpcl7+o1INZ3ViQqS0Uw5z6kMjbv(u"࠭࡜࡯࡞ࡱࠫံ")+HiguZF3b5pS4XeOMYDsTxk7QPVLUh+o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧ࡝ࡰ࡟ࡲ့ࠬ")+jKDJaPnXqs35lhHdvwOSL
	cFjMEShi6Pp0otRBgeXq8(aOQTKXFL54Nl60Zhp3MbE(u"ࠨࡴ࡬࡫࡭ࡺࠧး"),header,Swsqv2N01iQnITgrbC,LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸ္ࠬ"))
	return AAkZvIgX4hcfMWtbK
def gXY4KLGzRxk6VmfhM(SZvQ0Jre4BHyGVFxoPYM2IU6,wwA7OjHhazmqcQ6Z2DgB,showDialogs):
	ddecO3Tb9U5k = LhFAGlQ19zr
	if showDialogs:
		Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,AAbvaXV2DQzfNHdm4U3tT(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั်࠭"),s5WMHyQN4mpie(u"ุࠫ๎แࠡ์อ้ࠥอไร่ࠣะ้ฮࠠศๆ่่ๆࠦวๅ็ู฾ํ฽ࠠๅๆศฺฬ็ษࠡษ็้฼๊่ษห่่ࠣ๐๋ࠠฬ่ࠤฯัศ๋ฬ๊ࠤ฾๊้ࠡๅ๋ำ๏ࠦ࠮ࠡษ็้้็ࠠใัࠣ๎่๎ๆࠡๅห๎ึ่ࠦใัࠣ๎าะวอࠢห฽฻ࠦวๅ๊ๅฮࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬะ้๏๊ࠠศๆ่่ๆࠦวๅฤ้ࠤฤࠧࠧျ"))
		if Scj7zgGFVA83otMpwUkxhm0BLN1!=BkM54Kr7Qbqn: return LhFAGlQ19zr
	EaiJP7v6ksb5 = lxXI7yjkvd3OZ0E(wwA7OjHhazmqcQ6Z2DgB,{},showDialogs)
	if EaiJP7v6ksb5:
		i7iuDa1xCSskY = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(cRwuEXGWxj,SZvQ0Jre4BHyGVFxoPYM2IU6)
		rSOlpJAWb8Vh(i7iuDa1xCSskY,EsCplGc5N4mBuYW0RVQt6b,LhFAGlQ19zr)
		import zipfile as aMpPEAluLIkr8,io as npXqJI1LVD
		YpGk2XA13wqKDPTj8VsZta04ceiQ = npXqJI1LVD.BytesIO(EaiJP7v6ksb5)
		try:
			aREPULhkz9CGDgmsOtFyfbIAldj7Tn = aMpPEAluLIkr8.ZipFile(YpGk2XA13wqKDPTj8VsZta04ceiQ)
			aREPULhkz9CGDgmsOtFyfbIAldj7Tn.extractall(cRwuEXGWxj)
			uUqrNPcXKBoQ0slv.sleep(BkM54Kr7Qbqn)
			bEWpDHXjCBqd7aOiN6UG5k.executebuiltin(FgXzMs0YSDt(u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩြ"))
			uUqrNPcXKBoQ0slv.sleep(BkM54Kr7Qbqn)
			ddecO3Tb9U5k = ZgcKpIqT8QXNP(SZvQ0Jre4BHyGVFxoPYM2IU6)
		except: ddecO3Tb9U5k = LhFAGlQ19zr
	if showDialogs:
		if ddecO3Tb9U5k: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QjAINyUC7MDRq5d8e4vl9(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩွ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧห็ࠣฬ๋าวฮࠢอฯอ๐สࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠫှ"))
		else: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,s5WMHyQN4mpie(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫဿ"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥะหษ์อࠤฬ๊ลืษไอࠥอไๆู็์อฯࠧ၀"))
	return ddecO3Tb9U5k
def wwntyGQz2YbhoXNfMFm(SZvQ0Jre4BHyGVFxoPYM2IU6,showDialogs=EsCplGc5N4mBuYW0RVQt6b):
	if showDialogs==fy8iFgEkrO12NR9TWBI35sjY6qHvV: showDialogs = EsCplGc5N4mBuYW0RVQt6b
	acywAU3zkWCTEMf27ZYuQb50ntBi = vhV48zIDAUwyakxtndGRNj9([SZvQ0Jre4BHyGVFxoPYM2IU6])
	uuU5dEvGBKnO2lJCtIFbxkqQi06g,XcMGsyPBSJqr35bpwke2jQY = acywAU3zkWCTEMf27ZYuQb50ntBi[SZvQ0Jre4BHyGVFxoPYM2IU6]
	if XcMGsyPBSJqr35bpwke2jQY:
		ddecO3Tb9U5k = EsCplGc5N4mBuYW0RVQt6b
		if showDialogs: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,uulNDCPyef78(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭၁"),SnhLjmfeJC(u"ࠫๆำีࠡษ็ษ฻อแสࠢ࡟ࡲࠥ࠭၂")+SZvQ0Jre4BHyGVFxoPYM2IU6+C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬࠦ࡜࡯๊ࠢิ์ࠦรๅวูหๆฯฺ่ࠠา็๋่ࠥอ๊าอࠥ๎ๅโ฻็อࠥ๎ฬศ้ีอ๊ࠥไศีอาิอๅࠨ၃"))
	else:
		ddecO3Tb9U5k = LhFAGlQ19zr
		Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠭ࡣࡦࡰࡷࡩࡷ࠭၄"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,AAbvaXV2DQzfNHdm4U3tT(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ၅"),fy8iFgEkrO12NR9TWBI35sjY6qHvV+SZvQ0Jre4BHyGVFxoPYM2IU6+Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠨࠢ࡟ࡲࡡࡴ่ࠠา๊ࠤศ๊ลืษไอࠥ฿ๆะๅࠣ฾๏ืࠠๆใ฼่ฮࠦร้ࠢ฽๎ึࠦๅ้ฮ๋ำฮ่ࠦศๆหี๋อๅอࠢหัฬาษࠡๆ๊หࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬฮฬ๏ะ้ࠠฬไ฽๏๊่ࠠา๊ࠤฬ๊ลืษไอࠥอไร่ࠣรࠬ၆"))
		if Scj7zgGFVA83otMpwUkxhm0BLN1==o1INZ3ViQqS0Uw5z6kMjbv(u"࠷ᅇ"):
			bEWpDHXjCBqd7aOiN6UG5k.executebuiltin(sIzDXlTHYUC5L3xZGnr(u"ࠩࡌࡲࡸࡺࡡ࡭࡮ࡄࡨࡩࡵ࡮ࠩࠩ၇")+SZvQ0Jre4BHyGVFxoPYM2IU6+sIzDXlTHYUC5L3xZGnr(u"ࠪ࠭ࠬ၈"))
			uUqrNPcXKBoQ0slv.sleep(ssynAg0zhSkoCpOMDV9(u"࠱ᅈ"))
			bEWpDHXjCBqd7aOiN6UG5k.executebuiltin(s5WMHyQN4mpie(u"ࠫࡘ࡫࡮ࡥࡅ࡯࡭ࡨࡱࠨ࠲࠳ࠬࠫ၉"))
			uUqrNPcXKBoQ0slv.sleep(O3OVuapf0YFjbm5oUQDg(u"࠲ᅉ"))
			while bEWpDHXjCBqd7aOiN6UG5k.getCondVisibility(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬ࡝ࡩ࡯ࡦࡲࡻ࠳ࡏࡳࡂࡥࡷ࡭ࡻ࡫ࠨࡱࡴࡲ࡫ࡷ࡫ࡳࡴࡦ࡬ࡥࡱࡵࡧࠪࠩ၊")): uUqrNPcXKBoQ0slv.sleep(sIzDXlTHYUC5L3xZGnr(u"࠳ᅊ"))
			ddecO3Tb9U5k = ZgcKpIqT8QXNP(SZvQ0Jre4BHyGVFxoPYM2IU6)
			if showDialogs and ddecO3Tb9U5k: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,vU6DxuzPwMpg(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ။"),KfHAW8VGbrxi(u"ࠧห็ࠣๅา฻ࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠣ์์๐ࠠศๆล๊ࠥาว่ิฬࠤ้๊วิฬัำฬ๋ࠧ၌"))
			elif showDialogs: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,FgXzMs0YSDt(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ၍"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠩไุ้ࠦแ๋ࠢอฯอ๐สࠡล๋ࠤฯ็ู๋ๆࠣวํࠦสฮัํฯࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษࠡ࠰ࠣ์ฬ๊อๅ๊ࠢ์ࠥะหษ์อ๋ฬ่ࠦหใ฼๎้ํวࠡ็้ࠤำอัอࠢส่อืๆศ็ฯࠫ၎"))
	return ddecO3Tb9U5k
def YHKRJQq1sD6yz(showDialogs):
	if not showDialogs: Scj7zgGFVA83otMpwUkxhm0BLN1 = EsCplGc5N4mBuYW0RVQt6b
	else: Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(oRJAfwD957WkUyBM1Ehu8m(u"ࠪࡧࡪࡴࡴࡦࡴࠪ၏"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ggjO5CrKVRPITaesWkxD(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧၐ"),FmYoGejTnwKME7d9zPc(u"ࠬฮั็ษ่ะ้่ࠥะ์ࠣ๎็๎ๅࠡส฼้้๐ษࠡฬะำ๏ัࠠอ็ํ฽ࠥอไฦุสๅฬะࠠหๆๅหห๐วࠡๅ็ࠤ࠷࠺ࠠิษ฼อࠥ๎ไไ่้๊้ࠣๆࠡวฯีฬว็ศࠢส่ว์ࠠ࠯๊่ࠢࠥะั๋ัࠣห้ศๆࠡล้ࠤฯ฽ไษ่๊้่ࠢࠥะ์ࠣๅา฻้ࠠฬะำ๏ัࠠอ็ํ฽ࠥอไฦุสๅฬะࠠภࠩၑ"))
	if Scj7zgGFVA83otMpwUkxhm0BLN1==Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠴ᅋ"):
		bEWpDHXjCBqd7aOiN6UG5k.executebuiltin(vU6DxuzPwMpg(u"࠭ࡕࡱࡦࡤࡸࡪࡇࡤࡥࡱࡱࡖࡪࡶ࡯ࡴࠩၒ"))
		if showDialogs:
			GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪၓ"),FmYoGejTnwKME7d9zPc(u"ࠨฬ่ࠤสืำศๆࠣ฻้ฮࠠฦๆ์ࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢส่ี๐ࠠโ์ࠣะ์อาไࠢ็็๏๊ࠦใ๊่ࠤอะอะ์ฮࠤัฺ๋๊ࠢศฺฬ็วหࠢๆ์ิ๐ࠠ࠯ࠢห้ฬࠦแ๋้สࠤฯำฯ๋อ๋ࠣีอࠠศๆหี๋อๅอ๋ࠢฮาี๊ฬ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠ࠯ࠢํีั๏ࠠฦ฻ฺหฦࠦใ้ัํࠤ࠺ࠦฯใษษๆࠥษ่ࠡลๆฯึࠦไไ์ࠣ๎๋ํ๊ࠡ฻่่๏ฯࠠศๆอัิ๐หࠨၔ"))
	return
def kc58wNCXd79rl1xS3ZBKfUjPm0Tby():
	gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,ggjO5CrKVRPITaesWkxD(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬၕ"),ggjO5CrKVRPITaesWkxD(u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫၖ"))
	kkx4hCedgWn2lI15bTzHaD()
	AAkZvIgX4hcfMWtbK = QA7EfDU9MclJi()
	if AAkZvIgX4hcfMWtbK:
		mcPDrqAL95GBTaZfUtgvF0WM(EsCplGc5N4mBuYW0RVQt6b)
		YHKRJQq1sD6yz(EsCplGc5N4mBuYW0RVQt6b)
		ejX7kGtQ4hcYUHW9b31vriuZLM6Sp(LhFAGlQ19zr)
	return
def ZgcKpIqT8QXNP(SZvQ0Jre4BHyGVFxoPYM2IU6):
	OmsWt89dSA5HyCZ4wL = bEWpDHXjCBqd7aOiN6UG5k.executeJSONRPC(CsDcLqQUVK4YBvHFW1(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡅࡩࡪ࡯࡯ࡵ࠱ࡗࡪࡺࡁࡥࡦࡲࡲࡊࡴࡡࡣ࡮ࡨࡨࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡥࡩࡪ࡯࡯࡫ࡧࠦ࠿ࠨࠧၗ")+SZvQ0Jre4BHyGVFxoPYM2IU6+Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠬࠨࠬࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡸࡷࡻࡥࡾࡿࠪၘ"))
	succeeded = EsCplGc5N4mBuYW0RVQt6b if AAbvaXV2DQzfNHdm4U3tT(u"࠭ࡏࡌࠩၙ") in OmsWt89dSA5HyCZ4wL else LhFAGlQ19zr
	return succeeded
def ln7YdRNkJ3xDW(SZvQ0Jre4BHyGVFxoPYM2IU6):
	OmsWt89dSA5HyCZ4wL = bEWpDHXjCBqd7aOiN6UG5k.executeJSONRPC(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡁࡥࡦࡲࡲࡸ࠴ࡓࡦࡶࡄࡨࡩࡵ࡮ࡆࡰࡤࡦࡱ࡫ࡤࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡡࡥࡦࡲࡲ࡮ࡪࠢ࠻ࠤࠪၚ")+SZvQ0Jre4BHyGVFxoPYM2IU6+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠨࠤ࠯ࠦࡪࡴࡡࡣ࡮ࡨࡨࠧࡀࡦࡢ࡮ࡶࡩࢂࢃࠧၛ"))
	succeeded = EsCplGc5N4mBuYW0RVQt6b if aOQTKXFL54Nl60Zhp3MbE(u"ࠩࡒࡏࠬၜ") in OmsWt89dSA5HyCZ4wL else LhFAGlQ19zr
	return succeeded
def ElFY9uVGWzyB4TZ6dpjg3shv(SZvQ0Jre4BHyGVFxoPYM2IU6,showDialogs,rZUPTv2blhCK7zm1EuDtY,oSiV9K6kg3pRXF07Q=None):
	Scj7zgGFVA83otMpwUkxhm0BLN1,succeeded,H9DQpd06Of,dWkcumbLjr5AJzhIpavnowiqFZV = EsCplGc5N4mBuYW0RVQt6b,LhFAGlQ19zr,N6NGJ4vpmidqMCh7yo(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪၝ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if not oSiV9K6kg3pRXF07Q: oSiV9K6kg3pRXF07Q = cDVaL376lmoAX([SZvQ0Jre4BHyGVFxoPYM2IU6])
	if SZvQ0Jre4BHyGVFxoPYM2IU6 in list(oSiV9K6kg3pRXF07Q.keys()):
		AAkZvIgX4hcfMWtbK,dWkcumbLjr5AJzhIpavnowiqFZV,hhsgbw3fIeoRBELrnQucMGtTSpNXzx,RG61qOh52JP8kKIijxafHStg7Z3,Os3l9VdgEDyZamkn0HrSLW,GP1bwSUEA0H8,wwA7OjHhazmqcQ6Z2DgB = oSiV9K6kg3pRXF07Q[SZvQ0Jre4BHyGVFxoPYM2IU6]
		if GP1bwSUEA0H8==Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫ࡬ࡵ࡯ࡥࠩၞ"):
			succeeded,H9DQpd06Of = EsCplGc5N4mBuYW0RVQt6b,jL5CrsRwebpyDVXUc1EQP(u"ࠬࡴ࡯ࡵࡪ࡬ࡲ࡬࠭ၟ")
			if rZUPTv2blhCK7zm1EuDtY and showDialogs:
				Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,oRJAfwD957WkUyBM1Ehu8m(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩၠ"),Hr25gta6XcqO(u"ࠧอ์าࠤัีวࠡ࠰࠱ࠤ่๎ฯ๋ࠢํืฯิฯๆࠢฦาึࠦลึัสี๋ࠥส้ใิࠤๆ๐ࠠๆ๊สๆ฾ࠦๅิฬ๋ำ฾ูࠦๆษาࠤ้ํะ่ࠢส่ส฼วโห࡟ࡲࡡࡴࠧၡ")+SZvQ0Jre4BHyGVFxoPYM2IU6+FgXzMs0YSDt(u"ࠨ࡞ࡱࡠࡳํไࠡฬิ๎ิࠦลฺษาอࠥะหษ์อࠤ์ึ็ࠡษ็ษ฻อแส่ࠢีฮࠦรฯำ์ࠫၢ"))
				if Scj7zgGFVA83otMpwUkxhm0BLN1:
					succeeded = gXY4KLGzRxk6VmfhM(SZvQ0Jre4BHyGVFxoPYM2IU6,wwA7OjHhazmqcQ6Z2DgB,LhFAGlQ19zr)
					if succeeded:
						H9DQpd06Of = I18uSKaWhgTBeYUPD4sr(u"ࠩࡵࡩ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠧၣ")
						if showDialogs: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ggjO5CrKVRPITaesWkxD(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ၤ"),AAbvaXV2DQzfNHdm4U3tT(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢๆห๋ะࠠๆ๊ฯ์ิฯࠠ࠯࠰ࠣ์็อๅࠡษ็ฬึ์วๆฮࠣฬส฿วะหࠣฮะฮ๊ห้สࡠࡳࡢ࡮ࠨၥ")+SZvQ0Jre4BHyGVFxoPYM2IU6)
					else:
						H9DQpd06Of = Gcw2nelTR864XCVruO3mAFqI5a(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬၦ")
						GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,oRJAfwD957WkUyBM1Ehu8m(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩၧ"),vU6DxuzPwMpg(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢส่อืๆศ็ฯࠤ้๋๋ࠠีอ฻๏฿ࠠฦ฻สำฮࠦสฬสํฮࠥํะ่ࠢส่ส฼วโห࡟ࡲࡡࡴࠧၨ")+SZvQ0Jre4BHyGVFxoPYM2IU6)
		else:
			if showDialogs:
				if GP1bwSUEA0H8==QjAINyUC7MDRq5d8e4vl9(u"ࠨࡦ࡬ࡷࡦࡨ࡬ࡦࡦࠪၩ"): kf40tulvSA7z9RqNF5dXca3seMD = EE1jeHnIoad(u"่ࠩฮํ่แสࠩၪ")
				elif GP1bwSUEA0H8==s5WMHyQN4mpie(u"ࠪࡳࡱࡪࠧၫ"): kf40tulvSA7z9RqNF5dXca3seMD = Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠫ็ี๊ๆหࠪၬ")
				elif GP1bwSUEA0H8==LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠬࡳࡩࡴࡵ࡬ࡲ࡬࠭ၭ"): kf40tulvSA7z9RqNF5dXca3seMD = OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ฺ๋࠭ำ้ࠣะฮสสࠩၮ")
				Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,KfHAW8VGbrxi(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪၯ"),AAbvaXV2DQzfNHdm4U3tT(u"ࠨ้ำ๋ࠥอไฦุสๅฮࠦࠧၰ")+kf40tulvSA7z9RqNF5dXca3seMD+aOQTKXFL54Nl60Zhp3MbE(u"ࠩࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠฦื็หาࠦ็ั้ࠣห้๋ิไๆฬࠤฤࠧ࡜࡯࡞ࡱࠫၱ")+SZvQ0Jre4BHyGVFxoPYM2IU6)
			if not Scj7zgGFVA83otMpwUkxhm0BLN1: H9DQpd06Of = O3OVuapf0YFjbm5oUQDg(u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࠬၲ")
			else:
				if GP1bwSUEA0H8==ggjO5CrKVRPITaesWkxD(u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠭ၳ"):
					succeeded = ZgcKpIqT8QXNP(SZvQ0Jre4BHyGVFxoPYM2IU6)
					if succeeded:
						H9DQpd06Of = QjAINyUC7MDRq5d8e4vl9(u"ࠬ࡫࡮ࡢࡤ࡯ࡩࡩ࠭ၴ")
						if showDialogs: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Hr25gta6XcqO(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩၵ"),uulNDCPyef78(u"ࠧอ์าࠤัีวࠡ࠰࠱ࠤฬ๊ลืษไอ้ࠥว็ฬ้ࠣฯ๎โโหࠣ࠲࠳่ࠦใษ่ࠤฬ๊ศา่ส้ัࠦศหึ฽๎้ํว࡝ࡰ࡟ࡲࠬၶ")+SZvQ0Jre4BHyGVFxoPYM2IU6)
					elif showDialogs: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,aOQTKXFL54Nl60Zhp3MbE(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫၷ"),I18uSKaWhgTBeYUPD4sr(u"ࠩ็่ศูแࠡ࠰࠱ࠤฬ๊ลืษไอ๋ࠥส้ไไอࠥ࠴࠮๊ࠡ็้ࠥ๐ำหูํ฽ࠥอไษำ้ห๊าࠠหึ฽๎้ํว࡝ࡰ࡟ࡲࠬၸ")+SZvQ0Jre4BHyGVFxoPYM2IU6)
				elif GP1bwSUEA0H8 in [OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪࡳࡱࡪࠧၹ"),jL5CrsRwebpyDVXUc1EQP(u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬၺ")]:
					succeeded = gXY4KLGzRxk6VmfhM(SZvQ0Jre4BHyGVFxoPYM2IU6,wwA7OjHhazmqcQ6Z2DgB,LhFAGlQ19zr)
					if succeeded:
						if GP1bwSUEA0H8==QjAINyUC7MDRq5d8e4vl9(u"ࠬࡵ࡬ࡥࠩၻ"): H9DQpd06Of = Hr25gta6XcqO(u"࠭ࡵࡱࡦࡤࡸࡪࡪࠧၼ")
						elif GP1bwSUEA0H8==QjAINyUC7MDRq5d8e4vl9(u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨၽ"): H9DQpd06Of = sJw9QWiq1Kr0xfeVRI(u"ࠨ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠫၾ")
						dWkcumbLjr5AJzhIpavnowiqFZV = RG61qOh52JP8kKIijxafHStg7Z3
						if showDialogs:
							if H9DQpd06Of==vU6DxuzPwMpg(u"ࠩࡸࡴࡩࡧࡴࡦࡦࠪၿ"): GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ႀ"),sJw9QWiq1Kr0xfeVRI(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢๆห๋ะࠠใัํ้ฮࠦ࠮࠯๋ࠢห้ฮั็ษ่ะ่ࠥวๆࠢหฮาี๊ฬ้สࡠࡳࡢ࡮ࠨႁ")+SZvQ0Jre4BHyGVFxoPYM2IU6)
							elif H9DQpd06Of==jL5CrsRwebpyDVXUc1EQP(u"ࠬ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠨႂ"): GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,vU6DxuzPwMpg(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩႃ"),AAbvaXV2DQzfNHdm4U3tT(u"ࠧอ์าࠤัีวࠡ࠰࠱ࠤฬ๊ลืษไอ๊ࠥๅࠡฬๆ๊๋่ࠥอ๊าอࠥ็๊ࠡๅ๋ำ๏ࠦ࠮࠯๋ࠢห้ฮั็ษ่ะ่ࠥวๆࠢหฮะฮ๊ห้สࡠࡳࡢ࡮ࠨႄ")+SZvQ0Jre4BHyGVFxoPYM2IU6)
					elif showDialogs: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Gcw2nelTR864XCVruO3mAFqI5a(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫႅ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩ็่ศูแࠡ࠰࠱ࠤฬ๊ศา่ส้ัࠦไๆࠢํืฯ฽ฺ๊ࠢอัิ๐หࠡล๋ࠤฯัศ๋ฬ๋ࠣีํࠠศๆศฺฬ็ษ࡝ࡰ࡟ࡲࠬႆ")+SZvQ0Jre4BHyGVFxoPYM2IU6)
	elif showDialogs: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ႇ"),SnhLjmfeJC(u"้๊ࠫริใࠣ࠲࠳ࠦ็ั้ࠣห้หึศใฬࠤ฿๐ัࠡ็๋ะํีษࠡใํࠤู๊ส้ั฼ࠤ฾๋วะࠢ࠱࠲ࠥ๎ไ่าสࠤ้อ๋ࠠีอ฻๏฿ࠠศๆหี๋อๅอࠢฦ๊ࠥ๐โ้็ࠣฬฯัศ๋ฬ๋ࠣีํࠠศๆศฺฬ็ษࠡล๋ࠤฯำฯ๋อ๊หࡡࡴ࡜࡯ࠩႈ")+SZvQ0Jre4BHyGVFxoPYM2IU6)
	return succeeded,H9DQpd06Of,dWkcumbLjr5AJzhIpavnowiqFZV
def E0huTeDPIjbtcHflCxMdSqskVUX7w(SZvQ0Jre4BHyGVFxoPYM2IU6,showDialogs,MIDTu0YWCo7BOqwm4VZ):
	s3iuzBrnf6WNMgQSOYa1qlVtydKxT = GUpSgLmFJc2T5B6DRxtlN9KXHIYP.connect(al4SYe7CV19g)
	s3iuzBrnf6WNMgQSOYa1qlVtydKxT.text_factory = str
	aaLcdPtZmTG4ir = s3iuzBrnf6WNMgQSOYa1qlVtydKxT.cursor()
	succeeded,NeB6dVTMURE72049qu = EsCplGc5N4mBuYW0RVQt6b,LhFAGlQ19zr
	try:
		ttA8CzRpM2naKmhwdSUrefbWoklHs = EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧႉ")
		aaLcdPtZmTG4ir.execute(Hr25gta6XcqO(u"࠭ࡓࡆࡎࡈࡇ࡙ࠦ࡯ࡳ࡫ࡪ࡭ࡳࠦࡆࡓࡑࡐࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫႊ")+SZvQ0Jre4BHyGVFxoPYM2IU6+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧࠣࠢ࠾ࠫႋ"))
		munF8zxEdJ3 = aaLcdPtZmTG4ir.fetchall()
		if munF8zxEdJ3 and ttA8CzRpM2naKmhwdSUrefbWoklHs not in str(munF8zxEdJ3): aaLcdPtZmTG4ir.execute(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠨࡗࡓࡈࡆ࡚ࡅࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤࡘࡋࡔࠡࡱࡵ࡭࡬࡯࡮ࠡ࠿ࠣࠦࠬႌ")+ttA8CzRpM2naKmhwdSUrefbWoklHs+AAbvaXV2DQzfNHdm4U3tT(u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨႍ")+SZvQ0Jre4BHyGVFxoPYM2IU6+OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪࠦࠥࡁࠧႎ"))
		cH4jo52weYnhUTMkZFB9DQI1OSyNsG = oRJAfwD957WkUyBM1Ehu8m(u"ࠫࡧࡲࡡࡤ࡭࡯࡭ࡸࡺࠧႏ") if gZlSEJaXO9F461AL3sR7rWNpqf else I18uSKaWhgTBeYUPD4sr(u"ࠬࡻࡰࡥࡣࡷࡩࡤࡸࡵ࡭ࡧࡶࠫ႐")
		aaLcdPtZmTG4ir.execute(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࠪࠡࡈࡕࡓࡒࠦࠧ႑")+cH4jo52weYnhUTMkZFB9DQI1OSyNsG+N6NGJ4vpmidqMCh7yo(u"࡙ࠧࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ႒")+SZvQ0Jre4BHyGVFxoPYM2IU6+ggjO5CrKVRPITaesWkxD(u"ࠨࠤࠣ࠿ࠬ႓"))
		munF8zxEdJ3 = aaLcdPtZmTG4ir.fetchall()
		if munF8zxEdJ3:
			if showDialogs: Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,jL5CrsRwebpyDVXUc1EQP(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ႔"),jL5CrsRwebpyDVXUc1EQP(u"ࠪห้ะอะ์ฮࠤฬ๊ร้ฬ๋้ฬะ๊ไ์่ࠣส฼วโหࠣࡠࡳࠦࠧ႕")+SZvQ0Jre4BHyGVFxoPYM2IU6+LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠫࠥࡢ࡮࡝ࡰࠣࠫ႖")+n0nFOd4yR97fQzNLSW+AAbvaXV2DQzfNHdm4U3tT(u"ࠬࠦๅห๊ๅๅࠥ๎ไศࠢํ฽๊๊ࠠ࠯࠰๋้ࠣࠦสา์าࠤฯ็ู๋ๆ๊ࠤฬ๊ย็ࠢยࠥࠦࠦࠧ႗")+T7ASIp1ZYwio9HQ8cObJK+CsDcLqQUVK4YBvHFW1(u"࠭ࠠ࡝ࡰ࡟ࡲࠥะำหูํ฽ࠥห๊ใษไ๋ࠥฮำ่๊็อࠥ฿ๆะࠢส่฾๎ฯสࠢศ่๎ࠦ็ั้ࠣหฺ้วีหࠣห้๋่อ๊าอࠥ็๊ࠡไสส๊ฯࠠฯั่หฯࠦศา่ส้ัูࠦๆษาࠫ႘"))
			else: Scj7zgGFVA83otMpwUkxhm0BLN1 = BkM54Kr7Qbqn
			if Scj7zgGFVA83otMpwUkxhm0BLN1==BkM54Kr7Qbqn:
				NeB6dVTMURE72049qu = EsCplGc5N4mBuYW0RVQt6b
				aaLcdPtZmTG4ir.execute(PlpyFa9QMKXxOD1cvHzmI(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥ࠭႙")+cH4jo52weYnhUTMkZFB9DQI1OSyNsG+SnhLjmfeJC(u"ࠨ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭ႚ")+SZvQ0Jre4BHyGVFxoPYM2IU6+LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠩࠥࠤࡀ࠭ႛ"))
		elif MIDTu0YWCo7BOqwm4VZ:
			if showDialogs: Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ႜ"),jL5CrsRwebpyDVXUc1EQP(u"ࠫฬ๊สฮัํฯࠥอไฤ๊อ์๊อส๋ๅํࠤ้หึศใฬࠤࡡࡴࠠࠨႝ")+SZvQ0Jre4BHyGVFxoPYM2IU6+aOQTKXFL54Nl60Zhp3MbE(u"ࠬࠦ࡜࡯࡞ࡱࠤࠬ႞")+n0nFOd4yR97fQzNLSW+AAbvaXV2DQzfNHdm4U3tT(u"࠭ࠠๆใ฼่ࠥ๎ฺ๊็็ࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡวํๆฬ็็ࠡษ็ฦ๋ࠦฟࠢࠣࠣࠫ႟")+T7ASIp1ZYwio9HQ8cObJK+jL5CrsRwebpyDVXUc1EQP(u"ࠧࠡ࡞ࡱࡠࡳࠦสิฬฺ๎฾ࠦสโ฻ํ่์ࠦศิ้๋่ฮูࠦ็ัࠣห้฿่ะหࠣษ้๏่ࠠา๊ࠤฬ๊ิศึฬࠤฬ๊ๅ้ฮ๋ำฮࠦแ๋ࠢๅหห๋ษࠡะา้ฬะࠠษำ้ห๊าฺࠠ็สำࠬႠ"))
			else: Scj7zgGFVA83otMpwUkxhm0BLN1 = BkM54Kr7Qbqn
			if Scj7zgGFVA83otMpwUkxhm0BLN1==BkM54Kr7Qbqn:
				NeB6dVTMURE72049qu = EsCplGc5N4mBuYW0RVQt6b
				if gZlSEJaXO9F461AL3sR7rWNpqf: aaLcdPtZmTG4ir.execute(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠧႡ")+cH4jo52weYnhUTMkZFB9DQI1OSyNsG+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠩࠣࠬࡦࡪࡤࡰࡰࡌࡈ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩႢ")+SZvQ0Jre4BHyGVFxoPYM2IU6+OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪࠦ࠮ࠦ࠻ࠨႣ"))
				else: aaLcdPtZmTG4ir.execute(ggjO5CrKVRPITaesWkxD(u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠪႤ")+cH4jo52weYnhUTMkZFB9DQI1OSyNsG+sJw9QWiq1Kr0xfeVRI(u"ࠬࠦࠨࡢࡦࡧࡳࡳࡏࡄ࠭ࡷࡳࡨࡦࡺࡥࡓࡷ࡯ࡩ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩႥ")+SZvQ0Jre4BHyGVFxoPYM2IU6+oRJAfwD957WkUyBM1Ehu8m(u"࠭ࠢ࠭࠳ࠬࠤࡀ࠭Ⴆ"))
	except: succeeded = LhFAGlQ19zr
	s3iuzBrnf6WNMgQSOYa1qlVtydKxT.commit()
	s3iuzBrnf6WNMgQSOYa1qlVtydKxT.close()
	if NeB6dVTMURE72049qu:
		uUqrNPcXKBoQ0slv.sleep(SnhLjmfeJC(u"࠵ᅌ"))
		bEWpDHXjCBqd7aOiN6UG5k.executebuiltin(QjAINyUC7MDRq5d8e4vl9(u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫႧ"))
		uUqrNPcXKBoQ0slv.sleep(AAbvaXV2DQzfNHdm4U3tT(u"࠶ᅍ"))
		if showDialogs:
			if succeeded: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,PlpyFa9QMKXxOD1cvHzmI(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫႨ"),ggjO5CrKVRPITaesWkxD(u"้ࠩะาะฺࠠ็็๎ฮࠦลึๆสัࠥะอะ์ฮࠤฬ๊ลืษไอࠥࡢ࡮࡝ࡰࠪႩ")+SZvQ0Jre4BHyGVFxoPYM2IU6)
			else: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭Ⴊ"),EE1jeHnIoad(u"ࠫๆฺไหࠢ฼้้๐ษࠡวุ่ฬำࠠหฯา๎ะࠦวๅวูหๆฯࠠ࡝ࡰ࡟ࡲࠬႫ")+SZvQ0Jre4BHyGVFxoPYM2IU6)
	return NeB6dVTMURE72049qu
def kzN0bPLcDgGyJfCjOWRK3pF5VqI(bG6rH7snANpDE,showDialogs,rZUPTv2blhCK7zm1EuDtY,MIDTu0YWCo7BOqwm4VZ):
	oSiV9K6kg3pRXF07Q = cDVaL376lmoAX(bG6rH7snANpDE)
	XfzpmBZHbEVAk4TelhwgFM = LhFAGlQ19zr
	for SZvQ0Jre4BHyGVFxoPYM2IU6 in bG6rH7snANpDE:
		succeeded,H9DQpd06Of,dWkcumbLjr5AJzhIpavnowiqFZV = ElFY9uVGWzyB4TZ6dpjg3shv(SZvQ0Jre4BHyGVFxoPYM2IU6,showDialogs,rZUPTv2blhCK7zm1EuDtY,oSiV9K6kg3pRXF07Q)
		NeB6dVTMURE72049qu = E0huTeDPIjbtcHflCxMdSqskVUX7w(SZvQ0Jre4BHyGVFxoPYM2IU6,showDialogs,MIDTu0YWCo7BOqwm4VZ)
		if NeB6dVTMURE72049qu: XfzpmBZHbEVAk4TelhwgFM = EsCplGc5N4mBuYW0RVQt6b
	if XfzpmBZHbEVAk4TelhwgFM:
		uUqrNPcXKBoQ0slv.sleep(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠷ᅎ"))
		bEWpDHXjCBqd7aOiN6UG5k.executebuiltin(Hr25gta6XcqO(u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩႬ"))
		uUqrNPcXKBoQ0slv.sleep(I18uSKaWhgTBeYUPD4sr(u"࠱ᅏ"))
	if showDialogs:
		if len(bG6rH7snANpDE)>AAbvaXV2DQzfNHdm4U3tT(u"࠲ᅐ"): GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,s5WMHyQN4mpie(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩႭ"),oRJAfwD957WkUyBM1Ehu8m(u"ࠧห็ࠣฬ๋าวฮࠢไัฺࠦฬๆ์฼ࠤฬ๊ลืษไหฯ࠭Ⴎ"))
		else: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,AAbvaXV2DQzfNHdm4U3tT(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫႯ"),vU6DxuzPwMpg(u"ࠩอ้ࠥฮๆอษะࠤๆำีࠡษ็ษ฻อแส࡞ࡱࡠࡳ࠭Ⴐ")+bG6rH7snANpDE[KfHAW8VGbrxi(u"࠲ᅑ")])
	return
def mcPDrqAL95GBTaZfUtgvF0WM(showDialogs):
	cT4ibRDhn9zdAZE = [sJw9QWiq1Kr0xfeVRI(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨႱ"),FgXzMs0YSDt(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭Ⴒ"),Gcw2nelTR864XCVruO3mAFqI5a(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠩႳ"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡵ࠯ࡧࡰࡵ࠭Ⴔ")]
	EEf2oKQWATVCY8Umz59ts = [CsDcLqQUVK4YBvHFW1(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡲࡸ࡭࡫ࡲࡴࠩႵ"),FmYoGejTnwKME7d9zPc(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡥࡦࠩႶ"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩࠬႷ"),s5WMHyQN4mpie(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡪࡸࡦࠬႸ"),sIzDXlTHYUC5L3xZGnr(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡧࡪࡶࡨࡥࠬႹ"),sIzDXlTHYUC5L3xZGnr(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡤࡱࡧࡩࡧ࡫ࡲࡨࠩႺ")]
	for SZvQ0Jre4BHyGVFxoPYM2IU6 in EEf2oKQWATVCY8Umz59ts: ln7YdRNkJ3xDW(SZvQ0Jre4BHyGVFxoPYM2IU6)
	kzN0bPLcDgGyJfCjOWRK3pF5VqI(cT4ibRDhn9zdAZE,showDialogs,LhFAGlQ19zr,LhFAGlQ19zr)
	return
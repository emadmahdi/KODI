# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'DAILYMOTION'
K2l9rLfvoXxyZ4NYapO = '_DLM_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
rrkyXDFoKTYtf = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][1]
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text,type,jmI9qRnVJo2a3tpcH8gfYkP):
	if	 mode==400: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==401: OmsWt89dSA5HyCZ4wL = mYWJBG2nSCUjiAkEsu0ztwvVgdN4(url,text)
	elif mode==402: OmsWt89dSA5HyCZ4wL = juJ7zoTh3b6FNwqZK8MynaAUeCLD5(url,text)
	elif mode==403: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url,text)
	elif mode==404: OmsWt89dSA5HyCZ4wL = T27TaXrP8oF(text,jmI9qRnVJo2a3tpcH8gfYkP)
	elif mode==405: OmsWt89dSA5HyCZ4wL = GKR8sjtTDCm07hzE9XIlkv6goLxJN1(text,jmI9qRnVJo2a3tpcH8gfYkP)
	elif mode==406: OmsWt89dSA5HyCZ4wL = IrkDUzeGmjwiLEcHh1gRsfWJNT8F(text,jmI9qRnVJo2a3tpcH8gfYkP)
	elif mode==407: OmsWt89dSA5HyCZ4wL = A1S0layzKtb(url,jmI9qRnVJo2a3tpcH8gfYkP)
	elif mode==408: OmsWt89dSA5HyCZ4wL = GeiMAr3vZQSYh5XDjtfmcz1(url,jmI9qRnVJo2a3tpcH8gfYkP)
	elif mode==409: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text,jmI9qRnVJo2a3tpcH8gfYkP)
	elif mode==411: OmsWt89dSA5HyCZ4wL = W5W21L3Hl8JZpAYSuoKRqEI6xegTCm(url,text)
	elif mode==414: OmsWt89dSA5HyCZ4wL = zOZUbkxaEg8QqSC6GBXtpHLfmys5dW(text)
	elif mode==415: OmsWt89dSA5HyCZ4wL = mXHYruWapVeAiSFqGQ(text,jmI9qRnVJo2a3tpcH8gfYkP)
	elif mode==416: OmsWt89dSA5HyCZ4wL = Rlz9d5n1csuHWZFQAbB(text,jmI9qRnVJo2a3tpcH8gfYkP)
	elif mode==417: OmsWt89dSA5HyCZ4wL = pcuHbPWkilFVQnI7vJ(url,jmI9qRnVJo2a3tpcH8gfYkP)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الرئيسية',fy8iFgEkrO12NR9TWBI35sjY6qHvV,414)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,409,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث عن فيديوهات',fy8iFgEkrO12NR9TWBI35sjY6qHvV,409,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'videos?sortBy=','_REMEMBERRESULTS_')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث عن آخر الفيديوهات',fy8iFgEkrO12NR9TWBI35sjY6qHvV,409,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'videos?sortBy=RECENT','_REMEMBERRESULTS_')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث عن الفيديوهات الأكثر مشاهدة',fy8iFgEkrO12NR9TWBI35sjY6qHvV,409,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث عن قوائم التشغيل',fy8iFgEkrO12NR9TWBI35sjY6qHvV,409,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'playlists','_REMEMBERRESULTS_')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث عن مستخدم',fy8iFgEkrO12NR9TWBI35sjY6qHvV,409,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'channels','_REMEMBERRESULTS_')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث عن بث حي',fy8iFgEkrO12NR9TWBI35sjY6qHvV,409,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'lives','_REMEMBERRESULTS_')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث عن هاشتاك',fy8iFgEkrO12NR9TWBI35sjY6qHvV,409,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'hashtags','_REMEMBERRESULTS_')
	return
def juJ7zoTh3b6FNwqZK8MynaAUeCLD5(url,qiKhapruYTQv6oyVW7S):
	if '/dm_' in url:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,False,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = E6ECvznP9m5sWFMu.headers
		if 'Location' in list(headers.keys()): url = BOI3t1w8qfHAb0Kl4oMye7haEWS+headers['Location']
	qiKhapruYTQv6oyVW7S = n0nFOd4yR97fQzNLSW+qiKhapruYTQv6oyVW7S+T7ASIp1ZYwio9HQ8cObJK
	qiKhapruYTQv6oyVW7S = WkqGmXNMtE52jucsnZ(qiKhapruYTQv6oyVW7S)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+':: بث حي',url,411,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'channel_lives_now')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+':: آخر الفيديوهات',url+'/videos',408)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+':: المميزة',url,411,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'channel_featured_videos')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+':: قوائم التشغيل',url+'/playlists',407)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+':: قنوات ذات صلة',url,411,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'channel_related_channel')
	return
def WkqGmXNMtE52jucsnZ(title):
	title = title.rstrip('\\').strip(ksJdoFWhxTz8Y2N7bOZE).replace('\\\\','\\')
	title = XXcPiylRDh6IapYA25rwO8u(title)
	return title
def rr7SfotkneX85Klup(url,CRflaycBvUF):
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4([url],BfWYUAnyg6eONLjiuE,'video',url)
	return
def T27TaXrP8oF(search,jmI9qRnVJo2a3tpcH8gfYkP=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if jmI9qRnVJo2a3tpcH8gfYkP==fy8iFgEkrO12NR9TWBI35sjY6qHvV: jmI9qRnVJo2a3tpcH8gfYkP = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	search = search.split('/videos')[0]
	Bc7G3ur2Tw5QK1fPSkyJ = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mysearchwords',search)
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mypagelimit','40')
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mypagenumber',jmI9qRnVJo2a3tpcH8gfYkP)
	if sort==fy8iFgEkrO12NR9TWBI35sjY6qHvV: Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mysortmethod',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	else: Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/search/'+search+'/videos'
	FGRX4myP68S = Jxeonyjq0UQMEAXWi6TV7Ffpbch(Bc7G3ur2Tw5QK1fPSkyJ,search)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"videos"(.*?)"VideoConnection"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('"node":.*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for id,title,UHt2NSG0v6MXqcifgR8JL3xVeTs,qiKhapruYTQv6oyVW7S,rQ0jN7XkZPE1AYU,POjaBmHqzpsx1IYw7kQM4R in items:
			POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R.replace('\/','/')
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/video/'+id
			title = WkqGmXNMtE52jucsnZ(title)
			CRflaycBvUF = UHt2NSG0v6MXqcifgR8JL3xVeTs+'::'+qiKhapruYTQv6oyVW7S
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,403,POjaBmHqzpsx1IYw7kQM4R,rQ0jN7XkZPE1AYU,CRflaycBvUF)
		if '"hasNextPage":true' in FGRX4myP68S:
			jmI9qRnVJo2a3tpcH8gfYkP = str(int(jmI9qRnVJo2a3tpcH8gfYkP)+1)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+jmI9qRnVJo2a3tpcH8gfYkP,url,404,fy8iFgEkrO12NR9TWBI35sjY6qHvV,jmI9qRnVJo2a3tpcH8gfYkP,search)
	return
def GKR8sjtTDCm07hzE9XIlkv6goLxJN1(search,jmI9qRnVJo2a3tpcH8gfYkP=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if jmI9qRnVJo2a3tpcH8gfYkP==fy8iFgEkrO12NR9TWBI35sjY6qHvV: jmI9qRnVJo2a3tpcH8gfYkP = '1'
	Bc7G3ur2Tw5QK1fPSkyJ = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mysearchwords',search)
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mypagelimit','40')
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mypagenumber',jmI9qRnVJo2a3tpcH8gfYkP)
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/search/'+search+'/playlists'
	FGRX4myP68S = Jxeonyjq0UQMEAXWi6TV7Ffpbch(Bc7G3ur2Tw5QK1fPSkyJ,search)
	items = EcQxOa3RJm86WjTKA.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",.*?"total":(.*?),"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	for id,name,DBcg601ZHU35Nuk,UHt2NSG0v6MXqcifgR8JL3xVeTs,qiKhapruYTQv6oyVW7S,POjaBmHqzpsx1IYw7kQM4R,count in items:
		POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R.replace('\/','/')
		bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = WkqGmXNMtE52jucsnZ(title)
		CRflaycBvUF = UHt2NSG0v6MXqcifgR8JL3xVeTs+'::'+qiKhapruYTQv6oyVW7S
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,401,POjaBmHqzpsx1IYw7kQM4R,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CRflaycBvUF)
	if '"hasNextPage":true' in FGRX4myP68S:
		jmI9qRnVJo2a3tpcH8gfYkP = str(int(jmI9qRnVJo2a3tpcH8gfYkP)+1)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+jmI9qRnVJo2a3tpcH8gfYkP,url,405,fy8iFgEkrO12NR9TWBI35sjY6qHvV,jmI9qRnVJo2a3tpcH8gfYkP,search)
	return
def IrkDUzeGmjwiLEcHh1gRsfWJNT8F(search,jmI9qRnVJo2a3tpcH8gfYkP=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if jmI9qRnVJo2a3tpcH8gfYkP==fy8iFgEkrO12NR9TWBI35sjY6qHvV: jmI9qRnVJo2a3tpcH8gfYkP = '1'
	Bc7G3ur2Tw5QK1fPSkyJ = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mysearchwords',search)
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mypagelimit','40')
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mypagenumber',jmI9qRnVJo2a3tpcH8gfYkP)
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/search/'+search+'/channels'
	FGRX4myP68S = Jxeonyjq0UQMEAXWi6TV7Ffpbch(Bc7G3ur2Tw5QK1fPSkyJ,search)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"channels"(.*?)"ChannelConnection"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('"node".*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for id,name,POjaBmHqzpsx1IYw7kQM4R in items:
			POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R.replace('\/','/')
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+id
			title = 'USER:  '+name
			title = WkqGmXNMtE52jucsnZ(title)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,402,POjaBmHqzpsx1IYw7kQM4R,fy8iFgEkrO12NR9TWBI35sjY6qHvV,name)
		if '"hasNextPage":true' in FGRX4myP68S:
			jmI9qRnVJo2a3tpcH8gfYkP = str(int(jmI9qRnVJo2a3tpcH8gfYkP)+1)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+jmI9qRnVJo2a3tpcH8gfYkP,url,406,fy8iFgEkrO12NR9TWBI35sjY6qHvV,jmI9qRnVJo2a3tpcH8gfYkP,search)
	return
def zOZUbkxaEg8QqSC6GBXtpHLfmys5dW(YUP02mBl4C):
	Bc7G3ur2Tw5QK1fPSkyJ = '''{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  thumbnail: coverURL(size: \\"x532\\")  coverURL: coverURL(size: \\"x532\\")  isFollowed  whitelistStatus {    id    isWhitelisted    __typename  }  __typename}query HOME_QUERY($space: String!) {  home: views {    id    neon {      id      sections(space: $space) {        edges {          node {            id            name            title            description            groupingType            type            relatedComponent {              __typename              ... on Collection {                id                xid                __typename              }              ... on Channel {                id                xid                name                displayName                logoURL(size: \\"x60\\")                __typename              }              ... on Topic {                id                __typename                ...TOPIC_BASE_FRAG              }            }            components {              edges {                node {                  __typename                  ... on Video {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    description                    duration                    __typename                  }                  ... on Live {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    startAt                    __typename                  }                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	x3KcJMOQyeHhCZmN85ut6sVfp = Jxeonyjq0UQMEAXWi6TV7Ffpbch(Bc7G3ur2Tw5QK1fPSkyJ)
	if x3KcJMOQyeHhCZmN85ut6sVfp:
		LbJvaecGu63HDdyshFiMZ = LB7TcZnGYdfw5lWU1RH3Oztu9PyA('dict',x3KcJMOQyeHhCZmN85ut6sVfp)
		U7aK26zpmWRkEFMwAghj4QsPS = LbJvaecGu63HDdyshFiMZ['data']['home']['neon']['sections']['edges']
		if not YUP02mBl4C:
			WcslieN61f9JXyHEk = []
			for hTHSrokavCFsO in U7aK26zpmWRkEFMwAghj4QsPS:
				P5tnoSMIeLpiGNBDQd = hTHSrokavCFsO['node']['title']
				if P5tnoSMIeLpiGNBDQd not in WcslieN61f9JXyHEk: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+P5tnoSMIeLpiGNBDQd,fy8iFgEkrO12NR9TWBI35sjY6qHvV,414,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,P5tnoSMIeLpiGNBDQd)
				WcslieN61f9JXyHEk.append(P5tnoSMIeLpiGNBDQd)
		else:
			for hTHSrokavCFsO in U7aK26zpmWRkEFMwAghj4QsPS:
				P5tnoSMIeLpiGNBDQd = hTHSrokavCFsO['node']['title']
				if P5tnoSMIeLpiGNBDQd==YUP02mBl4C:
					PPInODHjuCEFvg = hTHSrokavCFsO['node']['components']['edges']
					for Lr0OpdXhNEj4om6znCJ9F in PPInODHjuCEFvg:
						rQ0jN7XkZPE1AYU = str(Lr0OpdXhNEj4om6znCJ9F['node']['duration'])
						title = XXcPiylRDh6IapYA25rwO8u(Lr0OpdXhNEj4om6znCJ9F['node']['title'])
						title = title.replace('\/','/')
						zLnXm6EWew817fOoi5Nbx = Lr0OpdXhNEj4om6znCJ9F['node']['xid']
						POjaBmHqzpsx1IYw7kQM4R = Lr0OpdXhNEj4om6znCJ9F['node']['thumbnailx480']
						POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R.replace('\/','/')
						bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/video/'+zLnXm6EWew817fOoi5Nbx
						OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,403,POjaBmHqzpsx1IYw7kQM4R,rQ0jN7XkZPE1AYU)
	return
def mXHYruWapVeAiSFqGQ(search,jmI9qRnVJo2a3tpcH8gfYkP=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if jmI9qRnVJo2a3tpcH8gfYkP==fy8iFgEkrO12NR9TWBI35sjY6qHvV: jmI9qRnVJo2a3tpcH8gfYkP = '1'
	Bc7G3ur2Tw5QK1fPSkyJ = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }  ... on Live {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          xid          title          thumbnail: thumbnailURL(size: \\"x240\\")          thumbnailx60: thumbnailURL(size: \\"x60\\")          thumbnailx120: thumbnailURL(size: \\"x120\\")          thumbnailx240: thumbnailURL(size: \\"x240\\")          thumbnailx720: thumbnailURL(size: \\"x720\\")          audienceCount          aspectRatio          isOnAir          channel {            id            xid            name            displayName            accountType            __typename          }          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mysearchwords',search)
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mypagelimit','40')
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mypagenumber',jmI9qRnVJo2a3tpcH8gfYkP)
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/search/'+search+'/lives'
	x3KcJMOQyeHhCZmN85ut6sVfp = Jxeonyjq0UQMEAXWi6TV7Ffpbch(Bc7G3ur2Tw5QK1fPSkyJ,search)
	if x3KcJMOQyeHhCZmN85ut6sVfp:
		LbJvaecGu63HDdyshFiMZ = LB7TcZnGYdfw5lWU1RH3Oztu9PyA('dict',x3KcJMOQyeHhCZmN85ut6sVfp)
		try: U7aK26zpmWRkEFMwAghj4QsPS = LbJvaecGu63HDdyshFiMZ['data']['search']['lives']['edges']
		except: U7aK26zpmWRkEFMwAghj4QsPS = []
		for hTHSrokavCFsO in U7aK26zpmWRkEFMwAghj4QsPS:
			name = hTHSrokavCFsO['node']['title']
			name = XXcPiylRDh6IapYA25rwO8u(name)
			zLnXm6EWew817fOoi5Nbx = hTHSrokavCFsO['node']['xid']
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/video/'+zLnXm6EWew817fOoi5Nbx
			OZD1l4pAMzeH('live',K2l9rLfvoXxyZ4NYapO+'LIVE: '+name,bigdh7fpZYl4aT2keV,403)
		if '"hasNextPage":true' in x3KcJMOQyeHhCZmN85ut6sVfp:
			jmI9qRnVJo2a3tpcH8gfYkP = str(int(jmI9qRnVJo2a3tpcH8gfYkP)+1)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+jmI9qRnVJo2a3tpcH8gfYkP,url,415,fy8iFgEkrO12NR9TWBI35sjY6qHvV,jmI9qRnVJo2a3tpcH8gfYkP,search)
	return
def vGdiWsnO0L1lJXBMbVm(search,jmI9qRnVJo2a3tpcH8gfYkP=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if jmI9qRnVJo2a3tpcH8gfYkP==fy8iFgEkrO12NR9TWBI35sjY6qHvV: jmI9qRnVJo2a3tpcH8gfYkP = '1'
	Bc7G3ur2Tw5QK1fPSkyJ = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    isInWatchLater    __typename  }  ... on Live {    id    isInWatchLater    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mysearchwords',search)
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mypagelimit','40')
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mypagenumber',jmI9qRnVJo2a3tpcH8gfYkP)
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/search/'+search+'/topics'
	x3KcJMOQyeHhCZmN85ut6sVfp = Jxeonyjq0UQMEAXWi6TV7Ffpbch(Bc7G3ur2Tw5QK1fPSkyJ,search)
	if x3KcJMOQyeHhCZmN85ut6sVfp:
		LbJvaecGu63HDdyshFiMZ = LB7TcZnGYdfw5lWU1RH3Oztu9PyA('dict',x3KcJMOQyeHhCZmN85ut6sVfp)
		try: U7aK26zpmWRkEFMwAghj4QsPS = LbJvaecGu63HDdyshFiMZ['data']['search']['topics']['edges']
		except: U7aK26zpmWRkEFMwAghj4QsPS = []
		for hTHSrokavCFsO in U7aK26zpmWRkEFMwAghj4QsPS:
			name = hTHSrokavCFsO['node']['name']
			zLnXm6EWew817fOoi5Nbx = hTHSrokavCFsO['node']['xid']
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/topic/'+zLnXm6EWew817fOoi5Nbx
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'TOPIC: '+name,bigdh7fpZYl4aT2keV,413)
		if '"hasNextPage":true' in x3KcJMOQyeHhCZmN85ut6sVfp:
			jmI9qRnVJo2a3tpcH8gfYkP = str(int(jmI9qRnVJo2a3tpcH8gfYkP)+1)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+jmI9qRnVJo2a3tpcH8gfYkP,url,412,fy8iFgEkrO12NR9TWBI35sjY6qHvV,jmI9qRnVJo2a3tpcH8gfYkP,search)
	return
def ECXLbDWrfazPIFTQp(url,jmI9qRnVJo2a3tpcH8gfYkP=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if jmI9qRnVJo2a3tpcH8gfYkP==fy8iFgEkrO12NR9TWBI35sjY6qHvV: jmI9qRnVJo2a3tpcH8gfYkP = '1'
	zLnXm6EWew817fOoi5Nbx = url.split('/')[-1]
	Bc7G3ur2Tw5QK1fPSkyJ = '''{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {  id  xid  title  duration  isLiked  isInWatchLater  isCreatedForKids  createdAt  isExplicit  videoHeight: height  videoWidth: width  category  channel {    id    xid    name    displayName    logoURLx25: logoURL(size: \\"x25\\")    logoURL(size: \\"x60\\")    accountType    __typename  }  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  aspectRatio  isPublished  __typename}query DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {  topic(xid: $xid) {    id    xid    name    videos(sort: \\"recent\\", first: 30, page: $page) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...TOPIC_VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mytopicid',zLnXm6EWew817fOoi5Nbx)
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mypagenumber',jmI9qRnVJo2a3tpcH8gfYkP)
	x3KcJMOQyeHhCZmN85ut6sVfp = Jxeonyjq0UQMEAXWi6TV7Ffpbch(Bc7G3ur2Tw5QK1fPSkyJ)
	if x3KcJMOQyeHhCZmN85ut6sVfp:
		LbJvaecGu63HDdyshFiMZ = LB7TcZnGYdfw5lWU1RH3Oztu9PyA('dict',x3KcJMOQyeHhCZmN85ut6sVfp)
		U7aK26zpmWRkEFMwAghj4QsPS = LbJvaecGu63HDdyshFiMZ['data']['topic']['videos']['edges']
		for hTHSrokavCFsO in U7aK26zpmWRkEFMwAghj4QsPS:
			rQ0jN7XkZPE1AYU = str(hTHSrokavCFsO['node']['duration'])
			title = XXcPiylRDh6IapYA25rwO8u(hTHSrokavCFsO['node']['title'])
			title = title.replace('\/','/')
			zLnXm6EWew817fOoi5Nbx = hTHSrokavCFsO['node']['xid']
			POjaBmHqzpsx1IYw7kQM4R = hTHSrokavCFsO['node']['thumbnailx480']
			POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R.replace('\/','/')
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/video/'+zLnXm6EWew817fOoi5Nbx
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,403,POjaBmHqzpsx1IYw7kQM4R,rQ0jN7XkZPE1AYU)
		if '"hasNextPage":true' in x3KcJMOQyeHhCZmN85ut6sVfp:
			jmI9qRnVJo2a3tpcH8gfYkP = str(int(jmI9qRnVJo2a3tpcH8gfYkP)+1)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+jmI9qRnVJo2a3tpcH8gfYkP,url,413,fy8iFgEkrO12NR9TWBI35sjY6qHvV,jmI9qRnVJo2a3tpcH8gfYkP)
	return
def mYWJBG2nSCUjiAkEsu0ztwvVgdN4(url,CRflaycBvUF):
	id = url.split('/')[-1]
	UHt2NSG0v6MXqcifgR8JL3xVeTs,qiKhapruYTQv6oyVW7S = CRflaycBvUF.split('::',1)
	bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+UHt2NSG0v6MXqcifgR8JL3xVeTs
	qiKhapruYTQv6oyVW7S = WkqGmXNMtE52jucsnZ(qiKhapruYTQv6oyVW7S)
	title = n0nFOd4yR97fQzNLSW+'OWNER:  '+qiKhapruYTQv6oyVW7S+T7ASIp1ZYwio9HQ8cObJK
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,402,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,qiKhapruYTQv6oyVW7S)
	Bc7G3ur2Tw5QK1fPSkyJ = '''{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {  views {    id    neon {      id      sections(device: $device, space: \\"watching\\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {        edges {          node {            id            name            groupingType            relatedComponent {              ... on Channel {                __typename                id                xid                name                displayName                logoURL(size: \\"x60\\")                logoURLx25: logoURL(size: \\"x25\\")              }              ... on Topic {                __typename                id                xid                name                names {                  edges {                    node {                      id                      name                      language {                        id                        codeAlpha2                        __typename                      }                      __typename                    }                    __typename                  }                  __typename                }              }              ... on Collection {                __typename                id                xid                name              }              __typename            }            components(first: $videoCountPerSection) {              metadata {                algorithm {                  name                  version                  uuid                  __typename                }                __typename              }              edges {                node {                  ... on Video {                    __typename                    id                    xid                    title                    duration                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    channel {                      id                      xid                      accountType                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      logoURL(size: \\"x60\\")                      __typename                    }                  }                  ... on Channel {                    __typename                    id                    xid                    name                    displayName                    accountType                    logoURL(size: \\"x60\\")                  }                  __typename                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('myplaylistid',id)
	FGRX4myP68S = Jxeonyjq0UQMEAXWi6TV7Ffpbch(Bc7G3ur2Tw5QK1fPSkyJ)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"collection_videos"(.*?)"SectionEdge"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",.*?"xid":"(.*?)",.*?"displayName":"(.*?)",',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for id,title,rQ0jN7XkZPE1AYU,POjaBmHqzpsx1IYw7kQM4R,UHt2NSG0v6MXqcifgR8JL3xVeTs,qiKhapruYTQv6oyVW7S in items:
			POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R.replace('\/','/')
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/video/'+id
			title = WkqGmXNMtE52jucsnZ(title)
			CRflaycBvUF = UHt2NSG0v6MXqcifgR8JL3xVeTs+'::'+qiKhapruYTQv6oyVW7S
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,403,POjaBmHqzpsx1IYw7kQM4R,rQ0jN7XkZPE1AYU,CRflaycBvUF)
	return
def GeiMAr3vZQSYh5XDjtfmcz1(url,jmI9qRnVJo2a3tpcH8gfYkP=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if jmI9qRnVJo2a3tpcH8gfYkP==fy8iFgEkrO12NR9TWBI35sjY6qHvV: jmI9qRnVJo2a3tpcH8gfYkP = '1'
	aiuh0XlPswEK = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	Bc7G3ur2Tw5QK1fPSkyJ = '''{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbURLx240: thumbnailURL(size: \\"x240\\")  thumbURLx360: thumbnailURL(size: \\"x360\\")  thumbURLx480: thumbnailURL(size: \\"x480\\")  thumbURLx720: thumbnailURL(size: \\"x720\\")  __typename}query CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mychannelid',aiuh0XlPswEK)
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mypagelimit','40')
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mypagenumber',jmI9qRnVJo2a3tpcH8gfYkP)
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mysortmethod',sort)
	FGRX4myP68S = Jxeonyjq0UQMEAXWi6TV7Ffpbch(Bc7G3ur2Tw5QK1fPSkyJ)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbURLx240":"(.*?)",',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for id,title,rQ0jN7XkZPE1AYU,UHt2NSG0v6MXqcifgR8JL3xVeTs,qiKhapruYTQv6oyVW7S,POjaBmHqzpsx1IYw7kQM4R in items:
			POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R.replace('\/','/')
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/video/'+id
			title = WkqGmXNMtE52jucsnZ(title)
			CRflaycBvUF = UHt2NSG0v6MXqcifgR8JL3xVeTs+'::'+qiKhapruYTQv6oyVW7S
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,403,POjaBmHqzpsx1IYw7kQM4R,rQ0jN7XkZPE1AYU,CRflaycBvUF)
		if '"hasNextPage":true' in FGRX4myP68S:
			jmI9qRnVJo2a3tpcH8gfYkP = str(int(jmI9qRnVJo2a3tpcH8gfYkP)+1)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+jmI9qRnVJo2a3tpcH8gfYkP,url,408,fy8iFgEkrO12NR9TWBI35sjY6qHvV,jmI9qRnVJo2a3tpcH8gfYkP)
	return
def A1S0layzKtb(url,jmI9qRnVJo2a3tpcH8gfYkP=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if jmI9qRnVJo2a3tpcH8gfYkP==fy8iFgEkrO12NR9TWBI35sjY6qHvV: jmI9qRnVJo2a3tpcH8gfYkP = '1'
	aiuh0XlPswEK = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	Bc7G3ur2Tw5QK1fPSkyJ = '''{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}query CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          xid          updatedAt          name          description          thumbURLx240: thumbnailURL(size: \\"x240\\")          thumbURLx360: thumbnailURL(size: \\"x360\\")          thumbURLx480: thumbnailURL(size: \\"x480\\")          stats {            videos {              total              __typename            }            __typename          }          channel {            id            ...CHANNEL_FRAGMENT            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mychannelid',aiuh0XlPswEK)
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mypagelimit','40')
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mypagenumber',jmI9qRnVJo2a3tpcH8gfYkP)
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mysortmethod',sort)
	FGRX4myP68S = Jxeonyjq0UQMEAXWi6TV7Ffpbch(Bc7G3ur2Tw5QK1fPSkyJ)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"thumbURLx240":"(.*?)",.*?"total":(.*?),".*?xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for id,name,POjaBmHqzpsx1IYw7kQM4R,count,DBcg601ZHU35Nuk,UHt2NSG0v6MXqcifgR8JL3xVeTs,qiKhapruYTQv6oyVW7S in items:
			POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R.replace('\/','/')
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = WkqGmXNMtE52jucsnZ(title)
			CRflaycBvUF = UHt2NSG0v6MXqcifgR8JL3xVeTs+'::'+qiKhapruYTQv6oyVW7S
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,401,POjaBmHqzpsx1IYw7kQM4R,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CRflaycBvUF)
		if '"hasNextPage":true' in FGRX4myP68S:
			jmI9qRnVJo2a3tpcH8gfYkP = str(int(jmI9qRnVJo2a3tpcH8gfYkP)+1)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+jmI9qRnVJo2a3tpcH8gfYkP,url,407,fy8iFgEkrO12NR9TWBI35sjY6qHvV,jmI9qRnVJo2a3tpcH8gfYkP)
	return
def W5W21L3Hl8JZpAYSuoKRqEI6xegTCm(url,letqERH6s3vWpA2CVcFwnjzurQL7Pg):
	aiuh0XlPswEK = url.split('/')[3]
	Bc7G3ur2Tw5QK1fPSkyJ = '''{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  __typename}fragment LIVE_FRAGMENT on Live {  id  xid  title  startAt  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment CHANNEL_MAIN_FRAGMENT on Channel {  id  xid  name  displayName  description  accountType  isArtist  logoURL(size: \\"x60\\")  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  isFollowed  tagline  country {    id    codeAlpha2    __typename  }  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  externalLinks {    id    facebookURL    twitterURL    websiteURL    instagramURL    pinterestURL    __typename  }  channel_lives_now: lives(first: 4, isOnAir: true) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_lives_scheduled: lives(first: 4, startIn: 7200) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_featured_videos: videos(first: 4, isFeatured: true) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_all_videos: videos(first: 4) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_most_viewed: videos(first: 4, sort: \\"visited\\") {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_collections: collections(first: 4) {    edges {      node {        id        xid        name        description        stats {          id          videos {            id            total            __typename          }          __typename        }        thumbnailx240: thumbnailURL(size: \\"x240\\")        thumbnailx360: thumbnailURL(size: \\"x360\\")        thumbnailx480: thumbnailURL(size: \\"x480\\")        channel {          id          ...CHANNEL_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }  channel_related_channel: networkChannels(    hasPublicVideos: true    first: $relatedChannels  ) {    edges {      node {        id        ...CHANNEL_FRAGMENT        __typename      }      __typename    }    __typename  }  __typename}query CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {  channel(name: $channel_name) {    id    ...CHANNEL_MAIN_FRAGMENT    __typename  }}"}'''
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mychannelid',aiuh0XlPswEK)
	FGRX4myP68S = Jxeonyjq0UQMEAXWi6TV7Ffpbch(Bc7G3ur2Tw5QK1fPSkyJ)
	PIAJtNdOiB35vp = Qra2CWgebk.loads(FGRX4myP68S)
	try: items = PIAJtNdOiB35vp['data']['channel'][letqERH6s3vWpA2CVcFwnjzurQL7Pg]['edges']
	except: items = []
	if not items: OZD1l4pAMzeH('link',K2l9rLfvoXxyZ4NYapO+'لا توجد نتائج',fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	else:
		for j25T6eKhaMk3 in items:
			cca4MwfSDHPrXZysiN = j25T6eKhaMk3['node']
			zLnXm6EWew817fOoi5Nbx = cca4MwfSDHPrXZysiN['xid']
			keys = list(cca4MwfSDHPrXZysiN.keys())
			qqd60en1mT = cca4MwfSDHPrXZysiN['__typename'].lower()
			if qqd60en1mT=='channel':
				name = cca4MwfSDHPrXZysiN['name']
				sqBCltAUiYJDIaeru9wk = cca4MwfSDHPrXZysiN['displayName']
				title = 'USER:  '+sqBCltAUiYJDIaeru9wk
				POjaBmHqzpsx1IYw7kQM4R = cca4MwfSDHPrXZysiN['coverURLx375']
			else:
				name = cca4MwfSDHPrXZysiN['channel']['name']
				sqBCltAUiYJDIaeru9wk = cca4MwfSDHPrXZysiN['channel']['displayName']
				title = cca4MwfSDHPrXZysiN['title']
				POjaBmHqzpsx1IYw7kQM4R = cca4MwfSDHPrXZysiN['thumbnailx360']
				if qqd60en1mT=='live': title = 'LIVE:  '+title
			title = WkqGmXNMtE52jucsnZ(title)
			CRflaycBvUF = name+'::'+sqBCltAUiYJDIaeru9wk
			if gZlSEJaXO9F461AL3sR7rWNpqf:
				title = title.encode(Tk9eH2qw6Brsuhj)
				CRflaycBvUF = CRflaycBvUF.encode(Tk9eH2qw6Brsuhj)
			POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R.replace('\/','/')
			if qqd60en1mT=='channel':
				bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+zLnXm6EWew817fOoi5Nbx
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,402,POjaBmHqzpsx1IYw7kQM4R,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CRflaycBvUF)
			else:
				if qqd60en1mT=='video': rQ0jN7XkZPE1AYU = str(cca4MwfSDHPrXZysiN['duration'])
				else: rQ0jN7XkZPE1AYU = fy8iFgEkrO12NR9TWBI35sjY6qHvV
				bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/video/'+zLnXm6EWew817fOoi5Nbx
				OZD1l4pAMzeH(qqd60en1mT,K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,403,POjaBmHqzpsx1IYw7kQM4R,rQ0jN7XkZPE1AYU,CRflaycBvUF)
	return
def Rlz9d5n1csuHWZFQAbB(search,jmI9qRnVJo2a3tpcH8gfYkP=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if jmI9qRnVJo2a3tpcH8gfYkP==fy8iFgEkrO12NR9TWBI35sjY6qHvV: jmI9qRnVJo2a3tpcH8gfYkP = '1'
	Bc7G3ur2Tw5QK1fPSkyJ = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeHashtags":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  duration  aspectRatio  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  accountType  isFollowed  avatar(height: SQUARE_120) {    id    url    __typename  }  followerEngagement {    id    followDate    __typename  }  metrics {    id    engagement {      id      followers {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  description  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  metrics {    id    engagement {      id      videos(filter: {visibility: {eq: PUBLIC}}) {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment HASHTAG_BASE_FRAG on Hashtag {  id  xid  name  metrics {    id    engagement {      id      videos {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment LIVE_BASE_FRAGMENT on Live {  id  xid  title  audienceCount  aspectRatio  isOnAir  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeHashtags: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...LIVE_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    hashtags(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeHashtags) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...HASHTAG_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mysearchwords',search)
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mypagelimit','40')
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mypagenumber',jmI9qRnVJo2a3tpcH8gfYkP)
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/search/'+search+'/hashtags'
	x3KcJMOQyeHhCZmN85ut6sVfp = Jxeonyjq0UQMEAXWi6TV7Ffpbch(Bc7G3ur2Tw5QK1fPSkyJ,search)
	if x3KcJMOQyeHhCZmN85ut6sVfp:
		LbJvaecGu63HDdyshFiMZ = LB7TcZnGYdfw5lWU1RH3Oztu9PyA('dict',x3KcJMOQyeHhCZmN85ut6sVfp)
		try: U7aK26zpmWRkEFMwAghj4QsPS = LbJvaecGu63HDdyshFiMZ['data']['search']['hashtags']['edges']
		except: U7aK26zpmWRkEFMwAghj4QsPS = []
		for hTHSrokavCFsO in U7aK26zpmWRkEFMwAghj4QsPS:
			name = hTHSrokavCFsO['node']['name']
			name = XXcPiylRDh6IapYA25rwO8u(name)
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/hashtag/'+name[1:]
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'HSHTG: '+name,bigdh7fpZYl4aT2keV,417)
		if '"hasNextPage":true' in x3KcJMOQyeHhCZmN85ut6sVfp:
			jmI9qRnVJo2a3tpcH8gfYkP = str(int(jmI9qRnVJo2a3tpcH8gfYkP)+1)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+jmI9qRnVJo2a3tpcH8gfYkP,url,416,fy8iFgEkrO12NR9TWBI35sjY6qHvV,jmI9qRnVJo2a3tpcH8gfYkP,search)
	return
def pcuHbPWkilFVQnI7vJ(url,jmI9qRnVJo2a3tpcH8gfYkP=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if jmI9qRnVJo2a3tpcH8gfYkP==fy8iFgEkrO12NR9TWBI35sjY6qHvV: jmI9qRnVJo2a3tpcH8gfYkP = '1'
	name = url.split('/')[-1]
	Bc7G3ur2Tw5QK1fPSkyJ = '''{"operationName":"HASHTAG_VIDEOS_QUERY","variables":{"hashtag_name":"#myhashtagname","page":mypagenumber},"query":"fragment FRAG_VIDEO_BASE on Video {  id  xid  title  description  thumbnail: thumbnailURL(size: \\"x240\\")  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  duration  createdAt  viewerEngagement {    id    liked    favorited    __typename  }  isExplicit  canDisplayAds  aspectRatio  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  videoHeight: height  videoWidth: width  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  description  logoURL(size: \\"x25\\")  logoURLx60: logoURL(size: \\"x60\\")  coverURL(size: \\"x200\\")  coverURLx1024: coverURL(size: \\"1024x\\")  isFollowed  isArtist  accountType  __typename}fragment VIDEO_FRAG on Video {  id  ...FRAG_VIDEO_BASE  channel {    id    ...CHANNEL_BASE_FRAG    __typename  }  __typename}query HASHTAG_VIDEOS_QUERY($hashtag_name: String!, $page: Int!) {  contentFeed(    name: HASHTAG    filter: {name: {eq: $hashtag_name}, post: {eq: VIDEO}}    sort: {create: DESC}    page: $page    first: 30  ) {    totalCount    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        post {          ...VIDEO_FRAG          __typename        }        featured        __typename      }      __typename    }    __typename  }}"}'''
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('myhashtagname',name)
	Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.replace('mypagenumber',jmI9qRnVJo2a3tpcH8gfYkP)
	x3KcJMOQyeHhCZmN85ut6sVfp = Jxeonyjq0UQMEAXWi6TV7Ffpbch(Bc7G3ur2Tw5QK1fPSkyJ)
	if x3KcJMOQyeHhCZmN85ut6sVfp:
		LbJvaecGu63HDdyshFiMZ = LB7TcZnGYdfw5lWU1RH3Oztu9PyA('dict',x3KcJMOQyeHhCZmN85ut6sVfp)
		U7aK26zpmWRkEFMwAghj4QsPS = LbJvaecGu63HDdyshFiMZ['data']['contentFeed']['edges']
		for hTHSrokavCFsO in U7aK26zpmWRkEFMwAghj4QsPS:
			rQ0jN7XkZPE1AYU = str(hTHSrokavCFsO['node']['post']['duration'])
			title = XXcPiylRDh6IapYA25rwO8u(hTHSrokavCFsO['node']['post']['title'])
			title = title.replace('\/','/')
			zLnXm6EWew817fOoi5Nbx = hTHSrokavCFsO['node']['post']['xid']
			POjaBmHqzpsx1IYw7kQM4R = hTHSrokavCFsO['node']['post']['thumbnailx480']
			POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R.replace('\/','/')
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/video/'+zLnXm6EWew817fOoi5Nbx
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,403,POjaBmHqzpsx1IYw7kQM4R,rQ0jN7XkZPE1AYU)
		if '"hasNextPage":true' in x3KcJMOQyeHhCZmN85ut6sVfp:
			jmI9qRnVJo2a3tpcH8gfYkP = str(int(jmI9qRnVJo2a3tpcH8gfYkP)+1)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+jmI9qRnVJo2a3tpcH8gfYkP,url,416,fy8iFgEkrO12NR9TWBI35sjY6qHvV,jmI9qRnVJo2a3tpcH8gfYkP)
	return
def Jxeonyjq0UQMEAXWi6TV7Ffpbch(Bc7G3ur2Tw5QK1fPSkyJ,search=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if jTDWgftK7NEmx0JAkOn2aRIvweq: Bc7G3ur2Tw5QK1fPSkyJ = Bc7G3ur2Tw5QK1fPSkyJ.encode(Tk9eH2qw6Brsuhj)
	Qzsr04vqA3PfeIG6jwU1ML2t = S53esg2EJNBdOzwHIA96GFKUn()
	headers = {"Authorization":Qzsr04vqA3PfeIG6jwU1ML2t,"Origin":BOI3t1w8qfHAb0Kl4oMye7haEWS,'Content-Type':'text/plain; charset=utf-8'}
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,'POST',rrkyXDFoKTYtf,Bc7G3ur2Tw5QK1fPSkyJ,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'DAILYMOTION-GET_PAGEDATA-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	return FGRX4myP68S
def S53esg2EJNBdOzwHIA96GFKUn():
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'DAILYMOTION-GET_AUTHINTICATION-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	JzLscwudWAMeI0C5Dk9 = EcQxOa3RJm86WjTKA.findall('var r="(.*?)",o="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	zYbqQElkjD24,aD0Ys97WMibLt = JzLscwudWAMeI0C5Dk9[-1]
	RRQBL6n2yYMbJkiP1hFmUNtgeIxo9 = 'https://graphql.api.dailymotion.com/oauth/token'
	JpCfuO8jAsBrqgSKoIxFz5ytGZL0w9 = 'client_credentials'
	data = {'client_id':zYbqQElkjD24,'client_secret':aD0Ys97WMibLt,'grant_type':JpCfuO8jAsBrqgSKoIxFz5ytGZL0w9}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,'POST',RRQBL6n2yYMbJkiP1hFmUNtgeIxo9,data,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'DAILYMOTION-GET_AUTHINTICATION-2nd')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	JzLscwudWAMeI0C5Dk9 = EcQxOa3RJm86WjTKA.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	spd4I5R1tc02NKAG7LzUYyC,ZFBAy78JmiW = JzLscwudWAMeI0C5Dk9[0]
	Qzsr04vqA3PfeIG6jwU1ML2t = ZFBAy78JmiW+" "+spd4I5R1tc02NKAG7LzUYyC
	return Qzsr04vqA3PfeIG6jwU1ML2t
def dPTs3joJiGpzfcWFvQZAa(search,HE7eaGoC6ixPIzV93A=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if not HE7eaGoC6ixPIzV93A and showDialogs:
		L18QfgbUaVkzKRAtscIl3MvrS2F = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن مستخدم','بحث عن بث حي','بحث عن هاشتاك']
		yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S('موقع ديلي موشن - اختر البحث',L18QfgbUaVkzKRAtscIl3MvrS2F)
		if yNqzFDjKM0SrO==-1: return
		elif yNqzFDjKM0SrO==0: HE7eaGoC6ixPIzV93A = 'videos?sortBy='
		elif yNqzFDjKM0SrO==1: HE7eaGoC6ixPIzV93A = 'videos?sortBy=RECENT'
		elif yNqzFDjKM0SrO==2: HE7eaGoC6ixPIzV93A = 'videos?sortBy=VIEW_COUNT'
		elif yNqzFDjKM0SrO==3: HE7eaGoC6ixPIzV93A = 'playlists'
		elif yNqzFDjKM0SrO==4: HE7eaGoC6ixPIzV93A = 'channels'
		elif yNqzFDjKM0SrO==5: HE7eaGoC6ixPIzV93A = 'lives'
		elif yNqzFDjKM0SrO==6: HE7eaGoC6ixPIzV93A = 'hashtags'
	elif '_DAILYMOTION-VIDEOS_' in yJWh5lC4wcNrRi3nFa: HE7eaGoC6ixPIzV93A = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in yJWh5lC4wcNrRi3nFa: HE7eaGoC6ixPIzV93A = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in yJWh5lC4wcNrRi3nFa: HE7eaGoC6ixPIzV93A = 'channels'
	elif '_DAILYMOTION-LIVES_' in yJWh5lC4wcNrRi3nFa: HE7eaGoC6ixPIzV93A = 'lives'
	elif '_DAILYMOTION-HASHTAGS_' in yJWh5lC4wcNrRi3nFa: HE7eaGoC6ixPIzV93A = 'hashtags'
	elif not HE7eaGoC6ixPIzV93A: HE7eaGoC6ixPIzV93A = 'videos?sortBy='
	if not search:
		search = GFYl1tsoOkHC0Ajeur8JQiMx()
		if not search: return
	if 'videos' in HE7eaGoC6ixPIzV93A: T27TaXrP8oF(search+'/'+HE7eaGoC6ixPIzV93A)
	elif 'playlists' in HE7eaGoC6ixPIzV93A: GKR8sjtTDCm07hzE9XIlkv6goLxJN1(search)
	elif 'channels' in HE7eaGoC6ixPIzV93A: IrkDUzeGmjwiLEcHh1gRsfWJNT8F(search)
	elif 'lives' in HE7eaGoC6ixPIzV93A: mXHYruWapVeAiSFqGQ(search)
	elif 'hashtags' in HE7eaGoC6ixPIzV93A: Rlz9d5n1csuHWZFQAbB(search)
	return
# -*- coding: utf-8 -*-
import sys as CfgZ0zWP5XBpoGQwLUY
D5DpyO2wPg7oL = CfgZ0zWP5XBpoGQwLUY.version_info [0] == 2
ccK5HIyfUgvOdQpWSXZtaBJ = 2048
W8WuBTGQg1Zwqy5F6xSe = 7
def zmQcCUZlPKBITW5bqx1 (rR5FPU8VhJQ):
	global Jfz4wMWSZb0BYV
	EEr5teuZbc = ord (rR5FPU8VhJQ [-1])
	ZZd5W9FVUhzu31NQyComxv = rR5FPU8VhJQ [:-1]
	sJYFyd6mZHev1IXEaMj0b = EEr5teuZbc % len (ZZd5W9FVUhzu31NQyComxv)
	qPJ7pUnt5rcm6NMaFYLSkHsGxI = ZZd5W9FVUhzu31NQyComxv [:sJYFyd6mZHev1IXEaMj0b] + ZZd5W9FVUhzu31NQyComxv [sJYFyd6mZHev1IXEaMj0b:]
	if D5DpyO2wPg7oL:
		Vv1b9fdEckNepm7 = unicode () .join ([unichr (ord (QdqoKlFn4yZUOJp1xYrNTaBSmt69hc) - ccK5HIyfUgvOdQpWSXZtaBJ - (hrazDC5q4oB + EEr5teuZbc) % W8WuBTGQg1Zwqy5F6xSe) for hrazDC5q4oB, QdqoKlFn4yZUOJp1xYrNTaBSmt69hc in enumerate (qPJ7pUnt5rcm6NMaFYLSkHsGxI)])
	else:
		Vv1b9fdEckNepm7 = str () .join ([chr (ord (QdqoKlFn4yZUOJp1xYrNTaBSmt69hc) - ccK5HIyfUgvOdQpWSXZtaBJ - (hrazDC5q4oB + EEr5teuZbc) % W8WuBTGQg1Zwqy5F6xSe) for hrazDC5q4oB, QdqoKlFn4yZUOJp1xYrNTaBSmt69hc in enumerate (qPJ7pUnt5rcm6NMaFYLSkHsGxI)])
	return eval (Vv1b9fdEckNepm7)
V3z5t4JAqyXk2fLsW1juoZ0BEp6,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye,wdftVMyzF17cYETHu=zmQcCUZlPKBITW5bqx1,zmQcCUZlPKBITW5bqx1,zmQcCUZlPKBITW5bqx1
Hr25gta6XcqO,FmYoGejTnwKME7d9zPc,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9=wdftVMyzF17cYETHu,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye,V3z5t4JAqyXk2fLsW1juoZ0BEp6
KfHAW8VGbrxi,aOQTKXFL54Nl60Zhp3MbE,jL5CrsRwebpyDVXUc1EQP=Dco0w1e5VM3YP7hLXTHBS8GtaCrO9,FmYoGejTnwKME7d9zPc,Hr25gta6XcqO
oRJAfwD957WkUyBM1Ehu8m,vU6DxuzPwMpg,I18uSKaWhgTBeYUPD4sr=jL5CrsRwebpyDVXUc1EQP,aOQTKXFL54Nl60Zhp3MbE,KfHAW8VGbrxi
o1INZ3ViQqS0Uw5z6kMjbv,s5WMHyQN4mpie,N6NGJ4vpmidqMCh7yo=I18uSKaWhgTBeYUPD4sr,vU6DxuzPwMpg,oRJAfwD957WkUyBM1Ehu8m
Gcw2nelTR864XCVruO3mAFqI5a,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7,OO9YiAQHGrLo0qpW2M3jDeXd1kx=N6NGJ4vpmidqMCh7yo,s5WMHyQN4mpie,o1INZ3ViQqS0Uw5z6kMjbv
O3OVuapf0YFjbm5oUQDg,sJw9QWiq1Kr0xfeVRI,SnhLjmfeJC=OO9YiAQHGrLo0qpW2M3jDeXd1kx,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7,Gcw2nelTR864XCVruO3mAFqI5a
QjAINyUC7MDRq5d8e4vl9,AAbvaXV2DQzfNHdm4U3tT,ggjO5CrKVRPITaesWkxD=SnhLjmfeJC,sJw9QWiq1Kr0xfeVRI,O3OVuapf0YFjbm5oUQDg
FgXzMs0YSDt,uulNDCPyef78,EQxFuqjw95WvaMm8Hnlt47XVihJ=ggjO5CrKVRPITaesWkxD,AAbvaXV2DQzfNHdm4U3tT,QjAINyUC7MDRq5d8e4vl9
ssynAg0zhSkoCpOMDV9,sIzDXlTHYUC5L3xZGnr,PlpyFa9QMKXxOD1cvHzmI=EQxFuqjw95WvaMm8Hnlt47XVihJ,uulNDCPyef78,FgXzMs0YSDt
CsDcLqQUVK4YBvHFW1,EE1jeHnIoad,LYIgTBeSmZWotDh4bnyQkvM50siu=PlpyFa9QMKXxOD1cvHzmI,sIzDXlTHYUC5L3xZGnr,ssynAg0zhSkoCpOMDV9
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = SnhLjmfeJC(u"ࠧࡓࡃࡑࡈࡔࡓࡓࠨ᫯")
K2l9rLfvoXxyZ4NYapO = N6NGJ4vpmidqMCh7yo(u"ࠨࡡࡏࡗ࡙ࡥࠧ᫰")
webrl8sY4tSqx = vD4Fh6ictZ7wME
r9U8hLPMKGwEQlc7fgIatJ3Wdoze = Gcw2nelTR864XCVruO3mAFqI5a(u"࠱࠱ᵞ")
def ugbnmWCrLpG9Av0xzocFaB5ew(hO3D6GVPY2qENv8bZWH,url,YMaiHbnIThsP7q,jmI9qRnVJo2a3tpcH8gfYkP,Q1q840Lz62ZxYGCEaRbjtuAFS7siW):
	try: FAVmIEYX4o3xJ8cdh = str(Q1q840Lz62ZxYGCEaRbjtuAFS7siW[aOQTKXFL54Nl60Zhp3MbE(u"ࠩࡩࡳࡱࡪࡥࡳࠩ᫱")])
	except: FAVmIEYX4o3xJ8cdh = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if   hO3D6GVPY2qENv8bZWH==CsDcLqQUVK4YBvHFW1(u"࠲࠸࠳ᵟ"): OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif hO3D6GVPY2qENv8bZWH==uulNDCPyef78(u"࠳࠹࠵ᵠ"): OmsWt89dSA5HyCZ4wL = qD21UpkXs5IcKJYGR8tNfPEi(YMaiHbnIThsP7q)
	elif hO3D6GVPY2qENv8bZWH==V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠴࠺࠷ᵡ"): OmsWt89dSA5HyCZ4wL = U6skEDzGalypOIFNLVWtn(YMaiHbnIThsP7q,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠴࠺࠷ᵡ"))
	elif hO3D6GVPY2qENv8bZWH==LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠵࠻࠹ᵢ"): OmsWt89dSA5HyCZ4wL = U6skEDzGalypOIFNLVWtn(YMaiHbnIThsP7q,LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠵࠻࠹ᵢ"))
	elif hO3D6GVPY2qENv8bZWH==EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠶࠼࠴ᵣ"): OmsWt89dSA5HyCZ4wL = Nsf37dTnjRU(YMaiHbnIThsP7q)
	elif hO3D6GVPY2qENv8bZWH==AAbvaXV2DQzfNHdm4U3tT(u"࠷࠶࠶ᵤ"): OmsWt89dSA5HyCZ4wL = wIk2nhr5JQs7OdG(url,YMaiHbnIThsP7q)
	elif hO3D6GVPY2qENv8bZWH==LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠱࠷࠸ᵥ"): OmsWt89dSA5HyCZ4wL = vzoZUeac9xlt8Ig0SPbTkOp7dAw(url,YMaiHbnIThsP7q)
	elif hO3D6GVPY2qENv8bZWH==sJw9QWiq1Kr0xfeVRI(u"࠲࠸࠺ᵦ"): OmsWt89dSA5HyCZ4wL = Aqe9VExdPgMYjs5bBao(url,YMaiHbnIThsP7q)
	elif hO3D6GVPY2qENv8bZWH==N6NGJ4vpmidqMCh7yo(u"࠳࠹࠼ᵧ"): OmsWt89dSA5HyCZ4wL = Yx034gfhSRqNsPdDzWZbu(url,YMaiHbnIThsP7q)
	elif hO3D6GVPY2qENv8bZWH==o1INZ3ViQqS0Uw5z6kMjbv(u"࠺࠺࠶ᵨ"): OmsWt89dSA5HyCZ4wL = sfyuvzGd0SDMXK97NOo8tmBE()
	elif hO3D6GVPY2qENv8bZWH==wdftVMyzF17cYETHu(u"࠻࠻࠸ᵩ"): OmsWt89dSA5HyCZ4wL = D72zfiSKIaRehgpcCk43OJEx()
	elif hO3D6GVPY2qENv8bZWH==FgXzMs0YSDt(u"࠼࠼࠳ᵪ"): OmsWt89dSA5HyCZ4wL = rev3lMkUIE7ASHnu(FAVmIEYX4o3xJ8cdh,YMaiHbnIThsP7q,jmI9qRnVJo2a3tpcH8gfYkP)
	elif hO3D6GVPY2qENv8bZWH==V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠽࠶࠵ᵫ"): OmsWt89dSA5HyCZ4wL = OO3brvsDGCkJU(FAVmIEYX4o3xJ8cdh,YMaiHbnIThsP7q)
	elif hO3D6GVPY2qENv8bZWH==PlpyFa9QMKXxOD1cvHzmI(u"࠷࠷࠷ᵬ"): OmsWt89dSA5HyCZ4wL = aCFYnzMTlGwe8(FAVmIEYX4o3xJ8cdh,YMaiHbnIThsP7q)
	else: OmsWt89dSA5HyCZ4wL = LhFAGlQ19zr
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᫲"),ssynAg0zhSkoCpOMDV9(u"ࠫ็์่ศฬࠣฮ้็า๋๊้ࠤ฾ฺ่ศศํอࠬ᫳"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,N6NGJ4vpmidqMCh7yo(u"࠲࠸࠴ᵭ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,uulNDCPyef78(u"ࠬࡥࡌࡊࡘࡈࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ᫴"))
	OZD1l4pAMzeH(FmYoGejTnwKME7d9zPc(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᫵"),CsDcLqQUVK4YBvHFW1(u"ࠧใี่ࠤ฾ฺ่ศศํࠫ᫶"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,I18uSKaWhgTBeYUPD4sr(u"࠳࠹࠶ᵮ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,FmYoGejTnwKME7d9zPc(u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᫷"))
	OZD1l4pAMzeH(Hr25gta6XcqO(u"ࠩࡩࡳࡱࡪࡥࡳࠩ᫸"),EE1jeHnIoad(u"ࠪๅ๏ี๊้้สฮࠥ฿ิ้ษษ๎ฮ࠭᫹"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,N6NGJ4vpmidqMCh7yo(u"࠴࠺࠸ᵯ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QjAINyUC7MDRq5d8e4vl9(u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ᫺"))
	OZD1l4pAMzeH(SnhLjmfeJC(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᫻"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭แ๋ัํ์์อสࠡสะฯࠥ฿ิ้ษษ๎ࠬ᫼"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,O3OVuapf0YFjbm5oUQDg(u"࠵࠻࠺ᵰ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᫽"))
	OZD1l4pAMzeH(EE1jeHnIoad(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᫾"),aOQTKXFL54Nl60Zhp3MbE(u"ࠩไ๎ิ๐่่ษอࠤ฾ฺ่ศศํอ๋ࠥๆࠡไึ้ࠬ᫿"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠼࠼࠳ᵱ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,s5WMHyQN4mpie(u"ࠪࡣࡘࡏࡔࡆࡕࡢࡣࡗࡇࡎࡅࡑࡐࡣࠬᬀ"))
	OZD1l4pAMzeH(N6NGJ4vpmidqMCh7yo(u"ࠫࡱ࡯࡮࡬ࠩᬁ"),n0nFOd4yR97fQzNLSW+LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫᬂ")+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,KfHAW8VGbrxi(u"࠿࠹࠺࠻ᵲ"))
	OZD1l4pAMzeH(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᬃ"),AAbvaXV2DQzfNHdm4U3tT(u"ࠧใ่๋หฯࠦࡍ࠴ࡗࠣ฽ู๎วว์ฬࠫᬄ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,sJw9QWiq1Kr0xfeVRI(u"࠱࠷࠵ᵳ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,sJw9QWiq1Kr0xfeVRI(u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᬅ"))
	OZD1l4pAMzeH(AAbvaXV2DQzfNHdm4U3tT(u"ࠩࡩࡳࡱࡪࡥࡳࠩᬆ"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠪๅ๏ี๊้้สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋หࠪᬇ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,EE1jeHnIoad(u"࠲࠸࠶ᵴ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,KfHAW8VGbrxi(u"ࠫࡤࡓ࠳ࡖࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᬈ"))
	OZD1l4pAMzeH(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᬉ"),uulNDCPyef78(u"࠭โิ็ࠣๆ๋๎วหࠢࡐ࠷ู࡚ࠦี๊สส๏࠭ᬊ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,PlpyFa9QMKXxOD1cvHzmI(u"࠳࠹࠶ᵵ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,SnhLjmfeJC(u"ࠧࡠࡏ࠶࡙ࡤࡥࡌࡊࡘࡈࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᬋ"))
	OZD1l4pAMzeH(N6NGJ4vpmidqMCh7yo(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᬌ"),o1INZ3ViQqS0Uw5z6kMjbv(u"ࠩๅื๊ࠦแ๋ัํ์ࠥࡓ࠳ࡖࠢ฼ุํอฦ๋ࠩᬍ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠴࠺࠷ᵶ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠪࡣࡒ࠹ࡕࡠࡡ࡙ࡓࡉࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᬎ"))
	OZD1l4pAMzeH(N6NGJ4vpmidqMCh7yo(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᬏ"),FmYoGejTnwKME7d9zPc(u"ࠬ็๊ะ์๋๋ฬะࠠࡎ࠵ࡘࠤอำหࠡ฻ื์ฬฬ๊ࠨᬐ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,o1INZ3ViQqS0Uw5z6kMjbv(u"࠵࠻࠺ᵷ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,jL5CrsRwebpyDVXUc1EQP(u"࠭࡟ࡎ࠵ࡘࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᬑ"))
	OZD1l4pAMzeH(vU6DxuzPwMpg(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᬒ"),ssynAg0zhSkoCpOMDV9(u"ࠨใํำ๏๎็ศฬࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ษࠡ็้ࠤ็ูๅࠨᬓ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,I18uSKaWhgTBeYUPD4sr(u"࠼࠼࠵ᵸ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,sJw9QWiq1Kr0xfeVRI(u"ࠩࡢࡑ࠸࡛࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᬔ"))
	OZD1l4pAMzeH(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪࡰ࡮ࡴ࡫ࠨᬕ"),n0nFOd4yR97fQzNLSW+QjAINyUC7MDRq5d8e4vl9(u"ࠫࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪᬖ")+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QjAINyUC7MDRq5d8e4vl9(u"࠿࠹࠺࠻ᵹ"))
	OZD1l4pAMzeH(AAbvaXV2DQzfNHdm4U3tT(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᬗ"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠭โ็๊สฮࠥࡏࡐࡕࡘࠣ฽ู๎วว์ฬࠫᬘ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,s5WMHyQN4mpie(u"࠱࠷࠵ᵺ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,O3OVuapf0YFjbm5oUQDg(u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᬙ"))
	OZD1l4pAMzeH(N6NGJ4vpmidqMCh7yo(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᬚ"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠩไ๎ิ๐่่ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋หࠪᬛ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠲࠸࠶ᵻ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠪࡣࡎࡖࡔࡗࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᬜ"))
	OZD1l4pAMzeH(CsDcLqQUVK4YBvHFW1(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᬝ"),uulNDCPyef78(u"่ࠬำๆࠢๅ๊ํอสࠡࡋࡓࡘู࡛ࠦี๊สส๏࠭ᬞ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,FgXzMs0YSDt(u"࠳࠹࠶ᵼ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,sIzDXlTHYUC5L3xZGnr(u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡌࡊࡘࡈࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᬟ"))
	OZD1l4pAMzeH(KfHAW8VGbrxi(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᬠ"),vU6DxuzPwMpg(u"ࠨไึ้ࠥ็๊ะ์๋ࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋ࠩᬡ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,Hr25gta6XcqO(u"࠴࠺࠷ᵽ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠩࡢࡍࡕ࡚ࡖࡠࡡ࡙ࡓࡉࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᬢ"))
	OZD1l4pAMzeH(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪࡪࡴࡲࡤࡦࡴࠪᬣ"),oRJAfwD957WkUyBM1Ehu8m(u"ࠫๆ๐ฯ๋๊๊หฯࠦࡉࡑࡖ࡙ࠤอำหࠡ฻ื์ฬฬ๊ࠨᬤ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,FmYoGejTnwKME7d9zPc(u"࠵࠻࠺ᵾ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᬥ"))
	OZD1l4pAMzeH(EE1jeHnIoad(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᬦ"),EE1jeHnIoad(u"ࠧโ์า๎ํํวหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ษࠡ็้ࠤ็ูๅࠨᬧ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,FmYoGejTnwKME7d9zPc(u"࠼࠼࠴ᵿ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,N6NGJ4vpmidqMCh7yo(u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᬨ"))
	return
def sfyuvzGd0SDMXK97NOo8tmBE():
	OZD1l4pAMzeH(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠩࡩࡳࡱࡪࡥࡳࠩᬩ"),ggjO5CrKVRPITaesWkxD(u"ࠪࡣࡎࡖࡔࡠࠩᬪ")+FgXzMs0YSDt(u"ࠫๆ๐ฯ๋๊๊หฯࠦฬๆ์฼ࠤࡎࡖࡔࡗࠩᬫ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,EE1jeHnIoad(u"࠽࠶࠵ᶀ"))
	OZD1l4pAMzeH(jL5CrsRwebpyDVXUc1EQP(u"ࠬࡲࡩ࡯࡭ࠪᬬ"),n0nFOd4yR97fQzNLSW+I18uSKaWhgTBeYUPD4sr(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫᬭ")+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CsDcLqQUVK4YBvHFW1(u"࠹࠺࠻࠼ᶁ"))
	for FAVmIEYX4o3xJ8cdh in range(BkM54Kr7Qbqn,gaUFPm1MLjDJ2lVecEuYI+BkM54Kr7Qbqn):
		K2l9rLfvoXxyZ4NYapO = ggjO5CrKVRPITaesWkxD(u"ࠧࡠࡋࡓࠫᬮ")+str(FAVmIEYX4o3xJ8cdh)+FgXzMs0YSDt(u"ࠨࡡࠪᬯ")
		OZD1l4pAMzeH(PlpyFa9QMKXxOD1cvHzmI(u"ࠩࡩࡳࡱࡪࡥࡳࠩᬰ"),K2l9rLfvoXxyZ4NYapO+ggjO5CrKVRPITaesWkxD(u"ࠪࠤๆ๐ฯ๋๊๊หฯࠦๅอๆาࠤࠬᬱ")+rjileqgmIOfLEWHoMz[FAVmIEYX4o3xJ8cdh],fy8iFgEkrO12NR9TWBI35sjY6qHvV,LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠸࠸࠷ᶂ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,{wdftVMyzF17cYETHu(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᬲ"):FAVmIEYX4o3xJ8cdh})
	return
def D72zfiSKIaRehgpcCk43OJEx():
	OZD1l4pAMzeH(LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᬳ"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠭࡟ࡎ࠵ࡘࡣ᬴ࠬ")+wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧโ์า๎ํํวหࠢฯ้๏฿ࠠࡎ࠵ࡘࠫᬵ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,O3OVuapf0YFjbm5oUQDg(u"࠹࠹࠹ᶃ"))
	OZD1l4pAMzeH(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠨ࡮࡬ࡲࡰ࠭ᬶ"),n0nFOd4yR97fQzNLSW+PlpyFa9QMKXxOD1cvHzmI(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧᬷ")+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠼࠽࠾࠿ᶄ"))
	for FAVmIEYX4o3xJ8cdh in range(BkM54Kr7Qbqn,gaUFPm1MLjDJ2lVecEuYI+BkM54Kr7Qbqn):
		K2l9rLfvoXxyZ4NYapO = Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠪࡣࡒ࡛ࠧᬸ")+str(FAVmIEYX4o3xJ8cdh)+FgXzMs0YSDt(u"ࠫࡤ࠭ᬹ")
		OZD1l4pAMzeH(s5WMHyQN4mpie(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᬺ"),K2l9rLfvoXxyZ4NYapO+Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠭ࠠโ์า๎ํํวห่ࠢะ้ีࠠࠨᬻ")+rjileqgmIOfLEWHoMz[FAVmIEYX4o3xJ8cdh],fy8iFgEkrO12NR9TWBI35sjY6qHvV,ggjO5CrKVRPITaesWkxD(u"࠻࠻࠻ᶅ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,{ssynAg0zhSkoCpOMDV9(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᬼ"):FAVmIEYX4o3xJ8cdh})
	return
def buoSpx5ATemEsLK6wgCOdaDN(C0C4kdG53sPAbNq8OBMpitLThHl):
	global K5iYxaUWePuXhSQnmp6CR,v8vcwFYZyIjWO4alkJQfniXdL
	i4YeIfAFjZkScx5RXLNGd96V,DDmgX24QRqwcVnez8GyP,rk0648WzSs7byUiKvRo5I1nBYPTMd = vjM9sANcTkUJViCD4PpBza0lH(C0C4kdG53sPAbNq8OBMpitLThHl)
	try:
		if sJw9QWiq1Kr0xfeVRI(u"ࠨࡋࡉࡍࡑࡓࠧᬽ") in C0C4kdG53sPAbNq8OBMpitLThHl: i4YeIfAFjZkScx5RXLNGd96V(C0C4kdG53sPAbNq8OBMpitLThHl)
		else: i4YeIfAFjZkScx5RXLNGd96V()
		tgd9wRmr0jISzDxF5qW = LhFAGlQ19zr
	except:
		XX09uEmwSJvLZyYjW()
		tgd9wRmr0jISzDxF5qW = EsCplGc5N4mBuYW0RVQt6b
	C0C4kdG53sPAbNq8OBMpitLThHl = eJYnofQG4mc8aFiN(C0C4kdG53sPAbNq8OBMpitLThHl)
	if tgd9wRmr0jISzDxF5qW:
		a6rVSjDMF87KyYINcuOP1l40Hbp(C0C4kdG53sPAbNq8OBMpitLThHl,oRJAfwD957WkUyBM1Ehu8m(u"ࠩไุ้ࠦไๅลึๅࠬᬾ"),uUqrNPcXKBoQ0slv=Gcw2nelTR864XCVruO3mAFqI5a(u"࠷࠶࠰࠱ᶆ"))
		K5iYxaUWePuXhSQnmp6CR += BkM54Kr7Qbqn
		v8vcwFYZyIjWO4alkJQfniXdL += uulNDCPyef78(u"ࠪࠤ࠳ࠦࠧᬿ")+C0C4kdG53sPAbNq8OBMpitLThHl
	else: a6rVSjDMF87KyYINcuOP1l40Hbp(C0C4kdG53sPAbNq8OBMpitLThHl,fy8iFgEkrO12NR9TWBI35sjY6qHvV,uUqrNPcXKBoQ0slv=vU6DxuzPwMpg(u"࠷࠰࠱࠲ᶇ"))
	return
kkFqaJz6KAmfdQlTIYvpNiUBhZ1 = {}
def C73G5sA6jdLxX4E(VBbINdng8TZc=EsCplGc5N4mBuYW0RVQt6b):
	global K5iYxaUWePuXhSQnmp6CR,v8vcwFYZyIjWO4alkJQfniXdL,kkFqaJz6KAmfdQlTIYvpNiUBhZ1
	if not VBbINdng8TZc:
		kkFqaJz6KAmfdQlTIYvpNiUBhZ1 = rIhXWK91vRuC(jUCABmLYMf0G,s5WMHyQN4mpie(u"ࠫࡩ࡯ࡣࡵࠩᭀ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘ࠭ᭁ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ࡙࡟ࡂࡎࡏࠫᭂ"))
		if kkFqaJz6KAmfdQlTIYvpNiUBhZ1: return
	Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(N6NGJ4vpmidqMCh7yo(u"ࠧࡤࡧࡱࡸࡪࡸࠧᭃ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯ᭄ࠫ"),Gcw2nelTR864XCVruO3mAFqI5a(u"ࠩะฮ๎ࠦสๆๆษࠤ์ึ็ࠡษ็ๆฬฬๅสࠢ࠱࠲ู๊ࠥโฯุࠤฬ๊ศา่ส้ัࠦฬๆ์฼ࠤ๊๎วใ฻ࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢไ๎ࠥอไษำ้ห๊าࠠฮฬ์ࠤ๏ูสฯำฯࠤ๊์็ศࠢไๆ฼ࠦวๅลๅืฬ๋ࠠศๆิส๏ู๊สࠢ࠱࠲ࠥัๅࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡสัึ๋ࠦ็ั้ࠣห้ษโิษ่ࠤาะ้ࠡๆสࠤฯำสศฮࠣว๋ࠦสๆๆษ๋ฬࠦๅาหࠣวำื้ࠡ࠰࠱ࠤ์ึ็ࠡษ็฽๊๊๊สࠢอัฯอฬࠡ฻สำฮࠦรใๆ้๋ࠣࠦ࠳ࠡัๅหห่ࠠ࡝ࡰ࡟ࡲࠬᭅ")+n0nFOd4yR97fQzNLSW+I18uSKaWhgTBeYUPD4sr(u"๋้ࠪࠦสา์าࠤศ์ࠠหฮ่฽่ࠥวว็ฬࠤฬ๊รใีส้ࠥอไร่ࠣรࠬᭆ")+T7ASIp1ZYwio9HQ8cObJK)
	if Scj7zgGFVA83otMpwUkxhm0BLN1!=BkM54Kr7Qbqn: return
	ZBILqw92kAymRHD7GstV(DDIe1w6Gj3NMV9E08FtqxbSsh,DDIe1w6Gj3NMV9E08FtqxbSsh,DDIe1w6Gj3NMV9E08FtqxbSsh)
	entOgEoCvJWmHhB8iFA = I4t9qonjrm.menuItemsLIST
	K5iYxaUWePuXhSQnmp6CR,v8vcwFYZyIjWO4alkJQfniXdL,threads = D2D96X5NGamBhrFwvL8VEbqiSfZIl,fy8iFgEkrO12NR9TWBI35sjY6qHvV,{}
	for C0C4kdG53sPAbNq8OBMpitLThHl in Yc24yz3S6stmNI:
		uUqrNPcXKBoQ0slv.sleep(BkM54Kr7Qbqn)
		threads[C0C4kdG53sPAbNq8OBMpitLThHl] = YMsWIfu7ojp2t4XJyZN05aC3l(daemon=EsCplGc5N4mBuYW0RVQt6b,target=buoSpx5ATemEsLK6wgCOdaDN,args=(C0C4kdG53sPAbNq8OBMpitLThHl,))
		threads[C0C4kdG53sPAbNq8OBMpitLThHl].start()
	else:
		for C0C4kdG53sPAbNq8OBMpitLThHl in list(threads.keys()): threads[C0C4kdG53sPAbNq8OBMpitLThHl].join()
	I4t9qonjrm.menuItemsLIST[:] = entOgEoCvJWmHhB8iFA
	kkFqaJz6KAmfdQlTIYvpNiUBhZ1 = {}
	for C0C4kdG53sPAbNq8OBMpitLThHl in list(threads.keys()):
		try: ozvSLuxkhreO1mJ9IaNCB4iHcn = I4t9qonjrm.menuItemsDICT[C0C4kdG53sPAbNq8OBMpitLThHl]
		except: continue
		C0C4kdG53sPAbNq8OBMpitLThHl = sJw9QWiq1Kr0xfeVRI(u"ࠫࡤࡒࡓࡕࡡࠪᭇ")+eJYnofQG4mc8aFiN(C0C4kdG53sPAbNq8OBMpitLThHl)
		for ppi24CwDdH3YzVIK8BUyLluQJEMW,z36flodJVD9jWxip14Rh,eEncXMVB2rNg4JObl3utYfj,hO3D6GVPY2qENv8bZWH,R87NZgODb1jyuxBAScelVivtP2,yy7dsVqg23CI5tbjXlwWmOe,YMaiHbnIThsP7q,R5gQk0ZcerYx3B,IYUEhjmyOzv40iCgxeN8JDPW in ozvSLuxkhreO1mJ9IaNCB4iHcn:
			if not z36flodJVD9jWxip14Rh: z36flodJVD9jWxip14Rh = sIzDXlTHYUC5L3xZGnr(u"ࠬ࠴࠮࠯࠰ࠪᭈ")
			else:
				if z36flodJVD9jWxip14Rh.count(FgXzMs0YSDt(u"࠭࡟ࠨᭉ"))>BkM54Kr7Qbqn: z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.split(SnhLjmfeJC(u"ࠧࡠࠩᭊ"),teaC5j4HuGDqpwcmUzJ)[teaC5j4HuGDqpwcmUzJ]
				z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(O3OVuapf0YFjbm5oUQDg(u"ࠨࢢࠪᭋ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(O3OVuapf0YFjbm5oUQDg(u"ࠩࠣࡌࡉ࠭ᭌ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(vU6DxuzPwMpg(u"ࠪࡌࡉࠦࠧ᭍"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
				z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(ggjO5CrKVRPITaesWkxD(u"ࠫๅ࠭᭎"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠬฯࠧ᭏"),sIzDXlTHYUC5L3xZGnr(u"࠭็ࠨ᭐")).replace(FmYoGejTnwKME7d9zPc(u"ࠧลࠩ᭑"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠨ๊ࠪ᭒"))
				z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(oRJAfwD957WkUyBM1Ehu8m(u"ࠩฦࠫ᭓"),PlpyFa9QMKXxOD1cvHzmI(u"ࠪหࠬ᭔")).replace(QjAINyUC7MDRq5d8e4vl9(u"ࠫส࠭᭕"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠬอࠧ᭖")).replace(N6NGJ4vpmidqMCh7yo(u"࠭ยࠨ᭗"),CsDcLqQUVK4YBvHFW1(u"ࠧศࠩ᭘"))
				z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(SnhLjmfeJC(u"ࠨๆฦࠫ᭙"),ggjO5CrKVRPITaesWkxD(u"ࠩ็หࠬ᭚")).replace(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"่ࠪส࠭᭛"),N6NGJ4vpmidqMCh7yo(u"้ࠫอࠧ᭜")).replace(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"๊ࠬยࠨ᭝"),FgXzMs0YSDt(u"࠭ไศࠩ᭞"))
				z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠧ๏ࠩ᭟"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(PlpyFa9QMKXxOD1cvHzmI(u"ࠨํࠪ᭠"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠩ๒ࠫ᭡"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(ssynAg0zhSkoCpOMDV9(u"ࠪ๐ࠬ᭢"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
				z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫ๕࠭᭣"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(jL5CrsRwebpyDVXUc1EQP(u"ࠬ๓ࠧ᭤"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠭๒ࠨ᭥"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(wdftVMyzF17cYETHu(u"ࠧ๒ࠩ᭦"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
				z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(oRJAfwD957WkUyBM1Ehu8m(u"ࠨࡾࠪ᭧"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(s5WMHyQN4mpie(u"ࠩࢁࠫ᭨"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
				z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪหํ์ࠠๅษํ๊ࠬ᭩"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(KfHAW8VGbrxi(u"ุࠫ๐ๅศࠢ็ห๏ะࠧ᭪"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
				mSYsbF5HDNdxIJV = [SnhLjmfeJC(u"ࠬอไฺษหࠫ᭫"),oRJAfwD957WkUyBM1Ehu8m(u"࠭ฮ๋ษ็᭬ࠫ"),FmYoGejTnwKME7d9zPc(u"ࠧศๆห์๊࠭᭭"),ggjO5CrKVRPITaesWkxD(u"ࠨษ็ห๋࠭᭮"),AAbvaXV2DQzfNHdm4U3tT(u"ࠩส฻ๆอไࠨ᭯"),AAbvaXV2DQzfNHdm4U3tT(u"ࠪัฬ๊๊่ࠩ᭰"),I18uSKaWhgTBeYUPD4sr(u"ࠫฬฺ๊ศิࠪ᭱"),ggjO5CrKVRPITaesWkxD(u"ࠬ฻วๅฯࠪ᭲"),Hr25gta6XcqO(u"࠭วๅัํ๊ࠬ᭳"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧๆ๊ส่๏ีࠧ᭴"),ssynAg0zhSkoCpOMDV9(u"ࠨษ็฽ฬ๊ๅࠨ᭵"),FgXzMs0YSDt(u"ࠩส฽๊อไࠨ᭶")]
				if not any(NuDMk1wQAyWXg in z36flodJVD9jWxip14Rh for NuDMk1wQAyWXg in mSYsbF5HDNdxIJV): z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(QjAINyUC7MDRq5d8e4vl9(u"ࠪห้࠭᭷"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
				z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(FgXzMs0YSDt(u"ࠫฬิั๋ࠩ᭸"),QjAINyUC7MDRq5d8e4vl9(u"ࠬอฮา๋ࠪ᭹")).replace(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠭วอ่หํࠬ᭺"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠧศฮ้ฬ๏࠭᭻")).replace(FmYoGejTnwKME7d9zPc(u"ࠨ฻สส้๐็ࠨ᭼"),I18uSKaWhgTBeYUPD4sr(u"ࠩ฼หห๊๊ࠨ᭽"))
				z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪหั์ศ๋้ࠪ᭾"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠫฬาๆษ์ࠪ᭿")).replace(aOQTKXFL54Nl60Zhp3MbE(u"ࠬ฿ัษ์๊ࠫᮀ"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ู࠭าสํࠫᮁ")).replace(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧา๊่หู๋๊่ࠩᮂ"),PlpyFa9QMKXxOD1cvHzmI(u"ࠨำ๋้ฬ์ำ๋ࠩᮃ"))
				z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(QjAINyUC7MDRq5d8e4vl9(u"ࠩ฽ีอ๐็ࠨᮄ"),sIzDXlTHYUC5L3xZGnr(u"ࠪ฾ึฮ๊ࠨᮅ")).replace(Hr25gta6XcqO(u"ࠫํࠦๅิๆึ่ฬะࠧᮆ"),QjAINyUC7MDRq5d8e4vl9(u"๋ࠬำๅี็หฯ࠭ᮇ")).replace(FmYoGejTnwKME7d9zPc(u"࠭ว฻ษ้ํࠬᮈ"),s5WMHyQN4mpie(u"ࠧศ฼ส๊๏࠭ᮉ"))
				z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(N6NGJ4vpmidqMCh7yo(u"ࠨฬสี๏ิ๊ࠨᮊ"),vU6DxuzPwMpg(u"ࠩอหึ๐ฮࠨᮋ")).replace(LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠪา๏อไࠡ฻็้๏࠭ᮌ"),uulNDCPyef78(u"ࠫำ๐วๅࠩᮍ")).replace(I18uSKaWhgTBeYUPD4sr(u"๋่ࠬิ์ๅ๎์࠭ᮎ"),sIzDXlTHYUC5L3xZGnr(u"࠭ๅ้ีํๆ๎࠭ᮏ"))
				z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(jL5CrsRwebpyDVXUc1EQP(u"่่ࠧาํࠬᮐ"),Hr25gta6XcqO(u"ࠨ้้ำ๏࠭ᮑ")).replace(o1INZ3ViQqS0Uw5z6kMjbv(u"๊๊ࠩิ๐็ࠨᮒ"),o1INZ3ViQqS0Uw5z6kMjbv(u"๋๋ࠪี๊ࠨᮓ")).replace(ggjO5CrKVRPITaesWkxD(u"ࠫํัววไํ๋ࠬᮔ"),Gcw2nelTR864XCVruO3mAFqI5a(u"ࠬ๎หศศๅ๎ࠬᮕ"))
				z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(QjAINyUC7MDRq5d8e4vl9(u"࠭สๅ์ไึ๏๎ๆ๋้ࠪᮖ"),ssynAg0zhSkoCpOMDV9(u"ࠧหๆไึ๏๎ๆࠨᮗ")).replace(sIzDXlTHYUC5L3xZGnr(u"ࠨฬ็ๅื๐่็์๊ࠫᮘ"),wdftVMyzF17cYETHu(u"ࠩอ่ๆุ๊้่ࠪᮙ")).replace(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠪ์้ࠥัห๊้ࠫᮚ"),jL5CrsRwebpyDVXUc1EQP(u"ࠫํ้ัห๊้ࠫᮛ"))
				z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(aOQTKXFL54Nl60Zhp3MbE(u"ࠬอไฮษ็๎์࠭ᮜ"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠭อศๆํ๋ࠬᮝ")).replace(QjAINyUC7MDRq5d8e4vl9(u"ࠧๆ๊ึ໐็๐ࠧᮞ"),FgXzMs0YSDt(u"ࠨ็๋ื๏่้ࠨᮟ")).replace(wdftVMyzF17cYETHu(u"ࠩส่ฬ์ๅ๋ࠩᮠ"),FgXzMs0YSDt(u"ࠪห๋๋๊ࠨᮡ"))
				z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠫฬ๊ๅิๆึ่ฬะࠧᮢ"),aOQTKXFL54Nl60Zhp3MbE(u"๋ࠬำๅี็หฯ࠭ᮣ")).replace(FgXzMs0YSDt(u"࠭วๅสิห๊าࠧᮤ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠧษำส้ั࠭ᮥ")).replace(N6NGJ4vpmidqMCh7yo(u"ࠨๅสีฯ๎ๆࠨᮦ"),N6NGJ4vpmidqMCh7yo(u"ࠩๆีฯ๎ๆࠨᮧ"))
				z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪัึ๎ศࠨᮨ"),Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫาืศࠨᮩ")).replace(SnhLjmfeJC(u"ࠬอไศ่สุ๏ี᮪ࠧ"),vU6DxuzPwMpg(u"࠭ว็ษื๎ิ᮫࠭")).replace(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠧศีํ์๏ํࠧᮬ"),sIzDXlTHYUC5L3xZGnr(u"ࠨษึ๎ํ๐ࠧᮭ"))
				z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(CsDcLqQUVK4YBvHFW1(u"ࠩ฼ีอ๏ࠧᮮ"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠪ฽ึฮ๊ࠨᮯ")).replace(wdftVMyzF17cYETHu(u"ࠫฯืใ๊ࠩ᮰"),o1INZ3ViQqS0Uw5z6kMjbv(u"ࠬะัไ์ࠪ᮱")).replace(Gcw2nelTR864XCVruO3mAFqI5a(u"࠭สาๅํ๋ࠬ᮲"),jL5CrsRwebpyDVXUc1EQP(u"ࠧหำๆ๎ࠬ᮳")).replace(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠨษ็้฻อแࠨ᮴"),sIzDXlTHYUC5L3xZGnr(u"ฺ่ࠩฬ็ࠧ᮵"))
				z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(jL5CrsRwebpyDVXUc1EQP(u"ࠪี๏อึ๋ࠩ᮶"),ggjO5CrKVRPITaesWkxD(u"ࠫึ๐วืหࠪ᮷")).replace(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠬื๊ศุ๊ࠫ᮸"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠭ั๋ษูอࠬ᮹")).replace(QjAINyUC7MDRq5d8e4vl9(u"ࠧศีํ์๏ํࠧᮺ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠨษึ๎ํ๐ࠧᮻ"))
				z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(EE1jeHnIoad(u"ࠩๆ์๊๐ฯ๊ࠩᮼ"),Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪ็ํ๋๊ะ์ࠪᮽ")).replace(Hr25gta6XcqO(u"่ࠫ๎ๅ๋ัํ๋ࠬᮾ"),oRJAfwD957WkUyBM1Ehu8m(u"้่ࠬๆ์า๎ࠬᮿ")).replace(AAbvaXV2DQzfNHdm4U3tT(u"࠭ว็์่๎ࠬᯀ"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠧศ่่๎ࠬᯁ"))
				z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(jL5CrsRwebpyDVXUc1EQP(u"ࠨษ้๎๊๐ิ็ࠩᯂ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠩส๊๊๐ิ็ࠩᯃ")).replace(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪห๋๋้ࠨᯄ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠫฬ์ๅ๋ึ้ࠫᯅ")).replace(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠬอๆๆ์ࠪᯆ"),FgXzMs0YSDt(u"࠭ว็็ํุ๋࠭ᯇ"))
				z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(FmYoGejTnwKME7d9zPc(u"ࠧศ่่๎ู์ิ็ࠩᯈ"),sJw9QWiq1Kr0xfeVRI(u"ࠨษ้้๏ฺๆࠨᯉ")).replace(wdftVMyzF17cYETHu(u"ࠩส่ฬ์ๅ๋ึ้ࠫᯊ"),sJw9QWiq1Kr0xfeVRI(u"ࠪห๋๋๊ี่ࠪᯋ")).replace(KfHAW8VGbrxi(u"ࠫฬ็ไศ็ุ้๊ࠣำๅษอࠫᯌ"),CsDcLqQUVK4YBvHFW1(u"ࠬอแๅษ่ࠤํ๋ำๅี็หฯ࠭ᯍ"))
				z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE).strip(wdftVMyzF17cYETHu(u"࠭࠭ࠨᯎ")).strip(ksJdoFWhxTz8Y2N7bOZE)
			if z36flodJVD9jWxip14Rh not in list(kkFqaJz6KAmfdQlTIYvpNiUBhZ1.keys()): kkFqaJz6KAmfdQlTIYvpNiUBhZ1[z36flodJVD9jWxip14Rh] = {}
			kkFqaJz6KAmfdQlTIYvpNiUBhZ1[z36flodJVD9jWxip14Rh][C0C4kdG53sPAbNq8OBMpitLThHl] = [ppi24CwDdH3YzVIK8BUyLluQJEMW,z36flodJVD9jWxip14Rh,eEncXMVB2rNg4JObl3utYfj,hO3D6GVPY2qENv8bZWH,R87NZgODb1jyuxBAScelVivtP2,yy7dsVqg23CI5tbjXlwWmOe,YMaiHbnIThsP7q,R5gQk0ZcerYx3B,IYUEhjmyOzv40iCgxeN8JDPW]
	tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,KfHAW8VGbrxi(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡖࡍ࡙ࡋࡓࠨᯏ"),wdftVMyzF17cYETHu(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡗࡎ࡚ࡅࡔࡡࡄࡐࡑ࠭ᯐ"),kkFqaJz6KAmfdQlTIYvpNiUBhZ1,zz2tnLhI1QHV7GwFCrv5)
	if K5iYxaUWePuXhSQnmp6CR>=r9U8hLPMKGwEQlc7fgIatJ3Wdoze: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,wdftVMyzF17cYETHu(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᯑ"),oRJAfwD957WkUyBM1Ehu8m(u"่ࠪิ๐ใࠡ็ื็้ฯࠠโ์ࠣࠫᯒ")+str(K5iYxaUWePuXhSQnmp6CR)+KfHAW8VGbrxi(u"๋่ࠫࠥใ฻้๋ࠣࠦๅ้ษๅ฽ࠥอไษำ้ห๊าࠠ࠯࠰࠱ࠤํํใัษู้้ࠣไสࠢึฬอํวࠡ฻สำฮࠦๅ็ࠢส่ส์สา่ํฮࠥ฿ๆะๅࠣ์ฬ๊ๅ้ษๅ฽ࠥํ๊࠻ࠩᯓ")+v8vcwFYZyIjWO4alkJQfniXdL)
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᯔ"),sJw9QWiq1Kr0xfeVRI(u"࠭สๆࠢฯ่อࠦฬๆ์฼ࠤฬ๊รใีส้ࠥอไๆฬ๋ๅึฯࠠโ์ࠣห้ฮั็ษ่ะࠬᯕ"))
	ZBILqw92kAymRHD7GstV(LLvswCIAk0tubrKgFpPW4BVf,LLvswCIAk0tubrKgFpPW4BVf,LLvswCIAk0tubrKgFpPW4BVf)
	n9grXGiQYD2wl8UjSRe3HcKhE()
	return
def jj1GJ7YuwylqmzSUBrEb(FAVmIEYX4o3xJ8cdh,JJnVRkiCSuK1D):
	vUTCBmuRD025KJ = LhFAGlQ19zr
	zcyQMjL09tm8UKbEfN1RBXgFkH = I4t9qonjrm.menuItemsLIST
	I4t9qonjrm.menuItemsLIST[:] = []
	if vUTCBmuRD025KJ and s5WMHyQN4mpie(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᯖ") not in JJnVRkiCSuK1D:
		OmsWt89dSA5HyCZ4wL = rIhXWK91vRuC(jUCABmLYMf0G,LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨ࡮࡬ࡷࡹ࠭ᯗ"),EE1jeHnIoad(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࠩᯘ"),QjAINyUC7MDRq5d8e4vl9(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࡢࠫᯙ")+FAVmIEYX4o3xJ8cdh)
	elif I18uSKaWhgTBeYUPD4sr(u"ࠫࡤࡒࡉࡗࡇࡢࠫᯚ") not in JJnVRkiCSuK1D or uulNDCPyef78(u"ࠬࡥࡖࡐࡆࡢࠫᯛ") not in JJnVRkiCSuK1D:
		import z1qJk2AYoC
		kf40tulvSA7z9RqNF5dXca3seMD = FgXzMs0YSDt(u"࠭ไๅลึๅ๊ࠥฯ๋ๅู้้ࠣไสࠢไ๎ࠥํะศࠢส่๊๎โฺࠢ࠱ࠤํืำศๆฬࠤฬ๊ฮุลࠣ็ฬ์ࠠโ์๊หࠥะแศืํ่ࠥอไๆึๆ่ฮࠦ࠮ࠡลำหࠥอไๆึๆ่ฮࠦไ๋ีอࠤาาศࠡใฯีอࠦลาีส่ࠥํะ่ࠢสฺ่๊ใๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ็้ࠤ็อฦๆหࠣาิ๋วหࠢส่อืๆศ็ฯࠫᯜ")
		if jL5CrsRwebpyDVXUc1EQP(u"ࠧࡠࡎࡌ࡚ࡊࡥࠧᯝ") not in JJnVRkiCSuK1D:
			try: z1qJk2AYoC.fXBo06ewvrJ38547Y(FAVmIEYX4o3xJ8cdh,sIzDXlTHYUC5L3xZGnr(u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᯞ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,JJnVRkiCSuK1D+PlpyFa9QMKXxOD1cvHzmI(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᯟ"),LhFAGlQ19zr)
			except: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,O3OVuapf0YFjbm5oUQDg(u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆไ๎ิ๐่่ษอࠫᯠ"),kf40tulvSA7z9RqNF5dXca3seMD)
			try: z1qJk2AYoC.fXBo06ewvrJ38547Y(FAVmIEYX4o3xJ8cdh,LYIgTBeSmZWotDh4bnyQkvM50siu(u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᯡ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,JJnVRkiCSuK1D+vU6DxuzPwMpg(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᯢ"),LhFAGlQ19zr)
			except: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QjAINyUC7MDRq5d8e4vl9(u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้ࠣ็๊ะ์๋๋ฬะࠧᯣ"),kf40tulvSA7z9RqNF5dXca3seMD)
			try: z1qJk2AYoC.fXBo06ewvrJ38547Y(FAVmIEYX4o3xJ8cdh,wdftVMyzF17cYETHu(u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬᯤ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,JJnVRkiCSuK1D+Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᯥ"),LhFAGlQ19zr)
			except: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,FgXzMs0YSDt(u"่ࠩ์็฿ࠠแࡋࡓࡘ࡛ࠦไๅใํำ๏๎็ศฬ᯦ࠪ"),kf40tulvSA7z9RqNF5dXca3seMD)
		if o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪࡣ࡛ࡕࡄࡠࠩᯧ") not in JJnVRkiCSuK1D:
			try: z1qJk2AYoC.fXBo06ewvrJ38547Y(FAVmIEYX4o3xJ8cdh,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫᯨ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,JJnVRkiCSuK1D+uulNDCPyef78(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᯩ"),LhFAGlQ19zr)
			except: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,oRJAfwD957WkUyBM1Ehu8m(u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้่ࠣๆ้ษอࠫᯪ"),kf40tulvSA7z9RqNF5dXca3seMD)
			try: z1qJk2AYoC.fXBo06ewvrJ38547Y(FAVmIEYX4o3xJ8cdh,Gcw2nelTR864XCVruO3mAFqI5a(u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭ᯫ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,JJnVRkiCSuK1D+ggjO5CrKVRPITaesWkxD(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᯬ"),LhFAGlQ19zr)
			except: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,SnhLjmfeJC(u"่ࠩ์็฿ࠠแࡋࡓࡘ࡛ࠦไๅไ้์ฬะࠧᯭ"),kf40tulvSA7z9RqNF5dXca3seMD)
		OmsWt89dSA5HyCZ4wL = I4t9qonjrm.menuItemsLIST
		if vUTCBmuRD025KJ: tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,aOQTKXFL54Nl60Zhp3MbE(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࠪᯮ"),FgXzMs0YSDt(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࡣࠬᯯ")+FAVmIEYX4o3xJ8cdh,OmsWt89dSA5HyCZ4wL,zz2tnLhI1QHV7GwFCrv5)
	I4t9qonjrm.menuItemsLIST[:] = zcyQMjL09tm8UKbEfN1RBXgFkH
	return OmsWt89dSA5HyCZ4wL
def dDF5SoYiLMpBl4b(FAVmIEYX4o3xJ8cdh,JJnVRkiCSuK1D):
	vUTCBmuRD025KJ = LhFAGlQ19zr
	zcyQMjL09tm8UKbEfN1RBXgFkH = I4t9qonjrm.menuItemsLIST
	I4t9qonjrm.menuItemsLIST[:] = []
	if vUTCBmuRD025KJ and Gcw2nelTR864XCVruO3mAFqI5a(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪᯰ") not in JJnVRkiCSuK1D:
		OmsWt89dSA5HyCZ4wL = rIhXWK91vRuC(jUCABmLYMf0G,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠭࡬ࡪࡵࡷࠫᯱ"),FmYoGejTnwKME7d9zPc(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷᯲࡚࠭"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛࡟ࠨ᯳")+FAVmIEYX4o3xJ8cdh)
	elif sJw9QWiq1Kr0xfeVRI(u"ࠩࡢࡐࡎ࡜ࡅࡠࠩ᯴") not in JJnVRkiCSuK1D or CsDcLqQUVK4YBvHFW1(u"ࠪࡣ࡛ࡕࡄࡠࠩ᯵") not in JJnVRkiCSuK1D:
		import ucJU0YkpTS
		kf40tulvSA7z9RqNF5dXca3seMD = V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"้๊ࠫริใ่ࠣิ๐ใࠡ็ื็้ฯࠠโ์๋ࠣีอࠠศๆ่์็฿ࠠ࠯๋ࠢีุอไสࠢส่ำ฽รࠡๅส๊ࠥ็๊่ษࠣฮๆอี๋ๆࠣห้๋ิไๆฬࠤ࠳ࠦรัษࠣห้๋ิไๆฬࠤ้๐ำหࠢะะอࠦแอำหࠤสืำศๆ๋ࠣีํࠠศๆุ่่๊ษࠡว็ํࠥอไๆสิ้ัࠦๅ็ࠢๅหห๋ษࠡะา้ฬะࠠศๆหี๋อๅอࠩ᯶")
		if ggjO5CrKVRPITaesWkxD(u"ࠬࡥࡌࡊࡘࡈࡣࠬ᯷") not in JJnVRkiCSuK1D:
			try: ucJU0YkpTS.fXBo06ewvrJ38547Y(FAVmIEYX4o3xJ8cdh,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ᯸"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,JJnVRkiCSuK1D+sIzDXlTHYUC5L3xZGnr(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᯹"),LhFAGlQ19zr)
			except: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨ็๋ๆ฾ࠦเࡎ࠵ࡘࠤ้๊แ๋ัํ์์อสࠨ᯺"),kf40tulvSA7z9RqNF5dXca3seMD)
			try: ucJU0YkpTS.fXBo06ewvrJ38547Y(FAVmIEYX4o3xJ8cdh,jL5CrsRwebpyDVXUc1EQP(u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ᯻"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,JJnVRkiCSuK1D+aOQTKXFL54Nl60Zhp3MbE(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᯼"),LhFAGlQ19zr)
			except: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,I18uSKaWhgTBeYUPD4sr(u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆไ๎ิ๐่่ษอࠫ᯽"),kf40tulvSA7z9RqNF5dXca3seMD)
			try: ucJU0YkpTS.fXBo06ewvrJ38547Y(FAVmIEYX4o3xJ8cdh,AAbvaXV2DQzfNHdm4U3tT(u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ᯾"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,JJnVRkiCSuK1D+O3OVuapf0YFjbm5oUQDg(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ᯿"),LhFAGlQ19zr)
			except: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QjAINyUC7MDRq5d8e4vl9(u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้ࠣ็๊ะ์๋๋ฬะࠧᰀ"),kf40tulvSA7z9RqNF5dXca3seMD)
		if sJw9QWiq1Kr0xfeVRI(u"ࠨࡡ࡙ࡓࡉࡥࠧᰁ") not in JJnVRkiCSuK1D:
			try: ucJU0YkpTS.fXBo06ewvrJ38547Y(FAVmIEYX4o3xJ8cdh,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠩࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᰂ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,JJnVRkiCSuK1D+Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᰃ"),LhFAGlQ19zr)
			except: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LYIgTBeSmZWotDh4bnyQkvM50siu(u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆๅ๊ํอสࠨᰄ"),kf40tulvSA7z9RqNF5dXca3seMD)
			try: ucJU0YkpTS.fXBo06ewvrJ38547Y(FAVmIEYX4o3xJ8cdh,PlpyFa9QMKXxOD1cvHzmI(u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫᰅ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,JJnVRkiCSuK1D+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᰆ"),LhFAGlQ19zr)
			except: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้่ࠣๆ้ษอࠫᰇ"),kf40tulvSA7z9RqNF5dXca3seMD)
		OmsWt89dSA5HyCZ4wL = I4t9qonjrm.menuItemsLIST
		if vUTCBmuRD025KJ: tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,FmYoGejTnwKME7d9zPc(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛ࠧᰈ"),wdftVMyzF17cYETHu(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࠩᰉ")+FAVmIEYX4o3xJ8cdh,OmsWt89dSA5HyCZ4wL,zz2tnLhI1QHV7GwFCrv5)
	I4t9qonjrm.menuItemsLIST[:] = zcyQMjL09tm8UKbEfN1RBXgFkH
	return OmsWt89dSA5HyCZ4wL
def rev3lMkUIE7ASHnu(FAVmIEYX4o3xJ8cdh,JJnVRkiCSuK1D,lqVQbuCkKFS1stcE9):
	ZBILqw92kAymRHD7GstV(cJsR8uCmEQpkzg2AyZXo1,cJsR8uCmEQpkzg2AyZXo1,DDIe1w6Gj3NMV9E08FtqxbSsh)
	if lqVQbuCkKFS1stcE9: C73G5sA6jdLxX4E(LhFAGlQ19zr)
	elif AAbvaXV2DQzfNHdm4U3tT(u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨᰊ") in JJnVRkiCSuK1D and not lqVQbuCkKFS1stcE9: C73G5sA6jdLxX4E(EsCplGc5N4mBuYW0RVQt6b)
	N5vAmntUE3 = JJnVRkiCSuK1D.replace(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩᰋ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(FmYoGejTnwKME7d9zPc(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧᰌ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(N6NGJ4vpmidqMCh7yo(u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᰍ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	if not lqVQbuCkKFS1stcE9:
		OZD1l4pAMzeH(CsDcLqQUVK4YBvHFW1(u"ࠧ࡭࡫ࡱ࡯ࠬᰎ"),wdftVMyzF17cYETHu(u"ࠨฬะำ๏ัࠠใษษ้ฮࠦวๅลๅืฬ๋ࠧᰏ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠷࠷࠵ᶈ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Hr25gta6XcqO(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧᰐ")+N5vAmntUE3,fy8iFgEkrO12NR9TWBI35sjY6qHvV,{vU6DxuzPwMpg(u"ࠪࡪࡴࡲࡤࡦࡴࠪᰑ"):FAVmIEYX4o3xJ8cdh})
		OZD1l4pAMzeH(ssynAg0zhSkoCpOMDV9(u"ࠫࡱ࡯࡮࡬ࠩᰒ"),n0nFOd4yR97fQzNLSW+C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪᰓ")+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,oRJAfwD957WkUyBM1Ehu8m(u"࠺࠻࠼࠽ᶉ"))
		K7Kt5Zfpv10oNX = [FgXzMs0YSDt(u"࠭รโๆส้ࠬᰔ"),QjAINyUC7MDRq5d8e4vl9(u"ࠧๆี็ื้อสࠨᰕ"),wdftVMyzF17cYETHu(u"ࠨ็ึีา๐วหࠩᰖ"),SnhLjmfeJC(u"ࠩหีฬ๋ฬࠨᰗ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪว฼็วๅ๋ࠢ็ึะ่็ࠩᰘ"),AAbvaXV2DQzfNHdm4U3tT(u"ࠫึ๋ึศ่ࠪᰙ"),s5WMHyQN4mpie(u"ࠬษอะอ࠰วำืࠧᰚ"),ggjO5CrKVRPITaesWkxD(u"࠭ำๅษึ่ࠬᰛ"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠧๆ๊ึ๎็๏ࠧᰜ"),ggjO5CrKVRPITaesWkxD(u"ࠨลื๋ึ࠳รไอิࠫᰝ"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠩส่ว์ࠧᰞ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ฺࠪา้ࠧᰟ"),ggjO5CrKVRPITaesWkxD(u"ࠫึ๐วืหࠪᰠ"),oRJAfwD957WkUyBM1Ehu8m(u"ࠬ์๊หใ็็ุ࠭ᰡ"),o1INZ3ViQqS0Uw5z6kMjbv(u"࠭ๅๆอ็๎๋࠭ᰢ"),I18uSKaWhgTBeYUPD4sr(u"ࠧษอࠣั๏࠭ᰣ"),Hr25gta6XcqO(u"ࠨัํ๊๏ฯࠧᰤ"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠩึ๊ํอสࠨᰥ"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠪวำื้ࠨᰦ")]
		lqVQbuCkKFS1stcE9 = D2D96X5NGamBhrFwvL8VEbqiSfZIl
		for TTP04o3ZwBsSnRQGjLOK67UvxdJh8e in K7Kt5Zfpv10oNX:
			lqVQbuCkKFS1stcE9 += BkM54Kr7Qbqn
			OZD1l4pAMzeH(s5WMHyQN4mpie(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᰧ"),K2l9rLfvoXxyZ4NYapO+TTP04o3ZwBsSnRQGjLOK67UvxdJh8e,fy8iFgEkrO12NR9TWBI35sjY6qHvV,wdftVMyzF17cYETHu(u"࠹࠹࠷ᶊ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,str(lqVQbuCkKFS1stcE9),N5vAmntUE3,fy8iFgEkrO12NR9TWBI35sjY6qHvV,{oRJAfwD957WkUyBM1Ehu8m(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᰨ"):FAVmIEYX4o3xJ8cdh})
	else:
		y3uQeUmrzjMlnVoChHwckNf4 = [EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭วโๆส้ࠬᰩ"),wdftVMyzF17cYETHu(u"ࠧ࡮ࡱࡹ࡭ࡪ࠭ᰪ"),SnhLjmfeJC(u"ࠨใํ่๊࠭ᰫ"),QjAINyUC7MDRq5d8e4vl9(u"ࠩไ่๊࠭ᰬ")]
		XiHWZGyhu27CE = [C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ุ้๊ࠪำๅࠩᰭ"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠫࡸ࡫ࡲࡪࡧࡶࠫᰮ")]
		h30zaQFqb5mpTgR = [Gcw2nelTR864XCVruO3mAFqI5a(u"๋ࠬำศำะࠫᰯ"),QjAINyUC7MDRq5d8e4vl9(u"࠭ๅิำะ๎ฬะࠧᰰ")]
		GGFOmaNSVz8k2drtRv3DuXCqT9Kn4L = [Gcw2nelTR864XCVruO3mAFqI5a(u"ࠧษำส้ั࠭ᰱ"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨࡵ࡫ࡳࡼ࠭ᰲ"),sIzDXlTHYUC5L3xZGnr(u"ࠩอ่ๆุ๊้่ࠪᰳ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪฮ้๐แำ์๋๊ࠬᰴ")]
		WoMt0Hasf1ydAw4Tq6F9iVkbE3c = [KfHAW8VGbrxi(u"ࠫฬ์ๅ๋ࠩᰵ"),N6NGJ4vpmidqMCh7yo(u"้ࠬัห๊้ࠫᰶ"),Gcw2nelTR864XCVruO3mAFqI5a(u"࠭ใศำอ์᰷๋࠭"),uulNDCPyef78(u"ࠧ࡬࡫ࡧࡷࠬ᰸"),s5WMHyQN4mpie(u"ࠨูไ่ࠬ᰹"),SnhLjmfeJC(u"ࠩส฻ๆอไࠨ᰺")]
		gfBmKIyDUChEH4VYNPdXs9 = [uulNDCPyef78(u"ࠪี๊฼ว็ࠩ᰻")]
		Voyqwkr1g8BY2LJXz3u = [QjAINyUC7MDRq5d8e4vl9(u"ࠫฬำฯฬࠩ᰼"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠬอฮาࠩ᰽"),uulNDCPyef78(u"࠭ๅ้ะิࠫ᰾"),aOQTKXFL54Nl60Zhp3MbE(u"ࠧอัํำࠬ᰿"),QjAINyUC7MDRq5d8e4vl9(u"ࠨ็ูหๆ࠭᱀"),wdftVMyzF17cYETHu(u"ࠩะำ๏ัࠧ᱁")]
		TCaXknulADmyZLGR = [I18uSKaWhgTBeYUPD4sr(u"ࠪื้อำๅࠩ᱂"),I18uSKaWhgTBeYUPD4sr(u"ุ๊ࠫำๅ้ࠪ᱃")]
		MJo4lhHT0UX1WSkdB = [aOQTKXFL54Nl60Zhp3MbE(u"ࠬอฺศ่ํࠫ᱄"),O3OVuapf0YFjbm5oUQDg(u"࠭ๅ้ีํๆ๎࠭᱅"),o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧไๆํฬࠬ᱆"),jL5CrsRwebpyDVXUc1EQP(u"ࠨฯไ่ࠬ᱇"),s5WMHyQN4mpie(u"ࠩࡰࡹࡸ࡯ࡣࠨ᱈")]
		W5GXTut6oEpMHARlir = [PlpyFa9QMKXxOD1cvHzmI(u"ࠪห่ััࠨ᱉"),FmYoGejTnwKME7d9zPc(u"ࠫฬฺ็าࠩ᱊"),aOQTKXFL54Nl60Zhp3MbE(u"๋ࠬๅ๋ิ๊ࠫ᱋"),FmYoGejTnwKME7d9zPc(u"࠭วฺๆ์ࠫ᱌"),Hr25gta6XcqO(u"ࠧๆะอหึํࠧᱍ"),KfHAW8VGbrxi(u"ࠨ็ัฮฬืวหࠩᱎ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠩสๆํ๏ࠧᱏ")]
		UU7plHM0k63OgSeERdJF5GVa8j9wxn = [V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪห้อๆࠨ᱐"),ssynAg0zhSkoCpOMDV9(u"ࠫาอไ๋ࠩ᱑"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"๋ࠬหษฬࠪ᱒"),jL5CrsRwebpyDVXUc1EQP(u"࠭ัศศฯࠫ᱓")]
		A3AOYdpC0RjlhsuKMGIVNqF94EBbZm = [Hr25gta6XcqO(u"ࠧืฯๆࠫ᱔"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠨๅ๋้๏ี๊ࠨ᱕")]
		rMYmCApR3QHFOx2 = [ggjO5CrKVRPITaesWkxD(u"ࠩิ๎ฬ฼็ࠨ᱖"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪ็ํื็ࠨ᱗"),jL5CrsRwebpyDVXUc1EQP(u"๊ࠫ฻วา฻๊ࠫ᱘"),PlpyFa9QMKXxOD1cvHzmI(u"ฺ่ࠬหࠩ᱙"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠭ั๋ษูอࠬᱚ")]
		XX7Onvbwzme2yc = [wdftVMyzF17cYETHu(u"ࠧ็์อๅ้้ำࠨᱛ"),N6NGJ4vpmidqMCh7yo(u"ࠨࡰࡨࡸ࡫ࡲࡩࡹࠩᱜ"),ssynAg0zhSkoCpOMDV9(u"้ࠩ๎ฯ็ไ๋ๅึࠫᱝ")]
		V4LlOS8gqBihRtbf = [CsDcLqQUVK4YBvHFW1(u"้๊ࠪัไ๋่ࠪᱞ"),PlpyFa9QMKXxOD1cvHzmI(u"ࠫฬฺฮศืࠪᱟ"),oRJAfwD957WkUyBM1Ehu8m(u"ࠬ์ฬ้็ࠪᱠ")]
		uEyU2e6lv4 = [wdftVMyzF17cYETHu(u"࠭ศฬࠢะ๎ࠬᱡ"),KfHAW8VGbrxi(u"ࠧ࡭࡫ࡹࡩࠬᱢ"),vU6DxuzPwMpg(u"ࠨไ้ห์࠭ᱣ"),Hr25gta6XcqO(u"ࠩๅ๊ํอสࠨᱤ")]
		skOzc8ZUSRI6K1eoAMtgPnHEyTwj = [uulNDCPyef78(u"ࠪำ๏์ࠧᱥ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠫฬีู๋้ࠪᱦ"),N6NGJ4vpmidqMCh7yo(u"ุ๊ࠬศำสฮࠬᱧ"),KfHAW8VGbrxi(u"࠭ไุ็ํหฯ࠭ᱨ"),o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧะ฻สลࠬᱩ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠨไิห๋࠭ᱪ"),I18uSKaWhgTBeYUPD4sr(u"ࠩๅูฬฬฯࠨᱫ"),s5WMHyQN4mpie(u"ࠪีะอมࠨᱬ"),Gcw2nelTR864XCVruO3mAFqI5a(u"๊ࠫืฬฺ์๊ࠫᱭ"),o1INZ3ViQqS0Uw5z6kMjbv(u"ࠬอะศ่ࠪᱮ"),FgXzMs0YSDt(u"࠭วิๆส้ࠬᱯ"),PlpyFa9QMKXxOD1cvHzmI(u"ࠧห๊สุ๏ำࠧᱰ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠨะฺฬࠬᱱ"),O3OVuapf0YFjbm5oUQDg(u"ࠩะ์ื๎๊ࠨᱲ"),I18uSKaWhgTBeYUPD4sr(u"ࠪ฽ฯฮวหࠩᱳ"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"๊ࠫ๎วๅ์าࠫᱴ"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠬ์่ศ฻ํࠫᱵ"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ู࠭ใษษำࠬᱶ"),QjAINyUC7MDRq5d8e4vl9(u"ࠧศ่สุ๏ีࠧᱷ")]
		uzRKehkJFox2CcDbMvTNVgBP6SZLG = [EE1jeHnIoad(u"ࠨ࠴࠳࠵࠵࠭ᱸ"),aOQTKXFL54Nl60Zhp3MbE(u"ࠩ࠵࠴࠶࠷ࠧᱹ"),Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪ࠶࠵࠷࠲ࠨᱺ"),oRJAfwD957WkUyBM1Ehu8m(u"ࠫ࠷࠶࠱࠴ࠩᱻ"),QjAINyUC7MDRq5d8e4vl9(u"ࠬ࠸࠰࠲࠶ࠪᱼ"),AAbvaXV2DQzfNHdm4U3tT(u"࠭࠲࠱࠳࠸ࠫᱽ"),KfHAW8VGbrxi(u"ࠧ࠳࠲࠴࠺ࠬ᱾"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠨ࠴࠳࠵࠼࠭᱿"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠩ࠵࠴࠶࠾ࠧᲀ"),uulNDCPyef78(u"ࠪ࠶࠵࠷࠹ࠨᲁ"),FgXzMs0YSDt(u"ࠫ࠷࠶࠲࠱ࠩᲂ"),FgXzMs0YSDt(u"ࠬ࠸࠰࠳࠳ࠪᲃ"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭࠲࠱࠴࠵ࠫᲄ"),oRJAfwD957WkUyBM1Ehu8m(u"ࠧ࠳࠲࠵࠷ࠬᲅ"),sIzDXlTHYUC5L3xZGnr(u"ࠨ࠴࠳࠶࠹࠭ᲆ"),O3OVuapf0YFjbm5oUQDg(u"ࠩ࠵࠴࠷࠻ࠧᲇ"),CsDcLqQUVK4YBvHFW1(u"ࠪ࠶࠵࠸࠶ࠨᲈ"),PlpyFa9QMKXxOD1cvHzmI(u"ࠫ࠷࠶࠲࠸ࠩᲉ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠬ࠸࠰࠳࠺ࠪᲊ")]
		for z36flodJVD9jWxip14Rh in sorted(list(kkFqaJz6KAmfdQlTIYvpNiUBhZ1.keys())):
			z6FysMQJTa2IWYdrDx7BjObwN3fE = z36flodJVD9jWxip14Rh.lower()
			fnogyzNA30JCPMYqHTavG7ZKp = []
			if any(value in z6FysMQJTa2IWYdrDx7BjObwN3fE for value in y3uQeUmrzjMlnVoChHwckNf4): fnogyzNA30JCPMYqHTavG7ZKp.append(BkM54Kr7Qbqn)
			if any(value in z6FysMQJTa2IWYdrDx7BjObwN3fE for value in XiHWZGyhu27CE): fnogyzNA30JCPMYqHTavG7ZKp.append(teaC5j4HuGDqpwcmUzJ)
			if any(value in z6FysMQJTa2IWYdrDx7BjObwN3fE for value in h30zaQFqb5mpTgR): fnogyzNA30JCPMYqHTavG7ZKp.append(XW57OCeGnFTLQbaqdrD9zM)
			if any(value in z6FysMQJTa2IWYdrDx7BjObwN3fE for value in GGFOmaNSVz8k2drtRv3DuXCqT9Kn4L): fnogyzNA30JCPMYqHTavG7ZKp.append(vD4Fh6ictZ7wME)
			if any(value in z6FysMQJTa2IWYdrDx7BjObwN3fE for value in WoMt0Hasf1ydAw4Tq6F9iVkbE3c): fnogyzNA30JCPMYqHTavG7ZKp.append(hvkue2LYgiOGrtcmxszl4S8MWdnF)
			if any(value in z6FysMQJTa2IWYdrDx7BjObwN3fE for value in gfBmKIyDUChEH4VYNPdXs9): fnogyzNA30JCPMYqHTavG7ZKp.append(s5WMHyQN4mpie(u"࠹ᶋ"))
			if any(value in z6FysMQJTa2IWYdrDx7BjObwN3fE for value in Voyqwkr1g8BY2LJXz3u) and z6FysMQJTa2IWYdrDx7BjObwN3fE not in [wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭วฯำ์ࠫ᲋")]: fnogyzNA30JCPMYqHTavG7ZKp.append(ssynAg0zhSkoCpOMDV9(u"࠻ᶌ"))
			if any(value in z6FysMQJTa2IWYdrDx7BjObwN3fE for value in TCaXknulADmyZLGR): fnogyzNA30JCPMYqHTavG7ZKp.append(sJw9QWiq1Kr0xfeVRI(u"࠽ᶍ"))
			if any(value in z6FysMQJTa2IWYdrDx7BjObwN3fE for value in MJo4lhHT0UX1WSkdB): fnogyzNA30JCPMYqHTavG7ZKp.append(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠿ᶎ"))
			if any(value in z6FysMQJTa2IWYdrDx7BjObwN3fE for value in W5GXTut6oEpMHARlir): fnogyzNA30JCPMYqHTavG7ZKp.append(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠱࠱ᶏ"))
			if any(value in z6FysMQJTa2IWYdrDx7BjObwN3fE for value in UU7plHM0k63OgSeERdJF5GVa8j9wxn): fnogyzNA30JCPMYqHTavG7ZKp.append(EE1jeHnIoad(u"࠲࠳ᶐ"))
			if any(value in z6FysMQJTa2IWYdrDx7BjObwN3fE for value in A3AOYdpC0RjlhsuKMGIVNqF94EBbZm): fnogyzNA30JCPMYqHTavG7ZKp.append(FmYoGejTnwKME7d9zPc(u"࠳࠵ᶑ"))
			if any(value in z6FysMQJTa2IWYdrDx7BjObwN3fE for value in rMYmCApR3QHFOx2): fnogyzNA30JCPMYqHTavG7ZKp.append(uulNDCPyef78(u"࠴࠷ᶒ"))
			if any(value in z6FysMQJTa2IWYdrDx7BjObwN3fE for value in XX7Onvbwzme2yc): fnogyzNA30JCPMYqHTavG7ZKp.append(ssynAg0zhSkoCpOMDV9(u"࠵࠹ᶓ"))
			if any(value in z6FysMQJTa2IWYdrDx7BjObwN3fE for value in V4LlOS8gqBihRtbf): fnogyzNA30JCPMYqHTavG7ZKp.append(N6NGJ4vpmidqMCh7yo(u"࠶࠻ᶔ"))
			if any(value in z6FysMQJTa2IWYdrDx7BjObwN3fE for value in uEyU2e6lv4): fnogyzNA30JCPMYqHTavG7ZKp.append(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠷࠶ᶕ"))
			if any(value in z6FysMQJTa2IWYdrDx7BjObwN3fE for value in skOzc8ZUSRI6K1eoAMtgPnHEyTwj): fnogyzNA30JCPMYqHTavG7ZKp.append(EE1jeHnIoad(u"࠱࠸ᶖ"))
			if any(value in z6FysMQJTa2IWYdrDx7BjObwN3fE for value in uzRKehkJFox2CcDbMvTNVgBP6SZLG): fnogyzNA30JCPMYqHTavG7ZKp.append(FgXzMs0YSDt(u"࠲࠺ᶗ"))
			if not fnogyzNA30JCPMYqHTavG7ZKp: fnogyzNA30JCPMYqHTavG7ZKp = [wdftVMyzF17cYETHu(u"࠳࠼ᶘ")]
			for MmJTgOuqvRBkLEKt in fnogyzNA30JCPMYqHTavG7ZKp:
				if str(MmJTgOuqvRBkLEKt)==lqVQbuCkKFS1stcE9:
					OZD1l4pAMzeH(wdftVMyzF17cYETHu(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᲌"),K2l9rLfvoXxyZ4NYapO+z36flodJVD9jWxip14Rh,z36flodJVD9jWxip14Rh,sJw9QWiq1Kr0xfeVRI(u"࠴࠺࠻ᶙ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,N5vAmntUE3+OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᲍"))
	ZBILqw92kAymRHD7GstV(cJsR8uCmEQpkzg2AyZXo1,cJsR8uCmEQpkzg2AyZXo1,LLvswCIAk0tubrKgFpPW4BVf)
	return
def OO3brvsDGCkJU(FAVmIEYX4o3xJ8cdh,JJnVRkiCSuK1D):
	vUTCBmuRD025KJ = LhFAGlQ19zr
	if vUTCBmuRD025KJ:
		OZD1l4pAMzeH(uulNDCPyef78(u"ࠩ࡯࡭ࡳࡱࠧ᲎"),vU6DxuzPwMpg(u"ࠪฮาี๊ฬࠢๅหห๋ษࠡลๅืฬ๋ࠠࡊࡒࡗ࡚ࠬ᲏"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠻࠻࠺ᶚ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,wdftVMyzF17cYETHu(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩᲐ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,{Gcw2nelTR864XCVruO3mAFqI5a(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᲑ"):FAVmIEYX4o3xJ8cdh})
		OZD1l4pAMzeH(sIzDXlTHYUC5L3xZGnr(u"࠭࡬ࡪࡰ࡮ࠫᲒ"),n0nFOd4yR97fQzNLSW+FmYoGejTnwKME7d9zPc(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬᲓ")+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,FmYoGejTnwKME7d9zPc(u"࠾࠿࠹࠺ᶛ"))
	zcyQMjL09tm8UKbEfN1RBXgFkH = I4t9qonjrm.menuItemsLIST[:]
	import z1qJk2AYoC
	if FAVmIEYX4o3xJ8cdh:
		if not z1qJk2AYoC.dt5U3cZpCFGRHDue7a1(FAVmIEYX4o3xJ8cdh,EsCplGc5N4mBuYW0RVQt6b): return
		DDWtUqTzXcBCya = jj1GJ7YuwylqmzSUBrEb(FAVmIEYX4o3xJ8cdh,JJnVRkiCSuK1D)
		VB3NKdsqvfAJYEWljanku8 = sorted(DDWtUqTzXcBCya,reverse=LhFAGlQ19zr,key=lambda key: key[BkM54Kr7Qbqn].lower())
	else:
		if not z1qJk2AYoC.dt5U3cZpCFGRHDue7a1(fy8iFgEkrO12NR9TWBI35sjY6qHvV,EsCplGc5N4mBuYW0RVQt6b): return
		if vUTCBmuRD025KJ and jL5CrsRwebpyDVXUc1EQP(u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭Ე") not in JJnVRkiCSuK1D:
			VB3NKdsqvfAJYEWljanku8 = rIhXWK91vRuC(jUCABmLYMf0G,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠩ࡯࡭ࡸࡺࠧᲕ"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࠪᲖ"),SnhLjmfeJC(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࡣࡆࡒࡌࠨᲗ"))
		else:
			U07UgjlknuDA4,VB3NKdsqvfAJYEWljanku8,DDWtUqTzXcBCya = [],[],[]
			for fxo3Q1FjS508DNbER7H in range(BkM54Kr7Qbqn,gaUFPm1MLjDJ2lVecEuYI+BkM54Kr7Qbqn):
				VB3NKdsqvfAJYEWljanku8 += jj1GJ7YuwylqmzSUBrEb(str(fxo3Q1FjS508DNbER7H),JJnVRkiCSuK1D)
			for type,z36flodJVD9jWxip14Rh,url,hO3D6GVPY2qENv8bZWH,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YMaiHbnIThsP7q,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW in VB3NKdsqvfAJYEWljanku8:
				if YMaiHbnIThsP7q not in U07UgjlknuDA4:
					U07UgjlknuDA4.append(YMaiHbnIThsP7q)
					OxHEA17NcF = type,z36flodJVD9jWxip14Rh,YMaiHbnIThsP7q,vU6DxuzPwMpg(u"࠷࠶࠶ᶜ"),mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,JJnVRkiCSuK1D,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW
					DDWtUqTzXcBCya.append(OxHEA17NcF)
			VB3NKdsqvfAJYEWljanku8 = sorted(DDWtUqTzXcBCya,reverse=LhFAGlQ19zr,key=lambda key: key[BkM54Kr7Qbqn].lower())
			if vUTCBmuRD025KJ: tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬᲘ"),oRJAfwD957WkUyBM1Ehu8m(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࡁࡍࡎࠪᲙ"),VB3NKdsqvfAJYEWljanku8,zz2tnLhI1QHV7GwFCrv5)
	I4t9qonjrm.menuItemsLIST[:] = zcyQMjL09tm8UKbEfN1RBXgFkH+VB3NKdsqvfAJYEWljanku8
	ejX7kGtQ4hcYUHW9b31vriuZLM6Sp(LhFAGlQ19zr)
	return
def aCFYnzMTlGwe8(FAVmIEYX4o3xJ8cdh,JJnVRkiCSuK1D):
	vUTCBmuRD025KJ = LhFAGlQ19zr
	if vUTCBmuRD025KJ:
		OZD1l4pAMzeH(KfHAW8VGbrxi(u"ࠧ࡭࡫ࡱ࡯ࠬᲚ"),o1INZ3ViQqS0Uw5z6kMjbv(u"ࠨฬะำ๏ัࠠใษษ้ฮࠦรใีส้ࠥࡓ࠳ࡖࠩᲛ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠷࠷࠷ᶝ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,wdftVMyzF17cYETHu(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧᲜ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,{aOQTKXFL54Nl60Zhp3MbE(u"ࠪࡪࡴࡲࡤࡦࡴࠪᲝ"):FAVmIEYX4o3xJ8cdh})
		OZD1l4pAMzeH(FmYoGejTnwKME7d9zPc(u"ࠫࡱ࡯࡮࡬ࠩᲞ"),n0nFOd4yR97fQzNLSW+LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪᲟ")+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ggjO5CrKVRPITaesWkxD(u"࠺࠻࠼࠽ᶞ"))
	zcyQMjL09tm8UKbEfN1RBXgFkH = I4t9qonjrm.menuItemsLIST[:]
	import ucJU0YkpTS
	if FAVmIEYX4o3xJ8cdh:
		if not ucJU0YkpTS.dt5U3cZpCFGRHDue7a1(FAVmIEYX4o3xJ8cdh,EsCplGc5N4mBuYW0RVQt6b): return
		DDWtUqTzXcBCya = dDF5SoYiLMpBl4b(FAVmIEYX4o3xJ8cdh,JJnVRkiCSuK1D)
		VB3NKdsqvfAJYEWljanku8 = sorted(DDWtUqTzXcBCya,reverse=LhFAGlQ19zr,key=lambda key: key[BkM54Kr7Qbqn].lower())
	else:
		if not ucJU0YkpTS.dt5U3cZpCFGRHDue7a1(fy8iFgEkrO12NR9TWBI35sjY6qHvV,EsCplGc5N4mBuYW0RVQt6b): return
		if vUTCBmuRD025KJ and EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫᲠ") not in JJnVRkiCSuK1D:
			VB3NKdsqvfAJYEWljanku8 = rIhXWK91vRuC(jUCABmLYMf0G,KfHAW8VGbrxi(u"ࠧ࡭࡫ࡶࡸࠬᲡ"),CsDcLqQUVK4YBvHFW1(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛ࠧᲢ"),sIzDXlTHYUC5L3xZGnr(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࡃࡏࡐࠬᲣ"))
		else:
			U07UgjlknuDA4,VB3NKdsqvfAJYEWljanku8,DDWtUqTzXcBCya = [],[],[]
			for fxo3Q1FjS508DNbER7H in range(BkM54Kr7Qbqn,gaUFPm1MLjDJ2lVecEuYI+BkM54Kr7Qbqn):
				VB3NKdsqvfAJYEWljanku8 += dDF5SoYiLMpBl4b(str(fxo3Q1FjS508DNbER7H),JJnVRkiCSuK1D)
			for type,z36flodJVD9jWxip14Rh,url,hO3D6GVPY2qENv8bZWH,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YMaiHbnIThsP7q,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW in VB3NKdsqvfAJYEWljanku8:
				if YMaiHbnIThsP7q not in U07UgjlknuDA4:
					U07UgjlknuDA4.append(YMaiHbnIThsP7q)
					OxHEA17NcF = type,z36flodJVD9jWxip14Rh,YMaiHbnIThsP7q,QjAINyUC7MDRq5d8e4vl9(u"࠳࠹࠹ᶟ"),mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,JJnVRkiCSuK1D,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW
					DDWtUqTzXcBCya.append(OxHEA17NcF)
			VB3NKdsqvfAJYEWljanku8 = sorted(DDWtUqTzXcBCya,reverse=LhFAGlQ19zr,key=lambda key: key[BkM54Kr7Qbqn].lower())
			if vUTCBmuRD025KJ: tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,QjAINyUC7MDRq5d8e4vl9(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࠩᲤ"),sJw9QWiq1Kr0xfeVRI(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࡅࡑࡒࠧᲥ"),VB3NKdsqvfAJYEWljanku8,zz2tnLhI1QHV7GwFCrv5)
	I4t9qonjrm.menuItemsLIST[:] = zcyQMjL09tm8UKbEfN1RBXgFkH+VB3NKdsqvfAJYEWljanku8
	ejX7kGtQ4hcYUHW9b31vriuZLM6Sp(LhFAGlQ19zr)
	return
def wIk2nhr5JQs7OdG(group,JJnVRkiCSuK1D):
	vUTCBmuRD025KJ = LhFAGlQ19zr
	OmsWt89dSA5HyCZ4wL = []
	LG4Yay1tsePjQuwBCoNpqkOif = ggjO5CrKVRPITaesWkxD(u"ࠬࡥࡉࡑࡖ࡙ࡣࠬᲦ") if Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠭ࡉࡑࡖ࡙ࠫᲧ") in JJnVRkiCSuK1D else PlpyFa9QMKXxOD1cvHzmI(u"ࠧࡠࡏ࠶࡙ࡤ࠭Შ")
	if vUTCBmuRD025KJ: OmsWt89dSA5HyCZ4wL = rIhXWK91vRuC(jUCABmLYMf0G,Gcw2nelTR864XCVruO3mAFqI5a(u"ࠨ࡮࡬ࡷࡹ࠭Ჩ"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࠫᲪ")+LG4Yay1tsePjQuwBCoNpqkOif[:-BkM54Kr7Qbqn],group)
	if not OmsWt89dSA5HyCZ4wL:
		for FAVmIEYX4o3xJ8cdh in range(BkM54Kr7Qbqn,gaUFPm1MLjDJ2lVecEuYI+BkM54Kr7Qbqn):
			if vUTCBmuRD025KJ: OmsWt89dSA5HyCZ4wL += rIhXWK91vRuC(jUCABmLYMf0G,LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠪࡰ࡮ࡹࡴࠨᲫ"),ggjO5CrKVRPITaesWkxD(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘ࠭Წ")+LG4Yay1tsePjQuwBCoNpqkOif[:-BkM54Kr7Qbqn],FmYoGejTnwKME7d9zPc(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙ࠧᲭ")+LG4Yay1tsePjQuwBCoNpqkOif+str(FAVmIEYX4o3xJ8cdh))
			elif LG4Yay1tsePjQuwBCoNpqkOif==Hr25gta6XcqO(u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭Ხ"): OmsWt89dSA5HyCZ4wL += jj1GJ7YuwylqmzSUBrEb(str(FAVmIEYX4o3xJ8cdh),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᲯ"))
			elif LG4Yay1tsePjQuwBCoNpqkOif==aOQTKXFL54Nl60Zhp3MbE(u"ࠨࡡࡐ࠷࡚ࡥࠧᲰ"): OmsWt89dSA5HyCZ4wL += dDF5SoYiLMpBl4b(str(FAVmIEYX4o3xJ8cdh),QjAINyUC7MDRq5d8e4vl9(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧᲱ"))
		for type,z36flodJVD9jWxip14Rh,url,hO3D6GVPY2qENv8bZWH,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YMaiHbnIThsP7q,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW in OmsWt89dSA5HyCZ4wL:
			if YMaiHbnIThsP7q==group: KYAmF1b4205(type,z36flodJVD9jWxip14Rh,url,hO3D6GVPY2qENv8bZWH,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YMaiHbnIThsP7q,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW)
		items,w7gedkFbJvcqu0fzW43NpyUP = [],[]
		for type,z36flodJVD9jWxip14Rh,url,hO3D6GVPY2qENv8bZWH,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YMaiHbnIThsP7q,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW in I4t9qonjrm.menuItemsLIST:
			I39yknbgp0aAU = type,z36flodJVD9jWxip14Rh[vD4Fh6ictZ7wME:],url,hO3D6GVPY2qENv8bZWH,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YMaiHbnIThsP7q,vBs70HtgMbzd6n3NwUpxe,fy8iFgEkrO12NR9TWBI35sjY6qHvV
			if I39yknbgp0aAU not in w7gedkFbJvcqu0fzW43NpyUP:
				w7gedkFbJvcqu0fzW43NpyUP.append(I39yknbgp0aAU)
				j25T6eKhaMk3 = type,z36flodJVD9jWxip14Rh,url,hO3D6GVPY2qENv8bZWH,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YMaiHbnIThsP7q,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW
				items.append(j25T6eKhaMk3)
		OmsWt89dSA5HyCZ4wL = sorted(items,reverse=LhFAGlQ19zr,key=lambda key: key[BkM54Kr7Qbqn].lower()[ssynAg0zhSkoCpOMDV9(u"࠸ᶠ"):])
		if vUTCBmuRD025KJ: tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,FmYoGejTnwKME7d9zPc(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࠬᲲ")+LG4Yay1tsePjQuwBCoNpqkOif[:-BkM54Kr7Qbqn],group,OmsWt89dSA5HyCZ4wL,zz2tnLhI1QHV7GwFCrv5)
	if Hr25gta6XcqO(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭Ჳ") in JJnVRkiCSuK1D and len(OmsWt89dSA5HyCZ4wL)>webrl8sY4tSqx:
		I4t9qonjrm.menuItemsLIST[:] = []
		OZD1l4pAMzeH(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᲴ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࡛࠭ࠨᲵ")+n0nFOd4yR97fQzNLSW+group+T7ASIp1ZYwio9HQ8cObJK+FmYoGejTnwKME7d9zPc(u"ࠧࠡ࠼ส่็ูๅ࡞ࠩᲶ"),group,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠵࠻࠻ᶡ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LG4Yay1tsePjQuwBCoNpqkOif+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᲷ"))
		OZD1l4pAMzeH(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠩࡩࡳࡱࡪࡥࡳࠩᲸ"),Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩᲹ"),group,ssynAg0zhSkoCpOMDV9(u"࠶࠼࠵ᶢ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LG4Yay1tsePjQuwBCoNpqkOif+PlpyFa9QMKXxOD1cvHzmI(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᲺ"))
		OZD1l4pAMzeH(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬࡲࡩ࡯࡭ࠪ᲻"),n0nFOd4yR97fQzNLSW+o1INZ3ViQqS0Uw5z6kMjbv(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫ᲼")+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,uulNDCPyef78(u"࠿࠹࠺࠻ᶣ"))
		OmsWt89dSA5HyCZ4wL = I4t9qonjrm.menuItemsLIST+yiTBYwps2mCrb4jGPux0cIJ.sample(OmsWt89dSA5HyCZ4wL,webrl8sY4tSqx)
	I4t9qonjrm.menuItemsLIST[:] = OmsWt89dSA5HyCZ4wL
	ejX7kGtQ4hcYUHW9b31vriuZLM6Sp(LhFAGlQ19zr)
	return
def qD21UpkXs5IcKJYGR8tNfPEi(JJnVRkiCSuK1D):
	OZD1l4pAMzeH(O3OVuapf0YFjbm5oUQDg(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᲽ"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠨว฼หิฯุࠠๆหࠤ็์่ศฬࠣ฽ู๎วว์ฬࠫᲾ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,FgXzMs0YSDt(u"࠱࠷࠳ᶤ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Gcw2nelTR864XCVruO3mAFqI5a(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡍࡋ࡙ࡉ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࠩᲿ"))
	OZD1l4pAMzeH(FmYoGejTnwKME7d9zPc(u"ࠪࡰ࡮ࡴ࡫ࠨ᳀"),n0nFOd4yR97fQzNLSW+FgXzMs0YSDt(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩ᳁")+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,o1INZ3ViQqS0Uw5z6kMjbv(u"࠺࠻࠼࠽ᶥ"))
	GIOLnhec0SQCP9vNUzVDYZjiWXd5m1 = I4t9qonjrm.menuItemsLIST[:]
	I4t9qonjrm.menuItemsLIST[:] = []
	import wwrEgQvVxo
	wwrEgQvVxo.zY53X6dEGkqnhmUDJ20rpbR8(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬ࠶ࠧ᳂"),LhFAGlQ19zr)
	wwrEgQvVxo.zY53X6dEGkqnhmUDJ20rpbR8(Hr25gta6XcqO(u"࠭࠱ࠨ᳃"),LhFAGlQ19zr)
	wwrEgQvVxo.zY53X6dEGkqnhmUDJ20rpbR8(aOQTKXFL54Nl60Zhp3MbE(u"ࠧ࠳ࠩ᳄"),LhFAGlQ19zr)
	if OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪ᳅") in JJnVRkiCSuK1D:
		I4t9qonjrm.menuItemsLIST[:] = JQevh5MmuIabrsxF4R3iE2TLHWpgo(I4t9qonjrm.menuItemsLIST)
		if len(I4t9qonjrm.menuItemsLIST)>webrl8sY4tSqx: I4t9qonjrm.menuItemsLIST[:] = yiTBYwps2mCrb4jGPux0cIJ.sample(I4t9qonjrm.menuItemsLIST,webrl8sY4tSqx)
	I4t9qonjrm.menuItemsLIST[:] = GIOLnhec0SQCP9vNUzVDYZjiWXd5m1+I4t9qonjrm.menuItemsLIST
	return
def Nsf37dTnjRU(JJnVRkiCSuK1D):
	JJnVRkiCSuK1D = JJnVRkiCSuK1D.replace(FmYoGejTnwKME7d9zPc(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ᳆"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ᳇"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	headers = { QjAINyUC7MDRq5d8e4vl9(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ᳈") : fy8iFgEkrO12NR9TWBI35sjY6qHvV }
	url = C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡦࡪࡹࡴࡳࡣࡱࡨࡴࡳࡳ࠯ࡥࡲࡱ࠴ࡸࡡ࡯ࡦࡲࡱ࠲ࡧࡲࡢࡤ࡬ࡧ࠲ࡽ࡯ࡳࡦࡶࠫ᳉")
	data = {wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭ࡱࡶࡣࡱࡸ࡮ࡺࡹࠨ᳊"):V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠧ࠶࠲ࠪ᳋")}
	data = YYpHcWVqImGPU4LXM(data)
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(D1KfvmcCjGYbgSoyX,jL5CrsRwebpyDVXUc1EQP(u"ࠨࡉࡈࡘࠬ᳌"),url,data,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,AAbvaXV2DQzfNHdm4U3tT(u"ࠩࡕࡅࡓࡊࡏࡎࡕ࠰ࡖࡆࡔࡄࡐࡏࡢ࡚ࡎࡊࡅࡐࡕࡢࡊࡗࡕࡍࡠ࡙ࡒࡖࡉ࡙࠭࠲ࡵࡷࠫ᳍"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall(ggjO5CrKVRPITaesWkxD(u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡦࡰࡪࡧࡲࡧ࡫ࡻࠦࠬ᳎"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	items = EcQxOa3RJm86WjTKA.findall(I18uSKaWhgTBeYUPD4sr(u"ࠫࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ᳏"),wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	O1hfHcrBj06yzZbRS,jO3lpS19MJoBTX5IF = list(zip(*items))
	MMIEA5CDSdrWcBu3wqojOZH14gyV7 = []
	PRvnUkhXmBtsTa0KIG4Yogj9 = [ksJdoFWhxTz8Y2N7bOZE,sJw9QWiq1Kr0xfeVRI(u"ࠬࠨࠧ᳐"),N6NGJ4vpmidqMCh7yo(u"࠭ࡠࠨ᳑"),sIzDXlTHYUC5L3xZGnr(u"ࠧ࠭ࠩ᳒"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨ࠰ࠪ᳓"),uulNDCPyef78(u"ࠩ࠽᳔ࠫ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪ࠿᳕ࠬ"),aOQTKXFL54Nl60Zhp3MbE(u"ࠦࠬࠨ᳖"),O3OVuapf0YFjbm5oUQDg(u"ࠬ࠳᳗ࠧ")]
	hTW2dQIoJ3PAzuwXV46lLct = jO3lpS19MJoBTX5IF+O1hfHcrBj06yzZbRS
	for ZZJYHnAEBca1P in hTW2dQIoJ3PAzuwXV46lLct:
		if ZZJYHnAEBca1P in jO3lpS19MJoBTX5IF: WbYBPQd8G1NcziMOswpVFAr = teaC5j4HuGDqpwcmUzJ
		if ZZJYHnAEBca1P in O1hfHcrBj06yzZbRS: WbYBPQd8G1NcziMOswpVFAr = vD4Fh6ictZ7wME
		UkiLKM74mD0B = [pk6YWixXFSrDLKCnlN39w in ZZJYHnAEBca1P for pk6YWixXFSrDLKCnlN39w in PRvnUkhXmBtsTa0KIG4Yogj9]
		if any(UkiLKM74mD0B):
			KKb4FNO1DIREh = UkiLKM74mD0B.index(EsCplGc5N4mBuYW0RVQt6b)
			sEdBKTQ1IwGnfri5OphqM = PRvnUkhXmBtsTa0KIG4Yogj9[KKb4FNO1DIREh]
			CuJI0PM53lyqpRwKSjBdv7mc8rT1 = fy8iFgEkrO12NR9TWBI35sjY6qHvV
			if ZZJYHnAEBca1P.count(sEdBKTQ1IwGnfri5OphqM)>BkM54Kr7Qbqn: zcGtuDK2rh,a4TtPjM7Iv5rzG98kmCpudOVAXnLsQ,CuJI0PM53lyqpRwKSjBdv7mc8rT1 = ZZJYHnAEBca1P.split(sEdBKTQ1IwGnfri5OphqM,teaC5j4HuGDqpwcmUzJ)
			else: zcGtuDK2rh,a4TtPjM7Iv5rzG98kmCpudOVAXnLsQ = ZZJYHnAEBca1P.split(sEdBKTQ1IwGnfri5OphqM,BkM54Kr7Qbqn)
			if len(zcGtuDK2rh)>WbYBPQd8G1NcziMOswpVFAr: MMIEA5CDSdrWcBu3wqojOZH14gyV7.append(zcGtuDK2rh.lower())
			if len(a4TtPjM7Iv5rzG98kmCpudOVAXnLsQ)>WbYBPQd8G1NcziMOswpVFAr: MMIEA5CDSdrWcBu3wqojOZH14gyV7.append(a4TtPjM7Iv5rzG98kmCpudOVAXnLsQ.lower())
			if len(CuJI0PM53lyqpRwKSjBdv7mc8rT1)>WbYBPQd8G1NcziMOswpVFAr: MMIEA5CDSdrWcBu3wqojOZH14gyV7.append(CuJI0PM53lyqpRwKSjBdv7mc8rT1.lower())
		elif len(ZZJYHnAEBca1P)>WbYBPQd8G1NcziMOswpVFAr: MMIEA5CDSdrWcBu3wqojOZH14gyV7.append(ZZJYHnAEBca1P.lower())
	for pk6YWixXFSrDLKCnlN39w in range(aOQTKXFL54Nl60Zhp3MbE(u"࠻ᶦ")): yiTBYwps2mCrb4jGPux0cIJ.shuffle(MMIEA5CDSdrWcBu3wqojOZH14gyV7)
	if EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭࡟ࡔࡋࡗࡉࡘࡥ᳘ࠧ") in JJnVRkiCSuK1D:
		rje925LWbRvztOlDydC1Yw = GgeKIqHm8XM
	elif ggjO5CrKVRPITaesWkxD(u"ࠧࡠࡋࡓࡘ࡛ࡥ᳙ࠧ") in JJnVRkiCSuK1D:
		rje925LWbRvztOlDydC1Yw = [aOQTKXFL54Nl60Zhp3MbE(u"ࠨࡋࡓࡘ࡛࠭᳚")]
		import z1qJk2AYoC
		if not z1qJk2AYoC.dt5U3cZpCFGRHDue7a1(fy8iFgEkrO12NR9TWBI35sjY6qHvV,EsCplGc5N4mBuYW0RVQt6b): return
	elif Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠩࡢࡑ࠸࡛࡟ࠨ᳛") in JJnVRkiCSuK1D:
		rje925LWbRvztOlDydC1Yw = [OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪࡑ࠸࡛᳜ࠧ")]
		import ucJU0YkpTS
		if not ucJU0YkpTS.dt5U3cZpCFGRHDue7a1(fy8iFgEkrO12NR9TWBI35sjY6qHvV,EsCplGc5N4mBuYW0RVQt6b): return
	count,JjMuhnpE6tiRdwrSgWlf780boU9 = D2D96X5NGamBhrFwvL8VEbqiSfZIl,D2D96X5NGamBhrFwvL8VEbqiSfZIl
	OZD1l4pAMzeH(ssynAg0zhSkoCpOMDV9(u"ࠫ࡫ࡵ࡬ࡥࡧࡵ᳝ࠫ"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬࡡࠠࠡ࡟ࠣ࠾ฬ๊ศฮอࠣ฽๋᳞࠭"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,AAbvaXV2DQzfNHdm4U3tT(u"࠴࠺࠹ᶧ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,aOQTKXFL54Nl60Zhp3MbE(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢ᳟ࠫ")+JJnVRkiCSuK1D)
	OZD1l4pAMzeH(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᳠"),KfHAW8VGbrxi(u"ࠨว฼หิฯࠠศๆหัะࠦวๅ฻ื์ฬฬ๊ࠨ᳡"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,FgXzMs0YSDt(u"࠵࠻࠺ᶨ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥ᳢ࠧ")+JJnVRkiCSuK1D)
	OZD1l4pAMzeH(LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠪࡰ࡮ࡴ࡫ࠨ᳣"),n0nFOd4yR97fQzNLSW+OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽᳤ࠡࠩ")+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠾࠿࠹࠺ᶩ"))
	Uo5bukFpzSDQjgZyLX3m861J = I4t9qonjrm.menuItemsLIST[:]
	I4t9qonjrm.menuItemsLIST[:] = []
	sRcPWevjuidpyrS9NgkwLb2OIG4E = []
	for ZZJYHnAEBca1P in MMIEA5CDSdrWcBu3wqojOZH14gyV7:
		a4TtPjM7Iv5rzG98kmCpudOVAXnLsQ = EcQxOa3RJm86WjTKA.findall(oRJAfwD957WkUyBM1Ehu8m(u"ࠬࡡࠠ࡝࠮࡟࠿ࡡࡀ࡜࠮࡞࠮ࡠࡂࡢࠢ࡝ࠩ࡟࡟ࡡࡣ࡜ࠩ࡞ࠬࡠࢀࡢࡽ࡝ࠣ࡟ࡄ᳥ࠬ")+ggjO5CrKVRPITaesWkxD(u"࠭ࠣࠨ᳦")+PlpyFa9QMKXxOD1cvHzmI(u"ࠧ࡝ࠦ࡟ࠩࡡࡤ࡜ࠧ࡞࠭ࡠࡤࡢ࠼࡝ࡀࡠ᳧ࠫ"),ZZJYHnAEBca1P,EcQxOa3RJm86WjTKA.DOTALL)
		if a4TtPjM7Iv5rzG98kmCpudOVAXnLsQ: ZZJYHnAEBca1P = ZZJYHnAEBca1P.split(a4TtPjM7Iv5rzG98kmCpudOVAXnLsQ[D2D96X5NGamBhrFwvL8VEbqiSfZIl],BkM54Kr7Qbqn)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		MMBrj5cIWU3hGnlVqCtNJSfdZ9 = ZZJYHnAEBca1P.replace(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠨ๓᳨ࠪ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(Hr25gta6XcqO(u"ࠩ๑ࠫᳩ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(jL5CrsRwebpyDVXUc1EQP(u"ࠪ๏ࠬᳪ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(KfHAW8VGbrxi(u"ࠫ๔࠭ᳫ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(KfHAW8VGbrxi(u"ࠬ๒ࠧᳬ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		MMBrj5cIWU3hGnlVqCtNJSfdZ9 = MMBrj5cIWU3hGnlVqCtNJSfdZ9.replace(s5WMHyQN4mpie(u"࠭๐ࠨ᳭"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(oRJAfwD957WkUyBM1Ehu8m(u"ࠧ๎ࠩᳮ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(AAbvaXV2DQzfNHdm4U3tT(u"ࠨ๔ࠪᳯ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠩฏࠫᳰ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪไࠬᳱ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		if MMBrj5cIWU3hGnlVqCtNJSfdZ9: sRcPWevjuidpyrS9NgkwLb2OIG4E.append(MMBrj5cIWU3hGnlVqCtNJSfdZ9)
	eWcvrsghzGK0BxLRYEZo = []
	for b3b24XZTV7gW9mhcqLoCnftO in range(D2D96X5NGamBhrFwvL8VEbqiSfZIl,O3OVuapf0YFjbm5oUQDg(u"࠸࠰ᶪ")):
		search = yiTBYwps2mCrb4jGPux0cIJ.sample(sRcPWevjuidpyrS9NgkwLb2OIG4E,BkM54Kr7Qbqn)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		if search in eWcvrsghzGK0BxLRYEZo: continue
		eWcvrsghzGK0BxLRYEZo.append(search)
		C0C4kdG53sPAbNq8OBMpitLThHl = yiTBYwps2mCrb4jGPux0cIJ.sample(rje925LWbRvztOlDydC1Yw,BkM54Kr7Qbqn)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡗ࡫ࡧࡩࡴࠦࡓࡦࡣࡵࡧ࡭ࠦࠠࠡࡵ࡬ࡸࡪࡀࠧᳲ")+str(C0C4kdG53sPAbNq8OBMpitLThHl)+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬࠦࠠࡴࡧࡤࡶࡨ࡮࠺ࠨᳳ")+search)
		i4YeIfAFjZkScx5RXLNGd96V,DDmgX24QRqwcVnez8GyP,rk0648WzSs7byUiKvRo5I1nBYPTMd = vjM9sANcTkUJViCD4PpBza0lH(C0C4kdG53sPAbNq8OBMpitLThHl)
		DDmgX24QRqwcVnez8GyP(search+ssynAg0zhSkoCpOMDV9(u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫ᳴"))
		if len(I4t9qonjrm.menuItemsLIST)>D2D96X5NGamBhrFwvL8VEbqiSfZIl: break
	search = search.replace(PlpyFa9QMKXxOD1cvHzmI(u"ࠧࡠࡏࡒࡈࡤ࠭ᳵ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	Uo5bukFpzSDQjgZyLX3m861J[D2D96X5NGamBhrFwvL8VEbqiSfZIl][BkM54Kr7Qbqn] = O3OVuapf0YFjbm5oUQDg(u"ࠨ࡝ࠪᳶ")+n0nFOd4yR97fQzNLSW+search+T7ASIp1ZYwio9HQ8cObJK+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠩࠣ࠾อำหࠡ฻้ࡡࠬ᳷")
	I4t9qonjrm.menuItemsLIST[:] = JQevh5MmuIabrsxF4R3iE2TLHWpgo(I4t9qonjrm.menuItemsLIST)
	if len(I4t9qonjrm.menuItemsLIST)>webrl8sY4tSqx: I4t9qonjrm.menuItemsLIST[:] = yiTBYwps2mCrb4jGPux0cIJ.sample(I4t9qonjrm.menuItemsLIST,webrl8sY4tSqx)
	I4t9qonjrm.menuItemsLIST[:] = Uo5bukFpzSDQjgZyLX3m861J+I4t9qonjrm.menuItemsLIST
	return
def vzoZUeac9xlt8Ig0SPbTkOp7dAw(gDvlbfkGJBqedrYZRsFoO5XAEQpmV,JJnVRkiCSuK1D):
	gDvlbfkGJBqedrYZRsFoO5XAEQpmV = gDvlbfkGJBqedrYZRsFoO5XAEQpmV.replace(vU6DxuzPwMpg(u"ࠪࡣࡒࡕࡄࡠࠩ᳸"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	JJnVRkiCSuK1D = JJnVRkiCSuK1D.replace(FgXzMs0YSDt(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭᳹"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(s5WMHyQN4mpie(u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᳺ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	C73G5sA6jdLxX4E(LhFAGlQ19zr)
	if not kkFqaJz6KAmfdQlTIYvpNiUBhZ1: return
	if oRJAfwD957WkUyBM1Ehu8m(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ᳻") in JJnVRkiCSuK1D:
		OZD1l4pAMzeH(O3OVuapf0YFjbm5oUQDg(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᳼"),uulNDCPyef78(u"ࠨ࡝ࠪ᳽")+n0nFOd4yR97fQzNLSW+gDvlbfkGJBqedrYZRsFoO5XAEQpmV+T7ASIp1ZYwio9HQ8cObJK+sJw9QWiq1Kr0xfeVRI(u"ࠩࠣ࠾ฬ๊โิ็ࡠࠫ᳾"),gDvlbfkGJBqedrYZRsFoO5XAEQpmV,FmYoGejTnwKME7d9zPc(u"࠱࠷࠸ᶫ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,N6NGJ4vpmidqMCh7yo(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᳿")+JJnVRkiCSuK1D)
		OZD1l4pAMzeH(jL5CrsRwebpyDVXUc1EQP(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᴀ"),s5WMHyQN4mpie(u"ࠬหูศัฬࠤฬ๊ืๅสࠣห้฿ิ้ษษ๎๋ࠥๆ่ࠡไืࠥอไใี่ࠫᴁ"),gDvlbfkGJBqedrYZRsFoO5XAEQpmV,Gcw2nelTR864XCVruO3mAFqI5a(u"࠲࠸࠹ᶬ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,wdftVMyzF17cYETHu(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᴂ")+JJnVRkiCSuK1D)
		OZD1l4pAMzeH(PlpyFa9QMKXxOD1cvHzmI(u"ࠧ࡭࡫ࡱ࡯ࠬᴃ"),n0nFOd4yR97fQzNLSW+PlpyFa9QMKXxOD1cvHzmI(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ᴄ")+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,o1INZ3ViQqS0Uw5z6kMjbv(u"࠻࠼࠽࠾ᶭ"))
	for website in sorted(list(kkFqaJz6KAmfdQlTIYvpNiUBhZ1[gDvlbfkGJBqedrYZRsFoO5XAEQpmV].keys())):
		type,z36flodJVD9jWxip14Rh,url,IeGPS8lnjLpR3JKVsOMyhHA9vd,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YMaiHbnIThsP7q,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW = kkFqaJz6KAmfdQlTIYvpNiUBhZ1[gDvlbfkGJBqedrYZRsFoO5XAEQpmV][website]
		if SnhLjmfeJC(u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫᴅ") in JJnVRkiCSuK1D or len(kkFqaJz6KAmfdQlTIYvpNiUBhZ1[gDvlbfkGJBqedrYZRsFoO5XAEQpmV])==BkM54Kr7Qbqn:
			KYAmF1b4205(type,fy8iFgEkrO12NR9TWBI35sjY6qHvV,url,IeGPS8lnjLpR3JKVsOMyhHA9vd,fy8iFgEkrO12NR9TWBI35sjY6qHvV,jmI9qRnVJo2a3tpcH8gfYkP,YMaiHbnIThsP7q,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			I4t9qonjrm.menuItemsLIST[:] = JQevh5MmuIabrsxF4R3iE2TLHWpgo(I4t9qonjrm.menuItemsLIST)
			zcyQMjL09tm8UKbEfN1RBXgFkH,VB3NKdsqvfAJYEWljanku8 = I4t9qonjrm.menuItemsLIST[:XW57OCeGnFTLQbaqdrD9zM],I4t9qonjrm.menuItemsLIST[XW57OCeGnFTLQbaqdrD9zM:]
			if sIzDXlTHYUC5L3xZGnr(u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬᴆ") in JJnVRkiCSuK1D:
				for pk6YWixXFSrDLKCnlN39w in range(KfHAW8VGbrxi(u"࠼ᶮ")): yiTBYwps2mCrb4jGPux0cIJ.shuffle(VB3NKdsqvfAJYEWljanku8)
				I4t9qonjrm.menuItemsLIST[:] = zcyQMjL09tm8UKbEfN1RBXgFkH+VB3NKdsqvfAJYEWljanku8[:webrl8sY4tSqx]
			else: I4t9qonjrm.menuItemsLIST[:] = zcyQMjL09tm8UKbEfN1RBXgFkH+VB3NKdsqvfAJYEWljanku8
		elif oRJAfwD957WkUyBM1Ehu8m(u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࠬᴇ") in JJnVRkiCSuK1D: OZD1l4pAMzeH(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᴈ"),website,url,IeGPS8lnjLpR3JKVsOMyhHA9vd,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YMaiHbnIThsP7q,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW)
	return
def U6skEDzGalypOIFNLVWtn(JJnVRkiCSuK1D,hO3D6GVPY2qENv8bZWH):
	JJnVRkiCSuK1D = JJnVRkiCSuK1D.replace(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᴉ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᴊ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	z36flodJVD9jWxip14Rh,VB3NKdsqvfAJYEWljanku8 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,[]
	OZD1l4pAMzeH(CsDcLqQUVK4YBvHFW1(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᴋ"),PlpyFa9QMKXxOD1cvHzmI(u"ࠩ࡞ࠫᴌ")+n0nFOd4yR97fQzNLSW+z36flodJVD9jWxip14Rh+T7ASIp1ZYwio9HQ8cObJK+FgXzMs0YSDt(u"ࠪࠤ࠿อไใี่ࡡࠬᴍ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,hO3D6GVPY2qENv8bZWH,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ssynAg0zhSkoCpOMDV9(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᴎ")+JJnVRkiCSuK1D)
	OZD1l4pAMzeH(jL5CrsRwebpyDVXUc1EQP(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᴏ"),Gcw2nelTR864XCVruO3mAFqI5a(u"࠭ลฺษาอࠥ฽ไษࠢๅืู๊ࠦี๊สส๏࠭ᴐ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,hO3D6GVPY2qENv8bZWH,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,FmYoGejTnwKME7d9zPc(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᴑ")+JJnVRkiCSuK1D)
	OZD1l4pAMzeH(FgXzMs0YSDt(u"ࠨ࡮࡬ࡲࡰ࠭ᴒ"),n0nFOd4yR97fQzNLSW+AAbvaXV2DQzfNHdm4U3tT(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧᴓ")+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,o1INZ3ViQqS0Uw5z6kMjbv(u"࠽࠾࠿࠹ᶯ"))
	zcyQMjL09tm8UKbEfN1RBXgFkH = I4t9qonjrm.menuItemsLIST[:]
	I4t9qonjrm.menuItemsLIST[:] = []
	OmsWt89dSA5HyCZ4wL = []
	if uulNDCPyef78(u"ࠪࡣࡘࡏࡔࡆࡕࡢࠫᴔ") in JJnVRkiCSuK1D:
		C73G5sA6jdLxX4E(LhFAGlQ19zr)
		if not kkFqaJz6KAmfdQlTIYvpNiUBhZ1: return
		jgbw3GD0L2tdVfuMWvzCoekYO = list(kkFqaJz6KAmfdQlTIYvpNiUBhZ1.keys())
		gDvlbfkGJBqedrYZRsFoO5XAEQpmV = yiTBYwps2mCrb4jGPux0cIJ.sample(jgbw3GD0L2tdVfuMWvzCoekYO,BkM54Kr7Qbqn)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		MMIEA5CDSdrWcBu3wqojOZH14gyV7 = list(kkFqaJz6KAmfdQlTIYvpNiUBhZ1[gDvlbfkGJBqedrYZRsFoO5XAEQpmV].keys())
		website = yiTBYwps2mCrb4jGPux0cIJ.sample(MMIEA5CDSdrWcBu3wqojOZH14gyV7,BkM54Kr7Qbqn)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		type,z36flodJVD9jWxip14Rh,url,IeGPS8lnjLpR3JKVsOMyhHA9vd,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YMaiHbnIThsP7q,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW = kkFqaJz6KAmfdQlTIYvpNiUBhZ1[gDvlbfkGJBqedrYZRsFoO5XAEQpmV][website]
		Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+s5WMHyQN4mpie(u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡼ࡫ࡢࡴ࡫ࡷࡩ࠿ࠦࠧᴕ")+website+CsDcLqQUVK4YBvHFW1(u"ࠬࠦࠠࠡࡰࡤࡱࡪࡀࠠࠨᴖ")+z36flodJVD9jWxip14Rh+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭ࠠࠡࠢࡸࡶࡱࡀࠠࠨᴗ")+url+OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠧࠡࠢࠣࡱࡴࡪࡥ࠻ࠢࠪᴘ")+str(IeGPS8lnjLpR3JKVsOMyhHA9vd))
	elif wdftVMyzF17cYETHu(u"ࠨࡡࡌࡔ࡙࡜࡟ࠨᴙ") in JJnVRkiCSuK1D:
		import z1qJk2AYoC
		if not z1qJk2AYoC.dt5U3cZpCFGRHDue7a1(fy8iFgEkrO12NR9TWBI35sjY6qHvV,EsCplGc5N4mBuYW0RVQt6b): return
		for FAVmIEYX4o3xJ8cdh in range(BkM54Kr7Qbqn,gaUFPm1MLjDJ2lVecEuYI+BkM54Kr7Qbqn):
			OmsWt89dSA5HyCZ4wL += jj1GJ7YuwylqmzSUBrEb(str(FAVmIEYX4o3xJ8cdh),JJnVRkiCSuK1D)
		if not OmsWt89dSA5HyCZ4wL: return
		type,z36flodJVD9jWxip14Rh,url,IeGPS8lnjLpR3JKVsOMyhHA9vd,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YMaiHbnIThsP7q,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW = yiTBYwps2mCrb4jGPux0cIJ.sample(OmsWt89dSA5HyCZ4wL,BkM54Kr7Qbqn)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+Gcw2nelTR864XCVruO3mAFqI5a(u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥࡉࡡࡵࡧࡪࡳࡷࡿࠠࠡࠢࡱࡥࡲ࡫࠺ࠡࠩᴚ")+z36flodJVD9jWxip14Rh+s5WMHyQN4mpie(u"ࠪࠤࠥࠦࡵࡳ࡮࠽ࠤࠬᴛ")+url+N6NGJ4vpmidqMCh7yo(u"ࠫࠥࠦࠠ࡮ࡱࡧࡩ࠿ࠦࠧᴜ")+str(IeGPS8lnjLpR3JKVsOMyhHA9vd))
	elif aOQTKXFL54Nl60Zhp3MbE(u"ࠬࡥࡍ࠴ࡗࡢࠫᴝ") in JJnVRkiCSuK1D:
		import ucJU0YkpTS
		if not ucJU0YkpTS.dt5U3cZpCFGRHDue7a1(fy8iFgEkrO12NR9TWBI35sjY6qHvV,EsCplGc5N4mBuYW0RVQt6b): return
		for FAVmIEYX4o3xJ8cdh in range(BkM54Kr7Qbqn,gaUFPm1MLjDJ2lVecEuYI+BkM54Kr7Qbqn):
			OmsWt89dSA5HyCZ4wL += dDF5SoYiLMpBl4b(str(FAVmIEYX4o3xJ8cdh),JJnVRkiCSuK1D)
		if not OmsWt89dSA5HyCZ4wL: return
		type,z36flodJVD9jWxip14Rh,url,IeGPS8lnjLpR3JKVsOMyhHA9vd,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YMaiHbnIThsP7q,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW = yiTBYwps2mCrb4jGPux0cIJ.sample(OmsWt89dSA5HyCZ4wL,BkM54Kr7Qbqn)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+AAbvaXV2DQzfNHdm4U3tT(u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦ࡮ࡢ࡯ࡨ࠾ࠥ࠭ᴞ")+z36flodJVD9jWxip14Rh+jL5CrsRwebpyDVXUc1EQP(u"ࠧࠡࠢࠣࡹࡷࡲ࠺ࠡࠩᴟ")+url+EE1jeHnIoad(u"ࠨࠢࠣࠤࡲࡵࡤࡦ࠼ࠣࠫᴠ")+str(IeGPS8lnjLpR3JKVsOMyhHA9vd))
	AvunibB1PK82D6d = z36flodJVD9jWxip14Rh
	xNoBEjGKCgeZSFW4fdY5qbms29c0X = []
	for pk6YWixXFSrDLKCnlN39w in range(D2D96X5NGamBhrFwvL8VEbqiSfZIl,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠶࠶ᶰ")):
		if pk6YWixXFSrDLKCnlN39w>D2D96X5NGamBhrFwvL8VEbqiSfZIl: Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+o1INZ3ViQqS0Uw5z6kMjbv(u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥࡉࡡࡵࡧࡪࡳࡷࡿࠠࠡࠢࡱࡥࡲ࡫࠺ࠡࠩᴡ")+z36flodJVD9jWxip14Rh+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪࠤࠥࠦࡵࡳ࡮࠽ࠤࠬᴢ")+url+wdftVMyzF17cYETHu(u"ࠫࠥࠦࠠ࡮ࡱࡧࡩ࠿ࠦࠧᴣ")+str(IeGPS8lnjLpR3JKVsOMyhHA9vd))
		I4t9qonjrm.menuItemsLIST[:] = []
		if IeGPS8lnjLpR3JKVsOMyhHA9vd==ggjO5CrKVRPITaesWkxD(u"࠸࠳࠵ᶱ") and oRJAfwD957WkUyBM1Ehu8m(u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭ᴤ") in YMaiHbnIThsP7q: IeGPS8lnjLpR3JKVsOMyhHA9vd = EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠲࠴࠵ᶲ")
		if IeGPS8lnjLpR3JKVsOMyhHA9vd==wdftVMyzF17cYETHu(u"࠸࠳࠷ᶳ") and LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭ᴥ") in YMaiHbnIThsP7q: IeGPS8lnjLpR3JKVsOMyhHA9vd = KfHAW8VGbrxi(u"࠹࠴࠷ᶴ")
		if IeGPS8lnjLpR3JKVsOMyhHA9vd==ggjO5CrKVRPITaesWkxD(u"࠴࠸࠹ᶵ"): IeGPS8lnjLpR3JKVsOMyhHA9vd = vU6DxuzPwMpg(u"࠶࠾࠷ᶶ")
		O4On5rLamD7q1zKBo6WfF3eEbS98 = KYAmF1b4205(type,z36flodJVD9jWxip14Rh,url,IeGPS8lnjLpR3JKVsOMyhHA9vd,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YMaiHbnIThsP7q,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW)
		if sJw9QWiq1Kr0xfeVRI(u"ࠧࡠࡋࡓࡘ࡛ࡥࠧᴦ") in JJnVRkiCSuK1D and IeGPS8lnjLpR3JKVsOMyhHA9vd==sIzDXlTHYUC5L3xZGnr(u"࠶࠼࠷ᶷ"): del I4t9qonjrm.menuItemsLIST[:XW57OCeGnFTLQbaqdrD9zM]
		if aOQTKXFL54Nl60Zhp3MbE(u"ࠨࡡࡐ࠷࡚ࡥࠧᴧ") in JJnVRkiCSuK1D and IeGPS8lnjLpR3JKVsOMyhHA9vd==FgXzMs0YSDt(u"࠷࠶࠹ᶸ"): del I4t9qonjrm.menuItemsLIST[:XW57OCeGnFTLQbaqdrD9zM]
		VB3NKdsqvfAJYEWljanku8[:] = JQevh5MmuIabrsxF4R3iE2TLHWpgo(I4t9qonjrm.menuItemsLIST)
		if xNoBEjGKCgeZSFW4fdY5qbms29c0X and bL7jBNOF9MK(I18uSKaWhgTBeYUPD4sr(u"ࡷࠪั้่ษࠨᴨ")) in str(VB3NKdsqvfAJYEWljanku8) or bL7jBNOF9MK(ggjO5CrKVRPITaesWkxD(u"ࡸࠫา๊โ่ࠩᴩ")) in str(VB3NKdsqvfAJYEWljanku8):
			z36flodJVD9jWxip14Rh = AvunibB1PK82D6d
			VB3NKdsqvfAJYEWljanku8[:] = xNoBEjGKCgeZSFW4fdY5qbms29c0X
			break
		AvunibB1PK82D6d = z36flodJVD9jWxip14Rh
		xNoBEjGKCgeZSFW4fdY5qbms29c0X = VB3NKdsqvfAJYEWljanku8
		if str(VB3NKdsqvfAJYEWljanku8).count(uulNDCPyef78(u"ࠫࡻ࡯ࡤࡦࡱࠪᴪ"))>D2D96X5NGamBhrFwvL8VEbqiSfZIl: break
		if str(VB3NKdsqvfAJYEWljanku8).count(CsDcLqQUVK4YBvHFW1(u"ࠬࡲࡩࡷࡧࠪᴫ"))>D2D96X5NGamBhrFwvL8VEbqiSfZIl: break
		if IeGPS8lnjLpR3JKVsOMyhHA9vd==OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠲࠴࠵ᶹ"): break
		if IeGPS8lnjLpR3JKVsOMyhHA9vd==jL5CrsRwebpyDVXUc1EQP(u"࠸࠳࠶ᶺ"): break
		if IeGPS8lnjLpR3JKVsOMyhHA9vd==V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠴࠼࠵ᶻ"): break
		if jL5CrsRwebpyDVXUc1EQP(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨᴬ") in JJnVRkiCSuK1D and VB3NKdsqvfAJYEWljanku8: type,z36flodJVD9jWxip14Rh,url,IeGPS8lnjLpR3JKVsOMyhHA9vd,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YMaiHbnIThsP7q,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW = yiTBYwps2mCrb4jGPux0cIJ.sample(VB3NKdsqvfAJYEWljanku8,BkM54Kr7Qbqn)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	if not z36flodJVD9jWxip14Rh: z36flodJVD9jWxip14Rh = PlpyFa9QMKXxOD1cvHzmI(u"ࠧ࠯࠰࠱࠲ࠬᴭ")
	elif z36flodJVD9jWxip14Rh.count(I18uSKaWhgTBeYUPD4sr(u"ࠨࡡࠪᴮ"))>BkM54Kr7Qbqn: z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.split(wdftVMyzF17cYETHu(u"ࠩࡢࠫᴯ"),teaC5j4HuGDqpwcmUzJ)[teaC5j4HuGDqpwcmUzJ]
	z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࡙ࠪࡓࡑࡎࡐ࡙ࡑ࠾ࠥ࠭ᴰ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(wdftVMyzF17cYETHu(u"ࠫࡤࡓࡏࡅࡡࠪᴱ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	zcyQMjL09tm8UKbEfN1RBXgFkH[D2D96X5NGamBhrFwvL8VEbqiSfZIl][BkM54Kr7Qbqn] = CsDcLqQUVK4YBvHFW1(u"ࠬࡡࠧᴲ")+n0nFOd4yR97fQzNLSW+z36flodJVD9jWxip14Rh+T7ASIp1ZYwio9HQ8cObJK+o1INZ3ViQqS0Uw5z6kMjbv(u"࠭ࠠ࠻ษ็ๆุ๋࡝ࠨᴳ")
	if LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩᴴ") in JJnVRkiCSuK1D:
		for pk6YWixXFSrDLKCnlN39w in range(N6NGJ4vpmidqMCh7yo(u"࠼ᶼ")): yiTBYwps2mCrb4jGPux0cIJ.shuffle(VB3NKdsqvfAJYEWljanku8)
		I4t9qonjrm.menuItemsLIST[:] = zcyQMjL09tm8UKbEfN1RBXgFkH+VB3NKdsqvfAJYEWljanku8[:webrl8sY4tSqx]
	else: I4t9qonjrm.menuItemsLIST[:] = zcyQMjL09tm8UKbEfN1RBXgFkH+VB3NKdsqvfAJYEWljanku8
	return
def Aqe9VExdPgMYjs5bBao(qGP3Ic1l5noR20p9bT,t5gnJ3zP1WRFTy4KpAVYOoeqNaBMlE):
	t5gnJ3zP1WRFTy4KpAVYOoeqNaBMlE = t5gnJ3zP1WRFTy4KpAVYOoeqNaBMlE.replace(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᴵ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(jL5CrsRwebpyDVXUc1EQP(u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᴶ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	rSVf9ptNnR4 = t5gnJ3zP1WRFTy4KpAVYOoeqNaBMlE
	if C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫᴷ") in t5gnJ3zP1WRFTy4KpAVYOoeqNaBMlE:
		rSVf9ptNnR4 = t5gnJ3zP1WRFTy4KpAVYOoeqNaBMlE.split(CsDcLqQUVK4YBvHFW1(u"ࠫࡤࡥࡉࡑࡖ࡙ࡗࡪࡸࡩࡦࡵࡢࡣࠬᴸ"))[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		type = oRJAfwD957WkUyBM1Ehu8m(u"ࠬ࠲ࡓࡆࡔࡌࡉࡘࡀࠠࠨᴹ")
	elif uulNDCPyef78(u"࠭ࡖࡐࡆࠪᴺ") in qGP3Ic1l5noR20p9bT: type = ssynAg0zhSkoCpOMDV9(u"ࠧ࠭ࡘࡌࡈࡊࡕࡓ࠻ࠢࠪᴻ")
	elif FgXzMs0YSDt(u"ࠨࡎࡌ࡚ࡊ࠭ᴼ") in qGP3Ic1l5noR20p9bT: type = FmYoGejTnwKME7d9zPc(u"ࠩ࠯ࡐࡎ࡜ࡅ࠻ࠢࠪᴽ")
	OZD1l4pAMzeH(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠪࡪࡴࡲࡤࡦࡴࠪᴾ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠫࡠ࠭ᴿ")+n0nFOd4yR97fQzNLSW+type+rSVf9ptNnR4+T7ASIp1ZYwio9HQ8cObJK+PlpyFa9QMKXxOD1cvHzmI(u"ࠬࠦ࠺ศๆๅื๊ࡣࠧᵀ"),qGP3Ic1l5noR20p9bT,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠵࠻࠽ᶽ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,KfHAW8VGbrxi(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᵁ")+t5gnJ3zP1WRFTy4KpAVYOoeqNaBMlE)
	OZD1l4pAMzeH(wdftVMyzF17cYETHu(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᵂ"),FmYoGejTnwKME7d9zPc(u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆุ๋ࠧᵃ"),qGP3Ic1l5noR20p9bT,FgXzMs0YSDt(u"࠶࠼࠷ᶾ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,uulNDCPyef78(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᵄ")+t5gnJ3zP1WRFTy4KpAVYOoeqNaBMlE)
	OZD1l4pAMzeH(CsDcLqQUVK4YBvHFW1(u"ࠪࡰ࡮ࡴ࡫ࠨᵅ"),n0nFOd4yR97fQzNLSW+uulNDCPyef78(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩᵆ")+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,o1INZ3ViQqS0Uw5z6kMjbv(u"࠿࠹࠺࠻ᶿ"))
	import z1qJk2AYoC
	for FAVmIEYX4o3xJ8cdh in range(BkM54Kr7Qbqn,gaUFPm1MLjDJ2lVecEuYI+BkM54Kr7Qbqn):
		if Gcw2nelTR864XCVruO3mAFqI5a(u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭ᵇ") in t5gnJ3zP1WRFTy4KpAVYOoeqNaBMlE: z1qJk2AYoC.fXBo06ewvrJ38547Y(str(FAVmIEYX4o3xJ8cdh),qGP3Ic1l5noR20p9bT,t5gnJ3zP1WRFTy4KpAVYOoeqNaBMlE,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LhFAGlQ19zr)
		else: z1qJk2AYoC.zY53X6dEGkqnhmUDJ20rpbR8(str(FAVmIEYX4o3xJ8cdh),qGP3Ic1l5noR20p9bT,t5gnJ3zP1WRFTy4KpAVYOoeqNaBMlE,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LhFAGlQ19zr)
	I4t9qonjrm.menuItemsLIST[:] = JQevh5MmuIabrsxF4R3iE2TLHWpgo(I4t9qonjrm.menuItemsLIST)
	if len(I4t9qonjrm.menuItemsLIST)>(webrl8sY4tSqx+XW57OCeGnFTLQbaqdrD9zM): I4t9qonjrm.menuItemsLIST[:] = I4t9qonjrm.menuItemsLIST[:XW57OCeGnFTLQbaqdrD9zM]+yiTBYwps2mCrb4jGPux0cIJ.sample(I4t9qonjrm.menuItemsLIST[XW57OCeGnFTLQbaqdrD9zM:],webrl8sY4tSqx)
	return
def Yx034gfhSRqNsPdDzWZbu(qGP3Ic1l5noR20p9bT,t5gnJ3zP1WRFTy4KpAVYOoeqNaBMlE):
	t5gnJ3zP1WRFTy4KpAVYOoeqNaBMlE = t5gnJ3zP1WRFTy4KpAVYOoeqNaBMlE.replace(oRJAfwD957WkUyBM1Ehu8m(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᵈ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᵉ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	rSVf9ptNnR4 = t5gnJ3zP1WRFTy4KpAVYOoeqNaBMlE
	if Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠨࡡࡢࡑ࠸࡛ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨᵊ") in t5gnJ3zP1WRFTy4KpAVYOoeqNaBMlE:
		rSVf9ptNnR4 = t5gnJ3zP1WRFTy4KpAVYOoeqNaBMlE.split(LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠩࡢࡣࡒ࠹ࡕࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩᵋ"))[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		type = ssynAg0zhSkoCpOMDV9(u"ࠪ࠰ࡘࡋࡒࡊࡇࡖ࠾ࠥ࠭ᵌ")
	elif ssynAg0zhSkoCpOMDV9(u"࡛ࠫࡕࡄࠨᵍ") in qGP3Ic1l5noR20p9bT: type = Gcw2nelTR864XCVruO3mAFqI5a(u"ࠬ࠲ࡖࡊࡆࡈࡓࡘࡀࠠࠨᵎ")
	elif Gcw2nelTR864XCVruO3mAFqI5a(u"࠭ࡌࡊࡘࡈࠫᵏ") in qGP3Ic1l5noR20p9bT: type = V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠧ࠭ࡎࡌ࡚ࡊࡀࠠࠨᵐ")
	OZD1l4pAMzeH(EE1jeHnIoad(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᵑ"),wdftVMyzF17cYETHu(u"ࠩ࡞ࠫᵒ")+n0nFOd4yR97fQzNLSW+type+rSVf9ptNnR4+T7ASIp1ZYwio9HQ8cObJK+Hr25gta6XcqO(u"ࠪࠤ࠿อไใี่ࡡࠬᵓ"),qGP3Ic1l5noR20p9bT,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠱࠷࠺᷀"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QjAINyUC7MDRq5d8e4vl9(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᵔ")+t5gnJ3zP1WRFTy4KpAVYOoeqNaBMlE)
	OZD1l4pAMzeH(I18uSKaWhgTBeYUPD4sr(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᵕ"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬᵖ"),qGP3Ic1l5noR20p9bT,s5WMHyQN4mpie(u"࠲࠸࠻᷁"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,KfHAW8VGbrxi(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᵗ")+t5gnJ3zP1WRFTy4KpAVYOoeqNaBMlE)
	OZD1l4pAMzeH(KfHAW8VGbrxi(u"ࠨ࡮࡬ࡲࡰ࠭ᵘ"),n0nFOd4yR97fQzNLSW+wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧᵙ")+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,I18uSKaWhgTBeYUPD4sr(u"࠻࠼࠽࠾᷂"))
	import ucJU0YkpTS
	for FAVmIEYX4o3xJ8cdh in range(BkM54Kr7Qbqn,gaUFPm1MLjDJ2lVecEuYI+BkM54Kr7Qbqn):
		if SnhLjmfeJC(u"ࠪࡣࡤࡓ࠳ࡖࡕࡨࡶ࡮࡫ࡳࡠࡡࠪᵚ") in t5gnJ3zP1WRFTy4KpAVYOoeqNaBMlE: ucJU0YkpTS.fXBo06ewvrJ38547Y(str(FAVmIEYX4o3xJ8cdh),qGP3Ic1l5noR20p9bT,t5gnJ3zP1WRFTy4KpAVYOoeqNaBMlE,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LhFAGlQ19zr)
		else: ucJU0YkpTS.zY53X6dEGkqnhmUDJ20rpbR8(str(FAVmIEYX4o3xJ8cdh),qGP3Ic1l5noR20p9bT,t5gnJ3zP1WRFTy4KpAVYOoeqNaBMlE,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LhFAGlQ19zr)
	I4t9qonjrm.menuItemsLIST[:] = JQevh5MmuIabrsxF4R3iE2TLHWpgo(I4t9qonjrm.menuItemsLIST)
	if len(I4t9qonjrm.menuItemsLIST)>(webrl8sY4tSqx+XW57OCeGnFTLQbaqdrD9zM): I4t9qonjrm.menuItemsLIST[:] = I4t9qonjrm.menuItemsLIST[:XW57OCeGnFTLQbaqdrD9zM]+yiTBYwps2mCrb4jGPux0cIJ.sample(I4t9qonjrm.menuItemsLIST[XW57OCeGnFTLQbaqdrD9zM:],webrl8sY4tSqx)
	return
def JQevh5MmuIabrsxF4R3iE2TLHWpgo(QUtyBqrdzXx9SgabJN):
	VvYac3JKrsIznMtdC0ujSG = []
	for type,z36flodJVD9jWxip14Rh,url,hO3D6GVPY2qENv8bZWH,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YMaiHbnIThsP7q,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW in QUtyBqrdzXx9SgabJN:
		if LYIgTBeSmZWotDh4bnyQkvM50siu(u"ฺࠫ็อสࠩᵛ") in z36flodJVD9jWxip14Rh or oRJAfwD957WkUyBM1Ehu8m(u"ࠬ฻แฮ้ࠪᵜ") in z36flodJVD9jWxip14Rh or I18uSKaWhgTBeYUPD4sr(u"࠭ࡰࡢࡩࡨࠫᵝ") in z36flodJVD9jWxip14Rh.lower(): continue
		VvYac3JKrsIznMtdC0ujSG.append([type,z36flodJVD9jWxip14Rh,url,hO3D6GVPY2qENv8bZWH,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YMaiHbnIThsP7q,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW])
	return VvYac3JKrsIznMtdC0ujSG
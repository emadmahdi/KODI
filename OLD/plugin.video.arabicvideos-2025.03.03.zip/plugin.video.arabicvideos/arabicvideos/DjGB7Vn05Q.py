# -*- coding: utf-8 -*-
import sys as CfgZ0zWP5XBpoGQwLUY
D5DpyO2wPg7oL = CfgZ0zWP5XBpoGQwLUY.version_info [0] == 2
ccK5HIyfUgvOdQpWSXZtaBJ = 2048
W8WuBTGQg1Zwqy5F6xSe = 7
def zmQcCUZlPKBITW5bqx1 (rR5FPU8VhJQ):
	global Jfz4wMWSZb0BYV
	EEr5teuZbc = ord (rR5FPU8VhJQ [-1])
	ZZd5W9FVUhzu31NQyComxv = rR5FPU8VhJQ [:-1]
	sJYFyd6mZHev1IXEaMj0b = EEr5teuZbc % len (ZZd5W9FVUhzu31NQyComxv)
	qPJ7pUnt5rcm6NMaFYLSkHsGxI = ZZd5W9FVUhzu31NQyComxv [:sJYFyd6mZHev1IXEaMj0b] + ZZd5W9FVUhzu31NQyComxv [sJYFyd6mZHev1IXEaMj0b:]
	if D5DpyO2wPg7oL:
		Vv1b9fdEckNepm7 = unicode () .join ([unichr (ord (QdqoKlFn4yZUOJp1xYrNTaBSmt69hc) - ccK5HIyfUgvOdQpWSXZtaBJ - (hrazDC5q4oB + EEr5teuZbc) % W8WuBTGQg1Zwqy5F6xSe) for hrazDC5q4oB, QdqoKlFn4yZUOJp1xYrNTaBSmt69hc in enumerate (qPJ7pUnt5rcm6NMaFYLSkHsGxI)])
	else:
		Vv1b9fdEckNepm7 = str () .join ([chr (ord (QdqoKlFn4yZUOJp1xYrNTaBSmt69hc) - ccK5HIyfUgvOdQpWSXZtaBJ - (hrazDC5q4oB + EEr5teuZbc) % W8WuBTGQg1Zwqy5F6xSe) for hrazDC5q4oB, QdqoKlFn4yZUOJp1xYrNTaBSmt69hc in enumerate (qPJ7pUnt5rcm6NMaFYLSkHsGxI)])
	return eval (Vv1b9fdEckNepm7)
V3z5t4JAqyXk2fLsW1juoZ0BEp6,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye,wdftVMyzF17cYETHu=zmQcCUZlPKBITW5bqx1,zmQcCUZlPKBITW5bqx1,zmQcCUZlPKBITW5bqx1
Hr25gta6XcqO,FmYoGejTnwKME7d9zPc,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9=wdftVMyzF17cYETHu,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye,V3z5t4JAqyXk2fLsW1juoZ0BEp6
KfHAW8VGbrxi,aOQTKXFL54Nl60Zhp3MbE,jL5CrsRwebpyDVXUc1EQP=Dco0w1e5VM3YP7hLXTHBS8GtaCrO9,FmYoGejTnwKME7d9zPc,Hr25gta6XcqO
oRJAfwD957WkUyBM1Ehu8m,vU6DxuzPwMpg,I18uSKaWhgTBeYUPD4sr=jL5CrsRwebpyDVXUc1EQP,aOQTKXFL54Nl60Zhp3MbE,KfHAW8VGbrxi
o1INZ3ViQqS0Uw5z6kMjbv,s5WMHyQN4mpie,N6NGJ4vpmidqMCh7yo=I18uSKaWhgTBeYUPD4sr,vU6DxuzPwMpg,oRJAfwD957WkUyBM1Ehu8m
Gcw2nelTR864XCVruO3mAFqI5a,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7,OO9YiAQHGrLo0qpW2M3jDeXd1kx=N6NGJ4vpmidqMCh7yo,s5WMHyQN4mpie,o1INZ3ViQqS0Uw5z6kMjbv
O3OVuapf0YFjbm5oUQDg,sJw9QWiq1Kr0xfeVRI,SnhLjmfeJC=OO9YiAQHGrLo0qpW2M3jDeXd1kx,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7,Gcw2nelTR864XCVruO3mAFqI5a
QjAINyUC7MDRq5d8e4vl9,AAbvaXV2DQzfNHdm4U3tT,ggjO5CrKVRPITaesWkxD=SnhLjmfeJC,sJw9QWiq1Kr0xfeVRI,O3OVuapf0YFjbm5oUQDg
FgXzMs0YSDt,uulNDCPyef78,EQxFuqjw95WvaMm8Hnlt47XVihJ=ggjO5CrKVRPITaesWkxD,AAbvaXV2DQzfNHdm4U3tT,QjAINyUC7MDRq5d8e4vl9
ssynAg0zhSkoCpOMDV9,sIzDXlTHYUC5L3xZGnr,PlpyFa9QMKXxOD1cvHzmI=EQxFuqjw95WvaMm8Hnlt47XVihJ,uulNDCPyef78,FgXzMs0YSDt
CsDcLqQUVK4YBvHFW1,EE1jeHnIoad,LYIgTBeSmZWotDh4bnyQkvM50siu=PlpyFa9QMKXxOD1cvHzmI,sIzDXlTHYUC5L3xZGnr,ssynAg0zhSkoCpOMDV9
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = sJw9QWiq1Kr0xfeVRI(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
K2l9rLfvoXxyZ4NYapO = V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
WZfqnGSYlRQAV8MihD7BPs = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(cRwuEXGWxj,wdftVMyzF17cYETHu(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
X6AmGZLUf8Dhdr3SRCe2YQJHF = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(cRwuEXGWxj,oRJAfwD957WkUyBM1Ehu8m(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
u5fU1irdYwz27Gle43mXOHPQg = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(ywEBSl6zHMFsO4Qmh3TJP8itgj,LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),PlpyFa9QMKXxOD1cvHzmI(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
pvsZguhiwFLV = luwjTO0m9SMhLE3Fe4KXxb
qLJm5ufXBh = aOQTKXFL54Nl60Zhp3MbE(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
g1mDX9e3oif5uMCzb = CsDcLqQUVK4YBvHFW1(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
qaD0xbYsT6gOujoXz538r1wkAM = ssynAg0zhSkoCpOMDV9(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
x9SYGtivQH1 = V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
ILzm10Nxrb = CsDcLqQUVK4YBvHFW1(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
ZZD7MSWkOheNIXuqHcVt1fPJL9y6v = aOQTKXFL54Nl60Zhp3MbE(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
XaGSbTRsEVH2vze = P8F6NtJD5ridLmglTbWpzMo4
eskp1J4nAlQ = Xsc4lqOhdziToWvunbRNSQZKIY8E
ZwgPxblcB0Caj95vADVm = M9MFNdZq3PuBkCsytJ
def ugbnmWCrLpG9Av0xzocFaB5ew(hO3D6GVPY2qENv8bZWH):
	if   hO3D6GVPY2qENv8bZWH==QjAINyUC7MDRq5d8e4vl9(u"࠺࠸࠵ࣘ"): OmsWt89dSA5HyCZ4wL = HHlKdMOR3SUs2y1g8Wh4wXrftkA()
	elif hO3D6GVPY2qENv8bZWH==EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠻࠹࠷ࣙ"): OmsWt89dSA5HyCZ4wL = rSOlpJAWb8Vh(WZfqnGSYlRQAV8MihD7BPs,EsCplGc5N4mBuYW0RVQt6b,EsCplGc5N4mBuYW0RVQt6b);e8ezb7O1yFxmH3tfEwKPZ4qRYLdVhB(OmsWt89dSA5HyCZ4wL)
	elif hO3D6GVPY2qENv8bZWH==aOQTKXFL54Nl60Zhp3MbE(u"࠼࠺࠲ࣚ"): OmsWt89dSA5HyCZ4wL = rSOlpJAWb8Vh(X6AmGZLUf8Dhdr3SRCe2YQJHF,EsCplGc5N4mBuYW0RVQt6b,EsCplGc5N4mBuYW0RVQt6b);e8ezb7O1yFxmH3tfEwKPZ4qRYLdVhB(OmsWt89dSA5HyCZ4wL)
	elif hO3D6GVPY2qENv8bZWH==o1INZ3ViQqS0Uw5z6kMjbv(u"࠽࠴࠴ࣛ"): OmsWt89dSA5HyCZ4wL = rSOlpJAWb8Vh(u5fU1irdYwz27Gle43mXOHPQg,LhFAGlQ19zr,EsCplGc5N4mBuYW0RVQt6b);e8ezb7O1yFxmH3tfEwKPZ4qRYLdVhB(OmsWt89dSA5HyCZ4wL)
	elif hO3D6GVPY2qENv8bZWH==jL5CrsRwebpyDVXUc1EQP(u"࠷࠵࠶ࣜ"): OmsWt89dSA5HyCZ4wL = vQ3USRaDebkZ8drlLmJGc(pvsZguhiwFLV,EsCplGc5N4mBuYW0RVQt6b);e8ezb7O1yFxmH3tfEwKPZ4qRYLdVhB(OmsWt89dSA5HyCZ4wL)
	elif hO3D6GVPY2qENv8bZWH==wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠸࠶࠸ࣝ"): OmsWt89dSA5HyCZ4wL = HVO5subWZdwno48YSULcRpakt2JClz(EsCplGc5N4mBuYW0RVQt6b);e8ezb7O1yFxmH3tfEwKPZ4qRYLdVhB(OmsWt89dSA5HyCZ4wL)
	elif hO3D6GVPY2qENv8bZWH==OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠹࠷࠺ࣞ"): OmsWt89dSA5HyCZ4wL = ZZjmLN1WbCkO7lMEo9chn2F5gP(EsCplGc5N4mBuYW0RVQt6b);e8ezb7O1yFxmH3tfEwKPZ4qRYLdVhB(OmsWt89dSA5HyCZ4wL)
	elif hO3D6GVPY2qENv8bZWH==aOQTKXFL54Nl60Zhp3MbE(u"࠺࠹࠵ࣟ"): OmsWt89dSA5HyCZ4wL = xxazf9QbuElZXwnDF()
	elif hO3D6GVPY2qENv8bZWH==I18uSKaWhgTBeYUPD4sr(u"࠻࠺࠷࣠"): OmsWt89dSA5HyCZ4wL = rSOlpJAWb8Vh(qLJm5ufXBh,LhFAGlQ19zr,EsCplGc5N4mBuYW0RVQt6b);e8ezb7O1yFxmH3tfEwKPZ4qRYLdVhB(OmsWt89dSA5HyCZ4wL)
	elif hO3D6GVPY2qENv8bZWH==LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠼࠻࠲࣡"): OmsWt89dSA5HyCZ4wL = rSOlpJAWb8Vh(g1mDX9e3oif5uMCzb,LhFAGlQ19zr,EsCplGc5N4mBuYW0RVQt6b);e8ezb7O1yFxmH3tfEwKPZ4qRYLdVhB(OmsWt89dSA5HyCZ4wL)
	elif hO3D6GVPY2qENv8bZWH==uulNDCPyef78(u"࠽࠵࠴࣢"): OmsWt89dSA5HyCZ4wL = rSOlpJAWb8Vh(qaD0xbYsT6gOujoXz538r1wkAM,LhFAGlQ19zr,EsCplGc5N4mBuYW0RVQt6b);e8ezb7O1yFxmH3tfEwKPZ4qRYLdVhB(OmsWt89dSA5HyCZ4wL)
	elif hO3D6GVPY2qENv8bZWH==C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠷࠶࠶ࣣ"): OmsWt89dSA5HyCZ4wL = rSOlpJAWb8Vh(x9SYGtivQH1,LhFAGlQ19zr,EsCplGc5N4mBuYW0RVQt6b);e8ezb7O1yFxmH3tfEwKPZ4qRYLdVhB(OmsWt89dSA5HyCZ4wL)
	elif hO3D6GVPY2qENv8bZWH==Hr25gta6XcqO(u"࠸࠷࠸ࣤ"): OmsWt89dSA5HyCZ4wL = rSOlpJAWb8Vh(ILzm10Nxrb,LhFAGlQ19zr,EsCplGc5N4mBuYW0RVQt6b);e8ezb7O1yFxmH3tfEwKPZ4qRYLdVhB(OmsWt89dSA5HyCZ4wL)
	elif hO3D6GVPY2qENv8bZWH==N6NGJ4vpmidqMCh7yo(u"࠹࠸࠺ࣥ"): OmsWt89dSA5HyCZ4wL = rSOlpJAWb8Vh(ZZD7MSWkOheNIXuqHcVt1fPJL9y6v,LhFAGlQ19zr,EsCplGc5N4mBuYW0RVQt6b);e8ezb7O1yFxmH3tfEwKPZ4qRYLdVhB(OmsWt89dSA5HyCZ4wL)
	elif hO3D6GVPY2qENv8bZWH==EE1jeHnIoad(u"࠺࠹࠼ࣦ"): OmsWt89dSA5HyCZ4wL = HzyX2J3lD0NYqf5hTcinV68d1B(EsCplGc5N4mBuYW0RVQt6b);e8ezb7O1yFxmH3tfEwKPZ4qRYLdVhB(OmsWt89dSA5HyCZ4wL)
	elif hO3D6GVPY2qENv8bZWH==KfHAW8VGbrxi(u"࠻࠺࠾ࣧ"): OmsWt89dSA5HyCZ4wL = yuPg0lbJrcWXx2QIep4LsOUSv7B();e8ezb7O1yFxmH3tfEwKPZ4qRYLdVhB(OmsWt89dSA5HyCZ4wL)
	elif hO3D6GVPY2qENv8bZWH==FmYoGejTnwKME7d9zPc(u"࠶࠶࠸࠱ࣨ"): OmsWt89dSA5HyCZ4wL = R7DwbNdJajKztnMcfux2UA()
	elif hO3D6GVPY2qENv8bZWH==vU6DxuzPwMpg(u"࠷࠰࠹࠳ࣩ"): OmsWt89dSA5HyCZ4wL = SYPxROov86GFIaeVJlBr4K(EsCplGc5N4mBuYW0RVQt6b);e8ezb7O1yFxmH3tfEwKPZ4qRYLdVhB(OmsWt89dSA5HyCZ4wL)
	elif hO3D6GVPY2qENv8bZWH==FmYoGejTnwKME7d9zPc(u"࠱࠱࠺࠵࣪"): OmsWt89dSA5HyCZ4wL = YrHUwPjAu8ipo();e8ezb7O1yFxmH3tfEwKPZ4qRYLdVhB(OmsWt89dSA5HyCZ4wL)
	elif hO3D6GVPY2qENv8bZWH==PlpyFa9QMKXxOD1cvHzmI(u"࠲࠲࠻࠷࣫"): OmsWt89dSA5HyCZ4wL = JyUrDd8HmoXPR3jqehfgi6ZY1l2xp();e8ezb7O1yFxmH3tfEwKPZ4qRYLdVhB(OmsWt89dSA5HyCZ4wL)
	elif hO3D6GVPY2qENv8bZWH==SnhLjmfeJC(u"࠳࠳࠼࠹࣬"): OmsWt89dSA5HyCZ4wL = Hpw3ecIj4vWRbqdYVCL9EF();e8ezb7O1yFxmH3tfEwKPZ4qRYLdVhB(OmsWt89dSA5HyCZ4wL)
	elif hO3D6GVPY2qENv8bZWH==KfHAW8VGbrxi(u"࠴࠴࠽࠻࣭"): OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	else: OmsWt89dSA5HyCZ4wL = LhFAGlQ19zr
	return OmsWt89dSA5HyCZ4wL
def e8ezb7O1yFxmH3tfEwKPZ4qRYLdVhB(ooysU7CDBeL3Apinrm):
	if ooysU7CDBeL3Apinrm: ejX7kGtQ4hcYUHW9b31vriuZLM6Sp(EsCplGc5N4mBuYW0RVQt6b)
	return
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠩࡩࡳࡱࡪࡥࡳࠩࠌ"),oRJAfwD957WkUyBM1Ehu8m(u"ࠪฮ๋฾๊โࠢส่ัํวำࠩࠍ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,ggjO5CrKVRPITaesWkxD(u"࠻࠺࠶࣮"))
	OZD1l4pAMzeH(ssynAg0zhSkoCpOMDV9(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫࠎ"),vU6DxuzPwMpg(u"ࠬะๆู์ไࠤ่๎ฯ๋ࠩࠏ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,QjAINyUC7MDRq5d8e4vl9(u"࠼࠺࠰࣯"))
	OZD1l4pAMzeH(N6NGJ4vpmidqMCh7yo(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠐ"),o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧห่฻๎ๆࠦวๅสิ๊ฬ๋ฬࠨࠑ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,jL5CrsRwebpyDVXUc1EQP(u"࠷࠰࠹࠲ࣰ"))
	return
def R7DwbNdJajKztnMcfux2UA():
	EEMwiv0RrUSZ,mOj9NtcpaZbFh = zhd7pRlPVkFuMfaHgeD4icNZObAnQ(XaGSbTRsEVH2vze)
	HdJlnyjYQziKL6o9,RRazcum7LbQlVr = zhd7pRlPVkFuMfaHgeD4icNZObAnQ(eskp1J4nAlQ)
	YmavJ4PWcyqU1xzAGDt6bjKpCgQShZ,EfdpGJU0yNcSbAKVtTLj = ucm10ohnRLA8d5ybFKEYkNQa3e6Gr(ZwgPxblcB0Caj95vADVm)
	p31JQlqT7eY6GtzdfwoUgRF,ooz1XqHy4C2anbV9k3dx5 = EEMwiv0RrUSZ+HdJlnyjYQziKL6o9+YmavJ4PWcyqU1xzAGDt6bjKpCgQShZ,mOj9NtcpaZbFh+RRazcum7LbQlVr+EfdpGJU0yNcSbAKVtTLj
	XEA2DbhGpcl7 = CsDcLqQUVK4YBvHFW1(u"ࠨࠢࠫࠫࠒ")+nn5eg2sIAqOozSxi9Y(EEMwiv0RrUSZ)+OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠩࠣ࠱ࠥ࠭ࠓ")+str(mOj9NtcpaZbFh)+FgXzMs0YSDt(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠔ")
	HiguZF3b5pS4XeOMYDsTxk7QPVLUh = vU6DxuzPwMpg(u"ࠫࠥ࠮ࠧࠕ")+nn5eg2sIAqOozSxi9Y(HdJlnyjYQziKL6o9)+ssynAg0zhSkoCpOMDV9(u"ࠬࠦ࠭ࠡࠩࠖ")+str(RRazcum7LbQlVr)+EE1jeHnIoad(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࠗ")
	jKDJaPnXqs35lhHdvwOSL = AAbvaXV2DQzfNHdm4U3tT(u"ࠧࠡࠪࠪ࠘")+nn5eg2sIAqOozSxi9Y(YmavJ4PWcyqU1xzAGDt6bjKpCgQShZ)+wdftVMyzF17cYETHu(u"ࠨࠢ࠰ࠤࠬ࠙")+str(EfdpGJU0yNcSbAKVtTLj)+oRJAfwD957WkUyBM1Ehu8m(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࠚ")
	Swsqv2N01iQnITgrbC = FgXzMs0YSDt(u"ࠪࠤ࠭࠭ࠛ")+nn5eg2sIAqOozSxi9Y(p31JQlqT7eY6GtzdfwoUgRF)+AAbvaXV2DQzfNHdm4U3tT(u"ࠫࠥ࠳ࠠࠨࠜ")+str(ooz1XqHy4C2anbV9k3dx5)+C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࠝ")
	OZD1l4pAMzeH(SnhLjmfeJC(u"࠭࡬ࡪࡰ࡮ࠫࠞ"),K2l9rLfvoXxyZ4NYapO+OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠧๆีะࠤฬ๊ฬๆ์฼ࠫࠟ")+Swsqv2N01iQnITgrbC,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠱࠱࠺࠷ࣱ"))
	OZD1l4pAMzeH(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠨ࡮࡬ࡲࡰ࠭ࠠ"),n0nFOd4yR97fQzNLSW+ssynAg0zhSkoCpOMDV9(u"ࠩࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨࠡ")+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,PlpyFa9QMKXxOD1cvHzmI(u"࠺࠻࠼࠽ࣲ"))
	OZD1l4pAMzeH(wdftVMyzF17cYETHu(u"ࠪࡰ࡮ࡴ࡫ࠨࠢ"),K2l9rLfvoXxyZ4NYapO+C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ู๊ࠫอࠡื๋ีࠥอไไฬสฬฮ࠭ࠣ")+XEA2DbhGpcl7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ggjO5CrKVRPITaesWkxD(u"࠳࠳࠼࠶ࣳ"))
	OZD1l4pAMzeH(wdftVMyzF17cYETHu(u"ࠬࡲࡩ࡯࡭ࠪࠤ"),K2l9rLfvoXxyZ4NYapO+sIzDXlTHYUC5L3xZGnr(u"࠭ๅิฯࠣ็ฬฺࠠศๆหี๋อๅอࠩࠥ")+HiguZF3b5pS4XeOMYDsTxk7QPVLUh,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ssynAg0zhSkoCpOMDV9(u"࠴࠴࠽࠸ࣴ"))
	OZD1l4pAMzeH(PlpyFa9QMKXxOD1cvHzmI(u"ࠧ࡭࡫ࡱ࡯ࠬࠦ"),K2l9rLfvoXxyZ4NYapO+KfHAW8VGbrxi(u"ࠨ็ึัࠥหูะษาหฯࠦวๅสิ๊ฬ๋ฬࠨࠧ")+jKDJaPnXqs35lhHdvwOSL,fy8iFgEkrO12NR9TWBI35sjY6qHvV,vU6DxuzPwMpg(u"࠵࠵࠾࠳ࣵ"))
	OZD1l4pAMzeH(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠩ࡯࡭ࡳࡱࠧࠨ"),K2l9rLfvoXxyZ4NYapO+uulNDCPyef78(u"ࠪฮฺ็๊าࠢส่อืๆศ็ฯࠫࠩ")+Swsqv2N01iQnITgrbC,fy8iFgEkrO12NR9TWBI35sjY6qHvV,sJw9QWiq1Kr0xfeVRI(u"࠶࠶࠸࠵ࣶ"))
	return
def Hpw3ecIj4vWRbqdYVCL9EF():
	ooysU7CDBeL3Apinrm = LhFAGlQ19zr
	Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ssynAg0zhSkoCpOMDV9(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࠪ"),O3OVuapf0YFjbm5oUQDg(u"ࠬํไࠡฬิ๎ิࠦแฺๆสࠤู๊อࠡฮ่๎฾ࠦลฺัสำฬะࠠศๆหี๋อๅอࠢ࠱࠲ࠥ๎ๅิฯࠣะ๊๐ูࠡ็็ๅฬะࠠศๆหี๋อๅอࠢส่็ี๊ๆหࠣ࠲࠳ࠦอห๋ࠣ๎฾๎ฯࠡษ็ฬึ์วๆฮࠣษ้๏ࠠฮษ็อࠥอไึใิࠤ࠳࠴๋ࠠ฻้๎ࠥำวๅหࠣ์฻฿๊สูࠢฬ฼ࠦวๅ็ุ๊฾ࠦ࠮࠯ࠢํ฽๋๐ࠠศๆะห้ฯࠠศๆอ๎ࠥ๎ึฺ้สࠤฬ๊ๅษำ่ะ๊ࠥไษำ้ห๊าࠠ࠯࠰๋ࠣีํࠠศๆ฼้้๐ษࠡฬอ้ࠥฮๅิฯ้ࠣั๊ฯࠡๅสุࠥอไษำ้ห๊า้ࠠ็ึั๋ࠥไโࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥลࠡࠨࠫ"))
	if Scj7zgGFVA83otMpwUkxhm0BLN1:
		ff1rnYPEpj78QFX5d = JyUrDd8HmoXPR3jqehfgi6ZY1l2xp()
		DhFB736RUVZQLuSs = rSOlpJAWb8Vh(Xsc4lqOhdziToWvunbRNSQZKIY8E,EsCplGc5N4mBuYW0RVQt6b,LhFAGlQ19zr)
		ooysU7CDBeL3Apinrm = ff1rnYPEpj78QFX5d and HyKTpcu89bFSVRmhY7P
		if ooysU7CDBeL3Apinrm: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,jL5CrsRwebpyDVXUc1EQP(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࠬ"),QjAINyUC7MDRq5d8e4vl9(u"ࠧอ์าࠤ࠳࠴ࠠ็ฮะฮࠥ฿ๅๅ์ฬࠤู๊อࠡษ็้้็วหࠢส่็ี๊ๆห่้ࠣฮั็ษ่ะࠥ࠴࠮๊ࠡ฼หิࠦวๅสิ๊ฬ๋ฬࠡว็ํࠥ๎ึฺ์ฬࠤฬ๊ีโำࠣ࠲࠳่ࠦื฻ํอࠥ฼ศุࠢส่๊฻ๆฺࠩ࠭"))
		else: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ggjO5CrKVRPITaesWkxD(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣๅู๊สࠡ฻่่๏ฯࠠหืไ๎ึࠦวๅสิ๊ฬ๋ฬ๊ࠡศ฽ฬีส่ࠢศ่๎่ࠦื฻ํอࠥ฼ศุࠢส่๊฻ๆฺࠩ࠮"))
	return ooysU7CDBeL3Apinrm
def YrHUwPjAu8ipo():
	import XbdWsnBA9G
	XbdWsnBA9G.zaSVrEi1HqZnjctTFuLsmQB7Y()
	ddecO3Tb9U5k = LhFAGlQ19zr
	Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠩࡦࡩࡳࡺࡥࡳࠩ࠯"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Hr25gta6XcqO(u"๋้ࠪࠦสา์าࠤู๊อࠡฮ่๎฾ࠦวๅๅสุࠥลࠧ࠰"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠫฬ๊ใศึࠣ๎ุืูࠡ฻่่ࠥอไษำ้ห๊า้ࠠ็ึั์ฺ๊ࠦ์าࠤุำศࠡษ็ูๆำวห่๊ࠢࠥอไฦ่อี๋ะฺ่ࠠาࠤฬ๊อศฮฬࠤส๊๊่ษࠣ࠲࠳ูࠦๅ็สࠤศ์ࠠศๆ่ืา๊ࠦห็ࠣฮ้่วว์สࠤ฾์ฯࠡษ้ฮ์อมࠡ฻่ีࠥอไึใะหฯࠦ࠮࠯๋ࠢว๏฼วࠡษ็ุ้ำࠠๅษࠣ๎฻ื้ࠠ็่็๋๊ࠦฮๆࠣฬ฾฼ࠠศๆุ่ฬ้ไࠨ࠱"))
	if Scj7zgGFVA83otMpwUkxhm0BLN1==BkM54Kr7Qbqn:
		ddecO3Tb9U5k = rSOlpJAWb8Vh(Xsc4lqOhdziToWvunbRNSQZKIY8E,EsCplGc5N4mBuYW0RVQt6b,LhFAGlQ19zr)
		if ddecO3Tb9U5k: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EE1jeHnIoad(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࠲"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠭อ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หุ้ࠣำࠠๆฮ็ำ้ࠥวีࠢส่อืๆศ็ฯࠫ࠳"))
		else: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦๅิฯ้ࠣั๊ฯࠡๅสุࠥอไษำ้ห๊าࠧ࠴"))
	return ddecO3Tb9U5k
def JyUrDd8HmoXPR3jqehfgi6ZY1l2xp():
	ddecO3Tb9U5k = LhFAGlQ19zr
	Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(sJw9QWiq1Kr0xfeVRI(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ࠵"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,aOQTKXFL54Nl60Zhp3MbE(u"ࠩึศฬ๊ࠧ࠶"),aOQTKXFL54Nl60Zhp3MbE(u"๋้ࠪࠦร็ฬ้ࠣฯษใะ๋ࠢฮึ๐ฯࠡ็ึัࠥ๎สึใํีࠥาๅ๋฻ࠣษ฾ีวะษอࠤอืๆศ็ฯࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯࠠ࠯ࠢะ๎ะࠦสฺ๊าࠤัฺ๋๊ࠢส่ส฿ฯศัสฮࠥหไฺ๊๋ࠢ฾๐ษࠡฬฮฬ๏ะࠠศๆหี๋อๅอࠢยࠫ࠷"))
	if Scj7zgGFVA83otMpwUkxhm0BLN1==BkM54Kr7Qbqn:
		try:
			HoxKENAey2MdTt9kDUrVnWGLS0CPa.remove(M9MFNdZq3PuBkCsytJ)
			ddecO3Tb9U5k = EsCplGc5N4mBuYW0RVQt6b
		except: pass
		if ddecO3Tb9U5k: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,vU6DxuzPwMpg(u"ࠫฯ๋ࠠษ่ฯหาࠦๅิฯࠣ์ฯ฻แ๋ำ้้ࠣ็ࠠฦ฻าหิอสࠡสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠫ࠸"))
		else: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ggjO5CrKVRPITaesWkxD(u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡ็ึั๋ࠥไโࠢส่ส฿ฯศัสฮࠬ࠹"))
	return ddecO3Tb9U5k
def R7DwbNdJajKztnMcfux2UA():
	EEMwiv0RrUSZ,mOj9NtcpaZbFh = zhd7pRlPVkFuMfaHgeD4icNZObAnQ(XaGSbTRsEVH2vze)
	HdJlnyjYQziKL6o9,RRazcum7LbQlVr = zhd7pRlPVkFuMfaHgeD4icNZObAnQ(eskp1J4nAlQ)
	YmavJ4PWcyqU1xzAGDt6bjKpCgQShZ,EfdpGJU0yNcSbAKVtTLj = ucm10ohnRLA8d5ybFKEYkNQa3e6Gr(ZwgPxblcB0Caj95vADVm)
	p31JQlqT7eY6GtzdfwoUgRF,ooz1XqHy4C2anbV9k3dx5 = EEMwiv0RrUSZ+HdJlnyjYQziKL6o9+YmavJ4PWcyqU1xzAGDt6bjKpCgQShZ,mOj9NtcpaZbFh+RRazcum7LbQlVr+EfdpGJU0yNcSbAKVtTLj
	XEA2DbhGpcl7 = s5WMHyQN4mpie(u"࠭ࠠࠩࠩ࠺")+nn5eg2sIAqOozSxi9Y(EEMwiv0RrUSZ)+Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠧࠡ࠯ࠣࠫ࠻")+str(mOj9NtcpaZbFh)+wdftVMyzF17cYETHu(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠼")
	HiguZF3b5pS4XeOMYDsTxk7QPVLUh = CsDcLqQUVK4YBvHFW1(u"ࠩࠣࠬࠬ࠽")+nn5eg2sIAqOozSxi9Y(HdJlnyjYQziKL6o9)+ssynAg0zhSkoCpOMDV9(u"ࠪࠤ࠲ࠦࠧ࠾")+str(RRazcum7LbQlVr)+sIzDXlTHYUC5L3xZGnr(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬ࠿")
	jKDJaPnXqs35lhHdvwOSL = wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠬࠦࠨࠨࡀ")+nn5eg2sIAqOozSxi9Y(YmavJ4PWcyqU1xzAGDt6bjKpCgQShZ)+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭ࠠ࠮ࠢࠪࡁ")+str(EfdpGJU0yNcSbAKVtTLj)+FgXzMs0YSDt(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࡂ")
	Swsqv2N01iQnITgrbC = sIzDXlTHYUC5L3xZGnr(u"ࠨࠢࠫࠫࡃ")+nn5eg2sIAqOozSxi9Y(p31JQlqT7eY6GtzdfwoUgRF)+oRJAfwD957WkUyBM1Ehu8m(u"ࠩࠣ࠱ࠥ࠭ࡄ")+str(ooz1XqHy4C2anbV9k3dx5)+KfHAW8VGbrxi(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡅ")
	OZD1l4pAMzeH(o1INZ3ViQqS0Uw5z6kMjbv(u"ࠫࡱ࡯࡮࡬ࠩࡆ"),K2l9rLfvoXxyZ4NYapO+AAbvaXV2DQzfNHdm4U3tT(u"๋ࠬำฮࠢส่ัฺ๋๊ࠩࡇ")+Swsqv2N01iQnITgrbC,fy8iFgEkrO12NR9TWBI35sjY6qHvV,KfHAW8VGbrxi(u"࠷࠰࠹࠶ࣷ"))
	OZD1l4pAMzeH(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭࡬ࡪࡰ࡮ࠫࡈ"),n0nFOd4yR97fQzNLSW+Gcw2nelTR864XCVruO3mAFqI5a(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ࡉ")+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,sIzDXlTHYUC5L3xZGnr(u"࠹࠺࠻࠼ࣸ"))
	OZD1l4pAMzeH(Hr25gta6XcqO(u"ࠨ࡮࡬ࡲࡰ࠭ࡊ"),K2l9rLfvoXxyZ4NYapO+s5WMHyQN4mpie(u"่ࠩืาࠦี้ำࠣห้้สศสฬࠫࡋ")+XEA2DbhGpcl7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Hr25gta6XcqO(u"࠲࠲࠻࠵ࣹ"))
	OZD1l4pAMzeH(o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪࡰ࡮ࡴ࡫ࠨࡌ"),K2l9rLfvoXxyZ4NYapO+vU6DxuzPwMpg(u"ู๊ࠫอࠡๅสุࠥอไษำ้ห๊าࠧࡍ")+HiguZF3b5pS4XeOMYDsTxk7QPVLUh,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QjAINyUC7MDRq5d8e4vl9(u"࠳࠳࠼࠷ࣺ"))
	OZD1l4pAMzeH(s5WMHyQN4mpie(u"ࠬࡲࡩ࡯࡭ࠪࡎ"),K2l9rLfvoXxyZ4NYapO+o1INZ3ViQqS0Uw5z6kMjbv(u"࠭ๅิฯࠣษ฾ีวะษอࠤฬ๊ศา่ส้ั࠭ࡏ")+jKDJaPnXqs35lhHdvwOSL,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EE1jeHnIoad(u"࠴࠴࠽࠹ࣻ"))
	OZD1l4pAMzeH(vU6DxuzPwMpg(u"ࠧ࡭࡫ࡱ࡯ࠬࡐ"),K2l9rLfvoXxyZ4NYapO+SnhLjmfeJC(u"ࠨฬุๅ๏ืࠠศๆหี๋อๅอࠩࡑ")+Swsqv2N01iQnITgrbC,fy8iFgEkrO12NR9TWBI35sjY6qHvV,AAbvaXV2DQzfNHdm4U3tT(u"࠵࠵࠾࠴ࣼ"))
	return
def HHlKdMOR3SUs2y1g8Wh4wXrftkA():
	EEMwiv0RrUSZ,mOj9NtcpaZbFh = zhd7pRlPVkFuMfaHgeD4icNZObAnQ(WZfqnGSYlRQAV8MihD7BPs)
	HdJlnyjYQziKL6o9,RRazcum7LbQlVr = zhd7pRlPVkFuMfaHgeD4icNZObAnQ(X6AmGZLUf8Dhdr3SRCe2YQJHF)
	YmavJ4PWcyqU1xzAGDt6bjKpCgQShZ,EfdpGJU0yNcSbAKVtTLj = zhd7pRlPVkFuMfaHgeD4icNZObAnQ(u5fU1irdYwz27Gle43mXOHPQg)
	p31JQlqT7eY6GtzdfwoUgRF,ooz1XqHy4C2anbV9k3dx5 = ucm10ohnRLA8d5ybFKEYkNQa3e6Gr(pvsZguhiwFLV)
	p31JQlqT7eY6GtzdfwoUgRF -= ssynAg0zhSkoCpOMDV9(u"࠸࠼࠸࠷࠶ࣽ")
	ooz1XqHy4C2anbV9k3dx5 -= BkM54Kr7Qbqn
	sTjfJ91McWaNYk7hmlDAQtIe8 = str(HoxKENAey2MdTt9kDUrVnWGLS0CPa.listdir(ihFXL4gb36G1U5rWSCKEMp29))
	Cn0poWaczxBq8 = sTjfJ91McWaNYk7hmlDAQtIe8.count(SnhLjmfeJC(u"ࠩ࡮ࡳࡩ࡯࡟ࡴࡶࡤࡧࡰࡺࡲࡢࡥࡨࠫࡒ"))+sTjfJ91McWaNYk7hmlDAQtIe8.count(QjAINyUC7MDRq5d8e4vl9(u"ࠪ࡯ࡴࡪࡩࡠࡥࡵࡥࡸ࡮࡬ࡰࡩࠪࡓ"))
	XEA2DbhGpcl7 = FgXzMs0YSDt(u"ࠫࠥ࠮ࠧࡔ")+nn5eg2sIAqOozSxi9Y(EEMwiv0RrUSZ)+Gcw2nelTR864XCVruO3mAFqI5a(u"ࠬࠦ࠭ࠡࠩࡕ")+str(mOj9NtcpaZbFh)+wdftVMyzF17cYETHu(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࡖ")
	HiguZF3b5pS4XeOMYDsTxk7QPVLUh = I18uSKaWhgTBeYUPD4sr(u"ࠧࠡࠪࠪࡗ")+nn5eg2sIAqOozSxi9Y(HdJlnyjYQziKL6o9)+Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠨࠢ࠰ࠤࠬࡘ")+str(RRazcum7LbQlVr)+EE1jeHnIoad(u"ࠩࠣࡪ࡮ࡲࡥࡴ࡙ࠫࠪ")
	jKDJaPnXqs35lhHdvwOSL = KfHAW8VGbrxi(u"ࠪࠤ࡚࠭࠭")+nn5eg2sIAqOozSxi9Y(YmavJ4PWcyqU1xzAGDt6bjKpCgQShZ)+wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠫࠥ࠳ࠠࠨ࡛")+str(EfdpGJU0yNcSbAKVtTLj)+CsDcLqQUVK4YBvHFW1(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭࡜")
	Swsqv2N01iQnITgrbC = SnhLjmfeJC(u"࠭ࠠࠩࠩ࡝")+nn5eg2sIAqOozSxi9Y(p31JQlqT7eY6GtzdfwoUgRF)+vU6DxuzPwMpg(u"ࠧࠪࠩ࡞")
	RmPzk5cdZO1twLx0 = C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨࠢࠫࠫ࡟")+str(Cn0poWaczxBq8)+vU6DxuzPwMpg(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࡠ")
	M06JC7gNv2OmV3ebp8D1IF9ha = EEMwiv0RrUSZ+HdJlnyjYQziKL6o9+YmavJ4PWcyqU1xzAGDt6bjKpCgQShZ+p31JQlqT7eY6GtzdfwoUgRF
	C37Q0bmsoJ8F4cvEXTikg = mOj9NtcpaZbFh+RRazcum7LbQlVr+EfdpGJU0yNcSbAKVtTLj+ooz1XqHy4C2anbV9k3dx5+Cn0poWaczxBq8
	YMaiHbnIThsP7q = LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠪࠤ࠭࠭ࡡ")+nn5eg2sIAqOozSxi9Y(M06JC7gNv2OmV3ebp8D1IF9ha)+ggjO5CrKVRPITaesWkxD(u"ࠫࠥ࠳ࠠࠨࡢ")+str(C37Q0bmsoJ8F4cvEXTikg)+EE1jeHnIoad(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࡣ")
	OZD1l4pAMzeH(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠭࡬ࡪࡰ࡮ࠫࡤ"),K2l9rLfvoXxyZ4NYapO+CsDcLqQUVK4YBvHFW1(u"ࠧๆีะࠤฬ๊ฬๆ์฼ࠫࡥ")+YMaiHbnIThsP7q,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EE1jeHnIoad(u"࠽࠴࠶ࣾ"))
	OZD1l4pAMzeH(sIzDXlTHYUC5L3xZGnr(u"ࠨ࡮࡬ࡲࡰ࠭ࡦ"),n0nFOd4yR97fQzNLSW+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠩࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨࡧ")+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Hr25gta6XcqO(u"࠹࠺࠻࠼ࣿ"))
	OZD1l4pAMzeH(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪࡰ࡮ࡴ࡫ࠨࡨ"),K2l9rLfvoXxyZ4NYapO+ggjO5CrKVRPITaesWkxD(u"ู๊ࠫอࠡษ็้้็วหࠢส่๊สโหหࠪࡩ")+XEA2DbhGpcl7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ssynAg0zhSkoCpOMDV9(u"࠸࠶࠴ऀ"))
	OZD1l4pAMzeH(QjAINyUC7MDRq5d8e4vl9(u"ࠬࡲࡩ࡯࡭ࠪࡪ"),K2l9rLfvoXxyZ4NYapO+Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠭ๅิฯࠣห้๋ไโษอࠤฬ๊ๅื฼๋฻ฮ࠭࡫")+HiguZF3b5pS4XeOMYDsTxk7QPVLUh,fy8iFgEkrO12NR9TWBI35sjY6qHvV,s5WMHyQN4mpie(u"࠹࠷࠶ँ"))
	OZD1l4pAMzeH(SnhLjmfeJC(u"ࠧ࡭࡫ࡱ࡯ࠬ࡬"),K2l9rLfvoXxyZ4NYapO+sJw9QWiq1Kr0xfeVRI(u"ࠨ็ึัࠥอไึ๊ิࠤฬ๊โะ์่อࠬ࡭")+jKDJaPnXqs35lhHdvwOSL,fy8iFgEkrO12NR9TWBI35sjY6qHvV,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠺࠸࠸ं"))
	OZD1l4pAMzeH(oRJAfwD957WkUyBM1Ehu8m(u"ࠩ࡯࡭ࡳࡱࠧ࡮"),K2l9rLfvoXxyZ4NYapO+C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠪฮๆื๊฻่่ࠢๆࠦี้ำࠣห้หึศใสฮࠬ࡯")+Swsqv2N01iQnITgrbC,fy8iFgEkrO12NR9TWBI35sjY6qHvV,AAbvaXV2DQzfNHdm4U3tT(u"࠻࠹࠺ः"))
	OZD1l4pAMzeH(LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠫࡱ࡯࡮࡬ࠩࡰ"),K2l9rLfvoXxyZ4NYapO+s5WMHyQN4mpie(u"๋ࠬำฮ่่ࠢๆอสࠡษ็็ึอิࠡษ็้ษ่สสࠩࡱ")+RmPzk5cdZO1twLx0,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EE1jeHnIoad(u"࠼࠺࠶ऄ"))
	return
def xxazf9QbuElZXwnDF():
	O5OhT3nNEzqa2 = EsCplGc5N4mBuYW0RVQt6b if Gcw2nelTR864XCVruO3mAFqI5a(u"࠭࠯ࠨࡲ") in ywEBSl6zHMFsO4Qmh3TJP8itgj else LhFAGlQ19zr
	if not O5OhT3nNEzqa2:
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,AAbvaXV2DQzfNHdm4U3tT(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࡳ"),ssynAg0zhSkoCpOMDV9(u"ࠨ฻่่๏ฯࠠห่฻๎ๆࠦวๅฮ๊หืࠦๅห๊ไีฮࠦแใู่ࠣศา็ำหࠣ๎ํ์ใิࠢ࠱࠲๋ࠥหๅࠢฦะ์ุษࠡลห่ࠥ๎ร็ัิ์๏ี้ࠠๆํ์๋้ำࠡ࠰࠱ࠤํา็ศิๆࠤ้๐ำࠡ็้ࠤ์ึวࠡษ็๊ํ฿ࠧࡴ"))
		return
	gYT79cyvtiJkrDNOH = OdiZIyCfDUsW3JBGR2VAb.getSetting(I18uSKaWhgTBeYUPD4sr(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭ࡵ"))
	if not gYT79cyvtiJkrDNOH: yuPg0lbJrcWXx2QIep4LsOUSv7B()
	EEMwiv0RrUSZ,mOj9NtcpaZbFh = zhd7pRlPVkFuMfaHgeD4icNZObAnQ(qLJm5ufXBh)
	HdJlnyjYQziKL6o9,RRazcum7LbQlVr = zhd7pRlPVkFuMfaHgeD4icNZObAnQ(g1mDX9e3oif5uMCzb)
	YmavJ4PWcyqU1xzAGDt6bjKpCgQShZ,EfdpGJU0yNcSbAKVtTLj = zhd7pRlPVkFuMfaHgeD4icNZObAnQ(qaD0xbYsT6gOujoXz538r1wkAM)
	p31JQlqT7eY6GtzdfwoUgRF,ooz1XqHy4C2anbV9k3dx5 = zhd7pRlPVkFuMfaHgeD4icNZObAnQ(x9SYGtivQH1)
	jRN6us4EntWFU5LlA,Cn0poWaczxBq8 = zhd7pRlPVkFuMfaHgeD4icNZObAnQ(ILzm10Nxrb)
	tNZCMJq2zfw1X8sFjxrTRISn,Ua57eOyHkIpVwjBKf6JQRcD3bsmi = zhd7pRlPVkFuMfaHgeD4icNZObAnQ(ZZD7MSWkOheNIXuqHcVt1fPJL9y6v)
	XEA2DbhGpcl7 = CsDcLqQUVK4YBvHFW1(u"ࠪࠤ࠭࠭ࡶ")+nn5eg2sIAqOozSxi9Y(EEMwiv0RrUSZ)+SnhLjmfeJC(u"ࠫࠥ࠳ࠠࠨࡷ")+str(mOj9NtcpaZbFh)+FmYoGejTnwKME7d9zPc(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࡸ")
	HiguZF3b5pS4XeOMYDsTxk7QPVLUh = s5WMHyQN4mpie(u"࠭ࠠࠩࠩࡹ")+nn5eg2sIAqOozSxi9Y(HdJlnyjYQziKL6o9)+Gcw2nelTR864XCVruO3mAFqI5a(u"ࠧࠡ࠯ࠣࠫࡺ")+str(RRazcum7LbQlVr)+aOQTKXFL54Nl60Zhp3MbE(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࡻ")
	jKDJaPnXqs35lhHdvwOSL = N6NGJ4vpmidqMCh7yo(u"ࠩࠣࠬࠬࡼ")+nn5eg2sIAqOozSxi9Y(YmavJ4PWcyqU1xzAGDt6bjKpCgQShZ)+C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠪࠤ࠲ࠦࠧࡽ")+str(EfdpGJU0yNcSbAKVtTLj)+QjAINyUC7MDRq5d8e4vl9(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࡾ")
	Swsqv2N01iQnITgrbC = SnhLjmfeJC(u"ࠬࠦࠨࠨࡿ")+nn5eg2sIAqOozSxi9Y(p31JQlqT7eY6GtzdfwoUgRF)+CsDcLqQUVK4YBvHFW1(u"࠭ࠠ࠮ࠢࠪࢀ")+str(ooz1XqHy4C2anbV9k3dx5)+CsDcLqQUVK4YBvHFW1(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࢁ")
	RmPzk5cdZO1twLx0 = LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨࠢࠫࠫࢂ")+nn5eg2sIAqOozSxi9Y(jRN6us4EntWFU5LlA)+jL5CrsRwebpyDVXUc1EQP(u"ࠩࠣ࠱ࠥ࠭ࢃ")+str(Cn0poWaczxBq8)+vU6DxuzPwMpg(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࢄ")
	aFCDlAhzd7ynSu2NBV8JTRH6 = FmYoGejTnwKME7d9zPc(u"ࠫࠥ࠮ࠧࢅ")+nn5eg2sIAqOozSxi9Y(tNZCMJq2zfw1X8sFjxrTRISn)+I18uSKaWhgTBeYUPD4sr(u"ࠬࠦ࠭ࠡࠩࢆ")+str(Ua57eOyHkIpVwjBKf6JQRcD3bsmi)+wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࢇ")
	M06JC7gNv2OmV3ebp8D1IF9ha = EEMwiv0RrUSZ+HdJlnyjYQziKL6o9+YmavJ4PWcyqU1xzAGDt6bjKpCgQShZ+p31JQlqT7eY6GtzdfwoUgRF+jRN6us4EntWFU5LlA+tNZCMJq2zfw1X8sFjxrTRISn
	C37Q0bmsoJ8F4cvEXTikg = mOj9NtcpaZbFh+RRazcum7LbQlVr+EfdpGJU0yNcSbAKVtTLj+ooz1XqHy4C2anbV9k3dx5+Cn0poWaczxBq8+Ua57eOyHkIpVwjBKf6JQRcD3bsmi
	YMaiHbnIThsP7q = C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧࠡࠪࠪ࢈")+nn5eg2sIAqOozSxi9Y(M06JC7gNv2OmV3ebp8D1IF9ha)+C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨࠢ࠰ࠤࠬࢉ")+str(C37Q0bmsoJ8F4cvEXTikg)+wdftVMyzF17cYETHu(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࢊ")
	OZD1l4pAMzeH(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪࡰ࡮ࡴ࡫ࠨࢋ"),K2l9rLfvoXxyZ4NYapO+QjAINyUC7MDRq5d8e4vl9(u"ࠫส฿ืศรࠣีำ฻ษࠡไิหฦฯ้ࠠๅอหอฯࠧࢌ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,oRJAfwD957WkUyBM1Ehu8m(u"࠽࠵࠹अ"))
	OZD1l4pAMzeH(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠬࡲࡩ࡯࡭ࠪࢍ"),K2l9rLfvoXxyZ4NYapO+vU6DxuzPwMpg(u"࠭ๅิฯࠣห้าๅ๋฻ࠪࢎ")+YMaiHbnIThsP7q,fy8iFgEkrO12NR9TWBI35sjY6qHvV,SnhLjmfeJC(u"࠷࠶࠹आ"))
	OZD1l4pAMzeH(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧ࡭࡫ࡱ࡯ࠬ࢏"),n0nFOd4yR97fQzNLSW+N6NGJ4vpmidqMCh7yo(u"ࠨࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧ࢐")+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠺࠻࠼࠽इ"))
	OZD1l4pAMzeH(wdftVMyzF17cYETHu(u"ࠩ࡯࡭ࡳࡱࠧ࢑"),K2l9rLfvoXxyZ4NYapO+O3OVuapf0YFjbm5oUQDg(u"ุ้ࠪำࠠๆๆไหฯࠦࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠪ࢒")+XEA2DbhGpcl7,fy8iFgEkrO12NR9TWBI35sjY6qHvV,O3OVuapf0YFjbm5oUQDg(u"࠹࠸࠵ई"))
	OZD1l4pAMzeH(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠫࡱ࡯࡮࡬ࠩ࢓"),K2l9rLfvoXxyZ4NYapO+Gcw2nelTR864XCVruO3mAFqI5a(u"๋ࠬำฮ่่ࠢๆอสࠡࡦࡵࡳࡵࡨ࡯ࡹࠩ࢔")+HiguZF3b5pS4XeOMYDsTxk7QPVLUh,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Hr25gta6XcqO(u"࠺࠹࠷उ"))
	OZD1l4pAMzeH(CsDcLqQUVK4YBvHFW1(u"࠭࡬ࡪࡰ࡮ࠫ࢕"),K2l9rLfvoXxyZ4NYapO+aOQTKXFL54Nl60Zhp3MbE(u"ࠧๆีะࠤ๊๊แศฬࠣࡸࡴࡳࡢࡴࡶࡲࡲࡪࡹࠧ࢖")+jKDJaPnXqs35lhHdvwOSL,fy8iFgEkrO12NR9TWBI35sjY6qHvV,o1INZ3ViQqS0Uw5z6kMjbv(u"࠻࠺࠹ऊ"))
	OZD1l4pAMzeH(oRJAfwD957WkUyBM1Ehu8m(u"ࠨ࡮࡬ࡲࡰ࠭ࢗ"),K2l9rLfvoXxyZ4NYapO+s5WMHyQN4mpie(u"่ࠩืาࠦๅๅใสฮࠥࡲ࡯ࡨࡩࡨࡶࠬ࢘")+Swsqv2N01iQnITgrbC,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠼࠻࠴ऋ"))
	OZD1l4pAMzeH(CsDcLqQUVK4YBvHFW1(u"ࠪࡰ࡮ࡴ࡫ࠨ࢙"),K2l9rLfvoXxyZ4NYapO+CsDcLqQUVK4YBvHFW1(u"ู๊ࠫอࠡ็็ๅฬะࠠ࡭ࡱࡪ࢚ࠫ")+RmPzk5cdZO1twLx0,fy8iFgEkrO12NR9TWBI35sjY6qHvV,I18uSKaWhgTBeYUPD4sr(u"࠽࠵࠶ऌ"))
	OZD1l4pAMzeH(wdftVMyzF17cYETHu(u"ࠬࡲࡩ࡯࡭࢛ࠪ"),K2l9rLfvoXxyZ4NYapO+EE1jeHnIoad(u"࠭ๅิฯ้้ࠣ็วหࠢࡤࡲࡷ࠭࢜")+aFCDlAhzd7ynSu2NBV8JTRH6,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Hr25gta6XcqO(u"࠷࠶࠸ऍ"))
	return
def SYPxROov86GFIaeVJlBr4K(showDialogs):
	if showDialogs: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࢝"),SnhLjmfeJC(u"ࠨ็ฯ่ิࠦี้ำࠣ็ฯอศสࠢส่็๎วว็ࠣ࠲࠳ࠦ็ัษࠣห้๋ฬๅัࠣๅ๏ํࠠษ฻ูࠤ็๎วว็ࠣห้ฮั็ษ่ะ๋ࠥฮำ่ฬࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠡ࠰࠱ࠤ฾์ฯࠡ็ึัࠥอไๆฮ็ำู๊ࠥใ๊่ࠤฬ๊ศา่ส้ัࠦศฯๆๅࠤ๊าไะࠢฯำ๏ี้ࠠ์หำศࠦๅาหࠣวำื้ࠡส่่หํࠠษษ็ูํืฺ่ࠠาࠤๆะอࠡษ็ๆํอฦๆࠩ࢞"))
	HQ97RL6MvU4PJCSqc30KFNgVpm,WUfitaCTlGYB8FK = [],D2D96X5NGamBhrFwvL8VEbqiSfZIl
	for uLb1XoWdyIvH7gJRi8G,cawA2foBqDhyQUMJHVtXO3xu1WYnI,G2HXQWVPlcTgDKjAC7 in HoxKENAey2MdTt9kDUrVnWGLS0CPa.walk(P8F6NtJD5ridLmglTbWpzMo4,topdown=LhFAGlQ19zr):
		irg4cIS8lf = len(G2HXQWVPlcTgDKjAC7)
		if irg4cIS8lf>aOQTKXFL54Nl60Zhp3MbE(u"࠶࠲࠳ऎ"): HQ97RL6MvU4PJCSqc30KFNgVpm.append(cawA2foBqDhyQUMJHVtXO3xu1WYnI)
		WUfitaCTlGYB8FK += irg4cIS8lf
	LCHab8iN37x9nf2kU = WUfitaCTlGYB8FK>EE1jeHnIoad(u"࠷࠳࠴࠵ए")
	if showDialogs:
		count = n0nFOd4yR97fQzNLSW+wdftVMyzF17cYETHu(u"ࠩ็ำ๏้ࠠࠡࠩ࢟")+str(WUfitaCTlGYB8FK)+N6NGJ4vpmidqMCh7yo(u"ࠪࠤࠥ฻่าหࠪࢠ")+T7ASIp1ZYwio9HQ8cObJK
		if not HQ97RL6MvU4PJCSqc30KFNgVpm and not LCHab8iN37x9nf2kU: Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࢡ"),sIzDXlTHYUC5L3xZGnr(u"๊ࠬวࠡ์๋ะิูࠦ็ัๆࠤฺ๎ัࠡๅอหอฯࠠไอํีฮࠦ࠮࠯๋่ࠢ์ึวࠡๆสࠤฯำสศฮࠣว๋ࠦสๆีะࠤฺ๎ัࠡษ็็ฯอศสࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦๅิฯูࠣํืࠠศๆๆฮฬฮษࠡษ็ฦ๋ࠦฟࠢࠢ࡟ࡲࡡࡴࠧࢢ")+count)
		else: Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,PlpyFa9QMKXxOD1cvHzmI(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢣ"),QjAINyUC7MDRq5d8e4vl9(u"ࠧๅัํ็ࠥ฻่าࠢๆฮฬฮษࠡๅฮ๎ึฯࠠ࠯࠰ࠣ์์ึวࠡไาࠤ๏ูศษุ่ࠢฬ้ไࠡใํࠤฯฺฺ๋ๆࠣห้า็ศิࠣ์ฯฺฺ๋ๆࠣฬึ์วๆฮࠣ฽๊อฯࠡ࠰࠱ࠤศ์สࠡสะหัฯࠠฦๆ์ࠤู๊อ้ࠡำ๋ࠥอไึ๊ิࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡ็ึัࠥ฻่าࠢส่่ะวษหࠣห้ศๆࠡมࠤࠤࡡࡴ࡜࡯ࠩࢤ")+count)
	else: Scj7zgGFVA83otMpwUkxhm0BLN1 = BkM54Kr7Qbqn
	if Scj7zgGFVA83otMpwUkxhm0BLN1==BkM54Kr7Qbqn:
		if LCHab8iN37x9nf2kU: rSOlpJAWb8Vh(uLb1XoWdyIvH7gJRi8G,LhFAGlQ19zr,LhFAGlQ19zr)
		elif HQ97RL6MvU4PJCSqc30KFNgVpm:
			for cawA2foBqDhyQUMJHVtXO3xu1WYnI in HQ97RL6MvU4PJCSqc30KFNgVpm: rSOlpJAWb8Vh(cawA2foBqDhyQUMJHVtXO3xu1WYnI,LhFAGlQ19zr,LhFAGlQ19zr)
	return
def yuPg0lbJrcWXx2QIep4LsOUSv7B():
	ooysU7CDBeL3Apinrm = LhFAGlQ19zr
	Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,O3OVuapf0YFjbm5oUQDg(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࢥ"),vU6DxuzPwMpg(u"ࠩ็็๏ฺ๊ࠦ็็ࠤฬ๊ส็ฺํๅࠥ฿ๆะๅࠣ࠲࠳ࠦศา่ส้ัูࠦๆษาࠤอำวอหࠣษ้๏ࠠฦ฻ฺหฦࠦัฯืฬࠤฬ๊โาษฤอࠥ๎วๅๅอหอฯࠠๅๆ่่ๆอส๊ࠡส่๊าไะษอࠤฬ๊ส๋ࠢึ์ๆ๊ࠦๆีะ๋ฬࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤ์๊ࠠหำํำࠥหูุษฤࠤ์ึ็ࠡษ็ีำ฻ษࠡษ็ฦ๋ࠦฟࠢࠩࢦ"))
	if Scj7zgGFVA83otMpwUkxhm0BLN1==-N6NGJ4vpmidqMCh7yo(u"࠴ऐ"): return
	if Scj7zgGFVA83otMpwUkxhm0BLN1:
		import subprocess as fF3eMHs1JlcAhRa5
		try:
			fF3eMHs1JlcAhRa5.Popen(AAbvaXV2DQzfNHdm4U3tT(u"ࠪࡷࡺ࠭ࢧ"))
			ooysU7CDBeL3Apinrm = EsCplGc5N4mBuYW0RVQt6b
		except: pass
		if ooysU7CDBeL3Apinrm:
			RdSIb8uUQ5MX2F = qLJm5ufXBh+ksJdoFWhxTz8Y2N7bOZE+g1mDX9e3oif5uMCzb+ksJdoFWhxTz8Y2N7bOZE+qaD0xbYsT6gOujoXz538r1wkAM+ksJdoFWhxTz8Y2N7bOZE+x9SYGtivQH1+ksJdoFWhxTz8Y2N7bOZE+ILzm10Nxrb+ksJdoFWhxTz8Y2N7bOZE+ZZD7MSWkOheNIXuqHcVt1fPJL9y6v
			Op0kgz8QevXoK7Nl = fF3eMHs1JlcAhRa5.Popen(uulNDCPyef78(u"ࠫࡸࡻࠠ࠮ࡥࠣࠦࡨ࡮࡭ࡰࡦࠣ࠱ࡗࠦ࠰࠸࠹࠺ࠤࠬࢨ")+RdSIb8uUQ5MX2F+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬࠨࠧࢩ"),shell=EsCplGc5N4mBuYW0RVQt6b,stdin=fF3eMHs1JlcAhRa5.PIPE,stdout=fF3eMHs1JlcAhRa5.PIPE,stderr=fF3eMHs1JlcAhRa5.PIPE)
			GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,sJw9QWiq1Kr0xfeVRI(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢪ"),O3OVuapf0YFjbm5oUQDg(u"ࠧ็ฮะฮࠥ฿ๅๅ์ฬࠤส฿ืศรࠣห้ืฮึหࠪࢫ"))
		else: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,O3OVuapf0YFjbm5oUQDg(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࢬ"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠩ฼้้๐ษࠡว฼฻ฬวࠠาะุอࠥอไใำสลฮ่ࠦศๆๆฮฬฮษࠡฬะฮฬาࠠษำ้ห๊าࠠࠡࡴࡲࡳࡹࠦࠠฤ๊ࠣࠤࡸࡻࡰࡦࡴࡸࡷࡪࡸࠠࠡล๋ࠤࠥࡹࡵ๋ࠡࠢะ์อาไࠢ็หࠥ๐่อัࠣๅ๏ํ่ࠠาสࠤฬ๊ศา่ส้ัࠦ࠮࠯ࠢฦ์้่ࠥะ์ࠣ฾๏ืࠠใษาีࠥ฿ไ๊ࠢสืฯิฯศ็๋ࠣีอࠠศๆหี๋อๅอࠩࢭ"))
	return ooysU7CDBeL3Apinrm
def nn5eg2sIAqOozSxi9Y(M06JC7gNv2OmV3ebp8D1IF9ha):
	for om0A7VRk2HYGbaUNPSDfJCIxEv in [aOQTKXFL54Nl60Zhp3MbE(u"ࠪࡆࠬࢮ"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠫࡐࡈࠧࢯ"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠬࡓࡂࠨࢰ"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠭ࡇࡃࠩࢱ"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠧࡕࡄࠪࢲ")]:
		if M06JC7gNv2OmV3ebp8D1IF9ha<uulNDCPyef78(u"࠵࠵࠸࠴ऑ"): break
		else: M06JC7gNv2OmV3ebp8D1IF9ha /= CsDcLqQUVK4YBvHFW1(u"࠶࠶࠲࠵࠰࠳ऒ")
	YMaiHbnIThsP7q = oRJAfwD957WkUyBM1Ehu8m(u"ࠣࠧ࠶࠲࠶࡬ࠠࠦࡵࠥࢳ")%(M06JC7gNv2OmV3ebp8D1IF9ha,om0A7VRk2HYGbaUNPSDfJCIxEv)
	return YMaiHbnIThsP7q
def zhd7pRlPVkFuMfaHgeD4icNZObAnQ(VpRSn1mwCOoz05EbH6I9AP=KfHAW8VGbrxi(u"ࠩ࠱ࠫࢴ")):
	global hjR15y8PscK2ldv4AU9FakWeoBIOHS,GBn1UXEQHTCbp8NfP6c90Rxq4
	hjR15y8PscK2ldv4AU9FakWeoBIOHS,GBn1UXEQHTCbp8NfP6c90Rxq4 = D2D96X5NGamBhrFwvL8VEbqiSfZIl,D2D96X5NGamBhrFwvL8VEbqiSfZIl
	def PiKpJjOHxeC90ydLIbntvoMD(VpRSn1mwCOoz05EbH6I9AP):
		global hjR15y8PscK2ldv4AU9FakWeoBIOHS,GBn1UXEQHTCbp8NfP6c90Rxq4
		if HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.exists(VpRSn1mwCOoz05EbH6I9AP):
			if D2D96X5NGamBhrFwvL8VEbqiSfZIl and EE1jeHnIoad(u"ࠪࡷࡨࡧ࡮ࡥ࡫ࡵࠫࢵ") in dir(HoxKENAey2MdTt9kDUrVnWGLS0CPa):
				for fWaTsFigqn in HoxKENAey2MdTt9kDUrVnWGLS0CPa.scandir(VpRSn1mwCOoz05EbH6I9AP):
					if fWaTsFigqn.is_dir(follow_symlinks=LhFAGlQ19zr):
						PiKpJjOHxeC90ydLIbntvoMD(fWaTsFigqn.path)
					elif fWaTsFigqn.is_file(follow_symlinks=LhFAGlQ19zr):
						hjR15y8PscK2ldv4AU9FakWeoBIOHS += fWaTsFigqn.stat().st_size
						GBn1UXEQHTCbp8NfP6c90Rxq4 += BkM54Kr7Qbqn
			else:
				for fWaTsFigqn in HoxKENAey2MdTt9kDUrVnWGLS0CPa.listdir(VpRSn1mwCOoz05EbH6I9AP):
					xGf4QetnVJukNBKF = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.abspath(HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(VpRSn1mwCOoz05EbH6I9AP,fWaTsFigqn))
					if HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.isdir(xGf4QetnVJukNBKF):
						PiKpJjOHxeC90ydLIbntvoMD(xGf4QetnVJukNBKF)
					elif HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.isfile(xGf4QetnVJukNBKF):
						M06JC7gNv2OmV3ebp8D1IF9ha,C37Q0bmsoJ8F4cvEXTikg = ucm10ohnRLA8d5ybFKEYkNQa3e6Gr(xGf4QetnVJukNBKF)
						hjR15y8PscK2ldv4AU9FakWeoBIOHS += M06JC7gNv2OmV3ebp8D1IF9ha
						GBn1UXEQHTCbp8NfP6c90Rxq4 += C37Q0bmsoJ8F4cvEXTikg
		return
	try: PiKpJjOHxeC90ydLIbntvoMD(VpRSn1mwCOoz05EbH6I9AP)
	except: pass
	return hjR15y8PscK2ldv4AU9FakWeoBIOHS,GBn1UXEQHTCbp8NfP6c90Rxq4
def HVO5subWZdwno48YSULcRpakt2JClz(showDialogs):
	if showDialogs:
		Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,uulNDCPyef78(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࢶ"),n0nFOd4yR97fQzNLSW+N6NGJ4vpmidqMCh7yo(u"ࠬํไࠡฬิ๎ิࠦๅิฯࠪࢷ")+C0qrknitpM4Z+Gcw2nelTR864XCVruO3mAFqI5a(u"࠭ๅอๆาࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮࠦ࠮࠯๋้ࠢั๊ฯࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠤ࠳࠴้ࠠ็ฯ่ิࠦวๅื๋ีࠥอไใัํ้ฮࠦ࠮࠯๋ࠢฮๆื๊฻่่ࠢๆࠦี้ำࠣห้หึศใสฮࠥ࠴࠮๊่่ࠡๆอสࠡษ็็ึอิࠨࢸ")+C0qrknitpM4Z+N6NGJ4vpmidqMCh7yo(u"ࠧภࠣࠤࠫࢹ")+T7ASIp1ZYwio9HQ8cObJK)
		if Scj7zgGFVA83otMpwUkxhm0BLN1!=BkM54Kr7Qbqn: return
	AoyPzbisawk8dfDRqFEg = rSOlpJAWb8Vh(WZfqnGSYlRQAV8MihD7BPs,EsCplGc5N4mBuYW0RVQt6b,LhFAGlQ19zr)
	HyKTpcu89bFSVRmhY7P = rSOlpJAWb8Vh(X6AmGZLUf8Dhdr3SRCe2YQJHF,EsCplGc5N4mBuYW0RVQt6b,LhFAGlQ19zr)
	bEf9C7V3wsvLFrzuDja4mYQgM = rSOlpJAWb8Vh(u5fU1irdYwz27Gle43mXOHPQg,LhFAGlQ19zr,LhFAGlQ19zr)
	Ojb7N5GULdZthivu8DKgIr3 = vQ3USRaDebkZ8drlLmJGc(pvsZguhiwFLV,LhFAGlQ19zr)
	U24uM7joCDdv = ZZjmLN1WbCkO7lMEo9chn2F5gP(LhFAGlQ19zr)
	succeeded = all([AoyPzbisawk8dfDRqFEg,HyKTpcu89bFSVRmhY7P,bEf9C7V3wsvLFrzuDja4mYQgM,Ojb7N5GULdZthivu8DKgIr3,U24uM7joCDdv])
	if showDialogs:
		if succeeded: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࢺ"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪࢻ"))
		else: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ggjO5CrKVRPITaesWkxD(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࢼ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"้๊ࠫริใࠣๅู๊สࠡ฻่่๏ฯࠠศๆ่ืา࠭ࢽ"))
	return succeeded
def HzyX2J3lD0NYqf5hTcinV68d1B(showDialogs):
	if showDialogs:
		RdSIb8uUQ5MX2F = qLJm5ufXBh+C0qrknitpM4Z+g1mDX9e3oif5uMCzb+C0qrknitpM4Z+qaD0xbYsT6gOujoXz538r1wkAM+C0qrknitpM4Z+x9SYGtivQH1+C0qrknitpM4Z+ILzm10Nxrb+C0qrknitpM4Z+ZZD7MSWkOheNIXuqHcVt1fPJL9y6v
		Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,N6NGJ4vpmidqMCh7yo(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࢾ"),n0nFOd4yR97fQzNLSW+AAbvaXV2DQzfNHdm4U3tT(u"࠭็ๅࠢอี๏ีࠠๆีะࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮࠦวๅฬํࠤๆ๐่ࠠา๊ࠤฬ๊ๅอๆาหฯࡢ࡮࡝ࡰࠪࢿ")+RdSIb8uUQ5MX2F+T7ASIp1ZYwio9HQ8cObJK)
		if Scj7zgGFVA83otMpwUkxhm0BLN1!=BkM54Kr7Qbqn: return
	AoyPzbisawk8dfDRqFEg = rSOlpJAWb8Vh(qLJm5ufXBh,LhFAGlQ19zr,LhFAGlQ19zr)
	HyKTpcu89bFSVRmhY7P = rSOlpJAWb8Vh(g1mDX9e3oif5uMCzb,LhFAGlQ19zr,LhFAGlQ19zr)
	bEf9C7V3wsvLFrzuDja4mYQgM = rSOlpJAWb8Vh(qaD0xbYsT6gOujoXz538r1wkAM,LhFAGlQ19zr,LhFAGlQ19zr)
	Ojb7N5GULdZthivu8DKgIr3 = rSOlpJAWb8Vh(x9SYGtivQH1,LhFAGlQ19zr,LhFAGlQ19zr)
	U24uM7joCDdv = rSOlpJAWb8Vh(ILzm10Nxrb,LhFAGlQ19zr,LhFAGlQ19zr)
	OIusvK7Ccg5 = rSOlpJAWb8Vh(ZZD7MSWkOheNIXuqHcVt1fPJL9y6v,LhFAGlQ19zr,LhFAGlQ19zr)
	succeeded = all([AoyPzbisawk8dfDRqFEg,HyKTpcu89bFSVRmhY7P,bEf9C7V3wsvLFrzuDja4mYQgM,Ojb7N5GULdZthivu8DKgIr3,U24uM7joCDdv,OIusvK7Ccg5])
	if showDialogs:
		if succeeded: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ssynAg0zhSkoCpOMDV9(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࣀ"),N6NGJ4vpmidqMCh7yo(u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩࣁ"))
		else: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ssynAg0zhSkoCpOMDV9(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࣂ"),FgXzMs0YSDt(u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦวๅ็ึัࠬࣃ"))
	return succeeded
def vQ3USRaDebkZ8drlLmJGc(ccwPvtXMB3jGNCeydFIZaHziLKER,showDialogs):
	if showDialogs:
		Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EE1jeHnIoad(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࣄ"),n0nFOd4yR97fQzNLSW+FmYoGejTnwKME7d9zPc(u"ࠬํไࠡฬิ๎ิࠦๅิฯ้ࠣาะ่๋ษอࠤ๊๊แࠡื๋ีࠥอไอๆาࠤฤࠧࠡࠨࣅ")+T7ASIp1ZYwio9HQ8cObJK)
		if Scj7zgGFVA83otMpwUkxhm0BLN1!=uulNDCPyef78(u"࠷ओ"): return aOQTKXFL54Nl60Zhp3MbE(u"ࡆࡢ࡮ࡶࡩऔ")
	try:
		succeeded = C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࡕࡴࡸࡩक")
		vvPmnHekOc7qrjidMwxf134VD = GUpSgLmFJc2T5B6DRxtlN9KXHIYP.connect(ccwPvtXMB3jGNCeydFIZaHziLKER)
		vvPmnHekOc7qrjidMwxf134VD.text_factory = str
		aaLcdPtZmTG4ir = vvPmnHekOc7qrjidMwxf134VD.cursor()
		aaLcdPtZmTG4ir.execute(CsDcLqQUVK4YBvHFW1(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡵࡧࡴࡩ࠽ࠪࣆ"))
		aaLcdPtZmTG4ir.execute(FgXzMs0YSDt(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡹࡩࡻࡧࡶ࠿ࠬࣇ"))
		aaLcdPtZmTG4ir.execute(KfHAW8VGbrxi(u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࡴࡦࡺࡷࡹࡷ࡫࠻ࠨࣈ"))
		vvPmnHekOc7qrjidMwxf134VD.commit()
		aaLcdPtZmTG4ir.execute(O3OVuapf0YFjbm5oUQDg(u"࡙ࠩࡅࡈ࡛ࡕࡎ࠽ࠪࣉ"))
		vvPmnHekOc7qrjidMwxf134VD.close()
	except: succeeded = FgXzMs0YSDt(u"ࡈࡤࡰࡸ࡫ख")
	if showDialogs:
		if succeeded: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ssynAg0zhSkoCpOMDV9(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭࣊"),uulNDCPyef78(u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬ࣋"))
		else: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࣌"),vU6DxuzPwMpg(u"࠭ไๅลึๅࠥ็ิๅฬࠣ฽๊๊๊สࠢสู่๊อࠨ࣍"))
	return succeeded
def ZZjmLN1WbCkO7lMEo9chn2F5gP(showDialogs):
	if showDialogs:
		Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,aOQTKXFL54Nl60Zhp3MbE(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࣎"),FgXzMs0YSDt(u"ࠨ็็ๅฬะࠠศๆๆีฬฺ่ࠠ์้้ࠣ็วหࠢํู๋฿็ศࠢๆ์ิ๐ฺ่ࠠา้ฬ๊ࠦ฻ๆๅࠤ๋็ำ่ࠢหูํืษࠡ็ไหัษษࠡ࠰࠱ࠤ์ึ็ࠡษ็้้็วหࠢํัฯอฬ่ษ้ࠣอืๅอ์ࠣ็ํี๊ࠡฯอํࠥ๐ูาใ๋๊๋ࠥๆ่ษࠣ็๏็ࠠฮัฮฮࠥอไๆึๆ่ฮ࣏࠭")+C0qrknitpM4Z+C0qrknitpM4Z+n0nFOd4yR97fQzNLSW+PlpyFa9QMKXxOD1cvHzmI(u"๊่ࠩࠥะั๋ัุ้ࠣำࠠๆๆไหฯࠦวๅๅิหูࠦวๅ็วๆฯฯࠠภࠣࠤ࣐ࠫ")+T7ASIp1ZYwio9HQ8cObJK)
		if Scj7zgGFVA83otMpwUkxhm0BLN1!=BkM54Kr7Qbqn: return aOQTKXFL54Nl60Zhp3MbE(u"ࡉࡥࡱࡹࡥग")
	succeeded = AAbvaXV2DQzfNHdm4U3tT(u"ࡘࡷࡻࡥघ")
	for file in HoxKENAey2MdTt9kDUrVnWGLS0CPa.listdir(ihFXL4gb36G1U5rWSCKEMp29):
		if FmYoGejTnwKME7d9zPc(u"ࠪ࡯ࡴࡪࡩࡠࡵࡷࡥࡨࡱࡴࡳࡣࡦࡩ࣑ࠬ") not in file and wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠫࡰࡵࡤࡪࡡࡦࡶࡦࡹࡨ࡭ࡱࡪ࣒ࠫ") not in file: continue
		GGCkYa7X603fZbDR = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(ihFXL4gb36G1U5rWSCKEMp29,file)
		try: HoxKENAey2MdTt9kDUrVnWGLS0CPa.remove(GGCkYa7X603fZbDR)
		except Exception as NYtXLZDyeiqPSgGO:
			succeeded = AAbvaXV2DQzfNHdm4U3tT(u"ࡋࡧ࡬ࡴࡧङ")
			if showDialogs: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,jL5CrsRwebpyDVXUc1EQP(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࣓"),str(NYtXLZDyeiqPSgGO))
	if showDialogs:
		if succeeded: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,sIzDXlTHYUC5L3xZGnr(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࣔ"),FgXzMs0YSDt(u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨࣕ"))
		else: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,FgXzMs0YSDt(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࣖ"),KfHAW8VGbrxi(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥอไๆีะࠫࣗ"))
	return succeeded
# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'BOKRA'
K2l9rLfvoXxyZ4NYapO = '_BKR_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
headers = {'User-Agent':fy8iFgEkrO12NR9TWBI35sjY6qHvV}
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['افلام للكبار','بكرا TV']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==370: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==371: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,text)
	elif mode==372: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==374: OmsWt89dSA5HyCZ4wL = SyAnPgJZTORB5dNvY(url)
	elif mode==375: OmsWt89dSA5HyCZ4wL = W5GXTut6oEpMHARlir(url)
	elif mode==376: OmsWt89dSA5HyCZ4wL = YOLRqKSueoC2j6(0,url)
	elif mode==377: OmsWt89dSA5HyCZ4wL = YOLRqKSueoC2j6(1,url)
	elif mode==379: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'BOKRA-MENU-1st')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,379,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('right-side(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
			if not any(value in title for value in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o):
				OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,371)
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'المميزة',BOI3t1w8qfHAb0Kl4oMye7haEWS,375)
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'الأحدث',BOI3t1w8qfHAb0Kl4oMye7haEWS,376)
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'قائمة الممثلين',BOI3t1w8qfHAb0Kl4oMye7haEWS,374)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="container"(.*?)top-menu',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items[7:]:
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
			if not any(value in title for value in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o):
				OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,371)
		for bigdh7fpZYl4aT2keV,title in items[0:7]:
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
			if not any(value in title for value in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o):
				OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,371)
	return
def SyAnPgJZTORB5dNvY(website=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'BOKRA-ACTORSMENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="row cat Tags"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)" title="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if 'http' in bigdh7fpZYl4aT2keV: continue
			else: bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
			if not any(value in title for value in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o):
				OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,371)
	return
def W5GXTut6oEpMHARlir(website=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'BOKRA-FEATURED-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"MainContent"(.*?)main-title2',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
			if not any(value in title for value in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o):
				POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R.replace('://',':///').replace('//','/').replace(ksJdoFWhxTz8Y2N7bOZE,'%20')
				OZD1l4pAMzeH('video',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,372,POjaBmHqzpsx1IYw7kQM4R)
	return
def YOLRqKSueoC2j6(id,website=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'BOKRA-WATCHINGNOW-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('main-title2(.*?)class="row',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[id]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
			if not any(value in title for value in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o):
				POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R.replace('://',':///').replace('//','/').replace(ksJdoFWhxTz8Y2N7bOZE,'%20')
				OZD1l4pAMzeH('video',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,372,POjaBmHqzpsx1IYw7kQM4R)
	return
def HAsKeZdTbqjPI1WY(url,zSydkVHNCriWaqT8ltOmbnuoKDI=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'BOKRA-TITLES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	if 'vidpage_' in url:
		bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall('href="(/Album-.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if bigdh7fpZYl4aT2keV:
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV[0]
			HAsKeZdTbqjPI1WY(bigdh7fpZYl4aT2keV)
			return
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class=" subcats"(.*?)class="col-md-3',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if zSydkVHNCriWaqT8ltOmbnuoKDI==fy8iFgEkrO12NR9TWBI35sjY6qHvV and z6PX2p7diaskQElBOvMRNcHwqG5D and z6PX2p7diaskQElBOvMRNcHwqG5D[0].count('href')>1:
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع',url,371,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'titles')
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)" title="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/'+bigdh7fpZYl4aT2keV
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,371)
	else:
		cmDaLEqWlT7GhonIdX5k1zHQjSiupe = []
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="col-md-3(.*?)col-xs-12',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if not z6PX2p7diaskQElBOvMRNcHwqG5D: z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="col-sm-8"(.*?)col-xs-12',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
				bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
				title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
				POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R.replace('://',':///').replace('//','/').replace(ksJdoFWhxTz8Y2N7bOZE,'%20')
				if '/al_' in bigdh7fpZYl4aT2keV:
					OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,371,POjaBmHqzpsx1IYw7kQM4R)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) - +الحلقة +\d+',title,EcQxOa3RJm86WjTKA.DOTALL)
					if RrzpbE3t9woCk7MXS0GvNdi1BcV: title = '_MOD_مسلسل '+RrzpbE3t9woCk7MXS0GvNdi1BcV[0]
					if title not in cmDaLEqWlT7GhonIdX5k1zHQjSiupe:
						cmDaLEqWlT7GhonIdX5k1zHQjSiupe.append(title)
						OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,371,POjaBmHqzpsx1IYw7kQM4R)
				else: OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,372,POjaBmHqzpsx1IYw7kQM4R)
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="pagination(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('class="".*?href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title in items:
				bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
				title = 'صفحة '+IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,371,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'titles')
	return
def rr7SfotkneX85Klup(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'BOKRA-PLAY-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	uuigJsvIZQ3tprnhxG = EcQxOa3RJm86WjTKA.findall('label-success mrg-btm-5 ">(.*?)<',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if uuigJsvIZQ3tprnhxG and SYJvigbI3fts(BfWYUAnyg6eONLjiuE,url,uuigJsvIZQ3tprnhxG): return
	MYWwFs7XA2 = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	YLKFRH6sSIrznXBg = EcQxOa3RJm86WjTKA.findall('var url = "(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if YLKFRH6sSIrznXBg: YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg[0]
	else: YLKFRH6sSIrznXBg = url.replace('/vidpage_','/Play/')
	if 'http' not in YLKFRH6sSIrznXBg: YLKFRH6sSIrznXBg = BOI3t1w8qfHAb0Kl4oMye7haEWS+YLKFRH6sSIrznXBg
	YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg.strip('-')
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(D1KfvmcCjGYbgSoyX,'GET',YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'BOKRA-PLAY-2nd')
	soEymUvkt19PQXVjzKau6x5 = E6ECvznP9m5sWFMu.content
	MYWwFs7XA2 = EcQxOa3RJm86WjTKA.findall('src="(.*?)"',soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
	if MYWwFs7XA2:
		MYWwFs7XA2 = MYWwFs7XA2[-1]
		if 'http' not in MYWwFs7XA2: MYWwFs7XA2 = 'http:'+MYWwFs7XA2
		if '/PLAY/' not in YLKFRH6sSIrznXBg:
			if 'embed.min.js' in MYWwFs7XA2:
				SEstoayqg0jH1w4QDbVv6FpX9KP3 = EcQxOa3RJm86WjTKA.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
				if SEstoayqg0jH1w4QDbVv6FpX9KP3:
					QqbPySehF5T7fZ, lTntAYp0U2BZyi8eXSwmP5sfquG = SEstoayqg0jH1w4QDbVv6FpX9KP3[0]
					MYWwFs7XA2 = VbHeOuU1ilzSp2ZRXwBD(MYWwFs7XA2,'url')+'/v2/'+QqbPySehF5T7fZ+'/config/'+lTntAYp0U2BZyi8eXSwmP5sfquG+'.json'
		import TT24gHhkWI
		TT24gHhkWI.F7ulLTJzOt6krWZa4([MYWwFs7XA2],BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/Search/'+search
	HAsKeZdTbqjPI1WY(url)
	return
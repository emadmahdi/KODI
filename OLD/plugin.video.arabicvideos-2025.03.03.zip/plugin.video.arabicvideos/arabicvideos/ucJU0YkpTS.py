# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
x5TvLsPECHUoaqg1Dl3GwJj = 'M3U'
RTUaJZyvOuDA83So7M = '_M3U_'
ndDvK6Nf4p5E = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
U08BAYfcpVrC3tzaFyG7gOWilKohL = 4
def fIaUG2SkWZHyeqP6oluzAN(hO3D6GVPY2qENv8bZWH,eEncXMVB2rNg4JObl3utYfj,YMaiHbnIThsP7q,ppi24CwDdH3YzVIK8BUyLluQJEMW,yy7dsVqg23CI5tbjXlwWmOe,IYUEhjmyOzv40iCgxeN8JDPW):
	global RTUaJZyvOuDA83So7M
	try:
		ZXOQjgueim57H6p1NrCsTyzA = str(IYUEhjmyOzv40iCgxeN8JDPW['folder'])
		RTUaJZyvOuDA83So7M = '_MU'+ZXOQjgueim57H6p1NrCsTyzA+'_'
	except: ZXOQjgueim57H6p1NrCsTyzA = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	try: d5dAoMmGN2V = str(IYUEhjmyOzv40iCgxeN8JDPW['sequence'])
	except: d5dAoMmGN2V = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if   hO3D6GVPY2qENv8bZWH==710: J5eBhfvXYF20DAOqs7L8l3KaR1 = ElL5nc6etmJKFWv9P38QsUS7GBz()
	elif hO3D6GVPY2qENv8bZWH==711: J5eBhfvXYF20DAOqs7L8l3KaR1 = zX2tLATroY9qi0(ZXOQjgueim57H6p1NrCsTyzA,d5dAoMmGN2V)
	elif hO3D6GVPY2qENv8bZWH==712: J5eBhfvXYF20DAOqs7L8l3KaR1 = adFJgtClIUqVkwpODMWGovNH(ZXOQjgueim57H6p1NrCsTyzA)
	elif hO3D6GVPY2qENv8bZWH==713: J5eBhfvXYF20DAOqs7L8l3KaR1 = fXBo06ewvrJ38547Y(ZXOQjgueim57H6p1NrCsTyzA,eEncXMVB2rNg4JObl3utYfj,YMaiHbnIThsP7q,yy7dsVqg23CI5tbjXlwWmOe)
	elif hO3D6GVPY2qENv8bZWH==714: J5eBhfvXYF20DAOqs7L8l3KaR1 = zY53X6dEGkqnhmUDJ20rpbR8(ZXOQjgueim57H6p1NrCsTyzA,eEncXMVB2rNg4JObl3utYfj,YMaiHbnIThsP7q,yy7dsVqg23CI5tbjXlwWmOe)
	elif hO3D6GVPY2qENv8bZWH==715: J5eBhfvXYF20DAOqs7L8l3KaR1 = rr7SfotkneX85Klup(ZXOQjgueim57H6p1NrCsTyzA,eEncXMVB2rNg4JObl3utYfj,ppi24CwDdH3YzVIK8BUyLluQJEMW)
	elif hO3D6GVPY2qENv8bZWH==716: J5eBhfvXYF20DAOqs7L8l3KaR1 = SUE7qcdbaYW54wBzNv80n(ZXOQjgueim57H6p1NrCsTyzA,True)
	elif hO3D6GVPY2qENv8bZWH==717: J5eBhfvXYF20DAOqs7L8l3KaR1 = L8ISmMEnWx1tkNCK5ZRHQwJz(ZXOQjgueim57H6p1NrCsTyzA,True)
	elif hO3D6GVPY2qENv8bZWH==718: J5eBhfvXYF20DAOqs7L8l3KaR1 = LLiWMyoQ0TOGgA(ZXOQjgueim57H6p1NrCsTyzA,eEncXMVB2rNg4JObl3utYfj,YMaiHbnIThsP7q)
	elif hO3D6GVPY2qENv8bZWH==719: J5eBhfvXYF20DAOqs7L8l3KaR1 = G5xvzuBVrfdP7eIOAwhW8UQ6Eic4(YMaiHbnIThsP7q,ZXOQjgueim57H6p1NrCsTyzA,eEncXMVB2rNg4JObl3utYfj,yy7dsVqg23CI5tbjXlwWmOe)
	elif hO3D6GVPY2qENv8bZWH==720: J5eBhfvXYF20DAOqs7L8l3KaR1 = O1NaXREkVqLJtKy0H86vzSmiP(ZXOQjgueim57H6p1NrCsTyzA,True)
	elif hO3D6GVPY2qENv8bZWH==721: J5eBhfvXYF20DAOqs7L8l3KaR1 = ffUZ928IdwQRJcsm4Y1pnGztqve6iP(ZXOQjgueim57H6p1NrCsTyzA)
	elif hO3D6GVPY2qENv8bZWH==722: J5eBhfvXYF20DAOqs7L8l3KaR1 = ZZlWDjVLPiEFoTGgUqOw2Mn6(ZXOQjgueim57H6p1NrCsTyzA)
	elif hO3D6GVPY2qENv8bZWH==723: J5eBhfvXYF20DAOqs7L8l3KaR1 = NHIDGo9Estfi0wAduFZ(ZXOQjgueim57H6p1NrCsTyzA)
	elif hO3D6GVPY2qENv8bZWH==726: J5eBhfvXYF20DAOqs7L8l3KaR1 = yUAtKsbY3rw(ZXOQjgueim57H6p1NrCsTyzA)
	elif hO3D6GVPY2qENv8bZWH==729: J5eBhfvXYF20DAOqs7L8l3KaR1 = olswHav1FmNJYhujfzqrAb2(YMaiHbnIThsP7q,ZXOQjgueim57H6p1NrCsTyzA,eEncXMVB2rNg4JObl3utYfj,yy7dsVqg23CI5tbjXlwWmOe)
	else: J5eBhfvXYF20DAOqs7L8l3KaR1 = False
	return J5eBhfvXYF20DAOqs7L8l3KaR1
def ElL5nc6etmJKFWv9P38QsUS7GBz():
	for ZXOQjgueim57H6p1NrCsTyzA in range(1,gaUFPm1MLjDJ2lVecEuYI+1):
		RTUaJZyvOuDA83So7M = '_MU'+str(ZXOQjgueim57H6p1NrCsTyzA)+'_'
		OZD1l4pAMzeH('folder',RTUaJZyvOuDA83So7M+'قائمة مجلد '+rjileqgmIOfLEWHoMz[ZXOQjgueim57H6p1NrCsTyzA],fy8iFgEkrO12NR9TWBI35sjY6qHvV,720,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,{'folder':ZXOQjgueim57H6p1NrCsTyzA})
	return
def O1NaXREkVqLJtKy0H86vzSmiP(ZXOQjgueim57H6p1NrCsTyzA=fy8iFgEkrO12NR9TWBI35sjY6qHvV,dJr5jL4cX7kfIeA21zx=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if ZXOQjgueim57H6p1NrCsTyzA:
		LLF9dQaltvJ50c2YxyhZpDj = {'folder':ZXOQjgueim57H6p1NrCsTyzA}
		aVnK0hTHcBA5OgfYGsQwt1jJi7zUpL = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	else:
		LLF9dQaltvJ50c2YxyhZpDj = fy8iFgEkrO12NR9TWBI35sjY6qHvV
		aVnK0hTHcBA5OgfYGsQwt1jJi7zUpL = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	k1qNUA08va9Jc3iCXOB2oYQVIK = dt5U3cZpCFGRHDue7a1(ZXOQjgueim57H6p1NrCsTyzA,dJr5jL4cX7kfIeA21zx)
	if not k1qNUA08va9Jc3iCXOB2oYQVIK:
		OZD1l4pAMzeH('link',RTUaJZyvOuDA83So7M+WydpaVx5YmLoCiIgA34eEBlb+' إضافة وتغيير رابط'+aVnK0hTHcBA5OgfYGsQwt1jJi7zUpL+ksJdoFWhxTz8Y2N7bOZE+rjileqgmIOfLEWHoMz[1]+' '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,711,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,{'folder':ZXOQjgueim57H6p1NrCsTyzA,'sequence':1})
		OZD1l4pAMzeH('link',RTUaJZyvOuDA83So7M+WydpaVx5YmLoCiIgA34eEBlb+' جلب ملفات'+aVnK0hTHcBA5OgfYGsQwt1jJi7zUpL+' '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,712,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LLF9dQaltvJ50c2YxyhZpDj)
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	else:
		OZD1l4pAMzeH('folder',RTUaJZyvOuDA83So7M+'بحث في الملفات'+aVnK0hTHcBA5OgfYGsQwt1jJi7zUpL,fy8iFgEkrO12NR9TWBI35sjY6qHvV,729,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_',fy8iFgEkrO12NR9TWBI35sjY6qHvV,LLF9dQaltvJ50c2YxyhZpDj)
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
		OZD1l4pAMzeH('folder',RTUaJZyvOuDA83So7M+'قنوات مصنفة مرتبة'+aVnK0hTHcBA5OgfYGsQwt1jJi7zUpL,'LIVE_GROUPED_SORTED',713,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LLF9dQaltvJ50c2YxyhZpDj)
		OZD1l4pAMzeH('folder',RTUaJZyvOuDA83So7M+'قنوات مصنفة من القسم'+aVnK0hTHcBA5OgfYGsQwt1jJi7zUpL,'LIVE_FROM_GROUP_SORTED',713,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LLF9dQaltvJ50c2YxyhZpDj)
		OZD1l4pAMzeH('folder',RTUaJZyvOuDA83So7M+'قنوات مصنفة من الاسم'+aVnK0hTHcBA5OgfYGsQwt1jJi7zUpL,'LIVE_FROM_NAME_SORTED',713,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LLF9dQaltvJ50c2YxyhZpDj)
		OZD1l4pAMzeH('folder',RTUaJZyvOuDA83So7M+'قنوات مصنفة بلا ترتيب'+aVnK0hTHcBA5OgfYGsQwt1jJi7zUpL,'LIVE_GROUPED',713,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LLF9dQaltvJ50c2YxyhZpDj)
		OZD1l4pAMzeH('folder',RTUaJZyvOuDA83So7M+'قنوات بلا ترتيب'+aVnK0hTHcBA5OgfYGsQwt1jJi7zUpL,'LIVE_ORIGINAL_GROUPED',713,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LLF9dQaltvJ50c2YxyhZpDj)
		OZD1l4pAMzeH('folder',RTUaJZyvOuDA83So7M+'قنوات مجهولة مرتبة'+aVnK0hTHcBA5OgfYGsQwt1jJi7zUpL,'LIVE_UNKNOWN_GROUPED_SORTED',713,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LLF9dQaltvJ50c2YxyhZpDj)
		OZD1l4pAMzeH('folder',RTUaJZyvOuDA83So7M+'قنوات مجهولة بلا ترتيب'+aVnK0hTHcBA5OgfYGsQwt1jJi7zUpL,'LIVE_UNKNOWN_GROUPED',713,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LLF9dQaltvJ50c2YxyhZpDj)
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
		OZD1l4pAMzeH('folder',RTUaJZyvOuDA83So7M+'فيديوهات بلا ترتيب'+aVnK0hTHcBA5OgfYGsQwt1jJi7zUpL,'VOD_ORIGINAL_GROUPED',713,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LLF9dQaltvJ50c2YxyhZpDj)
		OZD1l4pAMzeH('folder',RTUaJZyvOuDA83So7M+'فيديوهات مصنفة القسم'+aVnK0hTHcBA5OgfYGsQwt1jJi7zUpL,'VOD_FROM_GROUP_SORTED',713,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LLF9dQaltvJ50c2YxyhZpDj)
		OZD1l4pAMzeH('folder',RTUaJZyvOuDA83So7M+'فيديوهات مصنفة من الاسم'+aVnK0hTHcBA5OgfYGsQwt1jJi7zUpL,'VOD_FROM_NAME_SORTED',713,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LLF9dQaltvJ50c2YxyhZpDj)
		OZD1l4pAMzeH('folder',RTUaJZyvOuDA83So7M+'فيديوهات مجهولة بلا ترتيب'+aVnK0hTHcBA5OgfYGsQwt1jJi7zUpL,'VOD_UNKNOWN_GROUPED',713,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LLF9dQaltvJ50c2YxyhZpDj)
		OZD1l4pAMzeH('folder',RTUaJZyvOuDA83So7M+'فيديوهات مجهولة مرتبة'+aVnK0hTHcBA5OgfYGsQwt1jJi7zUpL,'VOD_UNKNOWN_GROUPED_SORTED',713,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LLF9dQaltvJ50c2YxyhZpDj)
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	for gLoUCe7WqVp in range(1,U08BAYfcpVrC3tzaFyG7gOWilKohL+1):
		OZD1l4pAMzeH('link',RTUaJZyvOuDA83So7M+'إضافة وتغيير رابط'+aVnK0hTHcBA5OgfYGsQwt1jJi7zUpL+ksJdoFWhxTz8Y2N7bOZE+rjileqgmIOfLEWHoMz[gLoUCe7WqVp],fy8iFgEkrO12NR9TWBI35sjY6qHvV,711,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,{'folder':ZXOQjgueim57H6p1NrCsTyzA,'sequence':gLoUCe7WqVp})
	OZD1l4pAMzeH('link',RTUaJZyvOuDA83So7M+'جلب ملفات'+aVnK0hTHcBA5OgfYGsQwt1jJi7zUpL,fy8iFgEkrO12NR9TWBI35sjY6qHvV,712,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LLF9dQaltvJ50c2YxyhZpDj)
	OZD1l4pAMzeH('link',RTUaJZyvOuDA83So7M+'مسح ملفات'+aVnK0hTHcBA5OgfYGsQwt1jJi7zUpL,fy8iFgEkrO12NR9TWBI35sjY6qHvV,717,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LLF9dQaltvJ50c2YxyhZpDj)
	OZD1l4pAMzeH('link',RTUaJZyvOuDA83So7M+'عدد فيديوهات'+aVnK0hTHcBA5OgfYGsQwt1jJi7zUpL,fy8iFgEkrO12NR9TWBI35sjY6qHvV,721,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LLF9dQaltvJ50c2YxyhZpDj)
	OZD1l4pAMzeH('link',RTUaJZyvOuDA83So7M+'Referer تغيير'+aVnK0hTHcBA5OgfYGsQwt1jJi7zUpL,fy8iFgEkrO12NR9TWBI35sjY6qHvV,726,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LLF9dQaltvJ50c2YxyhZpDj)
	OZD1l4pAMzeH('link',RTUaJZyvOuDA83So7M+'User-Agent تغيير'+aVnK0hTHcBA5OgfYGsQwt1jJi7zUpL,fy8iFgEkrO12NR9TWBI35sjY6qHvV,723,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LLF9dQaltvJ50c2YxyhZpDj)
	return
def SUE7qcdbaYW54wBzNv80n(ZXOQjgueim57H6p1NrCsTyzA,dJr5jL4cX7kfIeA21zx=True):
	btDv4SVx0ucesMmEY8hLy,Czr6j7m1JxaWyvqwphFRc = False,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	uq7nABJIXg1hUEcP,IIruJ4ewaCPfLFpcB3oXQZG57 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	lkJgRb8NafDzW1C,uzW1Gnb9y3,Bfx6z0mpyv24nXsGIDRPick8OAq,jLH92iKQbNwduyFUA1ERaCI8B,eeTOKr2C0B = AdopjyR7eknJQVHKD8EvhalW2Luz(ZXOQjgueim57H6p1NrCsTyzA)
	if jLH92iKQbNwduyFUA1ERaCI8B==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return False,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	LUvCxj6fMlnyEcDAahbgpH = vTfnxOoiXZL6QztIpbDycBgumY8j0q(ZXOQjgueim57H6p1NrCsTyzA)
	if lkJgRb8NafDzW1C:
		I7jcKisuTt = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,'GET',lkJgRb8NafDzW1C,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LUvCxj6fMlnyEcDAahbgpH,False,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'M3U-CHECK_ACCOUNT-1st')
		bbrCVFXl1YBE8n7 = I7jcKisuTt.content
		if I7jcKisuTt.succeeded:
			kdt1Y3oO24HhsD,QBi4x83NhWfaLyZM,Mte4T1Fohfz8NKGIilm,XHZQOvWnhsUkzBGC5V,LHU6WET91GRZ3DjX2e = 0,0,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
			try:
				vZYejnw1gd2QaOAoGyBfb86JsRqI = LB7TcZnGYdfw5lWU1RH3Oztu9PyA('dict',bbrCVFXl1YBE8n7)
				Czr6j7m1JxaWyvqwphFRc = vZYejnw1gd2QaOAoGyBfb86JsRqI['user_info']['status']
				btDv4SVx0ucesMmEY8hLy = True
				Mte4T1Fohfz8NKGIilm = vZYejnw1gd2QaOAoGyBfb86JsRqI['server_info']['time_now']
			except: pass
			if Mte4T1Fohfz8NKGIilm:
				try:
					GHiT09cXFQyzJ7YV6MqW8xR3 = uUqrNPcXKBoQ0slv.strptime(Mte4T1Fohfz8NKGIilm,'%Y.%m.%d %H:%M:%S')
					kdt1Y3oO24HhsD = int(uUqrNPcXKBoQ0slv.mktime(GHiT09cXFQyzJ7YV6MqW8xR3))
					QBi4x83NhWfaLyZM = int(VySKdWnH3vNq6klQ-kdt1Y3oO24HhsD)
					QBi4x83NhWfaLyZM = int((QBi4x83NhWfaLyZM+900)/1800)*1800
				except: pass
				try:
					GHiT09cXFQyzJ7YV6MqW8xR3 = uUqrNPcXKBoQ0slv.localtime(int(vZYejnw1gd2QaOAoGyBfb86JsRqI['user_info']['created_at']))
					XHZQOvWnhsUkzBGC5V = uUqrNPcXKBoQ0slv.strftime('%Y.%m.%d %H:%M:%S',GHiT09cXFQyzJ7YV6MqW8xR3)
				except: pass
				try:
					GHiT09cXFQyzJ7YV6MqW8xR3 = uUqrNPcXKBoQ0slv.localtime(int(vZYejnw1gd2QaOAoGyBfb86JsRqI['user_info']['exp_date']))
					LHU6WET91GRZ3DjX2e = uUqrNPcXKBoQ0slv.strftime('%Y.%m.%d %H:%M:%S',GHiT09cXFQyzJ7YV6MqW8xR3)
				except: pass
			OdiZIyCfDUsW3JBGR2VAb.setSetting('av.m3u.timestamp_'+ZXOQjgueim57H6p1NrCsTyzA,str(VySKdWnH3vNq6klQ))
			OdiZIyCfDUsW3JBGR2VAb.setSetting('av.m3u.timediff_'+ZXOQjgueim57H6p1NrCsTyzA,str(QBi4x83NhWfaLyZM))
			try:
				ggnRQlwW23NVGTOHtB5hy = '"server_info":'+bbrCVFXl1YBE8n7.split('"server_info":')[1]
				ggnRQlwW23NVGTOHtB5hy = ggnRQlwW23NVGTOHtB5hy.replace(':',': ').replace(',',', ').replace('}}','}')
				IWYQNwdUAgik = EcQxOa3RJm86WjTKA.findall('"url": "(.*?)", "port": "(.*?)"',ggnRQlwW23NVGTOHtB5hy,EcQxOa3RJm86WjTKA.DOTALL)
				uq7nABJIXg1hUEcP,IIruJ4ewaCPfLFpcB3oXQZG57 = IWYQNwdUAgik[0]
			except: btDv4SVx0ucesMmEY8hLy = False
			if btDv4SVx0ucesMmEY8hLy and dJr5jL4cX7kfIeA21zx:
				max = vZYejnw1gd2QaOAoGyBfb86JsRqI['user_info']['max_connections']
				erHA7oVqBhsj = vZYejnw1gd2QaOAoGyBfb86JsRqI['user_info']['active_cons']
				ptofOQLx4rAGsU = vZYejnw1gd2QaOAoGyBfb86JsRqI['user_info']['is_trial']
				HHFWdZqyTBjrtGJX1YCahDN0csLR = lkJgRb8NafDzW1C.split('?',1)
				kf40tulvSA7z9RqNF5dXca3seMD = 'URL:  '+n0nFOd4yR97fQzNLSW+lkJgRb8NafDzW1C+T7ASIp1ZYwio9HQ8cObJK
				kf40tulvSA7z9RqNF5dXca3seMD += '\n\nStatus:  '+n0nFOd4yR97fQzNLSW+Czr6j7m1JxaWyvqwphFRc+T7ASIp1ZYwio9HQ8cObJK
				kf40tulvSA7z9RqNF5dXca3seMD += '\nTrial:    '+n0nFOd4yR97fQzNLSW+str(ptofOQLx4rAGsU=='1')+T7ASIp1ZYwio9HQ8cObJK
				kf40tulvSA7z9RqNF5dXca3seMD += '\nCreated  At:  '+n0nFOd4yR97fQzNLSW+XHZQOvWnhsUkzBGC5V+T7ASIp1ZYwio9HQ8cObJK
				kf40tulvSA7z9RqNF5dXca3seMD += '\nExpiry Date:  '+n0nFOd4yR97fQzNLSW+LHU6WET91GRZ3DjX2e+T7ASIp1ZYwio9HQ8cObJK
				kf40tulvSA7z9RqNF5dXca3seMD += '\nConnections   ( Active / Maximum ) :  '+n0nFOd4yR97fQzNLSW+erHA7oVqBhsj+' / '+max+T7ASIp1ZYwio9HQ8cObJK
				kf40tulvSA7z9RqNF5dXca3seMD += '\nAllowed Outputs:   '+n0nFOd4yR97fQzNLSW+" , ".join(vZYejnw1gd2QaOAoGyBfb86JsRqI['user_info']['allowed_output_formats'])+T7ASIp1ZYwio9HQ8cObJK
				kf40tulvSA7z9RqNF5dXca3seMD += '\n\n'+ggnRQlwW23NVGTOHtB5hy
				if Czr6j7m1JxaWyvqwphFRc=='Active': BBUOlfYgcEFQCetXh8A04objZKG('الاشتراك يعمل بدون مشاكل',kf40tulvSA7z9RqNF5dXca3seMD)
				else: BBUOlfYgcEFQCetXh8A04objZKG('يبدو أن هناك مشكلة في الاشتراك',kf40tulvSA7z9RqNF5dXca3seMD)
	if lkJgRb8NafDzW1C and btDv4SVx0ucesMmEY8hLy and Czr6j7m1JxaWyvqwphFRc=='Active':
		Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,'.\tChecking M3U URL   [ M3U account is OK ]   [ '+lkJgRb8NafDzW1C+' ]')
		PDe9Y0d4kKrAX5HSChOumGZFVqU8 = True
	else:
		Clc8sIj97ZrThF(P3PazFblmtN,'Checking M3U URL   [ Does not work ]   [ '+lkJgRb8NafDzW1C+' ]')
		if dJr5jL4cX7kfIeA21zx: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'فحص اشتراك ـM3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		PDe9Y0d4kKrAX5HSChOumGZFVqU8 = False
	return PDe9Y0d4kKrAX5HSChOumGZFVqU8,uq7nABJIXg1hUEcP,IIruJ4ewaCPfLFpcB3oXQZG57
def zY53X6dEGkqnhmUDJ20rpbR8(ZXOQjgueim57H6p1NrCsTyzA,aXZ2lkohJwr,CCzG35xcSisAjmYNhFqJ8LPaQ091U,mEgQCiJ1uw0R3NchtZ,dJr5jL4cX7kfIeA21zx=True):
	if not mEgQCiJ1uw0R3NchtZ: mEgQCiJ1uw0R3NchtZ = '1'
	if not dt5U3cZpCFGRHDue7a1(ZXOQjgueim57H6p1NrCsTyzA,dJr5jL4cX7kfIeA21zx): return
	xQuWTvpwISyoGRr73A8Yz = q65BmenP4if3yG2D(ZXOQjgueim57H6p1NrCsTyzA,aXZ2lkohJwr)
	R4zwxKcC6785U2FtXMySgElqf = rIhXWK91vRuC(xQuWTvpwISyoGRr73A8Yz,'list',aXZ2lkohJwr,CCzG35xcSisAjmYNhFqJ8LPaQ091U)
	SPZYnlFURbovKjtBNe = int(mEgQCiJ1uw0R3NchtZ)*100
	FlBmLp1DQjxu0yRz3ePkAVU9iZTcra = SPZYnlFURbovKjtBNe-100
	for R5gQk0ZcerYx3B,ljGZCOmnVrtqy8WNHbgx4LEzpYfX,eEncXMVB2rNg4JObl3utYfj,BZylVOjQcDenA4qIC9whT in R4zwxKcC6785U2FtXMySgElqf[FlBmLp1DQjxu0yRz3ePkAVU9iZTcra:SPZYnlFURbovKjtBNe]:
		PPbYGzF24mZO3i5 = ('GROUPED' in aXZ2lkohJwr or aXZ2lkohJwr=='ALL')
		QQXADTwEskeoVcM6pYOr8dvZL1Ixy = ('GROUPED' not in aXZ2lkohJwr and aXZ2lkohJwr!='ALL')
		if PPbYGzF24mZO3i5 or QQXADTwEskeoVcM6pYOr8dvZL1Ixy:
			if   'ARCHIVED'  in aXZ2lkohJwr: I4t9qonjrm.menuItemsLIST.append(['folder',RTUaJZyvOuDA83So7M+ljGZCOmnVrtqy8WNHbgx4LEzpYfX,eEncXMVB2rNg4JObl3utYfj,718,BZylVOjQcDenA4qIC9whT,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ARCHIVED',fy8iFgEkrO12NR9TWBI35sjY6qHvV,{'folder':ZXOQjgueim57H6p1NrCsTyzA}])
			elif 'EPG' 		 in aXZ2lkohJwr: I4t9qonjrm.menuItemsLIST.append(['folder',RTUaJZyvOuDA83So7M+ljGZCOmnVrtqy8WNHbgx4LEzpYfX,eEncXMVB2rNg4JObl3utYfj,718,BZylVOjQcDenA4qIC9whT,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FULL_EPG',fy8iFgEkrO12NR9TWBI35sjY6qHvV,{'folder':ZXOQjgueim57H6p1NrCsTyzA}])
			elif 'TIMESHIFT' in aXZ2lkohJwr: I4t9qonjrm.menuItemsLIST.append(['folder',RTUaJZyvOuDA83So7M+ljGZCOmnVrtqy8WNHbgx4LEzpYfX,eEncXMVB2rNg4JObl3utYfj,718,BZylVOjQcDenA4qIC9whT,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'TIMESHIFT',fy8iFgEkrO12NR9TWBI35sjY6qHvV,{'folder':ZXOQjgueim57H6p1NrCsTyzA}])
			elif 'LIVE' 	 in aXZ2lkohJwr: I4t9qonjrm.menuItemsLIST.append(['live',RTUaJZyvOuDA83So7M+ljGZCOmnVrtqy8WNHbgx4LEzpYfX,eEncXMVB2rNg4JObl3utYfj,715,BZylVOjQcDenA4qIC9whT,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,R5gQk0ZcerYx3B,{'folder':ZXOQjgueim57H6p1NrCsTyzA}])
			else: I4t9qonjrm.menuItemsLIST.append(['video',RTUaJZyvOuDA83So7M+ljGZCOmnVrtqy8WNHbgx4LEzpYfX,eEncXMVB2rNg4JObl3utYfj,715,BZylVOjQcDenA4qIC9whT,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,{'folder':ZXOQjgueim57H6p1NrCsTyzA}])
	qqvDlN7sSFVGmdOYXjwrWZRyg = len(R4zwxKcC6785U2FtXMySgElqf)
	s2OC3m9qin8aegVSEPvZlH4Tro(ZXOQjgueim57H6p1NrCsTyzA,mEgQCiJ1uw0R3NchtZ,aXZ2lkohJwr,714,qqvDlN7sSFVGmdOYXjwrWZRyg,CCzG35xcSisAjmYNhFqJ8LPaQ091U)
	return
def mbdp7ya4Hh8wGjgQ(YhyMz1C6ZnG90B8Tk5):
	OZD1l4pAMzeH('link',YhyMz1C6ZnG90B8Tk5+'هذه القائمة إما فارغة أو غير موجودة',fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('link',YhyMz1C6ZnG90B8Tk5+'أو الخدمة غير موجودة في اشتراكك',fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('link',YhyMz1C6ZnG90B8Tk5+'أو رابط M3U الذي أنت أضفته غير صحيح',fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	return
def fXBo06ewvrJ38547Y(ZXOQjgueim57H6p1NrCsTyzA,aXZ2lkohJwr,CCzG35xcSisAjmYNhFqJ8LPaQ091U,mEgQCiJ1uw0R3NchtZ,Ji7MjybPkFfN5QSeBptx=fy8iFgEkrO12NR9TWBI35sjY6qHvV,dJr5jL4cX7kfIeA21zx=True):
	if not mEgQCiJ1uw0R3NchtZ: mEgQCiJ1uw0R3NchtZ = '1'
	YhyMz1C6ZnG90B8Tk5 = RTUaJZyvOuDA83So7M
	if not dt5U3cZpCFGRHDue7a1(ZXOQjgueim57H6p1NrCsTyzA,dJr5jL4cX7kfIeA21zx): return False
	if '__SERIES__' in CCzG35xcSisAjmYNhFqJ8LPaQ091U: poi4jIfTN5Wkag9mAuGn8Fx,ewbmMTWzLU9i28ZOR = CCzG35xcSisAjmYNhFqJ8LPaQ091U.split('__SERIES__')
	else: poi4jIfTN5Wkag9mAuGn8Fx,ewbmMTWzLU9i28ZOR = CCzG35xcSisAjmYNhFqJ8LPaQ091U,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	xQuWTvpwISyoGRr73A8Yz = q65BmenP4if3yG2D(ZXOQjgueim57H6p1NrCsTyzA,aXZ2lkohJwr)
	ZEIwR7UYvbDrkL4n = rIhXWK91vRuC(xQuWTvpwISyoGRr73A8Yz,'list',aXZ2lkohJwr,'__GROUPS__')
	if not ZEIwR7UYvbDrkL4n: return False
	rTIfBY3UWRsOPmFXv = []
	for GMdo5bjPOp1J86VQ4,BZylVOjQcDenA4qIC9whT in ZEIwR7UYvbDrkL4n:
		if '===== ===== =====' in GMdo5bjPOp1J86VQ4:
			OZD1l4pAMzeH('link',YhyMz1C6ZnG90B8Tk5+GMdo5bjPOp1J86VQ4,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
			OZD1l4pAMzeH('link',YhyMz1C6ZnG90B8Tk5+GMdo5bjPOp1J86VQ4,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
			continue
		if Ji7MjybPkFfN5QSeBptx:
			if '__SERIES__' in GMdo5bjPOp1J86VQ4: YhyMz1C6ZnG90B8Tk5 = 'SERIES'
			elif '!!__UNKNOWN__!!' in GMdo5bjPOp1J86VQ4: YhyMz1C6ZnG90B8Tk5 = 'UNKNOWN'
			elif 'LIVE' in aXZ2lkohJwr: YhyMz1C6ZnG90B8Tk5 = 'LIVE'
			else: YhyMz1C6ZnG90B8Tk5 = 'VIDEOS'
			YhyMz1C6ZnG90B8Tk5 = ','+n0nFOd4yR97fQzNLSW+YhyMz1C6ZnG90B8Tk5+': '+T7ASIp1ZYwio9HQ8cObJK
		if '__SERIES__' in GMdo5bjPOp1J86VQ4: tFhD42YAK7l9IbSvzr3dqLpTsy,JHNy2MZsRhUpYP8BV6F9nkc = GMdo5bjPOp1J86VQ4.split('__SERIES__')
		else: tFhD42YAK7l9IbSvzr3dqLpTsy,JHNy2MZsRhUpYP8BV6F9nkc = GMdo5bjPOp1J86VQ4,fy8iFgEkrO12NR9TWBI35sjY6qHvV
		if not CCzG35xcSisAjmYNhFqJ8LPaQ091U:
			if tFhD42YAK7l9IbSvzr3dqLpTsy in rTIfBY3UWRsOPmFXv: continue
			rTIfBY3UWRsOPmFXv.append(tFhD42YAK7l9IbSvzr3dqLpTsy)
			if 'RANDOM' in Ji7MjybPkFfN5QSeBptx: OZD1l4pAMzeH('folder',YhyMz1C6ZnG90B8Tk5+tFhD42YAK7l9IbSvzr3dqLpTsy,aXZ2lkohJwr,168,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1',GMdo5bjPOp1J86VQ4,fy8iFgEkrO12NR9TWBI35sjY6qHvV,{'folder':ZXOQjgueim57H6p1NrCsTyzA})
			elif '__SERIES__' in GMdo5bjPOp1J86VQ4: OZD1l4pAMzeH('folder',YhyMz1C6ZnG90B8Tk5+tFhD42YAK7l9IbSvzr3dqLpTsy,aXZ2lkohJwr,713,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1',GMdo5bjPOp1J86VQ4,fy8iFgEkrO12NR9TWBI35sjY6qHvV,{'folder':ZXOQjgueim57H6p1NrCsTyzA})
			else: OZD1l4pAMzeH('folder',YhyMz1C6ZnG90B8Tk5+tFhD42YAK7l9IbSvzr3dqLpTsy,aXZ2lkohJwr,714,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1',GMdo5bjPOp1J86VQ4,fy8iFgEkrO12NR9TWBI35sjY6qHvV,{'folder':ZXOQjgueim57H6p1NrCsTyzA})
		elif '__SERIES__' in GMdo5bjPOp1J86VQ4 and tFhD42YAK7l9IbSvzr3dqLpTsy==poi4jIfTN5Wkag9mAuGn8Fx:
			if JHNy2MZsRhUpYP8BV6F9nkc in rTIfBY3UWRsOPmFXv: continue
			rTIfBY3UWRsOPmFXv.append(JHNy2MZsRhUpYP8BV6F9nkc)
			if 'RANDOM' in Ji7MjybPkFfN5QSeBptx: OZD1l4pAMzeH('folder',YhyMz1C6ZnG90B8Tk5+JHNy2MZsRhUpYP8BV6F9nkc,aXZ2lkohJwr,168,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1',GMdo5bjPOp1J86VQ4,fy8iFgEkrO12NR9TWBI35sjY6qHvV,{'folder':ZXOQjgueim57H6p1NrCsTyzA})
			else: OZD1l4pAMzeH('folder',YhyMz1C6ZnG90B8Tk5+JHNy2MZsRhUpYP8BV6F9nkc,aXZ2lkohJwr,714,BZylVOjQcDenA4qIC9whT,'1',GMdo5bjPOp1J86VQ4,fy8iFgEkrO12NR9TWBI35sjY6qHvV,{'folder':ZXOQjgueim57H6p1NrCsTyzA})
	I4t9qonjrm.menuItemsLIST[:] = sorted(I4t9qonjrm.menuItemsLIST,reverse=False,key=lambda ZYo1OtjRwCc2eAlK: ZYo1OtjRwCc2eAlK[1].lower())
	if not Ji7MjybPkFfN5QSeBptx:
		SPZYnlFURbovKjtBNe = int(mEgQCiJ1uw0R3NchtZ)*100
		FlBmLp1DQjxu0yRz3ePkAVU9iZTcra = SPZYnlFURbovKjtBNe-100
		qqvDlN7sSFVGmdOYXjwrWZRyg = len(I4t9qonjrm.menuItemsLIST)
		I4t9qonjrm.menuItemsLIST[:] = I4t9qonjrm.menuItemsLIST[FlBmLp1DQjxu0yRz3ePkAVU9iZTcra:SPZYnlFURbovKjtBNe]
		s2OC3m9qin8aegVSEPvZlH4Tro(ZXOQjgueim57H6p1NrCsTyzA,mEgQCiJ1uw0R3NchtZ,aXZ2lkohJwr,713,qqvDlN7sSFVGmdOYXjwrWZRyg,CCzG35xcSisAjmYNhFqJ8LPaQ091U)
	return True
def LLiWMyoQ0TOGgA(ZXOQjgueim57H6p1NrCsTyzA,eEncXMVB2rNg4JObl3utYfj,gNPa1EDOeyLr3KjlQ2R0n):
	if not dt5U3cZpCFGRHDue7a1(ZXOQjgueim57H6p1NrCsTyzA,True): return
	LUvCxj6fMlnyEcDAahbgpH = vTfnxOoiXZL6QztIpbDycBgumY8j0q(ZXOQjgueim57H6p1NrCsTyzA)
	kdt1Y3oO24HhsD = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.m3u.timestamp_'+ZXOQjgueim57H6p1NrCsTyzA)
	if not kdt1Y3oO24HhsD or VySKdWnH3vNq6klQ-int(kdt1Y3oO24HhsD)>24*tpCSLxQO2swRuedhYbVB1Evri5k:
		PDe9Y0d4kKrAX5HSChOumGZFVqU8,uq7nABJIXg1hUEcP,IIruJ4ewaCPfLFpcB3oXQZG57 = SUE7qcdbaYW54wBzNv80n(ZXOQjgueim57H6p1NrCsTyzA,False)
		if not PDe9Y0d4kKrAX5HSChOumGZFVqU8: return
	QBi4x83NhWfaLyZM = int(OdiZIyCfDUsW3JBGR2VAb.getSetting('av.m3u.timediff_'+ZXOQjgueim57H6p1NrCsTyzA))
	Bfx6z0mpyv24nXsGIDRPick8OAq = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.m3u.server_'+ZXOQjgueim57H6p1NrCsTyzA)
	jLH92iKQbNwduyFUA1ERaCI8B = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.m3u.username_'+ZXOQjgueim57H6p1NrCsTyzA)
	eeTOKr2C0B = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.m3u.password_'+ZXOQjgueim57H6p1NrCsTyzA)
	UJjla9XE2dL3viMT6zQZC = eEncXMVB2rNg4JObl3utYfj.split('/')
	lFnOiIjzQ65cySV4CYPsN9XbaRBgdH = UJjla9XE2dL3viMT6zQZC[-1].replace('.ts',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('.m3u8',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	if gNPa1EDOeyLr3KjlQ2R0n=='SHORT_EPG': vvSQHZszRdONb = 'get_short_epg'
	else: vvSQHZszRdONb = 'get_simple_data_table'
	lkJgRb8NafDzW1C,uzW1Gnb9y3,Bfx6z0mpyv24nXsGIDRPick8OAq,jLH92iKQbNwduyFUA1ERaCI8B,eeTOKr2C0B = AdopjyR7eknJQVHKD8EvhalW2Luz(ZXOQjgueim57H6p1NrCsTyzA)
	if not jLH92iKQbNwduyFUA1ERaCI8B: return
	mO2UFZTdJMn = lkJgRb8NafDzW1C+'&action='+vvSQHZszRdONb+'&stream_id='+lFnOiIjzQ65cySV4CYPsN9XbaRBgdH
	bbrCVFXl1YBE8n7 = dQBuKGlXc0eNj1T27I(oWMrx7zvedHY0UiS48XbOqVTJ,mO2UFZTdJMn,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LUvCxj6fMlnyEcDAahbgpH,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'M3U-EPG_ITEMS-2nd')
	C2dymR8oDSBQYie = LB7TcZnGYdfw5lWU1RH3Oztu9PyA('dict',bbrCVFXl1YBE8n7)
	pe3VuOcGgMifbHIdQB = C2dymR8oDSBQYie['epg_listings']
	wShpRxqK8CaToQ1m = []
	if gNPa1EDOeyLr3KjlQ2R0n in ['ARCHIVED','TIMESHIFT']:
		for vZYejnw1gd2QaOAoGyBfb86JsRqI in pe3VuOcGgMifbHIdQB:
			if vZYejnw1gd2QaOAoGyBfb86JsRqI['has_archive']==1:
				wShpRxqK8CaToQ1m.append(vZYejnw1gd2QaOAoGyBfb86JsRqI)
				if gNPa1EDOeyLr3KjlQ2R0n in ['TIMESHIFT']: break
		if not wShpRxqK8CaToQ1m: return
		OZD1l4pAMzeH('link',RTUaJZyvOuDA83So7M+n0nFOd4yR97fQzNLSW+'الملفات الأولي بهذه القائمة قد لا تعمل'+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
		if gNPa1EDOeyLr3KjlQ2R0n in ['TIMESHIFT']:
			fosUtXbH7vJjywgIZhqBTkNR = 2
			f9jNByzVsbot1M8d3YmU = fosUtXbH7vJjywgIZhqBTkNR*tpCSLxQO2swRuedhYbVB1Evri5k
			wShpRxqK8CaToQ1m = []
			RlWCeZMjbELKtHz1 = int(int(vZYejnw1gd2QaOAoGyBfb86JsRqI['start_timestamp'])/f9jNByzVsbot1M8d3YmU)*f9jNByzVsbot1M8d3YmU
			FeYutPV9OnHxaU = VySKdWnH3vNq6klQ+f9jNByzVsbot1M8d3YmU
			X93qtlBGd1HoWKgkmjnSwu = int((FeYutPV9OnHxaU-RlWCeZMjbELKtHz1)/tpCSLxQO2swRuedhYbVB1Evri5k)
			for C37Q0bmsoJ8F4cvEXTikg in range(X93qtlBGd1HoWKgkmjnSwu):
				if C37Q0bmsoJ8F4cvEXTikg>=6:
					if C37Q0bmsoJ8F4cvEXTikg%fosUtXbH7vJjywgIZhqBTkNR!=0: continue
					WmDIuqRL3riSEo8U6Z2fwVvBeyjPQA = f9jNByzVsbot1M8d3YmU
				else: WmDIuqRL3riSEo8U6Z2fwVvBeyjPQA = f9jNByzVsbot1M8d3YmU//2
				nSRKXg1FMNhj0pt = RlWCeZMjbELKtHz1+C37Q0bmsoJ8F4cvEXTikg*tpCSLxQO2swRuedhYbVB1Evri5k
				vZYejnw1gd2QaOAoGyBfb86JsRqI = {}
				vZYejnw1gd2QaOAoGyBfb86JsRqI['title'] = fy8iFgEkrO12NR9TWBI35sjY6qHvV
				GHiT09cXFQyzJ7YV6MqW8xR3 = uUqrNPcXKBoQ0slv.localtime(nSRKXg1FMNhj0pt-QBi4x83NhWfaLyZM-tpCSLxQO2swRuedhYbVB1Evri5k)
				vZYejnw1gd2QaOAoGyBfb86JsRqI['start'] = uUqrNPcXKBoQ0slv.strftime('%Y.%m.%d %H:%M:%S',GHiT09cXFQyzJ7YV6MqW8xR3)
				vZYejnw1gd2QaOAoGyBfb86JsRqI['start_timestamp'] = str(nSRKXg1FMNhj0pt)
				vZYejnw1gd2QaOAoGyBfb86JsRqI['stop_timestamp'] = str(nSRKXg1FMNhj0pt+WmDIuqRL3riSEo8U6Z2fwVvBeyjPQA)
				wShpRxqK8CaToQ1m.append(vZYejnw1gd2QaOAoGyBfb86JsRqI)
	elif gNPa1EDOeyLr3KjlQ2R0n in ['SHORT_EPG','FULL_EPG']: wShpRxqK8CaToQ1m = pe3VuOcGgMifbHIdQB
	if gNPa1EDOeyLr3KjlQ2R0n=='FULL_EPG' and len(wShpRxqK8CaToQ1m)>0:
		OZD1l4pAMzeH('link',RTUaJZyvOuDA83So7M+n0nFOd4yR97fQzNLSW+'هذه قائمة برامج القنوات (جدول فقط)ـ'+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	GnUXf03YIKcSuW8mMjiQJ26BrF = []
	BZylVOjQcDenA4qIC9whT = bEWpDHXjCBqd7aOiN6UG5k.getInfoLabel('ListItem.Icon')
	for vZYejnw1gd2QaOAoGyBfb86JsRqI in wShpRxqK8CaToQ1m:
		ljGZCOmnVrtqy8WNHbgx4LEzpYfX = JNfHYgOdP9aR.b64decode(vZYejnw1gd2QaOAoGyBfb86JsRqI['title'])
		if jTDWgftK7NEmx0JAkOn2aRIvweq: ljGZCOmnVrtqy8WNHbgx4LEzpYfX = ljGZCOmnVrtqy8WNHbgx4LEzpYfX.decode(Tk9eH2qw6Brsuhj)
		nSRKXg1FMNhj0pt = int(vZYejnw1gd2QaOAoGyBfb86JsRqI['start_timestamp'])
		unhKOyY5EClV24XtUwq1xQi9e = int(vZYejnw1gd2QaOAoGyBfb86JsRqI['stop_timestamp'])
		bwSVZAzjcKdnMf2Xuk = str(int((unhKOyY5EClV24XtUwq1xQi9e-nSRKXg1FMNhj0pt+59)/60))
		ffWsckw8LaPJZC0n3i = vZYejnw1gd2QaOAoGyBfb86JsRqI['start'].replace(ksJdoFWhxTz8Y2N7bOZE,':')
		GHiT09cXFQyzJ7YV6MqW8xR3 = uUqrNPcXKBoQ0slv.localtime(nSRKXg1FMNhj0pt-tpCSLxQO2swRuedhYbVB1Evri5k)
		WOULJkEM0A = uUqrNPcXKBoQ0slv.strftime('%H:%M',GHiT09cXFQyzJ7YV6MqW8xR3)
		ggjnUe0FOGL = uUqrNPcXKBoQ0slv.strftime('%a',GHiT09cXFQyzJ7YV6MqW8xR3)
		if gNPa1EDOeyLr3KjlQ2R0n=='SHORT_EPG': ljGZCOmnVrtqy8WNHbgx4LEzpYfX = WydpaVx5YmLoCiIgA34eEBlb+WOULJkEM0A+' ـ '+ljGZCOmnVrtqy8WNHbgx4LEzpYfX+T7ASIp1ZYwio9HQ8cObJK
		elif gNPa1EDOeyLr3KjlQ2R0n=='TIMESHIFT': ljGZCOmnVrtqy8WNHbgx4LEzpYfX = ggjnUe0FOGL+ksJdoFWhxTz8Y2N7bOZE+WOULJkEM0A+' ('+bwSVZAzjcKdnMf2Xuk+'min)'
		else: ljGZCOmnVrtqy8WNHbgx4LEzpYfX = ggjnUe0FOGL+ksJdoFWhxTz8Y2N7bOZE+WOULJkEM0A+' ('+bwSVZAzjcKdnMf2Xuk+'min)   '+ljGZCOmnVrtqy8WNHbgx4LEzpYfX+' ـ'
		if gNPa1EDOeyLr3KjlQ2R0n in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			AozX01QZOFcjbP9kaMYRd25u = Bfx6z0mpyv24nXsGIDRPick8OAq+'/timeshift/'+jLH92iKQbNwduyFUA1ERaCI8B+'/'+eeTOKr2C0B+'/'+bwSVZAzjcKdnMf2Xuk+'/'+ffWsckw8LaPJZC0n3i+'/'+lFnOiIjzQ65cySV4CYPsN9XbaRBgdH+'.m3u8'
			if gNPa1EDOeyLr3KjlQ2R0n=='FULL_EPG': OZD1l4pAMzeH('link',RTUaJZyvOuDA83So7M+ljGZCOmnVrtqy8WNHbgx4LEzpYfX,AozX01QZOFcjbP9kaMYRd25u,9999,BZylVOjQcDenA4qIC9whT,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,{'folder':ZXOQjgueim57H6p1NrCsTyzA})
			else: OZD1l4pAMzeH('video',RTUaJZyvOuDA83So7M+ljGZCOmnVrtqy8WNHbgx4LEzpYfX,AozX01QZOFcjbP9kaMYRd25u,715,BZylVOjQcDenA4qIC9whT,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,{'folder':ZXOQjgueim57H6p1NrCsTyzA})
		GnUXf03YIKcSuW8mMjiQJ26BrF.append(ljGZCOmnVrtqy8WNHbgx4LEzpYfX)
	if gNPa1EDOeyLr3KjlQ2R0n=='SHORT_EPG' and GnUXf03YIKcSuW8mMjiQJ26BrF: kILGtPUqr96A = hjaUEy4dNPCIe(GnUXf03YIKcSuW8mMjiQJ26BrF)
	return GnUXf03YIKcSuW8mMjiQJ26BrF
def ZZlWDjVLPiEFoTGgUqOw2Mn6(ZXOQjgueim57H6p1NrCsTyzA):
	if not dt5U3cZpCFGRHDue7a1(ZXOQjgueim57H6p1NrCsTyzA,True): return
	Bfx6z0mpyv24nXsGIDRPick8OAq,eofyEsk9iCcR,sbqYa9kXChtcfWVLKH7UOGlg0 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,0,0
	PDe9Y0d4kKrAX5HSChOumGZFVqU8,uq7nABJIXg1hUEcP,IIruJ4ewaCPfLFpcB3oXQZG57 = SUE7qcdbaYW54wBzNv80n(ZXOQjgueim57H6p1NrCsTyzA,False)
	if PDe9Y0d4kKrAX5HSChOumGZFVqU8:
		e8KAj2wybvtUz9G4 = xuEgXlQW2PYy1MC7dAq3zIn69sKVN(uq7nABJIXg1hUEcP)
		eofyEsk9iCcR = gn6Rhp5VIDGUAbvYL(e8KAj2wybvtUz9G4[0],int(IIruJ4ewaCPfLFpcB3oXQZG57))
		xQuWTvpwISyoGRr73A8Yz = q65BmenP4if3yG2D(ZXOQjgueim57H6p1NrCsTyzA,'LIVE_GROUPED')
		iu0zWkDsBmVEcTyKlodC2x9fRZNF5 = rIhXWK91vRuC(xQuWTvpwISyoGRr73A8Yz,'list','LIVE_GROUPED')
		R4zwxKcC6785U2FtXMySgElqf = rIhXWK91vRuC(xQuWTvpwISyoGRr73A8Yz,'list','LIVE_GROUPED',iu0zWkDsBmVEcTyKlodC2x9fRZNF5[1])
		eEncXMVB2rNg4JObl3utYfj = R4zwxKcC6785U2FtXMySgElqf[0][2]
		KAMDS0BhOne2Lv73uZf8CcgEU = EcQxOa3RJm86WjTKA.findall('://(.*?)/',eEncXMVB2rNg4JObl3utYfj,EcQxOa3RJm86WjTKA.DOTALL)
		KAMDS0BhOne2Lv73uZf8CcgEU = KAMDS0BhOne2Lv73uZf8CcgEU[0]
		if ':' in KAMDS0BhOne2Lv73uZf8CcgEU: zGugDWjmIaRveVfoL1O23K0,PaIsqTutJ9Rif = KAMDS0BhOne2Lv73uZf8CcgEU.split(':')
		else: zGugDWjmIaRveVfoL1O23K0,PaIsqTutJ9Rif = KAMDS0BhOne2Lv73uZf8CcgEU,'80'
		UUIqzP5TMCwHV8tyx6iWGXSg4Os2de = xuEgXlQW2PYy1MC7dAq3zIn69sKVN(zGugDWjmIaRveVfoL1O23K0)
		sbqYa9kXChtcfWVLKH7UOGlg0 = gn6Rhp5VIDGUAbvYL(UUIqzP5TMCwHV8tyx6iWGXSg4Os2de[0],int(PaIsqTutJ9Rif))
	if eofyEsk9iCcR and sbqYa9kXChtcfWVLKH7UOGlg0:
		kf40tulvSA7z9RqNF5dXca3seMD = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		kf40tulvSA7z9RqNF5dXca3seMD += '\n\n'+'وقت ضائع في السيرفر الأصلي'+C0qrknitpM4Z+str(int(sbqYa9kXChtcfWVLKH7UOGlg0*1000))+' ملي ثانية'
		kf40tulvSA7z9RqNF5dXca3seMD += '\n\n'+'وقت ضائع في السيرفر البديل'+C0qrknitpM4Z+str(int(eofyEsk9iCcR*1000))+' ملي ثانية'
		P2xUVGmQ3TY1OXK46 = vv7siKgM9IfbCjPNqxXD('center','السيرفر الأصلي','السيرفر الأسرع','رسالة من المبرمج',kf40tulvSA7z9RqNF5dXca3seMD)
		if P2xUVGmQ3TY1OXK46==1 and eofyEsk9iCcR<sbqYa9kXChtcfWVLKH7UOGlg0: Bfx6z0mpyv24nXsGIDRPick8OAq = uq7nABJIXg1hUEcP+':'+IIruJ4ewaCPfLFpcB3oXQZG57
	else: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','البرنامج لم يجد السيرفر البديل')
	OdiZIyCfDUsW3JBGR2VAb.setSetting('av.m3u.server_'+ZXOQjgueim57H6p1NrCsTyzA,Bfx6z0mpyv24nXsGIDRPick8OAq)
	return
def rr7SfotkneX85Klup(ZXOQjgueim57H6p1NrCsTyzA,eEncXMVB2rNg4JObl3utYfj,ppi24CwDdH3YzVIK8BUyLluQJEMW):
	r1y6P9Xu2k8HvY0ijMwfdILZqxpDl = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.m3u.useragent_'+ZXOQjgueim57H6p1NrCsTyzA)
	jAHnXThec4vrQdqNKGb5oR = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.m3u.referer_'+ZXOQjgueim57H6p1NrCsTyzA)
	if r1y6P9Xu2k8HvY0ijMwfdILZqxpDl or jAHnXThec4vrQdqNKGb5oR:
		eEncXMVB2rNg4JObl3utYfj += '|'
		if r1y6P9Xu2k8HvY0ijMwfdILZqxpDl: eEncXMVB2rNg4JObl3utYfj += '&User-Agent='+r1y6P9Xu2k8HvY0ijMwfdILZqxpDl
		if jAHnXThec4vrQdqNKGb5oR: eEncXMVB2rNg4JObl3utYfj += '&Referer='+jAHnXThec4vrQdqNKGb5oR
		eEncXMVB2rNg4JObl3utYfj = eEncXMVB2rNg4JObl3utYfj.replace('|&','|')
	E7HR1ZcMuzUs9XCVrNGJYi(eEncXMVB2rNg4JObl3utYfj,x5TvLsPECHUoaqg1Dl3GwJj,ppi24CwDdH3YzVIK8BUyLluQJEMW)
	return
def NHIDGo9Estfi0wAduFZ(ZXOQjgueim57H6p1NrCsTyzA):
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـUser-Agent خاص')
	r1y6P9Xu2k8HvY0ijMwfdILZqxpDl = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.m3u.useragent_'+ZXOQjgueim57H6p1NrCsTyzA)
	Qfbryn5auc7TDVBghOj2GAqIopW = vv7siKgM9IfbCjPNqxXD('center','استخدام الأصلي','تعديل القديم',r1y6P9Xu2k8HvY0ijMwfdILZqxpDl,'هذا هو ـUser-Agent المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if Qfbryn5auc7TDVBghOj2GAqIopW==1: r1y6P9Xu2k8HvY0ijMwfdILZqxpDl = GFYl1tsoOkHC0Ajeur8JQiMx('أكتب ـM3U User-Agent جديد',r1y6P9Xu2k8HvY0ijMwfdILZqxpDl,True)
	else: r1y6P9Xu2k8HvY0ijMwfdILZqxpDl = 'Unknown'
	if r1y6P9Xu2k8HvY0ijMwfdILZqxpDl==ksJdoFWhxTz8Y2N7bOZE:
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	Qfbryn5auc7TDVBghOj2GAqIopW = vv7siKgM9IfbCjPNqxXD('center',fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,r1y6P9Xu2k8HvY0ijMwfdILZqxpDl,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if Qfbryn5auc7TDVBghOj2GAqIopW!=1:
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','تم الإلغاء')
		return
	OdiZIyCfDUsW3JBGR2VAb.setSetting('av.m3u.useragent_'+ZXOQjgueim57H6p1NrCsTyzA,r1y6P9Xu2k8HvY0ijMwfdILZqxpDl)
	PN79yfYMSuoElUBchqWA5j0L32(ZXOQjgueim57H6p1NrCsTyzA)
	return
def yUAtKsbY3rw(ZXOQjgueim57H6p1NrCsTyzA):
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـReferer خاص')
	jAHnXThec4vrQdqNKGb5oR = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.m3u.referer_'+ZXOQjgueim57H6p1NrCsTyzA)
	Qfbryn5auc7TDVBghOj2GAqIopW = vv7siKgM9IfbCjPNqxXD('center','استخدام الأصلي','تعديل القديم',jAHnXThec4vrQdqNKGb5oR,'هذا هو ـReferer المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if Qfbryn5auc7TDVBghOj2GAqIopW==1: jAHnXThec4vrQdqNKGb5oR = GFYl1tsoOkHC0Ajeur8JQiMx('أكتب ـM3U Referer جديد',jAHnXThec4vrQdqNKGb5oR,True)
	else: jAHnXThec4vrQdqNKGb5oR = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if jAHnXThec4vrQdqNKGb5oR==ksJdoFWhxTz8Y2N7bOZE:
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	Qfbryn5auc7TDVBghOj2GAqIopW = vv7siKgM9IfbCjPNqxXD('center',fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,jAHnXThec4vrQdqNKGb5oR,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if Qfbryn5auc7TDVBghOj2GAqIopW!=1:
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','تم الإلغاء')
		return
	OdiZIyCfDUsW3JBGR2VAb.setSetting('av.m3u.referer_'+ZXOQjgueim57H6p1NrCsTyzA,jAHnXThec4vrQdqNKGb5oR)
	PN79yfYMSuoElUBchqWA5j0L32(ZXOQjgueim57H6p1NrCsTyzA)
	return
def AdopjyR7eknJQVHKD8EvhalW2Luz(ZXOQjgueim57H6p1NrCsTyzA,RBXGuUwWvdaED2zkYK1lb=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if not zzJIg20oTjXx645rCQKi: zzJIg20oTjXx645rCQKi = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.m3u.url_'+ZXOQjgueim57H6p1NrCsTyzA)
	Bfx6z0mpyv24nXsGIDRPick8OAq = VbHeOuU1ilzSp2ZRXwBD(zzJIg20oTjXx645rCQKi,'url')
	jLH92iKQbNwduyFUA1ERaCI8B = EcQxOa3RJm86WjTKA.findall('username=(.*?)&',zzJIg20oTjXx645rCQKi+'&',EcQxOa3RJm86WjTKA.DOTALL)
	eeTOKr2C0B = EcQxOa3RJm86WjTKA.findall('password=(.*?)&',zzJIg20oTjXx645rCQKi+'&',EcQxOa3RJm86WjTKA.DOTALL)
	if not jLH92iKQbNwduyFUA1ERaCI8B or not eeTOKr2C0B:
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'فحص اشتراك M3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		return fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	jLH92iKQbNwduyFUA1ERaCI8B = jLH92iKQbNwduyFUA1ERaCI8B[0]
	eeTOKr2C0B = eeTOKr2C0B[0]
	lkJgRb8NafDzW1C = Bfx6z0mpyv24nXsGIDRPick8OAq+'/player_api.php?username='+jLH92iKQbNwduyFUA1ERaCI8B+'&password='+eeTOKr2C0B
	uzW1Gnb9y3 = Bfx6z0mpyv24nXsGIDRPick8OAq+'/get.php?username='+jLH92iKQbNwduyFUA1ERaCI8B+'&password='+eeTOKr2C0B+'&type=m3u_plus'
	return lkJgRb8NafDzW1C,uzW1Gnb9y3,Bfx6z0mpyv24nXsGIDRPick8OAq,jLH92iKQbNwduyFUA1ERaCI8B,eeTOKr2C0B
def WMurFt5Vw0HqaIiPyJSoTl1DmA(ZXOQjgueim57H6p1NrCsTyzA,Dle3w7YFbxTSKzMRnviW4UrdVg=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	RPxFQKVfJ8539aOwsdtp62yBXAhCS = Dle3w7YFbxTSKzMRnviW4UrdVg.replace('/','_').replace(':','_').replace('.','_')
	RPxFQKVfJ8539aOwsdtp62yBXAhCS = RPxFQKVfJ8539aOwsdtp62yBXAhCS.replace('?','_').replace('=','_').replace('&','_')
	RPxFQKVfJ8539aOwsdtp62yBXAhCS = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(Xsc4lqOhdziToWvunbRNSQZKIY8E,RPxFQKVfJ8539aOwsdtp62yBXAhCS).strip('.m3u')+'.m3u'
	return RPxFQKVfJ8539aOwsdtp62yBXAhCS
def zX2tLATroY9qi0(ZXOQjgueim57H6p1NrCsTyzA,d5dAoMmGN2V):
	jb3yhnu2CKmSeFER7cVLf8Z = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.m3u.url_'+ZXOQjgueim57H6p1NrCsTyzA+'_'+d5dAoMmGN2V)
	qeUCAg53xTsIvNM7fZdy = True
	if jb3yhnu2CKmSeFER7cVLf8Z:
		Qfbryn5auc7TDVBghOj2GAqIopW = jPRJMOhT415yvioG8rN9m0Q3b('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',n0nFOd4yR97fQzNLSW+jb3yhnu2CKmSeFER7cVLf8Z+T7ASIp1ZYwio9HQ8cObJK+'\n\n هذا هو رابط M3U المسجل في البرنامج .. هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if Qfbryn5auc7TDVBghOj2GAqIopW==-1: return
		elif Qfbryn5auc7TDVBghOj2GAqIopW==0: jb3yhnu2CKmSeFER7cVLf8Z = fy8iFgEkrO12NR9TWBI35sjY6qHvV
		elif Qfbryn5auc7TDVBghOj2GAqIopW==2:
			Qfbryn5auc7TDVBghOj2GAqIopW = vv7siKgM9IfbCjPNqxXD('center',fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if Qfbryn5auc7TDVBghOj2GAqIopW in [-1,0]: return
			GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','تم مسح الرابط')
			qeUCAg53xTsIvNM7fZdy = False
			ddOaGgfFsZnm7oW = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if qeUCAg53xTsIvNM7fZdy:
		ddOaGgfFsZnm7oW = GFYl1tsoOkHC0Ajeur8JQiMx('اكتب رابط M3U كاملا',jb3yhnu2CKmSeFER7cVLf8Z)
		ddOaGgfFsZnm7oW = ddOaGgfFsZnm7oW.strip(ksJdoFWhxTz8Y2N7bOZE)
		if not ddOaGgfFsZnm7oW:
			Qfbryn5auc7TDVBghOj2GAqIopW = vv7siKgM9IfbCjPNqxXD('center',fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if Qfbryn5auc7TDVBghOj2GAqIopW in [-1,0]: return
			GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','تم مسح الرابط')
		else:
			kf40tulvSA7z9RqNF5dXca3seMD = 'هذه المعلومات تم أخذها من رابط ـM3U الذي انت كتبته . هل تريد استخدامها ؟!\n'
			Qfbryn5auc7TDVBghOj2GAqIopW = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'الرابط الجديد هو:',n0nFOd4yR97fQzNLSW+ddOaGgfFsZnm7oW+T7ASIp1ZYwio9HQ8cObJK+'\n\n'+kf40tulvSA7z9RqNF5dXca3seMD)
			if Qfbryn5auc7TDVBghOj2GAqIopW!=1:
				GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','تم الإلغاء')
				return
	OdiZIyCfDUsW3JBGR2VAb.setSetting('av.m3u.url_'+ZXOQjgueim57H6p1NrCsTyzA+'_'+d5dAoMmGN2V,ddOaGgfFsZnm7oW)
	r1y6P9Xu2k8HvY0ijMwfdILZqxpDl = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.m3u.useragent_'+ZXOQjgueim57H6p1NrCsTyzA)
	if not r1y6P9Xu2k8HvY0ijMwfdILZqxpDl: OdiZIyCfDUsW3JBGR2VAb.setSetting('av.m3u.useragent_'+ZXOQjgueim57H6p1NrCsTyzA,'Unknown')
	PN79yfYMSuoElUBchqWA5j0L32(ZXOQjgueim57H6p1NrCsTyzA)
	return
def KG3SNymapwnOi74ejqtRb(LZhBxTSy4qP7zKIbGw,gRDbOecxwEh4r7q,CHx6dXNmWgV4,KSH2Qq8wdT4GiktV,gDb5wsPxWQJjVL8oXSIT2uF1rNUtZq,JhvuCHVREPNqU8bomeTcpOzFrw,uzW1Gnb9y3):
	R4zwxKcC6785U2FtXMySgElqf,VBogfjwYHnJe6aN = [],[]
	vf9YVHGD03zjIFink8SKxyMoh = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for gSUZXf3r57Bzeq in LZhBxTSy4qP7zKIbGw:
		if JhvuCHVREPNqU8bomeTcpOzFrw%473==0:
			Hnrjh7smUIGq3RgDy19CL(KSH2Qq8wdT4GiktV,40+int(10*JhvuCHVREPNqU8bomeTcpOzFrw/gDb5wsPxWQJjVL8oXSIT2uF1rNUtZq),'قراءة الفيديوهات','الفيديو رقم:-',str(JhvuCHVREPNqU8bomeTcpOzFrw)+' / '+str(gDb5wsPxWQJjVL8oXSIT2uF1rNUtZq))
			if KSH2Qq8wdT4GiktV.iscanceled():
				KSH2Qq8wdT4GiktV.close()
				return None,None,None
		eEncXMVB2rNg4JObl3utYfj = EcQxOa3RJm86WjTKA.findall('^(.*?)\n+((http|https|rtmp).*?)$',gSUZXf3r57Bzeq,EcQxOa3RJm86WjTKA.DOTALL)
		if eEncXMVB2rNg4JObl3utYfj:
			gSUZXf3r57Bzeq,eEncXMVB2rNg4JObl3utYfj,wwufxh1HS5oreOgtW = eEncXMVB2rNg4JObl3utYfj[0]
			eEncXMVB2rNg4JObl3utYfj = eEncXMVB2rNg4JObl3utYfj.replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			gSUZXf3r57Bzeq = gSUZXf3r57Bzeq.replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		else:
			VBogfjwYHnJe6aN.append({'line':gSUZXf3r57Bzeq})
			continue
		NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ,R5gQk0ZcerYx3B,GMdo5bjPOp1J86VQ4,ljGZCOmnVrtqy8WNHbgx4LEzpYfX,ppi24CwDdH3YzVIK8BUyLluQJEMW,qzv45xdspDhCQwGgMyNR8Y = {},fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,False
		try:
			gSUZXf3r57Bzeq,ljGZCOmnVrtqy8WNHbgx4LEzpYfX = gSUZXf3r57Bzeq.rsplit('",',1)
			gSUZXf3r57Bzeq = gSUZXf3r57Bzeq+'"'
		except:
			try: gSUZXf3r57Bzeq,ljGZCOmnVrtqy8WNHbgx4LEzpYfX = gSUZXf3r57Bzeq.rsplit('1,',1)
			except: ljGZCOmnVrtqy8WNHbgx4LEzpYfX = fy8iFgEkrO12NR9TWBI35sjY6qHvV
		NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['url'] = eEncXMVB2rNg4JObl3utYfj
		u3X8rmUMGwtTF24iPsLxvhBN9g = EcQxOa3RJm86WjTKA.findall(' (.*?)="(.*?)"',gSUZXf3r57Bzeq,EcQxOa3RJm86WjTKA.DOTALL)
		for ZYo1OtjRwCc2eAlK,NuDMk1wQAyWXg in u3X8rmUMGwtTF24iPsLxvhBN9g:
			ZYo1OtjRwCc2eAlK = ZYo1OtjRwCc2eAlK.replace('"',fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE)
			NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ[ZYo1OtjRwCc2eAlK] = NuDMk1wQAyWXg.strip(ksJdoFWhxTz8Y2N7bOZE)
		qTka2EHZlFfLcyzhXeCDS9dN16bIo = list(NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ.keys())
		if not ljGZCOmnVrtqy8WNHbgx4LEzpYfX:
			if 'name' in qTka2EHZlFfLcyzhXeCDS9dN16bIo and NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['name']: ljGZCOmnVrtqy8WNHbgx4LEzpYfX = NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['name']
		NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['title'] = ljGZCOmnVrtqy8WNHbgx4LEzpYfX.strip(ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE)
		if 'logo' in qTka2EHZlFfLcyzhXeCDS9dN16bIo:
			NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['img'] = NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['logo']
			del NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['logo']
		else: NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['img'] = fy8iFgEkrO12NR9TWBI35sjY6qHvV
		if 'group' in qTka2EHZlFfLcyzhXeCDS9dN16bIo and NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['group']: GMdo5bjPOp1J86VQ4 = NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['group']
		if any(value in eEncXMVB2rNg4JObl3utYfj.lower() for value in vf9YVHGD03zjIFink8SKxyMoh):
			qzv45xdspDhCQwGgMyNR8Y = True if 'm3u' not in eEncXMVB2rNg4JObl3utYfj else False
		if qzv45xdspDhCQwGgMyNR8Y or '__SERIES__' in GMdo5bjPOp1J86VQ4 or '__MOVIES__' in GMdo5bjPOp1J86VQ4:
			ppi24CwDdH3YzVIK8BUyLluQJEMW = 'VOD'
			if '__SERIES__' in GMdo5bjPOp1J86VQ4: ppi24CwDdH3YzVIK8BUyLluQJEMW = ppi24CwDdH3YzVIK8BUyLluQJEMW+'_SERIES'
			elif '__MOVIES__' in GMdo5bjPOp1J86VQ4: ppi24CwDdH3YzVIK8BUyLluQJEMW = ppi24CwDdH3YzVIK8BUyLluQJEMW+'_MOVIES'
			else: ppi24CwDdH3YzVIK8BUyLluQJEMW = ppi24CwDdH3YzVIK8BUyLluQJEMW+'_UNKNOWN'
			GMdo5bjPOp1J86VQ4 = GMdo5bjPOp1J86VQ4.replace('__SERIES__',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('__MOVIES__',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		else:
			ppi24CwDdH3YzVIK8BUyLluQJEMW = 'LIVE'
			if ljGZCOmnVrtqy8WNHbgx4LEzpYfX in gRDbOecxwEh4r7q: R5gQk0ZcerYx3B = R5gQk0ZcerYx3B+'_EPG'
			if ljGZCOmnVrtqy8WNHbgx4LEzpYfX in CHx6dXNmWgV4: R5gQk0ZcerYx3B = R5gQk0ZcerYx3B+'_ARCHIVED'
			if not GMdo5bjPOp1J86VQ4: ppi24CwDdH3YzVIK8BUyLluQJEMW = ppi24CwDdH3YzVIK8BUyLluQJEMW+'_UNKNOWN'
			else: ppi24CwDdH3YzVIK8BUyLluQJEMW = ppi24CwDdH3YzVIK8BUyLluQJEMW+R5gQk0ZcerYx3B
		GMdo5bjPOp1J86VQ4 = GMdo5bjPOp1J86VQ4.strip(ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE)
		if 'LIVE_UNKNOWN' in ppi24CwDdH3YzVIK8BUyLluQJEMW: GMdo5bjPOp1J86VQ4 = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in ppi24CwDdH3YzVIK8BUyLluQJEMW: GMdo5bjPOp1J86VQ4 = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in ppi24CwDdH3YzVIK8BUyLluQJEMW:
			ygoh3PU8tpWSiJYbR2BGKCXQAuT = EcQxOa3RJm86WjTKA.findall('(.*?) [Ss]\d+ +[Ee]\d+',NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['title'],EcQxOa3RJm86WjTKA.DOTALL)
			if ygoh3PU8tpWSiJYbR2BGKCXQAuT: ygoh3PU8tpWSiJYbR2BGKCXQAuT = ygoh3PU8tpWSiJYbR2BGKCXQAuT[0]
			else: ygoh3PU8tpWSiJYbR2BGKCXQAuT = '!!__UNKNOWN_SERIES__!!'
			GMdo5bjPOp1J86VQ4 = GMdo5bjPOp1J86VQ4+'__SERIES__'+ygoh3PU8tpWSiJYbR2BGKCXQAuT
		if 'id' in qTka2EHZlFfLcyzhXeCDS9dN16bIo: del NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['id']
		if 'ID' in qTka2EHZlFfLcyzhXeCDS9dN16bIo: del NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['ID']
		if 'name' in qTka2EHZlFfLcyzhXeCDS9dN16bIo: del NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['name']
		ljGZCOmnVrtqy8WNHbgx4LEzpYfX = NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['title']
		ljGZCOmnVrtqy8WNHbgx4LEzpYfX = XXcPiylRDh6IapYA25rwO8u(ljGZCOmnVrtqy8WNHbgx4LEzpYfX)
		ljGZCOmnVrtqy8WNHbgx4LEzpYfX = FFgMl17JpPrLD2zWubetwdTn96m(ljGZCOmnVrtqy8WNHbgx4LEzpYfX)
		a76KTkFwZUL5yjczQxmJqn4MuOrd9G,GMdo5bjPOp1J86VQ4 = oI4iJBleE65N08zRQF(GMdo5bjPOp1J86VQ4)
		hcM9SIWxqBOvuVRG6bENk,ljGZCOmnVrtqy8WNHbgx4LEzpYfX = oI4iJBleE65N08zRQF(ljGZCOmnVrtqy8WNHbgx4LEzpYfX)
		NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['type'] = ppi24CwDdH3YzVIK8BUyLluQJEMW
		NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['context'] = R5gQk0ZcerYx3B
		NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['group'] = GMdo5bjPOp1J86VQ4.upper()
		NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['title'] = ljGZCOmnVrtqy8WNHbgx4LEzpYfX.upper()
		NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['country'] = hcM9SIWxqBOvuVRG6bENk.upper()
		NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['language'] = a76KTkFwZUL5yjczQxmJqn4MuOrd9G.upper()
		R4zwxKcC6785U2FtXMySgElqf.append(NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ)
		JhvuCHVREPNqU8bomeTcpOzFrw += 1
	return R4zwxKcC6785U2FtXMySgElqf,JhvuCHVREPNqU8bomeTcpOzFrw,VBogfjwYHnJe6aN
def FFgMl17JpPrLD2zWubetwdTn96m(ljGZCOmnVrtqy8WNHbgx4LEzpYfX):
	ljGZCOmnVrtqy8WNHbgx4LEzpYfX = ljGZCOmnVrtqy8WNHbgx4LEzpYfX.replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE)
	ljGZCOmnVrtqy8WNHbgx4LEzpYfX = ljGZCOmnVrtqy8WNHbgx4LEzpYfX.replace('||','|').replace('___',':').replace('--','-')
	ljGZCOmnVrtqy8WNHbgx4LEzpYfX = ljGZCOmnVrtqy8WNHbgx4LEzpYfX.replace('[[','[').replace(']]',']')
	ljGZCOmnVrtqy8WNHbgx4LEzpYfX = ljGZCOmnVrtqy8WNHbgx4LEzpYfX.replace('((','(').replace('))',')')
	ljGZCOmnVrtqy8WNHbgx4LEzpYfX = ljGZCOmnVrtqy8WNHbgx4LEzpYfX.replace('<<','<').replace('>>','>')
	ljGZCOmnVrtqy8WNHbgx4LEzpYfX = ljGZCOmnVrtqy8WNHbgx4LEzpYfX.strip(ksJdoFWhxTz8Y2N7bOZE)
	return ljGZCOmnVrtqy8WNHbgx4LEzpYfX
def ZKWOcsJV2jxTALGenrpSQgvR(ppG9q0CtDci,KSH2Qq8wdT4GiktV,d5dAoMmGN2V):
	w136gLc0N5ul8YB = {}
	for bNV1HSM4fQDoKgT8Usu2FvJdOatIL in ndDvK6Nf4p5E: w136gLc0N5ul8YB[bNV1HSM4fQDoKgT8Usu2FvJdOatIL+'_'+d5dAoMmGN2V] = []
	gDb5wsPxWQJjVL8oXSIT2uF1rNUtZq = len(ppG9q0CtDci)
	yZtYQnsNP8 = str(gDb5wsPxWQJjVL8oXSIT2uF1rNUtZq)
	JhvuCHVREPNqU8bomeTcpOzFrw = 0
	VBogfjwYHnJe6aN = []
	for NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ in ppG9q0CtDci:
		if JhvuCHVREPNqU8bomeTcpOzFrw%873==0:
			Hnrjh7smUIGq3RgDy19CL(KSH2Qq8wdT4GiktV,50+int(5*JhvuCHVREPNqU8bomeTcpOzFrw/gDb5wsPxWQJjVL8oXSIT2uF1rNUtZq),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(JhvuCHVREPNqU8bomeTcpOzFrw)+' / '+yZtYQnsNP8)
			if KSH2Qq8wdT4GiktV.iscanceled():
				KSH2Qq8wdT4GiktV.close()
				return None,None
		GMdo5bjPOp1J86VQ4,R5gQk0ZcerYx3B,ljGZCOmnVrtqy8WNHbgx4LEzpYfX,eEncXMVB2rNg4JObl3utYfj,BZylVOjQcDenA4qIC9whT = NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['group'],NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['context'],NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['title'],NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['url'],NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['img']
		hcM9SIWxqBOvuVRG6bENk,a76KTkFwZUL5yjczQxmJqn4MuOrd9G,bNV1HSM4fQDoKgT8Usu2FvJdOatIL = NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['country'],NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['language'],NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['type']
		GTXZKHvSUcPRlrAFE = (GMdo5bjPOp1J86VQ4,R5gQk0ZcerYx3B,ljGZCOmnVrtqy8WNHbgx4LEzpYfX,eEncXMVB2rNg4JObl3utYfj,BZylVOjQcDenA4qIC9whT)
		bkCyqGfi1TNl = False
		if 'LIVE' in bNV1HSM4fQDoKgT8Usu2FvJdOatIL:
			if 'UNKNOWN' in bNV1HSM4fQDoKgT8Usu2FvJdOatIL: w136gLc0N5ul8YB['LIVE_UNKNOWN_GROUPED_'+d5dAoMmGN2V].append(GTXZKHvSUcPRlrAFE)
			elif 'LIVE' in bNV1HSM4fQDoKgT8Usu2FvJdOatIL: w136gLc0N5ul8YB['LIVE_GROUPED_'+d5dAoMmGN2V].append(GTXZKHvSUcPRlrAFE)
			else: bkCyqGfi1TNl = True
			w136gLc0N5ul8YB['LIVE_ORIGINAL_GROUPED_'+d5dAoMmGN2V].append(GTXZKHvSUcPRlrAFE)
		elif 'VOD' in bNV1HSM4fQDoKgT8Usu2FvJdOatIL:
			if 'UNKNOWN' in bNV1HSM4fQDoKgT8Usu2FvJdOatIL: w136gLc0N5ul8YB['VOD_UNKNOWN_GROUPED_'+d5dAoMmGN2V].append(GTXZKHvSUcPRlrAFE)
			elif 'MOVIES' in bNV1HSM4fQDoKgT8Usu2FvJdOatIL: w136gLc0N5ul8YB['VOD_MOVIES_GROUPED_'+d5dAoMmGN2V].append(GTXZKHvSUcPRlrAFE)
			elif 'SERIES' in bNV1HSM4fQDoKgT8Usu2FvJdOatIL: w136gLc0N5ul8YB['VOD_SERIES_GROUPED_'+d5dAoMmGN2V].append(GTXZKHvSUcPRlrAFE)
			else: bkCyqGfi1TNl = True
			w136gLc0N5ul8YB['VOD_ORIGINAL_GROUPED_'+d5dAoMmGN2V].append(GTXZKHvSUcPRlrAFE)
		else: bkCyqGfi1TNl = True
		if bkCyqGfi1TNl: VBogfjwYHnJe6aN.append(NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ)
		JhvuCHVREPNqU8bomeTcpOzFrw += 1
	Ux5vfeWlFRuL9A1w628ZzkmdajK = sorted(ppG9q0CtDci,reverse=False,key=lambda ZYo1OtjRwCc2eAlK: ZYo1OtjRwCc2eAlK['title'].lower())
	del ppG9q0CtDci
	yZtYQnsNP8 = str(gDb5wsPxWQJjVL8oXSIT2uF1rNUtZq)
	JhvuCHVREPNqU8bomeTcpOzFrw = 0
	for NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ in Ux5vfeWlFRuL9A1w628ZzkmdajK:
		JhvuCHVREPNqU8bomeTcpOzFrw += 1
		if JhvuCHVREPNqU8bomeTcpOzFrw%873==0:
			Hnrjh7smUIGq3RgDy19CL(KSH2Qq8wdT4GiktV,55+int(5*JhvuCHVREPNqU8bomeTcpOzFrw/gDb5wsPxWQJjVL8oXSIT2uF1rNUtZq),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(JhvuCHVREPNqU8bomeTcpOzFrw)+' / '+yZtYQnsNP8)
			if KSH2Qq8wdT4GiktV.iscanceled():
				KSH2Qq8wdT4GiktV.close()
				return None,None
		bNV1HSM4fQDoKgT8Usu2FvJdOatIL = NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['type']
		GMdo5bjPOp1J86VQ4,R5gQk0ZcerYx3B,ljGZCOmnVrtqy8WNHbgx4LEzpYfX,eEncXMVB2rNg4JObl3utYfj,BZylVOjQcDenA4qIC9whT = NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['group'],NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['context'],NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['title'],NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['url'],NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['img']
		hcM9SIWxqBOvuVRG6bENk,a76KTkFwZUL5yjczQxmJqn4MuOrd9G = NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['country'],NiI3vbsnA8KjpSDE2B7lcTVoGxLHJ['language']
		JvGYdBUqeNc2RwutWTpI8xf = (GMdo5bjPOp1J86VQ4,R5gQk0ZcerYx3B+'_TIMESHIFT',ljGZCOmnVrtqy8WNHbgx4LEzpYfX,eEncXMVB2rNg4JObl3utYfj,BZylVOjQcDenA4qIC9whT)
		GTXZKHvSUcPRlrAFE = (GMdo5bjPOp1J86VQ4,R5gQk0ZcerYx3B,ljGZCOmnVrtqy8WNHbgx4LEzpYfX,eEncXMVB2rNg4JObl3utYfj,BZylVOjQcDenA4qIC9whT)
		GPutVUC4rpf1oYIxH = (hcM9SIWxqBOvuVRG6bENk,R5gQk0ZcerYx3B,ljGZCOmnVrtqy8WNHbgx4LEzpYfX,eEncXMVB2rNg4JObl3utYfj,BZylVOjQcDenA4qIC9whT)
		ssiy1C9kDlZ8xAUdRN = (a76KTkFwZUL5yjczQxmJqn4MuOrd9G,R5gQk0ZcerYx3B,ljGZCOmnVrtqy8WNHbgx4LEzpYfX,eEncXMVB2rNg4JObl3utYfj,BZylVOjQcDenA4qIC9whT)
		if 'LIVE' in bNV1HSM4fQDoKgT8Usu2FvJdOatIL:
			if 'UNKNOWN' in bNV1HSM4fQDoKgT8Usu2FvJdOatIL: w136gLc0N5ul8YB['LIVE_UNKNOWN_GROUPED_SORTED_'+d5dAoMmGN2V].append(GTXZKHvSUcPRlrAFE)
			else: w136gLc0N5ul8YB['LIVE_GROUPED_SORTED_'+d5dAoMmGN2V].append(GTXZKHvSUcPRlrAFE)
			if 'EPG'		in bNV1HSM4fQDoKgT8Usu2FvJdOatIL: w136gLc0N5ul8YB['LIVE_EPG_GROUPED_SORTED_'+d5dAoMmGN2V].append(GTXZKHvSUcPRlrAFE)
			if 'ARCHIVED'	in bNV1HSM4fQDoKgT8Usu2FvJdOatIL: w136gLc0N5ul8YB['LIVE_ARCHIVED_GROUPED_SORTED_'+d5dAoMmGN2V].append(GTXZKHvSUcPRlrAFE)
			if 'ARCHIVED'	in bNV1HSM4fQDoKgT8Usu2FvJdOatIL: w136gLc0N5ul8YB['LIVE_TIMESHIFT_GROUPED_SORTED_'+d5dAoMmGN2V].append(JvGYdBUqeNc2RwutWTpI8xf)
			w136gLc0N5ul8YB['LIVE_FROM_NAME_SORTED_'+d5dAoMmGN2V].append(GPutVUC4rpf1oYIxH)
			w136gLc0N5ul8YB['LIVE_FROM_GROUP_SORTED_'+d5dAoMmGN2V].append(ssiy1C9kDlZ8xAUdRN)
		elif 'VOD' in bNV1HSM4fQDoKgT8Usu2FvJdOatIL:
			if   'UNKNOWN'	in bNV1HSM4fQDoKgT8Usu2FvJdOatIL: w136gLc0N5ul8YB['VOD_UNKNOWN_GROUPED_SORTED_'+d5dAoMmGN2V].append(GTXZKHvSUcPRlrAFE)
			elif 'MOVIES'	in bNV1HSM4fQDoKgT8Usu2FvJdOatIL: w136gLc0N5ul8YB['VOD_MOVIES_GROUPED_SORTED_'+d5dAoMmGN2V].append(GTXZKHvSUcPRlrAFE)
			elif 'SERIES'	in bNV1HSM4fQDoKgT8Usu2FvJdOatIL: w136gLc0N5ul8YB['VOD_SERIES_GROUPED_SORTED_'+d5dAoMmGN2V].append(GTXZKHvSUcPRlrAFE)
			w136gLc0N5ul8YB['VOD_FROM_NAME_SORTED_'+d5dAoMmGN2V].append(GPutVUC4rpf1oYIxH)
			w136gLc0N5ul8YB['VOD_FROM_GROUP_SORTED_'+d5dAoMmGN2V].append(ssiy1C9kDlZ8xAUdRN)
	return w136gLc0N5ul8YB,VBogfjwYHnJe6aN
def oI4iJBleE65N08zRQF(ljGZCOmnVrtqy8WNHbgx4LEzpYfX):
	if len(ljGZCOmnVrtqy8WNHbgx4LEzpYfX)<3: return ljGZCOmnVrtqy8WNHbgx4LEzpYfX,ljGZCOmnVrtqy8WNHbgx4LEzpYfX
	xatZNunFzSW0C9krgL3DpdMqoQj7A5,oopfrNHxksZjGDeVh8c5 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	NT38M2XV7L9Zt0AHgEQ = ljGZCOmnVrtqy8WNHbgx4LEzpYfX
	hTfCHGOtXvS8 = ljGZCOmnVrtqy8WNHbgx4LEzpYfX[:1]
	VunZTtwgJyvUxaR1HICGq = ljGZCOmnVrtqy8WNHbgx4LEzpYfX[1:]
	if   hTfCHGOtXvS8=='(': oopfrNHxksZjGDeVh8c5 = ')'
	elif hTfCHGOtXvS8=='[': oopfrNHxksZjGDeVh8c5 = ']'
	elif hTfCHGOtXvS8=='<': oopfrNHxksZjGDeVh8c5 = '>'
	elif hTfCHGOtXvS8=='|': oopfrNHxksZjGDeVh8c5 = '|'
	if oopfrNHxksZjGDeVh8c5 and (oopfrNHxksZjGDeVh8c5 in VunZTtwgJyvUxaR1HICGq):
		j9PvkauX07YVAWhRNmzDC48E,hf7AqPMbBmO3Ti5QIYK0DEFe = VunZTtwgJyvUxaR1HICGq.split(oopfrNHxksZjGDeVh8c5,1)
		xatZNunFzSW0C9krgL3DpdMqoQj7A5 = j9PvkauX07YVAWhRNmzDC48E
		NT38M2XV7L9Zt0AHgEQ = hTfCHGOtXvS8+j9PvkauX07YVAWhRNmzDC48E+oopfrNHxksZjGDeVh8c5+ksJdoFWhxTz8Y2N7bOZE+hf7AqPMbBmO3Ti5QIYK0DEFe
	elif ljGZCOmnVrtqy8WNHbgx4LEzpYfX.count('|')>=2:
		j9PvkauX07YVAWhRNmzDC48E,hf7AqPMbBmO3Ti5QIYK0DEFe = ljGZCOmnVrtqy8WNHbgx4LEzpYfX.split('|',1)
		xatZNunFzSW0C9krgL3DpdMqoQj7A5 = j9PvkauX07YVAWhRNmzDC48E
		NT38M2XV7L9Zt0AHgEQ = j9PvkauX07YVAWhRNmzDC48E+' |'+hf7AqPMbBmO3Ti5QIYK0DEFe
	else:
		oopfrNHxksZjGDeVh8c5 = EcQxOa3RJm86WjTKA.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',ljGZCOmnVrtqy8WNHbgx4LEzpYfX,EcQxOa3RJm86WjTKA.DOTALL)
		if not oopfrNHxksZjGDeVh8c5: oopfrNHxksZjGDeVh8c5 = EcQxOa3RJm86WjTKA.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',ljGZCOmnVrtqy8WNHbgx4LEzpYfX,EcQxOa3RJm86WjTKA.DOTALL)
		if not oopfrNHxksZjGDeVh8c5: oopfrNHxksZjGDeVh8c5 = EcQxOa3RJm86WjTKA.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',ljGZCOmnVrtqy8WNHbgx4LEzpYfX,EcQxOa3RJm86WjTKA.DOTALL)
		if oopfrNHxksZjGDeVh8c5:
			j9PvkauX07YVAWhRNmzDC48E,hf7AqPMbBmO3Ti5QIYK0DEFe = ljGZCOmnVrtqy8WNHbgx4LEzpYfX.split(oopfrNHxksZjGDeVh8c5[0],1)
			xatZNunFzSW0C9krgL3DpdMqoQj7A5 = j9PvkauX07YVAWhRNmzDC48E
			NT38M2XV7L9Zt0AHgEQ = j9PvkauX07YVAWhRNmzDC48E+ksJdoFWhxTz8Y2N7bOZE+oopfrNHxksZjGDeVh8c5[0]+ksJdoFWhxTz8Y2N7bOZE+hf7AqPMbBmO3Ti5QIYK0DEFe
	NT38M2XV7L9Zt0AHgEQ = NT38M2XV7L9Zt0AHgEQ.replace(yU7COAbsNJ916v5L0oew2n,ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE)
	xatZNunFzSW0C9krgL3DpdMqoQj7A5 = xatZNunFzSW0C9krgL3DpdMqoQj7A5.replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE)
	if not xatZNunFzSW0C9krgL3DpdMqoQj7A5: xatZNunFzSW0C9krgL3DpdMqoQj7A5 = '!!__UNKNOWN__!!'
	xatZNunFzSW0C9krgL3DpdMqoQj7A5 = xatZNunFzSW0C9krgL3DpdMqoQj7A5.strip(ksJdoFWhxTz8Y2N7bOZE)
	NT38M2XV7L9Zt0AHgEQ = NT38M2XV7L9Zt0AHgEQ.strip(ksJdoFWhxTz8Y2N7bOZE)
	return xatZNunFzSW0C9krgL3DpdMqoQj7A5,NT38M2XV7L9Zt0AHgEQ
def vTfnxOoiXZL6QztIpbDycBgumY8j0q(ZXOQjgueim57H6p1NrCsTyzA):
	LUvCxj6fMlnyEcDAahbgpH = {}
	r1y6P9Xu2k8HvY0ijMwfdILZqxpDl = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.m3u.useragent_'+ZXOQjgueim57H6p1NrCsTyzA)
	if r1y6P9Xu2k8HvY0ijMwfdILZqxpDl: LUvCxj6fMlnyEcDAahbgpH['User-Agent'] = r1y6P9Xu2k8HvY0ijMwfdILZqxpDl
	jAHnXThec4vrQdqNKGb5oR = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.m3u.referer_'+ZXOQjgueim57H6p1NrCsTyzA)
	if jAHnXThec4vrQdqNKGb5oR: LUvCxj6fMlnyEcDAahbgpH['Referer'] = jAHnXThec4vrQdqNKGb5oR
	return LUvCxj6fMlnyEcDAahbgpH
def si0SUOvWrnoqm9KpL(ZXOQjgueim57H6p1NrCsTyzA,d5dAoMmGN2V):
	global KSH2Qq8wdT4GiktV,w136gLc0N5ul8YB,KYRyVXdqWw2huMfCtLmS,P6M9vIpRo1szbujgBxYGycet,Z8hQpS0ATHfwRma29IUFg5,iu0zWkDsBmVEcTyKlodC2x9fRZNF5,ATO0NcGMzZ79IgqR1s3tQnDw,U2zFSIXg8WDqeHTGbpxLr,ttT0n3AbSUL2iCIWOD7E
	uzW1Gnb9y3 = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.m3u.url_'+ZXOQjgueim57H6p1NrCsTyzA+'_'+d5dAoMmGN2V)
	r1y6P9Xu2k8HvY0ijMwfdILZqxpDl = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.m3u.useragent_'+ZXOQjgueim57H6p1NrCsTyzA)
	LUvCxj6fMlnyEcDAahbgpH = {'User-Agent':r1y6P9Xu2k8HvY0ijMwfdILZqxpDl}
	RPxFQKVfJ8539aOwsdtp62yBXAhCS = gIzb6JN9UW0MnAVB.replace('___','_'+ZXOQjgueim57H6p1NrCsTyzA+'_'+d5dAoMmGN2V)
	if 1:
		PDe9Y0d4kKrAX5HSChOumGZFVqU8,uq7nABJIXg1hUEcP,IIruJ4ewaCPfLFpcB3oXQZG57 = True,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
		if not PDe9Y0d4kKrAX5HSChOumGZFVqU8:
			GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','فشل بسحب ملفات ـM3U . أحتمال رابط ـM3U غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـM3U الموجودة بهذا البرنامج')
			if not uzW1Gnb9y3: Clc8sIj97ZrThF(P3PazFblmtN,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+'   No M3U URL found to download M3U files')
			else: Clc8sIj97ZrThF(P3PazFblmtN,BaQzADt45VUslp1(x5TvLsPECHUoaqg1Dl3GwJj)+'   Failed to download M3U files')
			return
		ttf2i5eBHVXRd4wN = lxXI7yjkvd3OZ0E(uzW1Gnb9y3,LUvCxj6fMlnyEcDAahbgpH,True)
		if not ttf2i5eBHVXRd4wN: return
		open(RPxFQKVfJ8539aOwsdtp62yBXAhCS,'wb').write(ttf2i5eBHVXRd4wN)
	else: ttf2i5eBHVXRd4wN = open(RPxFQKVfJ8539aOwsdtp62yBXAhCS,'rb').read()
	if jTDWgftK7NEmx0JAkOn2aRIvweq and ttf2i5eBHVXRd4wN: ttf2i5eBHVXRd4wN = ttf2i5eBHVXRd4wN.decode(Tk9eH2qw6Brsuhj)
	KSH2Qq8wdT4GiktV = hieYJByqUTsF9CH7aD3()
	KSH2Qq8wdT4GiktV.create('جلب ملفات M3U جديدة',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	Hnrjh7smUIGq3RgDy19CL(KSH2Qq8wdT4GiktV,15,'تنظيف الملف الرئيسي',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	ttf2i5eBHVXRd4wN = ttf2i5eBHVXRd4wN.replace('"tvg-','" tvg-')
	ttf2i5eBHVXRd4wN = ttf2i5eBHVXRd4wN.replace('َ',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('ً',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('ُ',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('ٌ',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	ttf2i5eBHVXRd4wN = ttf2i5eBHVXRd4wN.replace('ّ',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('ِ',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('ٍ',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('ْ',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	ttf2i5eBHVXRd4wN = ttf2i5eBHVXRd4wN.replace('group-title=','group=').replace('tvg-',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	CHx6dXNmWgV4,gRDbOecxwEh4r7q = [],[]
	ttf2i5eBHVXRd4wN = ttf2i5eBHVXRd4wN.replace(FFkml6ZbgXD,C0qrknitpM4Z)
	LZhBxTSy4qP7zKIbGw = EcQxOa3RJm86WjTKA.findall('NF:(.+?)'+'#'+'EXTI',ttf2i5eBHVXRd4wN+'\n+'+'#'+'EXTINF:',EcQxOa3RJm86WjTKA.DOTALL)
	if not LZhBxTSy4qP7zKIbGw:
		Clc8sIj97ZrThF(P3PazFblmtN,BaQzADt45VUslp1(x5TvLsPECHUoaqg1Dl3GwJj)+'   Folder:'+ZXOQjgueim57H6p1NrCsTyzA+'  Sequence:'+d5dAoMmGN2V+'   No video links found in M3U file')
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','رابط ـM3U الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـM3U غير صحيح'+C0qrknitpM4Z+WydpaVx5YmLoCiIgA34eEBlb+'مجلد رقم '+ZXOQjgueim57H6p1NrCsTyzA+'      رابط رقم '+d5dAoMmGN2V+T7ASIp1ZYwio9HQ8cObJK)
		KSH2Qq8wdT4GiktV.close()
		return
	WlCm54IqEguKJD = []
	for gSUZXf3r57Bzeq in LZhBxTSy4qP7zKIbGw:
		ywVOMI8Athfc051Y = gSUZXf3r57Bzeq.lower()
		if 'adult' in ywVOMI8Athfc051Y: continue
		if 'xxx' in ywVOMI8Athfc051Y: continue
		WlCm54IqEguKJD.append(gSUZXf3r57Bzeq)
	LZhBxTSy4qP7zKIbGw = WlCm54IqEguKJD
	del WlCm54IqEguKJD
	if 'iptv-org' in uzW1Gnb9y3:
		WlCm54IqEguKJD,XFtKPxOiZWNd5f4l1y3Juq = [],[]
		for gSUZXf3r57Bzeq in LZhBxTSy4qP7zKIbGw:
			iu0zWkDsBmVEcTyKlodC2x9fRZNF5 = EcQxOa3RJm86WjTKA.findall('group="(.*?)"',gSUZXf3r57Bzeq,EcQxOa3RJm86WjTKA.DOTALL)
			if iu0zWkDsBmVEcTyKlodC2x9fRZNF5:
				iu0zWkDsBmVEcTyKlodC2x9fRZNF5 = iu0zWkDsBmVEcTyKlodC2x9fRZNF5[0]
				SScDILJytxdsWg7PN = iu0zWkDsBmVEcTyKlodC2x9fRZNF5.split(';')
				if 'region' in uzW1Gnb9y3: X8NdEiakCDSPg1tq = '1_'
				elif 'category' in uzW1Gnb9y3: X8NdEiakCDSPg1tq = '2_'
				elif 'language' in uzW1Gnb9y3: X8NdEiakCDSPg1tq = '3_'
				elif 'country' in uzW1Gnb9y3: X8NdEiakCDSPg1tq = '4_'
				else: X8NdEiakCDSPg1tq = '5_'
				jNeZ3UvXw1x5YJMiWut2PncfGOoCI = gSUZXf3r57Bzeq.replace('group="'+iu0zWkDsBmVEcTyKlodC2x9fRZNF5+'"','group="'+X8NdEiakCDSPg1tq+'~'+n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK+'"')
				WlCm54IqEguKJD.append(jNeZ3UvXw1x5YJMiWut2PncfGOoCI)
				for GMdo5bjPOp1J86VQ4 in SScDILJytxdsWg7PN:
					jNeZ3UvXw1x5YJMiWut2PncfGOoCI = gSUZXf3r57Bzeq.replace('group="'+iu0zWkDsBmVEcTyKlodC2x9fRZNF5+'"','group="'+X8NdEiakCDSPg1tq+GMdo5bjPOp1J86VQ4+'"')
					WlCm54IqEguKJD.append(jNeZ3UvXw1x5YJMiWut2PncfGOoCI)
			else: WlCm54IqEguKJD.append(gSUZXf3r57Bzeq)
		LZhBxTSy4qP7zKIbGw = WlCm54IqEguKJD
		del WlCm54IqEguKJD,XFtKPxOiZWNd5f4l1y3Juq
	Ia8ryCnSUjQuhZ = 1024*1024
	Gv8JV16P3fhIHQwRab = 1+len(ttf2i5eBHVXRd4wN)//Ia8ryCnSUjQuhZ//10
	del ttf2i5eBHVXRd4wN
	VVZlgXOYqorcM3UTivsmf2QtaWAI = len(LZhBxTSy4qP7zKIbGw)
	XFtKPxOiZWNd5f4l1y3Juq = aBU0XMbiZA7sJ(LZhBxTSy4qP7zKIbGw,Gv8JV16P3fhIHQwRab)
	del LZhBxTSy4qP7zKIbGw
	for uYA2DJg3vyzpo8IHnVjZ47s in range(Gv8JV16P3fhIHQwRab):
		Hnrjh7smUIGq3RgDy19CL(KSH2Qq8wdT4GiktV,35+int(5*uYA2DJg3vyzpo8IHnVjZ47s/Gv8JV16P3fhIHQwRab),'تقطيع الملف الرئيسي','الجزء رقم:-',str(uYA2DJg3vyzpo8IHnVjZ47s+1)+' / '+str(Gv8JV16P3fhIHQwRab))
		if KSH2Qq8wdT4GiktV.iscanceled():
			KSH2Qq8wdT4GiktV.close()
			return
		H5CbwxQ4sdPVYDXApRkqcl = str(XFtKPxOiZWNd5f4l1y3Juq[uYA2DJg3vyzpo8IHnVjZ47s])
		if jTDWgftK7NEmx0JAkOn2aRIvweq: H5CbwxQ4sdPVYDXApRkqcl = H5CbwxQ4sdPVYDXApRkqcl.encode(Tk9eH2qw6Brsuhj)
		open(RPxFQKVfJ8539aOwsdtp62yBXAhCS+'.00'+str(uYA2DJg3vyzpo8IHnVjZ47s),'wb').write(H5CbwxQ4sdPVYDXApRkqcl)
	del XFtKPxOiZWNd5f4l1y3Juq,H5CbwxQ4sdPVYDXApRkqcl
	oSw3pT4CuB5RePNDzhGv10VxMZmiX,ppG9q0CtDci,JhvuCHVREPNqU8bomeTcpOzFrw = [],[],0
	for uYA2DJg3vyzpo8IHnVjZ47s in range(Gv8JV16P3fhIHQwRab):
		if KSH2Qq8wdT4GiktV.iscanceled():
			KSH2Qq8wdT4GiktV.close()
			return
		H5CbwxQ4sdPVYDXApRkqcl = open(RPxFQKVfJ8539aOwsdtp62yBXAhCS+'.00'+str(uYA2DJg3vyzpo8IHnVjZ47s),'rb').read()
		uUqrNPcXKBoQ0slv.sleep(1)
		try: HoxKENAey2MdTt9kDUrVnWGLS0CPa.remove(RPxFQKVfJ8539aOwsdtp62yBXAhCS+'.00'+str(uYA2DJg3vyzpo8IHnVjZ47s))
		except: pass
		if jTDWgftK7NEmx0JAkOn2aRIvweq: H5CbwxQ4sdPVYDXApRkqcl = H5CbwxQ4sdPVYDXApRkqcl.decode(Tk9eH2qw6Brsuhj)
		HusCp5YdNhgWk8VL1fRb7Km = LB7TcZnGYdfw5lWU1RH3Oztu9PyA('list',H5CbwxQ4sdPVYDXApRkqcl)
		del H5CbwxQ4sdPVYDXApRkqcl
		R4zwxKcC6785U2FtXMySgElqf,JhvuCHVREPNqU8bomeTcpOzFrw,VBogfjwYHnJe6aN = KG3SNymapwnOi74ejqtRb(HusCp5YdNhgWk8VL1fRb7Km,gRDbOecxwEh4r7q,CHx6dXNmWgV4,KSH2Qq8wdT4GiktV,VVZlgXOYqorcM3UTivsmf2QtaWAI,JhvuCHVREPNqU8bomeTcpOzFrw,uzW1Gnb9y3)
		if KSH2Qq8wdT4GiktV.iscanceled():
			KSH2Qq8wdT4GiktV.close()
			return
		if not R4zwxKcC6785U2FtXMySgElqf:
			KSH2Qq8wdT4GiktV.close()
			return
		ppG9q0CtDci += R4zwxKcC6785U2FtXMySgElqf
		oSw3pT4CuB5RePNDzhGv10VxMZmiX += VBogfjwYHnJe6aN
	del HusCp5YdNhgWk8VL1fRb7Km,R4zwxKcC6785U2FtXMySgElqf
	w136gLc0N5ul8YB,VBogfjwYHnJe6aN = ZKWOcsJV2jxTALGenrpSQgvR(ppG9q0CtDci,KSH2Qq8wdT4GiktV,d5dAoMmGN2V)
	if KSH2Qq8wdT4GiktV.iscanceled():
		KSH2Qq8wdT4GiktV.close()
		return
	oSw3pT4CuB5RePNDzhGv10VxMZmiX += VBogfjwYHnJe6aN
	del ppG9q0CtDci,VBogfjwYHnJe6aN
	P6M9vIpRo1szbujgBxYGycet,Z8hQpS0ATHfwRma29IUFg5,iu0zWkDsBmVEcTyKlodC2x9fRZNF5,ATO0NcGMzZ79IgqR1s3tQnDw,U2zFSIXg8WDqeHTGbpxLr = {},{},{},0,0
	Pr5NRFya4hfgK9QvBmkLOsoAt7 = list(w136gLc0N5ul8YB.keys())
	ttT0n3AbSUL2iCIWOD7E = len(Pr5NRFya4hfgK9QvBmkLOsoAt7)*3
	if 1:
		FyzlktrfAVaOHRDo = {}
		for aXZ2lkohJwr in Pr5NRFya4hfgK9QvBmkLOsoAt7:
			FyzlktrfAVaOHRDo[aXZ2lkohJwr] = YMsWIfu7ojp2t4XJyZN05aC3l(daemon=EsCplGc5N4mBuYW0RVQt6b,target=R5Rdslwh1QPa3qyXbnJYFELS87iZ4,args=(aXZ2lkohJwr,))
			FyzlktrfAVaOHRDo[aXZ2lkohJwr].start()
		for aXZ2lkohJwr in Pr5NRFya4hfgK9QvBmkLOsoAt7:
			FyzlktrfAVaOHRDo[aXZ2lkohJwr].join()
		if KSH2Qq8wdT4GiktV.iscanceled():
			KSH2Qq8wdT4GiktV.close()
			return
	else:
		for aXZ2lkohJwr in Pr5NRFya4hfgK9QvBmkLOsoAt7:
			R5Rdslwh1QPa3qyXbnJYFELS87iZ4(aXZ2lkohJwr)
			if KSH2Qq8wdT4GiktV.iscanceled():
				KSH2Qq8wdT4GiktV.close()
				return
	ykwRfxEFd0v(ZXOQjgueim57H6p1NrCsTyzA,d5dAoMmGN2V,False)
	Pr5NRFya4hfgK9QvBmkLOsoAt7 = list(P6M9vIpRo1szbujgBxYGycet.keys())
	KYRyVXdqWw2huMfCtLmS = 0
	if 1:
		FyzlktrfAVaOHRDo = {}
		for aXZ2lkohJwr in Pr5NRFya4hfgK9QvBmkLOsoAt7:
			FyzlktrfAVaOHRDo[aXZ2lkohJwr] = YMsWIfu7ojp2t4XJyZN05aC3l(daemon=EsCplGc5N4mBuYW0RVQt6b,target=yBCgxoDkdZNE1KzpuqMW75iT2bj,args=(ZXOQjgueim57H6p1NrCsTyzA,aXZ2lkohJwr))
			FyzlktrfAVaOHRDo[aXZ2lkohJwr].start()
		for aXZ2lkohJwr in Pr5NRFya4hfgK9QvBmkLOsoAt7:
			FyzlktrfAVaOHRDo[aXZ2lkohJwr].join()
		if KSH2Qq8wdT4GiktV.iscanceled():
			KSH2Qq8wdT4GiktV.close()
			return
	else:
		for aXZ2lkohJwr in Pr5NRFya4hfgK9QvBmkLOsoAt7:
			yBCgxoDkdZNE1KzpuqMW75iT2bj(ZXOQjgueim57H6p1NrCsTyzA,aXZ2lkohJwr)
			if KSH2Qq8wdT4GiktV.iscanceled():
				KSH2Qq8wdT4GiktV.close()
				return
	uYA2DJg3vyzpo8IHnVjZ47s = 0
	V4VnwMfhGHNK = len(oSw3pT4CuB5RePNDzhGv10VxMZmiX)
	xQuWTvpwISyoGRr73A8Yz = q65BmenP4if3yG2D(ZXOQjgueim57H6p1NrCsTyzA,'IGNORED')
	for MFNPJuUrsEhfdXZj4ienxzYo in oSw3pT4CuB5RePNDzhGv10VxMZmiX:
		if uYA2DJg3vyzpo8IHnVjZ47s%27==0:
			Hnrjh7smUIGq3RgDy19CL(KSH2Qq8wdT4GiktV,95+int(5*uYA2DJg3vyzpo8IHnVjZ47s//V4VnwMfhGHNK),'تخزين المهملة','الفيديو رقم:-',str(uYA2DJg3vyzpo8IHnVjZ47s)+' / '+str(V4VnwMfhGHNK))
			if KSH2Qq8wdT4GiktV.iscanceled():
				KSH2Qq8wdT4GiktV.close()
				return
		tekGV6ob7fqlFjAL4Z(xQuWTvpwISyoGRr73A8Yz,'IGNORED_'+d5dAoMmGN2V,str(MFNPJuUrsEhfdXZj4ienxzYo),fy8iFgEkrO12NR9TWBI35sjY6qHvV,zz2tnLhI1QHV7GwFCrv5)
		uYA2DJg3vyzpo8IHnVjZ47s += 1
	tekGV6ob7fqlFjAL4Z(xQuWTvpwISyoGRr73A8Yz,'IGNORED_'+d5dAoMmGN2V,'__COUNT__',str(V4VnwMfhGHNK),zz2tnLhI1QHV7GwFCrv5)
	KSH2Qq8wdT4GiktV.close()
	uUqrNPcXKBoQ0slv.sleep(1)
	PN79yfYMSuoElUBchqWA5j0L32(ZXOQjgueim57H6p1NrCsTyzA)
	return
def R5Rdslwh1QPa3qyXbnJYFELS87iZ4(aXZ2lkohJwr):
	global KSH2Qq8wdT4GiktV,w136gLc0N5ul8YB,KYRyVXdqWw2huMfCtLmS,P6M9vIpRo1szbujgBxYGycet,Z8hQpS0ATHfwRma29IUFg5,iu0zWkDsBmVEcTyKlodC2x9fRZNF5,ATO0NcGMzZ79IgqR1s3tQnDw,U2zFSIXg8WDqeHTGbpxLr,ttT0n3AbSUL2iCIWOD7E
	P6M9vIpRo1szbujgBxYGycet[aXZ2lkohJwr] = {}
	q1XYKhFbJE8,ccB78gy4NsfSqH = {},[]
	hIKziOPt8ANjSLa = len(w136gLc0N5ul8YB[aXZ2lkohJwr])
	P6M9vIpRo1szbujgBxYGycet[aXZ2lkohJwr]['__COUNT__'] = hIKziOPt8ANjSLa
	if hIKziOPt8ANjSLa>0:
		PMyic4p1R92F,VRf0uxgqsiJSY7H5Omo,YvgEzuXCdm,vEZw0zmpXHgo1yJqnbPNi92BF,qqyO7SDYHJez2 = zip(*w136gLc0N5ul8YB[aXZ2lkohJwr])
		del VRf0uxgqsiJSY7H5Omo,YvgEzuXCdm,vEZw0zmpXHgo1yJqnbPNi92BF
		SScDILJytxdsWg7PN = list(set(PMyic4p1R92F))
		for GMdo5bjPOp1J86VQ4 in SScDILJytxdsWg7PN:
			q1XYKhFbJE8[GMdo5bjPOp1J86VQ4] = fy8iFgEkrO12NR9TWBI35sjY6qHvV
			P6M9vIpRo1szbujgBxYGycet[aXZ2lkohJwr][GMdo5bjPOp1J86VQ4] = []
		Hnrjh7smUIGq3RgDy19CL(KSH2Qq8wdT4GiktV,60+int(15*U2zFSIXg8WDqeHTGbpxLr//ttT0n3AbSUL2iCIWOD7E),'تصنيع القوائم','الجزء رقم:-',str(U2zFSIXg8WDqeHTGbpxLr)+' / '+str(ttT0n3AbSUL2iCIWOD7E))
		if KSH2Qq8wdT4GiktV.iscanceled(): return
		U2zFSIXg8WDqeHTGbpxLr += 1
		XeaB7lbjmMAEx1citpFRYqHTn5V = len(SScDILJytxdsWg7PN)
		del SScDILJytxdsWg7PN
		ccB78gy4NsfSqH = list(set(zip(PMyic4p1R92F,qqyO7SDYHJez2)))
		del PMyic4p1R92F,qqyO7SDYHJez2
		for GMdo5bjPOp1J86VQ4,R87NZgODb1jyuxBAScelVivtP2 in ccB78gy4NsfSqH:
			if not q1XYKhFbJE8[GMdo5bjPOp1J86VQ4] and R87NZgODb1jyuxBAScelVivtP2: q1XYKhFbJE8[GMdo5bjPOp1J86VQ4] = R87NZgODb1jyuxBAScelVivtP2
		Hnrjh7smUIGq3RgDy19CL(KSH2Qq8wdT4GiktV,60+int(15*U2zFSIXg8WDqeHTGbpxLr//ttT0n3AbSUL2iCIWOD7E),'تصنيع القوائم','الجزء رقم:-',str(U2zFSIXg8WDqeHTGbpxLr)+' / '+str(ttT0n3AbSUL2iCIWOD7E))
		if KSH2Qq8wdT4GiktV.iscanceled(): return
		U2zFSIXg8WDqeHTGbpxLr += 1
		SidTV8Flw5aYbyBR21P = list(q1XYKhFbJE8.keys())
		L8c15iX9FlRt7dM3JoaKDhs6qv = list(q1XYKhFbJE8.values())
		del q1XYKhFbJE8
		ccB78gy4NsfSqH = list(zip(SidTV8Flw5aYbyBR21P,L8c15iX9FlRt7dM3JoaKDhs6qv))
		del SidTV8Flw5aYbyBR21P,L8c15iX9FlRt7dM3JoaKDhs6qv
		ccB78gy4NsfSqH = sorted(ccB78gy4NsfSqH)
	else: U2zFSIXg8WDqeHTGbpxLr += 2
	P6M9vIpRo1szbujgBxYGycet[aXZ2lkohJwr]['__GROUPS__'] = ccB78gy4NsfSqH
	del ccB78gy4NsfSqH
	for GMdo5bjPOp1J86VQ4,R5gQk0ZcerYx3B,ljGZCOmnVrtqy8WNHbgx4LEzpYfX,eEncXMVB2rNg4JObl3utYfj,BZylVOjQcDenA4qIC9whT in w136gLc0N5ul8YB[aXZ2lkohJwr]:
		P6M9vIpRo1szbujgBxYGycet[aXZ2lkohJwr][GMdo5bjPOp1J86VQ4].append((R5gQk0ZcerYx3B,ljGZCOmnVrtqy8WNHbgx4LEzpYfX,eEncXMVB2rNg4JObl3utYfj,BZylVOjQcDenA4qIC9whT))
	Hnrjh7smUIGq3RgDy19CL(KSH2Qq8wdT4GiktV,60+int(15*U2zFSIXg8WDqeHTGbpxLr//ttT0n3AbSUL2iCIWOD7E),'تصنيع القوائم','الجزء رقم:-',str(U2zFSIXg8WDqeHTGbpxLr)+' / '+str(ttT0n3AbSUL2iCIWOD7E))
	if KSH2Qq8wdT4GiktV.iscanceled(): return
	U2zFSIXg8WDqeHTGbpxLr += 1
	del w136gLc0N5ul8YB[aXZ2lkohJwr]
	iu0zWkDsBmVEcTyKlodC2x9fRZNF5[aXZ2lkohJwr] = list(P6M9vIpRo1szbujgBxYGycet[aXZ2lkohJwr].keys())
	Z8hQpS0ATHfwRma29IUFg5[aXZ2lkohJwr] = len(iu0zWkDsBmVEcTyKlodC2x9fRZNF5[aXZ2lkohJwr])
	ATO0NcGMzZ79IgqR1s3tQnDw += Z8hQpS0ATHfwRma29IUFg5[aXZ2lkohJwr]
	return
def yBCgxoDkdZNE1KzpuqMW75iT2bj(ZXOQjgueim57H6p1NrCsTyzA,aXZ2lkohJwr):
	global KSH2Qq8wdT4GiktV,w136gLc0N5ul8YB,KYRyVXdqWw2huMfCtLmS,P6M9vIpRo1szbujgBxYGycet,Z8hQpS0ATHfwRma29IUFg5,iu0zWkDsBmVEcTyKlodC2x9fRZNF5,ATO0NcGMzZ79IgqR1s3tQnDw,U2zFSIXg8WDqeHTGbpxLr,ttT0n3AbSUL2iCIWOD7E
	xQuWTvpwISyoGRr73A8Yz = q65BmenP4if3yG2D(ZXOQjgueim57H6p1NrCsTyzA,aXZ2lkohJwr)
	for JhvuCHVREPNqU8bomeTcpOzFrw in range(1+Z8hQpS0ATHfwRma29IUFg5[aXZ2lkohJwr]//273):
		TTcr8jDR6Pxoumi4MXFVNpSOZ53LH = []
		ZIDNkfQb4rmJ0lwcq = iu0zWkDsBmVEcTyKlodC2x9fRZNF5[aXZ2lkohJwr][0:273]
		for GMdo5bjPOp1J86VQ4 in ZIDNkfQb4rmJ0lwcq:
			TTcr8jDR6Pxoumi4MXFVNpSOZ53LH.append(P6M9vIpRo1szbujgBxYGycet[aXZ2lkohJwr][GMdo5bjPOp1J86VQ4])
		tekGV6ob7fqlFjAL4Z(xQuWTvpwISyoGRr73A8Yz,aXZ2lkohJwr,ZIDNkfQb4rmJ0lwcq,TTcr8jDR6Pxoumi4MXFVNpSOZ53LH,zz2tnLhI1QHV7GwFCrv5,True)
		KYRyVXdqWw2huMfCtLmS += len(ZIDNkfQb4rmJ0lwcq)
		Hnrjh7smUIGq3RgDy19CL(KSH2Qq8wdT4GiktV,75+int(20*KYRyVXdqWw2huMfCtLmS//ATO0NcGMzZ79IgqR1s3tQnDw),'تخزين القوائم','القائمة رقم:-',str(KYRyVXdqWw2huMfCtLmS)+' / '+str(ATO0NcGMzZ79IgqR1s3tQnDw))
		if KSH2Qq8wdT4GiktV.iscanceled(): return
		del iu0zWkDsBmVEcTyKlodC2x9fRZNF5[aXZ2lkohJwr][0:273]
	del P6M9vIpRo1szbujgBxYGycet[aXZ2lkohJwr],iu0zWkDsBmVEcTyKlodC2x9fRZNF5[aXZ2lkohJwr],Z8hQpS0ATHfwRma29IUFg5[aXZ2lkohJwr]
	return
def mVnMk5DCWs4btTrULQ(ZXOQjgueim57H6p1NrCsTyzA,d5dAoMmGN2V,dJr5jL4cX7kfIeA21zx=True):
	TAO4U8d1N6lFq0XuYRLgMnK7ByQIC = 'عدد فيديوهات جميع الروابط'
	NNhvDYRmn0IE954wSgCFa = q65BmenP4if3yG2D(ZXOQjgueim57H6p1NrCsTyzA,'LIVE_ORIGINAL_GROUPED')
	l6dmRf8zF0nCHhK = q65BmenP4if3yG2D(ZXOQjgueim57H6p1NrCsTyzA,'VOD_ORIGINAL_GROUPED')
	if d5dAoMmGN2V:
		TAO4U8d1N6lFq0XuYRLgMnK7ByQIC = 'عدد فيديوهات رابط '+rjileqgmIOfLEWHoMz[int(d5dAoMmGN2V)]
		d5dAoMmGN2V = '_'+d5dAoMmGN2V
	V4VnwMfhGHNK = rIhXWK91vRuC(NNhvDYRmn0IE954wSgCFa,'int','IGNORED'+d5dAoMmGN2V,'__COUNT__')
	NuqOGYdAF76KyQJwBIanZ0CsckMH2 = rIhXWK91vRuC(NNhvDYRmn0IE954wSgCFa,'int','LIVE_ORIGINAL_GROUPED'+d5dAoMmGN2V,'__COUNT__')
	oXiM7Q6CTvuYPax = rIhXWK91vRuC(l6dmRf8zF0nCHhK,'int','VOD_ORIGINAL_GROUPED'+d5dAoMmGN2V,'__COUNT__')
	x0M1GfledUwZ9nrs5 = rIhXWK91vRuC(NNhvDYRmn0IE954wSgCFa,'int','LIVE_GROUPED'+d5dAoMmGN2V,'__COUNT__')
	IdqKi9eh1RNf5r2TnyOMxG3Sj7 = rIhXWK91vRuC(NNhvDYRmn0IE954wSgCFa,'int','LIVE_UNKNOWN_GROUPED'+d5dAoMmGN2V,'__COUNT__')
	WeCLGaEOpJbz8u7lN92droY = rIhXWK91vRuC(NNhvDYRmn0IE954wSgCFa,'int','VOD_MOVIES_GROUPED'+d5dAoMmGN2V,'__COUNT__')
	eL0gwhKmGyRXNljz = rIhXWK91vRuC(l6dmRf8zF0nCHhK,'int','VOD_SERIES_GROUPED'+d5dAoMmGN2V,'__COUNT__')
	vews8Rk2q1GK4ZVd = rIhXWK91vRuC(NNhvDYRmn0IE954wSgCFa,'int','VOD_UNKNOWN_GROUPED'+d5dAoMmGN2V,'__COUNT__')
	iu0zWkDsBmVEcTyKlodC2x9fRZNF5 = rIhXWK91vRuC(l6dmRf8zF0nCHhK,'list','VOD_SERIES_GROUPED'+d5dAoMmGN2V,'__GROUPS__')
	dMNEGe8BHRarwgSDpXmFoP7L = []
	for GMdo5bjPOp1J86VQ4,BZylVOjQcDenA4qIC9whT in iu0zWkDsBmVEcTyKlodC2x9fRZNF5:
		zBL4TWbdVhkgy = GMdo5bjPOp1J86VQ4.split('__SERIES__')[1]
		dMNEGe8BHRarwgSDpXmFoP7L.append(zBL4TWbdVhkgy)
	dfc4GFu2DLHeBl6WvXU38b5qjKkThp = len(dMNEGe8BHRarwgSDpXmFoP7L)
	qqvDlN7sSFVGmdOYXjwrWZRyg = int(WeCLGaEOpJbz8u7lN92droY)+int(eL0gwhKmGyRXNljz)+int(vews8Rk2q1GK4ZVd)+int(IdqKi9eh1RNf5r2TnyOMxG3Sj7)+int(x0M1GfledUwZ9nrs5)
	LepOzjBvxVDZ = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	LepOzjBvxVDZ += 'قنوات: '+str(x0M1GfledUwZ9nrs5)
	LepOzjBvxVDZ += '   .   أفلام: '+str(WeCLGaEOpJbz8u7lN92droY)
	LepOzjBvxVDZ += '\nمسلسلات: '+str(dfc4GFu2DLHeBl6WvXU38b5qjKkThp)
	LepOzjBvxVDZ += '   .   حلقات: '+str(eL0gwhKmGyRXNljz)
	LepOzjBvxVDZ += '\nقنوات مجهولة: '+str(IdqKi9eh1RNf5r2TnyOMxG3Sj7)
	LepOzjBvxVDZ += '   .   فيدوهات مجهولة: '+str(vews8Rk2q1GK4ZVd)
	LepOzjBvxVDZ += '\nمجموع القنوات: '+str(NuqOGYdAF76KyQJwBIanZ0CsckMH2)
	LepOzjBvxVDZ += '   .   مجموع الفيديوهات: '+str(oXiM7Q6CTvuYPax)
	LepOzjBvxVDZ += '\n\nمجموع المضافة: '+str(qqvDlN7sSFVGmdOYXjwrWZRyg)
	LepOzjBvxVDZ += '   .   مجموع المهملة: '+str(V4VnwMfhGHNK)
	if dJr5jL4cX7kfIeA21zx: GOnZYxartRwkPqMJFub('center',fy8iFgEkrO12NR9TWBI35sjY6qHvV,TAO4U8d1N6lFq0XuYRLgMnK7ByQIC,LepOzjBvxVDZ)
	Y47ykLv5VmeGhDMXSPTn = LepOzjBvxVDZ.replace('\n\n',C0qrknitpM4Z)
	if not d5dAoMmGN2V: d5dAoMmGN2V = 'All'
	else: d5dAoMmGN2V = d5dAoMmGN2V[1]
	Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,'.\tCounts of M3U videos   Folder: '+ZXOQjgueim57H6p1NrCsTyzA+'   Sequence: '+d5dAoMmGN2V+C0qrknitpM4Z+Y47ykLv5VmeGhDMXSPTn)
	return LepOzjBvxVDZ
def ykwRfxEFd0v(ZXOQjgueim57H6p1NrCsTyzA,d5dAoMmGN2V,dJr5jL4cX7kfIeA21zx=True):
	if dJr5jL4cX7kfIeA21zx:
		P2xUVGmQ3TY1OXK46 = vv7siKgM9IfbCjPNqxXD('center',fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'مسح ملفات M3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if P2xUVGmQ3TY1OXK46!=1: return
		KWb68M15YqePl7TVwinC = gIzb6JN9UW0MnAVB.replace('___','_'+ZXOQjgueim57H6p1NrCsTyzA+'_'+d5dAoMmGN2V)
		try: HoxKENAey2MdTt9kDUrVnWGLS0CPa.remove(KWb68M15YqePl7TVwinC)
		except: pass
	xQuWTvpwISyoGRr73A8Yz = q65BmenP4if3yG2D(ZXOQjgueim57H6p1NrCsTyzA,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	if d5dAoMmGN2V:
		vvZ3jLpbGIxkrRJW8E6CDq4AP0T = []
		for hU1ORk8vqm7sHG in ndDvK6Nf4p5E:
			vvZ3jLpbGIxkrRJW8E6CDq4AP0T.append(hU1ORk8vqm7sHG+'_'+d5dAoMmGN2V)
		gKY2bmAhjzv1qCDpZ876tudHSPwV(xQuWTvpwISyoGRr73A8Yz,'LINK_'+d5dAoMmGN2V)
	else:
		vvZ3jLpbGIxkrRJW8E6CDq4AP0T = ndDvK6Nf4p5E
		gKY2bmAhjzv1qCDpZ876tudHSPwV(xQuWTvpwISyoGRr73A8Yz,'DUMMY')
		gKY2bmAhjzv1qCDpZ876tudHSPwV(xQuWTvpwISyoGRr73A8Yz,'GROUPS')
		gKY2bmAhjzv1qCDpZ876tudHSPwV(xQuWTvpwISyoGRr73A8Yz,'ITEMS')
		gKY2bmAhjzv1qCDpZ876tudHSPwV(xQuWTvpwISyoGRr73A8Yz,'SEARCH')
	gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,'SECTIONS_M3U','SECTIONS_M3U_'+ZXOQjgueim57H6p1NrCsTyzA)
	gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	for aXZ2lkohJwr in vvZ3jLpbGIxkrRJW8E6CDq4AP0T:
		gKY2bmAhjzv1qCDpZ876tudHSPwV(xQuWTvpwISyoGRr73A8Yz,aXZ2lkohJwr)
	ZL2gHRX194IrVYoqcjnT(False)
	PN79yfYMSuoElUBchqWA5j0L32(ZXOQjgueim57H6p1NrCsTyzA)
	if dJr5jL4cX7kfIeA21zx: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
	return
def dt5U3cZpCFGRHDue7a1(ZXOQjgueim57H6p1NrCsTyzA=fy8iFgEkrO12NR9TWBI35sjY6qHvV,dJr5jL4cX7kfIeA21zx=True):
	if ZXOQjgueim57H6p1NrCsTyzA:
		xQuWTvpwISyoGRr73A8Yz = q65BmenP4if3yG2D(str(ZXOQjgueim57H6p1NrCsTyzA),'DUMMY')
		wwufxh1HS5oreOgtW = rIhXWK91vRuC(xQuWTvpwISyoGRr73A8Yz,'str','DUMMY','__DUMMY__')
		if wwufxh1HS5oreOgtW: return True
	else:
		ZXOQjgueim57H6p1NrCsTyzA = '1'
		for aVnK0hTHcBA5OgfYGsQwt1jJi7zUpL in range(1,gaUFPm1MLjDJ2lVecEuYI+1):
			xQuWTvpwISyoGRr73A8Yz = q65BmenP4if3yG2D(str(aVnK0hTHcBA5OgfYGsQwt1jJi7zUpL),'DUMMY')
			wwufxh1HS5oreOgtW = rIhXWK91vRuC(xQuWTvpwISyoGRr73A8Yz,'str','DUMMY','__DUMMY__')
			if wwufxh1HS5oreOgtW: return True
	if dJr5jL4cX7kfIeA21zx:
		ZMwRjaU2tVuJA84kp3oz19OK = 'https://iptv-org.github.io/iptv/index.region.m3u'
		MSRGnLv5o8UFIPOWs6zrk = 'https://iptv-org.github.io/iptv/index.category.m3u'
		sNPS5oJ6URGru84wELyfQe3vm = 'https://iptv-org.github.io/iptv/index.language.m3u'
		jjfTBaqnLGWruSlcbkRzKDU = 'https://iptv-org.github.io/iptv/index.country.m3u'
		XYivECxy9VbsqBjfJS4lRzUTPahd = ZMwRjaU2tVuJA84kp3oz19OK+C0qrknitpM4Z+MSRGnLv5o8UFIPOWs6zrk+C0qrknitpM4Z+sNPS5oJ6URGru84wELyfQe3vm+C0qrknitpM4Z+jjfTBaqnLGWruSlcbkRzKDU
		P2xUVGmQ3TY1OXK46 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','هذه القوائم تحتاج رابط فيديوهات نوعه M3U . وهو متوفر في الإنترنت مجانا . وأيضا تبيعه الشركات المختصة . الموقع أدناه فيه روابط مجانية وهي ليست ملك المبرمج (صاحب هذا البرنامج) . ولا علاقة للمبرمج بمحتوياتها . والمبرمج لا يتحمل أي مسؤولية بسبب استخدام روابط مجانية أو غير مجانية\n'+n0nFOd4yR97fQzNLSW+'http://github.com/iptv-org/iptv'+T7ASIp1ZYwio9HQ8cObJK+'\nالروابط أدناه مجانية ومأخوذة من الموقع أعلاه هل تريد استخدامها\n '+n0nFOd4yR97fQzNLSW+XYivECxy9VbsqBjfJS4lRzUTPahd+T7ASIp1ZYwio9HQ8cObJK,profile='confirm_smallfont')
		if P2xUVGmQ3TY1OXK46==1:
			OdiZIyCfDUsW3JBGR2VAb.setSetting('av.m3u.url_'+str(ZXOQjgueim57H6p1NrCsTyzA)+'_1',ZMwRjaU2tVuJA84kp3oz19OK)
			OdiZIyCfDUsW3JBGR2VAb.setSetting('av.m3u.url_'+str(ZXOQjgueim57H6p1NrCsTyzA)+'_2',MSRGnLv5o8UFIPOWs6zrk)
			OdiZIyCfDUsW3JBGR2VAb.setSetting('av.m3u.url_'+str(ZXOQjgueim57H6p1NrCsTyzA)+'_3',sNPS5oJ6URGru84wELyfQe3vm)
			OdiZIyCfDUsW3JBGR2VAb.setSetting('av.m3u.url_'+str(ZXOQjgueim57H6p1NrCsTyzA)+'_4',jjfTBaqnLGWruSlcbkRzKDU)
			P2xUVGmQ3TY1OXK46 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','للاستفادة من روابط M3U التي أنت أضفتها للبرنامج .. أنت بحاجة إلى جلب ملفات هذه الروابط الجديدة .. هل تريد الآن جلب ملفات روابط M3U التي أنت أضفتها للبرنامج ؟!')
			if P2xUVGmQ3TY1OXK46==1:
				EdTNPLryOxkBbItne9VspSaK2 = adFJgtClIUqVkwpODMWGovNH(ZXOQjgueim57H6p1NrCsTyzA)
				return EdTNPLryOxkBbItne9VspSaK2
		else:
			TAO4U8d1N6lFq0XuYRLgMnK7ByQIC = 'إضافة وتغيير رابط '+rjileqgmIOfLEWHoMz[1]+' (مجلد '+rjileqgmIOfLEWHoMz[int(ZXOQjgueim57H6p1NrCsTyzA)]+')'
			P2xUVGmQ3TY1OXK46 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,TAO4U8d1N6lFq0XuYRLgMnK7ByQIC,'لإضافة رابط M3U .. أولا أفتح قائمة M3U .. وثانيا أنقر على إضافة رابط أو اشتراك M3U .. وثالثا أنقر على جلب ملفات ـM3U \n\n هل تريد إضافة أو تغيير رابط M3U الآن ؟!')
			if P2xUVGmQ3TY1OXK46==1: zX2tLATroY9qi0(ZXOQjgueim57H6p1NrCsTyzA,'1')
	return False
def G5xvzuBVrfdP7eIOAwhW8UQ6Eic4(eBAnxgOqUG,ZXOQjgueim57H6p1NrCsTyzA=fy8iFgEkrO12NR9TWBI35sjY6qHvV,aXZ2lkohJwr=fy8iFgEkrO12NR9TWBI35sjY6qHvV,mEgQCiJ1uw0R3NchtZ=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if not mEgQCiJ1uw0R3NchtZ: mEgQCiJ1uw0R3NchtZ = '1'
	qO85TbiBND0g6G3Iktu7fomVCc,JJnVRkiCSuK1D,dJr5jL4cX7kfIeA21zx = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(eBAnxgOqUG)
	if not dt5U3cZpCFGRHDue7a1(ZXOQjgueim57H6p1NrCsTyzA,dJr5jL4cX7kfIeA21zx): return
	if not qO85TbiBND0g6G3Iktu7fomVCc:
		qO85TbiBND0g6G3Iktu7fomVCc = GFYl1tsoOkHC0Ajeur8JQiMx()
		if not qO85TbiBND0g6G3Iktu7fomVCc: return
	UAP2LNG1MbDk9YXHR4ZJpS = [fy8iFgEkrO12NR9TWBI35sjY6qHvV,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not aXZ2lkohJwr:
		if not dJr5jL4cX7kfIeA21zx:
			if   '_M3U-LIVE_' in JJnVRkiCSuK1D: aXZ2lkohJwr = UAP2LNG1MbDk9YXHR4ZJpS[1]
			elif '_M3U-MOVIES' in JJnVRkiCSuK1D: aXZ2lkohJwr = UAP2LNG1MbDk9YXHR4ZJpS[2]
			elif '_M3U-SERIES' in JJnVRkiCSuK1D: aXZ2lkohJwr = UAP2LNG1MbDk9YXHR4ZJpS[3]
			else: aXZ2lkohJwr = UAP2LNG1MbDk9YXHR4ZJpS[0]
		else:
			XXj4JGTtcW1PboFLE8I3pdzSVM2 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			YYxDRTA76kwZNBqnHSdJ = qYUPXpmOCTk9byoAGKieDQZ8u41J3S('أختر البحث المناسب', XXj4JGTtcW1PboFLE8I3pdzSVM2)
			if YYxDRTA76kwZNBqnHSdJ==-1: return
			aXZ2lkohJwr = UAP2LNG1MbDk9YXHR4ZJpS[YYxDRTA76kwZNBqnHSdJ]
	qO85TbiBND0g6G3Iktu7fomVCc = qO85TbiBND0g6G3Iktu7fomVCc+'_NODIALOGS_'
	if ZXOQjgueim57H6p1NrCsTyzA: olswHav1FmNJYhujfzqrAb2(qO85TbiBND0g6G3Iktu7fomVCc,ZXOQjgueim57H6p1NrCsTyzA,aXZ2lkohJwr,mEgQCiJ1uw0R3NchtZ)
	else:
		for ZXOQjgueim57H6p1NrCsTyzA in range(1,gaUFPm1MLjDJ2lVecEuYI+1):
			olswHav1FmNJYhujfzqrAb2(qO85TbiBND0g6G3Iktu7fomVCc,str(ZXOQjgueim57H6p1NrCsTyzA),aXZ2lkohJwr,mEgQCiJ1uw0R3NchtZ)
		I4t9qonjrm.menuItemsLIST[:] = sorted(I4t9qonjrm.menuItemsLIST,reverse=False,key=lambda ZYo1OtjRwCc2eAlK: ZYo1OtjRwCc2eAlK[1].lower())
	return
def olswHav1FmNJYhujfzqrAb2(eBAnxgOqUG,ZXOQjgueim57H6p1NrCsTyzA,aXZ2lkohJwr=fy8iFgEkrO12NR9TWBI35sjY6qHvV,mEgQCiJ1uw0R3NchtZ=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if not mEgQCiJ1uw0R3NchtZ: mEgQCiJ1uw0R3NchtZ = '1'
	qO85TbiBND0g6G3Iktu7fomVCc,JJnVRkiCSuK1D,dJr5jL4cX7kfIeA21zx = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(eBAnxgOqUG)
	if not ZXOQjgueim57H6p1NrCsTyzA: return
	if not dt5U3cZpCFGRHDue7a1(ZXOQjgueim57H6p1NrCsTyzA,dJr5jL4cX7kfIeA21zx): return
	if not qO85TbiBND0g6G3Iktu7fomVCc:
		qO85TbiBND0g6G3Iktu7fomVCc = GFYl1tsoOkHC0Ajeur8JQiMx()
		if not qO85TbiBND0g6G3Iktu7fomVCc: return
	UAP2LNG1MbDk9YXHR4ZJpS = [fy8iFgEkrO12NR9TWBI35sjY6qHvV,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not aXZ2lkohJwr:
		if not dJr5jL4cX7kfIeA21zx:
			if   '_M3U-LIVE_' in JJnVRkiCSuK1D: aXZ2lkohJwr = UAP2LNG1MbDk9YXHR4ZJpS[1]
			elif '_M3U-MOVIES' in JJnVRkiCSuK1D: aXZ2lkohJwr = UAP2LNG1MbDk9YXHR4ZJpS[2]
			elif '_M3U-SERIES' in JJnVRkiCSuK1D: aXZ2lkohJwr = UAP2LNG1MbDk9YXHR4ZJpS[3]
			else: aXZ2lkohJwr = UAP2LNG1MbDk9YXHR4ZJpS[0]
		else:
			XXj4JGTtcW1PboFLE8I3pdzSVM2 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			YYxDRTA76kwZNBqnHSdJ = qYUPXpmOCTk9byoAGKieDQZ8u41J3S('أختر البحث المناسب', XXj4JGTtcW1PboFLE8I3pdzSVM2)
			if YYxDRTA76kwZNBqnHSdJ==-1: return
			aXZ2lkohJwr = UAP2LNG1MbDk9YXHR4ZJpS[YYxDRTA76kwZNBqnHSdJ]
	EEDzFSbowjIOy5QR = qO85TbiBND0g6G3Iktu7fomVCc.lower()
	xQuWTvpwISyoGRr73A8Yz = q65BmenP4if3yG2D(ZXOQjgueim57H6p1NrCsTyzA,'SEARCH')
	J5eBhfvXYF20DAOqs7L8l3KaR1 = rIhXWK91vRuC(xQuWTvpwISyoGRr73A8Yz,'list','SEARCH',(aXZ2lkohJwr,EEDzFSbowjIOy5QR))
	if not J5eBhfvXYF20DAOqs7L8l3KaR1:
		utZDBW4kJ6K5b,pTXzsfYKvcR3loqMtAj = [],[]
		if not aXZ2lkohJwr: UuCIPROe09GLMqmpStAlhJVQci = [1,2,3,4,5]
		else: UuCIPROe09GLMqmpStAlhJVQci = [UAP2LNG1MbDk9YXHR4ZJpS.index(aXZ2lkohJwr)]
		for uYA2DJg3vyzpo8IHnVjZ47s in UuCIPROe09GLMqmpStAlhJVQci:
			if uYA2DJg3vyzpo8IHnVjZ47s!=3:
				R4zwxKcC6785U2FtXMySgElqf = rIhXWK91vRuC(xQuWTvpwISyoGRr73A8Yz,'dict',UAP2LNG1MbDk9YXHR4ZJpS[uYA2DJg3vyzpo8IHnVjZ47s])
				del R4zwxKcC6785U2FtXMySgElqf['__COUNT__']
				del R4zwxKcC6785U2FtXMySgElqf['__GROUPS__']
				del R4zwxKcC6785U2FtXMySgElqf['__SEQUENCED_COLUMNS__']
				iu0zWkDsBmVEcTyKlodC2x9fRZNF5 = list(R4zwxKcC6785U2FtXMySgElqf.keys())
				for GMdo5bjPOp1J86VQ4 in iu0zWkDsBmVEcTyKlodC2x9fRZNF5:
					for R5gQk0ZcerYx3B,ljGZCOmnVrtqy8WNHbgx4LEzpYfX,eEncXMVB2rNg4JObl3utYfj,BZylVOjQcDenA4qIC9whT in R4zwxKcC6785U2FtXMySgElqf[GMdo5bjPOp1J86VQ4]:
						if EEDzFSbowjIOy5QR in ljGZCOmnVrtqy8WNHbgx4LEzpYfX.lower(): pTXzsfYKvcR3loqMtAj.append((ljGZCOmnVrtqy8WNHbgx4LEzpYfX,eEncXMVB2rNg4JObl3utYfj,BZylVOjQcDenA4qIC9whT))
					del R4zwxKcC6785U2FtXMySgElqf[GMdo5bjPOp1J86VQ4]
				del R4zwxKcC6785U2FtXMySgElqf
			else: iu0zWkDsBmVEcTyKlodC2x9fRZNF5 = rIhXWK91vRuC(xQuWTvpwISyoGRr73A8Yz,'list',UAP2LNG1MbDk9YXHR4ZJpS[uYA2DJg3vyzpo8IHnVjZ47s],'__GROUPS__')
			for GMdo5bjPOp1J86VQ4 in iu0zWkDsBmVEcTyKlodC2x9fRZNF5:
				try: GMdo5bjPOp1J86VQ4,BZylVOjQcDenA4qIC9whT = GMdo5bjPOp1J86VQ4
				except: BZylVOjQcDenA4qIC9whT = fy8iFgEkrO12NR9TWBI35sjY6qHvV
				if EEDzFSbowjIOy5QR in GMdo5bjPOp1J86VQ4.lower():
					if uYA2DJg3vyzpo8IHnVjZ47s!=3: OdYqf2HE0PjrB = GMdo5bjPOp1J86VQ4
					else:
						tFhD42YAK7l9IbSvzr3dqLpTsy,JHNy2MZsRhUpYP8BV6F9nkc = GMdo5bjPOp1J86VQ4.split('__SERIES__')
						if EEDzFSbowjIOy5QR in tFhD42YAK7l9IbSvzr3dqLpTsy.lower(): OdYqf2HE0PjrB = tFhD42YAK7l9IbSvzr3dqLpTsy
						else: OdYqf2HE0PjrB = JHNy2MZsRhUpYP8BV6F9nkc
					utZDBW4kJ6K5b.append((GMdo5bjPOp1J86VQ4,OdYqf2HE0PjrB,UAP2LNG1MbDk9YXHR4ZJpS[uYA2DJg3vyzpo8IHnVjZ47s],BZylVOjQcDenA4qIC9whT))
			del iu0zWkDsBmVEcTyKlodC2x9fRZNF5
		utZDBW4kJ6K5b = set(utZDBW4kJ6K5b)
		pTXzsfYKvcR3loqMtAj = set(pTXzsfYKvcR3loqMtAj)
		utZDBW4kJ6K5b = sorted(utZDBW4kJ6K5b,reverse=False,key=lambda ZYo1OtjRwCc2eAlK: ZYo1OtjRwCc2eAlK[1])
		pTXzsfYKvcR3loqMtAj = sorted(pTXzsfYKvcR3loqMtAj,reverse=False,key=lambda ZYo1OtjRwCc2eAlK: ZYo1OtjRwCc2eAlK[0])
		tekGV6ob7fqlFjAL4Z(xQuWTvpwISyoGRr73A8Yz,'SEARCH',(aXZ2lkohJwr,EEDzFSbowjIOy5QR),(utZDBW4kJ6K5b,pTXzsfYKvcR3loqMtAj),zz2tnLhI1QHV7GwFCrv5)
	else: utZDBW4kJ6K5b,pTXzsfYKvcR3loqMtAj = J5eBhfvXYF20DAOqs7L8l3KaR1
	iu0zWkDsBmVEcTyKlodC2x9fRZNF5 = len(utZDBW4kJ6K5b)
	kp6y9JUQW8jqi = len(pTXzsfYKvcR3loqMtAj)
	yy7dsVqg23CI5tbjXlwWmOe = int(mEgQCiJ1uw0R3NchtZ)
	UMZelEX29JzBAdYbf = max(0,(yy7dsVqg23CI5tbjXlwWmOe-1)*100)
	nhA0JUQ3EjHReSKuM9GoWI = max(0,yy7dsVqg23CI5tbjXlwWmOe*100)
	AonUqicMWVLxj7pNsbQfgwr59XFu43 = max(0,UMZelEX29JzBAdYbf-iu0zWkDsBmVEcTyKlodC2x9fRZNF5)
	dqxZ2oYOGXyB = max(0,nhA0JUQ3EjHReSKuM9GoWI-iu0zWkDsBmVEcTyKlodC2x9fRZNF5)
	for GMdo5bjPOp1J86VQ4,OdYqf2HE0PjrB,efZzocWCdOGN0H,BZylVOjQcDenA4qIC9whT in utZDBW4kJ6K5b[UMZelEX29JzBAdYbf:nhA0JUQ3EjHReSKuM9GoWI]:
		OZD1l4pAMzeH('folder',RTUaJZyvOuDA83So7M+OdYqf2HE0PjrB,efZzocWCdOGN0H,714,BZylVOjQcDenA4qIC9whT,'1',GMdo5bjPOp1J86VQ4,fy8iFgEkrO12NR9TWBI35sjY6qHvV,{'folder':ZXOQjgueim57H6p1NrCsTyzA})
	del utZDBW4kJ6K5b
	for ljGZCOmnVrtqy8WNHbgx4LEzpYfX,eEncXMVB2rNg4JObl3utYfj,BZylVOjQcDenA4qIC9whT in pTXzsfYKvcR3loqMtAj[AonUqicMWVLxj7pNsbQfgwr59XFu43:dqxZ2oYOGXyB]:
		BuS3kWrDoC01aMY5jvTPm = ml1bXR85BJyhPAVvQY(eEncXMVB2rNg4JObl3utYfj)
		ppi24CwDdH3YzVIK8BUyLluQJEMW = 'live'
		if '.mkv' in BuS3kWrDoC01aMY5jvTPm or 'VOD' in aXZ2lkohJwr: ppi24CwDdH3YzVIK8BUyLluQJEMW = 'video'
		OZD1l4pAMzeH(ppi24CwDdH3YzVIK8BUyLluQJEMW,RTUaJZyvOuDA83So7M+ljGZCOmnVrtqy8WNHbgx4LEzpYfX,eEncXMVB2rNg4JObl3utYfj,715,BZylVOjQcDenA4qIC9whT,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,{'folder':ZXOQjgueim57H6p1NrCsTyzA})
	del pTXzsfYKvcR3loqMtAj
	s2OC3m9qin8aegVSEPvZlH4Tro(ZXOQjgueim57H6p1NrCsTyzA,mEgQCiJ1uw0R3NchtZ,aXZ2lkohJwr,719,iu0zWkDsBmVEcTyKlodC2x9fRZNF5+kp6y9JUQW8jqi,qO85TbiBND0g6G3Iktu7fomVCc+'_NODIALOGS_')
	return
def s2OC3m9qin8aegVSEPvZlH4Tro(ZXOQjgueim57H6p1NrCsTyzA,mEgQCiJ1uw0R3NchtZ,aXZ2lkohJwr,hO3D6GVPY2qENv8bZWH,qqvDlN7sSFVGmdOYXjwrWZRyg,YMaiHbnIThsP7q):
	if not mEgQCiJ1uw0R3NchtZ: mEgQCiJ1uw0R3NchtZ = '1'
	if mEgQCiJ1uw0R3NchtZ!='1': OZD1l4pAMzeH('folder',RTUaJZyvOuDA83So7M+'صفحة '+str(1),aXZ2lkohJwr,hO3D6GVPY2qENv8bZWH,fy8iFgEkrO12NR9TWBI35sjY6qHvV,str(1),YMaiHbnIThsP7q,fy8iFgEkrO12NR9TWBI35sjY6qHvV,{'folder':ZXOQjgueim57H6p1NrCsTyzA})
	if not qqvDlN7sSFVGmdOYXjwrWZRyg: qqvDlN7sSFVGmdOYXjwrWZRyg = 0
	uAZy7VeWcvNkDRbM0EH = int(qqvDlN7sSFVGmdOYXjwrWZRyg/100)+1
	for yy7dsVqg23CI5tbjXlwWmOe in range(2,uAZy7VeWcvNkDRbM0EH):
		PPbYGzF24mZO3i5 = (yy7dsVqg23CI5tbjXlwWmOe%10==0 or int(mEgQCiJ1uw0R3NchtZ)-4<yy7dsVqg23CI5tbjXlwWmOe<int(mEgQCiJ1uw0R3NchtZ)+4)
		QQXADTwEskeoVcM6pYOr8dvZL1Ixy = (PPbYGzF24mZO3i5 and int(mEgQCiJ1uw0R3NchtZ)-40<yy7dsVqg23CI5tbjXlwWmOe<int(mEgQCiJ1uw0R3NchtZ)+40)
		if str(yy7dsVqg23CI5tbjXlwWmOe)!=mEgQCiJ1uw0R3NchtZ and (yy7dsVqg23CI5tbjXlwWmOe%100==0 or QQXADTwEskeoVcM6pYOr8dvZL1Ixy):
			OZD1l4pAMzeH('folder',RTUaJZyvOuDA83So7M+'صفحة '+str(yy7dsVqg23CI5tbjXlwWmOe),aXZ2lkohJwr,hO3D6GVPY2qENv8bZWH,fy8iFgEkrO12NR9TWBI35sjY6qHvV,str(yy7dsVqg23CI5tbjXlwWmOe),YMaiHbnIThsP7q,fy8iFgEkrO12NR9TWBI35sjY6qHvV,{'folder':ZXOQjgueim57H6p1NrCsTyzA})
	if str(uAZy7VeWcvNkDRbM0EH)!=mEgQCiJ1uw0R3NchtZ: OZD1l4pAMzeH('folder',RTUaJZyvOuDA83So7M+'أخر صفحة '+str(uAZy7VeWcvNkDRbM0EH),aXZ2lkohJwr,hO3D6GVPY2qENv8bZWH,fy8iFgEkrO12NR9TWBI35sjY6qHvV,str(uAZy7VeWcvNkDRbM0EH),YMaiHbnIThsP7q,fy8iFgEkrO12NR9TWBI35sjY6qHvV,{'folder':ZXOQjgueim57H6p1NrCsTyzA})
	return
def q65BmenP4if3yG2D(ZXOQjgueim57H6p1NrCsTyzA,aXZ2lkohJwr):
	xQuWTvpwISyoGRr73A8Yz = XW2achsgu8UljFobiyBevJk5IrpxH.replace('___','_'+ZXOQjgueim57H6p1NrCsTyzA)
	return xQuWTvpwISyoGRr73A8Yz
def adFJgtClIUqVkwpODMWGovNH(ZXOQjgueim57H6p1NrCsTyzA):
	xQuWTvpwISyoGRr73A8Yz = q65BmenP4if3yG2D(ZXOQjgueim57H6p1NrCsTyzA,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	P2xUVGmQ3TY1OXK46 = vv7siKgM9IfbCjPNqxXD('center',fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','جلب ملفات M3U جديدة قد تحتاج عدة دقائق .. هل تريد أن تجلب الملفات الآن ؟!')
	if P2xUVGmQ3TY1OXK46!=1: return False
	L8ISmMEnWx1tkNCK5ZRHQwJz(ZXOQjgueim57H6p1NrCsTyzA,False)
	AANRfDXbrFo = [0]
	for gLoUCe7WqVp in range(1,U08BAYfcpVrC3tzaFyG7gOWilKohL+1):
		Dle3w7YFbxTSKzMRnviW4UrdVg = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.m3u.url_'+ZXOQjgueim57H6p1NrCsTyzA+'_'+str(gLoUCe7WqVp))
		if Dle3w7YFbxTSKzMRnviW4UrdVg: si0SUOvWrnoqm9KpL(ZXOQjgueim57H6p1NrCsTyzA,str(gLoUCe7WqVp))
		AANRfDXbrFo.append(0)
	for aXZ2lkohJwr in ndDvK6Nf4p5E:
		Y0Y8vRjrVS3nGQdsgFTipD6xelO2,cVO43lA0KFsHtXu,COq1JoldGyWzRpSHf5DwLkP3eXUIY,T7BrlXEP1dOo9IJUV,q1XYKhFbJE8 = 0,{},[],[],[]
		for gLoUCe7WqVp in range(1,U08BAYfcpVrC3tzaFyG7gOWilKohL+1):
			efZzocWCdOGN0H = aXZ2lkohJwr+'_'+str(gLoUCe7WqVp)
			w136gLc0N5ul8YB = rIhXWK91vRuC(xQuWTvpwISyoGRr73A8Yz,'dict',efZzocWCdOGN0H)
			try:
				b0icxKFLa9RHEt34WzSAmBvIh = w136gLc0N5ul8YB['__GROUPS__']
				C37Q0bmsoJ8F4cvEXTikg = w136gLc0N5ul8YB['__COUNT__']
			except: b0icxKFLa9RHEt34WzSAmBvIh,C37Q0bmsoJ8F4cvEXTikg = [],'0'
			for wKx8U0bqZztsS4J in b0icxKFLa9RHEt34WzSAmBvIh:
				GMdo5bjPOp1J86VQ4,R87NZgODb1jyuxBAScelVivtP2 = wKx8U0bqZztsS4J
				R4zwxKcC6785U2FtXMySgElqf = w136gLc0N5ul8YB[GMdo5bjPOp1J86VQ4]
				if GMdo5bjPOp1J86VQ4 not in T7BrlXEP1dOo9IJUV:
					T7BrlXEP1dOo9IJUV.append(GMdo5bjPOp1J86VQ4)
					q1XYKhFbJE8.append(wKx8U0bqZztsS4J)
					cVO43lA0KFsHtXu[GMdo5bjPOp1J86VQ4] = []
				cVO43lA0KFsHtXu[GMdo5bjPOp1J86VQ4] += R4zwxKcC6785U2FtXMySgElqf
			gKY2bmAhjzv1qCDpZ876tudHSPwV(xQuWTvpwISyoGRr73A8Yz,efZzocWCdOGN0H)
			tekGV6ob7fqlFjAL4Z(xQuWTvpwISyoGRr73A8Yz,efZzocWCdOGN0H,'__COUNT__',C37Q0bmsoJ8F4cvEXTikg,zz2tnLhI1QHV7GwFCrv5)
			AANRfDXbrFo[gLoUCe7WqVp] += int(C37Q0bmsoJ8F4cvEXTikg)
		for GMdo5bjPOp1J86VQ4 in T7BrlXEP1dOo9IJUV:
			R4zwxKcC6785U2FtXMySgElqf = list(set(cVO43lA0KFsHtXu[GMdo5bjPOp1J86VQ4]))
			if 'SORTED' in aXZ2lkohJwr: R4zwxKcC6785U2FtXMySgElqf = sorted(R4zwxKcC6785U2FtXMySgElqf,reverse=False,key=lambda key: key[1].lower())
			Y0Y8vRjrVS3nGQdsgFTipD6xelO2 += len(R4zwxKcC6785U2FtXMySgElqf)
			COq1JoldGyWzRpSHf5DwLkP3eXUIY.append(R4zwxKcC6785U2FtXMySgElqf)
		tekGV6ob7fqlFjAL4Z(xQuWTvpwISyoGRr73A8Yz,aXZ2lkohJwr,'__COUNT__',str(Y0Y8vRjrVS3nGQdsgFTipD6xelO2),zz2tnLhI1QHV7GwFCrv5)
		tekGV6ob7fqlFjAL4Z(xQuWTvpwISyoGRr73A8Yz,aXZ2lkohJwr,'__GROUPS__',q1XYKhFbJE8,zz2tnLhI1QHV7GwFCrv5)
		tekGV6ob7fqlFjAL4Z(xQuWTvpwISyoGRr73A8Yz,aXZ2lkohJwr,T7BrlXEP1dOo9IJUV,COq1JoldGyWzRpSHf5DwLkP3eXUIY,zz2tnLhI1QHV7GwFCrv5,True)
	NqIAo6K0buBxj8pm92FatdnORXH = False
	for gLoUCe7WqVp in range(1,U08BAYfcpVrC3tzaFyG7gOWilKohL+1):
		if int(AANRfDXbrFo[gLoUCe7WqVp])>0:
			Dle3w7YFbxTSKzMRnviW4UrdVg = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.m3u.url_'+ZXOQjgueim57H6p1NrCsTyzA+'_'+str(gLoUCe7WqVp))
			tekGV6ob7fqlFjAL4Z(xQuWTvpwISyoGRr73A8Yz,'LINK_'+str(gLoUCe7WqVp),'__LINK__',Dle3w7YFbxTSKzMRnviW4UrdVg,zz2tnLhI1QHV7GwFCrv5)
			NqIAo6K0buBxj8pm92FatdnORXH = True
	tekGV6ob7fqlFjAL4Z(xQuWTvpwISyoGRr73A8Yz,'DUMMY','__DUMMY__','DUMMY',zz2tnLhI1QHV7GwFCrv5)
	if not NqIAo6K0buBxj8pm92FatdnORXH:
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','فشل بسحب ملفات M3U .. أحتمال روابط M3U التي أنت أضفتها للبرنامج غير صحيحة .. علما أن هذه الخدمة تحتاج منك أن تضيف الرابط بنفسك للبرنامج باستخدام قائمة M3U الموجودة في هذا البرنامج')
		return False
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','تم جلب ملفات M3U جديدة')
	ffUZ928IdwQRJcsm4Y1pnGztqve6iP(ZXOQjgueim57H6p1NrCsTyzA)
	ZL2gHRX194IrVYoqcjnT(False)
	ejX7kGtQ4hcYUHW9b31vriuZLM6Sp(False)
	return True
def ffUZ928IdwQRJcsm4Y1pnGztqve6iP(ZXOQjgueim57H6p1NrCsTyzA):
	xQuWTvpwISyoGRr73A8Yz = q65BmenP4if3yG2D(ZXOQjgueim57H6p1NrCsTyzA,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	if not dt5U3cZpCFGRHDue7a1(ZXOQjgueim57H6p1NrCsTyzA,True): return
	for gLoUCe7WqVp in range(1,U08BAYfcpVrC3tzaFyG7gOWilKohL+1):
		Dle3w7YFbxTSKzMRnviW4UrdVg = rIhXWK91vRuC(xQuWTvpwISyoGRr73A8Yz,'str','LINK_'+str(gLoUCe7WqVp),'__LINK__')
		if Dle3w7YFbxTSKzMRnviW4UrdVg: LepOzjBvxVDZ = mVnMk5DCWs4btTrULQ(ZXOQjgueim57H6p1NrCsTyzA,str(gLoUCe7WqVp))
	mVnMk5DCWs4btTrULQ(ZXOQjgueim57H6p1NrCsTyzA,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	return
def L8ISmMEnWx1tkNCK5ZRHQwJz(ZXOQjgueim57H6p1NrCsTyzA,dJr5jL4cX7kfIeA21zx):
	if dJr5jL4cX7kfIeA21zx:
		P2xUVGmQ3TY1OXK46 = vv7siKgM9IfbCjPNqxXD('center',fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'مسح ملفات ـM3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if P2xUVGmQ3TY1OXK46!=1: return
	xQuWTvpwISyoGRr73A8Yz = q65BmenP4if3yG2D(ZXOQjgueim57H6p1NrCsTyzA,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	try: HoxKENAey2MdTt9kDUrVnWGLS0CPa.remove(xQuWTvpwISyoGRr73A8Yz)
	except: pass
	for gLoUCe7WqVp in range(1,U08BAYfcpVrC3tzaFyG7gOWilKohL+1):
		ZYvoT3WE7aCg5s = gIzb6JN9UW0MnAVB.replace('___','_'+ZXOQjgueim57H6p1NrCsTyzA+'_'+str(gLoUCe7WqVp))
		mWR17lgVLxJMn2UpF6cqdfkI4XHza = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(Xsc4lqOhdziToWvunbRNSQZKIY8E,ZYvoT3WE7aCg5s)
		try: HoxKENAey2MdTt9kDUrVnWGLS0CPa.remove(mWR17lgVLxJMn2UpF6cqdfkI4XHza)
		except: pass
	gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,'SECTIONS_M3U','SECTIONS_M3U_'+ZXOQjgueim57H6p1NrCsTyzA)
	gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	if dJr5jL4cX7kfIeA21zx:
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
		ejX7kGtQ4hcYUHW9b31vriuZLM6Sp(False)
	return
def PN79yfYMSuoElUBchqWA5j0L32(ZXOQjgueim57H6p1NrCsTyzA):
	hymL4GSEtnpD = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.language.provider')
	B9BCJXUkFHPIxvr2s0Of5LA = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.language.code')
	gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,'MENUS_CACHE_'+hymL4GSEtnpD+'_'+B9BCJXUkFHPIxvr2s0Of5LA,'%_MU'+ZXOQjgueim57H6p1NrCsTyzA+'_%')
	return
gJAHdfID9Pj = {
		 'AF':'Afghanistan'
		,'AL':'Albania'
		,'DZ':'Algeria'
		,'AS':'American Samoa'
		,'AD':'Andorra'
		,'AO':'Angola'
		,'AI':'Anguilla'
		,'AQ':'Antarctica'
		,'AG':'Antigua and Barbuda'
		,'AR':'Argentina'
		,'AM':'Armenia'
		,'AW':'Aruba'
		,'AU':'Australia'
		,'AT':'Austria'
		,'AZ':'Azerbaijan'
		,'BS':'Bahamas'
		,'BH':'Bahrain'
		,'BD':'Bangladesh'
		,'BB':'Barbados'
		,'BY':'Belarus'
		,'BE':'Belgium'
		,'BZ':'Belize'
		,'BJ':'Benin'
		,'BM':'Bermuda'
		,'BT':'Bhutan'
		,'BO':'Bolivia'
		,'BQ':'Bonaire'
		,'BA':'Bosnia and Herzegovina'
		,'BW':'Botswana'
		,'BV':'Bouvet Island'
		,'BR':'Brazil'
		,'IO':'British Indian Ocean Territory'
		,'VG':'British Virgin Islands'
		,'BN':'Brunei'
		,'BG':'Bulgaria'
		,'BF':'Burkina Faso'
		,'BI':'Burundi'
		,'KH':'Cambodia'
		,'CM':'Cameroon'
		,'CA':'Canada'
		,'CV':'Cape Verde'
		,'KY':'Cayman Islands'
		,'CF':'Central African Republic'
		,'TD':'Chad'
		,'CL':'Chile'
		,'CN':'China'
		,'CX':'Christmas Island'
		,'CC':'Cocos (Keeling) Islands'
		,'CO':'Colombia'
		,'KM':'Comoros'
		,'CK':'Cook Islands'
		,'CR':'Costa Rica'
		,'HR':'Croatia'
		,'CU':'Cuba'
		,'CW':'Curacao'
		,'CY':'Cyprus'
		,'CZ':'Czech Republic'
		,'CD':'Democratic Republic of the Congo'
		,'DK':'Denmark'
		,'DJ':'Djibouti'
		,'DM':'Dominica'
		,'DO':'Dominican Republic'
		,'TL':'East Timor'
		,'EC':'Ecuador'
		,'EG':'Egypt'
		,'SV':'El Salvador'
		,'GQ':'Equatorial Guinea'
		,'ER':'Eritrea'
		,'EE':'Estonia'
		,'ET':'Ethiopia'
		,'FK':'Falkland Islands'
		,'FO':'Faroe Islands'
		,'FJ':'Fiji'
		,'FI':'Finland'
		,'FR':'France'
		,'GF':'French Guiana'
		,'PF':'French Polynesia'
		,'TF':'French Southern Territories'
		,'GA':'Gabon'
		,'GM':'Gambia'
		,'GE':'Georgia'
		,'DE':'Germany'
		,'GH':'Ghana'
		,'GI':'Gibraltar'
		,'GR':'Greece'
		,'GL':'Greenland'
		,'GD':'Grenada'
		,'GP':'Guadeloupe'
		,'GU':'Guam'
		,'GT':'Guatemala'
		,'GG':'Guernsey'
		,'GN':'Guinea'
		,'GW':'Guinea-Bissau'
		,'GY':'Guyana'
		,'HT':'Haiti'
		,'HM':'Heard Island and McDonald Islands'
		,'HN':'Honduras'
		,'HK':'Hong Kong'
		,'HU':'Hungary'
		,'IS':'Iceland'
		,'IN':'India'
		,'ID':'Indonesia'
		,'IR':'Iran'
		,'IQ':'Iraq'
		,'IE':'Ireland'
		,'IM':'Isle of Man'
		,'IL':'Israel'
		,'IT':'Italy'
		,'CI':'Ivory Coast'
		,'JM':'Jamaica'
		,'JP':'Japan'
		,'JE':'Jersey'
		,'JO':'Jordan'
		,'KZ':'Kazakhstan'
		,'KE':'Kenya'
		,'KI':'Kiribati'
		,'XK':'Kosovo'
		,'KW':'Kuwait'
		,'KG':'Kyrgyzstan'
		,'LA':'Laos'
		,'LV':'Latvia'
		,'LB':'Lebanon'
		,'LS':'Lesotho'
		,'LR':'Liberia'
		,'LY':'Libya'
		,'LI':'Liechtenstein'
		,'LT':'Lithuania'
		,'LU':'Luxembourg'
		,'MO':'Macao'
		,'MG':'Madagascar'
		,'MW':'Malawi'
		,'MY':'Malaysia'
		,'MV':'Maldives'
		,'ML':'Mali'
		,'MT':'Malta'
		,'MH':'Marshall Islands'
		,'MQ':'Martinique'
		,'MR':'Mauritania'
		,'MU':'Mauritius'
		,'YT':'Mayotte'
		,'MX':'Mexico'
		,'FM':'Micronesia'
		,'MD':'Moldova'
		,'MC':'Monaco'
		,'MN':'Mongolia'
		,'ME':'Montenegro'
		,'MS':'Montserrat'
		,'MA':'Morocco'
		,'MZ':'Mozambique'
		,'MM':'Myanmar (Burma)'
		,'NA':'Namibia'
		,'NR':'Nauru'
		,'NP':'Nepal'
		,'NL':'Netherlands'
		,'NC':'New Caledonia'
		,'NZ':'New Zealand'
		,'NI':'Nicaragua'
		,'NE':'Niger'
		,'NG':'Nigeria'
		,'NU':'Niue'
		,'NF':'Norfolk Island'
		,'KP':'North Korea'
		,'MK':'North Macedonia'
		,'MP':'Northern Mariana Islands'
		,'NO':'Norway'
		,'OM':'Oman'
		,'PK':'Pakistan'
		,'PW':'Palau'
		,'PS':'Palestine'
		,'PA':'Panama'
		,'PG':'Papua New Guinea'
		,'PY':'Paraguay'
		,'PE':'Peru'
		,'PH':'Philippines'
		,'PN':'Pitcairn Islands'
		,'PL':'Poland'
		,'PT':'Portugal'
		,'PR':'Puerto Rico'
		,'QA':'Qatar'
		,'CG':'Republic of the Congo'
		,'RO':'Romania'
		,'RU':'Russia'
		,'RW':'Rwanda'
		,'RE':'Réunion'
		,'BL':'Saint Barthélemy'
		,'SH':'Saint Helena'
		,'KN':'Saint Kitts and Nevis'
		,'LC':'Saint Lucia'
		,'MF':'Saint Martin'
		,'PM':'Saint Pierre and Miquelon'
		,'VC':'Saint Vincent and the Grenadines'
		,'WS':'Samoa'
		,'SM':'San Marino'
		,'SA':'Saudi Arabia'
		,'SN':'Senegal'
		,'RS':'Serbia'
		,'SC':'Seychelles'
		,'SL':'Sierra Leone'
		,'SG':'Singapore'
		,'SX':'Sint Maarten'
		,'SK':'Slovakia'
		,'SI':'Slovenia'
		,'SB':'Solomon Islands'
		,'SO':'Somalia'
		,'ZA':'South Africa'
		,'GS':'South Georgia and the South Sandwich Islands'
		,'KR':'South Korea'
		,'SS':'South Sudan'
		,'ES':'Spain'
		,'LK':'Sri Lanka'
		,'SD':'Sudan'
		,'SR':'Suriname'
		,'SJ':'Svalbard and Jan Mayen'
		,'SZ':'Swaziland'
		,'SE':'Sweden'
		,'CH':'Switzerland'
		,'SY':'Syria'
		,'ST':'São Tomé and Príncipe'
		,'TW':'Taiwan'
		,'TJ':'Tajikistan'
		,'TZ':'Tanzania'
		,'TH':'Thailand'
		,'TG':'Togo'
		,'TK':'Tokelau'
		,'TO':'Tonga'
		,'TT':'Trinidad and Tobago'
		,'TN':'Tunisia'
		,'TR':'Turkey'
		,'TM':'Turkmenistan'
		,'TC':'Turks and Caicos Islands'
		,'TV':'Tuvalu'
		,'UM':'U.S. Minor Outlying Islands'
		,'VI':'U.S. Virgin Islands'
		,'UG':'Uganda'
		,'UA':'Ukraine'
		,'AE':'United Arab Emirates'
		,'UK':'United Kingdom'
		,'US':'United States'
		,'UY':'Uruguay'
		,'UZ':'Uzbekistan'
		,'VU':'Vanuatu'
		,'VA':'Vatican City'
		,'VE':'Venezuela'
		,'VN':'Vietnam'
		,'WF':'Wallis and Futuna'
		,'EH':'Western Sahara'
		,'YE':'Yemen'
		,'ZM':'Zambia'
		,'ZW':'Zimbabwe'
		,'AX':'Åland'
		}
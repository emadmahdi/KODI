# -*- coding: utf-8 -*-
import sys as CfgZ0zWP5XBpoGQwLUY
D5DpyO2wPg7oL = CfgZ0zWP5XBpoGQwLUY.version_info [0] == 2
ccK5HIyfUgvOdQpWSXZtaBJ = 2048
W8WuBTGQg1Zwqy5F6xSe = 7
def zmQcCUZlPKBITW5bqx1 (rR5FPU8VhJQ):
	global Jfz4wMWSZb0BYV
	EEr5teuZbc = ord (rR5FPU8VhJQ [-1])
	ZZd5W9FVUhzu31NQyComxv = rR5FPU8VhJQ [:-1]
	sJYFyd6mZHev1IXEaMj0b = EEr5teuZbc % len (ZZd5W9FVUhzu31NQyComxv)
	qPJ7pUnt5rcm6NMaFYLSkHsGxI = ZZd5W9FVUhzu31NQyComxv [:sJYFyd6mZHev1IXEaMj0b] + ZZd5W9FVUhzu31NQyComxv [sJYFyd6mZHev1IXEaMj0b:]
	if D5DpyO2wPg7oL:
		Vv1b9fdEckNepm7 = unicode () .join ([unichr (ord (QdqoKlFn4yZUOJp1xYrNTaBSmt69hc) - ccK5HIyfUgvOdQpWSXZtaBJ - (hrazDC5q4oB + EEr5teuZbc) % W8WuBTGQg1Zwqy5F6xSe) for hrazDC5q4oB, QdqoKlFn4yZUOJp1xYrNTaBSmt69hc in enumerate (qPJ7pUnt5rcm6NMaFYLSkHsGxI)])
	else:
		Vv1b9fdEckNepm7 = str () .join ([chr (ord (QdqoKlFn4yZUOJp1xYrNTaBSmt69hc) - ccK5HIyfUgvOdQpWSXZtaBJ - (hrazDC5q4oB + EEr5teuZbc) % W8WuBTGQg1Zwqy5F6xSe) for hrazDC5q4oB, QdqoKlFn4yZUOJp1xYrNTaBSmt69hc in enumerate (qPJ7pUnt5rcm6NMaFYLSkHsGxI)])
	return eval (Vv1b9fdEckNepm7)
V3z5t4JAqyXk2fLsW1juoZ0BEp6,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye,wdftVMyzF17cYETHu=zmQcCUZlPKBITW5bqx1,zmQcCUZlPKBITW5bqx1,zmQcCUZlPKBITW5bqx1
Hr25gta6XcqO,FmYoGejTnwKME7d9zPc,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9=wdftVMyzF17cYETHu,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye,V3z5t4JAqyXk2fLsW1juoZ0BEp6
KfHAW8VGbrxi,aOQTKXFL54Nl60Zhp3MbE,jL5CrsRwebpyDVXUc1EQP=Dco0w1e5VM3YP7hLXTHBS8GtaCrO9,FmYoGejTnwKME7d9zPc,Hr25gta6XcqO
oRJAfwD957WkUyBM1Ehu8m,vU6DxuzPwMpg,I18uSKaWhgTBeYUPD4sr=jL5CrsRwebpyDVXUc1EQP,aOQTKXFL54Nl60Zhp3MbE,KfHAW8VGbrxi
o1INZ3ViQqS0Uw5z6kMjbv,s5WMHyQN4mpie,N6NGJ4vpmidqMCh7yo=I18uSKaWhgTBeYUPD4sr,vU6DxuzPwMpg,oRJAfwD957WkUyBM1Ehu8m
Gcw2nelTR864XCVruO3mAFqI5a,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7,OO9YiAQHGrLo0qpW2M3jDeXd1kx=N6NGJ4vpmidqMCh7yo,s5WMHyQN4mpie,o1INZ3ViQqS0Uw5z6kMjbv
O3OVuapf0YFjbm5oUQDg,sJw9QWiq1Kr0xfeVRI,SnhLjmfeJC=OO9YiAQHGrLo0qpW2M3jDeXd1kx,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7,Gcw2nelTR864XCVruO3mAFqI5a
QjAINyUC7MDRq5d8e4vl9,AAbvaXV2DQzfNHdm4U3tT,ggjO5CrKVRPITaesWkxD=SnhLjmfeJC,sJw9QWiq1Kr0xfeVRI,O3OVuapf0YFjbm5oUQDg
FgXzMs0YSDt,uulNDCPyef78,EQxFuqjw95WvaMm8Hnlt47XVihJ=ggjO5CrKVRPITaesWkxD,AAbvaXV2DQzfNHdm4U3tT,QjAINyUC7MDRq5d8e4vl9
ssynAg0zhSkoCpOMDV9,sIzDXlTHYUC5L3xZGnr,PlpyFa9QMKXxOD1cvHzmI=EQxFuqjw95WvaMm8Hnlt47XVihJ,uulNDCPyef78,FgXzMs0YSDt
CsDcLqQUVK4YBvHFW1,EE1jeHnIoad,LYIgTBeSmZWotDh4bnyQkvM50siu=PlpyFa9QMKXxOD1cvHzmI,sIzDXlTHYUC5L3xZGnr,ssynAg0zhSkoCpOMDV9
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = ggjO5CrKVRPITaesWkxD(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭੅")
def ugbnmWCrLpG9Av0xzocFaB5ew(hO3D6GVPY2qENv8bZWH,eEncXMVB2rNg4JObl3utYfj):
	if   hO3D6GVPY2qENv8bZWH==OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠷࠸࠶૘"): OmsWt89dSA5HyCZ4wL = Vdh2Bjq6A3tiw()
	elif hO3D6GVPY2qENv8bZWH==sJw9QWiq1Kr0xfeVRI(u"࠸࠹࠱૙"): OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(eEncXMVB2rNg4JObl3utYfj)
	elif hO3D6GVPY2qENv8bZWH==CsDcLqQUVK4YBvHFW1(u"࠹࠳࠳૚"): OmsWt89dSA5HyCZ4wL = tjM7Kf5ZqUVNoc8zag()
	elif hO3D6GVPY2qENv8bZWH==uulNDCPyef78(u"࠳࠴࠵૛"): OmsWt89dSA5HyCZ4wL = nny3pwLQzuTgWJaCdbXKE()
	else: OmsWt89dSA5HyCZ4wL = LhFAGlQ19zr
	return OmsWt89dSA5HyCZ4wL
def rr7SfotkneX85Klup(eEncXMVB2rNg4JObl3utYfj):
	E7HR1ZcMuzUs9XCVrNGJYi(eEncXMVB2rNg4JObl3utYfj,BfWYUAnyg6eONLjiuE,oRJAfwD957WkUyBM1Ehu8m(u"ࠬࡼࡩࡥࡧࡲࠫ੆"))
	return
def nny3pwLQzuTgWJaCdbXKE():
	kf40tulvSA7z9RqNF5dXca3seMD = I18uSKaWhgTBeYUPD4sr(u"࠭รั้หࠤส๊้ࠡำสฬ฼ࠦวๅใํำ๏๎ࠠฤ๊ࠣห้฻่หࠢไ๎ࠥอไๆ๊ๅ฽ࠥอไๆู็์อࠦหๆࠢฦฺ฿฽ฺࠠๆ์ࠤืืࠠศๆๅหห๋ษࠡษ็๎๊๐ๆࠡอ่ࠤศิสศำࠣࠦฯำๅ๋ๆ้้ࠣ็วหࠢไ๎ิ๐่ࠣࠢฮ้ࠥอฮหษิࠤิ่ษࠡษ็ูํืษ๊ࠡสาฯอั่๋ࠡ฽๋ࠥไโࠢสฺ่๎ัส๋ࠢฬ฾ี็ศࠢึ์ๆ๊ࠦษัฦࠤฬ๊สฮ็ํ่ࠬੇ")
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QjAINyUC7MDRq5d8e4vl9(u"ุࠧำํๆฮࠦสฮ็ํ่ࠥอไๆๆไหฯ࠭ੈ"),kf40tulvSA7z9RqNF5dXca3seMD)
	return
def Vdh2Bjq6A3tiw():
	OZD1l4pAMzeH(KfHAW8VGbrxi(u"ࠨ࡮࡬ࡲࡰ࠭੉"),n0nFOd4yR97fQzNLSW+sIzDXlTHYUC5L3xZGnr(u"ฺࠩี๏่ษࠡฬะ้๏๊ࠠๆๆไหฯࠦวๅใํำ๏๎ࠧ੊")+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠴࠵࠶૜"))
	OZD1l4pAMzeH(EE1jeHnIoad(u"ࠪࡰ࡮ࡴ࡫ࠨੋ"),n0nFOd4yR97fQzNLSW+EE1jeHnIoad(u"ࠫฯเ๊๋ำ้่ࠣอๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠫੌ")+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠵࠶࠶૝"))
	OZD1l4pAMzeH(jL5CrsRwebpyDVXUc1EQP(u"ࠬࡲࡩ࡯࡭੍ࠪ"),n0nFOd4yR97fQzNLSW+ggjO5CrKVRPITaesWkxD(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬ੎")+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,oRJAfwD957WkUyBM1Ehu8m(u"࠼࠽࠾࠿૞"))
	bvAWytBjsO = XCQ4JU5IO3MisuDLonPaq()
	i250NeOyWLVhj4o3HG1tZ = HoxKENAey2MdTt9kDUrVnWGLS0CPa.stat(bvAWytBjsO).st_mtime
	sTjfJ91McWaNYk7hmlDAQtIe8 = []
	if jTDWgftK7NEmx0JAkOn2aRIvweq: zmQE2U86AKJ = HoxKENAey2MdTt9kDUrVnWGLS0CPa.listdir(bvAWytBjsO.encode(Tk9eH2qw6Brsuhj))
	else: zmQE2U86AKJ = HoxKENAey2MdTt9kDUrVnWGLS0CPa.listdir(bvAWytBjsO.decode(Tk9eH2qw6Brsuhj))
	for ZYvoT3WE7aCg5s in zmQE2U86AKJ:
		if jTDWgftK7NEmx0JAkOn2aRIvweq: ZYvoT3WE7aCg5s = ZYvoT3WE7aCg5s.decode(Tk9eH2qw6Brsuhj)
		if not ZYvoT3WE7aCg5s.startswith(FgXzMs0YSDt(u"ࠧࡧ࡫࡯ࡩࡤ࠭੏")): continue
		gPJOqsBDX5TIFfVwbCk7LEhWt = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(bvAWytBjsO,ZYvoT3WE7aCg5s)
		i250NeOyWLVhj4o3HG1tZ = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.getmtime(gPJOqsBDX5TIFfVwbCk7LEhWt)
		sTjfJ91McWaNYk7hmlDAQtIe8.append([ZYvoT3WE7aCg5s,i250NeOyWLVhj4o3HG1tZ])
	sTjfJ91McWaNYk7hmlDAQtIe8 = sorted(sTjfJ91McWaNYk7hmlDAQtIe8,reverse=EsCplGc5N4mBuYW0RVQt6b,key=lambda key: key[BkM54Kr7Qbqn])
	for ZYvoT3WE7aCg5s,i250NeOyWLVhj4o3HG1tZ in sTjfJ91McWaNYk7hmlDAQtIe8:
		if gZlSEJaXO9F461AL3sR7rWNpqf:
			try: ZYvoT3WE7aCg5s = ZYvoT3WE7aCg5s.decode(Tk9eH2qw6Brsuhj)
			except: pass
			ZYvoT3WE7aCg5s = ZYvoT3WE7aCg5s.encode(Tk9eH2qw6Brsuhj)
		gPJOqsBDX5TIFfVwbCk7LEhWt = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(bvAWytBjsO,ZYvoT3WE7aCg5s)
		OZD1l4pAMzeH(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠨࡸ࡬ࡨࡪࡵࠧ੐"),ZYvoT3WE7aCg5s,gPJOqsBDX5TIFfVwbCk7LEhWt,N6NGJ4vpmidqMCh7yo(u"࠷࠸࠷૟"))
	return
def XCQ4JU5IO3MisuDLonPaq():
	bvAWytBjsO = OdiZIyCfDUsW3JBGR2VAb.getSetting(s5WMHyQN4mpie(u"ࠩࡤࡺ࠳ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡱࡣࡷ࡬ࠬੑ"))
	if bvAWytBjsO: return bvAWytBjsO
	OdiZIyCfDUsW3JBGR2VAb.setSetting(FgXzMs0YSDt(u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭੒"),Xsc4lqOhdziToWvunbRNSQZKIY8E)
	return Xsc4lqOhdziToWvunbRNSQZKIY8E
def tjM7Kf5ZqUVNoc8zag():
	bvAWytBjsO = XCQ4JU5IO3MisuDLonPaq()
	fdaiFCJXN67WrzS4w = vv7siKgM9IfbCjPNqxXD(N6NGJ4vpmidqMCh7yo(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ੓"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,wdftVMyzF17cYETHu(u"๋ࠬใศ่ࠣฮำุ๊็่่ࠢๆอสࠡษ็ฮา๋๊ๅࠩ੔"),WydpaVx5YmLoCiIgA34eEBlb+bvAWytBjsO+T7ASIp1ZYwio9HQ8cObJK+LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠭࡜࡯࡞ࡱ๋ีอ่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะอๆๆ๊หࠥอๆหࠢหหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠣ࠲ࠥํไࠡฬิ๎ิࠦส฻์ํีࠥอไๆๅส๊ࠥลࠧ੕"))
	if fdaiFCJXN67WrzS4w==Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠶ૠ"):
		u52b3dL8tkPj = kkXUMFtcVYWZjDdseS(PlpyFa9QMKXxOD1cvHzmI(u"࠹ૡ"),EE1jeHnIoad(u"ࠧๆๅส๊ࠥะอๆ์็ࠤ๊๊แศฬࠣห้็๊ะ์๋ࠫ੖"),ssynAg0zhSkoCpOMDV9(u"ࠨ࡮ࡲࡧࡦࡲࠧ੗"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,LhFAGlQ19zr,EsCplGc5N4mBuYW0RVQt6b,bvAWytBjsO)
		Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(sJw9QWiq1Kr0xfeVRI(u"ࠩࡦࡩࡳࡺࡥࡳࠩ੘"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,O3OVuapf0YFjbm5oUQDg(u"้่ࠪอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅฬะ้๏๊ࠧਖ਼"),WydpaVx5YmLoCiIgA34eEBlb+bvAWytBjsO+T7ASIp1ZYwio9HQ8cObJK+PlpyFa9QMKXxOD1cvHzmI(u"ࠫࡡࡴ࡜࡯้ำหࠥํ่ࠡษ็้่อๆࠡษ็ะิ๐ฯࠡๆอาื๐ๆࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสฮ็็๋ฬࠦว็ฬࠣฬฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠤ࠳ࠦ็ๅࠢอี๏ีࠠศีอาิอๅ่ࠢหำ้อࠠๆ่ࠣห้๋ใศ่ࠣห้่ฯ๋็ࠣรࠬਗ਼"))
		if Scj7zgGFVA83otMpwUkxhm0BLN1==FgXzMs0YSDt(u"࠱ૢ"):
			OdiZIyCfDUsW3JBGR2VAb.setSetting(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠬࡧࡶ࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴࡦࡺࡨࠨਜ਼"),u52b3dL8tkPj)
			GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Hr25gta6XcqO(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩੜ"),s5WMHyQN4mpie(u"ࠧห็ࠣฮ฿๐๊า่ࠢ็ฬ์ࠠหะี๎๋ࠦวๅ็็ๅฬะࠠศๆ่ั๊๊ษࠨ੝"))
	return
def U8yuQWrbv4Y9qwtzlSj(eEncXMVB2rNg4JObl3utYfj,f5t4sb7BER=fy8iFgEkrO12NR9TWBI35sjY6qHvV,website=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+SnhLjmfeJC(u"ࠨࠢࠣࠤࡕࡸࡥࡱࡣࡵ࡭ࡳ࡭ࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨਫ਼")+eEncXMVB2rNg4JObl3utYfj+OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠩࠣࡡࠬ੟"))
	if not f5t4sb7BER: f5t4sb7BER = ml1bXR85BJyhPAVvQY(eEncXMVB2rNg4JObl3utYfj)
	bvAWytBjsO = XCQ4JU5IO3MisuDLonPaq()
	DDVFlXjdHQsc5nfigO1wPReZSU46 = bNHEp28wg51k(LhFAGlQ19zr)
	ZYvoT3WE7aCg5s = DDVFlXjdHQsc5nfigO1wPReZSU46.replace(ksJdoFWhxTz8Y2N7bOZE,sJw9QWiq1Kr0xfeVRI(u"ࠪࡣࠬ੠"))
	ZYvoT3WE7aCg5s = KaUrpGJVDF470YloiwbH69tqmXyuOT(ZYvoT3WE7aCg5s)
	ZYvoT3WE7aCg5s = LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠫ࡫࡯࡬ࡦࡡࠪ੡")+str(int(VySKdWnH3vNq6klQ))[-sIzDXlTHYUC5L3xZGnr(u"࠵ૣ"):]+Gcw2nelTR864XCVruO3mAFqI5a(u"ࠬࡥࠧ੢")+ZYvoT3WE7aCg5s+f5t4sb7BER
	zCOFIge6wnjrHtqQvaiA15P8Wob4NX = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(bvAWytBjsO,ZYvoT3WE7aCg5s)
	LUvCxj6fMlnyEcDAahbgpH = {}
	LUvCxj6fMlnyEcDAahbgpH[vU6DxuzPwMpg(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ੣")] = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	LUvCxj6fMlnyEcDAahbgpH[oRJAfwD957WkUyBM1Ehu8m(u"ࠧࡂࡥࡦࡩࡵࡺࠧ੤")] = SnhLjmfeJC(u"ࠨࠬ࠲࠮ࠬ੥")
	eEncXMVB2rNg4JObl3utYfj = eEncXMVB2rNg4JObl3utYfj.replace(ssynAg0zhSkoCpOMDV9(u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠬ੦"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	if wdftVMyzF17cYETHu(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨ੧") in eEncXMVB2rNg4JObl3utYfj:
		YLKFRH6sSIrznXBg,ll7qCX4wJ5kQonVW6KtcMuZGSvDEs = eEncXMVB2rNg4JObl3utYfj.rsplit(FmYoGejTnwKME7d9zPc(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩ੨"),PlpyFa9QMKXxOD1cvHzmI(u"࠳૤"))
		ll7qCX4wJ5kQonVW6KtcMuZGSvDEs = ll7qCX4wJ5kQonVW6KtcMuZGSvDEs.replace(FmYoGejTnwKME7d9zPc(u"ࠬࢂࠧ੩"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(EE1jeHnIoad(u"࠭ࠦࠨ੪"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	else: YLKFRH6sSIrznXBg,ll7qCX4wJ5kQonVW6KtcMuZGSvDEs = eEncXMVB2rNg4JObl3utYfj,None
	if not ll7qCX4wJ5kQonVW6KtcMuZGSvDEs: ll7qCX4wJ5kQonVW6KtcMuZGSvDEs = j4lUV5BzHDI6EN()
	if ll7qCX4wJ5kQonVW6KtcMuZGSvDEs: LUvCxj6fMlnyEcDAahbgpH[aOQTKXFL54Nl60Zhp3MbE(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ੫")] = ll7qCX4wJ5kQonVW6KtcMuZGSvDEs
	if O3OVuapf0YFjbm5oUQDg(u"ࠨࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ੬") in YLKFRH6sSIrznXBg: YLKFRH6sSIrznXBg,V6gGYKEO8UqQZ = YLKFRH6sSIrznXBg.rsplit(sJw9QWiq1Kr0xfeVRI(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ੭"),sIzDXlTHYUC5L3xZGnr(u"࠴૥"))
	else: YLKFRH6sSIrznXBg,V6gGYKEO8UqQZ = YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg.strip(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪࢀࠬ੮")).strip(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠫࠫ࠭੯")).strip(oRJAfwD957WkUyBM1Ehu8m(u"ࠬࢂࠧੰ")).strip(N6NGJ4vpmidqMCh7yo(u"࠭ࠦࠨੱ"))
	V6gGYKEO8UqQZ = V6gGYKEO8UqQZ.replace(O3OVuapf0YFjbm5oUQDg(u"ࠧࡽࠩੲ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠨࠨࠪੳ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	if V6gGYKEO8UqQZ:	LUvCxj6fMlnyEcDAahbgpH[Hr25gta6XcqO(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪੴ")] = V6gGYKEO8UqQZ
	Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+sJw9QWiq1Kr0xfeVRI(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫੵ")+YLKFRH6sSIrznXBg+aOQTKXFL54Nl60Zhp3MbE(u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧ੶")+str(LUvCxj6fMlnyEcDAahbgpH)+sJw9QWiq1Kr0xfeVRI(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬ੷")+zCOFIge6wnjrHtqQvaiA15P8Wob4NX+ssynAg0zhSkoCpOMDV9(u"࠭ࠠ࡞ࠩ੸"))
	J4NbqW35lrQnFhDZ0w = Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠵࠵࠸࠴૦")*Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠵࠵࠸࠴૦")
	LEpfGOn1wWiyI0eVZNklgR4 = au4qM5fhJ3lC()//J4NbqW35lrQnFhDZ0w
	if not LEpfGOn1wWiyI0eVZNklgR4:
		cFjMEShi6Pp0otRBgeXq8(CsDcLqQUVK4YBvHFW1(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭੹"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨ็ึหาฯࠠศๆอาื๐ๆࠡ็ฯ๋ํ๊ษࠨ੺"),Hr25gta6XcqO(u"ࠩ็่ศูแࠡษ็ฬึ์วๆฮࠣ฾๏ืࠠใษาีࠥษๆࠡ์ะำิࠦๅใัสี๋ࠥำศฯฬࠤฬ๊สฯิํ๊ࠥอไโษิ฾ฮࠦแ๋ࠢฯ๋ฬุใ๊ࠡ฼่๏ํࠠโษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠠๅ่ࠣ๎฾๋ไࠡ฻้ำ่ࠦลๅ๋ࠣว๋๊ࠦใ๊่ࠤ๊ฮัๆฮํࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢหั้ࠦ็ั้ࠣห้๋ิไๆฬࠤ้อๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠤ็ี๋ࠠีหฬࠥอๅหๆสลࠥา็ศิๆࠤออไๆๆไหฯ่่ࠦาสࠤๆ๐็ࠡะฺ์ึฯฺࠠๆ์ࠤ฾๋ไࠡฮ๊หื้ࠠษื๋ีฮࠦีฮ์ะอࠥ๎ไ่าสࠤฬ๊ำษสࠣๆฬ๋ࠠศๆ่ฬึ๋ฬࠡ็วๆฯอࠠษ็้฽ࠥอไษำ้ห๊าࠠๆ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯ࠭੻"),O3OVuapf0YFjbm5oUQDg(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭੼"))
		Clc8sIj97ZrThF(P3PazFblmtN,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠫࠥࠦࠠࡖࡰࡤࡦࡱ࡫ࠠࡵࡱࠣࡨࡪࡺࡥࡳ࡯࡬ࡲࡪࠦࡴࡩࡧࠣࡨ࡮ࡹ࡫ࠡࡨࡵࡩࡪࠦࡳࡱࡣࡦࡩࠬ੽"))
		return LhFAGlQ19zr
	if f5t4sb7BER==N6NGJ4vpmidqMCh7yo(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ੾"):
		WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = kDKwn73e02jNdRLG8U4HxTgpVQqI(BfWYUAnyg6eONLjiuE,YLKFRH6sSIrznXBg,LUvCxj6fMlnyEcDAahbgpH)
		if len(WFlpmsYGKNy)==o1INZ3ViQqS0Uw5z6kMjbv(u"࠵૧"):
			a6rVSjDMF87KyYINcuOP1l40Hbp(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠭แีๆࠣๅ๏ࠦล๋ฮสำ๋ࠥไโࠢส่ฯำๅ๋ๆࠪ੿"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			return LhFAGlQ19zr
		elif len(WFlpmsYGKNy)==FgXzMs0YSDt(u"࠷૨"): yNqzFDjKM0SrO = AAbvaXV2DQzfNHdm4U3tT(u"࠰૩")
		elif len(WFlpmsYGKNy)>O3OVuapf0YFjbm5oUQDg(u"࠲૪"):
			yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S(N6NGJ4vpmidqMCh7yo(u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬ઀"), WFlpmsYGKNy)
			if yNqzFDjKM0SrO == -CsDcLqQUVK4YBvHFW1(u"࠳૫") :
				a6rVSjDMF87KyYINcuOP1l40Hbp(sJw9QWiq1Kr0xfeVRI(u"ࠨฬ่ࠤสฺ๊ศรࠣห้ะอๆ์็ࠫઁ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
				return LhFAGlQ19zr
		YLKFRH6sSIrznXBg = XoSyx7p6dqZ1CF8[yNqzFDjKM0SrO]
	SoVCEij7l9zgO3L2 = wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠳૬")
	import requests as dgMhO3f7oA
	if f5t4sb7BER==sIzDXlTHYUC5L3xZGnr(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨં"):
		zCOFIge6wnjrHtqQvaiA15P8Wob4NX = zCOFIge6wnjrHtqQvaiA15P8Wob4NX.rsplit(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩઃ"))[D2D96X5NGamBhrFwvL8VEbqiSfZIl]+FgXzMs0YSDt(u"ࠫ࠳ࡳࡰ࠵ࠩ઄")
		I7jcKisuTt = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,Hr25gta6XcqO(u"ࠬࡍࡅࡕࠩઅ"),YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LUvCxj6fMlnyEcDAahbgpH,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,jL5CrsRwebpyDVXUc1EQP(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄ࠮ࡆࡒ࡛ࡓࡒࡏࡂࡆࡢ࡚ࡎࡊࡅࡐ࠯࠴ࡷࡹ࠭આ"))
		gPzsxH1WOBvGiwNqCQ = I7jcKisuTt.content
		zzECVswWcGAIXhrQlZ7jMokugnv = EcQxOa3RJm86WjTKA.findall(sIzDXlTHYUC5L3xZGnr(u"ࠧࠤࡇ࡛ࡘࡎࡔࡆ࠻࠰࠭ࡃࡠࡢ࡮࡝ࡴࡠࠬ࠳࠰࠿ࠪ࡝࡟ࡲࡡࡸ࡝ࠨઇ"),gPzsxH1WOBvGiwNqCQ+FgXzMs0YSDt(u"ࠨ࡞ࡱࡠࡷ࠭ઈ"),EcQxOa3RJm86WjTKA.DOTALL)
		if not zzECVswWcGAIXhrQlZ7jMokugnv:
			Clc8sIj97ZrThF(P3PazFblmtN,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩࠣࠤ࡚ࠥࡨࡦࠢࡰ࠷ࡺ࠾ࠠࡧ࡫࡯ࡩࠥࡪࡩࡥࠢࡱࡳࡹࠦࡨࡢࡸࡨࠤࡹ࡮ࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࡦࠣࡰ࡮ࡴ࡫ࡴࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬઉ")+YLKFRH6sSIrznXBg+vU6DxuzPwMpg(u"ࠪࠤࡢ࠭ઊ"))
			return LhFAGlQ19zr
		bigdh7fpZYl4aT2keV = zzECVswWcGAIXhrQlZ7jMokugnv[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		if not bigdh7fpZYl4aT2keV.startswith(FgXzMs0YSDt(u"ࠫ࡭ࡺࡴࡱࠩઋ")):
			if bigdh7fpZYl4aT2keV.startswith(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠬ࠵࠯ࠨઌ")): bigdh7fpZYl4aT2keV = YLKFRH6sSIrznXBg.split(KfHAW8VGbrxi(u"࠭࠺ࠨઍ"),PlpyFa9QMKXxOD1cvHzmI(u"࠵૭"))[D2D96X5NGamBhrFwvL8VEbqiSfZIl]+jL5CrsRwebpyDVXUc1EQP(u"ࠧ࠻ࠩ઎")+bigdh7fpZYl4aT2keV
			elif bigdh7fpZYl4aT2keV.startswith(EE1jeHnIoad(u"ࠨ࠱ࠪએ")): bigdh7fpZYl4aT2keV = VbHeOuU1ilzSp2ZRXwBD(YLKFRH6sSIrznXBg,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩࡸࡶࡱ࠭ઐ"))+bigdh7fpZYl4aT2keV
			else: bigdh7fpZYl4aT2keV = YLKFRH6sSIrznXBg.rsplit(vU6DxuzPwMpg(u"ࠪ࠳ࠬઑ"),EE1jeHnIoad(u"࠶૮"))[D2D96X5NGamBhrFwvL8VEbqiSfZIl]+oRJAfwD957WkUyBM1Ehu8m(u"ࠫ࠴࠭઒")+bigdh7fpZYl4aT2keV
		I7jcKisuTt = dgMhO3f7oA.request(QjAINyUC7MDRq5d8e4vl9(u"ࠬࡍࡅࡕࠩઓ"),bigdh7fpZYl4aT2keV,headers=LUvCxj6fMlnyEcDAahbgpH,verify=LhFAGlQ19zr)
		A8qfiDE1a5lG49SRhZP6ejztuICm = I7jcKisuTt.content
		l3K7wrHSWUikTP8V = len(A8qfiDE1a5lG49SRhZP6ejztuICm)
		nJi7mefc8wVCIt3DyxHY5kTW4Gap = len(zzECVswWcGAIXhrQlZ7jMokugnv)
		SoVCEij7l9zgO3L2 = l3K7wrHSWUikTP8V*nJi7mefc8wVCIt3DyxHY5kTW4Gap
	else:
		l3K7wrHSWUikTP8V = s5WMHyQN4mpie(u"࠷૯")*J4NbqW35lrQnFhDZ0w
		I7jcKisuTt = dgMhO3f7oA.request(Hr25gta6XcqO(u"࠭ࡇࡆࡖࠪઔ"),YLKFRH6sSIrznXBg,headers=LUvCxj6fMlnyEcDAahbgpH,verify=LhFAGlQ19zr,stream=EsCplGc5N4mBuYW0RVQt6b)
		if O3OVuapf0YFjbm5oUQDg(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨક") in I7jcKisuTt.headers: SoVCEij7l9zgO3L2 = int(I7jcKisuTt.headers[ssynAg0zhSkoCpOMDV9(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩખ")])
		nJi7mefc8wVCIt3DyxHY5kTW4Gap = int(SoVCEij7l9zgO3L2//l3K7wrHSWUikTP8V)
	J4By1CWSu27N5vbEX6V = int(SoVCEij7l9zgO3L2//J4NbqW35lrQnFhDZ0w)+QjAINyUC7MDRq5d8e4vl9(u"࠱૰")
	if SoVCEij7l9zgO3L2<Gcw2nelTR864XCVruO3mAFqI5a(u"࠳࠳࠳࠴࠵૱"):
		Clc8sIj97ZrThF(P3PazFblmtN,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢ࡬ࡷࠥࡺ࡯ࡰࠢࡶࡱࡦࡲ࡬ࠡࡱࡵࠤ࡮ࡺࠠࡪࡵࠣࡱ࠸ࡻ࠸࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫગ")+YLKFRH6sSIrznXBg+wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧઘ")+str(J4By1CWSu27N5vbEX6V)+ggjO5CrKVRPITaesWkxD(u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡇࡶࡢ࡫࡯ࡥࡧࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪઙ")+str(LEpfGOn1wWiyI0eVZNklgR4)+N6NGJ4vpmidqMCh7yo(u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨચ")+zCOFIge6wnjrHtqQvaiA15P8Wob4NX+SnhLjmfeJC(u"࠭ࠠ࡞ࠩછ"))
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪજ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠨใื่ࠥ็๊ࠡ็฼ีๆฯࠠฮฮ่ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠢฦ์ࠥอไๆๆไࠤฺเ๊าࠢฯำฬ่ࠦๅ้ำห๊ࠥวࠡ์่็๋ࠦไๅสิ๊ฬ๋ฬࠡฬะ้๏๊่ࠠาสࠤฬ๊ๅๅใࠪઝ"))
		return LhFAGlQ19zr
	wwfyxpEkiMr = oRJAfwD957WkUyBM1Ehu8m(u"࠶࠳࠴૲")
	GhJjoHF9EqUABp = LEpfGOn1wWiyI0eVZNklgR4-J4By1CWSu27N5vbEX6V
	if GhJjoHF9EqUABp<wwfyxpEkiMr:
		Clc8sIj97ZrThF(P3PazFblmtN,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠩࠣࠤࠥࡔ࡯ࡵࠢࡨࡲࡴࡻࡧࡩࠢࡧ࡭ࡸࡱࠠࡴࡲࡤࡧࡪࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡹ࡮ࡥࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨઞ")+YLKFRH6sSIrznXBg+vU6DxuzPwMpg(u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧટ")+str(J4By1CWSu27N5vbEX6V)+vU6DxuzPwMpg(u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡇࡶࡢ࡫࡯ࡥࡧࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪઠ")+str(LEpfGOn1wWiyI0eVZNklgR4)+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬࠦࡍࡃࠢ࠰ࠤࠬડ")+str(wwfyxpEkiMr)+PlpyFa9QMKXxOD1cvHzmI(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩઢ")+zCOFIge6wnjrHtqQvaiA15P8Wob4NX+wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧࠡ࡟ࠪણ"))
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ssynAg0zhSkoCpOMDV9(u"ࠨๆสࠤ๏๎ฬะ่ࠢืฬำษࠡๅสๅ๏ฯࠠๅๆอั๊๐ไࠨત"),FgXzMs0YSDt(u"ࠩส่๊๊แࠡษ็้฼๊่ษࠢอั๊๐ไ่ࠢะะ๊ํࠠࠨથ")+str(J4By1CWSu27N5vbEX6V)+FmYoGejTnwKME7d9zPc(u"ࠪࠤ๊๐ฺศสส๎ฯ่ࠦอ้สึ่ࠦแุ๋้้ࠣออสࠢไหึเษࠡࠩદ")+str(LEpfGOn1wWiyI0eVZNklgR4)+KfHAW8VGbrxi(u"๋๊ࠫࠥ฻ษหห๏ะ้ࠠๆ็้าอแูหࠣ฽้๏ฺࠠ็็ࠤัํวำๅࠣฬิ๎ๆࠡ็ืห่๊๋ࠠฮหࠤสฮโศรࠣࠫધ")+str(wwfyxpEkiMr)+s5WMHyQN4mpie(u"ࠬࠦๅ๋฼สฬฬ๐สࠡใสี฿ฯࠠะษษ้ฬ่่ࠦาสࠤ๊฿ๆศ้ࠣว๋ࠦฬ่ษี็๊ࠥวࠡฬ๋ะิࠦแุ๋้้ࠣออสࠢๆหๆ๐ษࠡๆอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํࠦวๅ็ฺ่ํฮࠧન"))
		return LhFAGlQ19zr
	Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(uulNDCPyef78(u"࠭ࡣࡦࡰࡷࡩࡷ࠭઩"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,oRJAfwD957WkUyBM1Ehu8m(u"่ࠧๆࠣฮึ๐ฯࠡฬะ้๏๊ࠠศๆ่่ๆࠦฟࠨપ"),oRJAfwD957WkUyBM1Ehu8m(u"ࠨษ็้้็ࠠศๆ่฻้๎ศࠡฯฯ้์ࠦสใำํฬฬࠦࠧફ")+str(J4By1CWSu27N5vbEX6V)+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"้ࠩࠣ๏เวษษํฮࠥ๎ฬ่ษี็ࠥ็๊่่ࠢืฬำษࠡใสี฿ฯࠠหไิ๎ออࠠࠨબ")+str(LEpfGOn1wWiyI0eVZNklgR4)+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪࠤ๊๐ฺศสส๎ฯ่่ࠦาสࠤฬ๊ๅๅใࠣๆิ๊ࠦฮฬสะࠥฮูืࠢส่ํ่สࠡๆ็ฮา๋๊ๅ่๊ࠢࠥอไฦ่อี๋ะࠠฦๆ์ࠤัํวำๅࠣ࠲ࠥํไࠡษ้ฮ๋ࠥสฤๅาࠤํะั๋ัࠣห้อำห็ิหึࠦศหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠤฤ࠭ભ"))
	if Scj7zgGFVA83otMpwUkxhm0BLN1!=jL5CrsRwebpyDVXUc1EQP(u"࠴૳"):
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,jL5CrsRwebpyDVXUc1EQP(u"ࠫฯ๋ࠠฦๆ฽หฦูࠦๆๆํอࠥะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩમ"))
		Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+CsDcLqQUVK4YBvHFW1(u"ࠬࠦࠠࠡࡗࡶࡩࡷࠦࡣࡢࡰࡦࡩࡱ࡫ࡤࠡࡶ࡫ࡩࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡰࡨࠣࡸ࡭࡫ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧય")+YLKFRH6sSIrznXBg+AAbvaXV2DQzfNHdm4U3tT(u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭ર")+zCOFIge6wnjrHtqQvaiA15P8Wob4NX+CsDcLqQUVK4YBvHFW1(u"ࠧࠡ࡟ࠪ઱"))
		return LhFAGlQ19zr
	Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨࠢࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡳࡵࡣࡵࡸࡪࡪࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯ࡰࡾ࠭લ"))
	ua2GNHKeh94QJSd = hieYJByqUTsF9CH7aD3()
	ua2GNHKeh94QJSd.create(zCOFIge6wnjrHtqQvaiA15P8Wob4NX,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠩสุ่฽ัࠡใ๋ๆࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪળ"))
	Reb2x3SZ7MfV = EsCplGc5N4mBuYW0RVQt6b
	TYfRSPL2HA3GuXIbgjyzBN69Wms = uUqrNPcXKBoQ0slv.time()
	if not I4t9qonjrm.mzAtNn5gGow2Z:
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭઴"),QjAINyUC7MDRq5d8e4vl9(u"ࠫอูศษࠢ฼ำ๊ࠦวๅฬหี฾ࠦสๆࠢศ่฿อมࠡฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬવ"))
		return LhFAGlQ19zr
	if jTDWgftK7NEmx0JAkOn2aRIvweq: KWb68M15YqePl7TVwinC = open(zCOFIge6wnjrHtqQvaiA15P8Wob4NX,sIzDXlTHYUC5L3xZGnr(u"ࠬࡽࡢࠨશ"))
	else: KWb68M15YqePl7TVwinC = open(zCOFIge6wnjrHtqQvaiA15P8Wob4NX.decode(Tk9eH2qw6Brsuhj),wdftVMyzF17cYETHu(u"࠭ࡷࡣࠩષ"))
	if f5t4sb7BER==sJw9QWiq1Kr0xfeVRI(u"ࠧ࠯࡯࠶ࡹ࠽࠭સ"):
		for b3b24XZTV7gW9mhcqLoCnftO in range(aOQTKXFL54Nl60Zhp3MbE(u"࠵૴"),nJi7mefc8wVCIt3DyxHY5kTW4Gap+aOQTKXFL54Nl60Zhp3MbE(u"࠵૴")):
			bigdh7fpZYl4aT2keV = zzECVswWcGAIXhrQlZ7jMokugnv[b3b24XZTV7gW9mhcqLoCnftO-KfHAW8VGbrxi(u"࠶૵")]
			if not bigdh7fpZYl4aT2keV.startswith(s5WMHyQN4mpie(u"ࠨࡪࡷࡸࡵ࠭હ")):
				if bigdh7fpZYl4aT2keV.startswith(oRJAfwD957WkUyBM1Ehu8m(u"ࠩ࠲࠳ࠬ઺")): bigdh7fpZYl4aT2keV = YLKFRH6sSIrznXBg.split(N6NGJ4vpmidqMCh7yo(u"ࠪ࠾ࠬ઻"),sIzDXlTHYUC5L3xZGnr(u"࠷૶"))[D2D96X5NGamBhrFwvL8VEbqiSfZIl]+LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠫ࠿઼࠭")+bigdh7fpZYl4aT2keV
				elif bigdh7fpZYl4aT2keV.startswith(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠬ࠵ࠧઽ")): bigdh7fpZYl4aT2keV = VbHeOuU1ilzSp2ZRXwBD(YLKFRH6sSIrznXBg,ssynAg0zhSkoCpOMDV9(u"࠭ࡵࡳ࡮ࠪા"))+bigdh7fpZYl4aT2keV
				else: bigdh7fpZYl4aT2keV = YLKFRH6sSIrznXBg.rsplit(Hr25gta6XcqO(u"ࠧ࠰ࠩિ"),FgXzMs0YSDt(u"࠱૷"))[D2D96X5NGamBhrFwvL8VEbqiSfZIl]+oRJAfwD957WkUyBM1Ehu8m(u"ࠨ࠱ࠪી")+bigdh7fpZYl4aT2keV
			I7jcKisuTt = dgMhO3f7oA.request(wdftVMyzF17cYETHu(u"ࠩࡊࡉ࡙࠭ુ"),bigdh7fpZYl4aT2keV,headers=LUvCxj6fMlnyEcDAahbgpH,verify=LhFAGlQ19zr)
			A8qfiDE1a5lG49SRhZP6ejztuICm = I7jcKisuTt.content
			I7jcKisuTt.close()
			KWb68M15YqePl7TVwinC.write(A8qfiDE1a5lG49SRhZP6ejztuICm)
			uuEl8mC7KUw3bBp1zv = uUqrNPcXKBoQ0slv.time()
			qrvwTxjMzLGigCtpays1XBDP = uuEl8mC7KUw3bBp1zv-TYfRSPL2HA3GuXIbgjyzBN69Wms
			AE2wXf3qkKpDaZTWlM1zh4iNom9 = qrvwTxjMzLGigCtpays1XBDP//b3b24XZTV7gW9mhcqLoCnftO
			J49WTuXajZcCq51rbPLpeKGElQAvBM = AE2wXf3qkKpDaZTWlM1zh4iNom9*(nJi7mefc8wVCIt3DyxHY5kTW4Gap+AAbvaXV2DQzfNHdm4U3tT(u"࠲૸"))
			rYFxVyl0XqmE1iNhHApS3B = J49WTuXajZcCq51rbPLpeKGElQAvBM-qrvwTxjMzLGigCtpays1XBDP
			Hnrjh7smUIGq3RgDy19CL(ua2GNHKeh94QJSd,int(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠴࠴࠵ૺ")*b3b24XZTV7gW9mhcqLoCnftO//(nJi7mefc8wVCIt3DyxHY5kTW4Gap+wdftVMyzF17cYETHu(u"࠳ૹ"))),oRJAfwD957WkUyBM1Ehu8m(u"ࠪหู้ืาࠢไ์็ࠦ็้่ࠢ็ฬ์ࠠหะี๎๋ࠦๅๅใࠣห้็๊ะ์๋ࠫૂ"),Hr25gta6XcqO(u"ࠫั๊ศࠡ็็ๅࠥอไโ์า๎ํࡀ࠭ࠡษ็ะืวࠠาไ่ࠫૃ"),str(b3b24XZTV7gW9mhcqLoCnftO*l3K7wrHSWUikTP8V//J4NbqW35lrQnFhDZ0w)+C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬ࠵ࠧૄ")+str(J4By1CWSu27N5vbEX6V)+ggjO5CrKVRPITaesWkxD(u"࠭ࠠࡎࡄࠣࠤ่ࠥࠦใฬ้ࠣฯฮโ๋࠼ࠣࠫૅ")+uUqrNPcXKBoQ0slv.strftime(ssynAg0zhSkoCpOMDV9(u"ࠢࠦࡊ࠽ࠩࡒࡀࠥࡔࠤ૆"),uUqrNPcXKBoQ0slv.gmtime(rYFxVyl0XqmE1iNhHApS3B))+Gcw2nelTR864XCVruO3mAFqI5a(u"ࠨࠢใࠫે"))
			if ua2GNHKeh94QJSd.iscanceled():
				Reb2x3SZ7MfV = LhFAGlQ19zr
				break
	else:
		b3b24XZTV7gW9mhcqLoCnftO = vU6DxuzPwMpg(u"࠴ૻ")
		for A8qfiDE1a5lG49SRhZP6ejztuICm in I7jcKisuTt.iter_content(chunk_size=l3K7wrHSWUikTP8V):
			KWb68M15YqePl7TVwinC.write(A8qfiDE1a5lG49SRhZP6ejztuICm)
			b3b24XZTV7gW9mhcqLoCnftO = b3b24XZTV7gW9mhcqLoCnftO+sIzDXlTHYUC5L3xZGnr(u"࠶ૼ")
			uuEl8mC7KUw3bBp1zv = uUqrNPcXKBoQ0slv.time()
			qrvwTxjMzLGigCtpays1XBDP = uuEl8mC7KUw3bBp1zv-TYfRSPL2HA3GuXIbgjyzBN69Wms
			AE2wXf3qkKpDaZTWlM1zh4iNom9 = qrvwTxjMzLGigCtpays1XBDP/b3b24XZTV7gW9mhcqLoCnftO
			J49WTuXajZcCq51rbPLpeKGElQAvBM = AE2wXf3qkKpDaZTWlM1zh4iNom9*(nJi7mefc8wVCIt3DyxHY5kTW4Gap+Hr25gta6XcqO(u"࠷૽"))
			rYFxVyl0XqmE1iNhHApS3B = J49WTuXajZcCq51rbPLpeKGElQAvBM-qrvwTxjMzLGigCtpays1XBDP
			Hnrjh7smUIGq3RgDy19CL(ua2GNHKeh94QJSd,int(oRJAfwD957WkUyBM1Ehu8m(u"࠲࠲࠳૿")*b3b24XZTV7gW9mhcqLoCnftO/(nJi7mefc8wVCIt3DyxHY5kTW4Gap+OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠱૾"))),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠩสุ่฽ัࠡใ๋ๆࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪૈ"),ssynAg0zhSkoCpOMDV9(u"ࠪะ้ฮࠠๆๆไࠤฬ๊แ๋ัํ์࠿࠳ࠠศๆฯึฦࠦัใ็ࠪૉ"),str(b3b24XZTV7gW9mhcqLoCnftO*l3K7wrHSWUikTP8V//J4NbqW35lrQnFhDZ0w)+N6NGJ4vpmidqMCh7yo(u"ࠫ࠴࠭૊")+str(J4By1CWSu27N5vbEX6V)+sIzDXlTHYUC5L3xZGnr(u"ࠬࠦࡍࡃࠢࠣࠤࠥ๎โห่ࠢฮอ่๊࠻ࠢࠪો")+uUqrNPcXKBoQ0slv.strftime(sJw9QWiq1Kr0xfeVRI(u"ࠨࠥࡉ࠼ࠨࡑ࠿ࠫࡓࠣૌ"),uUqrNPcXKBoQ0slv.gmtime(rYFxVyl0XqmE1iNhHApS3B))+EE1jeHnIoad(u"ࠧࠡโ્ࠪ"))
			if ua2GNHKeh94QJSd.iscanceled():
				Reb2x3SZ7MfV = LhFAGlQ19zr
				break
		I7jcKisuTt.close()
	KWb68M15YqePl7TVwinC.close()
	ua2GNHKeh94QJSd.close()
	if not Reb2x3SZ7MfV:
		Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+KfHAW8VGbrxi(u"ࠨࠢࠣࠤ࡚ࡹࡥࡳࠢࡦࡥࡳࡩࡥ࡭ࡧࡧ࠳࡮ࡴࡴࡦࡴࡵࡹࡵࡺࡥࡥࠢࡷ࡬ࡪࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡࡲࡵࡳࡨ࡫ࡳࡴࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ૎")+YLKFRH6sSIrznXBg+wdftVMyzF17cYETHu(u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩ૏")+zCOFIge6wnjrHtqQvaiA15P8Wob4NX+Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪࠤࡢ࠭ૐ"))
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,AAbvaXV2DQzfNHdm4U3tT(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ૑"),wdftVMyzF17cYETHu(u"ࠬฮอิสࠣ฻้ฮใࠡฬ่ࠤสฺ๊ศรࠣ฽๊๊๊สࠢอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํ࠭૒"))
		return EsCplGc5N4mBuYW0RVQt6b
	Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡤࡰࡹࡱࡰࡴࡧࡤࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ૓")+YLKFRH6sSIrznXBg+Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠࠦࠧ૔")+zCOFIge6wnjrHtqQvaiA15P8Wob4NX+oRJAfwD957WkUyBM1Ehu8m(u"ࠨࠢࡠࠫ૕"))
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,wdftVMyzF17cYETHu(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ૖"),aOQTKXFL54Nl60Zhp3MbE(u"ࠪฮ๊ࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠣฬ๋าวฮࠩ૗"))
	return EsCplGc5N4mBuYW0RVQt6b
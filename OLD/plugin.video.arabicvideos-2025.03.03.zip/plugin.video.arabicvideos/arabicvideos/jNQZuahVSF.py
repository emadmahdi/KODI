# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'CIMAFANS'
headers = { 'User-Agent' : fy8iFgEkrO12NR9TWBI35sjY6qHvV }
K2l9rLfvoXxyZ4NYapO = '_CMF_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==90: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==91: OmsWt89dSA5HyCZ4wL = zY53X6dEGkqnhmUDJ20rpbR8(url)
	elif mode==92: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==94: OmsWt89dSA5HyCZ4wL = Voyqwkr1g8BY2LJXz3u()
	elif mode==95: OmsWt89dSA5HyCZ4wL = eQgbVPaIBvTn8fsjJRt241(url)
	elif mode==99: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,99,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'المضاف حديثا',fy8iFgEkrO12NR9TWBI35sjY6qHvV,94)
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'الأحدث',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/?type=latest',91)
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'الأعلى تقيماً',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/?type=imdb',91)
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'الأكثر مشاهدة',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/?type=view',91)
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'المثبت',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/?type=pin',91)
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'جديد الأفلام',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/?type=newMovies',91)
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'جديد الحلقات',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/?type=newEpisodes',91)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMAFANS-MENU-1st')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="mainmenu(.*?)nav',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	items = EcQxOa3RJm86WjTKA.findall('<li><a href="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['افلام للكبار فقط']
	for bigdh7fpZYl4aT2keV,title in items:
		title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
		if not any(value in title for value in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o):
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,91)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="f-cats"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	items = EcQxOa3RJm86WjTKA.findall('<li><a href="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title in items:
		title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
		if not any(value in title for value in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o):
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,91)
	return FGRX4myP68S
def zY53X6dEGkqnhmUDJ20rpbR8(url):
	if '/search.php' in url:
		url,search = url.split('?t=')
		headers = { 'User-Agent' : fy8iFgEkrO12NR9TWBI35sjY6qHvV , 'Content-Type' : 'application/x-www-form-urlencoded' }
		data = { 't' : search }
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'POST',url,data,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMAFANS-ITEMS-1st')
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
	else:
		headers = { 'User-Agent' : fy8iFgEkrO12NR9TWBI35sjY6qHvV }
		FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMAFANS-ITEMS-2nd')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('id="movies-items(.*?)class="listfoot"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D: wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	else: wlJ6d8hEvpoMNSCmU = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	items = EcQxOa3RJm86WjTKA.findall('background-image:url\((.*?)\).*?href="(.*?)".*?movie-title">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	cmDaLEqWlT7GhonIdX5k1zHQjSiupe = []
	for POjaBmHqzpsx1IYw7kQM4R,bigdh7fpZYl4aT2keV,title in items:
		if 'الحلقة' in title and '/c/' not in url and '/cat/' not in url:
			RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) الحلقة [0-9]+',title,EcQxOa3RJm86WjTKA.DOTALL)
			if RrzpbE3t9woCk7MXS0GvNdi1BcV:
				title = '_MOD_'+RrzpbE3t9woCk7MXS0GvNdi1BcV[0]
				if title not in cmDaLEqWlT7GhonIdX5k1zHQjSiupe:
					OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,95,POjaBmHqzpsx1IYw7kQM4R)
					cmDaLEqWlT7GhonIdX5k1zHQjSiupe.append(title)
		elif '/video/' in bigdh7fpZYl4aT2keV: OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,92,POjaBmHqzpsx1IYw7kQM4R)
		else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,91,POjaBmHqzpsx1IYw7kQM4R)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="pagination(.*?)div',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('<a href="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
			title = title.replace('الصفحة ',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,91)
	return
def eQgbVPaIBvTn8fsjJRt241(url):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMAFANS-EPISODES-1st')
	POjaBmHqzpsx1IYw7kQM4R = EcQxOa3RJm86WjTKA.findall('img src="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R[0]
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('id="episodes-panel(.*?)div',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		name = EcQxOa3RJm86WjTKA.findall('itemprop="title">(.*?)<',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if name: name = name[1]
		else:
			name = bEWpDHXjCBqd7aOiN6UG5k.getInfoLabel('ListItem.Label')
			if T7ASIp1ZYwio9HQ8cObJK in name: name = name.split(T7ASIp1ZYwio9HQ8cObJK,1)[1]
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?name">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+name+' - '+title,bigdh7fpZYl4aT2keV,92,POjaBmHqzpsx1IYw7kQM4R)
	else:
		vY3c0hwATVGP7dn8bHCig6 = EcQxOa3RJm86WjTKA.findall('class="movietitle"><a href="(.*?)">(.*?)<',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if vY3c0hwATVGP7dn8bHCig6: bigdh7fpZYl4aT2keV,title = vY3c0hwATVGP7dn8bHCig6[0]
		else: bigdh7fpZYl4aT2keV,title = url,name
		OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,92,POjaBmHqzpsx1IYw7kQM4R)
	return
def rr7SfotkneX85Klup(url):
	XoSyx7p6dqZ1CF8,E3aZLDksNKFUmPGV = [],[]
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMAFANS-PLAY-1st')
	uuigJsvIZQ3tprnhxG = EcQxOa3RJm86WjTKA.findall('text-shadow: none;">(.*?)<',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if uuigJsvIZQ3tprnhxG and SYJvigbI3fts(BfWYUAnyg6eONLjiuE,url,uuigJsvIZQ3tprnhxG): return
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('id="links-panel(.*?)div',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV in items:
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?__download'
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('nav-tabs"(.*?)video-panel-more',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('id="(.*?)".*?embed src="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for id,bigdh7fpZYl4aT2keV in items:
			title = 'سيرفر '+id
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+title+'__watch'
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
		items = EcQxOa3RJm86WjTKA.findall('data-server-src="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV in items:
			if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = 'http:'+bigdh7fpZYl4aT2keV
			bigdh7fpZYl4aT2keV = U2Z7CVFftTmLeK3nzEbQPGga(bigdh7fpZYl4aT2keV)
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(XoSyx7p6dqZ1CF8,BfWYUAnyg6eONLjiuE,'video',url)
	return
def Voyqwkr1g8BY2LJXz3u():
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMAFANS-LATEST-1st')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('id="index-last-movie(.*?)id="index-slider-movie',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	items = EcQxOa3RJm86WjTKA.findall('src="(.*?)".*?href="(.*?)" title="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for POjaBmHqzpsx1IYw7kQM4R,bigdh7fpZYl4aT2keV,title in items:
		if '/video/' in bigdh7fpZYl4aT2keV: OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,92,POjaBmHqzpsx1IYw7kQM4R)
		else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,91,POjaBmHqzpsx1IYw7kQM4R)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS + '/search.php?t='+search
	zY53X6dEGkqnhmUDJ20rpbR8(url)
	return
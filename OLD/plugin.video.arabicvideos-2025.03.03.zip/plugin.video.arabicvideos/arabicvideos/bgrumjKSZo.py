# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'ALKAWTHAR'
K2l9rLfvoXxyZ4NYapO = '_KWT_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,jmI9qRnVJo2a3tpcH8gfYkP,text):
	if   mode==130: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==131: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url)
	elif mode==132: OmsWt89dSA5HyCZ4wL = C4B2gISwPdtL0nRrZ(url)
	elif mode==133: OmsWt89dSA5HyCZ4wL = eQgbVPaIBvTn8fsjJRt241(url,jmI9qRnVJo2a3tpcH8gfYkP)
	elif mode==134: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==135: OmsWt89dSA5HyCZ4wL = uEyU2e6lv4()
	elif mode==139: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text,url)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,139,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,True,'ALKAWTHAR-MENU-1st')
	z6PX2p7diaskQElBOvMRNcHwqG5D=EcQxOa3RJm86WjTKA.findall('dropdown-menu(.*?)dropdown-toggle',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[1]
	items=EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title in items:
		if '/conductor' in bigdh7fpZYl4aT2keV: continue
		title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
		url = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
		if '/category/' in url: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,132)
		else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,131)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'المسلسلات',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/category/543',132,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'الأفلام',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/category/628',132,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'برامج الصغار والشباب',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/category/517',132,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'ابرز البرامج',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/category/1763',132,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'المحاضرات',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/category/943',132,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'عاشوراء',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/category/1353',132,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'البرامج الاجتماعية',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/category/501',132,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'البرامج الدينية',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/category/509',132,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'البرامج الوثائقية',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/category/553',132,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'البرامج السياسية',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/category/545',132,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'كتب',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/category/291',132,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'تعلم الفارسية',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/category/88',132,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'أرشيف البرامج',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/category/1279',132,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1')
	return
def HAsKeZdTbqjPI1WY(url):
	ffIlTDmbVpjAgSeZ24HxFndPiq67 = ['/religious','/social','/political','/films','/series']
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,True,'ALKAWTHAR-TITLES-1st')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('titlebar(.*?)titlebar',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	if any(value in url for value in ffIlTDmbVpjAgSeZ24HxFndPiq67):
		items = EcQxOa3RJm86WjTKA.findall("src='(.*?)'.*?href='(.*?)'.*?>(.*?)<",wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for POjaBmHqzpsx1IYw7kQM4R,bigdh7fpZYl4aT2keV,title in items:
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS + bigdh7fpZYl4aT2keV
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,133,POjaBmHqzpsx1IYw7kQM4R,'1')
	elif '/docs' in url:
		items = EcQxOa3RJm86WjTKA.findall("src='(.*?)'.*?<h2>(.*?)</h2>.*?href='(.*?)'",wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for POjaBmHqzpsx1IYw7kQM4R,title,bigdh7fpZYl4aT2keV in items:
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS + bigdh7fpZYl4aT2keV
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,133,POjaBmHqzpsx1IYw7kQM4R,'1')
	return
def C4B2gISwPdtL0nRrZ(url):
	fnogyzNA30JCPMYqHTavG7ZKp = url.split('/')[-1]
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,True,'ALKAWTHAR-CATEGORIES-1st')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('parentcat(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not z6PX2p7diaskQElBOvMRNcHwqG5D:
		eQgbVPaIBvTn8fsjJRt241(url,'1')
		return
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	items = EcQxOa3RJm86WjTKA.findall("href='(.*?)'.*?>(.*?)<",wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title in items:
		title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
		bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS + bigdh7fpZYl4aT2keV
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,132,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1')
	return
def eQgbVPaIBvTn8fsjJRt241(url,jmI9qRnVJo2a3tpcH8gfYkP):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,True,'ALKAWTHAR-EPISODES-1st')
	items = EcQxOa3RJm86WjTKA.findall('totalpagecount=[\'"](.*?)[\'"]',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not items:
		url = EcQxOa3RJm86WjTKA.findall('class="news-detail-body".*?href="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		url = url[0]
		title = '_MOD_' + 'ملف التشغيل'
		if url: OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,url,134)
		else: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','لا يوجد حاليا ملفات فيديو في هذا الفرع')
		return
	UGhQMoHCgae4SqY6Vx5dzR1s7 = int(items[0])
	name = EcQxOa3RJm86WjTKA.findall('main-title.*?</a> >(.*?)<',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if name: name = name[0].strip(ksJdoFWhxTz8Y2N7bOZE)
	else: name = bEWpDHXjCBqd7aOiN6UG5k.getInfoLabel('ListItem.Label')
	if '/category/' in url or 'search?q=' in url:
		fnogyzNA30JCPMYqHTavG7ZKp = url.split('/')[-1]
		if jmI9qRnVJo2a3tpcH8gfYkP==fy8iFgEkrO12NR9TWBI35sjY6qHvV: YLKFRH6sSIrznXBg = url
		else: YLKFRH6sSIrznXBg = BOI3t1w8qfHAb0Kl4oMye7haEWS + '/category/' + fnogyzNA30JCPMYqHTavG7ZKp + '/' + jmI9qRnVJo2a3tpcH8gfYkP
		soEymUvkt19PQXVjzKau6x5 = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,True,'ALKAWTHAR-EPISODES-2nd')
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('currentpagenumber(.*?)pagination',soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('src="(.*?)".*?full(.*?)>.*?href="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for POjaBmHqzpsx1IYw7kQM4R,type,bigdh7fpZYl4aT2keV,title in items:
			if 'video' not in type: continue
			if 'مسلسل' in title and 'حلقة' not in title: continue
			title = title.replace('\r\n',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			if 'مسلسل' in name and 'حلقة' in title and 'مسلسل' not in title:
				title = '_MOD_' + name + ' - ' + title
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS + bigdh7fpZYl4aT2keV
			if fnogyzNA30JCPMYqHTavG7ZKp=='628': OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,133,POjaBmHqzpsx1IYw7kQM4R,'1')
			else: OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,134,POjaBmHqzpsx1IYw7kQM4R)
	elif '/episode/' in url:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('playlist(.*?)col-md-12',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall("video-track-text.*?loadVideo\('(.*?)','(.*?)'.*?>(.*?)<",wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
				title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
				OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,134,POjaBmHqzpsx1IYw7kQM4R)
		elif '/category/628' in FGRX4myP68S:
				title = '_MOD_' + 'ملف التشغيل'
				OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,url,134)
		else:
			items = EcQxOa3RJm86WjTKA.findall('id="Categories.*?href=\'(.*?)\'',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
			fnogyzNA30JCPMYqHTavG7ZKp = items[0].split('/')[-1]
			url = BOI3t1w8qfHAb0Kl4oMye7haEWS + '/category/' + fnogyzNA30JCPMYqHTavG7ZKp
			C4B2gISwPdtL0nRrZ(url)
			return
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('pagination(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		HKdIs1GFl89imxOhPS4qtRAruWNT = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in HKdIs1GFl89imxOhPS4qtRAruWNT:
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.replace('&amp;','&')
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,133)
	return
def rr7SfotkneX85Klup(url):
	if '/news/' in url or '/episode/' in url:
		FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,True,'ALKAWTHAR-PLAY-1st')
		items = EcQxOa3RJm86WjTKA.findall("mobilevideopath.*?value='(.*?)'",FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if items: url = items[0]
	E7HR1ZcMuzUs9XCVrNGJYi(url,BfWYUAnyg6eONLjiuE,'video')
	return
def uEyU2e6lv4():
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/live'
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,True,'ALKAWTHAR-LIVE-1st')
	YLKFRH6sSIrznXBg = EcQxOa3RJm86WjTKA.findall('live-container.*?src="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg[0]
	naBFTDfp6lmKjeOywg87IAcb = {'Referer':BOI3t1w8qfHAb0Kl4oMye7haEWS}
	JOB9NFKAlRSW8eyTQDPaG7 = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,'GET',YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,naBFTDfp6lmKjeOywg87IAcb,fy8iFgEkrO12NR9TWBI35sjY6qHvV,True,'ALKAWTHAR-LIVE-2nd')
	soEymUvkt19PQXVjzKau6x5 = JOB9NFKAlRSW8eyTQDPaG7.content
	eDi4j5Usrp = EcQxOa3RJm86WjTKA.findall('csrf-token" content="(.*?)"',soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
	eDi4j5Usrp = eDi4j5Usrp[0]
	fNehv4joEmS6lWQyC = VbHeOuU1ilzSp2ZRXwBD(YLKFRH6sSIrznXBg,'url')
	MYWwFs7XA2 = EcQxOa3RJm86WjTKA.findall("playUrl = '(.*?)'",soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
	MYWwFs7XA2 = fNehv4joEmS6lWQyC+MYWwFs7XA2[0]
	fVyzUAKh6sbjE = {'X-CSRF-TOKEN':eDi4j5Usrp}
	xmsOVkodWQ9ECanvR073l8 = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,'POST',MYWwFs7XA2,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fVyzUAKh6sbjE,False,True,'ALKAWTHAR-LIVE-3rd')
	kiIwQfreEsU4LMK = xmsOVkodWQ9ECanvR073l8.content
	hL4w3zgankZR75698QCyi = EcQxOa3RJm86WjTKA.findall('"(.*?)"',kiIwQfreEsU4LMK,EcQxOa3RJm86WjTKA.DOTALL)
	hL4w3zgankZR75698QCyi = hL4w3zgankZR75698QCyi[0].replace('\/','/')
	E7HR1ZcMuzUs9XCVrNGJYi(hL4w3zgankZR75698QCyi,BfWYUAnyg6eONLjiuE,'live')
	return
def dPTs3joJiGpzfcWFvQZAa(search,url=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if url==fy8iFgEkrO12NR9TWBI35sjY6qHvV:
		if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
		if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
		search = DVX5GWhnIxYlSd9rEuetjk40UJ(search)
		url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/search?q='+search
		eQgbVPaIBvTn8fsjJRt241(url,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		return
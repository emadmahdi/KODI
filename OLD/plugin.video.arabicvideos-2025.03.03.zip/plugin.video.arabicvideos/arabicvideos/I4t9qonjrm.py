# -*- coding: utf-8 -*-
import sys as CfgZ0zWP5XBpoGQwLUY
D5DpyO2wPg7oL = CfgZ0zWP5XBpoGQwLUY.version_info [0] == 2
ccK5HIyfUgvOdQpWSXZtaBJ = 2048
W8WuBTGQg1Zwqy5F6xSe = 7
def zmQcCUZlPKBITW5bqx1 (rR5FPU8VhJQ):
	global Jfz4wMWSZb0BYV
	EEr5teuZbc = ord (rR5FPU8VhJQ [-1])
	ZZd5W9FVUhzu31NQyComxv = rR5FPU8VhJQ [:-1]
	sJYFyd6mZHev1IXEaMj0b = EEr5teuZbc % len (ZZd5W9FVUhzu31NQyComxv)
	qPJ7pUnt5rcm6NMaFYLSkHsGxI = ZZd5W9FVUhzu31NQyComxv [:sJYFyd6mZHev1IXEaMj0b] + ZZd5W9FVUhzu31NQyComxv [sJYFyd6mZHev1IXEaMj0b:]
	if D5DpyO2wPg7oL:
		Vv1b9fdEckNepm7 = unicode () .join ([unichr (ord (QdqoKlFn4yZUOJp1xYrNTaBSmt69hc) - ccK5HIyfUgvOdQpWSXZtaBJ - (hrazDC5q4oB + EEr5teuZbc) % W8WuBTGQg1Zwqy5F6xSe) for hrazDC5q4oB, QdqoKlFn4yZUOJp1xYrNTaBSmt69hc in enumerate (qPJ7pUnt5rcm6NMaFYLSkHsGxI)])
	else:
		Vv1b9fdEckNepm7 = str () .join ([chr (ord (QdqoKlFn4yZUOJp1xYrNTaBSmt69hc) - ccK5HIyfUgvOdQpWSXZtaBJ - (hrazDC5q4oB + EEr5teuZbc) % W8WuBTGQg1Zwqy5F6xSe) for hrazDC5q4oB, QdqoKlFn4yZUOJp1xYrNTaBSmt69hc in enumerate (qPJ7pUnt5rcm6NMaFYLSkHsGxI)])
	return eval (Vv1b9fdEckNepm7)
V3z5t4JAqyXk2fLsW1juoZ0BEp6,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye,wdftVMyzF17cYETHu=zmQcCUZlPKBITW5bqx1,zmQcCUZlPKBITW5bqx1,zmQcCUZlPKBITW5bqx1
Hr25gta6XcqO,FmYoGejTnwKME7d9zPc,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9=wdftVMyzF17cYETHu,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye,V3z5t4JAqyXk2fLsW1juoZ0BEp6
KfHAW8VGbrxi,aOQTKXFL54Nl60Zhp3MbE,jL5CrsRwebpyDVXUc1EQP=Dco0w1e5VM3YP7hLXTHBS8GtaCrO9,FmYoGejTnwKME7d9zPc,Hr25gta6XcqO
oRJAfwD957WkUyBM1Ehu8m,vU6DxuzPwMpg,I18uSKaWhgTBeYUPD4sr=jL5CrsRwebpyDVXUc1EQP,aOQTKXFL54Nl60Zhp3MbE,KfHAW8VGbrxi
o1INZ3ViQqS0Uw5z6kMjbv,s5WMHyQN4mpie,N6NGJ4vpmidqMCh7yo=I18uSKaWhgTBeYUPD4sr,vU6DxuzPwMpg,oRJAfwD957WkUyBM1Ehu8m
Gcw2nelTR864XCVruO3mAFqI5a,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7,OO9YiAQHGrLo0qpW2M3jDeXd1kx=N6NGJ4vpmidqMCh7yo,s5WMHyQN4mpie,o1INZ3ViQqS0Uw5z6kMjbv
O3OVuapf0YFjbm5oUQDg,sJw9QWiq1Kr0xfeVRI,SnhLjmfeJC=OO9YiAQHGrLo0qpW2M3jDeXd1kx,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7,Gcw2nelTR864XCVruO3mAFqI5a
QjAINyUC7MDRq5d8e4vl9,AAbvaXV2DQzfNHdm4U3tT,ggjO5CrKVRPITaesWkxD=SnhLjmfeJC,sJw9QWiq1Kr0xfeVRI,O3OVuapf0YFjbm5oUQDg
FgXzMs0YSDt,uulNDCPyef78,EQxFuqjw95WvaMm8Hnlt47XVihJ=ggjO5CrKVRPITaesWkxD,AAbvaXV2DQzfNHdm4U3tT,QjAINyUC7MDRq5d8e4vl9
ssynAg0zhSkoCpOMDV9,sIzDXlTHYUC5L3xZGnr,PlpyFa9QMKXxOD1cvHzmI=EQxFuqjw95WvaMm8Hnlt47XVihJ,uulNDCPyef78,FgXzMs0YSDt
CsDcLqQUVK4YBvHFW1,EE1jeHnIoad,LYIgTBeSmZWotDh4bnyQkvM50siu=PlpyFa9QMKXxOD1cvHzmI,sIzDXlTHYUC5L3xZGnr,ssynAg0zhSkoCpOMDV9
from b0c2jnV5OD import *
SITESURLS = {
			 Hr25gta6XcqO(u"ࠩࡄࡌ࡜ࡇࡋࠨ଀")		:[ggjO5CrKVRPITaesWkxD(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡹ࠮ࡢࡪࡺࡥࡰࡺࡶ࠯ࡰࡨࡸࠬଁ")]
			,SnhLjmfeJC(u"ࠫࡆࡑࡏࡂࡏࠪଂ")		:[QjAINyUC7MDRq5d8e4vl9(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡬࠰ࡶࡺ࠴ࡵ࡬ࡥࠩଃ")]
			,SnhLjmfeJC(u"࠭ࡁࡌ࡙ࡄࡑࠬ଄")		:[OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣ࡮࠲ࡸࡼࠧଅ")]
			,LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨࡃࡎ࡛ࡆࡓࡔࡖࡄࡈࠫଆ")	:[Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡭࠳ࡧ࡫ࡸࡣࡰ࠲ࡹࡻࡢࡦࠩଇ")]
			,PlpyFa9QMKXxOD1cvHzmI(u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬଈ")		:[wdftVMyzF17cYETHu(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡬࡮ࡣࡤࡶࡪ࡬࠮ࡤࡪࠪଉ")]
			,N6NGJ4vpmidqMCh7yo(u"ࠬࡇࡌࡎࡕࡗࡆࡆ࠭ଊ")		:[EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷࡱࡧ࠲ࡦࡲ࡭ࡴࡶࡥࡥ࠳ࡺࡶࠨଋ")]
			,aOQTKXFL54Nl60Zhp3MbE(u"ࠧࡂࡐࡌࡑࡊࡠࡉࡅࠩଌ")		:[QjAINyUC7MDRq5d8e4vl9(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡲ࡮ࡳࡥࡻ࡫ࡧ࠲ࡸ࡮࡯ࡸࠩ଍")]
			,N6NGJ4vpmidqMCh7yo(u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧ଎")	:[EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡢࡴࡤࡦ࡮ࡩ࠭ࡵࡱࡲࡲࡸ࠴ࡣࡰ࡯ࠪଏ")]
			,PlpyFa9QMKXxOD1cvHzmI(u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭ଐ")		:[FgXzMs0YSDt(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡣࡥࡷࡪ࡫ࡤ࠯ࡰࡨࡸࠬ଑")]
			,AAbvaXV2DQzfNHdm4U3tT(u"࠭ࡁ࡚ࡎࡒࡐࠬ଒")		:[Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡨ࠲ࡦࡿ࡬ࡰ࡮࠱ࡲࡪࡺࠧଓ")]
			,Hr25gta6XcqO(u"ࠨࡄࡒࡏࡗࡇࠧଔ")		:[Hr25gta6XcqO(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶ࡬ࡴࡵࡦࡷࡱࡧ࠲ࡨࡵ࡭ࠨକ")]
			,N6NGJ4vpmidqMCh7yo(u"ࠪࡆࡗ࡙ࡔࡆࡌࠪଖ")		:[KfHAW8VGbrxi(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡨࡲࡴࡶࡨ࡮࠳ࡩ࡯࡮ࠩଗ")]
			,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭ଘ")		:[jL5CrsRwebpyDVXUc1EQP(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥ࠹࠶࠰࠯ࡥࡲࡱࠬଙ")]
			,ggjO5CrKVRPITaesWkxD(u"ࠧࡄࡋࡐࡅ࠹ࡖࠧଚ")		:[KfHAW8VGbrxi(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧ࠴ࡱ࠰ࡦࡳࡲ࠭ଛ")]
			,wdftVMyzF17cYETHu(u"ࠩࡆࡍࡒࡇ࠴ࡖࠩଜ")		:[I18uSKaWhgTBeYUPD4sr(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࠶ࡩࡩ࡮ࡣ࠷ࡹ࠳ࡩ࡯࡮ࠩଝ")]
			,O3OVuapf0YFjbm5oUQDg(u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭ଞ")		:[vU6DxuzPwMpg(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤ࠷ࡧࡪ࡯࠯ࡥࡲࡱࠬଟ")]
			,aOQTKXFL54Nl60Zhp3MbE(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨଠ")		:[sJw9QWiq1Kr0xfeVRI(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦࡩ࡬ࡶࡤ࠱ࡻࡦࡺࡣࡩࠩଡ")]
			,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࡚ࡓࡗࡑࠧଢ")	:[EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸࡻࡼ࠮ࡤ࡫ࡰࡥࡨࡲࡵࡣ࠰ࡶ࡬ࡴࡶࠧଣ")]
			,wdftVMyzF17cYETHu(u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗࠬତ")		:[oRJAfwD957WkUyBM1Ehu8m(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡦ࡭ࡲࡧࡦࡢࡰࡶ࠲ࡨࡵ࡭ࠨଥ")]
			,jL5CrsRwebpyDVXUc1EQP(u"ࠬࡉࡉࡎࡃࡉࡖࡊࡋࠧଦ")		:[EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥ࡫ࡸࡥࡦ࠰ࡹ࡭ࡵ࠭ଧ")]
			,FgXzMs0YSDt(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪନ")	:[Hr25gta6XcqO(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺ࠷࠻࠴࡭ࡺ࠯ࡦ࡭ࡲࡧ࠮࡯ࡧࡷ࠳࠺ࡼࡳ࠺ࠩ଩")]
			,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪପ")		:[FgXzMs0YSDt(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢࡰࡲࡻ࠳ࡩࡣࠨଫ")]
			,AAbvaXV2DQzfNHdm4U3tT(u"ࠫࡈࡏࡍࡂ࡙ࡅࡅࡘ࠭ବ")		:[OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤࡻࡧࡧࡳ࠯࡯ࡼࡧ࡮ࡳࡡ࠯ࡥࡦࠫଭ")]
			,N6NGJ4vpmidqMCh7yo(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫମ")	:[FmYoGejTnwKME7d9zPc(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠱ࡧࡴࡳࠧଯ"),FgXzMs0YSDt(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡪࡶࡦࡶࡨࡲ࡮࠱ࡥࡵ࡯࠮ࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠳ࡩ࡯࡮ࠩର")]
			,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠩࡇࡖࡆࡓࡁࡄࡃࡉࡉࠬ଱")	:[EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼ࠸࠵࠯ࡦࡵࡥࡲࡧࡣࡢࡨࡨ࠱ࡹࡼ࠮ࡤࡱࡰࠫଲ")]
			,Hr25gta6XcqO(u"ࠫࡉࡘࡁࡎࡃࡖ࠻ࠬଳ")		:[aOQTKXFL54Nl60Zhp3MbE(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡤࡳࡣࡰࡥࡸ࠽࠮࡯ࡧࡷࠫ଴")]
			,CsDcLqQUVK4YBvHFW1(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨଵ")		:[EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡩࡹࡳ࠭ଶ")]
			,s5WMHyQN4mpie(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴ࠪଷ")		:[C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡼ࡫ࡢࡤࡣࡰࠫସ")]
			,vU6DxuzPwMpg(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷ࠬହ")		:[LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡯ࡥࡨࡻࡥࡩࡸࡺ࠮ࡣ࡫ࡧࠫ଺")]
			,LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧ଻")		:[wdftVMyzF17cYETHu(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼ࠱ࡧ࡫ࡳࡵ࠰ࡱࡩࡹ଼࠭")]
			,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨଽ")		:[C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾࡪࡥࡢࡦ࠱ࡰ࡮ࡼࡥࠨା")]
			,AAbvaXV2DQzfNHdm4U3tT(u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄࠫି")		:[EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡲࡣࡪࡰࡨࡱࡦ࠴ࡣࡰ࡯ࠪୀ")]
			,Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫࡊࡒࡉࡇࡘࡌࡈࡊࡕࠧୁ")	:[jL5CrsRwebpyDVXUc1EQP(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡣ࡫࡭ࡩ࠴ࡥ࡭࡫ࡩ࠲ࡳ࡫ࡷࡴࠩୂ")]
			,jL5CrsRwebpyDVXUc1EQP(u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧୃ")		:[s5WMHyQN4mpie(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤࡦࡷࡱࡡ࠯ࡥࡲࡱࠬୄ")]
			,ggjO5CrKVRPITaesWkxD(u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫ୅")	:[EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦࡰࡥࡳ࠰ࡶ࡬ࡴࡽࠧ୆")]
			,Hr25gta6XcqO(u"ࠪࡊࡆࡘࡅࡔࡍࡒࠫେ")		:[Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡼࡩࡱ࠰ࡩࡥࡷ࡫ࡳ࡬ࡱ࠱ࡲࡪࡺࠧୈ")]
			,FgXzMs0YSDt(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸ࠧ୉")		:[ssynAg0zhSkoCpOMDV9(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡵ࡯ࡥ࠳࡬ࡡࡴࡧ࡯࡬ࡩ࠴ࡣ࡭ࡱࡸࡨࠬ୊")]
			,EE1jeHnIoad(u"ࠧࡇࡑࡖࡘࡆ࠭ୋ")		:[ssynAg0zhSkoCpOMDV9(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻ࡯࠴ࡦࡰࡵࡷࡥ࠲ࡺࡶ࠯ࡰࡨࡸࠬୌ")]
			,PlpyFa9QMKXxOD1cvHzmI(u"ࠩࡉ࡙ࡓࡕࡎࡕࡘ୍ࠪ")		:[C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬࠴ࡡ࡭࡯ࡨࡷ࡭ࡱࡡࡩ࠰ࡱࡩࡹ࠭୎")]
			,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠫࡋ࡛ࡓࡉࡃࡕࡘ࡛࠭୏")		:[aOQTKXFL54Nl60Zhp3MbE(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡢ࠯ࡨࡸࡷ࡭ࡧࡲ࠮ࡶࡹ࠲ࡨࡵ࡭ࠨ୐")]
			,I18uSKaWhgTBeYUPD4sr(u"࠭ࡆࡖࡕࡋࡅࡗ࡜ࡉࡅࡇࡒࠫ୑")	:[sIzDXlTHYUC5L3xZGnr(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࠱ࡪࡺࡹࡨࡢࡴ࠱ࡺ࡮ࡪࡥࡰࠩ୒")]
			,FgXzMs0YSDt(u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪ୓")		:[AAbvaXV2DQzfNHdm4U3tT(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡬ࡦࡲࡡࡤ࡫ࡰࡥ࠳ࡳࡥࡥ࡫ࡤࠫ୔")]
			,vU6DxuzPwMpg(u"ࠪࡍࡋࡏࡌࡎࠩ୕")		:[PlpyFa9QMKXxOD1cvHzmI(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲ࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬୖ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡯࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭ୗ"),ssynAg0zhSkoCpOMDV9(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣ࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧ୘"),o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤ࠶࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩ୙"),KfHAW8VGbrxi(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠻࠶࠲࠶࠿࠰࠯࠴࠷࠲࠶࠸࠲ࠨ୚")]
			,FmYoGejTnwKME7d9zPc(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ୛")	:[AAbvaXV2DQzfNHdm4U3tT(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡧࡲࡣࡣ࡯ࡥ࠲ࡺࡶ࠯࡫ࡴࠫଡ଼")]
			,QjAINyUC7MDRq5d8e4vl9(u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭ଢ଼")		:[ssynAg0zhSkoCpOMDV9(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡪࡶ࡮ࡳࡹ࠴ࡣࡢ࡯ࠪ୞")]
			,jL5CrsRwebpyDVXUc1EQP(u"࠭ࡋࡊࡔࡐࡅࡑࡑࠧୟ")		:[o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡸ࠲ࡰ࡯ࡲ࡮ࡣ࡯࡯࠳ࡩ࡯࡮ࠩୠ")]
			,N6NGJ4vpmidqMCh7yo(u"ࠨࡎࡄࡖࡔࡠࡁࠨୡ")		:[vU6DxuzPwMpg(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡰࡦࡸ࡯ࡻࡣ࠱࡭ࡳࡱࠧୢ")]
			,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫୣ")		:[sIzDXlTHYUC5L3xZGnr(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡲ࡯ࡥࡻࡱࡩࡹ࠴࡬ࡪࡰ࡮ࠫ୤")]
			,LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠬࡓࡁࡔࡃ࡙ࡍࡉࡋࡏࠨ୥")	:[Gcw2nelTR864XCVruO3mAFqI5a(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡰ࠱ࡱࡦࡹࡡ࠯ࡰࡨࡻࡸ࠭୦")]
			,KfHAW8VGbrxi(u"ࠧࡑࡃࡑࡉ࡙࠭୧")		:[FgXzMs0YSDt(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡶࡡ࡯ࡧࡷ࠲ࡨࡵ࠮ࡪ࡮ࠪ୨")]
			,AAbvaXV2DQzfNHdm4U3tT(u"ࠩࡕࡉࡑࡋࡁࡔࡇࡖࠫ୩")		:[AAbvaXV2DQzfNHdm4U3tT(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡳࡶࡴࡪࡩ࠳ࡹࡨ࠰࡭ࡲࡨ࡮࠵ࡥ࡮ࡣࡧࡣࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠲ࡳࡱࡪ࠯ࡪࡰࡧࡩࡽ࠴ࡨࡵ࡯࡯ࠫ୪")]
			,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠫࡘࡋࡒࡊࡇࡖࡘࡎࡓࡅࠨ୫")	:[AAbvaXV2DQzfNHdm4U3tT(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡢࡢ࠰ࡶࡩࡷ࡯ࡥࡴࡶ࡬ࡱࡪ࠴ࡣࡢ࡯ࠪ୬")]
			,uulNDCPyef78(u"࠭ࡓࡉࡃࡅࡅࡐࡇࡔ࡚ࠩ୭")	:[Hr25gta6XcqO(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࡮ࡤ࠯ࡸ࡬ࡴࠬ୮")]
			,oRJAfwD957WkUyBM1Ehu8m(u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪ୯")		:[vU6DxuzPwMpg(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡧࡨࡪࡦ࠷ࡹ࠳ࡪࡡࡺࠩ୰")]
			,sJw9QWiq1Kr0xfeVRI(u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧୱ")	:[uulNDCPyef78(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࠮ࡴࡪ࠷ࡹ࠳ࡴࡥࡸࡵࠪ୲")]
			,ggjO5CrKVRPITaesWkxD(u"࡙ࠬࡈࡐࡈࡋࡅࠬ୳")		:[I18uSKaWhgTBeYUPD4sr(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡲࡪ࡭ࡧ࠮ࡵࡸࠪ୴")]
			,aOQTKXFL54Nl60Zhp3MbE(u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩ୵")		:[sIzDXlTHYUC5L3xZGnr(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡴࡵࡦ࡮ࡣࡻ࠲ࡨࡵ࡭ࠨ୶"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷࡹࡧࡴࡪࡥ࠱ࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼ࠳ࡩ࡯࡮ࠩ୷"),EE1jeHnIoad(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡡࡻࡷࡵࡩࡪࡪࡧࡦ࠰ࡱࡩࡹ࠭୸")]
			,CsDcLqQUVK4YBvHFW1(u"ࠫࡘࡎࡏࡐࡈࡑࡉ࡙࠭୹")		:[PlpyFa9QMKXxOD1cvHzmI(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡴ࠰ࡤ࡯ࡼࡧ࡭࠯ࡶࡸࡦࡪ࠭୺")]
			,o1INZ3ViQqS0Uw5z6kMjbv(u"࠭ࡔࡊࡍࡄࡅ࡙࠭୻")		:[Hr25gta6XcqO(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡶ࡬࡯ࡦࡧࡴ࠯ࡰࡨࡸࠬ୼")]
			,I18uSKaWhgTBeYUPD4sr(u"ࠨࡖ࡙ࡊ࡚ࡔࠧ୽")		:[wdftVMyzF17cYETHu(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࠳ࡺࡶࡧࡷࡱ࠲ࡲ࡫ࠧ୾")]
			,Gcw2nelTR864XCVruO3mAFqI5a(u"࡚ࠪࡆࡘࡂࡐࡐࠪ୿")		:[vU6DxuzPwMpg(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡳ࠮ࡷࡣࡵࡦࡴࡴ࠮ࡤࡣࡰࠫ஀")]
			,jL5CrsRwebpyDVXUc1EQP(u"ࠬ࡜ࡉࡅࡇࡒࡒࡘࡇࡅࡎࠩ஁")	:[sJw9QWiq1Kr0xfeVRI(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷ࡫ࡧࡩࡴ࠴࡮ࡴࡣࡨࡱ࠳ࡴࡥࡵࠩஂ")]
			,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠧࡘࡇࡆࡍࡒࡇ࠱ࠨஃ")		:[AAbvaXV2DQzfNHdm4U3tT(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡩࡨ࡯࡭ࡢ࠰ࡶ࡬ࡴࡽࠧ஄")]
			,LYIgTBeSmZWotDh4bnyQkvM50siu(u"࡚ࠩࡉࡈࡏࡍࡂ࠴ࠪஅ")		:[vU6DxuzPwMpg(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼ࡫ࡣࡪ࡯ࡤ࠲ࡨࡲࡩࡤ࡭ࠪஆ")]
			,N6NGJ4vpmidqMCh7yo(u"ࠫ࡞ࡇࡑࡐࡖࠪஇ")		:[OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡹ࠯ࡻࡤࡵࡴࡺ࠮ࡵࡸࠪஈ")]
			,KfHAW8VGbrxi(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧஉ")		:[ggjO5CrKVRPITaesWkxD(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯ࠪஊ")]
			,N6NGJ4vpmidqMCh7yo(u"ࠨ࡛ࡗࡆࡤࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ஋")	:[FgXzMs0YSDt(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱࠬ஌")]
			,FgXzMs0YSDt(u"ࠪࡍࡕ࡚ࡖࠨ஍")			:[fy8iFgEkrO12NR9TWBI35sjY6qHvV]
			,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠫࡒ࠹ࡕࠨஎ")			:[fy8iFgEkrO12NR9TWBI35sjY6qHvV]
			,CsDcLqQUVK4YBvHFW1(u"ࠬࡘࡅࡑࡑࡖࠫஏ")		:[wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶ࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭ஐ"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑ࠲ࡅࡉࡊࡏࡏࡕ࠴࠼࠴ࡧࡤࡥࡱࡱࡷ࠶࠾࠮ࡹ࡯࡯ࠫ஑"),EE1jeHnIoad(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱ࠱ࡎࡓࡉࡏࡒࡆࡒࡒ࠳ࡆࡊࡄࡐࡐࡖ࠵࠾࠵ࡡࡥࡦࡲࡲࡸ࠷࠹࠯ࡺࡰࡰࠬஒ")]
			,wdftVMyzF17cYETHu(u"ࠩࡕࡉࡕࡕࡓࡠࡄࡎࡔ࠶࠭ஓ")	:[AAbvaXV2DQzfNHdm4U3tT(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬࡯ࡴࡩࡷࡥ࠲ࡨࡵ࡭࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠳ࡐࡕࡄࡊ࠱ࡵࡥࡼ࠵ࡲࡦࡨࡶ࠳࡭࡫ࡡࡥࡵ࠲ࡱࡦࡹࡴࡦࡴ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧஔ"),N6NGJ4vpmidqMCh7yo(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡭ࡩࡵࡪࡸࡦ࠳ࡩ࡯࡮࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠴ࡑࡏࡅࡋ࠲ࡶࡦࡽ࠯ࡳࡧࡩࡷ࠴࡮ࡥࡢࡦࡶ࠳ࡲࡧࡳࡵࡧࡵ࠳ࡆࡊࡄࡐࡐࡖ࠵࠽࠵ࡡࡥࡦࡲࡲࡸ࠷࠸࠯ࡺࡰࡰࠬக"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧࡪࡶ࡫ࡹࡧ࠴ࡣࡰ࡯࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠵ࡋࡐࡆࡌ࠳ࡷࡧࡷ࠰ࡴࡨࡪࡸ࠵ࡨࡦࡣࡧࡷ࠴ࡳࡡࡴࡶࡨࡶ࠴ࡇࡄࡅࡑࡑࡗ࠶࠿࠯ࡢࡦࡧࡳࡳࡹ࠱࠺࠰ࡻࡱࡱ࠭஖")]
			,s5WMHyQN4mpie(u"࠭ࡒࡆࡒࡒࡗࡤࡈࡋࡑ࠴ࠪ஗")	:[FgXzMs0YSDt(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡸ࡯࠳ࡺ࡯࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬ஘"),aOQTKXFL54Nl60Zhp3MbE(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰ࠱ࡄࡈࡉࡕࡎࡔ࠳࠻࠳ࡦࡪࡤࡰࡰࡶ࠵࠽࠴ࡸ࡮࡮ࠪங"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠴࠽࠴ࡧࡤࡥࡱࡱࡷ࠶࠿࠮ࡹ࡯࡯ࠫச")]
			,PlpyFa9QMKXxOD1cvHzmI(u"ࠪࡖࡊࡖࡏࡔࡡࡅࡏࡕ࠹ࠧ஛")	:[LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴࡭ࡰࡱࡲ࠲ࡨࡵ࡭࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬஜ"),SnhLjmfeJC(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮࡮ࡱࡲࡳ࠳ࡩ࡯࡮࠱ࡄࡈࡉࡕࡎࡔ࠳࠻࠳ࡦࡪࡤࡰࡰࡶ࠵࠽࠴ࡸ࡮࡮ࠪ஝"),AAbvaXV2DQzfNHdm4U3tT(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲ࡅࡉࡊࡏࡏࡕ࠴࠽࠴ࡧࡤࡥࡱࡱࡷ࠶࠿࠮ࡹ࡯࡯ࠫஞ")]
			,PlpyFa9QMKXxOD1cvHzmI(u"ࠧࡌࡑࡇࡍࡤ࡙ࡏࡖࡔࡆࡉࡘ࠭ட")	:[uulNDCPyef78(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡷࡺࡸࡧࡦ࠰ࡶ࡬࠴ࡱ࡯ࡥ࡫ࠪ஠"),jL5CrsRwebpyDVXUc1EQP(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰࡭ࡲࡨ࡮࠭஡"),sIzDXlTHYUC5L3xZGnr(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳ࡰࡵࡤࡪࠩ஢")]
			,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠫࡋࡏࡌࡆࡕࡢࡗࡔ࡛ࡒࡄࡇࡖࠫண"):[FgXzMs0YSDt(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴࠬத")]
			,wdftVMyzF17cYETHu(u"࠭ࡋࡐࡆࡌࡉࡒࡇࡄࡠࡃࡓࡔࠬ஥")	:[PlpyFa9QMKXxOD1cvHzmI(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡵ࡫ࡱࡽ࠳ࡩࡣ࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦࠪ஦"),FmYoGejTnwKME7d9zPc(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠲࠱࠳࠻࠲࡫ࡽࡳ࠯ࡵࡷࡳࡷ࡫ࠧ஧")]
			}
if BkM54Kr7Qbqn:
	SITESURLS[FmYoGejTnwKME7d9zPc(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩந")] = [I18uSKaWhgTBeYUPD4sr(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬன"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩப"),QjAINyUC7MDRq5d8e4vl9(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ஫"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ஬"),aOQTKXFL54Nl60Zhp3MbE(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ஭"),sIzDXlTHYUC5L3xZGnr(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧம"),O3OVuapf0YFjbm5oUQDg(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪய"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡧࡦࡶࡴࡤࡪࡤࠫர"),uulNDCPyef78(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬற"),vU6DxuzPwMpg(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵࡧࡻࡸࡷࡧࡰࡺࡶ࡫ࡳࡳࡩ࡯ࡥࡧࠪல"),I18uSKaWhgTBeYUPD4sr(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡥࡹࡧࡦࡹࡹ࡫ࡪࡴࠩள")]
	SITESURLS[o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓ࠵ࠬழ")] = [EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬவ"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩஶ"),EE1jeHnIoad(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨஷ"),FgXzMs0YSDt(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫஸ"),N6NGJ4vpmidqMCh7yo(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫஹ"),I18uSKaWhgTBeYUPD4sr(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ஺"),sJw9QWiq1Kr0xfeVRI(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ஻"),Hr25gta6XcqO(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡧࡦࡶࡴࡤࡪࡤࠫ஼"),s5WMHyQN4mpie(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ஽"),FmYoGejTnwKME7d9zPc(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵࡧࡻࡸࡷࡧࡰࡺࡶ࡫ࡳࡳࡩ࡯ࡥࡧࠪா"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡥࡹࡧࡦࡹࡹ࡫ࡪࡴࠩி")]
	SITESURLS[o1INZ3ViQqS0Uw5z6kMjbv(u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑ࠴ࠪீ")] = [LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩு"),jL5CrsRwebpyDVXUc1EQP(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭ூ"),o1INZ3ViQqS0Uw5z6kMjbv(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ௃"),aOQTKXFL54Nl60Zhp3MbE(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ௄"),sIzDXlTHYUC5L3xZGnr(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ௅"),KfHAW8VGbrxi(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫெ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧே"),ssynAg0zhSkoCpOMDV9(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨை"),SnhLjmfeJC(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩ௉"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧொ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡩࡽ࡫ࡣࡶࡶࡨ࡮ࡸ࠭ோ")]
	SITESURLS[ssynAg0zhSkoCpOMDV9(u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖ࠳ࠨௌ")] = [FgXzMs0YSDt(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡭ࡰࡱࡲ࠲ࡨࡵ࡭࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻ்ࠪ"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡮ࡱࡲࡳ࠳ࡩ࡯࡮࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ௎"),QjAINyUC7MDRq5d8e4vl9(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭௏"),wdftVMyzF17cYETHu(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩௐ"),uulNDCPyef78(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩ௑"),SnhLjmfeJC(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡲࡵ࡯ࡰ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ௒"),s5WMHyQN4mpie(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡳ࡯ࡰࡱ࠱ࡧࡴࡳ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ௓"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡭ࡰࡱࡲ࠲ࡨࡵ࡭࠰ࡥࡤࡴࡹࡩࡨࡢࠩ௔"),QjAINyUC7MDRq5d8e4vl9(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡮ࡱࡲࡳ࠳ࡩ࡯࡮࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪ௕"),CsDcLqQUVK4YBvHFW1(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨ௖"),Hr25gta6XcqO(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳ࡪࡾࡥࡤࡷࡷࡩ࡯ࡹࠧௗ")]
else:
	SITESURLS[ssynAg0zhSkoCpOMDV9(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ௘")] = [sIzDXlTHYUC5L3xZGnr(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ௙"),vU6DxuzPwMpg(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ௚"),FmYoGejTnwKME7d9zPc(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ௛"),vU6DxuzPwMpg(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ௜"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ௝"),SnhLjmfeJC(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ௞"),ggjO5CrKVRPITaesWkxD(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ௟"),ssynAg0zhSkoCpOMDV9(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡧࡦࡶࡴࡤࡪࡤࠫ௠"),oRJAfwD957WkUyBM1Ehu8m(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ௡"),QjAINyUC7MDRq5d8e4vl9(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡧࡻࡸࡷࡧࡰࡺࡶ࡫ࡳࡳࡩ࡯ࡥࡧࠪ௢"),vU6DxuzPwMpg(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡥࡹࡧࡦࡹࡹ࡫ࡪࡴࠩ௣")]
	SITESURLS[ssynAg0zhSkoCpOMDV9(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒ࠴ࠫ௤")] = [FgXzMs0YSDt(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ௥"),AAbvaXV2DQzfNHdm4U3tT(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ௦"),I18uSKaWhgTBeYUPD4sr(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭௧"),FgXzMs0YSDt(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ௨"),SnhLjmfeJC(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩ௩"),vU6DxuzPwMpg(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ௪"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ௫"),FmYoGejTnwKME7d9zPc(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡥࡤࡴࡹࡩࡨࡢࠩ௬"),wdftVMyzF17cYETHu(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪ௭"),sIzDXlTHYUC5L3xZGnr(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨ௮"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡪࡾࡥࡤࡷࡷࡩ࡯ࡹࠧ௯")]
	SITESURLS[Hr25gta6XcqO(u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐ࠳ࠩ௰")] = [V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨ௱"),FgXzMs0YSDt(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬ௲"),QjAINyUC7MDRq5d8e4vl9(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ௳"),KfHAW8VGbrxi(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ௴"),ggjO5CrKVRPITaesWkxD(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧ௵"),sIzDXlTHYUC5L3xZGnr(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ௶"),jL5CrsRwebpyDVXUc1EQP(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭௷"),s5WMHyQN4mpie(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧ௸"),PlpyFa9QMKXxOD1cvHzmI(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨ௹"),FmYoGejTnwKME7d9zPc(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡪࡾࡴࡳࡣࡳࡽࡹ࡮࡯࡯ࡥࡲࡨࡪ࠭௺"),aOQTKXFL54Nl60Zhp3MbE(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡨࡼࡪࡩࡵࡵࡧ࡭ࡷࠬ௻")]
	SITESURLS[I18uSKaWhgTBeYUPD4sr(u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠹ࠧ௼")] = [C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭௽"),FgXzMs0YSDt(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ௾"),vU6DxuzPwMpg(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ௿"),vU6DxuzPwMpg(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬఀ"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬఁ"),O3OVuapf0YFjbm5oUQDg(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨం"),o1INZ3ViQqS0Uw5z6kMjbv(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫః"),sJw9QWiq1Kr0xfeVRI(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬఄ"),uulNDCPyef78(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭అ"),ssynAg0zhSkoCpOMDV9(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡨࡼࡹࡸࡡࡱࡻࡷ࡬ࡴࡴࡣࡰࡦࡨࠫఆ"),I18uSKaWhgTBeYUPD4sr(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡦࡺࡨࡧࡺࡺࡥ࡫ࡵࠪఇ")]
api_python_actions = [C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧࡍࡋࡖࡘࡕࡒࡁ࡚ࠩఈ"),ssynAg0zhSkoCpOMDV9(u"ࠨࡔࡈࡔࡔࡘࡔࡔࠩఉ"),PlpyFa9QMKXxOD1cvHzmI(u"ࠩࡈࡑࡆࡏࡌࡔࠩఊ"),N6NGJ4vpmidqMCh7yo(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬఋ"),SnhLjmfeJC(u"ࠫࡎ࡙ࡌࡂࡏࡌࡇࡘ࠭ఌ"),KfHAW8VGbrxi(u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨ఍"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠭ࡋࡏࡑ࡚ࡒࡊࡘࡒࡐࡔࡖࠫఎ"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠧࡄࡃࡓࡘࡈࡎࡁࠨఏ"),oRJAfwD957WkUyBM1Ehu8m(u"ࠨࡖࡈࡗ࡙ࡏࡎࡈࠩఐ"),EE1jeHnIoad(u"ࠩࡈ࡜࡙ࡘࡁࡑ࡛ࡗࡌࡔࡔࡃࡐࡆࡈࠫ఑"),Hr25gta6XcqO(u"ࠪࡉ࡝ࡋࡃࡖࡖࡈࡎࡘ࠭ఒ")]
api_repos_actions = [sIzDXlTHYUC5L3xZGnr(u"ࠫࡆࡊࡄࡐࡐࡖࠫఓ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠬࡇࡄࡅࡑࡑࡗ࠶࠾ࠧఔ"),sIzDXlTHYUC5L3xZGnr(u"࠭ࡁࡅࡆࡒࡒࡘ࠷࠹ࠨక")]
tFkvuaLGpKHMI2l5J = LhFAGlQ19zr
mzAtNn5gGow2Z = LhFAGlQ19zr
g7OiLZfAHNlPJEUQCyx2pIrj = LhFAGlQ19zr
HA9kv8mRpfV = EsCplGc5N4mBuYW0RVQt6b
resolveonly = LhFAGlQ19zr
g503yRKdMjBLnGw2E4SuOvVH9t = LhFAGlQ19zr
ALLOW_DNS_FIX = zA8Ry1KDvmr3w4B5xeP
ALLOW_PROXY_FIX = zA8Ry1KDvmr3w4B5xeP
ALLOW_SHOWDIALOGS_FIX = zA8Ry1KDvmr3w4B5xeP
menuItemsLIST = []
SEND_THESE_EVENTS = []
FORWARDS_HOSTNAMES = {}
menuItemsDICT = {}
BADSCRAPERS = []
BADWEBSITES = [uulNDCPyef78(u"ࠧࡇࡗࡖࡌࡆࡘࡔࡗࠩఖ"),PlpyFa9QMKXxOD1cvHzmI(u"ࠨࡆࡕࡅࡒࡇࡃࡂࡈࡈࠫగ"),QjAINyUC7MDRq5d8e4vl9(u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪఘ"),sJw9QWiq1Kr0xfeVRI(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬఙ"),EE1jeHnIoad(u"ࠫࡑࡇࡒࡐ࡜ࡄࠫచ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧఛ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࡙࠭ࡂࡓࡒࡘࠬజ")]
BADCOMMONIDS = [EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧ࠺࠻࠼࠽࠲࠿࠹࠺࠻࠰࠽࠾࠿࠹࠮࠻࠼࠽࠾࠳࠰࠱࠲࠳ࠫఝ"),uulNDCPyef78(u"ࠨ࠻࠼࠼࠽࠳࠷࠸࠸࠹࠱࠺࠻࠴࠵࠯࠶࠷࠷࠸࠭࠳࠲࠻࠺ࠬఞ")]
GEOLOCATION_DATA = fy8iFgEkrO12NR9TWBI35sjY6qHvV
AV_CLIENT_IDS = fy8iFgEkrO12NR9TWBI35sjY6qHvV
DNS_SERVERS = [AAbvaXV2DQzfNHdm4U3tT(u"ࠩ࠴࠲࠶࠴࠱࠯࠳ࠪట"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪ࠼࠳࠾࠮࠹࠰࠻ࠫఠ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠫ࠶࠴࠰࠯࠲࠱࠵ࠬడ"),jL5CrsRwebpyDVXUc1EQP(u"ࠬ࠾࠮࠹࠰࠷࠲࠹࠭ఢ"),N6NGJ4vpmidqMCh7yo(u"࠭࠲࠱࠺࠱࠺࠼࠴࠲࠳࠴࠱࠶࠷࠸ࠧణ"),vU6DxuzPwMpg(u"ࠧ࠳࠲࠻࠲࠻࠽࠮࠳࠴࠳࠲࠷࠸࠰ࠨత")]
busydialog_active = LhFAGlQ19zr
dns_succeeded_urls = []
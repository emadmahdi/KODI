﻿# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'ALMAAREF'
headers = {'User-Agent':fy8iFgEkrO12NR9TWBI35sjY6qHvV}
K2l9rLfvoXxyZ4NYapO = '_MRF_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text,jmI9qRnVJo2a3tpcH8gfYkP):
	if   mode==40: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==41: OmsWt89dSA5HyCZ4wL = uEyU2e6lv4()
	elif mode==42: OmsWt89dSA5HyCZ4wL = TOCtp8JiB5U2d4(text,jmI9qRnVJo2a3tpcH8gfYkP)
	elif mode==43: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==44: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(text,jmI9qRnVJo2a3tpcH8gfYkP)
	elif mode==49: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,49)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('live',K2l9rLfvoXxyZ4NYapO+'البث الحي لقناة المعارف',fy8iFgEkrO12NR9TWBI35sjY6qHvV,41)
	TOCtp8JiB5U2d4(fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1')
	return
def v8g3VIz4fLu0(yJWh5lC4wcNrRi3nFa,dqCOQli2FLGnSw):
	search,sort,tKWF9uPXTEifS1hmY,fnogyzNA30JCPMYqHTavG7ZKp,XBcxQRa731 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,[],[],[],[]
	O4On5rLamD7q1zKBo6WfF3eEbS98,WGn3yrAqVgKdsaXo = lNyxXsMAcYHBUDh4dJbfTWR(yJWh5lC4wcNrRi3nFa)
	for srR9AuG6Pf8powqU4ixL5Ecl in list(WGn3yrAqVgKdsaXo.keys()):
		value = WGn3yrAqVgKdsaXo[srR9AuG6Pf8powqU4ixL5Ecl]
		if not value: continue
		if   srR9AuG6Pf8powqU4ixL5Ecl=='sort': sort = [value]
		elif srR9AuG6Pf8powqU4ixL5Ecl=='series': tKWF9uPXTEifS1hmY = [value]
		elif srR9AuG6Pf8powqU4ixL5Ecl=='search': search = value
		elif srR9AuG6Pf8powqU4ixL5Ecl=='category': fnogyzNA30JCPMYqHTavG7ZKp = [value]
		elif srR9AuG6Pf8powqU4ixL5Ecl=='specialist': XBcxQRa731 = [value]
	B7gtJnK24RY = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":fnogyzNA30JCPMYqHTavG7ZKp,"specialist":XBcxQRa731,"series":tKWF9uPXTEifS1hmY,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(dqCOQli2FLGnSw)}}
	B7gtJnK24RY = Qra2CWgebk.dumps(B7gtJnK24RY)
	bigdh7fpZYl4aT2keV = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'POST',bigdh7fpZYl4aT2keV,B7gtJnK24RY,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ALMAAREF-REQUEST_DATA_PAGE-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	data = LB7TcZnGYdfw5lWU1RH3Oztu9PyA('dict',FGRX4myP68S)
	return data
def TOCtp8JiB5U2d4(yJWh5lC4wcNrRi3nFa,level):
	VuGmoESTAfXlv5tD76PW1Masq0peB = v8g3VIz4fLu0(yJWh5lC4wcNrRi3nFa,'1')
	wlJ6d8hEvpoMNSCmU = VuGmoESTAfXlv5tD76PW1Masq0peB['facets']
	if level=='1':
		wlJ6d8hEvpoMNSCmU = wlJ6d8hEvpoMNSCmU['video_categories']
		items = EcQxOa3RJm86WjTKA.findall('<div(.*?)/div>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for j25T6eKhaMk3 in items:
			vY3c0hwATVGP7dn8bHCig6 = EcQxOa3RJm86WjTKA.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',j25T6eKhaMk3+'<',EcQxOa3RJm86WjTKA.DOTALL)
			if not vY3c0hwATVGP7dn8bHCig6: vY3c0hwATVGP7dn8bHCig6 = EcQxOa3RJm86WjTKA.findall('data-value=\\"(.*?)\\">(.*?)<',j25T6eKhaMk3+'<',EcQxOa3RJm86WjTKA.DOTALL)
			fnogyzNA30JCPMYqHTavG7ZKp,title = vY3c0hwATVGP7dn8bHCig6[0]
			if gZlSEJaXO9F461AL3sR7rWNpqf: title = XXcPiylRDh6IapYA25rwO8u(title)
			if not yJWh5lC4wcNrRi3nFa: OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,fy8iFgEkrO12NR9TWBI35sjY6qHvV,42,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'2','?category='+fnogyzNA30JCPMYqHTavG7ZKp)
			else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,fy8iFgEkrO12NR9TWBI35sjY6qHvV,42,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'2',yJWh5lC4wcNrRi3nFa+'&category='+fnogyzNA30JCPMYqHTavG7ZKp)
	if level=='2':
		wlJ6d8hEvpoMNSCmU = wlJ6d8hEvpoMNSCmU['specialist']
		items = EcQxOa3RJm86WjTKA.findall('value="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for XBcxQRa731,title in items:
			if gZlSEJaXO9F461AL3sR7rWNpqf: title = XXcPiylRDh6IapYA25rwO8u(title)
			if not XBcxQRa731: title = title = 'الجميع'
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,fy8iFgEkrO12NR9TWBI35sjY6qHvV,42,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'3',yJWh5lC4wcNrRi3nFa+'&specialist='+XBcxQRa731)
	elif level=='3':
		wlJ6d8hEvpoMNSCmU = wlJ6d8hEvpoMNSCmU['series']
		items = EcQxOa3RJm86WjTKA.findall('value="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for tKWF9uPXTEifS1hmY,title in items:
			if gZlSEJaXO9F461AL3sR7rWNpqf: title = XXcPiylRDh6IapYA25rwO8u(title)
			if not tKWF9uPXTEifS1hmY: title = title = 'الجميع'
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,fy8iFgEkrO12NR9TWBI35sjY6qHvV,42,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'4',yJWh5lC4wcNrRi3nFa+'&series='+tKWF9uPXTEifS1hmY)
	elif level=='4':
		wlJ6d8hEvpoMNSCmU = wlJ6d8hEvpoMNSCmU['sort_video']
		items = EcQxOa3RJm86WjTKA.findall('value="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for sort,title in items:
			if not sort: continue
			if gZlSEJaXO9F461AL3sR7rWNpqf: title = XXcPiylRDh6IapYA25rwO8u(title)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,fy8iFgEkrO12NR9TWBI35sjY6qHvV,44,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1',yJWh5lC4wcNrRi3nFa+'&sort='+sort)
	return
def HAsKeZdTbqjPI1WY(yJWh5lC4wcNrRi3nFa,dqCOQli2FLGnSw):
	VuGmoESTAfXlv5tD76PW1Masq0peB = v8g3VIz4fLu0(yJWh5lC4wcNrRi3nFa,dqCOQli2FLGnSw)
	wlJ6d8hEvpoMNSCmU = VuGmoESTAfXlv5tD76PW1Masq0peB['template']
	items = EcQxOa3RJm86WjTKA.findall('src="(.*?)".*?href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for POjaBmHqzpsx1IYw7kQM4R,bigdh7fpZYl4aT2keV,title in items:
		if gZlSEJaXO9F461AL3sR7rWNpqf: title = XXcPiylRDh6IapYA25rwO8u(title)
		OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,43,POjaBmHqzpsx1IYw7kQM4R)
	wlJ6d8hEvpoMNSCmU = VuGmoESTAfXlv5tD76PW1Masq0peB['facets']['pagination']
	items = EcQxOa3RJm86WjTKA.findall('data-page="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for jmI9qRnVJo2a3tpcH8gfYkP,title in items:
		if dqCOQli2FLGnSw==jmI9qRnVJo2a3tpcH8gfYkP: continue
		if gZlSEJaXO9F461AL3sR7rWNpqf: title = XXcPiylRDh6IapYA25rwO8u(title)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,fy8iFgEkrO12NR9TWBI35sjY6qHvV,44,fy8iFgEkrO12NR9TWBI35sjY6qHvV,jmI9qRnVJo2a3tpcH8gfYkP,yJWh5lC4wcNrRi3nFa)
	return
def rr7SfotkneX85Klup(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ALMAAREF-PLAY-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall('<video src="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall('youtube_url.*?(http.*?)&',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	hFzEyHWOoRxG = []
	if bigdh7fpZYl4aT2keV:
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[0].replace('\/','/')
		hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(hFzEyHWOoRxG,BfWYUAnyg6eONLjiuE,'video',url)
	return
def uEyU2e6lv4():
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/بث-مباشر',fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ALMAAREF-LIVE-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	url = EcQxOa3RJm86WjTKA.findall('"svpPlayer".*?(http.*?)&',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	url = url[0].replace('\\',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	E7HR1ZcMuzUs9XCVrNGJYi(url,BfWYUAnyg6eONLjiuE,'live')
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	jmbK6raMgeoAC = False
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV:
		search = GFYl1tsoOkHC0Ajeur8JQiMx()
		jmbK6raMgeoAC = True
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	if not jmbK6raMgeoAC: HAsKeZdTbqjPI1WY('?search='+search,'1')
	else: TOCtp8JiB5U2d4('?search='+search,'1')
	return
# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'FASELHD1'
headers = {'User-Agent':fy8iFgEkrO12NR9TWBI35sjY6qHvV}
K2l9rLfvoXxyZ4NYapO = '_FH1_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['جوائز الأوسكار','المراجعات','wwe']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==570: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==571: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,text)
	elif mode==572: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==573: OmsWt89dSA5HyCZ4wL = VNPHFcK5wvfL67Roir0Y(url,text)
	elif mode==576: OmsWt89dSA5HyCZ4wL = EEzGNBZSCnKkLJQa97fvqjeFoT()
	elif mode==579: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH('link',K2l9rLfvoXxyZ4NYapO+'لماذا الموقع بطيء',fy8iFgEkrO12NR9TWBI35sjY6qHvV,576)
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ,url = BOI3t1w8qfHAb0Kl4oMye7haEWS,BOI3t1w8qfHAb0Kl4oMye7haEWS
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FASELHD1-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ,579,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'المميزة',VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ,571,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'featured1')
	items = EcQxOa3RJm86WjTKA.findall('class="h3">(.*?)<.*?href="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	for title,bigdh7fpZYl4aT2keV in items:
		OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,571,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'details1')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"menu-primary"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		acnd3zbICVLtm2JFvWhforQ = EcQxOa3RJm86WjTKA.findall('<li (.*?)</li>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		jATs4xyXeEWSmrGIH = [fy8iFgEkrO12NR9TWBI35sjY6qHvV,'أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		b3b24XZTV7gW9mhcqLoCnftO = 0
		for ffqUAI9tudHkKSblEYv30aJjo in acnd3zbICVLtm2JFvWhforQ:
			if b3b24XZTV7gW9mhcqLoCnftO>0: OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)<',ffqUAI9tudHkKSblEYv30aJjo,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title in items:
				if bigdh7fpZYl4aT2keV=='#': continue
				if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+bigdh7fpZYl4aT2keV
				if title==fy8iFgEkrO12NR9TWBI35sjY6qHvV: continue
				if any(value in title.lower() for value in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o): continue
				title = jATs4xyXeEWSmrGIH[b3b24XZTV7gW9mhcqLoCnftO]+title
				OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,571,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'details2')
			b3b24XZTV7gW9mhcqLoCnftO += 1
	return
def EEzGNBZSCnKkLJQa97fvqjeFoT():
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def HAsKeZdTbqjPI1WY(url,type=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FASELHD1-TITLES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	UgbWFLzrCA5RMo7tjwNmdyc68khBGn = EcQxOa3RJm86WjTKA.findall('class="h4">(.*?)</div>(.*?)"container"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not UgbWFLzrCA5RMo7tjwNmdyc68khBGn: return
	if type=='filters':
		z6PX2p7diaskQElBOvMRNcHwqG5D = [FGRX4myP68S.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"homeSlide"(.*?)"container"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		SnPHJ6yl8Yr1EwTtbpNB7QMIDmg4oz,zzECVswWcGAIXhrQlZ7jMokugnv,p7Gkego0m6a8 = zip(*items)
		items = zip(zzECVswWcGAIXhrQlZ7jMokugnv,SnPHJ6yl8Yr1EwTtbpNB7QMIDmg4oz,p7Gkego0m6a8)
	elif type=='featured2':
		title,wlJ6d8hEvpoMNSCmU = UgbWFLzrCA5RMo7tjwNmdyc68khBGn[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	elif type=='details2' and len(UgbWFLzrCA5RMo7tjwNmdyc68khBGn)>1:
		title = UgbWFLzrCA5RMo7tjwNmdyc68khBGn[0][0]
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,571,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'featured2')
		title = UgbWFLzrCA5RMo7tjwNmdyc68khBGn[1][0]
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,571,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'details3')
		return
	else:
		title,wlJ6d8hEvpoMNSCmU = UgbWFLzrCA5RMo7tjwNmdyc68khBGn[-1]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	cmDaLEqWlT7GhonIdX5k1zHQjSiupe = []
	for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
		if any(value in title.lower() for value in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o): continue
		POjaBmHqzpsx1IYw7kQM4R = XXcPiylRDh6IapYA25rwO8u(POjaBmHqzpsx1IYw7kQM4R)
		POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R.split('?resize=')[0]
		title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
		RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) (الحلقة|حلقة).\d+',title,EcQxOa3RJm86WjTKA.DOTALL)
		if '/collections/' in bigdh7fpZYl4aT2keV:
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,571,POjaBmHqzpsx1IYw7kQM4R)
		elif RrzpbE3t9woCk7MXS0GvNdi1BcV and type==fy8iFgEkrO12NR9TWBI35sjY6qHvV:
			title = '_MOD_'+RrzpbE3t9woCk7MXS0GvNdi1BcV[0][0]
			title = title.strip(' –')
			if title not in cmDaLEqWlT7GhonIdX5k1zHQjSiupe:
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,573,POjaBmHqzpsx1IYw7kQM4R)
				cmDaLEqWlT7GhonIdX5k1zHQjSiupe.append(title)
		elif 'episodes/' in bigdh7fpZYl4aT2keV or 'movies/' in bigdh7fpZYl4aT2keV or 'hindi/' in bigdh7fpZYl4aT2keV:
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,572,POjaBmHqzpsx1IYw7kQM4R)
		else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,573,POjaBmHqzpsx1IYw7kQM4R)
	if type=='filters':
		RR6L0Hg8km2GPorNFwyD = EcQxOa3RJm86WjTKA.findall('"more_button_page":(.*?),',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if RR6L0Hg8km2GPorNFwyD:
			count = RR6L0Hg8km2GPorNFwyD[0]
			bigdh7fpZYl4aT2keV = url+'/offset/'+count
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة أخرى',bigdh7fpZYl4aT2keV,571,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filters')
	elif 'details' in type:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall("class='pagination(.*?)</div>",FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall("href='(.*?)'.*?>(.*?)<",wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title in items:
				title = 'صفحة '+IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,571,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'details4')
	return
def VNPHFcK5wvfL67Roir0Y(url,type=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FASELHD1-SEASONS_EPISODES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	CSX1FDkQOU = False
	if not type:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"seasonList"(.*?)"container"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			if len(items)>1:
				VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = VbHeOuU1ilzSp2ZRXwBD(url,'url')
				CSX1FDkQOU = True
				for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,name,title in items:
					name = IVcCL3aAfU9wS7kWev1g2XBjZRJ(name)
					if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+bigdh7fpZYl4aT2keV
					title = name+' - '+title
					OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,573,POjaBmHqzpsx1IYw7kQM4R,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'episodes')
	if type=='episodes' or not CSX1FDkQOU:
		mmEsSwOKazXLV1MT = EcQxOa3RJm86WjTKA.findall('"posterImg".*?src="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if mmEsSwOKazXLV1MT: POjaBmHqzpsx1IYw7kQM4R = mmEsSwOKazXLV1MT[0]
		else: POjaBmHqzpsx1IYw7kQM4R = fy8iFgEkrO12NR9TWBI35sjY6qHvV
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"epAll"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title in items:
				title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
				title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
				OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,572,POjaBmHqzpsx1IYw7kQM4R)
	return
def rr7SfotkneX85Klup(url):
	hFzEyHWOoRxG,NRBhjC91QHlmcqp6KwgntE,kENjB56TStKh = [],[],[]
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FASELHD1-PLAY-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	AUE2IHWYJZ = EcQxOa3RJm86WjTKA.findall('مستوى المشاهدة.*?">(.*?)</span>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if AUE2IHWYJZ:
		uuigJsvIZQ3tprnhxG = EcQxOa3RJm86WjTKA.findall('"tag">(.*?)</a>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if uuigJsvIZQ3tprnhxG and SYJvigbI3fts(BfWYUAnyg6eONLjiuE,url,uuigJsvIZQ3tprnhxG): return
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"videoRow"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('src="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV in items:
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.split('&img=')[0]
			hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV+'?named=__embed')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="streamHeader(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall("href = '(.*?)'.*?</i>(.*?)</a>",wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,name in items:
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.split('&img=')[0]
			name = name.strip(ksJdoFWhxTz8Y2N7bOZE)
			hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV+'?named='+name+'__watch')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="downloadLinks(.*?)blackwindow',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?</span>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,name in items:
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.split('&img=')[0]
			hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV+'?named='+name+'__download')
	for Z5Zl8LgtDFrJKOsnzXxc4f1UpN in hFzEyHWOoRxG:
		bigdh7fpZYl4aT2keV,name = Z5Zl8LgtDFrJKOsnzXxc4f1UpN.split('?named')
		if bigdh7fpZYl4aT2keV not in NRBhjC91QHlmcqp6KwgntE:
			NRBhjC91QHlmcqp6KwgntE.append(bigdh7fpZYl4aT2keV)
			kENjB56TStKh.append(Z5Zl8LgtDFrJKOsnzXxc4f1UpN)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(kENjB56TStKh,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	YLKFRH6sSIrznXBg = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/?s='+search
	HAsKeZdTbqjPI1WY(YLKFRH6sSIrznXBg,'details5')
	return
# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'SHAHID4U'
K2l9rLfvoXxyZ4NYapO = '_SH4_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
headers = {'User-Agent':j4lUV5BzHDI6EN(True)}
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==110: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==111: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,text)
	elif mode==112: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==113: OmsWt89dSA5HyCZ4wL = eQgbVPaIBvTn8fsjJRt241(url,True)
	elif mode==114: OmsWt89dSA5HyCZ4wL = F4ehkvPDxXU(url,'FULL_FILTER___'+text)
	elif mode==115: OmsWt89dSA5HyCZ4wL = F4ehkvPDxXU(url,'DEFINED_FILTER___'+text)
	elif mode==116: OmsWt89dSA5HyCZ4wL = eQgbVPaIBvTn8fsjJRt241(url,False)
	elif mode==119: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SHAHID4U-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = VbHeOuU1ilzSp2ZRXwBD(E6ECvznP9m5sWFMu.url,'url')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,119,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فلتر محدد',VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ,115)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فلتر كامل',VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ,114)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'المميزة',VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ,111,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'featured')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('simple-filter(.*?)adv-filter',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not z6PX2p7diaskQElBOvMRNcHwqG5D:
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for filter,POjaBmHqzpsx1IYw7kQM4R,title in items:
			url = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+filter
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,url,111,POjaBmHqzpsx1IYw7kQM4R,fy8iFgEkrO12NR9TWBI35sjY6qHvV,filter)
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="dropdown"(.*?)<script>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			title = title.replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(FFkml6ZbgXD,fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE)
			if title in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
			if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+bigdh7fpZYl4aT2keV
			if 'netflix' in bigdh7fpZYl4aT2keV: title = 'نيتفلكس'
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,111)
	return FGRX4myP68S
def HAsKeZdTbqjPI1WY(url,H1yrgtivdZBUk2NOGx4LncKFSYCWX=fy8iFgEkrO12NR9TWBI35sjY6qHvV,E6ECvznP9m5sWFMu=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if not E6ECvznP9m5sWFMu: E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SHAHID4U-TITLES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D,items,cmDaLEqWlT7GhonIdX5k1zHQjSiupe = [],[],[]
	if H1yrgtivdZBUk2NOGx4LncKFSYCWX=='featured': z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('glide__slides(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	else: z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('shows-container(.*?)pagination',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not z6PX2p7diaskQElBOvMRNcHwqG5D: return
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	if not items: items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)</h4>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	mmO39lwp0LFUrVT = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
		if 'WWE' in title: continue
		if 'javascript' in bigdh7fpZYl4aT2keV: continue
		bigdh7fpZYl4aT2keV = U2Z7CVFftTmLeK3nzEbQPGga(bigdh7fpZYl4aT2keV).strip('/')
		title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
		title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
		RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) الحلقة \d+',title,EcQxOa3RJm86WjTKA.DOTALL)
		if '/film/' in bigdh7fpZYl4aT2keV or 'فيلم' in bigdh7fpZYl4aT2keV or any(value in title for value in mmO39lwp0LFUrVT):
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,112,POjaBmHqzpsx1IYw7kQM4R)
		elif RrzpbE3t9woCk7MXS0GvNdi1BcV and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + RrzpbE3t9woCk7MXS0GvNdi1BcV[0]
			if title not in cmDaLEqWlT7GhonIdX5k1zHQjSiupe:
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,113,POjaBmHqzpsx1IYw7kQM4R)
				cmDaLEqWlT7GhonIdX5k1zHQjSiupe.append(title)
		elif '/actor/' in bigdh7fpZYl4aT2keV:
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,111,POjaBmHqzpsx1IYw7kQM4R)
		elif '/series/' in bigdh7fpZYl4aT2keV and '/list' not in url:
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'/list'
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,111,POjaBmHqzpsx1IYw7kQM4R)
		elif '/list' in url and 'حلقة' in title:
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,112,POjaBmHqzpsx1IYw7kQM4R)
		else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,113,POjaBmHqzpsx1IYw7kQM4R)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"pagination"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		if H1yrgtivdZBUk2NOGx4LncKFSYCWX!='search': items = EcQxOa3RJm86WjTKA.findall('(updateQuery).*?>(.+?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		else: items = EcQxOa3RJm86WjTKA.findall('<li>.*?href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if 'page=' in url: url = url.split('page=',1)[0][:-1]
		for bigdh7fpZYl4aT2keV,title in items:
			title = title.replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(FFkml6ZbgXD,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			if H1yrgtivdZBUk2NOGx4LncKFSYCWX!='search':
				if '?' in url: bigdh7fpZYl4aT2keV = url+'&page='+title
				else: bigdh7fpZYl4aT2keV = url+'?page='+title
			title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
			if title: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,111,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,H1yrgtivdZBUk2NOGx4LncKFSYCWX)
	return
def eQgbVPaIBvTn8fsjJRt241(url,Uh0AWcTef7DKo):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SHAHID4U-EPISODES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('items d-flex(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if len(z6PX2p7diaskQElBOvMRNcHwqG5D)>1:
		if '/season/' in z6PX2p7diaskQElBOvMRNcHwqG5D[0]: CSX1FDkQOU,jbpHA8eDFYwlT = z6PX2p7diaskQElBOvMRNcHwqG5D[0],z6PX2p7diaskQElBOvMRNcHwqG5D[1]
		else: CSX1FDkQOU,jbpHA8eDFYwlT = z6PX2p7diaskQElBOvMRNcHwqG5D[1],z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	else: CSX1FDkQOU,jbpHA8eDFYwlT = z6PX2p7diaskQElBOvMRNcHwqG5D[0],z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	for b3b24XZTV7gW9mhcqLoCnftO in range(2):
		if Uh0AWcTef7DKo: mode,type,wlJ6d8hEvpoMNSCmU = 116,'folder',CSX1FDkQOU
		else: mode,type,wlJ6d8hEvpoMNSCmU = 112,'video',jbpHA8eDFYwlT
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if Uh0AWcTef7DKo and len(items)<2:
			Uh0AWcTef7DKo = False
			continue
		for bigdh7fpZYl4aT2keV,c9LD37hsJzqNi2lQVWIBwFgoYy,D4DQ6k0oS39GKbZrthnsTB in items:
			title = c9LD37hsJzqNi2lQVWIBwFgoYy+ksJdoFWhxTz8Y2N7bOZE+D4DQ6k0oS39GKbZrthnsTB
			OZD1l4pAMzeH(type,K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,mode)
		break
	if not items and '/episodes' in FGRX4myP68S:
		IpngyHN0hFoXLsZuEw7T1mzeAxCc = EcQxOa3RJm86WjTKA.findall('class="breadcrumb"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if IpngyHN0hFoXLsZuEw7T1mzeAxCc:
			wlJ6d8hEvpoMNSCmU = IpngyHN0hFoXLsZuEw7T1mzeAxCc[0]
			zzECVswWcGAIXhrQlZ7jMokugnv = EcQxOa3RJm86WjTKA.findall('href="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			if len(zzECVswWcGAIXhrQlZ7jMokugnv)>2:
				bigdh7fpZYl4aT2keV = zzECVswWcGAIXhrQlZ7jMokugnv[2]+'list'
				HAsKeZdTbqjPI1WY(bigdh7fpZYl4aT2keV)
	return
def rr7SfotkneX85Klup(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SHAHID4U-PLAY-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="actions(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not z6PX2p7diaskQElBOvMRNcHwqG5D: return
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	zzECVswWcGAIXhrQlZ7jMokugnv = EcQxOa3RJm86WjTKA.findall('href="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	k2MSZF8gU6jt1xqIv3mJO4ecu7LpNo = '/watch/' in wlJ6d8hEvpoMNSCmU
	download = '/download/' in wlJ6d8hEvpoMNSCmU
	if   k2MSZF8gU6jt1xqIv3mJO4ecu7LpNo and not download: DwxkvjU3K79Jn5gl0sioO6,lqmvZRnUphjTOIQCF4cGEK0HAwrL = zzECVswWcGAIXhrQlZ7jMokugnv[0],fy8iFgEkrO12NR9TWBI35sjY6qHvV
	elif not k2MSZF8gU6jt1xqIv3mJO4ecu7LpNo and download: DwxkvjU3K79Jn5gl0sioO6,lqmvZRnUphjTOIQCF4cGEK0HAwrL = fy8iFgEkrO12NR9TWBI35sjY6qHvV,zzECVswWcGAIXhrQlZ7jMokugnv[0]
	elif k2MSZF8gU6jt1xqIv3mJO4ecu7LpNo and download: DwxkvjU3K79Jn5gl0sioO6,lqmvZRnUphjTOIQCF4cGEK0HAwrL = zzECVswWcGAIXhrQlZ7jMokugnv[0],zzECVswWcGAIXhrQlZ7jMokugnv[1]
	else: DwxkvjU3K79Jn5gl0sioO6,lqmvZRnUphjTOIQCF4cGEK0HAwrL = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	XoSyx7p6dqZ1CF8 = []
	if k2MSZF8gU6jt1xqIv3mJO4ecu7LpNo:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',DwxkvjU3K79Jn5gl0sioO6,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SHAHID4U-PLAY-2nd')
		soEymUvkt19PQXVjzKau6x5 = E6ECvznP9m5sWFMu.content
		UgbWFLzrCA5RMo7tjwNmdyc68khBGn = EcQxOa3RJm86WjTKA.findall('let servers(.*?)player',soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL|EcQxOa3RJm86WjTKA.IGNORECASE)
		if UgbWFLzrCA5RMo7tjwNmdyc68khBGn:
			OOCx0SzAcisQIJGM6DZkopvB3 = UgbWFLzrCA5RMo7tjwNmdyc68khBGn[0]
			w7gedkFbJvcqu0fzW43NpyUP = EcQxOa3RJm86WjTKA.findall('"name":"(.*?)".*?"url":"(.*?)"',OOCx0SzAcisQIJGM6DZkopvB3,EcQxOa3RJm86WjTKA.DOTALL)
			for title,bigdh7fpZYl4aT2keV in w7gedkFbJvcqu0fzW43NpyUP:
				bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.replace('\\/','/')
				bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+title+'__watch'
				XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	if download:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',lqmvZRnUphjTOIQCF4cGEK0HAwrL,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SHAHID4U-PLAY-3rd')
		soEymUvkt19PQXVjzKau6x5 = E6ECvznP9m5sWFMu.content
		UgbWFLzrCA5RMo7tjwNmdyc68khBGn = EcQxOa3RJm86WjTKA.findall('"servers"(.*?)info-container',soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
		if UgbWFLzrCA5RMo7tjwNmdyc68khBGn:
			OOCx0SzAcisQIJGM6DZkopvB3 = UgbWFLzrCA5RMo7tjwNmdyc68khBGn[0]
			w7gedkFbJvcqu0fzW43NpyUP = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',OOCx0SzAcisQIJGM6DZkopvB3,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title,OOnVxtP0TNWsci6HrEGqBm9boKF7g in w7gedkFbJvcqu0fzW43NpyUP:
				bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+title+'__download'+'____'+OOnVxtP0TNWsci6HrEGqBm9boKF7g
				XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(XoSyx7p6dqZ1CF8,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if not search:
		search = GFYl1tsoOkHC0Ajeur8JQiMx()
		if not search: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/search?s='+search
	HAsKeZdTbqjPI1WY(url,'search')
	return
def dfqB809Vbp6nyMRcmHvwZ(url):
	url = url.split('/smartemadfilter?')[0]
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SHAHID4U-GET_FILTERS_BLOCKS-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	W1A4L5P0Zc8wHnUGjVexElz = []
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('adv-filter(.*?)shows-container',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		W1A4L5P0Zc8wHnUGjVexElz = EcQxOa3RJm86WjTKA.findall('''updateQuery\('(.*?)'.*?value.*?>(.*?)<(.*?)</select''',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		i6m2Skc3nesTYu7QjPJWbxlay,ny5fseD6KMzR8m3vSE,VuGmoESTAfXlv5tD76PW1Masq0peB = zip(*W1A4L5P0Zc8wHnUGjVexElz)
		W1A4L5P0Zc8wHnUGjVexElz = zip(ny5fseD6KMzR8m3vSE,i6m2Skc3nesTYu7QjPJWbxlay,VuGmoESTAfXlv5tD76PW1Masq0peB)
	return W1A4L5P0Zc8wHnUGjVexElz
def XkO6QiU8yILWlfg(wlJ6d8hEvpoMNSCmU):
	items = EcQxOa3RJm86WjTKA.findall('value="(.*?)".*?>\s*(.*?)\s*<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	return items
def rCk5v93oAu1dgc8tzlOB4(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	uHyjkzgiAsGW5ZIb9U6TlV = url.split('/smartemadfilter?')[0]
	EW6mPCkSQRzH3Yw8ITFpc4nv5M = VbHeOuU1ilzSp2ZRXwBD(url,'url')
	url = url.replace(uHyjkzgiAsGW5ZIb9U6TlV,EW6mPCkSQRzH3Yw8ITFpc4nv5M)
	url = url.replace('/smartemadfilter?','/?')
	return url
gFxHyVTwqu3CBirYP8 = ['quality','year','genre','category']
ddWq05NVRP = ['category','genre','year']
def F4ehkvPDxXU(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==fy8iFgEkrO12NR9TWBI35sjY6qHvV: NnQ1hEsTV7Zaz3HKdfu,QlOXcH07nRVPAZub8pD356xMvdk4 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	else: NnQ1hEsTV7Zaz3HKdfu,QlOXcH07nRVPAZub8pD356xMvdk4 = filter.split('___')
	if type=='DEFINED_FILTER':
		if ddWq05NVRP[0]+'=' not in NnQ1hEsTV7Zaz3HKdfu: fnogyzNA30JCPMYqHTavG7ZKp = ddWq05NVRP[0]
		for pk6YWixXFSrDLKCnlN39w in range(len(ddWq05NVRP[0:-1])):
			if ddWq05NVRP[pk6YWixXFSrDLKCnlN39w]+'=' in NnQ1hEsTV7Zaz3HKdfu: fnogyzNA30JCPMYqHTavG7ZKp = ddWq05NVRP[pk6YWixXFSrDLKCnlN39w+1]
		z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&'+fnogyzNA30JCPMYqHTavG7ZKp+'=0'
		ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&'+fnogyzNA30JCPMYqHTavG7ZKp+'=0'
		HfvJenZmN3O8rPcshLux2EyzDWpQCb = z7VI1OaUPqs4lXxb.strip('&')+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq.strip('&')
		F231lsuCKnaSMdQ48W6PoL = nKT1QuLoXPc8CjyV(QlOXcH07nRVPAZub8pD356xMvdk4,'modified_filters')
		YLKFRH6sSIrznXBg = url+'/smartemadfilter?'+F231lsuCKnaSMdQ48W6PoL
	elif type=='FULL_FILTER':
		QUFL2gEBMn63qlsmI7W = nKT1QuLoXPc8CjyV(NnQ1hEsTV7Zaz3HKdfu,'modified_values')
		QUFL2gEBMn63qlsmI7W = U2Z7CVFftTmLeK3nzEbQPGga(QUFL2gEBMn63qlsmI7W)
		if QlOXcH07nRVPAZub8pD356xMvdk4!=fy8iFgEkrO12NR9TWBI35sjY6qHvV: QlOXcH07nRVPAZub8pD356xMvdk4 = nKT1QuLoXPc8CjyV(QlOXcH07nRVPAZub8pD356xMvdk4,'modified_filters')
		if QlOXcH07nRVPAZub8pD356xMvdk4==fy8iFgEkrO12NR9TWBI35sjY6qHvV: YLKFRH6sSIrznXBg = url
		else: YLKFRH6sSIrznXBg = url+'/smartemadfilter?'+QlOXcH07nRVPAZub8pD356xMvdk4
		MYWwFs7XA2 = rCk5v93oAu1dgc8tzlOB4(YLKFRH6sSIrznXBg)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'أظهار قائمة الفيديو التي تم اختيارها ',MYWwFs7XA2,111)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+' [[   '+QUFL2gEBMn63qlsmI7W+'   ]]',MYWwFs7XA2,111)
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	W1A4L5P0Zc8wHnUGjVexElz = dfqB809Vbp6nyMRcmHvwZ(url)
	dict = {}
	for name,jLA9nhxoZbG,wlJ6d8hEvpoMNSCmU in W1A4L5P0Zc8wHnUGjVexElz:
		name = name.replace('كل ',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		items = XkO6QiU8yILWlfg(wlJ6d8hEvpoMNSCmU)
		if '=' not in YLKFRH6sSIrznXBg: YLKFRH6sSIrznXBg = url
		if type=='DEFINED_FILTER':
			if fnogyzNA30JCPMYqHTavG7ZKp!=jLA9nhxoZbG: continue
			elif len(items)<2:
				if jLA9nhxoZbG==ddWq05NVRP[-1]:
					MYWwFs7XA2 = rCk5v93oAu1dgc8tzlOB4(YLKFRH6sSIrznXBg)
					HAsKeZdTbqjPI1WY(MYWwFs7XA2)
				else: F4ehkvPDxXU(YLKFRH6sSIrznXBg,'DEFINED_FILTER___'+HfvJenZmN3O8rPcshLux2EyzDWpQCb)
				return
			else:
				if jLA9nhxoZbG==ddWq05NVRP[-1]:
					MYWwFs7XA2 = rCk5v93oAu1dgc8tzlOB4(YLKFRH6sSIrznXBg)
					OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع',MYWwFs7XA2,111)
				else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع',YLKFRH6sSIrznXBg,115,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,HfvJenZmN3O8rPcshLux2EyzDWpQCb)
		elif type=='FULL_FILTER':
			z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&'+jLA9nhxoZbG+'=0'
			ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&'+jLA9nhxoZbG+'=0'
			HfvJenZmN3O8rPcshLux2EyzDWpQCb = z7VI1OaUPqs4lXxb+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع :'+name,YLKFRH6sSIrznXBg,114,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,HfvJenZmN3O8rPcshLux2EyzDWpQCb)
		dict[jLA9nhxoZbG] = {}
		for value,srR9AuG6Pf8powqU4ixL5Ecl in items:
			if value=='196533': srR9AuG6Pf8powqU4ixL5Ecl = 'أفلام نيتفلكس'
			elif value=='196531': srR9AuG6Pf8powqU4ixL5Ecl = 'مسلسلات نيتفلكس'
			if srR9AuG6Pf8powqU4ixL5Ecl in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
			dict[jLA9nhxoZbG][value] = srR9AuG6Pf8powqU4ixL5Ecl
			z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&'+jLA9nhxoZbG+'='+srR9AuG6Pf8powqU4ixL5Ecl
			ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&'+jLA9nhxoZbG+'='+value
			QdzUcX2iR5 = z7VI1OaUPqs4lXxb+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq
			title = srR9AuG6Pf8powqU4ixL5Ecl+' :'#+dict[jLA9nhxoZbG]['0']
			title = srR9AuG6Pf8powqU4ixL5Ecl+' :'+name
			if type=='FULL_FILTER': OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,114,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QdzUcX2iR5)
			elif type=='DEFINED_FILTER' and ddWq05NVRP[-2]+'=' in NnQ1hEsTV7Zaz3HKdfu:
				F231lsuCKnaSMdQ48W6PoL = nKT1QuLoXPc8CjyV(ybEUMsLp4zBVPnuAYI0cCdowekDq,'modified_filters')
				YLKFRH6sSIrznXBg = url+'/smartemadfilter?'+F231lsuCKnaSMdQ48W6PoL
				MYWwFs7XA2 = rCk5v93oAu1dgc8tzlOB4(YLKFRH6sSIrznXBg)
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,MYWwFs7XA2,111)
			else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,115,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QdzUcX2iR5)
	return
def nKT1QuLoXPc8CjyV(p9UP6wGlC1BF7fN2,mode):
	p9UP6wGlC1BF7fN2 = p9UP6wGlC1BF7fN2.replace('=&','=0&')
	p9UP6wGlC1BF7fN2 = p9UP6wGlC1BF7fN2.strip('&')
	vpLWbVm35iM0l2TzYIN7 = {}
	if '=' in p9UP6wGlC1BF7fN2:
		items = p9UP6wGlC1BF7fN2.split('&')
		for j25T6eKhaMk3 in items:
			XJRx6urSNaOM5AfZdDsgQBYGt,value = j25T6eKhaMk3.split('=')
			vpLWbVm35iM0l2TzYIN7[XJRx6urSNaOM5AfZdDsgQBYGt] = value
	MKJaIb2sDSr4VCQGTqyX3nkWL = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	for key in gFxHyVTwqu3CBirYP8:
		if key in list(vpLWbVm35iM0l2TzYIN7.keys()): value = vpLWbVm35iM0l2TzYIN7[key]
		else: value = '0'
		if '%' not in value: value = DVX5GWhnIxYlSd9rEuetjk40UJ(value)
		if mode=='modified_values' and value!='0': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+' + '+value
		elif mode=='modified_filters' and value!='0': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+'&'+key+'='+value
		elif mode=='all': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+'&'+key+'='+value
	MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL.strip(' + ')
	MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL.strip('&')
	MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL.replace('=0','=')
	return MKJaIb2sDSr4VCQGTqyX3nkWL
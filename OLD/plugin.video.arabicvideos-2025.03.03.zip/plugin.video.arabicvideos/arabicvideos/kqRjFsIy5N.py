# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
import bs4 as vMj9zGZ7Igw
BfWYUAnyg6eONLjiuE = 'ELCINEMA'
K2l9rLfvoXxyZ4NYapO = '_ELC_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
headers = {'Referer':BOI3t1w8qfHAb0Kl4oMye7haEWS}
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = []
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==510: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==511: OmsWt89dSA5HyCZ4wL = ZyT0kmMUtKFJ897BORbuX213YCe(url)
	elif mode==512: OmsWt89dSA5HyCZ4wL = AvVnpbcxEyRBX(url)
	elif mode==513: OmsWt89dSA5HyCZ4wL = ROjSZnMNsVa9lX8BTI5i6fFyJw(url)
	elif mode==514: OmsWt89dSA5HyCZ4wL = MMatQbhsKv1YdrIW8iLz5U7pSE(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: OmsWt89dSA5HyCZ4wL = MMatQbhsKv1YdrIW8iLz5U7pSE(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: OmsWt89dSA5HyCZ4wL = mEjeUobZfphL3VHAQw8PYgsB(text)
	elif mode==517: OmsWt89dSA5HyCZ4wL = a4iMqGE0YSeOjUX9KxT1(url)
	elif mode==518: OmsWt89dSA5HyCZ4wL = BwQS7hv9F0(url)
	elif mode==519: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	elif mode==520: OmsWt89dSA5HyCZ4wL = yyAMizRwx7OGC(url)
	elif mode==521: OmsWt89dSA5HyCZ4wL = xxtPcXGI6SH2LN8vYAkdDWjeT(url)
	elif mode==522: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==523: OmsWt89dSA5HyCZ4wL = xxpUN6ZSLFOhrE2KmDu7jwfCiXBs(text)
	elif mode==524: OmsWt89dSA5HyCZ4wL = CdtMPFv5rGKR()
	elif mode==525: OmsWt89dSA5HyCZ4wL = qjm645V9tFQ8rlNDAvdzs1ECJ()
	elif mode==526: OmsWt89dSA5HyCZ4wL = RgSEBXs3UM()
	elif mode==527: OmsWt89dSA5HyCZ4wL = bUpf9Mv4KXjzxi0ASTdJw()
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث بموسوعة السينما',fy8iFgEkrO12NR9TWBI35sjY6qHvV,519)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'موسوعة الأعمال',fy8iFgEkrO12NR9TWBI35sjY6qHvV,525)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'موسوعة الأشخاص',fy8iFgEkrO12NR9TWBI35sjY6qHvV,526)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'موسوعة المصنفات',fy8iFgEkrO12NR9TWBI35sjY6qHvV,527)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'موسوعة المنوعات',fy8iFgEkrO12NR9TWBI35sjY6qHvV,524)
	return
def CdtMPFv5rGKR():
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+' فيديوهات - خاصة',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/video',520)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فيديوهات - أحدث',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/video/latest',521)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فيديوهات - أقدم',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/video/oldest',521)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فيديوهات - أكثر مشاهدة',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/video/views',521)
	return
def qjm645V9tFQ8rlNDAvdzs1ECJ():
	cmVLNEXM3bsqgixS8CT = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/lineup?utf8=%E2%9C%93'
	CzkBhKd4i1W7NxwQH3gcTPmrS2v = cmVLNEXM3bsqgixS8CT+'&type=2&category=1&foreign=false&tag='
	BVsOo69jbkplmYqvJtu7Az4PayrdSI = cmVLNEXM3bsqgixS8CT+'&type=2&category=3&foreign=false&tag='
	uLgAI3YMQElpPC = cmVLNEXM3bsqgixS8CT+'&type=2&category=1&foreign=true&tag='
	I9UJ4EXAGWQKbR0iOFghSTkadH8BYp = cmVLNEXM3bsqgixS8CT+'&type=2&category=3&foreign=true&tag='
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مصنفات أفلام عربي',CzkBhKd4i1W7NxwQH3gcTPmrS2v,511)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مصنفات مسلسلات عربي',BVsOo69jbkplmYqvJtu7Az4PayrdSI,511)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مصنفات أفلام اجنبي',uLgAI3YMQElpPC,511)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مصنفات مسلسلات اجنبي',I9UJ4EXAGWQKbR0iOFghSTkadH8BYp,511)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فهرس أعمال أبجدي',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/index/work/alphabet',517)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فهرس  بلد الإنتاج',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/index/work/country',517)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فهرس اللغة',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/index/work/language',517)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فهرس مصنفات العمل',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/index/work/genre',517)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فهرس سنة الإصدار',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/index/work/release_year',517)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مواسم - فلتر محدد',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/seasonals',515)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مواسم - فلتر كامل',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/seasonals',514)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مصنفات - فلتر محدد',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/lineup',515)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مصنفات - فلتر كامل',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/lineup',514)
	return
def bUpf9Mv4KXjzxi0ASTdJw():
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/lineup',fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ELCINEMA-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	rYp4T13URylzh8BQAwvLcuq = vMj9zGZ7Igw.BeautifulSoup(FGRX4myP68S,'html.parser',multi_valued_attributes=None)
	wlJ6d8hEvpoMNSCmU = rYp4T13URylzh8BQAwvLcuq.find('select',attrs={'name':'tag'})
	yJWh5lC4wcNrRi3nFa = wlJ6d8hEvpoMNSCmU.find_all('option')
	for srR9AuG6Pf8powqU4ixL5Ecl in yJWh5lC4wcNrRi3nFa:
		value = srR9AuG6Pf8powqU4ixL5Ecl.get('value')
		if not value: continue
		title = srR9AuG6Pf8powqU4ixL5Ecl.text
		if gZlSEJaXO9F461AL3sR7rWNpqf:
			title = title.encode(Tk9eH2qw6Brsuhj)
			value = value.encode(Tk9eH2qw6Brsuhj)
		bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+value
		title = title.replace('قائمة ',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,511)
	return
def RgSEBXs3UM():
	cmVLNEXM3bsqgixS8CT = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/lineup?utf8=%E2%9C%93'
	rPBMHQe8J3boKv7LCw9OTufz64pS5d = cmVLNEXM3bsqgixS8CT+'&type=1&category=&foreign=&tag='
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مصنفات أشخاص',rPBMHQe8J3boKv7LCw9OTufz64pS5d,511)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فهرس أشخاص أبجدي',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/index/person/alphabet',517)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فهرس موطن',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/index/person/nationality',517)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فهرس  تاريخ الميلاد',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/index/person/birth_year',517)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فهرس  تاريخ الوفاة',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/index/person/death_year',517)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مصنفات - فلتر محدد',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/lineup',515)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مصنفات - فلتر كامل',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/lineup',514)
	return
def ZyT0kmMUtKFJ897BORbuX213YCe(url):
	if '/seasonals' in url: KKb4FNO1DIREh = 0
	elif '/lineup' in url: KKb4FNO1DIREh = 1
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ELCINEMA-LISTS-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	rYp4T13URylzh8BQAwvLcuq = vMj9zGZ7Igw.BeautifulSoup(FGRX4myP68S,'html.parser',multi_valued_attributes=None)
	VuGmoESTAfXlv5tD76PW1Masq0peB = rYp4T13URylzh8BQAwvLcuq.find_all(class_='jumbo-theater clearfix')
	for wlJ6d8hEvpoMNSCmU in VuGmoESTAfXlv5tD76PW1Masq0peB:
		title = wlJ6d8hEvpoMNSCmU.find_all('a')[KKb4FNO1DIREh].text
		bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+wlJ6d8hEvpoMNSCmU.find_all('a')[KKb4FNO1DIREh].get('href')
		if gZlSEJaXO9F461AL3sR7rWNpqf:
			title = title.encode(Tk9eH2qw6Brsuhj)
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.encode(Tk9eH2qw6Brsuhj)
		if not VuGmoESTAfXlv5tD76PW1Masq0peB:
			AvVnpbcxEyRBX(bigdh7fpZYl4aT2keV)
			return
		else:
			title = title.replace('قائمة ',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,512)
	s2OC3m9qin8aegVSEPvZlH4Tro(rYp4T13URylzh8BQAwvLcuq,511)
	return
def s2OC3m9qin8aegVSEPvZlH4Tro(rYp4T13URylzh8BQAwvLcuq,mode):
	wlJ6d8hEvpoMNSCmU = rYp4T13URylzh8BQAwvLcuq.find(class_='pagination')
	if wlJ6d8hEvpoMNSCmU:
		HKdIs1GFl89imxOhPS4qtRAruWNT = wlJ6d8hEvpoMNSCmU.find_all('a')
		hHkjFGKZsVE0iAXLyQ7D4bovOYNWft = wlJ6d8hEvpoMNSCmU.find_all('li')
		Fjv8GgI9Mr3yx5thZBmYH1LXAUo = list(zip(HKdIs1GFl89imxOhPS4qtRAruWNT,hHkjFGKZsVE0iAXLyQ7D4bovOYNWft))
		b3b24XZTV7gW9mhcqLoCnftO = -1
		z4O1GBfKgIn3W6byE = len(Fjv8GgI9Mr3yx5thZBmYH1LXAUo)
		for BfYztCZvQdgx,OY3Sr4G2pRBJyif8V in Fjv8GgI9Mr3yx5thZBmYH1LXAUo:
			b3b24XZTV7gW9mhcqLoCnftO += 1
			OY3Sr4G2pRBJyif8V = OY3Sr4G2pRBJyif8V['class']
			if 'unavailable' in OY3Sr4G2pRBJyif8V or 'current' in OY3Sr4G2pRBJyif8V: continue
			z6FysMQJTa2IWYdrDx7BjObwN3fE = BfYztCZvQdgx.text
			R9b8gUvoB4wOfkTIjlEsZrM5LtinpS = BOI3t1w8qfHAb0Kl4oMye7haEWS+BfYztCZvQdgx.get('href')
			if gZlSEJaXO9F461AL3sR7rWNpqf:
				z6FysMQJTa2IWYdrDx7BjObwN3fE = z6FysMQJTa2IWYdrDx7BjObwN3fE.encode(Tk9eH2qw6Brsuhj)
				R9b8gUvoB4wOfkTIjlEsZrM5LtinpS = R9b8gUvoB4wOfkTIjlEsZrM5LtinpS.encode(Tk9eH2qw6Brsuhj)
			if   b3b24XZTV7gW9mhcqLoCnftO==0: z6FysMQJTa2IWYdrDx7BjObwN3fE = 'أولى'
			elif b3b24XZTV7gW9mhcqLoCnftO==1: z6FysMQJTa2IWYdrDx7BjObwN3fE = 'سابقة'
			elif b3b24XZTV7gW9mhcqLoCnftO==z4O1GBfKgIn3W6byE-2: z6FysMQJTa2IWYdrDx7BjObwN3fE = 'لاحقة'
			elif b3b24XZTV7gW9mhcqLoCnftO==z4O1GBfKgIn3W6byE-1: z6FysMQJTa2IWYdrDx7BjObwN3fE = 'أخيرة'
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+z6FysMQJTa2IWYdrDx7BjObwN3fE,R9b8gUvoB4wOfkTIjlEsZrM5LtinpS,mode)
	return
def AvVnpbcxEyRBX(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ELCINEMA-TITLES1-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	rYp4T13URylzh8BQAwvLcuq = vMj9zGZ7Igw.BeautifulSoup(FGRX4myP68S,'html.parser',multi_valued_attributes=None)
	VuGmoESTAfXlv5tD76PW1Masq0peB = rYp4T13URylzh8BQAwvLcuq.find_all(class_='row')
	items,lUT6n1NfYxdp2IscbE8oq = [],True
	for wlJ6d8hEvpoMNSCmU in VuGmoESTAfXlv5tD76PW1Masq0peB:
		if not wlJ6d8hEvpoMNSCmU.find(class_='thumbnail-wrapper'): continue
		if lUT6n1NfYxdp2IscbE8oq: lUT6n1NfYxdp2IscbE8oq = False ; continue
		WfhwrdVDjNS6bOGuXB48MFevs5g9QU = []
		txgZFqCu9MH = wlJ6d8hEvpoMNSCmU.find_all(class_=['censorship red','censorship purple'])
		for xSALhkm9rpCZc54iywOzu6NY in txgZFqCu9MH:
			UU0LTHijNAh4SEyw6BO5sCY3Zo = xSALhkm9rpCZc54iywOzu6NY.find_all('li')[1].text
			if gZlSEJaXO9F461AL3sR7rWNpqf:
				UU0LTHijNAh4SEyw6BO5sCY3Zo = UU0LTHijNAh4SEyw6BO5sCY3Zo.encode(Tk9eH2qw6Brsuhj)
			WfhwrdVDjNS6bOGuXB48MFevs5g9QU.append(UU0LTHijNAh4SEyw6BO5sCY3Zo)
		if not SYJvigbI3fts(BfWYUAnyg6eONLjiuE,fy8iFgEkrO12NR9TWBI35sjY6qHvV,WfhwrdVDjNS6bOGuXB48MFevs5g9QU,False):
			mmEsSwOKazXLV1MT = wlJ6d8hEvpoMNSCmU.find('img').get('data-src')
			title = wlJ6d8hEvpoMNSCmU.find('h3')
			name = title.find('a').text
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+title.find('a').get('href')
			jk1Hexdcp7 = wlJ6d8hEvpoMNSCmU.find(class_='no-margin')
			tt9qfEWPBnZv5C7isTLRmQu3VpI0 = wlJ6d8hEvpoMNSCmU.find(class_='legend')
			if jk1Hexdcp7: jk1Hexdcp7 = jk1Hexdcp7.text
			if tt9qfEWPBnZv5C7isTLRmQu3VpI0: tt9qfEWPBnZv5C7isTLRmQu3VpI0 = tt9qfEWPBnZv5C7isTLRmQu3VpI0.text
			if gZlSEJaXO9F461AL3sR7rWNpqf:
				mmEsSwOKazXLV1MT = mmEsSwOKazXLV1MT.encode(Tk9eH2qw6Brsuhj)
				name = name.encode(Tk9eH2qw6Brsuhj)
				bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.encode(Tk9eH2qw6Brsuhj)
				if jk1Hexdcp7: jk1Hexdcp7 = jk1Hexdcp7.encode(Tk9eH2qw6Brsuhj)
			Q1q840Lz62ZxYGCEaRbjtuAFS7siW = {}
			if tt9qfEWPBnZv5C7isTLRmQu3VpI0: Q1q840Lz62ZxYGCEaRbjtuAFS7siW['stars'] = tt9qfEWPBnZv5C7isTLRmQu3VpI0
			if jk1Hexdcp7:
				jk1Hexdcp7 = jk1Hexdcp7.replace(C0qrknitpM4Z,' .. ')
				Q1q840Lz62ZxYGCEaRbjtuAFS7siW['plot'] = jk1Hexdcp7.replace('...اقرأ المزيد',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			if '/work/' in bigdh7fpZYl4aT2keV:
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+name,bigdh7fpZYl4aT2keV,516,mmEsSwOKazXLV1MT,fy8iFgEkrO12NR9TWBI35sjY6qHvV,name,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Q1q840Lz62ZxYGCEaRbjtuAFS7siW)
			elif '/person/' in bigdh7fpZYl4aT2keV: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+name,bigdh7fpZYl4aT2keV,513,mmEsSwOKazXLV1MT,fy8iFgEkrO12NR9TWBI35sjY6qHvV,name,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Q1q840Lz62ZxYGCEaRbjtuAFS7siW)
	s2OC3m9qin8aegVSEPvZlH4Tro(rYp4T13URylzh8BQAwvLcuq,512)
	return
def ROjSZnMNsVa9lX8BTI5i6fFyJw(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ELCINEMA-TITLES2-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	rYp4T13URylzh8BQAwvLcuq = vMj9zGZ7Igw.BeautifulSoup(FGRX4myP68S,'html.parser',multi_valued_attributes=None)
	VuGmoESTAfXlv5tD76PW1Masq0peB = rYp4T13URylzh8BQAwvLcuq.find_all('li')
	ny5fseD6KMzR8m3vSE,items = [],[]
	for wlJ6d8hEvpoMNSCmU in VuGmoESTAfXlv5tD76PW1Masq0peB:
		if not wlJ6d8hEvpoMNSCmU.find(class_='thumbnail-wrapper'): continue
		if not wlJ6d8hEvpoMNSCmU.find(class_=['unstyled','unstyled text-center']): continue
		if wlJ6d8hEvpoMNSCmU.find(class_='hide'): continue
		title = wlJ6d8hEvpoMNSCmU.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in ny5fseD6KMzR8m3vSE: continue
		ny5fseD6KMzR8m3vSE.append(name)
		bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+title.find('a').get('href')
		if '/search/work/' in url: mmEsSwOKazXLV1MT = wlJ6d8hEvpoMNSCmU.find('img').get('src')
		elif '/search/person/' in url: mmEsSwOKazXLV1MT = wlJ6d8hEvpoMNSCmU.find('img').get('data-src')
		elif '/search/video/' in url: mmEsSwOKazXLV1MT = wlJ6d8hEvpoMNSCmU.find('img').get('data-src')
		else: mmEsSwOKazXLV1MT = wlJ6d8hEvpoMNSCmU.find('img').get('src')
		if gZlSEJaXO9F461AL3sR7rWNpqf:
			name = name.encode(Tk9eH2qw6Brsuhj)
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.encode(Tk9eH2qw6Brsuhj)
			mmEsSwOKazXLV1MT = mmEsSwOKazXLV1MT.encode(Tk9eH2qw6Brsuhj)
		name = name.strip(ksJdoFWhxTz8Y2N7bOZE)
		items.append((name,bigdh7fpZYl4aT2keV,mmEsSwOKazXLV1MT))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,bigdh7fpZYl4aT2keV,mmEsSwOKazXLV1MT in items:
		if '/search/video/' in url: OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+name,bigdh7fpZYl4aT2keV,522,mmEsSwOKazXLV1MT)
		elif '/search/person/' in url: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+name,bigdh7fpZYl4aT2keV,513,mmEsSwOKazXLV1MT,fy8iFgEkrO12NR9TWBI35sjY6qHvV,name)
		else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+name,bigdh7fpZYl4aT2keV,516,mmEsSwOKazXLV1MT,fy8iFgEkrO12NR9TWBI35sjY6qHvV,name)
	return
def mEjeUobZfphL3VHAQw8PYgsB(text):
	text = text.replace('الإعلان',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('لفيلم',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('الرسمي',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	text = text.replace('إعلان',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('فيلم',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('البرومو',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	text = text.replace('التشويقي',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('لمسلسل',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('مسلسل',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	text = text.replace(':',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(')',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('(',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(',',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	text = text.replace('_',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(';',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('-',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('.',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	text = text.replace('\'',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('\"',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	text = text.replace(zz5wETpjWKMNb6JiLRndGhV9,ksJdoFWhxTz8Y2N7bOZE).replace(yU7COAbsNJ916v5L0oew2n,ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE)
	text = text.strip(ksJdoFWhxTz8Y2N7bOZE)
	qqW5J1p3iygTvMBrw908uoedKkE = text.count(ksJdoFWhxTz8Y2N7bOZE)+1
	if qqW5J1p3iygTvMBrw908uoedKkE==1:
		xxpUN6ZSLFOhrE2KmDu7jwfCiXBs(text)
		return
	OZD1l4pAMzeH('link',K2l9rLfvoXxyZ4NYapO+n0nFOd4yR97fQzNLSW+'==== كلمات للبحث ===='+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	dnAwx6TORmcYtgB = text.split(ksJdoFWhxTz8Y2N7bOZE)
	NPLhf2MZxIHToXDFkYlu6dbcWB = pow(2,qqW5J1p3iygTvMBrw908uoedKkE)
	NDoxAnVhETtLJXeRP7qcik = []
	def VVL2PuY8HAJh7UfIbl3jxTRKvgEy(E92E0SJiFO3vnodyP1B,G6A0ofqSmv4Lx7wsN8IC):
		if E92E0SJiFO3vnodyP1B=='1': return G6A0ofqSmv4Lx7wsN8IC
		return fy8iFgEkrO12NR9TWBI35sjY6qHvV
	for b3b24XZTV7gW9mhcqLoCnftO in range(NPLhf2MZxIHToXDFkYlu6dbcWB,0,-1):
		OEMnkQ6h8pZfH5g = list(qqW5J1p3iygTvMBrw908uoedKkE*'0'+bin(b3b24XZTV7gW9mhcqLoCnftO)[2:])[-qqW5J1p3iygTvMBrw908uoedKkE:]
		OEMnkQ6h8pZfH5g = reversed(OEMnkQ6h8pZfH5g)
		s9qgDT8oclCrdXK6EUO = map(VVL2PuY8HAJh7UfIbl3jxTRKvgEy,OEMnkQ6h8pZfH5g,dnAwx6TORmcYtgB)
		title = ksJdoFWhxTz8Y2N7bOZE.join(filter(None,s9qgDT8oclCrdXK6EUO))
		if gZlSEJaXO9F461AL3sR7rWNpqf: D4DQ6k0oS39GKbZrthnsTB = title.decode(Tk9eH2qw6Brsuhj)
		else: D4DQ6k0oS39GKbZrthnsTB = title
		if len(D4DQ6k0oS39GKbZrthnsTB)>2 and title not in NDoxAnVhETtLJXeRP7qcik:
			NDoxAnVhETtLJXeRP7qcik.append(title)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,fy8iFgEkrO12NR9TWBI35sjY6qHvV,523,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,title)
	return
def xxpUN6ZSLFOhrE2KmDu7jwfCiXBs(EfJc6xmorP9siHGZplU02yK7):
	if gZlSEJaXO9F461AL3sR7rWNpqf:
		EfJc6xmorP9siHGZplU02yK7 = EfJc6xmorP9siHGZplU02yK7.decode(Tk9eH2qw6Brsuhj)
		import arabic_reshaper as xIz4219LvqH,bidi.algorithm as n5nhyxsWuCGNpLR
		EfJc6xmorP9siHGZplU02yK7 = xIz4219LvqH.ArabicReshaper().reshape(EfJc6xmorP9siHGZplU02yK7)
		EfJc6xmorP9siHGZplU02yK7 = n5nhyxsWuCGNpLR.get_display(EfJc6xmorP9siHGZplU02yK7)
	import msb3A1OhNH
	EfJc6xmorP9siHGZplU02yK7 = GFYl1tsoOkHC0Ajeur8JQiMx(BgDNz7JOZr69oC5wvbGFl4anypKquA=EfJc6xmorP9siHGZplU02yK7)
	msb3A1OhNH.dPTs3joJiGpzfcWFvQZAa(EfJc6xmorP9siHGZplU02yK7)
	return
def a4iMqGE0YSeOjUX9KxT1(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ELCINEMA-INDEXES_LISTS-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	rYp4T13URylzh8BQAwvLcuq = vMj9zGZ7Igw.BeautifulSoup(FGRX4myP68S,'html.parser',multi_valued_attributes=None)
	wlJ6d8hEvpoMNSCmU = rYp4T13URylzh8BQAwvLcuq.find(class_='list-separator list-title')
	p7Gkego0m6a8 = wlJ6d8hEvpoMNSCmU.find_all('a')
	items = []
	for title in p7Gkego0m6a8:
		name = title.text
		bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+title.get('href')
		if gZlSEJaXO9F461AL3sR7rWNpqf:
			name = name.encode(Tk9eH2qw6Brsuhj)
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.encode(Tk9eH2qw6Brsuhj)
		if '#' not in bigdh7fpZYl4aT2keV: items.append((name,bigdh7fpZYl4aT2keV))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for j25T6eKhaMk3 in items:
		name,bigdh7fpZYl4aT2keV = j25T6eKhaMk3
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+name,bigdh7fpZYl4aT2keV,518)
	return
def BwQS7hv9F0(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ELCINEMA-INDEXES_TITLES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	rYp4T13URylzh8BQAwvLcuq = vMj9zGZ7Igw.BeautifulSoup(FGRX4myP68S,'html.parser',multi_valued_attributes=None)
	VuGmoESTAfXlv5tD76PW1Masq0peB = rYp4T13URylzh8BQAwvLcuq.find(class_='expand').find_all('tr')
	for wlJ6d8hEvpoMNSCmU in VuGmoESTAfXlv5tD76PW1Masq0peB:
		dsJENBtpx5PR7zfjOV = wlJ6d8hEvpoMNSCmU.find_all('a')
		if not dsJENBtpx5PR7zfjOV: continue
		mmEsSwOKazXLV1MT = wlJ6d8hEvpoMNSCmU.find('img').get('data-src')
		name = dsJENBtpx5PR7zfjOV[1].text
		bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+dsJENBtpx5PR7zfjOV[1].get('href')
		tt9qfEWPBnZv5C7isTLRmQu3VpI0 = wlJ6d8hEvpoMNSCmU.find(class_='legend')
		if tt9qfEWPBnZv5C7isTLRmQu3VpI0: tt9qfEWPBnZv5C7isTLRmQu3VpI0 = tt9qfEWPBnZv5C7isTLRmQu3VpI0.text
		if gZlSEJaXO9F461AL3sR7rWNpqf:
			name = name.encode(Tk9eH2qw6Brsuhj)
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.encode(Tk9eH2qw6Brsuhj)
			mmEsSwOKazXLV1MT = mmEsSwOKazXLV1MT.encode(Tk9eH2qw6Brsuhj)
		Q1q840Lz62ZxYGCEaRbjtuAFS7siW = {}
		if tt9qfEWPBnZv5C7isTLRmQu3VpI0: Q1q840Lz62ZxYGCEaRbjtuAFS7siW['stars'] = tt9qfEWPBnZv5C7isTLRmQu3VpI0
		if '/work/' in bigdh7fpZYl4aT2keV:
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+name,bigdh7fpZYl4aT2keV,516,mmEsSwOKazXLV1MT,fy8iFgEkrO12NR9TWBI35sjY6qHvV,name,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Q1q840Lz62ZxYGCEaRbjtuAFS7siW)
		elif '/person/' in bigdh7fpZYl4aT2keV: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+name,bigdh7fpZYl4aT2keV,513,mmEsSwOKazXLV1MT,fy8iFgEkrO12NR9TWBI35sjY6qHvV,name,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Q1q840Lz62ZxYGCEaRbjtuAFS7siW)
	s2OC3m9qin8aegVSEPvZlH4Tro(rYp4T13URylzh8BQAwvLcuq,518)
	return
def yyAMizRwx7OGC(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ELCINEMA-VIDEOS_LISTS-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	rYp4T13URylzh8BQAwvLcuq = vMj9zGZ7Igw.BeautifulSoup(FGRX4myP68S,'html.parser',multi_valued_attributes=None)
	p7Gkego0m6a8 = rYp4T13URylzh8BQAwvLcuq.find_all(class_='section-title inline')
	zzECVswWcGAIXhrQlZ7jMokugnv = rYp4T13URylzh8BQAwvLcuq.find_all(class_='button green small right')
	items = zip(p7Gkego0m6a8,zzECVswWcGAIXhrQlZ7jMokugnv)
	for title,bigdh7fpZYl4aT2keV in items:
		title = title.text
		bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV.get('href')
		if gZlSEJaXO9F461AL3sR7rWNpqf:
			title = title.encode(Tk9eH2qw6Brsuhj)
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.encode(Tk9eH2qw6Brsuhj)
		title = title.replace(zz5wETpjWKMNb6JiLRndGhV9,ksJdoFWhxTz8Y2N7bOZE).replace(yU7COAbsNJ916v5L0oew2n,ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,521)
	return
def xxtPcXGI6SH2LN8vYAkdDWjeT(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ELCINEMA-VIDEOS_TITLES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	rYp4T13URylzh8BQAwvLcuq = vMj9zGZ7Igw.BeautifulSoup(FGRX4myP68S,'html.parser',multi_valued_attributes=None)
	YB73fNZOmHQ = rYp4T13URylzh8BQAwvLcuq.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	VuGmoESTAfXlv5tD76PW1Masq0peB = YB73fNZOmHQ.find_all('li')
	for wlJ6d8hEvpoMNSCmU in VuGmoESTAfXlv5tD76PW1Masq0peB:
		title = wlJ6d8hEvpoMNSCmU.find(class_='title').text
		bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+wlJ6d8hEvpoMNSCmU.find('a').get('href')
		mmEsSwOKazXLV1MT = wlJ6d8hEvpoMNSCmU.find('img').get('data-src')
		rQ0jN7XkZPE1AYU = wlJ6d8hEvpoMNSCmU.find(class_='duration').text
		if gZlSEJaXO9F461AL3sR7rWNpqf:
			title = title.encode(Tk9eH2qw6Brsuhj)
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.encode(Tk9eH2qw6Brsuhj)
			mmEsSwOKazXLV1MT = mmEsSwOKazXLV1MT.encode(Tk9eH2qw6Brsuhj)
			rQ0jN7XkZPE1AYU = rQ0jN7XkZPE1AYU.encode(Tk9eH2qw6Brsuhj)
		rQ0jN7XkZPE1AYU = rQ0jN7XkZPE1AYU.replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE)
		OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,522,mmEsSwOKazXLV1MT,rQ0jN7XkZPE1AYU)
	s2OC3m9qin8aegVSEPvZlH4Tro(rYp4T13URylzh8BQAwvLcuq,521)
	return
def rr7SfotkneX85Klup(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ELCINEMA-PLAY-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	rYp4T13URylzh8BQAwvLcuq = vMj9zGZ7Igw.BeautifulSoup(FGRX4myP68S,'html.parser',multi_valued_attributes=None)
	bigdh7fpZYl4aT2keV = rYp4T13URylzh8BQAwvLcuq.find(class_='flex-video').find('iframe').get('src')
	if gZlSEJaXO9F461AL3sR7rWNpqf: bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.encode(Tk9eH2qw6Brsuhj)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4([bigdh7fpZYl4aT2keV],BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'%20')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/search/?q='+search
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ELCINEMA-SEARCH-1st')
	if not E6ECvznP9m5sWFMu.succeeded:
		rPBMHQe8J3boKv7LCw9OTufz64pS5d = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/search_entity/?q='+search+'&entity=work'
		R9b8gUvoB4wOfkTIjlEsZrM5LtinpS = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/search_entity/?q='+search+'&entity=person'
		WW1zbyCXmnLRQot3JEvkF = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/search_entity/?q='+search+'&entity=video'
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث عن أعمال',rPBMHQe8J3boKv7LCw9OTufz64pS5d,513,fy8iFgEkrO12NR9TWBI35sjY6qHvV,search)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث عن أشخاص',R9b8gUvoB4wOfkTIjlEsZrM5LtinpS,513,fy8iFgEkrO12NR9TWBI35sjY6qHvV,search)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث عن فيديوهات',WW1zbyCXmnLRQot3JEvkF,513,fy8iFgEkrO12NR9TWBI35sjY6qHvV,search)
		return
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	rYp4T13URylzh8BQAwvLcuq = vMj9zGZ7Igw.BeautifulSoup(FGRX4myP68S,'html.parser',multi_valued_attributes=None)
	VuGmoESTAfXlv5tD76PW1Masq0peB = rYp4T13URylzh8BQAwvLcuq.find_all(class_='section-title left')
	for wlJ6d8hEvpoMNSCmU in VuGmoESTAfXlv5tD76PW1Masq0peB:
		title = wlJ6d8hEvpoMNSCmU.text
		if gZlSEJaXO9F461AL3sR7rWNpqf:
			title = title.encode(Tk9eH2qw6Brsuhj)
		title = title.split('(',1)[0].strip(ksJdoFWhxTz8Y2N7bOZE)
		if   'أعمال' in title: bigdh7fpZYl4aT2keV = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: bigdh7fpZYl4aT2keV = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: bigdh7fpZYl4aT2keV = url.replace('/search/','/search/video/')
		else: continue
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,513)
	return
def MMatQbhsKv1YdrIW8iLz5U7pSE(url,text):
	global ffJIco45MG9kFntgWDwqyR,nohzWuNjPvp0MA
	if '/seasonals' in url:
		ffJIco45MG9kFntgWDwqyR = ['seasonal','year','category']
		nohzWuNjPvp0MA = ['seasonal','year','category']
	elif '/lineup' in url:
		ffJIco45MG9kFntgWDwqyR = ['category','foreign','type']
		nohzWuNjPvp0MA = ['category','foreign','type']
	F4ehkvPDxXU(url,text)
	return
def dfqB809Vbp6nyMRcmHvwZ(url):
	url = url.split('/smartemadfilter?')[0]
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'ELCINEMA-GET_FILTERS_BLOCKS-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('form action="/(.*?)</form>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	W1A4L5P0Zc8wHnUGjVexElz = EcQxOa3RJm86WjTKA.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	return W1A4L5P0Zc8wHnUGjVexElz
def XkO6QiU8yILWlfg(wlJ6d8hEvpoMNSCmU):
	items = EcQxOa3RJm86WjTKA.findall('<option value="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	return items
def U3Kb7B2Nd5VO1agDkxMsn9C4(url):
	uHyjkzgiAsGW5ZIb9U6TlV = url.split('/smartemadfilter?')[0]
	EW6mPCkSQRzH3Yw8ITFpc4nv5M = VbHeOuU1ilzSp2ZRXwBD(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def d1X9ziMC5b4s0qEStmjoAT3au6kc(ybEUMsLp4zBVPnuAYI0cCdowekDq,url):
	F231lsuCKnaSMdQ48W6PoL = nKT1QuLoXPc8CjyV(ybEUMsLp4zBVPnuAYI0cCdowekDq,'all_filters')
	MYWwFs7XA2 = url+'/smartemadfilter?'+F231lsuCKnaSMdQ48W6PoL
	MYWwFs7XA2 = U3Kb7B2Nd5VO1agDkxMsn9C4(MYWwFs7XA2)
	return MYWwFs7XA2
def F4ehkvPDxXU(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==fy8iFgEkrO12NR9TWBI35sjY6qHvV: NnQ1hEsTV7Zaz3HKdfu,QlOXcH07nRVPAZub8pD356xMvdk4 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	else: NnQ1hEsTV7Zaz3HKdfu,QlOXcH07nRVPAZub8pD356xMvdk4 = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if ffJIco45MG9kFntgWDwqyR[0]+'=' not in NnQ1hEsTV7Zaz3HKdfu: fnogyzNA30JCPMYqHTavG7ZKp = ffJIco45MG9kFntgWDwqyR[0]
		for pk6YWixXFSrDLKCnlN39w in range(len(ffJIco45MG9kFntgWDwqyR[0:-1])):
			if ffJIco45MG9kFntgWDwqyR[pk6YWixXFSrDLKCnlN39w]+'=' in NnQ1hEsTV7Zaz3HKdfu: fnogyzNA30JCPMYqHTavG7ZKp = ffJIco45MG9kFntgWDwqyR[pk6YWixXFSrDLKCnlN39w+1]
		z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&'+fnogyzNA30JCPMYqHTavG7ZKp+'=0'
		ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&'+fnogyzNA30JCPMYqHTavG7ZKp+'=0'
		HfvJenZmN3O8rPcshLux2EyzDWpQCb = z7VI1OaUPqs4lXxb.strip('&')+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq.strip('&')
		F231lsuCKnaSMdQ48W6PoL = nKT1QuLoXPc8CjyV(QlOXcH07nRVPAZub8pD356xMvdk4,'modified_filters')
		YLKFRH6sSIrznXBg = url+'/smartemadfilter?'+F231lsuCKnaSMdQ48W6PoL
	elif type=='ALL_ITEMS_FILTER':
		QUFL2gEBMn63qlsmI7W = nKT1QuLoXPc8CjyV(NnQ1hEsTV7Zaz3HKdfu,'modified_values')
		QUFL2gEBMn63qlsmI7W = U2Z7CVFftTmLeK3nzEbQPGga(QUFL2gEBMn63qlsmI7W)
		if QlOXcH07nRVPAZub8pD356xMvdk4!=fy8iFgEkrO12NR9TWBI35sjY6qHvV: QlOXcH07nRVPAZub8pD356xMvdk4 = nKT1QuLoXPc8CjyV(QlOXcH07nRVPAZub8pD356xMvdk4,'modified_filters')
		if QlOXcH07nRVPAZub8pD356xMvdk4==fy8iFgEkrO12NR9TWBI35sjY6qHvV: YLKFRH6sSIrznXBg = url
		else: YLKFRH6sSIrznXBg = url+'/smartemadfilter?'+QlOXcH07nRVPAZub8pD356xMvdk4
		YLKFRH6sSIrznXBg = U3Kb7B2Nd5VO1agDkxMsn9C4(YLKFRH6sSIrznXBg)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'أظهار قائمة الفيديو التي تم اختيارها ',YLKFRH6sSIrznXBg,511)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+' [[   '+QUFL2gEBMn63qlsmI7W+'   ]]',YLKFRH6sSIrznXBg,511)
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	W1A4L5P0Zc8wHnUGjVexElz = dfqB809Vbp6nyMRcmHvwZ(url)
	dict = {}
	for name,jLA9nhxoZbG,wlJ6d8hEvpoMNSCmU in W1A4L5P0Zc8wHnUGjVexElz:
		name = name.replace('--',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		items = XkO6QiU8yILWlfg(wlJ6d8hEvpoMNSCmU)
		if '=' not in YLKFRH6sSIrznXBg: YLKFRH6sSIrznXBg = url
		if type=='SPECIFIED_FILTER':
			if jLA9nhxoZbG not in ffJIco45MG9kFntgWDwqyR: continue
			if fnogyzNA30JCPMYqHTavG7ZKp!=jLA9nhxoZbG: continue
			elif len(items)<2:
				if jLA9nhxoZbG==ffJIco45MG9kFntgWDwqyR[-1]:
					url = U3Kb7B2Nd5VO1agDkxMsn9C4(url)
					AvVnpbcxEyRBX(url)
				else: F4ehkvPDxXU(YLKFRH6sSIrznXBg,'SPECIFIED_FILTER___'+HfvJenZmN3O8rPcshLux2EyzDWpQCb)
				return
			else:
				YLKFRH6sSIrznXBg = U3Kb7B2Nd5VO1agDkxMsn9C4(YLKFRH6sSIrznXBg)
				if jLA9nhxoZbG==ffJIco45MG9kFntgWDwqyR[-1]: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع',YLKFRH6sSIrznXBg,511)
				else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع',YLKFRH6sSIrznXBg,515,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,HfvJenZmN3O8rPcshLux2EyzDWpQCb)
		elif type=='ALL_ITEMS_FILTER':
			if jLA9nhxoZbG not in nohzWuNjPvp0MA: continue
			z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&'+jLA9nhxoZbG+'=0'
			ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&'+jLA9nhxoZbG+'=0'
			HfvJenZmN3O8rPcshLux2EyzDWpQCb = z7VI1OaUPqs4lXxb+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع: '+name,YLKFRH6sSIrznXBg,514,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,HfvJenZmN3O8rPcshLux2EyzDWpQCb)
		dict[jLA9nhxoZbG] = {}
		for value,srR9AuG6Pf8powqU4ixL5Ecl in items:
			if srR9AuG6Pf8powqU4ixL5Ecl in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
			if 'مصنفات أخرى' in srR9AuG6Pf8powqU4ixL5Ecl: continue
			if 'الكل' in srR9AuG6Pf8powqU4ixL5Ecl: continue
			if 'اللغة' in srR9AuG6Pf8powqU4ixL5Ecl: continue
			srR9AuG6Pf8powqU4ixL5Ecl = srR9AuG6Pf8powqU4ixL5Ecl.replace('قائمة ',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[jLA9nhxoZbG][value] = srR9AuG6Pf8powqU4ixL5Ecl
			z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&'+jLA9nhxoZbG+'='+srR9AuG6Pf8powqU4ixL5Ecl
			ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&'+jLA9nhxoZbG+'='+value
			QdzUcX2iR5 = z7VI1OaUPqs4lXxb+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq
			if name: title = srR9AuG6Pf8powqU4ixL5Ecl+' :'+name
			else: title = srR9AuG6Pf8powqU4ixL5Ecl
			if type=='ALL_ITEMS_FILTER': OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,514,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QdzUcX2iR5)
			elif type=='SPECIFIED_FILTER' and ffJIco45MG9kFntgWDwqyR[-2]+'=' in NnQ1hEsTV7Zaz3HKdfu:
				MYWwFs7XA2 = d1X9ziMC5b4s0qEStmjoAT3au6kc(ybEUMsLp4zBVPnuAYI0cCdowekDq,url)
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,MYWwFs7XA2,511)
			else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,515,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QdzUcX2iR5)
	return
def nKT1QuLoXPc8CjyV(p9UP6wGlC1BF7fN2,mode):
	p9UP6wGlC1BF7fN2 = p9UP6wGlC1BF7fN2.replace('=&','=0&')
	p9UP6wGlC1BF7fN2 = p9UP6wGlC1BF7fN2.strip('&')
	vpLWbVm35iM0l2TzYIN7 = {}
	if '=' in p9UP6wGlC1BF7fN2:
		items = p9UP6wGlC1BF7fN2.split('&')
		for j25T6eKhaMk3 in items:
			XJRx6urSNaOM5AfZdDsgQBYGt,value = j25T6eKhaMk3.split('=')
			vpLWbVm35iM0l2TzYIN7[XJRx6urSNaOM5AfZdDsgQBYGt] = value
	MKJaIb2sDSr4VCQGTqyX3nkWL = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	for key in nohzWuNjPvp0MA:
		if key in list(vpLWbVm35iM0l2TzYIN7.keys()): value = vpLWbVm35iM0l2TzYIN7[key]
		else: value = '0'
		if '%' not in value: value = DVX5GWhnIxYlSd9rEuetjk40UJ(value)
		if mode=='modified_values' and value!='0': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+' + '+value
		elif mode=='modified_filters' and value!='0': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+'&'+key+'='+value
		elif mode=='all_filters': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+'&'+key+'='+value
	MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL.strip(' + ')
	MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL.strip('&')
	MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL.replace('=0','=')
	return MKJaIb2sDSr4VCQGTqyX3nkWL
ffJIco45MG9kFntgWDwqyR = []
nohzWuNjPvp0MA = []
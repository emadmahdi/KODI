# -*- coding: utf-8 -*-
import sys as CfgZ0zWP5XBpoGQwLUY
D5DpyO2wPg7oL = CfgZ0zWP5XBpoGQwLUY.version_info [0] == 2
ccK5HIyfUgvOdQpWSXZtaBJ = 2048
W8WuBTGQg1Zwqy5F6xSe = 7
def zmQcCUZlPKBITW5bqx1 (rR5FPU8VhJQ):
	global Jfz4wMWSZb0BYV
	EEr5teuZbc = ord (rR5FPU8VhJQ [-1])
	ZZd5W9FVUhzu31NQyComxv = rR5FPU8VhJQ [:-1]
	sJYFyd6mZHev1IXEaMj0b = EEr5teuZbc % len (ZZd5W9FVUhzu31NQyComxv)
	qPJ7pUnt5rcm6NMaFYLSkHsGxI = ZZd5W9FVUhzu31NQyComxv [:sJYFyd6mZHev1IXEaMj0b] + ZZd5W9FVUhzu31NQyComxv [sJYFyd6mZHev1IXEaMj0b:]
	if D5DpyO2wPg7oL:
		Vv1b9fdEckNepm7 = unicode () .join ([unichr (ord (QdqoKlFn4yZUOJp1xYrNTaBSmt69hc) - ccK5HIyfUgvOdQpWSXZtaBJ - (hrazDC5q4oB + EEr5teuZbc) % W8WuBTGQg1Zwqy5F6xSe) for hrazDC5q4oB, QdqoKlFn4yZUOJp1xYrNTaBSmt69hc in enumerate (qPJ7pUnt5rcm6NMaFYLSkHsGxI)])
	else:
		Vv1b9fdEckNepm7 = str () .join ([chr (ord (QdqoKlFn4yZUOJp1xYrNTaBSmt69hc) - ccK5HIyfUgvOdQpWSXZtaBJ - (hrazDC5q4oB + EEr5teuZbc) % W8WuBTGQg1Zwqy5F6xSe) for hrazDC5q4oB, QdqoKlFn4yZUOJp1xYrNTaBSmt69hc in enumerate (qPJ7pUnt5rcm6NMaFYLSkHsGxI)])
	return eval (Vv1b9fdEckNepm7)
V3z5t4JAqyXk2fLsW1juoZ0BEp6,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye,wdftVMyzF17cYETHu=zmQcCUZlPKBITW5bqx1,zmQcCUZlPKBITW5bqx1,zmQcCUZlPKBITW5bqx1
Hr25gta6XcqO,FmYoGejTnwKME7d9zPc,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9=wdftVMyzF17cYETHu,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye,V3z5t4JAqyXk2fLsW1juoZ0BEp6
KfHAW8VGbrxi,aOQTKXFL54Nl60Zhp3MbE,jL5CrsRwebpyDVXUc1EQP=Dco0w1e5VM3YP7hLXTHBS8GtaCrO9,FmYoGejTnwKME7d9zPc,Hr25gta6XcqO
oRJAfwD957WkUyBM1Ehu8m,vU6DxuzPwMpg,I18uSKaWhgTBeYUPD4sr=jL5CrsRwebpyDVXUc1EQP,aOQTKXFL54Nl60Zhp3MbE,KfHAW8VGbrxi
o1INZ3ViQqS0Uw5z6kMjbv,s5WMHyQN4mpie,N6NGJ4vpmidqMCh7yo=I18uSKaWhgTBeYUPD4sr,vU6DxuzPwMpg,oRJAfwD957WkUyBM1Ehu8m
Gcw2nelTR864XCVruO3mAFqI5a,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7,OO9YiAQHGrLo0qpW2M3jDeXd1kx=N6NGJ4vpmidqMCh7yo,s5WMHyQN4mpie,o1INZ3ViQqS0Uw5z6kMjbv
O3OVuapf0YFjbm5oUQDg,sJw9QWiq1Kr0xfeVRI,SnhLjmfeJC=OO9YiAQHGrLo0qpW2M3jDeXd1kx,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7,Gcw2nelTR864XCVruO3mAFqI5a
QjAINyUC7MDRq5d8e4vl9,AAbvaXV2DQzfNHdm4U3tT,ggjO5CrKVRPITaesWkxD=SnhLjmfeJC,sJw9QWiq1Kr0xfeVRI,O3OVuapf0YFjbm5oUQDg
FgXzMs0YSDt,uulNDCPyef78,EQxFuqjw95WvaMm8Hnlt47XVihJ=ggjO5CrKVRPITaesWkxD,AAbvaXV2DQzfNHdm4U3tT,QjAINyUC7MDRq5d8e4vl9
ssynAg0zhSkoCpOMDV9,sIzDXlTHYUC5L3xZGnr,PlpyFa9QMKXxOD1cvHzmI=EQxFuqjw95WvaMm8Hnlt47XVihJ,uulNDCPyef78,FgXzMs0YSDt
CsDcLqQUVK4YBvHFW1,EE1jeHnIoad,LYIgTBeSmZWotDh4bnyQkvM50siu=PlpyFa9QMKXxOD1cvHzmI,sIzDXlTHYUC5L3xZGnr,ssynAg0zhSkoCpOMDV9
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = O3OVuapf0YFjbm5oUQDg(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭᷃")
bwmXNqtLlzxU4Fv = []
headers = {N6NGJ4vpmidqMCh7yo(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ᷄"):fy8iFgEkrO12NR9TWBI35sjY6qHvV}
def hxDjS7kzK0FLEunHtfRAv1C8c(source,ZJqDh4ByGPQn13tlzMOTLCNdcugx,url):
	Clc8sIj97ZrThF(P3PazFblmtN,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡨ࡬ࡲࡩ࡯࡮ࡨࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࡹࠠࠡࠢࠣࡗ࡮ࡺࡥ࠻ࠢ࡞ࠤࠬ᷅")+source+QjAINyUC7MDRq5d8e4vl9(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࠥࡹࡱࡧ࠽ࠤࡠࠦࠧ᷆")+ZJqDh4ByGPQn13tlzMOTLCNdcugx+O3OVuapf0YFjbm5oUQDg(u"ࠧࠡ࡟ࠪ᷇"))
	P9QG3u85ZvT4dqx = rIhXWK91vRuC(jUCABmLYMf0G,oRJAfwD957WkUyBM1Ehu8m(u"ࠨࡦ࡬ࡧࡹ࠭᷈"),s5WMHyQN4mpie(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ᷉"),PlpyFa9QMKXxOD1cvHzmI(u"ࠪࡗࡎ࡚ࡅࡔࡡࡈࡖࡗࡕࡒࡔ᷊ࠩ"))
	XXU91lsNhPkfVOSLRA = uUqrNPcXKBoQ0slv.strftime(O3OVuapf0YFjbm5oUQDg(u"ࠫࠪ࡟࠮ࠦ࡯࠱ࠩࡩࠦࠥࡉ࠼ࠨࡑࠬ᷋"),uUqrNPcXKBoQ0slv.gmtime(VySKdWnH3vNq6klQ))
	ZUcBH6T19kAxhs = XXU91lsNhPkfVOSLRA,url
	key = source+zz5wETpjWKMNb6JiLRndGhV9+KoxvjArhL1TdInDmN9s+zz5wETpjWKMNb6JiLRndGhV9+str(FpjKBIUaEwbmLkxANfs)
	kf40tulvSA7z9RqNF5dXca3seMD = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if key not in list(P9QG3u85ZvT4dqx.keys()): P9QG3u85ZvT4dqx[key] = [ZUcBH6T19kAxhs]
	else:
		if url not in str(P9QG3u85ZvT4dqx[key]): P9QG3u85ZvT4dqx[key].append(ZUcBH6T19kAxhs)
		else: kf40tulvSA7z9RqNF5dXca3seMD = N6NGJ4vpmidqMCh7yo(u"ࠬࡢ࡮้ࠡำหࠥอไโ์า๎ํࠦๅ้ฮ๋ำࠥ็๊ࠡไสส๊ฯࠠศๆไ๎ิ๐่่ษอࠤฬ๊ส๋ࠢ็้ࠥะูๆๆࠪ᷌")
	wENVWfgh9cJXPIBOMyx2Yb16SlDqeZ = D2D96X5NGamBhrFwvL8VEbqiSfZIl
	for key in list(P9QG3u85ZvT4dqx.keys()):
		P9QG3u85ZvT4dqx[key] = list(set(P9QG3u85ZvT4dqx[key]))
		wENVWfgh9cJXPIBOMyx2Yb16SlDqeZ += len(P9QG3u85ZvT4dqx[key])
	GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,uulNDCPyef78(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ᷍"),QjAINyUC7MDRq5d8e4vl9(u"ࠧๅๆฦืๆࠦวๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏าฯࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠨ᷎")+kf40tulvSA7z9RqNF5dXca3seMD+LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨ࡞ࡱࡠࡳࠦไๅ฻็้ࠥอไษำ้ห๊า๋ࠠไ๋้ࠥฮฬๆ฻ࠣๆฬฬๅสࠢหห้็๊ะ์๋๋ฬะࠠศๆอ๎๊ࠥๅࠡ์ฯำ๊ࠥ็ศ่่ࠢๆอสࠡใํำ๏๎้ࠠี๋ๅࠥ๐ูาุࠣ฽้๐ใࠡษ็ฬึ์วๆฮࠣว๋ࠦสาี็ࠤ์ึ็ࠡษ็ๆฬฬๅสࠢศ่๎ࠦวๅ็หี๊าฺ่ࠠา้ฬ๊ࠦึสะࠤ฾ีฯ่ษࠣ࠹ࠥ็๊ะ์๋๋ฬะ᷏ࠧ")+KfHAW8VGbrxi(u"ࠩ࡟ࡲࡡࡴ᷐ࠧ")+vU6DxuzPwMpg(u"ࠪ฽ิีࠠศๆไ๎ิ๐่่ษอࠤๆ๐ࠠศๆๅหห๋ษࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤࠥ࠭᷑")+str(wENVWfgh9cJXPIBOMyx2Yb16SlDqeZ))
	if wENVWfgh9cJXPIBOMyx2Yb16SlDqeZ>=hvkue2LYgiOGrtcmxszl4S8MWdnF:
		Scj7zgGFVA83otMpwUkxhm0BLN1 = vv7siKgM9IfbCjPNqxXD(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ᷒"),wdftVMyzF17cYETHu(u"ࠬอไษำ้ห๊าࠠอ็฼ࠤ็อฦๆหࠣๅ๏ํวࠡ࠷ࠣๅ๏ี๊้้สฮ๊ࠥๅࠡ์ฯำࠥอไษำ้ห๊าࠠๅ้สࠤ๊๊แศฬࠣๅ๏ี๊้ࠢ࠱࠲ู่ࠥโࠢํๆํ๋ࠠศๆหี๋อๅอࠢส่ว์ࠠษ็ึัࠥํะ่ࠢส่็อฦๆหࠣࡠࡳࡢ࡮้ࠡ็ࠤฯื๊ะࠢศีุอไ้ࠡำ๋ࠥอไใษษ้ฮࠦโษๆุ้ࠣำ็ศࠢศ่๎ࠦวๅ็หี๊าࠠๅๅํࠤ๏่่ๆࠢส่๊ฮัๆฮࠣฬๆำี้ࠡำ๋ࠥอไโ์า๎ํํวหࠢยࠥࠦ࠭ᷓ"))
		if Scj7zgGFVA83otMpwUkxhm0BLN1==BkM54Kr7Qbqn:
			Re3Tm1AxD4hLc2EOPYzqZn = fy8iFgEkrO12NR9TWBI35sjY6qHvV
			for key in list(P9QG3u85ZvT4dqx.keys()):
				Re3Tm1AxD4hLc2EOPYzqZn += C0qrknitpM4Z+key
				D5uownzjdx = sorted(P9QG3u85ZvT4dqx[key],reverse=LhFAGlQ19zr,key=lambda iIUQYdeqVJCB4oyw0: iIUQYdeqVJCB4oyw0[D2D96X5NGamBhrFwvL8VEbqiSfZIl])
				for XXU91lsNhPkfVOSLRA,url in D5uownzjdx:
					Re3Tm1AxD4hLc2EOPYzqZn += C0qrknitpM4Z+XXU91lsNhPkfVOSLRA+zz5wETpjWKMNb6JiLRndGhV9+U2Z7CVFftTmLeK3nzEbQPGga(url)
				Re3Tm1AxD4hLc2EOPYzqZn += FmYoGejTnwKME7d9zPc(u"࠭࡜࡯࡞ࡱࠫᷔ")
			import XbdWsnBA9G
			ddecO3Tb9U5k = XbdWsnBA9G.PkNFw8KBOny2fb9D(SnhLjmfeJC(u"ࠧࡗ࡫ࡧࡩࡴࡹࠧᷕ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,LhFAGlQ19zr,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡕࡒࡁ࡚ࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᷖ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,Re3Tm1AxD4hLc2EOPYzqZn)
			if ddecO3Tb9U5k: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,O3OVuapf0YFjbm5oUQDg(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᷗ"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠪฮ๊ࠦวๅวิืฬ๊ࠠษ่ฯหา࠭ᷘ"))
			else: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,KfHAW8VGbrxi(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᷙ"),ssynAg0zhSkoCpOMDV9(u"ࠬ็ิๅฬࠣ฽๊๊๊สࠢส่สืำศๆࠪᷚ"))
		if Scj7zgGFVA83otMpwUkxhm0BLN1!=-BkM54Kr7Qbqn:
			P9QG3u85ZvT4dqx = {}
			gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,oRJAfwD957WkUyBM1Ehu8m(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩᷛ"),wdftVMyzF17cYETHu(u"ࠧࡔࡋࡗࡉࡘࡥࡅࡓࡔࡒࡖࡘ࠭ᷜ"))
	if P9QG3u85ZvT4dqx: tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫᷝ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠩࡖࡍ࡙ࡋࡓࡠࡇࡕࡖࡔࡘࡓࠨᷞ"),P9QG3u85ZvT4dqx,zz2tnLhI1QHV7GwFCrv5)
	return
def jpO69Mta1uEoRqQ70s5yHWxLN(FPzha2NqwWc5XouTlI,source):
	kENjB56TStKh,WFlpmsYGKNy,XoSyx7p6dqZ1CF8,CXTL7NPUAE = [],[],[],[]
	for rPBMHQe8J3boKv7LCw9OTufz64pS5d in FPzha2NqwWc5XouTlI[:]:
		kTHGylV5uYs4wC,UfieKkPzcrWpIsh4vH9F = rPBMHQe8J3boKv7LCw9OTufz64pS5d,fy8iFgEkrO12NR9TWBI35sjY6qHvV
		if SnhLjmfeJC(u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᷟ") in rPBMHQe8J3boKv7LCw9OTufz64pS5d: kTHGylV5uYs4wC,UfieKkPzcrWpIsh4vH9F = rPBMHQe8J3boKv7LCw9OTufz64pS5d.split(ggjO5CrKVRPITaesWkxD(u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᷠ"),BkM54Kr7Qbqn)
		if kTHGylV5uYs4wC in CXTL7NPUAE: continue
		if source==EE1jeHnIoad(u"ࠬࡇࡌࡎࡕࡗࡆࡆ࠭ᷡ"): OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = qlWwXt6pmFAOKIjMBrYgvc3dESeuiy(kTHGylV5uYs4wC)
		elif EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭ࡱࡷ࡫ࡧࠫᷢ") in kTHGylV5uYs4wC: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = qlWwXt6pmFAOKIjMBrYgvc3dESeuiy(kTHGylV5uYs4wC)
		if XoSyx7p6dqZ1CF8:
			FPzha2NqwWc5XouTlI.remove(rPBMHQe8J3boKv7LCw9OTufz64pS5d)
			zSydkVHNCriWaqT8ltOmbnuoKDI = EcQxOa3RJm86WjTKA.findall(vU6DxuzPwMpg(u"ࠧ࡯ࡣࡰࡩࡩࡃ࠮ࠫࡁࡢࡣ࠭࠴ࠪࡀࠫࡢࡣࠬᷣ"),rPBMHQe8J3boKv7LCw9OTufz64pS5d+QjAINyUC7MDRq5d8e4vl9(u"ࠨࡡࡢࠫᷤ"),EcQxOa3RJm86WjTKA.DOTALL)
			zSydkVHNCriWaqT8ltOmbnuoKDI = zSydkVHNCriWaqT8ltOmbnuoKDI[D2D96X5NGamBhrFwvL8VEbqiSfZIl] if zSydkVHNCriWaqT8ltOmbnuoKDI else fy8iFgEkrO12NR9TWBI35sjY6qHvV
			for D4DQ6k0oS39GKbZrthnsTB,R9b8gUvoB4wOfkTIjlEsZrM5LtinpS in list(zip(WFlpmsYGKNy,XoSyx7p6dqZ1CF8)):
				if R9b8gUvoB4wOfkTIjlEsZrM5LtinpS in CXTL7NPUAE: continue
				CXTL7NPUAE.append(R9b8gUvoB4wOfkTIjlEsZrM5LtinpS)
				R9b8gUvoB4wOfkTIjlEsZrM5LtinpS = R9b8gUvoB4wOfkTIjlEsZrM5LtinpS+QjAINyUC7MDRq5d8e4vl9(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᷥ")+D4DQ6k0oS39GKbZrthnsTB+I18uSKaWhgTBeYUPD4sr(u"ࠪࡣࡤ࠭ᷦ")+zSydkVHNCriWaqT8ltOmbnuoKDI
				kENjB56TStKh.append(R9b8gUvoB4wOfkTIjlEsZrM5LtinpS)
	return FPzha2NqwWc5XouTlI+kENjB56TStKh
def F7ulLTJzOt6krWZa4(hFzEyHWOoRxG,source,ZJqDh4ByGPQn13tlzMOTLCNdcugx,url):
	if not hFzEyHWOoRxG:
		hxDjS7kzK0FLEunHtfRAv1C8c(source,ZJqDh4ByGPQn13tlzMOTLCNdcugx,url)
		return
	hFzEyHWOoRxG = jpO69Mta1uEoRqQ70s5yHWxLN(hFzEyHWOoRxG,source)
	hFzEyHWOoRxG = list(set(hFzEyHWOoRxG))
	WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = swHTA46JhqZgu(hFzEyHWOoRxG,source)
	if I4t9qonjrm.resolveonly:
		HQk0NXpoaAdDg9nI15LZqc8Yjfze = qs8vLCo5IUPu30dfEnl1hz6(WFlpmsYGKNy,XoSyx7p6dqZ1CF8,source,LhFAGlQ19zr)
		return
	gcFGxSyQJEHPsY,OK2mcs7f1ekzACupF,wUqsFlvdyKfa2cCYme,HQk0NXpoaAdDg9nI15LZqc8Yjfze,uGEX2dCfRLoePc0QZztBOsVIaT5x,j25T6eKhaMk3 = LhFAGlQ19zr,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,[],fy8iFgEkrO12NR9TWBI35sjY6qHvV,[]
	HvI5mjsbOa08yTuq4e3olP = not any(value in source for value in zTl1tuniYCM80WApFeN3qQL4axEr)
	if HvI5mjsbOa08yTuq4e3olP:
		hhFDimGWBaJTMx9NfbyS0 = D2D96X5NGamBhrFwvL8VEbqiSfZIl
		GbZV3aPJtwDxjhndC45HpI = rIhXWK91vRuC(jUCABmLYMf0G,O3OVuapf0YFjbm5oUQDg(u"ࠫࡱ࡯ࡳࡵࠩᷧ"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡊ࡟ࡔࡗࡆࡇࡊࡋࡄࡆࡆࠪᷨ"))
		KNx8k4BUbySJcztjVgG0w = rIhXWK91vRuC(jUCABmLYMf0G,s5WMHyQN4mpie(u"࠭࡬ࡪࡵࡷࠫᷩ"),Gcw2nelTR864XCVruO3mAFqI5a(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡅࡡࡘࡒࡐࡔࡏࡘࡐࠪᷪ"))
		jZeyuFlns5WY7Ovb9PGJa8kxfr = rIhXWK91vRuC(jUCABmLYMf0G,FmYoGejTnwKME7d9zPc(u"ࠨ࡮࡬ࡷࡹ࠭ᷫ"),FmYoGejTnwKME7d9zPc(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡇࡣࡋࡇࡉࡍࡇࡇࠫᷬ"))
		iYMzQVNL2h4IRemt = D2D96X5NGamBhrFwvL8VEbqiSfZIl
		for title,bigdh7fpZYl4aT2keV in list(zip(WFlpmsYGKNy,XoSyx7p6dqZ1CF8)):
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.split(ssynAg0zhSkoCpOMDV9(u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᷭ"),BkM54Kr7Qbqn)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			if bigdh7fpZYl4aT2keV in GbZV3aPJtwDxjhndC45HpI:
				hhFDimGWBaJTMx9NfbyS0 += BkM54Kr7Qbqn
				WFlpmsYGKNy[iYMzQVNL2h4IRemt] = ISYP5dC9xevhz0lJoV67cNfXM+title+T7ASIp1ZYwio9HQ8cObJK
			elif bigdh7fpZYl4aT2keV in jZeyuFlns5WY7Ovb9PGJa8kxfr:
				hhFDimGWBaJTMx9NfbyS0 += BkM54Kr7Qbqn
				WFlpmsYGKNy[iYMzQVNL2h4IRemt] = n0nFOd4yR97fQzNLSW+title+T7ASIp1ZYwio9HQ8cObJK
			elif bigdh7fpZYl4aT2keV in KNx8k4BUbySJcztjVgG0w:
				hhFDimGWBaJTMx9NfbyS0 += BkM54Kr7Qbqn
				WFlpmsYGKNy[iYMzQVNL2h4IRemt] = title
			else:
				hhFDimGWBaJTMx9NfbyS0 += BkM54Kr7Qbqn
				WFlpmsYGKNy[iYMzQVNL2h4IRemt] = title
			iYMzQVNL2h4IRemt += BkM54Kr7Qbqn
		j25T6eKhaMk3 = [WydpaVx5YmLoCiIgA34eEBlb+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠫๆำีࠡฮ่๎฾ࠦวๅีํีๆืวหࠩᷮ")+T7ASIp1ZYwio9HQ8cObJK]
	else: uGEX2dCfRLoePc0QZztBOsVIaT5x = WydpaVx5YmLoCiIgA34eEBlb+aOQTKXFL54Nl60Zhp3MbE(u"ࠬษฮหำࠣหู้๊าใิࠤฬ๊ๅ็ษึฬࠬᷯ")+T7ASIp1ZYwio9HQ8cObJK
	O0nkSFcZRm182p47v69tG = OdiZIyCfDUsW3JBGR2VAb.getSetting(QjAINyUC7MDRq5d8e4vl9(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡥ࡭ࡹࡸࡡࡵࡧࠪᷰ"))
	NpXaZHtWwMEjskeu5CI6KJLh0T = EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧ࠮ࠩᷱ") not in O0nkSFcZRm182p47v69tG
	while EsCplGc5N4mBuYW0RVQt6b:
		TplHBnOa5qu6cDQKJLAs = EsCplGc5N4mBuYW0RVQt6b
		if HvI5mjsbOa08yTuq4e3olP:
			if NpXaZHtWwMEjskeu5CI6KJLh0T and len(WFlpmsYGKNy)==BkM54Kr7Qbqn: yNqzFDjKM0SrO = BkM54Kr7Qbqn
			else:
				PPO4Uck32dFICoLph = str(WFlpmsYGKNy).count(ISYP5dC9xevhz0lJoV67cNfXM)
				Qe172zUxGrKaq8NDZjSEI = str(WFlpmsYGKNy).count(n0nFOd4yR97fQzNLSW)
				PnsqwlNz4CjLmkB1tH8MRaZ = len(WFlpmsYGKNy)-PPO4Uck32dFICoLph-Qe172zUxGrKaq8NDZjSEI
				if gZlSEJaXO9F461AL3sR7rWNpqf: uGEX2dCfRLoePc0QZztBOsVIaT5x = n0nFOd4yR97fQzNLSW+Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠨࠢࠣࠤุ๐ฦส࠼ࠪᷲ")+str(Qe172zUxGrKaq8NDZjSEI)+T7ASIp1ZYwio9HQ8cObJK+jL5CrsRwebpyDVXUc1EQP(u"ࠩࠣࠤ๋ࠥฬ่๊็อ࠿࠭ᷳ")+str(PnsqwlNz4CjLmkB1tH8MRaZ)+ISYP5dC9xevhz0lJoV67cNfXM+C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠪะ๏ีษ࠻ࠩᷴ")+str(PPO4Uck32dFICoLph)+T7ASIp1ZYwio9HQ8cObJK
				else: uGEX2dCfRLoePc0QZztBOsVIaT5x = ISYP5dC9xevhz0lJoV67cNfXM+jL5CrsRwebpyDVXUc1EQP(u"ࠫั๐ฯส࠼ࠪ᷵")+str(PPO4Uck32dFICoLph)+T7ASIp1ZYwio9HQ8cObJK+oRJAfwD957WkUyBM1Ehu8m(u"ࠬࠦࠠࠡ็ฯ๋ํ๊ษ࠻ࠩ᷶")+str(PnsqwlNz4CjLmkB1tH8MRaZ)+n0nFOd4yR97fQzNLSW+OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠭ࠠࠡࠢึ๎หฯ࠺ࠨ᷷")+str(Qe172zUxGrKaq8NDZjSEI)+T7ASIp1ZYwio9HQ8cObJK
				yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S(uGEX2dCfRLoePc0QZztBOsVIaT5x,j25T6eKhaMk3+WFlpmsYGKNy)
			if yNqzFDjKM0SrO==D2D96X5NGamBhrFwvL8VEbqiSfZIl:
				TplHBnOa5qu6cDQKJLAs = LhFAGlQ19zr
				start,end = D2D96X5NGamBhrFwvL8VEbqiSfZIl,len(WFlpmsYGKNy)-BkM54Kr7Qbqn
				HQk0NXpoaAdDg9nI15LZqc8Yjfze = qs8vLCo5IUPu30dfEnl1hz6(WFlpmsYGKNy,XoSyx7p6dqZ1CF8,source,EsCplGc5N4mBuYW0RVQt6b)
				wUqsFlvdyKfa2cCYme = N6NGJ4vpmidqMCh7yo(u"ࠧࡳࡧࡶࡳࡱࡼࡥࡥࡡࡤࡰࡱ᷸࠭") if HQk0NXpoaAdDg9nI15LZqc8Yjfze else I18uSKaWhgTBeYUPD4sr(u"ࠨࡰࡲࡸࡤࡸࡥࡴࡱ࡯ࡺࡦࡨ࡬ࡦ᷹ࠩ")
			elif yNqzFDjKM0SrO>D2D96X5NGamBhrFwvL8VEbqiSfZIl: start,end = yNqzFDjKM0SrO-BkM54Kr7Qbqn,yNqzFDjKM0SrO-BkM54Kr7Qbqn
		else:
			if NpXaZHtWwMEjskeu5CI6KJLh0T and len(WFlpmsYGKNy)==BkM54Kr7Qbqn: yNqzFDjKM0SrO = D2D96X5NGamBhrFwvL8VEbqiSfZIl
			else: yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S(uGEX2dCfRLoePc0QZztBOsVIaT5x,WFlpmsYGKNy)
			start,end = yNqzFDjKM0SrO,yNqzFDjKM0SrO
		if yNqzFDjKM0SrO==-BkM54Kr7Qbqn:
			wUqsFlvdyKfa2cCYme = SnhLjmfeJC(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧ᷺ࠫ")
			break
		if TplHBnOa5qu6cDQKJLAs:
			wUqsFlvdyKfa2cCYme = sIzDXlTHYUC5L3xZGnr(u"ࠪࡶࡪࡹ࡯࡭ࡸࡨࡨࡤࡵ࡮ࡦࠩ᷻")
			HQk0NXpoaAdDg9nI15LZqc8Yjfze = qs8vLCo5IUPu30dfEnl1hz6([WFlpmsYGKNy[start]],[XoSyx7p6dqZ1CF8[start]],source,EsCplGc5N4mBuYW0RVQt6b)
			title,bigdh7fpZYl4aT2keV,OK2mcs7f1ekzACupF,p7Gkego0m6a8,zzECVswWcGAIXhrQlZ7jMokugnv,nn7D6Z5AlxNQaBqpIWGVJFCROk = HQk0NXpoaAdDg9nI15LZqc8Yjfze[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			HA5uKCmvNspPTlQ1cntUg03GYh,Banw8tis9cfSXd61NryRVPK7Z0vh43 = ykZQg1zEHjmnf98rtqTJadMOeh(title,bigdh7fpZYl4aT2keV,p7Gkego0m6a8,zzECVswWcGAIXhrQlZ7jMokugnv,source,ZJqDh4ByGPQn13tlzMOTLCNdcugx)
			if HA5uKCmvNspPTlQ1cntUg03GYh in [EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠩ᷼"),sIzDXlTHYUC5L3xZGnr(u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬᷽࠭"),vU6DxuzPwMpg(u"࠭ࡴࡦࡵࡷ࡭ࡳ࡭ࠧ᷾")]:
				gcFGxSyQJEHPsY = EsCplGc5N4mBuYW0RVQt6b
				break
			else:
				if not OK2mcs7f1ekzACupF: OK2mcs7f1ekzACupF = oRJAfwD957WkUyBM1Ehu8m(u"ࠧࡗ࡫ࡧࡩࡴࠦࡰ࡭ࡣࡼࠤ࡫ࡧࡩ࡭ࡧࡧ᷿ࠫ")
				title = n0nFOd4yR97fQzNLSW+title+T7ASIp1ZYwio9HQ8cObJK
				HQk0NXpoaAdDg9nI15LZqc8Yjfze[D2D96X5NGamBhrFwvL8VEbqiSfZIl] = title,bigdh7fpZYl4aT2keV,OK2mcs7f1ekzACupF,p7Gkego0m6a8,zzECVswWcGAIXhrQlZ7jMokugnv,nn7D6Z5AlxNQaBqpIWGVJFCROk
				uPmowMLjc1UJ27Nzd0CK = bigdh7fpZYl4aT2keV.split(oRJAfwD957WkUyBM1Ehu8m(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩḀ"),BkM54Kr7Qbqn)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
				gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡇࡣࡘ࡛ࡃࡄࡇࡈࡈࡊࡊࠧḁ"),uPmowMLjc1UJ27Nzd0CK)
				tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,uulNDCPyef78(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡈࡤࡌࡁࡊࡎࡈࡈࠬḂ"),uPmowMLjc1UJ27Nzd0CK,[OK2mcs7f1ekzACupF,title,bigdh7fpZYl4aT2keV],CQOaFUrZJHwKRxIj4yXEYs5V)
			if OK2mcs7f1ekzACupF==PlpyFa9QMKXxOD1cvHzmI(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩḃ"): break
			poD2vOIqRzaJ9VhUA8P51KsBCbmgn = ssynAg0zhSkoCpOMDV9(u"ࠬࡡࡌࡆࡈࡗࡡࠥࠦࠧḄ")+OK2mcs7f1ekzACupF.replace(C0qrknitpM4Z,sIzDXlTHYUC5L3xZGnr(u"࠭࡜࡯࡝ࡏࡉࡋ࡚࡝ࠡࠢࠪḅ")) if OK2mcs7f1ekzACupF.count(C0qrknitpM4Z)>sJw9QWiq1Kr0xfeVRI(u"࠷ഫ") else C0qrknitpM4Z+OK2mcs7f1ekzACupF
			if s5WMHyQN4mpie(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨḆ") not in source: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,FgXzMs0YSDt(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫḇ"),oRJAfwD957WkUyBM1Ehu8m(u"ࠩสุ่๐ัโำฺ่๊๊ࠣࠦ็็ࠤัืศࠡีํีๆืࠠ฻์ิ๋ࡡࡴࠧḈ")+poD2vOIqRzaJ9VhUA8P51KsBCbmgn,profile=LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡲ࡫ࡤࡪࡷࡰࡪࡴࡴࡴࠨḉ"))
			if len(XoSyx7p6dqZ1CF8)==BkM54Kr7Qbqn and OK2mcs7f1ekzACupF: break
		for iYMzQVNL2h4IRemt in range(start,end+BkM54Kr7Qbqn):
			Nxce6pW02h1MAYdmJHgbzIRl = D2D96X5NGamBhrFwvL8VEbqiSfZIl if TplHBnOa5qu6cDQKJLAs else iYMzQVNL2h4IRemt
			title,bigdh7fpZYl4aT2keV,OK2mcs7f1ekzACupF,p7Gkego0m6a8,zzECVswWcGAIXhrQlZ7jMokugnv,nn7D6Z5AlxNQaBqpIWGVJFCROk = HQk0NXpoaAdDg9nI15LZqc8Yjfze[Nxce6pW02h1MAYdmJHgbzIRl]
			WFlpmsYGKNy[iYMzQVNL2h4IRemt] = WFlpmsYGKNy[iYMzQVNL2h4IRemt].replace(n0nFOd4yR97fQzNLSW,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(ISYP5dC9xevhz0lJoV67cNfXM,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(hjFvOY978VxiNa5dy,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			if nn7D6Z5AlxNQaBqpIWGVJFCROk==Hr25gta6XcqO(u"ࠫࡸࡻࡣࡤࡧࡶࡷࠬḊ"): WFlpmsYGKNy[iYMzQVNL2h4IRemt] = ISYP5dC9xevhz0lJoV67cNfXM+WFlpmsYGKNy[iYMzQVNL2h4IRemt]+T7ASIp1ZYwio9HQ8cObJK
			elif nn7D6Z5AlxNQaBqpIWGVJFCROk==s5WMHyQN4mpie(u"ࠬ࡬ࡡࡪ࡮ࡸࡶࡪ࠭ḋ"): WFlpmsYGKNy[iYMzQVNL2h4IRemt] = n0nFOd4yR97fQzNLSW+WFlpmsYGKNy[iYMzQVNL2h4IRemt]+T7ASIp1ZYwio9HQ8cObJK
			else: WFlpmsYGKNy[iYMzQVNL2h4IRemt] = WFlpmsYGKNy[iYMzQVNL2h4IRemt]
	if wUqsFlvdyKfa2cCYme==CsDcLqQUVK4YBvHFW1(u"࠭࡮ࡰࡶࡢࡶࡪࡹ࡯࡭ࡸࡤࡦࡱ࡫ࠧḌ"): GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,SnhLjmfeJC(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪḍ"),FgXzMs0YSDt(u"ࠨๆ็วุ็ࠠๅษࠣ๎ําฯࠡีํีๆืวหࠢฯ๎ิฯࠠโ์๋ࠣีอࠠศๆไ๎ิ๐่ࠡ࠰࠱ࠤาอ่ๅࠢฦ๊ࠥะศฮอࠣ฽๋ࠦ็ัษࠣห้็๊ะ์๋ࠤๆ๐ࠠๆ๊สๆ฾ࠦรฯำ์ࠤๆ๐่ࠠาสࠤฬ๊ศา่ส้ั࠭Ḏ"))
	if not gcFGxSyQJEHPsY or wUqsFlvdyKfa2cCYme in [C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࠫḏ"),EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪࡲࡴࡺ࡟ࡳࡧࡶࡳࡱࡼࡡࡣ࡮ࡨࠫḐ")] or OK2mcs7f1ekzACupF:
		lgLp2rPtWsycxonO3jk = bEWpDHXjCBqd7aOiN6UG5k.executeJSONRPC(aOQTKXFL54Nl60Zhp3MbE(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡔࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡉ࡬ࡦࡣࡵࠦ࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡳࡰࡦࡿ࡬ࡪࡵࡷ࡭ࡩࠨ࠺࠲ࡿࢀࠫḑ"))
	return
def qs8vLCo5IUPu30dfEnl1hz6(paJKP0Usbeju4liH,hFzEyHWOoRxG,source,showDialogs):
	global IPJ7yi4HSLna2UE,BS2ZMby0DqmcCdR,VY1bXQc8jKk,dk6SMCobOpfWnLu,LtN7PToYanhvc84I0DgdVp6mAzH,FsLGmERkA6CnPKaWQo
	IPJ7yi4HSLna2UE,BS2ZMby0DqmcCdR,VY1bXQc8jKk,dk6SMCobOpfWnLu,LtN7PToYanhvc84I0DgdVp6mAzH,FsLGmERkA6CnPKaWQo = [],[],[],[],[],[]
	OmsWt89dSA5HyCZ4wL,tsdoXzOypVNJ6MuC5DeUS9q47mvL,new = [],[],[]
	ZBILqw92kAymRHD7GstV(DDIe1w6Gj3NMV9E08FtqxbSsh,DDIe1w6Gj3NMV9E08FtqxbSsh,DDIe1w6Gj3NMV9E08FtqxbSsh)
	count = len(hFzEyHWOoRxG)
	for nOJQDh1rV9ZWyNzwHas6dMFml0 in range(count):
		IPJ7yi4HSLna2UE.append(zA8Ry1KDvmr3w4B5xeP)
		BS2ZMby0DqmcCdR.append(zA8Ry1KDvmr3w4B5xeP)
		VY1bXQc8jKk.append(zA8Ry1KDvmr3w4B5xeP)
		dk6SMCobOpfWnLu.append(zA8Ry1KDvmr3w4B5xeP)
		LtN7PToYanhvc84I0DgdVp6mAzH.append(zA8Ry1KDvmr3w4B5xeP)
		FsLGmERkA6CnPKaWQo.append(D2D96X5NGamBhrFwvL8VEbqiSfZIl)
		title = paJKP0Usbeju4liH[nOJQDh1rV9ZWyNzwHas6dMFml0]
		bigdh7fpZYl4aT2keV = hFzEyHWOoRxG[nOJQDh1rV9ZWyNzwHas6dMFml0].strip(ksJdoFWhxTz8Y2N7bOZE).strip(wdftVMyzF17cYETHu(u"ࠬࠬࠧḒ")).strip(LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠭࠿ࠨḓ")).strip(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠧ࠰ࠩḔ"))
		if count>BkM54Kr7Qbqn and showDialogs: a6rVSjDMF87KyYINcuOP1l40Hbp(I18uSKaWhgTBeYUPD4sr(u"ࠨใะูู๊ࠥาใิࠤึ่ๅࠡࠢࠪḕ")+str(nOJQDh1rV9ZWyNzwHas6dMFml0+N6NGJ4vpmidqMCh7yo(u"࠶ബ")),title)
		PheoWN6GtlZ = [FgXzMs0YSDt(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪḖ"),vU6DxuzPwMpg(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨḗ"),FmYoGejTnwKME7d9zPc(u"ࠫࡆࡑࡗࡂࡏࠪḘ")]
		if source in PheoWN6GtlZ: IPJ7yi4HSLna2UE[nOJQDh1rV9ZWyNzwHas6dMFml0] = rYcBZgAqE1jvuMLIS(title,bigdh7fpZYl4aT2keV,source,nOJQDh1rV9ZWyNzwHas6dMFml0)
		else:
			if BkM54Kr7Qbqn:
				dBT1QPwRvpSMhfjDsZiLlHU = YMsWIfu7ojp2t4XJyZN05aC3l(daemon=EsCplGc5N4mBuYW0RVQt6b,target=rYcBZgAqE1jvuMLIS,args=(title,bigdh7fpZYl4aT2keV,source,nOJQDh1rV9ZWyNzwHas6dMFml0))
				tsdoXzOypVNJ6MuC5DeUS9q47mvL.append(dBT1QPwRvpSMhfjDsZiLlHU)
				new.append(nOJQDh1rV9ZWyNzwHas6dMFml0)
	def xywa5QMgJmUicBh8WXzG0():
		B86BtJkdcozNuC4 = LhFAGlQ19zr
		for bigdh7fpZYl4aT2keV in IPJ7yi4HSLna2UE:
			if not bigdh7fpZYl4aT2keV: break
		else: B86BtJkdcozNuC4 = EsCplGc5N4mBuYW0RVQt6b
		cpwFIvHO0Db7hKTylq6S4nJj = bEWpDHXjCBqd7aOiN6UG5k.Player().isPlaying() if I4t9qonjrm.resolveonly else EsCplGc5N4mBuYW0RVQt6b
		return B86BtJkdcozNuC4 or not cpwFIvHO0Db7hKTylq6S4nJj
	kkfj6pyAalMWxoJKmnhFYutVrI9PZd(tsdoXzOypVNJ6MuC5DeUS9q47mvL,I21pK8eAmNMHE6OiJsYRD,Gcw2nelTR864XCVruO3mAFqI5a(u"࠶࠮࠲ഭ"),teaC5j4HuGDqpwcmUzJ,xywa5QMgJmUicBh8WXzG0)
	for nOJQDh1rV9ZWyNzwHas6dMFml0 in range(count):
		title = paJKP0Usbeju4liH[nOJQDh1rV9ZWyNzwHas6dMFml0]
		bigdh7fpZYl4aT2keV = hFzEyHWOoRxG[nOJQDh1rV9ZWyNzwHas6dMFml0].strip(ksJdoFWhxTz8Y2N7bOZE).strip(vU6DxuzPwMpg(u"ࠬࠬࠧḙ")).strip(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠭࠿ࠨḚ")).strip(ssynAg0zhSkoCpOMDV9(u"ࠧ࠰ࠩḛ"))
		uPmowMLjc1UJ27Nzd0CK = bigdh7fpZYl4aT2keV.split(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩḜ"),BkM54Kr7Qbqn)[D2D96X5NGamBhrFwvL8VEbqiSfZIl] if nOJQDh1rV9ZWyNzwHas6dMFml0 in new else LhFAGlQ19zr
		stream = IPJ7yi4HSLna2UE[nOJQDh1rV9ZWyNzwHas6dMFml0]
		if stream and not stream[D2D96X5NGamBhrFwvL8VEbqiSfZIl] and stream[teaC5j4HuGDqpwcmUzJ]:
			nn7D6Z5AlxNQaBqpIWGVJFCROk = AAbvaXV2DQzfNHdm4U3tT(u"ࠩࡶࡹࡨࡩࡥࡴࡵࠪḝ")
			poD2vOIqRzaJ9VhUA8P51KsBCbmgn,D4DQ6k0oS39GKbZrthnsTB,R9b8gUvoB4wOfkTIjlEsZrM5LtinpS = stream
			if uPmowMLjc1UJ27Nzd0CK: tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡈࡤ࡙ࡕࡄࡅࡈࡉࡉࡋࡄࠨḞ"),uPmowMLjc1UJ27Nzd0CK,[poD2vOIqRzaJ9VhUA8P51KsBCbmgn,D4DQ6k0oS39GKbZrthnsTB,R9b8gUvoB4wOfkTIjlEsZrM5LtinpS],CQOaFUrZJHwKRxIj4yXEYs5V)
		elif stream and stream[D2D96X5NGamBhrFwvL8VEbqiSfZIl] and not stream[BkM54Kr7Qbqn] and not stream[teaC5j4HuGDqpwcmUzJ]:
			nn7D6Z5AlxNQaBqpIWGVJFCROk = N6NGJ4vpmidqMCh7yo(u"ࠫ࡫ࡧࡩ࡭ࡷࡵࡩࠬḟ")
			poD2vOIqRzaJ9VhUA8P51KsBCbmgn,D4DQ6k0oS39GKbZrthnsTB,R9b8gUvoB4wOfkTIjlEsZrM5LtinpS = PlpyFa9QMKXxOD1cvHzmI(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࡓࡧࡶࡳࡱࡼࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࡟ࡲࠬḠ")+stream[D2D96X5NGamBhrFwvL8VEbqiSfZIl],[],[]
			if uPmowMLjc1UJ27Nzd0CK: tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,aOQTKXFL54Nl60Zhp3MbE(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡄࡠࡈࡄࡍࡑࡋࡄࠨḡ"),uPmowMLjc1UJ27Nzd0CK,[poD2vOIqRzaJ9VhUA8P51KsBCbmgn,D4DQ6k0oS39GKbZrthnsTB,R9b8gUvoB4wOfkTIjlEsZrM5LtinpS],CQOaFUrZJHwKRxIj4yXEYs5V)
		elif FsLGmERkA6CnPKaWQo[nOJQDh1rV9ZWyNzwHas6dMFml0]+BkM54Kr7Qbqn>bznkhxWOTcZLaF2U6A4iKd30NI:
			nn7D6Z5AlxNQaBqpIWGVJFCROk = Hr25gta6XcqO(u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨḢ")
			poD2vOIqRzaJ9VhUA8P51KsBCbmgn,D4DQ6k0oS39GKbZrthnsTB,R9b8gUvoB4wOfkTIjlEsZrM5LtinpS = o1INZ3ViQqS0Uw5z6kMjbv(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࡖࡪࡹ࡯࡭ࡸ࡬ࡲ࡬ࠦࡴࡪ࡯ࡨࡨࠥࡵࡵࡵࠢࠫࠫḣ")+str(FsLGmERkA6CnPKaWQo[nOJQDh1rV9ZWyNzwHas6dMFml0])+N6NGJ4vpmidqMCh7yo(u"ࠩࠣࡷࡪࡩ࡯࡯ࡦࡶ࠭ࠬḤ"),[],[]
			if uPmowMLjc1UJ27Nzd0CK: tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓ࠭ḥ"),uPmowMLjc1UJ27Nzd0CK,[poD2vOIqRzaJ9VhUA8P51KsBCbmgn,D4DQ6k0oS39GKbZrthnsTB,R9b8gUvoB4wOfkTIjlEsZrM5LtinpS],CQOaFUrZJHwKRxIj4yXEYs5V)
		elif not stream:
			nn7D6Z5AlxNQaBqpIWGVJFCROk = aOQTKXFL54Nl60Zhp3MbE(u"ࠫࡨࡧ࡮ࡤࡧ࡯ࠫḦ")
			poD2vOIqRzaJ9VhUA8P51KsBCbmgn,D4DQ6k0oS39GKbZrthnsTB,R9b8gUvoB4wOfkTIjlEsZrM5LtinpS = C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࡓࡧࡶࡳࡱࡼࡩ࡯ࡩࠣࡧࡦࡴࡣࡦ࡮ࡨࡨࠬḧ"),[],[]
			if uPmowMLjc1UJ27Nzd0CK: tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,CsDcLqQUVK4YBvHFW1(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡄࡠࡗࡑࡏࡓࡕࡗࡏࠩḨ"),uPmowMLjc1UJ27Nzd0CK,[poD2vOIqRzaJ9VhUA8P51KsBCbmgn,D4DQ6k0oS39GKbZrthnsTB,R9b8gUvoB4wOfkTIjlEsZrM5LtinpS],CQOaFUrZJHwKRxIj4yXEYs5V)
		else:
			nn7D6Z5AlxNQaBqpIWGVJFCROk = I18uSKaWhgTBeYUPD4sr(u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨḩ")
			poD2vOIqRzaJ9VhUA8P51KsBCbmgn,D4DQ6k0oS39GKbZrthnsTB,R9b8gUvoB4wOfkTIjlEsZrM5LtinpS = EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻࡙ࠢࠣࡳࡱ࡮ࡰࡹࡱࠤࡷ࡫ࡳࡰ࡮ࡹ࡭ࡳ࡭ࠠࡧࡣ࡬ࡰࡺࡸࡥࠨḪ"),[],[]
			if uPmowMLjc1UJ27Nzd0CK: tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,ssynAg0zhSkoCpOMDV9(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡇࡣ࡚ࡔࡋࡏࡑ࡚ࡒࠬḫ"),uPmowMLjc1UJ27Nzd0CK,[poD2vOIqRzaJ9VhUA8P51KsBCbmgn,D4DQ6k0oS39GKbZrthnsTB,R9b8gUvoB4wOfkTIjlEsZrM5LtinpS],CQOaFUrZJHwKRxIj4yXEYs5V)
		OmsWt89dSA5HyCZ4wL.append([title,bigdh7fpZYl4aT2keV,poD2vOIqRzaJ9VhUA8P51KsBCbmgn,D4DQ6k0oS39GKbZrthnsTB,R9b8gUvoB4wOfkTIjlEsZrM5LtinpS,nn7D6Z5AlxNQaBqpIWGVJFCROk])
	ZBILqw92kAymRHD7GstV(LLvswCIAk0tubrKgFpPW4BVf,LLvswCIAk0tubrKgFpPW4BVf,LLvswCIAk0tubrKgFpPW4BVf)
	return OmsWt89dSA5HyCZ4wL
def rYcBZgAqE1jvuMLIS(A8ECQ0qwTRzPifOGW76FK35uUvhe,url,source,gLoUCe7WqVp):
	global IPJ7yi4HSLna2UE,FsLGmERkA6CnPKaWQo
	FsLGmERkA6CnPKaWQo[gLoUCe7WqVp] = D2D96X5NGamBhrFwvL8VEbqiSfZIl
	TYfRSPL2HA3GuXIbgjyzBN69Wms = uUqrNPcXKBoQ0slv.time()
	Clc8sIj97ZrThF(wVhZ6bfkpSre95EFu,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+ggjO5CrKVRPITaesWkxD(u"ࠪࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡯࡮ࡨࠢࡶࡸࡦࡸࡴࡦࡦࠣࠤ࡙ࠥࡥ࡭ࡧࡦࡸࡪࡪ࠺ࠡ࡝ࠣࠫḬ")+A8ECQ0qwTRzPifOGW76FK35uUvhe+vU6DxuzPwMpg(u"ࠫࠥࡣࠠࠡࠢࡒࡶ࡮࡭ࡩ࡯ࡣ࡯࠾ࠥࡡࠠࠨḭ")+url+wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠬࠦ࡝ࠨḮ"))
	bigdh7fpZYl4aT2keV,hPVlYCXsfnx5 = url,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	rn9K8xcCvubz2adq3S = sJw9QWiq1Kr0xfeVRI(u"࠭ࡉࡏࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࠪḯ")
	OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = NL1KAXyY3Dw2(url,source)
	if OK2mcs7f1ekzACupF==C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬḰ"):
		IPJ7yi4HSLna2UE[gLoUCe7WqVp] = QjAINyUC7MDRq5d8e4vl9(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ḱ"),[],[]
		FsLGmERkA6CnPKaWQo[gLoUCe7WqVp] = uUqrNPcXKBoQ0slv.time()-TYfRSPL2HA3GuXIbgjyzBN69Wms
		return IPJ7yi4HSLna2UE[gLoUCe7WqVp]
	elif EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬḲ") in OK2mcs7f1ekzACupF:
		hPVlYCXsfnx5 = OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠲࠼ࠣࠤࡓ࡫ࡥࡥࠢࡈࡼࡹ࡫ࡲ࡯ࡣ࡯ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࡹࠠࠩ࠴࠰࠹࠮࠭ḳ")
		bigdh7fpZYl4aT2keV = cymM76PR0aiVnX5gZ(XoSyx7p6dqZ1CF8)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		rn9K8xcCvubz2adq3S,hPVlYCXsfnx5,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = rrDyq9ReVmEMBxsdbCw(hPVlYCXsfnx5,bigdh7fpZYl4aT2keV,source,gLoUCe7WqVp)
		if hPVlYCXsfnx5==O3OVuapf0YFjbm5oUQDg(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩḴ"):
			IPJ7yi4HSLna2UE[gLoUCe7WqVp] = hPVlYCXsfnx5,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
			FsLGmERkA6CnPKaWQo[gLoUCe7WqVp] = uUqrNPcXKBoQ0slv.time()-TYfRSPL2HA3GuXIbgjyzBN69Wms
			return hPVlYCXsfnx5,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
	elif OK2mcs7f1ekzACupF: hPVlYCXsfnx5 = O3OVuapf0YFjbm5oUQDg(u"ࠬࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠲࠼ࠣࠤࠬḵ")+OK2mcs7f1ekzACupF.replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(FFkml6ZbgXD,fy8iFgEkrO12NR9TWBI35sjY6qHvV)[:QjAINyUC7MDRq5d8e4vl9(u"࠸࠱മ")]
	if XoSyx7p6dqZ1CF8:
		XoSyx7p6dqZ1CF8 = cymM76PR0aiVnX5gZ(XoSyx7p6dqZ1CF8)
		Clc8sIj97ZrThF(wVhZ6bfkpSre95EFu,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+s5WMHyQN4mpie(u"࠭ࠠࠡࠢࡕࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡩࡩ࡫ࡤࠡࠢࠣࡗࡪࡲࡥࡤࡶࡨࡨ࠿࡛ࠦࠡࠩḶ")+A8ECQ0qwTRzPifOGW76FK35uUvhe+N6NGJ4vpmidqMCh7yo(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡴࡱ࡯ࡺࡪࡸ࠺ࠡ࡝ࠣࠫḷ")+rn9K8xcCvubz2adq3S+aOQTKXFL54Nl60Zhp3MbE(u"ࠨࠢࡠࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬḸ")+url+wdftVMyzF17cYETHu(u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩḹ")+bigdh7fpZYl4aT2keV+FgXzMs0YSDt(u"ࠪࠤࡢࠦࠠࠡࠢࠣࠤ࡛࡯ࡤࡦࡱࡶ࠾ࠥࡡࠠࠨḺ")+str(XoSyx7p6dqZ1CF8)+Hr25gta6XcqO(u"ࠫࠥࡣࠧḻ"))
	else: Clc8sIj97ZrThF(wVhZ6bfkpSre95EFu,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+EE1jeHnIoad(u"ࠬࠦࠠࠡࡔࡨࡷࡴࡲࡶࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤ࠻ࠢ࡞ࠤࠬḼ")+A8ECQ0qwTRzPifOGW76FK35uUvhe+oRJAfwD957WkUyBM1Ehu8m(u"࠭ࠠ࡞ࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪḽ")+url+O3OVuapf0YFjbm5oUQDg(u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧḾ")+bigdh7fpZYl4aT2keV+AAbvaXV2DQzfNHdm4U3tT(u"ࠨࠢࡠࠤࠥࠦࡅࡳࡴࡲࡶࡸࡀࠠ࡜ࠢࠪḿ")+hPVlYCXsfnx5+ggjO5CrKVRPITaesWkxD(u"ࠩࠣࡡࠬṀ"))
	hPVlYCXsfnx5 = U2Z7CVFftTmLeK3nzEbQPGga(hPVlYCXsfnx5)
	IPJ7yi4HSLna2UE[gLoUCe7WqVp] = hPVlYCXsfnx5,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
	FsLGmERkA6CnPKaWQo[gLoUCe7WqVp] = uUqrNPcXKBoQ0slv.time()-TYfRSPL2HA3GuXIbgjyzBN69Wms
	return hPVlYCXsfnx5,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
def ykZQg1zEHjmnf98rtqTJadMOeh(title,bigdh7fpZYl4aT2keV,WFlpmsYGKNy,XoSyx7p6dqZ1CF8,source,ZJqDh4ByGPQn13tlzMOTLCNdcugx=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if XoSyx7p6dqZ1CF8:
		if not WFlpmsYGKNy[D2D96X5NGamBhrFwvL8VEbqiSfZIl]: WFlpmsYGKNy = XoSyx7p6dqZ1CF8
		O0nkSFcZRm182p47v69tG = OdiZIyCfDUsW3JBGR2VAb.getSetting(LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡢࡪࡶࡵࡥࡹ࡫ࠧṁ"))
		NpXaZHtWwMEjskeu5CI6KJLh0T = Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫ࠲࠭Ṃ") not in O0nkSFcZRm182p47v69tG
		while EsCplGc5N4mBuYW0RVQt6b:
			if NpXaZHtWwMEjskeu5CI6KJLh0T and len(XoSyx7p6dqZ1CF8)==BkM54Kr7Qbqn: yNqzFDjKM0SrO = D2D96X5NGamBhrFwvL8VEbqiSfZIl
			else: yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠫṃ"), WFlpmsYGKNy)
			if yNqzFDjKM0SrO==-BkM54Kr7Qbqn: s9qgDT8oclCrdXK6EUO = Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࠨṄ")
			else:
				dGsCpVjz49i1 = XoSyx7p6dqZ1CF8[yNqzFDjKM0SrO]
				Clc8sIj97ZrThF(wVhZ6bfkpSre95EFu,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+oRJAfwD957WkUyBM1Ehu8m(u"ࠧࠡࠢࠣࡔࡱࡧࡹࡪࡰࡪࠤࡸࡺࡡࡳࡶࡨࡨࠥࠦࠠࡔࡧ࡯ࡩࡨࡺࡥࡥ࠼ࠣ࡟ࠥ࠭ṅ")+title+Hr25gta6XcqO(u"ࠨࠢࡠࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬṆ")+bigdh7fpZYl4aT2keV+Gcw2nelTR864XCVruO3mAFqI5a(u"ࠩࠣࡡࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪṇ")+str(dGsCpVjz49i1)+QjAINyUC7MDRq5d8e4vl9(u"ࠪࠤࡢ࠭Ṉ"))
				if C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴ࠧṉ") in dGsCpVjz49i1 and EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠬṊ") in dGsCpVjz49i1:
					poD2vOIqRzaJ9VhUA8P51KsBCbmgn,O9nG5azDistV1c,TCGZwKs43fSniQe6EqctNuW = WV1rqvfF7Ll(dGsCpVjz49i1)
					if TCGZwKs43fSniQe6EqctNuW: dGsCpVjz49i1 = TCGZwKs43fSniQe6EqctNuW[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
					else: dGsCpVjz49i1 = fy8iFgEkrO12NR9TWBI35sjY6qHvV
				if not dGsCpVjz49i1: s9qgDT8oclCrdXK6EUO = jL5CrsRwebpyDVXUc1EQP(u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪṋ")
				else: s9qgDT8oclCrdXK6EUO = E7HR1ZcMuzUs9XCVrNGJYi(dGsCpVjz49i1,source,ZJqDh4ByGPQn13tlzMOTLCNdcugx)
			if s9qgDT8oclCrdXK6EUO in [wdftVMyzF17cYETHu(u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨṌ"),EE1jeHnIoad(u"ࠨࡶࡨࡷࡹ࡯࡮ࡨࠩṍ"),oRJAfwD957WkUyBM1Ehu8m(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭ࠧṎ"),N6NGJ4vpmidqMCh7yo(u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࠬṏ")] or len(XoSyx7p6dqZ1CF8)==SnhLjmfeJC(u"࠲യ"): break
			elif s9qgDT8oclCrdXK6EUO in [wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫṐ"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭ṑ"),wdftVMyzF17cYETHu(u"࠭ࡴࡳ࡫ࡨࡨࠬṒ")]: break
			else: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,uulNDCPyef78(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪṓ"),C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨษ็้้็ࠠๅ็ࠣ๎฾๋ไࠡฮิฬ๋ࠥไโࠢ฽๎ึํࠧṔ"))
	else:
		s9qgDT8oclCrdXK6EUO = wdftVMyzF17cYETHu(u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭ṕ")
		if ml1bXR85BJyhPAVvQY(bigdh7fpZYl4aT2keV): s9qgDT8oclCrdXK6EUO = E7HR1ZcMuzUs9XCVrNGJYi(bigdh7fpZYl4aT2keV,source,ZJqDh4ByGPQn13tlzMOTLCNdcugx)
	return s9qgDT8oclCrdXK6EUO,XoSyx7p6dqZ1CF8
def T2IyJpEoPQKNw8(url,source):
	YLKFRH6sSIrznXBg,LLl9rOnRTypKFcBhM8,A8ECQ0qwTRzPifOGW76FK35uUvhe,bbBWiXefkN7VOpUhLQPGwIZF40s,z36flodJVD9jWxip14Rh,ZJqDh4ByGPQn13tlzMOTLCNdcugx,BIbU1q2NrFX,OOnVxtP0TNWsci6HrEGqBm9boKF7g,V6gGYKEO8UqQZ = url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if sJw9QWiq1Kr0xfeVRI(u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫṖ") in url:
		YLKFRH6sSIrznXBg,LLl9rOnRTypKFcBhM8 = url.split(PlpyFa9QMKXxOD1cvHzmI(u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬṗ"),BkM54Kr7Qbqn)
		LLl9rOnRTypKFcBhM8 = LLl9rOnRTypKFcBhM8+C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬࡥ࡟ࠨṘ")+O3OVuapf0YFjbm5oUQDg(u"࠭࡟ࡠࠩṙ")+LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠧࡠࡡࠪṚ")+N6NGJ4vpmidqMCh7yo(u"ࠨࡡࡢࠫṛ")+uulNDCPyef78(u"ࠩࡢࡣࠬṜ")
		z36flodJVD9jWxip14Rh,ZJqDh4ByGPQn13tlzMOTLCNdcugx,BIbU1q2NrFX,OOnVxtP0TNWsci6HrEGqBm9boKF7g,V6gGYKEO8UqQZ,buOAHlCgTQfIWP3t7qRw8pms6Z0xYj, = LLl9rOnRTypKFcBhM8.split(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠪࡣࡤ࠭ṝ"))[:sIzDXlTHYUC5L3xZGnr(u"࠸ര")]
	if not OOnVxtP0TNWsci6HrEGqBm9boKF7g: OOnVxtP0TNWsci6HrEGqBm9boKF7g = Hr25gta6XcqO(u"ࠫ࠵࠭Ṟ")
	else: OOnVxtP0TNWsci6HrEGqBm9boKF7g = OOnVxtP0TNWsci6HrEGqBm9boKF7g.replace(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠬࡶࠧṟ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(ksJdoFWhxTz8Y2N7bOZE,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg.strip(CsDcLqQUVK4YBvHFW1(u"࠭࠿ࠨṠ")).strip(AAbvaXV2DQzfNHdm4U3tT(u"ࠧ࠰ࠩṡ")).strip(PlpyFa9QMKXxOD1cvHzmI(u"ࠨࠨࠪṢ"))
	A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(YLKFRH6sSIrznXBg,CsDcLqQUVK4YBvHFW1(u"ࠩ࡫ࡳࡸࡺࠧṣ"))
	if z36flodJVD9jWxip14Rh: bbBWiXefkN7VOpUhLQPGwIZF40s = z36flodJVD9jWxip14Rh
	else: bbBWiXefkN7VOpUhLQPGwIZF40s = A8ECQ0qwTRzPifOGW76FK35uUvhe
	bbBWiXefkN7VOpUhLQPGwIZF40s = VbHeOuU1ilzSp2ZRXwBD(bbBWiXefkN7VOpUhLQPGwIZF40s,oRJAfwD957WkUyBM1Ehu8m(u"ࠪࡲࡦࡳࡥࠨṤ"))
	z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(Gcw2nelTR864XCVruO3mAFqI5a(u"๊ࠫฮวีำࠪṥ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(sJw9QWiq1Kr0xfeVRI(u"ู๊ࠬาใิࠫṦ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(wdftVMyzF17cYETHu(u"࠭วๅࠢࠪṧ"),ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE)
	LLl9rOnRTypKFcBhM8 = LLl9rOnRTypKFcBhM8.replace(KfHAW8VGbrxi(u"ࠧๆสสุึ࠭Ṩ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(uulNDCPyef78(u"ࠨีํีๆืࠧṩ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(CsDcLqQUVK4YBvHFW1(u"ࠩส่ࠥ࠭Ṫ"),ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE)
	bbBWiXefkN7VOpUhLQPGwIZF40s = bbBWiXefkN7VOpUhLQPGwIZF40s.replace(sIzDXlTHYUC5L3xZGnr(u"้ࠪออิาࠩṫ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(wdftVMyzF17cYETHu(u"ุࠫ๐ัโำࠪṬ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(aOQTKXFL54Nl60Zhp3MbE(u"ࠬอไࠡࠩṭ"),ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE)
	return YLKFRH6sSIrznXBg,LLl9rOnRTypKFcBhM8,A8ECQ0qwTRzPifOGW76FK35uUvhe,bbBWiXefkN7VOpUhLQPGwIZF40s,z36flodJVD9jWxip14Rh,ZJqDh4ByGPQn13tlzMOTLCNdcugx,BIbU1q2NrFX,OOnVxtP0TNWsci6HrEGqBm9boKF7g,V6gGYKEO8UqQZ
def oIsZOqV4lLD(url,source):
	RD2JpTs84Bin9oecLO,z36flodJVD9jWxip14Rh,iH1XqR6GlYbe8Q0IzFUhadBk,nNOVcw6kyz83RDX12ZFJKQ,qLTHPyOepEh5FbwnGN6D,UfieKkPzcrWpIsh4vH9F,rn9K8xcCvubz2adq3S = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,zA8Ry1KDvmr3w4B5xeP,zA8Ry1KDvmr3w4B5xeP,zA8Ry1KDvmr3w4B5xeP,zA8Ry1KDvmr3w4B5xeP,zA8Ry1KDvmr3w4B5xeP
	YLKFRH6sSIrznXBg,LLl9rOnRTypKFcBhM8,A8ECQ0qwTRzPifOGW76FK35uUvhe,bbBWiXefkN7VOpUhLQPGwIZF40s,z36flodJVD9jWxip14Rh,ZJqDh4ByGPQn13tlzMOTLCNdcugx,BIbU1q2NrFX,OOnVxtP0TNWsci6HrEGqBm9boKF7g,V6gGYKEO8UqQZ = T2IyJpEoPQKNw8(url,source)
	if N6NGJ4vpmidqMCh7yo(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧṮ") in url:
		if   ZJqDh4ByGPQn13tlzMOTLCNdcugx==wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧࡦ࡯ࡥࡩࡩ࠭ṯ"): ZJqDh4ByGPQn13tlzMOTLCNdcugx = ksJdoFWhxTz8Y2N7bOZE+C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨ็ไฺ้࠭Ṱ")
		elif ZJqDh4ByGPQn13tlzMOTLCNdcugx==vU6DxuzPwMpg(u"ࠩࡺࡥࡹࡩࡨࠨṱ"): ZJqDh4ByGPQn13tlzMOTLCNdcugx = ksJdoFWhxTz8Y2N7bOZE+O3OVuapf0YFjbm5oUQDg(u"ฺ๊ࠪࠩว่ัฬࠫṲ")
		elif ZJqDh4ByGPQn13tlzMOTLCNdcugx==FgXzMs0YSDt(u"ࠫࡧࡵࡴࡩࠩṳ"): ZJqDh4ByGPQn13tlzMOTLCNdcugx = ksJdoFWhxTz8Y2N7bOZE+O3OVuapf0YFjbm5oUQDg(u"ࠬࠫࠥๆึส๋ิฯ้ࠠฬะ้๏๊ࠧṴ")
		elif ZJqDh4ByGPQn13tlzMOTLCNdcugx==EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨṵ"): ZJqDh4ByGPQn13tlzMOTLCNdcugx = ksJdoFWhxTz8Y2N7bOZE+CsDcLqQUVK4YBvHFW1(u"ࠧࠦࠧࠨฮา๋๊ๅࠩṶ")
		elif ZJqDh4ByGPQn13tlzMOTLCNdcugx==fy8iFgEkrO12NR9TWBI35sjY6qHvV: ZJqDh4ByGPQn13tlzMOTLCNdcugx = ksJdoFWhxTz8Y2N7bOZE+PlpyFa9QMKXxOD1cvHzmI(u"ࠨࠧࠨࠩࠪ࠭ṷ")
		if BIbU1q2NrFX!=fy8iFgEkrO12NR9TWBI35sjY6qHvV:
			if OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠩࡰࡴ࠹࠭Ṹ") not in BIbU1q2NrFX: BIbU1q2NrFX = C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠪࠩࠬṹ")+BIbU1q2NrFX
			BIbU1q2NrFX = ksJdoFWhxTz8Y2N7bOZE+BIbU1q2NrFX
		if OOnVxtP0TNWsci6HrEGqBm9boKF7g!=fy8iFgEkrO12NR9TWBI35sjY6qHvV:
			OOnVxtP0TNWsci6HrEGqBm9boKF7g = o1INZ3ViQqS0Uw5z6kMjbv(u"ࠫࠪࠫࠥࠦࠧࠨࠩࠪࠫࠧṺ")+OOnVxtP0TNWsci6HrEGqBm9boKF7g
			OOnVxtP0TNWsci6HrEGqBm9boKF7g = ksJdoFWhxTz8Y2N7bOZE+OOnVxtP0TNWsci6HrEGqBm9boKF7g[-EE1jeHnIoad(u"࠼റ"):]
	if   aOQTKXFL54Nl60Zhp3MbE(u"ࠬࡇࡋࡐࡃࡐࠫṻ")		in source: UfieKkPzcrWpIsh4vH9F	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭ࡁࡌ࡙ࡄࡑࠬṼ")		in source: iH1XqR6GlYbe8Q0IzFUhadBk	= I18uSKaWhgTBeYUPD4sr(u"ࠧࡢ࡭ࡺࡥࡲ࠭ṽ")
	elif FmYoGejTnwKME7d9zPc(u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧࠪṾ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: iH1XqR6GlYbe8Q0IzFUhadBk	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif O3OVuapf0YFjbm5oUQDg(u"ࠩࡳ࡬ࡴࡺ࡯ࡴ࠰ࡤࡴࡵ࠴ࡧࠨṿ")	in A8ECQ0qwTRzPifOGW76FK35uUvhe: iH1XqR6GlYbe8Q0IzFUhadBk	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif PlpyFa9QMKXxOD1cvHzmI(u"ࠪࡥࡷࡧࡢࡴࡧࡨࡨࠬẀ")		in source: iH1XqR6GlYbe8Q0IzFUhadBk	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif sIzDXlTHYUC5L3xZGnr(u"ࠫࡦࡲࡡࡳࡣࡥࠫẁ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: iH1XqR6GlYbe8Q0IzFUhadBk	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif FmYoGejTnwKME7d9zPc(u"ࠬ࡬ࡡࡴࡧ࡯ࠫẂ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: iH1XqR6GlYbe8Q0IzFUhadBk	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif jL5CrsRwebpyDVXUc1EQP(u"࠭ࡴ࠸࡯ࡨࡩࡱ࠭ẃ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: iH1XqR6GlYbe8Q0IzFUhadBk	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif uulNDCPyef78(u"ࠧ࡮ࡱࡹࡷ࠹ࡻࠧẄ")		in z36flodJVD9jWxip14Rh:   iH1XqR6GlYbe8Q0IzFUhadBk	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif AAbvaXV2DQzfNHdm4U3tT(u"ࠨ࡯ࡼࡩ࡬ࡿࡶࡪࡲࠪẅ")		in z36flodJVD9jWxip14Rh:   iH1XqR6GlYbe8Q0IzFUhadBk	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif FgXzMs0YSDt(u"ࠩࡩࡥ࡯࡫ࡲࠨẆ")		in z36flodJVD9jWxip14Rh:   iH1XqR6GlYbe8Q0IzFUhadBk	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif FgXzMs0YSDt(u"ࠪๅัืࠧẇ")			in z36flodJVD9jWxip14Rh:   iH1XqR6GlYbe8Q0IzFUhadBk	= I18uSKaWhgTBeYUPD4sr(u"ࠫ࡫ࡧࡪࡦࡴࠪẈ")
	elif CsDcLqQUVK4YBvHFW1(u"ࠬ็ไิูํ๊ࠬẉ")		in z36flodJVD9jWxip14Rh:   iH1XqR6GlYbe8Q0IzFUhadBk	= wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭ࡰࡢ࡮ࡨࡷࡹ࡯࡮ࡦࠩẊ")
	elif wdftVMyzF17cYETHu(u"ࠧࡨࡦࡵ࡭ࡻ࡫ࠧẋ")		in YLKFRH6sSIrznXBg:   iH1XqR6GlYbe8Q0IzFUhadBk	= CsDcLqQUVK4YBvHFW1(u"ࠨࡩࡲࡳ࡬ࡲࡥࠨẌ")
	elif FgXzMs0YSDt(u"ࠩࡰࡽࡨ࡯࡭ࡢࠩẍ")		in z36flodJVD9jWxip14Rh:   iH1XqR6GlYbe8Q0IzFUhadBk	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif oRJAfwD957WkUyBM1Ehu8m(u"ࠪࡻࡪࡩࡩ࡮ࡣࠪẎ")		in z36flodJVD9jWxip14Rh:   iH1XqR6GlYbe8Q0IzFUhadBk	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif O3OVuapf0YFjbm5oUQDg(u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬẏ")		in z36flodJVD9jWxip14Rh:   iH1XqR6GlYbe8Q0IzFUhadBk	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠬࡴࡥࡸࡥ࡬ࡱࡦ࠭Ẑ")		in z36flodJVD9jWxip14Rh:   iH1XqR6GlYbe8Q0IzFUhadBk	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif oRJAfwD957WkUyBM1Ehu8m(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫẑ")	in A8ECQ0qwTRzPifOGW76FK35uUvhe: iH1XqR6GlYbe8Q0IzFUhadBk	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif vU6DxuzPwMpg(u"ࠧࡣࡱ࡮ࡶࡦ࠭Ẓ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: iH1XqR6GlYbe8Q0IzFUhadBk	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif FgXzMs0YSDt(u"ࠨࡶࡹࡪࡺࡴࠧẓ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: iH1XqR6GlYbe8Q0IzFUhadBk	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠩࡷࡺࡰࡹࡡࠨẔ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: iH1XqR6GlYbe8Q0IzFUhadBk	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif AAbvaXV2DQzfNHdm4U3tT(u"ࠪࡥࡳࡧࡶࡪࡦࡽࠫẕ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: iH1XqR6GlYbe8Q0IzFUhadBk	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif jL5CrsRwebpyDVXUc1EQP(u"ࠫࡸ࡮࡯ࡰࡨࡳࡶࡴ࠭ẖ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: iH1XqR6GlYbe8Q0IzFUhadBk	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif uulNDCPyef78(u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧẗ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: UfieKkPzcrWpIsh4vH9F	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif o1INZ3ViQqS0Uw5z6kMjbv(u"࠭ࡳࡩࡣ࡫ࡩࡩ࠺ࡵࠨẘ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: UfieKkPzcrWpIsh4vH9F	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif ggjO5CrKVRPITaesWkxD(u"ࠧࡤ࡫ࡰࡥ࠹ࡻࠧẙ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: UfieKkPzcrWpIsh4vH9F	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif ssynAg0zhSkoCpOMDV9(u"ࠨࡧࡪࡽࡳࡵࡷࠨẚ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: UfieKkPzcrWpIsh4vH9F	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif SnhLjmfeJC(u"ࠩ࡫ࡥࡱࡧࡣࡪ࡯ࡤࠫẛ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: UfieKkPzcrWpIsh4vH9F	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪࡧ࡮ࡳࡡࡢࡤࡧࡳࠬẜ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: UfieKkPzcrWpIsh4vH9F	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠫࡷ࡫ࡤ࡮ࡱࡧࡼࠬẝ")	 	in A8ECQ0qwTRzPifOGW76FK35uUvhe: iH1XqR6GlYbe8Q0IzFUhadBk	= EE1jeHnIoad(u"ࠬࡸࡥࡥ࡯ࡲࡨࡽ࠭ẞ")
	elif N6NGJ4vpmidqMCh7yo(u"࠭ࡹࡰࡷࡷࡹࠬẟ")	 	in A8ECQ0qwTRzPifOGW76FK35uUvhe: iH1XqR6GlYbe8Q0IzFUhadBk	= Hr25gta6XcqO(u"ࠧࡺࡱࡸࡸࡺࡨࡥࠨẠ")
	elif s5WMHyQN4mpie(u"ࠨࡻ࠵ࡹ࠳ࡨࡥࠨạ")	 	in A8ECQ0qwTRzPifOGW76FK35uUvhe: iH1XqR6GlYbe8Q0IzFUhadBk	= oRJAfwD957WkUyBM1Ehu8m(u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪẢ")
	elif FmYoGejTnwKME7d9zPc(u"ࠪࡩ࡬ࡿ࠭ࡣࡧࡶࡸ࠳ࡴࡥࡵࠩả")	in A8ECQ0qwTRzPifOGW76FK35uUvhe: iH1XqR6GlYbe8Q0IzFUhadBk	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif sJw9QWiq1Kr0xfeVRI(u"ࠫࡩ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡥࠩẤ")	in A8ECQ0qwTRzPifOGW76FK35uUvhe: iH1XqR6GlYbe8Q0IzFUhadBk	= C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹࡼࡩࡱࠩấ")
	elif SnhLjmfeJC(u"࠭ࡥࡨࡻ࠱ࡦࡪࡹࡴࠨẦ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: iH1XqR6GlYbe8Q0IzFUhadBk	= oRJAfwD957WkUyBM1Ehu8m(u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠲ࠩầ")
	elif KfHAW8VGbrxi(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩẨ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: iH1XqR6GlYbe8Q0IzFUhadBk	= ssynAg0zhSkoCpOMDV9(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠶ࠫẩ")
	elif wdftVMyzF17cYETHu(u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥࠬẪ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: iH1XqR6GlYbe8Q0IzFUhadBk	= EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠭ẫ")
	elif FgXzMs0YSDt(u"ࠬ࡬ࡡࡤࡷ࡯ࡸࡾࡨ࡯ࡰ࡭ࡶࠫẬ")	in A8ECQ0qwTRzPifOGW76FK35uUvhe: iH1XqR6GlYbe8Q0IzFUhadBk	= LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠭ࡦࡢࡥࡸࡰࡹࡿࡢࡰࡱ࡮ࡷࠬậ")
	elif sIzDXlTHYUC5L3xZGnr(u"ࠧࡪࡰࡩࡰࡦࡳ࠮ࡤࡥࠪẮ")	in A8ECQ0qwTRzPifOGW76FK35uUvhe: iH1XqR6GlYbe8Q0IzFUhadBk	= AAbvaXV2DQzfNHdm4U3tT(u"ࠨ࡫ࡱࡪࡱࡧ࡭ࠨắ")
	elif FmYoGejTnwKME7d9zPc(u"ࠩࡥࡹࡿࢀࡶࡳ࡮ࠪẰ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: iH1XqR6GlYbe8Q0IzFUhadBk	= Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠪࡦࡺࢀࡺࡷࡴ࡯ࠫằ")
	elif ssynAg0zhSkoCpOMDV9(u"ࠫࡦࡸࡡࡣ࡮ࡲࡥࡩࡹࠧẲ")	in A8ECQ0qwTRzPifOGW76FK35uUvhe: nNOVcw6kyz83RDX12ZFJKQ	= KfHAW8VGbrxi(u"ࠬࡧࡲࡢࡤ࡯ࡳࡦࡪࡳࠨẳ")
	elif s5WMHyQN4mpie(u"࠭ࡡࡳࡥ࡫࡭ࡻ࡫ࠧẴ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: nNOVcw6kyz83RDX12ZFJKQ	= LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠧࡢࡴࡦ࡬࡮ࡼࡥࠨẵ")
	elif KfHAW8VGbrxi(u"ࠨࡥࡤࡸࡨ࡮࠮ࡪࡵࠪẶ")	 	in A8ECQ0qwTRzPifOGW76FK35uUvhe: nNOVcw6kyz83RDX12ZFJKQ	= FmYoGejTnwKME7d9zPc(u"ࠩࡦࡥࡹࡩࡨࠨặ")
	elif wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠪࡪ࡮ࡲࡥࡳ࡫ࡲࠫẸ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: nNOVcw6kyz83RDX12ZFJKQ	= KfHAW8VGbrxi(u"ࠫ࡫࡯࡬ࡦࡴ࡬ࡳࠬẹ")
	elif oRJAfwD957WkUyBM1Ehu8m(u"ࠬࡼࡩࡥࡤࡰࠫẺ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: nNOVcw6kyz83RDX12ZFJKQ	= AAbvaXV2DQzfNHdm4U3tT(u"࠭ࡶࡪࡦࡥࡱࠬẻ")
	elif uulNDCPyef78(u"ࠧࡷ࡫ࡧ࡬ࡩ࠭Ẽ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: UfieKkPzcrWpIsh4vH9F	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif O3OVuapf0YFjbm5oUQDg(u"ࠨ࡯ࡼࡺ࡮ࡪࠧẽ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: UfieKkPzcrWpIsh4vH9F	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif ggjO5CrKVRPITaesWkxD(u"ࠩࡰࡽࡻ࡯ࡩࡥࠩẾ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: UfieKkPzcrWpIsh4vH9F	= bbBWiXefkN7VOpUhLQPGwIZF40s
	elif oRJAfwD957WkUyBM1Ehu8m(u"ࠪࡺ࡮ࡪࡥࡰࡤ࡬ࡲࠬế")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: nNOVcw6kyz83RDX12ZFJKQ	= N6NGJ4vpmidqMCh7yo(u"ࠫࡻ࡯ࡤࡦࡱࡥ࡭ࡳ࠭Ề")
	elif EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬ࡭࡯ࡷ࡫ࡧࠫề")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: nNOVcw6kyz83RDX12ZFJKQ	= N6NGJ4vpmidqMCh7yo(u"࠭ࡧࡰࡸ࡬ࡨࠬỂ")
	elif V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠧ࡭࡫࡬ࡺ࡮ࡪࡥࡰࠩể") 	in A8ECQ0qwTRzPifOGW76FK35uUvhe: nNOVcw6kyz83RDX12ZFJKQ	= OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠨ࡮࡬࡭ࡻ࡯ࡤࡦࡱࠪỄ")
	elif ggjO5CrKVRPITaesWkxD(u"ࠩࡰࡴ࠹ࡻࡰ࡭ࡱࡤࡨࠬễ")	in A8ECQ0qwTRzPifOGW76FK35uUvhe: nNOVcw6kyz83RDX12ZFJKQ	= s5WMHyQN4mpie(u"ࠪࡱࡵ࠺ࡵࡱ࡮ࡲࡥࡩ࠭Ệ")
	elif sJw9QWiq1Kr0xfeVRI(u"ࠫࡵࡻࡢ࡭࡫ࡦࡺ࡮ࡪࡥࡰࠩệ")	in A8ECQ0qwTRzPifOGW76FK35uUvhe: nNOVcw6kyz83RDX12ZFJKQ	= PlpyFa9QMKXxOD1cvHzmI(u"ࠬࡶࡵࡣ࡮࡬ࡧࡻ࡯ࡤࡦࡱࠪỈ")
	elif I18uSKaWhgTBeYUPD4sr(u"࠭ࡲࡢࡲ࡬ࡨࡻ࡯ࡤࡦࡱࠪỉ") 	in A8ECQ0qwTRzPifOGW76FK35uUvhe: nNOVcw6kyz83RDX12ZFJKQ	= o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧࡳࡣࡳ࡭ࡩࡼࡩࡥࡧࡲࠫỊ")
	elif jL5CrsRwebpyDVXUc1EQP(u"ࠨࡶࡲࡴ࠹ࡺ࡯ࡱࠩị")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: nNOVcw6kyz83RDX12ZFJKQ	= KfHAW8VGbrxi(u"ࠩࡷࡳࡵ࠺ࡴࡰࡲࠪỌ")
	elif N6NGJ4vpmidqMCh7yo(u"ࠪࡹࡵࡶࠧọ") 			in A8ECQ0qwTRzPifOGW76FK35uUvhe: nNOVcw6kyz83RDX12ZFJKQ	= uulNDCPyef78(u"ࠫࡺࡶࡢࡰ࡯ࠪỎ")
	elif oRJAfwD957WkUyBM1Ehu8m(u"ࠬࡻࡰࡣࠩỏ") 			in A8ECQ0qwTRzPifOGW76FK35uUvhe: nNOVcw6kyz83RDX12ZFJKQ	= s5WMHyQN4mpie(u"࠭ࡵࡱࡤࡲࡱࠬỐ")
	elif EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧࡶࡳ࡯ࡳࡦࡪࠧố") 		in A8ECQ0qwTRzPifOGW76FK35uUvhe: nNOVcw6kyz83RDX12ZFJKQ	= s5WMHyQN4mpie(u"ࠨࡷࡴࡰࡴࡧࡤࠨỒ")
	elif s5WMHyQN4mpie(u"ࠩࡹ࡯ࠬồ") 			in A8ECQ0qwTRzPifOGW76FK35uUvhe: nNOVcw6kyz83RDX12ZFJKQ	= wdftVMyzF17cYETHu(u"ࠪࡺࡰ࠭Ổ")
	elif ggjO5CrKVRPITaesWkxD(u"ࠫࡻࡩࡳࡵࡴࡨࡥࡲ࠭ổ") 	in A8ECQ0qwTRzPifOGW76FK35uUvhe: nNOVcw6kyz83RDX12ZFJKQ	= SnhLjmfeJC(u"ࠬࡼࡣࡴࡶࡵࡩࡦࡳࠧỖ")
	elif wdftVMyzF17cYETHu(u"࠭ࡶࡪࡦࡥࡳࡧ࠭ỗ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: nNOVcw6kyz83RDX12ZFJKQ	= OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠧࡷ࡫ࡧࡦࡴࡨࠧỘ")
	elif sIzDXlTHYUC5L3xZGnr(u"ࠨࡸ࡬ࡨࡴࢀࡡࠨộ") 		in A8ECQ0qwTRzPifOGW76FK35uUvhe: nNOVcw6kyz83RDX12ZFJKQ	= Gcw2nelTR864XCVruO3mAFqI5a(u"ࠩࡹ࡭ࡩࡵࡺࡢࠩỚ")
	elif Hr25gta6XcqO(u"ࠪࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵࠧớ") 	in A8ECQ0qwTRzPifOGW76FK35uUvhe: nNOVcw6kyz83RDX12ZFJKQ	= OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠫࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯ࠨỜ")
	elif Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠬࡽࡩ࡯ࡶࡹ࠲ࡱ࡯ࡶࡦࠩờ")	in A8ECQ0qwTRzPifOGW76FK35uUvhe: nNOVcw6kyz83RDX12ZFJKQ	= oRJAfwD957WkUyBM1Ehu8m(u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧࠪỞ")
	elif o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧࡻ࡫ࡳࡴࡾࡹࡨࡢࡴࡨࠫở")	in A8ECQ0qwTRzPifOGW76FK35uUvhe: nNOVcw6kyz83RDX12ZFJKQ	= o1INZ3ViQqS0Uw5z6kMjbv(u"ࠨࡼ࡬ࡴࡵࡿࡳࡩࡣࡵࡩࠬỠ")
	elif oRJAfwD957WkUyBM1Ehu8m(u"ࠩ࡫ࡨ࠲ࡩࡤ࡯ࠩỡ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: nNOVcw6kyz83RDX12ZFJKQ	= sJw9QWiq1Kr0xfeVRI(u"ࠪ࡬ࡩ࠳ࡣࡥࡰࠪỢ")
	if   iH1XqR6GlYbe8Q0IzFUhadBk:	RD2JpTs84Bin9oecLO,z36flodJVD9jWxip14Rh = C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠫำอีࠨợ"),iH1XqR6GlYbe8Q0IzFUhadBk
	elif UfieKkPzcrWpIsh4vH9F:		RD2JpTs84Bin9oecLO,z36flodJVD9jWxip14Rh = sJw9QWiq1Kr0xfeVRI(u"ࠬࠫๅฮัาࠫỤ"),UfieKkPzcrWpIsh4vH9F
	elif nNOVcw6kyz83RDX12ZFJKQ:		RD2JpTs84Bin9oecLO,z36flodJVD9jWxip14Rh = ssynAg0zhSkoCpOMDV9(u"࠭ࠥࠦ฻สู้๋ࠥา๊ไࠫụ"),nNOVcw6kyz83RDX12ZFJKQ
	elif qLTHPyOepEh5FbwnGN6D:	RD2JpTs84Bin9oecLO,z36flodJVD9jWxip14Rh = EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧࠦࠧࠨ฽ฬ๋ࠠฯษิะ๏࠭Ủ"),qLTHPyOepEh5FbwnGN6D
	elif rn9K8xcCvubz2adq3S:	RD2JpTs84Bin9oecLO,z36flodJVD9jWxip14Rh = jL5CrsRwebpyDVXUc1EQP(u"ࠨࠧࠨࠩࠪ฿วๆࠢัหึา๊ࠨủ"),bbBWiXefkN7VOpUhLQPGwIZF40s
	else:			RD2JpTs84Bin9oecLO,z36flodJVD9jWxip14Rh = Hr25gta6XcqO(u"ࠩࠨฺࠩࠪࠫࠥษ่ࠤ๊า็้ๆࠪỨ"),bbBWiXefkN7VOpUhLQPGwIZF40s
	return RD2JpTs84Bin9oecLO,z36flodJVD9jWxip14Rh,ZJqDh4ByGPQn13tlzMOTLCNdcugx,BIbU1q2NrFX,OOnVxtP0TNWsci6HrEGqBm9boKF7g
def V7Vj0iHFrU(OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8):
	p7Gkego0m6a8,zzECVswWcGAIXhrQlZ7jMokugnv = [],[]
	for title,bigdh7fpZYl4aT2keV in list(zip(WFlpmsYGKNy,XoSyx7p6dqZ1CF8)):
		if ml1bXR85BJyhPAVvQY(bigdh7fpZYl4aT2keV):
			p7Gkego0m6a8.append(title)
			zzECVswWcGAIXhrQlZ7jMokugnv.append(bigdh7fpZYl4aT2keV)
	if not zzECVswWcGAIXhrQlZ7jMokugnv and not OK2mcs7f1ekzACupF: OK2mcs7f1ekzACupF = EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪࡊࡦ࡯࡬ࡦࡦࠪứ")
	return OK2mcs7f1ekzACupF,p7Gkego0m6a8,zzECVswWcGAIXhrQlZ7jMokugnv
def NL1KAXyY3Dw2(url,source):
	YLKFRH6sSIrznXBg,UfieKkPzcrWpIsh4vH9F,A8ECQ0qwTRzPifOGW76FK35uUvhe,bbBWiXefkN7VOpUhLQPGwIZF40s,z36flodJVD9jWxip14Rh,ZJqDh4ByGPQn13tlzMOTLCNdcugx,BIbU1q2NrFX,OOnVxtP0TNWsci6HrEGqBm9boKF7g,V6gGYKEO8UqQZ = T2IyJpEoPQKNw8(url,source)
	if   aOQTKXFL54Nl60Zhp3MbE(u"ࠫࡾࡵࡵࡵࡷࠪỪ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = FmYoGejTnwKME7d9zPc(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨừ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[url]
	elif I18uSKaWhgTBeYUPD4sr(u"࠭ࡹ࠳ࡷ࠱ࡦࡪ࠭Ử")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪử"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[url]
	elif KfHAW8VGbrxi(u"ࠨࡳࡹ࡭ࡩ࠭Ữ")			in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = qlWwXt6pmFAOKIjMBrYgvc3dESeuiy(YLKFRH6sSIrznXBg)
	elif ggjO5CrKVRPITaesWkxD(u"ࠩࡩ࡭ࡱࡳࡥࡺࠩữ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = qlWwXt6pmFAOKIjMBrYgvc3dESeuiy(YLKFRH6sSIrznXBg)
	elif OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪࡅࡑࡓࡓࡕࡄࡄࠫỰ")		in source: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = qlWwXt6pmFAOKIjMBrYgvc3dESeuiy(YLKFRH6sSIrznXBg)
	elif ssynAg0zhSkoCpOMDV9(u"ࠫࡆࡑࡏࡂࡏࠪự")		in source: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = eSXLR24o65(YLKFRH6sSIrznXBg,z36flodJVD9jWxip14Rh)
	elif Gcw2nelTR864XCVruO3mAFqI5a(u"ࠬࡇࡋࡘࡃࡐࠫỲ")		in source: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = tt9rH5O0wE(YLKFRH6sSIrznXBg,ZJqDh4ByGPQn13tlzMOTLCNdcugx,OOnVxtP0TNWsci6HrEGqBm9boKF7g)
	elif sIzDXlTHYUC5L3xZGnr(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨỳ")		in source: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = VTjvHm9N02(YLKFRH6sSIrznXBg)
	elif aOQTKXFL54Nl60Zhp3MbE(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨỴ")		in source: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = ggjO5CrKVRPITaesWkxD(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫỵ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[url]
	elif PlpyFa9QMKXxOD1cvHzmI(u"ࠩࡆࡍࡒࡇ࠴ࡖࠩỶ")		in source: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = mmSelOD8xV(YLKFRH6sSIrznXBg)
	elif O3OVuapf0YFjbm5oUQDg(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬỷ")		in source: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = rzahyA67v3(YLKFRH6sSIrznXBg)
	elif aOQTKXFL54Nl60Zhp3MbE(u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭Ỹ")		in source: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = oTXYuAvz7q(YLKFRH6sSIrznXBg)
	elif QjAINyUC7MDRq5d8e4vl9(u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧỹ")		in source: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = YYIUphus1F(YLKFRH6sSIrznXBg)
	elif wdftVMyzF17cYETHu(u"࠭ࡓࡉࡑࡉࡌࡆ࠭Ỻ")		in source: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = FrSp3B1LEY(YLKFRH6sSIrznXBg)
	elif vU6DxuzPwMpg(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩỻ")		in source: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = TdGAwqzt94(YLKFRH6sSIrznXBg,V6gGYKEO8UqQZ)
	elif EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠨࡎࡄࡖࡔࡠࡁࠨỼ")		in source: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = PcJQBUOKfk(YLKFRH6sSIrznXBg)
	elif EE1jeHnIoad(u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭ỽ")	in source: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = oeDTz7nWbL(YLKFRH6sSIrznXBg)
	elif AAbvaXV2DQzfNHdm4U3tT(u"ࠪ࡯ࡦࡺ࡫ࡰࡷࡷࡩࠬỾ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = llQyzAJViv(YLKFRH6sSIrznXBg)
	elif CsDcLqQUVK4YBvHFW1(u"ࠫࡦࡱ࡯ࡢ࡯࠱ࡧࡦࡳࠧỿ")	in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = yyT9dmoRwD(YLKFRH6sSIrznXBg)
	elif N6NGJ4vpmidqMCh7yo(u"ࠬࡧ࡬ࡢࡴࡤࡦࠬἀ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = Y2R4hvV9acIbr8jP6l5(YLKFRH6sSIrznXBg)
	elif o1INZ3ViQqS0Uw5z6kMjbv(u"࠭ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨἁ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = drEPv43i0T(YLKFRH6sSIrznXBg)
	elif wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧࡴࡪࡤ࡬ࡪࡪ࠴ࡶࠩἂ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = drEPv43i0T(YLKFRH6sSIrznXBg)
	elif EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠨࡧࡪࡽࡳࡵࡷࠨἃ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = MMD01SrpIK(YLKFRH6sSIrznXBg)
	elif s5WMHyQN4mpie(u"ࠩࡷࡺ࡫ࡻ࡮ࠨἄ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = UUnxtcWRAf(YLKFRH6sSIrznXBg)
	elif V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪࡸࡻࡱࡳࡢࠩἅ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = UUnxtcWRAf(YLKFRH6sSIrznXBg)
	elif aOQTKXFL54Nl60Zhp3MbE(u"ࠫࡹࡼ࠭ࡧ࠰ࡦࡳࡲ࠭ἆ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = UUnxtcWRAf(YLKFRH6sSIrznXBg)
	elif OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠬ࡮ࡡ࡭ࡣࡦ࡭ࡲࡧࠧἇ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = MMarx62L4F(YLKFRH6sSIrznXBg)
	elif QjAINyUC7MDRq5d8e4vl9(u"࠭ࡳࡩࡱࡲࡪࡵࡸ࡯ࠨἈ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = eURCisO6mN(YLKFRH6sSIrznXBg)
	elif aOQTKXFL54Nl60Zhp3MbE(u"ࠧ࡮ࡻࡨ࡫ࡾࡼࡩࡱࠩἉ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = XXn8ZTeaC1Rt4c0uwQ9qHFOLo7jg(YLKFRH6sSIrznXBg)
	elif EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠨࡸࡶ࠸ࡺ࠭Ἂ")			in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = s8f9q7bOx1(YLKFRH6sSIrznXBg)
	elif FmYoGejTnwKME7d9zPc(u"ࠩࡩࡥ࡯࡫ࡲࠨἋ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = XgkoxRdncr(YLKFRH6sSIrznXBg)
	elif aOQTKXFL54Nl60Zhp3MbE(u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺࠫἌ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = SfjApdRFxq(YLKFRH6sSIrznXBg)
	elif LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠫࡳ࡫ࡷࡤ࡫ࡰࡥࠬἍ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = SfjApdRFxq(YLKFRH6sSIrznXBg)
	elif I18uSKaWhgTBeYUPD4sr(u"ࠬࡩࡩ࡮ࡣ࠰ࡰ࡮࡭ࡨࡵࠩἎ")	in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = N7YIE4aUZM(YLKFRH6sSIrznXBg)
	elif uulNDCPyef78(u"࠭ࡣࡪ࡯ࡤࡰ࡮࡭ࡨࡵࠩἏ")	in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = N7YIE4aUZM(YLKFRH6sSIrznXBg)
	elif vU6DxuzPwMpg(u"ࠧ࡮ࡻࡦ࡭ࡲࡧࠧἐ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = p1rgUFG2s4(YLKFRH6sSIrznXBg)
	elif KfHAW8VGbrxi(u"ࠨࡹࡨࡧ࡮ࡳࡡࠨἑ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = CAvwQ0mxPBbXqziK2t3SU(YLKFRH6sSIrznXBg)
	elif ssynAg0zhSkoCpOMDV9(u"ࠩࡥࡳࡰࡸࡡࠨἒ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = JoD7l3kPLf(YLKFRH6sSIrznXBg)
	elif C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨἓ")	in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = PcY8Ww2NmX(YLKFRH6sSIrznXBg)
	elif sJw9QWiq1Kr0xfeVRI(u"ࠫࡦࡸࡢ࡭࡫ࡲࡲࡿ࠭ἔ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = Q0QDmxKipe(YLKFRH6sSIrznXBg)
	elif OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠬ࡫ࡧࡺ࠯ࡥࡩࡸࡺ࠮࡯ࡧࡷࠫἕ")	in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = vahkltGD8L(YLKFRH6sSIrznXBg)
	elif Hr25gta6XcqO(u"࠭ࡤ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡧࠫ἖")	in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[YLKFRH6sSIrznXBg]
	elif wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧࡦࡩࡼࡦࡪࡹࡴࠨ἗")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = xEU5ZyWqcL(YLKFRH6sSIrznXBg)
	elif wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠨࡵࡨࡶ࡮࡫ࡳ࠵ࡹࡤࡸࡨ࡮ࠧἘ")	in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = CLOU4duzvl(YLKFRH6sSIrznXBg)
	elif oRJAfwD957WkUyBM1Ehu8m(u"ࠩࡸࡴࡧࡧ࡭ࠨἙ") 		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[YLKFRH6sSIrznXBg]
	else: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = N6NGJ4vpmidqMCh7yo(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭Ἒ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[YLKFRH6sSIrznXBg]
	if not OK2mcs7f1ekzACupF and not XoSyx7p6dqZ1CF8: OK2mcs7f1ekzACupF = KfHAW8VGbrxi(u"ࠫࡋࡧࡩ࡭ࡧࡧ࠾ࠥࠦࡕ࡯࡭ࡱࡳࡼࡴࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠴ࠤࡋࡧࡩ࡭ࡷࡵࡩࠬἛ")
	elif OK2mcs7f1ekzACupF not in [fy8iFgEkrO12NR9TWBI35sjY6qHvV,sIzDXlTHYUC5L3xZGnr(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪἜ"),CsDcLqQUVK4YBvHFW1(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩἝ")]: OK2mcs7f1ekzACupF = LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠧࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠢࠪ἞")+OK2mcs7f1ekzACupF
	return OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
def rrDyq9ReVmEMBxsdbCw(hPVlYCXsfnx5,url,source,gLoUCe7WqVp):
	global IPJ7yi4HSLna2UE,BS2ZMby0DqmcCdR,VY1bXQc8jKk,dk6SMCobOpfWnLu,LtN7PToYanhvc84I0DgdVp6mAzH
	ggWRvOkX8ioatcDTzuECl6JBKxSm30 = []
	for rn9K8xcCvubz2adq3S in [BS2ZMby0DqmcCdR,VY1bXQc8jKk,dk6SMCobOpfWnLu,LtN7PToYanhvc84I0DgdVp6mAzH]: rn9K8xcCvubz2adq3S[gLoUCe7WqVp] = Gcw2nelTR864XCVruO3mAFqI5a(u"ࠨࡖ࡬ࡱࡪࡵࡵࡵࠩ἟"),[],[]
	l6JmUpLKY9gFx8z70qGWcw2yRarsbD,NQurLXWvTZ = [a0nAtdSbXiKBFNQvHrsTkohx8m3,lBuLAQqsMndC,LEP6MUK8rgXYQ5dtDnb0s1,mCu0yTwD9ROtfsV1EjHrLSB],[]
	if Gcw2nelTR864XCVruO3mAFqI5a(u"ࠩࡩࡶࡩࡲࠧἠ") in url: l6JmUpLKY9gFx8z70qGWcw2yRarsbD,NQurLXWvTZ = [a0nAtdSbXiKBFNQvHrsTkohx8m3,lBuLAQqsMndC,mCu0yTwD9ROtfsV1EjHrLSB],[dk6SMCobOpfWnLu]
	if ssynAg0zhSkoCpOMDV9(u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫἡ") in url: l6JmUpLKY9gFx8z70qGWcw2yRarsbD,NQurLXWvTZ = [a0nAtdSbXiKBFNQvHrsTkohx8m3],[VY1bXQc8jKk,dk6SMCobOpfWnLu,LtN7PToYanhvc84I0DgdVp6mAzH]
	for rn9K8xcCvubz2adq3S in NQurLXWvTZ: rn9K8xcCvubz2adq3S[gLoUCe7WqVp] = sJw9QWiq1Kr0xfeVRI(u"ࠫࡘࡱࡩࡱࡲࡨࡨࠬἢ"),[],[]
	for rn9K8xcCvubz2adq3S in l6JmUpLKY9gFx8z70qGWcw2yRarsbD:
		DCtLufIM368KipQ705md9 = YMsWIfu7ojp2t4XJyZN05aC3l(daemon=EsCplGc5N4mBuYW0RVQt6b,target=rn9K8xcCvubz2adq3S,args=(url,source,gLoUCe7WqVp))
		ggWRvOkX8ioatcDTzuECl6JBKxSm30.append(DCtLufIM368KipQ705md9)
	def hYZELIFqQCJeRHxtlU5aWgD14v6s():
		ggx6UomqSEK7cLiAXh1eDzZIWOYN,pFlYLdoxAhei04vPm2ICRcS986,JHR9jZBI8AsULck4w2t,KKCw14hu8Wn9pa = LhFAGlQ19zr,LhFAGlQ19zr,LhFAGlQ19zr,LhFAGlQ19zr
		kM6cnpoDPsIjLQEw53RaVGZ7eb0WO2,title,bigdh7fpZYl4aT2keV = BS2ZMby0DqmcCdR[gLoUCe7WqVp]
		if (bigdh7fpZYl4aT2keV and not kM6cnpoDPsIjLQEw53RaVGZ7eb0WO2) or (kM6cnpoDPsIjLQEw53RaVGZ7eb0WO2 and kM6cnpoDPsIjLQEw53RaVGZ7eb0WO2!=N6NGJ4vpmidqMCh7yo(u"࡚ࠬࡩ࡮ࡧࡲࡹࡹ࠭ἣ")): ggx6UomqSEK7cLiAXh1eDzZIWOYN = EsCplGc5N4mBuYW0RVQt6b
		kM6cnpoDPsIjLQEw53RaVGZ7eb0WO2,title,bigdh7fpZYl4aT2keV = VY1bXQc8jKk[gLoUCe7WqVp]
		if (bigdh7fpZYl4aT2keV and not kM6cnpoDPsIjLQEw53RaVGZ7eb0WO2) or (kM6cnpoDPsIjLQEw53RaVGZ7eb0WO2 and kM6cnpoDPsIjLQEw53RaVGZ7eb0WO2!=ssynAg0zhSkoCpOMDV9(u"࠭ࡔࡪ࡯ࡨࡳࡺࡺࠧἤ")): pFlYLdoxAhei04vPm2ICRcS986 = EsCplGc5N4mBuYW0RVQt6b
		kM6cnpoDPsIjLQEw53RaVGZ7eb0WO2,title,bigdh7fpZYl4aT2keV = dk6SMCobOpfWnLu[gLoUCe7WqVp]
		if (bigdh7fpZYl4aT2keV and not kM6cnpoDPsIjLQEw53RaVGZ7eb0WO2) or (kM6cnpoDPsIjLQEw53RaVGZ7eb0WO2 and kM6cnpoDPsIjLQEw53RaVGZ7eb0WO2!=vU6DxuzPwMpg(u"ࠧࡕ࡫ࡰࡩࡴࡻࡴࠨἥ")): JHR9jZBI8AsULck4w2t = EsCplGc5N4mBuYW0RVQt6b
		kM6cnpoDPsIjLQEw53RaVGZ7eb0WO2,title,bigdh7fpZYl4aT2keV = LtN7PToYanhvc84I0DgdVp6mAzH[gLoUCe7WqVp]
		if (bigdh7fpZYl4aT2keV and not kM6cnpoDPsIjLQEw53RaVGZ7eb0WO2) or (kM6cnpoDPsIjLQEw53RaVGZ7eb0WO2 and kM6cnpoDPsIjLQEw53RaVGZ7eb0WO2!=O3OVuapf0YFjbm5oUQDg(u"ࠨࡖ࡬ࡱࡪࡵࡵࡵࠩἦ")): KKCw14hu8Wn9pa = EsCplGc5N4mBuYW0RVQt6b
		B86BtJkdcozNuC4 = all([ggx6UomqSEK7cLiAXh1eDzZIWOYN,pFlYLdoxAhei04vPm2ICRcS986,JHR9jZBI8AsULck4w2t,KKCw14hu8Wn9pa])
		cpwFIvHO0Db7hKTylq6S4nJj = bEWpDHXjCBqd7aOiN6UG5k.Player().isPlaying() if I4t9qonjrm.resolveonly else EsCplGc5N4mBuYW0RVQt6b
		return B86BtJkdcozNuC4 or not cpwFIvHO0Db7hKTylq6S4nJj
	kkfj6pyAalMWxoJKmnhFYutVrI9PZd(ggWRvOkX8ioatcDTzuECl6JBKxSm30,bznkhxWOTcZLaF2U6A4iKd30NI,N6NGJ4vpmidqMCh7yo(u"࠴࠳࠷ല"),teaC5j4HuGDqpwcmUzJ,hYZELIFqQCJeRHxtlU5aWgD14v6s)
	succeeded = AAbvaXV2DQzfNHdm4U3tT(u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠲ࠨἧ")
	OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = BS2ZMby0DqmcCdR[gLoUCe7WqVp]
	XoSyx7p6dqZ1CF8 = cymM76PR0aiVnX5gZ(XoSyx7p6dqZ1CF8)
	IPJ7yi4HSLna2UE[gLoUCe7WqVp] = hPVlYCXsfnx5,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
	if OK2mcs7f1ekzACupF==ssynAg0zhSkoCpOMDV9(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨἨ") or XoSyx7p6dqZ1CF8: return succeeded,OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
	hPVlYCXsfnx5 += ssynAg0zhSkoCpOMDV9(u"ࠫࡡࡴࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠴࠽ࠤࠥ࠭Ἡ")+OK2mcs7f1ekzACupF.replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(FFkml6ZbgXD,fy8iFgEkrO12NR9TWBI35sjY6qHvV)[:SnhLjmfeJC(u"࠽࠶ള")]
	succeeded = KfHAW8VGbrxi(u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠶ࠫἪ")
	OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = VY1bXQc8jKk[gLoUCe7WqVp]
	XoSyx7p6dqZ1CF8 = cymM76PR0aiVnX5gZ(XoSyx7p6dqZ1CF8)
	IPJ7yi4HSLna2UE[gLoUCe7WqVp] = hPVlYCXsfnx5,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
	if OK2mcs7f1ekzACupF==AAbvaXV2DQzfNHdm4U3tT(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫἫ") or XoSyx7p6dqZ1CF8: return succeeded,OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
	hPVlYCXsfnx5 += s5WMHyQN4mpie(u"ࠧ࡝ࡰࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠸ࡀࠠࠡࠩἬ")+OK2mcs7f1ekzACupF.replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(FFkml6ZbgXD,fy8iFgEkrO12NR9TWBI35sjY6qHvV)[:wdftVMyzF17cYETHu(u"࠾࠰ഴ")]
	succeeded = EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠺ࠧἭ")
	OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = dk6SMCobOpfWnLu[gLoUCe7WqVp]
	XoSyx7p6dqZ1CF8 = cymM76PR0aiVnX5gZ(XoSyx7p6dqZ1CF8)
	IPJ7yi4HSLna2UE[gLoUCe7WqVp] = hPVlYCXsfnx5,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
	if OK2mcs7f1ekzACupF==wdftVMyzF17cYETHu(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧἮ") or XoSyx7p6dqZ1CF8: return succeeded,OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
	hPVlYCXsfnx5 += vU6DxuzPwMpg(u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠵࠼ࠣࠤࠬἯ")+OK2mcs7f1ekzACupF.replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(FFkml6ZbgXD,fy8iFgEkrO12NR9TWBI35sjY6qHvV)[:Hr25gta6XcqO(u"࠸࠱വ")]
	succeeded = QjAINyUC7MDRq5d8e4vl9(u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠷ࠪἰ")
	OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = LtN7PToYanhvc84I0DgdVp6mAzH[gLoUCe7WqVp]
	XoSyx7p6dqZ1CF8 = cymM76PR0aiVnX5gZ(XoSyx7p6dqZ1CF8)
	IPJ7yi4HSLna2UE[gLoUCe7WqVp] = hPVlYCXsfnx5,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
	if OK2mcs7f1ekzACupF==QjAINyUC7MDRq5d8e4vl9(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪἱ") or XoSyx7p6dqZ1CF8: return succeeded,OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
	hPVlYCXsfnx5 += N6NGJ4vpmidqMCh7yo(u"࠭࡜࡯ࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠹࠿ࠦࠠࠨἲ")+OK2mcs7f1ekzACupF.replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(FFkml6ZbgXD,fy8iFgEkrO12NR9TWBI35sjY6qHvV)[:C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠹࠲ശ")]
	IPJ7yi4HSLna2UE[gLoUCe7WqVp] = hPVlYCXsfnx5,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
	return succeeded,hPVlYCXsfnx5,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
def a0nAtdSbXiKBFNQvHrsTkohx8m3(url,source,gLoUCe7WqVp):
	YLKFRH6sSIrznXBg,UfieKkPzcrWpIsh4vH9F,A8ECQ0qwTRzPifOGW76FK35uUvhe,bbBWiXefkN7VOpUhLQPGwIZF40s,z36flodJVD9jWxip14Rh,ZJqDh4ByGPQn13tlzMOTLCNdcugx,BIbU1q2NrFX,OOnVxtP0TNWsci6HrEGqBm9boKF7g,V6gGYKEO8UqQZ = T2IyJpEoPQKNw8(url,source)
	XoSyx7p6dqZ1CF8 = []
	if Hr25gta6XcqO(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬἳ")	in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = PcY8Ww2NmX(url)
	elif PlpyFa9QMKXxOD1cvHzmI(u"ࠨࡩࡲࡳ࡬ࡲࡥࡶࡵࡨࡶࡨࡵࠧἴ") in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = GZCYTyvcDAtbX(url)
	elif sIzDXlTHYUC5L3xZGnr(u"ࠩࡼࡳࡺࡺࡵࠨἵ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = bMzHYo254smEjwkrZ0IyJ7(url)
	elif O3OVuapf0YFjbm5oUQDg(u"ࠪࡽ࠷ࡻ࠮ࡣࡧࠪἶ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = bMzHYo254smEjwkrZ0IyJ7(url)
	elif Hr25gta6XcqO(u"ࠫࡵ࡮࡯ࡵࡱࡶ࠲ࡦࡶࡰ࠯ࡩࠪἷ")	in url   : OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = s2YLzbZuP58EgRk0(url)
	elif OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧࠧἸ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = WV1rqvfF7Ll(url)
	elif V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠭ࡦࡢࡵࡨࡰ࡭ࡪࠧἹ")		in url   : OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = VTjvHm9N02(url)
	elif FmYoGejTnwKME7d9zPc(u"ࠧࡢࡴࡤࡦࡱࡵࡡࡥࡵࠪἺ")	in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = aiQ1JbzWCNgSBsu76TyM28(url)
	elif PlpyFa9QMKXxOD1cvHzmI(u"ࠨࡣࡵࡧ࡭࡯ࡶࡦࠩἻ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = CVM0diN2e48Xb(url)
	elif N6NGJ4vpmidqMCh7yo(u"ࠩࡥࡹࡿࢀࡶࡳ࡮ࠪἼ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = ItYjeluZM5OEQgJ6HyU(url)
	elif N6NGJ4vpmidqMCh7yo(u"ࠪࡩ࠺ࡺࡳࡢࡴࠪἽ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = ogVCkWKYnB37fQPdwSrDUAyL0tj4(url)
	elif oRJAfwD957WkUyBM1Ehu8m(u"ࠫ࡫ࡧࡣࡶ࡮ࡷࡽࡧࡵ࡯࡬ࡵࠪἾ")	in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = egYth197Mnz60dWuvlUjq4D(url)
	elif Gcw2nelTR864XCVruO3mAFqI5a(u"ࠬ࡯࡮ࡧ࡮ࡤࡱ࠳ࡩࡣࠨἿ")	in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = egYth197Mnz60dWuvlUjq4D(url)
	elif Gcw2nelTR864XCVruO3mAFqI5a(u"࠭ࡵࡱࡤࡤࡱࠬὀ") 		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[url]
	elif CsDcLqQUVK4YBvHFW1(u"ࠧ࡭࡫࡬ࡺ࡮ࡪࡥࡰࠩὁ") 	in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = pyIGCgP0s2KdEfvjVHFbi7LqR(url)
	elif CsDcLqQUVK4YBvHFW1(u"ࠨ࡯ࡳ࠸ࡺࡶ࡬ࡰࡣࡧࠫὂ")	in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = m76kAQnvE1o(url)
	elif FgXzMs0YSDt(u"ࠩࡵࡥࡵ࡯ࡤࡷ࡫ࡧࡩࡴ࠭ὃ") 	in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = N7QPEUOTDefGkxpsh2d1(url)
	elif aOQTKXFL54Nl60Zhp3MbE(u"ࠪࡸࡴࡶ࠴ࡵࡱࡳࠫὄ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = jVKdv4xQJBGts3lh9bZpqnIy(url)
	elif uulNDCPyef78(u"ࠫࡺࡶࡢࠨὅ") 			in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = aShB6TyMz42IWGoV(url)
	elif FmYoGejTnwKME7d9zPc(u"ࠬࡻࡰࡱࠩ὆") 			in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = aShB6TyMz42IWGoV(url)
	elif jL5CrsRwebpyDVXUc1EQP(u"࠭ࡵࡲ࡮ࡲࡥࡩ࠭὇") 		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = f923fEHjrwl5yYh64A(url)
	elif s5WMHyQN4mpie(u"ࠧࡷ࡭ࠪὈ")	 		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = WW1kmVcfLqeKBCiJ0yjYN69d(YLKFRH6sSIrznXBg)
	elif SnhLjmfeJC(u"ࠨࡸࡦࡷࡹࡸࡥࡢ࡯ࠪὉ") 	in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = Bgnf6J12sxbqDpd(url)
	elif SnhLjmfeJC(u"ࠩࡹ࡭ࡩࡨ࡯ࡣࠩὊ")		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = OlvG5dgfXtFYsQ7ai68Zx4k(url)
	elif ggjO5CrKVRPITaesWkxD(u"ࠪࡺ࡮ࡪ࡯ࡻࡣࠪὋ") 		in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = giTbeEldcmwUp07AYNaxoO(url)
	elif ssynAg0zhSkoCpOMDV9(u"ࠫࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯ࠨὌ") 	in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = qPBYkp2tWTS(url)
	elif C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬࡽࡩ࡯ࡶࡹ࠲ࡱ࡯ࡶࡦࠩὍ")	in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = PPrunGxyD2z3QfFt4(url)
	elif jL5CrsRwebpyDVXUc1EQP(u"࠭ࡺࡪࡲࡳࡽࡸ࡮ࡡࡳࡧࠪ὎")	in A8ECQ0qwTRzPifOGW76FK35uUvhe: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = ocPK3HMS2dOlj0AJx8aeRDnWp(url)
	else: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,[],[]
	global BS2ZMby0DqmcCdR
	if not OK2mcs7f1ekzACupF and not XoSyx7p6dqZ1CF8: OK2mcs7f1ekzACupF = jL5CrsRwebpyDVXUc1EQP(u"ࠧࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠢࡘࡲࡰࡴ࡯ࡸࡰࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠸ࠠࡇࡣ࡬ࡰࡺࡸࡥࠨ὏")
	elif OK2mcs7f1ekzACupF not in [fy8iFgEkrO12NR9TWBI35sjY6qHvV,N6NGJ4vpmidqMCh7yo(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ὐ"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬὑ")]: OK2mcs7f1ekzACupF = CsDcLqQUVK4YBvHFW1(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥ࠭ὒ")+OK2mcs7f1ekzACupF
	BS2ZMby0DqmcCdR[gLoUCe7WqVp] = OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
	return
def lBuLAQqsMndC(url,source,gLoUCe7WqVp):
	global VY1bXQc8jKk
	if PlpyFa9QMKXxOD1cvHzmI(u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬὓ") in url:
		VY1bXQc8jKk[gLoUCe7WqVp] = aOQTKXFL54Nl60Zhp3MbE(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࡔ࡭࡬ࡴࡵ࡫ࡤࠨὔ"),[],[]
		return
	OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,[],[]
	if ml1bXR85BJyhPAVvQY(url):
		OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[url]
	if not XoSyx7p6dqZ1CF8:
		OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = TAsrWRzk7Mnug(url)
	if not XoSyx7p6dqZ1CF8:
		OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = kg8ifQSFucoCAMK4HZDGrjxs(url)
	if not XoSyx7p6dqZ1CF8:
		if OK2mcs7f1ekzACupF==oRJAfwD957WkUyBM1Ehu8m(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫὕ"): OK2mcs7f1ekzACupF = fy8iFgEkrO12NR9TWBI35sjY6qHvV
		OK2mcs7f1ekzACupF = O3OVuapf0YFjbm5oUQDg(u"ࠧࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠢࠪὖ")+OK2mcs7f1ekzACupF if OK2mcs7f1ekzACupF else V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻࡙ࠢࠣࡳࡱ࡮ࡰࡹࡱࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠳ࠡࡈࡤ࡭ࡱࡻࡲࡦࠩὗ")
	VY1bXQc8jKk[gLoUCe7WqVp] = OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
	return
def LEP6MUK8rgXYQ5dtDnb0s1(url,source,gLoUCe7WqVp):
	Okwr0yDIL1oVF9AlWRbduUtnzp = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	OmsWt89dSA5HyCZ4wL = LhFAGlQ19zr
	try:
		import resolveurl as AnLjom1GdB9
		OmsWt89dSA5HyCZ4wL = AnLjom1GdB9.resolve(url)
	except Exception as kM6cnpoDPsIjLQEw53RaVGZ7eb0WO2: Okwr0yDIL1oVF9AlWRbduUtnzp = str(kM6cnpoDPsIjLQEw53RaVGZ7eb0WO2)
	global dk6SMCobOpfWnLu
	if not OmsWt89dSA5HyCZ4wL:
		if Okwr0yDIL1oVF9AlWRbduUtnzp==fy8iFgEkrO12NR9TWBI35sjY6qHvV:
			Okwr0yDIL1oVF9AlWRbduUtnzp = NFtwAhXgZB9u.format_exc()
			if Okwr0yDIL1oVF9AlWRbduUtnzp!=wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬ὘"): CfgZ0zWP5XBpoGQwLUY.stderr.write(Okwr0yDIL1oVF9AlWRbduUtnzp)
		OK2mcs7f1ekzACupF = Okwr0yDIL1oVF9AlWRbduUtnzp.splitlines()[-BkM54Kr7Qbqn]
		dk6SMCobOpfWnLu[gLoUCe7WqVp] = wdftVMyzF17cYETHu(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥ࠭Ὑ")+OK2mcs7f1ekzACupF,[],[]
		return
	dk6SMCobOpfWnLu[gLoUCe7WqVp] = fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[OmsWt89dSA5HyCZ4wL]
	return
def mCu0yTwD9ROtfsV1EjHrLSB(url,source,gLoUCe7WqVp):
	Okwr0yDIL1oVF9AlWRbduUtnzp = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	OmsWt89dSA5HyCZ4wL = LhFAGlQ19zr
	try:
		import yt_dlp as Rtcoisbqv2pjlSfZFY
		YdQjl18L6ry = Rtcoisbqv2pjlSfZFY.YoutubeDL({Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫࡳࡵ࡟ࡤࡱ࡯ࡳࡷ࠭὚"): EsCplGc5N4mBuYW0RVQt6b})
		OmsWt89dSA5HyCZ4wL = YdQjl18L6ry.extract_info(url,download=LhFAGlQ19zr)
	except Exception as kM6cnpoDPsIjLQEw53RaVGZ7eb0WO2: Okwr0yDIL1oVF9AlWRbduUtnzp = str(kM6cnpoDPsIjLQEw53RaVGZ7eb0WO2)
	global LtN7PToYanhvc84I0DgdVp6mAzH
	if not OmsWt89dSA5HyCZ4wL or O3OVuapf0YFjbm5oUQDg(u"ࠬ࡬࡯ࡳ࡯ࡤࡸࡸ࠭Ὓ") not in list(OmsWt89dSA5HyCZ4wL.keys()):
		if Okwr0yDIL1oVF9AlWRbduUtnzp==fy8iFgEkrO12NR9TWBI35sjY6qHvV:
			Okwr0yDIL1oVF9AlWRbduUtnzp = NFtwAhXgZB9u.format_exc()
			if Okwr0yDIL1oVF9AlWRbduUtnzp!=EE1jeHnIoad(u"࠭ࡎࡰࡰࡨࡘࡾࡶࡥ࠻ࠢࡑࡳࡳ࡫࡜࡯ࠩ὜"): CfgZ0zWP5XBpoGQwLUY.stderr.write(Okwr0yDIL1oVF9AlWRbduUtnzp)
		OK2mcs7f1ekzACupF = Okwr0yDIL1oVF9AlWRbduUtnzp.splitlines()[-BkM54Kr7Qbqn]
		LtN7PToYanhvc84I0DgdVp6mAzH[gLoUCe7WqVp] = O3OVuapf0YFjbm5oUQDg(u"ࠧࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠢࠪὝ")+OK2mcs7f1ekzACupF,[],[]
	else:
		WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = [],[]
		for bigdh7fpZYl4aT2keV in OmsWt89dSA5HyCZ4wL[ssynAg0zhSkoCpOMDV9(u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩ὞")]:
			WFlpmsYGKNy.append(bigdh7fpZYl4aT2keV[OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠩࡩࡳࡷࡳࡡࡵࠩὟ")])
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV[QjAINyUC7MDRq5d8e4vl9(u"ࠪࡹࡷࡲࠧὠ")])
		LtN7PToYanhvc84I0DgdVp6mAzH[gLoUCe7WqVp] = fy8iFgEkrO12NR9TWBI35sjY6qHvV,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
	return
def TAsrWRzk7Mnug(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,KfHAW8VGbrxi(u"ࠫࡌࡋࡔࠨὡ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LhFAGlQ19zr,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡔࡈࡈࡎࡘࡅࡄࡖࡢ࡙ࡗࡒ࠭࠲ࡵࡷࠫὢ"))
	headers = E6ECvznP9m5sWFMu.headers
	if C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨὣ") in list(headers.keys()):
		bigdh7fpZYl4aT2keV = E6ECvznP9m5sWFMu.headers[N6NGJ4vpmidqMCh7yo(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩὤ")]
		if ml1bXR85BJyhPAVvQY(bigdh7fpZYl4aT2keV): return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
	return Hr25gta6XcqO(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠫὥ"),[],[]
def cymM76PR0aiVnX5gZ(tvl3Tdjo9w):
	if N6NGJ4vpmidqMCh7yo(u"ࠩ࡯࡭ࡸࡺࠧὦ") in str(type(tvl3Tdjo9w)):
		zzECVswWcGAIXhrQlZ7jMokugnv = []
		for bigdh7fpZYl4aT2keV in tvl3Tdjo9w:
			if FmYoGejTnwKME7d9zPc(u"ࠪࡷࡹࡸࠧὧ") in str(type(bigdh7fpZYl4aT2keV)): bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.replace(FFkml6ZbgXD,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE)
			zzECVswWcGAIXhrQlZ7jMokugnv.append(bigdh7fpZYl4aT2keV)
	else: zzECVswWcGAIXhrQlZ7jMokugnv = tvl3Tdjo9w.replace(FFkml6ZbgXD,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE)
	return zzECVswWcGAIXhrQlZ7jMokugnv
def swHTA46JhqZgu(TCGZwKs43fSniQe6EqctNuW,source):
	data = rIhXWK91vRuC(jUCABmLYMf0G,ggjO5CrKVRPITaesWkxD(u"ࠫࡱ࡯ࡳࡵࠩὨ"),o1INZ3ViQqS0Uw5z6kMjbv(u"࡙ࠬࡅࡓࡘࡈࡖࡘ࠭Ὡ"),TCGZwKs43fSniQe6EqctNuW)
	if data:
		WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = zip(*data)
		WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = list(WFlpmsYGKNy),list(XoSyx7p6dqZ1CF8)
		return WFlpmsYGKNy,XoSyx7p6dqZ1CF8
	WFlpmsYGKNy,XoSyx7p6dqZ1CF8,furvoUqQjB2w5n = [],[],[]
	for bigdh7fpZYl4aT2keV in TCGZwKs43fSniQe6EqctNuW:
		if jL5CrsRwebpyDVXUc1EQP(u"࠭࠯࠰ࠩὪ") not in bigdh7fpZYl4aT2keV: continue
		RD2JpTs84Bin9oecLO,z36flodJVD9jWxip14Rh,ZJqDh4ByGPQn13tlzMOTLCNdcugx,BIbU1q2NrFX,OOnVxtP0TNWsci6HrEGqBm9boKF7g = oIsZOqV4lLD(bigdh7fpZYl4aT2keV,source)
		OOnVxtP0TNWsci6HrEGqBm9boKF7g = EcQxOa3RJm86WjTKA.findall(FgXzMs0YSDt(u"ࠧ࡝ࡦ࠮ࠫὫ"),OOnVxtP0TNWsci6HrEGqBm9boKF7g,EcQxOa3RJm86WjTKA.DOTALL)
		if OOnVxtP0TNWsci6HrEGqBm9boKF7g: OOnVxtP0TNWsci6HrEGqBm9boKF7g = int(OOnVxtP0TNWsci6HrEGqBm9boKF7g[D2D96X5NGamBhrFwvL8VEbqiSfZIl])
		else: OOnVxtP0TNWsci6HrEGqBm9boKF7g = D2D96X5NGamBhrFwvL8VEbqiSfZIl
		A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠨࡰࡤࡱࡪ࠭Ὤ"))
		furvoUqQjB2w5n.append([RD2JpTs84Bin9oecLO,z36flodJVD9jWxip14Rh,ZJqDh4ByGPQn13tlzMOTLCNdcugx,BIbU1q2NrFX,OOnVxtP0TNWsci6HrEGqBm9boKF7g,bigdh7fpZYl4aT2keV,A8ECQ0qwTRzPifOGW76FK35uUvhe])
	if furvoUqQjB2w5n:
		EGeitxCKWa9blqUH6YdkoPw0mMIVAS = sorted(furvoUqQjB2w5n,reverse=EsCplGc5N4mBuYW0RVQt6b,key=lambda key: (key[vD4Fh6ictZ7wME],key[D2D96X5NGamBhrFwvL8VEbqiSfZIl],key[XW57OCeGnFTLQbaqdrD9zM],key[teaC5j4HuGDqpwcmUzJ],key[BkM54Kr7Qbqn],key[s5WMHyQN4mpie(u"࠷ഷ")],key[V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠹സ")]))
		CXTL7NPUAE,v2xW6H0ACkOZqwJEDsVcBt5 = [],[]
		for ZUcBH6T19kAxhs in EGeitxCKWa9blqUH6YdkoPw0mMIVAS:
			RD2JpTs84Bin9oecLO,z36flodJVD9jWxip14Rh,ZJqDh4ByGPQn13tlzMOTLCNdcugx,BIbU1q2NrFX,OOnVxtP0TNWsci6HrEGqBm9boKF7g,bigdh7fpZYl4aT2keV,A8ECQ0qwTRzPifOGW76FK35uUvhe = ZUcBH6T19kAxhs
			if EE1jeHnIoad(u"่ࠩๅ฻๊ࠧὭ") in ZJqDh4ByGPQn13tlzMOTLCNdcugx:
				v2xW6H0ACkOZqwJEDsVcBt5.append(ZUcBH6T19kAxhs)
				continue
			if ZUcBH6T19kAxhs not in CXTL7NPUAE: CXTL7NPUAE.append(ZUcBH6T19kAxhs)
		CXTL7NPUAE = v2xW6H0ACkOZqwJEDsVcBt5+CXTL7NPUAE
		iYMzQVNL2h4IRemt = D2D96X5NGamBhrFwvL8VEbqiSfZIl
		for RD2JpTs84Bin9oecLO,z36flodJVD9jWxip14Rh,ZJqDh4ByGPQn13tlzMOTLCNdcugx,BIbU1q2NrFX,OOnVxtP0TNWsci6HrEGqBm9boKF7g,bigdh7fpZYl4aT2keV,A8ECQ0qwTRzPifOGW76FK35uUvhe in CXTL7NPUAE:
			OOnVxtP0TNWsci6HrEGqBm9boKF7g = str(OOnVxtP0TNWsci6HrEGqBm9boKF7g) if OOnVxtP0TNWsci6HrEGqBm9boKF7g else fy8iFgEkrO12NR9TWBI35sjY6qHvV
			title = Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠪื๏ืแาࠩὮ")+ksJdoFWhxTz8Y2N7bOZE+ZJqDh4ByGPQn13tlzMOTLCNdcugx+ksJdoFWhxTz8Y2N7bOZE+RD2JpTs84Bin9oecLO+ksJdoFWhxTz8Y2N7bOZE+OOnVxtP0TNWsci6HrEGqBm9boKF7g+ksJdoFWhxTz8Y2N7bOZE+BIbU1q2NrFX+ksJdoFWhxTz8Y2N7bOZE+z36flodJVD9jWxip14Rh
			if A8ECQ0qwTRzPifOGW76FK35uUvhe.lower() not in title.lower(): title = title+ksJdoFWhxTz8Y2N7bOZE+A8ECQ0qwTRzPifOGW76FK35uUvhe
			title = title.replace(I18uSKaWhgTBeYUPD4sr(u"ࠫࠪ࠭Ὧ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE)
			iYMzQVNL2h4IRemt += BkM54Kr7Qbqn
			title = str(iYMzQVNL2h4IRemt)+EE1jeHnIoad(u"ࠬ࠴ࠠࠨὰ")+title
			if bigdh7fpZYl4aT2keV not in XoSyx7p6dqZ1CF8:
				WFlpmsYGKNy.append(title)
				XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
		if XoSyx7p6dqZ1CF8:
			data = list(zip(WFlpmsYGKNy,XoSyx7p6dqZ1CF8))
			if data: tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,vU6DxuzPwMpg(u"࠭ࡓࡆࡔ࡙ࡉࡗ࡙ࠧά"),TCGZwKs43fSniQe6EqctNuW,data,rrux12tcwQl5)
	WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = list(WFlpmsYGKNy),list(XoSyx7p6dqZ1CF8)
	return WFlpmsYGKNy,XoSyx7p6dqZ1CF8
def Y2R4hvV9acIbr8jP6l5(url):
	if CsDcLqQUVK4YBvHFW1(u"ࠧ࠯࡯࠶ࡹ࠽࠭ὲ") in url:
		WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = kDKwn73e02jNdRLG8U4HxTgpVQqI(BfWYUAnyg6eONLjiuE,url)
		if XoSyx7p6dqZ1CF8: return fy8iFgEkrO12NR9TWBI35sjY6qHvV,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
		return CsDcLqQUVK4YBvHFW1(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑ࠸࡛࠸ࠨέ"),[],[]
	return I18uSKaWhgTBeYUPD4sr(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬὴ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[url]
def llQyzAJViv(url):
	hFzEyHWOoRxG,paJKP0Usbeju4liH = [],[]
	if V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶ࠲ࡲࡶ࠴ࡀࡸ࡬ࡨࡂ࠭ή") in url:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠫࡌࡋࡔࠨὶ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LhFAGlQ19zr,fy8iFgEkrO12NR9TWBI35sjY6qHvV,KfHAW8VGbrxi(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡍࡄࡘࡐࡕࡕࡕࡇ࠰࠵ࡸࡺࠧί"))
		if uulNDCPyef78(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨὸ") in E6ECvznP9m5sWFMu.headers:
			bigdh7fpZYl4aT2keV = E6ECvznP9m5sWFMu.headers[KfHAW8VGbrxi(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩό")]
			hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
			A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,aOQTKXFL54Nl60Zhp3MbE(u"ࠨࡰࡤࡱࡪ࠭ὺ"))
			paJKP0Usbeju4liH.append(A8ECQ0qwTRzPifOGW76FK35uUvhe)
	elif Gcw2nelTR864XCVruO3mAFqI5a(u"ࠩ࡮ࡥࡹࡱ࡯ࡶࡶࡨ࠲ࡨࡵ࡭ࠨύ") in url:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠪࡋࡊ࡚ࠧὼ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EE1jeHnIoad(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯࠵ࡲࡩ࠭ώ"))
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		CDwfqFKj3u5s64JgANQTX2RLElkz = EcQxOa3RJm86WjTKA.findall(s5WMHyQN4mpie(u"ࠬ࠮ࡥࡷࡣ࡯ࡠ࠭࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡜ࠩࡲ࠯ࡥ࠱ࡩࠬ࡬࠮ࡨ࠰ࡩࡢࠩ࠯ࠬࡂࡠ࠮ࡢࠩࠪ࠰࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬ὾"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if CDwfqFKj3u5s64JgANQTX2RLElkz:
			CDwfqFKj3u5s64JgANQTX2RLElkz = CDwfqFKj3u5s64JgANQTX2RLElkz[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			p49VlrNTy3WF = sO08q1xvolnpguK4CDIQ9dk3j6L(CDwfqFKj3u5s64JgANQTX2RLElkz)
			OxdaGKn62ICq7jF8pPWcgE901UV = EcQxOa3RJm86WjTKA.findall(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺ࠩ࡞࡞࠲࠯ࡅ࡜࡞ࠫ࠯ࠫ὿"),p49VlrNTy3WF,EcQxOa3RJm86WjTKA.DOTALL)
			if OxdaGKn62ICq7jF8pPWcgE901UV:
				OxdaGKn62ICq7jF8pPWcgE901UV = OxdaGKn62ICq7jF8pPWcgE901UV[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
				OxdaGKn62ICq7jF8pPWcgE901UV = LB7TcZnGYdfw5lWU1RH3Oztu9PyA(FgXzMs0YSDt(u"ࠧ࡭࡫ࡶࡸࠬᾀ"),OxdaGKn62ICq7jF8pPWcgE901UV)
				for dict in OxdaGKn62ICq7jF8pPWcgE901UV:
					bigdh7fpZYl4aT2keV = dict[sJw9QWiq1Kr0xfeVRI(u"ࠨࡨ࡬ࡰࡪ࠭ᾁ")]
					OOnVxtP0TNWsci6HrEGqBm9boKF7g = dict[O3OVuapf0YFjbm5oUQDg(u"ࠩ࡯ࡥࡧ࡫࡬ࠨᾂ")]
					hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
					A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠪࡲࡦࡳࡥࠨᾃ"))
					paJKP0Usbeju4liH.append(OOnVxtP0TNWsci6HrEGqBm9boKF7g+ksJdoFWhxTz8Y2N7bOZE+A8ECQ0qwTRzPifOGW76FK35uUvhe)
		elif s5WMHyQN4mpie(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ᾄ") in E6ECvznP9m5sWFMu.headers:
			bigdh7fpZYl4aT2keV = E6ECvznP9m5sWFMu.headers[wdftVMyzF17cYETHu(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧᾅ")]
			hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
			A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,o1INZ3ViQqS0Uw5z6kMjbv(u"࠭࡮ࡢ࡯ࡨࠫᾆ"))
			paJKP0Usbeju4liH.append(A8ECQ0qwTRzPifOGW76FK35uUvhe)
		if I18uSKaWhgTBeYUPD4sr(u"ࠧࡀࡷࡵࡰࡂ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡰࡩࡱࡷࡳࡸ࠴ࡡࡱࡲ࠱࡫ࡴࡵࠧᾇ") in url:
			bigdh7fpZYl4aT2keV = url.split(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨࡁࡸࡶࡱࡃࠧᾈ"))[BkM54Kr7Qbqn]
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.split(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠩࠩࠫᾉ"))[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			if bigdh7fpZYl4aT2keV:
				hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
				paJKP0Usbeju4liH.append(oRJAfwD957WkUyBM1Ehu8m(u"ࠪࡴ࡭ࡵࡴࡰࡵࠣ࡫ࡴࡵࡧ࡭ࡧࠪᾊ"))
	else:
		hFzEyHWOoRxG.append(url)
		A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(url,Hr25gta6XcqO(u"ࠫࡳࡧ࡭ࡦࠩᾋ"))
		paJKP0Usbeju4liH.append(A8ECQ0qwTRzPifOGW76FK35uUvhe)
	if not hFzEyHWOoRxG: return I18uSKaWhgTBeYUPD4sr(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡌࡃࡗࡏࡔ࡛ࡔࡆࠩᾌ"),[],[]
	elif len(hFzEyHWOoRxG)==BkM54Kr7Qbqn: bigdh7fpZYl4aT2keV = hFzEyHWOoRxG[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	else:
		yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠭รฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫᾍ"),paJKP0Usbeju4liH)
		if yNqzFDjKM0SrO==-BkM54Kr7Qbqn: return vU6DxuzPwMpg(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᾎ"),[],[]
		bigdh7fpZYl4aT2keV = hFzEyHWOoRxG[yNqzFDjKM0SrO]
	return OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᾏ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
def GZCYTyvcDAtbX(url):
	headers = {AAbvaXV2DQzfNHdm4U3tT(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᾐ"):CsDcLqQUVK4YBvHFW1(u"ࠪࡏࡴࡪࡩ࠰ࠩᾑ")+str(FpjKBIUaEwbmLkxANfs)}
	for b3b24XZTV7gW9mhcqLoCnftO in range(o1INZ3ViQqS0Uw5z6kMjbv(u"࠹࠵ഹ")):
		uUqrNPcXKBoQ0slv.sleep(s5WMHyQN4mpie(u"࠵࠴࠱࠱࠲ഺ"))
		E6ECvznP9m5sWFMu = FlxDpgfQcuSWvGwtyC5d(sJw9QWiq1Kr0xfeVRI(u"ࠫࡌࡋࡔࠨᾒ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,LhFAGlQ19zr,fy8iFgEkrO12NR9TWBI35sjY6qHvV,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡒࡓࡌࡒࡅࡖࡕࡈࡖࡈࡕࡎࡕࡇࡑࡘ࠲࠷ࡳࡵࠩᾓ"))
		if PlpyFa9QMKXxOD1cvHzmI(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨᾔ") in list(E6ECvznP9m5sWFMu.headers.keys()):
			bigdh7fpZYl4aT2keV = E6ECvznP9m5sWFMu.headers[oRJAfwD957WkUyBM1Ehu8m(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩᾕ")]
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧᾖ")+headers[QjAINyUC7MDRq5d8e4vl9(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᾗ")]
			return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
		if E6ECvznP9m5sWFMu.code!=AAbvaXV2DQzfNHdm4U3tT(u"࠺࠲࠺഻"): break
	return ssynAg0zhSkoCpOMDV9(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕࠩᾘ"),[],[]
def s2YLzbZuP58EgRk0(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,sJw9QWiq1Kr0xfeVRI(u"ࠫࡌࡋࡔࠨᾙ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡒࡋࡓ࡙ࡕࡓࡈࡑࡒࡋࡑࡋ࠭࠲ࡵࡷࠫᾚ"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(FmYoGejTnwKME7d9zPc(u"࠭ࠢࠩࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡩ࡫࡯࠮ࡦࡲࡻࡳࡲ࡯ࡢࡦࡶ࠲࠯ࡅࠩࠣ࠮࠱࠮ࡄ࠲࠮ࠫࡁ࠯ࠬ࠳࠰࠿ࠪ࠮ࠪᾛ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if bigdh7fpZYl4aT2keV:
		bigdh7fpZYl4aT2keV,OOnVxtP0TNWsci6HrEGqBm9boKF7g = bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[OOnVxtP0TNWsci6HrEGqBm9boKF7g],[bigdh7fpZYl4aT2keV]
	return sIzDXlTHYUC5L3xZGnr(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡓࡌࡔ࡚ࡏࡔࡉࡒࡓࡌࡒࡅࠨᾜ"),[],[]
def jj2WXmTKkx(url):
	if s5WMHyQN4mpie(u"ࠨ࠱ࡺࡩࡪࡶࡩࡴ࠱ࠪᾝ") in url:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,AAbvaXV2DQzfNHdm4U3tT(u"ࠩࡊࡉ࡙࠭ᾞ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,PlpyFa9QMKXxOD1cvHzmI(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡆࡅࡌࡑࡆ࠸࠭࠲ࡵࡷࠫᾟ"))
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(PlpyFa9QMKXxOD1cvHzmI(u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡱࡶࡣ࡯࡭ࡹࡿ࠾ࠨᾠ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if bigdh7fpZYl4aT2keV: url = bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		else: return ggjO5CrKVRPITaesWkxD(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡇࡆࡍࡒࡇ࠲ࠨᾡ"),[],[]
	return OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᾢ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[url]
def qlWwXt6pmFAOKIjMBrYgvc3dESeuiy(url):
	OK2mcs7f1ekzACupF,paJKP0Usbeju4liH,hFzEyHWOoRxG = fy8iFgEkrO12NR9TWBI35sjY6qHvV,[],[]
	if ggjO5CrKVRPITaesWkxD(u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࠫᾣ") in url:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,I18uSKaWhgTBeYUPD4sr(u"ࠨࡉࡈࡘࠬᾤ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LhFAGlQ19zr,FmYoGejTnwKME7d9zPc(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡗࡖࡊࡆ࠰࠵ࡸࡺࠧᾥ"))
		bigdh7fpZYl4aT2keV = E6ECvznP9m5sWFMu.url
		if bigdh7fpZYl4aT2keV: OK2mcs7f1ekzACupF,paJKP0Usbeju4liH,hFzEyHWOoRxG = fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
	elif Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪࡷࡪࡸࡶ࠾ࠩᾦ") in url:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,oRJAfwD957WkUyBM1Ehu8m(u"ࠫࡌࡋࡔࠨᾧ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡓ࡙ࡍࡉ࠳࠲࡯ࡦࠪᾨ"))
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠭࠼ࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᾩ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if bigdh7fpZYl4aT2keV: url = bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		else:
			bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(AAbvaXV2DQzfNHdm4U3tT(u"ࠢࡂ࡮ࡥࡥࡕࡲࡡࡺࡧࡵࡇࡴࡴࡴࡳࡱ࡯ࡠ࠭࠭ࠨ࠯ࠬࡂ࠭ࠬࠨᾪ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
			if bigdh7fpZYl4aT2keV:
				url = bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
				url = JNfHYgOdP9aR.b64decode(url)
				if jTDWgftK7NEmx0JAkOn2aRIvweq: url = url.decode(Tk9eH2qw6Brsuhj)
			else: return OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡕ࡛ࡏࡄࠨᾫ"),[],[]
		OK2mcs7f1ekzACupF,paJKP0Usbeju4liH,hFzEyHWOoRxG = EE1jeHnIoad(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᾬ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[url]
	else:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,SnhLjmfeJC(u"ࠪࡋࡊ࡚ࠧᾭ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,AAbvaXV2DQzfNHdm4U3tT(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡒࡘࡌࡈ࠲࠹ࡲࡥࠩᾮ"))
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall(QjAINyUC7MDRq5d8e4vl9(u"ࠬࠨࡡࡱ࡮ࡵ࠱ࡲ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᾯ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			items = EcQxOa3RJm86WjTKA.findall(aOQTKXFL54Nl60Zhp3MbE(u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩᾰ"),wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title in items:
				paJKP0Usbeju4liH.append(title)
				hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
	return OK2mcs7f1ekzACupF,paJKP0Usbeju4liH,hFzEyHWOoRxG
def VTjvHm9N02(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,Gcw2nelTR864XCVruO3mAFqI5a(u"ࠧࡈࡇࡗࠫᾱ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CsDcLqQUVK4YBvHFW1(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡓࡆࡎࡋࡈ࠶࠳࠱ࡴࡶࠪᾲ"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	FGRX4myP68S = wgGqOiUQuT(FGRX4myP68S)
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(KfHAW8VGbrxi(u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪᾳ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if bigdh7fpZYl4aT2keV: return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl]]
	return uulNDCPyef78(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡁࡔࡇࡏࡌࡉ࠷ࠧᾴ"),[],[]
def PcJQBUOKfk(url):
	if len(url)>O3OVuapf0YFjbm5oUQDg(u"࠲࠱࠲഼"):
		url = url.strip(wdftVMyzF17cYETHu(u"ࠫ࠴࠭᾵"))+Hr25gta6XcqO(u"ࠬ࠵ࠧᾶ")
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,CsDcLqQUVK4YBvHFW1(u"࠭ࡇࡆࡖࠪᾷ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,oRJAfwD957WkUyBM1Ehu8m(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡐࡆࡘࡏ࡛ࡃ࠰࠵ࡸࡺࠧᾸ"))
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		if D2D96X5NGamBhrFwvL8VEbqiSfZIl and C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠫ࡬࠱ࡻࠬ࡯࠮ࡷ࠰ࡪ࠲ࡲࠪࠩᾹ") in FGRX4myP68S:
			z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall(wdftVMyzF17cYETHu(u"ࠩࠥࡰࡴࡧࡤࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᾺ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
			if z6PX2p7diaskQElBOvMRNcHwqG5D:
				wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
				z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall(uulNDCPyef78(u"ࠪࡀࡸࡩࡲࡪࡲࡷࡂࡻࡧࡲࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡥࡵ࡭ࡵࡺࠧΆ"),wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
				if z6PX2p7diaskQElBOvMRNcHwqG5D:
					wlJ6d8hEvpoMNSCmU = NNSLyeFBOc(z6PX2p7diaskQElBOvMRNcHwqG5D[D2D96X5NGamBhrFwvL8VEbqiSfZIl])
		elif len(FGRX4myP68S)<sIzDXlTHYUC5L3xZGnr(u"࠵࠲࠳ഽ"): bigdh7fpZYl4aT2keV = FGRX4myP68S
		else: return jL5CrsRwebpyDVXUc1EQP(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡌࡂࡔࡒ࡞ࡆ࠭ᾼ"),[],[]
		return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
	return aOQTKXFL54Nl60Zhp3MbE(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ᾽"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[url]
def FrSp3B1LEY(url):
	if V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠭࠯ࡥࡱࡺࡲ࠳ࡶࡨࡱࠩι") in url:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,FgXzMs0YSDt(u"ࠧࡈࡇࡗࠫ᾿"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡎࡏࡇࡊࡄ࠱࠶ࡹࡴࠨ῀"))
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(oRJAfwD957WkUyBM1Ehu8m(u"ࠩࡹ࡭ࡩ࡫࡯࠮ࡹࡵࡥࡵࡶࡥࡳ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ῁"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		url = bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	return vU6DxuzPwMpg(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ῂ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[url]
def mmSelOD8xV(url):
	if KfHAW8VGbrxi(u"ࠫࡸ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࠨῃ") in url:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬࡍࡅࡕࠩῄ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,SnhLjmfeJC(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇ࠴ࡖ࠯࠴ࡷࡹ࠭῅"))
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(FgXzMs0YSDt(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬῆ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		if C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨࡪࡷࡸࡵ࠭ῇ") in bigdh7fpZYl4aT2keV: return C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬῈ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
		return Hr25gta6XcqO(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡉࡉࡎࡃ࠷࡙ࠬΈ"),[],[]
	return V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧῊ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[url]
def MMD01SrpIK(url):
	YLKFRH6sSIrznXBg,gWBLDSlZGwqxHT = lNyxXsMAcYHBUDh4dJbfTWR(url)
	naBFTDfp6lmKjeOywg87IAcb = {KfHAW8VGbrxi(u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨΉ"):Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧῌ"),AAbvaXV2DQzfNHdm4U3tT(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭῍"):OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ῎")}
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,wdftVMyzF17cYETHu(u"ࠩࡓࡓࡘ࡚ࠧ῏"),YLKFRH6sSIrznXBg,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡑࡓ࡜࠳࠱ࡴࡶࠪῐ"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩῑ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not bigdh7fpZYl4aT2keV: return wdftVMyzF17cYETHu(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡉ࡜ࡒࡔ࡝ࠧῒ"),[],[]
	bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	return N6NGJ4vpmidqMCh7yo(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩΐ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
def eURCisO6mN(url):
	headers = {EE1jeHnIoad(u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ῔"):QjAINyUC7MDRq5d8e4vl9(u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ῕")}
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,vU6DxuzPwMpg(u"ࠩࡊࡉ࡙࠭ῖ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,AAbvaXV2DQzfNHdm4U3tT(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡑࡒࡊࡕࡘࡏ࠮࠳ࡶࡸࠬῗ"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩῘ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL|EcQxOa3RJm86WjTKA.IGNORECASE)
	if not bigdh7fpZYl4aT2keV: return ggjO5CrKVRPITaesWkxD(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡔࡊࡒࡓࡋࡖࡒࡐࠩῙ"),[],[]
	bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	return EE1jeHnIoad(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩῚ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
def MMarx62L4F(url):
	YLKFRH6sSIrznXBg,gWBLDSlZGwqxHT = lNyxXsMAcYHBUDh4dJbfTWR(url)
	naBFTDfp6lmKjeOywg87IAcb = {QjAINyUC7MDRq5d8e4vl9(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭Ί"):FmYoGejTnwKME7d9zPc(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ῜")}
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,jL5CrsRwebpyDVXUc1EQP(u"ࠩࡓࡓࡘ࡚ࠧ῝"),YLKFRH6sSIrznXBg,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,vU6DxuzPwMpg(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡈࡂࡎࡄࡇࡎࡓࡁ࠮࠳ࡶࡸࠬ῞"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫࠬ࠭࠼ࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࡠࠨࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣࠩࡠࠫࠬ࠭῟"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL|EcQxOa3RJm86WjTKA.IGNORECASE)
	if not bigdh7fpZYl4aT2keV: return OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡉࡃࡏࡅࡈࡏࡍࡂࠩῠ"),[],[]
	bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	if EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭ࡨࡵࡶࡳࠫῡ") not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = FmYoGejTnwKME7d9zPc(u"ࠧࡩࡶࡷࡴ࠿࠭ῢ")+bigdh7fpZYl4aT2keV
	return AAbvaXV2DQzfNHdm4U3tT(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫΰ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
def YYIUphus1F(url):
	R9b8gUvoB4wOfkTIjlEsZrM5LtinpS,paJKP0Usbeju4liH,hFzEyHWOoRxG = url,[],[]
	if EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࠩῤ") in url:
		YLKFRH6sSIrznXBg,gWBLDSlZGwqxHT = lNyxXsMAcYHBUDh4dJbfTWR(url)
		naBFTDfp6lmKjeOywg87IAcb = {wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩῥ"):SnhLjmfeJC(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫῦ")}
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,SnhLjmfeJC(u"ࠬࡖࡏࡔࡖࠪῧ"),YLKFRH6sSIrznXBg,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,I18uSKaWhgTBeYUPD4sr(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡁࡃࡆࡒ࠱࠶ࡹࡴࠨῨ"))
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		GmYolHzab0xs8F6f = EcQxOa3RJm86WjTKA.findall(AAbvaXV2DQzfNHdm4U3tT(u"ࠧࠨࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿࡞ࠦࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨࠧ࡞ࠩࠪࠫῩ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL|EcQxOa3RJm86WjTKA.IGNORECASE)
		if GmYolHzab0xs8F6f: R9b8gUvoB4wOfkTIjlEsZrM5LtinpS = GmYolHzab0xs8F6f[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	return C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫῪ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[R9b8gUvoB4wOfkTIjlEsZrM5LtinpS]
def UUnxtcWRAf(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,aOQTKXFL54Nl60Zhp3MbE(u"ࠩࡊࡉ࡙࠭Ύ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,FgXzMs0YSDt(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡔࡗࡈࡘࡒ࠲࠷ࡳࡵࠩῬ"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	AApFXTgazQ7leUroY5R = EcQxOa3RJm86WjTKA.findall(Hr25gta6XcqO(u"ࠦࡻࡧࡲࠡࡨࡶࡩࡷࡼࠠ࠾࠰࠭ࡃࠬ࠮࠮ࠫࡁࠬࠫࠧ῭"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL|EcQxOa3RJm86WjTKA.IGNORECASE)
	if AApFXTgazQ7leUroY5R:
		AApFXTgazQ7leUroY5R = AApFXTgazQ7leUroY5R[D2D96X5NGamBhrFwvL8VEbqiSfZIl][s5WMHyQN4mpie(u"࠴ാ"):]
		AApFXTgazQ7leUroY5R = JNfHYgOdP9aR.b64decode(AApFXTgazQ7leUroY5R)
		if jTDWgftK7NEmx0JAkOn2aRIvweq: AApFXTgazQ7leUroY5R = AApFXTgazQ7leUroY5R.decode(Tk9eH2qw6Brsuhj)
		bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(vU6DxuzPwMpg(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ΅"),AApFXTgazQ7leUroY5R,EcQxOa3RJm86WjTKA.DOTALL)
	else: bigdh7fpZYl4aT2keV = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if not bigdh7fpZYl4aT2keV: return EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡖ࡙ࡊ࡚ࡔࠧ`"),[],[]
	bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	if oRJAfwD957WkUyBM1Ehu8m(u"ࠧࡩࡶࡷࡴࠬ῰") not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠨࡪࡷࡸࡵࡀࠧ῱")+bigdh7fpZYl4aT2keV
	return OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬῲ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
def XXn8ZTeaC1Rt4c0uwQ9qHFOLo7jg(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,EE1jeHnIoad(u"ࠪࡋࡊ࡚ࠧῳ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎ࡛ࡈࡋ࡞࡜ࡉࡑ࠯࠴ࡷࡹ࠭ῴ"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(CsDcLqQUVK4YBvHFW1(u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡭࠯ࡶࡱ࠲࠷࠲ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ῵"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not bigdh7fpZYl4aT2keV: return QjAINyUC7MDRq5d8e4vl9(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏ࡜ࡉࡌ࡟ࡖࡊࡒࠪῶ"),[],[]
	bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	return FmYoGejTnwKME7d9zPc(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪῷ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
def PcY8Ww2NmX(url):
	id = url.split(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠨ࠱ࠪῸ"))[-oRJAfwD957WkUyBM1Ehu8m(u"࠴ി")]
	if SnhLjmfeJC(u"ࠩ࠲ࡩࡲࡨࡥࡥࠩΌ") in url: url = url.replace(aOQTKXFL54Nl60Zhp3MbE(u"ࠪ࠳ࡪࡳࡢࡦࡦࠪῺ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	url = url.replace(uulNDCPyef78(u"ࠫ࠳ࡩ࡯࡮࠱ࠪΏ"),o1INZ3ViQqS0Uw5z6kMjbv(u"ࠬ࠴ࡣࡰ࡯࠲ࡴࡱࡧࡹࡦࡴ࠲ࡱࡪࡺࡡࡥࡣࡷࡥ࠴࠭ῼ"))
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,aOQTKXFL54Nl60Zhp3MbE(u"࠭ࡇࡆࡖࠪ´"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,SnhLjmfeJC(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮࠳ࡶࡸࠬ῾"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	OK2mcs7f1ekzACupF = FgXzMs0YSDt(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨ῿")
	kM6cnpoDPsIjLQEw53RaVGZ7eb0WO2 = EcQxOa3RJm86WjTKA.findall(KfHAW8VGbrxi(u"ࠫࠧ࡫ࡲࡳࡱࡵࠦ࠳࠰࠿ࠣ࡯ࡨࡷࡸࡧࡧࡦࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬࠀ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if kM6cnpoDPsIjLQEw53RaVGZ7eb0WO2: OK2mcs7f1ekzACupF = kM6cnpoDPsIjLQEw53RaVGZ7eb0WO2[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	url = EcQxOa3RJm86WjTKA.findall(I18uSKaWhgTBeYUPD4sr(u"ࠬࡾ࠭࡮ࡲࡨ࡫࡚ࡘࡌࠣ࠮ࠥࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩࠁ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not url and OK2mcs7f1ekzACupF:
		return OK2mcs7f1ekzACupF,[],[]
	bigdh7fpZYl4aT2keV = url[D2D96X5NGamBhrFwvL8VEbqiSfZIl].replace(jL5CrsRwebpyDVXUc1EQP(u"࠭࡜࡝ࠩࠂ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	O9nG5azDistV1c,TCGZwKs43fSniQe6EqctNuW = kDKwn73e02jNdRLG8U4HxTgpVQqI(BfWYUAnyg6eONLjiuE,bigdh7fpZYl4aT2keV)
	O0nkSFcZRm182p47v69tG = OdiZIyCfDUsW3JBGR2VAb.getSetting(Hr25gta6XcqO(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡦ࡮ࡺࡲࡢࡶࡨࠫࠃ"))
	if O0nkSFcZRm182p47v69tG and oRJAfwD957WkUyBM1Ehu8m(u"ࠨ࠯ࠪࠄ") not in O0nkSFcZRm182p47v69tG: title,bigdh7fpZYl4aT2keV = O9nG5azDistV1c[D2D96X5NGamBhrFwvL8VEbqiSfZIl],TCGZwKs43fSniQe6EqctNuW[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	else:
		CRflaycBvUF = EcQxOa3RJm86WjTKA.findall(Hr25gta6XcqO(u"ࠩࠥࡳࡼࡴࡥࡳࠤ࠽ࡠࢀࠨࡩࡥࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡴࡥࡵࡩࡪࡴ࡮ࡢ࡯ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠅ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if CRflaycBvUF: bgJkshmLZ3l8EC,zzhNQojauBd2tLSpbcxgXqJVTHikY9,uNRvsTZ5bFm9EYtxQjJka = CRflaycBvUF[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		else: bgJkshmLZ3l8EC,zzhNQojauBd2tLSpbcxgXqJVTHikY9,uNRvsTZ5bFm9EYtxQjJka = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
		uNRvsTZ5bFm9EYtxQjJka = uNRvsTZ5bFm9EYtxQjJka.replace(KfHAW8VGbrxi(u"ࠪࡠ࠴࠭ࠆ"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠫ࠴࠭ࠇ"))
		zzhNQojauBd2tLSpbcxgXqJVTHikY9 = XXcPiylRDh6IapYA25rwO8u(zzhNQojauBd2tLSpbcxgXqJVTHikY9)
		WFlpmsYGKNy = [n0nFOd4yR97fQzNLSW+OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠬࡕࡗࡏࡇࡕ࠾ࠥࠦࠧࠈ")+zzhNQojauBd2tLSpbcxgXqJVTHikY9+T7ASIp1ZYwio9HQ8cObJK]+O9nG5azDistV1c
		XoSyx7p6dqZ1CF8 = [uNRvsTZ5bFm9EYtxQjJka]+TCGZwKs43fSniQe6EqctNuW
		yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠥ࠮ࠧࠉ")+str(len(XoSyx7p6dqZ1CF8)-I18uSKaWhgTBeYUPD4sr(u"࠵ീ"))+KfHAW8VGbrxi(u"ࠧࠡ็็ๅ࠮࠭ࠊ"),WFlpmsYGKNy)
		if yNqzFDjKM0SrO==-BkM54Kr7Qbqn: return C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ࠋ"),[],[]
		elif yNqzFDjKM0SrO==D2D96X5NGamBhrFwvL8VEbqiSfZIl:
			h6RSrfXtAnB2HgiaK = CfgZ0zWP5XBpoGQwLUY.argv[D2D96X5NGamBhrFwvL8VEbqiSfZIl]+FmYoGejTnwKME7d9zPc(u"ࠩࡂࡸࡾࡶࡥ࠾ࡨࡲࡰࡩ࡫ࡲࠧ࡯ࡲࡨࡪࡃ࠴࠱࠴ࠩࡹࡷࡲ࠽ࠨࠌ")+uNRvsTZ5bFm9EYtxQjJka+O3OVuapf0YFjbm5oUQDg(u"ࠪࠪࡹ࡫ࡸࡵࡶࡀࠫࠍ")+zzhNQojauBd2tLSpbcxgXqJVTHikY9
			bEWpDHXjCBqd7aOiN6UG5k.executebuiltin(vU6DxuzPwMpg(u"ࠦࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࠣࠎ")+h6RSrfXtAnB2HgiaK+sJw9QWiq1Kr0xfeVRI(u"ࠧ࠯ࠢࠏ"))
			return ggjO5CrKVRPITaesWkxD(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࠐ"),[],[]
		title,bigdh7fpZYl4aT2keV = WFlpmsYGKNy[yNqzFDjKM0SrO],XoSyx7p6dqZ1CF8[yNqzFDjKM0SrO]
	return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[title],[bigdh7fpZYl4aT2keV]
def JoD7l3kPLf(bigdh7fpZYl4aT2keV):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,EE1jeHnIoad(u"ࠧࡈࡇࡗࠫࠑ"),bigdh7fpZYl4aT2keV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,FmYoGejTnwKME7d9zPc(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇࡕࡋࡓࡃ࠰࠵ࡸࡺࠧࠒ"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	if LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠩ࠱࡮ࡸࡵ࡮ࠨࠓ") in bigdh7fpZYl4aT2keV: url = EcQxOa3RJm86WjTKA.findall(I18uSKaWhgTBeYUPD4sr(u"ࠪࠦࡸࡸࡣࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪࠔ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	else: url = EcQxOa3RJm86WjTKA.findall(o1INZ3ViQqS0Uw5z6kMjbv(u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩࠕ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not url: return vU6DxuzPwMpg(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡃࡑࡎࡖࡆ࠭ࠖ"),[],[]
	url = url[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	if SnhLjmfeJC(u"࠭ࡨࡵࡶࡳࠫࠗ") not in url: url = I18uSKaWhgTBeYUPD4sr(u"ࠧࡩࡶࡷࡴ࠿࠭࠘")+url
	return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[url]
def WV1rqvfF7Ll(url):
	headers = { EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ࠙") : fy8iFgEkrO12NR9TWBI35sjY6qHvV }
	if wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠩࡲࡴࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠬࠚ") in url:
		FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(d9vcuo3Hy7RhAk2,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠳ࡶࡸࠬࠛ"))
		items = EcQxOa3RJm86WjTKA.findall(EE1jeHnIoad(u"ࠫࡩ࡯ࡲࡦࡥࡷࠤࡱ࡯࡮࡬࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪࠜ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if items: return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[items[D2D96X5NGamBhrFwvL8VEbqiSfZIl]]
		else:
			kf40tulvSA7z9RqNF5dXca3seMD = EcQxOa3RJm86WjTKA.findall(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡫ࡲࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪࠝ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
			if kf40tulvSA7z9RqNF5dXca3seMD:
				GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠭ัิษ็อ๋ࠥๆࠡษ็้ํู่ࠡษ็หฺ๊๊ࠨࠞ"),kf40tulvSA7z9RqNF5dXca3seMD[D2D96X5NGamBhrFwvL8VEbqiSfZIl])
				return SnhLjmfeJC(u"ࠧࡆࡴࡵࡳࡷࡀࠠࠨࠟ")+kf40tulvSA7z9RqNF5dXca3seMD[D2D96X5NGamBhrFwvL8VEbqiSfZIl],[],[]
	else:
		z6FysMQJTa2IWYdrDx7BjObwN3fE = wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠨ࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧࠫࠠ")
		FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(d9vcuo3Hy7RhAk2,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,aOQTKXFL54Nl60Zhp3MbE(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠳ࡰࡧࠫࠡ"))
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall(EE1jeHnIoad(u"ࠪࡊࡴࡸ࡭ࠡ࡯ࡨࡸ࡭ࡵࡤ࠾ࠤࡓࡓࡘ࡚ࠢࠡࡣࡦࡸ࡮ࡵ࡮࠾࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬࠢ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if not z6PX2p7diaskQElBOvMRNcHwqG5D: return sJw9QWiq1Kr0xfeVRI(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡐࡕࡋࡅࡍࡊࡁࠨࠣ"),[],[]
		R9b8gUvoB4wOfkTIjlEsZrM5LtinpS = z6PX2p7diaskQElBOvMRNcHwqG5D[D2D96X5NGamBhrFwvL8VEbqiSfZIl][D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[D2D96X5NGamBhrFwvL8VEbqiSfZIl][BkM54Kr7Qbqn]
		if AAbvaXV2DQzfNHdm4U3tT(u"ࠬ࠴ࡲࡢࡴࠪࠤ") in wlJ6d8hEvpoMNSCmU or O3OVuapf0YFjbm5oUQDg(u"࠭࠮ࡻ࡫ࡳࠫࠥ") in wlJ6d8hEvpoMNSCmU: return PlpyFa9QMKXxOD1cvHzmI(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡎࡑࡖࡌࡆࡎࡄࡂࠢࡑࡳࡹࠦࡡࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠬࠦ"),[],[]
		items = EcQxOa3RJm86WjTKA.findall(I18uSKaWhgTBeYUPD4sr(u"ࠨࡰࡤࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩࠧ"),wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		B7gtJnK24RY = {}
		for z36flodJVD9jWxip14Rh,value in items:
			B7gtJnK24RY[z36flodJVD9jWxip14Rh] = value
		data = YYpHcWVqImGPU4LXM(B7gtJnK24RY)
		FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(d9vcuo3Hy7RhAk2,R9b8gUvoB4wOfkTIjlEsZrM5LtinpS,data,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,FgXzMs0YSDt(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠴ࡴࡧࠫࠨ"))
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall(aOQTKXFL54Nl60Zhp3MbE(u"ࠪࡈࡴࡽ࡮࡭ࡱࡤࡨࠥ࡜ࡩࡥࡧࡲ࠲࠯ࡅࡧࡦࡶ࡟ࠬࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭࠮ࠫࡁࡶࡳࡺࡸࡣࡦࡵ࠽ࠬ࠳࠰࠿ࠪ࡫ࡰࡥ࡬࡫࠺ࠨࠩ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if not z6PX2p7diaskQElBOvMRNcHwqG5D: return Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡐࡕࡋࡅࡍࡊࡁࠨࠪ"),[],[]
		download = z6PX2p7diaskQElBOvMRNcHwqG5D[D2D96X5NGamBhrFwvL8VEbqiSfZIl][D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[D2D96X5NGamBhrFwvL8VEbqiSfZIl][BkM54Kr7Qbqn]
		items = EcQxOa3RJm86WjTKA.findall(wdftVMyzF17cYETHu(u"ࠬ࡬ࡩ࡭ࡧ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠬ࠱ࡲࡡࡣࡧ࡯࠾ࠧ࠴ࠪࡀࠤࡿ࠭ࠬࠫ"),wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		JJVg3pG9Eayr5CAn,WFlpmsYGKNy,m06mELslRjhekXGW,XoSyx7p6dqZ1CF8,eUGLdJn8KYqAcpDt = [],[],[],[],[]
		for bigdh7fpZYl4aT2keV,title in items:
			if FmYoGejTnwKME7d9zPc(u"࠭࠮࡮࠵ࡸ࠼ࠬࠬ") in bigdh7fpZYl4aT2keV:
				JJVg3pG9Eayr5CAn,m06mELslRjhekXGW = kDKwn73e02jNdRLG8U4HxTgpVQqI(BfWYUAnyg6eONLjiuE,bigdh7fpZYl4aT2keV)
				XoSyx7p6dqZ1CF8 = XoSyx7p6dqZ1CF8 + m06mELslRjhekXGW
				if JJVg3pG9Eayr5CAn[D2D96X5NGamBhrFwvL8VEbqiSfZIl]==V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠧ࠮࠳ࠪ࠭"): WFlpmsYGKNy.append(Hr25gta6XcqO(u"ࠨࠢึ๎ึ็ัࠡะสูࠥ࠭࠮")+s5WMHyQN4mpie(u"ࠩࡰ࠷ࡺ࠾ࠠࠨ࠯")+z6FysMQJTa2IWYdrDx7BjObwN3fE)
				else:
					for title in JJVg3pG9Eayr5CAn:
						WFlpmsYGKNy.append(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪࠤุ๐ัโำࠣาฬ฻ࠠࠨ࠰")+o1INZ3ViQqS0Uw5z6kMjbv(u"ࠫࡲ࠹ࡵ࠹ࠢࠪ࠱")+z6FysMQJTa2IWYdrDx7BjObwN3fE+ksJdoFWhxTz8Y2N7bOZE+title)
			else:
				title = title.replace(EE1jeHnIoad(u"ࠬ࠲࡬ࡢࡤࡨࡰ࠿ࠨࠧ࠲"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
				title = title.strip(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠭ࠢࠨ࠳"))
				title = EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧࠡีํีๆืࠠࠡะสูࠥ࠭࠴")+jL5CrsRwebpyDVXUc1EQP(u"ࠨࠢࡰࡴ࠹ࠦࠧ࠵")+z6FysMQJTa2IWYdrDx7BjObwN3fE+ksJdoFWhxTz8Y2N7bOZE+title
				WFlpmsYGKNy.append(title)
				XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
		bigdh7fpZYl4aT2keV = Hr25gta6XcqO(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤ࠲ࡴࡴ࡬ࡪࡰࡨࠫ࠶") + download
		FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(d9vcuo3Hy7RhAk2,bigdh7fpZYl4aT2keV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠷ࡷ࡬ࠬ࠷"))
		items = EcQxOa3RJm86WjTKA.findall(KfHAW8VGbrxi(u"ࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࡥࡶࡪࡦࡨࡳࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭ࠬࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯ࠬࠣ࠸"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		for id,hO3D6GVPY2qENv8bZWH,hash,rsptjuWoTfEn6eVxhd in items:
			title = Gcw2nelTR864XCVruO3mAFqI5a(u"ࠬࠦำ๋ำไีࠥะอๆ์็ࠤำอีࠡࠩ࠹")+sJw9QWiq1Kr0xfeVRI(u"࠭ࠠ࡮ࡲ࠷ࠤࠬ࠺")+z6FysMQJTa2IWYdrDx7BjObwN3fE+ksJdoFWhxTz8Y2N7bOZE+rsptjuWoTfEn6eVxhd.split(sJw9QWiq1Kr0xfeVRI(u"ࠧࡹࠩ࠻"))[BkM54Kr7Qbqn]
			bigdh7fpZYl4aT2keV = sJw9QWiq1Kr0xfeVRI(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࠱ࡳࡳࡲࡩ࡯ࡧ࠲ࡨࡱࡅ࡯ࡱ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡴࡸࡩࡨࠨ࡬ࡨࡂ࠭࠼")+id+Gcw2nelTR864XCVruO3mAFqI5a(u"ࠩࠩࡱࡴࡪࡥ࠾ࠩ࠽")+hO3D6GVPY2qENv8bZWH+O3OVuapf0YFjbm5oUQDg(u"ࠪࠪ࡭ࡧࡳࡩ࠿ࠪ࠾")+hash
			eUGLdJn8KYqAcpDt.append(rsptjuWoTfEn6eVxhd)
			WFlpmsYGKNy.append(title)
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
		eUGLdJn8KYqAcpDt = set(eUGLdJn8KYqAcpDt)
		Bvow2nGu9HirlypOQjzR,ffo2RBKDNaJ39AdknbGMthc = [],[]
		for title in WFlpmsYGKNy:
			IerJ5GYbR9SZWl7XN8wdu2 = EcQxOa3RJm86WjTKA.findall(FgXzMs0YSDt(u"ࠦࠥ࠮࡜ࡥࠬࡻࢀࡡࡪࠪࠪࠨࠩࠦ࠿"),title+N6NGJ4vpmidqMCh7yo(u"ࠬࠬࠦࠨࡀ"),EcQxOa3RJm86WjTKA.DOTALL)
			for rsptjuWoTfEn6eVxhd in eUGLdJn8KYqAcpDt:
				if IerJ5GYbR9SZWl7XN8wdu2[D2D96X5NGamBhrFwvL8VEbqiSfZIl] in rsptjuWoTfEn6eVxhd:
					title = title.replace(IerJ5GYbR9SZWl7XN8wdu2[D2D96X5NGamBhrFwvL8VEbqiSfZIl],rsptjuWoTfEn6eVxhd.split(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠭ࡸࠨࡁ"))[BkM54Kr7Qbqn])
			Bvow2nGu9HirlypOQjzR.append(title)
		for pk6YWixXFSrDLKCnlN39w in range(len(XoSyx7p6dqZ1CF8)):
			items = EcQxOa3RJm86WjTKA.findall(KfHAW8VGbrxi(u"ࠢࠧࠨࠫ࠲࠯ࡅࠩࠩ࡞ࡧ࠮࠮ࠬࠦࠣࡂ"),Gcw2nelTR864XCVruO3mAFqI5a(u"ࠨࠨࠩࠫࡃ")+Bvow2nGu9HirlypOQjzR[pk6YWixXFSrDLKCnlN39w]+KfHAW8VGbrxi(u"ࠩࠩࠪࠬࡄ"),EcQxOa3RJm86WjTKA.DOTALL)
			ffo2RBKDNaJ39AdknbGMthc.append( [Bvow2nGu9HirlypOQjzR[pk6YWixXFSrDLKCnlN39w],XoSyx7p6dqZ1CF8[pk6YWixXFSrDLKCnlN39w],items[D2D96X5NGamBhrFwvL8VEbqiSfZIl][D2D96X5NGamBhrFwvL8VEbqiSfZIl],items[D2D96X5NGamBhrFwvL8VEbqiSfZIl][BkM54Kr7Qbqn]] )
		ffo2RBKDNaJ39AdknbGMthc = sorted(ffo2RBKDNaJ39AdknbGMthc, key=lambda om0A7VRk2HYGbaUNPSDfJCIxEv: om0A7VRk2HYGbaUNPSDfJCIxEv[XW57OCeGnFTLQbaqdrD9zM], reverse=EsCplGc5N4mBuYW0RVQt6b)
		ffo2RBKDNaJ39AdknbGMthc = sorted(ffo2RBKDNaJ39AdknbGMthc, key=lambda om0A7VRk2HYGbaUNPSDfJCIxEv: om0A7VRk2HYGbaUNPSDfJCIxEv[teaC5j4HuGDqpwcmUzJ], reverse=LhFAGlQ19zr)
		WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = [],[]
		for pk6YWixXFSrDLKCnlN39w in range(len(ffo2RBKDNaJ39AdknbGMthc)):
			WFlpmsYGKNy.append(ffo2RBKDNaJ39AdknbGMthc[pk6YWixXFSrDLKCnlN39w][D2D96X5NGamBhrFwvL8VEbqiSfZIl])
			XoSyx7p6dqZ1CF8.append(ffo2RBKDNaJ39AdknbGMthc[pk6YWixXFSrDLKCnlN39w][BkM54Kr7Qbqn])
	if len(XoSyx7p6dqZ1CF8)==D2D96X5NGamBhrFwvL8VEbqiSfZIl: return SnhLjmfeJC(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡏࡔࡊࡄࡌࡉࡇࠧࡅ"),[],[]
	return fy8iFgEkrO12NR9TWBI35sjY6qHvV,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
def ogVCkWKYnB37fQPdwSrDUAyL0tj4(url):
	V5VDwKLAYM3 = url.split(SnhLjmfeJC(u"ࠫࡄ࠭ࡆ"))
	YLKFRH6sSIrznXBg = V5VDwKLAYM3[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	headers = { oRJAfwD957WkUyBM1Ehu8m(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩࡇ") : fy8iFgEkrO12NR9TWBI35sjY6qHvV }
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(d9vcuo3Hy7RhAk2,YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Hr25gta6XcqO(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈ࠹࡙࡙ࡁࡓ࠯࠴ࡷࡹ࠭ࡈ"))
	items = EcQxOa3RJm86WjTKA.findall(KfHAW8VGbrxi(u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡸࡣ࡬ࡸ࠳࠰࠿ࡩࡴࡨࡪࡂࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠨࡉ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	url = items[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	return Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࡊ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[url]
def ItYjeluZM5OEQgJ6HyU(url):
	WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = [],[]
	headers = { V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ࡋ") : fy8iFgEkrO12NR9TWBI35sjY6qHvV }
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ggjO5CrKVRPITaesWkxD(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡅࡘࡐ࡙࡟ࡂࡐࡑࡎࡗ࠲࠷ࡳࡵࠩࡌ"))
	YLKFRH6sSIrznXBg = EcQxOa3RJm86WjTKA.findall(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠫࡷ࡫ࡤࡪࡴࡨࡧࡹࡥࡵࡳ࡮࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࡍ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if YLKFRH6sSIrznXBg: return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[YLKFRH6sSIrznXBg[D2D96X5NGamBhrFwvL8VEbqiSfZIl]]
	else: return C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡃࡗ࡝࡞࡛ࡘࡌࠨࡎ"),[],[]
def egYth197Mnz60dWuvlUjq4D(url):
	WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = [],[]
	headers = { N6NGJ4vpmidqMCh7yo(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪࡏ") : fy8iFgEkrO12NR9TWBI35sjY6qHvV }
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,aOQTKXFL54Nl60Zhp3MbE(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡉࡕࡍࡖ࡜ࡆࡔࡕࡋࡔ࠯࠴ࡷࡹ࠭ࡐ"))
	YLKFRH6sSIrznXBg = EcQxOa3RJm86WjTKA.findall(O3OVuapf0YFjbm5oUQDg(u"ࠨࡪࡵࡩ࡫ࠨࠬࠣࠪ࡫ࡸࡹ࠴ࠪࡀࠫࠥࠫࡑ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if YLKFRH6sSIrznXBg: return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[YLKFRH6sSIrznXBg[D2D96X5NGamBhrFwvL8VEbqiSfZIl]]
	else: return PlpyFa9QMKXxOD1cvHzmI(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡇࡃࡖࡎࡗ࡝ࡇࡕࡏࡌࡕࠪࡒ"),[],[]
def XgkoxRdncr(url):
	WFlpmsYGKNy,XoSyx7p6dqZ1CF8,errno = [],[],fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if sJw9QWiq1Kr0xfeVRI(u"ࠪ࠳ࡼࡶ࠭ࡢࡦࡰ࡭ࡳ࠵ࠧࡓ") in url:
		YLKFRH6sSIrznXBg,gWBLDSlZGwqxHT = lNyxXsMAcYHBUDh4dJbfTWR(url)
		naBFTDfp6lmKjeOywg87IAcb = {OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪࡔ"):ssynAg0zhSkoCpOMDV9(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬࡕ")}
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,FgXzMs0YSDt(u"࠭ࡐࡐࡕࡗࠫࡖ"),YLKFRH6sSIrznXBg,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳࠲࡯ࡦࠪࡗ"))
		soEymUvkt19PQXVjzKau6x5 = E6ECvznP9m5sWFMu.content
		if soEymUvkt19PQXVjzKau6x5.startswith(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠨࡪࡷࡸࡵ࠭ࡘ")): YLKFRH6sSIrznXBg = soEymUvkt19PQXVjzKau6x5
		else:
			MYWwFs7XA2 = EcQxOa3RJm86WjTKA.findall(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠩࠪࠫࡸࡸࡣ࠾࡝ࠪࠦࡢ࠮࠮ࠫࡁࠬ࡟ࠬࠨ࡝ࠨ࡙ࠩࠪ"),soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
			if MYWwFs7XA2:
				YLKFRH6sSIrznXBg = MYWwFs7XA2[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
				MYWwFs7XA2 = EcQxOa3RJm86WjTKA.findall(ssynAg0zhSkoCpOMDV9(u"ࠪࡷࡴࡻࡲࡤࡧࡀࠬ࠳࠰࠿ࠪ࡝ࠩࠨࡢ࡚࠭"),YLKFRH6sSIrznXBg,EcQxOa3RJm86WjTKA.DOTALL)
				if MYWwFs7XA2:
					YLKFRH6sSIrznXBg = U2Z7CVFftTmLeK3nzEbQPGga(MYWwFs7XA2[D2D96X5NGamBhrFwvL8VEbqiSfZIl])
					return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[YLKFRH6sSIrznXBg]
	elif QjAINyUC7MDRq5d8e4vl9(u"ࠫ࠴ࡲࡩ࡯࡭ࡶ࠳࡛ࠬ") in url:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,QjAINyUC7MDRq5d8e4vl9(u"ࠬࡍࡅࡕࠩ࡜"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EsCplGc5N4mBuYW0RVQt6b,fy8iFgEkrO12NR9TWBI35sjY6qHvV,N6NGJ4vpmidqMCh7yo(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡏࡋࡒࡔࡊࡒ࡛࠲࠷ࡳࡵࠩ࡝"))
		soEymUvkt19PQXVjzKau6x5 = E6ECvznP9m5sWFMu.content
		if PlpyFa9QMKXxOD1cvHzmI(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ࡞") in list(E6ECvznP9m5sWFMu.headers.keys()): YLKFRH6sSIrznXBg = E6ECvznP9m5sWFMu.headers[wdftVMyzF17cYETHu(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ࡟")]
		else: YLKFRH6sSIrznXBg = EcQxOa3RJm86WjTKA.findall(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩ࡬ࡨࡂࠨ࡬ࡪࡰ࡮ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࡠ"),soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	if FmYoGejTnwKME7d9zPc(u"ࠪ࠳ࡻ࠵ࠧࡡ") in YLKFRH6sSIrznXBg or KfHAW8VGbrxi(u"ࠫ࠴࡬࠯ࠨࡢ") in YLKFRH6sSIrznXBg:
		YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg.replace(aOQTKXFL54Nl60Zhp3MbE(u"ࠬ࠵ࡦ࠰ࠩࡣ"),PlpyFa9QMKXxOD1cvHzmI(u"࠭࠯ࡢࡲ࡬࠳ࡸࡵࡵࡳࡥࡨ࠳ࠬࡤ"))
		YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg.replace(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧ࠰ࡸ࠲ࠫࡥ"),SnhLjmfeJC(u"ࠨ࠱ࡤࡴ࡮࠵ࡳࡰࡷࡵࡧࡪ࠵ࠧࡦ"))
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,uulNDCPyef78(u"ࠩࡓࡓࡘ࡚ࠧࡧ"),YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ggjO5CrKVRPITaesWkxD(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯࠶ࡶࡩ࠭ࡨ"))
		soEymUvkt19PQXVjzKau6x5 = E6ECvznP9m5sWFMu.content
		items = EcQxOa3RJm86WjTKA.findall(wdftVMyzF17cYETHu(u"ࠫࠧ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨ࡬ࡢࡤࡨࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧࡩ"),soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
		if items:
			for bigdh7fpZYl4aT2keV,title in items:
				bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.replace(QjAINyUC7MDRq5d8e4vl9(u"ࠬࡢ࡜ࠨࡪ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
				WFlpmsYGKNy.append(title)
				XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
		else:
			items = EcQxOa3RJm86WjTKA.findall(CsDcLqQUVK4YBvHFW1(u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࡫"),soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
			if items:
				bigdh7fpZYl4aT2keV = items[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
				bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.replace(Hr25gta6XcqO(u"ࠧ࡝࡞ࠪ࡬"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
				WFlpmsYGKNy.append(fy8iFgEkrO12NR9TWBI35sjY6qHvV)
				XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	else: return AAbvaXV2DQzfNHdm4U3tT(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ࡭"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[YLKFRH6sSIrznXBg]
	if len(XoSyx7p6dqZ1CF8)==D2D96X5NGamBhrFwvL8VEbqiSfZIl: return Hr25gta6XcqO(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ࡮"),[],[]
	return fy8iFgEkrO12NR9TWBI35sjY6qHvV,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
def s8f9q7bOx1(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,s5WMHyQN4mpie(u"ࠪࡋࡊ࡚ࠧ࡯"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑ࡙ࡗ࠹࡛࠭࠲ࡵࡷࠫࡰ"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	WFlpmsYGKNy,XoSyx7p6dqZ1CF8,errno = [],[],fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if vU6DxuzPwMpg(u"ࠬࡶ࡬ࡢࡻࡨࡶࡤ࡫࡭ࡣࡧࡧ࠲ࡵ࡮ࡰࠨࡱ") in url or o1INZ3ViQqS0Uw5z6kMjbv(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠵ࠧࡲ") in url:
		if wdftVMyzF17cYETHu(u"ࠧࡱ࡮ࡤࡽࡪࡸ࡟ࡦ࡯ࡥࡩࡩ࠴ࡰࡩࡲࠪࡳ") in url:
			YLKFRH6sSIrznXBg = EcQxOa3RJm86WjTKA.findall(Hr25gta6XcqO(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࡴ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
			YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		else: YLKFRH6sSIrznXBg = url
		if QjAINyUC7MDRq5d8e4vl9(u"ࠩࡰࡳࡻࡹ࠴ࡶࠩࡵ") not in YLKFRH6sSIrznXBg: return OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ࡶ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[YLKFRH6sSIrznXBg]
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,N6NGJ4vpmidqMCh7yo(u"ࠫࡌࡋࡔࠨࡷ"),YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒ࡚ࡘ࠺ࡕ࠮࠴ࡱࡨࠬࡸ"))
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall(SnhLjmfeJC(u"࠭ࡩࡥ࠿ࠥࡴࡱࡧࡹࡦࡴࠥࠬ࠳࠰࠿ࠪࡸ࡬ࡨࡪࡵࡪࡴࠩࡹ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		items = EcQxOa3RJm86WjTKA.findall(o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧ࠽ࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡮ࡤࡦࡪࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࡺ"),wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if items:
			for bigdh7fpZYl4aT2keV,ffWgMXo20Hb5xurkdNqa in items:
				WFlpmsYGKNy.append(ffWgMXo20Hb5xurkdNqa)
				XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	elif Gcw2nelTR864XCVruO3mAFqI5a(u"ࠨ࡯ࡤ࡭ࡳࡥࡰ࡭ࡣࡼࡩࡷ࠴ࡰࡩࡲࠪࡻ") in url:
		YLKFRH6sSIrznXBg = EcQxOa3RJm86WjTKA.findall(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠩࡸࡶࡱࡃࠨ࠯ࠬࡂ࠭ࠧ࠭ࡼ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,aOQTKXFL54Nl60Zhp3MbE(u"ࠪࡋࡊ࡚ࠧࡽ"),YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑ࡙ࡗ࠹࡛࠭࠴ࡴࡧࠫࡾ"))
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		MYWwFs7XA2 = EcQxOa3RJm86WjTKA.findall(o1INZ3ViQqS0Uw5z6kMjbv(u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧࡿ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		MYWwFs7XA2 = MYWwFs7XA2[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		WFlpmsYGKNy.append(fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		XoSyx7p6dqZ1CF8.append(MYWwFs7XA2)
	elif PlpyFa9QMKXxOD1cvHzmI(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࡠ࡮࡬ࡲࡰ࠭ࢀ") in url:
		YLKFRH6sSIrznXBg = EcQxOa3RJm86WjTKA.findall(FgXzMs0YSDt(u"ࠧ࠽ࡥࡨࡲࡹ࡫ࡲ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪࢁ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if YLKFRH6sSIrznXBg:
			YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			return FgXzMs0YSDt(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࢂ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[YLKFRH6sSIrznXBg]
	if len(XoSyx7p6dqZ1CF8)==D2D96X5NGamBhrFwvL8VEbqiSfZIl: return N6NGJ4vpmidqMCh7yo(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡖࡔ࠶ࡘࠫࢃ"),[],[]
	return fy8iFgEkrO12NR9TWBI35sjY6qHvV,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
def rzahyA67v3(url):
	if uulNDCPyef78(u"ࠪࡃ࡬࡫ࡴ࠾ࠩࢄ") in url:
		bigdh7fpZYl4aT2keV = url.split(PlpyFa9QMKXxOD1cvHzmI(u"ࠫࡄ࡭ࡥࡵ࠿ࠪࢅ"),BkM54Kr7Qbqn)[BkM54Kr7Qbqn]
		bigdh7fpZYl4aT2keV = JNfHYgOdP9aR.b64decode(bigdh7fpZYl4aT2keV)
		if jTDWgftK7NEmx0JAkOn2aRIvweq: bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.decode(Tk9eH2qw6Brsuhj,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬࢆ"))
		return Gcw2nelTR864XCVruO3mAFqI5a(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࢇ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
	website = I4t9qonjrm.SITESURLS[EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩ࢈")][D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	headers = {OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩࢉ"):website}
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠩࡊࡉ࡙࠭ࢊ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,vU6DxuzPwMpg(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡇࡑ࡛ࡂ࠮࠴ࡱࡨࠬࢋ"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(url,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠫࡺࡸ࡬ࠨࢌ"))
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(oRJAfwD957WkUyBM1Ehu8m(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠽࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩࢍ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨࡳࡰࡷࡵࡧࡪࡹ࠺ࠡ࡞࡞ࠫ࠭࠴ࠪࡀࠫࠪࠦࢎ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(uulNDCPyef78(u"ࠢࡧ࡫࡯ࡩ࠿࠭ࠨ࠯ࠬࡂ࠭ࠬࠨ࢏"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if bigdh7fpZYl4aT2keV:
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl]+aOQTKXFL54Nl60Zhp3MbE(u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ࢐")+website
		return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
	if ggjO5CrKVRPITaesWkxD(u"ࠩࡱࡥࡲ࡫࠽࡚ࠣࡷࡳࡰ࡫࡮ࠣࠩ࢑") in FGRX4myP68S:
		Mz86a7FS9o1 = EcQxOa3RJm86WjTKA.findall(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠪࡲࡦࡳࡥ࠾ࠤ࡛ࡸࡴࡱࡥ࡯ࠤࠣࡧࡴࡴࡴࡦࡰࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ࢒"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if Mz86a7FS9o1:
			bigdh7fpZYl4aT2keV = Mz86a7FS9o1[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			bigdh7fpZYl4aT2keV = JNfHYgOdP9aR.b64decode(bigdh7fpZYl4aT2keV)
			if jTDWgftK7NEmx0JAkOn2aRIvweq: bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.decode(Tk9eH2qw6Brsuhj,aOQTKXFL54Nl60Zhp3MbE(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫ࢓"))
			bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(jL5CrsRwebpyDVXUc1EQP(u"ࠬ࡮ࡴࡵࡲ࠱࠮ࡄ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩ࠭ࠩ࢔"),bigdh7fpZYl4aT2keV,EcQxOa3RJm86WjTKA.DOTALL)
			if bigdh7fpZYl4aT2keV:
				bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl]+ssynAg0zhSkoCpOMDV9(u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ࢕")+website
				return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
	return Gcw2nelTR864XCVruO3mAFqI5a(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ࢖"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[url]
def TdGAwqzt94(url,V6gGYKEO8UqQZ):
	paJKP0Usbeju4liH,hFzEyHWOoRxG = [],[]
	if wdftVMyzF17cYETHu(u"ࠨ࠱࠴࠳ࠬࢗ") in url:
		bigdh7fpZYl4aT2keV = url.replace(aOQTKXFL54Nl60Zhp3MbE(u"ࠩ࠲࠵࠴࠭࢘"),EE1jeHnIoad(u"ࠪ࠳࠹࠵࢙ࠧ"))
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,N6NGJ4vpmidqMCh7yo(u"ࠫࡌࡋࡔࠨ࢚"),bigdh7fpZYl4aT2keV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LhFAGlQ19zr,fy8iFgEkrO12NR9TWBI35sjY6qHvV,FgXzMs0YSDt(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰࠵ࡸࡺ࢛ࠧ"))
		soEymUvkt19PQXVjzKau6x5 = E6ECvznP9m5sWFMu.content
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall(wdftVMyzF17cYETHu(u"࠭࠼ࡷ࡫ࡧࡩࡴ࠮࠮ࠫࡁࠬࡀ࠴ࡼࡩࡥࡧࡲࡂࠬ࢜"),soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			items = EcQxOa3RJm86WjTKA.findall(FmYoGejTnwKME7d9zPc(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴ࡫ࡽࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭࢝"),wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,OOnVxtP0TNWsci6HrEGqBm9boKF7g in items:
				if bigdh7fpZYl4aT2keV not in hFzEyHWOoRxG:
					hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
					A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,aOQTKXFL54Nl60Zhp3MbE(u"ࠨࡰࡤࡱࡪ࠭࢞"))
					paJKP0Usbeju4liH.append(A8ECQ0qwTRzPifOGW76FK35uUvhe+OOiSqkBcMPptI+OOnVxtP0TNWsci6HrEGqBm9boKF7g)
			return fy8iFgEkrO12NR9TWBI35sjY6qHvV,paJKP0Usbeju4liH,hFzEyHWOoRxG
	elif V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠩ࠲ࡨ࠴࠭࢟") in url:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,KfHAW8VGbrxi(u"ࠪࡋࡊ࡚ࠧࢠ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,jL5CrsRwebpyDVXUc1EQP(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠵ࡲࡩ࠭ࢡ"))
		soEymUvkt19PQXVjzKau6x5 = E6ECvznP9m5sWFMu.content
		bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(FgXzMs0YSDt(u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࢢ"),soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
		if bigdh7fpZYl4aT2keV:
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl].replace(PlpyFa9QMKXxOD1cvHzmI(u"࠭࠯࠲࠱ࠪࢣ"),CsDcLqQUVK4YBvHFW1(u"ࠧ࠰࠶࠲ࠫࢤ"))
			E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨࡉࡈࡘࠬࢥ"),bigdh7fpZYl4aT2keV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LhFAGlQ19zr,fy8iFgEkrO12NR9TWBI35sjY6qHvV,O3OVuapf0YFjbm5oUQDg(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠴ࡴࡧࠫࢦ"))
			soEymUvkt19PQXVjzKau6x5 = E6ECvznP9m5sWFMu.content
			bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(FmYoGejTnwKME7d9zPc(u"ࠪࡧࡱࡧࡳࡴ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪࢧ"),soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
			if bigdh7fpZYl4aT2keV: return o1INZ3ViQqS0Uw5z6kMjbv(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧࢨ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl]]
	elif sJw9QWiq1Kr0xfeVRI(u"ࠬ࠵ࡲࡰ࡮ࡨ࠳ࠬࢩ") in url:
		headers = {LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧࢪ"):V6gGYKEO8UqQZ}
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,CsDcLqQUVK4YBvHFW1(u"ࠧࡈࡇࡗࠫࢫ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,LhFAGlQ19zr,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CsDcLqQUVK4YBvHFW1(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳࠴ࡵࡪࠪࢬ"))
		bigdh7fpZYl4aT2keV = E6ECvznP9m5sWFMu.headers[o1INZ3ViQqS0Uw5z6kMjbv(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫࢭ")]
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠪࡋࡊ࡚ࠧࢮ"),bigdh7fpZYl4aT2keV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,vU6DxuzPwMpg(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠸ࡸ࡭࠭ࢯ"))
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		OK2mcs7f1ekzACupF,paJKP0Usbeju4liH,hFzEyHWOoRxG = dkPIfFASa2eDUGEmiLJ5BNVZH9u(bigdh7fpZYl4aT2keV,FGRX4myP68S)
		return OK2mcs7f1ekzACupF,paJKP0Usbeju4liH,hFzEyHWOoRxG
	elif s5WMHyQN4mpie(u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠰ࠩࢰ") in url:
		YLKFRH6sSIrznXBg = url.replace(wdftVMyzF17cYETHu(u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࠪࢱ"),ggjO5CrKVRPITaesWkxD(u"ࠧ࠰ࡵࡦࡶ࡮ࡶࡴ࠰ࠩࢲ"))
		naBFTDfp6lmKjeOywg87IAcb = {FmYoGejTnwKME7d9zPc(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩࢳ"):V6gGYKEO8UqQZ}
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,SnhLjmfeJC(u"ࠩࡊࡉ࡙࠭ࢴ"),YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,naBFTDfp6lmKjeOywg87IAcb,LhFAGlQ19zr,fy8iFgEkrO12NR9TWBI35sjY6qHvV,aOQTKXFL54Nl60Zhp3MbE(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠸ࡷ࡬ࠬࢵ"))
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(QjAINyUC7MDRq5d8e4vl9(u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬࢶ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if bigdh7fpZYl4aT2keV:
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,sJw9QWiq1Kr0xfeVRI(u"ࠬࡍࡅࡕࠩࢷ"),bigdh7fpZYl4aT2keV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,naBFTDfp6lmKjeOywg87IAcb,LhFAGlQ19zr,fy8iFgEkrO12NR9TWBI35sjY6qHvV,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠴࠱࠼ࡺࡨࠨࢸ"))
			FGRX4myP68S = E6ECvznP9m5sWFMu.content
			if Gcw2nelTR864XCVruO3mAFqI5a(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩࢹ") in list(E6ECvznP9m5sWFMu.headers.keys()):
				bigdh7fpZYl4aT2keV = E6ECvznP9m5sWFMu.headers[sJw9QWiq1Kr0xfeVRI(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪࢺ")]
				E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,EE1jeHnIoad(u"ࠩࡊࡉ࡙࠭ࢻ"),bigdh7fpZYl4aT2keV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,naBFTDfp6lmKjeOywg87IAcb,LhFAGlQ19zr,fy8iFgEkrO12NR9TWBI35sjY6qHvV,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠺ࡷ࡬ࠬࢼ"))
				FGRX4myP68S = E6ECvznP9m5sWFMu.content
				OK2mcs7f1ekzACupF,paJKP0Usbeju4liH,hFzEyHWOoRxG = dkPIfFASa2eDUGEmiLJ5BNVZH9u(bigdh7fpZYl4aT2keV,FGRX4myP68S)
				if hFzEyHWOoRxG: return OK2mcs7f1ekzACupF,paJKP0Usbeju4liH,hFzEyHWOoRxG
			elif QjAINyUC7MDRq5d8e4vl9(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠲ࡵ࡮ࡰࡀ࡫ࡧࡁࠬࢽ") in bigdh7fpZYl4aT2keV:
				bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.replace(PlpyFa9QMKXxOD1cvHzmI(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠳ࡶࡨࡱࡁ࡬ࡨࡂ࠭ࢾ"),wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭࠯࡫ࡹࡳࡰࡦࡿࡥࡳ࠰ࡳ࡬ࡵࡅࡩࡥ࠿ࠪࢿ"))
				return O3OVuapf0YFjbm5oUQDg(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪࣀ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
	else: return QjAINyUC7MDRq5d8e4vl9(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࣁ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[url]
	return s5WMHyQN4mpie(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭ࣂ"),[],[]
def xEU5ZyWqcL(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,sJw9QWiq1Kr0xfeVRI(u"ࠪࡋࡊ࡚ࠧࣃ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EE1jeHnIoad(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠴࠯࠴ࡷࡹ࠭ࣄ"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	data = EcQxOa3RJm86WjTKA.findall(CsDcLqQUVK4YBvHFW1(u"ࠬࠨࡡࡤࡶ࡬ࡳࡳࠨ࠮ࠫࡁࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࣅ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if data:
		rVosUJbwvXgcl,id,mv8nB7W9YtpMTLHo = data[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		data = Hr25gta6XcqO(u"࠭࡯ࡱ࠿ࠪࣆ")+rVosUJbwvXgcl+wdftVMyzF17cYETHu(u"ࠧࠧ࡫ࡧࡁࠬࣇ")+id+QjAINyUC7MDRq5d8e4vl9(u"ࠨࠨࡩࡲࡦࡳࡥ࠾ࠩࣈ")+mv8nB7W9YtpMTLHo
		headers = {OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨࣉ"):ssynAg0zhSkoCpOMDV9(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ࣊")}
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,EE1jeHnIoad(u"ࠫࡕࡕࡓࡕࠩ࣋"),url,data,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,SnhLjmfeJC(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠵࠰࠶ࡳࡪࠧ࣌"))
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠭ࠢࡳࡧࡩࡩࡷ࡫ࡲࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ࣍"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if bigdh7fpZYl4aT2keV: return LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ࣎"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl]]
	return V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡌ࡟ࡂࡆࡕࡗ࠵࣏ࠬ"),[],[]
def vahkltGD8L(url):
	headers = {EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬࣐ࠬ"):FgXzMs0YSDt(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷ࣑ࠫ")}
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,PlpyFa9QMKXxOD1cvHzmI(u"ࠫࡌࡋࡔࠨ࣒"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Hr25gta6XcqO(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠶࠰࠵ࡸࡺ࣓ࠧ"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(SnhLjmfeJC(u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࣔ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if bigdh7fpZYl4aT2keV:
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl].replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		return FgXzMs0YSDt(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪࣕ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
	return jL5CrsRwebpyDVXUc1EQP(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬࣖ"),[],[]
def MhgF6jcSCt(url):
	YLKFRH6sSIrznXBg = url.split(s5WMHyQN4mpie(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪࣗ"),BkM54Kr7Qbqn)[D2D96X5NGamBhrFwvL8VEbqiSfZIl].strip(vU6DxuzPwMpg(u"ࠪࡃࠬࣘ")).strip(AAbvaXV2DQzfNHdm4U3tT(u"ࠫ࠴࠭ࣙ")).strip(I18uSKaWhgTBeYUPD4sr(u"ࠬࠬࠧࣚ"))
	WFlpmsYGKNy,XoSyx7p6dqZ1CF8,items,MYWwFs7XA2 = [],[],[],fy8iFgEkrO12NR9TWBI35sjY6qHvV
	headers = { Hr25gta6XcqO(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪࣛ"):QjAINyUC7MDRq5d8e4vl9(u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢ࡭ࡳ࠼࠴࠼ࠢࡻ࠺࠹࠯ࠧࣜ") }
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠨࡉࡈࡘࠬࣝ"),YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,EsCplGc5N4mBuYW0RVQt6b,fy8iFgEkrO12NR9TWBI35sjY6qHvV,aOQTKXFL54Nl60Zhp3MbE(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠳࠱ࡴࡶࠪࣞ"))
	if LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬࣟ") in list(E6ECvznP9m5sWFMu.headers.keys()): MYWwFs7XA2 = E6ECvznP9m5sWFMu.headers[EE1jeHnIoad(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭࣠")]
	if LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠬ࡮ࡴࡵࡲࠪ࣡") in MYWwFs7XA2:
		if Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ࣢") in url: MYWwFs7XA2 = MYWwFs7XA2.replace(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧ࠰ࡨ࠲ࣣࠫ"),N6NGJ4vpmidqMCh7yo(u"ࠨ࠱ࡹ࠳ࠬࣤ"))
		Qj9Dd1cmPae8V3fxEKgArbuJ0 = YLKFRH6sSIrznXBg.split(jL5CrsRwebpyDVXUc1EQP(u"ࠩࡂࡔࡍࡖࡓࡊࡆࡀࠫࣥ"))[BkM54Kr7Qbqn]
		headers = { FgXzMs0YSDt(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࣦࠧ"):headers[KfHAW8VGbrxi(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨࣧ")] , C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬࣨ"):FmYoGejTnwKME7d9zPc(u"࠭ࡐࡉࡒࡖࡍࡉࡃࣩࠧ")+Qj9Dd1cmPae8V3fxEKgArbuJ0 }
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,EE1jeHnIoad(u"ࠧࡈࡇࡗࠫ࣪"),MYWwFs7XA2,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,LhFAGlQ19zr,fy8iFgEkrO12NR9TWBI35sjY6qHvV,oRJAfwD957WkUyBM1Ehu8m(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ࣫"))
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		if EE1jeHnIoad(u"ࠩ࠲ࡪ࠴࠭࣬") in MYWwFs7XA2: items = EcQxOa3RJm86WjTKA.findall(QjAINyUC7MDRq5d8e4vl9(u"ࠪࡀ࡭࠸࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅ࣭ࠩࠣࠩ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		elif FmYoGejTnwKME7d9zPc(u"ࠫ࠴ࡼ࠯ࠨ࣮") in MYWwFs7XA2: items = EcQxOa3RJm86WjTKA.findall(ggjO5CrKVRPITaesWkxD(u"ࠬ࡯ࡤ࠾ࠤࡹ࡭ࡩ࡫࡯ࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅ࣯ࠩࠣࠩ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if items: return [],[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[ items[D2D96X5NGamBhrFwvL8VEbqiSfZIl] ]
		elif jL5CrsRwebpyDVXUc1EQP(u"࠭࠼ࡩ࠳ࡁ࠸࠵࠺࠼࠰ࡪ࠴ࡂࣰࠬ") in FGRX4myP68S:
			return s5WMHyQN4mpie(u"ࠧࡆࡴࡵࡳࡷࡀࠠิ์ิๅึࠦวๅใํำ๏๎ࠠโ์๊ࠤาาศุࠡาࠤ่๎ฯฺ๋๋้ࠢีั่่๊ࠢࠥอไฦ่อี๋ะࠠศๆัหฺฯࠠษๅࣱࠪ"),[],[]
	else: return QjAINyUC7MDRq5d8e4vl9(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡌ࡟ࡂࡆࡕࡗࣲࠫ"),[],[]
def CLOU4duzvl(bigdh7fpZYl4aT2keV):
	V5VDwKLAYM3 = EcQxOa3RJm86WjTKA.findall(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠩࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫࣳ"),bigdh7fpZYl4aT2keV+wdftVMyzF17cYETHu(u"ࠪࠪࠫ࠭ࣴ"),EcQxOa3RJm86WjTKA.DOTALL|EcQxOa3RJm86WjTKA.IGNORECASE)
	pl3chZdq7I,cTUQ5iedtAwZgpqhHI3NsoLWaP = V5VDwKLAYM3[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	url = sJw9QWiq1Kr0xfeVRI(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡥࡳ࡫ࡨࡷ࠹ࡽࡡࡵࡥ࡫࠲ࡳ࡫ࡴ࠰ࡣ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶࡄࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡶࡩࡷࡼࡥࡳࠨࡢࡴࡴࡹࡴࡠ࡫ࡧࡁࠬࣵ")+pl3chZdq7I+Hr25gta6XcqO(u"ࠬࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࣶࠩ")+cTUQ5iedtAwZgpqhHI3NsoLWaP
	headers = { sJw9QWiq1Kr0xfeVRI(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪࣷ"):fy8iFgEkrO12NR9TWBI35sjY6qHvV , AAbvaXV2DQzfNHdm4U3tT(u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪࣸ"):CsDcLqQUVK4YBvHFW1(u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࣹࠩ") }
	YLKFRH6sSIrznXBg = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(d9vcuo3Hy7RhAk2,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Hr25gta6XcqO(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱࠶ࡹࡴࠨࣺ"))
	return SnhLjmfeJC(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ࣻ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[YLKFRH6sSIrznXBg]
def p1rgUFG2s4(url):
	A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(url,sJw9QWiq1Kr0xfeVRI(u"ࠫࡺࡸ࡬ࠨࣼ"))
	naBFTDfp6lmKjeOywg87IAcb = {Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ࣽ"):A8ECQ0qwTRzPifOGW76FK35uUvhe,aOQTKXFL54Nl60Zhp3MbE(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨࣾ"):wdftVMyzF17cYETHu(u"ࠧࡨࡼ࡬ࡴ࠱ࠦࡤࡦࡨ࡯ࡥࡹ࡫ࠧࣿ")}
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(D1KfvmcCjGYbgSoyX,N6NGJ4vpmidqMCh7yo(u"ࠨࡉࡈࡘࠬऀ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,naBFTDfp6lmKjeOywg87IAcb,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ssynAg0zhSkoCpOMDV9(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓ࡙ࡄࡋࡐࡅ࠲࠷ࡳࡵࠩँ"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪࡴࡱࡧࡹࡦࡴ࠱ࡵࡺࡧ࡬ࡪࡶࡼࡷࡪࡲࡥࡤࡶࡲࡶ࠭࠴ࠪࡀࠫࡩࡳࡷࡳࡡࡵࡵ࠽ࠫं"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	YLKFRH6sSIrznXBg = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		items = EcQxOa3RJm86WjTKA.findall(ggjO5CrKVRPITaesWkxD(u"ࠫ࡫ࡵࡲ࡮ࡣࡷ࠾ࠥࡢࠧࠩ࡞ࡧ࠲࠯ࡅࠩ࡝ࠩ࠯ࠤࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪः"),wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = [],[]
		for title,bigdh7fpZYl4aT2keV in items:
			WFlpmsYGKNy.append(title)
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
		if len(XoSyx7p6dqZ1CF8)==BkM54Kr7Qbqn: YLKFRH6sSIrznXBg = XoSyx7p6dqZ1CF8[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		elif len(XoSyx7p6dqZ1CF8)>BkM54Kr7Qbqn:
			yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S(CsDcLqQUVK4YBvHFW1(u"ࠬษฮหำࠣห้๋ไโࠢส่๊์วิสࠪऄ"), WFlpmsYGKNy)
			if yNqzFDjKM0SrO==-BkM54Kr7Qbqn: return s5WMHyQN4mpie(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫअ"),[],[]
			YLKFRH6sSIrznXBg = XoSyx7p6dqZ1CF8[yNqzFDjKM0SrO]
	else:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall(wdftVMyzF17cYETHu(u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬआ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D: YLKFRH6sSIrznXBg = z6PX2p7diaskQElBOvMRNcHwqG5D[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	if not YLKFRH6sSIrznXBg: return AAbvaXV2DQzfNHdm4U3tT(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑ࡞ࡉࡉࡎࡃࠪइ"),[],[]
	return jL5CrsRwebpyDVXUc1EQP(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬई"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[YLKFRH6sSIrznXBg]
def CAvwQ0mxPBbXqziK2t3SU(url):
	A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(url,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠪࡹࡷࡲࠧउ"))
	naBFTDfp6lmKjeOywg87IAcb = {Hr25gta6XcqO(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬऊ"):A8ECQ0qwTRzPifOGW76FK35uUvhe,jL5CrsRwebpyDVXUc1EQP(u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡋ࡮ࡤࡱࡧ࡭ࡳ࡭ࠧऋ"):aOQTKXFL54Nl60Zhp3MbE(u"࠭ࡧࡻ࡫ࡳ࠰ࠥࡪࡥࡧ࡮ࡤࡸࡪ࠭ऌ")}
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(D1KfvmcCjGYbgSoyX,I18uSKaWhgTBeYUPD4sr(u"ࠧࡈࡇࡗࠫऍ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,naBFTDfp6lmKjeOywg87IAcb,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡋࡃࡊࡏࡄ࠱࠶ࡹࡴࠨऎ"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall(Hr25gta6XcqO(u"ࠩࡳࡰࡦࡿࡥࡳ࠰ࡴࡹࡦࡲࡩࡵࡻࡶࡩࡱ࡫ࡣࡵࡱࡵࠬ࠳࠰࠿ࠪࡨࡲࡶࡲࡧࡴࡴ࠼ࠪए"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	YLKFRH6sSIrznXBg = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		items = EcQxOa3RJm86WjTKA.findall(vU6DxuzPwMpg(u"ࠪࡪࡴࡸ࡭ࡢࡶ࠽ࠤࡡ࠭ࠨ࡝ࡦ࠱࠮ࡄ࠯࡜ࠨ࠮ࠣࡷࡷࡩ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩऐ"),wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = [],[]
		for title,bigdh7fpZYl4aT2keV in items:
			WFlpmsYGKNy.append(title)
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
		if len(XoSyx7p6dqZ1CF8)==BkM54Kr7Qbqn: YLKFRH6sSIrznXBg = XoSyx7p6dqZ1CF8[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		elif len(XoSyx7p6dqZ1CF8)>BkM54Kr7Qbqn:
			yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S(N6NGJ4vpmidqMCh7yo(u"ࠫศิสาࠢส่๊๊แࠡษ็้๋อำษࠩऑ"), WFlpmsYGKNy)
			if yNqzFDjKM0SrO==-BkM54Kr7Qbqn: return Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪऒ"),[],[]
			YLKFRH6sSIrznXBg = XoSyx7p6dqZ1CF8[yNqzFDjKM0SrO]
	if not YLKFRH6sSIrznXBg:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall(PlpyFa9QMKXxOD1cvHzmI(u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫओ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D: YLKFRH6sSIrznXBg = z6PX2p7diaskQElBOvMRNcHwqG5D[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	if not YLKFRH6sSIrznXBg: return C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡚ࠢࡉࡈࡏࡍࡂࠩऔ"),[],[]
	return FgXzMs0YSDt(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫक"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[YLKFRH6sSIrznXBg]
def yyT9dmoRwD(bigdh7fpZYl4aT2keV):
	V5VDwKLAYM3 = EcQxOa3RJm86WjTKA.findall(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠩࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࡡࡅࡰࡰࡵࡷ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࠦࠨख"),bigdh7fpZYl4aT2keV+SnhLjmfeJC(u"ࠪࠪࠫ࠭ग"),EcQxOa3RJm86WjTKA.DOTALL)
	url,pl3chZdq7I,cTUQ5iedtAwZgpqhHI3NsoLWaP = V5VDwKLAYM3[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	data = {Hr25gta6XcqO(u"ࠫࡵࡵࡳࡵࡡ࡬ࡨࠬघ"):pl3chZdq7I,EE1jeHnIoad(u"ࠬࡹࡥࡳࡸࡨࡶࠬङ"):cTUQ5iedtAwZgpqhHI3NsoLWaP}
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,FmYoGejTnwKME7d9zPc(u"࠭ࡐࡐࡕࡗࠫच"),url,data,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,PlpyFa9QMKXxOD1cvHzmI(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎࡅࡄࡑ࠲࠷ࡳࡵࠩछ"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	YLKFRH6sSIrznXBg = EcQxOa3RJm86WjTKA.findall(sIzDXlTHYUC5L3xZGnr(u"ࠨ࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ज"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	return LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬझ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[YLKFRH6sSIrznXBg]
def oeDTz7nWbL(url):
	bigdh7fpZYl4aT2keV = url
	if V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪࡃࡸ࡫ࡲࡷ࠿ࠪञ") in url:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,sIzDXlTHYUC5L3xZGnr(u"ࠫࡌࡋࡔࠨट"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,O3OVuapf0YFjbm5oUQDg(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗ࠲࠷ࡳࡵࠩठ"))
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(vU6DxuzPwMpg(u"࠭࠼ࡪࡨࡵࡥࡲ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧड"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		else: return wdftVMyzF17cYETHu(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭ढ"),[],[]
	return jL5CrsRwebpyDVXUc1EQP(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫण"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
def N7YIE4aUZM(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,Gcw2nelTR864XCVruO3mAFqI5a(u"ࠩࡊࡉ࡙࠭त"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ssynAg0zhSkoCpOMDV9(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯࠴ࡷࡹ࠭थ"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(o1INZ3ViQqS0Uw5z6kMjbv(u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬद"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if bigdh7fpZYl4aT2keV:
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		if bigdh7fpZYl4aT2keV: return V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨध"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
	return Hr25gta6XcqO(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫन"),[],[]
def SSNfP6Evbj(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,SnhLjmfeJC(u"ࠧࡈࡇࡗࠫऩ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,uulNDCPyef78(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡅࡏ࡙ࡕ࠳࠱ࡴࡶࠪप"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(I18uSKaWhgTBeYUPD4sr(u"ࠩ࠿ࡍࡋࡘࡁࡎࡇࠣࡗࡗࡉ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨफ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	return CsDcLqQUVK4YBvHFW1(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ब"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
def SfjApdRFxq(url):
	uHyjkzgiAsGW5ZIb9U6TlV = VbHeOuU1ilzSp2ZRXwBD(url,aOQTKXFL54Nl60Zhp3MbE(u"ࠫࡺࡸ࡬ࠨभ"))
	if EE1jeHnIoad(u"ࠬ࡯࡮ࡥࡧࡻࡁࠬम") in url:
		headers = {sIzDXlTHYUC5L3xZGnr(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧय"):uHyjkzgiAsGW5ZIb9U6TlV}
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,ssynAg0zhSkoCpOMDV9(u"ࠧࡈࡇࡗࠫर"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,PlpyFa9QMKXxOD1cvHzmI(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠷ࡳࡵࠩऱ"))
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		YLKFRH6sSIrznXBg = EcQxOa3RJm86WjTKA.findall(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧल"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if YLKFRH6sSIrznXBg:
			YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			if wdftVMyzF17cYETHu(u"ࠪ࡬ࡹࡺࡰࠨळ") not in YLKFRH6sSIrznXBg: YLKFRH6sSIrznXBg = V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠫ࡭ࡺࡴࡱ࠼ࠪऴ")+YLKFRH6sSIrznXBg
			if EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭व") in YLKFRH6sSIrznXBg:
				E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭ࡇࡆࡖࠪश"),YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,I18uSKaWhgTBeYUPD4sr(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡏࡑ࡚࠱࠷ࡴࡤࠨष"))
				soEymUvkt19PQXVjzKau6x5 = E6ECvznP9m5sWFMu.content
				items = EcQxOa3RJm86WjTKA.findall(s5WMHyQN4mpie(u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡾࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧस"),soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
				if not items:
					z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠣࡠࡠ࠮࠮ࠫࡁࠬࡠࡢࡢ࠮ࠨह"),soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
					if z6PX2p7diaskQElBOvMRNcHwqG5D:
						OOCx0SzAcisQIJGM6DZkopvB3 = z6PX2p7diaskQElBOvMRNcHwqG5D[FgXzMs0YSDt(u"࠵ു")]
						items = EcQxOa3RJm86WjTKA.findall(oRJAfwD957WkUyBM1Ehu8m(u"ࠪࠦࡡࡡࠨ࠯ࠬࡂ࠭ࡡࡣࠠࠩ࠰࠭ࡃ࠮ࠨࠧऺ"),OOCx0SzAcisQIJGM6DZkopvB3,EcQxOa3RJm86WjTKA.DOTALL)
						if items:
							SY3A5GNoKpRfJZcq02,UUr86Suzdfl13PxiTweEMZyCjHcs7p = zip(*items)
							items = list(zip(UUr86Suzdfl13PxiTweEMZyCjHcs7p,SY3A5GNoKpRfJZcq02))
				WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = [],[]
				EW6mPCkSQRzH3Yw8ITFpc4nv5M = VbHeOuU1ilzSp2ZRXwBD(YLKFRH6sSIrznXBg,QjAINyUC7MDRq5d8e4vl9(u"ࠫࡺࡸ࡬ࠨऻ"))
				for bigdh7fpZYl4aT2keV,OOnVxtP0TNWsci6HrEGqBm9boKF7g in reversed(items):
					bigdh7fpZYl4aT2keV = EW6mPCkSQRzH3Yw8ITFpc4nv5M+bigdh7fpZYl4aT2keV+SnhLjmfeJC(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ़")+EW6mPCkSQRzH3Yw8ITFpc4nv5M
					WFlpmsYGKNy.append(OOnVxtP0TNWsci6HrEGqBm9boKF7g)
					XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
				return fy8iFgEkrO12NR9TWBI35sjY6qHvV,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
			else: return ssynAg0zhSkoCpOMDV9(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩऽ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[YLKFRH6sSIrznXBg]
	YLKFRH6sSIrznXBg = url+jL5CrsRwebpyDVXUc1EQP(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪा")+uHyjkzgiAsGW5ZIb9U6TlV
	if SnhLjmfeJC(u"ࠨࡪࡷࡸࡵ࠭ि") not in YLKFRH6sSIrznXBg: YLKFRH6sSIrznXBg = oRJAfwD957WkUyBM1Ehu8m(u"ࠩ࡫ࡸࡹࡶ࠺ࠨी")+YLKFRH6sSIrznXBg
	return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[YLKFRH6sSIrznXBg]
def ia2FgLdZ5r9CBbD60G(bigdh7fpZYl4aT2keV):
	uHyjkzgiAsGW5ZIb9U6TlV = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪࡹࡷࡲࠧु"))
	if PlpyFa9QMKXxOD1cvHzmI(u"ࠫࡵࡵࡳࡵ࡫ࡧࠫू") in bigdh7fpZYl4aT2keV:
		V5VDwKLAYM3 = EcQxOa3RJm86WjTKA.findall(O3OVuapf0YFjbm5oUQDg(u"ࠬ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩ࡝ࡁࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫृ"),bigdh7fpZYl4aT2keV+EE1jeHnIoad(u"࠭ࠦࠧࠩॄ"),EcQxOa3RJm86WjTKA.DOTALL)
		url,pl3chZdq7I,cTUQ5iedtAwZgpqhHI3NsoLWaP = V5VDwKLAYM3[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		data = {jL5CrsRwebpyDVXUc1EQP(u"ࠧࡪࡦࠪॅ"):pl3chZdq7I,N6NGJ4vpmidqMCh7yo(u"ࠨࡵࡨࡶࡻ࡫ࡲࠨॆ"):cTUQ5iedtAwZgpqhHI3NsoLWaP}
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,KfHAW8VGbrxi(u"ࠩࡓࡓࡘ࡚ࠧे"),url,data,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,O3OVuapf0YFjbm5oUQDg(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠲ࡵࡷࠫै"))
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		YLKFRH6sSIrznXBg = EcQxOa3RJm86WjTKA.findall(uulNDCPyef78(u"ࠫ࡮࡬ࡲࡢ࡯ࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩॉ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		if Hr25gta6XcqO(u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭ॊ") in YLKFRH6sSIrznXBg:
			headers = {EE1jeHnIoad(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧो"):uHyjkzgiAsGW5ZIb9U6TlV,KfHAW8VGbrxi(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫौ"):fy8iFgEkrO12NR9TWBI35sjY6qHvV}
			E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠨࡉࡈࡘ्ࠬ"),YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,SnhLjmfeJC(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠲࡯ࡦࠪॎ"))
			soEymUvkt19PQXVjzKau6x5 = E6ECvznP9m5sWFMu.content
			items = EcQxOa3RJm86WjTKA.findall(O3OVuapf0YFjbm5oUQDg(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࢀࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩॏ"),soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
			WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = [],[]
			EW6mPCkSQRzH3Yw8ITFpc4nv5M = VbHeOuU1ilzSp2ZRXwBD(YLKFRH6sSIrznXBg,LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠫࡺࡸ࡬ࠨॐ"))
			for bigdh7fpZYl4aT2keV,OOnVxtP0TNWsci6HrEGqBm9boKF7g in reversed(items):
				bigdh7fpZYl4aT2keV = EW6mPCkSQRzH3Yw8ITFpc4nv5M+bigdh7fpZYl4aT2keV+FgXzMs0YSDt(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ॑")+EW6mPCkSQRzH3Yw8ITFpc4nv5M
				WFlpmsYGKNy.append(OOnVxtP0TNWsci6HrEGqBm9boKF7g)
				XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
			return fy8iFgEkrO12NR9TWBI35sjY6qHvV,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
		else: return s5WMHyQN4mpie(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ॒ࠩ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[YLKFRH6sSIrznXBg]
	else:
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+N6NGJ4vpmidqMCh7yo(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ॓")+uHyjkzgiAsGW5ZIb9U6TlV
		return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
def Q0QDmxKipe(bigdh7fpZYl4aT2keV):
	if N6NGJ4vpmidqMCh7yo(u"ࠨࡲࡲࡷࡹ࡯ࡤࠨ॔") in bigdh7fpZYl4aT2keV:
		V5VDwKLAYM3 = EcQxOa3RJm86WjTKA.findall(SnhLjmfeJC(u"ࠩࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫॕ"),bigdh7fpZYl4aT2keV+aOQTKXFL54Nl60Zhp3MbE(u"ࠪࠪࠫ࠭ॖ"),EcQxOa3RJm86WjTKA.DOTALL|EcQxOa3RJm86WjTKA.IGNORECASE)
		pl3chZdq7I,cTUQ5iedtAwZgpqhHI3NsoLWaP = V5VDwKLAYM3[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		VRobjUJBgkECGnx68019i = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,KfHAW8VGbrxi(u"ࠫࡺࡸ࡬ࠨॗ"))
		url = VRobjUJBgkECGnx68019i+ssynAg0zhSkoCpOMDV9(u"ࠬ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡴࡧࡵࡺࡪࡸࠦࡠࡲࡲࡷࡹࡥࡩࡥ࠿ࠪक़")+pl3chZdq7I+oRJAfwD957WkUyBM1Ehu8m(u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪख़")+cTUQ5iedtAwZgpqhHI3NsoLWaP
		headers = { o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫग़"):fy8iFgEkrO12NR9TWBI35sjY6qHvV , I18uSKaWhgTBeYUPD4sr(u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫज़"):OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪड़") }
		YLKFRH6sSIrznXBg = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(d9vcuo3Hy7RhAk2,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,O3OVuapf0YFjbm5oUQDg(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡄࡏࡍࡔࡔ࡚࠮࠳ࡶࡸࠬढ़"))
		YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg.replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(FFkml6ZbgXD,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		return C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧफ़"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[YLKFRH6sSIrznXBg]
	elif C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬ࠵ࡲࡦࡦ࡬ࡶࡪࡩࡴ࠰ࠩय़") in bigdh7fpZYl4aT2keV:
		FdM76PmREvS0tYfyZx3eTgQw8o5I = D2D96X5NGamBhrFwvL8VEbqiSfZIl
		while wdftVMyzF17cYETHu(u"࠭࠯ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠱ࠪॠ") in bigdh7fpZYl4aT2keV and FdM76PmREvS0tYfyZx3eTgQw8o5I<vU6DxuzPwMpg(u"࠻ൂ"):
			E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,AAbvaXV2DQzfNHdm4U3tT(u"ࠧࡈࡇࡗࠫॡ"),bigdh7fpZYl4aT2keV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,aOQTKXFL54Nl60Zhp3MbE(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡂࡍࡋࡒࡒ࡟࠳࠲࡯ࡦࠪॢ"))
			if V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫॣ") in list(E6ECvznP9m5sWFMu.headers.keys()): bigdh7fpZYl4aT2keV = E6ECvznP9m5sWFMu.headers[PlpyFa9QMKXxOD1cvHzmI(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ।")]
			FdM76PmREvS0tYfyZx3eTgQw8o5I += BkM54Kr7Qbqn
		return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
	else: return Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡓࡄࡏࡍࡔࡔ࡚ࠨ॥"),[],[]
def oTXYuAvz7q(url):
	A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(url,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬࡻࡲ࡭ࠩ०"))
	headers = {aOQTKXFL54Nl60Zhp3MbE(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ१"):A8ECQ0qwTRzPifOGW76FK35uUvhe,wdftVMyzF17cYETHu(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ२"):j4lUV5BzHDI6EN()}
	if C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ३") in url:
		FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(d9vcuo3Hy7RhAk2,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ggjO5CrKVRPITaesWkxD(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠳ࡰࡧࠫ४"))
		bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(ssynAg0zhSkoCpOMDV9(u"ࠪࡀࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ५"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if bigdh7fpZYl4aT2keV:
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl].replace(oRJAfwD957WkUyBM1Ehu8m(u"ࠫ࡭ࡺࡴࡱࡵࠪ६"),Hr25gta6XcqO(u"ࠬ࡮ࡴࡵࡲࠪ७"))
			return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
	else:
		E2cPyHhV4q5n8R = TBPcjsyOYoM82pm(rrux12tcwQl5,QjAINyUC7MDRq5d8e4vl9(u"࠭ࡇࡆࡖࠪ८"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,oRJAfwD957WkUyBM1Ehu8m(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠹ࡲࡥࠩ९"))
		FGRX4myP68S = E2cPyHhV4q5n8R.content
		naBFTDfp6lmKjeOywg87IAcb = headers.copy()
		if vU6DxuzPwMpg(u"ࠨࡡ࡯ࡲࡰࡥࠧ॰") in str(E2cPyHhV4q5n8R.cookies):
			cookies = E2cPyHhV4q5n8R.cookies
			naBFTDfp6lmKjeOywg87IAcb[s5WMHyQN4mpie(u"ࠩࡆࡳࡴࡱࡩࡦࠩॱ")] = U2Z7CVFftTmLeK3nzEbQPGga(YYpHcWVqImGPU4LXM(cookies))
		bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(KfHAW8VGbrxi(u"ࠪࡰ࡮ࡴ࡫࠯ࡪࡵࡩ࡫ࠦ࠽ࠡࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠭ॲ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if not bigdh7fpZYl4aT2keV: return N6NGJ4vpmidqMCh7yo(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧॳ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[url]
		else:
			bigdh7fpZYl4aT2keV = U2Z7CVFftTmLeK3nzEbQPGga(bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl])+PlpyFa9QMKXxOD1cvHzmI(u"ࠬࠬࡤ࠾࠳ࠪॴ")
			JOB9NFKAlRSW8eyTQDPaG7 = TBPcjsyOYoM82pm(rrux12tcwQl5,sIzDXlTHYUC5L3xZGnr(u"࠭ࡇࡆࡖࠪॵ"),bigdh7fpZYl4aT2keV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,naBFTDfp6lmKjeOywg87IAcb,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠺ࡴࡩࠩॶ"))
			FGRX4myP68S = JOB9NFKAlRSW8eyTQDPaG7.content
			bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(PlpyFa9QMKXxOD1cvHzmI(u"ࠨ࡫ࡧࡁࠧࡨࡴ࡯ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫॷ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
			if bigdh7fpZYl4aT2keV:
				bigdh7fpZYl4aT2keV = U2Z7CVFftTmLeK3nzEbQPGga(bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl])
				if EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩࡰࡴ࠹࠭ॸ") in bigdh7fpZYl4aT2keV and EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪ࠳ࡩ࠵ࠧॹ") in bigdh7fpZYl4aT2keV: return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
				else: return s5WMHyQN4mpie(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧॺ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
	return O3OVuapf0YFjbm5oUQDg(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡄࡆࡘࡋࡅࡅࠩॻ"),[],[]
def drEPv43i0T(bigdh7fpZYl4aT2keV):
	if FgXzMs0YSDt(u"࠭࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡷࡪࡸࡶࡦࡴࠪॼ") in bigdh7fpZYl4aT2keV:
		headers = {C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪॽ"):ssynAg0zhSkoCpOMDV9(u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩॾ")}
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,s5WMHyQN4mpie(u"ࠩࡊࡉ࡙࠭ॿ"),bigdh7fpZYl4aT2keV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,O3OVuapf0YFjbm5oUQDg(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮࠳ࡶࡸࠬঀ"))
		url = E6ECvznP9m5sWFMu.content
		if url: return FmYoGejTnwKME7d9zPc(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧঁ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[url]
	else:
		V5VDwKLAYM3 = EcQxOa3RJm86WjTKA.findall(FmYoGejTnwKME7d9zPc(u"ࠬࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠩ࠭ং"),bigdh7fpZYl4aT2keV,EcQxOa3RJm86WjTKA.DOTALL|EcQxOa3RJm86WjTKA.IGNORECASE)
		if not V5VDwKLAYM3: V5VDwKLAYM3 = EcQxOa3RJm86WjTKA.findall(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠥࠩঃ"),bigdh7fpZYl4aT2keV,EcQxOa3RJm86WjTKA.DOTALL|EcQxOa3RJm86WjTKA.IGNORECASE)
		pl3chZdq7I,cTUQ5iedtAwZgpqhHI3NsoLWaP = V5VDwKLAYM3[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧࡶࡴ࡯ࠫ঄"))
		url = A8ECQ0qwTRzPifOGW76FK35uUvhe+wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡴࡩࡧࡰࡩ࠴ࡇࡪࡢࡺࡤࡸ࠴࡙ࡩ࡯ࡩ࡯ࡩ࠴࡙ࡥࡳࡸࡨࡶ࠳ࡶࡨࡱࠩঅ")
		data = {Hr25gta6XcqO(u"ࠩ࡬ࡨࠬআ"):pl3chZdq7I,O3OVuapf0YFjbm5oUQDg(u"ࠪ࡭ࠬই"):cTUQ5iedtAwZgpqhHI3NsoLWaP}
		headers = {I18uSKaWhgTBeYUPD4sr(u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧঈ"):wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭উ"),OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧঊ"):bigdh7fpZYl4aT2keV}
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,Gcw2nelTR864XCVruO3mAFqI5a(u"ࠧࡑࡑࡖࡘࠬঋ"),url,data,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,FmYoGejTnwKME7d9zPc(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡎࡁࡉࡋࡇ࠸࡚࠳࠲࡯ࡦࠪঌ"))
		soEymUvkt19PQXVjzKau6x5 = E6ECvznP9m5sWFMu.content
		YLKFRH6sSIrznXBg = EcQxOa3RJm86WjTKA.findall(o1INZ3ViQqS0Uw5z6kMjbv(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ঍"),soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL|EcQxOa3RJm86WjTKA.IGNORECASE)
		if YLKFRH6sSIrznXBg:
			YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			return ssynAg0zhSkoCpOMDV9(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭঎"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[YLKFRH6sSIrznXBg]
	return LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡓࡉࡃࡋࡍࡉ࠺ࡕࠨএ"),[],[]
def w5O8dKjstlEMZgTGBn6IJP19cNLq(eIqSghHr0AyK1):
	YrNCnX7AGaI9cs8 = OdiZIyCfDUsW3JBGR2VAb.getSetting(ggjO5CrKVRPITaesWkxD(u"ࠬࡧࡶ࠯ࡣ࡮ࡻࡦࡳ࠮ࡷࡧࡵ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳ࠭ঐ"))
	headers = {I18uSKaWhgTBeYUPD4sr(u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭঑"):YrNCnX7AGaI9cs8} if YrNCnX7AGaI9cs8 else fy8iFgEkrO12NR9TWBI35sjY6qHvV
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠧࡈࡇࡗࠫ঒"),eIqSghHr0AyK1,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠶ࡹࡴࠨও"))
	CN6RHLdaEDBzM9ZTyPpJcim = E6ECvznP9m5sWFMu.content
	nNZlA0QTqhPym8K = str(E6ECvznP9m5sWFMu.headers)
	rGhA6otd4O = nNZlA0QTqhPym8K+CN6RHLdaEDBzM9ZTyPpJcim
	if N6NGJ4vpmidqMCh7yo(u"ࠩ࠱ࡱࡵ࠺ࠧঔ") in rGhA6otd4O: IXlUkiwca1Yh5AQ9PNV3W2Cv4 = EsCplGc5N4mBuYW0RVQt6b
	else:
		htPWN2GJ8UiC97gjzZ6R,eDi4j5Usrp,CpEzq7Bdk0Z3n2MX4wVAlOQUf,FFjsOV62kReSQJBiXbZ7yq3lUN,IXlUkiwca1Yh5AQ9PNV3W2Cv4 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LhFAGlQ19zr
		captcha = EcQxOa3RJm86WjTKA.findall(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪࡴࡦ࡭ࡥ࠮ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠱࠮ࡄࡧࡣࡵ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡪࡶࡨ࡯ࡪࡿ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨক"),CN6RHLdaEDBzM9ZTyPpJcim,EcQxOa3RJm86WjTKA.DOTALL)
		if captcha: CpEzq7Bdk0Z3n2MX4wVAlOQUf,FFjsOV62kReSQJBiXbZ7yq3lUN = captcha[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		kLW0pVcG479RzSANEDaqvhBHTKPX = I4t9qonjrm.SITESURLS[oRJAfwD957WkUyBM1Ehu8m(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫখ")][N6NGJ4vpmidqMCh7yo(u"࠷ൃ")]
		if D2D96X5NGamBhrFwvL8VEbqiSfZIl:
			data = {FmYoGejTnwKME7d9zPc(u"ࠬࡻࡳࡦࡴࠪগ"):I4t9qonjrm.AV_CLIENT_IDS,FmYoGejTnwKME7d9zPc(u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧঘ"):KoxvjArhL1TdInDmN9s,I18uSKaWhgTBeYUPD4sr(u"ࠧࡶࡴ࡯ࠫঙ"):eIqSghHr0AyK1,ssynAg0zhSkoCpOMDV9(u"ࠨ࡭ࡨࡽࠬচ"):FFjsOV62kReSQJBiXbZ7yq3lUN,CsDcLqQUVK4YBvHFW1(u"ࠩ࡬ࡨࠬছ"):fy8iFgEkrO12NR9TWBI35sjY6qHvV,s5WMHyQN4mpie(u"ࠪ࡮ࡴࡨࠧজ"):C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠫ࡬࡫ࡴࡶࡴ࡯ࡷࠬঝ")}
			E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,aOQTKXFL54Nl60Zhp3MbE(u"ࠬࡖࡏࡔࡖࠪঞ"),kLW0pVcG479RzSANEDaqvhBHTKPX,data,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠵ࡲࡩ࠭ট"))
			FGRX4myP68S = E6ECvznP9m5sWFMu.content
		FGRX4myP68S = fy8iFgEkrO12NR9TWBI35sjY6qHvV
		if FGRX4myP68S.startswith(O3OVuapf0YFjbm5oUQDg(u"ࠧࡖࡔࡏࡗࡂ࠭ঠ")):
			tvl3Tdjo9w = LB7TcZnGYdfw5lWU1RH3Oztu9PyA(ggjO5CrKVRPITaesWkxD(u"ࠨ࡮࡬ࡷࡹ࠭ড"),FGRX4myP68S.split(LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠩࡘࡖࡑ࡙࠽ࠨঢ"),BkM54Kr7Qbqn)[BkM54Kr7Qbqn])
			for Bc7G3ur2Tw5QK1fPSkyJ in tvl3Tdjo9w:
				url = Bc7G3ur2Tw5QK1fPSkyJ[uulNDCPyef78(u"ࠪࡹࡷࡲࠧণ")]
				no84RQZzgM = Bc7G3ur2Tw5QK1fPSkyJ[aOQTKXFL54Nl60Zhp3MbE(u"ࠫࡲ࡫ࡴࡩࡱࡧࠫত")]
				data = Bc7G3ur2Tw5QK1fPSkyJ[wdftVMyzF17cYETHu(u"ࠬࡪࡡࡵࡣࠪথ")]
				headers = Bc7G3ur2Tw5QK1fPSkyJ[o1INZ3ViQqS0Uw5z6kMjbv(u"࠭ࡨࡦࡣࡧࡩࡷࡹࠧদ")]
				E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,no84RQZzgM,url,data,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ssynAg0zhSkoCpOMDV9(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠷ࡷࡪࠧধ"))
				CN6RHLdaEDBzM9ZTyPpJcim = E6ECvznP9m5sWFMu.content
				if sIzDXlTHYUC5L3xZGnr(u"ࠨ࠰ࡰࡴ࠹࠭ন") in CN6RHLdaEDBzM9ZTyPpJcim:
					IXlUkiwca1Yh5AQ9PNV3W2Cv4 = EsCplGc5N4mBuYW0RVQt6b
					break
				nNZlA0QTqhPym8K = str(E6ECvznP9m5sWFMu.headers)
				rGhA6otd4O = nNZlA0QTqhPym8K+CN6RHLdaEDBzM9ZTyPpJcim
				htPWN2GJ8UiC97gjzZ6R = EcQxOa3RJm86WjTKA.findall(Hr25gta6XcqO(u"ࠩࠫࡥࡰࡽࡡ࡮ࡘࡨࡶ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡜ࡸ࠭ࠬ࠲࠯ࡅࠢࠩࡧࡼࡎ࠳࠰࠿ࠪࠤࠪ঩"),rGhA6otd4O,EcQxOa3RJm86WjTKA.DOTALL)
				eDi4j5Usrp = EcQxOa3RJm86WjTKA.findall(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠳ࡴࡰ࡭ࡨࡲ࠳࠰࠿ࠣࠪ࠳࠷ࡆ࠴ࠪࡀࠫࠥࠫপ"),rGhA6otd4O,EcQxOa3RJm86WjTKA.DOTALL)
				if eDi4j5Usrp: eDi4j5Usrp = eDi4j5Usrp[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
				if htPWN2GJ8UiC97gjzZ6R or eDi4j5Usrp: break
		if not IXlUkiwca1Yh5AQ9PNV3W2Cv4:
			if not htPWN2GJ8UiC97gjzZ6R:
				if captcha and not eDi4j5Usrp:
					if BkM54Kr7Qbqn: eDi4j5Usrp = SalObZDeYVKXNnMH2CPdIkRB8Gc(FFjsOV62kReSQJBiXbZ7yq3lUN,s5WMHyQN4mpie(u"ࠫࡦࡸࠧফ"),eIqSghHr0AyK1)
					else:
						if not FGRX4myP68S.startswith(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠬࡏࡄ࠾ࠩব")):
							data = {KfHAW8VGbrxi(u"࠭ࡵࡴࡧࡵࠫভ"):I4t9qonjrm.AV_CLIENT_IDS,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨম"):KoxvjArhL1TdInDmN9s,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠨࡷࡵࡰࠬয"):eIqSghHr0AyK1,Hr25gta6XcqO(u"ࠩ࡮ࡩࡾ࠭র"):FFjsOV62kReSQJBiXbZ7yq3lUN,Hr25gta6XcqO(u"ࠪ࡭ࡩ࠭঱"):fy8iFgEkrO12NR9TWBI35sjY6qHvV,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠫ࡯ࡵࡢࠨল"):AAbvaXV2DQzfNHdm4U3tT(u"ࠬ࡭ࡥࡵ࡫ࡧࠫ঳")}
							E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,FgXzMs0YSDt(u"࠭ࡐࡐࡕࡗࠫ঴"),kLW0pVcG479RzSANEDaqvhBHTKPX,data,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QjAINyUC7MDRq5d8e4vl9(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠸ࡹ࡮ࠧ঵"))
							FGRX4myP68S = E6ECvznP9m5sWFMu.content
						else: FGRX4myP68S = CsDcLqQUVK4YBvHFW1(u"ࠨࡋࡇࡁ࠶࠸࠳࠵࠼࠽࠾࠿࡚ࡉࡎࡇࡒ࡙࡙ࡃ࠴࠶ࠩশ")
						if FGRX4myP68S.startswith(AAbvaXV2DQzfNHdm4U3tT(u"ࠩࡌࡈࡂ࠭ষ")):
							bGsRNOfFqWr1ePHtC48KTyjVdpm5 = EcQxOa3RJm86WjTKA.findall(SnhLjmfeJC(u"ࠪࡍࡉࡃࠨ࠯ࠬࡂ࠭࠿ࡀ࠺࠻ࡖࡌࡑࡊࡕࡕࡕ࠿ࠫ࠲࠯ࡅࠩࠥࠩস"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
							UowsE6XxP83YLpOt,TqNMvyzBUxolbKhdcRku2L74F8e = bGsRNOfFqWr1ePHtC48KTyjVdpm5[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
							kf40tulvSA7z9RqNF5dXca3seMD = N6NGJ4vpmidqMCh7yo(u"ࠫ์ึ็ࠡษ็฽๊๊๊สࠢอัฯอฬ๊ࠡๅฮ๋ࠥๆࠡ࠳࠳ࠤส๊้ࠡࠩহ")+TqNMvyzBUxolbKhdcRku2L74F8e+FgXzMs0YSDt(u"ࠬࠦหศ่ํอࠬ঺")
							ua2GNHKeh94QJSd = hieYJByqUTsF9CH7aD3()
							ua2GNHKeh94QJSd.create(FgXzMs0YSDt(u"࠭ๅฮษ๋่ฮࠦสอษ๋ึࠥ็อึࠢฦ๊ฬࠦร็ีส๊ࠥ๎ไิฬࠣฬึ์วๆฮࠣ็ํ๋ศ๋๊อีࠬ঻"),kf40tulvSA7z9RqNF5dXca3seMD)
							j6C7IM93Z2qEpfwl1kSF0HVAyR = uUqrNPcXKBoQ0slv.time()
							ppgUfvXWAdxzMhLI3wi40t1l,RNvWp0a84X1yK = D2D96X5NGamBhrFwvL8VEbqiSfZIl,D2D96X5NGamBhrFwvL8VEbqiSfZIl
							while ppgUfvXWAdxzMhLI3wi40t1l<int(TqNMvyzBUxolbKhdcRku2L74F8e):
								Hnrjh7smUIGq3RgDy19CL(ua2GNHKeh94QJSd,int(ppgUfvXWAdxzMhLI3wi40t1l/int(TqNMvyzBUxolbKhdcRku2L74F8e)*N6NGJ4vpmidqMCh7yo(u"࠲࠲࠳ൄ")),kf40tulvSA7z9RqNF5dXca3seMD,fy8iFgEkrO12NR9TWBI35sjY6qHvV,TqNMvyzBUxolbKhdcRku2L74F8e+AAbvaXV2DQzfNHdm4U3tT(u"ࠧࠡ࠱়ࠣࠫ")+str(int(ppgUfvXWAdxzMhLI3wi40t1l))+I18uSKaWhgTBeYUPD4sr(u"ࠨࠢࠣฯฬ์๊สࠩঽ"))
								if ppgUfvXWAdxzMhLI3wi40t1l>RNvWp0a84X1yK+sIzDXlTHYUC5L3xZGnr(u"࠳࠳൅"):
									data = {wdftVMyzF17cYETHu(u"ࠩࡸࡷࡪࡸࠧা"):I4t9qonjrm.AV_CLIENT_IDS,O3OVuapf0YFjbm5oUQDg(u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫি"):KoxvjArhL1TdInDmN9s,SnhLjmfeJC(u"ࠫࡺࡸ࡬ࠨী"):eIqSghHr0AyK1,aOQTKXFL54Nl60Zhp3MbE(u"ࠬࡱࡥࡺࠩু"):FFjsOV62kReSQJBiXbZ7yq3lUN,Hr25gta6XcqO(u"࠭ࡩࡥࠩূ"):UowsE6XxP83YLpOt,I18uSKaWhgTBeYUPD4sr(u"ࠧ࡫ࡱࡥࠫৃ"):O3OVuapf0YFjbm5oUQDg(u"ࠨࡩࡨࡸࡹࡵ࡫ࡦࡰࠪৄ")}
									E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,jL5CrsRwebpyDVXUc1EQP(u"ࠩࡓࡓࡘ࡚ࠧ৅"),kLW0pVcG479RzSANEDaqvhBHTKPX,data,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠵ࡵࡪࠪ৆"))
									FGRX4myP68S = E6ECvznP9m5sWFMu.content
									if FGRX4myP68S.startswith(sIzDXlTHYUC5L3xZGnr(u"࡙ࠫࡕࡋࡆࡐࡀࠫে")):
										eDi4j5Usrp = FGRX4myP68S.split(O3OVuapf0YFjbm5oUQDg(u"࡚ࠬࡏࡌࡇࡑࡁࠬৈ"),ssynAg0zhSkoCpOMDV9(u"࠴െ"))[BkM54Kr7Qbqn]
										break
									RNvWp0a84X1yK = ppgUfvXWAdxzMhLI3wi40t1l
								else: uUqrNPcXKBoQ0slv.sleep(BkM54Kr7Qbqn)
								ppgUfvXWAdxzMhLI3wi40t1l = uUqrNPcXKBoQ0slv.time()-j6C7IM93Z2qEpfwl1kSF0HVAyR
							ua2GNHKeh94QJSd.close()
				if eDi4j5Usrp:
					W8jwG43cYat7qOQlInHk = E6ECvznP9m5sWFMu.cookies
					nb8KE4GmNuWzJRxAMoc = EcQxOa3RJm86WjTKA.findall(N6NGJ4vpmidqMCh7yo(u"࠭ࡡ࡬ࡹࡤࡱࡤࡹࡥࡴࡵ࡬ࡳࡳࡃࠨ࠯ࠬࡂ࠭ࡀ࠭৉"),rGhA6otd4O,EcQxOa3RJm86WjTKA.DOTALL)
					if wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧࡢ࡭ࡺࡥࡲࡥࡳࡦࡵࡶ࡭ࡴࡴࠧ৊") in list(W8jwG43cYat7qOQlInHk.keys()): nb8KE4GmNuWzJRxAMoc = W8jwG43cYat7qOQlInHk[ssynAg0zhSkoCpOMDV9(u"ࠨࡣ࡮ࡻࡦࡳ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࠨো")]
					elif nb8KE4GmNuWzJRxAMoc: nb8KE4GmNuWzJRxAMoc = nb8KE4GmNuWzJRxAMoc[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
					captcha = EcQxOa3RJm86WjTKA.findall(N6NGJ4vpmidqMCh7yo(u"ࠩࡳࡥ࡬࡫࠭ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠰࠭ࡃࡦࡩࡴࡪࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡩࡵࡧ࡮ࡩࡾࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧৌ"),CN6RHLdaEDBzM9ZTyPpJcim,EcQxOa3RJm86WjTKA.DOTALL)
					if captcha: CpEzq7Bdk0Z3n2MX4wVAlOQUf,FFjsOV62kReSQJBiXbZ7yq3lUN = captcha[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
					if nb8KE4GmNuWzJRxAMoc and captcha:
						headers = {s5WMHyQN4mpie(u"ࠪࡇࡴࡵ࡫ࡪࡧ্ࠪ"):sJw9QWiq1Kr0xfeVRI(u"ࠫࡦࡱࡷࡢ࡯ࡢࡷࡪࡹࡳࡪࡱࡱࡁࠬৎ")+nb8KE4GmNuWzJRxAMoc,sIzDXlTHYUC5L3xZGnr(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭৏"):eIqSghHr0AyK1,AAbvaXV2DQzfNHdm4U3tT(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ৐"):FmYoGejTnwKME7d9zPc(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭৑")}
						data = sJw9QWiq1Kr0xfeVRI(u"ࠨࡩ࠰ࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠳ࡲࡦࡵࡳࡳࡳࡹࡥ࠾ࠩ৒")+eDi4j5Usrp
						E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,KfHAW8VGbrxi(u"ࠩࡓࡓࡘ࡚ࠧ৓"),CpEzq7Bdk0Z3n2MX4wVAlOQUf,data,headers,LhFAGlQ19zr,fy8iFgEkrO12NR9TWBI35sjY6qHvV,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠶ࡵࡪࠪ৔"))
						CN6RHLdaEDBzM9ZTyPpJcim = E6ECvznP9m5sWFMu.content
						try: cookies = E6ECvznP9m5sWFMu.cookies
						except: cookies = {}
						htPWN2GJ8UiC97gjzZ6R = EcQxOa3RJm86WjTKA.findall(ssynAg0zhSkoCpOMDV9(u"ࠦࠬ࠮ࡡ࡬ࡹࡤࡱ࡛࡫ࡲࡪࡨ࡬ࡧࡦࡺࡩࡰࡰ࠱࠮ࡄ࠯ࠧ࠻ࠢࠪࠬ࠳࠰࠿ࠪࠩࠥ৕"),str(cookies),EcQxOa3RJm86WjTKA.DOTALL)
			if htPWN2GJ8UiC97gjzZ6R:
				z36flodJVD9jWxip14Rh,htPWN2GJ8UiC97gjzZ6R = htPWN2GJ8UiC97gjzZ6R[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
				YrNCnX7AGaI9cs8 = z36flodJVD9jWxip14Rh+OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠬࡃࠧ৖")+htPWN2GJ8UiC97gjzZ6R
				OdiZIyCfDUsW3JBGR2VAb.setSetting(SnhLjmfeJC(u"࠭ࡡࡷ࠰ࡤ࡯ࡼࡧ࡭࠯ࡸࡨࡶ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࠧৗ"),YrNCnX7AGaI9cs8)
				GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ৘"),CsDcLqQUVK4YBvHFW1(u"ࠨ่ฯัฯูࠦๆๆํอࠥ็อึࠢฦ๊ฬࠦล็ีส๊ࠥ࠴࠮๊ࠡๅห๊ࠦวๅสิ๊ฬ๋ฬࠡสัึ๋ࠦๆหษษะࠥํะศࠢส่ๆำีࠡๆๆ๎ࠥ๐ำหะา้์อࠠๅษะๆฬࠦ࠮࠯๋่ࠢฬࠦส้ฮาࠤาอฬสࠢ็ษ฾อฯส๊ࠢิฬࠦวๅใะูู๊ࠥะหࠣวูํัࠡ࡞ࡱࡠࡳูࠦๅ็สࠤศ์่ࠠาสࠤฬ๊แฮืࠣืํ็๋ࠠฬๆีึࠦแ๋ࠢะห้ฯࠠห฼ํีࠥืศุࠢส่ัํวำࠢหห้หๆหำ้ฮࠥ࠴࠮ࠡล๋ࠤส฽แศรࠣีฬ๎สาࠢส่ส์สา่อࠤ࠳࠴ࠠฤ๊ࠣๅฺ๊ࠠิๆๆࠤฬ๊ัศ๊อีࠥ࠴࠮ࠡล๋ࠤฬูสฯัส้ࠥ࡜ࡐࡏࠢฦ์ࠥฮั้ๅึ๎ࠬ৙"))
				if uulNDCPyef78(u"ࠩ࠱ࡱࡵ࠺ࠧ৚") not in CN6RHLdaEDBzM9ZTyPpJcim:
					headers = {V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ৛"):YrNCnX7AGaI9cs8}
					E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠫࡌࡋࡔࠨড়"),eIqSghHr0AyK1,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,wdftVMyzF17cYETHu(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠹ࡷ࡬ࠬঢ়"))
					CN6RHLdaEDBzM9ZTyPpJcim = E6ECvznP9m5sWFMu.content
	if not IXlUkiwca1Yh5AQ9PNV3W2Cv4 and not YrNCnX7AGaI9cs8: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ৞"),O3OVuapf0YFjbm5oUQDg(u"ࠧโึ็ฮࠥ฿ๅๅ์ฬࠤๆำีࠡล้หࠥษๆิษ้ࠤ࠳࠴ࠠฮษ๋่ࠥหูศัฬࠤฬู๊ๆๆํอ๋ࠥัสࠢฦาึ๏ࠠษษึฮำีวๆ้ࠢๅุࠦวๅใํำ๏๎ࠠฤ๊ࠣๅ๏ี๊้ࠢ฽๎ึํࠠๆ่๊ࠣๆูࠠศๆ่์็฿ࠧয়"))
	return CN6RHLdaEDBzM9ZTyPpJcim
def tt9rH5O0wE(url,ZJqDh4ByGPQn13tlzMOTLCNdcugx,OOnVxtP0TNWsci6HrEGqBm9boKF7g):
	hFzEyHWOoRxG,paJKP0Usbeju4liH = [],[]
	eIqSghHr0AyK1 = url
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,PlpyFa9QMKXxOD1cvHzmI(u"ࠨࡉࡈࡘࠬৠ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,oRJAfwD957WkUyBM1Ehu8m(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡘࡃࡐ࠱࠶ࡹࡴࠨৡ"))
	soEymUvkt19PQXVjzKau6x5 = E6ECvznP9m5sWFMu.content
	YTPHg6RuOa4tCwoQvMjXxlsk = []
	if V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫৢ") in soEymUvkt19PQXVjzKau6x5 or Hr25gta6XcqO(u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨৣ") in soEymUvkt19PQXVjzKau6x5:
		VuGmoESTAfXlv5tD76PW1Masq0peB = EcQxOa3RJm86WjTKA.findall(wdftVMyzF17cYETHu(u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࡩࡶࡷࡴ࠳࠰࠿࠽࠱ࡤࡂࠬ৤"),soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
		if VuGmoESTAfXlv5tD76PW1Masq0peB:
			for wlJ6d8hEvpoMNSCmU in VuGmoESTAfXlv5tD76PW1Masq0peB:
				zzECVswWcGAIXhrQlZ7jMokugnv = EcQxOa3RJm86WjTKA.findall(sJw9QWiq1Kr0xfeVRI(u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ৥"),wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
				for bigdh7fpZYl4aT2keV,title in zzECVswWcGAIXhrQlZ7jMokugnv:
					if bigdh7fpZYl4aT2keV in hFzEyHWOoRxG: continue
					if LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࠨ০") not in bigdh7fpZYl4aT2keV and SnhLjmfeJC(u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬ১") not in bigdh7fpZYl4aT2keV: continue
					if KfHAW8VGbrxi(u"ࠩสࠫ২") not in title:
						YTPHg6RuOa4tCwoQvMjXxlsk.append((title,bigdh7fpZYl4aT2keV))
						continue
					title = title.replace(vU6DxuzPwMpg(u"ࠪࡀ࠴ࡹࡰࡢࡰࡁࠫ৩"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(AAbvaXV2DQzfNHdm4U3tT(u"ࠫࠥ࠳ࠠࠨ৪"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE)
					if EE1jeHnIoad(u"ࠬࡹࡰࡢࡰࠪ৫") in title: continue
					hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
					paJKP0Usbeju4liH.append(title)
			for title,bigdh7fpZYl4aT2keV in YTPHg6RuOa4tCwoQvMjXxlsk:
				if bigdh7fpZYl4aT2keV not in hFzEyHWOoRxG:
					hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
					paJKP0Usbeju4liH.append(title)
			yNqzFDjKM0SrO = D2D96X5NGamBhrFwvL8VEbqiSfZIl
			if len(hFzEyHWOoRxG)>BkM54Kr7Qbqn:
				yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S(vU6DxuzPwMpg(u"࠭ศฺุ๊หࠥ๐อหษฯࠤ࠻࠶ࠠฬษ้๎ฮ࠭৬"),paJKP0Usbeju4liH)
				if yNqzFDjKM0SrO==-BkM54Kr7Qbqn: return OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ৭"),[],[]
			if hFzEyHWOoRxG and yNqzFDjKM0SrO>=D2D96X5NGamBhrFwvL8VEbqiSfZIl: eIqSghHr0AyK1 = hFzEyHWOoRxG[yNqzFDjKM0SrO]
	CN6RHLdaEDBzM9ZTyPpJcim = w5O8dKjstlEMZgTGBn6IJP19cNLq(eIqSghHr0AyK1)
	XoSyx7p6dqZ1CF8,WFlpmsYGKNy = [],[]
	if ZJqDh4ByGPQn13tlzMOTLCNdcugx==sIzDXlTHYUC5L3xZGnr(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ৮"):
		Pv2Icj1rVNlmtn6x = EcQxOa3RJm86WjTKA.findall(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠩࡥࡸࡳ࠳࡬ࡰࡣࡧࡩࡷ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ৯"),CN6RHLdaEDBzM9ZTyPpJcim,EcQxOa3RJm86WjTKA.DOTALL)
		if Pv2Icj1rVNlmtn6x:
			bigdh7fpZYl4aT2keV = U2Z7CVFftTmLeK3nzEbQPGga(Pv2Icj1rVNlmtn6x[D2D96X5NGamBhrFwvL8VEbqiSfZIl])
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
			WFlpmsYGKNy.append(OOnVxtP0TNWsci6HrEGqBm9boKF7g)
	elif ZJqDh4ByGPQn13tlzMOTLCNdcugx==EE1jeHnIoad(u"ࠪࡻࡦࡺࡣࡩࠩৰ"):
		zzECVswWcGAIXhrQlZ7jMokugnv = EcQxOa3RJm86WjTKA.findall(FgXzMs0YSDt(u"ࠫࡁࡹ࡯ࡶࡴࡦࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴ࡫ࡽࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ৱ"),CN6RHLdaEDBzM9ZTyPpJcim,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,size in zzECVswWcGAIXhrQlZ7jMokugnv:
			if not bigdh7fpZYl4aT2keV: continue
			if OOnVxtP0TNWsci6HrEGqBm9boKF7g in size:
				WFlpmsYGKNy.append(size)
				XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
				break
		if not XoSyx7p6dqZ1CF8:
			for bigdh7fpZYl4aT2keV,size in zzECVswWcGAIXhrQlZ7jMokugnv:
				if not bigdh7fpZYl4aT2keV: continue
				WFlpmsYGKNy.append(size)
				XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	if not XoSyx7p6dqZ1CF8: return Gcw2nelTR864XCVruO3mAFqI5a(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡍ࡚ࡅࡒ࠭৲"),[],[]
	return fy8iFgEkrO12NR9TWBI35sjY6qHvV,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
def eSXLR24o65(url,z36flodJVD9jWxip14Rh):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,o1INZ3ViQqS0Uw5z6kMjbv(u"࠭ࡇࡆࡖࠪ৳"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EsCplGc5N4mBuYW0RVQt6b,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CsDcLqQUVK4YBvHFW1(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎ࠯࠴ࡷࡹ࠭৴"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	cookies = E6ECvznP9m5sWFMu.cookies
	if sIzDXlTHYUC5L3xZGnr(u"ࠨࡩࡲࡰ࡮ࡴ࡫ࠨ৵") in list(cookies.keys()):
		YrNCnX7AGaI9cs8 = cookies[jL5CrsRwebpyDVXUc1EQP(u"ࠩࡪࡳࡱ࡯࡮࡬ࠩ৶")]
		YrNCnX7AGaI9cs8 = U2Z7CVFftTmLeK3nzEbQPGga(XXcPiylRDh6IapYA25rwO8u(YrNCnX7AGaI9cs8))
		items = EcQxOa3RJm86WjTKA.findall(SnhLjmfeJC(u"ࠪࡶࡴࡻࡴࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ৷"),YrNCnX7AGaI9cs8,EcQxOa3RJm86WjTKA.DOTALL)
		YLKFRH6sSIrznXBg = items[D2D96X5NGamBhrFwvL8VEbqiSfZIl].replace(o1INZ3ViQqS0Uw5z6kMjbv(u"ࠫࡡ࠵ࠧ৸"),sIzDXlTHYUC5L3xZGnr(u"ࠬ࠵ࠧ৹"))
		YLKFRH6sSIrznXBg = XXcPiylRDh6IapYA25rwO8u(YLKFRH6sSIrznXBg)
	else: YLKFRH6sSIrznXBg = url
	if FgXzMs0YSDt(u"࠭ࡣࡢࡶࡦ࡬࠳࡯ࡳࠨ৺") in YLKFRH6sSIrznXBg:
		gyO5Q2TzRC0BZpfIMu3Yb4clJqAH = YLKFRH6sSIrznXBg.split(ggjO5CrKVRPITaesWkxD(u"ࠧࠦ࠴ࡉࠫ৻"))[-BkM54Kr7Qbqn]
		YLKFRH6sSIrznXBg = sIzDXlTHYUC5L3xZGnr(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡥࡤࡸࡨ࡮࠮ࡪࡵ࠲ࠫৼ")+gyO5Q2TzRC0BZpfIMu3Yb4clJqAH
		return I18uSKaWhgTBeYUPD4sr(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ৽"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[YLKFRH6sSIrznXBg]
	else:
		website = I4t9qonjrm.SITESURLS[V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪࡅࡐࡕࡁࡎࠩ৾")][D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,ssynAg0zhSkoCpOMDV9(u"ࠫࡌࡋࡔࠨ৿"),website,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EsCplGc5N4mBuYW0RVQt6b,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QjAINyUC7MDRq5d8e4vl9(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓ࠭࠳ࡰࡧࠫ਀"))
		Aw2cob3j9JnlS1OXH8pvk5PBN = E6ECvznP9m5sWFMu.url
		QB8R0xK4hw1o5 = YLKFRH6sSIrznXBg.split(o1INZ3ViQqS0Uw5z6kMjbv(u"࠭࠯ࠨਁ"))[teaC5j4HuGDqpwcmUzJ]
		pQy5ZXW2srCDgU = Aw2cob3j9JnlS1OXH8pvk5PBN.split(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧ࠰ࠩਂ"))[teaC5j4HuGDqpwcmUzJ]
		MYWwFs7XA2 = YLKFRH6sSIrznXBg.replace(QB8R0xK4hw1o5,pQy5ZXW2srCDgU)
		headers = { jL5CrsRwebpyDVXUc1EQP(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬਃ"):fy8iFgEkrO12NR9TWBI35sjY6qHvV , s5WMHyQN4mpie(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ਄"):I18uSKaWhgTBeYUPD4sr(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫਅ") , s5WMHyQN4mpie(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬਆ"):MYWwFs7XA2 }
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,s5WMHyQN4mpie(u"ࠬࡖࡏࡔࡖࠪਇ"), MYWwFs7XA2, fy8iFgEkrO12NR9TWBI35sjY6qHvV, headers, LhFAGlQ19zr,fy8iFgEkrO12NR9TWBI35sjY6qHvV,FmYoGejTnwKME7d9zPc(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍ࠮࠵ࡵࡨࠬਈ"))
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		items = EcQxOa3RJm86WjTKA.findall(FgXzMs0YSDt(u"ࠧࡥ࡫ࡵࡩࡨࡺ࡟࡭࡫ࡱ࡯ࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧਉ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL|EcQxOa3RJm86WjTKA.IGNORECASE)
		if not items:
			items = EcQxOa3RJm86WjTKA.findall(SnhLjmfeJC(u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩਊ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL|EcQxOa3RJm86WjTKA.IGNORECASE)
			if not items:
				items = EcQxOa3RJm86WjTKA.findall(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠩ࠿ࡩࡲࡨࡥࡥ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ਋"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL|EcQxOa3RJm86WjTKA.IGNORECASE)
		if items:
			bigdh7fpZYl4aT2keV = items[D2D96X5NGamBhrFwvL8VEbqiSfZIl].replace(QjAINyUC7MDRq5d8e4vl9(u"ࠪࡠ࠴࠭਌"),EE1jeHnIoad(u"ࠫ࠴࠭਍"))
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.rstrip(sIzDXlTHYUC5L3xZGnr(u"ࠬ࠵ࠧ਎"))
			if oRJAfwD957WkUyBM1Ehu8m(u"࠭ࡨࡵࡶࡳࠫਏ") not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = sJw9QWiq1Kr0xfeVRI(u"ࠧࡩࡶࡷࡴ࠿࠭ਐ") + bigdh7fpZYl4aT2keV
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.replace(LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠩ਑"),FmYoGejTnwKME7d9zPc(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫ਒"))
			if z36flodJVD9jWxip14Rh==fy8iFgEkrO12NR9TWBI35sjY6qHvV: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
			else: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ਓ"),[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
		else: OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = I18uSKaWhgTBeYUPD4sr(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡌࡑࡄࡑࠬਔ"),[],[]
		return OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
def N7QPEUOTDefGkxpsh2d1(url):
	headers = { wdftVMyzF17cYETHu(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩਕ") : fy8iFgEkrO12NR9TWBI35sjY6qHvV }
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(d9vcuo3Hy7RhAk2,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡕࡅࡕࡏࡄࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪਖ"))
	items = EcQxOa3RJm86WjTKA.findall(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧ࠽ࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡮ࡤࡦࡪࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨਗ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	WFlpmsYGKNy,XoSyx7p6dqZ1CF8,errno = [],[],fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if items:
		for bigdh7fpZYl4aT2keV,ffWgMXo20Hb5xurkdNqa in items:
			WFlpmsYGKNy.append(ffWgMXo20Hb5xurkdNqa)
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	if len(XoSyx7p6dqZ1CF8)==D2D96X5NGamBhrFwvL8VEbqiSfZIl: return sJw9QWiq1Kr0xfeVRI(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡖࡆࡖࡉࡅࡘࡌࡈࡊࡕࠧਘ"),[],[]
	return fy8iFgEkrO12NR9TWBI35sjY6qHvV,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
def s5tzjyxaWcqk(url):
	aiuh0XlPswEK = url.split(uulNDCPyef78(u"ࠩ࠲ࠫਙ"))[jL5CrsRwebpyDVXUc1EQP(u"࠷േ")]
	data = Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪࡳࡵࡃࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠨ࡬ࡨࡂ࠭ਚ")+aiuh0XlPswEK
	headers = {ssynAg0zhSkoCpOMDV9(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪਛ"):wdftVMyzF17cYETHu(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫਜ")}
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠭ࡐࡐࡕࡗࠫਝ"),url,data,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡗࡊࡌ࠮࠳ࡶࡸࠬਞ"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	items = EcQxOa3RJm86WjTKA.findall(aOQTKXFL54Nl60Zhp3MbE(u"ࠨࡣࡧࡦࡱࡵࡣ࡬ࡡࡧࡩࡹ࡫ࡣࡵࡧࡧ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬਟ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if items:
		url = items[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[url]
	return sJw9QWiq1Kr0xfeVRI(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡘࡄࡍࠩਠ"),[],[]
def WW1kmVcfLqeKBCiJ0yjYN69d(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪࡋࡊ࡚ࠧਡ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,N6NGJ4vpmidqMCh7yo(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡗࡍ࠰࠵ࡸࡺࠧਢ"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	try: FGRX4myP68S = FGRX4myP68S.decode(KfHAW8VGbrxi(u"ࠬࡻࡴࡧ࠺ࠪਣ"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ਤ"))
	except: pass
	items = EcQxOa3RJm86WjTKA.findall(wdftVMyzF17cYETHu(u"ࠧࡥࡱࡦࡷࡤࡴ࡯ࡠࡲࡵࡩࡻ࡯ࡥࡸࡡࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨਥ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if items:
		url = items[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[url]
	return oRJAfwD957WkUyBM1Ehu8m(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡐ࠭ਦ"),[],[]
def f923fEHjrwl5yYh64A(url):
	headers = {QjAINyUC7MDRq5d8e4vl9(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ਧ"):fy8iFgEkrO12NR9TWBI35sjY6qHvV}
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(d9vcuo3Hy7RhAk2,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡒࡎࡒࡅࡉ࠳࠱ࡴࡶࠪਨ"))
	items = EcQxOa3RJm86WjTKA.findall(I18uSKaWhgTBeYUPD4sr(u"ࠫࡸࡵࡵࡳࡥࡨࡷ࠿ࠦ࡜࡜ࠤࠫ࠲࠯ࡅࠩࠣࠩ਩"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if items:
		url = items[D2D96X5NGamBhrFwvL8VEbqiSfZIl]+I18uSKaWhgTBeYUPD4sr(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨਪ")+url
		return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[url]
	return Gcw2nelTR864XCVruO3mAFqI5a(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡗࡔࡐࡔࡇࡄࠨਫ"),[],[]
def Bgnf6J12sxbqDpd(url):
	url = url.strip(LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠧ࠰ࠩਬ"))
	if I18uSKaWhgTBeYUPD4sr(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠰ࠩਭ") in url: gyO5Q2TzRC0BZpfIMu3Yb4clJqAH = url.split(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠩ࠲ࠫਮ"))[vD4Fh6ictZ7wME]
	else: gyO5Q2TzRC0BZpfIMu3Yb4clJqAH = url.split(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪ࠳ࠬਯ"))[-BkM54Kr7Qbqn]
	url = Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡼࡣࡴࡶࡵࡩࡦࡳ࠮ࡵࡱ࠲ࡴࡱࡧࡹࡦࡴࡂࡪ࡮ࡪ࠽ࠨਰ") + gyO5Q2TzRC0BZpfIMu3Yb4clJqAH
	headers = { ggjO5CrKVRPITaesWkxD(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ਱") : fy8iFgEkrO12NR9TWBI35sjY6qHvV }
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(d9vcuo3Hy7RhAk2,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QjAINyUC7MDRq5d8e4vl9(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡙ࡇࡘ࡚ࡒࡆࡃࡐ࠱࠶ࡹࡴࠨਲ"))
	FGRX4myP68S = FGRX4myP68S.replace(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠧ࡝࡞ࠪਲ਼"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	items = EcQxOa3RJm86WjTKA.findall(o1INZ3ViQqS0Uw5z6kMjbv(u"ࠨࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ਴"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if items: return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[ items[D2D96X5NGamBhrFwvL8VEbqiSfZIl] ]
	return FgXzMs0YSDt(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡛ࡉࡓࡕࡔࡈࡅࡒ࠭ਵ"),[],[]
def giTbeEldcmwUp07AYNaxoO(url):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(d9vcuo3Hy7RhAk2,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,sJw9QWiq1Kr0xfeVRI(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡖࡊࡆࡒ࡞ࡆ࠳࠱ࡴࡶࠪਸ਼"))
	items = EcQxOa3RJm86WjTKA.findall(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠫࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡲࡡࡣࡧ࡯࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠦࡲࡦࡵ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ਷"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = [],[]
	for bigdh7fpZYl4aT2keV,ffWgMXo20Hb5xurkdNqa,IerJ5GYbR9SZWl7XN8wdu2 in items:
		WFlpmsYGKNy.append(ffWgMXo20Hb5xurkdNqa+ksJdoFWhxTz8Y2N7bOZE+IerJ5GYbR9SZWl7XN8wdu2)
		XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	if len(XoSyx7p6dqZ1CF8)==D2D96X5NGamBhrFwvL8VEbqiSfZIl: return CsDcLqQUVK4YBvHFW1(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡗࡋࡇࡓ࡟ࡇࠧਸ"),[],[]
	return fy8iFgEkrO12NR9TWBI35sjY6qHvV,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
def qPBYkp2tWTS(url):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(d9vcuo3Hy7RhAk2,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡚ࡅ࡙ࡉࡈࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪਹ"))
	items = EcQxOa3RJm86WjTKA.findall(s5WMHyQN4mpie(u"ࠢࡥࡱࡺࡲࡱࡵࡡࡥࡡࡹ࡭ࡩ࡫࡯࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫࡡ࠯࡜ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂ࠳࠰࠿࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠯࠲࠯ࡅ࠼࠰ࡶࡧࡂࠧ਺"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	items = set(items)
	WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = [],[]
	for gyO5Q2TzRC0BZpfIMu3Yb4clJqAH,hO3D6GVPY2qENv8bZWH,aJw1Duphr46NCRjnc2QLmG0TglEoIS,ffWgMXo20Hb5xurkdNqa,IerJ5GYbR9SZWl7XN8wdu2 in items:
		url = O3OVuapf0YFjbm5oUQDg(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠴ࡵࡴ࠱ࡧࡰࡄࡵࡰ࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡳࡷ࡯ࡧࠧ࡫ࡧࡁࠬ਻")+gyO5Q2TzRC0BZpfIMu3Yb4clJqAH+LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠩࠩࡱࡴࡪࡥ࠾਼ࠩ")+hO3D6GVPY2qENv8bZWH+N6NGJ4vpmidqMCh7yo(u"ࠪࠪ࡭ࡧࡳࡩ࠿ࠪ਽")+aJw1Duphr46NCRjnc2QLmG0TglEoIS
		FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(d9vcuo3Hy7RhAk2,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Hr25gta6XcqO(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒ࠱࠷ࡴࡤࠨਾ"))
		items = EcQxOa3RJm86WjTKA.findall(FgXzMs0YSDt(u"ࠬࡪࡩࡳࡧࡦࡸࠥࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫਿ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV in items:
			WFlpmsYGKNy.append(ffWgMXo20Hb5xurkdNqa+ksJdoFWhxTz8Y2N7bOZE+IerJ5GYbR9SZWl7XN8wdu2)
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	if len(XoSyx7p6dqZ1CF8)==D2D96X5NGamBhrFwvL8VEbqiSfZIl: return wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤ࡙ࠡࡄࡘࡈࡎࡖࡊࡆࡈࡓࠬੀ"),[],[]
	return fy8iFgEkrO12NR9TWBI35sjY6qHvV,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
def aShB6TyMz42IWGoV(url):
	bigdh7fpZYl4aT2keV = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if BkM54Kr7Qbqn or ssynAg0zhSkoCpOMDV9(u"ࠧࡌࡧࡼࡁࠬੁ") not in url:
		YLKFRH6sSIrznXBg = url.replace(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠨࡷࡳࡦࡴࡳ࠮࡭࡫ࡹࡩࠬੂ"),Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠩࡸࡴࡵࡵ࡭࠯࡮࡬ࡺࡪ࠭੃"))
		YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg.split(jL5CrsRwebpyDVXUc1EQP(u"ࠪ࠳ࠬ੄"))
		gyO5Q2TzRC0BZpfIMu3Yb4clJqAH = YLKFRH6sSIrznXBg[XW57OCeGnFTLQbaqdrD9zM]
		YLKFRH6sSIrznXBg = vU6DxuzPwMpg(u"ࠫ࠴࠭੅").join(YLKFRH6sSIrznXBg[D2D96X5NGamBhrFwvL8VEbqiSfZIl:vD4Fh6ictZ7wME])
		B7gtJnK24RY = {ssynAg0zhSkoCpOMDV9(u"ࠬ࡯ࡤࠨ੆"):gyO5Q2TzRC0BZpfIMu3Yb4clJqAH,AAbvaXV2DQzfNHdm4U3tT(u"࠭࡯ࡱࠩੇ"):SnhLjmfeJC(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠴ࠪੈ"),wdftVMyzF17cYETHu(u"ࠨ࡯ࡨࡸ࡭ࡵࡤࡠࡨࡵࡩࡪ࠭੉"):PlpyFa9QMKXxOD1cvHzmI(u"ࠩࡉࡶࡪ࡫ࠫࡅࡱࡺࡲࡱࡵࡡࡥ࠭ࠨ࠷ࡊࠫ࠳ࡆࠩ੊")}
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,Hr25gta6XcqO(u"ࠪࡔࡔ࡙ࡔࠨੋ"),YLKFRH6sSIrznXBg,B7gtJnK24RY,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QjAINyUC7MDRq5d8e4vl9(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡖࡒࡅࡓࡒ࠳࠱ࡴࡶࠪੌ"))
		if jL5CrsRwebpyDVXUc1EQP(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴ੍ࠧ") in list(E6ECvznP9m5sWFMu.headers.keys()): bigdh7fpZYl4aT2keV = E6ECvznP9m5sWFMu.headers[QjAINyUC7MDRq5d8e4vl9(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ੎")]
		if not bigdh7fpZYl4aT2keV and E6ECvznP9m5sWFMu.succeeded:
			FGRX4myP68S = E6ECvznP9m5sWFMu.content
			bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧࡪࡦࡀࠦࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ੏"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
			if bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	else:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,vU6DxuzPwMpg(u"ࠨࡉࡈࡘࠬ੐"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡛ࡐࡃࡑࡐ࠱࠷ࡴࡤࠨੑ"))
		if N6NGJ4vpmidqMCh7yo(u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬ੒") in list(E6ECvznP9m5sWFMu.headers.keys()): bigdh7fpZYl4aT2keV = E6ECvznP9m5sWFMu.headers[SnhLjmfeJC(u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭੓")]
	if bigdh7fpZYl4aT2keV: return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
	return SnhLjmfeJC(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡖࡒࡅࡓࡒ࠭੔"),[],[]
def pyIGCgP0s2KdEfvjVHFbi7LqR(url):
	headers = { s5WMHyQN4mpie(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ੕") : fy8iFgEkrO12NR9TWBI35sjY6qHvV }
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(d9vcuo3Hy7RhAk2,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,sIzDXlTHYUC5L3xZGnr(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡐࡎࡏࡖࡊࡆࡈࡓ࠲࠷ࡳࡵࠩ੖"))
	items = EcQxOa3RJm86WjTKA.findall(s5WMHyQN4mpie(u"ࠨࡵࡲࡹࡷࡩࡥࡴ࠼࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࠩ࠰࠭ࡃ࠮ࠨࠧ੗"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = [],[]
	if items:
		WFlpmsYGKNy.append(vU6DxuzPwMpg(u"ࠩࡰࡴ࠹࠭੘"))
		XoSyx7p6dqZ1CF8.append(items[D2D96X5NGamBhrFwvL8VEbqiSfZIl][BkM54Kr7Qbqn])
		WFlpmsYGKNy.append(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪࡱ࠸ࡻ࠸ࠨਖ਼"))
		XoSyx7p6dqZ1CF8.append(items[D2D96X5NGamBhrFwvL8VEbqiSfZIl][D2D96X5NGamBhrFwvL8VEbqiSfZIl])
		return fy8iFgEkrO12NR9TWBI35sjY6qHvV,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
	else: return C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡌࡊࡋ࡙ࡍࡉࡋࡏࠨਗ਼"),[],[]
def bMzHYo254smEjwkrZ0IyJ7(url):
	gyO5Q2TzRC0BZpfIMu3Yb4clJqAH = url.split(oRJAfwD957WkUyBM1Ehu8m(u"ࠬ࠵ࠧਜ਼"))[-BkM54Kr7Qbqn]
	gyO5Q2TzRC0BZpfIMu3Yb4clJqAH = gyO5Q2TzRC0BZpfIMu3Yb4clJqAH.split(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭ࠦࠨੜ"))[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	gyO5Q2TzRC0BZpfIMu3Yb4clJqAH = gyO5Q2TzRC0BZpfIMu3Yb4clJqAH.replace(sIzDXlTHYUC5L3xZGnr(u"ࠧࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ੝"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	YLKFRH6sSIrznXBg = I4t9qonjrm.SITESURLS[PlpyFa9QMKXxOD1cvHzmI(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩਫ਼")][D2D96X5NGamBhrFwvL8VEbqiSfZIl]+ssynAg0zhSkoCpOMDV9(u"ࠩ࠲ࡻࡦࡺࡣࡩࡁࡹࡁࠬ੟")+gyO5Q2TzRC0BZpfIMu3Yb4clJqAH
	RGS23XqK4jPHLAIY6ZOuFgpQC = AAbvaXV2DQzfNHdm4U3tT(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡽࡴࡻࡴࡶ࠰ࡥࡩ࠴࠭੠")+gyO5Q2TzRC0BZpfIMu3Yb4clJqAH
	H3HOmNFvc0e,bUnP65BivmkW = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	FGRX4myP68S = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	Zj9KqhyTuOG4a3fgX,bKTm4excAd = fy8iFgEkrO12NR9TWBI35sjY6qHvV,{}
	YAy2RPLQ3DO,MS76nQWTBvAud = fy8iFgEkrO12NR9TWBI35sjY6qHvV,{}
	headers = {wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ੡"):fy8iFgEkrO12NR9TWBI35sjY6qHvV}
	if D2D96X5NGamBhrFwvL8VEbqiSfZIl:
		kkxDv3NOJZByLshq4Io9FQl7XMReE0 = V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠶ൈ")
		for b3b24XZTV7gW9mhcqLoCnftO in range(kkxDv3NOJZByLshq4Io9FQl7XMReE0):
			E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,sJw9QWiq1Kr0xfeVRI(u"ࠬࡍࡅࡕࠩ੢"),YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,PlpyFa9QMKXxOD1cvHzmI(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠵ࡸࡺࠧ੣"))
			FGRX4myP68S = E6ECvznP9m5sWFMu.content
		x3KcJMOQyeHhCZmN85ut6sVfp = EcQxOa3RJm86WjTKA.findall(Hr25gta6XcqO(u"ࠧࡷࡣࡵࠤࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡐ࡭ࡣࡼࡩࡷࡘࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࠫ࠲࠯ࡅࠩ࠼࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ੤"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		Zj9KqhyTuOG4a3fgX = x3KcJMOQyeHhCZmN85ut6sVfp[D2D96X5NGamBhrFwvL8VEbqiSfZIl] if x3KcJMOQyeHhCZmN85ut6sVfp else FGRX4myP68S
		bKTm4excAd = LB7TcZnGYdfw5lWU1RH3Oztu9PyA(jL5CrsRwebpyDVXUc1EQP(u"ࠨࡦ࡬ࡧࡹ࠭੥"),Zj9KqhyTuOG4a3fgX)
	else:
		MYWwFs7XA2 = I4t9qonjrm.SITESURLS[ssynAg0zhSkoCpOMDV9(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ੦")][D2D96X5NGamBhrFwvL8VEbqiSfZIl]+ssynAg0zhSkoCpOMDV9(u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡳࡰࡦࡿࡥࡳࠩ੧")
		sLOGbi4J0aQV8lf2YAICopZSdT9r = OdiZIyCfDUsW3JBGR2VAb.getSetting(FgXzMs0YSDt(u"ࠫࡦࡼ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦࡤࡸࡦ࠭੨"))
		if sLOGbi4J0aQV8lf2YAICopZSdT9r.count(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠬࡀ࠺࠻ࠩ੩"))==AAbvaXV2DQzfNHdm4U3tT(u"࠺൉"):
			vXpUr18ekh,key,g4G0lU8YAsCM6zJ2VWZvxSBajf,GcEzuAdmtO430,eDi4j5Usrp = sLOGbi4J0aQV8lf2YAICopZSdT9r.split(sJw9QWiq1Kr0xfeVRI(u"࠭࠺࠻࠼ࠪ੪"))
			headers[OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࡙ࠧ࠯ࡊࡳࡴ࡭࠭ࡗ࡫ࡶ࡭ࡹࡵࡲ࠮ࡋࡧࠫ੫")] = vXpUr18ekh
		headers[sJw9QWiq1Kr0xfeVRI(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ੬")] = ssynAg0zhSkoCpOMDV9(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯࡫ࡵࡲࡲࠬ੭")
		if BkM54Kr7Qbqn:
			LLd3n6b1OUJPCVYvtc2yMSp5 = Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪࡿࠧࡼࡩࡥࡧࡲࡍࡩࠨ࠺ࠡࠤࠪ੮")+gyO5Q2TzRC0BZpfIMu3Yb4clJqAH+uulNDCPyef78(u"ࠫࠧ࠲ࠠࠣࡥࡲࡲࡹ࡫ࡸࡵࠤ࠽ࠤࢀࠨࡣ࡭࡫ࡨࡲࡹࠨ࠺ࠡࡽࠥࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠥ࠾ࠥࠨ࠷࠯࠴࠳࠶࠹࠷࠲࠱࠳࠱࠵࠽࠴࠰࠱ࠤ࠯ࠤࠧࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠤ࠽ࠤ࡚ࠧࡖࡉࡖࡐࡐ࠺ࠨࡽࡾࡿࠪ੯")
			E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,vU6DxuzPwMpg(u"ࠬࡖࡏࡔࡖࠪੰ"),MYWwFs7XA2,LLd3n6b1OUJPCVYvtc2yMSp5,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,wdftVMyzF17cYETHu(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠶ࡳࡪࠧੱ"))
			x3KcJMOQyeHhCZmN85ut6sVfp = E6ECvznP9m5sWFMu.content
			if LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧੲ") in x3KcJMOQyeHhCZmN85ut6sVfp:
				Zj9KqhyTuOG4a3fgX = x3KcJMOQyeHhCZmN85ut6sVfp.replace(oRJAfwD957WkUyBM1Ehu8m(u"ࠨ࡞࡟ࡹ࠵࠶࠲࠷ࠩੳ"),sJw9QWiq1Kr0xfeVRI(u"ࠩࠩࠫੴ"))
				bKTm4excAd = LB7TcZnGYdfw5lWU1RH3Oztu9PyA(uulNDCPyef78(u"ࠪࡨ࡮ࡩࡴࠨੵ"),Zj9KqhyTuOG4a3fgX)
		if BkM54Kr7Qbqn:
			LLd3n6b1OUJPCVYvtc2yMSp5 = OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠫࢀࠨࡶࡪࡦࡨࡳࡎࡪࠢ࠻ࠢࠥࠫ੶")+gyO5Q2TzRC0BZpfIMu3Yb4clJqAH+LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠬࠨࠬࠡࠤࡦࡳࡳࡺࡥࡹࡶࠥ࠾ࠥࢁࠢࡤ࡮࡬ࡩࡳࡺࠢ࠻ࠢࡾࠦࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠦ࠿ࠦࠢ࠲࠻࠱࠸࠺࠴࠴ࠣ࠮ࠣࠦࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠣ࠼ࠣࠦࡎࡕࡓࠣࡿࢀࢁࠬ੷")
			E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠭ࡐࡐࡕࡗࠫ੸"),MYWwFs7XA2,LLd3n6b1OUJPCVYvtc2yMSp5,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,KfHAW8VGbrxi(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠸ࡸࡤࠨ੹"))
			x3KcJMOQyeHhCZmN85ut6sVfp = E6ECvznP9m5sWFMu.content
			if vU6DxuzPwMpg(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨ੺") in x3KcJMOQyeHhCZmN85ut6sVfp:
				YAy2RPLQ3DO = x3KcJMOQyeHhCZmN85ut6sVfp.replace(SnhLjmfeJC(u"ࠩ࡟ࡠࡺ࠶࠰࠳࠸ࠪ੻"),s5WMHyQN4mpie(u"ࠪࠪࠬ੼"))
				MS76nQWTBvAud = LB7TcZnGYdfw5lWU1RH3Oztu9PyA(SnhLjmfeJC(u"ࠫࡩ࡯ࡣࡵࠩ੽"),YAy2RPLQ3DO)
		if BkM54Kr7Qbqn and CsDcLqQUVK4YBvHFW1(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬ੾") not in Zj9KqhyTuOG4a3fgX:
			Zj9KqhyTuOG4a3fgX,bKTm4excAd,bKTm4excAd = fy8iFgEkrO12NR9TWBI35sjY6qHvV,{},{}
			LLd3n6b1OUJPCVYvtc2yMSp5 = sJw9QWiq1Kr0xfeVRI(u"࠭ࡻࠣࡸ࡬ࡨࡪࡵࡉࡥࠤ࠽ࠤࠧ࠭੿")+gyO5Q2TzRC0BZpfIMu3Yb4clJqAH+s5WMHyQN4mpie(u"ࠧࠣ࠮ࠣࠦࡨࡵ࡮ࡵࡧࡻࡸࠧࡀࠠࡼࠤࡦࡰ࡮࡫࡮ࡵࠤ࠽ࠤࢀࠨࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳࠨ࠺ࠡࠤ࠵࠲࠷࠶࠲࠵࠲࠺࠶࠻࠴࠰࠲࠰࠳࠴ࠧ࠲ࠠࠣࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠧࡀࠠࠣࡏ࡚ࡉࡇࠨࡽࡾࡿࠪ઀")
			E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠨࡒࡒࡗ࡙࠭ઁ"),MYWwFs7XA2,LLd3n6b1OUJPCVYvtc2yMSp5,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,CsDcLqQUVK4YBvHFW1(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠴ࡵࡪࠪં"))
			x3KcJMOQyeHhCZmN85ut6sVfp = E6ECvznP9m5sWFMu.content
			if FmYoGejTnwKME7d9zPc(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪઃ") in x3KcJMOQyeHhCZmN85ut6sVfp:
				Zj9KqhyTuOG4a3fgX = x3KcJMOQyeHhCZmN85ut6sVfp.replace(AAbvaXV2DQzfNHdm4U3tT(u"ࠫࡡࡢࡵ࠱࠲࠵࠺ࠬ઄"),PlpyFa9QMKXxOD1cvHzmI(u"ࠬࠬࠧઅ"))
				bKTm4excAd = LB7TcZnGYdfw5lWU1RH3Oztu9PyA(FgXzMs0YSDt(u"࠭ࡤࡪࡥࡷࠫઆ"),Zj9KqhyTuOG4a3fgX)
		if BkM54Kr7Qbqn and Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧઇ") not in YAy2RPLQ3DO:
			YAy2RPLQ3DO,MS76nQWTBvAud,MS76nQWTBvAud = fy8iFgEkrO12NR9TWBI35sjY6qHvV,{},{}
			LLd3n6b1OUJPCVYvtc2yMSp5 = EE1jeHnIoad(u"ࠨࡽࠥࡺ࡮ࡪࡥࡰࡋࡧࠦ࠿ࠦࠢࠨઈ")+gyO5Q2TzRC0BZpfIMu3Yb4clJqAH+aOQTKXFL54Nl60Zhp3MbE(u"ࠩࠥ࠰ࠥࠨࡣࡰࡰࡷࡩࡽࡺࠢ࠻ࠢࡾࠦࡨࡲࡩࡦࡰࡷࠦ࠿ࠦࡻࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ࠼ࠣࠦ࠶࠿࠮࠳࠻࠱࠷࠼ࠨࠬࠡࠤࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪࠨ࠺ࠡࠤࡄࡒࡉࡘࡏࡊࡆࠥ࠰ࠥࠨࡡ࡯ࡦࡵࡳ࡮ࡪࡓࡥ࡭࡙ࡩࡷࡹࡩࡰࡰࠥ࠾ࠥࠨ࠳࠲ࠤࢀࢁࢂ࠭ઉ")
			headers[O3OVuapf0YFjbm5oUQDg(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧઊ")] = LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠫࡨࡵ࡭࠯ࡩࡲࡳ࡬ࡲࡥ࠯ࡣࡱࡨࡷࡵࡩࡥ࠰ࡼࡳࡺࡺࡵࡣࡧ࠲࠵࠾࠴࠲࠺࠰࠶࠻ࠥ࠮ࡌࡪࡰࡸࡼࡀࠦࡕ࠼ࠢࡄࡲࡩࡸ࡯ࡪࡦࠣ࠵࠷ࡁࠠࡈࡄࠬࠤ࡬ࢀࡩࡱࠩઋ")
			E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,Gcw2nelTR864XCVruO3mAFqI5a(u"ࠬࡖࡏࡔࡖࠪઌ"),MYWwFs7XA2,LLd3n6b1OUJPCVYvtc2yMSp5,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QjAINyUC7MDRq5d8e4vl9(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠹ࡹ࡮ࠧઍ"))
			x3KcJMOQyeHhCZmN85ut6sVfp = E6ECvznP9m5sWFMu.content
			if AAbvaXV2DQzfNHdm4U3tT(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧ઎") in x3KcJMOQyeHhCZmN85ut6sVfp:
				YAy2RPLQ3DO = x3KcJMOQyeHhCZmN85ut6sVfp.replace(CsDcLqQUVK4YBvHFW1(u"ࠨ࡞࡟ࡹ࠵࠶࠲࠷ࠩએ"),FmYoGejTnwKME7d9zPc(u"ࠩࠩࠫઐ"))
				MS76nQWTBvAud = LB7TcZnGYdfw5lWU1RH3Oztu9PyA(I18uSKaWhgTBeYUPD4sr(u"ࠪࡨ࡮ࡩࡴࠨઑ"),YAy2RPLQ3DO)
	XVWGt2owfl6L7JnKmvpOjsEc,g84qoUGATaZIfitEkBwmFPOL,b7ZuBLGKRfTDn,FoTAbnCgO9SUzhR3GE5Pix6YW = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,[],[]
	iZI3tkg5WEdq80pe1VGT,Mlk73Vps0mjrGh2EH,OfAjznPq7xu4NQTGry,GhrfIybSpeTu2qWmD = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,[],[]
	try: g84qoUGATaZIfitEkBwmFPOL = bKTm4excAd[Hr25gta6XcqO(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫ઒")][EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬ࡮࡬ࡴࡏࡤࡲ࡮࡬ࡥࡴࡶࡘࡶࡱ࠭ઓ")]
	except: pass
	try: Mlk73Vps0mjrGh2EH = MS76nQWTBvAud[CsDcLqQUVK4YBvHFW1(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭ઔ")][Hr25gta6XcqO(u"ࠧࡩ࡮ࡶࡑࡦࡴࡩࡧࡧࡶࡸ࡚ࡸ࡬ࠨક")]
	except: pass
	try: XVWGt2owfl6L7JnKmvpOjsEc = bKTm4excAd[EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨખ")][PlpyFa9QMKXxOD1cvHzmI(u"ࠩࡧࡥࡸ࡮ࡍࡢࡰ࡬ࡪࡪࡹࡴࡖࡴ࡯ࠫગ")]
	except: pass
	try: iZI3tkg5WEdq80pe1VGT = MS76nQWTBvAud[sJw9QWiq1Kr0xfeVRI(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪઘ")][EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠫࡩࡧࡳࡩࡏࡤࡲ࡮࡬ࡥࡴࡶࡘࡶࡱ࠭ઙ")]
	except: pass
	try: b7ZuBLGKRfTDn = bKTm4excAd[uulNDCPyef78(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬચ")][ggjO5CrKVRPITaesWkxD(u"࠭ࡦࡰࡴࡰࡥࡹࡹࠧછ")]
	except: pass
	try: OfAjznPq7xu4NQTGry = MS76nQWTBvAud[Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧજ")][EE1jeHnIoad(u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩઝ")]
	except: pass
	try: FoTAbnCgO9SUzhR3GE5Pix6YW = bKTm4excAd[wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩઞ")][QjAINyUC7MDRq5d8e4vl9(u"ࠪࡥࡩࡧࡰࡵ࡫ࡹࡩࡋࡵࡲ࡮ࡣࡷࡷࠬટ")]
	except: pass
	try: GhrfIybSpeTu2qWmD = MS76nQWTBvAud[FgXzMs0YSDt(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫઠ")][LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠬࡧࡤࡢࡲࡷ࡭ࡻ࡫ࡆࡰࡴࡰࡥࡹࡹࠧડ")]
	except: pass
	if not FGRX4myP68S:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,uulNDCPyef78(u"࠭ࡇࡆࡖࠪઢ"),YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,o1INZ3ViQqS0Uw5z6kMjbv(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠻ࡺࡨࠨણ"))
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
	if not any([g84qoUGATaZIfitEkBwmFPOL,Mlk73Vps0mjrGh2EH,XVWGt2owfl6L7JnKmvpOjsEc,iZI3tkg5WEdq80pe1VGT,b7ZuBLGKRfTDn,OfAjznPq7xu4NQTGry,FoTAbnCgO9SUzhR3GE5Pix6YW,GhrfIybSpeTu2qWmD]):
		XgbcrBleMx5LYWzKjFCHIOP = EcQxOa3RJm86WjTKA.findall(AAbvaXV2DQzfNHdm4U3tT(u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡨࡷࡸࡧࡧࡦࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫત"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		mmv7XkyreCIJGUqhTYi5KB6DWSn = EcQxOa3RJm86WjTKA.findall(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠩࠥࡴࡱࡧࡹࡦࡴࡈࡶࡷࡵࡲࡎࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡳࡶࡤࡵࡩࡦࡹ࡯࡯ࠤ࠽ࡠࢀࠨࡲࡶࡰࡶࠦ࠿ࡢ࡛࡝ࡽࠥࡸࡪࡾࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪથ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		kQ90RuKEmXbqfP6as7pe4MIdvoG1cH = EcQxOa3RJm86WjTKA.findall(s5WMHyQN4mpie(u"ࠪࠦࡵࡲࡡࡺࡧࡵࡉࡷࡸ࡯ࡳࡏࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠥ࠾ࡡࢁࠢࡳࡧࡤࡷࡴࡴࠢ࠻ࡽࠥࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩદ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		AAiROomtT6LBXpcaWPSC = EcQxOa3RJm86WjTKA.findall(sIzDXlTHYUC5L3xZGnr(u"ࠫࠧࡶ࡬ࡢࡻࡨࡶࡊࡸࡲࡰࡴࡐࡩࡸࡹࡡࡨࡧࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡵࡸࡦࡷ࡫ࡡࡴࡱࡱࠦ࠿ࢁࠢࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ધ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		yNHtZ2UL56qRM3vYxi,SqAcjxamEseGnNKvRrOTZ8oF15IiLW,sA4tHg9dZvLWYfqmyUc = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
		try: yNHtZ2UL56qRM3vYxi = bKTm4excAd[C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬࡶ࡬ࡢࡻࡤࡦ࡮ࡲࡩࡵࡻࡖࡸࡦࡺࡵࡴࠩન")][PlpyFa9QMKXxOD1cvHzmI(u"࠭ࡥࡳࡴࡲࡶࡘࡩࡲࡦࡧࡱࠫ઩")][FgXzMs0YSDt(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡅ࡫ࡤࡰࡴ࡭ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨપ")][PlpyFa9QMKXxOD1cvHzmI(u"ࠨࡶ࡬ࡸࡱ࡫ࠧફ")][ggjO5CrKVRPITaesWkxD(u"ࠩࡵࡹࡳࡹࠧબ")][D2D96X5NGamBhrFwvL8VEbqiSfZIl][OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠪࡸࡪࡾࡴࠨભ")]
		except:
			try: yNHtZ2UL56qRM3vYxi = MS76nQWTBvAud[sJw9QWiq1Kr0xfeVRI(u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨમ")][ggjO5CrKVRPITaesWkxD(u"ࠬ࡫ࡲࡳࡱࡵࡗࡨࡸࡥࡦࡰࠪય")][Hr25gta6XcqO(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳࡄࡪࡣ࡯ࡳ࡬ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧર")][Gcw2nelTR864XCVruO3mAFqI5a(u"ࠧࡵ࡫ࡷࡰࡪ࠭઱")][wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠨࡴࡸࡲࡸ࠭લ")][D2D96X5NGamBhrFwvL8VEbqiSfZIl][V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠩࡷࡩࡽࡺࠧળ")]
			except: pass
		try: SqAcjxamEseGnNKvRrOTZ8oF15IiLW = bKTm4excAd[O3OVuapf0YFjbm5oUQDg(u"ࠪࡴࡱࡧࡹࡢࡤ࡬ࡰ࡮ࡺࡹࡔࡶࡤࡸࡺࡹࠧ઴")][oRJAfwD957WkUyBM1Ehu8m(u"ࠫࡪࡸࡲࡰࡴࡖࡧࡷ࡫ࡥ࡯ࠩવ")][ggjO5CrKVRPITaesWkxD(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡊࡩࡢ࡮ࡲ࡫ࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭શ")][vU6DxuzPwMpg(u"࠭ࡤࡪࡣ࡯ࡳ࡬ࡓࡥࡴࡵࡤ࡫ࡪࡹࠧષ")][D2D96X5NGamBhrFwvL8VEbqiSfZIl][s5WMHyQN4mpie(u"ࠧࡳࡷࡱࡷࠬસ")][D2D96X5NGamBhrFwvL8VEbqiSfZIl][wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠨࡶࡨࡼࡹ࠭હ")]
		except:
			try: SqAcjxamEseGnNKvRrOTZ8oF15IiLW = MS76nQWTBvAud[N6NGJ4vpmidqMCh7yo(u"ࠩࡳࡰࡦࡿࡡࡣ࡫࡯࡭ࡹࡿࡓࡵࡣࡷࡹࡸ࠭઺")][aOQTKXFL54Nl60Zhp3MbE(u"ࠪࡩࡷࡸ࡯ࡳࡕࡦࡶࡪ࡫࡮ࠨ઻")][OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡉ࡯ࡡ࡭ࡱࡪࡖࡪࡴࡤࡦࡴࡨࡶ઼ࠬ")][ssynAg0zhSkoCpOMDV9(u"ࠬࡪࡩࡢ࡮ࡲ࡫ࡒ࡫ࡳࡴࡣࡪࡩࡸ࠭ઽ")][D2D96X5NGamBhrFwvL8VEbqiSfZIl][LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠭ࡲࡶࡰࡶࠫા")][D2D96X5NGamBhrFwvL8VEbqiSfZIl][ssynAg0zhSkoCpOMDV9(u"ࠧࡵࡧࡻࡸࠬિ")]
			except: pass
		try: sA4tHg9dZvLWYfqmyUc = bKTm4excAd[uulNDCPyef78(u"ࠨࡲ࡯ࡥࡾࡧࡢࡪ࡮࡬ࡸࡾ࡙ࡴࡢࡶࡸࡷࠬી")][vU6DxuzPwMpg(u"ࠩࡵࡩࡦࡹ࡯࡯ࠩુ")]
		except:
			try: sA4tHg9dZvLWYfqmyUc = MS76nQWTBvAud[FgXzMs0YSDt(u"ࠪࡴࡱࡧࡹࡢࡤ࡬ࡰ࡮ࡺࡹࡔࡶࡤࡸࡺࡹࠧૂ")][aOQTKXFL54Nl60Zhp3MbE(u"ࠫࡷ࡫ࡡࡴࡱࡱࠫૃ")]
			except: pass
		os0MYrFVyKcBOC38gAZIQf2Jk = fy8iFgEkrO12NR9TWBI35sjY6qHvV
		NvUG2Xdomi5sDyJVzQLtq8RcWh = n0nFOd4yR97fQzNLSW+CsDcLqQUVK4YBvHFW1(u"ࠬํะศࠢส่ๆ๐ฯ๋๊ࠣๅ๏ํࠠๆึๆ่ฮࠦ࠮࠯ࠢฦ์ࠥเ๊า่่ࠢฬฬๅࠡๆห฽฻ࠦวๅ็ึฮำีๅ๋่ࠣ࠲࠳ࠦร้ࠢ฽๎ึࠦๅห๊ไีࠥอไร่ࠣ࠲࠳ࠦร้ࠢํ์ฯ๐่ษࠢํัฯอฬࠡึํล๋ࠥอะัࠣ࠲࠳ࠦร้ࠢํ์ฯ๐่ษࠢ฽๎ึࠦโศัิࠤศ์๋ࠠึ฽่ࠥอไโ์า๎ํࠦวๅฤ้ࠫૄ")+T7ASIp1ZYwio9HQ8cObJK
		if XgbcrBleMx5LYWzKjFCHIOP or mmv7XkyreCIJGUqhTYi5KB6DWSn or kQ90RuKEmXbqfP6as7pe4MIdvoG1cH or AAiROomtT6LBXpcaWPSC or yNHtZ2UL56qRM3vYxi or SqAcjxamEseGnNKvRrOTZ8oF15IiLW or sA4tHg9dZvLWYfqmyUc:
			if   XgbcrBleMx5LYWzKjFCHIOP: kf40tulvSA7z9RqNF5dXca3seMD = XgbcrBleMx5LYWzKjFCHIOP[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			elif mmv7XkyreCIJGUqhTYi5KB6DWSn: kf40tulvSA7z9RqNF5dXca3seMD = mmv7XkyreCIJGUqhTYi5KB6DWSn[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			elif kQ90RuKEmXbqfP6as7pe4MIdvoG1cH: kf40tulvSA7z9RqNF5dXca3seMD = kQ90RuKEmXbqfP6as7pe4MIdvoG1cH[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			elif AAiROomtT6LBXpcaWPSC: kf40tulvSA7z9RqNF5dXca3seMD = AAiROomtT6LBXpcaWPSC[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			elif yNHtZ2UL56qRM3vYxi: kf40tulvSA7z9RqNF5dXca3seMD = yNHtZ2UL56qRM3vYxi
			elif SqAcjxamEseGnNKvRrOTZ8oF15IiLW: kf40tulvSA7z9RqNF5dXca3seMD = SqAcjxamEseGnNKvRrOTZ8oF15IiLW
			elif sA4tHg9dZvLWYfqmyUc: kf40tulvSA7z9RqNF5dXca3seMD = sA4tHg9dZvLWYfqmyUc
			os0MYrFVyKcBOC38gAZIQf2Jk = kf40tulvSA7z9RqNF5dXca3seMD.replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE)
			NvUG2Xdomi5sDyJVzQLtq8RcWh += O3OVuapf0YFjbm5oUQDg(u"࠭࡜࡯࡞ࡱࠫૅ")+WydpaVx5YmLoCiIgA34eEBlb+EE1jeHnIoad(u"ࠧาีส่ฮࠦๅ็ࠢํ์ฯ๐่ษࠩ૆")+T7ASIp1ZYwio9HQ8cObJK+C0qrknitpM4Z+os0MYrFVyKcBOC38gAZIQf2Jk
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,FgXzMs0YSDt(u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠣ์ฬ๊ๅษำ่ะࠬે"),NvUG2Xdomi5sDyJVzQLtq8RcWh)
		if os0MYrFVyKcBOC38gAZIQf2Jk: os0MYrFVyKcBOC38gAZIQf2Jk = sIzDXlTHYUC5L3xZGnr(u"ࠩ࠽ࠤࠬૈ")+os0MYrFVyKcBOC38gAZIQf2Jk
		return FgXzMs0YSDt(u"ࠪࡉࡷࡸ࡯ࡳࠢࠣࠤࠥࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࡜ࡓ࡚࡚ࡕࡃࡇࠣࡊࡦ࡯࡬ࡦࡦࠪૉ")+os0MYrFVyKcBOC38gAZIQf2Jk,[],[]
	ffGqw1pZBsR9JKt5hojOFgNnxadr,cYmqwKtC6nEN7gPB5DyahezGdUSJ,QFnOHlJtW3Tv09Biq7DRy = [],[],[]
	tQ2gHq9akwR6bnyFZWPOY0D = [g84qoUGATaZIfitEkBwmFPOL,Mlk73Vps0mjrGh2EH]
	A4AtCPrHDkxcYvNSn8zqlh2R19gU = [XVWGt2owfl6L7JnKmvpOjsEc,iZI3tkg5WEdq80pe1VGT]
	CXTL7NPUAE,tyLFkShUNjxfb4ilGJzcErn3oeROs = [],[]
	for vZYejnw1gd2QaOAoGyBfb86JsRqI in b7ZuBLGKRfTDn+OfAjznPq7xu4NQTGry:
		if vZYejnw1gd2QaOAoGyBfb86JsRqI[Hr25gta6XcqO(u"ࠫ࡮ࡺࡡࡨࠩ૊")] not in CXTL7NPUAE:
			CXTL7NPUAE.append(vZYejnw1gd2QaOAoGyBfb86JsRqI[CsDcLqQUVK4YBvHFW1(u"ࠬ࡯ࡴࡢࡩࠪો")])
			tyLFkShUNjxfb4ilGJzcErn3oeROs.append(vZYejnw1gd2QaOAoGyBfb86JsRqI)
	CXTL7NPUAE,yNhGCHjOBWweL2qrStgp61f4EV = [],[]
	for vZYejnw1gd2QaOAoGyBfb86JsRqI in FoTAbnCgO9SUzhR3GE5Pix6YW+GhrfIybSpeTu2qWmD:
		if vZYejnw1gd2QaOAoGyBfb86JsRqI[FgXzMs0YSDt(u"࠭ࡩࡵࡣࡪࠫૌ")] not in CXTL7NPUAE:
			CXTL7NPUAE.append(vZYejnw1gd2QaOAoGyBfb86JsRqI[N6NGJ4vpmidqMCh7yo(u"ࠧࡪࡶࡤ࡫્ࠬ")])
			yNhGCHjOBWweL2qrStgp61f4EV.append(vZYejnw1gd2QaOAoGyBfb86JsRqI)
	for dict in tyLFkShUNjxfb4ilGJzcErn3oeROs+yNhGCHjOBWweL2qrStgp61f4EV:
		if LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨ࡫ࡷࡥ࡬࠭૎") in list(dict.keys()): dict[KfHAW8VGbrxi(u"ࠩ࡬ࡸࡦ࡭ࠧ૏")] = str(dict[s5WMHyQN4mpie(u"ࠪ࡭ࡹࡧࡧࠨૐ")])
		if sJw9QWiq1Kr0xfeVRI(u"ࠫ࡫ࡶࡳࠨ૑") in list(dict.keys()): dict[I18uSKaWhgTBeYUPD4sr(u"ࠬ࡬ࡰࡴࠩ૒")] = str(dict[FmYoGejTnwKME7d9zPc(u"࠭ࡦࡱࡵࠪ૓")])
		if OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩ૔") in list(dict.keys()): dict[FmYoGejTnwKME7d9zPc(u"ࠨࡶࡼࡴࡪ࠭૕")] = dict[vU6DxuzPwMpg(u"ࠩࡰ࡭ࡲ࡫ࡔࡺࡲࡨࠫ૖")]
		if V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪࡥࡺࡪࡩࡰࡕࡤࡱࡵࡲࡥࡓࡣࡷࡩࠬ૗") in list(dict.keys()): dict[QjAINyUC7MDRq5d8e4vl9(u"ࠫࡦࡻࡤࡪࡱࡢࡷࡦࡳࡰ࡭ࡧࡢࡶࡦࡺࡥࠨ૘")] = str(dict[FgXzMs0YSDt(u"ࠬࡧࡵࡥ࡫ࡲࡗࡦࡳࡰ࡭ࡧࡕࡥࡹ࡫ࠧ૙")])
		if AAbvaXV2DQzfNHdm4U3tT(u"࠭ࡡࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭૚") in list(dict.keys()): dict[V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨ૛")] = str(dict[EE1jeHnIoad(u"ࠨࡣࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡳࠨ૜")])
		if PlpyFa9QMKXxOD1cvHzmI(u"ࠩࡺ࡭ࡩࡺࡨࠨ૝") in list(dict.keys()): dict[Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪࡷ࡮ࢀࡥࠨ૞")] = str(dict[Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫࡼ࡯ࡤࡵࡪࠪ૟")])+PlpyFa9QMKXxOD1cvHzmI(u"ࠬࡾࠧૠ")+str(dict[I18uSKaWhgTBeYUPD4sr(u"࠭ࡨࡦ࡫ࡪ࡬ࡹ࠭ૡ")])
		if FgXzMs0YSDt(u"ࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪૢ") in list(dict.keys()): dict[FmYoGejTnwKME7d9zPc(u"ࠨ࡫ࡱ࡭ࡹ࠭ૣ")] = dict[N6NGJ4vpmidqMCh7yo(u"ࠩ࡬ࡲ࡮ࡺࡒࡢࡰࡪࡩࠬ૤")][FgXzMs0YSDt(u"ࠪࡷࡹࡧࡲࡵࠩ૥")]+Gcw2nelTR864XCVruO3mAFqI5a(u"ࠫ࠲࠭૦")+dict[s5WMHyQN4mpie(u"ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨ૧")][wdftVMyzF17cYETHu(u"࠭ࡥ࡯ࡦࠪ૨")]
		if Hr25gta6XcqO(u"ࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫ૩") in list(dict.keys()): dict[oRJAfwD957WkUyBM1Ehu8m(u"ࠨ࡫ࡱࡨࡪࡾࠧ૪")] = dict[aOQTKXFL54Nl60Zhp3MbE(u"ࠩ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪ࠭૫")][EE1jeHnIoad(u"ࠪࡷࡹࡧࡲࡵࠩ૬")]+KfHAW8VGbrxi(u"ࠫ࠲࠭૭")+dict[AAbvaXV2DQzfNHdm4U3tT(u"ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩ૮")][vU6DxuzPwMpg(u"࠭ࡥ࡯ࡦࠪ૯")]
		if I18uSKaWhgTBeYUPD4sr(u"ࠧࡢࡸࡨࡶࡦ࡭ࡥࡃ࡫ࡷࡶࡦࡺࡥࠨ૰") in list(dict.keys()): dict[PlpyFa9QMKXxOD1cvHzmI(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ૱")] = dict[jL5CrsRwebpyDVXUc1EQP(u"ࠩࡤࡺࡪࡸࡡࡨࡧࡅ࡭ࡹࡸࡡࡵࡧࠪ૲")]
		if O3OVuapf0YFjbm5oUQDg(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ૳") in list(dict.keys()) and int(dict[uulNDCPyef78(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ૴")])>EE1jeHnIoad(u"࠱࠲࠳࠵࠶࠷࠹࠳࠴ൊ"): del dict[s5WMHyQN4mpie(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭૵")]
		if FmYoGejTnwKME7d9zPc(u"࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦࡅ࡬ࡴ࡭࡫ࡲࠨ૶") in list(dict.keys()):
			N0gcn4KRiGCeY = dict[Hr25gta6XcqO(u"ࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡆ࡭ࡵ࡮ࡥࡳࠩ૷")].split(jL5CrsRwebpyDVXUc1EQP(u"ࠨࠨࠪ૸"))
			for j25T6eKhaMk3 in N0gcn4KRiGCeY:
				key,value = j25T6eKhaMk3.split(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠩࡀࠫૹ"),EE1jeHnIoad(u"࠲ോ"))
				dict[key] = U2Z7CVFftTmLeK3nzEbQPGga(value)
		if sJw9QWiq1Kr0xfeVRI(u"ࠪࡹࡷࡲࠧૺ") in list(dict.keys()): dict[ssynAg0zhSkoCpOMDV9(u"ࠫࡺࡸ࡬ࠨૻ")] = U2Z7CVFftTmLeK3nzEbQPGga(dict[AAbvaXV2DQzfNHdm4U3tT(u"ࠬࡻࡲ࡭ࠩૼ")])
		ffGqw1pZBsR9JKt5hojOFgNnxadr.append(dict)
	shqUmoR5rWD4txldPG = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	V8VUTiOk4tpgHjIAaYSF2Wf1 = EcQxOa3RJm86WjTKA.findall(vU6DxuzPwMpg(u"࠭ࠢࠩ࠱ࡶ࠳ࡵࡲࡡࡺࡧࡵ࠳ࡡࡽࠪࡀ࠱ࡳࡰࡦࡿࡥࡳࡡ࡬ࡥࡸ࠴ࡶࡧ࡮ࡶࡩࡹ࠵ࡥ࡯ࡡ࠱࠲࠴ࡨࡡࡴࡧ࠱࡮ࡸ࠯ࠢࠨ૽"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if V8VUTiOk4tpgHjIAaYSF2Wf1:
		V8VUTiOk4tpgHjIAaYSF2Wf1 = I4t9qonjrm.SITESURLS[FgXzMs0YSDt(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ૾")][D2D96X5NGamBhrFwvL8VEbqiSfZIl]+V8VUTiOk4tpgHjIAaYSF2Wf1[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,ssynAg0zhSkoCpOMDV9(u"ࠨࡉࡈࡘࠬ૿"),V8VUTiOk4tpgHjIAaYSF2Wf1,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,aOQTKXFL54Nl60Zhp3MbE(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠸ࡵࡪࠪ଀"))
		shqUmoR5rWD4txldPG = E6ECvznP9m5sWFMu.content
	if shqUmoR5rWD4txldPG:
		if KfHAW8VGbrxi(u"ࠪࡷࡵࡃࡳࡪࡩࠪଁ") in Zj9KqhyTuOG4a3fgX+YAy2RPLQ3DO:
			import youtube_signature.cipher as q7eEVMNg81ZyRIcwlHkYW4SzaXi,youtube_signature.json_script_engine as zI2Rxk1Yvm8eTp
			N0gcn4KRiGCeY = ViZjBX0el29Ct53hExm8Kfvsr6kwdS.N0gcn4KRiGCeY.Cipher()
			N0gcn4KRiGCeY._object_cache = {}
			j4GsNAw9dEtXYV5B8eyLZaSfknK = N0gcn4KRiGCeY._load_javascript(shqUmoR5rWD4txldPG)
			prSk6fcObXDiN8 = LB7TcZnGYdfw5lWU1RH3Oztu9PyA(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠫࡸࡺࡲࠨଂ"),str(j4GsNAw9dEtXYV5B8eyLZaSfknK))
			TPNWgy5uhbcYDfjQx = ViZjBX0el29Ct53hExm8Kfvsr6kwdS.z0NBRFtakwn87QMvJcP35rTmo4VSX.JsonScriptEngine(prSk6fcObXDiN8)
		ImvPoUAijf146t = EcQxOa3RJm86WjTKA.findall(aOQTKXFL54Nl60Zhp3MbE(u"ࡷ࠭ࠧࠨࠪࡂࡼ࠮ࠐࠉࠊࠋࠫࡃ࠿ࠐࠉࠊࠋࠌࡠ࠳࡭ࡥࡵ࡞ࠫࠦࡳࠨ࡜ࠪ࡞ࠬࠪࠫࡢࠨࡣ࠿ࡿࠎࠎࠏࠉࠊࠪࡂ࠾ࠏࠏࠉࠊࠋࠌࡦࡂ࡙ࡴࡳ࡫ࡱ࡫ࡡ࠴ࡦࡳࡱࡰࡇ࡭ࡧࡲࡄࡱࡧࡩࡡ࠮࠱࠲࠲࡟࠭ࢁࠐࠉࠊࠋࠌࠍ࠭ࡅࡐ࠽ࡵࡷࡶࡤ࡯ࡤࡹࡀ࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡥࠤ࠯࡟࠮࠭ࠫࠬ࡜ࠩࡤࡀࠦࡳࡴࠢ࡝࡝࡟࠯࠭ࡅࡐ࠾ࡵࡷࡶࡤ࡯ࡤࡹࠫ࡟ࡡࠏࠏࠉࠊࠋࠬࠎࠎࠏࠉࠊࠪࡂ࠾ࠏࠏࠉࠊࠋࠌ࠰ࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹ࡠࠦࡠ࠯ࡡ࠮ࡡ࡝ࠫࠬࡃ࠱ࡩ࠽ࡢ࡞࠱ࠎࠎࠏࠉࠊࠋࠫࡃ࠿ࠐࠉࠊࠋࠌࠍࠎ࡭ࡥࡵ࡞ࠫࡦࡡ࠯ࡼࠋࠋࠌࠍࠎࠏࠉ࡜ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࡣࠩࡣࠫ࡝࡝ࡥࡠࡢࡢࡼ࡝ࡾࡱࡹࡱࡲࠊࠊࠋࠌࠍࠎ࠯࡜ࠪࠨࠩࡠ࠭ࡩ࠽ࡽࠌࠌࠍࠎࠏ࡜ࡣࠪࡂࡔࡁࡼࡡࡳࡀ࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡥࠤ࡞࠭ࠬࡁࠏࠏࠉࠊࠫࠫࡃࡕࡂ࡮ࡧࡷࡱࡧࡃࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࡡࠧࡡ࠰࠯ࠨࡀ࠼࡟࡟࠭ࡅࡐ࠽࡫ࡧࡼࡃࡢࡤࠬࠫ࡟ࡡ࠮ࡅ࡜ࠩ࡝ࡤ࠱ࡿࡇ࡛࠭࡟࡟࠭ࠏࠏࠉࠊࠪࡂࠬࡻࡧࡲࠪ࠮࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡥࠤ࡞࠭࡟࠲ࡸ࡫ࡴ࡝ࠪࠫࡃ࠿ࠨ࡮ࠬࠤࡿ࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡟ࠥ࡟࠮࠭ࡡ࠲ࠨࡀࡒࡀࡺࡦࡸࠩ࡝ࠫࠬࠫࠬ࠭ଃ"),shqUmoR5rWD4txldPG)
		if ImvPoUAijf146t:
			ImvPoUAijf146t = EcQxOa3RJm86WjTKA.findall(ImvPoUAijf146t[D2D96X5NGamBhrFwvL8VEbqiSfZIl][sIzDXlTHYUC5L3xZGnr(u"࠴ൌ")]+uulNDCPyef78(u"࠭࠽࡝࡝ࠫ࠲࠯ࡅࠩ࡝࡟ࠪ଄"),shqUmoR5rWD4txldPG,EcQxOa3RJm86WjTKA.DOTALL)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			niN4c1gy3YOXE0kfBZ5DPV2 = shqUmoR5rWD4txldPG.find(ImvPoUAijf146t+QjAINyUC7MDRq5d8e4vl9(u"ࠧ࠾ࡨࡸࡲࡨࡺࡩࡰࡰࠫࠫଅ"))
			Zk6QupINYF = shqUmoR5rWD4txldPG.find(LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨࡿ࠾ࠫଆ"), niN4c1gy3YOXE0kfBZ5DPV2)
			acs92MHxvVuqPfLwhQAgkEilzdCU1e = shqUmoR5rWD4txldPG[niN4c1gy3YOXE0kfBZ5DPV2:Zk6QupINYF]+FmYoGejTnwKME7d9zPc(u"ࠩࢀࠫଇ")
			k8n3NyjPseiYrVBIOGHqZmCSE = EcQxOa3RJm86WjTKA.findall(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠪࡺࡦࡸࠠ࠯ࠬࡂࡁ࠭࠴ࠪࡀࠫ࡟࠲ࠬଈ"),acs92MHxvVuqPfLwhQAgkEilzdCU1e,EcQxOa3RJm86WjTKA.DOTALL)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			TBSG6khzaVWrficgYlp0RNFKHZ8Itn = EcQxOa3RJm86WjTKA.findall(Hr25gta6XcqO(u"ࠫ࡮࡬࡜ࠩࡶࡼࡴࡪࡵࡦࠡ࠰࠭ࡃࡂࡃ࠽ࠣࡷࡱࡨࡪ࡬ࡩ࡯ࡧࡧࠦࡡ࠯ࡲࡦࡶࡸࡶࡳࠦࠧଉ")+k8n3NyjPseiYrVBIOGHqZmCSE+wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠬࡁࠧଊ"),acs92MHxvVuqPfLwhQAgkEilzdCU1e,EcQxOa3RJm86WjTKA.DOTALL)
			if TBSG6khzaVWrficgYlp0RNFKHZ8Itn: acs92MHxvVuqPfLwhQAgkEilzdCU1e = acs92MHxvVuqPfLwhQAgkEilzdCU1e.replace(TBSG6khzaVWrficgYlp0RNFKHZ8Itn[D2D96X5NGamBhrFwvL8VEbqiSfZIl],fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			FycAWj8SDozdZu93MrEeLUb6hBw = {}
			for dict in ffGqw1pZBsR9JKt5hojOFgNnxadr:
				url = dict[ggjO5CrKVRPITaesWkxD(u"࠭ࡵࡳ࡮ࠪଋ")]
				if aOQTKXFL54Nl60Zhp3MbE(u"ࠧࠧࡰࡀࠫଌ") in url:
					v0r3iucyoFqBTH2dPsWeINOZ = url.split(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨࠨࡱࡁࠬ଍"),BkM54Kr7Qbqn)[BkM54Kr7Qbqn].split(O3OVuapf0YFjbm5oUQDg(u"ࠩࠩࠫ଎"),BkM54Kr7Qbqn)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
					if v0r3iucyoFqBTH2dPsWeINOZ not in list(FycAWj8SDozdZu93MrEeLUb6hBw.keys()): FycAWj8SDozdZu93MrEeLUb6hBw[v0r3iucyoFqBTH2dPsWeINOZ] = jdUaoWsQxZJbuYTO1Cqey83XBnpMG(acs92MHxvVuqPfLwhQAgkEilzdCU1e,[ImvPoUAijf146t,v0r3iucyoFqBTH2dPsWeINOZ])
					dict[uulNDCPyef78(u"ࠪࡹࡷࡲࠧଏ")] = url.replace(PlpyFa9QMKXxOD1cvHzmI(u"ࠫࠫࡴ࠽ࠨଐ")+v0r3iucyoFqBTH2dPsWeINOZ+ggjO5CrKVRPITaesWkxD(u"ࠬࠬࠧ଑"),KfHAW8VGbrxi(u"࠭ࠦ࡯࠿ࠪ଒")+FycAWj8SDozdZu93MrEeLUb6hBw[v0r3iucyoFqBTH2dPsWeINOZ]+C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧࠧࠩଓ"))
	for dict in ffGqw1pZBsR9JKt5hojOFgNnxadr:
		url = dict[LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨࡷࡵࡰࠬଔ")]
		if aOQTKXFL54Nl60Zhp3MbE(u"ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡂ࠭କ") in url or url.count(SnhLjmfeJC(u"ࠪࡷ࡮࡭࠽ࠨଖ"))>BkM54Kr7Qbqn:
			cYmqwKtC6nEN7gPB5DyahezGdUSJ.append(dict)
		elif shqUmoR5rWD4txldPG and O3OVuapf0YFjbm5oUQDg(u"ࠫࡸ࠭ଗ") in list(dict.keys()) and CsDcLqQUVK4YBvHFW1(u"ࠬࡹࡰࠨଘ") in list(dict.keys()):
			rrUPaQOVSnwGTIo4m9ydR = TPNWgy5uhbcYDfjQx.execute(dict[LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠭ࡳࠨଙ")])
			if rrUPaQOVSnwGTIo4m9ydR!=dict[I18uSKaWhgTBeYUPD4sr(u"ࠧࡴࠩଚ")]:
				dict[FgXzMs0YSDt(u"ࠨࡷࡵࡰࠬଛ")] = url+EE1jeHnIoad(u"ࠩࠩࠫଜ")+dict[QjAINyUC7MDRq5d8e4vl9(u"ࠪࡷࡵ࠭ଝ")]+KfHAW8VGbrxi(u"ࠫࡂ࠭ଞ")+rrUPaQOVSnwGTIo4m9ydR
				cYmqwKtC6nEN7gPB5DyahezGdUSJ.append(dict)
	for dict in cYmqwKtC6nEN7gPB5DyahezGdUSJ:
		BIbU1q2NrFX,QEROc1sLiP2UbxgGfz80aq3FuAJDd,aEzov7fcuTlmikG,HE7eaGoC6ixPIzV93A,TF5KrGj6nP3U4hJQkwpI,gn2DUcWhvjpC4ZR0lr3bJO61GPVX = sJw9QWiq1Kr0xfeVRI(u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭ଟ"),N6NGJ4vpmidqMCh7yo(u"࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧଠ"),CsDcLqQUVK4YBvHFW1(u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨଡ"),N6NGJ4vpmidqMCh7yo(u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩଢ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV,wdftVMyzF17cYETHu(u"ࠩ࠳ࠫଣ")
		try:
			LZdog0KvJRUDVkNmn = dict[sJw9QWiq1Kr0xfeVRI(u"ࠪࡸࡾࡶࡥࠨତ")]
			LZdog0KvJRUDVkNmn = LZdog0KvJRUDVkNmn.replace(ggjO5CrKVRPITaesWkxD(u"ࠫ࠰࠭ଥ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			items = EcQxOa3RJm86WjTKA.findall(LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠬ࠮࠮ࠫࡁࠬ࠳࠭࠴ࠪࡀࠫ࠾࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧଦ"),LZdog0KvJRUDVkNmn,EcQxOa3RJm86WjTKA.DOTALL)
			HE7eaGoC6ixPIzV93A,BIbU1q2NrFX,TF5KrGj6nP3U4hJQkwpI = items[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			jjPcTFdn6WahK9Y0kGr = TF5KrGj6nP3U4hJQkwpI.split(I18uSKaWhgTBeYUPD4sr(u"࠭ࠬࠨଧ"))
			QEROc1sLiP2UbxgGfz80aq3FuAJDd = fy8iFgEkrO12NR9TWBI35sjY6qHvV
			for j25T6eKhaMk3 in jjPcTFdn6WahK9Y0kGr: QEROc1sLiP2UbxgGfz80aq3FuAJDd += j25T6eKhaMk3.split(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧ࠯ࠩନ"))[D2D96X5NGamBhrFwvL8VEbqiSfZIl]+Gcw2nelTR864XCVruO3mAFqI5a(u"ࠨ࠮ࠪ଩")
			QEROc1sLiP2UbxgGfz80aq3FuAJDd = QEROc1sLiP2UbxgGfz80aq3FuAJDd.strip(QjAINyUC7MDRq5d8e4vl9(u"ࠩ࠯ࠫପ"))
			if wdftVMyzF17cYETHu(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫଫ") in list(dict.keys()): gn2DUcWhvjpC4ZR0lr3bJO61GPVX = str(int(dict[O3OVuapf0YFjbm5oUQDg(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬବ")])//wdftVMyzF17cYETHu(u"࠴࠴࠷࠺്"))+I18uSKaWhgTBeYUPD4sr(u"ࠬࡱࡢࡱࡵࠣࠤࠬଭ")
			else: gn2DUcWhvjpC4ZR0lr3bJO61GPVX = fy8iFgEkrO12NR9TWBI35sjY6qHvV
			if HE7eaGoC6ixPIzV93A==o1INZ3ViQqS0Uw5z6kMjbv(u"࠭ࡴࡦࡺࡷࠫମ"): continue
			elif CsDcLqQUVK4YBvHFW1(u"ࠧ࠭ࠩଯ") in LZdog0KvJRUDVkNmn:
				HE7eaGoC6ixPIzV93A = N6NGJ4vpmidqMCh7yo(u"ࠨࡃ࠮࡚ࠬର")
				aEzov7fcuTlmikG = BIbU1q2NrFX+OOiSqkBcMPptI+gn2DUcWhvjpC4ZR0lr3bJO61GPVX+dict[o1INZ3ViQqS0Uw5z6kMjbv(u"ࠩࡶ࡭ࡿ࡫ࠧ଱")].split(Hr25gta6XcqO(u"ࠪࡼࠬଲ"))[BkM54Kr7Qbqn]
			elif HE7eaGoC6ixPIzV93A==FmYoGejTnwKME7d9zPc(u"ࠫࡻ࡯ࡤࡦࡱࠪଳ"):
				HE7eaGoC6ixPIzV93A = QjAINyUC7MDRq5d8e4vl9(u"ࠬ࡜ࡩࡥࡧࡲࠫ଴")
				aEzov7fcuTlmikG = gn2DUcWhvjpC4ZR0lr3bJO61GPVX+dict[CsDcLqQUVK4YBvHFW1(u"࠭ࡳࡪࡼࡨࠫଵ")].split(SnhLjmfeJC(u"ࠧࡹࠩଶ"))[BkM54Kr7Qbqn]+OOiSqkBcMPptI+dict[aOQTKXFL54Nl60Zhp3MbE(u"ࠨࡨࡳࡷࠬଷ")]+wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠩࡩࡴࡸ࠭ସ")+OOiSqkBcMPptI+BIbU1q2NrFX
			elif HE7eaGoC6ixPIzV93A==Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠪࡥࡺࡪࡩࡰࠩହ"):
				HE7eaGoC6ixPIzV93A = vU6DxuzPwMpg(u"ࠫࡆࡻࡤࡪࡱࠪ଺")
				aEzov7fcuTlmikG = gn2DUcWhvjpC4ZR0lr3bJO61GPVX+str(int(dict[uulNDCPyef78(u"ࠬࡧࡵࡥ࡫ࡲࡣࡸࡧ࡭ࡱ࡮ࡨࡣࡷࡧࡴࡦࠩ଻")])/QjAINyUC7MDRq5d8e4vl9(u"࠵࠵࠶࠰ൎ"))+PlpyFa9QMKXxOD1cvHzmI(u"࠭࡫ࡩࡼࠣࠤ଼ࠬ")+dict[LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨଽ")]+CsDcLqQUVK4YBvHFW1(u"ࠨࡥ࡫ࠫା")+OOiSqkBcMPptI+BIbU1q2NrFX
		except:
			Okwr0yDIL1oVF9AlWRbduUtnzp = NFtwAhXgZB9u.format_exc()
			if Okwr0yDIL1oVF9AlWRbduUtnzp!=o1INZ3ViQqS0Uw5z6kMjbv(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬି"): CfgZ0zWP5XBpoGQwLUY.stderr.write(Okwr0yDIL1oVF9AlWRbduUtnzp)
		if s5WMHyQN4mpie(u"ࠪࡨࡺࡸ࠽ࠨୀ") in dict[AAbvaXV2DQzfNHdm4U3tT(u"ࠫࡺࡸ࡬ࠨୁ")]: rQ0jN7XkZPE1AYU = round(FgXzMs0YSDt(u"࠶࠮࠶൐")+float(dict[Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠬࡻࡲ࡭ࠩୂ")].split(Gcw2nelTR864XCVruO3mAFqI5a(u"࠭ࡤࡶࡴࡀࠫୃ"),PlpyFa9QMKXxOD1cvHzmI(u"࠶൏"))[BkM54Kr7Qbqn].split(FgXzMs0YSDt(u"ࠧࠧࠩୄ"),BkM54Kr7Qbqn)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]))
		elif FgXzMs0YSDt(u"ࠨࡣࡳࡴࡷࡵࡸࡅࡷࡵࡥࡹ࡯࡯࡯ࡏࡶࠫ୅") in list(dict.keys()): rQ0jN7XkZPE1AYU = round(sJw9QWiq1Kr0xfeVRI(u"࠰࠯࠷൑")+float(dict[EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩࡤࡴࡵࡸ࡯ࡹࡆࡸࡶࡦࡺࡩࡰࡰࡐࡷࠬ୆")])/PlpyFa9QMKXxOD1cvHzmI(u"࠲࠲࠳࠴൒"))
		else: rQ0jN7XkZPE1AYU = Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠪ࠴ࠬେ")
		if uulNDCPyef78(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬୈ") not in list(dict.keys()): gn2DUcWhvjpC4ZR0lr3bJO61GPVX = dict[oRJAfwD957WkUyBM1Ehu8m(u"ࠬࡹࡩࡻࡧࠪ୉")].split(sIzDXlTHYUC5L3xZGnr(u"࠭ࡸࠨ୊"))[BkM54Kr7Qbqn]
		else: gn2DUcWhvjpC4ZR0lr3bJO61GPVX = str(int(dict[sJw9QWiq1Kr0xfeVRI(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨୋ")])//OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠳࠳࠶࠹൓"))
		if FmYoGejTnwKME7d9zPc(u"ࠨ࡫ࡱ࡭ࡹ࠭ୌ") not in list(dict.keys()): dict[o1INZ3ViQqS0Uw5z6kMjbv(u"ࠩ࡬ࡲ࡮ࡺ୍ࠧ")] = C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠪ࠴࠲࠶ࠧ୎")
		dict[uulNDCPyef78(u"ࠫࡹ࡯ࡴ࡭ࡧࠪ୏")] = HE7eaGoC6ixPIzV93A+LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠬࡀࠠࠡࠩ୐")+aEzov7fcuTlmikG+s5WMHyQN4mpie(u"࠭ࠠࠡࠪࠪ୑")+QEROc1sLiP2UbxgGfz80aq3FuAJDd+I18uSKaWhgTBeYUPD4sr(u"ࠧ࠭ࠩ୒")+dict[FgXzMs0YSDt(u"ࠨ࡫ࡷࡥ࡬࠭୓")]+KfHAW8VGbrxi(u"ࠩࠬࠫ୔")
		dict[N6NGJ4vpmidqMCh7yo(u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ୕")] = aEzov7fcuTlmikG.split(OOiSqkBcMPptI)[D2D96X5NGamBhrFwvL8VEbqiSfZIl].split(CsDcLqQUVK4YBvHFW1(u"ࠫࡰࡨࡰࡴࠩୖ"))[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		dict[FgXzMs0YSDt(u"ࠬࡺࡹࡱࡧ࠵ࠫୗ")] = HE7eaGoC6ixPIzV93A
		dict[OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ୘")] = BIbU1q2NrFX
		dict[wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧࡤࡱࡧࡩࡨࡹࠧ୙")] = TF5KrGj6nP3U4hJQkwpI
		dict[Hr25gta6XcqO(u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪ୚")] = rQ0jN7XkZPE1AYU
		dict[Hr25gta6XcqO(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ୛")] = gn2DUcWhvjpC4ZR0lr3bJO61GPVX
		QFnOHlJtW3Tv09Biq7DRy.append(dict)
	Hahq91izYnkflGVU4u8spydeMJmNR,ND9Pqesb8k4xSVrMt2gUZ16dnOwXmT,PPD0R6A24nVF81wosCZ5ubKSqhUjJ,ppNs25yXe7Ha,rVoSLu4AFZfIRiUpecYOMxv = [],[],[],[],[]
	JpoIQh63N5DEbFdOlWUTwyHPV9,MELcIvXemV63xhaKykS1s,SFTkjvy1N0fU2Zs4z9V,nELiDzuH2VF,i9Jzy1sqFR6HYILkeBx4ZmGl2rUPn = [],[],[],[],[]
	for Ij0v4pNRgtZTJxLAUz in A4AtCPrHDkxcYvNSn8zqlh2R19gU:
		if not Ij0v4pNRgtZTJxLAUz: continue
		dict = {}
		dict[FmYoGejTnwKME7d9zPc(u"ࠪࡸࡾࡶࡥ࠳ࠩଡ଼")] = I18uSKaWhgTBeYUPD4sr(u"ࠫࡆ࠱ࡖࠨଢ଼")
		dict[FmYoGejTnwKME7d9zPc(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ୞")] = sJw9QWiq1Kr0xfeVRI(u"࠭࡭ࡱࡦࠪୟ")
		dict[C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧࡵ࡫ࡷࡰࡪ࠭ୠ")] = dict[wdftVMyzF17cYETHu(u"ࠨࡶࡼࡴࡪ࠸ࠧୡ")]+ssynAg0zhSkoCpOMDV9(u"ࠩ࠽ࠤࠥ࠭ୢ")+dict[FmYoGejTnwKME7d9zPc(u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬୣ")]+OOiSqkBcMPptI+KfHAW8VGbrxi(u"ࠫั๎ฯสࠢำ็๏ฯࠧ୤")
		dict[QjAINyUC7MDRq5d8e4vl9(u"ࠬࡻࡲ࡭ࠩ୥")] = Ij0v4pNRgtZTJxLAUz
		dict[wdftVMyzF17cYETHu(u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ୦")] = wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧ࠱ࠩ୧")
		dict[EE1jeHnIoad(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ୨")] = QjAINyUC7MDRq5d8e4vl9(u"ࠩ࠴࠵࠶࠸࠲࠳࠵࠶࠷ࠬ୩")
		QFnOHlJtW3Tv09Biq7DRy.append(dict)
	for YVkuvwWqgPCTslK50baZcBoR8Me in tQ2gHq9akwR6bnyFZWPOY0D:
		if not YVkuvwWqgPCTslK50baZcBoR8Me: continue
		JJVg3pG9Eayr5CAn,m06mELslRjhekXGW = kDKwn73e02jNdRLG8U4HxTgpVQqI(BfWYUAnyg6eONLjiuE,YVkuvwWqgPCTslK50baZcBoR8Me)
		s1RXrpDlKJejOc9WGNn2q6wug = list(zip(JJVg3pG9Eayr5CAn,m06mELslRjhekXGW))
		for title,bigdh7fpZYl4aT2keV in s1RXrpDlKJejOc9WGNn2q6wug:
			dict = {}
			dict[aOQTKXFL54Nl60Zhp3MbE(u"ࠪࡸࡾࡶࡥ࠳ࠩ୪")] = EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠫࡆ࠱ࡖࠨ୫")
			dict[OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ୬")] = I18uSKaWhgTBeYUPD4sr(u"࠭࡭࠴ࡷ࠻ࠫ୭")
			dict[O3OVuapf0YFjbm5oUQDg(u"ࠧࡶࡴ࡯ࠫ୮")] = bigdh7fpZYl4aT2keV
			if Hr25gta6XcqO(u"ࠨ࡭ࡥࡴࡸ࠭୯") in title: dict[V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ୰")] = title.split(AAbvaXV2DQzfNHdm4U3tT(u"ࠪ࡯ࡧࡶࡳࠨୱ"))[D2D96X5NGamBhrFwvL8VEbqiSfZIl].rsplit(OOiSqkBcMPptI)[-BkM54Kr7Qbqn]
			else: dict[FgXzMs0YSDt(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ୲")] = EE1jeHnIoad(u"ࠬ࠷࠰ࠨ୳")
			if title.count(OOiSqkBcMPptI)>BkM54Kr7Qbqn:
				OOnVxtP0TNWsci6HrEGqBm9boKF7g = title.rsplit(OOiSqkBcMPptI)[-XW57OCeGnFTLQbaqdrD9zM]
				if OOnVxtP0TNWsci6HrEGqBm9boKF7g.isdigit(): dict[sJw9QWiq1Kr0xfeVRI(u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ୴")] = OOnVxtP0TNWsci6HrEGqBm9boKF7g
				else: dict[QjAINyUC7MDRq5d8e4vl9(u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ୵")] = N6NGJ4vpmidqMCh7yo(u"ࠨ࠲࠳࠴࠵࠭୶")
			if title==EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩ࠰࠵ࠬ୷"): dict[FmYoGejTnwKME7d9zPc(u"ࠪࡸ࡮ࡺ࡬ࡦࠩ୸")] = dict[ggjO5CrKVRPITaesWkxD(u"ࠫࡹࡿࡰࡦ࠴ࠪ୹")]+FmYoGejTnwKME7d9zPc(u"ࠬࡀࠠࠡࠩ୺")+dict[EE1jeHnIoad(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ୻")]+OOiSqkBcMPptI+aOQTKXFL54Nl60Zhp3MbE(u"ࠧอ๊าอࠥึใ๋หࠪ୼")
			else: dict[Hr25gta6XcqO(u"ࠨࡶ࡬ࡸࡱ࡫ࠧ୽")] = dict[EE1jeHnIoad(u"ࠩࡷࡽࡵ࡫࠲ࠨ୾")]+sJw9QWiq1Kr0xfeVRI(u"ࠪ࠾ࠥࠦࠧ୿")+dict[C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭஀")]+OOiSqkBcMPptI+dict[oRJAfwD957WkUyBM1Ehu8m(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭஁")]+o1INZ3ViQqS0Uw5z6kMjbv(u"࠭࡫ࡣࡲࡶࠤࠥ࠭ஂ")+dict[FmYoGejTnwKME7d9zPc(u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨஃ")]
			QFnOHlJtW3Tv09Biq7DRy.append(dict)
	QFnOHlJtW3Tv09Biq7DRy = sorted(QFnOHlJtW3Tv09Biq7DRy,reverse=EsCplGc5N4mBuYW0RVQt6b,key=lambda key: int(key[wdftVMyzF17cYETHu(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ஄")]))
	WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = [vU6DxuzPwMpg(u"ࠩหำํ์ࠠหำฯ้ฮ๊้ࠦฬํ์อ࠭அ")],[fy8iFgEkrO12NR9TWBI35sjY6qHvV]
	try: EUXxgl9zVCa3 = bKTm4excAd[CsDcLqQUVK4YBvHFW1(u"ࠪࡧࡦࡶࡴࡪࡱࡱࡷࠬஆ")][EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠫࡵࡲࡡࡺࡧࡵࡇࡦࡶࡴࡪࡱࡱࡷ࡙ࡸࡡࡤ࡭࡯࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨஇ")][QjAINyUC7MDRq5d8e4vl9(u"ࠬࡩࡡࡱࡶ࡬ࡳࡳ࡚ࡲࡢࡥ࡮ࡷࠬஈ")]
	except: EUXxgl9zVCa3 = []
	try: syjlQvNfYkwLMEDnxdGWg1c = bKTm4excAd[C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠭ࡣࡢࡲࡷ࡭ࡴࡴࡳࠨஉ")][aOQTKXFL54Nl60Zhp3MbE(u"ࠧࡱ࡮ࡤࡽࡪࡸࡃࡢࡲࡷ࡭ࡴࡴࡳࡕࡴࡤࡧࡰࡲࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫஊ")][s5WMHyQN4mpie(u"ࠨࡥࡤࡴࡹ࡯࡯࡯ࡖࡵࡥࡨࡱࡳࠨ஋")]
	except: syjlQvNfYkwLMEDnxdGWg1c = []
	for IU9fz0gYsqmABiQbN8KtG76x4 in EUXxgl9zVCa3+syjlQvNfYkwLMEDnxdGWg1c:
		try:
			bigdh7fpZYl4aT2keV = IU9fz0gYsqmABiQbN8KtG76x4[SnhLjmfeJC(u"ࠩࡥࡥࡸ࡫ࡕࡳ࡮ࠪ஌")]
			try: title = IU9fz0gYsqmABiQbN8KtG76x4[C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠪࡲࡦࡳࡥࠨ஍")][aOQTKXFL54Nl60Zhp3MbE(u"ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨஎ")]
			except: title = IU9fz0gYsqmABiQbN8KtG76x4[O3OVuapf0YFjbm5oUQDg(u"ࠬࡴࡡ࡮ࡧࠪஏ")][ggjO5CrKVRPITaesWkxD(u"࠭ࡲࡶࡰࡶࠫஐ")][D2D96X5NGamBhrFwvL8VEbqiSfZIl][KfHAW8VGbrxi(u"ࠧࡵࡧࡻࡸࠬ஑")]
		except: continue
		if title not in WFlpmsYGKNy:
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
			WFlpmsYGKNy.append(title)
	if len(WFlpmsYGKNy)>BkM54Kr7Qbqn:
		yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S(AAbvaXV2DQzfNHdm4U3tT(u"ࠨษัฮึࠦวๅฬิะ๊ฯࠠࠩࠩஒ")+str(len(WFlpmsYGKNy))+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"้้ࠩࠣ็ࠩࠨஓ"), WFlpmsYGKNy)
		if yNqzFDjKM0SrO==-BkM54Kr7Qbqn: return O3OVuapf0YFjbm5oUQDg(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨஔ"),[],[]
		elif yNqzFDjKM0SrO!=D2D96X5NGamBhrFwvL8VEbqiSfZIl:
			bigdh7fpZYl4aT2keV = XoSyx7p6dqZ1CF8[yNqzFDjKM0SrO]+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠫࠫ࠭க")
			Ws1mXQIvzRTdtjM2q4iUK9OaPy = EcQxOa3RJm86WjTKA.findall(vU6DxuzPwMpg(u"ࠬࠬࠨࡧ࡯ࡷࡁ࠳࠰࠿ࠪࠨࠪ஖"),bigdh7fpZYl4aT2keV)
			if Ws1mXQIvzRTdtjM2q4iUK9OaPy: bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.replace(Ws1mXQIvzRTdtjM2q4iUK9OaPy[D2D96X5NGamBhrFwvL8VEbqiSfZIl],ssynAg0zhSkoCpOMDV9(u"࠭ࡦ࡮ࡶࡀࡺࡹࡺࠧ஗"))
			else: bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠧࡧ࡯ࡷࡁࡻࡺࡴࠨ஘")
			H3HOmNFvc0e = bigdh7fpZYl4aT2keV.strip(aOQTKXFL54Nl60Zhp3MbE(u"ࠨࠨࠪங"))
	zAjL9CBJmsTYiX = []
	for dict in QFnOHlJtW3Tv09Biq7DRy:
		if dict[O3OVuapf0YFjbm5oUQDg(u"ࠩࡷࡽࡵ࡫࠲ࠨச")]==wdftVMyzF17cYETHu(u"࡚ࠪ࡮ࡪࡥࡰࠩ஛"):
			Hahq91izYnkflGVU4u8spydeMJmNR.append(dict[PlpyFa9QMKXxOD1cvHzmI(u"ࠫࡹ࡯ࡴ࡭ࡧࠪஜ")])
			JpoIQh63N5DEbFdOlWUTwyHPV9.append(dict)
		elif dict[s5WMHyQN4mpie(u"ࠬࡺࡹࡱࡧ࠵ࠫ஝")]==Hr25gta6XcqO(u"࠭ࡁࡶࡦ࡬ࡳࠬஞ"):
			ND9Pqesb8k4xSVrMt2gUZ16dnOwXmT.append(dict[SnhLjmfeJC(u"ࠧࡵ࡫ࡷࡰࡪ࠭ட")])
			MELcIvXemV63xhaKykS1s.append(dict)
		elif dict[KfHAW8VGbrxi(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ஠")]==OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠩࡰࡴࡩ࠭஡"):
			title = dict[EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪࡸ࡮ࡺ࡬ࡦࠩ஢")].replace(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠫࡆ࠱ࡖ࠻ࠢࠣࠫண"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			if uulNDCPyef78(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭த") not in list(dict.keys()): gn2DUcWhvjpC4ZR0lr3bJO61GPVX = EE1jeHnIoad(u"࠭࠰ࠨ஥")
			else: gn2DUcWhvjpC4ZR0lr3bJO61GPVX = dict[KfHAW8VGbrxi(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ஦")]
			zAjL9CBJmsTYiX.append([dict,{},title,gn2DUcWhvjpC4ZR0lr3bJO61GPVX])
		else:
			title = dict[O3OVuapf0YFjbm5oUQDg(u"ࠨࡶ࡬ࡸࡱ࡫ࠧ஧")].replace(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩࡄ࠯࡛ࡀࠠࠡࠩந"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			if o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫன") not in list(dict.keys()): gn2DUcWhvjpC4ZR0lr3bJO61GPVX = CsDcLqQUVK4YBvHFW1(u"ࠫ࠵࠭ப")
			else: gn2DUcWhvjpC4ZR0lr3bJO61GPVX = dict[Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭஫")]
			zAjL9CBJmsTYiX.append([dict,{},title,gn2DUcWhvjpC4ZR0lr3bJO61GPVX])
			PPD0R6A24nVF81wosCZ5ubKSqhUjJ.append(title)
			SFTkjvy1N0fU2Zs4z9V.append(dict)
		dzItoNkOXpb9i4Vr36nRC = EsCplGc5N4mBuYW0RVQt6b
		if V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠭ࡣࡰࡦࡨࡧࡸ࠭஬") in list(dict.keys()):
			if ggjO5CrKVRPITaesWkxD(u"ࠧࡢࡸ࠳ࠫ஭") in dict[Hr25gta6XcqO(u"ࠨࡥࡲࡨࡪࡩࡳࠨம")]: dzItoNkOXpb9i4Vr36nRC = LhFAGlQ19zr
			elif FpjKBIUaEwbmLkxANfs<EE1jeHnIoad(u"࠴࠼ൔ") and LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠩࡤࡺࡨ࠭ய") not in dict[C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠪࡧࡴࡪࡥࡤࡵࠪர")] and jL5CrsRwebpyDVXUc1EQP(u"ࠫࡲࡶ࠴ࡢࠩற") not in dict[Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠬࡩ࡯ࡥࡧࡦࡷࠬல")]: dzItoNkOXpb9i4Vr36nRC = LhFAGlQ19zr
		if dzItoNkOXpb9i4Vr36nRC and dict[ssynAg0zhSkoCpOMDV9(u"࠭ࡴࡺࡲࡨ࠶ࠬள")]==C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧࡗ࡫ࡧࡩࡴ࠭ழ") and dict[KfHAW8VGbrxi(u"ࠨ࡫ࡱ࡭ࡹ࠭வ")]!=wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠩ࠳࠱࠵࠭ஶ"):
			rVoSLu4AFZfIRiUpecYOMxv.append(dict[EE1jeHnIoad(u"ࠪࡸ࡮ࡺ࡬ࡦࠩஷ")])
			i9Jzy1sqFR6HYILkeBx4ZmGl2rUPn.append(dict)
		elif dzItoNkOXpb9i4Vr36nRC and dict[PlpyFa9QMKXxOD1cvHzmI(u"ࠫࡹࡿࡰࡦ࠴ࠪஸ")]==C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬࡇࡵࡥ࡫ࡲࠫஹ") and dict[sJw9QWiq1Kr0xfeVRI(u"࠭ࡩ࡯࡫ࡷࠫ஺")]!=FmYoGejTnwKME7d9zPc(u"ࠧ࠱࠯࠳ࠫ஻"):
			ppNs25yXe7Ha.append(dict[C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨࡶ࡬ࡸࡱ࡫ࠧ஼")])
			nELiDzuH2VF.append(dict)
	for FtksL8WCOxy4z5Rho1HvwVf in nELiDzuH2VF:
		OrD8x2SFVb7jzTQCG9sN = FtksL8WCOxy4z5Rho1HvwVf[Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ஽")]
		for yyKY4v0WsVhnNHwxoTkSfdAD in i9Jzy1sqFR6HYILkeBx4ZmGl2rUPn:
			kcdgOQFMEmsyvNChHTP8K7q9bVU = yyKY4v0WsVhnNHwxoTkSfdAD[EE1jeHnIoad(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫா")]
			gn2DUcWhvjpC4ZR0lr3bJO61GPVX = int(kcdgOQFMEmsyvNChHTP8K7q9bVU)+int(OrD8x2SFVb7jzTQCG9sN)
			title = yyKY4v0WsVhnNHwxoTkSfdAD[ggjO5CrKVRPITaesWkxD(u"ࠫࡹ࡯ࡴ࡭ࡧࠪி")].replace(Hr25gta6XcqO(u"ࠬ࡜ࡩࡥࡧࡲ࠾ࠥࠦࠧீ"),Gcw2nelTR864XCVruO3mAFqI5a(u"࠭࡭ࡱࡦࠣࠤࠬு"))
			title = title.replace(yyKY4v0WsVhnNHwxoTkSfdAD[N6NGJ4vpmidqMCh7yo(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩூ")]+OOiSqkBcMPptI,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			title = title.replace(kcdgOQFMEmsyvNChHTP8K7q9bVU+O3OVuapf0YFjbm5oUQDg(u"ࠨ࡭ࡥࡴࡸ࠭௃"),str(gn2DUcWhvjpC4ZR0lr3bJO61GPVX)+N6NGJ4vpmidqMCh7yo(u"ࠩ࡮ࡦࡵࡹࠧ௄"))
			title = title+N6NGJ4vpmidqMCh7yo(u"ࠪࠬࠬ௅")+FtksL8WCOxy4z5Rho1HvwVf[wdftVMyzF17cYETHu(u"ࠫࡹ࡯ࡴ࡭ࡧࠪெ")].split(LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠬ࠮ࠧே"),BkM54Kr7Qbqn)[BkM54Kr7Qbqn]
			zAjL9CBJmsTYiX.append([yyKY4v0WsVhnNHwxoTkSfdAD,FtksL8WCOxy4z5Rho1HvwVf,title,gn2DUcWhvjpC4ZR0lr3bJO61GPVX])
	qOXr0CTou75sSvjFUJl = []
	for stream in zAjL9CBJmsTYiX:
		yyKY4v0WsVhnNHwxoTkSfdAD,FtksL8WCOxy4z5Rho1HvwVf,title,gn2DUcWhvjpC4ZR0lr3bJO61GPVX = stream
		W9Wlfe5pMJXvu0Qxk = title[:XW57OCeGnFTLQbaqdrD9zM]
		if FgXzMs0YSDt(u"࠭ะไ์ฬࠫை") in title: W9Wlfe5pMJXvu0Qxk += FmYoGejTnwKME7d9zPc(u"ࠧࠬࠩ௉")
		qOXr0CTou75sSvjFUJl.append([stream,W9Wlfe5pMJXvu0Qxk,int(gn2DUcWhvjpC4ZR0lr3bJO61GPVX)])
	aVcyLohSDJ0ElCgHW = LhFAGlQ19zr
	KTeQfsVJgk = ngpwf5MVySAe8caPsWmD6GlNuvJb(BfWYUAnyg6eONLjiuE,qOXr0CTou75sSvjFUJl)
	if KTeQfsVJgk:
		k4r5IRC0fJuZdE9,ZRtzJk6q7ru,title,gn2DUcWhvjpC4ZR0lr3bJO61GPVX = KTeQfsVJgk[D2D96X5NGamBhrFwvL8VEbqiSfZIl][D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		bUnP65BivmkW = k4r5IRC0fJuZdE9[FmYoGejTnwKME7d9zPc(u"ࠨࡷࡵࡰࠬொ")]
		if SnhLjmfeJC(u"ࠩࡰࡴࡩ࠭ோ") in title and bUnP65BivmkW!=Ij0v4pNRgtZTJxLAUz: aVcyLohSDJ0ElCgHW = EsCplGc5N4mBuYW0RVQt6b
		LI6b5xf7pSoKZYUeD = title
	else:
		p8pUW7t2BPFo6M5 = ngpwf5MVySAe8caPsWmD6GlNuvJb(BfWYUAnyg6eONLjiuE,qOXr0CTou75sSvjFUJl,vU6DxuzPwMpg(u"࠵࠺࠶࠰ൕ"))
		p8pUW7t2BPFo6M5,Y1Y7cULHrsQb52KqE0,GYvZIK49eTCqWX3FbASM5zB = zip(*p8pUW7t2BPFo6M5)
		dkMlIfix3WVpojrY,ggpwPDUet5dHFCuniaVLqRI04f,wyCHRD0zhE6KfVU1JIOd7YtZG = [],[],D2D96X5NGamBhrFwvL8VEbqiSfZIl
		zAjL9CBJmsTYiX = sorted(zAjL9CBJmsTYiX, reverse=EsCplGc5N4mBuYW0RVQt6b, key=lambda key: float(key[XW57OCeGnFTLQbaqdrD9zM]))
		zzhNQojauBd2tLSpbcxgXqJVTHikY9,Adcp3FBLaDo40vXlRM6G2EH9fztnJ,lsRAD9Cxgv = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
		try: zzhNQojauBd2tLSpbcxgXqJVTHikY9 = bKTm4excAd[ggjO5CrKVRPITaesWkxD(u"ࠪࡺ࡮ࡪࡥࡰࡆࡨࡸࡦ࡯࡬ࡴࠩௌ")][AAbvaXV2DQzfNHdm4U3tT(u"ࠫࡦࡻࡴࡩࡱࡵ்ࠫ")]
		except:
			try: zzhNQojauBd2tLSpbcxgXqJVTHikY9 = MS76nQWTBvAud[wdftVMyzF17cYETHu(u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫ௎")][CsDcLqQUVK4YBvHFW1(u"࠭ࡡࡶࡶ࡫ࡳࡷ࠭௏")]
			except: pass
		try: Adcp3FBLaDo40vXlRM6G2EH9fztnJ = bKTm4excAd[Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭ௐ")][vU6DxuzPwMpg(u"ࠨࡥ࡫ࡥࡳࡴࡥ࡭ࡋࡧࠫ௑")]
		except:
			try: Adcp3FBLaDo40vXlRM6G2EH9fztnJ = MS76nQWTBvAud[Hr25gta6XcqO(u"ࠩࡹ࡭ࡩ࡫࡯ࡅࡧࡷࡥ࡮ࡲࡳࠨ௒")][sIzDXlTHYUC5L3xZGnr(u"ࠪࡧ࡭ࡧ࡮࡯ࡧ࡯ࡍࡩ࠭௓")]
			except: pass
		if zzhNQojauBd2tLSpbcxgXqJVTHikY9 and Adcp3FBLaDo40vXlRM6G2EH9fztnJ:
			wyCHRD0zhE6KfVU1JIOd7YtZG += BkM54Kr7Qbqn
			title = n0nFOd4yR97fQzNLSW+ggjO5CrKVRPITaesWkxD(u"ࠫࡔ࡝ࡎࡆࡔ࠽ࠤࠥ࠭௔")+zzhNQojauBd2tLSpbcxgXqJVTHikY9+T7ASIp1ZYwio9HQ8cObJK
			bigdh7fpZYl4aT2keV = I4t9qonjrm.SITESURLS[wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭௕")][D2D96X5NGamBhrFwvL8VEbqiSfZIl]+I18uSKaWhgTBeYUPD4sr(u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࠩ௖")+Adcp3FBLaDo40vXlRM6G2EH9fztnJ
			dkMlIfix3WVpojrY.append(title)
			ggpwPDUet5dHFCuniaVLqRI04f.append(bigdh7fpZYl4aT2keV)
			try: lsRAD9Cxgv = bKTm4excAd[FmYoGejTnwKME7d9zPc(u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭ௗ")][Gcw2nelTR864XCVruO3mAFqI5a(u"ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠫ௘")][FgXzMs0YSDt(u"ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭௙")][-BkM54Kr7Qbqn][jL5CrsRwebpyDVXUc1EQP(u"ࠪࡹࡷࡲࠧ௚")]
			except:
				try: lsRAD9Cxgv = MS76nQWTBvAud[aOQTKXFL54Nl60Zhp3MbE(u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪ௛")][o1INZ3ViQqS0Uw5z6kMjbv(u"ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠨ௜")][uulNDCPyef78(u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪ௝")][-BkM54Kr7Qbqn][PlpyFa9QMKXxOD1cvHzmI(u"ࠧࡶࡴ࡯ࠫ௞")]
				except: pass
		for yyKY4v0WsVhnNHwxoTkSfdAD,FtksL8WCOxy4z5Rho1HvwVf,title,gn2DUcWhvjpC4ZR0lr3bJO61GPVX in p8pUW7t2BPFo6M5:
			dkMlIfix3WVpojrY.append(title) ; ggpwPDUet5dHFCuniaVLqRI04f.append(AAbvaXV2DQzfNHdm4U3tT(u"ࠨࡪ࡬࡫࡭࡫ࡳࡵࠩ௟"))
		if PPD0R6A24nVF81wosCZ5ubKSqhUjJ: dkMlIfix3WVpojrY.append(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ุࠩ์ึฯ้ࠠื๋ฮ๋ࠥอะัฬࠫ௠")) ; ggpwPDUet5dHFCuniaVLqRI04f.append(o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪࡱࡺࡾࡥࡥࠩ௡"))
		if zAjL9CBJmsTYiX: dkMlIfix3WVpojrY.append(sJw9QWiq1Kr0xfeVRI(u"ฺࠫ๎ัสู๋ࠢํะࠠศๆ่ฮํ็ัࠨ௢")) ; ggpwPDUet5dHFCuniaVLqRI04f.append(Hr25gta6XcqO(u"ࠬࡧ࡬࡭ࠩ௣"))
		if rVoSLu4AFZfIRiUpecYOMxv: dkMlIfix3WVpojrY.append(oRJAfwD957WkUyBM1Ehu8m(u"࠭วฯฬิࠤฬ๊ี้ำฬࠤํอไึ๊อࠫ௤")) ; ggpwPDUet5dHFCuniaVLqRI04f.append(oRJAfwD957WkUyBM1Ehu8m(u"ࠧ࡮ࡲࡧࠫ௥"))
		if Hahq91izYnkflGVU4u8spydeMJmNR: dkMlIfix3WVpojrY.append(N6NGJ4vpmidqMCh7yo(u"ࠨื๋ีฮࠦศะ๊้ࠤฺ๎สࠨ௦")) ; ggpwPDUet5dHFCuniaVLqRI04f.append(FmYoGejTnwKME7d9zPc(u"ࠩࡹ࡭ࡩ࡫࡯ࠨ௧"))
		if ND9Pqesb8k4xSVrMt2gUZ16dnOwXmT: dkMlIfix3WVpojrY.append(Gcw2nelTR864XCVruO3mAFqI5a(u"ูࠪํะࠠษั๋๊ࠥ฻่าหࠪ௨")) ; ggpwPDUet5dHFCuniaVLqRI04f.append(ssynAg0zhSkoCpOMDV9(u"ࠫࡦࡻࡤࡪࡱࠪ௩"))
		while EsCplGc5N4mBuYW0RVQt6b:
			yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S(RGS23XqK4jPHLAIY6ZOuFgpQC, dkMlIfix3WVpojrY)
			if yNqzFDjKM0SrO==-BkM54Kr7Qbqn: return Gcw2nelTR864XCVruO3mAFqI5a(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ௪"),[],[]
			elif yNqzFDjKM0SrO==D2D96X5NGamBhrFwvL8VEbqiSfZIl and zzhNQojauBd2tLSpbcxgXqJVTHikY9:
				bigdh7fpZYl4aT2keV = ggpwPDUet5dHFCuniaVLqRI04f[yNqzFDjKM0SrO]
				h6RSrfXtAnB2HgiaK = CfgZ0zWP5XBpoGQwLUY.argv[D2D96X5NGamBhrFwvL8VEbqiSfZIl]+s5WMHyQN4mpie(u"࠭࠿ࡵࡻࡳࡩࡂ࡬࡯࡭ࡦࡨࡶࠫࡳ࡯ࡥࡧࡀ࠵࠹࠷ࠦ࡯ࡣࡰࡩࡂ࠭௫")+DVX5GWhnIxYlSd9rEuetjk40UJ(zzhNQojauBd2tLSpbcxgXqJVTHikY9)+C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧࠧࡷࡵࡰࡂ࠭௬")+bigdh7fpZYl4aT2keV
				if lsRAD9Cxgv: h6RSrfXtAnB2HgiaK = h6RSrfXtAnB2HgiaK+SnhLjmfeJC(u"ࠨࠨ࡬ࡱࡦ࡭ࡥ࠾ࠩ௭")+DVX5GWhnIxYlSd9rEuetjk40UJ(lsRAD9Cxgv)
				bEWpDHXjCBqd7aOiN6UG5k.executebuiltin(N6NGJ4vpmidqMCh7yo(u"ࠤࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࠨ௮")+h6RSrfXtAnB2HgiaK+ssynAg0zhSkoCpOMDV9(u"ࠥ࠭ࠧ௯"))
				return C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ௰"),[],[]
			YYxDRTA76kwZNBqnHSdJ = ggpwPDUet5dHFCuniaVLqRI04f[yNqzFDjKM0SrO]
			LI6b5xf7pSoKZYUeD = dkMlIfix3WVpojrY[yNqzFDjKM0SrO]
			if YYxDRTA76kwZNBqnHSdJ==SnhLjmfeJC(u"ࠬࡪࡡࡴࡪࠪ௱"):
				bUnP65BivmkW = Ij0v4pNRgtZTJxLAUz
				break
			elif YYxDRTA76kwZNBqnHSdJ in [uulNDCPyef78(u"࠭ࡡࡶࡦ࡬ࡳࠬ௲"),sJw9QWiq1Kr0xfeVRI(u"ࠧࡷ࡫ࡧࡩࡴ࠭௳"),s5WMHyQN4mpie(u"ࠨ࡯ࡸࡼࡪࡪࠧ௴")]:
				if YYxDRTA76kwZNBqnHSdJ==KfHAW8VGbrxi(u"ࠩࡰࡹࡽ࡫ࡤࠨ௵"): WFlpmsYGKNy,wNHVucGA6bSe1r = PPD0R6A24nVF81wosCZ5ubKSqhUjJ,SFTkjvy1N0fU2Zs4z9V
				elif YYxDRTA76kwZNBqnHSdJ==V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪࡺ࡮ࡪࡥࡰࠩ௶"): WFlpmsYGKNy,wNHVucGA6bSe1r = Hahq91izYnkflGVU4u8spydeMJmNR,JpoIQh63N5DEbFdOlWUTwyHPV9
				elif YYxDRTA76kwZNBqnHSdJ==PlpyFa9QMKXxOD1cvHzmI(u"ࠫࡦࡻࡤࡪࡱࠪ௷"): WFlpmsYGKNy,wNHVucGA6bSe1r = ND9Pqesb8k4xSVrMt2gUZ16dnOwXmT,MELcIvXemV63xhaKykS1s
				yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠬอฮหำࠣห้๋ไโࠢࠫࠫ௸")+str(len(WFlpmsYGKNy))+FgXzMs0YSDt(u"࠭ࠠๆๆไ࠭ࠬ௹"), WFlpmsYGKNy)
				if yNqzFDjKM0SrO!=-BkM54Kr7Qbqn:
					bUnP65BivmkW = wNHVucGA6bSe1r[yNqzFDjKM0SrO][wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧࡶࡴ࡯ࠫ௺")]
					LI6b5xf7pSoKZYUeD = WFlpmsYGKNy[yNqzFDjKM0SrO]
					break
			elif YYxDRTA76kwZNBqnHSdJ==vU6DxuzPwMpg(u"ࠨ࡯ࡳࡨࠬ௻"):
				yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S(AAbvaXV2DQzfNHdm4U3tT(u"ࠩสาฯืࠠอ๊าอࠥอไึ๊ิอࠥ࠮ࠧ௼")+str(len(rVoSLu4AFZfIRiUpecYOMxv))+Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠪࠤ๊๊แࠪࠩ௽"), rVoSLu4AFZfIRiUpecYOMxv)
				if yNqzFDjKM0SrO!=-BkM54Kr7Qbqn:
					LI6b5xf7pSoKZYUeD = rVoSLu4AFZfIRiUpecYOMxv[yNqzFDjKM0SrO]
					k4r5IRC0fJuZdE9 = i9Jzy1sqFR6HYILkeBx4ZmGl2rUPn[yNqzFDjKM0SrO]
					yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S(Hr25gta6XcqO(u"ࠫฬิสาࠢฯ์ิฯࠠศๆุ์ฯࠦࠨࠨ௾")+str(len(ppNs25yXe7Ha))+aOQTKXFL54Nl60Zhp3MbE(u"ࠬࠦๅๅใࠬࠫ௿"), ppNs25yXe7Ha)
					if yNqzFDjKM0SrO!=-BkM54Kr7Qbqn:
						LI6b5xf7pSoKZYUeD += aOQTKXFL54Nl60Zhp3MbE(u"࠭ࠠࠬࠢࠪఀ")+ppNs25yXe7Ha[yNqzFDjKM0SrO]
						ZRtzJk6q7ru = nELiDzuH2VF[yNqzFDjKM0SrO]
						aVcyLohSDJ0ElCgHW = EsCplGc5N4mBuYW0RVQt6b
						break
			elif YYxDRTA76kwZNBqnHSdJ==s5WMHyQN4mpie(u"ࠧࡢ࡮࡯ࠫఁ"):
				kbKCETJgMR0A61pVnxh,Q5v3T2Gj9hcYCmgzNBObV0unl,ha4IMHrTxRJtlcn,wwUOkEWQ5vi4PVC = list(zip(*zAjL9CBJmsTYiX))
				yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨษัฮึࠦวๅ็็ๅࠥ࠮ࠧం")+str(len(ha4IMHrTxRJtlcn))+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"้้ࠩࠣ็ࠩࠨః"), ha4IMHrTxRJtlcn)
				if yNqzFDjKM0SrO!=-BkM54Kr7Qbqn:
					LI6b5xf7pSoKZYUeD = ha4IMHrTxRJtlcn[yNqzFDjKM0SrO]
					k4r5IRC0fJuZdE9 = kbKCETJgMR0A61pVnxh[yNqzFDjKM0SrO]
					if C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠪࡱࡵࡪࠧఄ") in ha4IMHrTxRJtlcn[yNqzFDjKM0SrO] and k4r5IRC0fJuZdE9[vU6DxuzPwMpg(u"ࠫࡺࡸ࡬ࠨఅ")]!=Ij0v4pNRgtZTJxLAUz:
						ZRtzJk6q7ru = Q5v3T2Gj9hcYCmgzNBObV0unl[yNqzFDjKM0SrO]
						aVcyLohSDJ0ElCgHW = EsCplGc5N4mBuYW0RVQt6b
					else: bUnP65BivmkW = k4r5IRC0fJuZdE9[V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠬࡻࡲ࡭ࠩఆ")]
					break
			elif YYxDRTA76kwZNBqnHSdJ==ssynAg0zhSkoCpOMDV9(u"࠭ࡨࡪࡩ࡫ࡩࡸࡺࠧఇ"):
				kbKCETJgMR0A61pVnxh,Q5v3T2Gj9hcYCmgzNBObV0unl,ha4IMHrTxRJtlcn,wwUOkEWQ5vi4PVC = list(zip(*p8pUW7t2BPFo6M5))
				k4r5IRC0fJuZdE9 = kbKCETJgMR0A61pVnxh[yNqzFDjKM0SrO-wyCHRD0zhE6KfVU1JIOd7YtZG]
				if KfHAW8VGbrxi(u"ࠧ࡮ࡲࡧࠫఈ") in ha4IMHrTxRJtlcn[yNqzFDjKM0SrO-wyCHRD0zhE6KfVU1JIOd7YtZG] and k4r5IRC0fJuZdE9[EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠨࡷࡵࡰࠬఉ")]!=Ij0v4pNRgtZTJxLAUz:
					ZRtzJk6q7ru = Q5v3T2Gj9hcYCmgzNBObV0unl[yNqzFDjKM0SrO-wyCHRD0zhE6KfVU1JIOd7YtZG]
					aVcyLohSDJ0ElCgHW = EsCplGc5N4mBuYW0RVQt6b
				else: bUnP65BivmkW = k4r5IRC0fJuZdE9[s5WMHyQN4mpie(u"ࠩࡸࡶࡱ࠭ఊ")]
				LI6b5xf7pSoKZYUeD = ha4IMHrTxRJtlcn[yNqzFDjKM0SrO-wyCHRD0zhE6KfVU1JIOd7YtZG]
				break
	if aVcyLohSDJ0ElCgHW:
		bn5WZGaMX6OeCBjmqKv2IARxNQ0 = int(k4r5IRC0fJuZdE9[uulNDCPyef78(u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬఋ")])
		eYMuw1Gia462r5olpHLgt7W80kTsK = int(ZRtzJk6q7ru[KfHAW8VGbrxi(u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭ఌ")])
		rQ0jN7XkZPE1AYU = str(max(bn5WZGaMX6OeCBjmqKv2IARxNQ0,eYMuw1Gia462r5olpHLgt7W80kTsK))
		xco30SNJCwgPuDBOiszh8RHaVEI7j = k4r5IRC0fJuZdE9[O3OVuapf0YFjbm5oUQDg(u"ࠬࡻࡲ࡭ࠩ఍")].replace(O3OVuapf0YFjbm5oUQDg(u"࠭ࠦࠨఎ"),CsDcLqQUVK4YBvHFW1(u"ࠧࠧࡣࡰࡴࡀ࠭ఏ"))
		z3PAW1kdq6gCDVb7H = ZRtzJk6q7ru[I18uSKaWhgTBeYUPD4sr(u"ࠨࡷࡵࡰࠬఐ")].replace(SnhLjmfeJC(u"ࠩࠩࠫ఑"),PlpyFa9QMKXxOD1cvHzmI(u"ࠪࠪࡦࡳࡰ࠼ࠩఒ"))
		mpd = I18uSKaWhgTBeYUPD4sr(u"ࠫࡁࡓࡐࡅࠢࡰࡩࡩ࡯ࡡࡑࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࡊࡵࡳࡣࡷ࡭ࡴࡴ࠽ࠣࡒࡗࠫఓ")+rQ0jN7XkZPE1AYU+vU6DxuzPwMpg(u"࡙ࠬࠢ࠿࡞ࡱࠫఔ")
		mpd += AAbvaXV2DQzfNHdm4U3tT(u"࠭࠼ࡑࡧࡵ࡭ࡴࡪ࠾࡝ࡰࠪక")
		mpd += Gcw2nelTR864XCVruO3mAFqI5a(u"ࠧ࠽ࡃࡧࡥࡵࡺࡡࡵ࡫ࡲࡲࡘ࡫ࡴࠡ࡯࡬ࡱࡪ࡚ࡹࡱࡧࡀࠦࡻ࡯ࡤࡦࡱ࠲ࠫఖ")+k4r5IRC0fJuZdE9[o1INZ3ViQqS0Uw5z6kMjbv(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪగ")]+aOQTKXFL54Nl60Zhp3MbE(u"ࠩࠥࠤࡨࡵࡤࡦࡥࡶࡁࠧ࠭ఘ")+k4r5IRC0fJuZdE9[aOQTKXFL54Nl60Zhp3MbE(u"ࠪࡧࡴࡪࡥࡤࡵࠪఙ")]+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠫࠧࡄ࡜࡯ࠩచ")
		mpd += SnhLjmfeJC(u"ࠬࡂࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴ࠾࡝ࡰࠪఛ")
		mpd += C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠭࠼ࡃࡣࡶࡩ࡚ࡘࡌ࠿ࠩజ")+xco30SNJCwgPuDBOiszh8RHaVEI7j+aOQTKXFL54Nl60Zhp3MbE(u"ࠧ࠽࠱ࡅࡥࡸ࡫ࡕࡓࡎࡁࡠࡳ࠭ఝ")
		mpd += EE1jeHnIoad(u"ࠨ࠾ࡖࡩ࡬ࡳࡥ࡯ࡶࡅࡥࡸ࡫ࠠࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࡁࠧ࠭ఞ")+k4r5IRC0fJuZdE9[oRJAfwD957WkUyBM1Ehu8m(u"ࠩ࡬ࡲࡩ࡫ࡸࠨట")]+AAbvaXV2DQzfNHdm4U3tT(u"ࠪࠦࡃࡢ࡮ࠨఠ")
		mpd += I18uSKaWhgTBeYUPD4sr(u"ࠫࡁࡏ࡮ࡪࡶ࡬ࡥࡱ࡯ࡺࡢࡶ࡬ࡳࡳࠦࡲࡢࡰࡪࡩࡂࠨࠧడ")+k4r5IRC0fJuZdE9[EE1jeHnIoad(u"ࠬ࡯࡮ࡪࡶࠪఢ")]+vU6DxuzPwMpg(u"࠭ࠢࠡ࠱ࡁࡠࡳ࠭ణ")
		mpd += ssynAg0zhSkoCpOMDV9(u"ࠧ࠽࠱ࡖࡩ࡬ࡳࡥ࡯ࡶࡅࡥࡸ࡫࠾࡝ࡰࠪత")
		mpd += KfHAW8VGbrxi(u"ࠨ࠾࠲ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࡂࡡࡴࠧథ")
		mpd += sIzDXlTHYUC5L3xZGnr(u"ࠩ࠿࠳ࡆࡪࡡࡱࡶࡤࡸ࡮ࡵ࡮ࡔࡧࡷࡂࡡࡴࠧద")
		mpd += I18uSKaWhgTBeYUPD4sr(u"ࠪࡀࡆࡪࡡࡱࡶࡤࡸ࡮ࡵ࡮ࡔࡧࡷࠤࡲ࡯࡭ࡦࡖࡼࡴࡪࡃࠢࡢࡷࡧ࡭ࡴ࠵ࠧధ")+ZRtzJk6q7ru[FmYoGejTnwKME7d9zPc(u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭న")]+O3OVuapf0YFjbm5oUQDg(u"ࠬࠨࠠࡤࡱࡧࡩࡨࡹ࠽ࠣࠩ఩")+ZRtzJk6q7ru[SnhLjmfeJC(u"࠭ࡣࡰࡦࡨࡧࡸ࠭ప")]+KfHAW8VGbrxi(u"ࠧࠣࡀ࡟ࡲࠬఫ")
		mpd += sJw9QWiq1Kr0xfeVRI(u"ࠨ࠾ࡕࡩࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࡁࡠࡳ࠭బ")
		mpd += AAbvaXV2DQzfNHdm4U3tT(u"ࠩ࠿ࡆࡦࡹࡥࡖࡔࡏࡂࠬభ")+z3PAW1kdq6gCDVb7H+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪࡀ࠴ࡈࡡࡴࡧࡘࡖࡑࡄ࡜࡯ࠩమ")
		mpd += wdftVMyzF17cYETHu(u"ࠫࡁ࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࠣ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫࠽ࠣࠩయ")+ZRtzJk6q7ru[aOQTKXFL54Nl60Zhp3MbE(u"ࠬ࡯࡮ࡥࡧࡻࠫర")]+s5WMHyQN4mpie(u"࠭ࠢ࠿࡞ࡱࠫఱ")
		mpd += FgXzMs0YSDt(u"ࠧ࠽ࡋࡱ࡭ࡹ࡯ࡡ࡭࡫ࡽࡥࡹ࡯࡯࡯ࠢࡵࡥࡳ࡭ࡥ࠾ࠤࠪల")+ZRtzJk6q7ru[s5WMHyQN4mpie(u"ࠨ࡫ࡱ࡭ࡹ࠭ళ")]+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠩࠥࠤ࠴ࡄ࡜࡯ࠩఴ")
		mpd += I18uSKaWhgTBeYUPD4sr(u"ࠪࡀ࠴࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࡁࡠࡳ࠭వ")
		mpd += FgXzMs0YSDt(u"ࠫࡁ࠵ࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴ࠾࡝ࡰࠪశ")
		mpd += ggjO5CrKVRPITaesWkxD(u"ࠬࡂ࠯ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺ࠾࡝ࡰࠪష")
		mpd += QjAINyUC7MDRq5d8e4vl9(u"࠭࠼࠰ࡒࡨࡶ࡮ࡵࡤ࠿࡞ࡱࠫస")
		mpd += CsDcLqQUVK4YBvHFW1(u"ࠧ࠽࠱ࡐࡔࡉࡄ࡜࡯ࠩహ")
		if jTDWgftK7NEmx0JAkOn2aRIvweq:
			import http.server as IPqEYoyFu0dC2OgW8blv
			import http.client as m5XE8JHPAK0OWtZNfcsS
		else:
			import BaseHTTPServer as IPqEYoyFu0dC2OgW8blv
			import httplib as m5XE8JHPAK0OWtZNfcsS
		class W8fHrcdlwpR7iUKZtS5EPxeJsM0j(IPqEYoyFu0dC2OgW8blv.HTTPServer):
			def __init__(LjRoTMDiSwQlCmzO1,ip=oRJAfwD957WkUyBM1Ehu8m(u"ࠨ࡮ࡲࡧࡦࡲࡨࡰࡵࡷࠫ఺"),port=LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠺࠻࠰࠶࠷ൖ"),mpd=I18uSKaWhgTBeYUPD4sr(u"ࠩ࠿ࡂࠬ఻")):
				LjRoTMDiSwQlCmzO1.ip = ip
				LjRoTMDiSwQlCmzO1.port = port
				LjRoTMDiSwQlCmzO1.mpd = mpd
				IPqEYoyFu0dC2OgW8blv.HTTPServer.__init__(LjRoTMDiSwQlCmzO1,(LjRoTMDiSwQlCmzO1.ip,LjRoTMDiSwQlCmzO1.port),ZZNbRlstgeBmWq)
				LjRoTMDiSwQlCmzO1.mpdurl = ssynAg0zhSkoCpOMDV9(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲఼ࠫ")+ip+ssynAg0zhSkoCpOMDV9(u"ࠫ࠿࠭ఽ")+str(port)+jL5CrsRwebpyDVXUc1EQP(u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫా")
			def start(LjRoTMDiSwQlCmzO1):
				LjRoTMDiSwQlCmzO1.threads = Ui7X2Awte6o8J9QRV4kdsPmb(LhFAGlQ19zr)
				LjRoTMDiSwQlCmzO1.threads.hN0H7wlzTkjUr(BkM54Kr7Qbqn,LjRoTMDiSwQlCmzO1.a6ehqUwuNgz2LlxvZXGjbpMio48t)
			def a6ehqUwuNgz2LlxvZXGjbpMio48t(LjRoTMDiSwQlCmzO1):
				LjRoTMDiSwQlCmzO1.keeprunning = EsCplGc5N4mBuYW0RVQt6b
				while LjRoTMDiSwQlCmzO1.keeprunning:
					LjRoTMDiSwQlCmzO1.handle_request()
			def stop(LjRoTMDiSwQlCmzO1):
				LjRoTMDiSwQlCmzO1.keeprunning = LhFAGlQ19zr
				LjRoTMDiSwQlCmzO1.DAJLYGPwNfj4rnxokedmvgsI6()
			def G1NP2gIm5fH(LjRoTMDiSwQlCmzO1):
				LjRoTMDiSwQlCmzO1.stop()
				LjRoTMDiSwQlCmzO1.AA872c56aHvzhydmTfCSw0tlDxoZeK.close()
				LjRoTMDiSwQlCmzO1.server_close()
			def jXWxYZDSbFR137JNiH9KP8LkVsy(LjRoTMDiSwQlCmzO1,mpd):
				LjRoTMDiSwQlCmzO1.mpd = mpd
			def DAJLYGPwNfj4rnxokedmvgsI6(LjRoTMDiSwQlCmzO1):
				vvPmnHekOc7qrjidMwxf134VD = m5XE8JHPAK0OWtZNfcsS.HTTPConnection(LjRoTMDiSwQlCmzO1.ip+wdftVMyzF17cYETHu(u"࠭࠺ࠨి")+str(LjRoTMDiSwQlCmzO1.port))
				vvPmnHekOc7qrjidMwxf134VD.request(N6NGJ4vpmidqMCh7yo(u"ࠢࡉࡇࡄࡈࠧీ"), OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠣ࠱ࠥు"))
		class ZZNbRlstgeBmWq(IPqEYoyFu0dC2OgW8blv.BaseHTTPRequestHandler):
			def XD93qAjG0RYsVufI(LjRoTMDiSwQlCmzO1):
				LjRoTMDiSwQlCmzO1.send_response(ssynAg0zhSkoCpOMDV9(u"࠸࠰࠱ൗ"))
				LjRoTMDiSwQlCmzO1.send_header(EE1jeHnIoad(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡸࡾࡶࡥࠨూ"),SnhLjmfeJC(u"ࠪࡸࡪࡾࡴ࠰ࡲ࡯ࡥ࡮ࡴࠧృ"))
				LjRoTMDiSwQlCmzO1.end_headers()
				LjRoTMDiSwQlCmzO1.wfile.write(LjRoTMDiSwQlCmzO1.A8ECQ0qwTRzPifOGW76FK35uUvhe.mpd.encode(Tk9eH2qw6Brsuhj))
				uUqrNPcXKBoQ0slv.sleep(BkM54Kr7Qbqn)
				if LjRoTMDiSwQlCmzO1.path==sJw9QWiq1Kr0xfeVRI(u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࠴࡭ࡱࡦࠪౄ"): LjRoTMDiSwQlCmzO1.A8ECQ0qwTRzPifOGW76FK35uUvhe.G1NP2gIm5fH()
				if LjRoTMDiSwQlCmzO1.path==N6NGJ4vpmidqMCh7yo(u"ࠬ࠵ࡳࡩࡷࡷࡨࡴࡽ࡮ࠨ౅"): LjRoTMDiSwQlCmzO1.A8ECQ0qwTRzPifOGW76FK35uUvhe.G1NP2gIm5fH()
			def jIm92pfGsKeoRVQkUt0FxTyJ(LjRoTMDiSwQlCmzO1):
				LjRoTMDiSwQlCmzO1.send_response(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠲࠱࠲൘"))
				LjRoTMDiSwQlCmzO1.end_headers()
		pkeHTaD5cqGWm = W8fHrcdlwpR7iUKZtS5EPxeJsM0j(O3OVuapf0YFjbm5oUQDg(u"࠭࠱࠳࠹࠱࠴࠳࠶࠮࠲ࠩె"),jL5CrsRwebpyDVXUc1EQP(u"࠶࠷࠳࠹࠺൙"),mpd)
		bUnP65BivmkW = pkeHTaD5cqGWm.mpdurl
		pkeHTaD5cqGWm.start()
	else: pkeHTaD5cqGWm = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if jTDWgftK7NEmx0JAkOn2aRIvweq: FhnN04vHwi,a0siTyhwK9urB5P = fy8iFgEkrO12NR9TWBI35sjY6qHvV,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠧ࡝ࡶࠪే")
	else: FhnN04vHwi,a0siTyhwK9urB5P = Gcw2nelTR864XCVruO3mAFqI5a(u"ࠨ࡞ࡷࠫై"),fy8iFgEkrO12NR9TWBI35sjY6qHvV
	ZZBNkYJ5xsLmFnzKbGg1i4 = FhnN04vHwi+FmYoGejTnwKME7d9zPc(u"ࠩࡄࡹࡩ࡯࡯࠻ࠢ࡞ࠤࠬ౉")+ZRtzJk6q7ru[FmYoGejTnwKME7d9zPc(u"ࠪࡹࡷࡲࠧొ")]+CsDcLqQUVK4YBvHFW1(u"ࠫࠥࡣ࡜࡯࡞ࡷࡠࡹ࠭ో")+a0siTyhwK9urB5P+sJw9QWiq1Kr0xfeVRI(u"ࠬ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨౌ")+k4r5IRC0fJuZdE9[o1INZ3ViQqS0Uw5z6kMjbv(u"࠭ࡵࡳ࡮్ࠪ")]+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠧࠡ࡟ࠪ౎") if aVcyLohSDJ0ElCgHW else FhnN04vHwi+N6NGJ4vpmidqMCh7yo(u"ࠨࡃ࠮࡚࠿࡛ࠦࠡࠩ౏")+bUnP65BivmkW+OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠩࠣࡡࠬ౐")
	Clc8sIj97ZrThF(wVhZ6bfkpSre95EFu,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+aOQTKXFL54Nl60Zhp3MbE(u"ࠪࡠࡹࡖ࡬ࡢࡻ࡬ࡲ࡬ࠦࡓࡵࡴࡨࡥࡲࡀࠠ࡜ࠢࠪ౑")+LI6b5xf7pSoKZYUeD+FgXzMs0YSDt(u"ࠫࠥࡣࠠࠡࠢࠪ౒")+ZZBNkYJ5xsLmFnzKbGg1i4)
	if not bUnP65BivmkW: return V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠬࡋࡲࡳࡱࡵࠤࠥࠦࠠ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࠥࡌࡡࡪ࡮ࡨࡨࠬ౓"),[],[]
	return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[LI6b5xf7pSoKZYUeD],[[bUnP65BivmkW,H3HOmNFvc0e,pkeHTaD5cqGWm]]
def OlvG5dgfXtFYsQ7ai68Zx4k(url):
	headers = { vU6DxuzPwMpg(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ౔") : fy8iFgEkrO12NR9TWBI35sjY6qHvV }
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(d9vcuo3Hy7RhAk2,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,vU6DxuzPwMpg(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡎࡊࡂࡐࡄ࠰࠵ࡸࡺౕࠧ"))
	items = EcQxOa3RJm86WjTKA.findall(FgXzMs0YSDt(u"ࠨࡨ࡬ࡰࡪࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠭࡮ࡤࡦࡪࡲ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࡽࠫ࡟ࢁౖࠬ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	items = set(items)
	items = sorted(items, reverse=EsCplGc5N4mBuYW0RVQt6b, key=lambda key: key[teaC5j4HuGDqpwcmUzJ])
	JJVg3pG9Eayr5CAn,WFlpmsYGKNy,m06mELslRjhekXGW,XoSyx7p6dqZ1CF8 = [],[],[],[]
	if not items: return oRJAfwD957WkUyBM1Ehu8m(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡛ࡏࡄࡃࡑࡅࠫ౗"),[],[]
	for bigdh7fpZYl4aT2keV,O4On5rLamD7q1zKBo6WfF3eEbS98,ffWgMXo20Hb5xurkdNqa in items:
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.replace(Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪౘ"),uulNDCPyef78(u"ࠫ࡭ࡺࡴࡱ࠼ࠪౙ"))
		if Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠬ࠴࡭࠴ࡷ࠻ࠫౚ") in bigdh7fpZYl4aT2keV:
			JJVg3pG9Eayr5CAn,m06mELslRjhekXGW = kDKwn73e02jNdRLG8U4HxTgpVQqI(BfWYUAnyg6eONLjiuE,bigdh7fpZYl4aT2keV)
			XoSyx7p6dqZ1CF8 = XoSyx7p6dqZ1CF8 + m06mELslRjhekXGW
			if JJVg3pG9Eayr5CAn[D2D96X5NGamBhrFwvL8VEbqiSfZIl]==ggjO5CrKVRPITaesWkxD(u"࠭࠭࠲ࠩ౛"): WFlpmsYGKNy.append(FgXzMs0YSDt(u"ࠧิ์ิๅึࠦฮศืࠪ౜")+wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠨࠢࠣࠤࡲ࠹ࡵ࠹ࠩౝ"))
			else:
				for title in JJVg3pG9Eayr5CAn:
					WFlpmsYGKNy.append(o1INZ3ViQqS0Uw5z6kMjbv(u"ࠩึ๎ึ็ัࠡะสูࠬ౞")+yU7COAbsNJ916v5L0oew2n+title)
		else:
			title = O3OVuapf0YFjbm5oUQDg(u"ࠪื๏ืแาࠢัหฺ࠭౟")+I18uSKaWhgTBeYUPD4sr(u"ࠫࠥࠦࠠ࡮ࡲ࠷ࠤࠥࠦࠧౠ")+ffWgMXo20Hb5xurkdNqa
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
			WFlpmsYGKNy.append(title)
	return fy8iFgEkrO12NR9TWBI35sjY6qHvV,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
def dkPIfFASa2eDUGEmiLJ5BNVZH9u(url,FGRX4myP68S):
	paJKP0Usbeju4liH,hFzEyHWOoRxG,xgUASuq2pdFRoYB5364tl,kENjB56TStKh,zzECVswWcGAIXhrQlZ7jMokugnv = [],[],[],[],[]
	if Gcw2nelTR864XCVruO3mAFqI5a(u"ࠬࡹࡴࡳࠩౡ") not in str(type(FGRX4myP68S)): FGRX4myP68S = FGRX4myP68S.decode(Tk9eH2qw6Brsuhj,vU6DxuzPwMpg(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ౢ"))
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(sJw9QWiq1Kr0xfeVRI(u"ࠧ࠽ࡸ࡬ࡨࡪࡵࠠࡱࡴࡨࡰࡴࡧࡤ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨౣ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if bigdh7fpZYl4aT2keV and not ml1bXR85BJyhPAVvQY(bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl]): bigdh7fpZYl4aT2keV = []
	if not bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(uulNDCPyef78(u"ࠨ࠾ࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ౤"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if bigdh7fpZYl4aT2keV and not ml1bXR85BJyhPAVvQY(bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl]): bigdh7fpZYl4aT2keV = []
	if not bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall(FmYoGejTnwKME7d9zPc(u"ࠩࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ౥"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if bigdh7fpZYl4aT2keV and not ml1bXR85BJyhPAVvQY(bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl]): bigdh7fpZYl4aT2keV = []
	if bigdh7fpZYl4aT2keV:
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		title = bigdh7fpZYl4aT2keV.rsplit(ggjO5CrKVRPITaesWkxD(u"ࠪ࠲ࠬ౦"),sJw9QWiq1Kr0xfeVRI(u"࠳൚"))[BkM54Kr7Qbqn]
		paJKP0Usbeju4liH.append(title)
		hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
	else:
		VuGmoESTAfXlv5tD76PW1Masq0peB = EcQxOa3RJm86WjTKA.findall(sJw9QWiq1Kr0xfeVRI(u"ࠫࡸࡵࡵࡳࡥࡨࡷ࠿ࠦࠪࠩ࡞࡞࠲࠯ࡅ࡜࡞ࠫࠪ౧"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if not VuGmoESTAfXlv5tD76PW1Masq0peB: VuGmoESTAfXlv5tD76PW1Masq0peB = EcQxOa3RJm86WjTKA.findall(wdftVMyzF17cYETHu(u"ࠬࡼࡡࡳࠢࡶࡳࡺࡸࡣࡦࡵࠣࡁࠥ࠮࡜ࡼ࠰࠭ࡃࡡࢃࠩࠨ౨"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if not VuGmoESTAfXlv5tD76PW1Masq0peB: VuGmoESTAfXlv5tD76PW1Masq0peB = EcQxOa3RJm86WjTKA.findall(ggjO5CrKVRPITaesWkxD(u"࠭ࡶࡢࡴࠣ࡮ࡼࠦ࠽ࠡࠪ࡟ࡿ࠳࠰࠿࡝ࡿࠬࠫ౩"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if not VuGmoESTAfXlv5tD76PW1Masq0peB: VuGmoESTAfXlv5tD76PW1Masq0peB = EcQxOa3RJm86WjTKA.findall(AAbvaXV2DQzfNHdm4U3tT(u"ࠧࡷࡣࡵࠤࡵࡲࡡࡺࡧࡵࠤࡂࠦ࠮ࠫࡁ࡟ࠬ࠭ࡢࡻ࠯ࠬࡂࡠࢂ࠯࡜ࠪࠩ౪"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if VuGmoESTAfXlv5tD76PW1Masq0peB:
			VuGmoESTAfXlv5tD76PW1Masq0peB = VuGmoESTAfXlv5tD76PW1Masq0peB[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			VuGmoESTAfXlv5tD76PW1Masq0peB = EcQxOa3RJm86WjTKA.sub(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࡳࠩࠫ࡟ࡡࢁ࡜࠭࡟࡞ࡠࡹࡢࡳ࡝ࡰ࡟ࡶࡢ࠰ࠩࠩ࡞ࡺ࠯ࡠࡢࡴ࡝ࡵࡠ࠮࠮ࡀࠧ౫"),V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࡴࠪࡠ࠶ࠨ࡜࠳ࠤ࠽ࠫ౬"),VuGmoESTAfXlv5tD76PW1Masq0peB)
			VuGmoESTAfXlv5tD76PW1Masq0peB = LB7TcZnGYdfw5lWU1RH3Oztu9PyA(SnhLjmfeJC(u"ࠪࡨ࡮ࡩࡴࠨ౭"),VuGmoESTAfXlv5tD76PW1Masq0peB)
			if isinstance(VuGmoESTAfXlv5tD76PW1Masq0peB,dict): VuGmoESTAfXlv5tD76PW1Masq0peB = [VuGmoESTAfXlv5tD76PW1Masq0peB]
			for wlJ6d8hEvpoMNSCmU in VuGmoESTAfXlv5tD76PW1Masq0peB:
				DKgcku5BX93ja,bigdh7fpZYl4aT2keV = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
				if isinstance(wlJ6d8hEvpoMNSCmU,dict):
					keys = list(wlJ6d8hEvpoMNSCmU.keys())
					if   SnhLjmfeJC(u"ࠫࡹࡿࡰࡦࠩ౮") in keys: DKgcku5BX93ja = str(wlJ6d8hEvpoMNSCmU[s5WMHyQN4mpie(u"ࠬࡺࡹࡱࡧࠪ౯")])
					if   C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠭ࡦࡪ࡮ࡨࠫ౰") in keys: bigdh7fpZYl4aT2keV = wlJ6d8hEvpoMNSCmU[N6NGJ4vpmidqMCh7yo(u"ࠧࡧ࡫࡯ࡩࠬ౱")]
					elif sJw9QWiq1Kr0xfeVRI(u"ࠨࡪ࡯ࡷࠬ౲") in keys: bigdh7fpZYl4aT2keV = wlJ6d8hEvpoMNSCmU[vU6DxuzPwMpg(u"ࠩ࡫ࡰࡸ࠭౳")]
					elif aOQTKXFL54Nl60Zhp3MbE(u"ࠪࡷࡷࡩࠧ౴") in keys: bigdh7fpZYl4aT2keV = wlJ6d8hEvpoMNSCmU[AAbvaXV2DQzfNHdm4U3tT(u"ࠫࡸࡸࡣࠨ౵")]
					if   I18uSKaWhgTBeYUPD4sr(u"ࠬࡲࡡࡣࡧ࡯ࠫ౶") in keys: title = str(wlJ6d8hEvpoMNSCmU[uulNDCPyef78(u"࠭࡬ࡢࡤࡨࡰࠬ౷")])
					elif sJw9QWiq1Kr0xfeVRI(u"ࠧࡷ࡫ࡧࡩࡴࡥࡨࡦ࡫ࡪ࡬ࡹ࠭౸") in keys: title = str(wlJ6d8hEvpoMNSCmU[C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠨࡸ࡬ࡨࡪࡵ࡟ࡩࡧ࡬࡫࡭ࡺࠧ౹")])
					elif CsDcLqQUVK4YBvHFW1(u"ࠩ࠱ࠫ౺") in bigdh7fpZYl4aT2keV: title = bigdh7fpZYl4aT2keV.rsplit(KfHAW8VGbrxi(u"ࠪ࠲ࠬ౻"),BkM54Kr7Qbqn)[BkM54Kr7Qbqn]
					else: title = bigdh7fpZYl4aT2keV
				elif isinstance(wlJ6d8hEvpoMNSCmU,str):
					bigdh7fpZYl4aT2keV = wlJ6d8hEvpoMNSCmU
					title = bigdh7fpZYl4aT2keV.rsplit(O3OVuapf0YFjbm5oUQDg(u"ࠫ࠳࠭౼"),BkM54Kr7Qbqn)[BkM54Kr7Qbqn]
				if BkM54Kr7Qbqn:
					paJKP0Usbeju4liH.append(title+OOiSqkBcMPptI+DKgcku5BX93ja)
					hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
	for bigdh7fpZYl4aT2keV,title in list(zip(hFzEyHWOoRxG,paJKP0Usbeju4liH)):
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.replace(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠬࡢ࡜࠰ࠩ౽"),AAbvaXV2DQzfNHdm4U3tT(u"࠭࠯ࠨ౾"))
		A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(url,wdftVMyzF17cYETHu(u"ࠧࡶࡴ࡯ࠫ౿"))
		ll7qCX4wJ5kQonVW6KtcMuZGSvDEs = j4lUV5BzHDI6EN()
		if CsDcLqQUVK4YBvHFW1(u"ࠨࡪࡷࡸࡵ࠭ಀ") not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = A8ECQ0qwTRzPifOGW76FK35uUvhe+bigdh7fpZYl4aT2keV
		if Hr25gta6XcqO(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨಁ") in bigdh7fpZYl4aT2keV:
			headers = {AAbvaXV2DQzfNHdm4U3tT(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧಂ"):ll7qCX4wJ5kQonVW6KtcMuZGSvDEs,Hr25gta6XcqO(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬಃ"):A8ECQ0qwTRzPifOGW76FK35uUvhe}
			eGjILXMrvnkFl9KcSoy,o4p8W9hGbEkwfOIyrgZ = kDKwn73e02jNdRLG8U4HxTgpVQqI(BfWYUAnyg6eONLjiuE,bigdh7fpZYl4aT2keV,headers)
			kENjB56TStKh += o4p8W9hGbEkwfOIyrgZ
			xgUASuq2pdFRoYB5364tl += eGjILXMrvnkFl9KcSoy
		else:
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬࢂࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫ಄")+ll7qCX4wJ5kQonVW6KtcMuZGSvDEs+PlpyFa9QMKXxOD1cvHzmI(u"࠭ࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩಅ")+A8ECQ0qwTRzPifOGW76FK35uUvhe
			kENjB56TStKh.append(bigdh7fpZYl4aT2keV)
			xgUASuq2pdFRoYB5364tl.append(title)
	OK2mcs7f1ekzACupF,paJKP0Usbeju4liH,hFzEyHWOoRxG = fy8iFgEkrO12NR9TWBI35sjY6qHvV,[],[]
	if kENjB56TStKh: OK2mcs7f1ekzACupF,paJKP0Usbeju4liH,hFzEyHWOoRxG = fy8iFgEkrO12NR9TWBI35sjY6qHvV,xgUASuq2pdFRoYB5364tl,kENjB56TStKh
	else:
		if s5WMHyQN4mpie(u"ࠧ࠽ࠩಆ") not in FGRX4myP68S and len(FGRX4myP68S)<wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠴࠴࠵൛") and FGRX4myP68S: OK2mcs7f1ekzACupF = FGRX4myP68S
		else:
			msg = EcQxOa3RJm86WjTKA.findall(ssynAg0zhSkoCpOMDV9(u"ࠨ࠾ࡧ࡭ࡻࠦࡳࡵࡻ࡯ࡩࡂࠨ࠮ࠫࡁࠥࡂ࠭ࡌࡩ࡭ࡧ࠱࠮ࡄ࠯࠼ࠨಇ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
			if not msg: msg = EcQxOa3RJm86WjTKA.findall(V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡷࡲࡢࡺ࡮ࡪࡥࡰࡡࡶࡸࡺࡨ࡟ࡵࡺࡷࠦࡃ࠮࠮ࠫࡁࠬࡀࠬಈ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
			if not msg: msg = EcQxOa3RJm86WjTKA.findall(N6NGJ4vpmidqMCh7yo(u"ࠪࡀ࡭࠸࠾ࠩࡕࡲࡶࡷࡿ࠮ࠫࡁࠬࡀࠬಉ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
			if msg: OK2mcs7f1ekzACupF = msg[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	return OK2mcs7f1ekzACupF,paJKP0Usbeju4liH,hFzEyHWOoRxG
def nGhvprJVNW7uP1aQHF6sETBeg(cCLBrGSsZf,url):
	global ppdmQ2VaW7o3F
	url = url.strip(FmYoGejTnwKME7d9zPc(u"ࠫ࠴࠭ಊ"))
	p49VlrNTy3WF,B7gtJnK24RY = fy8iFgEkrO12NR9TWBI35sjY6qHvV,{}
	headers = {s5WMHyQN4mpie(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩಋ"):j4lUV5BzHDI6EN()}
	headers[OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧಌ")] = VbHeOuU1ilzSp2ZRXwBD(url,AAbvaXV2DQzfNHdm4U3tT(u"ࠧࡶࡴ࡯ࠫ಍"))
	headers[SnhLjmfeJC(u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡎࡤࡲ࡬ࡻࡡࡨࡧࠪಎ")] = OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠩࡨࡲ࠲࡛ࡓ࠭ࡧࡱ࠿ࡶࡃ࠰࠯࠻ࠪಏ")
	headers[ssynAg0zhSkoCpOMDV9(u"ࠪࡗࡪࡩ࠭ࡇࡧࡷࡧ࡭࠳ࡄࡦࡵࡷࠫಐ")] = wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠫ࡮࡬ࡲࡢ࡯ࡨࠫ಑")
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,O3OVuapf0YFjbm5oUQDg(u"ࠬࡍࡅࡕࠩಒ"),url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LhFAGlQ19zr,EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠶ࡹࡴࠨಓ"))
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	zPt0iLTbBDlQg = E6ECvznP9m5sWFMu.code
	if not isinstance(FGRX4myP68S,str): FGRX4myP68S = FGRX4myP68S.decode(Tk9eH2qw6Brsuhj,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧಔ"))
	if O3OVuapf0YFjbm5oUQDg(u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠫࡴ࠱ࡧࠬࡤ࠮࡮࠰ࡪ࠲ࠧಕ") in FGRX4myP68S:
		CDwfqFKj3u5s64JgANQTX2RLElkz = EcQxOa3RJm86WjTKA.findall(C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠩࠫࡩࡻࡧ࡬࡝ࠪࡩࡹࡳࡩࡴࡪࡱࡱࡠ࠭ࡶࠬࡢ࠮ࡦ࠰ࡰ࠲ࡥ࠭࡝ࡧࡶࡢ࠴ࠪࡀࠫ࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬಖ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if CDwfqFKj3u5s64JgANQTX2RLElkz:
			try: p49VlrNTy3WF = sO08q1xvolnpguK4CDIQ9dk3j6L(CDwfqFKj3u5s64JgANQTX2RLElkz[D2D96X5NGamBhrFwvL8VEbqiSfZIl])
			except: p49VlrNTy3WF = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if PlpyFa9QMKXxOD1cvHzmI(u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲ࠭࡮ࠬࡶ࠮ࡱ࠰ࡹ࠲ࡥ࠭ࡴࠬࠫಗ") in FGRX4myP68S:
		CDwfqFKj3u5s64JgANQTX2RLElkz = EcQxOa3RJm86WjTKA.findall(AAbvaXV2DQzfNHdm4U3tT(u"ࠫ࠭࡫ࡶࡢ࡮࡟ࠬ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࡢࠨࡩ࠮ࡸ࠰ࡳ࠲ࡴ࠭ࡧ࠯ࡶ࠳࠰࠿ࠪ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫಘ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if CDwfqFKj3u5s64JgANQTX2RLElkz:
			try: p49VlrNTy3WF = NNSLyeFBOc(CDwfqFKj3u5s64JgANQTX2RLElkz[D2D96X5NGamBhrFwvL8VEbqiSfZIl])
			except: p49VlrNTy3WF = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	soEymUvkt19PQXVjzKau6x5 = FGRX4myP68S+p49VlrNTy3WF
	if CsDcLqQUVK4YBvHFW1(u"ࠬࠨࡩࡥ࠴ࠥࠫಙ") in soEymUvkt19PQXVjzKau6x5 or EE1jeHnIoad(u"࠭ࠢࡪࡦࠥࠫಚ") in soEymUvkt19PQXVjzKau6x5:
		DY3A7FBfduZ41b6yv5NXicln = url.split(FgXzMs0YSDt(u"ࠧ࠰ࠩಛ"))[XW57OCeGnFTLQbaqdrD9zM].replace(wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠨࡧࡰࡦࡪࡪ࠭ࠨಜ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(SnhLjmfeJC(u"ࠩ࠱࡬ࡹࡳ࡬ࠨಝ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		if sIzDXlTHYUC5L3xZGnr(u"ࠪࠦ࡮ࡪ࠲ࠣࠩಞ") in soEymUvkt19PQXVjzKau6x5: B7gtJnK24RY = {O3OVuapf0YFjbm5oUQDg(u"ࠫ࡮ࡪ࠲ࠨಟ"):DY3A7FBfduZ41b6yv5NXicln,wdftVMyzF17cYETHu(u"ࠬࡵࡰࠨಠ"):C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠩಡ")}
		elif KfHAW8VGbrxi(u"ࠧࠣ࡫ࡧࠦࠬಢ") in soEymUvkt19PQXVjzKau6x5: B7gtJnK24RY = {LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠨ࡫ࡧࠫಣ"):DY3A7FBfduZ41b6yv5NXicln,jL5CrsRwebpyDVXUc1EQP(u"ࠩࡲࡴࠬತ"):LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ࠷࠭ಥ")}
		naBFTDfp6lmKjeOywg87IAcb = headers.copy()
		naBFTDfp6lmKjeOywg87IAcb[jL5CrsRwebpyDVXUc1EQP(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪದ")] = KfHAW8VGbrxi(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫಧ")
		JOB9NFKAlRSW8eyTQDPaG7 = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,ssynAg0zhSkoCpOMDV9(u"࠭ࡐࡐࡕࡗࠫನ"),url,B7gtJnK24RY,naBFTDfp6lmKjeOywg87IAcb,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LhFAGlQ19zr,sJw9QWiq1Kr0xfeVRI(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠸࡮ࡥࠩ಩"))
		soEymUvkt19PQXVjzKau6x5 = JOB9NFKAlRSW8eyTQDPaG7.content
	NHfti7YKapB4UzvG2QOe,GlxXc0AROCzkJwKZ76ioqSLsr,TT8lkXwmu7AtxVF1BzEa5fch6g = dkPIfFASa2eDUGEmiLJ5BNVZH9u(url,soEymUvkt19PQXVjzKau6x5)
	ppdmQ2VaW7o3F[cCLBrGSsZf] = NHfti7YKapB4UzvG2QOe,GlxXc0AROCzkJwKZ76ioqSLsr,TT8lkXwmu7AtxVF1BzEa5fch6g,zPt0iLTbBDlQg
	return
ppdmQ2VaW7o3F,TSKyu4kRAsex0N5Dz7 = {},D2D96X5NGamBhrFwvL8VEbqiSfZIl
def kg8ifQSFucoCAMK4HZDGrjxs(url):
	global ppdmQ2VaW7o3F,TSKyu4kRAsex0N5Dz7
	TSKyu4kRAsex0N5Dz7 += vU6DxuzPwMpg(u"࠵࠵࠶൜")
	K4UNcvgOG9sJW = TSKyu4kRAsex0N5Dz7
	zzECVswWcGAIXhrQlZ7jMokugnv = [(BkM54Kr7Qbqn,url)]
	YLKFRH6sSIrznXBg = url.replace(ssynAg0zhSkoCpOMDV9(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩಪ"),Gcw2nelTR864XCVruO3mAFqI5a(u"ࠩ࠲ࠫಫ"))
	V5VDwKLAYM3 = EcQxOa3RJm86WjTKA.findall(o1INZ3ViQqS0Uw5z6kMjbv(u"ࠪࡢ࠭࠴ࠪࡀ࠼࠲࠳࠳࠰࠿ࠪ࠱ࠫ࠲࠯ࡅࠩ࠰ࠪ࠱࠮ࡄ࠯ࠤࠨಬ"),YLKFRH6sSIrznXBg+sIzDXlTHYUC5L3xZGnr(u"ࠫ࠴࠭ಭ"),EcQxOa3RJm86WjTKA.DOTALL)
	start,wdbeFu4js3OSU,end = V5VDwKLAYM3[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	end = end.strip(LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠬ࠵ࠧಮ"))
	L6L4KBFw3qZunOdbHQ = len(wdbeFu4js3OSU)<vD4Fh6ictZ7wME or wdbeFu4js3OSU in [I18uSKaWhgTBeYUPD4sr(u"࠭ࡦࡪ࡮ࡨࠫಯ"),s5WMHyQN4mpie(u"ࠧࡷ࡫ࡧࡩࡴ࠭ರ"),s5WMHyQN4mpie(u"ࠨࡸ࡬ࡨࡪࡵࡥ࡮ࡤࡨࡨࠬಱ"),sIzDXlTHYUC5L3xZGnr(u"ࠩࡤ࡮ࡦࡾࠧಲ"),Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠪಳ"),EE1jeHnIoad(u"ࠫࡲ࡯ࡲࡳࡱࡵࠫ಴")]
	if not L6L4KBFw3qZunOdbHQ: zzECVswWcGAIXhrQlZ7jMokugnv.append([teaC5j4HuGDqpwcmUzJ,start+jL5CrsRwebpyDVXUc1EQP(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭ವ")+wdbeFu4js3OSU+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"࠭࠯ࠨಶ")+end])
	if end: zzECVswWcGAIXhrQlZ7jMokugnv.append([XW57OCeGnFTLQbaqdrD9zM,start+Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠧ࠰ࠩಷ")+wdbeFu4js3OSU+I18uSKaWhgTBeYUPD4sr(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩಸ")+end])
	if AAbvaXV2DQzfNHdm4U3tT(u"ࠩ࠱࡬ࡹࡳ࡬ࠨಹ") in wdbeFu4js3OSU:
		XbPSnYKhFlWZDo = wdbeFu4js3OSU.replace(ggjO5CrKVRPITaesWkxD(u"ࠪ࠲࡭ࡺ࡭࡭ࠩ಺"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		zzECVswWcGAIXhrQlZ7jMokugnv.append([vD4Fh6ictZ7wME,start+OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠫ࠴࠭಻")+XbPSnYKhFlWZDo+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠬ࠵಼ࠧ")+end])
		zzECVswWcGAIXhrQlZ7jMokugnv.append([Gcw2nelTR864XCVruO3mAFqI5a(u"࠺൝"),start+CsDcLqQUVK4YBvHFW1(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧಽ")+XbPSnYKhFlWZDo+SnhLjmfeJC(u"ࠧ࠰ࠩಾ")+end])
		if end: zzECVswWcGAIXhrQlZ7jMokugnv.append([sIzDXlTHYUC5L3xZGnr(u"࠼൞"),start+vU6DxuzPwMpg(u"ࠨ࠱ࠪಿ")+XbPSnYKhFlWZDo+C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪೀ")+end])
	elif aOQTKXFL54Nl60Zhp3MbE(u"ࠪ࠲࡭ࡺ࡭࡭ࠩು") in end:
		PPIw9BmqM8LyGDfOuVah7ZSn03z = end.replace(uulNDCPyef78(u"ࠫ࠳࡮ࡴ࡮࡮ࠪೂ"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		zzECVswWcGAIXhrQlZ7jMokugnv.append([CsDcLqQUVK4YBvHFW1(u"࠷ൟ"),start+Gcw2nelTR864XCVruO3mAFqI5a(u"ࠬ࠵ࠧೃ")+wdbeFu4js3OSU+PlpyFa9QMKXxOD1cvHzmI(u"࠭࠯ࠨೄ")+PPIw9BmqM8LyGDfOuVah7ZSn03z])
		if not L6L4KBFw3qZunOdbHQ: zzECVswWcGAIXhrQlZ7jMokugnv.append([jL5CrsRwebpyDVXUc1EQP(u"࠹ൠ"),start+AAbvaXV2DQzfNHdm4U3tT(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ೅")+wdbeFu4js3OSU+CsDcLqQUVK4YBvHFW1(u"ࠨ࠱ࠪೆ")+PPIw9BmqM8LyGDfOuVah7ZSn03z])
		zzECVswWcGAIXhrQlZ7jMokugnv.append([ggjO5CrKVRPITaesWkxD(u"࠻ൡ"),start+vU6DxuzPwMpg(u"ࠩ࠲ࠫೇ")+wdbeFu4js3OSU+EE1jeHnIoad(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫೈ")+PPIw9BmqM8LyGDfOuVah7ZSn03z])
	else:
		if not L6L4KBFw3qZunOdbHQ: zzECVswWcGAIXhrQlZ7jMokugnv.append([PlpyFa9QMKXxOD1cvHzmI(u"࠴࠴ൢ"),start+oRJAfwD957WkUyBM1Ehu8m(u"ࠫ࠴࠭೉")+wdbeFu4js3OSU+N6NGJ4vpmidqMCh7yo(u"ࠬ࠴ࡨࡵ࡯࡯ࠫೊ")])
		if not L6L4KBFw3qZunOdbHQ: zzECVswWcGAIXhrQlZ7jMokugnv.append([wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠵࠶ൣ"),start+PlpyFa9QMKXxOD1cvHzmI(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧೋ")+wdbeFu4js3OSU+uulNDCPyef78(u"ࠧ࠯ࡪࡷࡱࡱ࠭ೌ")])
		if end: zzECVswWcGAIXhrQlZ7jMokugnv.append([EE1jeHnIoad(u"࠶࠸൤"),start+oRJAfwD957WkUyBM1Ehu8m(u"ࠨ࠱್ࠪ")+wdbeFu4js3OSU+oRJAfwD957WkUyBM1Ehu8m(u"ࠩ࠲ࠫ೎")+end+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪ࠲࡭ࡺ࡭࡭ࠩ೏")])
		if end: zzECVswWcGAIXhrQlZ7jMokugnv.append([OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠷࠳൥"),start+AAbvaXV2DQzfNHdm4U3tT(u"ࠫ࠴࠭೐")+wdbeFu4js3OSU+PlpyFa9QMKXxOD1cvHzmI(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭೑")+end+CsDcLqQUVK4YBvHFW1(u"࠭࠮ࡩࡶࡰࡰࠬ೒")])
	if L6L4KBFw3qZunOdbHQ and end:
		end = end.replace(FgXzMs0YSDt(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ೓"),ssynAg0zhSkoCpOMDV9(u"ࠨ࠱ࠪ೔"))
		zzECVswWcGAIXhrQlZ7jMokugnv.append([PlpyFa9QMKXxOD1cvHzmI(u"࠱࠵൦"),start+KfHAW8VGbrxi(u"ࠩ࠲ࠫೕ")+end])
		zzECVswWcGAIXhrQlZ7jMokugnv.append([V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠲࠷൧"),start+aOQTKXFL54Nl60Zhp3MbE(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫೖ")+end])
		if I18uSKaWhgTBeYUPD4sr(u"ࠫ࠳࡮ࡴ࡮࡮ࠪ೗") in end:
			PPIw9BmqM8LyGDfOuVah7ZSn03z = end.replace(jL5CrsRwebpyDVXUc1EQP(u"ࠬ࠴ࡨࡵ࡯࡯ࠫ೘"),fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			zzECVswWcGAIXhrQlZ7jMokugnv.append([LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠳࠹൨"),start+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"࠭࠯ࠨ೙")+PPIw9BmqM8LyGDfOuVah7ZSn03z])
			zzECVswWcGAIXhrQlZ7jMokugnv.append([Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠴࠻൩"),start+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ೚")+PPIw9BmqM8LyGDfOuVah7ZSn03z])
		else:
			zzECVswWcGAIXhrQlZ7jMokugnv.append([vU6DxuzPwMpg(u"࠵࠽൪"),start+aOQTKXFL54Nl60Zhp3MbE(u"ࠨ࠱ࠪ೛")+end+jL5CrsRwebpyDVXUc1EQP(u"ࠩ࠱࡬ࡹࡳ࡬ࠨ೜")])
			zzECVswWcGAIXhrQlZ7jMokugnv.append([wdftVMyzF17cYETHu(u"࠶࠿൫"),start+wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫೝ")+end+sJw9QWiq1Kr0xfeVRI(u"ࠫ࠳࡮ࡴ࡮࡮ࠪೞ")])
	BBZ5oVf6pUWMjurl3zRC1x = []
	for aiuh0XlPswEK,R9b8gUvoB4wOfkTIjlEsZrM5LtinpS in zzECVswWcGAIXhrQlZ7jMokugnv:
		ppdmQ2VaW7o3F[K4UNcvgOG9sJW+aiuh0XlPswEK] = [zA8Ry1KDvmr3w4B5xeP,zA8Ry1KDvmr3w4B5xeP,zA8Ry1KDvmr3w4B5xeP,zA8Ry1KDvmr3w4B5xeP]
		pOfV2ewdoR = YMsWIfu7ojp2t4XJyZN05aC3l(daemon=EsCplGc5N4mBuYW0RVQt6b,target=nGhvprJVNW7uP1aQHF6sETBeg,args=(K4UNcvgOG9sJW+aiuh0XlPswEK,R9b8gUvoB4wOfkTIjlEsZrM5LtinpS))
		BBZ5oVf6pUWMjurl3zRC1x.append(pOfV2ewdoR)
	def xywa5QMgJmUicBh8WXzG0():
		B86BtJkdcozNuC4 = LhFAGlQ19zr
		for s9qgDT8oclCrdXK6EUO in ppdmQ2VaW7o3F:
			if not s9qgDT8oclCrdXK6EUO: break
		else: B86BtJkdcozNuC4 = EsCplGc5N4mBuYW0RVQt6b
		cpwFIvHO0Db7hKTylq6S4nJj = bEWpDHXjCBqd7aOiN6UG5k.Player().isPlaying() if I4t9qonjrm.resolveonly else EsCplGc5N4mBuYW0RVQt6b
		return B86BtJkdcozNuC4 or not cpwFIvHO0Db7hKTylq6S4nJj
	kkfj6pyAalMWxoJKmnhFYutVrI9PZd(BBZ5oVf6pUWMjurl3zRC1x,As7IrxH92BnhkX5aN0OKyUdwZ,oRJAfwD957WkUyBM1Ehu8m(u"࠶࠮࠲൬"),teaC5j4HuGDqpwcmUzJ,xywa5QMgJmUicBh8WXzG0)
	OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,[],[]
	AkhxDn6FEUJage2QMbCjvy7fuldrX = []
	for aiuh0XlPswEK,bigdh7fpZYl4aT2keV in zzECVswWcGAIXhrQlZ7jMokugnv:
		FmOtqUkXzygshDnKZ2aSRriE5o,lCsdk2v4gS9RceEb,jVp4UoKLIW1XxHer,PSYUz2JbCF9jKBZXl1gtQAvrMONo = ppdmQ2VaW7o3F[K4UNcvgOG9sJW+aiuh0XlPswEK]
		if not XoSyx7p6dqZ1CF8 and jVp4UoKLIW1XxHer: WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = lCsdk2v4gS9RceEb,jVp4UoKLIW1XxHer
		if not OK2mcs7f1ekzACupF and FmOtqUkXzygshDnKZ2aSRriE5o: OK2mcs7f1ekzACupF = FmOtqUkXzygshDnKZ2aSRriE5o
		if PSYUz2JbCF9jKBZXl1gtQAvrMONo: AkhxDn6FEUJage2QMbCjvy7fuldrX.append(PSYUz2JbCF9jKBZXl1gtQAvrMONo)
	AkhxDn6FEUJage2QMbCjvy7fuldrX = list(set(AkhxDn6FEUJage2QMbCjvy7fuldrX))
	if not OK2mcs7f1ekzACupF and len(AkhxDn6FEUJage2QMbCjvy7fuldrX)==BkM54Kr7Qbqn:
		zPt0iLTbBDlQg = AkhxDn6FEUJage2QMbCjvy7fuldrX[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		if zPt0iLTbBDlQg!=LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠲࠱࠲൭"):
			if zPt0iLTbBDlQg<D2D96X5NGamBhrFwvL8VEbqiSfZIl: OK2mcs7f1ekzACupF = EE1jeHnIoad(u"ࠬ࡜ࡩࡥࡧࡲࠤࡵࡧࡧࡦ࠱ࡶࡩࡷࡼࡥࡳࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡤࡧࡨ࡫ࡳࡴ࡫ࡥࡰࡪ࠭೟")
			else:
				OK2mcs7f1ekzACupF = sJw9QWiq1Kr0xfeVRI(u"࠭ࡈࡕࡖࡓࠤࡊࡸࡲࡰࡴ࠽ࠤࠬೠ")+str(zPt0iLTbBDlQg)
				if jTDWgftK7NEmx0JAkOn2aRIvweq: import http.client as m5XE8JHPAK0OWtZNfcsS
				else: import httplib as m5XE8JHPAK0OWtZNfcsS
				try: OK2mcs7f1ekzACupF += OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"ࠧࠡࠪࠣࠫೡ")+m5XE8JHPAK0OWtZNfcsS.responses[zPt0iLTbBDlQg]+CsDcLqQUVK4YBvHFW1(u"ࠨࠢࠬࠫೢ")
				except: pass
	uUqrNPcXKBoQ0slv.sleep(BkM54Kr7Qbqn)
	return OK2mcs7f1ekzACupF,WFlpmsYGKNy,XoSyx7p6dqZ1CF8
class PIAJK76UbRCqEOyl(nn19vN7ifGslVJODZWzCSudBK8.WindowDialog):
	def __init__(LjRoTMDiSwQlCmzO1, *args, **Ard3vPyNGLDTBYUQKc0pigVfM9H):
		vpG4NSmLh6AjzZnow = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(uugoLac4UGZztBeijxW1k0, sJw9QWiq1Kr0xfeVRI(u"ࠩࡵࡩࡸࡵࡵࡳࡥࡨࡷࠬೣ"), uulNDCPyef78(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠸ࠧ೤"), FgXzMs0YSDt(u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡦ࡬࠴ࡰ࡯ࡩࠪ೥"))
		w2sIgZDF8aJkRTq9t4ifKXmL51 = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(uugoLac4UGZztBeijxW1k0, wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠬࡸࡥࡴࡱࡸࡶࡨ࡫ࡳࠨ೦"), I18uSKaWhgTBeYUPD4sr(u"࠭ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠴ࠪ೧"), N6NGJ4vpmidqMCh7yo(u"ࠧࡴࡧ࡯ࡩࡨࡺࡥࡥ࠰ࡳࡲ࡬࠭೨"))
		UuJxyt0aljmR45FkLirsGYMz = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(uugoLac4UGZztBeijxW1k0, uulNDCPyef78(u"ࠨࡴࡨࡷࡴࡻࡲࡤࡧࡶࠫ೩"), FgXzMs0YSDt(u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠷࠭೪"), EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪࡦࡺࡺࡴࡰࡰࡩࡳ࠳ࡶ࡮ࡨࠩ೫"))
		Wo547IGYMFbf3wBmzsr8LHUlinEkp = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(uugoLac4UGZztBeijxW1k0, wdftVMyzF17cYETHu(u"ࠫࡷ࡫ࡳࡰࡷࡵࡧࡪࡹࠧ೬"), wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠳ࠩ೭"), oRJAfwD957WkUyBM1Ehu8m(u"࠭ࡢࡶࡶࡷࡳࡳࡴࡦ࠯ࡲࡱ࡫ࠬ೮"))
		OsJXcUjtIxgMe3k = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(uugoLac4UGZztBeijxW1k0, C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧࡳࡧࡶࡳࡺࡸࡣࡦࡵࠪ೯"), ssynAg0zhSkoCpOMDV9(u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠶ࠬ೰"), I18uSKaWhgTBeYUPD4sr(u"ࠩࡥࡹࡹࡺ࡯࡯ࡤࡪ࠲ࡵࡴࡧࠨೱ"))
		LjRoTMDiSwQlCmzO1.cancelled = LhFAGlQ19zr
		LjRoTMDiSwQlCmzO1.chk = [D2D96X5NGamBhrFwvL8VEbqiSfZIl] * Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠺൮")
		LjRoTMDiSwQlCmzO1.chkbutton = [D2D96X5NGamBhrFwvL8VEbqiSfZIl] * Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"࠻൯")
		LjRoTMDiSwQlCmzO1.chkstate = [LhFAGlQ19zr] * N6NGJ4vpmidqMCh7yo(u"࠼൰")
		Pe5JWZOgk2M1, fO8xST9mGiDFKyVnAYblUM, h2vmDPol1Jt9M3HpeyLq, pqknv97LyzcFadOmRWYP4tJ = EE1jeHnIoad(u"࠶࠺࠶൱"), D2D96X5NGamBhrFwvL8VEbqiSfZIl, FmYoGejTnwKME7d9zPc(u"࠼࠶࠰൲"), C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠽࠶࠱൳")
		NQhbwa15zTfAkrGHnJKjStLX = Pe5JWZOgk2M1+h2vmDPol1Jt9M3HpeyLq//teaC5j4HuGDqpwcmUzJ
		nFIabNP5Vl10ER, VuCWKJ0rygGks2P6T, cJbdjEHuWAt9ia8CMofpqTVFLkv1, kv8lBX5ZA7taoSFO1TMg6UmhrGxD = ggjO5CrKVRPITaesWkxD(u"࠴࠷࠸൵"), OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠱࠳࠲൴"), Gcw2nelTR864XCVruO3mAFqI5a(u"࠷࠳࠴൶"), Gcw2nelTR864XCVruO3mAFqI5a(u"࠷࠳࠴൶")
		w6Yif0PA4eXHkIJjT = nFIabNP5Vl10ER+cJbdjEHuWAt9ia8CMofpqTVFLkv1//teaC5j4HuGDqpwcmUzJ
		ZEPIU6OivjVC, Ol7RLFApSwCNg4r0Wy5hoB26ntkb, NvwV4igSZcOjbUTRKfXh, udxKAgmTjF2f = sJw9QWiq1Kr0xfeVRI(u"࠵࠵࠶൸"), sJw9QWiq1Kr0xfeVRI(u"࠻࠻࠵൹"), s5WMHyQN4mpie(u"࠴࠹࠵൷"), LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠻࠰ൺ")
		M8PVQmnIZzNtAK = NQhbwa15zTfAkrGHnJKjStLX-NvwV4igSZcOjbUTRKfXh-ZEPIU6OivjVC//teaC5j4HuGDqpwcmUzJ
		m1DAZujH8SanrQVJNk0vcRpgdl7w = NQhbwa15zTfAkrGHnJKjStLX+ZEPIU6OivjVC//teaC5j4HuGDqpwcmUzJ
		WWCNTjqyw86VhSRplzb4oYgLrkvZ, xTfsrmhq5gYySvuac40tX8wdj, rwxeJdW1UO0nDz7ckqymRip8, PwS4vGBaOZE = KfHAW8VGbrxi(u"࠳࠶࠷ൻ"), wdftVMyzF17cYETHu(u"࠴࠲ർ"), FgXzMs0YSDt(u"࠸࠴࠵ൾ"), Gcw2nelTR864XCVruO3mAFqI5a(u"࠷࠳ൽ")
		rroWyzOIJf3t, GXS08qpY1rCeTEibMWc, hrAgKMNYECBjwZDa3fyP4zTLGdI, VV3gIpBAZSXvhOdwleKPzUE = sJw9QWiq1Kr0xfeVRI(u"࠷࠺࠻ൿ"), s5WMHyQN4mpie(u"࠷࠱ං"), LYIgTBeSmZWotDh4bnyQkvM50siu(u"࠻࠰࠱ඁ"), FgXzMs0YSDt(u"࠺࠶඀")
		WiuKU9nahMqGLC80SoeAy54 = sJw9QWiq1Kr0xfeVRI(u"࠱࠰࠼ඃ")
		Pe5JWZOgk2M1, fO8xST9mGiDFKyVnAYblUM, h2vmDPol1Jt9M3HpeyLq, pqknv97LyzcFadOmRWYP4tJ = int(Pe5JWZOgk2M1*WiuKU9nahMqGLC80SoeAy54), int(fO8xST9mGiDFKyVnAYblUM*WiuKU9nahMqGLC80SoeAy54), int(h2vmDPol1Jt9M3HpeyLq*WiuKU9nahMqGLC80SoeAy54), int(pqknv97LyzcFadOmRWYP4tJ*WiuKU9nahMqGLC80SoeAy54)
		nFIabNP5Vl10ER, VuCWKJ0rygGks2P6T, cJbdjEHuWAt9ia8CMofpqTVFLkv1, kv8lBX5ZA7taoSFO1TMg6UmhrGxD = int(nFIabNP5Vl10ER*WiuKU9nahMqGLC80SoeAy54), int(VuCWKJ0rygGks2P6T*WiuKU9nahMqGLC80SoeAy54), int(cJbdjEHuWAt9ia8CMofpqTVFLkv1*WiuKU9nahMqGLC80SoeAy54), int(kv8lBX5ZA7taoSFO1TMg6UmhrGxD*WiuKU9nahMqGLC80SoeAy54)
		M8PVQmnIZzNtAK, YP7z4vT5Ssp, OKnDU7vwQ3oBbJk2FtARZx1y, ljODxuFwcy0bgqk = int(M8PVQmnIZzNtAK*WiuKU9nahMqGLC80SoeAy54), int(Ol7RLFApSwCNg4r0Wy5hoB26ntkb*WiuKU9nahMqGLC80SoeAy54), int(NvwV4igSZcOjbUTRKfXh*WiuKU9nahMqGLC80SoeAy54), int(udxKAgmTjF2f*WiuKU9nahMqGLC80SoeAy54)
		m1DAZujH8SanrQVJNk0vcRpgdl7w, GsoT5LblKaZ9PcVR6AuJMQyWw4jY, lo5bKBSskLfHQ8OvaqYMTF, b21J0DUsunwYv6mN7Qd = int(m1DAZujH8SanrQVJNk0vcRpgdl7w*WiuKU9nahMqGLC80SoeAy54), int(Ol7RLFApSwCNg4r0Wy5hoB26ntkb*WiuKU9nahMqGLC80SoeAy54), int(NvwV4igSZcOjbUTRKfXh*WiuKU9nahMqGLC80SoeAy54), int(udxKAgmTjF2f*WiuKU9nahMqGLC80SoeAy54)
		WWCNTjqyw86VhSRplzb4oYgLrkvZ, xTfsrmhq5gYySvuac40tX8wdj, rwxeJdW1UO0nDz7ckqymRip8, PwS4vGBaOZE = int(WWCNTjqyw86VhSRplzb4oYgLrkvZ*WiuKU9nahMqGLC80SoeAy54), int(xTfsrmhq5gYySvuac40tX8wdj*WiuKU9nahMqGLC80SoeAy54), int(rwxeJdW1UO0nDz7ckqymRip8*WiuKU9nahMqGLC80SoeAy54), int(PwS4vGBaOZE*WiuKU9nahMqGLC80SoeAy54)
		rroWyzOIJf3t, GXS08qpY1rCeTEibMWc, hrAgKMNYECBjwZDa3fyP4zTLGdI, VV3gIpBAZSXvhOdwleKPzUE = int(rroWyzOIJf3t*WiuKU9nahMqGLC80SoeAy54), int(GXS08qpY1rCeTEibMWc*WiuKU9nahMqGLC80SoeAy54), int(hrAgKMNYECBjwZDa3fyP4zTLGdI*WiuKU9nahMqGLC80SoeAy54), int(VV3gIpBAZSXvhOdwleKPzUE*WiuKU9nahMqGLC80SoeAy54)
		kHDhKzNMj5bYLW3rPwsA6xyRd = nn19vN7ifGslVJODZWzCSudBK8.ControlImage(Pe5JWZOgk2M1, fO8xST9mGiDFKyVnAYblUM, h2vmDPol1Jt9M3HpeyLq, pqknv97LyzcFadOmRWYP4tJ, vpG4NSmLh6AjzZnow)
		LjRoTMDiSwQlCmzO1.addControl(kHDhKzNMj5bYLW3rPwsA6xyRd)
		LjRoTMDiSwQlCmzO1.iteration = Ard3vPyNGLDTBYUQKc0pigVfM9H.get(Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪ࡭ࡹ࡫ࡲࡢࡶ࡬ࡳࡳ࠭ೲ"))
		f32Ju6ngXshNKwPeczL = WydpaVx5YmLoCiIgA34eEBlb+wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠫๆำีࠡล้หࠥหๆิษ้ࠤํ๊ำหࠢิ์อ๎สࠡࠢࠣࠤࠥࠦࠠࠡࠢࠪೳ")+C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬอไๆฯส์้ฯࠠาไ่ࠤࠥ࠭೴")+str(LjRoTMDiSwQlCmzO1.iteration)+T7ASIp1ZYwio9HQ8cObJK
		LjRoTMDiSwQlCmzO1.strActionInfo = nn19vN7ifGslVJODZWzCSudBK8.ControlLabel(WWCNTjqyw86VhSRplzb4oYgLrkvZ, xTfsrmhq5gYySvuac40tX8wdj, rwxeJdW1UO0nDz7ckqymRip8, PwS4vGBaOZE, f32Ju6ngXshNKwPeczL, jL5CrsRwebpyDVXUc1EQP(u"࠭ࡦࡰࡰࡷ࠵࠸࠭೵"))
		LjRoTMDiSwQlCmzO1.addControl(LjRoTMDiSwQlCmzO1.strActionInfo)
		POjaBmHqzpsx1IYw7kQM4R = nn19vN7ifGslVJODZWzCSudBK8.ControlImage(nFIabNP5Vl10ER, VuCWKJ0rygGks2P6T, cJbdjEHuWAt9ia8CMofpqTVFLkv1, kv8lBX5ZA7taoSFO1TMg6UmhrGxD, Ard3vPyNGLDTBYUQKc0pigVfM9H.get(s5WMHyQN4mpie(u"ࠧࡤࡣࡳࡸࡨ࡮ࡡࠨ೶")))
		LjRoTMDiSwQlCmzO1.addControl(POjaBmHqzpsx1IYw7kQM4R)
		VVRvTDdwJ8 = WydpaVx5YmLoCiIgA34eEBlb+Ard3vPyNGLDTBYUQKc0pigVfM9H.get(QjAINyUC7MDRq5d8e4vl9(u"ࠨ࡯ࡶ࡫ࠬ೷"))+T7ASIp1ZYwio9HQ8cObJK
		LjRoTMDiSwQlCmzO1.strActionInfo = nn19vN7ifGslVJODZWzCSudBK8.ControlLabel(rroWyzOIJf3t, GXS08qpY1rCeTEibMWc, hrAgKMNYECBjwZDa3fyP4zTLGdI, VV3gIpBAZSXvhOdwleKPzUE, VVRvTDdwJ8, Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠩࡩࡳࡳࡺ࠱࠴ࠩ೸"))
		LjRoTMDiSwQlCmzO1.addControl(LjRoTMDiSwQlCmzO1.strActionInfo)
		text = WydpaVx5YmLoCiIgA34eEBlb+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪาึ๎ฬࠨ೹")+T7ASIp1ZYwio9HQ8cObJK
		LjRoTMDiSwQlCmzO1.cancelbutton = nn19vN7ifGslVJODZWzCSudBK8.ControlButton(M8PVQmnIZzNtAK, YP7z4vT5Ssp, OKnDU7vwQ3oBbJk2FtARZx1y, ljODxuFwcy0bgqk, text, focusTexture=OsJXcUjtIxgMe3k, noFocusTexture=UuJxyt0aljmR45FkLirsGYMz, alignment=SnhLjmfeJC(u"࠴඄"))
		text = WydpaVx5YmLoCiIgA34eEBlb+sJw9QWiq1Kr0xfeVRI(u"ࠫฬูสๆำสีࠬ೺")+T7ASIp1ZYwio9HQ8cObJK
		LjRoTMDiSwQlCmzO1.okbutton = nn19vN7ifGslVJODZWzCSudBK8.ControlButton(m1DAZujH8SanrQVJNk0vcRpgdl7w, GsoT5LblKaZ9PcVR6AuJMQyWw4jY, lo5bKBSskLfHQ8OvaqYMTF, b21J0DUsunwYv6mN7Qd, text, focusTexture=OsJXcUjtIxgMe3k, noFocusTexture=UuJxyt0aljmR45FkLirsGYMz, alignment=C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠵අ"))
		LjRoTMDiSwQlCmzO1.addControl(LjRoTMDiSwQlCmzO1.okbutton)
		LjRoTMDiSwQlCmzO1.addControl(LjRoTMDiSwQlCmzO1.cancelbutton)
		Bk4HGa0bxTYqpJdyt, bDqfjnu28Nt0743Bg9PU6Z = kv8lBX5ZA7taoSFO1TMg6UmhrGxD//XW57OCeGnFTLQbaqdrD9zM, cJbdjEHuWAt9ia8CMofpqTVFLkv1//XW57OCeGnFTLQbaqdrD9zM
		for pk6YWixXFSrDLKCnlN39w in range(OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠽ආ")):
			AHw24UnoN1scjm9D = pk6YWixXFSrDLKCnlN39w // XW57OCeGnFTLQbaqdrD9zM
			Q4vaq0zH7TAkmrgyNXZbpY = pk6YWixXFSrDLKCnlN39w % XW57OCeGnFTLQbaqdrD9zM
			YRkm7ZCbuwWeVMOKo5yU1Qh3l9jSaI = nFIabNP5Vl10ER + (bDqfjnu28Nt0743Bg9PU6Z * Q4vaq0zH7TAkmrgyNXZbpY)
			msEJL0iO9TBwXQG = VuCWKJ0rygGks2P6T + (Bk4HGa0bxTYqpJdyt * AHw24UnoN1scjm9D)
			LjRoTMDiSwQlCmzO1.chk[pk6YWixXFSrDLKCnlN39w] = nn19vN7ifGslVJODZWzCSudBK8.ControlImage(YRkm7ZCbuwWeVMOKo5yU1Qh3l9jSaI, msEJL0iO9TBwXQG, bDqfjnu28Nt0743Bg9PU6Z, Bk4HGa0bxTYqpJdyt, w2sIgZDF8aJkRTq9t4ifKXmL51)
			LjRoTMDiSwQlCmzO1.addControl(LjRoTMDiSwQlCmzO1.chk[pk6YWixXFSrDLKCnlN39w])
			LjRoTMDiSwQlCmzO1.chk[pk6YWixXFSrDLKCnlN39w].setVisible(LhFAGlQ19zr)
			LjRoTMDiSwQlCmzO1.chkbutton[pk6YWixXFSrDLKCnlN39w] = nn19vN7ifGslVJODZWzCSudBK8.ControlButton(YRkm7ZCbuwWeVMOKo5yU1Qh3l9jSaI, msEJL0iO9TBwXQG, bDqfjnu28Nt0743Bg9PU6Z, Bk4HGa0bxTYqpJdyt, str(pk6YWixXFSrDLKCnlN39w + BkM54Kr7Qbqn), font=I18uSKaWhgTBeYUPD4sr(u"ࠬ࡬࡯࡯ࡶ࠴࠷ࠬ೻"), focusTexture=UuJxyt0aljmR45FkLirsGYMz, noFocusTexture=Wo547IGYMFbf3wBmzsr8LHUlinEkp)
			LjRoTMDiSwQlCmzO1.addControl(LjRoTMDiSwQlCmzO1.chkbutton[pk6YWixXFSrDLKCnlN39w])
		for pk6YWixXFSrDLKCnlN39w in range(SnhLjmfeJC(u"࠾ඇ")):
			F7Qg9KjpMUsinuvGV = (pk6YWixXFSrDLKCnlN39w // XW57OCeGnFTLQbaqdrD9zM) * XW57OCeGnFTLQbaqdrD9zM
			evj4mUIDho = F7Qg9KjpMUsinuvGV + (pk6YWixXFSrDLKCnlN39w + BkM54Kr7Qbqn) % XW57OCeGnFTLQbaqdrD9zM
			WtF0mlUNKV6I = F7Qg9KjpMUsinuvGV + (pk6YWixXFSrDLKCnlN39w - BkM54Kr7Qbqn) % XW57OCeGnFTLQbaqdrD9zM
			X3CbY0uApnU6isceyBwxdzVO = (pk6YWixXFSrDLKCnlN39w - XW57OCeGnFTLQbaqdrD9zM) % CsDcLqQUVK4YBvHFW1(u"࠿ඈ")
			lXHdyRsZqmpt69Fb4JYf = (pk6YWixXFSrDLKCnlN39w + XW57OCeGnFTLQbaqdrD9zM) % PlpyFa9QMKXxOD1cvHzmI(u"࠹ඉ")
			LjRoTMDiSwQlCmzO1.chkbutton[pk6YWixXFSrDLKCnlN39w].controlRight(LjRoTMDiSwQlCmzO1.chkbutton[evj4mUIDho])
			LjRoTMDiSwQlCmzO1.chkbutton[pk6YWixXFSrDLKCnlN39w].controlLeft(LjRoTMDiSwQlCmzO1.chkbutton[WtF0mlUNKV6I])
			if pk6YWixXFSrDLKCnlN39w <= teaC5j4HuGDqpwcmUzJ:
				LjRoTMDiSwQlCmzO1.chkbutton[pk6YWixXFSrDLKCnlN39w].controlUp(LjRoTMDiSwQlCmzO1.okbutton)
			else:
				LjRoTMDiSwQlCmzO1.chkbutton[pk6YWixXFSrDLKCnlN39w].controlUp(LjRoTMDiSwQlCmzO1.chkbutton[X3CbY0uApnU6isceyBwxdzVO])
			if pk6YWixXFSrDLKCnlN39w >= FmYoGejTnwKME7d9zPc(u"࠷ඊ"):
				LjRoTMDiSwQlCmzO1.chkbutton[pk6YWixXFSrDLKCnlN39w].controlDown(LjRoTMDiSwQlCmzO1.okbutton)
			else:
				LjRoTMDiSwQlCmzO1.chkbutton[pk6YWixXFSrDLKCnlN39w].controlDown(LjRoTMDiSwQlCmzO1.chkbutton[lXHdyRsZqmpt69Fb4JYf])
		LjRoTMDiSwQlCmzO1.okbutton.controlLeft(LjRoTMDiSwQlCmzO1.cancelbutton)
		LjRoTMDiSwQlCmzO1.okbutton.controlRight(LjRoTMDiSwQlCmzO1.cancelbutton)
		LjRoTMDiSwQlCmzO1.cancelbutton.controlLeft(LjRoTMDiSwQlCmzO1.okbutton)
		LjRoTMDiSwQlCmzO1.cancelbutton.controlRight(LjRoTMDiSwQlCmzO1.okbutton)
		LjRoTMDiSwQlCmzO1.okbutton.controlDown(LjRoTMDiSwQlCmzO1.chkbutton[teaC5j4HuGDqpwcmUzJ])
		LjRoTMDiSwQlCmzO1.okbutton.controlUp(LjRoTMDiSwQlCmzO1.chkbutton[wdftVMyzF17cYETHu(u"࠺උ")])
		LjRoTMDiSwQlCmzO1.cancelbutton.controlDown(LjRoTMDiSwQlCmzO1.chkbutton[D2D96X5NGamBhrFwvL8VEbqiSfZIl])
		LjRoTMDiSwQlCmzO1.cancelbutton.controlUp(LjRoTMDiSwQlCmzO1.chkbutton[FgXzMs0YSDt(u"࠹ඌ")])
		LjRoTMDiSwQlCmzO1.setFocus(LjRoTMDiSwQlCmzO1.okbutton)
	def get(LjRoTMDiSwQlCmzO1):
		LjRoTMDiSwQlCmzO1.doModal()
		LjRoTMDiSwQlCmzO1.close()
		if not LjRoTMDiSwQlCmzO1.cancelled:
			return [pk6YWixXFSrDLKCnlN39w for pk6YWixXFSrDLKCnlN39w in range(AAbvaXV2DQzfNHdm4U3tT(u"࠽ඍ")) if LjRoTMDiSwQlCmzO1.chkstate[pk6YWixXFSrDLKCnlN39w]]
	def onControl(LjRoTMDiSwQlCmzO1, XXu7raekSlFyL8sn6RoIDGBiYd92):
		if XXu7raekSlFyL8sn6RoIDGBiYd92.getId() == LjRoTMDiSwQlCmzO1.okbutton.getId() and any(LjRoTMDiSwQlCmzO1.chkstate):
			LjRoTMDiSwQlCmzO1.close()
		elif XXu7raekSlFyL8sn6RoIDGBiYd92.getId() == LjRoTMDiSwQlCmzO1.cancelbutton.getId():
			LjRoTMDiSwQlCmzO1.cancelled = EsCplGc5N4mBuYW0RVQt6b
			LjRoTMDiSwQlCmzO1.close()
		else:
			ffWgMXo20Hb5xurkdNqa = XXu7raekSlFyL8sn6RoIDGBiYd92.getLabel()
			if ffWgMXo20Hb5xurkdNqa.isnumeric():
				index = int(ffWgMXo20Hb5xurkdNqa) - BkM54Kr7Qbqn
				LjRoTMDiSwQlCmzO1.chkstate[index] = not LjRoTMDiSwQlCmzO1.chkstate[index]
				LjRoTMDiSwQlCmzO1.chk[index].setVisible(LjRoTMDiSwQlCmzO1.chkstate[index])
	def onAction(LjRoTMDiSwQlCmzO1, WWb2t4zoZspJfK):
		if WWb2t4zoZspJfK == OO9YiAQHGrLo0qpW2M3jDeXd1kx(u"࠶࠶ඎ"):
			LjRoTMDiSwQlCmzO1.cancelled = EsCplGc5N4mBuYW0RVQt6b
			LjRoTMDiSwQlCmzO1.close()
def SalObZDeYVKXNnMH2CPdIkRB8Gc(key,PwOhx7WTAQGq8o2n,url):
	headers = {wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ೼"):url,Gcw2nelTR864XCVruO3mAFqI5a(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡍࡣࡱ࡫ࡺࡧࡧࡦࠩ೽"):PwOhx7WTAQGq8o2n}
	SOH9oKVkXstbIT = I18uSKaWhgTBeYUPD4sr(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳࡭࡯ࡰࡩ࡯ࡩ࠳ࡩ࡯࡮࠱ࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠴ࡧࡰࡪ࠱ࡩࡥࡱࡲࡢࡢࡥ࡮ࡃࡰࡃࠧ೾")+key
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,wdftVMyzF17cYETHu(u"ࠩࡊࡉ࡙࠭೿"),SOH9oKVkXstbIT,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,vU6DxuzPwMpg(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡇࡆࡖࡢࡖࡊࡉࡁࡑࡖࡆࡌࡆ࠸࡟ࡕࡑࡎࡉࡓ࠳࠱ࡴࡶࠪഀ"))
	eDi4j5Usrp,iteration = fy8iFgEkrO12NR9TWBI35sjY6qHvV,D2D96X5NGamBhrFwvL8VEbqiSfZIl
	while EsCplGc5N4mBuYW0RVQt6b:
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		B7gtJnK24RY = EcQxOa3RJm86WjTKA.findall(o1INZ3ViQqS0Uw5z6kMjbv(u"ࠫࠧ࠮࠯ࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠲ࡥࡵ࡯࠲࠰ࡲࡤࡽࡱࡵࡡࡥ࡝ࡡࠦࡢ࠱ࠩࠨഁ"), FGRX4myP68S)
		iteration += BkM54Kr7Qbqn
		message = EcQxOa3RJm86WjTKA.findall(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠬࡂ࡬ࡢࡤࡨࡰࡠࡤ࠾࡞࠭ࡦࡰࡦࡹࡳ࠾ࠤࡩࡦࡨ࠳ࡩ࡮ࡣࡪࡩࡸ࡫࡬ࡦࡥࡷ࠱ࡲ࡫ࡳࡴࡣࡪࡩ࠲ࡺࡥࡹࡶࠥ࡟ࡣࡄ࡝ࠫࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯ࡥࡧ࡫࡬࠿ࠩം"), FGRX4myP68S)
		if not message: message = EcQxOa3RJm86WjTKA.findall(aOQTKXFL54Nl60Zhp3MbE(u"࠭࠼ࡥ࡫ࡹ࡟ࡣࡄ࡝ࠬࡥ࡯ࡥࡸࡹ࠽ࠣࡨࡥࡧ࠲࡯࡭ࡢࡩࡨࡷࡪࡲࡥࡤࡶ࠰ࡱࡪࡹࡳࡢࡩࡨ࠱ࡪࡸࡲࡰࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩഃ"), FGRX4myP68S)
		if not message:
			eDi4j5Usrp = EcQxOa3RJm86WjTKA.findall(vU6DxuzPwMpg(u"ࠧࡳࡧࡤࡨࡴࡴ࡬ࡺࡀࠫ࠲࠯ࡅࠩ࠽ࠩഄ"), FGRX4myP68S)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			break
		else:
			message = message[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			B7gtJnK24RY = B7gtJnK24RY[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		XDz9Vhx1sUF8y6OR0q4kf = EcQxOa3RJm86WjTKA.findall(AAbvaXV2DQzfNHdm4U3tT(u"ࡳࠩࡱࡥࡲ࡫࠽ࠣࡥࠥࡠࡸ࠱ࡶࡢ࡮ࡸࡩࡂࠨࠨ࡜ࡠࠥࡡ࠰࠯ࠧഅ"), FGRX4myP68S)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		G4ul6hk0peVgsbozBCW = EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡨࡱࡲ࡫ࡱ࡫࠮ࡤࡱࡰࠩࡸ࠭ആ") % (B7gtJnK24RY.replace(N6NGJ4vpmidqMCh7yo(u"ࠪࠪࡦࡳࡰ࠼ࠩഇ"), KfHAW8VGbrxi(u"ࠫࠫ࠭ഈ")))
		message = EcQxOa3RJm86WjTKA.sub(SnhLjmfeJC(u"ࠬࡂ࠯ࡀࠪࡧ࡭ࡻࢂࡳࡵࡴࡲࡲ࡬࠯࡛࡟ࡀࡠ࠮ࡃ࠭ഉ"), fy8iFgEkrO12NR9TWBI35sjY6qHvV, message)
		a1FHTu0OSJoMd = PIAJK76UbRCqEOyl(captcha=G4ul6hk0peVgsbozBCW, msg=message, iteration=iteration)
		P4b9hHt3uJFaAIfXq6U2vd = a1FHTu0OSJoMd.get()
		if not P4b9hHt3uJFaAIfXq6U2vd: break
		data = {o1INZ3ViQqS0Uw5z6kMjbv(u"࠭ࡣࠨഊ"): XDz9Vhx1sUF8y6OR0q4kf, KfHAW8VGbrxi(u"ࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩഋ"): P4b9hHt3uJFaAIfXq6U2vd}
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,CsDcLqQUVK4YBvHFW1(u"ࠨࡒࡒࡗ࡙࠭ഌ"),SOH9oKVkXstbIT,data,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,KfHAW8VGbrxi(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡍࡅࡕࡡࡕࡉࡈࡇࡐࡕࡅࡋࡅ࠷ࡥࡔࡐࡍࡈࡒ࠲࠸࡮ࡥࠩ഍"))
	return eDi4j5Usrp
def aiQ1JbzWCNgSBsu76TyM28(url):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(d9vcuo3Hy7RhAk2,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡃࡅࡐࡔࡇࡄࡔ࠯࠴ࡷࡹ࠭എ"))
	items = EcQxOa3RJm86WjTKA.findall(CsDcLqQUVK4YBvHFW1(u"ࠫࡨࡵ࡬ࡰࡴࡀࠦࡷ࡫ࡤࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩഏ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if items: return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[ items[D2D96X5NGamBhrFwvL8VEbqiSfZIl] ]
	else: return oRJAfwD957WkUyBM1Ehu8m(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡄࡆࡑࡕࡁࡅࡕࠪഐ"),[],[]
def jVKdv4xQJBGts3lh9bZpqnIy(url):
	return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[url]
def ocPK3HMS2dOlj0AJx8aeRDnWp(url):
	A8ECQ0qwTRzPifOGW76FK35uUvhe = url.split(aOQTKXFL54Nl60Zhp3MbE(u"࠭࠯ࠨ഑"))
	PPLwIrQial = CsDcLqQUVK4YBvHFW1(u"ࠧ࠰ࠩഒ").join(A8ECQ0qwTRzPifOGW76FK35uUvhe[D2D96X5NGamBhrFwvL8VEbqiSfZIl:XW57OCeGnFTLQbaqdrD9zM])
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(d9vcuo3Hy7RhAk2,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,O3OVuapf0YFjbm5oUQDg(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡟ࡏࡐࡑ࡛ࡖࡌࡆࡘࡅ࠮࠳ࡶࡸࠬഓ"))
	items = EcQxOa3RJm86WjTKA.findall(I18uSKaWhgTBeYUPD4sr(u"ࠩࡧࡰࡧࡻࡴࡵࡱࡱࡠࠬࡢࠩ࠯ࡪࡵࡩ࡫ࠦ࠽ࠡࠤࠫ࠲࠯ࡅࠩࠣࠢ࡟࠯ࠥࡢࠨࠩ࠰࠭ࡃ࠮ࠦ࡜ࠦࠢࠫ࠲࠯ࡅࠩࠡ࡞࠮ࠤ࠭࠴ࠪࡀࠫࠣࡠࠪࠦࠨ࠯ࠬࡂ࠭ࡡ࠯ࠠ࡝࠭ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫഔ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if items:
		co5Qjlkev7zdPm,UwDjzXMGId87,afZQbHNSmXD7zJRvcBWUdL4,nVDIb6APXN2T4YpukmqlGZ70,C5Czoal3yb1GhfFAR8OWitugPdTQ,b1TR2K7JhQ94 = items[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		XJRx6urSNaOM5AfZdDsgQBYGt = int(UwDjzXMGId87) % int(afZQbHNSmXD7zJRvcBWUdL4) + int(nVDIb6APXN2T4YpukmqlGZ70) % int(C5Czoal3yb1GhfFAR8OWitugPdTQ)
		url = PPLwIrQial + co5Qjlkev7zdPm + str(XJRx6urSNaOM5AfZdDsgQBYGt) + b1TR2K7JhQ94
		return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[url]
	else: return wdftVMyzF17cYETHu(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡠࡉࡑࡒ࡜ࡗࡍࡇࡒࡆࠩക"),[],[]
def m76kAQnvE1o(url):
	id = url.split(N6NGJ4vpmidqMCh7yo(u"ࠫ࠴࠭ഖ"))[-BkM54Kr7Qbqn]
	headers = { KfHAW8VGbrxi(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫഗ") : PlpyFa9QMKXxOD1cvHzmI(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬഘ") }
	B7gtJnK24RY = { o1INZ3ViQqS0Uw5z6kMjbv(u"ࠢࡪࡦࠥങ"):id , KfHAW8VGbrxi(u"ࠣࡱࡳࠦച"):ssynAg0zhSkoCpOMDV9(u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧ࠶ࠧഛ") }
	Bc7G3ur2Tw5QK1fPSkyJ = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,s5WMHyQN4mpie(u"ࠪࡔࡔ࡙ࡔࠨജ"), url, B7gtJnK24RY, headers, fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡒ࠷࡙ࡕࡒࡏࡂࡆ࠰࠵ࡸࡺࠧഝ"))
	if aOQTKXFL54Nl60Zhp3MbE(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧഞ") in list(Bc7G3ur2Tw5QK1fPSkyJ.headers.keys()): bigdh7fpZYl4aT2keV = Bc7G3ur2Tw5QK1fPSkyJ.headers[C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨട")]
	else: bigdh7fpZYl4aT2keV = url
	if bigdh7fpZYl4aT2keV: return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[bigdh7fpZYl4aT2keV]
	else: return C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡔ࠹࡛ࡐࡍࡑࡄࡈࠬഠ"),[],[]
def PPrunGxyD2z3QfFt4(url):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(d9vcuo3Hy7RhAk2,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,PlpyFa9QMKXxOD1cvHzmI(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡏࡎࡕࡘࡏࡍ࡛ࡋ࠭࠲ࡵࡷࠫഡ"))
	items = EcQxOa3RJm86WjTKA.findall(sIzDXlTHYUC5L3xZGnr(u"ࠩࡰࡴ࠹ࡀࠠ࡝࡝࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࠬഢ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if items: return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[ items[D2D96X5NGamBhrFwvL8VEbqiSfZIl] ]
	else: return oRJAfwD957WkUyBM1Ehu8m(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡝ࡉࡏࡖ࡙ࡐࡎ࡜ࡅࠨണ"),[],[]
def CVM0diN2e48Xb(url):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(d9vcuo3Hy7RhAk2,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,PlpyFa9QMKXxOD1cvHzmI(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡆࡌࡎ࡜ࡅ࠮࠳ࡶࡸࠬത"))
	items = EcQxOa3RJm86WjTKA.findall(CsDcLqQUVK4YBvHFW1(u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪഥ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if items:
		url = url = uulNDCPyef78(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡦ࡬࡮ࡼࡥ࠯ࡱࡵ࡫ࠬദ") + items[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[ url ]
	else: return EE1jeHnIoad(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡈࡎࡉࡗࡇࠪധ"),[],[]
def RKzWbugVM0BAyDp1ht7lIQE(url):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(d9vcuo3Hy7RhAk2,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,ggjO5CrKVRPITaesWkxD(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊ࡙ࡔࡓࡇࡄࡑ࠲࠷ࡳࡵࠩന"))
	items = EcQxOa3RJm86WjTKA.findall(s5WMHyQN4mpie(u"ࠩࡹ࡭ࡩ࡫࡯ࠡࡲࡵࡩࡱࡵࡡࡥ࠰࠭ࡃࡸࡸࡣ࠾࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩഩ"),FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if items: return fy8iFgEkrO12NR9TWBI35sjY6qHvV,[fy8iFgEkrO12NR9TWBI35sjY6qHvV],[ items[D2D96X5NGamBhrFwvL8VEbqiSfZIl] ]
	else: return QjAINyUC7MDRq5d8e4vl9(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡋࡓࡕࡔࡈࡅࡒ࠭പ"),[],[]
# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'EGYBEST1'
K2l9rLfvoXxyZ4NYapO = '_EB1_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['مكتبتي','ايجي بست']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,jmI9qRnVJo2a3tpcH8gfYkP,text):
	if   mode==770: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==771: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,jmI9qRnVJo2a3tpcH8gfYkP)
	elif mode==772: OmsWt89dSA5HyCZ4wL = vloIZHenE7imycDM2tPQ(url)
	elif mode==773: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==774: OmsWt89dSA5HyCZ4wL = F4ehkvPDxXU(url,'FULL_FILTER___'+text)
	elif mode==775: OmsWt89dSA5HyCZ4wL = F4ehkvPDxXU(url,'DEFINED_FILTER___'+text)
	elif mode==776: OmsWt89dSA5HyCZ4wL = VNPHFcK5wvfL67Roir0Y(url,jmI9qRnVJo2a3tpcH8gfYkP)
	elif mode==779: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text,url)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,779,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBEST1-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('nav-list(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?<span>(.*?)</span>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			if any(value in title for value in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o): continue
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,771)
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('main-article(.*?)social-box',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('main-title.*?">(.*?)<.*?href="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for title,bigdh7fpZYl4aT2keV in items:
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,771,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'mainmenu')
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('main-menu(.*?)</div></div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,771)
	return FGRX4myP68S
def VNPHFcK5wvfL67Roir0Y(url,type=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBEST1-SEASONS_EPISODES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('main-article".*?">(.*?)<(.*?)article',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		CSX1FDkQOU,jbpHA8eDFYwlT,items = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,[]
		for name,wlJ6d8hEvpoMNSCmU in z6PX2p7diaskQElBOvMRNcHwqG5D:
			if 'حلقات' in name: jbpHA8eDFYwlT = wlJ6d8hEvpoMNSCmU
			if 'مواسم' in name: CSX1FDkQOU = wlJ6d8hEvpoMNSCmU
		if CSX1FDkQOU and not type:
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',CSX1FDkQOU,EcQxOa3RJm86WjTKA.DOTALL)
			if len(items)>1:
				for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
					OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,776,POjaBmHqzpsx1IYw7kQM4R,'season')
		if jbpHA8eDFYwlT and len(items)<2:
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?data-src="(.*?)".*?title="(.*?)"',jbpHA8eDFYwlT,EcQxOa3RJm86WjTKA.DOTALL)
			if items:
				for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
					OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,773,POjaBmHqzpsx1IYw7kQM4R)
			else:
				items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)<',jbpHA8eDFYwlT,EcQxOa3RJm86WjTKA.DOTALL)
				for bigdh7fpZYl4aT2keV,title in items:
					OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,773)
	return
def HAsKeZdTbqjPI1WY(url,type=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBEST1-TITLES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	items,FFvZ6iAMxpBE,p9UP6wGlC1BF7fN2 = [],False,False
	if not type:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('main-content(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?</i>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title in items:
				title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,771,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'submenu')
				FFvZ6iAMxpBE = True
	if not type and 'p=' not in url:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('searchform(.*?)</form>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			if FFvZ6iAMxpBE: OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فلتر محدد',url,775,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filter')
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فلتر كامل',url,774,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filter')
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث',url,779)
			OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
			p9UP6wGlC1BF7fN2 = True
	if not FFvZ6iAMxpBE:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('blocks(.*?)article',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
				POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R.strip(C0qrknitpM4Z)
				bigdh7fpZYl4aT2keV = U2Z7CVFftTmLeK3nzEbQPGga(bigdh7fpZYl4aT2keV)
				if '/serie/' in bigdh7fpZYl4aT2keV: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,776,POjaBmHqzpsx1IYw7kQM4R,'season')
				else: OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,773,POjaBmHqzpsx1IYw7kQM4R)
			jmI9qRnVJo2a3tpcH8gfYkP = '1'
			if 'p=' in url: url,jmI9qRnVJo2a3tpcH8gfYkP = url.split('p=',1)
			vvPmnHekOc7qrjidMwxf134VD = '&' if '?' in url else '?'
			url = url+vvPmnHekOc7qrjidMwxf134VD
			url = url.replace('?&','?')
			if len(items)==40:
				url = url+'p='+str(int(jmI9qRnVJo2a3tpcH8gfYkP)+1)
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الصفحة التالية',url,771)
			elif jmI9qRnVJo2a3tpcH8gfYkP!='1':
				url = url+'p='+str(int(jmI9qRnVJo2a3tpcH8gfYkP)-1)
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الصفحة السابقة',url,771)
	return
def rr7SfotkneX85Klup(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBEST1-PLAY-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	uuigJsvIZQ3tprnhxG = EcQxOa3RJm86WjTKA.findall('<label>التصنيف</label>.*?">(.*?)<',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if uuigJsvIZQ3tprnhxG and SYJvigbI3fts(BfWYUAnyg6eONLjiuE,url,uuigJsvIZQ3tprnhxG): return
	paJKP0Usbeju4liH,hFzEyHWOoRxG,jQkdt6rvnxW8 = [],[],[]
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall('download-section.*?action="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if bigdh7fpZYl4aT2keV:
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[0]
		if bigdh7fpZYl4aT2keV not in jQkdt6rvnxW8:
			jQkdt6rvnxW8.append(bigdh7fpZYl4aT2keV)
			hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV+'?named=__embed______'+DVX5GWhnIxYlSd9rEuetjk40UJ(url))
	VuGmoESTAfXlv5tD76PW1Masq0peB = EcQxOa3RJm86WjTKA.findall('WatchServers(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	for wlJ6d8hEvpoMNSCmU in VuGmoESTAfXlv5tD76PW1Masq0peB:
		zzECVswWcGAIXhrQlZ7jMokugnv = EcQxOa3RJm86WjTKA.findall("url='(.*?)'.*?>(.*?)<",wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,A8ECQ0qwTRzPifOGW76FK35uUvhe in zzECVswWcGAIXhrQlZ7jMokugnv:
			if bigdh7fpZYl4aT2keV not in jQkdt6rvnxW8:
				jQkdt6rvnxW8.append(bigdh7fpZYl4aT2keV)
				hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV+'?named='+A8ECQ0qwTRzPifOGW76FK35uUvhe+'__both______'+DVX5GWhnIxYlSd9rEuetjk40UJ(url))
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(hFzEyHWOoRxG,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search,url=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if not search: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if not search: return
	CE6HW2phYix9XvVdfqe1ObQIFl5mMj = search.replace(ksJdoFWhxTz8Y2N7bOZE,'%20')
	if not url: url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/search?query='+CE6HW2phYix9XvVdfqe1ObQIFl5mMj
	else: url = url+'?title='+CE6HW2phYix9XvVdfqe1ObQIFl5mMj+'&genre=&year=&lang='
	HAsKeZdTbqjPI1WY(url,'search')
	return
def dfqB809Vbp6nyMRcmHvwZ(url):
	url = url.split('/smartemadfilter?')[0]
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBEST1-GET_FILTERS_BLOCKS-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	W1A4L5P0Zc8wHnUGjVexElz = []
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('form-row(.*?)</form>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		W1A4L5P0Zc8wHnUGjVexElz = EcQxOa3RJm86WjTKA.findall('select name="(.*?)".*?value>(.*?)<(.*?)</select',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		i6m2Skc3nesTYu7QjPJWbxlay,ny5fseD6KMzR8m3vSE,VuGmoESTAfXlv5tD76PW1Masq0peB = zip(*W1A4L5P0Zc8wHnUGjVexElz)
		W1A4L5P0Zc8wHnUGjVexElz = zip(ny5fseD6KMzR8m3vSE,i6m2Skc3nesTYu7QjPJWbxlay,VuGmoESTAfXlv5tD76PW1Masq0peB)
	return W1A4L5P0Zc8wHnUGjVexElz
def XkO6QiU8yILWlfg(wlJ6d8hEvpoMNSCmU):
	items = EcQxOa3RJm86WjTKA.findall('value="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	return items
def rCk5v93oAu1dgc8tzlOB4(url):
	url = url.replace('/smartemadfilter?','?title=&')
	return url
gFxHyVTwqu3CBirYP8 = ['year','lang','genre']
ddWq05NVRP = ['year','lang','genre']
def F4ehkvPDxXU(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==fy8iFgEkrO12NR9TWBI35sjY6qHvV: NnQ1hEsTV7Zaz3HKdfu,QlOXcH07nRVPAZub8pD356xMvdk4 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	else: NnQ1hEsTV7Zaz3HKdfu,QlOXcH07nRVPAZub8pD356xMvdk4 = filter.split('___')
	if type=='DEFINED_FILTER':
		if ddWq05NVRP[0]+'=' not in NnQ1hEsTV7Zaz3HKdfu: fnogyzNA30JCPMYqHTavG7ZKp = ddWq05NVRP[0]
		for pk6YWixXFSrDLKCnlN39w in range(len(ddWq05NVRP[0:-1])):
			if ddWq05NVRP[pk6YWixXFSrDLKCnlN39w]+'=' in NnQ1hEsTV7Zaz3HKdfu: fnogyzNA30JCPMYqHTavG7ZKp = ddWq05NVRP[pk6YWixXFSrDLKCnlN39w+1]
		z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&'+fnogyzNA30JCPMYqHTavG7ZKp+'=0'
		ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&'+fnogyzNA30JCPMYqHTavG7ZKp+'=0'
		HfvJenZmN3O8rPcshLux2EyzDWpQCb = z7VI1OaUPqs4lXxb.strip('&')+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq.strip('&')
		F231lsuCKnaSMdQ48W6PoL = nKT1QuLoXPc8CjyV(QlOXcH07nRVPAZub8pD356xMvdk4,'all')
		YLKFRH6sSIrznXBg = url+'/smartemadfilter?'+F231lsuCKnaSMdQ48W6PoL
	elif type=='FULL_FILTER':
		QUFL2gEBMn63qlsmI7W = nKT1QuLoXPc8CjyV(NnQ1hEsTV7Zaz3HKdfu,'modified_values')
		QUFL2gEBMn63qlsmI7W = U2Z7CVFftTmLeK3nzEbQPGga(QUFL2gEBMn63qlsmI7W)
		if QlOXcH07nRVPAZub8pD356xMvdk4: QlOXcH07nRVPAZub8pD356xMvdk4 = nKT1QuLoXPc8CjyV(QlOXcH07nRVPAZub8pD356xMvdk4,'all')
		if not QlOXcH07nRVPAZub8pD356xMvdk4: YLKFRH6sSIrznXBg = url
		else: YLKFRH6sSIrznXBg = url+'/smartemadfilter?'+QlOXcH07nRVPAZub8pD356xMvdk4
		MYWwFs7XA2 = rCk5v93oAu1dgc8tzlOB4(YLKFRH6sSIrznXBg)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'أظهار قائمة الفيديو التي تم اختيارها ',MYWwFs7XA2,771,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filter')
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+' [[   '+QUFL2gEBMn63qlsmI7W+'   ]]',MYWwFs7XA2,771,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filter')
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	W1A4L5P0Zc8wHnUGjVexElz = dfqB809Vbp6nyMRcmHvwZ(url)
	dict = {}
	for name,jLA9nhxoZbG,wlJ6d8hEvpoMNSCmU in W1A4L5P0Zc8wHnUGjVexElz:
		name = name.replace('كل ',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		items = XkO6QiU8yILWlfg(wlJ6d8hEvpoMNSCmU)
		if '=' not in YLKFRH6sSIrznXBg: YLKFRH6sSIrznXBg = url
		if type=='DEFINED_FILTER':
			if fnogyzNA30JCPMYqHTavG7ZKp!=jLA9nhxoZbG: continue
			elif len(items)<2:
				if jLA9nhxoZbG==ddWq05NVRP[-1]:
					MYWwFs7XA2 = rCk5v93oAu1dgc8tzlOB4(YLKFRH6sSIrznXBg)
					HAsKeZdTbqjPI1WY(MYWwFs7XA2)
				else: F4ehkvPDxXU(YLKFRH6sSIrznXBg,'DEFINED_FILTER___'+HfvJenZmN3O8rPcshLux2EyzDWpQCb)
				return
			else:
				if jLA9nhxoZbG==ddWq05NVRP[-1]:
					MYWwFs7XA2 = rCk5v93oAu1dgc8tzlOB4(YLKFRH6sSIrznXBg)
					OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع ',MYWwFs7XA2,771,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filter')
				else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع ',YLKFRH6sSIrznXBg,775,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,HfvJenZmN3O8rPcshLux2EyzDWpQCb)
		elif type=='FULL_FILTER':
			z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&'+jLA9nhxoZbG+'=0'
			ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&'+jLA9nhxoZbG+'=0'
			HfvJenZmN3O8rPcshLux2EyzDWpQCb = z7VI1OaUPqs4lXxb+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع :'+name,YLKFRH6sSIrznXBg,774,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,HfvJenZmN3O8rPcshLux2EyzDWpQCb)
		dict[jLA9nhxoZbG] = {}
		for value,srR9AuG6Pf8powqU4ixL5Ecl in items:
			if not value: continue
			if srR9AuG6Pf8powqU4ixL5Ecl in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
			dict[jLA9nhxoZbG][value] = srR9AuG6Pf8powqU4ixL5Ecl
			z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&'+jLA9nhxoZbG+'='+srR9AuG6Pf8powqU4ixL5Ecl
			ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&'+jLA9nhxoZbG+'='+value
			QdzUcX2iR5 = z7VI1OaUPqs4lXxb+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq
			title = srR9AuG6Pf8powqU4ixL5Ecl+' :'#+dict[jLA9nhxoZbG]['0']
			title = srR9AuG6Pf8powqU4ixL5Ecl+' :'+name
			if type=='FULL_FILTER': OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,774,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QdzUcX2iR5)
			elif type=='DEFINED_FILTER' and ddWq05NVRP[-2]+'=' in NnQ1hEsTV7Zaz3HKdfu:
				F231lsuCKnaSMdQ48W6PoL = nKT1QuLoXPc8CjyV(ybEUMsLp4zBVPnuAYI0cCdowekDq,'modified_filters')
				YLKFRH6sSIrznXBg = url+'/smartemadfilter?'+F231lsuCKnaSMdQ48W6PoL
				MYWwFs7XA2 = rCk5v93oAu1dgc8tzlOB4(YLKFRH6sSIrznXBg)
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,MYWwFs7XA2,771,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filter')
			elif type=='DEFINED_FILTER': OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,775,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QdzUcX2iR5)
	return
def nKT1QuLoXPc8CjyV(p9UP6wGlC1BF7fN2,mode):
	p9UP6wGlC1BF7fN2 = p9UP6wGlC1BF7fN2.replace('=&','=0&')
	p9UP6wGlC1BF7fN2 = p9UP6wGlC1BF7fN2.strip('&')
	vpLWbVm35iM0l2TzYIN7 = {}
	if '=' in p9UP6wGlC1BF7fN2:
		items = p9UP6wGlC1BF7fN2.split('&')
		for j25T6eKhaMk3 in items:
			XJRx6urSNaOM5AfZdDsgQBYGt,value = j25T6eKhaMk3.split('=')
			vpLWbVm35iM0l2TzYIN7[XJRx6urSNaOM5AfZdDsgQBYGt] = value
	MKJaIb2sDSr4VCQGTqyX3nkWL = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	for key in gFxHyVTwqu3CBirYP8:
		if key in list(vpLWbVm35iM0l2TzYIN7.keys()): value = vpLWbVm35iM0l2TzYIN7[key]
		else: value = '0'
		if '%' not in value: value = DVX5GWhnIxYlSd9rEuetjk40UJ(value)
		if mode=='modified_values' and value!='0': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+' + '+value
		elif mode=='modified_filters' and value!='0': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+'&'+key+'='+value
		elif mode=='all': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+'&'+key+'='+value
	MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL.strip(' + ')
	MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL.strip('&')
	MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL.replace('=0','=')
	return MKJaIb2sDSr4VCQGTqyX3nkWL
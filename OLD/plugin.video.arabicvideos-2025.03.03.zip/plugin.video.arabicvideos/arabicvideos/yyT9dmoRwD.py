# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
headers = { 'User-Agent' : fy8iFgEkrO12NR9TWBI35sjY6qHvV }
BfWYUAnyg6eONLjiuE = 'AKOAMCAM'
K2l9rLfvoXxyZ4NYapO = '_AKC_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['مصارعة']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==350: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==351: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,text)
	elif mode==352: OmsWt89dSA5HyCZ4wL = eQgbVPaIBvTn8fsjJRt241(url)
	elif mode==353: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==354: OmsWt89dSA5HyCZ4wL = F4ehkvPDxXU(url,'FILTERS___'+text)
	elif mode==355: OmsWt89dSA5HyCZ4wL = F4ehkvPDxXU(url,'CATEGORIES___'+text)
	elif mode==356: OmsWt89dSA5HyCZ4wL = VxL5HJnq2MC7KW6NUEQe80BPD1T(url)
	elif mode==357: OmsWt89dSA5HyCZ4wL = NS2PVUnHopQqhfl5x(url)
	elif mode==359: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH('link',K2l9rLfvoXxyZ4NYapO+WydpaVx5YmLoCiIgA34eEBlb+'هذا الموقع مغلق'+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,8)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,359,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فلتر محدد',BOI3t1w8qfHAb0Kl4oMye7haEWS,356)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فلتر كامل',BOI3t1w8qfHAb0Kl4oMye7haEWS,357)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'AKOAMCAM-MENU-1st')
	YLKFRH6sSIrznXBg = EcQxOa3RJm86WjTKA.findall('recently-container.*?href="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if YLKFRH6sSIrznXBg: YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg[0]
	else: YLKFRH6sSIrznXBg = BOI3t1w8qfHAb0Kl4oMye7haEWS
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'اضيف حديثا',YLKFRH6sSIrznXBg,351)
	YLKFRH6sSIrznXBg = EcQxOa3RJm86WjTKA.findall('@id":"(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if YLKFRH6sSIrznXBg: YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg[0]
	else: YLKFRH6sSIrznXBg = BOI3t1w8qfHAb0Kl4oMye7haEWS
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'المميزة',YLKFRH6sSIrznXBg,351,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'featured')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('main-categories-list(.*?)main-categories-list',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?class="font.*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if title not in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,351)
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="categories-box(.*?)<footer',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			bigdh7fpZYl4aT2keV = IVcCL3aAfU9wS7kWev1g2XBjZRJ(bigdh7fpZYl4aT2keV)
			if title not in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,351)
	return FGRX4myP68S
def VxL5HJnq2MC7KW6NUEQe80BPD1T(website=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'AKOAMCAM-MENU-1st')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="menu(.*?)<nav',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?text">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if title not in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o:
				title = title+' مصنفة'
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,355)
		if website==fy8iFgEkrO12NR9TWBI35sjY6qHvV: OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	return FGRX4myP68S
def NS2PVUnHopQqhfl5x(website=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'AKOAMCAM-MENU-1st')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="menu(.*?)<nav',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?text">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if title not in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o:
				title = title+' مفلترة'
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,354)
		if website==fy8iFgEkrO12NR9TWBI35sjY6qHvV: OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	return FGRX4myP68S
def HAsKeZdTbqjPI1WY(url,type=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(oWMrx7zvedHY0UiS48XbOqVTJ,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,True,'AKOAMCAM-TITLES-1st')
	if type=='featured': z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('swiper-container(.*?)swiper-button-prev',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	else: z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="container"(.*?)main-footer',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('xlink:href="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		cmDaLEqWlT7GhonIdX5k1zHQjSiupe = []
		for POjaBmHqzpsx1IYw7kQM4R,bigdh7fpZYl4aT2keV,title in items:
			title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
			if 'الحلقة' in title or 'الحلقه' in title:
				RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) (الحلقة|الحلقه) \d+',title,EcQxOa3RJm86WjTKA.DOTALL)
				if RrzpbE3t9woCk7MXS0GvNdi1BcV:
					title = '_MOD_' + RrzpbE3t9woCk7MXS0GvNdi1BcV[0][0]
					if title not in cmDaLEqWlT7GhonIdX5k1zHQjSiupe:
						OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,352,POjaBmHqzpsx1IYw7kQM4R)
						cmDaLEqWlT7GhonIdX5k1zHQjSiupe.append(title)
			elif 'مسلسل' in title:
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,352,POjaBmHqzpsx1IYw7kQM4R)
			else: OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,353,POjaBmHqzpsx1IYw7kQM4R)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('pagination(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href=["\'](.*?)["\'].*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			bigdh7fpZYl4aT2keV = IVcCL3aAfU9wS7kWev1g2XBjZRJ(bigdh7fpZYl4aT2keV)
			title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,351)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	CE6HW2phYix9XvVdfqe1ObQIFl5mMj = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS + '/?s='+CE6HW2phYix9XvVdfqe1ObQIFl5mMj
	OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url)
	return
def eQgbVPaIBvTn8fsjJRt241(url):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,True,'AKOAMCAM-EPISODES-1st')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('text-white">الحلقات(.*?)<header',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		jbpHA8eDFYwlT = EcQxOa3RJm86WjTKA.findall('href="(http.*?)".*?src="(.*?)".*?alt="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in jbpHA8eDFYwlT:
			if 'الحلقة' in title or 'الحلقه' in title: OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,353,POjaBmHqzpsx1IYw7kQM4R)
	else:
		POjaBmHqzpsx1IYw7kQM4R = bEWpDHXjCBqd7aOiN6UG5k.getInfoLabel('ListItem.Icon')
		if FGRX4myP68S.count('<title>')>1: title = EcQxOa3RJm86WjTKA.findall('<title>(.*?)<',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)[1]
		else: title = 'رابط التشغيل'
		OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,url,353,POjaBmHqzpsx1IYw7kQM4R)
	return
def rr7SfotkneX85Klup(url):
	XoSyx7p6dqZ1CF8,WFlpmsYGKNy = [],[]
	mDo9drBQj2 = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'AKOAMCAM-PLAY-1st')
	FGRX4myP68S = mDo9drBQj2.content
	pl3chZdq7I = EcQxOa3RJm86WjTKA.findall('post_id=(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if pl3chZdq7I:
		pl3chZdq7I = pl3chZdq7I[0]
		headers = {'User-Agent':fy8iFgEkrO12NR9TWBI35sjY6qHvV,'Content-Type':'application/x-www-form-urlencoded'}
		data = {'post_id':pl3chZdq7I}
		YLKFRH6sSIrznXBg = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Watch.php'
		PPBvpKVijRkJSrnATcdsbQGtlOm2a = TBPcjsyOYoM82pm(rrux12tcwQl5,'POST',YLKFRH6sSIrznXBg,data,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'AKOAMCAM-PLAY-1st')
		soEymUvkt19PQXVjzKau6x5 = PPBvpKVijRkJSrnATcdsbQGtlOm2a.content
		items = EcQxOa3RJm86WjTKA.findall('data-server="(.*?)".*?class="text">(.*?)<',soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
		for cTUQ5iedtAwZgpqhHI3NsoLWaP,name in items:
			bigdh7fpZYl4aT2keV = 'https://w.akoam.cam/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Server.php'
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?postid='+pl3chZdq7I+'&serverid='+cTUQ5iedtAwZgpqhHI3NsoLWaP+'?named='+name+'__watch'
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
			WFlpmsYGKNy.append(name)
		YLKFRH6sSIrznXBg = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Download.php'
		PPBvpKVijRkJSrnATcdsbQGtlOm2a = TBPcjsyOYoM82pm(rrux12tcwQl5,'POST',YLKFRH6sSIrznXBg,data,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'AKOAMCAM-PLAY-1st')
		soEymUvkt19PQXVjzKau6x5 = PPBvpKVijRkJSrnATcdsbQGtlOm2a.content
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?class="text">(.*?)<',soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.strip(ksJdoFWhxTz8Y2N7bOZE)
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+title+'__download'
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
			WFlpmsYGKNy.append(title)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(XoSyx7p6dqZ1CF8,BfWYUAnyg6eONLjiuE,'video',url)
	return
def F4ehkvPDxXU(url,filter):
	ffJIco45MG9kFntgWDwqyR = ['cat','genre','release-year','quality','orderby']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==fy8iFgEkrO12NR9TWBI35sjY6qHvV: NnQ1hEsTV7Zaz3HKdfu,QlOXcH07nRVPAZub8pD356xMvdk4 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	else: NnQ1hEsTV7Zaz3HKdfu,QlOXcH07nRVPAZub8pD356xMvdk4 = filter.split('___')
	if type=='CATEGORIES':
		if ffJIco45MG9kFntgWDwqyR[0]+'=' not in NnQ1hEsTV7Zaz3HKdfu: fnogyzNA30JCPMYqHTavG7ZKp = ffJIco45MG9kFntgWDwqyR[0]
		for pk6YWixXFSrDLKCnlN39w in range(len(ffJIco45MG9kFntgWDwqyR[0:-1])):
			if ffJIco45MG9kFntgWDwqyR[pk6YWixXFSrDLKCnlN39w]+'=' in NnQ1hEsTV7Zaz3HKdfu: fnogyzNA30JCPMYqHTavG7ZKp = ffJIco45MG9kFntgWDwqyR[pk6YWixXFSrDLKCnlN39w+1]
		z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&'+fnogyzNA30JCPMYqHTavG7ZKp+'=0'
		ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&'+fnogyzNA30JCPMYqHTavG7ZKp+'=0'
		HfvJenZmN3O8rPcshLux2EyzDWpQCb = z7VI1OaUPqs4lXxb.strip('&')+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq.strip('&')
		F231lsuCKnaSMdQ48W6PoL = nKT1QuLoXPc8CjyV(QlOXcH07nRVPAZub8pD356xMvdk4,'all')
		YLKFRH6sSIrznXBg = url+'?'+F231lsuCKnaSMdQ48W6PoL
	elif type=='FILTERS':
		QUFL2gEBMn63qlsmI7W = nKT1QuLoXPc8CjyV(NnQ1hEsTV7Zaz3HKdfu,'modified_values')
		QUFL2gEBMn63qlsmI7W = U2Z7CVFftTmLeK3nzEbQPGga(QUFL2gEBMn63qlsmI7W)
		if QlOXcH07nRVPAZub8pD356xMvdk4!=fy8iFgEkrO12NR9TWBI35sjY6qHvV: QlOXcH07nRVPAZub8pD356xMvdk4 = nKT1QuLoXPc8CjyV(QlOXcH07nRVPAZub8pD356xMvdk4,'all')
		if QlOXcH07nRVPAZub8pD356xMvdk4==fy8iFgEkrO12NR9TWBI35sjY6qHvV: YLKFRH6sSIrznXBg = url
		else: YLKFRH6sSIrznXBg = url+'?'+QlOXcH07nRVPAZub8pD356xMvdk4
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'أظهار قائمة الفيديو التي تم اختيارها',YLKFRH6sSIrznXBg,351,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1')
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+' [[   '+QUFL2gEBMn63qlsmI7W+'   ]]',YLKFRH6sSIrznXBg,351,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1')
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,True,'AKOAMCAM-FILTERS_MENU-1st')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('<form id(.*?)</form>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	W1A4L5P0Zc8wHnUGjVexElz = EcQxOa3RJm86WjTKA.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	dict = {}
	for jLA9nhxoZbG,name,wlJ6d8hEvpoMNSCmU in W1A4L5P0Zc8wHnUGjVexElz:
		items = EcQxOa3RJm86WjTKA.findall('<option(.*?)>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if '=' not in YLKFRH6sSIrznXBg: YLKFRH6sSIrznXBg = url
		if type=='CATEGORIES':
			if fnogyzNA30JCPMYqHTavG7ZKp!=jLA9nhxoZbG: continue
			elif len(items)<=1:
				if jLA9nhxoZbG==ffJIco45MG9kFntgWDwqyR[-1]: HAsKeZdTbqjPI1WY(YLKFRH6sSIrznXBg)
				else: F4ehkvPDxXU(YLKFRH6sSIrznXBg,'CATEGORIES___'+HfvJenZmN3O8rPcshLux2EyzDWpQCb)
				return
			else:
				if jLA9nhxoZbG==ffJIco45MG9kFntgWDwqyR[-1]: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع',YLKFRH6sSIrznXBg,351,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1')
				else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع',YLKFRH6sSIrznXBg,355,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,HfvJenZmN3O8rPcshLux2EyzDWpQCb)
		elif type=='FILTERS':
			z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&'+jLA9nhxoZbG+'=0'
			ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&'+jLA9nhxoZbG+'=0'
			HfvJenZmN3O8rPcshLux2EyzDWpQCb = z7VI1OaUPqs4lXxb+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع : '+name,YLKFRH6sSIrznXBg,354,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,HfvJenZmN3O8rPcshLux2EyzDWpQCb)
		dict[jLA9nhxoZbG] = {}
		for value,srR9AuG6Pf8powqU4ixL5Ecl in items:
			if srR9AuG6Pf8powqU4ixL5Ecl in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
			if 'value' not in value: value = srR9AuG6Pf8powqU4ixL5Ecl
			else: value = EcQxOa3RJm86WjTKA.findall('"(.*?)"',value,EcQxOa3RJm86WjTKA.DOTALL)[0]
			dict[jLA9nhxoZbG][value] = srR9AuG6Pf8powqU4ixL5Ecl
			z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&'+jLA9nhxoZbG+'='+srR9AuG6Pf8powqU4ixL5Ecl
			ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&'+jLA9nhxoZbG+'='+value
			QdzUcX2iR5 = z7VI1OaUPqs4lXxb+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq
			title = srR9AuG6Pf8powqU4ixL5Ecl+' : '#+dict[jLA9nhxoZbG]['0']
			title = srR9AuG6Pf8powqU4ixL5Ecl+' : '+name
			if type=='FILTERS': OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,354,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QdzUcX2iR5)
			elif type=='CATEGORIES' and ffJIco45MG9kFntgWDwqyR[-2]+'=' in NnQ1hEsTV7Zaz3HKdfu:
				F231lsuCKnaSMdQ48W6PoL = nKT1QuLoXPc8CjyV(ybEUMsLp4zBVPnuAYI0cCdowekDq,'all')
				MYWwFs7XA2 = url+'?'+F231lsuCKnaSMdQ48W6PoL
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,MYWwFs7XA2,351,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'1')
			else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,355,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QdzUcX2iR5)
	return
def nKT1QuLoXPc8CjyV(p9UP6wGlC1BF7fN2,mode):
	p9UP6wGlC1BF7fN2 = p9UP6wGlC1BF7fN2.strip('&')
	vpLWbVm35iM0l2TzYIN7 = {}
	if '=' in p9UP6wGlC1BF7fN2:
		items = p9UP6wGlC1BF7fN2.split('&')
		for j25T6eKhaMk3 in items:
			XJRx6urSNaOM5AfZdDsgQBYGt,value = j25T6eKhaMk3.split('=')
			vpLWbVm35iM0l2TzYIN7[XJRx6urSNaOM5AfZdDsgQBYGt] = value
	MKJaIb2sDSr4VCQGTqyX3nkWL = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	nohzWuNjPvp0MA = ['cat','genre','release-year','quality','orderby']
	for key in nohzWuNjPvp0MA:
		if key in list(vpLWbVm35iM0l2TzYIN7.keys()): value = vpLWbVm35iM0l2TzYIN7[key]
		else: value = '0'
		if mode=='modified_values' and value!='0': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+' + '+value
		elif mode=='modified_filters' and value!='0': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+'&'+key+'='+value
		elif mode=='all': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+'&'+key+'='+value
	MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL.strip(' + ')
	MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL.strip('&')
	return MKJaIb2sDSr4VCQGTqyX3nkWL
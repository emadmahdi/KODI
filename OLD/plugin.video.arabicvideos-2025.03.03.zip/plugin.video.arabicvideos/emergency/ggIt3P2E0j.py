# -*- coding: utf-8 -*-
import sys as pKa1u0TlfjDmGNicsJA5
r3VAbBw4dKSg7jakPvOzs6nX = pKa1u0TlfjDmGNicsJA5.version_info [0] == 2
UJcgGV57MXk4OlFtz = 2048
yyfncjY3J0tPTqZ7lxakAwHuE4v9 = 7
def OYCeqyLUxkXK7GntJ (ggyx52ojpEraFUnJSHGB9T8qmXC):
	global drlz4SPEQTGIm0Ye7xHNVJFith
	bs0qmdc8JtI3UuDk7 = ord (ggyx52ojpEraFUnJSHGB9T8qmXC [-1])
	G2LxO6Umrsi9 = ggyx52ojpEraFUnJSHGB9T8qmXC [:-1]
	MvnqAYJslIFLH1wg5 = bs0qmdc8JtI3UuDk7 % len (G2LxO6Umrsi9)
	bXE6uBpqhTWoxCmfUnvzs2V0e = G2LxO6Umrsi9 [:MvnqAYJslIFLH1wg5] + G2LxO6Umrsi9 [MvnqAYJslIFLH1wg5:]
	if r3VAbBw4dKSg7jakPvOzs6nX:
		bYaMxjoLEq3wf7WKAevGnzpUJ = unicode () .join ([unichr (ord (vSihmylIqsGWdFB06YuU7Pa3zT) - UJcgGV57MXk4OlFtz - (Zox7lpc3XQ + bs0qmdc8JtI3UuDk7) % yyfncjY3J0tPTqZ7lxakAwHuE4v9) for Zox7lpc3XQ, vSihmylIqsGWdFB06YuU7Pa3zT in enumerate (bXE6uBpqhTWoxCmfUnvzs2V0e)])
	else:
		bYaMxjoLEq3wf7WKAevGnzpUJ = str () .join ([chr (ord (vSihmylIqsGWdFB06YuU7Pa3zT) - UJcgGV57MXk4OlFtz - (Zox7lpc3XQ + bs0qmdc8JtI3UuDk7) % yyfncjY3J0tPTqZ7lxakAwHuE4v9) for Zox7lpc3XQ, vSihmylIqsGWdFB06YuU7Pa3zT in enumerate (bXE6uBpqhTWoxCmfUnvzs2V0e)])
	return eval (bYaMxjoLEq3wf7WKAevGnzpUJ)
XmoF6zpEyA02,D0DtPze5lgTkLrJSmGs1,WGx2ZLSntviYBUgOQHFTK=OYCeqyLUxkXK7GntJ,OYCeqyLUxkXK7GntJ,OYCeqyLUxkXK7GntJ
v8PgVyMQKq9cirknTtmfZXde3j4,y8JsFwe7nZhcoV,oJDrWBS1nd2HbLOcmZUfjw9hF6tV=WGx2ZLSntviYBUgOQHFTK,D0DtPze5lgTkLrJSmGs1,XmoF6zpEyA02
z8zfSJEeGV,PT3EozVtWF6O1XfrLcDBMIKmh,espLXqowxWQ6g3HJl7V2hRzcvZ=oJDrWBS1nd2HbLOcmZUfjw9hF6tV,y8JsFwe7nZhcoV,v8PgVyMQKq9cirknTtmfZXde3j4
ClgkqfXeacDvdApu1V,jzYpMnA9b1cIOVfa7DT4wRSo,A8Mz3RINKbBPrkdW7J=espLXqowxWQ6g3HJl7V2hRzcvZ,PT3EozVtWF6O1XfrLcDBMIKmh,z8zfSJEeGV
rVZencBlLS3X,h68nRKy0xsLafj59pw7MQimEHcXgB,MXfjqwL8KVtT=A8Mz3RINKbBPrkdW7J,jzYpMnA9b1cIOVfa7DT4wRSo,ClgkqfXeacDvdApu1V
HQ2fNJyt4nr1e,Jy71gvbcDQNHzBjEXkY3lP9,VzDtWQ93eOLNmiMc1aqnYrdG6w=MXfjqwL8KVtT,h68nRKy0xsLafj59pw7MQimEHcXgB,rVZencBlLS3X
u6fbnELOkBj,hhUAB3jynr2apH,hNSxcWr5eb6JFklO2vDoptPULIQn=VzDtWQ93eOLNmiMc1aqnYrdG6w,Jy71gvbcDQNHzBjEXkY3lP9,HQ2fNJyt4nr1e
R6UW7rjcLz,VIjeMAbrmxN80fX,cctO50YQ1f=hNSxcWr5eb6JFklO2vDoptPULIQn,hhUAB3jynr2apH,u6fbnELOkBj
qPB07jCaX4fI1VSi58o,NRgByCfFUKI39Xh,tt5djKRw0eU3lHQ7zXrgh9A=cctO50YQ1f,VIjeMAbrmxN80fX,R6UW7rjcLz
TTXke6j4fzZ9cSULM0RhpEKx,UjyTu7OdN5X1rKhq,kR1DV3eCSiAoc=tt5djKRw0eU3lHQ7zXrgh9A,NRgByCfFUKI39Xh,qPB07jCaX4fI1VSi58o
nPIvBxHVDyhQ7fzRl,pA32bf4OYgTs18GxkqhyFMUHrzWcEo,JmOncNUQdKw3rj7LCsxlzRuZqbHP=kR1DV3eCSiAoc,UjyTu7OdN5X1rKhq,TTXke6j4fzZ9cSULM0RhpEKx
import xbmc as yn562EIqXglZ8uMCm1,xbmcgui as BvTyn0kGDr7HMXUVw65hLeAS,sys as pKa1u0TlfjDmGNicsJA5,os as KKaTeP8NnIjkwcAQDMuRyYUBmgG,requests as u3GsSUp6d7LiJAxmYqTElNtOve5,re as cRItOw7Ed8KJZjTeCoSLz4156FAx,xbmcvfs as dQGhZfVFoLkTRAX6EJIK1g,base64 as llKm3Hec7J,time as w8wihmupIJTgXOjqLrGdE3k0
yyYJ7pLMrOxz6mE82AH0 = VzDtWQ93eOLNmiMc1aqnYrdG6w(u"ࠫࠬࠀ")
def jQY4yCeI3fZgJ710NHshV5w(request):
	EYszrFCU5VKh = y8JsFwe7nZhcoV(u"ࠬࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࡰࡲࡧࡦࡴࡣࡦ࡮ࠪࠁ")
	if request==u6fbnELOkBj(u"࠭ࡳࡵࡣࡵࡸࠬࠂ"): yn562EIqXglZ8uMCm1.executebuiltin(tt5djKRw0eU3lHQ7zXrgh9A(u"ࠧࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࠩࠃ")+EYszrFCU5VKh+y8JsFwe7nZhcoV(u"ࠨࠫࠪࠄ"))
	elif request==oJDrWBS1nd2HbLOcmZUfjw9hF6tV(u"ࠩࡶࡸࡴࡶࠧࠅ"): yn562EIqXglZ8uMCm1.executebuiltin(hhUAB3jynr2apH(u"ࠪࡈ࡮ࡧ࡬ࡰࡩ࠱ࡇࡱࡵࡳࡦࠪࠪࠆ")+EYszrFCU5VKh+R6UW7rjcLz(u"ࠫ࠮࠭ࠇ"))
	return
def llprkZsqYh(jjSieN3ZqyxvX,EZ02VGUz1kAhyFvKu3fPRIHJq7bcO,VP4tjATogflvbQ6Ip3ES2,uXi5gaqGAdVN6,text):
	if not EZ02VGUz1kAhyFvKu3fPRIHJq7bcO: EZ02VGUz1kAhyFvKu3fPRIHJq7bcO = Jy71gvbcDQNHzBjEXkY3lP9(u"้ࠬไศࠩࠈ")
	if not VP4tjATogflvbQ6Ip3ES2: VP4tjATogflvbQ6Ip3ES2 = oJDrWBS1nd2HbLOcmZUfjw9hF6tV(u"࠭ๆฺ็ࠪࠉ")
	if not uXi5gaqGAdVN6: uXi5gaqGAdVN6 = hNSxcWr5eb6JFklO2vDoptPULIQn(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࠊ")
	if cjdyhqEa4R9epQXUSLizTJ: c1G6VaLyqY = BvTyn0kGDr7HMXUVw65hLeAS.Dialog().yesno(uXi5gaqGAdVN6,text,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,EZ02VGUz1kAhyFvKu3fPRIHJq7bcO,VP4tjATogflvbQ6Ip3ES2)
	else: c1G6VaLyqY = BvTyn0kGDr7HMXUVw65hLeAS.Dialog().yesno(uXi5gaqGAdVN6,text,EZ02VGUz1kAhyFvKu3fPRIHJq7bcO,VP4tjATogflvbQ6Ip3ES2)
	return c1G6VaLyqY
def kPzAxbnJdW(jjSieN3ZqyxvX,mq78GXDC6refhTwSFH,uXi5gaqGAdVN6,text):
	if not uXi5gaqGAdVN6: uXi5gaqGAdVN6 = qPB07jCaX4fI1VSi58o(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࠋ")
	return BvTyn0kGDr7HMXUVw65hLeAS.Dialog().ok(uXi5gaqGAdVN6,text,mq78GXDC6refhTwSFH)
def KH9ZRJpjo7imzBb(uXi5gaqGAdVN6=y8JsFwe7nZhcoV(u"ࠩ็์าฯࠠศๆ่ๅฬะ๊ฮࠩࠌ"),YhcMDJPfHEnitCrv=yyYJ7pLMrOxz6mE82AH0):
	MMmJjt04gz = BvTyn0kGDr7HMXUVw65hLeAS.Dialog().input(uXi5gaqGAdVN6,YhcMDJPfHEnitCrv,type=BvTyn0kGDr7HMXUVw65hLeAS.INPUT_ALPHANUM)
	MMmJjt04gz = MMmJjt04gz.strip(VIjeMAbrmxN80fX(u"ࠪࠤࠬࠍ")).replace(cctO50YQ1f(u"ࠫࠥࠦࠠࠡࠩࠎ"),UjyTu7OdN5X1rKhq(u"ࠬࠦࠧࠏ")).replace(MXfjqwL8KVtT(u"࠭ࠠࠡࠢࠪࠐ"),R6UW7rjcLz(u"ࠧࠡࠩࠑ")).replace(h68nRKy0xsLafj59pw7MQimEHcXgB(u"ࠨࠢࠣࠫࠒ"),hNSxcWr5eb6JFklO2vDoptPULIQn(u"ࠩࠣࠫࠓ"))
	return MMmJjt04gz
def ooFVGs1PRH3dXM(U6Q5JKHbxy2):
	c1G6VaLyqY = llprkZsqYh(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,h68nRKy0xsLafj59pw7MQimEHcXgB(u"ࠪๆอ๊ࠠฦำึห้ࠦำอๆࠣห้ษฮุษฤࠤ๏าศࠡล้ࠤฯฺฺๅࠢหี๋อๅอࠢ฼้ฬี้ࠠฬ้ฮ฽ืࠠฮฬ์ࠤฯ฾็าࠢ็็ࠥอไๆึส็้่ࠦศๆฦา฼อมࠡ࠰࠱ࠤ฾์ฯ่ษࠣื๏่่ๆࠢๆ์ิ๐ࠠษฬึะ๏๊่ࠠา๊ࠤฬ๊ๅีษๆ่ࠥ๎วๅลั฻ฬวࠠโ์ࠣืั๊ࠠศๆฦา฼อมࠡ࠰࠱ࠤํฮูะ้สࠤ็๋ࠠษวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสล๊ࠥไๆสิ้ัࠦ࠮࠯๊่ࠢࠥะั๋ัࠣห้ศๆࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥหไ๊ࠢส่๊ฮัๆฮࠣรࠦ࠭ࠔ"))
	if c1G6VaLyqY!=VzDtWQ93eOLNmiMc1aqnYrdG6w(u"࠱ࢫ"): return
	if not KKaTeP8NnIjkwcAQDMuRyYUBmgG.path.exists(U6Q5JKHbxy2):
		kPzAxbnJdW(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,cctO50YQ1f(u"้๊ࠫริใࠣ࠲࠳ࠦำอๆࠣห้ษฮุษฤࠤ฿๐ัࠡ็๋ะํีࠠฤู๊้๊่ࠣฮࠩࠕ"))
		return
	message = KH9ZRJpjo7imzBb(jzYpMnA9b1cIOVfa7DT4wRSo(u"ࠬษใหสࠣีุอไหๅࠣห้ะ๊ࠡฬิ๎ิࠦลาีส่์อࠠๆ฻ࠣืั๊ࠠศๆฦา฼อมࠨࠖ"))
	nfPQB46HdsEtv = yn562EIqXglZ8uMCm1.getInfoLabel(PT3EozVtWF6O1XfrLcDBMIKmh(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡁࡥࡦࡲࡲ࡛࡫ࡲࡴ࡫ࡲࡲ࠭࠭ࠗ")+EFYwqgCNmGdrRH4yS61ZIj+z8zfSJEeGV(u"ࠧࠪࠩ࠘"))
	file = open(U6Q5JKHbxy2,VIjeMAbrmxN80fX(u"ࠨࡴࡥࠫ࠙"))
	fWUyO2mz5LGst73TMSc9uwI = KKaTeP8NnIjkwcAQDMuRyYUBmgG.path.getsize(U6Q5JKHbxy2)
	if fWUyO2mz5LGst73TMSc9uwI>tt5djKRw0eU3lHQ7zXrgh9A(u"࠴࠲࠴࠴࠵࠶ࢬ"): file.seek(-tt5djKRw0eU3lHQ7zXrgh9A(u"࠴࠲࠴࠴࠵࠶ࢬ"),KKaTeP8NnIjkwcAQDMuRyYUBmgG.SEEK_END)
	data = file.read()
	file.close()
	data = data.decode(cctO50YQ1f(u"ࠩࡸࡸ࡫࠾ࠧࠚ"))
	YgR0C6vcSjkNiBVAfP = cRItOw7Ed8KJZjTeCoSLz4156FAx.findall(hNSxcWr5eb6JFklO2vDoptPULIQn(u"ࠥࠫࡺࡹࡥࡳࡡ࡬ࡨࠬࡀࠠࠨࠪ࠱࠮ࡄ࠯ࠧࠣࠛ"),data,cRItOw7Ed8KJZjTeCoSLz4156FAx.DOTALL)
	if not YgR0C6vcSjkNiBVAfP: YgR0C6vcSjkNiBVAfP = cRItOw7Ed8KJZjTeCoSLz4156FAx.findall(VzDtWQ93eOLNmiMc1aqnYrdG6w(u"ࠦࠬࡻࡳࡦࡴࠪ࠾ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨࠜ"),data,cRItOw7Ed8KJZjTeCoSLz4156FAx.DOTALL)
	if not YgR0C6vcSjkNiBVAfP: YgR0C6vcSjkNiBVAfP = cRItOw7Ed8KJZjTeCoSLz4156FAx.findall(oJDrWBS1nd2HbLOcmZUfjw9hF6tV(u"ࠬࡢࡤࡼ࠶ࢀ࠱ࡡࡪࡻ࠵ࡿ࠰ࡠࡩࢁ࠴ࡾ࠯࡟ࡨࢀ࠺ࡽ࠮࡞ࡧࡿ࠹ࢃࠧࠝ"),data,cRItOw7Ed8KJZjTeCoSLz4156FAx.DOTALL)
	YgR0C6vcSjkNiBVAfP = YgR0C6vcSjkNiBVAfP[XmoF6zpEyA02(u"࠲ࢭ")] if YgR0C6vcSjkNiBVAfP else MXfjqwL8KVtT(u"࠭࠰࠱࠲࠳ࠫࠞ")
	YgR0C6vcSjkNiBVAfP = YgR0C6vcSjkNiBVAfP.split(MXfjqwL8KVtT(u"ࠧ࡝ࡰࠪࠟ"),pA32bf4OYgTs18GxkqhyFMUHrzWcEo(u"࠴ࢮ"))[v8PgVyMQKq9cirknTtmfZXde3j4(u"࠴ࢯ")]
	if cjdyhqEa4R9epQXUSLizTJ: YgR0C6vcSjkNiBVAfP = YgR0C6vcSjkNiBVAfP.encode(u6fbnELOkBj(u"ࠨࡷࡷࡪ࠽࠭ࠠ"))
	JDv89gnhVPXrQKetNqSIfd = nPIvBxHVDyhQ7fzRl(u"ࠩࡄ࡚࠿ࠦࠧࠡ")+YgR0C6vcSjkNiBVAfP+WGx2ZLSntviYBUgOQHFTK(u"ࠪ࠱ࡊࡳࡥࡳࡩࡨࡲࡨࡿࠧࠢ")
	message += hNSxcWr5eb6JFklO2vDoptPULIQn(u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࡞ࡱࡉࡲࡧࡩ࡭ࠢࡖࡩࡳࡪࡥࡳ࠼ࠣࠫࠣ")+YgR0C6vcSjkNiBVAfP+u6fbnELOkBj(u"ࠬࠦ࠺ࠨࠤ")+VzDtWQ93eOLNmiMc1aqnYrdG6w(u"࠭࡜࡯ࠩࠥ")+Jy71gvbcDQNHzBjEXkY3lP9(u"ࠧࡂࡦࡧࡳࡳࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩࠦ")+nfPQB46HdsEtv+VzDtWQ93eOLNmiMc1aqnYrdG6w(u"ࠨࠢ࠽ࡠࡳ࠭ࠧ")
	data = data.encode(UjyTu7OdN5X1rKhq(u"ࠩࡸࡸ࡫࠾ࠧࠨ"))
	cWIvNDjzJF2LSRMi16kCdoZQOH = llKm3Hec7J.b64encode(data)
	Bxgbl5mw4Jt9GKsfzPRFa = {UjyTu7OdN5X1rKhq(u"ࠪࡷࡺࡨࡪࡦࡥࡷࠫࠩ"):JDv89gnhVPXrQKetNqSIfd,HQ2fNJyt4nr1e(u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬࠪ"):message,NRgByCfFUKI39Xh(u"ࠬࡲ࡯ࡨࡨ࡬ࡰࡪ࠭ࠫ"):cWIvNDjzJF2LSRMi16kCdoZQOH}
	tEa1fCBXzvGykx5beUwc20uLVH = nPIvBxHVDyhQ7fzRl(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩࠬ")
	CZhPu9r6yg4Waez1v = u3GsSUp6d7LiJAxmYqTElNtOve5.request(kR1DV3eCSiAoc(u"ࠧࡑࡑࡖࡘࠬ࠭"),tEa1fCBXzvGykx5beUwc20uLVH,data=Bxgbl5mw4Jt9GKsfzPRFa)
	if CZhPu9r6yg4Waez1v.status_code==VzDtWQ93eOLNmiMc1aqnYrdG6w(u"࠷࠶࠰ࢰ"): kPzAxbnJdW(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,kR1DV3eCSiAoc(u"ࠨฮํำࠥ࠴࠮่ࠡฯัฯูࠦๆๆํอࠥหัิษ็ࠤุาไࠡษ็วำ฽วยࠩ࠮"))
	else: kPzAxbnJdW(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,ClgkqfXeacDvdApu1V(u"ࠩ็่ศูแࠡ࠰࠱ࠤๆฺไหࠢ฼้้๐ษࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠬ࠯"))
	return
def FwYqVOp6tuG2Ay8KhUJrH3TiD():
	c1G6VaLyqY = llprkZsqYh(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,PT3EozVtWF6O1XfrLcDBMIKmh(u"้้ࠪ็ࠠฦ฻าหิอสࠡษ็ฬึ์วๆฮࠣ๎าะ่๋ࠢ฼่๎ࠦๅฺๆ๋้ฬะࠠหะุࠤฯำฯ๋อࠣห้ฮั็ษ่ะࠥ๎ส็ฺํ้ࠥ฿ๅๅࠢส่อืๆศ็ฯࠤ࠳࠴ฺ่ࠠาࠤู๊อ้ࠡำหࠥอไๆๆไࠤุ๐โ้็ࠣห้ฮั็ษ่ะࠥฮฮๅไ้้ࠣ็ࠠอัํำࠥ็วา฼ࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠศๆล๊๋ࠥำฮ่่ࠢๆࠦลฺัสำฬะࠠศๆหี๋อๅอࠢยࠥࠬ࠰"))
	if c1G6VaLyqY!=h68nRKy0xsLafj59pw7MQimEHcXgB(u"࠷ࢱ"): return
	CNBReblmPLjsOAHUrkSq = DXJwqGErKey7dTWvcPfOtU(Y8vekg6CoNqQUAhDfx7JtBP,espLXqowxWQ6g3HJl7V2hRzcvZ(u"ࡌࡡ࡭ࡵࡨࣆ"))
	if CNBReblmPLjsOAHUrkSq: kPzAxbnJdW(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,NRgByCfFUKI39Xh(u"ࠫั๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡ็ึั๋ࠥไโࠢศ฽ิอฯศฬࠣฬึ์วๆฮࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮ࠭࠱"))
	else: kPzAxbnJdW(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,R6UW7rjcLz(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็็ๅࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ࠲"))
	return
def ZAVHj2Wku6Rfyl5KaNoxB49():
	c1G6VaLyqY = llprkZsqYh(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,u6fbnELOkBj(u"࠭ๅอๆาࠤ่อิࠡษ็ฬึ์วๆฮࠣ๎าะ่๋ࠢ฼่๎ࠦๅๅใสฮࠥะฮึࠢอ๊฽๐ๅࠡ฻่่ࠥอไษำ้ห๊าࠠๆอ็ࠤ๊๊แศฬࠣห้๋แืๆฬࠤํ๋ไโษอࠤࡎࡖࡔࡗ๋ࠢࠤࡒ࠹ࡕุ๊ࠡ์ึࠦวๅไ๋หห๋ࠠ࠯࠰ࠣ฽๋ีࠠๆีะࠤ์ึวࠡษ็้ั๊ฯࠡีํๆํ๋ࠠศๆหี๋อๅอࠢหา้่ࠠๆฮ็ำࠥาฯ๋ัࠣๅฬืฺࠡ࠰࠱ࠤ์๊ࠠหำํำࠥอไรุ่้ࠣำࠠๆฮ็ำ้ࠥวีࠢส่อืๆศ็ฯࠤฤࠧࠧ࠳"))
	if c1G6VaLyqY!=WGx2ZLSntviYBUgOQHFTK(u"࠱ࢲ"): return
	CNBReblmPLjsOAHUrkSq = pVsCIAjqBneGwh5fEWHTFO3c(vvFWsm1AJt8fxZ0nuMpodalBO,cctO50YQ1f(u"ࡕࡴࡸࡩࣈ"),cctO50YQ1f(u"ࡕࡴࡸࡩࣈ"),JmOncNUQdKw3rj7LCsxlzRuZqbHP(u"ࡆࡢ࡮ࡶࡩࣇ"))
	if CNBReblmPLjsOAHUrkSq: kPzAxbnJdW(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,tt5djKRw0eU3lHQ7zXrgh9A(u"ࠧอ์าࠤ࠳࠴ࠠ็ฮะฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็ฯ่ิࠦใศึࠣห้ฮั็ษ่ะࠬ࠴"))
	else: kPzAxbnJdW(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,D0DtPze5lgTkLrJSmGs1(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣๅู๊สࠡ฻่่๏ฯࠠๆีะࠤ๊าไะࠢๆหูࠦวๅสิ๊ฬ๋ฬࠨ࠵"))
	return
def DXJwqGErKey7dTWvcPfOtU(pDsAT9twgzfhWko5LQu,LLFkfBCTHA):
	CNBReblmPLjsOAHUrkSq = hhUAB3jynr2apH(u"ࡖࡵࡹࡪࣉ")
	if LLFkfBCTHA:
		c1G6VaLyqY = llprkZsqYh(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,WGx2ZLSntviYBUgOQHFTK(u"่่ࠩๆࠦลฺัสำฬะࠠศๆหี๋อๅอࠢํัฯ๎๊ࠡ฻็ํู๋ࠥๅ๊่หฯࠦสฯืࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤํะๆู์่ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣ࠲࠳ูࠦ็ัุ้ࠣำ่ࠠาสࠤฬ๊ๅๅใࠣื๏่่ๆࠢส่อืๆศ็ฯࠤอิไใ่่ࠢๆࠦฬะ์าࠤๆอั฻ࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤู๊อࠡ็็ๅࠥหูะษาหฯࠦวๅสิ๊ฬ๋ฬࠡมࠤࠫ࠶"))
		if c1G6VaLyqY!=MXfjqwL8KVtT(u"࠲ࢳ"): return
	if KKaTeP8NnIjkwcAQDMuRyYUBmgG.path.exists(pDsAT9twgzfhWko5LQu):
		try:
			pass
		except Exception as qq27LCR5ngKZPWG:
			CNBReblmPLjsOAHUrkSq = oJDrWBS1nd2HbLOcmZUfjw9hF6tV(u"ࡉࡥࡱࡹࡥ࣊")
			if LLFkfBCTHA: kPzAxbnJdW(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,str(qq27LCR5ngKZPWG))
	if LLFkfBCTHA:
		if CNBReblmPLjsOAHUrkSq: kPzAxbnJdW(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,JmOncNUQdKw3rj7LCsxlzRuZqbHP(u"ࠪะ๏ีࠠ࠯࠰๊ࠣัำสࠡ฻่่๏ฯࠠศๆ่ืา࠭࠷"))
		else: kPzAxbnJdW(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,Jy71gvbcDQNHzBjEXkY3lP9(u"้๊ࠫริใࠣ࠲࠳ࠦแีๆอࠤ฾๋ไ๋หࠣห้๋ำฮࠩ࠸"))
	return CNBReblmPLjsOAHUrkSq
def pVsCIAjqBneGwh5fEWHTFO3c(BmyLd8N2nAMPkW,sdaQVbKTc10qghLXx5OjeirR,rET1WJR5lm,LLFkfBCTHA):
	CNBReblmPLjsOAHUrkSq = WGx2ZLSntviYBUgOQHFTK(u"ࡘࡷࡻࡥ࣋")
	if LLFkfBCTHA:
		c1G6VaLyqY = llprkZsqYh(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,BmyLd8N2nAMPkW+JmOncNUQdKw3rj7LCsxlzRuZqbHP(u"ࠬࡢ࡮࡝ࡰ๊่ࠥะั๋ัุ้ࠣำ่ࠠาสࠤฬ๊ๅอๆาࠤฤࠧࠧ࠹"))
		if c1G6VaLyqY!=WGx2ZLSntviYBUgOQHFTK(u"࠳ࢴ"): return
	if KKaTeP8NnIjkwcAQDMuRyYUBmgG.path.exists(BmyLd8N2nAMPkW):
		for zqvdVNlc62K1W3kEtIBY,rFBfVDbiYunH6x41sLJlAZ2,GydZwIMN6PUSsJuCXr5hHj in KKaTeP8NnIjkwcAQDMuRyYUBmgG.walk(BmyLd8N2nAMPkW,topdown=PT3EozVtWF6O1XfrLcDBMIKmh(u"ࡋࡧ࡬ࡴࡧ࣌")):
			for LsufA9kxcWCmOzJNYo1PXGK53iMyg in GydZwIMN6PUSsJuCXr5hHj:
				loujKk9NMzS4CcTOWpsLnUIaG7E = KKaTeP8NnIjkwcAQDMuRyYUBmgG.path.join(zqvdVNlc62K1W3kEtIBY,LsufA9kxcWCmOzJNYo1PXGK53iMyg)
				try:
					KKaTeP8NnIjkwcAQDMuRyYUBmgG.remove(loujKk9NMzS4CcTOWpsLnUIaG7E)
				except Exception as qq27LCR5ngKZPWG:
					CNBReblmPLjsOAHUrkSq = UjyTu7OdN5X1rKhq(u"ࡌࡡ࡭ࡵࡨ࣍")
					if LLFkfBCTHA: kPzAxbnJdW(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,str(qq27LCR5ngKZPWG))
			if sdaQVbKTc10qghLXx5OjeirR:
				for qEcneTmLS46xADU2 in rFBfVDbiYunH6x41sLJlAZ2:
					F3hwLHrqY89aeb0ioPxC = KKaTeP8NnIjkwcAQDMuRyYUBmgG.path.join(zqvdVNlc62K1W3kEtIBY,qEcneTmLS46xADU2)
					try:
						KKaTeP8NnIjkwcAQDMuRyYUBmgG.rmdir(F3hwLHrqY89aeb0ioPxC)
					except: pass
		if rET1WJR5lm:
			try:
				KKaTeP8NnIjkwcAQDMuRyYUBmgG.rmdir(zqvdVNlc62K1W3kEtIBY)
			except: pass
	if LLFkfBCTHA:
		if CNBReblmPLjsOAHUrkSq: kPzAxbnJdW(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,oJDrWBS1nd2HbLOcmZUfjw9hF6tV(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หࠣห้๋ำฮࠩ࠺"))
		else: kPzAxbnJdW(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,MXfjqwL8KVtT(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦวๅ็ึัࠬ࠻"))
	return CNBReblmPLjsOAHUrkSq
def Q2zS7ek3ZmqrUduPEo4twgi0K():
	c1G6VaLyqY = llprkZsqYh(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,VIjeMAbrmxN80fX(u"ࠨ็ฯ่ิࠦี้ำࠣ็ฯอศสࠢส่็๎วว็ࠣ࠲࠳ࠦ็ัษࠣห้๋ฬๅัࠣๅ๏ํࠠษ฻ูࠤ็๎วว็ࠣห้ฮั็ษ่ะ๋ࠥฮำ่ฬࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠡ࠰࠱ࠤ฾์ฯࠡ็ึัࠥอไๆฮ็ำู๊ࠥใ๊่ࠤฬ๊ศา่ส้ัࠦศฯๆๅࠤ๊าไะࠢฯำ๏ี้ࠠ์หำศࠦๅาหࠣวำื้ࠡส่่หํࠠษษ็ูํืฺ่ࠠาࠤๆะอࠡษ็ๆํอฦๆࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤู๊อࠡ็ฯ่ิࠦี้ำࠣ็ฯอศสࠢๅ์ฬฬๅࠡษ็ฬึ์วๆฮࠣรࠦ࠭࠼"))
	if c1G6VaLyqY!=R6UW7rjcLz(u"࠴ࢵ"): return
	CNBReblmPLjsOAHUrkSq = pVsCIAjqBneGwh5fEWHTFO3c(ryWuQdm4zjxGc9,tt5djKRw0eU3lHQ7zXrgh9A(u"ࡕࡴࡸࡩ࣏"),MXfjqwL8KVtT(u"ࡆࡢ࡮ࡶࡩ࣎"),tt5djKRw0eU3lHQ7zXrgh9A(u"ࡕࡴࡸࡩ࣏"))
	if CNBReblmPLjsOAHUrkSq: kPzAxbnJdW(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,u6fbnELOkBj(u"ࠩฯ๎ิࠦ࠮࠯้ࠢะาะฺࠠ็็๎ฮࠦๅิฯ้ࠣั๊ฯࠡื๋ี้ࠥสศสฬࠤฬ๊โ้ษษ้ࠬ࠽"))
	else: kPzAxbnJdW(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,R6UW7rjcLz(u"่้ࠪษำโࠢ࠱࠲ࠥ็ิๅฬࠣ฽๊๊๊ส่ࠢืาࠦๅอๆาࠤฺ๎ัࠡๅอหอฯࠠศๆๅ์ฬฬๅࠨ࠾"))
	return
def UkgEiFeR1dDO4():
	tEa1fCBXzvGykx5beUwc20uLVH = VIjeMAbrmxN80fX(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡴࡷࡵ࡫ࡪ࠴ࡳࡩ࠱࡮ࡳࡩ࡯࠯ࡦ࡯ࡤࡨࡤࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠳ࡴࡲࡤ࠰࡫ࡱࡨࡪࡾ࠮ࡩࡶࡰࡰࠬ࠿")
	CZhPu9r6yg4Waez1v = u3GsSUp6d7LiJAxmYqTElNtOve5.request(oJDrWBS1nd2HbLOcmZUfjw9hF6tV(u"ࠬࡍࡅࡕࠩࡀ"),tEa1fCBXzvGykx5beUwc20uLVH)
	FbhAXp4qefLY72oSKJ = CZhPu9r6yg4Waez1v.content
	FbhAXp4qefLY72oSKJ = FbhAXp4qefLY72oSKJ.decode(hNSxcWr5eb6JFklO2vDoptPULIQn(u"࠭ࡵࡵࡨ࠻ࠫࡁ"))
	GydZwIMN6PUSsJuCXr5hHj = cRItOw7Ed8KJZjTeCoSLz4156FAx.findall(HQ2fNJyt4nr1e(u"ࠧࡩࡴࡨࡪࡂࠨࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࠮࠮ࠫࡁࠬ࠲ࡿ࡯ࡰࠣࠩࡂ"),FbhAXp4qefLY72oSKJ,cRItOw7Ed8KJZjTeCoSLz4156FAx.DOTALL)
	GydZwIMN6PUSsJuCXr5hHj = sorted(GydZwIMN6PUSsJuCXr5hHj,reverse=v8PgVyMQKq9cirknTtmfZXde3j4(u"ࡖࡵࡹࡪ࣐"))
	x0tkDlmAFYBqUzj5XryQwKEPS4ps = BvTyn0kGDr7HMXUVw65hLeAS.Dialog().select(HQ2fNJyt4nr1e(u"ࠨษัฮึࠦวๅวุำฬืࠠศๆำ๎ࠥะั๋ัࠣฮะฮ๊ห้ࠪࡃ"),GydZwIMN6PUSsJuCXr5hHj)
	if x0tkDlmAFYBqUzj5XryQwKEPS4ps==-XmoF6zpEyA02(u"࠵ࢶ"): return
	filename = GydZwIMN6PUSsJuCXr5hHj[x0tkDlmAFYBqUzj5XryQwKEPS4ps]
	if cjdyhqEa4R9epQXUSLizTJ: filename = filename.encode(v8PgVyMQKq9cirknTtmfZXde3j4(u"ࠩࡸࡸ࡫࠾ࠧࡄ"))
	hbFlQ8tsHoDZGgz4J = tEa1fCBXzvGykx5beUwc20uLVH.rsplit(z8zfSJEeGV(u"ࠪ࠳ࠬࡅ"),h68nRKy0xsLafj59pw7MQimEHcXgB(u"࠶ࢷ"))[kR1DV3eCSiAoc(u"࠶ࢸ")]+A8Mz3RINKbBPrkdW7J(u"ࠫ࠴࠭ࡆ")+h68nRKy0xsLafj59pw7MQimEHcXgB(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࠬࡇ")+filename+XmoF6zpEyA02(u"࠭࠮ࡻ࡫ࡳࠫࡈ")
	CNBReblmPLjsOAHUrkSq = rVZencBlLS3X(u"ࡉࡥࡱࡹࡥ࣑")
	CZhPu9r6yg4Waez1v = u3GsSUp6d7LiJAxmYqTElNtOve5.request(u6fbnELOkBj(u"ࠧࡈࡇࡗࠫࡉ"),hbFlQ8tsHoDZGgz4J)
	if CZhPu9r6yg4Waez1v.status_code==HQ2fNJyt4nr1e(u"࠲࠱࠲ࢹ"):
		vUaFIbKnJjDRN = CZhPu9r6yg4Waez1v.content
		import zipfile as DKgtuaCWZ0f,io as qXg8wFiSlLf4
		cay0zGuKQJqHTL6X4N = qXg8wFiSlLf4.BytesIO(vUaFIbKnJjDRN)
		pVsCIAjqBneGwh5fEWHTFO3c(HDjbFfVRg8,MXfjqwL8KVtT(u"࡙ࡸࡵࡦ࣓"),MXfjqwL8KVtT(u"࡙ࡸࡵࡦ࣓"),XmoF6zpEyA02(u"ࡊࡦࡲࡳࡦ࣒"))
		rN4Johjk69CU0VHfAaxcLqt12iTBY = DKgtuaCWZ0f.ZipFile(cay0zGuKQJqHTL6X4N)
		rN4Johjk69CU0VHfAaxcLqt12iTBY.extractall(QPcrkCOgHGqEyxBL0)
		w8wihmupIJTgXOjqLrGdE3k0.sleep(TTXke6j4fzZ9cSULM0RhpEKx(u"࠲ࢺ"))
		yn562EIqXglZ8uMCm1.executebuiltin(WGx2ZLSntviYBUgOQHFTK(u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬࡊ"))
		w8wihmupIJTgXOjqLrGdE3k0.sleep(ClgkqfXeacDvdApu1V(u"࠳ࢻ"))
		uDi2Nk6ljceHJZ9gLYaxqFSKQO = yn562EIqXglZ8uMCm1.executeJSONRPC(HQ2fNJyt4nr1e(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬࡋ")+EFYwqgCNmGdrRH4yS61ZIj+tt5djKRw0eU3lHQ7zXrgh9A(u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡶࡵࡹࡪࢃࡽࠨࡌ"))
		if WGx2ZLSntviYBUgOQHFTK(u"ࠫࡔࡑࠧࡍ") in uDi2Nk6ljceHJZ9gLYaxqFSKQO: CNBReblmPLjsOAHUrkSq = JmOncNUQdKw3rj7LCsxlzRuZqbHP(u"࡚ࡲࡶࡧࣔ")
	if CNBReblmPLjsOAHUrkSq:
		kPzAxbnJdW(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,Jy71gvbcDQNHzBjEXkY3lP9(u"ࠬา๊ะࠢ࠱࠲ࠥ์ฬฮฬࠣ฽๊๊๊สࠢอฯอ๐สࠡษ็ษฺีวาࠢส่็ี๊ๆࠢ࡟ࡲࡡࡴࠠࠨࡎ")+filename)
		msg = PT3EozVtWF6O1XfrLcDBMIKmh(u"࠭อห๋ࠣ๎อ่้ࠡษ็ษฺีวาࠢส่็ี๊ๆࠢไ๎ࠥา็ศิๆࠤํ๊วࠡ์อ้ࠥะอะ์ฮ๋ࠥษ่ห๊่หฯ๐ใ๋ษࠣ࠲࠳๊ࠦอสࠣว๋ࠦสใ๊่ࠤอห๊ใษไࠤฬ๊สฮัํฯࠥอไฤ๊อ์๊อส๋ๅํࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦล๋ไสๅࠥอไหฯา๎ะࠦวๅล๋ฮํ๋วห์ๆ๎๊ࠥไษำ้ห๊าࠠภࠣࠪࡏ")
		kE4WBAutlo5CYSL7bwDrRF1(msg)
	else: kPzAxbnJdW(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,hNSxcWr5eb6JFklO2vDoptPULIQn(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦสฬสํฮࠥอไฦืาหึࠦวๅไา๎๊ࠦ࡜࡯࡞ࡱࠤࠬࡐ")+filename)
	return
def kE4WBAutlo5CYSL7bwDrRF1(msg=VzDtWQ93eOLNmiMc1aqnYrdG6w(u"ࠨ้็ࠤฯื๊ะࠢอุ฿๐ไࠡล๋ࠤส๐โศใࠣห้ะอะ์ฮࠤฬ๊ร้ฬ๋้ฬะ๊ไ์่้ࠣฮั็ษ่ะࠥลࠡࠨࡑ")):
	c1G6VaLyqY = llprkZsqYh(yyYJ7pLMrOxz6mE82AH0,ClgkqfXeacDvdApu1V(u"ࠩศ๎็อแࠡษ็ฮาี๊ฬࠩࡒ"),HQ2fNJyt4nr1e(u"ࠪฮาี๊ฬࠢฦ์ฯ๎ๅศฬํ็๏࠭ࡓ"),yyYJ7pLMrOxz6mE82AH0,msg)
	if c1G6VaLyqY==-PT3EozVtWF6O1XfrLcDBMIKmh(u"࠴ࢼ"): return
	GFHpATum5j2sqzVIDWMhYZUr1X697K = R6UW7rjcLz(u"ࠫࡪࡴࡡࡣ࡮ࡨࠫࡔ") if c1G6VaLyqY else h68nRKy0xsLafj59pw7MQimEHcXgB(u"ࠬࡪࡩࡴࡣࡥࡰࡪ࠭ࡕ")
	CNBReblmPLjsOAHUrkSq = h68nRKy0xsLafj59pw7MQimEHcXgB(u"ࡆࡢ࡮ࡶࡩࣕ")
	Txcdz2YP5wSMEvXaZ4u = UjyTu7OdN5X1rKhq(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨࡖ")
	oYwDrB9EfSxs6ZMc1ivUgnJph3 = UjyTu7OdN5X1rKhq(u"ࠧࡣ࡮ࡤࡧࡰࡲࡩࡴࡶࠪࡗ") if cjdyhqEa4R9epQXUSLizTJ else VzDtWQ93eOLNmiMc1aqnYrdG6w(u"ࠨࡷࡳࡨࡦࡺࡥࡠࡴࡸࡰࡪࡹࠧࡘ")
	try:
		import sqlite3 as A4sXGi5QcVfy86ZIUJ7OpLxqYv
		KK0vbn4N1otsyi = A4sXGi5QcVfy86ZIUJ7OpLxqYv.connect(AA0WSNpuFnxrich7qa)
		KK0vbn4N1otsyi.text_factory = str
		j2jWNX8k6QbpD = KK0vbn4N1otsyi.cursor()
		j2jWNX8k6QbpD.execute(kR1DV3eCSiAoc(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡲࡶ࡮࡭ࡩ࡯ࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨ࡙ࠧ")+EFYwqgCNmGdrRH4yS61ZIj+R6UW7rjcLz(u"ࠪࠦࠥࡁ࡚ࠧ"))
		LIxjh2lC5nNR6aAboveQMtSm94z = j2jWNX8k6QbpD.fetchall()
		if LIxjh2lC5nNR6aAboveQMtSm94z and Txcdz2YP5wSMEvXaZ4u not in str(LIxjh2lC5nNR6aAboveQMtSm94z): j2jWNX8k6QbpD.execute(nPIvBxHVDyhQ7fzRl(u"࡚ࠫࡖࡄࡂࡖࡈࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡔࡇࡗࠤࡴࡸࡩࡨ࡫ࡱࠤࡂࠦࠢࠨ࡛")+Txcdz2YP5wSMEvXaZ4u+HQ2fNJyt4nr1e(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ࡜")+EFYwqgCNmGdrRH4yS61ZIj+Jy71gvbcDQNHzBjEXkY3lP9(u"࠭ࠢࠡ࠽ࠪ࡝"))
		j2jWNX8k6QbpD.execute(WGx2ZLSntviYBUgOQHFTK(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࠨ࡞")+oYwDrB9EfSxs6ZMc1ivUgnJph3+JmOncNUQdKw3rj7LCsxlzRuZqbHP(u"ࠨ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭࡟")+EFYwqgCNmGdrRH4yS61ZIj+cctO50YQ1f(u"ࠩࠥࠤࡀ࠭ࡠ"))
		LIxjh2lC5nNR6aAboveQMtSm94z = j2jWNX8k6QbpD.fetchall()
		okm9Edfpgbj50Dn6wcqQyZ = D0DtPze5lgTkLrJSmGs1(u"ࡈࡤࡰࡸ࡫ࣗ") if LIxjh2lC5nNR6aAboveQMtSm94z else VIjeMAbrmxN80fX(u"ࡕࡴࡸࡩࣖ")
		if not okm9Edfpgbj50Dn6wcqQyZ and WGx2ZLSntviYBUgOQHFTK(u"ࠪࡩࡳࡧࡢ࡭ࡧࠪࡡ") in GFHpATum5j2sqzVIDWMhYZUr1X697K: j2jWNX8k6QbpD.execute(espLXqowxWQ6g3HJl7V2hRzcvZ(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠪࡢ")+oYwDrB9EfSxs6ZMc1ivUgnJph3+h68nRKy0xsLafj59pw7MQimEHcXgB(u"ࠬࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪࡣ")+EFYwqgCNmGdrRH4yS61ZIj+A8Mz3RINKbBPrkdW7J(u"࠭ࠢࠡ࠽ࠪࡤ"))
		elif okm9Edfpgbj50Dn6wcqQyZ and JmOncNUQdKw3rj7LCsxlzRuZqbHP(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࠨࡥ") in GFHpATum5j2sqzVIDWMhYZUr1X697K:
			if cjdyhqEa4R9epQXUSLizTJ: j2jWNX8k6QbpD.execute(VzDtWQ93eOLNmiMc1aqnYrdG6w(u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠧࡦ")+oYwDrB9EfSxs6ZMc1ivUgnJph3+tt5djKRw0eU3lHQ7zXrgh9A(u"ࠩࠣࠬࡦࡪࡤࡰࡰࡌࡈ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩࡧ")+EFYwqgCNmGdrRH4yS61ZIj+UjyTu7OdN5X1rKhq(u"ࠪࠦ࠮ࠦ࠻ࠨࡨ"))
			else: j2jWNX8k6QbpD.execute(kR1DV3eCSiAoc(u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠪࡩ")+oYwDrB9EfSxs6ZMc1ivUgnJph3+D0DtPze5lgTkLrJSmGs1(u"ࠬࠦࠨࡢࡦࡧࡳࡳࡏࡄ࠭ࡷࡳࡨࡦࡺࡥࡓࡷ࡯ࡩ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩࡪ")+EFYwqgCNmGdrRH4yS61ZIj+pA32bf4OYgTs18GxkqhyFMUHrzWcEo(u"࠭ࠢ࠭࠳ࠬࠤࡀ࠭࡫"))
		KK0vbn4N1otsyi.commit()
		KK0vbn4N1otsyi.close()
		CNBReblmPLjsOAHUrkSq = nPIvBxHVDyhQ7fzRl(u"ࡗࡶࡺ࡫ࣘ")
	except: pass
	if CNBReblmPLjsOAHUrkSq:
		w8wihmupIJTgXOjqLrGdE3k0.sleep(oJDrWBS1nd2HbLOcmZUfjw9hF6tV(u"࠵ࢽ"))
		yn562EIqXglZ8uMCm1.executebuiltin(u6fbnELOkBj(u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫ࡬"))
		w8wihmupIJTgXOjqLrGdE3k0.sleep(XmoF6zpEyA02(u"࠶ࢾ"))
		kPzAxbnJdW(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,VIjeMAbrmxN80fX(u"ࠨฮํำࠥ࠴࠮่ࠡฯัฯࠦวๅ฻่่๏ฯࠧ࡭"))
	else: kPzAxbnJdW(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,oJDrWBS1nd2HbLOcmZUfjw9hF6tV(u"ࠩ็่ศูแࠡ࠰࠱ࠤๆฺไหࠢส่฾๋ไ๋หࠪ࡮"))
	return
def dtmqI7jwBNGfkEgo05FPlu():
	c1G6VaLyqY = llprkZsqYh(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,nPIvBxHVDyhQ7fzRl(u"ࠪ฽๊๊๊สࠢอ๊฽๐แࠡๅ๋ำ๏ࠦสห็ࠣฬู๊อࠡษ็้้็วหࠢส่็ี๊ๆหࠣห้๋ฤใฬฬࠤฬ๊ส๋่ࠢฮัู๋สࠢไ๎๋ࠥฬๅัสฮࠥ๎ๅๅใสฮ้่ࠥะ์ࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠห่฻๎ๆࠦใ้ัํࠤฬ๊ย็ࠢยࠥࠬ࡯"))
	if c1G6VaLyqY!=kR1DV3eCSiAoc(u"࠷ࢿ"): return
	hmBb4uIOwETnMRCe5aykftzVG = pVsCIAjqBneGwh5fEWHTFO3c(znhEJMr6Hbx,h68nRKy0xsLafj59pw7MQimEHcXgB(u"࡙ࡸࡵࡦࣚ"),hhUAB3jynr2apH(u"ࡊࡦࡲࡳࡦࣙ"),hhUAB3jynr2apH(u"ࡊࡦࡲࡳࡦࣙ"))
	NNui0ATnH7xUqDjPE5FKWocQVveI4Y = pVsCIAjqBneGwh5fEWHTFO3c(SSI5uG81BdQ2tfxEps,hNSxcWr5eb6JFklO2vDoptPULIQn(u"ࡔࡳࡷࡨࣜ"),WGx2ZLSntviYBUgOQHFTK(u"ࡌࡡ࡭ࡵࡨࣛ"),WGx2ZLSntviYBUgOQHFTK(u"ࡌࡡ࡭ࡵࡨࣛ"))
	G9au1yK8MROEkW = pVsCIAjqBneGwh5fEWHTFO3c(k2ReQbOxs7ZPMuUznH,Jy71gvbcDQNHzBjEXkY3lP9(u"ࡖࡵࡹࡪࣞ"),hNSxcWr5eb6JFklO2vDoptPULIQn(u"ࡇࡣ࡯ࡷࡪࣝ"),hNSxcWr5eb6JFklO2vDoptPULIQn(u"ࡇࡣ࡯ࡷࡪࣝ"))
	CCk6tbIzYqVraZJunELxi1g8 = mOxort5QYwIqCZn1T7MSF(nPIvBxHVDyhQ7fzRl(u"ࡗࡶࡺ࡫ࣟ"))
	L8A9r2vVTKOHQswFnG1ihJz = JNtn63uDmGRYBeyaqQSW7CV9T()
	CNBReblmPLjsOAHUrkSq = all([hmBb4uIOwETnMRCe5aykftzVG,NNui0ATnH7xUqDjPE5FKWocQVveI4Y,G9au1yK8MROEkW,CCk6tbIzYqVraZJunELxi1g8,L8A9r2vVTKOHQswFnG1ihJz])
	if CNBReblmPLjsOAHUrkSq: kPzAxbnJdW(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,WGx2ZLSntviYBUgOQHFTK(u"ࠫั๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡฬ้฼๏็ࠠไ๊า๎ࠬࡰ"))
	else: kPzAxbnJdW(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,kR1DV3eCSiAoc(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣ็ํี๊ࠨࡱ"))
	return
def JJIS37PxcAoXq0KRuglDL():
	c1G6VaLyqY = llprkZsqYh(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,nPIvBxHVDyhQ7fzRl(u"ู࠭ๆๆํอࠥะๆู์ไࠤฬ๊ฬ่ษีࠤฯะๅࠡส่ืาࠦวๅ็็ๅฬะࠠศๆๅำ๏๋ษࠡษ็้ษ่สสࠢส่ฯ๐ࠠๆฬฯ้฾ฯࠠโ์๊ࠣ฽อๅࠡฬื฾๏๊ࠠศๆฯ๋ฬุࠠ࠯࠰๋้ࠣࠦสา์าࠤฯ์ุ๋ใࠣห้า็ศิࠣห้ศๆࠡมࠤࠫࡲ"))
	if c1G6VaLyqY!=tt5djKRw0eU3lHQ7zXrgh9A(u"࠱ࣀ"): return
	i3tBS5aWNP2kxsGnD0U4R = oJDrWBS1nd2HbLOcmZUfjw9hF6tV(u"ࠧ࠰ࡦࡤࡸࡦ࠵ࡳࡺࡵࡷࡩࡲ࠵ࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠪࡳ")
	QxOtjLYFnIcih2 = jzYpMnA9b1cIOVfa7DT4wRSo(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡴࡻࡶࡸࡪࡳ࠯ࡥࡴࡲࡴࡧࡵࡸࠨࡴ")
	RHNw3LcCIQba1tGWuV4yxZsiqj69Eg = JmOncNUQdKw3rj7LCsxlzRuZqbHP(u"ࠩ࠲ࡨࡦࡺࡡ࠰ࡶࡲࡱࡧࡹࡴࡰࡰࡨࡷࠬࡵ")
	JNC9lGvQAYh75SgxoPBc2mUM = UjyTu7OdN5X1rKhq(u"ࠪ࠳ࡩࡧࡴࡢ࠱࡯ࡳ࡬࡭ࡥࡳࠩࡶ")
	FFPHh1ltTW5qrm84wNbsvUnu = rVZencBlLS3X(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡰࡴ࡭ࠧࡷ")
	vCfdlrDxnu5w = JmOncNUQdKw3rj7LCsxlzRuZqbHP(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡦࡴࡲࠨࡸ")
	hmBb4uIOwETnMRCe5aykftzVG = pVsCIAjqBneGwh5fEWHTFO3c(i3tBS5aWNP2kxsGnD0U4R,pA32bf4OYgTs18GxkqhyFMUHrzWcEo(u"࡙ࡸࡵࡦ࣡"),cctO50YQ1f(u"ࡊࡦࡲࡳࡦ࣠"),cctO50YQ1f(u"ࡊࡦࡲࡳࡦ࣠"))
	NNui0ATnH7xUqDjPE5FKWocQVveI4Y = pVsCIAjqBneGwh5fEWHTFO3c(QxOtjLYFnIcih2,z8zfSJEeGV(u"ࡔࡳࡷࡨࣣ"),TTXke6j4fzZ9cSULM0RhpEKx(u"ࡌࡡ࡭ࡵࡨ࣢"),TTXke6j4fzZ9cSULM0RhpEKx(u"ࡌࡡ࡭ࡵࡨ࣢"))
	G9au1yK8MROEkW = pVsCIAjqBneGwh5fEWHTFO3c(RHNw3LcCIQba1tGWuV4yxZsiqj69Eg,MXfjqwL8KVtT(u"ࡖࡵࡹࡪࣥ"),WGx2ZLSntviYBUgOQHFTK(u"ࡇࡣ࡯ࡷࡪࣤ"),WGx2ZLSntviYBUgOQHFTK(u"ࡇࡣ࡯ࡷࡪࣤ"))
	CCk6tbIzYqVraZJunELxi1g8 = pVsCIAjqBneGwh5fEWHTFO3c(JNC9lGvQAYh75SgxoPBc2mUM,pA32bf4OYgTs18GxkqhyFMUHrzWcEo(u"ࡘࡷࡻࡥࣧ"),HQ2fNJyt4nr1e(u"ࡉࡥࡱࡹࡥࣦ"),HQ2fNJyt4nr1e(u"ࡉࡥࡱࡹࡥࣦ"))
	L8A9r2vVTKOHQswFnG1ihJz = pVsCIAjqBneGwh5fEWHTFO3c(FFPHh1ltTW5qrm84wNbsvUnu,hhUAB3jynr2apH(u"࡚ࡲࡶࡧࣩ"),u6fbnELOkBj(u"ࡋࡧ࡬ࡴࡧࣨ"),u6fbnELOkBj(u"ࡋࡧ࡬ࡴࡧࣨ"))
	dEIXCzgD0u1ZhJstOa5 = pVsCIAjqBneGwh5fEWHTFO3c(vCfdlrDxnu5w,JmOncNUQdKw3rj7LCsxlzRuZqbHP(u"ࡕࡴࡸࡩ࣫"),h68nRKy0xsLafj59pw7MQimEHcXgB(u"ࡆࡢ࡮ࡶࡩ࣪"),h68nRKy0xsLafj59pw7MQimEHcXgB(u"ࡆࡢ࡮ࡶࡩ࣪"))
	CNBReblmPLjsOAHUrkSq = all([hmBb4uIOwETnMRCe5aykftzVG,NNui0ATnH7xUqDjPE5FKWocQVveI4Y,G9au1yK8MROEkW,CCk6tbIzYqVraZJunELxi1g8,L8A9r2vVTKOHQswFnG1ihJz,dEIXCzgD0u1ZhJstOa5])
	if CNBReblmPLjsOAHUrkSq: kPzAxbnJdW(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,qPB07jCaX4fI1VSi58o(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หࠣฮ๋฾๊โࠢส่ัํวำࠩࡹ"))
	else: kPzAxbnJdW(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,HQ2fNJyt4nr1e(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦส็ฺํๅࠥอไอ้สึࠬࡺ"))
	return
def mOxort5QYwIqCZn1T7MSF(LLFkfBCTHA):
	CNBReblmPLjsOAHUrkSq = PT3EozVtWF6O1XfrLcDBMIKmh(u"ࡖࡵࡹࡪ࣬")
	if LLFkfBCTHA:
		c1G6VaLyqY = llprkZsqYh(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,qPB07jCaX4fI1VSi58o(u"ࠨ้็ࠤฯื๊ะ่ࠢืาࠦๅฮฬ๋๎ฬะࠠๆๆไࠤฺ๎ัࠡษ็ะ้ีࠠภࠣࠤࠫࡻ"))
		if c1G6VaLyqY!=WGx2ZLSntviYBUgOQHFTK(u"࠲ࣁ"): return
	try:
		import sqlite3 as A4sXGi5QcVfy86ZIUJ7OpLxqYv
		MME2Hx3p1LQ = A4sXGi5QcVfy86ZIUJ7OpLxqYv.connect(j5BAJncoKRgWHS64sN7MF)
		MME2Hx3p1LQ.text_factory = str
		j2jWNX8k6QbpD = MME2Hx3p1LQ.cursor()
		j2jWNX8k6QbpD.execute(R6UW7rjcLz(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࡱࡣࡷ࡬ࡀ࠭ࡼ"))
		j2jWNX8k6QbpD.execute(y8JsFwe7nZhcoV(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࡵ࡬ࡾࡪࡹ࠻ࠨࡽ"))
		j2jWNX8k6QbpD.execute(VzDtWQ93eOLNmiMc1aqnYrdG6w(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡷࡩࡽࡺࡵࡳࡧ࠾ࠫࡾ"))
		MME2Hx3p1LQ.commit()
		j2jWNX8k6QbpD.execute(tt5djKRw0eU3lHQ7zXrgh9A(u"ࠬ࡜ࡁࡄࡗࡘࡑࡀ࠭ࡿ"))
		MME2Hx3p1LQ.close()
	except: CNBReblmPLjsOAHUrkSq = A8Mz3RINKbBPrkdW7J(u"ࡉࡥࡱࡹࡥ࣭")
	if LLFkfBCTHA and CNBReblmPLjsOAHUrkSq: kPzAxbnJdW(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,A8Mz3RINKbBPrkdW7J(u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧࢀ"))
	return CNBReblmPLjsOAHUrkSq
def JNtn63uDmGRYBeyaqQSW7CV9T():
	CNBReblmPLjsOAHUrkSq = jzYpMnA9b1cIOVfa7DT4wRSo(u"ࡘࡷࡻࡥ࣮")
	for file in KKaTeP8NnIjkwcAQDMuRyYUBmgG.listdir(PEWnOU3jmLAa8):
		if kR1DV3eCSiAoc(u"ࠧ࡬ࡱࡧ࡭ࡤࡹࡴࡢࡥ࡮ࡸࡷࡧࡣࡦࠩࢁ") not in file or pA32bf4OYgTs18GxkqhyFMUHrzWcEo(u"ࠨ࡭ࡲࡨ࡮ࡥࡣࡳࡣࡶ࡬ࡱࡵࡧࠨࢂ") not in file: continue
		loujKk9NMzS4CcTOWpsLnUIaG7E = KKaTeP8NnIjkwcAQDMuRyYUBmgG.path.join(PEWnOU3jmLAa8,file)
		try:
			KKaTeP8NnIjkwcAQDMuRyYUBmgG.remove(loujKk9NMzS4CcTOWpsLnUIaG7E)
		except Exception as qq27LCR5ngKZPWG:
			CNBReblmPLjsOAHUrkSq = qPB07jCaX4fI1VSi58o(u"ࡋࡧ࡬ࡴࡧ࣯")
			if LLFkfBCTHA and CNBReblmPLjsOAHUrkSq: kPzAxbnJdW(yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,yyYJ7pLMrOxz6mE82AH0,str(qq27LCR5ngKZPWG))
	return CNBReblmPLjsOAHUrkSq
jQY4yCeI3fZgJ710NHshV5w(hNSxcWr5eb6JFklO2vDoptPULIQn(u"ࠩࡶࡸࡦࡸࡴࠨࢃ"))
oorwzjA3d95IbevTZ1nqyktX = pKa1u0TlfjDmGNicsJA5.argv[TTXke6j4fzZ9cSULM0RhpEKx(u"࠳ࣂ")]
EFYwqgCNmGdrRH4yS61ZIj = Jy71gvbcDQNHzBjEXkY3lP9(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨࢄ")
yyOcWCZ83TdDPibQl = yn562EIqXglZ8uMCm1.getInfoLabel(XmoF6zpEyA02(u"ࠦࡘࡿࡳࡵࡧࡰ࠲ࡇࡻࡩ࡭ࡦ࡙ࡩࡷࡹࡩࡰࡰࠥࢅ"))
C8XBp5Tzf9DVxygIq6 = cRItOw7Ed8KJZjTeCoSLz4156FAx.findall(PT3EozVtWF6O1XfrLcDBMIKmh(u"ࠬ࠮࡜ࡥ࡞ࡧࡠ࠳ࡢࡤࠪࠩࢆ"),yyOcWCZ83TdDPibQl,cRItOw7Ed8KJZjTeCoSLz4156FAx.DOTALL)
C8XBp5Tzf9DVxygIq6 = float(C8XBp5Tzf9DVxygIq6[HQ2fNJyt4nr1e(u"࠳ࣃ")])
cjdyhqEa4R9epQXUSLizTJ = C8XBp5Tzf9DVxygIq6<XmoF6zpEyA02(u"࠵࠾ࣄ")
pvoEDjklVb1W6n = C8XBp5Tzf9DVxygIq6>tt5djKRw0eU3lHQ7zXrgh9A(u"࠶࠾࠮࠺࠻ࣅ")
if pvoEDjklVb1W6n:
	PEWnOU3jmLAa8 = dQGhZfVFoLkTRAX6EJIK1g.translatePath(R6UW7rjcLz(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡯ࡳ࡬ࡶࡡࡵࡪࠪࢇ"))
	CgvDmRZxV5zaSJUBI = dQGhZfVFoLkTRAX6EJIK1g.translatePath(PT3EozVtWF6O1XfrLcDBMIKmh(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨ࢈"))
	GeJAWzH5u2OsNdohI = dQGhZfVFoLkTRAX6EJIK1g.translatePath(PT3EozVtWF6O1XfrLcDBMIKmh(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡹ࡫࡭ࡱࠩࢉ"))
	AA0WSNpuFnxrich7qa = KKaTeP8NnIjkwcAQDMuRyYUBmgG.path.join(CgvDmRZxV5zaSJUBI,R6UW7rjcLz(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫࢊ"),z8zfSJEeGV(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬࢋ"),D0DtPze5lgTkLrJSmGs1(u"ࠫࡆࡪࡤࡰࡰࡶ࠷࠸࠴ࡤࡣࠩࢌ"))
else:
	PEWnOU3jmLAa8 = yn562EIqXglZ8uMCm1.translatePath(JmOncNUQdKw3rj7LCsxlzRuZqbHP(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩࢍ"))
	CgvDmRZxV5zaSJUBI = yn562EIqXglZ8uMCm1.translatePath(MXfjqwL8KVtT(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧࢎ"))
	GeJAWzH5u2OsNdohI = yn562EIqXglZ8uMCm1.translatePath(Jy71gvbcDQNHzBjEXkY3lP9(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡸࡪࡳࡰࠨ࢏"))
	AA0WSNpuFnxrich7qa = KKaTeP8NnIjkwcAQDMuRyYUBmgG.path.join(CgvDmRZxV5zaSJUBI,VIjeMAbrmxN80fX(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ࢐"),XmoF6zpEyA02(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ࢑"),XmoF6zpEyA02(u"ࠪࡅࡩࡪ࡯࡯ࡵ࠵࠻࠳ࡪࡢࠨ࢒"))
gpuJWKFMRL2lZYtwjm0d = KKaTeP8NnIjkwcAQDMuRyYUBmgG.path.join(CgvDmRZxV5zaSJUBI,jzYpMnA9b1cIOVfa7DT4wRSo(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭࢓"),pA32bf4OYgTs18GxkqhyFMUHrzWcEo(u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ࢔"),EFYwqgCNmGdrRH4yS61ZIj)
Y8vekg6CoNqQUAhDfx7JtBP = KKaTeP8NnIjkwcAQDMuRyYUBmgG.path.join(gpuJWKFMRL2lZYtwjm0d,z8zfSJEeGV(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ࢕"))
vvFWsm1AJt8fxZ0nuMpodalBO = KKaTeP8NnIjkwcAQDMuRyYUBmgG.path.join(GeJAWzH5u2OsNdohI,EFYwqgCNmGdrRH4yS61ZIj)
k2ReQbOxs7ZPMuUznH = KKaTeP8NnIjkwcAQDMuRyYUBmgG.path.join(CgvDmRZxV5zaSJUBI,kR1DV3eCSiAoc(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ࢖"),kR1DV3eCSiAoc(u"ࠨࡖ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࢗ"))
QPcrkCOgHGqEyxBL0 = KKaTeP8NnIjkwcAQDMuRyYUBmgG.path.join(CgvDmRZxV5zaSJUBI,jzYpMnA9b1cIOVfa7DT4wRSo(u"ࠩࡤࡨࡩࡵ࡮ࡴࠩ࢘"))
HDjbFfVRg8 = KKaTeP8NnIjkwcAQDMuRyYUBmgG.path.join(QPcrkCOgHGqEyxBL0,EFYwqgCNmGdrRH4yS61ZIj)
znhEJMr6Hbx = KKaTeP8NnIjkwcAQDMuRyYUBmgG.path.join(QPcrkCOgHGqEyxBL0,hhUAB3jynr2apH(u"ࠪࡸࡪࡳࡰࠨ࢙"))
SSI5uG81BdQ2tfxEps = KKaTeP8NnIjkwcAQDMuRyYUBmgG.path.join(QPcrkCOgHGqEyxBL0,tt5djKRw0eU3lHQ7zXrgh9A(u"ࠫࡵࡧࡣ࡬ࡣࡪࡩࡸ࢚࠭"))
j5BAJncoKRgWHS64sN7MF = KKaTeP8NnIjkwcAQDMuRyYUBmgG.path.join(CgvDmRZxV5zaSJUBI,kR1DV3eCSiAoc(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧ࢛ࠧ"),UjyTu7OdN5X1rKhq(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ࢜"),UjyTu7OdN5X1rKhq(u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧ࢝"))
ryWuQdm4zjxGc9 = KKaTeP8NnIjkwcAQDMuRyYUBmgG.path.join(vvFWsm1AJt8fxZ0nuMpodalBO,Jy71gvbcDQNHzBjEXkY3lP9(u"ࠨ࡫ࡰࡥ࡬࡫ࡳࠨ࢞"))
REBjAGYXDP74gntbdOU2S = KKaTeP8NnIjkwcAQDMuRyYUBmgG.path.join(PEWnOU3jmLAa8,u6fbnELOkBj(u"ࠩ࡮ࡳࡩ࡯࠮࡭ࡱࡪࠫ࢟"))
FsXaNr5KnMwt24 = KKaTeP8NnIjkwcAQDMuRyYUBmgG.path.join(PEWnOU3jmLAa8,kR1DV3eCSiAoc(u"ࠪ࡯ࡴࡪࡩ࠯ࡱ࡯ࡨ࠳ࡲ࡯ࡨࠩࢠ"))
if   oorwzjA3d95IbevTZ1nqyktX==h68nRKy0xsLafj59pw7MQimEHcXgB(u"ࠫࡸ࡫࡮ࡥࡡ࡯ࡳ࡬࡬ࡩ࡭ࡧࠪࢡ")		: ooFVGs1PRH3dXM(REBjAGYXDP74gntbdOU2S)
elif oorwzjA3d95IbevTZ1nqyktX==pA32bf4OYgTs18GxkqhyFMUHrzWcEo(u"ࠬࡹࡥ࡯ࡦࡢࡳࡱࡪ࡟࡭ࡱࡪࡪ࡮ࡲࡥࠨࢢ")	: ooFVGs1PRH3dXM(FsXaNr5KnMwt24)
elif oorwzjA3d95IbevTZ1nqyktX==TTXke6j4fzZ9cSULM0RhpEKx(u"࠭ࡤࡦ࡮ࡨࡸࡪࡥࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠨࢣ")		: FwYqVOp6tuG2Ay8KhUJrH3TiD()
elif oorwzjA3d95IbevTZ1nqyktX==hNSxcWr5eb6JFklO2vDoptPULIQn(u"ࠧࡥࡧ࡯ࡩࡹ࡫࡟ࡤࡣࡦ࡬ࡪ࠭ࢤ")		: ZAVHj2Wku6Rfyl5KaNoxB49()
elif oorwzjA3d95IbevTZ1nqyktX==Jy71gvbcDQNHzBjEXkY3lP9(u"ࠨࡥ࡯ࡩࡦࡴ࡟࡬ࡱࡧ࡭ࠬࢥ")			: dtmqI7jwBNGfkEgo05FPlu()
elif oorwzjA3d95IbevTZ1nqyktX==XmoF6zpEyA02(u"ࠩࡦࡰࡪࡧ࡮ࡠࡦࡨࡺ࡮ࡩࡥࡠࡱࡶࠫࢦ")		: JJIS37PxcAoXq0KRuglDL()
elif oorwzjA3d95IbevTZ1nqyktX==A8Mz3RINKbBPrkdW7J(u"ࠪ࡭ࡳࡹࡴࡢ࡮࡯ࡣࡴࡲࡤࡠࡸࡨࡶࡸ࡯࡯࡯ࠩࢧ")	: UkgEiFeR1dDO4()
elif oorwzjA3d95IbevTZ1nqyktX==u6fbnELOkBj(u"ࠫࡲࡵࡤࡪࡨࡼࡣࡦࡻࡴࡰࡷࡳࡨࡦࡺࡥࠨࢨ")	: kE4WBAutlo5CYSL7bwDrRF1()
elif oorwzjA3d95IbevTZ1nqyktX==WGx2ZLSntviYBUgOQHFTK(u"ࠬࡪࡥ࡭ࡧࡷࡩࡤࡳࡥ࡯ࡷࡶࡣ࡮ࡳࡡࡨࡧࡶࠫࢩ")	: Q2zS7ek3ZmqrUduPEo4twgi0K()
jQY4yCeI3fZgJ710NHshV5w(D0DtPze5lgTkLrJSmGs1(u"࠭ࡳࡵࡱࡳࠫࢪ"))
# -*- coding: utf-8 -*-
from pR2X91txEm import *
kNfc1ZX0HTKjpQImqiuy49g85G7UVa = 'FAVORITES'
def etoUZjTVky8ru7c(knBV0UPuCNdpIsAFH3coRKjh2lb,UUfxjiV7N4kSM95ocqd):
	if   knBV0UPuCNdpIsAFH3coRKjh2lb==270: ZLzmkuhti3vloIPnB9qcUya = q89q14REt7fG0KsrdymbHiNCVkax(UUfxjiV7N4kSM95ocqd)
	else: ZLzmkuhti3vloIPnB9qcUya = False
	return ZLzmkuhti3vloIPnB9qcUya
def z2sJc7NoDZhGTqkHWCSxf(qjyki7XR1FW,UUfxjiV7N4kSM95ocqd,EhO3Y25mozpUek1gVGICWQJ):
	if not qjyki7XR1FW: return
	if   EhO3Y25mozpUek1gVGICWQJ=='UP1'	: y58I2FWbQRXc3xTN1(UUfxjiV7N4kSM95ocqd,True,UnOIK1WBbw2)
	elif EhO3Y25mozpUek1gVGICWQJ=='DOWN1'	: y58I2FWbQRXc3xTN1(UUfxjiV7N4kSM95ocqd,False,UnOIK1WBbw2)
	elif EhO3Y25mozpUek1gVGICWQJ=='UP4'	: y58I2FWbQRXc3xTN1(UUfxjiV7N4kSM95ocqd,True,tpMX1Bgs0bzv8OEafyW)
	elif EhO3Y25mozpUek1gVGICWQJ=='DOWN4'	: y58I2FWbQRXc3xTN1(UUfxjiV7N4kSM95ocqd,False,tpMX1Bgs0bzv8OEafyW)
	elif EhO3Y25mozpUek1gVGICWQJ=='ADD1'	: BpRXcH8Wy7Urj(UUfxjiV7N4kSM95ocqd)
	elif EhO3Y25mozpUek1gVGICWQJ=='REMOVE1': QxlJhb3Nd2WZ5Y7CIvy(UUfxjiV7N4kSM95ocqd)
	elif EhO3Y25mozpUek1gVGICWQJ=='DELETELIST': iSNg9y6ojeK3QUnF4kBfP(UUfxjiV7N4kSM95ocqd)
	return
def q89q14REt7fG0KsrdymbHiNCVkax(UUfxjiV7N4kSM95ocqd):
	sLDEVGlgWtnz = yTZ8tkWLshpjMK1fJ()
	if UUfxjiV7N4kSM95ocqd in list(sLDEVGlgWtnz.keys()):
		try:
			MimStu7GRYH96zDP58JBqe3 = sLDEVGlgWtnz[UUfxjiV7N4kSM95ocqd]
			if IpFcwrWNgefMym3qta0hYQAzOdE and UUfxjiV7N4kSM95ocqd in ['5','11','12','13']:
				for WTavfhd7QJDABwpIVrZqHL,w8cPT5nhW2RUAFKDa,kOTdpYrPqu5A7UIcW0Ch,knBV0UPuCNdpIsAFH3coRKjh2lb,czMOJaKwoCnSPuNTd9bIH8pfLy72W5,QbuYlX5ctHaGp42jNef8,OOrjZaTIVXQ2Sp0ozhc,qjyki7XR1FW,Gv80f9tpWiRL in MimStu7GRYH96zDP58JBqe3:
					if WTavfhd7QJDABwpIVrZqHL=='video':
						TBt8bUDo9WhL('video',bbTCMJwEx8nhN4X+'تشغيل من الأعلى إلى الأسفل'+NwROdSj3nsA,kOTdpYrPqu5A7UIcW0Ch,knBV0UPuCNdpIsAFH3coRKjh2lb,czMOJaKwoCnSPuNTd9bIH8pfLy72W5,QbuYlX5ctHaGp42jNef8,OOrjZaTIVXQ2Sp0ozhc,qjyki7XR1FW)
						TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
						break
			for WTavfhd7QJDABwpIVrZqHL,w8cPT5nhW2RUAFKDa,kOTdpYrPqu5A7UIcW0Ch,knBV0UPuCNdpIsAFH3coRKjh2lb,czMOJaKwoCnSPuNTd9bIH8pfLy72W5,QbuYlX5ctHaGp42jNef8,OOrjZaTIVXQ2Sp0ozhc,qjyki7XR1FW,Gv80f9tpWiRL in MimStu7GRYH96zDP58JBqe3:
				TBt8bUDo9WhL(WTavfhd7QJDABwpIVrZqHL,w8cPT5nhW2RUAFKDa,kOTdpYrPqu5A7UIcW0Ch,knBV0UPuCNdpIsAFH3coRKjh2lb,czMOJaKwoCnSPuNTd9bIH8pfLy72W5,QbuYlX5ctHaGp42jNef8,OOrjZaTIVXQ2Sp0ozhc,qjyki7XR1FW,Gv80f9tpWiRL)
		except:
			sLDEVGlgWtnz = x1ibKhuTya7w3I589OcoEBAN(RihlJwXFNfe1IGPu9ZcUg85qsdn)
			MimStu7GRYH96zDP58JBqe3 = sLDEVGlgWtnz[UUfxjiV7N4kSM95ocqd]
			for WTavfhd7QJDABwpIVrZqHL,w8cPT5nhW2RUAFKDa,kOTdpYrPqu5A7UIcW0Ch,knBV0UPuCNdpIsAFH3coRKjh2lb,czMOJaKwoCnSPuNTd9bIH8pfLy72W5,QbuYlX5ctHaGp42jNef8,OOrjZaTIVXQ2Sp0ozhc,qjyki7XR1FW,Gv80f9tpWiRL in MimStu7GRYH96zDP58JBqe3:
				TBt8bUDo9WhL(WTavfhd7QJDABwpIVrZqHL,w8cPT5nhW2RUAFKDa,kOTdpYrPqu5A7UIcW0Ch,knBV0UPuCNdpIsAFH3coRKjh2lb,czMOJaKwoCnSPuNTd9bIH8pfLy72W5,QbuYlX5ctHaGp42jNef8,OOrjZaTIVXQ2Sp0ozhc,qjyki7XR1FW,Gv80f9tpWiRL)
	return
def BpRXcH8Wy7Urj(UUfxjiV7N4kSM95ocqd):
	WTavfhd7QJDABwpIVrZqHL,w8cPT5nhW2RUAFKDa,kOTdpYrPqu5A7UIcW0Ch,knBV0UPuCNdpIsAFH3coRKjh2lb,czMOJaKwoCnSPuNTd9bIH8pfLy72W5,QbuYlX5ctHaGp42jNef8,OOrjZaTIVXQ2Sp0ozhc,qjyki7XR1FW,Gv80f9tpWiRL = boLfu8ilHFRek4ECO9GZ(dWHUYEKD6hA)
	if UUfxjiV7N4kSM95ocqd in ['5','11','12','13'] and WTavfhd7QJDABwpIVrZqHL!='video':
		OmxJV4UQyeFqdBSIC0('','',OksCHeoL5SG,'هذا العنصر ليس ملف فيديو .. قوائم التشغيل فائدتها تشغيل الفيديوهات خلف بعضها أوتوماتيكيا .. ولهذا قوائم التشغيل يجب أن تحتوي على فيديوهات فقط')
		return
	f7K0kyHcnp = WTavfhd7QJDABwpIVrZqHL,w8cPT5nhW2RUAFKDa,kOTdpYrPqu5A7UIcW0Ch,knBV0UPuCNdpIsAFH3coRKjh2lb,czMOJaKwoCnSPuNTd9bIH8pfLy72W5,QbuYlX5ctHaGp42jNef8,OOrjZaTIVXQ2Sp0ozhc,nA5dhMRg6ENzsB0l1GwvH7aIr2,Gv80f9tpWiRL
	sLDEVGlgWtnz = yTZ8tkWLshpjMK1fJ()
	xmPyZYoaEA0Czk5LRrB = {}
	for nHtzJbmXOKFP in list(sLDEVGlgWtnz.keys()):
		if nHtzJbmXOKFP!=UUfxjiV7N4kSM95ocqd: xmPyZYoaEA0Czk5LRrB[nHtzJbmXOKFP] = sLDEVGlgWtnz[nHtzJbmXOKFP]
		else:
			if w8cPT5nhW2RUAFKDa and w8cPT5nhW2RUAFKDa!='..':
				Yo6d5yAQzLWume9hGRqnXkZPKc7 = sLDEVGlgWtnz[nHtzJbmXOKFP]
				if f7K0kyHcnp in Yo6d5yAQzLWume9hGRqnXkZPKc7:
					nlkKARyqhNLaf5xUFsXY = Yo6d5yAQzLWume9hGRqnXkZPKc7.index(f7K0kyHcnp)
					del Yo6d5yAQzLWume9hGRqnXkZPKc7[nlkKARyqhNLaf5xUFsXY]
				Q0rpEj4RmTX2S9uPZ6AVK8C = Yo6d5yAQzLWume9hGRqnXkZPKc7+[f7K0kyHcnp]
				xmPyZYoaEA0Czk5LRrB[nHtzJbmXOKFP] = Q0rpEj4RmTX2S9uPZ6AVK8C
			else: xmPyZYoaEA0Czk5LRrB[nHtzJbmXOKFP] = sLDEVGlgWtnz[nHtzJbmXOKFP]
	if UUfxjiV7N4kSM95ocqd not in list(xmPyZYoaEA0Czk5LRrB.keys()): xmPyZYoaEA0Czk5LRrB[UUfxjiV7N4kSM95ocqd] = [f7K0kyHcnp]
	QwfgWAhPC2uMiBVrDFyvTOJ = str(xmPyZYoaEA0Czk5LRrB)
	if BsLJ7p5Av2Vm0SQeCO1o: QwfgWAhPC2uMiBVrDFyvTOJ = QwfgWAhPC2uMiBVrDFyvTOJ.encode(YWEQ3Cf8RevpD0m7NjF1)
	open(RihlJwXFNfe1IGPu9ZcUg85qsdn,'wb').write(QwfgWAhPC2uMiBVrDFyvTOJ)
	return
def QxlJhb3Nd2WZ5Y7CIvy(UUfxjiV7N4kSM95ocqd):
	WTavfhd7QJDABwpIVrZqHL,w8cPT5nhW2RUAFKDa,kOTdpYrPqu5A7UIcW0Ch,knBV0UPuCNdpIsAFH3coRKjh2lb,czMOJaKwoCnSPuNTd9bIH8pfLy72W5,QbuYlX5ctHaGp42jNef8,OOrjZaTIVXQ2Sp0ozhc,qjyki7XR1FW,Gv80f9tpWiRL = boLfu8ilHFRek4ECO9GZ(dWHUYEKD6hA)
	f7K0kyHcnp = WTavfhd7QJDABwpIVrZqHL,w8cPT5nhW2RUAFKDa,kOTdpYrPqu5A7UIcW0Ch,knBV0UPuCNdpIsAFH3coRKjh2lb,czMOJaKwoCnSPuNTd9bIH8pfLy72W5,QbuYlX5ctHaGp42jNef8,OOrjZaTIVXQ2Sp0ozhc,nA5dhMRg6ENzsB0l1GwvH7aIr2,Gv80f9tpWiRL
	sLDEVGlgWtnz = yTZ8tkWLshpjMK1fJ()
	if UUfxjiV7N4kSM95ocqd in list(sLDEVGlgWtnz.keys()) and f7K0kyHcnp in sLDEVGlgWtnz[UUfxjiV7N4kSM95ocqd]:
		sLDEVGlgWtnz[UUfxjiV7N4kSM95ocqd].remove(f7K0kyHcnp)
		if len(sLDEVGlgWtnz[UUfxjiV7N4kSM95ocqd])==IpFcwrWNgefMym3qta0hYQAzOdE: del sLDEVGlgWtnz[UUfxjiV7N4kSM95ocqd]
		QwfgWAhPC2uMiBVrDFyvTOJ = str(sLDEVGlgWtnz)
		if BsLJ7p5Av2Vm0SQeCO1o: QwfgWAhPC2uMiBVrDFyvTOJ = QwfgWAhPC2uMiBVrDFyvTOJ.encode(YWEQ3Cf8RevpD0m7NjF1)
		open(RihlJwXFNfe1IGPu9ZcUg85qsdn,'wb').write(QwfgWAhPC2uMiBVrDFyvTOJ)
	return
def y58I2FWbQRXc3xTN1(UUfxjiV7N4kSM95ocqd,BDKgLQRGPV8akxqu3F4f5IOiWpw,rIazEL6wFHbe82DGPZud01yiUm):
	WTavfhd7QJDABwpIVrZqHL,w8cPT5nhW2RUAFKDa,kOTdpYrPqu5A7UIcW0Ch,knBV0UPuCNdpIsAFH3coRKjh2lb,czMOJaKwoCnSPuNTd9bIH8pfLy72W5,QbuYlX5ctHaGp42jNef8,OOrjZaTIVXQ2Sp0ozhc,qjyki7XR1FW,Gv80f9tpWiRL = boLfu8ilHFRek4ECO9GZ(dWHUYEKD6hA)
	f7K0kyHcnp = WTavfhd7QJDABwpIVrZqHL,w8cPT5nhW2RUAFKDa,kOTdpYrPqu5A7UIcW0Ch,knBV0UPuCNdpIsAFH3coRKjh2lb,czMOJaKwoCnSPuNTd9bIH8pfLy72W5,QbuYlX5ctHaGp42jNef8,OOrjZaTIVXQ2Sp0ozhc,nA5dhMRg6ENzsB0l1GwvH7aIr2,Gv80f9tpWiRL
	sLDEVGlgWtnz = yTZ8tkWLshpjMK1fJ()
	if UUfxjiV7N4kSM95ocqd in list(sLDEVGlgWtnz.keys()):
		Yo6d5yAQzLWume9hGRqnXkZPKc7 = sLDEVGlgWtnz[UUfxjiV7N4kSM95ocqd]
		if f7K0kyHcnp not in Yo6d5yAQzLWume9hGRqnXkZPKc7: return
		ZKDRACg71pl0VYLbdQEIjTMcanwuzh = len(Yo6d5yAQzLWume9hGRqnXkZPKc7)
		for yFwUm7LgRGa4BhNK6V0SAXedCvMD in range(IpFcwrWNgefMym3qta0hYQAzOdE,rIazEL6wFHbe82DGPZud01yiUm):
			zmPFfGjBHX1exkbRstiqw = Yo6d5yAQzLWume9hGRqnXkZPKc7.index(f7K0kyHcnp)
			if BDKgLQRGPV8akxqu3F4f5IOiWpw: R9rwzkpsNKMADamEnTjIych = zmPFfGjBHX1exkbRstiqw-UnOIK1WBbw2
			else: R9rwzkpsNKMADamEnTjIych = zmPFfGjBHX1exkbRstiqw+UnOIK1WBbw2
			if R9rwzkpsNKMADamEnTjIych>=ZKDRACg71pl0VYLbdQEIjTMcanwuzh: R9rwzkpsNKMADamEnTjIych = R9rwzkpsNKMADamEnTjIych-ZKDRACg71pl0VYLbdQEIjTMcanwuzh
			if R9rwzkpsNKMADamEnTjIych<IpFcwrWNgefMym3qta0hYQAzOdE: R9rwzkpsNKMADamEnTjIych = R9rwzkpsNKMADamEnTjIych+ZKDRACg71pl0VYLbdQEIjTMcanwuzh
			Yo6d5yAQzLWume9hGRqnXkZPKc7.insert(R9rwzkpsNKMADamEnTjIych, Yo6d5yAQzLWume9hGRqnXkZPKc7.pop(zmPFfGjBHX1exkbRstiqw))
		sLDEVGlgWtnz[UUfxjiV7N4kSM95ocqd] = Yo6d5yAQzLWume9hGRqnXkZPKc7
		QwfgWAhPC2uMiBVrDFyvTOJ = str(sLDEVGlgWtnz)
		if BsLJ7p5Av2Vm0SQeCO1o: QwfgWAhPC2uMiBVrDFyvTOJ = QwfgWAhPC2uMiBVrDFyvTOJ.encode(YWEQ3Cf8RevpD0m7NjF1)
		open(RihlJwXFNfe1IGPu9ZcUg85qsdn,'wb').write(QwfgWAhPC2uMiBVrDFyvTOJ)
	return
def uDfPyiIwt0c6CRE4(UUfxjiV7N4kSM95ocqd):
	if UUfxjiV7N4kSM95ocqd in ['1','2','3','4']: rQiYSBmjUlR8ba7F5d9sEh3,PA79j3vmpkZEWoa = 'مفضلة',UUfxjiV7N4kSM95ocqd
	elif UUfxjiV7N4kSM95ocqd in ['5']: rQiYSBmjUlR8ba7F5d9sEh3,PA79j3vmpkZEWoa = 'تشغيل','1'
	elif UUfxjiV7N4kSM95ocqd in ['11']: rQiYSBmjUlR8ba7F5d9sEh3,PA79j3vmpkZEWoa = 'تشغيل','2'
	else: rQiYSBmjUlR8ba7F5d9sEh3,PA79j3vmpkZEWoa = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	HZArKtwGCMoeD3bV5B6JPzQnlXd = rQiYSBmjUlR8ba7F5d9sEh3+hSXlxL9iB05c+PA79j3vmpkZEWoa
	return HZArKtwGCMoeD3bV5B6JPzQnlXd
def iSNg9y6ojeK3QUnF4kBfP(UUfxjiV7N4kSM95ocqd):
	HZArKtwGCMoeD3bV5B6JPzQnlXd = uDfPyiIwt0c6CRE4(UUfxjiV7N4kSM95ocqd)
	dQG457SnHylm1vL = bjyB5J1QuNaIXOx9qSwm4v0edDhg('center',nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'هل تريد فعلا مسح جميع محتويات قائمة '+HZArKtwGCMoeD3bV5B6JPzQnlXd+' ؟!')
	if dQG457SnHylm1vL!=1: return
	sLDEVGlgWtnz = yTZ8tkWLshpjMK1fJ()
	if UUfxjiV7N4kSM95ocqd in list(sLDEVGlgWtnz.keys()):
		del sLDEVGlgWtnz[UUfxjiV7N4kSM95ocqd]
		QwfgWAhPC2uMiBVrDFyvTOJ = str(sLDEVGlgWtnz)
		if BsLJ7p5Av2Vm0SQeCO1o: QwfgWAhPC2uMiBVrDFyvTOJ = QwfgWAhPC2uMiBVrDFyvTOJ.encode(YWEQ3Cf8RevpD0m7NjF1)
		open(RihlJwXFNfe1IGPu9ZcUg85qsdn,'wb').write(QwfgWAhPC2uMiBVrDFyvTOJ)
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'تم مسح جميع محتويات قائمة '+HZArKtwGCMoeD3bV5B6JPzQnlXd)
	return
def yTZ8tkWLshpjMK1fJ():
	sLDEVGlgWtnz = {}
	if XoZRpFe7B6gnfA.path.exists(RihlJwXFNfe1IGPu9ZcUg85qsdn):
		Q891QdEqoNUaCG7YnWAJL5PIvyVBt = open(RihlJwXFNfe1IGPu9ZcUg85qsdn,'rb').read()
		if BsLJ7p5Av2Vm0SQeCO1o: Q891QdEqoNUaCG7YnWAJL5PIvyVBt = Q891QdEqoNUaCG7YnWAJL5PIvyVBt.decode(YWEQ3Cf8RevpD0m7NjF1)
		sLDEVGlgWtnz = BwGPDSQOlfUas2n3eIH0ycFRWZ('dict',Q891QdEqoNUaCG7YnWAJL5PIvyVBt)
	return sLDEVGlgWtnz
def yHmCRPvKgaIOdJnGTf6Dk8N7us0qW9(sLDEVGlgWtnz,f7K0kyHcnp,dRykI4C0DF6VOA9vGjnp1wN):
	WTavfhd7QJDABwpIVrZqHL,w8cPT5nhW2RUAFKDa,kOTdpYrPqu5A7UIcW0Ch,knBV0UPuCNdpIsAFH3coRKjh2lb,czMOJaKwoCnSPuNTd9bIH8pfLy72W5,QbuYlX5ctHaGp42jNef8,OOrjZaTIVXQ2Sp0ozhc,qjyki7XR1FW,Gv80f9tpWiRL = f7K0kyHcnp
	if not knBV0UPuCNdpIsAFH3coRKjh2lb: WTavfhd7QJDABwpIVrZqHL,knBV0UPuCNdpIsAFH3coRKjh2lb = 'folder','260'
	jv52HmXEIJxwpu9Rlc,UUfxjiV7N4kSM95ocqd = [],nA5dhMRg6ENzsB0l1GwvH7aIr2
	if 'context=' in dWHUYEKD6hA:
		tJ7mYpAnqlMSDjUXgQbuHf4NP = PAztbuyYo4Kvd.findall('context=(\d+)',dWHUYEKD6hA,PAztbuyYo4Kvd.DOTALL)
		if tJ7mYpAnqlMSDjUXgQbuHf4NP: UUfxjiV7N4kSM95ocqd = str(tJ7mYpAnqlMSDjUXgQbuHf4NP[IpFcwrWNgefMym3qta0hYQAzOdE])
	if knBV0UPuCNdpIsAFH3coRKjh2lb=='270':
		UUfxjiV7N4kSM95ocqd = qjyki7XR1FW
		if UUfxjiV7N4kSM95ocqd in list(sLDEVGlgWtnz.keys()):
			HZArKtwGCMoeD3bV5B6JPzQnlXd = uDfPyiIwt0c6CRE4(UUfxjiV7N4kSM95ocqd)
			jv52HmXEIJxwpu9Rlc.append(('مسح قائمة '+HZArKtwGCMoeD3bV5B6JPzQnlXd,'RunPlugin('+dRykI4C0DF6VOA9vGjnp1wN+'&context='+UUfxjiV7N4kSM95ocqd+'_DELETELIST'+')'))
	else:
		if UUfxjiV7N4kSM95ocqd in list(sLDEVGlgWtnz.keys()):
			count = len(sLDEVGlgWtnz[UUfxjiV7N4kSM95ocqd])
			if count>UnOIK1WBbw2: jv52HmXEIJxwpu9Rlc.append(('تحريك 1 للأعلى','RunPlugin('+dRykI4C0DF6VOA9vGjnp1wN+'&context='+UUfxjiV7N4kSM95ocqd+'_UP1)'))
			if count>tpMX1Bgs0bzv8OEafyW: jv52HmXEIJxwpu9Rlc.append(('تحريك 4 للأعلى','RunPlugin('+dRykI4C0DF6VOA9vGjnp1wN+'&context='+UUfxjiV7N4kSM95ocqd+'_UP4)'))
			if count>UnOIK1WBbw2: jv52HmXEIJxwpu9Rlc.append(('تحريك 1 للأسفل','RunPlugin('+dRykI4C0DF6VOA9vGjnp1wN+'&context='+UUfxjiV7N4kSM95ocqd+'_DOWN1)'))
			if count>tpMX1Bgs0bzv8OEafyW: jv52HmXEIJxwpu9Rlc.append(('تحريك 4 للأسفل','RunPlugin('+dRykI4C0DF6VOA9vGjnp1wN+'&context='+UUfxjiV7N4kSM95ocqd+'_DOWN4)'))
		for UUfxjiV7N4kSM95ocqd in ['1','2','3','4','5','11']:
			HZArKtwGCMoeD3bV5B6JPzQnlXd = uDfPyiIwt0c6CRE4(UUfxjiV7N4kSM95ocqd)
			if UUfxjiV7N4kSM95ocqd in list(sLDEVGlgWtnz.keys()) and f7K0kyHcnp in sLDEVGlgWtnz[UUfxjiV7N4kSM95ocqd]:
				jv52HmXEIJxwpu9Rlc.append(('مسح من '+HZArKtwGCMoeD3bV5B6JPzQnlXd,'RunPlugin('+dRykI4C0DF6VOA9vGjnp1wN+'&context='+UUfxjiV7N4kSM95ocqd+'_REMOVE1)'))
			else: jv52HmXEIJxwpu9Rlc.append(('إضافة ل'+HZArKtwGCMoeD3bV5B6JPzQnlXd,'RunPlugin('+dRykI4C0DF6VOA9vGjnp1wN+'&context='+UUfxjiV7N4kSM95ocqd+'_ADD1)'))
	hnAgG9OBbpVa = []
	for tvDpNJiB8WelGaZzhXTYsfq9IC,goq41HeEB0iu9IkKhWbQnLX5fdOGVs in jv52HmXEIJxwpu9Rlc:
		tvDpNJiB8WelGaZzhXTYsfq9IC = lSWzOYmN08+tvDpNJiB8WelGaZzhXTYsfq9IC+NwROdSj3nsA
		hnAgG9OBbpVa.append((tvDpNJiB8WelGaZzhXTYsfq9IC,goq41HeEB0iu9IkKhWbQnLX5fdOGVs,))
	return hnAgG9OBbpVa
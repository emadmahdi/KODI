# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'EGYDEAD'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_EGD_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
SAsGubf1jW2Q3p = ['مصارعة','احدث البرامج','احدث الالعاب','الرئيسية','احدث الاغانى']
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==440: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==441: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,text)
	elif mode==442: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==443: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LLabVp7hzj28CE0f1udx(url)
	elif mode==449: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYDEAD-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	GWjBrpNhRsmt7eDba1yA4nukS = C2gnJ5tXFk9pAL(GiqvpBF9xLEdHDr37byJSngeCQ,'url')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,449,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الرئيسية',GiqvpBF9xLEdHDr37byJSngeCQ,441)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="title_menu_right"(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title in items:
		if title in SAsGubf1jW2Q3p: continue
		if ZylHkumQ8zD0=='#': continue
		TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,441)
	return
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,Ns6egmVv7nRutdLSQUaE8WFq5=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYDEAD-TITLES-2nd')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="list-related"(.*?)class="pagination"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('<li>.*?href="(.*?)".*?<h1>(.*?)</h1>.*?src="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title,HRlygv7YwjzbSLt8fkEerq2 in items:
		if '/url/' in ZylHkumQ8zD0: continue
		elif '/season/' in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,443,HRlygv7YwjzbSLt8fkEerq2)
		elif '/episode/' in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,443,HRlygv7YwjzbSLt8fkEerq2)
		else: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,442,HRlygv7YwjzbSLt8fkEerq2)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="pagination"(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			title = HH8SJuswDBPtniebmkXIr(title)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+title,ZylHkumQ8zD0,441)
	return
def LLabVp7hzj28CE0f1udx(url):
	data = {'View':1}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'POST',url,data,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYDEAD-EPISODES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	LKk0YdTN72XmnMuBbw = PAztbuyYo4Kvd.findall('"seasons-list"(.*?)</div>.</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	N5Vbkn2chPGfT3m97Bv1LHKI = PAztbuyYo4Kvd.findall('"episodes-list"(.*?)</div>.</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if LKk0YdTN72XmnMuBbw:
		WWU7QJP2tyTRLIfDh0csxbkvX = LKk0YdTN72XmnMuBbw[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title,HRlygv7YwjzbSLt8fkEerq2 in items:
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,443,HRlygv7YwjzbSLt8fkEerq2)
	elif N5Vbkn2chPGfT3m97Bv1LHKI:
		HRlygv7YwjzbSLt8fkEerq2 = PAztbuyYo4Kvd.findall('"og:image" content="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2[0]
		WWU7QJP2tyTRLIfDh0csxbkvX = N5Vbkn2chPGfT3m97Bv1LHKI[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			title = title.replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c)
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,442,HRlygv7YwjzbSLt8fkEerq2)
	return
def lNBcUr8RCn(url):
	data = {'View':1}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'POST',url,data,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYDEAD-PLAY-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	ce9zAaVFswSq6lLr82DfQyotGW = []
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"watchAreaMaster"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('data-link="(.*?)".*?<p>(.*?)</p>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			title = title.replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c)
			ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named='+title+'__watch'
			ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"donwload-servers-list"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('"ser-name">(.*?)</span>.*?<em>(.*?)</em>.*?href="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for title,OzWg1yEQG8wtvJ4x2ic9aKedFAPD,ZylHkumQ8zD0 in items:
			ZylHkumQ8zD0 = ZylHkumQ8zD0.replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2)
			ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named='+title+'__download'+'____'+OzWg1yEQG8wtvJ4x2ic9aKedFAPD
			ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(ce9zAaVFswSq6lLr82DfQyotGW,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	search = search.replace(hSXlxL9iB05c,'+')
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/?s='+search
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
	return
# -*- coding: utf-8 -*-
import sys as kCNHMOym1luTnJ0
MigYEN1cxduFB2lpk5 = kCNHMOym1luTnJ0.version_info [0] == 2
xJ3XdNcV5IujAkoGh = 2048
aE71QiuHI95zfPRBUsntedWZJ2bl = 7
def vR1b8iCLa9Qy2Sw5OYAlWXNhZp37 (AGxE4RIvuC6):
	global peWEVn47JRXo916j
	Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky = ord (AGxE4RIvuC6 [-1])
	FXUjnSw308z = AGxE4RIvuC6 [:-1]
	f81LoVwXMpQkvdKcmPyj6NzBlt = Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky % len (FXUjnSw308z)
	qyKv5nBTxgkQSlJ0aNP1CUmpjYLZ = FXUjnSw308z [:f81LoVwXMpQkvdKcmPyj6NzBlt] + FXUjnSw308z [f81LoVwXMpQkvdKcmPyj6NzBlt:]
	if MigYEN1cxduFB2lpk5:
		H0yFJ5LDCGYpIM1BViZKTSgv3jXr = unicode () .join ([unichr (ord (Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286) - xJ3XdNcV5IujAkoGh - (MfwWyztdYVXURgPqLrITku3CxF1 + Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky) % aE71QiuHI95zfPRBUsntedWZJ2bl) for MfwWyztdYVXURgPqLrITku3CxF1, Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286 in enumerate (qyKv5nBTxgkQSlJ0aNP1CUmpjYLZ)])
	else:
		H0yFJ5LDCGYpIM1BViZKTSgv3jXr = str () .join ([chr (ord (Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286) - xJ3XdNcV5IujAkoGh - (MfwWyztdYVXURgPqLrITku3CxF1 + Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky) % aE71QiuHI95zfPRBUsntedWZJ2bl) for MfwWyztdYVXURgPqLrITku3CxF1, Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286 in enumerate (qyKv5nBTxgkQSlJ0aNP1CUmpjYLZ)])
	return eval (H0yFJ5LDCGYpIM1BViZKTSgv3jXr)
Yj1msqVeivESfrCupRy9b7WacBd,XEcWOIwkZKubV7vQ,Pj9YaUq1ibJ=vR1b8iCLa9Qy2Sw5OYAlWXNhZp37,vR1b8iCLa9Qy2Sw5OYAlWXNhZp37,vR1b8iCLa9Qy2Sw5OYAlWXNhZp37
HD7MQqXd2gS,yPE2t1Co4YQDfsIecdxu0Gklq6AvO,bqCDnV7Bs5XgRvuKLNAa1Uz=Pj9YaUq1ibJ,XEcWOIwkZKubV7vQ,Yj1msqVeivESfrCupRy9b7WacBd
YIsyNBocg6fV3wEWPSu9GtvHxLOqDi,VVstJA9bfOqunLF0oaSgWUKHDdYNz,nfNTgkiWdUq=bqCDnV7Bs5XgRvuKLNAa1Uz,yPE2t1Co4YQDfsIecdxu0Gklq6AvO,HD7MQqXd2gS
FVxoQ2J5Mfv3Zj6sy9uhOS,n8BrpFLyaMAC1vP0bOHgwxEzeGRV,UUobzy0xZLaVScIt7=nfNTgkiWdUq,VVstJA9bfOqunLF0oaSgWUKHDdYNz,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi
JvQd6LMoBX4hiy1C,ZjELJ9VrUT07R8Hn4FuSDcf,pxt6wJ8ScYMWCivoO=UUobzy0xZLaVScIt7,n8BrpFLyaMAC1vP0bOHgwxEzeGRV,FVxoQ2J5Mfv3Zj6sy9uhOS
lw2snZ9J0uhLoxypqa,LJqSQvuhf7aMmnVjy23FbZBckKzx9l,gmPI7hVEM8nD=pxt6wJ8ScYMWCivoO,ZjELJ9VrUT07R8Hn4FuSDcf,JvQd6LMoBX4hiy1C
w0ivtSjV2sZDQoT1OEugIla7R6AC5M,rCmGE4YIDaZA,vzqjsVHSBlMpxC=gmPI7hVEM8nD,LJqSQvuhf7aMmnVjy23FbZBckKzx9l,lw2snZ9J0uhLoxypqa
xwIUQfiE7rmvYzH,ldIfvn6asURQ9toi85EhqAXW3,bb1fgjsAq4N2xYwnoh39lm=vzqjsVHSBlMpxC,rCmGE4YIDaZA,w0ivtSjV2sZDQoT1OEugIla7R6AC5M
AJHaiQq3PRd5cphzGuELnVg9X,jil8vRpBsENVYyPmDd,PPxYugzLZwHX23yiK=bb1fgjsAq4N2xYwnoh39lm,ldIfvn6asURQ9toi85EhqAXW3,xwIUQfiE7rmvYzH
baBcNd81eH5ry2Olp6Mj43,Qy6wlfLoOpg1,mRanX1HZupfSQVB2gsDGUO=PPxYugzLZwHX23yiK,jil8vRpBsENVYyPmDd,AJHaiQq3PRd5cphzGuELnVg9X
bDxWcjmaSgFeRKrfpJvyA4zThi,DFx6E0uON7Jm8,zhE5I4xHinX0UoVZMNwlkPrR=mRanX1HZupfSQVB2gsDGUO,Qy6wlfLoOpg1,baBcNd81eH5ry2Olp6Mj43
from ZtD8eQAKnl import *
wgj0rX5tbcxPulhmny = ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠨࡋࡑࡍ࡙࠭ၢ")
XQKORVzAPC = bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠩၣ")
zzU5PnmRv13toWs4bDFL,B7n3L9yPx54v,RxWJFBAGy4iIM,No03nbgziMqjZ,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4 = boLfu8ilHFRek4ECO9GZ(dWHUYEKD6hA)
rzKxlyoWwpQHZiObUdPm35 = int(No03nbgziMqjZ)
nI9bERJkQPWOfV0 = SoNGUfhMDERLyHOz1qkVAj.getInfoLabel(mRanX1HZupfSQVB2gsDGUO(u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫၤ"))
nI9bERJkQPWOfV0 = nI9bERJkQPWOfV0.replace(YgKcwxaR3Fm,nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(Vfn18PSH5g2v7muhXGso9CAE6WU,nA5dhMRg6ENzsB0l1GwvH7aIr2)
if rzKxlyoWwpQHZiObUdPm35==LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠸࠶࠱ႊ"): iACuvhQWTNFRX0qJ = nfNTgkiWdUq(u"ࠫࠥࠦࠠࡗࡧࡵࡷ࡮ࡵ࡮࠻ࠢ࡞ࠤࠬၥ")+s5WcxEPjUBokapYMhAwb60dvgi+gmPI7hVEM8nD(u"ࠬࠦ࡝ࠡࠢࠣࡏࡴࡪࡩ࠻ࠢ࡞ࠤࠬၦ")+SAz6H7KPDEMveXklcnxGW+yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠭ࠠ࡞ࠩၧ")
else:
	sHRNoh9q0X4lTJP6yIWMESBZf = pvOytL0nF7JY6flXTxAcHbQeNahu3(dWHUYEKD6hA).replace(bbTCMJwEx8nhN4X,nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(lSWzOYmN08,nA5dhMRg6ENzsB0l1GwvH7aIr2)
	sHRNoh9q0X4lTJP6yIWMESBZf = sHRNoh9q0X4lTJP6yIWMESBZf.replace(NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c)
	sHRNoh9q0X4lTJP6yIWMESBZf = sHRNoh9q0X4lTJP6yIWMESBZf.replace(cqsuhi1JE7nNIfbPYQSpFgeGr,hSXlxL9iB05c).replace(PwYGfc4gTjiyRlsHn1OE,hSXlxL9iB05c).replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c)
	iACuvhQWTNFRX0qJ = HD7MQqXd2gS(u"ࠧࠡࠢࠣࡐࡦࡨࡥ࡭࠼ࠣ࡟ࠥ࠭ၨ")+nI9bERJkQPWOfV0+Yj1msqVeivESfrCupRy9b7WacBd(u"ࠨࠢࡠࠤࠥࠦࡍࡰࡦࡨ࠾ࠥࡡࠠࠨၩ")+No03nbgziMqjZ+ldIfvn6asURQ9toi85EhqAXW3(u"ࠩࠣࡡࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩၪ")+sHRNoh9q0X4lTJP6yIWMESBZf+n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠪࠤࡢ࠭ၫ")
nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,XQKORVzAPC+CXtugbqhV3+PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+iACuvhQWTNFRX0qJ)
if vzqjsVHSBlMpxC(u"ࠫࡤ࠭ၬ") in kSqp7Ua0gATvrXG2RFdzN: LbE7zRf5SDmd2NaeAFqp6vgWQy9cwn,lA1roIBQKayswg0N = kSqp7Ua0gATvrXG2RFdzN.split(XEcWOIwkZKubV7vQ(u"ࠬࡥࠧၭ"),UnOIK1WBbw2)
else: LbE7zRf5SDmd2NaeAFqp6vgWQy9cwn,lA1roIBQKayswg0N = kSqp7Ua0gATvrXG2RFdzN,nA5dhMRg6ENzsB0l1GwvH7aIr2
Nzp9Fq5cTr.BWx4LyF0fcT1teAwjQJkgrS8nPNU,ZZcxIq8bHKnPy2VREUMFG = FFKncZx5pDTwdiJRYhMgQSNL,nA5dhMRg6ENzsB0l1GwvH7aIr2
if LbE7zRf5SDmd2NaeAFqp6vgWQy9cwn in [yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠭࠱ࠨၮ"),vzqjsVHSBlMpxC(u"ࠧ࠳ࠩၯ"),ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠨ࠵ࠪၰ"),XEcWOIwkZKubV7vQ(u"ࠩ࠷ࠫၱ"),nfNTgkiWdUq(u"ࠪ࠹ࠬၲ"),ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠫ࠶࠷ࠧၳ"),vzqjsVHSBlMpxC(u"ࠬ࠷࠲ࠨၴ"),Qy6wlfLoOpg1(u"࠭࠱࠴ࠩၵ")] and (UUobzy0xZLaVScIt7(u"ࠧࡂࡆࡇࠫၶ") in lA1roIBQKayswg0N or ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠨࡔࡈࡑࡔ࡜ࡅࠨၷ") in lA1roIBQKayswg0N or xwIUQfiE7rmvYzH(u"ࠩࡘࡔࠬၸ") in lA1roIBQKayswg0N or jil8vRpBsENVYyPmDd(u"ࠪࡈࡔ࡝ࡎࠨၹ") in lA1roIBQKayswg0N):
	from FjdxIzi5Pr import z2sJc7NoDZhGTqkHWCSxf
	z2sJc7NoDZhGTqkHWCSxf(kSqp7Ua0gATvrXG2RFdzN,LbE7zRf5SDmd2NaeAFqp6vgWQy9cwn,lA1roIBQKayswg0N)
	KQctJbXeEjDhplqknU3rzi.setSetting(XEcWOIwkZKubV7vQ(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨၺ"),dWHUYEKD6hA)
	Nzp9Fq5cTr.BWx4LyF0fcT1teAwjQJkgrS8nPNU = S5MWhgtZ37Xw
elif not AAnORceT4EpS0CXtgKFlvz9Mjb8 and rzKxlyoWwpQHZiObUdPm35 in [w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠲࠴࠷ႋ"),ldIfvn6asURQ9toi85EhqAXW3(u"࠸࠳࠸ႌ")]:
	QLSRWqIZ71KXcsJO2 = str(Xxcm31HuozfbJEAv8Rl7PwUgGBF4[UUobzy0xZLaVScIt7(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬၻ")])
	wgj0rX5tbcxPulhmny = XEcWOIwkZKubV7vQ(u"࠭ࡉࡑࡖ࡙ࠫၼ") if rzKxlyoWwpQHZiObUdPm35==HD7MQqXd2gS(u"࠴࠶࠹ႍ") else YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠧࡎ࠵ࡘࠫၽ")
	vMBQoxEs46SqJOHlmWZ = wgj0rX5tbcxPulhmny.lower()
	cgob7MO2qshG = KQctJbXeEjDhplqknU3rzi.getSetting(VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠨࡣࡹ࠲ࠬၾ")+vMBQoxEs46SqJOHlmWZ+YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠩ࠱ࡹࡸ࡫ࡲࡢࡩࡨࡲࡹࡥࠧၿ")+QLSRWqIZ71KXcsJO2)
	C5CBL2l96nAPobOujyWpEgsJ = KQctJbXeEjDhplqknU3rzi.getSetting(YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠪࡥࡻ࠴ࠧႀ")+vMBQoxEs46SqJOHlmWZ+ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠫ࠳ࡸࡥࡧࡧࡵࡩࡷࡥࠧႁ")+QLSRWqIZ71KXcsJO2)
	if cgob7MO2qshG or C5CBL2l96nAPobOujyWpEgsJ:
		RxWJFBAGy4iIM += jil8vRpBsENVYyPmDd(u"ࠬࢂࠧႂ")
		if cgob7MO2qshG: RxWJFBAGy4iIM += jil8vRpBsENVYyPmDd(u"࠭ࠦࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬႃ")+cgob7MO2qshG
		if C5CBL2l96nAPobOujyWpEgsJ: RxWJFBAGy4iIM += UUobzy0xZLaVScIt7(u"ࠧࠧࡔࡨࡪࡪࡸࡥࡳ࠿ࠪႄ")+C5CBL2l96nAPobOujyWpEgsJ
		RxWJFBAGy4iIM = RxWJFBAGy4iIM.replace(Qy6wlfLoOpg1(u"ࠨࡾࠩࠫႅ"),bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠩࡿࠫႆ"))
	fOXLYFxiEBD = KQctJbXeEjDhplqknU3rzi.getSetting(nfNTgkiWdUq(u"ࠪࡥࡻ࠴ࠧႇ")+vMBQoxEs46SqJOHlmWZ+n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠫ࠳ࡹࡥࡳࡸࡨࡶࡤ࠭ႈ")+QLSRWqIZ71KXcsJO2)
	if fOXLYFxiEBD:
		IIhT37xlVJ69YBOcDM5PN = PAztbuyYo4Kvd.findall(rCmGE4YIDaZA(u"ࠬࡀ࠯࠰ࠪ࠱࠮ࡄ࠯࠯ࠨႉ"),RxWJFBAGy4iIM,PAztbuyYo4Kvd.DOTALL)
		RxWJFBAGy4iIM = RxWJFBAGy4iIM.replace(IIhT37xlVJ69YBOcDM5PN[IpFcwrWNgefMym3qta0hYQAzOdE],fOXLYFxiEBD)
	ocUnzjShqIO35vZi8bk64pVKMCTBaw(RxWJFBAGy4iIM,wgj0rX5tbcxPulhmny,zzU5PnmRv13toWs4bDFL)
else:
	import pR2X91txEm
	try: pR2X91txEm.QKzapDSFdWlghCByIf7UVMGkboTH(zzU5PnmRv13toWs4bDFL,B7n3L9yPx54v,RxWJFBAGy4iIM,No03nbgziMqjZ,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4,rzKxlyoWwpQHZiObUdPm35,LbE7zRf5SDmd2NaeAFqp6vgWQy9cwn,lA1roIBQKayswg0N,nI9bERJkQPWOfV0)
	except Exception as OM5zCN21ERDn6ydljYpF: ZZcxIq8bHKnPy2VREUMFG = G7QdMkY6Rr.format_exc()
aMO0AHtPkKb5GZD72FqWUlLjgnu9V(Nzp9Fq5cTr.BWx4LyF0fcT1teAwjQJkgrS8nPNU,ZZcxIq8bHKnPy2VREUMFG)
# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'ALMSTBA'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_MST_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
SAsGubf1jW2Q3p = ['الرئيسية','يلا شوت']
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==860: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==861: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,text)
	elif mode==862: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==863: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = Uz7y8Vt3frjd6ZKHwcgsFBv05apxNC(url,text)
	elif mode==869: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',GiqvpBF9xLEdHDr37byJSngeCQ+'/indx1/',nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ALMSTBA-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,869,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"primary-links"(.*?)</u',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?<span>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			if title in SAsGubf1jW2Q3p: continue
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,861)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"list-categories"(.*?)<script',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+ZylHkumQ8zD0.lstrip('/')
			if title in SAsGubf1jW2Q3p: continue
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,861)
	return
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,LV9moOrXWFKbGYevPgul=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ALMSTBA-TITLES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"home-content"(.*?)"footer"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		WWU7QJP2tyTRLIfDh0csxbkvX = WWU7QJP2tyTRLIfDh0csxbkvX.replace('"overlay"','"duration"><')
		items = PAztbuyYo4Kvd.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		u0UiTmzYN6I3Q9eCZVoB = []
		for HRlygv7YwjzbSLt8fkEerq2,yoaKx7FtIlvcD,ZylHkumQ8zD0,title in items:
			title = title.strip(' ')
			title = HH8SJuswDBPtniebmkXIr(title)
			JfNHOP2BK1Yxl7Rq4 = PAztbuyYo4Kvd.findall('(.*?) (الحلقة|حلقة).\d+',title,PAztbuyYo4Kvd.DOTALL)
			if 'episodes' not in LV9moOrXWFKbGYevPgul and JfNHOP2BK1Yxl7Rq4:
				title = '_MOD_' + JfNHOP2BK1Yxl7Rq4[0][0]
				title = title.replace('اون لاين',nA5dhMRg6ENzsB0l1GwvH7aIr2)
				if title not in u0UiTmzYN6I3Q9eCZVoB:
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,863,HRlygv7YwjzbSLt8fkEerq2)
					u0UiTmzYN6I3Q9eCZVoB.append(title)
			else: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,862,HRlygv7YwjzbSLt8fkEerq2,yoaKx7FtIlvcD)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('''["']pagination["'](.*?)["']footer["']''',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		LV9moOrXWFKbGYevPgul = 'episodes_pages' if 'episodes' in LV9moOrXWFKbGYevPgul else 'pages'
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			title = HH8SJuswDBPtniebmkXIr(title)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+title,ZylHkumQ8zD0,861,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,LV9moOrXWFKbGYevPgul)
	else:
		toYcvhVnEMbzpBXC5FU2dWy = PAztbuyYo4Kvd.findall('class="pagination__next.*?href="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if toYcvhVnEMbzpBXC5FU2dWy:
			ZylHkumQ8zD0 = toYcvhVnEMbzpBXC5FU2dWy[0]
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة لاحقة',ZylHkumQ8zD0,861,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,LV9moOrXWFKbGYevPgul)
	return
def Uz7y8Vt3frjd6ZKHwcgsFBv05apxNC(url,Q9fbtnwCKAN5syS8DPvmX62gHE):
	GWjBrpNhRsmt7eDba1yA4nukS = C2gnJ5tXFk9pAL(url,'url')
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ALMSTBA-EPISODES_SEASONS-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	LKk0YdTN72XmnMuBbw = PAztbuyYo4Kvd.findall('"episodes-container"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	io76Hju84PtJO3hE5x9KZnpGmalIw = PAztbuyYo4Kvd.findall('"thumbnailUrl":"(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	HRlygv7YwjzbSLt8fkEerq2 = io76Hju84PtJO3hE5x9KZnpGmalIw[0] if io76Hju84PtJO3hE5x9KZnpGmalIw else nA5dhMRg6ENzsB0l1GwvH7aIr2
	HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2.replace('\/','/')
	HRlygv7YwjzbSLt8fkEerq2 += '|Referer='+GiqvpBF9xLEdHDr37byJSngeCQ
	items = []
	JJsF8i76eoYhdjqZ1Qg0lRKAHv9S = False
	if LKk0YdTN72XmnMuBbw and not Q9fbtnwCKAN5syS8DPvmX62gHE:
		WWU7QJP2tyTRLIfDh0csxbkvX = LKk0YdTN72XmnMuBbw[0]
		items = PAztbuyYo4Kvd.findall('data-tab="(.*?)".*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for Q9fbtnwCKAN5syS8DPvmX62gHE,title in items:
			Q9fbtnwCKAN5syS8DPvmX62gHE = Q9fbtnwCKAN5syS8DPvmX62gHE.strip('#')
			if len(items)>1: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,863,HRlygv7YwjzbSLt8fkEerq2,nA5dhMRg6ENzsB0l1GwvH7aIr2,Q9fbtnwCKAN5syS8DPvmX62gHE)
			else: JJsF8i76eoYhdjqZ1Qg0lRKAHv9S = True
	else: JJsF8i76eoYhdjqZ1Qg0lRKAHv9S = True
	if JJsF8i76eoYhdjqZ1Qg0lRKAHv9S or not Q9fbtnwCKAN5syS8DPvmX62gHE:
		if not Q9fbtnwCKAN5syS8DPvmX62gHE: N5Vbkn2chPGfT3m97Bv1LHKI = PAztbuyYo4Kvd.findall('"tab-content.*?id="(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		else: N5Vbkn2chPGfT3m97Bv1LHKI = PAztbuyYo4Kvd.findall('"tab-content.*?id="'+Q9fbtnwCKAN5syS8DPvmX62gHE+'"(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if N5Vbkn2chPGfT3m97Bv1LHKI:
			WWU7QJP2tyTRLIfDh0csxbkvX = N5Vbkn2chPGfT3m97Bv1LHKI[0]
			items = PAztbuyYo4Kvd.findall('href="(.*?)" title="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,title in items:
				if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = GWjBrpNhRsmt7eDba1yA4nukS+'/'+ZylHkumQ8zD0.strip('./')
				title = title.replace('</em><span>',hSXlxL9iB05c)
				TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,862,HRlygv7YwjzbSLt8fkEerq2)
	return
def lNBcUr8RCn(url):
	HtT6mBGwMaq1o0rybzZ4,xD9aheBXINOKbECng34JrRl = [],[]
	KteRnFMjHpBPqNf8 = url.strip('/')+'/?do=watch'
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ALMSTBA-PLAY-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	ZylHkumQ8zD0 = PAztbuyYo4Kvd.findall('iframe src="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if ZylHkumQ8zD0:
		ZylHkumQ8zD0 = ZylHkumQ8zD0[0]
		xD9aheBXINOKbECng34JrRl.append(ZylHkumQ8zD0)
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',ZylHkumQ8zD0,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ALMSTBA-PLAY-2nd')
		v2u4dgJnek0sQDxKf = Y3SmVGbfNvEeakMBr.content
		ww5oBKPZmc = PAztbuyYo4Kvd.findall('iframe src="(.*?)"',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL)
		ww5oBKPZmc = ww5oBKPZmc[0] if ww5oBKPZmc else ZylHkumQ8zD0
		ww5oBKPZmc = HH8SJuswDBPtniebmkXIr(ww5oBKPZmc)
		if ww5oBKPZmc not in xD9aheBXINOKbECng34JrRl:
			xD9aheBXINOKbECng34JrRl.append(ww5oBKPZmc)
			DQ7XgFltujVL = C2gnJ5tXFk9pAL(ww5oBKPZmc,'name')
			ww5oBKPZmc = ww5oBKPZmc+'?named='+DQ7XgFltujVL+'__embed'
			HtT6mBGwMaq1o0rybzZ4.append(ww5oBKPZmc)
	headers = {'Referer':url}
	bJ4y9AcpNTXFIEqMSvjuLgH3 = PAztbuyYo4Kvd.findall('post_id:(\d+)',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	ugzPEAchGjLaH2yqwYvJ = GiqvpBF9xLEdHDr37byJSngeCQ+'/wp-admin/admin-ajax.php?action=video_info&post_id='+bJ4y9AcpNTXFIEqMSvjuLgH3[0]
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',ugzPEAchGjLaH2yqwYvJ,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ALMSTBA-PLAY-3rd')
	v2u4dgJnek0sQDxKf = Y3SmVGbfNvEeakMBr.content
	ZylHkumQ8zD0 = PAztbuyYo4Kvd.findall('"src":"(.*?)"',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL)
	if ZylHkumQ8zD0:
		ZylHkumQ8zD0 = ZylHkumQ8zD0[0]
		ZylHkumQ8zD0 = ZylHkumQ8zD0.replace('\/','/')
		if ZylHkumQ8zD0 not in xD9aheBXINOKbECng34JrRl:
			xD9aheBXINOKbECng34JrRl.append(ZylHkumQ8zD0)
			DQ7XgFltujVL = C2gnJ5tXFk9pAL(ZylHkumQ8zD0,'name')
			ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named='+DQ7XgFltujVL+'__watch'
			HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0)
	ZylHkumQ8zD0 = PAztbuyYo4Kvd.findall('"Download" target="_blank" href="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if ZylHkumQ8zD0:
		ZylHkumQ8zD0 = ZylHkumQ8zD0[0]
		if ZylHkumQ8zD0 not in xD9aheBXINOKbECng34JrRl:
			xD9aheBXINOKbECng34JrRl.append(ZylHkumQ8zD0)
			DQ7XgFltujVL = C2gnJ5tXFk9pAL(ZylHkumQ8zD0,'name')
			ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named='+DQ7XgFltujVL+'__download'
			HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0)
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(HtT6mBGwMaq1o0rybzZ4,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	search = search.replace(hSXlxL9iB05c,'+')
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/?s='+search
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,'search')
	return
# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'YOUTUBE'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_YUT_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
sW4uZLyomIbza = 0
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text,type,Q0f7ytucSriRw8HTzd,name,io76Hju84PtJO3hE5x9KZnpGmalIw):
	if	 mode==140: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==141: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = QKkoR5LlSrA1e6cvxsy(url,name,io76Hju84PtJO3hE5x9KZnpGmalIw)
	elif mode==143: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url,type)
	elif mode==144: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,Q0f7ytucSriRw8HTzd,text)
	elif mode==145: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ccZu8TyQ5vdohlnENbp4qixKOr(url,Q0f7ytucSriRw8HTzd)
	elif mode==147: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = vb78SL1j2mD()
	elif mode==148: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = RgMCAQbpJ4rGV()
	elif mode==149: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	if 0:
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'قائمة 1',GiqvpBF9xLEdHDr37byJSngeCQ+'/playlist?list=PLDJPKWWTSFaaGNjpDcPUsWZJVePmAYk_E&pp=iAQB',144)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'قائمة 2',GiqvpBF9xLEdHDr37byJSngeCQ+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'شخص',GiqvpBF9xLEdHDr37byJSngeCQ+'/user/TCNofficial',144)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'موقع',GiqvpBF9xLEdHDr37byJSngeCQ+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'حساب',GiqvpBF9xLEdHDr37byJSngeCQ+'/@TheSocialCTV',144)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'العاب',GiqvpBF9xLEdHDr37byJSngeCQ+'/gaming',144)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'افلام',GiqvpBF9xLEdHDr37byJSngeCQ+'/feed/storefront',144)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مختارات',GiqvpBF9xLEdHDr37byJSngeCQ+'/feed/guide_builder',144)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'قصيرة',GiqvpBF9xLEdHDr37byJSngeCQ+'/shorts',144,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'تصفح',GiqvpBF9xLEdHDr37byJSngeCQ+'/youtubei/v1/guide?key=',144)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'رئيسية',GiqvpBF9xLEdHDr37byJSngeCQ+nA5dhMRg6ENzsB0l1GwvH7aIr2,144)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'رائج',GiqvpBF9xLEdHDr37byJSngeCQ+'/feed/trending?bp=',144)
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,149,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الرائجة',GiqvpBF9xLEdHDr37byJSngeCQ+'/feed/trending',144)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'التصفح',GiqvpBF9xLEdHDr37byJSngeCQ+'/youtubei/v1/guide?key=',144)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'القصيرة',GiqvpBF9xLEdHDr37byJSngeCQ+'/shorts',144,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مختارات يوتيوب',GiqvpBF9xLEdHDr37byJSngeCQ+'/feed/guide_builder',144)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مختارات البرنامج',nA5dhMRg6ENzsB0l1GwvH7aIr2,290)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث: قنوات عربية',nA5dhMRg6ENzsB0l1GwvH7aIr2,147)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث: قنوات أجنبية',nA5dhMRg6ENzsB0l1GwvH7aIr2,148)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث: افلام عربية',GiqvpBF9xLEdHDr37byJSngeCQ+'/results?search_query=فيلم',144)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث: افلام اجنبية',GiqvpBF9xLEdHDr37byJSngeCQ+'/results?search_query=movie',144)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث: مسرحيات عربية',GiqvpBF9xLEdHDr37byJSngeCQ+'/results?search_query=مسرحية',144)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث: مسلسلات عربية',GiqvpBF9xLEdHDr37byJSngeCQ+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث: مسلسلات اجنبية',GiqvpBF9xLEdHDr37byJSngeCQ+'/results?search_query=series&sp=EgIQAw==',144)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث: مسلسلات كارتون',GiqvpBF9xLEdHDr37byJSngeCQ+'/results?search_query=كارتون&sp=EgIQAw==',144)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث: خطبة المرجعية',GiqvpBF9xLEdHDr37byJSngeCQ+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def QKkoR5LlSrA1e6cvxsy(url,name,io76Hju84PtJO3hE5x9KZnpGmalIw):
	name = CRV3tDJ6gNczqXF7Z8jnvH1kh(name)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'CHNL:  '+name,url,144,io76Hju84PtJO3hE5x9KZnpGmalIw)
	return
def vb78SL1j2mD():
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(GiqvpBF9xLEdHDr37byJSngeCQ+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def RgMCAQbpJ4rGV():
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(GiqvpBF9xLEdHDr37byJSngeCQ+'/results?search_query=tv&sp=EgJAAQ==')
	return
def lNBcUr8RCn(url,type):
	url = url.split('&',1)[0]
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM([url],wgj0rX5tbcxPulhmny,type,url)
	return
def xq03zYF1ocEduBtrM(TIV7unFaebyoj35WMrgXLsKk,url,rRxld1HykSCacZs0mzWXIBibn):
	level,d9ygXDE7eLHjYkZB,Ct6971kvqrJmbHFlQNAZ5siBYK,bBd2oZ9HMU8AzufIW = rRxld1HykSCacZs0mzWXIBibn.split('::')
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp,EEVJf2i3eBSQMUda = [],[]
	if '/youtubei/v1/browse' in url: mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yccc['onResponseReceivedCommands']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	if level=='1': mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yccc['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yccc['entries']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yccc['items'][3]['guideSectionRenderer']['items']")
	CkSslRwMFVJPpfKY,liKsH8jAm5LREaUTo,glReyPVQ76du3XKhvp0F = mL4KUNQ6VBSO1FEk2pitlsy7o5Wa(TIV7unFaebyoj35WMrgXLsKk,nA5dhMRg6ENzsB0l1GwvH7aIr2,mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp)
	if level=='1' and CkSslRwMFVJPpfKY:
		if len(liKsH8jAm5LREaUTo)>1 and 'search_query' not in url:
			for PDA4n3y2WX in range(len(liKsH8jAm5LREaUTo)):
				d9ygXDE7eLHjYkZB = str(PDA4n3y2WX)
				mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp = []
				mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yddd["+d9ygXDE7eLHjYkZB+"]['reloadContinuationItemsCommand']['continuationItems']")
				mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yddd["+d9ygXDE7eLHjYkZB+"]['command']")
				mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yddd["+d9ygXDE7eLHjYkZB+"]")
				zTEXepHg92GkWf,CQtNwXGVAJ2y5nBY,Ns6egmVv7nRutdLSQUaE8WFq5 = mL4KUNQ6VBSO1FEk2pitlsy7o5Wa(liKsH8jAm5LREaUTo,nA5dhMRg6ENzsB0l1GwvH7aIr2,mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp)
				if zTEXepHg92GkWf: EEVJf2i3eBSQMUda.append([CQtNwXGVAJ2y5nBY,url,'2::'+d9ygXDE7eLHjYkZB+'::0::0'])
			mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yccc['continuationEndpoint']")
			zTEXepHg92GkWf,CQtNwXGVAJ2y5nBY,Ns6egmVv7nRutdLSQUaE8WFq5 = mL4KUNQ6VBSO1FEk2pitlsy7o5Wa(TIV7unFaebyoj35WMrgXLsKk,nA5dhMRg6ENzsB0l1GwvH7aIr2,mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp)
			if zTEXepHg92GkWf and EEVJf2i3eBSQMUda and 'continuationCommand' in list(CQtNwXGVAJ2y5nBY.keys()):
				ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/my_main_page_shorts_link'
				EEVJf2i3eBSQMUda.append([CQtNwXGVAJ2y5nBY,ZylHkumQ8zD0,'1::0::0::0'])
	return liKsH8jAm5LREaUTo,CkSslRwMFVJPpfKY,EEVJf2i3eBSQMUda,glReyPVQ76du3XKhvp0F
def vybYK8ueEN3VRon7wjplMT(TIV7unFaebyoj35WMrgXLsKk,liKsH8jAm5LREaUTo,url,rRxld1HykSCacZs0mzWXIBibn):
	level,d9ygXDE7eLHjYkZB,Ct6971kvqrJmbHFlQNAZ5siBYK,bBd2oZ9HMU8AzufIW = rRxld1HykSCacZs0mzWXIBibn.split('::')
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp,a9ls2BfZ5oTtYe7 = [],[]
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yddd[0]['itemSectionRenderer']['contents']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yddd["+d9ygXDE7eLHjYkZB+"]['reloadContinuationItemsCommand']['continuationItems']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yddd["+d9ygXDE7eLHjYkZB+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yddd["+d9ygXDE7eLHjYkZB+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yddd["+d9ygXDE7eLHjYkZB+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yddd["+d9ygXDE7eLHjYkZB+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yddd["+d9ygXDE7eLHjYkZB+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yddd["+d9ygXDE7eLHjYkZB+"]")
	ZH95UItD3qio0Xuc8sBM,b3zpaK4mEd7M69ATcCrPHgBwRUFtx,TTG8Ju0sYxRkfFQr26yn9 = mL4KUNQ6VBSO1FEk2pitlsy7o5Wa(liKsH8jAm5LREaUTo,nA5dhMRg6ENzsB0l1GwvH7aIr2,mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp)
	if level=='2' and ZH95UItD3qio0Xuc8sBM:
		if len(b3zpaK4mEd7M69ATcCrPHgBwRUFtx)>1:
			for PDA4n3y2WX in range(len(b3zpaK4mEd7M69ATcCrPHgBwRUFtx)):
				Ct6971kvqrJmbHFlQNAZ5siBYK = str(PDA4n3y2WX)
				mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp = []
				mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yeee["+Ct6971kvqrJmbHFlQNAZ5siBYK+"]['richSectionRenderer']['content']")
				mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yeee["+Ct6971kvqrJmbHFlQNAZ5siBYK+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yeee["+Ct6971kvqrJmbHFlQNAZ5siBYK+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yeee["+Ct6971kvqrJmbHFlQNAZ5siBYK+"]['itemSectionRenderer']['contents'][0]")
				mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yeee["+Ct6971kvqrJmbHFlQNAZ5siBYK+"]['richItemRenderer']['content']")
				mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yeee["+Ct6971kvqrJmbHFlQNAZ5siBYK+"]")
				zTEXepHg92GkWf,CQtNwXGVAJ2y5nBY,Ns6egmVv7nRutdLSQUaE8WFq5 = mL4KUNQ6VBSO1FEk2pitlsy7o5Wa(b3zpaK4mEd7M69ATcCrPHgBwRUFtx,nA5dhMRg6ENzsB0l1GwvH7aIr2,mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp)
				if zTEXepHg92GkWf: a9ls2BfZ5oTtYe7.append([CQtNwXGVAJ2y5nBY,url,'3::'+d9ygXDE7eLHjYkZB+'::'+Ct6971kvqrJmbHFlQNAZ5siBYK+'::0'])
			mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yddd[1]")
			zTEXepHg92GkWf,CQtNwXGVAJ2y5nBY,Ns6egmVv7nRutdLSQUaE8WFq5 = mL4KUNQ6VBSO1FEk2pitlsy7o5Wa(liKsH8jAm5LREaUTo,nA5dhMRg6ENzsB0l1GwvH7aIr2,mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp)
			if zTEXepHg92GkWf and a9ls2BfZ5oTtYe7 and 'continuationItemRenderer' in list(CQtNwXGVAJ2y5nBY.keys()):
				a9ls2BfZ5oTtYe7.append([CQtNwXGVAJ2y5nBY,url,'3::0::0::0'])
	return b3zpaK4mEd7M69ATcCrPHgBwRUFtx,ZH95UItD3qio0Xuc8sBM,a9ls2BfZ5oTtYe7,TTG8Ju0sYxRkfFQr26yn9
def eeY6jyz5nXQ0dlRZphgfvq3cKrT(TIV7unFaebyoj35WMrgXLsKk,b3zpaK4mEd7M69ATcCrPHgBwRUFtx,url,rRxld1HykSCacZs0mzWXIBibn):
	level,d9ygXDE7eLHjYkZB,Ct6971kvqrJmbHFlQNAZ5siBYK,bBd2oZ9HMU8AzufIW = rRxld1HykSCacZs0mzWXIBibn.split('::')
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp,kgMZiO2W4rVfTqxuz9NlA0QK = [],[]
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yeee["+Ct6971kvqrJmbHFlQNAZ5siBYK+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yeee["+Ct6971kvqrJmbHFlQNAZ5siBYK+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yeee["+Ct6971kvqrJmbHFlQNAZ5siBYK+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yeee["+Ct6971kvqrJmbHFlQNAZ5siBYK+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yeee["+Ct6971kvqrJmbHFlQNAZ5siBYK+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yeee["+Ct6971kvqrJmbHFlQNAZ5siBYK+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yeee["+Ct6971kvqrJmbHFlQNAZ5siBYK+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yeee["+Ct6971kvqrJmbHFlQNAZ5siBYK+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yeee["+Ct6971kvqrJmbHFlQNAZ5siBYK+"]['reelShelfRenderer']['items']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yeee["+Ct6971kvqrJmbHFlQNAZ5siBYK+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yeee")
	QUwv4Or2m3XJSYVkuAhqlPT15G0zx,Qt5yUMs9hKCF1OIYmrNSXRcvb6q8xf,XLUWwc6vESpAO4xGjFQ = mL4KUNQ6VBSO1FEk2pitlsy7o5Wa(b3zpaK4mEd7M69ATcCrPHgBwRUFtx,nA5dhMRg6ENzsB0l1GwvH7aIr2,mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp)
	if level=='3' and QUwv4Or2m3XJSYVkuAhqlPT15G0zx:
		if len(Qt5yUMs9hKCF1OIYmrNSXRcvb6q8xf)>0:
			for PDA4n3y2WX in range(len(Qt5yUMs9hKCF1OIYmrNSXRcvb6q8xf)):
				bBd2oZ9HMU8AzufIW = str(PDA4n3y2WX)
				mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp = []
				mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yfff["+bBd2oZ9HMU8AzufIW+"]['richItemRenderer']['content']")
				mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yfff["+bBd2oZ9HMU8AzufIW+"]['gameCardRenderer']['game']")
				mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yfff["+bBd2oZ9HMU8AzufIW+"]['itemSectionRenderer']['contents'][0]")
				mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yfff["+bBd2oZ9HMU8AzufIW+"]")
				mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yfff")
				zTEXepHg92GkWf,CQtNwXGVAJ2y5nBY,Ns6egmVv7nRutdLSQUaE8WFq5 = mL4KUNQ6VBSO1FEk2pitlsy7o5Wa(Qt5yUMs9hKCF1OIYmrNSXRcvb6q8xf,nA5dhMRg6ENzsB0l1GwvH7aIr2,mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp)
				if zTEXepHg92GkWf: kgMZiO2W4rVfTqxuz9NlA0QK.append([CQtNwXGVAJ2y5nBY,url,'4::'+d9ygXDE7eLHjYkZB+'::'+Ct6971kvqrJmbHFlQNAZ5siBYK+'::'+bBd2oZ9HMU8AzufIW])
	return Qt5yUMs9hKCF1OIYmrNSXRcvb6q8xf,QUwv4Or2m3XJSYVkuAhqlPT15G0zx,kgMZiO2W4rVfTqxuz9NlA0QK,XLUWwc6vESpAO4xGjFQ
def mL4KUNQ6VBSO1FEk2pitlsy7o5Wa(PVtaCQIjfu5UDS3pKsY21xz4,vEkDr7QlLO048A1SCBPpJo,rrRIKitDHS78aTCXgehpYjywcUGds):
	TIV7unFaebyoj35WMrgXLsKk,vEkDr7QlLO048A1SCBPpJo = PVtaCQIjfu5UDS3pKsY21xz4,vEkDr7QlLO048A1SCBPpJo
	liKsH8jAm5LREaUTo,vEkDr7QlLO048A1SCBPpJo = PVtaCQIjfu5UDS3pKsY21xz4,vEkDr7QlLO048A1SCBPpJo
	b3zpaK4mEd7M69ATcCrPHgBwRUFtx,vEkDr7QlLO048A1SCBPpJo = PVtaCQIjfu5UDS3pKsY21xz4,vEkDr7QlLO048A1SCBPpJo
	Qt5yUMs9hKCF1OIYmrNSXRcvb6q8xf,vEkDr7QlLO048A1SCBPpJo = PVtaCQIjfu5UDS3pKsY21xz4,vEkDr7QlLO048A1SCBPpJo
	CQtNwXGVAJ2y5nBY,LIPFEUMqS5vkKs4z1YNwiVrjbRgo = PVtaCQIjfu5UDS3pKsY21xz4,vEkDr7QlLO048A1SCBPpJo
	count = len(rrRIKitDHS78aTCXgehpYjywcUGds)
	for hsqrMEVB70i2ZnzPHlGYD1oy in range(count):
		try:
			ggSpuX4iBU = eval(rrRIKitDHS78aTCXgehpYjywcUGds[hsqrMEVB70i2ZnzPHlGYD1oy])
			return True,ggSpuX4iBU,hsqrMEVB70i2ZnzPHlGYD1oy+1
		except: pass
	return False,nA5dhMRg6ENzsB0l1GwvH7aIr2,0
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,rRxld1HykSCacZs0mzWXIBibn=nA5dhMRg6ENzsB0l1GwvH7aIr2,data=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	EEVJf2i3eBSQMUda,a9ls2BfZ5oTtYe7,kgMZiO2W4rVfTqxuz9NlA0QK = [],[],[]
	if '::' not in rRxld1HykSCacZs0mzWXIBibn: rRxld1HykSCacZs0mzWXIBibn = '1::0::0::0'
	level,d9ygXDE7eLHjYkZB,Ct6971kvqrJmbHFlQNAZ5siBYK,bBd2oZ9HMU8AzufIW = rRxld1HykSCacZs0mzWXIBibn.split('::')
	if level=='4': level,d9ygXDE7eLHjYkZB,Ct6971kvqrJmbHFlQNAZ5siBYK,bBd2oZ9HMU8AzufIW = '1',d9ygXDE7eLHjYkZB,Ct6971kvqrJmbHFlQNAZ5siBYK,bBd2oZ9HMU8AzufIW
	data = data.replace('_REMEMBERRESULTS_',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	kl2ZWdy8rXcHT,TIV7unFaebyoj35WMrgXLsKk,rA4ZGoQyIHlneVfzNukWd = aUJF2W73zVCEqQRiZYdD1pyI4(url,data)
	rRxld1HykSCacZs0mzWXIBibn = level+'::'+d9ygXDE7eLHjYkZB+'::'+Ct6971kvqrJmbHFlQNAZ5siBYK+'::'+bBd2oZ9HMU8AzufIW
	if level in ['1','2','3']:
		liKsH8jAm5LREaUTo,CkSslRwMFVJPpfKY,EEVJf2i3eBSQMUda,glReyPVQ76du3XKhvp0F = xq03zYF1ocEduBtrM(TIV7unFaebyoj35WMrgXLsKk,url,rRxld1HykSCacZs0mzWXIBibn)
		if not CkSslRwMFVJPpfKY: return
		tIzJpVo8H4A0 = len(EEVJf2i3eBSQMUda)
		if tIzJpVo8H4A0<2:
			if level=='1': level = '2'
			EEVJf2i3eBSQMUda = []
	rRxld1HykSCacZs0mzWXIBibn = level+'::'+d9ygXDE7eLHjYkZB+'::'+Ct6971kvqrJmbHFlQNAZ5siBYK+'::'+bBd2oZ9HMU8AzufIW
	if level in ['2','3']:
		b3zpaK4mEd7M69ATcCrPHgBwRUFtx,ZH95UItD3qio0Xuc8sBM,a9ls2BfZ5oTtYe7,TTG8Ju0sYxRkfFQr26yn9 = vybYK8ueEN3VRon7wjplMT(TIV7unFaebyoj35WMrgXLsKk,liKsH8jAm5LREaUTo,url,rRxld1HykSCacZs0mzWXIBibn)
		if not ZH95UItD3qio0Xuc8sBM: return
		D51wlUTOvEhoNK = len(a9ls2BfZ5oTtYe7)
		if D51wlUTOvEhoNK<2:
			if level=='2': level = '3'
			a9ls2BfZ5oTtYe7 = []
	rRxld1HykSCacZs0mzWXIBibn = level+'::'+d9ygXDE7eLHjYkZB+'::'+Ct6971kvqrJmbHFlQNAZ5siBYK+'::'+bBd2oZ9HMU8AzufIW
	if level in ['3']:
		Qt5yUMs9hKCF1OIYmrNSXRcvb6q8xf,QUwv4Or2m3XJSYVkuAhqlPT15G0zx,kgMZiO2W4rVfTqxuz9NlA0QK,XLUWwc6vESpAO4xGjFQ = eeY6jyz5nXQ0dlRZphgfvq3cKrT(TIV7unFaebyoj35WMrgXLsKk,b3zpaK4mEd7M69ATcCrPHgBwRUFtx,url,rRxld1HykSCacZs0mzWXIBibn)
		if not QUwv4Or2m3XJSYVkuAhqlPT15G0zx: return
		rpe3TM9xK7mDJOozLStc = len(kgMZiO2W4rVfTqxuz9NlA0QK)
	for CQtNwXGVAJ2y5nBY,url,rRxld1HykSCacZs0mzWXIBibn in EEVJf2i3eBSQMUda+a9ls2BfZ5oTtYe7+kgMZiO2W4rVfTqxuz9NlA0QK:
		fSNgKz476uAQsicDFI = MvTRSH40qWe8Pyh3ZNVorBiutLm(CQtNwXGVAJ2y5nBY,url,rRxld1HykSCacZs0mzWXIBibn)
	return
def MvTRSH40qWe8Pyh3ZNVorBiutLm(CQtNwXGVAJ2y5nBY,url=nA5dhMRg6ENzsB0l1GwvH7aIr2,rRxld1HykSCacZs0mzWXIBibn=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if '::' in rRxld1HykSCacZs0mzWXIBibn: level,d9ygXDE7eLHjYkZB,Ct6971kvqrJmbHFlQNAZ5siBYK,bBd2oZ9HMU8AzufIW = rRxld1HykSCacZs0mzWXIBibn.split('::')
	else: level,d9ygXDE7eLHjYkZB,Ct6971kvqrJmbHFlQNAZ5siBYK,bBd2oZ9HMU8AzufIW = '1','0','0','0'
	zTEXepHg92GkWf,title,ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,count,yoaKx7FtIlvcD,C1Ki8DwvYomIOl,gFSau2s1WH0rPMRKjJyQ,B7lPJkSvfTz = hP1WCdOlUQEixVkT36nHpX9qD(CQtNwXGVAJ2y5nBY)
	DlpFSrMqI59h = '/videos?' in ZylHkumQ8zD0 or '/streams?' in ZylHkumQ8zD0 or '/playlists?' in ZylHkumQ8zD0
	D7DteBEYizwmqPrLFc0SKosVp = '/channels?' in ZylHkumQ8zD0 or '/shorts?' in ZylHkumQ8zD0
	if DlpFSrMqI59h or D7DteBEYizwmqPrLFc0SKosVp: ZylHkumQ8zD0 = url
	DlpFSrMqI59h = 'watch?v=' not in ZylHkumQ8zD0 and '/playlist?list=' not in ZylHkumQ8zD0
	D7DteBEYizwmqPrLFc0SKosVp = '/gaming' not in ZylHkumQ8zD0  and '/feed/storefront' not in ZylHkumQ8zD0
	if rRxld1HykSCacZs0mzWXIBibn[0:5]=='3::0::' and DlpFSrMqI59h and D7DteBEYizwmqPrLFc0SKosVp: ZylHkumQ8zD0 = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in ZylHkumQ8zD0:
		level,d9ygXDE7eLHjYkZB,Ct6971kvqrJmbHFlQNAZ5siBYK,bBd2oZ9HMU8AzufIW = '1','0','0','0'
		rRxld1HykSCacZs0mzWXIBibn = nA5dhMRg6ENzsB0l1GwvH7aIr2
	rA4ZGoQyIHlneVfzNukWd = nA5dhMRg6ENzsB0l1GwvH7aIr2
	if '/youtubei/v1/browse' in ZylHkumQ8zD0 or '/youtubei/v1/search' in ZylHkumQ8zD0 or '/my_main_page_shorts_link' in url:
		data = KQctJbXeEjDhplqknU3rzi.getSetting('av.youtube.data')
		if data.count(':::')==4:
			DKJgUxk2Y8bG5vpQ,key,etsbrUY2KFoGliwWIdf9CA7gJj5Z4,LLEaTSZWh1JNo,IXtUCDoBP4GlHz7kN = data.split(':::')
			rA4ZGoQyIHlneVfzNukWd = DKJgUxk2Y8bG5vpQ+':::'+key+':::'+etsbrUY2KFoGliwWIdf9CA7gJj5Z4+':::'+LLEaTSZWh1JNo+':::'+B7lPJkSvfTz
			if '/my_main_page_shorts_link' in url and not ZylHkumQ8zD0: ZylHkumQ8zD0 = url
			else: ZylHkumQ8zD0 = ZylHkumQ8zD0+'?key='+key
	if not title:
		global sW4uZLyomIbza
		sW4uZLyomIbza += 1
		title = 'فيديوهات '+str(sW4uZLyomIbza)
		rRxld1HykSCacZs0mzWXIBibn = '3'+'::'+d9ygXDE7eLHjYkZB+'::'+Ct6971kvqrJmbHFlQNAZ5siBYK+'::'+bBd2oZ9HMU8AzufIW
	if not zTEXepHg92GkWf: return False
	elif 'searchPyvRenderer' in str(CQtNwXGVAJ2y5nBY): return False
	elif '/about' in ZylHkumQ8zD0: return False
	elif '/community' in ZylHkumQ8zD0: return False
	elif 'continuationItemRenderer' in list(CQtNwXGVAJ2y5nBY.keys()) or 'continuationCommand' in list(CQtNwXGVAJ2y5nBY.keys()):
		if int(level)>1: level = str(int(level)-1)
		rRxld1HykSCacZs0mzWXIBibn = level+'::'+d9ygXDE7eLHjYkZB+'::'+Ct6971kvqrJmbHFlQNAZ5siBYK+'::'+bBd2oZ9HMU8AzufIW
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+':: '+'صفحة أخرى',ZylHkumQ8zD0,144,HRlygv7YwjzbSLt8fkEerq2,rRxld1HykSCacZs0mzWXIBibn,rA4ZGoQyIHlneVfzNukWd)
	elif '/search' in ZylHkumQ8zD0:
		title = ':: '+title
		rRxld1HykSCacZs0mzWXIBibn = '3'+'::'+d9ygXDE7eLHjYkZB+'::'+Ct6971kvqrJmbHFlQNAZ5siBYK+'::'+bBd2oZ9HMU8AzufIW
		url = url.replace('/search',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,145,nA5dhMRg6ENzsB0l1GwvH7aIr2,rRxld1HykSCacZs0mzWXIBibn,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not ZylHkumQ8zD0:
		rRxld1HykSCacZs0mzWXIBibn = '3'+'::'+d9ygXDE7eLHjYkZB+'::'+Ct6971kvqrJmbHFlQNAZ5siBYK+'::'+bBd2oZ9HMU8AzufIW
		title = ':: '+title
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,144,HRlygv7YwjzbSLt8fkEerq2,rRxld1HykSCacZs0mzWXIBibn,rA4ZGoQyIHlneVfzNukWd)
	elif '/browse' in ZylHkumQ8zD0 and url==GiqvpBF9xLEdHDr37byJSngeCQ:
		title = ':: '+title
		rRxld1HykSCacZs0mzWXIBibn = '2::0::0::0'
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,144,HRlygv7YwjzbSLt8fkEerq2,rRxld1HykSCacZs0mzWXIBibn,rA4ZGoQyIHlneVfzNukWd)
	elif not ZylHkumQ8zD0 and 'horizontalMovieListRenderer' in str(CQtNwXGVAJ2y5nBY):
		title = ':: '+title
		rRxld1HykSCacZs0mzWXIBibn = '3::0::0::0'
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,144,HRlygv7YwjzbSLt8fkEerq2,rRxld1HykSCacZs0mzWXIBibn)
	elif 'messageRenderer' in str(CQtNwXGVAJ2y5nBY):
		TBt8bUDo9WhL('link',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	elif C1Ki8DwvYomIOl:
		TBt8bUDo9WhL('live',DjKrTPWEFw2YeCi5d6unBqhZSlAR+C1Ki8DwvYomIOl+title,ZylHkumQ8zD0,143,HRlygv7YwjzbSLt8fkEerq2)
	elif '/playlist?list=' in ZylHkumQ8zD0:
		ZylHkumQ8zD0 = ZylHkumQ8zD0.replace('&playnext=1',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'LIST'+count+':  '+title,ZylHkumQ8zD0,144,HRlygv7YwjzbSLt8fkEerq2,rRxld1HykSCacZs0mzWXIBibn)
	elif '/shorts/' in ZylHkumQ8zD0:
		ZylHkumQ8zD0 = ZylHkumQ8zD0.split('&list=',1)[0]
		TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,143,HRlygv7YwjzbSLt8fkEerq2,yoaKx7FtIlvcD)
	elif '/watch?v=' in ZylHkumQ8zD0:
		if '&list=' in ZylHkumQ8zD0 and count:
			dobL8Jit3Syuhm7Ma2fgWUzBOnYr = ZylHkumQ8zD0.split('&list=',1)[1]
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/playlist?list='+dobL8Jit3Syuhm7Ma2fgWUzBOnYr
			rRxld1HykSCacZs0mzWXIBibn = '1::0::0::0'
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'LIST'+count+':  '+title,ZylHkumQ8zD0,144,HRlygv7YwjzbSLt8fkEerq2,rRxld1HykSCacZs0mzWXIBibn)
		else:
			ZylHkumQ8zD0 = ZylHkumQ8zD0.split('&list=',1)[0]
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,143,HRlygv7YwjzbSLt8fkEerq2,yoaKx7FtIlvcD)
	elif '/channel/' in ZylHkumQ8zD0 or '/c/' in ZylHkumQ8zD0 or ('/@' in ZylHkumQ8zD0 and ZylHkumQ8zD0.count('/')==3):
		if cS2NYw4xulqJgvzkMF:
			title = title.decode(YWEQ3Cf8RevpD0m7NjF1).encode('raw_unicode_escape')
			title = jPgzFLH1niJpE2r(title)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'CHNL'+count+':  '+title,ZylHkumQ8zD0,144,HRlygv7YwjzbSLt8fkEerq2,rRxld1HykSCacZs0mzWXIBibn)
	elif '/user/' in ZylHkumQ8zD0:
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'USER'+count+':  '+title,ZylHkumQ8zD0,144,HRlygv7YwjzbSLt8fkEerq2,rRxld1HykSCacZs0mzWXIBibn)
	else:
		if not ZylHkumQ8zD0: ZylHkumQ8zD0 = url
		title = ':: '+title
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,144,HRlygv7YwjzbSLt8fkEerq2,rRxld1HykSCacZs0mzWXIBibn,rA4ZGoQyIHlneVfzNukWd)
	return True
def hP1WCdOlUQEixVkT36nHpX9qD(CQtNwXGVAJ2y5nBY):
	zTEXepHg92GkWf,title,ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,count,yoaKx7FtIlvcD,C1Ki8DwvYomIOl,gFSau2s1WH0rPMRKjJyQ,IXtUCDoBP4GlHz7kN = False,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	if not isinstance(CQtNwXGVAJ2y5nBY,dict): return zTEXepHg92GkWf,title,ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,count,yoaKx7FtIlvcD,C1Ki8DwvYomIOl,gFSau2s1WH0rPMRKjJyQ,IXtUCDoBP4GlHz7kN
	for gvTYVNyHxXRprAF8OQcSImBtUqPC0 in list(CQtNwXGVAJ2y5nBY.keys()):
		LIPFEUMqS5vkKs4z1YNwiVrjbRgo = CQtNwXGVAJ2y5nBY[gvTYVNyHxXRprAF8OQcSImBtUqPC0]
		if isinstance(LIPFEUMqS5vkKs4z1YNwiVrjbRgo,dict): break
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp = []
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['header']['playlistHeaderRenderer']['title']['simpleText']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['header']['richListHeaderRenderer']['title']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['headline']['simpleText']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['unplayableText']['simpleText']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['formattedTitle']['simpleText']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['title']['simpleText']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['title']['runs'][0]['text']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['text']['simpleText']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['text']['runs'][0]['text']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['title']['content']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['title']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("item['title']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("item['reelWatchEndpoint']['videoId']")
	zTEXepHg92GkWf,title,Ns6egmVv7nRutdLSQUaE8WFq5 = mL4KUNQ6VBSO1FEk2pitlsy7o5Wa(CQtNwXGVAJ2y5nBY,LIPFEUMqS5vkKs4z1YNwiVrjbRgo,mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp)
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp = []
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("item['commandMetadata']['webCommandMetadata']['url']")
	zTEXepHg92GkWf,ZylHkumQ8zD0,Ns6egmVv7nRutdLSQUaE8WFq5 = mL4KUNQ6VBSO1FEk2pitlsy7o5Wa(CQtNwXGVAJ2y5nBY,LIPFEUMqS5vkKs4z1YNwiVrjbRgo,mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp)
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp = []
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['thumbnail']['thumbnails'][0]['url']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	zTEXepHg92GkWf,HRlygv7YwjzbSLt8fkEerq2,Ns6egmVv7nRutdLSQUaE8WFq5 = mL4KUNQ6VBSO1FEk2pitlsy7o5Wa(CQtNwXGVAJ2y5nBY,LIPFEUMqS5vkKs4z1YNwiVrjbRgo,mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp)
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp = []
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['videoCountShortText']['simpleText']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['videoCountText']['runs'][0]['text']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['videoCount']")
	zTEXepHg92GkWf,count,Ns6egmVv7nRutdLSQUaE8WFq5 = mL4KUNQ6VBSO1FEk2pitlsy7o5Wa(CQtNwXGVAJ2y5nBY,LIPFEUMqS5vkKs4z1YNwiVrjbRgo,mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp)
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp = []
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['lengthText']['simpleText']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	zTEXepHg92GkWf,yoaKx7FtIlvcD,Ns6egmVv7nRutdLSQUaE8WFq5 = mL4KUNQ6VBSO1FEk2pitlsy7o5Wa(CQtNwXGVAJ2y5nBY,LIPFEUMqS5vkKs4z1YNwiVrjbRgo,mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp)
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp = []
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	zTEXepHg92GkWf,IXtUCDoBP4GlHz7kN,Ns6egmVv7nRutdLSQUaE8WFq5 = mL4KUNQ6VBSO1FEk2pitlsy7o5Wa(CQtNwXGVAJ2y5nBY,LIPFEUMqS5vkKs4z1YNwiVrjbRgo,mOoeyK1YuhVcfxAD0w67Z4ntrR3Ugp)
	if 'LIVE' in yoaKx7FtIlvcD: yoaKx7FtIlvcD,C1Ki8DwvYomIOl = nA5dhMRg6ENzsB0l1GwvH7aIr2,'LIVE:  '
	if 'مباشر' in yoaKx7FtIlvcD: yoaKx7FtIlvcD,C1Ki8DwvYomIOl = nA5dhMRg6ENzsB0l1GwvH7aIr2,'LIVE:  '
	if 'badges' in list(LIPFEUMqS5vkKs4z1YNwiVrjbRgo.keys()):
		IQZ5s4vkL017R2doaCXcmUHn = str(LIPFEUMqS5vkKs4z1YNwiVrjbRgo['badges'])
		if 'Free with Ads' in IQZ5s4vkL017R2doaCXcmUHn: gFSau2s1WH0rPMRKjJyQ = '$:  '
		if 'LIVE' in IQZ5s4vkL017R2doaCXcmUHn: C1Ki8DwvYomIOl = 'LIVE:  '
		if 'Buy' in IQZ5s4vkL017R2doaCXcmUHn or 'Rent' in IQZ5s4vkL017R2doaCXcmUHn: gFSau2s1WH0rPMRKjJyQ = '$$:  '
		if ekQTdRyiGNCuj6bhgwx4(u'مباشر') in IQZ5s4vkL017R2doaCXcmUHn: C1Ki8DwvYomIOl = 'LIVE:  '
		if ekQTdRyiGNCuj6bhgwx4(u'شراء') in IQZ5s4vkL017R2doaCXcmUHn: gFSau2s1WH0rPMRKjJyQ = '$$:  '
		if ekQTdRyiGNCuj6bhgwx4(u'استئجار') in IQZ5s4vkL017R2doaCXcmUHn: gFSau2s1WH0rPMRKjJyQ = '$$:  '
		if ekQTdRyiGNCuj6bhgwx4(u'إعلانات') in IQZ5s4vkL017R2doaCXcmUHn: gFSau2s1WH0rPMRKjJyQ = '$:  '
	ZylHkumQ8zD0 = jPgzFLH1niJpE2r(ZylHkumQ8zD0)
	if ZylHkumQ8zD0 and 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
	HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2.split('?')[0]
	if  HRlygv7YwjzbSLt8fkEerq2 and 'http' not in HRlygv7YwjzbSLt8fkEerq2: HRlygv7YwjzbSLt8fkEerq2 = 'https:'+HRlygv7YwjzbSLt8fkEerq2
	title = jPgzFLH1niJpE2r(title)
	if gFSau2s1WH0rPMRKjJyQ: title = gFSau2s1WH0rPMRKjJyQ+title
	yoaKx7FtIlvcD = yoaKx7FtIlvcD.replace(',',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	count = count.replace(',',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	count = PAztbuyYo4Kvd.findall('\d+',count)
	if count: count = count[0]
	else: count = nA5dhMRg6ENzsB0l1GwvH7aIr2
	return True,title,ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,count,yoaKx7FtIlvcD,C1Ki8DwvYomIOl,gFSau2s1WH0rPMRKjJyQ,IXtUCDoBP4GlHz7kN
def aUJF2W73zVCEqQRiZYdD1pyI4(url,data=nA5dhMRg6ENzsB0l1GwvH7aIr2,YsdSH10ta6wvi4nMRIO9=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if YsdSH10ta6wvi4nMRIO9==nA5dhMRg6ENzsB0l1GwvH7aIr2: YsdSH10ta6wvi4nMRIO9 = 'ytInitialData'
	cgob7MO2qshG = oOb8ZS417GwudNKHU6y()
	LevQwm0pbqP1 = {'User-Agent':cgob7MO2qshG,'Cookie':'PREF=hl=ar'}
	global KQctJbXeEjDhplqknU3rzi
	if not data: data = KQctJbXeEjDhplqknU3rzi.getSetting('av.youtube.data')
	if data.count(':::')==4: DKJgUxk2Y8bG5vpQ,key,etsbrUY2KFoGliwWIdf9CA7gJj5Z4,LLEaTSZWh1JNo,IXtUCDoBP4GlHz7kN = data.split(':::')
	else: DKJgUxk2Y8bG5vpQ,key,etsbrUY2KFoGliwWIdf9CA7gJj5Z4,LLEaTSZWh1JNo,IXtUCDoBP4GlHz7kN = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	rA4ZGoQyIHlneVfzNukWd = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":etsbrUY2KFoGliwWIdf9CA7gJj5Z4}}}
	if url==GiqvpBF9xLEdHDr37byJSngeCQ+'/shorts' or '/my_main_page_shorts_link' in url:
		url = GiqvpBF9xLEdHDr37byJSngeCQ+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		rA4ZGoQyIHlneVfzNukWd['sequenceParams'] = DKJgUxk2Y8bG5vpQ
		rA4ZGoQyIHlneVfzNukWd = str(rA4ZGoQyIHlneVfzNukWd)
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,'POST',url,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = GiqvpBF9xLEdHDr37byJSngeCQ+'/youtubei/v1/guide?key='+key
		rA4ZGoQyIHlneVfzNukWd = str(rA4ZGoQyIHlneVfzNukWd)
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,'POST',url,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and DKJgUxk2Y8bG5vpQ:
		rA4ZGoQyIHlneVfzNukWd['continuation'] = IXtUCDoBP4GlHz7kN
		rA4ZGoQyIHlneVfzNukWd['context']['client']['visitorData'] = DKJgUxk2Y8bG5vpQ
		rA4ZGoQyIHlneVfzNukWd = str(rA4ZGoQyIHlneVfzNukWd)
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,'POST',url,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and LLEaTSZWh1JNo:
		LevQwm0pbqP1.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':etsbrUY2KFoGliwWIdf9CA7gJj5Z4})
		LevQwm0pbqP1.update({'Cookie':'VISITOR_INFO1_LIVE='+LLEaTSZWh1JNo})
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,LevQwm0pbqP1,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'YOUTUBE-GET_PAGE_DATA-5th')
	else:
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,LevQwm0pbqP1,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'YOUTUBE-GET_PAGE_DATA-6th')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	wU70GYa1jm3Kk = PAztbuyYo4Kvd.findall('"innertubeApiKey".*?"(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL|PAztbuyYo4Kvd.I)
	if wU70GYa1jm3Kk: key = wU70GYa1jm3Kk[0]
	wU70GYa1jm3Kk = PAztbuyYo4Kvd.findall('"cver".*?"value".*?"(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL|PAztbuyYo4Kvd.I)
	if wU70GYa1jm3Kk: etsbrUY2KFoGliwWIdf9CA7gJj5Z4 = wU70GYa1jm3Kk[0]
	wU70GYa1jm3Kk = PAztbuyYo4Kvd.findall('"visitorData".*?"(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL|PAztbuyYo4Kvd.I)
	if wU70GYa1jm3Kk: DKJgUxk2Y8bG5vpQ = wU70GYa1jm3Kk[0]
	cookies = Y3SmVGbfNvEeakMBr.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): LLEaTSZWh1JNo = cookies['VISITOR_INFO1_LIVE']
	GnCJElcXiOjWPvufk8gxU = DKJgUxk2Y8bG5vpQ+':::'+key+':::'+etsbrUY2KFoGliwWIdf9CA7gJj5Z4+':::'+LLEaTSZWh1JNo+':::'+IXtUCDoBP4GlHz7kN
	if YsdSH10ta6wvi4nMRIO9=='ytInitialData' and 'ytInitialData' in kl2ZWdy8rXcHT:
		Bu8WPsyviVUnMEHdwr3xo9fOYlN = PAztbuyYo4Kvd.findall('window\["ytInitialData"\] = ({.*?});',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if not Bu8WPsyviVUnMEHdwr3xo9fOYlN: Bu8WPsyviVUnMEHdwr3xo9fOYlN = PAztbuyYo4Kvd.findall('var ytInitialData = ({.*?});',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		DDqvPVfr18SNbyE3 = BwGPDSQOlfUas2n3eIH0ycFRWZ('str',Bu8WPsyviVUnMEHdwr3xo9fOYlN[0])
	elif YsdSH10ta6wvi4nMRIO9=='ytInitialGuideData' and 'ytInitialGuideData' in kl2ZWdy8rXcHT:
		Bu8WPsyviVUnMEHdwr3xo9fOYlN = PAztbuyYo4Kvd.findall('var ytInitialGuideData = ({.*?});',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		DDqvPVfr18SNbyE3 = BwGPDSQOlfUas2n3eIH0ycFRWZ('str',Bu8WPsyviVUnMEHdwr3xo9fOYlN[0])
	elif '</script>' not in kl2ZWdy8rXcHT: DDqvPVfr18SNbyE3 = BwGPDSQOlfUas2n3eIH0ycFRWZ('str',kl2ZWdy8rXcHT)
	else: DDqvPVfr18SNbyE3 = nA5dhMRg6ENzsB0l1GwvH7aIr2
	if 0:
		TIV7unFaebyoj35WMrgXLsKk = str(DDqvPVfr18SNbyE3)
		if BsLJ7p5Av2Vm0SQeCO1o: TIV7unFaebyoj35WMrgXLsKk = TIV7unFaebyoj35WMrgXLsKk.encode(YWEQ3Cf8RevpD0m7NjF1)
		open('S:\\0000emad.dat','wb').write(TIV7unFaebyoj35WMrgXLsKk)
	KQctJbXeEjDhplqknU3rzi.setSetting('av.youtube.data',GnCJElcXiOjWPvufk8gxU)
	return kl2ZWdy8rXcHT,DDqvPVfr18SNbyE3,GnCJElcXiOjWPvufk8gxU
def ccZu8TyQ5vdohlnENbp4qixKOr(url,rRxld1HykSCacZs0mzWXIBibn):
	search = FaUBpzTGxtS7hZyl()
	if not search: return
	search = search.replace(hSXlxL9iB05c,'+')
	KteRnFMjHpBPqNf8 = url+'/search?query='+search
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(KteRnFMjHpBPqNf8,rRxld1HykSCacZs0mzWXIBibn)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if not search:
		search = FaUBpzTGxtS7hZyl()
		if not search: return
	search = search.replace(hSXlxL9iB05c,'+')
	KteRnFMjHpBPqNf8 = GiqvpBF9xLEdHDr37byJSngeCQ+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in m0YJ3feqUjD7: t8uDxMmbsCT = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in m0YJ3feqUjD7: t8uDxMmbsCT = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in m0YJ3feqUjD7: t8uDxMmbsCT = '&sp=EgIQAg%253D%253D'
		else: t8uDxMmbsCT = nA5dhMRg6ENzsB0l1GwvH7aIr2
		w7Ol6FnokgJDSsIt = KteRnFMjHpBPqNf8+t8uDxMmbsCT
	else:
		XYMOg6GS1h024lU9r,k2AZDQPeJmV04a9YwK1fI,g7qwMTAPoVpIyQUaDeNOnhvs = [],[],nA5dhMRg6ENzsB0l1GwvH7aIr2
		wwUoN9L2EAhHT = ['فيديوهات مرتبة بالصلة','فيديوهات مرتبة بالتاريخ','فيديوهات مرتبة بعدد المشاهدات','فيديوهات مرتبة بالتقييم','(جيد للمسلسلات) قوائم تشغيل','قنوات','بث حي']
		G3CwZ2bRa9hvHqxyQW = ['&sp=CAASAhAB','&sp=CAISAhAB','&sp=CAMSAhAB','&sp=CAESAhAB','&sp=EgIQAw==','&sp=EgIQAg==','&sp=EgJAAQ==']
		wnFP190qKeT4bgiDOroluU5Sf7MkXh = ccAMwn7hflDev8Kd3aqP('اختر البحث المناسب',wwUoN9L2EAhHT)
		if wnFP190qKeT4bgiDOroluU5Sf7MkXh == -1: return
		xxydg3tRv2CDT4LMhJAVGB = G3CwZ2bRa9hvHqxyQW[wnFP190qKeT4bgiDOroluU5Sf7MkXh]
		kl2ZWdy8rXcHT,DUs7RxlEHn,data = aUJF2W73zVCEqQRiZYdD1pyI4(KteRnFMjHpBPqNf8+xxydg3tRv2CDT4LMhJAVGB)
		if DUs7RxlEHn:
			try:
				kbV1wKRiDL96r87MmIcPB = DUs7RxlEHn['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for H68HLJRdUvt1bEmsWaiuS in range(len(kbV1wKRiDL96r87MmIcPB)):
					group = kbV1wKRiDL96r87MmIcPB[H68HLJRdUvt1bEmsWaiuS]['searchFilterGroupRenderer']['filters']
					for wlIOByWr94AeNpXUukTmhjb in range(len(group)):
						LIPFEUMqS5vkKs4z1YNwiVrjbRgo = group[wlIOByWr94AeNpXUukTmhjb]['searchFilterRenderer']
						if 'navigationEndpoint' in list(LIPFEUMqS5vkKs4z1YNwiVrjbRgo.keys()):
							ZylHkumQ8zD0 = LIPFEUMqS5vkKs4z1YNwiVrjbRgo['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							ZylHkumQ8zD0 = ZylHkumQ8zD0.replace('\u0026','&')
							title = LIPFEUMqS5vkKs4z1YNwiVrjbRgo['tooltip']
							title = title.replace('البحث عن ',nA5dhMRg6ENzsB0l1GwvH7aIr2)
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								g7qwMTAPoVpIyQUaDeNOnhvs = title
								ww5oBKPZmc = ZylHkumQ8zD0
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ',nA5dhMRg6ENzsB0l1GwvH7aIr2)
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								g7qwMTAPoVpIyQUaDeNOnhvs = title
								ww5oBKPZmc = ZylHkumQ8zD0
							if 'Sort by' in title: continue
							XYMOg6GS1h024lU9r.append(jPgzFLH1niJpE2r(title))
							k2AZDQPeJmV04a9YwK1fI.append(ZylHkumQ8zD0)
			except: pass
		if not g7qwMTAPoVpIyQUaDeNOnhvs: tpYqlFRTsEaimIBGV = nA5dhMRg6ENzsB0l1GwvH7aIr2
		else:
			XYMOg6GS1h024lU9r = ['بدون فلتر',g7qwMTAPoVpIyQUaDeNOnhvs]+XYMOg6GS1h024lU9r
			k2AZDQPeJmV04a9YwK1fI = [nA5dhMRg6ENzsB0l1GwvH7aIr2,ww5oBKPZmc]+k2AZDQPeJmV04a9YwK1fI
			ugnHONvRa5ej7Q1DyqVZd = ccAMwn7hflDev8Kd3aqP('موقع يوتيوب - اختر الفلتر',XYMOg6GS1h024lU9r)
			if ugnHONvRa5ej7Q1DyqVZd == -1: return
			tpYqlFRTsEaimIBGV = k2AZDQPeJmV04a9YwK1fI[ugnHONvRa5ej7Q1DyqVZd]
		if tpYqlFRTsEaimIBGV: w7Ol6FnokgJDSsIt = GiqvpBF9xLEdHDr37byJSngeCQ+tpYqlFRTsEaimIBGV
		elif xxydg3tRv2CDT4LMhJAVGB: w7Ol6FnokgJDSsIt = KteRnFMjHpBPqNf8+xxydg3tRv2CDT4LMhJAVGB
		else: w7Ol6FnokgJDSsIt = KteRnFMjHpBPqNf8
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(w7Ol6FnokgJDSsIt)
	return
# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'ALFATIMI'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_FTM_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
K6VDzZo8Gl = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
BsqYhcgwE8yNi6apf = ['3030','628']
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==60: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==61: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,text)
	elif mode==62: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LLabVp7hzj28CE0f1udx(url)
	elif mode==63: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==64: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = Ty5QSuxPZwEKWXoUkgz9HGId1(text)
	elif mode==69: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,69,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'ما يتم مشاهدته الان',GiqvpBF9xLEdHDr37byJSngeCQ,64,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'recent_viewed_vids')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الاكثر مشاهدة',GiqvpBF9xLEdHDr37byJSngeCQ,64,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'most_viewed_vids')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'اضيفت مؤخرا',GiqvpBF9xLEdHDr37byJSngeCQ,64,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'recently_added_vids')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فيديو عشوائي',GiqvpBF9xLEdHDr37byJSngeCQ,64,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'random_vids')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'افلام ومسلسلات',GiqvpBF9xLEdHDr37byJSngeCQ,61,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'-1')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'البرامج الدينية',GiqvpBF9xLEdHDr37byJSngeCQ,61,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'-2')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'English Videos',GiqvpBF9xLEdHDr37byJSngeCQ,61,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'-3')
	return nA5dhMRg6ENzsB0l1GwvH7aIr2
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,kvfOU7Tpz958QBqnIlaAePLys):
	UU1zr3DIiYFd6 = nA5dhMRg6ENzsB0l1GwvH7aIr2
	if kvfOU7Tpz958QBqnIlaAePLys not in ['-1','-2','-3']: UU1zr3DIiYFd6 = '?cat='+kvfOU7Tpz958QBqnIlaAePLys
	KteRnFMjHpBPqNf8 = GiqvpBF9xLEdHDr37byJSngeCQ+'/menu_level.php'+UU1zr3DIiYFd6
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ALFATIMI-TITLES-1st')
	items = PAztbuyYo4Kvd.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	Al43MnrKjDdq,Fb5sZyTgJ8Mz6WiRUDo = False,False
	for ZylHkumQ8zD0,title,count in items:
		title = HH8SJuswDBPtniebmkXIr(title)
		title = title.strip(hSXlxL9iB05c)
		if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = 'http:'+ZylHkumQ8zD0
		UU1zr3DIiYFd6 = PAztbuyYo4Kvd.findall('cat=(.*?)&',ZylHkumQ8zD0,PAztbuyYo4Kvd.DOTALL)[0]
		if kvfOU7Tpz958QBqnIlaAePLys==UU1zr3DIiYFd6: Al43MnrKjDdq = True
		elif Al43MnrKjDdq 	or (kvfOU7Tpz958QBqnIlaAePLys=='-1' and UU1zr3DIiYFd6 in K6VDzZo8Gl)  						or (kvfOU7Tpz958QBqnIlaAePLys=='-2' and UU1zr3DIiYFd6 not in BsqYhcgwE8yNi6apf and UU1zr3DIiYFd6 not in K6VDzZo8Gl)  						or (kvfOU7Tpz958QBqnIlaAePLys=='-3' and UU1zr3DIiYFd6 in BsqYhcgwE8yNi6apf):
							if count=='1': TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,63)
							else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,61,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,UU1zr3DIiYFd6)
							Fb5sZyTgJ8Mz6WiRUDo = True
	if not Fb5sZyTgJ8Mz6WiRUDo: LLabVp7hzj28CE0f1udx(url)
	return
def LLabVp7hzj28CE0f1udx(url):
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,True,'ALFATIMI-EPISODES-1st')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('pagination(.*?)id="footer',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	ZylHkumQ8zD0 = nA5dhMRg6ENzsB0l1GwvH7aIr2
	for HRlygv7YwjzbSLt8fkEerq2,title,ZylHkumQ8zD0 in items:
		title = title.replace('Add',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('to Quicklist',nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c)
		if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = 'http:'+ZylHkumQ8zD0
		TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,63,HRlygv7YwjzbSLt8fkEerq2)
	zz3eHskxE6lAyDR5cNj1ug=PAztbuyYo4Kvd.findall('(.*?)div',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX=zz3eHskxE6lAyDR5cNj1ug[0]
	WWU7QJP2tyTRLIfDh0csxbkvX=PAztbuyYo4Kvd.findall('pagination(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)[0]
	items=PAztbuyYo4Kvd.findall('href="(.*?)".*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	KteRnFMjHpBPqNf8 = url.split('?')[0]
	for ZylHkumQ8zD0,QQGubA8tRnHSPaXLKod4zMEFpjfcl in items:
		ZylHkumQ8zD0 = KteRnFMjHpBPqNf8 + ZylHkumQ8zD0
		title = HH8SJuswDBPtniebmkXIr(QQGubA8tRnHSPaXLKod4zMEFpjfcl)
		title = 'صفحة ' + title
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,62)
	return ZylHkumQ8zD0
def lNBcUr8RCn(url):
	if 'videos.php' in url: url = LLabVp7hzj28CE0f1udx(url)
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,True,'ALFATIMI-PLAY-1st')
	items = PAztbuyYo4Kvd.findall('playlistfile:"(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	ocUnzjShqIO35vZi8bk64pVKMCTBaw(url,wgj0rX5tbcxPulhmny,'video')
	return
def Ty5QSuxPZwEKWXoUkgz9HGId1(kvfOU7Tpz958QBqnIlaAePLys):
	hwZT5nYUGQ1RJC = { 'mode' : kvfOU7Tpz958QBqnIlaAePLys }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = U5gRdGyK1L90nskaxElqmiT4(hwZT5nYUGQ1RJC)
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(lPsYQwWdLO520ZHcFV8n1x,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = PAztbuyYo4Kvd.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title,HRlygv7YwjzbSLt8fkEerq2 in items:
		title = title.strip(hSXlxL9iB05c)
		if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = 'http:'+ZylHkumQ8zD0
		TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,63,HRlygv7YwjzbSLt8fkEerq2)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	SEGtTsCyUVi0lo4LJkH5 = search.replace(hSXlxL9iB05c,'+')
	url = GiqvpBF9xLEdHDr37byJSngeCQ + '/search_result.php?query=' + SEGtTsCyUVi0lo4LJkH5
	LLabVp7hzj28CE0f1udx(url)
	return
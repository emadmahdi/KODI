# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'LIVETV'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS['PYTHON'][0]
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url):
	if   mode==100: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==101: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = qTPzY96jGk8mQcNK3XvVHMUR4('0',True)
	elif mode==102: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = qTPzY96jGk8mQcNK3XvVHMUR4('1',True)
	elif mode==103: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = qTPzY96jGk8mQcNK3XvVHMUR4('2',True)
	elif mode==104: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = qTPzY96jGk8mQcNK3XvVHMUR4('3',True)
	elif mode==105: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==106: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = qTPzY96jGk8mQcNK3XvVHMUR4('4',True)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder','_M3U_'+'قوائم فيديوهات M3U',nA5dhMRg6ENzsB0l1GwvH7aIr2,762)
	TBt8bUDo9WhL('folder','_IPT_'+'قوائم فيديوهات IPTV',nA5dhMRg6ENzsB0l1GwvH7aIr2,761)
	TBt8bUDo9WhL('folder','_TV0_'+'قنوات من مواقعها الأصلية',nA5dhMRg6ENzsB0l1GwvH7aIr2,101)
	TBt8bUDo9WhL('folder','_TV4_'+'قنوات مختارة من يوتيوب',nA5dhMRg6ENzsB0l1GwvH7aIr2,106)
	TBt8bUDo9WhL('folder','_YUT_'+'قنوات عربية من يوتيوب',nA5dhMRg6ENzsB0l1GwvH7aIr2,147)
	TBt8bUDo9WhL('folder','_YUT_'+'قنوات أجنبية من يوتيوب',nA5dhMRg6ENzsB0l1GwvH7aIr2,148)
	TBt8bUDo9WhL('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ',nA5dhMRg6ENzsB0l1GwvH7aIr2,28)
	TBt8bUDo9WhL('live','_MRF_'+'قناة المعارف من موقعهم',nA5dhMRg6ENzsB0l1GwvH7aIr2,41)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder','_TV1_'+'قنوات تلفزيونية عامة',nA5dhMRg6ENzsB0l1GwvH7aIr2,102)
	TBt8bUDo9WhL('folder','_TV2_'+'قنوات تلفزيونية خاصة',nA5dhMRg6ENzsB0l1GwvH7aIr2,103)
	TBt8bUDo9WhL('folder','_TV3_'+'قنوات تلفزيونية للفحص',nA5dhMRg6ENzsB0l1GwvH7aIr2,104)
	return
def qTPzY96jGk8mQcNK3XvVHMUR4(K3WkBTmPE0Yynt5baRhA2ILHsOZwC9,showDialogs=True):
	DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_TV'+K3WkBTmPE0Yynt5baRhA2ILHsOZwC9+'_'
	hwZT5nYUGQ1RJC = {'id':nA5dhMRg6ENzsB0l1GwvH7aIr2,'user':Nzp9Fq5cTr.AV_CLIENT_IDS,'function':'list','menu':K3WkBTmPE0Yynt5baRhA2ILHsOZwC9}
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,'POST',GiqvpBF9xLEdHDr37byJSngeCQ,hwZT5nYUGQ1RJC,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'LIVETV-ITEMS-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	items = PAztbuyYo4Kvd.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if items:
		for q3kZpRe28O0s1NaCXQ9SMuGKin in range(len(items)):
			name = items[q3kZpRe28O0s1NaCXQ9SMuGKin][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[q3kZpRe28O0s1NaCXQ9SMuGKin] = items[q3kZpRe28O0s1NaCXQ9SMuGKin][0],items[q3kZpRe28O0s1NaCXQ9SMuGKin][1],items[q3kZpRe28O0s1NaCXQ9SMuGKin][2],name,items[q3kZpRe28O0s1NaCXQ9SMuGKin][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for FjO41UWNvs0Gg,DQ7XgFltujVL,xhqyQAmiYa6FwRM4DO21Jvj,name,HRlygv7YwjzbSLt8fkEerq2 in items:
			if '#' in FjO41UWNvs0Gg: continue
			if FjO41UWNvs0Gg!='URL': name = name+bbTCMJwEx8nhN4X+PwYGfc4gTjiyRlsHn1OE+FjO41UWNvs0Gg+NwROdSj3nsA
			url = FjO41UWNvs0Gg+';;'+DQ7XgFltujVL+';;'+xhqyQAmiYa6FwRM4DO21Jvj+';;'+K3WkBTmPE0Yynt5baRhA2ILHsOZwC9
			TBt8bUDo9WhL('live',DjKrTPWEFw2YeCi5d6unBqhZSlAR+nA5dhMRg6ENzsB0l1GwvH7aIr2+name,url,105,HRlygv7YwjzbSLt8fkEerq2)
	else:
		if showDialogs: TBt8bUDo9WhL('link',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'هذه الخدمة مخصصة للمبرمج فقط',nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	return
def lNBcUr8RCn(id):
	FjO41UWNvs0Gg,DQ7XgFltujVL,xhqyQAmiYa6FwRM4DO21Jvj,K3WkBTmPE0Yynt5baRhA2ILHsOZwC9 = id.split(';;')
	url = nA5dhMRg6ENzsB0l1GwvH7aIr2
	if FjO41UWNvs0Gg=='URL': url = xhqyQAmiYa6FwRM4DO21Jvj
	elif FjO41UWNvs0Gg=='YOUTUBE':
		url = Nzp9Fq5cTr.SITESURLS['YOUTUBE'][0]+'/watch?v='+xhqyQAmiYa6FwRM4DO21Jvj
		import wW9Vexi6dl
		wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM([url],wgj0rX5tbcxPulhmny,'live',url)
		return
	elif FjO41UWNvs0Gg=='GA':
		hwZT5nYUGQ1RJC = { 'id' : nA5dhMRg6ENzsB0l1GwvH7aIr2, 'user' : Nzp9Fq5cTr.AV_CLIENT_IDS , 'function' : 'playGA1' , 'menu' : nA5dhMRg6ENzsB0l1GwvH7aIr2 }
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,hwZT5nYUGQ1RJC,nA5dhMRg6ENzsB0l1GwvH7aIr2,False,nA5dhMRg6ENzsB0l1GwvH7aIr2,'LIVETV-PLAY-1st')
		if not Y3SmVGbfNvEeakMBr.succeeded:
			OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
		cookies = Y3SmVGbfNvEeakMBr.cookies
		BBezsrKop5I8Lx = cookies['ASP.NET_SessionId']
		url = Y3SmVGbfNvEeakMBr.headers['Location']
		hwZT5nYUGQ1RJC = { 'id' : xhqyQAmiYa6FwRM4DO21Jvj , 'user' : Nzp9Fq5cTr.AV_CLIENT_IDS , 'function' : 'playGA2' , 'menu' : nA5dhMRg6ENzsB0l1GwvH7aIr2 }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+BBezsrKop5I8Lx }
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,hwZT5nYUGQ1RJC,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'LIVETV-PLAY-2nd')
		if not Y3SmVGbfNvEeakMBr.succeeded:
			OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
		url = PAztbuyYo4Kvd.findall('resp":"(http.*?m3u8)(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		ZylHkumQ8zD0 = url[0][0]
		gtlFezGU5H1dKi8k = url[0][1]
		GkUcoSQ5C9rJlyT = 'http://38.'+DQ7XgFltujVL+'777/'+xhqyQAmiYa6FwRM4DO21Jvj+'_HD.m3u8'+gtlFezGU5H1dKi8k
		Q8Z427xMa6OjiVvreqhRfN = GkUcoSQ5C9rJlyT.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		EvnwzxCK6BPqpZS5hFbeiaMkLQ = GkUcoSQ5C9rJlyT.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		ecU4Hy7lNS = ['HD','SD1','SD2']
		ce9zAaVFswSq6lLr82DfQyotGW = [GkUcoSQ5C9rJlyT,Q8Z427xMa6OjiVvreqhRfN,EvnwzxCK6BPqpZS5hFbeiaMkLQ]
		iP7AUR41exzlKyZIf9Mt3u = 0
		if iP7AUR41exzlKyZIf9Mt3u == -1: return
		else: url = ce9zAaVFswSq6lLr82DfQyotGW[iP7AUR41exzlKyZIf9Mt3u]
	elif FjO41UWNvs0Gg=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		hwZT5nYUGQ1RJC = { 'id' : xhqyQAmiYa6FwRM4DO21Jvj , 'user' : Nzp9Fq5cTr.AV_CLIENT_IDS , 'function' : 'playNT' , 'menu' : K3WkBTmPE0Yynt5baRhA2ILHsOZwC9 }
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,'POST', GiqvpBF9xLEdHDr37byJSngeCQ, hwZT5nYUGQ1RJC, headers, False,nA5dhMRg6ENzsB0l1GwvH7aIr2,'LIVETV-PLAY-3rd')
		if not Y3SmVGbfNvEeakMBr.succeeded:
			OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
		url = Y3SmVGbfNvEeakMBr.headers['Location']
		url = url.replace('%20',hSXlxL9iB05c)
		url = url.replace('%3D','=')
		if 'Learn' in xhqyQAmiYa6FwRM4DO21Jvj:
			url = url.replace('NTNNile',nA5dhMRg6ENzsB0l1GwvH7aIr2)
			url = url.replace('learning1','Learning')
	elif FjO41UWNvs0Gg=='PL':
		hwZT5nYUGQ1RJC = { 'id' : xhqyQAmiYa6FwRM4DO21Jvj , 'user' : Nzp9Fq5cTr.AV_CLIENT_IDS , 'function' : 'playPL' , 'menu' : K3WkBTmPE0Yynt5baRhA2ILHsOZwC9 }
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,'POST', GiqvpBF9xLEdHDr37byJSngeCQ, hwZT5nYUGQ1RJC, nA5dhMRg6ENzsB0l1GwvH7aIr2,False,nA5dhMRg6ENzsB0l1GwvH7aIr2,'LIVETV-PLAY-4th')
		if not Y3SmVGbfNvEeakMBr.succeeded:
			OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
		url = Y3SmVGbfNvEeakMBr.headers['Location']
		headers = {'Referer':Y3SmVGbfNvEeakMBr.headers['Referer']}
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(yy6RomT9bQhJf,'POST',url, nA5dhMRg6ENzsB0l1GwvH7aIr2,headers , nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'LIVETV-PLAY-5th')
		if not Y3SmVGbfNvEeakMBr.succeeded:
			OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
		items = PAztbuyYo4Kvd.findall('source src="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		url = items[0]
	elif FjO41UWNvs0Gg in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if FjO41UWNvs0Gg=='TA': xhqyQAmiYa6FwRM4DO21Jvj = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		hwZT5nYUGQ1RJC = { 'id' : xhqyQAmiYa6FwRM4DO21Jvj , 'user' : Nzp9Fq5cTr.AV_CLIENT_IDS , 'function' : 'play'+FjO41UWNvs0Gg , 'menu' : K3WkBTmPE0Yynt5baRhA2ILHsOZwC9 }
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,'POST',GiqvpBF9xLEdHDr37byJSngeCQ,hwZT5nYUGQ1RJC,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'LIVETV-PLAY-6th')
		if not Y3SmVGbfNvEeakMBr.succeeded:
			OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
		url = Y3SmVGbfNvEeakMBr.headers['Location']
		if FjO41UWNvs0Gg=='FM':
			Y3SmVGbfNvEeakMBr = uANakQHcnhR(yy6RomT9bQhJf,'GET', url, nA5dhMRg6ENzsB0l1GwvH7aIr2, nA5dhMRg6ENzsB0l1GwvH7aIr2, False,nA5dhMRg6ENzsB0l1GwvH7aIr2,'LIVETV-PLAY-7th')
			url = Y3SmVGbfNvEeakMBr.headers['Location']
			url = url.replace('https','http')
	ocUnzjShqIO35vZi8bk64pVKMCTBaw(url,wgj0rX5tbcxPulhmny,'live')
	return
# -*- coding: utf-8 -*-
import sys as kCNHMOym1luTnJ0
MigYEN1cxduFB2lpk5 = kCNHMOym1luTnJ0.version_info [0] == 2
xJ3XdNcV5IujAkoGh = 2048
aE71QiuHI95zfPRBUsntedWZJ2bl = 7
def vR1b8iCLa9Qy2Sw5OYAlWXNhZp37 (AGxE4RIvuC6):
	global peWEVn47JRXo916j
	Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky = ord (AGxE4RIvuC6 [-1])
	FXUjnSw308z = AGxE4RIvuC6 [:-1]
	f81LoVwXMpQkvdKcmPyj6NzBlt = Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky % len (FXUjnSw308z)
	qyKv5nBTxgkQSlJ0aNP1CUmpjYLZ = FXUjnSw308z [:f81LoVwXMpQkvdKcmPyj6NzBlt] + FXUjnSw308z [f81LoVwXMpQkvdKcmPyj6NzBlt:]
	if MigYEN1cxduFB2lpk5:
		H0yFJ5LDCGYpIM1BViZKTSgv3jXr = unicode () .join ([unichr (ord (Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286) - xJ3XdNcV5IujAkoGh - (MfwWyztdYVXURgPqLrITku3CxF1 + Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky) % aE71QiuHI95zfPRBUsntedWZJ2bl) for MfwWyztdYVXURgPqLrITku3CxF1, Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286 in enumerate (qyKv5nBTxgkQSlJ0aNP1CUmpjYLZ)])
	else:
		H0yFJ5LDCGYpIM1BViZKTSgv3jXr = str () .join ([chr (ord (Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286) - xJ3XdNcV5IujAkoGh - (MfwWyztdYVXURgPqLrITku3CxF1 + Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky) % aE71QiuHI95zfPRBUsntedWZJ2bl) for MfwWyztdYVXURgPqLrITku3CxF1, Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286 in enumerate (qyKv5nBTxgkQSlJ0aNP1CUmpjYLZ)])
	return eval (H0yFJ5LDCGYpIM1BViZKTSgv3jXr)
Yj1msqVeivESfrCupRy9b7WacBd,XEcWOIwkZKubV7vQ,Pj9YaUq1ibJ=vR1b8iCLa9Qy2Sw5OYAlWXNhZp37,vR1b8iCLa9Qy2Sw5OYAlWXNhZp37,vR1b8iCLa9Qy2Sw5OYAlWXNhZp37
HD7MQqXd2gS,yPE2t1Co4YQDfsIecdxu0Gklq6AvO,bqCDnV7Bs5XgRvuKLNAa1Uz=Pj9YaUq1ibJ,XEcWOIwkZKubV7vQ,Yj1msqVeivESfrCupRy9b7WacBd
YIsyNBocg6fV3wEWPSu9GtvHxLOqDi,VVstJA9bfOqunLF0oaSgWUKHDdYNz,nfNTgkiWdUq=bqCDnV7Bs5XgRvuKLNAa1Uz,yPE2t1Co4YQDfsIecdxu0Gklq6AvO,HD7MQqXd2gS
FVxoQ2J5Mfv3Zj6sy9uhOS,n8BrpFLyaMAC1vP0bOHgwxEzeGRV,UUobzy0xZLaVScIt7=nfNTgkiWdUq,VVstJA9bfOqunLF0oaSgWUKHDdYNz,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi
JvQd6LMoBX4hiy1C,ZjELJ9VrUT07R8Hn4FuSDcf,pxt6wJ8ScYMWCivoO=UUobzy0xZLaVScIt7,n8BrpFLyaMAC1vP0bOHgwxEzeGRV,FVxoQ2J5Mfv3Zj6sy9uhOS
lw2snZ9J0uhLoxypqa,LJqSQvuhf7aMmnVjy23FbZBckKzx9l,gmPI7hVEM8nD=pxt6wJ8ScYMWCivoO,ZjELJ9VrUT07R8Hn4FuSDcf,JvQd6LMoBX4hiy1C
w0ivtSjV2sZDQoT1OEugIla7R6AC5M,rCmGE4YIDaZA,vzqjsVHSBlMpxC=gmPI7hVEM8nD,LJqSQvuhf7aMmnVjy23FbZBckKzx9l,lw2snZ9J0uhLoxypqa
xwIUQfiE7rmvYzH,ldIfvn6asURQ9toi85EhqAXW3,bb1fgjsAq4N2xYwnoh39lm=vzqjsVHSBlMpxC,rCmGE4YIDaZA,w0ivtSjV2sZDQoT1OEugIla7R6AC5M
AJHaiQq3PRd5cphzGuELnVg9X,jil8vRpBsENVYyPmDd,PPxYugzLZwHX23yiK=bb1fgjsAq4N2xYwnoh39lm,ldIfvn6asURQ9toi85EhqAXW3,xwIUQfiE7rmvYzH
baBcNd81eH5ry2Olp6Mj43,Qy6wlfLoOpg1,mRanX1HZupfSQVB2gsDGUO=PPxYugzLZwHX23yiK,jil8vRpBsENVYyPmDd,AJHaiQq3PRd5cphzGuELnVg9X
bDxWcjmaSgFeRKrfpJvyA4zThi,DFx6E0uON7Jm8,zhE5I4xHinX0UoVZMNwlkPrR=mRanX1HZupfSQVB2gsDGUO,Qy6wlfLoOpg1,baBcNd81eH5ry2Olp6Mj43
from lJjPdEZcew import *
SITESURLS = {
			 xwIUQfiE7rmvYzH(u"ࠪࡅࡍ࡝ࡁࡌࠩ૬")		:[gmPI7hVEM8nD(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡳ࠯ࡣ࡫ࡻࡦࡱࡴࡷ࠰ࡱࡩࡹ࠭૭")]
			,DFx6E0uON7Jm8(u"ࠬࡇࡋࡐࡃࡐࠫ૮")		:[VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡭࠱ࡷࡻ࠵࡯࡭ࡦࠪ૯")]
			,Qy6wlfLoOpg1(u"ࠧࡂࡍ࡚ࡅࡒ࠭૰")		:[zhE5I4xHinX0UoVZMNwlkPrR(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯࠳ࡹࡶࠨ૱")]
			,UUobzy0xZLaVScIt7(u"ࠩࡄࡏ࡜ࡇࡍࡕࡗࡅࡉࠬ૲")	:[HD7MQqXd2gS(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡹ࠮ࡢ࡭ࡺࡥࡲ࠴ࡴࡶࡤࡨࠫ૳")]
			,Yj1msqVeivESfrCupRy9b7WacBd(u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭૴")		:[FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡭࡯ࡤࡥࡷ࡫ࡦ࠯ࡥ࡫ࠫ૵")]
			,PPxYugzLZwHX23yiK(u"࠭ࡁࡍࡏࡖࡘࡇࡇࠧ૶")		:[w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡧ࡬࡮ࡵࡷࡦࡦ࠴ࡴࡷࠩ૷")]
			,PPxYugzLZwHX23yiK(u"ࠨࡃࡑࡍࡒࡋ࡚ࡊࡆࠪ૸")		:[gmPI7hVEM8nD(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡳ࡯࡭ࡦࡼ࡬ࡨ࠳ࡹࡨࡰࡹࠪૹ")]
			,vzqjsVHSBlMpxC(u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓࠨૺ")	:[zhE5I4xHinX0UoVZMNwlkPrR(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡣࡵࡥࡧ࡯ࡣ࠮ࡶࡲࡳࡳࡹ࠮ࡤࡱࡰࠫૻ")]
			,w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧૼ")		:[Yj1msqVeivESfrCupRy9b7WacBd(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡤࡦࡸ࡫ࡥࡥ࠰ࡱࡩࡹ࠭૽")]
			,nfNTgkiWdUq(u"ࠧࡂ࡛ࡏࡓࡑ࠭૾")		:[xwIUQfiE7rmvYzH(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡩ࠳ࡧࡹ࡭ࡱ࡯࠲ࡳ࡫ࡴࠨ૿")]
			,JvQd6LMoBX4hiy1C(u"ࠩࡅࡓࡐࡘࡁࠨ଀")		:[bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷ࡭ࡵ࡯ࡧࡸࡲࡨ࠳ࡩ࡯࡮ࠩଁ")]
			,rCmGE4YIDaZA(u"ࠫࡇࡘࡓࡕࡇࡍࠫଂ")		:[rCmGE4YIDaZA(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡢࡳࡵࡷࡩ࡯࠴ࡣࡰ࡯ࠪଃ")]
			,pxt6wJ8ScYMWCivoO(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧ଄")		:[ldIfvn6asURQ9toi85EhqAXW3(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠺࠰࠱࠰ࡦࡳࡲ࠭ଅ")]
			,baBcNd81eH5ry2Olp6Mj43(u"ࠨࡅࡌࡑࡆ࠺ࡐࠨଆ")		:[XEcWOIwkZKubV7vQ(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࠵ࡲ࠱ࡧࡴࡳࠧଇ")]
			,bb1fgjsAq4N2xYwnoh39lm(u"ࠪࡇࡎࡓࡁ࠵ࡗࠪଈ")		:[DFx6E0uON7Jm8(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠷ࡣࡪ࡯ࡤ࠸ࡺ࠴ࡣࡰ࡯ࠪଉ")]
			,pxt6wJ8ScYMWCivoO(u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧଊ")		:[YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥ࠸ࡨࡤࡰ࠰ࡦࡳࡲ࠭ଋ")]
			,JvQd6LMoBX4hiy1C(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩଌ")		:[ldIfvn6asURQ9toi85EhqAXW3(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧࡣ࡭ࡷࡥ࠲ࡼࡧࡴࡤࡪࠪ଍")]
			,bb1fgjsAq4N2xYwnoh39lm(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࡛ࡔࡘࡋࠨ଎")	:[PPxYugzLZwHX23yiK(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹࡼࡶ࠯ࡥ࡬ࡱࡦࡩ࡬ࡶࡤ࠱ࡷ࡭ࡵࡰࠨଏ")]
			,n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭ଐ")		:[nfNTgkiWdUq(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡧ࡮ࡳࡡࡧࡣࡱࡷ࠳ࡩ࡯ࠨ଑")]
			,lw2snZ9J0uhLoxypqa(u"࠭ࡃࡊࡏࡄࡊࡗࡋࡅࠨ଒")		:[bb1fgjsAq4N2xYwnoh39lm(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࡬ࡲࡦࡧ࠱ࡺ࡮ࡶࠧଓ")]
			,Pj9YaUq1ibJ(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫଔ")	:[bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡱࡾ࠳ࡣࡪ࡯ࡤ࠲ࡳ࡫ࡴࠨକ")]
			,ldIfvn6asURQ9toi85EhqAXW3(u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫଖ")		:[vzqjsVHSBlMpxC(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣࡱࡳࡼ࠴ࡣࡤࠩଗ")]
			,xwIUQfiE7rmvYzH(u"ࠬࡉࡉࡎࡃ࡚ࡆࡆ࡙ࠧଘ")		:[mRanX1HZupfSQVB2gsDGUO(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡮ࡻࡦ࡭ࡲࡧ࠮ࡤࡥࠪଙ")]
			,mRanX1HZupfSQVB2gsDGUO(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬଚ")	:[UUobzy0xZLaVScIt7(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨଛ"),Yj1msqVeivESfrCupRy9b7WacBd(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫ࡷࡧࡰࡩࡳ࡯࠲ࡦࡶࡩ࠯ࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠴ࡣࡰ࡯ࠪଜ")]
			,bb1fgjsAq4N2xYwnoh39lm(u"ࠪࡈࡗࡇࡍࡂࡅࡄࡊࡊ࠭ଝ")	:[UUobzy0xZLaVScIt7(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽ࠲࠶࠰ࡧࡶࡦࡳࡡࡤࡣࡩࡩ࠲ࡺࡶ࠯ࡥࡲࡱࠬଞ")]
			,rCmGE4YIDaZA(u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠭ଟ")		:[vzqjsVHSBlMpxC(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡥࡴࡤࡱࡦࡹ࠷࠯ࡰࡨࡸࠬଠ")]
			,mRanX1HZupfSQVB2gsDGUO(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩଡ")		:[bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡪࡺࡴࠧଢ")]
			,HD7MQqXd2gS(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠵ࠫଣ")		:[DFx6E0uON7Jm8(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡽࡥࡣࡥࡤࡱࠬତ")]
			,mRanX1HZupfSQVB2gsDGUO(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠭ଥ")		:[jil8vRpBsENVYyPmDd(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡩࡦࡩࡼࡦࡪࡹࡴ࠯ࡤ࡬ࡨࠬଦ")]
			,n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴ࠨଧ")		:[Pj9YaUq1ibJ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽ࠲ࡨࡥࡴࡶ࠱ࡲࡪࡺࠧନ")]
			,zhE5I4xHinX0UoVZMNwlkPrR(u"ࠨࡇࡊ࡝ࡉࡋࡁࡅࠩ଩")		:[Qy6wlfLoOpg1(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡤࡦࡣࡧ࠲ࡱ࡯ࡶࡦࠩପ")]
			,DFx6E0uON7Jm8(u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅࠬଫ")		:[zhE5I4xHinX0UoVZMNwlkPrR(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡬ࡤ࡫ࡱࡩࡲࡧ࠮ࡤࡱࡰࠫବ")]
			,UUobzy0xZLaVScIt7(u"ࠬࡋࡌࡊࡈ࡙ࡍࡉࡋࡏࠨଭ")	:[pxt6wJ8ScYMWCivoO(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡤ࡬࡮ࡪ࠮ࡦ࡮࡬ࡪ࠳ࡴࡥࡸࡵࠪମ")]
			,PPxYugzLZwHX23yiK(u"ࠧࡇࡃࡅࡖࡆࡑࡁࠨଯ")		:[FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥࡧࡸ࡫ࡢ࠰ࡦࡳࡲ࠭ର")]
			,Yj1msqVeivESfrCupRy9b7WacBd(u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ଱")	:[gmPI7hVEM8nD(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧࡪࡦࡴ࠱ࡷ࡭ࡵࡷࠨଲ")]
			,AJHaiQq3PRd5cphzGuELnVg9X(u"ࠫࡋࡇࡒࡆࡕࡎࡓࠬଳ")		:[pxt6wJ8ScYMWCivoO(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡪࡲ࠱ࡪࡦࡸࡥࡴ࡭ࡲ࠲ࡳ࡫ࡴࠨ଴")]
			,gmPI7hVEM8nD(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨଵ")		:[bb1fgjsAq4N2xYwnoh39lm(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡶࡰࡦ࠴ࡦࡢࡵࡨࡰ࡭ࡪ࠮ࡤ࡮ࡲࡹࡩ࠭ଶ")]
			,bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠨࡈࡒࡗ࡙ࡇࠧଷ")		:[mRanX1HZupfSQVB2gsDGUO(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡰ࠮ࡧࡱࡶࡸࡦ࠳ࡴࡷ࠰ࡱࡩࡹ࠭ସ")]
			,FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠪࡊ࡚ࡔࡏࡏࡖ࡙ࠫହ")		:[jil8vRpBsENVYyPmDd(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡭࠮ࡢ࡮ࡰࡩࡸ࡮࡫ࡢࡪ࠱ࡲࡪࡺࠧ଺")]
			,LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠬࡌࡕࡔࡊࡄࡖ࡙࡜ࠧ଻")		:[gmPI7hVEM8nD(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡣ࠰ࡩࡹࡸ࡮ࡡࡳ࠯ࡷࡺ࠳ࡩ࡯࡮଼ࠩ")]
			,UUobzy0xZLaVScIt7(u"ࠧࡇࡗࡖࡌࡆࡘࡖࡊࡆࡈࡓࠬଽ")	:[HD7MQqXd2gS(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࠲࡫ࡻࡳࡩࡣࡵ࠲ࡻ࡯ࡤࡦࡱࠪା")]
			,mRanX1HZupfSQVB2gsDGUO(u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫି")		:[XEcWOIwkZKubV7vQ(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡭ࡧ࡬ࡢࡥ࡬ࡱࡦ࠴࡭ࡦࡦ࡬ࡥࠬୀ")]
			,ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠫࡎࡌࡉࡍࡏࠪୁ")		:[PPxYugzLZwHX23yiK(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳ࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭ୂ"),HD7MQqXd2gS(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡰ࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧୃ"),bb1fgjsAq4N2xYwnoh39lm(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨୄ"),FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥ࠷࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪ୅"),jil8vRpBsENVYyPmDd(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠼࠷࠳࠷࠹࠱࠰࠵࠸࠳࠷࠲࠳ࠩ୆")]
			,DFx6E0uON7Jm8(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭େ")	:[lw2snZ9J0uhLoxypqa(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱࡡࡳࡤࡤࡰࡦ࠳ࡴࡷ࠰࡬ࡵࠬୈ")]
			,bb1fgjsAq4N2xYwnoh39lm(u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧ୉")		:[n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬࡫ࡷ࡯ࡴࡺ࠮ࡤࡣࡰࠫ୊")]
			,JvQd6LMoBX4hiy1C(u"ࠧࡌࡋࡕࡑࡆࡒࡋࠨୋ")		:[vzqjsVHSBlMpxC(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡹ࠳ࡱࡩࡳ࡯ࡤࡰࡰ࠴ࡣࡰ࡯ࠪୌ")]
			,AJHaiQq3PRd5cphzGuELnVg9X(u"ࠩࡏࡅࡗࡕ࡚ࡂ୍ࠩ")		:[ldIfvn6asURQ9toi85EhqAXW3(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡱࡧࡲࡰࡼࡤ࠲࡮ࡴ࡫ࠨ୎")]
			,xwIUQfiE7rmvYzH(u"ࠫࡑࡕࡄ࡚ࡐࡈࡘࠬ୏")		:[xwIUQfiE7rmvYzH(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡬ࡰࡦࡼࡲࡪࡺ࠮࡭࡫ࡱ࡯ࠬ୐")]
			,AJHaiQq3PRd5cphzGuELnVg9X(u"࠭ࡍࡂࡕࡄ࡚ࡎࡊࡅࡐࠩ୑")	:[nfNTgkiWdUq(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡱ࠲ࡲࡧࡳࡢ࠰ࡱࡩࡼࡹࠧ୒")]
			,Yj1msqVeivESfrCupRy9b7WacBd(u"ࠨࡒࡄࡒࡊ࡚ࠧ୓")		:[bb1fgjsAq4N2xYwnoh39lm(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡰࡢࡰࡨࡸ࠳ࡩ࡯࠯࡫࡯ࠫ୔")]
			,PPxYugzLZwHX23yiK(u"ࠪࡖࡊࡒࡅࡂࡕࡈࡗࠬ୕")		:[PPxYugzLZwHX23yiK(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡴࡷࡵ࡫ࡪ࠴ࡳࡩ࠱࡮ࡳࡩ࡯࠯ࡦ࡯ࡤࡨࡤࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠳ࡴࡲࡤ࠰࡫ࡱࡨࡪࡾ࠮ࡩࡶࡰࡰࠬୖ")]
			,vzqjsVHSBlMpxC(u"࡙ࠬࡅࡓࡋࡈࡗ࡙ࡏࡍࡆࠩୗ")	:[Qy6wlfLoOpg1(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡣࡣ࠱ࡷࡪࡸࡩࡦࡵࡷ࡭ࡲ࡫࠮ࡤࡣࡰࠫ୘")]
			,Pj9YaUq1ibJ(u"ࠧࡔࡊࡄࡆࡆࡑࡁࡕ࡛ࠪ୙")	:[baBcNd81eH5ry2Olp6Mj43(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧࡨࡥ࠰ࡹ࡭ࡵ࠭୚")]
			,JvQd6LMoBX4hiy1C(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ୛")		:[JvQd6LMoBX4hiy1C(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮ࡡࡩ࠶ࡸ࠲ࡳ࡫ࡴࠨଡ଼")]
			,HD7MQqXd2gS(u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠸ࠧଢ଼")	:[JvQd6LMoBX4hiy1C(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡣ࡫࡭ࡩ࠺ࡵ࠯࡮࡬ࡺࡪ࠭୞")]
			,pxt6wJ8ScYMWCivoO(u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪୟ")	:[vzqjsVHSBlMpxC(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧ࠱ࡷ࡭࠺ࡵ࠯ࡰࡨࡻࡸ࠭ୠ")]
			,HD7MQqXd2gS(u"ࠨࡕࡋࡓࡋࡎࡁࠨୡ")		:[lw2snZ9J0uhLoxypqa(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡵࡦࡩࡣ࠱ࡸࡻ࠭ୢ")]
			,nfNTgkiWdUq(u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬୣ")		:[gmPI7hVEM8nD(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡤࡱࡰࠫ୤"),zhE5I4xHinX0UoVZMNwlkPrR(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡵࡣࡷ࡭ࡨ࠴ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡥࡲࡱࠬ୥"),UUobzy0xZLaVScIt7(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡲࡳ࡫ࡳࡡࡹ࠰ࡤࡾࡺࡸࡥࡦࡦࡪࡩ࠳ࡴࡥࡵࠩ୦")]
			,baBcNd81eH5ry2Olp6Mj43(u"ࠧࡔࡊࡒࡓࡋࡔࡅࡕࠩ୧")		:[bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡷ࠳ࡹࡨࡰࡱࡩࡲࡪࡺ࠮ࡰࡰ࡯࡭ࡳ࡫ࠧ୨")]
			,zhE5I4xHinX0UoVZMNwlkPrR(u"ࠩࡗࡍࡐࡇࡁࡕࠩ୩")		:[Yj1msqVeivESfrCupRy9b7WacBd(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹ࡯࡫ࡢࡣࡷ࠲ࡳ࡫ࡴࠨ୪")]
			,xwIUQfiE7rmvYzH(u"࡙ࠫ࡜ࡆࡖࡐࠪ୫")		:[Yj1msqVeivESfrCupRy9b7WacBd(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳ࠯ࡶࡹࡪࡺࡴ࠮࡮ࡧࠪ୬")]
			,zhE5I4xHinX0UoVZMNwlkPrR(u"࠭ࡖࡂࡔࡅࡓࡓ࠭୭")		:[nfNTgkiWdUq(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡯࠱ࡺࡦࡸࡢࡰࡰ࠱ࡧࡦࡳࠧ୮")]
			,rCmGE4YIDaZA(u"ࠨࡘࡌࡈࡊࡕࡎࡔࡃࡈࡑࠬ୯")	:[gmPI7hVEM8nD(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺ࡮ࡪࡥࡰ࠰ࡱࡷࡦ࡫࡭࠯ࡰࡨࡸࠬ୰")]
			,lw2snZ9J0uhLoxypqa(u"࡛ࠪࡊࡉࡉࡎࡃ࠴ࠫୱ")		:[pxt6wJ8ScYMWCivoO(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡥࡤ࡫ࡰࡥ࠳ࡹࡨࡰࡹࠪ୲")]
			,PPxYugzLZwHX23yiK(u"ࠬ࡝ࡅࡄࡋࡐࡅ࠷࠭୳")		:[LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡧࡦ࡭ࡲࡧ࠮ࡤ࡮࡬ࡧࡰ࠭୴")]
			,bb1fgjsAq4N2xYwnoh39lm(u"࡚ࠧࡃࡔࡓ࡙࠭୵")		:[YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡼ࠲ࡾࡧࡱࡰࡶ࠱ࡸࡻ࠭୶")]
			,Pj9YaUq1ibJ(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ୷")		:[lw2snZ9J0uhLoxypqa(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠭୸")]
			,w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠫ࡞࡚ࡂࡠࡅࡋࡅࡓࡔࡅࡍࡕࠪ୹")	:[XEcWOIwkZKubV7vQ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭ࠨ୺")]
			,PPxYugzLZwHX23yiK(u"࠭ࡉࡑࡖ࡙ࠫ୻")			:[nA5dhMRg6ENzsB0l1GwvH7aIr2]
			,LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠧࡎ࠵ࡘࠫ୼")			:[nA5dhMRg6ENzsB0l1GwvH7aIr2]
			,jil8vRpBsENVYyPmDd(u"ࠨࡔࡈࡔࡔ࡙ࠧ୽")		:[pxt6wJ8ScYMWCivoO(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡴࡥࡵ࡮࡬ࡪࡾ࠴ࡡࡱࡲ࠲ࡏࡔࡊࡉࡓࡇࡓࡓ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩ୾"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧ୿"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨ஀")]
			,XEcWOIwkZKubV7vQ(u"ࠬࡘࡅࡑࡑࡖࡣࡇࡑࡐ࠲ࠩ஁")	:[XEcWOIwkZKubV7vQ(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨ࡫ࡷ࡬ࡺࡨ࠮ࡤࡱࡰ࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠯ࡌࡑࡇࡍ࠴ࡸࡡࡸ࠱ࡵࡩ࡫ࡹ࠯ࡩࡧࡤࡨࡸ࠵࡭ࡢࡵࡷࡩࡷ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪஂ"),nfNTgkiWdUq(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࡬ࡸ࡭ࡻࡢ࠯ࡥࡲࡱ࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠰ࡍࡒࡈࡎ࠵ࡲࡢࡹ࠲ࡶࡪ࡬ࡳ࠰ࡪࡨࡥࡩࡹ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠱࠹࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠻࠲ࡽࡳ࡬ࠨஃ"),baBcNd81eH5ry2Olp6Mj43(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡪ࡭ࡹ࡮ࡵࡣ࠰ࡦࡳࡲ࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠱ࡎࡓࡉࡏ࠯ࡳࡣࡺ࠳ࡷ࡫ࡦࡴ࠱࡫ࡩࡦࡪࡳ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡃࡇࡈࡔࡔࡓ࠲࠻࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠽࠳ࡾ࡭࡭ࠩ஄")]
			,baBcNd81eH5ry2Olp6Mj43(u"ࠩࡕࡉࡕࡕࡓࡠࡄࡎࡔ࠷࠭அ")	:[JvQd6LMoBX4hiy1C(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨஆ"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠶࠾࠯ࡢࡦࡧࡳࡳࡹ࠱࠹࠰ࡻࡱࡱ࠭இ"),XEcWOIwkZKubV7vQ(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮ࡶ࡭࠱ࡸࡴ࠵ࡁࡅࡆࡒࡒࡘ࠷࠹࠰ࡣࡧࡨࡴࡴࡳ࠲࠻࠱ࡼࡲࡲࠧஈ")]
			,mRanX1HZupfSQVB2gsDGUO(u"࠭ࡒࡆࡒࡒࡗࡤࡈࡋࡑ࠵ࠪஉ")	:[Yj1msqVeivESfrCupRy9b7WacBd(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳ࡆࡊࡄࡐࡐࡖ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨஊ"),bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴ࡇࡄࡅࡑࡑࡗ࠶࠾࠯ࡢࡦࡧࡳࡳࡹ࠱࠹࠰ࡻࡱࡱ࠭஋"),jil8vRpBsENVYyPmDd(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡲࡵ࡯ࡰ࠰ࡦࡳࡲ࠵ࡁࡅࡆࡒࡒࡘ࠷࠹࠰ࡣࡧࡨࡴࡴࡳ࠲࠻࠱ࡼࡲࡲࠧ஌")]
			,Qy6wlfLoOpg1(u"ࠪࡏࡔࡊࡉࡠࡕࡒ࡙ࡗࡉࡅࡔࠩ஍")	:[vzqjsVHSBlMpxC(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡳࡶࡴࡪࡩ࠳ࡹࡨ࠰࡭ࡲࡨ࡮࠭எ"),nfNTgkiWdUq(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡰࡵࡤࡪࠩஏ"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯࡬ࡱࡧ࡭ࠬஐ")]
			,HD7MQqXd2gS(u"ࠧࡇࡋࡏࡉࡘࡥࡓࡐࡗࡕࡇࡊ࡙ࠧ஑"):[VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰࠨஒ")]
			,vzqjsVHSBlMpxC(u"ࠩࡎࡓࡉࡏࡅࡎࡃࡇࡣࡆࡖࡐࠨஓ")	:[XEcWOIwkZKubV7vQ(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠭ஔ"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠵࠴࠶࠾࠮ࡧࡹࡶ࠲ࡸࡺ࡯ࡳࡧࠪக")]
			}
if UnOIK1WBbw2:
	SITESURLS[LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ஖")] = [lw2snZ9J0uhLoxypqa(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨ஗"),bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬ஘"),HD7MQqXd2gS(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫங"),nfNTgkiWdUq(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧச"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧ஛"),JvQd6LMoBX4hiy1C(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪஜ"),XEcWOIwkZKubV7vQ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭஝"),bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧஞ"),UUobzy0xZLaVScIt7(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨட"),vzqjsVHSBlMpxC(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡪࡾࡴࡳࡣࡳࡽࡹ࡮࡯࡯ࡥࡲࡨࡪ࠭஠"),pxt6wJ8ScYMWCivoO(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡨࡼࡪࡩࡵࡵࡧ࡭ࡷࠬ஡")]
	SITESURLS[baBcNd81eH5ry2Olp6Mj43(u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖ࠱ࠨ஢")] = [rCmGE4YIDaZA(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨண"),bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬத"),FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ஥"),AJHaiQq3PRd5cphzGuELnVg9X(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ஦"),ldIfvn6asURQ9toi85EhqAXW3(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧ஧"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪந"),HD7MQqXd2gS(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭ன"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧப"),vzqjsVHSBlMpxC(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨ஫"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡩࡨࡸࡪࡾࡴࡳࡣࡳࡽࡹ࡮࡯࡯ࡥࡲࡨࡪ࠭஬"),bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡨࡼࡪࡩࡵࡵࡧ࡭ࡷࠬ஭")]
	SITESURLS[VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔ࠷࠭ம")] = [yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬய"),mRanX1HZupfSQVB2gsDGUO(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩர"),zhE5I4xHinX0UoVZMNwlkPrR(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨற"),DFx6E0uON7Jm8(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫல"),UUobzy0xZLaVScIt7(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫள"),Yj1msqVeivESfrCupRy9b7WacBd(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧழ"),bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪவ"),nfNTgkiWdUq(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡧࡦࡶࡴࡤࡪࡤࠫஶ"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬஷ"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵࡧࡻࡸࡷࡧࡰࡺࡶ࡫ࡳࡳࡩ࡯ࡥࡧࠪஸ"),mRanX1HZupfSQVB2gsDGUO(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡥࡹࡧࡦࡹࡹ࡫ࡪࡴࠩஹ")]
	SITESURLS[mRanX1HZupfSQVB2gsDGUO(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒ࠶ࠫ஺")] = [rCmGE4YIDaZA(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭஻"),mRanX1HZupfSQVB2gsDGUO(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ஼"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡲࡵ࡯ࡰ࠰ࡦࡳࡲ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ஽"),xwIUQfiE7rmvYzH(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡳ࡯ࡰࡱ࠱ࡧࡴࡳ࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬா"),bb1fgjsAq4N2xYwnoh39lm(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡭ࡰࡱࡲ࠲ࡨࡵ࡭࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬி"),Yj1msqVeivESfrCupRy9b7WacBd(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡮ࡱࡲࡳ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨீ"),JvQd6LMoBX4hiy1C(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫு"),Qy6wlfLoOpg1(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬூ"),baBcNd81eH5ry2Olp6Mj43(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭௃"),zhE5I4xHinX0UoVZMNwlkPrR(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡲࡵ࡯ࡰ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡨࡼࡹࡸࡡࡱࡻࡷ࡬ࡴࡴࡣࡰࡦࡨࠫ௄"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡳ࡯ࡰࡱ࠱ࡧࡴࡳ࠯ࡦࡺࡨࡧࡺࡺࡥ࡫ࡵࠪ௅")]
else:
	SITESURLS[baBcNd81eH5ry2Olp6Mj43(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫெ")] = [n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨே"),JvQd6LMoBX4hiy1C(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬை"),xwIUQfiE7rmvYzH(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ௉"),xwIUQfiE7rmvYzH(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧொ"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧோ"),baBcNd81eH5ry2Olp6Mj43(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪௌ"),AJHaiQq3PRd5cphzGuELnVg9X(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ்࠭"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧ௎"),ldIfvn6asURQ9toi85EhqAXW3(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨ௏"),Qy6wlfLoOpg1(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡪࡾࡴࡳࡣࡳࡽࡹ࡮࡯࡯ࡥࡲࡨࡪ࠭ௐ"),vzqjsVHSBlMpxC(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡨࡼࡪࡩࡵࡵࡧ࡭ࡷࠬ௑")]
	SITESURLS[nfNTgkiWdUq(u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠷ࠧ௒")] = [FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭௓"),AJHaiQq3PRd5cphzGuELnVg9X(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ௔"),nfNTgkiWdUq(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ௕"),baBcNd81eH5ry2Olp6Mj43(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬ௖"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬௗ"),Qy6wlfLoOpg1(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ௘"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫ௙"),bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬ௚"),PPxYugzLZwHX23yiK(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭௛"),Yj1msqVeivESfrCupRy9b7WacBd(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡨࡼࡹࡸࡡࡱࡻࡷ࡬ࡴࡴࡣࡰࡦࡨࠫ௜"),mRanX1HZupfSQVB2gsDGUO(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡦࡺࡨࡧࡺࡺࡥ࡫ࡵࠪ௝")]
	SITESURLS[HD7MQqXd2gS(u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓ࠶ࠬ௞")] = [HD7MQqXd2gS(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ௟"),AJHaiQq3PRd5cphzGuELnVg9X(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ௠"),PPxYugzLZwHX23yiK(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ௡"),jil8vRpBsENVYyPmDd(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ௢"),UUobzy0xZLaVScIt7(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ௣"),lw2snZ9J0uhLoxypqa(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭௤"),ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ௥"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡦࡥࡵࡺࡣࡩࡣࠪ௦"),ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡸࡪࡹࡴࡪࡰࡪࠫ௧"),Pj9YaUq1ibJ(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡦࡺࡷࡶࡦࡶࡹࡵࡪࡲࡲࡨࡵࡤࡦࠩ௨"),gmPI7hVEM8nD(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡫ࡸࡦࡥࡸࡸࡪࡰࡳࠨ௩")]
	SITESURLS[AJHaiQq3PRd5cphzGuELnVg9X(u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑ࠵ࠪ௪")] = [pxt6wJ8ScYMWCivoO(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ௫"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭௬"),bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ௭"),ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ௮"),n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ௯"),xwIUQfiE7rmvYzH(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ௰"),bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ௱"),Qy6wlfLoOpg1(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨ௲"),ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩ௳"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧ௴"),zhE5I4xHinX0UoVZMNwlkPrR(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡩࡽ࡫ࡣࡶࡶࡨ࡮ࡸ࠭௵")]
api_python_actions = [AJHaiQq3PRd5cphzGuELnVg9X(u"ࠪࡐࡎ࡙ࡔࡑࡎࡄ࡝ࠬ௶"),gmPI7hVEM8nD(u"ࠫࡗࡋࡐࡐࡔࡗࡗࠬ௷"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠬࡋࡍࡂࡋࡏࡗࠬ௸"),vzqjsVHSBlMpxC(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨ௹"),xwIUQfiE7rmvYzH(u"ࠧࡊࡕࡏࡅࡒࡏࡃࡔࠩ௺"),JvQd6LMoBX4hiy1C(u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫ௻"),lw2snZ9J0uhLoxypqa(u"ࠩࡎࡒࡔ࡝ࡎࡆࡔࡕࡓࡗ࡙ࠧ௼"),Pj9YaUq1ibJ(u"ࠪࡇࡆࡖࡔࡄࡊࡄࠫ௽"),pxt6wJ8ScYMWCivoO(u"࡙ࠫࡋࡓࡕࡋࡑࡋࠬ௾"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠬࡋࡘࡕࡔࡄࡔ࡞࡚ࡈࡐࡐࡆࡓࡉࡋࠧ௿"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠭ࡅ࡙ࡇࡆ࡙࡙ࡋࡊࡔࠩఀ")]
api_repos_actions = [n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠧࡂࡆࡇࡓࡓ࡙ࠧఁ"),xwIUQfiE7rmvYzH(u"ࠨࡃࡇࡈࡔࡔࡓ࠲࠺ࠪం"),bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠩࡄࡈࡉࡕࡎࡔ࠳࠼ࠫః")]
non_videos_actions = [bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠪࡅࡑࡒࠧఄ"),FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫఅ"),DFx6E0uON7Jm8(u"ࠬࡏࡎࡔࡖࡄࡐࡑ࠭ఆ"),gmPI7hVEM8nD(u"࠭ࡍࡆࡖࡕࡓࡕࡕࡌࡊࡕࠪఇ"),mRanX1HZupfSQVB2gsDGUO(u"ࠧࡓࡇࡓࡓࡘ࠭ఈ"),mRanX1HZupfSQVB2gsDGUO(u"ࠨࡆࡒࡒࡆ࡚ࡉࡐࡐࡖࠫఉ"),rCmGE4YIDaZA(u"ࠩࡆࡅࡕ࡚ࡃࡉࡃࡌࡈࠬఊ"),n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠪࡇࡆࡖࡔࡄࡊࡄࡘࡔࡑࡅࡏࠩఋ")]+api_python_actions+api_repos_actions
KR9TdgoVwvr4mIP = FFKncZx5pDTwdiJRYhMgQSNL
eWcSBRXKYLw6arPkf = S5MWhgtZ37Xw
sz6qutHF1ITYr0a3cGJKOf = FFKncZx5pDTwdiJRYhMgQSNL
Gnkf9VO7o1Bv5hTyAUPbHE = FFKncZx5pDTwdiJRYhMgQSNL
avprivsnorestrict = FFKncZx5pDTwdiJRYhMgQSNL
avprivslongperiod = FFKncZx5pDTwdiJRYhMgQSNL
resolveonly = FFKncZx5pDTwdiJRYhMgQSNL
BWx4LyF0fcT1teAwjQJkgrS8nPNU = FFKncZx5pDTwdiJRYhMgQSNL
ALLOW_DNS_FIX = YWylfpKSRb
ALLOW_PROXY_FIX = YWylfpKSRb
ALLOW_SHOWDIALOGS_FIX = YWylfpKSRb
menuItemsLIST = []
SEND_THESE_EVENTS = []
FORWARDS_HOSTNAMES = {}
menuItemsDICT = {}
BADSCRAPERS = []
BADWEBSITES = [bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠫࡋ࡛ࡓࡉࡃࡕࡘ࡛࠭ఌ"),bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠬࡊࡒࡂࡏࡄࡇࡆࡌࡅࠨ఍"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧఎ"),rCmGE4YIDaZA(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵ࠩఏ"),Yj1msqVeivESfrCupRy9b7WacBd(u"ࠨࡎࡄࡖࡔࡠࡁࠨఐ"),pxt6wJ8ScYMWCivoO(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ఑"),ldIfvn6asURQ9toi85EhqAXW3(u"ࠪ࡝ࡆࡗࡏࡕࠩఒ"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࡛ࠫࡇࡒࡃࡑࡑࠫఓ"),n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧఔ"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠭ࡐࡂࡐࡈࡘࠬక")]
BADCOMMONIDS = [yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠧ࠺࠻࠼࠽࠲࠿࠹࠺࠻࠰࠽࠾࠿࠹࠮࠻࠼࠽࠾࠳࠰࠱࠲࠳ࠫఖ"),Yj1msqVeivESfrCupRy9b7WacBd(u"ࠨ࠻࠼࠼࠽࠳࠷࠸࠸࠹࠱࠺࠻࠴࠵࠯࠶࠷࠷࠸࠭࠳࠲࠻࠺ࠬగ")]
GEOLOCATION_DATA = nA5dhMRg6ENzsB0l1GwvH7aIr2
AV_CLIENT_IDS = nA5dhMRg6ENzsB0l1GwvH7aIr2
DNS_SERVERS = [DFx6E0uON7Jm8(u"ࠩ࠴࠲࠶࠴࠱࠯࠳ࠪఘ"),AJHaiQq3PRd5cphzGuELnVg9X(u"ࠪ࠼࠳࠾࠮࠹࠰࠻ࠫఙ"),jil8vRpBsENVYyPmDd(u"ࠫ࠶࠴࠰࠯࠲࠱࠵ࠬచ"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠬ࠾࠮࠹࠰࠷࠲࠹࠭ఛ"),baBcNd81eH5ry2Olp6Mj43(u"࠭࠲࠱࠺࠱࠺࠼࠴࠲࠳࠴࠱࠶࠷࠸ࠧజ"),nfNTgkiWdUq(u"ࠧ࠳࠲࠻࠲࠻࠽࠮࠳࠴࠳࠲࠷࠸࠰ࠨఝ")]
busydialog_active = FFKncZx5pDTwdiJRYhMgQSNL
dns_succeeded_urls = []
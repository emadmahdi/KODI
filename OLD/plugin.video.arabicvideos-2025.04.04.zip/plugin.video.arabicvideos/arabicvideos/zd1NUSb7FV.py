# -*- coding: utf-8 -*-
from pR2X91txEm import *
headers = { 'User-Agent' : nA5dhMRg6ENzsB0l1GwvH7aIr2 }
wgj0rX5tbcxPulhmny = 'AKWAM'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_AKW_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
EWqBecHAhuUVtrxnjZQ0s = nA5dhMRg6ENzsB0l1GwvH7aIr2
SAsGubf1jW2Q3p = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==240: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==241: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,text)
	elif mode==242: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LLabVp7hzj28CE0f1udx(url)
	elif mode==243: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==244: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = NNihMcqGKQEvLz6l(url,'FILTERS___'+text)
	elif mode==245: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = NNihMcqGKQEvLz6l(url,'CATEGORIES___'+text)
	elif mode==246: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = vji0AS3kFYDCZ(url)
	elif mode==247: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = vUbouSi29fWNkBHcR(url)
	elif mode==248: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = j3jWs4CkGfQtvSn2u()
	elif mode==249: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def j3jWs4CkGfQtvSn2u():
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def ErjIn5GfaBzkqycC():
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'AKWAM-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	JohktxgjI6r7Fz8dbTLy5RPH9 = PAztbuyYo4Kvd.findall('home-site-btn-container.*?href="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if JohktxgjI6r7Fz8dbTLy5RPH9: JohktxgjI6r7Fz8dbTLy5RPH9 = JohktxgjI6r7Fz8dbTLy5RPH9[0]
	else: JohktxgjI6r7Fz8dbTLy5RPH9 = GiqvpBF9xLEdHDr37byJSngeCQ
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',JohktxgjI6r7Fz8dbTLy5RPH9,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'AKWAM-MENU-2nd')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,249,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فلتر محدد',GiqvpBF9xLEdHDr37byJSngeCQ,246)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فلتر كامل',GiqvpBF9xLEdHDr37byJSngeCQ,247)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'المميزة',JohktxgjI6r7Fz8dbTLy5RPH9,241,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'featured')
	recent = PAztbuyYo4Kvd.findall('recently-container.*?href="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	ZylHkumQ8zD0 = recent[0]
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'أضيف حديثا',ZylHkumQ8zD0,241)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,name,WWU7QJP2tyTRLIfDh0csxbkvX in zz3eHskxE6lAyDR5cNj1ug:
		if name in SAsGubf1jW2Q3p: continue
		TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+name,ZylHkumQ8zD0,241)
		items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			if title in SAsGubf1jW2Q3p: continue
			title = name+hSXlxL9iB05c+title
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,241)
	return
def vji0AS3kFYDCZ(website=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'AKWAM-MENU-1st')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="menu(.*?)<nav',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?text">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			if title not in SAsGubf1jW2Q3p:
				title = title+' مصنفة'
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,245)
		if website==nA5dhMRg6ENzsB0l1GwvH7aIr2: TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	return kl2ZWdy8rXcHT
def vUbouSi29fWNkBHcR(website=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'AKWAM-MENU-1st')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="menu(.*?)<nav',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?text">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			if title not in SAsGubf1jW2Q3p:
				title = title+' مفلترة'
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,244)
		if website==nA5dhMRg6ENzsB0l1GwvH7aIr2: TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	return kl2ZWdy8rXcHT
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,type=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,True,'AKWAM-TITLES-1st')
	if type=='featured': zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('swiper-container(.*?)swiper-button-prev',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	else: zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="widget"(.*?)main-footer',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if not items:
			items = PAztbuyYo4Kvd.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for HRlygv7YwjzbSLt8fkEerq2,ZylHkumQ8zD0,title in items:
			if '/series/' in ZylHkumQ8zD0 or '/shows/' in ZylHkumQ8zD0:
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,242,HRlygv7YwjzbSLt8fkEerq2)
			elif '/movies/' in ZylHkumQ8zD0:
				TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,243,HRlygv7YwjzbSLt8fkEerq2)
			elif '/games/' not in ZylHkumQ8zD0:
				TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,243,HRlygv7YwjzbSLt8fkEerq2)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('pagination(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			ZylHkumQ8zD0 = HH8SJuswDBPtniebmkXIr(ZylHkumQ8zD0)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+title,ZylHkumQ8zD0,241)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	SEGtTsCyUVi0lo4LJkH5 = search.replace(hSXlxL9iB05c,'%20')
	url = GiqvpBF9xLEdHDr37byJSngeCQ + '/search?q='+SEGtTsCyUVi0lo4LJkH5
	V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
	return
def LLabVp7hzj28CE0f1udx(url):
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in kl2ZWdy8rXcHT:
		HRlygv7YwjzbSLt8fkEerq2 = SoNGUfhMDERLyHOz1qkVAj.getInfoLabel('ListItem.Icon')
		TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'رابط التشغيل',url,243,HRlygv7YwjzbSLt8fkEerq2)
	else:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('-episodes">(.*?)<div class="widget-4',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		GGr9WlIhv1BKDJjTZFNty4R3k0dCOA = PAztbuyYo4Kvd.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title,HRlygv7YwjzbSLt8fkEerq2 in GGr9WlIhv1BKDJjTZFNty4R3k0dCOA:
			title = title.replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c)
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,242,HRlygv7YwjzbSLt8fkEerq2)
			else: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,243,HRlygv7YwjzbSLt8fkEerq2)
	return
def lNBcUr8RCn(url):
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,True,'AKWAM-PLAY-1st')
	nR3YVtZDPs1IpAC = PAztbuyYo4Kvd.findall('badge-danger.*?>(.*?)<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if nR3YVtZDPs1IpAC and g4gUOtGiVkoNuaBrHhx8L(wgj0rX5tbcxPulhmny,url,nR3YVtZDPs1IpAC): return
	Ba6pEsGAHxD8wI = PAztbuyYo4Kvd.findall('li><a href="#(.*?)".*?>(.*?)<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	ce9zAaVFswSq6lLr82DfQyotGW,ecU4Hy7lNS,Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q,S8gC17eHbxrINJFsiMY = [],[],[],[]
	if Ba6pEsGAHxD8wI:
		RxY0QDOSFmUcBHwi754Kg2J = 'mp4'
		for ijdIAWp2rywmbSMnOYXH,OzWg1yEQG8wtvJ4x2ic9aKedFAPD in Ba6pEsGAHxD8wI:
			zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('tab-content quality" id="'+ijdIAWp2rywmbSMnOYXH+'".*?</div>.\s*</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q.append(WWU7QJP2tyTRLIfDh0csxbkvX)
			S8gC17eHbxrINJFsiMY.append(OzWg1yEQG8wtvJ4x2ic9aKedFAPD)
	else:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="qualities(.*?)<h3.*?>(.*?)<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if not zz3eHskxE6lAyDR5cNj1ug:
			OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			WWU7QJP2tyTRLIfDh0csxbkvX,filename = zz3eHskxE6lAyDR5cNj1ug[0]
			QNenGy4527KtTFYlXjLuEacwHo = ['zip','rar','txt','pdf','htm','tar','iso','html']
			RxY0QDOSFmUcBHwi754Kg2J = filename.rsplit('.',1)[1].strip(hSXlxL9iB05c)
			if RxY0QDOSFmUcBHwi754Kg2J in QNenGy4527KtTFYlXjLuEacwHo:
				OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'الملف ليس فيديو ولا صوت')
				return
		Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q.append(WWU7QJP2tyTRLIfDh0csxbkvX)
		S8gC17eHbxrINJFsiMY.append(nA5dhMRg6ENzsB0l1GwvH7aIr2)
	for q3kZpRe28O0s1NaCXQ9SMuGKin in range(len(Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q)):
		HRpMVv1x5ol9gbsnQquj = PAztbuyYo4Kvd.findall('href="(.*?)".*?icon-(.*?)"',Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q[q3kZpRe28O0s1NaCXQ9SMuGKin],PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,Gak2NF9fDugVE0L1Rit3qlmQv in HRpMVv1x5ol9gbsnQquj:
			if 'torrent' in Gak2NF9fDugVE0L1Rit3qlmQv: continue
			elif 'download' in Gak2NF9fDugVE0L1Rit3qlmQv: type = 'download'
			elif 'play' in Gak2NF9fDugVE0L1Rit3qlmQv: type = 'watch'
			else: type = 'unknown'
			ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named=__'+type+'____'+S8gC17eHbxrINJFsiMY[q3kZpRe28O0s1NaCXQ9SMuGKin]+'__akwam'
			ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(ce9zAaVFswSq6lLr82DfQyotGW,wgj0rX5tbcxPulhmny,'video',url)
	return
def NNihMcqGKQEvLz6l(url,filter):
	J8bDm67uSQ53EOUiltdTPRhcgNKY = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==nA5dhMRg6ENzsB0l1GwvH7aIr2: vvXcyZhkfV,guikd57yRSCMsNmlUqFHWAYL = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	else: vvXcyZhkfV,guikd57yRSCMsNmlUqFHWAYL = filter.split('___')
	if type=='CATEGORIES':
		if J8bDm67uSQ53EOUiltdTPRhcgNKY[0]+'=' not in vvXcyZhkfV: kvfOU7Tpz958QBqnIlaAePLys = J8bDm67uSQ53EOUiltdTPRhcgNKY[0]
		for q3kZpRe28O0s1NaCXQ9SMuGKin in range(len(J8bDm67uSQ53EOUiltdTPRhcgNKY[0:-1])):
			if J8bDm67uSQ53EOUiltdTPRhcgNKY[q3kZpRe28O0s1NaCXQ9SMuGKin]+'=' in vvXcyZhkfV: kvfOU7Tpz958QBqnIlaAePLys = J8bDm67uSQ53EOUiltdTPRhcgNKY[q3kZpRe28O0s1NaCXQ9SMuGKin+1]
		FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+kvfOU7Tpz958QBqnIlaAePLys+'=0'
		QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+kvfOU7Tpz958QBqnIlaAePLys+'=0'
		TB6HLPpacsK8f034jvYx7SNgFd = FqCItdu32L9hNwcEXWoges4R68KS.strip('&')+'___'+QA6C8r4lEdhemfJPRc.strip('&')
		OQmDdTI7hU4Lv3BfexPVKgRF8YN = EdpkojMzLm6b3ZSVcXwi0CPRIH(guikd57yRSCMsNmlUqFHWAYL,'all')
		KteRnFMjHpBPqNf8 = url+'?'+OQmDdTI7hU4Lv3BfexPVKgRF8YN
	elif type=='FILTERS':
		iEa2qGQctFxX = EdpkojMzLm6b3ZSVcXwi0CPRIH(vvXcyZhkfV,'modified_values')
		iEa2qGQctFxX = pvOytL0nF7JY6flXTxAcHbQeNahu3(iEa2qGQctFxX)
		if guikd57yRSCMsNmlUqFHWAYL!=nA5dhMRg6ENzsB0l1GwvH7aIr2: guikd57yRSCMsNmlUqFHWAYL = EdpkojMzLm6b3ZSVcXwi0CPRIH(guikd57yRSCMsNmlUqFHWAYL,'all')
		if guikd57yRSCMsNmlUqFHWAYL==nA5dhMRg6ENzsB0l1GwvH7aIr2: KteRnFMjHpBPqNf8 = url
		else: KteRnFMjHpBPqNf8 = url+'?'+guikd57yRSCMsNmlUqFHWAYL
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'أظهار قائمة الفيديو التي تم اختيارها',KteRnFMjHpBPqNf8,241,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1')
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+' [[   '+iEa2qGQctFxX+'   ]]',KteRnFMjHpBPqNf8,241,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1')
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,True,'AKWAM-FILTERS_MENU-1st')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('<form id(.*?)</form>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	AAkSjd9agcy = PAztbuyYo4Kvd.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	dict = {}
	for xWwIXcK0L61EBgtn7smr,name,WWU7QJP2tyTRLIfDh0csxbkvX in AAkSjd9agcy:
		items = PAztbuyYo4Kvd.findall('<option(.*?)>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if '=' not in KteRnFMjHpBPqNf8: KteRnFMjHpBPqNf8 = url
		if type=='CATEGORIES':
			if kvfOU7Tpz958QBqnIlaAePLys!=xWwIXcK0L61EBgtn7smr: continue
			elif len(items)<=1:
				if xWwIXcK0L61EBgtn7smr==J8bDm67uSQ53EOUiltdTPRhcgNKY[-1]: LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(KteRnFMjHpBPqNf8)
				else: NNihMcqGKQEvLz6l(KteRnFMjHpBPqNf8,'CATEGORIES___'+TB6HLPpacsK8f034jvYx7SNgFd)
				return
			else:
				if xWwIXcK0L61EBgtn7smr==J8bDm67uSQ53EOUiltdTPRhcgNKY[-1]: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع',KteRnFMjHpBPqNf8,241,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1')
				else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع',KteRnFMjHpBPqNf8,245,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,TB6HLPpacsK8f034jvYx7SNgFd)
		elif type=='FILTERS':
			FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+xWwIXcK0L61EBgtn7smr+'=0'
			QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+xWwIXcK0L61EBgtn7smr+'=0'
			TB6HLPpacsK8f034jvYx7SNgFd = FqCItdu32L9hNwcEXWoges4R68KS+'___'+QA6C8r4lEdhemfJPRc
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع : '+name,KteRnFMjHpBPqNf8,244,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,TB6HLPpacsK8f034jvYx7SNgFd)
		dict[xWwIXcK0L61EBgtn7smr] = {}
		for value,DOT0LXwgoHYkFBC4MbxN53 in items:
			if DOT0LXwgoHYkFBC4MbxN53 in SAsGubf1jW2Q3p: continue
			if 'value' not in value: value = DOT0LXwgoHYkFBC4MbxN53
			else: value = PAztbuyYo4Kvd.findall('"(.*?)"',value,PAztbuyYo4Kvd.DOTALL)[0]
			dict[xWwIXcK0L61EBgtn7smr][value] = DOT0LXwgoHYkFBC4MbxN53
			FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+xWwIXcK0L61EBgtn7smr+'='+DOT0LXwgoHYkFBC4MbxN53
			QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+xWwIXcK0L61EBgtn7smr+'='+value
			b97AdvPkWGEBe3ayj1Jhmcq2LVxr = FqCItdu32L9hNwcEXWoges4R68KS+'___'+QA6C8r4lEdhemfJPRc
			title = DOT0LXwgoHYkFBC4MbxN53+' : '#+dict[xWwIXcK0L61EBgtn7smr]['0']
			title = DOT0LXwgoHYkFBC4MbxN53+' : '+name
			if type=='FILTERS': TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,244,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,b97AdvPkWGEBe3ayj1Jhmcq2LVxr)
			elif type=='CATEGORIES' and J8bDm67uSQ53EOUiltdTPRhcgNKY[-2]+'=' in vvXcyZhkfV:
				OQmDdTI7hU4Lv3BfexPVKgRF8YN = EdpkojMzLm6b3ZSVcXwi0CPRIH(QA6C8r4lEdhemfJPRc,'all')
				w7Ol6FnokgJDSsIt = url+'?'+OQmDdTI7hU4Lv3BfexPVKgRF8YN
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,w7Ol6FnokgJDSsIt,241,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1')
			else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,245,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,b97AdvPkWGEBe3ayj1Jhmcq2LVxr)
	return
def EdpkojMzLm6b3ZSVcXwi0CPRIH(tgsLX2uACmFhVznejRy6O,mode):
	tgsLX2uACmFhVznejRy6O = tgsLX2uACmFhVznejRy6O.strip('&')
	bpoRYqt38j = {}
	if '=' in tgsLX2uACmFhVznejRy6O:
		items = tgsLX2uACmFhVznejRy6O.split('&')
		for CQtNwXGVAJ2y5nBY in items:
			eehzynNs85aTHrgCUmFc3DBO12,value = CQtNwXGVAJ2y5nBY.split('=')
			bpoRYqt38j[eehzynNs85aTHrgCUmFc3DBO12] = value
	H5ROYNwvQFkBiVElThr = nA5dhMRg6ENzsB0l1GwvH7aIr2
	F45fPJwzqEWNISAml = ['section','category','rating','year','language','formats','quality']
	for key in F45fPJwzqEWNISAml:
		if key in list(bpoRYqt38j.keys()): value = bpoRYqt38j[key]
		else: value = '0'
		if mode=='modified_values' and value!='0': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+' + '+value
		elif mode=='modified_filters' and value!='0': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+'&'+key+'='+value
		elif mode=='all': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+'&'+key+'='+value
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.strip(' + ')
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.strip('&')
	return H5ROYNwvQFkBiVElThr
# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'FAJERSHOW'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_FJS_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
SAsGubf1jW2Q3p = ['التصنيفات','انشاء حساب','طلبات الزوّار']
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==390: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==391: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,text)
	elif mode==392: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==393: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LLabVp7hzj28CE0f1udx(url)
	elif mode==399: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,399,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'FAJERSHOW-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	items = PAztbuyYo4Kvd.findall('<header>.*?<h2>(.*?)<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	for XXJAOcyjfEhSxC in range(len(items)):
		title = items[XXJAOcyjfEhSxC]
		TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,GiqvpBF9xLEdHDr37byJSngeCQ,391,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'latest'+str(XXJAOcyjfEhSxC))
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مختارات عشوائية',GiqvpBF9xLEdHDr37byJSngeCQ,391,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'randoms')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'أعلى الأفلام تقييماً',GiqvpBF9xLEdHDr37byJSngeCQ,391,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'top_imdb_movies')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'أعلى المسلسلات تقييماً',GiqvpBF9xLEdHDr37byJSngeCQ,391,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'top_imdb_series')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'أفلام مميزة',GiqvpBF9xLEdHDr37byJSngeCQ+'/movies',391,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'featured_movies')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مسلسلات مميزة',GiqvpBF9xLEdHDr37byJSngeCQ+'/tvshows',391,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'featured_tvshows')
	WWU7QJP2tyTRLIfDh0csxbkvX = nA5dhMRg6ENzsB0l1GwvH7aIr2
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="menu"(.*?)id="contenedor"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug: WWU7QJP2tyTRLIfDh0csxbkvX += zz3eHskxE6lAyDR5cNj1ug[0]
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',GiqvpBF9xLEdHDr37byJSngeCQ+'/movies',nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'FAJERSHOW-MENU-2nd')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="releases"(.*?)aside',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug: WWU7QJP2tyTRLIfDh0csxbkvX += zz3eHskxE6lAyDR5cNj1ug[0]
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	gtazKNuwmbOV5Rs3Q = True
	for ZylHkumQ8zD0,title in items:
		title = HH8SJuswDBPtniebmkXIr(title)
		if title=='الأعلى مشاهدة':
			if gtazKNuwmbOV5Rs3Q:
				title = 'الافلام '+title
				gtazKNuwmbOV5Rs3Q = False
			else: title = 'المسلسلات '+title
		if title not in SAsGubf1jW2Q3p:
			if title=='أفلام': TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,GiqvpBF9xLEdHDr37byJSngeCQ+'/movies',391,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'all_movies_tvshows')
			elif title=='مسلسلات': TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,GiqvpBF9xLEdHDr37byJSngeCQ+'/tvshows',391,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'all_movies_tvshows')
			else: TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,391)
	return kl2ZWdy8rXcHT
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,type):
	WWU7QJP2tyTRLIfDh0csxbkvX,items = [],[]
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'FAJERSHOW-TITLES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	if type in ['featured_movies','featured_tvshows']:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="content"(.*?)id="archive-content"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug: WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	elif type=='all_movies_tvshows':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('id="archive-content"(.*?)class="pagination"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug: WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	elif type=='top_imdb_movies':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall("class='top-imdb-list tleft(.*?)class='top-imdb-list tright",kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall("src='(.*?)'.*?href='(.*?)'>(.*?)<",WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	elif type=='top_imdb_series':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall("class='top-imdb-list tright(.*?)footer",kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall("src='(.*?)'.*?href='(.*?)'>(.*?)<",WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	elif type=='search':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="search-page"(.*?)class="sidebar',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall('src="(.*?)".*?href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	elif type=='sider':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="widget(.*?)class="widget',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		GP2jb0Bi4DJ85X9qYapMFEdWHT = PAztbuyYo4Kvd.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		ce9zAaVFswSq6lLr82DfQyotGW,A7cIH0dQfVkM3Uxs14O9nGtoN,ecU4Hy7lNS = zip(*GP2jb0Bi4DJ85X9qYapMFEdWHT)
		items = zip(A7cIH0dQfVkM3Uxs14O9nGtoN,ce9zAaVFswSq6lLr82DfQyotGW,ecU4Hy7lNS)
	elif type=='randoms':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('id="slider-movies-tvshows"(.*?)<header>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	elif 'latest' in type:
		XXJAOcyjfEhSxC = int(type[-1:])
		kl2ZWdy8rXcHT = kl2ZWdy8rXcHT.replace('<header>','<end><start>')
		kl2ZWdy8rXcHT = kl2ZWdy8rXcHT.replace('</div></div></div>','</div></div></div><end>')
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('<start>(.*?)<end>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[XXJAOcyjfEhSxC]
		if XXJAOcyjfEhSxC==6:
			GP2jb0Bi4DJ85X9qYapMFEdWHT = PAztbuyYo4Kvd.findall('src="(.*?)" alt="(.*?)".*?href="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			A7cIH0dQfVkM3Uxs14O9nGtoN,ecU4Hy7lNS,ce9zAaVFswSq6lLr82DfQyotGW = zip(*GP2jb0Bi4DJ85X9qYapMFEdWHT)
			items = zip(A7cIH0dQfVkM3Uxs14O9nGtoN,ce9zAaVFswSq6lLr82DfQyotGW,ecU4Hy7lNS)
	else:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="content"(.*?)class="(pagination|sidebar)',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0][0]
			if '/collection/' in url:
				items = PAztbuyYo4Kvd.findall('src="(.*?)".*?href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			elif '/quality/' in url:
				items = PAztbuyYo4Kvd.findall('src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	if not items and WWU7QJP2tyTRLIfDh0csxbkvX:
		items = PAztbuyYo4Kvd.findall('src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	u0UiTmzYN6I3Q9eCZVoB = []
	for HRlygv7YwjzbSLt8fkEerq2,ZylHkumQ8zD0,title in items:
		if 'src=' in title: continue
		if 'serie' in title:
			title = PAztbuyYo4Kvd.findall('^(.*?)<.*?serie">(.*?)<',title,PAztbuyYo4Kvd.DOTALL)
			title = title[0][1]
			if title in u0UiTmzYN6I3Q9eCZVoB: continue
			u0UiTmzYN6I3Q9eCZVoB.append(title)
			title = '_MOD_'+title
		g7qwMTAPoVpIyQUaDeNOnhvs = PAztbuyYo4Kvd.findall('^(.*?)<',title,PAztbuyYo4Kvd.DOTALL)
		if g7qwMTAPoVpIyQUaDeNOnhvs: title = g7qwMTAPoVpIyQUaDeNOnhvs[0]
		title = HH8SJuswDBPtniebmkXIr(title)
		if '/tvshows/' in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,393,HRlygv7YwjzbSLt8fkEerq2)
		elif '/episodes/' in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,393,HRlygv7YwjzbSLt8fkEerq2)
		elif '/seasons/' in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,393,HRlygv7YwjzbSLt8fkEerq2)
		elif '/collection/' in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,391,HRlygv7YwjzbSLt8fkEerq2)
		else: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,392,HRlygv7YwjzbSLt8fkEerq2)
	if type not in ['featured_movies','featured_tvshows']:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"pagination"(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,title in items:
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+title,ZylHkumQ8zD0,391,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,type)
	return
def LLabVp7hzj28CE0f1udx(url):
	DQ7XgFltujVL = C2gnJ5tXFk9pAL(url,'url')
	url = url.replace(DQ7XgFltujVL,GiqvpBF9xLEdHDr37byJSngeCQ)
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'FAJERSHOW-EPISODES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	nR3YVtZDPs1IpAC = PAztbuyYo4Kvd.findall('class="C rated".*?>(.*?)<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if nR3YVtZDPs1IpAC and g4gUOtGiVkoNuaBrHhx8L(wgj0rX5tbcxPulhmny,url,nR3YVtZDPs1IpAC): return
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('''<ul class=["']episodios["']>(.*?)</ul></div></div></div>''',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('''src=["'](.*?)["'].*?href=["'](.*?)["']>(.*?)</a>''',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for HRlygv7YwjzbSLt8fkEerq2,ZylHkumQ8zD0,title in items:
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,392,HRlygv7YwjzbSLt8fkEerq2)
	return
def lNBcUr8RCn(url):
	url = url.replace('//show.alfajertv.com/','//fajer.show/')
	kl2ZWdy8rXcHT = zzTUovwI31dFPiMLg4r7G(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'FAJERSHOW-PLAY-1st')
	nR3YVtZDPs1IpAC = PAztbuyYo4Kvd.findall('class="C rated".*?>(.*?)<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if nR3YVtZDPs1IpAC and g4gUOtGiVkoNuaBrHhx8L(wgj0rX5tbcxPulhmny,url,nR3YVtZDPs1IpAC): return
	ce9zAaVFswSq6lLr82DfQyotGW = []
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('id="player-option-1"(.*?)class=["|\'](sheader|pag_episodes)["|\']',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0][0]
		items = PAztbuyYo4Kvd.findall('data-type="(.*?)" data-post="(.*?)" data-nume="(.*?)".*?class="vid_title">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for type,PsbTIOQmGgNEV0Dx3Lv45WCyJMat,SSO0anLeywpMs569i4gGrQk,title in items:
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/wp-admin/admin-ajax.php?action=doo_player_ajax&post='+PsbTIOQmGgNEV0Dx3Lv45WCyJMat+'&nume='+SSO0anLeywpMs569i4gGrQk+'&type='+type
			ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named='+title+'__watch'
			ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('''id=["']download["'] class(.*?)class=["']sbox["']''',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('''img src=["'](.*?)["'].*?href=["'](.*?)["'].*?["']quality["']>(.*?)<.*?<td>(.*?)<''',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for HRlygv7YwjzbSLt8fkEerq2,ZylHkumQ8zD0,OzWg1yEQG8wtvJ4x2ic9aKedFAPD,VshXJcSOFngPKYQIC47a in items:
			if '=' in HRlygv7YwjzbSLt8fkEerq2:
				TBKorJgVLH2xDP8NkswXhMz7tnWZSF = HRlygv7YwjzbSLt8fkEerq2.split('=')[1]
				title = C2gnJ5tXFk9pAL(TBKorJgVLH2xDP8NkswXhMz7tnWZSF,'host')
			else: title = nA5dhMRg6ENzsB0l1GwvH7aIr2
			title = VshXJcSOFngPKYQIC47a+hSXlxL9iB05c+title
			ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named='+title+'__download____'+OzWg1yEQG8wtvJ4x2ic9aKedFAPD
			ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(ce9zAaVFswSq6lLr82DfQyotGW,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	search = search.replace(hSXlxL9iB05c,'+')
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/?s='+search
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,'search')
	return
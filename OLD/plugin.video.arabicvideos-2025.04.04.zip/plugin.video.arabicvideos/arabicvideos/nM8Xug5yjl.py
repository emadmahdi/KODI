# -*- coding: utf-8 -*-
from pR2X91txEm import *
headers = { 'User-Agent' : nA5dhMRg6ENzsB0l1GwvH7aIr2 }
wgj0rX5tbcxPulhmny = 'AKOAM'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_AKO_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
RkHmyInjC5sVAG = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==70: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==71: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = c4cJvKylRSok1WCxnPVgLapErBFhHm(url)
	elif mode==72: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,text)
	elif mode==73: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = h2dFOgQJW38n4Gqei7Vx5DU(url)
	elif mode==74: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==79: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,79,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'سلسلة افلام',nA5dhMRg6ENzsB0l1GwvH7aIr2,79,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'سلسلة افلام')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'سلاسل منوعة',nA5dhMRg6ENzsB0l1GwvH7aIr2,79,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'سلسلة')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	SAsGubf1jW2Q3p = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'AKOAM-MENU-1st')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="partions"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			if title not in SAsGubf1jW2Q3p:
				TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,71)
	return kl2ZWdy8rXcHT
def c4cJvKylRSok1WCxnPVgLapErBFhHm(url):
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'AKOAM-CATEGORIES-1st')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('sect_parts(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			title = title.strip(hSXlxL9iB05c)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,72)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'جميع الفروع',url,72)
	else: LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,nA5dhMRg6ENzsB0l1GwvH7aIr2)
	return
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,type):
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('section_title featured_title(.*?)subjects-crousel',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	elif type=='search':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('akoam_result(.*?)<script',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	elif type=='more':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('section_title more_title(.*?)footer_bottom_services',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	else:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('navigation(.*?)<script',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if not items and zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c)
		title = HH8SJuswDBPtniebmkXIr(title)
		if any(value in title for value in RkHmyInjC5sVAG): TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,73,HRlygv7YwjzbSLt8fkEerq2)
		else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,73,HRlygv7YwjzbSLt8fkEerq2)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="pagination"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall("</li><li >.*?href='(.*?)'>(.*?)<",WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+title,ZylHkumQ8zD0,72,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,type)
	return
def Ij6ZO3flobMUwQAsxRmXav(url):
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,True,'AKOAM-SECTIONS-2nd')
	KteRnFMjHpBPqNf8 = PAztbuyYo4Kvd.findall('"href","(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	KteRnFMjHpBPqNf8 = KteRnFMjHpBPqNf8[1]
	return KteRnFMjHpBPqNf8
def h2dFOgQJW38n4Gqei7Vx5DU(url):
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,True,'AKOAM-SECTIONS-1st')
	bt8sr5jZL7RcESABO9gl = PAztbuyYo4Kvd.findall('"(https*://akwam.net/\w+.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	RC2TipMjJfe9WAysBHLUI3vx8 = PAztbuyYo4Kvd.findall('"(https*://underurl.com/\w+.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if bt8sr5jZL7RcESABO9gl or RC2TipMjJfe9WAysBHLUI3vx8:
		if bt8sr5jZL7RcESABO9gl: w7Ol6FnokgJDSsIt = bt8sr5jZL7RcESABO9gl[0]
		elif RC2TipMjJfe9WAysBHLUI3vx8: w7Ol6FnokgJDSsIt = Ij6ZO3flobMUwQAsxRmXav(RC2TipMjJfe9WAysBHLUI3vx8[0])
		w7Ol6FnokgJDSsIt = pvOytL0nF7JY6flXTxAcHbQeNahu3(w7Ol6FnokgJDSsIt)
		import zd1NUSb7FV
		if '/series/' in w7Ol6FnokgJDSsIt or '/shows/' in w7Ol6FnokgJDSsIt: zd1NUSb7FV.LLabVp7hzj28CE0f1udx(w7Ol6FnokgJDSsIt)
		else: zd1NUSb7FV.lNBcUr8RCn(w7Ol6FnokgJDSsIt)
		return
	nR3YVtZDPs1IpAC = PAztbuyYo4Kvd.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if nR3YVtZDPs1IpAC and g4gUOtGiVkoNuaBrHhx8L(wgj0rX5tbcxPulhmny,url,nR3YVtZDPs1IpAC): return
	items = PAztbuyYo4Kvd.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title in items:
		title = HH8SJuswDBPtniebmkXIr(title)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,73)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if not zz3eHskxE6lAyDR5cNj1ug:
		ggYilKR5rMDyp7B('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,HRlygv7YwjzbSLt8fkEerq2,WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	name = name.strip(hSXlxL9iB05c)
	if 'sub_epsiode_title' in WWU7QJP2tyTRLIfDh0csxbkvX:
		items = PAztbuyYo4Kvd.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	else:
		sA9O1eCyNGhr = PAztbuyYo4Kvd.findall('sub_file_title\'>(.*?) - <i>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		items = []
		for filename in sA9O1eCyNGhr:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل',nA5dhMRg6ENzsB0l1GwvH7aIr2) ]
	count = 0
	ecU4Hy7lNS,N2ugCYQnwtc6Sb = [],[]
	size = len(items)
	for title,filename in items:
		RxY0QDOSFmUcBHwi754Kg2J = nA5dhMRg6ENzsB0l1GwvH7aIr2
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: RxY0QDOSFmUcBHwi754Kg2J = filename.split('.')[-1]
		title = title.replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c)
		ecU4Hy7lNS.append(title)
		N2ugCYQnwtc6Sb.append(count)
		count += 1
	if size>0:
		if any(value in name for value in RkHmyInjC5sVAG):
			if size==1:
				iP7AUR41exzlKyZIf9Mt3u = 0
			else:
				iP7AUR41exzlKyZIf9Mt3u = ccAMwn7hflDev8Kd3aqP('اختر الفيديو المناسب:', ecU4Hy7lNS)
				if iP7AUR41exzlKyZIf9Mt3u == -1: return
			lNBcUr8RCn(url+'?section='+str(1+N2ugCYQnwtc6Sb[size-iP7AUR41exzlKyZIf9Mt3u-1]))
		else:
			for q3kZpRe28O0s1NaCXQ9SMuGKin in reversed(range(size)):
				title = name + ' - ' + ecU4Hy7lNS[q3kZpRe28O0s1NaCXQ9SMuGKin]
				title = title.replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c)
				ZylHkumQ8zD0 = url + '?section='+str(size-q3kZpRe28O0s1NaCXQ9SMuGKin)
				TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,74,HRlygv7YwjzbSLt8fkEerq2)
	else:
		TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الرابط ليس فيديو',nA5dhMRg6ENzsB0l1GwvH7aIr2,9999,HRlygv7YwjzbSLt8fkEerq2)
	return
def lNBcUr8RCn(url):
	KteRnFMjHpBPqNf8,JfNHOP2BK1Yxl7Rq4 = url.split('?section=')
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,True,nA5dhMRg6ENzsB0l1GwvH7aIr2,'AKOAM-PLAY_AKOAM-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	BjqVlbGZS8IQKh6Wtw4iUE = zz3eHskxE6lAyDR5cNj1ug[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	BjqVlbGZS8IQKh6Wtw4iUE = BjqVlbGZS8IQKh6Wtw4iUE + 'direct_link_box'
	Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q = PAztbuyYo4Kvd.findall('epsoide_box(.*?)direct_link_box',BjqVlbGZS8IQKh6Wtw4iUE,PAztbuyYo4Kvd.DOTALL)
	JfNHOP2BK1Yxl7Rq4 = len(Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q)-int(JfNHOP2BK1Yxl7Rq4)
	WWU7QJP2tyTRLIfDh0csxbkvX = Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q[JfNHOP2BK1Yxl7Rq4]
	HtT6mBGwMaq1o0rybzZ4 = []
	u7JvsaVRFHYy3p1W4X5EhokZqI = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = PAztbuyYo4Kvd.findall("class='download_btn.*?href='(.*?)'",WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0 in items:
		HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0+'?named=________akoam')
	items = PAztbuyYo4Kvd.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for BtAcMohY9pIlE,ZylHkumQ8zD0 in items:
		BtAcMohY9pIlE = BtAcMohY9pIlE.split('/')[-1]
		BtAcMohY9pIlE = BtAcMohY9pIlE.split('.')[0]
		if BtAcMohY9pIlE in u7JvsaVRFHYy3p1W4X5EhokZqI:
			HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0+'?named='+u7JvsaVRFHYy3p1W4X5EhokZqI[BtAcMohY9pIlE]+'________akoam')
		else: HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0+'?named='+BtAcMohY9pIlE+'________akoam')
	if not HtT6mBGwMaq1o0rybzZ4:
		message = PAztbuyYo4Kvd.findall('sub-no-file.*?\n(.*?)\n',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if message: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'رسالة من الموقع الاصلي',message[0])
	else:
		import wW9Vexi6dl
		wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(HtT6mBGwMaq1o0rybzZ4,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	SEGtTsCyUVi0lo4LJkH5 = search.replace(hSXlxL9iB05c,'%20')
	url = GiqvpBF9xLEdHDr37byJSngeCQ + '/search/'+SEGtTsCyUVi0lo4LJkH5
	V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,'search')
	return
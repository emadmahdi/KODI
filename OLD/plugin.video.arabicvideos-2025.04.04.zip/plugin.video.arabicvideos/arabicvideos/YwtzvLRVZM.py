# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'AKWAMTUBE'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_AKT_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
SAsGubf1jW2Q3p = ['الرئيسية','يلا شوت']
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==850: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==851: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,text)
	elif mode==852: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==853: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = mHOkYD6jtvyEnVqWT(url)
	elif mode==859: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'AKWAMTUBE-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,859,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"primary-links"(.*?)</u',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?<span>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			if title in SAsGubf1jW2Q3p: continue
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,851)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"list-categories"(.*?)</u',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+ZylHkumQ8zD0.lstrip('/')
			if title in SAsGubf1jW2Q3p: continue
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,851)
	return
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,type=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'AKWAMTUBE-TITLES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"home-content"(.*?)"footer"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		WWU7QJP2tyTRLIfDh0csxbkvX = WWU7QJP2tyTRLIfDh0csxbkvX.replace('"overlay"','"duration"><')
		items = PAztbuyYo4Kvd.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		u0UiTmzYN6I3Q9eCZVoB = []
		for HRlygv7YwjzbSLt8fkEerq2,yoaKx7FtIlvcD,ZylHkumQ8zD0,title in items:
			title = title.strip(' ')
			title = HH8SJuswDBPtniebmkXIr(title)
			JfNHOP2BK1Yxl7Rq4 = PAztbuyYo4Kvd.findall('(.*?) (الحلقة|حلقة).\d+',title,PAztbuyYo4Kvd.DOTALL)
			if 0 and 'episodes' not in zzU5PnmRv13toWs4bDFL and JfNHOP2BK1Yxl7Rq4:
				title = '_MOD_' + JfNHOP2BK1Yxl7Rq4[0][0]
				title = title.replace('اون لاين',nA5dhMRg6ENzsB0l1GwvH7aIr2)
				if title not in u0UiTmzYN6I3Q9eCZVoB:
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,853,HRlygv7YwjzbSLt8fkEerq2)
					u0UiTmzYN6I3Q9eCZVoB.append(title)
			else: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,852,HRlygv7YwjzbSLt8fkEerq2,yoaKx7FtIlvcD)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('''["']pagination["'](.*?)["']footer["']''',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			title = HH8SJuswDBPtniebmkXIr(title)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+title,ZylHkumQ8zD0,851,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,type)
	return
def mHOkYD6jtvyEnVqWT(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'AKWAMTUBE-SERIES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="eplist"(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		GGr9WlIhv1BKDJjTZFNty4R3k0dCOA = PAztbuyYo4Kvd.findall('href="(.*?)" title="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in GGr9WlIhv1BKDJjTZFNty4R3k0dCOA:
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,872)
	else:
		ZylHkumQ8zD0 = PAztbuyYo4Kvd.findall('"category".*?href="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if ZylHkumQ8zD0:
			ZylHkumQ8zD0 = kGE6zoKSan54W(ZylHkumQ8zD0[0])
			LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(ZylHkumQ8zD0,'episodes')
	return
def lNBcUr8RCn(url):
	HtT6mBGwMaq1o0rybzZ4 = []
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'AKWAMTUBE-PLAY-2nd')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	if 'hash=' in kl2ZWdy8rXcHT:
		fvO9ALlsjT8qzIRi5MtPE01mQSJg = PAztbuyYo4Kvd.findall('hash=(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		fvO9ALlsjT8qzIRi5MtPE01mQSJg = list(set(fvO9ALlsjT8qzIRi5MtPE01mQSJg))
		for PsbTIOQmGgNEV0Dx3Lv45WCyJMat in fvO9ALlsjT8qzIRi5MtPE01mQSJg:
			kaX7315BPMRtmpWd = []
			yoGhEciOC1 = PsbTIOQmGgNEV0Dx3Lv45WCyJMat.split('__')
			for I4cgT6JwrH01 in yoGhEciOC1:
				try:
					I4cgT6JwrH01 = Ic92Lb6lnzM5KJsx4Y3UGa70imZo.b64decode(I4cgT6JwrH01+'=')
					if BsLJ7p5Av2Vm0SQeCO1o: I4cgT6JwrH01 = I4cgT6JwrH01.decode(YWEQ3Cf8RevpD0m7NjF1)
					kaX7315BPMRtmpWd.append(I4cgT6JwrH01)
				except: pass
			HRpMVv1x5ol9gbsnQquj = '>'.join(kaX7315BPMRtmpWd)
			HRpMVv1x5ol9gbsnQquj = HRpMVv1x5ol9gbsnQquj.splitlines()
			for ZylHkumQ8zD0 in HRpMVv1x5ol9gbsnQquj:
				if ' => ' in ZylHkumQ8zD0:
					title,ZylHkumQ8zD0 = ZylHkumQ8zD0.split(' => ')
					ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named='+title+'__watch'
					HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0)
	elif 'post_id' in kl2ZWdy8rXcHT:
		FPAhgMwOp1YSLN = PAztbuyYo4Kvd.findall("post_id = '(.*?)'",kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if FPAhgMwOp1YSLN:
			FPAhgMwOp1YSLN = FPAhgMwOp1YSLN[0]
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/wp-admin/admin-ajax.php?action=video_info&post_id='+FPAhgMwOp1YSLN
			Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',ZylHkumQ8zD0,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ALMSTBA-PLAY-2nd')
			kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
			HRpMVv1x5ol9gbsnQquj = PAztbuyYo4Kvd.findall('"name":"(.*?)","src":"(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
			if not HRpMVv1x5ol9gbsnQquj: HRpMVv1x5ol9gbsnQquj = PAztbuyYo4Kvd.findall('"(src)":"(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
			for name,ZylHkumQ8zD0 in HRpMVv1x5ol9gbsnQquj:
				ZylHkumQ8zD0 = ZylHkumQ8zD0.replace('\\/','/')
				ZylHkumQ8zD0 = kGE6zoKSan54W(ZylHkumQ8zD0)
				if name=='src': name = ''
				HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0+'?named='+name+'__watch')
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(HtT6mBGwMaq1o0rybzZ4,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	search = search.replace(hSXlxL9iB05c,'+')
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/?s='+search
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,'search')
	return
# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'ALARAB'
headers = {'User-Agent':nA5dhMRg6ENzsB0l1GwvH7aIr2}
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_KLA_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==10: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==11: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
	elif mode==12: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==13: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LLabVp7hzj28CE0f1udx(url)
	elif mode==14: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = CklyboIJDug75niLjhtmNU42fZs9ec()
	elif mode==15: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = K6SBVazZwXeqGD7P3Q91fnrxgFjIhN()
	elif mode==16: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = yyChfYK9vRXVHrWgkx()
	elif mode==19: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,19,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'آخر الإضافات',nA5dhMRg6ENzsB0l1GwvH7aIr2,14)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مسلسلات رمضان',nA5dhMRg6ENzsB0l1GwvH7aIr2,15)
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ALARAB-MENU-1st')
	zz3eHskxE6lAyDR5cNj1ug=PAztbuyYo4Kvd.findall('id="nav-slider"(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	nweul6VWQ1a75hk4 = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('href="(.*?)".*?>(.*?)<',nweul6VWQ1a75hk4,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title in items:
		ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
		title = title.strip(hSXlxL9iB05c)
		TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,11)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('id="navbar"(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	YERWNbgAThV2uBr5taO8zcd = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('href="(.*?)".*?>(.*?)<',YERWNbgAThV2uBr5taO8zcd,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title in items:
		ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
		TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,11)
	return kl2ZWdy8rXcHT
def K6SBVazZwXeqGD7P3Q91fnrxgFjIhN():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'جميع المسلسلات العربية',GiqvpBF9xLEdHDr37byJSngeCQ+'/view-8/مسلسلات-عربية',11)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مسلسلات السنة الأخيرة',nA5dhMRg6ENzsB0l1GwvH7aIr2,16)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مسلسلات رمضان الأخيرة 1',GiqvpBF9xLEdHDr37byJSngeCQ+'/view-8/مسلسلات-رمضان-2022',11)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مسلسلات رمضان الأخيرة 2',GiqvpBF9xLEdHDr37byJSngeCQ+'/view-8/مسلسلات-رمضان-2023',11)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مسلسلات رمضان 2023',GiqvpBF9xLEdHDr37byJSngeCQ+'/ramadan2023/مصرية',11)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مسلسلات رمضان 2022',GiqvpBF9xLEdHDr37byJSngeCQ+'/ramadan2022/مصرية',11)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مسلسلات رمضان 2021',GiqvpBF9xLEdHDr37byJSngeCQ+'/ramadan2021/مصرية',11)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مسلسلات رمضان 2020',GiqvpBF9xLEdHDr37byJSngeCQ+'/ramadan2020/مصرية',11)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مسلسلات رمضان 2019',GiqvpBF9xLEdHDr37byJSngeCQ+'/ramadan2019/مصرية',11)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مسلسلات رمضان 2018',GiqvpBF9xLEdHDr37byJSngeCQ+'/ramadan2018/مصرية',11)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مسلسلات رمضان 2017',GiqvpBF9xLEdHDr37byJSngeCQ+'/ramadan2017/مصرية',11)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مسلسلات رمضان 2016',GiqvpBF9xLEdHDr37byJSngeCQ+'/ramadan2016/مصرية',11)
	return
def CklyboIJDug75niLjhtmNU42fZs9ec():
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,True,'ALARAB-LATEST-1st')
	zz3eHskxE6lAyDR5cNj1ug=PAztbuyYo4Kvd.findall('heading-top(.*?)div class=',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]+zz3eHskxE6lAyDR5cNj1ug[1]
	items=PAztbuyYo4Kvd.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
		url = GiqvpBF9xLEdHDr37byJSngeCQ + ZylHkumQ8zD0
		if 'series' in url: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,11,HRlygv7YwjzbSLt8fkEerq2)
		else: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,12,HRlygv7YwjzbSLt8fkEerq2)
	return
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,True,True,'ALARAB-TITLES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('video-category(.*?)right_content',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if not zz3eHskxE6lAyDR5cNj1ug: return
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	Fb5sZyTgJ8Mz6WiRUDo = False
	items = PAztbuyYo4Kvd.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	u0UiTmzYN6I3Q9eCZVoB,rIgbVtw5WHEM = [],[]
	for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
		if title==nA5dhMRg6ENzsB0l1GwvH7aIr2: title = ZylHkumQ8zD0.split('/')[-1].replace('-',hSXlxL9iB05c)
		Ns6egmVv7nRutdLSQUaE8WFq5 = PAztbuyYo4Kvd.findall('(\d+)',title,PAztbuyYo4Kvd.DOTALL)
		if Ns6egmVv7nRutdLSQUaE8WFq5: Ns6egmVv7nRutdLSQUaE8WFq5 = int(Ns6egmVv7nRutdLSQUaE8WFq5[0])
		else: Ns6egmVv7nRutdLSQUaE8WFq5 = 0
		rIgbVtw5WHEM.append([HRlygv7YwjzbSLt8fkEerq2,ZylHkumQ8zD0,title,Ns6egmVv7nRutdLSQUaE8WFq5])
	rIgbVtw5WHEM = sorted(rIgbVtw5WHEM, reverse=True, key=lambda key: key[3])
	for HRlygv7YwjzbSLt8fkEerq2,ZylHkumQ8zD0,title,Ns6egmVv7nRutdLSQUaE8WFq5 in rIgbVtw5WHEM:
		ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ + ZylHkumQ8zD0
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		title = title.replace('عالية على العرب',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		title = title.replace('مشاهدة مباشرة',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		title = title.replace('اون لاين',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		title = title.replace('اونلاين',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		title = title.replace('بجودة عالية',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		title = title.replace('جودة عالية',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		title = title.replace('بدون تحميل',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		title = title.replace('على العرب',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		title = title.replace('مباشرة',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		title = title.strip(hSXlxL9iB05c).replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c).replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c)
		title = '_MOD_'+title
		g7qwMTAPoVpIyQUaDeNOnhvs = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			JfNHOP2BK1Yxl7Rq4 = PAztbuyYo4Kvd.findall('(.*?) الحلقة \d+',title,PAztbuyYo4Kvd.DOTALL)
			if JfNHOP2BK1Yxl7Rq4: g7qwMTAPoVpIyQUaDeNOnhvs = JfNHOP2BK1Yxl7Rq4[0]
		if g7qwMTAPoVpIyQUaDeNOnhvs not in u0UiTmzYN6I3Q9eCZVoB:
			u0UiTmzYN6I3Q9eCZVoB.append(g7qwMTAPoVpIyQUaDeNOnhvs)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+g7qwMTAPoVpIyQUaDeNOnhvs,ZylHkumQ8zD0,13,HRlygv7YwjzbSLt8fkEerq2)
				Fb5sZyTgJ8Mz6WiRUDo = True
			elif 'series' in ZylHkumQ8zD0:
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,11,HRlygv7YwjzbSLt8fkEerq2)
				Fb5sZyTgJ8Mz6WiRUDo = True
			else:
				TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,12,HRlygv7YwjzbSLt8fkEerq2)
				Fb5sZyTgJ8Mz6WiRUDo = True
	if Fb5sZyTgJ8Mz6WiRUDo:
		items = PAztbuyYo4Kvd.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,Q0f7ytucSriRw8HTzd in items:
			url = GiqvpBF9xLEdHDr37byJSngeCQ + ZylHkumQ8zD0
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+Q0f7ytucSriRw8HTzd,url,11)
	return
def LLabVp7hzj28CE0f1udx(url):
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,True,'ALARAB-EPISODES-1st')
	P1guOVJKRNn80L5sw427BS9FDbm = PAztbuyYo4Kvd.findall('href="(/series.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	KteRnFMjHpBPqNf8 = GiqvpBF9xLEdHDr37byJSngeCQ+P1guOVJKRNn80L5sw427BS9FDbm[0]
	V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(KteRnFMjHpBPqNf8)
	return
def lNBcUr8RCn(url):
	ce9zAaVFswSq6lLr82DfQyotGW = []
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(lPsYQwWdLO520ZHcFV8n1x,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,True,'ALARAB-PLAY-1st')
	KteRnFMjHpBPqNf8 = PAztbuyYo4Kvd.findall('class="resp-iframe" src="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if KteRnFMjHpBPqNf8:
		KteRnFMjHpBPqNf8 = KteRnFMjHpBPqNf8[0]
		HRpMVv1x5ol9gbsnQquj = PAztbuyYo4Kvd.findall('^(http.*?)(http.*?)$',KteRnFMjHpBPqNf8,PAztbuyYo4Kvd.DOTALL)
		if HRpMVv1x5ol9gbsnQquj:
			gtazKNuwmbOV5Rs3Q = HRpMVv1x5ol9gbsnQquj[0][0]
			LzbN6Dnu2JEmYgHxIdaciy7S,FCqVh3624iItUgz = HRpMVv1x5ol9gbsnQquj[0][1].rsplit('/',1)
			w7Ol6FnokgJDSsIt = LzbN6Dnu2JEmYgHxIdaciy7S+'?named=__watch'
			ce9zAaVFswSq6lLr82DfQyotGW.append(w7Ol6FnokgJDSsIt)
			mN3xi4TLMadDl10VHhOAbrXKjZB = gtazKNuwmbOV5Rs3Q+FCqVh3624iItUgz
		else:
			v2u4dgJnek0sQDxKf = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,False,'ALARAB-PLAY-2nd')
			KteRnFMjHpBPqNf8 = PAztbuyYo4Kvd.findall('"src": "(.*?)"',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL)
			if KteRnFMjHpBPqNf8:
				KteRnFMjHpBPqNf8 = KteRnFMjHpBPqNf8[0]+'?named=__watch__m3u8'
				ce9zAaVFswSq6lLr82DfQyotGW.append(KteRnFMjHpBPqNf8)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('searchBox(.*?)<style>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		KteRnFMjHpBPqNf8 = PAztbuyYo4Kvd.findall('href="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if KteRnFMjHpBPqNf8:
			KteRnFMjHpBPqNf8 = KteRnFMjHpBPqNf8[0]+'?named=__watch'
			ce9zAaVFswSq6lLr82DfQyotGW.append(KteRnFMjHpBPqNf8)
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(ce9zAaVFswSq6lLr82DfQyotGW,wgj0rX5tbcxPulhmny,'video',url)
	return
def yyChfYK9vRXVHrWgkx():
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,True,'ALARAB-RAMADAN-1st')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('id="content_sec"(.*?)id="left_content"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('href="(.*?)".*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	czoX3IRbqVPm0Z = PAztbuyYo4Kvd.findall('/ramadan([0-9]+)/',str(items),PAztbuyYo4Kvd.DOTALL)
	czoX3IRbqVPm0Z = czoX3IRbqVPm0Z[0]
	for ZylHkumQ8zD0,title in items:
		url = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
		title = title.strip(hSXlxL9iB05c)+hSXlxL9iB05c+czoX3IRbqVPm0Z
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,11)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	SEGtTsCyUVi0lo4LJkH5 = search.replace(hSXlxL9iB05c,'+')
	url = GiqvpBF9xLEdHDr37byJSngeCQ + "/q/" + SEGtTsCyUVi0lo4LJkH5
	V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
	return
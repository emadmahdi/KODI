# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'EGYNOW'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_EGN_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
SAsGubf1jW2Q3p = ['عروض مصارعة','الكل','n/A','المزيد','قصة عشق']
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==430: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==431: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,text)
	elif mode==432: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==433: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LLabVp7hzj28CE0f1udx(url)
	elif mode==434: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = NNihMcqGKQEvLz6l(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==435: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = NNihMcqGKQEvLz6l(url,'SPECIFIED_FILTER___'+text)
	elif mode==436: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = oWcvptkU2JObI0(url)
	elif mode==437: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ANGWCsYLH8Q0O7(url)
	elif mode==439: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',GiqvpBF9xLEdHDr37byJSngeCQ+'/films',nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYNOW-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	GWjBrpNhRsmt7eDba1yA4nukS = PAztbuyYo4Kvd.findall('"canonical" href="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	GWjBrpNhRsmt7eDba1yA4nukS = GWjBrpNhRsmt7eDba1yA4nukS[0].strip('/')
	GWjBrpNhRsmt7eDba1yA4nukS = C2gnJ5tXFk9pAL(GWjBrpNhRsmt7eDba1yA4nukS,'url')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,439,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فلتر محدد',GWjBrpNhRsmt7eDba1yA4nukS,435)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فلتر كامل',GWjBrpNhRsmt7eDba1yA4nukS,434)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'المضاف حديثا',GWjBrpNhRsmt7eDba1yA4nukS,431)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'افلام اون لاين',GWjBrpNhRsmt7eDba1yA4nukS+'/films1',436)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مسلسلات اون لاين',GWjBrpNhRsmt7eDba1yA4nukS+'/series-all1',436)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'قائمة تفصيلية',GWjBrpNhRsmt7eDba1yA4nukS,437)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"SiteNavigation"(.*?)"Search"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('href="(.*?)".*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title in items:
		if title in SAsGubf1jW2Q3p: continue
		if title=='الرئيسية': continue
		if 'اون لاين' in title: continue
		TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,431)
	return
def ANGWCsYLH8Q0O7(website=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',website+'/films',nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYNOW-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	GWjBrpNhRsmt7eDba1yA4nukS = PAztbuyYo4Kvd.findall('"canonical" href="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	GWjBrpNhRsmt7eDba1yA4nukS = GWjBrpNhRsmt7eDba1yA4nukS[0].strip('/')
	GWjBrpNhRsmt7eDba1yA4nukS = C2gnJ5tXFk9pAL(GWjBrpNhRsmt7eDba1yA4nukS,'url')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"ListDroped"(.*?)"SearchingMaster"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('data-tax="(.*?)" data-term="(.*?)" data-name="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for kvfOU7Tpz958QBqnIlaAePLys,value,title in items:
		if title in SAsGubf1jW2Q3p: continue
		ZylHkumQ8zD0 = website+'/explore/?'+kvfOU7Tpz958QBqnIlaAePLys+'='+value
		TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,431)
	return
def oWcvptkU2JObI0(url):
	GWjBrpNhRsmt7eDba1yA4nukS = C2gnJ5tXFk9pAL(url,'url')
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYNOW-SUBMENU-1st')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع',url,431)
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"titleSectionCon"(.*?)</div></div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('data-key="(.*?)".*?<em>(.*?)</em>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for nCDeSQzlyBIF,title in items:
		if title in SAsGubf1jW2Q3p: continue
		KteRnFMjHpBPqNf8 = GWjBrpNhRsmt7eDba1yA4nukS+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Movies/Keys.php?key='+nCDeSQzlyBIF
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,KteRnFMjHpBPqNf8,431)
	return
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,YsdSH10ta6wvi4nMRIO9=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	GWjBrpNhRsmt7eDba1yA4nukS = C2gnJ5tXFk9pAL(url,'url')
	items = []
	if '/Terms.php' in url or '/Get.php' in url or '/Keys.php' in url:
		KteRnFMjHpBPqNf8,rA4ZGoQyIHlneVfzNukWd = ss2VIkClmtevKqPUuSx9DGpX(url)
		LevQwm0pbqP1 = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'POST',KteRnFMjHpBPqNf8,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYNOW-TITLES-1st')
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
		WWU7QJP2tyTRLIfDh0csxbkvX = kl2ZWdy8rXcHT
	elif YsdSH10ta6wvi4nMRIO9=='featured':
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYNOW-TITLES-2nd')
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"MainSlider"(.*?)"MatchesTable"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('<a href="(.*?)" title="(.*?)".*?image: url\((.*?)\)',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	else:
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYNOW-TITLES-2nd')
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"BlocksList"(.*?)"Paginate"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if not zz3eHskxE6lAyDR5cNj1ug: zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"BlocksList"(.*?)"titleSectionCon"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	if not items: items = PAztbuyYo4Kvd.findall('<a href="(.*?)" title="(.*?)".*?data-image="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	u0UiTmzYN6I3Q9eCZVoB = []
	hdocEkRK0Q = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for ZylHkumQ8zD0,title,HRlygv7YwjzbSLt8fkEerq2 in items:
		ZylHkumQ8zD0 = pvOytL0nF7JY6flXTxAcHbQeNahu3(ZylHkumQ8zD0).strip('/')
		title = HH8SJuswDBPtniebmkXIr(title)
		JfNHOP2BK1Yxl7Rq4 = PAztbuyYo4Kvd.findall('(.*?) الحلقة \d+',title,PAztbuyYo4Kvd.DOTALL)
		if any(value in title for value in hdocEkRK0Q):
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,432,HRlygv7YwjzbSLt8fkEerq2)
		elif JfNHOP2BK1Yxl7Rq4 and 'الحلقة' in title:
			title = '_MOD_' + JfNHOP2BK1Yxl7Rq4[0]
			if title not in u0UiTmzYN6I3Q9eCZVoB:
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,433,HRlygv7YwjzbSLt8fkEerq2)
				u0UiTmzYN6I3Q9eCZVoB.append(title)
		elif '/movseries/' in ZylHkumQ8zD0:
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,431,HRlygv7YwjzbSLt8fkEerq2)
		else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,433,HRlygv7YwjzbSLt8fkEerq2)
	if YsdSH10ta6wvi4nMRIO9!='featured':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"Paginate"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,title in items:
				if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = GWjBrpNhRsmt7eDba1yA4nukS+ZylHkumQ8zD0
				ZylHkumQ8zD0 = HH8SJuswDBPtniebmkXIr(ZylHkumQ8zD0)
				title = HH8SJuswDBPtniebmkXIr(title)
				if title!=nA5dhMRg6ENzsB0l1GwvH7aIr2: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+title,ZylHkumQ8zD0,431)
		ew4mnlBdYOAbHPViyN1ZkWMGzx50S = PAztbuyYo4Kvd.findall('showmore" href="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if ew4mnlBdYOAbHPViyN1ZkWMGzx50S:
			ZylHkumQ8zD0 = ew4mnlBdYOAbHPViyN1ZkWMGzx50S[0]
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مشاهدة المزيد',ZylHkumQ8zD0,431)
	return
def LLabVp7hzj28CE0f1udx(url):
	GWjBrpNhRsmt7eDba1yA4nukS = C2gnJ5tXFk9pAL(url,'url')
	LKk0YdTN72XmnMuBbw,N5Vbkn2chPGfT3m97Bv1LHKI = [],[]
	if 'Episodes.php' in url:
		KteRnFMjHpBPqNf8,rA4ZGoQyIHlneVfzNukWd = ss2VIkClmtevKqPUuSx9DGpX(url)
		LevQwm0pbqP1 = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'POST',KteRnFMjHpBPqNf8,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYNOW-EPISODES-1st')
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
		N5Vbkn2chPGfT3m97Bv1LHKI = [kl2ZWdy8rXcHT]
	else:
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYNOW-EPISODES-2nd')
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
		LKk0YdTN72XmnMuBbw = PAztbuyYo4Kvd.findall('"SeasonsList"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		N5Vbkn2chPGfT3m97Bv1LHKI = PAztbuyYo4Kvd.findall('"EpisodesList"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if LKk0YdTN72XmnMuBbw:
		HRlygv7YwjzbSLt8fkEerq2 = PAztbuyYo4Kvd.findall('"og:image" content="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2[0]
		WWU7QJP2tyTRLIfDh0csxbkvX = LKk0YdTN72XmnMuBbw[0]
		items = PAztbuyYo4Kvd.findall('data-id="(.*?)".*?data-season="(.*?)".*?">(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for PsbTIOQmGgNEV0Dx3Lv45WCyJMat,JKQIrCFpL9,title in items:
			ZylHkumQ8zD0 = GWjBrpNhRsmt7eDba1yA4nukS+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Episodes.php?'+'season='+JKQIrCFpL9+'&post_id='+PsbTIOQmGgNEV0Dx3Lv45WCyJMat
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,433,HRlygv7YwjzbSLt8fkEerq2)
	elif N5Vbkn2chPGfT3m97Bv1LHKI:
		HRlygv7YwjzbSLt8fkEerq2 = SoNGUfhMDERLyHOz1qkVAj.getInfoLabel('ListItem.Thumb')
		WWU7QJP2tyTRLIfDh0csxbkvX = N5Vbkn2chPGfT3m97Bv1LHKI[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?</i>(.*?)<em>(.*?)</em>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title,JfNHOP2BK1Yxl7Rq4 in items:
			title = title+hSXlxL9iB05c+JfNHOP2BK1Yxl7Rq4
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,432,HRlygv7YwjzbSLt8fkEerq2)
	return
def lNBcUr8RCn(url):
	KteRnFMjHpBPqNf8 = url+'/watch/'
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYNOW-PLAY-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	ce9zAaVFswSq6lLr82DfQyotGW = []
	GWjBrpNhRsmt7eDba1yA4nukS = C2gnJ5tXFk9pAL(KteRnFMjHpBPqNf8,'url')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"container-servers"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		bJ4y9AcpNTXFIEqMSvjuLgH3 = PAztbuyYo4Kvd.findall('data-id="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if bJ4y9AcpNTXFIEqMSvjuLgH3:
			bJ4y9AcpNTXFIEqMSvjuLgH3 = bJ4y9AcpNTXFIEqMSvjuLgH3[0]
			items = PAztbuyYo4Kvd.findall('data-server="(.*?)".*?<span>(.*?)</span>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for DQ7XgFltujVL,title in items:
				ZylHkumQ8zD0 = GWjBrpNhRsmt7eDba1yA4nukS+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Server.php?server='+DQ7XgFltujVL+'&post_id='+bJ4y9AcpNTXFIEqMSvjuLgH3+'?named='+title+'__watch'
				ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	FvLOoRgbrhy = PAztbuyYo4Kvd.findall('"container-iframe"><iframe src="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if FvLOoRgbrhy:
		FvLOoRgbrhy = FvLOoRgbrhy[0].replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2)
		title = C2gnJ5tXFk9pAL(FvLOoRgbrhy,'name')
		ZylHkumQ8zD0 = FvLOoRgbrhy+'?named='+title+'__embed'
		ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"container-download"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?span>(.*?)<.*?em>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title,OzWg1yEQG8wtvJ4x2ic9aKedFAPD in items:
			ZylHkumQ8zD0 = ZylHkumQ8zD0.replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2)
			if OzWg1yEQG8wtvJ4x2ic9aKedFAPD!=nA5dhMRg6ENzsB0l1GwvH7aIr2: OzWg1yEQG8wtvJ4x2ic9aKedFAPD = '____'+OzWg1yEQG8wtvJ4x2ic9aKedFAPD
			ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named='+title+'__download'+OzWg1yEQG8wtvJ4x2ic9aKedFAPD
			ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(ce9zAaVFswSq6lLr82DfQyotGW,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	search = search.replace(hSXlxL9iB05c,'%20')
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/?s='+search
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
	return
def iBOFgUs6eTkIQyxKbqM(url):
	url = url.split('/smartemadfilter?')[0]
	GWjBrpNhRsmt7eDba1yA4nukS = C2gnJ5tXFk9pAL(url,'url')
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',GWjBrpNhRsmt7eDba1yA4nukS,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYNOW-GET_FILTERS_BLOCKS-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('("dropdown-button".*?)"SearchingMaster"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	AAkSjd9agcy = PAztbuyYo4Kvd.findall('"dropdown-button".*?<em>(.*?)</em>(.*?data-tax="(.*?)".*?</div>)',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	return AAkSjd9agcy
def vPOwqQ5zYHc10DVaSmU2ysG8k4t(WWU7QJP2tyTRLIfDh0csxbkvX):
	items = PAztbuyYo4Kvd.findall('data-term="(\d+)" data-name="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	return items
def GuvD6Ob3l0(url):
	YS4MDi1r3wOKFhTHjeEBIsag = url.split('/smartemadfilter?')[0]
	xTNCXea9SPBRb = C2gnJ5tXFk9pAL(url,'url')
	url = url.replace(YS4MDi1r3wOKFhTHjeEBIsag,xTNCXea9SPBRb)
	url = url.replace('/smartemadfilter?','/explore/?')
	return url
def dsYUEZWPIVB3vy0pjJ2zDO4fLr8icn(QA6C8r4lEdhemfJPRc,url):
	OQmDdTI7hU4Lv3BfexPVKgRF8YN = EdpkojMzLm6b3ZSVcXwi0CPRIH(QA6C8r4lEdhemfJPRc,'modified_filters')
	w7Ol6FnokgJDSsIt = url+'/smartemadfilter?'+OQmDdTI7hU4Lv3BfexPVKgRF8YN
	w7Ol6FnokgJDSsIt = GuvD6Ob3l0(w7Ol6FnokgJDSsIt)
	return w7Ol6FnokgJDSsIt
J8bDm67uSQ53EOUiltdTPRhcgNKY = ['category','country','genre','release-year']
F45fPJwzqEWNISAml = ['quality','release-year','genre','category','language','country']
def NNihMcqGKQEvLz6l(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==nA5dhMRg6ENzsB0l1GwvH7aIr2: vvXcyZhkfV,guikd57yRSCMsNmlUqFHWAYL = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	else: vvXcyZhkfV,guikd57yRSCMsNmlUqFHWAYL = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if J8bDm67uSQ53EOUiltdTPRhcgNKY[0]+'=' not in vvXcyZhkfV: kvfOU7Tpz958QBqnIlaAePLys = J8bDm67uSQ53EOUiltdTPRhcgNKY[0]
		for q3kZpRe28O0s1NaCXQ9SMuGKin in range(len(J8bDm67uSQ53EOUiltdTPRhcgNKY[0:-1])):
			if J8bDm67uSQ53EOUiltdTPRhcgNKY[q3kZpRe28O0s1NaCXQ9SMuGKin]+'=' in vvXcyZhkfV: kvfOU7Tpz958QBqnIlaAePLys = J8bDm67uSQ53EOUiltdTPRhcgNKY[q3kZpRe28O0s1NaCXQ9SMuGKin+1]
		FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+kvfOU7Tpz958QBqnIlaAePLys+'=0'
		QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+kvfOU7Tpz958QBqnIlaAePLys+'=0'
		TB6HLPpacsK8f034jvYx7SNgFd = FqCItdu32L9hNwcEXWoges4R68KS.strip('&')+'___'+QA6C8r4lEdhemfJPRc.strip('&')
		OQmDdTI7hU4Lv3BfexPVKgRF8YN = EdpkojMzLm6b3ZSVcXwi0CPRIH(guikd57yRSCMsNmlUqFHWAYL,'modified_filters')
		KteRnFMjHpBPqNf8 = url+'/smartemadfilter?'+OQmDdTI7hU4Lv3BfexPVKgRF8YN
	elif type=='ALL_ITEMS_FILTER':
		iEa2qGQctFxX = EdpkojMzLm6b3ZSVcXwi0CPRIH(vvXcyZhkfV,'modified_values')
		iEa2qGQctFxX = pvOytL0nF7JY6flXTxAcHbQeNahu3(iEa2qGQctFxX)
		if guikd57yRSCMsNmlUqFHWAYL!=nA5dhMRg6ENzsB0l1GwvH7aIr2: guikd57yRSCMsNmlUqFHWAYL = EdpkojMzLm6b3ZSVcXwi0CPRIH(guikd57yRSCMsNmlUqFHWAYL,'modified_filters')
		if guikd57yRSCMsNmlUqFHWAYL==nA5dhMRg6ENzsB0l1GwvH7aIr2: KteRnFMjHpBPqNf8 = url
		else: KteRnFMjHpBPqNf8 = url+'/smartemadfilter?'+guikd57yRSCMsNmlUqFHWAYL
		KteRnFMjHpBPqNf8 = GuvD6Ob3l0(KteRnFMjHpBPqNf8)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'أظهار قائمة الفيديو التي تم اختيارها ',KteRnFMjHpBPqNf8,431)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+' [[   '+iEa2qGQctFxX+'   ]]',KteRnFMjHpBPqNf8,431)
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	AAkSjd9agcy = iBOFgUs6eTkIQyxKbqM(url)
	dict = {}
	for name,WWU7QJP2tyTRLIfDh0csxbkvX,xWwIXcK0L61EBgtn7smr in AAkSjd9agcy:
		name = name.replace('--',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		items = vPOwqQ5zYHc10DVaSmU2ysG8k4t(WWU7QJP2tyTRLIfDh0csxbkvX)
		if '=' not in KteRnFMjHpBPqNf8: KteRnFMjHpBPqNf8 = url
		if type=='SPECIFIED_FILTER':
			if kvfOU7Tpz958QBqnIlaAePLys!=xWwIXcK0L61EBgtn7smr: continue
			elif len(items)<2:
				if xWwIXcK0L61EBgtn7smr==J8bDm67uSQ53EOUiltdTPRhcgNKY[-1]:
					url = GuvD6Ob3l0(url)
					LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
				else: NNihMcqGKQEvLz6l(KteRnFMjHpBPqNf8,'SPECIFIED_FILTER___'+TB6HLPpacsK8f034jvYx7SNgFd)
				return
			else:
				KteRnFMjHpBPqNf8 = GuvD6Ob3l0(KteRnFMjHpBPqNf8)
				if xWwIXcK0L61EBgtn7smr==J8bDm67uSQ53EOUiltdTPRhcgNKY[-1]: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع ',KteRnFMjHpBPqNf8,431)
				else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع ',KteRnFMjHpBPqNf8,435,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,TB6HLPpacsK8f034jvYx7SNgFd)
		elif type=='ALL_ITEMS_FILTER':
			FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+xWwIXcK0L61EBgtn7smr+'=0'
			QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+xWwIXcK0L61EBgtn7smr+'=0'
			TB6HLPpacsK8f034jvYx7SNgFd = FqCItdu32L9hNwcEXWoges4R68KS+'___'+QA6C8r4lEdhemfJPRc
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع :'+name,KteRnFMjHpBPqNf8,434,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,TB6HLPpacsK8f034jvYx7SNgFd)
		dict[xWwIXcK0L61EBgtn7smr] = {}
		for value,DOT0LXwgoHYkFBC4MbxN53 in items:
			if value=='196533': DOT0LXwgoHYkFBC4MbxN53 = 'أفلام نيتفلكس'
			elif value=='196531': DOT0LXwgoHYkFBC4MbxN53 = 'مسلسلات نيتفلكس'
			if DOT0LXwgoHYkFBC4MbxN53 in SAsGubf1jW2Q3p: continue
			dict[xWwIXcK0L61EBgtn7smr][value] = DOT0LXwgoHYkFBC4MbxN53
			FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+xWwIXcK0L61EBgtn7smr+'='+DOT0LXwgoHYkFBC4MbxN53
			QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+xWwIXcK0L61EBgtn7smr+'='+value
			b97AdvPkWGEBe3ayj1Jhmcq2LVxr = FqCItdu32L9hNwcEXWoges4R68KS+'___'+QA6C8r4lEdhemfJPRc
			title = DOT0LXwgoHYkFBC4MbxN53+' :'#+dict[xWwIXcK0L61EBgtn7smr]['0']
			title = DOT0LXwgoHYkFBC4MbxN53+' :'+name
			if type=='ALL_ITEMS_FILTER': TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,434,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,b97AdvPkWGEBe3ayj1Jhmcq2LVxr)
			elif type=='SPECIFIED_FILTER' and J8bDm67uSQ53EOUiltdTPRhcgNKY[-2]+'=' in vvXcyZhkfV:
				w7Ol6FnokgJDSsIt = dsYUEZWPIVB3vy0pjJ2zDO4fLr8icn(QA6C8r4lEdhemfJPRc,url)
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,w7Ol6FnokgJDSsIt,431)
			else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,435,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,b97AdvPkWGEBe3ayj1Jhmcq2LVxr)
	return
def EdpkojMzLm6b3ZSVcXwi0CPRIH(tgsLX2uACmFhVznejRy6O,mode):
	tgsLX2uACmFhVznejRy6O = tgsLX2uACmFhVznejRy6O.replace('=&','=0&')
	tgsLX2uACmFhVznejRy6O = tgsLX2uACmFhVznejRy6O.strip('&')
	bpoRYqt38j = {}
	if '=' in tgsLX2uACmFhVznejRy6O:
		items = tgsLX2uACmFhVznejRy6O.split('&')
		for CQtNwXGVAJ2y5nBY in items:
			eehzynNs85aTHrgCUmFc3DBO12,value = CQtNwXGVAJ2y5nBY.split('=')
			bpoRYqt38j[eehzynNs85aTHrgCUmFc3DBO12] = value
	H5ROYNwvQFkBiVElThr = nA5dhMRg6ENzsB0l1GwvH7aIr2
	for key in F45fPJwzqEWNISAml:
		if key in list(bpoRYqt38j.keys()): value = bpoRYqt38j[key]
		else: value = '0'
		if '%' not in value: value = kGE6zoKSan54W(value)
		if mode=='modified_values' and value!='0': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+' + '+value
		elif mode=='modified_filters' and value!='0': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+'&'+key+'='+value
		elif mode=='all_filters': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+'&'+key+'='+value
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.strip(' + ')
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.strip('&')
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.replace('=0','=')
	return H5ROYNwvQFkBiVElThr
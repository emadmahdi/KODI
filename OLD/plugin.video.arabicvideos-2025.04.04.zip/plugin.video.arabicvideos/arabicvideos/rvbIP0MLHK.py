# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'VIDEONSAEM'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_VNS_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
SAsGubf1jW2Q3p = ['الصفحة الرئيسية','Sign in','تسجيل','افلام للكبار فقط','Show more','قصة عشق','عروض المصارعة الحرة مترجم']
headers = {'Referer':GiqvpBF9xLEdHDr37byJSngeCQ}
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==1030: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==1031: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,text)
	elif mode==1032: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==1033: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = Uz7y8Vt3frjd6ZKHwcgsFBv05apxNC(url,text)
	elif mode==1034: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = oWcvptkU2JObI0(url)
	elif mode==1039: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'VIDEONSAEM-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,1039,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('''["']navslide-wrap["'](.*?)</ul>''',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?</i>(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			if title in SAsGubf1jW2Q3p: continue
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,1034)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('/category.php">(.*?)"navslide-divider"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('''["']dropdown-menu["'](.*?)</ul>''',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for YERWNbgAThV2uBr5taO8zcd in zz3eHskxE6lAyDR5cNj1ug: WWU7QJP2tyTRLIfDh0csxbkvX = WWU7QJP2tyTRLIfDh0csxbkvX.replace(YERWNbgAThV2uBr5taO8zcd,nA5dhMRg6ENzsB0l1GwvH7aIr2)
	items = PAztbuyYo4Kvd.findall('href="(.*?)".*?>(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title in items:
		if not title: continue
		if title in SAsGubf1jW2Q3p: continue
		if title=='جديد الأفلام': title = 'المضاف حديثا'
		TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,1034)
	return
def oWcvptkU2JObI0(url):
	kkgmyjLhK73DzNYCq8,hn2rCExmu5pgejyYOT = [],[]
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'VIDEONSAEM-SUBMENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	LKk0YdTN72XmnMuBbw = PAztbuyYo4Kvd.findall('"caret"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if LKk0YdTN72XmnMuBbw and '.php' in str(LKk0YdTN72XmnMuBbw):
		WWU7QJP2tyTRLIfDh0csxbkvX = LKk0YdTN72XmnMuBbw[0]
		WWU7QJP2tyTRLIfDh0csxbkvX = WWU7QJP2tyTRLIfDh0csxbkvX.replace('"presentation"','</ul>')
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if not zz3eHskxE6lAyDR5cNj1ug: zz3eHskxE6lAyDR5cNj1ug = [(nA5dhMRg6ENzsB0l1GwvH7aIr2,WWU7QJP2tyTRLIfDh0csxbkvX)]
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' فرز أو فلتر أو ترتيب '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
		for eMGqlWRdtC8EK2nFz,WWU7QJP2tyTRLIfDh0csxbkvX in zz3eHskxE6lAyDR5cNj1ug:
			kkgmyjLhK73DzNYCq8 = PAztbuyYo4Kvd.findall('href="(.*?)".*?>(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			if eMGqlWRdtC8EK2nFz: eMGqlWRdtC8EK2nFz = eMGqlWRdtC8EK2nFz+': '
			for ZylHkumQ8zD0,title in kkgmyjLhK73DzNYCq8:
				title = eMGqlWRdtC8EK2nFz+title
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,1031)
	N5Vbkn2chPGfT3m97Bv1LHKI = PAztbuyYo4Kvd.findall('"pm-category-subcats"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if N5Vbkn2chPGfT3m97Bv1LHKI:
		WWU7QJP2tyTRLIfDh0csxbkvX = N5Vbkn2chPGfT3m97Bv1LHKI[0]
		hn2rCExmu5pgejyYOT = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if 1 or len(hn2rCExmu5pgejyYOT)<30:
			if kkgmyjLhK73DzNYCq8: TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
			for ZylHkumQ8zD0,title in hn2rCExmu5pgejyYOT:
				if title in SAsGubf1jW2Q3p: continue
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,1031)
	if not LKk0YdTN72XmnMuBbw and not N5Vbkn2chPGfT3m97Bv1LHKI: LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
	return
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,YsdSH10ta6wvi4nMRIO9=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if YsdSH10ta6wvi4nMRIO9=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		LevQwm0pbqP1 = headers.copy()
		LevQwm0pbqP1['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'POST',url,data,LevQwm0pbqP1,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'VIDEONSAEM-TITLES-1st')
	else:
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'VIDEONSAEM-TITLES-2nd')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	WWU7QJP2tyTRLIfDh0csxbkvX,items = nA5dhMRg6ENzsB0l1GwvH7aIr2,[]
	GWjBrpNhRsmt7eDba1yA4nukS = C2gnJ5tXFk9pAL(url,'url')
	if YsdSH10ta6wvi4nMRIO9=='ajax-search':
		WWU7QJP2tyTRLIfDh0csxbkvX = kl2ZWdy8rXcHT
		hn2rCExmu5pgejyYOT = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in hn2rCExmu5pgejyYOT: items.append((nA5dhMRg6ENzsB0l1GwvH7aIr2,ZylHkumQ8zD0,title))
	elif YsdSH10ta6wvi4nMRIO9=='featured':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"pm-carousel_featured"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug: WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	elif YsdSH10ta6wvi4nMRIO9=='new_episodes':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"row pm-ul-browse-videos(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug: WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	elif YsdSH10ta6wvi4nMRIO9=='new_movies':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"row pm-ul-browse-videos(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if len(zz3eHskxE6lAyDR5cNj1ug)>1: WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[1]
	elif YsdSH10ta6wvi4nMRIO9=='featured_series':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug: WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	else:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"pm-grid"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug: WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	if WWU7QJP2tyTRLIfDh0csxbkvX and not items: items = PAztbuyYo4Kvd.findall('"thumbnail".*?<a href="(.*?)" title="(.*?)".*?data-echo="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	if not items: return
	u0UiTmzYN6I3Q9eCZVoB = []
	hdocEkRK0Q = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for ZylHkumQ8zD0,title,HRlygv7YwjzbSLt8fkEerq2 in items:
		HRlygv7YwjzbSLt8fkEerq2 += '|Referer='+GiqvpBF9xLEdHDr37byJSngeCQ
		if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = GWjBrpNhRsmt7eDba1yA4nukS+'/'+ZylHkumQ8zD0.strip('/')
		title = HH8SJuswDBPtniebmkXIr(title)
		JfNHOP2BK1Yxl7Rq4 = PAztbuyYo4Kvd.findall('(.*?) (الحلقة|حلقة).\d+',title,PAztbuyYo4Kvd.DOTALL)
		if YsdSH10ta6wvi4nMRIO9=='episodes' or any(value in title for value in hdocEkRK0Q):
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,1032,HRlygv7YwjzbSLt8fkEerq2)
		elif YsdSH10ta6wvi4nMRIO9=='new_episodes':
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,1032,HRlygv7YwjzbSLt8fkEerq2)
		elif JfNHOP2BK1Yxl7Rq4:
			title = '_MOD_' + JfNHOP2BK1Yxl7Rq4[0][0]
			if title not in u0UiTmzYN6I3Q9eCZVoB:
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,1033,HRlygv7YwjzbSLt8fkEerq2)
				u0UiTmzYN6I3Q9eCZVoB.append(title)
		else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,1033,HRlygv7YwjzbSLt8fkEerq2)
	if 1:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"pagination(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?>(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,title in items:
				if ZylHkumQ8zD0=='#': continue
				if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = GWjBrpNhRsmt7eDba1yA4nukS+'/'+ZylHkumQ8zD0.strip('/')
				title = HH8SJuswDBPtniebmkXIr(title)
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+title,ZylHkumQ8zD0,1031,'','',YsdSH10ta6wvi4nMRIO9)
	return
def Uz7y8Vt3frjd6ZKHwcgsFBv05apxNC(url,Q9fbtnwCKAN5syS8DPvmX62gHE):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'VIDEONSAEM-EPISODES_SEASONS-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="eplist"(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		GGr9WlIhv1BKDJjTZFNty4R3k0dCOA = PAztbuyYo4Kvd.findall('href="(.*?)" title="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in GGr9WlIhv1BKDJjTZFNty4R3k0dCOA:
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,872)
	else:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('<dt>(.*?)<dt>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			ZylHkumQ8zD0 = PAztbuyYo4Kvd.findall('href="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			if ZylHkumQ8zD0:
				LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(ZylHkumQ8zD0[-1],'episodes')
	return
def lNBcUr8RCn(url):
	HtT6mBGwMaq1o0rybzZ4,xD9aheBXINOKbECng34JrRl = [],[]
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'VIDEONSAEM-PLAY-2nd')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	if 'hash=' in kl2ZWdy8rXcHT:
		fvO9ALlsjT8qzIRi5MtPE01mQSJg = PAztbuyYo4Kvd.findall('hash=(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		fvO9ALlsjT8qzIRi5MtPE01mQSJg = list(set(fvO9ALlsjT8qzIRi5MtPE01mQSJg))
		for PsbTIOQmGgNEV0Dx3Lv45WCyJMat in fvO9ALlsjT8qzIRi5MtPE01mQSJg:
			kaX7315BPMRtmpWd = []
			yoGhEciOC1 = PsbTIOQmGgNEV0Dx3Lv45WCyJMat.split('__')
			for I4cgT6JwrH01 in yoGhEciOC1:
				try:
					I4cgT6JwrH01 = Ic92Lb6lnzM5KJsx4Y3UGa70imZo.b64decode(I4cgT6JwrH01+'=')
					if BsLJ7p5Av2Vm0SQeCO1o: I4cgT6JwrH01 = I4cgT6JwrH01.decode(YWEQ3Cf8RevpD0m7NjF1)
					kaX7315BPMRtmpWd.append(I4cgT6JwrH01)
				except: pass
			HRpMVv1x5ol9gbsnQquj = '>'.join(kaX7315BPMRtmpWd)
			HRpMVv1x5ol9gbsnQquj = HRpMVv1x5ol9gbsnQquj.splitlines()
			for ZylHkumQ8zD0 in HRpMVv1x5ol9gbsnQquj:
				if ' => ' in ZylHkumQ8zD0:
					title,ZylHkumQ8zD0 = ZylHkumQ8zD0.split(' => ')
					ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named='+title+'__watch'
					HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0)
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(HtT6mBGwMaq1o0rybzZ4,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	search = search.replace(hSXlxL9iB05c,'+')
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/search.php?keywords='+search
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,'search')
	return
# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'CIMAABDO'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_ABD_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
SAsGubf1jW2Q3p = ['الرئيسية','افلام للكبار فقط +18']
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==550: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==551: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,text)
	elif mode==552: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==553: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LLabVp7hzj28CE0f1udx(url)
	elif mode==559: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',GiqvpBF9xLEdHDr37byJSngeCQ+'/home',nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMAABDO-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	GWjBrpNhRsmt7eDba1yA4nukS = C2gnJ5tXFk9pAL(GiqvpBF9xLEdHDr37byJSngeCQ,'url')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,559,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'اخترنا لك',GWjBrpNhRsmt7eDba1yA4nukS+'/home',551,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'featured')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('main-content(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('data-name="(.*?)".*?</i>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for nCDeSQzlyBIF,title in items:
		ZylHkumQ8zD0 = GWjBrpNhRsmt7eDba1yA4nukS+'/ajax/getItem?item='+nCDeSQzlyBIF+'&Ajax=1'
		TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,551)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"nav-main"(.*?)</nav>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title in items:
		if ZylHkumQ8zD0=='#': continue
		if title in SAsGubf1jW2Q3p: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' in title: TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,551)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	for ZylHkumQ8zD0,title in items:
		if ZylHkumQ8zD0=='#': continue
		if title in SAsGubf1jW2Q3p: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' not in title: TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,551)
	return
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,nCDeSQzlyBIF=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		KteRnFMjHpBPqNf8,rA4ZGoQyIHlneVfzNukWd = ss2VIkClmtevKqPUuSx9DGpX(url)
		LevQwm0pbqP1 = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'POST',KteRnFMjHpBPqNf8,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMAABDO-TITLES-1st')
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
		zz3eHskxE6lAyDR5cNj1ug = [kl2ZWdy8rXcHT]
	else:
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMAABDO-TITLES-2nd')
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
		if nCDeSQzlyBIF=='featured':
			zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"container"(.*?)"container"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		elif '"section-post mb-10"' in kl2ZWdy8rXcHT:
			zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"section-post mb-10"(.*?)"container"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		else:
			zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('<article(.*?)"pagination"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if not zz3eHskxE6lAyDR5cNj1ug: return
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	if not items:
		items = PAztbuyYo4Kvd.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if not items: items = PAztbuyYo4Kvd.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	u0UiTmzYN6I3Q9eCZVoB = []
	hdocEkRK0Q = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for ZylHkumQ8zD0,title,HRlygv7YwjzbSLt8fkEerq2 in items:
		ZylHkumQ8zD0 = pvOytL0nF7JY6flXTxAcHbQeNahu3(ZylHkumQ8zD0).strip('/')
		JfNHOP2BK1Yxl7Rq4 = PAztbuyYo4Kvd.findall('(.*?) الحلقة \d+',title,PAztbuyYo4Kvd.DOTALL)
		if 'سلاسل' not in url and any(value in title for value in hdocEkRK0Q):
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,552,HRlygv7YwjzbSLt8fkEerq2)
		elif JfNHOP2BK1Yxl7Rq4 and 'الحلقة' in title:
			title = '_MOD_' + JfNHOP2BK1Yxl7Rq4[0]
			if title not in u0UiTmzYN6I3Q9eCZVoB:
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,553,HRlygv7YwjzbSLt8fkEerq2)
				u0UiTmzYN6I3Q9eCZVoB.append(title)
		elif '/movies/' in ZylHkumQ8zD0:
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,551,HRlygv7YwjzbSLt8fkEerq2)
		else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,553,HRlygv7YwjzbSLt8fkEerq2)
	if nCDeSQzlyBIF==nA5dhMRg6ENzsB0l1GwvH7aIr2:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"pagination"(.*?)<footer',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,title in items:
				if ZylHkumQ8zD0=="": continue
				if title!=nA5dhMRg6ENzsB0l1GwvH7aIr2: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+title,ZylHkumQ8zD0,551)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'هناك المزيد',url,551)
	return
def LLabVp7hzj28CE0f1udx(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMAABDO-EPISODES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	LKk0YdTN72XmnMuBbw = PAztbuyYo4Kvd.findall('"getSeasonsBySeries(.*?)"container"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	N5Vbkn2chPGfT3m97Bv1LHKI = PAztbuyYo4Kvd.findall('"list-episodes"(.*?)"container"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if LKk0YdTN72XmnMuBbw and '/series/' not in url:
		WWU7QJP2tyTRLIfDh0csxbkvX = LKk0YdTN72XmnMuBbw[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title,HRlygv7YwjzbSLt8fkEerq2 in items:
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,553,HRlygv7YwjzbSLt8fkEerq2)
	elif N5Vbkn2chPGfT3m97Bv1LHKI:
		HRlygv7YwjzbSLt8fkEerq2 = PAztbuyYo4Kvd.findall('"image" src="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2[0]
		WWU7QJP2tyTRLIfDh0csxbkvX = N5Vbkn2chPGfT3m97Bv1LHKI[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)" title="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,552,HRlygv7YwjzbSLt8fkEerq2)
	return
def lNBcUr8RCn(url):
	w7Ol6FnokgJDSsIt = url.replace('/movies/','/watch_movies/')
	w7Ol6FnokgJDSsIt = w7Ol6FnokgJDSsIt.replace('/episodes/','/watch_episodes/')
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',w7Ol6FnokgJDSsIt,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMAABDO-PLAY-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	GWjBrpNhRsmt7eDba1yA4nukS = C2gnJ5tXFk9pAL(w7Ol6FnokgJDSsIt,'url')
	HtT6mBGwMaq1o0rybzZ4 = []
	ZylHkumQ8zD0 = PAztbuyYo4Kvd.findall('''<iframe.*?src=["'](.*?)["']''',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if ZylHkumQ8zD0:
		ZylHkumQ8zD0 = ZylHkumQ8zD0[0]
		DQ7XgFltujVL = C2gnJ5tXFk9pAL(ZylHkumQ8zD0,'url')
		HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0+'?named='+DQ7XgFltujVL+'__embed')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"servers"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		FPAhgMwOp1YSLN = PAztbuyYo4Kvd.findall('postID = "(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		FPAhgMwOp1YSLN = FPAhgMwOp1YSLN[0]
		items = PAztbuyYo4Kvd.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if items:
			for DQ7XgFltujVL,title in items:
				title = title.replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c)
				ZylHkumQ8zD0 = GWjBrpNhRsmt7eDba1yA4nukS+'/ajax/getPlayer?server='+DQ7XgFltujVL+'&postID='+FPAhgMwOp1YSLN+'&Ajax=1'
				ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named='+title+'__watch'
				HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0)
		else:
			items = PAztbuyYo4Kvd.findall("getPlayerByName\('(.*?)','(.*?)'.*?\"server\">(.*?)</a>",WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			if items:
				DQ7XgFltujVL,YYjobMRxBnCt,title = items[0]
				ZylHkumQ8zD0 = GWjBrpNhRsmt7eDba1yA4nukS+'/ajax/getPlayerByName?server='+DQ7XgFltujVL+'&multipleServers='+YYjobMRxBnCt+'&postID='+FPAhgMwOp1YSLN+'&Ajax=1'
				KteRnFMjHpBPqNf8,rA4ZGoQyIHlneVfzNukWd = ss2VIkClmtevKqPUuSx9DGpX(ZylHkumQ8zD0)
				LevQwm0pbqP1 = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
				Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'POST',KteRnFMjHpBPqNf8,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMAABDO-PLAY-2nd')
				kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
				o5tUrNCbpVMPm6F = PAztbuyYo4Kvd.findall('''<iframe src=["'](.*?)["']''',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL|PAztbuyYo4Kvd.IGNORECASE)
				ww5oBKPZmc = o5tUrNCbpVMPm6F[0] if o5tUrNCbpVMPm6F else nA5dhMRg6ENzsB0l1GwvH7aIr2
				if '/iframe/' in ww5oBKPZmc:
					Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',ww5oBKPZmc,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMAABDO-PLAY-3rd')
					kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
					J6NHLBeUr874w = PAztbuyYo4Kvd.findall('version&quot;:&quot;(.*?)&',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
					J6NHLBeUr874w = J6NHLBeUr874w[0]
					LevQwm0pbqP1 = {}
					LevQwm0pbqP1['X-Inertia-Partial-Component'] = 'files/mirror/video'
					LevQwm0pbqP1['X-Inertia'] = 'true'
					LevQwm0pbqP1['X-Inertia-Partial-Data'] = 'streams'
					LevQwm0pbqP1['X-Inertia-Version'] = J6NHLBeUr874w
					Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',ww5oBKPZmc,nA5dhMRg6ENzsB0l1GwvH7aIr2,LevQwm0pbqP1,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMAABDO-PLAY-4th')
					kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
					ulfyLAzH0wg = BwGPDSQOlfUas2n3eIH0ycFRWZ('dict',kl2ZWdy8rXcHT)
					groups = ulfyLAzH0wg['props']['streams']['data']
					for group in groups:
						OzWg1yEQG8wtvJ4x2ic9aKedFAPD = group['label'].replace(' (source)',nA5dhMRg6ENzsB0l1GwvH7aIr2)
						bQ3zYXw7qVI094hC1tWPafNrnAeT = group['mirrors']
						for U5aXnL2hBoY8sg4EKJmRzNyC in bQ3zYXw7qVI094hC1tWPafNrnAeT:
							DQ7XgFltujVL = U5aXnL2hBoY8sg4EKJmRzNyC['driver']
							ZylHkumQ8zD0 = 'http:'+U5aXnL2hBoY8sg4EKJmRzNyC['link']+'?named='+DQ7XgFltujVL+'__watch____'+OzWg1yEQG8wtvJ4x2ic9aKedFAPD
							HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"downs"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)" title="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,name in items:
			ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named='+name+'__download'
			if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = 'http:'+ZylHkumQ8zD0
			HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0)
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(HtT6mBGwMaq1o0rybzZ4,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	search = search.replace(hSXlxL9iB05c,'-')
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/search/'+search+'.html'
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
	return
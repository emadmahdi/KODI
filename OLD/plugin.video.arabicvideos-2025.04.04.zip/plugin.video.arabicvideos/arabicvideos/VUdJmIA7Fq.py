# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'SHIAVOICE'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_SHV_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
headers = {'User-Agent':None}
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==310: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==311: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
	elif mode==312: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==313: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = E4y6ZQgipndlotWr25veaTXq(url)
	elif mode==314: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = CklyboIJDug75niLjhtmNU42fZs9ec(text)
	elif mode==319: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,319,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SHIAVOICE-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('id="menulinks"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	items = PAztbuyYo4Kvd.findall('<h5>(.*?)</h5>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL|PAztbuyYo4Kvd.IGNORECASE)
	for XXJAOcyjfEhSxC in range(len(items)):
		title = items[XXJAOcyjfEhSxC].strip(hSXlxL9iB05c)
		TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,GiqvpBF9xLEdHDr37byJSngeCQ,314,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,str(XXJAOcyjfEhSxC+1))
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مقاطع شهر',GiqvpBF9xLEdHDr37byJSngeCQ,314,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'0')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	items = PAztbuyYo4Kvd.findall('href="(.*?)".*?<B>(.*?)</B>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title in items:
		ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+ZylHkumQ8zD0
		TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,311)
	return kl2ZWdy8rXcHT
def CklyboIJDug75niLjhtmNU42fZs9ec(XXJAOcyjfEhSxC):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SHIAVOICE-LATEST-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	if XXJAOcyjfEhSxC=='0':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="tab-content"(.*?)</table>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,name,title in items:
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+ZylHkumQ8zD0
			title = title.strip(hSXlxL9iB05c)
			name = name.strip(hSXlxL9iB05c)
			title = title+' ('+name+')'
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,312)
	elif XXJAOcyjfEhSxC in ['1','2','3']:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('(<h5>.*?)<div class="col-lg',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		loubz7vYRNXxDahqsm5 = int(XXJAOcyjfEhSxC)-1
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[loubz7vYRNXxDahqsm5]
		if XXJAOcyjfEhSxC=='1': items = PAztbuyYo4Kvd.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		else: items = PAztbuyYo4Kvd.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title,name in items:
			HRlygv7YwjzbSLt8fkEerq2 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+HRlygv7YwjzbSLt8fkEerq2
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+ZylHkumQ8zD0
			title = title.strip(hSXlxL9iB05c)
			name = name.strip(hSXlxL9iB05c)
			title = title+' ('+name+')'
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,311,HRlygv7YwjzbSLt8fkEerq2)
	elif XXJAOcyjfEhSxC in ['4','5','6']:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('(<h5>.*?)</table>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		XXJAOcyjfEhSxC = int(XXJAOcyjfEhSxC)-4
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[XXJAOcyjfEhSxC]
		items = PAztbuyYo4Kvd.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for HRlygv7YwjzbSLt8fkEerq2,ZylHkumQ8zD0,CSziwD3bp1c9GWLakAB,title,gO2PcxfG7Yhd in items:
			HRlygv7YwjzbSLt8fkEerq2 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+HRlygv7YwjzbSLt8fkEerq2
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+ZylHkumQ8zD0
			title = title.strip(hSXlxL9iB05c)
			CSziwD3bp1c9GWLakAB = CSziwD3bp1c9GWLakAB.strip(hSXlxL9iB05c)
			gO2PcxfG7Yhd = gO2PcxfG7Yhd.strip(hSXlxL9iB05c)
			if CSziwD3bp1c9GWLakAB: name = CSziwD3bp1c9GWLakAB
			else: name = gO2PcxfG7Yhd
			title = title+' ('+name+')'
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,312,HRlygv7YwjzbSLt8fkEerq2)
	return
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SHIAVOICE-TITLES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('ibox-heading"(.*?)class="float-right',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	if 'catsum-mobile' in WWU7QJP2tyTRLIfDh0csxbkvX:
		items = PAztbuyYo4Kvd.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if items:
			for HRlygv7YwjzbSLt8fkEerq2,ZylHkumQ8zD0,title,count in items:
				HRlygv7YwjzbSLt8fkEerq2 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+HRlygv7YwjzbSLt8fkEerq2
				ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+ZylHkumQ8zD0
				count = count.replace(' الصوتية: ',':')
				title = title.strip(hSXlxL9iB05c)
				title = title+' ('+count+')'
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,311,HRlygv7YwjzbSLt8fkEerq2)
	else:
		items = PAztbuyYo4Kvd.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title,eemvTK6h45HbMJWsA1Ilwyi,yoaKx7FtIlvcD in items:
			if title==nA5dhMRg6ENzsB0l1GwvH7aIr2 or eemvTK6h45HbMJWsA1Ilwyi==nA5dhMRg6ENzsB0l1GwvH7aIr2: continue
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+ZylHkumQ8zD0
			title = title+' ('+yoaKx7FtIlvcD+')'
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,312)
	if not items: LLabVp7hzj28CE0f1udx(kl2ZWdy8rXcHT)
	return
def LLabVp7hzj28CE0f1udx(kl2ZWdy8rXcHT):
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="ibox-content"(.*?)class="pagination',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title,name,count,yoaKx7FtIlvcD in items:
		ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+ZylHkumQ8zD0
		title = title.strip(hSXlxL9iB05c)
		name = name.strip(hSXlxL9iB05c)
		title = title+' ('+name+')'
		TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,312,nA5dhMRg6ENzsB0l1GwvH7aIr2,yoaKx7FtIlvcD)
	return
def E4y6ZQgipndlotWr25veaTXq(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SHIAVOICE-SEARCH_ITEMS-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="ibox-content p-1"(.*?)class="ibox-content"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if not zz3eHskxE6lAyDR5cNj1ug:
		LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
		return
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('href="(.*?)".*?<strong>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title in items:
		ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+ZylHkumQ8zD0
		title = title.strip(hSXlxL9iB05c)
		if '/play-' in ZylHkumQ8zD0: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,312)
		else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,311)
	return
def lNBcUr8RCn(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SHIAVOICE-PLAY-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	ZylHkumQ8zD0 = PAztbuyYo4Kvd.findall('<audio.*?src="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if not ZylHkumQ8zD0: ZylHkumQ8zD0 = PAztbuyYo4Kvd.findall('<video.*?src="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0[0]
	ocUnzjShqIO35vZi8bk64pVKMCTBaw(ZylHkumQ8zD0,wgj0rX5tbcxPulhmny,'video')
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	search = search.replace(hSXlxL9iB05c,'+')
	g0IDsxBEzkGOuQe4VL9Mw2NPa = ['&t=a','&t=c','&t=s']
	if showDialogs:
		r6hgEokcpyR = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		iP7AUR41exzlKyZIf9Mt3u = ccAMwn7hflDev8Kd3aqP('موقع صوت الشيعة - أختر البحث', r6hgEokcpyR)
		if iP7AUR41exzlKyZIf9Mt3u == -1: return
	elif '_SHIAVOICE-PERSONS_' in m0YJ3feqUjD7: iP7AUR41exzlKyZIf9Mt3u = 0
	elif '_SHIAVOICE-ALBUMS_' in m0YJ3feqUjD7: iP7AUR41exzlKyZIf9Mt3u = 1
	elif '_SHIAVOICE-AUDIOS_' in m0YJ3feqUjD7: iP7AUR41exzlKyZIf9Mt3u = 2
	else: return
	type = g0IDsxBEzkGOuQe4VL9Mw2NPa[iP7AUR41exzlKyZIf9Mt3u]
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/search.php?q='+search+type
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SHIAVOICE-SEARCH-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="ibox-content"(.*?)class="ibox-content"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		if iP7AUR41exzlKyZIf9Mt3u in [0,1]:
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title,name in items:
				title = title.strip(hSXlxL9iB05c)
				name = name.strip(hSXlxL9iB05c)
				title = title+' ('+name+')'
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,313,HRlygv7YwjzbSLt8fkEerq2)
		elif iP7AUR41exzlKyZIf9Mt3u==2:
			items = PAztbuyYo4Kvd.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,title,name in items:
				title = title.strip(hSXlxL9iB05c)
				name = name.strip(hSXlxL9iB05c)
				title = title+' ('+name+')'
				TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,312)
	return
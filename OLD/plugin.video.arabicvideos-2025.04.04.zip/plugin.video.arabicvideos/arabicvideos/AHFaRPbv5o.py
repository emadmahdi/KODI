# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'SHAHID4U'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_SH4_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
headers = {'User-Agent':oOb8ZS417GwudNKHU6y(True)}
SAsGubf1jW2Q3p = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==110: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==111: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,text)
	elif mode==112: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==113: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LLabVp7hzj28CE0f1udx(url,True)
	elif mode==114: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = NNihMcqGKQEvLz6l(url,'FULL_FILTER___'+text)
	elif mode==115: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = NNihMcqGKQEvLz6l(url,'DEFINED_FILTER___'+text)
	elif mode==116: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LLabVp7hzj28CE0f1udx(url,False)
	elif mode==119: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SHAHID4U-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	GWjBrpNhRsmt7eDba1yA4nukS = C2gnJ5tXFk9pAL(Y3SmVGbfNvEeakMBr.url,'url')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,119,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فلتر محدد',GWjBrpNhRsmt7eDba1yA4nukS,115)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فلتر كامل',GWjBrpNhRsmt7eDba1yA4nukS,114)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'المميزة',GWjBrpNhRsmt7eDba1yA4nukS,111,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'featured')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('simple-filter(.*?)adv-filter',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if not zz3eHskxE6lAyDR5cNj1ug:
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for filter,HRlygv7YwjzbSLt8fkEerq2,title in items:
			url = GWjBrpNhRsmt7eDba1yA4nukS+filter
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,111,HRlygv7YwjzbSLt8fkEerq2,nA5dhMRg6ENzsB0l1GwvH7aIr2,filter)
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="dropdown"(.*?)<script>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			title = title.replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(sSBzjZdcbQraNx,nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c)
			if title in SAsGubf1jW2Q3p: continue
			if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = GWjBrpNhRsmt7eDba1yA4nukS+ZylHkumQ8zD0
			if 'netflix' in ZylHkumQ8zD0: title = 'نيتفلكس'
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,111)
	return kl2ZWdy8rXcHT
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,nCDeSQzlyBIF=nA5dhMRg6ENzsB0l1GwvH7aIr2,Y3SmVGbfNvEeakMBr=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if not Y3SmVGbfNvEeakMBr: Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SHAHID4U-TITLES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug,items,u0UiTmzYN6I3Q9eCZVoB = [],[],[]
	if nCDeSQzlyBIF=='featured': zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('glide__slides(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	else: zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('shows-container(.*?)pagination',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if not zz3eHskxE6lAyDR5cNj1ug: return
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	if not items: items = PAztbuyYo4Kvd.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)</h4>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	hdocEkRK0Q = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
		if 'WWE' in title: continue
		if 'javascript' in ZylHkumQ8zD0: continue
		ZylHkumQ8zD0 = pvOytL0nF7JY6flXTxAcHbQeNahu3(ZylHkumQ8zD0).strip('/')
		title = HH8SJuswDBPtniebmkXIr(title)
		title = title.strip(hSXlxL9iB05c)
		JfNHOP2BK1Yxl7Rq4 = PAztbuyYo4Kvd.findall('(.*?) الحلقة \d+',title,PAztbuyYo4Kvd.DOTALL)
		if '/film/' in ZylHkumQ8zD0 or 'فيلم' in ZylHkumQ8zD0 or any(value in title for value in hdocEkRK0Q):
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,112,HRlygv7YwjzbSLt8fkEerq2)
		elif JfNHOP2BK1Yxl7Rq4 and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + JfNHOP2BK1Yxl7Rq4[0]
			if title not in u0UiTmzYN6I3Q9eCZVoB:
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,113,HRlygv7YwjzbSLt8fkEerq2)
				u0UiTmzYN6I3Q9eCZVoB.append(title)
		elif '/actor/' in ZylHkumQ8zD0:
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,111,HRlygv7YwjzbSLt8fkEerq2)
		elif '/series/' in ZylHkumQ8zD0 and '/list' not in url:
			ZylHkumQ8zD0 = ZylHkumQ8zD0+'/list'
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,111,HRlygv7YwjzbSLt8fkEerq2)
		elif '/list' in url and 'حلقة' in title:
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,112,HRlygv7YwjzbSLt8fkEerq2)
		else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,113,HRlygv7YwjzbSLt8fkEerq2)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"pagination"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		if nCDeSQzlyBIF!='search': items = PAztbuyYo4Kvd.findall('(updateQuery).*?>(.+?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		else: items = PAztbuyYo4Kvd.findall('<li>.*?href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if 'page=' in url: url = url.split('page=',1)[0][:-1]
		for ZylHkumQ8zD0,title in items:
			title = title.replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(sSBzjZdcbQraNx,nA5dhMRg6ENzsB0l1GwvH7aIr2)
			title = title.strip(hSXlxL9iB05c)
			if nCDeSQzlyBIF!='search':
				if '?' in url: ZylHkumQ8zD0 = url+'&page='+title
				else: ZylHkumQ8zD0 = url+'?page='+title
			title = HH8SJuswDBPtniebmkXIr(title)
			if title: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+title,ZylHkumQ8zD0,111,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nCDeSQzlyBIF)
	return
def LLabVp7hzj28CE0f1udx(url,wz3GDAtJpVxEUIfMLYPa7s8BQjeu):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SHAHID4U-EPISODES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('items d-flex(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if len(zz3eHskxE6lAyDR5cNj1ug)>1:
		if '/season/' in zz3eHskxE6lAyDR5cNj1ug[0]: wWeVHSMqxGR,GGr9WlIhv1BKDJjTZFNty4R3k0dCOA = zz3eHskxE6lAyDR5cNj1ug[0],zz3eHskxE6lAyDR5cNj1ug[1]
		else: wWeVHSMqxGR,GGr9WlIhv1BKDJjTZFNty4R3k0dCOA = zz3eHskxE6lAyDR5cNj1ug[1],zz3eHskxE6lAyDR5cNj1ug[0]
	else: wWeVHSMqxGR,GGr9WlIhv1BKDJjTZFNty4R3k0dCOA = zz3eHskxE6lAyDR5cNj1ug[0],zz3eHskxE6lAyDR5cNj1ug[0]
	for hsqrMEVB70i2ZnzPHlGYD1oy in range(2):
		if wz3GDAtJpVxEUIfMLYPa7s8BQjeu: mode,type,WWU7QJP2tyTRLIfDh0csxbkvX = 116,'folder',wWeVHSMqxGR
		else: mode,type,WWU7QJP2tyTRLIfDh0csxbkvX = 112,'video',GGr9WlIhv1BKDJjTZFNty4R3k0dCOA
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if wz3GDAtJpVxEUIfMLYPa7s8BQjeu and len(items)<2:
			wz3GDAtJpVxEUIfMLYPa7s8BQjeu = False
			continue
		for ZylHkumQ8zD0,lnFIuANWwQ,g7qwMTAPoVpIyQUaDeNOnhvs in items:
			title = lnFIuANWwQ+hSXlxL9iB05c+g7qwMTAPoVpIyQUaDeNOnhvs
			TBt8bUDo9WhL(type,DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,mode)
		break
	if not items and '/episodes' in kl2ZWdy8rXcHT:
		uz3TGiOaQZdMA8x = PAztbuyYo4Kvd.findall('class="breadcrumb"(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if uz3TGiOaQZdMA8x:
			WWU7QJP2tyTRLIfDh0csxbkvX = uz3TGiOaQZdMA8x[0]
			HRpMVv1x5ol9gbsnQquj = PAztbuyYo4Kvd.findall('href="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			if len(HRpMVv1x5ol9gbsnQquj)>2:
				ZylHkumQ8zD0 = HRpMVv1x5ol9gbsnQquj[2]+'list'
				LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(ZylHkumQ8zD0)
	return
def lNBcUr8RCn(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SHAHID4U-PLAY-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="actions(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if not zz3eHskxE6lAyDR5cNj1ug: return
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	HRpMVv1x5ol9gbsnQquj = PAztbuyYo4Kvd.findall('href="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	pndhDfUHG0cKMOSVa = '/watch/' in WWU7QJP2tyTRLIfDh0csxbkvX
	download = '/download/' in WWU7QJP2tyTRLIfDh0csxbkvX
	if   pndhDfUHG0cKMOSVa and not download: SU8NiL1uHJtRF2mxOwC,fwbFBqSEUPxDIvY8NaX = HRpMVv1x5ol9gbsnQquj[0],nA5dhMRg6ENzsB0l1GwvH7aIr2
	elif not pndhDfUHG0cKMOSVa and download: SU8NiL1uHJtRF2mxOwC,fwbFBqSEUPxDIvY8NaX = nA5dhMRg6ENzsB0l1GwvH7aIr2,HRpMVv1x5ol9gbsnQquj[0]
	elif pndhDfUHG0cKMOSVa and download: SU8NiL1uHJtRF2mxOwC,fwbFBqSEUPxDIvY8NaX = HRpMVv1x5ol9gbsnQquj[0],HRpMVv1x5ol9gbsnQquj[1]
	else: SU8NiL1uHJtRF2mxOwC,fwbFBqSEUPxDIvY8NaX = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	ce9zAaVFswSq6lLr82DfQyotGW = []
	if pndhDfUHG0cKMOSVa:
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',SU8NiL1uHJtRF2mxOwC,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SHAHID4U-PLAY-2nd')
		v2u4dgJnek0sQDxKf = Y3SmVGbfNvEeakMBr.content
		N5Vbkn2chPGfT3m97Bv1LHKI = PAztbuyYo4Kvd.findall('let servers(.*?)player',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL|PAztbuyYo4Kvd.IGNORECASE)
		if N5Vbkn2chPGfT3m97Bv1LHKI:
			YERWNbgAThV2uBr5taO8zcd = N5Vbkn2chPGfT3m97Bv1LHKI[0]
			hn2rCExmu5pgejyYOT = PAztbuyYo4Kvd.findall('"name":"(.*?)".*?"url":"(.*?)"',YERWNbgAThV2uBr5taO8zcd,PAztbuyYo4Kvd.DOTALL)
			for title,ZylHkumQ8zD0 in hn2rCExmu5pgejyYOT:
				ZylHkumQ8zD0 = ZylHkumQ8zD0.replace('\\/','/')
				ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named='+title+'__watch'
				ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	if download:
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',fwbFBqSEUPxDIvY8NaX,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SHAHID4U-PLAY-3rd')
		v2u4dgJnek0sQDxKf = Y3SmVGbfNvEeakMBr.content
		N5Vbkn2chPGfT3m97Bv1LHKI = PAztbuyYo4Kvd.findall('"servers"(.*?)info-container',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL)
		if N5Vbkn2chPGfT3m97Bv1LHKI:
			YERWNbgAThV2uBr5taO8zcd = N5Vbkn2chPGfT3m97Bv1LHKI[0]
			hn2rCExmu5pgejyYOT = PAztbuyYo4Kvd.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',YERWNbgAThV2uBr5taO8zcd,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,title,OzWg1yEQG8wtvJ4x2ic9aKedFAPD in hn2rCExmu5pgejyYOT:
				ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named='+title+'__download'+'____'+OzWg1yEQG8wtvJ4x2ic9aKedFAPD
				ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(ce9zAaVFswSq6lLr82DfQyotGW,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if not search:
		search = FaUBpzTGxtS7hZyl()
		if not search: return
	search = search.replace(hSXlxL9iB05c,'+')
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/search?s='+search
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,'search')
	return
def iBOFgUs6eTkIQyxKbqM(url):
	url = url.split('/smartemadfilter?')[0]
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SHAHID4U-GET_FILTERS_BLOCKS-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	AAkSjd9agcy = []
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('adv-filter(.*?)shows-container',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		AAkSjd9agcy = PAztbuyYo4Kvd.findall('''updateQuery\('(.*?)'.*?value.*?>(.*?)<(.*?)</select''',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		MFd17IQ58Unz,KDuQ6YkSCLPz5be7BqTAxhMXwgF,Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q = zip(*AAkSjd9agcy)
		AAkSjd9agcy = zip(KDuQ6YkSCLPz5be7BqTAxhMXwgF,MFd17IQ58Unz,Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q)
	return AAkSjd9agcy
def vPOwqQ5zYHc10DVaSmU2ysG8k4t(WWU7QJP2tyTRLIfDh0csxbkvX):
	items = PAztbuyYo4Kvd.findall('value="(.*?)".*?>\s*(.*?)\s*<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	return items
def iCNd2ua6f9EHyBXWYMrKcR(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	YS4MDi1r3wOKFhTHjeEBIsag = url.split('/smartemadfilter?')[0]
	xTNCXea9SPBRb = C2gnJ5tXFk9pAL(url,'url')
	url = url.replace(YS4MDi1r3wOKFhTHjeEBIsag,xTNCXea9SPBRb)
	url = url.replace('/smartemadfilter?','/?')
	return url
cc0WqiHnzER = ['quality','year','genre','category']
o7o2QXr0sG = ['category','genre','year']
def NNihMcqGKQEvLz6l(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==nA5dhMRg6ENzsB0l1GwvH7aIr2: vvXcyZhkfV,guikd57yRSCMsNmlUqFHWAYL = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	else: vvXcyZhkfV,guikd57yRSCMsNmlUqFHWAYL = filter.split('___')
	if type=='DEFINED_FILTER':
		if o7o2QXr0sG[0]+'=' not in vvXcyZhkfV: kvfOU7Tpz958QBqnIlaAePLys = o7o2QXr0sG[0]
		for q3kZpRe28O0s1NaCXQ9SMuGKin in range(len(o7o2QXr0sG[0:-1])):
			if o7o2QXr0sG[q3kZpRe28O0s1NaCXQ9SMuGKin]+'=' in vvXcyZhkfV: kvfOU7Tpz958QBqnIlaAePLys = o7o2QXr0sG[q3kZpRe28O0s1NaCXQ9SMuGKin+1]
		FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+kvfOU7Tpz958QBqnIlaAePLys+'=0'
		QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+kvfOU7Tpz958QBqnIlaAePLys+'=0'
		TB6HLPpacsK8f034jvYx7SNgFd = FqCItdu32L9hNwcEXWoges4R68KS.strip('&')+'___'+QA6C8r4lEdhemfJPRc.strip('&')
		OQmDdTI7hU4Lv3BfexPVKgRF8YN = EdpkojMzLm6b3ZSVcXwi0CPRIH(guikd57yRSCMsNmlUqFHWAYL,'modified_filters')
		KteRnFMjHpBPqNf8 = url+'/smartemadfilter?'+OQmDdTI7hU4Lv3BfexPVKgRF8YN
	elif type=='FULL_FILTER':
		iEa2qGQctFxX = EdpkojMzLm6b3ZSVcXwi0CPRIH(vvXcyZhkfV,'modified_values')
		iEa2qGQctFxX = pvOytL0nF7JY6flXTxAcHbQeNahu3(iEa2qGQctFxX)
		if guikd57yRSCMsNmlUqFHWAYL!=nA5dhMRg6ENzsB0l1GwvH7aIr2: guikd57yRSCMsNmlUqFHWAYL = EdpkojMzLm6b3ZSVcXwi0CPRIH(guikd57yRSCMsNmlUqFHWAYL,'modified_filters')
		if guikd57yRSCMsNmlUqFHWAYL==nA5dhMRg6ENzsB0l1GwvH7aIr2: KteRnFMjHpBPqNf8 = url
		else: KteRnFMjHpBPqNf8 = url+'/smartemadfilter?'+guikd57yRSCMsNmlUqFHWAYL
		w7Ol6FnokgJDSsIt = iCNd2ua6f9EHyBXWYMrKcR(KteRnFMjHpBPqNf8)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'أظهار قائمة الفيديو التي تم اختيارها ',w7Ol6FnokgJDSsIt,111)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+' [[   '+iEa2qGQctFxX+'   ]]',w7Ol6FnokgJDSsIt,111)
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	AAkSjd9agcy = iBOFgUs6eTkIQyxKbqM(url)
	dict = {}
	for name,xWwIXcK0L61EBgtn7smr,WWU7QJP2tyTRLIfDh0csxbkvX in AAkSjd9agcy:
		name = name.replace('كل ',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		items = vPOwqQ5zYHc10DVaSmU2ysG8k4t(WWU7QJP2tyTRLIfDh0csxbkvX)
		if '=' not in KteRnFMjHpBPqNf8: KteRnFMjHpBPqNf8 = url
		if type=='DEFINED_FILTER':
			if kvfOU7Tpz958QBqnIlaAePLys!=xWwIXcK0L61EBgtn7smr: continue
			elif len(items)<2:
				if xWwIXcK0L61EBgtn7smr==o7o2QXr0sG[-1]:
					w7Ol6FnokgJDSsIt = iCNd2ua6f9EHyBXWYMrKcR(KteRnFMjHpBPqNf8)
					LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(w7Ol6FnokgJDSsIt)
				else: NNihMcqGKQEvLz6l(KteRnFMjHpBPqNf8,'DEFINED_FILTER___'+TB6HLPpacsK8f034jvYx7SNgFd)
				return
			else:
				if xWwIXcK0L61EBgtn7smr==o7o2QXr0sG[-1]:
					w7Ol6FnokgJDSsIt = iCNd2ua6f9EHyBXWYMrKcR(KteRnFMjHpBPqNf8)
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع',w7Ol6FnokgJDSsIt,111)
				else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع',KteRnFMjHpBPqNf8,115,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,TB6HLPpacsK8f034jvYx7SNgFd)
		elif type=='FULL_FILTER':
			FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+xWwIXcK0L61EBgtn7smr+'=0'
			QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+xWwIXcK0L61EBgtn7smr+'=0'
			TB6HLPpacsK8f034jvYx7SNgFd = FqCItdu32L9hNwcEXWoges4R68KS+'___'+QA6C8r4lEdhemfJPRc
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع :'+name,KteRnFMjHpBPqNf8,114,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,TB6HLPpacsK8f034jvYx7SNgFd)
		dict[xWwIXcK0L61EBgtn7smr] = {}
		for value,DOT0LXwgoHYkFBC4MbxN53 in items:
			if value=='196533': DOT0LXwgoHYkFBC4MbxN53 = 'أفلام نيتفلكس'
			elif value=='196531': DOT0LXwgoHYkFBC4MbxN53 = 'مسلسلات نيتفلكس'
			if DOT0LXwgoHYkFBC4MbxN53 in SAsGubf1jW2Q3p: continue
			dict[xWwIXcK0L61EBgtn7smr][value] = DOT0LXwgoHYkFBC4MbxN53
			FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+xWwIXcK0L61EBgtn7smr+'='+DOT0LXwgoHYkFBC4MbxN53
			QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+xWwIXcK0L61EBgtn7smr+'='+value
			b97AdvPkWGEBe3ayj1Jhmcq2LVxr = FqCItdu32L9hNwcEXWoges4R68KS+'___'+QA6C8r4lEdhemfJPRc
			title = DOT0LXwgoHYkFBC4MbxN53+' :'#+dict[xWwIXcK0L61EBgtn7smr]['0']
			title = DOT0LXwgoHYkFBC4MbxN53+' :'+name
			if type=='FULL_FILTER': TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,114,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,b97AdvPkWGEBe3ayj1Jhmcq2LVxr)
			elif type=='DEFINED_FILTER' and o7o2QXr0sG[-2]+'=' in vvXcyZhkfV:
				OQmDdTI7hU4Lv3BfexPVKgRF8YN = EdpkojMzLm6b3ZSVcXwi0CPRIH(QA6C8r4lEdhemfJPRc,'modified_filters')
				KteRnFMjHpBPqNf8 = url+'/smartemadfilter?'+OQmDdTI7hU4Lv3BfexPVKgRF8YN
				w7Ol6FnokgJDSsIt = iCNd2ua6f9EHyBXWYMrKcR(KteRnFMjHpBPqNf8)
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,w7Ol6FnokgJDSsIt,111)
			else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,115,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,b97AdvPkWGEBe3ayj1Jhmcq2LVxr)
	return
def EdpkojMzLm6b3ZSVcXwi0CPRIH(tgsLX2uACmFhVznejRy6O,mode):
	tgsLX2uACmFhVznejRy6O = tgsLX2uACmFhVznejRy6O.replace('=&','=0&')
	tgsLX2uACmFhVznejRy6O = tgsLX2uACmFhVznejRy6O.strip('&')
	bpoRYqt38j = {}
	if '=' in tgsLX2uACmFhVznejRy6O:
		items = tgsLX2uACmFhVznejRy6O.split('&')
		for CQtNwXGVAJ2y5nBY in items:
			eehzynNs85aTHrgCUmFc3DBO12,value = CQtNwXGVAJ2y5nBY.split('=')
			bpoRYqt38j[eehzynNs85aTHrgCUmFc3DBO12] = value
	H5ROYNwvQFkBiVElThr = nA5dhMRg6ENzsB0l1GwvH7aIr2
	for key in cc0WqiHnzER:
		if key in list(bpoRYqt38j.keys()): value = bpoRYqt38j[key]
		else: value = '0'
		if '%' not in value: value = kGE6zoKSan54W(value)
		if mode=='modified_values' and value!='0': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+' + '+value
		elif mode=='modified_filters' and value!='0': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+'&'+key+'='+value
		elif mode=='all': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+'&'+key+'='+value
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.strip(' + ')
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.strip('&')
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.replace('=0','=')
	return H5ROYNwvQFkBiVElThr
# -*- coding: utf-8 -*-
from pR2X91txEm import *
headers = { 'User-Agent' : nA5dhMRg6ENzsB0l1GwvH7aIr2 }
wgj0rX5tbcxPulhmny = 'AKOAMCAM'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_AKC_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
SAsGubf1jW2Q3p = ['مصارعة']
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==350: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==351: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,text)
	elif mode==352: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LLabVp7hzj28CE0f1udx(url)
	elif mode==353: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==354: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = NNihMcqGKQEvLz6l(url,'FILTERS___'+text)
	elif mode==355: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = NNihMcqGKQEvLz6l(url,'CATEGORIES___'+text)
	elif mode==356: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = vji0AS3kFYDCZ(url)
	elif mode==357: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = vUbouSi29fWNkBHcR(url)
	elif mode==359: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('link',DjKrTPWEFw2YeCi5d6unBqhZSlAR+lSWzOYmN08+'هذا الموقع مغلق'+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,8)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,359,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فلتر محدد',GiqvpBF9xLEdHDr37byJSngeCQ,356)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فلتر كامل',GiqvpBF9xLEdHDr37byJSngeCQ,357)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'AKOAMCAM-MENU-1st')
	KteRnFMjHpBPqNf8 = PAztbuyYo4Kvd.findall('recently-container.*?href="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if KteRnFMjHpBPqNf8: KteRnFMjHpBPqNf8 = KteRnFMjHpBPqNf8[0]
	else: KteRnFMjHpBPqNf8 = GiqvpBF9xLEdHDr37byJSngeCQ
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'اضيف حديثا',KteRnFMjHpBPqNf8,351)
	KteRnFMjHpBPqNf8 = PAztbuyYo4Kvd.findall('@id":"(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if KteRnFMjHpBPqNf8: KteRnFMjHpBPqNf8 = KteRnFMjHpBPqNf8[0]
	else: KteRnFMjHpBPqNf8 = GiqvpBF9xLEdHDr37byJSngeCQ
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'المميزة',KteRnFMjHpBPqNf8,351,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'featured')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('main-categories-list(.*?)main-categories-list',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?class="font.*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			if title not in SAsGubf1jW2Q3p: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,351)
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="categories-box(.*?)<footer',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			ZylHkumQ8zD0 = HH8SJuswDBPtniebmkXIr(ZylHkumQ8zD0)
			if title not in SAsGubf1jW2Q3p: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,351)
	return kl2ZWdy8rXcHT
def vji0AS3kFYDCZ(website=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'AKOAMCAM-MENU-1st')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="menu(.*?)<nav',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?text">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			if title not in SAsGubf1jW2Q3p:
				title = title+' مصنفة'
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,355)
		if website==nA5dhMRg6ENzsB0l1GwvH7aIr2: TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	return kl2ZWdy8rXcHT
def vUbouSi29fWNkBHcR(website=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'AKOAMCAM-MENU-1st')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="menu(.*?)<nav',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?text">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			if title not in SAsGubf1jW2Q3p:
				title = title+' مفلترة'
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,354)
		if website==nA5dhMRg6ENzsB0l1GwvH7aIr2: TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	return kl2ZWdy8rXcHT
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,type=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(yy6RomT9bQhJf,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,True,'AKOAMCAM-TITLES-1st')
	if type=='featured': zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('swiper-container(.*?)swiper-button-prev',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	else: zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="container"(.*?)main-footer',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('xlink:href="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		u0UiTmzYN6I3Q9eCZVoB = []
		for HRlygv7YwjzbSLt8fkEerq2,ZylHkumQ8zD0,title in items:
			title = HH8SJuswDBPtniebmkXIr(title)
			if 'الحلقة' in title or 'الحلقه' in title:
				JfNHOP2BK1Yxl7Rq4 = PAztbuyYo4Kvd.findall('(.*?) (الحلقة|الحلقه) \d+',title,PAztbuyYo4Kvd.DOTALL)
				if JfNHOP2BK1Yxl7Rq4:
					title = '_MOD_' + JfNHOP2BK1Yxl7Rq4[0][0]
					if title not in u0UiTmzYN6I3Q9eCZVoB:
						TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,352,HRlygv7YwjzbSLt8fkEerq2)
						u0UiTmzYN6I3Q9eCZVoB.append(title)
			elif 'مسلسل' in title:
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,352,HRlygv7YwjzbSLt8fkEerq2)
			else: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,353,HRlygv7YwjzbSLt8fkEerq2)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('pagination(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href=["\'](.*?)["\'].*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			ZylHkumQ8zD0 = HH8SJuswDBPtniebmkXIr(ZylHkumQ8zD0)
			title = HH8SJuswDBPtniebmkXIr(title)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+title,ZylHkumQ8zD0,351)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	SEGtTsCyUVi0lo4LJkH5 = search.replace(hSXlxL9iB05c,'+')
	url = GiqvpBF9xLEdHDr37byJSngeCQ + '/?s='+SEGtTsCyUVi0lo4LJkH5
	V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
	return
def LLabVp7hzj28CE0f1udx(url):
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,True,'AKOAMCAM-EPISODES-1st')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('text-white">الحلقات(.*?)<header',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		GGr9WlIhv1BKDJjTZFNty4R3k0dCOA = PAztbuyYo4Kvd.findall('href="(http.*?)".*?src="(.*?)".*?alt="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in GGr9WlIhv1BKDJjTZFNty4R3k0dCOA:
			if 'الحلقة' in title or 'الحلقه' in title: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,353,HRlygv7YwjzbSLt8fkEerq2)
	else:
		HRlygv7YwjzbSLt8fkEerq2 = SoNGUfhMDERLyHOz1qkVAj.getInfoLabel('ListItem.Icon')
		if kl2ZWdy8rXcHT.count('<title>')>1: title = PAztbuyYo4Kvd.findall('<title>(.*?)<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)[1]
		else: title = 'رابط التشغيل'
		TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,353,HRlygv7YwjzbSLt8fkEerq2)
	return
def lNBcUr8RCn(url):
	ce9zAaVFswSq6lLr82DfQyotGW,ecU4Hy7lNS = [],[]
	gP9iDKZElzvN2Ohqb1H = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'AKOAMCAM-PLAY-1st')
	kl2ZWdy8rXcHT = gP9iDKZElzvN2Ohqb1H.content
	FPAhgMwOp1YSLN = PAztbuyYo4Kvd.findall('post_id=(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if FPAhgMwOp1YSLN:
		FPAhgMwOp1YSLN = FPAhgMwOp1YSLN[0]
		headers = {'User-Agent':nA5dhMRg6ENzsB0l1GwvH7aIr2,'Content-Type':'application/x-www-form-urlencoded'}
		data = {'post_id':FPAhgMwOp1YSLN}
		KteRnFMjHpBPqNf8 = GiqvpBF9xLEdHDr37byJSngeCQ+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Watch.php'
		DYyUEMnphKx9Asmc = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'POST',KteRnFMjHpBPqNf8,data,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'AKOAMCAM-PLAY-1st')
		v2u4dgJnek0sQDxKf = DYyUEMnphKx9Asmc.content
		items = PAztbuyYo4Kvd.findall('data-server="(.*?)".*?class="text">(.*?)<',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL)
		for mikbQXHhDITrRglen,name in items:
			ZylHkumQ8zD0 = 'https://w.akoam.cam/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Server.php'
			ZylHkumQ8zD0 = ZylHkumQ8zD0+'?postid='+FPAhgMwOp1YSLN+'&serverid='+mikbQXHhDITrRglen+'?named='+name+'__watch'
			ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
			ecU4Hy7lNS.append(name)
		KteRnFMjHpBPqNf8 = GiqvpBF9xLEdHDr37byJSngeCQ+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Download.php'
		DYyUEMnphKx9Asmc = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'POST',KteRnFMjHpBPqNf8,data,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'AKOAMCAM-PLAY-1st')
		v2u4dgJnek0sQDxKf = DYyUEMnphKx9Asmc.content
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?class="text">(.*?)<',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			ZylHkumQ8zD0 = ZylHkumQ8zD0.strip(hSXlxL9iB05c)
			ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named='+title+'__download'
			ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
			ecU4Hy7lNS.append(title)
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(ce9zAaVFswSq6lLr82DfQyotGW,wgj0rX5tbcxPulhmny,'video',url)
	return
def NNihMcqGKQEvLz6l(url,filter):
	J8bDm67uSQ53EOUiltdTPRhcgNKY = ['cat','genre','release-year','quality','orderby']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==nA5dhMRg6ENzsB0l1GwvH7aIr2: vvXcyZhkfV,guikd57yRSCMsNmlUqFHWAYL = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	else: vvXcyZhkfV,guikd57yRSCMsNmlUqFHWAYL = filter.split('___')
	if type=='CATEGORIES':
		if J8bDm67uSQ53EOUiltdTPRhcgNKY[0]+'=' not in vvXcyZhkfV: kvfOU7Tpz958QBqnIlaAePLys = J8bDm67uSQ53EOUiltdTPRhcgNKY[0]
		for q3kZpRe28O0s1NaCXQ9SMuGKin in range(len(J8bDm67uSQ53EOUiltdTPRhcgNKY[0:-1])):
			if J8bDm67uSQ53EOUiltdTPRhcgNKY[q3kZpRe28O0s1NaCXQ9SMuGKin]+'=' in vvXcyZhkfV: kvfOU7Tpz958QBqnIlaAePLys = J8bDm67uSQ53EOUiltdTPRhcgNKY[q3kZpRe28O0s1NaCXQ9SMuGKin+1]
		FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+kvfOU7Tpz958QBqnIlaAePLys+'=0'
		QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+kvfOU7Tpz958QBqnIlaAePLys+'=0'
		TB6HLPpacsK8f034jvYx7SNgFd = FqCItdu32L9hNwcEXWoges4R68KS.strip('&')+'___'+QA6C8r4lEdhemfJPRc.strip('&')
		OQmDdTI7hU4Lv3BfexPVKgRF8YN = EdpkojMzLm6b3ZSVcXwi0CPRIH(guikd57yRSCMsNmlUqFHWAYL,'all')
		KteRnFMjHpBPqNf8 = url+'?'+OQmDdTI7hU4Lv3BfexPVKgRF8YN
	elif type=='FILTERS':
		iEa2qGQctFxX = EdpkojMzLm6b3ZSVcXwi0CPRIH(vvXcyZhkfV,'modified_values')
		iEa2qGQctFxX = pvOytL0nF7JY6flXTxAcHbQeNahu3(iEa2qGQctFxX)
		if guikd57yRSCMsNmlUqFHWAYL!=nA5dhMRg6ENzsB0l1GwvH7aIr2: guikd57yRSCMsNmlUqFHWAYL = EdpkojMzLm6b3ZSVcXwi0CPRIH(guikd57yRSCMsNmlUqFHWAYL,'all')
		if guikd57yRSCMsNmlUqFHWAYL==nA5dhMRg6ENzsB0l1GwvH7aIr2: KteRnFMjHpBPqNf8 = url
		else: KteRnFMjHpBPqNf8 = url+'?'+guikd57yRSCMsNmlUqFHWAYL
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'أظهار قائمة الفيديو التي تم اختيارها',KteRnFMjHpBPqNf8,351,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1')
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+' [[   '+iEa2qGQctFxX+'   ]]',KteRnFMjHpBPqNf8,351,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1')
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,True,'AKOAMCAM-FILTERS_MENU-1st')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('<form id(.*?)</form>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	AAkSjd9agcy = PAztbuyYo4Kvd.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	dict = {}
	for xWwIXcK0L61EBgtn7smr,name,WWU7QJP2tyTRLIfDh0csxbkvX in AAkSjd9agcy:
		items = PAztbuyYo4Kvd.findall('<option(.*?)>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if '=' not in KteRnFMjHpBPqNf8: KteRnFMjHpBPqNf8 = url
		if type=='CATEGORIES':
			if kvfOU7Tpz958QBqnIlaAePLys!=xWwIXcK0L61EBgtn7smr: continue
			elif len(items)<=1:
				if xWwIXcK0L61EBgtn7smr==J8bDm67uSQ53EOUiltdTPRhcgNKY[-1]: LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(KteRnFMjHpBPqNf8)
				else: NNihMcqGKQEvLz6l(KteRnFMjHpBPqNf8,'CATEGORIES___'+TB6HLPpacsK8f034jvYx7SNgFd)
				return
			else:
				if xWwIXcK0L61EBgtn7smr==J8bDm67uSQ53EOUiltdTPRhcgNKY[-1]: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع',KteRnFMjHpBPqNf8,351,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1')
				else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع',KteRnFMjHpBPqNf8,355,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,TB6HLPpacsK8f034jvYx7SNgFd)
		elif type=='FILTERS':
			FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+xWwIXcK0L61EBgtn7smr+'=0'
			QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+xWwIXcK0L61EBgtn7smr+'=0'
			TB6HLPpacsK8f034jvYx7SNgFd = FqCItdu32L9hNwcEXWoges4R68KS+'___'+QA6C8r4lEdhemfJPRc
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع : '+name,KteRnFMjHpBPqNf8,354,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,TB6HLPpacsK8f034jvYx7SNgFd)
		dict[xWwIXcK0L61EBgtn7smr] = {}
		for value,DOT0LXwgoHYkFBC4MbxN53 in items:
			if DOT0LXwgoHYkFBC4MbxN53 in SAsGubf1jW2Q3p: continue
			if 'value' not in value: value = DOT0LXwgoHYkFBC4MbxN53
			else: value = PAztbuyYo4Kvd.findall('"(.*?)"',value,PAztbuyYo4Kvd.DOTALL)[0]
			dict[xWwIXcK0L61EBgtn7smr][value] = DOT0LXwgoHYkFBC4MbxN53
			FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+xWwIXcK0L61EBgtn7smr+'='+DOT0LXwgoHYkFBC4MbxN53
			QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+xWwIXcK0L61EBgtn7smr+'='+value
			b97AdvPkWGEBe3ayj1Jhmcq2LVxr = FqCItdu32L9hNwcEXWoges4R68KS+'___'+QA6C8r4lEdhemfJPRc
			title = DOT0LXwgoHYkFBC4MbxN53+' : '#+dict[xWwIXcK0L61EBgtn7smr]['0']
			title = DOT0LXwgoHYkFBC4MbxN53+' : '+name
			if type=='FILTERS': TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,354,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,b97AdvPkWGEBe3ayj1Jhmcq2LVxr)
			elif type=='CATEGORIES' and J8bDm67uSQ53EOUiltdTPRhcgNKY[-2]+'=' in vvXcyZhkfV:
				OQmDdTI7hU4Lv3BfexPVKgRF8YN = EdpkojMzLm6b3ZSVcXwi0CPRIH(QA6C8r4lEdhemfJPRc,'all')
				w7Ol6FnokgJDSsIt = url+'?'+OQmDdTI7hU4Lv3BfexPVKgRF8YN
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,w7Ol6FnokgJDSsIt,351,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1')
			else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,355,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,b97AdvPkWGEBe3ayj1Jhmcq2LVxr)
	return
def EdpkojMzLm6b3ZSVcXwi0CPRIH(tgsLX2uACmFhVznejRy6O,mode):
	tgsLX2uACmFhVznejRy6O = tgsLX2uACmFhVznejRy6O.strip('&')
	bpoRYqt38j = {}
	if '=' in tgsLX2uACmFhVznejRy6O:
		items = tgsLX2uACmFhVznejRy6O.split('&')
		for CQtNwXGVAJ2y5nBY in items:
			eehzynNs85aTHrgCUmFc3DBO12,value = CQtNwXGVAJ2y5nBY.split('=')
			bpoRYqt38j[eehzynNs85aTHrgCUmFc3DBO12] = value
	H5ROYNwvQFkBiVElThr = nA5dhMRg6ENzsB0l1GwvH7aIr2
	F45fPJwzqEWNISAml = ['cat','genre','release-year','quality','orderby']
	for key in F45fPJwzqEWNISAml:
		if key in list(bpoRYqt38j.keys()): value = bpoRYqt38j[key]
		else: value = '0'
		if mode=='modified_values' and value!='0': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+' + '+value
		elif mode=='modified_filters' and value!='0': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+'&'+key+'='+value
		elif mode=='all': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+'&'+key+'='+value
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.strip(' + ')
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.strip('&')
	return H5ROYNwvQFkBiVElThr
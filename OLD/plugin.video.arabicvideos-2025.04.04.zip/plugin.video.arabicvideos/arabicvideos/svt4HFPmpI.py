# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'SHOOFPRO'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_SHP_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
SAsGubf1jW2Q3p = ['مصارعة','بث مباشر']
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==480: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==481: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,text)
	elif mode==482: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==483: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LLabVp7hzj28CE0f1udx(url,text)
	elif mode==489: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text,url)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SHOOFPRO-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	GWjBrpNhRsmt7eDba1yA4nukS = PAztbuyYo4Kvd.findall('href="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	GWjBrpNhRsmt7eDba1yA4nukS = GWjBrpNhRsmt7eDba1yA4nukS[0].strip('/')
	GWjBrpNhRsmt7eDba1yA4nukS = C2gnJ5tXFk9pAL(GWjBrpNhRsmt7eDba1yA4nukS,'url')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',GWjBrpNhRsmt7eDba1yA4nukS,489,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'أحدث المواضيع',GWjBrpNhRsmt7eDba1yA4nukS,481)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"navigation"(.*?)"myAccount"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('href="(.*?)".*?</span>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title in items:
		if ZylHkumQ8zD0=='#': continue
		if title in SAsGubf1jW2Q3p: continue
		title = HH8SJuswDBPtniebmkXIr(title)
		TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,481)
	return kl2ZWdy8rXcHT
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,hhSkmxi7F4rawWK3LeJNbR0uUvjPg):
	items = []
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SHOOFPRO-TITLES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"post(.*?)"footer"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if not zz3eHskxE6lAyDR5cNj1ug: return
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('href="(.*?)" title="(.*?)".*?image:url\((.*?)\)',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	u0UiTmzYN6I3Q9eCZVoB = []
	hdocEkRK0Q = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	pudPG4a2CQjF9OXg18MUVr57eitkLh = '/'.join(hhSkmxi7F4rawWK3LeJNbR0uUvjPg.strip('/').split('/')[4:]).split('-')
	for ZylHkumQ8zD0,title,HRlygv7YwjzbSLt8fkEerq2 in items:
		title = HH8SJuswDBPtniebmkXIr(title)
		JfNHOP2BK1Yxl7Rq4 = PAztbuyYo4Kvd.findall('(.*?) حلقة \d+',title,PAztbuyYo4Kvd.DOTALL)
		if hhSkmxi7F4rawWK3LeJNbR0uUvjPg:
			ww5oBKPZmc = '/'.join(ZylHkumQ8zD0.strip('/').split('/')[4:]).split('-')
			XzdxnkhfQB8OasJb10jU6ZEqP = len([Ab4TEqtXv5Smpf1PCoNQ9 for Ab4TEqtXv5Smpf1PCoNQ9 in pudPG4a2CQjF9OXg18MUVr57eitkLh if Ab4TEqtXv5Smpf1PCoNQ9 in ww5oBKPZmc])
			if XzdxnkhfQB8OasJb10jU6ZEqP>2 and '/episodes/' in ZylHkumQ8zD0:
				TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,482,HRlygv7YwjzbSLt8fkEerq2)
		else:
			if not JfNHOP2BK1Yxl7Rq4: JfNHOP2BK1Yxl7Rq4 = PAztbuyYo4Kvd.findall('(.*?) الحلقة \d+',title,PAztbuyYo4Kvd.DOTALL)
			if set(title.split()) & set(hdocEkRK0Q) and 'مسلسل' not in title:
				TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,482,HRlygv7YwjzbSLt8fkEerq2)
			elif JfNHOP2BK1Yxl7Rq4 and 'حلقة' in title:
				title = '_MOD_' + JfNHOP2BK1Yxl7Rq4[0]
				if title not in u0UiTmzYN6I3Q9eCZVoB:
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,483,HRlygv7YwjzbSLt8fkEerq2,nA5dhMRg6ENzsB0l1GwvH7aIr2,url)
					u0UiTmzYN6I3Q9eCZVoB.append(title)
			else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,483,HRlygv7YwjzbSLt8fkEerq2,nA5dhMRg6ENzsB0l1GwvH7aIr2,url)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall("'pagination'(.*?)</div>",kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall("href='(.*?)'.*?>(.*?)</a>",WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			title = HH8SJuswDBPtniebmkXIr(title)
			title = title.replace('الصفحة ',nA5dhMRg6ENzsB0l1GwvH7aIr2)
			if title!=nA5dhMRg6ENzsB0l1GwvH7aIr2: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+title,ZylHkumQ8zD0,481,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,hhSkmxi7F4rawWK3LeJNbR0uUvjPg)
	return
def LLabVp7hzj28CE0f1udx(url,KteRnFMjHpBPqNf8):
	headers = {'X-Requested-With':'XMLHttpRequest'}
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SHOOFPRO-EPISODES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	GWjBrpNhRsmt7eDba1yA4nukS = C2gnJ5tXFk9pAL(url,'url')
	HRlygv7YwjzbSLt8fkEerq2 = PAztbuyYo4Kvd.findall('"img-responsive" src="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if HRlygv7YwjzbSLt8fkEerq2: HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2[0]
	else: HRlygv7YwjzbSLt8fkEerq2 = SoNGUfhMDERLyHOz1qkVAj.getInfoLabel('ListItem.Thumb')
	jHsnGpK7CF8E3XyS9L2oY6ruzO1 = True
	LKk0YdTN72XmnMuBbw = PAztbuyYo4Kvd.findall('"listSeasons(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if LKk0YdTN72XmnMuBbw and '/ajax/seasons' not in url:
		WWU7QJP2tyTRLIfDh0csxbkvX = LKk0YdTN72XmnMuBbw[0]
		count = WWU7QJP2tyTRLIfDh0csxbkvX.count('data-slug=')
		if count==0: count = WWU7QJP2tyTRLIfDh0csxbkvX.count('data-season=')
		if count>1:
			jHsnGpK7CF8E3XyS9L2oY6ruzO1 = False
			if 'data-slug="' in WWU7QJP2tyTRLIfDh0csxbkvX:
				items = PAztbuyYo4Kvd.findall('data-slug="(.*?)">(.*?)</li>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
				for id,title in items:
					ZylHkumQ8zD0 = GWjBrpNhRsmt7eDba1yA4nukS+'/wp-content/themes/vo2021/temp/ajax/seasons2.php?slug='+id
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,483,HRlygv7YwjzbSLt8fkEerq2)
			else:
				items = PAztbuyYo4Kvd.findall('data-season="(.*?)">(.*?)</li>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
				for id,title in items:
					ZylHkumQ8zD0 = GWjBrpNhRsmt7eDba1yA4nukS+'/wp-content/themes/vo2021/temp/ajax/seasons.php?seriesID='+id
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,483,HRlygv7YwjzbSLt8fkEerq2)
	if jHsnGpK7CF8E3XyS9L2oY6ruzO1:
		WWU7QJP2tyTRLIfDh0csxbkvX = nA5dhMRg6ENzsB0l1GwvH7aIr2
		if '/ajax/seasons' in url: WWU7QJP2tyTRLIfDh0csxbkvX = kl2ZWdy8rXcHT
		else:
			N5Vbkn2chPGfT3m97Bv1LHKI = PAztbuyYo4Kvd.findall('"eplist"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
			if N5Vbkn2chPGfT3m97Bv1LHKI: WWU7QJP2tyTRLIfDh0csxbkvX = N5Vbkn2chPGfT3m97Bv1LHKI[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)" title="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if items:
			for ZylHkumQ8zD0,title in items:
				title = title.strip(hSXlxL9iB05c)
				TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,482,HRlygv7YwjzbSLt8fkEerq2)
	if not Nzp9Fq5cTr.menuItemsLIST: LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(KteRnFMjHpBPqNf8,url)
	return
def lNBcUr8RCn(url):
	KteRnFMjHpBPqNf8 = url.strip('/')+'/?do=watch'
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SHOOFPRO-PLAY-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	ce9zAaVFswSq6lLr82DfQyotGW = []
	GWjBrpNhRsmt7eDba1yA4nukS = C2gnJ5tXFk9pAL(url,'url')
	bJ4y9AcpNTXFIEqMSvjuLgH3 = PAztbuyYo4Kvd.findall('vo_postID = "(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if not bJ4y9AcpNTXFIEqMSvjuLgH3: bJ4y9AcpNTXFIEqMSvjuLgH3 = PAztbuyYo4Kvd.findall('\(this\.id\,0\,(.*?)\)',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	bJ4y9AcpNTXFIEqMSvjuLgH3 = bJ4y9AcpNTXFIEqMSvjuLgH3[0]
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"serversList"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('id="(.*?)".*?">(.*?)</li>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for sY92fNZ5vkMUn7V,title in items:
			title = title.strip(hSXlxL9iB05c)
			ZylHkumQ8zD0 = GWjBrpNhRsmt7eDba1yA4nukS+'/wp-content/themes/vo2021/temp/ajax/iframe2.php?id='+bJ4y9AcpNTXFIEqMSvjuLgH3+'&video='+sY92fNZ5vkMUn7V[2:]+'?named='+title+'__watch'
			ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	ZylHkumQ8zD0 = PAztbuyYo4Kvd.findall('"getEmbed".*?src="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if ZylHkumQ8zD0:
		title = C2gnJ5tXFk9pAL(ZylHkumQ8zD0[0],'url')
		ZylHkumQ8zD0 = ZylHkumQ8zD0[0]+'?named='+title+'__embed'
		ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	KteRnFMjHpBPqNf8 = url.strip('/')+'/?do=download'
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SHOOFPRO-PLAY-2nd')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"table-responsive"(.*?)</table>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('<td>(.*?)</td>.*?href="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for title,ZylHkumQ8zD0 in items:
			title = title.strip(hSXlxL9iB05c)
			if 'anavidz' in ZylHkumQ8zD0: g7qwMTAPoVpIyQUaDeNOnhvs = '__خاص'
			else: g7qwMTAPoVpIyQUaDeNOnhvs = nA5dhMRg6ENzsB0l1GwvH7aIr2
			ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named='+title+'__download'+g7qwMTAPoVpIyQUaDeNOnhvs
			ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(ce9zAaVFswSq6lLr82DfQyotGW,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search,GWjBrpNhRsmt7eDba1yA4nukS=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	search = search.replace(hSXlxL9iB05c,'+')
	if GWjBrpNhRsmt7eDba1yA4nukS==nA5dhMRg6ENzsB0l1GwvH7aIr2: GWjBrpNhRsmt7eDba1yA4nukS = GiqvpBF9xLEdHDr37byJSngeCQ
	url = GWjBrpNhRsmt7eDba1yA4nukS+'/search/'+search+'/'
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,nA5dhMRg6ENzsB0l1GwvH7aIr2)
	return
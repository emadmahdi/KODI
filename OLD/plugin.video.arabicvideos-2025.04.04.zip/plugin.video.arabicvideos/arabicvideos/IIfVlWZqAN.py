# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'EGYBEST3'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_EB3_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
SAsGubf1jW2Q3p = ['المصارعة الحرة','ايجي بست','التصميم الجديد','عروض المصارعة','مكتبتي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست','موقع نتفليكس']
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,Q0f7ytucSriRw8HTzd,text):
	if   mode==790: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==791: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,Q0f7ytucSriRw8HTzd)
	elif mode==792: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = oWcvptkU2JObI0(url)
	elif mode==793: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==796: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = SNVTEdvxWujYnGR7J6hACUP(url,Q0f7ytucSriRw8HTzd)
	elif mode==799: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBEST3-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('list-pages(.*?)fa-folder',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?<span>(.*?)</span>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			title = title.strip(hSXlxL9iB05c)
			if any(value in title for value in SAsGubf1jW2Q3p): continue
			if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,791)
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('main-article(.*?)social-box',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('main-title.*?">(.*?)<.*?href="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for title,ZylHkumQ8zD0 in items:
			title = title.strip(hSXlxL9iB05c)
			if any(value in title for value in SAsGubf1jW2Q3p): continue
			if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,791,nA5dhMRg6ENzsB0l1GwvH7aIr2,'mainmenu')
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('main-menu(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			title = title.strip(hSXlxL9iB05c)
			if any(value in title for value in SAsGubf1jW2Q3p): continue
			if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,791)
	return kl2ZWdy8rXcHT
def SNVTEdvxWujYnGR7J6hACUP(url,type=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBEST3-SEASONS_EPISODES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('main-article".*?">(.*?)<(.*?)article',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		wWeVHSMqxGR,GGr9WlIhv1BKDJjTZFNty4R3k0dCOA,items = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,[]
		for name,WWU7QJP2tyTRLIfDh0csxbkvX in zz3eHskxE6lAyDR5cNj1ug:
			if 'حلقات' in name: GGr9WlIhv1BKDJjTZFNty4R3k0dCOA = WWU7QJP2tyTRLIfDh0csxbkvX
			if 'مواسم' in name: wWeVHSMqxGR = WWU7QJP2tyTRLIfDh0csxbkvX
		if wWeVHSMqxGR and not type:
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',wWeVHSMqxGR,PAztbuyYo4Kvd.DOTALL)
			if len(items)>1:
				for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,796,HRlygv7YwjzbSLt8fkEerq2,'season')
		if GGr9WlIhv1BKDJjTZFNty4R3k0dCOA and len(items)<2:
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?data-src="(.*?)".*?class="title">(.*?)<',GGr9WlIhv1BKDJjTZFNty4R3k0dCOA,PAztbuyYo4Kvd.DOTALL)
			if items:
				for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
					TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,793,HRlygv7YwjzbSLt8fkEerq2)
			else:
				items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',GGr9WlIhv1BKDJjTZFNty4R3k0dCOA,PAztbuyYo4Kvd.DOTALL)
				for ZylHkumQ8zD0,title in items:
					TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,793)
	return
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,type=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	mmpqeadyUFbYhXR7fsHMQN1wlu6LDI,start,LV9moOrXWFKbGYevPgul,select,ssb3JvMHKk8C0O = 0,0,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	if 'pagination' in type:
		kHgE2dbiQNuP,data = ss2VIkClmtevKqPUuSx9DGpX(url)
		mmpqeadyUFbYhXR7fsHMQN1wlu6LDI = int(data['limit'])
		start = int(data['start'])
		LV9moOrXWFKbGYevPgul = data['type']
		select = data['select']
		rA4ZGoQyIHlneVfzNukWd = 'limit='+str(mmpqeadyUFbYhXR7fsHMQN1wlu6LDI)+'&start='+str(start)+'&type='+LV9moOrXWFKbGYevPgul+'&select='+select
		LevQwm0pbqP1 = {'Content-Type':'application/x-www-form-urlencoded'}
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'POST',kHgE2dbiQNuP,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBEST3-TITLES-1st')
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
		v2u4dgJnek0sQDxKf = 'blocks'+kl2ZWdy8rXcHT+'article'
	else:
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBEST3-TITLES-2nd')
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
		v2u4dgJnek0sQDxKf = kl2ZWdy8rXcHT
		code = PAztbuyYo4Kvd.findall("<script>(var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?);</script>",kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if code:
			code = code[0].replace('var',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(hSXlxL9iB05c,nA5dhMRg6ENzsB0l1GwvH7aIr2).replace("'",nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(';','&')
			eIlXpH1gLhmP4w3,data = ss2VIkClmtevKqPUuSx9DGpX('?'+code)
			mmpqeadyUFbYhXR7fsHMQN1wlu6LDI = int(data['limit'])
			start = int(data['start'])
			LV9moOrXWFKbGYevPgul = data['type']
			select = data['select']
			ssb3JvMHKk8C0O = data['ajaxurl']
			rA4ZGoQyIHlneVfzNukWd = 'limit='+str(mmpqeadyUFbYhXR7fsHMQN1wlu6LDI)+'&start='+str(start)+'&type='+LV9moOrXWFKbGYevPgul+'&select='+select
			kHgE2dbiQNuP = GiqvpBF9xLEdHDr37byJSngeCQ+ssb3JvMHKk8C0O
			LevQwm0pbqP1 = {'Content-Type':'application/x-www-form-urlencoded'}
			Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'POST',kHgE2dbiQNuP,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBEST3-TITLES-3rd')
			v2u4dgJnek0sQDxKf = Y3SmVGbfNvEeakMBr.content
			v2u4dgJnek0sQDxKf = 'blocks'+v2u4dgJnek0sQDxKf+'article'
	items,ddoTyXHWlmDVAnEpzGwhxu7i,tgsLX2uACmFhVznejRy6O = [],False,False
	if not type:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('main-content(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?</i>(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,title in items:
				title = title.strip(hSXlxL9iB05c)
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,791,nA5dhMRg6ENzsB0l1GwvH7aIr2,'submenu')
				ddoTyXHWlmDVAnEpzGwhxu7i = True
	if not type:
		tgsLX2uACmFhVznejRy6O = rYAf8NzmSqsLXgpKMVUCIHtjZ1JucD(kl2ZWdy8rXcHT)
	if not ddoTyXHWlmDVAnEpzGwhxu7i and not tgsLX2uACmFhVznejRy6O:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('blocks(.*?)article',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
				HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2.strip(CXtugbqhV3)
				ZylHkumQ8zD0 = pvOytL0nF7JY6flXTxAcHbQeNahu3(ZylHkumQ8zD0)
				if '/selary/' in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,791,HRlygv7YwjzbSLt8fkEerq2)
				elif 'مسلسل' in ZylHkumQ8zD0 and 'حلقة' not in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,796,HRlygv7YwjzbSLt8fkEerq2)
				elif 'موسم' in ZylHkumQ8zD0 and 'حلقة' not in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,796,HRlygv7YwjzbSLt8fkEerq2)
				else: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,793,HRlygv7YwjzbSLt8fkEerq2)
		B0hfc9OtnWYbs1 = 12
		data = PAztbuyYo4Kvd.findall('class="(load-more.*?)<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if len(items)==B0hfc9OtnWYbs1 and (data or 'pagination' in type):
			rA4ZGoQyIHlneVfzNukWd = 'limit='+str(B0hfc9OtnWYbs1)+'&start='+str(start+B0hfc9OtnWYbs1)+'&type='+LV9moOrXWFKbGYevPgul+'&select='+select
			KteRnFMjHpBPqNf8 = kHgE2dbiQNuP+'?next=page&'+rA4ZGoQyIHlneVfzNukWd
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'المزيد',KteRnFMjHpBPqNf8,791,nA5dhMRg6ENzsB0l1GwvH7aIr2,'pagination_'+type)
	return
def rYAf8NzmSqsLXgpKMVUCIHtjZ1JucD(kl2ZWdy8rXcHT):
	tgsLX2uACmFhVznejRy6O = False
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('main-article(.*?)article',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q = PAztbuyYo4Kvd.findall('data-tax="(.*?)".*?<span>(.*?)<(.*?)</ul>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q: TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
		for kvfOU7Tpz958QBqnIlaAePLys,name,WWU7QJP2tyTRLIfDh0csxbkvX in Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q:
			name = name.strip(hSXlxL9iB05c)
			items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,value in items:
				title = name+':  '+value
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,791,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filter')
				tgsLX2uACmFhVznejRy6O = True
	return tgsLX2uACmFhVznejRy6O
def lNBcUr8RCn(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(yy6RomT9bQhJf,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBEST3-PLAY-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	HtT6mBGwMaq1o0rybzZ4,Co7gJfiXOmlN4VrbjhuknEH = [],[]
	items = PAztbuyYo4Kvd.findall('server-item.*?data-code="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	for UIA69Ri127rKyu in items:
		jjpcqDEgJHMbl9zr76AanS = Ic92Lb6lnzM5KJsx4Y3UGa70imZo.b64decode(UIA69Ri127rKyu)
		if BsLJ7p5Av2Vm0SQeCO1o: jjpcqDEgJHMbl9zr76AanS = jjpcqDEgJHMbl9zr76AanS.decode(YWEQ3Cf8RevpD0m7NjF1)
		ZylHkumQ8zD0 = PAztbuyYo4Kvd.findall('src="(.*?)"',jjpcqDEgJHMbl9zr76AanS,PAztbuyYo4Kvd.DOTALL)
		if ZylHkumQ8zD0:
			ZylHkumQ8zD0 = ZylHkumQ8zD0[0]
			if ZylHkumQ8zD0 not in Co7gJfiXOmlN4VrbjhuknEH:
				Co7gJfiXOmlN4VrbjhuknEH.append(ZylHkumQ8zD0)
				DQ7XgFltujVL = C2gnJ5tXFk9pAL(ZylHkumQ8zD0,'name')
				HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0+'?named='+DQ7XgFltujVL+'__watch')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="downloads(.*?)</section>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('"tr flex-start".*?<div>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</div>.*?href="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for OzWg1yEQG8wtvJ4x2ic9aKedFAPD,ZylHkumQ8zD0 in items:
			if ZylHkumQ8zD0 not in Co7gJfiXOmlN4VrbjhuknEH:
				if '/?url=' in ZylHkumQ8zD0: ZylHkumQ8zD0 = ZylHkumQ8zD0.split('/?url=')[1]
				Co7gJfiXOmlN4VrbjhuknEH.append(ZylHkumQ8zD0)
				DQ7XgFltujVL = C2gnJ5tXFk9pAL(ZylHkumQ8zD0,'name')
				HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0+'?named='+DQ7XgFltujVL+'__download____'+OzWg1yEQG8wtvJ4x2ic9aKedFAPD)
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(HtT6mBGwMaq1o0rybzZ4,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(text):
	return
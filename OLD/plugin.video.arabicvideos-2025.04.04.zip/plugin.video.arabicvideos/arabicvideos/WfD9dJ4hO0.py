# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'KARBALATV'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_KRB_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
headers = {'User-Agent':nA5dhMRg6ENzsB0l1GwvH7aIr2}
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==320: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==321: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
	elif mode==322: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==329: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,329,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',GiqvpBF9xLEdHDr37byJSngeCQ+'/video.php',nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'KARBALATV-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="icono-plus"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title in items:
		if title=='المكتبة المرئية': continue
		ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
		TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,321)
	return kl2ZWdy8rXcHT
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'KARBALATV-TITLES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="container"(.*?)class="footer',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('href="(.*?)".*?url\((.*?)\).*?pd5">(.*?)<.*?<h3.*?">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	if not items: items = PAztbuyYo4Kvd.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)".*?<p.*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,count,title in items:
		count = count.replace('عدد ',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(hSXlxL9iB05c,nA5dhMRg6ENzsB0l1GwvH7aIr2)
		ZylHkumQ8zD0 = ZylHkumQ8zD0.replace('/',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2.replace("'",nA5dhMRg6ENzsB0l1GwvH7aIr2)
		if '.php' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = 'video.php'+ZylHkumQ8zD0
		ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+ZylHkumQ8zD0
		HRlygv7YwjzbSLt8fkEerq2 = GiqvpBF9xLEdHDr37byJSngeCQ+HRlygv7YwjzbSLt8fkEerq2
		title = title.strip(hSXlxL9iB05c)
		title = title+' ('+count+')'
		if 'video.php' in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,321,HRlygv7YwjzbSLt8fkEerq2)
		elif 'watch.php' in ZylHkumQ8zD0: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,322,HRlygv7YwjzbSLt8fkEerq2)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="pagination(.*?)class="footer',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/video.php'+ZylHkumQ8zD0
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+title,ZylHkumQ8zD0,321)
	return
def lNBcUr8RCn(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'KARBALATV-PLAY-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	ZylHkumQ8zD0 = PAztbuyYo4Kvd.findall('<video.*?src="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0[0]
	ocUnzjShqIO35vZi8bk64pVKMCTBaw(ZylHkumQ8zD0,wgj0rX5tbcxPulhmny,'video')
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	search = search.replace(hSXlxL9iB05c,'+')
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/search.php?q='+search
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
	return
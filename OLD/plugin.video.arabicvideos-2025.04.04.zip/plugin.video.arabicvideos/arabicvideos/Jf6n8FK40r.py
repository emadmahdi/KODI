﻿# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'ALMAAREF'
headers = {'User-Agent':nA5dhMRg6ENzsB0l1GwvH7aIr2}
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_MRF_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
SAsGubf1jW2Q3p = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text,Q0f7ytucSriRw8HTzd):
	if   mode==40: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==41: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = g3Vrp8uHOcdnY7t()
	elif mode==42: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = jkWtiP0DG76AabE(text,Q0f7ytucSriRw8HTzd)
	elif mode==43: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==44: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(text,Q0f7ytucSriRw8HTzd)
	elif mode==49: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,49)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('live',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'البث الحي لقناة المعارف',nA5dhMRg6ENzsB0l1GwvH7aIr2,41)
	jkWtiP0DG76AabE(nA5dhMRg6ENzsB0l1GwvH7aIr2,'1')
	return
def yytpn5rcDRKNaqPV3xhg9THswjv(m0YJ3feqUjD7,kmi4lE16XPF9sAKDTqVj):
	search,sort,P1guOVJKRNn80L5sw427BS9FDbm,kvfOU7Tpz958QBqnIlaAePLys,CA1wUkhLv4FeT87tqx = nA5dhMRg6ENzsB0l1GwvH7aIr2,[],[],[],[]
	eIlXpH1gLhmP4w3,iip0HIlTC9zVk8nJjhmW = ss2VIkClmtevKqPUuSx9DGpX(m0YJ3feqUjD7)
	for DOT0LXwgoHYkFBC4MbxN53 in list(iip0HIlTC9zVk8nJjhmW.keys()):
		value = iip0HIlTC9zVk8nJjhmW[DOT0LXwgoHYkFBC4MbxN53]
		if not value: continue
		if   DOT0LXwgoHYkFBC4MbxN53=='sort': sort = [value]
		elif DOT0LXwgoHYkFBC4MbxN53=='series': P1guOVJKRNn80L5sw427BS9FDbm = [value]
		elif DOT0LXwgoHYkFBC4MbxN53=='search': search = value
		elif DOT0LXwgoHYkFBC4MbxN53=='category': kvfOU7Tpz958QBqnIlaAePLys = [value]
		elif DOT0LXwgoHYkFBC4MbxN53=='specialist': CA1wUkhLv4FeT87tqx = [value]
	hwZT5nYUGQ1RJC = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":kvfOU7Tpz958QBqnIlaAePLys,"specialist":CA1wUkhLv4FeT87tqx,"series":P1guOVJKRNn80L5sw427BS9FDbm,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(kmi4lE16XPF9sAKDTqVj)}}
	hwZT5nYUGQ1RJC = DcFpQN9gqn.dumps(hwZT5nYUGQ1RJC)
	ZylHkumQ8zD0 = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'POST',ZylHkumQ8zD0,hwZT5nYUGQ1RJC,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ALMAAREF-REQUEST_DATA_PAGE-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	data = BwGPDSQOlfUas2n3eIH0ycFRWZ('dict',kl2ZWdy8rXcHT)
	return data
def jkWtiP0DG76AabE(m0YJ3feqUjD7,level):
	Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q = yytpn5rcDRKNaqPV3xhg9THswjv(m0YJ3feqUjD7,'1')
	WWU7QJP2tyTRLIfDh0csxbkvX = Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q['facets']
	if level=='1':
		WWU7QJP2tyTRLIfDh0csxbkvX = WWU7QJP2tyTRLIfDh0csxbkvX['video_categories']
		items = PAztbuyYo4Kvd.findall('<div(.*?)/div>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for CQtNwXGVAJ2y5nBY in items:
			wU70GYa1jm3Kk = PAztbuyYo4Kvd.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',CQtNwXGVAJ2y5nBY+'<',PAztbuyYo4Kvd.DOTALL)
			if not wU70GYa1jm3Kk: wU70GYa1jm3Kk = PAztbuyYo4Kvd.findall('data-value=\\"(.*?)\\">(.*?)<',CQtNwXGVAJ2y5nBY+'<',PAztbuyYo4Kvd.DOTALL)
			kvfOU7Tpz958QBqnIlaAePLys,title = wU70GYa1jm3Kk[0]
			if cS2NYw4xulqJgvzkMF: title = jPgzFLH1niJpE2r(title)
			if not m0YJ3feqUjD7: TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,nA5dhMRg6ENzsB0l1GwvH7aIr2,42,nA5dhMRg6ENzsB0l1GwvH7aIr2,'2','?category='+kvfOU7Tpz958QBqnIlaAePLys)
			else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,nA5dhMRg6ENzsB0l1GwvH7aIr2,42,nA5dhMRg6ENzsB0l1GwvH7aIr2,'2',m0YJ3feqUjD7+'&category='+kvfOU7Tpz958QBqnIlaAePLys)
	if level=='2':
		WWU7QJP2tyTRLIfDh0csxbkvX = WWU7QJP2tyTRLIfDh0csxbkvX['specialist']
		items = PAztbuyYo4Kvd.findall('value="(.*?)".*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for CA1wUkhLv4FeT87tqx,title in items:
			if cS2NYw4xulqJgvzkMF: title = jPgzFLH1niJpE2r(title)
			if not CA1wUkhLv4FeT87tqx: title = title = 'الجميع'
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,nA5dhMRg6ENzsB0l1GwvH7aIr2,42,nA5dhMRg6ENzsB0l1GwvH7aIr2,'3',m0YJ3feqUjD7+'&specialist='+CA1wUkhLv4FeT87tqx)
	elif level=='3':
		WWU7QJP2tyTRLIfDh0csxbkvX = WWU7QJP2tyTRLIfDh0csxbkvX['series']
		items = PAztbuyYo4Kvd.findall('value="(.*?)".*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for P1guOVJKRNn80L5sw427BS9FDbm,title in items:
			if cS2NYw4xulqJgvzkMF: title = jPgzFLH1niJpE2r(title)
			if not P1guOVJKRNn80L5sw427BS9FDbm: title = title = 'الجميع'
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,nA5dhMRg6ENzsB0l1GwvH7aIr2,42,nA5dhMRg6ENzsB0l1GwvH7aIr2,'4',m0YJ3feqUjD7+'&series='+P1guOVJKRNn80L5sw427BS9FDbm)
	elif level=='4':
		WWU7QJP2tyTRLIfDh0csxbkvX = WWU7QJP2tyTRLIfDh0csxbkvX['sort_video']
		items = PAztbuyYo4Kvd.findall('value="(.*?)".*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for sort,title in items:
			if not sort: continue
			if cS2NYw4xulqJgvzkMF: title = jPgzFLH1niJpE2r(title)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,nA5dhMRg6ENzsB0l1GwvH7aIr2,44,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1',m0YJ3feqUjD7+'&sort='+sort)
	return
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(m0YJ3feqUjD7,kmi4lE16XPF9sAKDTqVj):
	Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q = yytpn5rcDRKNaqPV3xhg9THswjv(m0YJ3feqUjD7,kmi4lE16XPF9sAKDTqVj)
	WWU7QJP2tyTRLIfDh0csxbkvX = Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q['template']
	items = PAztbuyYo4Kvd.findall('src="(.*?)".*?href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for HRlygv7YwjzbSLt8fkEerq2,ZylHkumQ8zD0,title in items:
		if cS2NYw4xulqJgvzkMF: title = jPgzFLH1niJpE2r(title)
		TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,43,HRlygv7YwjzbSLt8fkEerq2)
	WWU7QJP2tyTRLIfDh0csxbkvX = Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q['facets']['pagination']
	items = PAztbuyYo4Kvd.findall('data-page="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for Q0f7ytucSriRw8HTzd,title in items:
		if kmi4lE16XPF9sAKDTqVj==Q0f7ytucSriRw8HTzd: continue
		if cS2NYw4xulqJgvzkMF: title = jPgzFLH1niJpE2r(title)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+title,nA5dhMRg6ENzsB0l1GwvH7aIr2,44,nA5dhMRg6ENzsB0l1GwvH7aIr2,Q0f7ytucSriRw8HTzd,m0YJ3feqUjD7)
	return
def lNBcUr8RCn(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ALMAAREF-PLAY-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	ZylHkumQ8zD0 = PAztbuyYo4Kvd.findall('<video src="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if not ZylHkumQ8zD0: ZylHkumQ8zD0 = PAztbuyYo4Kvd.findall('youtube_url.*?(http.*?)&',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	HtT6mBGwMaq1o0rybzZ4 = []
	if ZylHkumQ8zD0:
		ZylHkumQ8zD0 = ZylHkumQ8zD0[0].replace('\/','/')
		HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0)
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(HtT6mBGwMaq1o0rybzZ4,wgj0rX5tbcxPulhmny,'video',url)
	return
def g3Vrp8uHOcdnY7t():
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',GiqvpBF9xLEdHDr37byJSngeCQ+'/بث-مباشر',nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ALMAAREF-LIVE-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	url = PAztbuyYo4Kvd.findall('"svpPlayer".*?(http.*?)&',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	url = url[0].replace('\\',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	ocUnzjShqIO35vZi8bk64pVKMCTBaw(url,wgj0rX5tbcxPulhmny,'live')
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	SCiyqtWAN9FgPmsOfV = False
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2:
		search = FaUBpzTGxtS7hZyl()
		SCiyqtWAN9FgPmsOfV = True
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	if not SCiyqtWAN9FgPmsOfV: LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD('?search='+search,'1')
	else: jkWtiP0DG76AabE('?search='+search,'1')
	return
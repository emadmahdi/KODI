# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'MOVS4U'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_M4U_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
SAsGubf1jW2Q3p = ['انواع افلام','جودات افلام']
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==380: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==381: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,text)
	elif mode==382: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==383: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LLabVp7hzj28CE0f1udx(url)
	elif mode==389: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,389,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'المميزة',GiqvpBF9xLEdHDr37byJSngeCQ,381,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'featured')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجانبية',GiqvpBF9xLEdHDr37byJSngeCQ,381,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'sider')
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'MOVS4U-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	items = PAztbuyYo4Kvd.findall('<header>.*?<h2>(.*?)<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	for XXJAOcyjfEhSxC in range(len(items)):
		title = items[XXJAOcyjfEhSxC]
		TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,GiqvpBF9xLEdHDr37byJSngeCQ,381,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'latest'+str(XXJAOcyjfEhSxC))
	WWU7QJP2tyTRLIfDh0csxbkvX = nA5dhMRg6ENzsB0l1GwvH7aIr2
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="menu"(.*?)id="contenedor"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug: WWU7QJP2tyTRLIfDh0csxbkvX += zz3eHskxE6lAyDR5cNj1ug[0]
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="sidebar(.*?)aside',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug: WWU7QJP2tyTRLIfDh0csxbkvX += zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	gtazKNuwmbOV5Rs3Q = True
	for ZylHkumQ8zD0,title in items:
		title = HH8SJuswDBPtniebmkXIr(title)
		if title=='الأعلى مشاهدة':
			if gtazKNuwmbOV5Rs3Q:
				title = 'الافلام '+title
				gtazKNuwmbOV5Rs3Q = False
			else: title = 'المسلسلات '+title
		if title not in SAsGubf1jW2Q3p:
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,381)
	return kl2ZWdy8rXcHT
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,type):
	WWU7QJP2tyTRLIfDh0csxbkvX,items = [],[]
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'MOVS4U-TITLES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	if type=='search':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="search-page"(.*?)class="sidebar',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	elif type=='sider':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="widget(.*?)class="widget',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		Tdn9JQaSf3gi = PAztbuyYo4Kvd.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		ce9zAaVFswSq6lLr82DfQyotGW,A7cIH0dQfVkM3Uxs14O9nGtoN,ecU4Hy7lNS = zip(*Tdn9JQaSf3gi)
		items = zip(A7cIH0dQfVkM3Uxs14O9nGtoN,ce9zAaVFswSq6lLr82DfQyotGW,ecU4Hy7lNS)
	elif type=='featured':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('id="slider-movies-tvshows"(.*?)<header>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	elif 'latest' in type:
		XXJAOcyjfEhSxC = int(type[-1:])
		kl2ZWdy8rXcHT = kl2ZWdy8rXcHT.replace('<header>','<end><start>')
		kl2ZWdy8rXcHT = kl2ZWdy8rXcHT.replace('<div class="sidebar','<end><div class="sidebar')
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('<start>(.*?)<end>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[XXJAOcyjfEhSxC]
		if XXJAOcyjfEhSxC==2: items = PAztbuyYo4Kvd.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	else:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="content"(.*?)class="(pagination|sidebar)',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0][0]
			if '/collection/' in url:
				items = PAztbuyYo4Kvd.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			elif '/quality/' in url:
				items = PAztbuyYo4Kvd.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	if not items and WWU7QJP2tyTRLIfDh0csxbkvX:
		items = PAztbuyYo4Kvd.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	u0UiTmzYN6I3Q9eCZVoB = []
	for HRlygv7YwjzbSLt8fkEerq2,ZylHkumQ8zD0,title in items:
		if 'serie' in title:
			title = PAztbuyYo4Kvd.findall('^(.*?)<.*?serie">(.*?)<',title,PAztbuyYo4Kvd.DOTALL)
			title = title[0][1]
			if title in u0UiTmzYN6I3Q9eCZVoB: continue
			u0UiTmzYN6I3Q9eCZVoB.append(title)
			title = '_MOD_'+title
		g7qwMTAPoVpIyQUaDeNOnhvs = PAztbuyYo4Kvd.findall('^(.*?)<',title,PAztbuyYo4Kvd.DOTALL)
		if g7qwMTAPoVpIyQUaDeNOnhvs: title = g7qwMTAPoVpIyQUaDeNOnhvs[0]
		title = HH8SJuswDBPtniebmkXIr(title)
		if '/tvshows/' in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,383,HRlygv7YwjzbSLt8fkEerq2)
		elif '/episodes/' in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,383,HRlygv7YwjzbSLt8fkEerq2)
		elif '/seasons/' in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,383,HRlygv7YwjzbSLt8fkEerq2)
		elif '/collection/' in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,381,HRlygv7YwjzbSLt8fkEerq2)
		else: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,382,HRlygv7YwjzbSLt8fkEerq2)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		qZnPtTj18YNwaL742dIG = zz3eHskxE6lAyDR5cNj1ug[0][0]
		Fhc5uNOlnDI1rAQ = zz3eHskxE6lAyDR5cNj1ug[0][1]
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0][2]
		items = PAztbuyYo4Kvd.findall("href='(.*?)'.*?>(.*?)<",WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			if title==nA5dhMRg6ENzsB0l1GwvH7aIr2 or title==Fhc5uNOlnDI1rAQ: continue
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+title,ZylHkumQ8zD0,381,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,type)
		ZylHkumQ8zD0 = ZylHkumQ8zD0.replace('/page/'+title+'/','/page/'+Fhc5uNOlnDI1rAQ+'/')
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'اخر صفحة '+Fhc5uNOlnDI1rAQ,ZylHkumQ8zD0,381,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,type)
	return
def LLabVp7hzj28CE0f1udx(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'MOVS4U-EPISODES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	nR3YVtZDPs1IpAC = PAztbuyYo4Kvd.findall('class="C rated".*?>(.*?)<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if nR3YVtZDPs1IpAC and g4gUOtGiVkoNuaBrHhx8L(wgj0rX5tbcxPulhmny,url,nR3YVtZDPs1IpAC,False):
		TBt8bUDo9WhL('link',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'المسلسل للكبار والمبرمج منعه',nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		KteRnFMjHpBPqNf8 = PAztbuyYo4Kvd.findall('''class='item'><a href="(.*?)"''',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if KteRnFMjHpBPqNf8:
			KteRnFMjHpBPqNf8 = KteRnFMjHpBPqNf8[1]
			LLabVp7hzj28CE0f1udx(KteRnFMjHpBPqNf8)
			return
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('''class='episodios'(.*?)id="cast"''',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for HRlygv7YwjzbSLt8fkEerq2,JfNHOP2BK1Yxl7Rq4,ZylHkumQ8zD0,name in items:
			title = JfNHOP2BK1Yxl7Rq4+' : '+name+' الحلقة'
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,382)
	return
def lNBcUr8RCn(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'MOVS4U-PLAY-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	nR3YVtZDPs1IpAC = PAztbuyYo4Kvd.findall('class="C rated".*?>(.*?)<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if nR3YVtZDPs1IpAC and g4gUOtGiVkoNuaBrHhx8L(wgj0rX5tbcxPulhmny,url,nR3YVtZDPs1IpAC): return
	ce9zAaVFswSq6lLr82DfQyotGW = []
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0][0]
		items = PAztbuyYo4Kvd.findall("data-url='(.*?)'.*?class='server'>(.*?)<",WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named='+title+'__watch'
			ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="remodal"(.*?)class="remodal-close"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
			ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named='+title+'__download'
			ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(ce9zAaVFswSq6lLr82DfQyotGW,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	search = search.replace(hSXlxL9iB05c,'+')
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/?s='+search
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,'search')
	return
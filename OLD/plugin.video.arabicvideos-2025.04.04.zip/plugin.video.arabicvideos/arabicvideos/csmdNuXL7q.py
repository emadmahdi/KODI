# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'ALKAWTHAR'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_KWT_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,Q0f7ytucSriRw8HTzd,text):
	if   mode==130: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==131: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
	elif mode==132: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = c4cJvKylRSok1WCxnPVgLapErBFhHm(url)
	elif mode==133: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LLabVp7hzj28CE0f1udx(url,Q0f7ytucSriRw8HTzd)
	elif mode==134: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==135: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = g3Vrp8uHOcdnY7t()
	elif mode==139: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text,url)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,139,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,True,'ALKAWTHAR-MENU-1st')
	zz3eHskxE6lAyDR5cNj1ug=PAztbuyYo4Kvd.findall('dropdown-menu(.*?)dropdown-toggle',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[1]
	items=PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title in items:
		if '/conductor' in ZylHkumQ8zD0: continue
		title = title.strip(hSXlxL9iB05c)
		url = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
		if '/category/' in url: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,132)
		else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,131)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'المسلسلات',GiqvpBF9xLEdHDr37byJSngeCQ+'/category/543',132,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الأفلام',GiqvpBF9xLEdHDr37byJSngeCQ+'/category/628',132,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'برامج الصغار والشباب',GiqvpBF9xLEdHDr37byJSngeCQ+'/category/517',132,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'ابرز البرامج',GiqvpBF9xLEdHDr37byJSngeCQ+'/category/1763',132,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'المحاضرات',GiqvpBF9xLEdHDr37byJSngeCQ+'/category/943',132,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'عاشوراء',GiqvpBF9xLEdHDr37byJSngeCQ+'/category/1353',132,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'البرامج الاجتماعية',GiqvpBF9xLEdHDr37byJSngeCQ+'/category/501',132,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'البرامج الدينية',GiqvpBF9xLEdHDr37byJSngeCQ+'/category/509',132,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'البرامج الوثائقية',GiqvpBF9xLEdHDr37byJSngeCQ+'/category/553',132,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'البرامج السياسية',GiqvpBF9xLEdHDr37byJSngeCQ+'/category/545',132,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'كتب',GiqvpBF9xLEdHDr37byJSngeCQ+'/category/291',132,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'تعلم الفارسية',GiqvpBF9xLEdHDr37byJSngeCQ+'/category/88',132,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'أرشيف البرامج',GiqvpBF9xLEdHDr37byJSngeCQ+'/category/1279',132,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1')
	return
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url):
	iigMKSVwrus = ['/religious','/social','/political','/films','/series']
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,True,'ALKAWTHAR-TITLES-1st')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('titlebar(.*?)titlebar',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	if any(value in url for value in iigMKSVwrus):
		items = PAztbuyYo4Kvd.findall("src='(.*?)'.*?href='(.*?)'.*?>(.*?)<",WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for HRlygv7YwjzbSLt8fkEerq2,ZylHkumQ8zD0,title in items:
			title = title.strip(hSXlxL9iB05c)
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ + ZylHkumQ8zD0
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,133,HRlygv7YwjzbSLt8fkEerq2,'1')
	elif '/docs' in url:
		items = PAztbuyYo4Kvd.findall("src='(.*?)'.*?<h2>(.*?)</h2>.*?href='(.*?)'",WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for HRlygv7YwjzbSLt8fkEerq2,title,ZylHkumQ8zD0 in items:
			title = title.strip(hSXlxL9iB05c)
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ + ZylHkumQ8zD0
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,133,HRlygv7YwjzbSLt8fkEerq2,'1')
	return
def c4cJvKylRSok1WCxnPVgLapErBFhHm(url):
	kvfOU7Tpz958QBqnIlaAePLys = url.split('/')[-1]
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,True,'ALKAWTHAR-CATEGORIES-1st')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('parentcat(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if not zz3eHskxE6lAyDR5cNj1ug:
		LLabVp7hzj28CE0f1udx(url,'1')
		return
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall("href='(.*?)'.*?>(.*?)<",WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title in items:
		title = title.strip(hSXlxL9iB05c)
		ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ + ZylHkumQ8zD0
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,132,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1')
	return
def LLabVp7hzj28CE0f1udx(url,Q0f7ytucSriRw8HTzd):
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,True,'ALKAWTHAR-EPISODES-1st')
	items = PAztbuyYo4Kvd.findall('totalpagecount=[\'"](.*?)[\'"]',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if not items:
		url = PAztbuyYo4Kvd.findall('class="news-detail-body".*?href="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		url = url[0]
		title = '_MOD_' + 'ملف التشغيل'
		if url: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,134)
		else: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'لا يوجد حاليا ملفات فيديو في هذا الفرع')
		return
	CEaQOG7y63TB2eS0UfDbrq8 = int(items[0])
	name = PAztbuyYo4Kvd.findall('main-title.*?</a> >(.*?)<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if name: name = name[0].strip(hSXlxL9iB05c)
	else: name = SoNGUfhMDERLyHOz1qkVAj.getInfoLabel('ListItem.Label')
	if '/category/' in url or 'search?q=' in url:
		kvfOU7Tpz958QBqnIlaAePLys = url.split('/')[-1]
		if Q0f7ytucSriRw8HTzd==nA5dhMRg6ENzsB0l1GwvH7aIr2: KteRnFMjHpBPqNf8 = url
		else: KteRnFMjHpBPqNf8 = GiqvpBF9xLEdHDr37byJSngeCQ + '/category/' + kvfOU7Tpz958QBqnIlaAePLys + '/' + Q0f7ytucSriRw8HTzd
		v2u4dgJnek0sQDxKf = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,True,'ALKAWTHAR-EPISODES-2nd')
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('currentpagenumber(.*?)pagination',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL)
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('src="(.*?)".*?full(.*?)>.*?href="(.*?)".*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for HRlygv7YwjzbSLt8fkEerq2,type,ZylHkumQ8zD0,title in items:
			if 'video' not in type: continue
			if 'مسلسل' in title and 'حلقة' not in title: continue
			title = title.replace('\r\n',nA5dhMRg6ENzsB0l1GwvH7aIr2)
			title = title.strip(hSXlxL9iB05c)
			if 'مسلسل' in name and 'حلقة' in title and 'مسلسل' not in title:
				title = '_MOD_' + name + ' - ' + title
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ + ZylHkumQ8zD0
			if kvfOU7Tpz958QBqnIlaAePLys=='628': TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,133,HRlygv7YwjzbSLt8fkEerq2,'1')
			else: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,134,HRlygv7YwjzbSLt8fkEerq2)
	elif '/episode/' in url:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('playlist(.*?)col-md-12',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall("video-track-text.*?loadVideo\('(.*?)','(.*?)'.*?>(.*?)<",WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
				title = title.strip(hSXlxL9iB05c)
				TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,134,HRlygv7YwjzbSLt8fkEerq2)
		elif '/category/628' in kl2ZWdy8rXcHT:
				title = '_MOD_' + 'ملف التشغيل'
				TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,134)
		else:
			items = PAztbuyYo4Kvd.findall('id="Categories.*?href=\'(.*?)\'',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
			kvfOU7Tpz958QBqnIlaAePLys = items[0].split('/')[-1]
			url = GiqvpBF9xLEdHDr37byJSngeCQ + '/category/' + kvfOU7Tpz958QBqnIlaAePLys
			c4cJvKylRSok1WCxnPVgLapErBFhHm(url)
			return
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('pagination(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		ttGUd3eobkxwFrmI0hX = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in ttGUd3eobkxwFrmI0hX:
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
			ZylHkumQ8zD0 = ZylHkumQ8zD0.replace('&amp;','&')
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+title,ZylHkumQ8zD0,133)
	return
def lNBcUr8RCn(url):
	if '/news/' in url or '/episode/' in url:
		kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,True,'ALKAWTHAR-PLAY-1st')
		items = PAztbuyYo4Kvd.findall("mobilevideopath.*?value='(.*?)'",kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if items: url = items[0]
	ocUnzjShqIO35vZi8bk64pVKMCTBaw(url,wgj0rX5tbcxPulhmny,'video')
	return
def g3Vrp8uHOcdnY7t():
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/live'
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,True,'ALKAWTHAR-LIVE-1st')
	KteRnFMjHpBPqNf8 = PAztbuyYo4Kvd.findall('live-container.*?src="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	KteRnFMjHpBPqNf8 = KteRnFMjHpBPqNf8[0]
	LevQwm0pbqP1 = {'Referer':GiqvpBF9xLEdHDr37byJSngeCQ}
	YakdN895mSD2uXRCBfWspJhIxV3L = uANakQHcnhR(yy6RomT9bQhJf,'GET',KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,LevQwm0pbqP1,nA5dhMRg6ENzsB0l1GwvH7aIr2,True,'ALKAWTHAR-LIVE-2nd')
	v2u4dgJnek0sQDxKf = YakdN895mSD2uXRCBfWspJhIxV3L.content
	IXtUCDoBP4GlHz7kN = PAztbuyYo4Kvd.findall('csrf-token" content="(.*?)"',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL)
	IXtUCDoBP4GlHz7kN = IXtUCDoBP4GlHz7kN[0]
	ww7qni9WXLh1ezgByvo = C2gnJ5tXFk9pAL(KteRnFMjHpBPqNf8,'url')
	w7Ol6FnokgJDSsIt = PAztbuyYo4Kvd.findall("playUrl = '(.*?)'",v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL)
	w7Ol6FnokgJDSsIt = ww7qni9WXLh1ezgByvo+w7Ol6FnokgJDSsIt[0]
	vmiAf0lZHsLVbKUPJgRq5cDoxC2ae = {'X-CSRF-TOKEN':IXtUCDoBP4GlHz7kN}
	kvste1oOZacAIpb2 = uANakQHcnhR(yy6RomT9bQhJf,'POST',w7Ol6FnokgJDSsIt,nA5dhMRg6ENzsB0l1GwvH7aIr2,vmiAf0lZHsLVbKUPJgRq5cDoxC2ae,False,True,'ALKAWTHAR-LIVE-3rd')
	u3V46MOsz2DxtbdPBKFohZkHn = kvste1oOZacAIpb2.content
	mN3xi4TLMadDl10VHhOAbrXKjZB = PAztbuyYo4Kvd.findall('"(.*?)"',u3V46MOsz2DxtbdPBKFohZkHn,PAztbuyYo4Kvd.DOTALL)
	mN3xi4TLMadDl10VHhOAbrXKjZB = mN3xi4TLMadDl10VHhOAbrXKjZB[0].replace('\/','/')
	ocUnzjShqIO35vZi8bk64pVKMCTBaw(mN3xi4TLMadDl10VHhOAbrXKjZB,wgj0rX5tbcxPulhmny,'live')
	return
def WULrxiSjG3d1Cemza7Kc(search,url=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if url==nA5dhMRg6ENzsB0l1GwvH7aIr2:
		if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
		if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
		search = kGE6zoKSan54W(search)
		url = GiqvpBF9xLEdHDr37byJSngeCQ+'/search?q='+search
		LLabVp7hzj28CE0f1udx(url,nA5dhMRg6ENzsB0l1GwvH7aIr2)
		return
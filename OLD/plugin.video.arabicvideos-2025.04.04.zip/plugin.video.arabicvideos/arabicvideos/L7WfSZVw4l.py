# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'EGYBESTVIP'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_EGV_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,Q0f7ytucSriRw8HTzd,text):
	if   mode==220: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==221: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,Q0f7ytucSriRw8HTzd)
	elif mode==222: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = oWcvptkU2JObI0(url)
	elif mode==223: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==224: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = NNihMcqGKQEvLz6l(url)
	elif mode==229: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,229,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBEST-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="i i-home"(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)"(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,222)
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="ba(.*?)<script',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		for title,ZylHkumQ8zD0 in items:
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,221)
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			if 'html' not in ZylHkumQ8zD0: continue
			if not ZylHkumQ8zD0.endswith('/'): TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,221)
	return kl2ZWdy8rXcHT
def oWcvptkU2JObI0(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBESTVIP-SUBMENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="rs_scroll"(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('href="(.*?)".*?</i>(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title in items:
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,224)
	return
def NNihMcqGKQEvLz6l(url):
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع',url,221)
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBESTVIP-FILTERS_MENU-1st')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="sub_nav(.*?)id="movies',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".+?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			if ZylHkumQ8zD0=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,221)
	else: LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
	return
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,Q0f7ytucSriRw8HTzd='1'):
	if Q0f7ytucSriRw8HTzd==nA5dhMRg6ENzsB0l1GwvH7aIr2: Q0f7ytucSriRw8HTzd = '1'
	if '/search' in url or '?' in url: KteRnFMjHpBPqNf8 = url + '&'
	else: KteRnFMjHpBPqNf8 = url + '?'
	KteRnFMjHpBPqNf8 = KteRnFMjHpBPqNf8 + 'page=' + Q0f7ytucSriRw8HTzd
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		zz3eHskxE6lAyDR5cNj1ug=PAztbuyYo4Kvd.findall('class="pda"(.*?)div',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[-1]
	elif '/series/' in url:
		zz3eHskxE6lAyDR5cNj1ug=PAztbuyYo4Kvd.findall('class="owl-carousel owl-carousel(.*?)div',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	else:
		zz3eHskxE6lAyDR5cNj1ug=PAztbuyYo4Kvd.findall('id="movies(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[-1]
	items = PAztbuyYo4Kvd.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
		title = HH8SJuswDBPtniebmkXIr(title)
		if '/movie/' in ZylHkumQ8zD0 or '/episode' in ZylHkumQ8zD0:
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0.rstrip('/'),223,HRlygv7YwjzbSLt8fkEerq2)
		else:
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,221,HRlygv7YwjzbSLt8fkEerq2)
	if len(items)>=16:
		UcvQz5KGkLm = ['/movies','/tv','/search','/trending']
		Q0f7ytucSriRw8HTzd = int(Q0f7ytucSriRw8HTzd)
		if any(value in url for value in UcvQz5KGkLm):
			for ipmeLn4NDUCWgw in range(0,1000,100):
				if int(Q0f7ytucSriRw8HTzd/100)*100==ipmeLn4NDUCWgw:
					for q3kZpRe28O0s1NaCXQ9SMuGKin in range(ipmeLn4NDUCWgw,ipmeLn4NDUCWgw+100,10):
						if int(Q0f7ytucSriRw8HTzd/10)*10==q3kZpRe28O0s1NaCXQ9SMuGKin:
							for daRDcunZIqGyCpPgJ48WlHFB in range(q3kZpRe28O0s1NaCXQ9SMuGKin,q3kZpRe28O0s1NaCXQ9SMuGKin+10,1):
								if not Q0f7ytucSriRw8HTzd==daRDcunZIqGyCpPgJ48WlHFB and daRDcunZIqGyCpPgJ48WlHFB!=0:
									TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+str(daRDcunZIqGyCpPgJ48WlHFB),url,221,nA5dhMRg6ENzsB0l1GwvH7aIr2,str(daRDcunZIqGyCpPgJ48WlHFB))
						elif q3kZpRe28O0s1NaCXQ9SMuGKin!=0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+str(q3kZpRe28O0s1NaCXQ9SMuGKin),url,221,nA5dhMRg6ENzsB0l1GwvH7aIr2,str(q3kZpRe28O0s1NaCXQ9SMuGKin))
						else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+str(1),url,221,nA5dhMRg6ENzsB0l1GwvH7aIr2,str(1))
				elif ipmeLn4NDUCWgw!=0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+str(ipmeLn4NDUCWgw),url,221,nA5dhMRg6ENzsB0l1GwvH7aIr2,str(ipmeLn4NDUCWgw))
				else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+str(1),url,221)
	return
def lNBcUr8RCn(url):
	ecU4Hy7lNS,ce9zAaVFswSq6lLr82DfQyotGW = [],[]
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBESTVIP-PLAY-1st')
	nR3YVtZDPs1IpAC = PAztbuyYo4Kvd.findall('<td>التصنيف</td>.*?">(.*?)<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if nR3YVtZDPs1IpAC and g4gUOtGiVkoNuaBrHhx8L(wgj0rX5tbcxPulhmny,url,nR3YVtZDPs1IpAC): return
	s1GTeX8VlcUJ7Mp4d0gQa,qdPSy3N9uYRcj8roBJlMmHWDUKeEfi = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	JvUrdB6cSb5zaytpq1s4nfwYmo,Yoab1B67gDVyC = kl2ZWdy8rXcHT,kl2ZWdy8rXcHT
	ha4nC1rEkmfZ = PAztbuyYo4Kvd.findall('show_dl api" href="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if ha4nC1rEkmfZ:
		for ZylHkumQ8zD0 in ha4nC1rEkmfZ:
			if '/watch/' in ZylHkumQ8zD0: s1GTeX8VlcUJ7Mp4d0gQa = ZylHkumQ8zD0
			elif '/download/' in ZylHkumQ8zD0: qdPSy3N9uYRcj8roBJlMmHWDUKeEfi = ZylHkumQ8zD0
		if s1GTeX8VlcUJ7Mp4d0gQa!=nA5dhMRg6ENzsB0l1GwvH7aIr2: JvUrdB6cSb5zaytpq1s4nfwYmo = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,s1GTeX8VlcUJ7Mp4d0gQa,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBESTVIP-PLAY-2nd')
		if qdPSy3N9uYRcj8roBJlMmHWDUKeEfi!=nA5dhMRg6ENzsB0l1GwvH7aIr2: Yoab1B67gDVyC = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,qdPSy3N9uYRcj8roBJlMmHWDUKeEfi,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBESTVIP-PLAY-3rd')
	zX03abkJgLiW1oEGwn = PAztbuyYo4Kvd.findall('id="video".*?data-src="(.*?)"',JvUrdB6cSb5zaytpq1s4nfwYmo,PAztbuyYo4Kvd.DOTALL)
	if zX03abkJgLiW1oEGwn:
		KteRnFMjHpBPqNf8 = zX03abkJgLiW1oEGwn[0]
		if KteRnFMjHpBPqNf8!=nA5dhMRg6ENzsB0l1GwvH7aIr2 and 'uploaded.egybest.download' in KteRnFMjHpBPqNf8 and '/?id=_' not in KteRnFMjHpBPqNf8:
			v2u4dgJnek0sQDxKf = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBESTVIP-PLAY-4th')
			IzKeutHWrQA1aiV9p = PAztbuyYo4Kvd.findall('source src="(.*?)" title="(.*?)"',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL)
			if IzKeutHWrQA1aiV9p:
				for ZylHkumQ8zD0,OzWg1yEQG8wtvJ4x2ic9aKedFAPD in IzKeutHWrQA1aiV9p:
					ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0+'?named=ed.egybest.do__watch__mp4__'+OzWg1yEQG8wtvJ4x2ic9aKedFAPD)
			else:
				DQ7XgFltujVL = KteRnFMjHpBPqNf8.split('/')[2]
				ce9zAaVFswSq6lLr82DfQyotGW.append(KteRnFMjHpBPqNf8+'?named='+DQ7XgFltujVL+'__watch')
		elif KteRnFMjHpBPqNf8!=nA5dhMRg6ENzsB0l1GwvH7aIr2:
			DQ7XgFltujVL = KteRnFMjHpBPqNf8.split('/')[2]
			ce9zAaVFswSq6lLr82DfQyotGW.append(KteRnFMjHpBPqNf8+'?named='+DQ7XgFltujVL+'__watch')
	a1uTYhi8pt79ZWXwHlynJIfxAOQmdk = PAztbuyYo4Kvd.findall('<table class="dls_table(.*?)</table>',Yoab1B67gDVyC,PAztbuyYo4Kvd.DOTALL)
	if a1uTYhi8pt79ZWXwHlynJIfxAOQmdk:
		a1uTYhi8pt79ZWXwHlynJIfxAOQmdk = a1uTYhi8pt79ZWXwHlynJIfxAOQmdk[0]
		CCZSzMG8loF = PAztbuyYo4Kvd.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',a1uTYhi8pt79ZWXwHlynJIfxAOQmdk,PAztbuyYo4Kvd.DOTALL)
		if CCZSzMG8loF:
			for OzWg1yEQG8wtvJ4x2ic9aKedFAPD,ZylHkumQ8zD0 in CCZSzMG8loF:
				if 'myegyvip' not in ZylHkumQ8zD0: continue
				if ZylHkumQ8zD0.count('/')>=2:
					DQ7XgFltujVL = ZylHkumQ8zD0.split('/')[2]
					ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0+'?named='+DQ7XgFltujVL+'__download__mp4__'+OzWg1yEQG8wtvJ4x2ic9aKedFAPD)
	tD8imP0HBbe = []
	for ZylHkumQ8zD0 in ce9zAaVFswSq6lLr82DfQyotGW:
		tD8imP0HBbe.append(ZylHkumQ8zD0)
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(tD8imP0HBbe,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	SEGtTsCyUVi0lo4LJkH5 = search.replace(hSXlxL9iB05c,'+')
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(lPsYQwWdLO520ZHcFV8n1x,GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBESTVIP-SEARCH-1st')
	IXtUCDoBP4GlHz7kN = PAztbuyYo4Kvd.findall('name="_token" value="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if IXtUCDoBP4GlHz7kN:
		url = GiqvpBF9xLEdHDr37byJSngeCQ+'/search?_token='+IXtUCDoBP4GlHz7kN[0]+'&q='+SEGtTsCyUVi0lo4LJkH5
		LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
	return
# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'CIMAFANS'
headers = { 'User-Agent' : nA5dhMRg6ENzsB0l1GwvH7aIr2 }
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_CMF_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==90: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==91: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = qTPzY96jGk8mQcNK3XvVHMUR4(url)
	elif mode==92: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==94: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = CklyboIJDug75niLjhtmNU42fZs9ec()
	elif mode==95: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LLabVp7hzj28CE0f1udx(url)
	elif mode==99: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,99,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'المضاف حديثا',nA5dhMRg6ENzsB0l1GwvH7aIr2,94)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الأحدث',GiqvpBF9xLEdHDr37byJSngeCQ+'/?type=latest',91)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الأعلى تقيماً',GiqvpBF9xLEdHDr37byJSngeCQ+'/?type=imdb',91)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الأكثر مشاهدة',GiqvpBF9xLEdHDr37byJSngeCQ+'/?type=view',91)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'المثبت',GiqvpBF9xLEdHDr37byJSngeCQ+'/?type=pin',91)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'جديد الأفلام',GiqvpBF9xLEdHDr37byJSngeCQ+'/?type=newMovies',91)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'جديد الحلقات',GiqvpBF9xLEdHDr37byJSngeCQ+'/?type=newEpisodes',91)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMAFANS-MENU-1st')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="mainmenu(.*?)nav',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('<li><a href="(.*?)".*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	SAsGubf1jW2Q3p = ['افلام للكبار فقط']
	for ZylHkumQ8zD0,title in items:
		title = title.strip(hSXlxL9iB05c)
		if not any(value in title for value in SAsGubf1jW2Q3p):
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,91)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="f-cats"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('<li><a href="(.*?)".*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title in items:
		title = title.strip(hSXlxL9iB05c)
		if not any(value in title for value in SAsGubf1jW2Q3p):
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,91)
	return kl2ZWdy8rXcHT
def qTPzY96jGk8mQcNK3XvVHMUR4(url):
	if '/search.php' in url:
		url,search = url.split('?t=')
		headers = { 'User-Agent' : nA5dhMRg6ENzsB0l1GwvH7aIr2 , 'Content-Type' : 'application/x-www-form-urlencoded' }
		data = { 't' : search }
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'POST',url,data,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMAFANS-ITEMS-1st')
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	else:
		headers = { 'User-Agent' : nA5dhMRg6ENzsB0l1GwvH7aIr2 }
		kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMAFANS-ITEMS-2nd')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('id="movies-items(.*?)class="listfoot"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug: WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	else: WWU7QJP2tyTRLIfDh0csxbkvX = nA5dhMRg6ENzsB0l1GwvH7aIr2
	items = PAztbuyYo4Kvd.findall('background-image:url\((.*?)\).*?href="(.*?)".*?movie-title">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	u0UiTmzYN6I3Q9eCZVoB = []
	for HRlygv7YwjzbSLt8fkEerq2,ZylHkumQ8zD0,title in items:
		if 'الحلقة' in title and '/c/' not in url and '/cat/' not in url:
			JfNHOP2BK1Yxl7Rq4 = PAztbuyYo4Kvd.findall('(.*?) الحلقة [0-9]+',title,PAztbuyYo4Kvd.DOTALL)
			if JfNHOP2BK1Yxl7Rq4:
				title = '_MOD_'+JfNHOP2BK1Yxl7Rq4[0]
				if title not in u0UiTmzYN6I3Q9eCZVoB:
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,95,HRlygv7YwjzbSLt8fkEerq2)
					u0UiTmzYN6I3Q9eCZVoB.append(title)
		elif '/video/' in ZylHkumQ8zD0: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,92,HRlygv7YwjzbSLt8fkEerq2)
		else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,91,HRlygv7YwjzbSLt8fkEerq2)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="pagination(.*?)div',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('<a href="(.*?)".*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			title = HH8SJuswDBPtniebmkXIr(title)
			title = title.replace('الصفحة ',nA5dhMRg6ENzsB0l1GwvH7aIr2)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+title,ZylHkumQ8zD0,91)
	return
def LLabVp7hzj28CE0f1udx(url):
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMAFANS-EPISODES-1st')
	HRlygv7YwjzbSLt8fkEerq2 = PAztbuyYo4Kvd.findall('img src="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2[0]
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('id="episodes-panel(.*?)div',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		name = PAztbuyYo4Kvd.findall('itemprop="title">(.*?)<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if name: name = name[1]
		else:
			name = SoNGUfhMDERLyHOz1qkVAj.getInfoLabel('ListItem.Label')
			if NwROdSj3nsA in name: name = name.split(NwROdSj3nsA,1)[1]
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?name">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+name+' - '+title,ZylHkumQ8zD0,92,HRlygv7YwjzbSLt8fkEerq2)
	else:
		wU70GYa1jm3Kk = PAztbuyYo4Kvd.findall('class="movietitle"><a href="(.*?)">(.*?)<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if wU70GYa1jm3Kk: ZylHkumQ8zD0,title = wU70GYa1jm3Kk[0]
		else: ZylHkumQ8zD0,title = url,name
		TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,92,HRlygv7YwjzbSLt8fkEerq2)
	return
def lNBcUr8RCn(url):
	ce9zAaVFswSq6lLr82DfQyotGW,xxOQ92YRr8fz5PqvS = [],[]
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMAFANS-PLAY-1st')
	nR3YVtZDPs1IpAC = PAztbuyYo4Kvd.findall('text-shadow: none;">(.*?)<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if nR3YVtZDPs1IpAC and g4gUOtGiVkoNuaBrHhx8L(wgj0rX5tbcxPulhmny,url,nR3YVtZDPs1IpAC): return
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('id="links-panel(.*?)div',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0 in items:
			ZylHkumQ8zD0 = ZylHkumQ8zD0+'?__download'
			ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('nav-tabs"(.*?)video-panel-more',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('id="(.*?)".*?embed src="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for id,ZylHkumQ8zD0 in items:
			title = 'سيرفر '+id
			ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named='+title+'__watch'
			ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
		items = PAztbuyYo4Kvd.findall('data-server-src="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0 in items:
			if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = 'http:'+ZylHkumQ8zD0
			ZylHkumQ8zD0 = pvOytL0nF7JY6flXTxAcHbQeNahu3(ZylHkumQ8zD0)
			ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(ce9zAaVFswSq6lLr82DfQyotGW,wgj0rX5tbcxPulhmny,'video',url)
	return
def CklyboIJDug75niLjhtmNU42fZs9ec():
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMAFANS-LATEST-1st')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('id="index-last-movie(.*?)id="index-slider-movie',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('src="(.*?)".*?href="(.*?)" title="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for HRlygv7YwjzbSLt8fkEerq2,ZylHkumQ8zD0,title in items:
		if '/video/' in ZylHkumQ8zD0: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,92,HRlygv7YwjzbSLt8fkEerq2)
		else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,91,HRlygv7YwjzbSLt8fkEerq2)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	search = search.replace(hSXlxL9iB05c,'+')
	url = GiqvpBF9xLEdHDr37byJSngeCQ + '/search.php?t='+search
	qTPzY96jGk8mQcNK3XvVHMUR4(url)
	return
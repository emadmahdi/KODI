# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'WECIMA2'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_WC2_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
SAsGubf1jW2Q3p = ['مصارعة حرة','wwe']
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==1000: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==1001: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,text)
	elif mode==1002: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==1003: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LLabVp7hzj28CE0f1udx(url,text)
	elif mode==1004: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = NNihMcqGKQEvLz6l(url,'CATEGORIES___'+text)
	elif mode==1005: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = NNihMcqGKQEvLz6l(url,'FILTERS___'+text)
	elif mode==1006: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = oWcvptkU2JObI0(url)
	elif mode==1009: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text,url)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',GiqvpBF9xLEdHDr37byJSngeCQ,1009,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فلتر محدد',GiqvpBF9xLEdHDr37byJSngeCQ+'/AjaxCenter/RightBar',1004)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فلتر كامل',GiqvpBF9xLEdHDr37byJSngeCQ+'/AjaxCenter/RightBar',1005)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'WECIMA2-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="NavigationMenu"(.*?)class="ProductionsListButton"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('class="menu-item.*?href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			if title==nA5dhMRg6ENzsB0l1GwvH7aIr2: continue
			if any(value in title.lower() for value in SAsGubf1jW2Q3p): continue
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,1006)
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('hoverable activable(.*?)hoverable activable',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?url\((.*?)\).*?span>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,1006,HRlygv7YwjzbSLt8fkEerq2)
	return kl2ZWdy8rXcHT
def oWcvptkU2JObI0(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'WECIMA2-SUBMENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	if 'class="Slider--Grid"' in kl2ZWdy8rXcHT:
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'المميزة',url,1001,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'featured')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="list--Tabsui"(.*?)div',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?i>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,1001)
	return
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(wJojUny9Wp5INatB4eqikHVc,type=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if '::' in wJojUny9Wp5INatB4eqikHVc:
		w7Ol6FnokgJDSsIt,url = wJojUny9Wp5INatB4eqikHVc.split('::')
		DQ7XgFltujVL = C2gnJ5tXFk9pAL(w7Ol6FnokgJDSsIt,'url')
		url = DQ7XgFltujVL+url
	else: url,w7Ol6FnokgJDSsIt = wJojUny9Wp5INatB4eqikHVc,wJojUny9Wp5INatB4eqikHVc
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'WECIMA2-TITLES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	if type=='featured':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="Slider--Grid"(.*?)class="list--Tabsui"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	elif type in ['filters','search']:
		zz3eHskxE6lAyDR5cNj1ug = [kl2ZWdy8rXcHT.replace('\\/','/').replace('\\"','"')]
	else:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"Grid--WecimaPosts"(.*?)"RightUI"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	u0UiTmzYN6I3Q9eCZVoB = []
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('"Thumb--GridItem".*?href="(.*?)" title="(.*?)".*?url\((.*?)\)',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title,HRlygv7YwjzbSLt8fkEerq2 in items:
			if any(value in title.lower() for value in SAsGubf1jW2Q3p): continue
			HRlygv7YwjzbSLt8fkEerq2 = jPgzFLH1niJpE2r(HRlygv7YwjzbSLt8fkEerq2)
			ZylHkumQ8zD0 = jPgzFLH1niJpE2r(ZylHkumQ8zD0)
			title = HH8SJuswDBPtniebmkXIr(title)
			title = jPgzFLH1niJpE2r(title)
			title = title.replace('مشاهدة ',nA5dhMRg6ENzsB0l1GwvH7aIr2)
			if '/series/' in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,1003,HRlygv7YwjzbSLt8fkEerq2)
			elif 'حلقة' in title:
				JfNHOP2BK1Yxl7Rq4 = PAztbuyYo4Kvd.findall('(.*?) +حلقة +\d+',title,PAztbuyYo4Kvd.DOTALL)
				if JfNHOP2BK1Yxl7Rq4: title = '_MOD_' + JfNHOP2BK1Yxl7Rq4[0]
				if title not in u0UiTmzYN6I3Q9eCZVoB:
					u0UiTmzYN6I3Q9eCZVoB.append(title)
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,1003,HRlygv7YwjzbSLt8fkEerq2)
			else:
				TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,1002,HRlygv7YwjzbSLt8fkEerq2)
		if type=='filters':
			D7XvWdzLEB2SNCb5eHuPx41G3Qs9o = PAztbuyYo4Kvd.findall('"more_button_page":(.*?),',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			if D7XvWdzLEB2SNCb5eHuPx41G3Qs9o:
				count = D7XvWdzLEB2SNCb5eHuPx41G3Qs9o[0]
				ZylHkumQ8zD0 = url+'/offset/'+count
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة أخرى',ZylHkumQ8zD0,1001,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filters')
		elif type==nA5dhMRg6ENzsB0l1GwvH7aIr2:
			zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="pagination(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
			if zz3eHskxE6lAyDR5cNj1ug:
				WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
				items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
				for ZylHkumQ8zD0,title in items:
					if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
					title = 'صفحة '+HH8SJuswDBPtniebmkXIr(title)
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,1001)
	return
def LLabVp7hzj28CE0f1udx(url,data=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if data:
		data = BwGPDSQOlfUas2n3eIH0ycFRWZ('dict',data)
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'POST',url,data,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'WECIMA2-EPISODES-1st')
	else: Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'WECIMA2-EPISODES-2nd')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	kl2ZWdy8rXcHT = pvOytL0nF7JY6flXTxAcHbQeNahu3(kl2ZWdy8rXcHT)
	name = PAztbuyYo4Kvd.findall('itemprop="item" href=".*?/series/(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if name: name = name[-1].replace('-',hSXlxL9iB05c).strip(hSXlxL9iB05c)
	else: name = nA5dhMRg6ENzsB0l1GwvH7aIr2
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="Seasons--Episodes"(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if not data and zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('data-id="(.*?)" data-season="(.*?)">(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if len(items)>1:
			for FPAhgMwOp1YSLN,nny5eSkLVacWBT,title in items:
				title = title.replace(sSBzjZdcbQraNx,nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c)
				if name: title += ' - '+name
				ZylHkumQ8zD0 = 'https://wecima.click/ajax/Episode'
				rA4ZGoQyIHlneVfzNukWd = {'season':nny5eSkLVacWBT,'post_id':FPAhgMwOp1YSLN}
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,1003,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,str(rA4ZGoQyIHlneVfzNukWd))
			return
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="Episodes--Seasons--Episodes(.*?)</singlesections>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0] if zz3eHskxE6lAyDR5cNj1ug else kl2ZWdy8rXcHT
	items = PAztbuyYo4Kvd.findall('href="(.*?)".*?<episodeTitle>(.*?)</episodeTitle>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL|PAztbuyYo4Kvd.IGNORECASE)
	for ZylHkumQ8zD0,title in items:
		title = title.replace(sSBzjZdcbQraNx,nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c)
		if name: title += ' - '+name
		TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,1002)
	return
def eCHqPrm2sfNa051OuWonwEG(MNSnz3UkBIl2dGKj):
	kF7hBx2jnXEHYRf5G = ((4-len(MNSnz3UkBIl2dGKj)%4)%4)*'='
	a4H16YGuzIWb8 = MNSnz3UkBIl2dGKj.replace('+',nA5dhMRg6ENzsB0l1GwvH7aIr2)+kF7hBx2jnXEHYRf5G
	if a4H16YGuzIWb8[:3] in ['HM6','Dov']: a4H16YGuzIWb8 = 'aHR0c'+a4H16YGuzIWb8
	eynrmMaDtViU = Ic92Lb6lnzM5KJsx4Y3UGa70imZo.b64decode(a4H16YGuzIWb8)
	MGpboSE764kjBq8ig59XU = eynrmMaDtViU.decode(YWEQ3Cf8RevpD0m7NjF1)
	if cS2NYw4xulqJgvzkMF: MGpboSE764kjBq8ig59XU = MGpboSE764kjBq8ig59XU.encode(YWEQ3Cf8RevpD0m7NjF1)
	return MGpboSE764kjBq8ig59XU
def lNBcUr8RCn(url):
	ce9zAaVFswSq6lLr82DfQyotGW = []
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'WECIMA2-PLAY-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	nR3YVtZDPs1IpAC = PAztbuyYo4Kvd.findall('<span>التصنيف<.*?<a.*?">(.*?)<.*?">(.*?)<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if nR3YVtZDPs1IpAC:
		nR3YVtZDPs1IpAC = [nR3YVtZDPs1IpAC[0][0],nR3YVtZDPs1IpAC[0][1]]
		if nR3YVtZDPs1IpAC and g4gUOtGiVkoNuaBrHhx8L(wgj0rX5tbcxPulhmny,url,nR3YVtZDPs1IpAC): return
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="WatchServersList"(.*?)class="WatchServersEmbed"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('data-url="(.*?)".*?strong>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,name in items:
			ZylHkumQ8zD0 = eCHqPrm2sfNa051OuWonwEG(ZylHkumQ8zD0)
			if name=='سيرفر وي سيما': name = 'wecima'
			ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named='+name+'__watch'
			ZylHkumQ8zD0 = ZylHkumQ8zD0.replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(sSBzjZdcbQraNx,nA5dhMRg6ENzsB0l1GwvH7aIr2)
			ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="List--Download.*?</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?</i>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,OzWg1yEQG8wtvJ4x2ic9aKedFAPD in items:
			ZylHkumQ8zD0 = eCHqPrm2sfNa051OuWonwEG(ZylHkumQ8zD0)
			OzWg1yEQG8wtvJ4x2ic9aKedFAPD = PAztbuyYo4Kvd.findall('\d\d\d+',OzWg1yEQG8wtvJ4x2ic9aKedFAPD,PAztbuyYo4Kvd.DOTALL)
			if OzWg1yEQG8wtvJ4x2ic9aKedFAPD: OzWg1yEQG8wtvJ4x2ic9aKedFAPD = '____'+OzWg1yEQG8wtvJ4x2ic9aKedFAPD[0]
			else: OzWg1yEQG8wtvJ4x2ic9aKedFAPD = nA5dhMRg6ENzsB0l1GwvH7aIr2
			ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named=wecima'+'__download'+OzWg1yEQG8wtvJ4x2ic9aKedFAPD
			ZylHkumQ8zD0 = ZylHkumQ8zD0.replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(sSBzjZdcbQraNx,nA5dhMRg6ENzsB0l1GwvH7aIr2)
			ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(ce9zAaVFswSq6lLr82DfQyotGW,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search,xycejnJHQawud3okbfstlr=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	search = search.replace(hSXlxL9iB05c,'+')
	if not xycejnJHQawud3okbfstlr:
		xycejnJHQawud3okbfstlr = GiqvpBF9xLEdHDr37byJSngeCQ
	KteRnFMjHpBPqNf8 = xycejnJHQawud3okbfstlr+'/AjaxCenter/Searching/'+search+'/'
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(KteRnFMjHpBPqNf8,'search')
	return
def NNihMcqGKQEvLz6l(wJojUny9Wp5INatB4eqikHVc,filter):
	if '??' in wJojUny9Wp5INatB4eqikHVc: url = wJojUny9Wp5INatB4eqikHVc.split('//getposts??')[0]
	else: url = wJojUny9Wp5INatB4eqikHVc
	filter = filter.replace('_FORGETRESULTS_',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	type,filter = filter.split('___',1)
	if filter==nA5dhMRg6ENzsB0l1GwvH7aIr2: vvXcyZhkfV,guikd57yRSCMsNmlUqFHWAYL = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	else: vvXcyZhkfV,guikd57yRSCMsNmlUqFHWAYL = filter.split('___')
	if type=='CATEGORIES':
		if j1Jk78D9ezVwrbKCWxPfEQvUyO65GF[0]+'==' not in vvXcyZhkfV: kvfOU7Tpz958QBqnIlaAePLys = j1Jk78D9ezVwrbKCWxPfEQvUyO65GF[0]
		for q3kZpRe28O0s1NaCXQ9SMuGKin in range(len(j1Jk78D9ezVwrbKCWxPfEQvUyO65GF[0:-1])):
			if j1Jk78D9ezVwrbKCWxPfEQvUyO65GF[q3kZpRe28O0s1NaCXQ9SMuGKin]+'==' in vvXcyZhkfV: kvfOU7Tpz958QBqnIlaAePLys = j1Jk78D9ezVwrbKCWxPfEQvUyO65GF[q3kZpRe28O0s1NaCXQ9SMuGKin+1]
		FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&&'+kvfOU7Tpz958QBqnIlaAePLys+'==0'
		QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&&'+kvfOU7Tpz958QBqnIlaAePLys+'==0'
		TB6HLPpacsK8f034jvYx7SNgFd = FqCItdu32L9hNwcEXWoges4R68KS.strip('&&')+'___'+QA6C8r4lEdhemfJPRc.strip('&&')
		OQmDdTI7hU4Lv3BfexPVKgRF8YN = EdpkojMzLm6b3ZSVcXwi0CPRIH(guikd57yRSCMsNmlUqFHWAYL,'modified_filters')
		KteRnFMjHpBPqNf8 = url+'//getposts??'+OQmDdTI7hU4Lv3BfexPVKgRF8YN
	elif type=='FILTERS':
		iEa2qGQctFxX = EdpkojMzLm6b3ZSVcXwi0CPRIH(vvXcyZhkfV,'modified_values')
		iEa2qGQctFxX = pvOytL0nF7JY6flXTxAcHbQeNahu3(iEa2qGQctFxX)
		if guikd57yRSCMsNmlUqFHWAYL!=nA5dhMRg6ENzsB0l1GwvH7aIr2: guikd57yRSCMsNmlUqFHWAYL = EdpkojMzLm6b3ZSVcXwi0CPRIH(guikd57yRSCMsNmlUqFHWAYL,'modified_filters')
		if guikd57yRSCMsNmlUqFHWAYL==nA5dhMRg6ENzsB0l1GwvH7aIr2: KteRnFMjHpBPqNf8 = url
		else: KteRnFMjHpBPqNf8 = url+'//getposts??'+guikd57yRSCMsNmlUqFHWAYL
		mN3xi4TLMadDl10VHhOAbrXKjZB = cTlIOYA7v4qU1k89iQe(KteRnFMjHpBPqNf8,wJojUny9Wp5INatB4eqikHVc)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'أظهار قائمة الفيديو التي تم اختيارها ',mN3xi4TLMadDl10VHhOAbrXKjZB,1001,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filters')
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+' [[   '+iEa2qGQctFxX+'   ]]',mN3xi4TLMadDl10VHhOAbrXKjZB,1001,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filters')
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'WECIMA2-FILTERS_MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	kl2ZWdy8rXcHT = kl2ZWdy8rXcHT.replace('\\"','"').replace('\\/','/')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('<wecima--filter(.*?)</wecima--filter>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if not zz3eHskxE6lAyDR5cNj1ug: return
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	AAkSjd9agcy = PAztbuyYo4Kvd.findall('taxonomy="(.*?)".*?<span>(.*?)<(.*?)<filterbox',WWU7QJP2tyTRLIfDh0csxbkvX+'<filterbox',PAztbuyYo4Kvd.DOTALL)
	dict = {}
	for xWwIXcK0L61EBgtn7smr,name,WWU7QJP2tyTRLIfDh0csxbkvX in AAkSjd9agcy:
		name = jPgzFLH1niJpE2r(name)
		if 'interest' in xWwIXcK0L61EBgtn7smr: continue
		items = PAztbuyYo4Kvd.findall('data-term="(.*?)".*?<txt>(.*?)</txt>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if '==' not in KteRnFMjHpBPqNf8: KteRnFMjHpBPqNf8 = url
		if type=='CATEGORIES':
			if kvfOU7Tpz958QBqnIlaAePLys!=xWwIXcK0L61EBgtn7smr: continue
			elif len(items)<=1:
				if xWwIXcK0L61EBgtn7smr==j1Jk78D9ezVwrbKCWxPfEQvUyO65GF[-1]: LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(KteRnFMjHpBPqNf8)
				else: NNihMcqGKQEvLz6l(KteRnFMjHpBPqNf8,'CATEGORIES___'+TB6HLPpacsK8f034jvYx7SNgFd)
				return
			else:
				mN3xi4TLMadDl10VHhOAbrXKjZB = cTlIOYA7v4qU1k89iQe(KteRnFMjHpBPqNf8,wJojUny9Wp5INatB4eqikHVc)
				if xWwIXcK0L61EBgtn7smr==j1Jk78D9ezVwrbKCWxPfEQvUyO65GF[-1]:
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع',mN3xi4TLMadDl10VHhOAbrXKjZB,1001,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filters')
				else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع',KteRnFMjHpBPqNf8,1004,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,TB6HLPpacsK8f034jvYx7SNgFd)
		elif type=='FILTERS':
			FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&&'+xWwIXcK0L61EBgtn7smr+'==0'
			QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&&'+xWwIXcK0L61EBgtn7smr+'==0'
			TB6HLPpacsK8f034jvYx7SNgFd = FqCItdu32L9hNwcEXWoges4R68KS+'___'+QA6C8r4lEdhemfJPRc
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+name+': الجميع',KteRnFMjHpBPqNf8,1005,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,TB6HLPpacsK8f034jvYx7SNgFd+'_FORGETRESULTS_')
		dict[xWwIXcK0L61EBgtn7smr] = {}
		for value,DOT0LXwgoHYkFBC4MbxN53 in items:
			name = jPgzFLH1niJpE2r(name)
			DOT0LXwgoHYkFBC4MbxN53 = jPgzFLH1niJpE2r(DOT0LXwgoHYkFBC4MbxN53)
			if value=='r' or value=='nc-17': continue
			if any(value in DOT0LXwgoHYkFBC4MbxN53.lower() for value in SAsGubf1jW2Q3p): continue
			if 'http' in DOT0LXwgoHYkFBC4MbxN53: continue
			if 'الكل' in DOT0LXwgoHYkFBC4MbxN53: continue
			if 'n-a' in value: continue
			if DOT0LXwgoHYkFBC4MbxN53==nA5dhMRg6ENzsB0l1GwvH7aIr2: DOT0LXwgoHYkFBC4MbxN53 = value
			lnFIuANWwQ = DOT0LXwgoHYkFBC4MbxN53
			CSziwD3bp1c9GWLakAB = PAztbuyYo4Kvd.findall('<name>(.*?)</name>',DOT0LXwgoHYkFBC4MbxN53,PAztbuyYo4Kvd.DOTALL)
			if CSziwD3bp1c9GWLakAB: lnFIuANWwQ = CSziwD3bp1c9GWLakAB[0]
			g7qwMTAPoVpIyQUaDeNOnhvs = name+': '+lnFIuANWwQ
			dict[xWwIXcK0L61EBgtn7smr][value] = g7qwMTAPoVpIyQUaDeNOnhvs
			FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&&'+xWwIXcK0L61EBgtn7smr+'=='+lnFIuANWwQ
			QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&&'+xWwIXcK0L61EBgtn7smr+'=='+value
			b97AdvPkWGEBe3ayj1Jhmcq2LVxr = FqCItdu32L9hNwcEXWoges4R68KS+'___'+QA6C8r4lEdhemfJPRc
			if type=='FILTERS':
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+g7qwMTAPoVpIyQUaDeNOnhvs,url,1005,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,b97AdvPkWGEBe3ayj1Jhmcq2LVxr+'_FORGETRESULTS_')
			elif type=='CATEGORIES' and j1Jk78D9ezVwrbKCWxPfEQvUyO65GF[-2]+'==' in vvXcyZhkfV:
				OQmDdTI7hU4Lv3BfexPVKgRF8YN = EdpkojMzLm6b3ZSVcXwi0CPRIH(QA6C8r4lEdhemfJPRc,'modified_filters')
				w7Ol6FnokgJDSsIt = url+'//getposts??'+OQmDdTI7hU4Lv3BfexPVKgRF8YN
				mN3xi4TLMadDl10VHhOAbrXKjZB = cTlIOYA7v4qU1k89iQe(w7Ol6FnokgJDSsIt,wJojUny9Wp5INatB4eqikHVc)
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+g7qwMTAPoVpIyQUaDeNOnhvs,mN3xi4TLMadDl10VHhOAbrXKjZB,1001,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filters')
			else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+g7qwMTAPoVpIyQUaDeNOnhvs,url,1004,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,b97AdvPkWGEBe3ayj1Jhmcq2LVxr)
	return
j1Jk78D9ezVwrbKCWxPfEQvUyO65GF = ['genre','release-year','nation']
rkTgCw98sH2JSAGRN0WiE = ['mpaa','genre','release-year','category','Quality','interest','nation','language']
def cTlIOYA7v4qU1k89iQe(KteRnFMjHpBPqNf8,w7Ol6FnokgJDSsIt):
	if '/AjaxCenter/RightBar' in KteRnFMjHpBPqNf8: KteRnFMjHpBPqNf8 = KteRnFMjHpBPqNf8.replace('/AjaxCenter/RightBar','/AjaxCenter/Filtering')
	KteRnFMjHpBPqNf8 = KteRnFMjHpBPqNf8.replace('//getposts??','::/AjaxCenter/Filtering/')
	KteRnFMjHpBPqNf8 = KteRnFMjHpBPqNf8.replace('==','/')
	KteRnFMjHpBPqNf8 = KteRnFMjHpBPqNf8.replace('&&','/')
	return KteRnFMjHpBPqNf8
def EdpkojMzLm6b3ZSVcXwi0CPRIH(tgsLX2uACmFhVznejRy6O,mode):
	tgsLX2uACmFhVznejRy6O = tgsLX2uACmFhVznejRy6O.strip('&&')
	bpoRYqt38j,H5ROYNwvQFkBiVElThr = {},nA5dhMRg6ENzsB0l1GwvH7aIr2
	if '==' in tgsLX2uACmFhVznejRy6O:
		items = tgsLX2uACmFhVznejRy6O.split('&&')
		for CQtNwXGVAJ2y5nBY in items:
			eehzynNs85aTHrgCUmFc3DBO12,value = CQtNwXGVAJ2y5nBY.split('==')
			bpoRYqt38j[eehzynNs85aTHrgCUmFc3DBO12] = value
	for key in rkTgCw98sH2JSAGRN0WiE:
		if key in list(bpoRYqt38j.keys()): value = bpoRYqt38j[key]
		else: value = '0'
		if '%' not in value: value = kGE6zoKSan54W(value)
		if mode=='modified_values' and value!='0': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+' + '+value
		elif mode=='modified_filters' and value!='0': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+'&&'+key+'=='+value
		elif mode=='all': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+'&&'+key+'=='+value
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.strip(' + ')
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.strip('&&')
	return H5ROYNwvQFkBiVElThr
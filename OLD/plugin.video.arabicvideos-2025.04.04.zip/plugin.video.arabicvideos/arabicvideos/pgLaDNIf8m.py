# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'EGYBEST2'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_EB2_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
SAsGubf1jW2Q3p = ['المصارعة الحرة','ايجي بيست','عروض المصارعة','egybest','ايجي بست البديل','ايجى بست الجديد']
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,Q0f7ytucSriRw8HTzd,text):
	if   mode==780: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==781: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,Q0f7ytucSriRw8HTzd)
	elif mode==782: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = oWcvptkU2JObI0(url)
	elif mode==783: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==784: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = NNihMcqGKQEvLz6l(url,'FULL_FILTER___'+text)
	elif mode==785: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = NNihMcqGKQEvLz6l(url,'DEFINED_FILTER___'+text)
	elif mode==786: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = SNVTEdvxWujYnGR7J6hACUP(url,Q0f7ytucSriRw8HTzd)
	elif mode==789: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,789,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBEST2-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('list-pages(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?<span>(.*?)</span>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			title = title.strip(hSXlxL9iB05c)
			if any(value in title for value in SAsGubf1jW2Q3p): continue
			if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,781)
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('main-article(.*?)social-box',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('main-title.*?">(.*?)<.*?href="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for title,ZylHkumQ8zD0 in items:
			title = title.strip(hSXlxL9iB05c)
			if any(value in title for value in SAsGubf1jW2Q3p): continue
			if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,781,nA5dhMRg6ENzsB0l1GwvH7aIr2,'mainmenu')
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('main-menu(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			title = title.strip(hSXlxL9iB05c)
			if any(value in title for value in SAsGubf1jW2Q3p): continue
			if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,781)
	return
def SNVTEdvxWujYnGR7J6hACUP(url,type=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBEST2-SEASONS_EPISODES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('main-article".*?">(.*?)<(.*?)article',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		wWeVHSMqxGR,GGr9WlIhv1BKDJjTZFNty4R3k0dCOA,items = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,[]
		for name,WWU7QJP2tyTRLIfDh0csxbkvX in zz3eHskxE6lAyDR5cNj1ug:
			if 'حلقات' in name: GGr9WlIhv1BKDJjTZFNty4R3k0dCOA = WWU7QJP2tyTRLIfDh0csxbkvX
			if 'مواسم' in name: wWeVHSMqxGR = WWU7QJP2tyTRLIfDh0csxbkvX
		if wWeVHSMqxGR and not type:
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',wWeVHSMqxGR,PAztbuyYo4Kvd.DOTALL)
			if len(items)>1:
				for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,786,HRlygv7YwjzbSLt8fkEerq2,'season')
		if GGr9WlIhv1BKDJjTZFNty4R3k0dCOA and len(items)<2:
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?data-src="(.*?)".*?title="(.*?)"',GGr9WlIhv1BKDJjTZFNty4R3k0dCOA,PAztbuyYo4Kvd.DOTALL)
			if items:
				for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
					TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,783,HRlygv7YwjzbSLt8fkEerq2)
			else:
				items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',GGr9WlIhv1BKDJjTZFNty4R3k0dCOA,PAztbuyYo4Kvd.DOTALL)
				for ZylHkumQ8zD0,title in items:
					TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,783)
		else: LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,'episodes')
	return
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,type=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if 'pagination' in type or 'filter' in type:
		KteRnFMjHpBPqNf8,data = url.split('?separator&')
		headers = {'Content-Type':'application/x-www-form-urlencoded'}
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'POST',KteRnFMjHpBPqNf8,data,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBEST2-TITLES-1st')
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
		kl2ZWdy8rXcHT = 'blocks'+kl2ZWdy8rXcHT+'article'
	else:
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBEST2-TITLES-2nd')
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	items,ddoTyXHWlmDVAnEpzGwhxu7i,tgsLX2uACmFhVznejRy6O = [],False,False
	if not type:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('main-content(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?</i>(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,title in items:
				title = title.strip(hSXlxL9iB05c)
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,781,nA5dhMRg6ENzsB0l1GwvH7aIr2,'submenu')
				ddoTyXHWlmDVAnEpzGwhxu7i = True
	if not type:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('all-taxes(.*?)"load"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug and type!='filter':
			if ddoTyXHWlmDVAnEpzGwhxu7i: TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فلتر محدد',url,785,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filter')
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فلتر كامل',url,784,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filter')
			tgsLX2uACmFhVznejRy6O = True
	if (not ddoTyXHWlmDVAnEpzGwhxu7i and not tgsLX2uACmFhVznejRy6O) or type=='episodes':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('blocks(.*?)article',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			u0UiTmzYN6I3Q9eCZVoB = []
			for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
				HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2.strip(CXtugbqhV3)
				ZylHkumQ8zD0 = pvOytL0nF7JY6flXTxAcHbQeNahu3(ZylHkumQ8zD0)
				if '/selary/' in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,786,HRlygv7YwjzbSLt8fkEerq2)
				elif type=='episodes' or 'pagination' in type: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,783,HRlygv7YwjzbSLt8fkEerq2)
				elif 'حلقة' in title:
					JfNHOP2BK1Yxl7Rq4 = PAztbuyYo4Kvd.findall('(.*?) (الحلقة|حلقة).\d+',title,PAztbuyYo4Kvd.DOTALL)
					if JfNHOP2BK1Yxl7Rq4:
						title = '_MOD_'+JfNHOP2BK1Yxl7Rq4[0][0]
						if title not in u0UiTmzYN6I3Q9eCZVoB:
							TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,786,HRlygv7YwjzbSLt8fkEerq2)
							u0UiTmzYN6I3Q9eCZVoB.append(title)
				elif 'مسلسل' in ZylHkumQ8zD0 and 'حلقة' not in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,786,HRlygv7YwjzbSLt8fkEerq2)
				elif 'موسم' in ZylHkumQ8zD0 and 'حلقة' not in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,786,HRlygv7YwjzbSLt8fkEerq2)
				else: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,783,HRlygv7YwjzbSLt8fkEerq2)
		if 'search' in type: B0hfc9OtnWYbs1 = 12
		else: B0hfc9OtnWYbs1 = 16
		data = PAztbuyYo4Kvd.findall('class="(load-more.*?) .*?data-(.*?)="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if len(items)==B0hfc9OtnWYbs1 and (data or 'pagination' in type):
			if data:
				offset = B0hfc9OtnWYbs1
				xzPTbdUKmfL7ly8,name,value = data[0]
				xzPTbdUKmfL7ly8 = xzPTbdUKmfL7ly8.replace('load','get').replace('-','_').replace('"',nA5dhMRg6ENzsB0l1GwvH7aIr2)
			else:
				data = PAztbuyYo4Kvd.findall('action=(.*?)&offset=(.*?)&(.*?)=(.*?)$',url,PAztbuyYo4Kvd.DOTALL)
				if data: xzPTbdUKmfL7ly8,offset,name,value = data[0]
				offset = int(offset)+B0hfc9OtnWYbs1
			data = 'action='+xzPTbdUKmfL7ly8+'&offset='+str(offset)+'&'+name+'='+value
			url = GiqvpBF9xLEdHDr37byJSngeCQ+'/wp-admin/admin-ajax.php?separator&'+data
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'المزيد',url,781,nA5dhMRg6ENzsB0l1GwvH7aIr2,'pagination_'+type)
	return
def lNBcUr8RCn(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(yy6RomT9bQhJf,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBEST2-PLAY-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	HtT6mBGwMaq1o0rybzZ4,Co7gJfiXOmlN4VrbjhuknEH = [],[]
	items = PAztbuyYo4Kvd.findall('server-item.*?data-code="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	for UIA69Ri127rKyu in items:
		jjpcqDEgJHMbl9zr76AanS = Ic92Lb6lnzM5KJsx4Y3UGa70imZo.b64decode(UIA69Ri127rKyu)
		if BsLJ7p5Av2Vm0SQeCO1o: jjpcqDEgJHMbl9zr76AanS = jjpcqDEgJHMbl9zr76AanS.decode(YWEQ3Cf8RevpD0m7NjF1)
		ZylHkumQ8zD0 = PAztbuyYo4Kvd.findall('src="(.*?)"',jjpcqDEgJHMbl9zr76AanS,PAztbuyYo4Kvd.DOTALL)
		if ZylHkumQ8zD0:
			ZylHkumQ8zD0 = ZylHkumQ8zD0[0]
			if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = 'http:'+ZylHkumQ8zD0
			if ZylHkumQ8zD0 not in Co7gJfiXOmlN4VrbjhuknEH:
				Co7gJfiXOmlN4VrbjhuknEH.append(ZylHkumQ8zD0)
				DQ7XgFltujVL = C2gnJ5tXFk9pAL(ZylHkumQ8zD0,'name')
				HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0+'?named='+DQ7XgFltujVL+'__watch')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="downloads(.*?)</section>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('<div>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</div>.*?href=".*?download=(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for OzWg1yEQG8wtvJ4x2ic9aKedFAPD,UVwlEkejQMuGzS4IKT in items:
			ZylHkumQ8zD0 = Ic92Lb6lnzM5KJsx4Y3UGa70imZo.b64decode(UVwlEkejQMuGzS4IKT)
			if BsLJ7p5Av2Vm0SQeCO1o: ZylHkumQ8zD0 = ZylHkumQ8zD0.decode(YWEQ3Cf8RevpD0m7NjF1)
			if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = 'http:'+ZylHkumQ8zD0
			if ZylHkumQ8zD0 not in Co7gJfiXOmlN4VrbjhuknEH:
				Co7gJfiXOmlN4VrbjhuknEH.append(ZylHkumQ8zD0)
				DQ7XgFltujVL = C2gnJ5tXFk9pAL(ZylHkumQ8zD0,'name')
				HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0+'?named='+DQ7XgFltujVL+'__download____'+OzWg1yEQG8wtvJ4x2ic9aKedFAPD)
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(HtT6mBGwMaq1o0rybzZ4,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if not search: search = FaUBpzTGxtS7hZyl()
	if not search: return
	SEGtTsCyUVi0lo4LJkH5 = search.replace(hSXlxL9iB05c,'-')
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/find/?q='+SEGtTsCyUVi0lo4LJkH5
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,'search')
	return
def iBOFgUs6eTkIQyxKbqM(url):
	url = url.split('/smartemadfilter?')[0]
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBEST2-GET_FILTERS_BLOCKS-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	AAkSjd9agcy = []
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('main-article(.*?)article',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		AAkSjd9agcy = PAztbuyYo4Kvd.findall('data-tax="(.*?)".*?<span>(.*?)<(.*?)</ul>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		MFd17IQ58Unz,KDuQ6YkSCLPz5be7BqTAxhMXwgF,Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q = zip(*AAkSjd9agcy)
		AAkSjd9agcy = zip(KDuQ6YkSCLPz5be7BqTAxhMXwgF,MFd17IQ58Unz,Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q)
	return AAkSjd9agcy
def vPOwqQ5zYHc10DVaSmU2ysG8k4t(WWU7QJP2tyTRLIfDh0csxbkvX):
	items = PAztbuyYo4Kvd.findall('value="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	return items
def iCNd2ua6f9EHyBXWYMrKcR(url):
	if '/smartemadfilter' not in url: KteRnFMjHpBPqNf8,iiDg7KPJT4ASHLFp13I56fxGmUXyv = url,nA5dhMRg6ENzsB0l1GwvH7aIr2
	else: KteRnFMjHpBPqNf8,iiDg7KPJT4ASHLFp13I56fxGmUXyv = url.split('/smartemadfilter')
	w7Ol6FnokgJDSsIt,vAMi4B7Wab18HfyVXnIxe9Kdc = ss2VIkClmtevKqPUuSx9DGpX(iiDg7KPJT4ASHLFp13I56fxGmUXyv)
	B3jdHaRK46VM2 = nA5dhMRg6ENzsB0l1GwvH7aIr2
	for key in list(vAMi4B7Wab18HfyVXnIxe9Kdc.keys()):
		B3jdHaRK46VM2 += '&args%5B'+key+'%5D='+vAMi4B7Wab18HfyVXnIxe9Kdc[key]
	mN3xi4TLMadDl10VHhOAbrXKjZB = GiqvpBF9xLEdHDr37byJSngeCQ+'/wp-admin/admin-ajax.php?separator&action=get_filterd_blocks'+B3jdHaRK46VM2
	return mN3xi4TLMadDl10VHhOAbrXKjZB
cc0WqiHnzER = ['release-year','language','genre','nation','category','quality','resolution']
o7o2QXr0sG = ['release-year','language','genre']
def NNihMcqGKQEvLz6l(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==nA5dhMRg6ENzsB0l1GwvH7aIr2: vvXcyZhkfV,guikd57yRSCMsNmlUqFHWAYL = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	else: vvXcyZhkfV,guikd57yRSCMsNmlUqFHWAYL = filter.split('___')
	if type=='DEFINED_FILTER':
		if o7o2QXr0sG[0]+'=' not in vvXcyZhkfV: kvfOU7Tpz958QBqnIlaAePLys = o7o2QXr0sG[0]
		for q3kZpRe28O0s1NaCXQ9SMuGKin in range(len(o7o2QXr0sG[0:-1])):
			if o7o2QXr0sG[q3kZpRe28O0s1NaCXQ9SMuGKin]+'=' in vvXcyZhkfV: kvfOU7Tpz958QBqnIlaAePLys = o7o2QXr0sG[q3kZpRe28O0s1NaCXQ9SMuGKin+1]
		FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+kvfOU7Tpz958QBqnIlaAePLys+'=0'
		QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+kvfOU7Tpz958QBqnIlaAePLys+'=0'
		TB6HLPpacsK8f034jvYx7SNgFd = FqCItdu32L9hNwcEXWoges4R68KS.strip('&')+'___'+QA6C8r4lEdhemfJPRc.strip('&')
		OQmDdTI7hU4Lv3BfexPVKgRF8YN = EdpkojMzLm6b3ZSVcXwi0CPRIH(guikd57yRSCMsNmlUqFHWAYL,'modified_filters')
		KteRnFMjHpBPqNf8 = url+'/smartemadfilter?'+OQmDdTI7hU4Lv3BfexPVKgRF8YN
	elif type=='FULL_FILTER':
		iEa2qGQctFxX = EdpkojMzLm6b3ZSVcXwi0CPRIH(vvXcyZhkfV,'modified_values')
		iEa2qGQctFxX = pvOytL0nF7JY6flXTxAcHbQeNahu3(iEa2qGQctFxX)
		if guikd57yRSCMsNmlUqFHWAYL: guikd57yRSCMsNmlUqFHWAYL = EdpkojMzLm6b3ZSVcXwi0CPRIH(guikd57yRSCMsNmlUqFHWAYL,'modified_filters')
		if not guikd57yRSCMsNmlUqFHWAYL: KteRnFMjHpBPqNf8 = url
		else: KteRnFMjHpBPqNf8 = url+'/smartemadfilter?'+guikd57yRSCMsNmlUqFHWAYL
		w7Ol6FnokgJDSsIt = iCNd2ua6f9EHyBXWYMrKcR(KteRnFMjHpBPqNf8)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'أظهار قائمة الفيديو التي تم اختيارها ',w7Ol6FnokgJDSsIt,781,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filter')
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+' [[   '+iEa2qGQctFxX+'   ]]',w7Ol6FnokgJDSsIt,781,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filter')
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	AAkSjd9agcy = iBOFgUs6eTkIQyxKbqM(url)
	dict = {}
	for name,xWwIXcK0L61EBgtn7smr,WWU7QJP2tyTRLIfDh0csxbkvX in AAkSjd9agcy:
		name = name.replace('كل ',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		items = vPOwqQ5zYHc10DVaSmU2ysG8k4t(WWU7QJP2tyTRLIfDh0csxbkvX)
		if '=' not in KteRnFMjHpBPqNf8: KteRnFMjHpBPqNf8 = url
		if type=='DEFINED_FILTER':
			if kvfOU7Tpz958QBqnIlaAePLys!=xWwIXcK0L61EBgtn7smr: continue
			elif len(items)<2:
				if xWwIXcK0L61EBgtn7smr==o7o2QXr0sG[-1]:
					w7Ol6FnokgJDSsIt = iCNd2ua6f9EHyBXWYMrKcR(KteRnFMjHpBPqNf8)
					LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(w7Ol6FnokgJDSsIt,'filter')
				else: NNihMcqGKQEvLz6l(KteRnFMjHpBPqNf8,'DEFINED_FILTER___'+TB6HLPpacsK8f034jvYx7SNgFd)
				return
			else:
				if xWwIXcK0L61EBgtn7smr==o7o2QXr0sG[-1]:
					w7Ol6FnokgJDSsIt = iCNd2ua6f9EHyBXWYMrKcR(KteRnFMjHpBPqNf8)
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع ',w7Ol6FnokgJDSsIt,781,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filter')
				else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع ',KteRnFMjHpBPqNf8,785,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,TB6HLPpacsK8f034jvYx7SNgFd)
		elif type=='FULL_FILTER':
			FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+xWwIXcK0L61EBgtn7smr+'=0'
			QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+xWwIXcK0L61EBgtn7smr+'=0'
			TB6HLPpacsK8f034jvYx7SNgFd = FqCItdu32L9hNwcEXWoges4R68KS+'___'+QA6C8r4lEdhemfJPRc
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع :'+name,KteRnFMjHpBPqNf8,784,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,TB6HLPpacsK8f034jvYx7SNgFd)
		dict[xWwIXcK0L61EBgtn7smr] = {}
		for value,DOT0LXwgoHYkFBC4MbxN53 in items:
			if not value: continue
			if DOT0LXwgoHYkFBC4MbxN53 in SAsGubf1jW2Q3p: continue
			dict[xWwIXcK0L61EBgtn7smr][value] = DOT0LXwgoHYkFBC4MbxN53
			FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+xWwIXcK0L61EBgtn7smr+'='+DOT0LXwgoHYkFBC4MbxN53
			QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+xWwIXcK0L61EBgtn7smr+'='+value
			b97AdvPkWGEBe3ayj1Jhmcq2LVxr = FqCItdu32L9hNwcEXWoges4R68KS+'___'+QA6C8r4lEdhemfJPRc
			title = DOT0LXwgoHYkFBC4MbxN53+' :'#+dict[xWwIXcK0L61EBgtn7smr]['0']
			title = DOT0LXwgoHYkFBC4MbxN53+' :'+name
			if type=='FULL_FILTER': TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,784,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,b97AdvPkWGEBe3ayj1Jhmcq2LVxr)
			elif type=='DEFINED_FILTER' and o7o2QXr0sG[-2]+'=' in vvXcyZhkfV:
				OQmDdTI7hU4Lv3BfexPVKgRF8YN = EdpkojMzLm6b3ZSVcXwi0CPRIH(QA6C8r4lEdhemfJPRc,'modified_filters')
				KteRnFMjHpBPqNf8 = url+'/smartemadfilter?'+OQmDdTI7hU4Lv3BfexPVKgRF8YN
				w7Ol6FnokgJDSsIt = iCNd2ua6f9EHyBXWYMrKcR(KteRnFMjHpBPqNf8)
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,w7Ol6FnokgJDSsIt,781,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filter')
			elif type=='DEFINED_FILTER': TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,785,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,b97AdvPkWGEBe3ayj1Jhmcq2LVxr)
	return
def EdpkojMzLm6b3ZSVcXwi0CPRIH(tgsLX2uACmFhVznejRy6O,mode):
	tgsLX2uACmFhVznejRy6O = tgsLX2uACmFhVznejRy6O.replace('=&','=0&')
	tgsLX2uACmFhVznejRy6O = tgsLX2uACmFhVznejRy6O.strip('&')
	bpoRYqt38j = {}
	if '=' in tgsLX2uACmFhVznejRy6O:
		items = tgsLX2uACmFhVznejRy6O.split('&')
		for CQtNwXGVAJ2y5nBY in items:
			eehzynNs85aTHrgCUmFc3DBO12,value = CQtNwXGVAJ2y5nBY.split('=')
			bpoRYqt38j[eehzynNs85aTHrgCUmFc3DBO12] = value
	H5ROYNwvQFkBiVElThr = nA5dhMRg6ENzsB0l1GwvH7aIr2
	for key in cc0WqiHnzER:
		if key in list(bpoRYqt38j.keys()): value = bpoRYqt38j[key]
		else: value = '0'
		if '%' not in value: value = kGE6zoKSan54W(value)
		if mode=='modified_values' and value!='0': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+' + '+value
		elif mode=='modified_filters' and value!='0': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+'&'+key+'='+value
		elif mode=='all': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+'&'+key+'='+value
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.strip(' + ')
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.strip('&')
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.replace('=0','=')
	return H5ROYNwvQFkBiVElThr
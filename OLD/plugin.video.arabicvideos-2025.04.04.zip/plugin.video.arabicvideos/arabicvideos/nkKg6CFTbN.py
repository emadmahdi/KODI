# -*- coding: utf-8 -*-
import sys as kCNHMOym1luTnJ0
MigYEN1cxduFB2lpk5 = kCNHMOym1luTnJ0.version_info [0] == 2
xJ3XdNcV5IujAkoGh = 2048
aE71QiuHI95zfPRBUsntedWZJ2bl = 7
def vR1b8iCLa9Qy2Sw5OYAlWXNhZp37 (AGxE4RIvuC6):
	global peWEVn47JRXo916j
	Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky = ord (AGxE4RIvuC6 [-1])
	FXUjnSw308z = AGxE4RIvuC6 [:-1]
	f81LoVwXMpQkvdKcmPyj6NzBlt = Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky % len (FXUjnSw308z)
	qyKv5nBTxgkQSlJ0aNP1CUmpjYLZ = FXUjnSw308z [:f81LoVwXMpQkvdKcmPyj6NzBlt] + FXUjnSw308z [f81LoVwXMpQkvdKcmPyj6NzBlt:]
	if MigYEN1cxduFB2lpk5:
		H0yFJ5LDCGYpIM1BViZKTSgv3jXr = unicode () .join ([unichr (ord (Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286) - xJ3XdNcV5IujAkoGh - (MfwWyztdYVXURgPqLrITku3CxF1 + Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky) % aE71QiuHI95zfPRBUsntedWZJ2bl) for MfwWyztdYVXURgPqLrITku3CxF1, Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286 in enumerate (qyKv5nBTxgkQSlJ0aNP1CUmpjYLZ)])
	else:
		H0yFJ5LDCGYpIM1BViZKTSgv3jXr = str () .join ([chr (ord (Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286) - xJ3XdNcV5IujAkoGh - (MfwWyztdYVXURgPqLrITku3CxF1 + Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky) % aE71QiuHI95zfPRBUsntedWZJ2bl) for MfwWyztdYVXURgPqLrITku3CxF1, Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286 in enumerate (qyKv5nBTxgkQSlJ0aNP1CUmpjYLZ)])
	return eval (H0yFJ5LDCGYpIM1BViZKTSgv3jXr)
Yj1msqVeivESfrCupRy9b7WacBd,XEcWOIwkZKubV7vQ,Pj9YaUq1ibJ=vR1b8iCLa9Qy2Sw5OYAlWXNhZp37,vR1b8iCLa9Qy2Sw5OYAlWXNhZp37,vR1b8iCLa9Qy2Sw5OYAlWXNhZp37
HD7MQqXd2gS,yPE2t1Co4YQDfsIecdxu0Gklq6AvO,bqCDnV7Bs5XgRvuKLNAa1Uz=Pj9YaUq1ibJ,XEcWOIwkZKubV7vQ,Yj1msqVeivESfrCupRy9b7WacBd
YIsyNBocg6fV3wEWPSu9GtvHxLOqDi,VVstJA9bfOqunLF0oaSgWUKHDdYNz,nfNTgkiWdUq=bqCDnV7Bs5XgRvuKLNAa1Uz,yPE2t1Co4YQDfsIecdxu0Gklq6AvO,HD7MQqXd2gS
FVxoQ2J5Mfv3Zj6sy9uhOS,n8BrpFLyaMAC1vP0bOHgwxEzeGRV,UUobzy0xZLaVScIt7=nfNTgkiWdUq,VVstJA9bfOqunLF0oaSgWUKHDdYNz,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi
JvQd6LMoBX4hiy1C,ZjELJ9VrUT07R8Hn4FuSDcf,pxt6wJ8ScYMWCivoO=UUobzy0xZLaVScIt7,n8BrpFLyaMAC1vP0bOHgwxEzeGRV,FVxoQ2J5Mfv3Zj6sy9uhOS
lw2snZ9J0uhLoxypqa,LJqSQvuhf7aMmnVjy23FbZBckKzx9l,gmPI7hVEM8nD=pxt6wJ8ScYMWCivoO,ZjELJ9VrUT07R8Hn4FuSDcf,JvQd6LMoBX4hiy1C
w0ivtSjV2sZDQoT1OEugIla7R6AC5M,rCmGE4YIDaZA,vzqjsVHSBlMpxC=gmPI7hVEM8nD,LJqSQvuhf7aMmnVjy23FbZBckKzx9l,lw2snZ9J0uhLoxypqa
xwIUQfiE7rmvYzH,ldIfvn6asURQ9toi85EhqAXW3,bb1fgjsAq4N2xYwnoh39lm=vzqjsVHSBlMpxC,rCmGE4YIDaZA,w0ivtSjV2sZDQoT1OEugIla7R6AC5M
AJHaiQq3PRd5cphzGuELnVg9X,jil8vRpBsENVYyPmDd,PPxYugzLZwHX23yiK=bb1fgjsAq4N2xYwnoh39lm,ldIfvn6asURQ9toi85EhqAXW3,xwIUQfiE7rmvYzH
baBcNd81eH5ry2Olp6Mj43,Qy6wlfLoOpg1,mRanX1HZupfSQVB2gsDGUO=PPxYugzLZwHX23yiK,jil8vRpBsENVYyPmDd,AJHaiQq3PRd5cphzGuELnVg9X
bDxWcjmaSgFeRKrfpJvyA4zThi,DFx6E0uON7Jm8,zhE5I4xHinX0UoVZMNwlkPrR=mRanX1HZupfSQVB2gsDGUO,Qy6wlfLoOpg1,baBcNd81eH5ry2Olp6Mj43
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠭೬")
def YYdDUV01oAtQljRBxO9enrEXHwfC(knBV0UPuCNdpIsAFH3coRKjh2lb,OOrjZaTIVXQ2Sp0ozhc=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if   knBV0UPuCNdpIsAFH3coRKjh2lb==lw2snZ9J0uhLoxypqa(u"࠵࿅"): YYwlpitP5zbxXodGR(OOrjZaTIVXQ2Sp0ozhc)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==ZjELJ9VrUT07R8Hn4FuSDcf(u"࠷࿆"): pass
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠲࿇"): z2JW4QB7vEgqxAX0p(OOrjZaTIVXQ2Sp0ozhc)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==pxt6wJ8ScYMWCivoO(u"࠴࿈"): u5MtiYU2FHl0f8IArJcVLkS9meEP()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠶࿉"): lbPyGfqewBD(OOrjZaTIVXQ2Sp0ozhc)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==PPxYugzLZwHX23yiK(u"࠸࿊"): SpuV5zRLDxmWcs()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠺࿋"): b5FWlN9LhQ1c()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==nfNTgkiWdUq(u"࠼࿌"): GGvnphbiLuEtqKA()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==PPxYugzLZwHX23yiK(u"࠾࿍"): NyacLXGD86AfB()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==XEcWOIwkZKubV7vQ(u"࠱࠶࠲࿎"): zCnHfmByw6W()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==xwIUQfiE7rmvYzH(u"࠲࠷࠴࿏"): PPrzbaRDQvLBCjto14GpWygOc()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==DFx6E0uON7Jm8(u"࠳࠸࠶࿐"): y4yTMK2gPDbdFofwB3c6jsnG9ev8()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==zhE5I4xHinX0UoVZMNwlkPrR(u"࠴࠹࠸࿑"): E8qst2e1nkaVC5O0WDf7JvbudhgiB()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠵࠺࠺࿒"): Qb14TRaUvqg9K3LWm()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==AJHaiQq3PRd5cphzGuELnVg9X(u"࠶࠻࠵࿓"): ckbQMsZ1GxAdt8VTyUPI()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠷࠵࠷࿔"): sPjrfqSoBLziCmZ9wMxYK1yFX()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==zhE5I4xHinX0UoVZMNwlkPrR(u"࠱࠶࠹࿕"): sz81RjeGBcpXvHVy5rA()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==XEcWOIwkZKubV7vQ(u"࠲࠷࠻࿖"): XZrzcQvO4uwJGA9i50TE8D()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠳࠸࠽࿗"): rOB0126CsQku8fmRngM4N7D(S5MWhgtZ37Xw)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠴࠻࠵࿘"): sftaSLlCFyD()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==pxt6wJ8ScYMWCivoO(u"࠵࠼࠷࿙"): skYoZMeSH9BQnXLmuAE58qD3CNV()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠶࠽࠲࿚"): fsypSgIu8ezW3ND([OOrjZaTIVXQ2Sp0ozhc],S5MWhgtZ37Xw,S5MWhgtZ37Xw,FFKncZx5pDTwdiJRYhMgQSNL)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==Pj9YaUq1ibJ(u"࠷࠷࠴࿛"): zfTIJNiuLFM2Kj(XEcWOIwkZKubV7vQ(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬ೭"),S5MWhgtZ37Xw)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==jil8vRpBsENVYyPmDd(u"࠱࠸࠶࿜"): zfTIJNiuLFM2Kj(jil8vRpBsENVYyPmDd(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡷࡺ࡭ࡱࠩ೮"),S5MWhgtZ37Xw)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==XEcWOIwkZKubV7vQ(u"࠲࠹࠸࿝"): p4xnGvHOqLVE9wutJFDK()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==Yj1msqVeivESfrCupRy9b7WacBd(u"࠳࠺࠺࿞"): KRrcmelOSDybuw0vMnoP2Wd3qkVz()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠴࠻࠼࿟"): KUmjl5a41P9ks0TuYdtbZeqMcLrO8G(baBcNd81eH5ry2Olp6Mj43(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫ೯"))
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==UUobzy0xZLaVScIt7(u"࠵࠼࠿࿠"): KUmjl5a41P9ks0TuYdtbZeqMcLrO8G(rCmGE4YIDaZA(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡺࡱࡸࡸࡺࡨࡥࠨ೰"))
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==JvQd6LMoBX4hiy1C(u"࠶࠿࠰࿡"): V1aNDbJw975()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==XEcWOIwkZKubV7vQ(u"࠷࠹࠲࿢"): j0aiH2nVhrtF7PIgGLZy45N()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠱࠺࠴࿣"): YtVOFdqWMAT327mzhXw58GE6rnScRj()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==HD7MQqXd2gS(u"࠲࠻࠶࿤"): ggBAetcGQ0PpVOKNCE1LaHWrswZ3()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠳࠼࠸࿥"): ExPAMIFqX9mzgQyN1vuiwt()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠴࠽࠺࿦"): vw1oIQem2ODz0YaK59()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠵࠾࠼࿧"): sOwCjZRK3DF()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==AJHaiQq3PRd5cphzGuELnVg9X(u"࠶࠿࠷࿨"): aXvgH9eTSF5xMifEkZIAz()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==Qy6wlfLoOpg1(u"࠷࠹࠹࿩"): Icay8uMD1UTLJ4()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==UUobzy0xZLaVScIt7(u"࠱࠺࠻࿪"): K67Fn0Lj3z2aSWU()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==xwIUQfiE7rmvYzH(u"࠴࠶࠳࿫"): qZacwbvB25oEn7(OOrjZaTIVXQ2Sp0ozhc)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==rCmGE4YIDaZA(u"࠵࠷࠵࿬"): iI3JWfjo4rBM()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠶࠸࠷࿭"): MharB6d3C19cipgKS5GAZFbNowzJ8()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==baBcNd81eH5ry2Olp6Mj43(u"࠷࠹࠹࿮"): eRYVGKwqE3fLC()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==ZjELJ9VrUT07R8Hn4FuSDcf(u"࠸࠺࠵࿯"): r4Sg1A7F0IqBu6k()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠹࠴࠷࿰"): woj8GNX2kh5vJfMLQ1iqxPCm3U9(FFKncZx5pDTwdiJRYhMgQSNL)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==JvQd6LMoBX4hiy1C(u"࠳࠵࠹࿱"): mzxoBQsiXNTZt6cw5gOyfLAjprRh(S5MWhgtZ37Xw)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠴࠶࠻࿲"): UFjVCoYfxQ9XyEhb()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==Pj9YaUq1ibJ(u"࠵࠷࠽࿳"): kszeX7LnlW2TGa(zhE5I4xHinX0UoVZMNwlkPrR(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧೱ"),S5MWhgtZ37Xw,S5MWhgtZ37Xw)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠸࠴࠵࿴"): wrY31coC2GSJl()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==baBcNd81eH5ry2Olp6Mj43(u"࠹࠵࠷࿵"): Bc36YdT8sMe5PItAf7KvXqn4OUhu()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==UUobzy0xZLaVScIt7(u"࠺࠶࠲࿶"): ttVEJ8S0CKTuhH6vzMa5N1F()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==zhE5I4xHinX0UoVZMNwlkPrR(u"࠻࠰࠴࿷"): TNSbdrPAvnQWshUgIeMmYpw(wGu23VIm0kSzJD7tEKo64nUQvgLXq)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==nfNTgkiWdUq(u"࠵࠱࠶࿸"): TNSbdrPAvnQWshUgIeMmYpw(RihlJwXFNfe1IGPu9ZcUg85qsdn)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠶࠲࠸࿹"): UVIGwQtX2nLuOEM6()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==zhE5I4xHinX0UoVZMNwlkPrR(u"࠷࠳࠺࿺"): GlAym7JHLirouYThdfcjCtV(S5MWhgtZ37Xw)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠸࠴࠼࿻"): oAdGjZLw6nI8sKC97T54RYVQzMyl()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==xwIUQfiE7rmvYzH(u"࠹࠵࠾࿼"): Ft2wcxR5Y16QLzvrW8gMOSZVebCk9()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==mRanX1HZupfSQVB2gsDGUO(u"࠶࠶࠲࠱࿽"): jMmDf1q4B02v()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==ZjELJ9VrUT07R8Hn4FuSDcf(u"࠷࠰࠳࠳࿾"): vZfi0eanOPmjR2SuXVgd()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==pxt6wJ8ScYMWCivoO(u"࠱࠱࠴࠵࿿"): KUmjl5a41P9ks0TuYdtbZeqMcLrO8G(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨೲ"))
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==xwIUQfiE7rmvYzH(u"࠲࠲࠵࠷က"): md9QNyRZSejrY6GD4()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠳࠳࠶࠹ခ"): Q9jaeyLX7GCA0mKRhNUkO25tnMrx(S5MWhgtZ37Xw)
	return
def Q9jaeyLX7GCA0mKRhNUkO25tnMrx(showDialogs=FFKncZx5pDTwdiJRYhMgQSNL):
	W19JFNPIuvoLCOpgl8eXctyx3QE2U = SoNGUfhMDERLyHOz1qkVAj.executeJSONRPC(w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡧࡦࡲࡥ࠯࡭ࡨࡽࡧࡵࡡࡳࡦ࡯ࡥࡾࡵࡵࡵࡵࠥࢁࢂ࠭ೳ"))
	W19JFNPIuvoLCOpgl8eXctyx3QE2U = DcFpQN9gqn.loads(W19JFNPIuvoLCOpgl8eXctyx3QE2U)[HD7MQqXd2gS(u"ࠬࡸࡥࡴࡷ࡯ࡸࠬ೴")][lw2snZ9J0uhLoxypqa(u"࠭ࡶࡢ࡮ࡸࡩࠬ೵")]
	igSA3BDxXY14efJCGs,mXQHSdY93CD = udq5tP0hwifHQCGYELDbOUI,W19JFNPIuvoLCOpgl8eXctyx3QE2U[:]
	if showDialogs:
		yVsaf3nRAJtmUrDLzYh = AJHaiQq3PRd5cphzGuELnVg9X(u"ࠧๅ๊ะอࠥอไๆใสฮ๏ำࠠศๆ฼ีอ๐ษࠡ็ไ฽้ฯ้ࠠฬ฼้้࠭೶") if ldIfvn6asURQ9toi85EhqAXW3(u"ࠨࡃࡵࡥࡧ࡯ࡣࠡࡓ࡚ࡉࡗ࡚࡙ࠨ೷") in W19JFNPIuvoLCOpgl8eXctyx3QE2U else FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠩ็์าฯࠠศๆ่ๅฬะ๊ฮࠢส่฾ืศ๋ห้ࠣฯ๎โโหࠪ೸")
		igSA3BDxXY14efJCGs = vnI6XSlmEtsx7(AJHaiQq3PRd5cphzGuELnVg9X(u"ࠪࡧࡪࡴࡴࡦࡴࠪ೹"),HD7MQqXd2gS(u"ࠫำื่อࠩ೺"),baBcNd81eH5ry2Olp6Mj43(u"ࠬห๊ใษไࠫ೻"),JvQd6LMoBX4hiy1C(u"࠭สี฼ํ่ࠬ೼"),OksCHeoL5SG,bbTCMJwEx8nhN4X+yVsaf3nRAJtmUrDLzYh+NwROdSj3nsA+CXtugbqhV3+CXtugbqhV3+HD7MQqXd2gS(u"่ࠧา๊ࠤฬู๊่์ไอࠥะำๆฯࠣฬฬูสฯัส้๊่ࠥฮหࠣห้๋แศฬํัࠥอไฺำห๎ฮࠦวๅ็๋ะํีษࠡใํࠤ่๎ฯ๋ࠢ࠱࠲ࠥ๎็ัษ้ࠣ฾์ว่ࠢส๊ฯࠦสิฬฺ๎฾ࠦร็ࠢอ฽๊๊ࠠษฯฮࠤๆ๐ࠠๆ๊สๆ฾ࠦวๅสิ๊ฬ๋ฬࠡสสืฯิฯศ็ࠣหฺ้๊สࠢส่฾ืศ๋หࠣ࠲࠳ࠦร้ࠢอืฯ฽ฺ๊ࠢฦ๊ࠥะใหสࠣีุอไสࠢ็่๊ฮัๆฮࠣฬฬ๊ไ฻หࠣห้฿ัษ์ฬࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦสี฼ํ่๊่ࠥฮหࠣห้๋แศฬํัࠥอไฺำห๎ฮࠦรๆࠢศ๎็อแ่ษࠣรࠦࠧࠧ೽"))
	if igSA3BDxXY14efJCGs==udq5tP0hwifHQCGYELDbOUI and baBcNd81eH5ry2Olp6Mj43(u"ࠨࡃࡵࡥࡧ࡯ࡣࠡࡓ࡚ࡉࡗ࡚࡙ࠨ೾") not in W19JFNPIuvoLCOpgl8eXctyx3QE2U: mXQHSdY93CD = [VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠩࡄࡶࡦࡨࡩࡤࠢࡔ࡛ࡊࡘࡔ࡚ࠩ೿")]+W19JFNPIuvoLCOpgl8eXctyx3QE2U
	elif igSA3BDxXY14efJCGs==UnOIK1WBbw2 and n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠪࡅࡷࡧࡢࡪࡥࠣࡕ࡜ࡋࡒࡕ࡛ࠪഀ") in W19JFNPIuvoLCOpgl8eXctyx3QE2U:
		mXQHSdY93CD = W19JFNPIuvoLCOpgl8eXctyx3QE2U[:]
		mXQHSdY93CD.remove(nfNTgkiWdUq(u"ࠫࡆࡸࡡࡣ࡫ࡦࠤࡖ࡝ࡅࡓࡖ࡜ࠫഁ"))
	if mXQHSdY93CD!=W19JFNPIuvoLCOpgl8eXctyx3QE2U:
		mXQHSdY93CD = str(mXQHSdY93CD).replace(Qy6wlfLoOpg1(u"ࠧ࠭ࠢം"),Qy6wlfLoOpg1(u"࠭ࠢࠨഃ"))
		V9OGBuyogH0CaUtQS6wWErAbPYDjlM = SoNGUfhMDERLyHOz1qkVAj.executeJSONRPC(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡕࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵࡣࡢ࡮ࡨ࠲ࡰ࡫ࡹࡣࡱࡤࡶࡩࡲࡡࡺࡱࡸࡸࡸࠨࠬࠣࡸࡤࡰࡺ࡫ࠢ࠻ࠩഄ")+mXQHSdY93CD+XEcWOIwkZKubV7vQ(u"ࠨࡿࢀࠫഅ"))
		if showDialogs:
			if xwIUQfiE7rmvYzH(u"ࠩࡷࡶࡺ࡫ࠧആ") in str(V9OGBuyogH0CaUtQS6wWErAbPYDjlM): OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,vzqjsVHSBlMpxC(u"ࠪฮ๊ะࠠศๆ฼้้๐ษࠡส้ะฬำࠧഇ"))
			else: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"้๊ࠫริใࠣห้฿ๅๅ์ฬࠤๆฺไหࠩഈ"))
	return
def md9QNyRZSejrY6GD4():
	OTQCuS0y4RDU8abeZ = KQctJbXeEjDhplqknU3rzi.getSetting(bb1fgjsAq4N2xYwnoh39lm(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡤ࡬ࡸࡷࡧࡴࡦࠩഉ"))
	message = LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠭วๅำๅ้ࠥอไๆฯาำࠥำวๅ์สࠤ์๎ࠠ࠻ࠢࠣࠤࠬഊ")+str(OTQCuS0y4RDU8abeZ)+bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠧࠡ࡭ࡥࡴࡸ࠭ഋ") if OTQCuS0y4RDU8abeZ else XEcWOIwkZKubV7vQ(u"ࠨษ็ะํีษࠡษ็วํะ่ๆษอ๎่๐ษࠡ็อ์็็ษࠡฯส่๏อࠧഌ")
	message = bbTCMJwEx8nhN4X+message+Pj9YaUq1ibJ(u"ࠩ࡟ࡲ์๊ࠠหำํำࠥอไร่ࠣฮูเ๊ๅࠢฦ์ࠥะฺ๋์ิࠤึ่ๅࠡษ็ะํีษࠡษ็วํะ่ๆษอ๎่๐ษࠨ഍")+NwROdSj3nsA
	uDP7kA6UcClgd2Gza0VO = vnI6XSlmEtsx7(ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠪࡧࡪࡴࡴࡦࡴࠪഎ"),JvQd6LMoBX4hiy1C(u"ࠫำื่อࠩഏ"),Yj1msqVeivESfrCupRy9b7WacBd(u"ࠬห๊ใษไࠫഐ"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠭สี฼ํ่ࠬ഑"),OksCHeoL5SG,XEcWOIwkZKubV7vQ(u"ࠧศๆฯ์ิฯࠠศๆฦ์ฯ๎ๅศฬํ็๏ฯ่ࠠ์ࠣ฽๊๊๊สࠢํๆํ๋ࠠษ้สࠤฬ๊ศา่ส้ัࠦศศะอ๎ฬืࠠฤ฻็ํࠥา่ะห้ࠣฯ๎แาห่ࠣึ่ๅࠡษ็ะํีษࠡษ็ิ๏ࠦว็ฬࠣฮาีฯ่ࠢไ๎ࠥํะ่ࠢสู่อิสࠢ࠱࠲ࠥ๎็ัษ้ࠣ฾์ว่ࠢ฼๊ิ๋วࠡฬๅ์๊ࠦว็ฬࠣฬฯฺฺ๋ๆࠣๅ๏ี๊้ࠢไห๋ࠦวๅสิ๊ฬ๋ฬࠡๆ้ࠤ๏ูรๅๅࠣ฽๋ࠦวๅฮ๋ำฮࠦวๅฬํࠤฯื๊ะ้สࠤ้ษๆࠡษ็ฬึ์วๆฮࠣืํ็๋ࠠะอหึࠦวๅฮ๋ำฮࠦร้ฬ๋้ฬะ๊ไ์สࠤ࠳࠴ฺࠠๆ่หࠥอๆ่ࠢํะอࠦวฯฬํหึࠦัใ็ࠣะํีษࠡื฽๎ึࠦลัษࠣ็ฬ์สࠡษ็ษ๋ะั็ฬࠣ฽๋ีใࠡสฺ๎หฯࠠฤ๊ࠣๆ้๐ไส࡞ࡱࡠࡳ࠭ഒ")+message)
	if uDP7kA6UcClgd2Gza0VO in [-Pj9YaUq1ibJ(u"࠴ဂ"),vzqjsVHSBlMpxC(u"࠴ဃ")]: return
	if uDP7kA6UcClgd2Gza0VO==JvQd6LMoBX4hiy1C(u"࠶င"):
		OTQCuS0y4RDU8abeZ = nA5dhMRg6ENzsB0l1GwvH7aIr2
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,ldIfvn6asURQ9toi85EhqAXW3(u"ࠨ่ฯัฯูࠦๆๆํอࠥห๊ใษไࠤฬ๊ฬ้ัฬࠤฬ๊ร้ฬ๋้ฬะ๊ไ์ฬࠫഓ"))
	else:
		items = [w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠩ࠵࠹࠵ࠦ࡫ࡣࡲࡶࠫഔ"),mRanX1HZupfSQVB2gsDGUO(u"ࠪ࠹࠵࠶ࠠ࡬ࡤࡳࡷࠬക"),UUobzy0xZLaVScIt7(u"ࠫ࠼࠻࠰ࠡ࡭ࡥࡴࡸ࠭ഖ"),gmPI7hVEM8nD(u"ࠬ࠷࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨഗ"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠭࠱࠳࠷࠳ࠤࡰࡨࡰࡴࠩഘ"),lw2snZ9J0uhLoxypqa(u"ࠧ࠲࠷࠳࠴ࠥࡱࡢࡱࡵࠪങ"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠨ࠳࠺࠹࠵ࠦ࡫ࡣࡲࡶࠫച"),nfNTgkiWdUq(u"ࠩ࠵࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬഛ"),UUobzy0xZLaVScIt7(u"ࠪ࠶࠺࠶࠰ࠡ࡭ࡥࡴࡸ࠭ജ"),vzqjsVHSBlMpxC(u"ࠫ࠸࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧഝ"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠬ࠹࠵࠱࠲ࠣ࡯ࡧࡶࡳࠨഞ"),jil8vRpBsENVYyPmDd(u"࠭࠴࠱࠲࠳ࠤࡰࡨࡰࡴࠩട"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠧ࠵࠷࠳࠴ࠥࡱࡢࡱࡵࠪഠ"),bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠨ࠷࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫഡ"),HD7MQqXd2gS(u"ࠩ࠹࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬഢ"),xwIUQfiE7rmvYzH(u"ࠪ࠻࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭ണ"),XEcWOIwkZKubV7vQ(u"ࠫ࠽࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧത"),AJHaiQq3PRd5cphzGuELnVg9X(u"ࠬ࠿࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨഥ"),pxt6wJ8ScYMWCivoO(u"࠭࠱࠱࠲࠳࠴ࠥࡱࡢࡱࡵࠪദ"),jil8vRpBsENVYyPmDd(u"ࠧ࠲࠳࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫധ"),rCmGE4YIDaZA(u"ࠨ࠳࠵࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬന"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠩ࠼࠽࠾࠿࠹ࠡ࡭ࡥࡴࡸ࠭ഩ")]
		iP7AUR41exzlKyZIf9Mt3u = ccAMwn7hflDev8Kd3aqP(w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠪหำะัࠡษ็ะํีษࠡษ็วํะ่ๆษอ๎่๐ษࠡษ็้๋อำษหࠪപ"),items)
		if iP7AUR41exzlKyZIf9Mt3u==-DFx6E0uON7Jm8(u"࠷စ"): return
		OTQCuS0y4RDU8abeZ = str(items[iP7AUR41exzlKyZIf9Mt3u][:-Yj1msqVeivESfrCupRy9b7WacBd(u"࠵ဆ")])
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,gmPI7hVEM8nD(u"๋ࠫาอหࠢ฼้้๐ษࠡฬื฾๏๊้ࠠฬะำ๏ีࠠาไ่ࠤฬ๊ฬ้ัฬࠤฬ๊ร้ฬ๋้ฬะ๊ไ์ฬࡠࡳࡢ࡮ࠨഫ")+bbTCMJwEx8nhN4X+OTQCuS0y4RDU8abeZ+n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠬࠦ࡫ࡣࡲࡶࠫബ")+NwROdSj3nsA)
	KQctJbXeEjDhplqknU3rzi.setSetting(ldIfvn6asURQ9toi85EhqAXW3(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡥ࡭ࡹࡸࡡࡵࡧࠪഭ"),OTQCuS0y4RDU8abeZ)
	return
def vZfi0eanOPmjR2SuXVgd(BAsdPIYwTrc0LVzRQ=FFKncZx5pDTwdiJRYhMgQSNL):
	uVTtQ2nhI6rXCb0 = JleVOsy9Aj340uHoQYGPFpbk()
	yVsaf3nRAJtmUrDLzYh = DFx6E0uON7Jm8(u"ࠧศๆอุ฿๐ไࠡษ็่ฬำโࠡ์฼้้࠭മ") if uVTtQ2nhI6rXCb0 else UUobzy0xZLaVScIt7(u"ࠨษ็ฮูเ๊ๅࠢส่้ออใ่ࠢฮํ่แࠨയ")
	uDP7kA6UcClgd2Gza0VO = vnI6XSlmEtsx7(ldIfvn6asURQ9toi85EhqAXW3(u"ࠩࡦࡩࡳࡺࡥࡳࠩര"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠪาึ๎ฬࠨറ"),ldIfvn6asURQ9toi85EhqAXW3(u"ࠫส๐โศใࠪല"),vzqjsVHSBlMpxC(u"ࠬะิ฻์็ࠫള"),OksCHeoL5SG,bbTCMJwEx8nhN4X+yVsaf3nRAJtmUrDLzYh+NwROdSj3nsA+CXtugbqhV3+n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠭็ั้ࠣห้๎ุ๋ใฬࠤฯาูๅࠢๆ์ิ๐ࠠฤ๊อ์๊อส๋ๅํหࠥ๐โ้็ࠣฬฯฺฺ๋ๆࠣห้็๊ะ์๋ࠤฬ๊ไศฯๅࠤ࠳࠴ࠠฦ็สࠤอ฿ฯࠡษ้ฮ์อมࠡษ็ๅ๏ี๊้ࠢส่าอไ๋ࠢหว่๋ไ่ࠢ࠱࠲ࠥษ่ࠡส฼ำࠥอไ็ไิࠤ฾๊้ࠡิิࠤࠧะฬศ๊ีࠤส๊้ࠡษ็่ฬำโࠣࠢ࠱࠲ࠥ๎รุ๋สࠤ๊๋ใ็ࠢศ่฿อมࠡษ็ฮูเ๊ๅࠢส่้ออใࠢหห้์โาࠢ฼่๎ࠦาาࠢࠥษ๏่วโࠢส่ๆ๐ฯ๋๊ࠥࠤ࠳࠴้ࠠลํฺฬࠦๅๆๅ้ࠤฬ๊วิฬไหิฯࠠๆ่ࠣฮ฿๐๊าࠢอีฯ๐ศࠡ็ะฮํ๐วหࠢส่็๎วว็ࠣ࠲࠳่ࠦฯษุอࠥะัห์หࠤา๊โศฬࠣห้๋ำๅี็หฯࠦ࠮࠯๊่ࠢࠥะั๋ัࠣห้ศๆࠡฬื฾๏๊่ࠠา๊ࠤฬู๊่์ไอࠥษๅࠡวํๆฬ็็ศࠢยࠥࠦ࠭ഴ"))
	if uDP7kA6UcClgd2Gza0VO==UnOIK1WBbw2: egWEvMhXIK = SoNGUfhMDERLyHOz1qkVAj.executeJSONRPC(jil8vRpBsENVYyPmDd(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡕࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡻ࡯ࡤࡦࡱࡳࡰࡦࡿࡥࡳ࠰ࡤࡹࡹࡵࡰ࡭ࡣࡼࡲࡪࡾࡴࡪࡶࡨࡱࠧ࠲ࠢࡷࡣ࡯ࡹࡪࠨ࠺࡜࡟ࢀࢁࠬവ"))
	elif uDP7kA6UcClgd2Gza0VO==udq5tP0hwifHQCGYELDbOUI: egWEvMhXIK = SoNGUfhMDERLyHOz1qkVAj.executeJSONRPC(gmPI7hVEM8nD(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡖࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡼࡩࡥࡧࡲࡴࡱࡧࡹࡦࡴ࠱ࡥࡺࡺ࡯ࡱ࡮ࡤࡽࡳ࡫ࡸࡵ࡫ࡷࡩࡲࠨࠬࠣࡸࡤࡰࡺ࡫ࠢ࠻࡝࠴ࡡࢂࢃࠧശ"))
	if uDP7kA6UcClgd2Gza0VO in [UnOIK1WBbw2,udq5tP0hwifHQCGYELDbOUI]:
		if bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠩࡷࡶࡺ࡫ࠧഷ") in str(egWEvMhXIK): OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠪฮ๊ะࠠศๆ฼้้๐ษࠡส้ะฬำࠧസ"))
		else: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,xwIUQfiE7rmvYzH(u"้๊ࠫริใࠣห้฿ๅๅ์ฬࠤๆฺไหࠩഹ"))
	return
def jMmDf1q4B02v():
	url = Nzp9Fq5cTr.SITESURLS[ldIfvn6asURQ9toi85EhqAXW3(u"ࠬࡘࡅࡍࡇࡄࡗࡊ࡙ࠧഺ")][JvQd6LMoBX4hiy1C(u"࠱ဇ")]
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(yy6RomT9bQhJf,xwIUQfiE7rmvYzH(u"࠭ࡇࡆࡖ഻ࠪ"),url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nfNTgkiWdUq(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡌࡒࡘ࡚ࡁࡍࡎࡢࡓࡑࡊ࡟ࡓࡇࡏࡉࡆ࡙ࡅ࠮࠳ࡶࡸ഼ࠬ"))
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	i0gkImCvH1p = PAztbuyYo4Kvd.findall(YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠨࡪࡵࡩ࡫ࡃࠢࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࠨࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠴ࠪࡀࠫ࠱ࡾ࡮ࡶࠢࠨഽ"),kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	i0gkImCvH1p = sorted(i0gkImCvH1p,reverse=S5MWhgtZ37Xw)
	iP7AUR41exzlKyZIf9Mt3u = ccAMwn7hflDev8Kd3aqP(zhE5I4xHinX0UoVZMNwlkPrR(u"ࠩสาฯืࠠศๆศูิอัࠡษ็ิ๏ࠦสา์าࠤฯัศ๋ฬ๊ࠫാ"),i0gkImCvH1p)
	if iP7AUR41exzlKyZIf9Mt3u>=bb1fgjsAq4N2xYwnoh39lm(u"࠲ဈ"):
		uu1i7ezXHVSljaU2xqNbYRfcZ3ACk = url.rsplit(zhE5I4xHinX0UoVZMNwlkPrR(u"ࠪ࠳ࠬി"),jil8vRpBsENVYyPmDd(u"࠴ဉ"))[ZjELJ9VrUT07R8Hn4FuSDcf(u"࠴ည")]+yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠫ࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࠬീ")+i0gkImCvH1p[iP7AUR41exzlKyZIf9Mt3u]+jil8vRpBsENVYyPmDd(u"ࠬ࠴ࡺࡪࡲࠪു")
		succeeded = qQcXZr4Pk6pg9RBIdEMjaiO3hvD(FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫൂ"),uu1i7ezXHVSljaU2xqNbYRfcZ3ACk,S5MWhgtZ37Xw)
		if succeeded:
			KQctJbXeEjDhplqknU3rzi.setSetting(DFx6E0uON7Jm8(u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫൃ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
			x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠨฬ่ࠤฯัศ๋ฬࠣษฺีวาࠢๅำ๏๋ࠠๅๆหี๋อๅอࠢ࠱࠲๊ࠥใ็ࠢหี๋อๅอࠢๆ์ิ๐๋ࠠไ๋้ࠥษ่ห๊่หฯ๐ใ๋ษࠣฬฯำฯ๋อࠣะ๊๐ูࠡษ็ฬึอๅอࠢหหุะฮะษ่ࠤวิัࠡวุำฬืࠠๆฬ๋ๅึࠦ࠮࠯๊่ࠢࠥะั๋ัࠣห้ศๆࠡวํๆฬ็ࠠศๆอัิ๐หࠡษ็วํะ่ๆษอ๎่๐ࠠๅ้ำหࠥอไษำ้ห๊าࠠภࠣࠤࠫൄ"))
			if x6zlf2tTZm: kszeX7LnlW2TGa(UUobzy0xZLaVScIt7(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ൅"),S5MWhgtZ37Xw,S5MWhgtZ37Xw)
	return
def oAdGjZLw6nI8sKC97T54RYVQzMyl():
	x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"๋้ࠪࠦสา์าࠤๆ฿ไศ่ࠢืาࠦลฺัสำฬะࠠศๆหี๋อๅอࠢส่ำอีสࠢห์็ะࠠอๆหࠤฬ๊สฮัํฯฬะࠠ࠯࠰๋ࠣีอࠠศๆ่ืาࠦำ้ใࠣ๎ุฮศࠡฬะำ๏ัࠠโ๊ิ๎๊ࠥฬๆ์฼ࠤํ฾ววใࠣห้ฮั็ษ่ะࠥอไห์ࠣฮ฾ะๅะࠢ฼่๎ࠦๅา๊ิࠤํ่สࠡ็฼๎๋࠭െ"))
	if x6zlf2tTZm:
		KQctJbXeEjDhplqknU3rzi.setSetting(vzqjsVHSBlMpxC(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡷ࡭ࡵࡲࡵࠩേ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
		KQctJbXeEjDhplqknU3rzi.setSetting(vzqjsVHSBlMpxC(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡷ࡫ࡧࡶ࡮ࡤࡶࠬൈ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
		KQctJbXeEjDhplqknU3rzi.setSetting(FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡲ࡯࡯ࡩࠪ൉"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
		KQctJbXeEjDhplqknU3rzi.setSetting(AJHaiQq3PRd5cphzGuELnVg9X(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨൊ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
		KQctJbXeEjDhplqknU3rzi.setSetting(PPxYugzLZwHX23yiK(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪോ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠩอ้๋ࠥำฮࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥอไฯษุอࠥฮ่ใฬࠣะ้ฮࠠศๆอัิ๐หศฬࠣ࠲࠳่ࠦิ๊ไࠤ๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢหฮาี๊ฬ๊ࠢิ์ࠦวๅว฼ำฬีวหࠢ࠱࠲ࠥ๎รุ๋สࠤฯำฯ๋อࠣ์฽อฦโࠢส่อืๆศ็ฯࠤฬ๊ส๋ࠢอ฽ฯ๋ฯࠡ฻็ํࠥอไ้ไอࠫൌ"))
		AA5FS4hUqeP9EsZCM(FFKncZx5pDTwdiJRYhMgQSNL)
	return
def UVIGwQtX2nLuOEM6():
	aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕࡥ࠱ࠨ്"),lw2snZ9J0uhLoxypqa(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧൎ"))
	LOYHM0pRiEKka5SfWVzxcUAlXumZt = bAQuqZOzEGe8DCH2RTwtL9(FFKncZx5pDTwdiJRYhMgQSNL)
	orbhZ8Psp5diewK0QfvRx6XBYL3 = CXtugbqhV3
	S5su1wxPTt = lSWzOYmN08+AJHaiQq3PRd5cphzGuELnVg9X(u"ࠬࠦ࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯ࠣ࠱࠲࠳࠭࠮ࠢ࠰࠱࠲࠳࠭ࠡࠩ൏")+NwROdSj3nsA
	eog3DiwmhZfpWN = CXtugbqhV3+bbTCMJwEx8nhN4X+LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪ൐")+NwROdSj3nsA+Pj9YaUq1ibJ(u"ࠧ࡝ࡰ࡟ࡲࠬ൑")
	for id,QQlJ2xKXAGUzh,mGy19ecrPjKCF,ccTbOMIrUX13m4pNRfyGquCadwJE,i4LsgZVpI3cQ,reason in reversed(LOYHM0pRiEKka5SfWVzxcUAlXumZt):
		if id==ldIfvn6asURQ9toi85EhqAXW3(u"ࠨ࠲ࠪ൒"):
			B6O85VTcMiPW1CFXZLYfdonsSK,Bq6o5cM8TxkKD4W = ccTbOMIrUX13m4pNRfyGquCadwJE.split(PPxYugzLZwHX23yiK(u"ࠩ࡟ࡲࡀࡁࠧ൓"))
			continue
		if orbhZ8Psp5diewK0QfvRx6XBYL3!=CXtugbqhV3: orbhZ8Psp5diewK0QfvRx6XBYL3 += eog3DiwmhZfpWN
		jr9ylNbvcHEzPG8UpkL = YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩൔ")+lSWzOYmN08+id+YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠫࠥࡀࠠࠨൕ")+xwIUQfiE7rmvYzH(u"ࠬอไิฦส่ࠥࡀࠠࠨൖ")+NwROdSj3nsA+mGy19ecrPjKCF
		jL23e6YO9IcvVME = pxt6wJ8ScYMWCivoO(u"࠭࡜࡯࡝ࡕࡘࡑࡣࠧൗ")+lSWzOYmN08+jil8vRpBsENVYyPmDd(u"ࠧศๆฯ์ฬฮࠠ࠻ࠢࠪ൘")+NwROdSj3nsA+ccTbOMIrUX13m4pNRfyGquCadwJE
		BdkeVTtAKUW9vrcqmy7 = VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠨ࡝ࡕࡘࡑࡣࠧ൙")+lSWzOYmN08+PPxYugzLZwHX23yiK(u"ࠩส่ำ฽รࠡ࠼ࠣࠫ൚")+NwROdSj3nsA+i4LsgZVpI3cQ
		N1AwpoxOhTb9gSEFJvZKHmD6 = ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠪࡠࡳࡡࡒࡕࡎࡠࠫ൛")+lSWzOYmN08+vzqjsVHSBlMpxC(u"ࠫฬ๊ำษสࠣ࠾ࠥ࠭൜")+NwROdSj3nsA+reason
		orbhZ8Psp5diewK0QfvRx6XBYL3 += jr9ylNbvcHEzPG8UpkL+jL23e6YO9IcvVME+CXtugbqhV3+S5su1wxPTt+CXtugbqhV3+BdkeVTtAKUW9vrcqmy7+N1AwpoxOhTb9gSEFJvZKHmD6+CXtugbqhV3
	d9EaJh5t3Tyj7CsXFL(pxt6wJ8ScYMWCivoO(u"ࠬࡸࡩࡨࡪࡷࠫ൝"),Bq6o5cM8TxkKD4W,orbhZ8Psp5diewK0QfvRx6XBYL3,AJHaiQq3PRd5cphzGuELnVg9X(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧ൞"))
	return
def TNSbdrPAvnQWshUgIeMmYpw(file):
	if file==RihlJwXFNfe1IGPu9ZcUg85qsdn: d0WF7sVSeRhPbiOfNztyKa4vHcxM = XEcWOIwkZKubV7vQ(u"ࠧใ๊สส๊ࠦวๅ็ไฺ้ฯࠧൟ")
	elif file==wGu23VIm0kSzJD7tEKo64nUQvgLXq: d0WF7sVSeRhPbiOfNztyKa4vHcxM = zhE5I4xHinX0UoVZMNwlkPrR(u"ࠨไ๋หห๋ࠠระิࠤฬ๊แ๋ัํ์์อสࠨൠ")
	uDP7kA6UcClgd2Gza0VO = vnI6XSlmEtsx7(Pj9YaUq1ibJ(u"ࠩࡦࡩࡳࡺࡥࡳࠩൡ"),xwIUQfiE7rmvYzH(u"ุ้ࠪำࠧൢ"),UUobzy0xZLaVScIt7(u"ࠫส฻ไศฯࠪൣ"),Pj9YaUq1ibJ(u"ࠬิั้ฮࠪ൤"),OksCHeoL5SG,bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠭็ๅࠢอี๏ีࠠฦื็หาࠦๅๅใࠣࠫ൥")+d0WF7sVSeRhPbiOfNztyKa4vHcxM+n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠧࠡล่ࠤฯื๊ะ่ࠢืาࠦวๅ็็ๅࠥลࠧ൦"))
	if uDP7kA6UcClgd2Gza0VO==rCmGE4YIDaZA(u"࠵ဋ"):
		if XoZRpFe7B6gnfA.path.exists(file):
			try: XoZRpFe7B6gnfA.remove(file)
			except: pass
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠨฬ่ࠤู๊อࠡ็็ๅࠥ࠭൧")+d0WF7sVSeRhPbiOfNztyKa4vHcxM)
	elif uDP7kA6UcClgd2Gza0VO==Pj9YaUq1ibJ(u"࠷ဌ"):
		data = x1ibKhuTya7w3I589OcoEBAN(file)
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠩอ้ࠥหีๅษะࠤ๊๊แࠡࠩ൨")+d0WF7sVSeRhPbiOfNztyKa4vHcxM)
	return
def Bc36YdT8sMe5PItAf7KvXqn4OUhu():
	if l2JAnWsaDGz8CIEZY<zhE5I4xHinX0UoVZMNwlkPrR(u"࠱࠹ဍ"):
		a1duvQ8Vh0gNo69nDcp3Pjtym = PPxYugzLZwHX23yiK(u"่้ࠪษำโࠢฦ๊ฯࠦสิฬัำ๊ࠦลึัสี้่ࠥะ์ࠣๆิ๐ๅࠡำๅ้ࠥ࠭൩")+str(l2JAnWsaDGz8CIEZY)+DFx6E0uON7Jm8(u"ࠫࠥ๎ไ่าสࠤฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦไศࠢอ฽ฺ๊๊่ࠠา็ࠥ࠴่ࠠา๊ࠤฬ๊ๅ๋ิฬࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣห้็๊ะ์๋๋ฬะࠠโ์ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠥ࠴ࠠๅวุ่ฬำࠠศๆุ่่๊ษࠡไ่ࠤอะอะ์ฮࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢศ่๎ࠦล๋ࠢศูิอัࠡำๅ้์ࠦรฺๆ์ࠤ๊์ࠠ࠲࠺࠱࠴ࠬ൪")
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,a1duvQ8Vh0gNo69nDcp3Pjtym)
		return
	POhJdDXSrE0p = SoNGUfhMDERLyHOz1qkVAj.executeJSONRPC(lw2snZ9J0uhLoxypqa(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨ൫"))
	KxieNnJUoIR9uj = gOHnJkmlPAGjiqN([zhE5I4xHinX0UoVZMNwlkPrR(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ൬")])
	ozirPWaNn5j9lUwbtOxEJIv0uT,ZZOyALd1rphxY97PojtCX4bf,f6oAtdNmP2VQBuqw,oyl0jUXtqY2KrC6E9W1vi7cVkAfRTz,zYLhQHagbRVIEnM,sGRhdPrpbFDl,q8EQD4lxzK = KxieNnJUoIR9uj[mRanX1HZupfSQVB2gsDGUO(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭൭")]
	if ozirPWaNn5j9lUwbtOxEJIv0uT or zhE5I4xHinX0UoVZMNwlkPrR(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ൮") not in str(POhJdDXSrE0p):
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠩส่็๎วว็ࠣห้๋ี้ำฬࠤฯ฿ๅๅࠢไๆ฼ࠦๅฺࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮้ࠡำ๋ࠥอไใ๊สส๊ࠦสๆๅ้็๋ࠥๆࠡำว๎ฮࠦโ้ษษ้ࠥฮั็ษ่ะࠥ฿ๅศัࠣฬู้ไࠡื๋ีࠥฮฯๅษ้๋ࠣࠦวๅๅอหอฯࠧ൯"))
		zTEXepHg92GkWf = ttVEJ8S0CKTuhH6vzMa5N1F()
		if not zTEXepHg92GkWf: return
	UHWdMnfqCxisbKaEe1By(S5MWhgtZ37Xw)
	return
def UHWdMnfqCxisbKaEe1By(showDialogs=S5MWhgtZ37Xw):
	POhJdDXSrE0p = SoNGUfhMDERLyHOz1qkVAj.executeJSONRPC(JvQd6LMoBX4hiy1C(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭൰"))
	if AJHaiQq3PRd5cphzGuELnVg9X(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ൱") not in str(POhJdDXSrE0p):
		if showDialogs:
			OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,xwIUQfiE7rmvYzH(u"๊ࠬไฤีไࠤัํวำๅ่ࠣฬ๊ࠦิฬัำ๊ࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠲ࠥอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠห฻่่ࠥ็โุ่ࠢ฽ࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤ์ึ็ࠡษ็ๆํอฦๆࠢอ้่์ใࠡ็้ࠤึส๊สࠢๅ์ฬฬๅࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศีๅ็ࠤฺ๎ัࠡสา่ฬࠦๅ็ࠢส่่ะวษหࠪ൲"))
		return
	clOH3ADqfydeBojFMRPS8I1 = XoZRpFe7B6gnfA.path.join(kkjOSvrlpDJNcqVIwUBt3,vzqjsVHSBlMpxC(u"࠭ࡡࡥࡦࡲࡲࡸ࠭൳"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭൴"),bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠨ࠹࠵࠴ࡵ࠭൵"),Pj9YaUq1ibJ(u"ࠩࡐࡽ࡛࡯ࡤࡦࡱࡑࡥࡻ࠴ࡸ࡮࡮ࠪ൶"))
	if not XoZRpFe7B6gnfA.path.exists(clOH3ADqfydeBojFMRPS8I1): return
	tFE1s8OzUMHLnWj4pgxvu90CYqoSm = open(clOH3ADqfydeBojFMRPS8I1,rCmGE4YIDaZA(u"ࠪࡶࡧ࠭൷")).read()
	if BsLJ7p5Av2Vm0SQeCO1o: tFE1s8OzUMHLnWj4pgxvu90CYqoSm = tFE1s8OzUMHLnWj4pgxvu90CYqoSm.decode(YWEQ3Cf8RevpD0m7NjF1)
	VZyqChfbJxNEL25l4iIm1RP = PAztbuyYo4Kvd.findall(rCmGE4YIDaZA(u"ࠫࡁࡼࡩࡦࡹࡶࡂ࠭ࡢࡤࠬ࠮࡟ࡨ࠰࠲࡜ࡥ࠭ࠬ࠰࠭࠴ࠪࡀࠫ࠿࠳ࡻ࡯ࡥࡸࡵࡁࠫ൸"),tFE1s8OzUMHLnWj4pgxvu90CYqoSm,PAztbuyYo4Kvd.DOTALL)
	c9RjxM5fHbuek,AQT1th2cIpzyNfG4ZuSgv = VZyqChfbJxNEL25l4iIm1RP[IpFcwrWNgefMym3qta0hYQAzOdE]
	UjeLGtBf8cqXTa0x = VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠬࡂࡶࡪࡧࡺࡷࡃ࠭൹")+c9RjxM5fHbuek+rCmGE4YIDaZA(u"࠭ࠬࠨൺ")+AQT1th2cIpzyNfG4ZuSgv+ldIfvn6asURQ9toi85EhqAXW3(u"ࠧ࠽࠱ࡹ࡭ࡪࡽࡳ࠿ࠩൻ")
	if showDialogs:
		FOuva426dp1XNg83zxU0SWloBci = SoNGUfhMDERLyHOz1qkVAj.getInfoLabel(Pj9YaUq1ibJ(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡛࡯ࡥࡸ࡯ࡲࡨࡪ࠭ർ"))
		if FOuva426dp1XNg83zxU0SWloBci==pxt6wJ8ScYMWCivoO(u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬൽ"): F5kODybpPJ = jil8vRpBsENVYyPmDd(u"ࠪๆํอฦๆࠢส่่ะวษหࠪൾ")
		elif FOuva426dp1XNg83zxU0SWloBci==ldIfvn6asURQ9toi85EhqAXW3(u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪൿ"): F5kODybpPJ = n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"่่ࠬศศ่ࠤฬ๊ี้ำࠪ඀")
		else: F5kODybpPJ = zhE5I4xHinX0UoVZMNwlkPrR(u"࠭โ้ษษ้ࠥษฮา๋ࠪඁ")
		uDP7kA6UcClgd2Gza0VO = vnI6XSlmEtsx7(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠧࡤࡧࡱࡸࡪࡸࠧං"),pxt6wJ8ScYMWCivoO(u"ࠨไ๋หห๋ࠠฤะิํࠬඃ"),gmPI7hVEM8nD(u"ࠩๅ์ฬฬๅࠡษ็็ฯอศสࠩ඄"),rCmGE4YIDaZA(u"ࠪๆํอฦๆࠢสฺ่๎ัࠨඅ"),gmPI7hVEM8nD(u"ࠫฬ์สࠡฯส่๏อࠠหีอาิ๋ࠠࠨආ")+F5kODybpPJ,w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠬอๆหࠢส่ว์ࠠหีอาิ๋ࠠศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮๊๊ࠡิฬࠦๅฺ่ส๋ࠥอๆไࠢอืฯ฽ฺ๊ࠢสืฯิฯศ็ࠣห้่่ศศ่ࠤฬ๊ๅึ๊ิอࠥฮฯๅษ้๋ࠣࠦโ้ษษ้ࠥอไไฬสฬฮࠦ࠮๊ࠡฦ๎฻อࠠหีอ฻๏฿ࠠฦ์ๅหๆํวࠡใํࠤศ๐้ࠠไอࠤฯฺวยࠢ࡟ࡲࡡࡴࠠࠨඇ")+lSWzOYmN08+lw2snZ9J0uhLoxypqa(u"࠭ࠠฤะอีࠥอไร่๊ࠣํ฿ࠠศๆๅ์ฬฬๅࠡษ็ฮ๏ࠦสา์าࠤศูสฯัส้์อࠠภࠣࠪඈ")+NwROdSj3nsA)
		if uDP7kA6UcClgd2Gza0VO==w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠲ဎ"): rcupP0JQINSEVbkBfTt63qHe2 = UUobzy0xZLaVScIt7(u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪඉ")
		elif uDP7kA6UcClgd2Gza0VO==mRanX1HZupfSQVB2gsDGUO(u"࠴ဏ"): rcupP0JQINSEVbkBfTt63qHe2 = UUobzy0xZLaVScIt7(u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧඊ")
		else: rcupP0JQINSEVbkBfTt63qHe2 = nA5dhMRg6ENzsB0l1GwvH7aIr2
	else:
		FOuva426dp1XNg83zxU0SWloBci = KQctJbXeEjDhplqknU3rzi.getSetting(Pj9YaUq1ibJ(u"ࠩࡤࡺ࠳ࡳࡹࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡰࡳࡩ࡫ࠧඋ"))
		if   FOuva426dp1XNg83zxU0SWloBci==nA5dhMRg6ENzsB0l1GwvH7aIr2: uDP7kA6UcClgd2Gza0VO = n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠳တ")
		elif FOuva426dp1XNg83zxU0SWloBci==DFx6E0uON7Jm8(u"ࠪࡉࡒࡇࡄࠡࡎ࡬ࡷࡹ࠭ඌ"): uDP7kA6UcClgd2Gza0VO = xwIUQfiE7rmvYzH(u"࠵ထ")
		elif FOuva426dp1XNg83zxU0SWloBci==bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪඍ"): uDP7kA6UcClgd2Gza0VO = bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠷ဒ")
		rcupP0JQINSEVbkBfTt63qHe2 = FOuva426dp1XNg83zxU0SWloBci
	if   uDP7kA6UcClgd2Gza0VO==n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠶ဓ"): UgLxCTPB85YtdG9ysni = baBcNd81eH5ry2Olp6Mj43(u"ࠬ࠻࠵࠭࠷࠷࠸࠱࠻࠵࠶ࠩඎ")
	elif uDP7kA6UcClgd2Gza0VO==bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠱န"): UgLxCTPB85YtdG9ysni = FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠭࠵࠵࠶࠯࠹࠺࠻ࠬ࠶࠷ࠪඏ")
	elif uDP7kA6UcClgd2Gza0VO==FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠳ပ"): UgLxCTPB85YtdG9ysni = ldIfvn6asURQ9toi85EhqAXW3(u"ࠧ࠶࠷࠸࠰࠺࠻ࠬ࠶࠶࠷ࠫඐ")
	else: return
	KQctJbXeEjDhplqknU3rzi.setSetting(UUobzy0xZLaVScIt7(u"ࠨࡣࡹ࠲ࡲࡿࡳ࡬࡫ࡱ࠲ࡻ࡯ࡥࡸ࡯ࡲࡨࡪ࠭එ"),rcupP0JQINSEVbkBfTt63qHe2)
	Z2zVRhGHruYtCKdJ1nE = ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠩ࠿ࡺ࡮࡫ࡷࡴࡀࠪඒ")+UgLxCTPB85YtdG9ysni+LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠪ࠰ࠬඓ")+AQT1th2cIpzyNfG4ZuSgv+nfNTgkiWdUq(u"ࠫࡁ࠵ࡶࡪࡧࡺࡷࡃ࠭ඔ")
	dovTcp20WhEXnaVBJrmqYl6UGif = tFE1s8OzUMHLnWj4pgxvu90CYqoSm.replace(UjeLGtBf8cqXTa0x,Z2zVRhGHruYtCKdJ1nE)
	if BsLJ7p5Av2Vm0SQeCO1o: dovTcp20WhEXnaVBJrmqYl6UGif = dovTcp20WhEXnaVBJrmqYl6UGif.encode(YWEQ3Cf8RevpD0m7NjF1)
	open(clOH3ADqfydeBojFMRPS8I1,HD7MQqXd2gS(u"ࠬࡽࡢࠨඕ")).write(dovTcp20WhEXnaVBJrmqYl6UGif)
	nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,baBcNd81eH5ry2Olp6Mj43(u"࠭࠮࡝ࡶࡖ࡯࡮ࡴࠠࡅࡧࡩࡥࡺࡲࡴࠡࡘ࡬ࡩࡼࡹ࠺ࠡ࡝ࠣࠫඖ")+UgLxCTPB85YtdG9ysni+Yj1msqVeivESfrCupRy9b7WacBd(u"ࠧࠡ࡟ࠪ඗"))
	if showDialogs: SoNGUfhMDERLyHOz1qkVAj.executebuiltin(AJHaiQq3PRd5cphzGuELnVg9X(u"ࠨࡔࡨࡰࡴࡧࡤࡔ࡭࡬ࡲ࠭࠯ࠧ඘"))
	return
def wrY31coC2GSJl():
	x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,Yj1msqVeivESfrCupRy9b7WacBd(u"ࠩหี๋อๅอࠢ฼้ฬีࠠโ์๊ࠤฺ๊ใๅหࠣ฽๋ีใࠡ࠰࠱࠲ࠥหๅศࠢฦ่ส฻ฯศำࠣๆิ๐ๅࠡ࠰࠱࠲ࠥษ่ࠡษ้ฮ๋ࠥๅ็๊฼ࠤ๊์ࠠศีอาิอๅࠡษ็ฬึ์วๆฮࠣ࠲࠳࠴ࠠฤ๊่ࠣิ๐ใࠡ็ื็้ฯࠠฤะิํࠥะฮึࠢฯ๋ฬุใࠡล้ฮࠥ๎ไศࠢอาฺࠦศใ์ฬࠤำ๊โࠡษ็่์ࠦ࡜࡯࡞ࡱࠤาอ่ๅࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣวํࠦวหื็ࠤออไๆสิ้ัࠦไๆ฻ิๅฮࠦำษสࠣห้๋ิไๆฬࠤ฾์ฯไࠢ࠱࠲࠳ࠦ็ๅࠢอี๏ีࠠโฯุࠤฬ๊สฮัํฯฬะࠠศๆล๊ࠥลࠧ඙"))
	if x6zlf2tTZm==pxt6wJ8ScYMWCivoO(u"࠳ဖ"): GGvnphbiLuEtqKA()
	return
def NyacLXGD86AfB():
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,jil8vRpBsENVYyPmDd(u"๋ࠪีอࠠศๆ่์็฿ࠠๆ฼็ๆ๋ࠥๆࠡษ็ฺ้ีั๊ࠡ฽๎ึࠦๅฺำ๋ๅ๋ࠥส๋ࠢํีั฿ࠠๅๆ฼้้࠭ක"))
	return
def UFjVCoYfxQ9XyEhb():
	jr9ylNbvcHEzPG8UpkL = lSWzOYmN08+PPxYugzLZwHX23yiK(u"ࠫฯ฿ฯศัุࠣ๏฿ษࠡฤ็ࠤ๊ำๅะࠢ็ื๋ฯࠠ࠳࠲࠵࠵ࠥࡀࠠࠨඛ")+NwROdSj3nsA
	jr9ylNbvcHEzPG8UpkL += bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠬอไๆ๊ๅ฽ࠥษฯ็ษ๊ࠤๆ๐็ࠡวะูฬฬ๊สࠢ็฽ิีࠠศๆื๎฾ฯࠠโ์ࠣห้฿วๅ็ࠣฮ๊ࠦฬๆ฻๊ห๋ࠥๆࠡฮ่๎฾ࠦวๅ็ุหิืࠠศๆ่ฮํ็ัสࠢไ๎ࠥอไฦ่อี๋ะࠠศๆๅำ๏๋ษ๊ࠡส่ัี๊ะหࠣห้ำใ้็ํอࠥ๎วๅ฼ํีࠥำใ้็ํอࠥ๎ๅ็ࠢฯ้๏฿ࠠะ๊็ࠤฬู๊ศๆ่ࠤะ๋ࠠห็ࠣฮํำ๊ะ้สࠤํำำศสࠣหู้๋ะๆࠣัุฮࠠิๅส๊ࠥี่ๅࠢส่฾อไๆࠢ็ื๋ฯࠠ࠳࠲࠵࠵ࠥ๎็๋ࠢส่สำีศศํอࠥอไฤฯาฯࠥ๎วๅลื้้ࠦวๅฬํࠤฯฺ๋ࠠ็็๋ฬࠦแ๋ࠢสุ่์่ศฬࠣห้฿ิาหࠣห้๋วื์ฬࠫග")
	jr9ylNbvcHEzPG8UpkL += CXtugbqhV3+lSWzOYmN08+YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡵ࡫ࡱࡽ࠳ࡩࡣ࠰ࡵ࡫࡭ࡦࡩ࡯ࡶࡰࡷࠫඝ")+NwROdSj3nsA
	jL23e6YO9IcvVME = lSWzOYmN08+jil8vRpBsENVYyPmDd(u"ࠧษำ้ห๊าࠠีำํ฻ࠥอไๆี็้ࠥࡀࠠࠨඞ")+NwROdSj3nsA
	jL23e6YO9IcvVME += HD7MQqXd2gS(u"ࠨ้๋ࠤ฾ฮวาหࠣ฽๋ࠦศา่ส้ั๊้ࠦใิࠤ๊฿ไ้็สฮࠥำำศสํอ้ࠥห๋ำฬࠤฯํๅࠡฮ่๎฾ࠦวๅ็ึ่๊๐ๆࠡ็ฮ่ࠥษ่ใษอࠤฬ๊ีๅษฬࠤํษ่ใษอࠤฬ๊ใิ๊ไࠤํอไฯี๋ๅࠥ๎ิไๆࠣห้่ๅา๋ࠢวํ่วหࠢส่็๋ั๊ࠡฦ๎฻อ๋๊ࠠไีࠥืฤ๋หࠣห้ํไศๆࠣๅ๏ࠦฬๆ์฼ࠤิ๎ไࠡษ็฽ฬ๊ๅ๊ࠡฦ๎฻อࠠโ์๊ࠤฯ่่๋็้ࠣ๏๊วะ์ࠣ์์าั๋๋ࠢๅ๏ํࠠฤ์ูหࠥฮอฬ๋ࠢๆึอมสࠢส่็ืย็๋ࠢว๏฼วࠡใํ๋ࠥอำหะสีฮ่ࠦหใสศ้่ࠦโ์๊ࠤศ่่ศๆู้๋่ࠣษห่้ࠣษๅศ็ࠣ฽้๐้ࠠล่์ึࠦรฯำ์ࠤฯํๅࠡๅ็ࠤู๊ไๆࠢ࠱ࠤฬ๊ศา่ส้ัࠦๅไฬ๋ฬࠥฮไ฻หࠣะฬ็วࠡีๆีอะ้ࠠ์ึฮำีๅ่ࠡ฻ห๊่๋่ࠦา์ืࠦสฮฬࠣฬ๏ฬษ๊ࠡํ๊ิ๎าࠡๅสะ๏ะ้ࠠ็ัฺูࠦแใู่ࠣศา็ำหࠣห้๎๊็ั๋ึࠥ࠴ࠠศๆ่์็฿ࠠศๆิื๊๐ࠠๅๆหี๋อๅอ๊ࠢ์ࠬඟ")
	jL23e6YO9IcvVME += CXtugbqhV3+lSWzOYmN08+nfNTgkiWdUq(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡲࡻࡳ࡭࡫ࡰࡶࡺࡲࡥࡳࠩච")+NwROdSj3nsA
	a1duvQ8Vh0gNo69nDcp3Pjtym = gmPI7hVEM8nD(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩඡ")+jr9ylNbvcHEzPG8UpkL+PPxYugzLZwHX23yiK(u"ࠫࡡࡴ࡜࡯࡞ࡱ࡟ࡗ࡚ࡌ࡞ࠩජ")+jL23e6YO9IcvVME
	d9EaJh5t3Tyj7CsXFL(jil8vRpBsENVYyPmDd(u"ࠬࡸࡩࡨࡪࡷࠫඣ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,a1duvQ8Vh0gNo69nDcp3Pjtym)
	return
def woj8GNX2kh5vJfMLQ1iqxPCm3U9(aoD3bFQiButV50LwGnhkRszJSm7):
	tixadpBDCATP07oQHqz8U1JN(yy6RomT9bQhJf)
	LOYHM0pRiEKka5SfWVzxcUAlXumZt = bAQuqZOzEGe8DCH2RTwtL9(aoD3bFQiButV50LwGnhkRszJSm7)
	for MPAamFNWTvj82 in [HD7MQqXd2gS(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨඤ"),baBcNd81eH5ry2Olp6Mj43(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪඥ"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࡢࡘࡘ࠭ඦ"),DFx6E0uON7Jm8(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࡤ࡚ࡓࠨට")]:
		if MPAamFNWTvj82 in Nzp9Fq5cTr.SEND_THESE_EVENTS: Nzp9Fq5cTr.SEND_THESE_EVENTS.remove(MPAamFNWTvj82)
	QHCysKvD58UIb930e2(DFx6E0uON7Jm8(u"ࠪࡈࡔࡔࡁࡕࡋࡒࡒࡘ࠭ඨ"))
	id,QQlJ2xKXAGUzh,mGy19ecrPjKCF,ccTbOMIrUX13m4pNRfyGquCadwJE,i4LsgZVpI3cQ,reason = LOYHM0pRiEKka5SfWVzxcUAlXumZt[IpFcwrWNgefMym3qta0hYQAzOdE]
	B6O85VTcMiPW1CFXZLYfdonsSK,Bq6o5cM8TxkKD4W = ccTbOMIrUX13m4pNRfyGquCadwJE.split(gmPI7hVEM8nD(u"ࠫࡡࡴ࠻࠼ࠩඩ"))
	jL23e6YO9IcvVME,BdkeVTtAKUW9vrcqmy7,N1AwpoxOhTb9gSEFJvZKHmD6 = i4LsgZVpI3cQ.split(LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠬࡢ࡮࠼࠽ࠪඪ"))
	g3NnzJebFAMYxvWwXyP9ofE2lu4 = S5MWhgtZ37Xw
	while g3NnzJebFAMYxvWwXyP9ofE2lu4:
		HAniEdCPaFNpTmBxfSY2sXoWU = vnI6XSlmEtsx7(nA5dhMRg6ENzsB0l1GwvH7aIr2,JvQd6LMoBX4hiy1C(u"࠭ฮา๊ฯࠫණ"),bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠧฦำึห้ࠦัิษ็อ๊ࠥไๆสิ้ั࠭ඬ"),UUobzy0xZLaVScIt7(u"ࠨไสส๊ฯࠠศๆอฬึ฿วหࠩත"),bb1fgjsAq4N2xYwnoh39lm(u"ࠩ็ษ๏่วโࠢส่ส฿ไศ่สฮࠥࡀࠠࠡฬหี฾ࠦร้ࠢสุ้ำࠠศๆหี๋อๅอࠩථ"),jL23e6YO9IcvVME)
		if HAniEdCPaFNpTmBxfSY2sXoWU==UUobzy0xZLaVScIt7(u"࠵ဗ"): tMF7vySUEVJl6PwoKcmpNA = vnI6XSlmEtsx7(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,AJHaiQq3PRd5cphzGuELnVg9X(u"ࠪ฽ํีษࠨද"),nA5dhMRg6ENzsB0l1GwvH7aIr2,mRanX1HZupfSQVB2gsDGUO(u"๊ࠫฮฯฤࠢส่ฯฮัฺࠢ฽๎ึࠦโศส็ࠤ้๊ๆใษืࠫධ"),BdkeVTtAKUW9vrcqmy7,JvQd6LMoBX4hiy1C(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥࡳ࡮ࡣ࡯ࡰ࡫ࡵ࡮ࡵࠩන"))
		elif HAniEdCPaFNpTmBxfSY2sXoWU==ZjELJ9VrUT07R8Hn4FuSDcf(u"࠵ဘ"): z2JW4QB7vEgqxAX0p()
		else: g3NnzJebFAMYxvWwXyP9ofE2lu4 = FFKncZx5pDTwdiJRYhMgQSNL
	if aoD3bFQiButV50LwGnhkRszJSm7: AA5FS4hUqeP9EsZCM(FFKncZx5pDTwdiJRYhMgQSNL)
	return
def r4Sg1A7F0IqBu6k():
	V1aNDbJw975()
	YTr8vjoVGw2LNRxfAg = KQctJbXeEjDhplqknU3rzi.getSetting(VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬ඲"))
	a1duvQ8Vh0gNo69nDcp3Pjtym = {}
	a1duvQ8Vh0gNo69nDcp3Pjtym[zhE5I4xHinX0UoVZMNwlkPrR(u"ࠧࡂࡗࡗࡓࠬඳ")] = lw2snZ9J0uhLoxypqa(u"ࠨษ็็ฬฺࠠศๆอ่็อฦ๋ࠢํ฽๊๊ࠧප")
	a1duvQ8Vh0gNo69nDcp3Pjtym[ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠩࡖࡘࡔࡖࠧඵ")] = AJHaiQq3PRd5cphzGuELnVg9X(u"ࠪห้้วี่ࠢฮํ่แࠡฬ่ห๊อ้ࠠสส่่อๅๅࠩබ")
	a1duvQ8Vh0gNo69nDcp3Pjtym[Pj9YaUq1ibJ(u"ࠫࡑࡏࡍࡊࡖࡈࡈࠬභ")] = pxt6wJ8ScYMWCivoO(u"้ࠬวีࠢฯำฬࠦโึ์ิࠤฬ๊ๅะ๋ࠣ࠲ࠥ࠭ම")+str(KZxiAeszDGHJT9MmNa6WoRF05/YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠻࠶မ"))+w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠭ࠠะไํๆฮࠦแใูࠪඹ")
	ebfBXWUqDSI5AZdsiPG0t632v18xH = a1duvQ8Vh0gNo69nDcp3Pjtym[YTr8vjoVGw2LNRxfAg]
	uDP7kA6UcClgd2Gza0VO = vnI6XSlmEtsx7(nA5dhMRg6ENzsB0l1GwvH7aIr2,gmPI7hVEM8nD(u"ࠧไษืࠤࠬය")+str(KZxiAeszDGHJT9MmNa6WoRF05/AJHaiQq3PRd5cphzGuELnVg9X(u"࠼࠰ယ"))+DFx6E0uON7Jm8(u"ࠨࠢาๆ๏่ษࠨර"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠩอุ฿๐ไࠡฬ็ๆฬฬ๊ࠨ඼"),lw2snZ9J0uhLoxypqa(u"ࠪษ๏่วโࠢๆห๊๊ࠧල"),ebfBXWUqDSI5AZdsiPG0t632v18xH,JvQd6LMoBX4hiy1C(u"ࠫ์๊ࠠหำํำࠥอำหะาห๊ࠦวๅๅสุࠥอไัๅํࠤฬ๊สๅไสส๏ࠦรๆࠢอี๏ีࠠฦ์ๅหๆࠦวๅๅสุࠥฮวๅๅส้้ࠦรๆࠢอี๏ีࠠไษืࠤ฾๋ั่ࠢๅู๏ืࠠอัสࠤฤࠧࠧ඾"))
	if uDP7kA6UcClgd2Gza0VO==DFx6E0uON7Jm8(u"࠰ရ"): R1DvnUP729h = baBcNd81eH5ry2Olp6Mj43(u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭඿")
	elif uDP7kA6UcClgd2Gza0VO==xwIUQfiE7rmvYzH(u"࠲လ"): R1DvnUP729h = Qy6wlfLoOpg1(u"࠭ࡁࡖࡖࡒࠫව")
	elif uDP7kA6UcClgd2Gza0VO==xwIUQfiE7rmvYzH(u"࠴ဝ"): R1DvnUP729h = JvQd6LMoBX4hiy1C(u"ࠧࡔࡖࡒࡔࠬශ")
	else: R1DvnUP729h = nA5dhMRg6ENzsB0l1GwvH7aIr2
	if R1DvnUP729h:
		KQctJbXeEjDhplqknU3rzi.setSetting(lw2snZ9J0uhLoxypqa(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧෂ"),R1DvnUP729h)
		bbJUlFAKksOew7itSg2 = a1duvQ8Vh0gNo69nDcp3Pjtym[R1DvnUP729h]
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,bbJUlFAKksOew7itSg2)
	return
def eRYVGKwqE3fLC():
	a1duvQ8Vh0gNo69nDcp3Pjtym = {}
	a1duvQ8Vh0gNo69nDcp3Pjtym[LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠩࡄ࡙࡙ࡕࠧස")] = Pj9YaUq1ibJ(u"ࠪื๏ืแาࠢࡇࡒࡘࠦวๅฬ็ๆฬฬ๊ࠡ์฼้้ࡀࠠࠨහ")
	a1duvQ8Vh0gNo69nDcp3Pjtym[bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠫࡆ࡙ࡋࠨළ")] = DFx6E0uON7Jm8(u"ู๊ࠬาใิࠤࡉࡔࡓࠡีํ฽๊๊ࠠษ฻าࠤฬ๊ำๆษะࠤ้ํ࠺ࠡࠩෆ")
	a1duvQ8Vh0gNo69nDcp3Pjtym[Qy6wlfLoOpg1(u"࠭ࡓࡕࡑࡓࠫ෇")] = YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠧิ์ิๅึࠦࡄࡏࡕ้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪ෈")
	p1BNKcLwXas = KQctJbXeEjDhplqknU3rzi.getSetting(UUobzy0xZLaVScIt7(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡩࡴࡳࠨ෉"))
	YTr8vjoVGw2LNRxfAg = KQctJbXeEjDhplqknU3rzi.getSetting(rCmGE4YIDaZA(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷ්ࠬ"))
	ebfBXWUqDSI5AZdsiPG0t632v18xH = a1duvQ8Vh0gNo69nDcp3Pjtym[YTr8vjoVGw2LNRxfAg]+p1BNKcLwXas
	uDP7kA6UcClgd2Gza0VO = vnI6XSlmEtsx7(nA5dhMRg6ENzsB0l1GwvH7aIr2,yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠪฮูเ๊ๅࠢ฼๊ิࠦวๅ็๋หๆ่ษࠨ෋"),mRanX1HZupfSQVB2gsDGUO(u"ࠫฯฺฺ๋ๆࠣฮ้่วว์ࠪ෌"),ldIfvn6asURQ9toi85EhqAXW3(u"ࠬห๊ใษไࠤ่อๅๅࠩ෍"),ebfBXWUqDSI5AZdsiPG0t632v18xH,xwIUQfiE7rmvYzH(u"࠭ำ๋ำไีࠥࡊࡎࡔ๊ࠢ์ࠥา็ศิࠣๅ๏ࠦวๅว้ฮึ์๊หࠢํๆํ๋ࠠษฬะ์๏๊ࠠฤี่หฦࠦวๅ็๋ห็฿้ࠠษ็ื๏ืแาษอࠤส๊้ࠡลิๆฬ๋้ࠠ฻้ำࠥฮูืࠢส่๋อำࠡ์ๅ์๊ࠦศฮฮหࠤํ๋ๆฺ๋ࠢั฻ืࠠษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ࠴ࠠๅฬื฾๏๊ࠠิ์ิๅึࠦࡄࡏࡕࠣๆ๊ࠦศศะอ๎ฬืࠠศๆึ๎ึ็ัࠡษ็้๋อำษࠢฦ์่ࠥๅࠡสศ๎็อแ่ࠢหห้้วๆๆࠪ෎"))
	if uDP7kA6UcClgd2Gza0VO==Qy6wlfLoOpg1(u"࠳သ"): R1DvnUP729h = VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠧࡂࡕࡎࠫා")
	elif uDP7kA6UcClgd2Gza0VO==rCmGE4YIDaZA(u"࠵ဟ"): R1DvnUP729h = n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠨࡃࡘࡘࡔ࠭ැ")
	elif uDP7kA6UcClgd2Gza0VO==UUobzy0xZLaVScIt7(u"࠷ဠ"): R1DvnUP729h = yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠩࡖࡘࡔࡖࠧෑ")
	if uDP7kA6UcClgd2Gza0VO in [w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠰ဢ"),JvQd6LMoBX4hiy1C(u"࠷အ")]:
		x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(JvQd6LMoBX4hiy1C(u"ࠪࡧࡪࡴࡴࡦࡴࠪි"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ุࠫ๐ัโำ࠽ࠤࠬී")+Nzp9Fq5cTr.DNS_SERVERS[UnOIK1WBbw2],nfNTgkiWdUq(u"ู๊ࠬาใิ࠾ࠥ࠭ු")+Nzp9Fq5cTr.DNS_SERVERS[IpFcwrWNgefMym3qta0hYQAzOdE],nA5dhMRg6ENzsB0l1GwvH7aIr2,FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠭รฯฬสีู๊ࠥาใิࠤࡉࡔࡓࠡษ็้๋อำษࠢ็็ࠬ෕"))
		if x6zlf2tTZm==LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠲ဣ"): jjyQ5ePm9EoDVl = Nzp9Fq5cTr.DNS_SERVERS[IpFcwrWNgefMym3qta0hYQAzOdE]
		else: jjyQ5ePm9EoDVl = Nzp9Fq5cTr.DNS_SERVERS[UnOIK1WBbw2]
	elif uDP7kA6UcClgd2Gza0VO==Yj1msqVeivESfrCupRy9b7WacBd(u"࠴ဤ"): jjyQ5ePm9EoDVl = nA5dhMRg6ENzsB0l1GwvH7aIr2
	else: R1DvnUP729h = nA5dhMRg6ENzsB0l1GwvH7aIr2
	if R1DvnUP729h:
		KQctJbXeEjDhplqknU3rzi.setSetting(LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪූ"),R1DvnUP729h)
		KQctJbXeEjDhplqknU3rzi.setSetting(rCmGE4YIDaZA(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡩࡴࡳࠨ෗"),jjyQ5ePm9EoDVl)
		bbJUlFAKksOew7itSg2 = a1duvQ8Vh0gNo69nDcp3Pjtym[R1DvnUP729h]+jjyQ5ePm9EoDVl
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,bbJUlFAKksOew7itSg2)
	return
def MharB6d3C19cipgKS5GAZFbNowzJ8():
	YTr8vjoVGw2LNRxfAg = KQctJbXeEjDhplqknU3rzi.getSetting(VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧෘ"))
	a1duvQ8Vh0gNo69nDcp3Pjtym = {}
	a1duvQ8Vh0gNo69nDcp3Pjtym[mRanX1HZupfSQVB2gsDGUO(u"ࠪࡅ࡚࡚ࡏࠨෙ")] = vzqjsVHSBlMpxC(u"ࠫฬ๊ศา๊ๆื๏ࠦวๅฬ็ๆฬฬ๊ࠡฮส๋ืࠦไๅ฻่่ࠬේ")
	a1duvQ8Vh0gNo69nDcp3Pjtym[Pj9YaUq1ibJ(u"ࠬࡇࡓࡌࠩෛ")] = DFx6E0uON7Jm8(u"࠭วๅสิ์ู่๊ࠡีํ฽๊๊ࠠษ฻าࠤฬ๊ำๆษะࠤ้ํࠧො")
	a1duvQ8Vh0gNo69nDcp3Pjtym[n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠧࡔࡖࡒࡔࠬෝ")] = gmPI7hVEM8nD(u"ࠨษ็ฬึ๎ใิ์้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪෞ")
	ebfBXWUqDSI5AZdsiPG0t632v18xH = a1duvQ8Vh0gNo69nDcp3Pjtym[YTr8vjoVGw2LNRxfAg]
	uDP7kA6UcClgd2Gza0VO = vnI6XSlmEtsx7(nA5dhMRg6ENzsB0l1GwvH7aIr2,bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠩอุ฿๐ไࠡ฻้ำࠥอไๆ๊สๅ็ฯࠧෟ"),bb1fgjsAq4N2xYwnoh39lm(u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩ෠"),zhE5I4xHinX0UoVZMNwlkPrR(u"ࠫส๐โศใࠣ็ฬ๋ไࠨ෡"),ebfBXWUqDSI5AZdsiPG0t632v18xH,n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠬอไษำ๋็ุ๐่๊ࠠࠣะ์อาࠡใํࠤฬ๊ล็ฬิ๊๏ะ๋ࠠ฻่่ࠥ๎ำู๋ࠣฬ๏์ࠠอ้สึ่่ࠦศๆศ๊ฯืๆ๋ฬࠣ࠲ࠥํ่ࠡ์ึฮุ้๋ࠠๆหหฯ้้ࠠ์ๅ์๊ࠦศิฯห๋ฬࠦศะๆสࠤ๊์ใࠡอ่ࠤ๏ฮูฬ้สࠤ้้ࠠ࠯๊่ࠢࠥะั๋ัࠣฮูเ๊ๅࠢฦ้ࠥห๊ใษไࠤฬ๊ศา๊ๆื๏ࠦฟࠨ෢"))
	if uDP7kA6UcClgd2Gza0VO==w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠳ဥ"): R1DvnUP729h = XEcWOIwkZKubV7vQ(u"࠭ࡁࡔࡍࠪ෣")
	elif uDP7kA6UcClgd2Gza0VO==gmPI7hVEM8nD(u"࠵ဦ"): R1DvnUP729h = LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠧࡂࡗࡗࡓࠬ෤")
	elif uDP7kA6UcClgd2Gza0VO==ldIfvn6asURQ9toi85EhqAXW3(u"࠷ဧ"): R1DvnUP729h = xwIUQfiE7rmvYzH(u"ࠨࡕࡗࡓࡕ࠭෥")
	else: R1DvnUP729h = nA5dhMRg6ENzsB0l1GwvH7aIr2
	if R1DvnUP729h:
		KQctJbXeEjDhplqknU3rzi.setSetting(bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧ෦"),R1DvnUP729h)
		bbJUlFAKksOew7itSg2 = a1duvQ8Vh0gNo69nDcp3Pjtym[R1DvnUP729h]
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,bbJUlFAKksOew7itSg2)
	return
def Ft2wcxR5Y16QLzvrW8gMOSZVebCk9():
	N0IdRQ8lsWFhiSTXG1pZ4u = KQctJbXeEjDhplqknU3rzi.getSetting(rCmGE4YIDaZA(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡨࡧࡣࡩࡧࠪ෧"))
	if N0IdRQ8lsWFhiSTXG1pZ4u==xwIUQfiE7rmvYzH(u"ࠫࡘ࡚ࡏࡑࠩ෨"): header = UUobzy0xZLaVScIt7(u"ࠬะฮำ์้ࠤฬ๊โ้ษษ้๋ࠥส้ไไࠫ෩")
	else: header = FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠭สฯิํ๊ࠥอไใ๊สส๊ࠦๅโ฻็ࠫ෪")
	x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,PPxYugzLZwHX23yiK(u"ࠧฦ์ๅหๆ࠭෫"),baBcNd81eH5ry2Olp6Mj43(u"ࠨฬไ฽๏๊ࠧ෬"),header,Yj1msqVeivESfrCupRy9b7WacBd(u"ࠩๅ์ฬฬๅࠡษ็ฬึ์วๆฮࠣ๎ฯ๋ࠠหฯา๎ะํวࠡล๋ฮํ๋วห์ๆ๎ฬࠦศฺัࠣ࠵࠻ࠦำศ฻ฬࠤ๊์ࠠฤ๊็ࠤศูสฯัส้ࠥ࠴࠮๊ࠡศ๎็อแࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠡ์วำ๏ࠦลๅ๋ࠣฮาี๊ฬ้สࠤๆ๐ࠠไๆ้ࠣึฯ๋ࠠฬ่ࠤฬูสฯัส้ࠥอไใ๊สส๊ࠦ࠮࠯๋๋ࠢีอ๋ࠠีหฬࠥฮืวࠢไ๎ࠥ็สฮࠢๅ์ฬฬๅࠡษ็ฬึ์วๆฮ࡟ࡲࡡࡴ่ࠠๆࠣฮึ๐ฯࠡฬไ฽๏๊ࠠฤ็ࠣษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠢยࠥࠦ࠭෭"))
	if x6zlf2tTZm==-XEcWOIwkZKubV7vQ(u"࠷ဨ"): return
	elif x6zlf2tTZm:
		KQctJbXeEjDhplqknU3rzi.setSetting(UUobzy0xZLaVScIt7(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡨࡧࡣࡩࡧࠪ෮"),n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠫࡆ࡛ࡔࡐࠩ෯"))
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,nfNTgkiWdUq(u"ࠬะๅࠡฬไ฽๏๊ࠠหะี๎๋ࠦวๅไ๋หห๋ࠧ෰"))
	else:
		KQctJbXeEjDhplqknU3rzi.setSetting(ldIfvn6asURQ9toi85EhqAXW3(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭෱"),bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠧࡔࡖࡒࡔࠬෲ"))
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠨฬ่ࠤส๐โศใࠣฮำุ๊็ࠢส่็๎วว็ࠪෳ"))
	return
def YYwlpitP5zbxXodGR(OOrjZaTIVXQ2Sp0ozhc):
	if OOrjZaTIVXQ2Sp0ozhc!=nA5dhMRg6ENzsB0l1GwvH7aIr2:
		OOrjZaTIVXQ2Sp0ozhc = KK3yegFpzo45D7(OOrjZaTIVXQ2Sp0ozhc)
		OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.decode(YWEQ3Cf8RevpD0m7NjF1).encode(YWEQ3Cf8RevpD0m7NjF1)
		x2NPyoqfetTjYi8HKIs = rCmGE4YIDaZA(u"࠱࠱࠳࠳࠷ဩ")
		wJ0IQEktls6OPAhMUR92V = z3jwnDkZ76OfKFB1rRoQVghbE0u92.Window(x2NPyoqfetTjYi8HKIs)
		wJ0IQEktls6OPAhMUR92V.getControl(jil8vRpBsENVYyPmDd(u"࠴࠳࠴ဪ")).setLabel(OOrjZaTIVXQ2Sp0ozhc)
	return
k2kv0fLH96 = [
			 Qy6wlfLoOpg1(u"ࠤࡨࡼࡹ࡫࡮ࡴ࡫ࡲࡲࠥࡧࡶࡴࡲࡤࡧࡪࡹ࠰ࠡ࡫ࡶࠤࡳࡵࡴࠡࡥࡸࡶࡷ࡫࡮ࡵ࡮ࡼࠤࡸࡻࡰࡱࡱࡵࡸࡪࡪࠢ෴")
			,gmPI7hVEM8nD(u"ࠪࡇ࡭࡫ࡣ࡬࡫ࡱ࡫ࠥ࡬࡯ࡳࠢࡐࡥࡱ࡯ࡣࡪࡱࡸࡷࠥࡹࡣࡳ࡫ࡳࡸࡸ࠭෵")
			,jil8vRpBsENVYyPmDd(u"ࠫࡕ࡜ࡒࠡࡋࡓࡘ࡛ࠦࡓࡪ࡯ࡳࡰࡪࠦࡃ࡭࡫ࡨࡲࡹ࠭෶")
			,bqCDnV7Bs5XgRvuKLNAa1Uz(u"࡛ࠬ࡮࡬ࡰࡲࡻࡳࠦࡖࡪࡦࡨࡳࠥࡏ࡮ࡧࡱࠣࡏࡪࡿࠧ෷")
			,bb1fgjsAq4N2xYwnoh39lm(u"࠭ࡴࡩ࡫ࡶࠤ࡭ࡧࡳࡩࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤ࡮ࡹࠠࡣࡴࡲ࡯ࡪࡴࠧ෸")
			,UUobzy0xZLaVScIt7(u"ࠧࡶࡵࡨࡷࠥࡶ࡬ࡢ࡫ࡱࠤࡍ࡚ࡔࡑࠢࡩࡳࡷࠦࡡࡥࡦ࠰ࡳࡳࠦࡤࡰࡹࡱࡰࡴࡧࡤࡴࠩ෹")
			,rCmGE4YIDaZA(u"ࠨࡣࡧࡺࡦࡴࡣࡦࡦ࠰ࡹࡸࡧࡧࡦ࠰࡫ࡸࡲࡲࠧ෺")+UUobzy0xZLaVScIt7(u"ࠩࠦࠫ෻")+jil8vRpBsENVYyPmDd(u"ࠪࡷࡸࡲ࠭ࡸࡣࡵࡲ࡮ࡴࡧࡴࠩ෼")
			,rCmGE4YIDaZA(u"ࠫࡎࡴࡳࡦࡥࡸࡶࡪࡘࡥࡲࡷࡨࡷࡹ࡝ࡡࡳࡰ࡬ࡲ࡬࠲ࠧ෽")
			,ldIfvn6asURQ9toi85EhqAXW3(u"ࠬࡋࡲࡳࡱࡵࠤ࡬࡫ࡴࡵ࡫ࡱ࡫ࠥࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠵࠿࡮ࡱࡧࡩࡪࡃ࠰ࠧࡶࡨࡼࡹࡺ࠽ࠨ෾")
			,Qy6wlfLoOpg1(u"࠭ࡷࡢࡴࡱ࡭ࡳ࡭ࡳ࠯ࡹࡤࡶࡳ࠮ࠧ෿")
			,n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠧ࡟ࡠࡡࡢࡣ࠭฀")
			,Yj1msqVeivESfrCupRy9b7WacBd(u"ࠨࡎࡲࡥࡩ࡯࡮ࡨࠢࡶ࡯࡮ࡴࠠࡧ࡫࡯ࡩ࠿࠭ก")
			,ldIfvn6asURQ9toi85EhqAXW3(u"ࠩ࡯ࡥࡷ࡭ࡥࠡࡣࡸࡨ࡮ࡵࠠࡴࡻࡱࡧࠥ࡫ࡲࡳࡱࡵ࠾ࠬข")
			,AJHaiQq3PRd5cphzGuELnVg9X(u"ࠪ࡭ࡳ࡬࡯࠻ࠢࡐࡩࡩ࡯ࡡࡤࡱࡧࡩࡨࠦࡤࡦࡥࡲࡨࡪࡸ࠺ࠨฃ")
			]
def XdreTYjbAoJPv5fLsxc103CFVy(PWjQyhAkS3RaGzNJUTvC6HiXsOLY):
	if JvQd6LMoBX4hiy1C(u"ࠫࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡹ࡫ࡪࡰࠣࡪ࡮ࡲࡥ࠻ࠩค") in PWjQyhAkS3RaGzNJUTvC6HiXsOLY and XEcWOIwkZKubV7vQ(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪฅ") in PWjQyhAkS3RaGzNJUTvC6HiXsOLY: return S5MWhgtZ37Xw
	for OOrjZaTIVXQ2Sp0ozhc in k2kv0fLH96:
		if OOrjZaTIVXQ2Sp0ozhc in PWjQyhAkS3RaGzNJUTvC6HiXsOLY: return S5MWhgtZ37Xw
	return FFKncZx5pDTwdiJRYhMgQSNL
def xqYz9lmBbsZ4rhC2(data):
	T4TcVyaPIWx6nqQlZYvrG = AJHaiQq3PRd5cphzGuELnVg9X(u"࠺ာ") if BsLJ7p5Av2Vm0SQeCO1o else UUobzy0xZLaVScIt7(u"࠳࠸ါ")
	data = data.replace(pxt6wJ8ScYMWCivoO(u"࠷࠵ိ")*hSXlxL9iB05c,T4TcVyaPIWx6nqQlZYvrG*hSXlxL9iB05c)
	data = data.replace(UUobzy0xZLaVScIt7(u"࠭ࠠ࠽ࡩࡨࡲࡪࡸࡡ࡭ࡀ࠽ࠤࠬฆ"),HD7MQqXd2gS(u"ࠧ࠻ࠢࠪง"))
	rA4ZGoQyIHlneVfzNukWd = nA5dhMRg6ENzsB0l1GwvH7aIr2
	for PWjQyhAkS3RaGzNJUTvC6HiXsOLY in data.splitlines():
		ZSw6Tpcd8A3XLxI = PAztbuyYo4Kvd.findall(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠨࠢࠣࠤࠥࠦࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠮ࠪࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧจ"),PWjQyhAkS3RaGzNJUTvC6HiXsOLY,PAztbuyYo4Kvd.DOTALL)
		if ZSw6Tpcd8A3XLxI: PWjQyhAkS3RaGzNJUTvC6HiXsOLY = PWjQyhAkS3RaGzNJUTvC6HiXsOLY.replace(ZSw6Tpcd8A3XLxI[IpFcwrWNgefMym3qta0hYQAzOdE],nA5dhMRg6ENzsB0l1GwvH7aIr2)
		rA4ZGoQyIHlneVfzNukWd += CXtugbqhV3+PWjQyhAkS3RaGzNJUTvC6HiXsOLY
	return rA4ZGoQyIHlneVfzNukWd
def qZacwbvB25oEn7(wHRdDumb1PNl6vypMngXzhiGZt):
	if vzqjsVHSBlMpxC(u"ࠩࡒࡐࡉ࠭ฉ") in wHRdDumb1PNl6vypMngXzhiGZt:
		JLs76xrNFmY1w0SGao345IglCv = JRUTFhVSfB5wjt6YL
		header = xwIUQfiE7rmvYzH(u"ࠪๆึอมสࠢสุ่าไࠡษ็ๆิ๐ๅࠡมࠪช")
	else:
		JLs76xrNFmY1w0SGao345IglCv = Mtgex07pkPUj6z
		header = FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠫ็ืวยหࠣหู้ฬๅࠢส่าอไ๋ࠢยࠫซ")
	x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,header,FVxoQ2J5Mfv3Zj6sy9uhOS(u"ูࠬฬๅࠢส่ศิืศรࠣ๎าะ่๋ࠢฦ๎฻อฺࠠๆ์ࠤุาไࠡษ็หุะฮะษ่ࠤ࠳่ࠦศๆสฯ๋๐ๆุࠡิ์ึ๐ษࠡๆ่฽ึ็ษࠡๅํๅࠥำฯฬฬࠣห้๋ิไๆฬࠤํ๋ว้๋ࠡࠤฬ๊ๅไษ้ࠤฬ๊ะ๋ࠢึฬอࠦอะ๊ฮࠤฬ๊ๅีๅ็อࠥ࠴ࠠไ๊า๎ࠥ๐อหใ฻ࠤอูฬๅ์้ࠤ࠳ࠦวๅล๋่ࠥํ่ࠡษ็ืั๊ࠠศๆะห้๐้ࠠใํู๋๋ࠥๅ๊่หฯࠦสษัฦࠤ๊์ะࠡสาห๏ฯࠠศๆอุ฿๐ไࠡษ็ัฬ๊๊ࠡๆหี๋อๅอࠢๆ์ิ๐้ࠠษ็ํࠥอไร่ࠣ࠲ࠥษๅศࠢสุ่าไࠡษ็ๆิ๐ๅࠡใ๊์ࠥอไิฮ็ࠤฬ๊ำศสๅࠤฬ๊ะ๋ࠢอ้ࠥาๅฺ้้๋ࠣࠦศา่ส้ัࠦใ้ัํࠤ็ฮไࠡฤัีࠥหืโษฤࠤ้ํࠠ࠯๊่ࠢࠥะั๋ัࠣห้อำห็ิหึࠦฟࠨฌ"))
	if x6zlf2tTZm!=yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠶ီ"): return
	ZDjJCQInmA9h3SgrLeiFKBfaNtsuO,qCKtN0J5Arb = [],yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠶ု")
	size,count = cpNjIxZEUORvTw(JLs76xrNFmY1w0SGao345IglCv)
	file = open(JLs76xrNFmY1w0SGao345IglCv,nfNTgkiWdUq(u"࠭ࡲࡣࠩญ"))
	if size>XEcWOIwkZKubV7vQ(u"࠲࠲࠳࠶࠵࠶ေ"): file.seek(-VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠱࠱࠲࠴࠴࠵ူ"),XoZRpFe7B6gnfA.SEEK_END)
	data = file.read()
	file.close()
	if BsLJ7p5Av2Vm0SQeCO1o: data = data.decode(YWEQ3Cf8RevpD0m7NjF1)
	data = xqYz9lmBbsZ4rhC2(data)
	Df6jx49PNm8 = data.split(CXtugbqhV3)
	for PWjQyhAkS3RaGzNJUTvC6HiXsOLY in reversed(Df6jx49PNm8):
		i9ToEhrJRmp = XdreTYjbAoJPv5fLsxc103CFVy(PWjQyhAkS3RaGzNJUTvC6HiXsOLY)
		if i9ToEhrJRmp: continue
		PWjQyhAkS3RaGzNJUTvC6HiXsOLY = PWjQyhAkS3RaGzNJUTvC6HiXsOLY.replace(XEcWOIwkZKubV7vQ(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࡠࠩฎ"),lSWzOYmN08+bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠨࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫฏ")+NwROdSj3nsA)
		PWjQyhAkS3RaGzNJUTvC6HiXsOLY = PWjQyhAkS3RaGzNJUTvC6HiXsOLY.replace(rCmGE4YIDaZA(u"ࠩࡈࡖࡗࡕࡒ࠻ࠩฐ"),pxt6wJ8ScYMWCivoO(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆ࠱࠲࠳࠴ࡢ࠭ฑ")+nfNTgkiWdUq(u"ࠫࡊࡘࡒࡐࡔ࠽ࠫฒ")+NwROdSj3nsA)
		SgbQaz9Y1cnqHfWOxPdwo5v = nA5dhMRg6ENzsB0l1GwvH7aIr2
		qqboA7uVCnZD = PAztbuyYo4Kvd.findall(ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠬࡤࠨ࡝ࡦ࠮࠱࠭ࡢࡤࠬ࠯࡟ࡨ࠰ࠦ࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤ࡚ࠬࠫࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬณ"),PWjQyhAkS3RaGzNJUTvC6HiXsOLY,PAztbuyYo4Kvd.DOTALL)
		if qqboA7uVCnZD:
			PWjQyhAkS3RaGzNJUTvC6HiXsOLY = PWjQyhAkS3RaGzNJUTvC6HiXsOLY.replace(qqboA7uVCnZD[IpFcwrWNgefMym3qta0hYQAzOdE][IpFcwrWNgefMym3qta0hYQAzOdE],qqboA7uVCnZD[IpFcwrWNgefMym3qta0hYQAzOdE][UnOIK1WBbw2]).replace(qqboA7uVCnZD[IpFcwrWNgefMym3qta0hYQAzOdE][udq5tP0hwifHQCGYELDbOUI],nA5dhMRg6ENzsB0l1GwvH7aIr2)
			SgbQaz9Y1cnqHfWOxPdwo5v = qqboA7uVCnZD[IpFcwrWNgefMym3qta0hYQAzOdE][UnOIK1WBbw2]
		else:
			qqboA7uVCnZD = PAztbuyYo4Kvd.findall(w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠭࡞ࠩ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠭ࠦࡔ࠻࡞ࡧ࠯࠮࠭ด"),PWjQyhAkS3RaGzNJUTvC6HiXsOLY,PAztbuyYo4Kvd.DOTALL)
			if qqboA7uVCnZD:
				PWjQyhAkS3RaGzNJUTvC6HiXsOLY = PWjQyhAkS3RaGzNJUTvC6HiXsOLY.replace(qqboA7uVCnZD[IpFcwrWNgefMym3qta0hYQAzOdE][UnOIK1WBbw2],nA5dhMRg6ENzsB0l1GwvH7aIr2)
				SgbQaz9Y1cnqHfWOxPdwo5v = qqboA7uVCnZD[IpFcwrWNgefMym3qta0hYQAzOdE][IpFcwrWNgefMym3qta0hYQAzOdE]
		if SgbQaz9Y1cnqHfWOxPdwo5v: PWjQyhAkS3RaGzNJUTvC6HiXsOLY = PWjQyhAkS3RaGzNJUTvC6HiXsOLY.replace(SgbQaz9Y1cnqHfWOxPdwo5v,bbTCMJwEx8nhN4X+SgbQaz9Y1cnqHfWOxPdwo5v+NwROdSj3nsA)
		ZDjJCQInmA9h3SgrLeiFKBfaNtsuO.append(PWjQyhAkS3RaGzNJUTvC6HiXsOLY)
		if len(str(ZDjJCQInmA9h3SgrLeiFKBfaNtsuO))>VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠷࠳࠵࠵࠶ဲ"): break
	ZDjJCQInmA9h3SgrLeiFKBfaNtsuO = reversed(ZDjJCQInmA9h3SgrLeiFKBfaNtsuO)
	cWiyehb8ELY7V2Cp0 = CXtugbqhV3.join(ZDjJCQInmA9h3SgrLeiFKBfaNtsuO)
	d9EaJh5t3Tyj7CsXFL(HD7MQqXd2gS(u"ࠧ࡭ࡧࡩࡸࠬต"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠨฤัีࠥษำุำࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠬถ"),cWiyehb8ELY7V2Cp0,bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡸࡳࡡ࡭࡮ࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬท"))
	return
def K67Fn0Lj3z2aSWU():
	zXtvWfmyCQH5SpPs1hGF6OgKuRUnBi = open(DzNFIcTdp0e,rCmGE4YIDaZA(u"ࠪࡶࡧ࠭ธ")).read()
	if BsLJ7p5Av2Vm0SQeCO1o: zXtvWfmyCQH5SpPs1hGF6OgKuRUnBi = zXtvWfmyCQH5SpPs1hGF6OgKuRUnBi.decode(YWEQ3Cf8RevpD0m7NjF1)
	zXtvWfmyCQH5SpPs1hGF6OgKuRUnBi = zXtvWfmyCQH5SpPs1hGF6OgKuRUnBi.replace(baBcNd81eH5ry2Olp6Mj43(u"ࠫࡡࡺࠧน"),PPxYugzLZwHX23yiK(u"ࠬࠦࠠࠡࠢࠣࠤࠥࠦࠧบ"))
	KxieNnJUoIR9uj = PAztbuyYo4Kvd.findall(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠭ࠨࡷ࡞ࡧ࠲࠯ࡅࠩ࡜࡞ࡱࡠࡷࡣࠧป"),zXtvWfmyCQH5SpPs1hGF6OgKuRUnBi,PAztbuyYo4Kvd.DOTALL)
	for PWjQyhAkS3RaGzNJUTvC6HiXsOLY in KxieNnJUoIR9uj:
		zXtvWfmyCQH5SpPs1hGF6OgKuRUnBi = zXtvWfmyCQH5SpPs1hGF6OgKuRUnBi.replace(PWjQyhAkS3RaGzNJUTvC6HiXsOLY,lSWzOYmN08+PWjQyhAkS3RaGzNJUTvC6HiXsOLY+NwROdSj3nsA)
	VryRxo21PBngU3(bb1fgjsAq4N2xYwnoh39lm(u"ࠧศๆอ฾๏๐ัศฬࠣห้ษฮ๋ำฬࠤๆ๐ࠠศๆหีฬ๋ฬࠨผ"),zXtvWfmyCQH5SpPs1hGF6OgKuRUnBi)
	return
def Icay8uMD1UTLJ4():
	jr9ylNbvcHEzPG8UpkL = zhE5I4xHinX0UoVZMNwlkPrR(u"ࠨส฼ฺࠥอไฤิิหึูࠦๅ๋ࠣห้ื๊ๆ๊อࠤ่๎ๆหำ๋่ࠥะ่โำࠣษ๊้ว็์ฬࠤฯ่ฯ๋็ࠣ์ฯษฮ๋ำࠣห้็๊ะ์๋ࠤํํะ่ࠢส่ศุัศำ๋ࠣ๏ࠦวๅลึ๋๊่ࠦศๆฦี็อๅࠡ็฼ࠤอ฿ึ๊ࠡๆห้ะวๅ์ࠪฝ")
	jL23e6YO9IcvVME = zhE5I4xHinX0UoVZMNwlkPrR(u"ࠩ็ฮ็ี๊ๆࠢส่ๆ๐ฯ๋๊ࠣหุะฮะ็ࠣหู้็ๆࠢส่๏๋๊็๋่ࠢฯษฮ๋ำ๊ࠤฬูสฯั่ࠤฬ๊ำ่็ࠣห้๐ำศำࠣ࠲ࠥษๅศࠢ฼ำฮࠦวิ้่ࠤ๊ะสศๆํอࠥ็็ั้ࠣฮ็๎ๅࠡสอัึ๐ใࠡษ็ๅ๏ี๊้ࠢห์็ะࠠศๅหี๋ࠥๆ๊ࠡๅฮࠥอไิ้่ࠤฬ๊่ศฯาࠤ࠳ࠦรๆษࠣหู้็ๆࠢส่ศ฿ไ๊๋ࠢห้ษำโๆࠣๅ์๎๋ࠠฯิ็ࠥอไโ์า๎ํࠦลๅ๋ࠣห้ษๅศ็ࠣวํࠦลๅ๋ࠣห้๎ัศรࠣ์้้ๆࠡสๅๅืฯࠠไสํีฮ࠭พ")
	BdkeVTtAKUW9vrcqmy7 = bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠪว๊อࠠศๆฦี็อๅࠡใ๊๎ࠥะำหะา้๊ࠥไหไา๎๊่ࠦศๆอวำ๐ั๊ࠡ็็๋ࠦศๆไาหึูࠦะัࠣห้ั่ศ่ํࠤํอไะไสส็ࠦ࠮ࠡ็ฮ่ฬࠦัใ็ࠣ࠹࠹࠺ࠠห฻้๎ࠥ࠻ࠠะไสส็่ࠦࠡ࠶࠷ࠤะอๆ๋หࠣษ้๏ࠠศๆฦ้ฬ๋ࠠฤ๊ࠣษ้๏ࠠศๆ๋ีฬวࠠษฯึฬࠥอำหะาห๊้ࠠๅๆึ๋๊ࠦวๅ์่๎๋ࠦร้ࠢึ๋๊ࠦวๅ์ึหึ࠭ฟ")
	a1duvQ8Vh0gNo69nDcp3Pjtym = jr9ylNbvcHEzPG8UpkL+bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠫ࠿ࠦࠧภ")+jL23e6YO9IcvVME+zhE5I4xHinX0UoVZMNwlkPrR(u"ࠬࠦ࠮ࠡࠩม")+BdkeVTtAKUW9vrcqmy7
	d9EaJh5t3Tyj7CsXFL(lw2snZ9J0uhLoxypqa(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ย"),OksCHeoL5SG,a1duvQ8Vh0gNo69nDcp3Pjtym,bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪร"))
	return
def gitJOXchdnSNVpjbLAKPq6Ds41WRuI(type,a1duvQ8Vh0gNo69nDcp3Pjtym,showDialogs=S5MWhgtZ37Xw,url=nA5dhMRg6ENzsB0l1GwvH7aIr2,FjO41UWNvs0Gg=nA5dhMRg6ENzsB0l1GwvH7aIr2,OOrjZaTIVXQ2Sp0ozhc=nA5dhMRg6ENzsB0l1GwvH7aIr2,ty4u3WxGfEALovcCgkObzlKUnID7=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	PcIFK3fokRnTJVUX = S5MWhgtZ37Xw
	if not Nzp9Fq5cTr.sz6qutHF1ITYr0a3cGJKOf:
		if showDialogs:
			vbFPEcLnUwMjVIz9 = (XEcWOIwkZKubV7vQ(u"ࠨษ็ื฼ื࠺ࠨฤ") in a1duvQ8Vh0gNo69nDcp3Pjtym and FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠩส่๊้ว็࠼ࠪล") in a1duvQ8Vh0gNo69nDcp3Pjtym and vzqjsVHSBlMpxC(u"ࠪห้๋ไโ࠼ࠪฦ") in a1duvQ8Vh0gNo69nDcp3Pjtym and yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠫฬ๊ฮุลࠪว") in a1duvQ8Vh0gNo69nDcp3Pjtym and Qy6wlfLoOpg1(u"ࠬอไๆืาี࠿࠭ศ") in a1duvQ8Vh0gNo69nDcp3Pjtym)
			if not vbFPEcLnUwMjVIz9: PcIFK3fokRnTJVUX = bjyB5J1QuNaIXOx9qSwm4v0edDhg(w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ษ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,bb1fgjsAq4N2xYwnoh39lm(u"่ࠧๆࠣฮึูไ้ࠡำ๋ࠥอไาีส่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠫส"),a1duvQ8Vh0gNo69nDcp3Pjtym.replace(vzqjsVHSBlMpxC(u"ࠨ࡞࡟ࡲࠬห"),CXtugbqhV3))
	elif showDialogs:
		a1duvQ8Vh0gNo69nDcp3Pjtym = gmPI7hVEM8nD(u"ࠩ࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไสࠩฬ")
		rNE4b89cjX65uWU3 = bjyB5J1QuNaIXOx9qSwm4v0edDhg(AJHaiQq3PRd5cphzGuELnVg9X(u"ࠪࡧࡪࡴࡴࡦࡴࠪอ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,mRanX1HZupfSQVB2gsDGUO(u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫฮ")+HD7MQqXd2gS(u"ࠬࠦࠠ࠲࠱࠸ࠫฯ"),n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫะ"))
		wr1XbnRhoplS2kP9zsgtmqT = bjyB5J1QuNaIXOx9qSwm4v0edDhg(Yj1msqVeivESfrCupRy9b7WacBd(u"ࠧࡤࡧࡱࡸࡪࡸࠧั"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,JvQd6LMoBX4hiy1C(u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨา")+pxt6wJ8ScYMWCivoO(u"ࠩࠣࠤ࠷࠵࠵ࠨำ"),ldIfvn6asURQ9toi85EhqAXW3(u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨิ"))
		UUx7Vi5D0YeTFKE = bjyB5J1QuNaIXOx9qSwm4v0edDhg(Yj1msqVeivESfrCupRy9b7WacBd(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫี"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,Qy6wlfLoOpg1(u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬึ")+VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠭ࠠࠡ࠵࠲࠹ࠬื"),lw2snZ9J0uhLoxypqa(u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อุࠬ"))
		CxJ1LlyWriUwS8 = bjyB5J1QuNaIXOx9qSwm4v0edDhg(pxt6wJ8ScYMWCivoO(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨู"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,mRanX1HZupfSQVB2gsDGUO(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไฺࠩ")+mRanX1HZupfSQVB2gsDGUO(u"ࠪࠤࠥ࠺࠯࠶ࠩ฻"),XEcWOIwkZKubV7vQ(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩ฼"))
		PcIFK3fokRnTJVUX = bjyB5J1QuNaIXOx9qSwm4v0edDhg(HD7MQqXd2gS(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ฽"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nfNTgkiWdUq(u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭฾")+DFx6E0uON7Jm8(u"ࠧࠡࠢ࠸࠳࠺࠭฿"),bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭เ"))
	QQlJ2xKXAGUzh = JrbHs6SAj9MouPqEGZO(FFKncZx5pDTwdiJRYhMgQSNL)
	mm3znT1xXdcyNwP = JvQd6LMoBX4hiy1C(u"ࠩࡄ࡚࠿ࠦࠧแ")+QQlJ2xKXAGUzh+UUobzy0xZLaVScIt7(u"ࠪ࠱ࠬโ")+type
	J3dmKbe7QfWCv1EByjANZ = S5MWhgtZ37Xw if rCmGE4YIDaZA(u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧใ") in OOrjZaTIVXQ2Sp0ozhc else FFKncZx5pDTwdiJRYhMgQSNL
	if not PcIFK3fokRnTJVUX:
		if showDialogs: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,AJHaiQq3PRd5cphzGuELnVg9X(u"ࠬะๅࠡว็฾ฬวࠠศๆศีุอไࠡส้หฦูࠦๅ๋ࠣ฻้ฮใࠨไ"))
		return FFKncZx5pDTwdiJRYhMgQSNL
	bIwCcBT3Vxuld8Agy4Eoi = SoNGUfhMDERLyHOz1qkVAj.getInfoLabel(pxt6wJ8ScYMWCivoO(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡆࡳ࡫ࡨࡲࡩࡲࡹࡏࡣࡰࡩࠬๅ"))
	a1duvQ8Vh0gNo69nDcp3Pjtym += Yj1msqVeivESfrCupRy9b7WacBd(u"ࠧࠡ࡞࡟ࡲࡡࡢ࡮࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽ࠡ࡞࡟ࡲࡆࡪࡤࡰࡰ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥ࠭ๆ")+s5WcxEPjUBokapYMhAwb60dvgi+Qy6wlfLoOpg1(u"ࠨࠢ࠽ࡠࡡࡴࠧ็")
	a1duvQ8Vh0gNo69nDcp3Pjtym += VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠩࡈࡱࡦ࡯࡬ࠡࡕࡨࡲࡩ࡫ࡲ࠻่ࠢࠪ")+QQlJ2xKXAGUzh+VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠪࠤ࠿ࡢ࡜࡯ࡍࡲࡨ࡮ࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺้ࠡࠩ")+SAz6H7KPDEMveXklcnxGW+PPxYugzLZwHX23yiK(u"ࠫࠥࡀ࡜࡝ࡰ๊ࠪ")
	a1duvQ8Vh0gNo69nDcp3Pjtym += vzqjsVHSBlMpxC(u"ࠬࡑ࡯ࡥ࡫ࠣࡒࡦࡳࡥ࠻๋ࠢࠪ")+bIwCcBT3Vxuld8Agy4Eoi
	MMENSb8ojUDHBG5 = Cu2PQbzG5shMkL08cdYNOfjvKx9o()
	MMENSb8ojUDHBG5 = kGE6zoKSan54W(MMENSb8ojUDHBG5)
	if MMENSb8ojUDHBG5: a1duvQ8Vh0gNo69nDcp3Pjtym += ZjELJ9VrUT07R8Hn4FuSDcf(u"࠭ࠠ࠻࡞࡟ࡲࡑࡵࡣࡢࡶ࡬ࡳࡳࡀࠠࠨ์")+MMENSb8ojUDHBG5
	if url: a1duvQ8Vh0gNo69nDcp3Pjtym += PPxYugzLZwHX23yiK(u"ࠧࠡ࠼࡟ࡠࡳ࡛ࡒࡍ࠼ࠣࠫํ")+url
	if FjO41UWNvs0Gg: a1duvQ8Vh0gNo69nDcp3Pjtym += pxt6wJ8ScYMWCivoO(u"ࠨࠢ࠽ࡠࡡࡴࡓࡰࡷࡵࡧࡪࡀࠠࠨ๎")+FjO41UWNvs0Gg
	a1duvQ8Vh0gNo69nDcp3Pjtym += pxt6wJ8ScYMWCivoO(u"ࠩࠣ࠾ࡡࡢ࡮ࠨ๏")
	if showDialogs: ggYilKR5rMDyp7B(JvQd6LMoBX4hiy1C(u"ࠪะฬื๊ࠡษ็ษึูวๅࠩ๐"),Qy6wlfLoOpg1(u"ࠫฬ๊ัอษฤࠤฬ๊ว็ฬ฻หึ࠭๑"))
	if ty4u3WxGfEALovcCgkObzlKUnID7:
		cWiyehb8ELY7V2Cp0 = ty4u3WxGfEALovcCgkObzlKUnID7
		if BsLJ7p5Av2Vm0SQeCO1o: cWiyehb8ELY7V2Cp0 = cWiyehb8ELY7V2Cp0.encode(YWEQ3Cf8RevpD0m7NjF1)
		cWiyehb8ELY7V2Cp0 = Ic92Lb6lnzM5KJsx4Y3UGa70imZo.b64encode(cWiyehb8ELY7V2Cp0)
	elif J3dmKbe7QfWCv1EByjANZ:
		if baBcNd81eH5ry2Olp6Mj43(u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࡐࡎࡇࡣࠬ๒") in OOrjZaTIVXQ2Sp0ozhc: a4WImVvztPUT7u32Cdikbn5oyLRN = JRUTFhVSfB5wjt6YL
		else: a4WImVvztPUT7u32Cdikbn5oyLRN = Mtgex07pkPUj6z
		if not XoZRpFe7B6gnfA.path.exists(a4WImVvztPUT7u32Cdikbn5oyLRN):
			OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,DFx6E0uON7Jm8(u"࠭ำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡ฼ํี๋่ࠥอ๊าࠫ๓"))
			return FFKncZx5pDTwdiJRYhMgQSNL
		nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠧ࠯࡞ࡷࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡶࡩࡳࡪࠠࡵࡪࡨࠤࡱࡵࡧࡧ࡫࡯ࡩࠬ๔"))
		ZDjJCQInmA9h3SgrLeiFKBfaNtsuO,qCKtN0J5Arb = [],gmPI7hVEM8nD(u"࠳ဳ")
		file = open(a4WImVvztPUT7u32Cdikbn5oyLRN,nfNTgkiWdUq(u"ࠨࡴࡥࠫ๕"))
		size,count = cpNjIxZEUORvTw(a4WImVvztPUT7u32Cdikbn5oyLRN)
		if size>baBcNd81eH5ry2Olp6Mj43(u"࠷࠵࠷࠰࠱࠲ဴ"): file.seek(-baBcNd81eH5ry2Olp6Mj43(u"࠷࠵࠷࠰࠱࠲ဴ"),XoZRpFe7B6gnfA.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(YWEQ3Cf8RevpD0m7NjF1)
		data = xqYz9lmBbsZ4rhC2(data)
		Df6jx49PNm8 = data.splitlines()
		for PWjQyhAkS3RaGzNJUTvC6HiXsOLY in reversed(Df6jx49PNm8):
			i9ToEhrJRmp = XdreTYjbAoJPv5fLsxc103CFVy(PWjQyhAkS3RaGzNJUTvC6HiXsOLY)
			if i9ToEhrJRmp: continue
			qqboA7uVCnZD = PAztbuyYo4Kvd.findall(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠩࡡࠬࡡࡪࠫ࠮ࠪ࡟ࡨ࠰࠳࡜ࡥ࠭ࠣࡠࡩ࠱࠺࡝ࡦ࠮࠾ࡡࡪࠫ࡝࠰࡟ࡨ࠰࠯ࠩࠩࠢࡗ࠾ࡡࡪࠫࠪࠩ๖"),PWjQyhAkS3RaGzNJUTvC6HiXsOLY,PAztbuyYo4Kvd.DOTALL)
			if qqboA7uVCnZD:
				PWjQyhAkS3RaGzNJUTvC6HiXsOLY = PWjQyhAkS3RaGzNJUTvC6HiXsOLY.replace(qqboA7uVCnZD[IpFcwrWNgefMym3qta0hYQAzOdE][IpFcwrWNgefMym3qta0hYQAzOdE],qqboA7uVCnZD[IpFcwrWNgefMym3qta0hYQAzOdE][UnOIK1WBbw2]).replace(qqboA7uVCnZD[IpFcwrWNgefMym3qta0hYQAzOdE][udq5tP0hwifHQCGYELDbOUI],nA5dhMRg6ENzsB0l1GwvH7aIr2)
			else:
				qqboA7uVCnZD = PAztbuyYo4Kvd.findall(HD7MQqXd2gS(u"ࠪࡢ࠭ࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪ๗"),PWjQyhAkS3RaGzNJUTvC6HiXsOLY,PAztbuyYo4Kvd.DOTALL)
				if qqboA7uVCnZD: PWjQyhAkS3RaGzNJUTvC6HiXsOLY = PWjQyhAkS3RaGzNJUTvC6HiXsOLY.replace(qqboA7uVCnZD[IpFcwrWNgefMym3qta0hYQAzOdE][UnOIK1WBbw2],nA5dhMRg6ENzsB0l1GwvH7aIr2)
			ZDjJCQInmA9h3SgrLeiFKBfaNtsuO.append(PWjQyhAkS3RaGzNJUTvC6HiXsOLY)
			if len(str(ZDjJCQInmA9h3SgrLeiFKBfaNtsuO))>PPxYugzLZwHX23yiK(u"࠷࠻࠱࠱࠲࠳ဵ"): break
		ZDjJCQInmA9h3SgrLeiFKBfaNtsuO = reversed(ZDjJCQInmA9h3SgrLeiFKBfaNtsuO)
		cWiyehb8ELY7V2Cp0 = bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠫࡡࡸ࡜࡯ࠩ๘").join(ZDjJCQInmA9h3SgrLeiFKBfaNtsuO)
		cWiyehb8ELY7V2Cp0 = cWiyehb8ELY7V2Cp0.encode(YWEQ3Cf8RevpD0m7NjF1)
		cWiyehb8ELY7V2Cp0 = Ic92Lb6lnzM5KJsx4Y3UGa70imZo.b64encode(cWiyehb8ELY7V2Cp0)
	else: cWiyehb8ELY7V2Cp0 = nA5dhMRg6ENzsB0l1GwvH7aIr2
	url = Nzp9Fq5cTr.SITESURLS[JvQd6LMoBX4hiy1C(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ๙")][udq5tP0hwifHQCGYELDbOUI]
	hwZT5nYUGQ1RJC = {n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠭ࡳࡶࡤ࡭ࡩࡨࡺࠧ๚"):mm3znT1xXdcyNwP,jil8vRpBsENVYyPmDd(u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨ๛"):a1duvQ8Vh0gNo69nDcp3Pjtym,DFx6E0uON7Jm8(u"ࠨ࡮ࡲ࡫࡫࡯࡬ࡦࠩ๜"):cWiyehb8ELY7V2Cp0}
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(yy6RomT9bQhJf,DFx6E0uON7Jm8(u"ࠩࡓࡓࡘ࡚ࠧ๝"),url,hwZT5nYUGQ1RJC,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡙ࡅࡏࡆࡢࡉࡒࡇࡉࡍ࠯࠴ࡷࡹ࠭๞"))
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	if n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠫࠧࡹࡵࡤࡥࡨࡩࡩ࡫ࡤࠣ࠼ࠣ࠵࠱࠭๟") in kl2ZWdy8rXcHT: zTEXepHg92GkWf = S5MWhgtZ37Xw
	else: zTEXepHg92GkWf = FFKncZx5pDTwdiJRYhMgQSNL
	if showDialogs:
		if zTEXepHg92GkWf:
			ggYilKR5rMDyp7B(ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠬะๅࠡษ็ษึูวๅࠢห๊ัออࠨ๠"),Pj9YaUq1ibJ(u"࠭ࡓࡶࡥࡦࡩࡸࡹࠧ๡"))
			OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠧࡎࡧࡶࡷࡦ࡭ࡥࠡࡵࡨࡲࡹ࠭๢"),gmPI7hVEM8nD(u"ࠨฬ่ࠤสืำศๆࠣห้ืำศๆฬࠤอ์ฬศฯࠪ๣"))
		else:
			ggYilKR5rMDyp7B(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠩ็่ศูแࠡใื่ࠥอไฦำึห้࠭๤"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠪࡊࡦ࡯࡬ࡶࡴࡨࠫ๥"))
			OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,Yj1msqVeivESfrCupRy9b7WacBd(u"ࠫำ฽ร๊ࠡไุ้ࠦแ๋ࠢศีุอไࠡษ็ีุอไสࠩ๦"))
	return zTEXepHg92GkWf
def PPrzbaRDQvLBCjto14GpWygOc():
	jr9ylNbvcHEzPG8UpkL = XEcWOIwkZKubV7vQ(u"ࠬࡊ࡯ࠡࡻࡲࡹࠥࡽࡡ࡯ࡶࠣࡸࡴࠦࡴࡳࡣࡱࡷࡱࡧࡴࡦࠢࡰࡩࡳࡻࠠࡪࡶࡨࡱࡸࠦࡴࡰࠢࡤࠤࡱࡧ࡮ࡨࡷࡤ࡫ࡪࠦ࡯ࡵࡪࡨࡶࠥࡺࡨࡢࡰࠣࡅࡷࡧࡢࡪࡥࠣ࠲࠳ࠦࡏࡳࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡇࡲࡢࡤ࡬ࡧࠥࡲࡥࡵࡶࡨࡶࡸࠦࡡ࡯ࡦࠣࡸࡪࡾࡴࠡࡁࠤࠫ๧")
	jL23e6YO9IcvVME = nfNTgkiWdUq(u"࠭็ๅࠢอี๏ีࠠหำฯ้ฮࠦโ้ษษ้ࠥอไษำ้ห๊าࠠฦๆ์ࠤ้เษࠡลัี๎ฺ๋ࠦำࠣห้฿ัษ์ฬࠤ࠳࠴ࠠฤ็ࠣฮึ๐ฯࠡว฻๋ฬืࠠศๆฦัึ็้ࠠษ็็ฯอศสࠢส่฾ืศ๋หࠣรࠦ࠭๨")
	igSA3BDxXY14efJCGs = vnI6XSlmEtsx7(pxt6wJ8ScYMWCivoO(u"ࠧࡤࡧࡱࡸࡪࡸࠧ๩"),vzqjsVHSBlMpxC(u"ࠨะิ์ัࠦࡅࡹ࡫ࡷࠫ๪"),vzqjsVHSBlMpxC(u"ࠩࡗࡶࡦࡴࡳ࡭ࡣࡷࡩࠥะัอ็ฬࠫ๫"),zhE5I4xHinX0UoVZMNwlkPrR(u"ࠪ฽ึฮ๊ࠡࡃࡵࡥࡧ࡯ࡣࠨ๬"),OksCHeoL5SG,jr9ylNbvcHEzPG8UpkL+XEcWOIwkZKubV7vQ(u"ࠫࡡࡴ࡜࡯ࠩ๭")+jL23e6YO9IcvVME)
	if igSA3BDxXY14efJCGs in [-Pj9YaUq1ibJ(u"࠷ံ"),Pj9YaUq1ibJ(u"࠰့")]: return
	elif igSA3BDxXY14efJCGs==w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠲း"):
		import UdES5ZYF1g
		UdES5ZYF1g.mBdeYxGKai()
		return
	bZX5isLKBQYfD16kOwlt = S5MWhgtZ37Xw
	while bZX5isLKBQYfD16kOwlt:
		bZX5isLKBQYfD16kOwlt = FFKncZx5pDTwdiJRYhMgQSNL
		message = pxt6wJ8ScYMWCivoO(u"ࠬหะศࠢ฼๊ิ้ࠠๆึๆ่ฮࠦแ๋ࠢส่ศำัโࠢส่฾ืศ๋หࠣๅฬึ็ษࠢศ่๎ࠦࠢฦ฻าหิอส๊ࠡสะ์ฯࠠไ๊า๎ࠧࠦหๆࠢ฽๎ึࠦวๅะฺࠤส๊้ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢ࠱࠲ࠥหะศࠢ็้ࠥะฬะࠢส่ำ฽ࠠࠣࡃࡵ࡭ࡦࡲࠢࠡใ฽๎ึࠦวๅฮ็ำࠥหไ๊ࠢฦ๎ࠥาไะࠢฮห๋๐ࠠโ์๊ࠤฬ๊ฮุࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠣ࠲࠳ࠦหๆࠢห฽ิํวࠡ฼ํีࠥอไฯูࠣษ้๏ࠠࠣࡃࡵ࡭ࡦࡲࠢࠡ࡞ࡱࠤสึวࠡๆ๋ัฮࠦวๅ็ไหฯ๐อࠡษ็฽ึฮ๊สࠢ็หࠥะุ่ำ่่ࠣࠦ࠮࠯ࠢสิ์ฮࠠฦๆ์ࠤࠧหูะษาหฯ่ࠦศฮ๊อ้่ࠥะ์ࠥࠤ࠳࠴ࠠฬ็ࠣ฾๏ืࠠฦ฻าหิอสࠡษ็้ํู่ࠡษ็ะ฿ืวโ์ࠣࡠࡳࡢ࡮้ࠡ็ࠤฯื๊ะࠢส่ว์ࠠโฬะࠤࠧหูะษาหฯ่ࠦศฮ๊อ้่ࠥะ์ࠥࠤฤࠧࠧ๮")
		igSA3BDxXY14efJCGs = vnI6XSlmEtsx7(LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠭ࡣࡦࡰࡷࡩࡷ࠭๯"),vzqjsVHSBlMpxC(u"ࠧࡆࡺ࡬ࡸࠥิั้ฮࠪ๰"),vzqjsVHSBlMpxC(u"ࠨ࡛ࡨࡷࠥ์ูๆࠩ๱"),lw2snZ9J0uhLoxypqa(u"ࠩࡈࡲ࡬ࡲࡩࡴࡪࠣษ๋าไ๋ิํࠫ๲"),zhE5I4xHinX0UoVZMNwlkPrR(u"ࠪ฽ิู๋้๋ࠠีࠥอไฤฯิๅࠥ๎วๅๅอหอฯࠠศๆ฼ีอ๐ษࠨ๳"),message,profile=YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡳࡥࡥ࡫ࡸࡱ࡫ࡵ࡮ࡵࠩ๴"))
		if igSA3BDxXY14efJCGs==Pj9YaUq1ibJ(u"࠴္"):
			message = ldIfvn6asURQ9toi85EhqAXW3(u"ࠬࡏࡦࠡࡻࡲࡹࠥ࡮ࡡࡷࡧࠣࡴࡷࡵࡢ࡭ࡧࡰࠤࡼ࡯ࡴࡩࠢࡄࡶࡦࡨࡩࡤࠢ࡯ࡩࡹࡺࡥࡳࡵࠣࡸ࡭࡫࡮ࠡࡱࡳࡩࡳࠦࠢࡌࡱࡧ࡭ࠥࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࠡࡕࡨࡸࡹ࡯࡮ࡨࡵࠥࠤࡦࡴࡤࠡࡥ࡫ࡥࡳ࡭ࡥࠡࡶ࡫ࡩࠥ࡬࡯࡯ࡶࠣࡸࡴࠦࠢࡂࡴ࡬ࡥࡱࠨࠠ࠯࠰ࠣࡍ࡫ࠦࡹࡰࡷࠣࡧࡦࡴ࡜ࠨࡶࠣࡪ࡮ࡴࡤࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢࡩࡳࡳࡺࠠࡵࡪࡨࡲࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡶ࡯࡮ࡴࠠࡵࡱࠣࡥࡳࡿࠠࡰࡶ࡫ࡩࡷࠦࡳ࡬࡫ࡱࠤࡹ࡮ࡡࡵࠢ࡫ࡥࡻ࡫ࠠ࡝ࠤࡄࡶ࡮ࡧ࡬࡝ࠤࠣࡪࡴࡴࡴࠡ࠰࠱ࠤࡆࡴࡤࠡࡶ࡫ࡩࡳࠦࡣࡩࡣࡱ࡫ࡪࠦࡴࡩࡧࠣࡪࡴࡴࡴࠡࡶࡲࠤࠧࡇࡲࡪࡣ࡯ࠦࠥࡢ࡮ࠡࡋࡩࠤࡆࡸࡡࡣ࡫ࡦࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡩࡴࠢࡱࡳࡹࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠢ࠱࠲࡚ࠥࡨࡦࡰࠣࡳࡵ࡫࡮ࠡࠤࡎࡳࡩ࡯ࠠࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡗࡪࡺࡴࡪࡰࡪࡷࠧࠦࡡ࡯ࡦࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡳࡧࡪ࡭ࡴࡴࡡ࡭ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠤࡡࡴ࡜࡯ࠢࡇࡳࠥࡿ࡯ࡶࠢࡺࡥࡳࡺࠠ࡯ࡱࡺࠤࡹࡵࠠࡰࡲࡨࡲࠥࡺࡨࡦࠢࠥࡏࡴࡪࡩࠡࡋࡱࡸࡪࡸࡦࡢࡥࡨࠤࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸࠨࠠࡀࠣࠪ๵")
			igSA3BDxXY14efJCGs = vnI6XSlmEtsx7(bb1fgjsAq4N2xYwnoh39lm(u"࠭ࡣࡦࡰࡷࡩࡷ࠭๶"),Qy6wlfLoOpg1(u"ࠧࡆࡺ࡬ࡸࠥิั้ฮࠪ๷"),XEcWOIwkZKubV7vQ(u"ࠨ࡛ࡨࡷࠥ์ูๆࠩ๸"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠩࡄࡶࡦࡨࡩࡤࠢ฼ีอ๐ࠧ๹"),jil8vRpBsENVYyPmDd(u"ࠪࡑ࡮ࡹࡳࡪࡰࡪࠤࡆࡸࡡࡣ࡫ࡦࠤࡋࡵ࡮ࡵࠢࠩࠤ࡙࡫ࡸࡵࠩ๺"),message,profile=ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡳࡥࡥ࡫ࡸࡱ࡫ࡵ࡮ࡵࠩ๻"))
			if igSA3BDxXY14efJCGs==w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠵်"): bZX5isLKBQYfD16kOwlt = S5MWhgtZ37Xw
		if igSA3BDxXY14efJCGs==lw2snZ9J0uhLoxypqa(u"࠵ျ"): b5FWlN9LhQ1c()
	return
def E8qst2e1nkaVC5O0WDf7JvbudhgiB():
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,xwIUQfiE7rmvYzH(u"ࠬเวๅสสࠤฬ๊ำษส๋ࠣํࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢส่๊เะ๋ࠢ็่อืๆศ็ฯࠤํ๊ไหลๆำ่ࠥๅࠡสอุ฿๐ไࠡษ็ีฬฮืࠡษ็ิ๏ࠦไศࠢํ฽๊๊ࠠฬ็ࠣๆ๊ࠦศฦำึห้ࠦๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮ้๋ࠣࠦวๅไสส๊ฯࠠศๆิส๏ู๊สࠢ็่อืๆศ็ฯࠫ๼"))
	return
def Qb14TRaUvqg9K3LWm():
	a1duvQ8Vh0gNo69nDcp3Pjtym = UUobzy0xZLaVScIt7(u"࠭็ัษࠣห้ฮั็ษ่ะ๋ࠥฮึืࠣๅ็฽ࠠๅๆ฽อࠥอไฺำห๎ฮ่ࠦๅๅ้ࠤ์ึวࠡๆสࠤ๏๋ๆฺ๋ࠢะํีࠠๆ๊สๆ฾ࠦแ๋้สࠤศ็ไศ็ࠣ์ู๊ไิๆสฮ๋ࠥสาฮ่อࠥษ่ࠡ็าฬ้าษࠡว็ํࠥอไๅ฼ฬࠤฬู๊าสํอࠥ๎วๅ๋่ࠣ฿อสࠡษัี๎่ࠦๅษࠣ๎ําฯࠡีหฬ๊ࠥไหๅิหึ࠭๽")
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,a1duvQ8Vh0gNo69nDcp3Pjtym)
	return
def ckbQMsZ1GxAdt8VTyUPI():
	a1duvQ8Vh0gNo69nDcp3Pjtym = nfNTgkiWdUq(u"ࠧศๆิ์ฬฮืࠡษ็ฬ฼๐ฦสࠢ็หࠥ฿ไศไฬࠤ้ํวࠡสส่อืๆศ็ฯࠤํเวๅสสࠤฬ๊ำษส๋ࠣํࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢส่๊เะ๋ࠢ็่อืๆศ็ฯࠫ๾")
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,a1duvQ8Vh0gNo69nDcp3Pjtym)
	return
def sPjrfqSoBLziCmZ9wMxYK1yFX():
	a1duvQ8Vh0gNo69nDcp3Pjtym = pxt6wJ8ScYMWCivoO(u"ࠨ้ํࠤุ๐ัโำสฮ๊ࠥวࠡ์ึฮ฼๐ูࠡษ็ฬึ์วๆฮࠣหุะฮะษ่๋ฬࠦศิสหࠤ่๎ๆ่ษ้ࠣา๋๊ส่๊ࠢࠥอไๆืาีࠥษ่ࠡสะหัฯࠠฦๆ์ࠤฬฺสาษๆࠤึูๅ๋ࠢฦ์ࠥาฯ๋ัฬࠤศ๎ࠠๅษࠣ๎฾ืแ่ษࠣห้ฮั็ษ่ะࠬ๿")
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,PPxYugzLZwHX23yiK(u"ࠩึ๎ึ็ัศฬࠣื๏ฬษࠡล๋ࠤ๊า็้ๆฬࠫ຀"),a1duvQ8Vh0gNo69nDcp3Pjtym)
	return
def sz81RjeGBcpXvHVy5rA():
	a1duvQ8Vh0gNo69nDcp3Pjtym = jil8vRpBsENVYyPmDd(u"ࠪหู้๊าใิหฯࠦวๅ฻ส้ฮࠦ็๋ࠢึ๎ึ็ัศฬࠣาฬืฬ๋หࠣ์฿๐ัࠡฬสฬ฾ฯࠠๅๆ่์็฿ࠠศๆฦู้๐้ࠠฮ่๎฾ࠦวๅ็๋ห็฿ࠠหีอาิ๋็ศ๋ࠢ฽ฬีษࠡฬๆ์๋ࠦๅอษ้๎ฮ่ࠦๆึส็้ํวࠡๅฮ๎ึฯࠠๅษ้ࠤฬ๊แ๋ัํ์์อสࠡใํ๋ฬࠦลๆษࠣฬ฼๐ฦสࠢฦ์๋ࠥๅ็๊฼อࠥษ่ࠡ็ะิํ็ษࠡล๋ࠤๆ๐็ศุ่่๊ࠢษࠡฯๅ์็ࠦวๅ็็็๏ฯ࡜࡯࡞ࡱࡠࡳอไิ์ิๅึอสࠡษ็าฬ฻ษ้ࠡํࠤุ๐ัโำสฮࠥะวษ฻ฬࠤ้๊ๅ้ไ฼ࠤฬ๊รึๆํࠤํ๋ำหะา้ฮࠦแ๋่ࠢ์ฬู่ࠡไ็๎้ฯࠠอัสࠤํ฿วะหࠣฮ่๎ๆࠡ็าๅํ฿ษࠡษ็วัืࠠฤ๊ࠣ๎๊๊ใ่ษࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣ์้ํะศࠢไ๋๏ࠦฬ๋ัฬࠤู๋ศ๋ษࠣ์ุืฺ๊หࠣ์ฺ๊วไๆ๊ห่ࠥไ๋ๆฬࠤัีวࠨກ")
	d9EaJh5t3Tyj7CsXFL(nfNTgkiWdUq(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫຂ"),OksCHeoL5SG,a1duvQ8Vh0gNo69nDcp3Pjtym,bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ຃"))
	return
def XZrzcQvO4uwJGA9i50TE8D():
	jr9ylNbvcHEzPG8UpkL = vzqjsVHSBlMpxC(u"࠭วษฬ฼ำࠥ฿ๆࠡ็็ๅฬะࠠศๆาๆฮࠦวๅ฻ส่๏ฯࠧຄ")
	jL23e6YO9IcvVME = jil8vRpBsENVYyPmDd(u"ࠧศสอ฽ิูࠦ็่่ࠢๆอสࠡล็ࠤࡲ࠹ࡵ࠹ࠩ຅")
	BdkeVTtAKUW9vrcqmy7 = UUobzy0xZLaVScIt7(u"ࠨษหฮ฾ีฺ่้้ࠠࠣ็วหࠢส่ฯำๅ๋ๆࠣ์ฬ๊ฯศ๊้่ํีࠠࡥࡱࡺࡲࡱࡵࡡࡥࠩຆ")
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,jr9ylNbvcHEzPG8UpkL,jL23e6YO9IcvVME,BdkeVTtAKUW9vrcqmy7)
	return
def V1aNDbJw975():
	jL23e6YO9IcvVME = ldIfvn6asURQ9toi85EhqAXW3(u"ࠩส่่อิ้๋ࠡࠤ๊ิา็่ࠢศ็ะࠠๅๆ่฽้๎ๅศฬࠣ๎ุะฮะ็๊ࠤฬ๊ศา่ส้ัࠦไฯิ้ࠤฺ็อศฬࠣห้หๆหำ้๎ฯ่ࠦา๊สฬ฼ࠦวๅใํำ๏๎็ศฬ่้ࠣ๎ี้ๆࠣษ้๐็ศࠢหืึ฿ษ๊ࠡหำํ์ࠠฦ่อี๋๐ส๊ࠡส่อืๆศ็ฯࠤ๏๋ำฮ้สࠤฯ๊โศศํหࠥฮูะࠢส๊ฯํวยࠢ฼้ึํว๊ࠡฦ๎฻อฺ่ࠠาࠤฯำฯ๋อࠣห้ฮั็ษ่ะࠥ࠴้้ࠠำหࠥอไษำ้ห๊า๋ࠠีอาิ๋ࠠิส฼อࠥษๆ้ษ฼ࠤ้฿ๅาࠢส่่อิࠡ࠼ࠪງ")
	jL23e6YO9IcvVME += n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠪࡠࡳࡢ࡮ࠨຈ") + rCmGE4YIDaZA(u"ࠫ࠶࠴ࠠฬษหฮ๊ࠥไึใะหฯࠦวๅฬํࠤ๊฿ั้ใࠣว๋ํวࠡๆสࠤฯะฺ๋ำ๊ࠣ์อฦ๋ษࠣ์๊ีส่ࠢࠪຉ") + str(l7ltVNxrbPimpXJDh/Qy6wlfLoOpg1(u"࠻࠶ြ")/Qy6wlfLoOpg1(u"࠻࠶ြ")/pxt6wJ8ScYMWCivoO(u"࠸࠴ွ")/LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠳࠱ှ")) + LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠬࠦิ่ำࠪຊ")
	jL23e6YO9IcvVME += CXtugbqhV3 + zhE5I4xHinX0UoVZMNwlkPrR(u"࠭࠲࠯ࠢฯำฬࠦื้์็ࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ๅโำฺ๋ࠥษๆ่ษ่ࠣฬࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬ຋") + str(KcwozFY2DsR3jSBO/ZjELJ9VrUT07R8Hn4FuSDcf(u"࠷࠲ဿ")/ZjELJ9VrUT07R8Hn4FuSDcf(u"࠷࠲ဿ")/mRanX1HZupfSQVB2gsDGUO(u"࠴࠷၀")) + ldIfvn6asURQ9toi85EhqAXW3(u"ࠧࠡ์๋้ࠬຌ")
	jL23e6YO9IcvVME += CXtugbqhV3 + XEcWOIwkZKubV7vQ(u"ࠨ࠵࠱ࠤ฼๎๊ๅࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠ็ษาีฬࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬຍ") + str(OkCUfhKTs9DZbcgnw3roPGBvlqt/ZjELJ9VrUT07R8Hn4FuSDcf(u"࠹࠴၁")/ZjELJ9VrUT07R8Hn4FuSDcf(u"࠹࠴၁")/nfNTgkiWdUq(u"࠶࠹၂")) + Qy6wlfLoOpg1(u"ࠩࠣ๎ํ๋ࠧຎ")
	jL23e6YO9IcvVME += CXtugbqhV3 + bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠪ࠸࠳ࠦๅห๊ึ฻ࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์ࠣๆิࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬຏ") + str(QdwW2s0iEp56qMmvCbOeLxBRU/VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠻࠶၃")/VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠻࠶၃")) + FVxoQ2J5Mfv3Zj6sy9uhOS(u"ูࠫࠥวฺหࠪຐ")
	jL23e6YO9IcvVME += CXtugbqhV3 + pxt6wJ8ScYMWCivoO(u"ࠬ࠻࠮ࠡไุ๎ึࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅฬํࠤฯะฺ๋ำࠣำฬฬๅศ๋้ࠢิะ็ࠡࠩຑ") + str(lPsYQwWdLO520ZHcFV8n1x/w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠼࠰၄")/w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠼࠰၄")) + PPxYugzLZwHX23yiK(u"࠭ࠠิษ฼อࠬຒ")
	jL23e6YO9IcvVME += CXtugbqhV3 + Pj9YaUq1ibJ(u"ࠧ࠷࠰ࠣะิอࠠใืํีࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์ࠣฮฯเ๊าࠢๆฯ๏ืว๊่ࠡำฯํࠠࠨຓ") + str(cbpdEaUM8rKSQvzuqiJyXwW4/bb1fgjsAq4N2xYwnoh39lm(u"࠶࠱၅")) + mRanX1HZupfSQVB2gsDGUO(u"ࠨࠢาๆ๏่ษࠨດ")
	jL23e6YO9IcvVME += CXtugbqhV3 + AJHaiQq3PRd5cphzGuELnVg9X(u"ࠩ࠺࠲ࠥฮฯ้่ࠣ็ฬฺࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํีࠥฮำา฻ฬࠤํ๋ฯห้ࠣࠫຕ") + str(yy6RomT9bQhJf) + LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠪࠤิ่๊ใหࠪຖ")
	jL23e6YO9IcvVME += bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠫࡡࡴ࡜࡯ࠩທ") + Qy6wlfLoOpg1(u"๋ࠬหๅษ࠽ࠤฺ็อศฬࠣๆํอฦๆࠢส่ศ็ไศ็ࠣ์ฬ๊ๅิๆึ่ฬะ้ࠠษ็ั้่วหࠢ฼้ึํวࠡࠩຘ") + str(QdwW2s0iEp56qMmvCbOeLxBRU/Qy6wlfLoOpg1(u"࠷࠲၆")/Qy6wlfLoOpg1(u"࠷࠲၆")) + HD7MQqXd2gS(u"࠭ࠠิษ฼อࠥ࠴ࠠฤ็สࠤ็๎วว็ࠣว๋๎วฺࠢส่ๆ๐ฯ๋๊๊หฯࠦแฺ็ิ๋ฬࠦࠧນ") + str(OkCUfhKTs9DZbcgnw3roPGBvlqt/Qy6wlfLoOpg1(u"࠷࠲၆")/Qy6wlfLoOpg1(u"࠷࠲၆")/FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠴࠷၇")) + pxt6wJ8ScYMWCivoO(u"ࠧࠡลํห๊ࠦ࠮ࠡล่ห๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥ็ูๆำ๊หࠥ࠭ບ") + str(lPsYQwWdLO520ZHcFV8n1x/Qy6wlfLoOpg1(u"࠷࠲၆")/Qy6wlfLoOpg1(u"࠷࠲၆")) + zhE5I4xHinX0UoVZMNwlkPrR(u"ࠨࠢึห฾ฯࠠโไฺࠤ࠳ࠦรๆษࠣๅา฻ࠠาไ่ࠤฬ๊ลึัสีࠥ็ูๆำ๊ࠤࠬປ") + str(cbpdEaUM8rKSQvzuqiJyXwW4/Qy6wlfLoOpg1(u"࠷࠲၆")) + VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠩࠣำ็๐โสࠢ࠱ࠤศ๋วࠡใะูࠥอิหำส็ࠥๆࡉࡑࡖ࡙ࠤๆ฿ๅา้ࠣࠫຜ") + str(yy6RomT9bQhJf) + YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠪࠤิ่๊ใหࠪຝ")
	d9EaJh5t3Tyj7CsXFL(ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠫࡷ࡯ࡧࡩࡶࠪພ"),zhE5I4xHinX0UoVZMNwlkPrR(u"๋ࠬว้๋ࠡࠤฬ๊ใศึࠣห้๋ำหะา้ࠥ็๊ࠡษ็ฬึ์วๆฮࠪຟ"),jL23e6YO9IcvVME,rCmGE4YIDaZA(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩຠ"))
	return
def j0aiH2nVhrtF7PIgGLZy45N():
	a1duvQ8Vh0gNo69nDcp3Pjtym = VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠧศๆไหฺ๊ษࠡฬ฼๊๏ࠦๅอๆาࠤอ์แิࠢสื๊ํࠠศๆฦู้๐้ࠠษ็๊็฽ษࠡฬ฼๊๏ࠦร็ࠢส่ฬูๅࠡษ็วฺ๊๊ࠡฬ่ࠤฯ฿ฯ๋ๆ๊ࠤํ็วึๆฬࠤํ์โุหࠣฮ฾์้ࠡ็ฯ่ิ่ࠦห็ࠣฮ฾ี๊ๅࠢสื๊ํ้ࠠสา์ู๋ࠦๅษ่อࠥะู็์้้ࠣ็ࠠษ่ไืࠥอำๆ้ࠣห้ษีๅ์ࠪມ")
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,a1duvQ8Vh0gNo69nDcp3Pjtym)
	return
def YtVOFdqWMAT327mzhXw58GE6rnScRj():
	a1duvQ8Vh0gNo69nDcp3Pjtym = Yj1msqVeivESfrCupRy9b7WacBd(u"ࠨวำหࠥ๎วอ้อ็๋ࠥิไๆฬࠤๆ๐ࠠศๆืฬ่ฯ้ࠠฬ่ࠤา๊็ศࠢ࠱࠲࠳ࠦร้ࠢส๊่ࠦสู่ࠣว๋ࠦวๅ็๋ๆ฾ࠦวๅลุ่๏ࠦใศ่ࠣๅ๏ํࠠๆึๆ่ฮࠦๅลไอ๋ࠥ๎สๆࠢะ่์อࠠ࠯࠰࠱ࠤๆหะ็ࠢฯีอࠦๅิฯࠣ็ฬฺࠠศๆหี๋อๅอࠢ็็๏๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦศุๆหࠤฬ๊ีโฯฬࠤฬ๊ีฮ์ะอࠥ๎สฯิํ๊์อࠠษั็ห๋ࠥๆࠡษ็ูๆำษࠡษ็ๆิ๐ๅสࠩຢ")
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,a1duvQ8Vh0gNo69nDcp3Pjtym)
	return
def ggBAetcGQ0PpVOKNCE1LaHWrswZ3():
	a1duvQ8Vh0gNo69nDcp3Pjtym = Yj1msqVeivESfrCupRy9b7WacBd(u"ࠩส่฿ืึࠡ็้ࠤูํวะหࠣห้ะิโ์ิࠤ์๎ࠠื็ส๊ࠥ฻อส๋ࠢืึ๐ษࠡษ็้฾๊่ๆษอࠤฬ๊ๅหสสำ้ฯࠠษ์้ࠤฬ๊ศา่ส้ั่ࠦศๆ่์็฿ࠠศๆุ่ๆื้้ࠠำหࠥอไื็ส๊ࠥเ๊า่ࠢ฻้๎ศ๊ࠡ็หࠥำวอห่ࠣ์ูࠦ็ัࠣห้อสึษ็ࠤฬ๎ࠠศๆิฬ฼ࠦๅฺ่ࠢ์ฬู่ࠡษ็ๅ๏ี๊้้สฮࠥอไๆึไีฮ࠭ຣ")
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,a1duvQ8Vh0gNo69nDcp3Pjtym)
	return
def ExPAMIFqX9mzgQyN1vuiwt():
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,ldIfvn6asURQ9toi85EhqAXW3(u"่่ࠪ๐๋ࠠ฻่่ࠥํะศࠢส่๋๎ูࠡ็้ࠤฬ๊แ๋ัํ์์อสࠡ࡞ࡱࠤ๏าศࠡฬไ฽๏๊ࠠฦุสๅฮࠦวิ็๊หࠥࡢ࡮ࠡ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ຤"))
	zfTIJNiuLFM2Kj(XEcWOIwkZKubV7vQ(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫລ"),S5MWhgtZ37Xw)
	return
def vw1oIQem2ODz0YaK59():
	a1duvQ8Vh0gNo69nDcp3Pjtym  = ZjELJ9VrUT07R8Hn4FuSDcf(u"๋ࠬฤฯำสࠤ็อๅหࠢห฽฻ࠦิาๅสฮࠥอไฦ่อี๋ะࠠศๆา์้๐ࠠษู๊฽ࠥ฿ววไฺࠣิࠦวๅสิห๊าࠠๆอ็ࠤ่๎ฯ๋ࠢ็ฮุ๋อࠡใๅ฻๊ࠥศฺุุ้ࠣะฮะ็ํࠤฬ๊ๅหืไัࠥฮวๅัั์้ࠦไๆ๊สๆ฾ࠦวๅใํำ๏๎ࠧ຦")
	a1duvQ8Vh0gNo69nDcp3Pjtym += VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"้่࠭ࠠอ๎ัฯࠠๅ้ำหࠥอไฺษษๆࠥ็ว็้ࠣฮ็ื๊ษษࠣะ๊๐ูࠡ็ึฮำีๅ๋ࠢหี๋อๅอࠢๆ์ิ๐ࠠๅษࠣ๎ุะื๋฻๋๊ࠥอไะะ๋่๊ࠥฬๆ์฼ࠤ๊๎วใ฻ࠣห้ฮั็ษ่ะࠥำส๊่ࠢ฽ࠥอำหะาห๊࠭ວ")
	a1duvQ8Vh0gNo69nDcp3Pjtym += CXtugbqhV3+bbTCMJwEx8nhN4X+JvQd6LMoBX4hiy1C(u"ࠧแ࡚ࠢࠣࡕࡔࠠࠡล๋ࠤࠥࡖࡲࡰࡺࡼࠤࠥษ่ࠡࠢࡇࡒࡘࠦࠠฤ๊ࠣว๏ࠦอๅࠢหื๏฽ࠠระิࠫຨ")+NwROdSj3nsA+CXtugbqhV3
	a1duvQ8Vh0gNo69nDcp3Pjtym += ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠨ࡞ࡱ่ฬ์่ࠠาสࠤ้์๋ࠠฯ็ࠤฬ๊ๅีๅ็อࠥ๎ล็็สࠤๆ่ืࠡีํๆํ๋ࠠษวุ่ฬำࠠษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ๎ลฺษๅอ๋่ࠥศไ฼ࠤฬิั๊ࠢๆห๋ะࠠห฻ู่่ࠥวษไสࠤอี่็ุ่ࠢฬ้ไࠨຩ")
	d9EaJh5t3Tyj7CsXFL(zhE5I4xHinX0UoVZMNwlkPrR(u"ࠩࡵ࡭࡬࡮ࡴࠨສ"),OksCHeoL5SG,a1duvQ8Vh0gNo69nDcp3Pjtym,yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ຫ"))
	a1duvQ8Vh0gNo69nDcp3Pjtym = baBcNd81eH5ry2Olp6Mj43(u"ࠫฬ๊ๅ้ษๅ฽ࠥอไห์ࠣฮศััหࠢหห้฿ววไࠣ฽๋ีࠠษ฻ูࠤฬ๊ๆศี๋ࠣ๏ࡀࠧຬ")
	a1duvQ8Vh0gNo69nDcp3Pjtym += CXtugbqhV3+bbTCMJwEx8nhN4X+jil8vRpBsENVYyPmDd(u"ࠬࡧ࡫ࡰࡣࡰࠤࠥ࡫ࡧࡺࡤࡨࡷࡹࠦࠠࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠤࠥࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤࠡࠢࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨࠡࠢࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫອ")+NwROdSj3nsA
	a1duvQ8Vh0gNo69nDcp3Pjtym += PPxYugzLZwHX23yiK(u"࠭࡜࡯࡞ࡱࠫຮ")+jil8vRpBsENVYyPmDd(u"ࠧศๆา์้ࠦวๅฬํࠤฯษหาฬࠣฬฬู๊ศศๅࠤ฾์ฯࠡส฼ฺࠥอไ็ษึࠤ์๐࠺ࠨຯ")
	a1duvQ8Vh0gNo69nDcp3Pjtym += CXtugbqhV3+bbTCMJwEx8nhN4X+xwIUQfiE7rmvYzH(u"ࠨ็ุีࠥࠦวๅๅ๋๎ฯࠦࠠฤ็ํี่อࠠࠡๅ้ำฬࠦࠠโำ้ืฬࠦࠠศๆํ์๋อๆࠡࠢหี๏฽ว็์สࠤฬ๊ลๆษิหฯࠦรๅ็ส๊๏อࠠา๊ึ๎ฬࠦวๅ์สฬฬ์ࠠศๆึ฽ํี๊สࠢิ์๊อๆ๋ษ๋ࠣํ๊ๆะษࠪະ")+NwROdSj3nsA
	a1duvQ8Vh0gNo69nDcp3Pjtym += n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠩ࡟ࡲࡡࡴࠧັ")+DFx6E0uON7Jm8(u"ࠪห้๋ศา็ฯࠤําฯูࠡิ๎็ฯࠠๅฬฯหํุࠠศๆ฼หห่้ࠠๆๆ๊์อࠠหฯอหัࠦฬ่ัࠣ็อ๐ั๊ࠡส่๊ฮัๆฮࠣ๎฽์ࠠศๆุ่่๊ษࠡื฽๎ึฯ้ࠠๆสࠤฯูสฮไࠣห้ะูษࠢไษีอࠠๅัํ็๋ࠥิไๆฬࠤออไะะ๋่๊ࠥศฺุࠣห้๋่ศไ฼ࠤํษ๊ืษ่่ࠣ๐๋ࠠฬูัࠥำฬๆࠢสฺ่๊ใๅหࠣࠫາ")
	a1duvQ8Vh0gNo69nDcp3Pjtym += bbTCMJwEx8nhN4X+pxt6wJ8ScYMWCivoO(u"ࠫฬืำๅࠢิืฬ๊ษࠡ็วำอฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ๎วไฬหࠤๆ๐็ศࠢสื๊ࠦศๅัๆࠤํษำๆษฤࠤฬ๊ๅ้ษๅ฽ࠥอไห์่ࠣฬࠦสิฬฺ๎฾ࠦฯฯ๊็๋ฬ࠭ຳ")+NwROdSj3nsA
	d9EaJh5t3Tyj7CsXFL(YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠬࡸࡩࡨࡪࡷࠫິ"),OksCHeoL5SG,a1duvQ8Vh0gNo69nDcp3Pjtym,DFx6E0uON7Jm8(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩີ"))
	return
def sOwCjZRK3DF():
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,HD7MQqXd2gS(u"ࠧฬๆสฯࠥ฽ัใࠢ็่ฯ๎วึๆ้ࠣ฾ࠦวๅ็หี๊าࠧຶ"),ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠨลิื้ࠦัิษ็อࠥษ่ࠡ็ื็้ฯࠠๆ่ࠣๆฬฬๅสࠢัำ๊อส้ࠡำหࠥอไษำ้ห๊า࡜࡯࡞ࡱวํࠦศศีอาิอๅࠡษ็ๅ๏ูศ้ๅࠣวิ์ว่࡞ࡱࠫື")+bbTCMJwEx8nhN4X+PPxYugzLZwHX23yiK(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡩࡥࡨ࡫ࡢࡰࡱ࡮࠲ࡨࡵ࡭࠰ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠲࠱࠳࠻ຸࠫ")+NwROdSj3nsA+LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠪࡠࡳࡢ࡮ฤ๊ࠣฬฬืำศๆࠣห๏๋๊ๅࠢส่๎ࠦระ่ส๋ࠥࠦ࡜࡯ູࠢࠪ")+bbTCMJwEx8nhN4X+LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠵࠴࠶࠾ࡀࡨ࡯ࡤ࡭ࡱ࠴ࡣࡰ࡯຺ࠪ")+NwROdSj3nsA)
	return
def lbPyGfqewBD(showDialogs=S5MWhgtZ37Xw):
	if not showDialogs: showDialogs = S5MWhgtZ37Xw
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(yy6RomT9bQhJf,HD7MQqXd2gS(u"ࠬࡍࡅࡕࠩົ"),FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡺࡤࡱࡵࡲࡥ࠯ࡥࡲࡱࠬຼ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,FFKncZx5pDTwdiJRYhMgQSNL,nA5dhMRg6ENzsB0l1GwvH7aIr2,ldIfvn6asURQ9toi85EhqAXW3(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡋࡘ࡙ࡖࡓࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪຽ"))
	if not Y3SmVGbfNvEeakMBr.succeeded:
		JnNKH9COaswl20 = FFKncZx5pDTwdiJRYhMgQSNL
		ByuFsZxqG3NTIQ54f9CPclLVS = A5ADUfVbRmFSyH94P(FFKncZx5pDTwdiJRYhMgQSNL)
		nhR0UxwS4yDiABj7V1G8la(ybrna7mLOFVDUtRseQ3Tkf2zXS,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+bb1fgjsAq4N2xYwnoh39lm(u"ࠨࠢࠣࠤࡍ࡚ࡔࡑࡕࠣࡊࡦ࡯࡬ࡦࡦࠣࠤࠥࡒࡡࡣࡧ࡯࠾ࡠ࠭຾")+ByuFsZxqG3NTIQ54f9CPclLVS+PPxYugzLZwHX23yiK(u"ࠩࡠࠫ຿"))
		if showDialogs: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,bb1fgjsAq4N2xYwnoh39lm(u"ࠪๅา฻ࠠศๆสฮฺอไࠡษ็ู้็ัࠡ࠰࠱࠲๋ࠥิไๆฬࠤ࠳࠴࠮ࠡษ็หฯ฻วๅࠢสฺ่๊แาࠢࠫห้ืศุࠢสฺ่๊แา่ࠫࠣฬฺ๊ࠦ็็ࠤ฾์ฯไࠢ฼่๎ࠦใ้ัํࠤ࠳࠴࠮๊ࠡ฼๊ิ้ࠠไ๊า๎ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬูสฯัส้ࠥอไๆ๊สๆ฾ࠦวๅ็ืๅึฯࠧເ"))
	else:
		JnNKH9COaswl20 = S5MWhgtZ37Xw
		if showDialogs: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮࠯ࠢส่ฬะีศๆࠣห้๋ิโำࠣࠬฬ๊ัษูࠣห้๋ิโำࠬࠤ๏฿ๅๅࠢ฼๊ิ้้ࠠษ็ฬึ์วๆฮࠣๆฬีัࠡ฻็ํࠥอำหะาห๊ࠦวๅ็๋ห็฿ࠠศๆุ่ๆืษࠨແ"))
	if not JnNKH9COaswl20 and showDialogs: y4yTMK2gPDbdFofwB3c6jsnG9ev8()
	return JnNKH9COaswl20
def y4yTMK2gPDbdFofwB3c6jsnG9ev8():
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,XEcWOIwkZKubV7vQ(u"ࠬฮูืࠢส่๊๎วใ฻ࠣฮาะวอࠢิฬ฼ࠦๅีใิࠤํ่ฯࠡ์ๆ์๋ࠦฬ่ษี็ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬ๊ัษูࠣห้๋ิโำࠣวํࠦ็็ษๆࠤฺ๊ใๅหࠣๅ๏ࠦิ่ษาอࠥอไหึไ๎ึࠦวๅะสูฮࠦศไ๊า๎ࠥ฿ๆะๅࠣ฽้๋วࠡษ้๋ࠥะๅࠡใะูࠥอไษำ้ห๊าฺࠠๆ์ࠤ่๎ฯ๋ࠢส่ส฻ฯศำสฮࠥࡢ࡮ࠡ࠳࠺࠲࠻ࠦࠠࠧࠢࠣ࠵࠽࠴࡛࠱࠯࠼ࡡࠥࠦࠦࠡࠢ࠴࠽࠳ࡡ࠰࠮࠵ࡠࠫໂ"))
	ddG7M83chw1BFWgD()
	return
def z2JW4QB7vEgqxAX0p(OOrjZaTIVXQ2Sp0ozhc=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	J3dmKbe7QfWCv1EByjANZ = S5MWhgtZ37Xw
	if JvQd6LMoBX4hiy1C(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩໃ") not in OOrjZaTIVXQ2Sp0ozhc:
		J3dmKbe7QfWCv1EByjANZ = FFKncZx5pDTwdiJRYhMgQSNL
		uDP7kA6UcClgd2Gza0VO = vnI6XSlmEtsx7(DFx6E0uON7Jm8(u"ࠧࡤࡧࡱࡸࡪࡸࠧໄ"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠨะิ์ั࠭໅"),HD7MQqXd2gS(u"ࠩศีุอไࠡ็ื็้ฯࠧໆ"),DFx6E0uON7Jm8(u"ࠪษึูวๅࠢิืฬ๊ษࠨ໇"),OksCHeoL5SG,bb1fgjsAq4N2xYwnoh39lm(u"ࠫ์๊ࠠหำํำࠥษๆࠡฬิื้ࠦัิษ็อࠥหไ๊ࠢส่๊ฮัๆฮࠣ࠲࠳ࠦรๆࠢอี๏ีࠠฤ่ࠣฮึูไࠡ็ื็้ฯࠠๆ๊ฯ์ิฯࠠโ์ࠣห้ฮั็ษ่ะࠥล່ࠧ"))
		if uDP7kA6UcClgd2Gza0VO in [-VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠴၈"),HD7MQqXd2gS(u"࠴၉")]: return
		elif uDP7kA6UcClgd2Gza0VO==Pj9YaUq1ibJ(u"࠶၊"):
			J3dmKbe7QfWCv1EByjANZ = S5MWhgtZ37Xw
			OOrjZaTIVXQ2Sp0ozhc = Pj9YaUq1ibJ(u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࠨ້")
	if J3dmKbe7QfWCv1EByjANZ:
		if VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࡑࡏࡈࡤ໊࠭") not in OOrjZaTIVXQ2Sp0ozhc:
			x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(xwIUQfiE7rmvYzH(u"ࠧࡤࡧࡱࡸࡪࡸ໋ࠧ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,HD7MQqXd2gS(u"ࠨู๊฽ࠥอไๆึๆ่ฮࠦแ๋ࠢสุ่าไࠨ໌"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠩๅฬ้ࠦลาีส่ࠥอไิฮ็ࠤ฾๊๊ไࠢฦ๊ࠥะใาำࠣࠤ๋็ำࠡษ็ๅ฾๊ࠠศๆำ๎ࠥษูุษๆࠤฬ๊ๅีๅ็อࠥ࠴ࠠๅๅํࠤ๏ะๅࠡฬึะ๏๊่ࠠา๊ࠤฬ๊ๅีๅ็อࠥ็๊ࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣ࠲ࠥ๎ศะ๊้ࠤ์ึวࠡษ็ฮุา๊ๅࠢึ์ๆࠦสาี็ࠤ๊๊แࠡๆสࠤๆอฦะห้๋ࠣํࠠๅว้๋๊ࠥวࠡ์ะฮํ๐ฺࠠๆ์ࠤฬ๊ๅีๅ็อࠥอไห์ࠣฮึ๐ฯࠡษ้ฮࠥอไฦส็ห฿ูࠦ็้สࠤ࠳ࠦ็ๅࠢๅ้ฯࠦศหๅิหึࠦวๅ็ื็้ฯࠠภࠩໍ"))
			if x6zlf2tTZm!=ZjELJ9VrUT07R8Hn4FuSDcf(u"࠷။"):
				OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,DFx6E0uON7Jm8(u"ࠪฮ๊ࠦลๅ฼สลࠥอไฦำึห้࠭໎"),PPxYugzLZwHX23yiK(u"้๊ࠫริใࠣฬิ๎ๆࠡฬึะ๏๊ࠠศๆุ่่๊ษࠡใํࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊ࠦแศ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠีอ฻๏฿ࠠๆ฻ิๅฮࠦวๅ็ื็้ฯ้ࠠๆสࠤา๊็ศࠢ็ห๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮࠧ໏"))
				return
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠬ็๊ࠡษ็ุฬฺษࠡษ็ๆฬีๅสࠢะหํ๊ࠠฤ่ࠣฮ่ะศࠡำึห้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ๎วีำะࠤๆ๐็ศࠢสฺ่๊ใๅหࠣวํࠦวๅ็ฺ๋ํ฿้ࠠวำหࠥษัะฬࠣะํอศࠡ็้ࠤฬ๊ๅษำ่ะࠥ็ลั่ࠣว่ะศࠡ฻้์ฬ์ࠠษำํำ่ࠦรๅว็็ฯื่็์ࠣห้ห๊ๆ์็ࠤํะะไำࠣ์้อࠠห่ึํࠥษๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษࠩ໐"))
	search = FaUBpzTGxtS7hZyl(header=Qy6wlfLoOpg1(u"࠭ࡗࡳ࡫ࡷࡩࠥࡧࠠ࡮ࡧࡶࡷࡦ࡭ࡥࡦࠢࠣࠤฬ้สษࠢิืฬ๊ษࠨ໑"),source=wgj0rX5tbcxPulhmny)
	if not search: return
	a1duvQ8Vh0gNo69nDcp3Pjtym = search
	if J3dmKbe7QfWCv1EByjANZ: type = LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠧࡑࡴࡲࡦࡱ࡫࡭ࠨ໒")
	else: type = Pj9YaUq1ibJ(u"ࠨࡏࡨࡷࡸࡧࡧࡦࠩ໓")
	zTEXepHg92GkWf = gitJOXchdnSNVpjbLAKPq6Ds41WRuI(type,a1duvQ8Vh0gNo69nDcp3Pjtym,S5MWhgtZ37Xw,nA5dhMRg6ENzsB0l1GwvH7aIr2,ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠩࡈࡑࡆࡏࡌ࠮ࡈࡕࡓࡒ࠳ࡕࡔࡇࡕࡗࠬ໔"),OOrjZaTIVXQ2Sp0ozhc)
	return
def u5MtiYU2FHl0f8IArJcVLkS9meEP():
	OOrjZaTIVXQ2Sp0ozhc = zhE5I4xHinX0UoVZMNwlkPrR(u"๋ࠪีอࠠศๆหี๋อๅอࠢ็หࠥ๐่อั่ࠣ์ࠦร๋ࠢึ๎ึ็ัࠡ์ึฮ฻๐แࠡลํࠤ๊ำส้์สฮ࠳ࠦวๅสิ๊ฬ๋ฬࠡ์ึฮำีๅࠡำ๋หอ฽้ࠠฬู้๏์ࠠๅ็ะฮํ๐วห่ࠢีๆ๎ูสࠢ฼่๎ࠦำ๋ำไีฬะࠠฯษิะ๏ฯ࠮ࠡษ็ฬึ์วๆฮࠣ฾๏ืࠠๆีว์ู้ࠦ็ࠢฦ๎๋ࠥอห๊ํหฯࠦสๆࠢอั๊๐ไ่ษࠣ฽้๏ࠠิ์ิๅึอส๊่ࠡ์ฬู่ࠡะสีั๐ษࠡࠤ่์ฬูู่ࠡิๅࠥัวๅอࠥ࠲ࠥาๅ๋฻ࠣห้ษำๆษฤࠤํอไๆษิ็ฬะ้ࠠษ็ูํื้ࠠษ็ฺ้๋่าษอࠤ์๐ࠠฯษุอࠥฮวึฯสฬ์อ࠮ࠡษ็ฬึ์วๆฮ่ࠣฬ๊ࠦ็ฬ๊็ࠥำโ้ไࠣห้฽ศฺ๋ࠢห้์ิา๋ࠢๆฬ์่็ࠢส่ศ๊แ๋ห่้๋ࠣไไ์ฬࠤฬ๊ัใ็ํอࠥࡊࡍࡄࡃࠣษีอࠠไษ้ࠤ้ี๊ไࠢื็ํ๏ࠠฯษุอࠥฮวๅำ๋หอ฽้ࠠษ็ฮ฻อๅ๋่ࠣห้ิวาฮํอࠥ็วๅำฯหฦࠦวๅฬ๋หฺ๊ࠠๆ฻ࠣษิอัส๊ࠢิ์ࠦวๅีํีๆืวห๋ࠢห้๋่ศไ฼ࠤฬ๊ฮศำฯ๎ฮ࠴่ࠠาสࠤฬ๊ศา่ส้ัࠦ็้ࠢหฬุอืส่ࠢฮฺ็อࠡๆ่์ฬู่ࠡษ็์๏ฮࠧ໕")
	d9EaJh5t3Tyj7CsXFL(xwIUQfiE7rmvYzH(u"ࠫࡷ࡯ࡧࡩࡶࠪ໖"),lw2snZ9J0uhLoxypqa(u"ࠬำโ้ไࠣห้฽ศฺ๋ࠢห้์ิา๋ࠢๆฬ์่็ࠢส่ศ๊แ๋ห่้๋ࠣไไ์ฬࠤฬ๊ัใ็ํอࠬ໗"),OOrjZaTIVXQ2Sp0ozhc,n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ໘"))
	OOrjZaTIVXQ2Sp0ozhc = lw2snZ9J0uhLoxypqa(u"ࠧࡕࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲࠦࡤࡰࡧࡶࠤࡳࡵࡴࠡࡪࡲࡷࡹࠦࡡ࡯ࡻࠣࡧࡴࡴࡴࡦࡰࡷࠤࡴࡴࠠࡢࡰࡼࠤࡸ࡫ࡲࡷࡧࡵ࠲ࠥࡏࡴࠡࡱࡱࡰࡾࠦࡵࡴࡧࡶࠤࡱ࡯࡮࡬ࡵࠣࡸࡴࠦࡥ࡮ࡤࡨࡨࡩ࡫ࡤࠡࡥࡲࡲࡹ࡫࡮ࡵࠢࡷ࡬ࡦࡺࠠࡸࡣࡶࠤࡺࡶ࡬ࡰࡣࡧࡩࡩࠦࡴࡰࠢࡳࡳࡵࡻ࡬ࡢࡴࠣࡳࡳࡲࡩ࡯ࡧࠣࡺ࡮ࡪࡥࡰࠢ࡫ࡳࡸࡺࡩ࡯ࡩࠣࡷ࡮ࡺࡥࡴ࠰ࠣࡅࡱࡲࠠࡵࡴࡤࡨࡪࡳࡡࡳ࡭ࡶ࠰ࠥࡼࡩࡥࡧࡲࡷ࠱ࠦࡴࡳࡣࡧࡩࠥࡴࡡ࡮ࡧࡶ࠰ࠥࡹࡥࡳࡸ࡬ࡧࡪࠦ࡭ࡢࡴ࡮ࡷ࠱ࠦࡣࡰࡲࡼࡶ࡮࡭ࡨࡵࡧࡧࠤࡼࡵࡲ࡬࠮ࠣࡰࡴ࡭࡯ࡴࠢࡵࡩ࡫࡫ࡲࡦࡰࡦࡩࡩࠦࡨࡦࡴࡨ࡭ࡳࠦࡢࡦ࡮ࡲࡲ࡬ࠦࡴࡰࠢࡷ࡬ࡪ࡯ࡲࠡࡴࡨࡷࡵ࡫ࡣࡵ࡫ࡹࡩࠥࡵࡷ࡯ࡧࡵࡷࠥ࠵ࠠࡤࡱࡰࡴࡦࡴࡩࡦࡵ࠱ࠤ࡙࡮ࡥࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡵࡩࡸࡶ࡯࡯ࡵ࡬ࡦࡱ࡫ࠠࡧࡱࡵࠤࡼ࡮ࡡࡵࠢࡲࡸ࡭࡫ࡲࠡࡲࡨࡳࡵࡲࡥࠡࡷࡳࡰࡴࡧࡤࠡࡶࡲࠤ࠸ࡸࡤࠡࡲࡤࡶࡹࡿࠠࡴ࡫ࡷࡩࡸ࠴ࠠࡘࡧࠣࡹࡷ࡭ࡥࠡࡣ࡯ࡰࠥࡩ࡯ࡱࡻࡵ࡭࡬࡮ࡴࠡࡱࡺࡲࡪࡸࡳ࠭ࠢࡷࡳࠥࡸࡥࡤࡱࡪࡲ࡮ࢀࡥࠡࡶ࡫ࡥࡹࠦࡴࡩࡧࠣࡰ࡮ࡴ࡫ࡴࠢࡦࡳࡳࡺࡡࡪࡰࡨࡨࠥࡽࡩࡵࡪ࡬ࡲࠥࡺࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤࡦࡸࡥࠡ࡮ࡲࡧࡦࡺࡥࡥࠢࡶࡳࡲ࡫ࡷࡩࡧࡵࡩࠥ࡫࡬ࡴࡧࠣࡳࡳࠦࡴࡩࡧࠣࡻࡪࡨࠠࡰࡴࠣࡺ࡮ࡪࡥࡰࠢࡨࡱࡧ࡫ࡤࡥࡧࡧࠤࡦࡸࡥࠡࡨࡵࡳࡲࠦ࡯ࡵࡪࡨࡶࠥࡼࡡࡳ࡫ࡲࡹࡸࠦࡳࡪࡶࡨࡷ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡨࡢࡸࡨࠤࡦࡴࡹࠡ࡮ࡨ࡫ࡦࡲࠠࡪࡵࡶࡹࡪࡹࠠࡱ࡮ࡨࡥࡸ࡫ࠠࡤࡱࡱࡸࡦࡩࡴࠡࡣࡳࡴࡷࡵࡰࡳ࡫ࡤࡸࡪࠦ࡭ࡦࡦ࡬ࡥࠥ࡬ࡩ࡭ࡧࠣࡳࡼࡴࡥࡳࡵࠣ࠳ࠥ࡮࡯ࡴࡶࡨࡶࡸ࠴ࠠࡕࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲࠦࡩࡴࠢࡶ࡭ࡲࡶ࡬ࡺࠢࡤࠤࡼ࡫ࡢࠡࡤࡵࡳࡼࡹࡥࡳ࠰ࠪ໙")
	d9EaJh5t3Tyj7CsXFL(Pj9YaUq1ibJ(u"ࠨ࡮ࡨࡪࡹ࠭໚"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠩࡇ࡭࡬࡯ࡴࡢ࡮ࠣࡑ࡮ࡲ࡬ࡦࡰࡱ࡭ࡺࡳࠠࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠣࡅࡨࡺࠠࠩࡆࡐࡇࡆ࠯ࠧ໛"),OOrjZaTIVXQ2Sp0ozhc,FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ໜ"))
	return
def skYoZMeSH9BQnXLmuAE58qD3CNV():
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,gmPI7hVEM8nD(u"ࠫฬ๊ศา่ส้ัࠦไศࠢํๅา฻ࠠี้สำฮࠦวๅฬืๅ๏ืฺ่ࠠาࠤฬ๊วหืส่ࠥฮวๅ็๋ห็฿ࠠศๆุ่ๆืษ๊ࠡ็๋ีอࠠโ์ࠣัฬ๊้ࠠฮ๋ำฺࠥ็ศัฬࠤ฿๐ัࠡืะ๎าฯࠠฤ๊้๋ࠣะ็๋หࠣห้฻ไศฯํอࠥษ่ࠡ็ี๎ๆฯࠠโษ้ࠤ์ึวࠡๆ้ࠤ๏๎โโࠢส่ึฮืࠡษ็ู้็ั๊ࠡ็๊ࠥ๐่ใใࠣ฽๊๊ࠠศๆหี๋อๅอࠩໝ"))
	ggBAetcGQ0PpVOKNCE1LaHWrswZ3()
	return
def KRrcmelOSDybuw0vMnoP2Wd3qkVz():
	WwBvnNaIZlz7o1y9kG = {}
	iI0NbuVHsG87h9pCMLR4632YaFv,ZFTd57sHPWQYvz1yhjX8GSroNIMwL0,Km5BFgNeECnzdwu263Y = ighZbvAKDn4N()
	jr9ylNbvcHEzPG8UpkL,jL23e6YO9IcvVME,BdkeVTtAKUW9vrcqmy7,N1AwpoxOhTb9gSEFJvZKHmD6,kTIRKDhl5aYVo0cOq3MJpGNvdne6,kkFP23NyJreHxGXIwTo8Q,mW7YVxlNbcJgUEDruyC = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	jr9ylNbvcHEzPG8UpkL = BSiDxUPsdHkz27VMop51uf6c3.join(ZFTd57sHPWQYvz1yhjX8GSroNIMwL0)
	jL23e6YO9IcvVME = BSiDxUPsdHkz27VMop51uf6c3.join(Km5BFgNeECnzdwu263Y)
	ZDNlg4rY0IyGQhn,GsOveSI8PFKatu6bJC24nD7,loVxr85jutg = iI0NbuVHsG87h9pCMLR4632YaFv
	for whXU4NCbPdFAcxErVJIutR8WDM3n,iMjldOyT8rHzKcCw6Rpn4mg70tU5f,tYGhkdaFgPibTzu6vyMA in GsOveSI8PFKatu6bJC24nD7:
		tYGhkdaFgPibTzu6vyMA = jPgzFLH1niJpE2r(tYGhkdaFgPibTzu6vyMA)
		tYGhkdaFgPibTzu6vyMA = tYGhkdaFgPibTzu6vyMA.strip(hSXlxL9iB05c).strip(ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠬࠦ࠮ࠨໞ"))
		SRv8TPC0ZNOQ = whXU4NCbPdFAcxErVJIutR8WDM3n.replace(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ໟ"),JvQd6LMoBX4hiy1C(u"ࠧࡂࡒࡌࠫ໠"))
		N1AwpoxOhTb9gSEFJvZKHmD6 += CXtugbqhV3+lSWzOYmN08+SRv8TPC0ZNOQ+xwIUQfiE7rmvYzH(u"ࠨ࠼ࠣࠫ໡")+NwROdSj3nsA+tYGhkdaFgPibTzu6vyMA+CXtugbqhV3
		if iMjldOyT8rHzKcCw6Rpn4mg70tU5f.isdigit(): WwBvnNaIZlz7o1y9kG[whXU4NCbPdFAcxErVJIutR8WDM3n] = int(iMjldOyT8rHzKcCw6Rpn4mg70tU5f)
	ELvPb7q0ryY2m3Oal6C9uiJ,f41SCoqzm32NlkxJY,p7tImi90VjPBCDxWs = list(zip(*GsOveSI8PFKatu6bJC24nD7))
	for whXU4NCbPdFAcxErVJIutR8WDM3n in sorted(P4GWBlzIwnMq2):
		if whXU4NCbPdFAcxErVJIutR8WDM3n not in ELvPb7q0ryY2m3Oal6C9uiJ:
			N1AwpoxOhTb9gSEFJvZKHmD6 += CXtugbqhV3+lSWzOYmN08+whXU4NCbPdFAcxErVJIutR8WDM3n+YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠩ࠽ࠤࠬ໢")+NwROdSj3nsA+FVxoQ2J5Mfv3Zj6sy9uhOS(u"่ࠪฬ๊้ࠦฮาࠫ໣")+CXtugbqhV3
			if whXU4NCbPdFAcxErVJIutR8WDM3n not in Nzp9Fq5cTr.non_videos_actions: BdkeVTtAKUW9vrcqmy7 += BSiDxUPsdHkz27VMop51uf6c3+whXU4NCbPdFAcxErVJIutR8WDM3n
	for tYGhkdaFgPibTzu6vyMA,qCKtN0J5Arb in ZDNlg4rY0IyGQhn:
		tYGhkdaFgPibTzu6vyMA = jPgzFLH1niJpE2r(tYGhkdaFgPibTzu6vyMA)
		kTIRKDhl5aYVo0cOq3MJpGNvdne6 += tYGhkdaFgPibTzu6vyMA+LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠫ࠿ࠦࠧ໤")+bbTCMJwEx8nhN4X+str(qCKtN0J5Arb)+NwROdSj3nsA+rCmGE4YIDaZA(u"ࠬࠦࠠࠡࠩ໥")
	jr9ylNbvcHEzPG8UpkL = jr9ylNbvcHEzPG8UpkL.strip(hSXlxL9iB05c)
	jL23e6YO9IcvVME = jL23e6YO9IcvVME.strip(hSXlxL9iB05c)
	BdkeVTtAKUW9vrcqmy7 = BdkeVTtAKUW9vrcqmy7.strip(hSXlxL9iB05c)
	japlFBEwb1 = jr9ylNbvcHEzPG8UpkL+DFx6E0uON7Jm8(u"࠭ࠠࠡ࠰࠱ࠤࠥ࠭໦")+jL23e6YO9IcvVME
	BJ0gYlw5jirM2tIAv  = UUobzy0xZLaVScIt7(u"ࠧๆ๊สๆ฾ࠦฬ๋ัฬࠤูเไࠡษ็ฬึ์วๆฮ้๋ࠣํวࠡใํำ๏๎็ศฬࠣๅ๏ࠦ࠳ࠡลํห๊ࠦวๅ็สฺ๏ฯࠠࠩ็้ࠤฬ๊รไอิࠤส๊้ࠡษ็ว็๊ࠩࠨ໧")+CXtugbqhV3+mRanX1HZupfSQVB2gsDGUO(u"ࠨ๊๊ิฬࠦๅฺ่ส๋ࠥหะศࠢ็ำ๏้ࠠๆึๆ่ฮࠦแ๋้่ࠤๆํ๊ࠡ็้ࠤ฾์ฯไ๋่ࠢ๏ูสࠡ็้ࠤฬ๊ศา่ส้ั่ࠦๅษ้๋ࠣࠦวๅ็๋ๆ฾࠭໨")+CXtugbqhV3
	BJ0gYlw5jirM2tIAv += bbTCMJwEx8nhN4X+japlFBEwb1+NwROdSj3nsA+lw2snZ9J0uhLoxypqa(u"ࠩ࡟ࡲࡡࡴࠧ໩")
	BJ0gYlw5jirM2tIAv += xwIUQfiE7rmvYzH(u"้ࠪํอโฺࠢ็้ࠥ๐ิ฻ๆ้๋ࠣํวࠡษ็ฬึ์วๆฮࠣๅ๏ี๊้้สฮࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊ส้ࠢࠫึะศสࠢฦฬัี๊ࠪࠩ໪")+CXtugbqhV3+gmPI7hVEM8nD(u"ࠫํํะศ่ࠢ฽๋อ็ࠡษะฮ๊อไ๊ࠡฯ์ิࠦๅีๅ็อࠥ฿ๆะๅࠣวํࠦแ๋ࠢส่๊๎โฺࠢฦ์ࠥ็๊ࠡษ็ฬึ์วๆฮࠪ໫")+CXtugbqhV3
	BdkeVTtAKUW9vrcqmy7 = BSiDxUPsdHkz27VMop51uf6c3.join(sorted(BdkeVTtAKUW9vrcqmy7.split(BSiDxUPsdHkz27VMop51uf6c3)))
	BJ0gYlw5jirM2tIAv += bbTCMJwEx8nhN4X+BdkeVTtAKUW9vrcqmy7+NwROdSj3nsA
	vPuBptGCdLg3m516acliR9472ezf,G2k93yMo7zP0Cg,k8Ea6OfbCNItlFwVBQjDTqvm,tmvZMLPNYa8ujAisGxEhTSK = YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠰၌"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠰၌"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠰၌"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠰၌")
	all = WwBvnNaIZlz7o1y9kG[zhE5I4xHinX0UoVZMNwlkPrR(u"ࠬࡇࡌࡍࠩ໬")]
	if vzqjsVHSBlMpxC(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭໭") in list(WwBvnNaIZlz7o1y9kG.keys()): vPuBptGCdLg3m516acliR9472ezf = WwBvnNaIZlz7o1y9kG[pxt6wJ8ScYMWCivoO(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ໮")]
	if baBcNd81eH5ry2Olp6Mj43(u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩ໯") in list(WwBvnNaIZlz7o1y9kG.keys()): G2k93yMo7zP0Cg = WwBvnNaIZlz7o1y9kG[xwIUQfiE7rmvYzH(u"ࠩࡌࡒࡘ࡚ࡁࡍࡎࠪ໰")]
	if HD7MQqXd2gS(u"ࠪࡑࡊ࡚ࡒࡐࡒࡒࡐࡎ࡙ࠧ໱") in list(WwBvnNaIZlz7o1y9kG.keys()): k8Ea6OfbCNItlFwVBQjDTqvm = WwBvnNaIZlz7o1y9kG[LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠫࡒࡋࡔࡓࡑࡓࡓࡑࡏࡓࠨ໲")]
	if mRanX1HZupfSQVB2gsDGUO(u"ࠬࡘࡅࡑࡑࡖࠫ໳") in list(WwBvnNaIZlz7o1y9kG.keys()): tmvZMLPNYa8ujAisGxEhTSK = WwBvnNaIZlz7o1y9kG[DFx6E0uON7Jm8(u"࠭ࡒࡆࡒࡒࡗࠬ໴")]
	k9ILSocsi72 = all-vPuBptGCdLg3m516acliR9472ezf-G2k93yMo7zP0Cg-k8Ea6OfbCNItlFwVBQjDTqvm-tmvZMLPNYa8ujAisGxEhTSK
	eIlXpH1gLhmP4w3,zsKU4WjrxYHbMLo8 = loVxr85jutg[IpFcwrWNgefMym3qta0hYQAzOdE]
	eIlXpH1gLhmP4w3,KNp5kmAoLigsd = loVxr85jutg[UnOIK1WBbw2]
	y9yiZ7PCxKzOdrXvMl1LqG = zsKU4WjrxYHbMLo8-KNp5kmAoLigsd
	mW7YVxlNbcJgUEDruyC += lSWzOYmN08+str(KNp5kmAoLigsd)+NwROdSj3nsA+PPxYugzLZwHX23yiK(u"ࠧศๆ฼ำิࠦวๅฯๅ๎็๐ࠠๅๆฦะ์ุษࠡ࠼ࠣࠫ໵")
	mW7YVxlNbcJgUEDruyC += CXtugbqhV3+lSWzOYmN08+str(y9yiZ7PCxKzOdrXvMl1LqG)+NwROdSj3nsA+PPxYugzLZwHX23yiK(u"ࠨสสืฯิฯศ็ࠣࡴࡷࡵࡸࡺࠢฦ์ࠥࡼࡰ࡯ࠢ࠽ࠤࠬ໶")
	mW7YVxlNbcJgUEDruyC += CXtugbqhV3+lSWzOYmN08+str(zsKU4WjrxYHbMLo8)+NwROdSj3nsA+lw2snZ9J0uhLoxypqa(u"ࠩส่฾ีฯࠡษ็็้๐ࠠๅฮ่๎฾ࠦวๅลฯ๋ืฯࠠ࠻ࠢࠪ໷")
	mW7YVxlNbcJgUEDruyC += CXtugbqhV3+lSWzOYmN08+str(len(loVxr85jutg[Yj1msqVeivESfrCupRy9b7WacBd(u"࠳၍"):]))+NwROdSj3nsA+mRanX1HZupfSQVB2gsDGUO(u"ࠪ฽ิีࠠศๆา์้ࠦวๅฬํࠤๆ๐็ศࠢฦะ์ุษࠡ࠼ࠣࡠࡳࡢ࡮ࠨ໸")
	for iPWN5tr1aBS0YZnmlgOM,QQlJ2xKXAGUzh in loVxr85jutg[JvQd6LMoBX4hiy1C(u"࠴၎"):]:
		iPWN5tr1aBS0YZnmlgOM = jPgzFLH1niJpE2r(iPWN5tr1aBS0YZnmlgOM)
		iPWN5tr1aBS0YZnmlgOM = iPWN5tr1aBS0YZnmlgOM.strip(hSXlxL9iB05c).strip(zhE5I4xHinX0UoVZMNwlkPrR(u"ࠫࠥ࠴ࠧ໹"))
		mW7YVxlNbcJgUEDruyC += iPWN5tr1aBS0YZnmlgOM+bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠬࡀࠠࠨ໺")+bbTCMJwEx8nhN4X+str(QQlJ2xKXAGUzh)+NwROdSj3nsA+baBcNd81eH5ry2Olp6Mj43(u"࠭ࠠࠡࠢࠪ໻")
	kkFP23NyJreHxGXIwTo8Q += lSWzOYmN08+str(k9ILSocsi72)+NwROdSj3nsA+ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠧโ์า๎ํํวหࠢสุฯเไหࠢ࠽ࠤࠬ໼")
	kkFP23NyJreHxGXIwTo8Q += CXtugbqhV3+lSWzOYmN08+str(vPuBptGCdLg3m516acliR9472ezf)+NwROdSj3nsA+baBcNd81eH5ry2Olp6Mj43(u"ࠨู็ฬฬะࠠิ์ิๅึࠦࡁࡑࡋࠣ࠾ࠥ࠭໽")
	kkFP23NyJreHxGXIwTo8Q += CXtugbqhV3+lSWzOYmN08+str(tmvZMLPNYa8ujAisGxEhTSK)+NwROdSj3nsA+zhE5I4xHinX0UoVZMNwlkPrR(u"ฺ่ࠩออสࠡีํีๆืࠠศๆ่ืฯ๎ฯฺࠢ࠽ࠤࠬ໾")
	kkFP23NyJreHxGXIwTo8Q += CXtugbqhV3+lSWzOYmN08+str(G2k93yMo7zP0Cg)+NwROdSj3nsA+xwIUQfiE7rmvYzH(u"ࠪฮะฮ๊หࠢอ฻อ๐โࠡๅ๋ำ๏ูࠦๆษาࠤ࠿ࠦࠧ໿")
	kkFP23NyJreHxGXIwTo8Q += CXtugbqhV3+lSWzOYmN08+str(k8Ea6OfbCNItlFwVBQjDTqvm)+NwROdSj3nsA+YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠫฯัศ๋ฬࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠻ࠢࠪༀ")
	kkFP23NyJreHxGXIwTo8Q += CXtugbqhV3+lSWzOYmN08+str(len(ZDNlg4rY0IyGQhn))+NwROdSj3nsA+pxt6wJ8ScYMWCivoO(u"ࠬี่ๅࠢื฾้ะࠠโ์า๎ํํวหࠢ࠽ࠤࠬ༁")
	kkFP23NyJreHxGXIwTo8Q += bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠭࡜࡯࡞ࡱࠫ༂")+kTIRKDhl5aYVo0cOq3MJpGNvdne6
	d9EaJh5t3Tyj7CsXFL(PPxYugzLZwHX23yiK(u"ࠧࡤࡧࡱࡸࡪࡸࠧ༃"),bb1fgjsAq4N2xYwnoh39lm(u"ࠨ฻าำࠥอไโ์า๎ํํวหࠢส่ฯ๐ࠠี฼็๋ฬࠦ็ัษࠣห้ฮั็ษ่ะࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠢไ๎ࠥอไฺษ็้้ࠥไ่ࠩ༄"),kkFP23NyJreHxGXIwTo8Q,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ༅"))
	d9EaJh5t3Tyj7CsXFL(bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠪࡧࡪࡴࡴࡦࡴࠪ༆"),AJHaiQq3PRd5cphzGuELnVg9X(u"๊ࠫ๎วใ฻ࠣหูะฺๅฬࠣๅ๏ࠦ࠳ࠡลํห๊ࠦวๅ็สฺ๏ฯࠠโ์ࠣห้฿วๅ็ࠣ็้ํࠧ༇"),BJ0gYlw5jirM2tIAv,LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ༈"))
	d9EaJh5t3Tyj7CsXFL(gmPI7hVEM8nD(u"࠭࡬ࡦࡨࡷࠫ༉"),baBcNd81eH5ry2Olp6Mj43(u"ࠧฤ฻็ํࠥอไะ๊็ࠤฬ๊ส๋ࠢสืฯิฯๆฬࠣห้ฮั็ษ่ะࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠩ༊"),N1AwpoxOhTb9gSEFJvZKHmD6,pxt6wJ8ScYMWCivoO(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩ་"))
	return
def aXvgH9eTSF5xMifEkZIAz():
	a1duvQ8Vh0gNo69nDcp3Pjtym = jil8vRpBsENVYyPmDd(u"๊ࠩิฬࠦวๅสิ๊ฬ๋ฬࠡ์฼้้ࠦวโุ็ࠤออำหะาห๊ࠦฬๅัࠣ็ํี๊ࠡࠪࡎࡳࡩ࡯ࠠࡔ࡭࡬ࡲ࠮ࠦวๅาํࠤฬูๅ่࡞ࡱࠫ༌")+lSWzOYmN08+bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ།")+NwROdSj3nsA+lw2snZ9J0uhLoxypqa(u"ࠫࡡࡴ࡜࡯࡞ࡱࠤํ๋ๅไ่ࠣฮะฮ๊ห้ࠣฬฬูสฯัส้๋ࠥำห๊า฽ࠥ฿ๅศัࠣࡉࡒࡇࡄࠡࡔࡨࡴࡴࡹࡩࡵࡱࡵࡽࠥษ่ࠡฬะ้๏๊็ࠡ็้ࡠࡳ࠭༎")+lSWzOYmN08+AJHaiQq3PRd5cphzGuELnVg9X(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮ࡶ࡭࠱ࡸࡴ࠭༏")+NwROdSj3nsA+bb1fgjsAq4N2xYwnoh39lm(u"࠭࡜࡯࡞ࡱࡠࡳࠦ็ั้ࠣห้ืำศๆฬࠤํเ๊า้สࠤ่ั๊า่ࠢ์ั๎ฯสࠢไ๎่ࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะࠥ๎วๅ็ี๎ิࠦรุ๋สࠤ๊๎ฬ้ัࠣๅ๏ࠦโศศ่อࠥษฬ้สฬࠤฬ๊ศา่ส้ั࠭༐")
	d9EaJh5t3Tyj7CsXFL(XEcWOIwkZKubV7vQ(u"ࠧࡤࡧࡱࡸࡪࡸࠧ༑"),OksCHeoL5SG,a1duvQ8Vh0gNo69nDcp3Pjtym,Yj1msqVeivESfrCupRy9b7WacBd(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ༒"))
	return
def iI3JWfjo4rBM():
	a1duvQ8Vh0gNo69nDcp3Pjtym = YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠩส่ึอศุ์้ࠤศีๆศ้ࠣๅ๏ํๅศࠢอ฻อ๐โࠡๅ๋ำ๏ูࠦๆษาࠤํํ่ࠡ฻หหึฯฺ่ࠠࠣฮะฮ๊หࠢๆห๊๊ࠠศ๊อ์๊อส๋ๅํࠤ้ฮั็ษ่ะ้่ࠥะ์ࠣ์๊฿็ࠡษูหๆฯฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠣ์๊฿็ࠡษูหๆฯࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤํู๋่ࠢสฺฬ็ษࠡ็ึฮํีูࠡ฻่หิ่ࠦโ์๊ࠤศ๐ึศࠢฯ้๏฿ࠠศ฻าหิะࠠไ๊า๎ࠥอไๆู็์อฯࠠๅ฻่่ࠥฮั็ษ่ะࠥ฿ๅศัࠣ์่๊็ศࠢอฮ๊ࠦว้ฬ๋้ฬะ๊ไ์สࠤํ๊วࠡฬะฮฬาࠠฤ์๊ࠣํ฿ࠠๆ่ࠣห้ิศาหࠣๅ๏ࠦใ้ัํࠤศ๎ࠠศๆัฬึฯࠠโ์ࠣฮะฮ๊หࠢฦฺฬ็วหࠢๆ์ิ๐ࠧ༓")+CXtugbqhV3+bbTCMJwEx8nhN4X+Nzp9Fq5cTr.SITESURLS[jil8vRpBsENVYyPmDd(u"ࠪࡏࡔࡊࡉࡆࡏࡄࡈࡤࡇࡐࡑࠩ༔")][IpFcwrWNgefMym3qta0hYQAzOdE]+NwROdSj3nsA+ldIfvn6asURQ9toi85EhqAXW3(u"ࠫࠥࠦࠠࠡล๋ࠤࠥࠦࠠࠨ༕")+bbTCMJwEx8nhN4X+Nzp9Fq5cTr.SITESURLS[jil8vRpBsENVYyPmDd(u"ࠬࡑࡏࡅࡋࡈࡑࡆࡊ࡟ࡂࡒࡓࠫ༖")][UnOIK1WBbw2]+NwROdSj3nsA
	a1duvQ8Vh0gNo69nDcp3Pjtym += gmPI7hVEM8nD(u"࠭࡜࡯࡞ࡱࡠࡳอไาษห฻ࠥษฯ็ษ๊ࠤ์๎ࠠศๆึ์ึูࠠศๆำ๎ࠥ๐อหษฯ๋๋ࠥฯ๋ำ้้ࠣ็วหࠢๆ์ิ๐ࠠๅฬฮฬ๏ะࠠษำ้ห๊าฺࠠ็สำࠥฮวๅูิ๎็ฯࠠศๆอๆ้๐ฯ๋หࠣห้่ฯ๋็ฬࡠࡳ࠭༗")+bbTCMJwEx8nhN4X+Nzp9Fq5cTr.SITESURLS[AJHaiQq3PRd5cphzGuELnVg9X(u"ࠧࡌࡑࡇࡍࡤ࡙ࡏࡖࡔࡆࡉࡘ༘࠭")][IpFcwrWNgefMym3qta0hYQAzOdE]+NwROdSj3nsA+YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠨࠢࠣࠤࠥษ่ࠡࠢࠣࠤ༙ࠬ")+bbTCMJwEx8nhN4X+Nzp9Fq5cTr.SITESURLS[VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠩࡎࡓࡉࡏ࡟ࡔࡑࡘࡖࡈࡋࡓࠨ༚")][UnOIK1WBbw2]+NwROdSj3nsA
	a1duvQ8Vh0gNo69nDcp3Pjtym += LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠪࡠࡳࡢ࡮࡝ࡰฯ้๏฿ࠠๆๆไหฯูࠦๆษาࠤ๊๎ฬ้ัฬࠤๆ๐ࠠศๆ่์็฿ࠠฤั้ห์࠭༛")+CXtugbqhV3+bbTCMJwEx8nhN4X+Nzp9Fq5cTr.SITESURLS[ldIfvn6asURQ9toi85EhqAXW3(u"ࠫࡋࡏࡌࡆࡕࡢࡗࡔ࡛ࡒࡄࡇࡖࠫ༜")][IpFcwrWNgefMym3qta0hYQAzOdE]+NwROdSj3nsA
	d9EaJh5t3Tyj7CsXFL(jil8vRpBsENVYyPmDd(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ༝"),Pj9YaUq1ibJ(u"࠭วๅ็๋ห็฿ࠠศๆิื๊๐ษࠡๆหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠬ༞"),a1duvQ8Vh0gNo69nDcp3Pjtym,nfNTgkiWdUq(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ༟"))
	return
def KUmjl5a41P9ks0TuYdtbZeqMcLrO8G(cY4n5fGTaiHRQgVM0hbWqXpv):
	SoNGUfhMDERLyHOz1qkVAj.executebuiltin(YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠨࡃࡧࡨࡴࡴ࠮ࡐࡲࡨࡲࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠮ࠧ༠")+cY4n5fGTaiHRQgVM0hbWqXpv+AJHaiQq3PRd5cphzGuELnVg9X(u"ࠩࠬࠫ༡"), S5MWhgtZ37Xw)
	return
def b5FWlN9LhQ1c():
	B8DRukzCLEiX0JbZtPvwUTOWA(UUobzy0xZLaVScIt7(u"ࠪࡷࡹࡵࡰࠨ༢"))
	SoNGUfhMDERLyHOz1qkVAj.executebuiltin(JvQd6LMoBX4hiy1C(u"ࠦࡆࡩࡴࡪࡸࡤࡸࡪ࡝ࡩ࡯ࡦࡲࡻ࠭ࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࡔࡧࡷࡸ࡮ࡴࡧࡴࠫࠥ༣"))
	return
def SpuV5zRLDxmWcs():
	SoNGUfhMDERLyHOz1qkVAj.executebuiltin(gmPI7hVEM8nD(u"ࠬࡇࡤࡥࡱࡱ࠲ࡔࡶࡥ࡯ࡕࡨࡸࡹ࡯࡮ࡨࡵࠫ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠬࠫ༤"), S5MWhgtZ37Xw)
	return
def sftaSLlCFyD():
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,UUobzy0xZLaVScIt7(u"࠭ไๆีะࠤ๊ำส้์สฮ่ࠥวว็ฬࠤ࠳ࠦวั้หࠤส๊้ࠡษ็ๆฬฬๅสࠢส่ฯ๐ࠠหำํำ๋ࠥำฮ้สࠤํ๊วࠡฬาา้ࠦลๅ์๊หࠥ๎ไไ่ࠣฬฬูสฯัส้ࠥࠨวๅ็ส์ุࠨࠠฤ๊ࠣࠦฬ๊ั๋็๋ฮࠧࠦวื฼ฺࠤ฾๊้ࠡษ็ึึࠦฬ่หࠣห้๐ๅ๋่ࠣวํࠦวิฬัำ๊ࠦࠢศๆๆ๎อ๎ัะࠤࠣ์ฬ฼ฺุࠢ฼่๎ࠦอาใࠣࠦࡈࠨࠠฤ๊ࠣ฽้๏ࠠศุ฽฻ࠥ฿ไ๊ࠢีีࠥࠨวๅไสส๊ฯࠢࠡษ็ิ๏ࠦแ๋ࠢฯ๋ฮࠦวๅ์่๎๋࠭༥"))
	return
def zCnHfmByw6W():
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,Qy6wlfLoOpg1(u"ࠧๅๆอ฽ฬ๋ไࠡ็฼ࠤฬ๊ๅโุ็อࠥ࠴ࠠศา๊ฬࠥหไ๊ࠢส่ึอศุࠢส่ี๐ࠠหำํำࠥหึศใอ๋ࠥษ่ࠡ็ึั์ࠦๅ็ࠢࠣๆฬฬๅสࠢส่๊็ึๅหࠣ์้้ๆࠡๆสࠤฯ์โาࠢ฼่๏ํ้ࠠๆสࠤฯฺฺๅ้ࠣ࠲ࠥ๎ศศีอาิอๅࠡࠤส่๊อ่ิࠤࠣวํࠦࠢศๆิ๎๊๎สࠣࠢสฺ฿฽ฺࠠๆ์ࠤฬ๊าาࠢฯ๋ฮࠦวๅ์่๎๋ࠦ࠮๊ࠡฦ้ฬࠦศศีอาิอๅࠡࠤส่่๐ศ้ำาࠦࠥ็วื฼ฺࠤ฾๊้ࠡฯิๅࠥࠨࡃࠣࠢฦ์ࠥ฿ไ๊ࠢีีࠥࠨวๅไสส๊ฯࠢࠡษ็ิ๏ࠦแ๋ࠢฯ๋ฮࠦวๅ์่๎๋ࠦ࠮๊้ࠡๅุࠦวๅๅ็ห๊่ࠦศๆฺี๏่ษࠡ฻้ำࠥอไห฻ส้้ࠦๅฺ่ࠢัฯ๎๊ศฬࠣๆํอฦๆࠢส่๊็ึๅหࠪ༦"))
	return
def ttVEJ8S0CKTuhH6vzMa5N1F(agSsdtKzcmX0UZEBjRLTfkhx2i43p=bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ༧"),showDialogs=S5MWhgtZ37Xw):
	POhJdDXSrE0p = SoNGUfhMDERLyHOz1qkVAj.executeJSONRPC(PPxYugzLZwHX23yiK(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤࢀࢁࠬ༨"))
	data = DcFpQN9gqn.loads(POhJdDXSrE0p)
	uA9PfwV7yN4xkqnI1OS26HcvRLdl = data[yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠪࡶࡪࡹࡵ࡭ࡶࠪ༩")][HD7MQqXd2gS(u"ࠫࡻࡧ࡬ࡶࡧࠪ༪")]
	if cS2NYw4xulqJgvzkMF: uA9PfwV7yN4xkqnI1OS26HcvRLdl = uA9PfwV7yN4xkqnI1OS26HcvRLdl.encode(YWEQ3Cf8RevpD0m7NjF1)
	if showDialogs:
		x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,DFx6E0uON7Jm8(u"ࠬํไࠡฬิ๎ิࠦส฻์ํีࠥาไะࠢࠪ༫")+uA9PfwV7yN4xkqnI1OS26HcvRLdl+PPxYugzLZwHX23yiK(u"࠭ࠠศๆำ๎๋ࠥำหะา้ࠥอไร่ࠣๅ๏ࠦใ้ัํࠤส๊้ࠡษ็ษฺีวาࠢส่ศิ๊าࠢ็ะ้ีࠠࠨ༬")+agSsdtKzcmX0UZEBjRLTfkhx2i43p+ldIfvn6asURQ9toi85EhqAXW3(u"ࠧࠡมࠤࠫ༭"))
		if x6zlf2tTZm!=lw2snZ9J0uhLoxypqa(u"࠴၏"): return FFKncZx5pDTwdiJRYhMgQSNL
	zTEXepHg92GkWf,L9rpEVxMSlsaUzPn2wOeYBftICq,x4x8dq1EeFm = SNlKELcfWt9zMaAOZQFP(agSsdtKzcmX0UZEBjRLTfkhx2i43p,FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL)
	if zTEXepHg92GkWf:
		if showDialogs: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,baBcNd81eH5ry2Olp6Mj43(u"ࠨฬ่ฮࠥ฿ๅๅ์ฬࠤฯัศ๋ฬࠣห้าไะࠢส่ัี๊ะ๋๋ࠢํࠦฬศ้ีࠤ้๊วิฬัำฬ๋ࠠ࠯ࠢึ์ๆ๊ࠦห็ࠣห้ศๆࠡฬ฽๎๏ืࠠฦ฻าหิอสࠡๅ๋ำ๏ࠦไไ์ࠣ๎ุะูๆๆࠣห้าไะࠢส่ัี๊ะࠢหำ้อࠠๆ่ࠣห้่ฯ๋็ࠪ༮"))
		UwQYtvDH9oc8nOemluxdCXKr2JN = SoNGUfhMDERLyHOz1qkVAj.executeJSONRPC(Yj1msqVeivESfrCupRy9b7WacBd(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡗࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤ࠯ࠦࡻࡧ࡬ࡶࡧࠥ࠾ࠧ࠭༯")+agSsdtKzcmX0UZEBjRLTfkhx2i43p+mRanX1HZupfSQVB2gsDGUO(u"ࠪࠦࢂࢃࠧ༰"))
		zTEXepHg92GkWf = S5MWhgtZ37Xw if PPxYugzLZwHX23yiK(u"ࠫࡔࡑࠧ༱") in UwQYtvDH9oc8nOemluxdCXKr2JN else FFKncZx5pDTwdiJRYhMgQSNL
		h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(xwIUQfiE7rmvYzH(u"࠵ၐ"))
		SoNGUfhMDERLyHOz1qkVAj.executebuiltin(lw2snZ9J0uhLoxypqa(u"࡙ࠬࡥ࡯ࡦࡆࡰ࡮ࡩ࡫ࠩ࠳࠴࠭ࠬ༲"))
	elif showDialogs: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,baBcNd81eH5ry2Olp6Mj43(u"࠭ไๅลึๅࠥ็ิๅฬࠣ฽๊๊๊สࠢอฯอ๐ส๊ࠡอๅ฾๐ไࠡษ็ะ้ีࠠศๆ่฻้๎ศࠨ༳"))
	return zTEXepHg92GkWf
def ddG7M83chw1BFWgD():
	url = JvQd6LMoBX4hiy1C(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮࡫ࡵࡶࡴࡸࡳ࠯࡭ࡲࡨ࡮࠴ࡴࡷ࠱ࡵࡩࡱ࡫ࡡࡴࡧࡶ࠳ࡼ࡯࡮ࡥࡱࡺࡷ࠴ࡽࡩ࡯࠸࠷࠳ࠬ༴")
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠨࡉࡈࡘ༵ࠬ"),url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡘࡎࡏࡘࡡࡏࡅ࡙ࡋࡓࡕࡡࡎࡓࡉࡏ࡟ࡗࡇࡕࡗࡎࡕࡎ࠮࠳ࡶࡸࠬ༶"))
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zCQ4Fng9kUyLOhxRbSDEu6lv0P5a8q = PAztbuyYo4Kvd.findall(AJHaiQq3PRd5cphzGuELnVg9X(u"ࠪࡸ࡮ࡺ࡬ࡦ࠿ࠥ࡯ࡴࡪࡩ࠮ࠪ࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠱ࡠࡧ࠭ࡻࡃ࠰࡞ࡢ࠱ࠩ࠮༷ࠩ"),kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	zCQ4Fng9kUyLOhxRbSDEu6lv0P5a8q = zCQ4Fng9kUyLOhxRbSDEu6lv0P5a8q[IpFcwrWNgefMym3qta0hYQAzOdE].split(bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠫ࠲࠭༸"))[IpFcwrWNgefMym3qta0hYQAzOdE]
	IJi7x4PRjhASEC = str(l2JAnWsaDGz8CIEZY)
	N1AwpoxOhTb9gSEFJvZKHmD6 = XEcWOIwkZKubV7vQ(u"ࠬࡡࡒࡕࡎࡠษฺีวาࠢๆ์ิ๐ࠠศๆฦา๏ืࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤ༹ࠥࠦࠧ")+lSWzOYmN08+zCQ4Fng9kUyLOhxRbSDEu6lv0P5a8q+NwROdSj3nsA
	N1AwpoxOhTb9gSEFJvZKHmD6 += w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠭࡜࡯࡞ࡱࠫ༺")+bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠧ࡜ࡔࡗࡐࡢหีะษิࠤ่๎ฯ๋ࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋ࠥํ่ࠡ࠼ࠣࠤࠥ࠭༻")+lSWzOYmN08+IJi7x4PRjhASEC+NwROdSj3nsA
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,N1AwpoxOhTb9gSEFJvZKHmD6)
	return
def zdH6utpK2wOGlc():
	t4OvS1a2fjV9rzo,C4JcvBLETwtYAIHSbyPn,JQX9OeY0RA82EdKSwWBHg = FFKncZx5pDTwdiJRYhMgQSNL,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	NYdIWsy23EkoHwG7gaDQcKB,Zjp5K9N2sSCX7l3H,yfhxIi7ktS2 = FFKncZx5pDTwdiJRYhMgQSNL,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	R5Ru96VUB2cXWTMGPOnLef3KNkS = [UUobzy0xZLaVScIt7(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭༼"),xwIUQfiE7rmvYzH(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ༽"),XEcWOIwkZKubV7vQ(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ༾")]
	KxieNnJUoIR9uj = gOHnJkmlPAGjiqN(R5Ru96VUB2cXWTMGPOnLef3KNkS)
	for jmPwATvkoixS92pOuas in R5Ru96VUB2cXWTMGPOnLef3KNkS:
		if jmPwATvkoixS92pOuas not in list(KxieNnJUoIR9uj.keys()): continue
		ozirPWaNn5j9lUwbtOxEJIv0uT,iSUYvwkn67LMq54zWO,LqWTcx69EMZ0orBkRGmg,oXAWxOcB62YG8Dya5H7wqPhK1fkR,lRiromYq6Kh7EC5wtsk,IIgs9UQ8vm42Koh7,mSiLWanTBc3tqfypPv7k6RHV2QFoj = KxieNnJUoIR9uj[jmPwATvkoixS92pOuas]
		if jmPwATvkoixS92pOuas==yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ༿"):
			NYdIWsy23EkoHwG7gaDQcKB = ozirPWaNn5j9lUwbtOxEJIv0uT
			Zjp5K9N2sSCX7l3H = iSUYvwkn67LMq54zWO+zhE5I4xHinX0UoVZMNwlkPrR(u"ࠬࠦࠠࠡࠢࠫࠤࠬཀ")+AEyNnLOu7g6BGrw5tlcj(IIgs9UQ8vm42Koh7)+nfNTgkiWdUq(u"࠭ࠠࠪࠩཁ")
			yfhxIi7ktS2 = oXAWxOcB62YG8Dya5H7wqPhK1fkR
		elif jmPwATvkoixS92pOuas==UUobzy0xZLaVScIt7(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩག"):
			t4OvS1a2fjV9rzo = t4OvS1a2fjV9rzo or ozirPWaNn5j9lUwbtOxEJIv0uT
			C4JcvBLETwtYAIHSbyPn += bb1fgjsAq4N2xYwnoh39lm(u"ࠨࠢࠣ࠰ࠥࠦࠧགྷ")+iSUYvwkn67LMq54zWO+ldIfvn6asURQ9toi85EhqAXW3(u"ࠩࠣࠤࠥࠦࠨࠡࠩང")+AEyNnLOu7g6BGrw5tlcj(IIgs9UQ8vm42Koh7)+rCmGE4YIDaZA(u"ࠪࠤ࠮࠭ཅ")
			JQX9OeY0RA82EdKSwWBHg += LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠫࠥࠦࠬࠡࠢࠪཆ")+oXAWxOcB62YG8Dya5H7wqPhK1fkR
		elif jmPwATvkoixS92pOuas==VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫཇ"):
			z1toTUGZ65QAbBcr70j3CuKJpPqd = ozirPWaNn5j9lUwbtOxEJIv0uT
			SayigXNbQ6OFcHIp = iSUYvwkn67LMq54zWO+VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠭ࠠࠡࠢࠣࠬࠥ࠭཈")+AEyNnLOu7g6BGrw5tlcj(IIgs9UQ8vm42Koh7)+AJHaiQq3PRd5cphzGuELnVg9X(u"ࠧࠡࠫࠪཉ")
			q2OgiAh7vnek = oXAWxOcB62YG8Dya5H7wqPhK1fkR
	C4JcvBLETwtYAIHSbyPn = C4JcvBLETwtYAIHSbyPn.strip(w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠨࠢࠣ࠰ࠥࠦࠧཊ"))
	JQX9OeY0RA82EdKSwWBHg = JQX9OeY0RA82EdKSwWBHg.strip(YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠩࠣࠤ࠱ࠦࠠࠨཋ"))
	gtDwSCe3Z9xfL5zn  = JvQd6LMoBX4hiy1C(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ศิ๊าࠢ็ฬึ์วๆฮࠣ฽๊อฯࠡษ็้ฯ๎แาࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠠࠨཌ")+lSWzOYmN08+yfhxIi7ktS2+NwROdSj3nsA
	gtDwSCe3Z9xfL5zn += CXtugbqhV3+bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦไษำ้ห๊าฺࠠ็สำࠥํ่ࠡ࠼ࠣࠤࠥ࠭ཌྷ")+lSWzOYmN08+Zjp5K9N2sSCX7l3H+NwROdSj3nsA
	gtDwSCe3Z9xfL5zn += zhE5I4xHinX0UoVZMNwlkPrR(u"ࠬࡢ࡮࡝ࡰࠪཎ")+yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไฤะํี๊ࠥๅิฬ๋ำ฾ูࠦๆษาࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣࠫཏ")+lSWzOYmN08+JQX9OeY0RA82EdKSwWBHg+NwROdSj3nsA
	gtDwSCe3Z9xfL5zn += CXtugbqhV3+bb1fgjsAq4N2xYwnoh39lm(u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅาํࠤฬ์สࠡฬึฮำีๅ่ࠢ็ุ้ะ่ะ฻ࠣ฽๊อฯ้๋ࠡࠤ࠿ࠦࠠࠡࠩཐ")+lSWzOYmN08+C4JcvBLETwtYAIHSbyPn+NwROdSj3nsA
	gtDwSCe3Z9xfL5zn += YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠨ࡞ࡱࡠࡳ࠭ད")+zhE5I4xHinX0UoVZMNwlkPrR(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥ࠭དྷ")+lSWzOYmN08+q2OgiAh7vnek+NwROdSj3nsA
	gtDwSCe3Z9xfL5zn += CXtugbqhV3+xwIUQfiE7rmvYzH(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋๊ࠥฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศั๋ࠣํࠦ࠺ࠡࠢࠣࠫན")+lSWzOYmN08+SayigXNbQ6OFcHIp+NwROdSj3nsA
	ozirPWaNn5j9lUwbtOxEJIv0uT = NYdIWsy23EkoHwG7gaDQcKB or t4OvS1a2fjV9rzo
	if ozirPWaNn5j9lUwbtOxEJIv0uT:
		header = n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠫฬ๊ัอษฤࠤฯำฯ๋อࠣษ฻อแศฬࠣ็ํี๊ࠡๆะ่ࠥอไๆึส็้࠭པ")
		oyiZl283hIc9BNv = PPxYugzLZwHX23yiK(u"ࠬอๆหࠢหัฬาษࠡๆอัิ๐หࠡสิ๊ฬ๋ฬࠡ฻่หิࠦร้ࠢอัิ๐หࠡ็ึฮํีูࠡ฻่หิ࠭ཕ")
	else:
		header = n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠭อศๆํห๊ࠥวࠡ์๋ะิࠦสฮัํฯฬะࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦร้่ࠢืฯ๎ฯฺࠢ฼้ฬีࠧབ")
		oyiZl283hIc9BNv = bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠧศๆิะฬวࠠฦส็ห฿ࠦวๅ็หี๊าฺ่ࠠࠣห้๋ิไๆฬࠤฬ๊ส๋ࠢอ์ฬา็ไࠩབྷ")
	k7EHn02TyKNpduB9SRWG5JMx = ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠨๆๆ๎ࠥ๐ูๆๆࠣ฽๋ีใࠡษ็ฮาี๊ฬࠢส่ฯ๊โศศํࠤ๏าศࠡล้ࠤ๏้่็ࠢ็ำ๏้ࠠโ์ࠣ็ํี๊࡝ࡰ่ืฯ๎ฯฺࠢ฼้ฬีࠠࡆࡏࡄࡈࠥࡘࡥࡱࡱࡶ࡭ࡹࡵࡲࡺࠩམ")
	WQCm8UvrpDYB = gtDwSCe3Z9xfL5zn+FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠩ࡟ࡲࡡࡴࠧཙ")+oyiZl283hIc9BNv+bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠪࡠࡳࡢ࡮ࠨཚ")+k7EHn02TyKNpduB9SRWG5JMx
	d9EaJh5t3Tyj7CsXFL(XEcWOIwkZKubV7vQ(u"ࠫࡷ࡯ࡧࡩࡶࠪཛ"),header,WQCm8UvrpDYB,w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨཛྷ"))
	return ozirPWaNn5j9lUwbtOxEJIv0uT
def qQcXZr4Pk6pg9RBIdEMjaiO3hvD(jmPwATvkoixS92pOuas,mSiLWanTBc3tqfypPv7k6RHV2QFoj,showDialogs):
	zTEXepHg92GkWf = FFKncZx5pDTwdiJRYhMgQSNL
	if showDialogs:
		x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,ldIfvn6asURQ9toi85EhqAXW3(u"࠭ำ้ใࠣ๎ฯ๋ࠠศๆล๊ࠥาไษࠢส่๊๊แࠡษ็้฻เุ่ࠢ็่ส฼วโหࠣห้๋ืๅ๊หอ๊ࠥใ๋ࠢํฮ๊ࠦสฬสํฮ์ูࠦๅ๋ࠣ็ํี๊ࠡ࠰ࠣห้๋ไโࠢๅำࠥ๐ใ้่ࠣ็อ๐ั๊ࠡๅำࠥ๐อหษฯࠤอ฿ึࠡษ็์็ะࠠ࠯๊่ࠢࠥะั๋ัࠣฮา๋๊ๅࠢส่๊๊แࠡษ็ฦ๋ࠦฟࠢࠩཝ"))
		if x6zlf2tTZm!=UnOIK1WBbw2: return FFKncZx5pDTwdiJRYhMgQSNL
	bbxtVz2hp958murcQqy = Ew2exk7boOIaX(mSiLWanTBc3tqfypPv7k6RHV2QFoj,{},showDialogs)
	if bbxtVz2hp958murcQqy:
		guESBP6KazmZU = XoZRpFe7B6gnfA.path.join(y9SrAlWpbuYgeEQ,jmPwATvkoixS92pOuas)
		mJZ2eb9HzawrqRCsU7D6(guESBP6KazmZU,S5MWhgtZ37Xw,FFKncZx5pDTwdiJRYhMgQSNL)
		import zipfile as qQLkyShPxDiz0E5gf,io as TtdE4jc1FvAMuwq5Kso3I
		NwTq2rphRHWYFbjaU3oQlyXsId45 = TtdE4jc1FvAMuwq5Kso3I.BytesIO(bbxtVz2hp958murcQqy)
		try:
			G7Cze8Uxbv = qQLkyShPxDiz0E5gf.ZipFile(NwTq2rphRHWYFbjaU3oQlyXsId45)
			G7Cze8Uxbv.extractall(y9SrAlWpbuYgeEQ)
			h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(UnOIK1WBbw2)
			SoNGUfhMDERLyHOz1qkVAj.executebuiltin(JvQd6LMoBX4hiy1C(u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫཞ"))
			h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(UnOIK1WBbw2)
			zTEXepHg92GkWf = pphURl8yNGDLfVr1YInAKE(jmPwATvkoixS92pOuas)
		except: zTEXepHg92GkWf = FFKncZx5pDTwdiJRYhMgQSNL
	if showDialogs:
		if zTEXepHg92GkWf: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,bb1fgjsAq4N2xYwnoh39lm(u"ࠨฬ่ࠤอ์ฬศฯࠣฮะฮ๊หࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠬཟ"))
		else: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,AJHaiQq3PRd5cphzGuELnVg9X(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥะหษ์อࠤฬ๊ลืษไอࠥอไๆู็์อฯࠧའ"))
	return zTEXepHg92GkWf
def zfTIJNiuLFM2Kj(jmPwATvkoixS92pOuas,showDialogs=S5MWhgtZ37Xw):
	if showDialogs==nA5dhMRg6ENzsB0l1GwvH7aIr2: showDialogs = S5MWhgtZ37Xw
	xK4gcQE0hu8TArX37sBPW5mpMFqyR1 = UDTcAkV9d4sqbgwh([jmPwATvkoixS92pOuas])
	xFTwHdVkMo9bGv8ilWhR2BePn,v7ZNstILn8yXxb2MUGiTBrCkFP6D = xK4gcQE0hu8TArX37sBPW5mpMFqyR1[jmPwATvkoixS92pOuas]
	if v7ZNstILn8yXxb2MUGiTBrCkFP6D:
		zTEXepHg92GkWf = S5MWhgtZ37Xw
		if showDialogs: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠪๅา฻ࠠศๆศฺฬ็ษࠡ࡞ࡱࠤࠬཡ")+jmPwATvkoixS92pOuas+zhE5I4xHinX0UoVZMNwlkPrR(u"ࠫࠥࡢ࡮้ࠡำ๋ࠥษไฦุสๅฮูࠦ็ัๆࠤ๊๎ฬ้ัฬࠤํ๋แฺๆฬࠤําว่ิฬࠤ้๊วิฬัำฬ๋ࠧར"))
	else:
		zTEXepHg92GkWf = FFKncZx5pDTwdiJRYhMgQSNL
		x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(jil8vRpBsENVYyPmDd(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬལ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,nA5dhMRg6ENzsB0l1GwvH7aIr2+jmPwATvkoixS92pOuas+bb1fgjsAq4N2xYwnoh39lm(u"࠭ࠠ࡝ࡰ࡟ࡲࠥํะ่ࠢฦ่ส฼วโหࠣ฽๋ีใࠡ฼ํี๋ࠥแฺๆฬࠤศ๎ࠠ฻์ิࠤ๊๎ฬ้ัฬࠤํอไษำ้ห๊าࠠษฯสะฮࠦไ่ษࠣ࠲ࠥํไࠡฬิ๎ิࠦสฬสํฮࠥ๎สโ฻ํ่ࠥํะ่ࠢส่ส฼วโหࠣห้ศๆࠡมࠪཤ"))
		if x6zlf2tTZm==xwIUQfiE7rmvYzH(u"࠶ၑ"):
			SoNGUfhMDERLyHOz1qkVAj.executebuiltin(LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠧࡊࡰࡶࡸࡦࡲ࡬ࡂࡦࡧࡳࡳ࠮ࠧཥ")+jmPwATvkoixS92pOuas+Yj1msqVeivESfrCupRy9b7WacBd(u"ࠨࠫࠪས"))
			h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(baBcNd81eH5ry2Olp6Mj43(u"࠷ၒ"))
			SoNGUfhMDERLyHOz1qkVAj.executebuiltin(lw2snZ9J0uhLoxypqa(u"ࠩࡖࡩࡳࡪࡃ࡭࡫ࡦ࡯࠭࠷࠱ࠪࠩཧ"))
			h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(Pj9YaUq1ibJ(u"࠱ၓ"))
			while SoNGUfhMDERLyHOz1qkVAj.getCondVisibility(bqCDnV7Bs5XgRvuKLNAa1Uz(u"࡛ࠪ࡮ࡴࡤࡰࡹ࠱ࡍࡸࡇࡣࡵ࡫ࡹࡩ࠭ࡶࡲࡰࡩࡵࡩࡸࡹࡤࡪࡣ࡯ࡳ࡬࠯ࠧཨ")): h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(lw2snZ9J0uhLoxypqa(u"࠲ၔ"))
			zTEXepHg92GkWf = pphURl8yNGDLfVr1YInAKE(jmPwATvkoixS92pOuas)
			if showDialogs and zTEXepHg92GkWf: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,Pj9YaUq1ibJ(u"ࠫฯ๋ࠠโฯุࠤฬ๊ลืษไอࠥอไๆู็์อฯ้้ࠠํࠤฬ๊ย็ࠢฯห์ุษࠡๆ็หุะฮะษ่ࠫཀྵ"))
			elif showDialogs: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,AJHaiQq3PRd5cphzGuELnVg9X(u"ࠬ็ิๅࠢไ๎ࠥะหษ์อࠤศ๎ࠠหใ฼๎้ࠦร้ࠢอัิ๐หࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠤ࠳่ࠦศๆะ่ࠥํ่ࠡฬฮฬ๏ะ็ศ๋ࠢฮๆ฿๊ๅ้สࠤ๊์ࠠฯษิะࠥอไษำ้ห๊าࠧཪ"))
	return zTEXepHg92GkWf
def rOB0126CsQku8fmRngM4N7D(showDialogs):
	if not showDialogs: x6zlf2tTZm = S5MWhgtZ37Xw
	else: x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(XEcWOIwkZKubV7vQ(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ཫ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠧษำ้ห๊าࠠไ๊า๎ࠥ๐โ้็ࠣฬ฾๋ไ๋หࠣฮาี๊ฬࠢฯ้๏฿ࠠศๆศฺฬ็วหࠢอ่็อฦ๋ษࠣ็้ࠦ࠲࠵ࠢึห฾ฯ้ࠠๆๆ๊๋ࠥๅไ่ࠣษัืวย้สࠤฬ๊ย็ࠢ࠱ࠤ์๊ࠠหำํำࠥอไร่ࠣว๋ࠦสุๆหࠤ๊์ࠠไ๊า๎ࠥ็อึ๋ࠢฮาี๊ฬࠢฯ้๏฿ࠠศๆศฺฬ็วหࠢยࠫཬ"))
	if x6zlf2tTZm==LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠳ၕ"):
		SoNGUfhMDERLyHOz1qkVAj.executebuiltin(nfNTgkiWdUq(u"ࠨࡗࡳࡨࡦࡺࡥࡂࡦࡧࡳࡳࡘࡥࡱࡱࡶࠫ཭"))
		if showDialogs:
			OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠩอ้ࠥหัิษ็ࠤ฼๊ศࠡว็ํࠥฮั็ษ่ะ้่ࠥะ์ࠣห้ึ๊ࠡใํࠤัํวำๅ่่ࠣ๐๋ࠠไ๋้ࠥฮสฮัํฯࠥาๅ๋฻ࠣษ฻อแศฬࠣ็ํี๊ࠡ࠰ࠣฬ๊อࠠโ์๊หࠥะอะ์ฮࠤ์ึวࠡษ็ฬึ์วๆฮࠣ์ฯำฯ๋อุ้ࠣะ่ะ฻ࠣ฽๊อฯࠡ࠰ࠣ๎ึา้ࠡว฼฻ฬวࠠไ๊า๎ࠥ࠻ࠠะไสส็ࠦร้ࠢฦ็ะืࠠๅๅํࠤ๏์็๋ࠢ฼้้๐ษࠡษ็ฮาี๊ฬࠩ཮"))
	return
def GGvnphbiLuEtqKA():
	aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,JvQd6LMoBX4hiy1C(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕࡥ࠱ࠨ཯"),PPxYugzLZwHX23yiK(u"ࠫࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐࠬ཰"))
	ddG7M83chw1BFWgD()
	ozirPWaNn5j9lUwbtOxEJIv0uT = zdH6utpK2wOGlc()
	if ozirPWaNn5j9lUwbtOxEJIv0uT:
		mzxoBQsiXNTZt6cw5gOyfLAjprRh(S5MWhgtZ37Xw)
		rOB0126CsQku8fmRngM4N7D(S5MWhgtZ37Xw)
		AA5FS4hUqeP9EsZCM(FFKncZx5pDTwdiJRYhMgQSNL)
	return
def pphURl8yNGDLfVr1YInAKE(jmPwATvkoixS92pOuas):
	V9OGBuyogH0CaUtQS6wWErAbPYDjlM = SoNGUfhMDERLyHOz1qkVAj.executeJSONRPC(UUobzy0xZLaVScIt7(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡆࡪࡤࡰࡰࡶ࠲ࡘ࡫ࡴࡂࡦࡧࡳࡳࡋ࡮ࡢࡤ࡯ࡩࡩࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡦࡪࡤࡰࡰ࡬ࡨࠧࡀࠢࠨཱ")+jmPwATvkoixS92pOuas+nfNTgkiWdUq(u"࠭ࠢ࠭ࠤࡨࡲࡦࡨ࡬ࡦࡦࠥ࠾ࡹࡸࡵࡦࡿࢀིࠫ"))
	succeeded = S5MWhgtZ37Xw if Qy6wlfLoOpg1(u"ࠧࡐࡍཱིࠪ") in V9OGBuyogH0CaUtQS6wWErAbPYDjlM else FFKncZx5pDTwdiJRYhMgQSNL
	return succeeded
def xwEaMGBOCV21bSql(jmPwATvkoixS92pOuas):
	V9OGBuyogH0CaUtQS6wWErAbPYDjlM = SoNGUfhMDERLyHOz1qkVAj.executeJSONRPC(ldIfvn6asURQ9toi85EhqAXW3(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡂࡦࡧࡳࡳࡹ࠮ࡔࡧࡷࡅࡩࡪ࡯࡯ࡇࡱࡥࡧࡲࡥࡥࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡢࡦࡧࡳࡳ࡯ࡤࠣ࠼ུࠥࠫ")+jmPwATvkoixS92pOuas+pxt6wJ8ScYMWCivoO(u"ࠩࠥ࠰ࠧ࡫࡮ࡢࡤ࡯ࡩࡩࠨ࠺ࡧࡣ࡯ࡷࡪࢃࡽࠨཱུ"))
	succeeded = S5MWhgtZ37Xw if LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠪࡓࡐ࠭ྲྀ") in V9OGBuyogH0CaUtQS6wWErAbPYDjlM else FFKncZx5pDTwdiJRYhMgQSNL
	return succeeded
def SNlKELcfWt9zMaAOZQFP(jmPwATvkoixS92pOuas,showDialogs,V0i2yHX5aUl38ZOYedj,KxieNnJUoIR9uj=None):
	x6zlf2tTZm,succeeded,L9rpEVxMSlsaUzPn2wOeYBftICq,iSUYvwkn67LMq54zWO = S5MWhgtZ37Xw,FFKncZx5pDTwdiJRYhMgQSNL,HD7MQqXd2gS(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫཷ"),nA5dhMRg6ENzsB0l1GwvH7aIr2
	if not KxieNnJUoIR9uj: KxieNnJUoIR9uj = gOHnJkmlPAGjiqN([jmPwATvkoixS92pOuas])
	if jmPwATvkoixS92pOuas in list(KxieNnJUoIR9uj.keys()):
		ozirPWaNn5j9lUwbtOxEJIv0uT,iSUYvwkn67LMq54zWO,LqWTcx69EMZ0orBkRGmg,oXAWxOcB62YG8Dya5H7wqPhK1fkR,lRiromYq6Kh7EC5wtsk,IIgs9UQ8vm42Koh7,mSiLWanTBc3tqfypPv7k6RHV2QFoj = KxieNnJUoIR9uj[jmPwATvkoixS92pOuas]
		if IIgs9UQ8vm42Koh7==nfNTgkiWdUq(u"ࠬ࡭࡯ࡰࡦࠪླྀ"):
			succeeded,L9rpEVxMSlsaUzPn2wOeYBftICq = S5MWhgtZ37Xw,w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠭࡮ࡰࡶ࡫࡭ࡳ࡭ࠧཹ")
			if V0i2yHX5aUl38ZOYedj and showDialogs:
				x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠧอ์าࠤัีวࠡ࠰࠱ࠤ่๎ฯ๋ࠢํืฯิฯๆࠢฦาึࠦลึัสี๋ࠥส้ใิࠤๆ๐ࠠๆ๊สๆ฾ࠦๅิฬ๋ำ฾ูࠦๆษาࠤ้ํะ่ࠢส่ส฼วโห࡟ࡲࡡࡴེࠧ")+jmPwATvkoixS92pOuas+AJHaiQq3PRd5cphzGuELnVg9X(u"ࠨ࡞ࡱࡠࡳํไࠡฬิ๎ิࠦลฺษาอࠥะหษ์อࠤ์ึ็ࠡษ็ษ฻อแส่ࠢีฮࠦรฯำ์ཻࠫ"))
				if x6zlf2tTZm:
					succeeded = qQcXZr4Pk6pg9RBIdEMjaiO3hvD(jmPwATvkoixS92pOuas,mSiLWanTBc3tqfypPv7k6RHV2QFoj,FFKncZx5pDTwdiJRYhMgQSNL)
					if succeeded:
						L9rpEVxMSlsaUzPn2wOeYBftICq = UUobzy0xZLaVScIt7(u"ࠩࡵࡩ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪོࠧ")
						if showDialogs: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,mRanX1HZupfSQVB2gsDGUO(u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠศๆศฺฬ็ษࠡๅส๊ฯࠦๅ้ฮ๋ำฮࠦ࠮࠯๋ࠢๆฬ๋ࠠศๆหี๋อๅอࠢหษ฾อฯสࠢอฯอ๐ส่ษ࡟ࡲࡡࡴཽࠧ")+jmPwATvkoixS92pOuas)
					else:
						L9rpEVxMSlsaUzPn2wOeYBftICq = mRanX1HZupfSQVB2gsDGUO(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫཾ")
						OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,zhE5I4xHinX0UoVZMNwlkPrR(u"๊ࠬไฤีไࠤ࠳࠴ࠠศๆหี๋อๅอࠢ็้ࠥ๐ำหูํ฽ࠥหูศัฬࠤฯัศ๋ฬ๋ࠣีํࠠศๆศฺฬ็ษ࡝ࡰ࡟ࡲࠬཿ")+jmPwATvkoixS92pOuas)
		else:
			if showDialogs:
				if IIgs9UQ8vm42Koh7==HD7MQqXd2gS(u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࡤࠨྀ"): a1duvQ8Vh0gNo69nDcp3Pjtym = bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠧๆฬ๋ๆๆฯཱྀࠧ")
				elif IIgs9UQ8vm42Koh7==PPxYugzLZwHX23yiK(u"ࠨࡱ࡯ࡨࠬྂ"): a1duvQ8Vh0gNo69nDcp3Pjtym = PPxYugzLZwHX23yiK(u"ࠩๅำ๏๋ษࠨྃ")
				elif IIgs9UQ8vm42Koh7==YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠪࡱ࡮ࡹࡳࡪࡰࡪ྄ࠫ"): a1duvQ8Vh0gNo69nDcp3Pjtym = FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠫ฿๐ัࠡ็ฮฬฯฯࠧ྅")
				x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,zhE5I4xHinX0UoVZMNwlkPrR(u"ࠬํะ่ࠢส่ส฼วโหࠣࠫ྆")+a1duvQ8Vh0gNo69nDcp3Pjtym+gmPI7hVEM8nD(u"࠭ࠠ࠯࠰๋้ࠣࠦสา์าࠤส฻ไศฯ๋ࠣีํࠠศๆุ่่๊ษࠡมࠤࡠࡳࡢ࡮ࠨ྇")+jmPwATvkoixS92pOuas)
			if not x6zlf2tTZm: L9rpEVxMSlsaUzPn2wOeYBftICq = vzqjsVHSBlMpxC(u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࠩྈ")
			else:
				if IIgs9UQ8vm42Koh7==ldIfvn6asURQ9toi85EhqAXW3(u"ࠨࡦ࡬ࡷࡦࡨ࡬ࡦࡦࠪྉ"):
					succeeded = pphURl8yNGDLfVr1YInAKE(jmPwATvkoixS92pOuas)
					if succeeded:
						L9rpEVxMSlsaUzPn2wOeYBftICq = n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠩࡨࡲࡦࡨ࡬ࡦࡦࠪྊ")
						if showDialogs: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,JvQd6LMoBX4hiy1C(u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠศๆศฺฬ็ษࠡๅส๊ฯࠦๅห๊ๅๅฮࠦ࠮࠯๋ࠢๆฬ๋ࠠศๆหี๋อๅอࠢหฮูเ๊ๅ้สࡠࡳࡢ࡮ࠨྋ")+jmPwATvkoixS92pOuas)
					elif showDialogs: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,AJHaiQq3PRd5cphzGuELnVg9X(u"้๊ࠫริใࠣ࠲࠳ࠦวๅวูหๆฯࠠๆฬ๋ๆๆฯࠠ࠯࠰ࠣ์้๋๋ࠠีอ฻๏฿ࠠศๆหี๋อๅอࠢอุ฿๐ไ่ษ࡟ࡲࡡࡴࠧྌ")+jmPwATvkoixS92pOuas)
				elif IIgs9UQ8vm42Koh7 in [Qy6wlfLoOpg1(u"ࠬࡵ࡬ࡥࠩྍ"),XEcWOIwkZKubV7vQ(u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧྎ")]:
					succeeded = qQcXZr4Pk6pg9RBIdEMjaiO3hvD(jmPwATvkoixS92pOuas,mSiLWanTBc3tqfypPv7k6RHV2QFoj,FFKncZx5pDTwdiJRYhMgQSNL)
					if succeeded:
						if IIgs9UQ8vm42Koh7==gmPI7hVEM8nD(u"ࠧࡰ࡮ࡧࠫྏ"): L9rpEVxMSlsaUzPn2wOeYBftICq = pxt6wJ8ScYMWCivoO(u"ࠨࡷࡳࡨࡦࡺࡥࡥࠩྐ")
						elif IIgs9UQ8vm42Koh7==jil8vRpBsENVYyPmDd(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪྑ"): L9rpEVxMSlsaUzPn2wOeYBftICq = gmPI7hVEM8nD(u"ࠪ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠭ྒ")
						iSUYvwkn67LMq54zWO = oXAWxOcB62YG8Dya5H7wqPhK1fkR
						if showDialogs:
							if L9rpEVxMSlsaUzPn2wOeYBftICq==gmPI7hVEM8nD(u"ࠫࡺࡶࡤࡢࡶࡨࡨࠬྒྷ"): OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,PPxYugzLZwHX23yiK(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢส่ส฼วโหࠣ็ฬ์สࠡไา๎๊ฯࠠ࠯࠰ࠣ์ฬ๊ศา่ส้ัࠦโศ็ࠣฬฯำฯ๋อ๊หࡡࡴ࡜࡯ࠩྔ")+jmPwATvkoixS92pOuas)
							elif L9rpEVxMSlsaUzPn2wOeYBftICq==yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠭ࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠩྕ"): OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,ldIfvn6asURQ9toi85EhqAXW3(u"ࠧอ์าࠤัีวࠡ࠰࠱ࠤฬ๊ลืษไอ๊ࠥๅࠡฬๆ๊๋่ࠥอ๊าอࠥ็๊ࠡๅ๋ำ๏ࠦ࠮࠯๋ࠢห้ฮั็ษ่ะ่ࠥวๆࠢหฮะฮ๊ห้สࡠࡳࡢ࡮ࠨྖ")+jmPwATvkoixS92pOuas)
					elif showDialogs: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,JvQd6LMoBX4hiy1C(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣห้ฮั็ษ่ะ๊ࠥๅࠡ์ึฮ฼๐ูࠡฬะำ๏ัࠠฤ๊ࠣฮะฮ๊ห๊ࠢิ์ࠦวๅวูหๆฯ࡜࡯࡞ࡱࠫྗ")+jmPwATvkoixS92pOuas)
	elif showDialogs: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠩ็่ศูแࠡ࠰࠱ࠤ์ึ็ࠡษ็ษ฻อแสࠢ฽๎ึࠦๅ้ฮ๋ำฮࠦแ๋่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠ࠯࠰ࠣ์้ํะศࠢ็หࠥ๐ำหูํ฽ࠥอไษำ้ห๊าࠠฤ่ࠣ๎็๎ๅࠡสอฯอ๐ส้ࠡำ๋ࠥอไฦุสๅฮࠦร้ࠢอัิ๐ห่ษ࡟ࡲࡡࡴࠧ྘")+jmPwATvkoixS92pOuas)
	return succeeded,L9rpEVxMSlsaUzPn2wOeYBftICq,iSUYvwkn67LMq54zWO
def kszeX7LnlW2TGa(jmPwATvkoixS92pOuas,showDialogs,q8BVAH0wUM):
	rm6vXhBWV7u5NyEORS2QkelI4c = NpEaoJdsihbVYkrfHOuMeycA.connect(NS8ELxPk4JMTa2gzrHjnoh)
	rm6vXhBWV7u5NyEORS2QkelI4c.text_factory = str
	ADJdGOPzaeo0rXf2SuKQbcFWqilw = rm6vXhBWV7u5NyEORS2QkelI4c.cursor()
	succeeded,EH98hkmL5zF0643br = S5MWhgtZ37Xw,FFKncZx5pDTwdiJRYhMgQSNL
	try:
		UgaKGHhtv1ZuNyiJDC = pxt6wJ8ScYMWCivoO(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬྙ")
		ADJdGOPzaeo0rXf2SuKQbcFWqilw.execute(ldIfvn6asURQ9toi85EhqAXW3(u"ࠫࡘࡋࡌࡆࡅࡗࠤࡴࡸࡩࡨ࡫ࡱࠤࡋࡘࡏࡎࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩྚ")+jmPwATvkoixS92pOuas+nfNTgkiWdUq(u"ࠬࠨࠠ࠼ࠩྛ"))
		pxoW2F57mI6JXcqrfhUgnYwCZQ = ADJdGOPzaeo0rXf2SuKQbcFWqilw.fetchall()
		if pxoW2F57mI6JXcqrfhUgnYwCZQ and UgaKGHhtv1ZuNyiJDC not in str(pxoW2F57mI6JXcqrfhUgnYwCZQ): ADJdGOPzaeo0rXf2SuKQbcFWqilw.execute(gmPI7hVEM8nD(u"࠭ࡕࡑࡆࡄࡘࡊࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠢࡖࡉ࡙ࠦ࡯ࡳ࡫ࡪ࡭ࡳࠦ࠽ࠡࠤࠪྜ")+UgaKGHhtv1ZuNyiJDC+ldIfvn6asURQ9toi85EhqAXW3(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭ྜྷ")+jmPwATvkoixS92pOuas+PPxYugzLZwHX23yiK(u"ࠨࠤࠣ࠿ࠬྞ"))
		cgTMLjCouWyVtI1Kv0nxr = VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠩࡥࡰࡦࡩ࡫࡭࡫ࡶࡸࠬྟ") if cS2NYw4xulqJgvzkMF else baBcNd81eH5ry2Olp6Mj43(u"ࠪࡹࡵࡪࡡࡵࡧࡢࡶࡺࡲࡥࡴࠩྠ")
		ADJdGOPzaeo0rXf2SuKQbcFWqilw.execute(YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠫࡘࡋࡌࡆࡅࡗࠤ࠯ࠦࡆࡓࡑࡐࠤࠬྡ")+cgTMLjCouWyVtI1Kv0nxr+baBcNd81eH5ry2Olp6Mj43(u"ࠬࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪྡྷ")+jmPwATvkoixS92pOuas+yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠭ࠢࠡ࠽ࠪྣ"))
		pxoW2F57mI6JXcqrfhUgnYwCZQ = ADJdGOPzaeo0rXf2SuKQbcFWqilw.fetchall()
		if pxoW2F57mI6JXcqrfhUgnYwCZQ:
			if showDialogs: x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠧศๆอัิ๐หࠡษ็วํะ่ๆษอ๎่๐ࠠๅวูหๆฯࠠ࡝ࡰࠣࠫྤ")+jmPwATvkoixS92pOuas+YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠨࠢ࡟ࡲࡡࡴࠠࠨྥ")+bbTCMJwEx8nhN4X+PPxYugzLZwHX23yiK(u"้ࠩࠣฯ๎โโ๋่ࠢฬฺ๊ࠦ็็ࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡฬไ฽๏๊็ࠡษ็ฦ๋ࠦฟࠢࠣࠣࠫྦ")+NwROdSj3nsA+Pj9YaUq1ibJ(u"ࠪࠤࡡࡴ࡜࡯ࠢอืฯ฽ฺ๊ࠢศ๎็อแ่ࠢหื์๎ไสࠢ฼๊ิࠦวๅ฻๋ำฮࠦลๅ๋๋ࠣีํࠠศๆืหูฯࠠศๆ่์ั๎ฯสࠢไ๎่ࠥวว็ฬࠤำีๅศฬࠣฬึ์วๆฮࠣ฽๊อฯࠨྦྷ"))
			else: x6zlf2tTZm = UnOIK1WBbw2
			if x6zlf2tTZm==UnOIK1WBbw2:
				EH98hkmL5zF0643br = S5MWhgtZ37Xw
				ADJdGOPzaeo0rXf2SuKQbcFWqilw.execute(ldIfvn6asURQ9toi85EhqAXW3(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠪྨ")+cgTMLjCouWyVtI1Kv0nxr+jil8vRpBsENVYyPmDd(u"ࠬࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪྩ")+jmPwATvkoixS92pOuas+DFx6E0uON7Jm8(u"࠭ࠢࠡ࠽ࠪྪ"))
		elif q8BVAH0wUM:
			if showDialogs: x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,Pj9YaUq1ibJ(u"ࠧศๆอัิ๐หࠡษ็วํะ่ๆษอ๎่๐ࠠๅวูหๆฯࠠ࡝ࡰࠣࠫྫ")+jmPwATvkoixS92pOuas+pxt6wJ8ScYMWCivoO(u"ࠨࠢ࡟ࡲࡡࡴࠠࠨྫྷ")+bbTCMJwEx8nhN4X+Qy6wlfLoOpg1(u"้ࠩࠣๆ฿ไ๊ࠡํ฽๊๊ࠠ࠯࠰๋้ࠣࠦสา์าࠤส๐โศใ๊ࠤฬ๊ย็ࠢยࠥࠦࠦࠧྭ")+NwROdSj3nsA+PPxYugzLZwHX23yiK(u"ࠪࠤࡡࡴ࡜࡯ࠢอืฯ฽ฺ๊ࠢอๅ฾๐ไ่ࠢหื์๎ไสࠢ฼๊ิࠦวๅ฻๋ำฮࠦลๅ๋๋ࠣีํࠠศๆืหูฯࠠศๆ่์ั๎ฯสࠢไ๎่ࠥวว็ฬࠤำีๅศฬࠣฬึ์วๆฮࠣ฽๊อฯࠨྮ"))
			else: x6zlf2tTZm = UnOIK1WBbw2
			if x6zlf2tTZm==UnOIK1WBbw2:
				EH98hkmL5zF0643br = S5MWhgtZ37Xw
				if cS2NYw4xulqJgvzkMF: ADJdGOPzaeo0rXf2SuKQbcFWqilw.execute(Qy6wlfLoOpg1(u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠪྯ")+cgTMLjCouWyVtI1Kv0nxr+ldIfvn6asURQ9toi85EhqAXW3(u"ࠬࠦࠨࡢࡦࡧࡳࡳࡏࡄ࡙ࠪࠢࡅࡑ࡛ࡅࡔࠢࠫࠦࠬྰ")+jmPwATvkoixS92pOuas+pxt6wJ8ScYMWCivoO(u"࠭ࠢࠪࠢ࠾ࠫྱ"))
				else: ADJdGOPzaeo0rXf2SuKQbcFWqilw.execute(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥ࠭ྲ")+cgTMLjCouWyVtI1Kv0nxr+DFx6E0uON7Jm8(u"ࠨࠢࠫࡥࡩࡪ࡯࡯ࡋࡇ࠰ࡺࡶࡤࡢࡶࡨࡖࡺࡲࡥ࡙ࠪࠢࡅࡑ࡛ࡅࡔࠢࠫࠦࠬླ")+jmPwATvkoixS92pOuas+nfNTgkiWdUq(u"ࠩࠥ࠰࠶࠯ࠠ࠼ࠩྴ"))
	except: succeeded = FFKncZx5pDTwdiJRYhMgQSNL
	rm6vXhBWV7u5NyEORS2QkelI4c.commit()
	rm6vXhBWV7u5NyEORS2QkelI4c.close()
	if EH98hkmL5zF0643br:
		h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(pxt6wJ8ScYMWCivoO(u"࠴ၖ"))
		SoNGUfhMDERLyHOz1qkVAj.executebuiltin(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧྵ"))
		h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(ZjELJ9VrUT07R8Hn4FuSDcf(u"࠵ၗ"))
		if showDialogs:
			if succeeded: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,baBcNd81eH5ry2Olp6Mj43(u"๋ࠫาอหࠢ฼้้๐ษࠡวุ่ฬำࠠหฯา๎ะࠦวๅวูหๆฯࠠ࡝ࡰ࡟ࡲࠬྶ")+jmPwATvkoixS92pOuas)
			else: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,baBcNd81eH5ry2Olp6Mj43(u"ࠬ็ิๅฬࠣ฽๊๊๊สࠢศู้ออࠡฬะำ๏ัࠠศๆศฺฬ็ษࠡ࡞ࡱࡠࡳ࠭ྷ")+jmPwATvkoixS92pOuas)
	return EH98hkmL5zF0643br
def fsypSgIu8ezW3ND(R5Ru96VUB2cXWTMGPOnLef3KNkS,showDialogs,V0i2yHX5aUl38ZOYedj,q8BVAH0wUM):
	KxieNnJUoIR9uj = gOHnJkmlPAGjiqN(R5Ru96VUB2cXWTMGPOnLef3KNkS)
	QiRDZH2VoL4 = FFKncZx5pDTwdiJRYhMgQSNL
	for jmPwATvkoixS92pOuas in R5Ru96VUB2cXWTMGPOnLef3KNkS:
		succeeded,L9rpEVxMSlsaUzPn2wOeYBftICq,iSUYvwkn67LMq54zWO = SNlKELcfWt9zMaAOZQFP(jmPwATvkoixS92pOuas,showDialogs,V0i2yHX5aUl38ZOYedj,KxieNnJUoIR9uj)
		EH98hkmL5zF0643br = kszeX7LnlW2TGa(jmPwATvkoixS92pOuas,showDialogs,q8BVAH0wUM)
		if EH98hkmL5zF0643br: QiRDZH2VoL4 = S5MWhgtZ37Xw
	if QiRDZH2VoL4:
		h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(jil8vRpBsENVYyPmDd(u"࠶ၘ"))
		SoNGUfhMDERLyHOz1qkVAj.executebuiltin(baBcNd81eH5ry2Olp6Mj43(u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪྸ"))
		h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(jil8vRpBsENVYyPmDd(u"࠷ၙ"))
	if showDialogs:
		if len(R5Ru96VUB2cXWTMGPOnLef3KNkS)>xwIUQfiE7rmvYzH(u"࠱ၚ"): OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,AJHaiQq3PRd5cphzGuELnVg9X(u"ࠧห็ࠣฬ๋าวฮࠢไัฺࠦฬๆ์฼ࠤฬ๊ลืษไหฯ࠭ྐྵ"))
		else: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,JvQd6LMoBX4hiy1C(u"ࠨฬ่ࠤอ์ฬศฯࠣๅา฻ࠠศๆศฺฬ็ษ࡝ࡰ࡟ࡲࠬྺ")+R5Ru96VUB2cXWTMGPOnLef3KNkS[JvQd6LMoBX4hiy1C(u"࠱ၛ")])
	return
def mzxoBQsiXNTZt6cw5gOyfLAjprRh(showDialogs):
	Wfh0UvuNwMn = [UUobzy0xZLaVScIt7(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧྻ"),pxt6wJ8ScYMWCivoO(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬྼ"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡷ࡫ࡳࡰ࡮ࡹࡩࡺࡸ࡬ࠨ྽"),Pj9YaUq1ibJ(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿࡴ࠮ࡦ࡯ࡴࠬ྾")]
	WEiXRzZh6rIomc = [LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡱࡷ࡬ࡪࡸࡳࠨ྿"),mRanX1HZupfSQVB2gsDGUO(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡪ࡭ࡹ࡫ࡥࠨ࿀"),pxt6wJ8ScYMWCivoO(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨࠫ࿁"),vzqjsVHSBlMpxC(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲࡬࡯ࡴࡩࡷࡥࠫ࿂"),HD7MQqXd2gS(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡧࡤࠫ࿃"),ldIfvn6asURQ9toi85EhqAXW3(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡣࡰࡦࡨࡦࡪࡸࡧࠨ࿄")]
	for jmPwATvkoixS92pOuas in WEiXRzZh6rIomc: xwEaMGBOCV21bSql(jmPwATvkoixS92pOuas)
	fsypSgIu8ezW3ND(Wfh0UvuNwMn,showDialogs,FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL)
	return
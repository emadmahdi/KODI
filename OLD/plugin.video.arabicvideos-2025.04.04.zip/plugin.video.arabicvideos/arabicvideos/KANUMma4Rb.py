# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'SHOOFMAX'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_SHM_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
Ega71ZGOcjfw = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][1]
XXtMiQq2Ij3OhzRnWT = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][2]
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==50: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==51: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
	elif mode==52: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LLabVp7hzj28CE0f1udx(url)
	elif mode==53: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==55: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YJBwfnE9vlDxrV7eb52oNK60GAtc1i()
	elif mode==56: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = RRSDp2fuT7otNHc6ryXWsl3bM8m()
	elif mode==57: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = rYAf8NzmSqsLXgpKMVUCIHtjZ1JucD(url,1)
	elif mode==58: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = rYAf8NzmSqsLXgpKMVUCIHtjZ1JucD(url,2)
	elif mode==59: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,59,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'المسلسلات',nA5dhMRg6ENzsB0l1GwvH7aIr2,56)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الافلام',nA5dhMRg6ENzsB0l1GwvH7aIr2,55)
	return nA5dhMRg6ENzsB0l1GwvH7aIr2
def YJBwfnE9vlDxrV7eb52oNK60GAtc1i():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'أفلام مرتبة بسنة الإنتاج',GiqvpBF9xLEdHDr37byJSngeCQ+'/movie/1/yop',57)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'أفلام مرتبة بالأفضل تقييم',GiqvpBF9xLEdHDr37byJSngeCQ+'/movie/1/review',57)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'أفلام مرتبة بالأكثر مشاهدة',GiqvpBF9xLEdHDr37byJSngeCQ+'/movie/1/views',57)
	return
def RRSDp2fuT7otNHc6ryXWsl3bM8m():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مسلسلات مرتبة بسنة الإنتاج',GiqvpBF9xLEdHDr37byJSngeCQ+'/series/1/yop',57)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مسلسلات مرتبة بالأفضل تقييم',GiqvpBF9xLEdHDr37byJSngeCQ+'/series/1/review',57)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مسلسلات مرتبة بالأكثر مشاهدة',GiqvpBF9xLEdHDr37byJSngeCQ+'/series/1/views',57)
	return
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url):
	if '?' in url:
		yoGhEciOC1 = url.split('?')
		url = yoGhEciOC1[0]
		filter = '?' + kGE6zoKSan54W(yoGhEciOC1[1],'=&:/%')
	else: filter = nA5dhMRg6ENzsB0l1GwvH7aIr2
	type,Q0f7ytucSriRw8HTzd,sort = url.split('/')[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': UmQgD1n6NZh2IpLV7='فيلم'
		elif type=='series': UmQgD1n6NZh2IpLV7='مسلسل'
		url = GiqvpBF9xLEdHDr37byJSngeCQ + '/genre/filter/' + kGE6zoKSan54W(UmQgD1n6NZh2IpLV7) + '/' + Q0f7ytucSriRw8HTzd + '/' + sort + filter
		kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SHOOFMAX-TITLES-1st')
		items = PAztbuyYo4Kvd.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		HUSvGqye1ZJTEl7Q=0
		for id,title,TQ9DFpiKUIzRAja,HRlygv7YwjzbSLt8fkEerq2 in items:
			HUSvGqye1ZJTEl7Q += 1
			HRlygv7YwjzbSLt8fkEerq2 = XXtMiQq2Ij3OhzRnWT + '/v2/img/program/main/' + HRlygv7YwjzbSLt8fkEerq2 + '-2.jpg'
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ + '/program/' + id
			if type=='movie': TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,53,HRlygv7YwjzbSLt8fkEerq2)
			if type=='series': TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مسلسل '+title,ZylHkumQ8zD0+'?ep='+TQ9DFpiKUIzRAja+'='+title+'='+HRlygv7YwjzbSLt8fkEerq2,52,HRlygv7YwjzbSLt8fkEerq2)
	else:
		if type=='movie': UmQgD1n6NZh2IpLV7='movies'
		elif type=='series': UmQgD1n6NZh2IpLV7='series'
		url = Ega71ZGOcjfw + '/json/selected/' + sort + '-' + UmQgD1n6NZh2IpLV7 + '-WW.json'
		kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SHOOFMAX-TITLES-2nd')
		items = PAztbuyYo4Kvd.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		HUSvGqye1ZJTEl7Q=0
		for id,TQ9DFpiKUIzRAja,HRlygv7YwjzbSLt8fkEerq2,title in items:
			HUSvGqye1ZJTEl7Q += 1
			HRlygv7YwjzbSLt8fkEerq2 = Ega71ZGOcjfw + '/img/program/' + HRlygv7YwjzbSLt8fkEerq2 + '-2.jpg'
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ + '/program/' + id
			if type=='movie': TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,53,HRlygv7YwjzbSLt8fkEerq2)
			elif type=='series': TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مسلسل '+title,ZylHkumQ8zD0+'?ep='+TQ9DFpiKUIzRAja+'='+title+'='+HRlygv7YwjzbSLt8fkEerq2,52,HRlygv7YwjzbSLt8fkEerq2)
	title='صفحة '
	if HUSvGqye1ZJTEl7Q==16:
		for Ah7eyRqVoNbZrLCSYG3 in range(1,13) :
			if not Q0f7ytucSriRw8HTzd==str(Ah7eyRqVoNbZrLCSYG3):
				url = GiqvpBF9xLEdHDr37byJSngeCQ+'/genre/filter/'+type+'/'+str(Ah7eyRqVoNbZrLCSYG3)+'/'+sort+filter
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title+str(Ah7eyRqVoNbZrLCSYG3),url,51)
	return
def LLabVp7hzj28CE0f1udx(url):
	yoGhEciOC1 = url.split('=')
	TQ9DFpiKUIzRAja = int(yoGhEciOC1[1])
	name = pvOytL0nF7JY6flXTxAcHbQeNahu3(yoGhEciOC1[2])
	name = name.replace('_MOD_مسلسل ',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	HRlygv7YwjzbSLt8fkEerq2 = yoGhEciOC1[3]
	url = url.split('?')[0]
	if TQ9DFpiKUIzRAja==0:
		kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SHOOFMAX-EPISODES-1st')
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('<select(.*?)</select>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('option value="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		TQ9DFpiKUIzRAja = int(items[-1])
	for JfNHOP2BK1Yxl7Rq4 in range(TQ9DFpiKUIzRAja,0,-1):
		ZylHkumQ8zD0 = url + '?ep=' + str(JfNHOP2BK1Yxl7Rq4)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(JfNHOP2BK1Yxl7Rq4)
		TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,53,HRlygv7YwjzbSLt8fkEerq2)
	return
def lNBcUr8RCn(url):
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SHOOFMAX-PLAY-1st')
	Yzdce9ShbDtHQJf2 = PAztbuyYo4Kvd.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if Yzdce9ShbDtHQJf2:
		h0skHe7TcIY9x1UP5VBrZAE8dKGnl = Yzdce9ShbDtHQJf2[1].replace('T',cqsuhi1JE7nNIfbPYQSpFgeGr)
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+CXtugbqhV3+h0skHe7TcIY9x1UP5VBrZAE8dKGnl)
		return
	uFKx4DjCbRQPlNmOynUi35WpfT,B15eJyDjGE4LNk7FKUSsTC = [],[]
	DDUxmyAL0NBXGwlhjcOQfZ = PAztbuyYo4Kvd.findall('var origin_link = "(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)[0]
	TxLsXo0E3gIyRAB = PAztbuyYo4Kvd.findall('var backup_origin_link = "(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)[0]
	HRpMVv1x5ol9gbsnQquj = PAztbuyYo4Kvd.findall('hls: (.*?)_link\+"(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	for DQ7XgFltujVL,ZylHkumQ8zD0 in HRpMVv1x5ol9gbsnQquj:
		if 'backup' in DQ7XgFltujVL:
			DQ7XgFltujVL = 'backup server'
			url = TxLsXo0E3gIyRAB + ZylHkumQ8zD0
		else:
			DQ7XgFltujVL = 'main server'
			url = DDUxmyAL0NBXGwlhjcOQfZ + ZylHkumQ8zD0
		if '.m3u8' in url:
			uFKx4DjCbRQPlNmOynUi35WpfT.append(url)
			B15eJyDjGE4LNk7FKUSsTC.append('m3u8  '+DQ7XgFltujVL)
	HRpMVv1x5ol9gbsnQquj = PAztbuyYo4Kvd.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	HRpMVv1x5ol9gbsnQquj += PAztbuyYo4Kvd.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	for DQ7XgFltujVL,ZylHkumQ8zD0 in HRpMVv1x5ol9gbsnQquj:
		filename = ZylHkumQ8zD0.split('/')[-1]
		filename = filename.replace('fallback',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		filename = filename.replace('.mp4',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		filename = filename.replace('-',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		if 'backup' in DQ7XgFltujVL:
			DQ7XgFltujVL = 'backup server'
			url = TxLsXo0E3gIyRAB + ZylHkumQ8zD0
		else:
			DQ7XgFltujVL = 'main server'
			url = DDUxmyAL0NBXGwlhjcOQfZ + ZylHkumQ8zD0
		uFKx4DjCbRQPlNmOynUi35WpfT.append(url)
		B15eJyDjGE4LNk7FKUSsTC.append('mp4  '+DQ7XgFltujVL+BSiDxUPsdHkz27VMop51uf6c3+filename)
	iP7AUR41exzlKyZIf9Mt3u = ccAMwn7hflDev8Kd3aqP('Select Video Quality:', B15eJyDjGE4LNk7FKUSsTC)
	if iP7AUR41exzlKyZIf9Mt3u == -1 : return
	url = uFKx4DjCbRQPlNmOynUi35WpfT[iP7AUR41exzlKyZIf9Mt3u]
	ocUnzjShqIO35vZi8bk64pVKMCTBaw(url,wgj0rX5tbcxPulhmny,'video')
	return
def rYAf8NzmSqsLXgpKMVUCIHtjZ1JucD(url,type):
	if 'series' in url: KteRnFMjHpBPqNf8 = GiqvpBF9xLEdHDr37byJSngeCQ + '/genre/مسلسل'
	else: KteRnFMjHpBPqNf8 = GiqvpBF9xLEdHDr37byJSngeCQ + '/genre/فيلم'
	KteRnFMjHpBPqNf8 = kGE6zoKSan54W(KteRnFMjHpBPqNf8)
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SHOOFMAX-FILTERS-1st')
	if type==1: zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('subgenre(.*?)div',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	elif type==2: zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('country(.*?)div',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('option value="(.*?)">(.*?)</option',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	if type==1:
		for cOfmxNL5C8aEWT9PoY,title in items:
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url+'?subgenre='+cOfmxNL5C8aEWT9PoY,58)
	elif type==2:
		url,cOfmxNL5C8aEWT9PoY = url.split('?')
		for iPWN5tr1aBS0YZnmlgOM,title in items:
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url+'?country='+iPWN5tr1aBS0YZnmlgOM+'&'+cOfmxNL5C8aEWT9PoY,51)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if not search: search = FaUBpzTGxtS7hZyl()
	if not search: return
	SEGtTsCyUVi0lo4LJkH5 = search.replace(hSXlxL9iB05c,'%20')
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/search?q='+SEGtTsCyUVi0lo4LJkH5
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,True,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SHOOFMAX-SEARCH-2nd')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('general-body(.*?)search-bottom-padding',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	if items:
		for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
			url = GiqvpBF9xLEdHDr37byJSngeCQ + ZylHkumQ8zD0
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+kGE6zoKSan54W(title)+'='+HRlygv7YwjzbSLt8fkEerq2
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,52,HRlygv7YwjzbSLt8fkEerq2)
				else:
					title = '_MOD_فيلم '+title
					TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,53,HRlygv7YwjzbSLt8fkEerq2)
	return
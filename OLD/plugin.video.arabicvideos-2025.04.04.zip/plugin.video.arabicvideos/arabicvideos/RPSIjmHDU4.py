# -*- coding: utf-8 -*-
from pR2X91txEm import *
kNfc1ZX0HTKjpQImqiuy49g85G7UVa = 'EXCLUDES'
def Ck7X6YhDqrM1Ec(w8cPT5nhW2RUAFKDa,yalezLRFxwCk):
	yalezLRFxwCk = yalezLRFxwCk.replace(bbTCMJwEx8nhN4X,nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(' '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2)[UnOIK1WBbw2:]
	BgvLMnSiP5uZ = PAztbuyYo4Kvd.findall('[a-zA-Z]',w8cPT5nhW2RUAFKDa,PAztbuyYo4Kvd.DOTALL)
	if 'بحث IPTV - ' in w8cPT5nhW2RUAFKDa: w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace('بحث IPTV - ',Vfn18PSH5g2v7muhXGso9CAE6WU+'بحث IPTV - '+Vfn18PSH5g2v7muhXGso9CAE6WU)
	elif ' IPTV' in w8cPT5nhW2RUAFKDa and yalezLRFxwCk=='IPT': w8cPT5nhW2RUAFKDa = Vfn18PSH5g2v7muhXGso9CAE6WU+w8cPT5nhW2RUAFKDa
	elif 'بحث M3U - ' in w8cPT5nhW2RUAFKDa: w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace('بحث M3U - ',Vfn18PSH5g2v7muhXGso9CAE6WU+'بحث M3U - '+Vfn18PSH5g2v7muhXGso9CAE6WU)
	elif ' M3U' in w8cPT5nhW2RUAFKDa and yalezLRFxwCk=='M3U': w8cPT5nhW2RUAFKDa = Vfn18PSH5g2v7muhXGso9CAE6WU+w8cPT5nhW2RUAFKDa
	elif 'بحث ' in w8cPT5nhW2RUAFKDa and ' - ' in w8cPT5nhW2RUAFKDa: w8cPT5nhW2RUAFKDa = Vfn18PSH5g2v7muhXGso9CAE6WU+w8cPT5nhW2RUAFKDa
	elif not BgvLMnSiP5uZ:
		AH0up6QxJE17yn3Ljheo = PAztbuyYo4Kvd.findall('^( *?)(.*?)( *?)$',w8cPT5nhW2RUAFKDa)
		HzLZnEQ2cFDX4Jpg,ANOBRv48wX7nkCcgFfG,BqDlrTMoXsFbna1zSI2WYjk8 = AH0up6QxJE17yn3Ljheo[IpFcwrWNgefMym3qta0hYQAzOdE]
		DN0mJWO2Vu8eIAkLpYBfSjqtz3Rwv = PAztbuyYo4Kvd.findall('^([!-~])',ANOBRv48wX7nkCcgFfG)
		if DN0mJWO2Vu8eIAkLpYBfSjqtz3Rwv: w8cPT5nhW2RUAFKDa = HzLZnEQ2cFDX4Jpg+YgKcwxaR3Fm+ANOBRv48wX7nkCcgFfG+BqDlrTMoXsFbna1zSI2WYjk8
		else: w8cPT5nhW2RUAFKDa = BqDlrTMoXsFbna1zSI2WYjk8+Vfn18PSH5g2v7muhXGso9CAE6WU+ANOBRv48wX7nkCcgFfG+HzLZnEQ2cFDX4Jpg
	else:
		import bidi.algorithm as rrEG9U6dalA
		if UnOIK1WBbw2:
			pLeDnPIoRGUq8Ax6aH1zcMb7 = w8cPT5nhW2RUAFKDa
			if cS2NYw4xulqJgvzkMF: pLeDnPIoRGUq8Ax6aH1zcMb7 = pLeDnPIoRGUq8Ax6aH1zcMb7.decode(YWEQ3Cf8RevpD0m7NjF1,'ignore')
			Pn4b5EYvA9mD1CKchSHNr0kO = rrEG9U6dalA.get_display(pLeDnPIoRGUq8Ax6aH1zcMb7,base_dir='L')
			Omsjle40u9XnZp8VwfKbQYUMz1 = pLeDnPIoRGUq8Ax6aH1zcMb7.split(hSXlxL9iB05c)
			XagzmTrbuMx8Q2i = Pn4b5EYvA9mD1CKchSHNr0kO.split(hSXlxL9iB05c)
			qVJkxIuFBzlQd2Eteh95p36vHg,aaxQCg5BMk4,Imuiy3eHRLJSozsVbZrp,CRZEHaFTzywq4s = [],[],nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
			Grq6BdfY4SEHpbxFDUCJs3hn = zip(Omsjle40u9XnZp8VwfKbQYUMz1,XagzmTrbuMx8Q2i)
			for bbFkg8arGEpDQNvAK2qBiTWzYmhOs3,NzMEQHuqYf in Grq6BdfY4SEHpbxFDUCJs3hn:
				if bbFkg8arGEpDQNvAK2qBiTWzYmhOs3==NzMEQHuqYf==nA5dhMRg6ENzsB0l1GwvH7aIr2 and CRZEHaFTzywq4s:
					Imuiy3eHRLJSozsVbZrp += hSXlxL9iB05c
					continue
				if bbFkg8arGEpDQNvAK2qBiTWzYmhOs3==NzMEQHuqYf:
					VzS02wPZBC615eOUgdha = 'EN'
					if CRZEHaFTzywq4s==VzS02wPZBC615eOUgdha: Imuiy3eHRLJSozsVbZrp += hSXlxL9iB05c+bbFkg8arGEpDQNvAK2qBiTWzYmhOs3
					elif bbFkg8arGEpDQNvAK2qBiTWzYmhOs3:
						if Imuiy3eHRLJSozsVbZrp:
							aaxQCg5BMk4.append(Imuiy3eHRLJSozsVbZrp)
							qVJkxIuFBzlQd2Eteh95p36vHg.append(nA5dhMRg6ENzsB0l1GwvH7aIr2)
						Imuiy3eHRLJSozsVbZrp = bbFkg8arGEpDQNvAK2qBiTWzYmhOs3
				else:
					VzS02wPZBC615eOUgdha = 'AR'
					if CRZEHaFTzywq4s==VzS02wPZBC615eOUgdha: Imuiy3eHRLJSozsVbZrp += hSXlxL9iB05c+bbFkg8arGEpDQNvAK2qBiTWzYmhOs3
					elif bbFkg8arGEpDQNvAK2qBiTWzYmhOs3:
						if Imuiy3eHRLJSozsVbZrp:
							qVJkxIuFBzlQd2Eteh95p36vHg.append(Imuiy3eHRLJSozsVbZrp)
							aaxQCg5BMk4.append(nA5dhMRg6ENzsB0l1GwvH7aIr2)
						Imuiy3eHRLJSozsVbZrp = bbFkg8arGEpDQNvAK2qBiTWzYmhOs3
				CRZEHaFTzywq4s = VzS02wPZBC615eOUgdha
			if VzS02wPZBC615eOUgdha=='EN':
				qVJkxIuFBzlQd2Eteh95p36vHg.append(Imuiy3eHRLJSozsVbZrp)
				aaxQCg5BMk4.append(nA5dhMRg6ENzsB0l1GwvH7aIr2)
			else:
				aaxQCg5BMk4.append(Imuiy3eHRLJSozsVbZrp)
				qVJkxIuFBzlQd2Eteh95p36vHg.append(nA5dhMRg6ENzsB0l1GwvH7aIr2)
			lzt802cDHVIXQYNOsg5B = nA5dhMRg6ENzsB0l1GwvH7aIr2
			Grq6BdfY4SEHpbxFDUCJs3hn = zip(qVJkxIuFBzlQd2Eteh95p36vHg,aaxQCg5BMk4)
			import bidi.mirror as Ya2sPoTkNzb5RxBVp3lm
			for qbMR7l4n9DIXCkJ1oGFU,zd8Bu4OwfWDv3raJG9o7q5b in Grq6BdfY4SEHpbxFDUCJs3hn:
				if qbMR7l4n9DIXCkJ1oGFU: lzt802cDHVIXQYNOsg5B += hSXlxL9iB05c+qbMR7l4n9DIXCkJ1oGFU
				else:
					DN0mJWO2Vu8eIAkLpYBfSjqtz3Rwv = PAztbuyYo4Kvd.findall('([!-~]) *$',zd8Bu4OwfWDv3raJG9o7q5b)
					if DN0mJWO2Vu8eIAkLpYBfSjqtz3Rwv:
						DN0mJWO2Vu8eIAkLpYBfSjqtz3Rwv = DN0mJWO2Vu8eIAkLpYBfSjqtz3Rwv[IpFcwrWNgefMym3qta0hYQAzOdE]
						try:
							jDi7tTdFOlyIUWPLBZab63SCMm = Ya2sPoTkNzb5RxBVp3lm.MIRRORED[DN0mJWO2Vu8eIAkLpYBfSjqtz3Rwv]
							AH0up6QxJE17yn3Ljheo = PAztbuyYo4Kvd.findall('^( *?)(.*?)( *?)$',zd8Bu4OwfWDv3raJG9o7q5b)
							if AH0up6QxJE17yn3Ljheo: HzLZnEQ2cFDX4Jpg,zd8Bu4OwfWDv3raJG9o7q5b,BqDlrTMoXsFbna1zSI2WYjk8 = AH0up6QxJE17yn3Ljheo[IpFcwrWNgefMym3qta0hYQAzOdE]
							zd8Bu4OwfWDv3raJG9o7q5b = HzLZnEQ2cFDX4Jpg+jDi7tTdFOlyIUWPLBZab63SCMm+zd8Bu4OwfWDv3raJG9o7q5b[:-UnOIK1WBbw2]+BqDlrTMoXsFbna1zSI2WYjk8
						except: pass
					lzt802cDHVIXQYNOsg5B += hSXlxL9iB05c+zd8Bu4OwfWDv3raJG9o7q5b
			w8cPT5nhW2RUAFKDa = lzt802cDHVIXQYNOsg5B[UnOIK1WBbw2:]
			if cS2NYw4xulqJgvzkMF: w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.encode(YWEQ3Cf8RevpD0m7NjF1)
		else:
			if cS2NYw4xulqJgvzkMF: w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.decode(YWEQ3Cf8RevpD0m7NjF1)
			w8cPT5nhW2RUAFKDa = rrEG9U6dalA.get_display(w8cPT5nhW2RUAFKDa)
			pLeDnPIoRGUq8Ax6aH1zcMb7,Pn4b5EYvA9mD1CKchSHNr0kO = w8cPT5nhW2RUAFKDa,w8cPT5nhW2RUAFKDa
			if 1:
				CRZEHaFTzywq4s,jUl4mTkRY0OWyCzuGLHvw = nA5dhMRg6ENzsB0l1GwvH7aIr2,[]
				iwt1IY37gFUhHbqdV0Na4y = w8cPT5nhW2RUAFKDa.split(hSXlxL9iB05c)
				for IvBSf4QwCTg in iwt1IY37gFUhHbqdV0Na4y:
					if not IvBSf4QwCTg:
						if jUl4mTkRY0OWyCzuGLHvw: jUl4mTkRY0OWyCzuGLHvw[-UnOIK1WBbw2] += hSXlxL9iB05c
						else: jUl4mTkRY0OWyCzuGLHvw.append(nA5dhMRg6ENzsB0l1GwvH7aIr2)
						continue
					DdLkPfH0ABCSFW = PAztbuyYo4Kvd.findall('[!-~]',IvBSf4QwCTg[IpFcwrWNgefMym3qta0hYQAzOdE])
					if DdLkPfH0ABCSFW==CRZEHaFTzywq4s and jUl4mTkRY0OWyCzuGLHvw: jUl4mTkRY0OWyCzuGLHvw[-UnOIK1WBbw2] += hSXlxL9iB05c+IvBSf4QwCTg
					else:
						if jUl4mTkRY0OWyCzuGLHvw:
							ejbvJat5S6U0TFodr = PAztbuyYo4Kvd.findall('[^!-~]',jUl4mTkRY0OWyCzuGLHvw[-UnOIK1WBbw2])
							if ejbvJat5S6U0TFodr:
								jUl4mTkRY0OWyCzuGLHvw[-UnOIK1WBbw2] = rrEG9U6dalA.get_display(jUl4mTkRY0OWyCzuGLHvw[-UnOIK1WBbw2])
								aeRji2pF8wf6QbcXYxA7EH5g = PAztbuyYo4Kvd.findall('^ +',jUl4mTkRY0OWyCzuGLHvw[-UnOIK1WBbw2])
								if aeRji2pF8wf6QbcXYxA7EH5g: jUl4mTkRY0OWyCzuGLHvw[-UnOIK1WBbw2] = jUl4mTkRY0OWyCzuGLHvw[-UnOIK1WBbw2].lstrip(hSXlxL9iB05c)+aeRji2pF8wf6QbcXYxA7EH5g[IpFcwrWNgefMym3qta0hYQAzOdE]
						jUl4mTkRY0OWyCzuGLHvw.append(IvBSf4QwCTg)
					CRZEHaFTzywq4s = DdLkPfH0ABCSFW
				if jUl4mTkRY0OWyCzuGLHvw: jUl4mTkRY0OWyCzuGLHvw[-UnOIK1WBbw2] = rrEG9U6dalA.get_display(jUl4mTkRY0OWyCzuGLHvw[-UnOIK1WBbw2])
				w8cPT5nhW2RUAFKDa = hSXlxL9iB05c.join(jUl4mTkRY0OWyCzuGLHvw)
			if cS2NYw4xulqJgvzkMF: w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.encode(YWEQ3Cf8RevpD0m7NjF1)
	return w8cPT5nhW2RUAFKDa
def xu6ls91K5a2ZJtnQ(f7K0kyHcnp,jTHGNtlpXwR9E45e,l0KyZsDT1hm3z7xFkNXB4d8c):
	WTavfhd7QJDABwpIVrZqHL,w8cPT5nhW2RUAFKDa,kOTdpYrPqu5A7UIcW0Ch,knBV0UPuCNdpIsAFH3coRKjh2lb,czMOJaKwoCnSPuNTd9bIH8pfLy72W5,LLrB8ubpWDQI6s,jjPW6f0cAT2KHx7iNs,qjyki7XR1FW,Gv80f9tpWiRL = f7K0kyHcnp
	knBV0UPuCNdpIsAFH3coRKjh2lb = int(knBV0UPuCNdpIsAFH3coRKjh2lb)
	HkSGPfvR2dUcE7ayKTWVjq = PAztbuyYo4Kvd.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',w8cPT5nhW2RUAFKDa,PAztbuyYo4Kvd.DOTALL)
	if HkSGPfvR2dUcE7ayKTWVjq:
		HkSGPfvR2dUcE7ayKTWVjq,PHjW8JoseVEMGUpAcRDB2CTmZx,S01wg8oJB6G3CH = HkSGPfvR2dUcE7ayKTWVjq[IpFcwrWNgefMym3qta0hYQAzOdE]
		w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(HkSGPfvR2dUcE7ayKTWVjq,nA5dhMRg6ENzsB0l1GwvH7aIr2)
	wWEx4POmh7dQzqoujcVyMZYeC9BLfr = w8cPT5nhW2RUAFKDa
	yalezLRFxwCk = PAztbuyYo4Kvd.findall('^_(\w\w\w)_(.*?)$',w8cPT5nhW2RUAFKDa,PAztbuyYo4Kvd.DOTALL)
	if yalezLRFxwCk:
		yalezLRFxwCk,w8cPT5nhW2RUAFKDa = yalezLRFxwCk[IpFcwrWNgefMym3qta0hYQAzOdE]
		K0CZB3dkOzsGW = '_MOD_' in w8cPT5nhW2RUAFKDa
		dkq07Y6WG5enK1QlOLEU8uAj49x = WTavfhd7QJDABwpIVrZqHL=='folder'
		if K0CZB3dkOzsGW and dkq07Y6WG5enK1QlOLEU8uAj49x: zfD3NvSkIWi5QVasAY4gqc7Orpw8u = ';'
		elif K0CZB3dkOzsGW and not dkq07Y6WG5enK1QlOLEU8uAj49x: zfD3NvSkIWi5QVasAY4gqc7Orpw8u = pRYO3SUfqaTdlW4jhrV6xI
		elif not K0CZB3dkOzsGW and dkq07Y6WG5enK1QlOLEU8uAj49x: zfD3NvSkIWi5QVasAY4gqc7Orpw8u = ','
		elif not K0CZB3dkOzsGW and not dkq07Y6WG5enK1QlOLEU8uAj49x: zfD3NvSkIWi5QVasAY4gqc7Orpw8u = hSXlxL9iB05c
		w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace('_MOD_',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		yalezLRFxwCk = zfD3NvSkIWi5QVasAY4gqc7Orpw8u+bbTCMJwEx8nhN4X+yalezLRFxwCk+' '+NwROdSj3nsA
	else: yalezLRFxwCk = nA5dhMRg6ENzsB0l1GwvH7aIr2
	if HkSGPfvR2dUcE7ayKTWVjq:
		if cS2NYw4xulqJgvzkMF:
			HkSGPfvR2dUcE7ayKTWVjq = lSWzOYmN08+PHjW8JoseVEMGUpAcRDB2CTmZx+hSXlxL9iB05c+S01wg8oJB6G3CH+NwROdSj3nsA
			if yalezLRFxwCk: w8cPT5nhW2RUAFKDa = HkSGPfvR2dUcE7ayKTWVjq+hSXlxL9iB05c+Vfn18PSH5g2v7muhXGso9CAE6WU+yalezLRFxwCk+w8cPT5nhW2RUAFKDa
			else: w8cPT5nhW2RUAFKDa = HkSGPfvR2dUcE7ayKTWVjq+Vfn18PSH5g2v7muhXGso9CAE6WU+w8cPT5nhW2RUAFKDa+hSXlxL9iB05c
		elif BsLJ7p5Av2Vm0SQeCO1o:
			if yalezLRFxwCk:
				HkSGPfvR2dUcE7ayKTWVjq = lSWzOYmN08+PHjW8JoseVEMGUpAcRDB2CTmZx+hSXlxL9iB05c+S01wg8oJB6G3CH+NwROdSj3nsA
				w8cPT5nhW2RUAFKDa = HkSGPfvR2dUcE7ayKTWVjq+hSXlxL9iB05c+yalezLRFxwCk+w8cPT5nhW2RUAFKDa
			else:
				HkSGPfvR2dUcE7ayKTWVjq = lSWzOYmN08+S01wg8oJB6G3CH+hSXlxL9iB05c+PHjW8JoseVEMGUpAcRDB2CTmZx+NwROdSj3nsA
				w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa+hSXlxL9iB05c+Vfn18PSH5g2v7muhXGso9CAE6WU+HkSGPfvR2dUcE7ayKTWVjq
	elif yalezLRFxwCk:
		w8cPT5nhW2RUAFKDa = Ck7X6YhDqrM1Ec(w8cPT5nhW2RUAFKDa,yalezLRFxwCk)
		w8cPT5nhW2RUAFKDa = yalezLRFxwCk+w8cPT5nhW2RUAFKDa
	f7K0kyHcnp = WTavfhd7QJDABwpIVrZqHL,wWEx4POmh7dQzqoujcVyMZYeC9BLfr,kOTdpYrPqu5A7UIcW0Ch,str(knBV0UPuCNdpIsAFH3coRKjh2lb),czMOJaKwoCnSPuNTd9bIH8pfLy72W5,LLrB8ubpWDQI6s,jjPW6f0cAT2KHx7iNs,qjyki7XR1FW,Gv80f9tpWiRL
	AcuKhJBRkZEeMPd = {'type':nA5dhMRg6ENzsB0l1GwvH7aIr2,'mode':nA5dhMRg6ENzsB0l1GwvH7aIr2,'url':nA5dhMRg6ENzsB0l1GwvH7aIr2,'text':nA5dhMRg6ENzsB0l1GwvH7aIr2,'page':nA5dhMRg6ENzsB0l1GwvH7aIr2,'name':nA5dhMRg6ENzsB0l1GwvH7aIr2,'image':nA5dhMRg6ENzsB0l1GwvH7aIr2,'context':nA5dhMRg6ENzsB0l1GwvH7aIr2,'infodict':nA5dhMRg6ENzsB0l1GwvH7aIr2}
	if BsLJ7p5Av2Vm0SQeCO1o: wWEx4POmh7dQzqoujcVyMZYeC9BLfr = wWEx4POmh7dQzqoujcVyMZYeC9BLfr.encode(YWEQ3Cf8RevpD0m7NjF1,'ignore').decode(YWEQ3Cf8RevpD0m7NjF1)
	AcuKhJBRkZEeMPd['name'] = kGE6zoKSan54W(wWEx4POmh7dQzqoujcVyMZYeC9BLfr)
	AcuKhJBRkZEeMPd['type'] = WTavfhd7QJDABwpIVrZqHL.strip(hSXlxL9iB05c)
	AcuKhJBRkZEeMPd['mode'] = str(knBV0UPuCNdpIsAFH3coRKjh2lb).strip(hSXlxL9iB05c)
	if WTavfhd7QJDABwpIVrZqHL=='folder' and LLrB8ubpWDQI6s: AcuKhJBRkZEeMPd['page'] = kGE6zoKSan54W(LLrB8ubpWDQI6s.strip(hSXlxL9iB05c))
	if qjyki7XR1FW: AcuKhJBRkZEeMPd['context'] = qjyki7XR1FW.strip(hSXlxL9iB05c)
	if jjPW6f0cAT2KHx7iNs: AcuKhJBRkZEeMPd['text'] = kGE6zoKSan54W(jjPW6f0cAT2KHx7iNs.strip(hSXlxL9iB05c))
	if czMOJaKwoCnSPuNTd9bIH8pfLy72W5: AcuKhJBRkZEeMPd['image'] = kGE6zoKSan54W(czMOJaKwoCnSPuNTd9bIH8pfLy72W5.strip(hSXlxL9iB05c))
	if Gv80f9tpWiRL:
		Gv80f9tpWiRL = str(Gv80f9tpWiRL)
		AcuKhJBRkZEeMPd['infodict'] = kGE6zoKSan54W(Gv80f9tpWiRL.strip(hSXlxL9iB05c))
		Gv80f9tpWiRL = eval(Gv80f9tpWiRL)
	else: Gv80f9tpWiRL = {}
	if kOTdpYrPqu5A7UIcW0Ch: AcuKhJBRkZEeMPd['url'] = kGE6zoKSan54W(kOTdpYrPqu5A7UIcW0Ch.strip(hSXlxL9iB05c))
	MeRoiIW63bYlkD = {'name':nA5dhMRg6ENzsB0l1GwvH7aIr2,'context_menu':nA5dhMRg6ENzsB0l1GwvH7aIr2,'plot':nA5dhMRg6ENzsB0l1GwvH7aIr2,'stars':nA5dhMRg6ENzsB0l1GwvH7aIr2,'image':nA5dhMRg6ENzsB0l1GwvH7aIr2,'type':nA5dhMRg6ENzsB0l1GwvH7aIr2,'isFolder':nA5dhMRg6ENzsB0l1GwvH7aIr2,'newpath':nA5dhMRg6ENzsB0l1GwvH7aIr2,'duration':nA5dhMRg6ENzsB0l1GwvH7aIr2}
	rRK0DHsXhiBZ6dTCFYgGk84pLm = []
	qqnx9KdHMPtJ0bLTyrh = 'plugin://'+jmPwATvkoixS92pOuas+'/?type='+AcuKhJBRkZEeMPd['type']+'&mode='+AcuKhJBRkZEeMPd['mode']
	if AcuKhJBRkZEeMPd['page']: qqnx9KdHMPtJ0bLTyrh += '&page='+AcuKhJBRkZEeMPd['page']
	if AcuKhJBRkZEeMPd['name']: qqnx9KdHMPtJ0bLTyrh += '&name='+AcuKhJBRkZEeMPd['name']
	if AcuKhJBRkZEeMPd['text']: qqnx9KdHMPtJ0bLTyrh += '&text='+AcuKhJBRkZEeMPd['text']
	if AcuKhJBRkZEeMPd['infodict']: qqnx9KdHMPtJ0bLTyrh += '&infodict='+AcuKhJBRkZEeMPd['infodict']
	if AcuKhJBRkZEeMPd['image']: qqnx9KdHMPtJ0bLTyrh += '&image='+AcuKhJBRkZEeMPd['image']
	if AcuKhJBRkZEeMPd['url']: qqnx9KdHMPtJ0bLTyrh += '&url='+AcuKhJBRkZEeMPd['url']
	if knBV0UPuCNdpIsAFH3coRKjh2lb not in [265,533]: MeRoiIW63bYlkD['favorites'] = S5MWhgtZ37Xw
	else: MeRoiIW63bYlkD['favorites'] = FFKncZx5pDTwdiJRYhMgQSNL
	if AcuKhJBRkZEeMPd['context']: qqnx9KdHMPtJ0bLTyrh += '&context='+AcuKhJBRkZEeMPd['context']
	if knBV0UPuCNdpIsAFH3coRKjh2lb in [235,238] and WTavfhd7QJDABwpIVrZqHL=='live' and 'EPG' in qjyki7XR1FW:
		X0RdVnhUMe497QouqNEDi = 'plugin://'+jmPwATvkoixS92pOuas+'?mode=238&text=SHORT_EPG&url='+kOTdpYrPqu5A7UIcW0Ch
		HhCQi7FGoqxM4 = lSWzOYmN08+'البرامج القادمة'+NwROdSj3nsA
		WUS0s3IoveFrmiB = (HhCQi7FGoqxM4,'RunPlugin('+X0RdVnhUMe497QouqNEDi+')')
		rRK0DHsXhiBZ6dTCFYgGk84pLm.append(WUS0s3IoveFrmiB)
	if knBV0UPuCNdpIsAFH3coRKjh2lb==265:
		DZ0htFdQal58pI49oWy = jTHGNtlpXwR9E45e(jjPW6f0cAT2KHx7iNs,S5MWhgtZ37Xw)
		if DZ0htFdQal58pI49oWy>IpFcwrWNgefMym3qta0hYQAzOdE:
			X0RdVnhUMe497QouqNEDi = 'plugin://'+jmPwATvkoixS92pOuas+'?mode=266&text='+jjPW6f0cAT2KHx7iNs
			HhCQi7FGoqxM4 = lSWzOYmN08+'مسح قائمة آخر 50 '+AEyNnLOu7g6BGrw5tlcj(jjPW6f0cAT2KHx7iNs)+NwROdSj3nsA
			WUS0s3IoveFrmiB = (HhCQi7FGoqxM4,'RunPlugin('+X0RdVnhUMe497QouqNEDi+')')
			rRK0DHsXhiBZ6dTCFYgGk84pLm.append(WUS0s3IoveFrmiB)
	if WTavfhd7QJDABwpIVrZqHL=='video' and knBV0UPuCNdpIsAFH3coRKjh2lb!=331:
		X0RdVnhUMe497QouqNEDi = qqnx9KdHMPtJ0bLTyrh+'&context=6_DOWNLOAD'
		HhCQi7FGoqxM4 = lSWzOYmN08+'تحميل ملف الفيديو'+NwROdSj3nsA
		WUS0s3IoveFrmiB = (HhCQi7FGoqxM4,'RunPlugin('+X0RdVnhUMe497QouqNEDi+')')
		rRK0DHsXhiBZ6dTCFYgGk84pLm.append(WUS0s3IoveFrmiB)
	if knBV0UPuCNdpIsAFH3coRKjh2lb==331:
		X0RdVnhUMe497QouqNEDi = qqnx9KdHMPtJ0bLTyrh+'&context=6_DELETE'
		HhCQi7FGoqxM4 = lSWzOYmN08+'حذف ملف الفيديو'+NwROdSj3nsA
		WUS0s3IoveFrmiB = (HhCQi7FGoqxM4,'RunPlugin('+X0RdVnhUMe497QouqNEDi+')')
		rRK0DHsXhiBZ6dTCFYgGk84pLm.append(WUS0s3IoveFrmiB)
	if WTavfhd7QJDABwpIVrZqHL=='folder' and knBV0UPuCNdpIsAFH3coRKjh2lb==540:
		rSs7hg4MFOXo = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,'list','GLOBALSEARCH_SPLITTED_ALL')
		if rSs7hg4MFOXo:
			X0RdVnhUMe497QouqNEDi = 'plugin://'+jmPwATvkoixS92pOuas+'?context=7'
			HhCQi7FGoqxM4 = lSWzOYmN08+'مسح كلمات بحث المواقع'+NwROdSj3nsA
			WUS0s3IoveFrmiB = (HhCQi7FGoqxM4,'RunPlugin('+X0RdVnhUMe497QouqNEDi+')')
			rRK0DHsXhiBZ6dTCFYgGk84pLm.append(WUS0s3IoveFrmiB)
	if WTavfhd7QJDABwpIVrZqHL=='folder' and knBV0UPuCNdpIsAFH3coRKjh2lb==1010:
		rSs7hg4MFOXo = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,'list','GLOBALSEARCH_SPLITTED_GOOGLE')
		if rSs7hg4MFOXo:
			X0RdVnhUMe497QouqNEDi = 'plugin://'+jmPwATvkoixS92pOuas+'?context=10'
			HhCQi7FGoqxM4 = lSWzOYmN08+'مسح كلمات بحث جوجل'+NwROdSj3nsA
			WUS0s3IoveFrmiB = (HhCQi7FGoqxM4,'RunPlugin('+X0RdVnhUMe497QouqNEDi+')')
			rRK0DHsXhiBZ6dTCFYgGk84pLm.append(WUS0s3IoveFrmiB)
	LLZKCU0A5qTPyBVcsDQ = [9990,9999,udq5tP0hwifHQCGYELDbOUI,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,536,540,710,719,761,762,1010,1022]
	if knBV0UPuCNdpIsAFH3coRKjh2lb not in LLZKCU0A5qTPyBVcsDQ:
		X0RdVnhUMe497QouqNEDi = 'plugin://'+jmPwATvkoixS92pOuas+'?context=8&mode=260'
		HhCQi7FGoqxM4 = lSWzOYmN08+'القائمة الرئيسية'+NwROdSj3nsA
		WUS0s3IoveFrmiB = (HhCQi7FGoqxM4,'RunPlugin('+X0RdVnhUMe497QouqNEDi+')')
		rRK0DHsXhiBZ6dTCFYgGk84pLm.append(WUS0s3IoveFrmiB)
	TEcSfCYPnew9JiOl60KdGuN3o = knBV0UPuCNdpIsAFH3coRKjh2lb-knBV0UPuCNdpIsAFH3coRKjh2lb%10
	if knBV0UPuCNdpIsAFH3coRKjh2lb%10:
		if TEcSfCYPnew9JiOl60KdGuN3o==280: TEcSfCYPnew9JiOl60KdGuN3o = 230
		if TEcSfCYPnew9JiOl60KdGuN3o==410: TEcSfCYPnew9JiOl60KdGuN3o = 400
		if TEcSfCYPnew9JiOl60KdGuN3o==520: TEcSfCYPnew9JiOl60KdGuN3o = 510
		if TEcSfCYPnew9JiOl60KdGuN3o not in yv4ToSVPrxwtLc8nD3I52kmebEfNs:
			X0RdVnhUMe497QouqNEDi = 'plugin://'+jmPwATvkoixS92pOuas+'?context=8&mode='+str(TEcSfCYPnew9JiOl60KdGuN3o)
			HhCQi7FGoqxM4 = lSWzOYmN08+'قائمة الموقع'+NwROdSj3nsA
			WUS0s3IoveFrmiB = (HhCQi7FGoqxM4,'RunPlugin('+X0RdVnhUMe497QouqNEDi+')')
			rRK0DHsXhiBZ6dTCFYgGk84pLm.append(WUS0s3IoveFrmiB)
	X0RdVnhUMe497QouqNEDi = qqnx9KdHMPtJ0bLTyrh+'&context=9'
	HhCQi7FGoqxM4 = lSWzOYmN08+'تحديث القائمة'+NwROdSj3nsA
	WUS0s3IoveFrmiB = (HhCQi7FGoqxM4,'RunPlugin('+X0RdVnhUMe497QouqNEDi+')')
	rRK0DHsXhiBZ6dTCFYgGk84pLm.append(WUS0s3IoveFrmiB)
	if WTavfhd7QJDABwpIVrZqHL in ['video','live']:
		X0RdVnhUMe497QouqNEDi = qqnx9KdHMPtJ0bLTyrh+'&context=18'
		HhCQi7FGoqxM4 = lSWzOYmN08+'إظهار قوائم الجودة'+NwROdSj3nsA
		WUS0s3IoveFrmiB = (HhCQi7FGoqxM4,'RunPlugin('+X0RdVnhUMe497QouqNEDi+')')
		rRK0DHsXhiBZ6dTCFYgGk84pLm.append(WUS0s3IoveFrmiB)
	if WTavfhd7QJDABwpIVrZqHL in ['link','video','live']: uuHw5pjCGc1WhMO6rqbK4U = FFKncZx5pDTwdiJRYhMgQSNL
	elif WTavfhd7QJDABwpIVrZqHL=='folder': uuHw5pjCGc1WhMO6rqbK4U = S5MWhgtZ37Xw
	MeRoiIW63bYlkD['name'] = w8cPT5nhW2RUAFKDa
	MeRoiIW63bYlkD['context_menu'] = rRK0DHsXhiBZ6dTCFYgGk84pLm
	if 'plot' in list(Gv80f9tpWiRL.keys()): MeRoiIW63bYlkD['plot'] = Gv80f9tpWiRL['plot']
	if 'stars' in list(Gv80f9tpWiRL.keys()): MeRoiIW63bYlkD['stars'] = Gv80f9tpWiRL['stars']
	if czMOJaKwoCnSPuNTd9bIH8pfLy72W5: MeRoiIW63bYlkD['image'] = czMOJaKwoCnSPuNTd9bIH8pfLy72W5
	if WTavfhd7QJDABwpIVrZqHL=='video' and LLrB8ubpWDQI6s:
		gWC2upn5lKPMtRD37cG8wqd = PAztbuyYo4Kvd.findall('[\d:]+',LLrB8ubpWDQI6s,PAztbuyYo4Kvd.DOTALL)
		if gWC2upn5lKPMtRD37cG8wqd:
			gWC2upn5lKPMtRD37cG8wqd = '0:0:0:0:0:'+gWC2upn5lKPMtRD37cG8wqd[IpFcwrWNgefMym3qta0hYQAzOdE]
			NbaWkXeUGq26YhRISVouD,WWzeBuAgZaiLSTUpHV716vx,DEjk9cPZ2CmwIR341hJounbeKTdS7N,vZAU9zcYMRDCP78,htAVRFw5keUaB = gWC2upn5lKPMtRD37cG8wqd.rsplit(':',tpMX1Bgs0bzv8OEafyW)
			rjvpM4xml5nahHJGK31BLc = int(WWzeBuAgZaiLSTUpHV716vx)*24*QhOXE7ztloReYp0nMVAIZb+int(DEjk9cPZ2CmwIR341hJounbeKTdS7N)*QhOXE7ztloReYp0nMVAIZb+int(vZAU9zcYMRDCP78)*60+int(htAVRFw5keUaB)
			MeRoiIW63bYlkD['duration'] = rjvpM4xml5nahHJGK31BLc
	MeRoiIW63bYlkD['type'] = WTavfhd7QJDABwpIVrZqHL
	MeRoiIW63bYlkD['isFolder'] = uuHw5pjCGc1WhMO6rqbK4U
	MeRoiIW63bYlkD['newpath'] = qqnx9KdHMPtJ0bLTyrh
	MeRoiIW63bYlkD['menuItem'] = f7K0kyHcnp
	MeRoiIW63bYlkD['mode'] = knBV0UPuCNdpIsAFH3coRKjh2lb
	return MeRoiIW63bYlkD
def Sve9PMyXLKO10YJc6xFjTlNfai(jTHGNtlpXwR9E45e):
	IHAzM3FB5CnTQ90qtOVcLyDXGYah,CSziwD3bp1c9GWLakAB = [],nA5dhMRg6ENzsB0l1GwvH7aIr2
	from FjdxIzi5Pr import yTZ8tkWLshpjMK1fJ,yHmCRPvKgaIOdJnGTf6Dk8N7us0qW9
	l0KyZsDT1hm3z7xFkNXB4d8c = yTZ8tkWLshpjMK1fJ()
	rFj1gkWuXpTniOeKAl9VN = KQctJbXeEjDhplqknU3rzi.getSetting('av.status.refresh')
	if dWHUYEKD6hA and (not rFj1gkWuXpTniOeKAl9VN or rFj1gkWuXpTniOeKAl9VN=='REFRESH_CACHE'): rFj1gkWuXpTniOeKAl9VN = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,'str','FOLDERS_SORT',dWHUYEKD6hA)
	if rFj1gkWuXpTniOeKAl9VN:
		if   '_PERM' in rFj1gkWuXpTniOeKAl9VN: CSziwD3bp1c9GWLakAB = 'دائمي'
		elif '_TEMP' in rFj1gkWuXpTniOeKAl9VN: CSziwD3bp1c9GWLakAB = 'مؤقت'
		if   '_REVERSED_' in rFj1gkWuXpTniOeKAl9VN: gO2PcxfG7Yhd = 'عكسي' ; Nzp9Fq5cTr.menuItemsLIST[:] = reversed(Nzp9Fq5cTr.menuItemsLIST)
		elif '_ASCENDED_' in rFj1gkWuXpTniOeKAl9VN: gO2PcxfG7Yhd = 'تصاعدي' ; Nzp9Fq5cTr.menuItemsLIST[:] = sorted(Nzp9Fq5cTr.menuItemsLIST,reverse=FFKncZx5pDTwdiJRYhMgQSNL,key=lambda key:key[UnOIK1WBbw2])
		elif '_DESCENDED_' in rFj1gkWuXpTniOeKAl9VN: gO2PcxfG7Yhd = 'تنازلي' ; Nzp9Fq5cTr.menuItemsLIST[:] = sorted(Nzp9Fq5cTr.menuItemsLIST,reverse=S5MWhgtZ37Xw,key=lambda key:key[UnOIK1WBbw2])
		elif '_RANDOMIZED_' in rFj1gkWuXpTniOeKAl9VN: gO2PcxfG7Yhd = 'عشوائي' ; avZmSHVO7swUYFnTu5p9iNR8g.shuffle(Nzp9Fq5cTr.menuItemsLIST)
	name = 'ترتيب '+gO2PcxfG7Yhd+hSXlxL9iB05c+CSziwD3bp1c9GWLakAB if CSziwD3bp1c9GWLakAB else 'بدون ترتيب (أصلي)'
	name = lSWzOYmN08+name+NwROdSj3nsA
	if rFj1gkWuXpTniOeKAl9VN in Jf3OFEMHvK9mBXxnc5: KQctJbXeEjDhplqknU3rzi.setSetting('av.status.refresh',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	zzU5PnmRv13toWs4bDFL,B7n3L9yPx54v,RxWJFBAGy4iIM,No03nbgziMqjZ,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4 = boLfu8ilHFRek4ECO9GZ(dWHUYEKD6hA)
	knBV0UPuCNdpIsAFH3coRKjh2lb = int(No03nbgziMqjZ)
	TEcSfCYPnew9JiOl60KdGuN3o = knBV0UPuCNdpIsAFH3coRKjh2lb-knBV0UPuCNdpIsAFH3coRKjh2lb%10
	if knBV0UPuCNdpIsAFH3coRKjh2lb%10 and TEcSfCYPnew9JiOl60KdGuN3o not in yv4ToSVPrxwtLc8nD3I52kmebEfNs and len(Nzp9Fq5cTr.menuItemsLIST)>1:
		Nzp9Fq5cTr.menuItemsLIST[:] = [('link',name,'',533,'','',dWHUYEKD6hA,'','')]+Nzp9Fq5cTr.menuItemsLIST
	for f7K0kyHcnp in Nzp9Fq5cTr.menuItemsLIST:
		MeRoiIW63bYlkD = xu6ls91K5a2ZJtnQ(f7K0kyHcnp,jTHGNtlpXwR9E45e,l0KyZsDT1hm3z7xFkNXB4d8c)
		if MeRoiIW63bYlkD['favorites']:
			FDEa53fvWu6m8jKeZRJ = yHmCRPvKgaIOdJnGTf6Dk8N7us0qW9(l0KyZsDT1hm3z7xFkNXB4d8c,MeRoiIW63bYlkD['menuItem'],MeRoiIW63bYlkD['newpath'])
			MeRoiIW63bYlkD['context_menu'] = FDEa53fvWu6m8jKeZRJ+MeRoiIW63bYlkD['context_menu']
		IHAzM3FB5CnTQ90qtOVcLyDXGYah.append(MeRoiIW63bYlkD)
	ASrm72ijz8WEltH = FFKncZx5pDTwdiJRYhMgQSNL if '_TEMP' in rFj1gkWuXpTniOeKAl9VN else S5MWhgtZ37Xw
	return IHAzM3FB5CnTQ90qtOVcLyDXGYah,ASrm72ijz8WEltH
def AhtjSOswUNXWf8o9a6G(iAcpSGqr7yTotbZBXkN4):
	zfD3NvSkIWi5QVasAY4gqc7Orpw8u,ZONPws6T9pkcIlymvXjaozhMRrW, = [],nA5dhMRg6ENzsB0l1GwvH7aIr2
	for QQkCeBnHPEcsl6xrUTYSZ20Lo in iAcpSGqr7yTotbZBXkN4:
		if not QQkCeBnHPEcsl6xrUTYSZ20Lo: zfD3NvSkIWi5QVasAY4gqc7Orpw8u.append(nA5dhMRg6ENzsB0l1GwvH7aIr2)
		else: break
	iAcpSGqr7yTotbZBXkN4 = iAcpSGqr7yTotbZBXkN4[len(zfD3NvSkIWi5QVasAY4gqc7Orpw8u):]
	OOrjZaTIVXQ2Sp0ozhc = '\n\n\n\n'.join(iAcpSGqr7yTotbZBXkN4)
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace('===== ===== =====','000001')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace(bbTCMJwEx8nhN4X,'000002')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace(lSWzOYmN08,'000003')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace(NwROdSj3nsA,'000004')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace('[RIGHT]','000005')
	zQdDN8IFkS = 100000
	UMw0Y85Bsapzb4A = {}
	i1iSVwZyGjq9xp5UzIh7Po8mErneF = PAztbuyYo4Kvd.findall('http.*?[\r\n ]',OOrjZaTIVXQ2Sp0ozhc,PAztbuyYo4Kvd.DOTALL)
	for r58rUcGNXKHRlbmFDqyja7iIBVE in i1iSVwZyGjq9xp5UzIh7Po8mErneF:
		zQdDN8IFkS += UnOIK1WBbw2
		OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace(r58rUcGNXKHRlbmFDqyja7iIBVE,str(zQdDN8IFkS))
		UMw0Y85Bsapzb4A[str(zQdDN8IFkS)] = r58rUcGNXKHRlbmFDqyja7iIBVE
	for yFwUm7LgRGa4BhNK6V0SAXedCvMD in range(IpFcwrWNgefMym3qta0hYQAzOdE,len(OOrjZaTIVXQ2Sp0ozhc),4800):
		kXHbFalLE2xDsR3jUgKvYuI = OOrjZaTIVXQ2Sp0ozhc[yFwUm7LgRGa4BhNK6V0SAXedCvMD:yFwUm7LgRGa4BhNK6V0SAXedCvMD+4800]
		z3bkmoAhfDLW6q9jSn = KQctJbXeEjDhplqknU3rzi.getSetting('av.language.code')
		kOTdpYrPqu5A7UIcW0Ch = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+z3bkmoAhfDLW6q9jSn
		kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3 = {'Content-Type':'text/plain'}
		p2oAZgRUYeaIVnsByOuNfSGr7TdW4 = kXHbFalLE2xDsR3jUgKvYuI.encode(YWEQ3Cf8RevpD0m7NjF1)
		yyt7YxPTa8WEfK2VcMrudgJSUhzNCG = uANakQHcnhR(yy6RomT9bQhJf,'POST',kOTdpYrPqu5A7UIcW0Ch,p2oAZgRUYeaIVnsByOuNfSGr7TdW4,kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'LIBRARY-GLOSBE_TRANSLATE-1st')
		if yyt7YxPTa8WEfK2VcMrudgJSUhzNCG.succeeded:
			PB1feMy50JE6xjCv4XAHhFNd8I2R = yyt7YxPTa8WEfK2VcMrudgJSUhzNCG.content
			P2MfCEq3wkOF0 = BwGPDSQOlfUas2n3eIH0ycFRWZ('str',PB1feMy50JE6xjCv4XAHhFNd8I2R)
			if P2MfCEq3wkOF0:
				P2MfCEq3wkOF0 = P2MfCEq3wkOF0['translation']
				P2MfCEq3wkOF0 = jPgzFLH1niJpE2r(P2MfCEq3wkOF0)
				for N97NarvCiOW5uUGITznKV4gsecqh in range(len(P2MfCEq3wkOF0)):
					ZONPws6T9pkcIlymvXjaozhMRrW += P2MfCEq3wkOF0[N97NarvCiOW5uUGITznKV4gsecqh][IpFcwrWNgefMym3qta0hYQAzOdE]
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.replace('000001','===== ===== =====')
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.replace('000002',bbTCMJwEx8nhN4X)
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.replace('000003',lSWzOYmN08)
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.replace('000004',NwROdSj3nsA)
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.replace('000005','[RIGHT]')
	for zQdDN8IFkS in list(UMw0Y85Bsapzb4A.keys()):
		r58rUcGNXKHRlbmFDqyja7iIBVE = UMw0Y85Bsapzb4A[zQdDN8IFkS]
		ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.replace(zQdDN8IFkS,r58rUcGNXKHRlbmFDqyja7iIBVE)
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.split('\n\n\n\n')
	return zfD3NvSkIWi5QVasAY4gqc7Orpw8u+ZONPws6T9pkcIlymvXjaozhMRrW
def aEIH8lJUeqwVW4zAPRG(iAcpSGqr7yTotbZBXkN4):
	zfD3NvSkIWi5QVasAY4gqc7Orpw8u,ZONPws6T9pkcIlymvXjaozhMRrW, = [],nA5dhMRg6ENzsB0l1GwvH7aIr2
	for QQkCeBnHPEcsl6xrUTYSZ20Lo in iAcpSGqr7yTotbZBXkN4:
		if not QQkCeBnHPEcsl6xrUTYSZ20Lo: zfD3NvSkIWi5QVasAY4gqc7Orpw8u.append(nA5dhMRg6ENzsB0l1GwvH7aIr2)
		else: break
	iAcpSGqr7yTotbZBXkN4 = iAcpSGqr7yTotbZBXkN4[len(zfD3NvSkIWi5QVasAY4gqc7Orpw8u):]
	OOrjZaTIVXQ2Sp0ozhc = '\\n\\n\\n\\n'.join(iAcpSGqr7yTotbZBXkN4)
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace('كلا','no')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace('استمرار','continue')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace('===== ===== =====','000001')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace(bbTCMJwEx8nhN4X,'000002')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace(lSWzOYmN08,'000003')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace(NwROdSj3nsA,'000004')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace('[RIGHT]','000005')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace('[CENTER]','000006')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace('[RTL]','000007')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace("'","\\\\\\'")
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace('"','\\\\\\"')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace(CXtugbqhV3,'\\n')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace(sSBzjZdcbQraNx,'\\\\r')
	for yFwUm7LgRGa4BhNK6V0SAXedCvMD in range(IpFcwrWNgefMym3qta0hYQAzOdE,len(OOrjZaTIVXQ2Sp0ozhc),4800):
		kXHbFalLE2xDsR3jUgKvYuI = OOrjZaTIVXQ2Sp0ozhc[yFwUm7LgRGa4BhNK6V0SAXedCvMD:yFwUm7LgRGa4BhNK6V0SAXedCvMD+4800]
		kOTdpYrPqu5A7UIcW0Ch = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3 = {'Content-Type':'application/x-www-form-urlencoded'}
		z3bkmoAhfDLW6q9jSn = KQctJbXeEjDhplqknU3rzi.getSetting('av.language.code')
		p2oAZgRUYeaIVnsByOuNfSGr7TdW4 = 'f.req='+kGE6zoKSan54W('[[["MkEWBc","[[\\"'+kXHbFalLE2xDsR3jUgKvYuI+'\\",\\"ar\\",\\"'+z3bkmoAhfDLW6q9jSn+'\\",1],[]]",null,"generic"]]]',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		p2oAZgRUYeaIVnsByOuNfSGr7TdW4 = p2oAZgRUYeaIVnsByOuNfSGr7TdW4.replace('%5Cn','%5C%5Cn')
		yyt7YxPTa8WEfK2VcMrudgJSUhzNCG = uANakQHcnhR(yy6RomT9bQhJf,'POST',kOTdpYrPqu5A7UIcW0Ch,p2oAZgRUYeaIVnsByOuNfSGr7TdW4,kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'LIBRARY-GOOGLE_TRANSLATE-1st')
		if yyt7YxPTa8WEfK2VcMrudgJSUhzNCG.succeeded:
			PB1feMy50JE6xjCv4XAHhFNd8I2R = yyt7YxPTa8WEfK2VcMrudgJSUhzNCG.content
			PB1feMy50JE6xjCv4XAHhFNd8I2R = PB1feMy50JE6xjCv4XAHhFNd8I2R.split(CXtugbqhV3)[-UnOIK1WBbw2]
			P2MfCEq3wkOF0 = BwGPDSQOlfUas2n3eIH0ycFRWZ('str',PB1feMy50JE6xjCv4XAHhFNd8I2R)[IpFcwrWNgefMym3qta0hYQAzOdE][udq5tP0hwifHQCGYELDbOUI]
			if P2MfCEq3wkOF0:
				P2MfCEq3wkOF0 = BwGPDSQOlfUas2n3eIH0ycFRWZ('str',P2MfCEq3wkOF0)[UnOIK1WBbw2][IpFcwrWNgefMym3qta0hYQAzOdE][IpFcwrWNgefMym3qta0hYQAzOdE][eCaWsMty53QI9Y]
				P2MfCEq3wkOF0 = jPgzFLH1niJpE2r(P2MfCEq3wkOF0)
				for N97NarvCiOW5uUGITznKV4gsecqh in range(len(P2MfCEq3wkOF0)):
					ZONPws6T9pkcIlymvXjaozhMRrW += P2MfCEq3wkOF0[N97NarvCiOW5uUGITznKV4gsecqh][IpFcwrWNgefMym3qta0hYQAzOdE]
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.replace('00000','0000').replace('0000','000')
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.replace('0001','===== ===== =====')
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.replace('0002',bbTCMJwEx8nhN4X)
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.replace('0003',lSWzOYmN08)
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.replace('0004',NwROdSj3nsA)
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.replace('0005','[RIGHT]')
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.replace('0006','[CENTER]')
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.replace('0007','[RTL]')
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.split('\n\n\n\n')
	return zfD3NvSkIWi5QVasAY4gqc7Orpw8u+ZONPws6T9pkcIlymvXjaozhMRrW
def vBdIWk29CEtlAm3GLsaVjUguy7Z(iAcpSGqr7yTotbZBXkN4):
	zfD3NvSkIWi5QVasAY4gqc7Orpw8u,jIsb0kdR2Dw9utqC3hl = [],[]
	for QQkCeBnHPEcsl6xrUTYSZ20Lo in iAcpSGqr7yTotbZBXkN4:
		if not QQkCeBnHPEcsl6xrUTYSZ20Lo: zfD3NvSkIWi5QVasAY4gqc7Orpw8u.append(nA5dhMRg6ENzsB0l1GwvH7aIr2)
		else: break
	iAcpSGqr7yTotbZBXkN4 = iAcpSGqr7yTotbZBXkN4[len(zfD3NvSkIWi5QVasAY4gqc7Orpw8u):]
	OOrjZaTIVXQ2Sp0ozhc = '\n\n\n\n'.join(iAcpSGqr7yTotbZBXkN4)
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace('كلا','no')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace('استمرار','continue')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace('أدناه','below')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace(bbTCMJwEx8nhN4X,'00001')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace(lSWzOYmN08,'00002')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace(NwROdSj3nsA,'00003')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace('=====','00004')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace(',','00005')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace('[RTL]','00009')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace('[CENTER]','0000A')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace(sSBzjZdcbQraNx,'0000B')
	iAcpSGqr7yTotbZBXkN4 = OOrjZaTIVXQ2Sp0ozhc.split(CXtugbqhV3)
	OOrjZaTIVXQ2Sp0ozhc,ZONPws6T9pkcIlymvXjaozhMRrW = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	for QQkCeBnHPEcsl6xrUTYSZ20Lo in iAcpSGqr7yTotbZBXkN4:
		if len(OOrjZaTIVXQ2Sp0ozhc+QQkCeBnHPEcsl6xrUTYSZ20Lo)<1800: OOrjZaTIVXQ2Sp0ozhc += CXtugbqhV3+QQkCeBnHPEcsl6xrUTYSZ20Lo
		else:
			jIsb0kdR2Dw9utqC3hl.append(OOrjZaTIVXQ2Sp0ozhc)
			OOrjZaTIVXQ2Sp0ozhc = QQkCeBnHPEcsl6xrUTYSZ20Lo
	jIsb0kdR2Dw9utqC3hl.append(OOrjZaTIVXQ2Sp0ozhc)
	for QQkCeBnHPEcsl6xrUTYSZ20Lo in jIsb0kdR2Dw9utqC3hl:
		kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3 = {'Content-Type':'application/json','User-Agent':nA5dhMRg6ENzsB0l1GwvH7aIr2}
		kOTdpYrPqu5A7UIcW0Ch = 'https://api.reverso.net/translate/v1/translation'
		z3bkmoAhfDLW6q9jSn = KQctJbXeEjDhplqknU3rzi.getSetting('av.language.code')
		p2oAZgRUYeaIVnsByOuNfSGr7TdW4 = {"format":"text","from":"ara","to":z3bkmoAhfDLW6q9jSn,"input":QQkCeBnHPEcsl6xrUTYSZ20Lo,"options":{"sentenceSplitter":S5MWhgtZ37Xw,"origin":"translation.web","contextResults":FFKncZx5pDTwdiJRYhMgQSNL,"languageDetection":FFKncZx5pDTwdiJRYhMgQSNL}}
		p2oAZgRUYeaIVnsByOuNfSGr7TdW4 = DcFpQN9gqn.dumps(p2oAZgRUYeaIVnsByOuNfSGr7TdW4)
		yyt7YxPTa8WEfK2VcMrudgJSUhzNCG = uANakQHcnhR(yy6RomT9bQhJf,'POST',kOTdpYrPqu5A7UIcW0Ch,p2oAZgRUYeaIVnsByOuNfSGr7TdW4,kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'LIBRARY-REVERSO_TRANSLATE-1st')
		if yyt7YxPTa8WEfK2VcMrudgJSUhzNCG.succeeded:
			PB1feMy50JE6xjCv4XAHhFNd8I2R = yyt7YxPTa8WEfK2VcMrudgJSUhzNCG.content
			PB1feMy50JE6xjCv4XAHhFNd8I2R = BwGPDSQOlfUas2n3eIH0ycFRWZ('dict',PB1feMy50JE6xjCv4XAHhFNd8I2R)
			ZONPws6T9pkcIlymvXjaozhMRrW += CXtugbqhV3+nA5dhMRg6ENzsB0l1GwvH7aIr2.join(PB1feMy50JE6xjCv4XAHhFNd8I2R['translation'])
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW[udq5tP0hwifHQCGYELDbOUI:]
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.replace('000000','00000').replace('00000','0000').replace('0000','000')
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.replace('0001',bbTCMJwEx8nhN4X)
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.replace('0002',lSWzOYmN08)
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.replace('0003',NwROdSj3nsA)
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.replace('0004','=====')
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.replace('0005',',')
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.replace('0009','[RTL]')
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.replace('000A','[CENTER]')
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.replace('000B',sSBzjZdcbQraNx)
	ZONPws6T9pkcIlymvXjaozhMRrW = ZONPws6T9pkcIlymvXjaozhMRrW.split('\n\n\n\n')
	return zfD3NvSkIWi5QVasAY4gqc7Orpw8u+ZONPws6T9pkcIlymvXjaozhMRrW
def mQuC7REyLnh1ixAJ(iAcpSGqr7yTotbZBXkN4):
	LKX3RsruTaBd8Htp7GU = KQctJbXeEjDhplqknU3rzi.getSetting('av.language.translate')
	if not LKX3RsruTaBd8Htp7GU or not iAcpSGqr7yTotbZBXkN4: return iAcpSGqr7yTotbZBXkN4
	VxtKwlyZ1gQUcdBjCOTnSsNE = KQctJbXeEjDhplqknU3rzi.getSetting('av.language.provider')
	z3bkmoAhfDLW6q9jSn = KQctJbXeEjDhplqknU3rzi.getSetting('av.language.code')
	Hr1KNfOw7U4eLdaJiAMl8v0n = z3bkmoAhfDLW6q9jSn+'__'+str(iAcpSGqr7yTotbZBXkN4)
	KQctJbXeEjDhplqknU3rzi.setSetting('av.language.translate',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	ZONPws6T9pkcIlymvXjaozhMRrW = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,'list','TRANSLATE_'+VxtKwlyZ1gQUcdBjCOTnSsNE,Hr1KNfOw7U4eLdaJiAMl8v0n)
	if not ZONPws6T9pkcIlymvXjaozhMRrW:
		if VxtKwlyZ1gQUcdBjCOTnSsNE=='GOOGLE': ZONPws6T9pkcIlymvXjaozhMRrW = aEIH8lJUeqwVW4zAPRG(iAcpSGqr7yTotbZBXkN4)
		elif VxtKwlyZ1gQUcdBjCOTnSsNE=='REVERSO': ZONPws6T9pkcIlymvXjaozhMRrW = vBdIWk29CEtlAm3GLsaVjUguy7Z(iAcpSGqr7yTotbZBXkN4)
		elif VxtKwlyZ1gQUcdBjCOTnSsNE=='GLOSBE': ZONPws6T9pkcIlymvXjaozhMRrW = AhtjSOswUNXWf8o9a6G(iAcpSGqr7yTotbZBXkN4)
		if len(iAcpSGqr7yTotbZBXkN4)==len(ZONPws6T9pkcIlymvXjaozhMRrW):
			WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,'TRANSLATE_'+VxtKwlyZ1gQUcdBjCOTnSsNE,Hr1KNfOw7U4eLdaJiAMl8v0n,ZONPws6T9pkcIlymvXjaozhMRrW,KcwozFY2DsR3jSBO)
		else:
			ZONPws6T9pkcIlymvXjaozhMRrW = iAcpSGqr7yTotbZBXkN4
			ggYilKR5rMDyp7B('الترجمة فشلت','Translation Failed')
	KQctJbXeEjDhplqknU3rzi.setSetting('av.language.translate','1')
	return ZONPws6T9pkcIlymvXjaozhMRrW
def ujJytsaMw68dzFC(f7K0kyHcnp,IHAzM3FB5CnTQ90qtOVcLyDXGYah,aZXjJt1MRcdoWT0EUB5yhxLCG,EBYL3IOJc4RHQrbzPWolx,ggMijuX0nDdlLOszIWwBVtA):
	WTavfhd7QJDABwpIVrZqHL,w8cPT5nhW2RUAFKDa,kOTdpYrPqu5A7UIcW0Ch,knBV0UPuCNdpIsAFH3coRKjh2lb,czMOJaKwoCnSPuNTd9bIH8pfLy72W5,QbuYlX5ctHaGp42jNef8,OOrjZaTIVXQ2Sp0ozhc,qjyki7XR1FW,Gv80f9tpWiRL = f7K0kyHcnp
	fKLxqHEY6CzBcI7 = []
	LKX3RsruTaBd8Htp7GU = KQctJbXeEjDhplqknU3rzi.getSetting('av.language.translate')
	if LKX3RsruTaBd8Htp7GU:
		y5yRcOHB0vsuh3aiLEGkNrjgmJY,m7ZTJEiR9V1Lg5DXF4d0IUPljqpYnB,mmzLv3Ws0EBflrex = [],[],[]
		if not fKLxqHEY6CzBcI7:
			for MeRoiIW63bYlkD in IHAzM3FB5CnTQ90qtOVcLyDXGYah:
				w8cPT5nhW2RUAFKDa = MeRoiIW63bYlkD['name'].replace(Vfn18PSH5g2v7muhXGso9CAE6WU,nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(YgKcwxaR3Fm,nA5dhMRg6ENzsB0l1GwvH7aIr2)
				HkSGPfvR2dUcE7ayKTWVjq = PAztbuyYo4Kvd.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',w8cPT5nhW2RUAFKDa,PAztbuyYo4Kvd.DOTALL)
				if HkSGPfvR2dUcE7ayKTWVjq:
					zfD3NvSkIWi5QVasAY4gqc7Orpw8u,PHjW8JoseVEMGUpAcRDB2CTmZx,S01wg8oJB6G3CH,ii63B0KHWVEcuwjS,w8cPT5nhW2RUAFKDa = HkSGPfvR2dUcE7ayKTWVjq[IpFcwrWNgefMym3qta0hYQAzOdE]
					HkSGPfvR2dUcE7ayKTWVjq = zfD3NvSkIWi5QVasAY4gqc7Orpw8u+PHjW8JoseVEMGUpAcRDB2CTmZx+hSXlxL9iB05c+S01wg8oJB6G3CH+ii63B0KHWVEcuwjS+hSXlxL9iB05c
				else:
					HkSGPfvR2dUcE7ayKTWVjq = PAztbuyYo4Kvd.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',w8cPT5nhW2RUAFKDa,PAztbuyYo4Kvd.DOTALL)
					if HkSGPfvR2dUcE7ayKTWVjq:
						w8cPT5nhW2RUAFKDa,zfD3NvSkIWi5QVasAY4gqc7Orpw8u,S01wg8oJB6G3CH,PHjW8JoseVEMGUpAcRDB2CTmZx,ii63B0KHWVEcuwjS = HkSGPfvR2dUcE7ayKTWVjq[IpFcwrWNgefMym3qta0hYQAzOdE]
						HkSGPfvR2dUcE7ayKTWVjq = zfD3NvSkIWi5QVasAY4gqc7Orpw8u+PHjW8JoseVEMGUpAcRDB2CTmZx+hSXlxL9iB05c+S01wg8oJB6G3CH+ii63B0KHWVEcuwjS+hSXlxL9iB05c
					else: HkSGPfvR2dUcE7ayKTWVjq = nA5dhMRg6ENzsB0l1GwvH7aIr2
				yalezLRFxwCk = PAztbuyYo4Kvd.findall('^(.\[COLOR FFF08C1F\]\w\w\w \[/COLOR\])(.*?)$',w8cPT5nhW2RUAFKDa,PAztbuyYo4Kvd.DOTALL)
				if yalezLRFxwCk: yalezLRFxwCk,w8cPT5nhW2RUAFKDa = yalezLRFxwCk[IpFcwrWNgefMym3qta0hYQAzOdE]
				else: yalezLRFxwCk = nA5dhMRg6ENzsB0l1GwvH7aIr2
				y5yRcOHB0vsuh3aiLEGkNrjgmJY.append(HkSGPfvR2dUcE7ayKTWVjq+yalezLRFxwCk)
				m7ZTJEiR9V1Lg5DXF4d0IUPljqpYnB.append(w8cPT5nhW2RUAFKDa)
			mmzLv3Ws0EBflrex = mQuC7REyLnh1ixAJ(m7ZTJEiR9V1Lg5DXF4d0IUPljqpYnB)
			if mmzLv3Ws0EBflrex:
				for yFwUm7LgRGa4BhNK6V0SAXedCvMD in range(len(IHAzM3FB5CnTQ90qtOVcLyDXGYah)):
					MeRoiIW63bYlkD = IHAzM3FB5CnTQ90qtOVcLyDXGYah[yFwUm7LgRGa4BhNK6V0SAXedCvMD]
					MeRoiIW63bYlkD['name'] = y5yRcOHB0vsuh3aiLEGkNrjgmJY[yFwUm7LgRGa4BhNK6V0SAXedCvMD]+mmzLv3Ws0EBflrex[yFwUm7LgRGa4BhNK6V0SAXedCvMD]
					fKLxqHEY6CzBcI7.append(MeRoiIW63bYlkD)
	if fKLxqHEY6CzBcI7: IHAzM3FB5CnTQ90qtOVcLyDXGYah = fKLxqHEY6CzBcI7
	OA6WtDzEBfTQw3Yycu8UhKr9pPxGmv,N7j6anBqyVXIQcYidUAWKlLG,wadAZXKoHFU2Izb = [],IpFcwrWNgefMym3qta0hYQAzOdE,IpFcwrWNgefMym3qta0hYQAzOdE
	srf3mCNu1Akq0EFdJ9 = KQctJbXeEjDhplqknU3rzi.getSetting('av.status.menusimages')
	xoSkBUt7JZb2v0uMD4zf9dlHNAVCKT = srf3mCNu1Akq0EFdJ9!='STOP'
	LQiITjKJ7S105WuUgFOayNChnAmsf = []
	if xoSkBUt7JZb2v0uMD4zf9dlHNAVCKT:
		Mf6lgFUcHnJWSbs2erEXdR4Da8 = XoZRpFe7B6gnfA.path.join(A1CKpbwyFL8jY4I,knBV0UPuCNdpIsAFH3coRKjh2lb)
		try: LQiITjKJ7S105WuUgFOayNChnAmsf = XoZRpFe7B6gnfA.listdir(Mf6lgFUcHnJWSbs2erEXdR4Da8)
		except:
			if not XoZRpFe7B6gnfA.path.exists(Mf6lgFUcHnJWSbs2erEXdR4Da8):
				try: XoZRpFe7B6gnfA.makedirs(Mf6lgFUcHnJWSbs2erEXdR4Da8)
				except: pass
	Uq8DGuv9m5R6BnXYS7QWdkFpiMVJ4 = Ciy2JAmwpbjG4IrLV3('menu_item')
	ukLsrh7ObUGBVmWp9vl = LQiITjKJ7S105WuUgFOayNChnAmsf
	if cS2NYw4xulqJgvzkMF and kCNHMOym1luTnJ0.platform=='win32':
		ukLsrh7ObUGBVmWp9vl = []
		for nI0w6pMjdP53qKtcxSRalv9 in LQiITjKJ7S105WuUgFOayNChnAmsf:
			nI0w6pMjdP53qKtcxSRalv9 = nI0w6pMjdP53qKtcxSRalv9.decode('windows-1256').encode(YWEQ3Cf8RevpD0m7NjF1)
			ukLsrh7ObUGBVmWp9vl.append(nI0w6pMjdP53qKtcxSRalv9)
	for MeRoiIW63bYlkD in IHAzM3FB5CnTQ90qtOVcLyDXGYah:
		w8cPT5nhW2RUAFKDa = MeRoiIW63bYlkD['name']
		if BsLJ7p5Av2Vm0SQeCO1o: w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.encode(YWEQ3Cf8RevpD0m7NjF1,'ignore').decode(YWEQ3Cf8RevpD0m7NjF1)
		rRK0DHsXhiBZ6dTCFYgGk84pLm = MeRoiIW63bYlkD['context_menu']
		Om3qZnh01xRyAf6kFYwuJ7aV4dW8 = MeRoiIW63bYlkD['plot']
		K12W9ByOoAXDTSwh = MeRoiIW63bYlkD['stars']
		czMOJaKwoCnSPuNTd9bIH8pfLy72W5 = MeRoiIW63bYlkD['image']
		WTavfhd7QJDABwpIVrZqHL = MeRoiIW63bYlkD['type']
		gWC2upn5lKPMtRD37cG8wqd = MeRoiIW63bYlkD['duration']
		uuHw5pjCGc1WhMO6rqbK4U = MeRoiIW63bYlkD['isFolder']
		qqnx9KdHMPtJ0bLTyrh = MeRoiIW63bYlkD['newpath']
		XkwbSfO9D6As = z3jwnDkZ76OfKFB1rRoQVghbE0u92.ListItem(w8cPT5nhW2RUAFKDa)
		XkwbSfO9D6As.addContextMenuItems(rRK0DHsXhiBZ6dTCFYgGk84pLm)
		qmOFxkYv5WUciKM3S8E0s2CdI1l = FFKncZx5pDTwdiJRYhMgQSNL if xoSkBUt7JZb2v0uMD4zf9dlHNAVCKT else S5MWhgtZ37Xw
		if czMOJaKwoCnSPuNTd9bIH8pfLy72W5:
			XkwbSfO9D6As.setArt({'icon':czMOJaKwoCnSPuNTd9bIH8pfLy72W5,'thumb':czMOJaKwoCnSPuNTd9bIH8pfLy72W5,'fanart':czMOJaKwoCnSPuNTd9bIH8pfLy72W5,'banner':czMOJaKwoCnSPuNTd9bIH8pfLy72W5,'clearart':czMOJaKwoCnSPuNTd9bIH8pfLy72W5,'poster':czMOJaKwoCnSPuNTd9bIH8pfLy72W5,'clearlogo':czMOJaKwoCnSPuNTd9bIH8pfLy72W5,'landscape':czMOJaKwoCnSPuNTd9bIH8pfLy72W5})
			qmOFxkYv5WUciKM3S8E0s2CdI1l = FFKncZx5pDTwdiJRYhMgQSNL
		elif not qmOFxkYv5WUciKM3S8E0s2CdI1l:
			qmOFxkYv5WUciKM3S8E0s2CdI1l = S5MWhgtZ37Xw
			w8cPT5nhW2RUAFKDa = A5ADUfVbRmFSyH94P(FFKncZx5pDTwdiJRYhMgQSNL,w8cPT5nhW2RUAFKDa)
			w8cPT5nhW2RUAFKDa = AIWw30xBhusg(w8cPT5nhW2RUAFKDa)
			ZZJUTfwKWI = w8cPT5nhW2RUAFKDa+'.png'
			xxZ1nVtYwODjNFIhE = XoZRpFe7B6gnfA.path.join(Mf6lgFUcHnJWSbs2erEXdR4Da8,ZZJUTfwKWI)
			if ZZJUTfwKWI in ukLsrh7ObUGBVmWp9vl:
				XkwbSfO9D6As.setArt({'icon':xxZ1nVtYwODjNFIhE,'thumb':xxZ1nVtYwODjNFIhE,'fanart':xxZ1nVtYwODjNFIhE,'banner':xxZ1nVtYwODjNFIhE,'clearart':xxZ1nVtYwODjNFIhE,'poster':xxZ1nVtYwODjNFIhE,'clearlogo':xxZ1nVtYwODjNFIhE,'landscape':xxZ1nVtYwODjNFIhE})
				qmOFxkYv5WUciKM3S8E0s2CdI1l = FFKncZx5pDTwdiJRYhMgQSNL
			elif N7j6anBqyVXIQcYidUAWKlLG<40 and wadAZXKoHFU2Izb<=AH0zdvBqibaXY:
				try:
					DF8cVULNBsJf5I6 = nCRhVXfSyZlevzu04(Uq8DGuv9m5R6BnXYS7QWdkFpiMVJ4,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,w8cPT5nhW2RUAFKDa,'menu_item','center',FFKncZx5pDTwdiJRYhMgQSNL,xxZ1nVtYwODjNFIhE)
					XkwbSfO9D6As.setArt({'icon':xxZ1nVtYwODjNFIhE,'thumb':xxZ1nVtYwODjNFIhE,'fanart':xxZ1nVtYwODjNFIhE,'banner':xxZ1nVtYwODjNFIhE,'clearart':xxZ1nVtYwODjNFIhE,'poster':xxZ1nVtYwODjNFIhE,'clearlogo':xxZ1nVtYwODjNFIhE,'landscape':xxZ1nVtYwODjNFIhE})
					N7j6anBqyVXIQcYidUAWKlLG += UnOIK1WBbw2
					qmOFxkYv5WUciKM3S8E0s2CdI1l = FFKncZx5pDTwdiJRYhMgQSNL
					ukLsrh7ObUGBVmWp9vl.append(ZZJUTfwKWI)
					if N7j6anBqyVXIQcYidUAWKlLG==eCaWsMty53QI9Y: ggYilKR5rMDyp7B('إضافة الكتابة لصور القائمة','انتظار',h0skHe7TcIY9x1UP5VBrZAE8dKGnl=500)
				except: wadAZXKoHFU2Izb += UnOIK1WBbw2
		if qmOFxkYv5WUciKM3S8E0s2CdI1l:
			XkwbSfO9D6As.setArt({'icon':auGIdBD3XOJ7,'thumb':auGIdBD3XOJ7,'fanart':auGIdBD3XOJ7,'banner':auGIdBD3XOJ7,'clearart':auGIdBD3XOJ7,'poster':auGIdBD3XOJ7,'clearlogo':auGIdBD3XOJ7,'landscape':auGIdBD3XOJ7})
		if l2JAnWsaDGz8CIEZY<20:
			if Om3qZnh01xRyAf6kFYwuJ7aV4dW8: XkwbSfO9D6As.setInfo('video',{'Plot':Om3qZnh01xRyAf6kFYwuJ7aV4dW8,'PlotOutline':Om3qZnh01xRyAf6kFYwuJ7aV4dW8})
			if K12W9ByOoAXDTSwh: XkwbSfO9D6As.setInfo('video',{'Rating':K12W9ByOoAXDTSwh})
			if not czMOJaKwoCnSPuNTd9bIH8pfLy72W5:
				XkwbSfO9D6As.setInfo('video',{'Title':w8cPT5nhW2RUAFKDa})
			if WTavfhd7QJDABwpIVrZqHL=='video':
				XkwbSfO9D6As.setInfo('video',{'mediatype':'tvshow'})
				if gWC2upn5lKPMtRD37cG8wqd: XkwbSfO9D6As.setInfo('video',{'duration':gWC2upn5lKPMtRD37cG8wqd})
				XkwbSfO9D6As.setProperty('IsPlayable','true')
		else:
			VMne1SmW3ru2spG8Xtq = XkwbSfO9D6As.getVideoInfoTag()
			if K12W9ByOoAXDTSwh: VMne1SmW3ru2spG8Xtq.setRating(float(K12W9ByOoAXDTSwh))
			if not czMOJaKwoCnSPuNTd9bIH8pfLy72W5:
				VMne1SmW3ru2spG8Xtq.setTitle(w8cPT5nhW2RUAFKDa)
			if WTavfhd7QJDABwpIVrZqHL=='video':
				VMne1SmW3ru2spG8Xtq.setMediaType('tvshow')
				if gWC2upn5lKPMtRD37cG8wqd: VMne1SmW3ru2spG8Xtq.setDuration(gWC2upn5lKPMtRD37cG8wqd)
				XkwbSfO9D6As.setProperty('IsPlayable','true')
		OA6WtDzEBfTQw3Yycu8UhKr9pPxGmv.append((qqnx9KdHMPtJ0bLTyrh,XkwbSfO9D6As,uuHw5pjCGc1WhMO6rqbK4U))
	ddKIcR7M0rHT3.setContent(Aovr58Gh96iqYxOTsSnkdbF,'tvshows')
	Ao3nQxFXLu = ddKIcR7M0rHT3.addDirectoryItems(Aovr58Gh96iqYxOTsSnkdbF,OA6WtDzEBfTQw3Yycu8UhKr9pPxGmv)
	ddKIcR7M0rHT3.endOfDirectory(Aovr58Gh96iqYxOTsSnkdbF,aZXjJt1MRcdoWT0EUB5yhxLCG,EBYL3IOJc4RHQrbzPWolx,ggMijuX0nDdlLOszIWwBVtA)
	return Ao3nQxFXLu
def TBt8bUDo9WhL(WTavfhd7QJDABwpIVrZqHL,w8cPT5nhW2RUAFKDa,kOTdpYrPqu5A7UIcW0Ch,knBV0UPuCNdpIsAFH3coRKjh2lb,czMOJaKwoCnSPuNTd9bIH8pfLy72W5=nA5dhMRg6ENzsB0l1GwvH7aIr2,QbuYlX5ctHaGp42jNef8=nA5dhMRg6ENzsB0l1GwvH7aIr2,OOrjZaTIVXQ2Sp0ozhc=nA5dhMRg6ENzsB0l1GwvH7aIr2,qjyki7XR1FW=nA5dhMRg6ENzsB0l1GwvH7aIr2,Gv80f9tpWiRL={}):
	w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(sSBzjZdcbQraNx,nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('\t',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	kOTdpYrPqu5A7UIcW0Ch = kOTdpYrPqu5A7UIcW0Ch.replace(sSBzjZdcbQraNx,nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('\t',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	if '_SCRIPT_' in w8cPT5nhW2RUAFKDa:
		kNfc1ZX0HTKjpQImqiuy49g85G7UVa,w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.split('_SCRIPT_',UnOIK1WBbw2)
		if kNfc1ZX0HTKjpQImqiuy49g85G7UVa not in list(Nzp9Fq5cTr.menuItemsDICT.keys()): Nzp9Fq5cTr.menuItemsDICT[kNfc1ZX0HTKjpQImqiuy49g85G7UVa] = []
		Nzp9Fq5cTr.menuItemsDICT[kNfc1ZX0HTKjpQImqiuy49g85G7UVa].append([WTavfhd7QJDABwpIVrZqHL,w8cPT5nhW2RUAFKDa,kOTdpYrPqu5A7UIcW0Ch,knBV0UPuCNdpIsAFH3coRKjh2lb,czMOJaKwoCnSPuNTd9bIH8pfLy72W5,QbuYlX5ctHaGp42jNef8,OOrjZaTIVXQ2Sp0ozhc,qjyki7XR1FW,Gv80f9tpWiRL])
	Nzp9Fq5cTr.menuItemsLIST.append([WTavfhd7QJDABwpIVrZqHL,w8cPT5nhW2RUAFKDa,kOTdpYrPqu5A7UIcW0Ch,knBV0UPuCNdpIsAFH3coRKjh2lb,czMOJaKwoCnSPuNTd9bIH8pfLy72W5,QbuYlX5ctHaGp42jNef8,OOrjZaTIVXQ2Sp0ozhc,qjyki7XR1FW,Gv80f9tpWiRL])
	return
def HH8SJuswDBPtniebmkXIr(RSnorVLXgCp3D2Aq9zT4tE):
	if BsLJ7p5Av2Vm0SQeCO1o: from html import unescape as _U6aYfZvIWs0Kxi
	else:
		from HTMLParser import HTMLParser as MkIOg5b6BEFa
		_U6aYfZvIWs0Kxi = MkIOg5b6BEFa().unescape
	if '&' in RSnorVLXgCp3D2Aq9zT4tE and ';' in RSnorVLXgCp3D2Aq9zT4tE:
		if cS2NYw4xulqJgvzkMF: RSnorVLXgCp3D2Aq9zT4tE = RSnorVLXgCp3D2Aq9zT4tE.decode(YWEQ3Cf8RevpD0m7NjF1)
		RSnorVLXgCp3D2Aq9zT4tE = _U6aYfZvIWs0Kxi(RSnorVLXgCp3D2Aq9zT4tE)
		if cS2NYw4xulqJgvzkMF: RSnorVLXgCp3D2Aq9zT4tE = RSnorVLXgCp3D2Aq9zT4tE.encode(YWEQ3Cf8RevpD0m7NjF1)
	return RSnorVLXgCp3D2Aq9zT4tE
def jPgzFLH1niJpE2r(RSnorVLXgCp3D2Aq9zT4tE):
	if '\\u' in RSnorVLXgCp3D2Aq9zT4tE:
		if cS2NYw4xulqJgvzkMF: RSnorVLXgCp3D2Aq9zT4tE = RSnorVLXgCp3D2Aq9zT4tE.decode('unicode_escape','ignore').encode(YWEQ3Cf8RevpD0m7NjF1)
		elif BsLJ7p5Av2Vm0SQeCO1o: RSnorVLXgCp3D2Aq9zT4tE = RSnorVLXgCp3D2Aq9zT4tE.encode(YWEQ3Cf8RevpD0m7NjF1).decode('unicode_escape','ignore')
	return RSnorVLXgCp3D2Aq9zT4tE
def Nru4ln6fMS(Dz7PsbtOWhvfY6,exGwdgFIitYMmzTjpNHchXEBbRfW,xCF5zbESHJpIZlVMnmgo12wi,iRFL8y3NTAS4re1matYh9l,OOrjZaTIVXQ2Sp0ozhc,vbXDUlVaj2m6wp4PL,puNx5D97GBgP1,CCAcD10kGrTsMYQy,OmGwnXa9yu5jCIcTD6x):
	vdDWqjeEbko7cR = XoZRpFe7B6gnfA.path.dirname(OmGwnXa9yu5jCIcTD6x)
	if not XoZRpFe7B6gnfA.path.exists(vdDWqjeEbko7cR):
		try: XoZRpFe7B6gnfA.makedirs(vdDWqjeEbko7cR)
		except: pass
	IWLc4A6CEtnqOU = Ciy2JAmwpbjG4IrLV3(vbXDUlVaj2m6wp4PL)
	DF8cVULNBsJf5I6 = nCRhVXfSyZlevzu04(IWLc4A6CEtnqOU,Dz7PsbtOWhvfY6,exGwdgFIitYMmzTjpNHchXEBbRfW,xCF5zbESHJpIZlVMnmgo12wi,iRFL8y3NTAS4re1matYh9l,OOrjZaTIVXQ2Sp0ozhc,vbXDUlVaj2m6wp4PL,puNx5D97GBgP1,CCAcD10kGrTsMYQy,OmGwnXa9yu5jCIcTD6x)
	return DF8cVULNBsJf5I6
def Ciy2JAmwpbjG4IrLV3(vbXDUlVaj2m6wp4PL):
	OuM3e1R0YAiNsVv7QGdXUakIphy = eCaWsMty53QI9Y
	F0CRcWrOASM53dV6KIj = 20
	rHbIMnkTNvZJDOx = 20
	V4EzMqQehnTbf5tCYJSouGkNA = IpFcwrWNgefMym3qta0hYQAzOdE
	XJ36hDUK9kf15jbTsIld0rw = 'center'
	X2VkgA9dUzq5M1sc = IpFcwrWNgefMym3qta0hYQAzOdE
	RRwtzASPpI1sE5WHGNB0yk = 19
	PSA6o0Q2hC8NOED5l = 30
	LSD2aXmxFYzlf = 8
	qD3AkGjYXcz = S5MWhgtZ37Xw
	ZmDcywp7hILFOXGCHkJ1nSPj4 = 375
	eIZ7nuOToshB6v0d5mUNf = 410
	SZFMeKg1DTYrd = 50
	WWG0dM7JaVj2TbXPFyNwehugU = 280
	uyvzLnQgwmTCpXA6 = 28
	Tmaf58elxPGihC0p = eCaWsMty53QI9Y
	iYOToLsKbdSAqr4C5QaZ = IpFcwrWNgefMym3qta0hYQAzOdE
	C5CfGXjdRA9rE4 = 31
	yyYzG2EZNktlIF5V = [36,32,28]
	from PIL import ImageDraw as WW53tEdxkFrR6SCI2,ImageFont as C5dJgIkWOEhi9bcYFzUtSvG72L,Image as CK3ReBo6qsbwYQljSA1MO0
	if 'notification' in vbXDUlVaj2m6wp4PL:
		if vbXDUlVaj2m6wp4PL=='notification_regular':
			Z0wALoijfY16Jl4OmKgCRvtzSD5H = 117
			XJ36hDUK9kf15jbTsIld0rw = 'left'
			qD3AkGjYXcz = FFKncZx5pDTwdiJRYhMgQSNL
		elif vbXDUlVaj2m6wp4PL=='notification_auto':
			Z0wALoijfY16Jl4OmKgCRvtzSD5H = 'UPPER'
			XJ36hDUK9kf15jbTsIld0rw = 'right'
			V4EzMqQehnTbf5tCYJSouGkNA = 10
		C93CSfxrqTXhaV = 720
		yyYzG2EZNktlIF5V = [33,33,33]
		rHbIMnkTNvZJDOx = 20
		F0CRcWrOASM53dV6KIj = IpFcwrWNgefMym3qta0hYQAzOdE
		PSA6o0Q2hC8NOED5l = 20
		RRwtzASPpI1sE5WHGNB0yk = 35
	elif vbXDUlVaj2m6wp4PL=='menu_item':
		yyYzG2EZNktlIF5V,C93CSfxrqTXhaV,Z0wALoijfY16Jl4OmKgCRvtzSD5H = [28,28,28],200,250
		X2VkgA9dUzq5M1sc,PSA6o0Q2hC8NOED5l,RRwtzASPpI1sE5WHGNB0yk, = IpFcwrWNgefMym3qta0hYQAzOdE,-12,-30
		F0CRcWrOASM53dV6KIj = IpFcwrWNgefMym3qta0hYQAzOdE
		rb5zIEfVeLw3MByK4PqutWZDhnFaU = CK3ReBo6qsbwYQljSA1MO0.open(auGIdBD3XOJ7)
		k2ZdNjURSB6HTrgaz45vnMOw31lhFm = CK3ReBo6qsbwYQljSA1MO0.new('RGBA',(C93CSfxrqTXhaV,Z0wALoijfY16Jl4OmKgCRvtzSD5H),(255,IpFcwrWNgefMym3qta0hYQAzOdE,IpFcwrWNgefMym3qta0hYQAzOdE,255))
	elif vbXDUlVaj2m6wp4PL=='confirm_smallfont': yyYzG2EZNktlIF5V,Z0wALoijfY16Jl4OmKgCRvtzSD5H,C93CSfxrqTXhaV = [28,24,20],500,900
	elif vbXDUlVaj2m6wp4PL=='confirm_mediumfont': yyYzG2EZNktlIF5V,Z0wALoijfY16Jl4OmKgCRvtzSD5H,C93CSfxrqTXhaV = [32,28,24],500,900
	elif vbXDUlVaj2m6wp4PL=='confirm_bigfont': yyYzG2EZNktlIF5V,Z0wALoijfY16Jl4OmKgCRvtzSD5H,C93CSfxrqTXhaV = [36,32,28],500,900
	elif vbXDUlVaj2m6wp4PL=='textview_bigfont': Z0wALoijfY16Jl4OmKgCRvtzSD5H,C93CSfxrqTXhaV = 740,1270
	elif vbXDUlVaj2m6wp4PL=='textview_bigfont_long': Z0wALoijfY16Jl4OmKgCRvtzSD5H,C93CSfxrqTXhaV = 'UPPER',1270
	elif vbXDUlVaj2m6wp4PL=='textview_smallfont': yyYzG2EZNktlIF5V,Z0wALoijfY16Jl4OmKgCRvtzSD5H,C93CSfxrqTXhaV = [28,23,18],740,1270
	elif vbXDUlVaj2m6wp4PL=='textview_smallfont_long': yyYzG2EZNktlIF5V,Z0wALoijfY16Jl4OmKgCRvtzSD5H,C93CSfxrqTXhaV = [28,23,18],'UPPER',1270
	Uj4uY5azwtcEsJgLGVBT,jjGmlFRJyhdDov0icZe4xpTs,vBe4MqGTbtWud0k8Oyjcwfs = yyYzG2EZNktlIF5V
	Cbm7tOdrijpKgfu4BhSWNL0c8ZJMy = C5dJgIkWOEhi9bcYFzUtSvG72L.truetype(YXaEVg2JMDik9bt,size=Uj4uY5azwtcEsJgLGVBT)
	CFKHD4IPl3GrvenpWVhXJ9yw = C5dJgIkWOEhi9bcYFzUtSvG72L.truetype(YXaEVg2JMDik9bt,size=jjGmlFRJyhdDov0icZe4xpTs)
	zzRNMv2Kak58BItcuQVHsUpo1 = C5dJgIkWOEhi9bcYFzUtSvG72L.truetype(YXaEVg2JMDik9bt,size=vBe4MqGTbtWud0k8Oyjcwfs)
	ptwPCk5jz87B = C93CSfxrqTXhaV-PSA6o0Q2hC8NOED5l*udq5tP0hwifHQCGYELDbOUI
	yyuMopDrbJfj95vHAZU6SizOg1 = CK3ReBo6qsbwYQljSA1MO0.new('RGBA',(ptwPCk5jz87B,100),(255,255,255,IpFcwrWNgefMym3qta0hYQAzOdE))
	Ht64WJlAC8qR9FKQi7jdUNhmEgP = WW53tEdxkFrR6SCI2.Draw(yyuMopDrbJfj95vHAZU6SizOg1)
	wbQO3DXnM9a2ZKBHA58,fF0e374JiIHgxuzLnNGUwE8 = Ht64WJlAC8qR9FKQi7jdUNhmEgP.textsize('HHH BBB 888 000',font=Cbm7tOdrijpKgfu4BhSWNL0c8ZJMy)
	V3kRqY0ELiaUy,t2tfpKSYnRdgxJ0EPL7aHVhD4UMCs = Ht64WJlAC8qR9FKQi7jdUNhmEgP.textsize('HHH BBB 888 000',font=CFKHD4IPl3GrvenpWVhXJ9yw)
	aAE5Guj2BSf4xo1MbUDYcXnV = {'delete_harakat':FFKncZx5pDTwdiJRYhMgQSNL,'support_ligatures':S5MWhgtZ37Xw,'ARABIC LIGATURE ALLAH':FFKncZx5pDTwdiJRYhMgQSNL}
	from arabic_reshaper import ArabicReshaper as C6Ik7dw2yDnKJmFsVu
	IIPBD6ojiv3F = C6Ik7dw2yDnKJmFsVu(configuration=aAE5Guj2BSf4xo1MbUDYcXnV)
	IWLc4A6CEtnqOU = {}
	ljYLgpHW2bxGePkR3aM9 = locals()
	for RRDE0VLWY7CgkuoXlQ4jTwUM23SK in ljYLgpHW2bxGePkR3aM9: IWLc4A6CEtnqOU[RRDE0VLWY7CgkuoXlQ4jTwUM23SK] = ljYLgpHW2bxGePkR3aM9[RRDE0VLWY7CgkuoXlQ4jTwUM23SK]
	return IWLc4A6CEtnqOU
def nCRhVXfSyZlevzu04(IWLc4A6CEtnqOU,Dz7PsbtOWhvfY6,exGwdgFIitYMmzTjpNHchXEBbRfW,xCF5zbESHJpIZlVMnmgo12wi,iRFL8y3NTAS4re1matYh9l,OOrjZaTIVXQ2Sp0ozhc,vbXDUlVaj2m6wp4PL,puNx5D97GBgP1,CCAcD10kGrTsMYQy,OmGwnXa9yu5jCIcTD6x):
	for RRDE0VLWY7CgkuoXlQ4jTwUM23SK in IWLc4A6CEtnqOU: globals()[RRDE0VLWY7CgkuoXlQ4jTwUM23SK] = IWLc4A6CEtnqOU[RRDE0VLWY7CgkuoXlQ4jTwUM23SK]
	global uyvzLnQgwmTCpXA6,Tmaf58elxPGihC0p
	if vbXDUlVaj2m6wp4PL!='menu_item':
		LKX3RsruTaBd8Htp7GU = KQctJbXeEjDhplqknU3rzi.getSetting('av.language.translate')
		if LKX3RsruTaBd8Htp7GU:
			if Dz7PsbtOWhvfY6=='نعم  Yes': Dz7PsbtOWhvfY6 = 'Yes'
			elif Dz7PsbtOWhvfY6=='كلا  No': Dz7PsbtOWhvfY6 = 'No'
			if exGwdgFIitYMmzTjpNHchXEBbRfW=='نعم  Yes': exGwdgFIitYMmzTjpNHchXEBbRfW = 'Yes'
			elif exGwdgFIitYMmzTjpNHchXEBbRfW=='كلا  No': exGwdgFIitYMmzTjpNHchXEBbRfW = 'No'
			if xCF5zbESHJpIZlVMnmgo12wi=='نعم  Yes': xCF5zbESHJpIZlVMnmgo12wi = 'Yes'
			elif xCF5zbESHJpIZlVMnmgo12wi=='كلا  No': xCF5zbESHJpIZlVMnmgo12wi = 'No'
			ZLzmkuhti3vloIPnB9qcUya = mQuC7REyLnh1ixAJ([Dz7PsbtOWhvfY6,exGwdgFIitYMmzTjpNHchXEBbRfW,xCF5zbESHJpIZlVMnmgo12wi,iRFL8y3NTAS4re1matYh9l,OOrjZaTIVXQ2Sp0ozhc])
			if ZLzmkuhti3vloIPnB9qcUya: Dz7PsbtOWhvfY6,exGwdgFIitYMmzTjpNHchXEBbRfW,xCF5zbESHJpIZlVMnmgo12wi,iRFL8y3NTAS4re1matYh9l,OOrjZaTIVXQ2Sp0ozhc = ZLzmkuhti3vloIPnB9qcUya
	if cS2NYw4xulqJgvzkMF:
		OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.decode(YWEQ3Cf8RevpD0m7NjF1)
		iRFL8y3NTAS4re1matYh9l = iRFL8y3NTAS4re1matYh9l.decode(YWEQ3Cf8RevpD0m7NjF1)
		Dz7PsbtOWhvfY6 = Dz7PsbtOWhvfY6.decode(YWEQ3Cf8RevpD0m7NjF1)
		exGwdgFIitYMmzTjpNHchXEBbRfW = exGwdgFIitYMmzTjpNHchXEBbRfW.decode(YWEQ3Cf8RevpD0m7NjF1)
		xCF5zbESHJpIZlVMnmgo12wi = xCF5zbESHJpIZlVMnmgo12wi.decode(YWEQ3Cf8RevpD0m7NjF1)
	s0XLDc6to2 = iRFL8y3NTAS4re1matYh9l.count(CXtugbqhV3)+UnOIK1WBbw2
	QlmGDftcKJa8CwMzB4 = F0CRcWrOASM53dV6KIj+s0XLDc6to2*(fF0e374JiIHgxuzLnNGUwE8+V4EzMqQehnTbf5tCYJSouGkNA)-V4EzMqQehnTbf5tCYJSouGkNA
	if OOrjZaTIVXQ2Sp0ozhc:
		EZyzUBWPapSKju4sGY1RHJce7ND = t2tfpKSYnRdgxJ0EPL7aHVhD4UMCs+LSD2aXmxFYzlf
		KmuL2EF7UW = IIPBD6ojiv3F.reshape(OOrjZaTIVXQ2Sp0ozhc)
		if qD3AkGjYXcz:
			JSyYPEk1nb3 = pHW84bvj09AEkcsnlSROyIGq(Ht64WJlAC8qR9FKQi7jdUNhmEgP,CFKHD4IPl3GrvenpWVhXJ9yw,KmuL2EF7UW,jjGmlFRJyhdDov0icZe4xpTs,ptwPCk5jz87B,EZyzUBWPapSKju4sGY1RHJce7ND)
			J053XGvkNnIHdsqOAVRScjgQ = nF5gDBfa4KoJ(JSyYPEk1nb3)
			n5ntsHliT7DeZkRWgmbL8AwM = J053XGvkNnIHdsqOAVRScjgQ.count(CXtugbqhV3)+UnOIK1WBbw2
			ktVmIPCj28cbdzasB = RRwtzASPpI1sE5WHGNB0yk+n5ntsHliT7DeZkRWgmbL8AwM*EZyzUBWPapSKju4sGY1RHJce7ND-LSD2aXmxFYzlf
		else:
			ktVmIPCj28cbdzasB = RRwtzASPpI1sE5WHGNB0yk+t2tfpKSYnRdgxJ0EPL7aHVhD4UMCs
			J053XGvkNnIHdsqOAVRScjgQ = KmuL2EF7UW.split(CXtugbqhV3)[IpFcwrWNgefMym3qta0hYQAzOdE]
			JSyYPEk1nb3 = KmuL2EF7UW.split(CXtugbqhV3)[IpFcwrWNgefMym3qta0hYQAzOdE]
	else: ktVmIPCj28cbdzasB = RRwtzASPpI1sE5WHGNB0yk
	VuqWsBdQI3XnN0j = iYOToLsKbdSAqr4C5QaZ+C5CfGXjdRA9rE4
	if CCAcD10kGrTsMYQy:
		Bxm7IZEY8V = eIZ7nuOToshB6v0d5mUNf-ZmDcywp7hILFOXGCHkJ1nSPj4
		VuqWsBdQI3XnN0j += Bxm7IZEY8V
	else: Bxm7IZEY8V = IpFcwrWNgefMym3qta0hYQAzOdE
	if Dz7PsbtOWhvfY6 or exGwdgFIitYMmzTjpNHchXEBbRfW or xCF5zbESHJpIZlVMnmgo12wi: VuqWsBdQI3XnN0j += SZFMeKg1DTYrd
	DF8cVULNBsJf5I6 = Z0wALoijfY16Jl4OmKgCRvtzSD5H if Z0wALoijfY16Jl4OmKgCRvtzSD5H!='UPPER' else QlmGDftcKJa8CwMzB4+ktVmIPCj28cbdzasB+VuqWsBdQI3XnN0j
	yyuMopDrbJfj95vHAZU6SizOg1 = CK3ReBo6qsbwYQljSA1MO0.new('RGBA',(C93CSfxrqTXhaV,DF8cVULNBsJf5I6),(255,255,255,IpFcwrWNgefMym3qta0hYQAzOdE))
	O7SgGWycpPxanXJ0Q1 = WW53tEdxkFrR6SCI2.Draw(yyuMopDrbJfj95vHAZU6SizOg1)
	z28oKHsIMXlpmgyNcxBh = DF8cVULNBsJf5I6-QlmGDftcKJa8CwMzB4-VuqWsBdQI3XnN0j-RRwtzASPpI1sE5WHGNB0yk
	if not exGwdgFIitYMmzTjpNHchXEBbRfW and Dz7PsbtOWhvfY6 and xCF5zbESHJpIZlVMnmgo12wi:
		uyvzLnQgwmTCpXA6 += 105
		Tmaf58elxPGihC0p -= 110
	import bidi.algorithm as rrEG9U6dalA
	if iRFL8y3NTAS4re1matYh9l:
		H8FJjTOtElZSvDsXGQPY7K9Vkbx3yg = F0CRcWrOASM53dV6KIj
		iRFL8y3NTAS4re1matYh9l = rrEG9U6dalA.get_display(IIPBD6ojiv3F.reshape(iRFL8y3NTAS4re1matYh9l))
		iAcpSGqr7yTotbZBXkN4 = iRFL8y3NTAS4re1matYh9l.splitlines()
		for QQkCeBnHPEcsl6xrUTYSZ20Lo in iAcpSGqr7yTotbZBXkN4:
			if QQkCeBnHPEcsl6xrUTYSZ20Lo:
				Xy69ezFdrlItkUwDivVTsKG7nPj4up,jjZqIEN0CW = O7SgGWycpPxanXJ0Q1.textsize(QQkCeBnHPEcsl6xrUTYSZ20Lo,font=Cbm7tOdrijpKgfu4BhSWNL0c8ZJMy)
				if XJ36hDUK9kf15jbTsIld0rw=='center': UCs2NQytdfloHcVhkx = OuM3e1R0YAiNsVv7QGdXUakIphy+(C93CSfxrqTXhaV-Xy69ezFdrlItkUwDivVTsKG7nPj4up)/udq5tP0hwifHQCGYELDbOUI
				elif XJ36hDUK9kf15jbTsIld0rw=='right': UCs2NQytdfloHcVhkx = OuM3e1R0YAiNsVv7QGdXUakIphy+C93CSfxrqTXhaV-Xy69ezFdrlItkUwDivVTsKG7nPj4up-rHbIMnkTNvZJDOx
				elif XJ36hDUK9kf15jbTsIld0rw=='left': UCs2NQytdfloHcVhkx = OuM3e1R0YAiNsVv7QGdXUakIphy+rHbIMnkTNvZJDOx
				O7SgGWycpPxanXJ0Q1.text((UCs2NQytdfloHcVhkx,H8FJjTOtElZSvDsXGQPY7K9Vkbx3yg),QQkCeBnHPEcsl6xrUTYSZ20Lo,font=Cbm7tOdrijpKgfu4BhSWNL0c8ZJMy,fill='yellow')
			H8FJjTOtElZSvDsXGQPY7K9Vkbx3yg += Uj4uY5azwtcEsJgLGVBT+V4EzMqQehnTbf5tCYJSouGkNA
	if Dz7PsbtOWhvfY6 or exGwdgFIitYMmzTjpNHchXEBbRfW or xCF5zbESHJpIZlVMnmgo12wi:
		hC5v84bdWw3Q0Vea9 = QlmGDftcKJa8CwMzB4+z28oKHsIMXlpmgyNcxBh+RRwtzASPpI1sE5WHGNB0yk+Bxm7IZEY8V+iYOToLsKbdSAqr4C5QaZ
		if Dz7PsbtOWhvfY6:
			Dz7PsbtOWhvfY6 = rrEG9U6dalA.get_display(IIPBD6ojiv3F.reshape(Dz7PsbtOWhvfY6))
			JrZSMC9Fny,jg9VLzMACn4WUR = O7SgGWycpPxanXJ0Q1.textsize(Dz7PsbtOWhvfY6,font=zzRNMv2Kak58BItcuQVHsUpo1)
			llnWFBcTwLJbZsapU = uyvzLnQgwmTCpXA6+IpFcwrWNgefMym3qta0hYQAzOdE*(Tmaf58elxPGihC0p+WWG0dM7JaVj2TbXPFyNwehugU)+(WWG0dM7JaVj2TbXPFyNwehugU-JrZSMC9Fny)/udq5tP0hwifHQCGYELDbOUI
			O7SgGWycpPxanXJ0Q1.text((llnWFBcTwLJbZsapU,hC5v84bdWw3Q0Vea9),Dz7PsbtOWhvfY6,font=zzRNMv2Kak58BItcuQVHsUpo1,fill='yellow')
		if exGwdgFIitYMmzTjpNHchXEBbRfW:
			exGwdgFIitYMmzTjpNHchXEBbRfW = rrEG9U6dalA.get_display(IIPBD6ojiv3F.reshape(exGwdgFIitYMmzTjpNHchXEBbRfW))
			rNyEhYOTe2x5QBkPsovwXDZW6jf,Rpz4bhurBHM = O7SgGWycpPxanXJ0Q1.textsize(exGwdgFIitYMmzTjpNHchXEBbRfW,font=zzRNMv2Kak58BItcuQVHsUpo1)
			sTfQAMWZ1mlw7ebNvPo6Vcd = uyvzLnQgwmTCpXA6+UnOIK1WBbw2*(Tmaf58elxPGihC0p+WWG0dM7JaVj2TbXPFyNwehugU)+(WWG0dM7JaVj2TbXPFyNwehugU-rNyEhYOTe2x5QBkPsovwXDZW6jf)/udq5tP0hwifHQCGYELDbOUI
			O7SgGWycpPxanXJ0Q1.text((sTfQAMWZ1mlw7ebNvPo6Vcd,hC5v84bdWw3Q0Vea9),exGwdgFIitYMmzTjpNHchXEBbRfW,font=zzRNMv2Kak58BItcuQVHsUpo1,fill='yellow')
		if xCF5zbESHJpIZlVMnmgo12wi:
			xCF5zbESHJpIZlVMnmgo12wi = rrEG9U6dalA.get_display(IIPBD6ojiv3F.reshape(xCF5zbESHJpIZlVMnmgo12wi))
			Wv8C7XaT3NK0Q,ZHuSKNp1e7cFY5LRPrJ3EtTg = O7SgGWycpPxanXJ0Q1.textsize(xCF5zbESHJpIZlVMnmgo12wi,font=zzRNMv2Kak58BItcuQVHsUpo1)
			GbH1xgsVRlWyTP4oQNapru9nz7hOY = uyvzLnQgwmTCpXA6+udq5tP0hwifHQCGYELDbOUI*(Tmaf58elxPGihC0p+WWG0dM7JaVj2TbXPFyNwehugU)+(WWG0dM7JaVj2TbXPFyNwehugU-Wv8C7XaT3NK0Q)/udq5tP0hwifHQCGYELDbOUI
			O7SgGWycpPxanXJ0Q1.text((GbH1xgsVRlWyTP4oQNapru9nz7hOY,hC5v84bdWw3Q0Vea9),xCF5zbESHJpIZlVMnmgo12wi,font=zzRNMv2Kak58BItcuQVHsUpo1,fill='yellow')
	if OOrjZaTIVXQ2Sp0ozhc:
		RjiSUIn3VYp,aYAiZ0InfrjpWc9VN = [],[]
		JSyYPEk1nb3 = RlbYKmaJe6uCjVkE0HQ8dr(JSyYPEk1nb3)
		fLwqkB83DvX24sNyj5 = JSyYPEk1nb3.split('_sss__newline_')
		for BZ6XWKEjcktPwAF4a2d in fLwqkB83DvX24sNyj5:
			NUm0BKot5vWE1cG2r6 = puNx5D97GBgP1
			if   '_sss__lineleft_' in BZ6XWKEjcktPwAF4a2d: NUm0BKot5vWE1cG2r6 = 'left'
			elif '_sss__lineright_' in BZ6XWKEjcktPwAF4a2d: NUm0BKot5vWE1cG2r6 = 'right'
			elif '_sss__linecenter_' in BZ6XWKEjcktPwAF4a2d: NUm0BKot5vWE1cG2r6 = 'center'
			LL0feOxFVUDszwoM7hNGrCKI = BZ6XWKEjcktPwAF4a2d
			bJCUrtdWivXcZ3MLERpmeH = PAztbuyYo4Kvd.findall('_sss__.*?_',BZ6XWKEjcktPwAF4a2d,PAztbuyYo4Kvd.DOTALL)
			for lHGcjIkwOvEQMo in bJCUrtdWivXcZ3MLERpmeH: LL0feOxFVUDszwoM7hNGrCKI = LL0feOxFVUDszwoM7hNGrCKI.replace(lHGcjIkwOvEQMo,nA5dhMRg6ENzsB0l1GwvH7aIr2)
			if LL0feOxFVUDszwoM7hNGrCKI==nA5dhMRg6ENzsB0l1GwvH7aIr2: Xy69ezFdrlItkUwDivVTsKG7nPj4up,jjZqIEN0CW = IpFcwrWNgefMym3qta0hYQAzOdE,EZyzUBWPapSKju4sGY1RHJce7ND
			else: Xy69ezFdrlItkUwDivVTsKG7nPj4up,jjZqIEN0CW = O7SgGWycpPxanXJ0Q1.textsize(LL0feOxFVUDszwoM7hNGrCKI,font=CFKHD4IPl3GrvenpWVhXJ9yw)
			if   NUm0BKot5vWE1cG2r6=='left': zc6IeHFdrqb3u0lvpOWmjDMXTy = X2VkgA9dUzq5M1sc+PSA6o0Q2hC8NOED5l
			elif NUm0BKot5vWE1cG2r6=='right': zc6IeHFdrqb3u0lvpOWmjDMXTy = X2VkgA9dUzq5M1sc+PSA6o0Q2hC8NOED5l+ptwPCk5jz87B-Xy69ezFdrlItkUwDivVTsKG7nPj4up
			elif NUm0BKot5vWE1cG2r6=='center': zc6IeHFdrqb3u0lvpOWmjDMXTy = X2VkgA9dUzq5M1sc+PSA6o0Q2hC8NOED5l+(ptwPCk5jz87B-Xy69ezFdrlItkUwDivVTsKG7nPj4up)/udq5tP0hwifHQCGYELDbOUI
			if zc6IeHFdrqb3u0lvpOWmjDMXTy<PSA6o0Q2hC8NOED5l: zc6IeHFdrqb3u0lvpOWmjDMXTy = X2VkgA9dUzq5M1sc+PSA6o0Q2hC8NOED5l
			RjiSUIn3VYp.append(zc6IeHFdrqb3u0lvpOWmjDMXTy)
			aYAiZ0InfrjpWc9VN.append(Xy69ezFdrlItkUwDivVTsKG7nPj4up)
		zc6IeHFdrqb3u0lvpOWmjDMXTy = RjiSUIn3VYp[IpFcwrWNgefMym3qta0hYQAzOdE]
		RmphvSFLD7cTaMl83JouYkbteKBC = JSyYPEk1nb3.split('_sss_')
		DBfx4z3XVjWI67qOFUrd = (255,255,255,255)
		hitdxYvZcnXSJlIuRVkmGp2K = DBfx4z3XVjWI67qOFUrd
		gCSeRKjHIObnGVE2,duQYAe5IWX = IpFcwrWNgefMym3qta0hYQAzOdE,IpFcwrWNgefMym3qta0hYQAzOdE
		xokX8yPdiRnYhmQI4Fp5KLq0Gs = FFKncZx5pDTwdiJRYhMgQSNL
		ttOU7M5HyJnGVmuwSixZlz = IpFcwrWNgefMym3qta0hYQAzOdE
		HD91Q2RpsiF = QlmGDftcKJa8CwMzB4+RRwtzASPpI1sE5WHGNB0yk/udq5tP0hwifHQCGYELDbOUI
		if ktVmIPCj28cbdzasB<(z28oKHsIMXlpmgyNcxBh+RRwtzASPpI1sE5WHGNB0yk):
			AnxDPjmEG9rwYqBZ2evt1ldaWNoXQz = (z28oKHsIMXlpmgyNcxBh+RRwtzASPpI1sE5WHGNB0yk-ktVmIPCj28cbdzasB)/udq5tP0hwifHQCGYELDbOUI
			HD91Q2RpsiF = QlmGDftcKJa8CwMzB4+RRwtzASPpI1sE5WHGNB0yk+AnxDPjmEG9rwYqBZ2evt1ldaWNoXQz-t2tfpKSYnRdgxJ0EPL7aHVhD4UMCs/udq5tP0hwifHQCGYELDbOUI
		for QQkCeBnHPEcsl6xrUTYSZ20Lo in RmphvSFLD7cTaMl83JouYkbteKBC:
			if not QQkCeBnHPEcsl6xrUTYSZ20Lo or (QQkCeBnHPEcsl6xrUTYSZ20Lo and ord(QQkCeBnHPEcsl6xrUTYSZ20Lo[IpFcwrWNgefMym3qta0hYQAzOdE])==65279): continue
			ffw1qg5mI2XRVlSKhtNHJrCYd = QQkCeBnHPEcsl6xrUTYSZ20Lo.split('_newline_',UnOIK1WBbw2)
			wSYOrDdnVs9 = QQkCeBnHPEcsl6xrUTYSZ20Lo.split('_newcolor',UnOIK1WBbw2)
			w5wVuDr3Kvql = QQkCeBnHPEcsl6xrUTYSZ20Lo.split('_endcolor_',UnOIK1WBbw2)
			dPkUhE3KFH = QQkCeBnHPEcsl6xrUTYSZ20Lo.split('_linertl_',UnOIK1WBbw2)
			JJ5FgUyR7uVLcGf3noMr2WsYdC = QQkCeBnHPEcsl6xrUTYSZ20Lo.split('_lineleft_',UnOIK1WBbw2)
			NspRrTO1Cm0nUaiLFeB5k = QQkCeBnHPEcsl6xrUTYSZ20Lo.split('_lineright_',UnOIK1WBbw2)
			dOLAVU04jD2BKGCx = QQkCeBnHPEcsl6xrUTYSZ20Lo.split('_linecenter_',UnOIK1WBbw2)
			if len(ffw1qg5mI2XRVlSKhtNHJrCYd)>UnOIK1WBbw2:
				ttOU7M5HyJnGVmuwSixZlz += UnOIK1WBbw2
				QQkCeBnHPEcsl6xrUTYSZ20Lo = ffw1qg5mI2XRVlSKhtNHJrCYd[UnOIK1WBbw2]
				gCSeRKjHIObnGVE2 = IpFcwrWNgefMym3qta0hYQAzOdE
				zc6IeHFdrqb3u0lvpOWmjDMXTy = RjiSUIn3VYp[ttOU7M5HyJnGVmuwSixZlz]
				duQYAe5IWX += EZyzUBWPapSKju4sGY1RHJce7ND
				xokX8yPdiRnYhmQI4Fp5KLq0Gs = FFKncZx5pDTwdiJRYhMgQSNL
			elif len(wSYOrDdnVs9)>UnOIK1WBbw2:
				QQkCeBnHPEcsl6xrUTYSZ20Lo = wSYOrDdnVs9[UnOIK1WBbw2]
				hitdxYvZcnXSJlIuRVkmGp2K = QQkCeBnHPEcsl6xrUTYSZ20Lo[IpFcwrWNgefMym3qta0hYQAzOdE:8]
				hitdxYvZcnXSJlIuRVkmGp2K = '#'+hitdxYvZcnXSJlIuRVkmGp2K[udq5tP0hwifHQCGYELDbOUI:]
				QQkCeBnHPEcsl6xrUTYSZ20Lo = QQkCeBnHPEcsl6xrUTYSZ20Lo[9:]
			elif len(w5wVuDr3Kvql)>UnOIK1WBbw2:
				QQkCeBnHPEcsl6xrUTYSZ20Lo = w5wVuDr3Kvql[UnOIK1WBbw2]
				hitdxYvZcnXSJlIuRVkmGp2K = DBfx4z3XVjWI67qOFUrd
			elif len(dPkUhE3KFH)>UnOIK1WBbw2:
				QQkCeBnHPEcsl6xrUTYSZ20Lo = dPkUhE3KFH[UnOIK1WBbw2]
				xokX8yPdiRnYhmQI4Fp5KLq0Gs = S5MWhgtZ37Xw
				gCSeRKjHIObnGVE2 = aYAiZ0InfrjpWc9VN[ttOU7M5HyJnGVmuwSixZlz]
			elif len(JJ5FgUyR7uVLcGf3noMr2WsYdC)>1: QQkCeBnHPEcsl6xrUTYSZ20Lo = JJ5FgUyR7uVLcGf3noMr2WsYdC[UnOIK1WBbw2]
			elif len(NspRrTO1Cm0nUaiLFeB5k)>1: QQkCeBnHPEcsl6xrUTYSZ20Lo = NspRrTO1Cm0nUaiLFeB5k[UnOIK1WBbw2]
			elif len(dOLAVU04jD2BKGCx)>1: QQkCeBnHPEcsl6xrUTYSZ20Lo = dOLAVU04jD2BKGCx[UnOIK1WBbw2]
			if QQkCeBnHPEcsl6xrUTYSZ20Lo:
				MMOPWXsKGomq412Qb5iSHNEru = HD91Q2RpsiF+duQYAe5IWX
				QQkCeBnHPEcsl6xrUTYSZ20Lo = rrEG9U6dalA.get_display(QQkCeBnHPEcsl6xrUTYSZ20Lo)
				Xy69ezFdrlItkUwDivVTsKG7nPj4up,jjZqIEN0CW = O7SgGWycpPxanXJ0Q1.textsize(QQkCeBnHPEcsl6xrUTYSZ20Lo,font=CFKHD4IPl3GrvenpWVhXJ9yw)
				if xokX8yPdiRnYhmQI4Fp5KLq0Gs: gCSeRKjHIObnGVE2 -= Xy69ezFdrlItkUwDivVTsKG7nPj4up
				FkXdZ7uVx16esg28 = zc6IeHFdrqb3u0lvpOWmjDMXTy+gCSeRKjHIObnGVE2
				O7SgGWycpPxanXJ0Q1.text((FkXdZ7uVx16esg28,MMOPWXsKGomq412Qb5iSHNEru),QQkCeBnHPEcsl6xrUTYSZ20Lo,font=CFKHD4IPl3GrvenpWVhXJ9yw,fill=hitdxYvZcnXSJlIuRVkmGp2K)
				if vbXDUlVaj2m6wp4PL=='menu_item': O7SgGWycpPxanXJ0Q1.text((FkXdZ7uVx16esg28+UnOIK1WBbw2,MMOPWXsKGomq412Qb5iSHNEru+UnOIK1WBbw2),QQkCeBnHPEcsl6xrUTYSZ20Lo,font=CFKHD4IPl3GrvenpWVhXJ9yw,fill=hitdxYvZcnXSJlIuRVkmGp2K)
				if not xokX8yPdiRnYhmQI4Fp5KLq0Gs: gCSeRKjHIObnGVE2 += Xy69ezFdrlItkUwDivVTsKG7nPj4up
				if MMOPWXsKGomq412Qb5iSHNEru>z28oKHsIMXlpmgyNcxBh+EZyzUBWPapSKju4sGY1RHJce7ND: break
	if vbXDUlVaj2m6wp4PL=='menu_item':
		ANf0MarKjEGmy7YhX9LuPJ3O6 = rb5zIEfVeLw3MByK4PqutWZDhnFaU.copy()
		h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(0.05)
		ANf0MarKjEGmy7YhX9LuPJ3O6.paste(k2ZdNjURSB6HTrgaz45vnMOw31lhFm,(IpFcwrWNgefMym3qta0hYQAzOdE,IpFcwrWNgefMym3qta0hYQAzOdE),mask=yyuMopDrbJfj95vHAZU6SizOg1)
	else: ANf0MarKjEGmy7YhX9LuPJ3O6 = yyuMopDrbJfj95vHAZU6SizOg1
	if cS2NYw4xulqJgvzkMF: OmGwnXa9yu5jCIcTD6x = OmGwnXa9yu5jCIcTD6x.decode(YWEQ3Cf8RevpD0m7NjF1)
	try: ANf0MarKjEGmy7YhX9LuPJ3O6.save(OmGwnXa9yu5jCIcTD6x)
	except UnicodeError:
		if cS2NYw4xulqJgvzkMF:
			OmGwnXa9yu5jCIcTD6x = OmGwnXa9yu5jCIcTD6x.encode(YWEQ3Cf8RevpD0m7NjF1)
			ANf0MarKjEGmy7YhX9LuPJ3O6.save(OmGwnXa9yu5jCIcTD6x)
	return DF8cVULNBsJf5I6
def pHW84bvj09AEkcsnlSROyIGq(Ht64WJlAC8qR9FKQi7jdUNhmEgP,CFKHD4IPl3GrvenpWVhXJ9yw,Y2Zx39Ic4pEOmw5NWaqbu,CC4c0qgrf18GJ3MKpjnB,ptwPCk5jz87B,jgVG26Ui7LkJl8dNxRXS3BwqT):
	h3hHgtwvi5qrb2Fo,UqH2hZaCDdLkJKI5F71fRVgYi9Ml,tsMKbgqfFcLRhC = nA5dhMRg6ENzsB0l1GwvH7aIr2,IpFcwrWNgefMym3qta0hYQAzOdE,15000
	Y2Zx39Ic4pEOmw5NWaqbu = Y2Zx39Ic4pEOmw5NWaqbu.replace('[COLOR ','[COLOR:::')
	DxJvsGzTtOCIEqU6Ke = ptwPCk5jz87B-CC4c0qgrf18GJ3MKpjnB*udq5tP0hwifHQCGYELDbOUI
	for qPR2LvzFVo40wcWS6MHABubXCedJ in Y2Zx39Ic4pEOmw5NWaqbu.splitlines():
		UqH2hZaCDdLkJKI5F71fRVgYi9Ml += jgVG26Ui7LkJl8dNxRXS3BwqT
		zCsnceK35iNX,G9GXqubr35naTyZgIR = IpFcwrWNgefMym3qta0hYQAzOdE,nA5dhMRg6ENzsB0l1GwvH7aIr2
		for IvBSf4QwCTg in qPR2LvzFVo40wcWS6MHABubXCedJ.split(hSXlxL9iB05c):
			sDvTRdfN8xkEWbjzpIVtP = nF5gDBfa4KoJ(hSXlxL9iB05c+IvBSf4QwCTg)
			ZZlxz6GQeRE,NNkEiWAhSIQM64 = Ht64WJlAC8qR9FKQi7jdUNhmEgP.textsize(sDvTRdfN8xkEWbjzpIVtP,font=CFKHD4IPl3GrvenpWVhXJ9yw)
			if zCsnceK35iNX+ZZlxz6GQeRE<DxJvsGzTtOCIEqU6Ke:
				if not G9GXqubr35naTyZgIR: G9GXqubr35naTyZgIR += IvBSf4QwCTg
				else: G9GXqubr35naTyZgIR += hSXlxL9iB05c+IvBSf4QwCTg
				zCsnceK35iNX += ZZlxz6GQeRE
			else:
				if ZZlxz6GQeRE<DxJvsGzTtOCIEqU6Ke:
					G9GXqubr35naTyZgIR += '\n '+IvBSf4QwCTg
					UqH2hZaCDdLkJKI5F71fRVgYi9Ml += jgVG26Ui7LkJl8dNxRXS3BwqT
					zCsnceK35iNX = ZZlxz6GQeRE
				else:
					while ZZlxz6GQeRE>DxJvsGzTtOCIEqU6Ke:
						for yFwUm7LgRGa4BhNK6V0SAXedCvMD in range(UnOIK1WBbw2,len(hSXlxL9iB05c+IvBSf4QwCTg),UnOIK1WBbw2):
							eeQIgDWYSlbyzd3nxG4Nfpc7EAPFa = hSXlxL9iB05c+IvBSf4QwCTg[:yFwUm7LgRGa4BhNK6V0SAXedCvMD]
							lk28deAbXBCwNLF1TM = IvBSf4QwCTg[yFwUm7LgRGa4BhNK6V0SAXedCvMD:]
							vnahQGlum5O697MtLCgITsYXHKD = nF5gDBfa4KoJ(eeQIgDWYSlbyzd3nxG4Nfpc7EAPFa)
							uirsmAEV4e6tg83ZGadpScC,aSQ0HI2CZTpLBsxDjrfGlnt5OMvE6 = Ht64WJlAC8qR9FKQi7jdUNhmEgP.textsize(vnahQGlum5O697MtLCgITsYXHKD,font=CFKHD4IPl3GrvenpWVhXJ9yw)
							if zCsnceK35iNX+uirsmAEV4e6tg83ZGadpScC>DxJvsGzTtOCIEqU6Ke:
								oE041wixrAUHNn = ZZlxz6GQeRE-uirsmAEV4e6tg83ZGadpScC
								G9GXqubr35naTyZgIR += eeQIgDWYSlbyzd3nxG4Nfpc7EAPFa+CXtugbqhV3
								UqH2hZaCDdLkJKI5F71fRVgYi9Ml += jgVG26Ui7LkJl8dNxRXS3BwqT
								ZZlxz6GQeRE = oE041wixrAUHNn
								if oE041wixrAUHNn>DxJvsGzTtOCIEqU6Ke:
									zCsnceK35iNX = IpFcwrWNgefMym3qta0hYQAzOdE
									IvBSf4QwCTg = lk28deAbXBCwNLF1TM
								else:
									zCsnceK35iNX = oE041wixrAUHNn
									G9GXqubr35naTyZgIR += lk28deAbXBCwNLF1TM
								break
				if UqH2hZaCDdLkJKI5F71fRVgYi9Ml>tsMKbgqfFcLRhC: break
		h3hHgtwvi5qrb2Fo += CXtugbqhV3+G9GXqubr35naTyZgIR
		if UqH2hZaCDdLkJKI5F71fRVgYi9Ml>tsMKbgqfFcLRhC: break
	h3hHgtwvi5qrb2Fo = h3hHgtwvi5qrb2Fo[UnOIK1WBbw2:]
	h3hHgtwvi5qrb2Fo = h3hHgtwvi5qrb2Fo.replace('[COLOR:::','[COLOR ')
	return h3hHgtwvi5qrb2Fo
def nF5gDBfa4KoJ(IvBSf4QwCTg):
	if '[' in IvBSf4QwCTg and ']' in IvBSf4QwCTg:
		bJCUrtdWivXcZ3MLERpmeH = [NwROdSj3nsA,'[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		RqGa6pwQAObCxfYBX52yS = PAztbuyYo4Kvd.findall('\[COLOR .*?\]',IvBSf4QwCTg,PAztbuyYo4Kvd.DOTALL)
		RQbw6yn2mC0jVNKUOTJsASZE = PAztbuyYo4Kvd.findall('\[COLOR:::.*?\]',IvBSf4QwCTg,PAztbuyYo4Kvd.DOTALL)
		ZVX51Wk2RacKJyotxGhjFObps = bJCUrtdWivXcZ3MLERpmeH+RqGa6pwQAObCxfYBX52yS+RQbw6yn2mC0jVNKUOTJsASZE
		for lHGcjIkwOvEQMo in ZVX51Wk2RacKJyotxGhjFObps: IvBSf4QwCTg = IvBSf4QwCTg.replace(lHGcjIkwOvEQMo,nA5dhMRg6ENzsB0l1GwvH7aIr2)
	return IvBSf4QwCTg
def RlbYKmaJe6uCjVkE0HQ8dr(OOrjZaTIVXQ2Sp0ozhc):
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace(CXtugbqhV3,'_sss__newline_')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace('[RTL]','_sss__linertl_')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace('[LEFT]','_sss__lineleft_')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace('[RIGHT]','_sss__lineright_')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace('[CENTER]','_sss__linecenter_')
	OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace(NwROdSj3nsA,'_sss__endcolor_')
	QGcCw3oBKE1ZdT4DbzUOHP = PAztbuyYo4Kvd.findall('\[COLOR (.*?)\]',OOrjZaTIVXQ2Sp0ozhc,PAztbuyYo4Kvd.DOTALL)
	for cgh26iPjA4xQVysXCD in QGcCw3oBKE1ZdT4DbzUOHP: OOrjZaTIVXQ2Sp0ozhc = OOrjZaTIVXQ2Sp0ozhc.replace('[COLOR '+cgh26iPjA4xQVysXCD+']','_sss__newcolor'+cgh26iPjA4xQVysXCD+'_')
	return OOrjZaTIVXQ2Sp0ozhc
def A5ADUfVbRmFSyH94P(qADBrcFgYK,w8cPT5nhW2RUAFKDa=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if not w8cPT5nhW2RUAFKDa: w8cPT5nhW2RUAFKDa = SoNGUfhMDERLyHOz1qkVAj.getInfoLabel('ListItem.Label')
	w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(cqsuhi1JE7nNIfbPYQSpFgeGr,hSXlxL9iB05c).replace(PwYGfc4gTjiyRlsHn1OE,hSXlxL9iB05c).replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c).strip(hSXlxL9iB05c)
	if qADBrcFgYK: w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace('[COLOR ',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(']',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	else: w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(lSWzOYmN08,nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(bbTCMJwEx8nhN4X,nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(h7h2iacotq5wjsvEfyu3IBgTO,nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(bwfNZXGCvAdcBlDqLJpT2Hnj,nA5dhMRg6ENzsB0l1GwvH7aIr2)
	w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(sSBzjZdcbQraNx,nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2)
	w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(Vfn18PSH5g2v7muhXGso9CAE6WU,nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(YgKcwxaR3Fm,nA5dhMRg6ENzsB0l1GwvH7aIr2)
	tJ7mYpAnqlMSDjUXgQbuHf4NP = PAztbuyYo4Kvd.findall('\d\d:\d\d ',w8cPT5nhW2RUAFKDa,PAztbuyYo4Kvd.DOTALL)
	if tJ7mYpAnqlMSDjUXgQbuHf4NP: w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.split(tJ7mYpAnqlMSDjUXgQbuHf4NP[IpFcwrWNgefMym3qta0hYQAzOdE],UnOIK1WBbw2)[UnOIK1WBbw2]
	if not w8cPT5nhW2RUAFKDa: w8cPT5nhW2RUAFKDa = 'Main Menu'
	return w8cPT5nhW2RUAFKDa
def AIWw30xBhusg(kaZpSFbNwUu1d4C3qnILMiR0lQ57e):
	utRq3sJPvZx1 = nA5dhMRg6ENzsB0l1GwvH7aIr2.join(yFwUm7LgRGa4BhNK6V0SAXedCvMD for yFwUm7LgRGa4BhNK6V0SAXedCvMD in kaZpSFbNwUu1d4C3qnILMiR0lQ57e if yFwUm7LgRGa4BhNK6V0SAXedCvMD not in '\/":*?<>|'+pRYO3SUfqaTdlW4jhrV6xI)
	return utRq3sJPvZx1
def qmgW4xHL875VQrGpas9fcOTiCFyS(QbuYlX5ctHaGp42jNef8):
	p2oAZgRUYeaIVnsByOuNfSGr7TdW4 = PAztbuyYo4Kvd.findall("adilbo_HTML_encoder(.*?)/g.....(.*?)\)",QbuYlX5ctHaGp42jNef8,PAztbuyYo4Kvd.S)
	if p2oAZgRUYeaIVnsByOuNfSGr7TdW4:
		Y9YTW1zAL3B5ecaqGfrPuo7b,zDUWweAvmEkBcKZPjb6nC20OJH = p2oAZgRUYeaIVnsByOuNfSGr7TdW4[IpFcwrWNgefMym3qta0hYQAzOdE]
		Y9YTW1zAL3B5ecaqGfrPuo7b = PAztbuyYo4Kvd.findall("=[\r\n\s\t]+'(.*?)';", Y9YTW1zAL3B5ecaqGfrPuo7b, PAztbuyYo4Kvd.S)[IpFcwrWNgefMym3qta0hYQAzOdE]
		if Y9YTW1zAL3B5ecaqGfrPuo7b and zDUWweAvmEkBcKZPjb6nC20OJH:
			X9bW6ovsEhHwiJ8qOy2 = Y9YTW1zAL3B5ecaqGfrPuo7b.replace("'",nA5dhMRg6ENzsB0l1GwvH7aIr2).replace("+",nA5dhMRg6ENzsB0l1GwvH7aIr2).replace("\n",nA5dhMRg6ENzsB0l1GwvH7aIr2).replace("\r",nA5dhMRg6ENzsB0l1GwvH7aIr2)
			QjRwFxnJXNk = X9bW6ovsEhHwiJ8qOy2.split('.')
			QbuYlX5ctHaGp42jNef8 = nA5dhMRg6ENzsB0l1GwvH7aIr2
			for Mhd61zknlyL3PFJwHNtTX47x0 in QjRwFxnJXNk:
				F8PqO9oGzNIQe5sMEgy3kl2vA6bx = Ic92Lb6lnzM5KJsx4Y3UGa70imZo.b64decode(Mhd61zknlyL3PFJwHNtTX47x0+'==').decode(YWEQ3Cf8RevpD0m7NjF1)
				Tzm7xs2CJk5gLGhi = PAztbuyYo4Kvd.findall('\d+', F8PqO9oGzNIQe5sMEgy3kl2vA6bx, PAztbuyYo4Kvd.S)
				if Tzm7xs2CJk5gLGhi:
					CEqbiDR406HfuyAlwzp = int(Tzm7xs2CJk5gLGhi[IpFcwrWNgefMym3qta0hYQAzOdE])
					CEqbiDR406HfuyAlwzp += int(zDUWweAvmEkBcKZPjb6nC20OJH)
					QbuYlX5ctHaGp42jNef8 = QbuYlX5ctHaGp42jNef8 + chr(CEqbiDR406HfuyAlwzp)
			if BsLJ7p5Av2Vm0SQeCO1o: QbuYlX5ctHaGp42jNef8 = QbuYlX5ctHaGp42jNef8.encode('iso-8859-1').decode(YWEQ3Cf8RevpD0m7NjF1)
	return QbuYlX5ctHaGp42jNef8
def uANakQHcnhR(rj2U9E4KbDMOzpkP,QNwj4Toh3Vk60rfeGyY,RxWJFBAGy4iIM,JEiFBCayPfze7n3KspN6AY,PPblYOcLrJH6QI,xxpGC6WXNdqUolKO,showDialogs,FjO41UWNvs0Gg,Jdc2FbzlVg0uHtALvjWG6nfRKop=nA5dhMRg6ENzsB0l1GwvH7aIr2,MAmJTVeP0CZB=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if '::' in QNwj4Toh3Vk60rfeGyY: QNwj4Toh3Vk60rfeGyY,zzU5PnmRv13toWs4bDFL = QNwj4Toh3Vk60rfeGyY.split('::')
	else: QNwj4Toh3Vk60rfeGyY,zzU5PnmRv13toWs4bDFL = QNwj4Toh3Vk60rfeGyY,''
	KteRnFMjHpBPqNf8,DG5rzEqHLYk4vA1g6lfReChnQTWd3,sebNaroikFVY6hHj7dMZQfInty,jwsCEuO791RtU = MyP7jWmAVGS8rfN51zdqclDeUs(RxWJFBAGy4iIM)
	WMXDKcxozC1vw2sP = PPblYOcLrJH6QI.copy() if isinstance(PPblYOcLrJH6QI,dict) else PPblYOcLrJH6QI
	X5lnUjdopBiE = QNwj4Toh3Vk60rfeGyY,KteRnFMjHpBPqNf8,JEiFBCayPfze7n3KspN6AY,WMXDKcxozC1vw2sP,xxpGC6WXNdqUolKO
	if rj2U9E4KbDMOzpkP<IpFcwrWNgefMym3qta0hYQAzOdE:
		aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,'OPENURL_REQUESTS',X5lnUjdopBiE)
		rj2U9E4KbDMOzpkP = -rj2U9E4KbDMOzpkP
	if rj2U9E4KbDMOzpkP>IpFcwrWNgefMym3qta0hYQAzOdE:
		tkSbvVxf8h1d0gLTci = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,'response','OPENURL_REQUESTS',X5lnUjdopBiE)
		if tkSbvVxf8h1d0gLTci.succeeded:
			zz3SEjnWHCvyoO('REQUESTS  READ_CACHE',KteRnFMjHpBPqNf8,JEiFBCayPfze7n3KspN6AY,PPblYOcLrJH6QI,FjO41UWNvs0Gg,QNwj4Toh3Vk60rfeGyY)
			return tkSbvVxf8h1d0gLTci
	if zzU5PnmRv13toWs4bDFL=='SCRAPERS': tkSbvVxf8h1d0gLTci = U4wtdoh6sePSauql5RjJ9BOCXpNn(QNwj4Toh3Vk60rfeGyY,RxWJFBAGy4iIM,JEiFBCayPfze7n3KspN6AY,PPblYOcLrJH6QI,xxpGC6WXNdqUolKO,showDialogs,FjO41UWNvs0Gg)
	else: tkSbvVxf8h1d0gLTci = p3LnaOYNwmCP8fic(QNwj4Toh3Vk60rfeGyY,RxWJFBAGy4iIM,JEiFBCayPfze7n3KspN6AY,PPblYOcLrJH6QI,xxpGC6WXNdqUolKO,showDialogs,FjO41UWNvs0Gg,Jdc2FbzlVg0uHtALvjWG6nfRKop,MAmJTVeP0CZB)
	if tkSbvVxf8h1d0gLTci.succeeded:
		if 'CIMANOW' in FjO41UWNvs0Gg: tkSbvVxf8h1d0gLTci.content = qmgW4xHL875VQrGpas9fcOTiCFyS(tkSbvVxf8h1d0gLTci.content)
		if tkSbvVxf8h1d0gLTci.scrape: rj2U9E4KbDMOzpkP = OkCUfhKTs9DZbcgnw3roPGBvlqt
		if rj2U9E4KbDMOzpkP and tkSbvVxf8h1d0gLTci.content: WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,'OPENURL_REQUESTS',X5lnUjdopBiE,tkSbvVxf8h1d0gLTci,rj2U9E4KbDMOzpkP)
	return tkSbvVxf8h1d0gLTci
def G4wHJpsE8xlQenf9ro(QNwj4Toh3Vk60rfeGyY,RxWJFBAGy4iIM,data,headers,allow_redirects,showDialogs,FjO41UWNvs0Gg,Jdc2FbzlVg0uHtALvjWG6nfRKop,MAmJTVeP0CZB):
	if data==nA5dhMRg6ENzsB0l1GwvH7aIr2: data = {}
	if headers==nA5dhMRg6ENzsB0l1GwvH7aIr2: headers = {}
	tZMRykpjCAse = S5MWhgtZ37Xw if allow_redirects in [nA5dhMRg6ENzsB0l1GwvH7aIr2,S5MWhgtZ37Xw] else FFKncZx5pDTwdiJRYhMgQSNL
	NNIGPDvUJABZoTba = S5MWhgtZ37Xw if showDialogs in [nA5dhMRg6ENzsB0l1GwvH7aIr2,S5MWhgtZ37Xw] else FFKncZx5pDTwdiJRYhMgQSNL
	I349TF0vrW = S5MWhgtZ37Xw if Jdc2FbzlVg0uHtALvjWG6nfRKop in [nA5dhMRg6ENzsB0l1GwvH7aIr2,S5MWhgtZ37Xw] else FFKncZx5pDTwdiJRYhMgQSNL
	sm7FeVUb1xdw3I9EN2gXWaSl = S5MWhgtZ37Xw if MAmJTVeP0CZB in [nA5dhMRg6ENzsB0l1GwvH7aIr2,S5MWhgtZ37Xw] else FFKncZx5pDTwdiJRYhMgQSNL
	rA4ZGoQyIHlneVfzNukWd = data
	LevQwm0pbqP1 = headers
	NNIGPDvUJABZoTba = NNIGPDvUJABZoTba if Nzp9Fq5cTr.ALLOW_SHOWDIALOGS_FIX==YWylfpKSRb else Nzp9Fq5cTr.ALLOW_SHOWDIALOGS_FIX
	I349TF0vrW = I349TF0vrW if Nzp9Fq5cTr.ALLOW_DNS_FIX==YWylfpKSRb else Nzp9Fq5cTr.ALLOW_DNS_FIX
	sm7FeVUb1xdw3I9EN2gXWaSl = sm7FeVUb1xdw3I9EN2gXWaSl if Nzp9Fq5cTr.ALLOW_PROXY_FIX==YWylfpKSRb else Nzp9Fq5cTr.ALLOW_PROXY_FIX
	if FjO41UWNvs0Gg=='SERVICES-INSTALL_OLD_RELEASE-1st': LevQwm0pbqP1 = {}
	else:
		pNVijKtHFT28r9BZuAg1LJqdI = list(LevQwm0pbqP1.keys())
		if 'Referer' not in pNVijKtHFT28r9BZuAg1LJqdI: LevQwm0pbqP1['Referer'] = 'http'
		if 'User-Agent' not in pNVijKtHFT28r9BZuAg1LJqdI: LevQwm0pbqP1['User-Agent'] = oOb8ZS417GwudNKHU6y(S5MWhgtZ37Xw)
	return QNwj4Toh3Vk60rfeGyY,RxWJFBAGy4iIM,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,tZMRykpjCAse,NNIGPDvUJABZoTba,FjO41UWNvs0Gg,I349TF0vrW,sm7FeVUb1xdw3I9EN2gXWaSl
def p3LnaOYNwmCP8fic(QNwj4Toh3Vk60rfeGyY,RxWJFBAGy4iIM,JEiFBCayPfze7n3KspN6AY,PPblYOcLrJH6QI,xxpGC6WXNdqUolKO,showDialogs,FjO41UWNvs0Gg,Jdc2FbzlVg0uHtALvjWG6nfRKop=nA5dhMRg6ENzsB0l1GwvH7aIr2,MAmJTVeP0CZB=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	gtlFezGU5H1dKi8k = G4wHJpsE8xlQenf9ro(QNwj4Toh3Vk60rfeGyY,RxWJFBAGy4iIM,JEiFBCayPfze7n3KspN6AY,PPblYOcLrJH6QI,xxpGC6WXNdqUolKO,showDialogs,FjO41UWNvs0Gg,Jdc2FbzlVg0uHtALvjWG6nfRKop,MAmJTVeP0CZB)
	QNwj4Toh3Vk60rfeGyY,RxWJFBAGy4iIM,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,tZMRykpjCAse,NNIGPDvUJABZoTba,FjO41UWNvs0Gg,I349TF0vrW,sm7FeVUb1xdw3I9EN2gXWaSl = gtlFezGU5H1dKi8k
	KteRnFMjHpBPqNf8,DG5rzEqHLYk4vA1g6lfReChnQTWd3,sebNaroikFVY6hHj7dMZQfInty,jwsCEuO791RtU = MyP7jWmAVGS8rfN51zdqclDeUs(RxWJFBAGy4iIM)
	idaV8KwMJjWgF5C4N = KQctJbXeEjDhplqknU3rzi.getSetting('av.status.dns')
	PjDfEWbY3p9vLrc2OZw5ltHg7dhRs = KQctJbXeEjDhplqknU3rzi.getSetting('av.status.usedns')
	HT1rEx29SanKZzujMh5ke0Wb = KQctJbXeEjDhplqknU3rzi.getSetting('av.status.useproxy')
	Prj4muZgRx5Sq = ['scrapeops','scraperapi','scrapingant','scrapingrobot','scrapeup','scrape.do']
	sueTPcpiGtj7UhmNorZF = S5MWhgtZ37Xw if any(value in RxWJFBAGy4iIM for value in Prj4muZgRx5Sq) else FFKncZx5pDTwdiJRYhMgQSNL
	if '&url=' in KteRnFMjHpBPqNf8 and sueTPcpiGtj7UhmNorZF: U47iXYESpARe9JPrfCNHGO6 = KteRnFMjHpBPqNf8.rsplit('&url=',UnOIK1WBbw2)[UnOIK1WBbw2]
	else: U47iXYESpARe9JPrfCNHGO6 = nA5dhMRg6ENzsB0l1GwvH7aIr2
	S4HBriDUfgVRLGJxz9dZE71jCe = Nzp9Fq5cTr.SITESURLS['PYTHON']
	F5MUuTCSn4iaxXb6Wc = KteRnFMjHpBPqNf8 in S4HBriDUfgVRLGJxz9dZE71jCe or U47iXYESpARe9JPrfCNHGO6 in S4HBriDUfgVRLGJxz9dZE71jCe
	DM5LjrUAG12whplE = Nzp9Fq5cTr.SITESURLS['REPOS']
	BD10T5OF4hgbVHi = KteRnFMjHpBPqNf8 in DM5LjrUAG12whplE or U47iXYESpARe9JPrfCNHGO6 in DM5LjrUAG12whplE
	pl62ZRdvOM7okcC = F5MUuTCSn4iaxXb6Wc or BD10T5OF4hgbVHi
	DAzNLdxhmycGR9 = FFKncZx5pDTwdiJRYhMgQSNL
	Nad0VQHncz = S5MWhgtZ37Xw
	zznS5RE3t91XeYh = DG5rzEqHLYk4vA1g6lfReChnQTWd3==None and sebNaroikFVY6hHj7dMZQfInty==None and not sueTPcpiGtj7UhmNorZF
	if zznS5RE3t91XeYh and pl62ZRdvOM7okcC:
		if F5MUuTCSn4iaxXb6Wc:
			FG9xiuLqhPTI3yn8JXM2 = S4HBriDUfgVRLGJxz9dZE71jCe.index(KteRnFMjHpBPqNf8)
			Y5ro02b87iqOCDA3GpxdNQefP = Nzp9Fq5cTr.SITESURLS['PYTHON_BKP1'][FG9xiuLqhPTI3yn8JXM2]
			JtZ4Q2RTsk70WGhXdMOCpPbDINx = Nzp9Fq5cTr.SITESURLS['PYTHON_BKP2'][FG9xiuLqhPTI3yn8JXM2]
			OY4mGD0HtxIvNycsVWrpw3JUZLulk = Nzp9Fq5cTr.SITESURLS['PYTHON_BKP3'][FG9xiuLqhPTI3yn8JXM2]
			xzPTbdUKmfL7ly8 = Nzp9Fq5cTr.api_python_actions[FG9xiuLqhPTI3yn8JXM2]
			if xzPTbdUKmfL7ly8=='LISTPLAY': I349TF0vrW,sm7FeVUb1xdw3I9EN2gXWaSl,Nad0VQHncz = FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL
			elif xzPTbdUKmfL7ly8=='CAPTCHA': DAzNLdxhmycGR9 = S5MWhgtZ37Xw
		elif BD10T5OF4hgbVHi:
			FG9xiuLqhPTI3yn8JXM2 = DM5LjrUAG12whplE.index(KteRnFMjHpBPqNf8)
			Y5ro02b87iqOCDA3GpxdNQefP = Nzp9Fq5cTr.SITESURLS['REPOS_BKP1'][FG9xiuLqhPTI3yn8JXM2]
			JtZ4Q2RTsk70WGhXdMOCpPbDINx = Nzp9Fq5cTr.SITESURLS['REPOS_BKP2'][FG9xiuLqhPTI3yn8JXM2]
			OY4mGD0HtxIvNycsVWrpw3JUZLulk = Nzp9Fq5cTr.SITESURLS['REPOS_BKP3'][FG9xiuLqhPTI3yn8JXM2]
			xzPTbdUKmfL7ly8 = Nzp9Fq5cTr.api_repos_actions[FG9xiuLqhPTI3yn8JXM2]
	if sebNaroikFVY6hHj7dMZQfInty==nA5dhMRg6ENzsB0l1GwvH7aIr2: sebNaroikFVY6hHj7dMZQfInty = idaV8KwMJjWgF5C4N
	elif sebNaroikFVY6hHj7dMZQfInty==None and PjDfEWbY3p9vLrc2OZw5ltHg7dhRs in ['AUTO','ACCEPTED'] and I349TF0vrW: sebNaroikFVY6hHj7dMZQfInty = idaV8KwMJjWgF5C4N
	if F5MUuTCSn4iaxXb6Wc or BD10T5OF4hgbVHi: pxnIrsSMzymlvud8ZQaCgTtRJ1DWHe = 15
	elif sueTPcpiGtj7UhmNorZF: pxnIrsSMzymlvud8ZQaCgTtRJ1DWHe = 60
	elif FjO41UWNvs0Gg in TCvP3Y9u5jJlEqG2: pxnIrsSMzymlvud8ZQaCgTtRJ1DWHe = 10
	elif FjO41UWNvs0Gg=='LIBRARY-REVERSO_TRANSLATE-1st': pxnIrsSMzymlvud8ZQaCgTtRJ1DWHe = 20
	elif FjO41UWNvs0Gg=='LIBRARY-GOOGLE_TRANSLATE-1st': pxnIrsSMzymlvud8ZQaCgTtRJ1DWHe = 20
	elif 'RESOLVERS-AKWAM' in FjO41UWNvs0Gg: pxnIrsSMzymlvud8ZQaCgTtRJ1DWHe = 70
	elif 'SHOFHA' in FjO41UWNvs0Gg: pxnIrsSMzymlvud8ZQaCgTtRJ1DWHe = 75
	elif 'CIMA4U' in FjO41UWNvs0Gg: pxnIrsSMzymlvud8ZQaCgTtRJ1DWHe = 25
	elif 'AHWAK' in FjO41UWNvs0Gg: pxnIrsSMzymlvud8ZQaCgTtRJ1DWHe = 20
	elif 'CIMALIGHT' in FjO41UWNvs0Gg: pxnIrsSMzymlvud8ZQaCgTtRJ1DWHe = 20
	elif 'CIMACLUBWORK' in FjO41UWNvs0Gg: pxnIrsSMzymlvud8ZQaCgTtRJ1DWHe = 30
	elif 'AKOAM' in FjO41UWNvs0Gg: pxnIrsSMzymlvud8ZQaCgTtRJ1DWHe = 25
	elif 'AKWAM' in FjO41UWNvs0Gg: pxnIrsSMzymlvud8ZQaCgTtRJ1DWHe = 30
	elif 'FASELHD1' in FjO41UWNvs0Gg: pxnIrsSMzymlvud8ZQaCgTtRJ1DWHe = 20
	elif 'EGYBEST3' in FjO41UWNvs0Gg: pxnIrsSMzymlvud8ZQaCgTtRJ1DWHe = 60
	elif 'HALACIMA' in FjO41UWNvs0Gg: pxnIrsSMzymlvud8ZQaCgTtRJ1DWHe = 40
	else: pxnIrsSMzymlvud8ZQaCgTtRJ1DWHe = 15
	OOmrXyYWt81UBZaI7GA3T2 = (DG5rzEqHLYk4vA1g6lfReChnQTWd3!=None)
	ou2RGcKbfprdYnXaC9 = (sebNaroikFVY6hHj7dMZQfInty!=None and PjDfEWbY3p9vLrc2OZw5ltHg7dhRs!='STOP')
	if OOmrXyYWt81UBZaI7GA3T2 and not sueTPcpiGtj7UhmNorZF: ggYilKR5rMDyp7B('تفعيل بروكسي رقم',DG5rzEqHLYk4vA1g6lfReChnQTWd3)
	elif ou2RGcKbfprdYnXaC9: ggYilKR5rMDyp7B('تفعيل DNS رقم',sebNaroikFVY6hHj7dMZQfInty)
	if OOmrXyYWt81UBZaI7GA3T2:
		l6jBMgq7wnY5Wt9z = {"http":DG5rzEqHLYk4vA1g6lfReChnQTWd3,"https":DG5rzEqHLYk4vA1g6lfReChnQTWd3}
		iTqrojRm7H0PAyOVlkQa3UNX8FeK = DG5rzEqHLYk4vA1g6lfReChnQTWd3
	else: l6jBMgq7wnY5Wt9z,iTqrojRm7H0PAyOVlkQa3UNX8FeK = {},nA5dhMRg6ENzsB0l1GwvH7aIr2
	if ou2RGcKbfprdYnXaC9:
		import urllib3.util.connection as vgAyGYboURP6chTO7iltMCZWxD
		K5alJtTvLm = vvOPrlqIYuAXG(vgAyGYboURP6chTO7iltMCZWxD,idaV8KwMJjWgF5C4N,S5MWhgtZ37Xw)
	FkMur9AsEIXUwpm3eQy0,HKGbumzxgnk87JlLdVvWeS0ZhX,QF6HsoZefWPVzxn,BPXYUsudW12QEm0iNgcOTtojA,OU0P6KcWbQfL4iXGYtCVMIq,JyF75eHfKmv18Wd,verify = tZMRykpjCAse,FjO41UWNvs0Gg,QNwj4Toh3Vk60rfeGyY,FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL,jwsCEuO791RtU
	if DAzNLdxhmycGR9: OU0P6KcWbQfL4iXGYtCVMIq = S5MWhgtZ37Xw
	if pl62ZRdvOM7okcC or tZMRykpjCAse: FkMur9AsEIXUwpm3eQy0 = FFKncZx5pDTwdiJRYhMgQSNL
	if F5MUuTCSn4iaxXb6Wc: QF6HsoZefWPVzxn = 'POST'
	wwzCYnRmoFcxMIHAfB8kiJLOG,YZAKaSrmp57OUEtIXcyv3hoe8RVqWG = -UnOIK1WBbw2,'Unknown Error'
	aXm9nS5BuJFQUf4kqKs6oD = FFKncZx5pDTwdiJRYhMgQSNL
	if not Nzp9Fq5cTr.FORWARDS_HOSTNAMES: Nzp9Fq5cTr.FORWARDS_HOSTNAMES = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,'dict','MISC_TEMP_2','FORWARDS')
	U5betxAT7pLn1Y2VKyQ8Bij = []
	while KteRnFMjHpBPqNf8 not in U5betxAT7pLn1Y2VKyQ8Bij and KteRnFMjHpBPqNf8 in list(Nzp9Fq5cTr.FORWARDS_HOSTNAMES.keys()):
		U5betxAT7pLn1Y2VKyQ8Bij.append(KteRnFMjHpBPqNf8)
		KteRnFMjHpBPqNf8 = Nzp9Fq5cTr.FORWARDS_HOSTNAMES[KteRnFMjHpBPqNf8]
	import requests as xsu2pPbTo9XwU4v0tDO3
	for hsqrMEVB70i2ZnzPHlGYD1oy in range(9):
		zTEXepHg92GkWf = FFKncZx5pDTwdiJRYhMgQSNL
		if hsqrMEVB70i2ZnzPHlGYD1oy:
			HKGbumzxgnk87JlLdVvWeS0ZhX = 'LIBRARY-OPENURL_REQUESTS-1st'
			try: tkSbvVxf8h1d0gLTci.close()
			except: pass
		if sueTPcpiGtj7UhmNorZF or not OOmrXyYWt81UBZaI7GA3T2: zz3SEjnWHCvyoO('REQUESTS\tOPEN_URL',KteRnFMjHpBPqNf8,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,HKGbumzxgnk87JlLdVvWeS0ZhX,QF6HsoZefWPVzxn)
		w7Ol6FnokgJDSsIt = KteRnFMjHpBPqNf8
		try:
			tkSbvVxf8h1d0gLTci = xsu2pPbTo9XwU4v0tDO3.request(QF6HsoZefWPVzxn,KteRnFMjHpBPqNf8,data=rA4ZGoQyIHlneVfzNukWd,headers=LevQwm0pbqP1,verify=verify,allow_redirects=FkMur9AsEIXUwpm3eQy0,timeout=pxnIrsSMzymlvud8ZQaCgTtRJ1DWHe,proxies=l6jBMgq7wnY5Wt9z)
			if 300<=tkSbvVxf8h1d0gLTci.status_code<=399:
				if not BPXYUsudW12QEm0iNgcOTtojA:
					lZbfi5cX0F6xojuMCIJayGOskA = list(tkSbvVxf8h1d0gLTci.headers.keys())
					if 'Location' in lZbfi5cX0F6xojuMCIJayGOskA: KteRnFMjHpBPqNf8 = tkSbvVxf8h1d0gLTci.headers['Location']
					elif 'location' in lZbfi5cX0F6xojuMCIJayGOskA: KteRnFMjHpBPqNf8 = tkSbvVxf8h1d0gLTci.headers['location']
					else: BPXYUsudW12QEm0iNgcOTtojA = S5MWhgtZ37Xw
					if not BPXYUsudW12QEm0iNgcOTtojA: KteRnFMjHpBPqNf8 = KteRnFMjHpBPqNf8.encode('latin-1','ignore').decode(YWEQ3Cf8RevpD0m7NjF1,'ignore')
					if pl62ZRdvOM7okcC and tkSbvVxf8h1d0gLTci.status_code==307:
						FkMur9AsEIXUwpm3eQy0 = tZMRykpjCAse
						QF6HsoZefWPVzxn = QNwj4Toh3Vk60rfeGyY
						BPXYUsudW12QEm0iNgcOTtojA = S5MWhgtZ37Xw
						iwAplnYROITU954M7S
				if not BPXYUsudW12QEm0iNgcOTtojA or tZMRykpjCAse:
					if 'http' not in KteRnFMjHpBPqNf8:
						luqzt3VwT8MaD = C2gnJ5tXFk9pAL(w7Ol6FnokgJDSsIt,'url')
						KteRnFMjHpBPqNf8 = luqzt3VwT8MaD+'/'+KteRnFMjHpBPqNf8.lstrip('/')
				if KteRnFMjHpBPqNf8!=w7Ol6FnokgJDSsIt:
					Nzp9Fq5cTr.FORWARDS_HOSTNAMES[w7Ol6FnokgJDSsIt] = KteRnFMjHpBPqNf8
					aXm9nS5BuJFQUf4kqKs6oD = S5MWhgtZ37Xw
				if not BPXYUsudW12QEm0iNgcOTtojA and tZMRykpjCAse:
					if EbwS0djxcz(KteRnFMjHpBPqNf8): iwAplnYROITU954M7S
					else: continue
			elif 550<=tkSbvVxf8h1d0gLTci.status_code<=599:
				tkSbvVxf8h1d0gLTci.reason = tkSbvVxf8h1d0gLTci.content
				OU0P6KcWbQfL4iXGYtCVMIq = S5MWhgtZ37Xw
			w7Ol6FnokgJDSsIt = tkSbvVxf8h1d0gLTci.url
			wwzCYnRmoFcxMIHAfB8kiJLOG = tkSbvVxf8h1d0gLTci.status_code
			YZAKaSrmp57OUEtIXcyv3hoe8RVqWG = tkSbvVxf8h1d0gLTci.reason
			tkSbvVxf8h1d0gLTci.raise_for_status()
			zTEXepHg92GkWf = S5MWhgtZ37Xw
		except xsu2pPbTo9XwU4v0tDO3.exceptions.HTTPError as f3xe1K6ndi:
			pass
		except xsu2pPbTo9XwU4v0tDO3.exceptions.Timeout as f3xe1K6ndi:
			if cS2NYw4xulqJgvzkMF: YZAKaSrmp57OUEtIXcyv3hoe8RVqWG = str(f3xe1K6ndi.message).split(': ')[UnOIK1WBbw2]
			else: YZAKaSrmp57OUEtIXcyv3hoe8RVqWG = str(f3xe1K6ndi).split(': ')[UnOIK1WBbw2]
		except xsu2pPbTo9XwU4v0tDO3.exceptions.ConnectionError as f3xe1K6ndi:
			try: OM5zCN21ERDn6ydljYpF = f3xe1K6ndi.message[IpFcwrWNgefMym3qta0hYQAzOdE]
			except: OM5zCN21ERDn6ydljYpF = str(f3xe1K6ndi)
			Nhyglk5Ja73x62PzrYTpvdot9H = PAztbuyYo4Kvd.findall("\[Errno (\d+)\] (.*?)'",OM5zCN21ERDn6ydljYpF)
			if not Nhyglk5Ja73x62PzrYTpvdot9H: Nhyglk5Ja73x62PzrYTpvdot9H = PAztbuyYo4Kvd.findall(", error\((\d+), '(.*?)'",OM5zCN21ERDn6ydljYpF)
			if not Nhyglk5Ja73x62PzrYTpvdot9H:
				KhmRpX6ZzfE9 = PAztbuyYo4Kvd.findall(": (.*?):.*?(\d+):",OM5zCN21ERDn6ydljYpF)
				if KhmRpX6ZzfE9: Nhyglk5Ja73x62PzrYTpvdot9H = [KhmRpX6ZzfE9[IpFcwrWNgefMym3qta0hYQAzOdE][UnOIK1WBbw2],KhmRpX6ZzfE9[IpFcwrWNgefMym3qta0hYQAzOdE][IpFcwrWNgefMym3qta0hYQAzOdE]]
			if not Nhyglk5Ja73x62PzrYTpvdot9H: Nhyglk5Ja73x62PzrYTpvdot9H = PAztbuyYo4Kvd.findall(":(\d+): (.*?)'",OM5zCN21ERDn6ydljYpF)
			if not Nhyglk5Ja73x62PzrYTpvdot9H: Nhyglk5Ja73x62PzrYTpvdot9H = PAztbuyYo4Kvd.findall(" (\d+)] (.*?)'",OM5zCN21ERDn6ydljYpF)
			try: wwzCYnRmoFcxMIHAfB8kiJLOG,YZAKaSrmp57OUEtIXcyv3hoe8RVqWG = Nhyglk5Ja73x62PzrYTpvdot9H[IpFcwrWNgefMym3qta0hYQAzOdE]
			except: wwzCYnRmoFcxMIHAfB8kiJLOG,YZAKaSrmp57OUEtIXcyv3hoe8RVqWG = -udq5tP0hwifHQCGYELDbOUI,OM5zCN21ERDn6ydljYpF
		except xsu2pPbTo9XwU4v0tDO3.exceptions.RequestException as f3xe1K6ndi:
			if cS2NYw4xulqJgvzkMF: YZAKaSrmp57OUEtIXcyv3hoe8RVqWG = f3xe1K6ndi.message
			else: YZAKaSrmp57OUEtIXcyv3hoe8RVqWG = str(f3xe1K6ndi)
		except:
			try: wwzCYnRmoFcxMIHAfB8kiJLOG = tkSbvVxf8h1d0gLTci.status_code
			except: pass
			try: YZAKaSrmp57OUEtIXcyv3hoe8RVqWG = tkSbvVxf8h1d0gLTci.reason
			except: pass
		YZAKaSrmp57OUEtIXcyv3hoe8RVqWG = str(YZAKaSrmp57OUEtIXcyv3hoe8RVqWG)
		nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,'OPENURL_REQUESTS\tRESPONSE  Code: [ '+str(wwzCYnRmoFcxMIHAfB8kiJLOG)+' ]   Reason: [ '+YZAKaSrmp57OUEtIXcyv3hoe8RVqWG+' ]   Source: [ '+FjO41UWNvs0Gg+' ]   URL: [ '+RxWJFBAGy4iIM+' ]')
		if zznS5RE3t91XeYh and pl62ZRdvOM7okcC and not OU0P6KcWbQfL4iXGYtCVMIq and wwzCYnRmoFcxMIHAfB8kiJLOG!=200:
			if KteRnFMjHpBPqNf8 not in [Y5ro02b87iqOCDA3GpxdNQefP,JtZ4Q2RTsk70WGhXdMOCpPbDINx,OY4mGD0HtxIvNycsVWrpw3JUZLulk]: KteRnFMjHpBPqNf8,OU0P6KcWbQfL4iXGYtCVMIq = Y5ro02b87iqOCDA3GpxdNQefP,FFKncZx5pDTwdiJRYhMgQSNL
			elif KteRnFMjHpBPqNf8==Y5ro02b87iqOCDA3GpxdNQefP: KteRnFMjHpBPqNf8,OU0P6KcWbQfL4iXGYtCVMIq = JtZ4Q2RTsk70WGhXdMOCpPbDINx,FFKncZx5pDTwdiJRYhMgQSNL
			elif KteRnFMjHpBPqNf8==JtZ4Q2RTsk70WGhXdMOCpPbDINx: KteRnFMjHpBPqNf8,OU0P6KcWbQfL4iXGYtCVMIq = OY4mGD0HtxIvNycsVWrpw3JUZLulk,S5MWhgtZ37Xw
			continue
		break
	wwzCYnRmoFcxMIHAfB8kiJLOG = int(wwzCYnRmoFcxMIHAfB8kiJLOG)
	if not zTEXepHg92GkWf:
		WdnJVMgSm0pDvhawITN5Xosq = e1MtrcQ06UEH('1.1.1.1',80)
		if WdnJVMgSm0pDvhawITN5Xosq==-UnOIK1WBbw2:
			nhR0UxwS4yDiABj7V1G8la(ybrna7mLOFVDUtRseQ3Tkf2zXS,'OPENURL_REQUESTS   DISCONNECTED   The device is not connected to the internet !!')
			OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'للأسف جهازك غير مربوط بالإنترنت .. أو غير قادر أن يستخدم الإنترنت .. أو إعدادات جهازك غير صحيحة \n\n لحل المشكلة تأكد أن جهازك مربوط بطريقة صحيحة بالإنترنت وفيه الإنترنت تعمل بصورة جيدة')
			OeR9Dyin6a4hK5VvFMBo()
			return tkSbvVxf8h1d0gLTci
	if not zTEXepHg92GkWf and U5betxAT7pLn1Y2VKyQ8Bij:
		for url in U5betxAT7pLn1Y2VKyQ8Bij:
			if url in list(Nzp9Fq5cTr.FORWARDS_HOSTNAMES.keys()):
				del Nzp9Fq5cTr.FORWARDS_HOSTNAMES[url]
				aXm9nS5BuJFQUf4kqKs6oD = S5MWhgtZ37Xw
	if aXm9nS5BuJFQUf4kqKs6oD:
		WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,'MISC_TEMP_2','FORWARDS',Nzp9Fq5cTr.FORWARDS_HOSTNAMES,OkCUfhKTs9DZbcgnw3roPGBvlqt)
		Nzp9Fq5cTr.FORWARDS_HOSTNAMES = {}
	if sebNaroikFVY6hHj7dMZQfInty!=None and PjDfEWbY3p9vLrc2OZw5ltHg7dhRs!='STOP': vgAyGYboURP6chTO7iltMCZWxD.create_connection = K5alJtTvLm
	if PjDfEWbY3p9vLrc2OZw5ltHg7dhRs=='ALWAYS' and I349TF0vrW: sebNaroikFVY6hHj7dMZQfInty = None
	if not zTEXepHg92GkWf and DG5rzEqHLYk4vA1g6lfReChnQTWd3==None and FjO41UWNvs0Gg not in TCvP3Y9u5jJlEqG2:
		ZZcxIq8bHKnPy2VREUMFG = G7QdMkY6Rr.format_exc()
		if ZZcxIq8bHKnPy2VREUMFG!='NoneType: None\n': kCNHMOym1luTnJ0.stderr.write(ZZcxIq8bHKnPy2VREUMFG)
	YakdN895mSD2uXRCBfWspJhIxV3L = aIh6GTlW0973UgY()
	if sueTPcpiGtj7UhmNorZF: w7Ol6FnokgJDSsIt = U47iXYESpARe9JPrfCNHGO6
	if not w7Ol6FnokgJDSsIt: w7Ol6FnokgJDSsIt = KteRnFMjHpBPqNf8
	YakdN895mSD2uXRCBfWspJhIxV3L.url = w7Ol6FnokgJDSsIt
	YakdN895mSD2uXRCBfWspJhIxV3L.scrape = sueTPcpiGtj7UhmNorZF
	try: rrkXjutz7iRhZaFxKbD = tkSbvVxf8h1d0gLTci.content
	except: rrkXjutz7iRhZaFxKbD = nA5dhMRg6ENzsB0l1GwvH7aIr2
	try: vmiAf0lZHsLVbKUPJgRq5cDoxC2ae = tkSbvVxf8h1d0gLTci.headers
	except: vmiAf0lZHsLVbKUPJgRq5cDoxC2ae = {}
	try: Dco6nBUXPGFaHdO3bT0 = tkSbvVxf8h1d0gLTci.cookies.get_dict()
	except: Dco6nBUXPGFaHdO3bT0 = {}
	try: tkSbvVxf8h1d0gLTci.close()
	except: pass
	if BsLJ7p5Av2Vm0SQeCO1o:
		try: rrkXjutz7iRhZaFxKbD = rrkXjutz7iRhZaFxKbD.decode(YWEQ3Cf8RevpD0m7NjF1)
		except: pass
	YakdN895mSD2uXRCBfWspJhIxV3L.code = wwzCYnRmoFcxMIHAfB8kiJLOG
	YakdN895mSD2uXRCBfWspJhIxV3L.reason = YZAKaSrmp57OUEtIXcyv3hoe8RVqWG
	YakdN895mSD2uXRCBfWspJhIxV3L.content = rrkXjutz7iRhZaFxKbD
	YakdN895mSD2uXRCBfWspJhIxV3L.headers = vmiAf0lZHsLVbKUPJgRq5cDoxC2ae
	YakdN895mSD2uXRCBfWspJhIxV3L.cookies = Dco6nBUXPGFaHdO3bT0
	YakdN895mSD2uXRCBfWspJhIxV3L.succeeded = zTEXepHg92GkWf
	YakdN895mSD2uXRCBfWspJhIxV3L.scrapernumber = nA5dhMRg6ENzsB0l1GwvH7aIr2
	YakdN895mSD2uXRCBfWspJhIxV3L.scraperserver = nA5dhMRg6ENzsB0l1GwvH7aIr2
	YakdN895mSD2uXRCBfWspJhIxV3L.scraperurl = nA5dhMRg6ENzsB0l1GwvH7aIr2
	if cS2NYw4xulqJgvzkMF or isinstance(YakdN895mSD2uXRCBfWspJhIxV3L.content,str): FShkxQ1H8PO5WJ07 = YakdN895mSD2uXRCBfWspJhIxV3L.content.lower()
	else: FShkxQ1H8PO5WJ07 = nA5dhMRg6ENzsB0l1GwvH7aIr2
	DlpFSrMqI59h = ('cloudflare' in FShkxQ1H8PO5WJ07 or 'google' in FShkxQ1H8PO5WJ07) and FShkxQ1H8PO5WJ07.count('recaptcha')>udq5tP0hwifHQCGYELDbOUI and 'FASELHD1' not in FjO41UWNvs0Gg and 'recaptcha-token' not in FShkxQ1H8PO5WJ07 and not sueTPcpiGtj7UhmNorZF
	lCx3tZon1aLgc7IMwS4BKHOe = ('verify.html?redirect=' in w7Ol6FnokgJDSsIt)
	if wwzCYnRmoFcxMIHAfB8kiJLOG==200 and (DlpFSrMqI59h or lCx3tZon1aLgc7IMwS4BKHOe):
		YakdN895mSD2uXRCBfWspJhIxV3L.succeeded = FFKncZx5pDTwdiJRYhMgQSNL
	if YakdN895mSD2uXRCBfWspJhIxV3L.succeeded and zznS5RE3t91XeYh and pl62ZRdvOM7okcC:
		MPAamFNWTvj82 = 'CAPTCHA'+rA4ZGoQyIHlneVfzNukWd['job'].upper().replace('GET',nA5dhMRg6ENzsB0l1GwvH7aIr2) if DAzNLdxhmycGR9 else xzPTbdUKmfL7ly8
		QHCysKvD58UIb930e2(MPAamFNWTvj82)
	if not YakdN895mSD2uXRCBfWspJhIxV3L.succeeded and zznS5RE3t91XeYh:
		D7DteBEYizwmqPrLFc0SKosVp = ('cloudflare' in FShkxQ1H8PO5WJ07 and 'ray id: ' in FShkxQ1H8PO5WJ07)
		orETKUBnt8uYe6 = ('5 sec' in FShkxQ1H8PO5WJ07 and 'browser' in FShkxQ1H8PO5WJ07)
		V9RJLGro0P = (wwzCYnRmoFcxMIHAfB8kiJLOG in [403] and 'error code: 1020' in FShkxQ1H8PO5WJ07)
		IzgiPY3r4M7OsQvVy9EcqaxRmjCNF = ('_cf_chl_' in FShkxQ1H8PO5WJ07 and 'challenge-' in FShkxQ1H8PO5WJ07)
		kkIgyWNlumJhs7CfeZr2 = ('WRONG_VERSION_NUMBER' in YZAKaSrmp57OUEtIXcyv3hoe8RVqWG or 'wrong version number' in YZAKaSrmp57OUEtIXcyv3hoe8RVqWG)
		if   DlpFSrMqI59h: YZAKaSrmp57OUEtIXcyv3hoe8RVqWG = 'Blocked by recaptcha'
		elif D7DteBEYizwmqPrLFc0SKosVp: YZAKaSrmp57OUEtIXcyv3hoe8RVqWG = 'Blocked by cloudflare'
		elif orETKUBnt8uYe6: YZAKaSrmp57OUEtIXcyv3hoe8RVqWG = 'Blocked by 5 seconds browser check'
		elif V9RJLGro0P: YZAKaSrmp57OUEtIXcyv3hoe8RVqWG = 'Blocked by cloudflare access denied'
		elif IzgiPY3r4M7OsQvVy9EcqaxRmjCNF: YZAKaSrmp57OUEtIXcyv3hoe8RVqWG = 'Blocked by cloudflare security check'
		elif lCx3tZon1aLgc7IMwS4BKHOe: YZAKaSrmp57OUEtIXcyv3hoe8RVqWG = 'Blocked by missing javascript check'
		elif kkIgyWNlumJhs7CfeZr2: YZAKaSrmp57OUEtIXcyv3hoe8RVqWG = 'Blocked by your network devices'
		else: YZAKaSrmp57OUEtIXcyv3hoe8RVqWG = str(YZAKaSrmp57OUEtIXcyv3hoe8RVqWG)
		if FjO41UWNvs0Gg in JFvYcXxr9hUDI0NkWs: pass
		elif FjO41UWNvs0Gg in TCvP3Y9u5jJlEqG2:
			nhR0UxwS4yDiABj7V1G8la(ybrna7mLOFVDUtRseQ3Tkf2zXS,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+'  Direct connection failed   Code: [ '+str(wwzCYnRmoFcxMIHAfB8kiJLOG)+' ]   Reason: [ '+YZAKaSrmp57OUEtIXcyv3hoe8RVqWG+' ]   Source: [ '+FjO41UWNvs0Gg+' ]   URL: [ '+KteRnFMjHpBPqNf8+' ]')
		else: nhR0UxwS4yDiABj7V1G8la(ybrna7mLOFVDUtRseQ3Tkf2zXS,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+'   Direct connection failed   Code: [ '+str(wwzCYnRmoFcxMIHAfB8kiJLOG)+' ]   Reason: [ '+YZAKaSrmp57OUEtIXcyv3hoe8RVqWG+' ]   Source: [ '+FjO41UWNvs0Gg+' ]   URL: [ '+KteRnFMjHpBPqNf8+' ]')
		xz9Wj1eLct4qGUAHO2S7upi = U47iXYESpARe9JPrfCNHGO6 if sueTPcpiGtj7UhmNorZF else pvOytL0nF7JY6flXTxAcHbQeNahu3(KteRnFMjHpBPqNf8)
		if cS2NYw4xulqJgvzkMF and isinstance(xz9Wj1eLct4qGUAHO2S7upi,unicode): xz9Wj1eLct4qGUAHO2S7upi = xz9Wj1eLct4qGUAHO2S7upi.encode(YWEQ3Cf8RevpD0m7NjF1)
		if pl62ZRdvOM7okcC: xz9Wj1eLct4qGUAHO2S7upi = xz9Wj1eLct4qGUAHO2S7upi.split('/')[-UnOIK1WBbw2]
		Gxzjuy8tCk6QOmD4aM9 = str(YZAKaSrmp57OUEtIXcyv3hoe8RVqWG)+'\n('+xz9Wj1eLct4qGUAHO2S7upi+')'
		if any([DlpFSrMqI59h,D7DteBEYizwmqPrLFc0SKosVp,orETKUBnt8uYe6,V9RJLGro0P,IzgiPY3r4M7OsQvVy9EcqaxRmjCNF,lCx3tZon1aLgc7IMwS4BKHOe,kkIgyWNlumJhs7CfeZr2]) and sm7FeVUb1xdw3I9EN2gXWaSl:
			if not kkIgyWNlumJhs7CfeZr2:
				YakdN895mSD2uXRCBfWspJhIxV3L.code = -AH0zdvBqibaXY
				bGdRfELvrTJZYD8u5I7sq4X1HOpFWw = 'هذه الصفحة لا يمكن جلبها من الإنترنت الخاص بك .. لأن عليها نوع من الحجب يمنع برامج الكومبيوتر من جلب وفتح واستخدام هذا النوع من الصفحات .. برنامج عماد يستطيع أن يحاول استخدام إنترنت أخرى لتجاوز هذا الحجب .. لكن لا يوجد ضمان أن هذه المحاولة سوف تنجح\n'+lSWzOYmN08+'Error Code:  '+str(YakdN895mSD2uXRCBfWspJhIxV3L.code)+NwROdSj3nsA+CXtugbqhV3+bbTCMJwEx8nhN4X+'هل تريد من برنامج عماد أن يحاول تجاوز هذا الحجب ؟!'+NwROdSj3nsA
			else:
				YakdN895mSD2uXRCBfWspJhIxV3L.code = -tpMX1Bgs0bzv8OEafyW
				bGdRfELvrTJZYD8u5I7sq4X1HOpFWw = 'لديك مشكلة في الإنترنت تمنع فتح بعض صفحات الإنترنت الضرورية .. هذه المشكلة قد تكون من الراوتر عندك أو من برنامج عندك أو من جهاز عندك .. وظيفته الحماية ضد الفيروسات أو ضد التجسس أو ضد البرامج المؤذية .. لحل المشكلة يجب إيقاف هذه الحماية الخاطئة\n'+lSWzOYmN08+'Error Code:  '+str(YakdN895mSD2uXRCBfWspJhIxV3L.code)+NwROdSj3nsA+CXtugbqhV3+bbTCMJwEx8nhN4X+'هل تريد من برنامج عماد أن يحاول استخدام إنترنت أخرى لتجاوز هذه الحماية ؟!'+NwROdSj3nsA
			x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,bGdRfELvrTJZYD8u5I7sq4X1HOpFWw)
			if x6zlf2tTZm:
				qqQUL1k7bGnjc = U4wtdoh6sePSauql5RjJ9BOCXpNn(QNwj4Toh3Vk60rfeGyY,KteRnFMjHpBPqNf8,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,tZMRykpjCAse,NNIGPDvUJABZoTba,FjO41UWNvs0Gg,wwzCYnRmoFcxMIHAfB8kiJLOG,YZAKaSrmp57OUEtIXcyv3hoe8RVqWG)
				if qqQUL1k7bGnjc.succeeded: return qqQUL1k7bGnjc
		x6zlf2tTZm = S5MWhgtZ37Xw
		if (PjDfEWbY3p9vLrc2OZw5ltHg7dhRs=='ASK' or HT1rEx29SanKZzujMh5ke0Wb=='ASK') and (I349TF0vrW or sm7FeVUb1xdw3I9EN2gXWaSl):
			x6zlf2tTZm = zeQigAm1b0BcNFnf8kDJU7HuShl(wwzCYnRmoFcxMIHAfB8kiJLOG,Gxzjuy8tCk6QOmD4aM9,FjO41UWNvs0Gg,NNIGPDvUJABZoTba)
			if x6zlf2tTZm and PjDfEWbY3p9vLrc2OZw5ltHg7dhRs=='ASK': PjDfEWbY3p9vLrc2OZw5ltHg7dhRs = 'ACCEPTED'
			else: PjDfEWbY3p9vLrc2OZw5ltHg7dhRs = 'REJECTED'
			if x6zlf2tTZm and HT1rEx29SanKZzujMh5ke0Wb=='ASK': HT1rEx29SanKZzujMh5ke0Wb = 'ACCEPTED'
			else: HT1rEx29SanKZzujMh5ke0Wb = 'REJECTED'
			KQctJbXeEjDhplqknU3rzi.setSetting('av.status.usedns',PjDfEWbY3p9vLrc2OZw5ltHg7dhRs)
			KQctJbXeEjDhplqknU3rzi.setSetting('av.status.useproxy',HT1rEx29SanKZzujMh5ke0Wb)
		if x6zlf2tTZm:
			if wwzCYnRmoFcxMIHAfB8kiJLOG==8 and 'https' in KteRnFMjHpBPqNf8 and Nad0VQHncz:
				if NNIGPDvUJABZoTba: ggYilKR5rMDyp7B('تفعيل فحص شهادة التشفير SSL','لإصلاح مشكلة الإنترنيت',h0skHe7TcIY9x1UP5VBrZAE8dKGnl=2000)
				w7Ol6FnokgJDSsIt = KteRnFMjHpBPqNf8+'||NoVerifySSL'
				kvste1oOZacAIpb2 = p3LnaOYNwmCP8fic(QNwj4Toh3Vk60rfeGyY,w7Ol6FnokgJDSsIt,JEiFBCayPfze7n3KspN6AY,PPblYOcLrJH6QI,xxpGC6WXNdqUolKO,NNIGPDvUJABZoTba,'LIBRARY-OPENURL_REQUESTS-2nd')
				if kvste1oOZacAIpb2.succeeded:
					YakdN895mSD2uXRCBfWspJhIxV3L = kvste1oOZacAIpb2
					nhR0UxwS4yDiABj7V1G8la(hhOuTCDWIJe7SQPrcKVgF8ZN1qYEz,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+'   Succeeded using SSL:   Source: [ '+FjO41UWNvs0Gg+' ]   URL: [ '+RxWJFBAGy4iIM+' ]')
					if NNIGPDvUJABZoTba: ggYilKR5rMDyp7B('نجاح باستخدام SSL','لإصلاح مشكلة الإنترنيت',h0skHe7TcIY9x1UP5VBrZAE8dKGnl=2000)
				else:
					nhR0UxwS4yDiABj7V1G8la(ybrna7mLOFVDUtRseQ3Tkf2zXS,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+'   Failed using SSL:   Source: [ '+FjO41UWNvs0Gg+' ]   URL: [ '+RxWJFBAGy4iIM+' ]')
					if NNIGPDvUJABZoTba: ggYilKR5rMDyp7B('فشل باستخدام SSL','لإصلاح مشكلة الإنترنيت',h0skHe7TcIY9x1UP5VBrZAE8dKGnl=2000)
			if not YakdN895mSD2uXRCBfWspJhIxV3L.succeeded and HT1rEx29SanKZzujMh5ke0Wb in ['AUTO','ACCEPTED'] and sm7FeVUb1xdw3I9EN2gXWaSl:
				if NNIGPDvUJABZoTba: ggYilKR5rMDyp7B('تفعيل سيرفرات بروكسي','لإصلاح مشكلة الإنترنيت',h0skHe7TcIY9x1UP5VBrZAE8dKGnl=2000)
				kvste1oOZacAIpb2 = U7iZw8CKDBE0GovjHWz6T1LxpXNk(QNwj4Toh3Vk60rfeGyY,KteRnFMjHpBPqNf8,JEiFBCayPfze7n3KspN6AY,PPblYOcLrJH6QI,xxpGC6WXNdqUolKO,NNIGPDvUJABZoTba,FjO41UWNvs0Gg)
				if kvste1oOZacAIpb2.succeeded:
					YakdN895mSD2uXRCBfWspJhIxV3L = kvste1oOZacAIpb2
					nhR0UxwS4yDiABj7V1G8la(hhOuTCDWIJe7SQPrcKVgF8ZN1qYEz,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+'   Proxies succeeded:   Source: [ '+FjO41UWNvs0Gg+' ]   URL: [ '+RxWJFBAGy4iIM+' ]')
					if NNIGPDvUJABZoTba: ggYilKR5rMDyp7B('نجاح سيرفرات بروكسي','لإصلاح مشكلة الإنترنيت',h0skHe7TcIY9x1UP5VBrZAE8dKGnl=2000)
				else:
					nhR0UxwS4yDiABj7V1G8la(ybrna7mLOFVDUtRseQ3Tkf2zXS,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+'   Proxies failed:   Source: [ '+FjO41UWNvs0Gg+' ]   URL: [ '+RxWJFBAGy4iIM+' ]')
					if NNIGPDvUJABZoTba: ggYilKR5rMDyp7B('فشل سيرفرات بروكسي','لإصلاح مشكلة الإنترنيت',h0skHe7TcIY9x1UP5VBrZAE8dKGnl=2000)
			if not YakdN895mSD2uXRCBfWspJhIxV3L.succeeded and PjDfEWbY3p9vLrc2OZw5ltHg7dhRs in ['AUTO','ACCEPTED'] and I349TF0vrW:
				if NNIGPDvUJABZoTba: ggYilKR5rMDyp7B('تفعيل سيرفر DNS','لإصلاح مشكلة الإنترنيت',h0skHe7TcIY9x1UP5VBrZAE8dKGnl=2000)
				w7Ol6FnokgJDSsIt = KteRnFMjHpBPqNf8+'||MyDNSUrl='
				kvste1oOZacAIpb2 = p3LnaOYNwmCP8fic(QNwj4Toh3Vk60rfeGyY,w7Ol6FnokgJDSsIt,JEiFBCayPfze7n3KspN6AY,PPblYOcLrJH6QI,xxpGC6WXNdqUolKO,NNIGPDvUJABZoTba,'LIBRARY-OPENURL_REQUESTS-4th')
				if kvste1oOZacAIpb2.succeeded:
					YakdN895mSD2uXRCBfWspJhIxV3L = kvste1oOZacAIpb2
					nhR0UxwS4yDiABj7V1G8la(hhOuTCDWIJe7SQPrcKVgF8ZN1qYEz,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+'   DNS succeeded:   DNS: [ '+idaV8KwMJjWgF5C4N+' ]   Source: [ '+FjO41UWNvs0Gg+' ]   URL: [ '+RxWJFBAGy4iIM+' ]')
					if NNIGPDvUJABZoTba: ggYilKR5rMDyp7B('نجاح سيرفر DNS','لإصلاح مشكلة الإنترنيت',h0skHe7TcIY9x1UP5VBrZAE8dKGnl=2000)
				else:
					nhR0UxwS4yDiABj7V1G8la(ybrna7mLOFVDUtRseQ3Tkf2zXS,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+'   DNS failed:   DNS: [ '+idaV8KwMJjWgF5C4N+' ]   Source: [ '+FjO41UWNvs0Gg+' ]   URL: [ '+RxWJFBAGy4iIM+' ]')
					if NNIGPDvUJABZoTba: ggYilKR5rMDyp7B('فشل سيرفر DNS','لإصلاح مشكلة الإنترنيت',h0skHe7TcIY9x1UP5VBrZAE8dKGnl=2000)
		if HT1rEx29SanKZzujMh5ke0Wb=='REJECTED' or PjDfEWbY3p9vLrc2OZw5ltHg7dhRs=='REJECTED': NNIGPDvUJABZoTba = FFKncZx5pDTwdiJRYhMgQSNL
		if not YakdN895mSD2uXRCBfWspJhIxV3L.succeeded:
			if NNIGPDvUJABZoTba: auCGNHjFTqPWdwJiQ4cDfnS = zeQigAm1b0BcNFnf8kDJU7HuShl(wwzCYnRmoFcxMIHAfB8kiJLOG,Gxzjuy8tCk6QOmD4aM9,FjO41UWNvs0Gg,NNIGPDvUJABZoTba)
			if YakdN895mSD2uXRCBfWspJhIxV3L.code!=200 and FjO41UWNvs0Gg not in DYbV1egIdWwQN840zoLsrnhmB7 and 'RESOLVERS-' not in FjO41UWNvs0Gg: OeR9Dyin6a4hK5VvFMBo()
	if KQctJbXeEjDhplqknU3rzi.getSetting('av.status.usedns') not in ['AUTO','STOP','ASK']: KQctJbXeEjDhplqknU3rzi.setSetting('av.status.usedns','ASK')
	if KQctJbXeEjDhplqknU3rzi.getSetting('av.status.useproxy') not in ['AUTO','STOP','ASK']: KQctJbXeEjDhplqknU3rzi.setSetting('av.status.useproxy','ASK')
	return YakdN895mSD2uXRCBfWspJhIxV3L
def w59lKDhpOYZm(aoD3bFQiButV50LwGnhkRszJSm7):
	g4whnoOlMRyQeG,tE0Sv5XxqW = nA5dhMRg6ENzsB0l1GwvH7aIr2,FFKncZx5pDTwdiJRYhMgQSNL
	if aoD3bFQiButV50LwGnhkRszJSm7: g4whnoOlMRyQeG = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,'str','MISC_TEMP_2','EXTRAPYTHONCODE')
	if not g4whnoOlMRyQeG:
		RxWJFBAGy4iIM = Nzp9Fq5cTr.SITESURLS['PYTHON'][9]
		S0adTZ3gA7vexpiNfPJt2mVKuURM = {'user':Nzp9Fq5cTr.AV_CLIENT_IDS,'version':s5WcxEPjUBokapYMhAwb60dvgi}
		g4whnoOlMRyQeG = YWgBqcEwA5NSUv('POST',RxWJFBAGy4iIM,S0adTZ3gA7vexpiNfPJt2mVKuURM,nA5dhMRg6ENzsB0l1GwvH7aIr2,'LIBRARY-EXTRA_PYTHON_CODE-1st')
		QHCysKvD58UIb930e2(Nzp9Fq5cTr.api_python_actions[9])
		if g4whnoOlMRyQeG: WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,'MISC_TEMP_2','EXTRAPYTHONCODE',g4whnoOlMRyQeG,l7ltVNxrbPimpXJDh)
		tE0Sv5XxqW = S5MWhgtZ37Xw
	if g4whnoOlMRyQeG:
		global NEW_SITESURLS,NEW_BADSCRAPERS,NEW_BADWEBSITES,NEW_BADCOMMONIDS
		exec(g4whnoOlMRyQeG,globals(),locals())
		Nzp9Fq5cTr.SITESURLS.update(NEW_SITESURLS)
		Nzp9Fq5cTr.BADSCRAPERS = list(set(Nzp9Fq5cTr.BADSCRAPERS+NEW_BADSCRAPERS))
		Nzp9Fq5cTr.BADCOMMONIDS = list(set(Nzp9Fq5cTr.BADCOMMONIDS+NEW_BADCOMMONIDS))
		if s5WcxEPjUBokapYMhAwb60dvgi in list(NEW_BADWEBSITES.keys()): Nzp9Fq5cTr.BADWEBSITES += NEW_BADWEBSITES[s5WcxEPjUBokapYMhAwb60dvgi]
	return tE0Sv5XxqW
def HPgrAYaGEqe2(zzU5PnmRv13toWs4bDFL,B7n3L9yPx54v,RxWJFBAGy4iIM,No03nbgziMqjZ,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4,rzKxlyoWwpQHZiObUdPm35,nI9bERJkQPWOfV0,zTEXepHg92GkWf,EBZLyUM8S37uNqlcA,uzchXbN4SQLm6riG1E):
	H5HSWurzPl = int(rzKxlyoWwpQHZiObUdPm35%10)
	HXq9bKhZ8c4SxY2iA = int(rzKxlyoWwpQHZiObUdPm35/10)
	r6J2iNjQAhH9PI7bauMy = zzU5PnmRv13toWs4bDFL,B7n3L9yPx54v,RxWJFBAGy4iIM,No03nbgziMqjZ,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8,nA5dhMRg6ENzsB0l1GwvH7aIr2,Xxcm31HuozfbJEAv8Rl7PwUgGBF4
	N0IdRQ8lsWFhiSTXG1pZ4u = KQctJbXeEjDhplqknU3rzi.getSetting('av.status.menuscache')
	if not N0IdRQ8lsWFhiSTXG1pZ4u: KQctJbXeEjDhplqknU3rzi.setSetting('av.status.menuscache','AUTO')
	rFj1gkWuXpTniOeKAl9VN = KQctJbXeEjDhplqknU3rzi.getSetting('av.status.refresh')
	ByuFsZxqG3NTIQ54f9CPclLVS = CRV3tDJ6gNczqXF7Z8jnvH1kh(nI9bERJkQPWOfV0)
	f49v8VtAYGu1hMFs2zXxDqcalL0j = [IpFcwrWNgefMym3qta0hYQAzOdE,15,17,19,26,34,50,53]
	CXmwLjEqdG4icBy = HXq9bKhZ8c4SxY2iA not in f49v8VtAYGu1hMFs2zXxDqcalL0j
	w0oIP29kE6n5VfMt = HXq9bKhZ8c4SxY2iA in [23,28,71,72]
	Nmg2DS0kTr = rzKxlyoWwpQHZiObUdPm35 in [265,270]
	cF4NrO9XMWIBL2Ri3Adzsvqyel = (CXmwLjEqdG4icBy or w0oIP29kE6n5VfMt) and not Nmg2DS0kTr
	nrsfGi1BtcWpv2QP = (rFj1gkWuXpTniOeKAl9VN or not kSqp7Ua0gATvrXG2RFdzN) and rFj1gkWuXpTniOeKAl9VN not in ['REFRESH_CACHE']+Jf3OFEMHvK9mBXxnc5
	uxkZtArBFe4y23OHiLf1GcoDhN = 'type=' in rFj1gkWuXpTniOeKAl9VN
	lPh2SwNp9v = rzKxlyoWwpQHZiObUdPm35 in [161,162,163,164,165,166,167,168,761,762,763,764,765]
	WULrxiSjG3d1Cemza7Kc = H5HSWurzPl==9 or rzKxlyoWwpQHZiObUdPm35 in [145,516,523,45]
	jy86azdusIfCwGeE0iDroUN9nl = not lPh2SwNp9v
	R7ftgCuNlvcDopr9qYGO6HZw8ah2S = not WULrxiSjG3d1Cemza7Kc
	YM9LsBl3xkq51jJ0AFTIg4NC = ByuFsZxqG3NTIQ54f9CPclLVS in [nA5dhMRg6ENzsB0l1GwvH7aIr2,'..']
	nbP9Si816qAjdcE = YM9LsBl3xkq51jJ0AFTIg4NC or jy86azdusIfCwGeE0iDroUN9nl
	l04iMgn8N5BxAyVqjv6JU = YM9LsBl3xkq51jJ0AFTIg4NC or R7ftgCuNlvcDopr9qYGO6HZw8ah2S or uxkZtArBFe4y23OHiLf1GcoDhN
	RRg51fWoQy0M9b7 = rzKxlyoWwpQHZiObUdPm35 not in [260,261,265,270,330,536,540,1010]
	if N0IdRQ8lsWFhiSTXG1pZ4u=='STOP': CMyFNihBVn = WULrxiSjG3d1Cemza7Kc or lPh2SwNp9v
	else: CMyFNihBVn = S5MWhgtZ37Xw
	Anbm9wdl2VaCxQ4cMYr18E = HXq9bKhZ8c4SxY2iA in [74,75,108]
	p6JXH2LFiZb9rDaxgNzBwyTVAdmG = rzKxlyoWwpQHZiObUdPm35 in [280,720]
	NHEan8rgUq = not Anbm9wdl2VaCxQ4cMYr18E and not p6JXH2LFiZb9rDaxgNzBwyTVAdmG
	sf9Gi0U5b3lDNrtwkE = nbP9Si816qAjdcE and l04iMgn8N5BxAyVqjv6JU and RRg51fWoQy0M9b7 and CMyFNihBVn and NHEan8rgUq
	gxF2p1ks3SLGDblB6hUY9HeWwr = RRg51fWoQy0M9b7 and CMyFNihBVn and NHEan8rgUq
	dKCXFM0cQe = gxF2p1ks3SLGDblB6hUY9HeWwr
	fL9XNQajnw53gsU1eyxk08FPl = KQctJbXeEjDhplqknU3rzi.getSetting('av.language.provider')
	GRLQr9gC26iol4HIupkbvAW0BdVN5s = KQctJbXeEjDhplqknU3rzi.getSetting('av.language.code')
	FCwVmbUj6gGNkWrvayhIKo = FFKncZx5pDTwdiJRYhMgQSNL
	if nrsfGi1BtcWpv2QP and sf9Gi0U5b3lDNrtwkE:
		a9DVIdhsHUGrA67iujWZowNSl3MfKP = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,'list','MENUS_CACHE_'+fL9XNQajnw53gsU1eyxk08FPl+'_'+GRLQr9gC26iol4HIupkbvAW0BdVN5s,r6J2iNjQAhH9PI7bauMy)
		if a9DVIdhsHUGrA67iujWZowNSl3MfKP:
			nhR0UxwS4yDiABj7V1G8la(nA5dhMRg6ENzsB0l1GwvH7aIr2,'.\tMENUS_CACHE_'+fL9XNQajnw53gsU1eyxk08FPl+'_'+GRLQr9gC26iol4HIupkbvAW0BdVN5s+'   Loading menu from cache')
			if uxkZtArBFe4y23OHiLf1GcoDhN:
				cjnMe69wLxd = []
				from UdES5ZYF1g import avDUSb8uhRF6JEXgsM
				from FjdxIzi5Pr import yTZ8tkWLshpjMK1fJ,yHmCRPvKgaIOdJnGTf6Dk8N7us0qW9
				jM8rgt21kBcd4wiZFfT6 = avDUSb8uhRF6JEXgsM
				pRJYBGh9HX0dxn = yTZ8tkWLshpjMK1fJ()
				TXiykGm7dAML = rFj1gkWuXpTniOeKAl9VN
				ow1vOEbVgl0KkeARd5zNGaI4hSQ,BBFZlctxLJwvYIWT0RahyOdK7bug4,wJojUny9Wp5INatB4eqikHVc,lou1bKpxSIL4RBD7faGmniQ8J3,I67jRFmCZW5yEBnqxwd0Tbsa,esAxYrVLPz7RJchkKHTSE6,Lpu8jv6FZf4Ab5GeQJmnqWIPHYstx,idTPZNmY7grv4t,d3fuH2STqpD = boLfu8ilHFRek4ECO9GZ(TXiykGm7dAML)
				cIuUM48R1jy = ow1vOEbVgl0KkeARd5zNGaI4hSQ,BBFZlctxLJwvYIWT0RahyOdK7bug4,wJojUny9Wp5INatB4eqikHVc,lou1bKpxSIL4RBD7faGmniQ8J3,I67jRFmCZW5yEBnqxwd0Tbsa,esAxYrVLPz7RJchkKHTSE6,Lpu8jv6FZf4Ab5GeQJmnqWIPHYstx,nA5dhMRg6ENzsB0l1GwvH7aIr2,d3fuH2STqpD
				for u5is0LGFYgNBHPZEdjcXVfySo29 in a9DVIdhsHUGrA67iujWZowNSl3MfKP:
					XBRmMnHowf08ea = u5is0LGFYgNBHPZEdjcXVfySo29['menuItem']
					if XBRmMnHowf08ea==cIuUM48R1jy or u5is0LGFYgNBHPZEdjcXVfySo29['mode'] in [265,270]:
						u5is0LGFYgNBHPZEdjcXVfySo29 = xu6ls91K5a2ZJtnQ(XBRmMnHowf08ea,jM8rgt21kBcd4wiZFfT6,pRJYBGh9HX0dxn)
						if u5is0LGFYgNBHPZEdjcXVfySo29['favorites']:
							B3Y9FAJLSm7kn0veVOcRMjUtHCZEfx = yHmCRPvKgaIOdJnGTf6Dk8N7us0qW9(pRJYBGh9HX0dxn,XBRmMnHowf08ea,u5is0LGFYgNBHPZEdjcXVfySo29['newpath'])
							u5is0LGFYgNBHPZEdjcXVfySo29['context_menu'] = B3Y9FAJLSm7kn0veVOcRMjUtHCZEfx+u5is0LGFYgNBHPZEdjcXVfySo29['context_menu']
					cjnMe69wLxd.append(u5is0LGFYgNBHPZEdjcXVfySo29)
				KQctJbXeEjDhplqknU3rzi.setSetting('av.status.refresh',nA5dhMRg6ENzsB0l1GwvH7aIr2)
				if zzU5PnmRv13toWs4bDFL=='folder': WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,'MENUS_CACHE_'+fL9XNQajnw53gsU1eyxk08FPl+'_'+GRLQr9gC26iol4HIupkbvAW0BdVN5s,r6J2iNjQAhH9PI7bauMy,cjnMe69wLxd,QdwW2s0iEp56qMmvCbOeLxBRU)
			else: cjnMe69wLxd = a9DVIdhsHUGrA67iujWZowNSl3MfKP
			if zzU5PnmRv13toWs4bDFL=='folder' and ByuFsZxqG3NTIQ54f9CPclLVS!='..' and cF4NrO9XMWIBL2Ri3Adzsvqyel: cbpzS0aUIdKLlOBWxk4Nrt()
			FCwVmbUj6gGNkWrvayhIKo = ujJytsaMw68dzFC(r6J2iNjQAhH9PI7bauMy,cjnMe69wLxd,zTEXepHg92GkWf,EBZLyUM8S37uNqlcA,uzchXbN4SQLm6riG1E)
	elif zzU5PnmRv13toWs4bDFL=='folder' and rFj1gkWuXpTniOeKAl9VN not in ['REFRESH_CACHE']+Jf3OFEMHvK9mBXxnc5 and gxF2p1ks3SLGDblB6hUY9HeWwr:
		aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,'MENUS_CACHE_'+fL9XNQajnw53gsU1eyxk08FPl+'_'+GRLQr9gC26iol4HIupkbvAW0BdVN5s,r6J2iNjQAhH9PI7bauMy)
	return FCwVmbUj6gGNkWrvayhIKo,rFj1gkWuXpTniOeKAl9VN,r6J2iNjQAhH9PI7bauMy,ByuFsZxqG3NTIQ54f9CPclLVS,cF4NrO9XMWIBL2Ri3Adzsvqyel,dKCXFM0cQe,fL9XNQajnw53gsU1eyxk08FPl,GRLQr9gC26iol4HIupkbvAW0BdVN5s
def uliqcaDoAVbL2(zzU5PnmRv13toWs4bDFL,B7n3L9yPx54v,RxWJFBAGy4iIM,No03nbgziMqjZ,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4):
	rzKxlyoWwpQHZiObUdPm35 = int(No03nbgziMqjZ)
	HXq9bKhZ8c4SxY2iA = int(rzKxlyoWwpQHZiObUdPm35//10)
	if   HXq9bKhZ8c4SxY2iA==IpFcwrWNgefMym3qta0hYQAzOdE:  from nkKg6CFTbN 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==UnOIK1WBbw2:  from RxovbNgODm 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==udq5tP0hwifHQCGYELDbOUI:  from h8hVDl3HS1 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==AH0zdvBqibaXY:  from QwA8XcxeVC 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==tpMX1Bgs0bzv8OEafyW:  from Jf6n8FK40r 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8,Q0f7ytucSriRw8HTzd)
	elif HXq9bKhZ8c4SxY2iA==eCaWsMty53QI9Y:  from KANUMma4Rb 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==6:  from EEGA2VM7PC 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==7:  from nM8Xug5yjl 			import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==8:  from f8f4Ct3Gg1 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==9:  from AAtpe390qR		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==10: from W5tgT0hvbn 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM)
	elif HXq9bKhZ8c4SxY2iA==11: from AHFaRPbv5o 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==12: from pTSbh92Qra 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==13: from csmdNuXL7q		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==14: from yGVNaP54kZ 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8,zzU5PnmRv13toWs4bDFL,Q0f7ytucSriRw8HTzd,B7n3L9yPx54v,io76Hju84PtJO3hE5x9KZnpGmalIw)
	elif HXq9bKhZ8c4SxY2iA==15: from nkKg6CFTbN 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==16: from lPh2SwNp9v		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8,Q0f7ytucSriRw8HTzd,Xxcm31HuozfbJEAv8Rl7PwUgGBF4)
	elif HXq9bKhZ8c4SxY2iA==17: from nkKg6CFTbN 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==18: from qqY4aTRVuZ		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==19: from nkKg6CFTbN 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==20: from mNAHFhGBe0		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==21: from EUPwSbVvHc	import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==22: from L7WfSZVw4l		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==23: from atoGunAmqK			import etoUZjTVky8ru7c; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = etoUZjTVky8ru7c(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8,zzU5PnmRv13toWs4bDFL,Q0f7ytucSriRw8HTzd,Xxcm31HuozfbJEAv8Rl7PwUgGBF4)
	elif HXq9bKhZ8c4SxY2iA==24: from zd1NUSb7FV 			import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==25: from kPXKMEVLmO 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==26: from UdES5ZYF1g 			import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==27: from FjdxIzi5Pr		import etoUZjTVky8ru7c; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = etoUZjTVky8ru7c(rzKxlyoWwpQHZiObUdPm35,kSqp7Ua0gATvrXG2RFdzN)
	elif HXq9bKhZ8c4SxY2iA==28: from atoGunAmqK			import etoUZjTVky8ru7c; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = etoUZjTVky8ru7c(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8,zzU5PnmRv13toWs4bDFL,Q0f7ytucSriRw8HTzd,Xxcm31HuozfbJEAv8Rl7PwUgGBF4)
	elif HXq9bKhZ8c4SxY2iA==29: from UUIS0B8xVC	import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==30: from BUOWAzsN5n		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==31: from VUdJmIA7Fq		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==32: from WfD9dJ4hO0		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==33: from YYgzUwQ1oN		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM)
	elif HXq9bKhZ8c4SxY2iA==34: from nkKg6CFTbN 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==35: from dT46xpmJOA		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==36: from xx5Zm6kzpv			import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==37: from vSX3ktWrTy			import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==38: from oQtvnypW6j 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==39: from lJrhM57sR2		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==40: from whLXEMapkb	import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8,zzU5PnmRv13toWs4bDFL,Q0f7ytucSriRw8HTzd)
	elif HXq9bKhZ8c4SxY2iA==41: from whLXEMapkb	import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8,zzU5PnmRv13toWs4bDFL,Q0f7ytucSriRw8HTzd)
	elif HXq9bKhZ8c4SxY2iA==42: from UFoYRT3b8c			import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==43: from iEQFHOvgZq			import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==44: from FFtYygSs4C		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==45: from xxVHDpTBMF		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==46: from ttPYy0HmjL			import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==47: from r4KE58LjVC		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==48: from svt4HFPmpI		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==49: from oy5aV7khgQ		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==50: from nkKg6CFTbN 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==51: from eeBRQN6Xin 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==52: from eeBRQN6Xin 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==53: from UdES5ZYF1g 			import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==54: from BBFeHcDpy6	import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8,Q0f7ytucSriRw8HTzd)
	elif HXq9bKhZ8c4SxY2iA==55: from N3Lo7hvnXf 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==56: from cp4ZoSWT3q		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==57: from BuoVzJ2O9t		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==58: from CbBz58GVsw		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==59: from DSZdIq91VC		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==60: from wZVGy8atc5			import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==61: from rWLl0RNect			import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==62: from qq2RAG5mQT		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==63: from BF9CYfxmHD	import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==64: from LBMQjO6qxX			import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==65: from dcQwCNFnVx			import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==66: from NNsUMy7niJ			import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==67: from Obo0piMIzQ		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==68: from RYuDlE1emt		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==69: from bjJd2XQOls		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==70: from M9eNzGxthm			import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==71: from Bn18ZLUmyw			import etoUZjTVky8ru7c; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = etoUZjTVky8ru7c(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8,zzU5PnmRv13toWs4bDFL,Q0f7ytucSriRw8HTzd,Xxcm31HuozfbJEAv8Rl7PwUgGBF4)
	elif HXq9bKhZ8c4SxY2iA==72: from Bn18ZLUmyw			import etoUZjTVky8ru7c; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = etoUZjTVky8ru7c(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8,zzU5PnmRv13toWs4bDFL,Q0f7ytucSriRw8HTzd,Xxcm31HuozfbJEAv8Rl7PwUgGBF4)
	elif HXq9bKhZ8c4SxY2iA==73: from nnOWPTY4u7	import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==74: from WgJLjECVOa		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35)
	elif HXq9bKhZ8c4SxY2iA==75: from WgJLjECVOa		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35)
	elif HXq9bKhZ8c4SxY2iA==76: from lPh2SwNp9v		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8,Q0f7ytucSriRw8HTzd,Xxcm31HuozfbJEAv8Rl7PwUgGBF4)
	elif HXq9bKhZ8c4SxY2iA==77: from GvDLytQbNz 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==78: from pgLaDNIf8m 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==79: from IIfVlWZqAN 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==80: from s7seSBfgiW 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==81: from NNX0YcRHsB 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==82: from yjo4I0zXwn		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==83: from V6FAwmbMiX		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==84: from kJFiNz0IGL		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==85: from YwtzvLRVZM		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==86: from OOM5hYorXR		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==87: from JpejmuP7gr			import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==88: from rLpeiHYAg1			import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==89: from bXP1zMUCvy		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==90: from ppVSbYsmHZ	import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==91: from mjgwoe5AY9		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==92: from X2hM5BF6Y7		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==93: from Vqm40MpjsJ		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==94: from K9dIPrMwlR			import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==95: from JDwTsV4OLy			import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==96: from i9u6UmvN0t		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==97: from hhS62AN4sc		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==98: from hfaA1EbPOL		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==99: from TIxHuR5PA6		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==100: from j9jQwbJLAM		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==101: from z65zZiX18G	import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==102: from nkKg6CFTbN 		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==103: from rvbIP0MLHK	import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==104: from NvMezGk3DT		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==105: from aSz9PsQUNO			import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==106: from TfJER1Nwq9		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==107: from damH1jtGEw		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	elif HXq9bKhZ8c4SxY2iA==108: from WgJLjECVOa		import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35)
	elif HXq9bKhZ8c4SxY2iA==109: from LWhrbmFws1 	import YYdDUV01oAtQljRBxO9enrEXHwfC	; V9OGBuyogH0CaUtQS6wWErAbPYDjlM = YYdDUV01oAtQljRBxO9enrEXHwfC(rzKxlyoWwpQHZiObUdPm35,RxWJFBAGy4iIM,ooJmTWvjkAOHMN6EQSa23b4wiY8)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = None
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
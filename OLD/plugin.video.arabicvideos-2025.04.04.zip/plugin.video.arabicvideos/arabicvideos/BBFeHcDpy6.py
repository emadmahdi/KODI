# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'GLOBALSEARCH'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_GLS_'
def YYdDUV01oAtQljRBxO9enrEXHwfC(knBV0UPuCNdpIsAFH3coRKjh2lb,kOTdpYrPqu5A7UIcW0Ch,OOrjZaTIVXQ2Sp0ozhc,Q0f7ytucSriRw8HTzd):
	if   knBV0UPuCNdpIsAFH3coRKjh2lb==540: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==541: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = Q5TaHeWg9LZ2KF641pcG7oIXVS(OOrjZaTIVXQ2Sp0ozhc)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==542: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = TJIrM3ouekXGqpdl76nmNwth(OOrjZaTIVXQ2Sp0ozhc,kOTdpYrPqu5A7UIcW0Ch,Q0f7ytucSriRw8HTzd)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==543: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = trcCz1Yl2KPSFXs7LG8BTnyJukE()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==548: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = t4pHYMuTrZWBFUEivL6V1R(kOTdpYrPqu5A7UIcW0Ch,OOrjZaTIVXQ2Sp0ozhc)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==549: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(OOrjZaTIVXQ2Sp0ozhc)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder','بحث جديد لجميع المواقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,549)
	TBt8bUDo9WhL('link','كيف يعمل بحث جميع المواقع','',543)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+'==== كلمات البحث المخزنة ===='+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	t6vW1oSB4we7hVM283yK0dO = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,'dict','GLOBALSEARCH_SPLITTED_ALL')
	if t6vW1oSB4we7hVM283yK0dO:
		t6vW1oSB4we7hVM283yK0dO = t6vW1oSB4we7hVM283yK0dO['__SEQUENCED_COLUMNS__']
		for BBFVq0I5Ecsl in reversed(t6vW1oSB4we7hVM283yK0dO):
			TBt8bUDo9WhL('folder',BBFVq0I5Ecsl,nA5dhMRg6ENzsB0l1GwvH7aIr2,549,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,BBFVq0I5Ecsl)
	return
def WULrxiSjG3d1Cemza7Kc(BBFVq0I5Ecsl):
	if not BBFVq0I5Ecsl:
		BBFVq0I5Ecsl = FaUBpzTGxtS7hZyl()
		if not BBFVq0I5Ecsl: return
		BBFVq0I5Ecsl = BBFVq0I5Ecsl.lower()
	hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O = BBFVq0I5Ecsl.replace(DjKrTPWEFw2YeCi5d6unBqhZSlAR,nA5dhMRg6ENzsB0l1GwvH7aIr2)
	RImJK3US8zW1h6iFgkE4Dp(hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,'_ALL',True)
	TBt8bUDo9WhL('link','بحث جماعي للمواقع - '+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,'search_sites_all',542,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O)
	TBt8bUDo9WhL('folder','بحث منفرد للمواقع - '+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,541,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+'===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder','نتائج البحث مفصلة - '+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,'opened_sites_all',542,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O)
	TBt8bUDo9WhL('folder','نتائج البحث مقسمة - '+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,'listed_sites_all',542,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O)
	return
def RImJK3US8zW1h6iFgkE4Dp(cl6jGTf12UyMDB9QaJSbhO,xjqzFNB40XmkI72gEwv,SyXklnC5zwN8aR):
	if xjqzFNB40XmkI72gEwv=='_ALL': gja6P2hrITZpUSFfbuJ8 = '_GLS_'
	elif xjqzFNB40XmkI72gEwv=='_GOOGLE': gja6P2hrITZpUSFfbuJ8 = '_GOS_'
	tvCwDaM38b7 = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,'list','GLOBALSEARCH_SPLITTED'+xjqzFNB40XmkI72gEwv,cl6jGTf12UyMDB9QaJSbhO)
	dQYVETg5Xe = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,'list','GLOBALSEARCH_SPLITTED'+xjqzFNB40XmkI72gEwv,gja6P2hrITZpUSFfbuJ8+cl6jGTf12UyMDB9QaJSbhO)
	aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,'GLOBALSEARCH_SPLITTED'+xjqzFNB40XmkI72gEwv,cl6jGTf12UyMDB9QaJSbhO)
	aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,'GLOBALSEARCH_SPLITTED'+xjqzFNB40XmkI72gEwv,gja6P2hrITZpUSFfbuJ8+cl6jGTf12UyMDB9QaJSbhO)
	UAf10G6OlWRoBNtdIkMQpJbsx2Z = tvCwDaM38b7+dQYVETg5Xe
	if UAf10G6OlWRoBNtdIkMQpJbsx2Z and SyXklnC5zwN8aR: cl6jGTf12UyMDB9QaJSbhO = gja6P2hrITZpUSFfbuJ8+cl6jGTf12UyMDB9QaJSbhO
	WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,'GLOBALSEARCH_SPLITTED'+xjqzFNB40XmkI72gEwv,cl6jGTf12UyMDB9QaJSbhO,UAf10G6OlWRoBNtdIkMQpJbsx2Z,KcwozFY2DsR3jSBO)
	return
def hjQMgsBO5V4bR7fZocrWy(xjqzFNB40XmkI72gEwv):
	x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if x6zlf2tTZm!=1: return
	aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,'GLOBALSEARCH_SPLITTED'+xjqzFNB40XmkI72gEwv)
	aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,'GLOBALSEARCH_DETAILED'+xjqzFNB40XmkI72gEwv)
	aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,'GLOBALSEARCH_DIVIDED'+xjqzFNB40XmkI72gEwv)
	if xjqzFNB40XmkI72gEwv=='_GOOGLE': aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,'GOOGLESEARCH_RESULTS')
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def TJIrM3ouekXGqpdl76nmNwth(pp95FoYkj7z,aEFPC0Z3IObLufciARewMrG1pW6T,EQJ4wmV0bN9kaBtMe=nA5dhMRg6ENzsB0l1GwvH7aIr2,lSJ6xmhDXCb=WOkE6hBtPfVNLJu28eFSZmTndQ,QEs2ARGqU7KLuOvVgInB={}):
	K09KldkuPXHAjy,sK8DXTJa3NifCpZmkLer5u4t,DSn3QvrizjTUc6HZk1Pwyf,ik4H8beBQzfc2hEds,KMBYqvTk0J1HVowpaQn9LXU = [],{},{},{},{}
	if '_all' in aEFPC0Z3IObLufciARewMrG1pW6T: xjqzFNB40XmkI72gEwv,hz2HnpMwOAQ9asERGCForbqWSK,gja6P2hrITZpUSFfbuJ8 = '_ALL','_all','_GLS_'
	elif '_google' in aEFPC0Z3IObLufciARewMrG1pW6T: xjqzFNB40XmkI72gEwv,hz2HnpMwOAQ9asERGCForbqWSK,gja6P2hrITZpUSFfbuJ8 = '_GOOGLE','_google','_GOS_'
	if aEFPC0Z3IObLufciARewMrG1pW6T in ['listed_sites'+hz2HnpMwOAQ9asERGCForbqWSK,'opened_sites'+hz2HnpMwOAQ9asERGCForbqWSK,'closed_sites'+hz2HnpMwOAQ9asERGCForbqWSK]:
		if aEFPC0Z3IObLufciARewMrG1pW6T=='listed_sites'+hz2HnpMwOAQ9asERGCForbqWSK: K09KldkuPXHAjy = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,'list','GLOBALSEARCH_SPLITTED'+xjqzFNB40XmkI72gEwv,gja6P2hrITZpUSFfbuJ8+pp95FoYkj7z)
		elif aEFPC0Z3IObLufciARewMrG1pW6T=='opened_sites'+hz2HnpMwOAQ9asERGCForbqWSK: K09KldkuPXHAjy = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,'list','GLOBALSEARCH_DETAILED'+xjqzFNB40XmkI72gEwv,pp95FoYkj7z)
		elif aEFPC0Z3IObLufciARewMrG1pW6T=='closed_sites'+hz2HnpMwOAQ9asERGCForbqWSK: K09KldkuPXHAjy = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,'list','GLOBALSEARCH_DIVIDED'+xjqzFNB40XmkI72gEwv,(EQJ4wmV0bN9kaBtMe,pp95FoYkj7z))
	if not K09KldkuPXHAjy:
		jr9ylNbvcHEzPG8UpkL = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		jL23e6YO9IcvVME = 'هل تريد الآن البحث في جميع المواقع عن \n "'+lSWzOYmN08+hSXlxL9iB05c+pp95FoYkj7z+hSXlxL9iB05c+NwROdSj3nsA+'" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if aEFPC0Z3IObLufciARewMrG1pW6T=='search_sites'+hz2HnpMwOAQ9asERGCForbqWSK: a1duvQ8Vh0gNo69nDcp3Pjtym = jL23e6YO9IcvVME
		else: a1duvQ8Vh0gNo69nDcp3Pjtym = jr9ylNbvcHEzPG8UpkL+jL23e6YO9IcvVME
		x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,a1duvQ8Vh0gNo69nDcp3Pjtym)
		if x6zlf2tTZm!=1: return
		RUEwdIv5WrlKDFhTBe(oZqKcvlJx1pTLN2ske5f0PtVrw,oZqKcvlJx1pTLN2ske5f0PtVrw,oZqKcvlJx1pTLN2ske5f0PtVrw)
		nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+'   Search For: [ '+pp95FoYkj7z+' ]')
		IIy1OHunht3qoMJrWbj = 1
		for whXU4NCbPdFAcxErVJIutR8WDM3n in lSJ6xmhDXCb:
			qixB6G2UTL = QEs2ARGqU7KLuOvVgInB[whXU4NCbPdFAcxErVJIutR8WDM3n] if QEs2ARGqU7KLuOvVgInB else pp95FoYkj7z
			try: hT9D8fRSNgycG36k,vlm7dBDy2RXPj1C8,CYv7ydT6WAGtu0o = EN1Pg52zbjsmLMQq9(whXU4NCbPdFAcxErVJIutR8WDM3n)
			except: continue
			sK8DXTJa3NifCpZmkLer5u4t[whXU4NCbPdFAcxErVJIutR8WDM3n] = []
			QKHC8Vlk21Up = '_NODIALOGS_'
			if '-' in whXU4NCbPdFAcxErVJIutR8WDM3n: QKHC8Vlk21Up = QKHC8Vlk21Up+'_REMEMBERRESULTS__'+whXU4NCbPdFAcxErVJIutR8WDM3n+'_'
			if IIy1OHunht3qoMJrWbj:
				h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(0.75)
				KMBYqvTk0J1HVowpaQn9LXU[whXU4NCbPdFAcxErVJIutR8WDM3n] = QCxDqOcS9z586(daemon=S5MWhgtZ37Xw,target=vlm7dBDy2RXPj1C8,args=(qixB6G2UTL+QKHC8Vlk21Up,))
				KMBYqvTk0J1HVowpaQn9LXU[whXU4NCbPdFAcxErVJIutR8WDM3n].start()
			else: vlm7dBDy2RXPj1C8(qixB6G2UTL+QKHC8Vlk21Up)
			ggYilKR5rMDyp7B(AEyNnLOu7g6BGrw5tlcj(whXU4NCbPdFAcxErVJIutR8WDM3n),nA5dhMRg6ENzsB0l1GwvH7aIr2,h0skHe7TcIY9x1UP5VBrZAE8dKGnl=1000)
		if IIy1OHunht3qoMJrWbj:
			h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(2)
			for whXU4NCbPdFAcxErVJIutR8WDM3n in lSJ6xmhDXCb: KMBYqvTk0J1HVowpaQn9LXU[whXU4NCbPdFAcxErVJIutR8WDM3n].join(10)
			h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(2)
		for whXU4NCbPdFAcxErVJIutR8WDM3n in lSJ6xmhDXCb:
			try: hT9D8fRSNgycG36k,vlm7dBDy2RXPj1C8,CYv7ydT6WAGtu0o = EN1Pg52zbjsmLMQq9(whXU4NCbPdFAcxErVJIutR8WDM3n)
			except: continue
			for GLS4zosKmrciQfvg0REtVN in Nzp9Fq5cTr.menuItemsLIST:
				WTavfhd7QJDABwpIVrZqHL,w8cPT5nhW2RUAFKDa,kOTdpYrPqu5A7UIcW0Ch,knBV0UPuCNdpIsAFH3coRKjh2lb,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,OOrjZaTIVXQ2Sp0ozhc,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4 = GLS4zosKmrciQfvg0REtVN
				if CYv7ydT6WAGtu0o in w8cPT5nhW2RUAFKDa:
					if 'IPTV-' in whXU4NCbPdFAcxErVJIutR8WDM3n and (239>=knBV0UPuCNdpIsAFH3coRKjh2lb>=230 or 289>=knBV0UPuCNdpIsAFH3coRKjh2lb>=280):
						if GLS4zosKmrciQfvg0REtVN in sK8DXTJa3NifCpZmkLer5u4t['IPTV-LIVE']: continue
						if GLS4zosKmrciQfvg0REtVN in sK8DXTJa3NifCpZmkLer5u4t['IPTV-MOVIES']: continue
						if GLS4zosKmrciQfvg0REtVN in sK8DXTJa3NifCpZmkLer5u4t['IPTV-SERIES']: continue
						if 'صفحة' not in w8cPT5nhW2RUAFKDa:
							if   WTavfhd7QJDABwpIVrZqHL=='live': whXU4NCbPdFAcxErVJIutR8WDM3n = 'IPTV-LIVE'
							elif WTavfhd7QJDABwpIVrZqHL=='video': whXU4NCbPdFAcxErVJIutR8WDM3n = 'IPTV-MOVIES'
							elif WTavfhd7QJDABwpIVrZqHL=='folder': whXU4NCbPdFAcxErVJIutR8WDM3n = 'IPTV-SERIES'
						else:
							if   'LIVE' in kOTdpYrPqu5A7UIcW0Ch: whXU4NCbPdFAcxErVJIutR8WDM3n = 'IPTV-LIVE'
							elif 'MOVIES' in kOTdpYrPqu5A7UIcW0Ch: whXU4NCbPdFAcxErVJIutR8WDM3n = 'IPTV-MOVIES'
							elif 'SERIES' in kOTdpYrPqu5A7UIcW0Ch: whXU4NCbPdFAcxErVJIutR8WDM3n = 'IPTV-SERIES'
					elif 'M3U-' in whXU4NCbPdFAcxErVJIutR8WDM3n and 729>=knBV0UPuCNdpIsAFH3coRKjh2lb>=710:
						if GLS4zosKmrciQfvg0REtVN in sK8DXTJa3NifCpZmkLer5u4t['M3U-LIVE']: continue
						if GLS4zosKmrciQfvg0REtVN in sK8DXTJa3NifCpZmkLer5u4t['M3U-MOVIES']: continue
						if GLS4zosKmrciQfvg0REtVN in sK8DXTJa3NifCpZmkLer5u4t['M3U-SERIES']: continue
						if 'صفحة' not in w8cPT5nhW2RUAFKDa:
							if   WTavfhd7QJDABwpIVrZqHL=='live': whXU4NCbPdFAcxErVJIutR8WDM3n = 'M3U-LIVE'
							elif WTavfhd7QJDABwpIVrZqHL=='video': whXU4NCbPdFAcxErVJIutR8WDM3n = 'M3U-MOVIES'
							elif WTavfhd7QJDABwpIVrZqHL=='folder': whXU4NCbPdFAcxErVJIutR8WDM3n = 'M3U-SERIES'
						else:
							if   'LIVE' in kOTdpYrPqu5A7UIcW0Ch: whXU4NCbPdFAcxErVJIutR8WDM3n = 'M3U-LIVE'
							elif 'MOVIES' in kOTdpYrPqu5A7UIcW0Ch: whXU4NCbPdFAcxErVJIutR8WDM3n = 'M3U-MOVIES'
							elif 'SERIES' in kOTdpYrPqu5A7UIcW0Ch: whXU4NCbPdFAcxErVJIutR8WDM3n = 'M3U-SERIES'
					elif 'YOUTUBE-' in whXU4NCbPdFAcxErVJIutR8WDM3n and 149>=knBV0UPuCNdpIsAFH3coRKjh2lb>=140:
						if GLS4zosKmrciQfvg0REtVN in sK8DXTJa3NifCpZmkLer5u4t['YOUTUBE-CHANNELS']: continue
						if GLS4zosKmrciQfvg0REtVN in sK8DXTJa3NifCpZmkLer5u4t['YOUTUBE-PLAYLISTS']: continue
						if GLS4zosKmrciQfvg0REtVN in sK8DXTJa3NifCpZmkLer5u4t['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in w8cPT5nhW2RUAFKDa or ':: ' in w8cPT5nhW2RUAFKDa:
							continue
						else:
							if   knBV0UPuCNdpIsAFH3coRKjh2lb==144 and 'USER' in w8cPT5nhW2RUAFKDa: whXU4NCbPdFAcxErVJIutR8WDM3n = 'YOUTUBE-CHANNELS'
							elif knBV0UPuCNdpIsAFH3coRKjh2lb==144 and 'CHNL' in w8cPT5nhW2RUAFKDa: whXU4NCbPdFAcxErVJIutR8WDM3n = 'YOUTUBE-CHANNELS'
							elif knBV0UPuCNdpIsAFH3coRKjh2lb==144 and 'LIST' in w8cPT5nhW2RUAFKDa: whXU4NCbPdFAcxErVJIutR8WDM3n = 'YOUTUBE-PLAYLISTS'
							elif knBV0UPuCNdpIsAFH3coRKjh2lb==143: whXU4NCbPdFAcxErVJIutR8WDM3n = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in whXU4NCbPdFAcxErVJIutR8WDM3n and 419>=knBV0UPuCNdpIsAFH3coRKjh2lb>=400:
						if GLS4zosKmrciQfvg0REtVN in sK8DXTJa3NifCpZmkLer5u4t['DAILYMOTION-PLAYLISTS']: continue
						if GLS4zosKmrciQfvg0REtVN in sK8DXTJa3NifCpZmkLer5u4t['DAILYMOTION-CHANNELS']: continue
						if GLS4zosKmrciQfvg0REtVN in sK8DXTJa3NifCpZmkLer5u4t['DAILYMOTION-VIDEOS']: continue
						if GLS4zosKmrciQfvg0REtVN in sK8DXTJa3NifCpZmkLer5u4t['DAILYMOTION-LIVES']: continue
						if GLS4zosKmrciQfvg0REtVN in sK8DXTJa3NifCpZmkLer5u4t['DAILYMOTION-HASHTAGS']: continue
						if   knBV0UPuCNdpIsAFH3coRKjh2lb in [401,405]: whXU4NCbPdFAcxErVJIutR8WDM3n = 'DAILYMOTION-PLAYLISTS'
						elif knBV0UPuCNdpIsAFH3coRKjh2lb in [402,406]: whXU4NCbPdFAcxErVJIutR8WDM3n = 'DAILYMOTION-CHANNELS'
						elif knBV0UPuCNdpIsAFH3coRKjh2lb in [404]: whXU4NCbPdFAcxErVJIutR8WDM3n = 'DAILYMOTION-VIDEOS'
						elif knBV0UPuCNdpIsAFH3coRKjh2lb in [415]: whXU4NCbPdFAcxErVJIutR8WDM3n = 'DAILYMOTION-LIVES'
						elif knBV0UPuCNdpIsAFH3coRKjh2lb in [416]: whXU4NCbPdFAcxErVJIutR8WDM3n = 'DAILYMOTION-HASHTAGS'
					elif 'PANET-' in whXU4NCbPdFAcxErVJIutR8WDM3n and 39>=knBV0UPuCNdpIsAFH3coRKjh2lb>=30:
						if GLS4zosKmrciQfvg0REtVN in sK8DXTJa3NifCpZmkLer5u4t['PANET-SERIES']: continue
						if GLS4zosKmrciQfvg0REtVN in sK8DXTJa3NifCpZmkLer5u4t['PANET-MOVIES']: continue
						if   knBV0UPuCNdpIsAFH3coRKjh2lb in [32,39]: whXU4NCbPdFAcxErVJIutR8WDM3n = 'PANET-SERIES'
						elif knBV0UPuCNdpIsAFH3coRKjh2lb in [33,39]: whXU4NCbPdFAcxErVJIutR8WDM3n = 'PANET-MOVIES'
					elif 'IFILM-' in whXU4NCbPdFAcxErVJIutR8WDM3n and 29>=knBV0UPuCNdpIsAFH3coRKjh2lb>=20:
						if GLS4zosKmrciQfvg0REtVN in sK8DXTJa3NifCpZmkLer5u4t['IFILM-ARABIC']: continue
						if GLS4zosKmrciQfvg0REtVN in sK8DXTJa3NifCpZmkLer5u4t['IFILM-ENGLISH']: continue
						if   '/ar.' in kOTdpYrPqu5A7UIcW0Ch: whXU4NCbPdFAcxErVJIutR8WDM3n = 'IFILM-ARABIC'
						elif '/en.' in kOTdpYrPqu5A7UIcW0Ch: whXU4NCbPdFAcxErVJIutR8WDM3n = 'IFILM-ENGLISH'
					sK8DXTJa3NifCpZmkLer5u4t[whXU4NCbPdFAcxErVJIutR8WDM3n].append(GLS4zosKmrciQfvg0REtVN)
		for whXU4NCbPdFAcxErVJIutR8WDM3n in list(sK8DXTJa3NifCpZmkLer5u4t.keys()):
			DSn3QvrizjTUc6HZk1Pwyf[whXU4NCbPdFAcxErVJIutR8WDM3n] = []
			ik4H8beBQzfc2hEds[whXU4NCbPdFAcxErVJIutR8WDM3n] = []
			for WTavfhd7QJDABwpIVrZqHL,w8cPT5nhW2RUAFKDa,kOTdpYrPqu5A7UIcW0Ch,knBV0UPuCNdpIsAFH3coRKjh2lb,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,OOrjZaTIVXQ2Sp0ozhc,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4 in sK8DXTJa3NifCpZmkLer5u4t[whXU4NCbPdFAcxErVJIutR8WDM3n]:
				GLS4zosKmrciQfvg0REtVN = (WTavfhd7QJDABwpIVrZqHL,w8cPT5nhW2RUAFKDa,kOTdpYrPqu5A7UIcW0Ch,knBV0UPuCNdpIsAFH3coRKjh2lb,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,OOrjZaTIVXQ2Sp0ozhc,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4)
				if 'صفحة' in w8cPT5nhW2RUAFKDa and WTavfhd7QJDABwpIVrZqHL=='folder': ik4H8beBQzfc2hEds[whXU4NCbPdFAcxErVJIutR8WDM3n].append(GLS4zosKmrciQfvg0REtVN)
				else: DSn3QvrizjTUc6HZk1Pwyf[whXU4NCbPdFAcxErVJIutR8WDM3n].append(GLS4zosKmrciQfvg0REtVN)
		xqBSZLOCJcm98Kb,MCfZ8qp62mxnTvNklaoezRh07 = [],[]
		RjieJlz6cK10gSqrLa8k3TQWwAtm = list(DSn3QvrizjTUc6HZk1Pwyf.keys())
		Cp1gVNwaYDlZ7 = RL95rqviDebl4jcWynm7VEaug2(RjieJlz6cK10gSqrLa8k3TQWwAtm)
		sLh9jdJxM0u3nl4wIvAbOG52Bo = []
		for whXU4NCbPdFAcxErVJIutR8WDM3n in Cp1gVNwaYDlZ7:
			if isinstance(whXU4NCbPdFAcxErVJIutR8WDM3n,tuple):
				sLh9jdJxM0u3nl4wIvAbOG52Bo = [whXU4NCbPdFAcxErVJIutR8WDM3n]
				continue
			if whXU4NCbPdFAcxErVJIutR8WDM3n not in lSJ6xmhDXCb: continue
			if DSn3QvrizjTUc6HZk1Pwyf[whXU4NCbPdFAcxErVJIutR8WDM3n]:
				klei8XAEQJjzGS9MsF2fxpDLOV = AEyNnLOu7g6BGrw5tlcj(whXU4NCbPdFAcxErVJIutR8WDM3n)
				vzMykwUriPK0jtdhVSaRCuB9mnIe = [('link',lSWzOYmN08+'===== '+klei8XAEQJjzGS9MsF2fxpDLOV+' ====='+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2)]
				if 0: F4RtcDqnbU0dfrpjOWG2vwHXJCBNA = pp95FoYkj7z+' - '+'بحث'+hSXlxL9iB05c+klei8XAEQJjzGS9MsF2fxpDLOV
				else: F4RtcDqnbU0dfrpjOWG2vwHXJCBNA = 'بحث'+hSXlxL9iB05c+klei8XAEQJjzGS9MsF2fxpDLOV+' - '+pp95FoYkj7z
				if len(DSn3QvrizjTUc6HZk1Pwyf[whXU4NCbPdFAcxErVJIutR8WDM3n])<8: MvY92NWAVQG0Jb = []
				else:
					CTsa18grceozh = bbTCMJwEx8nhN4X+F4RtcDqnbU0dfrpjOWG2vwHXJCBNA+NwROdSj3nsA
					MvY92NWAVQG0Jb = [('folder',gja6P2hrITZpUSFfbuJ8+CTsa18grceozh,'closed_sites'+hz2HnpMwOAQ9asERGCForbqWSK,542,nA5dhMRg6ENzsB0l1GwvH7aIr2,whXU4NCbPdFAcxErVJIutR8WDM3n,pp95FoYkj7z,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2)]
				JkInWNGTDSogLQc2Eh71659ft = DSn3QvrizjTUc6HZk1Pwyf[whXU4NCbPdFAcxErVJIutR8WDM3n]+ik4H8beBQzfc2hEds[whXU4NCbPdFAcxErVJIutR8WDM3n]
				A2m6En8Iazv = sLh9jdJxM0u3nl4wIvAbOG52Bo+vzMykwUriPK0jtdhVSaRCuB9mnIe+JkInWNGTDSogLQc2Eh71659ft[:7]+MvY92NWAVQG0Jb
				xqBSZLOCJcm98Kb += A2m6En8Iazv
				oa8Xnp6eUJ = [('folder',gja6P2hrITZpUSFfbuJ8+F4RtcDqnbU0dfrpjOWG2vwHXJCBNA,'closed_sites'+hz2HnpMwOAQ9asERGCForbqWSK,542,nA5dhMRg6ENzsB0l1GwvH7aIr2,whXU4NCbPdFAcxErVJIutR8WDM3n,pp95FoYkj7z,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2)]
				fQrKy42hONXsoIpk = sLh9jdJxM0u3nl4wIvAbOG52Bo+oa8Xnp6eUJ
				MCfZ8qp62mxnTvNklaoezRh07 += fQrKy42hONXsoIpk
				WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,'GLOBALSEARCH_DIVIDED'+xjqzFNB40XmkI72gEwv,(whXU4NCbPdFAcxErVJIutR8WDM3n,pp95FoYkj7z),JkInWNGTDSogLQc2Eh71659ft,KcwozFY2DsR3jSBO)
				sLh9jdJxM0u3nl4wIvAbOG52Bo = []
		WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,'GLOBALSEARCH_DETAILED'+xjqzFNB40XmkI72gEwv,pp95FoYkj7z,xqBSZLOCJcm98Kb,KcwozFY2DsR3jSBO)
		aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,'GLOBALSEARCH_SPLITTED'+xjqzFNB40XmkI72gEwv,pp95FoYkj7z)
		WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,'GLOBALSEARCH_SPLITTED'+xjqzFNB40XmkI72gEwv,gja6P2hrITZpUSFfbuJ8+pp95FoYkj7z,MCfZ8qp62mxnTvNklaoezRh07,KcwozFY2DsR3jSBO)
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم حتى تستطيع العودة إليها بدون عمل بحث جديد')
		K09KldkuPXHAjy = MCfZ8qp62mxnTvNklaoezRh07 if aEFPC0Z3IObLufciARewMrG1pW6T=='listed_sites'+hz2HnpMwOAQ9asERGCForbqWSK and MCfZ8qp62mxnTvNklaoezRh07 else xqBSZLOCJcm98Kb
	if aEFPC0Z3IObLufciARewMrG1pW6T in ['listed_sites'+hz2HnpMwOAQ9asERGCForbqWSK,'opened_sites'+hz2HnpMwOAQ9asERGCForbqWSK,'closed_sites'+hz2HnpMwOAQ9asERGCForbqWSK]:
		for WTavfhd7QJDABwpIVrZqHL,w8cPT5nhW2RUAFKDa,kOTdpYrPqu5A7UIcW0Ch,knBV0UPuCNdpIsAFH3coRKjh2lb,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,OOrjZaTIVXQ2Sp0ozhc,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4 in K09KldkuPXHAjy:
			if aEFPC0Z3IObLufciARewMrG1pW6T in ['listed_sites'+hz2HnpMwOAQ9asERGCForbqWSK,'opened_sites'+hz2HnpMwOAQ9asERGCForbqWSK] and 'صفحة' in w8cPT5nhW2RUAFKDa and WTavfhd7QJDABwpIVrZqHL=='folder': continue
			TBt8bUDo9WhL(WTavfhd7QJDABwpIVrZqHL,w8cPT5nhW2RUAFKDa,kOTdpYrPqu5A7UIcW0Ch,knBV0UPuCNdpIsAFH3coRKjh2lb,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,OOrjZaTIVXQ2Sp0ozhc,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4)
	RUEwdIv5WrlKDFhTBe(GGlX1Dsd3bJKMFw,GGlX1Dsd3bJKMFw,GGlX1Dsd3bJKMFw)
	return
def Q5TaHeWg9LZ2KF641pcG7oIXVS(search):
	Cp1gVNwaYDlZ7 = RL95rqviDebl4jcWynm7VEaug2(f6U7kuwg2zqXCTx0Gs8HJh1v)
	for whXU4NCbPdFAcxErVJIutR8WDM3n in Cp1gVNwaYDlZ7:
		if '-' in whXU4NCbPdFAcxErVJIutR8WDM3n: continue
		if isinstance(whXU4NCbPdFAcxErVJIutR8WDM3n,tuple):
			Nzp9Fq5cTr.menuItemsLIST.append(whXU4NCbPdFAcxErVJIutR8WDM3n)
			continue
		hT9D8fRSNgycG36k,vlm7dBDy2RXPj1C8,CYv7ydT6WAGtu0o = EN1Pg52zbjsmLMQq9(whXU4NCbPdFAcxErVJIutR8WDM3n)
		name = AEyNnLOu7g6BGrw5tlcj(whXU4NCbPdFAcxErVJIutR8WDM3n)+' - '+search
		TBt8bUDo9WhL('folder',CYv7ydT6WAGtu0o+name,whXU4NCbPdFAcxErVJIutR8WDM3n,548,'','',search)
	return
def t4pHYMuTrZWBFUEivL6V1R(whXU4NCbPdFAcxErVJIutR8WDM3n,search):
	hT9D8fRSNgycG36k,vlm7dBDy2RXPj1C8,CYv7ydT6WAGtu0o = EN1Pg52zbjsmLMQq9(whXU4NCbPdFAcxErVJIutR8WDM3n)
	vlm7dBDy2RXPj1C8(search)
	return
def trcCz1Yl2KPSFXs7LG8BTnyJukE():
	OmxJV4UQyeFqdBSIC0('','',OksCHeoL5SG,'هذا البحث يستخدم محركات البحث الصغيرة الموجودة في كل موقع من مواقع البرنامج .. ونتائج هذا البحث تعتمد على دقة وفعالية وبرمجة كل موقع منها\n\nللأسف هذه المحركات الصغيرة لا تفهم جميع تفاصيل الفيديوهات ولا تفهم طريقة تفكير البشر ولا تستطيع إصلاح الأخطاء الإملائية .. ولهذا هي تحتاج دقة كبيرة جدا في اختيار وكتابة كلمات البحث المناسبة الصحيحة الدقيقة حتى تجد لك طلبك')
	return
def yOwo1j7Sc2M(pp95FoYkj7z=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	BBFVq0I5Ecsl,QKHC8Vlk21Up,showDialogs = Vit4q8MczeLRHnJQCyXAam(pp95FoYkj7z)
	if not BBFVq0I5Ecsl:
		BBFVq0I5Ecsl = FaUBpzTGxtS7hZyl()
		if not BBFVq0I5Ecsl: return
		BBFVq0I5Ecsl = BBFVq0I5Ecsl.lower()
	nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+'   Search For: [ '+BBFVq0I5Ecsl+' ]')
	SEGtTsCyUVi0lo4LJkH5 = BBFVq0I5Ecsl+QKHC8Vlk21Up
	if 0: XPCs5Wym0n,hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O = BBFVq0I5Ecsl+' - ',nA5dhMRg6ENzsB0l1GwvH7aIr2
	else: XPCs5Wym0n,hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O = nA5dhMRg6ENzsB0l1GwvH7aIr2,' - '+BBFVq0I5Ecsl
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+'مواقع سيرفرات خاصة - قليلة المشاكل'+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,157)
	TBt8bUDo9WhL('folder','_M3U_'+XPCs5Wym0n+'بحث M3U'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,719,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_IPT_'+XPCs5Wym0n+'بحث IPTV'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,239,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_BKR_'+XPCs5Wym0n+'بحث موقع بكرا'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,379,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_ART_'+XPCs5Wym0n+'بحث موقع تونز عربية'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,739,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_KRB_'+XPCs5Wym0n+'بحث موقع قناة كربلاء'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,329,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_FH2_'+XPCs5Wym0n+'بحث موقع فاصل الثاني'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,599,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_KTV_'+XPCs5Wym0n+'بحث موقع كتكوت تيفي'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,819,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_EB1_'+XPCs5Wym0n+'بحث موقع ايجي بيست 1'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,779,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_EB2_'+XPCs5Wym0n+'بحث موقع ايجي بيست 2'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,789,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_IFL_'+XPCs5Wym0n+'  بحث موقع قناة آي فيلم'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O+BSiDxUPsdHkz27VMop51uf6c3,nA5dhMRg6ENzsB0l1GwvH7aIr2,29,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_AKO_'+XPCs5Wym0n+'بحث موقع أكوام القديم'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,79,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_AKW_'+XPCs5Wym0n+'بحث موقع أكوام الجديد'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,249,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_MRF_'+XPCs5Wym0n+'بحث موقع قناة المعارف'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,49,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_SHM_'+XPCs5Wym0n+'بحث موقع شوف ماكس'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,59,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+'مواقع سيرفرات خاصة وعامة - كثيرة المشاكل'+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,157)
	TBt8bUDo9WhL('folder','_LRZ_'+XPCs5Wym0n+'بحث موقع لاروزا'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,709,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_FJS_'+XPCs5Wym0n+' بحث موقع فجر شو'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O+hSXlxL9iB05c,nA5dhMRg6ENzsB0l1GwvH7aIr2,399,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_TVF_'+XPCs5Wym0n+'بحث موقع تيفي فان'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,469,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_LDN_'+XPCs5Wym0n+'بحث موقع لودي نت'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,459,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_CMN_'+XPCs5Wym0n+'بحث موقع سيما ناو'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,309,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_SHN_'+XPCs5Wym0n+'بحث موقع شاهد نيوز'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,589,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5+'_NODIALOGS_')
	TBt8bUDo9WhL('folder','_ARS_'+XPCs5Wym0n+'بحث موقع عرب سييد'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,259,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_CCB_'+XPCs5Wym0n+'بحث موقع سيما كلوب'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,829,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_SH4_'+XPCs5Wym0n+'بحث موقع شاهد فوريو'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,119,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5+'_NODIALOGS_')
	TBt8bUDo9WhL('folder','_SHT_'+XPCs5Wym0n+'بحث موقع شوفها تيفي'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,649,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_WC1_'+XPCs5Wym0n+'بحث موقع وي سيما 1'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,569,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_WC2_'+XPCs5Wym0n+'بحث موقع وي سيما 2'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,1009,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+'مواقع سيرفرات عامة - كثيرة المشاكل'+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,157)
	TBt8bUDo9WhL('folder','_TKT_'+XPCs5Wym0n+'بحث موقع تكات'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,949,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_FST_'+XPCs5Wym0n+'بحث موقع فوستا'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,609,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_FBK_'+XPCs5Wym0n+'بحث موقع فبركة'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,629,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_YQT_'+XPCs5Wym0n+'بحث موقع ياقوت'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,669,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_SHB_'+XPCs5Wym0n+'بحث موقع شبكتي'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,969,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_VRB_'+XPCs5Wym0n+'بحث موقع فاربون'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,879,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_BRS_'+XPCs5Wym0n+'بحث موقع برستيج'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,659,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_KRM_'+XPCs5Wym0n+'بحث موقع كرمالك'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,929,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_ANZ_'+XPCs5Wym0n+'بحث موقع انمي زد'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,979,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_FSK_'+XPCs5Wym0n+'بحث موقع فارسكو'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,999,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_HLC_'+XPCs5Wym0n+'بحث موقع هلا سيما'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,89,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_MST_'+XPCs5Wym0n+'بحث موقع المصطبة'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,869,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_SNT_'+XPCs5Wym0n+'بحث موقع شوف نت'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,849,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_DR7_'+XPCs5Wym0n+'بحث موقع دراما صح'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,689,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_CFR_'+XPCs5Wym0n+'بحث موقع سيما فري'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,839,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_CMF_'+XPCs5Wym0n+'بحث موقع سيما فانز'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,99,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_CML_'+XPCs5Wym0n+'بحث موقع سيما لايت'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,479,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_C4H_'+XPCs5Wym0n+'بحث موقع سيما 400'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,699,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_ABD_'+XPCs5Wym0n+'بحث موقع سيما عبدو'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,559,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_AKT_'+XPCs5Wym0n+'بحث موقع اكوام تيوب'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,859,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_DCF_'+XPCs5Wym0n+'بحث موقع دراما كافيه'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,939,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_FTV_'+XPCs5Wym0n+'بحث موقع فوشار تيفي'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,919,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_CWB_'+XPCs5Wym0n+'بحث موقع سيما وبس'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,989,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_AHK_'+XPCs5Wym0n+'بحث موقع أهواك تيفي'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,619,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_SRT_'+XPCs5Wym0n+'بحث موقع سيريس تايم'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,899,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_FVD_'+XPCs5Wym0n+'بحث موقع فوشار فيديو'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,909,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_C4P_'+XPCs5Wym0n+'بحث موقع سيما فور بي'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,889,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_EB4_'+XPCs5Wym0n+'بحث موقع ايجي بيست 4'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,809,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+'مواقع سيرفرات خاصة - قليلة المشاكل'+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,157)
	TBt8bUDo9WhL('folder','_YUT_'+XPCs5Wym0n+'بحث موقع يوتيوب'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,149,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	TBt8bUDo9WhL('folder','_DLM_'+XPCs5Wym0n+'بحث موقع دايلي موشن'+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,nA5dhMRg6ENzsB0l1GwvH7aIr2,409,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,SEGtTsCyUVi0lo4LJkH5)
	return
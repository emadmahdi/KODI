# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'GOOGLESEARCH'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_GOS_'
def YYdDUV01oAtQljRBxO9enrEXHwfC(knBV0UPuCNdpIsAFH3coRKjh2lb,kOTdpYrPqu5A7UIcW0Ch,OOrjZaTIVXQ2Sp0ozhc):
	if   knBV0UPuCNdpIsAFH3coRKjh2lb==1010: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==1011: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = K7qnaV43rZ2o0tNmPQEc(OOrjZaTIVXQ2Sp0ozhc)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==1012: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = b8CYRyuWGNqK(kOTdpYrPqu5A7UIcW0Ch,OOrjZaTIVXQ2Sp0ozhc)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==1013: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = trcCz1Yl2KPSFXs7LG8BTnyJukE()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==1014: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = muprY61tfc48dqhCvQZ7A(kOTdpYrPqu5A7UIcW0Ch,OOrjZaTIVXQ2Sp0ozhc)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==1015: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = idwVOZPCz6ylcQJFuj2ThWrXqnK(OOrjZaTIVXQ2Sp0ozhc)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==1016: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = Y6Kl4e1kG3uLU2djP0wI7xqTtRXZ(OOrjZaTIVXQ2Sp0ozhc)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==1018: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = kyHFVNiUe3d8Dj6IpbcvhtZ4P(OOrjZaTIVXQ2Sp0ozhc)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==1019: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(OOrjZaTIVXQ2Sp0ozhc,False)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder','بحث جوجل جديد',nA5dhMRg6ENzsB0l1GwvH7aIr2,1019)
	TBt8bUDo9WhL('link','كيف يعمل بحث جوجل','',1013)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+'==== كلمات البحث المخزنة ===='+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	t6vW1oSB4we7hVM283yK0dO = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,'dict','GLOBALSEARCH_SPLITTED_GOOGLE')
	if t6vW1oSB4we7hVM283yK0dO:
		t6vW1oSB4we7hVM283yK0dO = t6vW1oSB4we7hVM283yK0dO['__SEQUENCED_COLUMNS__']
		for BBFVq0I5Ecsl in reversed(t6vW1oSB4we7hVM283yK0dO):
			TBt8bUDo9WhL('folder',BBFVq0I5Ecsl,nA5dhMRg6ENzsB0l1GwvH7aIr2,1019,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,BBFVq0I5Ecsl)
	return
def kyHFVNiUe3d8Dj6IpbcvhtZ4P(search):
	WULrxiSjG3d1Cemza7Kc(search,True)
	AA5FS4hUqeP9EsZCM(FFKncZx5pDTwdiJRYhMgQSNL)
	return
def WULrxiSjG3d1Cemza7Kc(search,U51824ZLoeM7tmGD=False):
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O = search.replace(DjKrTPWEFw2YeCi5d6unBqhZSlAR,nA5dhMRg6ENzsB0l1GwvH7aIr2).lower()
	Ax1IaT0ydq6Rgbk8vlrftHMWi,MEnXPShcasv5dzF0b2oguUq,ZINygqCpSfajKL8hE = [],[],[]
	if not U51824ZLoeM7tmGD:
		Ax1IaT0ydq6Rgbk8vlrftHMWi = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,'list','GOOGLESEARCH_RESULTS',hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O)
		if Ax1IaT0ydq6Rgbk8vlrftHMWi: MEnXPShcasv5dzF0b2oguUq,ZINygqCpSfajKL8hE = Ax1IaT0ydq6Rgbk8vlrftHMWi
	if U51824ZLoeM7tmGD or not Ax1IaT0ydq6Rgbk8vlrftHMWi:
		import BBFeHcDpy6
		BBFeHcDpy6.RImJK3US8zW1h6iFgkE4Dp(hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,'_GOOGLE',True)
		xRyaw4fugAjZqInbvXco5OM3st9 = ouF7O6qkpnKtBNYjy(hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O)
		for CQtNwXGVAJ2y5nBY in xRyaw4fugAjZqInbvXco5OM3st9:
			name,ZylHkumQ8zD0,title,text,RXWNJBhqwMoFUjv4at,whXU4NCbPdFAcxErVJIutR8WDM3n = CQtNwXGVAJ2y5nBY
			if whXU4NCbPdFAcxErVJIutR8WDM3n in f6U7kuwg2zqXCTx0Gs8HJh1v: MEnXPShcasv5dzF0b2oguUq.append(CQtNwXGVAJ2y5nBY)
			else: ZINygqCpSfajKL8hE.append(CQtNwXGVAJ2y5nBY)
		MEnXPShcasv5dzF0b2oguUq = sorted(MEnXPShcasv5dzF0b2oguUq,reverse=FFKncZx5pDTwdiJRYhMgQSNL,key=lambda key: key[IpFcwrWNgefMym3qta0hYQAzOdE])
		ZINygqCpSfajKL8hE = sorted(ZINygqCpSfajKL8hE,reverse=FFKncZx5pDTwdiJRYhMgQSNL,key=lambda key: key[IpFcwrWNgefMym3qta0hYQAzOdE])
		WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,'GOOGLESEARCH_RESULTS',hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,[MEnXPShcasv5dzF0b2oguUq,ZINygqCpSfajKL8hE],KcwozFY2DsR3jSBO)
		aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,'GLOBALSEARCH_DETAILED_GOOGLE',hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O)
		BBFeHcDpy6.RImJK3US8zW1h6iFgkE4Dp(hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,'_GOOGLE',False)
		aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,'GLOBALSEARCH_DIVIDED_GOOGLE',"%, '"+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O+"')")
		if MEnXPShcasv5dzF0b2oguUq: OmxJV4UQyeFqdBSIC0('','',OksCHeoL5SG,'تم عمل بحث جوجل جديد وتم إيجاد\n\n'+str(len(MEnXPShcasv5dzF0b2oguUq))+'  مواقع')
		else: MEnXPShcasv5dzF0b2oguUq,ZINygqCpSfajKL8hE = BUFcw3rjokLfq4IJHS(hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,FFKncZx5pDTwdiJRYhMgQSNL)
	TBt8bUDo9WhL('link','بحث جماعي لمواقع جوجل','search_sites_google',1012,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O)
	TBt8bUDo9WhL('folder','بحث منفرد لمواقع جوجل',nA5dhMRg6ENzsB0l1GwvH7aIr2,1011,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+'===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder','نتائج البحث مفصلة - '+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,'opened_sites_google',1012,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O)
	TBt8bUDo9WhL('folder','نتائج البحث مقسمة - '+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,'listed_sites_google',1012,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+'===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder','مواقع جوجل ('+str(len(MEnXPShcasv5dzF0b2oguUq))+') - '+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,'',1016,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O)
	TBt8bUDo9WhL('link','إعادة بحث جوجل - '+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,'',1018,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,search)
	return
def Y6Kl4e1kG3uLU2djP0wI7xqTtRXZ(hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O):
	MEnXPShcasv5dzF0b2oguUq,ZINygqCpSfajKL8hE = BUFcw3rjokLfq4IJHS(hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O)
	if not MEnXPShcasv5dzF0b2oguUq and not ZINygqCpSfajKL8hE: return
	JAqWpmkt3D = {}
	for name,ZylHkumQ8zD0,title,text,RXWNJBhqwMoFUjv4at,whXU4NCbPdFAcxErVJIutR8WDM3n in MEnXPShcasv5dzF0b2oguUq: JAqWpmkt3D[whXU4NCbPdFAcxErVJIutR8WDM3n] = name,ZylHkumQ8zD0,title,text,RXWNJBhqwMoFUjv4at,whXU4NCbPdFAcxErVJIutR8WDM3n
	RjieJlz6cK10gSqrLa8k3TQWwAtm = list(JAqWpmkt3D.keys())
	import BBFeHcDpy6
	Cp1gVNwaYDlZ7 = BBFeHcDpy6.RL95rqviDebl4jcWynm7VEaug2(RjieJlz6cK10gSqrLa8k3TQWwAtm)
	for whXU4NCbPdFAcxErVJIutR8WDM3n in Cp1gVNwaYDlZ7:
		if isinstance(whXU4NCbPdFAcxErVJIutR8WDM3n,tuple):
			Nzp9Fq5cTr.menuItemsLIST.append(whXU4NCbPdFAcxErVJIutR8WDM3n)
			continue
		name,ZylHkumQ8zD0,title,text,RXWNJBhqwMoFUjv4at,whXU4NCbPdFAcxErVJIutR8WDM3n = JAqWpmkt3D[whXU4NCbPdFAcxErVJIutR8WDM3n]
		hT9D8fRSNgycG36k,vlm7dBDy2RXPj1C8,CYv7ydT6WAGtu0o = EN1Pg52zbjsmLMQq9(whXU4NCbPdFAcxErVJIutR8WDM3n)
		TBt8bUDo9WhL('folder',CYv7ydT6WAGtu0o+name,ZylHkumQ8zD0,1014,RXWNJBhqwMoFUjv4at,'',whXU4NCbPdFAcxErVJIutR8WDM3n)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+'===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+'مواقع بجوجل غير موجودة بالبرنامج'+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,1015)
	ZINygqCpSfajKL8hE = sorted(ZINygqCpSfajKL8hE,reverse=FFKncZx5pDTwdiJRYhMgQSNL,key=lambda key: key[IpFcwrWNgefMym3qta0hYQAzOdE])
	for name,ZylHkumQ8zD0,title,text,RXWNJBhqwMoFUjv4at,whXU4NCbPdFAcxErVJIutR8WDM3n in ZINygqCpSfajKL8hE:
		TBt8bUDo9WhL('link','_GOS_'+name,ZylHkumQ8zD0,1015,RXWNJBhqwMoFUjv4at,'',whXU4NCbPdFAcxErVJIutR8WDM3n)
	return
def BUFcw3rjokLfq4IJHS(hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,BAsdPIYwTrc0LVzRQ=S5MWhgtZ37Xw):
	MEnXPShcasv5dzF0b2oguUq,ZINygqCpSfajKL8hE = [],[]
	if BAsdPIYwTrc0LVzRQ:
		Ax1IaT0ydq6Rgbk8vlrftHMWi = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,'list','GOOGLESEARCH_RESULTS',hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O)
		if Ax1IaT0ydq6Rgbk8vlrftHMWi: MEnXPShcasv5dzF0b2oguUq,ZINygqCpSfajKL8hE = Ax1IaT0ydq6Rgbk8vlrftHMWi
	if not MEnXPShcasv5dzF0b2oguUq and not ZINygqCpSfajKL8hE: OmxJV4UQyeFqdBSIC0('','',OksCHeoL5SG,'للأسف جوجل لم يجد مواقع فيها طلبك')
	return MEnXPShcasv5dzF0b2oguUq,ZINygqCpSfajKL8hE
def b8CYRyuWGNqK(hz2HnpMwOAQ9asERGCForbqWSK,hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O):
	MEnXPShcasv5dzF0b2oguUq,ZINygqCpSfajKL8hE = BUFcw3rjokLfq4IJHS(hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O)
	if not MEnXPShcasv5dzF0b2oguUq and not ZINygqCpSfajKL8hE: return
	Pl2FLE9g7hBfTa0Yq4V8CG,MBACYaWL2kKh8d9H = [],{}
	for name,ZylHkumQ8zD0,title,text,RXWNJBhqwMoFUjv4at,whXU4NCbPdFAcxErVJIutR8WDM3n in MEnXPShcasv5dzF0b2oguUq:
		Pl2FLE9g7hBfTa0Yq4V8CG.append(whXU4NCbPdFAcxErVJIutR8WDM3n)
		MBACYaWL2kKh8d9H[whXU4NCbPdFAcxErVJIutR8WDM3n] = EPDRzo65tCvaiM8pQmH(text)
	import BBFeHcDpy6
	BBFeHcDpy6.TJIrM3ouekXGqpdl76nmNwth(hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O,hz2HnpMwOAQ9asERGCForbqWSK,nA5dhMRg6ENzsB0l1GwvH7aIr2,Pl2FLE9g7hBfTa0Yq4V8CG,MBACYaWL2kKh8d9H)
	return
def K7qnaV43rZ2o0tNmPQEc(hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O):
	MEnXPShcasv5dzF0b2oguUq,ZINygqCpSfajKL8hE = BUFcw3rjokLfq4IJHS(hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O)
	if not MEnXPShcasv5dzF0b2oguUq and not ZINygqCpSfajKL8hE: return
	JAqWpmkt3D = {}
	for name,ZylHkumQ8zD0,title,text,RXWNJBhqwMoFUjv4at,whXU4NCbPdFAcxErVJIutR8WDM3n in MEnXPShcasv5dzF0b2oguUq:
		JAqWpmkt3D[whXU4NCbPdFAcxErVJIutR8WDM3n] = name,ZylHkumQ8zD0,title,text,RXWNJBhqwMoFUjv4at,whXU4NCbPdFAcxErVJIutR8WDM3n
	RjieJlz6cK10gSqrLa8k3TQWwAtm = list(JAqWpmkt3D.keys())
	import BBFeHcDpy6
	Cp1gVNwaYDlZ7 = BBFeHcDpy6.RL95rqviDebl4jcWynm7VEaug2(RjieJlz6cK10gSqrLa8k3TQWwAtm)
	for whXU4NCbPdFAcxErVJIutR8WDM3n in Cp1gVNwaYDlZ7:
		if isinstance(whXU4NCbPdFAcxErVJIutR8WDM3n,tuple):
			Nzp9Fq5cTr.menuItemsLIST.append(whXU4NCbPdFAcxErVJIutR8WDM3n)
			continue
		name,ZylHkumQ8zD0,title,text,RXWNJBhqwMoFUjv4at,whXU4NCbPdFAcxErVJIutR8WDM3n = JAqWpmkt3D[whXU4NCbPdFAcxErVJIutR8WDM3n]
		hT9D8fRSNgycG36k,vlm7dBDy2RXPj1C8,CYv7ydT6WAGtu0o = EN1Pg52zbjsmLMQq9(whXU4NCbPdFAcxErVJIutR8WDM3n)
		text = EPDRzo65tCvaiM8pQmH(text)
		name = name+' - '+hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O
		TBt8bUDo9WhL('folder',CYv7ydT6WAGtu0o+name,whXU4NCbPdFAcxErVJIutR8WDM3n,548,RXWNJBhqwMoFUjv4at,'',text)
	return
def EPDRzo65tCvaiM8pQmH(title):
	JfNHOP2BK1Yxl7Rq4 = PAztbuyYo4Kvd.findall('(.*?) (الحلقة|حلقة)',title,PAztbuyYo4Kvd.DOTALL)
	g7qwMTAPoVpIyQUaDeNOnhvs = JfNHOP2BK1Yxl7Rq4[0][0] if JfNHOP2BK1Yxl7Rq4 else title
	g7qwMTAPoVpIyQUaDeNOnhvs = g7qwMTAPoVpIyQUaDeNOnhvs.replace('مشاهدة اونلاين، فيديو، الإعلان، صور - السينما.كوم','').replace('- ‎عرب سيد - Arabseed','')
	g7qwMTAPoVpIyQUaDeNOnhvs = g7qwMTAPoVpIyQUaDeNOnhvs.replace('- وى سيما wecima ماى سيما mycima - وي سيما','').replace('- فيديو Dailymotion','')
	g7qwMTAPoVpIyQUaDeNOnhvs = g7qwMTAPoVpIyQUaDeNOnhvs.replace('الموسم','').replace('الموقع','').replace('- شوف نت','').replace('موسم','').replace('HD','')
	g7qwMTAPoVpIyQUaDeNOnhvs = g7qwMTAPoVpIyQUaDeNOnhvs.replace('مشاهدة','').replace('نتائج البحث:','').replace('اونلاين','').replace('- سيما فور بي','')
	g7qwMTAPoVpIyQUaDeNOnhvs = g7qwMTAPoVpIyQUaDeNOnhvs.replace('موقع','').replace('| اكوام','').replace('','').replace('','').replace('','').replace('','')
	g7qwMTAPoVpIyQUaDeNOnhvs = g7qwMTAPoVpIyQUaDeNOnhvs.strip(' ').replace('    ',' ').replace('   ',' ').replace('  ',' ').replace('  ',' ')
	return g7qwMTAPoVpIyQUaDeNOnhvs
def ouF7O6qkpnKtBNYjy(search):
	search = search.replace(hSXlxL9iB05c,'+')
	headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0'}
	url = 'https://www.google.com/search?hl=en&filter=1&imgSize=small&safe=active&q=-youtube+-instagram+-facebook+-tiktok+-elcinema+'+search
	KteRnFMjHpBPqNf8 = url+'&start=0&num=100&tbm=vid&udm=7'
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(yy6RomT9bQhJf,'GET',KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'GOOGLESEARCH-SEARCH-1st')
	if not Y3SmVGbfNvEeakMBr.succeeded: return []
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	lyq2UgNK9FkP1mswQ0VHG5cRfzCp = XoZRpFe7B6gnfA.path.join(A1CKpbwyFL8jY4I,'googlesearch')
	if not XoZRpFe7B6gnfA.path.exists(lyq2UgNK9FkP1mswQ0VHG5cRfzCp):
		try: XoZRpFe7B6gnfA.makedirs(lyq2UgNK9FkP1mswQ0VHG5cRfzCp)
		except: pass
	items = []
	Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q = PAztbuyYo4Kvd.findall('jsname="UWckNb" href="(.*?)".*?<span.*?>(.*?).*?aria-label="(.*?)".*?src="(.*?)".*?class="cuFRh">(.*?)<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q:
		for WWU7QJP2tyTRLIfDh0csxbkvX in Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q:
			ZylHkumQ8zD0,title,text,io76Hju84PtJO3hE5x9KZnpGmalIw,name = WWU7QJP2tyTRLIfDh0csxbkvX
			io76Hju84PtJO3hE5x9KZnpGmalIw = ''
			items.append([ZylHkumQ8zD0,title,text,name,io76Hju84PtJO3hE5x9KZnpGmalIw])
	else:
		KteRnFMjHpBPqNf8 = url+'&start=0&num=200'
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(yy6RomT9bQhJf,'GET::SCRAPERS',KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'GOOGLESEARCH-SEARCH-2nd')
		if not Y3SmVGbfNvEeakMBr.succeeded: return []
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
		Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q = PAztbuyYo4Kvd.findall('(\[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,".*?\]\])',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if not Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q: Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q = PAztbuyYo4Kvd.findall('(\[None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,".*?\]\])',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		for WWU7QJP2tyTRLIfDh0csxbkvX in Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q:
			WWU7QJP2tyTRLIfDh0csxbkvX = BwGPDSQOlfUas2n3eIH0ycFRWZ('list',WWU7QJP2tyTRLIfDh0csxbkvX)
			if len(WWU7QJP2tyTRLIfDh0csxbkvX)>17:
				ZylHkumQ8zD0 = WWU7QJP2tyTRLIfDh0csxbkvX[17]
				title,text,name,io76Hju84PtJO3hE5x9KZnpGmalIw = WWU7QJP2tyTRLIfDh0csxbkvX[31][0:4]
				items.append([ZylHkumQ8zD0,title,text,name,io76Hju84PtJO3hE5x9KZnpGmalIw])
	Fqa12CQZ3Wp,WGAmVXrOBCIvM7L = [],[]
	for CQtNwXGVAJ2y5nBY in items:
		ZylHkumQ8zD0,title,text,name,io76Hju84PtJO3hE5x9KZnpGmalIw = CQtNwXGVAJ2y5nBY
		name = name.strip(' ')
		if not name: name = C2gnJ5tXFk9pAL(ZylHkumQ8zD0,'name')
		name = AIWw30xBhusg(name)
		if 'http://' in io76Hju84PtJO3hE5x9KZnpGmalIw or 'https://' in io76Hju84PtJO3hE5x9KZnpGmalIw: RXWNJBhqwMoFUjv4at = io76Hju84PtJO3hE5x9KZnpGmalIw
		elif 'data:image/' in io76Hju84PtJO3hE5x9KZnpGmalIw and ';base64,' in io76Hju84PtJO3hE5x9KZnpGmalIw:
			gzUIcRjKqf0Gt342dVWC5PSZBh = PAztbuyYo4Kvd.findall('data:image/(\w+);base64,',io76Hju84PtJO3hE5x9KZnpGmalIw)
			gzUIcRjKqf0Gt342dVWC5PSZBh = gzUIcRjKqf0Gt342dVWC5PSZBh[0]
			RXWNJBhqwMoFUjv4at = XoZRpFe7B6gnfA.path.join(lyq2UgNK9FkP1mswQ0VHG5cRfzCp,name+'.'+gzUIcRjKqf0Gt342dVWC5PSZBh)
			if not XoZRpFe7B6gnfA.path.exists(RXWNJBhqwMoFUjv4at):
				io76Hju84PtJO3hE5x9KZnpGmalIw = io76Hju84PtJO3hE5x9KZnpGmalIw.replace('\\u003d','=')
				io76Hju84PtJO3hE5x9KZnpGmalIw = io76Hju84PtJO3hE5x9KZnpGmalIw.replace('data:image/'+gzUIcRjKqf0Gt342dVWC5PSZBh+';base64,','')
				ZMO7fdhSA6IX0wNu8JjvcplV4B = Ic92Lb6lnzM5KJsx4Y3UGa70imZo.b64decode(io76Hju84PtJO3hE5x9KZnpGmalIw)
				open(RXWNJBhqwMoFUjv4at,'wb').write(ZMO7fdhSA6IX0wNu8JjvcplV4B)
		else: RXWNJBhqwMoFUjv4at = ''
		whXU4NCbPdFAcxErVJIutR8WDM3n = TW9hMHXOSrm1kpwGb6vnEgR(name,ZylHkumQ8zD0)
		if whXU4NCbPdFAcxErVJIutR8WDM3n not in WGAmVXrOBCIvM7L:
			WGAmVXrOBCIvM7L.append(whXU4NCbPdFAcxErVJIutR8WDM3n)
			name = AEyNnLOu7g6BGrw5tlcj(whXU4NCbPdFAcxErVJIutR8WDM3n)
			Fqa12CQZ3Wp.append([name,ZylHkumQ8zD0,title,text,RXWNJBhqwMoFUjv4at,whXU4NCbPdFAcxErVJIutR8WDM3n])
	return Fqa12CQZ3Wp
def muprY61tfc48dqhCvQZ7A(ZylHkumQ8zD0,whXU4NCbPdFAcxErVJIutR8WDM3n):
	hT9D8fRSNgycG36k,vlm7dBDy2RXPj1C8,CYv7ydT6WAGtu0o = EN1Pg52zbjsmLMQq9(whXU4NCbPdFAcxErVJIutR8WDM3n)
	if CYv7ydT6WAGtu0o: hT9D8fRSNgycG36k()
	else: idwVOZPCz6ylcQJFuj2ThWrXqnK()
	return
def trcCz1Yl2KPSFXs7LG8BTnyJukE():
	OmxJV4UQyeFqdBSIC0('','',OksCHeoL5SG,'هذا البحث يستخدم ذكاء وشمولية وسرعة محرك بحث جوجل .. ونتائج هذا البحث هي أسماء مواقع الإنترنت التي موجودة في هذا البرنامج والتي فيها الفيديوهات المطلوبة\n\nهذا البحث يحتاج كلمات بحث عادية جدا بدون أي مراعاة لدقة الكلمات أو تفاصيل الفيديوهات أو حتى إملاء الكلمات\n\nهذا البحث يستطيع أيضا أن يفحص محتويات المواقع التي وجدها جوجل إذا كانت هذه المواقع موجودة بهذا البرنامج')
	return
def idwVOZPCz6ylcQJFuj2ThWrXqnK(whXU4NCbPdFAcxErVJIutR8WDM3n=''):
	OmxJV4UQyeFqdBSIC0('','',whXU4NCbPdFAcxErVJIutR8WDM3n,'هذا الموقع غير موجود في البرنامج .. أو أسم الموقع مختلف وغير مطابق للاسم المستخدم في البرنامج')
	return
def TW9hMHXOSrm1kpwGb6vnEgR(name,ZylHkumQ8zD0):
	iAdDS3jhG4eTmX = {
	 'فشار فيديو مشاهدة افلام ومسلسلات اون لاين'	:'FUSHARVIDEO'
	,'وى سيما wecima ماى سيما mycima'			:'WECIMA1'
	,'شبكتي تي في - SHABAKATY TV'				:'SHABAKATY'
	,'اكوام  شبكة اكوام AKWAM'					:'AKWAM'
	,'سيما كلوب  CIMACLUB'						:'CIMACLUB'
	,'سيما فري CIMAFREE':'CIMAFREE'
	,'هلا سيما'			:'HALACIMA'
	,'لاروزا'			:'LAROZA'
	,'برستيج'			:'BRSTEJ'
	,'كرمالك TV'		:'KIRMALK'
	,'سيما فور بي'		:'CIMA4P'
	,'اهواك تي في'		:'AHWAK'
	,'CIMA CLUB'		:'CIMACLUB'
	,'اكوام'			:'AKWAM'
	,'وي سيما'			:'WECIMA1'
	,'سيما ناو'			:'CIMANOW'
	,'سيما لايت'			:'CIMALIGHT'
	,'موقع ماي سيما'	:'CIMALIGHT'
	,'عرب سيد'			:'ARABSEED'
	,'فيديو ياقوت'		:'YAQOT'
	,'المصطبة TV'		:'ALMSTBA'
	,'دراما كافيه'		:'DRAMACAFE'
	,'سيما 400'			:'CIMA400'
	,'فيديو تكات'		:'TIKAAT'
	,'السينما.كوم'		:'ELCINEMA'
	,'فوستا'			:'FOSTA'
	,'سيما عبدو'		:'CIMAABDO'
	,'فاصل إعلاني'		:'FASELHD1'
	,'مسلسلات تايم'		:'SERIESTIME'
	,'شوف نت'			:'SHOOFNET'
	}
	gO2PcxfG7Yhd = name.lower()
	UwQYtvDH9oc8nOemluxdCXKr2JN = ''
	for key in list(iAdDS3jhG4eTmX.keys()):
		if key.lower() in gO2PcxfG7Yhd: UwQYtvDH9oc8nOemluxdCXKr2JN = iAdDS3jhG4eTmX[key]
	if not UwQYtvDH9oc8nOemluxdCXKr2JN:
		ww5oBKPZmc = C2gnJ5tXFk9pAL(ZylHkumQ8zD0,'url')
		for whXU4NCbPdFAcxErVJIutR8WDM3n in list(Nzp9Fq5cTr.SITESURLS.keys()):
			nBr8XhiEG37A5LCad6fJm = C2gnJ5tXFk9pAL(Nzp9Fq5cTr.SITESURLS[whXU4NCbPdFAcxErVJIutR8WDM3n][0],'url')
			if ww5oBKPZmc==nBr8XhiEG37A5LCad6fJm: UwQYtvDH9oc8nOemluxdCXKr2JN = whXU4NCbPdFAcxErVJIutR8WDM3n
	if not UwQYtvDH9oc8nOemluxdCXKr2JN:
		gO2PcxfG7Yhd = C2gnJ5tXFk9pAL(ZylHkumQ8zD0,'name')
		for whXU4NCbPdFAcxErVJIutR8WDM3n in list(Nzp9Fq5cTr.SITESURLS.keys()):
			dKbZ5BoNe0FLfmMlYyDSwCEQ1kX4AG = C2gnJ5tXFk9pAL(Nzp9Fq5cTr.SITESURLS[whXU4NCbPdFAcxErVJIutR8WDM3n][0],'name')
			if gO2PcxfG7Yhd==dKbZ5BoNe0FLfmMlYyDSwCEQ1kX4AG: UwQYtvDH9oc8nOemluxdCXKr2JN = whXU4NCbPdFAcxErVJIutR8WDM3n
	if not UwQYtvDH9oc8nOemluxdCXKr2JN: UwQYtvDH9oc8nOemluxdCXKr2JN = name
	UwQYtvDH9oc8nOemluxdCXKr2JN = UwQYtvDH9oc8nOemluxdCXKr2JN.upper()
	return UwQYtvDH9oc8nOemluxdCXKr2JN
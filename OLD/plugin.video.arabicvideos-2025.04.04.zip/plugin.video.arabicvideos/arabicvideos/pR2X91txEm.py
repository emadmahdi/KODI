# -*- coding: utf-8 -*-
import sys as kCNHMOym1luTnJ0
MigYEN1cxduFB2lpk5 = kCNHMOym1luTnJ0.version_info [0] == 2
xJ3XdNcV5IujAkoGh = 2048
aE71QiuHI95zfPRBUsntedWZJ2bl = 7
def vR1b8iCLa9Qy2Sw5OYAlWXNhZp37 (AGxE4RIvuC6):
	global peWEVn47JRXo916j
	Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky = ord (AGxE4RIvuC6 [-1])
	FXUjnSw308z = AGxE4RIvuC6 [:-1]
	f81LoVwXMpQkvdKcmPyj6NzBlt = Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky % len (FXUjnSw308z)
	qyKv5nBTxgkQSlJ0aNP1CUmpjYLZ = FXUjnSw308z [:f81LoVwXMpQkvdKcmPyj6NzBlt] + FXUjnSw308z [f81LoVwXMpQkvdKcmPyj6NzBlt:]
	if MigYEN1cxduFB2lpk5:
		H0yFJ5LDCGYpIM1BViZKTSgv3jXr = unicode () .join ([unichr (ord (Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286) - xJ3XdNcV5IujAkoGh - (MfwWyztdYVXURgPqLrITku3CxF1 + Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky) % aE71QiuHI95zfPRBUsntedWZJ2bl) for MfwWyztdYVXURgPqLrITku3CxF1, Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286 in enumerate (qyKv5nBTxgkQSlJ0aNP1CUmpjYLZ)])
	else:
		H0yFJ5LDCGYpIM1BViZKTSgv3jXr = str () .join ([chr (ord (Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286) - xJ3XdNcV5IujAkoGh - (MfwWyztdYVXURgPqLrITku3CxF1 + Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky) % aE71QiuHI95zfPRBUsntedWZJ2bl) for MfwWyztdYVXURgPqLrITku3CxF1, Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286 in enumerate (qyKv5nBTxgkQSlJ0aNP1CUmpjYLZ)])
	return eval (H0yFJ5LDCGYpIM1BViZKTSgv3jXr)
Yj1msqVeivESfrCupRy9b7WacBd,XEcWOIwkZKubV7vQ,Pj9YaUq1ibJ=vR1b8iCLa9Qy2Sw5OYAlWXNhZp37,vR1b8iCLa9Qy2Sw5OYAlWXNhZp37,vR1b8iCLa9Qy2Sw5OYAlWXNhZp37
HD7MQqXd2gS,yPE2t1Co4YQDfsIecdxu0Gklq6AvO,bqCDnV7Bs5XgRvuKLNAa1Uz=Pj9YaUq1ibJ,XEcWOIwkZKubV7vQ,Yj1msqVeivESfrCupRy9b7WacBd
YIsyNBocg6fV3wEWPSu9GtvHxLOqDi,VVstJA9bfOqunLF0oaSgWUKHDdYNz,nfNTgkiWdUq=bqCDnV7Bs5XgRvuKLNAa1Uz,yPE2t1Co4YQDfsIecdxu0Gklq6AvO,HD7MQqXd2gS
FVxoQ2J5Mfv3Zj6sy9uhOS,n8BrpFLyaMAC1vP0bOHgwxEzeGRV,UUobzy0xZLaVScIt7=nfNTgkiWdUq,VVstJA9bfOqunLF0oaSgWUKHDdYNz,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi
JvQd6LMoBX4hiy1C,ZjELJ9VrUT07R8Hn4FuSDcf,pxt6wJ8ScYMWCivoO=UUobzy0xZLaVScIt7,n8BrpFLyaMAC1vP0bOHgwxEzeGRV,FVxoQ2J5Mfv3Zj6sy9uhOS
lw2snZ9J0uhLoxypqa,LJqSQvuhf7aMmnVjy23FbZBckKzx9l,gmPI7hVEM8nD=pxt6wJ8ScYMWCivoO,ZjELJ9VrUT07R8Hn4FuSDcf,JvQd6LMoBX4hiy1C
w0ivtSjV2sZDQoT1OEugIla7R6AC5M,rCmGE4YIDaZA,vzqjsVHSBlMpxC=gmPI7hVEM8nD,LJqSQvuhf7aMmnVjy23FbZBckKzx9l,lw2snZ9J0uhLoxypqa
xwIUQfiE7rmvYzH,ldIfvn6asURQ9toi85EhqAXW3,bb1fgjsAq4N2xYwnoh39lm=vzqjsVHSBlMpxC,rCmGE4YIDaZA,w0ivtSjV2sZDQoT1OEugIla7R6AC5M
AJHaiQq3PRd5cphzGuELnVg9X,jil8vRpBsENVYyPmDd,PPxYugzLZwHX23yiK=bb1fgjsAq4N2xYwnoh39lm,ldIfvn6asURQ9toi85EhqAXW3,xwIUQfiE7rmvYzH
baBcNd81eH5ry2Olp6Mj43,Qy6wlfLoOpg1,mRanX1HZupfSQVB2gsDGUO=PPxYugzLZwHX23yiK,jil8vRpBsENVYyPmDd,AJHaiQq3PRd5cphzGuELnVg9X
bDxWcjmaSgFeRKrfpJvyA4zThi,DFx6E0uON7Jm8,zhE5I4xHinX0UoVZMNwlkPrR=mRanX1HZupfSQVB2gsDGUO,Qy6wlfLoOpg1,baBcNd81eH5ry2Olp6Mj43
from ZtD8eQAKnl import *
import base64 as Ic92Lb6lnzM5KJsx4Y3UGa70imZo
wgj0rX5tbcxPulhmny = JvQd6LMoBX4hiy1C(u"ࠨࡎࡌࡆࡘ࡚ࡗࡐࠩฝ")
if BsLJ7p5Av2Vm0SQeCO1o:
	GAu38kbFlWcSQO = OmGz648BbVsqJjT9FukShIlH.translatePath(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡾࡢ࡮ࡥࠪพ"))
	kkjOSvrlpDJNcqVIwUBt3 = OmGz648BbVsqJjT9FukShIlH.translatePath(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫฟ"))
	iTQzLPEURbp943ulcfWwear = OmGz648BbVsqJjT9FukShIlH.translatePath(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯࡭ࡱࡪࡴࡦࡺࡨࠨภ"))
	NS8ELxPk4JMTa2gzrHjnoh = XoZRpFe7B6gnfA.path.join(kkjOSvrlpDJNcqVIwUBt3,nfNTgkiWdUq(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧม"),UUobzy0xZLaVScIt7(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨย"),jil8vRpBsENVYyPmDd(u"ࠧࡂࡦࡧࡳࡳࡹ࠳࠴࠰ࡧࡦࠬร"))
	h4cvzRIWJ127fZMEHkr = XoZRpFe7B6gnfA.path.join(kkjOSvrlpDJNcqVIwUBt3,PPxYugzLZwHX23yiK(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪฤ"),bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫล"),zhE5I4xHinX0UoVZMNwlkPrR(u"࡚ࠪ࡮࡫ࡷࡎࡱࡧࡩࡸ࠼࠮ࡥࡤࠪฦ"))
	PSZn6Ac25XlT8bjQe = XoZRpFe7B6gnfA.path.join(kkjOSvrlpDJNcqVIwUBt3,XEcWOIwkZKubV7vQ(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭ว"),vzqjsVHSBlMpxC(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧศ"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠭ࡔࡦࡺࡷࡹࡷ࡫ࡳ࠲࠵࠱ࡨࡧ࠭ษ"))
	pRYO3SUfqaTdlW4jhrV6xI = UUobzy0xZLaVScIt7(u"ࡵࠨ࡞ࡸ࠴࠷ࡪ࠱ࠨส")
	from urllib.parse import quote as _NaTjlhXKH6xcpF8evw
else:
	GAu38kbFlWcSQO = SoNGUfhMDERLyHOz1qkVAj.translatePath(HD7MQqXd2gS(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡽࡨ࡭ࡤࠩห"))
	kkjOSvrlpDJNcqVIwUBt3 = SoNGUfhMDERLyHOz1qkVAj.translatePath(Pj9YaUq1ibJ(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴࡮࡯࡮ࡧࠪฬ"))
	iTQzLPEURbp943ulcfWwear = SoNGUfhMDERLyHOz1qkVAj.translatePath(ldIfvn6asURQ9toi85EhqAXW3(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵࡬ࡰࡩࡳࡥࡹ࡮ࠧอ"))
	NS8ELxPk4JMTa2gzrHjnoh = XoZRpFe7B6gnfA.path.join(kkjOSvrlpDJNcqVIwUBt3,LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭ฮ"),n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧฯ"),ZjELJ9VrUT07R8Hn4FuSDcf(u"࠭ࡁࡥࡦࡲࡲࡸ࠸࠷࠯ࡦࡥࠫะ"))
	h4cvzRIWJ127fZMEHkr = XoZRpFe7B6gnfA.path.join(kkjOSvrlpDJNcqVIwUBt3,n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩั"),zhE5I4xHinX0UoVZMNwlkPrR(u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪา"),AJHaiQq3PRd5cphzGuELnVg9X(u"࡙ࠩ࡭ࡪࡽࡍࡰࡦࡨࡷ࠻࠴ࡤࡣࠩำ"))
	PSZn6Ac25XlT8bjQe = XoZRpFe7B6gnfA.path.join(kkjOSvrlpDJNcqVIwUBt3,PPxYugzLZwHX23yiK(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬิ"),rCmGE4YIDaZA(u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭ี"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࡚ࠬࡥࡹࡶࡸࡶࡪࡹ࠱࠴࠰ࡧࡦࠬึ"))
	pRYO3SUfqaTdlW4jhrV6xI = rCmGE4YIDaZA(u"ࡻࠧ࡝ࡷ࠳࠶ࡩ࠷ࠧื").encode(YWEQ3Cf8RevpD0m7NjF1)
	from urllib import quote as _NaTjlhXKH6xcpF8evw
Mtgex07pkPUj6z = XoZRpFe7B6gnfA.path.join(iTQzLPEURbp943ulcfWwear,bb1fgjsAq4N2xYwnoh39lm(u"ࠧ࡬ࡱࡧ࡭࠳ࡲ࡯ࡨุࠩ"))
JRUTFhVSfB5wjt6YL = XoZRpFe7B6gnfA.path.join(iTQzLPEURbp943ulcfWwear,n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠨ࡭ࡲࡨ࡮࠴࡯࡭ࡦ࠱ࡰࡴ࡭ูࠧ"))
T9mAsfqv0P1rlyebgc47OdFYzUiG5J = XoZRpFe7B6gnfA.path.join(QQwBc24Oza7jJ8ClTRWexUoqGAkg0,FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠩ࡬ࡴࡹࡼ࠱ࡥࡣࡷࡥࡤࡥ࡟࠯ࡦࡥฺࠫ"))
dd6UyOGBsfSctVIv = XoZRpFe7B6gnfA.path.join(QQwBc24Oza7jJ8ClTRWexUoqGAkg0,bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠪ࡭ࡵࡺࡶ࠳ࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬ฻"))
WMxUSRTbBvhZCLXl7tn1pEzwg0ioq6 = XoZRpFe7B6gnfA.path.join(QQwBc24Oza7jJ8ClTRWexUoqGAkg0,LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠫࡲ࠹ࡵࡥࡣࡷࡥࡤࡥ࡟࠯ࡦࡥࠫ฼"))
RihlJwXFNfe1IGPu9ZcUg85qsdn = XoZRpFe7B6gnfA.path.join(QQwBc24Oza7jJ8ClTRWexUoqGAkg0,Yj1msqVeivESfrCupRy9b7WacBd(u"ࠬ࡬ࡡࡷࡱࡸࡶ࡮ࡺࡥࡴ࠰ࡧࡥࡹ࠭฽"))
t7W5qnsUTdXJjMHm = XoZRpFe7B6gnfA.path.join(QQwBc24Oza7jJ8ClTRWexUoqGAkg0,XEcWOIwkZKubV7vQ(u"࠭ࡩࡱࡶࡹࡪ࡮ࡲࡥࡠࡡࡢ࠲ࡩࡧࡴࠨ฾"))
ee1DuYUEtmy = XoZRpFe7B6gnfA.path.join(QQwBc24Oza7jJ8ClTRWexUoqGAkg0,jil8vRpBsENVYyPmDd(u"ࠧ࡮࠵ࡸࡪ࡮ࡲࡥࡠࡡࡢ࠲ࡩࡧࡴࠨ฿"))
A1CKpbwyFL8jY4I = XoZRpFe7B6gnfA.path.join(QQwBc24Oza7jJ8ClTRWexUoqGAkg0,bb1fgjsAq4N2xYwnoh39lm(u"ࠨ࡫ࡰࡥ࡬࡫ࡳࠨเ"))
gAnxlaS365LDp2y = XoZRpFe7B6gnfA.path.join(A1CKpbwyFL8jY4I,lw2snZ9J0uhLoxypqa(u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡵࠪแ"))
moqHbwiCz51GU6eBM = XoZRpFe7B6gnfA.path.join(A1CKpbwyFL8jY4I,ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡵࠪโ"))
N5F4JMDmHylghXfYS = XoZRpFe7B6gnfA.path.join(gAnxlaS365LDp2y,n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡣ࠵࠶࠰࠱ࡡ࠱ࡴࡳ࡭ࠧใ"))
mQKDw6vcXNIkngiWrC8GdPFqeRH = zw6NdxVgQW2uJiXh.Addon().getAddonInfo(baBcNd81eH5ry2Olp6Mj43(u"ࠬࡶࡡࡵࡪࠪไ"))
RSGTtbnZpQchIH6X09m3 = XoZRpFe7B6gnfA.path.join(mQKDw6vcXNIkngiWrC8GdPFqeRH,pxt6wJ8ScYMWCivoO(u"࠭ࡩࡤࡱࡱ࠲ࡵࡴࡧࠨๅ"))
xFctkpb9ZySnIfLAJ1zQMm8dPYX = XoZRpFe7B6gnfA.path.join(mQKDw6vcXNIkngiWrC8GdPFqeRH,UUobzy0xZLaVScIt7(u"ࠧࡵࡪࡸࡱࡧ࠴ࡰ࡯ࡩࠪๆ"))
VpnThC10NBF5cHdY4P = XoZRpFe7B6gnfA.path.join(mQKDw6vcXNIkngiWrC8GdPFqeRH,xwIUQfiE7rmvYzH(u"ࠨࡨࡤࡲࡦࡸࡴ࠯ࡲࡱ࡫ࠬ็"))
oOfmZ16j5XCH28MDLzA = XoZRpFe7B6gnfA.path.join(mQKDw6vcXNIkngiWrC8GdPFqeRH,UUobzy0xZLaVScIt7(u"ࠩࡥࡥࡳࡴࡥࡳ࠰ࡳࡲ࡬่࠭"))
dlf1ejnDU9IaBkxvGr = XoZRpFe7B6gnfA.path.join(mQKDw6vcXNIkngiWrC8GdPFqeRH,lw2snZ9J0uhLoxypqa(u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠴ࡰ࡯ࡩ้ࠪ"))
E8JjfC9NdeHq = XoZRpFe7B6gnfA.path.join(mQKDw6vcXNIkngiWrC8GdPFqeRH,nfNTgkiWdUq(u"ࠫࡵࡵࡳࡵࡧࡵ࠲ࡵࡴࡧࠨ๊"))
f5X7lZ8C2LFokR4 = XoZRpFe7B6gnfA.path.join(mQKDw6vcXNIkngiWrC8GdPFqeRH,DFx6E0uON7Jm8(u"ࠬࡩ࡬ࡦࡣࡵࡰࡴ࡭࡯࠯ࡲࡱ࡫๋ࠬ"))
ttfdmLWovsbBN0FyIT1kXJK43unYMi = XoZRpFe7B6gnfA.path.join(mQKDw6vcXNIkngiWrC8GdPFqeRH,AJHaiQq3PRd5cphzGuELnVg9X(u"࠭ࡣ࡭ࡧࡤࡶࡦࡸࡴ࠯ࡲࡱ࡫ࠬ์"))
auGIdBD3XOJ7 = XoZRpFe7B6gnfA.path.join(mQKDw6vcXNIkngiWrC8GdPFqeRH,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠧ࡮ࡧࡱࡹࡤࡸࡥࡥࡡ࠵࠴࠵ࡾ࠲࠶࠲࠱ࡴࡳ࡭ࠧํ"))
DzNFIcTdp0e = XoZRpFe7B6gnfA.path.join(mQKDw6vcXNIkngiWrC8GdPFqeRH,JvQd6LMoBX4hiy1C(u"ࠨࡥ࡫ࡥࡳ࡭ࡥ࡭ࡱࡪ࠲ࡹࡾࡴࠨ๎"))
y9SrAlWpbuYgeEQ = XoZRpFe7B6gnfA.path.join(kkjOSvrlpDJNcqVIwUBt3,w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠩࡤࡨࡩࡵ࡮ࡴࠩ๏"))
T6NIoa8vxGjn5HUh0wS9iY = XoZRpFe7B6gnfA.path.join(kkjOSvrlpDJNcqVIwUBt3,baBcNd81eH5ry2Olp6Mj43(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ๐"),n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨ๑"),jmPwATvkoixS92pOuas)
LLfnMdCSp5uKc3GIzjQ17mk6APNtU2 = XoZRpFe7B6gnfA.path.join(T6NIoa8vxGjn5HUh0wS9iY,FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫ๒"))
YXaEVg2JMDik9bt = XoZRpFe7B6gnfA.path.join(GAu38kbFlWcSQO,bb1fgjsAq4N2xYwnoh39lm(u"࠭࡭ࡦࡦ࡬ࡥࠬ๓"),lw2snZ9J0uhLoxypqa(u"ࠧࡇࡱࡱࡸࡸ࠭๔"),UUobzy0xZLaVScIt7(u"ࠨࡣࡵ࡭ࡦࡲ࠮ࡵࡶࡩࠫ๕"))
aWoAQBfMe2 = set(Nzp9Fq5cTr.BADWEBSITES)
uWb2o5k9HiaF436GL8TlDIhnvXJ = [CQtNwXGVAJ2y5nBY for CQtNwXGVAJ2y5nBY in uWb2o5k9HiaF436GL8TlDIhnvXJ if CQtNwXGVAJ2y5nBY not in aWoAQBfMe2]
WOkE6hBtPfVNLJu28eFSZmTndQ = [CQtNwXGVAJ2y5nBY for CQtNwXGVAJ2y5nBY in WOkE6hBtPfVNLJu28eFSZmTndQ if CQtNwXGVAJ2y5nBY not in aWoAQBfMe2]
f6U7kuwg2zqXCTx0Gs8HJh1v = [CQtNwXGVAJ2y5nBY for CQtNwXGVAJ2y5nBY in f6U7kuwg2zqXCTx0Gs8HJh1v if CQtNwXGVAJ2y5nBY not in aWoAQBfMe2]
P4GWBlzIwnMq2 = [CQtNwXGVAJ2y5nBY for CQtNwXGVAJ2y5nBY in P4GWBlzIwnMq2 if CQtNwXGVAJ2y5nBY not in aWoAQBfMe2]
class iYAeb1pKuWtr3S52GPCh(LhHmwYu3cT1VnbGkvN5iOD):
	def __init__(sqvreZdonIByS9UthcfDbMEk,*aargs,**kkwargs):
		sqvreZdonIByS9UthcfDbMEk.choiceID = -UnOIK1WBbw2
	def onClick(sqvreZdonIByS9UthcfDbMEk,c4AluvXWZmdfsGO70b):
		if c4AluvXWZmdfsGO70b>=mRanX1HZupfSQVB2gsDGUO(u"࠺࠲࠴࠴Ꭳ"): sqvreZdonIByS9UthcfDbMEk.choiceID = c4AluvXWZmdfsGO70b-mRanX1HZupfSQVB2gsDGUO(u"࠺࠲࠴࠴Ꭳ")
		sqvreZdonIByS9UthcfDbMEk.ZSw6Tpcd8A3XLxI()
	def H41EK2XkiSsFrAh5Wy(sqvreZdonIByS9UthcfDbMEk,*aargs):
		sqvreZdonIByS9UthcfDbMEk.button0,sqvreZdonIByS9UthcfDbMEk.button1,sqvreZdonIByS9UthcfDbMEk.button2 = aargs[IpFcwrWNgefMym3qta0hYQAzOdE],aargs[UnOIK1WBbw2],aargs[udq5tP0hwifHQCGYELDbOUI]
		sqvreZdonIByS9UthcfDbMEk.header,sqvreZdonIByS9UthcfDbMEk.text = aargs[AH0zdvBqibaXY],aargs[tpMX1Bgs0bzv8OEafyW]
		sqvreZdonIByS9UthcfDbMEk.profile,sqvreZdonIByS9UthcfDbMEk.direction = aargs[rCmGE4YIDaZA(u"࠷Ꭴ")],aargs[mRanX1HZupfSQVB2gsDGUO(u"࠹Ꭵ")]
		sqvreZdonIByS9UthcfDbMEk.buttonstimeout,sqvreZdonIByS9UthcfDbMEk.closetimeout = aargs[Qy6wlfLoOpg1(u"࠼Ꭷ")],aargs[mRanX1HZupfSQVB2gsDGUO(u"࠼Ꭶ")]
		if sqvreZdonIByS9UthcfDbMEk.buttonstimeout>IpFcwrWNgefMym3qta0hYQAzOdE or sqvreZdonIByS9UthcfDbMEk.closetimeout>xwIUQfiE7rmvYzH(u"࠶Ꭸ"): sqvreZdonIByS9UthcfDbMEk.enable_progressbar = S5MWhgtZ37Xw
		else: sqvreZdonIByS9UthcfDbMEk.enable_progressbar = FFKncZx5pDTwdiJRYhMgQSNL
		sqvreZdonIByS9UthcfDbMEk.image_filename = N5F4JMDmHylghXfYS.replace(w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠩࡢ࠴࠵࠶࠰ࡠࠩ๖"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠪࡣࠬ๗")+str(h0skHe7TcIY9x1UP5VBrZAE8dKGnl.time())+gmPI7hVEM8nD(u"ࠫࡤ࠭๘"))
		sqvreZdonIByS9UthcfDbMEk.image_filename = sqvreZdonIByS9UthcfDbMEk.image_filename.replace(baBcNd81eH5ry2Olp6Mj43(u"ࠬࡢ࡜ࠨ๙"),ZjELJ9VrUT07R8Hn4FuSDcf(u"࠭࡜࡝࡞࡟ࠫ๚")).replace(jil8vRpBsENVYyPmDd(u"ࠧ࠰࠱ࠪ๛"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠨ࠱࠲࠳࠴࠭๜"))
		sqvreZdonIByS9UthcfDbMEk.image_height = Nru4ln6fMS(sqvreZdonIByS9UthcfDbMEk.button0,sqvreZdonIByS9UthcfDbMEk.button1,sqvreZdonIByS9UthcfDbMEk.button2,sqvreZdonIByS9UthcfDbMEk.header,sqvreZdonIByS9UthcfDbMEk.text,sqvreZdonIByS9UthcfDbMEk.profile,sqvreZdonIByS9UthcfDbMEk.direction,sqvreZdonIByS9UthcfDbMEk.enable_progressbar,sqvreZdonIByS9UthcfDbMEk.image_filename)
		sqvreZdonIByS9UthcfDbMEk.show()
		sqvreZdonIByS9UthcfDbMEk.getControl(PPxYugzLZwHX23yiK(u"࠹࠱࠷࠳Ꭹ")).setImage(sqvreZdonIByS9UthcfDbMEk.image_filename)
		sqvreZdonIByS9UthcfDbMEk.getControl(nfNTgkiWdUq(u"࠺࠲࠸࠴Ꭺ")).setHeight(sqvreZdonIByS9UthcfDbMEk.image_height)
		if not sqvreZdonIByS9UthcfDbMEk.button1 and sqvreZdonIByS9UthcfDbMEk.button0 and sqvreZdonIByS9UthcfDbMEk.button2: sqvreZdonIByS9UthcfDbMEk.getControl(Qy6wlfLoOpg1(u"࠼࠴࠶࠸Ꭼ")).setPosition(-FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠶࠷࠶Ꭽ"),lw2snZ9J0uhLoxypqa(u"࠲Ꭻ"))
		return sqvreZdonIByS9UthcfDbMEk.image_filename,sqvreZdonIByS9UthcfDbMEk.image_height
	def gqc5blLE8Od6KhTys(sqvreZdonIByS9UthcfDbMEk):
		if sqvreZdonIByS9UthcfDbMEk.buttonstimeout:
			sqvreZdonIByS9UthcfDbMEk.th1 = QCxDqOcS9z586(daemon=S5MWhgtZ37Xw,target=sqvreZdonIByS9UthcfDbMEk.kBOTQRy3aSmwDvINApKC6oX)
			sqvreZdonIByS9UthcfDbMEk.th1.start()
		else: sqvreZdonIByS9UthcfDbMEk.dHXkm4GTqN()
	def kBOTQRy3aSmwDvINApKC6oX(sqvreZdonIByS9UthcfDbMEk):
		sqvreZdonIByS9UthcfDbMEk.getControl(YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠾࠶࠲࠱Ꭾ")).setEnabled(S5MWhgtZ37Xw)
		for hsqrMEVB70i2ZnzPHlGYD1oy in range(UnOIK1WBbw2,sqvreZdonIByS9UthcfDbMEk.buttonstimeout+UnOIK1WBbw2):
			h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(UnOIK1WBbw2)
			VVHzr38FhQuewRTt5Mqm = int(pxt6wJ8ScYMWCivoO(u"࠷࠰࠱Ꭿ")*hsqrMEVB70i2ZnzPHlGYD1oy/sqvreZdonIByS9UthcfDbMEk.buttonstimeout)
			sqvreZdonIByS9UthcfDbMEk.g7uqLP28UOGkaMZVDWTrxfI(VVHzr38FhQuewRTt5Mqm)
			if sqvreZdonIByS9UthcfDbMEk.choiceID>zhE5I4xHinX0UoVZMNwlkPrR(u"࠰Ꮀ"): break
		sqvreZdonIByS9UthcfDbMEk.dHXkm4GTqN()
	def irWZpLH9no(sqvreZdonIByS9UthcfDbMEk):
		if sqvreZdonIByS9UthcfDbMEk.closetimeout:
			sqvreZdonIByS9UthcfDbMEk.th2 = QCxDqOcS9z586(daemon=S5MWhgtZ37Xw,target=sqvreZdonIByS9UthcfDbMEk.O9k45jJR0TMlUgyLvtuD6nE)
			sqvreZdonIByS9UthcfDbMEk.th2.start()
		else: sqvreZdonIByS9UthcfDbMEk.dHXkm4GTqN()
	def O9k45jJR0TMlUgyLvtuD6nE(sqvreZdonIByS9UthcfDbMEk):
		sqvreZdonIByS9UthcfDbMEk.getControl(FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠺࠲࠵࠴Ꮁ")).setEnabled(S5MWhgtZ37Xw)
		h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(sqvreZdonIByS9UthcfDbMEk.buttonstimeout)
		for hsqrMEVB70i2ZnzPHlGYD1oy in range(sqvreZdonIByS9UthcfDbMEk.closetimeout-UnOIK1WBbw2,-UnOIK1WBbw2,-UnOIK1WBbw2):
			h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(UnOIK1WBbw2)
			VVHzr38FhQuewRTt5Mqm = int(ZjELJ9VrUT07R8Hn4FuSDcf(u"࠳࠳࠴Ꮂ")*hsqrMEVB70i2ZnzPHlGYD1oy/sqvreZdonIByS9UthcfDbMEk.closetimeout)
			sqvreZdonIByS9UthcfDbMEk.g7uqLP28UOGkaMZVDWTrxfI(VVHzr38FhQuewRTt5Mqm)
			if sqvreZdonIByS9UthcfDbMEk.choiceID>IpFcwrWNgefMym3qta0hYQAzOdE: break
		if sqvreZdonIByS9UthcfDbMEk.closetimeout>IpFcwrWNgefMym3qta0hYQAzOdE: sqvreZdonIByS9UthcfDbMEk.choiceID = gmPI7hVEM8nD(u"࠴࠴Ꮃ")
		sqvreZdonIByS9UthcfDbMEk.ZSw6Tpcd8A3XLxI()
	def g7uqLP28UOGkaMZVDWTrxfI(sqvreZdonIByS9UthcfDbMEk,VVHzr38FhQuewRTt5Mqm):
		sqvreZdonIByS9UthcfDbMEk.precent = VVHzr38FhQuewRTt5Mqm
		sqvreZdonIByS9UthcfDbMEk.getControl(Yj1msqVeivESfrCupRy9b7WacBd(u"࠽࠵࠸࠰Ꮄ")).setPercent(sqvreZdonIByS9UthcfDbMEk.precent)
	def dHXkm4GTqN(sqvreZdonIByS9UthcfDbMEk):
		if sqvreZdonIByS9UthcfDbMEk.button0: sqvreZdonIByS9UthcfDbMEk.getControl(Yj1msqVeivESfrCupRy9b7WacBd(u"࠾࠶࠱࠱Ꮅ")).setEnabled(S5MWhgtZ37Xw)
		if sqvreZdonIByS9UthcfDbMEk.button1: sqvreZdonIByS9UthcfDbMEk.getControl(FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠿࠰࠲࠳Ꮆ")).setEnabled(S5MWhgtZ37Xw)
		if sqvreZdonIByS9UthcfDbMEk.button2: sqvreZdonIByS9UthcfDbMEk.getControl(bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠹࠱࠳࠵Ꮇ")).setEnabled(S5MWhgtZ37Xw)
	def ZSw6Tpcd8A3XLxI(sqvreZdonIByS9UthcfDbMEk):
		sqvreZdonIByS9UthcfDbMEk.close()
		try: XoZRpFe7B6gnfA.remove(sqvreZdonIByS9UthcfDbMEk.image_filename)
		except: pass
class vD0q4oHLey6RaSCFNzr():
	def __init__(sqvreZdonIByS9UthcfDbMEk,showDialogs=FFKncZx5pDTwdiJRYhMgQSNL,logErrors=S5MWhgtZ37Xw):
		sqvreZdonIByS9UthcfDbMEk.showDialogs = showDialogs
		sqvreZdonIByS9UthcfDbMEk.logErrors = logErrors
		sqvreZdonIByS9UthcfDbMEk.finishedLIST,sqvreZdonIByS9UthcfDbMEk.failedLIST = [],[]
		sqvreZdonIByS9UthcfDbMEk.statusDICT,sqvreZdonIByS9UthcfDbMEk.resultsDICT = {},{}
		sqvreZdonIByS9UthcfDbMEk.processesLIST = []
		sqvreZdonIByS9UthcfDbMEk.starttimeDICT,sqvreZdonIByS9UthcfDbMEk.finishtimeDICT,sqvreZdonIByS9UthcfDbMEk.elpasedtimeDICT = {},{},{}
	def vz6gluNMCZ3ncR4AXfY1jVrwpHt(sqvreZdonIByS9UthcfDbMEk,aUJr1yX8602OvfEm9dWjkZH,XRfZdpskljnyKiIvTFq4O3Mt1,*aargs):
		aUJr1yX8602OvfEm9dWjkZH = str(aUJr1yX8602OvfEm9dWjkZH)
		sqvreZdonIByS9UthcfDbMEk.statusDICT[aUJr1yX8602OvfEm9dWjkZH] = AJHaiQq3PRd5cphzGuELnVg9X(u"ࠩࡵࡹࡳࡴࡩ࡯ࡩࠪ๝")
		if sqvreZdonIByS9UthcfDbMEk.showDialogs: ggYilKR5rMDyp7B(nA5dhMRg6ENzsB0l1GwvH7aIr2,aUJr1yX8602OvfEm9dWjkZH)
		gVMATP1b5cr96zk = QCxDqOcS9z586(daemon=S5MWhgtZ37Xw,target=sqvreZdonIByS9UthcfDbMEk.DZfR9btMuqi8JcIoKnlQOxyV,args=(aUJr1yX8602OvfEm9dWjkZH,XRfZdpskljnyKiIvTFq4O3Mt1,aargs))
		sqvreZdonIByS9UthcfDbMEk.processesLIST.append(gVMATP1b5cr96zk)
		return gVMATP1b5cr96zk
	def Jvrhu42CyMxdc1AmS8pPaLl(sqvreZdonIByS9UthcfDbMEk,aUJr1yX8602OvfEm9dWjkZH,XRfZdpskljnyKiIvTFq4O3Mt1,*aargs):
		gVMATP1b5cr96zk = sqvreZdonIByS9UthcfDbMEk.vz6gluNMCZ3ncR4AXfY1jVrwpHt(aUJr1yX8602OvfEm9dWjkZH,XRfZdpskljnyKiIvTFq4O3Mt1,*aargs)
		gVMATP1b5cr96zk.start()
	def DZfR9btMuqi8JcIoKnlQOxyV(sqvreZdonIByS9UthcfDbMEk,aUJr1yX8602OvfEm9dWjkZH,XRfZdpskljnyKiIvTFq4O3Mt1,aargs):
		aUJr1yX8602OvfEm9dWjkZH = str(aUJr1yX8602OvfEm9dWjkZH)
		sqvreZdonIByS9UthcfDbMEk.starttimeDICT[aUJr1yX8602OvfEm9dWjkZH] = h0skHe7TcIY9x1UP5VBrZAE8dKGnl.time()
		try:
			sqvreZdonIByS9UthcfDbMEk.resultsDICT[aUJr1yX8602OvfEm9dWjkZH] = XRfZdpskljnyKiIvTFq4O3Mt1(*aargs)
			if jil8vRpBsENVYyPmDd(u"ࠪࡓࡕࡋࡎࡖࡔࡏࠫ๞") in str(XRfZdpskljnyKiIvTFq4O3Mt1) and not sqvreZdonIByS9UthcfDbMEk.resultsDICT[aUJr1yX8602OvfEm9dWjkZH].succeeded: OeR9Dyin6a4hK5VvFMBo()
			sqvreZdonIByS9UthcfDbMEk.finishedLIST.append(aUJr1yX8602OvfEm9dWjkZH)
			sqvreZdonIByS9UthcfDbMEk.statusDICT[aUJr1yX8602OvfEm9dWjkZH] = HD7MQqXd2gS(u"ࠫ࡫࡯࡮ࡪࡵ࡫ࡩࡩ࠭๟")
		except Exception as f3xe1K6ndi:
			if sqvreZdonIByS9UthcfDbMEk.logErrors:
				ZZcxIq8bHKnPy2VREUMFG = G7QdMkY6Rr.format_exc()
				if ZZcxIq8bHKnPy2VREUMFG!=Qy6wlfLoOpg1(u"ࠬࡔ࡯࡯ࡧࡗࡽࡵ࡫࠺ࠡࡐࡲࡲࡪࡢ࡮ࠨ๠"): kCNHMOym1luTnJ0.stderr.write(ZZcxIq8bHKnPy2VREUMFG)
			sqvreZdonIByS9UthcfDbMEk.failedLIST.append(aUJr1yX8602OvfEm9dWjkZH)
			sqvreZdonIByS9UthcfDbMEk.statusDICT[aUJr1yX8602OvfEm9dWjkZH] = Pj9YaUq1ibJ(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭๡")
		sqvreZdonIByS9UthcfDbMEk.finishtimeDICT[aUJr1yX8602OvfEm9dWjkZH] = h0skHe7TcIY9x1UP5VBrZAE8dKGnl.time()
		sqvreZdonIByS9UthcfDbMEk.elpasedtimeDICT[aUJr1yX8602OvfEm9dWjkZH] = sqvreZdonIByS9UthcfDbMEk.finishtimeDICT[aUJr1yX8602OvfEm9dWjkZH] - sqvreZdonIByS9UthcfDbMEk.starttimeDICT[aUJr1yX8602OvfEm9dWjkZH]
	def ccyNK7q6w3i0PrnV1pXkIJWf(sqvreZdonIByS9UthcfDbMEk):
		for ydg29Q5Pc7CbKv in sqvreZdonIByS9UthcfDbMEk.processesLIST:
			ydg29Q5Pc7CbKv.start()
	def bOyEZCcUg12eMtYum(sqvreZdonIByS9UthcfDbMEk):
		while AJHaiQq3PRd5cphzGuELnVg9X(u"ࠧࡳࡷࡱࡲ࡮ࡴࡧࠨ๢") in list(sqvreZdonIByS9UthcfDbMEk.statusDICT.values()): h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(ZjELJ9VrUT07R8Hn4FuSDcf(u"࠲Ꮈ"))
def qT8KSt0HLdbRGpi():
	if not AAnORceT4EpS0CXtgKFlvz9Mjb8: return LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠨࡐࡒࡣ࡚ࡖࡄࡂࡖࡈࠫ๣")
	Ls7vhVfP1YtAub = LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠩࡉ࡙ࡑࡒ࡟ࡖࡒࡇࡅ࡙ࡋࠧ๤")
	oVzLfi2m73AHBT = [mRanX1HZupfSQVB2gsDGUO(u"ࠪ࠼࠳࠻࠮࠱ࠩ๥"),jil8vRpBsENVYyPmDd(u"ࠫ࠷࠶࠲࠲࠰࠴࠴࠳࠷࠹ࠨ๦"),jil8vRpBsENVYyPmDd(u"ࠬ࠸࠰࠳࠳࠱࠵࠶࠴࠲࠵ࡣࠪ๧"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠭࠲࠱࠴࠴࠲࠶࠸࠮࠴࠲ࠪ๨"),ldIfvn6asURQ9toi85EhqAXW3(u"ࠧ࠳࠲࠵࠶࠳࠶࠲࠯࠲࠵ࠫ๩"),bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠨ࠴࠳࠶࠷࠴࠱࠱࠰࠵࠶ࠬ๪"),FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠩ࠵࠴࠷࠹࠮࠱࠵࠱࠴࠻࠭๫"),HD7MQqXd2gS(u"ࠪ࠶࠵࠸࠳࠯࠲࠸࠲࠶࠼ࠧ๬"),nfNTgkiWdUq(u"ࠫ࠷࠶࠲࠴࠰࠳࠺࠳࠶࠶ࠨ๭"),XEcWOIwkZKubV7vQ(u"ࠬ࠸࠰࠳࠵࠱࠵࠵࠴࠲࠹ࠩ๮"),bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠭࠲࠱࠴࠷࠲࠵࠷࠮࠲࠶ࠪ๯"),Yj1msqVeivESfrCupRy9b7WacBd(u"ࠧ࠳࠲࠵࠸࠳࠶࠷࠯࠴࠳ࠫ๰")]
	Q4QGwZLmyDVXTknW1jqY7O = oVzLfi2m73AHBT[-UnOIK1WBbw2]
	BoqTtOJvi5CGrELpMse80mu = u7CoUO12mcNP4RSfQ(Q4QGwZLmyDVXTknW1jqY7O)
	stWlCIQ5abqOoBY = u7CoUO12mcNP4RSfQ(s5WcxEPjUBokapYMhAwb60dvgi)
	if stWlCIQ5abqOoBY>BoqTtOJvi5CGrELpMse80mu:
		Ls7vhVfP1YtAub = w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠨࡕࡌࡑࡕࡒࡅࡠࡗࡓࡈࡆ࡚ࡅࠨ๱")
	return Ls7vhVfP1YtAub
def kUWtJwS5aEIiqfpTv8LKrn3D6P7Ac():
	try: XoZRpFe7B6gnfA.makedirs(QQwBc24Oza7jJ8ClTRWexUoqGAkg0)
	except: pass
	GDRqx3bswtIF9HYuXNUhZ2JSoOiB = qT8KSt0HLdbRGpi()
	if GDRqx3bswtIF9HYuXNUhZ2JSoOiB==Yj1msqVeivESfrCupRy9b7WacBd(u"ࠩࡖࡍࡒࡖࡌࡆࡡࡘࡔࡉࡇࡔࡆࠩ๲"): nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,DFx6E0uON7Jm8(u"ࠪ࠲ࡡࡺࡁࡳࡣࡥ࡭ࡨ࡜ࡩࡥࡧࡲࡷ࡛ࠥࡰࡥࡣࡷࡩ࡚ࠥࡹࡱࡧ࠽ࠤ࡙ࠥࡉࡎࡒࡏࡉ࡛ࠥࡐࡅࡃࡗࡉࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩ๳")+dWHUYEKD6hA+HD7MQqXd2gS(u"ࠫࠥࡣࠧ๴"))
	else: nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠬ࠴࡜ࡵࡃࡵࡥࡧ࡯ࡣࡗ࡫ࡧࡩࡴࡹࠠࡖࡲࡧࡥࡹ࡫ࠠࡕࡻࡳࡩ࠿ࠦࠠࡇࡗࡏࡐ࡛ࠥࡐࡅࡃࡗࡉࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩ๵")+dWHUYEKD6hA+AJHaiQq3PRd5cphzGuELnVg9X(u"࠭ࠠ࡞ࠩ๶"))
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,zhE5I4xHinX0UoVZMNwlkPrR(u"ࠧห็ࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤๆ๐ࠠอ้สึ่ࡢ࡮ฦๆ์ࠤฬ๊ลึัสีࠥืโๆ࠼࡟ࡲࡡࡴࠧ๷")+s5WcxEPjUBokapYMhAwb60dvgi)
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,XEcWOIwkZKubV7vQ(u"ࠨฬ่ࠤฯัศ๋ฬࠣวํࠦสฮัํฯࠥอไฦืาหึࠦวๅฮา๎ิࠦไษำ้ห๊าࠠศๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ࠴ࠠฤ๊ࠣฮ๊ࠦๅิฯࠣ็ฬฺࠠศๆหี๋อๅอࠢ࡟ࡲࡡࡴࠠิ์ๅ์๊ࠦวๅฤ้ࠤฬ๊ศา่ส้ัࠦศษ฻ูࠤฬ๊แฮุ๊หฯࠦไื็ส๊ࠥ฿ๅๅࠢส่อืๆศ็ฯࠤอ฻่าหูࠣา๐อส๋้ࠢฯ้วๆๆฬࠫ๸"))
	aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,xwIUQfiE7rmvYzH(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠷ࠧ๹"),ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭๺"))
	aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,AJHaiQq3PRd5cphzGuELnVg9X(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖ࡟࠲ࠩ๻"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭๼"))
	aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,rCmGE4YIDaZA(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࡡ࠵ࠫ๽"))
	aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,lw2snZ9J0uhLoxypqa(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ๾"),bb1fgjsAq4N2xYwnoh39lm(u"ࠨࡕࡌࡘࡊ࡙࡟ࡏࡃࡐࡉࡘ࠭๿"))
	aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ຀"),FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠪࡗࡎ࡚ࡅࡔࡡࡆࡌࡊࡉࡋࠨກ"))
	aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,PPxYugzLZwHX23yiK(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧຂ"),gmPI7hVEM8nD(u"࡙ࠬࡉࡕࡇࡖࡣ࡛ࡋࡒࡊࡈ࡜ࠫ຃"))
	KQctJbXeEjDhplqknU3rzi.setSetting(pxt6wJ8ScYMWCivoO(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࡧࡱࡶࡸࡦ࠭ຄ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	KQctJbXeEjDhplqknU3rzi.setSetting(UUobzy0xZLaVScIt7(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡨࡤࡦࡷࡧ࡫ࡢࠩ຅"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	KQctJbXeEjDhplqknU3rzi.setSetting(zhE5I4xHinX0UoVZMNwlkPrR(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫຆ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	KQctJbXeEjDhplqknU3rzi.setSetting(DFx6E0uON7Jm8(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡪࡦࡹࡥ࡭ࡪࡧ࠵ࠬງ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	KQctJbXeEjDhplqknU3rzi.setSetting(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷ࠶࠭ຈ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	KQctJbXeEjDhplqknU3rzi.setSetting(AJHaiQq3PRd5cphzGuELnVg9X(u"ࠫࡦࡼ࠮ࡱࡧࡵ࡭ࡴࡪ࠮ࡪࡰࡩࡳࡸ࠭ຉ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	KQctJbXeEjDhplqknU3rzi.setSetting(ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡸ࡮࡯ࡳࡶࠪຊ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	KQctJbXeEjDhplqknU3rzi.setSetting(VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡸࡥࡨࡷ࡯ࡥࡷ࠭຋"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	KQctJbXeEjDhplqknU3rzi.setSetting(Qy6wlfLoOpg1(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡬ࡰࡰࡪࠫຌ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	KQctJbXeEjDhplqknU3rzi.setSetting(UUobzy0xZLaVScIt7(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩຍ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	KQctJbXeEjDhplqknU3rzi.setSetting(bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫຎ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,vzqjsVHSBlMpxC(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤ࡙ࡉࡕࡇࡖࠫຏ"))
	aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࠫຐ"))
	aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,ZjELJ9VrUT07R8Hn4FuSDcf(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫຑ"))
	aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,ldIfvn6asURQ9toi85EhqAXW3(u"࠭ࡓࡄࡔࡄࡔࡊࡘࡓࡠࡕࡗࡅ࡙࡛ࡓࠨຒ"))
	GlAym7JHLirouYThdfcjCtV(FFKncZx5pDTwdiJRYhMgQSNL)
	tixadpBDCATP07oQHqz8U1JN(yy6RomT9bQhJf)
	import nkKg6CFTbN
	nkKg6CFTbN.zfTIJNiuLFM2Kj(Qy6wlfLoOpg1(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧຓ"),FFKncZx5pDTwdiJRYhMgQSNL)
	nkKg6CFTbN.zfTIJNiuLFM2Kj(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫດ"),FFKncZx5pDTwdiJRYhMgQSNL)
	nkKg6CFTbN.zfTIJNiuLFM2Kj(lw2snZ9J0uhLoxypqa(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡧࡨࡰࡴࡪ࡭ࡤࡪࡴࡨࡧࡹ࠭ຕ"),FFKncZx5pDTwdiJRYhMgQSNL)
	nkKg6CFTbN.mzxoBQsiXNTZt6cw5gOyfLAjprRh(S5MWhgtZ37Xw)
	nkKg6CFTbN.Q9jaeyLX7GCA0mKRhNUkO25tnMrx(FFKncZx5pDTwdiJRYhMgQSNL)
	if GDRqx3bswtIF9HYuXNUhZ2JSoOiB==DFx6E0uON7Jm8(u"ࠪࡗࡎࡓࡐࡍࡇࡢ࡙ࡕࡊࡁࡕࡇࠪຖ"):
		W2NlwDyop7Eqzd(S5MWhgtZ37Xw,[FeDIpVljXmOnNkPAHscdTKWrEa])
	else:
		W2NlwDyop7Eqzd(FFKncZx5pDTwdiJRYhMgQSNL,[])
		nkKg6CFTbN.iI3JWfjo4rBM()
		try:
			d5hjegyqfGxaznwXQtYA3KZC6TmWS = XoZRpFe7B6gnfA.path.join(kkjOSvrlpDJNcqVIwUBt3,bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭ທ"),Qy6wlfLoOpg1(u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩຘ"),UUobzy0xZLaVScIt7(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪນ"),baBcNd81eH5ry2Olp6Mj43(u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭ບ"))
			dF7lJUK6LyH = zw6NdxVgQW2uJiXh.Addon(id=AJHaiQq3PRd5cphzGuELnVg9X(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬປ"))
			dF7lJUK6LyH.setSetting(Yj1msqVeivESfrCupRy9b7WacBd(u"ࠩࡤࡺ࠳ࡧࡵࡵࡱࡢࡴ࡮ࡩ࡫ࠨຜ"),XEcWOIwkZKubV7vQ(u"ࠪࡊࡦࡲࡳࡦࠩຝ"))
		except: pass
		try:
			d5hjegyqfGxaznwXQtYA3KZC6TmWS = XoZRpFe7B6gnfA.path.join(kkjOSvrlpDJNcqVIwUBt3,xwIUQfiE7rmvYzH(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭ພ"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩຟ"),gmPI7hVEM8nD(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡵ࠯ࡧࡰࡵ࠭ຠ"),baBcNd81eH5ry2Olp6Mj43(u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭ມ"))
			dF7lJUK6LyH = zw6NdxVgQW2uJiXh.Addon(id=AJHaiQq3PRd5cphzGuELnVg9X(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡷ࠱ࡩࡲࡰࠨຢ"))
			dF7lJUK6LyH.setSetting(PPxYugzLZwHX23yiK(u"ࠩࡤࡺ࠳ࡼࡩࡥࡧࡲࡣࡶࡻࡡ࡭࡫ࡷࡽࠬຣ"),jil8vRpBsENVYyPmDd(u"ࠪ࠷ࠬ຤"))
		except: pass
		try:
			d5hjegyqfGxaznwXQtYA3KZC6TmWS = XoZRpFe7B6gnfA.path.join(kkjOSvrlpDJNcqVIwUBt3,bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭ລ"),Qy6wlfLoOpg1(u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ຦"),FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭ວ"),AJHaiQq3PRd5cphzGuELnVg9X(u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭ຨ"))
			dF7lJUK6LyH = zw6NdxVgQW2uJiXh.Addon(id=yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨຩ"))
			dF7lJUK6LyH.setSetting(pxt6wJ8ScYMWCivoO(u"ࠩࡤࡺ࠳࡙ࡔࡓࡇࡄࡑࡘࡋࡌࡆࡅࡗࡍࡔࡔࠧສ"),Yj1msqVeivESfrCupRy9b7WacBd(u"ࠪ࠶ࠬຫ"))
		except: pass
	JEiFBCayPfze7n3KspN6AY = x1ibKhuTya7w3I589OcoEBAN(wGu23VIm0kSzJD7tEKo64nUQvgLXq)
	JEiFBCayPfze7n3KspN6AY = x1ibKhuTya7w3I589OcoEBAN(RihlJwXFNfe1IGPu9ZcUg85qsdn)
	nkKg6CFTbN.UHWdMnfqCxisbKaEe1By(FFKncZx5pDTwdiJRYhMgQSNL)
	KQctJbXeEjDhplqknU3rzi.setSetting(w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠫࡦࡼ࠮ࡷࡧࡵࡷ࡮ࡵ࡮ࠨຬ"),s5WcxEPjUBokapYMhAwb60dvgi)
	AA5FS4hUqeP9EsZCM(FFKncZx5pDTwdiJRYhMgQSNL)
	return
def HCXKgLnJFhq71DOmV(rzKxlyoWwpQHZiObUdPm35):
	tE0Sv5XxqW = w59lKDhpOYZm(S5MWhgtZ37Xw)
	if tE0Sv5XxqW:
		return
	hVHTXLcQoyOJafsYd7zCIg = cMda92KRnsEG7gmAtwqYT0lJ1uDj(KQctJbXeEjDhplqknU3rzi.getSetting(DFx6E0uON7Jm8(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡸ࡮࡯ࡳࡶࠪອ")))
	hVHTXLcQoyOJafsYd7zCIg = IpFcwrWNgefMym3qta0hYQAzOdE if not hVHTXLcQoyOJafsYd7zCIg else int(hVHTXLcQoyOJafsYd7zCIg)
	if not hVHTXLcQoyOJafsYd7zCIg or not IpFcwrWNgefMym3qta0hYQAzOdE<=GHSrzcU3jo2-hVHTXLcQoyOJafsYd7zCIg<=lPsYQwWdLO520ZHcFV8n1x:
		KQctJbXeEjDhplqknU3rzi.setSetting(pxt6wJ8ScYMWCivoO(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡹࡨࡰࡴࡷࠫຮ"),AsG2TjLa1DUMI(GHSrzcU3jo2))
		tixadpBDCATP07oQHqz8U1JN(yy6RomT9bQhJf)
		return
	ok1KP3f9WuSEMcYXriBDL05eCh = cMda92KRnsEG7gmAtwqYT0lJ1uDj(KQctJbXeEjDhplqknU3rzi.getSetting(jil8vRpBsENVYyPmDd(u"ࠧࡢࡸ࠱ࡴࡪࡸࡩࡰࡦ࠱࡭ࡳ࡬࡯ࡴࠩຯ")))
	ok1KP3f9WuSEMcYXriBDL05eCh = IpFcwrWNgefMym3qta0hYQAzOdE if not ok1KP3f9WuSEMcYXriBDL05eCh else int(ok1KP3f9WuSEMcYXriBDL05eCh)
	Reakb3sdo4XtW2JxwqGIVi6 = cMda92KRnsEG7gmAtwqYT0lJ1uDj(KQctJbXeEjDhplqknU3rzi.getSetting(Qy6wlfLoOpg1(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪະ")))
	Reakb3sdo4XtW2JxwqGIVi6 = IpFcwrWNgefMym3qta0hYQAzOdE if not Reakb3sdo4XtW2JxwqGIVi6 else int(Reakb3sdo4XtW2JxwqGIVi6)
	if not ok1KP3f9WuSEMcYXriBDL05eCh or not Reakb3sdo4XtW2JxwqGIVi6 or not IpFcwrWNgefMym3qta0hYQAzOdE<=GHSrzcU3jo2-Reakb3sdo4XtW2JxwqGIVi6<=ok1KP3f9WuSEMcYXriBDL05eCh:
		H67JSvdLCRnc5ArBEYhT(S5MWhgtZ37Xw,ok1KP3f9WuSEMcYXriBDL05eCh)
		return
	uYdI7jO2ZNGSi105RT6crt = cMda92KRnsEG7gmAtwqYT0lJ1uDj(KQctJbXeEjDhplqknU3rzi.getSetting(bb1fgjsAq4N2xYwnoh39lm(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡴࡨ࡫ࡺࡲࡡࡳࠩັ")))
	uYdI7jO2ZNGSi105RT6crt = IpFcwrWNgefMym3qta0hYQAzOdE if not uYdI7jO2ZNGSi105RT6crt else int(uYdI7jO2ZNGSi105RT6crt)
	if not uYdI7jO2ZNGSi105RT6crt or not IpFcwrWNgefMym3qta0hYQAzOdE<=GHSrzcU3jo2-uYdI7jO2ZNGSi105RT6crt<=QdwW2s0iEp56qMmvCbOeLxBRU:
		KQctJbXeEjDhplqknU3rzi.setSetting(w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡵࡩ࡬ࡻ࡬ࡢࡴࠪາ"),AsG2TjLa1DUMI(GHSrzcU3jo2))
		w59lKDhpOYZm(FFKncZx5pDTwdiJRYhMgQSNL)
		return
	if FFKncZx5pDTwdiJRYhMgQSNL:
		LiIn06cMwRxZueEmFb = cMda92KRnsEG7gmAtwqYT0lJ1uDj(KQctJbXeEjDhplqknU3rzi.getSetting(Pj9YaUq1ibJ(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡰࡴࡴࡧࠨຳ")))
		LiIn06cMwRxZueEmFb = IpFcwrWNgefMym3qta0hYQAzOdE if not LiIn06cMwRxZueEmFb else int(LiIn06cMwRxZueEmFb)
		if not LiIn06cMwRxZueEmFb or not IpFcwrWNgefMym3qta0hYQAzOdE<=GHSrzcU3jo2-LiIn06cMwRxZueEmFb<=OkCUfhKTs9DZbcgnw3roPGBvlqt:
			KQctJbXeEjDhplqknU3rzi.setSetting(AJHaiQq3PRd5cphzGuELnVg9X(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡱࡵ࡮ࡨࠩິ"),AsG2TjLa1DUMI(GHSrzcU3jo2))
	return
def H67JSvdLCRnc5ArBEYhT(aoD3bFQiButV50LwGnhkRszJSm7,ok1KP3f9WuSEMcYXriBDL05eCh):
	eXbIgzROU0 = UnOIK1WBbw2
	jopAaOZhv2tFJ7EG = FFKncZx5pDTwdiJRYhMgQSNL if Nzp9Fq5cTr.KR9TdgoVwvr4mIP else S5MWhgtZ37Xw
	if jopAaOZhv2tFJ7EG:
		if not ok1KP3f9WuSEMcYXriBDL05eCh: aoD3bFQiButV50LwGnhkRszJSm7 = FFKncZx5pDTwdiJRYhMgQSNL
		LOYHM0pRiEKka5SfWVzxcUAlXumZt = bAQuqZOzEGe8DCH2RTwtL9(aoD3bFQiButV50LwGnhkRszJSm7)
		if len(LOYHM0pRiEKka5SfWVzxcUAlXumZt)>UnOIK1WBbw2:
			nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,baBcNd81eH5ry2Olp6Mj43(u"࠭࠮࡝ࡶࡖ࡬ࡴࡽࡩ࡯ࡩࠣࡕࡺ࡫ࡳࡵ࡫ࡲࡲࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩີ")+dWHUYEKD6hA+ldIfvn6asURQ9toi85EhqAXW3(u"ࠧࠡ࡟ࠪຶ"))
			aUJr1yX8602OvfEm9dWjkZH,QQlJ2xKXAGUzh,mGy19ecrPjKCF,ccTbOMIrUX13m4pNRfyGquCadwJE,i4LsgZVpI3cQ,YZAKaSrmp57OUEtIXcyv3hoe8RVqWG = LOYHM0pRiEKka5SfWVzxcUAlXumZt[IpFcwrWNgefMym3qta0hYQAzOdE]
			B6O85VTcMiPW1CFXZLYfdonsSK,Bq6o5cM8TxkKD4W = ccTbOMIrUX13m4pNRfyGquCadwJE.split(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠨ࡞ࡱ࠿ࡀ࠭ື"))
			del LOYHM0pRiEKka5SfWVzxcUAlXumZt[IpFcwrWNgefMym3qta0hYQAzOdE]
			zuTeKf9v3bkZMJgL2dADhtp0sEynGY = avZmSHVO7swUYFnTu5p9iNR8g.sample(LOYHM0pRiEKka5SfWVzxcUAlXumZt,UnOIK1WBbw2)
			aUJr1yX8602OvfEm9dWjkZH,QQlJ2xKXAGUzh,mGy19ecrPjKCF,ccTbOMIrUX13m4pNRfyGquCadwJE,i4LsgZVpI3cQ,YZAKaSrmp57OUEtIXcyv3hoe8RVqWG = zuTeKf9v3bkZMJgL2dADhtp0sEynGY[IpFcwrWNgefMym3qta0hYQAzOdE]
			mGy19ecrPjKCF = JvQd6LMoBX4hiy1C(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨຸ")+lSWzOYmN08+JvQd6LMoBX4hiy1C(u"ࠪࠤ࠿ູࠦࠧ")+aUJr1yX8602OvfEm9dWjkZH+NwROdSj3nsA+mGy19ecrPjKCF
			i4LsgZVpI3cQ = VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠫสืำศๆࠣีุอไสࠢ็่๊ฮัๆฮ຺ࠪ")
			Ds1APf4eXQZOJ = bb1fgjsAq4N2xYwnoh39lm(u"ࠬอไหสิ฽ฬะࠧົ")
			button0,button1 = ccTbOMIrUX13m4pNRfyGquCadwJE,i4LsgZVpI3cQ
			Ba6pEsGAHxD8wI = [button0,button1,Ds1APf4eXQZOJ]
			RtEumVq86POGaMyN10h = UnOIK1WBbw2 if Nzp9Fq5cTr.Gnkf9VO7o1Bv5hTyAUPbHE else ZjELJ9VrUT07R8Hn4FuSDcf(u"࠳࠳Ꮉ")
			Jxg8Od1foHnuRrwvZAW4iNCVMzEUF = -lw2snZ9J0uhLoxypqa(u"࠼Ꮊ")
			while Jxg8Od1foHnuRrwvZAW4iNCVMzEUF<IpFcwrWNgefMym3qta0hYQAzOdE:
				b5bZuxeCag4qrFVSoNiYlApnzsTLv = avZmSHVO7swUYFnTu5p9iNR8g.sample(Ba6pEsGAHxD8wI,AH0zdvBqibaXY)
				Jxg8Od1foHnuRrwvZAW4iNCVMzEUF = vnI6XSlmEtsx7(nA5dhMRg6ENzsB0l1GwvH7aIr2,b5bZuxeCag4qrFVSoNiYlApnzsTLv[IpFcwrWNgefMym3qta0hYQAzOdE],b5bZuxeCag4qrFVSoNiYlApnzsTLv[UnOIK1WBbw2],b5bZuxeCag4qrFVSoNiYlApnzsTLv[udq5tP0hwifHQCGYELDbOUI],B6O85VTcMiPW1CFXZLYfdonsSK,mGy19ecrPjKCF,ZjELJ9VrUT07R8Hn4FuSDcf(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨຼ"),RtEumVq86POGaMyN10h,zhE5I4xHinX0UoVZMNwlkPrR(u"࠺࠵Ꮋ"))
				if Jxg8Od1foHnuRrwvZAW4iNCVMzEUF==Yj1msqVeivESfrCupRy9b7WacBd(u"࠶࠶Ꮌ"): break
				import nkKg6CFTbN
				if Jxg8Od1foHnuRrwvZAW4iNCVMzEUF>=IpFcwrWNgefMym3qta0hYQAzOdE and b5bZuxeCag4qrFVSoNiYlApnzsTLv[Jxg8Od1foHnuRrwvZAW4iNCVMzEUF]==Ba6pEsGAHxD8wI[UnOIK1WBbw2]:
					nkKg6CFTbN.z2JW4QB7vEgqxAX0p()
					if Jxg8Od1foHnuRrwvZAW4iNCVMzEUF>=IpFcwrWNgefMym3qta0hYQAzOdE: Jxg8Od1foHnuRrwvZAW4iNCVMzEUF = -jil8vRpBsENVYyPmDd(u"࠿Ꮍ")
				elif Jxg8Od1foHnuRrwvZAW4iNCVMzEUF>=IpFcwrWNgefMym3qta0hYQAzOdE and b5bZuxeCag4qrFVSoNiYlApnzsTLv[Jxg8Od1foHnuRrwvZAW4iNCVMzEUF]==Ba6pEsGAHxD8wI[udq5tP0hwifHQCGYELDbOUI]:
					nkKg6CFTbN.woj8GNX2kh5vJfMLQ1iqxPCm3U9(FFKncZx5pDTwdiJRYhMgQSNL)
				if Jxg8Od1foHnuRrwvZAW4iNCVMzEUF==-UnOIK1WBbw2: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,lSWzOYmN08+JvQd6LMoBX4hiy1C(u"ࠧฯำ๋ะࠥิืฤࠩຽ")+NwROdSj3nsA+n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠨ࡞ࡱࠤ้๊ฮา๊ฯࠤฬ๊ีฮ์ะࠤศิสา๋ࠢหาีࠠๆ่ࠣห้ษฬ้สฬࠤฬ๊ๅห๊ไีฮ࠭຾"))
			eXbIgzROU0 = UnOIK1WBbw2
		else: eXbIgzROU0 = IpFcwrWNgefMym3qta0hYQAzOdE
	KQctJbXeEjDhplqknU3rzi.setSetting(JvQd6LMoBX4hiy1C(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ຿"),AsG2TjLa1DUMI(GHSrzcU3jo2))
	WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,JvQd6LMoBX4hiy1C(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ເ"),nfNTgkiWdUq(u"ࠫࡘࡏࡔࡆࡕࡢࡒࡆࡓࡅࡔࠩແ"),eXbIgzROU0,l7ltVNxrbPimpXJDh)
	return
def uLpUECveAY(zzU5PnmRv13toWs4bDFL,B7n3L9yPx54v,RxWJFBAGy4iIM,No03nbgziMqjZ,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4,rzKxlyoWwpQHZiObUdPm35,LbE7zRf5SDmd2NaeAFqp6vgWQy9cwn,lA1roIBQKayswg0N):
	if LbE7zRf5SDmd2NaeAFqp6vgWQy9cwn in [zhE5I4xHinX0UoVZMNwlkPrR(u"ࠬ࠷ࠧໂ"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠭࠲ࠨໃ"),baBcNd81eH5ry2Olp6Mj43(u"ࠧ࠴ࠩໄ"),XEcWOIwkZKubV7vQ(u"ࠨ࠶ࠪ໅"),baBcNd81eH5ry2Olp6Mj43(u"ࠩ࠸ࠫໆ"),bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠪ࠵࠶࠭໇"),bb1fgjsAq4N2xYwnoh39lm(u"ࠫ࠶࠸່ࠧ"),Yj1msqVeivESfrCupRy9b7WacBd(u"ࠬ࠷࠳ࠨ້")] and lA1roIBQKayswg0N:
		import FjdxIzi5Pr
		FjdxIzi5Pr.z2sJc7NoDZhGTqkHWCSxf(kSqp7Ua0gATvrXG2RFdzN,LbE7zRf5SDmd2NaeAFqp6vgWQy9cwn,lA1roIBQKayswg0N)
		AA5FS4hUqeP9EsZCM(FFKncZx5pDTwdiJRYhMgQSNL,dWHUYEKD6hA)
	elif LbE7zRf5SDmd2NaeAFqp6vgWQy9cwn==HD7MQqXd2gS(u"࠭࠶ࠨ໊"):
		import pR2X91txEm
		if lA1roIBQKayswg0N==vzqjsVHSBlMpxC(u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅ໋ࠩ"): pR2X91txEm.ggYilKR5rMDyp7B(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠨ์ิะ๎ࠦวๅษ้ฮ฽อัࠨ໌"),rCmGE4YIDaZA(u"ࠩฯหึ๐ࠠโฯุࠤ๊๊แࠡษ็ฮา๋๊ๅࠩໍ"),h0skHe7TcIY9x1UP5VBrZAE8dKGnl=LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠲࠱࠲࠳Ꮎ"))
		elif lA1roIBQKayswg0N==jil8vRpBsENVYyPmDd(u"ࠪࡈࡊࡒࡅࡕࡇࠪ໎"): j1tZf3FQH0MxiO2nvwEpJ79h(kOTdpYrPqu5A7UIcW0Ch,FFKncZx5pDTwdiJRYhMgQSNL)
		V9OGBuyogH0CaUtQS6wWErAbPYDjlM = pR2X91txEm.uliqcaDoAVbL2(zzU5PnmRv13toWs4bDFL,B7n3L9yPx54v,RxWJFBAGy4iIM,rzKxlyoWwpQHZiObUdPm35,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4)
		if lA1roIBQKayswg0N==DFx6E0uON7Jm8(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭໏"): OeR9Dyin6a4hK5VvFMBo()
	elif kSqp7Ua0gATvrXG2RFdzN==XEcWOIwkZKubV7vQ(u"ࠬ࠽ࠧ໐"):
		import BBFeHcDpy6
		BBFeHcDpy6.hjQMgsBO5V4bR7fZocrWy(DFx6E0uON7Jm8(u"࠭࡟ࡂࡎࡏࠫ໑"))
		AA5FS4hUqeP9EsZCM(FFKncZx5pDTwdiJRYhMgQSNL)
	elif kSqp7Ua0gATvrXG2RFdzN==jil8vRpBsENVYyPmDd(u"ࠧ࠹ࠩ໒"): SoNGUfhMDERLyHOz1qkVAj.executebuiltin(XEcWOIwkZKubV7vQ(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡚ࡶࡤࡢࡶࡨࠬࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧ໓")+jmPwATvkoixS92pOuas+nfNTgkiWdUq(u"ࠩࡂࡱࡴࡪࡥ࠾ࠩ໔")+str(No03nbgziMqjZ)+XEcWOIwkZKubV7vQ(u"ࠪࠪࡹࡿࡰࡦ࠿ࡩࡳࡱࡪࡥࡳࠫࠪ໕"))
	elif kSqp7Ua0gATvrXG2RFdzN==AJHaiQq3PRd5cphzGuELnVg9X(u"ࠫ࠾࠭໖"):
		AA5FS4hUqeP9EsZCM(S5MWhgtZ37Xw)
	elif kSqp7Ua0gATvrXG2RFdzN==Yj1msqVeivESfrCupRy9b7WacBd(u"ࠬ࠷࠰ࠨ໗"):
		import BBFeHcDpy6
		BBFeHcDpy6.hjQMgsBO5V4bR7fZocrWy(bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠭࡟ࡈࡑࡒࡋࡑࡋࠧ໘"))
		AA5FS4hUqeP9EsZCM(FFKncZx5pDTwdiJRYhMgQSNL)
	elif kSqp7Ua0gATvrXG2RFdzN==YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠧ࠲࠶ࠪ໙"): AA5FS4hUqeP9EsZCM(S5MWhgtZ37Xw,mRanX1HZupfSQVB2gsDGUO(u"ࠨࡏࡈࡒ࡚ࡥࡒࡆࡘࡈࡖࡘࡋࡄࡠࡖࡈࡑࡕ࠭໚"))
	elif kSqp7Ua0gATvrXG2RFdzN==ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠩ࠴࠹ࠬ໛"): AA5FS4hUqeP9EsZCM(S5MWhgtZ37Xw,nfNTgkiWdUq(u"ࠪࡑࡊࡔࡕࡠࡃࡖࡇࡊࡔࡄࡆࡆࡢࡘࡊࡓࡐࠨໜ"))
	elif kSqp7Ua0gATvrXG2RFdzN==vzqjsVHSBlMpxC(u"ࠫ࠶࠼ࠧໝ"): AA5FS4hUqeP9EsZCM(S5MWhgtZ37Xw,HD7MQqXd2gS(u"ࠬࡓࡅࡏࡗࡢࡈࡊ࡙ࡃࡆࡐࡇࡉࡉࡥࡔࡆࡏࡓࠫໞ"))
	elif kSqp7Ua0gATvrXG2RFdzN==Yj1msqVeivESfrCupRy9b7WacBd(u"࠭࠱࠸ࠩໟ"): AA5FS4hUqeP9EsZCM(S5MWhgtZ37Xw,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠧࡎࡇࡑ࡙ࡤࡘࡁࡏࡆࡒࡑࡎࡠࡅࡅࡡࡗࡉࡒࡖࠧ໠"))
	elif kSqp7Ua0gATvrXG2RFdzN==mRanX1HZupfSQVB2gsDGUO(u"ࠨ࠳࠻ࠫ໡"):
		OTQCuS0y4RDU8abeZ = KQctJbXeEjDhplqknU3rzi.getSetting(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡨࡩࡵࡴࡤࡸࡪ࠭໢"))
		KQctJbXeEjDhplqknU3rzi.setSetting(pxt6wJ8ScYMWCivoO(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡢࡪࡶࡵࡥࡹ࡫ࠧ໣"),Pj9YaUq1ibJ(u"ࠫ࠲࠭໤")+OTQCuS0y4RDU8abeZ)
	if kSqp7Ua0gATvrXG2RFdzN in [ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠬ࠿ࠧ໥"),xwIUQfiE7rmvYzH(u"࠭࠱࠵ࠩ໦"),baBcNd81eH5ry2Olp6Mj43(u"ࠧ࠲࠷ࠪ໧"),jil8vRpBsENVYyPmDd(u"ࠨ࠳࠹ࠫ໨"),UUobzy0xZLaVScIt7(u"ࠩ࠴࠻ࠬ໩")]: OeR9Dyin6a4hK5VvFMBo(S5MWhgtZ37Xw)
	return
def QKzapDSFdWlghCByIf7UVMGkboTH(zzU5PnmRv13toWs4bDFL,B7n3L9yPx54v,RxWJFBAGy4iIM,No03nbgziMqjZ,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4,rzKxlyoWwpQHZiObUdPm35,LbE7zRf5SDmd2NaeAFqp6vgWQy9cwn,lA1roIBQKayswg0N,nI9bERJkQPWOfV0):
	if AAnORceT4EpS0CXtgKFlvz9Mjb8: kUWtJwS5aEIiqfpTv8LKrn3D6P7Ac()
	if kSqp7Ua0gATvrXG2RFdzN: uLpUECveAY(zzU5PnmRv13toWs4bDFL,B7n3L9yPx54v,RxWJFBAGy4iIM,No03nbgziMqjZ,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4,rzKxlyoWwpQHZiObUdPm35,LbE7zRf5SDmd2NaeAFqp6vgWQy9cwn,lA1roIBQKayswg0N)
	HCXKgLnJFhq71DOmV(rzKxlyoWwpQHZiObUdPm35)
	zTEXepHg92GkWf,EBZLyUM8S37uNqlcA,uzchXbN4SQLm6riG1E = S5MWhgtZ37Xw,FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL
	HHmS973aZVf80TLC = HPgrAYaGEqe2(zzU5PnmRv13toWs4bDFL,B7n3L9yPx54v,RxWJFBAGy4iIM,No03nbgziMqjZ,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4,rzKxlyoWwpQHZiObUdPm35,nI9bERJkQPWOfV0,zTEXepHg92GkWf,EBZLyUM8S37uNqlcA,uzchXbN4SQLm6riG1E)
	FCwVmbUj6gGNkWrvayhIKo,rFj1gkWuXpTniOeKAl9VN,r6J2iNjQAhH9PI7bauMy,ByuFsZxqG3NTIQ54f9CPclLVS,cF4NrO9XMWIBL2Ri3Adzsvqyel,dKCXFM0cQe,fL9XNQajnw53gsU1eyxk08FPl,GRLQr9gC26iol4HIupkbvAW0BdVN5s = HHmS973aZVf80TLC
	if FCwVmbUj6gGNkWrvayhIKo: return
	if rFj1gkWuXpTniOeKAl9VN==jil8vRpBsENVYyPmDd(u"ࠪࡖࡊࡌࡒࡆࡕࡋࡣࡈࡇࡃࡉࡇࠪ໪"): tixadpBDCATP07oQHqz8U1JN(yy6RomT9bQhJf)
	B8DRukzCLEiX0JbZtPvwUTOWA(Qy6wlfLoOpg1(u"ࠫࡸࡺࡡࡳࡶࠪ໫"))
	if KQctJbXeEjDhplqknU3rzi.getSetting(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡪࡷࡸࡵࡩࡡࡤࡪࡨࠫ໬")) not in [nfNTgkiWdUq(u"࠭ࡁࡖࡖࡒࠫ໭"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠧࡔࡖࡒࡔࠬ໮"),FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩ໯")]:
		KQctJbXeEjDhplqknU3rzi.setSetting(HD7MQqXd2gS(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨ໰"),bb1fgjsAq4N2xYwnoh39lm(u"ࠪࡅ࡚࡚ࡏࠨ໱"))
	if not KQctJbXeEjDhplqknU3rzi.getSetting(DFx6E0uON7Jm8(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡥࡰࡶࠫ໲")): KQctJbXeEjDhplqknU3rzi.setSetting(DFx6E0uON7Jm8(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡦࡱࡷࠬ໳"),Nzp9Fq5cTr.DNS_SERVERS[IpFcwrWNgefMym3qta0hYQAzOdE])
	V9OGBuyogH0CaUtQS6wWErAbPYDjlM = uliqcaDoAVbL2(zzU5PnmRv13toWs4bDFL,B7n3L9yPx54v,RxWJFBAGy4iIM,No03nbgziMqjZ,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4)
	if Qy6wlfLoOpg1(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ໴") in ooJmTWvjkAOHMN6EQSa23b4wiY8: EBZLyUM8S37uNqlcA = S5MWhgtZ37Xw
	if zzU5PnmRv13toWs4bDFL==w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ໵"):
		if ByuFsZxqG3NTIQ54f9CPclLVS!=lw2snZ9J0uhLoxypqa(u"ࠨ࠰࠱ࠫ໶") and cF4NrO9XMWIBL2Ri3Adzsvqyel: cbpzS0aUIdKLlOBWxk4Nrt()
		if Aovr58Gh96iqYxOTsSnkdbF>-UnOIK1WBbw2:
			HUlZtziuBLos2 = [IpFcwrWNgefMym3qta0hYQAzOdE,Yj1msqVeivESfrCupRy9b7WacBd(u"࠳࠸Ꮐ"),lw2snZ9J0uhLoxypqa(u"࠴࠻Ꮑ"),ZjELJ9VrUT07R8Hn4FuSDcf(u"࠵࠾Ꮒ"),pxt6wJ8ScYMWCivoO(u"࠳࠸Ꮏ"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠳࠵Ꮕ"),jil8vRpBsENVYyPmDd(u"࠺࠶Ꮓ"),FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠻࠳Ꮔ")]
			if (CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠩ࡬ࡲࡹ࠭໷"),rCmGE4YIDaZA(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭໸"),nfNTgkiWdUq(u"ࠫࡘࡏࡔࡆࡕࡢࡒࡆࡓࡅࡔࠩ໹")) or rzKxlyoWwpQHZiObUdPm35 not in HUlZtziuBLos2) and not Nzp9Fq5cTr.sz6qutHF1ITYr0a3cGJKOf:
				from UdES5ZYF1g import avDUSb8uhRF6JEXgsM
				a9DVIdhsHUGrA67iujWZowNSl3MfKP,ASrm72ijz8WEltH = Sve9PMyXLKO10YJc6xFjTlNfai(avDUSb8uhRF6JEXgsM)
				FCwVmbUj6gGNkWrvayhIKo = ujJytsaMw68dzFC(r6J2iNjQAhH9PI7bauMy,a9DVIdhsHUGrA67iujWZowNSl3MfKP,zTEXepHg92GkWf,EBZLyUM8S37uNqlcA,uzchXbN4SQLm6riG1E)
				if a9DVIdhsHUGrA67iujWZowNSl3MfKP and dKCXFM0cQe:
					if ASrm72ijz8WEltH: WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠬࡓࡅࡏࡗࡖࡣࡈࡇࡃࡉࡇࡢࠫ໺")+fL9XNQajnw53gsU1eyxk08FPl+bb1fgjsAq4N2xYwnoh39lm(u"࠭࡟ࠨ໻")+GRLQr9gC26iol4HIupkbvAW0BdVN5s,r6J2iNjQAhH9PI7bauMy,a9DVIdhsHUGrA67iujWZowNSl3MfKP,QdwW2s0iEp56qMmvCbOeLxBRU)
					else: aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠧࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭໼")+fL9XNQajnw53gsU1eyxk08FPl+nfNTgkiWdUq(u"ࠨࡡࠪ໽")+GRLQr9gC26iol4HIupkbvAW0BdVN5s,r6J2iNjQAhH9PI7bauMy)
			else:
				ddKIcR7M0rHT3.addDirectoryItem(Aovr58Gh96iqYxOTsSnkdbF,LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ໾")+jmPwATvkoixS92pOuas+zhE5I4xHinX0UoVZMNwlkPrR(u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡰ࡮ࡴ࡫ࠧ࡯ࡲࡨࡪࡃ࠵࠱࠲ࠪ໿"),z3jwnDkZ76OfKFB1rRoQVghbE0u92.ListItem(PPxYugzLZwHX23yiK(u"้ࠫี๊ไุ่่๊ࠢษࠡ็้ࠤัํวำๅࠪༀ")))
				ddKIcR7M0rHT3.addDirectoryItem(Aovr58Gh96iqYxOTsSnkdbF,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ༁")+jmPwATvkoixS92pOuas+AJHaiQq3PRd5cphzGuELnVg9X(u"࠭࠯ࡀࡶࡼࡴࡪࡃ࡬ࡪࡰ࡮ࠪࡲࡵࡤࡦ࠿࠸࠴࠵࠭༂"),z3jwnDkZ76OfKFB1rRoQVghbE0u92.ListItem(vzqjsVHSBlMpxC(u"ࠧฤใอั๊ࠥสใำฦࠤฬ๊สโษุ๎้࠭༃")))
			ddKIcR7M0rHT3.endOfDirectory(Aovr58Gh96iqYxOTsSnkdbF,zTEXepHg92GkWf,EBZLyUM8S37uNqlcA,uzchXbN4SQLm6riG1E)
	return
def tixadpBDCATP07oQHqz8U1JN(P3PrqMtKkyb1l):
	if Yj1msqVeivESfrCupRy9b7WacBd(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪ༄") in str(Nzp9Fq5cTr.SEND_THESE_EVENTS): return
	sQAZm5MkjvDP9w0VftaJLp = FFKncZx5pDTwdiJRYhMgQSNL if P3PrqMtKkyb1l else S5MWhgtZ37Xw
	if not sQAZm5MkjvDP9w0VftaJLp:
		YmrfQKjJzoB4FWgy = cMda92KRnsEG7gmAtwqYT0lJ1uDj(KQctJbXeEjDhplqknU3rzi.getSetting(ldIfvn6asURQ9toi85EhqAXW3(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪ༅")))
		YmrfQKjJzoB4FWgy = IpFcwrWNgefMym3qta0hYQAzOdE if not YmrfQKjJzoB4FWgy else int(YmrfQKjJzoB4FWgy)
		if not YmrfQKjJzoB4FWgy or not IpFcwrWNgefMym3qta0hYQAzOdE<=GHSrzcU3jo2-YmrfQKjJzoB4FWgy<=P3PrqMtKkyb1l: sQAZm5MkjvDP9w0VftaJLp = S5MWhgtZ37Xw
	if not sQAZm5MkjvDP9w0VftaJLp:
		m9rZXEFBRdp4IG = KQctJbXeEjDhplqknU3rzi.getSetting(AJHaiQq3PRd5cphzGuELnVg9X(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ༆"))
		if m9rZXEFBRdp4IG in [nA5dhMRg6ENzsB0l1GwvH7aIr2,w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠫࡔࡒࡄࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪ༇"),baBcNd81eH5ry2Olp6Mj43(u"ࠬࡔࡅࡘࡡࡗࡓࡤࡋࡒࡓࡑࡕࠫ༈")]: sQAZm5MkjvDP9w0VftaJLp = S5MWhgtZ37Xw
	if not sQAZm5MkjvDP9w0VftaJLp:
		rgaKu157bTywDlZi3VQxOmh = KQctJbXeEjDhplqknU3rzi.getSetting(bb1fgjsAq4N2xYwnoh39lm(u"࠭ࡡࡷ࠰ࡳࡶ࡮ࡼࡳ࠲ࠩ༉"))
		Ccemh2nAvQ,ADJdGOPzaeo0rXf2SuKQbcFWqilw = WbauZQKtLNV8BYxR0(FeDIpVljXmOnNkPAHscdTKWrEa)
		EEKgZxlwqGVCbyFaj3uS = fCIXRAyscP0b2MOGhJwTa7tjLl(FeDIpVljXmOnNkPAHscdTKWrEa,Ccemh2nAvQ,ADJdGOPzaeo0rXf2SuKQbcFWqilw,FFKncZx5pDTwdiJRYhMgQSNL,Qy6wlfLoOpg1(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡤ࡯ࡤࠡ࠽ࠪ༊"))
		EEKgZxlwqGVCbyFaj3uS = EEKgZxlwqGVCbyFaj3uS[ldIfvn6asURQ9toi85EhqAXW3(u"࠱Ꮖ")][ldIfvn6asURQ9toi85EhqAXW3(u"࠱Ꮖ")]
		Ccemh2nAvQ.close()
		barWI0ALHCiKu3vkd = l4pFeYACHV1.md5(HD7MQqXd2gS(u"࠷Ꮗ")*rgaKu157bTywDlZi3VQxOmh.encode(YWEQ3Cf8RevpD0m7NjF1)).hexdigest()
		barWI0ALHCiKu3vkd = l4pFeYACHV1.md5(xwIUQfiE7rmvYzH(u"࠴࠸Ꮘ")*barWI0ALHCiKu3vkd.encode(YWEQ3Cf8RevpD0m7NjF1)).hexdigest()
		barWI0ALHCiKu3vkd = l4pFeYACHV1.md5(UUobzy0xZLaVScIt7(u"࠵࠾Ꮙ")*barWI0ALHCiKu3vkd.encode(YWEQ3Cf8RevpD0m7NjF1)).hexdigest()
		barWI0ALHCiKu3vkd = str(int(barWI0ALHCiKu3vkd[xwIUQfiE7rmvYzH(u"࠹Ꮛ"):UUobzy0xZLaVScIt7(u"࠱࠳Ꮜ")],vzqjsVHSBlMpxC(u"࠲࠸Ꮝ")))[:Qy6wlfLoOpg1(u"࠾Ꮚ")]
		if barWI0ALHCiKu3vkd!=EEKgZxlwqGVCbyFaj3uS: sQAZm5MkjvDP9w0VftaJLp = S5MWhgtZ37Xw
	if sQAZm5MkjvDP9w0VftaJLp: uytr9P8Bwz6FN(FFKncZx5pDTwdiJRYhMgQSNL)
	return
def zeQigAm1b0BcNFnf8kDJU7HuShl(wwzCYnRmoFcxMIHAfB8kiJLOG,YZAKaSrmp57OUEtIXcyv3hoe8RVqWG,FjO41UWNvs0Gg,showDialogs):
	whXU4NCbPdFAcxErVJIutR8WDM3n = FjO41UWNvs0Gg.split(Yj1msqVeivESfrCupRy9b7WacBd(u"ࠨ࠯ࠪ་"),UnOIK1WBbw2)[IpFcwrWNgefMym3qta0hYQAzOdE] if bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠩ࠰ࠫ༌") in FjO41UWNvs0Gg else FjO41UWNvs0Gg
	if not showDialogs or FjO41UWNvs0Gg in TCvP3Y9u5jJlEqG2: return FFKncZx5pDTwdiJRYhMgQSNL
	nke2HiysEdRvaYXCM06flINS1 = KQctJbXeEjDhplqknU3rzi.getSetting(XEcWOIwkZKubV7vQ(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫ།"))
	KQctJbXeEjDhplqknU3rzi.setSetting(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬ༎"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	vwSZ4hpdaCrLtBqfg6iyVobWz = wwzCYnRmoFcxMIHAfB8kiJLOG in [UUobzy0xZLaVScIt7(u"࠼Ꮡ"),UUobzy0xZLaVScIt7(u"࠴࠵࠵࠶࠱Ꮟ"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠳࠴࠴࠵࠸Ꮞ"),Yj1msqVeivESfrCupRy9b7WacBd(u"࠵࠵࠶࠵࠵Ꮠ")]
	bd7m4yFgiYOQ3thU = YZAKaSrmp57OUEtIXcyv3hoe8RVqWG.lower()
	g7xNZROkEe = wwzCYnRmoFcxMIHAfB8kiJLOG in [IpFcwrWNgefMym3qta0hYQAzOdE,FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠲࠲࠷Ꮤ"),lw2snZ9J0uhLoxypqa(u"࠷࠰࠱࠸࠴Ꮢ"),bb1fgjsAq4N2xYwnoh39lm(u"࠱࠲࠳Ꮣ")]
	AKxuSv6iUC3EH8n9OTLyq4BW = lw2snZ9J0uhLoxypqa(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪ࠭༏") in bd7m4yFgiYOQ3thU
	adZpeBrz1kT = vzqjsVHSBlMpxC(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣ࠹ࠥࡹࡥࡤࡱࡱࡨࡸࠦࡢࡳࡱࡺࡷࡪࡸࠠࡤࡪࡨࡧࡰ࠭༐") in bd7m4yFgiYOQ3thU
	mmy4QK0uSFp = baBcNd81eH5ry2Olp6Mj43(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧࠧ༑") in bd7m4yFgiYOQ3thU
	rs4bTWFLexj = Qy6wlfLoOpg1(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠢࡶࡩࡨࡻࡲࡪࡶࡼࠤࡨ࡮ࡥࡤ࡭ࠪ༒") in bd7m4yFgiYOQ3thU
	odv6jgpYGDEbPTeL7QhrCc = baBcNd81eH5ry2Olp6Mj43(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦ࡭ࡪࡵࡶ࡭ࡳ࡭ࠠ࡫ࡣࡹࡥࡸࡩࡲࡪࡲࡷࠤࡨ࡮ࡥࡤ࡭ࠪ༓") in bd7m4yFgiYOQ3thU
	mf31GYWrPpTvyLK = mRanX1HZupfSQVB2gsDGUO(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡺࡱࡸࡶࠥࡴࡥࡵࡹࡲࡶࡰࠦࡤࡦࡸ࡬ࡧࡪࡹࠧ༔") in bd7m4yFgiYOQ3thU
	HT1rEx29SanKZzujMh5ke0Wb = KQctJbXeEjDhplqknU3rzi.getSetting(bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩ༕"))
	PjDfEWbY3p9vLrc2OZw5ltHg7dhRs = KQctJbXeEjDhplqknU3rzi.getSetting(DFx6E0uON7Jm8(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨ༖"))
	pLt3zTEWa0HZbljr8h = LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠭แีๆࠣๅ๏ࠦำฮสࠣห้฻แฮห้๋ࠣࠦวๅว้ฮึ์สࠨ༗")
	NNxeS0LTlKwrCy2a8opPR3qXhi = jil8vRpBsENVYyPmDd(u"ࠧࡆࡴࡵࡳࡷ༘ࠦࠧ")+str(wwzCYnRmoFcxMIHAfB8kiJLOG)+rCmGE4YIDaZA(u"ࠨ࠼༙ࠣࠫ")+YZAKaSrmp57OUEtIXcyv3hoe8RVqWG
	NNxeS0LTlKwrCy2a8opPR3qXhi = pvOytL0nF7JY6flXTxAcHbQeNahu3(NNxeS0LTlKwrCy2a8opPR3qXhi)
	if any([g7xNZROkEe,AKxuSv6iUC3EH8n9OTLyq4BW,adZpeBrz1kT,mmy4QK0uSFp,rs4bTWFLexj,odv6jgpYGDEbPTeL7QhrCc,mf31GYWrPpTvyLK]): pLt3zTEWa0HZbljr8h += PPxYugzLZwHX23yiK(u"ࠩࠣ࠲ࠥอไๆ๊ๅ฽ࠥ็๊่ࠢะะอࠦึะࠢๆ์ิ๐ࠠๆืาี์ࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅࠣวํࠦศศๆ่์็฿࡜࡯ࠩ༚")
	if vwSZ4hpdaCrLtBqfg6iyVobWz: pLt3zTEWa0HZbljr8h += XEcWOIwkZKubV7vQ(u"ࠪࠤ࠳ࠦไะ์ๆࠤำ฽รࠡࡆࡑࡗࠥ๎ๅฺ่ส๋ࠥะูัำࠣฮึาๅสࠢสื๊ࠦวๅ็๋ๆ฾ࠦลๅ๋ࠣี็๋็࡝ࡰࠪ༛")
	NNxeS0LTlKwrCy2a8opPR3qXhi = CXtugbqhV3+bbTCMJwEx8nhN4X+NNxeS0LTlKwrCy2a8opPR3qXhi+NwROdSj3nsA
	if HT1rEx29SanKZzujMh5ke0Wb==lw2snZ9J0uhLoxypqa(u"ࠫࡆ࡙ࡋࠨ༜") or PjDfEWbY3p9vLrc2OZw5ltHg7dhRs==PPxYugzLZwHX23yiK(u"ࠬࡇࡓࡌࠩ༝"):
		pLt3zTEWa0HZbljr8h += CXtugbqhV3+lSWzOYmN08+UUobzy0xZLaVScIt7(u"࠭็ๅࠢอี๏ีࠠฤ่ࠣ๎าอ่ๅࠢส่อืๆศ็ฯࠤส฻ไศฯࠣห้๋ิไๆฬࠤ࠳࠴ࠠฤ็ࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦร้ࠢั฻ศࠦลๅ๋ࠣห้๋ศา็ฯࠤฤࠧࠡࠨ༞")+NwROdSj3nsA
	auCGNHjFTqPWdwJiQ4cDfnS = FFKncZx5pDTwdiJRYhMgQSNL
	if HT1rEx29SanKZzujMh5ke0Wb==jil8vRpBsENVYyPmDd(u"ࠧࡂࡕࡎࠫ༟") or PjDfEWbY3p9vLrc2OZw5ltHg7dhRs==mRanX1HZupfSQVB2gsDGUO(u"ࠨࡃࡖࡏࠬ༠"):
		Jxg8Od1foHnuRrwvZAW4iNCVMzEUF = vnI6XSlmEtsx7(jil8vRpBsENVYyPmDd(u"ࠩࡦࡩࡳࡺࡥࡳࠩ༡"),FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠪาึ๎ฬࠨ༢"),zhE5I4xHinX0UoVZMNwlkPrR(u"ࠫสืำศๆ่้๋ࠣศา็ฯࠫ༣"),baBcNd81eH5ry2Olp6Mj43(u"ࠬะีๅ์ะࠤฬ๊ๅีๅ็อࠬ༤"),whXU4NCbPdFAcxErVJIutR8WDM3n+PwYGfc4gTjiyRlsHn1OE+AEyNnLOu7g6BGrw5tlcj(whXU4NCbPdFAcxErVJIutR8WDM3n),pLt3zTEWa0HZbljr8h+CXtugbqhV3+NNxeS0LTlKwrCy2a8opPR3qXhi)
		if Jxg8Od1foHnuRrwvZAW4iNCVMzEUF==UnOIK1WBbw2:
			from nkKg6CFTbN import z2JW4QB7vEgqxAX0p
			z2JW4QB7vEgqxAX0p()
		elif Jxg8Od1foHnuRrwvZAW4iNCVMzEUF==udq5tP0hwifHQCGYELDbOUI: auCGNHjFTqPWdwJiQ4cDfnS = S5MWhgtZ37Xw
	else: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,whXU4NCbPdFAcxErVJIutR8WDM3n+PwYGfc4gTjiyRlsHn1OE+AEyNnLOu7g6BGrw5tlcj(whXU4NCbPdFAcxErVJIutR8WDM3n),pLt3zTEWa0HZbljr8h,NNxeS0LTlKwrCy2a8opPR3qXhi)
	KQctJbXeEjDhplqknU3rzi.setSetting(XEcWOIwkZKubV7vQ(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧ༥"),nke2HiysEdRvaYXCM06flINS1)
	return auCGNHjFTqPWdwJiQ4cDfnS
def W2NlwDyop7Eqzd(klgQThUDnsu01AR4wpFm7Wzb8=FFKncZx5pDTwdiJRYhMgQSNL,BSGNFT49PD=[]):
	O7nR3KgC64WVfoQlquZhMP1z8es = [wGu23VIm0kSzJD7tEKo64nUQvgLXq,RihlJwXFNfe1IGPu9ZcUg85qsdn]+BSGNFT49PD
	for SR0vOrfBXW6AJ in XoZRpFe7B6gnfA.listdir(QQwBc24Oza7jJ8ClTRWexUoqGAkg0):
		if klgQThUDnsu01AR4wpFm7Wzb8 and (SR0vOrfBXW6AJ.startswith(xwIUQfiE7rmvYzH(u"ࠧࡪࡲࡷࡺࠬ༦")) or SR0vOrfBXW6AJ.startswith(lw2snZ9J0uhLoxypqa(u"ࠨ࡯࠶ࡹࠬ༧"))): continue
		if SR0vOrfBXW6AJ.startswith(pxt6wJ8ScYMWCivoO(u"ࠩࡩ࡭ࡱ࡫࡟ࠨ༨")): continue
		G4GnqXQEr0Hm5gS87xu2zbK = XoZRpFe7B6gnfA.path.join(QQwBc24Oza7jJ8ClTRWexUoqGAkg0,SR0vOrfBXW6AJ)
		if G4GnqXQEr0Hm5gS87xu2zbK in O7nR3KgC64WVfoQlquZhMP1z8es: continue
		try: XoZRpFe7B6gnfA.remove(G4GnqXQEr0Hm5gS87xu2zbK)
		except: pass
	if A1CKpbwyFL8jY4I not in O7nR3KgC64WVfoQlquZhMP1z8es: mJZ2eb9HzawrqRCsU7D6(A1CKpbwyFL8jY4I,S5MWhgtZ37Xw,FFKncZx5pDTwdiJRYhMgQSNL)
	h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(mRanX1HZupfSQVB2gsDGUO(u"࠳Ꮥ"))
	return
def GVOW8brmfNRuqthwi6Zl931LJ2CX(O6wfYnWi8bqSNJhx,QNwj4Toh3Vk60rfeGyY,RxWJFBAGy4iIM,JEiFBCayPfze7n3KspN6AY,PPblYOcLrJH6QI,xxpGC6WXNdqUolKO,showDialogs,FjO41UWNvs0Gg,Jdc2FbzlVg0uHtALvjWG6nfRKop=S5MWhgtZ37Xw,MAmJTVeP0CZB=S5MWhgtZ37Xw):
	RxWJFBAGy4iIM = RxWJFBAGy4iIM+XEcWOIwkZKubV7vQ(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪ༩")+O6wfYnWi8bqSNJhx
	tkSbvVxf8h1d0gLTci = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,QNwj4Toh3Vk60rfeGyY,RxWJFBAGy4iIM,JEiFBCayPfze7n3KspN6AY,PPblYOcLrJH6QI,xxpGC6WXNdqUolKO,showDialogs,FjO41UWNvs0Gg,Jdc2FbzlVg0uHtALvjWG6nfRKop,MAmJTVeP0CZB)
	if RxWJFBAGy4iIM in tkSbvVxf8h1d0gLTci.content: tkSbvVxf8h1d0gLTci.succeeded = FFKncZx5pDTwdiJRYhMgQSNL
	if not tkSbvVxf8h1d0gLTci.succeeded:
		OeR9Dyin6a4hK5VvFMBo()
	return tkSbvVxf8h1d0gLTci
def d9bpWL27fsUhxF3mCI(RxWJFBAGy4iIM):
	tkSbvVxf8h1d0gLTci = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠫࡌࡋࡔࠨ༪"),RxWJFBAGy4iIM,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,S5MWhgtZ37Xw,nA5dhMRg6ENzsB0l1GwvH7aIr2,Yj1msqVeivESfrCupRy9b7WacBd(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡔࡗࡕࡘࡊࡇࡖࡣࡑࡏࡓࡕ࠯࠴ࡷࡹ࠭༫"),S5MWhgtZ37Xw,FFKncZx5pDTwdiJRYhMgQSNL)
	BQz5etTbkNGFMx92X8w = []
	if tkSbvVxf8h1d0gLTci.succeeded:
		h1hN5GRPeA2YIgmvKax3EMJfu9ilZ = tkSbvVxf8h1d0gLTci.content
		xGyeH1iBNsfSjp30dQ2J7CcIhbO = PAztbuyYo4Kvd.findall(bb1fgjsAq4N2xYwnoh39lm(u"࠭ࠠࠩ࠰࠭ࡃ࠮ࠦ࡜ࡥࡽ࠴࠰࠸ࢃ࡭ࡴࠩ༬"),h1hN5GRPeA2YIgmvKax3EMJfu9ilZ)
		if xGyeH1iBNsfSjp30dQ2J7CcIhbO: h1hN5GRPeA2YIgmvKax3EMJfu9ilZ = CXtugbqhV3.join(xGyeH1iBNsfSjp30dQ2J7CcIhbO)
		l6jBMgq7wnY5Wt9z = h1hN5GRPeA2YIgmvKax3EMJfu9ilZ.replace(sSBzjZdcbQraNx,nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(CXtugbqhV3).split(CXtugbqhV3)
		BQz5etTbkNGFMx92X8w = []
		for O6wfYnWi8bqSNJhx in l6jBMgq7wnY5Wt9z:
			if O6wfYnWi8bqSNJhx.count(UUobzy0xZLaVScIt7(u"ࠧ࠯ࠩ༭"))==AH0zdvBqibaXY: BQz5etTbkNGFMx92X8w.append(O6wfYnWi8bqSNJhx)
	return BQz5etTbkNGFMx92X8w
def U7iZw8CKDBE0GovjHWz6T1LxpXNk(*aargs):
	uiNPJhab0t5FZmnk7f = xwIUQfiE7rmvYzH(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡴ࡮࠴ࡰࡳࡱࡻࡽࡸࡩࡲࡢࡲࡨ࠲ࡨࡵ࡭࠰ࡸ࠵࠳ࡄࡸࡥࡲࡷࡨࡷࡹࡃࡤࡪࡵࡳࡰࡦࡿࡰࡳࡱࡻ࡭ࡪࡹࠦࡱࡴࡲࡼࡾࡺࡹࡱࡧࡀ࡬ࡹࡺࡰࠧࡶ࡬ࡱࡪࡵࡵࡵ࠿࠴࠴࠵࠶࠰ࠧࡵࡶࡰࡂࡿࡥࡴࠨ࡯࡭ࡲ࡯ࡴ࠾࠳࠳ࠪࡨࡵࡵ࡯ࡶࡵࡽࡂࡔࡌ࠭ࡄࡈ࠰ࡉࡋࠬࡇࡔ࠯ࡋࡇ࠲ࡔࡓࠩ༮")
	UUyk6eboZBPuvIw3WfHKV0i4 = FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡶࡦࡽ࠮ࡨ࡫ࡷ࡬ࡺࡨࡵࡴࡧࡵࡧࡴࡴࡴࡦࡰࡷ࠲ࡨࡵ࡭࠰ࡴࡲࡳࡸࡺࡥࡳ࡭࡬ࡨ࠴ࡵࡰࡦࡰࡳࡶࡴࡾࡹ࡭࡫ࡶࡸ࠴ࡳࡡࡪࡰ࠲ࡌ࡙࡚ࡐࡔ࠰ࡷࡼࡹ࠭༯")
	PAlsTcZY8yjtQha4 = d9bpWL27fsUhxF3mCI(UUyk6eboZBPuvIw3WfHKV0i4)
	BQz5etTbkNGFMx92X8w = d9bpWL27fsUhxF3mCI(uiNPJhab0t5FZmnk7f)
	B8BNcjWqnmDgoxMlHiKs = PAlsTcZY8yjtQha4+BQz5etTbkNGFMx92X8w
	nhR0UxwS4yDiABj7V1G8la(hhOuTCDWIJe7SQPrcKVgF8ZN1qYEz,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠪࠤࠥࠦࡇࡰࡶࠣࡴࡷࡵࡸࡪࡧࡶࠤࡱ࡯ࡳࡵࠢࠣࠤ࠶ࡹࡴࠬ࠴ࡱࡨ࠿࡛ࠦࠡࠩ༰")+str(len(PAlsTcZY8yjtQha4))+Qy6wlfLoOpg1(u"ࠫ࠰࠭༱")+str(len(BQz5etTbkNGFMx92X8w))+lw2snZ9J0uhLoxypqa(u"ࠬࠦ࡝ࠨ༲"))
	O6wfYnWi8bqSNJhx = KQctJbXeEjDhplqknU3rzi.getSetting(xwIUQfiE7rmvYzH(u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯࡮ࡤࡷࡹ࠭༳"))
	tkSbvVxf8h1d0gLTci = aIh6GTlW0973UgY()
	KQctJbXeEjDhplqknU3rzi.setSetting(jil8vRpBsENVYyPmDd(u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺࠧ༴"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	if O6wfYnWi8bqSNJhx or B8BNcjWqnmDgoxMlHiKs:
		aUJr1yX8602OvfEm9dWjkZH,pxnIrsSMzymlvud8ZQaCgTtRJ1DWHe = IpFcwrWNgefMym3qta0hYQAzOdE,vzqjsVHSBlMpxC(u"࠴࠴Ꮦ")
		PPq0XfMLj8Cxa34eiZtcnRgK = len(B8BNcjWqnmDgoxMlHiKs)
		HlRnCT1U7pgqWGu8c9B3k = pxnIrsSMzymlvud8ZQaCgTtRJ1DWHe
		if PPq0XfMLj8Cxa34eiZtcnRgK>HlRnCT1U7pgqWGu8c9B3k: EEm2xV473Hw06YeDy = HlRnCT1U7pgqWGu8c9B3k
		else: EEm2xV473Hw06YeDy = PPq0XfMLj8Cxa34eiZtcnRgK
		H7FjW2gNmRMO6VY = avZmSHVO7swUYFnTu5p9iNR8g.sample(B8BNcjWqnmDgoxMlHiKs,EEm2xV473Hw06YeDy)
		if O6wfYnWi8bqSNJhx: H7FjW2gNmRMO6VY = [O6wfYnWi8bqSNJhx]+H7FjW2gNmRMO6VY
		Y7IQUmXbvA2 = vD0q4oHLey6RaSCFNzr(FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL)
		QUevxqzda3 = h0skHe7TcIY9x1UP5VBrZAE8dKGnl.time()
		while h0skHe7TcIY9x1UP5VBrZAE8dKGnl.time()-QUevxqzda3<=pxnIrsSMzymlvud8ZQaCgTtRJ1DWHe and not Y7IQUmXbvA2.finishedLIST:
			if aUJr1yX8602OvfEm9dWjkZH<EEm2xV473Hw06YeDy:
				O6wfYnWi8bqSNJhx = H7FjW2gNmRMO6VY[aUJr1yX8602OvfEm9dWjkZH]
				Y7IQUmXbvA2.Jvrhu42CyMxdc1AmS8pPaLl(aUJr1yX8602OvfEm9dWjkZH,GVOW8brmfNRuqthwi6Zl931LJ2CX,O6wfYnWi8bqSNJhx,*aargs)
			h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠴࠳࠽࠵Ꮧ"))
			aUJr1yX8602OvfEm9dWjkZH += UnOIK1WBbw2
			nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+Qy6wlfLoOpg1(u"ࠨࠢࠣࠤ࡙ࡸࡹࡪࡰࡪ࠾ࠥࠦࠠࡑࡴࡲࡼࡾࡀࠠ࡜༵ࠢࠪ")+O6wfYnWi8bqSNJhx+Pj9YaUq1ibJ(u"ࠩࠣࡡࠬ༶"))
		finishedLIST = Y7IQUmXbvA2.finishedLIST
		if finishedLIST:
			resultsDICT = Y7IQUmXbvA2.resultsDICT
			NdFza6ILJiHMOveuXGotf1 = finishedLIST[IpFcwrWNgefMym3qta0hYQAzOdE]
			tkSbvVxf8h1d0gLTci = resultsDICT[NdFza6ILJiHMOveuXGotf1]
			O6wfYnWi8bqSNJhx = H7FjW2gNmRMO6VY[int(NdFza6ILJiHMOveuXGotf1)]
			KQctJbXeEjDhplqknU3rzi.setSetting(Yj1msqVeivESfrCupRy9b7WacBd(u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡲࡡࡴࡶ༷ࠪ"),O6wfYnWi8bqSNJhx)
			if NdFza6ILJiHMOveuXGotf1!=IpFcwrWNgefMym3qta0hYQAzOdE: nhR0UxwS4yDiABj7V1G8la(hhOuTCDWIJe7SQPrcKVgF8ZN1qYEz,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪࡹࡳ࠻ࠢࠣࠤࡕࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ༸")+O6wfYnWi8bqSNJhx+YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠬࠦ࡝ࠨ༹"))
			else: nhR0UxwS4yDiABj7V1G8la(hhOuTCDWIJe7SQPrcKVgF8ZN1qYEz,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡴࡵ࠽ࠤࠥࠦࡓࡢࡸࡨࡨࠥࡶࡲࡰࡺࡼ࠾ࠥࡡࠠࠨ༺")+O6wfYnWi8bqSNJhx+baBcNd81eH5ry2Olp6Mj43(u"ࠧࠡ࡟ࠪ༻"))
	return tkSbvVxf8h1d0gLTci
def vvOPrlqIYuAXG(vgAyGYboURP6chTO7iltMCZWxD,idaV8KwMJjWgF5C4N,BPUWXQd3x0V=S5MWhgtZ37Xw):
	K5alJtTvLm = vgAyGYboURP6chTO7iltMCZWxD.create_connection
	def UZY8rFate6(Fm1EAo8yI4Tk,*aargs,**kkwargs):
		c9BuLKw8Pk1bm4fetghY7lp0DCojia,VBqkfmswQI4vapo3eytY2r = Fm1EAo8yI4Tk
		ip = cch8fV9GQvyt7rlp5WzuCbi(c9BuLKw8Pk1bm4fetghY7lp0DCojia,idaV8KwMJjWgF5C4N)
		if ip: c9BuLKw8Pk1bm4fetghY7lp0DCojia = ip[IpFcwrWNgefMym3qta0hYQAzOdE]
		elif BPUWXQd3x0V:
			if idaV8KwMJjWgF5C4N in Nzp9Fq5cTr.DNS_SERVERS: Nzp9Fq5cTr.DNS_SERVERS.remove(idaV8KwMJjWgF5C4N)
			if Nzp9Fq5cTr.DNS_SERVERS:
				AeysEJDdMvCT = Nzp9Fq5cTr.DNS_SERVERS[IpFcwrWNgefMym3qta0hYQAzOdE]
				ip = cch8fV9GQvyt7rlp5WzuCbi(c9BuLKw8Pk1bm4fetghY7lp0DCojia,AeysEJDdMvCT)
				if ip: c9BuLKw8Pk1bm4fetghY7lp0DCojia = ip[IpFcwrWNgefMym3qta0hYQAzOdE]
		if ip: Nzp9Fq5cTr.dns_succeeded_urls.append(c9BuLKw8Pk1bm4fetghY7lp0DCojia)
		Fm1EAo8yI4Tk = (c9BuLKw8Pk1bm4fetghY7lp0DCojia,VBqkfmswQI4vapo3eytY2r)
		return K5alJtTvLm(Fm1EAo8yI4Tk,*aargs,**kkwargs)
	vgAyGYboURP6chTO7iltMCZWxD.create_connection = UZY8rFate6
	return K5alJtTvLm
def aEILr8yROFiQh6Z(RxWJFBAGy4iIM):
	mJChOPxtD0cT58FIaXridMBWg,ps4TGBfVkdSngh59wCjoIJPbR = RxWJFBAGy4iIM.split(gmPI7hVEM8nD(u"ࠨ࠱ࠪ༼"))[udq5tP0hwifHQCGYELDbOUI],vzqjsVHSBlMpxC(u"࠽࠶Ꮨ")
	if LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠩ࠽ࠫ༽") in mJChOPxtD0cT58FIaXridMBWg: mJChOPxtD0cT58FIaXridMBWg,ps4TGBfVkdSngh59wCjoIJPbR = mJChOPxtD0cT58FIaXridMBWg.split(xwIUQfiE7rmvYzH(u"ࠪ࠾ࠬ༾"))
	bAE36u2fx7kG8toqLsBlmz09e = FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠫ࠴࠭༿")+JvQd6LMoBX4hiy1C(u"ࠬ࠵ࠧཀ").join(RxWJFBAGy4iIM.split(pxt6wJ8ScYMWCivoO(u"࠭࠯ࠨཁ"))[FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠹Ꮩ"):])
	YsdSH10ta6wvi4nMRIO9 = yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠧࡈࡇࡗࠤࠬག")+bAE36u2fx7kG8toqLsBlmz09e+UUobzy0xZLaVScIt7(u"ࠨࠢࡋࡘ࡙ࡖ࠯࠲࠰࠴ࡠࡷࡢ࡮ࠨགྷ")
	YsdSH10ta6wvi4nMRIO9 += baBcNd81eH5ry2Olp6Mj43(u"ࠩࡋࡳࡸࡺ࠺ࠡࠩང")+mJChOPxtD0cT58FIaXridMBWg+HD7MQqXd2gS(u"ࠪࡠࡷࡢ࡮ࠨཅ")
	YsdSH10ta6wvi4nMRIO9 += bb1fgjsAq4N2xYwnoh39lm(u"ࠫࡡࡸ࡜࡯ࠩཆ")
	from socket import socket as rvBVZ0QSYs3pqRjAzHl9KJ,AF_INET as WW53tEdxkFrR6SCI2,SOCK_STREAM as C5dJgIkWOEhi9bcYFzUtSvG72L
	try:
		X1SgvuQcaPCd9J = rvBVZ0QSYs3pqRjAzHl9KJ(WW53tEdxkFrR6SCI2,C5dJgIkWOEhi9bcYFzUtSvG72L)
		X1SgvuQcaPCd9J.connect((mJChOPxtD0cT58FIaXridMBWg,ps4TGBfVkdSngh59wCjoIJPbR))
		X1SgvuQcaPCd9J.send(YsdSH10ta6wvi4nMRIO9.encode(YWEQ3Cf8RevpD0m7NjF1))
		IBkl2tTM7bAZiO6Rg = X1SgvuQcaPCd9J.recv(HD7MQqXd2gS(u"࠵࠲࠼࠺Ꮫ")*nfNTgkiWdUq(u"࠱࠱࠴࠷Ꮪ"))
		h1hN5GRPeA2YIgmvKax3EMJfu9ilZ = repr(IBkl2tTM7bAZiO6Rg)
	except: h1hN5GRPeA2YIgmvKax3EMJfu9ilZ = nA5dhMRg6ENzsB0l1GwvH7aIr2
	return h1hN5GRPeA2YIgmvKax3EMJfu9ilZ
def C2gnJ5tXFk9pAL(MMiCSjBhseZHtNLX,zzU5PnmRv13toWs4bDFL):
	if UUobzy0xZLaVScIt7(u"ࠬ࠴ࠧཇ") not in MMiCSjBhseZHtNLX: return MMiCSjBhseZHtNLX
	MMiCSjBhseZHtNLX = MMiCSjBhseZHtNLX+nfNTgkiWdUq(u"࠭࠯ࠨ཈")
	NbB02AhurZckDf5a1lnF,MG9yuDdS28AzJmItiwKZoqrxTgk1 = MMiCSjBhseZHtNLX.split(bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠧ࠯ࠩཉ"),AJHaiQq3PRd5cphzGuELnVg9X(u"࠳Ꮬ"))
	WWeBHdst0Z6fRPJ,jOYtbpwLxmsKZdiXPflQkFDEIaB = MG9yuDdS28AzJmItiwKZoqrxTgk1.split(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠨ࠱ࠪཊ"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠴Ꮭ"))
	luqzt3VwT8MaD = NbB02AhurZckDf5a1lnF+PPxYugzLZwHX23yiK(u"ࠩ࠱ࠫཋ")+WWeBHdst0Z6fRPJ
	if zzU5PnmRv13toWs4bDFL in [pxt6wJ8ScYMWCivoO(u"ࠪ࡬ࡴࡹࡴࠨཌ"),XEcWOIwkZKubV7vQ(u"ࠫࡳࡧ࡭ࡦࠩཌྷ")] and nfNTgkiWdUq(u"ࠬ࠵ࠧཎ") in luqzt3VwT8MaD: luqzt3VwT8MaD = luqzt3VwT8MaD.rsplit(FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠭࠯ࠨཏ"),gmPI7hVEM8nD(u"࠵Ꮮ"))[UnOIK1WBbw2]
	if zzU5PnmRv13toWs4bDFL==pxt6wJ8ScYMWCivoO(u"ࠧ࡯ࡣࡰࡩࠬཐ") and bb1fgjsAq4N2xYwnoh39lm(u"ࠨ࠰ࠪད") in luqzt3VwT8MaD:
		kUz8m5076OtbrcYRylCD9 = luqzt3VwT8MaD.split(lw2snZ9J0uhLoxypqa(u"ࠩ࠱ࠫདྷ"))
		S4SHw7hZvLPup1k0clV5zOgUboKDQF = len(kUz8m5076OtbrcYRylCD9)
		if yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨན") in luqzt3VwT8MaD: kUz8m5076OtbrcYRylCD9 = LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩཔ")
		elif S4SHw7hZvLPup1k0clV5zOgUboKDQF<=udq5tP0hwifHQCGYELDbOUI: kUz8m5076OtbrcYRylCD9 = kUz8m5076OtbrcYRylCD9[IpFcwrWNgefMym3qta0hYQAzOdE]
		elif S4SHw7hZvLPup1k0clV5zOgUboKDQF>=AH0zdvBqibaXY: kUz8m5076OtbrcYRylCD9 = kUz8m5076OtbrcYRylCD9[UnOIK1WBbw2]
		if len(kUz8m5076OtbrcYRylCD9)>UnOIK1WBbw2: luqzt3VwT8MaD = kUz8m5076OtbrcYRylCD9
	return luqzt3VwT8MaD
def ekQTdRyiGNCuj6bhgwx4(Nu6yRpiDxjTWvIZ7):
	glGceRA672jiLzJ89 = repr(Nu6yRpiDxjTWvIZ7.encode(YWEQ3Cf8RevpD0m7NjF1)).replace(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠧ࠭ࠢཕ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	return glGceRA672jiLzJ89
def KK3yegFpzo45D7(cxpTkSgEiC4UOqeuR9sDaKAr):
	iEgV28CyYAIQsaup4M = nA5dhMRg6ENzsB0l1GwvH7aIr2
	if cS2NYw4xulqJgvzkMF: cxpTkSgEiC4UOqeuR9sDaKAr = cxpTkSgEiC4UOqeuR9sDaKAr.decode(YWEQ3Cf8RevpD0m7NjF1)
	from unicodedata import decomposition as CK3ReBo6qsbwYQljSA1MO0
	for oFwnMCQtx35pBdk8WOb1mZK in cxpTkSgEiC4UOqeuR9sDaKAr:
		if   oFwnMCQtx35pBdk8WOb1mZK==pxt6wJ8ScYMWCivoO(u"ࡻࠧรࠩབ"): Gx0cg8aMS6bZKt95niTVyJE = FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠧ࡝࡞ࡸ࠴࠻࠸࠲ࠨབྷ")
		elif oFwnMCQtx35pBdk8WOb1mZK==vzqjsVHSBlMpxC(u"ࡶࠩฦࠫམ"): Gx0cg8aMS6bZKt95niTVyJE = nfNTgkiWdUq(u"ࠩ࡟ࡠࡺ࠶࠶࠳࠵ࠪཙ")
		elif oFwnMCQtx35pBdk8WOb1mZK==lw2snZ9J0uhLoxypqa(u"ࡸࠫษ࠭ཚ"): Gx0cg8aMS6bZKt95niTVyJE = FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠫࡡࡢࡵ࠱࠸࠵࠸ࠬཛ")
		elif oFwnMCQtx35pBdk8WOb1mZK==ldIfvn6asURQ9toi85EhqAXW3(u"ࡺ࠭ลࠨཛྷ"): Gx0cg8aMS6bZKt95niTVyJE = UUobzy0xZLaVScIt7(u"࠭࡜࡝ࡷ࠳࠺࠷࠻ࠧཝ")
		elif oFwnMCQtx35pBdk8WOb1mZK==baBcNd81eH5ry2Olp6Mj43(u"ࡵࠨศࠪཞ"): Gx0cg8aMS6bZKt95niTVyJE = nfNTgkiWdUq(u"ࠨ࡞࡟ࡹ࠵࠼࠲࠷ࠩཟ")
		else:
			EPrZhIRfx8K0 = CK3ReBo6qsbwYQljSA1MO0(oFwnMCQtx35pBdk8WOb1mZK)
			if hSXlxL9iB05c in EPrZhIRfx8K0: Gx0cg8aMS6bZKt95niTVyJE = Pj9YaUq1ibJ(u"ࠩ࡟ࡠࡺ࠭འ")+EPrZhIRfx8K0.split(hSXlxL9iB05c,UnOIK1WBbw2)[UnOIK1WBbw2]
			else:
				Gx0cg8aMS6bZKt95niTVyJE = ldIfvn6asURQ9toi85EhqAXW3(u"ࠪ࠴࠵࠶࠰ࠨཡ")+hex(ord(oFwnMCQtx35pBdk8WOb1mZK)).replace(PPxYugzLZwHX23yiK(u"ࠫ࠵ࡾࠧར"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
				Gx0cg8aMS6bZKt95niTVyJE = JvQd6LMoBX4hiy1C(u"ࠬࡢ࡜ࡶࠩལ")+Gx0cg8aMS6bZKt95niTVyJE[-tpMX1Bgs0bzv8OEafyW:]
		iEgV28CyYAIQsaup4M += Gx0cg8aMS6bZKt95niTVyJE
	iEgV28CyYAIQsaup4M = iEgV28CyYAIQsaup4M.replace(JvQd6LMoBX4hiy1C(u"࠭࡜࡝ࡷ࠳࠺ࡈࡉࠧཤ"),ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠧ࡝࡞ࡸ࠴࠻࠺࠹ࠨཥ"))
	if cS2NYw4xulqJgvzkMF: iEgV28CyYAIQsaup4M = iEgV28CyYAIQsaup4M.decode(bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩས")).encode(YWEQ3Cf8RevpD0m7NjF1)
	else: iEgV28CyYAIQsaup4M = iEgV28CyYAIQsaup4M.encode(YWEQ3Cf8RevpD0m7NjF1).decode(nfNTgkiWdUq(u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪཧ"))
	return iEgV28CyYAIQsaup4M
def FaUBpzTGxtS7hZyl(header=nfNTgkiWdUq(u"่ࠪํำษࠡษ็้ๆอส๋ฯࠪཨ"),gcfWqOoyDiR5LQPAeX=nA5dhMRg6ENzsB0l1GwvH7aIr2,ZhEA6OBzVjLUg0iR1qnwC=FFKncZx5pDTwdiJRYhMgQSNL,source=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	ooJmTWvjkAOHMN6EQSa23b4wiY8 = m07dnYFoPRxKg3leVUjAbB2SIDOqwX(header,gcfWqOoyDiR5LQPAeX,type=z3jwnDkZ76OfKFB1rRoQVghbE0u92.INPUT_ALPHANUM)
	ooJmTWvjkAOHMN6EQSa23b4wiY8 = ooJmTWvjkAOHMN6EQSa23b4wiY8.strip(hSXlxL9iB05c).replace(cqsuhi1JE7nNIfbPYQSpFgeGr,hSXlxL9iB05c).replace(PwYGfc4gTjiyRlsHn1OE,hSXlxL9iB05c).replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c)
	if not ooJmTWvjkAOHMN6EQSa23b4wiY8 and not ZhEA6OBzVjLUg0iR1qnwC:
		nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,lw2snZ9J0uhLoxypqa(u"ࠫ࠳ࡢࡴࡌࡧࡼࡦࡴࡧࡲࡥࠢࡨࡲࡹࡸࡹࠡࡥࡤࡲࡨ࡫࡬ࡦࡦ࠽ࠤࠥࠦࠢࠨཀྵ")+ooJmTWvjkAOHMN6EQSa23b4wiY8+bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠬࠨࠧཪ"))
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,jil8vRpBsENVYyPmDd(u"࠭สๆࠢศ่฿อมࠡษ็ษิิวๅࠩཫ"))
		return nA5dhMRg6ENzsB0l1GwvH7aIr2
	if ooJmTWvjkAOHMN6EQSa23b4wiY8 not in [nA5dhMRg6ENzsB0l1GwvH7aIr2,hSXlxL9iB05c]:
		ooJmTWvjkAOHMN6EQSa23b4wiY8 = ooJmTWvjkAOHMN6EQSa23b4wiY8.strip(hSXlxL9iB05c)
		ooJmTWvjkAOHMN6EQSa23b4wiY8 = KK3yegFpzo45D7(ooJmTWvjkAOHMN6EQSa23b4wiY8)
	if source!=xwIUQfiE7rmvYzH(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔࠩཬ") and g4gUOtGiVkoNuaBrHhx8L(YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠨࡍࡈ࡝ࡇࡕࡁࡓࡆࠪ཭"),nA5dhMRg6ENzsB0l1GwvH7aIr2,[ooJmTWvjkAOHMN6EQSa23b4wiY8],FFKncZx5pDTwdiJRYhMgQSNL):
		nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,UUobzy0xZLaVScIt7(u"ࠩ࠱ࡠࡹࡑࡥࡺࡤࡲࡥࡷࡪࠠࡦࡰࡷࡶࡾࠦࡢ࡭ࡱࡦ࡯ࡪࡪ࠺ࠡࠢࠣࠦࠬ཮")+ooJmTWvjkAOHMN6EQSa23b4wiY8+Pj9YaUq1ibJ(u"ࠪࠦࠬ཯"))
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠫฬ์สࠡๅอฬฯࠦใๅ็ฬࠤศ๎ࠠาไ่ࠤ้ํฺࠠๆสๆฮࠦศฤใ็ห๊ࠦไๅๅหหึࠦแใูࠣ࠲࠳่่ࠦาสࠤฬ๊ศา่ส้ัࠦไศࠢํื๊ำࠠษษึฮำีวๆ๊ࠢ็ีอࠠไๆ่หฯ࠭཰"))
		return nA5dhMRg6ENzsB0l1GwvH7aIr2
	nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,HD7MQqXd2gS(u"ࠬ࠴࡜ࡵࡍࡨࡽࡧࡵࡡࡳࡦࠣࡩࡳࡺࡲࡺࠢࡤࡰࡱࡵࡷࡦࡦ࠽ࠤࠥࠦࠢࠨཱ")+ooJmTWvjkAOHMN6EQSa23b4wiY8+FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠭ࠢࠨི"))
	return ooJmTWvjkAOHMN6EQSa23b4wiY8
def vWyhsCqMc98ptw5gEPaLl(wgj0rX5tbcxPulhmny,KteRnFMjHpBPqNf8,LevQwm0pbqP1={}):
	RxWJFBAGy4iIM,bKpvte6CqLWAgRYm8zMjfD,vmiAf0lZHsLVbKUPJgRq5cDoxC2ae,NTOPaqL485vkAIFR7fgDlS = KteRnFMjHpBPqNf8,{},{},nA5dhMRg6ENzsB0l1GwvH7aIr2
	if rCmGE4YIDaZA(u"ࠧࡽཱིࠩ") in KteRnFMjHpBPqNf8: RxWJFBAGy4iIM,bKpvte6CqLWAgRYm8zMjfD = ss2VIkClmtevKqPUuSx9DGpX(KteRnFMjHpBPqNf8,vzqjsVHSBlMpxC(u"ࠨࡾུࠪ"))
	kEQaTjWm3G7eB = list(set(list(LevQwm0pbqP1.keys())+list(bKpvte6CqLWAgRYm8zMjfD.keys())))
	for XXqnevZw5VPsyczgmkdK10laD68hj in kEQaTjWm3G7eB:
		if XXqnevZw5VPsyczgmkdK10laD68hj in list(bKpvte6CqLWAgRYm8zMjfD.keys()): vmiAf0lZHsLVbKUPJgRq5cDoxC2ae[XXqnevZw5VPsyczgmkdK10laD68hj] = bKpvte6CqLWAgRYm8zMjfD[XXqnevZw5VPsyczgmkdK10laD68hj]
		else: vmiAf0lZHsLVbKUPJgRq5cDoxC2ae[XXqnevZw5VPsyczgmkdK10laD68hj] = LevQwm0pbqP1[XXqnevZw5VPsyczgmkdK10laD68hj]
	if AJHaiQq3PRd5cphzGuELnVg9X(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹཱུ࠭") not in kEQaTjWm3G7eB: vmiAf0lZHsLVbKUPJgRq5cDoxC2ae[AJHaiQq3PRd5cphzGuELnVg9X(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧྲྀ")] = oOb8ZS417GwudNKHU6y()
	if FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬཷ") not in kEQaTjWm3G7eB: vmiAf0lZHsLVbKUPJgRq5cDoxC2ae[baBcNd81eH5ry2Olp6Mj43(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ླྀ")] = C2gnJ5tXFk9pAL(RxWJFBAGy4iIM,Yj1msqVeivESfrCupRy9b7WacBd(u"࠭ࡵࡳ࡮ࠪཹ"))
	if bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡍࡣࡱ࡫ࡺࡧࡧࡦེࠩ") not in kEQaTjWm3G7eB: vmiAf0lZHsLVbKUPJgRq5cDoxC2ae[PPxYugzLZwHX23yiK(u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡎࡤࡲ࡬ࡻࡡࡨࡧཻࠪ")] = baBcNd81eH5ry2Olp6Mj43(u"ࠩࡨࡲ࠲࡛ࡓ࠭ࡧࡱ࠿ࡶࡃ࠰࠯࠻ོࠪ")
	for XXqnevZw5VPsyczgmkdK10laD68hj in list(vmiAf0lZHsLVbKUPJgRq5cDoxC2ae.keys()): NTOPaqL485vkAIFR7fgDlS += YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ཽࠪࠪࠬ")+XXqnevZw5VPsyczgmkdK10laD68hj+XEcWOIwkZKubV7vQ(u"ࠫࡂ࠭ཾ")+vmiAf0lZHsLVbKUPJgRq5cDoxC2ae[XXqnevZw5VPsyczgmkdK10laD68hj]
	if NTOPaqL485vkAIFR7fgDlS: NTOPaqL485vkAIFR7fgDlS = FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠬࢂࠧཿ")+NTOPaqL485vkAIFR7fgDlS[UnOIK1WBbw2:]
	tkSbvVxf8h1d0gLTci = uANakQHcnhR(cbpdEaUM8rKSQvzuqiJyXwW4,PPxYugzLZwHX23yiK(u"࠭ࡇࡆࡖྀࠪ"),RxWJFBAGy4iIM,nA5dhMRg6ENzsB0l1GwvH7aIr2,vmiAf0lZHsLVbKUPJgRq5cDoxC2ae,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jil8vRpBsENVYyPmDd(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡇ࡛ࡘࡗࡇࡃࡕࡡࡐ࠷࡚࠾࠭࠲ࡵࡷཱྀࠫ"),FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL)
	h1hN5GRPeA2YIgmvKax3EMJfu9ilZ = tkSbvVxf8h1d0gLTci.content
	if AJHaiQq3PRd5cphzGuELnVg9X(u"ࠨࡕࡗࡖࡊࡇࡍ࠮ࡋࡑࡊࠬྂ") not in h1hN5GRPeA2YIgmvKax3EMJfu9ilZ: return [Pj9YaUq1ibJ(u"ࠩ࠰࠵ࠬྃ")],[RxWJFBAGy4iIM+NTOPaqL485vkAIFR7fgDlS]
	if bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠪࡘ࡞ࡖࡅ࠾ࡃࡘࡈࡎࡕ྄ࠧ") in h1hN5GRPeA2YIgmvKax3EMJfu9ilZ: return [nfNTgkiWdUq(u"ࠫ࠲࠷ࠧ྅")],[RxWJFBAGy4iIM+NTOPaqL485vkAIFR7fgDlS]
	if bDxWcjmaSgFeRKrfpJvyA4zThi(u"࡚࡙ࠬࡑࡇࡀ࡚ࡎࡊࡅࡐࠩ྆") in h1hN5GRPeA2YIgmvKax3EMJfu9ilZ: return [UUobzy0xZLaVScIt7(u"࠭࠭࠲ࠩ྇")],[RxWJFBAGy4iIM+NTOPaqL485vkAIFR7fgDlS]
	ecU4Hy7lNS,ce9zAaVFswSq6lLr82DfQyotGW,BRE9hKa2Hm58Z6vSj,p0zgYxwy4b8oarHse5cDdAST = [],[],[],[]
	Df6jx49PNm8 = PAztbuyYo4Kvd.findall(lw2snZ9J0uhLoxypqa(u"ࠧࠤࡇ࡛ࡘ࠲࡞࠭ࡔࡖࡕࡉࡆࡓ࠭ࡊࡐࡉ࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫࠨྈ"),h1hN5GRPeA2YIgmvKax3EMJfu9ilZ+CXtugbqhV3,PAztbuyYo4Kvd.DOTALL)
	if not Df6jx49PNm8: return [Qy6wlfLoOpg1(u"ࠨ࠯࠴ࠫྉ")],[RxWJFBAGy4iIM+NTOPaqL485vkAIFR7fgDlS]
	for MBQ1jYxHkSyVD72cg6niAIRaC,MMiCSjBhseZHtNLX in Df6jx49PNm8:
		umNqpnv5lYcfZEGwdkJA28,OTQCuS0y4RDU8abeZ,OzWg1yEQG8wtvJ4x2ic9aKedFAPD = {},-rCmGE4YIDaZA(u"࠶Ꮯ"),-rCmGE4YIDaZA(u"࠶Ꮯ")
		NMiobZv972Dxwh = nA5dhMRg6ENzsB0l1GwvH7aIr2
		d2xVuyiIPc = MBQ1jYxHkSyVD72cg6niAIRaC.split(lw2snZ9J0uhLoxypqa(u"ࠩ࠯ࠫྊ"))
		for X5lnUjdopBiE in d2xVuyiIPc:
			if UUobzy0xZLaVScIt7(u"ࠪࡁࠬྋ") in X5lnUjdopBiE:
				XXqnevZw5VPsyczgmkdK10laD68hj,tLpxn6v5huoUji2QHsfJE4DWRql = X5lnUjdopBiE.split(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠫࡂ࠭ྌ"),xwIUQfiE7rmvYzH(u"࠷Ꮰ"))
				umNqpnv5lYcfZEGwdkJA28[XXqnevZw5VPsyczgmkdK10laD68hj.lower()] = tLpxn6v5huoUji2QHsfJE4DWRql
		if ldIfvn6asURQ9toi85EhqAXW3(u"ࠬࡧࡶࡦࡴࡤ࡫ࡪ࠳ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩྍ") in MBQ1jYxHkSyVD72cg6niAIRaC.lower():
			OTQCuS0y4RDU8abeZ = int(umNqpnv5lYcfZEGwdkJA28[w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠭ࡡࡷࡧࡵࡥ࡬࡫࠭ࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪྎ")])//gmPI7hVEM8nD(u"࠱࠱࠴࠷Ꮱ")
			NMiobZv972Dxwh += str(OTQCuS0y4RDU8abeZ)+bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠧ࡬ࡤࡳࡷࠥࠦࠧྏ")
		elif HD7MQqXd2gS(u"ࠨࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫྐ") in MBQ1jYxHkSyVD72cg6niAIRaC.lower():
			OTQCuS0y4RDU8abeZ = int(umNqpnv5lYcfZEGwdkJA28[lw2snZ9J0uhLoxypqa(u"ࠩࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬྑ")])//DFx6E0uON7Jm8(u"࠲࠲࠵࠸Ꮲ")
			NMiobZv972Dxwh += str(OTQCuS0y4RDU8abeZ)+baBcNd81eH5ry2Olp6Mj43(u"ࠪ࡯ࡧࡶࡳࠡࠢࠪྒ")
		if Yj1msqVeivESfrCupRy9b7WacBd(u"ࠫࡷ࡫ࡳࡰ࡮ࡸࡸ࡮ࡵ࡮ࠨྒྷ") in MBQ1jYxHkSyVD72cg6niAIRaC.lower():
			OzWg1yEQG8wtvJ4x2ic9aKedFAPD = int(umNqpnv5lYcfZEGwdkJA28[yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠬࡸࡥࡴࡱ࡯ࡹࡹ࡯࡯࡯ࠩྔ")].split(mRanX1HZupfSQVB2gsDGUO(u"࠭ࡸࠨྕ"))[UnOIK1WBbw2])
			NMiobZv972Dxwh += str(OzWg1yEQG8wtvJ4x2ic9aKedFAPD)+BSiDxUPsdHkz27VMop51uf6c3
		NMiobZv972Dxwh = NMiobZv972Dxwh.strip(BSiDxUPsdHkz27VMop51uf6c3)
		if not NMiobZv972Dxwh: NMiobZv972Dxwh = AJHaiQq3PRd5cphzGuELnVg9X(u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠨྖ")
		if not MMiCSjBhseZHtNLX.startswith(YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠨࡪࡷࡸࡵ࠭ྗ")):
			if MMiCSjBhseZHtNLX.startswith(baBcNd81eH5ry2Olp6Mj43(u"ࠩ࠲࠳ࠬ྘")): MMiCSjBhseZHtNLX = RxWJFBAGy4iIM.split(w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠪ࠾ࠬྙ"),UnOIK1WBbw2)[IpFcwrWNgefMym3qta0hYQAzOdE]+Yj1msqVeivESfrCupRy9b7WacBd(u"ࠫ࠿࠭ྚ")+MMiCSjBhseZHtNLX
			elif MMiCSjBhseZHtNLX.startswith(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠬ࠵ࠧྛ")): MMiCSjBhseZHtNLX = C2gnJ5tXFk9pAL(RxWJFBAGy4iIM,LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠭ࡵࡳ࡮ࠪྜ"))+MMiCSjBhseZHtNLX
			else: MMiCSjBhseZHtNLX = RxWJFBAGy4iIM.rsplit(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠧ࠰ࠩྜྷ"),UnOIK1WBbw2)[IpFcwrWNgefMym3qta0hYQAzOdE]+HD7MQqXd2gS(u"ࠨ࠱ࠪྞ")+MMiCSjBhseZHtNLX
		if n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠩࡳࡶࡴ࡭ࡲࡦࡵࡶ࡭ࡻ࡫࠭ࡶࡴ࡬ࠫྟ") in list(umNqpnv5lYcfZEGwdkJA28.keys()):
			ww5oBKPZmc = umNqpnv5lYcfZEGwdkJA28[nfNTgkiWdUq(u"ࠪࡴࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥ࠮ࡷࡵ࡭ࠬྠ")]
			ww5oBKPZmc = ww5oBKPZmc.replace(PPxYugzLZwHX23yiK(u"ࠫࠧ࠭ྡ"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(lw2snZ9J0uhLoxypqa(u"ࠧ࠭ࠢྡྷ"),nA5dhMRg6ENzsB0l1GwvH7aIr2).split(LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠭ࠣࠨྣ"),UnOIK1WBbw2)[IpFcwrWNgefMym3qta0hYQAzOdE]
			tb1IX8C3igp5 = EbwS0djxcz(ww5oBKPZmc)
			if tb1IX8C3igp5: g7qwMTAPoVpIyQUaDeNOnhvs = NMiobZv972Dxwh+BSiDxUPsdHkz27VMop51uf6c3+tb1IX8C3igp5
			else: g7qwMTAPoVpIyQUaDeNOnhvs = NMiobZv972Dxwh
			g7qwMTAPoVpIyQUaDeNOnhvs = g7qwMTAPoVpIyQUaDeNOnhvs+zhE5I4xHinX0UoVZMNwlkPrR(u"ࠧࠡࠢࡓࡶࡴ࡭ࡲࡦࡵࡶ࡭ࡻ࡫ࠧྤ")
			g7qwMTAPoVpIyQUaDeNOnhvs = g7qwMTAPoVpIyQUaDeNOnhvs+BSiDxUPsdHkz27VMop51uf6c3+C2gnJ5tXFk9pAL(ww5oBKPZmc,baBcNd81eH5ry2Olp6Mj43(u"ࠨࡰࡤࡱࡪ࠭ྥ"))
			ecU4Hy7lNS.append(g7qwMTAPoVpIyQUaDeNOnhvs)
			ce9zAaVFswSq6lLr82DfQyotGW.append(ww5oBKPZmc)
			BRE9hKa2Hm58Z6vSj.append(OzWg1yEQG8wtvJ4x2ic9aKedFAPD)
			p0zgYxwy4b8oarHse5cDdAST.append(OTQCuS0y4RDU8abeZ)
		MMiCSjBhseZHtNLX = MMiCSjBhseZHtNLX.split(w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠩࠦࠫྦ"),UnOIK1WBbw2)[IpFcwrWNgefMym3qta0hYQAzOdE]
		tb1IX8C3igp5 = EbwS0djxcz(MMiCSjBhseZHtNLX)
		if tb1IX8C3igp5: NMiobZv972Dxwh = NMiobZv972Dxwh+BSiDxUPsdHkz27VMop51uf6c3+tb1IX8C3igp5
		NMiobZv972Dxwh = NMiobZv972Dxwh+BSiDxUPsdHkz27VMop51uf6c3+C2gnJ5tXFk9pAL(MMiCSjBhseZHtNLX,Qy6wlfLoOpg1(u"ࠪࡲࡦࡳࡥࠨྦྷ"))
		ecU4Hy7lNS.append(NMiobZv972Dxwh)
		ce9zAaVFswSq6lLr82DfQyotGW.append(MMiCSjBhseZHtNLX)
		BRE9hKa2Hm58Z6vSj.append(OzWg1yEQG8wtvJ4x2ic9aKedFAPD)
		p0zgYxwy4b8oarHse5cDdAST.append(OTQCuS0y4RDU8abeZ)
	GP2jb0Bi4DJ85X9qYapMFEdWHT = list(zip(ecU4Hy7lNS,ce9zAaVFswSq6lLr82DfQyotGW,BRE9hKa2Hm58Z6vSj,p0zgYxwy4b8oarHse5cDdAST))
	GP2jb0Bi4DJ85X9qYapMFEdWHT = sorted(GP2jb0Bi4DJ85X9qYapMFEdWHT, reverse=S5MWhgtZ37Xw, key=lambda key: key[AH0zdvBqibaXY])
	ecU4Hy7lNS,ce9zAaVFswSq6lLr82DfQyotGW,BRE9hKa2Hm58Z6vSj,p0zgYxwy4b8oarHse5cDdAST = list(zip(*GP2jb0Bi4DJ85X9qYapMFEdWHT))
	ecU4Hy7lNS,ce9zAaVFswSq6lLr82DfQyotGW = list(ecU4Hy7lNS),list(ce9zAaVFswSq6lLr82DfQyotGW)
	TSUVm0q6gaDdKkrtEGl7ncZX2O9Y = []
	for MMiCSjBhseZHtNLX in ce9zAaVFswSq6lLr82DfQyotGW: TSUVm0q6gaDdKkrtEGl7ncZX2O9Y.append(MMiCSjBhseZHtNLX+NTOPaqL485vkAIFR7fgDlS)
	jREJaXp7BMA = list(zip(TSUVm0q6gaDdKkrtEGl7ncZX2O9Y,[nfNTgkiWdUq(u"ࠫࡩࡻ࡭࡮ࡻࠪྨ")]*len(TSUVm0q6gaDdKkrtEGl7ncZX2O9Y),p0zgYxwy4b8oarHse5cDdAST))
	MvK3GkfS7V = ae0rWS8x6DGQKIMEku9B4YUwz57(wgj0rX5tbcxPulhmny,jREJaXp7BMA)
	if MvK3GkfS7V:
		ZylHkumQ8zD0,eIlXpH1gLhmP4w3,OTQCuS0y4RDU8abeZ = MvK3GkfS7V[HD7MQqXd2gS(u"࠲Ꮳ")]
		index = TSUVm0q6gaDdKkrtEGl7ncZX2O9Y.index(ZylHkumQ8zD0)
		title = ecU4Hy7lNS[index]
		ecU4Hy7lNS,TSUVm0q6gaDdKkrtEGl7ncZX2O9Y = [title],[ZylHkumQ8zD0]
	return ecU4Hy7lNS,TSUVm0q6gaDdKkrtEGl7ncZX2O9Y
def cch8fV9GQvyt7rlp5WzuCbi(c9BuLKw8Pk1bm4fetghY7lp0DCojia,idaV8KwMJjWgF5C4N=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if not idaV8KwMJjWgF5C4N: idaV8KwMJjWgF5C4N = Nzp9Fq5cTr.DNS_SERVERS[IpFcwrWNgefMym3qta0hYQAzOdE]
	if c9BuLKw8Pk1bm4fetghY7lp0DCojia.replace(bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠬ࠴ࠧྩ"),nA5dhMRg6ENzsB0l1GwvH7aIr2).isdigit(): return [c9BuLKw8Pk1bm4fetghY7lp0DCojia]
	from struct import pack as C6Ik7dw2yDnKJmFsVu,unpack_from as hPfiNVUFeMtWEuDpdcYwC
	from socket import socket as rvBVZ0QSYs3pqRjAzHl9KJ,AF_INET as WW53tEdxkFrR6SCI2,SOCK_DGRAM as Gz2g8SnUcot9HJEdrsfmvBuR05NT
	try:
		RGnHZhkdMg1Btiu95SqJPOjyl6Q2xw = C6Ik7dw2yDnKJmFsVu(bb1fgjsAq4N2xYwnoh39lm(u"ࠨ࠾ࡉࠤྪ"), HD7MQqXd2gS(u"࠴࠶࠵࠺࠹Ꮴ"))
		RGnHZhkdMg1Btiu95SqJPOjyl6Q2xw += C6Ik7dw2yDnKJmFsVu(DFx6E0uON7Jm8(u"ࠢ࠿ࡊࠥྫ"), bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠶࠺࠼Ꮵ"))
		RGnHZhkdMg1Btiu95SqJPOjyl6Q2xw += C6Ik7dw2yDnKJmFsVu(HD7MQqXd2gS(u"ࠣࡀࡋࠦྫྷ"), UnOIK1WBbw2)
		RGnHZhkdMg1Btiu95SqJPOjyl6Q2xw += C6Ik7dw2yDnKJmFsVu(JvQd6LMoBX4hiy1C(u"ࠤࡁࡌࠧྭ"), IpFcwrWNgefMym3qta0hYQAzOdE)
		RGnHZhkdMg1Btiu95SqJPOjyl6Q2xw += C6Ik7dw2yDnKJmFsVu(DFx6E0uON7Jm8(u"ࠥࡂࡍࠨྮ"), IpFcwrWNgefMym3qta0hYQAzOdE)
		RGnHZhkdMg1Btiu95SqJPOjyl6Q2xw += C6Ik7dw2yDnKJmFsVu(Yj1msqVeivESfrCupRy9b7WacBd(u"ࠦࡃࡎࠢྯ"), IpFcwrWNgefMym3qta0hYQAzOdE)
		if BsLJ7p5Av2Vm0SQeCO1o: ueI34DoEA7gifC21hZOwJj0HkG = c9BuLKw8Pk1bm4fetghY7lp0DCojia.split(PPxYugzLZwHX23yiK(u"ࠬ࠴ࠧྰ"))
		else: ueI34DoEA7gifC21hZOwJj0HkG = c9BuLKw8Pk1bm4fetghY7lp0DCojia.decode(YWEQ3Cf8RevpD0m7NjF1).split(bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠭࠮ࠨྱ"))
		for lB7qZmE0j9C8FVLG4zHahYQ5 in ueI34DoEA7gifC21hZOwJj0HkG:
			Gun4sgy3Hxjp7Viw = lB7qZmE0j9C8FVLG4zHahYQ5.encode(YWEQ3Cf8RevpD0m7NjF1)
			RGnHZhkdMg1Btiu95SqJPOjyl6Q2xw += C6Ik7dw2yDnKJmFsVu(YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠢࡃࠤྲ"), len(lB7qZmE0j9C8FVLG4zHahYQ5))
			for bbLQ5NK8YSoZhCysa in lB7qZmE0j9C8FVLG4zHahYQ5:
				RGnHZhkdMg1Btiu95SqJPOjyl6Q2xw += C6Ik7dw2yDnKJmFsVu(VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠣࡥࠥླ"), bbLQ5NK8YSoZhCysa.encode(YWEQ3Cf8RevpD0m7NjF1))
		RGnHZhkdMg1Btiu95SqJPOjyl6Q2xw += C6Ik7dw2yDnKJmFsVu(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠤࡅࠦྴ"), IpFcwrWNgefMym3qta0hYQAzOdE)
		RGnHZhkdMg1Btiu95SqJPOjyl6Q2xw += C6Ik7dw2yDnKJmFsVu(PPxYugzLZwHX23yiK(u"ࠥࡂࡍࠨྵ"), UnOIK1WBbw2)
		RGnHZhkdMg1Btiu95SqJPOjyl6Q2xw += C6Ik7dw2yDnKJmFsVu(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠦࡃࡎࠢྶ"), UnOIK1WBbw2)
		f8JXirYax34njhV1H = rvBVZ0QSYs3pqRjAzHl9KJ(WW53tEdxkFrR6SCI2,Gz2g8SnUcot9HJEdrsfmvBuR05NT)
		f8JXirYax34njhV1H.sendto(bytes(RGnHZhkdMg1Btiu95SqJPOjyl6Q2xw),(idaV8KwMJjWgF5C4N,mRanX1HZupfSQVB2gsDGUO(u"࠺࠹Ꮶ")))
		f8JXirYax34njhV1H.settimeout(bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠼Ꮷ"))
		JEiFBCayPfze7n3KspN6AY, mUXexYC4kV8sz5 = f8JXirYax34njhV1H.recvfrom(ldIfvn6asURQ9toi85EhqAXW3(u"࠱࠱࠴࠷Ꮸ"))
		f8JXirYax34njhV1H.close()
		e4EdvlGUu6i0FINa = hPfiNVUFeMtWEuDpdcYwC(Pj9YaUq1ibJ(u"ࠧࡄࡈࡉࡊࡋࡌࡍࠨྷ"), JEiFBCayPfze7n3KspN6AY, IpFcwrWNgefMym3qta0hYQAzOdE)
		PsMkQUxpuCGg = e4EdvlGUu6i0FINa[AH0zdvBqibaXY]
		gCmxohbETAOw9d = len(c9BuLKw8Pk1bm4fetghY7lp0DCojia)+JvQd6LMoBX4hiy1C(u"࠲࠺Ꮹ")
		ccTbOMIrUX13m4pNRfyGquCadwJE = []
		for _Khlb7y3dAFt8 in range(PsMkQUxpuCGg):
			W4lJMKPvGrVCd = gCmxohbETAOw9d
			FxHt968PNkX0fgaGZjq = UnOIK1WBbw2
			yVLJAk4bTQN = FFKncZx5pDTwdiJRYhMgQSNL
			while S5MWhgtZ37Xw:
				bbLQ5NK8YSoZhCysa = hPfiNVUFeMtWEuDpdcYwC(VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠨ࠾ࡃࠤྸ"), JEiFBCayPfze7n3KspN6AY, W4lJMKPvGrVCd)[IpFcwrWNgefMym3qta0hYQAzOdE]
				if bbLQ5NK8YSoZhCysa == IpFcwrWNgefMym3qta0hYQAzOdE:
					W4lJMKPvGrVCd += UnOIK1WBbw2
					break
				if bbLQ5NK8YSoZhCysa >= pxt6wJ8ScYMWCivoO(u"࠳࠼࠶Ꮺ"):
					PRMwqK89ZnNfeF3 = hPfiNVUFeMtWEuDpdcYwC(JvQd6LMoBX4hiy1C(u"ࠢ࠿ࡄࠥྐྵ"), JEiFBCayPfze7n3KspN6AY, W4lJMKPvGrVCd + UnOIK1WBbw2)[IpFcwrWNgefMym3qta0hYQAzOdE]
					W4lJMKPvGrVCd = ((bbLQ5NK8YSoZhCysa << Yj1msqVeivESfrCupRy9b7WacBd(u"࠻Ꮻ")) + PRMwqK89ZnNfeF3 - 0xc000) - UnOIK1WBbw2
					yVLJAk4bTQN = S5MWhgtZ37Xw
				W4lJMKPvGrVCd += UnOIK1WBbw2
				if yVLJAk4bTQN == FFKncZx5pDTwdiJRYhMgQSNL: FxHt968PNkX0fgaGZjq += UnOIK1WBbw2
			if yVLJAk4bTQN == S5MWhgtZ37Xw: FxHt968PNkX0fgaGZjq += UnOIK1WBbw2
			gCmxohbETAOw9d = gCmxohbETAOw9d + FxHt968PNkX0fgaGZjq
			dorQKm8Wi6uqS2OR = hPfiNVUFeMtWEuDpdcYwC(ldIfvn6asURQ9toi85EhqAXW3(u"ࠣࡀࡋࡌࡎࡎࠢྺ"), JEiFBCayPfze7n3KspN6AY, gCmxohbETAOw9d)
			gCmxohbETAOw9d = gCmxohbETAOw9d + JvQd6LMoBX4hiy1C(u"࠵࠵Ꮼ")
			OotzyaniQxHWEB2cV6b9SCwgr8 = dorQKm8Wi6uqS2OR[IpFcwrWNgefMym3qta0hYQAzOdE]
			sGLMAbjEJQ = dorQKm8Wi6uqS2OR[AH0zdvBqibaXY]
			if OotzyaniQxHWEB2cV6b9SCwgr8 == UnOIK1WBbw2:
				T7Tho6LHwrn9ExbMSUByjt4uW = hPfiNVUFeMtWEuDpdcYwC(xwIUQfiE7rmvYzH(u"ࠤࡁࠦྻ")+w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠥࡆࠧྼ")*sGLMAbjEJQ, JEiFBCayPfze7n3KspN6AY, gCmxohbETAOw9d)
				ip = nA5dhMRg6ENzsB0l1GwvH7aIr2
				for bbLQ5NK8YSoZhCysa in T7Tho6LHwrn9ExbMSUByjt4uW: ip += str(bbLQ5NK8YSoZhCysa) + lw2snZ9J0uhLoxypqa(u"ࠫ࠳࠭྽")
				ip = ip[IpFcwrWNgefMym3qta0hYQAzOdE:-UnOIK1WBbw2]
				ccTbOMIrUX13m4pNRfyGquCadwJE.append(ip)
			if OotzyaniQxHWEB2cV6b9SCwgr8 in [UnOIK1WBbw2,udq5tP0hwifHQCGYELDbOUI,baBcNd81eH5ry2Olp6Mj43(u"࠵Ꮿ"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠷Ᏸ"),Pj9YaUq1ibJ(u"࠷࠵Ꮾ"),ZjELJ9VrUT07R8Hn4FuSDcf(u"࠷࠾Ꮽ")]: gCmxohbETAOw9d = gCmxohbETAOw9d + sGLMAbjEJQ
	except: ccTbOMIrUX13m4pNRfyGquCadwJE = []
	if not ccTbOMIrUX13m4pNRfyGquCadwJE: nhR0UxwS4yDiABj7V1G8la(ybrna7mLOFVDUtRseQ3Tkf2zXS,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠬࠦࠠࠡࡆࡑࡗࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࠢࡋࡳࡸࡺ࠺ࠡ࡝ࠣࠫ྾")+c9BuLKw8Pk1bm4fetghY7lp0DCojia+VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠭ࠠ࡞ࠩ྿"))
	return ccTbOMIrUX13m4pNRfyGquCadwJE
def g4gUOtGiVkoNuaBrHhx8L(wgj0rX5tbcxPulhmny,RxWJFBAGy4iIM,nR3YVtZDPs1IpAC,showDialogs=S5MWhgtZ37Xw):
	if Nzp9Fq5cTr.avprivsnorestrict or not nR3YVtZDPs1IpAC: return FFKncZx5pDTwdiJRYhMgQSNL
	QiL4GnFTq3EsJaBMXzC = [YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠧࡢࡦࡸࡰࡹ࠭࿀"),jil8vRpBsENVYyPmDd(u"ࠨ࠳࠻࠯ࠬ࿁"),ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠩࡻࡼࠬ࿂"),Pj9YaUq1ibJ(u"ࠪࡴࡴࡸ࡮ࠨ࿃"),nfNTgkiWdUq(u"ࠫࡸ࡫ࡸࠨ࿄"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠬࡴࡳࡧࡹࠪ࿅"),xwIUQfiE7rmvYzH(u"࠭࡭ࡢࡶࡸࡶࡪ࿆࠭"),lw2snZ9J0uhLoxypqa(u"ࠧไสสีࠬ࿇"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠨสส่฿࠭࿈"),rCmGE4YIDaZA(u"ࠩสฬฬำ๊ࠨ࿉"),mRanX1HZupfSQVB2gsDGUO(u"ࠪะู๋ࠧ࿊"),JvQd6LMoBX4hiy1C(u"๊๋ࠫๆ้฻ࠪ࿋")]
	if wgj0rX5tbcxPulhmny!=mRanX1HZupfSQVB2gsDGUO(u"ࠬࡈࡏࡌࡔࡄࠫ࿌"): QiL4GnFTq3EsJaBMXzC += [yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠭ࡲ࠻ࠩ࿍"),UUobzy0xZLaVScIt7(u"ࠧ࠻ࡴࠪ࿎"),Yj1msqVeivESfrCupRy9b7WacBd(u"ࠨࡴ࠰ࠫ࿏"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠩ࠰ࡶࠬ࿐"),mRanX1HZupfSQVB2gsDGUO(u"ࠪ࠱ࡲࡧࠧ࿑"),zhE5I4xHinX0UoVZMNwlkPrR(u"ࠫࡲࡧ࠭ࠨ࿒")]
	for UUf9aXA7nki5oJ8wYCxgZqHGde3 in nR3YVtZDPs1IpAC:
		UUf9aXA7nki5oJ8wYCxgZqHGde3 = UUf9aXA7nki5oJ8wYCxgZqHGde3.lower()
		if xwIUQfiE7rmvYzH(u"ࠬ࡭ࡥࡵ࠰ࡳ࡬ࡵࡅࠧ࿓") in UUf9aXA7nki5oJ8wYCxgZqHGde3: continue
		if UUobzy0xZLaVScIt7(u"࠭࡮ࡰࡶࠣࡶࡦࡺࡥࡥࠩ࿔") in UUf9aXA7nki5oJ8wYCxgZqHGde3: continue
		if rCmGE4YIDaZA(u"ࠧࡶࡰࡵࡥࡹ࡫ࡤࠨ࿕") in UUf9aXA7nki5oJ8wYCxgZqHGde3: continue
		if Yj1msqVeivESfrCupRy9b7WacBd(u"ࠨฯ็ๆฮ࠭࿖") in UUf9aXA7nki5oJ8wYCxgZqHGde3: continue
		if HD7MQqXd2gS(u"ࠩ฽๎ึࠦๅึ่ไࠫ࿗") in UUf9aXA7nki5oJ8wYCxgZqHGde3: continue
		UUf9aXA7nki5oJ8wYCxgZqHGde3 = UUf9aXA7nki5oJ8wYCxgZqHGde3.replace(HD7MQqXd2gS(u"ࠪวࠬ࿘"),lw2snZ9J0uhLoxypqa(u"ࠫฬ࠭࿙")).replace(mRanX1HZupfSQVB2gsDGUO(u"ࠬหࠧ࿚"),vzqjsVHSBlMpxC(u"࠭วࠨ࿛")).replace(XEcWOIwkZKubV7vQ(u"ࠧรࠩ࿜"),ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠨษࠪ࿝")).replace(Qy6wlfLoOpg1(u"ࠩ๑ࠫ࿞"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(mRanX1HZupfSQVB2gsDGUO(u"ࠪ๏ࠬ࿟"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
		UUf9aXA7nki5oJ8wYCxgZqHGde3 = UUf9aXA7nki5oJ8wYCxgZqHGde3.replace(jil8vRpBsENVYyPmDd(u"ࠫ๔࠭࿠"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠬ๖ࠧ࿡"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(ZjELJ9VrUT07R8Hn4FuSDcf(u"࠭ํࠨ࿢"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(baBcNd81eH5ry2Olp6Mj43(u"ࠧ๒ࠩ࿣"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
		UUf9aXA7nki5oJ8wYCxgZqHGde3 = UUf9aXA7nki5oJ8wYCxgZqHGde3.replace(LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠨโࠪ࿤"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(baBcNd81eH5ry2Olp6Mj43(u"ࠩ࠽ࠫ࿥"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
		if cS2NYw4xulqJgvzkMF: UUf9aXA7nki5oJ8wYCxgZqHGde3 = UUf9aXA7nki5oJ8wYCxgZqHGde3.decode(YWEQ3Cf8RevpD0m7NjF1).encode(YWEQ3Cf8RevpD0m7NjF1)
		V4VrUy7tYa9wzgB2fQ1lv8F6KDh = PAztbuyYo4Kvd.findall(vzqjsVHSBlMpxC(u"ࠪࠬ࠶ࡡ࠵࠮࠻ࡠ࠯ࢁ࠸࡛࠱࠯࠶ࡡ࠰࠯ࠧ࿦"),UUf9aXA7nki5oJ8wYCxgZqHGde3,PAztbuyYo4Kvd.DOTALL)
		pISMNmLkrdORWTE4c6qFny1xzQ = FFKncZx5pDTwdiJRYhMgQSNL
		for ddlmLPy9JKcTQureN0 in V4VrUy7tYa9wzgB2fQ1lv8F6KDh:
			if len(ddlmLPy9JKcTQureN0)==udq5tP0hwifHQCGYELDbOUI:
				pISMNmLkrdORWTE4c6qFny1xzQ = S5MWhgtZ37Xw
				break
		if UUf9aXA7nki5oJ8wYCxgZqHGde3 in [bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠫࡷ࠭࿧")] or pISMNmLkrdORWTE4c6qFny1xzQ or any(value in UUf9aXA7nki5oJ8wYCxgZqHGde3 for value in QiL4GnFTq3EsJaBMXzC):
			nhR0UxwS4yDiABj7V1G8la(ybrna7mLOFVDUtRseQ3Tkf2zXS,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠬࠦࠠࠡࡄ࡯ࡳࡨࡱࡥࡥࠢࡤࡨࡺࡲࡴࡴࠢࡹ࡭ࡩ࡫࡯࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ࿨")+RxWJFBAGy4iIM+jil8vRpBsENVYyPmDd(u"࠭ࠠ࡞ࠩ࿩"))
			if showDialogs: ggYilKR5rMDyp7B(OksCHeoL5SG,Qy6wlfLoOpg1(u"ࠧศๆไ๎ิ๐่ࠡๆ็็ออัࠡใๅ฻ࠥ๎ร็ษ้๋ࠣ฿ส่ࠩ࿪"))
			return S5MWhgtZ37Xw
	return FFKncZx5pDTwdiJRYhMgQSNL
def OmxJV4UQyeFqdBSIC0(*aargs,**kkwargs):
	if aargs:
		direction = aargs[IpFcwrWNgefMym3qta0hYQAzOdE]
		ijdIAWp2rywmbSMnOYXH = aargs[UnOIK1WBbw2]
		if not direction: direction = gmPI7hVEM8nD(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ࿫")
		if not ijdIAWp2rywmbSMnOYXH: ijdIAWp2rywmbSMnOYXH = baBcNd81eH5ry2Olp6Mj43(u"ࠩสืฯ๋ัศำࠪ࿬")
		Tu4mE1VlHBO = aargs[udq5tP0hwifHQCGYELDbOUI]
		ooJmTWvjkAOHMN6EQSa23b4wiY8 = CXtugbqhV3.join(aargs[HD7MQqXd2gS(u"࠵Ᏹ"):])
	else: direction,ijdIAWp2rywmbSMnOYXH,Tu4mE1VlHBO,ooJmTWvjkAOHMN6EQSa23b4wiY8 = nA5dhMRg6ENzsB0l1GwvH7aIr2,UUobzy0xZLaVScIt7(u"ࠪࡓࡐ࠭࿭"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	vnI6XSlmEtsx7(direction,nA5dhMRg6ENzsB0l1GwvH7aIr2,ijdIAWp2rywmbSMnOYXH,nA5dhMRg6ENzsB0l1GwvH7aIr2,Tu4mE1VlHBO,ooJmTWvjkAOHMN6EQSa23b4wiY8,**kkwargs)
	return
def bjyB5J1QuNaIXOx9qSwm4v0edDhg(*aargs,**kkwargs):
	direction = aargs[IpFcwrWNgefMym3qta0hYQAzOdE]
	s4HqJLuCSBIyX1wv = aargs[UnOIK1WBbw2]
	FxtZymciL5vD4 = aargs[udq5tP0hwifHQCGYELDbOUI]
	if FxtZymciL5vD4 or s4HqJLuCSBIyX1wv: os2ekYlHFG6nTPpADq3CLNatjguE1 = S5MWhgtZ37Xw
	else: os2ekYlHFG6nTPpADq3CLNatjguE1 = FFKncZx5pDTwdiJRYhMgQSNL
	Tu4mE1VlHBO = aargs[AH0zdvBqibaXY]
	ooJmTWvjkAOHMN6EQSa23b4wiY8 = aargs[tpMX1Bgs0bzv8OEafyW]
	if not direction: direction = bb1fgjsAq4N2xYwnoh39lm(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ࿮")
	if not s4HqJLuCSBIyX1wv: s4HqJLuCSBIyX1wv = w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"้ࠬไศࠢࠣࡒࡴ࠭࿯")
	if not FxtZymciL5vD4: FxtZymciL5vD4 = PPxYugzLZwHX23yiK(u"࠭ๆฺ็ࠣࠤ࡞࡫ࡳࠨ࿰")
	if len(aargs)>=FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠺Ᏻ"): ooJmTWvjkAOHMN6EQSa23b4wiY8 += CXtugbqhV3+aargs[PPxYugzLZwHX23yiK(u"࠸Ᏺ")]
	if len(aargs)>=yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠼Ᏼ"): ooJmTWvjkAOHMN6EQSa23b4wiY8 += CXtugbqhV3+aargs[zhE5I4xHinX0UoVZMNwlkPrR(u"࠼Ᏽ")]
	Jxg8Od1foHnuRrwvZAW4iNCVMzEUF = vnI6XSlmEtsx7(direction,s4HqJLuCSBIyX1wv,nA5dhMRg6ENzsB0l1GwvH7aIr2,FxtZymciL5vD4,Tu4mE1VlHBO,ooJmTWvjkAOHMN6EQSa23b4wiY8,**kkwargs)
	if Jxg8Od1foHnuRrwvZAW4iNCVMzEUF==-bb1fgjsAq4N2xYwnoh39lm(u"࠱᏶") and os2ekYlHFG6nTPpADq3CLNatjguE1: Jxg8Od1foHnuRrwvZAW4iNCVMzEUF = -UnOIK1WBbw2
	elif Jxg8Od1foHnuRrwvZAW4iNCVMzEUF==-UnOIK1WBbw2 and not os2ekYlHFG6nTPpADq3CLNatjguE1: Jxg8Od1foHnuRrwvZAW4iNCVMzEUF = FFKncZx5pDTwdiJRYhMgQSNL
	elif Jxg8Od1foHnuRrwvZAW4iNCVMzEUF==IpFcwrWNgefMym3qta0hYQAzOdE: Jxg8Od1foHnuRrwvZAW4iNCVMzEUF = FFKncZx5pDTwdiJRYhMgQSNL
	elif Jxg8Od1foHnuRrwvZAW4iNCVMzEUF==udq5tP0hwifHQCGYELDbOUI: Jxg8Od1foHnuRrwvZAW4iNCVMzEUF = S5MWhgtZ37Xw
	return Jxg8Od1foHnuRrwvZAW4iNCVMzEUF
def ccAMwn7hflDev8Kd3aqP(*aargs,**kkwargs):
	return z3jwnDkZ76OfKFB1rRoQVghbE0u92.Dialog().select(*aargs,**kkwargs)
def ggYilKR5rMDyp7B(*aargs,**kkwargs):
	Tu4mE1VlHBO = aargs[IpFcwrWNgefMym3qta0hYQAzOdE]
	ooJmTWvjkAOHMN6EQSa23b4wiY8 = aargs[UnOIK1WBbw2]
	bJQrZRFya9P = kkwargs[jil8vRpBsENVYyPmDd(u"ࠧࡵ࡫ࡰࡩࠬ࿱")] if yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠨࡶ࡬ࡱࡪ࠭࿲") in list(kkwargs.keys()) else YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠲࠲࠳࠴᏷")
	lr4GhB6kA7gM5I9Je = aargs[udq5tP0hwifHQCGYELDbOUI] if len(aargs)>udq5tP0hwifHQCGYELDbOUI and Yj1msqVeivESfrCupRy9b7WacBd(u"ࠩࡷ࡭ࡲ࡫ࠧ࿳") not in aargs[udq5tP0hwifHQCGYELDbOUI] else FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࡵࡩ࡬ࡻ࡬ࡢࡴࠪ࿴")
	gVMATP1b5cr96zk = QCxDqOcS9z586(daemon=S5MWhgtZ37Xw,target=PPXjyxvISh4,args=(Tu4mE1VlHBO,ooJmTWvjkAOHMN6EQSa23b4wiY8,lr4GhB6kA7gM5I9Je,bJQrZRFya9P))
	gVMATP1b5cr96zk.start()
	return
def PPXjyxvISh4(Tu4mE1VlHBO,ooJmTWvjkAOHMN6EQSa23b4wiY8,lr4GhB6kA7gM5I9Je,bJQrZRFya9P):
	DeM4UZhAym = lr4GhB6kA7gM5I9Je.replace(nfNTgkiWdUq(u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡢࠫ࿵"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	name = A5ADUfVbRmFSyH94P(S5MWhgtZ37Xw,DeM4UZhAym+JvQd6LMoBX4hiy1C(u"ࠬࠦ࠭ࠡࠩ࿶")+Tu4mE1VlHBO+YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠭ࠠ࠮ࠢࠪ࿷")+ooJmTWvjkAOHMN6EQSa23b4wiY8)
	name = AIWw30xBhusg(name)
	image_filename = XoZRpFe7B6gnfA.path.join(moqHbwiCz51GU6eBM,name+zhE5I4xHinX0UoVZMNwlkPrR(u"ࠧ࠯ࡲࡱ࡫ࠬ࿸"))
	if XoZRpFe7B6gnfA.path.exists(image_filename):
		if lr4GhB6kA7gM5I9Je==XEcWOIwkZKubV7vQ(u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡳࡧࡪࡹࡱࡧࡲࠨ࿹"): image_height = bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠳࠴࠻ᏸ")
		elif lr4GhB6kA7gM5I9Je==bb1fgjsAq4N2xYwnoh39lm(u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡣࡸࡸࡴ࠭࿺"): image_height = UUobzy0xZLaVScIt7(u"࠵࠵࠵ᏹ")
	else: image_height = Nru4ln6fMS(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,Tu4mE1VlHBO,ooJmTWvjkAOHMN6EQSa23b4wiY8,lr4GhB6kA7gM5I9Je,LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠪࡰࡪ࡬ࡴࠨ࿻"),FFKncZx5pDTwdiJRYhMgQSNL,image_filename)
	Z6uoKzn35I8yXs = LhHmwYu3cT1VnbGkvN5iOD(gmPI7hVEM8nD(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡒࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡋࡰࡥ࡬࡫࠮ࡹ࡯࡯ࠫ࿼"),mQKDw6vcXNIkngiWrC8GdPFqeRH,DFx6E0uON7Jm8(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭࿽"),mRanX1HZupfSQVB2gsDGUO(u"࠭࠷࠳࠲ࡳࠫ࿾"))
	Z6uoKzn35I8yXs.show()
	if lr4GhB6kA7gM5I9Je==UUobzy0xZLaVScIt7(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡡࡶࡶࡲࠫ࿿"):
		Z6uoKzn35I8yXs.getControl(jil8vRpBsENVYyPmDd(u"࠾࠶࠴࠱ᏻ")).setHeight(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠶࠶࠻ᏺ"))
		Z6uoKzn35I8yXs.getControl(AJHaiQq3PRd5cphzGuELnVg9X(u"࠺࠲࠷࠴᏾")).setPosition(XEcWOIwkZKubV7vQ(u"࠻࠵ᏼ"),-pxt6wJ8ScYMWCivoO(u"࠸࠱ᏽ"))
		Z6uoKzn35I8yXs.getControl(JvQd6LMoBX4hiy1C(u"࠻࠳࠹࠵᏿")).setPosition(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠴࠶࠵᐀"),-AJHaiQq3PRd5cphzGuELnVg9X(u"࠺࠵ᐁ"))
		Z6uoKzn35I8yXs.getControl(AJHaiQq3PRd5cphzGuELnVg9X(u"࠴࠱࠲ᐄ")).setPosition(zhE5I4xHinX0UoVZMNwlkPrR(u"࠾࠶ᐂ"),-ZjELJ9VrUT07R8Hn4FuSDcf(u"࠹࠵ᐃ"))
	Z6uoKzn35I8yXs.getControl(bb1fgjsAq4N2xYwnoh39lm(u"࠵࠲࠴ᐅ")).setVisible(FFKncZx5pDTwdiJRYhMgQSNL)
	Z6uoKzn35I8yXs.getControl(FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠶࠳࠶ᐆ")).setVisible(FFKncZx5pDTwdiJRYhMgQSNL)
	Z6uoKzn35I8yXs.getControl(jil8vRpBsENVYyPmDd(u"࠼࠴࠺࠶ᐇ")).setImage(image_filename)
	Z6uoKzn35I8yXs.getControl(AJHaiQq3PRd5cphzGuELnVg9X(u"࠽࠵࠻࠰ᐈ")).setHeight(image_height)
	h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(bJQrZRFya9P//DFx6E0uON7Jm8(u"࠶࠶࠰࠱࠰࠳ᐉ"))
	return
def VryRxo21PBngU3(*aargs,**kkwargs):
	Tu4mE1VlHBO,ooJmTWvjkAOHMN6EQSa23b4wiY8,profile,direction = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩက"),rCmGE4YIDaZA(u"ࠩ࡯ࡩ࡫ࡺࠧခ")
	if len(aargs)>=UnOIK1WBbw2: Tu4mE1VlHBO = aargs[IpFcwrWNgefMym3qta0hYQAzOdE]
	if len(aargs)>=udq5tP0hwifHQCGYELDbOUI: ooJmTWvjkAOHMN6EQSa23b4wiY8 = aargs[UnOIK1WBbw2]
	if len(aargs)>=AH0zdvBqibaXY: profile = aargs[udq5tP0hwifHQCGYELDbOUI]
	if len(aargs)>=tpMX1Bgs0bzv8OEafyW: direction = aargs[AH0zdvBqibaXY]
	return d9EaJh5t3Tyj7CsXFL(direction,Tu4mE1VlHBO,ooJmTWvjkAOHMN6EQSa23b4wiY8,profile)
def BaYvn3uN2cKT(*aargs,**kkwargs):
	return z3jwnDkZ76OfKFB1rRoQVghbE0u92.Dialog().contextmenu(*aargs,**kkwargs)
def ZZpK5jXgcHiCFJDM4r7GoLyQnz0m(*aargs,**kkwargs):
	return z3jwnDkZ76OfKFB1rRoQVghbE0u92.Dialog().browseSingle(*aargs,**kkwargs)
def m07dnYFoPRxKg3leVUjAbB2SIDOqwX(*aargs,**kkwargs):
	return z3jwnDkZ76OfKFB1rRoQVghbE0u92.Dialog().input(*aargs,**kkwargs)
def SHolYI1dP8g5ThqUAEt(*aargs,**kkwargs):
	return z3jwnDkZ76OfKFB1rRoQVghbE0u92.DialogProgress(*aargs,**kkwargs)
def vnI6XSlmEtsx7(direction,button0=nA5dhMRg6ENzsB0l1GwvH7aIr2,button1=nA5dhMRg6ENzsB0l1GwvH7aIr2,button2=nA5dhMRg6ENzsB0l1GwvH7aIr2,Tu4mE1VlHBO=nA5dhMRg6ENzsB0l1GwvH7aIr2,ooJmTWvjkAOHMN6EQSa23b4wiY8=nA5dhMRg6ENzsB0l1GwvH7aIr2,profile=HD7MQqXd2gS(u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡧ࡯ࡧࡧࡱࡱࡸࠬဂ"),eBaY4wsOd5RSr820FMtC3b6=IpFcwrWNgefMym3qta0hYQAzOdE,HTuM2mYB9CAgq=IpFcwrWNgefMym3qta0hYQAzOdE):
	if not direction: direction = XEcWOIwkZKubV7vQ(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫဃ")
	Z6uoKzn35I8yXs = iYAeb1pKuWtr3S52GPCh(ldIfvn6asURQ9toi85EhqAXW3(u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡈࡵ࡮ࡧ࡫ࡵࡱ࡙࡮ࡲࡦࡧࡅࡹࡹࡺ࡯࡯ࡵ࠱ࡼࡲࡲࠧင"),mQKDw6vcXNIkngiWrC8GdPFqeRH,ldIfvn6asURQ9toi85EhqAXW3(u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧစ"),n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠧ࠸࠴࠳ࡴࠬဆ"))
	Z6uoKzn35I8yXs.H41EK2XkiSsFrAh5Wy(button0,button1,button2,Tu4mE1VlHBO,ooJmTWvjkAOHMN6EQSa23b4wiY8,profile,direction,eBaY4wsOd5RSr820FMtC3b6,HTuM2mYB9CAgq)
	if eBaY4wsOd5RSr820FMtC3b6>IpFcwrWNgefMym3qta0hYQAzOdE: Z6uoKzn35I8yXs.gqc5blLE8Od6KhTys()
	if HTuM2mYB9CAgq>IpFcwrWNgefMym3qta0hYQAzOdE: Z6uoKzn35I8yXs.irWZpLH9no()
	if eBaY4wsOd5RSr820FMtC3b6==IpFcwrWNgefMym3qta0hYQAzOdE and HTuM2mYB9CAgq==IpFcwrWNgefMym3qta0hYQAzOdE: Z6uoKzn35I8yXs.dHXkm4GTqN()
	Z6uoKzn35I8yXs.doModal()
	Jxg8Od1foHnuRrwvZAW4iNCVMzEUF = Z6uoKzn35I8yXs.choiceID
	return Jxg8Od1foHnuRrwvZAW4iNCVMzEUF
def d9EaJh5t3Tyj7CsXFL(direction,Tu4mE1VlHBO,ooJmTWvjkAOHMN6EQSa23b4wiY8,profile=UUobzy0xZLaVScIt7(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩဇ")):
	if not direction: direction = JvQd6LMoBX4hiy1C(u"ࠩ࡯ࡩ࡫ࡺࠧဈ")
	Z6uoKzn35I8yXs = LhHmwYu3cT1VnbGkvN5iOD(rCmGE4YIDaZA(u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡗࡩࡽࡺࡖࡪࡧࡺࡩࡷࡌࡵ࡭࡮ࡖࡧࡷ࡫ࡥ࡯࠰ࡻࡱࡱ࠭ဉ"),mQKDw6vcXNIkngiWrC8GdPFqeRH,UUobzy0xZLaVScIt7(u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬည"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠬ࠽࠲࠱ࡲࠪဋ"))
	image_filename = N5F4JMDmHylghXfYS.replace(pxt6wJ8ScYMWCivoO(u"࠭࡟࠱࠲࠳࠴ࡤ࠭ဌ"),HD7MQqXd2gS(u"ࠧࡠࠩဍ")+str(h0skHe7TcIY9x1UP5VBrZAE8dKGnl.time())+UUobzy0xZLaVScIt7(u"ࠨࡡࠪဎ"))
	image_filename = image_filename.replace(DFx6E0uON7Jm8(u"ࠩ࡟ࡠࠬဏ"),pxt6wJ8ScYMWCivoO(u"ࠪࡠࡡࡢ࡜ࠨတ")).replace(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠫ࠴࠵ࠧထ"),mRanX1HZupfSQVB2gsDGUO(u"ࠬ࠵࠯࠰࠱ࠪဒ"))
	image_height = Nru4ln6fMS(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,Tu4mE1VlHBO,ooJmTWvjkAOHMN6EQSa23b4wiY8,profile,direction,FFKncZx5pDTwdiJRYhMgQSNL,image_filename)
	Z6uoKzn35I8yXs.show()
	Z6uoKzn35I8yXs.getControl(PPxYugzLZwHX23yiK(u"࠿࠰࠶࠲ᐊ")).setHeight(image_height)
	Z6uoKzn35I8yXs.getControl(JvQd6LMoBX4hiy1C(u"࠹࠱࠷࠳ᐋ")).setImage(image_filename)
	fZrv0AwH7isgUaLVdpqmRt5BjbQPW = Z6uoKzn35I8yXs.doModal()
	try: XoZRpFe7B6gnfA.remove(image_filename)
	except: pass
	return fZrv0AwH7isgUaLVdpqmRt5BjbQPW
def oOb8ZS417GwudNKHU6y(fhqzB9kJ8HeVP7dAFy4Z=S5MWhgtZ37Xw):
	if fhqzB9kJ8HeVP7dAFy4Z:
		cgob7MO2qshG = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠭ࡳࡵࡴࠪဓ"),bb1fgjsAq4N2xYwnoh39lm(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࡢ࠵ࠬန"),mRanX1HZupfSQVB2gsDGUO(u"ࠨࡗࡖࡉࡗࡇࡇࡆࡐࡗࠫပ"))
		if cgob7MO2qshG: return cgob7MO2qshG
	ooJmTWvjkAOHMN6EQSa23b4wiY8 = nA5dhMRg6ENzsB0l1GwvH7aIr2
	if IpFcwrWNgefMym3qta0hYQAzOdE and tkSbvVxf8h1d0gLTci.succeeded:
		h1hN5GRPeA2YIgmvKax3EMJfu9ilZ = tkSbvVxf8h1d0gLTci.content
		GsxA9qQzNZKg5XfiWuMd0HCE = h1hN5GRPeA2YIgmvKax3EMJfu9ilZ.count(nfNTgkiWdUq(u"ࠩࡐࡳࡿ࡯࡬࡭ࡣࠪဖ"))
		if GsxA9qQzNZKg5XfiWuMd0HCE>Pj9YaUq1ibJ(u"࠹࠲ᐌ"):
			ooJmTWvjkAOHMN6EQSa23b4wiY8 = PAztbuyYo4Kvd.findall(mRanX1HZupfSQVB2gsDGUO(u"ࠪ࡫ࡪࡺ࠭ࡵࡪࡨ࠱ࡱ࡯ࡳࡵ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬဗ"),h1hN5GRPeA2YIgmvKax3EMJfu9ilZ,PAztbuyYo4Kvd.DOTALL)
			ooJmTWvjkAOHMN6EQSa23b4wiY8 = ooJmTWvjkAOHMN6EQSa23b4wiY8[IpFcwrWNgefMym3qta0hYQAzOdE]
	if not ooJmTWvjkAOHMN6EQSa23b4wiY8:
		GAJVvSc6dIs21gL0wpzWRaxPQb7N = XoZRpFe7B6gnfA.path.join(mQKDw6vcXNIkngiWrC8GdPFqeRH,ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪဘ"),HD7MQqXd2gS(u"ࠬࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡴ࠰ࡷࡼࡹ࠭မ"))
		ooJmTWvjkAOHMN6EQSa23b4wiY8 = open(GAJVvSc6dIs21gL0wpzWRaxPQb7N,pxt6wJ8ScYMWCivoO(u"࠭ࡲࡣࠩယ")).read()
		if BsLJ7p5Av2Vm0SQeCO1o: ooJmTWvjkAOHMN6EQSa23b4wiY8 = ooJmTWvjkAOHMN6EQSa23b4wiY8.decode(YWEQ3Cf8RevpD0m7NjF1)
		ooJmTWvjkAOHMN6EQSa23b4wiY8 = ooJmTWvjkAOHMN6EQSa23b4wiY8.replace(sSBzjZdcbQraNx,nA5dhMRg6ENzsB0l1GwvH7aIr2)
	NPuRmtg9khj = PAztbuyYo4Kvd.findall(XEcWOIwkZKubV7vQ(u"ࠧࠩࡏࡲࡾ࡮ࡲ࡬ࡢ࠰࠭ࡃ࠮ࡢ࡮ࠨရ"),ooJmTWvjkAOHMN6EQSa23b4wiY8,PAztbuyYo4Kvd.DOTALL)
	zW2sb3gQ8NlEpjewGIqK5rxo = []
	for MBQ1jYxHkSyVD72cg6niAIRaC in NPuRmtg9khj:
		b8tT31ySvE4uGBxc7M6UDkYZXRn0 = MBQ1jYxHkSyVD72cg6niAIRaC.lower()
		if PPxYugzLZwHX23yiK(u"ࠨࡣࡱࡨࡷࡵࡩࡥࠩလ") in b8tT31ySvE4uGBxc7M6UDkYZXRn0: continue
		if mRanX1HZupfSQVB2gsDGUO(u"ࠩࡸࡦࡺࡴࡴࡶࠩဝ") in b8tT31ySvE4uGBxc7M6UDkYZXRn0: continue
		if baBcNd81eH5ry2Olp6Mj43(u"ࠪ࡭ࡵ࡮࡯࡯ࡧࠪသ") in b8tT31ySvE4uGBxc7M6UDkYZXRn0: continue
		if YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠫࡨࡸ࡯ࡴࠩဟ") in b8tT31ySvE4uGBxc7M6UDkYZXRn0: continue
		zW2sb3gQ8NlEpjewGIqK5rxo.append(MBQ1jYxHkSyVD72cg6niAIRaC)
	cgob7MO2qshG = avZmSHVO7swUYFnTu5p9iNR8g.sample(zW2sb3gQ8NlEpjewGIqK5rxo,UnOIK1WBbw2)
	cgob7MO2qshG = cgob7MO2qshG[IpFcwrWNgefMym3qta0hYQAzOdE]
	WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,Pj9YaUq1ibJ(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࡠ࠳ࠪဠ"),lw2snZ9J0uhLoxypqa(u"࠭ࡕࡔࡇࡕࡅࡌࡋࡎࡕࠩအ"),cgob7MO2qshG,QdwW2s0iEp56qMmvCbOeLxBRU)
	return cgob7MO2qshG
def GznfPAD8ard3y4h(ZZcxIq8bHKnPy2VREUMFG=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if Nzp9Fq5cTr.ALLOW_SHOWDIALOGS_FIX==FFKncZx5pDTwdiJRYhMgQSNL: return
	if not ZZcxIq8bHKnPy2VREUMFG: ZZcxIq8bHKnPy2VREUMFG = G7QdMkY6Rr.format_exc()
	if Pj9YaUq1ibJ(u"ࠧࡔࡻࡶࡸࡪࡳࡅࡹ࡫ࡷࠫဢ") in ZZcxIq8bHKnPy2VREUMFG or lw2snZ9J0uhLoxypqa(u"ࠨࡡࡢࡣࡋࡕࡒࡄࡇࡢࡉ࡝ࡏࡔࡠࡡࡢࠫဣ") in ZZcxIq8bHKnPy2VREUMFG: return
	if ZZcxIq8bHKnPy2VREUMFG!=gmPI7hVEM8nD(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬဤ"): kCNHMOym1luTnJ0.stderr.write(ZZcxIq8bHKnPy2VREUMFG)
	Df6jx49PNm8 = ZZcxIq8bHKnPy2VREUMFG.splitlines()
	OM5zCN21ERDn6ydljYpF = Df6jx49PNm8[-ldIfvn6asURQ9toi85EhqAXW3(u"࠳ᐍ")]
	a9qRC7fhskwdDiyg3YJW6 = open(Mtgex07pkPUj6z,pxt6wJ8ScYMWCivoO(u"ࠪࡶࡧ࠭ဥ")).read()
	if BsLJ7p5Av2Vm0SQeCO1o: a9qRC7fhskwdDiyg3YJW6 = a9qRC7fhskwdDiyg3YJW6.decode(YWEQ3Cf8RevpD0m7NjF1)
	a9qRC7fhskwdDiyg3YJW6 = a9qRC7fhskwdDiyg3YJW6[-LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠻࠴࠵࠶ᐎ"):]
	bzUCfhqk0j = bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠫࡂ࠭ဦ")*HD7MQqXd2gS(u"࠵࠵࠶ᐏ")
	if bzUCfhqk0j in a9qRC7fhskwdDiyg3YJW6: a9qRC7fhskwdDiyg3YJW6 = a9qRC7fhskwdDiyg3YJW6.rsplit(bzUCfhqk0j,UnOIK1WBbw2)[UnOIK1WBbw2]
	if OM5zCN21ERDn6ydljYpF in a9qRC7fhskwdDiyg3YJW6: a9qRC7fhskwdDiyg3YJW6 = a9qRC7fhskwdDiyg3YJW6.rsplit(OM5zCN21ERDn6ydljYpF,UnOIK1WBbw2)[IpFcwrWNgefMym3qta0hYQAzOdE]
	hMoa1XBSgH = PAztbuyYo4Kvd.findall(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠬ࠮ࡓࡰࡷࡵࡧࡪࢂࡍࡰࡦࡨ࠭࠿ࠦ࡜࡜ࠢࠫ࠲࠯ࡅࠩࠡ࡞ࡠࠫဧ"),a9qRC7fhskwdDiyg3YJW6,PAztbuyYo4Kvd.DOTALL)
	for LOIYTyQrhHb379,FjO41UWNvs0Gg in reversed(hMoa1XBSgH):
		if FjO41UWNvs0Gg: break
	else: FjO41UWNvs0Gg = mRanX1HZupfSQVB2gsDGUO(u"࠭ࡎࡐࡖࠣࡗࡕࡋࡃࡊࡈࡌࡉࡉ࠭ဨ")
	hhZ6lIumVNX,MBQ1jYxHkSyVD72cg6niAIRaC,XRfZdpskljnyKiIvTFq4O3Mt1 = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	t1M4LYOzZp8am = bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠧ࡜ࡔࡗࡐࡢ࠭ဩ")+lSWzOYmN08+vzqjsVHSBlMpxC(u"ࠨษ็า฼ษ࠺ࠡࠢࠪဪ")+NwROdSj3nsA+OM5zCN21ERDn6ydljYpF
	HKGbumzxgnk87JlLdVvWeS0ZhX = bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨါ")+lSWzOYmN08+lw2snZ9J0uhLoxypqa(u"ࠪห้๋ีะำ࠽ࠤࠥ࠭ာ")+NwROdSj3nsA+FjO41UWNvs0Gg
	for s3slevH2WaUMEYyt in reversed(Df6jx49PNm8):
		if pxt6wJ8ScYMWCivoO(u"ࠫࡋ࡯࡬ࡦࠢࠥࠫိ") in s3slevH2WaUMEYyt and yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫီ") in s3slevH2WaUMEYyt: break
	s3slevH2WaUMEYyt = PAztbuyYo4Kvd.findall(Pj9YaUq1ibJ(u"࠭ࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࠬࠦࡡ࠲ࠠ࡭࡫ࡱࡩࠥ࠮࠮ࠫࡁࠬࡠ࠱ࠦࡩ࡯ࠢࠫ࠲࠯ࡅࠩࠥࠩု"),s3slevH2WaUMEYyt,PAztbuyYo4Kvd.DOTALL)
	if s3slevH2WaUMEYyt:
		hhZ6lIumVNX,MBQ1jYxHkSyVD72cg6niAIRaC,XRfZdpskljnyKiIvTFq4O3Mt1 = s3slevH2WaUMEYyt[IpFcwrWNgefMym3qta0hYQAzOdE]
		if Qy6wlfLoOpg1(u"ࠧ࠰ࠩူ") in hhZ6lIumVNX: hhZ6lIumVNX = hhZ6lIumVNX.rsplit(lw2snZ9J0uhLoxypqa(u"ࠨ࠱ࠪေ"),UnOIK1WBbw2)[UnOIK1WBbw2]
		else: hhZ6lIumVNX = hhZ6lIumVNX.rsplit(Yj1msqVeivESfrCupRy9b7WacBd(u"ࠩ࡟ࡠࠬဲ"),UnOIK1WBbw2)[UnOIK1WBbw2]
		Sgz9XFQJ2rqIcPitMpm = Yj1msqVeivESfrCupRy9b7WacBd(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩဳ")+lSWzOYmN08+PPxYugzLZwHX23yiK(u"ࠫฬ๊ๅๅใ࠽ࠤࠥ࠭ဴ")+NwROdSj3nsA+hhZ6lIumVNX
		cjz0tFbeTumWOd2PoDHJi = Pj9YaUq1ibJ(u"ࠬࡡࡒࡕࡎࡠࠫဵ")+lSWzOYmN08+w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠭วๅีฺี࠿ࠦࠠࠨံ")+NwROdSj3nsA+MBQ1jYxHkSyVD72cg6niAIRaC
		vMw8lRn6DTF0zIHiucmLjo3 = bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠧ࡜ࡔࡗࡐࡢ့࠭")+lSWzOYmN08+UUobzy0xZLaVScIt7(u"ࠨษ็้่อๆ࠻ࠢࠣࠫး")+NwROdSj3nsA+XRfZdpskljnyKiIvTFq4O3Mt1
		yjSBLvZYHJM = Sgz9XFQJ2rqIcPitMpm+CXtugbqhV3+cjz0tFbeTumWOd2PoDHJi+CXtugbqhV3+vMw8lRn6DTF0zIHiucmLjo3+CXtugbqhV3+HKGbumzxgnk87JlLdVvWeS0ZhX+CXtugbqhV3+t1M4LYOzZp8am
		MMq4CGsYXwRP = cjz0tFbeTumWOd2PoDHJi+CXtugbqhV3+HKGbumzxgnk87JlLdVvWeS0ZhX+CXtugbqhV3+t1M4LYOzZp8am+CXtugbqhV3+Sgz9XFQJ2rqIcPitMpm+CXtugbqhV3+vMw8lRn6DTF0zIHiucmLjo3
		FRbvnxdUfgaCHpN45V = cjz0tFbeTumWOd2PoDHJi+CXtugbqhV3+t1M4LYOzZp8am+CXtugbqhV3+Sgz9XFQJ2rqIcPitMpm+CXtugbqhV3+vMw8lRn6DTF0zIHiucmLjo3
	else:
		Sgz9XFQJ2rqIcPitMpm,cjz0tFbeTumWOd2PoDHJi,vMw8lRn6DTF0zIHiucmLjo3 = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
		yjSBLvZYHJM = HKGbumzxgnk87JlLdVvWeS0ZhX+lw2snZ9J0uhLoxypqa(u"ࠩ࡟ࡲࡡࡴ္ࠧ")+t1M4LYOzZp8am
		MMq4CGsYXwRP = HKGbumzxgnk87JlLdVvWeS0ZhX+ldIfvn6asURQ9toi85EhqAXW3(u"ࠪࡠࡳࡢ࡮ࠨ်")+t1M4LYOzZp8am
		FRbvnxdUfgaCHpN45V = t1M4LYOzZp8am
	GQvCq7gbBpo0XWxAfNS8RO = JvQd6LMoBX4hiy1C(u"ࠫาีหࠡะฺวࠥเ๊า่ࠢๆฺ๎ฯࠨျ")+CXtugbqhV3
	pXzR8bC5mFJL1 = SvsRiXawpqUo51fd()
	uvBw9r085LET3Wp4fAq2gD7UZ16X = []
	V9OGBuyogH0CaUtQS6wWErAbPYDjlM = pXzR8bC5mFJL1[lw2snZ9J0uhLoxypqa(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪြ")]
	stWlCIQ5abqOoBY = u7CoUO12mcNP4RSfQ(s5WcxEPjUBokapYMhAwb60dvgi)
	if bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫွ") in list(pXzR8bC5mFJL1.keys()):
		for Y6i2MkG7ROgbS5dEL1zfvuoj8VXI,YYJeIOoXzjbP4EnmUqg2iZ1fKld,uwXfKSBg8YP2vFqZ7QzN in V9OGBuyogH0CaUtQS6wWErAbPYDjlM:
			uvBw9r085LET3Wp4fAq2gD7UZ16X = max(uvBw9r085LET3Wp4fAq2gD7UZ16X,YYJeIOoXzjbP4EnmUqg2iZ1fKld)
		if stWlCIQ5abqOoBY<uvBw9r085LET3Wp4fAq2gD7UZ16X:
			Tu4mE1VlHBO = mRanX1HZupfSQVB2gsDGUO(u"ࠧใ็ࠣฬฯำฯ๋อࠣห้ฮั็ษ่ะ่ࠥศๅࠢศีุอไࠡษ็วำ฽วยࠢ็่๊ฮัๆฮࠪှ")
			Jxg8Od1foHnuRrwvZAW4iNCVMzEUF = vnI6XSlmEtsx7(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠨࡴ࡬࡫࡭ࡺࠧဿ"),PPxYugzLZwHX23yiK(u"ࠩศีุอไࠡว็ํࠥอไๆสิ้ั࠭၀"),pxt6wJ8ScYMWCivoO(u"ࠪฮาี๊ฬࠩ၁"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠫำื่อࠩ၂"),GQvCq7gbBpo0XWxAfNS8RO+Tu4mE1VlHBO,yjSBLvZYHJM)
			if Jxg8Od1foHnuRrwvZAW4iNCVMzEUF==UnOIK1WBbw2:
				import nkKg6CFTbN
				nkKg6CFTbN.mzxoBQsiXNTZt6cw5gOyfLAjprRh(S5MWhgtZ37Xw)
				OeR9Dyin6a4hK5VvFMBo()
			elif Jxg8Od1foHnuRrwvZAW4iNCVMzEUF==udq5tP0hwifHQCGYELDbOUI: OeR9Dyin6a4hK5VvFMBo()
	XwiczS0xPdWFp = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,pxt6wJ8ScYMWCivoO(u"ࠬࡲࡩࡴࡶࠪ၃"),JvQd6LMoBX4hiy1C(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ၄"),lw2snZ9J0uhLoxypqa(u"ࠧࡂࡎࡏࡣࡘࡋࡎࡕࡡࡈࡖࡗࡕࡒࡔࠩ၅"))
	if not XwiczS0xPdWFp: XwiczS0xPdWFp = []
	MMq4CGsYXwRP = MMq4CGsYXwRP.replace(CXtugbqhV3,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠨ࡞࡟ࡲࠬ၆")).replace(DFx6E0uON7Jm8(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨ၇"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(lSWzOYmN08,nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2)
	FRbvnxdUfgaCHpN45V = FRbvnxdUfgaCHpN45V.replace(CXtugbqhV3,HD7MQqXd2gS(u"ࠪࡠࡡࡴࠧ၈")).replace(rCmGE4YIDaZA(u"ࠫࡠࡘࡔࡍ࡟ࠪ၉"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(lSWzOYmN08,nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2)
	qqSEmfirYXul0H6UZzCaVbT7tGw8 = s5WcxEPjUBokapYMhAwb60dvgi+bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠬࡀ࠺ࠨ၊")+FRbvnxdUfgaCHpN45V
	if qqSEmfirYXul0H6UZzCaVbT7tGw8 in XwiczS0xPdWFp:
		Tu4mE1VlHBO = bb1fgjsAq4N2xYwnoh39lm(u"࠭ไใัࠣๆ๊ะࠠศ่อࠤุอศใษࠣฬสืำศๆ๋ࠣีอࠠศๆั฻ศࠦลๅ๋ࠣห้๋ศา็ฯࠫ။")
		OmxJV4UQyeFqdBSIC0(VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭၌"),nA5dhMRg6ENzsB0l1GwvH7aIr2,GQvCq7gbBpo0XWxAfNS8RO+Tu4mE1VlHBO,yjSBLvZYHJM)
		return
	vWLnZwJSuYkKUlq = str(l2JAnWsaDGz8CIEZY).split(DFx6E0uON7Jm8(u"ࠨ࠰ࠪ၍"))[IpFcwrWNgefMym3qta0hYQAzOdE]
	RxWJFBAGy4iIM = Nzp9Fq5cTr.SITESURLS[jil8vRpBsENVYyPmDd(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ၎")][VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠻ᐐ")]
	tkSbvVxf8h1d0gLTci = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,Qy6wlfLoOpg1(u"ࠪࡔࡔ࡙ࡔࠨ၏"),RxWJFBAGy4iIM,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,AJHaiQq3PRd5cphzGuELnVg9X(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡈࡐ࡙ࡢࡉ࡝ࡏࡔࡠࡇࡕࡖࡔࡘࡓ࠮࠳ࡶࡸࠬၐ"),FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL)
	h1hN5GRPeA2YIgmvKax3EMJfu9ilZ = tkSbvVxf8h1d0gLTci.content
	MFzUjyv9gpTAD68LKum4fo = PAztbuyYo4Kvd.findall(lw2snZ9J0uhLoxypqa(u"࡙ࠬࡔࡂࡔࡗ࠾࠿࡙ࡔࡂࡔࡗ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮ࡉࡓࡊ࠺࠻ࡇࡑࡈࠬၑ"),h1hN5GRPeA2YIgmvKax3EMJfu9ilZ,PAztbuyYo4Kvd.DOTALL)
	for WhFurnAYvyec,u0iWD5dMrc6,ssMAonY67Tbk,KOZpVsvf8cPX6dzt5AMWTbmSiYg2 in MFzUjyv9gpTAD68LKum4fo:
		WhFurnAYvyec = WhFurnAYvyec.split(UUobzy0xZLaVScIt7(u"࠭ࠫࠨၒ"))
		ssMAonY67Tbk = ssMAonY67Tbk.split(HD7MQqXd2gS(u"ࠧࠬࠩၓ"))
		KOZpVsvf8cPX6dzt5AMWTbmSiYg2 = KOZpVsvf8cPX6dzt5AMWTbmSiYg2.split(jil8vRpBsENVYyPmDd(u"ࠨ࠭ࠪၔ"))
		if MBQ1jYxHkSyVD72cg6niAIRaC in WhFurnAYvyec and OM5zCN21ERDn6ydljYpF==u0iWD5dMrc6 and s5WcxEPjUBokapYMhAwb60dvgi in ssMAonY67Tbk and vWLnZwJSuYkKUlq in KOZpVsvf8cPX6dzt5AMWTbmSiYg2:
			Tu4mE1VlHBO = yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"๊ࠩิฬࠦวๅะฺวู๋ࠥา๊ไࠤํฺู๊ษ็ะࠥฮวๅวุำฬืࠠศๆๅหิ๋ࠧၕ")
			x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(mRanX1HZupfSQVB2gsDGUO(u"ࠪࡶ࡮࡭ࡨࡵࠩၖ"),pxt6wJ8ScYMWCivoO(u"ࠫำื่อࠩၗ"),ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩၘ"),GQvCq7gbBpo0XWxAfNS8RO+Tu4mE1VlHBO,yjSBLvZYHJM)
			if x6zlf2tTZm==UnOIK1WBbw2: OmxJV4UQyeFqdBSIC0(FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ၙ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,Tu4mE1VlHBO)
			return
	Tu4mE1VlHBO = UUobzy0xZLaVScIt7(u"ࠧศๆิะฬวࠠฦำึห้ࠦ็ัษࠣห้ิืฤࠢศ่๎ࠦวๅ็หี๊าࠧၚ")
	igSA3BDxXY14efJCGs = vnI6XSlmEtsx7(XEcWOIwkZKubV7vQ(u"ࠨࡴ࡬࡫࡭ࡺࠧၛ"),AJHaiQq3PRd5cphzGuELnVg9X(u"ࠩศีุอไࠡว็ํࠥอไๆสิ้ั࠭ၜ"),xwIUQfiE7rmvYzH(u"ࠪฮาี๊ฬࠢฯึห๐ࠧၝ"),baBcNd81eH5ry2Olp6Mj43(u"ࠫฯำฯ๋อࠣห้ฮั็ษ่ะࠬၞ"),GQvCq7gbBpo0XWxAfNS8RO+Tu4mE1VlHBO,yjSBLvZYHJM)
	if igSA3BDxXY14efJCGs==UnOIK1WBbw2:
		w59lKDhpOYZm(FFKncZx5pDTwdiJRYhMgQSNL)
		ggYilKR5rMDyp7B(rCmGE4YIDaZA(u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢส่ฯำฯ๋อࠣห้าาว์ࠪၟ"),HD7MQqXd2gS(u"࠭ํࡔࡷࡦࡧࡪࡹࡳࠨၠ"),h0skHe7TcIY9x1UP5VBrZAE8dKGnl=xwIUQfiE7rmvYzH(u"࠽࠵࠱ᐑ"))
		OeR9Dyin6a4hK5VvFMBo()
	elif igSA3BDxXY14efJCGs==udq5tP0hwifHQCGYELDbOUI:
		import nkKg6CFTbN
		nkKg6CFTbN.mzxoBQsiXNTZt6cw5gOyfLAjprRh(S5MWhgtZ37Xw)
		OeR9Dyin6a4hK5VvFMBo()
	x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(bb1fgjsAq4N2xYwnoh39lm(u"ࠧࡤࡧࡱࡸࡪࡸࠧၡ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,mRanX1HZupfSQVB2gsDGUO(u"ࠨี๋ๅࠥ๐สๆࠢศีุอไࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡๆๆ๎ࠥ๐ูาใࠣห้๋ศา็ฯࠤศ๐ๆ๊่ࠡฮ๎่ࠦไ์ไࠤํ๊ๅศาสࠤา฻ไห๊ࠢิ์ࠦวๅ็ื็้ฯࠠๅล้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠥ๎ไศࠢํืฯ฽ฺ๊ࠢสู้ออࠡ็ื็้ฯ้้๋ࠠࠤ้อ๋ࠠ฻ิๅ้๊ࠥโࠢ฻๋ึะ้ࠠๆ่หีอู้ࠠิฮࠥ๎ๅห๋ࠣ฼์ืส้ࠡำ๋ࠥอไๆึๆ่ฮࠦ࠮้ࠡ็ࠤฯื๊ะࠢฦีุอไࠡษ็ืั๊ࠠภࠩၢ"))
	if x6zlf2tTZm==UnOIK1WBbw2: J3dmKbe7QfWCv1EByjANZ = bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬၣ")
	else:
		OmxJV4UQyeFqdBSIC0(Pj9YaUq1ibJ(u"ࠪࡧࡪࡴࡴࡦࡴࠪၤ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,lSWzOYmN08+bb1fgjsAq4N2xYwnoh39lm(u"ࠫฯ๋ࠠฦๆ฽หฦࠦลาีส่ࠥอไฯูฦࠫၥ")+NwROdSj3nsA+HD7MQqXd2gS(u"ࠬࡢ࡮ๅล้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠥ๎ไศࠢํืฯ฽ฺ๊ࠢศู้ออࠡษ็า฼ษࠠษัู๋๊ࠥฬๅࠢส่ศิืศรࠣห้ึ๊ࠡ็ๆฮํฮࠠโ์๊ࠤัฺ๋๊ࠢอๅฬ฻๊ๅ๊ࠢิฬࠦวๅะฺวࠥ๎ฺ๋ำ๊ࠤ๊์ࠠศๆฦา฼อมࠨၦ"))
		return
	oZOKmgkbJIHtAyuvrqFQBS1CzNa0Tw = MMq4CGsYXwRP
	import nkKg6CFTbN
	zTEXepHg92GkWf = nkKg6CFTbN.gitJOXchdnSNVpjbLAKPq6Ds41WRuI(AJHaiQq3PRd5cphzGuELnVg9X(u"࠭ࡅࡳࡴࡲࡶࡸ࠭ၧ"),oZOKmgkbJIHtAyuvrqFQBS1CzNa0Tw,S5MWhgtZ37Xw,nA5dhMRg6ENzsB0l1GwvH7aIr2,DFx6E0uON7Jm8(u"ࠧࡆࡏࡄࡍࡑ࠳ࡆࡓࡑࡐ࠱ࡘࡎࡏࡘࡡࡈ࡜ࡎ࡚࡟ࡆࡔࡕࡓࡗ࡙ࠧၨ"),J3dmKbe7QfWCv1EByjANZ)
	if zTEXepHg92GkWf and J3dmKbe7QfWCv1EByjANZ:
		XwiczS0xPdWFp.append(qqSEmfirYXul0H6UZzCaVbT7tGw8)
		WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,bb1fgjsAq4N2xYwnoh39lm(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫၩ"),Yj1msqVeivESfrCupRy9b7WacBd(u"ࠩࡄࡐࡑࡥࡓࡆࡐࡗࡣࡊࡘࡒࡐࡔࡖࠫၪ"),XwiczS0xPdWFp,l7ltVNxrbPimpXJDh)
	return
def H31dtjlxUFrCs9mW64aY(JEiFBCayPfze7n3KspN6AY,filename=YWylfpKSRb):
	h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(pxt6wJ8ScYMWCivoO(u"࠰࠯࠲࠵࠹ᐒ"))
	if BsLJ7p5Av2Vm0SQeCO1o: JEiFBCayPfze7n3KspN6AY = JEiFBCayPfze7n3KspN6AY.encode(YWEQ3Cf8RevpD0m7NjF1)
	if not filename: SR0vOrfBXW6AJ = ldIfvn6asURQ9toi85EhqAXW3(u"ࠪࡷ࠿ࡢ࡜࠱࠲࠳࠴ࡪࡳࡡࡥࡡࠪၫ")+str(h0skHe7TcIY9x1UP5VBrZAE8dKGnl.time())+PPxYugzLZwHX23yiK(u"ࠫ࠳ࡪࡡࡵࠩၬ")
	else: SR0vOrfBXW6AJ = LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠬࡹ࠺࡝࡞࠳࠴࠵࠶ࡥ࡮ࡣࡧࡣࠬၭ")+filename+bb1fgjsAq4N2xYwnoh39lm(u"࠭࠮ࡥࡣࡷࠫၮ")
	open(SR0vOrfBXW6AJ,bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠧࡸࡤࠪၯ")).write(JEiFBCayPfze7n3KspN6AY)
	return
def bAQuqZOzEGe8DCH2RTwtL9(aoD3bFQiButV50LwGnhkRszJSm7):
	if aoD3bFQiButV50LwGnhkRszJSm7:
		LOYHM0pRiEKka5SfWVzxcUAlXumZt = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,gmPI7hVEM8nD(u"ࠨ࡮࡬ࡷࡹ࠭ၰ"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠷ࠧၱ"),gmPI7hVEM8nD(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭ၲ"))
		if LOYHM0pRiEKka5SfWVzxcUAlXumZt: return LOYHM0pRiEKka5SfWVzxcUAlXumZt
	RxWJFBAGy4iIM = Nzp9Fq5cTr.SITESURLS[YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫၳ")][rCmGE4YIDaZA(u"࠶ᐓ")]
	QQlJ2xKXAGUzh = JrbHs6SAj9MouPqEGZO(FFKncZx5pDTwdiJRYhMgQSNL) if not aoD3bFQiButV50LwGnhkRszJSm7 else Nzp9Fq5cTr.AV_CLIENT_IDS
	MMENSb8ojUDHBG5 = Cu2PQbzG5shMkL08cdYNOfjvKx9o()
	iPWN5tr1aBS0YZnmlgOM = MMENSb8ojUDHBG5.split(gmPI7hVEM8nD(u"ࠬ࠲ࠧၴ"))[udq5tP0hwifHQCGYELDbOUI]
	S706VNtgw3yU = XoZRpFe7B6gnfA.path.join(mQKDw6vcXNIkngiWrC8GdPFqeRH,FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬၵ"))
	bvnOLkyBGt0pr3Nwx = CrklfeQ3LOI1X()
	S0adTZ3gA7vexpiNfPJt2mVKuURM = {nfNTgkiWdUq(u"ࠧࡶࡵࡨࡶࠬၶ"):QQlJ2xKXAGUzh,pxt6wJ8ScYMWCivoO(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩၷ"):s5WcxEPjUBokapYMhAwb60dvgi,bb1fgjsAq4N2xYwnoh39lm(u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪၸ"):iPWN5tr1aBS0YZnmlgOM,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠪ࡭ࡩࡹࠧၹ"):AsG2TjLa1DUMI(bvnOLkyBGt0pr3Nwx)}
	tkSbvVxf8h1d0gLTci = uANakQHcnhR(yy6RomT9bQhJf,DFx6E0uON7Jm8(u"ࠫࡕࡕࡓࡕࠩၺ"),RxWJFBAGy4iIM,S0adTZ3gA7vexpiNfPJt2mVKuURM,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠳࠱ࡴࡶࠪၻ"))
	LOYHM0pRiEKka5SfWVzxcUAlXumZt = []
	if tkSbvVxf8h1d0gLTci.succeeded:
		h1hN5GRPeA2YIgmvKax3EMJfu9ilZ = tkSbvVxf8h1d0gLTci.content
		LOYHM0pRiEKka5SfWVzxcUAlXumZt = h1hN5GRPeA2YIgmvKax3EMJfu9ilZ.replace(zhE5I4xHinX0UoVZMNwlkPrR(u"࠭࡜࡝ࡴࠪၼ"),CXtugbqhV3).replace(nfNTgkiWdUq(u"ࠧ࡝࡞ࡱࠫၽ"),CXtugbqhV3).replace(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠨ࡞ࡵࡠࡳ࠭ၾ"),CXtugbqhV3).replace(sSBzjZdcbQraNx,CXtugbqhV3)
		LOYHM0pRiEKka5SfWVzxcUAlXumZt = PAztbuyYo4Kvd.findall(bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠩࡖࡘࡆࡘࡔ࠻࠼ࡖࡘࡆࡘࡔ࠻࠼ࠫࡠࡩ࠱ࠩ࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱࡉࡓࡊ࠺࠻ࡇࡑࡈࠬၿ"),LOYHM0pRiEKka5SfWVzxcUAlXumZt,PAztbuyYo4Kvd.DOTALL)
		if LOYHM0pRiEKka5SfWVzxcUAlXumZt:
			LOYHM0pRiEKka5SfWVzxcUAlXumZt = sorted(LOYHM0pRiEKka5SfWVzxcUAlXumZt,reverse=FFKncZx5pDTwdiJRYhMgQSNL,key=lambda key: int(key[IpFcwrWNgefMym3qta0hYQAzOdE]))
			aUJr1yX8602OvfEm9dWjkZH,QQlJ2xKXAGUzh,mGy19ecrPjKCF,ccTbOMIrUX13m4pNRfyGquCadwJE,i4LsgZVpI3cQ,YZAKaSrmp57OUEtIXcyv3hoe8RVqWG = LOYHM0pRiEKka5SfWVzxcUAlXumZt[IpFcwrWNgefMym3qta0hYQAzOdE]
			D5xFVeJasC9f6OLvmu1 = YZAKaSrmp57OUEtIXcyv3hoe8RVqWG if Nzp9Fq5cTr.avprivslongperiod else mGy19ecrPjKCF
			KQctJbXeEjDhplqknU3rzi.setSetting(gmPI7hVEM8nD(u"ࠪࡥࡻ࠴ࡰࡦࡴ࡬ࡳࡩ࠴ࡩ࡯ࡨࡲࡷࠬႀ"),D5xFVeJasC9f6OLvmu1)
			WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖ࡟࠲ࠩႁ"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨႂ"),LOYHM0pRiEKka5SfWVzxcUAlXumZt,QdwW2s0iEp56qMmvCbOeLxBRU)
			KQctJbXeEjDhplqknU3rzi.setSetting(bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨႃ"),AsG2TjLa1DUMI(GHSrzcU3jo2))
	return LOYHM0pRiEKka5SfWVzxcUAlXumZt
def yfPE67m3z9KO0WYtLSqBGCTQX(d2xVuyiIPc,XSG0oihyE6Rb=IpFcwrWNgefMym3qta0hYQAzOdE,STLgzh2PbA3w=IpFcwrWNgefMym3qta0hYQAzOdE):
	if XSG0oihyE6Rb and not STLgzh2PbA3w: STLgzh2PbA3w = len(d2xVuyiIPc)//XSG0oihyE6Rb
	eRdgEJSMHzlDfXZOxuoq,hsqrMEVB70i2ZnzPHlGYD1oy,NNvUtJnePHZ8wra49 = [],-UnOIK1WBbw2,IpFcwrWNgefMym3qta0hYQAzOdE
	for X5lnUjdopBiE in d2xVuyiIPc:
		if NNvUtJnePHZ8wra49%STLgzh2PbA3w==IpFcwrWNgefMym3qta0hYQAzOdE:
			hsqrMEVB70i2ZnzPHlGYD1oy += UnOIK1WBbw2
			eRdgEJSMHzlDfXZOxuoq.append([])
		eRdgEJSMHzlDfXZOxuoq[hsqrMEVB70i2ZnzPHlGYD1oy].append(X5lnUjdopBiE)
		NNvUtJnePHZ8wra49 += UnOIK1WBbw2
	return eRdgEJSMHzlDfXZOxuoq
def JO42mSdB30jeF(SR0vOrfBXW6AJ,JEiFBCayPfze7n3KspN6AY):
	i9GKPyIEQjSC6tpgo = XoZRpFe7B6gnfA.path.join(QQwBc24Oza7jJ8ClTRWexUoqGAkg0,SR0vOrfBXW6AJ)
	if UnOIK1WBbw2 or Yj1msqVeivESfrCupRy9b7WacBd(u"ࠧࡊࡒࡗ࡚ࡤ࠭ႄ") not in SR0vOrfBXW6AJ or bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠨࡏ࠶࡙ࡤ࠭ႅ") not in SR0vOrfBXW6AJ: ooJmTWvjkAOHMN6EQSa23b4wiY8 = str(JEiFBCayPfze7n3KspN6AY)
	else:
		eRdgEJSMHzlDfXZOxuoq = yfPE67m3z9KO0WYtLSqBGCTQX(JEiFBCayPfze7n3KspN6AY,HD7MQqXd2gS(u"࠺ᐔ"))
		ooJmTWvjkAOHMN6EQSa23b4wiY8 = nA5dhMRg6ENzsB0l1GwvH7aIr2
		for eIsjxbpgoGTf in eRdgEJSMHzlDfXZOxuoq:
			ooJmTWvjkAOHMN6EQSa23b4wiY8 += str(eIsjxbpgoGTf)+yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨႆ")
		ooJmTWvjkAOHMN6EQSa23b4wiY8 = ooJmTWvjkAOHMN6EQSa23b4wiY8.strip(JvQd6LMoBX4hiy1C(u"ࠪࡠࡳࡢ࡮࠾࠿ࡀࡁࡡࡴ࡜࡯ࠩႇ"))
	xeFjaWpC5qLGgkvrK4t6H97mOR = BV9K0HISqUzm4G2WhAnOblM.compress(ooJmTWvjkAOHMN6EQSa23b4wiY8)
	open(i9GKPyIEQjSC6tpgo,gmPI7hVEM8nD(u"ࠫࡼࡨࠧႈ")).write(xeFjaWpC5qLGgkvrK4t6H97mOR)
	return
def ysMuxdn92YZIA5T(DPbIJFcMks7BewZzAn,SR0vOrfBXW6AJ):
	if DPbIJFcMks7BewZzAn==xwIUQfiE7rmvYzH(u"ࠬࡪࡩࡤࡶࠪႉ"): JEiFBCayPfze7n3KspN6AY = {}
	elif DPbIJFcMks7BewZzAn==pxt6wJ8ScYMWCivoO(u"࠭࡬ࡪࡵࡷࠫႊ"): JEiFBCayPfze7n3KspN6AY = []
	elif DPbIJFcMks7BewZzAn==gmPI7hVEM8nD(u"ࠧࡴࡶࡵࠫႋ"): JEiFBCayPfze7n3KspN6AY = nA5dhMRg6ENzsB0l1GwvH7aIr2
	elif DPbIJFcMks7BewZzAn==lw2snZ9J0uhLoxypqa(u"ࠨ࡫ࡱࡸࠬႌ"): JEiFBCayPfze7n3KspN6AY = IpFcwrWNgefMym3qta0hYQAzOdE
	else: JEiFBCayPfze7n3KspN6AY = YWylfpKSRb
	i9GKPyIEQjSC6tpgo = XoZRpFe7B6gnfA.path.join(QQwBc24Oza7jJ8ClTRWexUoqGAkg0,SR0vOrfBXW6AJ)
	xeFjaWpC5qLGgkvrK4t6H97mOR = open(i9GKPyIEQjSC6tpgo,bb1fgjsAq4N2xYwnoh39lm(u"ࠩࡵࡦႍࠬ")).read()
	ooJmTWvjkAOHMN6EQSa23b4wiY8 = BV9K0HISqUzm4G2WhAnOblM.decompress(xeFjaWpC5qLGgkvrK4t6H97mOR)
	if xwIUQfiE7rmvYzH(u"ࠪࡠࡳࡢ࡮࠾࠿ࡀࡁࡡࡴ࡜࡯ࠩႎ") not in ooJmTWvjkAOHMN6EQSa23b4wiY8: JEiFBCayPfze7n3KspN6AY = eval(ooJmTWvjkAOHMN6EQSa23b4wiY8)
	else:
		eRdgEJSMHzlDfXZOxuoq = ooJmTWvjkAOHMN6EQSa23b4wiY8.split(VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࡢ࡮࡝ࡰࠪႏ"))
		del ooJmTWvjkAOHMN6EQSa23b4wiY8
		JEiFBCayPfze7n3KspN6AY = []
		TIcyb7QFjNGMz0aYZkE8LCOhi = vD0q4oHLey6RaSCFNzr()
		aUJr1yX8602OvfEm9dWjkZH = IpFcwrWNgefMym3qta0hYQAzOdE
		for eIsjxbpgoGTf in eRdgEJSMHzlDfXZOxuoq:
			TIcyb7QFjNGMz0aYZkE8LCOhi.vz6gluNMCZ3ncR4AXfY1jVrwpHt(str(aUJr1yX8602OvfEm9dWjkZH),eval,eIsjxbpgoGTf)
			aUJr1yX8602OvfEm9dWjkZH += UnOIK1WBbw2
		del eRdgEJSMHzlDfXZOxuoq
		TIcyb7QFjNGMz0aYZkE8LCOhi.ccyNK7q6w3i0PrnV1pXkIJWf()
		TIcyb7QFjNGMz0aYZkE8LCOhi.bOyEZCcUg12eMtYum()
		FZhuJ12t4RHExcdPm76ajBqkgX = list(TIcyb7QFjNGMz0aYZkE8LCOhi.resultsDICT.keys())
		qq7AZilmtK = sorted(FZhuJ12t4RHExcdPm76ajBqkgX,reverse=FFKncZx5pDTwdiJRYhMgQSNL,key=lambda key: int(key))
		for aUJr1yX8602OvfEm9dWjkZH in qq7AZilmtK:
			JEiFBCayPfze7n3KspN6AY += TIcyb7QFjNGMz0aYZkE8LCOhi.resultsDICT[aUJr1yX8602OvfEm9dWjkZH]
	return JEiFBCayPfze7n3KspN6AY
def BBz7lCMmxV2E3(jmPwATvkoixS92pOuas):
	nV9jWiNmtyfv1Yu5lO0G = XoZRpFe7B6gnfA.path.join(kkjOSvrlpDJNcqVIwUBt3,HD7MQqXd2gS(u"ࠬࡧࡤࡥࡱࡱࡷࠬ႐"),jmPwATvkoixS92pOuas,yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠭ࡡࡥࡦࡲࡲ࠳ࡾ࡭࡭ࠩ႑"))
	try: yc5dejfhb7Ykz2P3ENnVRpL8osw = open(nV9jWiNmtyfv1Yu5lO0G,gmPI7hVEM8nD(u"ࠧࡳࡤࠪ႒")).read()
	except:
		CugHo1Y0jzDrT2XwNQnI3Sm = XoZRpFe7B6gnfA.path.join(GAu38kbFlWcSQO,gmPI7hVEM8nD(u"ࠨࡣࡧࡨࡴࡴࡳࠨ႓"),jmPwATvkoixS92pOuas,Yj1msqVeivESfrCupRy9b7WacBd(u"ࠩࡤࡨࡩࡵ࡮࠯ࡺࡰࡰࠬ႔"))
		try: yc5dejfhb7Ykz2P3ENnVRpL8osw = open(CugHo1Y0jzDrT2XwNQnI3Sm,AJHaiQq3PRd5cphzGuELnVg9X(u"ࠪࡶࡧ࠭႕")).read()
		except: return nA5dhMRg6ENzsB0l1GwvH7aIr2,[]
	if BsLJ7p5Av2Vm0SQeCO1o: yc5dejfhb7Ykz2P3ENnVRpL8osw = yc5dejfhb7Ykz2P3ENnVRpL8osw.decode(YWEQ3Cf8RevpD0m7NjF1)
	kOrjtfDemERMnHBW7q5Kd8yC = PAztbuyYo4Kvd.findall(rCmGE4YIDaZA(u"ࠫ࡮ࡪ࠽࠯ࠬࡂࡺࡪࡸࡳࡪࡱࡱࡁࡠࡢࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝࡟ࠦࡡ࠭࡝ࠨ႖"),yc5dejfhb7Ykz2P3ENnVRpL8osw,PAztbuyYo4Kvd.DOTALL|PAztbuyYo4Kvd.IGNORECASE)
	if not kOrjtfDemERMnHBW7q5Kd8yC: return nA5dhMRg6ENzsB0l1GwvH7aIr2,[]
	aj8om6EQA7LYWbgx9NVSCn,Jbu5KXL0W9sZGzMOeTvUoBy1f = kOrjtfDemERMnHBW7q5Kd8yC[IpFcwrWNgefMym3qta0hYQAzOdE],u7CoUO12mcNP4RSfQ(kOrjtfDemERMnHBW7q5Kd8yC[IpFcwrWNgefMym3qta0hYQAzOdE])
	return aj8om6EQA7LYWbgx9NVSCn,Jbu5KXL0W9sZGzMOeTvUoBy1f
def SvsRiXawpqUo51fd():
	AotYjlsCGrVT2Kmp7SaN1u = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,XEcWOIwkZKubV7vQ(u"ࠬࡪࡩࡤࡶࠪ႗"),UUobzy0xZLaVScIt7(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࡡ࠴ࠫ႘"),PPxYugzLZwHX23yiK(u"ࠧࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌࠨ႙"))
	if AotYjlsCGrVT2Kmp7SaN1u: return AotYjlsCGrVT2Kmp7SaN1u
	pXzR8bC5mFJL1,AotYjlsCGrVT2Kmp7SaN1u = {},{}
	hMoa1XBSgH = [Nzp9Fq5cTr.SITESURLS[DFx6E0uON7Jm8(u"ࠨࡔࡈࡔࡔ࡙ࠧႚ")][IpFcwrWNgefMym3qta0hYQAzOdE]]
	if l2JAnWsaDGz8CIEZY>JvQd6LMoBX4hiy1C(u"࠴࠻࠳࠿࠹ᐕ"): hMoa1XBSgH.append(Nzp9Fq5cTr.SITESURLS[xwIUQfiE7rmvYzH(u"ࠩࡕࡉࡕࡕࡓࠨႛ")][UnOIK1WBbw2])
	if BsLJ7p5Av2Vm0SQeCO1o: hMoa1XBSgH.append(Nzp9Fq5cTr.SITESURLS[UUobzy0xZLaVScIt7(u"ࠪࡖࡊࡖࡏࡔࠩႜ")][udq5tP0hwifHQCGYELDbOUI])
	for LZFbTmX0sKd387awr in hMoa1XBSgH:
		tkSbvVxf8h1d0gLTci = uANakQHcnhR(yy6RomT9bQhJf,FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠫࡌࡋࡔࠨႝ"),LZFbTmX0sKd387awr,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡆࡃࡇࡣࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐ࠲࠷ࡳࡵࠩ႞"))
		if tkSbvVxf8h1d0gLTci.succeeded:
			h1hN5GRPeA2YIgmvKax3EMJfu9ilZ = tkSbvVxf8h1d0gLTci.content
			SRQB3d748EPDo = LZFbTmX0sKd387awr.rsplit(AJHaiQq3PRd5cphzGuELnVg9X(u"࠭࠯ࠨ႟"),xwIUQfiE7rmvYzH(u"࠵ᐖ"))[IpFcwrWNgefMym3qta0hYQAzOdE]
			EmaspXMyktNiz = PAztbuyYo4Kvd.findall(baBcNd81eH5ry2Olp6Mj43(u"ࠧࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡶࡦࡴࡶ࡭ࡴࡴ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨႠ"),h1hN5GRPeA2YIgmvKax3EMJfu9ilZ,PAztbuyYo4Kvd.DOTALL|PAztbuyYo4Kvd.IGNORECASE)
			for jmPwATvkoixS92pOuas,rOgKdXelBE8hkHC149 in EmaspXMyktNiz:
				b1rclf7TjeZNv6pEahtonq3dRLOVw = SRQB3d748EPDo+mRanX1HZupfSQVB2gsDGUO(u"ࠨ࠱ࠪႡ")+jmPwATvkoixS92pOuas+yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠩ࠲ࠫႢ")+jmPwATvkoixS92pOuas+nfNTgkiWdUq(u"ࠪ࠱ࠬႣ")+rOgKdXelBE8hkHC149+YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠫ࠳ࢀࡩࡱࠩႤ")
				if jmPwATvkoixS92pOuas not in list(pXzR8bC5mFJL1.keys()):
					pXzR8bC5mFJL1[jmPwATvkoixS92pOuas] = []
					AotYjlsCGrVT2Kmp7SaN1u[jmPwATvkoixS92pOuas] = []
				ypzQYTKGXmBU = u7CoUO12mcNP4RSfQ(rOgKdXelBE8hkHC149)
				pXzR8bC5mFJL1[jmPwATvkoixS92pOuas].append((rOgKdXelBE8hkHC149,ypzQYTKGXmBU,b1rclf7TjeZNv6pEahtonq3dRLOVw))
	for jmPwATvkoixS92pOuas in list(pXzR8bC5mFJL1.keys()):
		AotYjlsCGrVT2Kmp7SaN1u[jmPwATvkoixS92pOuas] = sorted(pXzR8bC5mFJL1[jmPwATvkoixS92pOuas],reverse=S5MWhgtZ37Xw,key=lambda key: key[UnOIK1WBbw2])
	WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࡠ࠳ࠪႥ"),zhE5I4xHinX0UoVZMNwlkPrR(u"࠭ࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒࠧႦ"),AotYjlsCGrVT2Kmp7SaN1u,QdwW2s0iEp56qMmvCbOeLxBRU)
	return AotYjlsCGrVT2Kmp7SaN1u
def u7CoUO12mcNP4RSfQ(rOgKdXelBE8hkHC149):
	ypzQYTKGXmBU = []
	eePXCMOVBN0SJ1hb = rOgKdXelBE8hkHC149.split(Yj1msqVeivESfrCupRy9b7WacBd(u"ࠧ࠯ࠩႧ"))
	for gbix8W9vyoDLZQUtqu2w36X in eePXCMOVBN0SJ1hb:
		Gun4sgy3Hxjp7Viw = PAztbuyYo4Kvd.findall(VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠨ࡞ࡧ࠯ࢁࡡ࡜ࠬ࡞࠰ࡥ࠲ࢀࡁ࠮࡜ࡠ࠯ࠬႨ"),gbix8W9vyoDLZQUtqu2w36X,PAztbuyYo4Kvd.DOTALL)
		kaX7315BPMRtmpWd = []
		for lB7qZmE0j9C8FVLG4zHahYQ5 in Gun4sgy3Hxjp7Viw:
			if lB7qZmE0j9C8FVLG4zHahYQ5.isdigit(): lB7qZmE0j9C8FVLG4zHahYQ5 = int(lB7qZmE0j9C8FVLG4zHahYQ5)
			kaX7315BPMRtmpWd.append(lB7qZmE0j9C8FVLG4zHahYQ5)
		ypzQYTKGXmBU.append(kaX7315BPMRtmpWd)
	return ypzQYTKGXmBU
def kk0uJNo7dZDMpmyFbVTclHsC(ypzQYTKGXmBU):
	rOgKdXelBE8hkHC149 = nA5dhMRg6ENzsB0l1GwvH7aIr2
	for gbix8W9vyoDLZQUtqu2w36X in ypzQYTKGXmBU:
		for lB7qZmE0j9C8FVLG4zHahYQ5 in gbix8W9vyoDLZQUtqu2w36X: rOgKdXelBE8hkHC149 += str(lB7qZmE0j9C8FVLG4zHahYQ5)
		rOgKdXelBE8hkHC149 += pxt6wJ8ScYMWCivoO(u"ࠩ࠱ࠫႩ")
	rOgKdXelBE8hkHC149 = rOgKdXelBE8hkHC149.strip(JvQd6LMoBX4hiy1C(u"ࠪ࠲ࠬႪ"))
	return rOgKdXelBE8hkHC149
def gOHnJkmlPAGjiqN(R5Ru96VUB2cXWTMGPOnLef3KNkS):
	KxieNnJUoIR9uj = {}
	pXzR8bC5mFJL1 = SvsRiXawpqUo51fd()
	xK4gcQE0hu8TArX37sBPW5mpMFqyR1 = UDTcAkV9d4sqbgwh(R5Ru96VUB2cXWTMGPOnLef3KNkS)
	for jmPwATvkoixS92pOuas in R5Ru96VUB2cXWTMGPOnLef3KNkS:
		if jmPwATvkoixS92pOuas not in list(pXzR8bC5mFJL1.keys()): continue
		AotYjlsCGrVT2Kmp7SaN1u = pXzR8bC5mFJL1[jmPwATvkoixS92pOuas]
		oXAWxOcB62YG8Dya5H7wqPhK1fkR,lRiromYq6Kh7EC5wtsk,mSiLWanTBc3tqfypPv7k6RHV2QFoj = AotYjlsCGrVT2Kmp7SaN1u[IpFcwrWNgefMym3qta0hYQAzOdE]
		iSUYvwkn67LMq54zWO,LqWTcx69EMZ0orBkRGmg = BBz7lCMmxV2E3(jmPwATvkoixS92pOuas)
		xFTwHdVkMo9bGv8ilWhR2BePn,v7ZNstILn8yXxb2MUGiTBrCkFP6D = xK4gcQE0hu8TArX37sBPW5mpMFqyR1[jmPwATvkoixS92pOuas]
		w3sfCidrJEvNF = lRiromYq6Kh7EC5wtsk>LqWTcx69EMZ0orBkRGmg and xFTwHdVkMo9bGv8ilWhR2BePn
		ozirPWaNn5j9lUwbtOxEJIv0uT = S5MWhgtZ37Xw
		if not xFTwHdVkMo9bGv8ilWhR2BePn: Omxr4lqHLBFfEPpWjnRbM7Q = XEcWOIwkZKubV7vQ(u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬႫ")
		elif not v7ZNstILn8yXxb2MUGiTBrCkFP6D: Omxr4lqHLBFfEPpWjnRbM7Q = XEcWOIwkZKubV7vQ(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧႬ")
		elif w3sfCidrJEvNF: Omxr4lqHLBFfEPpWjnRbM7Q = PPxYugzLZwHX23yiK(u"࠭࡯࡭ࡦࠪႭ")
		else:
			Omxr4lqHLBFfEPpWjnRbM7Q = vzqjsVHSBlMpxC(u"ࠧࡨࡱࡲࡨࠬႮ")
			ozirPWaNn5j9lUwbtOxEJIv0uT = FFKncZx5pDTwdiJRYhMgQSNL
		KxieNnJUoIR9uj[jmPwATvkoixS92pOuas] = ozirPWaNn5j9lUwbtOxEJIv0uT,iSUYvwkn67LMq54zWO,LqWTcx69EMZ0orBkRGmg,oXAWxOcB62YG8Dya5H7wqPhK1fkR,lRiromYq6Kh7EC5wtsk,Omxr4lqHLBFfEPpWjnRbM7Q,mSiLWanTBc3tqfypPv7k6RHV2QFoj
	return KxieNnJUoIR9uj
def buQ2eMwxvTinjNrLVpUm6IH8fq(p3BeaGrkduEo7zF,tT9OdQ3kPM8oB7XC1ZSj0,W82WoYjAP1yJfFMGm4EpSudVbq=nA5dhMRg6ENzsB0l1GwvH7aIr2,cjz0tFbeTumWOd2PoDHJi=nA5dhMRg6ENzsB0l1GwvH7aIr2,WhFurnAYvyec=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if cS2NYw4xulqJgvzkMF: p3BeaGrkduEo7zF.update(tT9OdQ3kPM8oB7XC1ZSj0,W82WoYjAP1yJfFMGm4EpSudVbq,cjz0tFbeTumWOd2PoDHJi,WhFurnAYvyec)
	else: p3BeaGrkduEo7zF.update(tT9OdQ3kPM8oB7XC1ZSj0,W82WoYjAP1yJfFMGm4EpSudVbq+CXtugbqhV3+cjz0tFbeTumWOd2PoDHJi+CXtugbqhV3+WhFurnAYvyec)
	return
def MQjY7XqoPUHtrcKyxDlA6(pC29B56a7JfUWE3HSwkOLr8):
	def mvPrFDdRwhJYHBUC(uuljKBtveMkh6D41EyRPbmoGrSsJ2,uu4aPIg6AE,bbrsBMOiEvmKLuIwPG84eYgJ56=Yj1msqVeivESfrCupRy9b7WacBd(u"ࠣ࠲࠴࠶࠸࠺࠵࠷࠹࠻࠽ࡦࡨࡣࡥࡧࡩ࡫࡭࡯ࡪ࡬࡮ࡰࡲࡴࡶࡱࡳࡵࡷࡹࡻࡽࡸࡺࡼࡄࡆࡈࡊࡅࡇࡉࡋࡍࡏࡑࡌࡎࡐࡒࡔࡖࡘࡓࡕࡗ࡙࡛࡝࡟࡚ࠣႯ")):
		return ((uuljKBtveMkh6D41EyRPbmoGrSsJ2 == IpFcwrWNgefMym3qta0hYQAzOdE) and bbrsBMOiEvmKLuIwPG84eYgJ56[IpFcwrWNgefMym3qta0hYQAzOdE]) or (mvPrFDdRwhJYHBUC(uuljKBtveMkh6D41EyRPbmoGrSsJ2 // uu4aPIg6AE, uu4aPIg6AE, bbrsBMOiEvmKLuIwPG84eYgJ56).lstrip(bbrsBMOiEvmKLuIwPG84eYgJ56[IpFcwrWNgefMym3qta0hYQAzOdE]) + bbrsBMOiEvmKLuIwPG84eYgJ56[uuljKBtveMkh6D41EyRPbmoGrSsJ2 % uu4aPIg6AE])
	def G037LcyQ54WbDE(LLuSER9morxvO23gdliBw41kbGpqD, GLpoAINt4k, DUs7RxlEHn, jjK64StIxmH2phPbGUMAz7, BSkCGXZKmJl2rty5EWODbu6A1=YWylfpKSRb, kbV1wKRiDL96r87MmIcPB=YWylfpKSRb, STydR2Gh0MxmeDXoZAUfvr85V=YWylfpKSRb):
		while (DUs7RxlEHn):
			DUs7RxlEHn-=rCmGE4YIDaZA(u"࠶ᐗ")
			if (jjK64StIxmH2phPbGUMAz7[DUs7RxlEHn]): LLuSER9morxvO23gdliBw41kbGpqD = PAztbuyYo4Kvd.sub(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠤ࡟ࡠࡧࠨႰ") + mvPrFDdRwhJYHBUC(DUs7RxlEHn, GLpoAINt4k) + gmPI7hVEM8nD(u"ࠥࡠࡡࡨࠢႱ"),  jjK64StIxmH2phPbGUMAz7[DUs7RxlEHn], LLuSER9morxvO23gdliBw41kbGpqD)
		return LLuSER9morxvO23gdliBw41kbGpqD
	pC29B56a7JfUWE3HSwkOLr8 = pC29B56a7JfUWE3HSwkOLr8.split(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠫࢂ࠮ࠧႲ"))[UnOIK1WBbw2]
	pC29B56a7JfUWE3HSwkOLr8 = pC29B56a7JfUWE3HSwkOLr8.rsplit(HD7MQqXd2gS(u"ࠬࡹࡰ࡭࡫ࡷࠫႳ"))[IpFcwrWNgefMym3qta0hYQAzOdE]+rCmGE4YIDaZA(u"ࠨࡳࡱ࡮࡬ࡸ࠭࠭ࡼࠨࠫࠬࠦႴ")
	HHtGE4K1m8pSid = eval(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠧࡶࡰࡳࡥࡨࡱࠨࠨႵ")+pC29B56a7JfUWE3HSwkOLr8,{VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠨࡤࡤࡷࡪࡔࠧႶ"):mvPrFDdRwhJYHBUC,bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠩࡸࡲࡵࡧࡣ࡬ࠩႷ"):G037LcyQ54WbDE})
	return HHtGE4K1m8pSid
def q6qYNih7gOB(code):
	_MwrB3sN145yLpARgadY=DFx6E0uON7Jm8(u"ࠥ࠴࠶࠸࠳࠵࠷࠹࠻࠽࠿ࡡࡣࡥࡧࡩ࡫࡭ࡨࡪ࡬࡮ࡰࡲࡴ࡯ࡱࡳࡵࡷࡹࡻࡶࡸࡺࡼࡾࡆࡈࡃࡅࡇࡉࡋࡍࡏࡊࡌࡎࡐࡒࡔࡖࡑࡓࡕࡗ࡙࡛࡝ࡘ࡚࡜࠮࠳ࠧႸ")
	def ldD6nc4gy2E81qLzkUA3M5WNpbX9(kbV1wKRiDL96r87MmIcPB,BSkCGXZKmJl2rty5EWODbu6A1,ggceBwFNyEx9XJbI):
		KSlpcQfJ6Pk = list(_MwrB3sN145yLpARgadY)
		sErXzRTiV0vM4Cdj5H = KSlpcQfJ6Pk[rCmGE4YIDaZA(u"࠶ᐘ"):BSkCGXZKmJl2rty5EWODbu6A1]
		q3kZpRe28O0s1NaCXQ9SMuGKin = KSlpcQfJ6Pk[JvQd6LMoBX4hiy1C(u"࠰ᐙ"):ggceBwFNyEx9XJbI]
		kbV1wKRiDL96r87MmIcPB = list(kbV1wKRiDL96r87MmIcPB)[::-jil8vRpBsENVYyPmDd(u"࠲ᐚ")]
		daRDcunZIqGyCpPgJ48WlHFB = bb1fgjsAq4N2xYwnoh39lm(u"࠲ᐛ")
		for DUs7RxlEHn,uu4aPIg6AE in enumerate(kbV1wKRiDL96r87MmIcPB):
			if uu4aPIg6AE in sErXzRTiV0vM4Cdj5H: daRDcunZIqGyCpPgJ48WlHFB = daRDcunZIqGyCpPgJ48WlHFB + sErXzRTiV0vM4Cdj5H.index(uu4aPIg6AE)*BSkCGXZKmJl2rty5EWODbu6A1**DUs7RxlEHn
		jjK64StIxmH2phPbGUMAz7 = xwIUQfiE7rmvYzH(u"ࠦࠧႹ")
		while daRDcunZIqGyCpPgJ48WlHFB > LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠳ᐜ"):
			jjK64StIxmH2phPbGUMAz7 = q3kZpRe28O0s1NaCXQ9SMuGKin[daRDcunZIqGyCpPgJ48WlHFB%ggceBwFNyEx9XJbI] + jjK64StIxmH2phPbGUMAz7
			daRDcunZIqGyCpPgJ48WlHFB = (daRDcunZIqGyCpPgJ48WlHFB - (daRDcunZIqGyCpPgJ48WlHFB%ggceBwFNyEx9XJbI))//ggceBwFNyEx9XJbI
		return int(jjK64StIxmH2phPbGUMAz7) or bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠴ᐝ")
	def mufXdP97IY4clthNsEKHSe2WiDvC(sErXzRTiV0vM4Cdj5H,u,ipmeLn4NDUCWgw,v2jaL1CxbqJGEFlhZ,BSkCGXZKmJl2rty5EWODbu6A1,STydR2Gh0MxmeDXoZAUfvr85V):
		STydR2Gh0MxmeDXoZAUfvr85V = DFx6E0uON7Jm8(u"ࠧࠨႺ");
		q3kZpRe28O0s1NaCXQ9SMuGKin = PPxYugzLZwHX23yiK(u"࠵ᐞ")
		while q3kZpRe28O0s1NaCXQ9SMuGKin < len(sErXzRTiV0vM4Cdj5H):
			daRDcunZIqGyCpPgJ48WlHFB = DFx6E0uON7Jm8(u"࠶ᐟ")
			NPnuLZx13ysk9Wol2DOU5C4d = mRanX1HZupfSQVB2gsDGUO(u"ࠨࠢႻ")
			while sErXzRTiV0vM4Cdj5H[q3kZpRe28O0s1NaCXQ9SMuGKin] is not ipmeLn4NDUCWgw[BSkCGXZKmJl2rty5EWODbu6A1]:
				NPnuLZx13ysk9Wol2DOU5C4d = nA5dhMRg6ENzsB0l1GwvH7aIr2.join([NPnuLZx13ysk9Wol2DOU5C4d,sErXzRTiV0vM4Cdj5H[q3kZpRe28O0s1NaCXQ9SMuGKin]])
				q3kZpRe28O0s1NaCXQ9SMuGKin = q3kZpRe28O0s1NaCXQ9SMuGKin + PPxYugzLZwHX23yiK(u"࠱ᐠ")
			while daRDcunZIqGyCpPgJ48WlHFB < len(ipmeLn4NDUCWgw):
				NPnuLZx13ysk9Wol2DOU5C4d = NPnuLZx13ysk9Wol2DOU5C4d.replace(ipmeLn4NDUCWgw[daRDcunZIqGyCpPgJ48WlHFB],str(daRDcunZIqGyCpPgJ48WlHFB))
				daRDcunZIqGyCpPgJ48WlHFB = daRDcunZIqGyCpPgJ48WlHFB + baBcNd81eH5ry2Olp6Mj43(u"࠲ᐡ")
			STydR2Gh0MxmeDXoZAUfvr85V = nA5dhMRg6ENzsB0l1GwvH7aIr2.join([STydR2Gh0MxmeDXoZAUfvr85V,nA5dhMRg6ENzsB0l1GwvH7aIr2.join(map(chr, [ldD6nc4gy2E81qLzkUA3M5WNpbX9(NPnuLZx13ysk9Wol2DOU5C4d,BSkCGXZKmJl2rty5EWODbu6A1,n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠳࠳ᐢ")) - v2jaL1CxbqJGEFlhZ]))])
			q3kZpRe28O0s1NaCXQ9SMuGKin = q3kZpRe28O0s1NaCXQ9SMuGKin + pxt6wJ8ScYMWCivoO(u"࠴ᐣ")
		return STydR2Gh0MxmeDXoZAUfvr85V
	code = code.replace(nfNTgkiWdUq(u"ࠧ࡝ࡰࠪႼ"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(nfNTgkiWdUq(u"ࠨ࡞ࡵࠫႽ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	tjDniRLEUa9 = PAztbuyYo4Kvd.findall(bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠩ࡟ࢁࡡ࠮ࠢࠩ࡞ࡺ࠯࠮ࠨࠬࠩ࡞ࡧ࠯࠮࠲ࠢࠩ࡞ࡺ࠯࠮ࠨࠬࠩ࡞ࡧ࠯࠮࠲ࠨ࡝ࡦ࠮࠭࠱࠮࡜ࡥ࠭ࠬࡠ࠮ࡢࠩࠨႾ"),code,PAztbuyYo4Kvd.DOTALL)
	if tjDniRLEUa9:
		tjDniRLEUa9 = list(tjDniRLEUa9[vzqjsVHSBlMpxC(u"࠴ᐤ")])
		for EbqsKowvUnQmaAR27JcZpuyYGtHkTf,code in enumerate(tjDniRLEUa9):
			if code.isdigit(): tjDniRLEUa9[EbqsKowvUnQmaAR27JcZpuyYGtHkTf] = int(code)
			else: tjDniRLEUa9[EbqsKowvUnQmaAR27JcZpuyYGtHkTf] = code.replace(bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠪࡠࠧ࠭Ⴟ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
		or9v7NSf4py2tVmHi0sFBQc6IqKMOY = mufXdP97IY4clthNsEKHSe2WiDvC(*tjDniRLEUa9)
		return or9v7NSf4py2tVmHi0sFBQc6IqKMOY
	return nA5dhMRg6ENzsB0l1GwvH7aIr2
def Almp7rktWj1ZQKgI25(RxWJFBAGy4iIM,dbJHcFj1xm=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if dbJHcFj1xm==rCmGE4YIDaZA(u"ࠫࡱࡵࡷࡦࡴࠪჀ"): RxWJFBAGy4iIM = PAztbuyYo4Kvd.sub(xwIUQfiE7rmvYzH(u"ࡷ࠭ࠥ࡜࠲࠰࠽ࡆ࠳࡚࡞ࡽ࠵ࢁࠬჁ"),lambda mmabx9vzOVAQk40iCPgNydF: mmabx9vzOVAQk40iCPgNydF.group(IpFcwrWNgefMym3qta0hYQAzOdE).lower(),RxWJFBAGy4iIM)
	elif dbJHcFj1xm==JvQd6LMoBX4hiy1C(u"࠭ࡵࡱࡲࡨࡶࠬჂ"): RxWJFBAGy4iIM = PAztbuyYo4Kvd.sub(PPxYugzLZwHX23yiK(u"ࡲࠨࠧ࡞࠴࠲࠿ࡡ࠮ࡼࡠࡿ࠷ࢃࠧჃ"),lambda mmabx9vzOVAQk40iCPgNydF: mmabx9vzOVAQk40iCPgNydF.group(IpFcwrWNgefMym3qta0hYQAzOdE).upper(),RxWJFBAGy4iIM)
	return RxWJFBAGy4iIM
def UDTcAkV9d4sqbgwh(R5Ru96VUB2cXWTMGPOnLef3KNkS):
	J9IczDe7oFdvybtQPnZk6NVjEHix3,uVTtQ2nhI6rXCb0 = FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL
	Ccemh2nAvQ = NpEaoJdsihbVYkrfHOuMeycA.connect(NS8ELxPk4JMTa2gzrHjnoh)
	Ccemh2nAvQ.text_factory = str
	ADJdGOPzaeo0rXf2SuKQbcFWqilw = Ccemh2nAvQ.cursor()
	if len(R5Ru96VUB2cXWTMGPOnLef3KNkS)==UnOIK1WBbw2: iXUkvoWT7tMKaEn = ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠨࠪࠥࠫჄ")+R5Ru96VUB2cXWTMGPOnLef3KNkS[IpFcwrWNgefMym3qta0hYQAzOdE]+YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠩࠥ࠭ࠬჅ")
	else: iXUkvoWT7tMKaEn = str(tuple(R5Ru96VUB2cXWTMGPOnLef3KNkS))
	ADJdGOPzaeo0rXf2SuKQbcFWqilw.execute(Yj1msqVeivESfrCupRy9b7WacBd(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡥࡩࡪ࡯࡯ࡋࡇ࠰ࡪࡴࡡࡣ࡮ࡨࡨࠥࡌࡒࡐࡏࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦࡉࡏࠢࠪ჆")+iXUkvoWT7tMKaEn+JvQd6LMoBX4hiy1C(u"ࠫࠥࡁࠧჇ"))
	pxoW2F57mI6JXcqrfhUgnYwCZQ = ADJdGOPzaeo0rXf2SuKQbcFWqilw.fetchall()
	Ccemh2nAvQ.close()
	xK4gcQE0hu8TArX37sBPW5mpMFqyR1 = {}
	for jmPwATvkoixS92pOuas in R5Ru96VUB2cXWTMGPOnLef3KNkS: xK4gcQE0hu8TArX37sBPW5mpMFqyR1[jmPwATvkoixS92pOuas] = (FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL)
	for jmPwATvkoixS92pOuas,uVTtQ2nhI6rXCb0 in pxoW2F57mI6JXcqrfhUgnYwCZQ:
		J9IczDe7oFdvybtQPnZk6NVjEHix3 = S5MWhgtZ37Xw
		uVTtQ2nhI6rXCb0 = uVTtQ2nhI6rXCb0==UnOIK1WBbw2
		xK4gcQE0hu8TArX37sBPW5mpMFqyR1[jmPwATvkoixS92pOuas] = (J9IczDe7oFdvybtQPnZk6NVjEHix3,uVTtQ2nhI6rXCb0)
	return xK4gcQE0hu8TArX37sBPW5mpMFqyR1
def x1ibKhuTya7w3I589OcoEBAN(hhZ6lIumVNX):
	V9OGBuyogH0CaUtQS6wWErAbPYDjlM = nA5dhMRg6ENzsB0l1GwvH7aIr2
	if XoZRpFe7B6gnfA.path.exists(hhZ6lIumVNX):
		tFE1s8OzUMHLnWj4pgxvu90CYqoSm = open(hhZ6lIumVNX,yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠬࡸࡢࠨ჈")).read()
		if BsLJ7p5Av2Vm0SQeCO1o: tFE1s8OzUMHLnWj4pgxvu90CYqoSm = tFE1s8OzUMHLnWj4pgxvu90CYqoSm.decode(YWEQ3Cf8RevpD0m7NjF1)
		ffzXP8bjnC6AUO7DcegQ9 = BwGPDSQOlfUas2n3eIH0ycFRWZ(vzqjsVHSBlMpxC(u"࠭ࡤࡪࡥࡷࠫ჉"),tFE1s8OzUMHLnWj4pgxvu90CYqoSm)
		if ffzXP8bjnC6AUO7DcegQ9:
			V9OGBuyogH0CaUtQS6wWErAbPYDjlM = {}
			for XXqnevZw5VPsyczgmkdK10laD68hj in ffzXP8bjnC6AUO7DcegQ9.keys():
				V9OGBuyogH0CaUtQS6wWErAbPYDjlM[XXqnevZw5VPsyczgmkdK10laD68hj] = []
				for KDadtGcLMS in ffzXP8bjnC6AUO7DcegQ9[XXqnevZw5VPsyczgmkdK10laD68hj]:
					zzU5PnmRv13toWs4bDFL,B7n3L9yPx54v,RxWJFBAGy4iIM,No03nbgziMqjZ,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4 = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
					zzU5PnmRv13toWs4bDFL = KDadtGcLMS[IpFcwrWNgefMym3qta0hYQAzOdE]
					B7n3L9yPx54v = KDadtGcLMS[UnOIK1WBbw2]
					B7n3L9yPx54v = CRV3tDJ6gNczqXF7Z8jnvH1kh(B7n3L9yPx54v)
					RxWJFBAGy4iIM = KDadtGcLMS[udq5tP0hwifHQCGYELDbOUI]
					No03nbgziMqjZ = KDadtGcLMS[AH0zdvBqibaXY]
					io76Hju84PtJO3hE5x9KZnpGmalIw = KDadtGcLMS[tpMX1Bgs0bzv8OEafyW]
					Q0f7ytucSriRw8HTzd = KDadtGcLMS[AJHaiQq3PRd5cphzGuELnVg9X(u"࠺ᐥ")]
					if len(KDadtGcLMS)>lw2snZ9J0uhLoxypqa(u"࠼ᐦ"): ooJmTWvjkAOHMN6EQSa23b4wiY8 = KDadtGcLMS[lw2snZ9J0uhLoxypqa(u"࠼ᐦ")]
					if len(KDadtGcLMS)>vzqjsVHSBlMpxC(u"࠷ᐧ"): kSqp7Ua0gATvrXG2RFdzN = KDadtGcLMS[vzqjsVHSBlMpxC(u"࠷ᐧ")]
					if len(KDadtGcLMS)>FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠹ᐨ"): Xxcm31HuozfbJEAv8Rl7PwUgGBF4 = KDadtGcLMS[FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠹ᐨ")]
					if hhZ6lIumVNX==RihlJwXFNfe1IGPu9ZcUg85qsdn: tQc5fB3zWpJMYEqb24ZayxSmgTe = zzU5PnmRv13toWs4bDFL,B7n3L9yPx54v,RxWJFBAGy4iIM,No03nbgziMqjZ,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8,nA5dhMRg6ENzsB0l1GwvH7aIr2,Xxcm31HuozfbJEAv8Rl7PwUgGBF4
					else: tQc5fB3zWpJMYEqb24ZayxSmgTe = zzU5PnmRv13toWs4bDFL,B7n3L9yPx54v,RxWJFBAGy4iIM,No03nbgziMqjZ,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,ooJmTWvjkAOHMN6EQSa23b4wiY8,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4
					V9OGBuyogH0CaUtQS6wWErAbPYDjlM[XXqnevZw5VPsyczgmkdK10laD68hj].append(tQc5fB3zWpJMYEqb24ZayxSmgTe)
		dovTcp20WhEXnaVBJrmqYl6UGif = str(V9OGBuyogH0CaUtQS6wWErAbPYDjlM)
		if BsLJ7p5Av2Vm0SQeCO1o: dovTcp20WhEXnaVBJrmqYl6UGif = dovTcp20WhEXnaVBJrmqYl6UGif.encode(YWEQ3Cf8RevpD0m7NjF1)
		open(hhZ6lIumVNX,DFx6E0uON7Jm8(u"ࠧࡸࡤࠪ჊")).write(dovTcp20WhEXnaVBJrmqYl6UGif)
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def EN1Pg52zbjsmLMQq9(whXU4NCbPdFAcxErVJIutR8WDM3n):
	SRv8TPC0ZNOQ = whXU4NCbPdFAcxErVJIutR8WDM3n.split(lw2snZ9J0uhLoxypqa(u"ࠨ࠯ࠪ჋"),UnOIK1WBbw2)[IpFcwrWNgefMym3qta0hYQAzOdE]
	hT9D8fRSNgycG36k,vlm7dBDy2RXPj1C8,CYv7ydT6WAGtu0o = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	if   SRv8TPC0ZNOQ==baBcNd81eH5ry2Olp6Mj43(u"ࠩࡄࡌ࡜ࡇࡋࠨ჌")		:	from rWLl0RNect			import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==DFx6E0uON7Jm8(u"ࠪࡅࡐࡕࡁࡎࠩჍ")		:	from nM8Xug5yjl			import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==rCmGE4YIDaZA(u"ࠫࡆࡑࡏࡂࡏࡆࡅࡒ࠭჎")	:	from dT46xpmJOA		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==xwIUQfiE7rmvYzH(u"ࠬࡇࡋࡘࡃࡐࠫ჏")		:	from zd1NUSb7FV			import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==Pj9YaUq1ibJ(u"࠭ࡁࡌ࡙ࡄࡑ࡙࡛ࡂࡆࠩა")	:	from YwtzvLRVZM		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==bb1fgjsAq4N2xYwnoh39lm(u"ࠧࡂࡎࡄࡖࡆࡈࠧბ")	:	from RxovbNgODm			import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋࠪგ")	:	from EEGA2VM7PC		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==PPxYugzLZwHX23yiK(u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖࠬდ")	: 	from csmdNuXL7q		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬე")	:	from Jf6n8FK40r		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠫࡆࡒࡍࡔࡖࡅࡅࠬვ")	:	from OOM5hYorXR		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==bb1fgjsAq4N2xYwnoh39lm(u"ࠬࡇࡎࡊࡏࡈ࡞ࡎࡊࠧზ")	:	from hhS62AN4sc		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==Qy6wlfLoOpg1(u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫთ"):	from nnOWPTY4u7	import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==Yj1msqVeivESfrCupRy9b7WacBd(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩი")	:	from kPXKMEVLmO		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==jil8vRpBsENVYyPmDd(u"ࠨࡃ࡜ࡐࡔࡒࠧკ")		:	from aSz9PsQUNO			import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==xwIUQfiE7rmvYzH(u"ࠩࡅࡓࡐࡘࡁࠨლ")		:	from vSX3ktWrTy			import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==UUobzy0xZLaVScIt7(u"ࠪࡆࡗ࡙ࡔࡆࡌࠪმ")	:	from dcQwCNFnVx			import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==rCmGE4YIDaZA(u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬნ")	:	from bjJd2XQOls		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠬࡉࡉࡎࡃ࠷ࡔࠬო")	:	from rLpeiHYAg1			import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==baBcNd81eH5ry2Olp6Mj43(u"࠭ࡃࡊࡏࡄ࠸࡚࠭პ")	:	from UFoYRT3b8c			import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩჟ")	:	from N3Lo7hvnXf		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==lw2snZ9J0uhLoxypqa(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪრ")	:	from yjo4I0zXwn		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==Yj1msqVeivESfrCupRy9b7WacBd(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࡛ࡔࡘࡋࠨს"):	from BF9CYfxmHD	import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔࠬტ")	:	from oy5aV7khgQ		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==Yj1msqVeivESfrCupRy9b7WacBd(u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭უ")	:	from AAtpe390qR		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠬࡉࡉࡎࡃࡉࡖࡊࡋࠧფ")	:	from V6FAwmbMiX		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩქ")	:	from r4KE58LjVC		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==rCmGE4YIDaZA(u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨღ")	:	from BUOWAzsN5n		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==mRanX1HZupfSQVB2gsDGUO(u"ࠨࡅࡌࡑࡆ࡝ࡂࡂࡕࠪყ")	:	from hfaA1EbPOL		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧშ"):	from whLXEMapkb	import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==xwIUQfiE7rmvYzH(u"ࠪࡈࡗࡇࡍࡂࡅࡄࡊࡊ࠭ჩ")	:	from Vqm40MpjsJ		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==Qy6wlfLoOpg1(u"ࠫࡉࡘࡁࡎࡃࡖ࠻ࠬც")	:	from RYuDlE1emt		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==xwIUQfiE7rmvYzH(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠭ძ")	:	from pTSbh92Qra		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==JvQd6LMoBX4hiy1C(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨწ")	:	from GvDLytQbNz		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳ࠩჭ")	:	from pgLaDNIf8m		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==xwIUQfiE7rmvYzH(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠵ࠪხ")	:	from IIfVlWZqAN		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫჯ")	:	from s7seSBfgiW		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫჰ")	:	from FFtYygSs4C		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==rCmGE4YIDaZA(u"ࠫࡊࡍ࡙ࡏࡑ࡚ࠫჱ")	:	from iEQFHOvgZq			import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==Yj1msqVeivESfrCupRy9b7WacBd(u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇࠧჲ")	:	from eeBRQN6Xin		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==nfNTgkiWdUq(u"࠭ࡅࡍࡋࡉ࡚ࡎࡊࡅࡐࠩჳ")	:	from TfJER1Nwq9		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==HD7MQqXd2gS(u"ࠧࡇࡃࡅࡖࡆࡑࡁࠨჴ")	:	from qq2RAG5mQT		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==ldIfvn6asURQ9toi85EhqAXW3(u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫჵ")	:	from lJrhM57sR2		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==pxt6wJ8ScYMWCivoO(u"ࠩࡉࡅࡗࡋࡓࡌࡑࠪჶ")	:	from TIxHuR5PA6		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==JvQd6LMoBX4hiy1C(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬჷ")	:	from BuoVzJ2O9t		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==DFx6E0uON7Jm8(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭ჸ")	:	from DSZdIq91VC		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==bb1fgjsAq4N2xYwnoh39lm(u"ࠬࡌࡏࡔࡖࡄࠫჹ")		:	from wZVGy8atc5			import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==rCmGE4YIDaZA(u"࠭ࡆࡖࡐࡒࡒ࡙࡜ࠧჺ")	:	from damH1jtGEw		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠧࡇࡗࡖࡌࡆࡘࡔࡗࠩ჻")	:	from mjgwoe5AY9		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠨࡈࡘࡗࡍࡇࡒࡗࡋࡇࡉࡔ࠭ჼ"):	from ppVSbYsmHZ	import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==baBcNd81eH5ry2Olp6Mj43(u"ࠩࡊࡓࡔࡍࡌࡆࡕࡈࡅࡗࡉࡈࠨჽ"):	from z65zZiX18G	import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==zhE5I4xHinX0UoVZMNwlkPrR(u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬჾ")	:	from f8f4Ct3Gg1		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==zhE5I4xHinX0UoVZMNwlkPrR(u"ࠫࡎࡌࡉࡍࡏࠪჿ")		:	from h8hVDl3HS1			import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==nfNTgkiWdUq(u"ࠬࡏࡐࡕࡘࠪᄀ")		:	from atoGunAmqK			import q89q14REt7fG0KsrdymbHiNCVkax as hT9D8fRSNgycG36k,BZOyPrlKzJmRGD as vlm7dBDy2RXPj1C8,r1r9MU8jSNR2csPJnauFeWzvOGhl5q as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==vzqjsVHSBlMpxC(u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩᄁ")	:	from WfD9dJ4hO0		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==PPxYugzLZwHX23yiK(u"ࠧࡌࡃࡗࡏࡔ࡚ࡔࡗࠩᄂ")	:	from NNX0YcRHsB		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==pxt6wJ8ScYMWCivoO(u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇࠪᄃ")	:	from Obo0piMIzQ		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==jil8vRpBsENVYyPmDd(u"ࠩࡎࡍࡗࡓࡁࡍࡍࠪᄄ")	:	from X2hM5BF6Y7		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠪࡐࡆࡘࡏ࡛ࡃࠪᄅ")	:	from M9eNzGxthm			import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==lw2snZ9J0uhLoxypqa(u"ࠫࡑࡕࡄ࡚ࡐࡈࡘࠬᄆ")	:	from xxVHDpTBMF		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==XEcWOIwkZKubV7vQ(u"ࠬࡓ࠳ࡖࠩᄇ")		:	from Bn18ZLUmyw			import q89q14REt7fG0KsrdymbHiNCVkax as hT9D8fRSNgycG36k,BZOyPrlKzJmRGD as vlm7dBDy2RXPj1C8,r1r9MU8jSNR2csPJnauFeWzvOGhl5q as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠭ࡍࡂࡕࡄ࡚ࡎࡊࡅࡐࠩᄈ")	:	from NvMezGk3DT		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠧࡎࡑ࡙ࡗ࠹࡛ࠧᄉ")	:	from oQtvnypW6j			import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠨࡏ࡜ࡇࡎࡓࡁࠨᄊ")	:	from xx5Zm6kzpv			import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==Yj1msqVeivESfrCupRy9b7WacBd(u"ࠩࡓࡅࡓࡋࡔࠨᄋ")		:	from QwA8XcxeVC			import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠪࡕࡋࡏࡌࡎࠩᄌ")		:	from JDwTsV4OLy			import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠫࡘࡋࡒࡊࡇࡖࡘࡎࡓࡅࠨᄍ"):	from bXP1zMUCvy		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==ldIfvn6asURQ9toi85EhqAXW3(u"࡙ࠬࡈࡂࡄࡄࡏࡆ࡚࡙ࠨᄎ")	:	from i9u6UmvN0t		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==lw2snZ9J0uhLoxypqa(u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨᄏ")	:	from AHFaRPbv5o		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==ldIfvn6asURQ9toi85EhqAXW3(u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠴ࠪᄐ")	:	from LWhrbmFws1		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==Pj9YaUq1ibJ(u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗࠬᄑ"):	from CbBz58GVsw		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉࠬᄒ")	:	from VUdJmIA7Fq		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠪࡗࡍࡕࡆࡉࡃࠪᄓ")	:	from LBMQjO6qxX			import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==jil8vRpBsENVYyPmDd(u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭ᄔ")	:	from KANUMma4Rb		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==pxt6wJ8ScYMWCivoO(u"࡙ࠬࡈࡐࡑࡉࡒࡊ࡚ࠧᄕ")	:	from kJFiNz0IGL		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==pxt6wJ8ScYMWCivoO(u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏࠨᄖ")	:	from svt4HFPmpI		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠧࡕࡋࡎࡅࡆ࡚ࠧᄗ")	:	from K9dIPrMwlR			import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==XEcWOIwkZKubV7vQ(u"ࠨࡖ࡙ࡊ࡚ࡔࠧᄘ")		:	from ttPYy0HmjL			import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==bb1fgjsAq4N2xYwnoh39lm(u"࡙ࠩࡅࡗࡈࡏࡏࠩᄙ")	:	from JpejmuP7gr			import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==PPxYugzLZwHX23yiK(u"࡚ࠪࡎࡊࡅࡐࡐࡖࡅࡊࡓࠧᄚ"):	from rvbIP0MLHK		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠵ࠬᄛ")	:	from cp4ZoSWT3q		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==vzqjsVHSBlMpxC(u"ࠬ࡝ࡅࡄࡋࡐࡅ࠷࠭ᄜ")	:	from j9jQwbJLAM		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==UUobzy0xZLaVScIt7(u"࡙࠭ࡂࡓࡒࡘࠬᄝ")		:	from NNsUMy7niJ			import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==HD7MQqXd2gS(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨᄞ")	:	from yGVNaP54kZ		import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	elif SRv8TPC0ZNOQ==PPxYugzLZwHX23yiK(u"ࠨ࡛ࡗࡆࡤࡉࡈࡂࡐࡑࡉࡑ࡙ࠧᄟ"):	from UUIS0B8xVC	import ErjIn5GfaBzkqycC as hT9D8fRSNgycG36k,WULrxiSjG3d1Cemza7Kc as vlm7dBDy2RXPj1C8,DjKrTPWEFw2YeCi5d6unBqhZSlAR as CYv7ydT6WAGtu0o
	return hT9D8fRSNgycG36k,vlm7dBDy2RXPj1C8,CYv7ydT6WAGtu0o
def Ew2exk7boOIaX(TXJ9sq0zxbQrUEBi8SlPAaut3y,PPblYOcLrJH6QI,showDialogs):
	nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,lw2snZ9J0uhLoxypqa(u"ࠩ࠱ࡠࡹࡊ࡯ࡸࡰ࡯ࡳࡦࡪࡩ࡯ࡩ࠽ࠤࡠࠦࠧᄠ")+TXJ9sq0zxbQrUEBi8SlPAaut3y+rCmGE4YIDaZA(u"ࠪࠤࡢࠦࠠࠡࡊࡨࡥࡩ࡫ࡲࡴ࠼ࠣ࡟ࠥ࠭ᄡ")+str(PPblYOcLrJH6QI)+n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠫࠥࡣࠧᄢ"))
	p3BeaGrkduEo7zF = SHolYI1dP8g5ThqUAEt()
	p3BeaGrkduEo7zF.create(OksCHeoL5SG,HD7MQqXd2gS(u"ࠬ๐ฬา์ࠣห้ศๆࠡใะูࠥอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥะอๆ์็๋ࠥ๎ศฺั๊หู่ࠥโࠢอฬิษฺࠠ็็๎ฮࠦฬๅสࠣห้๋ไโ่๊ࠢࠥอไฦ่อี๋ะࠧᄣ"))
	yh3NdFJAT5kS9QpM6PwHgx84KIW = Yj1msqVeivESfrCupRy9b7WacBd(u"࠳࠳࠶࠹ᐩ")*Yj1msqVeivESfrCupRy9b7WacBd(u"࠳࠳࠶࠹ᐩ")
	ydanGHQjBiIWVb7SeKuYP6 = w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠴ᐪ")*yh3NdFJAT5kS9QpM6PwHgx84KIW
	import requests as xsu2pPbTo9XwU4v0tDO3
	tkSbvVxf8h1d0gLTci = xsu2pPbTo9XwU4v0tDO3.get(TXJ9sq0zxbQrUEBi8SlPAaut3y,stream=S5MWhgtZ37Xw,headers=PPblYOcLrJH6QI)
	E70UVeTi5AhOkm2aK6PJ = tkSbvVxf8h1d0gLTci.headers
	tkSbvVxf8h1d0gLTci.close()
	WFxmrsM2GIUTnhpg0boBR4lPNu9E = bytes()
	if not E70UVeTi5AhOkm2aK6PJ:
		if showDialogs: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,AJHaiQq3PRd5cphzGuELnVg9X(u"࠭วๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏ะๅไ่้๋ࠣࠦสฮ็ํ่ࠥอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥ๎วๅีหฬ่ࠥฯࠡ์ๆ์ู๋ࠦ็ัๆࠤฺ๊ใๅหࠣๅ๏ࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅࠣ࠲ࠥาัษࠢอั๊๐ไࠡษ็้้็ࠠๆำฬࠤศิั๊ࠩᄤ"))
		p3BeaGrkduEo7zF.close()
	else:
		if rCmGE4YIDaZA(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨᄥ") not in list(E70UVeTi5AhOkm2aK6PJ.keys()): CgiJ64R8cmUe9ZSX3N5YnstGQIh = IpFcwrWNgefMym3qta0hYQAzOdE
		else: CgiJ64R8cmUe9ZSX3N5YnstGQIh = int(E70UVeTi5AhOkm2aK6PJ[zhE5I4xHinX0UoVZMNwlkPrR(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩᄦ")])
		WkFs1KGMR2 = str(int(JvQd6LMoBX4hiy1C(u"࠶࠶࠰࠱ᐬ")*CgiJ64R8cmUe9ZSX3N5YnstGQIh/yh3NdFJAT5kS9QpM6PwHgx84KIW)/w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠵࠵࠶࠰࠯࠲ᐫ"))
		OaYVPIrb7uQNRCW9 = int(CgiJ64R8cmUe9ZSX3N5YnstGQIh/ydanGHQjBiIWVb7SeKuYP6)+UnOIK1WBbw2
		if YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡖࡦࡴࡧࡦࠩᄧ") in list(E70UVeTi5AhOkm2aK6PJ.keys()) and CgiJ64R8cmUe9ZSX3N5YnstGQIh>yh3NdFJAT5kS9QpM6PwHgx84KIW:
			SGdI5eBWianJOu201M9ljZ6bHkph7 = S5MWhgtZ37Xw
			RrMBxFZXLUnik = []
			opagI48rtNRjVHDSFxAJwqlYOZBM = bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠷࠰ᐭ")
			RrMBxFZXLUnik.append(str(IpFcwrWNgefMym3qta0hYQAzOdE*CgiJ64R8cmUe9ZSX3N5YnstGQIh//opagI48rtNRjVHDSFxAJwqlYOZBM)+Pj9YaUq1ibJ(u"ࠪ࠱ࠬᄨ")+str(UnOIK1WBbw2*CgiJ64R8cmUe9ZSX3N5YnstGQIh//opagI48rtNRjVHDSFxAJwqlYOZBM-UnOIK1WBbw2))
			RrMBxFZXLUnik.append(str(UnOIK1WBbw2*CgiJ64R8cmUe9ZSX3N5YnstGQIh//opagI48rtNRjVHDSFxAJwqlYOZBM)+Pj9YaUq1ibJ(u"ࠫ࠲࠭ᄩ")+str(udq5tP0hwifHQCGYELDbOUI*CgiJ64R8cmUe9ZSX3N5YnstGQIh//opagI48rtNRjVHDSFxAJwqlYOZBM-UnOIK1WBbw2))
			RrMBxFZXLUnik.append(str(udq5tP0hwifHQCGYELDbOUI*CgiJ64R8cmUe9ZSX3N5YnstGQIh//opagI48rtNRjVHDSFxAJwqlYOZBM)+lw2snZ9J0uhLoxypqa(u"ࠬ࠳ࠧᄪ")+str(AH0zdvBqibaXY*CgiJ64R8cmUe9ZSX3N5YnstGQIh//opagI48rtNRjVHDSFxAJwqlYOZBM-UnOIK1WBbw2))
			RrMBxFZXLUnik.append(str(AH0zdvBqibaXY*CgiJ64R8cmUe9ZSX3N5YnstGQIh//opagI48rtNRjVHDSFxAJwqlYOZBM)+bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠭࠭ࠨᄫ")+str(tpMX1Bgs0bzv8OEafyW*CgiJ64R8cmUe9ZSX3N5YnstGQIh//opagI48rtNRjVHDSFxAJwqlYOZBM-UnOIK1WBbw2))
			RrMBxFZXLUnik.append(str(tpMX1Bgs0bzv8OEafyW*CgiJ64R8cmUe9ZSX3N5YnstGQIh//opagI48rtNRjVHDSFxAJwqlYOZBM)+baBcNd81eH5ry2Olp6Mj43(u"ࠧ࠮ࠩᄬ")+str(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠵ᐮ")*CgiJ64R8cmUe9ZSX3N5YnstGQIh//opagI48rtNRjVHDSFxAJwqlYOZBM-UnOIK1WBbw2))
			RrMBxFZXLUnik.append(str(JvQd6LMoBX4hiy1C(u"࠶ᐯ")*CgiJ64R8cmUe9ZSX3N5YnstGQIh//opagI48rtNRjVHDSFxAJwqlYOZBM)+Qy6wlfLoOpg1(u"ࠨ࠯ࠪᄭ")+str(zhE5I4xHinX0UoVZMNwlkPrR(u"࠸ᐰ")*CgiJ64R8cmUe9ZSX3N5YnstGQIh//opagI48rtNRjVHDSFxAJwqlYOZBM-UnOIK1WBbw2))
			RrMBxFZXLUnik.append(str(zhE5I4xHinX0UoVZMNwlkPrR(u"࠺ᐲ")*CgiJ64R8cmUe9ZSX3N5YnstGQIh//opagI48rtNRjVHDSFxAJwqlYOZBM)+PPxYugzLZwHX23yiK(u"ࠩ࠰ࠫᄮ")+str(bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠺ᐱ")*CgiJ64R8cmUe9ZSX3N5YnstGQIh//opagI48rtNRjVHDSFxAJwqlYOZBM-UnOIK1WBbw2))
			RrMBxFZXLUnik.append(str(zhE5I4xHinX0UoVZMNwlkPrR(u"࠽ᐴ")*CgiJ64R8cmUe9ZSX3N5YnstGQIh//opagI48rtNRjVHDSFxAJwqlYOZBM)+AJHaiQq3PRd5cphzGuELnVg9X(u"ࠪ࠱ࠬᄯ")+str(ldIfvn6asURQ9toi85EhqAXW3(u"࠽ᐳ")*CgiJ64R8cmUe9ZSX3N5YnstGQIh//opagI48rtNRjVHDSFxAJwqlYOZBM-UnOIK1WBbw2))
			RrMBxFZXLUnik.append(str(rCmGE4YIDaZA(u"࠹ᐶ")*CgiJ64R8cmUe9ZSX3N5YnstGQIh//opagI48rtNRjVHDSFxAJwqlYOZBM)+lw2snZ9J0uhLoxypqa(u"ࠫ࠲࠭ᄰ")+str(pxt6wJ8ScYMWCivoO(u"࠹ᐵ")*CgiJ64R8cmUe9ZSX3N5YnstGQIh//opagI48rtNRjVHDSFxAJwqlYOZBM-UnOIK1WBbw2))
			RrMBxFZXLUnik.append(str(zhE5I4xHinX0UoVZMNwlkPrR(u"࠻ᐷ")*CgiJ64R8cmUe9ZSX3N5YnstGQIh//opagI48rtNRjVHDSFxAJwqlYOZBM)+Pj9YaUq1ibJ(u"ࠬ࠳ࠧᄱ"))
			V5DIvbzYZPNLJFXa6 = float(OaYVPIrb7uQNRCW9)/opagI48rtNRjVHDSFxAJwqlYOZBM
			iC8KeacbmsHf = V5DIvbzYZPNLJFXa6/int(UnOIK1WBbw2+V5DIvbzYZPNLJFXa6)
		else:
			SGdI5eBWianJOu201M9ljZ6bHkph7 = FFKncZx5pDTwdiJRYhMgQSNL
			opagI48rtNRjVHDSFxAJwqlYOZBM = UnOIK1WBbw2
			iC8KeacbmsHf = UnOIK1WBbw2
		nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠭࠮࡝ࡶࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡺࡹࡩ࡯ࡩࠣࡶࡦࡴࡧࡦࡵ࠽ࠤࡠࠦࠧᄲ")+str(SGdI5eBWianJOu201M9ljZ6bHkph7)+YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠧࠡ࡟ࠣࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩᄳ")+str(CgiJ64R8cmUe9ZSX3N5YnstGQIh)+HD7MQqXd2gS(u"ࠨࠢࡠࠫᄴ"))
		hsqrMEVB70i2ZnzPHlGYD1oy,ZzotVIFdmR = IpFcwrWNgefMym3qta0hYQAzOdE,IpFcwrWNgefMym3qta0hYQAzOdE
		for NNvUtJnePHZ8wra49 in range(opagI48rtNRjVHDSFxAJwqlYOZBM):
			LevQwm0pbqP1 = PPblYOcLrJH6QI.copy()
			if SGdI5eBWianJOu201M9ljZ6bHkph7: LevQwm0pbqP1[YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠩࡕࡥࡳ࡭ࡥࠨᄵ")] = yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠪࡦࡾࡺࡥࡴ࠿ࠪᄶ")+RrMBxFZXLUnik[NNvUtJnePHZ8wra49]
			tkSbvVxf8h1d0gLTci = xsu2pPbTo9XwU4v0tDO3.get(TXJ9sq0zxbQrUEBi8SlPAaut3y,stream=S5MWhgtZ37Xw,headers=LevQwm0pbqP1,timeout=w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠶࠴࠵ᐸ"))
			for JXEuO8qBF97 in tkSbvVxf8h1d0gLTci.iter_content(chunk_size=ydanGHQjBiIWVb7SeKuYP6):
				if p3BeaGrkduEo7zF.iscanceled():
					nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,gmPI7hVEM8nD(u"ࠫ࠳ࡢࡴࡅࡱࡺࡲࡱࡵࡡࡥࠢࡆࡥࡳࡩࡥ࡭ࡧࡧࠫᄷ"))
					break
				hsqrMEVB70i2ZnzPHlGYD1oy += iC8KeacbmsHf
				WFxmrsM2GIUTnhpg0boBR4lPNu9E += JXEuO8qBF97
				if not ZzotVIFdmR: ZzotVIFdmR = len(JXEuO8qBF97)
				if CgiJ64R8cmUe9ZSX3N5YnstGQIh: buQ2eMwxvTinjNrLVpUm6IH8fq(p3BeaGrkduEo7zF,jil8vRpBsENVYyPmDd(u"࠵࠵࠶ᐹ")*hsqrMEVB70i2ZnzPHlGYD1oy//OaYVPIrb7uQNRCW9,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠬาไษࠢส่๊๊แ࠻࠯ࠣห้าายࠢิๆ๊࠭ᄸ"),str(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠶࠶࠰࠯࠲ᐺ")*ZzotVIFdmR*hsqrMEVB70i2ZnzPHlGYD1oy//ydanGHQjBiIWVb7SeKuYP6//yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠶࠶࠰࠯࠲ᐺ"))+yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠭ࠠ࠰ࠢࠪᄹ")+WkFs1KGMR2+bb1fgjsAq4N2xYwnoh39lm(u"ࠧࠡࡏࡅࠫᄺ"))
				else: buQ2eMwxvTinjNrLVpUm6IH8fq(p3BeaGrkduEo7zF,ZzotVIFdmR*hsqrMEVB70i2ZnzPHlGYD1oy//ydanGHQjBiIWVb7SeKuYP6,UUobzy0xZLaVScIt7(u"ࠨฮ็ฬࠥอไๆๆไ࠾࠲࠭ᄻ"),str(HD7MQqXd2gS(u"࠷࠰࠱࠰࠳ᐻ")*ZzotVIFdmR*hsqrMEVB70i2ZnzPHlGYD1oy//ydanGHQjBiIWVb7SeKuYP6//HD7MQqXd2gS(u"࠷࠰࠱࠰࠳ᐻ"))+w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠩࠣࡑࡇ࠭ᄼ"))
			tkSbvVxf8h1d0gLTci.close()
		p3BeaGrkduEo7zF.close()
		if len(WFxmrsM2GIUTnhpg0boBR4lPNu9E)<CgiJ64R8cmUe9ZSX3N5YnstGQIh and CgiJ64R8cmUe9ZSX3N5YnstGQIh>IpFcwrWNgefMym3qta0hYQAzOdE:
			nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,UUobzy0xZLaVScIt7(u"ࠪ࠲ࡡࡺࡄࡰࡹࡱࡰࡴࡧࡤࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡱࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩࠦࡡࡵ࠼ࠣ࡟ࠥ࠭ᄽ")+str(len(WFxmrsM2GIUTnhpg0boBR4lPNu9E)//yh3NdFJAT5kS9QpM6PwHgx84KIW)+vzqjsVHSBlMpxC(u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡌࡲࡰ࡯ࠣࡸࡴࡺࡡ࡭ࠢࡲࡪ࠿࡛ࠦࠡࠩᄾ")+WkFs1KGMR2+DFx6E0uON7Jm8(u"ࠬࠦࡍࡃࠢࡠࠫᄿ"))
			Jxg8Od1foHnuRrwvZAW4iNCVMzEUF = vnI6XSlmEtsx7(nA5dhMRg6ENzsB0l1GwvH7aIr2,xwIUQfiE7rmvYzH(u"࠭ลๅ฼สลࠥ๎ฮา๊ฯࠫᅀ"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠧศีอาิอๅࠡษ็้้็ࠠศๆ้ห็฻ࠧᅁ"),Pj9YaUq1ibJ(u"ࠨว฼หิฯࠠอๆหࠤฬ๊ๅๅใࠪᅂ"),OksCHeoL5SG,rCmGE4YIDaZA(u"ࠩไุ้ࠦแ๋ࠢฯ่อࠦวๅ็็ๅࠥࡢ࡮ࠡๆ็วุ็ࠠฮัฮࠤำ฽รࠡใํࠤฯำๅ๋ๆࠣห้๋ไโࠢ࡟ࡲࠥะๅࠡฮ็ฬࠥ࠭ᅃ")+str(len(WFxmrsM2GIUTnhpg0boBR4lPNu9E)//yh3NdFJAT5kS9QpM6PwHgx84KIW)+bb1fgjsAq4N2xYwnoh39lm(u"ࠪࠤ๊๐ฺศสส๎ฯࠦๅ็่ࠢะ๊๎ูࠡࠩᅄ")+WkFs1KGMR2+mRanX1HZupfSQVB2gsDGUO(u"๋๊ࠫࠥ฻ษหห๏ะࠠ࡝ࡰࠣะึฮࠠอๆหࠤฬ๊ๅๅใ้ࠣึฯࠠฤะิํࠥࡢ࡮้ࠡ็ࠤฯื๊ะࠢสืฯิฯศ็ࠣห้๋ไโࠢส่๋อโึࠢยࠥࠦ࠭ᅅ"))
			if Jxg8Od1foHnuRrwvZAW4iNCVMzEUF==udq5tP0hwifHQCGYELDbOUI: WFxmrsM2GIUTnhpg0boBR4lPNu9E = Ew2exk7boOIaX(TXJ9sq0zxbQrUEBi8SlPAaut3y,PPblYOcLrJH6QI,showDialogs)
			elif Jxg8Od1foHnuRrwvZAW4iNCVMzEUF==UnOIK1WBbw2: nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,rCmGE4YIDaZA(u"ࠬ࠴࡜ࡵࡐࡲࡸࠥࡩ࡯࡮ࡲ࡯ࡩࡹ࡫ࡤࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡨࡨࠥ࡬ࡩ࡭ࡧࠣ࡭ࡸࠦࡡࡤࡥࡨࡴࡹ࡫ࡤࠡࡣࡱࡨࠥࡽࡩ࡭࡮ࠣࡦࡪࠦࡵࡴࡧࡧࠫᅆ"))
			else: return nA5dhMRg6ENzsB0l1GwvH7aIr2
			if not WFxmrsM2GIUTnhpg0boBR4lPNu9E: return nA5dhMRg6ENzsB0l1GwvH7aIr2
		else: nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,rCmGE4YIDaZA(u"࠭࠮࡝ࡶࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡘࡻࡣࡤࡧࡨࡨࡪࡪ࠮ࠡࠢࠣࡊ࡮ࡲࡥࠡࡕ࡬ࡾࡪࡀࠠ࡜ࠢࠪᅇ")+WkFs1KGMR2+w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠧࠡࡏࡅࠤࡢ࠭ᅈ"))
	return WFxmrsM2GIUTnhpg0boBR4lPNu9E
def waeY492jyUPOEoJ7m(wgj0rX5tbcxPulhmny):
	return tkSbvVxf8h1d0gLTci
def Cu2PQbzG5shMkL08cdYNOfjvKx9o(ip=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if Nzp9Fq5cTr.GEOLOCATION_DATA: return Nzp9Fq5cTr.GEOLOCATION_DATA
	TrRmF5oN3gZ40ykL2,iPWN5tr1aBS0YZnmlgOM,wCBpM4Lktz735hsljdZPeqHWxQE2,HiDnlyVWOaMZsB0SmdeoRTwXYULf,yxwcSYGIgO,QQ2WEg1pr8BbsuY = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	RxWJFBAGy4iIM = YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡫ࡳࡻ࡭ࡵ࠮ࡪࡵ࠲ࠫᅉ")+ip+ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠩࡂࡳࡺࡺࡰࡶࡶࡀ࡮ࡸࡵ࡮ࠧࡨ࡬ࡩࡱࡪࡳ࠾࡫ࡳ࠰ࡨࡵ࡮ࡵ࡫ࡱࡩࡳࡺࠬࡤࡱࡸࡲࡹࡸࡹ࠭ࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫ࠬࡳࡧࡪ࡭ࡴࡴࠬࡤ࡫ࡷࡽ࠱ࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧᅊ")
	PPblYOcLrJH6QI = {FVxoQ2J5Mfv3Zj6sy9uhOS(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᅋ"):nA5dhMRg6ENzsB0l1GwvH7aIr2}
	tkSbvVxf8h1d0gLTci = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠫࡌࡋࡔࠨᅌ"),RxWJFBAGy4iIM,nA5dhMRg6ENzsB0l1GwvH7aIr2,PPblYOcLrJH6QI,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,XEcWOIwkZKubV7vQ(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡑࡏࡓࡈࡇࡔࡊࡑࡑ࠱࠶ࡹࡴࠨᅍ"))
	if not tkSbvVxf8h1d0gLTci.succeeded:
		RxWJFBAGy4iIM = xwIUQfiE7rmvYzH(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡩࡱ࠯ࡤࡴ࡮࠴ࡣࡰ࡯࠲࡮ࡸࡵ࡮࠰ࠩᅎ")+ip+DFx6E0uON7Jm8(u"ࠧࡀࡨ࡬ࡩࡱࡪࡳ࠾ࡳࡸࡩࡷࡿࠬࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶ࠯ࡧࡴࡻ࡮ࡵࡴࡼ࠰ࡨࡵࡵ࡯ࡶࡵࡽࡈࡵࡤࡦ࠮ࡵࡩ࡬࡯࡯࡯ࡐࡤࡱࡪ࠲ࡣࡪࡶࡼ࠰ࡴ࡬ࡦࡴࡧࡷࠫᅏ")
		tkSbvVxf8h1d0gLTci = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠨࡉࡈࡘࠬᅐ"),RxWJFBAGy4iIM,nA5dhMRg6ENzsB0l1GwvH7aIr2,PPblYOcLrJH6QI,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,zhE5I4xHinX0UoVZMNwlkPrR(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊࡕࡌࡐࡅࡄࡘࡎࡕࡎ࠮࠴ࡱࡨࠬᅑ"))
	if tkSbvVxf8h1d0gLTci.succeeded:
		kl2ZWdy8rXcHT = tkSbvVxf8h1d0gLTci.content
		qmrGBJcXlQ3CE8KIMxWYVy67Za1o = DcFpQN9gqn.loads(kl2ZWdy8rXcHT)
		q8Cx9zw4engtQ = list(qmrGBJcXlQ3CE8KIMxWYVy67Za1o.keys())
		if yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠪ࡭ࡵ࠭ᅒ") in q8Cx9zw4engtQ: ip = qmrGBJcXlQ3CE8KIMxWYVy67Za1o[DFx6E0uON7Jm8(u"ࠫ࡮ࡶࠧᅓ")]
		if vzqjsVHSBlMpxC(u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴࠨᅔ") in q8Cx9zw4engtQ: TrRmF5oN3gZ40ykL2 = qmrGBJcXlQ3CE8KIMxWYVy67Za1o[bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠭ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵࠩᅕ")]
		if UUobzy0xZLaVScIt7(u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨᅖ") in q8Cx9zw4engtQ: iPWN5tr1aBS0YZnmlgOM = qmrGBJcXlQ3CE8KIMxWYVy67Za1o[jil8vRpBsENVYyPmDd(u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩᅗ")]
		if baBcNd81eH5ry2Olp6Mj43(u"ࠩࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥࠨᅘ") in q8Cx9zw4engtQ: wCBpM4Lktz735hsljdZPeqHWxQE2 = qmrGBJcXlQ3CE8KIMxWYVy67Za1o[rCmGE4YIDaZA(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦࠩᅙ")]
		if nfNTgkiWdUq(u"ࠫࡷ࡫ࡧࡪࡱࡱࠫᅚ") in q8Cx9zw4engtQ: HiDnlyVWOaMZsB0SmdeoRTwXYULf = qmrGBJcXlQ3CE8KIMxWYVy67Za1o[lw2snZ9J0uhLoxypqa(u"ࠬࡸࡥࡨ࡫ࡲࡲࠬᅛ")]
		if jil8vRpBsENVYyPmDd(u"࠭ࡣࡪࡶࡼࠫᅜ") in q8Cx9zw4engtQ: yxwcSYGIgO = qmrGBJcXlQ3CE8KIMxWYVy67Za1o[nfNTgkiWdUq(u"ࠧࡤ࡫ࡷࡽࠬᅝ")]
		if HD7MQqXd2gS(u"ࠨࡳࡸࡩࡷࡿࠧᅞ") in q8Cx9zw4engtQ: ip = qmrGBJcXlQ3CE8KIMxWYVy67Za1o[JvQd6LMoBX4hiy1C(u"ࠩࡴࡹࡪࡸࡹࠨᅟ")]
		if mRanX1HZupfSQVB2gsDGUO(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࡇࡴࡪࡥࠨᅠ") in q8Cx9zw4engtQ: wCBpM4Lktz735hsljdZPeqHWxQE2 = qmrGBJcXlQ3CE8KIMxWYVy67Za1o[xwIUQfiE7rmvYzH(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࡈࡵࡤࡦࠩᅡ")]
		if bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠬࡸࡥࡨ࡫ࡲࡲࡓࡧ࡭ࡦࠩᅢ") in q8Cx9zw4engtQ: HiDnlyVWOaMZsB0SmdeoRTwXYULf = qmrGBJcXlQ3CE8KIMxWYVy67Za1o[zhE5I4xHinX0UoVZMNwlkPrR(u"࠭ࡲࡦࡩ࡬ࡳࡳࡔࡡ࡮ࡧࠪᅣ")]
		if UUobzy0xZLaVScIt7(u"ࠧࡵ࡫ࡰࡩࡿࡵ࡮ࡦࠩᅤ") in q8Cx9zw4engtQ:
			QQ2WEg1pr8BbsuY = qmrGBJcXlQ3CE8KIMxWYVy67Za1o[VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠨࡶ࡬ࡱࡪࢀ࡯࡯ࡧࠪᅥ")][XEcWOIwkZKubV7vQ(u"ࠩࡸࡸࡨ࠭ᅦ")]
			if QQ2WEg1pr8BbsuY[IpFcwrWNgefMym3qta0hYQAzOdE] not in [VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠪ࠱ࠬᅧ"),DFx6E0uON7Jm8(u"ࠫ࠰࠭ᅨ")]: QQ2WEg1pr8BbsuY = ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠬ࠱ࠧᅩ")+QQ2WEg1pr8BbsuY
		if XEcWOIwkZKubV7vQ(u"࠭࡯ࡧࡨࡶࡩࡹ࠭ᅪ") in q8Cx9zw4engtQ:
			QQ2WEg1pr8BbsuY = qmrGBJcXlQ3CE8KIMxWYVy67Za1o[lw2snZ9J0uhLoxypqa(u"ࠧࡰࡨࡩࡷࡪࡺࠧᅫ")]
			if QQ2WEg1pr8BbsuY>=lw2snZ9J0uhLoxypqa(u"࠰ᐼ"): QQ2WEg1pr8BbsuY = Yj1msqVeivESfrCupRy9b7WacBd(u"ࠨ࠭ࠪᅬ")+h0skHe7TcIY9x1UP5VBrZAE8dKGnl.strftime(ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠤࠨࡌ࠿ࠫࡍࠣᅭ"),h0skHe7TcIY9x1UP5VBrZAE8dKGnl.gmtime(QQ2WEg1pr8BbsuY))
			else: QQ2WEg1pr8BbsuY = zhE5I4xHinX0UoVZMNwlkPrR(u"ࠪ࠱ࠬᅮ")+h0skHe7TcIY9x1UP5VBrZAE8dKGnl.strftime(LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠦࠪࡎ࠺ࠦࡏࠥᅯ"),h0skHe7TcIY9x1UP5VBrZAE8dKGnl.gmtime(-QQ2WEg1pr8BbsuY))
	hT6JqAgVontUpRHZNw5G1mCOlvzi0 = ip+n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠬ࠲ࠧᅰ")+TrRmF5oN3gZ40ykL2+Qy6wlfLoOpg1(u"࠭ࠬࠨᅱ")+iPWN5tr1aBS0YZnmlgOM+rCmGE4YIDaZA(u"ࠧ࠭ࠩᅲ")+HiDnlyVWOaMZsB0SmdeoRTwXYULf+nfNTgkiWdUq(u"ࠨ࠮ࠪᅳ")+yxwcSYGIgO+AJHaiQq3PRd5cphzGuELnVg9X(u"ࠩ࠯ࠫᅴ")+QQ2WEg1pr8BbsuY
	hT6JqAgVontUpRHZNw5G1mCOlvzi0 = hT6JqAgVontUpRHZNw5G1mCOlvzi0.encode(YWEQ3Cf8RevpD0m7NjF1)
	if BsLJ7p5Av2Vm0SQeCO1o: hT6JqAgVontUpRHZNw5G1mCOlvzi0 = hT6JqAgVontUpRHZNw5G1mCOlvzi0.decode(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫᅵ"))
	Nzp9Fq5cTr.GEOLOCATION_DATA = jPgzFLH1niJpE2r(hT6JqAgVontUpRHZNw5G1mCOlvzi0)
	return Nzp9Fq5cTr.GEOLOCATION_DATA
def Vit4q8MczeLRHnJQCyXAam(JJTXBwzaIeH745AYmSf):
	v9fCwmQx7uVUS,showDialogs = nA5dhMRg6ENzsB0l1GwvH7aIr2,S5MWhgtZ37Xw
	if JJTXBwzaIeH745AYmSf.count(rCmGE4YIDaZA(u"ࠫࡤ࠭ᅶ"))>=udq5tP0hwifHQCGYELDbOUI:
		JJTXBwzaIeH745AYmSf,v9fCwmQx7uVUS = JJTXBwzaIeH745AYmSf.split(vzqjsVHSBlMpxC(u"ࠬࡥࠧᅷ"),UnOIK1WBbw2)
		v9fCwmQx7uVUS = VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠭࡟ࠨᅸ")+v9fCwmQx7uVUS
		if HD7MQqXd2gS(u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࠬᅹ") in v9fCwmQx7uVUS: showDialogs = FFKncZx5pDTwdiJRYhMgQSNL
		else: showDialogs = S5MWhgtZ37Xw
	return JJTXBwzaIeH745AYmSf,v9fCwmQx7uVUS,showDialogs
def CrklfeQ3LOI1X():
	S706VNtgw3yU = XoZRpFe7B6gnfA.path.join(mQKDw6vcXNIkngiWrC8GdPFqeRH,FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧᅺ"))
	bvnOLkyBGt0pr3Nwx = IpFcwrWNgefMym3qta0hYQAzOdE
	if XoZRpFe7B6gnfA.path.exists(S706VNtgw3yU):
		for SR0vOrfBXW6AJ in XoZRpFe7B6gnfA.listdir(S706VNtgw3yU):
			if mRanX1HZupfSQVB2gsDGUO(u"ࠩ࠱ࡴࡾࡵࠧᅻ") in SR0vOrfBXW6AJ: continue
			if HD7MQqXd2gS(u"ࠪࡣࡤࡶࡹࡤࡣࡦ࡬ࡪࡥ࡟ࠨᅼ") in SR0vOrfBXW6AJ: continue
			ScBlEZs4p5dGmrzTCgiD3fWPO7hqK = XoZRpFe7B6gnfA.path.join(S706VNtgw3yU,SR0vOrfBXW6AJ)
			b92ByL07OjDwvKCgzMFNTfm5APUGqQ,GsxA9qQzNZKg5XfiWuMd0HCE = cpNjIxZEUORvTw(ScBlEZs4p5dGmrzTCgiD3fWPO7hqK)
			bvnOLkyBGt0pr3Nwx += b92ByL07OjDwvKCgzMFNTfm5APUGqQ
	return bvnOLkyBGt0pr3Nwx
def uytr9P8Bwz6FN(showDialogs):
	xsJihYq5eSE = KQctJbXeEjDhplqknU3rzi.getSetting(lw2snZ9J0uhLoxypqa(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩᅽ"))
	Q3zOj4EUcMmrY = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠬࡹࡴࡳࠩᅾ"),pxt6wJ8ScYMWCivoO(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࡡ࠴ࠫᅿ"),lw2snZ9J0uhLoxypqa(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩᆀ"))
	GFaoJdYmfyPibIT6rv8LSMKps7D0,g8It4wGJfh0S5rX1qcZbnM7jQaiu = xsJihYq5eSE,Q3zOj4EUcMmrY
	hdKC4wO3xINoWVQkaTsZpJlHqG0tYi,LTeOSaGYnAMsimPz27 = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	if nfNTgkiWdUq(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪᆁ") not in str(Nzp9Fq5cTr.SEND_THESE_EVENTS):
		RxWJFBAGy4iIM = Nzp9Fq5cTr.SITESURLS[VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩᆂ")][AH0zdvBqibaXY]
		MMENSb8ojUDHBG5 = Cu2PQbzG5shMkL08cdYNOfjvKx9o()
		iPWN5tr1aBS0YZnmlgOM = MMENSb8ojUDHBG5.split(VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠪ࠰ࠬᆃ"))[udq5tP0hwifHQCGYELDbOUI]
		bvnOLkyBGt0pr3Nwx = CrklfeQ3LOI1X()
		S0adTZ3gA7vexpiNfPJt2mVKuURM = {pxt6wJ8ScYMWCivoO(u"ࠫࡺࡹࡥࡳࠩᆄ"):Nzp9Fq5cTr.AV_CLIENT_IDS,bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭ᆅ"):s5WcxEPjUBokapYMhAwb60dvgi,pxt6wJ8ScYMWCivoO(u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧᆆ"):iPWN5tr1aBS0YZnmlgOM,UUobzy0xZLaVScIt7(u"ࠧࡪࡦࡶࠫᆇ"):AsG2TjLa1DUMI(bvnOLkyBGt0pr3Nwx)}
		tkSbvVxf8h1d0gLTci = uANakQHcnhR(yy6RomT9bQhJf,JvQd6LMoBX4hiy1C(u"ࠨࡒࡒࡗ࡙࠭ᆈ"),RxWJFBAGy4iIM,S0adTZ3gA7vexpiNfPJt2mVKuURM,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,UUobzy0xZLaVScIt7(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡎࡇࡖࡗࡆࡍࡅࡔ࠯࠴ࡷࡹ࠭ᆉ"))
		if not tkSbvVxf8h1d0gLTci.succeeded:
			if xsJihYq5eSE in [nA5dhMRg6ENzsB0l1GwvH7aIr2,JvQd6LMoBX4hiy1C(u"ࠪࡒࡊ࡝ࠧᆊ")]: GFaoJdYmfyPibIT6rv8LSMKps7D0 = bb1fgjsAq4N2xYwnoh39lm(u"ࠫࡓࡋࡗࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪᆋ")
			elif xsJihYq5eSE==nfNTgkiWdUq(u"ࠬࡕࡌࡅࠩᆌ"): GFaoJdYmfyPibIT6rv8LSMKps7D0 = jil8vRpBsENVYyPmDd(u"࠭ࡏࡍࡆࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬᆍ")
		else:
			jmwVr4kqo7f5gPZzv2pna9 = tkSbvVxf8h1d0gLTci.content
			jmwVr4kqo7f5gPZzv2pna9 = BwGPDSQOlfUas2n3eIH0ycFRWZ(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠧ࡭࡫ࡶࡸࠬᆎ"),jmwVr4kqo7f5gPZzv2pna9)
			jmwVr4kqo7f5gPZzv2pna9 = sorted(jmwVr4kqo7f5gPZzv2pna9,reverse=S5MWhgtZ37Xw,key=lambda key: int(key[IpFcwrWNgefMym3qta0hYQAzOdE]))
			LTeOSaGYnAMsimPz27,g8It4wGJfh0S5rX1qcZbnM7jQaiu = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
			for VVrzQjKtNe,nNu4r3Imscg2ad8UJbq69lok,oZOKmgkbJIHtAyuvrqFQBS1CzNa0Tw in jmwVr4kqo7f5gPZzv2pna9:
				if VVrzQjKtNe==PPxYugzLZwHX23yiK(u"ࠨ࠲ࠪᆏ"):
					LTeOSaGYnAMsimPz27 += oZOKmgkbJIHtAyuvrqFQBS1CzNa0Tw+bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠩ࠽࠾ࠬᆐ")
					continue
				if g8It4wGJfh0S5rX1qcZbnM7jQaiu: g8It4wGJfh0S5rX1qcZbnM7jQaiu += CXtugbqhV3+bbTCMJwEx8nhN4X+DFx6E0uON7Jm8(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩᆑ")+NwROdSj3nsA+yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠫࡡࡴ࡜࡯ࠩᆒ")
				etM8lYh09bcKCAw4FaDXRjPfkBioy = oZOKmgkbJIHtAyuvrqFQBS1CzNa0Tw.split(CXtugbqhV3)[IpFcwrWNgefMym3qta0hYQAzOdE]
				oyQkfCvd94jcIKAUZHM7LphG0gD = yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠬืำศๆฬࠤำอีสࠢ็็ࠥ็โุࠩᆓ") if nNu4r3Imscg2ad8UJbq69lok else nA5dhMRg6ENzsB0l1GwvH7aIr2
				g8It4wGJfh0S5rX1qcZbnM7jQaiu += oZOKmgkbJIHtAyuvrqFQBS1CzNa0Tw.replace(etM8lYh09bcKCAw4FaDXRjPfkBioy,lSWzOYmN08+etM8lYh09bcKCAw4FaDXRjPfkBioy+oyQkfCvd94jcIKAUZHM7LphG0gD+NwROdSj3nsA)+CXtugbqhV3
			g8It4wGJfh0S5rX1qcZbnM7jQaiu = CXtugbqhV3+g8It4wGJfh0S5rX1qcZbnM7jQaiu+LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠭࡜࡯࡞ࡱࠫᆔ")
			LTeOSaGYnAMsimPz27 = LTeOSaGYnAMsimPz27.strip(xwIUQfiE7rmvYzH(u"ࠧ࠻࠼ࠪᆕ"))
			hdKC4wO3xINoWVQkaTsZpJlHqG0tYi = KQctJbXeEjDhplqknU3rzi.getSetting(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠨࡣࡹ࠲ࡵࡸࡩࡷࡵ࠴ࠫᆖ"))
			if g8It4wGJfh0S5rX1qcZbnM7jQaiu==Q3zOj4EUcMmrY and xsJihYq5eSE in [UUobzy0xZLaVScIt7(u"ࠩࡒࡐࡉ࠭ᆗ"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠪࡓࡑࡊ࡟ࡕࡑࡢࡉࡗࡘࡏࡓࠩᆘ")]: GFaoJdYmfyPibIT6rv8LSMKps7D0 = lw2snZ9J0uhLoxypqa(u"ࠫࡔࡒࡄࠨᆙ")
			else: GFaoJdYmfyPibIT6rv8LSMKps7D0 = pxt6wJ8ScYMWCivoO(u"ࠬࡔࡅࡘࠩᆚ")
			WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࡡ࠴ࠫᆛ"),ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩᆜ"),g8It4wGJfh0S5rX1qcZbnM7jQaiu,l7ltVNxrbPimpXJDh)
			KQctJbXeEjDhplqknU3rzi.setSetting(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩᆝ"),AsG2TjLa1DUMI(GHSrzcU3jo2))
			KQctJbXeEjDhplqknU3rzi.setSetting(bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ࠵ࠬᆞ"),LTeOSaGYnAMsimPz27)
			barWI0ALHCiKu3vkd = l4pFeYACHV1.md5(rCmGE4YIDaZA(u"࠶ᐽ")*LTeOSaGYnAMsimPz27.encode(YWEQ3Cf8RevpD0m7NjF1)).hexdigest()
			barWI0ALHCiKu3vkd = l4pFeYACHV1.md5(AJHaiQq3PRd5cphzGuELnVg9X(u"࠳࠷ᐾ")*barWI0ALHCiKu3vkd.encode(YWEQ3Cf8RevpD0m7NjF1)).hexdigest()
			barWI0ALHCiKu3vkd = l4pFeYACHV1.md5(mRanX1HZupfSQVB2gsDGUO(u"࠴࠽ᐿ")*barWI0ALHCiKu3vkd.encode(YWEQ3Cf8RevpD0m7NjF1)).hexdigest()
			Ccemh2nAvQ,ADJdGOPzaeo0rXf2SuKQbcFWqilw = WbauZQKtLNV8BYxR0(FeDIpVljXmOnNkPAHscdTKWrEa)
			fCIXRAyscP0b2MOGhJwTa7tjLl(FeDIpVljXmOnNkPAHscdTKWrEa,Ccemh2nAvQ,ADJdGOPzaeo0rXf2SuKQbcFWqilw,FFKncZx5pDTwdiJRYhMgQSNL,nfNTgkiWdUq(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮ࡠ࡫ࡧࡁࠬᆟ")+str(int(barWI0ALHCiKu3vkd[YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠸ᑁ"):UUobzy0xZLaVScIt7(u"࠷࠲ᑂ")],mRanX1HZupfSQVB2gsDGUO(u"࠱࠷ᑃ")))[:UUobzy0xZLaVScIt7(u"࠽ᑀ")]+bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠫࠥࡁࠧᆠ"))
			Ccemh2nAvQ.close()
		HHagVMUxO2Y96Q0 = S5MWhgtZ37Xw if LTeOSaGYnAMsimPz27!=hdKC4wO3xINoWVQkaTsZpJlHqG0tYi else FFKncZx5pDTwdiJRYhMgQSNL
		if HHagVMUxO2Y96Q0:
			oosT6HyfG3RO5bMnI = Nzp9Fq5cTr.Gnkf9VO7o1Bv5hTyAUPbHE
			Nzp9Fq5cTr.sz6qutHF1ITYr0a3cGJKOf,Nzp9Fq5cTr.Gnkf9VO7o1Bv5hTyAUPbHE,Nzp9Fq5cTr.eWcSBRXKYLw6arPkf,Nzp9Fq5cTr.KR9TdgoVwvr4mIP,Nzp9Fq5cTr.avprivsnorestrict,Nzp9Fq5cTr.avprivslongperiod = wlLKvDsi3Ex2WcqyJVFrdmpk([Qy6wlfLoOpg1(u"ࠬࡉࡔࡆ࠻ࡇࡗ࠶࠿ࡖࡖ࠲࡙ࡗ࡝࠭ᆡ"),pxt6wJ8ScYMWCivoO(u"࠭ࡗࡔࡗࡕࡊ࡙࠷࠹ࡒࡖࡈࡊ࡟࡞ࠧᆢ"),JvQd6LMoBX4hiy1C(u"ࠧࡃࡖࡈࡼࡕ࡜࠱࠺ࡗࡕ࡚ࡓ࡛ࡓࡖ࠷ࡋ࡜ࠬᆣ"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠨࡑࡗ࠵࠾ࡐࡕ࠱ࡺࡅࡘ࡚ࡲࡄ࡙ࠩᆤ"),ldIfvn6asURQ9toi85EhqAXW3(u"ࠩࡅࡘࡊࡾࡐࡗ࠳࠼ࡗࡗ࡜ࡎࡖࡗ࡮ࡰࡉ࡜ࡅࡗࡇ࡛ࠫᆥ"),DFx6E0uON7Jm8(u"ࠪࡑ࡙࠶࠵ࡉ࡚࠳ࡰ࡙࡚ࡅࡇࡐࡖ࡙ࡓ࡬ࡕࡆࡘࡖࡗ࡚࠿ࡅ࡙ࠩᆦ")])
			BErCJH5IP8VmZUsYutc1dW = Nzp9Fq5cTr.Gnkf9VO7o1Bv5hTyAUPbHE
			if not oosT6HyfG3RO5bMnI and BErCJH5IP8VmZUsYutc1dW and FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘࡥࡔࡔࠩᆧ") in Nzp9Fq5cTr.SEND_THESE_EVENTS:
				Nzp9Fq5cTr.SEND_THESE_EVENTS.remove(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙࡟ࡕࡕࠪᆨ"))
				Nzp9Fq5cTr.SEND_THESE_EVENTS.append(mRanX1HZupfSQVB2gsDGUO(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨᆩ"))
			elif oosT6HyfG3RO5bMnI and not BErCJH5IP8VmZUsYutc1dW and n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩᆪ") in Nzp9Fq5cTr.SEND_THESE_EVENTS:
				Nzp9Fq5cTr.SEND_THESE_EVENTS.remove(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪᆫ"))
				Nzp9Fq5cTr.SEND_THESE_EVENTS.append(DFx6E0uON7Jm8(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࡣ࡙࡙ࠧᆬ"))
			AA5FS4hUqeP9EsZCM(FFKncZx5pDTwdiJRYhMgQSNL)
	if showDialogs:
		if GFaoJdYmfyPibIT6rv8LSMKps7D0 in [Yj1msqVeivESfrCupRy9b7WacBd(u"ࠪࡓࡑࡊ࡟ࡕࡑࡢࡉࡗࡘࡏࡓࠩᆭ"),xwIUQfiE7rmvYzH(u"ࠫࡓࡋࡗࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪᆮ")]:
			OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,vzqjsVHSBlMpxC(u"ࠬํๆศๅู้้ࠣไสࠢไ๎ࠥา็ศิๆࠤํํ๊ࠡๆํืฯࠦๅ็ࠢส่อืๆศ็ฯࠤ࠳࠴่ࠠา๊ࠤฬ๊ๅีๅ็อ่ࠥฯࠡ์ๆ์๋ࠦำษส๊หࠥอไฦ่อี๋ะࠠศๆัหฺࠦศไࠢฦ์ࠥอไาษ๋ฮึࠦวๅะสูࠥฮใࠡล๋ࠤฺ๊ใๅหࠣๅ๏ࠦวๅลึ่ฬฺ้่ࠠา็ࠬᆯ"))
		else:
			d9EaJh5t3Tyj7CsXFL(HD7MQqXd2gS(u"࠭ࡲࡪࡩ࡫ࡸࠬᆰ"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠧาีสส้ࠦๅ็ࠢส่๊ฮัๆฮࠣษ้๏ࠠๆีอาิ๋๊ࠡษ็ฬึ์วๆฮࠪᆱ"),g8It4wGJfh0S5rX1qcZbnM7jQaiu,UUobzy0xZLaVScIt7(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩᆲ"))
			GFaoJdYmfyPibIT6rv8LSMKps7D0 = xwIUQfiE7rmvYzH(u"ࠩࡒࡐࡉ࠭ᆳ")
	if GFaoJdYmfyPibIT6rv8LSMKps7D0!=xsJihYq5eSE:
		KQctJbXeEjDhplqknU3rzi.setSetting(bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨᆴ"),GFaoJdYmfyPibIT6rv8LSMKps7D0)
		AA5FS4hUqeP9EsZCM(FFKncZx5pDTwdiJRYhMgQSNL)
	return
def e1MtrcQ06UEH(c9BuLKw8Pk1bm4fetghY7lp0DCojia,VBqkfmswQI4vapo3eytY2r):
	import socket as rvBVZ0QSYs3pqRjAzHl9KJ
	f8JXirYax34njhV1H = rvBVZ0QSYs3pqRjAzHl9KJ.socket(rvBVZ0QSYs3pqRjAzHl9KJ.AF_INET,rvBVZ0QSYs3pqRjAzHl9KJ.SOCK_STREAM)
	f8JXirYax34njhV1H.settimeout(AH0zdvBqibaXY)
	try:
		QUevxqzda3 = h0skHe7TcIY9x1UP5VBrZAE8dKGnl.time()
		f8JXirYax34njhV1H.connect((c9BuLKw8Pk1bm4fetghY7lp0DCojia,VBqkfmswQI4vapo3eytY2r))
		ttb1zM62VP7gNonFQdhuxUwRy = h0skHe7TcIY9x1UP5VBrZAE8dKGnl.time()
		WdnJVMgSm0pDvhawITN5Xosq = round((ttb1zM62VP7gNonFQdhuxUwRy-QUevxqzda3)*Qy6wlfLoOpg1(u"࠲࠲࠳࠴ᑄ"))
	except: WdnJVMgSm0pDvhawITN5Xosq = -UnOIK1WBbw2
	f8JXirYax34njhV1H.close()
	return WdnJVMgSm0pDvhawITN5Xosq
def GlAym7JHLirouYThdfcjCtV(showDialogs):
	if showDialogs:
		x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,zhE5I4xHinX0UoVZMNwlkPrR(u"ุࠫ๎แࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡษ็ฦ๋ࠦศฦื็หา่ࠦห่฻๎ๆࠦฬๆ์฼ࠤ็๎วฺัࠣห้ฮ๊ศ่สฮࠥ๎วๅๅสุࠥอไๆีอาิ๋ษࠡใํࠤฬ๊ศา่ส้ัࠦ࠮࠯๊่ࠢࠥะั๋ัࠣฮูเ๊ๅࠢ฼้้๐ษࠡษ็ฮ๋฾๊โࠢส่ว์ࠠภࠣࠪᆵ"))
	else: x6zlf2tTZm = S5MWhgtZ37Xw
	if x6zlf2tTZm==UnOIK1WBbw2:
		for SR0vOrfBXW6AJ in XoZRpFe7B6gnfA.listdir(QQwBc24Oza7jJ8ClTRWexUoqGAkg0):
			if SR0vOrfBXW6AJ.endswith(xwIUQfiE7rmvYzH(u"ࠬ࠴ࡤࡣࠩᆶ")) and VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠭ࡤࡢࡶࡤࠫᆷ") in SR0vOrfBXW6AJ:
				kkgGhU2YA15oHcB = XoZRpFe7B6gnfA.path.join(QQwBc24Oza7jJ8ClTRWexUoqGAkg0,SR0vOrfBXW6AJ)
				Ccemh2nAvQ,ADJdGOPzaeo0rXf2SuKQbcFWqilw = WbauZQKtLNV8BYxR0(kkgGhU2YA15oHcB)
				ADJdGOPzaeo0rXf2SuKQbcFWqilw.execute(bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡧࡱࡵࡩ࡮࡭࡮ࡠ࡭ࡨࡽࡸࡃ࡮ࡰ࠽ࠪᆸ"))
				ADJdGOPzaeo0rXf2SuKQbcFWqilw.execute(bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡶࡨࡱࡵࡥࡳࡵࡱࡵࡩࡂࡓࡅࡎࡑࡕ࡝ࡀ࠭ᆹ"))
				ADJdGOPzaeo0rXf2SuKQbcFWqilw.execute(lw2snZ9J0uhLoxypqa(u"ࠩࡓࡖࡆࡍࡍࡂࠢ࡬ࡲࡹ࡫ࡧࡳ࡫ࡷࡽࡤࡩࡨࡦࡥ࡮࠿ࠬᆺ"))
				ADJdGOPzaeo0rXf2SuKQbcFWqilw.execute(nfNTgkiWdUq(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡳࡵࡺࡩ࡮࡫ࡽࡩࡀ࠭ᆻ"))
				ADJdGOPzaeo0rXf2SuKQbcFWqilw.execute(PPxYugzLZwHX23yiK(u"࡛ࠫࡇࡃࡖࡗࡐ࠿ࠬᆼ"))
				Ccemh2nAvQ.commit()
				Ccemh2nAvQ.close()
		if showDialogs: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠬะๅหࠢห๊ัออࠡ฻่่๏ฯࠠฦื็หา่ࠦห่฻๎ๆࠦฬๆ์฼ࠤ็๎วฺัࠣห้ฮ๊ศ่สฮࠥ๎วๅๅสุࠥอไๆีอาิ๋ษࠡใํࠤฬ๊ศา่ส้ั࠭ᆽ"))
	return
def RUEwdIv5WrlKDFhTBe(V9Lm1n23OjyfK,aaKCjS7AfVx,showDialogs):
	if V9Lm1n23OjyfK!=jKqWB2QMYJO8vTh0o6CVIyamw:
		if V9Lm1n23OjyfK==v8gG4ThP7CAMWEm6fp: Nzp9Fq5cTr.ALLOW_DNS_FIX = S5MWhgtZ37Xw
		elif V9Lm1n23OjyfK==oZqKcvlJx1pTLN2ske5f0PtVrw: Nzp9Fq5cTr.ALLOW_DNS_FIX = FFKncZx5pDTwdiJRYhMgQSNL
		elif V9Lm1n23OjyfK==GGlX1Dsd3bJKMFw: Nzp9Fq5cTr.ALLOW_DNS_FIX = S5MWhgtZ37Xw
	if aaKCjS7AfVx!=jKqWB2QMYJO8vTh0o6CVIyamw:
		if aaKCjS7AfVx==v8gG4ThP7CAMWEm6fp: Nzp9Fq5cTr.ALLOW_PROXY_FIX = S5MWhgtZ37Xw
		elif aaKCjS7AfVx==oZqKcvlJx1pTLN2ske5f0PtVrw: Nzp9Fq5cTr.ALLOW_PROXY_FIX = FFKncZx5pDTwdiJRYhMgQSNL
		elif aaKCjS7AfVx==GGlX1Dsd3bJKMFw: Nzp9Fq5cTr.ALLOW_PROXY_FIX = S5MWhgtZ37Xw
	if showDialogs!=jKqWB2QMYJO8vTh0o6CVIyamw:
		if showDialogs==v8gG4ThP7CAMWEm6fp: Nzp9Fq5cTr.ALLOW_SHOWDIALOGS_FIX = S5MWhgtZ37Xw
		elif showDialogs==oZqKcvlJx1pTLN2ske5f0PtVrw: Nzp9Fq5cTr.ALLOW_SHOWDIALOGS_FIX = FFKncZx5pDTwdiJRYhMgQSNL
		elif showDialogs==GGlX1Dsd3bJKMFw: Nzp9Fq5cTr.ALLOW_SHOWDIALOGS_FIX = S5MWhgtZ37Xw
	return
def qqjpboa6YLRKsZeIC90D(website,q6NEO3atUSGTkC7,yogsqk8EzQFwR=YWylfpKSRb):
	axyi1hTubkt35B47RL9XNUmF = bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠳࠳ᑅ")
	gSpjryMZkBx8Tcz7Y0vN3lsq9Au = [Pj9YaUq1ibJ(u"࠴ᑆ"),Pj9YaUq1ibJ(u"࠴ᑆ"),Pj9YaUq1ibJ(u"࠴ᑆ"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠵࠵ᑇ"),ZjELJ9VrUT07R8Hn4FuSDcf(u"࠺ᑈ"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠵࠵ᑇ"),Pj9YaUq1ibJ(u"࠴ᑆ"),Pj9YaUq1ibJ(u"࠴ᑆ"),Pj9YaUq1ibJ(u"࠴ᑆ"),ZjELJ9VrUT07R8Hn4FuSDcf(u"࠺ᑈ")]
	IIYGf5k6xLWdi8PjD = []
	H74sUdFJiBp52ax9L1wA = [Qy6wlfLoOpg1(u"࠶ᑉ")]*axyi1hTubkt35B47RL9XNUmF
	tMJPCB1nluys2ROpwdHvfWo54Xrih = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,zhE5I4xHinX0UoVZMNwlkPrR(u"࠭ࡤࡪࡥࡷࠫᆾ"),AJHaiQq3PRd5cphzGuELnVg9X(u"ࠧࡔࡅࡕࡅࡕࡋࡒࡔࡡࡖࡘࡆ࡚ࡕࡔࠩᆿ"))
	for cSiv4Iz0tWV3nFC1 in list(tMJPCB1nluys2ROpwdHvfWo54Xrih.keys()):
		if website not in cSiv4Iz0tWV3nFC1: continue
		whXU4NCbPdFAcxErVJIutR8WDM3n,kTKbsGrWQwFRJEUZH59Ncu38pyn7vx = cSiv4Iz0tWV3nFC1.split(pxt6wJ8ScYMWCivoO(u"ࠨࡡࡢࠫᇀ"))
		H74sUdFJiBp52ax9L1wA[int(kTKbsGrWQwFRJEUZH59Ncu38pyn7vx)] = tMJPCB1nluys2ROpwdHvfWo54Xrih[cSiv4Iz0tWV3nFC1]
	for UGLpqfbPAkQJD in range(axyi1hTubkt35B47RL9XNUmF):
		if UGLpqfbPAkQJD in Nzp9Fq5cTr.BADSCRAPERS+q6NEO3atUSGTkC7: continue
		if UGLpqfbPAkQJD==yogsqk8EzQFwR: H74sUdFJiBp52ax9L1wA[UGLpqfbPAkQJD] = H74sUdFJiBp52ax9L1wA[UGLpqfbPAkQJD]+LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠱ᑊ")
		if H74sUdFJiBp52ax9L1wA[UGLpqfbPAkQJD]<Pj9YaUq1ibJ(u"࠴ᑋ"): IIYGf5k6xLWdi8PjD += [UGLpqfbPAkQJD]*gSpjryMZkBx8Tcz7Y0vN3lsq9Au[UGLpqfbPAkQJD]
	if not IIYGf5k6xLWdi8PjD:
		for UGLpqfbPAkQJD in range(axyi1hTubkt35B47RL9XNUmF):
			H74sUdFJiBp52ax9L1wA[UGLpqfbPAkQJD] = HD7MQqXd2gS(u"࠲ᑌ")
			if UGLpqfbPAkQJD in Nzp9Fq5cTr.BADSCRAPERS+q6NEO3atUSGTkC7: continue
			IIYGf5k6xLWdi8PjD += [UGLpqfbPAkQJD]*gSpjryMZkBx8Tcz7Y0vN3lsq9Au[UGLpqfbPAkQJD]
	for UGLpqfbPAkQJD in Nzp9Fq5cTr.BADSCRAPERS: H74sUdFJiBp52ax9L1wA[UGLpqfbPAkQJD] = YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠼࠽࠾࠿ᑍ")
	OOnL0uM4GvA7EeIQS5XU = []
	for UGLpqfbPAkQJD in range(axyi1hTubkt35B47RL9XNUmF): OOnL0uM4GvA7EeIQS5XU.append(website+Qy6wlfLoOpg1(u"ࠩࡢࡣࠬᇁ")+str(UGLpqfbPAkQJD))
	WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,XEcWOIwkZKubV7vQ(u"ࠪࡗࡈࡘࡁࡑࡇࡕࡗࡤ࡙ࡔࡂࡖࡘࡗࠬᇂ"),OOnL0uM4GvA7EeIQS5XU,H74sUdFJiBp52ax9L1wA,rzCHwYijmSR4JW*Qy6wlfLoOpg1(u"࠹ᑎ"),S5MWhgtZ37Xw)
	return IIYGf5k6xLWdi8PjD
def U4wtdoh6sePSauql5RjJ9BOCXpNn(QNwj4Toh3Vk60rfeGyY,KteRnFMjHpBPqNf8,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,tZMRykpjCAse,NNIGPDvUJABZoTba,FjO41UWNvs0Gg,wwzCYnRmoFcxMIHAfB8kiJLOG=nA5dhMRg6ENzsB0l1GwvH7aIr2,YZAKaSrmp57OUEtIXcyv3hoe8RVqWG=nA5dhMRg6ENzsB0l1GwvH7aIr2,q6NEO3atUSGTkC7=[]):
	website = FjO41UWNvs0Gg.split(ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠫ࠲࠭ᇃ"))[IpFcwrWNgefMym3qta0hYQAzOdE]
	Prj4muZgRx5Sq = qqjpboa6YLRKsZeIC90D(website,q6NEO3atUSGTkC7)
	o5tUrNCbpVMPm6F = []
	if website==JvQd6LMoBX4hiy1C(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧᇄ"):
		if IpFcwrWNgefMym3qta0hYQAzOdE in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [IpFcwrWNgefMym3qta0hYQAzOdE]
		if UnOIK1WBbw2 in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [UnOIK1WBbw2]
		if udq5tP0hwifHQCGYELDbOUI in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [udq5tP0hwifHQCGYELDbOUI]
		if AH0zdvBqibaXY in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [AH0zdvBqibaXY]*YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠶࠶ᑏ")
		if tpMX1Bgs0bzv8OEafyW in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [tpMX1Bgs0bzv8OEafyW]*eCaWsMty53QI9Y
		if eCaWsMty53QI9Y in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [eCaWsMty53QI9Y]*bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠷࠰ᑐ")
		if ldIfvn6asURQ9toi85EhqAXW3(u"࠶ᑑ") in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [ldIfvn6asURQ9toi85EhqAXW3(u"࠶ᑑ")]
		if zhE5I4xHinX0UoVZMNwlkPrR(u"࠸ᑒ") in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [zhE5I4xHinX0UoVZMNwlkPrR(u"࠸ᑒ")]
	elif website==ldIfvn6asURQ9toi85EhqAXW3(u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨᇅ"):
		if AH0zdvBqibaXY in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [AH0zdvBqibaXY]*jil8vRpBsENVYyPmDd(u"࠳࠳ᑓ")
	elif website==Pj9YaUq1ibJ(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪᇆ"):
		if tpMX1Bgs0bzv8OEafyW in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [tpMX1Bgs0bzv8OEafyW]*eCaWsMty53QI9Y
		if eCaWsMty53QI9Y in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [eCaWsMty53QI9Y]*nfNTgkiWdUq(u"࠴࠴ᑔ")
	elif website==zhE5I4xHinX0UoVZMNwlkPrR(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠲ࠩᇇ"):
		if bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠽ᑕ") in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠽ᑕ")]*n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠶࠶ᑖ")
	elif website==baBcNd81eH5ry2Olp6Mj43(u"࡚ࠩࡉࡈࡏࡍࡂ࠴ࠪᇈ"):
		if UnOIK1WBbw2 in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [UnOIK1WBbw2]
		if eCaWsMty53QI9Y in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [eCaWsMty53QI9Y]*yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠷࠰ᑗ")
	elif website==Qy6wlfLoOpg1(u"ࠪࡋࡔࡕࡇࡍࡇࡖࡉࡆࡘࡃࡉࠩᇉ"):
		if tpMX1Bgs0bzv8OEafyW in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [tpMX1Bgs0bzv8OEafyW]*eCaWsMty53QI9Y
	elif website==xwIUQfiE7rmvYzH(u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬᇊ"):
		if eCaWsMty53QI9Y in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [eCaWsMty53QI9Y]*mRanX1HZupfSQVB2gsDGUO(u"࠱࠱ᑘ")
		if n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠷ᑙ") in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠷ᑙ")]
		if lw2snZ9J0uhLoxypqa(u"࠹ᑚ") in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [lw2snZ9J0uhLoxypqa(u"࠹ᑚ")]
		if rCmGE4YIDaZA(u"࠻ᑛ") in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [rCmGE4YIDaZA(u"࠻ᑛ")]
	elif website==ldIfvn6asURQ9toi85EhqAXW3(u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧᇋ"):
		if Yj1msqVeivESfrCupRy9b7WacBd(u"࠺ᑜ") in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [Yj1msqVeivESfrCupRy9b7WacBd(u"࠺ᑜ")]
		if VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠼ᑝ") in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠼ᑝ")]
	elif website==Qy6wlfLoOpg1(u"࠭ࡃࡊࡏࡄ࡛ࡇࡇࡓࠨᇌ"):
		if UnOIK1WBbw2 in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [UnOIK1WBbw2]
		if tpMX1Bgs0bzv8OEafyW in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [tpMX1Bgs0bzv8OEafyW]*eCaWsMty53QI9Y
		if eCaWsMty53QI9Y in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [eCaWsMty53QI9Y]*UUobzy0xZLaVScIt7(u"࠷࠰ᑞ")
		if ZjELJ9VrUT07R8Hn4FuSDcf(u"࠶ᑟ") in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [ZjELJ9VrUT07R8Hn4FuSDcf(u"࠶ᑟ")]
		if PPxYugzLZwHX23yiK(u"࠸ᑠ") in Prj4muZgRx5Sq: o5tUrNCbpVMPm6F += [PPxYugzLZwHX23yiK(u"࠸ᑠ")]
	if o5tUrNCbpVMPm6F: Prj4muZgRx5Sq = o5tUrNCbpVMPm6F
	if Prj4muZgRx5Sq:
		Tj6Swc5QdUzRGXkMp1ZHP2yfh = avZmSHVO7swUYFnTu5p9iNR8g.sample(Prj4muZgRx5Sq,UnOIK1WBbw2)[IpFcwrWNgefMym3qta0hYQAzOdE]
	else: Tj6Swc5QdUzRGXkMp1ZHP2yfh = -UnOIK1WBbw2
	vC9r5kQ6LRVOAqMfKJuD = yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠧิ์ิๅึࠦัใ็ࠣࠫᇍ")+str(Tj6Swc5QdUzRGXkMp1ZHP2yfh)
	nhR0UxwS4yDiABj7V1G8la(hhOuTCDWIJe7SQPrcKVgF8ZN1qYEz,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+PPxYugzLZwHX23yiK(u"ࠨࠢࠣࠤ࡙ࡸࡹࡪࡰࡪࠤࡧࡿࡰࡢࡵࡶࠤࡧࡲ࡯ࡤ࡭࡬ࡲ࡬ࠦࠠࠡࡕࡨࡶࡻ࡫ࡲ࠻ࠢ࡞ࠤࠬᇎ")+str(Tj6Swc5QdUzRGXkMp1ZHP2yfh)+Pj9YaUq1ibJ(u"ࠩࠣࡡࠥࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩᇏ")+str(wwzCYnRmoFcxMIHAfB8kiJLOG)+nfNTgkiWdUq(u"ࠪࠤࡢࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫᇐ")+YZAKaSrmp57OUEtIXcyv3hoe8RVqWG+DFx6E0uON7Jm8(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ᇑ")+FjO41UWNvs0Gg+YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠬࠦ࡝ࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᇒ")+KteRnFMjHpBPqNf8+HD7MQqXd2gS(u"࠭ࠠ࡞ࠩᇓ"))
	update = S5MWhgtZ37Xw
	if Tj6Swc5QdUzRGXkMp1ZHP2yfh==IpFcwrWNgefMym3qta0hYQAzOdE:
		scraperserver = n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠧࡴࡥࡵࡥࡵ࡫࡯ࡱࡵ࠴ࠫᇔ")
		SjMJqei1oVtxO9NWmbdh5 = mRanX1HZupfSQVB2gsDGUO(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡦࡶࡦࡶࡥࡰࡲࡶ࠲ࡰ࡫ࡥࡱࡡ࡫ࡩࡦࡪࡥࡳࡵࡀࡘࡷࡻࡥ࠯ࡥࡲࡹࡳࡺࡲࡺ࠿࡬ࡰ࠿࠷࠵࠱ࡦ࠵࠶࡫࠷࠭ࡤ࠷࠻ࡥ࠲࠺࠰࠳࠳࠰ࡥࡦ࠾࠴࠮ࡧ࠼࠶࠸ࡩࡡࡧ࠺࠸࠼࠸࠺ࡀࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴࡪࡵࡰࡴ࠰࡬ࡳ࠿࠻࠳࠶࠵ࠪᇕ")
		mN3xi4TLMadDl10VHhOAbrXKjZB = KteRnFMjHpBPqNf8+mRanX1HZupfSQVB2gsDGUO(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩᇖ")+SjMJqei1oVtxO9NWmbdh5+zhE5I4xHinX0UoVZMNwlkPrR(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪᇗ")
		qqQUL1k7bGnjc = p3LnaOYNwmCP8fic(QNwj4Toh3Vk60rfeGyY,mN3xi4TLMadDl10VHhOAbrXKjZB,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,tZMRykpjCAse,NNIGPDvUJABZoTba,FjO41UWNvs0Gg,FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL)
	elif Tj6Swc5QdUzRGXkMp1ZHP2yfh==UnOIK1WBbw2:
		scraperserver = LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠫࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠲ࠨᇘ")
		SjMJqei1oVtxO9NWmbdh5 = XEcWOIwkZKubV7vQ(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠯࡭ࡨࡩࡵࡥࡨࡦࡣࡧࡩࡷࡹ࠽ࡕࡴࡸࡩ࠳ࡩ࡯ࡶࡰࡷࡶࡾࡃࡩ࡭࠼࠶࠽࠾࠷ࡥ࠺ࡥ࠸࠱࠼࡫ࡥ࠴࠯࠷ࡩࡪ࠸࠭࠹࠶ࡦ࠴࠲࡬ࡤ࠸࠻࠵ࡦࡦࡪࡤ࠴ࡦ࠸ࡄࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱࡧࡲࡴࡸ࠴ࡩࡰ࠼࠸࠷࠺࠹ࠧᇙ")
		mN3xi4TLMadDl10VHhOAbrXKjZB = KteRnFMjHpBPqNf8+bb1fgjsAq4N2xYwnoh39lm(u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭ᇚ")+SjMJqei1oVtxO9NWmbdh5+HD7MQqXd2gS(u"ࠧࡽࡾࡑࡳ࡛࡫ࡲࡪࡨࡼࡗࡘࡒࠧᇛ")
		qqQUL1k7bGnjc = p3LnaOYNwmCP8fic(QNwj4Toh3Vk60rfeGyY,mN3xi4TLMadDl10VHhOAbrXKjZB,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,tZMRykpjCAse,NNIGPDvUJABZoTba,FjO41UWNvs0Gg,FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL)
	elif Tj6Swc5QdUzRGXkMp1ZHP2yfh==udq5tP0hwifHQCGYELDbOUI:
		scraperserver = jil8vRpBsENVYyPmDd(u"ࠨࡵࡦࡶࡦࡶࡥࡳࡣࡳ࡭ࠬᇜ")
		SjMJqei1oVtxO9NWmbdh5 = lw2snZ9J0uhLoxypqa(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡧࡷࡧࡰࡦࡴࡤࡴ࡮࠴࡫ࡦࡧࡳࡣ࡭࡫ࡡࡥࡧࡵࡷࡂ࡚ࡲࡶࡧ࠱ࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦ࠿࡬ࡰ࠿࠽࠶ࡣ࠶ࡩࡧ࠸࠺ࡦࡤࡦ࠴࠽ࡩ࠿ࡣ࠶࠷ࡤ࠵࠺࡬࠳࠷࠲࠷ࡧࡩ࠿࠱࠵ࡥࡃࡴࡷࡵࡸࡺ࠯ࡶࡩࡷࡼࡥࡳ࠰ࡶࡧࡷࡧࡰࡦࡴࡤࡴ࡮࠴ࡣࡰ࡯࠽࠼࠵࠶࠱ࠨᇝ")
		mN3xi4TLMadDl10VHhOAbrXKjZB = KteRnFMjHpBPqNf8+ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪᇞ")+SjMJqei1oVtxO9NWmbdh5+Yj1msqVeivESfrCupRy9b7WacBd(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫᇟ")
		qqQUL1k7bGnjc = p3LnaOYNwmCP8fic(QNwj4Toh3Vk60rfeGyY,mN3xi4TLMadDl10VHhOAbrXKjZB,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,tZMRykpjCAse,NNIGPDvUJABZoTba,FjO41UWNvs0Gg,FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL)
	elif Tj6Swc5QdUzRGXkMp1ZHP2yfh==AH0zdvBqibaXY:
		scraperserver = ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠬࡹࡣࡳࡣࡳࡩࡺࡶࠧᇠ")
		w7Ol6FnokgJDSsIt = KteRnFMjHpBPqNf8.replace(bb1fgjsAq4N2xYwnoh39lm(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࠨᇡ"),FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨᇢ"))
		mN3xi4TLMadDl10VHhOAbrXKjZB = rCmGE4YIDaZA(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡣࡳ࡭࠳ࡹࡣࡳࡣࡳࡩࡺࡶ࠮ࡤࡱࡰ࠳ࡄࡧࡰࡪࡡ࡮ࡩࡾࡃ࠱ࡗࡐࡶࡑࡹࡒ࠱ࡰࡄࡕ࡜ࡰ࡙ࡎࡄࡤࡆࡑࡏ࠷ࡋ࡙࡛ࡍ࡮࡯࠶ࡤ࡫࡜ࡺࠪࡰ࡫ࡥࡱࡡ࡫ࡩࡦࡪࡥࡳࡵࡀࡊࡦࡲࡳࡦࠨࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥ࠾࡫࡯ࠪࡺࡸ࡬࠾ࠩᇣ")+kGE6zoKSan54W(w7Ol6FnokgJDSsIt)
		qqQUL1k7bGnjc = p3LnaOYNwmCP8fic(UUobzy0xZLaVScIt7(u"ࠩࡊࡉ࡙࠭ᇤ"),mN3xi4TLMadDl10VHhOAbrXKjZB,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,tZMRykpjCAse,NNIGPDvUJABZoTba,FjO41UWNvs0Gg,FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL)
	elif Tj6Swc5QdUzRGXkMp1ZHP2yfh==tpMX1Bgs0bzv8OEafyW:
		scraperserver = bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠪࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡷࡵࡢࡰࡶࠪᇥ")
		mN3xi4TLMadDl10VHhOAbrXKjZB = VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡶࡩ࠯ࡵࡦࡶࡦࡶࡩ࡯ࡩࡵࡳࡧࡵࡴ࠯ࡥࡲࡱ࠴ࡅࡴࡰ࡭ࡨࡲࡂࡧ࠴ࡧ࠹ࡩࡦ࠶࠺࠭࠳ࡦࡨࡪ࠲࠺࠰࠸࠳࠰࠼࠻࠺ࡢ࠮࠴࠵ࡩ࠸࠸࠶࠵ࡦ࠷ࡨࡩࡩࠦࡱࡴࡲࡼࡾࡉ࡯ࡶࡰࡷࡶࡾࡃࡉࡍࠨࡸࡶࡱࡃࠧᇦ")+kGE6zoKSan54W(KteRnFMjHpBPqNf8)
		qqQUL1k7bGnjc = p3LnaOYNwmCP8fic(JvQd6LMoBX4hiy1C(u"ࠬࡍࡅࡕࠩᇧ"),mN3xi4TLMadDl10VHhOAbrXKjZB,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,tZMRykpjCAse,NNIGPDvUJABZoTba,FjO41UWNvs0Gg,FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL)
		try:
			qqQUL1k7bGnjc.content = BwGPDSQOlfUas2n3eIH0ycFRWZ(Yj1msqVeivESfrCupRy9b7WacBd(u"࠭ࡤࡪࡥࡷࠫᇨ"),qqQUL1k7bGnjc.content)
			qqQUL1k7bGnjc.content = qqQUL1k7bGnjc.content[XEcWOIwkZKubV7vQ(u"ࠧࡳࡧࡶࡹࡱࡺࠧᇩ")]
		except: pass
	elif Tj6Swc5QdUzRGXkMp1ZHP2yfh==eCaWsMty53QI9Y:
		scraperserver = nfNTgkiWdUq(u"ࠨࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹ࠷ࠧᇪ")
		SjMJqei1oVtxO9NWmbdh5 = n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡧࡷࡧࡰࡪࡰࡪࡥࡳࡺࠦࡱࡴࡲࡼࡾࡥࡣࡰࡷࡱࡸࡷࡿ࠽ࡊࡎࠩࡦࡷࡵࡷࡴࡧࡵࡁࡋࡧ࡬ࡴࡧࠩࡪࡴࡸࡷࡢࡴࡧࡣ࡭࡫ࡡࡥࡧࡵࡷࡂ࡚ࡲࡶࡧ࠽࠶ࡧ࠹࠴࠱ࡣ࠹࠼࠾࠶ࡡ࠶࠶࠳࠵ࡩࡨࡣ࠴࠹࠵ࡧ࠶࠷࠴࠶ࡦ࠼࠺࠷࡫࠸ࡁࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡯࡮ࡨࡣࡱࡸ࠳ࡩ࡯࡮࠼࠻࠴࠽࠶ࠧᇫ")
		mN3xi4TLMadDl10VHhOAbrXKjZB = KteRnFMjHpBPqNf8+UUobzy0xZLaVScIt7(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪᇬ")+SjMJqei1oVtxO9NWmbdh5+VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫᇭ")
		qqQUL1k7bGnjc = p3LnaOYNwmCP8fic(QNwj4Toh3Vk60rfeGyY,mN3xi4TLMadDl10VHhOAbrXKjZB,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,tZMRykpjCAse,NNIGPDvUJABZoTba,FjO41UWNvs0Gg,FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL)
	elif Tj6Swc5QdUzRGXkMp1ZHP2yfh==zhE5I4xHinX0UoVZMNwlkPrR(u"࠸ᑡ"):
		scraperserver = VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠬࡹࡣࡳࡣࡳࡩ࠳ࡪ࡯࠲ࠩᇮ")
		SjMJqei1oVtxO9NWmbdh5 = Pj9YaUq1ibJ(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡣࡤ࠴࠹࠷ࡦࡨ࠱ࡦ࠷࠳࠸࠹ࡪ࠲ࡤࡣ࠸ࡨ࠺ࡪ࠳ࡧ࠻ࡨ࠷ࡨ࠹࠸࠷ࡧࡦࡥ࠶࠷࠰࠹࠵࠻࠽ࡦ࠽࠳࠻ࡥࡸࡷࡹࡵ࡭ࡉࡧࡤࡨࡪࡸࡳ࠾ࡖࡵࡹࡪࠬࡧࡦࡱࡆࡳࡩ࡫࠽ࡪ࡮ࡃࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡦ࠰ࡧࡳ࠿࠾࠰࠹࠲ࠪᇯ")
		mN3xi4TLMadDl10VHhOAbrXKjZB = KteRnFMjHpBPqNf8+rCmGE4YIDaZA(u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧᇰ")+SjMJqei1oVtxO9NWmbdh5+vzqjsVHSBlMpxC(u"ࠨࡾࡿࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨᇱ")
		qqQUL1k7bGnjc = p3LnaOYNwmCP8fic(QNwj4Toh3Vk60rfeGyY,mN3xi4TLMadDl10VHhOAbrXKjZB,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,tZMRykpjCAse,NNIGPDvUJABZoTba,FjO41UWNvs0Gg,FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL)
	elif Tj6Swc5QdUzRGXkMp1ZHP2yfh==jil8vRpBsENVYyPmDd(u"࠺ᑢ"):
		scraperserver = vzqjsVHSBlMpxC(u"ࠩࡶࡧࡷࡧࡰࡦ࠰ࡧࡳ࠷࠭ᇲ")
		SjMJqei1oVtxO9NWmbdh5 = ldIfvn6asURQ9toi85EhqAXW3(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵ࡨ࠹ࡤ࠴ࡣࡨ࠵࠽࠻ࡤࡧ࠶ࡥࡪ࠻ࡧࡦ࠶࠵࠶ࡧ࠼࠶࠴࠱ࡤ࠶࠸࠼ࡩ࠹ࡦ࠻࠼ࡦࡪ࠺࠶࠷ࡣࡨ࠽࠿ࡩࡵࡴࡶࡲࡱࡍ࡫ࡡࡥࡧࡵࡷࡂ࡚ࡲࡶࡧࠩ࡫ࡪࡵࡃࡰࡦࡨࡁ࡮ࡲࡀࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴࡪ࠴ࡤࡰ࠼࠻࠴࠽࠶ࠧᇳ")
		mN3xi4TLMadDl10VHhOAbrXKjZB = KteRnFMjHpBPqNf8+mRanX1HZupfSQVB2gsDGUO(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫᇴ")+SjMJqei1oVtxO9NWmbdh5+nfNTgkiWdUq(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬᇵ")
		qqQUL1k7bGnjc = p3LnaOYNwmCP8fic(QNwj4Toh3Vk60rfeGyY,mN3xi4TLMadDl10VHhOAbrXKjZB,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,tZMRykpjCAse,NNIGPDvUJABZoTba,FjO41UWNvs0Gg,FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL)
	elif Tj6Swc5QdUzRGXkMp1ZHP2yfh==zhE5I4xHinX0UoVZMNwlkPrR(u"࠼ᑣ"):
		scraperserver = bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠭ࡳࡤࡴࡤࡴࡪࡵࡰࡴ࠵ࠪᇶ")
		mN3xi4TLMadDl10VHhOAbrXKjZB = FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫࡯ࡱࡵ࠱࡭ࡴ࠵ࡶ࠲࠱ࡂࡥࡵ࡯࡟࡬ࡧࡼࡁ࠸࠿࠹࠲ࡧ࠼ࡧ࠺࠳࠷ࡦࡧ࠶࠱࠹࡫ࡥ࠳࠯࠻࠸ࡨ࠶࠭ࡧࡦ࠺࠽࠷ࡨࡡࡥࡦ࠶ࡨ࠺ࠬࡣࡰࡷࡱࡸࡷࡿ࠽ࡪ࡮ࠩࡹࡷࡲ࠽ࠨᇷ")+kGE6zoKSan54W(KteRnFMjHpBPqNf8)
		qqQUL1k7bGnjc = p3LnaOYNwmCP8fic(baBcNd81eH5ry2Olp6Mj43(u"ࠨࡉࡈࡘࠬᇸ"),mN3xi4TLMadDl10VHhOAbrXKjZB,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,tZMRykpjCAse,NNIGPDvUJABZoTba,FjO41UWNvs0Gg,FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL)
	elif Tj6Swc5QdUzRGXkMp1ZHP2yfh==Qy6wlfLoOpg1(u"࠾ᑤ"):
		scraperserver = w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠩࡶࡧࡷࡧࡰࡪࡰࡪࡥࡳࡺ࠲ࠨᇹ")
		SjMJqei1oVtxO9NWmbdh5 = zhE5I4xHinX0UoVZMNwlkPrR(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡦࡴࡴࠧࡲࡵࡳࡽࡿ࡟ࡤࡱࡸࡲࡹࡸࡹ࠾ࡃࡈࠪࡷ࡫ࡴࡶࡴࡱࡣࡵࡧࡧࡦࡡࡶࡳࡺࡸࡣࡦ࠿ࡷࡶࡺ࡫ࠦࡧࡱࡵࡻࡦࡸࡤࡠࡪࡨࡥࡩ࡫ࡲࡴ࠿ࡷࡶࡺ࡫࠺࠳ࡤ࠶࠸࠵ࡧ࠶࠹࠻࠳ࡥ࠺࠺࠰࠲ࡦࡥࡧ࠸࠽࠲ࡤ࠳࠴࠸࠺ࡪ࠹࠷࠴ࡨ࠼ࡅࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡧ࡮ࡵ࠰ࡦࡳࡲࡀ࠸࠱࠺࠳ࠫᇺ")
		mN3xi4TLMadDl10VHhOAbrXKjZB = KteRnFMjHpBPqNf8+YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫᇻ")+SjMJqei1oVtxO9NWmbdh5+nfNTgkiWdUq(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬᇼ")
		qqQUL1k7bGnjc = p3LnaOYNwmCP8fic(QNwj4Toh3Vk60rfeGyY,mN3xi4TLMadDl10VHhOAbrXKjZB,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,tZMRykpjCAse,NNIGPDvUJABZoTba,FjO41UWNvs0Gg,FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL)
	else:
		scraperserver,mN3xi4TLMadDl10VHhOAbrXKjZB = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
		qqQUL1k7bGnjc = aIh6GTlW0973UgY()
		update = FFKncZx5pDTwdiJRYhMgQSNL
	lCx3tZon1aLgc7IMwS4BKHOe = (nfNTgkiWdUq(u"࠭ࡶࡦࡴ࡬ࡪࡾ࠴ࡨࡵ࡯࡯ࡃࡷ࡫ࡤࡪࡴࡨࡧࡹࡃࠧᇽ") in KteRnFMjHpBPqNf8)
	if lCx3tZon1aLgc7IMwS4BKHOe: qqQUL1k7bGnjc.succeeded = FFKncZx5pDTwdiJRYhMgQSNL
	if update and not qqQUL1k7bGnjc.succeeded:
		qqjpboa6YLRKsZeIC90D(website,[],Tj6Swc5QdUzRGXkMp1ZHP2yfh)
		if len(list(set(Prj4muZgRx5Sq)))>UnOIK1WBbw2:
			x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,JvQd6LMoBX4hiy1C(u"ࠧๅๆฦืๆࠦำ๋ำไีู๋ࠥศๆฯอࠥอไฮฮหࠤึ่ๅࠡࠩᇾ")+str(Tj6Swc5QdUzRGXkMp1ZHP2yfh)+zhE5I4xHinX0UoVZMNwlkPrR(u"ࠨࠢไุ้ࠦแ๋ࠢ฼้้๐ษࠡฬฯหํุࠠศๆะะอࠦ࠮࠯๊่ࠢࠥะั๋ั้ࠣาอ่ๅหࠣฮัอ่ำࠢส่าาศࠡ็ิอࠥษฮา๋ࠣฬฬูสฯัสู้๊ࠥาใิࠤ๊ิสๅใࠣรࠦ࠭ᇿ"))
			if x6zlf2tTZm==UnOIK1WBbw2:
				q6NEO3atUSGTkC7.append(Tj6Swc5QdUzRGXkMp1ZHP2yfh)
				qqQUL1k7bGnjc = U4wtdoh6sePSauql5RjJ9BOCXpNn(QNwj4Toh3Vk60rfeGyY,KteRnFMjHpBPqNf8,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,tZMRykpjCAse,NNIGPDvUJABZoTba,FjO41UWNvs0Gg,wwzCYnRmoFcxMIHAfB8kiJLOG,YZAKaSrmp57OUEtIXcyv3hoe8RVqWG,q6NEO3atUSGTkC7)
				return qqQUL1k7bGnjc
	qqQUL1k7bGnjc.scrapernumber = str(Tj6Swc5QdUzRGXkMp1ZHP2yfh)
	scraperserver = scraperserver+JvQd6LMoBX4hiy1C(u"ࠩࠣ࠾ࠥ࠭ሀ")+str(Tj6Swc5QdUzRGXkMp1ZHP2yfh)
	qqQUL1k7bGnjc.scraperserver = scraperserver
	qqQUL1k7bGnjc.scraperurl = mN3xi4TLMadDl10VHhOAbrXKjZB
	if qqQUL1k7bGnjc.succeeded:
		nhR0UxwS4yDiABj7V1G8la(hhOuTCDWIJe7SQPrcKVgF8ZN1qYEz,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+baBcNd81eH5ry2Olp6Mj43(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡪࡪࡥࡥࠢࡥࡽࡵࡧࡳࡴࠢࡥࡰࡴࡩ࡫ࡪࡰࡪࠤࠥࠦࡓࡦࡴࡹࡩࡷࡀࠠ࡜ࠢࠪሁ")+scraperserver+mRanX1HZupfSQVB2gsDGUO(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ሂ")+FjO41UWNvs0Gg+pxt6wJ8ScYMWCivoO(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫሃ")+KteRnFMjHpBPqNf8+pxt6wJ8ScYMWCivoO(u"࠭ࠠ࡞ࠩሄ"))
		ggYilKR5rMDyp7B(gmPI7hVEM8nD(u"ࠧ็ฮะฮࠥ฿ๅๅ์ฬࠤฯาว้ิࠣห้ำฬษࠩህ"),vC9r5kQ6LRVOAqMfKJuD,h0skHe7TcIY9x1UP5VBrZAE8dKGnl=pxt6wJ8ScYMWCivoO(u"࠷࠰࠱࠲ᑥ"))
	else:
		nhR0UxwS4yDiABj7V1G8la(ybrna7mLOFVDUtRseQ3Tkf2zXS,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+zhE5I4xHinX0UoVZMNwlkPrR(u"ࠨࠢࠣࠤࡋࡧࡩ࡭ࡧࡧࠤࡧࡿࡰࡢࡵࡶࠤࡧࡲ࡯ࡤ࡭࡬ࡲ࡬ࠦࠠࠡࡕࡨࡶࡻ࡫ࡲ࠻ࠢ࡞ࠤࠬሆ")+scraperserver+mRanX1HZupfSQVB2gsDGUO(u"ࠩࠣࡡࠥࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩሇ")+str(qqQUL1k7bGnjc.code)+bb1fgjsAq4N2xYwnoh39lm(u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬለ")+qqQUL1k7bGnjc.reason+yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ሉ")+FjO41UWNvs0Gg+HD7MQqXd2gS(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫሊ")+KteRnFMjHpBPqNf8+FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠭ࠠ࡞ࠩላ"))
		ggYilKR5rMDyp7B(Pj9YaUq1ibJ(u"ࠧโึ็ฮࠥ฿ๅๅ์ฬࠤฯาว้ิࠣห้ำฬษࠩሌ"),vC9r5kQ6LRVOAqMfKJuD,h0skHe7TcIY9x1UP5VBrZAE8dKGnl=ldIfvn6asURQ9toi85EhqAXW3(u"࠱࠱࠲࠳ᑦ"))
	return qqQUL1k7bGnjc
def ckQrBFeAOKz8RxDup3wGmd5SZ(rj2U9E4KbDMOzpkP,RxWJFBAGy4iIM,JEiFBCayPfze7n3KspN6AY,PPblYOcLrJH6QI,showDialogs,FjO41UWNvs0Gg):
	if not JEiFBCayPfze7n3KspN6AY or isinstance(JEiFBCayPfze7n3KspN6AY,dict): QNwj4Toh3Vk60rfeGyY = bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠨࡉࡈࡘࠬል")
	else:
		QNwj4Toh3Vk60rfeGyY = yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠩࡓࡓࡘ࡚ࠧሎ")
		JEiFBCayPfze7n3KspN6AY = pvOytL0nF7JY6flXTxAcHbQeNahu3(JEiFBCayPfze7n3KspN6AY)
		Mz4dDEP8SfhHReoC,JEiFBCayPfze7n3KspN6AY = ss2VIkClmtevKqPUuSx9DGpX(JEiFBCayPfze7n3KspN6AY)
	tkSbvVxf8h1d0gLTci = uANakQHcnhR(rj2U9E4KbDMOzpkP,QNwj4Toh3Vk60rfeGyY,RxWJFBAGy4iIM,JEiFBCayPfze7n3KspN6AY,PPblYOcLrJH6QI,S5MWhgtZ37Xw,showDialogs,FjO41UWNvs0Gg)
	h1hN5GRPeA2YIgmvKax3EMJfu9ilZ = tkSbvVxf8h1d0gLTci.content
	h1hN5GRPeA2YIgmvKax3EMJfu9ilZ = str(h1hN5GRPeA2YIgmvKax3EMJfu9ilZ)
	return h1hN5GRPeA2YIgmvKax3EMJfu9ilZ
def MyP7jWmAVGS8rfN51zdqclDeUs(RxWJFBAGy4iIM):
	Dotv3zc7iEM5A1V = RxWJFBAGy4iIM.split(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠪࢀࢁ࠭ሏ"))
	KteRnFMjHpBPqNf8,DG5rzEqHLYk4vA1g6lfReChnQTWd3,sebNaroikFVY6hHj7dMZQfInty,jwsCEuO791RtU = Dotv3zc7iEM5A1V[IpFcwrWNgefMym3qta0hYQAzOdE],YWylfpKSRb,YWylfpKSRb,S5MWhgtZ37Xw
	for X5lnUjdopBiE in Dotv3zc7iEM5A1V:
		if YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠫࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩሐ") in X5lnUjdopBiE: DG5rzEqHLYk4vA1g6lfReChnQTWd3 = X5lnUjdopBiE[ZjELJ9VrUT07R8Hn4FuSDcf(u"࠲࠳ᑧ"):]
		elif UUobzy0xZLaVScIt7(u"ࠬࡓࡹࡅࡐࡖ࡙ࡷࡲ࠽ࠨሑ") in X5lnUjdopBiE: sebNaroikFVY6hHj7dMZQfInty = X5lnUjdopBiE[zhE5I4xHinX0UoVZMNwlkPrR(u"࠻ᑨ"):]
		elif DFx6E0uON7Jm8(u"࠭ࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫሒ") in X5lnUjdopBiE: jwsCEuO791RtU = FFKncZx5pDTwdiJRYhMgQSNL
	return KteRnFMjHpBPqNf8,DG5rzEqHLYk4vA1g6lfReChnQTWd3,sebNaroikFVY6hHj7dMZQfInty,jwsCEuO791RtU
def K1r6FDIjHbk9ZSO8uc4Ama(rj2U9E4KbDMOzpkP,QNwj4Toh3Vk60rfeGyY,RxWJFBAGy4iIM,l9SK4qU2WahEuAptB53rZsL,IB0Wu9dPaSRHAXnqK,AQil0Ufv25rI9YueJFHC,PPblYOcLrJH6QI=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	TDIENGnVJUwpqC6b = C2gnJ5tXFk9pAL(RxWJFBAGy4iIM,FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠧࡶࡴ࡯ࠫሓ"))
	jjyQ5ePm9EoDVl = KQctJbXeEjDhplqknU3rzi.getSetting(LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࠪሔ")+l9SK4qU2WahEuAptB53rZsL)
	if TDIENGnVJUwpqC6b==jjyQ5ePm9EoDVl: KQctJbXeEjDhplqknU3rzi.setSetting(PPxYugzLZwHX23yiK(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫሕ")+l9SK4qU2WahEuAptB53rZsL,nA5dhMRg6ENzsB0l1GwvH7aIr2)
	if jjyQ5ePm9EoDVl: w7Ol6FnokgJDSsIt = RxWJFBAGy4iIM.replace(TDIENGnVJUwpqC6b,jjyQ5ePm9EoDVl)
	else:
		w7Ol6FnokgJDSsIt = RxWJFBAGy4iIM
		jjyQ5ePm9EoDVl = TDIENGnVJUwpqC6b
	kvste1oOZacAIpb2 = uANakQHcnhR(rj2U9E4KbDMOzpkP,QNwj4Toh3Vk60rfeGyY,w7Ol6FnokgJDSsIt,nA5dhMRg6ENzsB0l1GwvH7aIr2,PPblYOcLrJH6QI,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠵ࡸࡺࠧሖ"))
	h1hN5GRPeA2YIgmvKax3EMJfu9ilZ = kvste1oOZacAIpb2.content
	if BsLJ7p5Av2Vm0SQeCO1o:
		try: h1hN5GRPeA2YIgmvKax3EMJfu9ilZ = h1hN5GRPeA2YIgmvKax3EMJfu9ilZ.decode(YWEQ3Cf8RevpD0m7NjF1,DFx6E0uON7Jm8(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫሗ"))
		except: pass
	if not kvste1oOZacAIpb2.succeeded or AQil0Ufv25rI9YueJFHC not in h1hN5GRPeA2YIgmvKax3EMJfu9ilZ:
		IB0Wu9dPaSRHAXnqK = IB0Wu9dPaSRHAXnqK.replace(hSXlxL9iB05c,jil8vRpBsENVYyPmDd(u"ࠬ࠱ࠧመ"))
		KteRnFMjHpBPqNf8 = Qy6wlfLoOpg1(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠲ࡨࡵ࡭࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡀࠫሙ")+IB0Wu9dPaSRHAXnqK
		LevQwm0pbqP1 = {vzqjsVHSBlMpxC(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫሚ"):nA5dhMRg6ENzsB0l1GwvH7aIr2}
		YakdN895mSD2uXRCBfWspJhIxV3L = uANakQHcnhR(rj2U9E4KbDMOzpkP,QNwj4Toh3Vk60rfeGyY,KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,LevQwm0pbqP1,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,baBcNd81eH5ry2Olp6Mj43(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠴ࡱࡨࠬማ"))
		if YakdN895mSD2uXRCBfWspJhIxV3L.succeeded:
			h1hN5GRPeA2YIgmvKax3EMJfu9ilZ = YakdN895mSD2uXRCBfWspJhIxV3L.content
			if BsLJ7p5Av2Vm0SQeCO1o:
				try: h1hN5GRPeA2YIgmvKax3EMJfu9ilZ = h1hN5GRPeA2YIgmvKax3EMJfu9ilZ.decode(YWEQ3Cf8RevpD0m7NjF1,LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩሜ"))
				except: pass
			HRpMVv1x5ol9gbsnQquj = PAztbuyYo4Kvd.findall(DFx6E0uON7Jm8(u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠵࡜ࡸࠬ࡟ࡃ࠳࠰࠿ࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥࠫም"),h1hN5GRPeA2YIgmvKax3EMJfu9ilZ,PAztbuyYo4Kvd.DOTALL)
			LgADVa82mqJQcCz9p5oFkSB = [jjyQ5ePm9EoDVl]
			z9e8Ybhstl2NoEIOuxwU1TgQ0fyB = [JvQd6LMoBX4hiy1C(u"ࠫࡦࡶ࡫ࠨሞ"),jil8vRpBsENVYyPmDd(u"ࠬ࡭࡯ࡰࡩ࡯ࡩࠬሟ"),ZjELJ9VrUT07R8Hn4FuSDcf(u"࠭ࡴࡸ࡫ࡷࡸࡪࡸࠧሠ"),PPxYugzLZwHX23yiK(u"ࠧࡺࡱࡸࡸࡺࡨࡥࠨሡ"),AJHaiQq3PRd5cphzGuELnVg9X(u"ࠨࡨࡤࡧࡪࡨ࡯ࡰ࡭ࠪሢ"),JvQd6LMoBX4hiy1C(u"ࠩࡳ࡬ࡵ࠭ሣ"),mRanX1HZupfSQVB2gsDGUO(u"ࠪࡥࡹࡲࡡࡲࠩሤ"),xwIUQfiE7rmvYzH(u"ࠫࡸ࡯ࡴࡦ࡫ࡱࡨ࡮ࡩࡥࡴࠩሥ"),AJHaiQq3PRd5cphzGuELnVg9X(u"ࠬࡹࡵࡳ࠰࡯ࡽࠬሦ"),UUobzy0xZLaVScIt7(u"࠭ࡢ࡭ࡱࡪࡷࡵࡵࡴࠨሧ"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠧࡪࡰࡩࡳࡷࡳࡥࡳࠩረ"),zhE5I4xHinX0UoVZMNwlkPrR(u"ࠨࡵ࡬ࡸࡪࡲࡩ࡬ࡧࠪሩ"),Yj1msqVeivESfrCupRy9b7WacBd(u"ࠩ࡬ࡲࡸࡺࡡࡨࡴࡤࡱࠬሪ"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠪࡷࡳࡧࡰࡤࡪࡤࡸࠬራ"),Pj9YaUq1ibJ(u"ࠫ࡭ࡺࡴࡱ࠯ࡨࡵࡺ࡯ࡶࠨሬ"),vzqjsVHSBlMpxC(u"ࠬ࡬ࡡࡴࡧ࡯ࡴࡱࡻࡳࠨር")]
			for MMiCSjBhseZHtNLX in HRpMVv1x5ol9gbsnQquj:
				if any(value in MMiCSjBhseZHtNLX for value in z9e8Ybhstl2NoEIOuxwU1TgQ0fyB): continue
				jjyQ5ePm9EoDVl = C2gnJ5tXFk9pAL(MMiCSjBhseZHtNLX,DFx6E0uON7Jm8(u"࠭ࡵࡳ࡮ࠪሮ"))
				if jjyQ5ePm9EoDVl in LgADVa82mqJQcCz9p5oFkSB: continue
				if len(LgADVa82mqJQcCz9p5oFkSB)==nfNTgkiWdUq(u"࠼ᑩ"):
					nhR0UxwS4yDiABj7V1G8la(ybrna7mLOFVDUtRseQ3Tkf2zXS,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+Yj1msqVeivESfrCupRy9b7WacBd(u"ࠧࠡࠢࠣࡋࡴࡵࡧ࡭ࡧࠣࡨ࡮ࡪࠠ࡯ࡱࡷࠤ࡫࡯࡮ࡥࠢࡤࠤࡳ࡫ࡷࠡࡪࡲࡷࡹࡴࡡ࡮ࡧࠣࠤ࡙ࠥࡩࡵࡧ࠽ࠤࡠࠦࠧሯ")+l9SK4qU2WahEuAptB53rZsL+nfNTgkiWdUq(u"ࠨࠢࡠࠤࠥࡕ࡬ࡥ࠼ࠣ࡟ࠥ࠭ሰ")+TDIENGnVJUwpqC6b+gmPI7hVEM8nD(u"ࠩࠣࡡࠬሱ"))
					KQctJbXeEjDhplqknU3rzi.setSetting(Qy6wlfLoOpg1(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࠬሲ")+l9SK4qU2WahEuAptB53rZsL,nA5dhMRg6ENzsB0l1GwvH7aIr2)
					break
				LgADVa82mqJQcCz9p5oFkSB.append(jjyQ5ePm9EoDVl)
				w7Ol6FnokgJDSsIt = RxWJFBAGy4iIM.replace(TDIENGnVJUwpqC6b,jjyQ5ePm9EoDVl)
				kvste1oOZacAIpb2 = uANakQHcnhR(rj2U9E4KbDMOzpkP,QNwj4Toh3Vk60rfeGyY,w7Ol6FnokgJDSsIt,nA5dhMRg6ENzsB0l1GwvH7aIr2,PPblYOcLrJH6QI,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,rCmGE4YIDaZA(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤࡔࡅࡘࡡࡋࡓࡘ࡚ࡎࡂࡏࡈ࠱࠸ࡸࡤࠨሳ"))
				h1hN5GRPeA2YIgmvKax3EMJfu9ilZ = kvste1oOZacAIpb2.content
				if kvste1oOZacAIpb2.succeeded and AQil0Ufv25rI9YueJFHC in h1hN5GRPeA2YIgmvKax3EMJfu9ilZ:
					nhR0UxwS4yDiABj7V1G8la(hhOuTCDWIJe7SQPrcKVgF8ZN1qYEz,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+AJHaiQq3PRd5cphzGuELnVg9X(u"ࠬࠦࠠࠡࡉࡲࡳ࡬ࡲࡥࠡࡨࡲࡹࡳࡪࠠࡢࠢࡱࡩࡼࠦࡨࡰࡵࡷࡲࡦࡳࡥࠡࠢࠣࡗ࡮ࡺࡥ࠻ࠢ࡞ࠤࠬሴ")+l9SK4qU2WahEuAptB53rZsL+AJHaiQq3PRd5cphzGuELnVg9X(u"࠭ࠠ࡞ࠢࠣࠤࡓ࡫ࡷ࠻ࠢ࡞ࠤࠬስ")+jjyQ5ePm9EoDVl+JvQd6LMoBX4hiy1C(u"ࠧࠡ࡟ࠣࠤࡔࡲࡤ࠻ࠢ࡞ࠤࠬሶ")+TDIENGnVJUwpqC6b+LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠨࠢࡠࠫሷ"))
					KQctJbXeEjDhplqknU3rzi.setSetting(mRanX1HZupfSQVB2gsDGUO(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫሸ")+l9SK4qU2WahEuAptB53rZsL,jjyQ5ePm9EoDVl)
					break
	return jjyQ5ePm9EoDVl,w7Ol6FnokgJDSsIt,kvste1oOZacAIpb2
def AEyNnLOu7g6BGrw5tlcj(ooJmTWvjkAOHMN6EQSa23b4wiY8):
	epM5JOB8HL1RTAfhuaKxvy2bEj = {
	 AJHaiQq3PRd5cphzGuELnVg9X(u"ࠪࡥ࡭ࡽࡡ࡬ࠩሹ")				:ZjELJ9VrUT07R8Hn4FuSDcf(u"๊ࠫ๎โฺࠢฦ๋ํอใࠡฬํๅ๏࠭ሺ")
	,pxt6wJ8ScYMWCivoO(u"ࠬࡧ࡫ࡰࡣࡰࠫሻ")				:PPxYugzLZwHX23yiK(u"࠭ๅ้ไ฼ࠤศ้่ศ็ࠣห้่ฯ๋็ࠪሼ")
	,UUobzy0xZLaVScIt7(u"ࠧࡢ࡭ࡲࡥࡲࡩࡡ࡮ࠩሽ")				:Yj1msqVeivESfrCupRy9b7WacBd(u"ࠨ็๋ๆ฾ࠦรไ๊ส้้ࠥวๆࠩሾ")
	,HD7MQqXd2gS(u"ࠩࡤ࡯ࡼࡧ࡭ࠨሿ")				:Pj9YaUq1ibJ(u"้ࠪํู่ࠡลๆ์ฬ๋ࠠศๆฯำ๏ีࠧቀ")
	,jil8vRpBsENVYyPmDd(u"ࠫࡦࡱࡷࡢ࡯ࡷࡹࡧ࡫ࠧቁ")			:Pj9YaUq1ibJ(u"๋่ࠬใ฻ࠣห่๎วๆࠢอ๎ํฮࠧቂ")
	,pxt6wJ8ScYMWCivoO(u"࠭ࡡ࡭ࡣࡵࡥࡧ࠭ቃ")				:ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠧๆ๊ๅ฽้ࠥไࠡษ็฽ึฮࠧቄ")
	,pxt6wJ8ScYMWCivoO(u"ࠨࡣ࡯ࡪࡦࡺࡩ࡮࡫ࠪቅ")				:bDxWcjmaSgFeRKrfpJvyA4zThi(u"่ࠩ์็฿ࠠศๆ่๊อืࠠศๆไห฼๋๊ࠨቆ")
	,vzqjsVHSBlMpxC(u"ࠪࡥࡱࡱࡡࡸࡶ࡫ࡥࡷ࠭ቇ")			:Qy6wlfLoOpg1(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠศๆๆ์ะืࠧቈ")
	,PPxYugzLZwHX23yiK(u"ࠬࡧ࡬࡮ࡣࡤࡶࡪ࡬ࠧ቉")				:AJHaiQq3PRd5cphzGuELnVg9X(u"࠭ๅ้ไ฼ࠤ็์วสࠢส่๊฿วาใࠪቊ")
	,bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠧࡢ࡮ࡰࡷࡹࡨࡡࠨቋ")				:w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠨ็๋ๆ฾ࠦวๅ็ุ฻อฯࠧቌ")
	,ldIfvn6asURQ9toi85EhqAXW3(u"ࠩࡤࡲ࡮ࡳࡥࡻ࡫ࡧࠫቍ")				:JvQd6LMoBX4hiy1C(u"้ࠪํู่ࠡษ้้๏ࠦาะࠩ቎")
	,DFx6E0uON7Jm8(u"ࠫࡦࡸࡡࡣ࡫ࡦࡸࡴࡵ࡮ࡴࠩ቏")			:ldIfvn6asURQ9toi85EhqAXW3(u"๋่ࠬใ฻ࠣฮํ์าࠡ฻ิฬ๏ฯࠧቐ")
	,yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨቑ")				:nfNTgkiWdUq(u"ࠧๆ๊ๅ฽ࠥ฿ัษࠢึ๎๏ีࠧቒ")
	,zhE5I4xHinX0UoVZMNwlkPrR(u"ࠨࡣࡵࡦࡱ࡯࡯࡯ࡼࠪቓ")				:JvQd6LMoBX4hiy1C(u"่ࠩ์็฿ฺࠠำหࠤ้๐่็ิࠪቔ")
	,gmPI7hVEM8nD(u"ࠪࡥࡾࡲ࡯࡭ࠩቕ")				:Yj1msqVeivESfrCupRy9b7WacBd(u"๊ࠫ๎โฺࠢฦ๎้๎ไࠨቖ")
	,jil8vRpBsENVYyPmDd(u"ࠬࡨ࡯࡬ࡴࡤࠫ቗")				:mRanX1HZupfSQVB2gsDGUO(u"࠭ๅ้ไ฼ࠤอ้ัศࠩቘ")
	,PPxYugzLZwHX23yiK(u"ࠧࡣࡴࡶࡸࡪࡰࠧ቙")				:nfNTgkiWdUq(u"ࠨ็๋ๆ฾ࠦศาีอ๎ั࠭ቚ")
	,Pj9YaUq1ibJ(u"ࠩࡦ࡭ࡲࡧ࠴࠱࠲ࠪቛ")				:Qy6wlfLoOpg1(u"้ࠪํู่ࠡีํ้ฬࠦ࠴࠱࠲ࠪቜ")
	,mRanX1HZupfSQVB2gsDGUO(u"ࠫࡨ࡯࡭ࡢ࠶ࡳࠫቝ")				:JvQd6LMoBX4hiy1C(u"๋่ࠬใ฻ࠣื๏๋วࠡใ๋ีࠥฮ๊ࠨ቞")
	,lw2snZ9J0uhLoxypqa(u"࠭ࡣࡪ࡯ࡤ࠸ࡺ࠭቟")				:n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣๅํื๊้ࠩበ")
	,XEcWOIwkZKubV7vQ(u"ࠨࡥ࡬ࡱࡦࡧࡢࡥࡱࠪቡ")				:YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"่ࠩ์็฿ࠠิ์่หࠥ฿ศะ๊ࠪቢ")
	,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠪࡧ࡮ࡳࡡࡤ࡮ࡸࡦࠬባ")				:zhE5I4xHinX0UoVZMNwlkPrR(u"๊ࠫ๎โฺࠢึ๎๊อࠠไๆ๋ฬࠬቤ")
	,Pj9YaUq1ibJ(u"ࠬࡩࡩ࡮ࡣࡦࡰࡺࡨࡷࡰࡴ࡮ࠫብ")			:XEcWOIwkZKubV7vQ(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢๆ่ํฮฺࠠ็็ࠫቦ")
	,Qy6wlfLoOpg1(u"ࠧࡤ࡫ࡰࡥࡨࡲࡵࡱࠩቧ")				:vzqjsVHSBlMpxC(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ่๊่ษࠩቨ")
	,Qy6wlfLoOpg1(u"ࠩࡦ࡭ࡲࡧࡦࡢࡰࡶࠫቩ")				:FVxoQ2J5Mfv3Zj6sy9uhOS(u"้ࠪํู่ࠡีํ้ฬࠦแศ่ีࠫቪ")
	,DFx6E0uON7Jm8(u"ࠫࡨ࡯࡭ࡢࡨࡵࡩࡪ࠭ቫ")				:vzqjsVHSBlMpxC(u"๋่ࠬใ฻ࠣื๏๋วࠡใิ๎ࠬቬ")
	,UUobzy0xZLaVScIt7(u"࠭ࡣࡪ࡯ࡤࡰ࡮࡭ࡨࡵࠩቭ")			:gmPI7hVEM8nD(u"ࠧๆ๊ๅ฽ู๊ࠥๆษ่ࠣฬ๐สࠨቮ")
	,w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩቯ")				:ZjELJ9VrUT07R8Hn4FuSDcf(u"่ࠩ์็฿ࠠิ์่หࠥ์ว้ࠩተ")
	,zhE5I4xHinX0UoVZMNwlkPrR(u"ࠪࡧ࡮ࡳࡡࡸࡤࡤࡷࠬቱ")				:gmPI7hVEM8nD(u"๊ࠫ๎โฺࠢึ๎๊อ้ࠠสึࠫቲ")
	,ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪታ")			:nfNTgkiWdUq(u"࠭ๅ้ไ฼ࠤิอ๊ๅ์้ࠣํฺๆࠨቴ")
	,PPxYugzLZwHX23yiK(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡩࡨࡢࡰࡱࡩࡱࡹࠧት")	:Pj9YaUq1ibJ(u"ࠨ็๋ๆ฾ࠦฯศ์็๎๋่ࠥีุ่้ࠣะฮะ็ํ๊ࠬቶ")
	,xwIUQfiE7rmvYzH(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡩࡣࡶ࡬ࡹࡧࡧࡴࠩቷ")	:DFx6E0uON7Jm8(u"้ࠪํู่ࠡัส๎้๐ࠠๆ๊ื๊ࠥํวีฬส็ࠬቸ")
	,n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯࡯࡭ࡻ࡫ࡳࠨቹ")	:pxt6wJ8ScYMWCivoO(u"๋่ࠬใ฻ࠣำฬ๐ไ๋่ࠢ์ู์ࠠๆสสุึ࠭ቺ")
	,rCmGE4YIDaZA(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧቻ"):ldIfvn6asURQ9toi85EhqAXW3(u"ࠧๆ๊ๅ฽ࠥีว๋ๆํࠤ๊๎ิ็ࠢๅ์ฬฬๅࠨቼ")
	,mRanX1HZupfSQVB2gsDGUO(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡴࡰࡲ࡬ࡧࡸ࠭ች")	:YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"่ࠩ์็฿ࠠะษํ่๏ࠦๅ้ึ้ࠤ๊๎วื์฼ࠫቾ")
	,nfNTgkiWdUq(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮ࡸ࡬ࡨࡪࡵࡳࠨቿ")	:VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"๊ࠫ๎โฺࠢาห๏๊๊ࠡ็ุ๋๋ࠦแ๋ัํ์์อสࠨኀ")
	,Yj1msqVeivESfrCupRy9b7WacBd(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧኁ")				:baBcNd81eH5ry2Olp6Mj43(u"࠭ๅห๊ๅๅࠬኂ")
	,rCmGE4YIDaZA(u"ࠧࡥࡴࡤࡱࡦࡩࡡࡧࡧࠪኃ")			:ldIfvn6asURQ9toi85EhqAXW3(u"ࠨ็๋ๆ฾ࠦฯาษ่ห้ࠥวโ์๊ࠫኄ")
	,vzqjsVHSBlMpxC(u"ࠩࡧࡶࡦࡳࡡࡴ࠹ࠪኅ")				:jil8vRpBsENVYyPmDd(u"้ࠪํู่ࠡัิห๊อࠠึฯࠪኆ")
	,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬኇ")				:yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯ࠭ኈ")
	,nfNTgkiWdUq(u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠱ࠨ኉")				:bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠳ࠪኊ")
	,bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠴ࠪኋ")				:Pj9YaUq1ibJ(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠶ࠬኌ")
	,LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠷ࠬኍ")				:zhE5I4xHinX0UoVZMNwlkPrR(u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠹ࠧ኎")
	,jil8vRpBsENVYyPmDd(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠺ࠧ኏")				:rCmGE4YIDaZA(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠵ࠩነ")
	,HD7MQqXd2gS(u"ࠧࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠫኑ")			:VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢࡹ࡭ࡵ࠭ኒ")
	,FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠩࡨ࡫ࡾࡪࡥࡢࡦࠪና")				:bb1fgjsAq4N2xYwnoh39lm(u"้ࠪํู่ࠡวํะ๏ࠦฯ๋ัࠪኔ")
	,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠫࡪ࡭ࡹ࡯ࡱࡺࠫን")				:xwIUQfiE7rmvYzH(u"๋่ࠬใ฻ࠣษ๏า๊่ࠡส์ࠬኖ")
	,DFx6E0uON7Jm8(u"࠭ࡥ࡭ࡥ࡬ࡲࡪࡳࡡࠨኗ")				:xwIUQfiE7rmvYzH(u"ࠧๆ๊ๅ฽๋่ࠥิ๊฼อࠥอไิ์้้ฬ࠭ኘ")
	,jil8vRpBsENVYyPmDd(u"ࠨࡧ࡯࡭࡫ࡼࡩࡥࡧࡲࠫኙ")			:bDxWcjmaSgFeRKrfpJvyA4zThi(u"่ࠩ์็฿ࠠฤๆํๅࠥ็๊ะ์๋ࠫኚ")
	,rCmGE4YIDaZA(u"ࠪࡪࡦࡨࡲࡢ࡭ࡤࠫኛ")				:Pj9YaUq1ibJ(u"๊ࠫ๎โฺࠢไฬึ้ษࠨኜ")
	,ldIfvn6asURQ9toi85EhqAXW3(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬኝ")				:vzqjsVHSBlMpxC(u"࠭แีๆࠪኞ")
	,Pj9YaUq1ibJ(u"ࠧࡧࡣ࡭ࡩࡷࡹࡨࡰࡹࠪኟ")			:lw2snZ9J0uhLoxypqa(u"ࠨ็๋ๆ฾ࠦแอำุࠣํ࠭አ")
	,FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠩࡩࡥࡷ࡫ࡳ࡬ࡱࠪኡ")				:UUobzy0xZLaVScIt7(u"้ࠪํู่ࠡใสีุ้่ࠨኢ")
	,ldIfvn6asURQ9toi85EhqAXW3(u"ࠫ࡫ࡧࡳࡦ࡮࡫ࡨ࠶࠭ኣ")				:DFx6E0uON7Jm8(u"๋่ࠬใ฻ࠣๅฬ฻ไࠡษ็วํ๊ࠧኤ")
	,lw2snZ9J0uhLoxypqa(u"࠭ࡦࡢࡵࡨࡰ࡭ࡪ࠲ࠨእ")				:XEcWOIwkZKubV7vQ(u"ࠧๆ๊ๅ฽ࠥ็วึๆࠣห้ัว็์ࠪኦ")
	,nfNTgkiWdUq(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨኧ")				:zhE5I4xHinX0UoVZMNwlkPrR(u"่ࠩะ้ีࠧከ")
	,Qy6wlfLoOpg1(u"ࠪࡪࡴࡹࡴࡢࠩኩ")				:DFx6E0uON7Jm8(u"๊ࠫ๎โฺࠢไ์ุะวࠨኪ")
	,bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠬ࡬ࡵ࡯ࡱࡱࡸࡻ࠭ካ")				:JvQd6LMoBX4hiy1C(u"࠭ๅ้ไ฼ࠤๆ์่็ࠢอ๎ๆ๐ࠧኬ")
	,vzqjsVHSBlMpxC(u"ࠧࡧࡷࡶ࡬ࡦࡸࡴࡷࠩክ")				:jil8vRpBsENVYyPmDd(u"ࠨ็๋ๆ฾ࠦแ้ึสีࠥะ๊โ์ࠪኮ")
	,HD7MQqXd2gS(u"ࠩࡩࡹࡸ࡮ࡡࡳࡸ࡬ࡨࡪࡵࠧኯ")			:bb1fgjsAq4N2xYwnoh39lm(u"้ࠪํู่ࠡใุ๋ฬืࠠโ์า๎ํ࠭ኰ")
	,UUobzy0xZLaVScIt7(u"ࠫ࡬ࡵ࡯ࡥࠩ኱")					:Yj1msqVeivESfrCupRy9b7WacBd(u"ࠬา๊ะࠩኲ")
	,UUobzy0xZLaVScIt7(u"࠭ࡨࡢ࡮ࡤࡧ࡮ࡳࡡࠨኳ")				:vzqjsVHSBlMpxC(u"ࠧๆ๊ๅ฽ࠥํไศࠢึ๎๊อࠧኴ")
	,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠨࡪࡨࡰࡦࡲࠧኵ")				:jil8vRpBsENVYyPmDd(u"่ࠩ์็฿่ࠠๆส่ࠥ๐่ห์๋ฬࠬ኶")
	,ldIfvn6asURQ9toi85EhqAXW3(u"ࠪ࡭࡫࡯࡬࡮ࠩ኷")				:w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠨኸ")
	,jil8vRpBsENVYyPmDd(u"ࠬ࡯ࡦࡪ࡮ࡰ࠱ࡦࡸࡡࡣ࡫ࡦࠫኹ")			:w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠭ๅ้ไ฼ࠤ็์วสࠢล๎ࠥ็๊ๅ็ࠣ฽ึฮ๊ࠨኺ")
	,mRanX1HZupfSQVB2gsDGUO(u"ࠧࡪࡨ࡬ࡰࡲ࠳ࡥ࡯ࡩ࡯࡭ࡸ࡮ࠧኻ")		:gmPI7hVEM8nD(u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠥอๆอๆํึ๏࠭ኼ")
	,w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠩ࡬ࡴࡹࡼࠧኽ")					:n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠪࡍࡕ࡚ࡖࠨኾ")
	,bb1fgjsAq4N2xYwnoh39lm(u"ࠫ࡮ࡶࡴࡷ࠯࡯࡭ࡻ࡫ࠧ኿")			:Pj9YaUq1ibJ(u"ࠬࡏࡐࡕࡘࠣๆ๋๎วหࠩዀ")
	,bb1fgjsAq4N2xYwnoh39lm(u"࠭ࡩࡱࡶࡹ࠱ࡲࡵࡶࡪࡧࡶࠫ዁")			:zhE5I4xHinX0UoVZMNwlkPrR(u"ࠧࡊࡒࡗ࡚ࠥษแๅษ่ࠫዂ")
	,baBcNd81eH5ry2Olp6Mj43(u"ࠨ࡫ࡳࡸࡻ࠳ࡳࡦࡴ࡬ࡩࡸ࠭ዃ")			:Pj9YaUq1ibJ(u"ࠩࡌࡔ࡙࡜ࠠๆี็ื้อสࠨዄ")
	,nfNTgkiWdUq(u"ࠪ࡯ࡦࡸࡢࡢ࡮ࡤࡸࡻ࠭ዅ")			:FVxoQ2J5Mfv3Zj6sy9uhOS(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠไำห่ฬวࠧ዆")
	,jil8vRpBsENVYyPmDd(u"ࠬࡱࡡࡵ࡭ࡲࡸࡹࡼࠧ዇")				:mRanX1HZupfSQVB2gsDGUO(u"࠭ๅ้ไ฼ࠤ่ะใ้ฬࠣฮ๏็๊ࠨወ")
	,bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦࠩዉ")				:nfNTgkiWdUq(u"ࠨ็๋ๆ฾ࠦใหๅ๋ฮࠬዊ")
	,Pj9YaUq1ibJ(u"ࠩ࡮࡭ࡷࡳࡡ࡭࡭ࠪዋ")				:Qy6wlfLoOpg1(u"้ࠪํู่ࠡๅิ้ฬ๊ใࠨዌ")
	,bb1fgjsAq4N2xYwnoh39lm(u"ࠫࡱࡧࡲࡰࡼࡤࠫው")				:XEcWOIwkZKubV7vQ(u"๋่ࠬใ฻่ࠣฬื่ำษࠪዎ")
	,bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠭࡬ࡪࡤࡵࡥࡷࡿࠧዏ")				:bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠧๆๆไࠫዐ")
	,pxt6wJ8ScYMWCivoO(u"ࠨ࡮࡬ࡺࡪ࠭ዑ")					:bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠩๅ๊ฬฯࠧዒ")
	,xwIUQfiE7rmvYzH(u"ࠪࡰ࡮ࡼࡥࡵࡸࠪዓ")				:jil8vRpBsENVYyPmDd(u"๊๊ࠫแࠨዔ")
	,UUobzy0xZLaVScIt7(u"ࠬࡲ࡯ࡥࡻࡱࡩࡹ࠭ዕ")				:lw2snZ9J0uhLoxypqa(u"࠭ๅ้ไ฼ࠤ้๎ฯ๋้ࠢฮࠬዖ")
	,Qy6wlfLoOpg1(u"ࠧ࡮࠵ࡸࠫ዗")					:pxt6wJ8ScYMWCivoO(u"ࠨࡏ࠶࡙ࠬዘ")
	,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠩࡰ࠷ࡺ࠳࡬ࡪࡸࡨࠫዙ")				:HD7MQqXd2gS(u"ࠪࡑ࠸࡛ࠠใ่๋หฯ࠭ዚ")
	,zhE5I4xHinX0UoVZMNwlkPrR(u"ࠫࡲ࠹ࡵ࠮࡯ࡲࡺ࡮࡫ࡳࠨዛ")			:n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠬࡓ࠳ࡖࠢฦๅ้อๅࠨዜ")
	,JvQd6LMoBX4hiy1C(u"࠭࡭࠴ࡷ࠰ࡷࡪࡸࡩࡦࡵࠪዝ")			:yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠧࡎ࠵ࡘࠤู๊ไิๆสฮࠬዞ")
	,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠨ࡯ࡤࡷࡦࡼࡩࡥࡧࡲࠫዟ")			:yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"่ࠩ์็฿ࠠๆษึหࠥ็๊ะ์๋ࠫዠ")
	,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫዡ")				:pxt6wJ8ScYMWCivoO(u"๊ࠫ็โ้ัࠪዢ")
	,baBcNd81eH5ry2Olp6Mj43(u"ࠬࡳ࡯ࡷࡵ࠷ࡹࠬዣ")				:rCmGE4YIDaZA(u"࠭ๅ้ไ฼ࠤ๊๎แำࠢไ์ึ๐่ࠨዤ")
	,FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠧ࡮ࡻࡦ࡭ࡲࡧࠧዥ")				:DFx6E0uON7Jm8(u"ࠨ็๋ๆ฾ࠦๅศ์ࠣื๏๋วࠨዦ")
	,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠩࡲࡰࡩ࠭ዧ")					:Yj1msqVeivESfrCupRy9b7WacBd(u"ࠪๆิ๐ๅࠨየ")
	,AJHaiQq3PRd5cphzGuELnVg9X(u"ࠫࡵࡧ࡮ࡦࡶࠪዩ")				:YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"๋่ࠬใ฻ࠣฬฬ์๊หࠩዪ")
	,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠭ࡰࡢࡰࡨࡸ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬያ")			:ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠧๆ๊ๅ฽ࠥฮว็์อࠤฬ็ไศ็ࠪዬ")
	,ldIfvn6asURQ9toi85EhqAXW3(u"ࠨࡲࡤࡲࡪࡺ࠭ࡴࡧࡵ࡭ࡪࡹࠧይ")			:UUobzy0xZLaVScIt7(u"่ࠩ์็฿ࠠษษ้๎ฯࠦๅิๆึ่ฬะࠧዮ")
	,xwIUQfiE7rmvYzH(u"ࠪࡵ࡫࡯࡬࡮ࠩዯ")				:YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"๊ࠫ๎โฺࠢๆ๎ํࠦแ๋ๆ่ࠫደ")
	,DFx6E0uON7Jm8(u"ࠬࡹࡥࡳ࡫ࡨࡷࡹ࡯࡭ࡦࠩዱ")			:XEcWOIwkZKubV7vQ(u"࠭ๅ้ไ฼ࠤุ๐ั๋ีࠣฮฬ๐ๅࠨዲ")
	,zhE5I4xHinX0UoVZMNwlkPrR(u"ࠧࡴࡪࡤࡦࡦࡱࡡࡵࡻࠪዳ")			:w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠨ็๋ๆ฾ࠦิษๅอ๎ࠬዴ")
	,rCmGE4YIDaZA(u"ࠩࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫድ")				:pxt6wJ8ScYMWCivoO(u"้ࠪํู่ࠡึส๋ิࠦแ้ำํ์ࠬዶ")
	,UUobzy0xZLaVScIt7(u"ࠫࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠸ࠧዷ")			:Pj9YaUq1ibJ(u"๋่ࠬใ฻ุࠣฬํฯࠡใ๋ี๏๎ࠠ࠳ࠩዸ")
	,pxt6wJ8ScYMWCivoO(u"࠭ࡳࡩࡣ࡫࡭ࡩࡴࡥࡸࡵࠪዹ")			:PPxYugzLZwHX23yiK(u"ࠧๆ๊ๅ฽ฺࠥว่ั๊ࠣ๏๎าࠨዺ")
	,pxt6wJ8ScYMWCivoO(u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨࠫዻ")			:PPxYugzLZwHX23yiK(u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠫዼ")
	,ldIfvn6asURQ9toi85EhqAXW3(u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠳ࡡ࡭ࡤࡸࡱࡸ࠭ዽ")		:w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦวๅส๋้ࠬዾ")
	,ldIfvn6asURQ9toi85EhqAXW3(u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥ࠮ࡣࡸࡨ࡮ࡵࡳࠨዿ")		:ZjELJ9VrUT07R8Hn4FuSDcf(u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠡื๋ฮ๏อสࠨጀ")
	,Pj9YaUq1ibJ(u"ࠧࡴࡪ࡬ࡥࡻࡵࡩࡤࡧ࠰ࡴࡪࡸࡳࡰࡰࡶࠫጁ")	:VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠣๆฬืฦࠨጂ")
	,baBcNd81eH5ry2Olp6Mj43(u"ࠩࡶ࡬ࡴ࡬ࡨࡢࠩጃ")				:w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"้ࠪํู่ࠡึ๋ๅ์อࠠห์ไ๎ࠬጄ")
	,vzqjsVHSBlMpxC(u"ࠫࡸ࡮࡯ࡰࡨࡰࡥࡽ࠭ጅ")				:zhE5I4xHinX0UoVZMNwlkPrR(u"๋่ࠬใ฻ุࠣํ็ࠠๆษๆืࠬጆ")
	,LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠭ࡳࡩࡱࡲࡪࡳ࡫ࡴࠨጇ")				:ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠧๆ๊ๅ฽ฺ่ࠥโ้ࠢฮࠬገ")
	,PPxYugzLZwHX23yiK(u"ࠨࡵ࡫ࡳࡴ࡬ࡰࡳࡱࠪጉ")				:VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"่ࠩ์็฿ࠠี๊ไࠤอื่ࠨጊ")
	,ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠪࡸ࡮ࡱࡡࡢࡶࠪጋ")				:zhE5I4xHinX0UoVZMNwlkPrR(u"๊ࠫ๎โฺࠢอ็ฬะࠧጌ")
	,lw2snZ9J0uhLoxypqa(u"ࠬࡺࡶࡧࡷࡱࠫግ")				:Pj9YaUq1ibJ(u"࠭ๅ้ไ฼ࠤฯ๐แ๋ࠢไห๋࠭ጎ")
	,HD7MQqXd2gS(u"ࠧࡷࡣࡵࡦࡴࡴࠧጏ")				:bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠨ็๋ๆ฾ࠦแศำห์๋࠭ጐ")
	,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠩࡹ࡭ࡩ࡫࡯ࠨ጑")				:zhE5I4xHinX0UoVZMNwlkPrR(u"ࠪๅ๏ี๊้ࠩጒ")
	,LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠫࡻ࡯ࡤࡦࡱࡱࡷࡦ࡫࡭ࠨጓ")			:bb1fgjsAq4N2xYwnoh39lm(u"๋่ࠬใ฻ࠣๅ๏ี๊้้ࠢืฬฬๅࠨጔ")
	,HD7MQqXd2gS(u"࠭ࡷࡦࡥ࡬ࡱࡦ࠷ࠧጕ")				:XEcWOIwkZKubV7vQ(u"ࠧๆ๊ๅ฽ࠥ๎๊ࠡีํ้ฬࠦ࠱ࠨ጖")
	,rCmGE4YIDaZA(u"ࠨࡹࡨࡧ࡮ࡳࡡ࠳ࠩ጗")				:rCmGE4YIDaZA(u"่ࠩ์็฿้ࠠ์ࠣื๏๋วࠡ࠴ࠪጘ")
	,baBcNd81eH5ry2Olp6Mj43(u"ࠪࡽࡦࡷ࡯ࡵࠩጙ")				:HD7MQqXd2gS(u"๊ࠫ๎โฺࠢํห็๎สࠨጚ")
	,gmPI7hVEM8nD(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭ጛ")				:pxt6wJ8ScYMWCivoO(u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠫጜ")
	,rCmGE4YIDaZA(u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠮ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪጝ")		:ldIfvn6asURQ9toi85EhqAXW3(u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦโ็๊สฮࠬጞ")
	,JvQd6LMoBX4hiy1C(u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠰ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭ጟ")	:zhE5I4xHinX0UoVZMNwlkPrR(u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡไ๋หห๋ࠧጠ")
	,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠲ࡼࡩࡥࡧࡲࡷࠬጡ")		:DFx6E0uON7Jm8(u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣๅ๏ี๊้้สฮࠬጢ")
	,n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠭ࡹࡵࡤࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬጣ")			:Pj9YaUq1ibJ(u"ࠧๆ๊สๆ฾ࠦๅ็ࠢํ์ฯ๐่ษࠩጤ")
	}
	TzPShYRQ24q8wtfOke6b = ooJmTWvjkAOHMN6EQSa23b4wiY8.lower()
	for key in list(epM5JOB8HL1RTAfhuaKxvy2bEj.keys()):
		HHFdEPxwCqDN3TgMX2ikR = key.lower()
		if TzPShYRQ24q8wtfOke6b==HHFdEPxwCqDN3TgMX2ikR:
			ooJmTWvjkAOHMN6EQSa23b4wiY8 = epM5JOB8HL1RTAfhuaKxvy2bEj[key]
			break
	return ooJmTWvjkAOHMN6EQSa23b4wiY8
def AA5FS4hUqeP9EsZCM(Y6qWL8lVPt2aoMb0cgkI,In70lxPqc8QUoatYBw19Rup=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	Nzp9Fq5cTr.BWx4LyF0fcT1teAwjQJkgrS8nPNU = S5MWhgtZ37Xw
	if not In70lxPqc8QUoatYBw19Rup and Y6qWL8lVPt2aoMb0cgkI: In70lxPqc8QUoatYBw19Rup = FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡡࡕࡉࡋࡘࡅࡔࡊࡢࡇࡆࡉࡈࡆࠩጥ")
	KQctJbXeEjDhplqknU3rzi.setSetting(ldIfvn6asURQ9toi85EhqAXW3(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭ጦ"),In70lxPqc8QUoatYBw19Rup)
	return
def kGE6zoKSan54W(RxWJFBAGy4iIM,JEY6GbTqjHw7D5sZPnR1C=mRanX1HZupfSQVB2gsDGUO(u"ࠪ࠾࠴࠭ጧ")):
	return _NaTjlhXKH6xcpF8evw(RxWJFBAGy4iIM,JEY6GbTqjHw7D5sZPnR1C)
def g3Q4HsItAwoRfhETlyPCvB(hzpRwCnI98b):
	if hzpRwCnI98b in [nA5dhMRg6ENzsB0l1GwvH7aIr2,Yj1msqVeivESfrCupRy9b7WacBd(u"ࠫ࠵࠭ጨ"),IpFcwrWNgefMym3qta0hYQAzOdE]: return nA5dhMRg6ENzsB0l1GwvH7aIr2
	hzpRwCnI98b = int(hzpRwCnI98b)
	kcX4x1eWC5pLt0wur = hzpRwCnI98b^OkCUfhKTs9DZbcgnw3roPGBvlqt
	hfU0dHlP3iyIDu = hzpRwCnI98b^QdwW2s0iEp56qMmvCbOeLxBRU
	FCqVh3624iItUgz = hzpRwCnI98b^lPsYQwWdLO520ZHcFV8n1x
	fZrv0AwH7isgUaLVdpqmRt5BjbQPW = str(kcX4x1eWC5pLt0wur)+str(hfU0dHlP3iyIDu)+str(FCqVh3624iItUgz)
	return fZrv0AwH7isgUaLVdpqmRt5BjbQPW
def fPHdWY3yN2EwpamST0uQUVsA(hzpRwCnI98b):
	if hzpRwCnI98b in [nA5dhMRg6ENzsB0l1GwvH7aIr2,Yj1msqVeivESfrCupRy9b7WacBd(u"ࠬ࠶ࠧጩ"),IpFcwrWNgefMym3qta0hYQAzOdE]: return nA5dhMRg6ENzsB0l1GwvH7aIr2
	hzpRwCnI98b = str(hzpRwCnI98b)
	fZrv0AwH7isgUaLVdpqmRt5BjbQPW = nA5dhMRg6ENzsB0l1GwvH7aIr2
	if len(hzpRwCnI98b)==w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠵࠺ᑪ"):
		kcX4x1eWC5pLt0wur,hfU0dHlP3iyIDu,FCqVh3624iItUgz = hzpRwCnI98b[IpFcwrWNgefMym3qta0hYQAzOdE:tpMX1Bgs0bzv8OEafyW],hzpRwCnI98b[tpMX1Bgs0bzv8OEafyW:VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠾ᑫ")],hzpRwCnI98b[VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠾ᑫ"):]
		kcX4x1eWC5pLt0wur = int(kcX4x1eWC5pLt0wur)^lPsYQwWdLO520ZHcFV8n1x
		hfU0dHlP3iyIDu = int(hfU0dHlP3iyIDu)^QdwW2s0iEp56qMmvCbOeLxBRU
		FCqVh3624iItUgz = int(FCqVh3624iItUgz)^OkCUfhKTs9DZbcgnw3roPGBvlqt
		if kcX4x1eWC5pLt0wur==hfU0dHlP3iyIDu==FCqVh3624iItUgz: fZrv0AwH7isgUaLVdpqmRt5BjbQPW = str(kcX4x1eWC5pLt0wur*Yj1msqVeivESfrCupRy9b7WacBd(u"࠼࠰ᑬ"))
	return fZrv0AwH7isgUaLVdpqmRt5BjbQPW
def AsG2TjLa1DUMI(hzpRwCnI98b,MM2J4iACpPsmqGnFcgwDlE3NdBjtWO=lw2snZ9J0uhLoxypqa(u"࠭࠶࠴࠺࠷࠵࠽࠸࠳ࠨጪ")):
	if hzpRwCnI98b==nA5dhMRg6ENzsB0l1GwvH7aIr2: return nA5dhMRg6ENzsB0l1GwvH7aIr2
	hzpRwCnI98b = int(hzpRwCnI98b)+int(MM2J4iACpPsmqGnFcgwDlE3NdBjtWO)
	kcX4x1eWC5pLt0wur = hzpRwCnI98b^OkCUfhKTs9DZbcgnw3roPGBvlqt
	hfU0dHlP3iyIDu = hzpRwCnI98b^QdwW2s0iEp56qMmvCbOeLxBRU
	FCqVh3624iItUgz = hzpRwCnI98b^lPsYQwWdLO520ZHcFV8n1x
	fZrv0AwH7isgUaLVdpqmRt5BjbQPW = str(kcX4x1eWC5pLt0wur)+str(hfU0dHlP3iyIDu)+str(FCqVh3624iItUgz)
	return fZrv0AwH7isgUaLVdpqmRt5BjbQPW
def cMda92KRnsEG7gmAtwqYT0lJ1uDj(hzpRwCnI98b,MM2J4iACpPsmqGnFcgwDlE3NdBjtWO=ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠧ࠷࠵࠻࠸࠶࠾࠲࠴ࠩጫ")):
	if hzpRwCnI98b==nA5dhMRg6ENzsB0l1GwvH7aIr2: return nA5dhMRg6ENzsB0l1GwvH7aIr2
	hzpRwCnI98b = str(hzpRwCnI98b)
	S4SHw7hZvLPup1k0clV5zOgUboKDQF = int(len(hzpRwCnI98b)/AH0zdvBqibaXY)
	kcX4x1eWC5pLt0wur = int(hzpRwCnI98b[IpFcwrWNgefMym3qta0hYQAzOdE:S4SHw7hZvLPup1k0clV5zOgUboKDQF])^OkCUfhKTs9DZbcgnw3roPGBvlqt
	hfU0dHlP3iyIDu = int(hzpRwCnI98b[S4SHw7hZvLPup1k0clV5zOgUboKDQF:udq5tP0hwifHQCGYELDbOUI*S4SHw7hZvLPup1k0clV5zOgUboKDQF])^QdwW2s0iEp56qMmvCbOeLxBRU
	FCqVh3624iItUgz = int(hzpRwCnI98b[udq5tP0hwifHQCGYELDbOUI*S4SHw7hZvLPup1k0clV5zOgUboKDQF:AH0zdvBqibaXY*S4SHw7hZvLPup1k0clV5zOgUboKDQF])^lPsYQwWdLO520ZHcFV8n1x
	fZrv0AwH7isgUaLVdpqmRt5BjbQPW = nA5dhMRg6ENzsB0l1GwvH7aIr2
	if kcX4x1eWC5pLt0wur==hfU0dHlP3iyIDu==FCqVh3624iItUgz: fZrv0AwH7isgUaLVdpqmRt5BjbQPW = str(int(kcX4x1eWC5pLt0wur)-int(MM2J4iACpPsmqGnFcgwDlE3NdBjtWO))
	return fZrv0AwH7isgUaLVdpqmRt5BjbQPW
def U2jmQhBSu1vX4IDglaCnYs0c(yyLk2NYKcga4vJbTBQVXzrpxA):
	le4fx8S2BKM1IutaG6XVDdk5mj3O = Nzp9Fq5cTr.SITESURLS[ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨጬ")][jil8vRpBsENVYyPmDd(u"࠸ᑭ")]
	RtwHdLu8XGq9xPs0VJkeNpr = XoZRpFe7B6gnfA.path.join(mQKDw6vcXNIkngiWrC8GdPFqeRH,vzqjsVHSBlMpxC(u"ࠩࡵࡩࡸࡵࡵࡳࡥࡨࡷࠬጭ"),n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠪࡷࡰ࡯࡮ࡴࠩጮ"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬጯ"),bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠬ࠽࠲࠱ࡲࠪጰ"),UUobzy0xZLaVScIt7(u"࠭ࡄࡪࡣ࡯ࡳ࡬ࡉ࡯࡯ࡨ࡬ࡶࡲ࡚ࡨࡳࡧࡨࡆࡺࡺࡴࡰࡰࡶ࠲ࡽࡳ࡬ࠨጱ"))
	PuQB3RUSK8kEjnMGmq0fox1sDVaAH,ggOr6vyqWkFhwCjtVb = cpNjIxZEUORvTw(RtwHdLu8XGq9xPs0VJkeNpr)
	PuQB3RUSK8kEjnMGmq0fox1sDVaAH = AsG2TjLa1DUMI(PuQB3RUSK8kEjnMGmq0fox1sDVaAH,LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠧ࠲࠴࠴࠼࠸࠷࠸࠶࠵ࠪጲ"))
	iua93DSoA1 = {vzqjsVHSBlMpxC(u"ࠨ࡫ࡧࡷࠬጳ"):vzqjsVHSBlMpxC(u"ࠩࡇࡍࡆࡒࡏࡈࠩጴ"),n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠪࡹࡸࡸࠧጵ"):Nzp9Fq5cTr.AV_CLIENT_IDS,bb1fgjsAq4N2xYwnoh39lm(u"ࠫࡻ࡫ࡲࠨጶ"):s5WcxEPjUBokapYMhAwb60dvgi,bb1fgjsAq4N2xYwnoh39lm(u"ࠬࡹࡣࡳࠩጷ"):yyLk2NYKcga4vJbTBQVXzrpxA,bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠭ࡳࡪࡼࠪጸ"):PuQB3RUSK8kEjnMGmq0fox1sDVaAH}
	Yt93BCDAfS4RcrKygiNH0bwELjM67k = {VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ጹ"):LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧጺ")}
	steLxydUG9DKVnFOi1gRZbhEIk = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,HD7MQqXd2gS(u"ࠩࡓࡓࡘ࡚ࠧጻ"),le4fx8S2BKM1IutaG6XVDdk5mj3O,iua93DSoA1,Yt93BCDAfS4RcrKygiNH0bwELjM67k,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,bb1fgjsAq4N2xYwnoh39lm(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡎࡏࡘࡡࡓࡐࡆ࡟࡟ࡅࡋࡄࡐࡔࡍ࠭࠲ࡵࡷࠫጼ"))
	uzRj7xMiWN39n2Aq = steLxydUG9DKVnFOi1gRZbhEIk.content
	try:
		if not uzRj7xMiWN39n2Aq: rSmp8aCILTN50xMtgwoFJ9qc7hE
		BB67oZK8TdMhzErtlmNisgWF = BwGPDSQOlfUas2n3eIH0ycFRWZ(xwIUQfiE7rmvYzH(u"ࠫࡩ࡯ࡣࡵࠩጽ"),uzRj7xMiWN39n2Aq)
		Yfx6OGh4NmDM = BB67oZK8TdMhzErtlmNisgWF[vzqjsVHSBlMpxC(u"ࠬࡳࡳࡨࠩጾ")]
		kkaqSPdvebJXpg9rzME = BB67oZK8TdMhzErtlmNisgWF[bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠭ࡳࡦࡥࠪጿ")]
		ooaAXVpCu8L29qRtMYG7 = BB67oZK8TdMhzErtlmNisgWF[ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠧࡴࡶࡳࠫፀ")]
		kkaqSPdvebJXpg9rzME = int(cMda92KRnsEG7gmAtwqYT0lJ1uDj(kkaqSPdvebJXpg9rzME,bb1fgjsAq4N2xYwnoh39lm(u"ࠨ࠳࠵࠵࠽࠹࠱࠹࠷࠶ࠫፁ")))
		ooaAXVpCu8L29qRtMYG7 = int(cMda92KRnsEG7gmAtwqYT0lJ1uDj(ooaAXVpCu8L29qRtMYG7,lw2snZ9J0uhLoxypqa(u"ࠩ࠴࠶࠶࠾࠳࠲࠺࠸࠷ࠬፂ")))
		for Y07YgqxOj3zMw in range(kkaqSPdvebJXpg9rzME,IpFcwrWNgefMym3qta0hYQAzOdE,-ooaAXVpCu8L29qRtMYG7):
			if not eval(rCmGE4YIDaZA(u"ࠪࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱࡭ࡸࡖ࡬ࡢࡻ࡬ࡲ࡬࠮ࠩࠨፃ"),{rCmGE4YIDaZA(u"ࠫࡽࡨ࡭ࡤࠩፄ"):SoNGUfhMDERLyHOz1qkVAj}): rSmp8aCILTN50xMtgwoFJ9qc7hE
			ggYilKR5rMDyp7B(Pj9YaUq1ibJ(u"ࠬฮวใ์่้ࠣะฬาสฬࠤํอไโฯุࠫፅ"),str(Y07YgqxOj3zMw)+lw2snZ9J0uhLoxypqa(u"࠭ࠠࠡอส๊๏ฯࠧፆ"),h0skHe7TcIY9x1UP5VBrZAE8dKGnl=VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠲࠲࠳ᑮ")*ooaAXVpCu8L29qRtMYG7)
			SoNGUfhMDERLyHOz1qkVAj.sleep(HD7MQqXd2gS(u"࠳࠳࠴࠵ᑯ")*ooaAXVpCu8L29qRtMYG7)
		if eval(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠧࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡪࡵࡓࡰࡦࡿࡩ࡯ࡩࠫ࠭ࠬፇ"),{bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠨࡺࡥࡱࡨ࠭ፈ"):SoNGUfhMDERLyHOz1qkVAj}):
			Yfx6OGh4NmDM = Yfx6OGh4NmDM.replace(CXtugbqhV3,baBcNd81eH5ry2Olp6Mj43(u"ࠩ࡟ࡠࡳ࠭ፉ")).replace(sSBzjZdcbQraNx,ldIfvn6asURQ9toi85EhqAXW3(u"ࠪࡠࡡࡸࠧፊ"))
			OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,JvQd6LMoBX4hiy1C(u"ࠫำื่อࠩፋ"),OksCHeoL5SG,Yfx6OGh4NmDM)
		rSmp8aCILTN50xMtgwoFJ9qc7hE
	except: exec(rCmGE4YIDaZA(u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳ࡹࡴࡰࡲࠫ࠭ࠬፌ"),{DFx6E0uON7Jm8(u"࠭ࡸࡣ࡯ࡦࠫፍ"):SoNGUfhMDERLyHOz1qkVAj})
	return
def iQaU4bpr7gewRfLyvl():
	exec(JvQd6LMoBX4hiy1C(u"ࠧࠨࠩࠐࠎࡹࡸࡹ࠻ࠏࠍࠍࡼ࡯࡮ࡥࡱࡺ࠵࠷࠹ࠠ࠾ࠢࡻࡦࡲࡩࡧࡶ࡫࠱࡛࡮ࡴࡤࡰࡹࠫ࠵࠵࠶࠲࠶ࠫࠐࠎࠎࡽࡨࡪ࡮ࡨࠤ࡙ࡸࡵࡦ࠼ࠐࠎࠎࠏࡸࡣ࡯ࡦ࠲ࡸࡲࡥࡦࡲࠫ࠵࠵࠶࠰ࠪࠏࠍࠍࠎࡺࡲࡺ࠼ࠣࡻ࡮ࡴࡤࡰࡹ࠴࠶࠸࠴ࡧࡦࡶࡉࡳࡨࡻࡳࠩ࠳࠳࠴࠷࠻ࠩࠎࠌࠌࠍࡪࡾࡣࡦࡲࡷ࠾ࠥࡨࡲࡦࡣ࡮ࠑࠏࠏࡺࡤࡴࡨࡥࡹ࡫࡟ࡦࡴࡲࡶࡷࠓࠊࡦࡺࡦࡩࡵࡺ࠺ࠡࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯ࡵࡷࡳࡵ࠮ࠩࠎࠌࠪࠫࠬፎ"),{FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠨࡺࡥࡱࡨ࡭ࡵࡪࠩፏ"):z3jwnDkZ76OfKFB1rRoQVghbE0u92,PPxYugzLZwHX23yiK(u"ࠩࡻࡦࡲࡩࠧፐ"):SoNGUfhMDERLyHOz1qkVAj})
	return
def cpNjIxZEUORvTw(hhZ6lIumVNX):
	b92ByL07OjDwvKCgzMFNTfm5APUGqQ,GsxA9qQzNZKg5XfiWuMd0HCE = IpFcwrWNgefMym3qta0hYQAzOdE,IpFcwrWNgefMym3qta0hYQAzOdE
	if XoZRpFe7B6gnfA.path.exists(hhZ6lIumVNX):
		try: b92ByL07OjDwvKCgzMFNTfm5APUGqQ = XoZRpFe7B6gnfA.path.getsize(hhZ6lIumVNX)
		except: pass
		if not b92ByL07OjDwvKCgzMFNTfm5APUGqQ:
			try: b92ByL07OjDwvKCgzMFNTfm5APUGqQ = XoZRpFe7B6gnfA.stat(hhZ6lIumVNX).st_size
			except: pass
		if not b92ByL07OjDwvKCgzMFNTfm5APUGqQ:
			try:
				from pathlib import Path as VMZjlefw6nK1hCP2
				b92ByL07OjDwvKCgzMFNTfm5APUGqQ = VMZjlefw6nK1hCP2(hhZ6lIumVNX).stat().st_size
			except: pass
		if b92ByL07OjDwvKCgzMFNTfm5APUGqQ: GsxA9qQzNZKg5XfiWuMd0HCE = UnOIK1WBbw2
	return b92ByL07OjDwvKCgzMFNTfm5APUGqQ,GsxA9qQzNZKg5XfiWuMd0HCE
def j1tZf3FQH0MxiO2nvwEpJ79h(SgjYGPuifqyamW8BQzxrVnM,showDialogs):
	if showDialogs:
		x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,SgjYGPuifqyamW8BQzxrVnM+PPxYugzLZwHX23yiK(u"ࠪࡠࡳࡢ࡮ࠨፑ")+bbTCMJwEx8nhN4X+ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠫ์๊ࠠหำํำ๋ࠥำฮ๊ࠢิฬࠦวๅ็็ๅࠥลࠡࠨፒ")+NwROdSj3nsA)
		if x6zlf2tTZm!=XEcWOIwkZKubV7vQ(u"࠴ᑰ"): return FFKncZx5pDTwdiJRYhMgQSNL
	succeeded = S5MWhgtZ37Xw
	if XoZRpFe7B6gnfA.path.exists(SgjYGPuifqyamW8BQzxrVnM):
		try: XoZRpFe7B6gnfA.remove(SgjYGPuifqyamW8BQzxrVnM.decode(YWEQ3Cf8RevpD0m7NjF1))
		except:
			try: XoZRpFe7B6gnfA.remove(mfZxOe4AJqvcpFCKhYwRGWtg)
			except Exception as f3xe1K6ndi:
				succeeded = FFKncZx5pDTwdiJRYhMgQSNL
				if showDialogs: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,str(f3xe1K6ndi))
	if showDialogs:
		if succeeded: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,ldIfvn6asURQ9toi85EhqAXW3(u"ࠬ็ิๅฬࠣ฽๊๊๊ส่ࠢืาࠦวๅ็็ๅࠬፓ"))
		else: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,JvQd6LMoBX4hiy1C(u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧፔ"))
	return succeeded
def mJZ2eb9HzawrqRCsU7D6(LxyCDEN26lWUmJcfRMuVZow1Ip4j,YgiVSujm6q9hNQrcLlPMXzBZf,showDialogs):
	if showDialogs:
		x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,LxyCDEN26lWUmJcfRMuVZow1Ip4j+PPxYugzLZwHX23yiK(u"ࠧ࡝ࡰ࡟ࡲࠬፕ")+bbTCMJwEx8nhN4X+mRanX1HZupfSQVB2gsDGUO(u"ࠨ้็ࠤฯื๊ะ่ࠢืาࠦ็ัษࠣห้๋ฬๅัࠣรࠦ࠭ፖ")+NwROdSj3nsA)
		if x6zlf2tTZm!=UnOIK1WBbw2: return FFKncZx5pDTwdiJRYhMgQSNL
	succeeded = S5MWhgtZ37Xw
	if XoZRpFe7B6gnfA.path.exists(LxyCDEN26lWUmJcfRMuVZow1Ip4j):
		for kN0B75b1nSQ3H,RXZOhWQTbJkBC4q,i0gkImCvH1p in XoZRpFe7B6gnfA.walk(LxyCDEN26lWUmJcfRMuVZow1Ip4j,topdown=FFKncZx5pDTwdiJRYhMgQSNL):
			for hhZ6lIumVNX in i0gkImCvH1p:
				i9GKPyIEQjSC6tpgo = XoZRpFe7B6gnfA.path.join(kN0B75b1nSQ3H,hhZ6lIumVNX)
				try: XoZRpFe7B6gnfA.remove(i9GKPyIEQjSC6tpgo)
				except Exception as f3xe1K6ndi:
					succeeded = FFKncZx5pDTwdiJRYhMgQSNL
					if showDialogs: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,str(f3xe1K6ndi))
			if YgiVSujm6q9hNQrcLlPMXzBZf:
				for dir in RXZOhWQTbJkBC4q:
					guESBP6KazmZU = XoZRpFe7B6gnfA.path.join(kN0B75b1nSQ3H,dir)
					try: XoZRpFe7B6gnfA.rmdir(guESBP6KazmZU)
					except: pass
		if YgiVSujm6q9hNQrcLlPMXzBZf:
			try: XoZRpFe7B6gnfA.rmdir(kN0B75b1nSQ3H)
			except: pass
	if showDialogs:
		if succeeded: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,jil8vRpBsENVYyPmDd(u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪፗ"))
		else: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,vzqjsVHSBlMpxC(u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦวๅ็ึัࠬፘ"))
	return succeeded
def zzTUovwI31dFPiMLg4r7G(rj2U9E4KbDMOzpkP,QNwj4Toh3Vk60rfeGyY,RxWJFBAGy4iIM,JEiFBCayPfze7n3KspN6AY,PPblYOcLrJH6QI,FjO41UWNvs0Gg):
	KteRnFMjHpBPqNf8,DG5rzEqHLYk4vA1g6lfReChnQTWd3,sebNaroikFVY6hHj7dMZQfInty,jwsCEuO791RtU = MyP7jWmAVGS8rfN51zdqclDeUs(RxWJFBAGy4iIM)
	X5lnUjdopBiE = QNwj4Toh3Vk60rfeGyY,KteRnFMjHpBPqNf8,JEiFBCayPfze7n3KspN6AY,PPblYOcLrJH6QI
	if rj2U9E4KbDMOzpkP<JvQd6LMoBX4hiy1C(u"࠴ᑱ"):
		aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤ࡛ࡒࡍࡎࡌࡆࠬፙ"),X5lnUjdopBiE)
		rj2U9E4KbDMOzpkP = -rj2U9E4KbDMOzpkP
	if rj2U9E4KbDMOzpkP>DFx6E0uON7Jm8(u"࠵ᑲ"):
		h1hN5GRPeA2YIgmvKax3EMJfu9ilZ = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,HD7MQqXd2gS(u"ࠬࡹࡴࡳࠩፚ"),rCmGE4YIDaZA(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡖࡔࡏࡐࡎࡈࠧ፛"),X5lnUjdopBiE)
		if h1hN5GRPeA2YIgmvKax3EMJfu9ilZ:
			zz3SEjnWHCvyoO(ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠧࡖࡔࡏࡐࡎࡈࠠࠡࡔࡈࡅࡉࡥࡃࡂࡅࡋࡉࠬ፜"),RxWJFBAGy4iIM,JEiFBCayPfze7n3KspN6AY,PPblYOcLrJH6QI,FjO41UWNvs0Gg,QNwj4Toh3Vk60rfeGyY)
			return h1hN5GRPeA2YIgmvKax3EMJfu9ilZ
	h1hN5GRPeA2YIgmvKax3EMJfu9ilZ = YWgBqcEwA5NSUv(QNwj4Toh3Vk60rfeGyY,RxWJFBAGy4iIM,JEiFBCayPfze7n3KspN6AY,PPblYOcLrJH6QI,FjO41UWNvs0Gg)
	if h1hN5GRPeA2YIgmvKax3EMJfu9ilZ and rj2U9E4KbDMOzpkP: WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,gmPI7hVEM8nD(u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡘࡖࡑࡒࡉࡃࠩ፝"),X5lnUjdopBiE,h1hN5GRPeA2YIgmvKax3EMJfu9ilZ,rj2U9E4KbDMOzpkP)
	return h1hN5GRPeA2YIgmvKax3EMJfu9ilZ
def ae0rWS8x6DGQKIMEku9B4YUwz57(wgj0rX5tbcxPulhmny,HUhFj8s60Wg,h10Mtzo3mL=IpFcwrWNgefMym3qta0hYQAzOdE):
	uwqJj3iXmvTx2VY0gZPEQGIBHfoUS8 = KQctJbXeEjDhplqknU3rzi.getSetting(baBcNd81eH5ry2Olp6Mj43(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡨࡩࡵࡴࡤࡸࡪ࠭፞"))
	if uwqJj3iXmvTx2VY0gZPEQGIBHfoUS8 and vzqjsVHSBlMpxC(u"ࠪ࠱ࠬ፟") not in uwqJj3iXmvTx2VY0gZPEQGIBHfoUS8: mmpqeadyUFbYhXR7fsHMQN1wlu6LDI,k2s9vYhM8d01LNZeyJAbwVuFWC = int(uwqJj3iXmvTx2VY0gZPEQGIBHfoUS8),S5MWhgtZ37Xw
	elif h10Mtzo3mL: mmpqeadyUFbYhXR7fsHMQN1wlu6LDI,k2s9vYhM8d01LNZeyJAbwVuFWC = h10Mtzo3mL,FFKncZx5pDTwdiJRYhMgQSNL
	else: return []
	SyaX1RQeYUAZrVhTjJuo96N2,G9j7whZ5byWcOfmx3HkFLAUg = [],nA5dhMRg6ENzsB0l1GwvH7aIr2
	o9d8DnRA4ZvmOrJhfKa2CFE,AsTveQbzZtWlkfu3cILXg,Ay6NYpB34OZ1Hs,r5yTdDPsB8A = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,IpFcwrWNgefMym3qta0hYQAzOdE,IpFcwrWNgefMym3qta0hYQAzOdE
	HUhFj8s60Wg = sorted(HUhFj8s60Wg,reverse=S5MWhgtZ37Xw,key=lambda key: (key[UnOIK1WBbw2],key[udq5tP0hwifHQCGYELDbOUI]))
	for stream,HBDWpnczoGFTCJhkMLNVjXl9mSK,OTQCuS0y4RDU8abeZ in HUhFj8s60Wg+[[nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,IpFcwrWNgefMym3qta0hYQAzOdE]]:
		if HBDWpnczoGFTCJhkMLNVjXl9mSK==G9j7whZ5byWcOfmx3HkFLAUg:
			if OTQCuS0y4RDU8abeZ>mmpqeadyUFbYhXR7fsHMQN1wlu6LDI: AsTveQbzZtWlkfu3cILXg,r5yTdDPsB8A = stream,OTQCuS0y4RDU8abeZ
			elif not o9d8DnRA4ZvmOrJhfKa2CFE: o9d8DnRA4ZvmOrJhfKa2CFE,Ay6NYpB34OZ1Hs = stream,OTQCuS0y4RDU8abeZ
		else:
			if AsTveQbzZtWlkfu3cILXg or o9d8DnRA4ZvmOrJhfKa2CFE:
				if o9d8DnRA4ZvmOrJhfKa2CFE: SyaX1RQeYUAZrVhTjJuo96N2.append([o9d8DnRA4ZvmOrJhfKa2CFE,G9j7whZ5byWcOfmx3HkFLAUg,Ay6NYpB34OZ1Hs])
				elif AsTveQbzZtWlkfu3cILXg: SyaX1RQeYUAZrVhTjJuo96N2.append([AsTveQbzZtWlkfu3cILXg,G9j7whZ5byWcOfmx3HkFLAUg,r5yTdDPsB8A])
			if OTQCuS0y4RDU8abeZ>mmpqeadyUFbYhXR7fsHMQN1wlu6LDI:
				AsTveQbzZtWlkfu3cILXg,r5yTdDPsB8A = stream,OTQCuS0y4RDU8abeZ
				o9d8DnRA4ZvmOrJhfKa2CFE,Ay6NYpB34OZ1Hs = nA5dhMRg6ENzsB0l1GwvH7aIr2,IpFcwrWNgefMym3qta0hYQAzOdE
			else:
				AsTveQbzZtWlkfu3cILXg,r5yTdDPsB8A = nA5dhMRg6ENzsB0l1GwvH7aIr2,IpFcwrWNgefMym3qta0hYQAzOdE
				o9d8DnRA4ZvmOrJhfKa2CFE,Ay6NYpB34OZ1Hs = stream,OTQCuS0y4RDU8abeZ
		G9j7whZ5byWcOfmx3HkFLAUg = HBDWpnczoGFTCJhkMLNVjXl9mSK
	if k2s9vYhM8d01LNZeyJAbwVuFWC:
		ne6z1JudcGlW07BD9Hgw3irs,x3wugjEtcQmJTBv0X8ndG2,uuiGoZhP4NOKvICWeyBVQ1M9fq = zip(*SyaX1RQeYUAZrVhTjJuo96N2)
		dNLAtBySbVUXh6j5kc = [FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠫࡲࡶ࠴ࠨ፠"),gmPI7hVEM8nD(u"ࠬࡳࡰࡥࠩ፡"),rCmGE4YIDaZA(u"࠭ࡴࡴࠩ።"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠧ࡮࠵ࡸࠫ፣")]
		for HBDWpnczoGFTCJhkMLNVjXl9mSK in dNLAtBySbVUXh6j5kc:
			if HBDWpnczoGFTCJhkMLNVjXl9mSK in x3wugjEtcQmJTBv0X8ndG2:
				index = x3wugjEtcQmJTBv0X8ndG2.index(HBDWpnczoGFTCJhkMLNVjXl9mSK)
				SyaX1RQeYUAZrVhTjJuo96N2 = [[ne6z1JudcGlW07BD9Hgw3irs[index],x3wugjEtcQmJTBv0X8ndG2[index],uuiGoZhP4NOKvICWeyBVQ1M9fq[index]]]
				break
	return SyaX1RQeYUAZrVhTjJuo96N2
def RL95rqviDebl4jcWynm7VEaug2(RjieJlz6cK10gSqrLa8k3TQWwAtm):
	Cp1gVNwaYDlZ7,sLh9jdJxM0u3nl4wIvAbOG52Bo = [],YWylfpKSRb
	for whXU4NCbPdFAcxErVJIutR8WDM3n in f6U7kuwg2zqXCTx0Gs8HJh1v:
		if whXU4NCbPdFAcxErVJIutR8WDM3n==Yj1msqVeivESfrCupRy9b7WacBd(u"ࠨࡒࡕࡍ࡛ࡇࡔࡆࠩ፤"): sLh9jdJxM0u3nl4wIvAbOG52Bo = (lw2snZ9J0uhLoxypqa(u"ࠩ࡯࡭ࡳࡱࠧ፥"),bbTCMJwEx8nhN4X+LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"้ࠪํอโฺࠢึ๎ึ็ัศฬࠣาฬ฻ษࠡ࠯ࠣๆ้๐ไสࠢสฺ่๊วไๆࠪ፦")+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,gmPI7hVEM8nD(u"࠷࠵࠸ᑳ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2)
		elif whXU4NCbPdFAcxErVJIutR8WDM3n==gmPI7hVEM8nD(u"ࠫࡒࡏࡘࡆࡆࠪ፧"): sLh9jdJxM0u3nl4wIvAbOG52Bo = (JvQd6LMoBX4hiy1C(u"ࠬࡲࡩ࡯࡭ࠪ፨"),bbTCMJwEx8nhN4X+FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠭ๅ้ษๅ฽ู๊ࠥาใิหฯࠦฮศืฬࠤํ฿วๆหࠣ࠱้ࠥห๋ำฬࠤฬ๊ๅีษๆ่ࠬ፩")+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,zhE5I4xHinX0UoVZMNwlkPrR(u"࠱࠶࠹ᑴ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2)
		elif whXU4NCbPdFAcxErVJIutR8WDM3n==baBcNd81eH5ry2Olp6Mj43(u"ࠧࡑࡗࡅࡐࡎࡉࠧ፪"): sLh9jdJxM0u3nl4wIvAbOG52Bo = (w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠨ࡮࡬ࡲࡰ࠭፫"),bbTCMJwEx8nhN4X+lw2snZ9J0uhLoxypqa(u"่ࠩ์ฬู่ࠡีํีๆืวหࠢ฼ห๊ฯࠠ࠮ࠢๆฯ๏ืษࠡษ็ู้อใๅࠩ፬")+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,nfNTgkiWdUq(u"࠲࠷࠺ᑵ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2)
		if whXU4NCbPdFAcxErVJIutR8WDM3n not in RjieJlz6cK10gSqrLa8k3TQWwAtm: continue
		if sLh9jdJxM0u3nl4wIvAbOG52Bo:
			Cp1gVNwaYDlZ7.append(sLh9jdJxM0u3nl4wIvAbOG52Bo)
			sLh9jdJxM0u3nl4wIvAbOG52Bo = YWylfpKSRb
		if whXU4NCbPdFAcxErVJIutR8WDM3n not in [ldIfvn6asURQ9toi85EhqAXW3(u"ࠪࡔࡗࡏࡖࡂࡖࡈࠫ፭"),mRanX1HZupfSQVB2gsDGUO(u"ࠫࡒࡏࡘࡆࡆࠪ፮"),DFx6E0uON7Jm8(u"ࠬࡖࡕࡃࡎࡌࡇࠬ፯")]: Cp1gVNwaYDlZ7.append(whXU4NCbPdFAcxErVJIutR8WDM3n)
	return Cp1gVNwaYDlZ7
def fupUhlX2VEM4(nbOtpdXAxSTIvfBa,args=[]):
	Yt93BCDAfS4RcrKygiNH0bwELjM67k = {Yj1msqVeivESfrCupRy9b7WacBd(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ፰"):bb1fgjsAq4N2xYwnoh39lm(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡰࡳࡰࡰࠪ፱")}
	DDQYF9rgkzA,hBDJc1Hnex9faguV,MOjXugIEba95W03H84PtTYwvSo7QJ = ldIfvn6asURQ9toi85EhqAXW3(u"ࠨࡸࡦࡦࡨ࠼࠵࠴࠶࠹࡫࡫࡮ࡢ࡯ࡻࡰࡹ࡯ࡱࠧ፲"),rCmGE4YIDaZA(u"ࠩ࠷࠷ࡻࡩࡶ࠴ࡦࡩ࡫࡯ࡱ࡯࠸࠺ࡶࡼࡿࡪ࠲ࠨ፳"),int(h0skHe7TcIY9x1UP5VBrZAE8dKGnl.time())
	fXBtHeUEMgQFbASoOnrqdGhm8TKv = DDQYF9rgkzA+mW5pDRIgwQ8n+str(MOjXugIEba95W03H84PtTYwvSo7QJ)+s5WcxEPjUBokapYMhAwb60dvgi+hBDJc1Hnex9faguV
	barWI0ALHCiKu3vkd = l4pFeYACHV1.md5(fXBtHeUEMgQFbASoOnrqdGhm8TKv.encode(gmPI7hVEM8nD(u"ࠪࡹࡹ࡬࠸ࠨ፴"))).hexdigest()[:vzqjsVHSBlMpxC(u"࠵࠵ᑶ")]
	iua93DSoA1 = {Qy6wlfLoOpg1(u"ࠫ࡯ࡹࡣࡰࡦࡨࠫ፵"):nbOtpdXAxSTIvfBa,HD7MQqXd2gS(u"ࠬࡧࡲࡨࡵࠪ፶"):args,mRanX1HZupfSQVB2gsDGUO(u"࠭ࡵࡴࡧࡵࠫ፷"):mW5pDRIgwQ8n,jil8vRpBsENVYyPmDd(u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ፸"):s5WcxEPjUBokapYMhAwb60dvgi,nfNTgkiWdUq(u"ࠨ࡫ࡧࡷࠬ፹"):barWI0ALHCiKu3vkd}
	iua93DSoA1 = DcFpQN9gqn.dumps(iua93DSoA1)
	PRa9Yj3C6BSXKpTFdOZHQUs8WrwmxM = Nzp9Fq5cTr.SITESURLS[lw2snZ9J0uhLoxypqa(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ፺")][pxt6wJ8ScYMWCivoO(u"࠴࠴ᑷ")]
	steLxydUG9DKVnFOi1gRZbhEIk = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠪࡔࡔ࡙ࡔࠨ፻"),PRa9Yj3C6BSXKpTFdOZHQUs8WrwmxM,iua93DSoA1,Yt93BCDAfS4RcrKygiNH0bwELjM67k,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,lw2snZ9J0uhLoxypqa(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡆࡅࡘࡘࡊࡥࡊࡔ࠯࠴ࡷࡹ࠭፼"))
	uzRj7xMiWN39n2Aq = steLxydUG9DKVnFOi1gRZbhEIk.content
	return uzRj7xMiWN39n2Aq
def b8iUa52sRO7MgJF09t(tx6LOZzwvpqsYE5dr8U0Jao3PSI7W,timeout,KpV0Gs7Fxl,VVETW87go5k,f70aTgEKUCMtkxVh):
	bUsHI3nkgytNxKMfYjw0X7rSC58FL = FFKncZx5pDTwdiJRYhMgQSNL
	for Sgk0OmqbWpuPH5cy1 in tx6LOZzwvpqsYE5dr8U0Jao3PSI7W:
		Sgk0OmqbWpuPH5cy1.start()
		h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(KpV0Gs7Fxl)
		bUsHI3nkgytNxKMfYjw0X7rSC58FL = f70aTgEKUCMtkxVh()
		if bUsHI3nkgytNxKMfYjw0X7rSC58FL: break
	else:
		EPAvdGRnTxszF5IfJ0 = int(timeout-len(tx6LOZzwvpqsYE5dr8U0Jao3PSI7W)*KpV0Gs7Fxl)
		if EPAvdGRnTxszF5IfJ0>IpFcwrWNgefMym3qta0hYQAzOdE:
			for eIlXpH1gLhmP4w3 in range(EPAvdGRnTxszF5IfJ0//VVETW87go5k):
				h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(VVETW87go5k)
				bUsHI3nkgytNxKMfYjw0X7rSC58FL = f70aTgEKUCMtkxVh()
				if bUsHI3nkgytNxKMfYjw0X7rSC58FL: break
	for Sgk0OmqbWpuPH5cy1 in tx6LOZzwvpqsYE5dr8U0Jao3PSI7W:
		try: Sgk0OmqbWpuPH5cy1.join(KpV0Gs7Fxl)
		except: pass
	return bUsHI3nkgytNxKMfYjw0X7rSC58FL
def uCXFHaxhO8lNMQyTzktcV6DWoe0P(gvwcPho2QbKNM6fTx9r75G1DueF=vaCVgh7E5l9NP1kYIGFiT):
	E0EjyrC3knbBuUiZJK2VA = gmPI7hVEM8nD(u"࠵࠵࠸࠴ᑸ")
	UUpSCmK5G6YfL = IpFcwrWNgefMym3qta0hYQAzOdE
	if not UUpSCmK5G6YfL:
		try:
			import shutil as ap1IxbTCS3JgfBnv
			UUpSCmK5G6YfL = ap1IxbTCS3JgfBnv.disk_usage(gvwcPho2QbKNM6fTx9r75G1DueF).free
		except: pass
	if not UUpSCmK5G6YfL and hasattr(XoZRpFe7B6gnfA,zhE5I4xHinX0UoVZMNwlkPrR(u"ࠬࡹࡴࡢࡶࡹࡪࡸ࠭፽")):
		try:
			gguDmAIf3UiL6sczxyapJkWE = XoZRpFe7B6gnfA.statvfs(gvwcPho2QbKNM6fTx9r75G1DueF)
			UUpSCmK5G6YfL = gguDmAIf3UiL6sczxyapJkWE.f_frsize * gguDmAIf3UiL6sczxyapJkWE.f_bavail
		except: pass
	if not UUpSCmK5G6YfL and hasattr(XoZRpFe7B6gnfA,FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠭ࡦࡴࡶࡤࡸࡻ࡬ࡳࠨ፾")):
		try:
			gguDmAIf3UiL6sczxyapJkWE = XoZRpFe7B6gnfA.fstatvfs(gvwcPho2QbKNM6fTx9r75G1DueF)
			UUpSCmK5G6YfL = gguDmAIf3UiL6sczxyapJkWE.f_frsize * gguDmAIf3UiL6sczxyapJkWE.f_bavail
		except: pass
	if not UUpSCmK5G6YfL and kCNHMOym1luTnJ0.platform == LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠧࡸ࡫ࡱ࠷࠷࠭፿"):
		try:
			import ctypes as y0g6cZUPFVMtjkYXvCJW
			Fp1MkolqCXPnKQfy = y0g6cZUPFVMtjkYXvCJW.c_ulonglong(IpFcwrWNgefMym3qta0hYQAzOdE)
			y0g6cZUPFVMtjkYXvCJW.windll.kernel32.GetDiskFreeSpaceExW(y0g6cZUPFVMtjkYXvCJW.c_wchar_p(gvwcPho2QbKNM6fTx9r75G1DueF),None,None,y0g6cZUPFVMtjkYXvCJW.pointer(Fp1MkolqCXPnKQfy))
			UUpSCmK5G6YfL = Fp1MkolqCXPnKQfy.value
		except: pass
	if not UUpSCmK5G6YfL:
		try:
			XI2nt9hqdTP8i = SoNGUfhMDERLyHOz1qkVAj.getInfoLabel(YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡈࡵࡩࡪ࡙ࡰࡢࡥࡨࠫᎀ"))
			DA96sFgTw1qzCXdvut0o7 = PAztbuyYo4Kvd.findall(JvQd6LMoBX4hiy1C(u"ࠩ࡟ࡨ࠰࠮࠿࠻࡞࠱ࡠࡩ࠱ࠩࡀࠩᎁ"),XI2nt9hqdTP8i,PAztbuyYo4Kvd.DOTALL)
			if DA96sFgTw1qzCXdvut0o7:
				DA96sFgTw1qzCXdvut0o7 = float(DA96sFgTw1qzCXdvut0o7[DFx6E0uON7Jm8(u"࠵ᑹ")])
				if   bb1fgjsAq4N2xYwnoh39lm(u"ࠪࡘࠬᎂ") in XI2nt9hqdTP8i: UUpSCmK5G6YfL = DA96sFgTw1qzCXdvut0o7*E0EjyrC3knbBuUiZJK2VA**tpMX1Bgs0bzv8OEafyW
				elif xwIUQfiE7rmvYzH(u"ࠫࡌ࠭ᎃ") in XI2nt9hqdTP8i: UUpSCmK5G6YfL = DA96sFgTw1qzCXdvut0o7*E0EjyrC3knbBuUiZJK2VA**AH0zdvBqibaXY
				elif lw2snZ9J0uhLoxypqa(u"ࠬࡓࠧᎄ") in XI2nt9hqdTP8i: UUpSCmK5G6YfL = DA96sFgTw1qzCXdvut0o7*E0EjyrC3knbBuUiZJK2VA**udq5tP0hwifHQCGYELDbOUI
				elif w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠭ࡋࠨᎅ") in XI2nt9hqdTP8i: UUpSCmK5G6YfL = DA96sFgTw1qzCXdvut0o7*E0EjyrC3knbBuUiZJK2VA
				else: UUpSCmK5G6YfL = DA96sFgTw1qzCXdvut0o7
		except: pass
	if not UUpSCmK5G6YfL: UUpSCmK5G6YfL = PPxYugzLZwHX23yiK(u"࠿࠹࠺࠻࠼࠽࠾࠿࠹࠺࠻࠼࠽࠾࠿ᑺ")
	return int(UUpSCmK5G6YfL)
def ighZbvAKDn4N():
	xg2Z3VhKBUHwofGATWeyPD0nlqOYv = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠧ࡭࡫ࡶࡸࠬᎆ"),zhE5I4xHinX0UoVZMNwlkPrR(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࡣ࠷࠭ᎇ"),pxt6wJ8ScYMWCivoO(u"ࠩࡖࡍ࡙ࡋࡓࡠࡗࡖࡅࡌࡋࠧᎈ"))
	if xg2Z3VhKBUHwofGATWeyPD0nlqOYv: return xg2Z3VhKBUHwofGATWeyPD0nlqOYv
	hwZT5nYUGQ1RJC = {VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠪࡥࠬᎉ"):VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠫࡦ࠭ᎊ")}
	url = Nzp9Fq5cTr.SITESURLS[yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬᎋ")][UnOIK1WBbw2]
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(yy6RomT9bQhJf,ldIfvn6asURQ9toi85EhqAXW3(u"࠭ࡐࡐࡕࡗࠫᎌ"),url,hwZT5nYUGQ1RJC,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡊࡉ࡙ࡥࡓࡊࡖࡈࡗࡤ࡛ࡓࡂࡉࡈ࠱࠶ࡹࡴࠨᎍ"))
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	kl2ZWdy8rXcHT = kl2ZWdy8rXcHT.replace(AJHaiQq3PRd5cphzGuELnVg9X(u"ࠨࡗࡱ࡭ࡹ࡫ࡤࠡࡕࡷࡥࡹ࡫ࡳࠨᎎ"),lw2snZ9J0uhLoxypqa(u"ࠩࡘࡗࡆ࠭ᎏ"))
	kl2ZWdy8rXcHT = kl2ZWdy8rXcHT.replace(bb1fgjsAq4N2xYwnoh39lm(u"࡙ࠪࡳ࡯ࡴࡦࡦࠣࡏ࡮ࡴࡧࡥࡱࡰࠫ᎐"),mRanX1HZupfSQVB2gsDGUO(u"࡚ࠫࡑࠧ᎑"))
	kl2ZWdy8rXcHT = kl2ZWdy8rXcHT.replace(VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࡛ࠬ࡮ࡪࡶࡨࡨࠥࡇࡲࡢࡤࠣࡉࡲ࡯ࡲࡢࡶࡨࡷࠬ᎒"),UUobzy0xZLaVScIt7(u"࠭ࡕࡂࡇࠪ᎓"))
	kl2ZWdy8rXcHT = kl2ZWdy8rXcHT.replace(lw2snZ9J0uhLoxypqa(u"ࠧࡔࡣࡸࡨ࡮ࠦࡁࡳࡣࡥ࡭ࡦ࠭᎔"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠨࡍࡖࡅࠬ᎕"))
	kl2ZWdy8rXcHT = kl2ZWdy8rXcHT.replace(Qy6wlfLoOpg1(u"ࠩࡑࡳࡷࡺࡨࠡࡏࡤࡧࡪࡪ࡯࡯࡫ࡤࠫ᎖"),vzqjsVHSBlMpxC(u"ࠪࡒ࠳ࡓࡡࡤࡧࡧࡳࡳ࡯ࡡࠨ᎗"))
	kl2ZWdy8rXcHT = kl2ZWdy8rXcHT.replace(ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠫ࡜࡫ࡳࡵࡧࡵࡲ࡙ࠥࡡࡩࡣࡵࡥࠬ᎘"),bb1fgjsAq4N2xYwnoh39lm(u"ࠬ࡝࠮ࡔࡣ࡫ࡥࡷࡧࠧ᎙"))
	kl2ZWdy8rXcHT = kl2ZWdy8rXcHT.replace(zhE5I4xHinX0UoVZMNwlkPrR(u"࠭࡟ࡠࡡࠪ᎚"),BSiDxUPsdHkz27VMop51uf6c3)
	try: iI0NbuVHsG87h9pCMLR4632YaFv = BwGPDSQOlfUas2n3eIH0ycFRWZ(YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠧ࡭࡫ࡶࡸࠬ᎛"),kl2ZWdy8rXcHT)
	except:
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,XEcWOIwkZKubV7vQ(u"ࠨใื่ࠥ็๊ࠡฮ็ฬ๋ࠥอห๊ํหฯࠦสใำํีࠥอไศีอาิอๅࠨ᎜"))
		return
	ZDNlg4rY0IyGQhn,GsOveSI8PFKatu6bJC24nD7,loVxr85jutg = iI0NbuVHsG87h9pCMLR4632YaFv
	ZFTd57sHPWQYvz1yhjX8GSroNIMwL0,Km5BFgNeECnzdwu263Y = [],[]
	for whXU4NCbPdFAcxErVJIutR8WDM3n,iMjldOyT8rHzKcCw6Rpn4mg70tU5f,tYGhkdaFgPibTzu6vyMA in GsOveSI8PFKatu6bJC24nD7:
		if iMjldOyT8rHzKcCw6Rpn4mg70tU5f.isdigit(): iMjldOyT8rHzKcCw6Rpn4mg70tU5f = vzqjsVHSBlMpxC(u"ࠩ࡫࡭࡬࡮ࡵࡴࡣࡪࡩࠬ᎝") if int(iMjldOyT8rHzKcCw6Rpn4mg70tU5f)>gmPI7hVEM8nD(u"࠵࠱ᑻ") else lw2snZ9J0uhLoxypqa(u"ࠪࡰࡴࡽࡵࡴࡣࡪࡩࠬ᎞")
		if whXU4NCbPdFAcxErVJIutR8WDM3n not in Nzp9Fq5cTr.non_videos_actions:
			if   iMjldOyT8rHzKcCw6Rpn4mg70tU5f==VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠫ࡭࡯ࡧࡩࡷࡶࡥ࡬࡫ࠧ᎟"): ZFTd57sHPWQYvz1yhjX8GSroNIMwL0.append(whXU4NCbPdFAcxErVJIutR8WDM3n)
			elif iMjldOyT8rHzKcCw6Rpn4mg70tU5f==VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠬࡲ࡯ࡸࡷࡶࡥ࡬࡫ࠧᎠ"): Km5BFgNeECnzdwu263Y.append(whXU4NCbPdFAcxErVJIutR8WDM3n)
	WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,UUobzy0xZLaVScIt7(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࡡ࠵ࠫᎡ"),baBcNd81eH5ry2Olp6Mj43(u"ࠧࡔࡋࡗࡉࡘࡥࡕࡔࡃࡊࡉࠬᎢ"),[iI0NbuVHsG87h9pCMLR4632YaFv,ZFTd57sHPWQYvz1yhjX8GSroNIMwL0,Km5BFgNeECnzdwu263Y],QdwW2s0iEp56qMmvCbOeLxBRU)
	return iI0NbuVHsG87h9pCMLR4632YaFv,ZFTd57sHPWQYvz1yhjX8GSroNIMwL0,Km5BFgNeECnzdwu263Y
from RPSIjmHDU4 import *
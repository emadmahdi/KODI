# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'ARABSEED'
headers = {'User-Agent':oOb8ZS417GwudNKHU6y()}
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_ARS_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
SAsGubf1jW2Q3p = ['الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==250: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==251: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,text)
	elif mode==252: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==253: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LLabVp7hzj28CE0f1udx(url)
	elif mode==254: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = NNihMcqGKQEvLz6l(url,'CATEGORIES___'+text)
	elif mode==255: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = NNihMcqGKQEvLz6l(url,'FILTERS___'+text)
	elif mode==256: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = oWcvptkU2JObI0(url,text)
	elif mode==259: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',GiqvpBF9xLEdHDr37byJSngeCQ+'/main',nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ARABSEED-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,259,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فلتر محدد',GiqvpBF9xLEdHDr37byJSngeCQ+'/category/اخرى',254)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فلتر كامل',GiqvpBF9xLEdHDr37byJSngeCQ+'/category/اخرى',255)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'المميزة',GiqvpBF9xLEdHDr37byJSngeCQ+'/main',251,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'featured_main')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'جديد الأفلام',GiqvpBF9xLEdHDr37byJSngeCQ+'/main',251,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'new_movies')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'جديد الحلقات',GiqvpBF9xLEdHDr37byJSngeCQ+'/main',251,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'new_episodes')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'المضاف حديثاً',GiqvpBF9xLEdHDr37byJSngeCQ+'/latest',251,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'lastest')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	N5Vbkn2chPGfT3m97Bv1LHKI = PAztbuyYo4Kvd.findall('class="MenuHeader"(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	YERWNbgAThV2uBr5taO8zcd = N5Vbkn2chPGfT3m97Bv1LHKI[0]
	hn2rCExmu5pgejyYOT = PAztbuyYo4Kvd.findall('href="(.*?)".*?>(.*?)<',YERWNbgAThV2uBr5taO8zcd,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title in hn2rCExmu5pgejyYOT:
		title = HH8SJuswDBPtniebmkXIr(title)
		if title not in SAsGubf1jW2Q3p and title!=nA5dhMRg6ENzsB0l1GwvH7aIr2:
			if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,256)
	return kl2ZWdy8rXcHT
def oWcvptkU2JObI0(url,type):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ARABSEED-SUBMENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	if 'class="SliderInSection' in kl2ZWdy8rXcHT: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الأكثر مشاهدة',url,251,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'most')
	if 'class="MainSlides' in kl2ZWdy8rXcHT: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'المميزة',url,251,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'featured')
	if 'class="LinksList' in kl2ZWdy8rXcHT:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="LinksList(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			if len(zz3eHskxE6lAyDR5cNj1ug)>1 and type=='new_episodes': WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[1]
			items = PAztbuyYo4Kvd.findall('href="(.*?)"(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,title in items:
				g7qwMTAPoVpIyQUaDeNOnhvs = PAztbuyYo4Kvd.findall('</i>(.*?)<span>(.*?)<',title,PAztbuyYo4Kvd.DOTALL)
				try: QUevxqzda3 = g7qwMTAPoVpIyQUaDeNOnhvs[0][0].replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c)
				except: QUevxqzda3 = nA5dhMRg6ENzsB0l1GwvH7aIr2
				try: ttb1zM62VP7gNonFQdhuxUwRy = g7qwMTAPoVpIyQUaDeNOnhvs[0][1].replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c)
				except: ttb1zM62VP7gNonFQdhuxUwRy = nA5dhMRg6ENzsB0l1GwvH7aIr2
				g7qwMTAPoVpIyQUaDeNOnhvs = QUevxqzda3+hSXlxL9iB05c+ttb1zM62VP7gNonFQdhuxUwRy
				if '<strong>' in title:
					aKpdNiIfkFzyu9XH0J65BwA31vnM = PAztbuyYo4Kvd.findall('</i>(.*?)<',title,PAztbuyYo4Kvd.DOTALL)
					if aKpdNiIfkFzyu9XH0J65BwA31vnM: g7qwMTAPoVpIyQUaDeNOnhvs = aKpdNiIfkFzyu9XH0J65BwA31vnM[0]
				if not g7qwMTAPoVpIyQUaDeNOnhvs:
					aKpdNiIfkFzyu9XH0J65BwA31vnM = PAztbuyYo4Kvd.findall('alt="(.*?)"',title,PAztbuyYo4Kvd.DOTALL)
					if aKpdNiIfkFzyu9XH0J65BwA31vnM: g7qwMTAPoVpIyQUaDeNOnhvs = aKpdNiIfkFzyu9XH0J65BwA31vnM[0]
				if g7qwMTAPoVpIyQUaDeNOnhvs:
					if 'key=' in ZylHkumQ8zD0: type = ZylHkumQ8zD0.split('key=')[1]
					else: type = 'newest'
					g7qwMTAPoVpIyQUaDeNOnhvs = g7qwMTAPoVpIyQUaDeNOnhvs.strip(hSXlxL9iB05c)
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+g7qwMTAPoVpIyQUaDeNOnhvs,ZylHkumQ8zD0,251,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,type)
	return
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,type):
	plbraNGcCgKzO4xjVIwshTLoW,data,items = 'GET',nA5dhMRg6ENzsB0l1GwvH7aIr2,[]
	if type=='filters':
		if '?' in url:
			QF6HsoZefWPVzxn,rA4ZGoQyIHlneVfzNukWd = 'POST',{}
			KteRnFMjHpBPqNf8,GnCJElcXiOjWPvufk8gxU = url.split('?')
			Df6jx49PNm8 = GnCJElcXiOjWPvufk8gxU.split('&')
			for PWjQyhAkS3RaGzNJUTvC6HiXsOLY in Df6jx49PNm8:
				key,value = PWjQyhAkS3RaGzNJUTvC6HiXsOLY.split('=')
				rA4ZGoQyIHlneVfzNukWd[key] = value
			if Df6jx49PNm8: plbraNGcCgKzO4xjVIwshTLoW,url,data = QF6HsoZefWPVzxn,KteRnFMjHpBPqNf8,rA4ZGoQyIHlneVfzNukWd
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,plbraNGcCgKzO4xjVIwshTLoW,url,data,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ARABSEED-TITLES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	if type=='filters': zz3eHskxE6lAyDR5cNj1ug = [kl2ZWdy8rXcHT]
	elif 'featured' in type: zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="MainSlides(.*?)class="LinksList',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	elif type=='new_movies': zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('جديد الافلام.*?class="SliderInSection"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	elif type=='new_episodes': zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('جديد الحلقات.*?class="SliderInSection"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	elif type=='most': zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="SliderInSection(.*?)class="LinksList',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	else: zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="Blocks-UL"(.*?)class="AboElSeed"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if 'featured' in type:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		PDA4n3y2WX = PAztbuyYo4Kvd.findall('href="(.*?)" title="(.*?)".*?data-lazy.*? (src|data-image)="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if PDA4n3y2WX:
			ce9zAaVFswSq6lLr82DfQyotGW,ecU4Hy7lNS,yyknP0EuXwJmvz6pUgR7FNQ,A7cIH0dQfVkM3Uxs14O9nGtoN = zip(*PDA4n3y2WX)
			items = zip(ce9zAaVFswSq6lLr82DfQyotGW,A7cIH0dQfVkM3Uxs14O9nGtoN,ecU4Hy7lNS)
	else:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('LoadingArea.*? href="(.*?)".*? data-\w{3,5}="(.*?)".*? alt="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	u0UiTmzYN6I3Q9eCZVoB = []
	for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
		if 'WWE' in title: continue
		title = HH8SJuswDBPtniebmkXIr(title)
		if 'الحلقة' in title:
			JfNHOP2BK1Yxl7Rq4 = PAztbuyYo4Kvd.findall('(.*?) الحلقة \d+',title,PAztbuyYo4Kvd.DOTALL)
			if JfNHOP2BK1Yxl7Rq4:
				title = '_MOD_' + JfNHOP2BK1Yxl7Rq4[0]
				if title not in u0UiTmzYN6I3Q9eCZVoB:
					u0UiTmzYN6I3Q9eCZVoB.append(title)
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,253,HRlygv7YwjzbSLt8fkEerq2)
			else: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,252,HRlygv7YwjzbSLt8fkEerq2)
		elif '/selary/' in ZylHkumQ8zD0 or 'مسلسل' in title:
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,253,HRlygv7YwjzbSLt8fkEerq2)
		else:
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,252,HRlygv7YwjzbSLt8fkEerq2)
	if type in ['newest','best','most']:
		items = PAztbuyYo4Kvd.findall('page-numbers" href="(.*?)">(.*?)<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
			ZylHkumQ8zD0 = HH8SJuswDBPtniebmkXIr(ZylHkumQ8zD0)
			title = HH8SJuswDBPtniebmkXIr(title)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+title,ZylHkumQ8zD0,251,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,type)
	return
def LLabVp7hzj28CE0f1udx(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ARABSEED-EPISODES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	kl2ZWdy8rXcHT = kl2ZWdy8rXcHT[10000:]
	items = PAztbuyYo4Kvd.findall('data-src="(.*?)".*?alt="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if not items: return
	HRlygv7YwjzbSLt8fkEerq2,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(hSXlxL9iB05c)
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(hSXlxL9iB05c)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="ContainerEpisodesList"(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?<em>(.*?)</em>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,JfNHOP2BK1Yxl7Rq4 in items:
			title = name+' - الحلقة رقم '+JfNHOP2BK1Yxl7Rq4
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,252,HRlygv7YwjzbSLt8fkEerq2)
	else: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'ملف التشغيل',url,252,HRlygv7YwjzbSLt8fkEerq2)
	return
def CCRIBlxTNgk16yua48QjJeoO5pS(title,ZylHkumQ8zD0):
	g7qwMTAPoVpIyQUaDeNOnhvs = PAztbuyYo4Kvd.findall('[a-zA-Z-]+',title,PAztbuyYo4Kvd.DOTALL)
	if g7qwMTAPoVpIyQUaDeNOnhvs: title = g7qwMTAPoVpIyQUaDeNOnhvs[0]
	else: title = title+hSXlxL9iB05c+C2gnJ5tXFk9pAL(ZylHkumQ8zD0,'name')
	title = title.replace('عرب سيد',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('مباشر',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('مشاهدة',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	title = title.replace('ٍ',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	title = title.replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c).replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c)
	return title
def lNBcUr8RCn(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ARABSEED-PLAY-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	KteRnFMjHpBPqNf8 = Y3SmVGbfNvEeakMBr.url
	DQ7XgFltujVL = C2gnJ5tXFk9pAL(KteRnFMjHpBPqNf8,'url')
	headers['Referer'] = DQ7XgFltujVL+'/'
	headers['Content-Type'] = 'application/x-www-form-urlencoded'
	ce9zAaVFswSq6lLr82DfQyotGW,Oa1D8NYLrVM9 = [],[]
	s1GTeX8VlcUJ7Mp4d0gQa,T4IjbVChMQ2n8yo0FpXUra,bliwCgFTapm8qZL = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	qdPSy3N9uYRcj8roBJlMmHWDUKeEfi,C7g3PH2dIspQkiBtf,nAqEHJtQcVPpBoi69sX40 = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	XQfWqvF5ulBh8j74HnDULC = PAztbuyYo4Kvd.findall('"WatchButtons"(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if XQfWqvF5ulBh8j74HnDULC:
		WWU7QJP2tyTRLIfDh0csxbkvX = XQfWqvF5ulBh8j74HnDULC[IpFcwrWNgefMym3qta0hYQAzOdE]
		if '<form' in WWU7QJP2tyTRLIfDh0csxbkvX:
			Oa1D8NYLrVM9 = PAztbuyYo4Kvd.findall('<form action="(.*?)".*?name="(.*?)".*?value="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			if Oa1D8NYLrVM9:
				plbraNGcCgKzO4xjVIwshTLoW = 'POST'
				for xzPTbdUKmfL7ly8,name,value in Oa1D8NYLrVM9:
					if 'wpost' in name: s1GTeX8VlcUJ7Mp4d0gQa,T4IjbVChMQ2n8yo0FpXUra,bliwCgFTapm8qZL = xzPTbdUKmfL7ly8,name,value
					elif 'dpost' in name: qdPSy3N9uYRcj8roBJlMmHWDUKeEfi,C7g3PH2dIspQkiBtf,nAqEHJtQcVPpBoi69sX40 = xzPTbdUKmfL7ly8,name,value
				UY52vkIEOe71mXLVHWxQMufBFyr6 = T4IjbVChMQ2n8yo0FpXUra+'='+bliwCgFTapm8qZL
				onW8PAdCQV0pHg9DxByJ4Fa5IrZ6 = C7g3PH2dIspQkiBtf+'='+nAqEHJtQcVPpBoi69sX40
		else:
			Oa1D8NYLrVM9 = PAztbuyYo4Kvd.findall('href="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			if Oa1D8NYLrVM9:
				plbraNGcCgKzO4xjVIwshTLoW = 'GET'
				for ZylHkumQ8zD0 in Oa1D8NYLrVM9:
					if 'wpost' in ZylHkumQ8zD0: s1GTeX8VlcUJ7Mp4d0gQa = ZylHkumQ8zD0
					elif 'dpost' in ZylHkumQ8zD0: qdPSy3N9uYRcj8roBJlMmHWDUKeEfi = ZylHkumQ8zD0
				UY52vkIEOe71mXLVHWxQMufBFyr6 = nA5dhMRg6ENzsB0l1GwvH7aIr2
				onW8PAdCQV0pHg9DxByJ4Fa5IrZ6 = nA5dhMRg6ENzsB0l1GwvH7aIr2
	if s1GTeX8VlcUJ7Mp4d0gQa:
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,plbraNGcCgKzO4xjVIwshTLoW,s1GTeX8VlcUJ7Mp4d0gQa,UY52vkIEOe71mXLVHWxQMufBFyr6,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ARABSEED-PLAY-2nd')
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="WatcherArea(.*?</ul>)',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			BjqVlbGZS8IQKh6Wtw4iUE = zz3eHskxE6lAyDR5cNj1ug[0]
			BjqVlbGZS8IQKh6Wtw4iUE = BjqVlbGZS8IQKh6Wtw4iUE.replace('</ul>','<h3>')
			BjqVlbGZS8IQKh6Wtw4iUE = BjqVlbGZS8IQKh6Wtw4iUE.replace('<h3>','<h3><h3>')
			Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q = PAztbuyYo4Kvd.findall('<h3>.*?(\d+)(.*?)<h3>',BjqVlbGZS8IQKh6Wtw4iUE,PAztbuyYo4Kvd.DOTALL)
			if not Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q: Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q = [(nA5dhMRg6ENzsB0l1GwvH7aIr2,BjqVlbGZS8IQKh6Wtw4iUE)]
			for OzWg1yEQG8wtvJ4x2ic9aKedFAPD,WWU7QJP2tyTRLIfDh0csxbkvX in Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q:
				if OzWg1yEQG8wtvJ4x2ic9aKedFAPD: OzWg1yEQG8wtvJ4x2ic9aKedFAPD = '____'+OzWg1yEQG8wtvJ4x2ic9aKedFAPD
				items = PAztbuyYo4Kvd.findall('data-link="(.*?)".*?<span>(.*?)</span>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
				for ZylHkumQ8zD0,name in items:
					if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = 'http:'+ZylHkumQ8zD0
					ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named='+name+'__watch'+OzWg1yEQG8wtvJ4x2ic9aKedFAPD
					ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
		HRpMVv1x5ol9gbsnQquj = PAztbuyYo4Kvd.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL|PAztbuyYo4Kvd.IGNORECASE)
		if HRpMVv1x5ol9gbsnQquj:
			ZylHkumQ8zD0,OzWg1yEQG8wtvJ4x2ic9aKedFAPD = HRpMVv1x5ol9gbsnQquj[0]
			name = C2gnJ5tXFk9pAL(ZylHkumQ8zD0,'name')
			if '%' in OzWg1yEQG8wtvJ4x2ic9aKedFAPD: ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named='+name+'__embed__'
			else: ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named='+name+'__embed____'+OzWg1yEQG8wtvJ4x2ic9aKedFAPD
			ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	if qdPSy3N9uYRcj8roBJlMmHWDUKeEfi:
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,plbraNGcCgKzO4xjVIwshTLoW,qdPSy3N9uYRcj8roBJlMmHWDUKeEfi,onW8PAdCQV0pHg9DxByJ4Fa5IrZ6,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ARABSEED-PLAY-3rd')
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="DownloadArea(.*?)<script src=',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			BjqVlbGZS8IQKh6Wtw4iUE = zz3eHskxE6lAyDR5cNj1ug[0]
			Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q = PAztbuyYo4Kvd.findall('class="DownloadServers(.*?)</ul>',BjqVlbGZS8IQKh6Wtw4iUE,PAztbuyYo4Kvd.DOTALL)
			for WWU7QJP2tyTRLIfDh0csxbkvX in Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q:
				items = PAztbuyYo4Kvd.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
				for ZylHkumQ8zD0,title,OzWg1yEQG8wtvJ4x2ic9aKedFAPD in items:
					if not ZylHkumQ8zD0: continue
					if 'reviewstation' in ZylHkumQ8zD0: continue
					ZylHkumQ8zD0 = pvOytL0nF7JY6flXTxAcHbQeNahu3(ZylHkumQ8zD0)
					ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named='+title+'__download____'+OzWg1yEQG8wtvJ4x2ic9aKedFAPD
					ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	pROPYBMxdT0aG2W9Lr5 = str(ce9zAaVFswSq6lLr82DfQyotGW)
	QNenGy4527KtTFYlXjLuEacwHo = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(value in pROPYBMxdT0aG2W9Lr5 for value in QNenGy4527KtTFYlXjLuEacwHo):
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(ce9zAaVFswSq6lLr82DfQyotGW,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if not search: search = FaUBpzTGxtS7hZyl()
	if not search: return
	search = search.replace(hSXlxL9iB05c,'+')
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/find/?find='+search
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,'search')
	return
def NNihMcqGKQEvLz6l(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter==nA5dhMRg6ENzsB0l1GwvH7aIr2: vvXcyZhkfV,guikd57yRSCMsNmlUqFHWAYL = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	else: vvXcyZhkfV,guikd57yRSCMsNmlUqFHWAYL = filter.split('___')
	if type=='CATEGORIES':
		if j1Jk78D9ezVwrbKCWxPfEQvUyO65GF[0]+'==' not in vvXcyZhkfV: kvfOU7Tpz958QBqnIlaAePLys = j1Jk78D9ezVwrbKCWxPfEQvUyO65GF[0]
		for q3kZpRe28O0s1NaCXQ9SMuGKin in range(len(j1Jk78D9ezVwrbKCWxPfEQvUyO65GF[0:-1])):
			if j1Jk78D9ezVwrbKCWxPfEQvUyO65GF[q3kZpRe28O0s1NaCXQ9SMuGKin]+'==' in vvXcyZhkfV: kvfOU7Tpz958QBqnIlaAePLys = j1Jk78D9ezVwrbKCWxPfEQvUyO65GF[q3kZpRe28O0s1NaCXQ9SMuGKin+1]
		FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&&'+kvfOU7Tpz958QBqnIlaAePLys+'==0'
		QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&&'+kvfOU7Tpz958QBqnIlaAePLys+'==0'
		TB6HLPpacsK8f034jvYx7SNgFd = FqCItdu32L9hNwcEXWoges4R68KS.strip('&&')+'___'+QA6C8r4lEdhemfJPRc.strip('&&')
		OQmDdTI7hU4Lv3BfexPVKgRF8YN = EdpkojMzLm6b3ZSVcXwi0CPRIH(guikd57yRSCMsNmlUqFHWAYL,'modified_filters')
		KteRnFMjHpBPqNf8 = url+'//getposts??'+OQmDdTI7hU4Lv3BfexPVKgRF8YN
	elif type=='FILTERS':
		iEa2qGQctFxX = EdpkojMzLm6b3ZSVcXwi0CPRIH(vvXcyZhkfV,'modified_values')
		iEa2qGQctFxX = pvOytL0nF7JY6flXTxAcHbQeNahu3(iEa2qGQctFxX)
		if guikd57yRSCMsNmlUqFHWAYL!=nA5dhMRg6ENzsB0l1GwvH7aIr2: guikd57yRSCMsNmlUqFHWAYL = EdpkojMzLm6b3ZSVcXwi0CPRIH(guikd57yRSCMsNmlUqFHWAYL,'modified_filters')
		if guikd57yRSCMsNmlUqFHWAYL==nA5dhMRg6ENzsB0l1GwvH7aIr2: KteRnFMjHpBPqNf8 = url
		else: KteRnFMjHpBPqNf8 = url+'//getposts??'+guikd57yRSCMsNmlUqFHWAYL
		mN3xi4TLMadDl10VHhOAbrXKjZB = cTlIOYA7v4qU1k89iQe(KteRnFMjHpBPqNf8)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'أظهار قائمة الفيديو التي تم اختيارها ',mN3xi4TLMadDl10VHhOAbrXKjZB,251,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filters')
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+' [[   '+iEa2qGQctFxX+'   ]]',mN3xi4TLMadDl10VHhOAbrXKjZB,251,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filters')
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'POST',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ARABSEED-FILTERS_MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	d4VcGPRN3uwC = PAztbuyYo4Kvd.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	SpcntCWzJ1vHF829UgbO3 = PAztbuyYo4Kvd.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	AAkSjd9agcy = d4VcGPRN3uwC+SpcntCWzJ1vHF829UgbO3
	dict = {}
	for name,xWwIXcK0L61EBgtn7smr,WWU7QJP2tyTRLIfDh0csxbkvX in AAkSjd9agcy:
		items = PAztbuyYo4Kvd.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			hn2rCExmu5pgejyYOT = PAztbuyYo4Kvd.findall('data-rate="(.*?)".*?<em>(.*?)</em>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			items = []
			for DOT0LXwgoHYkFBC4MbxN53,value in hn2rCExmu5pgejyYOT: items.append([DOT0LXwgoHYkFBC4MbxN53,nA5dhMRg6ENzsB0l1GwvH7aIr2,value])
			xWwIXcK0L61EBgtn7smr = 'rate'
			name = 'التقييم'
		else: xWwIXcK0L61EBgtn7smr = items[0][1]
		if '==' not in KteRnFMjHpBPqNf8: KteRnFMjHpBPqNf8 = url
		if type=='CATEGORIES':
			if kvfOU7Tpz958QBqnIlaAePLys!=xWwIXcK0L61EBgtn7smr: continue
			elif len(items)<=1:
				if xWwIXcK0L61EBgtn7smr==j1Jk78D9ezVwrbKCWxPfEQvUyO65GF[-1]: LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(KteRnFMjHpBPqNf8)
				else: NNihMcqGKQEvLz6l(KteRnFMjHpBPqNf8,'CATEGORIES___'+TB6HLPpacsK8f034jvYx7SNgFd)
				return
			else:
				mN3xi4TLMadDl10VHhOAbrXKjZB = cTlIOYA7v4qU1k89iQe(KteRnFMjHpBPqNf8)
				if xWwIXcK0L61EBgtn7smr==j1Jk78D9ezVwrbKCWxPfEQvUyO65GF[-1]: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع ',mN3xi4TLMadDl10VHhOAbrXKjZB,251,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filters')
				else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع ',KteRnFMjHpBPqNf8,254,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,TB6HLPpacsK8f034jvYx7SNgFd)
		elif type=='FILTERS':
			FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&&'+xWwIXcK0L61EBgtn7smr+'==0'
			QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&&'+xWwIXcK0L61EBgtn7smr+'==0'
			TB6HLPpacsK8f034jvYx7SNgFd = FqCItdu32L9hNwcEXWoges4R68KS+'___'+QA6C8r4lEdhemfJPRc
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع :'+name,KteRnFMjHpBPqNf8,255,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,TB6HLPpacsK8f034jvYx7SNgFd)
		dict[xWwIXcK0L61EBgtn7smr] = {}
		for DOT0LXwgoHYkFBC4MbxN53,eIlXpH1gLhmP4w3,value in items:
			if DOT0LXwgoHYkFBC4MbxN53 in SAsGubf1jW2Q3p: continue
			if 'الكل' in DOT0LXwgoHYkFBC4MbxN53: continue
			DOT0LXwgoHYkFBC4MbxN53 = HH8SJuswDBPtniebmkXIr(DOT0LXwgoHYkFBC4MbxN53)
			lnFIuANWwQ,g7qwMTAPoVpIyQUaDeNOnhvs = DOT0LXwgoHYkFBC4MbxN53,DOT0LXwgoHYkFBC4MbxN53
			g7qwMTAPoVpIyQUaDeNOnhvs = name+': '+lnFIuANWwQ
			dict[xWwIXcK0L61EBgtn7smr][value] = g7qwMTAPoVpIyQUaDeNOnhvs
			FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&&'+xWwIXcK0L61EBgtn7smr+'=='+lnFIuANWwQ
			QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&&'+xWwIXcK0L61EBgtn7smr+'=='+value
			b97AdvPkWGEBe3ayj1Jhmcq2LVxr = FqCItdu32L9hNwcEXWoges4R68KS+'___'+QA6C8r4lEdhemfJPRc
			if type=='FILTERS':
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+g7qwMTAPoVpIyQUaDeNOnhvs,url,255,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,b97AdvPkWGEBe3ayj1Jhmcq2LVxr)
			elif type=='CATEGORIES' and j1Jk78D9ezVwrbKCWxPfEQvUyO65GF[-2]+'==' in vvXcyZhkfV:
				OQmDdTI7hU4Lv3BfexPVKgRF8YN = EdpkojMzLm6b3ZSVcXwi0CPRIH(QA6C8r4lEdhemfJPRc,'modified_filters')
				w7Ol6FnokgJDSsIt = url+'//getposts??'+OQmDdTI7hU4Lv3BfexPVKgRF8YN
				mN3xi4TLMadDl10VHhOAbrXKjZB = cTlIOYA7v4qU1k89iQe(w7Ol6FnokgJDSsIt)
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+g7qwMTAPoVpIyQUaDeNOnhvs,mN3xi4TLMadDl10VHhOAbrXKjZB,251,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filters')
			else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+g7qwMTAPoVpIyQUaDeNOnhvs,url,254,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,b97AdvPkWGEBe3ayj1Jhmcq2LVxr)
	return
j1Jk78D9ezVwrbKCWxPfEQvUyO65GF = ['category','country','release-year']
rkTgCw98sH2JSAGRN0WiE = ['category','country','genre','release-year','language','quality','rate']
def cTlIOYA7v4qU1k89iQe(url):
	MsCyGTpjqDl = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',MsCyGTpjqDl)
	url = url.replace('/category/اخرى',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	if MsCyGTpjqDl not in url: url = url+MsCyGTpjqDl
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def EdpkojMzLm6b3ZSVcXwi0CPRIH(tgsLX2uACmFhVznejRy6O,mode):
	tgsLX2uACmFhVznejRy6O = tgsLX2uACmFhVznejRy6O.strip('&&')
	bpoRYqt38j,H5ROYNwvQFkBiVElThr = {},nA5dhMRg6ENzsB0l1GwvH7aIr2
	if '==' in tgsLX2uACmFhVznejRy6O:
		items = tgsLX2uACmFhVznejRy6O.split('&&')
		for CQtNwXGVAJ2y5nBY in items:
			eehzynNs85aTHrgCUmFc3DBO12,value = CQtNwXGVAJ2y5nBY.split('==')
			bpoRYqt38j[eehzynNs85aTHrgCUmFc3DBO12] = value
	for key in rkTgCw98sH2JSAGRN0WiE:
		if key in list(bpoRYqt38j.keys()): value = bpoRYqt38j[key]
		else: value = '0'
		if '%' not in value: value = kGE6zoKSan54W(value)
		if mode=='modified_values' and value!='0': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+' + '+value
		elif mode=='modified_filters' and value!='0': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+'&&'+key+'=='+value
		elif mode=='all': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+'&&'+key+'=='+value
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.strip(' + ')
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.strip('&&')
	return H5ROYNwvQFkBiVElThr
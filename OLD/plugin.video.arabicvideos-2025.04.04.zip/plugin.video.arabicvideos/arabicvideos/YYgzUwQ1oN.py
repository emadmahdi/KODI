# -*- coding: utf-8 -*-
import sys as kCNHMOym1luTnJ0
MigYEN1cxduFB2lpk5 = kCNHMOym1luTnJ0.version_info [0] == 2
xJ3XdNcV5IujAkoGh = 2048
aE71QiuHI95zfPRBUsntedWZJ2bl = 7
def vR1b8iCLa9Qy2Sw5OYAlWXNhZp37 (AGxE4RIvuC6):
	global peWEVn47JRXo916j
	Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky = ord (AGxE4RIvuC6 [-1])
	FXUjnSw308z = AGxE4RIvuC6 [:-1]
	f81LoVwXMpQkvdKcmPyj6NzBlt = Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky % len (FXUjnSw308z)
	qyKv5nBTxgkQSlJ0aNP1CUmpjYLZ = FXUjnSw308z [:f81LoVwXMpQkvdKcmPyj6NzBlt] + FXUjnSw308z [f81LoVwXMpQkvdKcmPyj6NzBlt:]
	if MigYEN1cxduFB2lpk5:
		H0yFJ5LDCGYpIM1BViZKTSgv3jXr = unicode () .join ([unichr (ord (Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286) - xJ3XdNcV5IujAkoGh - (MfwWyztdYVXURgPqLrITku3CxF1 + Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky) % aE71QiuHI95zfPRBUsntedWZJ2bl) for MfwWyztdYVXURgPqLrITku3CxF1, Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286 in enumerate (qyKv5nBTxgkQSlJ0aNP1CUmpjYLZ)])
	else:
		H0yFJ5LDCGYpIM1BViZKTSgv3jXr = str () .join ([chr (ord (Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286) - xJ3XdNcV5IujAkoGh - (MfwWyztdYVXURgPqLrITku3CxF1 + Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky) % aE71QiuHI95zfPRBUsntedWZJ2bl) for MfwWyztdYVXURgPqLrITku3CxF1, Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286 in enumerate (qyKv5nBTxgkQSlJ0aNP1CUmpjYLZ)])
	return eval (H0yFJ5LDCGYpIM1BViZKTSgv3jXr)
Yj1msqVeivESfrCupRy9b7WacBd,XEcWOIwkZKubV7vQ,Pj9YaUq1ibJ=vR1b8iCLa9Qy2Sw5OYAlWXNhZp37,vR1b8iCLa9Qy2Sw5OYAlWXNhZp37,vR1b8iCLa9Qy2Sw5OYAlWXNhZp37
HD7MQqXd2gS,yPE2t1Co4YQDfsIecdxu0Gklq6AvO,bqCDnV7Bs5XgRvuKLNAa1Uz=Pj9YaUq1ibJ,XEcWOIwkZKubV7vQ,Yj1msqVeivESfrCupRy9b7WacBd
YIsyNBocg6fV3wEWPSu9GtvHxLOqDi,VVstJA9bfOqunLF0oaSgWUKHDdYNz,nfNTgkiWdUq=bqCDnV7Bs5XgRvuKLNAa1Uz,yPE2t1Co4YQDfsIecdxu0Gklq6AvO,HD7MQqXd2gS
FVxoQ2J5Mfv3Zj6sy9uhOS,n8BrpFLyaMAC1vP0bOHgwxEzeGRV,UUobzy0xZLaVScIt7=nfNTgkiWdUq,VVstJA9bfOqunLF0oaSgWUKHDdYNz,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi
JvQd6LMoBX4hiy1C,ZjELJ9VrUT07R8Hn4FuSDcf,pxt6wJ8ScYMWCivoO=UUobzy0xZLaVScIt7,n8BrpFLyaMAC1vP0bOHgwxEzeGRV,FVxoQ2J5Mfv3Zj6sy9uhOS
lw2snZ9J0uhLoxypqa,LJqSQvuhf7aMmnVjy23FbZBckKzx9l,gmPI7hVEM8nD=pxt6wJ8ScYMWCivoO,ZjELJ9VrUT07R8Hn4FuSDcf,JvQd6LMoBX4hiy1C
w0ivtSjV2sZDQoT1OEugIla7R6AC5M,rCmGE4YIDaZA,vzqjsVHSBlMpxC=gmPI7hVEM8nD,LJqSQvuhf7aMmnVjy23FbZBckKzx9l,lw2snZ9J0uhLoxypqa
xwIUQfiE7rmvYzH,ldIfvn6asURQ9toi85EhqAXW3,bb1fgjsAq4N2xYwnoh39lm=vzqjsVHSBlMpxC,rCmGE4YIDaZA,w0ivtSjV2sZDQoT1OEugIla7R6AC5M
AJHaiQq3PRd5cphzGuELnVg9X,jil8vRpBsENVYyPmDd,PPxYugzLZwHX23yiK=bb1fgjsAq4N2xYwnoh39lm,ldIfvn6asURQ9toi85EhqAXW3,xwIUQfiE7rmvYzH
baBcNd81eH5ry2Olp6Mj43,Qy6wlfLoOpg1,mRanX1HZupfSQVB2gsDGUO=PPxYugzLZwHX23yiK,jil8vRpBsENVYyPmDd,AJHaiQq3PRd5cphzGuELnVg9X
bDxWcjmaSgFeRKrfpJvyA4zThi,DFx6E0uON7Jm8,zhE5I4xHinX0UoVZMNwlkPrR=mRanX1HZupfSQVB2gsDGUO,Qy6wlfLoOpg1,baBcNd81eH5ry2Olp6Mj43
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = zhE5I4xHinX0UoVZMNwlkPrR(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬਸ਼")
def YYdDUV01oAtQljRBxO9enrEXHwfC(knBV0UPuCNdpIsAFH3coRKjh2lb,kOTdpYrPqu5A7UIcW0Ch):
	if   knBV0UPuCNdpIsAFH3coRKjh2lb==gmPI7hVEM8nD(u"࠸࠹࠰ૄ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = hQWf0gweHoRY6qvKkAl()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==vzqjsVHSBlMpxC(u"࠹࠳࠲ૅ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(kOTdpYrPqu5A7UIcW0Ch)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==XEcWOIwkZKubV7vQ(u"࠳࠴࠴૆"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = F4bOTWBwiNzpa9lexR6Vdo73qMg8v()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠴࠵࠶ે"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = rGutYmv7eHnR()
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = FFKncZx5pDTwdiJRYhMgQSNL
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def lNBcUr8RCn(kOTdpYrPqu5A7UIcW0Ch):
	ocUnzjShqIO35vZi8bk64pVKMCTBaw(kOTdpYrPqu5A7UIcW0Ch,wgj0rX5tbcxPulhmny,bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠫࡻ࡯ࡤࡦࡱࠪ਷"))
	return
def rGutYmv7eHnR():
	a1duvQ8Vh0gNo69nDcp3Pjtym = YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠬษะ่สࠣษ้๏ࠠาษห฻ࠥอไโ์า๎ํࠦร้ࠢสฺ่๎สࠡใํࠤฬ๊ๅ้ไ฼ࠤฬ๊ๅุๆ๋ฬࠥัๅࠡลู฾฼ูࠦๅ๋ࠣึึࠦวๅไสส๊ฯࠠศๆํ้๏์ࠠฬ็ࠣวำะวาࠢࠥฮา๋๊ๅ่่ࠢๆอสࠡใํำ๏๎ࠢࠡอ่ࠤฬิสศำࠣำ็ฯࠠศๆุ์ึฯ้ࠠษัฮฬืࠠ็๊฼ࠤ๊๊แࠡษ็ูํืษ๊ࠡห฽ิํวࠡี๋ๅࠥ๐ศะลࠣห้ะอๆ์็ࠫਸ")
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,pxt6wJ8ScYMWCivoO(u"࠭ืา์ๅอࠥะอๆ์็ࠤฬ๊ๅๅใสฮࠬਹ"),a1duvQ8Vh0gNo69nDcp3Pjtym)
	return
def hQWf0gweHoRY6qvKkAl():
	TBt8bUDo9WhL(bb1fgjsAq4N2xYwnoh39lm(u"ࠧ࡭࡫ࡱ࡯ࠬ਺"),bbTCMJwEx8nhN4X+HD7MQqXd2gS(u"ࠨูิ๎็ฯࠠหฯ่๎้ࠦๅๅใสฮࠥอไโ์า๎ํ࠭਻")+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠵࠶࠷ૈ"))
	TBt8bUDo9WhL(vzqjsVHSBlMpxC(u"ࠩ࡯࡭ࡳࡱ਼ࠧ"),bbTCMJwEx8nhN4X+vzqjsVHSBlMpxC(u"ࠪฮ฿๐๊า่ࠢ็ฬ์ࠠหฯ่๎้ࠦวๅใํำ๏๎็ศฬࠪ਽")+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,UUobzy0xZLaVScIt7(u"࠶࠷࠷ૉ"))
	TBt8bUDo9WhL(Yj1msqVeivESfrCupRy9b7WacBd(u"ࠫࡱ࡯࡮࡬ࠩਾ"),bbTCMJwEx8nhN4X+DFx6E0uON7Jm8(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫਿ")+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,xwIUQfiE7rmvYzH(u"࠽࠾࠿࠹૊"))
	vpWlc70qQJP6O3GY8doT = aLNADRBrUPhSjHW()
	MTD5eWnOEGq2j3HVAyIPx = XoZRpFe7B6gnfA.stat(vpWlc70qQJP6O3GY8doT).st_mtime
	i0gkImCvH1p = []
	if BsLJ7p5Av2Vm0SQeCO1o: KHrkCb5zLmp1s38P4JvFRxZNTd6t = XoZRpFe7B6gnfA.listdir(vpWlc70qQJP6O3GY8doT.encode(YWEQ3Cf8RevpD0m7NjF1))
	else: KHrkCb5zLmp1s38P4JvFRxZNTd6t = XoZRpFe7B6gnfA.listdir(vpWlc70qQJP6O3GY8doT.decode(YWEQ3Cf8RevpD0m7NjF1))
	for kaZpSFbNwUu1d4C3qnILMiR0lQ57e in KHrkCb5zLmp1s38P4JvFRxZNTd6t:
		if BsLJ7p5Av2Vm0SQeCO1o: kaZpSFbNwUu1d4C3qnILMiR0lQ57e = kaZpSFbNwUu1d4C3qnILMiR0lQ57e.decode(YWEQ3Cf8RevpD0m7NjF1)
		if not kaZpSFbNwUu1d4C3qnILMiR0lQ57e.startswith(pxt6wJ8ScYMWCivoO(u"࠭ࡦࡪ࡮ࡨࡣࠬੀ")): continue
		g61t0d4bqYVriPfuz2WXSa8ZwCv7 = XoZRpFe7B6gnfA.path.join(vpWlc70qQJP6O3GY8doT,kaZpSFbNwUu1d4C3qnILMiR0lQ57e)
		MTD5eWnOEGq2j3HVAyIPx = XoZRpFe7B6gnfA.path.getmtime(g61t0d4bqYVriPfuz2WXSa8ZwCv7)
		i0gkImCvH1p.append([kaZpSFbNwUu1d4C3qnILMiR0lQ57e,MTD5eWnOEGq2j3HVAyIPx])
	i0gkImCvH1p = sorted(i0gkImCvH1p,reverse=S5MWhgtZ37Xw,key=lambda key: key[UnOIK1WBbw2])
	for kaZpSFbNwUu1d4C3qnILMiR0lQ57e,MTD5eWnOEGq2j3HVAyIPx in i0gkImCvH1p:
		if cS2NYw4xulqJgvzkMF:
			try: kaZpSFbNwUu1d4C3qnILMiR0lQ57e = kaZpSFbNwUu1d4C3qnILMiR0lQ57e.decode(YWEQ3Cf8RevpD0m7NjF1)
			except: pass
			kaZpSFbNwUu1d4C3qnILMiR0lQ57e = kaZpSFbNwUu1d4C3qnILMiR0lQ57e.encode(YWEQ3Cf8RevpD0m7NjF1)
		g61t0d4bqYVriPfuz2WXSa8ZwCv7 = XoZRpFe7B6gnfA.path.join(vpWlc70qQJP6O3GY8doT,kaZpSFbNwUu1d4C3qnILMiR0lQ57e)
		TBt8bUDo9WhL(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠧࡷ࡫ࡧࡩࡴ࠭ੁ"),kaZpSFbNwUu1d4C3qnILMiR0lQ57e,g61t0d4bqYVriPfuz2WXSa8ZwCv7,baBcNd81eH5ry2Olp6Mj43(u"࠸࠹࠱ો"))
	return
def aLNADRBrUPhSjHW():
	vpWlc70qQJP6O3GY8doT = KQctJbXeEjDhplqknU3rzi.getSetting(HD7MQqXd2gS(u"ࠨࡣࡹ࠲ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠴ࡰࡢࡶ࡫ࠫੂ"))
	if vpWlc70qQJP6O3GY8doT: return vpWlc70qQJP6O3GY8doT
	KQctJbXeEjDhplqknU3rzi.setSetting(xwIUQfiE7rmvYzH(u"ࠩࡤࡺ࠳ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡱࡣࡷ࡬ࠬ੃"),QQwBc24Oza7jJ8ClTRWexUoqGAkg0)
	return QQwBc24Oza7jJ8ClTRWexUoqGAkg0
def F4bOTWBwiNzpa9lexR6Vdo73qMg8v():
	vpWlc70qQJP6O3GY8doT = aLNADRBrUPhSjHW()
	F0kcfCYOWoaqpVy4jD19MU3HmXt = bjyB5J1QuNaIXOx9qSwm4v0edDhg(JvQd6LMoBX4hiy1C(u"ࠪࡧࡪࡴࡴࡦࡴࠪ੄"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,zhE5I4xHinX0UoVZMNwlkPrR(u"๊้ࠫว็ࠢอาื๐ๆࠡ็็ๅฬะࠠศๆอั๊๐ไࠨ੅"),lSWzOYmN08+vpWlc70qQJP6O3GY8doT+NwROdSj3nsA+PPxYugzLZwHX23yiK(u"ࠬࡢ࡮࡝ࡰ๊ิฬࠦ็้่ࠢ็ฬ์ࠠหะี๎๋ࠦๅๅใสฮࠥอไโ์า๎ํࠦวๅฬํࠤฯำๅๅ้สࠤฬ์สࠡสสืฯิฯศ็๋ࠣีอࠠศๆหี๋อๅอࠢ࠱ࠤ์๊ࠠหำํำࠥะฺ๋์ิࠤฬ๊ๅไษ้ࠤฤ࠭੆"))
	if F0kcfCYOWoaqpVy4jD19MU3HmXt==AJHaiQq3PRd5cphzGuELnVg9X(u"࠷ૌ"):
		fGounA94hrB3XkaZR = ZZpK5jXgcHiCFJDM4r7GoLyQnz0m(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠳્"),Qy6wlfLoOpg1(u"࠭ๅไษ้ࠤฯำๅ๋ๆ้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠪੇ"),bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠧ࡭ࡱࡦࡥࡱ࠭ੈ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,FFKncZx5pDTwdiJRYhMgQSNL,S5MWhgtZ37Xw,vpWlc70qQJP6O3GY8doT)
		x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(baBcNd81eH5ry2Olp6Mj43(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ੉"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,HD7MQqXd2gS(u"่ࠩ็ฬ์ࠠหะี๎๋ࠦๅๅใสฮࠥอไหฯ่๎้࠭੊"),lSWzOYmN08+vpWlc70qQJP6O3GY8doT+NwROdSj3nsA+LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠪࡠࡳࡢ࡮่าสࠤ์๎ࠠศๆ่็ฬ์ࠠศๆฯำ๏ีࠠๅฬัึ๏์ࠠๆๆไหฯࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะอๆๆ๊หࠥอๆหࠢหหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠣ࠲ࠥํไࠡฬิ๎ิࠦวิฬัำฬ๋็ࠡสา่ฬࠦๅ็ࠢส่๊้ว็ࠢส่็ี๊ๆࠢยࠫੋ"))
		if x6zlf2tTZm==mRanX1HZupfSQVB2gsDGUO(u"࠲૎"):
			KQctJbXeEjDhplqknU3rzi.setSetting(pxt6wJ8ScYMWCivoO(u"ࠫࡦࡼ࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧੌ"),fGounA94hrB3XkaZR)
			OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠬะๅࠡฬ฽๎๏ืࠠๆๅส๊ࠥะฮำ์้ࠤฬ๊ๅๅใสฮࠥอไๆฯ่่ฮ੍࠭"))
	return
def yTgpId7BjZJLfteVFHarRv(kOTdpYrPqu5A7UIcW0Ch,tb1IX8C3igp5=nA5dhMRg6ENzsB0l1GwvH7aIr2,website=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+Qy6wlfLoOpg1(u"࠭ࠠࠡࠢࡓࡶࡪࡶࡡࡳ࡫ࡱ࡫ࠥࡺ࡯ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭੎")+kOTdpYrPqu5A7UIcW0Ch+lw2snZ9J0uhLoxypqa(u"ࠧࠡ࡟ࠪ੏"))
	if not tb1IX8C3igp5: tb1IX8C3igp5 = EbwS0djxcz(kOTdpYrPqu5A7UIcW0Ch)
	vpWlc70qQJP6O3GY8doT = aLNADRBrUPhSjHW()
	ByuFsZxqG3NTIQ54f9CPclLVS = A5ADUfVbRmFSyH94P(FFKncZx5pDTwdiJRYhMgQSNL)
	kaZpSFbNwUu1d4C3qnILMiR0lQ57e = ByuFsZxqG3NTIQ54f9CPclLVS.replace(hSXlxL9iB05c,bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠨࡡࠪ੐"))
	kaZpSFbNwUu1d4C3qnILMiR0lQ57e = AIWw30xBhusg(kaZpSFbNwUu1d4C3qnILMiR0lQ57e)
	kaZpSFbNwUu1d4C3qnILMiR0lQ57e = jil8vRpBsENVYyPmDd(u"ࠩࡩ࡭ࡱ࡫࡟ࠨੑ")+str(int(GHSrzcU3jo2))[-bb1fgjsAq4N2xYwnoh39lm(u"࠶૏"):]+rCmGE4YIDaZA(u"ࠪࡣࠬ੒")+kaZpSFbNwUu1d4C3qnILMiR0lQ57e+tb1IX8C3igp5
	Jyw21ed6Pjs = XoZRpFe7B6gnfA.path.join(vpWlc70qQJP6O3GY8doT,kaZpSFbNwUu1d4C3qnILMiR0lQ57e)
	kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3 = {}
	kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3[Yj1msqVeivESfrCupRy9b7WacBd(u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡊࡴࡣࡰࡦ࡬ࡲ࡬࠭੓")] = nA5dhMRg6ENzsB0l1GwvH7aIr2
	kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3[UUobzy0xZLaVScIt7(u"ࠬࡇࡣࡤࡧࡳࡸࠬ੔")] = JvQd6LMoBX4hiy1C(u"࠭ࠪ࠰ࠬࠪ੕")
	kOTdpYrPqu5A7UIcW0Ch = kOTdpYrPqu5A7UIcW0Ch.replace(baBcNd81eH5ry2Olp6Mj43(u"ࠧࡷࡧࡵ࡭࡫ࡿࡰࡦࡧࡵࡁ࡫ࡧ࡬ࡴࡧࠪ੖"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	if UUobzy0xZLaVScIt7(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭੗") in kOTdpYrPqu5A7UIcW0Ch:
		KteRnFMjHpBPqNf8,cgob7MO2qshG = kOTdpYrPqu5A7UIcW0Ch.rsplit(vzqjsVHSBlMpxC(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧ੘"),DFx6E0uON7Jm8(u"࠴ૐ"))
		cgob7MO2qshG = cgob7MO2qshG.replace(baBcNd81eH5ry2Olp6Mj43(u"ࠪࢀࠬਖ਼"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(Qy6wlfLoOpg1(u"ࠫࠫ࠭ਗ਼"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	else: KteRnFMjHpBPqNf8,cgob7MO2qshG = kOTdpYrPqu5A7UIcW0Ch,None
	if not cgob7MO2qshG: cgob7MO2qshG = oOb8ZS417GwudNKHU6y()
	if cgob7MO2qshG: kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3[LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩਜ਼")] = cgob7MO2qshG
	if vzqjsVHSBlMpxC(u"࠭ࡒࡦࡨࡨࡶࡪࡸ࠽ࠨੜ") in KteRnFMjHpBPqNf8: KteRnFMjHpBPqNf8,C5CBL2l96nAPobOujyWpEgsJ = KteRnFMjHpBPqNf8.rsplit(lw2snZ9J0uhLoxypqa(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ੝"),PPxYugzLZwHX23yiK(u"࠵૑"))
	else: KteRnFMjHpBPqNf8,C5CBL2l96nAPobOujyWpEgsJ = KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2
	KteRnFMjHpBPqNf8 = KteRnFMjHpBPqNf8.strip(JvQd6LMoBX4hiy1C(u"ࠨࡾࠪਫ਼")).strip(Qy6wlfLoOpg1(u"ࠩࠩࠫ੟")).strip(mRanX1HZupfSQVB2gsDGUO(u"ࠪࢀࠬ੠")).strip(UUobzy0xZLaVScIt7(u"ࠫࠫ࠭੡"))
	C5CBL2l96nAPobOujyWpEgsJ = C5CBL2l96nAPobOujyWpEgsJ.replace(pxt6wJ8ScYMWCivoO(u"ࠬࢂࠧ੢"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(mRanX1HZupfSQVB2gsDGUO(u"࠭ࠦࠨ੣"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	if C5CBL2l96nAPobOujyWpEgsJ:	kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3[xwIUQfiE7rmvYzH(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ੤")] = C5CBL2l96nAPobOujyWpEgsJ
	nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+nfNTgkiWdUq(u"ࠨࠢࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ੥")+KteRnFMjHpBPqNf8+xwIUQfiE7rmvYzH(u"ࠩࠣࡡࠥࠦࠠࡉࡧࡤࡨࡪࡸࡳ࠻ࠢ࡞ࠤࠬ੦")+str(kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3)+xwIUQfiE7rmvYzH(u"ࠪࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪ੧")+Jyw21ed6Pjs+DFx6E0uON7Jm8(u"ࠫࠥࡣࠧ੨"))
	yh3NdFJAT5kS9QpM6PwHgx84KIW = lw2snZ9J0uhLoxypqa(u"࠶࠶࠲࠵૒")*lw2snZ9J0uhLoxypqa(u"࠶࠶࠲࠵૒")
	bq31xLIXnS7Kvcmz = uCXFHaxhO8lNMQyTzktcV6DWoe0P()//yh3NdFJAT5kS9QpM6PwHgx84KIW
	if not bq31xLIXnS7Kvcmz:
		d9EaJh5t3Tyj7CsXFL(rCmGE4YIDaZA(u"ࠬࡸࡩࡨࡪࡷࠫ੩"),nfNTgkiWdUq(u"࠭ๅิษะอࠥอไหะี๎๋ࠦๅอ้๋่ฮ࠭੪"),baBcNd81eH5ry2Olp6Mj43(u"ࠧๅๆฦืๆࠦวๅสิ๊ฬ๋ฬࠡ฼ํี่ࠥวะำࠣว๋๊ࠦฮัาࠤ๊่ฯศำุ้ࠣออสࠢส่ฯิา๋่ࠣห้็วา฼ฬࠤๆ๐ࠠอ้สึฺ่่ࠦๆํ๋ࠥ็ว็ࠢอั๊๐ไࠡษ็ๅ๏ี๊้้สฮ๊ࠥๆࠡ์฼ู้้ࠦ็ัๆࠤส๊้ࠡล้ࠤ๏่่ๆ่ࠢฬึ๋ฬ๋ࠢหี๋อๅอࠢๆ์ิ๐ࠠษฯ็ࠤ์ึ็ࠡษ็ู้้ไสࠢ็ห๋ࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠢๅำࠥ๐ำษสࠣห๊ะไศรࠣะ์อาไࠢหห้๋ไโษอࠤํํะศࠢไ๎์ࠦฮุ๊ิอࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮี้ำฬࠤฺำ๊ฮหࠣ์้ํะศࠢสุ่ฮศࠡไส้ࠥอไๆสิ้ัࠦๅลไอหࠥฮๅ็฻ࠣห้ฮั็ษ่ะ๋ࠥๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠫ੫"),bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ੬"))
		nhR0UxwS4yDiABj7V1G8la(ybrna7mLOFVDUtRseQ3Tkf2zXS,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+zhE5I4xHinX0UoVZMNwlkPrR(u"ࠩࠣࠤ࡛ࠥ࡮ࡢࡤ࡯ࡩࠥࡺ࡯ࠡࡦࡨࡸࡪࡸ࡭ࡪࡰࡨࠤࡹ࡮ࡥࠡࡦ࡬ࡷࡰࠦࡦࡳࡧࡨࠤࡸࡶࡡࡤࡧࠪ੭"))
		return FFKncZx5pDTwdiJRYhMgQSNL
	if tb1IX8C3igp5==JvQd6LMoBX4hiy1C(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ੮"):
		ecU4Hy7lNS,ce9zAaVFswSq6lLr82DfQyotGW = vWyhsCqMc98ptw5gEPaLl(wgj0rX5tbcxPulhmny,KteRnFMjHpBPqNf8,kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3)
		if len(ecU4Hy7lNS)==HD7MQqXd2gS(u"࠶૓"):
			ggYilKR5rMDyp7B(HD7MQqXd2gS(u"ࠫๆฺไࠡใํࠤส๐ฬศั้้ࠣ็ࠠศๆอั๊๐ไࠨ੯"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
			return FFKncZx5pDTwdiJRYhMgQSNL
		elif len(ecU4Hy7lNS)==XEcWOIwkZKubV7vQ(u"࠱૔"): iP7AUR41exzlKyZIf9Mt3u = lw2snZ9J0uhLoxypqa(u"࠱૕")
		elif len(ecU4Hy7lNS)>nfNTgkiWdUq(u"࠳૖"):
			iP7AUR41exzlKyZIf9Mt3u = ccAMwn7hflDev8Kd3aqP(baBcNd81eH5ry2Olp6Mj43(u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิสࠪੰ"), ecU4Hy7lNS)
			if iP7AUR41exzlKyZIf9Mt3u == -n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠴૗") :
				ggYilKR5rMDyp7B(XEcWOIwkZKubV7vQ(u"࠭สๆࠢศ่฿อมࠡษ็ฮา๋๊ๅࠩੱ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
				return FFKncZx5pDTwdiJRYhMgQSNL
		KteRnFMjHpBPqNf8 = ce9zAaVFswSq6lLr82DfQyotGW[iP7AUR41exzlKyZIf9Mt3u]
	w27iEpn8ctqeQFxZAlG5P4 = n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠴૘")
	import requests as xsu2pPbTo9XwU4v0tDO3
	if tb1IX8C3igp5==VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠧ࠯࡯࠶ࡹ࠽࠭ੲ"):
		Jyw21ed6Pjs = Jyw21ed6Pjs.rsplit(bb1fgjsAq4N2xYwnoh39lm(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧੳ"))[IpFcwrWNgefMym3qta0hYQAzOdE]+AJHaiQq3PRd5cphzGuELnVg9X(u"ࠩ࠱ࡱࡵ࠺ࠧੴ")
		yyt7YxPTa8WEfK2VcMrudgJSUhzNCG = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,Yj1msqVeivESfrCupRy9b7WacBd(u"ࠪࡋࡊ࡚ࠧੵ"),KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,gmPI7hVEM8nD(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠳ࡄࡐ࡙ࡑࡐࡔࡇࡄࡠࡘࡌࡈࡊࡕ࠭࠲ࡵࡷࠫ੶"))
		Ae3kiYMZ1IO4tuF8T9gph = yyt7YxPTa8WEfK2VcMrudgJSUhzNCG.content
		HRpMVv1x5ol9gbsnQquj = PAztbuyYo4Kvd.findall(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠬࠩࡅ࡙ࡖࡌࡒࡋࡀ࠮ࠫࡁ࡞ࡠࡳࡢࡲ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࡰ࡟ࡶࡢ࠭੷"),Ae3kiYMZ1IO4tuF8T9gph+vzqjsVHSBlMpxC(u"࠭࡜࡯࡞ࡵࠫ੸"),PAztbuyYo4Kvd.DOTALL)
		if not HRpMVv1x5ol9gbsnQquj:
			nhR0UxwS4yDiABj7V1G8la(ybrna7mLOFVDUtRseQ3Tkf2zXS,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠧࠡࠢࠣࡘ࡭࡫ࠠ࡮࠵ࡸ࠼ࠥ࡬ࡩ࡭ࡧࠣࡨ࡮ࡪࠠ࡯ࡱࡷࠤ࡭ࡧࡶࡦࠢࡷ࡬ࡪࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡ࡮࡬ࡲࡰࡹࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ੹")+KteRnFMjHpBPqNf8+JvQd6LMoBX4hiy1C(u"ࠨࠢࡠࠫ੺"))
			return FFKncZx5pDTwdiJRYhMgQSNL
		ZylHkumQ8zD0 = HRpMVv1x5ol9gbsnQquj[IpFcwrWNgefMym3qta0hYQAzOdE]
		if not ZylHkumQ8zD0.startswith(DFx6E0uON7Jm8(u"ࠩ࡫ࡸࡹࡶࠧ੻")):
			if ZylHkumQ8zD0.startswith(LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠪ࠳࠴࠭੼")): ZylHkumQ8zD0 = KteRnFMjHpBPqNf8.split(Qy6wlfLoOpg1(u"ࠫ࠿࠭੽"),baBcNd81eH5ry2Olp6Mj43(u"࠶૙"))[IpFcwrWNgefMym3qta0hYQAzOdE]+HD7MQqXd2gS(u"ࠬࡀࠧ੾")+ZylHkumQ8zD0
			elif ZylHkumQ8zD0.startswith(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠭࠯ࠨ੿")): ZylHkumQ8zD0 = C2gnJ5tXFk9pAL(KteRnFMjHpBPqNf8,ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠧࡶࡴ࡯ࠫ઀"))+ZylHkumQ8zD0
			else: ZylHkumQ8zD0 = KteRnFMjHpBPqNf8.rsplit(PPxYugzLZwHX23yiK(u"ࠨ࠱ࠪઁ"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠷૚"))[IpFcwrWNgefMym3qta0hYQAzOdE]+UUobzy0xZLaVScIt7(u"ࠩ࠲ࠫં")+ZylHkumQ8zD0
		yyt7YxPTa8WEfK2VcMrudgJSUhzNCG = xsu2pPbTo9XwU4v0tDO3.request(Pj9YaUq1ibJ(u"ࠪࡋࡊ࡚ࠧઃ"),ZylHkumQ8zD0,headers=kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3,verify=FFKncZx5pDTwdiJRYhMgQSNL)
		tbgMTSLKjOHRAiIdqQkE3uf704 = yyt7YxPTa8WEfK2VcMrudgJSUhzNCG.content
		heWtiUMwo12ypOm0lPrDVu7b = len(tbgMTSLKjOHRAiIdqQkE3uf704)
		OaYVPIrb7uQNRCW9 = len(HRpMVv1x5ol9gbsnQquj)
		w27iEpn8ctqeQFxZAlG5P4 = heWtiUMwo12ypOm0lPrDVu7b*OaYVPIrb7uQNRCW9
	else:
		heWtiUMwo12ypOm0lPrDVu7b = Yj1msqVeivESfrCupRy9b7WacBd(u"࠱૛")*yh3NdFJAT5kS9QpM6PwHgx84KIW
		yyt7YxPTa8WEfK2VcMrudgJSUhzNCG = xsu2pPbTo9XwU4v0tDO3.request(pxt6wJ8ScYMWCivoO(u"ࠫࡌࡋࡔࠨ઄"),KteRnFMjHpBPqNf8,headers=kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3,verify=FFKncZx5pDTwdiJRYhMgQSNL,stream=S5MWhgtZ37Xw)
		if jil8vRpBsENVYyPmDd(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡌࡦࡰࡪࡸ࡭࠭અ") in yyt7YxPTa8WEfK2VcMrudgJSUhzNCG.headers: w27iEpn8ctqeQFxZAlG5P4 = int(yyt7YxPTa8WEfK2VcMrudgJSUhzNCG.headers[w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡍࡧࡱ࡫ࡹ࡮ࠧઆ")])
		OaYVPIrb7uQNRCW9 = int(w27iEpn8ctqeQFxZAlG5P4//heWtiUMwo12ypOm0lPrDVu7b)
	WkFs1KGMR2 = int(w27iEpn8ctqeQFxZAlG5P4//yh3NdFJAT5kS9QpM6PwHgx84KIW)+PPxYugzLZwHX23yiK(u"࠲૜")
	if w27iEpn8ctqeQFxZAlG5P4<LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠴࠴࠴࠵࠶૝"):
		nhR0UxwS4yDiABj7V1G8la(ybrna7mLOFVDUtRseQ3Tkf2zXS,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+UUobzy0xZLaVScIt7(u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡪࡵࠣࡸࡴࡵࠠࡴ࡯ࡤࡰࡱࠦ࡯ࡳࠢ࡬ࡸࠥ࡯ࡳࠡ࡯࠶ࡹ࠽ࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩઇ")+KteRnFMjHpBPqNf8+n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠨࠢࡠࠤࠥࠦࡖࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬઈ")+str(WkFs1KGMR2)+rCmGE4YIDaZA(u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡅࡻࡧࡩ࡭ࡣࡥࡰࡪࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨઉ")+str(bq31xLIXnS7Kvcmz)+bb1fgjsAq4N2xYwnoh39lm(u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭ઊ")+Jyw21ed6Pjs+Qy6wlfLoOpg1(u"ࠫࠥࡣࠧઋ"))
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,Qy6wlfLoOpg1(u"ࠬ็ิๅࠢไ๎ู๋ࠥาใฬࠤาาๅࠡ็็ๅࠥอไโ์า๎ํࠦร้ࠢส่๊๊แࠡื฽๎ึࠦฬะษࠣ์้ํะศࠢ็หࠥ๐ๅไ่่้ࠣฮั็ษ่ะࠥะอๆ์็ࠤ์ึวࠡษ็้้็ࠧઌ"))
		return FFKncZx5pDTwdiJRYhMgQSNL
	Yp4HOtkqV5UFIZ2cSxPjEiaCghu = lw2snZ9J0uhLoxypqa(u"࠷࠴࠵૞")
	qFapxVwuTeItRn2sLlEH4f36ziQvB = bq31xLIXnS7Kvcmz-WkFs1KGMR2
	if qFapxVwuTeItRn2sLlEH4f36ziQvB<Yp4HOtkqV5UFIZ2cSxPjEiaCghu:
		nhR0UxwS4yDiABj7V1G8la(ybrna7mLOFVDUtRseQ3Tkf2zXS,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+baBcNd81eH5ry2Olp6Mj43(u"࠭ࠠࠡࠢࡑࡳࡹࠦࡥ࡯ࡱࡸ࡫࡭ࠦࡤࡪࡵ࡮ࠤࡸࡶࡡࡤࡧࠣࡸࡴࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡࡶ࡫ࡩࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬઍ")+KteRnFMjHpBPqNf8+AJHaiQq3PRd5cphzGuELnVg9X(u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫ઎")+str(WkFs1KGMR2)+Qy6wlfLoOpg1(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡄࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧએ")+str(bq31xLIXnS7Kvcmz)+bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠩࠣࡑࡇࠦ࠭ࠡࠩઐ")+str(Yp4HOtkqV5UFIZ2cSxPjEiaCghu)+Pj9YaUq1ibJ(u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭ઑ")+Jyw21ed6Pjs+bb1fgjsAq4N2xYwnoh39lm(u"ࠫࠥࡣࠧ઒"))
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,ldIfvn6asURQ9toi85EhqAXW3(u"๊ࠬวࠡ์๋ะิࠦๅิษะอ้ࠥวโ์ฬࠤ้๊สฮ็ํ่ࠬઓ"),Pj9YaUq1ibJ(u"࠭วๅ็็ๅࠥอไๆู็์อࠦสฮ็ํ่์ࠦออ็๊ࠤࠬઔ")+str(WkFs1KGMR2)+vzqjsVHSBlMpxC(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์ัํวำๅࠣๅ๏ํࠠๆีสัฮࠦแศำ฽อࠥ࠭ક")+str(bq31xLIXnS7Kvcmz)+jil8vRpBsENVYyPmDd(u"ࠨ่ࠢ๎฿อศศ์อࠤํ๊ไๆฯสๅ฽ฯฺࠠๆ์ࠤ฾๋ไࠡฮ๊หื้ࠠษั๋๊๋ࠥิศๅ็ࠤ๏าศࠡวหๆฬวࠠࠨખ")+str(Yp4HOtkqV5UFIZ2cSxPjEiaCghu)+Pj9YaUq1ibJ(u"้ࠩࠣ๏เวษษํฮࠥ็วา฼ฬࠤิอฦๆษࠣ์์ึวࠡ็฼๊ฬํࠠฤ่ࠣะ์อาไࠢ็หࠥะ่อัࠣๅ๏ํࠠๆีสัฮࠦใศใํอ๊ࠥสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠣห้๋ืๅ๊หࠫગ"))
		return FFKncZx5pDTwdiJRYhMgQSNL
	x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠪࡧࡪࡴࡴࡦࡴࠪઘ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,lw2snZ9J0uhLoxypqa(u"ࠫ์๊ࠠหำํำࠥะอๆ์็ࠤฬ๊ๅๅใࠣรࠬઙ"),UUobzy0xZLaVScIt7(u"ࠬอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥำฬๆ้ࠣฮ็ื๊ษษࠣࠫચ")+str(WkFs1KGMR2)+w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠭ࠠๆ์฽หออ๊ห๋ࠢะ์อาไࠢไ๎์ࠦๅิษะอࠥ็วา฼ฬࠤฯ่ั๋สสࠤࠬછ")+str(bq31xLIXnS7Kvcmz)+bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์์ึวࠡษ็้้็ࠠใัࠣ๎าะวอࠢห฽฻ࠦวๅ๊ๅฮ๊ࠥไหฯ่๎้ࠦๅ็ࠢส่ส์สา่อࠤส๊้ࠡฮ๊หื้ࠠ࠯๊่ࠢࠥอๆห่ࠢฮศ้ฯ๊ࠡอี๏ีࠠศๆสืฯ๋ัศำࠣฬฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡมࠪજ"))
	if x6zlf2tTZm!=ZjELJ9VrUT07R8Hn4FuSDcf(u"࠵૟"):
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,rCmGE4YIDaZA(u"ࠨฬ่ࠤสฺ๊ศรࠣ฽๊๊๊สࠢอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํ࠭ઝ"))
		nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+lw2snZ9J0uhLoxypqa(u"ࠩࠣࠤ࡛ࠥࡳࡦࡴࠣࡧࡦࡴࡣࡦ࡮ࡨࡨࠥࡺࡨࡦࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡴ࡬ࠠࡵࡪࡨࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫઞ")+KteRnFMjHpBPqNf8+Qy6wlfLoOpg1(u"ࠪࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪટ")+Jyw21ed6Pjs+bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠫࠥࡣࠧઠ"))
		return FFKncZx5pDTwdiJRYhMgQSNL
	nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+XEcWOIwkZKubV7vQ(u"ࠬࠦࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡷࡹࡧࡲࡵࡧࡧࠤࡸࡻࡣࡤࡧࡶࡷ࡫ࡻ࡬࡭ࡻࠪડ"))
	p3BeaGrkduEo7zF = SHolYI1dP8g5ThqUAEt()
	p3BeaGrkduEo7zF.create(Jyw21ed6Pjs,mRanX1HZupfSQVB2gsDGUO(u"࠭วๅีฺีࠥ็่ใ๊ࠢ์๋ࠥใศ่ࠣฮำุ๊็่่ࠢๆࠦวๅใํำ๏๎ࠧઢ"))
	bUsHI3nkgytNxKMfYjw0X7rSC58FL = S5MWhgtZ37Xw
	QUevxqzda3 = h0skHe7TcIY9x1UP5VBrZAE8dKGnl.time()
	if not Nzp9Fq5cTr.Gnkf9VO7o1Bv5hTyAUPbHE:
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,lw2snZ9J0uhLoxypqa(u"ࠧษีหฬࠥ฿ฯๆࠢส่ฯฮัฺࠢอ้ࠥหไ฻ษฤࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨણ"))
		return FFKncZx5pDTwdiJRYhMgQSNL
	if BsLJ7p5Av2Vm0SQeCO1o: Nyqsxg9c4TEHR10BzI2OV = open(Jyw21ed6Pjs,bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠨࡹࡥࠫત"))
	else: Nyqsxg9c4TEHR10BzI2OV = open(Jyw21ed6Pjs.decode(YWEQ3Cf8RevpD0m7NjF1),bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠩࡺࡦࠬથ"))
	if tb1IX8C3igp5==XEcWOIwkZKubV7vQ(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩદ"):
		for hsqrMEVB70i2ZnzPHlGYD1oy in range(baBcNd81eH5ry2Olp6Mj43(u"࠶ૠ"),OaYVPIrb7uQNRCW9+baBcNd81eH5ry2Olp6Mj43(u"࠶ૠ")):
			ZylHkumQ8zD0 = HRpMVv1x5ol9gbsnQquj[hsqrMEVB70i2ZnzPHlGYD1oy-xwIUQfiE7rmvYzH(u"࠷ૡ")]
			if not ZylHkumQ8zD0.startswith(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠫ࡭ࡺࡴࡱࠩધ")):
				if ZylHkumQ8zD0.startswith(PPxYugzLZwHX23yiK(u"ࠬ࠵࠯ࠨન")): ZylHkumQ8zD0 = KteRnFMjHpBPqNf8.split(HD7MQqXd2gS(u"࠭࠺ࠨ઩"),FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠱ૢ"))[IpFcwrWNgefMym3qta0hYQAzOdE]+JvQd6LMoBX4hiy1C(u"ࠧ࠻ࠩપ")+ZylHkumQ8zD0
				elif ZylHkumQ8zD0.startswith(YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠨ࠱ࠪફ")): ZylHkumQ8zD0 = C2gnJ5tXFk9pAL(KteRnFMjHpBPqNf8,JvQd6LMoBX4hiy1C(u"ࠩࡸࡶࡱ࠭બ"))+ZylHkumQ8zD0
				else: ZylHkumQ8zD0 = KteRnFMjHpBPqNf8.rsplit(VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠪ࠳ࠬભ"),nfNTgkiWdUq(u"࠲ૣ"))[IpFcwrWNgefMym3qta0hYQAzOdE]+bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠫ࠴࠭મ")+ZylHkumQ8zD0
			yyt7YxPTa8WEfK2VcMrudgJSUhzNCG = xsu2pPbTo9XwU4v0tDO3.request(pxt6wJ8ScYMWCivoO(u"ࠬࡍࡅࡕࠩય"),ZylHkumQ8zD0,headers=kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3,verify=FFKncZx5pDTwdiJRYhMgQSNL)
			tbgMTSLKjOHRAiIdqQkE3uf704 = yyt7YxPTa8WEfK2VcMrudgJSUhzNCG.content
			yyt7YxPTa8WEfK2VcMrudgJSUhzNCG.close()
			Nyqsxg9c4TEHR10BzI2OV.write(tbgMTSLKjOHRAiIdqQkE3uf704)
			wme7R0H5IrWMYUV = h0skHe7TcIY9x1UP5VBrZAE8dKGnl.time()
			sGbLId2VaZu4YPF = wme7R0H5IrWMYUV-QUevxqzda3
			Kp0iweTImZjD7lWVBuXO = sGbLId2VaZu4YPF//hsqrMEVB70i2ZnzPHlGYD1oy
			IkPt8iKrEW0ZfV4 = Kp0iweTImZjD7lWVBuXO*(OaYVPIrb7uQNRCW9+zhE5I4xHinX0UoVZMNwlkPrR(u"࠳૤"))
			zzauhEJ9GUZP0SrL7 = IkPt8iKrEW0ZfV4-sGbLId2VaZu4YPF
			buQ2eMwxvTinjNrLVpUm6IH8fq(p3BeaGrkduEo7zF,int(zhE5I4xHinX0UoVZMNwlkPrR(u"࠵࠵࠶૦")*hsqrMEVB70i2ZnzPHlGYD1oy//(OaYVPIrb7uQNRCW9+UUobzy0xZLaVScIt7(u"࠴૥"))),lw2snZ9J0uhLoxypqa(u"࠭วๅีฺีࠥ็่ใ๊ࠢ์๋ࠥใศ่ࠣฮำุ๊็่่ࠢๆࠦวๅใํำ๏๎ࠧર"),vzqjsVHSBlMpxC(u"ࠧอๆหࠤ๊๊แࠡษ็ๅ๏ี๊้࠼࠰ࠤฬ๊ฬำรࠣี็๋ࠧ઱"),str(hsqrMEVB70i2ZnzPHlGYD1oy*heWtiUMwo12ypOm0lPrDVu7b//yh3NdFJAT5kS9QpM6PwHgx84KIW)+AJHaiQq3PRd5cphzGuELnVg9X(u"ࠨ࠱ࠪલ")+str(WkFs1KGMR2)+YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠩࠣࡑࡇ๋ࠦࠠࠡࠢๆฯࠦๅหสๅ๎࠿ࠦࠧળ")+h0skHe7TcIY9x1UP5VBrZAE8dKGnl.strftime(DFx6E0uON7Jm8(u"ࠥࠩࡍࡀࠥࡎ࠼ࠨࡗࠧ઴"),h0skHe7TcIY9x1UP5VBrZAE8dKGnl.gmtime(zzauhEJ9GUZP0SrL7))+gmPI7hVEM8nD(u"ࠫࠥๆࠧવ"))
			if p3BeaGrkduEo7zF.iscanceled():
				bUsHI3nkgytNxKMfYjw0X7rSC58FL = FFKncZx5pDTwdiJRYhMgQSNL
				break
	else:
		hsqrMEVB70i2ZnzPHlGYD1oy = nfNTgkiWdUq(u"࠵૧")
		for tbgMTSLKjOHRAiIdqQkE3uf704 in yyt7YxPTa8WEfK2VcMrudgJSUhzNCG.iter_content(chunk_size=heWtiUMwo12ypOm0lPrDVu7b):
			Nyqsxg9c4TEHR10BzI2OV.write(tbgMTSLKjOHRAiIdqQkE3uf704)
			hsqrMEVB70i2ZnzPHlGYD1oy = hsqrMEVB70i2ZnzPHlGYD1oy+zhE5I4xHinX0UoVZMNwlkPrR(u"࠷૨")
			wme7R0H5IrWMYUV = h0skHe7TcIY9x1UP5VBrZAE8dKGnl.time()
			sGbLId2VaZu4YPF = wme7R0H5IrWMYUV-QUevxqzda3
			Kp0iweTImZjD7lWVBuXO = sGbLId2VaZu4YPF/hsqrMEVB70i2ZnzPHlGYD1oy
			IkPt8iKrEW0ZfV4 = Kp0iweTImZjD7lWVBuXO*(OaYVPIrb7uQNRCW9+gmPI7hVEM8nD(u"࠱૩"))
			zzauhEJ9GUZP0SrL7 = IkPt8iKrEW0ZfV4-sGbLId2VaZu4YPF
			buQ2eMwxvTinjNrLVpUm6IH8fq(p3BeaGrkduEo7zF,int(Yj1msqVeivESfrCupRy9b7WacBd(u"࠳࠳࠴૫")*hsqrMEVB70i2ZnzPHlGYD1oy/(OaYVPIrb7uQNRCW9+UUobzy0xZLaVScIt7(u"࠲૪"))),bb1fgjsAq4N2xYwnoh39lm(u"ࠬอไิูิࠤๆ๎โ้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅࠥอไโ์า๎ํ࠭શ"),n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠭ฬๅส้้ࠣ็ࠠศๆไ๎ิ๐่࠻࠯ࠣห้าายࠢิๆ๊࠭ષ"),str(hsqrMEVB70i2ZnzPHlGYD1oy*heWtiUMwo12ypOm0lPrDVu7b//yh3NdFJAT5kS9QpM6PwHgx84KIW)+zhE5I4xHinX0UoVZMNwlkPrR(u"ࠧ࠰ࠩસ")+str(WkFs1KGMR2)+Yj1msqVeivESfrCupRy9b7WacBd(u"ࠨࠢࡐࡆ๊ࠥࠦࠠࠡๅฮ๋ࠥสษไํ࠾ࠥ࠭હ")+h0skHe7TcIY9x1UP5VBrZAE8dKGnl.strftime(DFx6E0uON7Jm8(u"ࠤࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦ઺"),h0skHe7TcIY9x1UP5VBrZAE8dKGnl.gmtime(zzauhEJ9GUZP0SrL7))+rCmGE4YIDaZA(u"ࠪࠤๅ࠭઻"))
			if p3BeaGrkduEo7zF.iscanceled():
				bUsHI3nkgytNxKMfYjw0X7rSC58FL = FFKncZx5pDTwdiJRYhMgQSNL
				break
		yyt7YxPTa8WEfK2VcMrudgJSUhzNCG.close()
	Nyqsxg9c4TEHR10BzI2OV.close()
	p3BeaGrkduEo7zF.close()
	if not bUsHI3nkgytNxKMfYjw0X7rSC58FL:
		nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠫࠥࠦࠠࡖࡵࡨࡶࠥࡩࡡ࡯ࡥࡨࡰࡪࡪ࠯ࡪࡰࡷࡩࡷࡸࡵࡱࡶࡨࡨࠥࡺࡨࡦࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡵࡸ࡯ࡤࡧࡶࡷࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ઼")+KteRnFMjHpBPqNf8+YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬઽ")+Jyw21ed6Pjs+yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠭ࠠ࡞ࠩા"))
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠧษฯึฬࠥ฽ไษๅࠣฮ๊ࠦลๅ฼สลࠥ฿ๅๅ์ฬࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨિ"))
		return S5MWhgtZ37Xw
	nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡨࡨࠥࡹࡵࡤࡥࡨࡷࡸ࡬ࡵ࡭࡮ࡼࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧી")+KteRnFMjHpBPqNf8+PPxYugzLZwHX23yiK(u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩુ")+Jyw21ed6Pjs+nfNTgkiWdUq(u"ࠪࠤࡢ࠭ૂ"))
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,Pj9YaUq1ibJ(u"ࠫฯ๋ࠠหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠤอ์ฬศฯࠪૃ"))
	return S5MWhgtZ37Xw
﻿# -*- coding: utf-8 -*-
from pR2X91txEm import *
def YYdDUV01oAtQljRBxO9enrEXHwfC(knBV0UPuCNdpIsAFH3coRKjh2lb,ooJEDbM1jeVhW05cNF7B6XIxQl):
	if ooJEDbM1jeVhW05cNF7B6XIxQl==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	if knBV0UPuCNdpIsAFH3coRKjh2lb==1:
		x2NPyoqfetTjYi8HKIs = z3jwnDkZ76OfKFB1rRoQVghbE0u92.getCurrentWindowDialogId()
		wJ0IQEktls6OPAhMUR92V = z3jwnDkZ76OfKFB1rRoQVghbE0u92.Window(x2NPyoqfetTjYi8HKIs)
		ooJEDbM1jeVhW05cNF7B6XIxQl = KK3yegFpzo45D7(ooJEDbM1jeVhW05cNF7B6XIxQl)
		wJ0IQEktls6OPAhMUR92V.getControl(311).setLabel(ooJEDbM1jeVhW05cNF7B6XIxQl)
	if knBV0UPuCNdpIsAFH3coRKjh2lb==0:
		zzU5PnmRv13toWs4bDFL='X'
		if BsLJ7p5Av2Vm0SQeCO1o: Fxa04LpPdJcyXAoD9lIU5H13mwkC = isinstance(ooJEDbM1jeVhW05cNF7B6XIxQl,str)
		else: Fxa04LpPdJcyXAoD9lIU5H13mwkC = isinstance(ooJEDbM1jeVhW05cNF7B6XIxQl,unicode)
		if Fxa04LpPdJcyXAoD9lIU5H13mwkC==True: zzU5PnmRv13toWs4bDFL='U'
		oNGlubykW8YjPwxrvctR5S1dsmDBTX=str(type(ooJEDbM1jeVhW05cNF7B6XIxQl))+hSXlxL9iB05c+ooJEDbM1jeVhW05cNF7B6XIxQl+hSXlxL9iB05c+zzU5PnmRv13toWs4bDFL+hSXlxL9iB05c
		for q3kZpRe28O0s1NaCXQ9SMuGKin in range(0,len(ooJEDbM1jeVhW05cNF7B6XIxQl),1):
			oNGlubykW8YjPwxrvctR5S1dsmDBTX += hex(ord(ooJEDbM1jeVhW05cNF7B6XIxQl[q3kZpRe28O0s1NaCXQ9SMuGKin])).replace('0x',nA5dhMRg6ENzsB0l1GwvH7aIr2)+hSXlxL9iB05c
		ooJEDbM1jeVhW05cNF7B6XIxQl = KK3yegFpzo45D7(ooJEDbM1jeVhW05cNF7B6XIxQl)
		zzU5PnmRv13toWs4bDFL='X'
		if BsLJ7p5Av2Vm0SQeCO1o: Fxa04LpPdJcyXAoD9lIU5H13mwkC = isinstance(ooJEDbM1jeVhW05cNF7B6XIxQl, str)
		else: Fxa04LpPdJcyXAoD9lIU5H13mwkC = isinstance(ooJEDbM1jeVhW05cNF7B6XIxQl, unicode)
		if Fxa04LpPdJcyXAoD9lIU5H13mwkC==True: zzU5PnmRv13toWs4bDFL='U'
		L6MHcDOt9r50fR17UBn=str(type(ooJEDbM1jeVhW05cNF7B6XIxQl))+hSXlxL9iB05c+ooJEDbM1jeVhW05cNF7B6XIxQl+hSXlxL9iB05c+zzU5PnmRv13toWs4bDFL+hSXlxL9iB05c
		for q3kZpRe28O0s1NaCXQ9SMuGKin in range(0,len(ooJEDbM1jeVhW05cNF7B6XIxQl),1):
			L6MHcDOt9r50fR17UBn += hex(ord(ooJEDbM1jeVhW05cNF7B6XIxQl[q3kZpRe28O0s1NaCXQ9SMuGKin])).replace('0x',nA5dhMRg6ENzsB0l1GwvH7aIr2)+hSXlxL9iB05c
	return
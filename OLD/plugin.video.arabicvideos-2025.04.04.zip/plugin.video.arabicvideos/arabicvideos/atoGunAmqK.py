# -*- coding: utf-8 -*-
from pR2X91txEm import *
kNfc1ZX0HTKjpQImqiuy49g85G7UVa = 'IPTV'
r1r9MU8jSNR2csPJnauFeWzvOGhl5q = '_IPT_'
zhfR0KQZaI = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_ARCHIVED_GROUPED_SORTED','LIVE_EPG_GROUPED_SORTED','LIVE_TIMESHIFT_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
def etoUZjTVky8ru7c(knBV0UPuCNdpIsAFH3coRKjh2lb,kOTdpYrPqu5A7UIcW0Ch,OOrjZaTIVXQ2Sp0ozhc,WTavfhd7QJDABwpIVrZqHL,QbuYlX5ctHaGp42jNef8,Gv80f9tpWiRL):
	global r1r9MU8jSNR2csPJnauFeWzvOGhl5q
	try:
		dkq07Y6WG5enK1QlOLEU8uAj49x = str(Gv80f9tpWiRL['folder'])
		r1r9MU8jSNR2csPJnauFeWzvOGhl5q = '_IP'+dkq07Y6WG5enK1QlOLEU8uAj49x+'_'
	except: dkq07Y6WG5enK1QlOLEU8uAj49x = nA5dhMRg6ENzsB0l1GwvH7aIr2
	if   knBV0UPuCNdpIsAFH3coRKjh2lb==230: ZLzmkuhti3vloIPnB9qcUya = DSwxRTinY4UZV0cL()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==231: ZLzmkuhti3vloIPnB9qcUya = WWH0ca5PyIkL2C(dkq07Y6WG5enK1QlOLEU8uAj49x)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==232: ZLzmkuhti3vloIPnB9qcUya = rK5HAhscvtzDE2gkj(dkq07Y6WG5enK1QlOLEU8uAj49x)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==233: ZLzmkuhti3vloIPnB9qcUya = oHJ5CWIeGX8up7hTKxOdzNPrk(dkq07Y6WG5enK1QlOLEU8uAj49x,kOTdpYrPqu5A7UIcW0Ch,OOrjZaTIVXQ2Sp0ozhc,QbuYlX5ctHaGp42jNef8)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==234: ZLzmkuhti3vloIPnB9qcUya = qTPzY96jGk8mQcNK3XvVHMUR4(dkq07Y6WG5enK1QlOLEU8uAj49x,kOTdpYrPqu5A7UIcW0Ch,OOrjZaTIVXQ2Sp0ozhc,QbuYlX5ctHaGp42jNef8)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==235: ZLzmkuhti3vloIPnB9qcUya = lNBcUr8RCn(dkq07Y6WG5enK1QlOLEU8uAj49x,kOTdpYrPqu5A7UIcW0Ch,WTavfhd7QJDABwpIVrZqHL)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==236: ZLzmkuhti3vloIPnB9qcUya = c3P0A8ltZuqo1OCXIy5(dkq07Y6WG5enK1QlOLEU8uAj49x,True)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==237: ZLzmkuhti3vloIPnB9qcUya = BqXa1702HQUJ6xzfVLhD5NGSi8(dkq07Y6WG5enK1QlOLEU8uAj49x,True)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==238: ZLzmkuhti3vloIPnB9qcUya = IOc1asTKJ7DBWZFiUypEwCvlGhkPLA(dkq07Y6WG5enK1QlOLEU8uAj49x,kOTdpYrPqu5A7UIcW0Ch,OOrjZaTIVXQ2Sp0ozhc)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==239: ZLzmkuhti3vloIPnB9qcUya = BZOyPrlKzJmRGD(OOrjZaTIVXQ2Sp0ozhc,dkq07Y6WG5enK1QlOLEU8uAj49x,kOTdpYrPqu5A7UIcW0Ch,QbuYlX5ctHaGp42jNef8)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==280: ZLzmkuhti3vloIPnB9qcUya = q89q14REt7fG0KsrdymbHiNCVkax(dkq07Y6WG5enK1QlOLEU8uAj49x,True)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==281: ZLzmkuhti3vloIPnB9qcUya = nF4t0SoVgzUijw(dkq07Y6WG5enK1QlOLEU8uAj49x)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==282: ZLzmkuhti3vloIPnB9qcUya = tyFquKhIMsa(dkq07Y6WG5enK1QlOLEU8uAj49x)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==283: ZLzmkuhti3vloIPnB9qcUya = ibDuhN4oRfMVp2TH06Bg1I3JqOFdyc(dkq07Y6WG5enK1QlOLEU8uAj49x)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==285: ZLzmkuhti3vloIPnB9qcUya = oiS9MplKsVnfvNdyHY(dkq07Y6WG5enK1QlOLEU8uAj49x,kOTdpYrPqu5A7UIcW0Ch,OOrjZaTIVXQ2Sp0ozhc)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==286: ZLzmkuhti3vloIPnB9qcUya = aeYqKcUBg0LdJlvAmpMTtP(dkq07Y6WG5enK1QlOLEU8uAj49x)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==289: ZLzmkuhti3vloIPnB9qcUya = v5MgwIrObe2QLt7GqpDuSZWd1PX9(OOrjZaTIVXQ2Sp0ozhc,dkq07Y6WG5enK1QlOLEU8uAj49x,kOTdpYrPqu5A7UIcW0Ch,QbuYlX5ctHaGp42jNef8)
	else: ZLzmkuhti3vloIPnB9qcUya = False
	return ZLzmkuhti3vloIPnB9qcUya
def DSwxRTinY4UZV0cL():
	for dkq07Y6WG5enK1QlOLEU8uAj49x in range(1,EYcbkTrLd8MqHSXzxFGft+1):
		r1r9MU8jSNR2csPJnauFeWzvOGhl5q = '_IP'+str(dkq07Y6WG5enK1QlOLEU8uAj49x)+'_'
		TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'قائمة مجلد '+c0Qs8Db7KdxGzt[dkq07Y6WG5enK1QlOLEU8uAj49x],nA5dhMRg6ENzsB0l1GwvH7aIr2,280,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,{'folder':dkq07Y6WG5enK1QlOLEU8uAj49x})
	return
def q89q14REt7fG0KsrdymbHiNCVkax(dkq07Y6WG5enK1QlOLEU8uAj49x=nA5dhMRg6ENzsB0l1GwvH7aIr2,ZZEzx0vdikFU6Lu5=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if dkq07Y6WG5enK1QlOLEU8uAj49x:
		jTgZ1CPkAQpDV29tJ4KauIcE3 = {'folder':dkq07Y6WG5enK1QlOLEU8uAj49x}
		aYfNMm15XKB = nA5dhMRg6ENzsB0l1GwvH7aIr2
	else:
		jTgZ1CPkAQpDV29tJ4KauIcE3 = nA5dhMRg6ENzsB0l1GwvH7aIr2
		aYfNMm15XKB = nA5dhMRg6ENzsB0l1GwvH7aIr2
	uOyd6MzNVpfYKA3CR81Iwj2LPrD = jx8bBYMhnguRAHoWtXLFml(dkq07Y6WG5enK1QlOLEU8uAj49x,ZZEzx0vdikFU6Lu5)
	if not uOyd6MzNVpfYKA3CR81Iwj2LPrD:
		TBt8bUDo9WhL('link',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+lSWzOYmN08+' إضافة أو تغيير اشتراك'+aYfNMm15XKB+' '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,231,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
		TBt8bUDo9WhL('link',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+lSWzOYmN08+' جلب ملفات'+aYfNMm15XKB+' '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,232,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	else:
		TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'بحث في الملفات'+aYfNMm15XKB,nA5dhMRg6ENzsB0l1GwvH7aIr2,289,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_',nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
		TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'قنوات بدون جلب ملفات','XTREAM_LIVE_GROUPS',285,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
		TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'قنوات مصنفة مرتبة'+aYfNMm15XKB,'LIVE_GROUPED_SORTED',233,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
		TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'قنوات مصنفة من القسم'+aYfNMm15XKB,'LIVE_FROM_GROUP_SORTED',233,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
		TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'قنوات مصنفة من الاسم'+aYfNMm15XKB,'LIVE_FROM_NAME_SORTED',233,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
		TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'قنوات مصنفة بلا ترتيب'+aYfNMm15XKB,'LIVE_GROUPED',233,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
		TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'قنوات بلا ترتيب'+aYfNMm15XKB,'LIVE_ORIGINAL_GROUPED',233,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
		TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'قنوات مجهولة مرتبة'+aYfNMm15XKB,'LIVE_UNKNOWN_GROUPED_SORTED',233,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
		TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'قنوات مجهولة بلا ترتيب'+aYfNMm15XKB,'LIVE_UNKNOWN_GROUPED',233,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
		TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'أفلام بدون جلب ملفات','XTREAM_VOD_GROUPS',285,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
		TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'أفلام مصنفة بلا ترتيب'+aYfNMm15XKB,'VOD_MOVIES_GROUPED',233,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
		TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'أفلام مصنفة مرتبة'+aYfNMm15XKB,'VOD_MOVIES_GROUPED_SORTED',233,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
		TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'مسلسلات بدون جلب ملفات','XTREAM_SERIES_GROUPS',285,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
		TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'مسلسلات مصنفة بلا ترتيب'+aYfNMm15XKB,'VOD_SERIES_GROUPED',233,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
		TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'مسلسلات مصنفة مرتبة'+aYfNMm15XKB,'VOD_SERIES_GROUPED_SORTED',233,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
		TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'فيديوهات بلا ترتيب'+aYfNMm15XKB,'VOD_ORIGINAL_GROUPED',233,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
		TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'فيديوهات مصنفة من القسم'+aYfNMm15XKB,'VOD_FROM_GROUP_SORTED',233,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
		TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'فيديوهات مصنفة من الاسم'+aYfNMm15XKB,'VOD_FROM_NAME_SORTED',233,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
		TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'فيديوهات مجهولة بلا ترتيب'+aYfNMm15XKB,'VOD_UNKNOWN_GROUPED',233,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
		TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'فيديوهات مجهولة مرتبة'+aYfNMm15XKB,'VOD_UNKNOWN_GROUPED_SORTED',233,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
		TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'برامج القنوات (جدول فقط)'+aYfNMm15XKB,'LIVE_EPG_GROUPED_SORTED',233,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
		TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'أرشيف القنوات للأيام الماضية'+aYfNMm15XKB,'LIVE_TIMESHIFT_GROUPED_SORTED',233,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
		TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'أرشيف برامج القنوات للأيام الماضية'+aYfNMm15XKB,'LIVE_ARCHIVED_GROUPED_SORTED',233,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('link',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'إضافة أو تغيير اشتراك'+aYfNMm15XKB,nA5dhMRg6ENzsB0l1GwvH7aIr2,231,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
	TBt8bUDo9WhL('link',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'جلب ملفات'+aYfNMm15XKB,nA5dhMRg6ENzsB0l1GwvH7aIr2,232,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
	TBt8bUDo9WhL('link',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'مسح ملفات'+aYfNMm15XKB,nA5dhMRg6ENzsB0l1GwvH7aIr2,237,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
	TBt8bUDo9WhL('link',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'فحص اشتراك'+aYfNMm15XKB,nA5dhMRg6ENzsB0l1GwvH7aIr2,236,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
	TBt8bUDo9WhL('link',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'عدد فيديوهات'+aYfNMm15XKB,nA5dhMRg6ENzsB0l1GwvH7aIr2,281,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
	TBt8bUDo9WhL('link',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'Referer تغيير'+aYfNMm15XKB,nA5dhMRg6ENzsB0l1GwvH7aIr2,286,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
	TBt8bUDo9WhL('link',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'User-Agent تغيير'+aYfNMm15XKB,nA5dhMRg6ENzsB0l1GwvH7aIr2,283,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
	TBt8bUDo9WhL('link',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'استخدم السيرفر الأسرع'+aYfNMm15XKB,nA5dhMRg6ENzsB0l1GwvH7aIr2,282,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jTgZ1CPkAQpDV29tJ4KauIcE3)
	return
def c3P0A8ltZuqo1OCXIy5(dkq07Y6WG5enK1QlOLEU8uAj49x,ZZEzx0vdikFU6Lu5=True):
	L3Z7qxkHcFjvWKPbg,AEK1sPFcoxpwzIiJBj0hC5f = False,nA5dhMRg6ENzsB0l1GwvH7aIr2
	X0S7wkdetPNTAs9MaH3,l1Im6cu8sCKWtSxZUEMjhpdfeV5gb = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	n5RqEMBVZT0L2,YUzvpc6yTixLVqO24m5ldKwFb1,M8nVAHG7lPzpb64Kho,oKDEiS6bdRqkw1MFJ2ah,ZNwox8KRnW1mP = JywhLB0sPzqC94Hl(dkq07Y6WG5enK1QlOLEU8uAj49x)
	if oKDEiS6bdRqkw1MFJ2ah==nA5dhMRg6ENzsB0l1GwvH7aIr2: return False,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3 = ir4Kqb5p3N76S1yeQFf9dElHYILBt(dkq07Y6WG5enK1QlOLEU8uAj49x)
	if n5RqEMBVZT0L2:
		yyt7YxPTa8WEfK2VcMrudgJSUhzNCG = uANakQHcnhR(yy6RomT9bQhJf,'GET',n5RqEMBVZT0L2,nA5dhMRg6ENzsB0l1GwvH7aIr2,kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3,False,nA5dhMRg6ENzsB0l1GwvH7aIr2,'IPTV-CHECK_ACCOUNT-1st')
		PB1feMy50JE6xjCv4XAHhFNd8I2R = yyt7YxPTa8WEfK2VcMrudgJSUhzNCG.content
		if yyt7YxPTa8WEfK2VcMrudgJSUhzNCG.succeeded:
			llGrMZf5Ikmzo,DyxY1ENhbFRlMHXmQa8VTIu4iqCB0,H6Kp7ZqXM8QBi,ffPUpieH2gF8GyhJ,Hf6MGwaRxe9l8bnWS1ic = 0,0,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
			try:
				nt6lZ95gL0sbNYkQpWGiXrK = BwGPDSQOlfUas2n3eIH0ycFRWZ('dict',PB1feMy50JE6xjCv4XAHhFNd8I2R)
				AEK1sPFcoxpwzIiJBj0hC5f = nt6lZ95gL0sbNYkQpWGiXrK['user_info']['status']
				L3Z7qxkHcFjvWKPbg = True
				H6Kp7ZqXM8QBi = nt6lZ95gL0sbNYkQpWGiXrK['server_info']['time_now']
			except: pass
			if H6Kp7ZqXM8QBi:
				try:
					fp907IWBdA6 = h0skHe7TcIY9x1UP5VBrZAE8dKGnl.strptime(H6Kp7ZqXM8QBi,'%Y.%m.%d %H:%M:%S')
					llGrMZf5Ikmzo = int(h0skHe7TcIY9x1UP5VBrZAE8dKGnl.mktime(fp907IWBdA6))
					DyxY1ENhbFRlMHXmQa8VTIu4iqCB0 = int(GHSrzcU3jo2-llGrMZf5Ikmzo)
					DyxY1ENhbFRlMHXmQa8VTIu4iqCB0 = int((DyxY1ENhbFRlMHXmQa8VTIu4iqCB0+900)/1800)*1800
				except: pass
				try:
					fp907IWBdA6 = h0skHe7TcIY9x1UP5VBrZAE8dKGnl.localtime(int(nt6lZ95gL0sbNYkQpWGiXrK['user_info']['created_at']))
					ffPUpieH2gF8GyhJ = h0skHe7TcIY9x1UP5VBrZAE8dKGnl.strftime('%Y.%m.%d %H:%M:%S',fp907IWBdA6)
				except: pass
				try:
					fp907IWBdA6 = h0skHe7TcIY9x1UP5VBrZAE8dKGnl.localtime(int(nt6lZ95gL0sbNYkQpWGiXrK['user_info']['exp_date']))
					Hf6MGwaRxe9l8bnWS1ic = h0skHe7TcIY9x1UP5VBrZAE8dKGnl.strftime('%Y.%m.%d %H:%M:%S',fp907IWBdA6)
				except: pass
			KQctJbXeEjDhplqknU3rzi.setSetting('av.iptv.timestamp_'+dkq07Y6WG5enK1QlOLEU8uAj49x,str(GHSrzcU3jo2))
			KQctJbXeEjDhplqknU3rzi.setSetting('av.iptv.timediff_'+dkq07Y6WG5enK1QlOLEU8uAj49x,str(DyxY1ENhbFRlMHXmQa8VTIu4iqCB0))
			try:
				msc8MWdjVx2o7Kz6XnryfSE = '"server_info":'+PB1feMy50JE6xjCv4XAHhFNd8I2R.split('"server_info":')[1]
				msc8MWdjVx2o7Kz6XnryfSE = msc8MWdjVx2o7Kz6XnryfSE.replace(':',': ').replace(',',', ').replace('}}','}')
				SSfh1ykHo0aeDK4 = PAztbuyYo4Kvd.findall('"url": "(.*?)", "port": "(.*?)"',msc8MWdjVx2o7Kz6XnryfSE,PAztbuyYo4Kvd.DOTALL)
				X0S7wkdetPNTAs9MaH3,l1Im6cu8sCKWtSxZUEMjhpdfeV5gb = SSfh1ykHo0aeDK4[0]
			except: L3Z7qxkHcFjvWKPbg = False
			if L3Z7qxkHcFjvWKPbg and ZZEzx0vdikFU6Lu5:
				max = nt6lZ95gL0sbNYkQpWGiXrK['user_info']['max_connections']
				vUTmeqHgMZhB6cb15tAE2 = nt6lZ95gL0sbNYkQpWGiXrK['user_info']['active_cons']
				TD21EHxpC7dnzWhNu4U = nt6lZ95gL0sbNYkQpWGiXrK['user_info']['is_trial']
				dCBmo2FVcv75AkLRWZgIt4Q = n5RqEMBVZT0L2.split('?',1)
				a1duvQ8Vh0gNo69nDcp3Pjtym = 'URL:  '+bbTCMJwEx8nhN4X+n5RqEMBVZT0L2+NwROdSj3nsA
				a1duvQ8Vh0gNo69nDcp3Pjtym += '\n\nStatus:  '+bbTCMJwEx8nhN4X+AEK1sPFcoxpwzIiJBj0hC5f+NwROdSj3nsA
				a1duvQ8Vh0gNo69nDcp3Pjtym += '\nTrial:    '+bbTCMJwEx8nhN4X+str(TD21EHxpC7dnzWhNu4U=='1')+NwROdSj3nsA
				a1duvQ8Vh0gNo69nDcp3Pjtym += '\nCreated  At:  '+bbTCMJwEx8nhN4X+ffPUpieH2gF8GyhJ+NwROdSj3nsA
				a1duvQ8Vh0gNo69nDcp3Pjtym += '\nExpiry Date:  '+bbTCMJwEx8nhN4X+Hf6MGwaRxe9l8bnWS1ic+NwROdSj3nsA
				a1duvQ8Vh0gNo69nDcp3Pjtym += '\nConnections   ( Active / Maximum ) :  '+bbTCMJwEx8nhN4X+vUTmeqHgMZhB6cb15tAE2+' / '+max+NwROdSj3nsA
				a1duvQ8Vh0gNo69nDcp3Pjtym += '\nAllowed Outputs:   '+bbTCMJwEx8nhN4X+" , ".join(nt6lZ95gL0sbNYkQpWGiXrK['user_info']['allowed_output_formats'])+NwROdSj3nsA
				a1duvQ8Vh0gNo69nDcp3Pjtym += '\n\n'+msc8MWdjVx2o7Kz6XnryfSE
				if AEK1sPFcoxpwzIiJBj0hC5f=='Active': VryRxo21PBngU3('الاشتراك يعمل بدون مشاكل',a1duvQ8Vh0gNo69nDcp3Pjtym)
				else: VryRxo21PBngU3('يبدو أن هناك مشكلة في الاشتراك',a1duvQ8Vh0gNo69nDcp3Pjtym)
	if n5RqEMBVZT0L2 and L3Z7qxkHcFjvWKPbg and AEK1sPFcoxpwzIiJBj0hC5f=='Active':
		nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,'.\tChecking IPTV URL   [ IPTV account is OK ]   [ '+n5RqEMBVZT0L2+' ]')
		aZXjJt1MRcdoWT0EUB5yhxLCG = True
	else:
		nhR0UxwS4yDiABj7V1G8la(ybrna7mLOFVDUtRseQ3Tkf2zXS,'Checking IPTV URL   [ Does not work ]   [ '+n5RqEMBVZT0L2+' ]')
		if ZZEzx0vdikFU6Lu5: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		aZXjJt1MRcdoWT0EUB5yhxLCG = False
	return aZXjJt1MRcdoWT0EUB5yhxLCG,X0S7wkdetPNTAs9MaH3,l1Im6cu8sCKWtSxZUEMjhpdfeV5gb
def qTPzY96jGk8mQcNK3XvVHMUR4(dkq07Y6WG5enK1QlOLEU8uAj49x,LS9oDJNxeiTrgny,IZnRxG8uSPKzimk,L9Chqa1OZp0dfJ3s,ZZEzx0vdikFU6Lu5=True):
	if not L9Chqa1OZp0dfJ3s: L9Chqa1OZp0dfJ3s = '1'
	if not jx8bBYMhnguRAHoWtXLFml(dkq07Y6WG5enK1QlOLEU8uAj49x,ZZEzx0vdikFU6Lu5): return
	j5oVghLMlvCKDybz2FfkOPU3XWr0NE = kKmTYuDsdNl6WAqcj(dkq07Y6WG5enK1QlOLEU8uAj49x,LS9oDJNxeiTrgny)
	TX3ZNz2IOets9SW764QxP0Kaphg = CLAr1U2pRe3VhTP(j5oVghLMlvCKDybz2FfkOPU3XWr0NE,'list',LS9oDJNxeiTrgny,IZnRxG8uSPKzimk)
	ii63B0KHWVEcuwjS = int(L9Chqa1OZp0dfJ3s)*100
	zfD3NvSkIWi5QVasAY4gqc7Orpw8u = ii63B0KHWVEcuwjS-100
	for qjyki7XR1FW,v8JT61OEjNwKtXmheW,kOTdpYrPqu5A7UIcW0Ch,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX in TX3ZNz2IOets9SW764QxP0Kaphg[zfD3NvSkIWi5QVasAY4gqc7Orpw8u:ii63B0KHWVEcuwjS]:
		WWIjehXUlyTkMnmwbL9JS8ORYs4570 = ('GROUPED' in LS9oDJNxeiTrgny or LS9oDJNxeiTrgny=='ALL')
		ExuFiMZ5XYRo9jVvO1W = ('GROUPED' not in LS9oDJNxeiTrgny and LS9oDJNxeiTrgny!='ALL')
		if WWIjehXUlyTkMnmwbL9JS8ORYs4570 or ExuFiMZ5XYRo9jVvO1W:
			if   'ARCHIVED'  in LS9oDJNxeiTrgny: Nzp9Fq5cTr.menuItemsLIST.append(['folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+v8JT61OEjNwKtXmheW,kOTdpYrPqu5A7UIcW0Ch,238,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ARCHIVED',nA5dhMRg6ENzsB0l1GwvH7aIr2,{'folder':dkq07Y6WG5enK1QlOLEU8uAj49x}])
			elif 'EPG' 		 in LS9oDJNxeiTrgny: Nzp9Fq5cTr.menuItemsLIST.append(['folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+v8JT61OEjNwKtXmheW,kOTdpYrPqu5A7UIcW0Ch,238,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX,nA5dhMRg6ENzsB0l1GwvH7aIr2,'FULL_EPG',nA5dhMRg6ENzsB0l1GwvH7aIr2,{'folder':dkq07Y6WG5enK1QlOLEU8uAj49x}])
			elif 'TIMESHIFT' in LS9oDJNxeiTrgny: Nzp9Fq5cTr.menuItemsLIST.append(['folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+v8JT61OEjNwKtXmheW,kOTdpYrPqu5A7UIcW0Ch,238,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX,nA5dhMRg6ENzsB0l1GwvH7aIr2,'TIMESHIFT',nA5dhMRg6ENzsB0l1GwvH7aIr2,{'folder':dkq07Y6WG5enK1QlOLEU8uAj49x}])
			elif 'LIVE' 	 in LS9oDJNxeiTrgny: Nzp9Fq5cTr.menuItemsLIST.append(['live',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+v8JT61OEjNwKtXmheW,kOTdpYrPqu5A7UIcW0Ch,235,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,qjyki7XR1FW,{'folder':dkq07Y6WG5enK1QlOLEU8uAj49x}])
			else: Nzp9Fq5cTr.menuItemsLIST.append(['video',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+v8JT61OEjNwKtXmheW,kOTdpYrPqu5A7UIcW0Ch,235,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,{'folder':dkq07Y6WG5enK1QlOLEU8uAj49x}])
	v5nXoH1xdULBmpITwAb9Vy4tcs = len(TX3ZNz2IOets9SW764QxP0Kaphg)
	xxVd5HftDBAeLbmZTKkz(dkq07Y6WG5enK1QlOLEU8uAj49x,L9Chqa1OZp0dfJ3s,LS9oDJNxeiTrgny,234,v5nXoH1xdULBmpITwAb9Vy4tcs,IZnRxG8uSPKzimk)
	return
def TE6FRzGSetoDl1xqbX2rvIy3p0(yy7mLkAcNCw2PK5MibzpO8BX):
	TBt8bUDo9WhL('link',yy7mLkAcNCw2PK5MibzpO8BX+'هذه القائمة إما فارغة أو غير موجودة',nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('link',yy7mLkAcNCw2PK5MibzpO8BX+'أو الخدمة غير موجودة في اشتراكك',nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('link',yy7mLkAcNCw2PK5MibzpO8BX+'أو رابط IPTVـ الذي أنت أضفته غير صحيح',nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	return
def oHJ5CWIeGX8up7hTKxOdzNPrk(dkq07Y6WG5enK1QlOLEU8uAj49x,LS9oDJNxeiTrgny,IZnRxG8uSPKzimk,L9Chqa1OZp0dfJ3s,ccusBF3oQmX2Abf5=nA5dhMRg6ENzsB0l1GwvH7aIr2,ZZEzx0vdikFU6Lu5=True):
	if not L9Chqa1OZp0dfJ3s: L9Chqa1OZp0dfJ3s = '1'
	yy7mLkAcNCw2PK5MibzpO8BX = r1r9MU8jSNR2csPJnauFeWzvOGhl5q
	if not jx8bBYMhnguRAHoWtXLFml(dkq07Y6WG5enK1QlOLEU8uAj49x,ZZEzx0vdikFU6Lu5): return False
	if '__SERIES__' in IZnRxG8uSPKzimk: JlanhmC26NLbZ,Mz0rREWK7t4GhTCQZlyYsiwSLqm = IZnRxG8uSPKzimk.split('__SERIES__')
	else: JlanhmC26NLbZ,Mz0rREWK7t4GhTCQZlyYsiwSLqm = IZnRxG8uSPKzimk,nA5dhMRg6ENzsB0l1GwvH7aIr2
	j5oVghLMlvCKDybz2FfkOPU3XWr0NE = kKmTYuDsdNl6WAqcj(dkq07Y6WG5enK1QlOLEU8uAj49x,LS9oDJNxeiTrgny)
	cGoaCxfKV0PXOb7zM9 = CLAr1U2pRe3VhTP(j5oVghLMlvCKDybz2FfkOPU3XWr0NE,'list',LS9oDJNxeiTrgny,'__GROUPS__')
	if not cGoaCxfKV0PXOb7zM9: return False
	aQN7oEKpCeHxlLVr5bn8J9fYSFXD = []
	for ra9Zzwkm0SJAHgRcLoB3,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX in cGoaCxfKV0PXOb7zM9:
		if ccusBF3oQmX2Abf5:
			if '__SERIES__' in ra9Zzwkm0SJAHgRcLoB3: yy7mLkAcNCw2PK5MibzpO8BX = 'SERIES'
			elif '!!__UNKNOWN__!!' in ra9Zzwkm0SJAHgRcLoB3: yy7mLkAcNCw2PK5MibzpO8BX = 'UNKNOWN'
			elif 'LIVE' in LS9oDJNxeiTrgny: yy7mLkAcNCw2PK5MibzpO8BX = 'LIVE'
			else: yy7mLkAcNCw2PK5MibzpO8BX = 'VIDEOS'
			yy7mLkAcNCw2PK5MibzpO8BX = ','+bbTCMJwEx8nhN4X+yy7mLkAcNCw2PK5MibzpO8BX+': '+NwROdSj3nsA
		if '__SERIES__' in ra9Zzwkm0SJAHgRcLoB3: SS3g4lyHwG,ze9UdbWpsEK7PrFJt0gjfkSHvL = ra9Zzwkm0SJAHgRcLoB3.split('__SERIES__')
		else: SS3g4lyHwG,ze9UdbWpsEK7PrFJt0gjfkSHvL = ra9Zzwkm0SJAHgRcLoB3,nA5dhMRg6ENzsB0l1GwvH7aIr2
		if not IZnRxG8uSPKzimk:
			if SS3g4lyHwG in aQN7oEKpCeHxlLVr5bn8J9fYSFXD: continue
			aQN7oEKpCeHxlLVr5bn8J9fYSFXD.append(SS3g4lyHwG)
			if 'RANDOM' in ccusBF3oQmX2Abf5: TBt8bUDo9WhL('folder',yy7mLkAcNCw2PK5MibzpO8BX+SS3g4lyHwG,LS9oDJNxeiTrgny,167,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1',ra9Zzwkm0SJAHgRcLoB3,nA5dhMRg6ENzsB0l1GwvH7aIr2,{'folder':dkq07Y6WG5enK1QlOLEU8uAj49x})
			elif '__SERIES__' in ra9Zzwkm0SJAHgRcLoB3: TBt8bUDo9WhL('folder',yy7mLkAcNCw2PK5MibzpO8BX+SS3g4lyHwG,LS9oDJNxeiTrgny,233,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1',ra9Zzwkm0SJAHgRcLoB3,nA5dhMRg6ENzsB0l1GwvH7aIr2,{'folder':dkq07Y6WG5enK1QlOLEU8uAj49x})
			else: TBt8bUDo9WhL('folder',yy7mLkAcNCw2PK5MibzpO8BX+SS3g4lyHwG,LS9oDJNxeiTrgny,234,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1',ra9Zzwkm0SJAHgRcLoB3,nA5dhMRg6ENzsB0l1GwvH7aIr2,{'folder':dkq07Y6WG5enK1QlOLEU8uAj49x})
		elif '__SERIES__' in ra9Zzwkm0SJAHgRcLoB3 and SS3g4lyHwG==JlanhmC26NLbZ:
			if ze9UdbWpsEK7PrFJt0gjfkSHvL in aQN7oEKpCeHxlLVr5bn8J9fYSFXD: continue
			aQN7oEKpCeHxlLVr5bn8J9fYSFXD.append(ze9UdbWpsEK7PrFJt0gjfkSHvL)
			if 'RANDOM' in ccusBF3oQmX2Abf5: TBt8bUDo9WhL('folder',yy7mLkAcNCw2PK5MibzpO8BX+ze9UdbWpsEK7PrFJt0gjfkSHvL,LS9oDJNxeiTrgny,167,nA5dhMRg6ENzsB0l1GwvH7aIr2,'1',ra9Zzwkm0SJAHgRcLoB3,nA5dhMRg6ENzsB0l1GwvH7aIr2,{'folder':dkq07Y6WG5enK1QlOLEU8uAj49x})
			else: TBt8bUDo9WhL('folder',yy7mLkAcNCw2PK5MibzpO8BX+ze9UdbWpsEK7PrFJt0gjfkSHvL,LS9oDJNxeiTrgny,234,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX,'1',ra9Zzwkm0SJAHgRcLoB3,nA5dhMRg6ENzsB0l1GwvH7aIr2,{'folder':dkq07Y6WG5enK1QlOLEU8uAj49x})
	Nzp9Fq5cTr.menuItemsLIST[:] = sorted(Nzp9Fq5cTr.menuItemsLIST,reverse=False,key=lambda RRDE0VLWY7CgkuoXlQ4jTwUM23SK: RRDE0VLWY7CgkuoXlQ4jTwUM23SK[1].lower())
	if not ccusBF3oQmX2Abf5:
		ii63B0KHWVEcuwjS = int(L9Chqa1OZp0dfJ3s)*100
		zfD3NvSkIWi5QVasAY4gqc7Orpw8u = ii63B0KHWVEcuwjS-100
		v5nXoH1xdULBmpITwAb9Vy4tcs = len(Nzp9Fq5cTr.menuItemsLIST)
		Nzp9Fq5cTr.menuItemsLIST[:] = Nzp9Fq5cTr.menuItemsLIST[zfD3NvSkIWi5QVasAY4gqc7Orpw8u:ii63B0KHWVEcuwjS]
		xxVd5HftDBAeLbmZTKkz(dkq07Y6WG5enK1QlOLEU8uAj49x,L9Chqa1OZp0dfJ3s,LS9oDJNxeiTrgny,233,v5nXoH1xdULBmpITwAb9Vy4tcs,IZnRxG8uSPKzimk)
	return True
def IOc1asTKJ7DBWZFiUypEwCvlGhkPLA(dkq07Y6WG5enK1QlOLEU8uAj49x,kOTdpYrPqu5A7UIcW0Ch,e8kzmXfI2puUnGct):
	if not jx8bBYMhnguRAHoWtXLFml(dkq07Y6WG5enK1QlOLEU8uAj49x,True): return
	kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3 = ir4Kqb5p3N76S1yeQFf9dElHYILBt(dkq07Y6WG5enK1QlOLEU8uAj49x)
	llGrMZf5Ikmzo = KQctJbXeEjDhplqknU3rzi.getSetting('av.iptv.timestamp_'+dkq07Y6WG5enK1QlOLEU8uAj49x)
	if not llGrMZf5Ikmzo or GHSrzcU3jo2-int(llGrMZf5Ikmzo)>24*QhOXE7ztloReYp0nMVAIZb:
		aZXjJt1MRcdoWT0EUB5yhxLCG,X0S7wkdetPNTAs9MaH3,l1Im6cu8sCKWtSxZUEMjhpdfeV5gb = c3P0A8ltZuqo1OCXIy5(dkq07Y6WG5enK1QlOLEU8uAj49x,False)
		if not aZXjJt1MRcdoWT0EUB5yhxLCG: return
	DyxY1ENhbFRlMHXmQa8VTIu4iqCB0 = int(KQctJbXeEjDhplqknU3rzi.getSetting('av.iptv.timediff_'+dkq07Y6WG5enK1QlOLEU8uAj49x))
	M8nVAHG7lPzpb64Kho = KQctJbXeEjDhplqknU3rzi.getSetting('av.iptv.server_'+dkq07Y6WG5enK1QlOLEU8uAj49x)
	oKDEiS6bdRqkw1MFJ2ah = KQctJbXeEjDhplqknU3rzi.getSetting('av.iptv.username_'+dkq07Y6WG5enK1QlOLEU8uAj49x)
	ZNwox8KRnW1mP = KQctJbXeEjDhplqknU3rzi.getSetting('av.iptv.password_'+dkq07Y6WG5enK1QlOLEU8uAj49x)
	fSmPOY5o9sN = kOTdpYrPqu5A7UIcW0Ch.split('/')
	dosGBl7N42tHYpDQiMLez1EcnUCR = fSmPOY5o9sN[-1].replace('.ts',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('.m3u8',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	if e8kzmXfI2puUnGct=='SHORT_EPG': RjsQ5V7BZIO80CXM2Lk6lgGw = 'get_short_epg'
	else: RjsQ5V7BZIO80CXM2Lk6lgGw = 'get_simple_data_table'
	n5RqEMBVZT0L2,YUzvpc6yTixLVqO24m5ldKwFb1,M8nVAHG7lPzpb64Kho,oKDEiS6bdRqkw1MFJ2ah,ZNwox8KRnW1mP = JywhLB0sPzqC94Hl(dkq07Y6WG5enK1QlOLEU8uAj49x)
	if not oKDEiS6bdRqkw1MFJ2ah: return
	ohEx0qcN7Qw52tdJKVlsFWzag = n5RqEMBVZT0L2+'&action='+RjsQ5V7BZIO80CXM2Lk6lgGw+'&stream_id='+dosGBl7N42tHYpDQiMLez1EcnUCR
	PB1feMy50JE6xjCv4XAHhFNd8I2R = VcyqOptSYfTRmEHNZGl8siLzrMK3J(yy6RomT9bQhJf,ohEx0qcN7Qw52tdJKVlsFWzag,nA5dhMRg6ENzsB0l1GwvH7aIr2,kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3,nA5dhMRg6ENzsB0l1GwvH7aIr2,'IPTV-EPG_ITEMS-2nd')
	nkGOcag6wTC8tLzhyslUoJXQN71b = BwGPDSQOlfUas2n3eIH0ycFRWZ('dict',PB1feMy50JE6xjCv4XAHhFNd8I2R)
	v4vN8tBn5uqVFfA = nkGOcag6wTC8tLzhyslUoJXQN71b['epg_listings']
	uwyxo6KzhpmevaB487 = []
	if e8kzmXfI2puUnGct in ['ARCHIVED','TIMESHIFT']:
		for nt6lZ95gL0sbNYkQpWGiXrK in v4vN8tBn5uqVFfA:
			if nt6lZ95gL0sbNYkQpWGiXrK['has_archive']==1:
				uwyxo6KzhpmevaB487.append(nt6lZ95gL0sbNYkQpWGiXrK)
				if e8kzmXfI2puUnGct in ['TIMESHIFT']: break
		if not uwyxo6KzhpmevaB487: return
		TBt8bUDo9WhL('link',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+bbTCMJwEx8nhN4X+'الملفات الأولي بهذه القائمة قد لا تعمل'+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
		if e8kzmXfI2puUnGct in ['TIMESHIFT']:
			fB6LJRCiUjVOxEMgpkQ0wran1NHo = 2
			n9jPcZWBNEUStMJlTR2pDXaQbI = fB6LJRCiUjVOxEMgpkQ0wran1NHo*QhOXE7ztloReYp0nMVAIZb
			uwyxo6KzhpmevaB487 = []
			KeFX8wj0Aapi = int(int(nt6lZ95gL0sbNYkQpWGiXrK['start_timestamp'])/n9jPcZWBNEUStMJlTR2pDXaQbI)*n9jPcZWBNEUStMJlTR2pDXaQbI
			B6BClLuaI8qt1zb5EQRJ = GHSrzcU3jo2+n9jPcZWBNEUStMJlTR2pDXaQbI
			OPYqFI7US8cXC1toEp = int((B6BClLuaI8qt1zb5EQRJ-KeFX8wj0Aapi)/QhOXE7ztloReYp0nMVAIZb)
			for PnRFqykti9 in range(OPYqFI7US8cXC1toEp):
				if PnRFqykti9>=6:
					if PnRFqykti9%fB6LJRCiUjVOxEMgpkQ0wran1NHo!=0: continue
					gWC2upn5lKPMtRD37cG8wqd = n9jPcZWBNEUStMJlTR2pDXaQbI
				else: gWC2upn5lKPMtRD37cG8wqd = n9jPcZWBNEUStMJlTR2pDXaQbI//2
				EjCcW8mr56x0v2PnB3UJYLk7MQZ9 = KeFX8wj0Aapi+PnRFqykti9*QhOXE7ztloReYp0nMVAIZb
				nt6lZ95gL0sbNYkQpWGiXrK = {}
				nt6lZ95gL0sbNYkQpWGiXrK['title'] = nA5dhMRg6ENzsB0l1GwvH7aIr2
				fp907IWBdA6 = h0skHe7TcIY9x1UP5VBrZAE8dKGnl.localtime(EjCcW8mr56x0v2PnB3UJYLk7MQZ9-DyxY1ENhbFRlMHXmQa8VTIu4iqCB0-QhOXE7ztloReYp0nMVAIZb)
				nt6lZ95gL0sbNYkQpWGiXrK['start'] = h0skHe7TcIY9x1UP5VBrZAE8dKGnl.strftime('%Y.%m.%d %H:%M:%S',fp907IWBdA6)
				nt6lZ95gL0sbNYkQpWGiXrK['start_timestamp'] = str(EjCcW8mr56x0v2PnB3UJYLk7MQZ9)
				nt6lZ95gL0sbNYkQpWGiXrK['stop_timestamp'] = str(EjCcW8mr56x0v2PnB3UJYLk7MQZ9+gWC2upn5lKPMtRD37cG8wqd)
				uwyxo6KzhpmevaB487.append(nt6lZ95gL0sbNYkQpWGiXrK)
	elif e8kzmXfI2puUnGct in ['SHORT_EPG','FULL_EPG']: uwyxo6KzhpmevaB487 = v4vN8tBn5uqVFfA
	if e8kzmXfI2puUnGct=='FULL_EPG' and len(uwyxo6KzhpmevaB487)>0:
		TBt8bUDo9WhL('link',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+bbTCMJwEx8nhN4X+'هذه قائمة برامج القنوات (جدول فقط)ـ'+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	Zzb28REpPwOUIcdaKLM4tJviqAQy = []
	otyuV4JPfh5SiaKF9pbDY8AqkvlZHX = SoNGUfhMDERLyHOz1qkVAj.getInfoLabel('ListItem.Icon')
	for nt6lZ95gL0sbNYkQpWGiXrK in uwyxo6KzhpmevaB487:
		v8JT61OEjNwKtXmheW = Ic92Lb6lnzM5KJsx4Y3UGa70imZo.b64decode(nt6lZ95gL0sbNYkQpWGiXrK['title'])
		if BsLJ7p5Av2Vm0SQeCO1o: v8JT61OEjNwKtXmheW = v8JT61OEjNwKtXmheW.decode(YWEQ3Cf8RevpD0m7NjF1)
		EjCcW8mr56x0v2PnB3UJYLk7MQZ9 = int(nt6lZ95gL0sbNYkQpWGiXrK['start_timestamp'])
		yKtoTGJg3vxasjhmpO = int(nt6lZ95gL0sbNYkQpWGiXrK['stop_timestamp'])
		YCOQsbnp8NxLutG6T5 = str(int((yKtoTGJg3vxasjhmpO-EjCcW8mr56x0v2PnB3UJYLk7MQZ9+59)/60))
		zokWFcbSasOxENRfAvhGn = nt6lZ95gL0sbNYkQpWGiXrK['start'].replace(hSXlxL9iB05c,':')
		fp907IWBdA6 = h0skHe7TcIY9x1UP5VBrZAE8dKGnl.localtime(EjCcW8mr56x0v2PnB3UJYLk7MQZ9-QhOXE7ztloReYp0nMVAIZb)
		j90IqPkCzWVL4ScTOos = h0skHe7TcIY9x1UP5VBrZAE8dKGnl.strftime('%H:%M',fp907IWBdA6)
		CCESTFpIvm0gV = h0skHe7TcIY9x1UP5VBrZAE8dKGnl.strftime('%a',fp907IWBdA6)
		if e8kzmXfI2puUnGct=='SHORT_EPG': v8JT61OEjNwKtXmheW = lSWzOYmN08+j90IqPkCzWVL4ScTOos+' ـ '+v8JT61OEjNwKtXmheW+NwROdSj3nsA
		elif e8kzmXfI2puUnGct=='TIMESHIFT': v8JT61OEjNwKtXmheW = CCESTFpIvm0gV+hSXlxL9iB05c+j90IqPkCzWVL4ScTOos+' ('+YCOQsbnp8NxLutG6T5+'min)'
		else: v8JT61OEjNwKtXmheW = CCESTFpIvm0gV+hSXlxL9iB05c+j90IqPkCzWVL4ScTOos+' ('+YCOQsbnp8NxLutG6T5+'min)   '+v8JT61OEjNwKtXmheW+' ـ'
		if e8kzmXfI2puUnGct in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			vNVJkXSKMYu8pQrUmP5 = M8nVAHG7lPzpb64Kho+'/timeshift/'+oKDEiS6bdRqkw1MFJ2ah+'/'+ZNwox8KRnW1mP+'/'+YCOQsbnp8NxLutG6T5+'/'+zokWFcbSasOxENRfAvhGn+'/'+dosGBl7N42tHYpDQiMLez1EcnUCR+'.m3u8'
			if e8kzmXfI2puUnGct=='FULL_EPG': TBt8bUDo9WhL('link',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+v8JT61OEjNwKtXmheW,vNVJkXSKMYu8pQrUmP5,9999,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,{'folder':dkq07Y6WG5enK1QlOLEU8uAj49x})
			else: TBt8bUDo9WhL('video',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+v8JT61OEjNwKtXmheW,vNVJkXSKMYu8pQrUmP5,235,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,{'folder':dkq07Y6WG5enK1QlOLEU8uAj49x})
		Zzb28REpPwOUIcdaKLM4tJviqAQy.append(v8JT61OEjNwKtXmheW)
	if e8kzmXfI2puUnGct=='SHORT_EPG' and Zzb28REpPwOUIcdaKLM4tJviqAQy: uCYLVmQj4pvKA6lx8JzBFofDh = BaYvn3uN2cKT(Zzb28REpPwOUIcdaKLM4tJviqAQy)
	return Zzb28REpPwOUIcdaKLM4tJviqAQy
def tyFquKhIMsa(dkq07Y6WG5enK1QlOLEU8uAj49x):
	if not jx8bBYMhnguRAHoWtXLFml(dkq07Y6WG5enK1QlOLEU8uAj49x,True): return
	M8nVAHG7lPzpb64Kho,PPzpoSDfTlCGd95HW,MwoXsh1rPIJ8RW = nA5dhMRg6ENzsB0l1GwvH7aIr2,0,0
	aZXjJt1MRcdoWT0EUB5yhxLCG,X0S7wkdetPNTAs9MaH3,l1Im6cu8sCKWtSxZUEMjhpdfeV5gb = c3P0A8ltZuqo1OCXIy5(dkq07Y6WG5enK1QlOLEU8uAj49x,False)
	if aZXjJt1MRcdoWT0EUB5yhxLCG:
		BAfRlLX3nzWj25T = cch8fV9GQvyt7rlp5WzuCbi(X0S7wkdetPNTAs9MaH3)
		PPzpoSDfTlCGd95HW = e1MtrcQ06UEH(BAfRlLX3nzWj25T[0],int(l1Im6cu8sCKWtSxZUEMjhpdfeV5gb))
		j5oVghLMlvCKDybz2FfkOPU3XWr0NE = kKmTYuDsdNl6WAqcj(dkq07Y6WG5enK1QlOLEU8uAj49x,'LIVE_GROUPED')
		APChJW6GTDdK = CLAr1U2pRe3VhTP(j5oVghLMlvCKDybz2FfkOPU3XWr0NE,'list','LIVE_GROUPED')
		TX3ZNz2IOets9SW764QxP0Kaphg = CLAr1U2pRe3VhTP(j5oVghLMlvCKDybz2FfkOPU3XWr0NE,'list','LIVE_GROUPED',APChJW6GTDdK[1])
		kOTdpYrPqu5A7UIcW0Ch = TX3ZNz2IOets9SW764QxP0Kaphg[0][2]
		ITYW2Us1zfe9J04LrHNkj3wAm = PAztbuyYo4Kvd.findall('://(.*?)/',kOTdpYrPqu5A7UIcW0Ch,PAztbuyYo4Kvd.DOTALL)
		ITYW2Us1zfe9J04LrHNkj3wAm = ITYW2Us1zfe9J04LrHNkj3wAm[0]
		if ':' in ITYW2Us1zfe9J04LrHNkj3wAm: aIgS0wxJ2ri,kTjRFVXQ43vpg = ITYW2Us1zfe9J04LrHNkj3wAm.split(':')
		else: aIgS0wxJ2ri,kTjRFVXQ43vpg = ITYW2Us1zfe9J04LrHNkj3wAm,'80'
		ikfCKRX5VaB6epmI2W = cch8fV9GQvyt7rlp5WzuCbi(aIgS0wxJ2ri)
		MwoXsh1rPIJ8RW = e1MtrcQ06UEH(ikfCKRX5VaB6epmI2W[0],int(kTjRFVXQ43vpg))
	if PPzpoSDfTlCGd95HW and MwoXsh1rPIJ8RW:
		a1duvQ8Vh0gNo69nDcp3Pjtym = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		a1duvQ8Vh0gNo69nDcp3Pjtym += '\n\n'+'وقت ضائع في السيرفر الأصلي'+CXtugbqhV3+str(int(MwoXsh1rPIJ8RW*1000))+' ملي ثانية'
		a1duvQ8Vh0gNo69nDcp3Pjtym += '\n\n'+'وقت ضائع في السيرفر البديل'+CXtugbqhV3+str(int(PPzpoSDfTlCGd95HW*1000))+' ملي ثانية'
		dQG457SnHylm1vL = bjyB5J1QuNaIXOx9qSwm4v0edDhg('center','السيرفر الأصلي','السيرفر الأسرع',OksCHeoL5SG,a1duvQ8Vh0gNo69nDcp3Pjtym)
		if dQG457SnHylm1vL==1 and PPzpoSDfTlCGd95HW<MwoXsh1rPIJ8RW: M8nVAHG7lPzpb64Kho = X0S7wkdetPNTAs9MaH3+':'+l1Im6cu8sCKWtSxZUEMjhpdfeV5gb
	else: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'البرنامج لم يجد السيرفر البديل')
	KQctJbXeEjDhplqknU3rzi.setSetting('av.iptv.server_'+dkq07Y6WG5enK1QlOLEU8uAj49x,M8nVAHG7lPzpb64Kho)
	return
def lNBcUr8RCn(dkq07Y6WG5enK1QlOLEU8uAj49x,kOTdpYrPqu5A7UIcW0Ch,WTavfhd7QJDABwpIVrZqHL):
	VrzqC0iQeygP64pvdKMTIuUEWaBX19 = KQctJbXeEjDhplqknU3rzi.getSetting('av.iptv.useragent_'+dkq07Y6WG5enK1QlOLEU8uAj49x)
	TjKXRuIe3W = KQctJbXeEjDhplqknU3rzi.getSetting('av.iptv.referer_'+dkq07Y6WG5enK1QlOLEU8uAj49x)
	if VrzqC0iQeygP64pvdKMTIuUEWaBX19 or TjKXRuIe3W:
		kOTdpYrPqu5A7UIcW0Ch += '|'
		if VrzqC0iQeygP64pvdKMTIuUEWaBX19: kOTdpYrPqu5A7UIcW0Ch += '&User-Agent='+VrzqC0iQeygP64pvdKMTIuUEWaBX19
		if TjKXRuIe3W: kOTdpYrPqu5A7UIcW0Ch += '&Referer='+TjKXRuIe3W
		kOTdpYrPqu5A7UIcW0Ch = kOTdpYrPqu5A7UIcW0Ch.replace('|&','|')
	mRY6y3Zr1z7vFi5wDgXHSLkpt = KQctJbXeEjDhplqknU3rzi.getSetting('av.iptv.server_'+dkq07Y6WG5enK1QlOLEU8uAj49x)
	if mRY6y3Zr1z7vFi5wDgXHSLkpt:
		F5QjIiEhgvdcnNGmJD9ZYAy = PAztbuyYo4Kvd.findall('://(.*?)/',kOTdpYrPqu5A7UIcW0Ch,PAztbuyYo4Kvd.DOTALL)
		kOTdpYrPqu5A7UIcW0Ch = kOTdpYrPqu5A7UIcW0Ch.replace(F5QjIiEhgvdcnNGmJD9ZYAy[0],mRY6y3Zr1z7vFi5wDgXHSLkpt)
	ocUnzjShqIO35vZi8bk64pVKMCTBaw(kOTdpYrPqu5A7UIcW0Ch,kNfc1ZX0HTKjpQImqiuy49g85G7UVa,WTavfhd7QJDABwpIVrZqHL)
	return
def ibDuhN4oRfMVp2TH06Bg1I3JqOFdyc(dkq07Y6WG5enK1QlOLEU8uAj49x):
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـUser-Agent خاص')
	VrzqC0iQeygP64pvdKMTIuUEWaBX19 = KQctJbXeEjDhplqknU3rzi.getSetting('av.iptv.useragent_'+dkq07Y6WG5enK1QlOLEU8uAj49x)
	oo0xd4bTCMmDhilAPBLs = bjyB5J1QuNaIXOx9qSwm4v0edDhg('center','استخدام الأصلي','تعديل القديم',VrzqC0iQeygP64pvdKMTIuUEWaBX19,'هذا هو ـUser-Agent المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if oo0xd4bTCMmDhilAPBLs==1: VrzqC0iQeygP64pvdKMTIuUEWaBX19 = FaUBpzTGxtS7hZyl('أكتب ـIPTV User-Agent جديد',VrzqC0iQeygP64pvdKMTIuUEWaBX19,True)
	else: VrzqC0iQeygP64pvdKMTIuUEWaBX19 = 'Unknown'
	if VrzqC0iQeygP64pvdKMTIuUEWaBX19==hSXlxL9iB05c:
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	oo0xd4bTCMmDhilAPBLs = bjyB5J1QuNaIXOx9qSwm4v0edDhg('center',nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,VrzqC0iQeygP64pvdKMTIuUEWaBX19,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if oo0xd4bTCMmDhilAPBLs!=1:
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'تم الإلغاء')
		return
	KQctJbXeEjDhplqknU3rzi.setSetting('av.iptv.useragent_'+dkq07Y6WG5enK1QlOLEU8uAj49x,VrzqC0iQeygP64pvdKMTIuUEWaBX19)
	Q8rLzHaSPp4bFfvZNDcMVywx3G(dkq07Y6WG5enK1QlOLEU8uAj49x)
	return
def aeYqKcUBg0LdJlvAmpMTtP(dkq07Y6WG5enK1QlOLEU8uAj49x):
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـReferer خاص')
	TjKXRuIe3W = KQctJbXeEjDhplqknU3rzi.getSetting('av.iptv.referer_'+dkq07Y6WG5enK1QlOLEU8uAj49x)
	oo0xd4bTCMmDhilAPBLs = bjyB5J1QuNaIXOx9qSwm4v0edDhg('center','استخدام الأصلي','تعديل القديم',TjKXRuIe3W,'هذا هو ـReferer المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if oo0xd4bTCMmDhilAPBLs==1: TjKXRuIe3W = FaUBpzTGxtS7hZyl('أكتب ـIPTV Referer جديد',TjKXRuIe3W,True)
	else: TjKXRuIe3W = nA5dhMRg6ENzsB0l1GwvH7aIr2
	if TjKXRuIe3W==hSXlxL9iB05c:
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	oo0xd4bTCMmDhilAPBLs = bjyB5J1QuNaIXOx9qSwm4v0edDhg('center',nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,TjKXRuIe3W,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if oo0xd4bTCMmDhilAPBLs!=1:
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'تم الإلغاء')
		return
	KQctJbXeEjDhplqknU3rzi.setSetting('av.iptv.referer_'+dkq07Y6WG5enK1QlOLEU8uAj49x,TjKXRuIe3W)
	Q8rLzHaSPp4bFfvZNDcMVywx3G(dkq07Y6WG5enK1QlOLEU8uAj49x)
	return
def JywhLB0sPzqC94Hl(dkq07Y6WG5enK1QlOLEU8uAj49x,U35APMhve7WqDmT1YgwV2N=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if not U35APMhve7WqDmT1YgwV2N: U35APMhve7WqDmT1YgwV2N = KQctJbXeEjDhplqknU3rzi.getSetting('av.iptv.url_'+dkq07Y6WG5enK1QlOLEU8uAj49x)
	M8nVAHG7lPzpb64Kho = C2gnJ5tXFk9pAL(U35APMhve7WqDmT1YgwV2N,'url')
	oKDEiS6bdRqkw1MFJ2ah = PAztbuyYo4Kvd.findall('username=(.*?)&',U35APMhve7WqDmT1YgwV2N+'&',PAztbuyYo4Kvd.DOTALL)
	ZNwox8KRnW1mP = PAztbuyYo4Kvd.findall('password=(.*?)&',U35APMhve7WqDmT1YgwV2N+'&',PAztbuyYo4Kvd.DOTALL)
	if not oKDEiS6bdRqkw1MFJ2ah or not ZNwox8KRnW1mP:
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		return nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	oKDEiS6bdRqkw1MFJ2ah = oKDEiS6bdRqkw1MFJ2ah[0]
	ZNwox8KRnW1mP = ZNwox8KRnW1mP[0]
	n5RqEMBVZT0L2 = M8nVAHG7lPzpb64Kho+'/player_api.php?username='+oKDEiS6bdRqkw1MFJ2ah+'&password='+ZNwox8KRnW1mP
	YUzvpc6yTixLVqO24m5ldKwFb1 = M8nVAHG7lPzpb64Kho+'/get.php?username='+oKDEiS6bdRqkw1MFJ2ah+'&password='+ZNwox8KRnW1mP+'&type=m3u_plus'
	return n5RqEMBVZT0L2,YUzvpc6yTixLVqO24m5ldKwFb1,M8nVAHG7lPzpb64Kho,oKDEiS6bdRqkw1MFJ2ah,ZNwox8KRnW1mP
def XXub1xAr37pLt8zPfT9dJBv(dkq07Y6WG5enK1QlOLEU8uAj49x,JN41xFAcoaXsQgM5BzvqUeHP=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	prw120syvAPaxlngVGDiz7BKjL = JN41xFAcoaXsQgM5BzvqUeHP.replace('/','_').replace(':','_').replace('.','_')
	prw120syvAPaxlngVGDiz7BKjL = prw120syvAPaxlngVGDiz7BKjL.replace('?','_').replace('=','_').replace('&','_')
	prw120syvAPaxlngVGDiz7BKjL = XoZRpFe7B6gnfA.path.join(QQwBc24Oza7jJ8ClTRWexUoqGAkg0,prw120syvAPaxlngVGDiz7BKjL).strip('.m3u')+'.m3u'
	return prw120syvAPaxlngVGDiz7BKjL
def WWH0ca5PyIkL2C(dkq07Y6WG5enK1QlOLEU8uAj49x):
	PJf96l2EkLz7vZXQcR01t8m = KQctJbXeEjDhplqknU3rzi.getSetting('av.iptv.url_'+dkq07Y6WG5enK1QlOLEU8uAj49x)
	QnJjpH5Elg91dDX6hFTaKeSq = True
	if PJf96l2EkLz7vZXQcR01t8m:
		oo0xd4bTCMmDhilAPBLs = vnI6XSlmEtsx7('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',bbTCMJwEx8nhN4X+PJf96l2EkLz7vZXQcR01t8m+NwROdSj3nsA+'\n\n هذا هو رابط ـIPTV المسجل في البرنامج ... هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if oo0xd4bTCMmDhilAPBLs==-1: return
		elif oo0xd4bTCMmDhilAPBLs==0: PJf96l2EkLz7vZXQcR01t8m = nA5dhMRg6ENzsB0l1GwvH7aIr2
		elif oo0xd4bTCMmDhilAPBLs==2:
			oo0xd4bTCMmDhilAPBLs = bjyB5J1QuNaIXOx9qSwm4v0edDhg('center',nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if oo0xd4bTCMmDhilAPBLs in [-1,0]: return
			OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'تم مسح الرابط')
			QnJjpH5Elg91dDX6hFTaKeSq = False
			LL0lsp8NXDjJuIhmZYnx2T4QF = nA5dhMRg6ENzsB0l1GwvH7aIr2
	if QnJjpH5Elg91dDX6hFTaKeSq:
		LL0lsp8NXDjJuIhmZYnx2T4QF = FaUBpzTGxtS7hZyl('اكتب رابط ـIPTV كاملا',PJf96l2EkLz7vZXQcR01t8m)
		LL0lsp8NXDjJuIhmZYnx2T4QF = LL0lsp8NXDjJuIhmZYnx2T4QF.strip(hSXlxL9iB05c)
		if not LL0lsp8NXDjJuIhmZYnx2T4QF:
			oo0xd4bTCMmDhilAPBLs = bjyB5J1QuNaIXOx9qSwm4v0edDhg('center',nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if oo0xd4bTCMmDhilAPBLs in [-1,0]: return
			OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'تم مسح الرابط')
	else:
		n5RqEMBVZT0L2,YUzvpc6yTixLVqO24m5ldKwFb1,M8nVAHG7lPzpb64Kho,oKDEiS6bdRqkw1MFJ2ah,ZNwox8KRnW1mP = JywhLB0sPzqC94Hl(dkq07Y6WG5enK1QlOLEU8uAj49x,LL0lsp8NXDjJuIhmZYnx2T4QF)
		if not oKDEiS6bdRqkw1MFJ2ah: return
		a1duvQ8Vh0gNo69nDcp3Pjtym = 'هذه المعلومات تم أخذها من رابط ـIPTV الذي انت كتبته . هل تريد استخدامها ؟!\n'
		a1duvQ8Vh0gNo69nDcp3Pjtym += CXtugbqhV3+lSWzOYmN08+M8nVAHG7lPzpb64Kho+NwROdSj3nsA+'عنوان السيرفر: '
		a1duvQ8Vh0gNo69nDcp3Pjtym += CXtugbqhV3+lSWzOYmN08+oKDEiS6bdRqkw1MFJ2ah+NwROdSj3nsA+'اسم المستخدم: '
		a1duvQ8Vh0gNo69nDcp3Pjtym += CXtugbqhV3+lSWzOYmN08+rY7tVDb1CZoxk0++'كلمة السر: '
		oo0xd4bTCMmDhilAPBLs = bjyB5J1QuNaIXOx9qSwm4v0edDhg('right',nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'الرابط الجديد هو:',bbTCMJwEx8nhN4X+LL0lsp8NXDjJuIhmZYnx2T4QF+NwROdSj3nsA+'\n\n'+a1duvQ8Vh0gNo69nDcp3Pjtym)
		if oo0xd4bTCMmDhilAPBLs!=1:
			OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'تم الإلغاء')
			return
	KQctJbXeEjDhplqknU3rzi.setSetting('av.iptv.url_'+dkq07Y6WG5enK1QlOLEU8uAj49x,LL0lsp8NXDjJuIhmZYnx2T4QF)
	KQctJbXeEjDhplqknU3rzi.setSetting('av.iptv.timestamp_'+dkq07Y6WG5enK1QlOLEU8uAj49x,nA5dhMRg6ENzsB0l1GwvH7aIr2)
	KQctJbXeEjDhplqknU3rzi.setSetting('av.iptv.timediff_'+dkq07Y6WG5enK1QlOLEU8uAj49x,nA5dhMRg6ENzsB0l1GwvH7aIr2)
	VrzqC0iQeygP64pvdKMTIuUEWaBX19 = KQctJbXeEjDhplqknU3rzi.getSetting('av.iptv.useragent_'+dkq07Y6WG5enK1QlOLEU8uAj49x)
	if not VrzqC0iQeygP64pvdKMTIuUEWaBX19: KQctJbXeEjDhplqknU3rzi.setSetting('av.iptv.useragent_'+dkq07Y6WG5enK1QlOLEU8uAj49x,'Unknown')
	tKiCUv4E96yxWT7r = bjyB5J1QuNaIXOx9qSwm4v0edDhg('center',nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,LL0lsp8NXDjJuIhmZYnx2T4QF+'\n\nتم تغير رابط اشتراك ـIPTV إلى هذا الرابط الجديد ... هل تريد فحص هذا الرابط الآن ؟')
	if tKiCUv4E96yxWT7r==1: aZXjJt1MRcdoWT0EUB5yhxLCG,X0S7wkdetPNTAs9MaH3,l1Im6cu8sCKWtSxZUEMjhpdfeV5gb = c3P0A8ltZuqo1OCXIy5(dkq07Y6WG5enK1QlOLEU8uAj49x,True)
	Q8rLzHaSPp4bFfvZNDcMVywx3G(dkq07Y6WG5enK1QlOLEU8uAj49x)
	return
def FgmfBcVwT32z5erlj(iAcpSGqr7yTotbZBXkN4,aagZ2YWnkUDOpcPr,YjBZT9oizvasK0dSer3xD4pfbIC,uvEp2OVtGJmADgyMIjYHnw,DZ0htFdQal58pI49oWy,N97NarvCiOW5uUGITznKV4gsecqh,YUzvpc6yTixLVqO24m5ldKwFb1):
	TX3ZNz2IOets9SW764QxP0Kaphg,u7UtlVf8a5kDP9I = [],[]
	We7VTLhwXD32ytgCiU5dHIPQjBq = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for QQkCeBnHPEcsl6xrUTYSZ20Lo in iAcpSGqr7yTotbZBXkN4:
		if N97NarvCiOW5uUGITznKV4gsecqh%473==0:
			buQ2eMwxvTinjNrLVpUm6IH8fq(uvEp2OVtGJmADgyMIjYHnw,40+int(10*N97NarvCiOW5uUGITznKV4gsecqh/DZ0htFdQal58pI49oWy),'قراءة الفيديوهات','الفيديو رقم:-',str(N97NarvCiOW5uUGITznKV4gsecqh)+' / '+str(DZ0htFdQal58pI49oWy))
			if uvEp2OVtGJmADgyMIjYHnw.iscanceled():
				uvEp2OVtGJmADgyMIjYHnw.close()
				return None,None,None
		kOTdpYrPqu5A7UIcW0Ch = PAztbuyYo4Kvd.findall('^(.*?)\n+((http|https|rtmp).*?)$',QQkCeBnHPEcsl6xrUTYSZ20Lo,PAztbuyYo4Kvd.DOTALL)
		if kOTdpYrPqu5A7UIcW0Ch:
			QQkCeBnHPEcsl6xrUTYSZ20Lo,kOTdpYrPqu5A7UIcW0Ch,NbaWkXeUGq26YhRISVouD = kOTdpYrPqu5A7UIcW0Ch[0]
			kOTdpYrPqu5A7UIcW0Ch = kOTdpYrPqu5A7UIcW0Ch.replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2)
			QQkCeBnHPEcsl6xrUTYSZ20Lo = QQkCeBnHPEcsl6xrUTYSZ20Lo.replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2)
		else:
			u7UtlVf8a5kDP9I.append({'line':QQkCeBnHPEcsl6xrUTYSZ20Lo})
			continue
		TlSnpKz8qAsiNybkj1Ir0X9U,qjyki7XR1FW,ra9Zzwkm0SJAHgRcLoB3,v8JT61OEjNwKtXmheW,WTavfhd7QJDABwpIVrZqHL,uncCV3ERDWyzb5pLO9Fog6B = {},nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,False
		try:
			QQkCeBnHPEcsl6xrUTYSZ20Lo,v8JT61OEjNwKtXmheW = QQkCeBnHPEcsl6xrUTYSZ20Lo.rsplit('",',1)
			QQkCeBnHPEcsl6xrUTYSZ20Lo = QQkCeBnHPEcsl6xrUTYSZ20Lo+'"'
		except:
			try: QQkCeBnHPEcsl6xrUTYSZ20Lo,v8JT61OEjNwKtXmheW = QQkCeBnHPEcsl6xrUTYSZ20Lo.rsplit('1,',1)
			except: v8JT61OEjNwKtXmheW = nA5dhMRg6ENzsB0l1GwvH7aIr2
		TlSnpKz8qAsiNybkj1Ir0X9U['url'] = kOTdpYrPqu5A7UIcW0Ch
		m8MowZjxdQhO7a2D1 = PAztbuyYo4Kvd.findall(' (.*?)="(.*?)"',QQkCeBnHPEcsl6xrUTYSZ20Lo,PAztbuyYo4Kvd.DOTALL)
		for RRDE0VLWY7CgkuoXlQ4jTwUM23SK,jS6mozBH5x87aliFAUZqgJRMI2rG in m8MowZjxdQhO7a2D1:
			RRDE0VLWY7CgkuoXlQ4jTwUM23SK = RRDE0VLWY7CgkuoXlQ4jTwUM23SK.replace('"',nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c)
			TlSnpKz8qAsiNybkj1Ir0X9U[RRDE0VLWY7CgkuoXlQ4jTwUM23SK] = jS6mozBH5x87aliFAUZqgJRMI2rG.strip(hSXlxL9iB05c)
		jUNScgAfpO1kVb = list(TlSnpKz8qAsiNybkj1Ir0X9U.keys())
		if not v8JT61OEjNwKtXmheW:
			if 'name' in jUNScgAfpO1kVb and TlSnpKz8qAsiNybkj1Ir0X9U['name']: v8JT61OEjNwKtXmheW = TlSnpKz8qAsiNybkj1Ir0X9U['name']
		TlSnpKz8qAsiNybkj1Ir0X9U['title'] = v8JT61OEjNwKtXmheW.strip(hSXlxL9iB05c).replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c).replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c)
		if 'logo' in jUNScgAfpO1kVb:
			TlSnpKz8qAsiNybkj1Ir0X9U['img'] = TlSnpKz8qAsiNybkj1Ir0X9U['logo']
			del TlSnpKz8qAsiNybkj1Ir0X9U['logo']
		else: TlSnpKz8qAsiNybkj1Ir0X9U['img'] = nA5dhMRg6ENzsB0l1GwvH7aIr2
		if 'group' in jUNScgAfpO1kVb and TlSnpKz8qAsiNybkj1Ir0X9U['group']: ra9Zzwkm0SJAHgRcLoB3 = TlSnpKz8qAsiNybkj1Ir0X9U['group']
		if any(value in kOTdpYrPqu5A7UIcW0Ch.lower() for value in We7VTLhwXD32ytgCiU5dHIPQjBq):
			uncCV3ERDWyzb5pLO9Fog6B = True if 'm3u' not in kOTdpYrPqu5A7UIcW0Ch else False
		if uncCV3ERDWyzb5pLO9Fog6B or '__SERIES__' in ra9Zzwkm0SJAHgRcLoB3 or '__MOVIES__' in ra9Zzwkm0SJAHgRcLoB3:
			WTavfhd7QJDABwpIVrZqHL = 'VOD'
			if '__SERIES__' in ra9Zzwkm0SJAHgRcLoB3: WTavfhd7QJDABwpIVrZqHL = WTavfhd7QJDABwpIVrZqHL+'_SERIES'
			elif '__MOVIES__' in ra9Zzwkm0SJAHgRcLoB3: WTavfhd7QJDABwpIVrZqHL = WTavfhd7QJDABwpIVrZqHL+'_MOVIES'
			else: WTavfhd7QJDABwpIVrZqHL = WTavfhd7QJDABwpIVrZqHL+'_UNKNOWN'
			ra9Zzwkm0SJAHgRcLoB3 = ra9Zzwkm0SJAHgRcLoB3.replace('__SERIES__',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('__MOVIES__',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		else:
			WTavfhd7QJDABwpIVrZqHL = 'LIVE'
			if v8JT61OEjNwKtXmheW in aagZ2YWnkUDOpcPr: qjyki7XR1FW = qjyki7XR1FW+'_EPG'
			if v8JT61OEjNwKtXmheW in YjBZT9oizvasK0dSer3xD4pfbIC: qjyki7XR1FW = qjyki7XR1FW+'_ARCHIVED'
			if not ra9Zzwkm0SJAHgRcLoB3: WTavfhd7QJDABwpIVrZqHL = WTavfhd7QJDABwpIVrZqHL+'_UNKNOWN'
			else: WTavfhd7QJDABwpIVrZqHL = WTavfhd7QJDABwpIVrZqHL+qjyki7XR1FW
		ra9Zzwkm0SJAHgRcLoB3 = ra9Zzwkm0SJAHgRcLoB3.strip(hSXlxL9iB05c).replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c).replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c)
		if 'LIVE_UNKNOWN' in WTavfhd7QJDABwpIVrZqHL: ra9Zzwkm0SJAHgRcLoB3 = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in WTavfhd7QJDABwpIVrZqHL: ra9Zzwkm0SJAHgRcLoB3 = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in WTavfhd7QJDABwpIVrZqHL:
			hbEIQvjJr63fgdzBp9 = PAztbuyYo4Kvd.findall('(.*?) [Ss]\d+ +[Ee]\d+',TlSnpKz8qAsiNybkj1Ir0X9U['title'],PAztbuyYo4Kvd.DOTALL)
			if hbEIQvjJr63fgdzBp9: hbEIQvjJr63fgdzBp9 = hbEIQvjJr63fgdzBp9[0]
			else: hbEIQvjJr63fgdzBp9 = '!!__UNKNOWN_SERIES__!!'
			ra9Zzwkm0SJAHgRcLoB3 = ra9Zzwkm0SJAHgRcLoB3+'__SERIES__'+hbEIQvjJr63fgdzBp9
		if 'id' in jUNScgAfpO1kVb: del TlSnpKz8qAsiNybkj1Ir0X9U['id']
		if 'ID' in jUNScgAfpO1kVb: del TlSnpKz8qAsiNybkj1Ir0X9U['ID']
		if 'name' in jUNScgAfpO1kVb: del TlSnpKz8qAsiNybkj1Ir0X9U['name']
		v8JT61OEjNwKtXmheW = TlSnpKz8qAsiNybkj1Ir0X9U['title']
		v8JT61OEjNwKtXmheW = jPgzFLH1niJpE2r(v8JT61OEjNwKtXmheW)
		v8JT61OEjNwKtXmheW = YzX5ljLC8FUEBKRcT160oOwsIgb(v8JT61OEjNwKtXmheW)
		jPgtHLvJUkr,ra9Zzwkm0SJAHgRcLoB3 = mmwJElVaL2dFpXegBcz6nWZKkh0T5Q(ra9Zzwkm0SJAHgRcLoB3)
		ZPJvufyUQbzLrO2gSM8dRlDnX,v8JT61OEjNwKtXmheW = mmwJElVaL2dFpXegBcz6nWZKkh0T5Q(v8JT61OEjNwKtXmheW)
		TlSnpKz8qAsiNybkj1Ir0X9U['type'] = WTavfhd7QJDABwpIVrZqHL
		TlSnpKz8qAsiNybkj1Ir0X9U['context'] = qjyki7XR1FW
		TlSnpKz8qAsiNybkj1Ir0X9U['group'] = ra9Zzwkm0SJAHgRcLoB3.upper()
		TlSnpKz8qAsiNybkj1Ir0X9U['title'] = v8JT61OEjNwKtXmheW.upper()
		TlSnpKz8qAsiNybkj1Ir0X9U['country'] = ZPJvufyUQbzLrO2gSM8dRlDnX.upper()
		TlSnpKz8qAsiNybkj1Ir0X9U['language'] = jPgtHLvJUkr.upper()
		TX3ZNz2IOets9SW764QxP0Kaphg.append(TlSnpKz8qAsiNybkj1Ir0X9U)
		N97NarvCiOW5uUGITznKV4gsecqh += 1
	return TX3ZNz2IOets9SW764QxP0Kaphg,N97NarvCiOW5uUGITznKV4gsecqh,u7UtlVf8a5kDP9I
def YzX5ljLC8FUEBKRcT160oOwsIgb(v8JT61OEjNwKtXmheW):
	v8JT61OEjNwKtXmheW = v8JT61OEjNwKtXmheW.replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c).replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c).replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c)
	v8JT61OEjNwKtXmheW = v8JT61OEjNwKtXmheW.replace('||','|').replace('___',':').replace('--','-')
	v8JT61OEjNwKtXmheW = v8JT61OEjNwKtXmheW.replace('[[','[').replace(']]',']')
	v8JT61OEjNwKtXmheW = v8JT61OEjNwKtXmheW.replace('((','(').replace('))',')')
	v8JT61OEjNwKtXmheW = v8JT61OEjNwKtXmheW.replace('<<','<').replace('>>','>')
	v8JT61OEjNwKtXmheW = v8JT61OEjNwKtXmheW.strip(hSXlxL9iB05c)
	return v8JT61OEjNwKtXmheW
def clAHbYKLe4T8MtvzPjixfn7O309R5q(rHhsTD3NpitG,uvEp2OVtGJmADgyMIjYHnw):
	TqS3ri9cgkt0WFIjPmBl86esZGoOQd = {}
	for YYToieWfxNMrX1GU4nLsD0JkHVZ in zhfR0KQZaI: TqS3ri9cgkt0WFIjPmBl86esZGoOQd[YYToieWfxNMrX1GU4nLsD0JkHVZ] = []
	DZ0htFdQal58pI49oWy = len(rHhsTD3NpitG)
	ptWghKU8swCPxlJ9GDb0ro1EI = str(DZ0htFdQal58pI49oWy)
	N97NarvCiOW5uUGITznKV4gsecqh = 0
	u7UtlVf8a5kDP9I = []
	for TlSnpKz8qAsiNybkj1Ir0X9U in rHhsTD3NpitG:
		if N97NarvCiOW5uUGITznKV4gsecqh%873==0:
			buQ2eMwxvTinjNrLVpUm6IH8fq(uvEp2OVtGJmADgyMIjYHnw,50+int(5*N97NarvCiOW5uUGITznKV4gsecqh/DZ0htFdQal58pI49oWy),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(N97NarvCiOW5uUGITznKV4gsecqh)+' / '+ptWghKU8swCPxlJ9GDb0ro1EI)
			if uvEp2OVtGJmADgyMIjYHnw.iscanceled():
				uvEp2OVtGJmADgyMIjYHnw.close()
				return None,None
		ra9Zzwkm0SJAHgRcLoB3,qjyki7XR1FW,v8JT61OEjNwKtXmheW,kOTdpYrPqu5A7UIcW0Ch,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX = TlSnpKz8qAsiNybkj1Ir0X9U['group'],TlSnpKz8qAsiNybkj1Ir0X9U['context'],TlSnpKz8qAsiNybkj1Ir0X9U['title'],TlSnpKz8qAsiNybkj1Ir0X9U['url'],TlSnpKz8qAsiNybkj1Ir0X9U['img']
		ZPJvufyUQbzLrO2gSM8dRlDnX,jPgtHLvJUkr,YYToieWfxNMrX1GU4nLsD0JkHVZ = TlSnpKz8qAsiNybkj1Ir0X9U['country'],TlSnpKz8qAsiNybkj1Ir0X9U['language'],TlSnpKz8qAsiNybkj1Ir0X9U['type']
		f07Pi1W5dmeuCgpDnaNq3xzvoOhZ = (ra9Zzwkm0SJAHgRcLoB3,qjyki7XR1FW,v8JT61OEjNwKtXmheW,kOTdpYrPqu5A7UIcW0Ch,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX)
		y30yDuOXwtzvYUVaLcMx4QZk9JhERH = False
		if 'LIVE' in YYToieWfxNMrX1GU4nLsD0JkHVZ:
			if 'UNKNOWN' in YYToieWfxNMrX1GU4nLsD0JkHVZ: TqS3ri9cgkt0WFIjPmBl86esZGoOQd['LIVE_UNKNOWN_GROUPED'].append(f07Pi1W5dmeuCgpDnaNq3xzvoOhZ)
			elif 'LIVE' in YYToieWfxNMrX1GU4nLsD0JkHVZ: TqS3ri9cgkt0WFIjPmBl86esZGoOQd['LIVE_GROUPED'].append(f07Pi1W5dmeuCgpDnaNq3xzvoOhZ)
			else: y30yDuOXwtzvYUVaLcMx4QZk9JhERH = True
			TqS3ri9cgkt0WFIjPmBl86esZGoOQd['LIVE_ORIGINAL_GROUPED'].append(f07Pi1W5dmeuCgpDnaNq3xzvoOhZ)
		elif 'VOD' in YYToieWfxNMrX1GU4nLsD0JkHVZ:
			if 'UNKNOWN' in YYToieWfxNMrX1GU4nLsD0JkHVZ: TqS3ri9cgkt0WFIjPmBl86esZGoOQd['VOD_UNKNOWN_GROUPED'].append(f07Pi1W5dmeuCgpDnaNq3xzvoOhZ)
			elif 'MOVIES' in YYToieWfxNMrX1GU4nLsD0JkHVZ: TqS3ri9cgkt0WFIjPmBl86esZGoOQd['VOD_MOVIES_GROUPED'].append(f07Pi1W5dmeuCgpDnaNq3xzvoOhZ)
			elif 'SERIES' in YYToieWfxNMrX1GU4nLsD0JkHVZ: TqS3ri9cgkt0WFIjPmBl86esZGoOQd['VOD_SERIES_GROUPED'].append(f07Pi1W5dmeuCgpDnaNq3xzvoOhZ)
			else: y30yDuOXwtzvYUVaLcMx4QZk9JhERH = True
			TqS3ri9cgkt0WFIjPmBl86esZGoOQd['VOD_ORIGINAL_GROUPED'].append(f07Pi1W5dmeuCgpDnaNq3xzvoOhZ)
		else: y30yDuOXwtzvYUVaLcMx4QZk9JhERH = True
		if y30yDuOXwtzvYUVaLcMx4QZk9JhERH: u7UtlVf8a5kDP9I.append(TlSnpKz8qAsiNybkj1Ir0X9U)
		N97NarvCiOW5uUGITznKV4gsecqh += 1
	NwOBUuD4i2CvFn3VJPfZqRd = sorted(rHhsTD3NpitG,reverse=False,key=lambda RRDE0VLWY7CgkuoXlQ4jTwUM23SK: RRDE0VLWY7CgkuoXlQ4jTwUM23SK['title'].lower())
	del rHhsTD3NpitG
	ptWghKU8swCPxlJ9GDb0ro1EI = str(DZ0htFdQal58pI49oWy)
	N97NarvCiOW5uUGITznKV4gsecqh = 0
	for TlSnpKz8qAsiNybkj1Ir0X9U in NwOBUuD4i2CvFn3VJPfZqRd:
		N97NarvCiOW5uUGITznKV4gsecqh += 1
		if N97NarvCiOW5uUGITznKV4gsecqh%873==0:
			buQ2eMwxvTinjNrLVpUm6IH8fq(uvEp2OVtGJmADgyMIjYHnw,55+int(5*N97NarvCiOW5uUGITznKV4gsecqh/DZ0htFdQal58pI49oWy),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(N97NarvCiOW5uUGITznKV4gsecqh)+' / '+ptWghKU8swCPxlJ9GDb0ro1EI)
			if uvEp2OVtGJmADgyMIjYHnw.iscanceled():
				uvEp2OVtGJmADgyMIjYHnw.close()
				return None,None
		YYToieWfxNMrX1GU4nLsD0JkHVZ = TlSnpKz8qAsiNybkj1Ir0X9U['type']
		ra9Zzwkm0SJAHgRcLoB3,qjyki7XR1FW,v8JT61OEjNwKtXmheW,kOTdpYrPqu5A7UIcW0Ch,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX = TlSnpKz8qAsiNybkj1Ir0X9U['group'],TlSnpKz8qAsiNybkj1Ir0X9U['context'],TlSnpKz8qAsiNybkj1Ir0X9U['title'],TlSnpKz8qAsiNybkj1Ir0X9U['url'],TlSnpKz8qAsiNybkj1Ir0X9U['img']
		ZPJvufyUQbzLrO2gSM8dRlDnX,jPgtHLvJUkr = TlSnpKz8qAsiNybkj1Ir0X9U['country'],TlSnpKz8qAsiNybkj1Ir0X9U['language']
		lFz5Q0ydBhxciso1IJXSmHCprPWkEL = (ra9Zzwkm0SJAHgRcLoB3,qjyki7XR1FW+'_TIMESHIFT',v8JT61OEjNwKtXmheW,kOTdpYrPqu5A7UIcW0Ch,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX)
		f07Pi1W5dmeuCgpDnaNq3xzvoOhZ = (ra9Zzwkm0SJAHgRcLoB3,qjyki7XR1FW,v8JT61OEjNwKtXmheW,kOTdpYrPqu5A7UIcW0Ch,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX)
		PgCdc1AjRQWGp2saSmiO53vY = (ZPJvufyUQbzLrO2gSM8dRlDnX,qjyki7XR1FW,v8JT61OEjNwKtXmheW,kOTdpYrPqu5A7UIcW0Ch,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX)
		uu3biFxk7opEcfDz41SYNdRTQshyaG = (jPgtHLvJUkr,qjyki7XR1FW,v8JT61OEjNwKtXmheW,kOTdpYrPqu5A7UIcW0Ch,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX)
		if 'LIVE' in YYToieWfxNMrX1GU4nLsD0JkHVZ:
			if 'UNKNOWN' in YYToieWfxNMrX1GU4nLsD0JkHVZ: TqS3ri9cgkt0WFIjPmBl86esZGoOQd['LIVE_UNKNOWN_GROUPED_SORTED'].append(f07Pi1W5dmeuCgpDnaNq3xzvoOhZ)
			else: TqS3ri9cgkt0WFIjPmBl86esZGoOQd['LIVE_GROUPED_SORTED'].append(f07Pi1W5dmeuCgpDnaNq3xzvoOhZ)
			if 'EPG'		in YYToieWfxNMrX1GU4nLsD0JkHVZ: TqS3ri9cgkt0WFIjPmBl86esZGoOQd['LIVE_EPG_GROUPED_SORTED'].append(f07Pi1W5dmeuCgpDnaNq3xzvoOhZ)
			if 'ARCHIVED'	in YYToieWfxNMrX1GU4nLsD0JkHVZ: TqS3ri9cgkt0WFIjPmBl86esZGoOQd['LIVE_ARCHIVED_GROUPED_SORTED'].append(f07Pi1W5dmeuCgpDnaNq3xzvoOhZ)
			if 'ARCHIVED'	in YYToieWfxNMrX1GU4nLsD0JkHVZ: TqS3ri9cgkt0WFIjPmBl86esZGoOQd['LIVE_TIMESHIFT_GROUPED_SORTED'].append(lFz5Q0ydBhxciso1IJXSmHCprPWkEL)
			TqS3ri9cgkt0WFIjPmBl86esZGoOQd['LIVE_FROM_NAME_SORTED'].append(PgCdc1AjRQWGp2saSmiO53vY)
			TqS3ri9cgkt0WFIjPmBl86esZGoOQd['LIVE_FROM_GROUP_SORTED'].append(uu3biFxk7opEcfDz41SYNdRTQshyaG)
		elif 'VOD' in YYToieWfxNMrX1GU4nLsD0JkHVZ:
			if   'UNKNOWN'	in YYToieWfxNMrX1GU4nLsD0JkHVZ: TqS3ri9cgkt0WFIjPmBl86esZGoOQd['VOD_UNKNOWN_GROUPED_SORTED'].append(f07Pi1W5dmeuCgpDnaNq3xzvoOhZ)
			elif 'MOVIES'	in YYToieWfxNMrX1GU4nLsD0JkHVZ: TqS3ri9cgkt0WFIjPmBl86esZGoOQd['VOD_MOVIES_GROUPED_SORTED'].append(f07Pi1W5dmeuCgpDnaNq3xzvoOhZ)
			elif 'SERIES'	in YYToieWfxNMrX1GU4nLsD0JkHVZ: TqS3ri9cgkt0WFIjPmBl86esZGoOQd['VOD_SERIES_GROUPED_SORTED'].append(f07Pi1W5dmeuCgpDnaNq3xzvoOhZ)
			TqS3ri9cgkt0WFIjPmBl86esZGoOQd['VOD_FROM_NAME_SORTED'].append(PgCdc1AjRQWGp2saSmiO53vY)
			TqS3ri9cgkt0WFIjPmBl86esZGoOQd['VOD_FROM_GROUP_SORTED'].append(uu3biFxk7opEcfDz41SYNdRTQshyaG)
	return TqS3ri9cgkt0WFIjPmBl86esZGoOQd,u7UtlVf8a5kDP9I
def mmwJElVaL2dFpXegBcz6nWZKkh0T5Q(v8JT61OEjNwKtXmheW):
	if len(v8JT61OEjNwKtXmheW)<3: return v8JT61OEjNwKtXmheW,v8JT61OEjNwKtXmheW
	VzS02wPZBC615eOUgdha,fJ8HjYdKP9Rxrz7IhaN6pl2ZUv4t1b = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	oIh1g6pyYl8 = v8JT61OEjNwKtXmheW
	Pq4T03FfBxRXDotcCju = v8JT61OEjNwKtXmheW[:1]
	hUuHFdXzl5J0L1 = v8JT61OEjNwKtXmheW[1:]
	if   Pq4T03FfBxRXDotcCju=='(': fJ8HjYdKP9Rxrz7IhaN6pl2ZUv4t1b = ')'
	elif Pq4T03FfBxRXDotcCju=='[': fJ8HjYdKP9Rxrz7IhaN6pl2ZUv4t1b = ']'
	elif Pq4T03FfBxRXDotcCju=='<': fJ8HjYdKP9Rxrz7IhaN6pl2ZUv4t1b = '>'
	elif Pq4T03FfBxRXDotcCju=='|': fJ8HjYdKP9Rxrz7IhaN6pl2ZUv4t1b = '|'
	if fJ8HjYdKP9Rxrz7IhaN6pl2ZUv4t1b and (fJ8HjYdKP9Rxrz7IhaN6pl2ZUv4t1b in hUuHFdXzl5J0L1):
		yYZAXQKcjiPa1lWEtTG7ezRVf3,RR4w2k9QWZMiOecqXbmrUH5 = hUuHFdXzl5J0L1.split(fJ8HjYdKP9Rxrz7IhaN6pl2ZUv4t1b,1)
		VzS02wPZBC615eOUgdha = yYZAXQKcjiPa1lWEtTG7ezRVf3
		oIh1g6pyYl8 = Pq4T03FfBxRXDotcCju+yYZAXQKcjiPa1lWEtTG7ezRVf3+fJ8HjYdKP9Rxrz7IhaN6pl2ZUv4t1b+hSXlxL9iB05c+RR4w2k9QWZMiOecqXbmrUH5
	elif v8JT61OEjNwKtXmheW.count('|')>=2:
		yYZAXQKcjiPa1lWEtTG7ezRVf3,RR4w2k9QWZMiOecqXbmrUH5 = v8JT61OEjNwKtXmheW.split('|',1)
		VzS02wPZBC615eOUgdha = yYZAXQKcjiPa1lWEtTG7ezRVf3
		oIh1g6pyYl8 = yYZAXQKcjiPa1lWEtTG7ezRVf3+' |'+RR4w2k9QWZMiOecqXbmrUH5
	else:
		fJ8HjYdKP9Rxrz7IhaN6pl2ZUv4t1b = PAztbuyYo4Kvd.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',v8JT61OEjNwKtXmheW,PAztbuyYo4Kvd.DOTALL)
		if not fJ8HjYdKP9Rxrz7IhaN6pl2ZUv4t1b: fJ8HjYdKP9Rxrz7IhaN6pl2ZUv4t1b = PAztbuyYo4Kvd.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',v8JT61OEjNwKtXmheW,PAztbuyYo4Kvd.DOTALL)
		if not fJ8HjYdKP9Rxrz7IhaN6pl2ZUv4t1b: fJ8HjYdKP9Rxrz7IhaN6pl2ZUv4t1b = PAztbuyYo4Kvd.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',v8JT61OEjNwKtXmheW,PAztbuyYo4Kvd.DOTALL)
		if fJ8HjYdKP9Rxrz7IhaN6pl2ZUv4t1b:
			yYZAXQKcjiPa1lWEtTG7ezRVf3,RR4w2k9QWZMiOecqXbmrUH5 = v8JT61OEjNwKtXmheW.split(fJ8HjYdKP9Rxrz7IhaN6pl2ZUv4t1b[0],1)
			VzS02wPZBC615eOUgdha = yYZAXQKcjiPa1lWEtTG7ezRVf3
			oIh1g6pyYl8 = yYZAXQKcjiPa1lWEtTG7ezRVf3+hSXlxL9iB05c+fJ8HjYdKP9Rxrz7IhaN6pl2ZUv4t1b[0]+hSXlxL9iB05c+RR4w2k9QWZMiOecqXbmrUH5
	oIh1g6pyYl8 = oIh1g6pyYl8.replace(PwYGfc4gTjiyRlsHn1OE,hSXlxL9iB05c).replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c)
	VzS02wPZBC615eOUgdha = VzS02wPZBC615eOUgdha.replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c)
	if not VzS02wPZBC615eOUgdha: VzS02wPZBC615eOUgdha = '!!__UNKNOWN__!!'
	VzS02wPZBC615eOUgdha = VzS02wPZBC615eOUgdha.strip(hSXlxL9iB05c)
	oIh1g6pyYl8 = oIh1g6pyYl8.strip(hSXlxL9iB05c)
	return VzS02wPZBC615eOUgdha,oIh1g6pyYl8
def ir4Kqb5p3N76S1yeQFf9dElHYILBt(dkq07Y6WG5enK1QlOLEU8uAj49x):
	kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3 = {}
	VrzqC0iQeygP64pvdKMTIuUEWaBX19 = KQctJbXeEjDhplqknU3rzi.getSetting('av.iptv.useragent_'+dkq07Y6WG5enK1QlOLEU8uAj49x)
	if VrzqC0iQeygP64pvdKMTIuUEWaBX19: kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3['User-Agent'] = VrzqC0iQeygP64pvdKMTIuUEWaBX19
	TjKXRuIe3W = KQctJbXeEjDhplqknU3rzi.getSetting('av.iptv.referer_'+dkq07Y6WG5enK1QlOLEU8uAj49x)
	if TjKXRuIe3W: kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3['Referer'] = TjKXRuIe3W
	return kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3
def rK5HAhscvtzDE2gkj(dkq07Y6WG5enK1QlOLEU8uAj49x):
	global uvEp2OVtGJmADgyMIjYHnw,TqS3ri9cgkt0WFIjPmBl86esZGoOQd,A3WTSa2wRe5BbUFh,jj9yVT3umUKMeFkJ,xAVdlsmIDeGJf4Qui516UgY7,APChJW6GTDdK,Q2s8zdrjDYZIM53UGun7o4WFixVRy,xXl8zAitWC,blHwLf0puBn2Y1Z9d3FKsU4ERg
	n5RqEMBVZT0L2,YUzvpc6yTixLVqO24m5ldKwFb1,M8nVAHG7lPzpb64Kho,oKDEiS6bdRqkw1MFJ2ah,ZNwox8KRnW1mP = JywhLB0sPzqC94Hl(dkq07Y6WG5enK1QlOLEU8uAj49x)
	if not oKDEiS6bdRqkw1MFJ2ah: return
	kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3 = ir4Kqb5p3N76S1yeQFf9dElHYILBt(dkq07Y6WG5enK1QlOLEU8uAj49x)
	dQG457SnHylm1vL = bjyB5J1QuNaIXOx9qSwm4v0edDhg('center',nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'جلب ملفات ـIPTV جديدة قد تحتاج عدة دقائق . هل تريد أن تجلب الملفات الآن ؟')
	if dQG457SnHylm1vL!=1: return
	prw120syvAPaxlngVGDiz7BKjL = t7W5qnsUTdXJjMHm.replace('___','_'+dkq07Y6WG5enK1QlOLEU8uAj49x)
	if 1:
		aZXjJt1MRcdoWT0EUB5yhxLCG,X0S7wkdetPNTAs9MaH3,l1Im6cu8sCKWtSxZUEMjhpdfeV5gb = c3P0A8ltZuqo1OCXIy5(dkq07Y6WG5enK1QlOLEU8uAj49x,False)
		if not aZXjJt1MRcdoWT0EUB5yhxLCG:
			OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'فشل بسحب ملفات ـIPTV . أحتمال رابط ـIPTV غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـIPTV الموجودة بهذا البرنامج')
			if not YUzvpc6yTixLVqO24m5ldKwFb1: nhR0UxwS4yDiABj7V1G8la(ybrna7mLOFVDUtRseQ3Tkf2zXS,PN7XfUGhIx5wVApBjYtJnzCc(kNfc1ZX0HTKjpQImqiuy49g85G7UVa)+'   No IPTV URL found to download IPTV files')
			else: nhR0UxwS4yDiABj7V1G8la(ybrna7mLOFVDUtRseQ3Tkf2zXS,PN7XfUGhIx5wVApBjYtJnzCc(kNfc1ZX0HTKjpQImqiuy49g85G7UVa)+'   Failed to download IPTV files')
			return
		SLkAplH01xwzGDjT49CdRsPt = Ew2exk7boOIaX(YUzvpc6yTixLVqO24m5ldKwFb1,kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3,True)
		if not SLkAplH01xwzGDjT49CdRsPt: return
		open(prw120syvAPaxlngVGDiz7BKjL,'wb').write(SLkAplH01xwzGDjT49CdRsPt)
	else: SLkAplH01xwzGDjT49CdRsPt = open(prw120syvAPaxlngVGDiz7BKjL,'rb').read()
	if BsLJ7p5Av2Vm0SQeCO1o and SLkAplH01xwzGDjT49CdRsPt: SLkAplH01xwzGDjT49CdRsPt = SLkAplH01xwzGDjT49CdRsPt.decode(YWEQ3Cf8RevpD0m7NjF1)
	uvEp2OVtGJmADgyMIjYHnw = SHolYI1dP8g5ThqUAEt()
	uvEp2OVtGJmADgyMIjYHnw.create('جلب ملفات ـIPTV جديدة',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	buQ2eMwxvTinjNrLVpUm6IH8fq(uvEp2OVtGJmADgyMIjYHnw,15,'تنظيف الملف الرئيسي',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	SLkAplH01xwzGDjT49CdRsPt = SLkAplH01xwzGDjT49CdRsPt.replace('"tvg-','" tvg-')
	SLkAplH01xwzGDjT49CdRsPt = SLkAplH01xwzGDjT49CdRsPt.replace('َ',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('ً',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('ُ',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('ٌ',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	SLkAplH01xwzGDjT49CdRsPt = SLkAplH01xwzGDjT49CdRsPt.replace('ّ',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('ِ',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('ٍ',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('ْ',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	SLkAplH01xwzGDjT49CdRsPt = SLkAplH01xwzGDjT49CdRsPt.replace('group-title=','group=').replace('tvg-',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	YjBZT9oizvasK0dSer3xD4pfbIC,aagZ2YWnkUDOpcPr = [],[]
	buQ2eMwxvTinjNrLVpUm6IH8fq(uvEp2OVtGJmADgyMIjYHnw,20,'جلب الملفات الثانوية','الملف رقم:-','1 / 3')
	if uvEp2OVtGJmADgyMIjYHnw.iscanceled():
		uvEp2OVtGJmADgyMIjYHnw.close()
		return
	kOTdpYrPqu5A7UIcW0Ch = n5RqEMBVZT0L2+'&action=get_series_categories'
	yyt7YxPTa8WEfK2VcMrudgJSUhzNCG = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',kOTdpYrPqu5A7UIcW0Ch,nA5dhMRg6ENzsB0l1GwvH7aIr2,kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'IPTV-CREATE_STREAMS-1st')
	PB1feMy50JE6xjCv4XAHhFNd8I2R = yyt7YxPTa8WEfK2VcMrudgJSUhzNCG.content
	PB1feMy50JE6xjCv4XAHhFNd8I2R = jPgzFLH1niJpE2r(PB1feMy50JE6xjCv4XAHhFNd8I2R)
	wwXFzDZqIxkBYfdlC0ca29 = PAztbuyYo4Kvd.findall('category_name":"(.*?)"',PB1feMy50JE6xjCv4XAHhFNd8I2R,PAztbuyYo4Kvd.DOTALL)
	del PB1feMy50JE6xjCv4XAHhFNd8I2R
	for ra9Zzwkm0SJAHgRcLoB3 in wwXFzDZqIxkBYfdlC0ca29:
		ra9Zzwkm0SJAHgRcLoB3 = ra9Zzwkm0SJAHgRcLoB3.replace('\/','/')
		if cS2NYw4xulqJgvzkMF: ra9Zzwkm0SJAHgRcLoB3 = ra9Zzwkm0SJAHgRcLoB3.decode(YWEQ3Cf8RevpD0m7NjF1).encode(YWEQ3Cf8RevpD0m7NjF1)
		SLkAplH01xwzGDjT49CdRsPt = SLkAplH01xwzGDjT49CdRsPt.replace('group="'+ra9Zzwkm0SJAHgRcLoB3+'"','group="__SERIES__'+ra9Zzwkm0SJAHgRcLoB3+'"')
	del wwXFzDZqIxkBYfdlC0ca29
	buQ2eMwxvTinjNrLVpUm6IH8fq(uvEp2OVtGJmADgyMIjYHnw,25,'جلب الملفات الثانوية','الملف رقم:-','2 / 3')
	if uvEp2OVtGJmADgyMIjYHnw.iscanceled():
		uvEp2OVtGJmADgyMIjYHnw.close()
		return
	kOTdpYrPqu5A7UIcW0Ch = n5RqEMBVZT0L2+'&action=get_vod_categories'
	yyt7YxPTa8WEfK2VcMrudgJSUhzNCG = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',kOTdpYrPqu5A7UIcW0Ch,nA5dhMRg6ENzsB0l1GwvH7aIr2,kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'IPTV-CREATE_STREAMS-2nd')
	PB1feMy50JE6xjCv4XAHhFNd8I2R = yyt7YxPTa8WEfK2VcMrudgJSUhzNCG.content
	PB1feMy50JE6xjCv4XAHhFNd8I2R = jPgzFLH1niJpE2r(PB1feMy50JE6xjCv4XAHhFNd8I2R)
	Q5970tXTPKUGxHCf3RbVsu = PAztbuyYo4Kvd.findall('category_name":"(.*?)"',PB1feMy50JE6xjCv4XAHhFNd8I2R,PAztbuyYo4Kvd.DOTALL)
	del PB1feMy50JE6xjCv4XAHhFNd8I2R
	for ra9Zzwkm0SJAHgRcLoB3 in Q5970tXTPKUGxHCf3RbVsu:
		ra9Zzwkm0SJAHgRcLoB3 = ra9Zzwkm0SJAHgRcLoB3.replace('\/','/')
		if cS2NYw4xulqJgvzkMF: ra9Zzwkm0SJAHgRcLoB3 = ra9Zzwkm0SJAHgRcLoB3.decode(YWEQ3Cf8RevpD0m7NjF1).encode(YWEQ3Cf8RevpD0m7NjF1)
		SLkAplH01xwzGDjT49CdRsPt = SLkAplH01xwzGDjT49CdRsPt.replace('group="'+ra9Zzwkm0SJAHgRcLoB3+'"','group="__MOVIES__'+ra9Zzwkm0SJAHgRcLoB3+'"')
	del Q5970tXTPKUGxHCf3RbVsu
	buQ2eMwxvTinjNrLVpUm6IH8fq(uvEp2OVtGJmADgyMIjYHnw,30,'جلب الملفات الثانوية','الملف رقم:-','3 / 3')
	if uvEp2OVtGJmADgyMIjYHnw.iscanceled():
		uvEp2OVtGJmADgyMIjYHnw.close()
		return
	kOTdpYrPqu5A7UIcW0Ch = n5RqEMBVZT0L2+'&action=get_live_streams'
	yyt7YxPTa8WEfK2VcMrudgJSUhzNCG = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',kOTdpYrPqu5A7UIcW0Ch,nA5dhMRg6ENzsB0l1GwvH7aIr2,kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'IPTV-CREATE_STREAMS-3rd')
	PB1feMy50JE6xjCv4XAHhFNd8I2R = yyt7YxPTa8WEfK2VcMrudgJSUhzNCG.content
	PB1feMy50JE6xjCv4XAHhFNd8I2R = jPgzFLH1niJpE2r(PB1feMy50JE6xjCv4XAHhFNd8I2R)
	Itf67sP1Q85J4VlGLCqxka9gMYdvSj = PAztbuyYo4Kvd.findall('"name":"(.*?)".*?"tv_archive":(.*?),',PB1feMy50JE6xjCv4XAHhFNd8I2R,PAztbuyYo4Kvd.DOTALL)
	for w8cPT5nhW2RUAFKDa,Wnxy4pMrGjUODhf in Itf67sP1Q85J4VlGLCqxka9gMYdvSj:
		if Wnxy4pMrGjUODhf=='1': YjBZT9oizvasK0dSer3xD4pfbIC.append(w8cPT5nhW2RUAFKDa)
	del Itf67sP1Q85J4VlGLCqxka9gMYdvSj
	lqDcXC6L24saOHt5ozxvhS = PAztbuyYo4Kvd.findall('"name":"(.*?)".*?"epg_channel_id":(.*?),',PB1feMy50JE6xjCv4XAHhFNd8I2R,PAztbuyYo4Kvd.DOTALL)
	del PB1feMy50JE6xjCv4XAHhFNd8I2R
	for w8cPT5nhW2RUAFKDa,av6198ORcbY3odDWn0qTNMeSymtB4J in lqDcXC6L24saOHt5ozxvhS:
		if av6198ORcbY3odDWn0qTNMeSymtB4J!='null': aagZ2YWnkUDOpcPr.append(w8cPT5nhW2RUAFKDa)
	del lqDcXC6L24saOHt5ozxvhS
	SLkAplH01xwzGDjT49CdRsPt = SLkAplH01xwzGDjT49CdRsPt.replace(sSBzjZdcbQraNx,CXtugbqhV3)
	iAcpSGqr7yTotbZBXkN4 = PAztbuyYo4Kvd.findall('NF:(.+?)'+'#'+'EXTI',SLkAplH01xwzGDjT49CdRsPt+'\n+'+'#'+'EXTINF:',PAztbuyYo4Kvd.DOTALL)
	if not iAcpSGqr7yTotbZBXkN4:
		nhR0UxwS4yDiABj7V1G8la(ybrna7mLOFVDUtRseQ3Tkf2zXS,PN7XfUGhIx5wVApBjYtJnzCc(kNfc1ZX0HTKjpQImqiuy49g85G7UVa)+'   Folder:'+dkq07Y6WG5enK1QlOLEU8uAj49x+'   No video links found in IPTV file')
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'رابط ـIPTV الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـIPTV غير صحيح'+CXtugbqhV3+lSWzOYmN08+'مجلد رقم '+dkq07Y6WG5enK1QlOLEU8uAj49x)
		uvEp2OVtGJmADgyMIjYHnw.close()
		return
	ObtklU0RSQNAyigV9hzeJqIT7pG = []
	for QQkCeBnHPEcsl6xrUTYSZ20Lo in iAcpSGqr7yTotbZBXkN4:
		i2RHeuTG9IEgjK4hbCs8D5m7O = QQkCeBnHPEcsl6xrUTYSZ20Lo.lower()
		if 'adult' in i2RHeuTG9IEgjK4hbCs8D5m7O: continue
		if 'xxx' in i2RHeuTG9IEgjK4hbCs8D5m7O: continue
		ObtklU0RSQNAyigV9hzeJqIT7pG.append(QQkCeBnHPEcsl6xrUTYSZ20Lo)
	iAcpSGqr7yTotbZBXkN4 = ObtklU0RSQNAyigV9hzeJqIT7pG
	del ObtklU0RSQNAyigV9hzeJqIT7pG
	LaAxti0ncZp4TMWdyHo6BSDJmz = 1024*1024
	C6VIX1aYxNo = 1+len(SLkAplH01xwzGDjT49CdRsPt)//LaAxti0ncZp4TMWdyHo6BSDJmz//10
	del SLkAplH01xwzGDjT49CdRsPt
	ykql7jQHoVFW = len(iAcpSGqr7yTotbZBXkN4)
	GmJuU2sC3yIcnKko = yfPE67m3z9KO0WYtLSqBGCTQX(iAcpSGqr7yTotbZBXkN4,C6VIX1aYxNo)
	del iAcpSGqr7yTotbZBXkN4
	for yFwUm7LgRGa4BhNK6V0SAXedCvMD in range(C6VIX1aYxNo):
		buQ2eMwxvTinjNrLVpUm6IH8fq(uvEp2OVtGJmADgyMIjYHnw,35+int(5*yFwUm7LgRGa4BhNK6V0SAXedCvMD/C6VIX1aYxNo),'تقطيع الملف الرئيسي','الجزء رقم:-',str(yFwUm7LgRGa4BhNK6V0SAXedCvMD+1)+' / '+str(C6VIX1aYxNo))
		if uvEp2OVtGJmADgyMIjYHnw.iscanceled():
			uvEp2OVtGJmADgyMIjYHnw.close()
			return
		x5dHaAGz9n = str(GmJuU2sC3yIcnKko[yFwUm7LgRGa4BhNK6V0SAXedCvMD])
		if BsLJ7p5Av2Vm0SQeCO1o: x5dHaAGz9n = x5dHaAGz9n.encode(YWEQ3Cf8RevpD0m7NjF1)
		open(prw120syvAPaxlngVGDiz7BKjL+'.00'+str(yFwUm7LgRGa4BhNK6V0SAXedCvMD),'wb').write(x5dHaAGz9n)
	del GmJuU2sC3yIcnKko,x5dHaAGz9n
	nzpQ7MWYG5h,rHhsTD3NpitG,N97NarvCiOW5uUGITznKV4gsecqh = [],[],0
	for yFwUm7LgRGa4BhNK6V0SAXedCvMD in range(C6VIX1aYxNo):
		if uvEp2OVtGJmADgyMIjYHnw.iscanceled():
			uvEp2OVtGJmADgyMIjYHnw.close()
			return
		x5dHaAGz9n = open(prw120syvAPaxlngVGDiz7BKjL+'.00'+str(yFwUm7LgRGa4BhNK6V0SAXedCvMD),'rb').read()
		h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(1)
		try: XoZRpFe7B6gnfA.remove(prw120syvAPaxlngVGDiz7BKjL+'.00'+str(yFwUm7LgRGa4BhNK6V0SAXedCvMD))
		except: pass
		if BsLJ7p5Av2Vm0SQeCO1o: x5dHaAGz9n = x5dHaAGz9n.decode(YWEQ3Cf8RevpD0m7NjF1)
		mFNvOV2PXsyad = BwGPDSQOlfUas2n3eIH0ycFRWZ('list',x5dHaAGz9n)
		del x5dHaAGz9n
		TX3ZNz2IOets9SW764QxP0Kaphg,N97NarvCiOW5uUGITznKV4gsecqh,u7UtlVf8a5kDP9I = FgmfBcVwT32z5erlj(mFNvOV2PXsyad,aagZ2YWnkUDOpcPr,YjBZT9oizvasK0dSer3xD4pfbIC,uvEp2OVtGJmADgyMIjYHnw,ykql7jQHoVFW,N97NarvCiOW5uUGITznKV4gsecqh,YUzvpc6yTixLVqO24m5ldKwFb1)
		if uvEp2OVtGJmADgyMIjYHnw.iscanceled():
			uvEp2OVtGJmADgyMIjYHnw.close()
			return
		if not TX3ZNz2IOets9SW764QxP0Kaphg:
			uvEp2OVtGJmADgyMIjYHnw.close()
			return
		rHhsTD3NpitG += TX3ZNz2IOets9SW764QxP0Kaphg
		nzpQ7MWYG5h += u7UtlVf8a5kDP9I
	del mFNvOV2PXsyad,TX3ZNz2IOets9SW764QxP0Kaphg
	TqS3ri9cgkt0WFIjPmBl86esZGoOQd,u7UtlVf8a5kDP9I = clAHbYKLe4T8MtvzPjixfn7O309R5q(rHhsTD3NpitG,uvEp2OVtGJmADgyMIjYHnw)
	if uvEp2OVtGJmADgyMIjYHnw.iscanceled():
		uvEp2OVtGJmADgyMIjYHnw.close()
		return
	nzpQ7MWYG5h += u7UtlVf8a5kDP9I
	del rHhsTD3NpitG,u7UtlVf8a5kDP9I
	jj9yVT3umUKMeFkJ,xAVdlsmIDeGJf4Qui516UgY7,APChJW6GTDdK,Q2s8zdrjDYZIM53UGun7o4WFixVRy,xXl8zAitWC = {},{},{},0,0
	ck1drLC8SQfxuB6MT = list(TqS3ri9cgkt0WFIjPmBl86esZGoOQd.keys())
	blHwLf0puBn2Y1Z9d3FKsU4ERg = len(ck1drLC8SQfxuB6MT)*3
	if 1:
		KMBYqvTk0J1HVowpaQn9LXU = {}
		for LS9oDJNxeiTrgny in ck1drLC8SQfxuB6MT:
			KMBYqvTk0J1HVowpaQn9LXU[LS9oDJNxeiTrgny] = QCxDqOcS9z586(daemon=S5MWhgtZ37Xw,target=M2Men0DybqZo9PXUGrdxRh64,args=(LS9oDJNxeiTrgny,))
			KMBYqvTk0J1HVowpaQn9LXU[LS9oDJNxeiTrgny].start()
		for LS9oDJNxeiTrgny in ck1drLC8SQfxuB6MT:
			KMBYqvTk0J1HVowpaQn9LXU[LS9oDJNxeiTrgny].join()
		if uvEp2OVtGJmADgyMIjYHnw.iscanceled():
			uvEp2OVtGJmADgyMIjYHnw.close()
			return
	else:
		for LS9oDJNxeiTrgny in ck1drLC8SQfxuB6MT:
			M2Men0DybqZo9PXUGrdxRh64(LS9oDJNxeiTrgny)
			if uvEp2OVtGJmADgyMIjYHnw.iscanceled():
				uvEp2OVtGJmADgyMIjYHnw.close()
				return
	BqXa1702HQUJ6xzfVLhD5NGSi8(dkq07Y6WG5enK1QlOLEU8uAj49x,False)
	ck1drLC8SQfxuB6MT = list(jj9yVT3umUKMeFkJ.keys())
	A3WTSa2wRe5BbUFh = 0
	if 1:
		KMBYqvTk0J1HVowpaQn9LXU = {}
		for LS9oDJNxeiTrgny in ck1drLC8SQfxuB6MT:
			KMBYqvTk0J1HVowpaQn9LXU[LS9oDJNxeiTrgny] = QCxDqOcS9z586(daemon=S5MWhgtZ37Xw,target=QA5PCRESqv8Gai46UcghKdoD,args=(dkq07Y6WG5enK1QlOLEU8uAj49x,LS9oDJNxeiTrgny))
			KMBYqvTk0J1HVowpaQn9LXU[LS9oDJNxeiTrgny].start()
		for LS9oDJNxeiTrgny in ck1drLC8SQfxuB6MT:
			KMBYqvTk0J1HVowpaQn9LXU[LS9oDJNxeiTrgny].join()
		if uvEp2OVtGJmADgyMIjYHnw.iscanceled():
			uvEp2OVtGJmADgyMIjYHnw.close()
			return
	else:
		for LS9oDJNxeiTrgny in ck1drLC8SQfxuB6MT:
			QA5PCRESqv8Gai46UcghKdoD(dkq07Y6WG5enK1QlOLEU8uAj49x,LS9oDJNxeiTrgny)
			if uvEp2OVtGJmADgyMIjYHnw.iscanceled():
				uvEp2OVtGJmADgyMIjYHnw.close()
				return
	yFwUm7LgRGa4BhNK6V0SAXedCvMD = 0
	GGE6PoQqcKZXIu5khF = len(nzpQ7MWYG5h)
	j5oVghLMlvCKDybz2FfkOPU3XWr0NE = kKmTYuDsdNl6WAqcj(dkq07Y6WG5enK1QlOLEU8uAj49x,'IGNORED')
	for opmNFG2M3YDjXV1fwrCaQAsk in nzpQ7MWYG5h:
		if yFwUm7LgRGa4BhNK6V0SAXedCvMD%27==0:
			buQ2eMwxvTinjNrLVpUm6IH8fq(uvEp2OVtGJmADgyMIjYHnw,95+int(5*yFwUm7LgRGa4BhNK6V0SAXedCvMD//GGE6PoQqcKZXIu5khF),'تخزين المهملة','الفيديو رقم:-',str(yFwUm7LgRGa4BhNK6V0SAXedCvMD)+' / '+str(GGE6PoQqcKZXIu5khF))
			if uvEp2OVtGJmADgyMIjYHnw.iscanceled():
				uvEp2OVtGJmADgyMIjYHnw.close()
				return
		WW5Rt1uxN7jBGAZ(j5oVghLMlvCKDybz2FfkOPU3XWr0NE,'IGNORED',str(opmNFG2M3YDjXV1fwrCaQAsk),nA5dhMRg6ENzsB0l1GwvH7aIr2,l7ltVNxrbPimpXJDh)
		yFwUm7LgRGa4BhNK6V0SAXedCvMD += 1
	WW5Rt1uxN7jBGAZ(j5oVghLMlvCKDybz2FfkOPU3XWr0NE,'IGNORED','__COUNT__',str(GGE6PoQqcKZXIu5khF),l7ltVNxrbPimpXJDh)
	WW5Rt1uxN7jBGAZ(j5oVghLMlvCKDybz2FfkOPU3XWr0NE,'DUMMY','__DUMMY__','1',l7ltVNxrbPimpXJDh)
	uvEp2OVtGJmADgyMIjYHnw.close()
	h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(1)
	WLbanDiOCGqAjJ64p3uSvwRmBxt2c9 = nF4t0SoVgzUijw(dkq07Y6WG5enK1QlOLEU8uAj49x,False)
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,lSWzOYmN08+'تم جلب ملفات ـIPTV جديدة'+NwROdSj3nsA+'\n\n'+WLbanDiOCGqAjJ64p3uSvwRmBxt2c9)
	Q8rLzHaSPp4bFfvZNDcMVywx3G(dkq07Y6WG5enK1QlOLEU8uAj49x)
	GlAym7JHLirouYThdfcjCtV(False)
	AA5FS4hUqeP9EsZCM(False)
	return
def M2Men0DybqZo9PXUGrdxRh64(LS9oDJNxeiTrgny):
	global uvEp2OVtGJmADgyMIjYHnw,TqS3ri9cgkt0WFIjPmBl86esZGoOQd,A3WTSa2wRe5BbUFh,jj9yVT3umUKMeFkJ,xAVdlsmIDeGJf4Qui516UgY7,APChJW6GTDdK,Q2s8zdrjDYZIM53UGun7o4WFixVRy,xXl8zAitWC,blHwLf0puBn2Y1Z9d3FKsU4ERg
	jj9yVT3umUKMeFkJ[LS9oDJNxeiTrgny] = {}
	pfKvAzlURm20GQ3LPDj,zKG95ZuCjDYvkLTVJb8nxIBpfWtlh = {},[]
	xEuRg4pCqZUNP1lDeajAOBchf3 = len(TqS3ri9cgkt0WFIjPmBl86esZGoOQd[LS9oDJNxeiTrgny])
	jj9yVT3umUKMeFkJ[LS9oDJNxeiTrgny]['__COUNT__'] = xEuRg4pCqZUNP1lDeajAOBchf3
	if xEuRg4pCqZUNP1lDeajAOBchf3>0:
		Ugh3d5EiFDbJ7TslaLrxB4cfj,ASziNCatbDhGT,l5xHTEtOrpR6zJWQS8,kepH0KChVNf9qJbQW3u2v1ZoE5,iOvTZU98zwj = zip(*TqS3ri9cgkt0WFIjPmBl86esZGoOQd[LS9oDJNxeiTrgny])
		del ASziNCatbDhGT,l5xHTEtOrpR6zJWQS8,kepH0KChVNf9qJbQW3u2v1ZoE5
		vni2lj6mLOJTE = list(set(Ugh3d5EiFDbJ7TslaLrxB4cfj))
		for ra9Zzwkm0SJAHgRcLoB3 in vni2lj6mLOJTE:
			pfKvAzlURm20GQ3LPDj[ra9Zzwkm0SJAHgRcLoB3] = nA5dhMRg6ENzsB0l1GwvH7aIr2
			jj9yVT3umUKMeFkJ[LS9oDJNxeiTrgny][ra9Zzwkm0SJAHgRcLoB3] = []
		buQ2eMwxvTinjNrLVpUm6IH8fq(uvEp2OVtGJmADgyMIjYHnw,60+int(15*xXl8zAitWC//blHwLf0puBn2Y1Z9d3FKsU4ERg),'تصنيع القوائم','الجزء رقم:-',str(xXl8zAitWC)+' / '+str(blHwLf0puBn2Y1Z9d3FKsU4ERg))
		if uvEp2OVtGJmADgyMIjYHnw.iscanceled(): return
		xXl8zAitWC += 1
		ppHLdjhZa3TkrVD6Bu7IOR2E8UCQ = len(vni2lj6mLOJTE)
		del vni2lj6mLOJTE
		zKG95ZuCjDYvkLTVJb8nxIBpfWtlh = list(set(zip(Ugh3d5EiFDbJ7TslaLrxB4cfj,iOvTZU98zwj)))
		del Ugh3d5EiFDbJ7TslaLrxB4cfj,iOvTZU98zwj
		for ra9Zzwkm0SJAHgRcLoB3,czMOJaKwoCnSPuNTd9bIH8pfLy72W5 in zKG95ZuCjDYvkLTVJb8nxIBpfWtlh:
			if not pfKvAzlURm20GQ3LPDj[ra9Zzwkm0SJAHgRcLoB3] and czMOJaKwoCnSPuNTd9bIH8pfLy72W5: pfKvAzlURm20GQ3LPDj[ra9Zzwkm0SJAHgRcLoB3] = czMOJaKwoCnSPuNTd9bIH8pfLy72W5
		buQ2eMwxvTinjNrLVpUm6IH8fq(uvEp2OVtGJmADgyMIjYHnw,60+int(15*xXl8zAitWC//blHwLf0puBn2Y1Z9d3FKsU4ERg),'تصنيع القوائم','الجزء رقم:-',str(xXl8zAitWC)+' / '+str(blHwLf0puBn2Y1Z9d3FKsU4ERg))
		if uvEp2OVtGJmADgyMIjYHnw.iscanceled(): return
		xXl8zAitWC += 1
		cRU4Eqtons2lVZQNF3I = list(pfKvAzlURm20GQ3LPDj.keys())
		km2q3hBACZ5aTuvnxfMpdKNOU = list(pfKvAzlURm20GQ3LPDj.values())
		del pfKvAzlURm20GQ3LPDj
		zKG95ZuCjDYvkLTVJb8nxIBpfWtlh = list(zip(cRU4Eqtons2lVZQNF3I,km2q3hBACZ5aTuvnxfMpdKNOU))
		del cRU4Eqtons2lVZQNF3I,km2q3hBACZ5aTuvnxfMpdKNOU
		zKG95ZuCjDYvkLTVJb8nxIBpfWtlh = sorted(zKG95ZuCjDYvkLTVJb8nxIBpfWtlh)
	else: xXl8zAitWC += 2
	jj9yVT3umUKMeFkJ[LS9oDJNxeiTrgny]['__GROUPS__'] = zKG95ZuCjDYvkLTVJb8nxIBpfWtlh
	del zKG95ZuCjDYvkLTVJb8nxIBpfWtlh
	for ra9Zzwkm0SJAHgRcLoB3,qjyki7XR1FW,v8JT61OEjNwKtXmheW,kOTdpYrPqu5A7UIcW0Ch,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX in TqS3ri9cgkt0WFIjPmBl86esZGoOQd[LS9oDJNxeiTrgny]:
		jj9yVT3umUKMeFkJ[LS9oDJNxeiTrgny][ra9Zzwkm0SJAHgRcLoB3].append((qjyki7XR1FW,v8JT61OEjNwKtXmheW,kOTdpYrPqu5A7UIcW0Ch,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX))
	buQ2eMwxvTinjNrLVpUm6IH8fq(uvEp2OVtGJmADgyMIjYHnw,60+int(15*xXl8zAitWC//blHwLf0puBn2Y1Z9d3FKsU4ERg),'تصنيع القوائم','الجزء رقم:-',str(xXl8zAitWC)+' / '+str(blHwLf0puBn2Y1Z9d3FKsU4ERg))
	if uvEp2OVtGJmADgyMIjYHnw.iscanceled(): return
	xXl8zAitWC += 1
	del TqS3ri9cgkt0WFIjPmBl86esZGoOQd[LS9oDJNxeiTrgny]
	APChJW6GTDdK[LS9oDJNxeiTrgny] = list(jj9yVT3umUKMeFkJ[LS9oDJNxeiTrgny].keys())
	xAVdlsmIDeGJf4Qui516UgY7[LS9oDJNxeiTrgny] = len(APChJW6GTDdK[LS9oDJNxeiTrgny])
	Q2s8zdrjDYZIM53UGun7o4WFixVRy += xAVdlsmIDeGJf4Qui516UgY7[LS9oDJNxeiTrgny]
	return
def QA5PCRESqv8Gai46UcghKdoD(dkq07Y6WG5enK1QlOLEU8uAj49x,LS9oDJNxeiTrgny):
	global uvEp2OVtGJmADgyMIjYHnw,TqS3ri9cgkt0WFIjPmBl86esZGoOQd,A3WTSa2wRe5BbUFh,jj9yVT3umUKMeFkJ,xAVdlsmIDeGJf4Qui516UgY7,APChJW6GTDdK,Q2s8zdrjDYZIM53UGun7o4WFixVRy,xXl8zAitWC,blHwLf0puBn2Y1Z9d3FKsU4ERg
	j5oVghLMlvCKDybz2FfkOPU3XWr0NE = kKmTYuDsdNl6WAqcj(dkq07Y6WG5enK1QlOLEU8uAj49x,LS9oDJNxeiTrgny)
	for N97NarvCiOW5uUGITznKV4gsecqh in range(1+xAVdlsmIDeGJf4Qui516UgY7[LS9oDJNxeiTrgny]//273):
		e8N5xZijpHsDdS3QlTf = []
		LQsJOvhzWmFytNuD = APChJW6GTDdK[LS9oDJNxeiTrgny][0:273]
		for ra9Zzwkm0SJAHgRcLoB3 in LQsJOvhzWmFytNuD:
			e8N5xZijpHsDdS3QlTf.append(jj9yVT3umUKMeFkJ[LS9oDJNxeiTrgny][ra9Zzwkm0SJAHgRcLoB3])
		WW5Rt1uxN7jBGAZ(j5oVghLMlvCKDybz2FfkOPU3XWr0NE,LS9oDJNxeiTrgny,LQsJOvhzWmFytNuD,e8N5xZijpHsDdS3QlTf,l7ltVNxrbPimpXJDh,True)
		A3WTSa2wRe5BbUFh += len(LQsJOvhzWmFytNuD)
		buQ2eMwxvTinjNrLVpUm6IH8fq(uvEp2OVtGJmADgyMIjYHnw,75+int(20*A3WTSa2wRe5BbUFh//Q2s8zdrjDYZIM53UGun7o4WFixVRy),'تخزين القوائم','القائمة رقم:-',str(A3WTSa2wRe5BbUFh)+' / '+str(Q2s8zdrjDYZIM53UGun7o4WFixVRy))
		if uvEp2OVtGJmADgyMIjYHnw.iscanceled(): return
		del APChJW6GTDdK[LS9oDJNxeiTrgny][0:273]
	del jj9yVT3umUKMeFkJ[LS9oDJNxeiTrgny],APChJW6GTDdK[LS9oDJNxeiTrgny],xAVdlsmIDeGJf4Qui516UgY7[LS9oDJNxeiTrgny]
	return
def nF4t0SoVgzUijw(dkq07Y6WG5enK1QlOLEU8uAj49x,ZZEzx0vdikFU6Lu5=True):
	if not jx8bBYMhnguRAHoWtXLFml(dkq07Y6WG5enK1QlOLEU8uAj49x,ZZEzx0vdikFU6Lu5): return
	z4WdDalHybmRnuB8hOS = OksCHeoL5SG
	UJ3dsb0RHiM = kKmTYuDsdNl6WAqcj(dkq07Y6WG5enK1QlOLEU8uAj49x,'LIVE_ORIGINAL_GROUPED')
	IObJRH4hi0EoZsP2BYu5gxSCMrfU = kKmTYuDsdNl6WAqcj(dkq07Y6WG5enK1QlOLEU8uAj49x,'VOD_ORIGINAL_GROUPED')
	GGE6PoQqcKZXIu5khF = CLAr1U2pRe3VhTP(UJ3dsb0RHiM,'int','IGNORED','__COUNT__')
	eDzVS4jikwoJcs7HWKIT2FqEQ = CLAr1U2pRe3VhTP(UJ3dsb0RHiM,'int','LIVE_ORIGINAL_GROUPED','__COUNT__')
	iMouwsxhTJ2 = CLAr1U2pRe3VhTP(IObJRH4hi0EoZsP2BYu5gxSCMrfU,'int','VOD_ORIGINAL_GROUPED','__COUNT__')
	s4z8v5PYuDiqRBxajQ2n9mOpwUdW = CLAr1U2pRe3VhTP(UJ3dsb0RHiM,'int','LIVE_GROUPED','__COUNT__')
	EPxD3d8Xu4VN = CLAr1U2pRe3VhTP(UJ3dsb0RHiM,'int','LIVE_UNKNOWN_GROUPED','__COUNT__')
	UaDXcHxAjnfdPmOF = CLAr1U2pRe3VhTP(UJ3dsb0RHiM,'int','VOD_MOVIES_GROUPED','__COUNT__')
	m4zNcKyaHuvX8p05h = CLAr1U2pRe3VhTP(IObJRH4hi0EoZsP2BYu5gxSCMrfU,'int','VOD_SERIES_GROUPED','__COUNT__')
	U9YZcesAHh7N1 = CLAr1U2pRe3VhTP(UJ3dsb0RHiM,'int','VOD_UNKNOWN_GROUPED','__COUNT__')
	APChJW6GTDdK = CLAr1U2pRe3VhTP(IObJRH4hi0EoZsP2BYu5gxSCMrfU,'list','VOD_SERIES_GROUPED','__GROUPS__')
	SFK5sbWGNMqO2TcfyBLY1PmlEho4V = []
	for ra9Zzwkm0SJAHgRcLoB3,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX in APChJW6GTDdK:
		ZXd0nlfmkt2qIVxwWMyu8vEe3 = ra9Zzwkm0SJAHgRcLoB3.split('__SERIES__')[1]
		SFK5sbWGNMqO2TcfyBLY1PmlEho4V.append(ZXd0nlfmkt2qIVxwWMyu8vEe3)
	Qam2E4MguxO = len(SFK5sbWGNMqO2TcfyBLY1PmlEho4V)
	v5nXoH1xdULBmpITwAb9Vy4tcs = int(UaDXcHxAjnfdPmOF)+int(m4zNcKyaHuvX8p05h)+int(U9YZcesAHh7N1)+int(EPxD3d8Xu4VN)+int(s4z8v5PYuDiqRBxajQ2n9mOpwUdW)
	WLbanDiOCGqAjJ64p3uSvwRmBxt2c9 = nA5dhMRg6ENzsB0l1GwvH7aIr2
	WLbanDiOCGqAjJ64p3uSvwRmBxt2c9 += 'قنوات: '+str(s4z8v5PYuDiqRBxajQ2n9mOpwUdW)
	WLbanDiOCGqAjJ64p3uSvwRmBxt2c9 += '   .   أفلام: '+str(UaDXcHxAjnfdPmOF)
	WLbanDiOCGqAjJ64p3uSvwRmBxt2c9 += '\nمسلسلات: '+str(Qam2E4MguxO)
	WLbanDiOCGqAjJ64p3uSvwRmBxt2c9 += '   .   حلقات: '+str(m4zNcKyaHuvX8p05h)
	WLbanDiOCGqAjJ64p3uSvwRmBxt2c9 += '\nقنوات مجهولة: '+str(EPxD3d8Xu4VN)
	WLbanDiOCGqAjJ64p3uSvwRmBxt2c9 += '   .   فيدوهات مجهولة: '+str(U9YZcesAHh7N1)
	WLbanDiOCGqAjJ64p3uSvwRmBxt2c9 += '\nمجموع القنوات: '+str(eDzVS4jikwoJcs7HWKIT2FqEQ)
	WLbanDiOCGqAjJ64p3uSvwRmBxt2c9 += '   .   مجموع الفيديوهات: '+str(iMouwsxhTJ2)
	WLbanDiOCGqAjJ64p3uSvwRmBxt2c9 += '\n\nمجموع المضافة: '+str(v5nXoH1xdULBmpITwAb9Vy4tcs)
	WLbanDiOCGqAjJ64p3uSvwRmBxt2c9 += '   .   مجموع المهملة: '+str(GGE6PoQqcKZXIu5khF)
	if ZZEzx0vdikFU6Lu5: OmxJV4UQyeFqdBSIC0('center',nA5dhMRg6ENzsB0l1GwvH7aIr2,z4WdDalHybmRnuB8hOS,WLbanDiOCGqAjJ64p3uSvwRmBxt2c9)
	NNdJR3g1nAi9XDkepxyr = WLbanDiOCGqAjJ64p3uSvwRmBxt2c9.replace('\n\n',CXtugbqhV3)
	nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,'.\tCounts of IPTV videos   Folder: '+dkq07Y6WG5enK1QlOLEU8uAj49x+CXtugbqhV3+NNdJR3g1nAi9XDkepxyr)
	return WLbanDiOCGqAjJ64p3uSvwRmBxt2c9
def BqXa1702HQUJ6xzfVLhD5NGSi8(dkq07Y6WG5enK1QlOLEU8uAj49x,ZZEzx0vdikFU6Lu5=True):
	if ZZEzx0vdikFU6Lu5:
		dQG457SnHylm1vL = bjyB5J1QuNaIXOx9qSwm4v0edDhg('center',nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'مسح ملفات ـIPTV','تستطيع في أي وقت الدخول إلى قائمة ـIPTV وجلب ملفات ـIPTV جديدة .. هل تريد الآن مسح الملفات القديمة المخزنة في البرنامج ؟!')
		if dQG457SnHylm1vL!=1: return
		Nyqsxg9c4TEHR10BzI2OV = t7W5qnsUTdXJjMHm.replace('___','_'+dkq07Y6WG5enK1QlOLEU8uAj49x)
		try: XoZRpFe7B6gnfA.remove(Nyqsxg9c4TEHR10BzI2OV)
		except: pass
	Nyqsxg9c4TEHR10BzI2OV = T9mAsfqv0P1rlyebgc47OdFYzUiG5J.replace('___','_'+dkq07Y6WG5enK1QlOLEU8uAj49x)
	try: XoZRpFe7B6gnfA.remove(Nyqsxg9c4TEHR10BzI2OV)
	except: pass
	Nyqsxg9c4TEHR10BzI2OV = dd6UyOGBsfSctVIv.replace('___','_'+dkq07Y6WG5enK1QlOLEU8uAj49x)
	try: XoZRpFe7B6gnfA.remove(Nyqsxg9c4TEHR10BzI2OV)
	except: pass
	aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,'SECTIONS_IPTV','SECTIONS_IPTV_'+dkq07Y6WG5enK1QlOLEU8uAj49x)
	aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,'SECTIONS_IPTV','SECTIONS_IPTV_ALL')
	GlAym7JHLirouYThdfcjCtV(False)
	Q8rLzHaSPp4bFfvZNDcMVywx3G(dkq07Y6WG5enK1QlOLEU8uAj49x)
	if ZZEzx0vdikFU6Lu5:
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'تم مسح جميع ملفات ـIPTV')
		AA5FS4hUqeP9EsZCM(False)
	return
def jx8bBYMhnguRAHoWtXLFml(dkq07Y6WG5enK1QlOLEU8uAj49x=nA5dhMRg6ENzsB0l1GwvH7aIr2,ZZEzx0vdikFU6Lu5=True):
	if dkq07Y6WG5enK1QlOLEU8uAj49x:
		j5oVghLMlvCKDybz2FfkOPU3XWr0NE = kKmTYuDsdNl6WAqcj(str(dkq07Y6WG5enK1QlOLEU8uAj49x),'DUMMY')
		NbaWkXeUGq26YhRISVouD = CLAr1U2pRe3VhTP(j5oVghLMlvCKDybz2FfkOPU3XWr0NE,'str','DUMMY','__DUMMY__')
		if NbaWkXeUGq26YhRISVouD: return True
	else:
		dkq07Y6WG5enK1QlOLEU8uAj49x = '1'
		for aYfNMm15XKB in range(1,EYcbkTrLd8MqHSXzxFGft+1):
			j5oVghLMlvCKDybz2FfkOPU3XWr0NE = kKmTYuDsdNl6WAqcj(str(aYfNMm15XKB),'DUMMY')
			NbaWkXeUGq26YhRISVouD = CLAr1U2pRe3VhTP(j5oVghLMlvCKDybz2FfkOPU3XWr0NE,'str','DUMMY','__DUMMY__')
			if NbaWkXeUGq26YhRISVouD: return True
	if ZZEzx0vdikFU6Lu5:
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'هذا الجزء من البرنامج يحتاج اشتراك IPTV مدفوع من شركة IPTV .. ونوع الرابط المطلوب هو  m3u .. وهذا مثال لتوضيح شكل الرابط المطلوب في هذا البرنامج  '+bbTCMJwEx8nhN4X+' \n\nhttp://xyz.xyz/get.php?username=xyz&password=xyz&type=m3u_plus '+NwROdSj3nsA)
		z4WdDalHybmRnuB8hOS = 'إضافة وتغيير رابط '+c0Qs8Db7KdxGzt[1]+' (مجلد '+c0Qs8Db7KdxGzt[int(dkq07Y6WG5enK1QlOLEU8uAj49x)]+')'
		dQG457SnHylm1vL = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,z4WdDalHybmRnuB8hOS,'لإضافة رابط IPTV .. أولا أفتح قائمة IPTV .. وثانيا أنقر على إضافة رابط أو اشتراك ـIPTV .. وثالثا أنقر على جلب ملفات ـIPTV \n\n هل تريد إضافة أو تغيير رابط IPTV الآن ؟!')
		if dQG457SnHylm1vL==1: WWH0ca5PyIkL2C(dkq07Y6WG5enK1QlOLEU8uAj49x)
	return False
def BZOyPrlKzJmRGD(wzfHl9Y5OyAFjVM3tTPcIQZC0,dkq07Y6WG5enK1QlOLEU8uAj49x=nA5dhMRg6ENzsB0l1GwvH7aIr2,LS9oDJNxeiTrgny=nA5dhMRg6ENzsB0l1GwvH7aIr2,L9Chqa1OZp0dfJ3s=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if not L9Chqa1OZp0dfJ3s: L9Chqa1OZp0dfJ3s = '1'
	BBFVq0I5Ecsl,QKHC8Vlk21Up,ZZEzx0vdikFU6Lu5 = Vit4q8MczeLRHnJQCyXAam(wzfHl9Y5OyAFjVM3tTPcIQZC0)
	if not jx8bBYMhnguRAHoWtXLFml(dkq07Y6WG5enK1QlOLEU8uAj49x,ZZEzx0vdikFU6Lu5): return
	if not BBFVq0I5Ecsl:
		BBFVq0I5Ecsl = FaUBpzTGxtS7hZyl()
		if not BBFVq0I5Ecsl: return
	utRL4X5HwyZn3aGJ7EhF6gD = [nA5dhMRg6ENzsB0l1GwvH7aIr2,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not LS9oDJNxeiTrgny:
		if not ZZEzx0vdikFU6Lu5:
			if   '_IPTV-LIVE_' in QKHC8Vlk21Up: LS9oDJNxeiTrgny = utRL4X5HwyZn3aGJ7EhF6gD[1]
			elif '_IPTV-MOVIES' in QKHC8Vlk21Up: LS9oDJNxeiTrgny = utRL4X5HwyZn3aGJ7EhF6gD[2]
			elif '_IPTV-SERIES' in QKHC8Vlk21Up: LS9oDJNxeiTrgny = utRL4X5HwyZn3aGJ7EhF6gD[3]
			else: LS9oDJNxeiTrgny = utRL4X5HwyZn3aGJ7EhF6gD[0]
		else:
			bU1zf9H8WkG2YRp7 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			uDP7kA6UcClgd2Gza0VO = ccAMwn7hflDev8Kd3aqP('أختر البحث المناسب', bU1zf9H8WkG2YRp7)
			if uDP7kA6UcClgd2Gza0VO==-1: return
			LS9oDJNxeiTrgny = utRL4X5HwyZn3aGJ7EhF6gD[uDP7kA6UcClgd2Gza0VO]
	BBFVq0I5Ecsl = BBFVq0I5Ecsl+'_NODIALOGS_'
	if dkq07Y6WG5enK1QlOLEU8uAj49x: v5MgwIrObe2QLt7GqpDuSZWd1PX9(BBFVq0I5Ecsl,dkq07Y6WG5enK1QlOLEU8uAj49x,LS9oDJNxeiTrgny,L9Chqa1OZp0dfJ3s)
	else:
		for dkq07Y6WG5enK1QlOLEU8uAj49x in range(1,EYcbkTrLd8MqHSXzxFGft+1):
			v5MgwIrObe2QLt7GqpDuSZWd1PX9(BBFVq0I5Ecsl,str(dkq07Y6WG5enK1QlOLEU8uAj49x),LS9oDJNxeiTrgny,L9Chqa1OZp0dfJ3s)
		Nzp9Fq5cTr.menuItemsLIST[:] = sorted(Nzp9Fq5cTr.menuItemsLIST,reverse=False,key=lambda RRDE0VLWY7CgkuoXlQ4jTwUM23SK: RRDE0VLWY7CgkuoXlQ4jTwUM23SK[1].lower())
	return
def v5MgwIrObe2QLt7GqpDuSZWd1PX9(wzfHl9Y5OyAFjVM3tTPcIQZC0,dkq07Y6WG5enK1QlOLEU8uAj49x,LS9oDJNxeiTrgny=nA5dhMRg6ENzsB0l1GwvH7aIr2,L9Chqa1OZp0dfJ3s=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if not L9Chqa1OZp0dfJ3s: L9Chqa1OZp0dfJ3s = '1'
	BBFVq0I5Ecsl,QKHC8Vlk21Up,ZZEzx0vdikFU6Lu5 = Vit4q8MczeLRHnJQCyXAam(wzfHl9Y5OyAFjVM3tTPcIQZC0)
	if not dkq07Y6WG5enK1QlOLEU8uAj49x: return
	if not jx8bBYMhnguRAHoWtXLFml(dkq07Y6WG5enK1QlOLEU8uAj49x,ZZEzx0vdikFU6Lu5): return
	if not BBFVq0I5Ecsl:
		BBFVq0I5Ecsl = FaUBpzTGxtS7hZyl()
		if not BBFVq0I5Ecsl: return
	utRL4X5HwyZn3aGJ7EhF6gD = [nA5dhMRg6ENzsB0l1GwvH7aIr2,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not LS9oDJNxeiTrgny:
		if not ZZEzx0vdikFU6Lu5:
			if   '_IPTV-LIVE_' in QKHC8Vlk21Up: LS9oDJNxeiTrgny = utRL4X5HwyZn3aGJ7EhF6gD[1]
			elif '_IPTV-MOVIES' in QKHC8Vlk21Up: LS9oDJNxeiTrgny = utRL4X5HwyZn3aGJ7EhF6gD[2]
			elif '_IPTV-SERIES' in QKHC8Vlk21Up: LS9oDJNxeiTrgny = utRL4X5HwyZn3aGJ7EhF6gD[3]
			else: LS9oDJNxeiTrgny = utRL4X5HwyZn3aGJ7EhF6gD[0]
		else:
			bU1zf9H8WkG2YRp7 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			uDP7kA6UcClgd2Gza0VO = ccAMwn7hflDev8Kd3aqP('أختر البحث المناسب', bU1zf9H8WkG2YRp7)
			if uDP7kA6UcClgd2Gza0VO==-1: return
			LS9oDJNxeiTrgny = utRL4X5HwyZn3aGJ7EhF6gD[uDP7kA6UcClgd2Gza0VO]
	E6DtxcFleVkToWJb7MGwfuH4niB5j = BBFVq0I5Ecsl.lower()
	j5oVghLMlvCKDybz2FfkOPU3XWr0NE = kKmTYuDsdNl6WAqcj(dkq07Y6WG5enK1QlOLEU8uAj49x,'SEARCH')
	ZLzmkuhti3vloIPnB9qcUya = CLAr1U2pRe3VhTP(j5oVghLMlvCKDybz2FfkOPU3XWr0NE,'list','SEARCH',(LS9oDJNxeiTrgny,E6DtxcFleVkToWJb7MGwfuH4niB5j))
	if not ZLzmkuhti3vloIPnB9qcUya:
		FFwiE9u6zBYD,Cvqca8s7XQB9d1MgJ6Ln240U = [],[]
		if not LS9oDJNxeiTrgny: oyWJYD5tqHCbvP0EsZeiRcQ9N = [1,2,3,4,5]
		else: oyWJYD5tqHCbvP0EsZeiRcQ9N = [utRL4X5HwyZn3aGJ7EhF6gD.index(LS9oDJNxeiTrgny)]
		for yFwUm7LgRGa4BhNK6V0SAXedCvMD in oyWJYD5tqHCbvP0EsZeiRcQ9N:
			j5oVghLMlvCKDybz2FfkOPU3XWr0NE = kKmTYuDsdNl6WAqcj(dkq07Y6WG5enK1QlOLEU8uAj49x,utRL4X5HwyZn3aGJ7EhF6gD[yFwUm7LgRGa4BhNK6V0SAXedCvMD])
			if yFwUm7LgRGa4BhNK6V0SAXedCvMD!=3:
				TX3ZNz2IOets9SW764QxP0Kaphg = CLAr1U2pRe3VhTP(j5oVghLMlvCKDybz2FfkOPU3XWr0NE,'dict',utRL4X5HwyZn3aGJ7EhF6gD[yFwUm7LgRGa4BhNK6V0SAXedCvMD])
				del TX3ZNz2IOets9SW764QxP0Kaphg['__COUNT__']
				del TX3ZNz2IOets9SW764QxP0Kaphg['__GROUPS__']
				del TX3ZNz2IOets9SW764QxP0Kaphg['__SEQUENCED_COLUMNS__']
				APChJW6GTDdK = list(TX3ZNz2IOets9SW764QxP0Kaphg.keys())
				for ra9Zzwkm0SJAHgRcLoB3 in APChJW6GTDdK:
					for qjyki7XR1FW,v8JT61OEjNwKtXmheW,kOTdpYrPqu5A7UIcW0Ch,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX in TX3ZNz2IOets9SW764QxP0Kaphg[ra9Zzwkm0SJAHgRcLoB3]:
						if E6DtxcFleVkToWJb7MGwfuH4niB5j in v8JT61OEjNwKtXmheW.lower(): Cvqca8s7XQB9d1MgJ6Ln240U.append((v8JT61OEjNwKtXmheW,kOTdpYrPqu5A7UIcW0Ch,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX))
					del TX3ZNz2IOets9SW764QxP0Kaphg[ra9Zzwkm0SJAHgRcLoB3]
				del TX3ZNz2IOets9SW764QxP0Kaphg
			else: APChJW6GTDdK = CLAr1U2pRe3VhTP(j5oVghLMlvCKDybz2FfkOPU3XWr0NE,'list',utRL4X5HwyZn3aGJ7EhF6gD[yFwUm7LgRGa4BhNK6V0SAXedCvMD],'__GROUPS__')
			for ra9Zzwkm0SJAHgRcLoB3 in APChJW6GTDdK:
				try: ra9Zzwkm0SJAHgRcLoB3,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX = ra9Zzwkm0SJAHgRcLoB3
				except: otyuV4JPfh5SiaKF9pbDY8AqkvlZHX = nA5dhMRg6ENzsB0l1GwvH7aIr2
				if E6DtxcFleVkToWJb7MGwfuH4niB5j in ra9Zzwkm0SJAHgRcLoB3.lower():
					if yFwUm7LgRGa4BhNK6V0SAXedCvMD!=3: WEgeBj94kOATDfHLmnoyZGP83 = ra9Zzwkm0SJAHgRcLoB3
					else:
						SS3g4lyHwG,ze9UdbWpsEK7PrFJt0gjfkSHvL = ra9Zzwkm0SJAHgRcLoB3.split('__SERIES__')
						if E6DtxcFleVkToWJb7MGwfuH4niB5j in SS3g4lyHwG.lower(): WEgeBj94kOATDfHLmnoyZGP83 = SS3g4lyHwG
						else: WEgeBj94kOATDfHLmnoyZGP83 = ze9UdbWpsEK7PrFJt0gjfkSHvL
					FFwiE9u6zBYD.append((ra9Zzwkm0SJAHgRcLoB3,WEgeBj94kOATDfHLmnoyZGP83,utRL4X5HwyZn3aGJ7EhF6gD[yFwUm7LgRGa4BhNK6V0SAXedCvMD],otyuV4JPfh5SiaKF9pbDY8AqkvlZHX))
			del APChJW6GTDdK
		FFwiE9u6zBYD = set(FFwiE9u6zBYD)
		Cvqca8s7XQB9d1MgJ6Ln240U = set(Cvqca8s7XQB9d1MgJ6Ln240U)
		FFwiE9u6zBYD = sorted(FFwiE9u6zBYD,reverse=False,key=lambda RRDE0VLWY7CgkuoXlQ4jTwUM23SK: RRDE0VLWY7CgkuoXlQ4jTwUM23SK[1])
		Cvqca8s7XQB9d1MgJ6Ln240U = sorted(Cvqca8s7XQB9d1MgJ6Ln240U,reverse=False,key=lambda RRDE0VLWY7CgkuoXlQ4jTwUM23SK: RRDE0VLWY7CgkuoXlQ4jTwUM23SK[0])
		WW5Rt1uxN7jBGAZ(j5oVghLMlvCKDybz2FfkOPU3XWr0NE,'SEARCH',(LS9oDJNxeiTrgny,E6DtxcFleVkToWJb7MGwfuH4niB5j),(FFwiE9u6zBYD,Cvqca8s7XQB9d1MgJ6Ln240U),l7ltVNxrbPimpXJDh)
	else: FFwiE9u6zBYD,Cvqca8s7XQB9d1MgJ6Ln240U = ZLzmkuhti3vloIPnB9qcUya
	APChJW6GTDdK = len(FFwiE9u6zBYD)
	q2Y7IHyMif8xwBcCRmKnV = len(Cvqca8s7XQB9d1MgJ6Ln240U)
	QbuYlX5ctHaGp42jNef8 = int(L9Chqa1OZp0dfJ3s)
	tIX1zj50Y2xUZplovqcru9TRH4h = max(0,(QbuYlX5ctHaGp42jNef8-1)*100)
	j9RsKku7mDNhv1JZSX5WpMarnYOLb = max(0,QbuYlX5ctHaGp42jNef8*100)
	cXoBCjnlupPKJFTIbtr4hi = max(0,tIX1zj50Y2xUZplovqcru9TRH4h-APChJW6GTDdK)
	oorRcgmOd9PqtlSjLu2AWz = max(0,j9RsKku7mDNhv1JZSX5WpMarnYOLb-APChJW6GTDdK)
	for ra9Zzwkm0SJAHgRcLoB3,WEgeBj94kOATDfHLmnoyZGP83,IhyVvN3icH8s4,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX in FFwiE9u6zBYD[tIX1zj50Y2xUZplovqcru9TRH4h:j9RsKku7mDNhv1JZSX5WpMarnYOLb]:
		TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+WEgeBj94kOATDfHLmnoyZGP83,IhyVvN3icH8s4,234,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX,'1',ra9Zzwkm0SJAHgRcLoB3,nA5dhMRg6ENzsB0l1GwvH7aIr2,{'folder':dkq07Y6WG5enK1QlOLEU8uAj49x})
	del FFwiE9u6zBYD
	for v8JT61OEjNwKtXmheW,kOTdpYrPqu5A7UIcW0Ch,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX in Cvqca8s7XQB9d1MgJ6Ln240U[cXoBCjnlupPKJFTIbtr4hi:oorRcgmOd9PqtlSjLu2AWz]:
		V4AmHY5dhkN8vXLRc2 = EbwS0djxcz(kOTdpYrPqu5A7UIcW0Ch)
		WTavfhd7QJDABwpIVrZqHL = 'live'
		if '.mkv' in V4AmHY5dhkN8vXLRc2 or 'VOD' in LS9oDJNxeiTrgny: WTavfhd7QJDABwpIVrZqHL = 'video'
		TBt8bUDo9WhL(WTavfhd7QJDABwpIVrZqHL,r1r9MU8jSNR2csPJnauFeWzvOGhl5q+v8JT61OEjNwKtXmheW,kOTdpYrPqu5A7UIcW0Ch,235,otyuV4JPfh5SiaKF9pbDY8AqkvlZHX,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,{'folder':dkq07Y6WG5enK1QlOLEU8uAj49x})
	del Cvqca8s7XQB9d1MgJ6Ln240U
	xxVd5HftDBAeLbmZTKkz(dkq07Y6WG5enK1QlOLEU8uAj49x,L9Chqa1OZp0dfJ3s,LS9oDJNxeiTrgny,239,APChJW6GTDdK+q2Y7IHyMif8xwBcCRmKnV,BBFVq0I5Ecsl+'_NODIALOGS_')
	return
def xxVd5HftDBAeLbmZTKkz(dkq07Y6WG5enK1QlOLEU8uAj49x,L9Chqa1OZp0dfJ3s,LS9oDJNxeiTrgny,knBV0UPuCNdpIsAFH3coRKjh2lb,v5nXoH1xdULBmpITwAb9Vy4tcs,OOrjZaTIVXQ2Sp0ozhc):
	if L9Chqa1OZp0dfJ3s!='1': TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'صفحة '+str(1),LS9oDJNxeiTrgny,knBV0UPuCNdpIsAFH3coRKjh2lb,nA5dhMRg6ENzsB0l1GwvH7aIr2,str(1),OOrjZaTIVXQ2Sp0ozhc,nA5dhMRg6ENzsB0l1GwvH7aIr2,{'folder':dkq07Y6WG5enK1QlOLEU8uAj49x})
	if not v5nXoH1xdULBmpITwAb9Vy4tcs: v5nXoH1xdULBmpITwAb9Vy4tcs = 0
	W6oVLI1tlmdfQw78BjOXaAF = int(v5nXoH1xdULBmpITwAb9Vy4tcs/100)+1
	for QbuYlX5ctHaGp42jNef8 in range(2,W6oVLI1tlmdfQw78BjOXaAF):
		WWIjehXUlyTkMnmwbL9JS8ORYs4570 = (QbuYlX5ctHaGp42jNef8%10==0 or int(L9Chqa1OZp0dfJ3s)-4<QbuYlX5ctHaGp42jNef8<int(L9Chqa1OZp0dfJ3s)+4)
		ExuFiMZ5XYRo9jVvO1W = (WWIjehXUlyTkMnmwbL9JS8ORYs4570 and int(L9Chqa1OZp0dfJ3s)-40<QbuYlX5ctHaGp42jNef8<int(L9Chqa1OZp0dfJ3s)+40)
		if str(QbuYlX5ctHaGp42jNef8)!=L9Chqa1OZp0dfJ3s and (QbuYlX5ctHaGp42jNef8%100==0 or ExuFiMZ5XYRo9jVvO1W):
			TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'صفحة '+str(QbuYlX5ctHaGp42jNef8),LS9oDJNxeiTrgny,knBV0UPuCNdpIsAFH3coRKjh2lb,nA5dhMRg6ENzsB0l1GwvH7aIr2,str(QbuYlX5ctHaGp42jNef8),OOrjZaTIVXQ2Sp0ozhc,nA5dhMRg6ENzsB0l1GwvH7aIr2,{'folder':dkq07Y6WG5enK1QlOLEU8uAj49x})
	if str(W6oVLI1tlmdfQw78BjOXaAF)!=L9Chqa1OZp0dfJ3s: TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+'أخر صفحة '+str(W6oVLI1tlmdfQw78BjOXaAF),LS9oDJNxeiTrgny,knBV0UPuCNdpIsAFH3coRKjh2lb,nA5dhMRg6ENzsB0l1GwvH7aIr2,str(W6oVLI1tlmdfQw78BjOXaAF),OOrjZaTIVXQ2Sp0ozhc,nA5dhMRg6ENzsB0l1GwvH7aIr2,{'folder':dkq07Y6WG5enK1QlOLEU8uAj49x})
	return
def kKmTYuDsdNl6WAqcj(dkq07Y6WG5enK1QlOLEU8uAj49x,LS9oDJNxeiTrgny):
	if 'SERIES' in LS9oDJNxeiTrgny or 'VOD_ORIGINAL' in LS9oDJNxeiTrgny: j5oVghLMlvCKDybz2FfkOPU3XWr0NE = dd6UyOGBsfSctVIv
	else: j5oVghLMlvCKDybz2FfkOPU3XWr0NE = T9mAsfqv0P1rlyebgc47OdFYzUiG5J
	j5oVghLMlvCKDybz2FfkOPU3XWr0NE = j5oVghLMlvCKDybz2FfkOPU3XWr0NE.replace('___','_'+dkq07Y6WG5enK1QlOLEU8uAj49x)
	return j5oVghLMlvCKDybz2FfkOPU3XWr0NE
def oiS9MplKsVnfvNdyHY(dkq07Y6WG5enK1QlOLEU8uAj49x,LS9oDJNxeiTrgny,IZnRxG8uSPKzimk):
	n5RqEMBVZT0L2,YUzvpc6yTixLVqO24m5ldKwFb1,M8nVAHG7lPzpb64Kho,oKDEiS6bdRqkw1MFJ2ah,ZNwox8KRnW1mP = JywhLB0sPzqC94Hl(dkq07Y6WG5enK1QlOLEU8uAj49x)
	if not oKDEiS6bdRqkw1MFJ2ah: return
	kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3 = ir4Kqb5p3N76S1yeQFf9dElHYILBt(dkq07Y6WG5enK1QlOLEU8uAj49x)
	if   LS9oDJNxeiTrgny=='XTREAM_LIVE_GROUPS': kOTdpYrPqu5A7UIcW0Ch = n5RqEMBVZT0L2+'&action=get_live_categories'
	elif LS9oDJNxeiTrgny=='XTREAM_VOD_GROUPS': kOTdpYrPqu5A7UIcW0Ch = n5RqEMBVZT0L2+'&action=get_vod_categories'
	elif LS9oDJNxeiTrgny=='XTREAM_SERIES_GROUPS': kOTdpYrPqu5A7UIcW0Ch = n5RqEMBVZT0L2+'&action=get_series_categories'
	elif LS9oDJNxeiTrgny=='XTREAM_LIVE_ITEMS': kOTdpYrPqu5A7UIcW0Ch = n5RqEMBVZT0L2+'&action=get_live_streams&category_id='+IZnRxG8uSPKzimk
	elif LS9oDJNxeiTrgny=='XTREAM_VOD_ITEMS': kOTdpYrPqu5A7UIcW0Ch = n5RqEMBVZT0L2+'&action=get_vod_streams&category_id='+IZnRxG8uSPKzimk
	elif LS9oDJNxeiTrgny=='XTREAM_SERIES_ITEMS': kOTdpYrPqu5A7UIcW0Ch = n5RqEMBVZT0L2+'&action=get_series&category_id='+IZnRxG8uSPKzimk
	elif LS9oDJNxeiTrgny=='XTREAM_EPISODES': kOTdpYrPqu5A7UIcW0Ch = n5RqEMBVZT0L2+'&action=get_series_info&series_id='+IZnRxG8uSPKzimk
	else: return
	yyt7YxPTa8WEfK2VcMrudgJSUhzNCG = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',kOTdpYrPqu5A7UIcW0Ch,nA5dhMRg6ENzsB0l1GwvH7aIr2,kKfXcLhNF5ZWJGVHvIbq9pT4r1ztx3,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'IPTV-XTREAM_MENUS-1st')
	PB1feMy50JE6xjCv4XAHhFNd8I2R = yyt7YxPTa8WEfK2VcMrudgJSUhzNCG.content
	if cS2NYw4xulqJgvzkMF: PB1feMy50JE6xjCv4XAHhFNd8I2R = PB1feMy50JE6xjCv4XAHhFNd8I2R.decode(YWEQ3Cf8RevpD0m7NjF1).encode(YWEQ3Cf8RevpD0m7NjF1)
	C0YrLWOMgX4 = BwGPDSQOlfUas2n3eIH0ycFRWZ('list',PB1feMy50JE6xjCv4XAHhFNd8I2R)
	if 'GROUPS' in LS9oDJNxeiTrgny:
		LS9oDJNxeiTrgny = LS9oDJNxeiTrgny.replace('_GROUPS','_ITEMS')
		C0YrLWOMgX4 = sorted(C0YrLWOMgX4,reverse=False,key=lambda RRDE0VLWY7CgkuoXlQ4jTwUM23SK: RRDE0VLWY7CgkuoXlQ4jTwUM23SK['category_name'].lower())
		for ra9Zzwkm0SJAHgRcLoB3 in C0YrLWOMgX4:
			TRu4LUg6qXC2 = ra9Zzwkm0SJAHgRcLoB3['category_id']
			v8JT61OEjNwKtXmheW = ra9Zzwkm0SJAHgRcLoB3['category_name']
			TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+v8JT61OEjNwKtXmheW,LS9oDJNxeiTrgny,285,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,str(TRu4LUg6qXC2),nA5dhMRg6ENzsB0l1GwvH7aIr2,{'folder':dkq07Y6WG5enK1QlOLEU8uAj49x})
	elif LS9oDJNxeiTrgny=='XTREAM_SERIES_ITEMS':
		C0YrLWOMgX4 = sorted(C0YrLWOMgX4,reverse=False,key=lambda RRDE0VLWY7CgkuoXlQ4jTwUM23SK: RRDE0VLWY7CgkuoXlQ4jTwUM23SK['name'].lower())
		for U7Rihca2mtGqD in C0YrLWOMgX4:
			v8JT61OEjNwKtXmheW = U7Rihca2mtGqD['name']
			czMOJaKwoCnSPuNTd9bIH8pfLy72W5 = U7Rihca2mtGqD['cover']
			TRu4LUg6qXC2 = U7Rihca2mtGqD['series_id']
			TBt8bUDo9WhL('folder',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+v8JT61OEjNwKtXmheW,'XTREAM_EPISODES',285,czMOJaKwoCnSPuNTd9bIH8pfLy72W5,nA5dhMRg6ENzsB0l1GwvH7aIr2,str(TRu4LUg6qXC2),nA5dhMRg6ENzsB0l1GwvH7aIr2,{'folder':dkq07Y6WG5enK1QlOLEU8uAj49x})
	elif LS9oDJNxeiTrgny=='XTREAM_EPISODES':
		czMOJaKwoCnSPuNTd9bIH8pfLy72W5 = C0YrLWOMgX4['info']['cover']
		w8cPT5nhW2RUAFKDa = C0YrLWOMgX4['info']['name']
		RRLKMPglQ85FVIBj = C0YrLWOMgX4['episodes']
		for VyO7lLpP36ichegxrbGnaNBIQusv9M in RRLKMPglQ85FVIBj:
			PpCB9WyY3xE60OVJomaiNur5X = RRLKMPglQ85FVIBj[VyO7lLpP36ichegxrbGnaNBIQusv9M]
			for i07qDgNewohjcO in PpCB9WyY3xE60OVJomaiNur5X:
				v8JT61OEjNwKtXmheW = i07qDgNewohjcO['title']
				tJ7mYpAnqlMSDjUXgQbuHf4NP = PAztbuyYo4Kvd.findall('\d+.(S\d+E\d+)',v8JT61OEjNwKtXmheW,PAztbuyYo4Kvd.DOTALL)
				if tJ7mYpAnqlMSDjUXgQbuHf4NP: v8JT61OEjNwKtXmheW = w8cPT5nhW2RUAFKDa+hSXlxL9iB05c+tJ7mYpAnqlMSDjUXgQbuHf4NP[0]
				TRu4LUg6qXC2 = i07qDgNewohjcO['id']
				aQ72dvw1uF6yxpgPcn8XrCNkzIZ = i07qDgNewohjcO['container_extension']
				kOTdpYrPqu5A7UIcW0Ch = n5RqEMBVZT0L2.split('/player_api.php')[0]+'/series/'+oKDEiS6bdRqkw1MFJ2ah+'/'+ZNwox8KRnW1mP+'/'+str(TRu4LUg6qXC2)+'.'+aQ72dvw1uF6yxpgPcn8XrCNkzIZ
				TBt8bUDo9WhL('video',r1r9MU8jSNR2csPJnauFeWzvOGhl5q+v8JT61OEjNwKtXmheW,kOTdpYrPqu5A7UIcW0Ch,235,czMOJaKwoCnSPuNTd9bIH8pfLy72W5,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,{'folder':dkq07Y6WG5enK1QlOLEU8uAj49x})
	elif 'ITEMS' in LS9oDJNxeiTrgny:
		WTavfhd7QJDABwpIVrZqHL = 'live' if 'LIVE' in LS9oDJNxeiTrgny else 'video'
		C0YrLWOMgX4 = sorted(C0YrLWOMgX4,reverse=False,key=lambda RRDE0VLWY7CgkuoXlQ4jTwUM23SK: RRDE0VLWY7CgkuoXlQ4jTwUM23SK['name'].lower())
		for zvkuY9iEHGONF4r in C0YrLWOMgX4:
			v8JT61OEjNwKtXmheW = zvkuY9iEHGONF4r['name']
			czMOJaKwoCnSPuNTd9bIH8pfLy72W5 = zvkuY9iEHGONF4r['stream_icon']
			TRu4LUg6qXC2 = zvkuY9iEHGONF4r['stream_id']
			try:
				aQ72dvw1uF6yxpgPcn8XrCNkzIZ = zvkuY9iEHGONF4r['container_extension']
				if aQ72dvw1uF6yxpgPcn8XrCNkzIZ: aQ72dvw1uF6yxpgPcn8XrCNkzIZ = '.'+aQ72dvw1uF6yxpgPcn8XrCNkzIZ
			except: aQ72dvw1uF6yxpgPcn8XrCNkzIZ = nA5dhMRg6ENzsB0l1GwvH7aIr2
			if zvkuY9iEHGONF4r['stream_type']=='live': YYToieWfxNMrX1GU4nLsD0JkHVZ,vQMxRXu59g8VWPbyzDcdm = nA5dhMRg6ENzsB0l1GwvH7aIr2,'live'
			elif zvkuY9iEHGONF4r['stream_type']=='movie': YYToieWfxNMrX1GU4nLsD0JkHVZ,vQMxRXu59g8VWPbyzDcdm = 'movie/','video'
			kOTdpYrPqu5A7UIcW0Ch = n5RqEMBVZT0L2.split('/player_api.php')[0]+'/'+YYToieWfxNMrX1GU4nLsD0JkHVZ+oKDEiS6bdRqkw1MFJ2ah+'/'+ZNwox8KRnW1mP+'/'+str(TRu4LUg6qXC2)+aQ72dvw1uF6yxpgPcn8XrCNkzIZ
			TBt8bUDo9WhL(WTavfhd7QJDABwpIVrZqHL,r1r9MU8jSNR2csPJnauFeWzvOGhl5q+v8JT61OEjNwKtXmheW,kOTdpYrPqu5A7UIcW0Ch,235,czMOJaKwoCnSPuNTd9bIH8pfLy72W5,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,{'folder':dkq07Y6WG5enK1QlOLEU8uAj49x})
	return
def Q8rLzHaSPp4bFfvZNDcMVywx3G(dkq07Y6WG5enK1QlOLEU8uAj49x):
	VxtKwlyZ1gQUcdBjCOTnSsNE = KQctJbXeEjDhplqknU3rzi.getSetting('av.language.provider')
	z3bkmoAhfDLW6q9jSn = KQctJbXeEjDhplqknU3rzi.getSetting('av.language.code')
	aPonC9uhBVpe(FeDIpVljXmOnNkPAHscdTKWrEa,'MENUS_CACHE_'+VxtKwlyZ1gQUcdBjCOTnSsNE+'_'+z3bkmoAhfDLW6q9jSn,'%_IP'+dkq07Y6WG5enK1QlOLEU8uAj49x+'_%')
	return
# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'SERIES4WATCH'
headers = { 'User-Agent' : nA5dhMRg6ENzsB0l1GwvH7aIr2 }
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_SFW_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==210: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==211: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
	elif mode==212: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==213: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LLabVp7hzj28CE0f1udx(url)
	elif mode==214: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = oSQrELd71azHlDtRh3W8KYAJfUFuC(url)
	elif mode==215: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = FqWDuypLSwQ4GB(url)
	elif mode==218: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = TNeG43JwpWRlvcEPfbUydmLnkxaYV8()
	elif mode==219: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def TNeG43JwpWRlvcEPfbUydmLnkxaYV8():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'الموقع تغير بالكامل',message)
	return
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,219,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/getpostsPin?type=one&data=pin&limit=25'
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'المميزة',url,211)
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SERIES4WATCH-MENU-1st')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('FiltersButtons(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('data-get="(.*?)".*?</i>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title in items:
		url = GiqvpBF9xLEdHDr37byJSngeCQ+'/getposts?type=one&data='+ZylHkumQ8zD0
		TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,211)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('navigation-menu(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('href="(http.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	SAsGubf1jW2Q3p = ['مسلسلات انمي','الرئيسية']
	for ZylHkumQ8zD0,title in items:
		title = title.strip(hSXlxL9iB05c)
		if not any(value in title for value in SAsGubf1jW2Q3p):
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,211)
	return kl2ZWdy8rXcHT
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url):
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: WWU7QJP2tyTRLIfDh0csxbkvX = kl2ZWdy8rXcHT
	else:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('MediaGrid"(.*?)class="pagination"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug: WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		else: return
	items = PAztbuyYo4Kvd.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	u0UiTmzYN6I3Q9eCZVoB = []
	rrau73jLb0H = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for HRlygv7YwjzbSLt8fkEerq2,ZylHkumQ8zD0,title in items:
		if '/series/' in ZylHkumQ8zD0: continue
		ZylHkumQ8zD0 = pvOytL0nF7JY6flXTxAcHbQeNahu3(ZylHkumQ8zD0).strip('/')
		title = HH8SJuswDBPtniebmkXIr(title)
		title = title.strip(hSXlxL9iB05c)
		if '/film/' in ZylHkumQ8zD0 or any(value in title for value in rrau73jLb0H):
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,212,HRlygv7YwjzbSLt8fkEerq2)
		elif '/episode/' in ZylHkumQ8zD0 and 'الحلقة' in title:
			JfNHOP2BK1Yxl7Rq4 = PAztbuyYo4Kvd.findall('(.*?) الحلقة \d+',title,PAztbuyYo4Kvd.DOTALL)
			if JfNHOP2BK1Yxl7Rq4:
				title = '_MOD_' + JfNHOP2BK1Yxl7Rq4[0]
				if title not in u0UiTmzYN6I3Q9eCZVoB:
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,213,HRlygv7YwjzbSLt8fkEerq2)
					u0UiTmzYN6I3Q9eCZVoB.append(title)
		else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,213,HRlygv7YwjzbSLt8fkEerq2)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="pagination(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			ZylHkumQ8zD0 = HH8SJuswDBPtniebmkXIr(ZylHkumQ8zD0)
			title = HH8SJuswDBPtniebmkXIr(title)
			title = title.replace('الصفحة ',nA5dhMRg6ENzsB0l1GwvH7aIr2)
			if title!=nA5dhMRg6ENzsB0l1GwvH7aIr2: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+title,ZylHkumQ8zD0,211)
	return
def LLabVp7hzj28CE0f1udx(url):
	pByiaN1kE60RLcwAv5UKbQFYJjGh,items,rIgbVtw5WHEM = -1,[],[]
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SERIES4WATCH-EPISODES-1st')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('ti-list-numbered(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q = nA5dhMRg6ENzsB0l1GwvH7aIr2.join(zz3eHskxE6lAyDR5cNj1ug)
		items = PAztbuyYo4Kvd.findall('href="(.*?)"',Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q,PAztbuyYo4Kvd.DOTALL)
	items.append(url)
	items = set(items)
	for ZylHkumQ8zD0 in items:
		ZylHkumQ8zD0 = ZylHkumQ8zD0.strip('/')
		title = '_MOD_' + ZylHkumQ8zD0.split('/')[-1].replace('-',hSXlxL9iB05c)
		Ns6egmVv7nRutdLSQUaE8WFq5 = PAztbuyYo4Kvd.findall('الحلقة-(\d+)',ZylHkumQ8zD0.split('/')[-1],PAztbuyYo4Kvd.DOTALL)
		if Ns6egmVv7nRutdLSQUaE8WFq5: Ns6egmVv7nRutdLSQUaE8WFq5 = Ns6egmVv7nRutdLSQUaE8WFq5[0]
		else: Ns6egmVv7nRutdLSQUaE8WFq5 = '0'
		rIgbVtw5WHEM.append([ZylHkumQ8zD0,title,Ns6egmVv7nRutdLSQUaE8WFq5])
	items = sorted(rIgbVtw5WHEM, reverse=False, key=lambda key: int(key[2]))
	LTZIA5N9xbQCs743 = str(items).count('/season/')
	pByiaN1kE60RLcwAv5UKbQFYJjGh = str(items).count('/episode/')
	if LTZIA5N9xbQCs743>1 and pByiaN1kE60RLcwAv5UKbQFYJjGh>0 and '/season/' not in url:
		for ZylHkumQ8zD0,title,Ns6egmVv7nRutdLSQUaE8WFq5 in items:
			if '/season/' in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,213)
	else:
		for ZylHkumQ8zD0,title,Ns6egmVv7nRutdLSQUaE8WFq5 in items:
			if '/season/' not in ZylHkumQ8zD0: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,212)
	return
def lNBcUr8RCn(url):
	ce9zAaVFswSq6lLr82DfQyotGW = []
	yoGhEciOC1 = url.split('/')
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SERIES4WATCH-PLAY-1st')
	if '/watch/' in kl2ZWdy8rXcHT:
		KteRnFMjHpBPqNf8 = url.replace(yoGhEciOC1[3],'watch')
		v2u4dgJnek0sQDxKf = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SERIES4WATCH-PLAY-2nd')
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="servers-list(.*?)</div>',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			if items:
				id = PAztbuyYo4Kvd.findall('post_id=(.*?)"',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL)
				if id:
					xhqyQAmiYa6FwRM4DO21Jvj = id[0]
					for ZylHkumQ8zD0,title in items:
						ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/?postid='+xhqyQAmiYa6FwRM4DO21Jvj+'&serverid='+ZylHkumQ8zD0+'?named='+title+'__watch'
						ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
			else:
				items = PAztbuyYo4Kvd.findall('data-embedd=".*?(http.*?)("|&quot;)',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
				for ZylHkumQ8zD0,eIlXpH1gLhmP4w3 in items:
					ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	if '/download/' in kl2ZWdy8rXcHT:
		KteRnFMjHpBPqNf8 = url.replace(yoGhEciOC1[3],'download')
		v2u4dgJnek0sQDxKf = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SERIES4WATCH-PLAY-3rd')
		id = PAztbuyYo4Kvd.findall('postId:"(.*?)"',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL)
		if id:
			xhqyQAmiYa6FwRM4DO21Jvj = id[0]
			LevQwm0pbqP1 = { 'User-Agent':nA5dhMRg6ENzsB0l1GwvH7aIr2 , 'X-Requested-With':'XMLHttpRequest' }
			KteRnFMjHpBPqNf8 = GiqvpBF9xLEdHDr37byJSngeCQ + '/ajaxCenter?_action=getdownloadlinks&postId='+xhqyQAmiYa6FwRM4DO21Jvj
			v2u4dgJnek0sQDxKf = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,LevQwm0pbqP1,nA5dhMRg6ENzsB0l1GwvH7aIr2,'SERIES4WATCH-PLAY-4th')
			zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('<h3.*?(\d+)(.*?)</div>',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL)
			if zz3eHskxE6lAyDR5cNj1ug:
				for woRNi2hL8G7,WWU7QJP2tyTRLIfDh0csxbkvX in zz3eHskxE6lAyDR5cNj1ug:
					items = PAztbuyYo4Kvd.findall('<td>(.*?)<.*?href="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
					for name,ZylHkumQ8zD0 in items:
						ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0+'?named='+name+'__download'+'____'+woRNi2hL8G7)
			else:
				zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('<h6(.*?)</table>',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL)
				if not zz3eHskxE6lAyDR5cNj1ug: zz3eHskxE6lAyDR5cNj1ug = [v2u4dgJnek0sQDxKf]
				for WWU7QJP2tyTRLIfDh0csxbkvX in zz3eHskxE6lAyDR5cNj1ug:
					name = nA5dhMRg6ENzsB0l1GwvH7aIr2
					items = PAztbuyYo4Kvd.findall('href="(http.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
					for ZylHkumQ8zD0 in items:
						DQ7XgFltujVL = '&&' + ZylHkumQ8zD0.split('/')[2].lower() + '&&'
						DQ7XgFltujVL = DQ7XgFltujVL.replace('.com&&',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('.co&&',nA5dhMRg6ENzsB0l1GwvH7aIr2)
						DQ7XgFltujVL = DQ7XgFltujVL.replace('.net&&',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('.org&&',nA5dhMRg6ENzsB0l1GwvH7aIr2)
						DQ7XgFltujVL = DQ7XgFltujVL.replace('.live&&',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('.online&&',nA5dhMRg6ENzsB0l1GwvH7aIr2)
						DQ7XgFltujVL = DQ7XgFltujVL.replace('&&hd.',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('&&www.',nA5dhMRg6ENzsB0l1GwvH7aIr2)
						DQ7XgFltujVL = DQ7XgFltujVL.replace('&&',nA5dhMRg6ENzsB0l1GwvH7aIr2)
						ZylHkumQ8zD0 = ZylHkumQ8zD0 + '?named=' + name + DQ7XgFltujVL + '__download'
						ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(ce9zAaVFswSq6lLr82DfQyotGW,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	search = search.replace(hSXlxL9iB05c,'+')
	url = GiqvpBF9xLEdHDr37byJSngeCQ + '/search?s='+search
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
	return
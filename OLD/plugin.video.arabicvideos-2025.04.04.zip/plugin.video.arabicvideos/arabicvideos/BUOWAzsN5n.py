# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'CIMANOW'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_CMN_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
SAsGubf1jW2Q3p = ['قائمتي']
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==300: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==301: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = oWcvptkU2JObI0(url)
	elif mode==302: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
	elif mode==303: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = G7GSMxU0Iw8zd(url)
	elif mode==304: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LLabVp7hzj28CE0f1udx(url)
	elif mode==305: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==306: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = zi4GqFhBkjuS8()
	elif mode==309: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,309,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',GiqvpBF9xLEdHDr37byJSngeCQ+'/home',nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMANOW-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('<header(.*?)</header>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('<li><a href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title in items:
		title = title.strip(hSXlxL9iB05c)
		if not any(value in title for value in SAsGubf1jW2Q3p):
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,301)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	oWcvptkU2JObI0(GiqvpBF9xLEdHDr37byJSngeCQ+'/home',kl2ZWdy8rXcHT)
	return kl2ZWdy8rXcHT
def zi4GqFhBkjuS8():
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,'موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def oWcvptkU2JObI0(url,kl2ZWdy8rXcHT=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if not kl2ZWdy8rXcHT:
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMANOW-SUBMENU-1st')
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	XXJAOcyjfEhSxC = 0
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('(<section>.*?</section>)',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		for WWU7QJP2tyTRLIfDh0csxbkvX in zz3eHskxE6lAyDR5cNj1ug:
			XXJAOcyjfEhSxC += 1
			items = PAztbuyYo4Kvd.findall('<section>.<span>(.*?)<(.*?)href="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for title,HHzRcC0Fv1u6r5,ZylHkumQ8zD0 in items:
				title = title.strip(hSXlxL9iB05c)
				if title==nA5dhMRg6ENzsB0l1GwvH7aIr2: title = 'بووووو'
				if 'em><a' not in HHzRcC0Fv1u6r5:
					if WWU7QJP2tyTRLIfDh0csxbkvX.count('/category/')>0:
						yDlV9KzvF7k6SB2MRu1YsW = PAztbuyYo4Kvd.findall('href="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
						for ZylHkumQ8zD0 in yDlV9KzvF7k6SB2MRu1YsW:
							title = ZylHkumQ8zD0.split('/')[-2]
							TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,301)
						continue
					else: ZylHkumQ8zD0 = url+'?sequence='+str(XXJAOcyjfEhSxC)
				if not any(value in title for value in SAsGubf1jW2Q3p):
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,302)
	else: LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,kl2ZWdy8rXcHT)
	return
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,kl2ZWdy8rXcHT=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if kl2ZWdy8rXcHT==nA5dhMRg6ENzsB0l1GwvH7aIr2:
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMANOW-TITLES-1st')
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	if '?sequence=' in url:
		url,XXJAOcyjfEhSxC = url.split('?sequence=')
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('(<section>.*?</section>)',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[int(XXJAOcyjfEhSxC)-1]
	else:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"posts"(.*?)</body>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	u0UiTmzYN6I3Q9eCZVoB = []
	for ZylHkumQ8zD0,data,HRlygv7YwjzbSLt8fkEerq2 in items:
		title = PAztbuyYo4Kvd.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,PAztbuyYo4Kvd.DOTALL)
		if title: title = title[0][2].replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c)
		if not title or title==nA5dhMRg6ENzsB0l1GwvH7aIr2:
			title = PAztbuyYo4Kvd.findall('title">.*?</em>(.*?)<',data,PAztbuyYo4Kvd.DOTALL)
			if title: title = title[0].replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c)
			if not title or title==nA5dhMRg6ENzsB0l1GwvH7aIr2:
				title = PAztbuyYo4Kvd.findall('title">(.*?)<',data,PAztbuyYo4Kvd.DOTALL)
				title = title[0].replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c)
		title = HH8SJuswDBPtniebmkXIr(title)
		title = title.replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c)
		if title not in u0UiTmzYN6I3Q9eCZVoB:
			u0UiTmzYN6I3Q9eCZVoB.append(title)
			YERWNbgAThV2uBr5taO8zcd = ZylHkumQ8zD0+data+HRlygv7YwjzbSLt8fkEerq2
			if '/selary/' in YERWNbgAThV2uBr5taO8zcd or 'مسلسل' in YERWNbgAThV2uBr5taO8zcd or '"episode"' in YERWNbgAThV2uBr5taO8zcd:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,303,HRlygv7YwjzbSLt8fkEerq2)
			else: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,305,HRlygv7YwjzbSLt8fkEerq2)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"pagination"(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('<li><a href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+title,ZylHkumQ8zD0,302)
	return
def G7GSMxU0Iw8zd(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMANOW-SEASONS-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	name = PAztbuyYo4Kvd.findall('<title>(.*?)</title>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if name:
		name = name[0].replace('| سيما ناو',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('Cima Now',nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c).replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c)
		name = name.split('الحلقة')[0].strip(hSXlxL9iB05c)+' - '
	else: name = nA5dhMRg6ENzsB0l1GwvH7aIr2
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('<section(.*?)</section>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if len(items)>1:
			for ZylHkumQ8zD0,title in items:
				title = name+title.replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c)
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,304)
		elif len(items)==1:
			ZylHkumQ8zD0,title = items[0]
			LLabVp7hzj28CE0f1udx(ZylHkumQ8zD0)
		else: LLabVp7hzj28CE0f1udx(url)
	return
def LLabVp7hzj28CE0f1udx(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMANOW-EPISODES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	if '/selary/' not in url:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"episodes"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[IpFcwrWNgefMym3qta0hYQAzOdE]
		items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			title = title.replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c)
			title = 'الحلقة '+title
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,305)
	else:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"details"(.*?)"related"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[IpFcwrWNgefMym3qta0hYQAzOdE]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
			title = title.replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c)
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,305,HRlygv7YwjzbSLt8fkEerq2)
	return
def lNBcUr8RCn(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMANOW-PLAY-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	ppMQ1JzdrAc6W7iXxgaHLbTDeF92h = PAztbuyYo4Kvd.findall('class="shine" href="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if ppMQ1JzdrAc6W7iXxgaHLbTDeF92h:
		DQ7XgFltujVL = C2gnJ5tXFk9pAL(ppMQ1JzdrAc6W7iXxgaHLbTDeF92h[0],'url')
		headers = {'Referer':DQ7XgFltujVL}
	else: headers = nA5dhMRg6ENzsB0l1GwvH7aIr2
	KteRnFMjHpBPqNf8 = url+'watching/'
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,'GET',KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMANOW-PLAY-5th')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	ce9zAaVFswSq6lLr82DfQyotGW = []
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"download"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?</i>(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			title = title.replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c)
			OzWg1yEQG8wtvJ4x2ic9aKedFAPD = PAztbuyYo4Kvd.findall('\d\d\d+',title,PAztbuyYo4Kvd.DOTALL)
			if OzWg1yEQG8wtvJ4x2ic9aKedFAPD:
				OzWg1yEQG8wtvJ4x2ic9aKedFAPD = '____'+OzWg1yEQG8wtvJ4x2ic9aKedFAPD[0]
				title = C2gnJ5tXFk9pAL(ZylHkumQ8zD0,'name')
			else: OzWg1yEQG8wtvJ4x2ic9aKedFAPD = nA5dhMRg6ENzsB0l1GwvH7aIr2
			ww5oBKPZmc = ZylHkumQ8zD0+'?named='+title+'__download'+OzWg1yEQG8wtvJ4x2ic9aKedFAPD
			ce9zAaVFswSq6lLr82DfQyotGW.append(ww5oBKPZmc)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"watch"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		HRpMVv1x5ol9gbsnQquj = PAztbuyYo4Kvd.findall('"embed".*?src="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0 in HRpMVv1x5ol9gbsnQquj:
			if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = 'http:'+ZylHkumQ8zD0
			title = C2gnJ5tXFk9pAL(ZylHkumQ8zD0,'name')
			ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named='+title+'__embed'
			ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
		HRpMVv1x5ol9gbsnQquj = [GiqvpBF9xLEdHDr37byJSngeCQ+'/wp-content/themes/Cima%20Now%20New/core.php']
		if HRpMVv1x5ol9gbsnQquj:
			items = PAztbuyYo4Kvd.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for rRxld1HykSCacZs0mzWXIBibn,id,title in items:
				title = title.replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c)
				ZylHkumQ8zD0 = HRpMVv1x5ol9gbsnQquj[0]+'?action=switch&index='+rRxld1HykSCacZs0mzWXIBibn+'&id='+id+'?named='+title+'__watch'
				ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(ce9zAaVFswSq6lLr82DfQyotGW,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	search = search.replace(hSXlxL9iB05c,'+')
	url = GiqvpBF9xLEdHDr37byJSngeCQ + '/?s='+search
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
	return
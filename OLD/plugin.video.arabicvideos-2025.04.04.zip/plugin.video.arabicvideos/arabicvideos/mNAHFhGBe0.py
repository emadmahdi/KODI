# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'ARBLIONZ'
headers = { 'User-Agent' : nA5dhMRg6ENzsB0l1GwvH7aIr2 }
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_ARL_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
SAsGubf1jW2Q3p = ['عروض المصارعة','الكل','الرئيسية','العاب','برامج كمبيوتر','موبايل و جوال','القسم الاسلامي']
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==200: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==201: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
	elif mode==202: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==203: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LLabVp7hzj28CE0f1udx(url)
	elif mode==204: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = NNihMcqGKQEvLz6l(url,'FILTERS___'+text)
	elif mode==205: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = NNihMcqGKQEvLz6l(url,'CATEGORIES___'+text)
	elif mode==209: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,209,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فلتر محدد',GiqvpBF9xLEdHDr37byJSngeCQ,205)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فلتر كامل',GiqvpBF9xLEdHDr37byJSngeCQ,204)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مميزة',GiqvpBF9xLEdHDr37byJSngeCQ+'??trending',201)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'أفلام مميزة',GiqvpBF9xLEdHDr37byJSngeCQ+'??trending_movies',201)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مسلسلات مميزة',GiqvpBF9xLEdHDr37byJSngeCQ+'??trending_series',201)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الصفحة الرئيسية',GiqvpBF9xLEdHDr37byJSngeCQ+'??mainpage',201)
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,True,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ARBLIONZ-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('categories-tabs(.*?)MainRow',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('data-get="(.*?)".*?<h3>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for filter,title in items:
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/ajax/home/more?filter='+filter
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,201)
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('navigation-menu(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('href="(.*?)".*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title in items:
		if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
		title = title.strip(hSXlxL9iB05c)
		if not any(value in title for value in SAsGubf1jW2Q3p):
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,201)
	return kl2ZWdy8rXcHT
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url):
	if '??' in url: url,type = url.split('??')
	else: type = nA5dhMRg6ENzsB0l1GwvH7aIr2
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,True,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ARBLIONZ-TITLES-2nd')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content.encode(YWEQ3Cf8RevpD0m7NjF1)
	if 'getposts' in url: zz3eHskxE6lAyDR5cNj1ug = [kl2ZWdy8rXcHT]
	elif type=='trending':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('MasterSlider(.*?)</div>\n *</div>\n *</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	elif type=='trending_movies':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('Slider_1(.*?)</div>.</div>.</div>.</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	elif type=='trending_series':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('Slider_2(.*?)</div>.</div>.</div>.</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	elif type=='111mainpage':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="container page-content"(.*?)class="tabs"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	else:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('page-content(.*?)main-footer',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if not zz3eHskxE6lAyDR5cNj1ug: return
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	rrau73jLb0H = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	items = PAztbuyYo4Kvd.findall('content-box".*?src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	if not items:
		items = PAztbuyYo4Kvd.findall('SliderItem".*?href="(.*?)".*?image: url\((.*?)\).*?<h2>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		HRpMVv1x5ol9gbsnQquj,YqUzIsN4oSOlVuhEiG2keyFj3,FwAWKXTqvQiL98jeJ2 = zip(*items)
		items = zip(YqUzIsN4oSOlVuhEiG2keyFj3,HRpMVv1x5ol9gbsnQquj,FwAWKXTqvQiL98jeJ2)
	u0UiTmzYN6I3Q9eCZVoB = []
	for HRlygv7YwjzbSLt8fkEerq2,ZylHkumQ8zD0,title in items:
		if '/series/' in ZylHkumQ8zD0: continue
		ZylHkumQ8zD0 = ZylHkumQ8zD0.strip('/')
		title = HH8SJuswDBPtniebmkXIr(title)
		title = title.strip(hSXlxL9iB05c)
		if '/film/' in ZylHkumQ8zD0 or any(value in title for value in rrau73jLb0H):
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,202,HRlygv7YwjzbSLt8fkEerq2)
		elif '/episode/' in ZylHkumQ8zD0 and 'الحلقة' in title:
			JfNHOP2BK1Yxl7Rq4 = PAztbuyYo4Kvd.findall('(.*?) الحلقة \d+',title,PAztbuyYo4Kvd.DOTALL)
			if JfNHOP2BK1Yxl7Rq4:
				title = '_MOD_' + JfNHOP2BK1Yxl7Rq4[0]
				if title not in u0UiTmzYN6I3Q9eCZVoB:
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,203,HRlygv7YwjzbSLt8fkEerq2)
					u0UiTmzYN6I3Q9eCZVoB.append(title)
		elif '/pack/' in ZylHkumQ8zD0:
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0+'/films',201,HRlygv7YwjzbSLt8fkEerq2)
		else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,203,HRlygv7YwjzbSLt8fkEerq2)
	if type in [nA5dhMRg6ENzsB0l1GwvH7aIr2,'mainpage']:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="pagination(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall('href=["\'](http.*?)["\'].*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,title in items:
				ZylHkumQ8zD0 = HH8SJuswDBPtniebmkXIr(ZylHkumQ8zD0)
				title = HH8SJuswDBPtniebmkXIr(title)
				title = title.replace('الصفحة ',nA5dhMRg6ENzsB0l1GwvH7aIr2)
				if 'search?s=' in url:
					pCiQo05u7YM1fbZLPyE = ZylHkumQ8zD0.split('page=')[1]
					OSvw5lk261zxLjh = url.split('page=')[1]
					ZylHkumQ8zD0 = url.replace('page='+OSvw5lk261zxLjh,'page='+pCiQo05u7YM1fbZLPyE)
				if title!=nA5dhMRg6ENzsB0l1GwvH7aIr2: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+title,ZylHkumQ8zD0,201)
	return
def LLabVp7hzj28CE0f1udx(url):
	pByiaN1kE60RLcwAv5UKbQFYJjGh,items,rIgbVtw5WHEM = -1,[],[]
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,True,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ARBLIONZ-EPISODES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content.encode(YWEQ3Cf8RevpD0m7NjF1)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('ti-list-numbered(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		rIgbVtw5WHEM = []
		Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q = nA5dhMRg6ENzsB0l1GwvH7aIr2.join(zz3eHskxE6lAyDR5cNj1ug)
		items = PAztbuyYo4Kvd.findall('href="(.*?)"',Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q,PAztbuyYo4Kvd.DOTALL)
	items.append(url)
	items = set(items)
	for ZylHkumQ8zD0 in items:
		ZylHkumQ8zD0 = ZylHkumQ8zD0.strip('/')
		title = '_MOD_' + ZylHkumQ8zD0.split('/')[-1].replace('-',hSXlxL9iB05c)
		Ns6egmVv7nRutdLSQUaE8WFq5 = PAztbuyYo4Kvd.findall('الحلقة-(\d+)',ZylHkumQ8zD0.split('/')[-1],PAztbuyYo4Kvd.DOTALL)
		if Ns6egmVv7nRutdLSQUaE8WFq5: Ns6egmVv7nRutdLSQUaE8WFq5 = Ns6egmVv7nRutdLSQUaE8WFq5[0]
		else: Ns6egmVv7nRutdLSQUaE8WFq5 = '0'
		rIgbVtw5WHEM.append([ZylHkumQ8zD0,title,Ns6egmVv7nRutdLSQUaE8WFq5])
	items = sorted(rIgbVtw5WHEM, reverse=False, key=lambda key: int(key[2]))
	LTZIA5N9xbQCs743 = str(items).count('/season/')
	pByiaN1kE60RLcwAv5UKbQFYJjGh = str(items).count('/episode/')
	if LTZIA5N9xbQCs743>1 and pByiaN1kE60RLcwAv5UKbQFYJjGh>0 and '/season/' not in url:
		for ZylHkumQ8zD0,title,Ns6egmVv7nRutdLSQUaE8WFq5 in items:
			if '/season/' in ZylHkumQ8zD0:
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,203)
	else:
		for ZylHkumQ8zD0,title,Ns6egmVv7nRutdLSQUaE8WFq5 in items:
			if '/season/' not in ZylHkumQ8zD0:
				title = pvOytL0nF7JY6flXTxAcHbQeNahu3(title)
				TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,202)
	return
def lNBcUr8RCn(url):
	ce9zAaVFswSq6lLr82DfQyotGW = []
	yoGhEciOC1 = url.split('/')
	xycejnJHQawud3okbfstlr = GiqvpBF9xLEdHDr37byJSngeCQ
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,True,True,'ARBLIONZ-PLAY-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content.encode(YWEQ3Cf8RevpD0m7NjF1)
	id = PAztbuyYo4Kvd.findall('postId:"(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if not id: id = PAztbuyYo4Kvd.findall('post_id=(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if not id: id = PAztbuyYo4Kvd.findall('post-id="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if id: id = id[0]
	if '/watch/' in kl2ZWdy8rXcHT:
		KteRnFMjHpBPqNf8 = url.replace(yoGhEciOC1[3],'watch')
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,True,True,'ARBLIONZ-PLAY-2nd')
		v2u4dgJnek0sQDxKf = Y3SmVGbfNvEeakMBr.content.encode(YWEQ3Cf8RevpD0m7NjF1)
		kkgmyjLhK73DzNYCq8 = PAztbuyYo4Kvd.findall('data-embedd="(.*?)".*?alt="(.*?)"',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL)
		hn2rCExmu5pgejyYOT = PAztbuyYo4Kvd.findall('data-embedd=".*?(http.*?)("|&quot;)',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL)
		ZA0l1Eby9n3MLeDjcH6XWPFtopJu7K = PAztbuyYo4Kvd.findall('src=&quot;(.*?)&quot;.*?>(.*?)<',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL|PAztbuyYo4Kvd.IGNORECASE)
		kqdyWrcGETKNHzLh4fsQP19pF = PAztbuyYo4Kvd.findall('data-embedd="(.*?)">\n*.*?server_image">\n(.*?)\n',v2u4dgJnek0sQDxKf)
		VXhZNzUBEcnJyqF1uQtf6M = PAztbuyYo4Kvd.findall('src=&quot;(.*?)&quot;.*?alt="(.*?)"',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL|PAztbuyYo4Kvd.IGNORECASE)
		bNS1AXqKIx5Y7ulyBwneFCrkLiW = PAztbuyYo4Kvd.findall('server="(.*?)".*?<span>(.*?)<',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL|PAztbuyYo4Kvd.IGNORECASE)
		items = kkgmyjLhK73DzNYCq8+hn2rCExmu5pgejyYOT+ZA0l1Eby9n3MLeDjcH6XWPFtopJu7K+kqdyWrcGETKNHzLh4fsQP19pF+VXhZNzUBEcnJyqF1uQtf6M+bNS1AXqKIx5Y7ulyBwneFCrkLiW
		if not items:
			items = PAztbuyYo4Kvd.findall('<span>(.*?)</span>.*?src="(.*?)"',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL|PAztbuyYo4Kvd.IGNORECASE)
			items = [(uu4aPIg6AE,GLpoAINt4k) for GLpoAINt4k,uu4aPIg6AE in items]
		for DQ7XgFltujVL,title in items:
			if '.png' in DQ7XgFltujVL: continue
			if '.jpg' in DQ7XgFltujVL: continue
			if '&quot;' in DQ7XgFltujVL: continue
			OzWg1yEQG8wtvJ4x2ic9aKedFAPD = PAztbuyYo4Kvd.findall('\d\d\d+',title,PAztbuyYo4Kvd.DOTALL)
			if OzWg1yEQG8wtvJ4x2ic9aKedFAPD:
				OzWg1yEQG8wtvJ4x2ic9aKedFAPD = OzWg1yEQG8wtvJ4x2ic9aKedFAPD[0]
				if OzWg1yEQG8wtvJ4x2ic9aKedFAPD in title: title = title.replace(OzWg1yEQG8wtvJ4x2ic9aKedFAPD+'p',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(OzWg1yEQG8wtvJ4x2ic9aKedFAPD,nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c)
				OzWg1yEQG8wtvJ4x2ic9aKedFAPD = '____'+OzWg1yEQG8wtvJ4x2ic9aKedFAPD
			else: OzWg1yEQG8wtvJ4x2ic9aKedFAPD = nA5dhMRg6ENzsB0l1GwvH7aIr2
			if DQ7XgFltujVL.isdigit():
				ZylHkumQ8zD0 = xycejnJHQawud3okbfstlr+'/?postid='+id+'&serverid='+DQ7XgFltujVL+'?named='+title+'__watch'+OzWg1yEQG8wtvJ4x2ic9aKedFAPD
			else:
				if 'http' not in DQ7XgFltujVL: DQ7XgFltujVL = 'http:'+DQ7XgFltujVL
				OzWg1yEQG8wtvJ4x2ic9aKedFAPD = PAztbuyYo4Kvd.findall('\d\d\d+',title,PAztbuyYo4Kvd.DOTALL)
				if OzWg1yEQG8wtvJ4x2ic9aKedFAPD: OzWg1yEQG8wtvJ4x2ic9aKedFAPD = '____'+OzWg1yEQG8wtvJ4x2ic9aKedFAPD[0]
				else: OzWg1yEQG8wtvJ4x2ic9aKedFAPD = nA5dhMRg6ENzsB0l1GwvH7aIr2
				ZylHkumQ8zD0 = DQ7XgFltujVL+'?named=__watch'+OzWg1yEQG8wtvJ4x2ic9aKedFAPD
			ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	if 'DownloadNow' in kl2ZWdy8rXcHT:
		LevQwm0pbqP1 = { 'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8' }
		KteRnFMjHpBPqNf8 = url+'/download'
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,LevQwm0pbqP1,True,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ARBLIONZ-PLAY-3rd')
		v2u4dgJnek0sQDxKf = Y3SmVGbfNvEeakMBr.content.encode(YWEQ3Cf8RevpD0m7NjF1)
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('<ul class="download-items(.*?)</ul>',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL)
		for WWU7QJP2tyTRLIfDh0csxbkvX in zz3eHskxE6lAyDR5cNj1ug:
			items = PAztbuyYo4Kvd.findall('href="(http.*?)".*?<span>(.*?)<.*?<p>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,name,OzWg1yEQG8wtvJ4x2ic9aKedFAPD in items:
				ZylHkumQ8zD0 = ZylHkumQ8zD0+'?named='+name+'__download'+'____'+OzWg1yEQG8wtvJ4x2ic9aKedFAPD
				ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	elif '/download/' in kl2ZWdy8rXcHT:
		LevQwm0pbqP1 = { 'User-Agent':nA5dhMRg6ENzsB0l1GwvH7aIr2 , 'X-Requested-With':'XMLHttpRequest' }
		KteRnFMjHpBPqNf8 = xycejnJHQawud3okbfstlr + '/ajaxCenter?_action=getdownloadlinks&postId='+id
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,LevQwm0pbqP1,True,True,'ARBLIONZ-PLAY-4th')
		v2u4dgJnek0sQDxKf = Y3SmVGbfNvEeakMBr.content.encode(YWEQ3Cf8RevpD0m7NjF1)
		if 'download-btns' in v2u4dgJnek0sQDxKf:
			ZA0l1Eby9n3MLeDjcH6XWPFtopJu7K = PAztbuyYo4Kvd.findall('href="(.*?)"',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL)
			for w7Ol6FnokgJDSsIt in ZA0l1Eby9n3MLeDjcH6XWPFtopJu7K:
				if '/page/' not in w7Ol6FnokgJDSsIt and 'http' in w7Ol6FnokgJDSsIt:
					w7Ol6FnokgJDSsIt = w7Ol6FnokgJDSsIt+'?named=__download'
					ce9zAaVFswSq6lLr82DfQyotGW.append(w7Ol6FnokgJDSsIt)
				elif '/page/' in w7Ol6FnokgJDSsIt:
					OzWg1yEQG8wtvJ4x2ic9aKedFAPD = nA5dhMRg6ENzsB0l1GwvH7aIr2
					Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',w7Ol6FnokgJDSsIt,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,True,True,'ARBLIONZ-PLAY-5th')
					oRhWMsQXZ8AGiB3kCeDzcESPa = Y3SmVGbfNvEeakMBr.content.encode(YWEQ3Cf8RevpD0m7NjF1)
					Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q = PAztbuyYo4Kvd.findall('(<strong>.*?)-----',oRhWMsQXZ8AGiB3kCeDzcESPa,PAztbuyYo4Kvd.DOTALL)
					for tUjkcN0T31uia5FA2n in Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q:
						d9WVqQifocSGHEDv7u = nA5dhMRg6ENzsB0l1GwvH7aIr2
						kqdyWrcGETKNHzLh4fsQP19pF = PAztbuyYo4Kvd.findall('<strong>(.*?)</strong>',tUjkcN0T31uia5FA2n,PAztbuyYo4Kvd.DOTALL)
						for ZiG5TofQhEbP6psHkgSvWuC14FK3U in kqdyWrcGETKNHzLh4fsQP19pF:
							CQtNwXGVAJ2y5nBY = PAztbuyYo4Kvd.findall('\d\d\d+',ZiG5TofQhEbP6psHkgSvWuC14FK3U,PAztbuyYo4Kvd.DOTALL)
							if CQtNwXGVAJ2y5nBY:
								OzWg1yEQG8wtvJ4x2ic9aKedFAPD = '____'+CQtNwXGVAJ2y5nBY[0]
								break
						for ZiG5TofQhEbP6psHkgSvWuC14FK3U in reversed(kqdyWrcGETKNHzLh4fsQP19pF):
							CQtNwXGVAJ2y5nBY = PAztbuyYo4Kvd.findall('\w\w+',ZiG5TofQhEbP6psHkgSvWuC14FK3U,PAztbuyYo4Kvd.DOTALL)
							if CQtNwXGVAJ2y5nBY:
								d9WVqQifocSGHEDv7u = CQtNwXGVAJ2y5nBY[0]
								break
						VXhZNzUBEcnJyqF1uQtf6M = PAztbuyYo4Kvd.findall('href="(.*?)"',tUjkcN0T31uia5FA2n,PAztbuyYo4Kvd.DOTALL)
						for fALdovXWt7DpxM5iZn01c2 in VXhZNzUBEcnJyqF1uQtf6M:
							fALdovXWt7DpxM5iZn01c2 = fALdovXWt7DpxM5iZn01c2+'?named='+d9WVqQifocSGHEDv7u+'__download'+OzWg1yEQG8wtvJ4x2ic9aKedFAPD
							ce9zAaVFswSq6lLr82DfQyotGW.append(fALdovXWt7DpxM5iZn01c2)
		elif 'slow-motion' in v2u4dgJnek0sQDxKf:
			v2u4dgJnek0sQDxKf = v2u4dgJnek0sQDxKf.replace('<h6 ','==END== ==START==')+'==END=='
			v2u4dgJnek0sQDxKf = v2u4dgJnek0sQDxKf.replace('<h3 ','==END== ==START==')+'==END=='
			Mg3SCeFi2Uy9bdm4qj8XQ = PAztbuyYo4Kvd.findall('==START==(.*?)==END==',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL)
			if Mg3SCeFi2Uy9bdm4qj8XQ:
				for tUjkcN0T31uia5FA2n in Mg3SCeFi2Uy9bdm4qj8XQ:
					if 'href=' not in tUjkcN0T31uia5FA2n: continue
					tNRplaqHJ7XfDsT103AugCZ9 = nA5dhMRg6ENzsB0l1GwvH7aIr2
					kqdyWrcGETKNHzLh4fsQP19pF = PAztbuyYo4Kvd.findall('slow-motion">(.*?)<',tUjkcN0T31uia5FA2n,PAztbuyYo4Kvd.DOTALL)
					for ZiG5TofQhEbP6psHkgSvWuC14FK3U in kqdyWrcGETKNHzLh4fsQP19pF:
						CQtNwXGVAJ2y5nBY = PAztbuyYo4Kvd.findall('\d\d\d+',ZiG5TofQhEbP6psHkgSvWuC14FK3U,PAztbuyYo4Kvd.DOTALL)
						if CQtNwXGVAJ2y5nBY:
							tNRplaqHJ7XfDsT103AugCZ9 = '____'+CQtNwXGVAJ2y5nBY[0]
							break
					kqdyWrcGETKNHzLh4fsQP19pF = PAztbuyYo4Kvd.findall('<td>(.*?)</td>.*?href="(http.*?)"',tUjkcN0T31uia5FA2n,PAztbuyYo4Kvd.DOTALL)
					if kqdyWrcGETKNHzLh4fsQP19pF:
						for d9WVqQifocSGHEDv7u,Yye6RJGs14XhW in kqdyWrcGETKNHzLh4fsQP19pF:
							Yye6RJGs14XhW = Yye6RJGs14XhW+'?named='+d9WVqQifocSGHEDv7u+'__download'+tNRplaqHJ7XfDsT103AugCZ9
							ce9zAaVFswSq6lLr82DfQyotGW.append(Yye6RJGs14XhW)
					else:
						kqdyWrcGETKNHzLh4fsQP19pF = PAztbuyYo4Kvd.findall('href="(.*?http.*?)".*?name">(.*?)<',tUjkcN0T31uia5FA2n,PAztbuyYo4Kvd.DOTALL)
						for Yye6RJGs14XhW,d9WVqQifocSGHEDv7u in kqdyWrcGETKNHzLh4fsQP19pF:
							Yye6RJGs14XhW = Yye6RJGs14XhW.strip(hSXlxL9iB05c)+'?named='+d9WVqQifocSGHEDv7u+'__download'+tNRplaqHJ7XfDsT103AugCZ9
							ce9zAaVFswSq6lLr82DfQyotGW.append(Yye6RJGs14XhW)
			else:
				kqdyWrcGETKNHzLh4fsQP19pF = PAztbuyYo4Kvd.findall('href="(.*?)".*?>(\w+)<',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL)
				for Yye6RJGs14XhW,d9WVqQifocSGHEDv7u in kqdyWrcGETKNHzLh4fsQP19pF:
					Yye6RJGs14XhW = Yye6RJGs14XhW.strip(hSXlxL9iB05c)+'?named='+d9WVqQifocSGHEDv7u+'__download'
					ce9zAaVFswSq6lLr82DfQyotGW.append(Yye6RJGs14XhW)
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(ce9zAaVFswSq6lLr82DfQyotGW,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	search = search.replace(hSXlxL9iB05c,'+')
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',GiqvpBF9xLEdHDr37byJSngeCQ+'/alz',nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,True,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ARBLIONZ-SEARCH-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content.encode(YWEQ3Cf8RevpD0m7NjF1)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('chevron-select(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if showDialogs and zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('value="(.*?)".*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		XXeuDGkQS9oz,h2hgXPkjUFZidvzMQxaY = [],[]
		for kvfOU7Tpz958QBqnIlaAePLys,title in items:
			XXeuDGkQS9oz.append(kvfOU7Tpz958QBqnIlaAePLys)
			h2hgXPkjUFZidvzMQxaY.append(title)
		iP7AUR41exzlKyZIf9Mt3u = ccAMwn7hflDev8Kd3aqP('اختر الفلتر المناسب:', h2hgXPkjUFZidvzMQxaY)
		if iP7AUR41exzlKyZIf9Mt3u == -1 : return
		kvfOU7Tpz958QBqnIlaAePLys = XXeuDGkQS9oz[iP7AUR41exzlKyZIf9Mt3u]
	else: kvfOU7Tpz958QBqnIlaAePLys = nA5dhMRg6ENzsB0l1GwvH7aIr2
	url = GiqvpBF9xLEdHDr37byJSngeCQ + '/search?s='+search+'&category='+kvfOU7Tpz958QBqnIlaAePLys+'&page=1'
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
	return
def NNihMcqGKQEvLz6l(url,filter):
	J8bDm67uSQ53EOUiltdTPRhcgNKY = ['category','release-year','genre','Quality']
	if '?' in url: url = url.split('/getposts?')[0]
	type,filter = filter.split('___',1)
	if filter==nA5dhMRg6ENzsB0l1GwvH7aIr2: vvXcyZhkfV,guikd57yRSCMsNmlUqFHWAYL = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	else: vvXcyZhkfV,guikd57yRSCMsNmlUqFHWAYL = filter.split('___')
	if type=='CATEGORIES':
		if J8bDm67uSQ53EOUiltdTPRhcgNKY[0]+'=' not in vvXcyZhkfV: kvfOU7Tpz958QBqnIlaAePLys = J8bDm67uSQ53EOUiltdTPRhcgNKY[0]
		for q3kZpRe28O0s1NaCXQ9SMuGKin in range(len(J8bDm67uSQ53EOUiltdTPRhcgNKY[0:-1])):
			if J8bDm67uSQ53EOUiltdTPRhcgNKY[q3kZpRe28O0s1NaCXQ9SMuGKin]+'=' in vvXcyZhkfV: kvfOU7Tpz958QBqnIlaAePLys = J8bDm67uSQ53EOUiltdTPRhcgNKY[q3kZpRe28O0s1NaCXQ9SMuGKin+1]
		FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+kvfOU7Tpz958QBqnIlaAePLys+'=0'
		QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+kvfOU7Tpz958QBqnIlaAePLys+'=0'
		TB6HLPpacsK8f034jvYx7SNgFd = FqCItdu32L9hNwcEXWoges4R68KS.strip('&')+'___'+QA6C8r4lEdhemfJPRc.strip('&')
		OQmDdTI7hU4Lv3BfexPVKgRF8YN = EdpkojMzLm6b3ZSVcXwi0CPRIH(guikd57yRSCMsNmlUqFHWAYL,'modified_filters')
		KteRnFMjHpBPqNf8 = url+'/getposts?'+OQmDdTI7hU4Lv3BfexPVKgRF8YN
	elif type=='FILTERS':
		iEa2qGQctFxX = EdpkojMzLm6b3ZSVcXwi0CPRIH(vvXcyZhkfV,'modified_values')
		iEa2qGQctFxX = pvOytL0nF7JY6flXTxAcHbQeNahu3(iEa2qGQctFxX)
		if guikd57yRSCMsNmlUqFHWAYL!=nA5dhMRg6ENzsB0l1GwvH7aIr2: guikd57yRSCMsNmlUqFHWAYL = EdpkojMzLm6b3ZSVcXwi0CPRIH(guikd57yRSCMsNmlUqFHWAYL,'modified_filters')
		if guikd57yRSCMsNmlUqFHWAYL==nA5dhMRg6ENzsB0l1GwvH7aIr2: KteRnFMjHpBPqNf8 = url
		else: KteRnFMjHpBPqNf8 = url+'/getposts?'+guikd57yRSCMsNmlUqFHWAYL
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'أظهار قائمة الفيديو التي تم اختيارها ',KteRnFMjHpBPqNf8,201)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+' [[   '+iEa2qGQctFxX+'   ]]',KteRnFMjHpBPqNf8,201)
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,url+'/alz',nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ARBLIONZ-FILTERS_MENU-1st')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('AjaxFilteringData(.*?)FilterWord',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	AAkSjd9agcy = PAztbuyYo4Kvd.findall('</i>(.*?)<.*?data-forTax="(.*?)"(.*?)<h2',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	dict = {}
	for name,xWwIXcK0L61EBgtn7smr,WWU7QJP2tyTRLIfDh0csxbkvX in AAkSjd9agcy:
		name = name.replace('اختيار ',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		name = name.replace('سنة الإنتاج','السنة')
		items = PAztbuyYo4Kvd.findall('value="(.*?)".*?</div>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if '=' not in KteRnFMjHpBPqNf8: KteRnFMjHpBPqNf8 = url
		if type=='CATEGORIES':
			if kvfOU7Tpz958QBqnIlaAePLys!=xWwIXcK0L61EBgtn7smr: continue
			elif len(items)<=1:
				if xWwIXcK0L61EBgtn7smr==J8bDm67uSQ53EOUiltdTPRhcgNKY[-1]: LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(KteRnFMjHpBPqNf8)
				else: NNihMcqGKQEvLz6l(KteRnFMjHpBPqNf8,'CATEGORIES___'+TB6HLPpacsK8f034jvYx7SNgFd)
				return
			else:
				if xWwIXcK0L61EBgtn7smr==J8bDm67uSQ53EOUiltdTPRhcgNKY[-1]: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع ',KteRnFMjHpBPqNf8,201)
				else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع ',KteRnFMjHpBPqNf8,205,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,TB6HLPpacsK8f034jvYx7SNgFd)
		elif type=='FILTERS':
			FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+xWwIXcK0L61EBgtn7smr+'=0'
			QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+xWwIXcK0L61EBgtn7smr+'=0'
			TB6HLPpacsK8f034jvYx7SNgFd = FqCItdu32L9hNwcEXWoges4R68KS+'___'+QA6C8r4lEdhemfJPRc
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع :'+name,KteRnFMjHpBPqNf8,204,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,TB6HLPpacsK8f034jvYx7SNgFd)
		dict[xWwIXcK0L61EBgtn7smr] = {}
		for value,DOT0LXwgoHYkFBC4MbxN53 in items:
			DOT0LXwgoHYkFBC4MbxN53 = DOT0LXwgoHYkFBC4MbxN53.replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2)
			if DOT0LXwgoHYkFBC4MbxN53 in SAsGubf1jW2Q3p: continue
			dict[xWwIXcK0L61EBgtn7smr][value] = DOT0LXwgoHYkFBC4MbxN53
			FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+xWwIXcK0L61EBgtn7smr+'='+DOT0LXwgoHYkFBC4MbxN53
			QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+xWwIXcK0L61EBgtn7smr+'='+value
			b97AdvPkWGEBe3ayj1Jhmcq2LVxr = FqCItdu32L9hNwcEXWoges4R68KS+'___'+QA6C8r4lEdhemfJPRc
			title = DOT0LXwgoHYkFBC4MbxN53+' :'#+dict[xWwIXcK0L61EBgtn7smr]['0']
			title = DOT0LXwgoHYkFBC4MbxN53+' :'+name
			if type=='FILTERS': TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,204,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,b97AdvPkWGEBe3ayj1Jhmcq2LVxr)
			elif type=='CATEGORIES' and J8bDm67uSQ53EOUiltdTPRhcgNKY[-2]+'=' in vvXcyZhkfV:
				OQmDdTI7hU4Lv3BfexPVKgRF8YN = EdpkojMzLm6b3ZSVcXwi0CPRIH(QA6C8r4lEdhemfJPRc,'modified_filters')
				w7Ol6FnokgJDSsIt = url+'/getposts?'+OQmDdTI7hU4Lv3BfexPVKgRF8YN
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,w7Ol6FnokgJDSsIt,201)
			else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,205,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,b97AdvPkWGEBe3ayj1Jhmcq2LVxr)
	return
def EdpkojMzLm6b3ZSVcXwi0CPRIH(tgsLX2uACmFhVznejRy6O,mode):
	tgsLX2uACmFhVznejRy6O = tgsLX2uACmFhVznejRy6O.replace('=&','=0&')
	tgsLX2uACmFhVznejRy6O = tgsLX2uACmFhVznejRy6O.strip('&')
	bpoRYqt38j = {}
	if '=' in tgsLX2uACmFhVznejRy6O:
		items = tgsLX2uACmFhVznejRy6O.split('&')
		for CQtNwXGVAJ2y5nBY in items:
			eehzynNs85aTHrgCUmFc3DBO12,value = CQtNwXGVAJ2y5nBY.split('=')
			bpoRYqt38j[eehzynNs85aTHrgCUmFc3DBO12] = value
	H5ROYNwvQFkBiVElThr = nA5dhMRg6ENzsB0l1GwvH7aIr2
	F45fPJwzqEWNISAml = ['category','release-year','genre','Quality']
	for key in F45fPJwzqEWNISAml:
		if key in list(bpoRYqt38j.keys()): value = bpoRYqt38j[key]
		else: value = '0'
		if '%' not in value: value = kGE6zoKSan54W(value)
		if mode=='modified_values' and value!='0': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+' + '+value
		elif mode=='modified_filters' and value!='0': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+'&'+key+'='+value
		elif mode=='all': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+'&'+key+'='+value
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.strip(' + ')
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.strip('&')
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.replace('=0','=')
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.replace('Quality','quality')
	return H5ROYNwvQFkBiVElThr
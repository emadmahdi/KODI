# -*- coding: utf-8 -*-
import sys as kCNHMOym1luTnJ0
MigYEN1cxduFB2lpk5 = kCNHMOym1luTnJ0.version_info [0] == 2
xJ3XdNcV5IujAkoGh = 2048
aE71QiuHI95zfPRBUsntedWZJ2bl = 7
def vR1b8iCLa9Qy2Sw5OYAlWXNhZp37 (AGxE4RIvuC6):
	global peWEVn47JRXo916j
	Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky = ord (AGxE4RIvuC6 [-1])
	FXUjnSw308z = AGxE4RIvuC6 [:-1]
	f81LoVwXMpQkvdKcmPyj6NzBlt = Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky % len (FXUjnSw308z)
	qyKv5nBTxgkQSlJ0aNP1CUmpjYLZ = FXUjnSw308z [:f81LoVwXMpQkvdKcmPyj6NzBlt] + FXUjnSw308z [f81LoVwXMpQkvdKcmPyj6NzBlt:]
	if MigYEN1cxduFB2lpk5:
		H0yFJ5LDCGYpIM1BViZKTSgv3jXr = unicode () .join ([unichr (ord (Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286) - xJ3XdNcV5IujAkoGh - (MfwWyztdYVXURgPqLrITku3CxF1 + Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky) % aE71QiuHI95zfPRBUsntedWZJ2bl) for MfwWyztdYVXURgPqLrITku3CxF1, Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286 in enumerate (qyKv5nBTxgkQSlJ0aNP1CUmpjYLZ)])
	else:
		H0yFJ5LDCGYpIM1BViZKTSgv3jXr = str () .join ([chr (ord (Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286) - xJ3XdNcV5IujAkoGh - (MfwWyztdYVXURgPqLrITku3CxF1 + Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky) % aE71QiuHI95zfPRBUsntedWZJ2bl) for MfwWyztdYVXURgPqLrITku3CxF1, Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286 in enumerate (qyKv5nBTxgkQSlJ0aNP1CUmpjYLZ)])
	return eval (H0yFJ5LDCGYpIM1BViZKTSgv3jXr)
Yj1msqVeivESfrCupRy9b7WacBd,XEcWOIwkZKubV7vQ,Pj9YaUq1ibJ=vR1b8iCLa9Qy2Sw5OYAlWXNhZp37,vR1b8iCLa9Qy2Sw5OYAlWXNhZp37,vR1b8iCLa9Qy2Sw5OYAlWXNhZp37
HD7MQqXd2gS,yPE2t1Co4YQDfsIecdxu0Gklq6AvO,bqCDnV7Bs5XgRvuKLNAa1Uz=Pj9YaUq1ibJ,XEcWOIwkZKubV7vQ,Yj1msqVeivESfrCupRy9b7WacBd
YIsyNBocg6fV3wEWPSu9GtvHxLOqDi,VVstJA9bfOqunLF0oaSgWUKHDdYNz,nfNTgkiWdUq=bqCDnV7Bs5XgRvuKLNAa1Uz,yPE2t1Co4YQDfsIecdxu0Gklq6AvO,HD7MQqXd2gS
FVxoQ2J5Mfv3Zj6sy9uhOS,n8BrpFLyaMAC1vP0bOHgwxEzeGRV,UUobzy0xZLaVScIt7=nfNTgkiWdUq,VVstJA9bfOqunLF0oaSgWUKHDdYNz,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi
JvQd6LMoBX4hiy1C,ZjELJ9VrUT07R8Hn4FuSDcf,pxt6wJ8ScYMWCivoO=UUobzy0xZLaVScIt7,n8BrpFLyaMAC1vP0bOHgwxEzeGRV,FVxoQ2J5Mfv3Zj6sy9uhOS
lw2snZ9J0uhLoxypqa,LJqSQvuhf7aMmnVjy23FbZBckKzx9l,gmPI7hVEM8nD=pxt6wJ8ScYMWCivoO,ZjELJ9VrUT07R8Hn4FuSDcf,JvQd6LMoBX4hiy1C
w0ivtSjV2sZDQoT1OEugIla7R6AC5M,rCmGE4YIDaZA,vzqjsVHSBlMpxC=gmPI7hVEM8nD,LJqSQvuhf7aMmnVjy23FbZBckKzx9l,lw2snZ9J0uhLoxypqa
xwIUQfiE7rmvYzH,ldIfvn6asURQ9toi85EhqAXW3,bb1fgjsAq4N2xYwnoh39lm=vzqjsVHSBlMpxC,rCmGE4YIDaZA,w0ivtSjV2sZDQoT1OEugIla7R6AC5M
AJHaiQq3PRd5cphzGuELnVg9X,jil8vRpBsENVYyPmDd,PPxYugzLZwHX23yiK=bb1fgjsAq4N2xYwnoh39lm,ldIfvn6asURQ9toi85EhqAXW3,xwIUQfiE7rmvYzH
baBcNd81eH5ry2Olp6Mj43,Qy6wlfLoOpg1,mRanX1HZupfSQVB2gsDGUO=PPxYugzLZwHX23yiK,jil8vRpBsENVYyPmDd,AJHaiQq3PRd5cphzGuELnVg9X
bDxWcjmaSgFeRKrfpJvyA4zThi,DFx6E0uON7Jm8,zhE5I4xHinX0UoVZMNwlkPrR=mRanX1HZupfSQVB2gsDGUO,Qy6wlfLoOpg1,baBcNd81eH5ry2Olp6Mj43
IpFcwrWNgefMym3qta0hYQAzOdE = Pj9YaUq1ibJ(u"࠳ਓ")
UnOIK1WBbw2 = bb1fgjsAq4N2xYwnoh39lm(u"࠵ਔ")
udq5tP0hwifHQCGYELDbOUI = UnOIK1WBbw2+UnOIK1WBbw2
AH0zdvBqibaXY = udq5tP0hwifHQCGYELDbOUI+UnOIK1WBbw2
tpMX1Bgs0bzv8OEafyW = AH0zdvBqibaXY+UnOIK1WBbw2
eCaWsMty53QI9Y = tpMX1Bgs0bzv8OEafyW+UnOIK1WBbw2
nA5dhMRg6ENzsB0l1GwvH7aIr2 = LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠩࠪए")
hSXlxL9iB05c = jil8vRpBsENVYyPmDd(u"ࠪࠤࠬऐ")
BSiDxUPsdHkz27VMop51uf6c3 = hSXlxL9iB05c*udq5tP0hwifHQCGYELDbOUI
PwYGfc4gTjiyRlsHn1OE = hSXlxL9iB05c*AH0zdvBqibaXY
cqsuhi1JE7nNIfbPYQSpFgeGr = hSXlxL9iB05c*tpMX1Bgs0bzv8OEafyW
YWylfpKSRb = None
S5MWhgtZ37Xw = LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࡕࡴࡸࡩ਴")
FFKncZx5pDTwdiJRYhMgQSNL = lw2snZ9J0uhLoxypqa(u"ࡈࡤࡰࡸ࡫ਵ")
v8gG4ThP7CAMWEm6fp = lw2snZ9J0uhLoxypqa(u"ࠫࡹࡸࡵࡦࠩऑ")
oZqKcvlJx1pTLN2ske5f0PtVrw = vzqjsVHSBlMpxC(u"ࠬ࡬ࡡ࡭ࡵࡨࠫऒ")
jKqWB2QMYJO8vTh0o6CVIyamw = JvQd6LMoBX4hiy1C(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ओ")
GGlX1Dsd3bJKMFw = JvQd6LMoBX4hiy1C(u"ࠧࡥࡧࡩࡥࡺࡲࡴࠨऔ")
bbTCMJwEx8nhN4X = ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡈ࠵࠳ࡈࡠࠫक")
lSWzOYmN08 = bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬख")
h7h2iacotq5wjsvEfyu3IBgTO = ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋ࠹࠳ࡆ࠶࠶࠷ࡢ࠭ग")
bwfNZXGCvAdcBlDqLJpT2Hnj = rCmGE4YIDaZA(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌ࠱ࡇ࠷࠴ࡊࡋࡣࠧघ")
BTVqD15pSrOZMIlWnLgPGfs9A7a = Pj9YaUq1ibJ(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊࡋࡌ࡝ࠨङ")
NwROdSj3nsA = AJHaiQq3PRd5cphzGuELnVg9X(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨच")
YWEQ3Cf8RevpD0m7NjF1 = JvQd6LMoBX4hiy1C(u"ࠧࡶࡶࡩ࠼ࠬछ")
gqsRPaf8EzGDeKx7WdZkuX0YrV1 = yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠨࡐࡒࡘࡎࡉࡅࠨज")
hhOuTCDWIJe7SQPrcKVgF8ZN1qYEz = baBcNd81eH5ry2Olp6Mj43(u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨझ")
QsPKdFuz4JwyXvbiI2UcYj59f8Llq = AJHaiQq3PRd5cphzGuELnVg9X(u"ࠪࡉࡗࡘࡏࡓࠩञ")
ybrna7mLOFVDUtRseQ3Tkf2zXS = PPxYugzLZwHX23yiK(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩट")
CXtugbqhV3 = xwIUQfiE7rmvYzH(u"ࠬࡢ࡮ࠨठ")
sSBzjZdcbQraNx = YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠭࡜ࡳࠩड")
OksCHeoL5SG = w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪढ")
G8VAS3qP9esn72muMZ5HRb1QJF = w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠵࠴࠲࠶ਕ")
JLRlN4Z7cpB9W = zhE5I4xHinX0UoVZMNwlkPrR(u"࠷࠵ਖ")
YwpL8zKdjSA = baBcNd81eH5ry2Olp6Mj43(u"࠳࠱ਗ")
yybK2WJnijg64cmvFz5wSXOqa1QIrE = vzqjsVHSBlMpxC(u"࠲࠲ਘ")
RDYlfT47cFGUrVMqIWB = FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠳࠵࠴ਙ")
TCvP3Y9u5jJlEqG2 = [
						 w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡉࡓࡊ࡟ࡂࡐࡄࡐ࡞࡚ࡉࡄࡕࡢࡉ࡛ࡋࡎࡕࡕ࠰࠵ࡸࡺࠧण")
						,LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡉ࡝࡚ࡒࡂࡅࡗࡣࡒ࠹ࡕ࠹࠯࠴ࡷࡹ࠭त")
						,HD7MQqXd2gS(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡇࡎࡅࡑࡐࡣ࡚࡙ࡅࡓࡃࡊࡉࡓ࡚࠭࠲ࡵࡷࠫथ")
						,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡕࡡࡓࡖࡔ࡞ࡉࡆࡕࡢࡐࡎ࡙ࡔ࠮࠳ࡶࡸࠬद")
						,nfNTgkiWdUq(u"ࠬࡏࡐࡕࡘ࠰ࡇࡍࡋࡃࡌࡡࡄࡇࡈࡕࡕࡏࡖ࠰࠵ࡸࡺࠧध")
						,yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡒࡐࡔࡉࡁࡕࡋࡒࡒ࠲࠷ࡳࡵࠩन")
						,gmPI7hVEM8nD(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠲ࡵࡷࠫऩ")
						,Yj1msqVeivESfrCupRy9b7WacBd(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠵ࡵࡨࠬप")
						,FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊࡇࡄࡠࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍ࠯࠴ࡷࡹ࠭फ")
						,JvQd6LMoBX4hiy1C(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡇࡐࡑࡊࡐࡊ࡛ࡓࡆࡔࡆࡓࡓ࡚ࡅࡏࡖ࠰࠵ࡸࡺࠧब")
						,AJHaiQq3PRd5cphzGuELnVg9X(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠴ࡴࡧࠫभ")
						,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠷ࡷ࡬ࠬम")
						,bb1fgjsAq4N2xYwnoh39lm(u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬय")
						,gmPI7hVEM8nD(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠷ࡳࡵࠩर")
						,Pj9YaUq1ibJ(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝࡙ࡈࡂࡔࡌࡒࡌ࠳࠲࡯ࡦࠪऱ")
						]
DYbV1egIdWwQN840zoLsrnhmB7 = TCvP3Y9u5jJlEqG2+[
				 pxt6wJ8ScYMWCivoO(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡔࡗࡕࡘ࡚ࡡࡗࡉࡘ࡚࠭࠲ࡵࡷࠫल")
				,Yj1msqVeivESfrCupRy9b7WacBd(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡎࡔࡕࡒࡖࡔࡗࡕࡘࡊࡇࡖ࠱࠶ࡹࡴࠨळ")
				,ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞ࡉࡆࡕ࠰࠵ࡸࡺࠧऴ")
				,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘࡊࡇࡖ࠱࠷ࡴࡤࠨव")
				,bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙࡛ࡗࡓ࠲࠷ࡳࡵࠩश")
				,nfNTgkiWdUq(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚࡜ࡘࡔ࠳࠲࡯ࡦࠪष")
				,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡏࡕࡘࡏ࡙࡛ࡆࡓࡒ࠳࠱ࡴࡶࠪस")
				,bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡐࡖࡒࡐ࡚࡜ࡇࡔࡓ࠭࠳ࡰࡧࠫह")
				,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠵ࡵࡨࠬऺ")
				,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡉࡈࡆࡅࡎࡣࡍ࡚ࡔࡑࡕࡢࡔࡗࡕࡘࡊࡇࡖ࠱࠶ࡹࡴࠨऻ")
				,vzqjsVHSBlMpxC(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡉࡖࡗࡔࡘࡥࡔࡆࡕࡗ࠱࠶ࡹࡴࠨ़")
				,bb1fgjsAq4N2xYwnoh39lm(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡖࡈࡗ࡙ࡥࡁࡍࡎࡢ࡛ࡊࡈࡓࡊࡖࡈࡗ࠲࠷ࡳࡵࠩऽ")
				,pxt6wJ8ScYMWCivoO(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡗࡉࡘ࡚࡟ࡂࡎࡏࡣ࡜ࡋࡂࡔࡋࡗࡉࡘ࠳࠲࡯ࡦࠪा")
				,PPxYugzLZwHX23yiK(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰࡙ࡘࡇࡇࡆࡡࡕࡉࡕࡕࡒࡕ࠯࠴ࡷࡹ࠭ि")
				,gmPI7hVEM8nD(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠳࠱ࡴࡶࠪी")
				,DFx6E0uON7Jm8(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡖࡆࡔࡖࡓࡤ࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅ࠮࠳ࡶࡸࠬु")
				]
JFvYcXxr9hUDI0NkWs = [
						 VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭ू")
						,LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠶ࡳࡪࠧृ")
						,Pj9YaUq1ibJ(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐ࡙ࡑ࡚ࡉࡠ࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧॄ")
						]
EYcbkTrLd8MqHSXzxFGft = eCaWsMty53QI9Y
c0Qs8Db7KdxGzt = [w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠧึใิࠫॅ"),UUobzy0xZLaVScIt7(u"ࠨล๋่ࠬॆ"),nfNTgkiWdUq(u"ࠩฮห๋๐ࠧे"),rCmGE4YIDaZA(u"ࠪฯฬ๊หࠨै"),AJHaiQq3PRd5cphzGuELnVg9X(u"ࠫึอศฺࠩॉ"),UUobzy0xZLaVScIt7(u"ࠬิวๆีࠪॊ"),bb1fgjsAq4N2xYwnoh39lm(u"࠭ำศัึࠫो"),PPxYugzLZwHX23yiK(u"ࠧิษห฽ࠬौ"),PPxYugzLZwHX23yiK(u"ࠨอส्้๋࠭"),bb1fgjsAq4N2xYwnoh39lm(u"ࠩอหุ฿ࠧॎ"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠪ฽ฬฺัࠨॏ")]
EqjeBirSFZ = UUobzy0xZLaVScIt7(u"࠹࠴ਚ")
QhOXE7ztloReYp0nMVAIZb = Qy6wlfLoOpg1(u"࠺࠵ਛ")*EqjeBirSFZ
rzCHwYijmSR4JW = ldIfvn6asURQ9toi85EhqAXW3(u"࠷࠺ਜ")*QhOXE7ztloReYp0nMVAIZb
YEJmrSWajKig3LDvy79l = xwIUQfiE7rmvYzH(u"࠹࠰ਝ")*rzCHwYijmSR4JW
yy6RomT9bQhJf = IpFcwrWNgefMym3qta0hYQAzOdE
cbpdEaUM8rKSQvzuqiJyXwW4 = FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠳࠱ਞ")*EqjeBirSFZ
lPsYQwWdLO520ZHcFV8n1x = udq5tP0hwifHQCGYELDbOUI*QhOXE7ztloReYp0nMVAIZb
QdwW2s0iEp56qMmvCbOeLxBRU = pxt6wJ8ScYMWCivoO(u"࠲࠸ਟ")*QhOXE7ztloReYp0nMVAIZb
OkCUfhKTs9DZbcgnw3roPGBvlqt = AH0zdvBqibaXY*rzCHwYijmSR4JW
KcwozFY2DsR3jSBO = rCmGE4YIDaZA(u"࠵࠳ਠ")*rzCHwYijmSR4JW
l7ltVNxrbPimpXJDh = XEcWOIwkZKubV7vQ(u"࠴࠶ਡ")*YEJmrSWajKig3LDvy79l
KZxiAeszDGHJT9MmNa6WoRF05 = QhOXE7ztloReYp0nMVAIZb
rm1yICzMi5Lj8734ulwAS = [ldIfvn6asURQ9toi85EhqAXW3(u"ࠫࡇࡕࡋࡓࡃࠪॐ"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠬࡖࡁࡏࡇࡗࠫ॑"),DFx6E0uON7Jm8(u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖ॒ࠫ"),UUobzy0xZLaVScIt7(u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪ॓"),JvQd6LMoBX4hiy1C(u"ࠨࡋࡉࡍࡑࡓࠧ॔"),ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠩࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࠨॕ"),mRanX1HZupfSQVB2gsDGUO(u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࠪॖ")]
rm1yICzMi5Lj8734ulwAS += [yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠫ࡞࡚ࡂࡠࡅࡋࡅࡓࡔࡅࡍࡕࠪॗ"),bb1fgjsAq4N2xYwnoh39lm(u"ࠬࡇࡋࡐࡃࡐࠫक़"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠭ࡁࡌ࡙ࡄࡑࠬख़"),xwIUQfiE7rmvYzH(u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇࠩग़"),bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪज़")]
iYOV4hTaDEbZCf67MQPsGWgto = [DFx6E0uON7Jm8(u"ࠩࡏࡅࡗࡕ࡚ࡂࠩड़"),nfNTgkiWdUq(u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭ढ़"),mRanX1HZupfSQVB2gsDGUO(u"࡙ࠫ࡜ࡆࡖࡐࠪफ़"),jil8vRpBsENVYyPmDd(u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭य़"),rCmGE4YIDaZA(u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧॠ"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫॡ"),zhE5I4xHinX0UoVZMNwlkPrR(u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪॢ")]
iYOV4hTaDEbZCf67MQPsGWgto += [baBcNd81eH5ry2Olp6Mj43(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫॣ"),nfNTgkiWdUq(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ।"),pxt6wJ8ScYMWCivoO(u"ࠫࡘࡎࡏࡇࡊࡄࠫ॥"),gmPI7hVEM8nD(u"ࠬ࡝ࡅࡄࡋࡐࡅ࠶࠭०"),Yj1msqVeivESfrCupRy9b7WacBd(u"࠭ࡗࡆࡅࡌࡑࡆ࠸ࠧ१")]
F8MV3veKyr7HIuqasbYQc = [Yj1msqVeivESfrCupRy9b7WacBd(u"ࠧࡕࡋࡎࡅࡆ࡚ࠧ२"),lw2snZ9J0uhLoxypqa(u"ࠨࡃ࡜ࡐࡔࡒࠧ३"),xwIUQfiE7rmvYzH(u"ࠩࡉࡓࡘ࡚ࡁࠨ४"),Yj1msqVeivESfrCupRy9b7WacBd(u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫ५"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠫ࡞ࡇࡑࡐࡖࠪ६"),rCmGE4YIDaZA(u"࡙ࠬࡈࡂࡄࡄࡏࡆ࡚࡙ࠨ७"),Pj9YaUq1ibJ(u"࠭ࡖࡂࡔࡅࡓࡓ࠭८"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠧࡃࡔࡖࡘࡊࡐࠧ९")]
F8MV3veKyr7HIuqasbYQc += [YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠨࡍࡌࡖࡒࡇࡌࡌࠩ॰"),FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠩࡄࡒࡎࡓࡅ࡛ࡋࡇࠫॱ"),AJHaiQq3PRd5cphzGuELnVg9X(u"ࠪࡊࡆࡘࡅࡔࡍࡒࠫॲ"),lw2snZ9J0uhLoxypqa(u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭ॳ"),xwIUQfiE7rmvYzH(u"ࠬࡇࡌࡎࡕࡗࡆࡆ࠭ॴ"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠭ࡓࡉࡑࡒࡊࡓࡋࡔࠨॵ"),Pj9YaUq1ibJ(u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨॶ")]
F8MV3veKyr7HIuqasbYQc += [xwIUQfiE7rmvYzH(u"ࠨࡅࡌࡑࡆࡌࡒࡆࡇࠪॷ"),n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫॸ"),HD7MQqXd2gS(u"ࠪࡉࡑࡏࡆࡗࡋࡇࡉࡔ࠭ॹ"),XEcWOIwkZKubV7vQ(u"ࠫࡋ࡛ࡎࡐࡐࡗ࡚ࠬॺ"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨॻ"),HD7MQqXd2gS(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧॼ"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩॽ")]
F8MV3veKyr7HIuqasbYQc += [JvQd6LMoBX4hiy1C(u"ࠨࡃࡎ࡛ࡆࡓࡔࡖࡄࡈࠫॾ"),Qy6wlfLoOpg1(u"ࠩࡐࡅࡘࡇࡖࡊࡆࡈࡓࠬॿ"),HD7MQqXd2gS(u"ࠪࡈࡗࡇࡍࡂࡅࡄࡊࡊ࠭ঀ"),jil8vRpBsENVYyPmDd(u"ࠫࡋ࡛ࡓࡉࡃࡕࡘ࡛࠭ঁ"),Yj1msqVeivESfrCupRy9b7WacBd(u"ࠬࡉࡉࡎࡃ࡚ࡆࡆ࡙ࠧং"),pxt6wJ8ScYMWCivoO(u"࠭ࡁࡉ࡙ࡄࡏࠬঃ"),FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳ࠩ঄"),UUobzy0xZLaVScIt7(u"ࠨࡘࡌࡈࡊࡕࡎࡔࡃࡈࡑࠬঅ")]
F8MV3veKyr7HIuqasbYQc += [yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫআ"),JvQd6LMoBX4hiy1C(u"ࠪࡗࡊࡘࡉࡆࡕࡗࡍࡒࡋࠧই"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠫࡋ࡛ࡓࡉࡃࡕ࡚ࡎࡊࡅࡐࠩঈ"),n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠬࡉࡉࡎࡃ࠷ࡔࠬউ"),lw2snZ9J0uhLoxypqa(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨঊ"),FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠴ࠪঋ"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴ࠪঌ"),zhE5I4xHinX0UoVZMNwlkPrR(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫ঍")]
ZSaLRonHF3rWQCAxgG75PY6sOKhUB8 = [vzqjsVHSBlMpxC(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ঎"),bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲࡜ࡉࡅࡇࡒࡗࠬএ"),PPxYugzLZwHX23yiK(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩঐ"),gmPI7hVEM8nD(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ঑")]
ZSaLRonHF3rWQCAxgG75PY6sOKhUB8 += [zhE5I4xHinX0UoVZMNwlkPrR(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬ঒"),Pj9YaUq1ibJ(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡖࡊࡆࡈࡓࡘ࠭ও"),XEcWOIwkZKubV7vQ(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪঔ"),gmPI7hVEM8nD(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪক"),JvQd6LMoBX4hiy1C(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡏࡍ࡛ࡋࡓࠨখ"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡌࡆ࡙ࡈࡕࡃࡊࡗࠬগ")]
qW8vOGrfE2J = [YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬঘ")]
vvXD0IiPxt3dOoR7YLmuQsgG  = [UUobzy0xZLaVScIt7(u"ࠧࡂࡍ࡚ࡅࡒ࠭ঙ"),nfNTgkiWdUq(u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪচ"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠩࡅࡓࡐࡘࡁࠨছ"),xwIUQfiE7rmvYzH(u"ࠪࡅࡐࡕࡁࡎࠩজ"),JvQd6LMoBX4hiy1C(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭ঝ"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭ঞ"),ldIfvn6asURQ9toi85EhqAXW3(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨট"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠧࡄࡋࡐࡅࡋࡘࡅࡆࠩঠ"),baBcNd81eH5ry2Olp6Mj43(u"ࠨࡅࡌࡑࡆ࠺ࡐࠨড")]
vvXD0IiPxt3dOoR7YLmuQsgG += [YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫঢ"),nfNTgkiWdUq(u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭ণ"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬত"),Yj1msqVeivESfrCupRy9b7WacBd(u"ࠬ࡝ࡅࡄࡋࡐࡅ࠶࠭থ"),JvQd6LMoBX4hiy1C(u"࠭ࡗࡆࡅࡌࡑࡆ࠸ࠧদ"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫধ"),Qy6wlfLoOpg1(u"ࠨࡈࡒࡗ࡙ࡇࠧন"),jil8vRpBsENVYyPmDd(u"ࠩࡄࡌ࡜ࡇࡋࠨ঩"),FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠪࡗࡍࡕࡏࡇࡐࡈࡘࠬপ")]
vvXD0IiPxt3dOoR7YLmuQsgG += [mRanX1HZupfSQVB2gsDGUO(u"ࠫࡘࡋࡒࡊࡇࡖࡘࡎࡓࡅࠨফ"),gmPI7hVEM8nD(u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨব"),bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩভ"),xwIUQfiE7rmvYzH(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩম"),mRanX1HZupfSQVB2gsDGUO(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴ࠪয"),bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫর"),zhE5I4xHinX0UoVZMNwlkPrR(u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ঱"),jil8vRpBsENVYyPmDd(u"ࠫࡆࡑࡗࡂࡏࡗ࡙ࡇࡋࠧল")]
vvXD0IiPxt3dOoR7YLmuQsgG += [ldIfvn6asURQ9toi85EhqAXW3(u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭঳"),rCmGE4YIDaZA(u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ঴"),bb1fgjsAq4N2xYwnoh39lm(u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩ঵"),Yj1msqVeivESfrCupRy9b7WacBd(u"ࠨࡖ࡙ࡊ࡚ࡔࠧশ"),gmPI7hVEM8nD(u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫষ"),rCmGE4YIDaZA(u"ࠪࡗࡍࡕࡆࡉࡃࠪস"),gmPI7hVEM8nD(u"࡛ࠫࡇࡒࡃࡑࡑࠫহ"),FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠬࡇࡌࡎࡕࡗࡆࡆ࠭঺"),Qy6wlfLoOpg1(u"࠭ࡆࡂࡔࡈࡗࡐࡕࠧ঻")]
vvXD0IiPxt3dOoR7YLmuQsgG += [HD7MQqXd2gS(u"ࠧࡃࡔࡖࡘࡊࡐ়ࠧ"),XEcWOIwkZKubV7vQ(u"ࠨ࡛ࡄࡕࡔ࡚ࠧঽ"),pxt6wJ8ScYMWCivoO(u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪা"),vzqjsVHSBlMpxC(u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫি"),pxt6wJ8ScYMWCivoO(u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔࠩী"),FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧু"),pxt6wJ8ScYMWCivoO(u"࠭ࡋࡂࡖࡎࡓ࡙࡚ࡖࠨূ"),Yj1msqVeivESfrCupRy9b7WacBd(u"ࠧࡍࡃࡕࡓ࡟ࡇࠧৃ"),ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠨࡅࡌࡑࡆ࡝ࡂࡂࡕࠪৄ")]
vvXD0IiPxt3dOoR7YLmuQsgG += [AJHaiQq3PRd5cphzGuELnVg9X(u"ࠩࡉ࡙ࡘࡎࡁࡓࡘࡌࡈࡊࡕࠧ৅"),HD7MQqXd2gS(u"ࠪࡊ࡚࡙ࡈࡂࡔࡗ࡚ࠬ৆"),ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠫࡐࡏࡒࡎࡃࡏࡏࠬে"),Yj1msqVeivESfrCupRy9b7WacBd(u"ࠬࡊࡒࡂࡏࡄࡇࡆࡌࡅࠨৈ"),XEcWOIwkZKubV7vQ(u"࠭ࡔࡊࡍࡄࡅ࡙࠭৉"),vzqjsVHSBlMpxC(u"ࠧࡔࡊࡄࡆࡆࡑࡁࡕ࡛ࠪ৊"),UUobzy0xZLaVScIt7(u"ࠨࡃࡑࡍࡒࡋ࡚ࡊࡆࠪো"),bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠶ࠬৌ")]
ppHwD4gB0ZYTbX1KRl3saUMJImrNP  = [bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡘࡌࡈࡊࡕࡓࠨ্"),HD7MQqXd2gS(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬৎ"),HD7MQqXd2gS(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ৏"),PPxYugzLZwHX23yiK(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡑࡏࡖࡆࡕࠪ৐"),HD7MQqXd2gS(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡎࡁࡔࡊࡗࡅࡌ࡙ࠧ৑")]
ppHwD4gB0ZYTbX1KRl3saUMJImrNP += [zhE5I4xHinX0UoVZMNwlkPrR(u"ࠨࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉࠧ৒"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡑࡋࡑࡏࡓࡉࠩ৓")]
ppHwD4gB0ZYTbX1KRl3saUMJImrNP += [XEcWOIwkZKubV7vQ(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱࡛ࡏࡄࡆࡑࡖࠫ৔"),ldIfvn6asURQ9toi85EhqAXW3(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ৕"),HD7MQqXd2gS(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ৖")]
ppHwD4gB0ZYTbX1KRl3saUMJImrNP += [bb1fgjsAq4N2xYwnoh39lm(u"࠭ࡉࡑࡖ࡙࠱ࡑࡏࡖࡆࠩৗ"),nfNTgkiWdUq(u"ࠧࡊࡒࡗ࡚࠲ࡓࡏࡗࡋࡈࡗࠬ৘"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠨࡋࡓࡘ࡛࠳ࡓࡆࡔࡌࡉࡘ࠭৙")]
ppHwD4gB0ZYTbX1KRl3saUMJImrNP += [Yj1msqVeivESfrCupRy9b7WacBd(u"ࠩࡐ࠷࡚࠳ࡌࡊࡘࡈࠫ৚"),JvQd6LMoBX4hiy1C(u"ࠪࡑ࠸࡛࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ৛"),DFx6E0uON7Jm8(u"ࠫࡒ࠹ࡕ࠮ࡕࡈࡖࡎࡋࡓࠨড়")]
QQF0Dfwlbhv8HAYT9aW = [YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠬࡓ࠳ࡖࠩঢ়"),vzqjsVHSBlMpxC(u"࠭ࡉࡑࡖ࡙ࠫ৞"),bb1fgjsAq4N2xYwnoh39lm(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬয়"),jil8vRpBsENVYyPmDd(u"ࠨࡋࡉࡍࡑࡓࠧৠ"),baBcNd81eH5ry2Olp6Mj43(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪৡ")]
P4GWBlzIwnMq2 = vvXD0IiPxt3dOoR7YLmuQsgG+QQF0Dfwlbhv8HAYT9aW
WOkE6hBtPfVNLJu28eFSZmTndQ = vvXD0IiPxt3dOoR7YLmuQsgG+ppHwD4gB0ZYTbX1KRl3saUMJImrNP
uWb2o5k9HiaF436GL8TlDIhnvXJ = WOkE6hBtPfVNLJu28eFSZmTndQ+qW8vOGrfE2J
f6U7kuwg2zqXCTx0Gs8HJh1v = [LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠪࡔࡗࡏࡖࡂࡖࡈࠫৢ")]+rm1yICzMi5Lj8734ulwAS+[FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠫࡒࡏࡘࡆࡆࠪৣ")]+iYOV4hTaDEbZCf67MQPsGWgto+[pxt6wJ8ScYMWCivoO(u"ࠬࡖࡕࡃࡎࡌࡇࠬ৤")]+F8MV3veKyr7HIuqasbYQc+[rCmGE4YIDaZA(u"࠭ࡐࡓࡋ࡙ࡅ࡙ࡋࠧ৥")]+ZSaLRonHF3rWQCAxgG75PY6sOKhUB8
P2CAhGMl54LQb1VaDWtfk8eqzBj = [XEcWOIwkZKubV7vQ(u"ࠧࡂࡍࡒࡅࡒ࠭০"),UUobzy0xZLaVScIt7(u"ࠨࡃࡎ࡛ࡆࡓࠧ১"),Qy6wlfLoOpg1(u"ࠩࡌࡊࡎࡒࡍࠨ২"),zhE5I4xHinX0UoVZMNwlkPrR(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭৩"),JvQd6LMoBX4hiy1C(u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭৪"),Pj9YaUq1ibJ(u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧ৫"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆࠩ৬"),PPxYugzLZwHX23yiK(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ৭"),zhE5I4xHinX0UoVZMNwlkPrR(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭৮"),bb1fgjsAq4N2xYwnoh39lm(u"ࠩࡐ࠷࡚࠭৯"),PPxYugzLZwHX23yiK(u"ࠪࡍࡕ࡚ࡖࠨৰ"),gmPI7hVEM8nD(u"ࠫࡇࡕࡋࡓࡃࠪৱ"),jil8vRpBsENVYyPmDd(u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇࠧ৲"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫ৳")]
NOT_TO_TEST_ALL_SERVERS = [rCmGE4YIDaZA(u"ࠧࡠࡃࡎࡓࡤ࠭৴"),lw2snZ9J0uhLoxypqa(u"ࠨࡡࡄࡏ࡜ࡥࠧ৵"),DFx6E0uON7Jm8(u"ࠩࡢࡍࡋࡒ࡟ࠨ৶"),Qy6wlfLoOpg1(u"ࠪࡣࡐࡘࡂࡠࠩ৷"),DFx6E0uON7Jm8(u"ࠫࡤࡓࡒࡇࡡࠪ৸"),FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠬࡥࡓࡉࡏࡢࠫ৹"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠭࡟ࡔࡊ࡙ࡣࠬ৺"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠧࡠ࡛ࡘࡘࡤ࠭৻"),FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠨࡡࡇࡐࡒࡥࠧৼ"),bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠩࡢࡑ࡚࠭৽"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠪࡣࡎࡖࠧ৾"),zhE5I4xHinX0UoVZMNwlkPrR(u"ࠫࡤࡈࡋࡓࡡࠪ৿"),ldIfvn6asURQ9toi85EhqAXW3(u"ࠬࡥࡅࡍࡅࡢࠫ਀"),FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠭࡟ࡂࡔࡗࡣࠬਁ")]
Jf3OFEMHvK9mBXxnc5 = [vzqjsVHSBlMpxC(u"ࠧࡎࡇࡑ࡙ࡤࡘࡅࡗࡇࡕࡗࡊࡊ࡟ࡑࡇࡕࡑࠬਂ"),bb1fgjsAq4N2xYwnoh39lm(u"ࠨࡏࡈࡒ࡚ࡥࡁࡔࡅࡈࡒࡉࡋࡄࡠࡒࡈࡖࡒ࠭ਃ"),rCmGE4YIDaZA(u"ࠩࡐࡉࡓ࡛࡟ࡅࡇࡖࡇࡊࡔࡄࡆࡆࡢࡔࡊࡘࡍࠨ਄"),nfNTgkiWdUq(u"ࠪࡑࡊࡔࡕࡠࡔࡄࡒࡉࡕࡍࡊ࡜ࡈࡈࡤࡖࡅࡓࡏࠪਅ"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠫࡒࡋࡎࡖࡡࡕࡉ࡛ࡋࡒࡔࡇࡇࡣ࡙ࡋࡍࡑࠩਆ"),vzqjsVHSBlMpxC(u"ࠬࡓࡅࡏࡗࡢࡅࡘࡉࡅࡏࡆࡈࡈࡤ࡚ࡅࡎࡒࠪਇ"),rCmGE4YIDaZA(u"࠭ࡍࡆࡐࡘࡣࡉࡋࡓࡄࡇࡑࡈࡊࡊ࡟ࡕࡇࡐࡔࠬਈ"),lw2snZ9J0uhLoxypqa(u"ࠧࡎࡇࡑ࡙ࡤࡘࡁࡏࡆࡒࡑࡎࡠࡅࡅࡡࡗࡉࡒࡖࠧਉ")]
yv4ToSVPrxwtLc8nD3I52kmebEfNs = [IpFcwrWNgefMym3qta0hYQAzOdE,bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠵࠺࠶ਢ"),baBcNd81eH5ry2Olp6Mj43(u"࠵࠻࠶ਰ"),XEcWOIwkZKubV7vQ(u"࠱࠸࠲ਲ਼"),mRanX1HZupfSQVB2gsDGUO(u"࠵࠾࠶਩"),zhE5I4xHinX0UoVZMNwlkPrR(u"࠲࠷࠲ਬ"),bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠵࠼࠵ਯ"),baBcNd81eH5ry2Olp6Mj43(u"࠸࠹࠰ਪ"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠴࠶࠳ਭ"),UUobzy0xZLaVScIt7(u"࠹࠷࠰ਣ"),XEcWOIwkZKubV7vQ(u"࠻࠰࠱ਲ"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠸࠶࠵ਨ"),UUobzy0xZLaVScIt7(u"࠷࠶࠴ਮ"),baBcNd81eH5ry2Olp6Mj43(u"࠻࠴࠱ਫ"),bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠼࠼࠰਱"),FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠳࠳࠵࠵ਧ"),bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠺࠻࠼࠴ਦ"),zhE5I4xHinX0UoVZMNwlkPrR(u"࠷࠰࠳࠲ਤ"),XEcWOIwkZKubV7vQ(u"࠱࠱࠺࠳ਥ")]
ChHOyU7NDKkpaonjvXWqBR = [YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠨ࠴࠸࠸ࡩࡪ࠳ࡢ࠶࠳࠽ࡩ࠾ࡢ࠷࠺࠴ࡨ࠹࡫࠱࠲࠹ࡨࡩ࠼࠾ࡣࡦࡤࡩ࠶࠾࠭ਊ"),Pj9YaUq1ibJ(u"ࠩ࠴࠹࠵ࡪ࠲࠳ࡨ࠴࠱ࡨ࠻࠸ࡢ࠯࠷࠴࠷࠷࠭ࡢࡣ࠻࠸࠲࡫࠹࠳࠵ࡦࡥ࡫࠾࠵࠹࠵࠷ࠫ਋"),ldIfvn6asURQ9toi85EhqAXW3(u"ࠪ࠷࠾࠿࠱ࡦ࠻ࡦ࠹࠲࠽ࡥࡦ࠵࠰࠸ࡪ࡫࠲࠮࠺࠷ࡧ࠵࠳ࡦࡥ࠹࠼࠶ࡧࡧࡤࡥ࠵ࡧ࠹ࠬ਌"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠫ࠼࠼ࡢ࠵ࡨࡦ࠷࠹࡬ࡣࡥ࠳࠼ࡨ࠾ࡩ࠵࠶ࡣ࠴࠹࡫࠹࠶࠱࠶ࡦࡨ࠾࠷࠴ࡤࠩ਍"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠬ࠷ࡖࡏࡵࡐࡸࡑ࠷࡯ࡃࡔ࡛࡯ࡘࡔࡃࡣࡅࡐࡎ࠶ࡑࡘ࡚ࡌ࡭࡮࠵ࡪࡪ࡛ࡹࠪ਎"),nfNTgkiWdUq(u"࠭ࡡ࠵ࡨ࠺ࡪࡧ࠷࠴࠮࠴ࡧࡩ࡫࠳࠴࠱࠹࠴࠱࠽࠼࠴ࡣ࠯࠵࠶ࡪ࠹࠲࠷࠶ࡧ࠸ࡩࡪࡣࠨਏ"),Pj9YaUq1ibJ(u"ࠧ࠳ࡤ࠶࠸࠵ࡧ࠶࠹࠻࠳ࡥ࠺࠺࠰࠲ࡦࡥࡧ࠸࠽࠲ࡤ࠳࠴࠸࠺ࡪ࠹࠷࠴ࡨ࠼ࠬਐ"),zhE5I4xHinX0UoVZMNwlkPrR(u"ࠨࡥࡦ࠶࠻࠹ࡡࡣ࠳ࡨ࠹࠵࠺࠴ࡥ࠴ࡦࡥ࠺ࡪ࠵ࡥ࠵ࡩ࠽ࡪ࠹ࡣ࠴࠺࠹ࡩࡨࡧ࠱࠲࠲࠻࠷࠽࠿ࡡ࠸࠵ࠪ਑"),Qy6wlfLoOpg1(u"ࠩ࠴ࡧ࠸ࡪ࠳ࡢࡧ࠴࠼࠺ࡪࡦ࠵ࡤࡩ࠺ࡦ࡬࠵࠴࠵ࡦ࠻࠵࠺࠰ࡣ࠵࠷࠻ࡨ࠿ࡥ࠺࠻ࡥࡩ࠹࠼࠶ࡢࡧ࠼ࠫ਒")]
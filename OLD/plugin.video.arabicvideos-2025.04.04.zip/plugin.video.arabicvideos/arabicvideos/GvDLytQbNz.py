# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'EGYBEST1'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_EB1_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
SAsGubf1jW2Q3p = ['مكتبتي','ايجي بست']
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,Q0f7ytucSriRw8HTzd,text):
	if   mode==770: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==771: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,Q0f7ytucSriRw8HTzd)
	elif mode==772: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = oWcvptkU2JObI0(url)
	elif mode==773: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==774: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = NNihMcqGKQEvLz6l(url,'FULL_FILTER___'+text)
	elif mode==775: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = NNihMcqGKQEvLz6l(url,'DEFINED_FILTER___'+text)
	elif mode==776: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = SNVTEdvxWujYnGR7J6hACUP(url,Q0f7ytucSriRw8HTzd)
	elif mode==779: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text,url)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,779,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBEST1-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('nav-list(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?<span>(.*?)</span>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			title = title.strip(hSXlxL9iB05c)
			if any(value in title for value in SAsGubf1jW2Q3p): continue
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,771)
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('main-article(.*?)social-box',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('main-title.*?">(.*?)<.*?href="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for title,ZylHkumQ8zD0 in items:
			title = title.strip(hSXlxL9iB05c)
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,771,nA5dhMRg6ENzsB0l1GwvH7aIr2,'mainmenu')
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('main-menu(.*?)</div></div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			title = title.strip(hSXlxL9iB05c)
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,771)
	return kl2ZWdy8rXcHT
def SNVTEdvxWujYnGR7J6hACUP(url,type=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBEST1-SEASONS_EPISODES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('main-article".*?">(.*?)<(.*?)article',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		wWeVHSMqxGR,GGr9WlIhv1BKDJjTZFNty4R3k0dCOA,items = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,[]
		for name,WWU7QJP2tyTRLIfDh0csxbkvX in zz3eHskxE6lAyDR5cNj1ug:
			if 'حلقات' in name: GGr9WlIhv1BKDJjTZFNty4R3k0dCOA = WWU7QJP2tyTRLIfDh0csxbkvX
			if 'مواسم' in name: wWeVHSMqxGR = WWU7QJP2tyTRLIfDh0csxbkvX
		if wWeVHSMqxGR and not type:
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',wWeVHSMqxGR,PAztbuyYo4Kvd.DOTALL)
			if len(items)>1:
				for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,776,HRlygv7YwjzbSLt8fkEerq2,'season')
		if GGr9WlIhv1BKDJjTZFNty4R3k0dCOA and len(items)<2:
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?data-src="(.*?)".*?title="(.*?)"',GGr9WlIhv1BKDJjTZFNty4R3k0dCOA,PAztbuyYo4Kvd.DOTALL)
			if items:
				for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
					TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,773,HRlygv7YwjzbSLt8fkEerq2)
			else:
				items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',GGr9WlIhv1BKDJjTZFNty4R3k0dCOA,PAztbuyYo4Kvd.DOTALL)
				for ZylHkumQ8zD0,title in items:
					TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,773)
	return
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,type=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBEST1-TITLES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	items,ddoTyXHWlmDVAnEpzGwhxu7i,tgsLX2uACmFhVznejRy6O = [],False,False
	if not type:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('main-content(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?</i>(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,title in items:
				title = title.strip(hSXlxL9iB05c)
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,771,nA5dhMRg6ENzsB0l1GwvH7aIr2,'submenu')
				ddoTyXHWlmDVAnEpzGwhxu7i = True
	if not type and 'p=' not in url:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('searchform(.*?)</form>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			if ddoTyXHWlmDVAnEpzGwhxu7i: TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فلتر محدد',url,775,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filter')
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فلتر كامل',url,774,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filter')
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث',url,779)
			TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
			tgsLX2uACmFhVznejRy6O = True
	if not ddoTyXHWlmDVAnEpzGwhxu7i:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('blocks(.*?)article',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
				HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2.strip(CXtugbqhV3)
				ZylHkumQ8zD0 = pvOytL0nF7JY6flXTxAcHbQeNahu3(ZylHkumQ8zD0)
				if '/serie/' in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,776,HRlygv7YwjzbSLt8fkEerq2,'season')
				else: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,773,HRlygv7YwjzbSLt8fkEerq2)
			Q0f7ytucSriRw8HTzd = '1'
			if 'p=' in url: url,Q0f7ytucSriRw8HTzd = url.split('p=',1)
			Ccemh2nAvQ = '&' if '?' in url else '?'
			url = url+Ccemh2nAvQ
			url = url.replace('?&','?')
			if len(items)==40:
				url = url+'p='+str(int(Q0f7ytucSriRw8HTzd)+1)
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الصفحة التالية',url,771)
			elif Q0f7ytucSriRw8HTzd!='1':
				url = url+'p='+str(int(Q0f7ytucSriRw8HTzd)-1)
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الصفحة السابقة',url,771)
	return
def lNBcUr8RCn(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(yy6RomT9bQhJf,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBEST1-PLAY-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	nR3YVtZDPs1IpAC = PAztbuyYo4Kvd.findall('<label>التصنيف</label>.*?">(.*?)<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if nR3YVtZDPs1IpAC and g4gUOtGiVkoNuaBrHhx8L(wgj0rX5tbcxPulhmny,url,nR3YVtZDPs1IpAC): return
	M85MsAZyPBVrujXwbCHea4Wn1mLd,HtT6mBGwMaq1o0rybzZ4,Co7gJfiXOmlN4VrbjhuknEH = [],[],[]
	ZylHkumQ8zD0 = PAztbuyYo4Kvd.findall('download-section.*?action="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if ZylHkumQ8zD0:
		ZylHkumQ8zD0 = ZylHkumQ8zD0[0]
		if ZylHkumQ8zD0 not in Co7gJfiXOmlN4VrbjhuknEH:
			Co7gJfiXOmlN4VrbjhuknEH.append(ZylHkumQ8zD0)
			HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0+'?named=__embed______'+kGE6zoKSan54W(url))
	Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q = PAztbuyYo4Kvd.findall('WatchServers(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	for WWU7QJP2tyTRLIfDh0csxbkvX in Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q:
		HRpMVv1x5ol9gbsnQquj = PAztbuyYo4Kvd.findall("url='(.*?)'.*?>(.*?)<",WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,DQ7XgFltujVL in HRpMVv1x5ol9gbsnQquj:
			if ZylHkumQ8zD0 not in Co7gJfiXOmlN4VrbjhuknEH:
				Co7gJfiXOmlN4VrbjhuknEH.append(ZylHkumQ8zD0)
				HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0+'?named='+DQ7XgFltujVL+'__both______'+kGE6zoKSan54W(url))
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(HtT6mBGwMaq1o0rybzZ4,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search,url=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if not search: search = FaUBpzTGxtS7hZyl()
	if not search: return
	SEGtTsCyUVi0lo4LJkH5 = search.replace(hSXlxL9iB05c,'%20')
	if not url: url = GiqvpBF9xLEdHDr37byJSngeCQ+'/search?query='+SEGtTsCyUVi0lo4LJkH5
	else: url = url+'?title='+SEGtTsCyUVi0lo4LJkH5+'&genre=&year=&lang='
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,'search')
	return
def iBOFgUs6eTkIQyxKbqM(url):
	url = url.split('/smartemadfilter?')[0]
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBEST1-GET_FILTERS_BLOCKS-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	AAkSjd9agcy = []
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('form-row(.*?)</form>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		AAkSjd9agcy = PAztbuyYo4Kvd.findall('select name="(.*?)".*?value>(.*?)<(.*?)</select',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		MFd17IQ58Unz,KDuQ6YkSCLPz5be7BqTAxhMXwgF,Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q = zip(*AAkSjd9agcy)
		AAkSjd9agcy = zip(KDuQ6YkSCLPz5be7BqTAxhMXwgF,MFd17IQ58Unz,Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q)
	return AAkSjd9agcy
def vPOwqQ5zYHc10DVaSmU2ysG8k4t(WWU7QJP2tyTRLIfDh0csxbkvX):
	items = PAztbuyYo4Kvd.findall('value="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	return items
def iCNd2ua6f9EHyBXWYMrKcR(url):
	url = url.replace('/smartemadfilter?','?title=&')
	return url
cc0WqiHnzER = ['year','lang','genre']
o7o2QXr0sG = ['year','lang','genre']
def NNihMcqGKQEvLz6l(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==nA5dhMRg6ENzsB0l1GwvH7aIr2: vvXcyZhkfV,guikd57yRSCMsNmlUqFHWAYL = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	else: vvXcyZhkfV,guikd57yRSCMsNmlUqFHWAYL = filter.split('___')
	if type=='DEFINED_FILTER':
		if o7o2QXr0sG[0]+'=' not in vvXcyZhkfV: kvfOU7Tpz958QBqnIlaAePLys = o7o2QXr0sG[0]
		for q3kZpRe28O0s1NaCXQ9SMuGKin in range(len(o7o2QXr0sG[0:-1])):
			if o7o2QXr0sG[q3kZpRe28O0s1NaCXQ9SMuGKin]+'=' in vvXcyZhkfV: kvfOU7Tpz958QBqnIlaAePLys = o7o2QXr0sG[q3kZpRe28O0s1NaCXQ9SMuGKin+1]
		FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+kvfOU7Tpz958QBqnIlaAePLys+'=0'
		QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+kvfOU7Tpz958QBqnIlaAePLys+'=0'
		TB6HLPpacsK8f034jvYx7SNgFd = FqCItdu32L9hNwcEXWoges4R68KS.strip('&')+'___'+QA6C8r4lEdhemfJPRc.strip('&')
		OQmDdTI7hU4Lv3BfexPVKgRF8YN = EdpkojMzLm6b3ZSVcXwi0CPRIH(guikd57yRSCMsNmlUqFHWAYL,'all')
		KteRnFMjHpBPqNf8 = url+'/smartemadfilter?'+OQmDdTI7hU4Lv3BfexPVKgRF8YN
	elif type=='FULL_FILTER':
		iEa2qGQctFxX = EdpkojMzLm6b3ZSVcXwi0CPRIH(vvXcyZhkfV,'modified_values')
		iEa2qGQctFxX = pvOytL0nF7JY6flXTxAcHbQeNahu3(iEa2qGQctFxX)
		if guikd57yRSCMsNmlUqFHWAYL: guikd57yRSCMsNmlUqFHWAYL = EdpkojMzLm6b3ZSVcXwi0CPRIH(guikd57yRSCMsNmlUqFHWAYL,'all')
		if not guikd57yRSCMsNmlUqFHWAYL: KteRnFMjHpBPqNf8 = url
		else: KteRnFMjHpBPqNf8 = url+'/smartemadfilter?'+guikd57yRSCMsNmlUqFHWAYL
		w7Ol6FnokgJDSsIt = iCNd2ua6f9EHyBXWYMrKcR(KteRnFMjHpBPqNf8)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'أظهار قائمة الفيديو التي تم اختيارها ',w7Ol6FnokgJDSsIt,771,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filter')
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+' [[   '+iEa2qGQctFxX+'   ]]',w7Ol6FnokgJDSsIt,771,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filter')
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	AAkSjd9agcy = iBOFgUs6eTkIQyxKbqM(url)
	dict = {}
	for name,xWwIXcK0L61EBgtn7smr,WWU7QJP2tyTRLIfDh0csxbkvX in AAkSjd9agcy:
		name = name.replace('كل ',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		items = vPOwqQ5zYHc10DVaSmU2ysG8k4t(WWU7QJP2tyTRLIfDh0csxbkvX)
		if '=' not in KteRnFMjHpBPqNf8: KteRnFMjHpBPqNf8 = url
		if type=='DEFINED_FILTER':
			if kvfOU7Tpz958QBqnIlaAePLys!=xWwIXcK0L61EBgtn7smr: continue
			elif len(items)<2:
				if xWwIXcK0L61EBgtn7smr==o7o2QXr0sG[-1]:
					w7Ol6FnokgJDSsIt = iCNd2ua6f9EHyBXWYMrKcR(KteRnFMjHpBPqNf8)
					LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(w7Ol6FnokgJDSsIt)
				else: NNihMcqGKQEvLz6l(KteRnFMjHpBPqNf8,'DEFINED_FILTER___'+TB6HLPpacsK8f034jvYx7SNgFd)
				return
			else:
				if xWwIXcK0L61EBgtn7smr==o7o2QXr0sG[-1]:
					w7Ol6FnokgJDSsIt = iCNd2ua6f9EHyBXWYMrKcR(KteRnFMjHpBPqNf8)
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع ',w7Ol6FnokgJDSsIt,771,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filter')
				else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع ',KteRnFMjHpBPqNf8,775,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,TB6HLPpacsK8f034jvYx7SNgFd)
		elif type=='FULL_FILTER':
			FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+xWwIXcK0L61EBgtn7smr+'=0'
			QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+xWwIXcK0L61EBgtn7smr+'=0'
			TB6HLPpacsK8f034jvYx7SNgFd = FqCItdu32L9hNwcEXWoges4R68KS+'___'+QA6C8r4lEdhemfJPRc
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع :'+name,KteRnFMjHpBPqNf8,774,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,TB6HLPpacsK8f034jvYx7SNgFd)
		dict[xWwIXcK0L61EBgtn7smr] = {}
		for value,DOT0LXwgoHYkFBC4MbxN53 in items:
			if not value: continue
			if DOT0LXwgoHYkFBC4MbxN53 in SAsGubf1jW2Q3p: continue
			dict[xWwIXcK0L61EBgtn7smr][value] = DOT0LXwgoHYkFBC4MbxN53
			FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+xWwIXcK0L61EBgtn7smr+'='+DOT0LXwgoHYkFBC4MbxN53
			QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+xWwIXcK0L61EBgtn7smr+'='+value
			b97AdvPkWGEBe3ayj1Jhmcq2LVxr = FqCItdu32L9hNwcEXWoges4R68KS+'___'+QA6C8r4lEdhemfJPRc
			title = DOT0LXwgoHYkFBC4MbxN53+' :'#+dict[xWwIXcK0L61EBgtn7smr]['0']
			title = DOT0LXwgoHYkFBC4MbxN53+' :'+name
			if type=='FULL_FILTER': TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,774,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,b97AdvPkWGEBe3ayj1Jhmcq2LVxr)
			elif type=='DEFINED_FILTER' and o7o2QXr0sG[-2]+'=' in vvXcyZhkfV:
				OQmDdTI7hU4Lv3BfexPVKgRF8YN = EdpkojMzLm6b3ZSVcXwi0CPRIH(QA6C8r4lEdhemfJPRc,'modified_filters')
				KteRnFMjHpBPqNf8 = url+'/smartemadfilter?'+OQmDdTI7hU4Lv3BfexPVKgRF8YN
				w7Ol6FnokgJDSsIt = iCNd2ua6f9EHyBXWYMrKcR(KteRnFMjHpBPqNf8)
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,w7Ol6FnokgJDSsIt,771,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filter')
			elif type=='DEFINED_FILTER': TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,775,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,b97AdvPkWGEBe3ayj1Jhmcq2LVxr)
	return
def EdpkojMzLm6b3ZSVcXwi0CPRIH(tgsLX2uACmFhVznejRy6O,mode):
	tgsLX2uACmFhVznejRy6O = tgsLX2uACmFhVznejRy6O.replace('=&','=0&')
	tgsLX2uACmFhVznejRy6O = tgsLX2uACmFhVznejRy6O.strip('&')
	bpoRYqt38j = {}
	if '=' in tgsLX2uACmFhVznejRy6O:
		items = tgsLX2uACmFhVznejRy6O.split('&')
		for CQtNwXGVAJ2y5nBY in items:
			eehzynNs85aTHrgCUmFc3DBO12,value = CQtNwXGVAJ2y5nBY.split('=')
			bpoRYqt38j[eehzynNs85aTHrgCUmFc3DBO12] = value
	H5ROYNwvQFkBiVElThr = nA5dhMRg6ENzsB0l1GwvH7aIr2
	for key in cc0WqiHnzER:
		if key in list(bpoRYqt38j.keys()): value = bpoRYqt38j[key]
		else: value = '0'
		if '%' not in value: value = kGE6zoKSan54W(value)
		if mode=='modified_values' and value!='0': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+' + '+value
		elif mode=='modified_filters' and value!='0': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+'&'+key+'='+value
		elif mode=='all': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+'&'+key+'='+value
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.strip(' + ')
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.strip('&')
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.replace('=0','=')
	return H5ROYNwvQFkBiVElThr
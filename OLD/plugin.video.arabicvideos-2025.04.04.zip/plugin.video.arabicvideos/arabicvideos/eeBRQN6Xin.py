# -*- coding: utf-8 -*-
from pR2X91txEm import *
import bs4 as LmbRNanktW4Yi3GBj6
wgj0rX5tbcxPulhmny = 'ELCINEMA'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_ELC_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
headers = {'Referer':GiqvpBF9xLEdHDr37byJSngeCQ}
SAsGubf1jW2Q3p = []
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==510: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==511: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = Qa08I7VPGflhtBgxNobZv1jsmrEy6(url)
	elif mode==512: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = jm0Me6Ja47K(url)
	elif mode==513: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = L6LzKwk4Hgy7(url)
	elif mode==514: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = wJkMefCP0gq1VuT9z(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = wJkMefCP0gq1VuT9z(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = nRyAKlUaqBpc6tsgwZxzP2k(text)
	elif mode==517: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = FRZAhVPtSGcXDswMl(url)
	elif mode==518: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = oXV1xKEYD4MBQ0aUNZkprgvdFPmWLq(url)
	elif mode==519: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	elif mode==520: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = vvASlGOg2XskqCpn3(url)
	elif mode==521: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = wioQstGrCLI(url)
	elif mode==522: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==523: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = vEwp2rVIcjZbh(text)
	elif mode==524: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = PPhdtlXGNLFw()
	elif mode==525: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = dOCuS291Nsp()
	elif mode==526: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LrK3Xu5Im0vHeZgWoAxMQ()
	elif mode==527: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = hK1McnCXrquYZSQtJm()
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث بموسوعة السينما',nA5dhMRg6ENzsB0l1GwvH7aIr2,519)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'موسوعة الأعمال',nA5dhMRg6ENzsB0l1GwvH7aIr2,525)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'موسوعة الأشخاص',nA5dhMRg6ENzsB0l1GwvH7aIr2,526)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'موسوعة المصنفات',nA5dhMRg6ENzsB0l1GwvH7aIr2,527)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'موسوعة المنوعات',nA5dhMRg6ENzsB0l1GwvH7aIr2,524)
	return
def PPhdtlXGNLFw():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+' فيديوهات - خاصة',GiqvpBF9xLEdHDr37byJSngeCQ+'/video',520)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فيديوهات - أحدث',GiqvpBF9xLEdHDr37byJSngeCQ+'/video/latest',521)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فيديوهات - أقدم',GiqvpBF9xLEdHDr37byJSngeCQ+'/video/oldest',521)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فيديوهات - أكثر مشاهدة',GiqvpBF9xLEdHDr37byJSngeCQ+'/video/views',521)
	return
def dOCuS291Nsp():
	lpz6UW1GfRdwMKjJVQtPa8c0E = GiqvpBF9xLEdHDr37byJSngeCQ+'/lineup?utf8=%E2%9C%93'
	LqFwCQ5W2SikGavdIAD7Nb6lM = lpz6UW1GfRdwMKjJVQtPa8c0E+'&type=2&category=1&foreign=false&tag='
	SSUGKMZDzbW = lpz6UW1GfRdwMKjJVQtPa8c0E+'&type=2&category=3&foreign=false&tag='
	vvyd7Fj5YWHwu6hNO8T2itfDB = lpz6UW1GfRdwMKjJVQtPa8c0E+'&type=2&category=1&foreign=true&tag='
	rwy7o05hKPVtn = lpz6UW1GfRdwMKjJVQtPa8c0E+'&type=2&category=3&foreign=true&tag='
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مصنفات أفلام عربي',LqFwCQ5W2SikGavdIAD7Nb6lM,511)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مصنفات مسلسلات عربي',SSUGKMZDzbW,511)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مصنفات أفلام اجنبي',vvyd7Fj5YWHwu6hNO8T2itfDB,511)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مصنفات مسلسلات اجنبي',rwy7o05hKPVtn,511)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فهرس أعمال أبجدي',GiqvpBF9xLEdHDr37byJSngeCQ+'/index/work/alphabet',517)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فهرس  بلد الإنتاج',GiqvpBF9xLEdHDr37byJSngeCQ+'/index/work/country',517)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فهرس اللغة',GiqvpBF9xLEdHDr37byJSngeCQ+'/index/work/language',517)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فهرس مصنفات العمل',GiqvpBF9xLEdHDr37byJSngeCQ+'/index/work/genre',517)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فهرس سنة الإصدار',GiqvpBF9xLEdHDr37byJSngeCQ+'/index/work/release_year',517)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مواسم - فلتر محدد',GiqvpBF9xLEdHDr37byJSngeCQ+'/seasonals',515)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مواسم - فلتر كامل',GiqvpBF9xLEdHDr37byJSngeCQ+'/seasonals',514)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مصنفات - فلتر محدد',GiqvpBF9xLEdHDr37byJSngeCQ+'/lineup',515)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مصنفات - فلتر كامل',GiqvpBF9xLEdHDr37byJSngeCQ+'/lineup',514)
	return
def hK1McnCXrquYZSQtJm():
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',GiqvpBF9xLEdHDr37byJSngeCQ+'/lineup',nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ELCINEMA-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	z1zyAncjpsw2MVg4PXt = LmbRNanktW4Yi3GBj6.BeautifulSoup(kl2ZWdy8rXcHT,'html.parser',multi_valued_attributes=None)
	WWU7QJP2tyTRLIfDh0csxbkvX = z1zyAncjpsw2MVg4PXt.find('select',attrs={'name':'tag'})
	m0YJ3feqUjD7 = WWU7QJP2tyTRLIfDh0csxbkvX.find_all('option')
	for DOT0LXwgoHYkFBC4MbxN53 in m0YJ3feqUjD7:
		value = DOT0LXwgoHYkFBC4MbxN53.get('value')
		if not value: continue
		title = DOT0LXwgoHYkFBC4MbxN53.text
		if cS2NYw4xulqJgvzkMF:
			title = title.encode(YWEQ3Cf8RevpD0m7NjF1)
			value = value.encode(YWEQ3Cf8RevpD0m7NjF1)
		ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+value
		title = title.replace('قائمة ',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,511)
	return
def LrK3Xu5Im0vHeZgWoAxMQ():
	lpz6UW1GfRdwMKjJVQtPa8c0E = GiqvpBF9xLEdHDr37byJSngeCQ+'/lineup?utf8=%E2%9C%93'
	jLevlJ4xCFsM7oq9hunwXmR2D = lpz6UW1GfRdwMKjJVQtPa8c0E+'&type=1&category=&foreign=&tag='
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مصنفات أشخاص',jLevlJ4xCFsM7oq9hunwXmR2D,511)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فهرس أشخاص أبجدي',GiqvpBF9xLEdHDr37byJSngeCQ+'/index/person/alphabet',517)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فهرس موطن',GiqvpBF9xLEdHDr37byJSngeCQ+'/index/person/nationality',517)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فهرس  تاريخ الميلاد',GiqvpBF9xLEdHDr37byJSngeCQ+'/index/person/birth_year',517)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فهرس  تاريخ الوفاة',GiqvpBF9xLEdHDr37byJSngeCQ+'/index/person/death_year',517)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مصنفات - فلتر محدد',GiqvpBF9xLEdHDr37byJSngeCQ+'/lineup',515)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مصنفات - فلتر كامل',GiqvpBF9xLEdHDr37byJSngeCQ+'/lineup',514)
	return
def Qa08I7VPGflhtBgxNobZv1jsmrEy6(url):
	if '/seasonals' in url: rRxld1HykSCacZs0mzWXIBibn = 0
	elif '/lineup' in url: rRxld1HykSCacZs0mzWXIBibn = 1
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ELCINEMA-LISTS-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	z1zyAncjpsw2MVg4PXt = LmbRNanktW4Yi3GBj6.BeautifulSoup(kl2ZWdy8rXcHT,'html.parser',multi_valued_attributes=None)
	Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q = z1zyAncjpsw2MVg4PXt.find_all(class_='jumbo-theater clearfix')
	for WWU7QJP2tyTRLIfDh0csxbkvX in Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q:
		title = WWU7QJP2tyTRLIfDh0csxbkvX.find_all('a')[rRxld1HykSCacZs0mzWXIBibn].text
		ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+WWU7QJP2tyTRLIfDh0csxbkvX.find_all('a')[rRxld1HykSCacZs0mzWXIBibn].get('href')
		if cS2NYw4xulqJgvzkMF:
			title = title.encode(YWEQ3Cf8RevpD0m7NjF1)
			ZylHkumQ8zD0 = ZylHkumQ8zD0.encode(YWEQ3Cf8RevpD0m7NjF1)
		if not Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q:
			jm0Me6Ja47K(ZylHkumQ8zD0)
			return
		else:
			title = title.replace('قائمة ',nA5dhMRg6ENzsB0l1GwvH7aIr2)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,512)
	xxVd5HftDBAeLbmZTKkz(z1zyAncjpsw2MVg4PXt,511)
	return
def xxVd5HftDBAeLbmZTKkz(z1zyAncjpsw2MVg4PXt,mode):
	WWU7QJP2tyTRLIfDh0csxbkvX = z1zyAncjpsw2MVg4PXt.find(class_='pagination')
	if WWU7QJP2tyTRLIfDh0csxbkvX:
		ttGUd3eobkxwFrmI0hX = WWU7QJP2tyTRLIfDh0csxbkvX.find_all('a')
		kRvQAbGlLeNSfJgiWmHB3aXDsVc = WWU7QJP2tyTRLIfDh0csxbkvX.find_all('li')
		FFcufLbxNDSw = list(zip(ttGUd3eobkxwFrmI0hX,kRvQAbGlLeNSfJgiWmHB3aXDsVc))
		hsqrMEVB70i2ZnzPHlGYD1oy = -1
		B0hfc9OtnWYbs1 = len(FFcufLbxNDSw)
		for QQGubA8tRnHSPaXLKod4zMEFpjfcl,aynYOZhM3vLbT9U1PEKJjwpx in FFcufLbxNDSw:
			hsqrMEVB70i2ZnzPHlGYD1oy += 1
			aynYOZhM3vLbT9U1PEKJjwpx = aynYOZhM3vLbT9U1PEKJjwpx['class']
			if 'unavailable' in aynYOZhM3vLbT9U1PEKJjwpx or 'current' in aynYOZhM3vLbT9U1PEKJjwpx: continue
			gO2PcxfG7Yhd = QQGubA8tRnHSPaXLKod4zMEFpjfcl.text
			ww5oBKPZmc = GiqvpBF9xLEdHDr37byJSngeCQ+QQGubA8tRnHSPaXLKod4zMEFpjfcl.get('href')
			if cS2NYw4xulqJgvzkMF:
				gO2PcxfG7Yhd = gO2PcxfG7Yhd.encode(YWEQ3Cf8RevpD0m7NjF1)
				ww5oBKPZmc = ww5oBKPZmc.encode(YWEQ3Cf8RevpD0m7NjF1)
			if   hsqrMEVB70i2ZnzPHlGYD1oy==0: gO2PcxfG7Yhd = 'أولى'
			elif hsqrMEVB70i2ZnzPHlGYD1oy==1: gO2PcxfG7Yhd = 'سابقة'
			elif hsqrMEVB70i2ZnzPHlGYD1oy==B0hfc9OtnWYbs1-2: gO2PcxfG7Yhd = 'لاحقة'
			elif hsqrMEVB70i2ZnzPHlGYD1oy==B0hfc9OtnWYbs1-1: gO2PcxfG7Yhd = 'أخيرة'
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+gO2PcxfG7Yhd,ww5oBKPZmc,mode)
	return
def jm0Me6Ja47K(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ELCINEMA-TITLES1-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	z1zyAncjpsw2MVg4PXt = LmbRNanktW4Yi3GBj6.BeautifulSoup(kl2ZWdy8rXcHT,'html.parser',multi_valued_attributes=None)
	Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q = z1zyAncjpsw2MVg4PXt.find_all(class_='row')
	items,gtazKNuwmbOV5Rs3Q = [],True
	for WWU7QJP2tyTRLIfDh0csxbkvX in Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q:
		if not WWU7QJP2tyTRLIfDh0csxbkvX.find(class_='thumbnail-wrapper'): continue
		if gtazKNuwmbOV5Rs3Q: gtazKNuwmbOV5Rs3Q = False ; continue
		DKZLYW9MGU6RAfoEiBe = []
		OS38QX6HBMsDLkJuTiE = WWU7QJP2tyTRLIfDh0csxbkvX.find_all(class_=['censorship red','censorship purple'])
		for aO923s0Detd in OS38QX6HBMsDLkJuTiE:
			UUf9aXA7nki5oJ8wYCxgZqHGde3 = aO923s0Detd.find_all('li')[1].text
			if cS2NYw4xulqJgvzkMF:
				UUf9aXA7nki5oJ8wYCxgZqHGde3 = UUf9aXA7nki5oJ8wYCxgZqHGde3.encode(YWEQ3Cf8RevpD0m7NjF1)
			DKZLYW9MGU6RAfoEiBe.append(UUf9aXA7nki5oJ8wYCxgZqHGde3)
		if not g4gUOtGiVkoNuaBrHhx8L(wgj0rX5tbcxPulhmny,nA5dhMRg6ENzsB0l1GwvH7aIr2,DKZLYW9MGU6RAfoEiBe,False):
			io76Hju84PtJO3hE5x9KZnpGmalIw = WWU7QJP2tyTRLIfDh0csxbkvX.find('img').get('data-src')
			title = WWU7QJP2tyTRLIfDh0csxbkvX.find('h3')
			name = title.find('a').text
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+title.find('a').get('href')
			W98t2obgunQLGIld4JxEeiB = WWU7QJP2tyTRLIfDh0csxbkvX.find(class_='no-margin')
			EzkIN7wDlxMCGZ = WWU7QJP2tyTRLIfDh0csxbkvX.find(class_='legend')
			if W98t2obgunQLGIld4JxEeiB: W98t2obgunQLGIld4JxEeiB = W98t2obgunQLGIld4JxEeiB.text
			if EzkIN7wDlxMCGZ: EzkIN7wDlxMCGZ = EzkIN7wDlxMCGZ.text
			if cS2NYw4xulqJgvzkMF:
				io76Hju84PtJO3hE5x9KZnpGmalIw = io76Hju84PtJO3hE5x9KZnpGmalIw.encode(YWEQ3Cf8RevpD0m7NjF1)
				name = name.encode(YWEQ3Cf8RevpD0m7NjF1)
				ZylHkumQ8zD0 = ZylHkumQ8zD0.encode(YWEQ3Cf8RevpD0m7NjF1)
				if W98t2obgunQLGIld4JxEeiB: W98t2obgunQLGIld4JxEeiB = W98t2obgunQLGIld4JxEeiB.encode(YWEQ3Cf8RevpD0m7NjF1)
			Xxcm31HuozfbJEAv8Rl7PwUgGBF4 = {}
			if EzkIN7wDlxMCGZ: Xxcm31HuozfbJEAv8Rl7PwUgGBF4['stars'] = EzkIN7wDlxMCGZ
			if W98t2obgunQLGIld4JxEeiB:
				W98t2obgunQLGIld4JxEeiB = W98t2obgunQLGIld4JxEeiB.replace(CXtugbqhV3,' .. ')
				Xxcm31HuozfbJEAv8Rl7PwUgGBF4['plot'] = W98t2obgunQLGIld4JxEeiB.replace('...اقرأ المزيد',nA5dhMRg6ENzsB0l1GwvH7aIr2)
			if '/work/' in ZylHkumQ8zD0:
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+name,ZylHkumQ8zD0,516,io76Hju84PtJO3hE5x9KZnpGmalIw,nA5dhMRg6ENzsB0l1GwvH7aIr2,name,nA5dhMRg6ENzsB0l1GwvH7aIr2,Xxcm31HuozfbJEAv8Rl7PwUgGBF4)
			elif '/person/' in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+name,ZylHkumQ8zD0,513,io76Hju84PtJO3hE5x9KZnpGmalIw,nA5dhMRg6ENzsB0l1GwvH7aIr2,name,nA5dhMRg6ENzsB0l1GwvH7aIr2,Xxcm31HuozfbJEAv8Rl7PwUgGBF4)
	xxVd5HftDBAeLbmZTKkz(z1zyAncjpsw2MVg4PXt,512)
	return
def L6LzKwk4Hgy7(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ELCINEMA-TITLES2-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	z1zyAncjpsw2MVg4PXt = LmbRNanktW4Yi3GBj6.BeautifulSoup(kl2ZWdy8rXcHT,'html.parser',multi_valued_attributes=None)
	Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q = z1zyAncjpsw2MVg4PXt.find_all('li')
	KDuQ6YkSCLPz5be7BqTAxhMXwgF,items = [],[]
	for WWU7QJP2tyTRLIfDh0csxbkvX in Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q:
		if not WWU7QJP2tyTRLIfDh0csxbkvX.find(class_='thumbnail-wrapper'): continue
		if not WWU7QJP2tyTRLIfDh0csxbkvX.find(class_=['unstyled','unstyled text-center']): continue
		if WWU7QJP2tyTRLIfDh0csxbkvX.find(class_='hide'): continue
		title = WWU7QJP2tyTRLIfDh0csxbkvX.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in KDuQ6YkSCLPz5be7BqTAxhMXwgF: continue
		KDuQ6YkSCLPz5be7BqTAxhMXwgF.append(name)
		ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+title.find('a').get('href')
		if '/search/work/' in url: io76Hju84PtJO3hE5x9KZnpGmalIw = WWU7QJP2tyTRLIfDh0csxbkvX.find('img').get('src')
		elif '/search/person/' in url: io76Hju84PtJO3hE5x9KZnpGmalIw = WWU7QJP2tyTRLIfDh0csxbkvX.find('img').get('data-src')
		elif '/search/video/' in url: io76Hju84PtJO3hE5x9KZnpGmalIw = WWU7QJP2tyTRLIfDh0csxbkvX.find('img').get('data-src')
		else: io76Hju84PtJO3hE5x9KZnpGmalIw = WWU7QJP2tyTRLIfDh0csxbkvX.find('img').get('src')
		if cS2NYw4xulqJgvzkMF:
			name = name.encode(YWEQ3Cf8RevpD0m7NjF1)
			ZylHkumQ8zD0 = ZylHkumQ8zD0.encode(YWEQ3Cf8RevpD0m7NjF1)
			io76Hju84PtJO3hE5x9KZnpGmalIw = io76Hju84PtJO3hE5x9KZnpGmalIw.encode(YWEQ3Cf8RevpD0m7NjF1)
		name = name.strip(hSXlxL9iB05c)
		items.append((name,ZylHkumQ8zD0,io76Hju84PtJO3hE5x9KZnpGmalIw))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,ZylHkumQ8zD0,io76Hju84PtJO3hE5x9KZnpGmalIw in items:
		if '/search/video/' in url: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+name,ZylHkumQ8zD0,522,io76Hju84PtJO3hE5x9KZnpGmalIw)
		elif '/search/person/' in url: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+name,ZylHkumQ8zD0,513,io76Hju84PtJO3hE5x9KZnpGmalIw,nA5dhMRg6ENzsB0l1GwvH7aIr2,name)
		else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+name,ZylHkumQ8zD0,516,io76Hju84PtJO3hE5x9KZnpGmalIw,nA5dhMRg6ENzsB0l1GwvH7aIr2,name)
	return
def nRyAKlUaqBpc6tsgwZxzP2k(text):
	text = text.replace('الإعلان',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('لفيلم',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('الرسمي',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	text = text.replace('إعلان',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('فيلم',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('البرومو',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	text = text.replace('التشويقي',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('لمسلسل',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('مسلسل',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	text = text.replace(':',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(')',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('(',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(',',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	text = text.replace('_',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(';',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('-',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('.',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	text = text.replace('\'',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('\"',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	text = text.replace(cqsuhi1JE7nNIfbPYQSpFgeGr,hSXlxL9iB05c).replace(PwYGfc4gTjiyRlsHn1OE,hSXlxL9iB05c).replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c)
	text = text.strip(hSXlxL9iB05c)
	OhgvSQxFZWK = text.count(hSXlxL9iB05c)+1
	if OhgvSQxFZWK==1:
		vEwp2rVIcjZbh(text)
		return
	TBt8bUDo9WhL('link',DjKrTPWEFw2YeCi5d6unBqhZSlAR+bbTCMJwEx8nhN4X+'==== كلمات للبحث ===='+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	bbI09jMYXKVoAEzT = text.split(hSXlxL9iB05c)
	UFvW6K2CneRQj7aHgYSwfmEB4ZoLs = pow(2,OhgvSQxFZWK)
	PmC7clhQwMeTrsYb8x3DUL1kR2tZN = []
	def RRHFStlIVvnxDf8rOhuGAzqMQ6b(GLpoAINt4k,uu4aPIg6AE):
		if GLpoAINt4k=='1': return uu4aPIg6AE
		return nA5dhMRg6ENzsB0l1GwvH7aIr2
	for hsqrMEVB70i2ZnzPHlGYD1oy in range(UFvW6K2CneRQj7aHgYSwfmEB4ZoLs,0,-1):
		ggoki2YM6Fmvb = list(OhgvSQxFZWK*'0'+bin(hsqrMEVB70i2ZnzPHlGYD1oy)[2:])[-OhgvSQxFZWK:]
		ggoki2YM6Fmvb = reversed(ggoki2YM6Fmvb)
		UwQYtvDH9oc8nOemluxdCXKr2JN = map(RRHFStlIVvnxDf8rOhuGAzqMQ6b,ggoki2YM6Fmvb,bbI09jMYXKVoAEzT)
		title = hSXlxL9iB05c.join(filter(None,UwQYtvDH9oc8nOemluxdCXKr2JN))
		if cS2NYw4xulqJgvzkMF: g7qwMTAPoVpIyQUaDeNOnhvs = title.decode(YWEQ3Cf8RevpD0m7NjF1)
		else: g7qwMTAPoVpIyQUaDeNOnhvs = title
		if len(g7qwMTAPoVpIyQUaDeNOnhvs)>2 and title not in PmC7clhQwMeTrsYb8x3DUL1kR2tZN:
			PmC7clhQwMeTrsYb8x3DUL1kR2tZN.append(title)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,nA5dhMRg6ENzsB0l1GwvH7aIr2,523,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,title)
	return
def vEwp2rVIcjZbh(hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O):
	if cS2NYw4xulqJgvzkMF:
		hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O = hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O.decode(YWEQ3Cf8RevpD0m7NjF1)
		import arabic_reshaper as ffAjT4itIRONkMyHp8mBgw,bidi.algorithm as rrEG9U6dalA
		hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O = ffAjT4itIRONkMyHp8mBgw.ArabicReshaper().reshape(hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O)
		hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O = rrEG9U6dalA.get_display(hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O)
	import BBFeHcDpy6
	hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O = FaUBpzTGxtS7hZyl(gcfWqOoyDiR5LQPAeX=hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O)
	BBFeHcDpy6.WULrxiSjG3d1Cemza7Kc(hWa9cdUJwrQVyt2lBXqT4K6oMS8H0O)
	return
def FRZAhVPtSGcXDswMl(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ELCINEMA-INDEXES_LISTS-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	z1zyAncjpsw2MVg4PXt = LmbRNanktW4Yi3GBj6.BeautifulSoup(kl2ZWdy8rXcHT,'html.parser',multi_valued_attributes=None)
	WWU7QJP2tyTRLIfDh0csxbkvX = z1zyAncjpsw2MVg4PXt.find(class_='list-separator list-title')
	FwAWKXTqvQiL98jeJ2 = WWU7QJP2tyTRLIfDh0csxbkvX.find_all('a')
	items = []
	for title in FwAWKXTqvQiL98jeJ2:
		name = title.text
		ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+title.get('href')
		if cS2NYw4xulqJgvzkMF:
			name = name.encode(YWEQ3Cf8RevpD0m7NjF1)
			ZylHkumQ8zD0 = ZylHkumQ8zD0.encode(YWEQ3Cf8RevpD0m7NjF1)
		if '#' not in ZylHkumQ8zD0: items.append((name,ZylHkumQ8zD0))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for CQtNwXGVAJ2y5nBY in items:
		name,ZylHkumQ8zD0 = CQtNwXGVAJ2y5nBY
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+name,ZylHkumQ8zD0,518)
	return
def oXV1xKEYD4MBQ0aUNZkprgvdFPmWLq(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ELCINEMA-INDEXES_TITLES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	z1zyAncjpsw2MVg4PXt = LmbRNanktW4Yi3GBj6.BeautifulSoup(kl2ZWdy8rXcHT,'html.parser',multi_valued_attributes=None)
	Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q = z1zyAncjpsw2MVg4PXt.find(class_='expand').find_all('tr')
	for WWU7QJP2tyTRLIfDh0csxbkvX in Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q:
		y8a6iwkHLgfEF = WWU7QJP2tyTRLIfDh0csxbkvX.find_all('a')
		if not y8a6iwkHLgfEF: continue
		io76Hju84PtJO3hE5x9KZnpGmalIw = WWU7QJP2tyTRLIfDh0csxbkvX.find('img').get('data-src')
		name = y8a6iwkHLgfEF[1].text
		ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+y8a6iwkHLgfEF[1].get('href')
		EzkIN7wDlxMCGZ = WWU7QJP2tyTRLIfDh0csxbkvX.find(class_='legend')
		if EzkIN7wDlxMCGZ: EzkIN7wDlxMCGZ = EzkIN7wDlxMCGZ.text
		if cS2NYw4xulqJgvzkMF:
			name = name.encode(YWEQ3Cf8RevpD0m7NjF1)
			ZylHkumQ8zD0 = ZylHkumQ8zD0.encode(YWEQ3Cf8RevpD0m7NjF1)
			io76Hju84PtJO3hE5x9KZnpGmalIw = io76Hju84PtJO3hE5x9KZnpGmalIw.encode(YWEQ3Cf8RevpD0m7NjF1)
		Xxcm31HuozfbJEAv8Rl7PwUgGBF4 = {}
		if EzkIN7wDlxMCGZ: Xxcm31HuozfbJEAv8Rl7PwUgGBF4['stars'] = EzkIN7wDlxMCGZ
		if '/work/' in ZylHkumQ8zD0:
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+name,ZylHkumQ8zD0,516,io76Hju84PtJO3hE5x9KZnpGmalIw,nA5dhMRg6ENzsB0l1GwvH7aIr2,name,nA5dhMRg6ENzsB0l1GwvH7aIr2,Xxcm31HuozfbJEAv8Rl7PwUgGBF4)
		elif '/person/' in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+name,ZylHkumQ8zD0,513,io76Hju84PtJO3hE5x9KZnpGmalIw,nA5dhMRg6ENzsB0l1GwvH7aIr2,name,nA5dhMRg6ENzsB0l1GwvH7aIr2,Xxcm31HuozfbJEAv8Rl7PwUgGBF4)
	xxVd5HftDBAeLbmZTKkz(z1zyAncjpsw2MVg4PXt,518)
	return
def vvASlGOg2XskqCpn3(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ELCINEMA-VIDEOS_LISTS-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	z1zyAncjpsw2MVg4PXt = LmbRNanktW4Yi3GBj6.BeautifulSoup(kl2ZWdy8rXcHT,'html.parser',multi_valued_attributes=None)
	FwAWKXTqvQiL98jeJ2 = z1zyAncjpsw2MVg4PXt.find_all(class_='section-title inline')
	HRpMVv1x5ol9gbsnQquj = z1zyAncjpsw2MVg4PXt.find_all(class_='button green small right')
	items = zip(FwAWKXTqvQiL98jeJ2,HRpMVv1x5ol9gbsnQquj)
	for title,ZylHkumQ8zD0 in items:
		title = title.text
		ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0.get('href')
		if cS2NYw4xulqJgvzkMF:
			title = title.encode(YWEQ3Cf8RevpD0m7NjF1)
			ZylHkumQ8zD0 = ZylHkumQ8zD0.encode(YWEQ3Cf8RevpD0m7NjF1)
		title = title.replace(cqsuhi1JE7nNIfbPYQSpFgeGr,hSXlxL9iB05c).replace(PwYGfc4gTjiyRlsHn1OE,hSXlxL9iB05c).replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,521)
	return
def wioQstGrCLI(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ELCINEMA-VIDEOS_TITLES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	z1zyAncjpsw2MVg4PXt = LmbRNanktW4Yi3GBj6.BeautifulSoup(kl2ZWdy8rXcHT,'html.parser',multi_valued_attributes=None)
	uMDdmJUXgSLC6cjawPWVK = z1zyAncjpsw2MVg4PXt.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q = uMDdmJUXgSLC6cjawPWVK.find_all('li')
	for WWU7QJP2tyTRLIfDh0csxbkvX in Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q:
		title = WWU7QJP2tyTRLIfDh0csxbkvX.find(class_='title').text
		ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+WWU7QJP2tyTRLIfDh0csxbkvX.find('a').get('href')
		io76Hju84PtJO3hE5x9KZnpGmalIw = WWU7QJP2tyTRLIfDh0csxbkvX.find('img').get('data-src')
		yoaKx7FtIlvcD = WWU7QJP2tyTRLIfDh0csxbkvX.find(class_='duration').text
		if cS2NYw4xulqJgvzkMF:
			title = title.encode(YWEQ3Cf8RevpD0m7NjF1)
			ZylHkumQ8zD0 = ZylHkumQ8zD0.encode(YWEQ3Cf8RevpD0m7NjF1)
			io76Hju84PtJO3hE5x9KZnpGmalIw = io76Hju84PtJO3hE5x9KZnpGmalIw.encode(YWEQ3Cf8RevpD0m7NjF1)
			yoaKx7FtIlvcD = yoaKx7FtIlvcD.encode(YWEQ3Cf8RevpD0m7NjF1)
		yoaKx7FtIlvcD = yoaKx7FtIlvcD.replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c)
		TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,522,io76Hju84PtJO3hE5x9KZnpGmalIw,yoaKx7FtIlvcD)
	xxVd5HftDBAeLbmZTKkz(z1zyAncjpsw2MVg4PXt,521)
	return
def lNBcUr8RCn(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ELCINEMA-PLAY-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	z1zyAncjpsw2MVg4PXt = LmbRNanktW4Yi3GBj6.BeautifulSoup(kl2ZWdy8rXcHT,'html.parser',multi_valued_attributes=None)
	ZylHkumQ8zD0 = z1zyAncjpsw2MVg4PXt.find(class_='flex-video').find('iframe').get('src')
	if cS2NYw4xulqJgvzkMF: ZylHkumQ8zD0 = ZylHkumQ8zD0.encode(YWEQ3Cf8RevpD0m7NjF1)
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM([ZylHkumQ8zD0],wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	search = search.replace(hSXlxL9iB05c,'%20')
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/search/?q='+search
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ELCINEMA-SEARCH-1st')
	if not Y3SmVGbfNvEeakMBr.succeeded:
		jLevlJ4xCFsM7oq9hunwXmR2D = GiqvpBF9xLEdHDr37byJSngeCQ+'/search_entity/?q='+search+'&entity=work'
		ww5oBKPZmc = GiqvpBF9xLEdHDr37byJSngeCQ+'/search_entity/?q='+search+'&entity=person'
		nBr8XhiEG37A5LCad6fJm = GiqvpBF9xLEdHDr37byJSngeCQ+'/search_entity/?q='+search+'&entity=video'
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث عن أعمال',jLevlJ4xCFsM7oq9hunwXmR2D,513,nA5dhMRg6ENzsB0l1GwvH7aIr2,search)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث عن أشخاص',ww5oBKPZmc,513,nA5dhMRg6ENzsB0l1GwvH7aIr2,search)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث عن فيديوهات',nBr8XhiEG37A5LCad6fJm,513,nA5dhMRg6ENzsB0l1GwvH7aIr2,search)
		return
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	z1zyAncjpsw2MVg4PXt = LmbRNanktW4Yi3GBj6.BeautifulSoup(kl2ZWdy8rXcHT,'html.parser',multi_valued_attributes=None)
	Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q = z1zyAncjpsw2MVg4PXt.find_all(class_='section-title left')
	for WWU7QJP2tyTRLIfDh0csxbkvX in Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q:
		title = WWU7QJP2tyTRLIfDh0csxbkvX.text
		if cS2NYw4xulqJgvzkMF:
			title = title.encode(YWEQ3Cf8RevpD0m7NjF1)
		title = title.split('(',1)[0].strip(hSXlxL9iB05c)
		if   'أعمال' in title: ZylHkumQ8zD0 = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: ZylHkumQ8zD0 = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: ZylHkumQ8zD0 = url.replace('/search/','/search/video/')
		else: continue
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,513)
	return
def wJkMefCP0gq1VuT9z(url,text):
	global J8bDm67uSQ53EOUiltdTPRhcgNKY,F45fPJwzqEWNISAml
	if '/seasonals' in url:
		J8bDm67uSQ53EOUiltdTPRhcgNKY = ['seasonal','year','category']
		F45fPJwzqEWNISAml = ['seasonal','year','category']
	elif '/lineup' in url:
		J8bDm67uSQ53EOUiltdTPRhcgNKY = ['category','foreign','type']
		F45fPJwzqEWNISAml = ['category','foreign','type']
	NNihMcqGKQEvLz6l(url,text)
	return
def iBOFgUs6eTkIQyxKbqM(url):
	url = url.split('/smartemadfilter?')[0]
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ELCINEMA-GET_FILTERS_BLOCKS-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('form action="/(.*?)</form>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	AAkSjd9agcy = PAztbuyYo4Kvd.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	return AAkSjd9agcy
def vPOwqQ5zYHc10DVaSmU2ysG8k4t(WWU7QJP2tyTRLIfDh0csxbkvX):
	items = PAztbuyYo4Kvd.findall('<option value="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	return items
def GuvD6Ob3l0(url):
	YS4MDi1r3wOKFhTHjeEBIsag = url.split('/smartemadfilter?')[0]
	xTNCXea9SPBRb = C2gnJ5tXFk9pAL(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def exJmzaldQny6TgKq(QA6C8r4lEdhemfJPRc,url):
	OQmDdTI7hU4Lv3BfexPVKgRF8YN = EdpkojMzLm6b3ZSVcXwi0CPRIH(QA6C8r4lEdhemfJPRc,'all_filters')
	w7Ol6FnokgJDSsIt = url+'/smartemadfilter?'+OQmDdTI7hU4Lv3BfexPVKgRF8YN
	w7Ol6FnokgJDSsIt = GuvD6Ob3l0(w7Ol6FnokgJDSsIt)
	return w7Ol6FnokgJDSsIt
def NNihMcqGKQEvLz6l(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==nA5dhMRg6ENzsB0l1GwvH7aIr2: vvXcyZhkfV,guikd57yRSCMsNmlUqFHWAYL = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	else: vvXcyZhkfV,guikd57yRSCMsNmlUqFHWAYL = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if J8bDm67uSQ53EOUiltdTPRhcgNKY[0]+'=' not in vvXcyZhkfV: kvfOU7Tpz958QBqnIlaAePLys = J8bDm67uSQ53EOUiltdTPRhcgNKY[0]
		for q3kZpRe28O0s1NaCXQ9SMuGKin in range(len(J8bDm67uSQ53EOUiltdTPRhcgNKY[0:-1])):
			if J8bDm67uSQ53EOUiltdTPRhcgNKY[q3kZpRe28O0s1NaCXQ9SMuGKin]+'=' in vvXcyZhkfV: kvfOU7Tpz958QBqnIlaAePLys = J8bDm67uSQ53EOUiltdTPRhcgNKY[q3kZpRe28O0s1NaCXQ9SMuGKin+1]
		FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+kvfOU7Tpz958QBqnIlaAePLys+'=0'
		QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+kvfOU7Tpz958QBqnIlaAePLys+'=0'
		TB6HLPpacsK8f034jvYx7SNgFd = FqCItdu32L9hNwcEXWoges4R68KS.strip('&')+'___'+QA6C8r4lEdhemfJPRc.strip('&')
		OQmDdTI7hU4Lv3BfexPVKgRF8YN = EdpkojMzLm6b3ZSVcXwi0CPRIH(guikd57yRSCMsNmlUqFHWAYL,'modified_filters')
		KteRnFMjHpBPqNf8 = url+'/smartemadfilter?'+OQmDdTI7hU4Lv3BfexPVKgRF8YN
	elif type=='ALL_ITEMS_FILTER':
		iEa2qGQctFxX = EdpkojMzLm6b3ZSVcXwi0CPRIH(vvXcyZhkfV,'modified_values')
		iEa2qGQctFxX = pvOytL0nF7JY6flXTxAcHbQeNahu3(iEa2qGQctFxX)
		if guikd57yRSCMsNmlUqFHWAYL!=nA5dhMRg6ENzsB0l1GwvH7aIr2: guikd57yRSCMsNmlUqFHWAYL = EdpkojMzLm6b3ZSVcXwi0CPRIH(guikd57yRSCMsNmlUqFHWAYL,'modified_filters')
		if guikd57yRSCMsNmlUqFHWAYL==nA5dhMRg6ENzsB0l1GwvH7aIr2: KteRnFMjHpBPqNf8 = url
		else: KteRnFMjHpBPqNf8 = url+'/smartemadfilter?'+guikd57yRSCMsNmlUqFHWAYL
		KteRnFMjHpBPqNf8 = GuvD6Ob3l0(KteRnFMjHpBPqNf8)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'أظهار قائمة الفيديو التي تم اختيارها ',KteRnFMjHpBPqNf8,511)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+' [[   '+iEa2qGQctFxX+'   ]]',KteRnFMjHpBPqNf8,511)
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	AAkSjd9agcy = iBOFgUs6eTkIQyxKbqM(url)
	dict = {}
	for name,xWwIXcK0L61EBgtn7smr,WWU7QJP2tyTRLIfDh0csxbkvX in AAkSjd9agcy:
		name = name.replace('--',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		items = vPOwqQ5zYHc10DVaSmU2ysG8k4t(WWU7QJP2tyTRLIfDh0csxbkvX)
		if '=' not in KteRnFMjHpBPqNf8: KteRnFMjHpBPqNf8 = url
		if type=='SPECIFIED_FILTER':
			if xWwIXcK0L61EBgtn7smr not in J8bDm67uSQ53EOUiltdTPRhcgNKY: continue
			if kvfOU7Tpz958QBqnIlaAePLys!=xWwIXcK0L61EBgtn7smr: continue
			elif len(items)<2:
				if xWwIXcK0L61EBgtn7smr==J8bDm67uSQ53EOUiltdTPRhcgNKY[-1]:
					url = GuvD6Ob3l0(url)
					jm0Me6Ja47K(url)
				else: NNihMcqGKQEvLz6l(KteRnFMjHpBPqNf8,'SPECIFIED_FILTER___'+TB6HLPpacsK8f034jvYx7SNgFd)
				return
			else:
				KteRnFMjHpBPqNf8 = GuvD6Ob3l0(KteRnFMjHpBPqNf8)
				if xWwIXcK0L61EBgtn7smr==J8bDm67uSQ53EOUiltdTPRhcgNKY[-1]: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع',KteRnFMjHpBPqNf8,511)
				else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع',KteRnFMjHpBPqNf8,515,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,TB6HLPpacsK8f034jvYx7SNgFd)
		elif type=='ALL_ITEMS_FILTER':
			if xWwIXcK0L61EBgtn7smr not in F45fPJwzqEWNISAml: continue
			FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+xWwIXcK0L61EBgtn7smr+'=0'
			QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+xWwIXcK0L61EBgtn7smr+'=0'
			TB6HLPpacsK8f034jvYx7SNgFd = FqCItdu32L9hNwcEXWoges4R68KS+'___'+QA6C8r4lEdhemfJPRc
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع: '+name,KteRnFMjHpBPqNf8,514,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,TB6HLPpacsK8f034jvYx7SNgFd)
		dict[xWwIXcK0L61EBgtn7smr] = {}
		for value,DOT0LXwgoHYkFBC4MbxN53 in items:
			if DOT0LXwgoHYkFBC4MbxN53 in SAsGubf1jW2Q3p: continue
			if 'مصنفات أخرى' in DOT0LXwgoHYkFBC4MbxN53: continue
			if 'الكل' in DOT0LXwgoHYkFBC4MbxN53: continue
			if 'اللغة' in DOT0LXwgoHYkFBC4MbxN53: continue
			DOT0LXwgoHYkFBC4MbxN53 = DOT0LXwgoHYkFBC4MbxN53.replace('قائمة ',nA5dhMRg6ENzsB0l1GwvH7aIr2)
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[xWwIXcK0L61EBgtn7smr][value] = DOT0LXwgoHYkFBC4MbxN53
			FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+xWwIXcK0L61EBgtn7smr+'='+DOT0LXwgoHYkFBC4MbxN53
			QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+xWwIXcK0L61EBgtn7smr+'='+value
			b97AdvPkWGEBe3ayj1Jhmcq2LVxr = FqCItdu32L9hNwcEXWoges4R68KS+'___'+QA6C8r4lEdhemfJPRc
			if name: title = DOT0LXwgoHYkFBC4MbxN53+' :'+name
			else: title = DOT0LXwgoHYkFBC4MbxN53
			if type=='ALL_ITEMS_FILTER': TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,514,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,b97AdvPkWGEBe3ayj1Jhmcq2LVxr)
			elif type=='SPECIFIED_FILTER' and J8bDm67uSQ53EOUiltdTPRhcgNKY[-2]+'=' in vvXcyZhkfV:
				w7Ol6FnokgJDSsIt = exJmzaldQny6TgKq(QA6C8r4lEdhemfJPRc,url)
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,w7Ol6FnokgJDSsIt,511)
			else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,515,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,b97AdvPkWGEBe3ayj1Jhmcq2LVxr)
	return
def EdpkojMzLm6b3ZSVcXwi0CPRIH(tgsLX2uACmFhVznejRy6O,mode):
	tgsLX2uACmFhVznejRy6O = tgsLX2uACmFhVznejRy6O.replace('=&','=0&')
	tgsLX2uACmFhVznejRy6O = tgsLX2uACmFhVznejRy6O.strip('&')
	bpoRYqt38j = {}
	if '=' in tgsLX2uACmFhVznejRy6O:
		items = tgsLX2uACmFhVznejRy6O.split('&')
		for CQtNwXGVAJ2y5nBY in items:
			eehzynNs85aTHrgCUmFc3DBO12,value = CQtNwXGVAJ2y5nBY.split('=')
			bpoRYqt38j[eehzynNs85aTHrgCUmFc3DBO12] = value
	H5ROYNwvQFkBiVElThr = nA5dhMRg6ENzsB0l1GwvH7aIr2
	for key in F45fPJwzqEWNISAml:
		if key in list(bpoRYqt38j.keys()): value = bpoRYqt38j[key]
		else: value = '0'
		if '%' not in value: value = kGE6zoKSan54W(value)
		if mode=='modified_values' and value!='0': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+' + '+value
		elif mode=='modified_filters' and value!='0': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+'&'+key+'='+value
		elif mode=='all_filters': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+'&'+key+'='+value
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.strip(' + ')
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.strip('&')
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.replace('=0','=')
	return H5ROYNwvQFkBiVElThr
J8bDm67uSQ53EOUiltdTPRhcgNKY = []
F45fPJwzqEWNISAml = []
# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'ARABICTOONS'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_ART_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==730: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==731: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,text)
	elif mode==732: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==733: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LLabVp7hzj28CE0f1udx(url)
	elif mode==734: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ounHt8wI7DF0TBOY5ihPlE9c1Krb(url)
	elif mode==735: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = GnDrhWItXgMRkbi6w4zHYU3VLSKNa(url)
	elif mode==739: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,739,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'افلام',GiqvpBF9xLEdHDr37byJSngeCQ+'/movies.php',731)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مسلسلات',GiqvpBF9xLEdHDr37byJSngeCQ+'/cartoon.php',734)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مسلسلات مميزة',GiqvpBF9xLEdHDr37byJSngeCQ+'/top.php',735)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'أحدث الأفلام المضافة',GiqvpBF9xLEdHDr37byJSngeCQ,731,'','','LATEST_MOVIES')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'أحدث المسلسلات المضافة',GiqvpBF9xLEdHDr37byJSngeCQ,731,'','','LATEST_SERIES')
	return
def ounHt8wI7DF0TBOY5ihPlE9c1Krb(url):
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الكل',url,731)
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ARABICTOONS-SERIES_SUBMENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('label="navigation"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall("href='(.*?)'>(.*?)</a>",WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+ZylHkumQ8zD0
			title = 'حرف '+title
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,731)
	return
def GnDrhWItXgMRkbi6w4zHYU3VLSKNa(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ARABICTOONS-SERIES_FEATURED-2nd')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="slider"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for title,ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2 in items:
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+ZylHkumQ8zD0
			HRlygv7YwjzbSLt8fkEerq2 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+HRlygv7YwjzbSLt8fkEerq2
			title = title.strip(hSXlxL9iB05c)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,733,HRlygv7YwjzbSLt8fkEerq2)
	return
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,YsdSH10ta6wvi4nMRIO9):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ARABICTOONS-TITLES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall("class='moviesBlocks(.*?)list-group",kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if YsdSH10ta6wvi4nMRIO9=='LATEST_SERIES': WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[1]
	else: WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('class="movie".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
		ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+ZylHkumQ8zD0
		HRlygv7YwjzbSLt8fkEerq2 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+HRlygv7YwjzbSLt8fkEerq2
		title = title.strip(hSXlxL9iB05c)
		if 'movies.php' in url or YsdSH10ta6wvi4nMRIO9=='LATEST_MOVIES':
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,732,HRlygv7YwjzbSLt8fkEerq2)
		else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,733,HRlygv7YwjzbSLt8fkEerq2)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"pagination(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[-1]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?>(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+ZylHkumQ8zD0
			title = title.strip(hSXlxL9iB05c)
			title = HH8SJuswDBPtniebmkXIr(title)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+title,ZylHkumQ8zD0,731)
	return
def LLabVp7hzj28CE0f1udx(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ARABICTOONS-EPISODES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall("class='moviesBlocks(.*?)script",kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('class="movie".*?title="(.*?)".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for title,ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,hzpRwCnI98b in items:
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+ZylHkumQ8zD0
			HRlygv7YwjzbSLt8fkEerq2 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+HRlygv7YwjzbSLt8fkEerq2
			title = title.strip(hSXlxL9iB05c)
			title = title+hSXlxL9iB05c+hzpRwCnI98b.strip(hSXlxL9iB05c)
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,732,HRlygv7YwjzbSLt8fkEerq2)
	return
def lNBcUr8RCn(url):
	HtT6mBGwMaq1o0rybzZ4 = []
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ARABICTOONS-PLAY-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	HRpMVv1x5ol9gbsnQquj = PAztbuyYo4Kvd.findall('source src="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if HRpMVv1x5ol9gbsnQquj:
		ZylHkumQ8zD0 = HRpMVv1x5ol9gbsnQquj[0]
		if 'Referer=' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = ZylHkumQ8zD0+'|Referer=https://www.arabic-toons.com'
		HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0+'?named=__embed')
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(HtT6mBGwMaq1o0rybzZ4,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	search = search.replace(hSXlxL9iB05c,'%20')
	ce9zAaVFswSq6lLr82DfQyotGW = [nA5dhMRg6ENzsB0l1GwvH7aIr2,'m']
	AROQUxpWHVXSZ7Elcvdz5mL1JtFYD = ['مسلسلات','افلام']
	if showDialogs:
		iP7AUR41exzlKyZIf9Mt3u = ccAMwn7hflDev8Kd3aqP('اختر النوع المطلوب:', AROQUxpWHVXSZ7Elcvdz5mL1JtFYD)
		if iP7AUR41exzlKyZIf9Mt3u==-1: return
	else: iP7AUR41exzlKyZIf9Mt3u = 0
	type = ce9zAaVFswSq6lLr82DfQyotGW[iP7AUR41exzlKyZIf9Mt3u]
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/livesearch.php?'+type+'&q='+search
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'ARABICTOONS-SEARCH-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title in items:
		ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+ZylHkumQ8zD0
		title = title.strip(hSXlxL9iB05c)
		if type=='m': TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,732)
		else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,733)
	return
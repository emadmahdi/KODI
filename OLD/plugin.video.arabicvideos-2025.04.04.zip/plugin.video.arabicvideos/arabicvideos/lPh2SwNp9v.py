# -*- coding: utf-8 -*-
import sys as kCNHMOym1luTnJ0
MigYEN1cxduFB2lpk5 = kCNHMOym1luTnJ0.version_info [0] == 2
xJ3XdNcV5IujAkoGh = 2048
aE71QiuHI95zfPRBUsntedWZJ2bl = 7
def vR1b8iCLa9Qy2Sw5OYAlWXNhZp37 (AGxE4RIvuC6):
	global peWEVn47JRXo916j
	Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky = ord (AGxE4RIvuC6 [-1])
	FXUjnSw308z = AGxE4RIvuC6 [:-1]
	f81LoVwXMpQkvdKcmPyj6NzBlt = Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky % len (FXUjnSw308z)
	qyKv5nBTxgkQSlJ0aNP1CUmpjYLZ = FXUjnSw308z [:f81LoVwXMpQkvdKcmPyj6NzBlt] + FXUjnSw308z [f81LoVwXMpQkvdKcmPyj6NzBlt:]
	if MigYEN1cxduFB2lpk5:
		H0yFJ5LDCGYpIM1BViZKTSgv3jXr = unicode () .join ([unichr (ord (Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286) - xJ3XdNcV5IujAkoGh - (MfwWyztdYVXURgPqLrITku3CxF1 + Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky) % aE71QiuHI95zfPRBUsntedWZJ2bl) for MfwWyztdYVXURgPqLrITku3CxF1, Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286 in enumerate (qyKv5nBTxgkQSlJ0aNP1CUmpjYLZ)])
	else:
		H0yFJ5LDCGYpIM1BViZKTSgv3jXr = str () .join ([chr (ord (Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286) - xJ3XdNcV5IujAkoGh - (MfwWyztdYVXURgPqLrITku3CxF1 + Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky) % aE71QiuHI95zfPRBUsntedWZJ2bl) for MfwWyztdYVXURgPqLrITku3CxF1, Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286 in enumerate (qyKv5nBTxgkQSlJ0aNP1CUmpjYLZ)])
	return eval (H0yFJ5LDCGYpIM1BViZKTSgv3jXr)
Yj1msqVeivESfrCupRy9b7WacBd,XEcWOIwkZKubV7vQ,Pj9YaUq1ibJ=vR1b8iCLa9Qy2Sw5OYAlWXNhZp37,vR1b8iCLa9Qy2Sw5OYAlWXNhZp37,vR1b8iCLa9Qy2Sw5OYAlWXNhZp37
HD7MQqXd2gS,yPE2t1Co4YQDfsIecdxu0Gklq6AvO,bqCDnV7Bs5XgRvuKLNAa1Uz=Pj9YaUq1ibJ,XEcWOIwkZKubV7vQ,Yj1msqVeivESfrCupRy9b7WacBd
YIsyNBocg6fV3wEWPSu9GtvHxLOqDi,VVstJA9bfOqunLF0oaSgWUKHDdYNz,nfNTgkiWdUq=bqCDnV7Bs5XgRvuKLNAa1Uz,yPE2t1Co4YQDfsIecdxu0Gklq6AvO,HD7MQqXd2gS
FVxoQ2J5Mfv3Zj6sy9uhOS,n8BrpFLyaMAC1vP0bOHgwxEzeGRV,UUobzy0xZLaVScIt7=nfNTgkiWdUq,VVstJA9bfOqunLF0oaSgWUKHDdYNz,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi
JvQd6LMoBX4hiy1C,ZjELJ9VrUT07R8Hn4FuSDcf,pxt6wJ8ScYMWCivoO=UUobzy0xZLaVScIt7,n8BrpFLyaMAC1vP0bOHgwxEzeGRV,FVxoQ2J5Mfv3Zj6sy9uhOS
lw2snZ9J0uhLoxypqa,LJqSQvuhf7aMmnVjy23FbZBckKzx9l,gmPI7hVEM8nD=pxt6wJ8ScYMWCivoO,ZjELJ9VrUT07R8Hn4FuSDcf,JvQd6LMoBX4hiy1C
w0ivtSjV2sZDQoT1OEugIla7R6AC5M,rCmGE4YIDaZA,vzqjsVHSBlMpxC=gmPI7hVEM8nD,LJqSQvuhf7aMmnVjy23FbZBckKzx9l,lw2snZ9J0uhLoxypqa
xwIUQfiE7rmvYzH,ldIfvn6asURQ9toi85EhqAXW3,bb1fgjsAq4N2xYwnoh39lm=vzqjsVHSBlMpxC,rCmGE4YIDaZA,w0ivtSjV2sZDQoT1OEugIla7R6AC5M
AJHaiQq3PRd5cphzGuELnVg9X,jil8vRpBsENVYyPmDd,PPxYugzLZwHX23yiK=bb1fgjsAq4N2xYwnoh39lm,ldIfvn6asURQ9toi85EhqAXW3,xwIUQfiE7rmvYzH
baBcNd81eH5ry2Olp6Mj43,Qy6wlfLoOpg1,mRanX1HZupfSQVB2gsDGUO=PPxYugzLZwHX23yiK,jil8vRpBsENVYyPmDd,AJHaiQq3PRd5cphzGuELnVg9X
bDxWcjmaSgFeRKrfpJvyA4zThi,DFx6E0uON7Jm8,zhE5I4xHinX0UoVZMNwlkPrR=mRanX1HZupfSQVB2gsDGUO,Qy6wlfLoOpg1,baBcNd81eH5ry2Olp6Mj43
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = lw2snZ9J0uhLoxypqa(u"ࠨࡔࡄࡒࡉࡕࡍࡔࠩᨬ")
DjKrTPWEFw2YeCi5d6unBqhZSlAR = XEcWOIwkZKubV7vQ(u"ࠩࡢࡐࡘ࡚࡟ࠨᨭ")
Pkf0RaNHAUsqMKCzb6J7WSmwFOnG = tpMX1Bgs0bzv8OEafyW
rZeA4mhYJX0Tj83WdcGqOl = mRanX1HZupfSQVB2gsDGUO(u"࠶࠶Ი")
def YYdDUV01oAtQljRBxO9enrEXHwfC(knBV0UPuCNdpIsAFH3coRKjh2lb,url,OOrjZaTIVXQ2Sp0ozhc,Q0f7ytucSriRw8HTzd,Xxcm31HuozfbJEAv8Rl7PwUgGBF4):
	try: QLSRWqIZ71KXcsJO2 = str(Xxcm31HuozfbJEAv8Rl7PwUgGBF4[n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠪࡪࡴࡲࡤࡦࡴࠪᨮ")])
	except: QLSRWqIZ71KXcsJO2 = nA5dhMRg6ENzsB0l1GwvH7aIr2
	if   knBV0UPuCNdpIsAFH3coRKjh2lb==vzqjsVHSBlMpxC(u"࠷࠶࠱Კ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠱࠷࠳Ლ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = P9hzNHqT7XGpc8ove4SrtuOxYaCim(OOrjZaTIVXQ2Sp0ozhc)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==AJHaiQq3PRd5cphzGuELnVg9X(u"࠲࠸࠵Მ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = I06Rawhn4XT2fb8QPgt9vxpLCE5q(OOrjZaTIVXQ2Sp0ozhc,AJHaiQq3PRd5cphzGuELnVg9X(u"࠲࠸࠵Მ"))
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠳࠹࠷Ნ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = I06Rawhn4XT2fb8QPgt9vxpLCE5q(OOrjZaTIVXQ2Sp0ozhc,bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠳࠹࠷Ნ"))
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==AJHaiQq3PRd5cphzGuELnVg9X(u"࠴࠺࠹Ო"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = va8SiyTtNq6OwAeguPGs(OOrjZaTIVXQ2Sp0ozhc)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==xwIUQfiE7rmvYzH(u"࠵࠻࠻Პ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = SPB0sZ6YzyJQctjFmfro(url,OOrjZaTIVXQ2Sp0ozhc)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠶࠼࠶Ჟ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = KBb3w9L5MVNqZtIO(url,OOrjZaTIVXQ2Sp0ozhc)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠷࠶࠸Რ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = BWKk5bsi2FvSzq(url,OOrjZaTIVXQ2Sp0ozhc)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==zhE5I4xHinX0UoVZMNwlkPrR(u"࠱࠷࠺Ს"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = fzVRjEIm1Gr5MKSHC23FeNh7(url,OOrjZaTIVXQ2Sp0ozhc)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠸࠸࠴Ტ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = MlniXwLec5FSamdRx9zK10CEDBugbv()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==Pj9YaUq1ibJ(u"࠹࠹࠶Უ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = H07b5ymw8lfZBcIeTsRStqiKG9()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==zhE5I4xHinX0UoVZMNwlkPrR(u"࠺࠺࠸Ფ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = H8eh2Q1T0mk4bEfJaYF73cP(QLSRWqIZ71KXcsJO2,OOrjZaTIVXQ2Sp0ozhc,Q0f7ytucSriRw8HTzd)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==vzqjsVHSBlMpxC(u"࠻࠻࠺Ქ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = oPj2IkmwrRE(QLSRWqIZ71KXcsJO2,OOrjZaTIVXQ2Sp0ozhc)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠼࠼࠵Ღ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = zlLQBJmqfciaKSd9g(QLSRWqIZ71KXcsJO2,OOrjZaTIVXQ2Sp0ozhc)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = FFKncZx5pDTwdiJRYhMgQSNL
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL(bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᨯ"),zhE5I4xHinX0UoVZMNwlkPrR(u"่ࠬๆ้ษอࠤฯ๊แำ์๋๊ࠥ฿ิ้ษษ๎ฮ࠭ᨰ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,lw2snZ9J0uhLoxypqa(u"࠷࠶࠲Ყ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jil8vRpBsENVYyPmDd(u"࠭࡟ࡍࡋ࡙ࡉ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᨱ"))
	TBt8bUDo9WhL(XEcWOIwkZKubV7vQ(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᨲ"),HD7MQqXd2gS(u"ࠨไึ้ࠥ฿ิ้ษษ๎ࠬᨳ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nfNTgkiWdUq(u"࠱࠷࠴Შ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,DFx6E0uON7Jm8(u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᨴ"))
	TBt8bUDo9WhL(Yj1msqVeivESfrCupRy9b7WacBd(u"ࠪࡪࡴࡲࡤࡦࡴࠪᨵ"),AJHaiQq3PRd5cphzGuELnVg9X(u"ࠫๆ๐ฯ๋๊๊หฯูࠦี๊สส๏ฯࠧᨶ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠲࠸࠶Ჩ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,zhE5I4xHinX0UoVZMNwlkPrR(u"ࠬࡥࡓࡊࡖࡈࡗࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᨷ"))
	TBt8bUDo9WhL(rCmGE4YIDaZA(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᨸ"),bb1fgjsAq4N2xYwnoh39lm(u"ࠧโ์า๎ํํวหࠢหัะูࠦี๊สส๏࠭ᨹ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,Yj1msqVeivESfrCupRy9b7WacBd(u"࠳࠹࠸Ც"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,mRanX1HZupfSQVB2gsDGUO(u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᨺ"))
	TBt8bUDo9WhL(xwIUQfiE7rmvYzH(u"ࠩࡩࡳࡱࡪࡥࡳࠩᨻ"),gmPI7hVEM8nD(u"ࠪๅ๏ี๊้้สฮࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื๊࠭ᨼ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,gmPI7hVEM8nD(u"࠺࠺࠸Ძ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,Pj9YaUq1ibJ(u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࡤࡘࡁࡏࡆࡒࡑࡤ࠭ᨽ"))
	TBt8bUDo9WhL(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠬࡲࡩ࡯࡭ࠪᨾ"),bbTCMJwEx8nhN4X+Qy6wlfLoOpg1(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬᨿ")+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠽࠾࠿࠹Წ"))
	TBt8bUDo9WhL(nfNTgkiWdUq(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᩀ"),PPxYugzLZwHX23yiK(u"ࠨไ้์ฬะࠠࡎ࠵ࡘࠤ฾ฺ่ศศํอࠬᩁ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠶࠼࠳Ჭ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠩࡢࡑ࠸࡛࡟ࡠࡎࡌ࡚ࡊࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᩂ"))
	TBt8bUDo9WhL(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠪࡪࡴࡲࡤࡦࡴࠪᩃ"),n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠫๆ๐ฯ๋๊๊หฯࠦࡍ࠴ࡗࠣ฽ู๎วว์ฬࠫᩄ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,DFx6E0uON7Jm8(u"࠷࠶࠴Ხ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,UUobzy0xZLaVScIt7(u"ࠬࡥࡍ࠴ࡗࡢࡣ࡛ࡕࡄࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᩅ"))
	TBt8bUDo9WhL(nfNTgkiWdUq(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᩆ"),vzqjsVHSBlMpxC(u"ࠧใี่ࠤ็์่ศฬࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ࠧᩇ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,lw2snZ9J0uhLoxypqa(u"࠱࠷࠴Ჯ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,Qy6wlfLoOpg1(u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᩈ"))
	TBt8bUDo9WhL(rCmGE4YIDaZA(u"ࠩࡩࡳࡱࡪࡥࡳࠩᩉ"),HD7MQqXd2gS(u"ࠪๆุ๋ࠠโ์า๎ํࠦࡍ࠴ࡗࠣ฽ู๎วว์ࠪᩊ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,xwIUQfiE7rmvYzH(u"࠲࠸࠵Ჰ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,baBcNd81eH5ry2Olp6Mj43(u"ࠫࡤࡓ࠳ࡖࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᩋ"))
	TBt8bUDo9WhL(LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᩌ"),Yj1msqVeivESfrCupRy9b7WacBd(u"࠭แ๋ัํ์์อสࠡࡏ࠶࡙ࠥฮอฬࠢ฼ุํอฦ๋ࠩᩍ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,ldIfvn6asURQ9toi85EhqAXW3(u"࠳࠹࠸Ჱ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,HD7MQqXd2gS(u"ࠧࡠࡏ࠶࡙ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᩎ"))
	TBt8bUDo9WhL(vzqjsVHSBlMpxC(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᩏ"),PPxYugzLZwHX23yiK(u"ࠩไ๎ิ๐่่ษอࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊ส่๊่ࠢࠥำๆࠩᩐ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠺࠺࠺Ჲ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠪࡣࡒ࠹ࡕࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᩑ"))
	TBt8bUDo9WhL(VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠫࡱ࡯࡮࡬ࠩᩒ"),bbTCMJwEx8nhN4X+AJHaiQq3PRd5cphzGuELnVg9X(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫᩓ")+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,UUobzy0xZLaVScIt7(u"࠽࠾࠿࠹Ჳ"))
	TBt8bUDo9WhL(bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᩔ"),ldIfvn6asURQ9toi85EhqAXW3(u"ࠧใ่๋หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํอࠬᩕ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,ZjELJ9VrUT07R8Hn4FuSDcf(u"࠶࠼࠳Ჴ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,zhE5I4xHinX0UoVZMNwlkPrR(u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡎࡌ࡚ࡊࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᩖ"))
	TBt8bUDo9WhL(gmPI7hVEM8nD(u"ࠩࡩࡳࡱࡪࡥࡳࠩᩗ"),UUobzy0xZLaVScIt7(u"ࠪๅ๏ี๊้้สฮࠥࡏࡐࡕࡘࠣ฽ู๎วว์ฬࠫᩘ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,mRanX1HZupfSQVB2gsDGUO(u"࠷࠶࠴Ჵ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,lw2snZ9J0uhLoxypqa(u"ࠫࡤࡏࡐࡕࡘࡢࡣ࡛ࡕࡄࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᩙ"))
	TBt8bUDo9WhL(gmPI7hVEM8nD(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᩚ"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠭โิ็ࠣๆ๋๎วหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ࠧᩛ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,DFx6E0uON7Jm8(u"࠱࠷࠴Ჶ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,baBcNd81eH5ry2Olp6Mj43(u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᩜ"))
	TBt8bUDo9WhL(Qy6wlfLoOpg1(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᩝ"),bb1fgjsAq4N2xYwnoh39lm(u"ࠩๅื๊ࠦแ๋ัํ์ࠥࡏࡐࡕࡘࠣ฽ู๎วว์ࠪᩞ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠲࠸࠵Ჷ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,Yj1msqVeivESfrCupRy9b7WacBd(u"ࠪࡣࡎࡖࡔࡗࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ᩟"))
	TBt8bUDo9WhL(mRanX1HZupfSQVB2gsDGUO(u"ࠫ࡫ࡵ࡬ࡥࡧࡵ᩠ࠫ"),zhE5I4xHinX0UoVZMNwlkPrR(u"ࠬ็๊ะ์๋๋ฬะࠠࡊࡒࡗ࡚ࠥฮอฬࠢ฼ุํอฦ๋ࠩᩡ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠳࠹࠸Ჸ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,Pj9YaUq1ibJ(u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᩢ"))
	TBt8bUDo9WhL(Yj1msqVeivESfrCupRy9b7WacBd(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᩣ"),Pj9YaUq1ibJ(u"ࠨใํำ๏๎็ศฬࠣࡍࡕ࡚ࡖࠡ฻ื์ฬฬ๊ส่๊่ࠢࠥำๆࠩᩤ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,Yj1msqVeivESfrCupRy9b7WacBd(u"࠺࠺࠹Ჹ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,DFx6E0uON7Jm8(u"ࠩࡢࡍࡕ࡚ࡖࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᩥ"))
	return
def MlniXwLec5FSamdRx9zK10CEDBugbv():
	TBt8bUDo9WhL(JvQd6LMoBX4hiy1C(u"ࠪࡪࡴࡲࡤࡦࡴࠪᩦ"),xwIUQfiE7rmvYzH(u"ࠫࡤࡏࡐࡕࡡࠪᩧ")+jil8vRpBsENVYyPmDd(u"ࠬ็๊ะ์๋๋ฬะࠠอ็ํ฽ࠥࡏࡐࡕࡘࠪᩨ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,vzqjsVHSBlMpxC(u"࠻࠻࠺Ჺ"))
	TBt8bUDo9WhL(baBcNd81eH5ry2Olp6Mj43(u"࠭࡬ࡪࡰ࡮ࠫᩩ"),bbTCMJwEx8nhN4X+Yj1msqVeivESfrCupRy9b7WacBd(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬᩪ")+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,lw2snZ9J0uhLoxypqa(u"࠾࠿࠹࠺᲻"))
	for QLSRWqIZ71KXcsJO2 in range(UnOIK1WBbw2,EYcbkTrLd8MqHSXzxFGft+UnOIK1WBbw2):
		DjKrTPWEFw2YeCi5d6unBqhZSlAR = HD7MQqXd2gS(u"ࠨࡡࡌࡔࠬᩫ")+str(QLSRWqIZ71KXcsJO2)+rCmGE4YIDaZA(u"ࠩࡢࠫᩬ")
		TBt8bUDo9WhL(ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠪࡪࡴࡲࡤࡦࡴࠪᩭ"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+zhE5I4xHinX0UoVZMNwlkPrR(u"ࠫࠥ็๊ะ์๋๋ฬะࠠๆฮ็ำࠥ࠭ᩮ")+c0Qs8Db7KdxGzt[QLSRWqIZ71KXcsJO2],nA5dhMRg6ENzsB0l1GwvH7aIr2,FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠽࠶࠵᲼"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,{n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᩯ"):QLSRWqIZ71KXcsJO2})
	return
def H07b5ymw8lfZBcIeTsRStqiKG9():
	TBt8bUDo9WhL(w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᩰ"),xwIUQfiE7rmvYzH(u"ࠧࡠࡏ࠶࡙ࡤ࠭ᩱ")+HD7MQqXd2gS(u"ࠨใํำ๏๎็ศฬࠣะ๊๐ูࠡࡏ࠶࡙ࠬᩲ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,Qy6wlfLoOpg1(u"࠷࠷࠷Ჽ"))
	TBt8bUDo9WhL(xwIUQfiE7rmvYzH(u"ࠩ࡯࡭ࡳࡱࠧᩳ"),bbTCMJwEx8nhN4X+zhE5I4xHinX0UoVZMNwlkPrR(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨᩴ")+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,Yj1msqVeivESfrCupRy9b7WacBd(u"࠺࠻࠼࠽Ჾ"))
	for QLSRWqIZ71KXcsJO2 in range(UnOIK1WBbw2,EYcbkTrLd8MqHSXzxFGft+UnOIK1WBbw2):
		DjKrTPWEFw2YeCi5d6unBqhZSlAR = vzqjsVHSBlMpxC(u"ࠫࡤࡓࡕࠨ᩵")+str(QLSRWqIZ71KXcsJO2)+HD7MQqXd2gS(u"ࠬࡥࠧ᩶")
		TBt8bUDo9WhL(ldIfvn6asURQ9toi85EhqAXW3(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᩷"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠧࠡใํำ๏๎็ศฬ้ࠣั๊ฯࠡࠩ᩸")+c0Qs8Db7KdxGzt[QLSRWqIZ71KXcsJO2],nA5dhMRg6ENzsB0l1GwvH7aIr2,baBcNd81eH5ry2Olp6Mj43(u"࠹࠹࠹Ჿ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,{VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᩹"):QLSRWqIZ71KXcsJO2})
	return
def qwfSnTtDvgRPa(whXU4NCbPdFAcxErVJIutR8WDM3n):
	global ns1UjyrKQIT28l6,mUOd89K7MvRwb
	hT9D8fRSNgycG36k,vlm7dBDy2RXPj1C8,CYv7ydT6WAGtu0o = EN1Pg52zbjsmLMQq9(whXU4NCbPdFAcxErVJIutR8WDM3n)
	try:
		if jil8vRpBsENVYyPmDd(u"ࠩࡌࡊࡎࡒࡍࠨ᩺") in whXU4NCbPdFAcxErVJIutR8WDM3n: hT9D8fRSNgycG36k(whXU4NCbPdFAcxErVJIutR8WDM3n)
		else: hT9D8fRSNgycG36k()
		qV8v3EITJ4A0WdbsFcerM = FFKncZx5pDTwdiJRYhMgQSNL
	except:
		GznfPAD8ard3y4h()
		qV8v3EITJ4A0WdbsFcerM = S5MWhgtZ37Xw
	whXU4NCbPdFAcxErVJIutR8WDM3n = AEyNnLOu7g6BGrw5tlcj(whXU4NCbPdFAcxErVJIutR8WDM3n)
	if qV8v3EITJ4A0WdbsFcerM:
		ggYilKR5rMDyp7B(whXU4NCbPdFAcxErVJIutR8WDM3n,LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠪๅู๊ࠠๅๆฦืๆ࠭᩻"),h0skHe7TcIY9x1UP5VBrZAE8dKGnl=vzqjsVHSBlMpxC(u"࠵࠴࠵࠶᳀"))
		ns1UjyrKQIT28l6 += UnOIK1WBbw2
		mUOd89K7MvRwb += baBcNd81eH5ry2Olp6Mj43(u"ࠫࠥ࠴ࠠࠨ᩼")+whXU4NCbPdFAcxErVJIutR8WDM3n
	else: ggYilKR5rMDyp7B(whXU4NCbPdFAcxErVJIutR8WDM3n,nA5dhMRg6ENzsB0l1GwvH7aIr2,h0skHe7TcIY9x1UP5VBrZAE8dKGnl=bb1fgjsAq4N2xYwnoh39lm(u"࠵࠵࠶࠰᳁"))
	return
Vjy0JqnlGvRbiN1z5roxI3KCkX = {}
def NDGKQC9HV0(MMyVfkeKptZgPTcEiC=S5MWhgtZ37Xw):
	global ns1UjyrKQIT28l6,mUOd89K7MvRwb,Vjy0JqnlGvRbiN1z5roxI3KCkX
	if not MMyVfkeKptZgPTcEiC:
		Vjy0JqnlGvRbiN1z5roxI3KCkX = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,vzqjsVHSBlMpxC(u"ࠬࡪࡩࡤࡶࠪ᩽"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ࡙ࠧ᩾"),gmPI7hVEM8nD(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡖࡍ࡙ࡋࡓࡠࡃࡏࡐ᩿ࠬ"))
		if Vjy0JqnlGvRbiN1z5roxI3KCkX: return
	x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ᪀"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠩะฮ๎ࠦสๆๆษࠤ์ึ็ࠡษ็ๆฬฬๅสࠢ࠱࠲ู๊ࠥโฯุࠤฬ๊ศา่ส้ัࠦฬๆ์฼ࠤ๊๎วใ฻ࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢไ๎ࠥอไษำ้ห๊าࠠฮฬ์ࠤ๏ูสฯำฯࠤ๊์็ศࠢไๆ฼ࠦวๅลๅืฬ๋ࠠศๆิส๏ู๊สࠢ࠱࠲ࠥัๅࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡสัึ๋ࠦ็ั้ࠣห้ษโิษ่ࠤาะ้ࠡๆสࠤฯำสศฮࠣว๋ࠦสๆๆษ๋ฬࠦๅาหࠣวำื้ࠡ࠰࠱ࠤ์ึ็ࠡษ็฽๊๊๊สࠢอัฯอฬࠡ฻สำฮࠦรใๆ้๋ࠣࠦ࠳ࠡัๅหห่ࠠ࡝ࡰ࡟ࡲࠬ᪁")+bbTCMJwEx8nhN4X+zhE5I4xHinX0UoVZMNwlkPrR(u"๋้ࠪࠦสา์าࠤศ์ࠠหฮ่฽่ࠥวว็ฬࠤฬ๊รใีส้ࠥอไร่ࠣรࠬ᪂")+NwROdSj3nsA)
	if x6zlf2tTZm!=UnOIK1WBbw2: return
	RUEwdIv5WrlKDFhTBe(oZqKcvlJx1pTLN2ske5f0PtVrw,oZqKcvlJx1pTLN2ske5f0PtVrw,oZqKcvlJx1pTLN2ske5f0PtVrw)
	l0lCN6kzwHg = Nzp9Fq5cTr.menuItemsLIST
	ns1UjyrKQIT28l6,mUOd89K7MvRwb,threads = IpFcwrWNgefMym3qta0hYQAzOdE,nA5dhMRg6ENzsB0l1GwvH7aIr2,{}
	for whXU4NCbPdFAcxErVJIutR8WDM3n in uWb2o5k9HiaF436GL8TlDIhnvXJ:
		h0skHe7TcIY9x1UP5VBrZAE8dKGnl.sleep(UnOIK1WBbw2)
		threads[whXU4NCbPdFAcxErVJIutR8WDM3n] = QCxDqOcS9z586(daemon=S5MWhgtZ37Xw,target=qwfSnTtDvgRPa,args=(whXU4NCbPdFAcxErVJIutR8WDM3n,))
		threads[whXU4NCbPdFAcxErVJIutR8WDM3n].start()
	else:
		for whXU4NCbPdFAcxErVJIutR8WDM3n in list(threads.keys()): threads[whXU4NCbPdFAcxErVJIutR8WDM3n].join()
	Nzp9Fq5cTr.menuItemsLIST[:] = l0lCN6kzwHg
	Vjy0JqnlGvRbiN1z5roxI3KCkX = {}
	for whXU4NCbPdFAcxErVJIutR8WDM3n in list(threads.keys()):
		try: njkrTx0vBEmLIzCR4d5g = Nzp9Fq5cTr.menuItemsDICT[whXU4NCbPdFAcxErVJIutR8WDM3n]
		except: continue
		whXU4NCbPdFAcxErVJIutR8WDM3n = ldIfvn6asURQ9toi85EhqAXW3(u"ࠫࡤࡒࡓࡕࡡࠪ᪃")+AEyNnLOu7g6BGrw5tlcj(whXU4NCbPdFAcxErVJIutR8WDM3n)
		for WTavfhd7QJDABwpIVrZqHL,w8cPT5nhW2RUAFKDa,kOTdpYrPqu5A7UIcW0Ch,knBV0UPuCNdpIsAFH3coRKjh2lb,czMOJaKwoCnSPuNTd9bIH8pfLy72W5,QbuYlX5ctHaGp42jNef8,OOrjZaTIVXQ2Sp0ozhc,qjyki7XR1FW,Gv80f9tpWiRL in njkrTx0vBEmLIzCR4d5g:
			if not w8cPT5nhW2RUAFKDa: w8cPT5nhW2RUAFKDa = LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠬ࠴࠮࠯࠰ࠪ᪄")
			else:
				if w8cPT5nhW2RUAFKDa.count(bb1fgjsAq4N2xYwnoh39lm(u"࠭࡟ࠨ᪅"))>UnOIK1WBbw2: w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.split(UUobzy0xZLaVScIt7(u"ࠧࡠࠩ᪆"),udq5tP0hwifHQCGYELDbOUI)[udq5tP0hwifHQCGYELDbOUI]
				w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(Yj1msqVeivESfrCupRy9b7WacBd(u"ࠨࢢࠪ᪇"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(jil8vRpBsENVYyPmDd(u"ࠩࠣࡌࡉ࠭᪈"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠪࡌࡉࠦࠧ᪉"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
				w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠫๅ࠭᪊"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(AJHaiQq3PRd5cphzGuELnVg9X(u"ࠬฯࠧ᪋"),bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠭็ࠨ᪌")).replace(rCmGE4YIDaZA(u"ࠧลࠩ᪍"),Qy6wlfLoOpg1(u"ࠨ๊ࠪ᪎"))
				w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠩฦࠫ᪏"),HD7MQqXd2gS(u"ࠪหࠬ᪐")).replace(bb1fgjsAq4N2xYwnoh39lm(u"ࠫส࠭᪑"),jil8vRpBsENVYyPmDd(u"ࠬอࠧ᪒")).replace(Qy6wlfLoOpg1(u"࠭ยࠨ᪓"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠧศࠩ᪔"))
				w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(UUobzy0xZLaVScIt7(u"ࠨๆฦࠫ᪕"),lw2snZ9J0uhLoxypqa(u"ࠩ็หࠬ᪖")).replace(xwIUQfiE7rmvYzH(u"่ࠪส࠭᪗"),ZjELJ9VrUT07R8Hn4FuSDcf(u"้ࠫอࠧ᪘")).replace(xwIUQfiE7rmvYzH(u"๊ࠬยࠨ᪙"),baBcNd81eH5ry2Olp6Mj43(u"࠭ไศࠩ᪚"))
				w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(JvQd6LMoBX4hiy1C(u"ࠧ๏ࠩ᪛"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠨํࠪ᪜"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(lw2snZ9J0uhLoxypqa(u"ࠩ๒ࠫ᪝"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(gmPI7hVEM8nD(u"ࠪ๐ࠬ᪞"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
				w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(bb1fgjsAq4N2xYwnoh39lm(u"ࠫ๕࠭᪟"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(AJHaiQq3PRd5cphzGuELnVg9X(u"ࠬ๓ࠧ᪠"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(HD7MQqXd2gS(u"࠭๒ࠨ᪡"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(gmPI7hVEM8nD(u"ࠧ๒ࠩ᪢"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
				w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠨࡾࠪ᪣"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(Pj9YaUq1ibJ(u"ࠩࢁࠫ᪤"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
				w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(XEcWOIwkZKubV7vQ(u"ࠪหํ์ࠠๅษํ๊ࠬ᪥"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(XEcWOIwkZKubV7vQ(u"ุࠫ๐ๅศࠢ็ห๏ะࠧ᪦"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
				wuil5r8pAkdE2HP6VtfeC = [UUobzy0xZLaVScIt7(u"ࠬอไฺษหࠫᪧ"),bb1fgjsAq4N2xYwnoh39lm(u"࠭ฮ๋ษ็ࠫ᪨"),jil8vRpBsENVYyPmDd(u"ࠧศๆห์๊࠭᪩"),XEcWOIwkZKubV7vQ(u"ࠨษ็ห๋࠭᪪"),nfNTgkiWdUq(u"ࠩส฻ๆอไࠨ᪫"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠪัฬ๊๊่ࠩ᪬"),bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠫฬฺ๊ศิࠪ᪭"),bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠬ฻วๅฯࠪ᪮"),bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠭วๅัํ๊ࠬ᪯"),n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠧๆ๊ส่๏ีࠧ᪰"),gmPI7hVEM8nD(u"ࠨษ็฽ฬ๊ๅࠨ᪱"),HD7MQqXd2gS(u"ࠩส฽๊อไࠨ᪲")]
				if not any(jS6mozBH5x87aliFAUZqgJRMI2rG in w8cPT5nhW2RUAFKDa for jS6mozBH5x87aliFAUZqgJRMI2rG in wuil5r8pAkdE2HP6VtfeC): w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(lw2snZ9J0uhLoxypqa(u"ࠪห้࠭᪳"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
				w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠫฬิั๋ࠩ᪴"),HD7MQqXd2gS(u"ࠬอฮา๋᪵ࠪ")).replace(rCmGE4YIDaZA(u"࠭วอ่หํ᪶ࠬ"),vzqjsVHSBlMpxC(u"ࠧศฮ้ฬ๏᪷࠭")).replace(XEcWOIwkZKubV7vQ(u"ࠨ฻สส้๐็ࠨ᪸"),PPxYugzLZwHX23yiK(u"ࠩ฼หห๊๊ࠨ᪹"))
				w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(Qy6wlfLoOpg1(u"ࠪหั์ศ๋้᪺ࠪ"),JvQd6LMoBX4hiy1C(u"ࠫฬาๆษ์ࠪ᪻")).replace(Pj9YaUq1ibJ(u"ࠬ฿ัษ์๊ࠫ᪼"),XEcWOIwkZKubV7vQ(u"ู࠭าสํ᪽ࠫ")).replace(xwIUQfiE7rmvYzH(u"ࠧา๊่หู๋๊่ࠩ᪾"),ldIfvn6asURQ9toi85EhqAXW3(u"ࠨำ๋้ฬ์ำ๋ᪿࠩ"))
				w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠩ฽ีอ๐็ࠨᫀ"),n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠪ฾ึฮ๊ࠨ᫁")).replace(nfNTgkiWdUq(u"ࠫํࠦๅิๆึ่ฬะࠧ᫂"),baBcNd81eH5ry2Olp6Mj43(u"๋ࠬำๅี็หฯ᫃࠭")).replace(bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠭ว฻ษ้ํ᫄ࠬ"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠧศ฼ส๊๏࠭᫅"))
				w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(AJHaiQq3PRd5cphzGuELnVg9X(u"ࠨฬสี๏ิ๊ࠨ᫆"),ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠩอหึ๐ฮࠨ᫇")).replace(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠪา๏อไࠡ฻็้๏࠭᫈"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠫำ๐วๅࠩ᫉")).replace(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"๋่ࠬิ์ๅ๎์᫊࠭"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠭ๅ้ีํๆ๎࠭᫋"))
				w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(FVxoQ2J5Mfv3Zj6sy9uhOS(u"่่ࠧาํࠬᫌ"),zhE5I4xHinX0UoVZMNwlkPrR(u"ࠨ้้ำ๏࠭ᫍ")).replace(AJHaiQq3PRd5cphzGuELnVg9X(u"๊๊ࠩิ๐็ࠨᫎ"),gmPI7hVEM8nD(u"๋๋ࠪี๊ࠨ᫏")).replace(YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠫํัววไํ๋ࠬ᫐"),XEcWOIwkZKubV7vQ(u"ࠬ๎หศศๅ๎ࠬ᫑"))
				w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(pxt6wJ8ScYMWCivoO(u"࠭สๅ์ไึ๏๎ๆ๋้ࠪ᫒"),ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠧหๆไึ๏๎ๆࠨ᫓")).replace(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠨฬ็ๅื๐่็์๊ࠫ᫔"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠩอ่ๆุ๊้่ࠪ᫕")).replace(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠪ์้ࠥัห๊้ࠫ᫖"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠫํ้ัห๊้ࠫ᫗"))
				w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(JvQd6LMoBX4hiy1C(u"ࠬอไฮษ็๎์࠭᫘"),Yj1msqVeivESfrCupRy9b7WacBd(u"࠭อศๆํ๋ࠬ᫙")).replace(jil8vRpBsENVYyPmDd(u"ࠧๆ๊ึ໐็๐ࠧ᫚"),n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠨ็๋ื๏่้ࠨ᫛")).replace(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠩส่ฬ์ๅ๋ࠩ᫜"),bb1fgjsAq4N2xYwnoh39lm(u"ࠪห๋๋๊ࠨ᫝"))
				w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(rCmGE4YIDaZA(u"ࠫฬ๊ๅิๆึ่ฬะࠧ᫞"),HD7MQqXd2gS(u"๋ࠬำๅี็หฯ࠭᫟")).replace(XEcWOIwkZKubV7vQ(u"࠭วๅสิห๊าࠧ᫠"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠧษำส้ั࠭᫡")).replace(UUobzy0xZLaVScIt7(u"ࠨๅสีฯ๎ๆࠨ᫢"),bb1fgjsAq4N2xYwnoh39lm(u"ࠩๆีฯ๎ๆࠨ᫣"))
				w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(Yj1msqVeivESfrCupRy9b7WacBd(u"ࠪัึ๎ศࠨ᫤"),JvQd6LMoBX4hiy1C(u"ࠫาืศࠨ᫥")).replace(bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠬอไศ่สุ๏ีࠧ᫦"),ldIfvn6asURQ9toi85EhqAXW3(u"࠭ว็ษื๎ิ࠭᫧")).replace(bb1fgjsAq4N2xYwnoh39lm(u"ࠧศีํ์๏ํࠧ᫨"),mRanX1HZupfSQVB2gsDGUO(u"ࠨษึ๎ํ๐ࠧ᫩"))
				w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(vzqjsVHSBlMpxC(u"ࠩ฼ีอ๏ࠧ᫪"),vzqjsVHSBlMpxC(u"ࠪ฽ึฮ๊ࠨ᫫")).replace(bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠫฯืใ๊ࠩ᫬"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠬะัไ์ࠪ᫭")).replace(rCmGE4YIDaZA(u"࠭สาๅํ๋ࠬ᫮"),JvQd6LMoBX4hiy1C(u"ࠧหำๆ๎ࠬ᫯")).replace(ldIfvn6asURQ9toi85EhqAXW3(u"ࠨษ็้฻อแࠨ᫰"),bDxWcjmaSgFeRKrfpJvyA4zThi(u"ฺ่ࠩฬ็ࠧ᫱"))
				w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(nfNTgkiWdUq(u"ࠪี๏อึ๋ࠩ᫲"),gmPI7hVEM8nD(u"ࠫึ๐วืหࠪ᫳")).replace(ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠬื๊ศุ๊ࠫ᫴"),bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠭ั๋ษูอࠬ᫵")).replace(AJHaiQq3PRd5cphzGuELnVg9X(u"ࠧศีํ์๏ํࠧ᫶"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠨษึ๎ํ๐ࠧ᫷"))
				w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠩๆ์๊๐ฯ๊ࠩ᫸"),baBcNd81eH5ry2Olp6Mj43(u"ࠪ็ํ๋๊ะ์ࠪ᫹")).replace(ldIfvn6asURQ9toi85EhqAXW3(u"่ࠫ๎ๅ๋ัํ๋ࠬ᫺"),JvQd6LMoBX4hiy1C(u"้่ࠬๆ์า๎ࠬ᫻")).replace(rCmGE4YIDaZA(u"࠭ว็์่๎ࠬ᫼"),XEcWOIwkZKubV7vQ(u"ࠧศ่่๎ࠬ᫽"))
				w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(rCmGE4YIDaZA(u"ࠨษ้๎๊๐ิ็ࠩ᫾"),jil8vRpBsENVYyPmDd(u"ࠩส๊๊๐ิ็ࠩ᫿")).replace(zhE5I4xHinX0UoVZMNwlkPrR(u"ࠪห๋๋้ࠨᬀ"),baBcNd81eH5ry2Olp6Mj43(u"ࠫฬ์ๅ๋ึ้ࠫᬁ")).replace(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠬอๆๆ์ࠪᬂ"),lw2snZ9J0uhLoxypqa(u"࠭ว็็ํุ๋࠭ᬃ"))
				w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(HD7MQqXd2gS(u"ࠧศ่่๎ู์ิ็ࠩᬄ"),XEcWOIwkZKubV7vQ(u"ࠨษ้้๏ฺๆࠨᬅ")).replace(w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠩส่ฬ์ๅ๋ึ้ࠫᬆ"),vzqjsVHSBlMpxC(u"ࠪห๋๋๊ี่ࠪᬇ")).replace(zhE5I4xHinX0UoVZMNwlkPrR(u"ࠫฬ็ไศ็ุ้๊ࠣำๅษอࠫᬈ"),Yj1msqVeivESfrCupRy9b7WacBd(u"ࠬอแๅษ่ࠤํ๋ำๅี็หฯ࠭ᬉ"))
				w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c).strip(HD7MQqXd2gS(u"࠭࠭ࠨᬊ")).strip(hSXlxL9iB05c)
			if w8cPT5nhW2RUAFKDa not in list(Vjy0JqnlGvRbiN1z5roxI3KCkX.keys()): Vjy0JqnlGvRbiN1z5roxI3KCkX[w8cPT5nhW2RUAFKDa] = {}
			Vjy0JqnlGvRbiN1z5roxI3KCkX[w8cPT5nhW2RUAFKDa][whXU4NCbPdFAcxErVJIutR8WDM3n] = [WTavfhd7QJDABwpIVrZqHL,w8cPT5nhW2RUAFKDa,kOTdpYrPqu5A7UIcW0Ch,knBV0UPuCNdpIsAFH3coRKjh2lb,czMOJaKwoCnSPuNTd9bIH8pfLy72W5,QbuYlX5ctHaGp42jNef8,OOrjZaTIVXQ2Sp0ozhc,qjyki7XR1FW,Gv80f9tpWiRL]
	WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,zhE5I4xHinX0UoVZMNwlkPrR(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡖࡍ࡙ࡋࡓࠨᬋ"),jil8vRpBsENVYyPmDd(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡗࡎ࡚ࡅࡔࡡࡄࡐࡑ࠭ᬌ"),Vjy0JqnlGvRbiN1z5roxI3KCkX,l7ltVNxrbPimpXJDh)
	if ns1UjyrKQIT28l6>=rZeA4mhYJX0Tj83WdcGqOl: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,baBcNd81eH5ry2Olp6Mj43(u"ࠩ็ำ๏้ࠠๆึๆ่ฮࠦแ๋ࠢࠪᬍ")+str(ns1UjyrKQIT28l6)+HD7MQqXd2gS(u"ࠪࠤ๊๎โฺ่๊๋่ࠢࠥศไ฼ࠤฬ๊ศา่ส้ัࠦ࠮࠯࠰ࠣ์์้ะศุ่่๊ࠢษࠡีหฬ์อฺࠠษาอ๋ࠥๆࠡษ็ษ๋ะั็์อࠤ฾์ฯไ๋ࠢห้๋่ศไ฼ࠤ์๐࠺ࠨᬎ")+mUOd89K7MvRwb)
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,rCmGE4YIDaZA(u"ࠫฯ๋ࠠอๆหࠤัฺ๋๊ࠢส่ศ่ำศ็ࠣห้๋ส้ใิอࠥ็๊ࠡษ็ฬึ์วๆฮࠪᬏ"))
	RUEwdIv5WrlKDFhTBe(GGlX1Dsd3bJKMFw,GGlX1Dsd3bJKMFw,GGlX1Dsd3bJKMFw)
	OeR9Dyin6a4hK5VvFMBo()
	return
def giKatT6eG4sfjRPoBYElFpZvCUzN(QLSRWqIZ71KXcsJO2,QKHC8Vlk21Up):
	aoD3bFQiButV50LwGnhkRszJSm7 = FFKncZx5pDTwdiJRYhMgQSNL
	pYyO6d7ceuQBt = Nzp9Fq5cTr.menuItemsLIST
	Nzp9Fq5cTr.menuItemsLIST[:] = []
	if aoD3bFQiButV50LwGnhkRszJSm7 and w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪᬐ") not in QKHC8Vlk21Up:
		V9OGBuyogH0CaUtQS6wWErAbPYDjlM = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,xwIUQfiE7rmvYzH(u"࠭࡬ࡪࡵࡷࠫᬑ"),vzqjsVHSBlMpxC(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜ࠧᬒ"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࡠࠩᬓ")+QLSRWqIZ71KXcsJO2)
	elif YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠩࡢࡐࡎ࡜ࡅࡠࠩᬔ") not in QKHC8Vlk21Up or VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠪࡣ࡛ࡕࡄࡠࠩᬕ") not in QKHC8Vlk21Up:
		import atoGunAmqK
		a1duvQ8Vh0gNo69nDcp3Pjtym = LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"้๊ࠫริใ่ࠣิ๐ใࠡ็ื็้ฯࠠโ์๋ࠣีอࠠศๆ่์็฿ࠠ࠯๋ࠢีุอไสࠢส่ำ฽รࠡๅส๊ࠥ็๊่ษࠣฮๆอี๋ๆࠣห้๋ิไๆฬࠤ࠳ࠦรัษࠣห้๋ิไๆฬࠤ้๐ำหࠢะะอࠦแอำหࠤสืำศๆ๋ࠣีํࠠศๆุ่่๊ษࠡว็ํࠥอไๆสิ้ัࠦๅ็ࠢๅหห๋ษࠡะา้ฬะࠠศๆหี๋อๅอࠩᬖ")
		if HD7MQqXd2gS(u"ࠬࡥࡌࡊࡘࡈࡣࠬᬗ") not in QKHC8Vlk21Up:
			try: atoGunAmqK.oHJ5CWIeGX8up7hTKxOdzNPrk(QLSRWqIZ71KXcsJO2,mRanX1HZupfSQVB2gsDGUO(u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬᬘ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,QKHC8Vlk21Up+baBcNd81eH5ry2Olp6Mj43(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᬙ"),FFKncZx5pDTwdiJRYhMgQSNL)
			except: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไโ์า๎ํํวหࠩᬚ"),a1duvQ8Vh0gNo69nDcp3Pjtym)
			try: atoGunAmqK.oHJ5CWIeGX8up7hTKxOdzNPrk(QLSRWqIZ71KXcsJO2,bDxWcjmaSgFeRKrfpJvyA4zThi(u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᬛ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,QKHC8Vlk21Up+Yj1msqVeivESfrCupRy9b7WacBd(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᬜ"),FFKncZx5pDTwdiJRYhMgQSNL)
			except: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,AJHaiQq3PRd5cphzGuELnVg9X(u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๅ๏ี๊้้สฮࠬᬝ"),a1duvQ8Vh0gNo69nDcp3Pjtym)
			try: atoGunAmqK.oHJ5CWIeGX8up7hTKxOdzNPrk(QLSRWqIZ71KXcsJO2,FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪᬞ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,QKHC8Vlk21Up+bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᬟ"),FFKncZx5pDTwdiJRYhMgQSNL)
			except: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,zhE5I4xHinX0UoVZMNwlkPrR(u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊แ๋ัํ์์อสࠨᬠ"),a1duvQ8Vh0gNo69nDcp3Pjtym)
		if jil8vRpBsENVYyPmDd(u"ࠨࡡ࡙ࡓࡉࡥࠧᬡ") not in QKHC8Vlk21Up:
			try: atoGunAmqK.oHJ5CWIeGX8up7hTKxOdzNPrk(QLSRWqIZ71KXcsJO2,rCmGE4YIDaZA(u"ࠩࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᬢ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,QKHC8Vlk21Up+bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᬣ"),FFKncZx5pDTwdiJRYhMgQSNL)
			except: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๆ๋๎วหࠩᬤ"),a1duvQ8Vh0gNo69nDcp3Pjtym)
			try: atoGunAmqK.oHJ5CWIeGX8up7hTKxOdzNPrk(QLSRWqIZ71KXcsJO2,w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫᬥ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,QKHC8Vlk21Up+xwIUQfiE7rmvYzH(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᬦ"),FFKncZx5pDTwdiJRYhMgQSNL)
			except: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,bb1fgjsAq4N2xYwnoh39lm(u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊โ็๊สฮࠬᬧ"),a1duvQ8Vh0gNo69nDcp3Pjtym)
		V9OGBuyogH0CaUtQS6wWErAbPYDjlM = Nzp9Fq5cTr.menuItemsLIST
		if aoD3bFQiButV50LwGnhkRszJSm7: WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,Qy6wlfLoOpg1(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨᬨ"),n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࠪᬩ")+QLSRWqIZ71KXcsJO2,V9OGBuyogH0CaUtQS6wWErAbPYDjlM,l7ltVNxrbPimpXJDh)
	Nzp9Fq5cTr.menuItemsLIST[:] = pYyO6d7ceuQBt
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def RRIgrJoCn8Lh4kdMa(QLSRWqIZ71KXcsJO2,QKHC8Vlk21Up):
	aoD3bFQiButV50LwGnhkRszJSm7 = FFKncZx5pDTwdiJRYhMgQSNL
	pYyO6d7ceuQBt = Nzp9Fq5cTr.menuItemsLIST
	Nzp9Fq5cTr.menuItemsLIST[:] = []
	if aoD3bFQiButV50LwGnhkRszJSm7 and ldIfvn6asURQ9toi85EhqAXW3(u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨᬪ") not in QKHC8Vlk21Up:
		V9OGBuyogH0CaUtQS6wWErAbPYDjlM = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,mRanX1HZupfSQVB2gsDGUO(u"ࠫࡱ࡯ࡳࡵࠩᬫ"),Yj1msqVeivESfrCupRy9b7WacBd(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫᬬ"),Pj9YaUq1ibJ(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤ࠭ᬭ")+QLSRWqIZ71KXcsJO2)
	elif n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠧࡠࡎࡌ࡚ࡊࡥࠧᬮ") not in QKHC8Vlk21Up or lw2snZ9J0uhLoxypqa(u"ࠨࡡ࡙ࡓࡉࡥࠧᬯ") not in QKHC8Vlk21Up:
		import Bn18ZLUmyw
		a1duvQ8Vh0gNo69nDcp3Pjtym = Pj9YaUq1ibJ(u"ࠩ็่ศูแࠡๆา๎่ࠦๅีๅ็อࠥ็๊้ࠡำหࠥอไๆ๊ๅ฽ࠥ࠴้ࠠำึห้ฯࠠศๆั฻ศࠦใศ่ࠣๅ๏ํวࠡฬไหฺ๐ไࠡษ็ู้้ไสࠢ࠱ࠤศึวࠡษ็ู้้ไสࠢ็๎ุะࠠฮฮหࠤๆาัษࠢศีุอไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ๊์ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊าࠧᬰ")
		if AJHaiQq3PRd5cphzGuELnVg9X(u"ࠪࡣࡑࡏࡖࡆࡡࠪᬱ") not in QKHC8Vlk21Up:
			try: Bn18ZLUmyw.oHJ5CWIeGX8up7hTKxOdzNPrk(QLSRWqIZ71KXcsJO2,xwIUQfiE7rmvYzH(u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪᬲ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,QKHC8Vlk21Up+vzqjsVHSBlMpxC(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᬳ"),FFKncZx5pDTwdiJRYhMgQSNL)
			except: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,XEcWOIwkZKubV7vQ(u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่ๆ๐ฯ๋๊๊หฯ᬴࠭"),a1duvQ8Vh0gNo69nDcp3Pjtym)
			try: Bn18ZLUmyw.oHJ5CWIeGX8up7hTKxOdzNPrk(QLSRWqIZ71KXcsJO2,gmPI7hVEM8nD(u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬᬵ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,QKHC8Vlk21Up+Pj9YaUq1ibJ(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᬶ"),FFKncZx5pDTwdiJRYhMgQSNL)
			except: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไโ์า๎ํํวหࠩᬷ"),a1duvQ8Vh0gNo69nDcp3Pjtym)
			try: Bn18ZLUmyw.oHJ5CWIeGX8up7hTKxOdzNPrk(QLSRWqIZ71KXcsJO2,bqCDnV7Bs5XgRvuKLNAa1Uz(u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨᬸ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,QKHC8Vlk21Up+n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᬹ"),FFKncZx5pDTwdiJRYhMgQSNL)
			except: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,lw2snZ9J0uhLoxypqa(u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๅ๏ี๊้้สฮࠬᬺ"),a1duvQ8Vh0gNo69nDcp3Pjtym)
		if PPxYugzLZwHX23yiK(u"࠭࡟ࡗࡑࡇࡣࠬᬻ") not in QKHC8Vlk21Up:
			try: Bn18ZLUmyw.oHJ5CWIeGX8up7hTKxOdzNPrk(QLSRWqIZ71KXcsJO2,vzqjsVHSBlMpxC(u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᬼ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,QKHC8Vlk21Up+AJHaiQq3PRd5cphzGuELnVg9X(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᬽ"),FFKncZx5pDTwdiJRYhMgQSNL)
			except: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไใ่๋หฯ࠭ᬾ"),a1duvQ8Vh0gNo69nDcp3Pjtym)
			try: Bn18ZLUmyw.oHJ5CWIeGX8up7hTKxOdzNPrk(QLSRWqIZ71KXcsJO2,xwIUQfiE7rmvYzH(u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᬿ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,QKHC8Vlk21Up+gmPI7hVEM8nD(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᭀ"),FFKncZx5pDTwdiJRYhMgQSNL)
			except: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,ldIfvn6asURQ9toi85EhqAXW3(u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๆ๋๎วหࠩᭁ"),a1duvQ8Vh0gNo69nDcp3Pjtym)
		V9OGBuyogH0CaUtQS6wWErAbPYDjlM = Nzp9Fq5cTr.menuItemsLIST
		if aoD3bFQiButV50LwGnhkRszJSm7: WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,mRanX1HZupfSQVB2gsDGUO(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬᭂ"),lw2snZ9J0uhLoxypqa(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚ࡥࠧᭃ")+QLSRWqIZ71KXcsJO2,V9OGBuyogH0CaUtQS6wWErAbPYDjlM,l7ltVNxrbPimpXJDh)
	Nzp9Fq5cTr.menuItemsLIST[:] = pYyO6d7ceuQBt
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def H8eh2Q1T0mk4bEfJaYF73cP(QLSRWqIZ71KXcsJO2,QKHC8Vlk21Up,DqKQpeSHYvGcO5RZ4zdaTV1lfwxyE):
	RUEwdIv5WrlKDFhTBe(jKqWB2QMYJO8vTh0o6CVIyamw,jKqWB2QMYJO8vTh0o6CVIyamw,oZqKcvlJx1pTLN2ske5f0PtVrw)
	if DqKQpeSHYvGcO5RZ4zdaTV1lfwxyE: NDGKQC9HV0(FFKncZx5pDTwdiJRYhMgQSNL)
	elif xwIUQfiE7rmvYzH(u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ᭄࠭") in QKHC8Vlk21Up and not DqKQpeSHYvGcO5RZ4zdaTV1lfwxyE: NDGKQC9HV0(S5MWhgtZ37Xw)
	sQeLg1qSCF3ly9HoY = QKHC8Vlk21Up.replace(Yj1msqVeivESfrCupRy9b7WacBd(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧᭅ"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᭆ"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᭇ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	if not DqKQpeSHYvGcO5RZ4zdaTV1lfwxyE:
		TBt8bUDo9WhL(ldIfvn6asURQ9toi85EhqAXW3(u"ࠬࡲࡩ࡯࡭ࠪᭈ"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠭สฮัํฯ่ࠥวว็ฬࠤฬ๊รใีส้ࠬᭉ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,jil8vRpBsENVYyPmDd(u"࠼࠼࠳᳂"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᭊ")+sQeLg1qSCF3ly9HoY,nA5dhMRg6ENzsB0l1GwvH7aIr2,{bb1fgjsAq4N2xYwnoh39lm(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᭋ"):QLSRWqIZ71KXcsJO2})
		TBt8bUDo9WhL(mRanX1HZupfSQVB2gsDGUO(u"ࠩ࡯࡭ࡳࡱࠧᭌ"),bbTCMJwEx8nhN4X+Pj9YaUq1ibJ(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨ᭍")+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,jil8vRpBsENVYyPmDd(u"࠿࠹࠺࠻᳃"))
		yDlV9KzvF7k6SB2MRu1YsW = [vzqjsVHSBlMpxC(u"ࠫศ็ไศ็ࠪ᭎"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"๋ࠬำๅี็หฯ࠭᭏"),UUobzy0xZLaVScIt7(u"࠭ๅิำะ๎ฬะࠧ᭐"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠧษำส้ั࠭᭑"),JvQd6LMoBX4hiy1C(u"ࠨลฺๅฬ๊้ࠠๅิฮํ์ࠧ᭒"),bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠩิ้฻อๆࠨ᭓"),vzqjsVHSBlMpxC(u"ࠪวาีห࠮ลัีࠬ᭔"),bDxWcjmaSgFeRKrfpJvyA4zThi(u"ุ๊ࠫวิๆࠪ᭕"),HD7MQqXd2gS(u"๋่ࠬิ์ๅํࠬ᭖"),UUobzy0xZLaVScIt7(u"࠭รี้ิ࠱ศ้หาࠩ᭗"),gmPI7hVEM8nD(u"ࠧศๆล๊ࠬ᭘"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠨุะ็ࠬ᭙"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠩิ๎ฬ฼ษࠨ᭚"),XEcWOIwkZKubV7vQ(u"๊ࠪ๏ะแๅๅึࠫ᭛"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"๊๋ࠫหๅ์้ࠫ᭜"),AJHaiQq3PRd5cphzGuELnVg9X(u"ࠬฮหࠡฯํࠫ᭝"),bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠭ฯ๋่ํอࠬ᭞"),UUobzy0xZLaVScIt7(u"ࠧิ่๋หฯ࠭᭟"),DFx6E0uON7Jm8(u"ࠨลัี๎࠭᭠")]
		DqKQpeSHYvGcO5RZ4zdaTV1lfwxyE = IpFcwrWNgefMym3qta0hYQAzOdE
		for s96sCdIfv2Z in yDlV9KzvF7k6SB2MRu1YsW:
			DqKQpeSHYvGcO5RZ4zdaTV1lfwxyE += UnOIK1WBbw2
			TBt8bUDo9WhL(AJHaiQq3PRd5cphzGuELnVg9X(u"ࠩࡩࡳࡱࡪࡥࡳࠩ᭡"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+s96sCdIfv2Z,nA5dhMRg6ENzsB0l1GwvH7aIr2,vzqjsVHSBlMpxC(u"࠷࠷࠵᳄"),nA5dhMRg6ENzsB0l1GwvH7aIr2,str(DqKQpeSHYvGcO5RZ4zdaTV1lfwxyE),sQeLg1qSCF3ly9HoY,nA5dhMRg6ENzsB0l1GwvH7aIr2,{bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᭢"):QLSRWqIZ71KXcsJO2})
	else:
		TP1xIp4ubYkFyX03mZQiUrSWCtAc = [bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠫฬ็ไศ็ࠪ᭣"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠬࡳ࡯ࡷ࡫ࡨࠫ᭤"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠭แ๋ๆ่ࠫ᭥"),mRanX1HZupfSQVB2gsDGUO(u"ࠧโๆ่ࠫ᭦")]
		mHOkYD6jtvyEnVqWT = [lw2snZ9J0uhLoxypqa(u"ࠨ็ึุ่๊ࠧ᭧"),gmPI7hVEM8nD(u"ࠩࡶࡩࡷ࡯ࡥࡴࠩ᭨")]
		ghGQ1tLTex3flCmckr = [LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ุ้ࠪอัฮࠩ᭩"),Yj1msqVeivESfrCupRy9b7WacBd(u"ู๊ࠫัฮ์สฮࠬ᭪")]
		AYxEkOTUreyR2PlNF74cd9msQ = [VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠬฮัศ็ฯࠫ᭫"),nfNTgkiWdUq(u"࠭ࡳࡩࡱࡺ᭬ࠫ"),XEcWOIwkZKubV7vQ(u"ࠧหๆไึ๏๎ๆࠨ᭭"),lw2snZ9J0uhLoxypqa(u"ࠨฬ็๎ๆุ๊้่ࠪ᭮")]
		oZPmBqT40LapGYCdFkOxV = [PPxYugzLZwHX23yiK(u"ࠩส๊๊๐ࠧ᭯"),bb1fgjsAq4N2xYwnoh39lm(u"ࠪ็ึะ่็ࠩ᭰"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"่ࠫอัห๊้ࠫ᭱"),baBcNd81eH5ry2Olp6Mj43(u"ࠬࡱࡩࡥࡵࠪ᭲"),gmPI7hVEM8nD(u"࠭ืโๆࠪ᭳"),XEcWOIwkZKubV7vQ(u"ࠧศูไห้࠭᭴")]
		yyChfYK9vRXVHrWgkx = [LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠨำฺ่ฬ์ࠧ᭵")]
		CklyboIJDug75niLjhtmNU42fZs9ec = [mRanX1HZupfSQVB2gsDGUO(u"ࠩสัิัࠧ᭶"),Yj1msqVeivESfrCupRy9b7WacBd(u"ࠪหำืࠧ᭷"),gmPI7hVEM8nD(u"๊ࠫ๎ฮาࠩ᭸"),pxt6wJ8ScYMWCivoO(u"ࠬาฯ๋ัࠪ᭹"),rCmGE4YIDaZA(u"࠭ๅืษไࠫ᭺"),bb1fgjsAq4N2xYwnoh39lm(u"ࠧฮัํฯࠬ᭻")]
		wwahgARYl9ev8GW20S4 = [pxt6wJ8ScYMWCivoO(u"ࠨี็หุ๊ࠧ᭼"),AJHaiQq3PRd5cphzGuELnVg9X(u"ࠩึุ่๊็ࠨ᭽")]
		tU3fGb8EjVNWyh1YqnKPvs0 = [yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠪห฿อๆ๋ࠩ᭾"),bqCDnV7Bs5XgRvuKLNAa1Uz(u"๊ࠫ๎ำ๋ไ์ࠫ᭿"),baBcNd81eH5ry2Olp6Mj43(u"้ࠬไ๋สࠪᮀ"),jil8vRpBsENVYyPmDd(u"࠭อโๆࠪᮁ"),pxt6wJ8ScYMWCivoO(u"ࠧ࡮ࡷࡶ࡭ࡨ࠭ᮂ")]
		cyFbUPCMOosZ5tpQrNI4HqY08a = [HD7MQqXd2gS(u"ࠨษๆฯึ࠭ᮃ"),nfNTgkiWdUq(u"ࠩสุ์ืࠧᮄ"),HD7MQqXd2gS(u"้๊ࠪ๐า่ࠩᮅ"),PPxYugzLZwHX23yiK(u"ࠫฬ฿ไ๊ࠩᮆ"),xwIUQfiE7rmvYzH(u"๋ࠬฮหษิ๋ࠬᮇ"),PPxYugzLZwHX23yiK(u"࠭ๅฯฬสีฬะࠧᮈ"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠧศไ๋ํࠬᮉ")]
		KV4aBPiTMFvgbeuOl = [LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠨษ็ห๋࠭ᮊ"),ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠩะห้๐ࠧᮋ"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"้ࠪะฮสࠨᮌ"),Qy6wlfLoOpg1(u"ࠫึอฦอࠩᮍ")]
		DdUOYGz5SMt3PaI7JR = [jil8vRpBsENVYyPmDd(u"ࠬ฼อไࠩᮎ"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠭ใ้็ํำ๏࠭ᮏ")]
		edfgQSjRVTCJwxNO7yK4mq82isAptE = [LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠧา์สฺ์࠭ᮐ"),gmPI7hVEM8nD(u"ࠨๅ๋ี์࠭ᮑ"),rCmGE4YIDaZA(u"ู่ࠩฬืู่ࠩᮒ"),xwIUQfiE7rmvYzH(u"ุࠪํะࠧᮓ"),bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠫึ๐วืหࠪᮔ")]
		iinyoN95EOlJX = [zhE5I4xHinX0UoVZMNwlkPrR(u"ࠬ์๊หใ็็ุ࠭ᮕ"),ldIfvn6asURQ9toi85EhqAXW3(u"࠭࡮ࡦࡶࡩࡰ࡮ࡾࠧᮖ"),jil8vRpBsENVYyPmDd(u"ࠧ็์อๅ้๐ใิࠩᮗ")]
		b6QWNm5zH0Ygac = [Pj9YaUq1ibJ(u"ࠨ็่ฯ้๐ๆࠨᮘ"),rCmGE4YIDaZA(u"ࠩสุำอีࠨᮙ"),vzqjsVHSBlMpxC(u"๊ࠪั๎ๅࠨᮚ")]
		g3Vrp8uHOcdnY7t = [JvQd6LMoBX4hiy1C(u"ࠫอัࠠฮ์ࠪᮛ"),FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠬࡲࡩࡷࡧࠪᮜ"),xwIUQfiE7rmvYzH(u"࠭โ็ษ๊ࠫᮝ"),mRanX1HZupfSQVB2gsDGUO(u"ࠧใ่๋หฯ࠭ᮞ")]
		SNLsU7cA2WgfnkOm84EwBuyjerTp9l = [bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠨัํ๊ࠬᮟ"),baBcNd81eH5ry2Olp6Mj43(u"ࠩสำ฾๐็ࠨᮠ"),DFx6E0uON7Jm8(u"ࠪึ๏อัศฬࠪᮡ"),baBcNd81eH5ry2Olp6Mj43(u"้ࠫ฽ๅ๋ษอࠫᮢ"),lw2snZ9J0uhLoxypqa(u"ࠬีูศรࠪᮣ"),xwIUQfiE7rmvYzH(u"࠭โาษ้ࠫᮤ"),gmPI7hVEM8nD(u"ࠧใืสสิ࠭ᮥ"),gmPI7hVEM8nD(u"ࠨำฮหฦ࠭ᮦ"),pxt6wJ8ScYMWCivoO(u"่ࠩีั฿๊่ࠩᮧ"),Yj1msqVeivESfrCupRy9b7WacBd(u"ࠪหีอๆࠨᮨ"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠫฬูไศ็ࠪᮩ"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠬะ่ศึํั᮪ࠬ"),PPxYugzLZwHX23yiK(u"࠭ฮุส᮫ࠪ"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠧฮ๊ี์๏࠭ᮬ"),bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠨ฻อฬฬะࠧᮭ"),DFx6E0uON7Jm8(u"่ࠩ์ฬ๊๊ะࠩᮮ"),gmPI7hVEM8nD(u"๊ࠪํอู๋ࠩᮯ"),Yj1msqVeivESfrCupRy9b7WacBd(u"ࠫ฾่ววัࠪ᮰"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠬอๆศึํำࠬ᮱")]
		A2ARaHWuVxeYQ = [Pj9YaUq1ibJ(u"࠭࠲࠱࠳࠳ࠫ᮲"),zhE5I4xHinX0UoVZMNwlkPrR(u"ࠧ࠳࠲࠴࠵ࠬ᮳"),PPxYugzLZwHX23yiK(u"ࠨ࠴࠳࠵࠷࠭᮴"),AJHaiQq3PRd5cphzGuELnVg9X(u"ࠩ࠵࠴࠶࠹ࠧ᮵"),Qy6wlfLoOpg1(u"ࠪ࠶࠵࠷࠴ࠨ᮶"),ldIfvn6asURQ9toi85EhqAXW3(u"ࠫ࠷࠶࠱࠶ࠩ᮷"),gmPI7hVEM8nD(u"ࠬ࠸࠰࠲࠸ࠪ᮸"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠭࠲࠱࠳࠺ࠫ᮹"),HD7MQqXd2gS(u"ࠧ࠳࠲࠴࠼ࠬᮺ"),lw2snZ9J0uhLoxypqa(u"ࠨ࠴࠳࠵࠾࠭ᮻ"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠩ࠵࠴࠷࠶ࠧᮼ"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠪ࠶࠵࠸࠱ࠨᮽ"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠫ࠷࠶࠲࠳ࠩᮾ"),pxt6wJ8ScYMWCivoO(u"ࠬ࠸࠰࠳࠵ࠪᮿ"),lw2snZ9J0uhLoxypqa(u"࠭࠲࠱࠴࠷ࠫᯀ"),rCmGE4YIDaZA(u"ࠧ࠳࠲࠵࠹ࠬᯁ"),UUobzy0xZLaVScIt7(u"ࠨ࠴࠳࠶࠻࠭ᯂ"),ldIfvn6asURQ9toi85EhqAXW3(u"ࠩ࠵࠴࠷࠽ࠧᯃ"),bb1fgjsAq4N2xYwnoh39lm(u"ࠪ࠶࠵࠸࠸ࠨᯄ")]
		for w8cPT5nhW2RUAFKDa in sorted(list(Vjy0JqnlGvRbiN1z5roxI3KCkX.keys())):
			gO2PcxfG7Yhd = w8cPT5nhW2RUAFKDa.lower()
			kvfOU7Tpz958QBqnIlaAePLys = []
			if any(value in gO2PcxfG7Yhd for value in TP1xIp4ubYkFyX03mZQiUrSWCtAc): kvfOU7Tpz958QBqnIlaAePLys.append(UnOIK1WBbw2)
			if any(value in gO2PcxfG7Yhd for value in mHOkYD6jtvyEnVqWT): kvfOU7Tpz958QBqnIlaAePLys.append(udq5tP0hwifHQCGYELDbOUI)
			if any(value in gO2PcxfG7Yhd for value in ghGQ1tLTex3flCmckr): kvfOU7Tpz958QBqnIlaAePLys.append(AH0zdvBqibaXY)
			if any(value in gO2PcxfG7Yhd for value in AYxEkOTUreyR2PlNF74cd9msQ): kvfOU7Tpz958QBqnIlaAePLys.append(tpMX1Bgs0bzv8OEafyW)
			if any(value in gO2PcxfG7Yhd for value in oZPmBqT40LapGYCdFkOxV): kvfOU7Tpz958QBqnIlaAePLys.append(eCaWsMty53QI9Y)
			if any(value in gO2PcxfG7Yhd for value in yyChfYK9vRXVHrWgkx): kvfOU7Tpz958QBqnIlaAePLys.append(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠷᳅"))
			if any(value in gO2PcxfG7Yhd for value in CklyboIJDug75niLjhtmNU42fZs9ec) and gO2PcxfG7Yhd not in [Yj1msqVeivESfrCupRy9b7WacBd(u"ࠫฬิั๊ࠩᯅ")]: kvfOU7Tpz958QBqnIlaAePLys.append(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠹᳆"))
			if any(value in gO2PcxfG7Yhd for value in wwahgARYl9ev8GW20S4): kvfOU7Tpz958QBqnIlaAePLys.append(baBcNd81eH5ry2Olp6Mj43(u"࠻᳇"))
			if any(value in gO2PcxfG7Yhd for value in tU3fGb8EjVNWyh1YqnKPvs0): kvfOU7Tpz958QBqnIlaAePLys.append(Pj9YaUq1ibJ(u"࠽᳈"))
			if any(value in gO2PcxfG7Yhd for value in cyFbUPCMOosZ5tpQrNI4HqY08a): kvfOU7Tpz958QBqnIlaAePLys.append(AJHaiQq3PRd5cphzGuELnVg9X(u"࠶࠶᳉"))
			if any(value in gO2PcxfG7Yhd for value in KV4aBPiTMFvgbeuOl): kvfOU7Tpz958QBqnIlaAePLys.append(rCmGE4YIDaZA(u"࠷࠱᳊"))
			if any(value in gO2PcxfG7Yhd for value in DdUOYGz5SMt3PaI7JR): kvfOU7Tpz958QBqnIlaAePLys.append(jil8vRpBsENVYyPmDd(u"࠱࠳᳋"))
			if any(value in gO2PcxfG7Yhd for value in edfgQSjRVTCJwxNO7yK4mq82isAptE): kvfOU7Tpz958QBqnIlaAePLys.append(w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠲࠵᳌"))
			if any(value in gO2PcxfG7Yhd for value in iinyoN95EOlJX): kvfOU7Tpz958QBqnIlaAePLys.append(ldIfvn6asURQ9toi85EhqAXW3(u"࠳࠷᳍"))
			if any(value in gO2PcxfG7Yhd for value in b6QWNm5zH0Ygac): kvfOU7Tpz958QBqnIlaAePLys.append(zhE5I4xHinX0UoVZMNwlkPrR(u"࠴࠹᳎"))
			if any(value in gO2PcxfG7Yhd for value in g3Vrp8uHOcdnY7t): kvfOU7Tpz958QBqnIlaAePLys.append(bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠵࠻᳏"))
			if any(value in gO2PcxfG7Yhd for value in SNLsU7cA2WgfnkOm84EwBuyjerTp9l): kvfOU7Tpz958QBqnIlaAePLys.append(bb1fgjsAq4N2xYwnoh39lm(u"࠶࠽᳐"))
			if any(value in gO2PcxfG7Yhd for value in A2ARaHWuVxeYQ): kvfOU7Tpz958QBqnIlaAePLys.append(PPxYugzLZwHX23yiK(u"࠷࠸᳑"))
			if not kvfOU7Tpz958QBqnIlaAePLys: kvfOU7Tpz958QBqnIlaAePLys = [baBcNd81eH5ry2Olp6Mj43(u"࠱࠺᳒")]
			for UU1zr3DIiYFd6 in kvfOU7Tpz958QBqnIlaAePLys:
				if str(UU1zr3DIiYFd6)==DqKQpeSHYvGcO5RZ4zdaTV1lfwxyE:
					TBt8bUDo9WhL(PPxYugzLZwHX23yiK(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᯆ"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+w8cPT5nhW2RUAFKDa,w8cPT5nhW2RUAFKDa,ZjELJ9VrUT07R8Hn4FuSDcf(u"࠲࠸࠹᳓"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,sQeLg1qSCF3ly9HoY+baBcNd81eH5ry2Olp6Mj43(u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᯇ"))
	RUEwdIv5WrlKDFhTBe(jKqWB2QMYJO8vTh0o6CVIyamw,jKqWB2QMYJO8vTh0o6CVIyamw,GGlX1Dsd3bJKMFw)
	return
def oPj2IkmwrRE(QLSRWqIZ71KXcsJO2,QKHC8Vlk21Up):
	aoD3bFQiButV50LwGnhkRszJSm7 = FFKncZx5pDTwdiJRYhMgQSNL
	if aoD3bFQiButV50LwGnhkRszJSm7:
		TBt8bUDo9WhL(jil8vRpBsENVYyPmDd(u"ࠧ࡭࡫ࡱ࡯ࠬᯈ"),XEcWOIwkZKubV7vQ(u"ࠨฬะำ๏ัࠠใษษ้ฮࠦรใีส้ࠥࡏࡐࡕࡘࠪᯉ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,xwIUQfiE7rmvYzH(u"࠹࠹࠸᳔"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧᯊ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,{UUobzy0xZLaVScIt7(u"ࠪࡪࡴࡲࡤࡦࡴࠪᯋ"):QLSRWqIZ71KXcsJO2})
		TBt8bUDo9WhL(PPxYugzLZwHX23yiK(u"ࠫࡱ࡯࡮࡬ࠩᯌ"),bbTCMJwEx8nhN4X+bb1fgjsAq4N2xYwnoh39lm(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪᯍ")+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,ZjELJ9VrUT07R8Hn4FuSDcf(u"࠼࠽࠾࠿᳕"))
	pYyO6d7ceuQBt = Nzp9Fq5cTr.menuItemsLIST[:]
	import atoGunAmqK
	if QLSRWqIZ71KXcsJO2:
		if not atoGunAmqK.jx8bBYMhnguRAHoWtXLFml(QLSRWqIZ71KXcsJO2,S5MWhgtZ37Xw): return
		XqenRf7gdMi = giKatT6eG4sfjRPoBYElFpZvCUzN(QLSRWqIZ71KXcsJO2,QKHC8Vlk21Up)
		tD8imP0HBbe = sorted(XqenRf7gdMi,reverse=FFKncZx5pDTwdiJRYhMgQSNL,key=lambda key: key[UnOIK1WBbw2].lower())
	else:
		if not atoGunAmqK.jx8bBYMhnguRAHoWtXLFml(nA5dhMRg6ENzsB0l1GwvH7aIr2,S5MWhgtZ37Xw): return
		if aoD3bFQiButV50LwGnhkRszJSm7 and LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫᯎ") not in QKHC8Vlk21Up:
			tD8imP0HBbe = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,Qy6wlfLoOpg1(u"ࠧ࡭࡫ࡶࡸࠬᯏ"),zhE5I4xHinX0UoVZMNwlkPrR(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨᯐ"),n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࡄࡐࡑ࠭ᯑ"))
		else:
			UfCRvyu3JIwFBbTno8Dda2qc,tD8imP0HBbe,XqenRf7gdMi = [],[],[]
			for kPsNCZHraKUMnt6d7f2VRcSF in range(UnOIK1WBbw2,EYcbkTrLd8MqHSXzxFGft+UnOIK1WBbw2):
				tD8imP0HBbe += giKatT6eG4sfjRPoBYElFpZvCUzN(str(kPsNCZHraKUMnt6d7f2VRcSF),QKHC8Vlk21Up)
			for type,w8cPT5nhW2RUAFKDa,url,knBV0UPuCNdpIsAFH3coRKjh2lb,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,OOrjZaTIVXQ2Sp0ozhc,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4 in tD8imP0HBbe:
				if OOrjZaTIVXQ2Sp0ozhc not in UfCRvyu3JIwFBbTno8Dda2qc:
					UfCRvyu3JIwFBbTno8Dda2qc.append(OOrjZaTIVXQ2Sp0ozhc)
					AK6LojQwb8xC = type,w8cPT5nhW2RUAFKDa,OOrjZaTIVXQ2Sp0ozhc,FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠵࠻࠻᳖"),io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,QKHC8Vlk21Up,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4
					XqenRf7gdMi.append(AK6LojQwb8xC)
			tD8imP0HBbe = sorted(XqenRf7gdMi,reverse=FFKncZx5pDTwdiJRYhMgQSNL,key=lambda key: key[UnOIK1WBbw2].lower())
			if aoD3bFQiButV50LwGnhkRszJSm7: WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,jil8vRpBsENVYyPmDd(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࠪᯒ"),JvQd6LMoBX4hiy1C(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࡣࡆࡒࡌࠨᯓ"),tD8imP0HBbe,l7ltVNxrbPimpXJDh)
	Nzp9Fq5cTr.menuItemsLIST[:] = pYyO6d7ceuQBt+tD8imP0HBbe
	AA5FS4hUqeP9EsZCM(FFKncZx5pDTwdiJRYhMgQSNL)
	return
def zlLQBJmqfciaKSd9g(QLSRWqIZ71KXcsJO2,QKHC8Vlk21Up):
	aoD3bFQiButV50LwGnhkRszJSm7 = FFKncZx5pDTwdiJRYhMgQSNL
	if aoD3bFQiButV50LwGnhkRszJSm7:
		TBt8bUDo9WhL(HD7MQqXd2gS(u"ࠬࡲࡩ࡯࡭ࠪᯔ"),ldIfvn6asURQ9toi85EhqAXW3(u"࠭สฮัํฯ่ࠥวว็ฬࠤศ่ำศ็ࠣࡑ࠸࡛ࠧᯕ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠼࠼࠵᳗"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,JvQd6LMoBX4hiy1C(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᯖ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,{YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᯗ"):QLSRWqIZ71KXcsJO2})
		TBt8bUDo9WhL(pxt6wJ8ScYMWCivoO(u"ࠩ࡯࡭ࡳࡱࠧᯘ"),bbTCMJwEx8nhN4X+PPxYugzLZwHX23yiK(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨᯙ")+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,zhE5I4xHinX0UoVZMNwlkPrR(u"࠿࠹࠺࠻᳘"))
	pYyO6d7ceuQBt = Nzp9Fq5cTr.menuItemsLIST[:]
	import Bn18ZLUmyw
	if QLSRWqIZ71KXcsJO2:
		if not Bn18ZLUmyw.jx8bBYMhnguRAHoWtXLFml(QLSRWqIZ71KXcsJO2,S5MWhgtZ37Xw): return
		XqenRf7gdMi = RRIgrJoCn8Lh4kdMa(QLSRWqIZ71KXcsJO2,QKHC8Vlk21Up)
		tD8imP0HBbe = sorted(XqenRf7gdMi,reverse=FFKncZx5pDTwdiJRYhMgQSNL,key=lambda key: key[UnOIK1WBbw2].lower())
	else:
		if not Bn18ZLUmyw.jx8bBYMhnguRAHoWtXLFml(nA5dhMRg6ENzsB0l1GwvH7aIr2,S5MWhgtZ37Xw): return
		if aoD3bFQiButV50LwGnhkRszJSm7 and pxt6wJ8ScYMWCivoO(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩᯚ") not in QKHC8Vlk21Up:
			tD8imP0HBbe = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,Pj9YaUq1ibJ(u"ࠬࡲࡩࡴࡶࠪᯛ"),ZjELJ9VrUT07R8Hn4FuSDcf(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬᯜ"),mRanX1HZupfSQVB2gsDGUO(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚ࡥࡁࡍࡎࠪᯝ"))
		else:
			UfCRvyu3JIwFBbTno8Dda2qc,tD8imP0HBbe,XqenRf7gdMi = [],[],[]
			for kPsNCZHraKUMnt6d7f2VRcSF in range(UnOIK1WBbw2,EYcbkTrLd8MqHSXzxFGft+UnOIK1WBbw2):
				tD8imP0HBbe += RRIgrJoCn8Lh4kdMa(str(kPsNCZHraKUMnt6d7f2VRcSF),QKHC8Vlk21Up)
			for type,w8cPT5nhW2RUAFKDa,url,knBV0UPuCNdpIsAFH3coRKjh2lb,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,OOrjZaTIVXQ2Sp0ozhc,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4 in tD8imP0HBbe:
				if OOrjZaTIVXQ2Sp0ozhc not in UfCRvyu3JIwFBbTno8Dda2qc:
					UfCRvyu3JIwFBbTno8Dda2qc.append(OOrjZaTIVXQ2Sp0ozhc)
					AK6LojQwb8xC = type,w8cPT5nhW2RUAFKDa,OOrjZaTIVXQ2Sp0ozhc,HD7MQqXd2gS(u"࠱࠷࠷᳙"),io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,QKHC8Vlk21Up,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4
					XqenRf7gdMi.append(AK6LojQwb8xC)
			tD8imP0HBbe = sorted(XqenRf7gdMi,reverse=FFKncZx5pDTwdiJRYhMgQSNL,key=lambda key: key[UnOIK1WBbw2].lower())
			if aoD3bFQiButV50LwGnhkRszJSm7: WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,mRanX1HZupfSQVB2gsDGUO(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛ࠧᯞ"),jil8vRpBsENVYyPmDd(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࡃࡏࡐࠬᯟ"),tD8imP0HBbe,l7ltVNxrbPimpXJDh)
	Nzp9Fq5cTr.menuItemsLIST[:] = pYyO6d7ceuQBt+tD8imP0HBbe
	AA5FS4hUqeP9EsZCM(FFKncZx5pDTwdiJRYhMgQSNL)
	return
def SPB0sZ6YzyJQctjFmfro(group,QKHC8Vlk21Up):
	aoD3bFQiButV50LwGnhkRszJSm7 = FFKncZx5pDTwdiJRYhMgQSNL
	V9OGBuyogH0CaUtQS6wWErAbPYDjlM = []
	ZJcqhM7vSTN = VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠪࡣࡎࡖࡔࡗࡡࠪᯠ") if Pj9YaUq1ibJ(u"ࠫࡎࡖࡔࡗࠩᯡ") in QKHC8Vlk21Up else lw2snZ9J0uhLoxypqa(u"ࠬࡥࡍ࠴ࡗࡢࠫᯢ")
	if aoD3bFQiButV50LwGnhkRszJSm7: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,PPxYugzLZwHX23yiK(u"࠭࡬ࡪࡵࡷࠫᯣ"),baBcNd81eH5ry2Olp6Mj43(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࠩᯤ")+ZJcqhM7vSTN[:-UnOIK1WBbw2],group)
	if not V9OGBuyogH0CaUtQS6wWErAbPYDjlM:
		for QLSRWqIZ71KXcsJO2 in range(UnOIK1WBbw2,EYcbkTrLd8MqHSXzxFGft+UnOIK1WBbw2):
			if aoD3bFQiButV50LwGnhkRszJSm7: V9OGBuyogH0CaUtQS6wWErAbPYDjlM += CLAr1U2pRe3VhTP(FeDIpVljXmOnNkPAHscdTKWrEa,baBcNd81eH5ry2Olp6Mj43(u"ࠨ࡮࡬ࡷࡹ࠭ᯥ"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖ᯦ࠫ")+ZJcqhM7vSTN[:-UnOIK1WBbw2],XEcWOIwkZKubV7vQ(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࠬᯧ")+ZJcqhM7vSTN+str(QLSRWqIZ71KXcsJO2))
			elif ZJcqhM7vSTN==lw2snZ9J0uhLoxypqa(u"ࠫࡤࡏࡐࡕࡘࡢࠫᯨ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM += giKatT6eG4sfjRPoBYElFpZvCUzN(str(QLSRWqIZ71KXcsJO2),vzqjsVHSBlMpxC(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪᯩ"))
			elif ZJcqhM7vSTN==JvQd6LMoBX4hiy1C(u"࠭࡟ࡎ࠵ࡘࡣࠬᯪ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM += RRIgrJoCn8Lh4kdMa(str(QLSRWqIZ71KXcsJO2),pxt6wJ8ScYMWCivoO(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᯫ"))
		for type,w8cPT5nhW2RUAFKDa,url,knBV0UPuCNdpIsAFH3coRKjh2lb,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,OOrjZaTIVXQ2Sp0ozhc,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4 in V9OGBuyogH0CaUtQS6wWErAbPYDjlM:
			if OOrjZaTIVXQ2Sp0ozhc==group: uliqcaDoAVbL2(type,w8cPT5nhW2RUAFKDa,url,knBV0UPuCNdpIsAFH3coRKjh2lb,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,OOrjZaTIVXQ2Sp0ozhc,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4)
		items,hn2rCExmu5pgejyYOT = [],[]
		for type,w8cPT5nhW2RUAFKDa,url,knBV0UPuCNdpIsAFH3coRKjh2lb,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,OOrjZaTIVXQ2Sp0ozhc,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4 in Nzp9Fq5cTr.menuItemsLIST:
			aZF0goxbuiKD4pRvMcYh2eSWwHJLd = type,w8cPT5nhW2RUAFKDa[tpMX1Bgs0bzv8OEafyW:],url,knBV0UPuCNdpIsAFH3coRKjh2lb,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,OOrjZaTIVXQ2Sp0ozhc,kSqp7Ua0gATvrXG2RFdzN,nA5dhMRg6ENzsB0l1GwvH7aIr2
			if aZF0goxbuiKD4pRvMcYh2eSWwHJLd not in hn2rCExmu5pgejyYOT:
				hn2rCExmu5pgejyYOT.append(aZF0goxbuiKD4pRvMcYh2eSWwHJLd)
				CQtNwXGVAJ2y5nBY = type,w8cPT5nhW2RUAFKDa,url,knBV0UPuCNdpIsAFH3coRKjh2lb,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,OOrjZaTIVXQ2Sp0ozhc,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4
				items.append(CQtNwXGVAJ2y5nBY)
		V9OGBuyogH0CaUtQS6wWErAbPYDjlM = sorted(items,reverse=FFKncZx5pDTwdiJRYhMgQSNL,key=lambda key: key[UnOIK1WBbw2].lower()[UUobzy0xZLaVScIt7(u"࠶᳚"):])
		if aoD3bFQiButV50LwGnhkRszJSm7: WW5Rt1uxN7jBGAZ(FeDIpVljXmOnNkPAHscdTKWrEa,gmPI7hVEM8nD(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࠪᯬ")+ZJcqhM7vSTN[:-UnOIK1WBbw2],group,V9OGBuyogH0CaUtQS6wWErAbPYDjlM,l7ltVNxrbPimpXJDh)
	if mRanX1HZupfSQVB2gsDGUO(u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫᯭ") in QKHC8Vlk21Up and len(V9OGBuyogH0CaUtQS6wWErAbPYDjlM)>Pkf0RaNHAUsqMKCzb6J7WSmwFOnG:
		Nzp9Fq5cTr.menuItemsLIST[:] = []
		TBt8bUDo9WhL(YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠪࡪࡴࡲࡤࡦࡴࠪᯮ"),nfNTgkiWdUq(u"ࠫࡠ࠭ᯯ")+bbTCMJwEx8nhN4X+group+NwROdSj3nsA+JvQd6LMoBX4hiy1C(u"ࠬࠦ࠺ศๆๅื๊ࡣࠧᯰ"),group,Pj9YaUq1ibJ(u"࠳࠹࠹᳛"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,ZJcqhM7vSTN+mRanX1HZupfSQVB2gsDGUO(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᯱ"))
		TBt8bUDo9WhL(baBcNd81eH5ry2Olp6Mj43(u"ࠧࡧࡱ࡯ࡨࡪࡸ᯲ࠧ"),Yj1msqVeivESfrCupRy9b7WacBd(u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆ᯳ุ๋ࠧ"),group,vzqjsVHSBlMpxC(u"࠴࠺࠺᳜"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,ZJcqhM7vSTN+yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᯴"))
		TBt8bUDo9WhL(w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠪࡰ࡮ࡴ࡫ࠨ᯵"),bbTCMJwEx8nhN4X+yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩ᯶")+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠽࠾࠿࠹᳝"))
		V9OGBuyogH0CaUtQS6wWErAbPYDjlM = Nzp9Fq5cTr.menuItemsLIST+avZmSHVO7swUYFnTu5p9iNR8g.sample(V9OGBuyogH0CaUtQS6wWErAbPYDjlM,Pkf0RaNHAUsqMKCzb6J7WSmwFOnG)
	Nzp9Fq5cTr.menuItemsLIST[:] = V9OGBuyogH0CaUtQS6wWErAbPYDjlM
	AA5FS4hUqeP9EsZCM(FFKncZx5pDTwdiJRYhMgQSNL)
	return
def P9hzNHqT7XGpc8ove4SrtuOxYaCim(QKHC8Vlk21Up):
	TBt8bUDo9WhL(mRanX1HZupfSQVB2gsDGUO(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᯷"),Qy6wlfLoOpg1(u"࠭ลฺษาอࠥ฽ไษࠢๅ๊ํอสࠡ฻ื์ฬฬ๊สࠩ᯸"),nA5dhMRg6ENzsB0l1GwvH7aIr2,XEcWOIwkZKubV7vQ(u"࠶࠼࠱᳞"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,jil8vRpBsENVYyPmDd(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡒࡉࡗࡇࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥࠧ᯹"))
	TBt8bUDo9WhL(Yj1msqVeivESfrCupRy9b7WacBd(u"ࠨ࡮࡬ࡲࡰ࠭᯺"),bbTCMJwEx8nhN4X+FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧ᯻")+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,DFx6E0uON7Jm8(u"࠿࠹࠺࠻᳟"))
	MVkczJR1hAqEHKPxmtSbnZ = Nzp9Fq5cTr.menuItemsLIST[:]
	Nzp9Fq5cTr.menuItemsLIST[:] = []
	import W5tgT0hvbn
	W5tgT0hvbn.qTPzY96jGk8mQcNK3XvVHMUR4(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠪ࠴ࠬ᯼"),FFKncZx5pDTwdiJRYhMgQSNL)
	W5tgT0hvbn.qTPzY96jGk8mQcNK3XvVHMUR4(nfNTgkiWdUq(u"ࠫ࠶࠭᯽"),FFKncZx5pDTwdiJRYhMgQSNL)
	W5tgT0hvbn.qTPzY96jGk8mQcNK3XvVHMUR4(gmPI7hVEM8nD(u"ࠬ࠸ࠧ᯾"),FFKncZx5pDTwdiJRYhMgQSNL)
	if HD7MQqXd2gS(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ᯿") in QKHC8Vlk21Up:
		Nzp9Fq5cTr.menuItemsLIST[:] = fd0r782LaE4yto(Nzp9Fq5cTr.menuItemsLIST)
		if len(Nzp9Fq5cTr.menuItemsLIST)>Pkf0RaNHAUsqMKCzb6J7WSmwFOnG: Nzp9Fq5cTr.menuItemsLIST[:] = avZmSHVO7swUYFnTu5p9iNR8g.sample(Nzp9Fq5cTr.menuItemsLIST,Pkf0RaNHAUsqMKCzb6J7WSmwFOnG)
	Nzp9Fq5cTr.menuItemsLIST[:] = MVkczJR1hAqEHKPxmtSbnZ+Nzp9Fq5cTr.menuItemsLIST
	return
def va8SiyTtNq6OwAeguPGs(QKHC8Vlk21Up):
	QKHC8Vlk21Up = QKHC8Vlk21Up.replace(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᰀ"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(lw2snZ9J0uhLoxypqa(u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᰁ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	headers = { jil8vRpBsENVYyPmDd(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᰂ") : nA5dhMRg6ENzsB0l1GwvH7aIr2 }
	url = baBcNd81eH5ry2Olp6Mj43(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡨࡷࡹࡸࡡ࡯ࡦࡲࡱࡸ࠴ࡣࡰ࡯࠲ࡶࡦࡴࡤࡰ࡯࠰ࡥࡷࡧࡢࡪࡥ࠰ࡻࡴࡸࡤࡴࠩᰃ")
	data = {VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠫࡶࡻࡡ࡯ࡶ࡬ࡸࡾ࠭ᰄ"):jil8vRpBsENVYyPmDd(u"ࠬ࠻࠰ࠨᰅ")}
	data = U5gRdGyK1L90nskaxElqmiT4(data)
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(cbpdEaUM8rKSQvzuqiJyXwW4,pxt6wJ8ScYMWCivoO(u"࠭ࡇࡆࡖࠪᰆ"),url,data,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,Yj1msqVeivESfrCupRy9b7WacBd(u"ࠧࡓࡃࡑࡈࡔࡓࡓ࠮ࡔࡄࡒࡉࡕࡍࡠࡘࡌࡈࡊࡕࡓࡠࡈࡕࡓࡒࡥࡗࡐࡔࡇࡗ࠲࠷ࡳࡵࠩᰇ"))
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall(ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡤ࡮ࡨࡥࡷ࡬ࡩࡹࠤࠪᰈ"),kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[IpFcwrWNgefMym3qta0hYQAzOdE]
	items = PAztbuyYo4Kvd.findall(rCmGE4YIDaZA(u"ࠩ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧᰉ"),WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	uzSfclFIGs85LaExZ9COvXhPgwV6k,j8mMPBrYsL0xKOvzQi7Uf = list(zip(*items))
	EgMelp5RGv86w = []
	kFiQzSEPftmr3nB2aYjX65LZxw = [hSXlxL9iB05c,baBcNd81eH5ry2Olp6Mj43(u"ࠪࠦࠬᰊ"),lw2snZ9J0uhLoxypqa(u"ࠫࡥ࠭ᰋ"),LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠬ࠲ࠧᰌ"),baBcNd81eH5ry2Olp6Mj43(u"࠭࠮ࠨᰍ"),nfNTgkiWdUq(u"ࠧ࠻ࠩᰎ"),ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠨ࠽ࠪᰏ"),w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"ࠤࠪࠦᰐ"),bb1fgjsAq4N2xYwnoh39lm(u"ࠪ࠱ࠬᰑ")]
	A9PgHOtZdN = j8mMPBrYsL0xKOvzQi7Uf+uzSfclFIGs85LaExZ9COvXhPgwV6k
	for GTozhUX7q20Y in A9PgHOtZdN:
		if GTozhUX7q20Y in j8mMPBrYsL0xKOvzQi7Uf: PIpRBelhgxwyujL0TiDrQon = udq5tP0hwifHQCGYELDbOUI
		if GTozhUX7q20Y in uzSfclFIGs85LaExZ9COvXhPgwV6k: PIpRBelhgxwyujL0TiDrQon = tpMX1Bgs0bzv8OEafyW
		RK0mLwuPZkbrO8cBxng3tJ = [q3kZpRe28O0s1NaCXQ9SMuGKin in GTozhUX7q20Y for q3kZpRe28O0s1NaCXQ9SMuGKin in kFiQzSEPftmr3nB2aYjX65LZxw]
		if any(RK0mLwuPZkbrO8cBxng3tJ):
			rRxld1HykSCacZs0mzWXIBibn = RK0mLwuPZkbrO8cBxng3tJ.index(S5MWhgtZ37Xw)
			CGZMPEiuJBK = kFiQzSEPftmr3nB2aYjX65LZxw[rRxld1HykSCacZs0mzWXIBibn]
			zkVeHmAb6t = nA5dhMRg6ENzsB0l1GwvH7aIr2
			if GTozhUX7q20Y.count(CGZMPEiuJBK)>UnOIK1WBbw2: I5LOzdouCH0sQVYPgSA3pla,wnsl7DbHXxSv86yPiod,zkVeHmAb6t = GTozhUX7q20Y.split(CGZMPEiuJBK,udq5tP0hwifHQCGYELDbOUI)
			else: I5LOzdouCH0sQVYPgSA3pla,wnsl7DbHXxSv86yPiod = GTozhUX7q20Y.split(CGZMPEiuJBK,UnOIK1WBbw2)
			if len(I5LOzdouCH0sQVYPgSA3pla)>PIpRBelhgxwyujL0TiDrQon: EgMelp5RGv86w.append(I5LOzdouCH0sQVYPgSA3pla.lower())
			if len(wnsl7DbHXxSv86yPiod)>PIpRBelhgxwyujL0TiDrQon: EgMelp5RGv86w.append(wnsl7DbHXxSv86yPiod.lower())
			if len(zkVeHmAb6t)>PIpRBelhgxwyujL0TiDrQon: EgMelp5RGv86w.append(zkVeHmAb6t.lower())
		elif len(GTozhUX7q20Y)>PIpRBelhgxwyujL0TiDrQon: EgMelp5RGv86w.append(GTozhUX7q20Y.lower())
	for q3kZpRe28O0s1NaCXQ9SMuGKin in range(jil8vRpBsENVYyPmDd(u"࠹᳠")): avZmSHVO7swUYFnTu5p9iNR8g.shuffle(EgMelp5RGv86w)
	if n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࠬᰒ") in QKHC8Vlk21Up:
		d2hOsZCVKWfe5puXG3vwLP7cl = P4GWBlzIwnMq2
	elif YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠬࡥࡉࡑࡖ࡙ࡣࠬᰓ") in QKHC8Vlk21Up:
		d2hOsZCVKWfe5puXG3vwLP7cl = [VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠭ࡉࡑࡖ࡙ࠫᰔ")]
		import atoGunAmqK
		if not atoGunAmqK.jx8bBYMhnguRAHoWtXLFml(nA5dhMRg6ENzsB0l1GwvH7aIr2,S5MWhgtZ37Xw): return
	elif mRanX1HZupfSQVB2gsDGUO(u"ࠧࡠࡏ࠶࡙ࡤ࠭ᰕ") in QKHC8Vlk21Up:
		d2hOsZCVKWfe5puXG3vwLP7cl = [ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠨࡏ࠶࡙ࠬᰖ")]
		import Bn18ZLUmyw
		if not Bn18ZLUmyw.jx8bBYMhnguRAHoWtXLFml(nA5dhMRg6ENzsB0l1GwvH7aIr2,S5MWhgtZ37Xw): return
	count,dcuKCfv7yLnhlrO3E = IpFcwrWNgefMym3qta0hYQAzOdE,IpFcwrWNgefMym3qta0hYQAzOdE
	TBt8bUDo9WhL(xwIUQfiE7rmvYzH(u"ࠩࡩࡳࡱࡪࡥࡳࠩᰗ"),nfNTgkiWdUq(u"ࠪ࡟ࠥࠦ࡝ࠡ࠼ส่อำหࠡ฻้ࠫᰘ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,JvQd6LMoBX4hiy1C(u"࠲࠸࠷᳡"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,AJHaiQq3PRd5cphzGuELnVg9X(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᰙ")+QKHC8Vlk21Up)
	TBt8bUDo9WhL(AJHaiQq3PRd5cphzGuELnVg9X(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᰚ"),yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠭ลฺษาอࠥอไษฯฮࠤฬู๊ี๊สส๏࠭ᰛ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠳࠹࠸᳢"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nfNTgkiWdUq(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᰜ")+QKHC8Vlk21Up)
	TBt8bUDo9WhL(nfNTgkiWdUq(u"ࠨ࡮࡬ࡲࡰ࠭ᰝ"),bbTCMJwEx8nhN4X+AJHaiQq3PRd5cphzGuELnVg9X(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧᰞ")+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠼࠽࠾࠿᳣"))
	WU6TZi2ELf = Nzp9Fq5cTr.menuItemsLIST[:]
	Nzp9Fq5cTr.menuItemsLIST[:] = []
	iaKw8b1OA7rxRzCnqWUdB = []
	for GTozhUX7q20Y in EgMelp5RGv86w:
		wnsl7DbHXxSv86yPiod = PAztbuyYo4Kvd.findall(YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠪ࡟ࠥࡢࠬ࡝࠽࡟࠾ࡡ࠳࡜ࠬ࡞ࡀࡠࠧࡢࠧ࡝࡝࡟ࡡࡡ࠮࡜ࠪ࡞ࡾࡠࢂࡢࠡ࡝ࡂࠪᰟ")+Yj1msqVeivESfrCupRy9b7WacBd(u"ࠫࠨ࠭ᰠ")+AJHaiQq3PRd5cphzGuELnVg9X(u"ࠬࡢࠤ࡝ࠧ࡟ࡢࡡࠬ࡜ࠫ࡞ࡢࡠࡁࡢ࠾࡞ࠩᰡ"),GTozhUX7q20Y,PAztbuyYo4Kvd.DOTALL)
		if wnsl7DbHXxSv86yPiod: GTozhUX7q20Y = GTozhUX7q20Y.split(wnsl7DbHXxSv86yPiod[IpFcwrWNgefMym3qta0hYQAzOdE],UnOIK1WBbw2)[IpFcwrWNgefMym3qta0hYQAzOdE]
		MM2q1kDNSaGpULvAw = GTozhUX7q20Y.replace(Qy6wlfLoOpg1(u"࠭๑ࠨᰢ"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠧ๏ࠩᰣ"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(vzqjsVHSBlMpxC(u"ࠨํࠪᰤ"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(XEcWOIwkZKubV7vQ(u"ࠩ๒ࠫᰥ"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(JvQd6LMoBX4hiy1C(u"ࠪ๐ࠬᰦ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
		MM2q1kDNSaGpULvAw = MM2q1kDNSaGpULvAw.replace(nfNTgkiWdUq(u"ࠫ๕࠭ᰧ"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(PPxYugzLZwHX23yiK(u"ࠬ๓ࠧᰨ"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(JvQd6LMoBX4hiy1C(u"࠭๒ࠨᰩ"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(HD7MQqXd2gS(u"ࠧญࠩᰪ"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠨโࠪᰫ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
		if MM2q1kDNSaGpULvAw: iaKw8b1OA7rxRzCnqWUdB.append(MM2q1kDNSaGpULvAw)
	oPkKZe8G6yj0WxtsgFIq5TuQlrVM = []
	for hsqrMEVB70i2ZnzPHlGYD1oy in range(IpFcwrWNgefMym3qta0hYQAzOdE,HD7MQqXd2gS(u"࠶࠵᳤")):
		search = avZmSHVO7swUYFnTu5p9iNR8g.sample(iaKw8b1OA7rxRzCnqWUdB,UnOIK1WBbw2)[IpFcwrWNgefMym3qta0hYQAzOdE]
		if search in oPkKZe8G6yj0WxtsgFIq5TuQlrVM: continue
		oPkKZe8G6yj0WxtsgFIq5TuQlrVM.append(search)
		whXU4NCbPdFAcxErVJIutR8WDM3n = avZmSHVO7swUYFnTu5p9iNR8g.sample(d2hOsZCVKWfe5puXG3vwLP7cl,UnOIK1WBbw2)[IpFcwrWNgefMym3qta0hYQAzOdE]
		nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+gmPI7hVEM8nD(u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥ࡜ࡩࡥࡧࡲࠤࡘ࡫ࡡࡳࡥ࡫ࠤࠥࠦࡳࡪࡶࡨ࠾ࠬᰬ")+str(whXU4NCbPdFAcxErVJIutR8WDM3n)+ldIfvn6asURQ9toi85EhqAXW3(u"ࠪࠤࠥࡹࡥࡢࡴࡦ࡬࠿࠭ᰭ")+search)
		hT9D8fRSNgycG36k,vlm7dBDy2RXPj1C8,CYv7ydT6WAGtu0o = EN1Pg52zbjsmLMQq9(whXU4NCbPdFAcxErVJIutR8WDM3n)
		vlm7dBDy2RXPj1C8(search+XEcWOIwkZKubV7vQ(u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩᰮ"))
		if len(Nzp9Fq5cTr.menuItemsLIST)>IpFcwrWNgefMym3qta0hYQAzOdE: break
	search = search.replace(DFx6E0uON7Jm8(u"ࠬࡥࡍࡐࡆࡢࠫᰯ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	WU6TZi2ELf[IpFcwrWNgefMym3qta0hYQAzOdE][UnOIK1WBbw2] = AJHaiQq3PRd5cphzGuELnVg9X(u"࡛࠭ࠨᰰ")+bbTCMJwEx8nhN4X+search+NwROdSj3nsA+bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠧࠡ࠼หัะูࠦ็࡟ࠪᰱ")
	Nzp9Fq5cTr.menuItemsLIST[:] = fd0r782LaE4yto(Nzp9Fq5cTr.menuItemsLIST)
	if len(Nzp9Fq5cTr.menuItemsLIST)>Pkf0RaNHAUsqMKCzb6J7WSmwFOnG: Nzp9Fq5cTr.menuItemsLIST[:] = avZmSHVO7swUYFnTu5p9iNR8g.sample(Nzp9Fq5cTr.menuItemsLIST,Pkf0RaNHAUsqMKCzb6J7WSmwFOnG)
	Nzp9Fq5cTr.menuItemsLIST[:] = WU6TZi2ELf+Nzp9Fq5cTr.menuItemsLIST
	return
def KBb3w9L5MVNqZtIO(C8wDVTRjNIQyHAS91sgMzGXhPdv,QKHC8Vlk21Up):
	C8wDVTRjNIQyHAS91sgMzGXhPdv = C8wDVTRjNIQyHAS91sgMzGXhPdv.replace(bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠨࡡࡐࡓࡉࡥࠧᰲ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	QKHC8Vlk21Up = QKHC8Vlk21Up.replace(zhE5I4xHinX0UoVZMNwlkPrR(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᰳ"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(AJHaiQq3PRd5cphzGuELnVg9X(u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᰴ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	NDGKQC9HV0(FFKncZx5pDTwdiJRYhMgQSNL)
	if not Vjy0JqnlGvRbiN1z5roxI3KCkX: return
	if VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭ᰵ") in QKHC8Vlk21Up:
		TBt8bUDo9WhL(bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᰶ"),bb1fgjsAq4N2xYwnoh39lm(u"࡛࠭ࠨ᰷")+bbTCMJwEx8nhN4X+C8wDVTRjNIQyHAS91sgMzGXhPdv+NwROdSj3nsA+FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠧࠡ࠼ส่็ูๅ࡞ࠩ᰸"),C8wDVTRjNIQyHAS91sgMzGXhPdv,baBcNd81eH5ry2Olp6Mj43(u"࠶࠼࠶᳥"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,gmPI7hVEM8nD(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᰹")+QKHC8Vlk21Up)
		TBt8bUDo9WhL(gmPI7hVEM8nD(u"ࠩࡩࡳࡱࡪࡥࡳࠩ᰺"),jil8vRpBsENVYyPmDd(u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩ᰻"),C8wDVTRjNIQyHAS91sgMzGXhPdv,pxt6wJ8ScYMWCivoO(u"࠷࠶࠷᳦"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ᰼")+QKHC8Vlk21Up)
		TBt8bUDo9WhL(UUobzy0xZLaVScIt7(u"ࠬࡲࡩ࡯࡭ࠪ᰽"),bbTCMJwEx8nhN4X+bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫ᰾")+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,lw2snZ9J0uhLoxypqa(u"࠹࠺࠻࠼᳧"))
	for website in sorted(list(Vjy0JqnlGvRbiN1z5roxI3KCkX[C8wDVTRjNIQyHAS91sgMzGXhPdv].keys())):
		type,w8cPT5nhW2RUAFKDa,url,HXq9bKhZ8c4SxY2iA,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,OOrjZaTIVXQ2Sp0ozhc,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4 = Vjy0JqnlGvRbiN1z5roxI3KCkX[C8wDVTRjNIQyHAS91sgMzGXhPdv][website]
		if Yj1msqVeivESfrCupRy9b7WacBd(u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩ᰿") in QKHC8Vlk21Up or len(Vjy0JqnlGvRbiN1z5roxI3KCkX[C8wDVTRjNIQyHAS91sgMzGXhPdv])==UnOIK1WBbw2:
			uliqcaDoAVbL2(type,nA5dhMRg6ENzsB0l1GwvH7aIr2,url,HXq9bKhZ8c4SxY2iA,nA5dhMRg6ENzsB0l1GwvH7aIr2,Q0f7ytucSriRw8HTzd,OOrjZaTIVXQ2Sp0ozhc,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2)
			Nzp9Fq5cTr.menuItemsLIST[:] = fd0r782LaE4yto(Nzp9Fq5cTr.menuItemsLIST)
			pYyO6d7ceuQBt,tD8imP0HBbe = Nzp9Fq5cTr.menuItemsLIST[:AH0zdvBqibaXY],Nzp9Fq5cTr.menuItemsLIST[AH0zdvBqibaXY:]
			if HD7MQqXd2gS(u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪ᱀") in QKHC8Vlk21Up:
				for q3kZpRe28O0s1NaCXQ9SMuGKin in range(UUobzy0xZLaVScIt7(u"࠺᳨")): avZmSHVO7swUYFnTu5p9iNR8g.shuffle(tD8imP0HBbe)
				Nzp9Fq5cTr.menuItemsLIST[:] = pYyO6d7ceuQBt+tD8imP0HBbe[:Pkf0RaNHAUsqMKCzb6J7WSmwFOnG]
			else: Nzp9Fq5cTr.menuItemsLIST[:] = pYyO6d7ceuQBt+tD8imP0HBbe
		elif nfNTgkiWdUq(u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࠪ᱁") in QKHC8Vlk21Up: TBt8bUDo9WhL(Yj1msqVeivESfrCupRy9b7WacBd(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᱂"),website,url,HXq9bKhZ8c4SxY2iA,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,OOrjZaTIVXQ2Sp0ozhc,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4)
	return
def I06Rawhn4XT2fb8QPgt9vxpLCE5q(QKHC8Vlk21Up,knBV0UPuCNdpIsAFH3coRKjh2lb):
	QKHC8Vlk21Up = QKHC8Vlk21Up.replace(PPxYugzLZwHX23yiK(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭᱃"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(pxt6wJ8ScYMWCivoO(u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ᱄"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	w8cPT5nhW2RUAFKDa,tD8imP0HBbe = nA5dhMRg6ENzsB0l1GwvH7aIr2,[]
	TBt8bUDo9WhL(AJHaiQq3PRd5cphzGuELnVg9X(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᱅"),xwIUQfiE7rmvYzH(u"ࠧ࡜ࠩ᱆")+bbTCMJwEx8nhN4X+w8cPT5nhW2RUAFKDa+NwROdSj3nsA+PPxYugzLZwHX23yiK(u"ࠨࠢ࠽ห้่ำๆ࡟ࠪ᱇"),nA5dhMRg6ENzsB0l1GwvH7aIr2,knBV0UPuCNdpIsAFH3coRKjh2lb,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,bb1fgjsAq4N2xYwnoh39lm(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ᱈")+QKHC8Vlk21Up)
	TBt8bUDo9WhL(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᱉"),bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠫส฿วะหࠣ฻้ฮࠠใี่ࠤ฾ฺ่ศศํࠫ᱊"),nA5dhMRg6ENzsB0l1GwvH7aIr2,knBV0UPuCNdpIsAFH3coRKjh2lb,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nfNTgkiWdUq(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᱋")+QKHC8Vlk21Up)
	TBt8bUDo9WhL(Yj1msqVeivESfrCupRy9b7WacBd(u"࠭࡬ࡪࡰ࡮ࠫ᱌"),bbTCMJwEx8nhN4X+bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬᱍ")+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,DFx6E0uON7Jm8(u"࠻࠼࠽࠾ᳩ"))
	pYyO6d7ceuQBt = Nzp9Fq5cTr.menuItemsLIST[:]
	Nzp9Fq5cTr.menuItemsLIST[:] = []
	V9OGBuyogH0CaUtQS6wWErAbPYDjlM = []
	if bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࠩᱎ") in QKHC8Vlk21Up:
		NDGKQC9HV0(FFKncZx5pDTwdiJRYhMgQSNL)
		if not Vjy0JqnlGvRbiN1z5roxI3KCkX: return
		qQdIzBPeGsRn5cf8WA07VHo1 = list(Vjy0JqnlGvRbiN1z5roxI3KCkX.keys())
		C8wDVTRjNIQyHAS91sgMzGXhPdv = avZmSHVO7swUYFnTu5p9iNR8g.sample(qQdIzBPeGsRn5cf8WA07VHo1,UnOIK1WBbw2)[IpFcwrWNgefMym3qta0hYQAzOdE]
		EgMelp5RGv86w = list(Vjy0JqnlGvRbiN1z5roxI3KCkX[C8wDVTRjNIQyHAS91sgMzGXhPdv].keys())
		website = avZmSHVO7swUYFnTu5p9iNR8g.sample(EgMelp5RGv86w,UnOIK1WBbw2)[IpFcwrWNgefMym3qta0hYQAzOdE]
		type,w8cPT5nhW2RUAFKDa,url,HXq9bKhZ8c4SxY2iA,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,OOrjZaTIVXQ2Sp0ozhc,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4 = Vjy0JqnlGvRbiN1z5roxI3KCkX[C8wDVTRjNIQyHAS91sgMzGXhPdv][website]
		nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥࡉࡡࡵࡧࡪࡳࡷࡿࠠࠡࠢࡺࡩࡧࡹࡩࡵࡧ࠽ࠤࠬᱏ")+website+XEcWOIwkZKubV7vQ(u"ࠪࠤࠥࠦ࡮ࡢ࡯ࡨ࠾ࠥ࠭᱐")+w8cPT5nhW2RUAFKDa+PPxYugzLZwHX23yiK(u"ࠫࠥࠦࠠࡶࡴ࡯࠾ࠥ࠭᱑")+url+ldIfvn6asURQ9toi85EhqAXW3(u"ࠬࠦࠠࠡ࡯ࡲࡨࡪࡀࠠࠨ᱒")+str(HXq9bKhZ8c4SxY2iA))
	elif pxt6wJ8ScYMWCivoO(u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭᱓") in QKHC8Vlk21Up:
		import atoGunAmqK
		if not atoGunAmqK.jx8bBYMhnguRAHoWtXLFml(nA5dhMRg6ENzsB0l1GwvH7aIr2,S5MWhgtZ37Xw): return
		for QLSRWqIZ71KXcsJO2 in range(UnOIK1WBbw2,EYcbkTrLd8MqHSXzxFGft+UnOIK1WBbw2):
			V9OGBuyogH0CaUtQS6wWErAbPYDjlM += giKatT6eG4sfjRPoBYElFpZvCUzN(str(QLSRWqIZ71KXcsJO2),QKHC8Vlk21Up)
		if not V9OGBuyogH0CaUtQS6wWErAbPYDjlM: return
		type,w8cPT5nhW2RUAFKDa,url,HXq9bKhZ8c4SxY2iA,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,OOrjZaTIVXQ2Sp0ozhc,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4 = avZmSHVO7swUYFnTu5p9iNR8g.sample(V9OGBuyogH0CaUtQS6wWErAbPYDjlM,UnOIK1WBbw2)[IpFcwrWNgefMym3qta0hYQAzOdE]
		nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+nfNTgkiWdUq(u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠ࡯ࡣࡰࡩ࠿ࠦࠧ᱔")+w8cPT5nhW2RUAFKDa+pxt6wJ8ScYMWCivoO(u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪ᱕")+url+jil8vRpBsENVYyPmDd(u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬ᱖")+str(HXq9bKhZ8c4SxY2iA))
	elif Pj9YaUq1ibJ(u"ࠪࡣࡒ࠹ࡕࡠࠩ᱗") in QKHC8Vlk21Up:
		import Bn18ZLUmyw
		if not Bn18ZLUmyw.jx8bBYMhnguRAHoWtXLFml(nA5dhMRg6ENzsB0l1GwvH7aIr2,S5MWhgtZ37Xw): return
		for QLSRWqIZ71KXcsJO2 in range(UnOIK1WBbw2,EYcbkTrLd8MqHSXzxFGft+UnOIK1WBbw2):
			V9OGBuyogH0CaUtQS6wWErAbPYDjlM += RRIgrJoCn8Lh4kdMa(str(QLSRWqIZ71KXcsJO2),QKHC8Vlk21Up)
		if not V9OGBuyogH0CaUtQS6wWErAbPYDjlM: return
		type,w8cPT5nhW2RUAFKDa,url,HXq9bKhZ8c4SxY2iA,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,OOrjZaTIVXQ2Sp0ozhc,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4 = avZmSHVO7swUYFnTu5p9iNR8g.sample(V9OGBuyogH0CaUtQS6wWErAbPYDjlM,UnOIK1WBbw2)[IpFcwrWNgefMym3qta0hYQAzOdE]
		nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+jil8vRpBsENVYyPmDd(u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫ᱘")+w8cPT5nhW2RUAFKDa+JvQd6LMoBX4hiy1C(u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧ᱙")+url+Pj9YaUq1ibJ(u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩᱚ")+str(HXq9bKhZ8c4SxY2iA))
	tdUi8pPCVo4q1xrIRS2HzclNY0Q = w8cPT5nhW2RUAFKDa
	ggHtoy5lFCSj4qmP = []
	for q3kZpRe28O0s1NaCXQ9SMuGKin in range(IpFcwrWNgefMym3qta0hYQAzOdE,bb1fgjsAq4N2xYwnoh39lm(u"࠴࠴ᳪ")):
		if q3kZpRe28O0s1NaCXQ9SMuGKin>IpFcwrWNgefMym3qta0hYQAzOdE: nhR0UxwS4yDiABj7V1G8la(gqsRPaf8EzGDeKx7WdZkuX0YrV1,PN7XfUGhIx5wVApBjYtJnzCc(wgj0rX5tbcxPulhmny)+PPxYugzLZwHX23yiK(u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠ࡯ࡣࡰࡩ࠿ࠦࠧᱛ")+w8cPT5nhW2RUAFKDa+Yj1msqVeivESfrCupRy9b7WacBd(u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪᱜ")+url+AJHaiQq3PRd5cphzGuELnVg9X(u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬᱝ")+str(HXq9bKhZ8c4SxY2iA))
		Nzp9Fq5cTr.menuItemsLIST[:] = []
		if HXq9bKhZ8c4SxY2iA==yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠶࠸࠺ᳫ") and zhE5I4xHinX0UoVZMNwlkPrR(u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫᱞ") in OOrjZaTIVXQ2Sp0ozhc: HXq9bKhZ8c4SxY2iA = lw2snZ9J0uhLoxypqa(u"࠷࠹࠳ᳬ")
		if HXq9bKhZ8c4SxY2iA==Qy6wlfLoOpg1(u"࠽࠱࠵᳭") and lw2snZ9J0uhLoxypqa(u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫᱟ") in OOrjZaTIVXQ2Sp0ozhc: HXq9bKhZ8c4SxY2iA = yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠷࠲࠵ᳮ")
		if HXq9bKhZ8c4SxY2iA==yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠲࠶࠷ᳯ"): HXq9bKhZ8c4SxY2iA = xwIUQfiE7rmvYzH(u"࠴࠼࠵ᳰ")
		eIlXpH1gLhmP4w3 = uliqcaDoAVbL2(type,w8cPT5nhW2RUAFKDa,url,HXq9bKhZ8c4SxY2iA,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,OOrjZaTIVXQ2Sp0ozhc,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4)
		if HD7MQqXd2gS(u"ࠬࡥࡉࡑࡖ࡙ࡣࠬᱠ") in QKHC8Vlk21Up and HXq9bKhZ8c4SxY2iA==w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠴࠺࠼ᳱ"): del Nzp9Fq5cTr.menuItemsLIST[:AH0zdvBqibaXY]
		if xwIUQfiE7rmvYzH(u"࠭࡟ࡎ࠵ࡘࡣࠬᱡ") in QKHC8Vlk21Up and HXq9bKhZ8c4SxY2iA==zhE5I4xHinX0UoVZMNwlkPrR(u"࠵࠻࠾ᳲ"): del Nzp9Fq5cTr.menuItemsLIST[:AH0zdvBqibaXY]
		tD8imP0HBbe[:] = fd0r782LaE4yto(Nzp9Fq5cTr.menuItemsLIST)
		if ggHtoy5lFCSj4qmP and ekQTdRyiGNCuj6bhgwx4(XEcWOIwkZKubV7vQ(u"ࡵࠨฯ็ๆฮ࠭ᱢ")) in str(tD8imP0HBbe) or ekQTdRyiGNCuj6bhgwx4(Pj9YaUq1ibJ(u"ࡶࠩะ่็ํࠧᱣ")) in str(tD8imP0HBbe):
			w8cPT5nhW2RUAFKDa = tdUi8pPCVo4q1xrIRS2HzclNY0Q
			tD8imP0HBbe[:] = ggHtoy5lFCSj4qmP
			break
		tdUi8pPCVo4q1xrIRS2HzclNY0Q = w8cPT5nhW2RUAFKDa
		ggHtoy5lFCSj4qmP = tD8imP0HBbe
		if str(tD8imP0HBbe).count(AJHaiQq3PRd5cphzGuELnVg9X(u"ࠩࡹ࡭ࡩ࡫࡯ࠨᱤ"))>IpFcwrWNgefMym3qta0hYQAzOdE: break
		if str(tD8imP0HBbe).count(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠪࡰ࡮ࡼࡥࠨᱥ"))>IpFcwrWNgefMym3qta0hYQAzOdE: break
		if HXq9bKhZ8c4SxY2iA==AJHaiQq3PRd5cphzGuELnVg9X(u"࠷࠹࠳ᳳ"): break
		if HXq9bKhZ8c4SxY2iA==yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠽࠱࠴᳴"): break
		if HXq9bKhZ8c4SxY2iA==n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠲࠺࠳ᳵ"): break
		if PPxYugzLZwHX23yiK(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭ᱦ") in QKHC8Vlk21Up and tD8imP0HBbe: type,w8cPT5nhW2RUAFKDa,url,HXq9bKhZ8c4SxY2iA,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,OOrjZaTIVXQ2Sp0ozhc,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4 = avZmSHVO7swUYFnTu5p9iNR8g.sample(tD8imP0HBbe,UnOIK1WBbw2)[IpFcwrWNgefMym3qta0hYQAzOdE]
	if not w8cPT5nhW2RUAFKDa: w8cPT5nhW2RUAFKDa = HD7MQqXd2gS(u"ࠬ࠴࠮࠯࠰ࠪᱧ")
	elif w8cPT5nhW2RUAFKDa.count(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠭࡟ࠨᱨ"))>UnOIK1WBbw2: w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.split(jil8vRpBsENVYyPmDd(u"ࠧࡠࠩᱩ"),udq5tP0hwifHQCGYELDbOUI)[udq5tP0hwifHQCGYELDbOUI]
	w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(lw2snZ9J0uhLoxypqa(u"ࠨࡗࡑࡏࡓࡕࡗࡏ࠼ࠣࠫᱪ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	w8cPT5nhW2RUAFKDa = w8cPT5nhW2RUAFKDa.replace(baBcNd81eH5ry2Olp6Mj43(u"ࠩࡢࡑࡔࡊ࡟ࠨᱫ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	pYyO6d7ceuQBt[IpFcwrWNgefMym3qta0hYQAzOdE][UnOIK1WBbw2] = pxt6wJ8ScYMWCivoO(u"ࠪ࡟ࠬᱬ")+bbTCMJwEx8nhN4X+w8cPT5nhW2RUAFKDa+NwROdSj3nsA+AJHaiQq3PRd5cphzGuELnVg9X(u"ࠫࠥࡀวๅไึ้ࡢ࠭ᱭ")
	if nfNTgkiWdUq(u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧᱮ") in QKHC8Vlk21Up:
		for q3kZpRe28O0s1NaCXQ9SMuGKin in range(bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠺ᳶ")): avZmSHVO7swUYFnTu5p9iNR8g.shuffle(tD8imP0HBbe)
		Nzp9Fq5cTr.menuItemsLIST[:] = pYyO6d7ceuQBt+tD8imP0HBbe[:Pkf0RaNHAUsqMKCzb6J7WSmwFOnG]
	else: Nzp9Fq5cTr.menuItemsLIST[:] = pYyO6d7ceuQBt+tD8imP0HBbe
	return
def BWKk5bsi2FvSzq(Nb68XMOavKFl392V5YLUdwWQ,mKEj8H7NQR6Y1FUbCa5z4):
	mKEj8H7NQR6Y1FUbCa5z4 = mKEj8H7NQR6Y1FUbCa5z4.replace(jil8vRpBsENVYyPmDd(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᱯ"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(lw2snZ9J0uhLoxypqa(u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᱰ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	A409dcvrmtkY = mKEj8H7NQR6Y1FUbCa5z4
	if yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠨࡡࡢࡍࡕ࡚ࡖࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩᱱ") in mKEj8H7NQR6Y1FUbCa5z4:
		A409dcvrmtkY = mKEj8H7NQR6Y1FUbCa5z4.split(XEcWOIwkZKubV7vQ(u"ࠩࡢࡣࡎࡖࡔࡗࡕࡨࡶ࡮࡫ࡳࡠࡡࠪᱲ"))[IpFcwrWNgefMym3qta0hYQAzOdE]
		type = baBcNd81eH5ry2Olp6Mj43(u"ࠪ࠰ࡘࡋࡒࡊࡇࡖ࠾ࠥ࠭ᱳ")
	elif PPxYugzLZwHX23yiK(u"࡛ࠫࡕࡄࠨᱴ") in Nb68XMOavKFl392V5YLUdwWQ: type = bb1fgjsAq4N2xYwnoh39lm(u"ࠬ࠲ࡖࡊࡆࡈࡓࡘࡀࠠࠨᱵ")
	elif bb1fgjsAq4N2xYwnoh39lm(u"࠭ࡌࡊࡘࡈࠫᱶ") in Nb68XMOavKFl392V5YLUdwWQ: type = vzqjsVHSBlMpxC(u"ࠧ࠭ࡎࡌ࡚ࡊࡀࠠࠨᱷ")
	TBt8bUDo9WhL(gmPI7hVEM8nD(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᱸ"),bb1fgjsAq4N2xYwnoh39lm(u"ࠩ࡞ࠫᱹ")+bbTCMJwEx8nhN4X+type+A409dcvrmtkY+NwROdSj3nsA+HD7MQqXd2gS(u"ࠪࠤ࠿อไใี่ࡡࠬᱺ"),Nb68XMOavKFl392V5YLUdwWQ,Qy6wlfLoOpg1(u"࠳࠹࠻᳷"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,xwIUQfiE7rmvYzH(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᱻ")+mKEj8H7NQR6Y1FUbCa5z4)
	TBt8bUDo9WhL(UUobzy0xZLaVScIt7(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᱼ"),ZjELJ9VrUT07R8Hn4FuSDcf(u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬᱽ"),Nb68XMOavKFl392V5YLUdwWQ,UUobzy0xZLaVScIt7(u"࠴࠺࠼᳸"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,vzqjsVHSBlMpxC(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᱾")+mKEj8H7NQR6Y1FUbCa5z4)
	TBt8bUDo9WhL(bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠨ࡮࡬ࡲࡰ࠭᱿"),bbTCMJwEx8nhN4X+n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧᲀ")+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,zhE5I4xHinX0UoVZMNwlkPrR(u"࠽࠾࠿࠹᳹"))
	import atoGunAmqK
	for QLSRWqIZ71KXcsJO2 in range(UnOIK1WBbw2,EYcbkTrLd8MqHSXzxFGft+UnOIK1WBbw2):
		if XEcWOIwkZKubV7vQ(u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫᲁ") in mKEj8H7NQR6Y1FUbCa5z4: atoGunAmqK.oHJ5CWIeGX8up7hTKxOdzNPrk(str(QLSRWqIZ71KXcsJO2),Nb68XMOavKFl392V5YLUdwWQ,mKEj8H7NQR6Y1FUbCa5z4,nA5dhMRg6ENzsB0l1GwvH7aIr2,FFKncZx5pDTwdiJRYhMgQSNL)
		else: atoGunAmqK.qTPzY96jGk8mQcNK3XvVHMUR4(str(QLSRWqIZ71KXcsJO2),Nb68XMOavKFl392V5YLUdwWQ,mKEj8H7NQR6Y1FUbCa5z4,nA5dhMRg6ENzsB0l1GwvH7aIr2,FFKncZx5pDTwdiJRYhMgQSNL)
	Nzp9Fq5cTr.menuItemsLIST[:] = fd0r782LaE4yto(Nzp9Fq5cTr.menuItemsLIST)
	if len(Nzp9Fq5cTr.menuItemsLIST)>(Pkf0RaNHAUsqMKCzb6J7WSmwFOnG+AH0zdvBqibaXY): Nzp9Fq5cTr.menuItemsLIST[:] = Nzp9Fq5cTr.menuItemsLIST[:AH0zdvBqibaXY]+avZmSHVO7swUYFnTu5p9iNR8g.sample(Nzp9Fq5cTr.menuItemsLIST[AH0zdvBqibaXY:],Pkf0RaNHAUsqMKCzb6J7WSmwFOnG)
	return
def fzVRjEIm1Gr5MKSHC23FeNh7(Nb68XMOavKFl392V5YLUdwWQ,mKEj8H7NQR6Y1FUbCa5z4):
	mKEj8H7NQR6Y1FUbCa5z4 = mKEj8H7NQR6Y1FUbCa5z4.replace(LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᲂ"),nA5dhMRg6ENzsB0l1GwvH7aIr2).replace(AJHaiQq3PRd5cphzGuELnVg9X(u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᲃ"),nA5dhMRg6ENzsB0l1GwvH7aIr2)
	A409dcvrmtkY = mKEj8H7NQR6Y1FUbCa5z4
	if vzqjsVHSBlMpxC(u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭ᲄ") in mKEj8H7NQR6Y1FUbCa5z4:
		A409dcvrmtkY = mKEj8H7NQR6Y1FUbCa5z4.split(YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠧࡠࡡࡐ࠷࡚࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧᲅ"))[IpFcwrWNgefMym3qta0hYQAzOdE]
		type = VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠨ࠮ࡖࡉࡗࡏࡅࡔ࠼ࠣࠫᲆ")
	elif vzqjsVHSBlMpxC(u"࡙ࠩࡓࡉ࠭ᲇ") in Nb68XMOavKFl392V5YLUdwWQ: type = n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠪ࠰࡛ࡏࡄࡆࡑࡖ࠾ࠥ࠭ᲈ")
	elif mRanX1HZupfSQVB2gsDGUO(u"ࠫࡑࡏࡖࡆࠩᲉ") in Nb68XMOavKFl392V5YLUdwWQ: type = LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠬ࠲ࡌࡊࡘࡈ࠾ࠥ࠭ᲊ")
	TBt8bUDo9WhL(VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᲋"),n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠧ࡜ࠩ᲌")+bbTCMJwEx8nhN4X+type+A409dcvrmtkY+NwROdSj3nsA+LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠨࠢ࠽ห้่ำๆ࡟ࠪ᲍"),Nb68XMOavKFl392V5YLUdwWQ,yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠶࠼࠸ᳺ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,gmPI7hVEM8nD(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ᲎")+mKEj8H7NQR6Y1FUbCa5z4)
	TBt8bUDo9WhL(lw2snZ9J0uhLoxypqa(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᲏"),AJHaiQq3PRd5cphzGuELnVg9X(u"ࠫส฿วะหࠣห้฽ไษࠢส่฾ฺ่ศศํࠤ๊์ࠠ็ใึࠤฬ๊โิ็ࠪᲐ"),Nb68XMOavKFl392V5YLUdwWQ,mRanX1HZupfSQVB2gsDGUO(u"࠷࠶࠹᳻"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᲑ")+mKEj8H7NQR6Y1FUbCa5z4)
	TBt8bUDo9WhL(bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠭࡬ࡪࡰ࡮ࠫᲒ"),bbTCMJwEx8nhN4X+bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬᲓ")+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,DFx6E0uON7Jm8(u"࠹࠺࠻࠼᳼"))
	import Bn18ZLUmyw
	for QLSRWqIZ71KXcsJO2 in range(UnOIK1WBbw2,EYcbkTrLd8MqHSXzxFGft+UnOIK1WBbw2):
		if HD7MQqXd2gS(u"ࠨࡡࡢࡑ࠸࡛ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨᲔ") in mKEj8H7NQR6Y1FUbCa5z4: Bn18ZLUmyw.oHJ5CWIeGX8up7hTKxOdzNPrk(str(QLSRWqIZ71KXcsJO2),Nb68XMOavKFl392V5YLUdwWQ,mKEj8H7NQR6Y1FUbCa5z4,nA5dhMRg6ENzsB0l1GwvH7aIr2,FFKncZx5pDTwdiJRYhMgQSNL)
		else: Bn18ZLUmyw.qTPzY96jGk8mQcNK3XvVHMUR4(str(QLSRWqIZ71KXcsJO2),Nb68XMOavKFl392V5YLUdwWQ,mKEj8H7NQR6Y1FUbCa5z4,nA5dhMRg6ENzsB0l1GwvH7aIr2,FFKncZx5pDTwdiJRYhMgQSNL)
	Nzp9Fq5cTr.menuItemsLIST[:] = fd0r782LaE4yto(Nzp9Fq5cTr.menuItemsLIST)
	if len(Nzp9Fq5cTr.menuItemsLIST)>(Pkf0RaNHAUsqMKCzb6J7WSmwFOnG+AH0zdvBqibaXY): Nzp9Fq5cTr.menuItemsLIST[:] = Nzp9Fq5cTr.menuItemsLIST[:AH0zdvBqibaXY]+avZmSHVO7swUYFnTu5p9iNR8g.sample(Nzp9Fq5cTr.menuItemsLIST[AH0zdvBqibaXY:],Pkf0RaNHAUsqMKCzb6J7WSmwFOnG)
	return
def fd0r782LaE4yto(K2prH1jo6RPg4EhkABMzS0DLwNcOst):
	doanfOcMP6JAXqwNY1gTFItpDUZ = []
	for type,w8cPT5nhW2RUAFKDa,url,knBV0UPuCNdpIsAFH3coRKjh2lb,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,OOrjZaTIVXQ2Sp0ozhc,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4 in K2prH1jo6RPg4EhkABMzS0DLwNcOst:
		if ZjELJ9VrUT07R8Hn4FuSDcf(u"ุࠩๅาฯࠧᲕ") in w8cPT5nhW2RUAFKDa or XEcWOIwkZKubV7vQ(u"ูࠪๆำ็ࠨᲖ") in w8cPT5nhW2RUAFKDa or PPxYugzLZwHX23yiK(u"ࠫࡵࡧࡧࡦࠩᲗ") in w8cPT5nhW2RUAFKDa.lower(): continue
		doanfOcMP6JAXqwNY1gTFItpDUZ.append([type,w8cPT5nhW2RUAFKDa,url,knBV0UPuCNdpIsAFH3coRKjh2lb,io76Hju84PtJO3hE5x9KZnpGmalIw,Q0f7ytucSriRw8HTzd,OOrjZaTIVXQ2Sp0ozhc,kSqp7Ua0gATvrXG2RFdzN,Xxcm31HuozfbJEAv8Rl7PwUgGBF4])
	return doanfOcMP6JAXqwNY1gTFItpDUZ
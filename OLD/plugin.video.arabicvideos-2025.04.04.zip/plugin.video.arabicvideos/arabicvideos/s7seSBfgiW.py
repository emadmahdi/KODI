# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'EGYBEST4'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_EB4_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
SAsGubf1jW2Q3p = ['ايجي بست','اتصل بنا','ايجي بست الاصلي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست']
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,Q0f7ytucSriRw8HTzd,text):
	if   mode==800: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==801: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,Q0f7ytucSriRw8HTzd)
	elif mode==802: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = oWcvptkU2JObI0(url)
	elif mode==803: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==804: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = rYAf8NzmSqsLXgpKMVUCIHtjZ1JucD(url)
	elif mode==806: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = SNVTEdvxWujYnGR7J6hACUP(url,Q0f7ytucSriRw8HTzd)
	elif mode==809: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,809,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فلتر',GiqvpBF9xLEdHDr37byJSngeCQ+'/trending',804,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBEST4-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('nav-categories(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			title = title.strip(hSXlxL9iB05c)
			if any(value in title for value in SAsGubf1jW2Q3p): continue
			if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,801)
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('mainContent(.*?)<footer>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('mainTitle.*?href="(.*?)".*?title="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			title = title.strip(hSXlxL9iB05c)
			if any(value in title for value in SAsGubf1jW2Q3p): continue
			if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,801,nA5dhMRg6ENzsB0l1GwvH7aIr2,'mainmenu')
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('main-menu(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			title = title.strip(hSXlxL9iB05c)
			if any(value in title for value in SAsGubf1jW2Q3p): continue
			if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,801)
	return kl2ZWdy8rXcHT
def SNVTEdvxWujYnGR7J6hACUP(url,type=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBEST4-SEASONS_EPISODES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('mainTitle.*?>(.*?)<(.*?)pageContent',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		wWeVHSMqxGR,GGr9WlIhv1BKDJjTZFNty4R3k0dCOA,items = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,[]
		for name,WWU7QJP2tyTRLIfDh0csxbkvX in zz3eHskxE6lAyDR5cNj1ug:
			if 'حلقات' in name: GGr9WlIhv1BKDJjTZFNty4R3k0dCOA = WWU7QJP2tyTRLIfDh0csxbkvX
			if 'مواسم' in name: wWeVHSMqxGR = WWU7QJP2tyTRLIfDh0csxbkvX
		if wWeVHSMqxGR and not type:
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',wWeVHSMqxGR,PAztbuyYo4Kvd.DOTALL)
			if len(items)>1:
				for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,806,HRlygv7YwjzbSLt8fkEerq2,'season')
		if GGr9WlIhv1BKDJjTZFNty4R3k0dCOA and len(items)<2:
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',GGr9WlIhv1BKDJjTZFNty4R3k0dCOA,PAztbuyYo4Kvd.DOTALL)
			if items:
				for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
					TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,803,HRlygv7YwjzbSLt8fkEerq2)
			else:
				items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',GGr9WlIhv1BKDJjTZFNty4R3k0dCOA,PAztbuyYo4Kvd.DOTALL)
				for ZylHkumQ8zD0,title in items:
					TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,803)
	return
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,type=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	mmpqeadyUFbYhXR7fsHMQN1wlu6LDI,start,LV9moOrXWFKbGYevPgul,select,ssb3JvMHKk8C0O = 0,0,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	if 'pagination' in type:
		kHgE2dbiQNuP,rA4ZGoQyIHlneVfzNukWd = url.split('?next=page&')
		LevQwm0pbqP1 = {'Content-Type':'application/x-www-form-urlencoded'}
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'POST',kHgE2dbiQNuP,rA4ZGoQyIHlneVfzNukWd,LevQwm0pbqP1,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBEST4-TITLES-1st')
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
		v2u4dgJnek0sQDxKf = 'secContent'+kl2ZWdy8rXcHT+'<footer>'
	else:
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBEST4-TITLES-2nd')
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
		v2u4dgJnek0sQDxKf = kl2ZWdy8rXcHT
	items,ddoTyXHWlmDVAnEpzGwhxu7i,tgsLX2uACmFhVznejRy6O = [],False,False
	if not type and '/collections' not in url:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('mainContent(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?</i>(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,title in items:
				title = title.strip(hSXlxL9iB05c)
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,801,nA5dhMRg6ENzsB0l1GwvH7aIr2,'submenu')
				ddoTyXHWlmDVAnEpzGwhxu7i = True
	if not ddoTyXHWlmDVAnEpzGwhxu7i:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('secContent(.*?)mainContent',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
				ZylHkumQ8zD0 = pvOytL0nF7JY6flXTxAcHbQeNahu3(ZylHkumQ8zD0)
				HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2.strip(CXtugbqhV3)
				title = HH8SJuswDBPtniebmkXIr(title)
				if '/series/' in ZylHkumQ8zD0 and type=='season': TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,806,HRlygv7YwjzbSLt8fkEerq2,'season')
				elif '/series/' in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,806,HRlygv7YwjzbSLt8fkEerq2)
				elif '/seasons/' in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,801,HRlygv7YwjzbSLt8fkEerq2,'season')
				elif '/collections' in url: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,801,HRlygv7YwjzbSLt8fkEerq2,'collections')
				else: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,803,HRlygv7YwjzbSLt8fkEerq2)
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('loadMoreParams = (.*?);',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			gtlFezGU5H1dKi8k = BwGPDSQOlfUas2n3eIH0ycFRWZ('dict',WWU7QJP2tyTRLIfDh0csxbkvX)
			ssb3JvMHKk8C0O = gtlFezGU5H1dKi8k['ajaxurl']
			D7XvWdzLEB2SNCb5eHuPx41G3Qs9o = int(gtlFezGU5H1dKi8k['current_page'])+1
			JRWbZjTNYq8wVxH1y6eg4DM = int(gtlFezGU5H1dKi8k['max_page'])
			JksvX3VR4d5WOBnwQbI2eShl = gtlFezGU5H1dKi8k['posts'].replace('False','false').replace('True','true').replace('None','null')
			if D7XvWdzLEB2SNCb5eHuPx41G3Qs9o<JRWbZjTNYq8wVxH1y6eg4DM:
				rA4ZGoQyIHlneVfzNukWd = 'action=loadmore&query='+kGE6zoKSan54W(JksvX3VR4d5WOBnwQbI2eShl,nA5dhMRg6ENzsB0l1GwvH7aIr2)+'&page='+str(D7XvWdzLEB2SNCb5eHuPx41G3Qs9o)
				KteRnFMjHpBPqNf8 = ssb3JvMHKk8C0O+'?next=page&'+rA4ZGoQyIHlneVfzNukWd
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'جلب المزيد',KteRnFMjHpBPqNf8,801,nA5dhMRg6ENzsB0l1GwvH7aIr2,'pagination_'+type)
		elif '?next=page&' in url:
			rA4ZGoQyIHlneVfzNukWd,QQGubA8tRnHSPaXLKod4zMEFpjfcl = rA4ZGoQyIHlneVfzNukWd.rsplit('=',1)
			QQGubA8tRnHSPaXLKod4zMEFpjfcl = int(QQGubA8tRnHSPaXLKod4zMEFpjfcl)+1
			KteRnFMjHpBPqNf8 = kHgE2dbiQNuP+'?next=page&'+rA4ZGoQyIHlneVfzNukWd+'='+str(QQGubA8tRnHSPaXLKod4zMEFpjfcl)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'جلب المزيد',KteRnFMjHpBPqNf8,801,nA5dhMRg6ENzsB0l1GwvH7aIr2,'pagination_'+type)
	return
def rYAf8NzmSqsLXgpKMVUCIHtjZ1JucD(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBEST4-FILTERS-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('sub_nav(.*?)secContent ',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q = PAztbuyYo4Kvd.findall('"current_opt">(.*?)<(.*?)</div>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for name,WWU7QJP2tyTRLIfDh0csxbkvX in Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q:
			if 'التصنيف' in name: continue
			name = name.strip(hSXlxL9iB05c)
			items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,value in items:
				title = name+':  '+value
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,801,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filter')
	return
def lNBcUr8RCn(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(yy6RomT9bQhJf,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'EGYBEST4-PLAY-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	nR3YVtZDPs1IpAC = PAztbuyYo4Kvd.findall('<td>التصنيف</td>.*?">(.*?)<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if nR3YVtZDPs1IpAC and g4gUOtGiVkoNuaBrHhx8L(wgj0rX5tbcxPulhmny,url,nR3YVtZDPs1IpAC): return
	HtT6mBGwMaq1o0rybzZ4,Co7gJfiXOmlN4VrbjhuknEH = [],[]
	ZylHkumQ8zD0 = PAztbuyYo4Kvd.findall('postEmbed.*?src="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if ZylHkumQ8zD0:
		ZylHkumQ8zD0 = ZylHkumQ8zD0[0].replace(CXtugbqhV3,nA5dhMRg6ENzsB0l1GwvH7aIr2)
		Co7gJfiXOmlN4VrbjhuknEH.append(ZylHkumQ8zD0)
		DQ7XgFltujVL = C2gnJ5tXFk9pAL(ZylHkumQ8zD0,'name')
		HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0+'?named='+DQ7XgFltujVL+'__embed')
	pvjHgSlOhtLYaZXinCJTy5 = PAztbuyYo4Kvd.findall('vo_theme_dir.*?"(.*?)".*?"(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if pvjHgSlOhtLYaZXinCJTy5:
		ssb3JvMHKk8C0O,FPAhgMwOp1YSLN = pvjHgSlOhtLYaZXinCJTy5[0]
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('postPlayer(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			ne6z1JudcGlW07BD9Hgw3irs = PAztbuyYo4Kvd.findall('<li.*?id\,(.*?)\);">(.*?)</li>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for SQdbRxCUuwzmlgP62H,name in ne6z1JudcGlW07BD9Hgw3irs:
				ZylHkumQ8zD0 = ssb3JvMHKk8C0O+'/temp/ajax/iframe.php?id='+FPAhgMwOp1YSLN+'&video='+SQdbRxCUuwzmlgP62H
				HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0+'?named='+name+'__watch')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('pageContentDown(.*?)</table>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('<tr>.*?<td>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</td>.*?href="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for OzWg1yEQG8wtvJ4x2ic9aKedFAPD,ZylHkumQ8zD0 in items:
			if ZylHkumQ8zD0 not in Co7gJfiXOmlN4VrbjhuknEH:
				if '/?url=' in ZylHkumQ8zD0: ZylHkumQ8zD0 = ZylHkumQ8zD0.split('/?url=')[1]
				Co7gJfiXOmlN4VrbjhuknEH.append(ZylHkumQ8zD0)
				DQ7XgFltujVL = C2gnJ5tXFk9pAL(ZylHkumQ8zD0,'name')
				HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0+'?named='+DQ7XgFltujVL+'__download____'+OzWg1yEQG8wtvJ4x2ic9aKedFAPD)
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(HtT6mBGwMaq1o0rybzZ4,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if not search: search = FaUBpzTGxtS7hZyl()
	if not search: return
	SEGtTsCyUVi0lo4LJkH5 = search.replace(hSXlxL9iB05c,'+')
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/?s='+SEGtTsCyUVi0lo4LJkH5
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,'search')
	return
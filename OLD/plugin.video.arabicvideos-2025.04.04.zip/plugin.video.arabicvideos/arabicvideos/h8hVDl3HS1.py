# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'IFILM'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_IFL_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
Ega71ZGOcjfw = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][1]
XXtMiQq2Ij3OhzRnWT = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][2]
lWkNJQoMgC6 = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][3]
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,Q0f7ytucSriRw8HTzd,text):
	if   mode==20: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = veF3swAlYiQ18fdCP2()
	elif mode==21: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC(url)
	elif mode==22: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,Q0f7ytucSriRw8HTzd)
	elif mode==23: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LLabVp7hzj28CE0f1udx(url,Q0f7ytucSriRw8HTzd)
	elif mode==24: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url,text)
	elif mode==25: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = hnjlaUNPtYmsVOiI8(url)
	elif mode==27: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = g3Vrp8uHOcdnY7t(url)
	elif mode==28: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ugWDKyNzvCbiBMk1s()
	elif mode==29: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def veF3swAlYiQ18fdCP2():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'عربي',GiqvpBF9xLEdHDr37byJSngeCQ,21,nA5dhMRg6ENzsB0l1GwvH7aIr2,'101')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'English',Ega71ZGOcjfw,21,nA5dhMRg6ENzsB0l1GwvH7aIr2,'101')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فارسى',XXtMiQq2Ij3OhzRnWT,21,nA5dhMRg6ENzsB0l1GwvH7aIr2,'101')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فارسى 2',lWkNJQoMgC6,21,nA5dhMRg6ENzsB0l1GwvH7aIr2,'101')
	return
def ugWDKyNzvCbiBMk1s():
	TBt8bUDo9WhL('live',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'عربي',GiqvpBF9xLEdHDr37byJSngeCQ,27)
	TBt8bUDo9WhL('live',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'English',Ega71ZGOcjfw,27)
	TBt8bUDo9WhL('live',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فارسى',XXtMiQq2Ij3OhzRnWT,27)
	TBt8bUDo9WhL('live',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'فارسى 2',lWkNJQoMgC6,27)
	return
def ErjIn5GfaBzkqycC(kqZQfoVgAH8DY):
	wgj0rX5tbcxPulhmny = kqZQfoVgAH8DY
	if kqZQfoVgAH8DY=='IFILM-ARABIC': kqZQfoVgAH8DY = GiqvpBF9xLEdHDr37byJSngeCQ
	elif kqZQfoVgAH8DY=='IFILM-ENGLISH': kqZQfoVgAH8DY = Ega71ZGOcjfw
	else: wgj0rX5tbcxPulhmny = nA5dhMRg6ENzsB0l1GwvH7aIr2
	VshXJcSOFngPKYQIC47a = aZO05AwrXo4uUdDPn(kqZQfoVgAH8DY)
	if VshXJcSOFngPKYQIC47a=='ar' or wgj0rX5tbcxPulhmny=='IFILM-ARABIC':
		L6bnKPUmTrQXf5VlZO = 'بحث في الموقع'
		CSziwD3bp1c9GWLakAB = 'مسلسلات - حالية'
		gO2PcxfG7Yhd = 'مسلسلات - أحدث'
		dKbZ5BoNe0FLfmMlYyDSwCEQ1kX4AG = 'مسلسلات - أبجدي'
		SMobBcLJxP1uCg = 'بث حي آي فيلم'
		nCUQ20wXrFYfB7ko9 = 'أفلام'
		MF0dzqBY96EUxwjvTRNfp = 'موسيقى'
		U9IGYdr0ThFfQDLgbCMJqp = 'برامج'
	elif VshXJcSOFngPKYQIC47a=='en' or wgj0rX5tbcxPulhmny=='IFILM-ENGLISH':
		L6bnKPUmTrQXf5VlZO = 'Search in site'
		CSziwD3bp1c9GWLakAB = 'Series - Current'
		gO2PcxfG7Yhd = 'Series - Latest'
		dKbZ5BoNe0FLfmMlYyDSwCEQ1kX4AG = 'Series - Alphabet'
		SMobBcLJxP1uCg = 'Live iFilm channel'
		nCUQ20wXrFYfB7ko9 = 'Movies'
		MF0dzqBY96EUxwjvTRNfp = 'Music'
		U9IGYdr0ThFfQDLgbCMJqp = 'Shows'
	elif VshXJcSOFngPKYQIC47a in ['fa','fa2']:
		L6bnKPUmTrQXf5VlZO = 'جستجو در سایت'
		CSziwD3bp1c9GWLakAB = 'سريال - جاری'
		gO2PcxfG7Yhd = 'سريال - آخرین'
		dKbZ5BoNe0FLfmMlYyDSwCEQ1kX4AG = 'سريال - الفبا'
		SMobBcLJxP1uCg = 'پخش زنده اي فيلم'
		nCUQ20wXrFYfB7ko9 = 'فيلم'
		MF0dzqBY96EUxwjvTRNfp = 'موسيقى'
		U9IGYdr0ThFfQDLgbCMJqp = 'برنامه ها'
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+L6bnKPUmTrQXf5VlZO,kqZQfoVgAH8DY,29,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('live',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+SMobBcLJxP1uCg,kqZQfoVgAH8DY,27)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	K3WkBTmPE0Yynt5baRhA2ILHsOZwC9 = ['Series','Program','Music']
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,kqZQfoVgAH8DY+'/home',nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'IFILM-MENU-1st')
	zz3eHskxE6lAyDR5cNj1ug=PAztbuyYo4Kvd.findall('button-menu(.*?)/Contact',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			if any(value in ZylHkumQ8zD0 for value in K3WkBTmPE0Yynt5baRhA2ILHsOZwC9):
				url = kqZQfoVgAH8DY+ZylHkumQ8zD0
				if 'Series' in ZylHkumQ8zD0:
					TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+CSziwD3bp1c9GWLakAB,url,22,nA5dhMRg6ENzsB0l1GwvH7aIr2,'100')
					TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+gO2PcxfG7Yhd,url,22,nA5dhMRg6ENzsB0l1GwvH7aIr2,'101')
					TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+dKbZ5BoNe0FLfmMlYyDSwCEQ1kX4AG,url,22,nA5dhMRg6ENzsB0l1GwvH7aIr2,'201')
				elif 'Film' in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+nCUQ20wXrFYfB7ko9,url,22,nA5dhMRg6ENzsB0l1GwvH7aIr2,'100')
				elif 'Music' in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+MF0dzqBY96EUxwjvTRNfp,url,25,nA5dhMRg6ENzsB0l1GwvH7aIr2,'101')
				elif 'Program' in ZylHkumQ8zD0: TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+U9IGYdr0ThFfQDLgbCMJqp,url,22,nA5dhMRg6ENzsB0l1GwvH7aIr2,'101')
	return kl2ZWdy8rXcHT
def hnjlaUNPtYmsVOiI8(url):
	kqZQfoVgAH8DY = jxWTqZk2M91fLpCtK(url)
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'IFILM-MUSIC_MENU-1st')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('Music-tools-header(.*?)Music-body',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	title = PAztbuyYo4Kvd.findall('<p>(.*?)</p>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)[0]
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,22,nA5dhMRg6ENzsB0l1GwvH7aIr2,'101')
	items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title in items:
		ZylHkumQ8zD0 = kqZQfoVgAH8DY + ZylHkumQ8zD0
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,23,nA5dhMRg6ENzsB0l1GwvH7aIr2,'101')
	return
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,Q0f7ytucSriRw8HTzd):
	kqZQfoVgAH8DY = jxWTqZk2M91fLpCtK(url)
	VshXJcSOFngPKYQIC47a = aZO05AwrXo4uUdDPn(url)
	type = url.split('/')[-1]
	Lqey5UCBduTsMxah62b8ogrE = str(int(Q0f7ytucSriRw8HTzd)//100)
	Q0f7ytucSriRw8HTzd = str(int(Q0f7ytucSriRw8HTzd)%100)
	if type=='Series' and Q0f7ytucSriRw8HTzd=='0':
		kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'IFILM-TITLES-1st')
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('serial-body(.*?)class="row',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
			title = jPgzFLH1niJpE2r(title)
			title = HH8SJuswDBPtniebmkXIr(title)
			ZylHkumQ8zD0 = kqZQfoVgAH8DY + ZylHkumQ8zD0
			HRlygv7YwjzbSLt8fkEerq2 = kqZQfoVgAH8DY + kGE6zoKSan54W(HRlygv7YwjzbSLt8fkEerq2)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,23,HRlygv7YwjzbSLt8fkEerq2,Lqey5UCBduTsMxah62b8ogrE+'01')
	HUSvGqye1ZJTEl7Q=0
	if type=='Series': kvfOU7Tpz958QBqnIlaAePLys='3'
	if type=='Film': kvfOU7Tpz958QBqnIlaAePLys='5'
	if type=='Program': kvfOU7Tpz958QBqnIlaAePLys='7'
	if type in ['Series','Program','Film'] and Q0f7ytucSriRw8HTzd!='0':
		KteRnFMjHpBPqNf8 = kqZQfoVgAH8DY+'/Home/PageingItem?category='+kvfOU7Tpz958QBqnIlaAePLys+'&page='+Q0f7ytucSriRw8HTzd+'&size=30&orderby='+Lqey5UCBduTsMxah62b8ogrE
		kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'IFILM-TITLES-2nd')
		items = PAztbuyYo4Kvd.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		for id,title,HRlygv7YwjzbSLt8fkEerq2 in items:
			title = jPgzFLH1niJpE2r(title)
			title = title.replace('\\',nA5dhMRg6ENzsB0l1GwvH7aIr2)
			title = title.replace('"',nA5dhMRg6ENzsB0l1GwvH7aIr2)
			HUSvGqye1ZJTEl7Q += 1
			ZylHkumQ8zD0 = kqZQfoVgAH8DY + '/' + type + '/Content/' + id
			HRlygv7YwjzbSLt8fkEerq2 = kqZQfoVgAH8DY + kGE6zoKSan54W(HRlygv7YwjzbSLt8fkEerq2)
			if type=='Film': TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,24,HRlygv7YwjzbSLt8fkEerq2,Lqey5UCBduTsMxah62b8ogrE+'01')
			else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,23,HRlygv7YwjzbSLt8fkEerq2,Lqey5UCBduTsMxah62b8ogrE+'01')
	if type=='Music':
		kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,kqZQfoVgAH8DY+'/Music/Index?page='+Q0f7ytucSriRw8HTzd,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'IFILM-TITLES-3rd')
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('pagination-demo(.*?)pagination-demo',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
			HUSvGqye1ZJTEl7Q += 1
			HRlygv7YwjzbSLt8fkEerq2 = kqZQfoVgAH8DY + HRlygv7YwjzbSLt8fkEerq2
			ZylHkumQ8zD0 = kqZQfoVgAH8DY + ZylHkumQ8zD0
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,23,HRlygv7YwjzbSLt8fkEerq2,'101')
	if HUSvGqye1ZJTEl7Q>20:
		title='صفحة '
		if VshXJcSOFngPKYQIC47a=='en': title = 'Page '
		if VshXJcSOFngPKYQIC47a=='fa': title = 'صفحه '
		if VshXJcSOFngPKYQIC47a=='fa2': title = 'صفحه '
		for Ah7eyRqVoNbZrLCSYG3 in range(1,11) :
			if not Q0f7ytucSriRw8HTzd==str(Ah7eyRqVoNbZrLCSYG3):
				BIr0LuDkdRSQPH3NWGb8sEq = '0'+str(Ah7eyRqVoNbZrLCSYG3)
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title+str(Ah7eyRqVoNbZrLCSYG3),url,22,nA5dhMRg6ENzsB0l1GwvH7aIr2,Lqey5UCBduTsMxah62b8ogrE+BIr0LuDkdRSQPH3NWGb8sEq[-2:])
	return
def LLabVp7hzj28CE0f1udx(url,Q0f7ytucSriRw8HTzd):
	if not Q0f7ytucSriRw8HTzd: Q0f7ytucSriRw8HTzd = 0
	kqZQfoVgAH8DY = jxWTqZk2M91fLpCtK(url)
	PkjMuW8x1oqTS02 = jxWTqZk2M91fLpCtK(url)
	VshXJcSOFngPKYQIC47a = aZO05AwrXo4uUdDPn(url)
	yoGhEciOC1 = url.split('/')
	id,type = yoGhEciOC1[-1],yoGhEciOC1[3]
	Lqey5UCBduTsMxah62b8ogrE = str(int(Q0f7ytucSriRw8HTzd)//100)
	Q0f7ytucSriRw8HTzd = str(int(Q0f7ytucSriRw8HTzd)%100)
	HUSvGqye1ZJTEl7Q = 0
	if type=='Series':
		kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'IFILM-EPISODES-1st')
		items = PAztbuyYo4Kvd.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		title = ' - الحلقة '
		if VshXJcSOFngPKYQIC47a=='en': title = ' - Episode '
		if VshXJcSOFngPKYQIC47a=='fa': title = ' - قسمت '
		if VshXJcSOFngPKYQIC47a=='fa2': title = ' - قسمت '
		if VshXJcSOFngPKYQIC47a=='fa': wwYvNIuSmJMcWB9KxUlfR = nA5dhMRg6ENzsB0l1GwvH7aIr2
		else: wwYvNIuSmJMcWB9KxUlfR = VshXJcSOFngPKYQIC47a
		oskpzAI0yVKc81X = PAztbuyYo4Kvd.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		for name,count,HRlygv7YwjzbSLt8fkEerq2,ZylHkumQ8zD0 in items:
			for JfNHOP2BK1Yxl7Rq4 in range(int(count),0,-1):
				YY07fmUcdkwDKbMCIP5snSo1z = HRlygv7YwjzbSLt8fkEerq2 + wwYvNIuSmJMcWB9KxUlfR + id + '/' + str(JfNHOP2BK1Yxl7Rq4) + '.png'
				CSziwD3bp1c9GWLakAB = name + title + str(JfNHOP2BK1Yxl7Rq4)
				CSziwD3bp1c9GWLakAB = HH8SJuswDBPtniebmkXIr(CSziwD3bp1c9GWLakAB)
				TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+CSziwD3bp1c9GWLakAB,url,24,YY07fmUcdkwDKbMCIP5snSo1z,nA5dhMRg6ENzsB0l1GwvH7aIr2,str(JfNHOP2BK1Yxl7Rq4))
	elif type=='Program':
		KteRnFMjHpBPqNf8 = kqZQfoVgAH8DY+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+Q0f7ytucSriRw8HTzd+'&size=30&orderby=1'
		kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'IFILM-EPISODES-2nd')
		items = PAztbuyYo4Kvd.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		title = ' - الحلقة '
		if VshXJcSOFngPKYQIC47a=='en': title = ' - Episode '
		if VshXJcSOFngPKYQIC47a=='fa': title = ' - قسمت '
		if VshXJcSOFngPKYQIC47a=='fa2': title = ' - قسمت '
		for JfNHOP2BK1Yxl7Rq4,HRlygv7YwjzbSLt8fkEerq2,ZylHkumQ8zD0,CYMscgtiTIEwhvf714FjoSN,name in items:
			HUSvGqye1ZJTEl7Q += 1
			YY07fmUcdkwDKbMCIP5snSo1z = PkjMuW8x1oqTS02 + kGE6zoKSan54W(HRlygv7YwjzbSLt8fkEerq2)
			name = jPgzFLH1niJpE2r(name)
			CSziwD3bp1c9GWLakAB = name + title + str(JfNHOP2BK1Yxl7Rq4)
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+CSziwD3bp1c9GWLakAB,KteRnFMjHpBPqNf8,24,YY07fmUcdkwDKbMCIP5snSo1z,nA5dhMRg6ENzsB0l1GwvH7aIr2,str(HUSvGqye1ZJTEl7Q))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			KteRnFMjHpBPqNf8 = kqZQfoVgAH8DY+'/Music/GetTracksBy?id='+str(id)+'&page='+Q0f7ytucSriRw8HTzd+'&size=30&type=0'
			kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'IFILM-EPISODES-3rd')
			items = PAztbuyYo4Kvd.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
			for HRlygv7YwjzbSLt8fkEerq2,ZylHkumQ8zD0,name,title in items:
				HUSvGqye1ZJTEl7Q += 1
				YY07fmUcdkwDKbMCIP5snSo1z = PkjMuW8x1oqTS02 + kGE6zoKSan54W(HRlygv7YwjzbSLt8fkEerq2)
				CSziwD3bp1c9GWLakAB = name + ' - ' + title
				CSziwD3bp1c9GWLakAB = CSziwD3bp1c9GWLakAB.strip(hSXlxL9iB05c)
				CSziwD3bp1c9GWLakAB = jPgzFLH1niJpE2r(CSziwD3bp1c9GWLakAB)
				TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+CSziwD3bp1c9GWLakAB,KteRnFMjHpBPqNf8,24,YY07fmUcdkwDKbMCIP5snSo1z,nA5dhMRg6ENzsB0l1GwvH7aIr2,str(HUSvGqye1ZJTEl7Q))
		elif 'Clips' in url:
			KteRnFMjHpBPqNf8 = kqZQfoVgAH8DY+'/Music/GetTracksBy?id=0&page='+Q0f7ytucSriRw8HTzd+'&size=30&type=15'
			kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'IFILM-EPISODES-4th')
			items = PAztbuyYo4Kvd.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
			for HRlygv7YwjzbSLt8fkEerq2,title,ZylHkumQ8zD0 in items:
				HUSvGqye1ZJTEl7Q += 1
				YY07fmUcdkwDKbMCIP5snSo1z = PkjMuW8x1oqTS02 + kGE6zoKSan54W(HRlygv7YwjzbSLt8fkEerq2)
				CSziwD3bp1c9GWLakAB = title.strip(hSXlxL9iB05c)
				CSziwD3bp1c9GWLakAB = jPgzFLH1niJpE2r(CSziwD3bp1c9GWLakAB)
				TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+CSziwD3bp1c9GWLakAB,KteRnFMjHpBPqNf8,24,YY07fmUcdkwDKbMCIP5snSo1z,nA5dhMRg6ENzsB0l1GwvH7aIr2,str(HUSvGqye1ZJTEl7Q))
		elif 'category' in url:
			if 'category=6' in url:
				KteRnFMjHpBPqNf8 = kqZQfoVgAH8DY+'/Music/GetTracksBy?id=0&page='+Q0f7ytucSriRw8HTzd+'&size=30&type=6'
				kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'IFILM-EPISODES-5th')
			elif 'category=4' in url:
				KteRnFMjHpBPqNf8 = kqZQfoVgAH8DY+'/Music/GetTracksBy?id=0&page='+Q0f7ytucSriRw8HTzd+'&size=30&type=4'
				kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'IFILM-EPISODES-6th')
			items = PAztbuyYo4Kvd.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
			for HRlygv7YwjzbSLt8fkEerq2,ZylHkumQ8zD0,name,title in items:
				HUSvGqye1ZJTEl7Q += 1
				YY07fmUcdkwDKbMCIP5snSo1z = PkjMuW8x1oqTS02 + kGE6zoKSan54W(HRlygv7YwjzbSLt8fkEerq2)
				CSziwD3bp1c9GWLakAB = name + ' - ' + title
				CSziwD3bp1c9GWLakAB = CSziwD3bp1c9GWLakAB.strip(hSXlxL9iB05c)
				CSziwD3bp1c9GWLakAB = jPgzFLH1niJpE2r(CSziwD3bp1c9GWLakAB)
				TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+CSziwD3bp1c9GWLakAB,KteRnFMjHpBPqNf8,24,YY07fmUcdkwDKbMCIP5snSo1z,nA5dhMRg6ENzsB0l1GwvH7aIr2,str(HUSvGqye1ZJTEl7Q))
	if type=='Music' or type=='Program':
		if HUSvGqye1ZJTEl7Q>25:
			title='صفحة '
			if VshXJcSOFngPKYQIC47a=='en': title = ' Page '
			if VshXJcSOFngPKYQIC47a=='fa': title = ' صفحه '
			if VshXJcSOFngPKYQIC47a=='fa2': title = ' صفحه '
			for Ah7eyRqVoNbZrLCSYG3 in range(1,11):
				if not Q0f7ytucSriRw8HTzd==str(Ah7eyRqVoNbZrLCSYG3):
					BIr0LuDkdRSQPH3NWGb8sEq = '0'+str(Ah7eyRqVoNbZrLCSYG3)
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title+str(Ah7eyRqVoNbZrLCSYG3),url,23,nA5dhMRg6ENzsB0l1GwvH7aIr2,Lqey5UCBduTsMxah62b8ogrE+BIr0LuDkdRSQPH3NWGb8sEq[-2:])
	return
def lNBcUr8RCn(url,JfNHOP2BK1Yxl7Rq4):
	PkjMuW8x1oqTS02 = jxWTqZk2M91fLpCtK(url)
	ecU4Hy7lNS,ce9zAaVFswSq6lLr82DfQyotGW = [],[]
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'IFILM-PLAY-1st')
	items = PAztbuyYo4Kvd.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if items:
		VshXJcSOFngPKYQIC47a = aZO05AwrXo4uUdDPn(url)
		yoGhEciOC1 = url.split('/')
		id,type = yoGhEciOC1[-1],yoGhEciOC1[3]
		ZylHkumQ8zD0 = items[0][0]+VshXJcSOFngPKYQIC47a+id+'/,'+JfNHOP2BK1Yxl7Rq4+','+JfNHOP2BK1Yxl7Rq4+'_'+items[0][2]
		ecU4Hy7lNS.append('m3u8')
		ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	items = PAztbuyYo4Kvd.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if items:
		VshXJcSOFngPKYQIC47a = aZO05AwrXo4uUdDPn(url)
		yoGhEciOC1 = url.split('/')
		id,type = yoGhEciOC1[-1],yoGhEciOC1[3]
		ZylHkumQ8zD0 = items[0][0]+VshXJcSOFngPKYQIC47a+id+'/'+JfNHOP2BK1Yxl7Rq4+items[0][2]
		ecU4Hy7lNS.append('mp4 url')
		ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	items = PAztbuyYo4Kvd.findall('source src="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0 in items:
		ZylHkumQ8zD0 = ZylHkumQ8zD0.replace('//','/')
		ecU4Hy7lNS.append('mp4 src')
		ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	items = PAztbuyYo4Kvd.findall('VideoAddress":"(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if items:
		ZylHkumQ8zD0 = items[int(JfNHOP2BK1Yxl7Rq4)-1]
		ZylHkumQ8zD0 = PkjMuW8x1oqTS02+kGE6zoKSan54W(ZylHkumQ8zD0)
		ecU4Hy7lNS.append('mp4 address')
		ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	items = PAztbuyYo4Kvd.findall('VoiceAddress":"(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if items:
		ZylHkumQ8zD0 = items[int(JfNHOP2BK1Yxl7Rq4)-1]
		ZylHkumQ8zD0 = PkjMuW8x1oqTS02+kGE6zoKSan54W(ZylHkumQ8zD0)
		ecU4Hy7lNS.append('mp3 address')
		ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	if len(ce9zAaVFswSq6lLr82DfQyotGW)==1: ZylHkumQ8zD0 = ce9zAaVFswSq6lLr82DfQyotGW[0]
	else:
		iP7AUR41exzlKyZIf9Mt3u = ccAMwn7hflDev8Kd3aqP('اختر الفيديو المناسب:', ecU4Hy7lNS)
		if iP7AUR41exzlKyZIf9Mt3u == -1 : return
		ZylHkumQ8zD0 = ce9zAaVFswSq6lLr82DfQyotGW[iP7AUR41exzlKyZIf9Mt3u]
	ocUnzjShqIO35vZi8bk64pVKMCTBaw(ZylHkumQ8zD0,wgj0rX5tbcxPulhmny,'video')
	return
def jxWTqZk2M91fLpCtK(url):
	if GiqvpBF9xLEdHDr37byJSngeCQ in url: whXU4NCbPdFAcxErVJIutR8WDM3n = GiqvpBF9xLEdHDr37byJSngeCQ
	elif Ega71ZGOcjfw in url: whXU4NCbPdFAcxErVJIutR8WDM3n = Ega71ZGOcjfw
	elif XXtMiQq2Ij3OhzRnWT in url: whXU4NCbPdFAcxErVJIutR8WDM3n = XXtMiQq2Ij3OhzRnWT
	elif lWkNJQoMgC6 in url: whXU4NCbPdFAcxErVJIutR8WDM3n = lWkNJQoMgC6
	else: whXU4NCbPdFAcxErVJIutR8WDM3n = nA5dhMRg6ENzsB0l1GwvH7aIr2
	return whXU4NCbPdFAcxErVJIutR8WDM3n
def aZO05AwrXo4uUdDPn(url):
	if   GiqvpBF9xLEdHDr37byJSngeCQ in url: VshXJcSOFngPKYQIC47a = 'ar'
	elif Ega71ZGOcjfw in url: VshXJcSOFngPKYQIC47a = 'en'
	elif XXtMiQq2Ij3OhzRnWT in url: VshXJcSOFngPKYQIC47a = 'fa'
	elif lWkNJQoMgC6 in url: VshXJcSOFngPKYQIC47a = 'fa2'
	else: VshXJcSOFngPKYQIC47a = nA5dhMRg6ENzsB0l1GwvH7aIr2
	return VshXJcSOFngPKYQIC47a
def g3Vrp8uHOcdnY7t(url):
	VshXJcSOFngPKYQIC47a = aZO05AwrXo4uUdDPn(url)
	KteRnFMjHpBPqNf8 = url + '/Home/Live'
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'IFILM-LIVE-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	items = PAztbuyYo4Kvd.findall('source src="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	w7Ol6FnokgJDSsIt = items[0]
	ocUnzjShqIO35vZi8bk64pVKMCTBaw(w7Ol6FnokgJDSsIt,wgj0rX5tbcxPulhmny,'live')
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if not search:
		search = FaUBpzTGxtS7hZyl()
		if not search: return
	SEGtTsCyUVi0lo4LJkH5 = search.replace(hSXlxL9iB05c,'+')
	if showDialogs:
		xxOQ92YRr8fz5PqvS = [ GiqvpBF9xLEdHDr37byJSngeCQ , Ega71ZGOcjfw , XXtMiQq2Ij3OhzRnWT , lWkNJQoMgC6 ]
		AROQUxpWHVXSZ7Elcvdz5mL1JtFYD = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		iP7AUR41exzlKyZIf9Mt3u = ccAMwn7hflDev8Kd3aqP('اختر اللغة المناسبة:', AROQUxpWHVXSZ7Elcvdz5mL1JtFYD)
		if iP7AUR41exzlKyZIf9Mt3u == -1 : return
		website = xxOQ92YRr8fz5PqvS[iP7AUR41exzlKyZIf9Mt3u]
	else:
		if '_IFILM-ARABIC_' in m0YJ3feqUjD7: website = GiqvpBF9xLEdHDr37byJSngeCQ
		elif '_IFILM-ENGLISH_' in m0YJ3feqUjD7: website = Ega71ZGOcjfw
		else: website = nA5dhMRg6ENzsB0l1GwvH7aIr2
	if not website: return
	VshXJcSOFngPKYQIC47a = aZO05AwrXo4uUdDPn(website)
	KteRnFMjHpBPqNf8 = website + "/Home/Search?searchstring=" + SEGtTsCyUVi0lo4LJkH5
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'IFILM-SEARCH-1st')
	items = PAztbuyYo4Kvd.findall('"ImageAddress_S":"(.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if items:
		for HRlygv7YwjzbSLt8fkEerq2,kvfOU7Tpz958QBqnIlaAePLys,id,title in items:
			if kvfOU7Tpz958QBqnIlaAePLys in ['3','7']:
				title = title.replace('\\',nA5dhMRg6ENzsB0l1GwvH7aIr2)
				title = title.replace('"',nA5dhMRg6ENzsB0l1GwvH7aIr2)
				if kvfOU7Tpz958QBqnIlaAePLys=='3':
					type = 'Series'
					if VshXJcSOFngPKYQIC47a=='ar': name = 'مسلسل : '
					elif VshXJcSOFngPKYQIC47a=='en': name = 'Series : '
					elif VshXJcSOFngPKYQIC47a=='fa': name = 'سريال ها : '
					elif VshXJcSOFngPKYQIC47a=='fa2': name = 'سريال ها : '
				elif kvfOU7Tpz958QBqnIlaAePLys=='5':
					type = 'Film'
					if VshXJcSOFngPKYQIC47a=='ar': name = 'فيلم : '
					elif VshXJcSOFngPKYQIC47a=='en': name = 'Movie : '
					elif VshXJcSOFngPKYQIC47a=='fa': name = 'فيلم : '
					elif VshXJcSOFngPKYQIC47a=='fa2': name = 'فلم ها : '
				elif kvfOU7Tpz958QBqnIlaAePLys=='7':
					type = 'Program'
					if VshXJcSOFngPKYQIC47a=='ar': name = 'برنامج : '
					elif VshXJcSOFngPKYQIC47a=='en': name = 'Program : '
					elif VshXJcSOFngPKYQIC47a=='fa': name = 'برنامه ها : '
					elif VshXJcSOFngPKYQIC47a=='fa2': name = 'برنامه ها : '
				title = name + title
				ZylHkumQ8zD0 = website + '/' + type + '/Content/' + id
				HRlygv7YwjzbSLt8fkEerq2 = kGE6zoKSan54W(HRlygv7YwjzbSLt8fkEerq2)
				HRlygv7YwjzbSLt8fkEerq2 = website+HRlygv7YwjzbSLt8fkEerq2
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,23,HRlygv7YwjzbSLt8fkEerq2,'101')
	return
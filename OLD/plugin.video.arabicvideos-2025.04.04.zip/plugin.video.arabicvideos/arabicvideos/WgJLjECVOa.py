# -*- coding: utf-8 -*-
import sys as kCNHMOym1luTnJ0
MigYEN1cxduFB2lpk5 = kCNHMOym1luTnJ0.version_info [0] == 2
xJ3XdNcV5IujAkoGh = 2048
aE71QiuHI95zfPRBUsntedWZJ2bl = 7
def vR1b8iCLa9Qy2Sw5OYAlWXNhZp37 (AGxE4RIvuC6):
	global peWEVn47JRXo916j
	Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky = ord (AGxE4RIvuC6 [-1])
	FXUjnSw308z = AGxE4RIvuC6 [:-1]
	f81LoVwXMpQkvdKcmPyj6NzBlt = Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky % len (FXUjnSw308z)
	qyKv5nBTxgkQSlJ0aNP1CUmpjYLZ = FXUjnSw308z [:f81LoVwXMpQkvdKcmPyj6NzBlt] + FXUjnSw308z [f81LoVwXMpQkvdKcmPyj6NzBlt:]
	if MigYEN1cxduFB2lpk5:
		H0yFJ5LDCGYpIM1BViZKTSgv3jXr = unicode () .join ([unichr (ord (Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286) - xJ3XdNcV5IujAkoGh - (MfwWyztdYVXURgPqLrITku3CxF1 + Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky) % aE71QiuHI95zfPRBUsntedWZJ2bl) for MfwWyztdYVXURgPqLrITku3CxF1, Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286 in enumerate (qyKv5nBTxgkQSlJ0aNP1CUmpjYLZ)])
	else:
		H0yFJ5LDCGYpIM1BViZKTSgv3jXr = str () .join ([chr (ord (Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286) - xJ3XdNcV5IujAkoGh - (MfwWyztdYVXURgPqLrITku3CxF1 + Gn3cNgKi8fAwV2ZbaCqsj4BOrhYtky) % aE71QiuHI95zfPRBUsntedWZJ2bl) for MfwWyztdYVXURgPqLrITku3CxF1, Nvz9l1pZ7VgdcFKqCx4kXeDTjtS286 in enumerate (qyKv5nBTxgkQSlJ0aNP1CUmpjYLZ)])
	return eval (H0yFJ5LDCGYpIM1BViZKTSgv3jXr)
Yj1msqVeivESfrCupRy9b7WacBd,XEcWOIwkZKubV7vQ,Pj9YaUq1ibJ=vR1b8iCLa9Qy2Sw5OYAlWXNhZp37,vR1b8iCLa9Qy2Sw5OYAlWXNhZp37,vR1b8iCLa9Qy2Sw5OYAlWXNhZp37
HD7MQqXd2gS,yPE2t1Co4YQDfsIecdxu0Gklq6AvO,bqCDnV7Bs5XgRvuKLNAa1Uz=Pj9YaUq1ibJ,XEcWOIwkZKubV7vQ,Yj1msqVeivESfrCupRy9b7WacBd
YIsyNBocg6fV3wEWPSu9GtvHxLOqDi,VVstJA9bfOqunLF0oaSgWUKHDdYNz,nfNTgkiWdUq=bqCDnV7Bs5XgRvuKLNAa1Uz,yPE2t1Co4YQDfsIecdxu0Gklq6AvO,HD7MQqXd2gS
FVxoQ2J5Mfv3Zj6sy9uhOS,n8BrpFLyaMAC1vP0bOHgwxEzeGRV,UUobzy0xZLaVScIt7=nfNTgkiWdUq,VVstJA9bfOqunLF0oaSgWUKHDdYNz,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi
JvQd6LMoBX4hiy1C,ZjELJ9VrUT07R8Hn4FuSDcf,pxt6wJ8ScYMWCivoO=UUobzy0xZLaVScIt7,n8BrpFLyaMAC1vP0bOHgwxEzeGRV,FVxoQ2J5Mfv3Zj6sy9uhOS
lw2snZ9J0uhLoxypqa,LJqSQvuhf7aMmnVjy23FbZBckKzx9l,gmPI7hVEM8nD=pxt6wJ8ScYMWCivoO,ZjELJ9VrUT07R8Hn4FuSDcf,JvQd6LMoBX4hiy1C
w0ivtSjV2sZDQoT1OEugIla7R6AC5M,rCmGE4YIDaZA,vzqjsVHSBlMpxC=gmPI7hVEM8nD,LJqSQvuhf7aMmnVjy23FbZBckKzx9l,lw2snZ9J0uhLoxypqa
xwIUQfiE7rmvYzH,ldIfvn6asURQ9toi85EhqAXW3,bb1fgjsAq4N2xYwnoh39lm=vzqjsVHSBlMpxC,rCmGE4YIDaZA,w0ivtSjV2sZDQoT1OEugIla7R6AC5M
AJHaiQq3PRd5cphzGuELnVg9X,jil8vRpBsENVYyPmDd,PPxYugzLZwHX23yiK=bb1fgjsAq4N2xYwnoh39lm,ldIfvn6asURQ9toi85EhqAXW3,xwIUQfiE7rmvYzH
baBcNd81eH5ry2Olp6Mj43,Qy6wlfLoOpg1,mRanX1HZupfSQVB2gsDGUO=PPxYugzLZwHX23yiK,jil8vRpBsENVYyPmDd,AJHaiQq3PRd5cphzGuELnVg9X
bDxWcjmaSgFeRKrfpJvyA4zThi,DFx6E0uON7Jm8,zhE5I4xHinX0UoVZMNwlkPrR=mRanX1HZupfSQVB2gsDGUO,Qy6wlfLoOpg1,baBcNd81eH5ry2Olp6Mj43
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
DjKrTPWEFw2YeCi5d6unBqhZSlAR = FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
U5d4FgmSCzTZGe9wPu37kXaHqo0 = XoZRpFe7B6gnfA.path.join(y9SrAlWpbuYgeEQ,Yj1msqVeivESfrCupRy9b7WacBd(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
LVmeESUHAw2Tr7XPoNOYiWqIbxv6ZG = XoZRpFe7B6gnfA.path.join(y9SrAlWpbuYgeEQ,ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
VPAWJQf10uicMnh2dZCK = XoZRpFe7B6gnfA.path.join(kkjOSvrlpDJNcqVIwUBt3,baBcNd81eH5ry2Olp6Mj43(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),lw2snZ9J0uhLoxypqa(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
dqoIyMV9P1KZB4spkXrReWmlL = bb1fgjsAq4N2xYwnoh39lm(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
B0jShzKWwCdopDvR84Ft6gGcl2XOMx = nfNTgkiWdUq(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
RGtWEB1XDQ0 = bb1fgjsAq4N2xYwnoh39lm(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
rrMtjF6f3LmUu = lw2snZ9J0uhLoxypqa(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
kswWoy93idmRQuchLj6tzHe2bI085 = bb1fgjsAq4N2xYwnoh39lm(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
QrfYaDiq9xX25VeG = JvQd6LMoBX4hiy1C(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
TLeNP9vpcu7gozCIA4UqYOikaSd2Dj = A1CKpbwyFL8jY4I
uuNo4ROjpFtXHbfBzcxrqn5lL = QQwBc24Oza7jJ8ClTRWexUoqGAkg0
pov40VyNdZshR = LLfnMdCSp5uKc3GIzjQ17mk6APNtU2
def YYdDUV01oAtQljRBxO9enrEXHwfC(knBV0UPuCNdpIsAFH3coRKjh2lb):
	if   knBV0UPuCNdpIsAFH3coRKjh2lb==gmPI7hVEM8nD(u"࠹࠷࠴ࣉ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = eRbIgFjyA8u()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠺࠸࠶࣊"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = mJZ2eb9HzawrqRCsU7D6(U5d4FgmSCzTZGe9wPu37kXaHqo0,S5MWhgtZ37Xw,S5MWhgtZ37Xw);A3mrIqtlCoeUWPHVLyfa6MG8buxQ1(V9OGBuyogH0CaUtQS6wWErAbPYDjlM)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==AJHaiQq3PRd5cphzGuELnVg9X(u"࠻࠹࠸࣋"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = mJZ2eb9HzawrqRCsU7D6(LVmeESUHAw2Tr7XPoNOYiWqIbxv6ZG,S5MWhgtZ37Xw,S5MWhgtZ37Xw);A3mrIqtlCoeUWPHVLyfa6MG8buxQ1(V9OGBuyogH0CaUtQS6wWErAbPYDjlM)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠼࠺࠳࣌"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = mJZ2eb9HzawrqRCsU7D6(VPAWJQf10uicMnh2dZCK,FFKncZx5pDTwdiJRYhMgQSNL,S5MWhgtZ37Xw);A3mrIqtlCoeUWPHVLyfa6MG8buxQ1(V9OGBuyogH0CaUtQS6wWErAbPYDjlM)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==mRanX1HZupfSQVB2gsDGUO(u"࠽࠴࠵࣍"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = csnW6ZSXRIQoYmTf(S5MWhgtZ37Xw);A3mrIqtlCoeUWPHVLyfa6MG8buxQ1(V9OGBuyogH0CaUtQS6wWErAbPYDjlM)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==pxt6wJ8ScYMWCivoO(u"࠷࠵࠷࣎"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = gbwIZTGQDPrq(S5MWhgtZ37Xw);A3mrIqtlCoeUWPHVLyfa6MG8buxQ1(V9OGBuyogH0CaUtQS6wWErAbPYDjlM)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==AJHaiQq3PRd5cphzGuELnVg9X(u"࠸࠶࠹࣏"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = cKzyGqPdsW3ADFZJgIV7Et19j25rNb(S5MWhgtZ37Xw);A3mrIqtlCoeUWPHVLyfa6MG8buxQ1(V9OGBuyogH0CaUtQS6wWErAbPYDjlM)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==zhE5I4xHinX0UoVZMNwlkPrR(u"࠹࠸࠴࣐"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = UgmSb9CtivJazVojkE3dx()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==mRanX1HZupfSQVB2gsDGUO(u"࠺࠹࠶࣑"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = mJZ2eb9HzawrqRCsU7D6(dqoIyMV9P1KZB4spkXrReWmlL,FFKncZx5pDTwdiJRYhMgQSNL,S5MWhgtZ37Xw);A3mrIqtlCoeUWPHVLyfa6MG8buxQ1(V9OGBuyogH0CaUtQS6wWErAbPYDjlM)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠻࠺࠸࣒"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = mJZ2eb9HzawrqRCsU7D6(B0jShzKWwCdopDvR84Ft6gGcl2XOMx,FFKncZx5pDTwdiJRYhMgQSNL,S5MWhgtZ37Xw);A3mrIqtlCoeUWPHVLyfa6MG8buxQ1(V9OGBuyogH0CaUtQS6wWErAbPYDjlM)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==UUobzy0xZLaVScIt7(u"࠼࠻࠳࣓"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = mJZ2eb9HzawrqRCsU7D6(RGtWEB1XDQ0,FFKncZx5pDTwdiJRYhMgQSNL,S5MWhgtZ37Xw);A3mrIqtlCoeUWPHVLyfa6MG8buxQ1(V9OGBuyogH0CaUtQS6wWErAbPYDjlM)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==HD7MQqXd2gS(u"࠽࠵࠵ࣔ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = mJZ2eb9HzawrqRCsU7D6(rrMtjF6f3LmUu,FFKncZx5pDTwdiJRYhMgQSNL,S5MWhgtZ37Xw);A3mrIqtlCoeUWPHVLyfa6MG8buxQ1(V9OGBuyogH0CaUtQS6wWErAbPYDjlM)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==jil8vRpBsENVYyPmDd(u"࠷࠶࠷ࣕ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = mJZ2eb9HzawrqRCsU7D6(kswWoy93idmRQuchLj6tzHe2bI085,FFKncZx5pDTwdiJRYhMgQSNL,S5MWhgtZ37Xw);A3mrIqtlCoeUWPHVLyfa6MG8buxQ1(V9OGBuyogH0CaUtQS6wWErAbPYDjlM)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==ZjELJ9VrUT07R8Hn4FuSDcf(u"࠸࠷࠹ࣖ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = mJZ2eb9HzawrqRCsU7D6(QrfYaDiq9xX25VeG,FFKncZx5pDTwdiJRYhMgQSNL,S5MWhgtZ37Xw);A3mrIqtlCoeUWPHVLyfa6MG8buxQ1(V9OGBuyogH0CaUtQS6wWErAbPYDjlM)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠹࠸࠻ࣗ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = UuAGvYCnHoczTKr40R53VPXZQ(S5MWhgtZ37Xw);A3mrIqtlCoeUWPHVLyfa6MG8buxQ1(V9OGBuyogH0CaUtQS6wWErAbPYDjlM)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠺࠹࠽ࣘ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = iL6JnHKDGUv5lC7Q8IsO();A3mrIqtlCoeUWPHVLyfa6MG8buxQ1(V9OGBuyogH0CaUtQS6wWErAbPYDjlM)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠵࠵࠾࠰ࣙ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = DuVqPbzQScUXdf1pTW()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==HD7MQqXd2gS(u"࠶࠶࠸࠲ࣚ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = Ar9fuT3HvtEWglaxMiDJGS5(S5MWhgtZ37Xw);A3mrIqtlCoeUWPHVLyfa6MG8buxQ1(V9OGBuyogH0CaUtQS6wWErAbPYDjlM)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==DFx6E0uON7Jm8(u"࠷࠰࠹࠴ࣛ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = hSknJwYdFoiayDZ();A3mrIqtlCoeUWPHVLyfa6MG8buxQ1(V9OGBuyogH0CaUtQS6wWErAbPYDjlM)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==UUobzy0xZLaVScIt7(u"࠱࠱࠺࠶ࣜ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = MVx75LYvEdCyWpcI();A3mrIqtlCoeUWPHVLyfa6MG8buxQ1(V9OGBuyogH0CaUtQS6wWErAbPYDjlM)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==JvQd6LMoBX4hiy1C(u"࠲࠲࠻࠸ࣝ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ECi1VwvQ3M8HRuYxKrdeDy0();A3mrIqtlCoeUWPHVLyfa6MG8buxQ1(V9OGBuyogH0CaUtQS6wWErAbPYDjlM)
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==gmPI7hVEM8nD(u"࠳࠳࠼࠺ࣞ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif knBV0UPuCNdpIsAFH3coRKjh2lb==YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠴࠴࠽࠼ࣟ"): V9OGBuyogH0CaUtQS6wWErAbPYDjlM = IzUuCqZ72xflerT()
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = FFKncZx5pDTwdiJRYhMgQSNL
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def IzUuCqZ72xflerT():
	yh3NdFJAT5kS9QpM6PwHgx84KIW = Pj9YaUq1ibJ(u"࠵࠵࠸࠴࣠")*Pj9YaUq1ibJ(u"࠵࠵࠸࠴࣠")
	bq31xLIXnS7Kvcmz = uCXFHaxhO8lNMQyTzktcV6DWoe0P()//yh3NdFJAT5kS9QpM6PwHgx84KIW
	C9aUJoOYnH4qK = bq31xLIXnS7Kvcmz<Yj1msqVeivESfrCupRy9b7WacBd(u"࠺࠶࣡")
	size = bbTCMJwEx8nhN4X+PPxYugzLZwHX23yiK(u"ࠩ็ำ๏้ࠠๆีสัฮࠦแศำ฽อࠥࠦࠧࠌ")+str(bq31xLIXnS7Kvcmz)+gmPI7hVEM8nD(u"ࠪࠤ๋๊ࠥอษหห๏ะࠧࠍ")+NwROdSj3nsA
	if C9aUJoOYnH4qK:
		nhR0UxwS4yDiABj7V1G8la(ybrna7mLOFVDUtRseQ3Tkf2zXS,HD7MQqXd2gS(u"ࠫࡈࡎࡅࡄࡍࡢࡈࡎ࡙ࡋࡠࡕࡓࡅࡈࡋࠠࠡࠢࡖࡘࡔࡘࡁࡈࡇࠣࡍࡘࠦࡆࡖࡎࡏࠤࠥࠦࠧࠎ")+str(bq31xLIXnS7Kvcmz)+bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠬࠦࡍࡃࠢࠤࠥࠬࠏ"))
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,Yj1msqVeivESfrCupRy9b7WacBd(u"࠭ๅิษะอࠥอไหะี๎๋ࠦแ๋ࠢฯ๋ฬุใࠡลุฬาะࠠๆ็อ่หฯࠠ࠯࠰ࠣ์์ึวࠡ์ึฬอࠦๅีษๆ่้ࠥห๋ำฬࠤๆ๐ࠠหึ฽๎้ࠦวๅฮ๊หื่ࠦหึ฽๎้ࠦใ้ัํࠤํะิ฻์็ࠤอืๆศ็ฯࠤ฾๋วะࠢ࠱࠲ࠥอๆหࠢหัฬาษࠡว็ํࠥะๆู์ไࠤัํวำๅࠣ์ฯ์ื๋ใࠣ็ํี๊๊ࠡอ๊฽๐แ้ࠡำหࠥอไษำ้ห๊า࡜࡯࡞ࡱࠫࠐ")+size)
	else: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,UUobzy0xZLaVScIt7(u"ࠧๆีสัฮࠦวๅฬัึ๏์ࠠโ์ࠣะ์อาไࠢฯ๎ิฯ࡜࡯࡞ࡱࠫࠑ")+size)
	return C9aUJoOYnH4qK
def A3mrIqtlCoeUWPHVLyfa6MG8buxQ1(fSNgKz476uAQsicDFI):
	if fSNgKz476uAQsicDFI: AA5FS4hUqeP9EsZCM(S5MWhgtZ37Xw)
	return
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL(XEcWOIwkZKubV7vQ(u"ࠨ࡮࡬ࡲࡰ࠭ࠒ"),bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠩไัฺࠦๅิษะอࠥอไหะี๎๋࠭ࠓ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,ZjELJ9VrUT07R8Hn4FuSDcf(u"࠷࠰࠹࠸࣢"))
	TBt8bUDo9WhL(pxt6wJ8ScYMWCivoO(u"ࠪࡪࡴࡲࡤࡦࡴࠪࠔ"),YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠫฯ์ุ๋ใࠣห้า็ศิࠪࠕ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,jil8vRpBsENVYyPmDd(u"࠷࠶࠲ࣣ"))
	TBt8bUDo9WhL(lw2snZ9J0uhLoxypqa(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬࠖ"),nfNTgkiWdUq(u"࠭ส็ฺํๅ้่ࠥะ์ࠪࠗ"),nA5dhMRg6ENzsB0l1GwvH7aIr2,n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"࠸࠶࠳ࣤ"))
	TBt8bUDo9WhL(PPxYugzLZwHX23yiK(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠘"),bDxWcjmaSgFeRKrfpJvyA4zThi(u"ࠨฬ้฼๏็ࠠศๆหี๋อๅอࠩ࠙"),nA5dhMRg6ENzsB0l1GwvH7aIr2,Qy6wlfLoOpg1(u"࠳࠳࠼࠵ࣥ"))
	return
def DuVqPbzQScUXdf1pTW():
	hny96IgYU8GPrb1vXplF0REAQ,tIzJpVo8H4A0 = uuA7BHRfgmOPZnQVtdYzDyFqiE(TLeNP9vpcu7gozCIA4UqYOikaSd2Dj)
	AT97seKDgcuBqlPfFSN452wx8mnoWk,D51wlUTOvEhoNK = uuA7BHRfgmOPZnQVtdYzDyFqiE(uuNo4ROjpFtXHbfBzcxrqn5lL)
	mH0RFAUd3S,rpe3TM9xK7mDJOozLStc = cpNjIxZEUORvTw(pov40VyNdZshR)
	Rchs1vok6tWZGV0,BXphwoMZy4QNIxzgHOUGqPd = hny96IgYU8GPrb1vXplF0REAQ+AT97seKDgcuBqlPfFSN452wx8mnoWk+mH0RFAUd3S,tIzJpVo8H4A0+D51wlUTOvEhoNK+rpe3TM9xK7mDJOozLStc
	gtDwSCe3Z9xfL5zn = mRanX1HZupfSQVB2gsDGUO(u"ࠩࠣࠬࠬࠚ")+dOh1KDo5nqWZ2e8zBRTgjrCF0XV(hny96IgYU8GPrb1vXplF0REAQ)+VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠪࠤ࠲ࠦࠧࠛ")+str(tIzJpVo8H4A0)+xwIUQfiE7rmvYzH(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠜ")
	oyiZl283hIc9BNv = jil8vRpBsENVYyPmDd(u"ࠬࠦࠨࠨࠝ")+dOh1KDo5nqWZ2e8zBRTgjrCF0XV(AT97seKDgcuBqlPfFSN452wx8mnoWk)+Qy6wlfLoOpg1(u"࠭ࠠ࠮ࠢࠪࠞ")+str(D51wlUTOvEhoNK)+Qy6wlfLoOpg1(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠟ")
	k7EHn02TyKNpduB9SRWG5JMx = bb1fgjsAq4N2xYwnoh39lm(u"ࠨࠢࠫࠫࠠ")+dOh1KDo5nqWZ2e8zBRTgjrCF0XV(mH0RFAUd3S)+gmPI7hVEM8nD(u"ࠩࠣ࠱ࠥ࠭ࠡ")+str(rpe3TM9xK7mDJOozLStc)+LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠢ")
	WQCm8UvrpDYB = pxt6wJ8ScYMWCivoO(u"ࠫࠥ࠮ࠧࠣ")+dOh1KDo5nqWZ2e8zBRTgjrCF0XV(Rchs1vok6tWZGV0)+vzqjsVHSBlMpxC(u"ࠬࠦ࠭ࠡࠩࠤ")+str(BXphwoMZy4QNIxzgHOUGqPd)+mRanX1HZupfSQVB2gsDGUO(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࠥ")
	TBt8bUDo9WhL(YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"ࠧ࡭࡫ࡱ࡯ࠬࠦ"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+baBcNd81eH5ry2Olp6Mj43(u"ࠨ็ึัࠥอไอ็ํ฽ࠬࠧ")+WQCm8UvrpDYB,nA5dhMRg6ENzsB0l1GwvH7aIr2,rCmGE4YIDaZA(u"࠴࠴࠽࠺ࣦ"))
	TBt8bUDo9WhL(jil8vRpBsENVYyPmDd(u"ࠩ࡯࡭ࡳࡱࠧࠨ"),bbTCMJwEx8nhN4X+rCmGE4YIDaZA(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩࠩ")+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,bb1fgjsAq4N2xYwnoh39lm(u"࠽࠾࠿࠹ࣧ"))
	TBt8bUDo9WhL(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠫࡱ࡯࡮࡬ࠩࠪ"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+rCmGE4YIDaZA(u"๋ࠬำฮุࠢ์ึࠦวๅๅอหอฯࠧࠫ")+gtDwSCe3Z9xfL5zn,nA5dhMRg6ENzsB0l1GwvH7aIr2,ZjELJ9VrUT07R8Hn4FuSDcf(u"࠶࠶࠸࠲ࣨ"))
	TBt8bUDo9WhL(gmPI7hVEM8nD(u"࠭࡬ࡪࡰ࡮ࠫࠬ"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+zhE5I4xHinX0UoVZMNwlkPrR(u"ࠧๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠪ࠭")+oyiZl283hIc9BNv,nA5dhMRg6ENzsB0l1GwvH7aIr2,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠷࠰࠹࠴ࣩ"))
	TBt8bUDo9WhL(PPxYugzLZwHX23yiK(u"ࠨ࡮࡬ࡲࡰ࠭࠮"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+FVxoQ2J5Mfv3Zj6sy9uhOS(u"่ࠩืาࠦลฺัสำฬะࠠศๆหี๋อๅอࠩ࠯")+k7EHn02TyKNpduB9SRWG5JMx,nA5dhMRg6ENzsB0l1GwvH7aIr2,AJHaiQq3PRd5cphzGuELnVg9X(u"࠱࠱࠺࠶࣪"))
	TBt8bUDo9WhL(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠪࡰ࡮ࡴ࡫ࠨ࠰"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࠫฯ฻แ๋ำࠣห้ฮั็ษ่ะࠬ࠱")+WQCm8UvrpDYB,nA5dhMRg6ENzsB0l1GwvH7aIr2,Yj1msqVeivESfrCupRy9b7WacBd(u"࠲࠲࠻࠸࣫"))
	return
def ECi1VwvQ3M8HRuYxKrdeDy0():
	fSNgKz476uAQsicDFI = FFKncZx5pDTwdiJRYhMgQSNL
	x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠬํไࠡฬิ๎ิࠦแฺๆสࠤู๊อࠡฮ่๎฾ࠦลฺัสำฬะࠠศๆหี๋อๅอࠢ࠱࠲ࠥ๎ๅิฯࠣะ๊๐ูࠡ็็ๅฬะࠠศๆหี๋อๅอࠢส่็ี๊ๆหࠣ࠲࠳ࠦอห๋ࠣ๎฾๎ฯࠡษ็ฬึ์วๆฮࠣษ้๏ࠠฮษ็อࠥอไึใิࠤ࠳࠴๋ࠠ฻้๎ࠥำวๅหࠣ์฻฿๊สูࠢฬ฼ࠦวๅ็ุ๊฾ࠦ࠮࠯ࠢํ฽๋๐ࠠศๆะห้ฯࠠศๆอ๎ࠥ๎ึฺ้สࠤฬ๊ๅษำ่ะ๊ࠥไษำ้ห๊าࠠ࠯࠰๋ࠣีํࠠศๆ฼้้๐ษࠡฬอ้ࠥฮๅิฯ้ࠣั๊ฯࠡๅสุࠥอไษำ้ห๊า้ࠠ็ึั๋ࠥไโࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥลࠡࠨ࠲"))
	if x6zlf2tTZm:
		mmLW380CtxQkwzRc9aGif = MVx75LYvEdCyWpcI()
		EENVJo0sDYtiZO3S = mJZ2eb9HzawrqRCsU7D6(QQwBc24Oza7jJ8ClTRWexUoqGAkg0,S5MWhgtZ37Xw,FFKncZx5pDTwdiJRYhMgQSNL)
		fSNgKz476uAQsicDFI = mmLW380CtxQkwzRc9aGif and EENVJo0sDYtiZO3S
		if fSNgKz476uAQsicDFI: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หุ้ࠣำࠠศๆ่่ๆอสࠡษ็ๆิ๐ๅสࠢ็่อืๆศ็ฯࠤ࠳࠴้ࠠ฻สำࠥอไษำ้ห๊าࠠฦๆ์ࠤํ฼ู๋หࠣห้฻แาࠢ࠱࠲ࠥ๎ึฺ์ฬࠤ฻ฮืࠡษ็ฺ้์ูࠨ࠳"))
		else: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,zhE5I4xHinX0UoVZMNwlkPrR(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦสึใํีࠥอไษำ้ห๊า้ࠠว฼หิะ็ࠡว็ํࠥ๎ึฺ์ฬࠤ฻ฮืࠡษ็ฺ้์ูࠨ࠴"))
	return fSNgKz476uAQsicDFI
def hSknJwYdFoiayDZ():
	import nkKg6CFTbN
	nkKg6CFTbN.V1aNDbJw975()
	zTEXepHg92GkWf = FFKncZx5pDTwdiJRYhMgQSNL
	x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(mRanX1HZupfSQVB2gsDGUO(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ࠵"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"๊่ࠩࠥะั๋ัุ้ࠣำࠠอ็ํ฽ࠥอไไษืࠤฤ࠭࠶"),vzqjsVHSBlMpxC(u"ࠪห้้วีࠢํืึ฿ฺࠠ็็ࠤฬ๊ศา่ส้ั่ࠦๆีะ๋ࠥ๐ู๋ัࠣืาฮࠠศๆุๅาอสࠡ็้ࠤฬ๊ล็ฬิ๊ฯูࠦ็ัࠣห้ำวอหࠣษ้๐็ศࠢ࠱࠲ࠥ฿ไๆษࠣว๋ࠦวๅ็ึัࠥ๐สๆࠢอ่็อฦ๋ษࠣ฽๋ีࠠศ่อ๋ฬวฺࠠ็ิࠤฬ๊ีโฯสฮࠥ࠴࠮๊ࠡฦ๎฻อࠠศๆ่ืาࠦไศࠢํฺึ่ࠦๆ็ๆ๊ࠥ๐อๅࠢห฽฻ࠦวๅ็ืห่๊ࠧ࠷"))
	if x6zlf2tTZm==UnOIK1WBbw2:
		zTEXepHg92GkWf = mJZ2eb9HzawrqRCsU7D6(QQwBc24Oza7jJ8ClTRWexUoqGAkg0,S5MWhgtZ37Xw,FFKncZx5pDTwdiJRYhMgQSNL)
		if zTEXepHg92GkWf: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠫา๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡ็ึั๋ࠥฬๅัࠣ็ฬฺࠠศๆหี๋อๅอࠩ࠸"))
		else: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,ZjELJ9VrUT07R8Hn4FuSDcf(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็ฯ่ิࠦใศึࠣห้ฮั็ษ่ะࠬ࠹"))
	return zTEXepHg92GkWf
def MVx75LYvEdCyWpcI():
	zTEXepHg92GkWf = FFKncZx5pDTwdiJRYhMgQSNL
	x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(w0ivtSjV2sZDQoT1OEugIla7R6AC5M(u"࠭ࡣࡦࡰࡷࡩࡷ࠭࠺"),nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,Qy6wlfLoOpg1(u"ࠧิฦส่ࠬ࠻"),VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠨ้็ࠤศ์สࠡ็อว่ี้ࠠฬิ๎ิࠦๅิฯࠣ์ฯ฻แ๋ำࠣะ๊๐ูࠡว฼ำฬีวหࠢหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ࠴ࠠฮ์ฮࠤฯ฿่ะࠢฯ้๏฿ࠠศๆศ฽ิอฯศฬࠣษ้๏ุ้ࠠ฼๎ฮࠦสฬสํฮࠥอไษำ้ห๊าࠠภࠩ࠼"))
	if x6zlf2tTZm==UnOIK1WBbw2:
		try:
			XoZRpFe7B6gnfA.remove(LLfnMdCSp5uKc3GIzjQ17mk6APNtU2)
			zTEXepHg92GkWf = S5MWhgtZ37Xw
		except: pass
		if zTEXepHg92GkWf: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,vzqjsVHSBlMpxC(u"ࠩอ้ࠥฮๆอษะࠤู๊อ๊ࠡอูๆ๐ัࠡ็็ๅࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ࠽"))
		else: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,rCmGE4YIDaZA(u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦๅิฯ้้ࠣ็ࠠศๆศ฽ิอฯศฬࠪ࠾"))
	return zTEXepHg92GkWf
def DuVqPbzQScUXdf1pTW():
	hny96IgYU8GPrb1vXplF0REAQ,tIzJpVo8H4A0 = uuA7BHRfgmOPZnQVtdYzDyFqiE(TLeNP9vpcu7gozCIA4UqYOikaSd2Dj)
	AT97seKDgcuBqlPfFSN452wx8mnoWk,D51wlUTOvEhoNK = uuA7BHRfgmOPZnQVtdYzDyFqiE(uuNo4ROjpFtXHbfBzcxrqn5lL)
	mH0RFAUd3S,rpe3TM9xK7mDJOozLStc = cpNjIxZEUORvTw(pov40VyNdZshR)
	Rchs1vok6tWZGV0,BXphwoMZy4QNIxzgHOUGqPd = hny96IgYU8GPrb1vXplF0REAQ+AT97seKDgcuBqlPfFSN452wx8mnoWk+mH0RFAUd3S,tIzJpVo8H4A0+D51wlUTOvEhoNK+rpe3TM9xK7mDJOozLStc
	gtDwSCe3Z9xfL5zn = mRanX1HZupfSQVB2gsDGUO(u"ࠫࠥ࠮ࠧ࠿")+dOh1KDo5nqWZ2e8zBRTgjrCF0XV(hny96IgYU8GPrb1vXplF0REAQ)+mRanX1HZupfSQVB2gsDGUO(u"ࠬࠦ࠭ࠡࠩࡀ")+str(tIzJpVo8H4A0)+FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࡁ")
	oyiZl283hIc9BNv = rCmGE4YIDaZA(u"ࠧࠡࠪࠪࡂ")+dOh1KDo5nqWZ2e8zBRTgjrCF0XV(AT97seKDgcuBqlPfFSN452wx8mnoWk)+zhE5I4xHinX0UoVZMNwlkPrR(u"ࠨࠢ࠰ࠤࠬࡃ")+str(D51wlUTOvEhoNK)+ldIfvn6asURQ9toi85EhqAXW3(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࡄ")
	k7EHn02TyKNpduB9SRWG5JMx = xwIUQfiE7rmvYzH(u"ࠪࠤ࠭࠭ࡅ")+dOh1KDo5nqWZ2e8zBRTgjrCF0XV(mH0RFAUd3S)+Yj1msqVeivESfrCupRy9b7WacBd(u"ࠫࠥ࠳ࠠࠨࡆ")+str(rpe3TM9xK7mDJOozLStc)+FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࡇ")
	WQCm8UvrpDYB = HD7MQqXd2gS(u"࠭ࠠࠩࠩࡈ")+dOh1KDo5nqWZ2e8zBRTgjrCF0XV(Rchs1vok6tWZGV0)+pxt6wJ8ScYMWCivoO(u"ࠧࠡ࠯ࠣࠫࡉ")+str(BXphwoMZy4QNIxzgHOUGqPd)+bb1fgjsAq4N2xYwnoh39lm(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࡊ")
	TBt8bUDo9WhL(DFx6E0uON7Jm8(u"ࠩ࡯࡭ࡳࡱࠧࡋ"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+HD7MQqXd2gS(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࡌ")+WQCm8UvrpDYB,nA5dhMRg6ENzsB0l1GwvH7aIr2,rCmGE4YIDaZA(u"࠳࠳࠼࠹࣬"))
	TBt8bUDo9WhL(xwIUQfiE7rmvYzH(u"ࠫࡱ࡯࡮࡬ࠩࡍ"),bbTCMJwEx8nhN4X+bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫࡎ")+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,baBcNd81eH5ry2Olp6Mj43(u"࠼࠽࠾࠿࣭"))
	TBt8bUDo9WhL(PPxYugzLZwHX23yiK(u"࠭࡬ࡪࡰ࡮ࠫࡏ"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠧๆีะࠤฺ๎ัࠡษ็็ฯอศสࠩࡐ")+gtDwSCe3Z9xfL5zn,nA5dhMRg6ENzsB0l1GwvH7aIr2,Qy6wlfLoOpg1(u"࠵࠵࠾࠱࣮"))
	TBt8bUDo9WhL(pxt6wJ8ScYMWCivoO(u"ࠨ࡮࡬ࡲࡰ࠭ࡑ"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+nfNTgkiWdUq(u"่ࠩืาࠦใศึࠣห้ฮั็ษ่ะࠬࡒ")+oyiZl283hIc9BNv,nA5dhMRg6ENzsB0l1GwvH7aIr2,HD7MQqXd2gS(u"࠶࠶࠸࠳࣯"))
	TBt8bUDo9WhL(ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠪࡰ࡮ࡴ࡫ࠨࡓ"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+baBcNd81eH5ry2Olp6Mj43(u"ู๊ࠫอࠡว฼ำฬีวหࠢส่อืๆศ็ฯࠫࡔ")+k7EHn02TyKNpduB9SRWG5JMx,nA5dhMRg6ENzsB0l1GwvH7aIr2,Qy6wlfLoOpg1(u"࠷࠰࠹࠵ࣰ"))
	TBt8bUDo9WhL(bb1fgjsAq4N2xYwnoh39lm(u"ࠬࡲࡩ࡯࡭ࠪࡕ"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"࠭สึใํีࠥอไษำ้ห๊าࠧࡖ")+WQCm8UvrpDYB,nA5dhMRg6ENzsB0l1GwvH7aIr2,lw2snZ9J0uhLoxypqa(u"࠱࠱࠺࠷ࣱ"))
	return
def eRbIgFjyA8u():
	hny96IgYU8GPrb1vXplF0REAQ,tIzJpVo8H4A0 = uuA7BHRfgmOPZnQVtdYzDyFqiE(U5d4FgmSCzTZGe9wPu37kXaHqo0)
	AT97seKDgcuBqlPfFSN452wx8mnoWk,D51wlUTOvEhoNK = uuA7BHRfgmOPZnQVtdYzDyFqiE(LVmeESUHAw2Tr7XPoNOYiWqIbxv6ZG)
	mH0RFAUd3S,rpe3TM9xK7mDJOozLStc = uuA7BHRfgmOPZnQVtdYzDyFqiE(VPAWJQf10uicMnh2dZCK)
	Rchs1vok6tWZGV0,BXphwoMZy4QNIxzgHOUGqPd = cpNjIxZEUORvTw(PSZn6Ac25XlT8bjQe)
	Rchs1vok6tWZGV0 -= mRanX1HZupfSQVB2gsDGUO(u"࠴࠸࠻࠺࠹ࣲ")
	BXphwoMZy4QNIxzgHOUGqPd -= UnOIK1WBbw2
	i0gkImCvH1p = str(XoZRpFe7B6gnfA.listdir(iTQzLPEURbp943ulcfWwear))
	UEXiuLlp3y0C9Jrq8dSZba6wHxKvo = i0gkImCvH1p.count(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠧ࡬ࡱࡧ࡭ࡤࡹࡴࡢࡥ࡮ࡸࡷࡧࡣࡦࠩࡗ"))+i0gkImCvH1p.count(JvQd6LMoBX4hiy1C(u"ࠨ࡭ࡲࡨ࡮ࡥࡣࡳࡣࡶ࡬ࡱࡵࡧࠨࡘ"))
	gtDwSCe3Z9xfL5zn = YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࡙ࠩࠣࠬࠬ")+dOh1KDo5nqWZ2e8zBRTgjrCF0XV(hny96IgYU8GPrb1vXplF0REAQ)+pxt6wJ8ScYMWCivoO(u"ࠪࠤ࠲࡚ࠦࠧ")+str(tIzJpVo8H4A0)+AJHaiQq3PRd5cphzGuELnVg9X(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࡛࠭ࠬ")
	oyiZl283hIc9BNv = xwIUQfiE7rmvYzH(u"ࠬࠦࠨࠨ࡜")+dOh1KDo5nqWZ2e8zBRTgjrCF0XV(AT97seKDgcuBqlPfFSN452wx8mnoWk)+Pj9YaUq1ibJ(u"࠭ࠠ࠮ࠢࠪ࡝")+str(D51wlUTOvEhoNK)+VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࡞")
	k7EHn02TyKNpduB9SRWG5JMx = baBcNd81eH5ry2Olp6Mj43(u"ࠨࠢࠫࠫ࡟")+dOh1KDo5nqWZ2e8zBRTgjrCF0XV(mH0RFAUd3S)+PPxYugzLZwHX23yiK(u"ࠩࠣ࠱ࠥ࠭ࡠ")+str(rpe3TM9xK7mDJOozLStc)+Pj9YaUq1ibJ(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡡ")
	WQCm8UvrpDYB = VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠫࠥ࠮ࠧࡢ")+dOh1KDo5nqWZ2e8zBRTgjrCF0XV(Rchs1vok6tWZGV0)+DFx6E0uON7Jm8(u"ࠬ࠯ࠧࡣ")
	p1HnbGqvc2 = lw2snZ9J0uhLoxypqa(u"࠭ࠠࠩࠩࡤ")+str(UEXiuLlp3y0C9Jrq8dSZba6wHxKvo)+gmPI7hVEM8nD(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࡥ")
	ZKDRACg71pl0VYLbdQEIjTMcanwuzh = hny96IgYU8GPrb1vXplF0REAQ+AT97seKDgcuBqlPfFSN452wx8mnoWk+mH0RFAUd3S+Rchs1vok6tWZGV0
	PnRFqykti9 = tIzJpVo8H4A0+D51wlUTOvEhoNK+rpe3TM9xK7mDJOozLStc+BXphwoMZy4QNIxzgHOUGqPd+UEXiuLlp3y0C9Jrq8dSZba6wHxKvo
	OOrjZaTIVXQ2Sp0ozhc = HD7MQqXd2gS(u"ࠨࠢࠫࠫࡦ")+dOh1KDo5nqWZ2e8zBRTgjrCF0XV(ZKDRACg71pl0VYLbdQEIjTMcanwuzh)+FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠩࠣ࠱ࠥ࠭ࡧ")+str(PnRFqykti9)+yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡨ")
	TBt8bUDo9WhL(FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠫࡱ࡯࡮࡬ࠩࡩ"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+Qy6wlfLoOpg1(u"๋ࠬำฮࠢส่ัฺ๋๊ࠩࡪ")+OOrjZaTIVXQ2Sp0ozhc,nA5dhMRg6ENzsB0l1GwvH7aIr2,bb1fgjsAq4N2xYwnoh39lm(u"࠹࠷࠹ࣳ"))
	TBt8bUDo9WhL(FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠭࡬ࡪࡰ࡮ࠫ࡫"),bbTCMJwEx8nhN4X+vzqjsVHSBlMpxC(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭࡬")+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠼࠽࠾࠿ࣴ"))
	TBt8bUDo9WhL(yPE2t1Co4YQDfsIecdxu0Gklq6AvO(u"ࠨ࡮࡬ࡲࡰ࠭࡭"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+jil8vRpBsENVYyPmDd(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠨ࡮")+gtDwSCe3Z9xfL5zn,nA5dhMRg6ENzsB0l1GwvH7aIr2,jil8vRpBsENVYyPmDd(u"࠻࠹࠷ࣵ"))
	TBt8bUDo9WhL(nfNTgkiWdUq(u"ࠪࡰ࡮ࡴ࡫ࠨ࡯"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ู๊ࠫอࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠫࡰ")+oyiZl283hIc9BNv,nA5dhMRg6ENzsB0l1GwvH7aIr2,jil8vRpBsENVYyPmDd(u"࠼࠺࠲ࣶ"))
	TBt8bUDo9WhL(zhE5I4xHinX0UoVZMNwlkPrR(u"ࠬࡲࡩ࡯࡭ࠪࡱ"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠭ๅิฯࠣห้฻่าࠢส่็ี๊ๆหࠪࡲ")+k7EHn02TyKNpduB9SRWG5JMx,nA5dhMRg6ENzsB0l1GwvH7aIr2,FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠽࠴࠴ࣷ"))
	TBt8bUDo9WhL(vzqjsVHSBlMpxC(u"ࠧ࡭࡫ࡱ࡯ࠬࡳ"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠨฬไี๏เࠠๆๆไࠤฺ๎ัࠡษ็ษ฻อแศฬࠪࡴ")+WQCm8UvrpDYB,nA5dhMRg6ENzsB0l1GwvH7aIr2,Qy6wlfLoOpg1(u"࠷࠵࠶ࣸ"))
	TBt8bUDo9WhL(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠩ࡯࡭ࡳࡱࠧࡵ"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+jil8vRpBsENVYyPmDd(u"ุ้ࠪำࠠๆๆไหฯࠦวๅๅิหูࠦวๅ็วๆฯฯࠧࡶ")+p1HnbGqvc2,nA5dhMRg6ENzsB0l1GwvH7aIr2,YIsyNBocg6fV3wEWPSu9GtvHxLOqDi(u"࠸࠶࠹ࣹ"))
	return
def UgmSb9CtivJazVojkE3dx():
	oIgksnmcpWZGb = S5MWhgtZ37Xw if gmPI7hVEM8nD(u"ࠫ࠴࠭ࡷ") in kkjOSvrlpDJNcqVIwUBt3 else FFKncZx5pDTwdiJRYhMgQSNL
	if not oIgksnmcpWZGb:
		OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,Pj9YaUq1ibJ(u"ࠬ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣห้า็ศิ้ࠣฯ๎แาหࠣๅ็฽ࠠๅลฯ๋ืฯ๋๊้ࠠ็ุࠦ࠮࠯่ࠢฯ้ࠦรอ้ีอࠥษศๅ๋ࠢว๋ีั้์าࠤํ๊๊้่ๆืࠥ࠴࠮๊ࠡฯ๋ฬุใࠡๆํื๋ࠥๆ้ࠡำหࠥอไ็๊฼ࠫࡸ"))
		return
	rFj1gkWuXpTniOeKAl9VN = KQctJbXeEjDhplqknU3rzi.getSetting(LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࡹ"))
	if not rFj1gkWuXpTniOeKAl9VN: iL6JnHKDGUv5lC7Q8IsO()
	hny96IgYU8GPrb1vXplF0REAQ,tIzJpVo8H4A0 = uuA7BHRfgmOPZnQVtdYzDyFqiE(dqoIyMV9P1KZB4spkXrReWmlL)
	AT97seKDgcuBqlPfFSN452wx8mnoWk,D51wlUTOvEhoNK = uuA7BHRfgmOPZnQVtdYzDyFqiE(B0jShzKWwCdopDvR84Ft6gGcl2XOMx)
	mH0RFAUd3S,rpe3TM9xK7mDJOozLStc = uuA7BHRfgmOPZnQVtdYzDyFqiE(RGtWEB1XDQ0)
	Rchs1vok6tWZGV0,BXphwoMZy4QNIxzgHOUGqPd = uuA7BHRfgmOPZnQVtdYzDyFqiE(rrMtjF6f3LmUu)
	hzKdtuX1Eabf2xOnFgeyS,UEXiuLlp3y0C9Jrq8dSZba6wHxKvo = uuA7BHRfgmOPZnQVtdYzDyFqiE(kswWoy93idmRQuchLj6tzHe2bI085)
	wFo3aV9CGvjqS7bEsPitulXN86,Ir7wsSKbqAn = uuA7BHRfgmOPZnQVtdYzDyFqiE(QrfYaDiq9xX25VeG)
	gtDwSCe3Z9xfL5zn = Yj1msqVeivESfrCupRy9b7WacBd(u"ࠧࠡࠪࠪࡺ")+dOh1KDo5nqWZ2e8zBRTgjrCF0XV(hny96IgYU8GPrb1vXplF0REAQ)+Yj1msqVeivESfrCupRy9b7WacBd(u"ࠨࠢ࠰ࠤࠬࡻ")+str(tIzJpVo8H4A0)+bb1fgjsAq4N2xYwnoh39lm(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࡼ")
	oyiZl283hIc9BNv = n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠪࠤ࠭࠭ࡽ")+dOh1KDo5nqWZ2e8zBRTgjrCF0XV(AT97seKDgcuBqlPfFSN452wx8mnoWk)+ldIfvn6asURQ9toi85EhqAXW3(u"ࠫࠥ࠳ࠠࠨࡾ")+str(D51wlUTOvEhoNK)+xwIUQfiE7rmvYzH(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࡿ")
	k7EHn02TyKNpduB9SRWG5JMx = HD7MQqXd2gS(u"࠭ࠠࠩࠩࢀ")+dOh1KDo5nqWZ2e8zBRTgjrCF0XV(mH0RFAUd3S)+gmPI7hVEM8nD(u"ࠧࠡ࠯ࠣࠫࢁ")+str(rpe3TM9xK7mDJOozLStc)+baBcNd81eH5ry2Olp6Mj43(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࢂ")
	WQCm8UvrpDYB = VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠩࠣࠬࠬࢃ")+dOh1KDo5nqWZ2e8zBRTgjrCF0XV(Rchs1vok6tWZGV0)+bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠪࠤ࠲ࠦࠧࢄ")+str(BXphwoMZy4QNIxzgHOUGqPd)+zhE5I4xHinX0UoVZMNwlkPrR(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࢅ")
	p1HnbGqvc2 = xwIUQfiE7rmvYzH(u"ࠬࠦࠨࠨࢆ")+dOh1KDo5nqWZ2e8zBRTgjrCF0XV(hzKdtuX1Eabf2xOnFgeyS)+Pj9YaUq1ibJ(u"࠭ࠠ࠮ࠢࠪࢇ")+str(UEXiuLlp3y0C9Jrq8dSZba6wHxKvo)+bb1fgjsAq4N2xYwnoh39lm(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࢈")
	QdWjHE8hsFIu3N7iobAl = DFx6E0uON7Jm8(u"ࠨࠢࠫࠫࢉ")+dOh1KDo5nqWZ2e8zBRTgjrCF0XV(wFo3aV9CGvjqS7bEsPitulXN86)+DFx6E0uON7Jm8(u"ࠩࠣ࠱ࠥ࠭ࢊ")+str(Ir7wsSKbqAn)+Qy6wlfLoOpg1(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࢋ")
	ZKDRACg71pl0VYLbdQEIjTMcanwuzh = hny96IgYU8GPrb1vXplF0REAQ+AT97seKDgcuBqlPfFSN452wx8mnoWk+mH0RFAUd3S+Rchs1vok6tWZGV0+hzKdtuX1Eabf2xOnFgeyS+wFo3aV9CGvjqS7bEsPitulXN86
	PnRFqykti9 = tIzJpVo8H4A0+D51wlUTOvEhoNK+rpe3TM9xK7mDJOozLStc+BXphwoMZy4QNIxzgHOUGqPd+UEXiuLlp3y0C9Jrq8dSZba6wHxKvo+Ir7wsSKbqAn
	OOrjZaTIVXQ2Sp0ozhc = bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠫࠥ࠮ࠧࢌ")+dOh1KDo5nqWZ2e8zBRTgjrCF0XV(ZKDRACg71pl0VYLbdQEIjTMcanwuzh)+ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠬࠦ࠭ࠡࠩࢍ")+str(PnRFqykti9)+JvQd6LMoBX4hiy1C(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࢎ")
	TBt8bUDo9WhL(XEcWOIwkZKubV7vQ(u"ࠧ࡭࡫ࡱ࡯ࠬ࢏"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+bb1fgjsAq4N2xYwnoh39lm(u"ࠨว฼฻ฬวࠠาะุอ่ࠥัศรฬࠤํ้สศสฬࠫ࢐"),nA5dhMRg6ENzsB0l1GwvH7aIr2,vzqjsVHSBlMpxC(u"࠹࠸࠼ࣺ"))
	TBt8bUDo9WhL(rCmGE4YIDaZA(u"ࠩ࡯࡭ࡳࡱࠧ࢑"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+xwIUQfiE7rmvYzH(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧ࢒")+OOrjZaTIVXQ2Sp0ozhc,nA5dhMRg6ENzsB0l1GwvH7aIr2,lw2snZ9J0uhLoxypqa(u"࠺࠹࠼ࣻ"))
	TBt8bUDo9WhL(bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠫࡱ࡯࡮࡬ࠩ࢓"),bbTCMJwEx8nhN4X+lw2snZ9J0uhLoxypqa(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫ࢔")+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,gmPI7hVEM8nD(u"࠽࠾࠿࠹ࣼ"))
	TBt8bUDo9WhL(pxt6wJ8ScYMWCivoO(u"࠭࡬ࡪࡰ࡮ࠫ࢕"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+bb1fgjsAq4N2xYwnoh39lm(u"ࠧๆีะࠤ๊๊แศฬࠣࡹࡸࡧࡧࡦࡵࡷࡥࡹࡹࠧ࢖")+gtDwSCe3Z9xfL5zn,nA5dhMRg6ENzsB0l1GwvH7aIr2,pxt6wJ8ScYMWCivoO(u"࠼࠻࠱ࣽ"))
	TBt8bUDo9WhL(jil8vRpBsENVYyPmDd(u"ࠨ࡮࡬ࡲࡰ࠭ࢗ"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+zhE5I4xHinX0UoVZMNwlkPrR(u"่ࠩืาࠦๅๅใสฮࠥࡪࡲࡰࡲࡥࡳࡽ࠭࢘")+oyiZl283hIc9BNv,nA5dhMRg6ENzsB0l1GwvH7aIr2,gmPI7hVEM8nD(u"࠽࠵࠳ࣾ"))
	TBt8bUDo9WhL(JvQd6LMoBX4hiy1C(u"ࠪࡰ࡮ࡴ࡫ࠨ࢙"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ู๊ࠫอࠡ็็ๅฬะࠠࡵࡱࡰࡦࡸࡺ࡯࡯ࡧࡶ࢚ࠫ")+k7EHn02TyKNpduB9SRWG5JMx,nA5dhMRg6ENzsB0l1GwvH7aIr2,DFx6E0uON7Jm8(u"࠷࠶࠵ࣿ"))
	TBt8bUDo9WhL(VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"ࠬࡲࡩ࡯࡭࢛ࠪ"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+gmPI7hVEM8nD(u"࠭ๅิฯ้้ࠣ็วหࠢ࡯ࡳ࡬࡭ࡥࡳࠩ࢜")+WQCm8UvrpDYB,nA5dhMRg6ENzsB0l1GwvH7aIr2,bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠸࠷࠷ऀ"))
	TBt8bUDo9WhL(n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠧ࡭࡫ࡱ࡯ࠬ࢝"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+gmPI7hVEM8nD(u"ࠨ็ึั๋ࠥไโษอࠤࡱࡵࡧࠨ࢞")+p1HnbGqvc2,nA5dhMRg6ENzsB0l1GwvH7aIr2,mRanX1HZupfSQVB2gsDGUO(u"࠹࠸࠹ँ"))
	TBt8bUDo9WhL(PPxYugzLZwHX23yiK(u"ࠩ࡯࡭ࡳࡱࠧ࢟"),DjKrTPWEFw2YeCi5d6unBqhZSlAR+XEcWOIwkZKubV7vQ(u"ุ้ࠪำࠠๆๆไหฯࠦࡡ࡯ࡴࠪࢠ")+QdWjHE8hsFIu3N7iobAl,nA5dhMRg6ENzsB0l1GwvH7aIr2,bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠺࠹࠻ं"))
	return
def Ar9fuT3HvtEWglaxMiDJGS5(showDialogs):
	if showDialogs: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,gmPI7hVEM8nD(u"๊ࠫาไะุࠢ์ึࠦใหษหอࠥอไใ๊สส๊ࠦ࠮࠯๊ࠢิฬࠦวๅ็ฯ่ิࠦแ๋้ࠣฬ฾฼ࠠใ๊สส๊ࠦวๅสิ๊ฬ๋ฬࠡ็ัึ๋ฯࠠษึๆ่ࠥ฻่าࠢหำ้อࠠๆ่ࠣห้้สศสฬࠤ࠳࠴ฺ่ࠠาࠤู๊อࠡษ็้ั๊ฯࠡีํๆํ๋ࠠศๆหี๋อๅอࠢหา้่ࠠๆฮ็ำࠥาฯ๋ัࠣ์๏ฮฯฤ่ࠢีฮࠦรฯำ์ࠤอ๋ไว้ࠣฬฬ๊ี้ำࠣ฽๋ีࠠโฬะࠤฬ๊โ้ษษ้ࠬࢡ"))
	UkTX8GQw45Dsy9du2znf31eCmcj,TcZ9BkqlvuP8GY4d7WyE = [],IpFcwrWNgefMym3qta0hYQAzOdE
	for kN0B75b1nSQ3H,Ic9vwkj5NXup0,svkXZ6y1cxbd5JG9 in XoZRpFe7B6gnfA.walk(A1CKpbwyFL8jY4I,topdown=FFKncZx5pDTwdiJRYhMgQSNL):
		U1PINxV3agOdtA = len(svkXZ6y1cxbd5JG9)
		if U1PINxV3agOdtA>bqCDnV7Bs5XgRvuKLNAa1Uz(u"࠹࠵࠶ः"): UkTX8GQw45Dsy9du2znf31eCmcj.append(Ic9vwkj5NXup0)
		TcZ9BkqlvuP8GY4d7WyE += U1PINxV3agOdtA
	fBlqdQwmeMUO = TcZ9BkqlvuP8GY4d7WyE>Yj1msqVeivESfrCupRy9b7WacBd(u"࠺࠶࠰࠱ऄ")
	if showDialogs:
		count = bbTCMJwEx8nhN4X+HD7MQqXd2gS(u"๊ࠬฯ๋ๅࠣࠤࠬࢢ")+str(TcZ9BkqlvuP8GY4d7WyE)+gmPI7hVEM8nD(u"࠭ࠠࠡื๋ีฮ࠭ࢣ")+NwROdSj3nsA
		if not UkTX8GQw45Dsy9du2znf31eCmcj and not fBlqdQwmeMUO: x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠧๅษࠣ๎ําฯࠡ฻้ำ่ࠦี้ำࠣ็ฯอศสࠢๆฯ๏ืษࠡ࠰࠱ࠤํ๊็ัษ่ࠣฬࠦสฮฬสะࠥษๆࠡฬ่ืาࠦี้ำࠣห้้สศสฬࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡ็ึัࠥ฻่าࠢส่่ะวษหࠣห้ศๆࠡมࠤࠤࡡࡴ࡜࡯ࠩࢤ")+count)
		else: x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,lw2snZ9J0uhLoxypqa(u"ࠨๆา๎่ࠦี้ำࠣ็ฯอศสࠢๆฯ๏ืษࠡ࠰࠱ࠤํํะศࠢๅำࠥ๐ำษสู้ࠣอใๅࠢไ๎ࠥะิ฻์็ࠤฬ๊ฬ่ษีࠤํะิ฻์็ࠤอืๆศ็ฯࠤ฾๋วะࠢ࠱࠲ࠥษๆหࠢหัฬาษࠡว็ํ๋ࠥำฮ๊ࠢิ์ࠦวๅื๋ีࠥ࠴࠮้ࠡ็ࠤฯื๊ะ่ࠢืาࠦี้ำࠣห้้สศสฬࠤฬ๊ย็ࠢยࠥࠥࡢ࡮࡝ࡰࠪࢥ")+count)
	else: x6zlf2tTZm = UnOIK1WBbw2
	if x6zlf2tTZm==UnOIK1WBbw2:
		if fBlqdQwmeMUO: mJZ2eb9HzawrqRCsU7D6(kN0B75b1nSQ3H,FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL)
		elif UkTX8GQw45Dsy9du2znf31eCmcj:
			for Ic9vwkj5NXup0 in UkTX8GQw45Dsy9du2znf31eCmcj: mJZ2eb9HzawrqRCsU7D6(Ic9vwkj5NXup0,FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL)
	return
def iL6JnHKDGUv5lC7Q8IsO():
	fSNgKz476uAQsicDFI = FFKncZx5pDTwdiJRYhMgQSNL
	x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,bb1fgjsAq4N2xYwnoh39lm(u"ࠩ็็๏ฺ๊ࠦ็็ࠤฬ๊ส็ฺํๅࠥ฿ๆะๅࠣ࠲࠳ࠦศา่ส้ัูࠦๆษาࠤอำวอหࠣษ้๏ࠠฦ฻ฺหฦࠦัฯืฬࠤฬ๊โาษฤอࠥ๎วๅๅอหอฯࠠๅๆ่่ๆอส๊ࠡส่๊าไะษอࠤฬ๊ส๋ࠢึ์ๆ๊ࠦๆีะ๋ฬࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤ์๊ࠠหำํำࠥหูุษฤࠤ์ึ็ࠡษ็ีำ฻ษࠡษ็ฦ๋ࠦฟࠢࠩࢦ"))
	if x6zlf2tTZm==-bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠷अ"): return
	if x6zlf2tTZm:
		import subprocess as gMHawR1pqNsG0OScAZILfBYm6Eyb
		try:
			gMHawR1pqNsG0OScAZILfBYm6Eyb.Popen(bqCDnV7Bs5XgRvuKLNAa1Uz(u"ࠪࡷࡺ࠭ࢧ"))
			fSNgKz476uAQsicDFI = S5MWhgtZ37Xw
		except: pass
		if fSNgKz476uAQsicDFI:
			RKd9jfEtByCVnsWe2rZ = dqoIyMV9P1KZB4spkXrReWmlL+hSXlxL9iB05c+B0jShzKWwCdopDvR84Ft6gGcl2XOMx+hSXlxL9iB05c+RGtWEB1XDQ0+hSXlxL9iB05c+rrMtjF6f3LmUu+hSXlxL9iB05c+kswWoy93idmRQuchLj6tzHe2bI085+hSXlxL9iB05c+QrfYaDiq9xX25VeG
			NCr1wDWZ7t36xVfRdUis2Tzl = gMHawR1pqNsG0OScAZILfBYm6Eyb.Popen(JvQd6LMoBX4hiy1C(u"ࠫࡸࡻࠠ࠮ࡥࠣࠦࡨ࡮࡭ࡰࡦࠣ࠱ࡗࠦ࠰࠸࠹࠺ࠤࠬࢨ")+RKd9jfEtByCVnsWe2rZ+Pj9YaUq1ibJ(u"ࠬࠨࠧࢩ"),shell=S5MWhgtZ37Xw,stdin=gMHawR1pqNsG0OScAZILfBYm6Eyb.PIPE,stdout=gMHawR1pqNsG0OScAZILfBYm6Eyb.PIPE,stderr=gMHawR1pqNsG0OScAZILfBYm6Eyb.PIPE)
			OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,FVxoQ2J5Mfv3Zj6sy9uhOS(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣษ฾฽วยࠢส่ึิีสࠩࢪ"))
		else: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,bb1fgjsAq4N2xYwnoh39lm(u"ฺࠧ็็๎ฮࠦลฺูสลࠥืฮึหࠣห้่ัศรฬࠤํอไไฬสฬฮࠦสฮฬสะࠥฮั็ษ่ะࠥࠦࡲࡰࡱࡷࠤࠥษ่ࠡࠢࡶࡹࡵ࡫ࡲࡶࡵࡨࡶࠥࠦร้ࠢࠣࡷࡺ้ࠦࠠฮ๊หื้ࠠๅษࠣ๎ําฯࠡใํ๋ࠥํะศࠢส่อืๆศ็ฯࠤ࠳࠴ࠠฤ๊ࠣ็ํี๊ࠡ฼ํี่ࠥวะำࠣ฽้๏ࠠศีอาิอๅ้ࠡำหࠥอไษำ้ห๊าࠧࢫ"))
	return fSNgKz476uAQsicDFI
def dOh1KDo5nqWZ2e8zBRTgjrCF0XV(ZKDRACg71pl0VYLbdQEIjTMcanwuzh):
	for Ab4TEqtXv5Smpf1PCoNQ9 in [ldIfvn6asURQ9toi85EhqAXW3(u"ࠨࡄࠪࢬ"),JvQd6LMoBX4hiy1C(u"ࠩࡎࡆࠬࢭ"),Qy6wlfLoOpg1(u"ࠪࡑࡇ࠭ࢮ"),n8BrpFLyaMAC1vP0bOHgwxEzeGRV(u"ࠫࡌࡈࠧࢯ"),ldIfvn6asURQ9toi85EhqAXW3(u"࡚ࠬࡂࠨࢰ")]:
		if ZKDRACg71pl0VYLbdQEIjTMcanwuzh<LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"࠱࠱࠴࠷आ"): break
		else: ZKDRACg71pl0VYLbdQEIjTMcanwuzh /= VVstJA9bfOqunLF0oaSgWUKHDdYNz(u"࠲࠲࠵࠸࠳࠶इ")
	OOrjZaTIVXQ2Sp0ozhc = baBcNd81eH5ry2Olp6Mj43(u"ࠨࠥ࠴࠰࠴ࡪࠥࠫࡳࠣࢱ")%(ZKDRACg71pl0VYLbdQEIjTMcanwuzh,Ab4TEqtXv5Smpf1PCoNQ9)
	return OOrjZaTIVXQ2Sp0ozhc
def uuA7BHRfgmOPZnQVtdYzDyFqiE(vjOXmJfZM1TAzk5GhLr3W9Pg4eF7=FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠧ࠯ࠩࢲ")):
	global XiUsQl8BKeFxcJYnzWujG6,su5PoYBfSrAnqxRWLyH0
	XiUsQl8BKeFxcJYnzWujG6,su5PoYBfSrAnqxRWLyH0 = IpFcwrWNgefMym3qta0hYQAzOdE,IpFcwrWNgefMym3qta0hYQAzOdE
	def t10d5gkIXEaB(vjOXmJfZM1TAzk5GhLr3W9Pg4eF7):
		global XiUsQl8BKeFxcJYnzWujG6,su5PoYBfSrAnqxRWLyH0
		if XoZRpFe7B6gnfA.path.exists(vjOXmJfZM1TAzk5GhLr3W9Pg4eF7):
			if IpFcwrWNgefMym3qta0hYQAzOdE and ZjELJ9VrUT07R8Hn4FuSDcf(u"ࠨࡵࡦࡥࡳࡪࡩࡳࠩࢳ") in dir(XoZRpFe7B6gnfA):
				for zz34dRoaFI6BhGM in XoZRpFe7B6gnfA.scandir(vjOXmJfZM1TAzk5GhLr3W9Pg4eF7):
					if zz34dRoaFI6BhGM.is_dir(follow_symlinks=FFKncZx5pDTwdiJRYhMgQSNL):
						t10d5gkIXEaB(zz34dRoaFI6BhGM.path)
					elif zz34dRoaFI6BhGM.is_file(follow_symlinks=FFKncZx5pDTwdiJRYhMgQSNL):
						XiUsQl8BKeFxcJYnzWujG6 += zz34dRoaFI6BhGM.stat().st_size
						su5PoYBfSrAnqxRWLyH0 += UnOIK1WBbw2
			else:
				for zz34dRoaFI6BhGM in XoZRpFe7B6gnfA.listdir(vjOXmJfZM1TAzk5GhLr3W9Pg4eF7):
					ScBlEZs4p5dGmrzTCgiD3fWPO7hqK = XoZRpFe7B6gnfA.path.abspath(XoZRpFe7B6gnfA.path.join(vjOXmJfZM1TAzk5GhLr3W9Pg4eF7,zz34dRoaFI6BhGM))
					if XoZRpFe7B6gnfA.path.isdir(ScBlEZs4p5dGmrzTCgiD3fWPO7hqK):
						t10d5gkIXEaB(ScBlEZs4p5dGmrzTCgiD3fWPO7hqK)
					elif XoZRpFe7B6gnfA.path.isfile(ScBlEZs4p5dGmrzTCgiD3fWPO7hqK):
						ZKDRACg71pl0VYLbdQEIjTMcanwuzh,PnRFqykti9 = cpNjIxZEUORvTw(ScBlEZs4p5dGmrzTCgiD3fWPO7hqK)
						XiUsQl8BKeFxcJYnzWujG6 += ZKDRACg71pl0VYLbdQEIjTMcanwuzh
						su5PoYBfSrAnqxRWLyH0 += PnRFqykti9
		return
	try: t10d5gkIXEaB(vjOXmJfZM1TAzk5GhLr3W9Pg4eF7)
	except: pass
	return XiUsQl8BKeFxcJYnzWujG6,su5PoYBfSrAnqxRWLyH0
def gbwIZTGQDPrq(showDialogs):
	if showDialogs:
		x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,bbTCMJwEx8nhN4X+bqCDnV7Bs5XgRvuKLNAa1Uz(u"๊่ࠩࠥะั๋ัุ้ࠣำࠧࢴ")+CXtugbqhV3+LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"้ࠪั๊ฯࠡษ็้้็วหࠢส่๊สโหหࠣ࠲࠳่ࠦๆฮ็ำࠥอไๆๆไหฯࠦวๅ็ู฾ํ฽ษࠡ࠰࠱ࠤํ๋ฬๅัࠣห้฻่าࠢส่็ี๊ๆหࠣ࠲࠳่ࠦหใิ๎฿ࠦๅๅใูࠣํืࠠศๆศฺฬ็วหࠢ࠱࠲ࠥ๎ๅๅใสฮࠥอไไำสุࠬࢵ")+CXtugbqhV3+UUobzy0xZLaVScIt7(u"ࠫฤࠧࠡࠨࢶ")+NwROdSj3nsA)
		if x6zlf2tTZm!=UnOIK1WBbw2: return
	CkSslRwMFVJPpfKY = mJZ2eb9HzawrqRCsU7D6(U5d4FgmSCzTZGe9wPu37kXaHqo0,S5MWhgtZ37Xw,FFKncZx5pDTwdiJRYhMgQSNL)
	ZH95UItD3qio0Xuc8sBM = mJZ2eb9HzawrqRCsU7D6(LVmeESUHAw2Tr7XPoNOYiWqIbxv6ZG,S5MWhgtZ37Xw,FFKncZx5pDTwdiJRYhMgQSNL)
	QUwv4Or2m3XJSYVkuAhqlPT15G0zx = mJZ2eb9HzawrqRCsU7D6(VPAWJQf10uicMnh2dZCK,FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL)
	XxkjQKImalGDMwzenT = csnW6ZSXRIQoYmTf(FFKncZx5pDTwdiJRYhMgQSNL)
	JJ185NOtjqS = cKzyGqPdsW3ADFZJgIV7Et19j25rNb(FFKncZx5pDTwdiJRYhMgQSNL)
	succeeded = all([CkSslRwMFVJPpfKY,ZH95UItD3qio0Xuc8sBM,QUwv4Or2m3XJSYVkuAhqlPT15G0zx,XxkjQKImalGDMwzenT,JJ185NOtjqS])
	if showDialogs:
		if succeeded: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,JvQd6LMoBX4hiy1C(u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ࢷ"))
		else: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,Pj9YaUq1ibJ(u"࠭ไๅลึๅࠥ็ิๅฬࠣ฽๊๊๊สࠢสู่๊อࠨࢸ"))
	return succeeded
def UuAGvYCnHoczTKr40R53VPXZQ(showDialogs):
	if showDialogs:
		RKd9jfEtByCVnsWe2rZ = dqoIyMV9P1KZB4spkXrReWmlL+CXtugbqhV3+B0jShzKWwCdopDvR84Ft6gGcl2XOMx+CXtugbqhV3+RGtWEB1XDQ0+CXtugbqhV3+rrMtjF6f3LmUu+CXtugbqhV3+kswWoy93idmRQuchLj6tzHe2bI085+CXtugbqhV3+QrfYaDiq9xX25VeG
		x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,bbTCMJwEx8nhN4X+DFx6E0uON7Jm8(u"่ࠧๆࠣฮึ๐ฯࠡ็ึัࠥอไๆๆไหฯࠦวๅ็วๆฯฯࠠศๆอ๎ࠥ็๊้ࠡำ๋ࠥอไๆฮ็ำฬะ࡜࡯࡞ࡱࠫࢹ")+RKd9jfEtByCVnsWe2rZ+NwROdSj3nsA)
		if x6zlf2tTZm!=UnOIK1WBbw2: return
	CkSslRwMFVJPpfKY = mJZ2eb9HzawrqRCsU7D6(dqoIyMV9P1KZB4spkXrReWmlL,FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL)
	ZH95UItD3qio0Xuc8sBM = mJZ2eb9HzawrqRCsU7D6(B0jShzKWwCdopDvR84Ft6gGcl2XOMx,FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL)
	QUwv4Or2m3XJSYVkuAhqlPT15G0zx = mJZ2eb9HzawrqRCsU7D6(RGtWEB1XDQ0,FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL)
	XxkjQKImalGDMwzenT = mJZ2eb9HzawrqRCsU7D6(rrMtjF6f3LmUu,FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL)
	JJ185NOtjqS = mJZ2eb9HzawrqRCsU7D6(kswWoy93idmRQuchLj6tzHe2bI085,FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL)
	QQNa5Egsk6Yv0HIUOA38RLKo = mJZ2eb9HzawrqRCsU7D6(QrfYaDiq9xX25VeG,FFKncZx5pDTwdiJRYhMgQSNL,FFKncZx5pDTwdiJRYhMgQSNL)
	succeeded = all([CkSslRwMFVJPpfKY,ZH95UItD3qio0Xuc8sBM,QUwv4Or2m3XJSYVkuAhqlPT15G0zx,XxkjQKImalGDMwzenT,JJ185NOtjqS,QQNa5Egsk6Yv0HIUOA38RLKo])
	if showDialogs:
		if succeeded: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,XEcWOIwkZKubV7vQ(u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩࢺ"))
		else: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,gmPI7hVEM8nD(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥอไๆีะࠫࢻ"))
	return succeeded
def csnW6ZSXRIQoYmTf(showDialogs):
	if showDialogs:
		x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,bbTCMJwEx8nhN4X+zhE5I4xHinX0UoVZMNwlkPrR(u"๋้ࠪࠦสา์าࠤู๊อࠡ็ะฮํ๐วห่่ࠢๆࠦี้ำࠣห้าไะࠢยࠥࠦ࠭ࢼ")+NwROdSj3nsA)
		if x6zlf2tTZm!=jil8vRpBsENVYyPmDd(u"࠳ई"): return mRanX1HZupfSQVB2gsDGUO(u"ࡉࡥࡱࡹࡥउ")
	try:
		succeeded = DFx6E0uON7Jm8(u"ࡘࡷࡻࡥऊ")
		Ccemh2nAvQ = NpEaoJdsihbVYkrfHOuMeycA.connect(PSZn6Ac25XlT8bjQe)
		Ccemh2nAvQ.text_factory = str
		ADJdGOPzaeo0rXf2SuKQbcFWqilw = Ccemh2nAvQ.cursor()
		ADJdGOPzaeo0rXf2SuKQbcFWqilw.execute(JvQd6LMoBX4hiy1C(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡳࡥࡹ࡮࠻ࠨࢽ"))
		ADJdGOPzaeo0rXf2SuKQbcFWqilw.execute(jil8vRpBsENVYyPmDd(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡷ࡮ࢀࡥࡴ࠽ࠪࢾ"))
		ADJdGOPzaeo0rXf2SuKQbcFWqilw.execute(bDxWcjmaSgFeRKrfpJvyA4zThi(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡹ࡫ࡸࡵࡷࡵࡩࡀ࠭ࢿ"))
		Ccemh2nAvQ.commit()
		ADJdGOPzaeo0rXf2SuKQbcFWqilw.execute(gmPI7hVEM8nD(u"ࠧࡗࡃࡆ࡙࡚ࡓ࠻ࠨࣀ"))
		Ccemh2nAvQ.close()
	except: succeeded = mRanX1HZupfSQVB2gsDGUO(u"ࡋࡧ࡬ࡴࡧऋ")
	if showDialogs:
		if succeeded: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,lw2snZ9J0uhLoxypqa(u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩࣁ"))
		else: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,FVxoQ2J5Mfv3Zj6sy9uhOS(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥอไๆีะࠫࣂ"))
	return succeeded
def cKzyGqPdsW3ADFZJgIV7Et19j25rNb(showDialogs):
	if showDialogs:
		x6zlf2tTZm = bjyB5J1QuNaIXOx9qSwm4v0edDhg(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,FVxoQ2J5Mfv3Zj6sy9uhOS(u"้้ࠪ็วหࠢส่่ืวี๊ࠢ๎๋ࠥไโษอࠤ๏฻ๆฺ้สࠤ่๎ฯ๋ࠢ฼๊ิ๋วࠡ์฽่็ࠦๆโี๊ࠤอ฻่าห้ࠣๆอฬฤหࠣ࠲࠳ࠦ็ั้ࠣห้๋ไโษอࠤ๏ำสศฮ๊ห๋ࠥศา็ฯ๎้่ࠥะ์ࠣัฯ๏๋ࠠ฻ิๅํ์ࠠๆ่๊ห้๊ࠥโࠢะำะะࠠศๆุ่่๊ษࠨࣃ")+CXtugbqhV3+CXtugbqhV3+bbTCMJwEx8nhN4X+Qy6wlfLoOpg1(u"ࠫ์๊ࠠหำํำ๋ࠥำฮ่่ࠢๆอสࠡษ็็ึอิࠡษ็้ษ่สสࠢยࠥࠦ࠭ࣄ")+NwROdSj3nsA)
		if x6zlf2tTZm!=UnOIK1WBbw2: return bb1fgjsAq4N2xYwnoh39lm(u"ࡌࡡ࡭ࡵࡨऌ")
	succeeded = LJqSQvuhf7aMmnVjy23FbZBckKzx9l(u"ࡔࡳࡷࡨऍ")
	for file in XoZRpFe7B6gnfA.listdir(iTQzLPEURbp943ulcfWwear):
		if JvQd6LMoBX4hiy1C(u"ࠬࡱ࡯ࡥ࡫ࡢࡷࡹࡧࡣ࡬ࡶࡵࡥࡨ࡫ࠧࣅ") not in file and nfNTgkiWdUq(u"࠭࡫ࡰࡦ࡬ࡣࡨࡸࡡࡴࡪ࡯ࡳ࡬࠭ࣆ") not in file: continue
		i9GKPyIEQjSC6tpgo = XoZRpFe7B6gnfA.path.join(iTQzLPEURbp943ulcfWwear,file)
		try: XoZRpFe7B6gnfA.remove(i9GKPyIEQjSC6tpgo)
		except Exception as f3xe1K6ndi:
			succeeded = AJHaiQq3PRd5cphzGuELnVg9X(u"ࡇࡣ࡯ࡷࡪऎ")
			if showDialogs: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,str(f3xe1K6ndi))
	if showDialogs:
		if succeeded: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,PPxYugzLZwHX23yiK(u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨࣇ"))
		else: OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,jil8vRpBsENVYyPmDd(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฬ๊ๅิฯࠪࣈ"))
	return succeeded
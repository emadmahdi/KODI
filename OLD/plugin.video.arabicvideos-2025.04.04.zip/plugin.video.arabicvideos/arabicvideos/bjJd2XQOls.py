# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'CIMA400'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_C4H_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
SAsGubf1jW2Q3p = ['الصفحة الرئيسية','Sign in','الاقسام','عرض المزيد','Categories',nA5dhMRg6ENzsB0l1GwvH7aIr2]
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==690: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==691: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,text)
	elif mode==692: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==693: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = Uz7y8Vt3frjd6ZKHwcgsFBv05apxNC(url,text)
	elif mode==694: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = oWcvptkU2JObI0(url)
	elif mode==699: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMA400-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,699,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"navslide-divider"(.*?)"navslide-divider"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	items = PAztbuyYo4Kvd.findall('href="(.*?)".*?>(.*?)</',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title in items:
		if title in SAsGubf1jW2Q3p: continue
		title = title.replace('<b>',nA5dhMRg6ENzsB0l1GwvH7aIr2).strip(hSXlxL9iB05c)
		TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,694)
	return
def oWcvptkU2JObI0(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMA400-SUBMENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	LKk0YdTN72XmnMuBbw = PAztbuyYo4Kvd.findall('"caret"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if LKk0YdTN72XmnMuBbw:
		WWU7QJP2tyTRLIfDh0csxbkvX = LKk0YdTN72XmnMuBbw[0]
		WWU7QJP2tyTRLIfDh0csxbkvX = WWU7QJP2tyTRLIfDh0csxbkvX.replace('"presentation"','</ul>')
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if not zz3eHskxE6lAyDR5cNj1ug: zz3eHskxE6lAyDR5cNj1ug = [(nA5dhMRg6ENzsB0l1GwvH7aIr2,WWU7QJP2tyTRLIfDh0csxbkvX)]
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' فرز أو فلتر أو ترتيب '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
		for eMGqlWRdtC8EK2nFz,WWU7QJP2tyTRLIfDh0csxbkvX in zz3eHskxE6lAyDR5cNj1ug:
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?>(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			if eMGqlWRdtC8EK2nFz: eMGqlWRdtC8EK2nFz = eMGqlWRdtC8EK2nFz+': '
			for ZylHkumQ8zD0,title in items:
				title = eMGqlWRdtC8EK2nFz+title
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,691)
	N5Vbkn2chPGfT3m97Bv1LHKI = PAztbuyYo4Kvd.findall('"pm-category-subcats"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if N5Vbkn2chPGfT3m97Bv1LHKI:
		WWU7QJP2tyTRLIfDh0csxbkvX = N5Vbkn2chPGfT3m97Bv1LHKI[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if len(items)<30:
			TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
			for ZylHkumQ8zD0,title in items:
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,691)
	if not LKk0YdTN72XmnMuBbw and not N5Vbkn2chPGfT3m97Bv1LHKI: LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
	return
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,YsdSH10ta6wvi4nMRIO9=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if YsdSH10ta6wvi4nMRIO9=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'POST',url,data,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMA400-TITLES-1st')
	else:
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMA400-TITLES-2nd')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	WWU7QJP2tyTRLIfDh0csxbkvX,items = nA5dhMRg6ENzsB0l1GwvH7aIr2,[]
	GWjBrpNhRsmt7eDba1yA4nukS = C2gnJ5tXFk9pAL(url,'url')
	if YsdSH10ta6wvi4nMRIO9=='ajax-search':
		WWU7QJP2tyTRLIfDh0csxbkvX = kl2ZWdy8rXcHT
		hn2rCExmu5pgejyYOT = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in hn2rCExmu5pgejyYOT: items.append((nA5dhMRg6ENzsB0l1GwvH7aIr2,ZylHkumQ8zD0,title))
	elif YsdSH10ta6wvi4nMRIO9=='featured':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"pm-video-watch-featured"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug: WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	elif YsdSH10ta6wvi4nMRIO9=='new_episodes':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"row pm-ul-browse-videos(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug: WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	elif YsdSH10ta6wvi4nMRIO9=='new_movies':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"row pm-ul-browse-videos(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if len(zz3eHskxE6lAyDR5cNj1ug)>1: WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[1]
	elif YsdSH10ta6wvi4nMRIO9=='featured_series':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"ba mgb table full"(.*?)"clearfix"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug: WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		hn2rCExmu5pgejyYOT = PAztbuyYo4Kvd.findall('href="(.*?)" title="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in hn2rCExmu5pgejyYOT: items.append((nA5dhMRg6ENzsB0l1GwvH7aIr2,ZylHkumQ8zD0,title))
	else:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('(data-echo=".*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug: WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	if WWU7QJP2tyTRLIfDh0csxbkvX and not items: items = PAztbuyYo4Kvd.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	if not items: return
	u0UiTmzYN6I3Q9eCZVoB = []
	hdocEkRK0Q = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for HRlygv7YwjzbSLt8fkEerq2,ZylHkumQ8zD0,title in items:
		JfNHOP2BK1Yxl7Rq4 = PAztbuyYo4Kvd.findall('(.*?) (الحلقة|حلقة).\d+',title,PAztbuyYo4Kvd.DOTALL)
		if any(value in title for value in hdocEkRK0Q):
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,692,HRlygv7YwjzbSLt8fkEerq2)
		elif YsdSH10ta6wvi4nMRIO9=='new_episodes':
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,692,HRlygv7YwjzbSLt8fkEerq2)
		elif JfNHOP2BK1Yxl7Rq4:
			title = '_MOD_' + JfNHOP2BK1Yxl7Rq4[0][0]
			if title not in u0UiTmzYN6I3Q9eCZVoB:
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,693,HRlygv7YwjzbSLt8fkEerq2)
				u0UiTmzYN6I3Q9eCZVoB.append(title)
		else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,693,HRlygv7YwjzbSLt8fkEerq2)
	if 1:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"pagination(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?>(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,title in items:
				if ZylHkumQ8zD0=='#': continue
				ZylHkumQ8zD0 = GWjBrpNhRsmt7eDba1yA4nukS+'/'+ZylHkumQ8zD0.strip('/')
				title = HH8SJuswDBPtniebmkXIr(title)
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+title,ZylHkumQ8zD0,691)
	return
def Uz7y8Vt3frjd6ZKHwcgsFBv05apxNC(url,Q9fbtnwCKAN5syS8DPvmX62gHE):
	GWjBrpNhRsmt7eDba1yA4nukS = C2gnJ5tXFk9pAL(url,'url')
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMA400-EPISODES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	LKk0YdTN72XmnMuBbw = PAztbuyYo4Kvd.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	io76Hju84PtJO3hE5x9KZnpGmalIw = PAztbuyYo4Kvd.findall('"series-header".*?src="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if io76Hju84PtJO3hE5x9KZnpGmalIw: HRlygv7YwjzbSLt8fkEerq2 = io76Hju84PtJO3hE5x9KZnpGmalIw[0]
	else: HRlygv7YwjzbSLt8fkEerq2 = nA5dhMRg6ENzsB0l1GwvH7aIr2
	items = []
	JJsF8i76eoYhdjqZ1Qg0lRKAHv9S = False
	if LKk0YdTN72XmnMuBbw and not Q9fbtnwCKAN5syS8DPvmX62gHE:
		WWU7QJP2tyTRLIfDh0csxbkvX = LKk0YdTN72XmnMuBbw[0]
		items = PAztbuyYo4Kvd.findall('''openCity\(event, '(.*?)'\).*?">(.*?)</button>''',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if not items: items = PAztbuyYo4Kvd.findall('data-serie="(.*?)".*?">(.*?)</',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for Q9fbtnwCKAN5syS8DPvmX62gHE,title in items:
			Q9fbtnwCKAN5syS8DPvmX62gHE = Q9fbtnwCKAN5syS8DPvmX62gHE.strip('#')
			if len(items)>1: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,693,HRlygv7YwjzbSLt8fkEerq2,nA5dhMRg6ENzsB0l1GwvH7aIr2,Q9fbtnwCKAN5syS8DPvmX62gHE)
			else: JJsF8i76eoYhdjqZ1Qg0lRKAHv9S = True
	else: JJsF8i76eoYhdjqZ1Qg0lRKAHv9S = True
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"SeasonsEpisodesMain(.*?</div>).</div>.</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		N5Vbkn2chPGfT3m97Bv1LHKI = PAztbuyYo4Kvd.findall('id="'+Q9fbtnwCKAN5syS8DPvmX62gHE+'"(.*?)</ul>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if not N5Vbkn2chPGfT3m97Bv1LHKI: N5Vbkn2chPGfT3m97Bv1LHKI = PAztbuyYo4Kvd.findall('data-serie="'+Q9fbtnwCKAN5syS8DPvmX62gHE+'"(.*?)</div>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if not N5Vbkn2chPGfT3m97Bv1LHKI: N5Vbkn2chPGfT3m97Bv1LHKI = PAztbuyYo4Kvd.findall('id="Season'+Q9fbtnwCKAN5syS8DPvmX62gHE+'"(.*?)</ul>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if N5Vbkn2chPGfT3m97Bv1LHKI and JJsF8i76eoYhdjqZ1Qg0lRKAHv9S:
			WWU7QJP2tyTRLIfDh0csxbkvX = N5Vbkn2chPGfT3m97Bv1LHKI[0]
			hn2rCExmu5pgejyYOT = PAztbuyYo4Kvd.findall("href='(.*?)'><li><em>(.*?)</span>",WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			if not hn2rCExmu5pgejyYOT: hn2rCExmu5pgejyYOT = PAztbuyYo4Kvd.findall('href="(.*?)".*?<em>(.*?)</span>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			items = []
			for ZylHkumQ8zD0,title in hn2rCExmu5pgejyYOT: items.append((ZylHkumQ8zD0,title,HRlygv7YwjzbSLt8fkEerq2))
			if not items: items = PAztbuyYo4Kvd.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,title,HRlygv7YwjzbSLt8fkEerq2 in items:
				ZylHkumQ8zD0 = ZylHkumQ8zD0.strip('./')
				ZylHkumQ8zD0 = GWjBrpNhRsmt7eDba1yA4nukS+'/'+ZylHkumQ8zD0.strip('/')
				title = title.replace('</em><span>',hSXlxL9iB05c)
				TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,692,HRlygv7YwjzbSLt8fkEerq2)
	return
def lNBcUr8RCn(url):
	ce9zAaVFswSq6lLr82DfQyotGW,AROQUxpWHVXSZ7Elcvdz5mL1JtFYD,HtT6mBGwMaq1o0rybzZ4 = [],[],[]
	KteRnFMjHpBPqNf8 = url.replace('/watch.php','/see.php')
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMA400-PLAY-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"WatchList"(.*?)</div>.</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		ZylHkumQ8zD0 = PAztbuyYo4Kvd.findall('<iframe src="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if ZylHkumQ8zD0:
			ZylHkumQ8zD0 = ZylHkumQ8zD0[0]
			AROQUxpWHVXSZ7Elcvdz5mL1JtFYD.append('?named=__embed')
			ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
		HRpMVv1x5ol9gbsnQquj = PAztbuyYo4Kvd.findall('data-embed-url="(.*?)".*?onclick.*?">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in HRpMVv1x5ol9gbsnQquj:
			title = title.strip(hSXlxL9iB05c)
			if ZylHkumQ8zD0 not in ce9zAaVFswSq6lLr82DfQyotGW:
				AROQUxpWHVXSZ7Elcvdz5mL1JtFYD.append('?named='+title+'__watch')
				ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
		HRpMVv1x5ol9gbsnQquj = PAztbuyYo4Kvd.findall('href="(http.*?)".*?</i>(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in HRpMVv1x5ol9gbsnQquj:
			if ZylHkumQ8zD0 not in ce9zAaVFswSq6lLr82DfQyotGW:
				title = title.strip(CXtugbqhV3)
				AROQUxpWHVXSZ7Elcvdz5mL1JtFYD.append('?named='+title+'__download')
				ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	GP2jb0Bi4DJ85X9qYapMFEdWHT = zip(ce9zAaVFswSq6lLr82DfQyotGW,AROQUxpWHVXSZ7Elcvdz5mL1JtFYD)
	for ZylHkumQ8zD0,name in GP2jb0Bi4DJ85X9qYapMFEdWHT: HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0+name)
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(HtT6mBGwMaq1o0rybzZ4,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	search = search.replace(hSXlxL9iB05c,'+')
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/search.php?keywords='+search
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,'search')
	return
# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'FASELHD2'
headers = {'User-Agent':nA5dhMRg6ENzsB0l1GwvH7aIr2}
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_FH2_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
SAsGubf1jW2Q3p = ['wwe']
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==590: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==591: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,text)
	elif mode==592: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==593: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = SNVTEdvxWujYnGR7J6hACUP(url,text)
	elif mode==599: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	GWjBrpNhRsmt7eDba1yA4nukS = GiqvpBF9xLEdHDr37byJSngeCQ
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',GWjBrpNhRsmt7eDba1yA4nukS,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'FASELHD2-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',GWjBrpNhRsmt7eDba1yA4nukS,599,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'المميزة',GWjBrpNhRsmt7eDba1yA4nukS,591,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'featured1')
	items = PAztbuyYo4Kvd.findall('<strong>(.*?)</strong>.*?href="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	for title,ZylHkumQ8zD0 in items:
		TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,591,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'details1')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('main-menu"(.*?)header-social',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		YD3pS647NlOnqEv1Lox5X9Wi = PAztbuyYo4Kvd.findall('<li (.*?)</li>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for K3WkBTmPE0Yynt5baRhA2ILHsOZwC9 in YD3pS647NlOnqEv1Lox5X9Wi:
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?>(.*?)<',K3WkBTmPE0Yynt5baRhA2ILHsOZwC9,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,title in items:
				if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = GWjBrpNhRsmt7eDba1yA4nukS+ZylHkumQ8zD0
				TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,591,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'details2')
	return kl2ZWdy8rXcHT
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,type=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'FASELHD2-TITLES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	GZO3KcmHC904hQWAFuqdrgvVpaLI = 0
	N5Vbkn2chPGfT3m97Bv1LHKI = PAztbuyYo4Kvd.findall('"archive-slider(.*?)<h4>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if N5Vbkn2chPGfT3m97Bv1LHKI: YERWNbgAThV2uBr5taO8zcd = N5Vbkn2chPGfT3m97Bv1LHKI[0]
	else: YERWNbgAThV2uBr5taO8zcd = nA5dhMRg6ENzsB0l1GwvH7aIr2
	if type=='featured1':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"slider-carousel"(.*?)</container>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall(' src="(.*?)".*?"slider-title">(.*?)<.*?<a href="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		YqUzIsN4oSOlVuhEiG2keyFj3,FwAWKXTqvQiL98jeJ2,HRpMVv1x5ol9gbsnQquj = zip(*items)
		items = zip(HRpMVv1x5ol9gbsnQquj,YqUzIsN4oSOlVuhEiG2keyFj3,FwAWKXTqvQiL98jeJ2)
	elif type=='featured2':
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',YERWNbgAThV2uBr5taO8zcd,PAztbuyYo4Kvd.DOTALL)
	elif type=='filters':
		zz3eHskxE6lAyDR5cNj1ug = [kl2ZWdy8rXcHT.replace('\\/','/').replace('\\"','"')]
	elif type=='details2' and 'href' in YERWNbgAThV2uBr5taO8zcd:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('<h4>(.*?)</h4>(.*?)</container>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'مميزة',url,591,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'featured2')
		title = zz3eHskxE6lAyDR5cNj1ug[0][0]
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,591,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'details3')
		return
	else:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('<h4>(.*?)</h4>(.*?)</container>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		title,WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	hdocEkRK0Q = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	u0UiTmzYN6I3Q9eCZVoB = []
	for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
		if any(value in title.lower() for value in SAsGubf1jW2Q3p): continue
		title = title.strip(hSXlxL9iB05c)
		title = HH8SJuswDBPtniebmkXIr(title)
		JfNHOP2BK1Yxl7Rq4 = PAztbuyYo4Kvd.findall('(.*?) (الحلقة|حلقة).\d+',title,PAztbuyYo4Kvd.DOTALL)
		if '/movseries/' in ZylHkumQ8zD0:
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,591,HRlygv7YwjzbSLt8fkEerq2)
		elif JfNHOP2BK1Yxl7Rq4 and type==nA5dhMRg6ENzsB0l1GwvH7aIr2:
			title = '_MOD_'+JfNHOP2BK1Yxl7Rq4[0][0]
			if title not in u0UiTmzYN6I3Q9eCZVoB:
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,593,HRlygv7YwjzbSLt8fkEerq2)
				u0UiTmzYN6I3Q9eCZVoB.append(title)
		elif any(value in title for value in hdocEkRK0Q):
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,592,HRlygv7YwjzbSLt8fkEerq2)
		else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,593,HRlygv7YwjzbSLt8fkEerq2)
	if type=='filters':
		D7XvWdzLEB2SNCb5eHuPx41G3Qs9o = PAztbuyYo4Kvd.findall('"more_button_page":(.*?),',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		if D7XvWdzLEB2SNCb5eHuPx41G3Qs9o:
			count = D7XvWdzLEB2SNCb5eHuPx41G3Qs9o[0]
			ZylHkumQ8zD0 = url+'/offset/'+count
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة أخرى',ZylHkumQ8zD0,591,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filters')
	elif 'details' in type:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="pagination(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,title in items:
				title = 'صفحة '+HH8SJuswDBPtniebmkXIr(title)
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,591,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'details4')
	return
def SNVTEdvxWujYnGR7J6hACUP(url,type=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'FASELHD2-SEASONS_EPISODES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	wWeVHSMqxGR = False
	if not type:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('<seasons(.*?)</seasons>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3>(.*?)</h3>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			if len(items)>1:
				GWjBrpNhRsmt7eDba1yA4nukS = C2gnJ5tXFk9pAL(url,'url')
				wWeVHSMqxGR = True
				for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
					title = HH8SJuswDBPtniebmkXIr(title)
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,593,HRlygv7YwjzbSLt8fkEerq2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'episodes')
	if type=='episodes' or not wWeVHSMqxGR:
		io76Hju84PtJO3hE5x9KZnpGmalIw = PAztbuyYo4Kvd.findall('<bkز*?image:url\((.*?)\)"></bk>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if io76Hju84PtJO3hE5x9KZnpGmalIw: HRlygv7YwjzbSLt8fkEerq2 = io76Hju84PtJO3hE5x9KZnpGmalIw[0]
		else: HRlygv7YwjzbSLt8fkEerq2 = nA5dhMRg6ENzsB0l1GwvH7aIr2
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('<all-episodes(.*?)</all-episodes>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?>(.*?)</a>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,title in items:
				title = title.strip(hSXlxL9iB05c)
				title = HH8SJuswDBPtniebmkXIr(title)
				TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,592,HRlygv7YwjzbSLt8fkEerq2)
	return
def lNBcUr8RCn(url):
	HtT6mBGwMaq1o0rybzZ4,s38m4cjvSr1Zwhu,xYyKaz0tHoiB5J = [],[],[]
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'FASELHD2-PLAY-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	N9Ro3qPYHMmz8 = PAztbuyYo4Kvd.findall('العمر :.*?<strong">(.*?)</strong>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if N9Ro3qPYHMmz8 and g4gUOtGiVkoNuaBrHhx8L(wgj0rX5tbcxPulhmny,url,N9Ro3qPYHMmz8): return
	ZylHkumQ8zD0 = PAztbuyYo4Kvd.findall('<iframe src="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if ZylHkumQ8zD0:
		ZylHkumQ8zD0 = ZylHkumQ8zD0[0]
		HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0+'?named=__embed')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('<slice-title(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('data-url="(.*?)".*?</i>(.*?)</li>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,name in items:
			name = name.strip(hSXlxL9iB05c)
			HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0+'?named='+name+'__watch')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('<downloads(.*?)</downloads>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?</div>(.*?)</div>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,name in items:
			HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0+'?named='+name+'__download')
	for wn15Sg8FDXiCNGIOb43WEHYhyPl in HtT6mBGwMaq1o0rybzZ4:
		ZylHkumQ8zD0,name = wn15Sg8FDXiCNGIOb43WEHYhyPl.split('?named')
		if ZylHkumQ8zD0 not in s38m4cjvSr1Zwhu:
			s38m4cjvSr1Zwhu.append(ZylHkumQ8zD0)
			xYyKaz0tHoiB5J.append(wn15Sg8FDXiCNGIOb43WEHYhyPl)
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(xYyKaz0tHoiB5J,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	search = search.replace(hSXlxL9iB05c,'+')
	GWjBrpNhRsmt7eDba1yA4nukS = GiqvpBF9xLEdHDr37byJSngeCQ
	url = GWjBrpNhRsmt7eDba1yA4nukS+'/?s='+search
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,'details5')
	return
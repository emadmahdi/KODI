# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'DAILYMOTION'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_DLM_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
Ega71ZGOcjfw = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][1]
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text,type,Q0f7ytucSriRw8HTzd):
	if	 mode==400: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==401: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = FF4HqV0fQiT(url,text)
	elif mode==402: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = MzRoiNw5Bxq91lYaD(url,text)
	elif mode==403: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url,text)
	elif mode==404: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = Zzsbqp1dToaODw8(text,Q0f7ytucSriRw8HTzd)
	elif mode==405: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = iVMWBC7qoGvz2nF8gO(text,Q0f7ytucSriRw8HTzd)
	elif mode==406: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = R0RJjXnpMKO53fbkrS6QyZIUhP(text,Q0f7ytucSriRw8HTzd)
	elif mode==407: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = JS9UgBHs2Q(url,Q0f7ytucSriRw8HTzd)
	elif mode==408: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = K27NDywhtmzlb65FGWMkVeEQjY(url,Q0f7ytucSriRw8HTzd)
	elif mode==409: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text,Q0f7ytucSriRw8HTzd)
	elif mode==411: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = b0f1x75XyhOrTJDKiLEV(url,text)
	elif mode==414: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = bkvxjcqUs2m5(text)
	elif mode==415: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = pJqnQ1UKZlm(text,Q0f7ytucSriRw8HTzd)
	elif mode==416: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = CnMQesZ5tPDIRN3wOFfTh81gko(text,Q0f7ytucSriRw8HTzd)
	elif mode==417: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = Egf5Bw23H1ZQ7OIhTJery4Vj(url,Q0f7ytucSriRw8HTzd)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الرئيسية',nA5dhMRg6ENzsB0l1GwvH7aIr2,414)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,409,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث عن فيديوهات',nA5dhMRg6ENzsB0l1GwvH7aIr2,409,nA5dhMRg6ENzsB0l1GwvH7aIr2,'videos?sortBy=','_REMEMBERRESULTS_')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث عن آخر الفيديوهات',nA5dhMRg6ENzsB0l1GwvH7aIr2,409,nA5dhMRg6ENzsB0l1GwvH7aIr2,'videos?sortBy=RECENT','_REMEMBERRESULTS_')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث عن الفيديوهات الأكثر مشاهدة',nA5dhMRg6ENzsB0l1GwvH7aIr2,409,nA5dhMRg6ENzsB0l1GwvH7aIr2,'videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث عن قوائم التشغيل',nA5dhMRg6ENzsB0l1GwvH7aIr2,409,nA5dhMRg6ENzsB0l1GwvH7aIr2,'playlists','_REMEMBERRESULTS_')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث عن مستخدم',nA5dhMRg6ENzsB0l1GwvH7aIr2,409,nA5dhMRg6ENzsB0l1GwvH7aIr2,'channels','_REMEMBERRESULTS_')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث عن بث حي',nA5dhMRg6ENzsB0l1GwvH7aIr2,409,nA5dhMRg6ENzsB0l1GwvH7aIr2,'lives','_REMEMBERRESULTS_')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث عن هاشتاك',nA5dhMRg6ENzsB0l1GwvH7aIr2,409,nA5dhMRg6ENzsB0l1GwvH7aIr2,'hashtags','_REMEMBERRESULTS_')
	return
def MzRoiNw5Bxq91lYaD(url,YVbZB31aSgojx8):
	if '/dm_' in url:
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,False,nA5dhMRg6ENzsB0l1GwvH7aIr2,'DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = Y3SmVGbfNvEeakMBr.headers
		if 'Location' in list(headers.keys()): url = GiqvpBF9xLEdHDr37byJSngeCQ+headers['Location']
	YVbZB31aSgojx8 = bbTCMJwEx8nhN4X+YVbZB31aSgojx8+NwROdSj3nsA
	YVbZB31aSgojx8 = e9tFVyMoR3spHNXvQkYnLDuW6(YVbZB31aSgojx8)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+':: بث حي',url,411,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'channel_lives_now')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+':: آخر الفيديوهات',url+'/videos',408)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+':: المميزة',url,411,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'channel_featured_videos')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+':: قوائم التشغيل',url+'/playlists',407)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+':: قنوات ذات صلة',url,411,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'channel_related_channel')
	return
def e9tFVyMoR3spHNXvQkYnLDuW6(title):
	title = title.rstrip('\\').strip(hSXlxL9iB05c).replace('\\\\','\\')
	title = jPgzFLH1niJpE2r(title)
	return title
def lNBcUr8RCn(url,f3CI9uLoNmRdptSG8Zs):
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM([url],wgj0rX5tbcxPulhmny,'video',url)
	return
def Zzsbqp1dToaODw8(search,Q0f7ytucSriRw8HTzd=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if Q0f7ytucSriRw8HTzd==nA5dhMRg6ENzsB0l1GwvH7aIr2: Q0f7ytucSriRw8HTzd = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = nA5dhMRg6ENzsB0l1GwvH7aIr2
	search = search.split('/videos')[0]
	YsdSH10ta6wvi4nMRIO9 = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mysearchwords',search)
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mypagelimit','40')
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mypagenumber',Q0f7ytucSriRw8HTzd)
	if sort==nA5dhMRg6ENzsB0l1GwvH7aIr2: YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mysortmethod',nA5dhMRg6ENzsB0l1GwvH7aIr2)
	else: YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/search/'+search+'/videos'
	kl2ZWdy8rXcHT = ccRYh7QKHzZtPMp45sdJmyCAn3wV8v(YsdSH10ta6wvi4nMRIO9,search)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"videos"(.*?)"VideoConnection"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('"node":.*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for id,title,JJFy5ZMVOXjLCoxzQcNmYDekb8pd,YVbZB31aSgojx8,yoaKx7FtIlvcD,HRlygv7YwjzbSLt8fkEerq2 in items:
			HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2.replace('\/','/')
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/video/'+id
			title = e9tFVyMoR3spHNXvQkYnLDuW6(title)
			f3CI9uLoNmRdptSG8Zs = JJFy5ZMVOXjLCoxzQcNmYDekb8pd+'::'+YVbZB31aSgojx8
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,403,HRlygv7YwjzbSLt8fkEerq2,yoaKx7FtIlvcD,f3CI9uLoNmRdptSG8Zs)
		if '"hasNextPage":true' in kl2ZWdy8rXcHT:
			Q0f7ytucSriRw8HTzd = str(int(Q0f7ytucSriRw8HTzd)+1)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+Q0f7ytucSriRw8HTzd,url,404,nA5dhMRg6ENzsB0l1GwvH7aIr2,Q0f7ytucSriRw8HTzd,search)
	return
def iVMWBC7qoGvz2nF8gO(search,Q0f7ytucSriRw8HTzd=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if Q0f7ytucSriRw8HTzd==nA5dhMRg6ENzsB0l1GwvH7aIr2: Q0f7ytucSriRw8HTzd = '1'
	YsdSH10ta6wvi4nMRIO9 = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mysearchwords',search)
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mypagelimit','40')
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mypagenumber',Q0f7ytucSriRw8HTzd)
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/search/'+search+'/playlists'
	kl2ZWdy8rXcHT = ccRYh7QKHzZtPMp45sdJmyCAn3wV8v(YsdSH10ta6wvi4nMRIO9,search)
	items = PAztbuyYo4Kvd.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",.*?"total":(.*?),"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	for id,name,h0rt7YJ2AQ81jTVxF3LPZIuOyD4,JJFy5ZMVOXjLCoxzQcNmYDekb8pd,YVbZB31aSgojx8,HRlygv7YwjzbSLt8fkEerq2,count in items:
		HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2.replace('\/','/')
		ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = e9tFVyMoR3spHNXvQkYnLDuW6(title)
		f3CI9uLoNmRdptSG8Zs = JJFy5ZMVOXjLCoxzQcNmYDekb8pd+'::'+YVbZB31aSgojx8
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,401,HRlygv7YwjzbSLt8fkEerq2,nA5dhMRg6ENzsB0l1GwvH7aIr2,f3CI9uLoNmRdptSG8Zs)
	if '"hasNextPage":true' in kl2ZWdy8rXcHT:
		Q0f7ytucSriRw8HTzd = str(int(Q0f7ytucSriRw8HTzd)+1)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+Q0f7ytucSriRw8HTzd,url,405,nA5dhMRg6ENzsB0l1GwvH7aIr2,Q0f7ytucSriRw8HTzd,search)
	return
def R0RJjXnpMKO53fbkrS6QyZIUhP(search,Q0f7ytucSriRw8HTzd=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if Q0f7ytucSriRw8HTzd==nA5dhMRg6ENzsB0l1GwvH7aIr2: Q0f7ytucSriRw8HTzd = '1'
	YsdSH10ta6wvi4nMRIO9 = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mysearchwords',search)
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mypagelimit','40')
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mypagenumber',Q0f7ytucSriRw8HTzd)
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/search/'+search+'/channels'
	kl2ZWdy8rXcHT = ccRYh7QKHzZtPMp45sdJmyCAn3wV8v(YsdSH10ta6wvi4nMRIO9,search)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"channels"(.*?)"ChannelConnection"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('"node".*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for id,name,HRlygv7YwjzbSLt8fkEerq2 in items:
			HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2.replace('\/','/')
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+id
			title = 'USER:  '+name
			title = e9tFVyMoR3spHNXvQkYnLDuW6(title)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,402,HRlygv7YwjzbSLt8fkEerq2,nA5dhMRg6ENzsB0l1GwvH7aIr2,name)
		if '"hasNextPage":true' in kl2ZWdy8rXcHT:
			Q0f7ytucSriRw8HTzd = str(int(Q0f7ytucSriRw8HTzd)+1)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+Q0f7ytucSriRw8HTzd,url,406,nA5dhMRg6ENzsB0l1GwvH7aIr2,Q0f7ytucSriRw8HTzd,search)
	return
def bkvxjcqUs2m5(pvHi04K3N8Xwt1BA7uQVFgbsC):
	YsdSH10ta6wvi4nMRIO9 = '''{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  thumbnail: coverURL(size: \\"x532\\")  coverURL: coverURL(size: \\"x532\\")  isFollowed  whitelistStatus {    id    isWhitelisted    __typename  }  __typename}query HOME_QUERY($space: String!) {  home: views {    id    neon {      id      sections(space: $space) {        edges {          node {            id            name            title            description            groupingType            type            relatedComponent {              __typename              ... on Collection {                id                xid                __typename              }              ... on Channel {                id                xid                name                displayName                logoURL(size: \\"x60\\")                __typename              }              ... on Topic {                id                __typename                ...TOPIC_BASE_FRAG              }            }            components {              edges {                node {                  __typename                  ... on Video {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    description                    duration                    __typename                  }                  ... on Live {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    startAt                    __typename                  }                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	sLdQxt1cymXejrf = ccRYh7QKHzZtPMp45sdJmyCAn3wV8v(YsdSH10ta6wvi4nMRIO9)
	if sLdQxt1cymXejrf:
		oybU5lgN98AxMJ3DkYEVBac60uwO = BwGPDSQOlfUas2n3eIH0ycFRWZ('dict',sLdQxt1cymXejrf)
		XA4gRkJDnBEqMma9hdwlI76vzF0 = oybU5lgN98AxMJ3DkYEVBac60uwO['data']['home']['neon']['sections']['edges']
		if not pvHi04K3N8Xwt1BA7uQVFgbsC:
			X5XlteU7ATYxNLrjwRvHMkq = []
			for iOCV9hPk0bANm642cl1 in XA4gRkJDnBEqMma9hdwlI76vzF0:
				gbix8W9vyoDLZQUtqu2w36X = iOCV9hPk0bANm642cl1['node']['title']
				if gbix8W9vyoDLZQUtqu2w36X not in X5XlteU7ATYxNLrjwRvHMkq: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+gbix8W9vyoDLZQUtqu2w36X,nA5dhMRg6ENzsB0l1GwvH7aIr2,414,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,gbix8W9vyoDLZQUtqu2w36X)
				X5XlteU7ATYxNLrjwRvHMkq.append(gbix8W9vyoDLZQUtqu2w36X)
		else:
			for iOCV9hPk0bANm642cl1 in XA4gRkJDnBEqMma9hdwlI76vzF0:
				gbix8W9vyoDLZQUtqu2w36X = iOCV9hPk0bANm642cl1['node']['title']
				if gbix8W9vyoDLZQUtqu2w36X==pvHi04K3N8Xwt1BA7uQVFgbsC:
					LLfUyiBmeKlj3 = iOCV9hPk0bANm642cl1['node']['components']['edges']
					for r7y9lt5bA6YhLKGHWe in LLfUyiBmeKlj3:
						yoaKx7FtIlvcD = str(r7y9lt5bA6YhLKGHWe['node']['duration'])
						title = jPgzFLH1niJpE2r(r7y9lt5bA6YhLKGHWe['node']['title'])
						title = title.replace('\/','/')
						QnK8G3NsVklupv = r7y9lt5bA6YhLKGHWe['node']['xid']
						HRlygv7YwjzbSLt8fkEerq2 = r7y9lt5bA6YhLKGHWe['node']['thumbnailx480']
						HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2.replace('\/','/')
						ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/video/'+QnK8G3NsVklupv
						TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,403,HRlygv7YwjzbSLt8fkEerq2,yoaKx7FtIlvcD)
	return
def pJqnQ1UKZlm(search,Q0f7ytucSriRw8HTzd=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if Q0f7ytucSriRw8HTzd==nA5dhMRg6ENzsB0l1GwvH7aIr2: Q0f7ytucSriRw8HTzd = '1'
	YsdSH10ta6wvi4nMRIO9 = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }  ... on Live {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          xid          title          thumbnail: thumbnailURL(size: \\"x240\\")          thumbnailx60: thumbnailURL(size: \\"x60\\")          thumbnailx120: thumbnailURL(size: \\"x120\\")          thumbnailx240: thumbnailURL(size: \\"x240\\")          thumbnailx720: thumbnailURL(size: \\"x720\\")          audienceCount          aspectRatio          isOnAir          channel {            id            xid            name            displayName            accountType            __typename          }          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mysearchwords',search)
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mypagelimit','40')
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mypagenumber',Q0f7ytucSriRw8HTzd)
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/search/'+search+'/lives'
	sLdQxt1cymXejrf = ccRYh7QKHzZtPMp45sdJmyCAn3wV8v(YsdSH10ta6wvi4nMRIO9,search)
	if sLdQxt1cymXejrf:
		oybU5lgN98AxMJ3DkYEVBac60uwO = BwGPDSQOlfUas2n3eIH0ycFRWZ('dict',sLdQxt1cymXejrf)
		try: XA4gRkJDnBEqMma9hdwlI76vzF0 = oybU5lgN98AxMJ3DkYEVBac60uwO['data']['search']['lives']['edges']
		except: XA4gRkJDnBEqMma9hdwlI76vzF0 = []
		for iOCV9hPk0bANm642cl1 in XA4gRkJDnBEqMma9hdwlI76vzF0:
			name = iOCV9hPk0bANm642cl1['node']['title']
			name = jPgzFLH1niJpE2r(name)
			QnK8G3NsVklupv = iOCV9hPk0bANm642cl1['node']['xid']
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/video/'+QnK8G3NsVklupv
			TBt8bUDo9WhL('live',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'LIVE: '+name,ZylHkumQ8zD0,403)
		if '"hasNextPage":true' in sLdQxt1cymXejrf:
			Q0f7ytucSriRw8HTzd = str(int(Q0f7ytucSriRw8HTzd)+1)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+Q0f7ytucSriRw8HTzd,url,415,nA5dhMRg6ENzsB0l1GwvH7aIr2,Q0f7ytucSriRw8HTzd,search)
	return
def jWtMagZmfd654KbD0roBlFx(search,Q0f7ytucSriRw8HTzd=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if Q0f7ytucSriRw8HTzd==nA5dhMRg6ENzsB0l1GwvH7aIr2: Q0f7ytucSriRw8HTzd = '1'
	YsdSH10ta6wvi4nMRIO9 = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    isInWatchLater    __typename  }  ... on Live {    id    isInWatchLater    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mysearchwords',search)
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mypagelimit','40')
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mypagenumber',Q0f7ytucSriRw8HTzd)
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/search/'+search+'/topics'
	sLdQxt1cymXejrf = ccRYh7QKHzZtPMp45sdJmyCAn3wV8v(YsdSH10ta6wvi4nMRIO9,search)
	if sLdQxt1cymXejrf:
		oybU5lgN98AxMJ3DkYEVBac60uwO = BwGPDSQOlfUas2n3eIH0ycFRWZ('dict',sLdQxt1cymXejrf)
		try: XA4gRkJDnBEqMma9hdwlI76vzF0 = oybU5lgN98AxMJ3DkYEVBac60uwO['data']['search']['topics']['edges']
		except: XA4gRkJDnBEqMma9hdwlI76vzF0 = []
		for iOCV9hPk0bANm642cl1 in XA4gRkJDnBEqMma9hdwlI76vzF0:
			name = iOCV9hPk0bANm642cl1['node']['name']
			QnK8G3NsVklupv = iOCV9hPk0bANm642cl1['node']['xid']
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/topic/'+QnK8G3NsVklupv
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'TOPIC: '+name,ZylHkumQ8zD0,413)
		if '"hasNextPage":true' in sLdQxt1cymXejrf:
			Q0f7ytucSriRw8HTzd = str(int(Q0f7ytucSriRw8HTzd)+1)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+Q0f7ytucSriRw8HTzd,url,412,nA5dhMRg6ENzsB0l1GwvH7aIr2,Q0f7ytucSriRw8HTzd,search)
	return
def TUOYsLzNCGSP(url,Q0f7ytucSriRw8HTzd=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if Q0f7ytucSriRw8HTzd==nA5dhMRg6ENzsB0l1GwvH7aIr2: Q0f7ytucSriRw8HTzd = '1'
	QnK8G3NsVklupv = url.split('/')[-1]
	YsdSH10ta6wvi4nMRIO9 = '''{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {  id  xid  title  duration  isLiked  isInWatchLater  isCreatedForKids  createdAt  isExplicit  videoHeight: height  videoWidth: width  category  channel {    id    xid    name    displayName    logoURLx25: logoURL(size: \\"x25\\")    logoURL(size: \\"x60\\")    accountType    __typename  }  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  aspectRatio  isPublished  __typename}query DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {  topic(xid: $xid) {    id    xid    name    videos(sort: \\"recent\\", first: 30, page: $page) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...TOPIC_VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mytopicid',QnK8G3NsVklupv)
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mypagenumber',Q0f7ytucSriRw8HTzd)
	sLdQxt1cymXejrf = ccRYh7QKHzZtPMp45sdJmyCAn3wV8v(YsdSH10ta6wvi4nMRIO9)
	if sLdQxt1cymXejrf:
		oybU5lgN98AxMJ3DkYEVBac60uwO = BwGPDSQOlfUas2n3eIH0ycFRWZ('dict',sLdQxt1cymXejrf)
		XA4gRkJDnBEqMma9hdwlI76vzF0 = oybU5lgN98AxMJ3DkYEVBac60uwO['data']['topic']['videos']['edges']
		for iOCV9hPk0bANm642cl1 in XA4gRkJDnBEqMma9hdwlI76vzF0:
			yoaKx7FtIlvcD = str(iOCV9hPk0bANm642cl1['node']['duration'])
			title = jPgzFLH1niJpE2r(iOCV9hPk0bANm642cl1['node']['title'])
			title = title.replace('\/','/')
			QnK8G3NsVklupv = iOCV9hPk0bANm642cl1['node']['xid']
			HRlygv7YwjzbSLt8fkEerq2 = iOCV9hPk0bANm642cl1['node']['thumbnailx480']
			HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2.replace('\/','/')
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/video/'+QnK8G3NsVklupv
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,403,HRlygv7YwjzbSLt8fkEerq2,yoaKx7FtIlvcD)
		if '"hasNextPage":true' in sLdQxt1cymXejrf:
			Q0f7ytucSriRw8HTzd = str(int(Q0f7ytucSriRw8HTzd)+1)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+Q0f7ytucSriRw8HTzd,url,413,nA5dhMRg6ENzsB0l1GwvH7aIr2,Q0f7ytucSriRw8HTzd)
	return
def FF4HqV0fQiT(url,f3CI9uLoNmRdptSG8Zs):
	id = url.split('/')[-1]
	JJFy5ZMVOXjLCoxzQcNmYDekb8pd,YVbZB31aSgojx8 = f3CI9uLoNmRdptSG8Zs.split('::',1)
	ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+JJFy5ZMVOXjLCoxzQcNmYDekb8pd
	YVbZB31aSgojx8 = e9tFVyMoR3spHNXvQkYnLDuW6(YVbZB31aSgojx8)
	title = bbTCMJwEx8nhN4X+'OWNER:  '+YVbZB31aSgojx8+NwROdSj3nsA
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,402,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,YVbZB31aSgojx8)
	YsdSH10ta6wvi4nMRIO9 = '''{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {  views {    id    neon {      id      sections(device: $device, space: \\"watching\\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {        edges {          node {            id            name            groupingType            relatedComponent {              ... on Channel {                __typename                id                xid                name                displayName                logoURL(size: \\"x60\\")                logoURLx25: logoURL(size: \\"x25\\")              }              ... on Topic {                __typename                id                xid                name                names {                  edges {                    node {                      id                      name                      language {                        id                        codeAlpha2                        __typename                      }                      __typename                    }                    __typename                  }                  __typename                }              }              ... on Collection {                __typename                id                xid                name              }              __typename            }            components(first: $videoCountPerSection) {              metadata {                algorithm {                  name                  version                  uuid                  __typename                }                __typename              }              edges {                node {                  ... on Video {                    __typename                    id                    xid                    title                    duration                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    channel {                      id                      xid                      accountType                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      logoURL(size: \\"x60\\")                      __typename                    }                  }                  ... on Channel {                    __typename                    id                    xid                    name                    displayName                    accountType                    logoURL(size: \\"x60\\")                  }                  __typename                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('myplaylistid',id)
	kl2ZWdy8rXcHT = ccRYh7QKHzZtPMp45sdJmyCAn3wV8v(YsdSH10ta6wvi4nMRIO9)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"collection_videos"(.*?)"SectionEdge"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",.*?"xid":"(.*?)",.*?"displayName":"(.*?)",',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for id,title,yoaKx7FtIlvcD,HRlygv7YwjzbSLt8fkEerq2,JJFy5ZMVOXjLCoxzQcNmYDekb8pd,YVbZB31aSgojx8 in items:
			HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2.replace('\/','/')
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/video/'+id
			title = e9tFVyMoR3spHNXvQkYnLDuW6(title)
			f3CI9uLoNmRdptSG8Zs = JJFy5ZMVOXjLCoxzQcNmYDekb8pd+'::'+YVbZB31aSgojx8
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,403,HRlygv7YwjzbSLt8fkEerq2,yoaKx7FtIlvcD,f3CI9uLoNmRdptSG8Zs)
	return
def K27NDywhtmzlb65FGWMkVeEQjY(url,Q0f7ytucSriRw8HTzd=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if Q0f7ytucSriRw8HTzd==nA5dhMRg6ENzsB0l1GwvH7aIr2: Q0f7ytucSriRw8HTzd = '1'
	xhqyQAmiYa6FwRM4DO21Jvj = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	YsdSH10ta6wvi4nMRIO9 = '''{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbURLx240: thumbnailURL(size: \\"x240\\")  thumbURLx360: thumbnailURL(size: \\"x360\\")  thumbURLx480: thumbnailURL(size: \\"x480\\")  thumbURLx720: thumbnailURL(size: \\"x720\\")  __typename}query CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mychannelid',xhqyQAmiYa6FwRM4DO21Jvj)
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mypagelimit','40')
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mypagenumber',Q0f7ytucSriRw8HTzd)
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mysortmethod',sort)
	kl2ZWdy8rXcHT = ccRYh7QKHzZtPMp45sdJmyCAn3wV8v(YsdSH10ta6wvi4nMRIO9)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbURLx240":"(.*?)",',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for id,title,yoaKx7FtIlvcD,JJFy5ZMVOXjLCoxzQcNmYDekb8pd,YVbZB31aSgojx8,HRlygv7YwjzbSLt8fkEerq2 in items:
			HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2.replace('\/','/')
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/video/'+id
			title = e9tFVyMoR3spHNXvQkYnLDuW6(title)
			f3CI9uLoNmRdptSG8Zs = JJFy5ZMVOXjLCoxzQcNmYDekb8pd+'::'+YVbZB31aSgojx8
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,403,HRlygv7YwjzbSLt8fkEerq2,yoaKx7FtIlvcD,f3CI9uLoNmRdptSG8Zs)
		if '"hasNextPage":true' in kl2ZWdy8rXcHT:
			Q0f7ytucSriRw8HTzd = str(int(Q0f7ytucSriRw8HTzd)+1)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+Q0f7ytucSriRw8HTzd,url,408,nA5dhMRg6ENzsB0l1GwvH7aIr2,Q0f7ytucSriRw8HTzd)
	return
def JS9UgBHs2Q(url,Q0f7ytucSriRw8HTzd=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if Q0f7ytucSriRw8HTzd==nA5dhMRg6ENzsB0l1GwvH7aIr2: Q0f7ytucSriRw8HTzd = '1'
	xhqyQAmiYa6FwRM4DO21Jvj = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	YsdSH10ta6wvi4nMRIO9 = '''{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}query CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          xid          updatedAt          name          description          thumbURLx240: thumbnailURL(size: \\"x240\\")          thumbURLx360: thumbnailURL(size: \\"x360\\")          thumbURLx480: thumbnailURL(size: \\"x480\\")          stats {            videos {              total              __typename            }            __typename          }          channel {            id            ...CHANNEL_FRAGMENT            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mychannelid',xhqyQAmiYa6FwRM4DO21Jvj)
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mypagelimit','40')
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mypagenumber',Q0f7ytucSriRw8HTzd)
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mysortmethod',sort)
	kl2ZWdy8rXcHT = ccRYh7QKHzZtPMp45sdJmyCAn3wV8v(YsdSH10ta6wvi4nMRIO9)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"thumbURLx240":"(.*?)",.*?"total":(.*?),".*?xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for id,name,HRlygv7YwjzbSLt8fkEerq2,count,h0rt7YJ2AQ81jTVxF3LPZIuOyD4,JJFy5ZMVOXjLCoxzQcNmYDekb8pd,YVbZB31aSgojx8 in items:
			HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2.replace('\/','/')
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = e9tFVyMoR3spHNXvQkYnLDuW6(title)
			f3CI9uLoNmRdptSG8Zs = JJFy5ZMVOXjLCoxzQcNmYDekb8pd+'::'+YVbZB31aSgojx8
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,401,HRlygv7YwjzbSLt8fkEerq2,nA5dhMRg6ENzsB0l1GwvH7aIr2,f3CI9uLoNmRdptSG8Zs)
		if '"hasNextPage":true' in kl2ZWdy8rXcHT:
			Q0f7ytucSriRw8HTzd = str(int(Q0f7ytucSriRw8HTzd)+1)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+Q0f7ytucSriRw8HTzd,url,407,nA5dhMRg6ENzsB0l1GwvH7aIr2,Q0f7ytucSriRw8HTzd)
	return
def b0f1x75XyhOrTJDKiLEV(url,N7uzjHXWd0TlqGS65Ft3JPcRyYrm):
	xhqyQAmiYa6FwRM4DO21Jvj = url.split('/')[3]
	YsdSH10ta6wvi4nMRIO9 = '''{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  __typename}fragment LIVE_FRAGMENT on Live {  id  xid  title  startAt  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment CHANNEL_MAIN_FRAGMENT on Channel {  id  xid  name  displayName  description  accountType  isArtist  logoURL(size: \\"x60\\")  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  isFollowed  tagline  country {    id    codeAlpha2    __typename  }  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  externalLinks {    id    facebookURL    twitterURL    websiteURL    instagramURL    pinterestURL    __typename  }  channel_lives_now: lives(first: 4, isOnAir: true) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_lives_scheduled: lives(first: 4, startIn: 7200) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_featured_videos: videos(first: 4, isFeatured: true) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_all_videos: videos(first: 4) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_most_viewed: videos(first: 4, sort: \\"visited\\") {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_collections: collections(first: 4) {    edges {      node {        id        xid        name        description        stats {          id          videos {            id            total            __typename          }          __typename        }        thumbnailx240: thumbnailURL(size: \\"x240\\")        thumbnailx360: thumbnailURL(size: \\"x360\\")        thumbnailx480: thumbnailURL(size: \\"x480\\")        channel {          id          ...CHANNEL_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }  channel_related_channel: networkChannels(    hasPublicVideos: true    first: $relatedChannels  ) {    edges {      node {        id        ...CHANNEL_FRAGMENT        __typename      }      __typename    }    __typename  }  __typename}query CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {  channel(name: $channel_name) {    id    ...CHANNEL_MAIN_FRAGMENT    __typename  }}"}'''
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mychannelid',xhqyQAmiYa6FwRM4DO21Jvj)
	kl2ZWdy8rXcHT = ccRYh7QKHzZtPMp45sdJmyCAn3wV8v(YsdSH10ta6wvi4nMRIO9)
	ROsySt8U0lEBVIN45GoDXrPxQ9ahpf = DcFpQN9gqn.loads(kl2ZWdy8rXcHT)
	try: items = ROsySt8U0lEBVIN45GoDXrPxQ9ahpf['data']['channel'][N7uzjHXWd0TlqGS65Ft3JPcRyYrm]['edges']
	except: items = []
	if not items: TBt8bUDo9WhL('link',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'لا توجد نتائج',nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	else:
		for CQtNwXGVAJ2y5nBY in items:
			aJxFZOUmE70yAiXGHlNhnLIo5 = CQtNwXGVAJ2y5nBY['node']
			QnK8G3NsVklupv = aJxFZOUmE70yAiXGHlNhnLIo5['xid']
			keys = list(aJxFZOUmE70yAiXGHlNhnLIo5.keys())
			PPs8wYzAVgytCGQE1rHvXJF576qRTe = aJxFZOUmE70yAiXGHlNhnLIo5['__typename'].lower()
			if PPs8wYzAVgytCGQE1rHvXJF576qRTe=='channel':
				name = aJxFZOUmE70yAiXGHlNhnLIo5['name']
				VsIe8Yrx3HJlZSE = aJxFZOUmE70yAiXGHlNhnLIo5['displayName']
				title = 'USER:  '+VsIe8Yrx3HJlZSE
				HRlygv7YwjzbSLt8fkEerq2 = aJxFZOUmE70yAiXGHlNhnLIo5['coverURLx375']
			else:
				name = aJxFZOUmE70yAiXGHlNhnLIo5['channel']['name']
				VsIe8Yrx3HJlZSE = aJxFZOUmE70yAiXGHlNhnLIo5['channel']['displayName']
				title = aJxFZOUmE70yAiXGHlNhnLIo5['title']
				HRlygv7YwjzbSLt8fkEerq2 = aJxFZOUmE70yAiXGHlNhnLIo5['thumbnailx360']
				if PPs8wYzAVgytCGQE1rHvXJF576qRTe=='live': title = 'LIVE:  '+title
			title = e9tFVyMoR3spHNXvQkYnLDuW6(title)
			f3CI9uLoNmRdptSG8Zs = name+'::'+VsIe8Yrx3HJlZSE
			if cS2NYw4xulqJgvzkMF:
				title = title.encode(YWEQ3Cf8RevpD0m7NjF1)
				f3CI9uLoNmRdptSG8Zs = f3CI9uLoNmRdptSG8Zs.encode(YWEQ3Cf8RevpD0m7NjF1)
			HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2.replace('\/','/')
			if PPs8wYzAVgytCGQE1rHvXJF576qRTe=='channel':
				ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+QnK8G3NsVklupv
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,402,HRlygv7YwjzbSLt8fkEerq2,nA5dhMRg6ENzsB0l1GwvH7aIr2,f3CI9uLoNmRdptSG8Zs)
			else:
				if PPs8wYzAVgytCGQE1rHvXJF576qRTe=='video': yoaKx7FtIlvcD = str(aJxFZOUmE70yAiXGHlNhnLIo5['duration'])
				else: yoaKx7FtIlvcD = nA5dhMRg6ENzsB0l1GwvH7aIr2
				ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/video/'+QnK8G3NsVklupv
				TBt8bUDo9WhL(PPs8wYzAVgytCGQE1rHvXJF576qRTe,DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,403,HRlygv7YwjzbSLt8fkEerq2,yoaKx7FtIlvcD,f3CI9uLoNmRdptSG8Zs)
	return
def CnMQesZ5tPDIRN3wOFfTh81gko(search,Q0f7ytucSriRw8HTzd=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if Q0f7ytucSriRw8HTzd==nA5dhMRg6ENzsB0l1GwvH7aIr2: Q0f7ytucSriRw8HTzd = '1'
	YsdSH10ta6wvi4nMRIO9 = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeHashtags":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  duration  aspectRatio  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  accountType  isFollowed  avatar(height: SQUARE_120) {    id    url    __typename  }  followerEngagement {    id    followDate    __typename  }  metrics {    id    engagement {      id      followers {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  description  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  metrics {    id    engagement {      id      videos(filter: {visibility: {eq: PUBLIC}}) {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment HASHTAG_BASE_FRAG on Hashtag {  id  xid  name  metrics {    id    engagement {      id      videos {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment LIVE_BASE_FRAGMENT on Live {  id  xid  title  audienceCount  aspectRatio  isOnAir  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeHashtags: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...LIVE_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    hashtags(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeHashtags) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...HASHTAG_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mysearchwords',search)
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mypagelimit','40')
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mypagenumber',Q0f7ytucSriRw8HTzd)
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/search/'+search+'/hashtags'
	sLdQxt1cymXejrf = ccRYh7QKHzZtPMp45sdJmyCAn3wV8v(YsdSH10ta6wvi4nMRIO9,search)
	if sLdQxt1cymXejrf:
		oybU5lgN98AxMJ3DkYEVBac60uwO = BwGPDSQOlfUas2n3eIH0ycFRWZ('dict',sLdQxt1cymXejrf)
		try: XA4gRkJDnBEqMma9hdwlI76vzF0 = oybU5lgN98AxMJ3DkYEVBac60uwO['data']['search']['hashtags']['edges']
		except: XA4gRkJDnBEqMma9hdwlI76vzF0 = []
		for iOCV9hPk0bANm642cl1 in XA4gRkJDnBEqMma9hdwlI76vzF0:
			name = iOCV9hPk0bANm642cl1['node']['name']
			name = jPgzFLH1niJpE2r(name)
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/hashtag/'+name[1:]
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'HSHTG: '+name,ZylHkumQ8zD0,417)
		if '"hasNextPage":true' in sLdQxt1cymXejrf:
			Q0f7ytucSriRw8HTzd = str(int(Q0f7ytucSriRw8HTzd)+1)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+Q0f7ytucSriRw8HTzd,url,416,nA5dhMRg6ENzsB0l1GwvH7aIr2,Q0f7ytucSriRw8HTzd,search)
	return
def Egf5Bw23H1ZQ7OIhTJery4Vj(url,Q0f7ytucSriRw8HTzd=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if Q0f7ytucSriRw8HTzd==nA5dhMRg6ENzsB0l1GwvH7aIr2: Q0f7ytucSriRw8HTzd = '1'
	name = url.split('/')[-1]
	YsdSH10ta6wvi4nMRIO9 = '''{"operationName":"HASHTAG_VIDEOS_QUERY","variables":{"hashtag_name":"#myhashtagname","page":mypagenumber},"query":"fragment FRAG_VIDEO_BASE on Video {  id  xid  title  description  thumbnail: thumbnailURL(size: \\"x240\\")  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  duration  createdAt  viewerEngagement {    id    liked    favorited    __typename  }  isExplicit  canDisplayAds  aspectRatio  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  videoHeight: height  videoWidth: width  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  description  logoURL(size: \\"x25\\")  logoURLx60: logoURL(size: \\"x60\\")  coverURL(size: \\"x200\\")  coverURLx1024: coverURL(size: \\"1024x\\")  isFollowed  isArtist  accountType  __typename}fragment VIDEO_FRAG on Video {  id  ...FRAG_VIDEO_BASE  channel {    id    ...CHANNEL_BASE_FRAG    __typename  }  __typename}query HASHTAG_VIDEOS_QUERY($hashtag_name: String!, $page: Int!) {  contentFeed(    name: HASHTAG    filter: {name: {eq: $hashtag_name}, post: {eq: VIDEO}}    sort: {create: DESC}    page: $page    first: 30  ) {    totalCount    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        post {          ...VIDEO_FRAG          __typename        }        featured        __typename      }      __typename    }    __typename  }}"}'''
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('myhashtagname',name)
	YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.replace('mypagenumber',Q0f7ytucSriRw8HTzd)
	sLdQxt1cymXejrf = ccRYh7QKHzZtPMp45sdJmyCAn3wV8v(YsdSH10ta6wvi4nMRIO9)
	if sLdQxt1cymXejrf:
		oybU5lgN98AxMJ3DkYEVBac60uwO = BwGPDSQOlfUas2n3eIH0ycFRWZ('dict',sLdQxt1cymXejrf)
		XA4gRkJDnBEqMma9hdwlI76vzF0 = oybU5lgN98AxMJ3DkYEVBac60uwO['data']['contentFeed']['edges']
		for iOCV9hPk0bANm642cl1 in XA4gRkJDnBEqMma9hdwlI76vzF0:
			yoaKx7FtIlvcD = str(iOCV9hPk0bANm642cl1['node']['post']['duration'])
			title = jPgzFLH1niJpE2r(iOCV9hPk0bANm642cl1['node']['post']['title'])
			title = title.replace('\/','/')
			QnK8G3NsVklupv = iOCV9hPk0bANm642cl1['node']['post']['xid']
			HRlygv7YwjzbSLt8fkEerq2 = iOCV9hPk0bANm642cl1['node']['post']['thumbnailx480']
			HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2.replace('\/','/')
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/video/'+QnK8G3NsVklupv
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,403,HRlygv7YwjzbSLt8fkEerq2,yoaKx7FtIlvcD)
		if '"hasNextPage":true' in sLdQxt1cymXejrf:
			Q0f7ytucSriRw8HTzd = str(int(Q0f7ytucSriRw8HTzd)+1)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+Q0f7ytucSriRw8HTzd,url,416,nA5dhMRg6ENzsB0l1GwvH7aIr2,Q0f7ytucSriRw8HTzd)
	return
def ccRYh7QKHzZtPMp45sdJmyCAn3wV8v(YsdSH10ta6wvi4nMRIO9,search=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	if BsLJ7p5Av2Vm0SQeCO1o: YsdSH10ta6wvi4nMRIO9 = YsdSH10ta6wvi4nMRIO9.encode(YWEQ3Cf8RevpD0m7NjF1)
	vdAU3fy7mqLIRZNWKrBGbuY6aTVp0t = SYuQ7PMNFdxkTCg0i()
	headers = {"Authorization":vdAU3fy7mqLIRZNWKrBGbuY6aTVp0t,"Origin":GiqvpBF9xLEdHDr37byJSngeCQ,'Content-Type':'text/plain; charset=utf-8'}
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,'POST',Ega71ZGOcjfw,YsdSH10ta6wvi4nMRIO9,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'DAILYMOTION-GET_PAGEDATA-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	return kl2ZWdy8rXcHT
def SYuQ7PMNFdxkTCg0i():
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'DAILYMOTION-GET_AUTHINTICATION-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	c2pj9H8f4NEvm7ZIM = PAztbuyYo4Kvd.findall('var r="(.*?)",o="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	lQ9B4JbqnmruTw0k2HZ3hvUgMz,kHJiN39eAzMjCn = c2pj9H8f4NEvm7ZIM[-1]
	tbXBKWAcYmFRz = 'https://graphql.api.dailymotion.com/oauth/token'
	xxKWnYwtDgJZH = 'client_credentials'
	data = {'client_id':lQ9B4JbqnmruTw0k2HZ3hvUgMz,'client_secret':kHJiN39eAzMjCn,'grant_type':xxKWnYwtDgJZH}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,'POST',tbXBKWAcYmFRz,data,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'DAILYMOTION-GET_AUTHINTICATION-2nd')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	c2pj9H8f4NEvm7ZIM = PAztbuyYo4Kvd.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	FqXhs31goGWC8bxzQ4UetVLTSm,PTWqfV5Syxgi0LGlO2rX6vwaF = c2pj9H8f4NEvm7ZIM[0]
	vdAU3fy7mqLIRZNWKrBGbuY6aTVp0t = PTWqfV5Syxgi0LGlO2rX6vwaF+" "+FqXhs31goGWC8bxzQ4UetVLTSm
	return vdAU3fy7mqLIRZNWKrBGbuY6aTVp0t
def WULrxiSjG3d1Cemza7Kc(search,LV9moOrXWFKbGYevPgul=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if not LV9moOrXWFKbGYevPgul and showDialogs:
		Vnu839fZ6bqepGkM = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن مستخدم','بحث عن بث حي','بحث عن هاشتاك']
		iP7AUR41exzlKyZIf9Mt3u = ccAMwn7hflDev8Kd3aqP('موقع ديلي موشن - اختر البحث',Vnu839fZ6bqepGkM)
		if iP7AUR41exzlKyZIf9Mt3u==-1: return
		elif iP7AUR41exzlKyZIf9Mt3u==0: LV9moOrXWFKbGYevPgul = 'videos?sortBy='
		elif iP7AUR41exzlKyZIf9Mt3u==1: LV9moOrXWFKbGYevPgul = 'videos?sortBy=RECENT'
		elif iP7AUR41exzlKyZIf9Mt3u==2: LV9moOrXWFKbGYevPgul = 'videos?sortBy=VIEW_COUNT'
		elif iP7AUR41exzlKyZIf9Mt3u==3: LV9moOrXWFKbGYevPgul = 'playlists'
		elif iP7AUR41exzlKyZIf9Mt3u==4: LV9moOrXWFKbGYevPgul = 'channels'
		elif iP7AUR41exzlKyZIf9Mt3u==5: LV9moOrXWFKbGYevPgul = 'lives'
		elif iP7AUR41exzlKyZIf9Mt3u==6: LV9moOrXWFKbGYevPgul = 'hashtags'
	elif '_DAILYMOTION-VIDEOS_' in m0YJ3feqUjD7: LV9moOrXWFKbGYevPgul = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in m0YJ3feqUjD7: LV9moOrXWFKbGYevPgul = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in m0YJ3feqUjD7: LV9moOrXWFKbGYevPgul = 'channels'
	elif '_DAILYMOTION-LIVES_' in m0YJ3feqUjD7: LV9moOrXWFKbGYevPgul = 'lives'
	elif '_DAILYMOTION-HASHTAGS_' in m0YJ3feqUjD7: LV9moOrXWFKbGYevPgul = 'hashtags'
	elif not LV9moOrXWFKbGYevPgul: LV9moOrXWFKbGYevPgul = 'videos?sortBy='
	if not search:
		search = FaUBpzTGxtS7hZyl()
		if not search: return
	if 'videos' in LV9moOrXWFKbGYevPgul: Zzsbqp1dToaODw8(search+'/'+LV9moOrXWFKbGYevPgul)
	elif 'playlists' in LV9moOrXWFKbGYevPgul: iVMWBC7qoGvz2nF8gO(search)
	elif 'channels' in LV9moOrXWFKbGYevPgul: R0RJjXnpMKO53fbkrS6QyZIUhP(search)
	elif 'lives' in LV9moOrXWFKbGYevPgul: pJqnQ1UKZlm(search)
	elif 'hashtags' in LV9moOrXWFKbGYevPgul: CnMQesZ5tPDIRN3wOFfTh81gko(search)
	return
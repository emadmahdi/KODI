# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'BOKRA'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_BKR_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
headers = {'User-Agent':nA5dhMRg6ENzsB0l1GwvH7aIr2}
SAsGubf1jW2Q3p = ['افلام للكبار','بكرا TV']
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==370: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==371: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,text)
	elif mode==372: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==374: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = Wfx8d5P2pmLu(url)
	elif mode==375: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = cyFbUPCMOosZ5tpQrNI4HqY08a(url)
	elif mode==376: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = RrlVa2hOn1(0,url)
	elif mode==377: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = RrlVa2hOn1(1,url)
	elif mode==379: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'BOKRA-MENU-1st')
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,379,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('right-side(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
			if not any(value in title for value in SAsGubf1jW2Q3p):
				TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,371)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'المميزة',GiqvpBF9xLEdHDr37byJSngeCQ,375)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الأحدث',GiqvpBF9xLEdHDr37byJSngeCQ,376)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'قائمة الممثلين',GiqvpBF9xLEdHDr37byJSngeCQ,374)
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="container"(.*?)top-menu',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items[7:]:
			title = title.strip(hSXlxL9iB05c)
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
			if not any(value in title for value in SAsGubf1jW2Q3p):
				TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,371)
		for ZylHkumQ8zD0,title in items[0:7]:
			title = title.strip(hSXlxL9iB05c)
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
			if not any(value in title for value in SAsGubf1jW2Q3p):
				TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,371)
	return
def Wfx8d5P2pmLu(website=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'BOKRA-ACTORSMENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="row cat Tags"(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)" title="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			if 'http' in ZylHkumQ8zD0: continue
			else: ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
			if not any(value in title for value in SAsGubf1jW2Q3p):
				TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,371)
	return
def cyFbUPCMOosZ5tpQrNI4HqY08a(website=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'BOKRA-FEATURED-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"MainContent"(.*?)main-title2',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
			if not any(value in title for value in SAsGubf1jW2Q3p):
				HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2.replace('://',':///').replace('//','/').replace(hSXlxL9iB05c,'%20')
				TBt8bUDo9WhL('video',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,372,HRlygv7YwjzbSLt8fkEerq2)
	return
def RrlVa2hOn1(id,website=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'BOKRA-WATCHINGNOW-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('main-title2(.*?)class="row',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[id]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
			if not any(value in title for value in SAsGubf1jW2Q3p):
				HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2.replace('://',':///').replace('//','/').replace(hSXlxL9iB05c,'%20')
				TBt8bUDo9WhL('video',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,372,HRlygv7YwjzbSLt8fkEerq2)
	return
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,UmQgD1n6NZh2IpLV7=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'BOKRA-TITLES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	if 'vidpage_' in url:
		ZylHkumQ8zD0 = PAztbuyYo4Kvd.findall('href="(/Album-.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if ZylHkumQ8zD0:
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0[0]
			LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(ZylHkumQ8zD0)
			return
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class=" subcats"(.*?)class="col-md-3',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if UmQgD1n6NZh2IpLV7==nA5dhMRg6ENzsB0l1GwvH7aIr2 and zz3eHskxE6lAyDR5cNj1ug and zz3eHskxE6lAyDR5cNj1ug[0].count('href')>1:
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع',url,371,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'titles')
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)" title="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+'/'+ZylHkumQ8zD0
			title = title.strip(hSXlxL9iB05c)
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,371)
	else:
		u0UiTmzYN6I3Q9eCZVoB = []
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="col-md-3(.*?)col-xs-12',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if not zz3eHskxE6lAyDR5cNj1ug: zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="col-sm-8"(.*?)col-xs-12',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
				ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
				title = title.strip(hSXlxL9iB05c)
				HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2.replace('://',':///').replace('//','/').replace(hSXlxL9iB05c,'%20')
				if '/al_' in ZylHkumQ8zD0:
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,371,HRlygv7YwjzbSLt8fkEerq2)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					JfNHOP2BK1Yxl7Rq4 = PAztbuyYo4Kvd.findall('(.*?) - +الحلقة +\d+',title,PAztbuyYo4Kvd.DOTALL)
					if JfNHOP2BK1Yxl7Rq4: title = '_MOD_مسلسل '+JfNHOP2BK1Yxl7Rq4[0]
					if title not in u0UiTmzYN6I3Q9eCZVoB:
						u0UiTmzYN6I3Q9eCZVoB.append(title)
						TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,371,HRlygv7YwjzbSLt8fkEerq2)
				else: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,372,HRlygv7YwjzbSLt8fkEerq2)
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="pagination(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall('class="".*?href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,title in items:
				ZylHkumQ8zD0 = GiqvpBF9xLEdHDr37byJSngeCQ+ZylHkumQ8zD0
				title = 'صفحة '+HH8SJuswDBPtniebmkXIr(title)
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,371,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'titles')
	return
def lNBcUr8RCn(url):
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(lPsYQwWdLO520ZHcFV8n1x,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'BOKRA-PLAY-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	nR3YVtZDPs1IpAC = PAztbuyYo4Kvd.findall('label-success mrg-btm-5 ">(.*?)<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if nR3YVtZDPs1IpAC and g4gUOtGiVkoNuaBrHhx8L(wgj0rX5tbcxPulhmny,url,nR3YVtZDPs1IpAC): return
	w7Ol6FnokgJDSsIt = nA5dhMRg6ENzsB0l1GwvH7aIr2
	KteRnFMjHpBPqNf8 = PAztbuyYo4Kvd.findall('var url = "(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if KteRnFMjHpBPqNf8: KteRnFMjHpBPqNf8 = KteRnFMjHpBPqNf8[0]
	else: KteRnFMjHpBPqNf8 = url.replace('/vidpage_','/Play/')
	if 'http' not in KteRnFMjHpBPqNf8: KteRnFMjHpBPqNf8 = GiqvpBF9xLEdHDr37byJSngeCQ+KteRnFMjHpBPqNf8
	KteRnFMjHpBPqNf8 = KteRnFMjHpBPqNf8.strip('-')
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(cbpdEaUM8rKSQvzuqiJyXwW4,'GET',KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'BOKRA-PLAY-2nd')
	v2u4dgJnek0sQDxKf = Y3SmVGbfNvEeakMBr.content
	w7Ol6FnokgJDSsIt = PAztbuyYo4Kvd.findall('src="(.*?)"',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL)
	if w7Ol6FnokgJDSsIt:
		w7Ol6FnokgJDSsIt = w7Ol6FnokgJDSsIt[-1]
		if 'http' not in w7Ol6FnokgJDSsIt: w7Ol6FnokgJDSsIt = 'http:'+w7Ol6FnokgJDSsIt
		if '/PLAY/' not in KteRnFMjHpBPqNf8:
			if 'embed.min.js' in w7Ol6FnokgJDSsIt:
				qqunF51xhTSmBjwHlaIDoir0keJV = PAztbuyYo4Kvd.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',v2u4dgJnek0sQDxKf,PAztbuyYo4Kvd.DOTALL)
				if qqunF51xhTSmBjwHlaIDoir0keJV:
					Cs0lpJibEdTcOm, JYlwp9rtmseNq6fTMVz = qqunF51xhTSmBjwHlaIDoir0keJV[0]
					w7Ol6FnokgJDSsIt = C2gnJ5tXFk9pAL(w7Ol6FnokgJDSsIt,'url')+'/v2/'+Cs0lpJibEdTcOm+'/config/'+JYlwp9rtmseNq6fTMVz+'.json'
		import wW9Vexi6dl
		wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM([w7Ol6FnokgJDSsIt],wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	search = search.replace(hSXlxL9iB05c,'+')
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/Search/'+search
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
	return
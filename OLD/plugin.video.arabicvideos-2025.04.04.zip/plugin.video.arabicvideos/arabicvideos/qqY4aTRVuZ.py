# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'MOVIZLAND'
headers = { 'User-Agent' : nA5dhMRg6ENzsB0l1GwvH7aIr2 }
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_MVZ_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
Ega71ZGOcjfw = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][1]
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,text):
	if   mode==180: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==181: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,text)
	elif mode==182: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==183: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LLabVp7hzj28CE0f1udx(url)
	elif mode==188: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = TNeG43JwpWRlvcEPfbUydmLnkxaYV8()
	elif mode==189: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def TNeG43JwpWRlvcEPfbUydmLnkxaYV8():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	OmxJV4UQyeFqdBSIC0(nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,OksCHeoL5SG,message)
	return
def ErjIn5GfaBzkqycC():
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',nA5dhMRg6ENzsB0l1GwvH7aIr2,189,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بوكس اوفيس موفيز لاند',GiqvpBF9xLEdHDr37byJSngeCQ,181,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'box-office')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'أحدث الافلام',GiqvpBF9xLEdHDr37byJSngeCQ,181,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'latest-movies')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'تليفزيون موفيز لاند',GiqvpBF9xLEdHDr37byJSngeCQ,181,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'tv')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الاكثر مشاهدة',GiqvpBF9xLEdHDr37byJSngeCQ,181,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'top-views')
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'أقوى الافلام الحالية',GiqvpBF9xLEdHDr37byJSngeCQ,181,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'top-movies')
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'MOVIZLAND-MENU-1st')
	items = PAztbuyYo4Kvd.findall('<h2><a href="(.*?)".*?">(.*?)<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	for ZylHkumQ8zD0,title in items:
		TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,181)
	return kl2ZWdy8rXcHT
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,type=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,url,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': WWU7QJP2tyTRLIfDh0csxbkvX = PAztbuyYo4Kvd.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)[0]
	elif type=='box-office': WWU7QJP2tyTRLIfDh0csxbkvX = PAztbuyYo4Kvd.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)[0]
	elif type=='top-movies': WWU7QJP2tyTRLIfDh0csxbkvX = PAztbuyYo4Kvd.findall('btn-2-overlay(.*?)<style>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)[0]
	elif type=='top-views': WWU7QJP2tyTRLIfDh0csxbkvX = PAztbuyYo4Kvd.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)[0]
	elif type=='tv': WWU7QJP2tyTRLIfDh0csxbkvX = PAztbuyYo4Kvd.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)[0]
	else: WWU7QJP2tyTRLIfDh0csxbkvX = kl2ZWdy8rXcHT
	if type in ['top-views','top-movies']:
		items = PAztbuyYo4Kvd.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	else: items = PAztbuyYo4Kvd.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	u0UiTmzYN6I3Q9eCZVoB = []
	rrau73jLb0H = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for HRlygv7YwjzbSLt8fkEerq2,PVtaCQIjfu5UDS3pKsY21xz4,vEkDr7QlLO048A1SCBPpJo,OOG7xA9cKJarWB48eCTQXZPzny in items:
		if type in ['top-views','top-movies']:
			HRlygv7YwjzbSLt8fkEerq2,ZylHkumQ8zD0,ww5oBKPZmc,title = HRlygv7YwjzbSLt8fkEerq2,PVtaCQIjfu5UDS3pKsY21xz4,vEkDr7QlLO048A1SCBPpJo,OOG7xA9cKJarWB48eCTQXZPzny
		else: HRlygv7YwjzbSLt8fkEerq2,title,ZylHkumQ8zD0,ww5oBKPZmc = HRlygv7YwjzbSLt8fkEerq2,PVtaCQIjfu5UDS3pKsY21xz4,vEkDr7QlLO048A1SCBPpJo,OOG7xA9cKJarWB48eCTQXZPzny
		ZylHkumQ8zD0 = pvOytL0nF7JY6flXTxAcHbQeNahu3(ZylHkumQ8zD0)
		ZylHkumQ8zD0 = ZylHkumQ8zD0.replace('?view=true',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		title = HH8SJuswDBPtniebmkXIr(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('بجوده ',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		title = title.strip(hSXlxL9iB05c)
		if 'الحلقة' in title or 'الحلقه' in title:
			JfNHOP2BK1Yxl7Rq4 = PAztbuyYo4Kvd.findall('(.*?) (الحلقة|الحلقه) \d+',title,PAztbuyYo4Kvd.DOTALL)
			if JfNHOP2BK1Yxl7Rq4:
				title = '_MOD_' + JfNHOP2BK1Yxl7Rq4[0][0]
				if title not in u0UiTmzYN6I3Q9eCZVoB:
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,183,HRlygv7YwjzbSLt8fkEerq2)
					u0UiTmzYN6I3Q9eCZVoB.append(title)
		elif any(value in title for value in rrau73jLb0H):
			ZylHkumQ8zD0 = ZylHkumQ8zD0 + '?servers=' + ww5oBKPZmc
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,182,HRlygv7YwjzbSLt8fkEerq2)
		else:
			ZylHkumQ8zD0 = ZylHkumQ8zD0 + '?servers=' + ww5oBKPZmc
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,183,HRlygv7YwjzbSLt8fkEerq2)
	if type==nA5dhMRg6ENzsB0l1GwvH7aIr2:
		items = PAztbuyYo4Kvd.findall('\n<li><a href="(.*?)".*?>(.*?)<',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			title = HH8SJuswDBPtniebmkXIr(title)
			title = title.replace('الصفحة ',nA5dhMRg6ENzsB0l1GwvH7aIr2)
			if title!=nA5dhMRg6ENzsB0l1GwvH7aIr2:
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+title,ZylHkumQ8zD0,181)
	return
def LLabVp7hzj28CE0f1udx(url):
	KteRnFMjHpBPqNf8 = url.split('?servers=')[0]
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'MOVIZLAND-EPISODES-1st')
	WWU7QJP2tyTRLIfDh0csxbkvX = PAztbuyYo4Kvd.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	title,eIlXpH1gLhmP4w3,HRlygv7YwjzbSLt8fkEerq2 = WWU7QJP2tyTRLIfDh0csxbkvX[0]
	name = PAztbuyYo4Kvd.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,PAztbuyYo4Kvd.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="episodesNumbers"(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0 in items:
			ZylHkumQ8zD0 = pvOytL0nF7JY6flXTxAcHbQeNahu3(ZylHkumQ8zD0)
			title = PAztbuyYo4Kvd.findall('(الحلقة|الحلقه)-([0-9]+)',ZylHkumQ8zD0.split('/')[-2],PAztbuyYo4Kvd.DOTALL)
			if not title: title = PAztbuyYo4Kvd.findall('()-([0-9]+)',ZylHkumQ8zD0.split('/')[-2],PAztbuyYo4Kvd.DOTALL)
			if title: title = hSXlxL9iB05c + title[0][1]
			else: title = nA5dhMRg6ENzsB0l1GwvH7aIr2
			title = name + ' - ' + 'الحلقة' + title
			title = HH8SJuswDBPtniebmkXIr(title)
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,182,HRlygv7YwjzbSLt8fkEerq2)
	if not items:
		title = HH8SJuswDBPtniebmkXIr(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('بجوده ',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,182,HRlygv7YwjzbSLt8fkEerq2)
	return
def lNBcUr8RCn(url):
	s28gWH519TQ7qI3b = url.split('?servers=')
	KteRnFMjHpBPqNf8 = s28gWH519TQ7qI3b[0]
	del s28gWH519TQ7qI3b[0]
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,KteRnFMjHpBPqNf8,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'MOVIZLAND-PLAY-1st')
	ZylHkumQ8zD0 = PAztbuyYo4Kvd.findall('font-size: 25px;" href="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)[0]
	if ZylHkumQ8zD0 not in s28gWH519TQ7qI3b: s28gWH519TQ7qI3b.append(ZylHkumQ8zD0)
	ce9zAaVFswSq6lLr82DfQyotGW = []
	for ZylHkumQ8zD0 in s28gWH519TQ7qI3b:
		if '://moshahda.' in ZylHkumQ8zD0:
			BYyNDkJW6e0947TP5 = ZylHkumQ8zD0
			ce9zAaVFswSq6lLr82DfQyotGW.append(BYyNDkJW6e0947TP5+'?named=Main')
	for ZylHkumQ8zD0 in s28gWH519TQ7qI3b:
		if '://vb.movizland.' in ZylHkumQ8zD0:
			kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,ZylHkumQ8zD0,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'MOVIZLAND-PLAY-2nd')
			kl2ZWdy8rXcHT = kl2ZWdy8rXcHT.decode('windows-1256').encode(YWEQ3Cf8RevpD0m7NjF1)
			kl2ZWdy8rXcHT = kl2ZWdy8rXcHT.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			kl2ZWdy8rXcHT = kl2ZWdy8rXcHT.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			kl2ZWdy8rXcHT = kl2ZWdy8rXcHT.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			kl2ZWdy8rXcHT = kl2ZWdy8rXcHT.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
			if zz3eHskxE6lAyDR5cNj1ug:
				EyQ4CavgNc2sUrAZwRIXFm1MLb7G,TSUVm0q6gaDdKkrtEGl7ncZX2O9Y = [],[]
				if len(zz3eHskxE6lAyDR5cNj1ug)==1:
					title = nA5dhMRg6ENzsB0l1GwvH7aIr2
					WWU7QJP2tyTRLIfDh0csxbkvX = kl2ZWdy8rXcHT
				else:
					for WWU7QJP2tyTRLIfDh0csxbkvX in zz3eHskxE6lAyDR5cNj1ug:
						YERWNbgAThV2uBr5taO8zcd = PAztbuyYo4Kvd.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
						if YERWNbgAThV2uBr5taO8zcd: WWU7QJP2tyTRLIfDh0csxbkvX = 'src="/uploads/13721411411.png"  \n  ' + YERWNbgAThV2uBr5taO8zcd[0][1]
						YERWNbgAThV2uBr5taO8zcd = PAztbuyYo4Kvd.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
						if YERWNbgAThV2uBr5taO8zcd: WWU7QJP2tyTRLIfDh0csxbkvX = 'src="/uploads/13721411411.png"  \n  ' + YERWNbgAThV2uBr5taO8zcd[0]
						YERWNbgAThV2uBr5taO8zcd = PAztbuyYo4Kvd.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
						if YERWNbgAThV2uBr5taO8zcd: WWU7QJP2tyTRLIfDh0csxbkvX = YERWNbgAThV2uBr5taO8zcd[0] + '  \n  src="/uploads/13721411411.png"'
						GDeBxE6S18VwHtmdYz2q = PAztbuyYo4Kvd.findall('<(.*?)http://up.movizland.(online|com)/uploads/',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
						title = PAztbuyYo4Kvd.findall('> *([^<>]+) *<',GDeBxE6S18VwHtmdYz2q[0][0],PAztbuyYo4Kvd.DOTALL)
						title = hSXlxL9iB05c.join(title)
						title = title.strip(hSXlxL9iB05c)
						title = title.replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c).replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c).replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c).replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c).replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c)
						EyQ4CavgNc2sUrAZwRIXFm1MLb7G.append(title)
					iP7AUR41exzlKyZIf9Mt3u = ccAMwn7hflDev8Kd3aqP('أختر الفيديو المطلوب:', EyQ4CavgNc2sUrAZwRIXFm1MLb7G)
					if iP7AUR41exzlKyZIf9Mt3u == -1 : return
					title = EyQ4CavgNc2sUrAZwRIXFm1MLb7G[iP7AUR41exzlKyZIf9Mt3u]
					WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[iP7AUR41exzlKyZIf9Mt3u]
				ZylHkumQ8zD0 = PAztbuyYo4Kvd.findall('href="(http://moshahda\..*?/\w+.html)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
				Ld71ZNHreOwmBoUpV0nfqt = ZylHkumQ8zD0[0]
				ce9zAaVFswSq6lLr82DfQyotGW.append(Ld71ZNHreOwmBoUpV0nfqt+'?named=Forum')
				WWU7QJP2tyTRLIfDh0csxbkvX = WWU7QJP2tyTRLIfDh0csxbkvX.replace('ـ',nA5dhMRg6ENzsB0l1GwvH7aIr2)
				WWU7QJP2tyTRLIfDh0csxbkvX = WWU7QJP2tyTRLIfDh0csxbkvX.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				WWU7QJP2tyTRLIfDh0csxbkvX = WWU7QJP2tyTRLIfDh0csxbkvX.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				WWU7QJP2tyTRLIfDh0csxbkvX = WWU7QJP2tyTRLIfDh0csxbkvX.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				WWU7QJP2tyTRLIfDh0csxbkvX = WWU7QJP2tyTRLIfDh0csxbkvX.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				WWU7QJP2tyTRLIfDh0csxbkvX = WWU7QJP2tyTRLIfDh0csxbkvX.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				WWU7QJP2tyTRLIfDh0csxbkvX = WWU7QJP2tyTRLIfDh0csxbkvX.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				h64A1FfItNrHUP8bBdY7qguXyQO = PAztbuyYo4Kvd.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
				for Af3uoCM9BH in h64A1FfItNrHUP8bBdY7qguXyQO:
					type = PAztbuyYo4Kvd.findall(' typetype="(.*?)" ',Af3uoCM9BH)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = nA5dhMRg6ENzsB0l1GwvH7aIr2
					items = PAztbuyYo4Kvd.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',Af3uoCM9BH,PAztbuyYo4Kvd.DOTALL)
					for xZySazQXlfDo3IcCgrhq,ZylHkumQ8zD0 in items:
						title = PAztbuyYo4Kvd.findall('(\w+[ \w]*)<',xZySazQXlfDo3IcCgrhq)
						title = title[-1]
						ZylHkumQ8zD0 = ZylHkumQ8zD0 + '?named=' + title + type
						ce9zAaVFswSq6lLr82DfQyotGW.append(ZylHkumQ8zD0)
	w7Ol6FnokgJDSsIt = KteRnFMjHpBPqNf8.replace(GiqvpBF9xLEdHDr37byJSngeCQ,Ega71ZGOcjfw)
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(OkCUfhKTs9DZbcgnw3roPGBvlqt,w7Ol6FnokgJDSsIt,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'MOVIZLAND-PLAY-3rd')
	items = PAztbuyYo4Kvd.findall('" href="(.*?)"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if items:
		MhQBWc4CZuIxl = items[-1]
		ce9zAaVFswSq6lLr82DfQyotGW.append(MhQBWc4CZuIxl+'?named=Mobile')
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(ce9zAaVFswSq6lLr82DfQyotGW,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: search = FaUBpzTGxtS7hZyl()
	if search==nA5dhMRg6ENzsB0l1GwvH7aIr2: return
	search = search.replace(hSXlxL9iB05c,'+')
	kl2ZWdy8rXcHT = ckQrBFeAOKz8RxDup3wGmd5SZ(QdwW2s0iEp56qMmvCbOeLxBRU,GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,headers,nA5dhMRg6ENzsB0l1GwvH7aIr2,'MOVIZLAND-SEARCH-1st')
	items = PAztbuyYo4Kvd.findall('<option value="(.*?)">(.*?)</option>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	XXeuDGkQS9oz = [ nA5dhMRg6ENzsB0l1GwvH7aIr2 ]
	h2hgXPkjUFZidvzMQxaY = [ 'الكل وبدون فلتر' ]
	for kvfOU7Tpz958QBqnIlaAePLys,title in items:
		XXeuDGkQS9oz.append(kvfOU7Tpz958QBqnIlaAePLys)
		h2hgXPkjUFZidvzMQxaY.append(title)
	if kvfOU7Tpz958QBqnIlaAePLys:
		iP7AUR41exzlKyZIf9Mt3u = ccAMwn7hflDev8Kd3aqP('اختر الفلتر المناسب:', h2hgXPkjUFZidvzMQxaY)
		if iP7AUR41exzlKyZIf9Mt3u == -1 : return
		kvfOU7Tpz958QBqnIlaAePLys = XXeuDGkQS9oz[iP7AUR41exzlKyZIf9Mt3u]
	else: kvfOU7Tpz958QBqnIlaAePLys = nA5dhMRg6ENzsB0l1GwvH7aIr2
	url = GiqvpBF9xLEdHDr37byJSngeCQ + '/?s='+search+'&mcat='+kvfOU7Tpz958QBqnIlaAePLys
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url)
	return
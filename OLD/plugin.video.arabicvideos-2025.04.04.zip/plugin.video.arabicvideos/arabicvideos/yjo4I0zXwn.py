# -*- coding: utf-8 -*-
from pR2X91txEm import *
wgj0rX5tbcxPulhmny = 'CIMACLUB'
DjKrTPWEFw2YeCi5d6unBqhZSlAR = '_CCB_'
GiqvpBF9xLEdHDr37byJSngeCQ = Nzp9Fq5cTr.SITESURLS[wgj0rX5tbcxPulhmny][0]
SAsGubf1jW2Q3p = ['عروض المصارعه','للكبار فقط +18','الرئيسية','افلام للكبار فقط','DMCA','مصارعة حرة']
def YYdDUV01oAtQljRBxO9enrEXHwfC(mode,url,Q0f7ytucSriRw8HTzd,text):
	if   mode==820: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = ErjIn5GfaBzkqycC()
	elif mode==821: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,Q0f7ytucSriRw8HTzd)
	elif mode==822: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = lNBcUr8RCn(url)
	elif mode==823: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = SNVTEdvxWujYnGR7J6hACUP(url,text)
	elif mode==824: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = NNihMcqGKQEvLz6l(url,'FULL_FILTER___'+text)
	elif mode==825: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = NNihMcqGKQEvLz6l(url,'DEFINED_FILTER___'+text)
	elif mode==829: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = WULrxiSjG3d1Cemza7Kc(text)
	else: V9OGBuyogH0CaUtQS6wWErAbPYDjlM = False
	return V9OGBuyogH0CaUtQS6wWErAbPYDjlM
def ErjIn5GfaBzkqycC():
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',GiqvpBF9xLEdHDr37byJSngeCQ,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMACLUB-MENU-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	DQ7XgFltujVL = Y3SmVGbfNvEeakMBr.url
	if cS2NYw4xulqJgvzkMF: DQ7XgFltujVL = DQ7XgFltujVL.encode(YWEQ3Cf8RevpD0m7NjF1)
	TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'بحث في الموقع',DQ7XgFltujVL,829,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'_REMEMBERRESULTS_')
	TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+'المميزة',DQ7XgFltujVL,821,nA5dhMRg6ENzsB0l1GwvH7aIr2,'featured','_REMEMBERRESULTS_')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"Tabs"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('get="(.*?)".*?<span>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for data,title in items:
			ZylHkumQ8zD0 = DQ7XgFltujVL+'/getposts?type=one&data='+data
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,821,nA5dhMRg6ENzsB0l1GwvH7aIr2,'highest')
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('navigation-menu(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			if '/' not in ZylHkumQ8zD0: continue
			if '=' in ZylHkumQ8zD0: continue
			if title in SAsGubf1jW2Q3p: continue
			if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = DQ7XgFltujVL+ZylHkumQ8zD0
			TBt8bUDo9WhL('folder',wgj0rX5tbcxPulhmny+'_SCRIPT_'+DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,821)
	return
def LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,type=nA5dhMRg6ENzsB0l1GwvH7aIr2):
	DQ7XgFltujVL = C2gnJ5tXFk9pAL(url,'url')
	WWU7QJP2tyTRLIfDh0csxbkvX,items = nA5dhMRg6ENzsB0l1GwvH7aIr2,[]
	if type=='featured':
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMACLUB-TITLES-1st')
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('home-slider(.*?)page-content',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug: WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	elif type=='highest':
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMACLUB-TITLES-2nd')
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	else:
		Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMACLUB-TITLES-3rd')
		kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('page-content(.*?)footer-menu',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug: WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
	if not WWU7QJP2tyTRLIfDh0csxbkvX: WWU7QJP2tyTRLIfDh0csxbkvX = kl2ZWdy8rXcHT
	if not items: items = PAztbuyYo4Kvd.findall('content-box.*?href="(.*?)".*?src="(.*?)".*?<h3>(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	PmC7clhQwMeTrsYb8x3DUL1kR2tZN = []
	for ZylHkumQ8zD0,HRlygv7YwjzbSLt8fkEerq2,title in items:
		ZylHkumQ8zD0 = ZylHkumQ8zD0.replace('\/','/')
		if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = DQ7XgFltujVL+ZylHkumQ8zD0
		HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2.replace('\/','/')
		ZylHkumQ8zD0 = jPgzFLH1niJpE2r(ZylHkumQ8zD0)
		title = jPgzFLH1niJpE2r(title)
		JfNHOP2BK1Yxl7Rq4 = PAztbuyYo4Kvd.findall('(.*?) (حلقة|الحلقة)',title,PAztbuyYo4Kvd.DOTALL)
		if JfNHOP2BK1Yxl7Rq4: title = '_MOD_'+JfNHOP2BK1Yxl7Rq4[0][0]
		if title in PmC7clhQwMeTrsYb8x3DUL1kR2tZN: continue
		PmC7clhQwMeTrsYb8x3DUL1kR2tZN.append(title)
		if JfNHOP2BK1Yxl7Rq4: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,823,HRlygv7YwjzbSLt8fkEerq2)
		else: TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,822,HRlygv7YwjzbSLt8fkEerq2)
	if type!='featured':
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"paginate"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			for ZylHkumQ8zD0,title in items:
				title = HH8SJuswDBPtniebmkXIr(title)
				if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = DQ7XgFltujVL+ZylHkumQ8zD0
				if title: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'صفحة '+title,ZylHkumQ8zD0,821)
	return
def SNVTEdvxWujYnGR7J6hACUP(url,Q9fbtnwCKAN5syS8DPvmX62gHE):
	DQ7XgFltujVL = C2gnJ5tXFk9pAL(url,'url')
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMACLUB-SEASONS_EPISODES-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	HRlygv7YwjzbSLt8fkEerq2 = PAztbuyYo4Kvd.findall('poster-image.*?url\((.*?)\)',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	HRlygv7YwjzbSLt8fkEerq2 = HRlygv7YwjzbSLt8fkEerq2[0] if HRlygv7YwjzbSLt8fkEerq2 else nA5dhMRg6ENzsB0l1GwvH7aIr2
	items = []
	if not Q9fbtnwCKAN5syS8DPvmX62gHE:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('"Seasons"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug:
			WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
			items = PAztbuyYo4Kvd.findall('<li.*?data-season="(.*?)" data-S="(.*?)" data-B="(.*?)".*?title="(.*?)"',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
			if len(items)>1:
				for Q9fbtnwCKAN5syS8DPvmX62gHE,nOrQlsIvbkNSUELpF,SJHLTtAGogVEjYiz,title in items:
					title = title.replace(BSiDxUPsdHkz27VMop51uf6c3,hSXlxL9iB05c)
					ZylHkumQ8zD0 = DQ7XgFltujVL+'/ajaxCenter?_action=GetSeasonEp&_season='+Q9fbtnwCKAN5syS8DPvmX62gHE+'&_S='+nOrQlsIvbkNSUELpF+'&_B='+SJHLTtAGogVEjYiz
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,823,HRlygv7YwjzbSLt8fkEerq2,nA5dhMRg6ENzsB0l1GwvH7aIr2,Q9fbtnwCKAN5syS8DPvmX62gHE)
	if len(items)<2:
		zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('episodes-ul"(.*?)</ul>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
		if zz3eHskxE6lAyDR5cNj1ug: JKQIrCFpL9,WWU7QJP2tyTRLIfDh0csxbkvX = nA5dhMRg6ENzsB0l1GwvH7aIr2,zz3eHskxE6lAyDR5cNj1ug[0]
		else: JKQIrCFpL9,WWU7QJP2tyTRLIfDh0csxbkvX = 'موسم '+Q9fbtnwCKAN5syS8DPvmX62gHE,kl2ZWdy8rXcHT
		items = PAztbuyYo4Kvd.findall('href="(.*?)">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,JfNHOP2BK1Yxl7Rq4 in items:
			if 'http' not in ZylHkumQ8zD0: ZylHkumQ8zD0 = DQ7XgFltujVL+ZylHkumQ8zD0
			title = ZylHkumQ8zD0.split('/',3)[3]
			title = pvOytL0nF7JY6flXTxAcHbQeNahu3(title).strip('/').replace('-',hSXlxL9iB05c).replace('مسلسل ',nA5dhMRg6ENzsB0l1GwvH7aIr2).replace('مشاهدة ',nA5dhMRg6ENzsB0l1GwvH7aIr2)
			TBt8bUDo9WhL('video',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,ZylHkumQ8zD0,822,HRlygv7YwjzbSLt8fkEerq2)
	return
def lNBcUr8RCn(url):
	url = url+'/see'
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(QdwW2s0iEp56qMmvCbOeLxBRU,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMACLUB-PLAY-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	HtT6mBGwMaq1o0rybzZ4,Co7gJfiXOmlN4VrbjhuknEH = [],[]
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('class="serverWatch(.*?)class="embed"',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('data-embed="(.*?)".*?">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			title = title.strip(hSXlxL9iB05c)
			if ZylHkumQ8zD0 not in Co7gJfiXOmlN4VrbjhuknEH:
				Co7gJfiXOmlN4VrbjhuknEH.append(ZylHkumQ8zD0)
				HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0+'?named='+title+'__watch')
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('data-tab="downloads"(.*?)</div>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		items = PAztbuyYo4Kvd.findall('href="(.*?)".*?<span>(.*?)</span>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		for ZylHkumQ8zD0,title in items:
			if ZylHkumQ8zD0 not in Co7gJfiXOmlN4VrbjhuknEH:
				Co7gJfiXOmlN4VrbjhuknEH.append(ZylHkumQ8zD0)
				title = title.strip(hSXlxL9iB05c)
				HtT6mBGwMaq1o0rybzZ4.append(ZylHkumQ8zD0+'?named='+title+'__download')
	import wW9Vexi6dl
	wW9Vexi6dl.RJqFajhDyZuk2do3OIE1QYl9r6bSM(HtT6mBGwMaq1o0rybzZ4,wgj0rX5tbcxPulhmny,'video',url)
	return
def WULrxiSjG3d1Cemza7Kc(search):
	search,m0YJ3feqUjD7,showDialogs = Vit4q8MczeLRHnJQCyXAam(search)
	if not search: search = FaUBpzTGxtS7hZyl()
	if not search: return
	search = search.replace(hSXlxL9iB05c,'+')
	url = GiqvpBF9xLEdHDr37byJSngeCQ+'/?s='+search
	LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(url,'search')
	return
def iBOFgUs6eTkIQyxKbqM(url):
	url = url.split('/smartemadfilter?')[0]
	Y3SmVGbfNvEeakMBr = uANakQHcnhR(OkCUfhKTs9DZbcgnw3roPGBvlqt,'GET',url,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,'CIMACLUB-GET_FILTERS_BLOCKS-1st')
	kl2ZWdy8rXcHT = Y3SmVGbfNvEeakMBr.content
	AAkSjd9agcy = []
	zz3eHskxE6lAyDR5cNj1ug = PAztbuyYo4Kvd.findall('advanced-search(.*?)</form>',kl2ZWdy8rXcHT,PAztbuyYo4Kvd.DOTALL)
	if zz3eHskxE6lAyDR5cNj1ug:
		WWU7QJP2tyTRLIfDh0csxbkvX = zz3eHskxE6lAyDR5cNj1ug[0]
		AAkSjd9agcy = PAztbuyYo4Kvd.findall('select-menu">.*?">(.*?)<.*?data-tax="(.*?)"(.*?)</ul>',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
		KDuQ6YkSCLPz5be7BqTAxhMXwgF,MFd17IQ58Unz,Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q = zip(*AAkSjd9agcy)
		AAkSjd9agcy = zip(KDuQ6YkSCLPz5be7BqTAxhMXwgF,MFd17IQ58Unz,Jn1lD3WAHqzorX0k45uvhpgfKMIm8Q)
	return AAkSjd9agcy
def vPOwqQ5zYHc10DVaSmU2ysG8k4t(WWU7QJP2tyTRLIfDh0csxbkvX):
	items = PAztbuyYo4Kvd.findall('cat="(.*?)".*?bold">(.*?)<',WWU7QJP2tyTRLIfDh0csxbkvX,PAztbuyYo4Kvd.DOTALL)
	return items
def iCNd2ua6f9EHyBXWYMrKcR(url):
	DQ7XgFltujVL = C2gnJ5tXFk9pAL(url,'url')
	if '/smartemadfilter?' in url:
		url,tgsLX2uACmFhVznejRy6O = url.split('/smartemadfilter?')
		ZylHkumQ8zD0 = DQ7XgFltujVL+'/getposts?'+tgsLX2uACmFhVznejRy6O
	else: ZylHkumQ8zD0 = DQ7XgFltujVL
	return ZylHkumQ8zD0
cc0WqiHnzER = ['category','release-year','genre','quality']
o7o2QXr0sG = ['category','release-year','genre']
def NNihMcqGKQEvLz6l(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==nA5dhMRg6ENzsB0l1GwvH7aIr2: vvXcyZhkfV,guikd57yRSCMsNmlUqFHWAYL = nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2
	else: vvXcyZhkfV,guikd57yRSCMsNmlUqFHWAYL = filter.split('___')
	if type=='DEFINED_FILTER':
		if o7o2QXr0sG[0]+'=' not in vvXcyZhkfV: kvfOU7Tpz958QBqnIlaAePLys = o7o2QXr0sG[0]
		for q3kZpRe28O0s1NaCXQ9SMuGKin in range(len(o7o2QXr0sG[0:-1])):
			if o7o2QXr0sG[q3kZpRe28O0s1NaCXQ9SMuGKin]+'=' in vvXcyZhkfV: kvfOU7Tpz958QBqnIlaAePLys = o7o2QXr0sG[q3kZpRe28O0s1NaCXQ9SMuGKin+1]
		FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+kvfOU7Tpz958QBqnIlaAePLys+'=0'
		QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+kvfOU7Tpz958QBqnIlaAePLys+'=0'
		TB6HLPpacsK8f034jvYx7SNgFd = FqCItdu32L9hNwcEXWoges4R68KS.strip('&')+'___'+QA6C8r4lEdhemfJPRc.strip('&')
		OQmDdTI7hU4Lv3BfexPVKgRF8YN = EdpkojMzLm6b3ZSVcXwi0CPRIH(guikd57yRSCMsNmlUqFHWAYL,'modified_filters')
		KteRnFMjHpBPqNf8 = url+'/smartemadfilter?'+OQmDdTI7hU4Lv3BfexPVKgRF8YN
	elif type=='FULL_FILTER':
		iEa2qGQctFxX = EdpkojMzLm6b3ZSVcXwi0CPRIH(vvXcyZhkfV,'modified_values')
		iEa2qGQctFxX = pvOytL0nF7JY6flXTxAcHbQeNahu3(iEa2qGQctFxX)
		if guikd57yRSCMsNmlUqFHWAYL: guikd57yRSCMsNmlUqFHWAYL = EdpkojMzLm6b3ZSVcXwi0CPRIH(guikd57yRSCMsNmlUqFHWAYL,'modified_filters')
		if not guikd57yRSCMsNmlUqFHWAYL: KteRnFMjHpBPqNf8 = url
		else: KteRnFMjHpBPqNf8 = url+'/smartemadfilter?'+guikd57yRSCMsNmlUqFHWAYL
		w7Ol6FnokgJDSsIt = iCNd2ua6f9EHyBXWYMrKcR(KteRnFMjHpBPqNf8)
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'أظهار قائمة الفيديو التي تم اختيارها ',w7Ol6FnokgJDSsIt,821,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filter')
		TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+' [[   '+iEa2qGQctFxX+'   ]]',w7Ol6FnokgJDSsIt,821,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filter')
		TBt8bUDo9WhL('link',bbTCMJwEx8nhN4X+' ===== ===== ===== '+NwROdSj3nsA,nA5dhMRg6ENzsB0l1GwvH7aIr2,9999)
	AAkSjd9agcy = iBOFgUs6eTkIQyxKbqM(url)
	dict = {}
	for name,xWwIXcK0L61EBgtn7smr,WWU7QJP2tyTRLIfDh0csxbkvX in AAkSjd9agcy:
		name = name.replace('كل ',nA5dhMRg6ENzsB0l1GwvH7aIr2)
		items = vPOwqQ5zYHc10DVaSmU2ysG8k4t(WWU7QJP2tyTRLIfDh0csxbkvX)
		if '=' not in KteRnFMjHpBPqNf8: KteRnFMjHpBPqNf8 = url
		if type=='DEFINED_FILTER':
			if kvfOU7Tpz958QBqnIlaAePLys!=xWwIXcK0L61EBgtn7smr: continue
			elif len(items)<2:
				if xWwIXcK0L61EBgtn7smr==o7o2QXr0sG[-1]:
					w7Ol6FnokgJDSsIt = iCNd2ua6f9EHyBXWYMrKcR(KteRnFMjHpBPqNf8)
					LsqHcg0veiXnSjZkhPBQ1EIr4xWJKD(w7Ol6FnokgJDSsIt,'filter')
				else: NNihMcqGKQEvLz6l(KteRnFMjHpBPqNf8,'DEFINED_FILTER___'+TB6HLPpacsK8f034jvYx7SNgFd)
				return
			else:
				if xWwIXcK0L61EBgtn7smr==o7o2QXr0sG[-1]:
					w7Ol6FnokgJDSsIt = iCNd2ua6f9EHyBXWYMrKcR(KteRnFMjHpBPqNf8)
					TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع ',w7Ol6FnokgJDSsIt,821,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filter')
				else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع ',KteRnFMjHpBPqNf8,825,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,TB6HLPpacsK8f034jvYx7SNgFd)
		elif type=='FULL_FILTER':
			FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+xWwIXcK0L61EBgtn7smr+'=0'
			QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+xWwIXcK0L61EBgtn7smr+'=0'
			TB6HLPpacsK8f034jvYx7SNgFd = FqCItdu32L9hNwcEXWoges4R68KS+'___'+QA6C8r4lEdhemfJPRc
			TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+'الجميع :'+name,KteRnFMjHpBPqNf8,824,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,TB6HLPpacsK8f034jvYx7SNgFd)
		dict[xWwIXcK0L61EBgtn7smr] = {}
		for value,DOT0LXwgoHYkFBC4MbxN53 in items:
			if not value: continue
			if DOT0LXwgoHYkFBC4MbxN53 in SAsGubf1jW2Q3p: continue
			dict[xWwIXcK0L61EBgtn7smr][value] = DOT0LXwgoHYkFBC4MbxN53
			FqCItdu32L9hNwcEXWoges4R68KS = vvXcyZhkfV+'&'+xWwIXcK0L61EBgtn7smr+'='+DOT0LXwgoHYkFBC4MbxN53
			QA6C8r4lEdhemfJPRc = guikd57yRSCMsNmlUqFHWAYL+'&'+xWwIXcK0L61EBgtn7smr+'='+value
			b97AdvPkWGEBe3ayj1Jhmcq2LVxr = FqCItdu32L9hNwcEXWoges4R68KS+'___'+QA6C8r4lEdhemfJPRc
			title = DOT0LXwgoHYkFBC4MbxN53+' :'#+dict[xWwIXcK0L61EBgtn7smr]['0']
			title = DOT0LXwgoHYkFBC4MbxN53+' :'+name
			if type=='FULL_FILTER': TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,824,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,b97AdvPkWGEBe3ayj1Jhmcq2LVxr)
			elif type=='DEFINED_FILTER' and o7o2QXr0sG[-2]+'=' in vvXcyZhkfV:
				OQmDdTI7hU4Lv3BfexPVKgRF8YN = EdpkojMzLm6b3ZSVcXwi0CPRIH(QA6C8r4lEdhemfJPRc,'modified_filters')
				KteRnFMjHpBPqNf8 = url+'/smartemadfilter?'+OQmDdTI7hU4Lv3BfexPVKgRF8YN
				w7Ol6FnokgJDSsIt = iCNd2ua6f9EHyBXWYMrKcR(KteRnFMjHpBPqNf8)
				TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,w7Ol6FnokgJDSsIt,821,nA5dhMRg6ENzsB0l1GwvH7aIr2,'filter')
			else: TBt8bUDo9WhL('folder',DjKrTPWEFw2YeCi5d6unBqhZSlAR+title,url,825,nA5dhMRg6ENzsB0l1GwvH7aIr2,nA5dhMRg6ENzsB0l1GwvH7aIr2,b97AdvPkWGEBe3ayj1Jhmcq2LVxr)
	return
def EdpkojMzLm6b3ZSVcXwi0CPRIH(tgsLX2uACmFhVznejRy6O,mode):
	tgsLX2uACmFhVznejRy6O = tgsLX2uACmFhVznejRy6O.replace('=&','=0&')
	tgsLX2uACmFhVznejRy6O = tgsLX2uACmFhVznejRy6O.strip('&')
	bpoRYqt38j = {}
	if '=' in tgsLX2uACmFhVznejRy6O:
		items = tgsLX2uACmFhVznejRy6O.split('&')
		for CQtNwXGVAJ2y5nBY in items:
			eehzynNs85aTHrgCUmFc3DBO12,value = CQtNwXGVAJ2y5nBY.split('=')
			bpoRYqt38j[eehzynNs85aTHrgCUmFc3DBO12] = value
	H5ROYNwvQFkBiVElThr = nA5dhMRg6ENzsB0l1GwvH7aIr2
	for key in cc0WqiHnzER:
		if key in list(bpoRYqt38j.keys()): value = bpoRYqt38j[key]
		else: value = '0'
		if '%' not in value: value = kGE6zoKSan54W(value)
		if mode=='modified_values' and value!='0': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+' + '+value
		elif mode=='modified_filters' and value!='0': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+'&'+key+'='+value
		elif mode=='all': H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr+'&'+key+'='+value
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.strip(' + ')
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.strip('&')
	H5ROYNwvQFkBiVElThr = H5ROYNwvQFkBiVElThr.replace('=0','=')
	return H5ROYNwvQFkBiVElThr
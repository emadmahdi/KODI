# -*- coding: utf-8 -*-
import sys as eCw7Jk26zZUYbWOis
JTxHbSyGAPcI7XeY = eCw7Jk26zZUYbWOis.version_info [0] == 2
S3sAdDhoTvWILYG8CV157nBgfu = 2048
Bp4rqR9QENCMPK = 7
def Dpg068bx9T4c7JHmEZoILenPFdRA (igqCz1KM4aVwrANmh3Gk765Lb):
	global NcdY7ObymK
	BjytU09nuPGX2SA16 = ord (igqCz1KM4aVwrANmh3Gk765Lb [-1])
	LOqCNsXvwVdGAbgMfF5H4R = igqCz1KM4aVwrANmh3Gk765Lb [:-1]
	c1MatR0DhXmVI6nFEkq8Nz7S4jHUy = BjytU09nuPGX2SA16 % len (LOqCNsXvwVdGAbgMfF5H4R)
	Ap5UwMPSZE = LOqCNsXvwVdGAbgMfF5H4R [:c1MatR0DhXmVI6nFEkq8Nz7S4jHUy] + LOqCNsXvwVdGAbgMfF5H4R [c1MatR0DhXmVI6nFEkq8Nz7S4jHUy:]
	if JTxHbSyGAPcI7XeY:
		nWYbR8mBTKaQirHkVAy61w3I4Ch2Ue = unicode () .join ([unichr (ord (llQfZVqw1SjWJxa0pY7o3dcuU6v) - S3sAdDhoTvWILYG8CV157nBgfu - (DmWXlKgrtzpJMTiY + BjytU09nuPGX2SA16) % Bp4rqR9QENCMPK) for DmWXlKgrtzpJMTiY, llQfZVqw1SjWJxa0pY7o3dcuU6v in enumerate (Ap5UwMPSZE)])
	else:
		nWYbR8mBTKaQirHkVAy61w3I4Ch2Ue = str () .join ([chr (ord (llQfZVqw1SjWJxa0pY7o3dcuU6v) - S3sAdDhoTvWILYG8CV157nBgfu - (DmWXlKgrtzpJMTiY + BjytU09nuPGX2SA16) % Bp4rqR9QENCMPK) for DmWXlKgrtzpJMTiY, llQfZVqw1SjWJxa0pY7o3dcuU6v in enumerate (Ap5UwMPSZE)])
	return eval (nWYbR8mBTKaQirHkVAy61w3I4Ch2Ue)
nQOd8oBjEytHXh0VplK,mETzRscblNZtFni96YjD2u,Djp41MUYzvsPNnHBmfESwA6otC=Dpg068bx9T4c7JHmEZoILenPFdRA,Dpg068bx9T4c7JHmEZoILenPFdRA,Dpg068bx9T4c7JHmEZoILenPFdRA
HrstEm2RLMPUD7bTXyCup6fVg3c0,xvHaIZD5QqhzREbi,LQh1lmqxOoFbiAKseW9nE7DrSyNc8=Djp41MUYzvsPNnHBmfESwA6otC,mETzRscblNZtFni96YjD2u,nQOd8oBjEytHXh0VplK
Nl3vfawn0KkHL5QtA2rdMZF4xByiq,vTsPg1YO5qzWJd2Sbytn,QgBbGdzYRqIHvAChS=LQh1lmqxOoFbiAKseW9nE7DrSyNc8,xvHaIZD5QqhzREbi,HrstEm2RLMPUD7bTXyCup6fVg3c0
eejESDzCBYfOQvWrqT295lui,rPDnOfLo0sxFt6ip4Hl,eevFjkGECQywctRaSm9Tsrz=QgBbGdzYRqIHvAChS,vTsPg1YO5qzWJd2Sbytn,Nl3vfawn0KkHL5QtA2rdMZF4xByiq
ome6pQcSvE4j31PYnUGaDROhZ,dZl53Dzscvr7TNSPBFQb,SxV9NtHj1wIlPifcJO3m=eevFjkGECQywctRaSm9Tsrz,rPDnOfLo0sxFt6ip4Hl,eejESDzCBYfOQvWrqT295lui
JGbk7cLp86WdgVIK0OqUuZrtT,yfrj12mSutPMJ4EVe93TxFgbk,mmZuHe4QrVN9MWSnyK02A=SxV9NtHj1wIlPifcJO3m,dZl53Dzscvr7TNSPBFQb,ome6pQcSvE4j31PYnUGaDROhZ
l8LsywaCXm75Nog,nXIve0m9criy7tgNR2EoJVzqMuP1C,W1gPyQCncoE9jbu04=mmZuHe4QrVN9MWSnyK02A,yfrj12mSutPMJ4EVe93TxFgbk,JGbk7cLp86WdgVIK0OqUuZrtT
k6DPHGL3YsCJFSulbnzf4OxMw,ClIwBW87oZ9G6OU2,erQ31Yx4wX59=W1gPyQCncoE9jbu04,nXIve0m9criy7tgNR2EoJVzqMuP1C,l8LsywaCXm75Nog
fb3vLFDQ9q7Pckldt2AJiE,PFSq79oLVW,V94cA3xQFW=erQ31Yx4wX59,ClIwBW87oZ9G6OU2,k6DPHGL3YsCJFSulbnzf4OxMw
DuZFQnVcMjrPw6Cbo,HHl2Um8jMn5CwSGt1K0E,RjGs6Fgq8tur5m3M2S=V94cA3xQFW,PFSq79oLVW,fb3vLFDQ9q7Pckldt2AJiE
QojUslBRaC0wO5puvebf,zL0B7IsJmuFaDfXKOh81Sjr2ot6,oOmsEUA7vGcMFbRuBnf9r=RjGs6Fgq8tur5m3M2S,HHl2Um8jMn5CwSGt1K0E,DuZFQnVcMjrPw6Cbo
import xbmc as YmawkKSRDIrP1ygz6i3lVC59n,xbmcgui as kh5y8Bv9fNRP,sys as eCw7Jk26zZUYbWOis,os as G8JViHtf6CMocK0bu,requests as J7J4DcaS1XpsQ3Zg6hRPElWOrfBij,re as k41kuEIK0YeWBgVyMoF,xbmcvfs as Z0pr6LOG9mHW5h7eRiXoBNEnjYc,base64 as pzw6c7mLvkS,time as QVgJq2M8FUDAa
TySbPRlcpakUfQmgoeNW52vIt = k6DPHGL3YsCJFSulbnzf4OxMw(u"ࠫࠬࠀ")
def ubW3w4KCP0ei8tApVYOsjBg75TJZUr(request):
	j6jX0r7xStaGF4ERWKZyVJqAfN5 = JGbk7cLp86WdgVIK0OqUuZrtT(u"ࠬࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࡰࡲࡧࡦࡴࡣࡦ࡮ࠪࠁ")
	if request==HrstEm2RLMPUD7bTXyCup6fVg3c0(u"࠭ࡳࡵࡣࡵࡸࠬࠂ"): YmawkKSRDIrP1ygz6i3lVC59n.executebuiltin(JGbk7cLp86WdgVIK0OqUuZrtT(u"ࠧࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࠩࠃ")+j6jX0r7xStaGF4ERWKZyVJqAfN5+QojUslBRaC0wO5puvebf(u"ࠨࠫࠪࠄ"))
	elif request==fb3vLFDQ9q7Pckldt2AJiE(u"ࠩࡶࡸࡴࡶࠧࠅ"): YmawkKSRDIrP1ygz6i3lVC59n.executebuiltin(eevFjkGECQywctRaSm9Tsrz(u"ࠪࡈ࡮ࡧ࡬ࡰࡩ࠱ࡇࡱࡵࡳࡦࠪࠪࠆ")+j6jX0r7xStaGF4ERWKZyVJqAfN5+RjGs6Fgq8tur5m3M2S(u"ࠫ࠮࠭ࠇ"))
	return
def wFbvm7h6HEgN8Gf(dh07pTacIz9lF2Uk,uTkYPNM1iOes2KRAnWDpbx5h6lQ9dJ,GfqkE4tMHen,uuXoTICxtvRHb7lpK4icW0PQmUV,text):
	if not uTkYPNM1iOes2KRAnWDpbx5h6lQ9dJ: uTkYPNM1iOes2KRAnWDpbx5h6lQ9dJ = nXIve0m9criy7tgNR2EoJVzqMuP1C(u"้ࠬไศࠩࠈ")
	if not GfqkE4tMHen: GfqkE4tMHen = xvHaIZD5QqhzREbi(u"࠭ๆฺ็ࠪࠉ")
	if not uuXoTICxtvRHb7lpK4icW0PQmUV: uuXoTICxtvRHb7lpK4icW0PQmUV = eejESDzCBYfOQvWrqT295lui(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࠊ")
	if bY5mXEDZPKpy: I6CT1aAzBWbp9xyRZHvolu = kh5y8Bv9fNRP.Dialog().yesno(uuXoTICxtvRHb7lpK4icW0PQmUV,text,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,uTkYPNM1iOes2KRAnWDpbx5h6lQ9dJ,GfqkE4tMHen)
	else: I6CT1aAzBWbp9xyRZHvolu = kh5y8Bv9fNRP.Dialog().yesno(uuXoTICxtvRHb7lpK4icW0PQmUV,text,uTkYPNM1iOes2KRAnWDpbx5h6lQ9dJ,GfqkE4tMHen)
	return I6CT1aAzBWbp9xyRZHvolu
def QCGMcS62wiZg(dh07pTacIz9lF2Uk,cC41WZg5pAOTolkX7,uuXoTICxtvRHb7lpK4icW0PQmUV,text):
	if not uuXoTICxtvRHb7lpK4icW0PQmUV: uuXoTICxtvRHb7lpK4icW0PQmUV = fb3vLFDQ9q7Pckldt2AJiE(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࠋ")
	return kh5y8Bv9fNRP.Dialog().ok(uuXoTICxtvRHb7lpK4icW0PQmUV,text)
def tt1eg2KoZadqCwSAnP7OzD5YQXV89(uuXoTICxtvRHb7lpK4icW0PQmUV=mmZuHe4QrVN9MWSnyK02A(u"ࠩ็์าฯࠠศๆ่ๅฬะ๊ฮࠩࠌ"),X0gEYdCJtj7nLpRNP5cvl9D=TySbPRlcpakUfQmgoeNW52vIt):
	fIS9wPQ01Zcm8GVg = kh5y8Bv9fNRP.Dialog().input(uuXoTICxtvRHb7lpK4icW0PQmUV,X0gEYdCJtj7nLpRNP5cvl9D,type=kh5y8Bv9fNRP.INPUT_ALPHANUM)
	fIS9wPQ01Zcm8GVg = fIS9wPQ01Zcm8GVg.strip(fb3vLFDQ9q7Pckldt2AJiE(u"ࠪࠤࠬࠍ")).replace(oOmsEUA7vGcMFbRuBnf9r(u"ࠫࠥࠦࠠࠡࠩࠎ"),rPDnOfLo0sxFt6ip4Hl(u"ࠬࠦࠧࠏ")).replace(yfrj12mSutPMJ4EVe93TxFgbk(u"࠭ࠠࠡࠢࠪࠐ"),erQ31Yx4wX59(u"ࠧࠡࠩࠑ")).replace(LQh1lmqxOoFbiAKseW9nE7DrSyNc8(u"ࠨࠢࠣࠫࠒ"),mETzRscblNZtFni96YjD2u(u"ࠩࠣࠫࠓ"))
	return fIS9wPQ01Zcm8GVg
def UUIHyVCWKXxGm92(jLBQfAWzCsb4dnNiu7H5T1YhrKIxM):
	I6CT1aAzBWbp9xyRZHvolu = wFbvm7h6HEgN8Gf(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,eejESDzCBYfOQvWrqT295lui(u"ࠪๆอ๊ࠠฦำึห้ࠦำอๆࠣห้ษฮุษฤࠤ๏าศࠡล้ࠤฯฺฺๅࠢหี๋อๅอࠢ฼้ฬี้ࠠฬ้ฮ฽ืࠠฮฬ์ࠤฯ฾็าࠢ็็ࠥอไๆึส็้่ࠦศๆฦา฼อมࠡ࠰࠱ࠤ฾์ฯ่ษࠣื๏่่ๆࠢๆ์ิ๐ࠠษฬึะ๏๊่ࠠา๊ࠤฬ๊ๅีษๆ่ࠥ๎วๅลั฻ฬวࠠโ์ࠣืั๊ࠠศๆฦา฼อมࠡ࠰࠱ࠤํฮูะ้สࠤ็๋ࠠษวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสล๊ࠥไๆสิ้ัࠦ࠮࠯๊่ࠢࠥะั๋ัࠣห้ศๆࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥหไ๊ࠢส่๊ฮัๆฮࠣรࠦ࠭ࠔ"))
	if I6CT1aAzBWbp9xyRZHvolu!=JGbk7cLp86WdgVIK0OqUuZrtT(u"࠱ࢫ"): return
	if not G8JViHtf6CMocK0bu.path.exists(jLBQfAWzCsb4dnNiu7H5T1YhrKIxM):
		QCGMcS62wiZg(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,JGbk7cLp86WdgVIK0OqUuZrtT(u"้๊ࠫริใࠣ࠲࠳ࠦำอๆࠣห้ษฮุษฤࠤ฿๐ัࠡ็๋ะํีࠠฤู๊้๊่ࠣฮࠩࠕ"))
		return
	message = tt1eg2KoZadqCwSAnP7OzD5YQXV89(rPDnOfLo0sxFt6ip4Hl(u"ࠬษใหสࠣีุอไหๅࠣห้ะ๊ࠡฬิ๎ิࠦลาีส่์อࠠๆ฻ࠣืั๊ࠠศๆฦา฼อมࠨࠖ"))
	GizsLDktBoVhNbveQw3CpE0P8JYy = YmawkKSRDIrP1ygz6i3lVC59n.getInfoLabel(k6DPHGL3YsCJFSulbnzf4OxMw(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡁࡥࡦࡲࡲ࡛࡫ࡲࡴ࡫ࡲࡲ࠭࠭ࠗ")+YwJL1B84sj9tM05pe7KSAXfU+l8LsywaCXm75Nog(u"ࠧࠪࠩ࠘"))
	file = open(jLBQfAWzCsb4dnNiu7H5T1YhrKIxM,k6DPHGL3YsCJFSulbnzf4OxMw(u"ࠨࡴࡥࠫ࠙"))
	BUqh04FLzQDEdgKcueWRfOIP = G8JViHtf6CMocK0bu.path.getsize(jLBQfAWzCsb4dnNiu7H5T1YhrKIxM)
	if BUqh04FLzQDEdgKcueWRfOIP>V94cA3xQFW(u"࠴࠲࠴࠴࠵࠶ࢬ"): file.seek(-V94cA3xQFW(u"࠴࠲࠴࠴࠵࠶ࢬ"),G8JViHtf6CMocK0bu.SEEK_END)
	data = file.read()
	file.close()
	data = data.decode(V94cA3xQFW(u"ࠩࡸࡸ࡫࠾ࠧࠚ"))
	hGD9kmPzSIuXv2HJetsnqCFTbpR = k41kuEIK0YeWBgVyMoF.findall(k6DPHGL3YsCJFSulbnzf4OxMw(u"ࠥࠫࡺࡹࡥࡳࡡ࡬ࡨࠬࡀࠠࠨࠪ࠱࠮ࡄ࠯ࠧࠣࠛ"),data,k41kuEIK0YeWBgVyMoF.DOTALL)
	if not hGD9kmPzSIuXv2HJetsnqCFTbpR: hGD9kmPzSIuXv2HJetsnqCFTbpR = k41kuEIK0YeWBgVyMoF.findall(ome6pQcSvE4j31PYnUGaDROhZ(u"ࠦࠬࡻࡳࡦࡴࠪ࠾ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨࠜ"),data,k41kuEIK0YeWBgVyMoF.DOTALL)
	if not hGD9kmPzSIuXv2HJetsnqCFTbpR: hGD9kmPzSIuXv2HJetsnqCFTbpR = k41kuEIK0YeWBgVyMoF.findall(QgBbGdzYRqIHvAChS(u"ࠬࡢࡤࡼ࠶ࢀ࠱ࡡࡪࡻ࠵ࡿ࠰ࡠࡩࢁ࠴ࡾ࠯࡟ࡨࢀ࠺ࡽ࠮࡞ࡧࡿ࠹ࢃࠧࠝ"),data,k41kuEIK0YeWBgVyMoF.DOTALL)
	hGD9kmPzSIuXv2HJetsnqCFTbpR = hGD9kmPzSIuXv2HJetsnqCFTbpR[nXIve0m9criy7tgNR2EoJVzqMuP1C(u"࠲ࢭ")] if hGD9kmPzSIuXv2HJetsnqCFTbpR else V94cA3xQFW(u"࠭࠰࠱࠲࠳ࠫࠞ")
	hGD9kmPzSIuXv2HJetsnqCFTbpR = hGD9kmPzSIuXv2HJetsnqCFTbpR.split(eevFjkGECQywctRaSm9Tsrz(u"ࠧ࡝ࡰࠪࠟ"),dZl53Dzscvr7TNSPBFQb(u"࠴ࢮ"))[SxV9NtHj1wIlPifcJO3m(u"࠴ࢯ")]
	if bY5mXEDZPKpy: hGD9kmPzSIuXv2HJetsnqCFTbpR = hGD9kmPzSIuXv2HJetsnqCFTbpR.encode(ClIwBW87oZ9G6OU2(u"ࠨࡷࡷࡪ࠽࠭ࠠ"))
	skEWI4wLSlTdgtjJVpoFmx8qUAbDRa = V94cA3xQFW(u"ࠩࡄ࡚࠿ࠦࠧࠡ")+hGD9kmPzSIuXv2HJetsnqCFTbpR+yfrj12mSutPMJ4EVe93TxFgbk(u"ࠪ࠱ࡊࡳࡥࡳࡩࡨࡲࡨࡿࠧࠢ")
	message += HHl2Um8jMn5CwSGt1K0E(u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࡞ࡱࡉࡲࡧࡩ࡭ࠢࡖࡩࡳࡪࡥࡳ࠼ࠣࠫࠣ")+hGD9kmPzSIuXv2HJetsnqCFTbpR+yfrj12mSutPMJ4EVe93TxFgbk(u"ࠬࠦ࠺ࠨࠤ")+vTsPg1YO5qzWJd2Sbytn(u"࠭࡜࡯ࠩࠥ")+SxV9NtHj1wIlPifcJO3m(u"ࠧࡂࡦࡧࡳࡳࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩࠦ")+GizsLDktBoVhNbveQw3CpE0P8JYy+rPDnOfLo0sxFt6ip4Hl(u"ࠨࠢ࠽ࡠࡳ࠭ࠧ")
	data = data.encode(LQh1lmqxOoFbiAKseW9nE7DrSyNc8(u"ࠩࡸࡸ࡫࠾ࠧࠨ"))
	BcPHpIsxLYafS = pzw6c7mLvkS.b64encode(data)
	ayxhILru41PNEGnVX = {Djp41MUYzvsPNnHBmfESwA6otC(u"ࠪࡷࡺࡨࡪࡦࡥࡷࠫࠩ"):skEWI4wLSlTdgtjJVpoFmx8qUAbDRa,eejESDzCBYfOQvWrqT295lui(u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬࠪ"):message,eejESDzCBYfOQvWrqT295lui(u"ࠬࡲ࡯ࡨࡨ࡬ࡰࡪ࠭ࠫ"):BcPHpIsxLYafS}
	Q0DuibF2Gfxj6U8 = nQOd8oBjEytHXh0VplK(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩࠬ")
	HCYG1f83LadhjxPVi7bIFlTBs4DSk = J7J4DcaS1XpsQ3Zg6hRPElWOrfBij.request(dZl53Dzscvr7TNSPBFQb(u"ࠧࡑࡑࡖࡘࠬ࠭"),Q0DuibF2Gfxj6U8,data=ayxhILru41PNEGnVX)
	if HCYG1f83LadhjxPVi7bIFlTBs4DSk.status_code==QojUslBRaC0wO5puvebf(u"࠷࠶࠰ࢰ"): QCGMcS62wiZg(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,fb3vLFDQ9q7Pckldt2AJiE(u"ࠨฮํำࠥ࠴࠮่ࠡฯัฯูࠦๆๆํอࠥหัิษ็ࠤุาไࠡษ็วำ฽วยࠩ࠮"))
	else: QCGMcS62wiZg(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,vTsPg1YO5qzWJd2Sbytn(u"ࠩ็่ศูแࠡ࠰࠱ࠤๆฺไหࠢ฼้้๐ษࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠬ࠯"))
	return
def LYwebougHm():
	I6CT1aAzBWbp9xyRZHvolu = wFbvm7h6HEgN8Gf(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,k6DPHGL3YsCJFSulbnzf4OxMw(u"้้ࠪ็ࠠฦ฻าหิอสࠡษ็ฬึ์วๆฮࠣ๎าะ่๋ࠢ฼่๎ࠦๅฺๆ๋้ฬะࠠหะุࠤฯำฯ๋อࠣห้ฮั็ษ่ะࠥ๎ส็ฺํ้ࠥ฿ๅๅࠢส่อืๆศ็ฯࠤ࠳࠴ฺ่ࠠาࠤู๊อ้ࠡำหࠥอไๆๆไࠤุ๐โ้็ࠣห้ฮั็ษ่ะࠥฮฮๅไ้้ࠣ็ࠠอัํำࠥ็วา฼ࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠศๆล๊๋ࠥำฮ่่ࠢๆࠦลฺัสำฬะࠠศๆหี๋อๅอࠢยࠥࠬ࠰"))
	if I6CT1aAzBWbp9xyRZHvolu!=nXIve0m9criy7tgNR2EoJVzqMuP1C(u"࠷ࢱ"): return
	N5vMaR4sIdwQ0mXFiPne = g8lIECfTSjoqxZLU(SUrgJH4BtpKXQczO3h,RjGs6Fgq8tur5m3M2S(u"ࡌࡡ࡭ࡵࡨࣆ"))
	if N5vMaR4sIdwQ0mXFiPne: QCGMcS62wiZg(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,V94cA3xQFW(u"ࠫั๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡ็ึั๋ࠥไโࠢศ฽ิอฯศฬࠣฬึ์วๆฮࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮ࠭࠱"))
	else: QCGMcS62wiZg(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,JGbk7cLp86WdgVIK0OqUuZrtT(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็็ๅࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ࠲"))
	return
def KHp5F7g2wAVJkvPIysOrjfeo():
	I6CT1aAzBWbp9xyRZHvolu = wFbvm7h6HEgN8Gf(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,ome6pQcSvE4j31PYnUGaDROhZ(u"࠭ๅอๆาࠤ่อิࠡษ็ฬึ์วๆฮࠣ๎าะ่๋ࠢ฼่๎ࠦๅๅใสฮࠥะฮึࠢอ๊฽๐ๅࠡ฻่่ࠥอไษำ้ห๊าࠠๆอ็ࠤ๊๊แศฬࠣห้๋แืๆฬࠤํ๋ไโษอࠤࡎࡖࡔࡗ๋ࠢࠤࡒ࠹ࡕุ๊ࠡ์ึࠦวๅไ๋หห๋ࠠ࠯࠰ࠣ฽๋ีࠠๆีะࠤ์ึวࠡษ็้ั๊ฯࠡีํๆํ๋ࠠศๆหี๋อๅอࠢหา้่ࠠๆฮ็ำࠥาฯ๋ัࠣๅฬืฺࠡ࠰࠱ࠤ์๊ࠠหำํำࠥอไรุ่้ࠣำࠠๆฮ็ำ้ࠥวีࠢส่อืๆศ็ฯࠤฤࠧࠧ࠳"))
	if I6CT1aAzBWbp9xyRZHvolu!=erQ31Yx4wX59(u"࠱ࢲ"): return
	N5vMaR4sIdwQ0mXFiPne = zUqauR5C9dVBb(pT0emE8XBW4SLrvDHOAzh9fUI2c,erQ31Yx4wX59(u"ࡕࡴࡸࡩࣈ"),erQ31Yx4wX59(u"ࡕࡴࡸࡩࣈ"),SxV9NtHj1wIlPifcJO3m(u"ࡆࡢ࡮ࡶࡩࣇ"))
	if N5vMaR4sIdwQ0mXFiPne: QCGMcS62wiZg(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,SxV9NtHj1wIlPifcJO3m(u"ࠧอ์าࠤ࠳࠴ࠠ็ฮะฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็ฯ่ิࠦใศึࠣห้ฮั็ษ่ะࠬ࠴"))
	else: QCGMcS62wiZg(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,zL0B7IsJmuFaDfXKOh81Sjr2ot6(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣๅู๊สࠡ฻่่๏ฯࠠๆีะࠤ๊าไะࠢๆหูࠦวๅสิ๊ฬ๋ฬࠨ࠵"))
	return
def g8lIECfTSjoqxZLU(V1xrcjOdqDKslLEWbm52a04,sDiWb3jZ9o):
	N5vMaR4sIdwQ0mXFiPne = LQh1lmqxOoFbiAKseW9nE7DrSyNc8(u"ࡖࡵࡹࡪࣉ")
	if sDiWb3jZ9o:
		I6CT1aAzBWbp9xyRZHvolu = wFbvm7h6HEgN8Gf(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,LQh1lmqxOoFbiAKseW9nE7DrSyNc8(u"่่ࠩๆࠦลฺัสำฬะࠠศๆหี๋อๅอࠢํัฯ๎๊ࠡ฻็ํู๋ࠥๅ๊่หฯࠦสฯืࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤํะๆู์่ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣ࠲࠳ูࠦ็ัุ้ࠣำ่ࠠาสࠤฬ๊ๅๅใࠣื๏่่ๆࠢส่อืๆศ็ฯࠤอิไใ่่ࠢๆࠦฬะ์าࠤๆอั฻ࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤู๊อࠡ็็ๅࠥหูะษาหฯࠦวๅสิ๊ฬ๋ฬࠡมࠤࠫ࠶"))
		if I6CT1aAzBWbp9xyRZHvolu!=QojUslBRaC0wO5puvebf(u"࠲ࢳ"): return
	if G8JViHtf6CMocK0bu.path.exists(V1xrcjOdqDKslLEWbm52a04):
		try:
			pass
		except Exception as ToNpC9zamHPshcGr4jk3KS2LD:
			N5vMaR4sIdwQ0mXFiPne = JGbk7cLp86WdgVIK0OqUuZrtT(u"ࡉࡥࡱࡹࡥ࣊")
			if sDiWb3jZ9o: QCGMcS62wiZg(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,str(ToNpC9zamHPshcGr4jk3KS2LD))
	if sDiWb3jZ9o:
		if N5vMaR4sIdwQ0mXFiPne: QCGMcS62wiZg(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,HHl2Um8jMn5CwSGt1K0E(u"ࠪะ๏ีࠠ࠯࠰๊ࠣัำสࠡ฻่่๏ฯࠠศๆ่ืา࠭࠷"))
		else: QCGMcS62wiZg(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,V94cA3xQFW(u"้๊ࠫริใࠣ࠲࠳ࠦแีๆอࠤ฾๋ไ๋หࠣห้๋ำฮࠩ࠸"))
	return N5vMaR4sIdwQ0mXFiPne
def zUqauR5C9dVBb(JMSzB59QIDe,IGRKTg4hSJwH,ocfNEh9jdTOJBA3qV7rHGasuLP,sDiWb3jZ9o):
	N5vMaR4sIdwQ0mXFiPne = yfrj12mSutPMJ4EVe93TxFgbk(u"ࡘࡷࡻࡥ࣋")
	if sDiWb3jZ9o:
		I6CT1aAzBWbp9xyRZHvolu = wFbvm7h6HEgN8Gf(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,JMSzB59QIDe+dZl53Dzscvr7TNSPBFQb(u"ࠬࡢ࡮࡝ࡰ๊่ࠥะั๋ัุ้ࠣำ่ࠠาสࠤฬ๊ๅอๆาࠤฤࠧࠧ࠹"))
		if I6CT1aAzBWbp9xyRZHvolu!=mETzRscblNZtFni96YjD2u(u"࠳ࢴ"): return
	if G8JViHtf6CMocK0bu.path.exists(JMSzB59QIDe):
		for YtByQ4XmFC,bAHfjBylrS,NNUh0z5HIlpwVCvc3 in G8JViHtf6CMocK0bu.walk(JMSzB59QIDe,topdown=Djp41MUYzvsPNnHBmfESwA6otC(u"ࡋࡧ࡬ࡴࡧ࣌")):
			for NYqdZ9DS3rCyh8TatjUQA in NNUh0z5HIlpwVCvc3:
				w2LughZYqP = G8JViHtf6CMocK0bu.path.join(YtByQ4XmFC,NYqdZ9DS3rCyh8TatjUQA)
				try:
					G8JViHtf6CMocK0bu.remove(w2LughZYqP)
				except Exception as ToNpC9zamHPshcGr4jk3KS2LD:
					N5vMaR4sIdwQ0mXFiPne = xvHaIZD5QqhzREbi(u"ࡌࡡ࡭ࡵࡨ࣍")
					if sDiWb3jZ9o: QCGMcS62wiZg(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,str(ToNpC9zamHPshcGr4jk3KS2LD))
			if IGRKTg4hSJwH:
				for ozn4y7RKHcEa9sgpZUOk in bAHfjBylrS:
					ASs6iBMZwrjYg = G8JViHtf6CMocK0bu.path.join(YtByQ4XmFC,ozn4y7RKHcEa9sgpZUOk)
					try:
						G8JViHtf6CMocK0bu.rmdir(ASs6iBMZwrjYg)
					except: pass
		if ocfNEh9jdTOJBA3qV7rHGasuLP:
			try:
				G8JViHtf6CMocK0bu.rmdir(YtByQ4XmFC)
			except: pass
	if sDiWb3jZ9o:
		if N5vMaR4sIdwQ0mXFiPne: QCGMcS62wiZg(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,Nl3vfawn0KkHL5QtA2rdMZF4xByiq(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หࠣห้๋ำฮࠩ࠺"))
		else: QCGMcS62wiZg(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,HrstEm2RLMPUD7bTXyCup6fVg3c0(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦวๅ็ึัࠬ࠻"))
	return N5vMaR4sIdwQ0mXFiPne
def EJAWkxwrHnYmUvBDXfLq6():
	I6CT1aAzBWbp9xyRZHvolu = wFbvm7h6HEgN8Gf(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,ClIwBW87oZ9G6OU2(u"ࠨ็ฯ่ิࠦี้ำࠣ็ฯอศสࠢส่็๎วว็ࠣ࠲࠳ࠦ็ัษࠣห้๋ฬๅัࠣๅ๏ํࠠษ฻ูࠤ็๎วว็ࠣห้ฮั็ษ่ะ๋ࠥฮำ่ฬࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠡ࠰࠱ࠤ฾์ฯࠡ็ึัࠥอไๆฮ็ำู๊ࠥใ๊่ࠤฬ๊ศา่ส้ัࠦศฯๆๅࠤ๊าไะࠢฯำ๏ี้ࠠ์หำศࠦๅาหࠣวำื้ࠡส่่หํࠠษษ็ูํืฺ่ࠠาࠤๆะอࠡษ็ๆํอฦๆࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤู๊อࠡ็ฯ่ิࠦี้ำࠣ็ฯอศสࠢๅ์ฬฬๅࠡษ็ฬึ์วๆฮࠣรࠦ࠭࠼"))
	if I6CT1aAzBWbp9xyRZHvolu!=SxV9NtHj1wIlPifcJO3m(u"࠴ࢵ"): return
	N5vMaR4sIdwQ0mXFiPne = zUqauR5C9dVBb(d27lzZAFfHJVN,DuZFQnVcMjrPw6Cbo(u"ࡕࡴࡸࡩ࣏"),dZl53Dzscvr7TNSPBFQb(u"ࡆࡢ࡮ࡶࡩ࣎"),DuZFQnVcMjrPw6Cbo(u"ࡕࡴࡸࡩ࣏"))
	if N5vMaR4sIdwQ0mXFiPne: QCGMcS62wiZg(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,xvHaIZD5QqhzREbi(u"ࠩฯ๎ิࠦ࠮࠯้ࠢะาะฺࠠ็็๎ฮࠦๅิฯ้ࠣั๊ฯࠡื๋ี้ࠥสศสฬࠤฬ๊โ้ษษ้ࠬ࠽"))
	else: QCGMcS62wiZg(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,eejESDzCBYfOQvWrqT295lui(u"่้ࠪษำโࠢ࠱࠲ࠥ็ิๅฬࠣ฽๊๊๊ส่ࠢืาࠦๅอๆาࠤฺ๎ัࠡๅอหอฯࠠศๆๅ์ฬฬๅࠨ࠾"))
	return
def zOb5jyaXY78LGwAFhcZMqInlKu():
	Q0DuibF2Gfxj6U8 = mmZuHe4QrVN9MWSnyK02A(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡴࡷࡵ࡫ࡪ࠴ࡳࡩ࠱࡮ࡳࡩ࡯࠯ࡦ࡯ࡤࡨࡤࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠳ࡴࡲࡤ࠰࡫ࡱࡨࡪࡾ࠮ࡩࡶࡰࡰࠬ࠿")
	HCYG1f83LadhjxPVi7bIFlTBs4DSk = J7J4DcaS1XpsQ3Zg6hRPElWOrfBij.request(HrstEm2RLMPUD7bTXyCup6fVg3c0(u"ࠬࡍࡅࡕࠩࡀ"),Q0DuibF2Gfxj6U8)
	cbP1rGFozw = HCYG1f83LadhjxPVi7bIFlTBs4DSk.content
	cbP1rGFozw = cbP1rGFozw.decode(nQOd8oBjEytHXh0VplK(u"࠭ࡵࡵࡨ࠻ࠫࡁ"))
	NNUh0z5HIlpwVCvc3 = k41kuEIK0YeWBgVyMoF.findall(nXIve0m9criy7tgNR2EoJVzqMuP1C(u"ࠧࡩࡴࡨࡪࡂࠨࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࠮࠮ࠫࡁࠬ࠲ࡿ࡯ࡰࠣࠩࡂ"),cbP1rGFozw,k41kuEIK0YeWBgVyMoF.DOTALL)
	NNUh0z5HIlpwVCvc3 = sorted(NNUh0z5HIlpwVCvc3,reverse=ome6pQcSvE4j31PYnUGaDROhZ(u"ࡖࡵࡹࡪ࣐"))
	ppq4usHYBDFemlKaId28XN07zj = kh5y8Bv9fNRP.Dialog().select(eejESDzCBYfOQvWrqT295lui(u"ࠨษัฮึࠦวๅวุำฬืࠠศๆำ๎ࠥะั๋ัࠣฮะฮ๊ห้ࠪࡃ"),NNUh0z5HIlpwVCvc3)
	if ppq4usHYBDFemlKaId28XN07zj==-fb3vLFDQ9q7Pckldt2AJiE(u"࠵ࢶ"): return
	filename = NNUh0z5HIlpwVCvc3[ppq4usHYBDFemlKaId28XN07zj]
	if bY5mXEDZPKpy: filename = filename.encode(eejESDzCBYfOQvWrqT295lui(u"ࠩࡸࡸ࡫࠾ࠧࡄ"))
	iwkJLCuEhTbA5zys = Q0DuibF2Gfxj6U8.rsplit(mETzRscblNZtFni96YjD2u(u"ࠪ࠳ࠬࡅ"),nQOd8oBjEytHXh0VplK(u"࠶ࢷ"))[nXIve0m9criy7tgNR2EoJVzqMuP1C(u"࠶ࢸ")]+ClIwBW87oZ9G6OU2(u"ࠫ࠴࠭ࡆ")+eevFjkGECQywctRaSm9Tsrz(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࠬࡇ")+filename+eevFjkGECQywctRaSm9Tsrz(u"࠭࠮ࡻ࡫ࡳࠫࡈ")
	N5vMaR4sIdwQ0mXFiPne = DuZFQnVcMjrPw6Cbo(u"ࡉࡥࡱࡹࡥ࣑")
	HCYG1f83LadhjxPVi7bIFlTBs4DSk = J7J4DcaS1XpsQ3Zg6hRPElWOrfBij.request(dZl53Dzscvr7TNSPBFQb(u"ࠧࡈࡇࡗࠫࡉ"),iwkJLCuEhTbA5zys)
	if HCYG1f83LadhjxPVi7bIFlTBs4DSk.status_code==QojUslBRaC0wO5puvebf(u"࠲࠱࠲ࢹ"):
		qPdGeC4DmF = HCYG1f83LadhjxPVi7bIFlTBs4DSk.content
		import zipfile as hIlfM7Z4ySD5Yt8rX,io as CA4vi0pjVob
		jc4Py6T3vn2gStklMaCqrb0UzsZ = CA4vi0pjVob.BytesIO(qPdGeC4DmF)
		zUqauR5C9dVBb(b92lMukFmgw,k6DPHGL3YsCJFSulbnzf4OxMw(u"࡙ࡸࡵࡦ࣓"),k6DPHGL3YsCJFSulbnzf4OxMw(u"࡙ࡸࡵࡦ࣓"),RjGs6Fgq8tur5m3M2S(u"ࡊࡦࡲࡳࡦ࣒"))
		wBU7FRJdGqhXlA3zSfV2NDT = hIlfM7Z4ySD5Yt8rX.ZipFile(jc4Py6T3vn2gStklMaCqrb0UzsZ)
		wBU7FRJdGqhXlA3zSfV2NDT.extractall(pcHiPsBjADkOtFbVGmXlT7I)
		QVgJq2M8FUDAa.sleep(ome6pQcSvE4j31PYnUGaDROhZ(u"࠲ࢺ"))
		YmawkKSRDIrP1ygz6i3lVC59n.executebuiltin(ome6pQcSvE4j31PYnUGaDROhZ(u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬࡊ"))
		QVgJq2M8FUDAa.sleep(nXIve0m9criy7tgNR2EoJVzqMuP1C(u"࠳ࢻ"))
		Fcrb1EVU3dqsAOlJQezBXMa2 = YmawkKSRDIrP1ygz6i3lVC59n.executeJSONRPC(LQh1lmqxOoFbiAKseW9nE7DrSyNc8(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬࡋ")+YwJL1B84sj9tM05pe7KSAXfU+ome6pQcSvE4j31PYnUGaDROhZ(u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡶࡵࡹࡪࢃࡽࠨࡌ"))
		if erQ31Yx4wX59(u"ࠫࡔࡑࠧࡍ") in Fcrb1EVU3dqsAOlJQezBXMa2: N5vMaR4sIdwQ0mXFiPne = vTsPg1YO5qzWJd2Sbytn(u"࡚ࡲࡶࡧࣔ")
	if N5vMaR4sIdwQ0mXFiPne:
		QCGMcS62wiZg(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,V94cA3xQFW(u"ࠬา๊ะࠢ࠱࠲ࠥ์ฬฮฬࠣ฽๊๊๊สࠢอฯอ๐สࠡษ็ษฺีวาࠢส่็ี๊ๆࠢ࡟ࡲࡡࡴࠠࠨࡎ")+filename)
		msg = RjGs6Fgq8tur5m3M2S(u"࠭อห๋ࠣ๎อ่้ࠡษ็ษฺีวาࠢส่็ี๊ๆࠢไ๎ࠥา็ศิๆࠤํ๊วࠡ์อ้ࠥะอะ์ฮ๋ࠥษ่ห๊่หฯ๐ใ๋ษࠣ࠲࠳๊ࠦอสࠣว๋ࠦสใ๊่ࠤอห๊ใษไࠤฬ๊สฮัํฯࠥอไฤ๊อ์๊อส๋ๅํࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦล๋ไสๅࠥอไหฯา๎ะࠦวๅล๋ฮํ๋วห์ๆ๎๊ࠥไษำ้ห๊าࠠภࠣࠪࡏ")
		MxaUuLQ87G4ThiK2qSDreoVN9ZI(msg)
	else: QCGMcS62wiZg(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,QgBbGdzYRqIHvAChS(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦสฬสํฮࠥอไฦืาหึࠦวๅไา๎๊ࠦ࡜࡯࡞ࡱࠤࠬࡐ")+filename)
	return
def MxaUuLQ87G4ThiK2qSDreoVN9ZI(msg=V94cA3xQFW(u"ࠨ้็ࠤฯื๊ะࠢอุ฿๐ไࠡล๋ࠤส๐โศใࠣห้ะอะ์ฮࠤฬ๊ร้ฬ๋้ฬะ๊ไ์่้ࠣฮั็ษ่ะࠥลࠡࠨࡑ")):
	I6CT1aAzBWbp9xyRZHvolu = wFbvm7h6HEgN8Gf(TySbPRlcpakUfQmgoeNW52vIt,V94cA3xQFW(u"ࠩศ๎็อแࠡษ็ฮาี๊ฬࠩࡒ"),oOmsEUA7vGcMFbRuBnf9r(u"ࠪฮาี๊ฬࠢฦ์ฯ๎ๅศฬํ็๏࠭ࡓ"),TySbPRlcpakUfQmgoeNW52vIt,msg)
	if I6CT1aAzBWbp9xyRZHvolu==-DuZFQnVcMjrPw6Cbo(u"࠴ࢼ"): return
	Rpi3gHJDLj5ABvSEWYb = xvHaIZD5QqhzREbi(u"ࠫࡪࡴࡡࡣ࡮ࡨࠫࡔ") if I6CT1aAzBWbp9xyRZHvolu else ome6pQcSvE4j31PYnUGaDROhZ(u"ࠬࡪࡩࡴࡣࡥࡰࡪ࠭ࡕ")
	N5vMaR4sIdwQ0mXFiPne = eevFjkGECQywctRaSm9Tsrz(u"ࡆࡢ࡮ࡶࡩࣕ")
	Y7YV13LOfimHK6gexq0pnu = LQh1lmqxOoFbiAKseW9nE7DrSyNc8(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨࡖ")
	AYtRdguF2EINp = PFSq79oLVW(u"ࠧࡣ࡮ࡤࡧࡰࡲࡩࡴࡶࠪࡗ") if bY5mXEDZPKpy else SxV9NtHj1wIlPifcJO3m(u"ࠨࡷࡳࡨࡦࡺࡥࡠࡴࡸࡰࡪࡹࠧࡘ")
	try:
		import sqlite3 as ZVw5jvCY4mxkFfBXTJN1DE
		VV1wKOBaZ60 = ZVw5jvCY4mxkFfBXTJN1DE.connect(UVvyPa4lurO)
		VV1wKOBaZ60.text_factory = str
		wfCZMcBXTOlU9mFjY0uAIdLSh = VV1wKOBaZ60.cursor()
		wfCZMcBXTOlU9mFjY0uAIdLSh.execute(HHl2Um8jMn5CwSGt1K0E(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡲࡶ࡮࡭ࡩ࡯ࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨ࡙ࠧ")+YwJL1B84sj9tM05pe7KSAXfU+RjGs6Fgq8tur5m3M2S(u"ࠪࠦࠥࡁ࡚ࠧ"))
		yaDoCpQ9Tm1EAferutBFZ = wfCZMcBXTOlU9mFjY0uAIdLSh.fetchall()
		if yaDoCpQ9Tm1EAferutBFZ and Y7YV13LOfimHK6gexq0pnu not in str(yaDoCpQ9Tm1EAferutBFZ): wfCZMcBXTOlU9mFjY0uAIdLSh.execute(RjGs6Fgq8tur5m3M2S(u"࡚ࠫࡖࡄࡂࡖࡈࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡔࡇࡗࠤࡴࡸࡩࡨ࡫ࡱࠤࡂࠦࠢࠨ࡛")+Y7YV13LOfimHK6gexq0pnu+ome6pQcSvE4j31PYnUGaDROhZ(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ࡜")+YwJL1B84sj9tM05pe7KSAXfU+LQh1lmqxOoFbiAKseW9nE7DrSyNc8(u"࠭ࠢࠡ࠽ࠪ࡝"))
		wfCZMcBXTOlU9mFjY0uAIdLSh.execute(eejESDzCBYfOQvWrqT295lui(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࠨ࡞")+AYtRdguF2EINp+V94cA3xQFW(u"ࠨ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭࡟")+YwJL1B84sj9tM05pe7KSAXfU+zL0B7IsJmuFaDfXKOh81Sjr2ot6(u"ࠩࠥࠤࡀ࠭ࡠ"))
		yaDoCpQ9Tm1EAferutBFZ = wfCZMcBXTOlU9mFjY0uAIdLSh.fetchall()
		E4nCOgbu625Rydxe = xvHaIZD5QqhzREbi(u"ࡈࡤࡰࡸ࡫ࣗ") if yaDoCpQ9Tm1EAferutBFZ else vTsPg1YO5qzWJd2Sbytn(u"ࡕࡴࡸࡩࣖ")
		if not E4nCOgbu625Rydxe and JGbk7cLp86WdgVIK0OqUuZrtT(u"ࠪࡩࡳࡧࡢ࡭ࡧࠪࡡ") in Rpi3gHJDLj5ABvSEWYb: wfCZMcBXTOlU9mFjY0uAIdLSh.execute(nXIve0m9criy7tgNR2EoJVzqMuP1C(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠪࡢ")+AYtRdguF2EINp+V94cA3xQFW(u"ࠬࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪࡣ")+YwJL1B84sj9tM05pe7KSAXfU+V94cA3xQFW(u"࠭ࠢࠡ࠽ࠪࡤ"))
		elif E4nCOgbu625Rydxe and eevFjkGECQywctRaSm9Tsrz(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࠨࡥ") in Rpi3gHJDLj5ABvSEWYb:
			if bY5mXEDZPKpy: wfCZMcBXTOlU9mFjY0uAIdLSh.execute(QgBbGdzYRqIHvAChS(u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠧࡦ")+AYtRdguF2EINp+dZl53Dzscvr7TNSPBFQb(u"ࠩࠣࠬࡦࡪࡤࡰࡰࡌࡈ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩࡧ")+YwJL1B84sj9tM05pe7KSAXfU+Djp41MUYzvsPNnHBmfESwA6otC(u"ࠪࠦ࠮ࠦ࠻ࠨࡨ"))
			else: wfCZMcBXTOlU9mFjY0uAIdLSh.execute(xvHaIZD5QqhzREbi(u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠪࡩ")+AYtRdguF2EINp+mmZuHe4QrVN9MWSnyK02A(u"ࠬࠦࠨࡢࡦࡧࡳࡳࡏࡄ࠭ࡷࡳࡨࡦࡺࡥࡓࡷ࡯ࡩ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩࡪ")+YwJL1B84sj9tM05pe7KSAXfU+nXIve0m9criy7tgNR2EoJVzqMuP1C(u"࠭ࠢ࠭࠳ࠬࠤࡀ࠭࡫"))
		VV1wKOBaZ60.commit()
		VV1wKOBaZ60.close()
		N5vMaR4sIdwQ0mXFiPne = oOmsEUA7vGcMFbRuBnf9r(u"ࡗࡶࡺ࡫ࣘ")
	except: pass
	if N5vMaR4sIdwQ0mXFiPne:
		QVgJq2M8FUDAa.sleep(nQOd8oBjEytHXh0VplK(u"࠵ࢽ"))
		YmawkKSRDIrP1ygz6i3lVC59n.executebuiltin(erQ31Yx4wX59(u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫ࡬"))
		QVgJq2M8FUDAa.sleep(ome6pQcSvE4j31PYnUGaDROhZ(u"࠶ࢾ"))
		QCGMcS62wiZg(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,eejESDzCBYfOQvWrqT295lui(u"ࠨฮํำࠥ࠴࠮่ࠡฯัฯࠦวๅ฻่่๏ฯࠧ࡭"))
	else: QCGMcS62wiZg(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,fb3vLFDQ9q7Pckldt2AJiE(u"ࠩ็่ศูแࠡ࠰࠱ࠤๆฺไหࠢส่฾๋ไ๋หࠪ࡮"))
	return
def cR7eaFmfWNukK1TzV3():
	I6CT1aAzBWbp9xyRZHvolu = wFbvm7h6HEgN8Gf(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,nXIve0m9criy7tgNR2EoJVzqMuP1C(u"ࠪ฽๊๊๊สࠢอ๊฽๐แࠡๅ๋ำ๏ࠦสห็ࠣฬู๊อࠡษ็้้็วหࠢส่็ี๊ๆหࠣห้๋ฤใฬฬࠤฬ๊ส๋่ࠢฮัู๋สࠢไ๎๋ࠥฬๅัสฮࠥ๎ๅๅใสฮ้่ࠥะ์ࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠห่฻๎ๆࠦใ้ัํࠤฬ๊ย็ࠢยࠥࠬ࡯"))
	if I6CT1aAzBWbp9xyRZHvolu!=yfrj12mSutPMJ4EVe93TxFgbk(u"࠷ࢿ"): return
	ww1qzMmYxR6GFBjs84ouQJE7Vrh = zUqauR5C9dVBb(phjbXFfJTrDsCEIeiLklPG,Nl3vfawn0KkHL5QtA2rdMZF4xByiq(u"࡙ࡸࡵࡦࣚ"),QgBbGdzYRqIHvAChS(u"ࡊࡦࡲࡳࡦࣙ"),QgBbGdzYRqIHvAChS(u"ࡊࡦࡲࡳࡦࣙ"))
	aGlgPA1tsqRI2WbSQ7yjX8cL9kd = zUqauR5C9dVBb(PMhuJEI98TR5gpcU2aHs3QF,V94cA3xQFW(u"ࡔࡳࡷࡨࣜ"),k6DPHGL3YsCJFSulbnzf4OxMw(u"ࡌࡡ࡭ࡵࡨࣛ"),k6DPHGL3YsCJFSulbnzf4OxMw(u"ࡌࡡ࡭ࡵࡨࣛ"))
	q8qZjWsVtgieAfR = zUqauR5C9dVBb(wP1LuxSZvio,k6DPHGL3YsCJFSulbnzf4OxMw(u"ࡖࡵࡹࡪࣞ"),rPDnOfLo0sxFt6ip4Hl(u"ࡇࡣ࡯ࡷࡪࣝ"),rPDnOfLo0sxFt6ip4Hl(u"ࡇࡣ࡯ࡷࡪࣝ"))
	NNaXizY5MWJ2y = RYONlbhVs1capqCQWxBGPeu(HHl2Um8jMn5CwSGt1K0E(u"ࡗࡶࡺ࡫ࣟ"))
	fBW0oGxrjYXKS = l1PvNVeZ2AFn5MuDp0()
	N5vMaR4sIdwQ0mXFiPne = all([ww1qzMmYxR6GFBjs84ouQJE7Vrh,aGlgPA1tsqRI2WbSQ7yjX8cL9kd,q8qZjWsVtgieAfR,NNaXizY5MWJ2y,fBW0oGxrjYXKS])
	if N5vMaR4sIdwQ0mXFiPne: QCGMcS62wiZg(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,V94cA3xQFW(u"ࠫั๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡฬ้฼๏็ࠠไ๊า๎ࠬࡰ"))
	else: QCGMcS62wiZg(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,HrstEm2RLMPUD7bTXyCup6fVg3c0(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣ็ํี๊ࠨࡱ"))
	return
def PPHe3i2InUYfkvrG6K05XypSWF():
	I6CT1aAzBWbp9xyRZHvolu = wFbvm7h6HEgN8Gf(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,eejESDzCBYfOQvWrqT295lui(u"ู࠭ๆๆํอࠥะๆู์ไࠤฬ๊ฬ่ษีࠤฯะๅࠡส่ืาࠦวๅ็็ๅฬะࠠศๆๅำ๏๋ษࠡษ็้ษ่สสࠢส่ฯ๐ࠠๆฬฯ้฾ฯࠠโ์๊ࠣ฽อๅࠡฬื฾๏๊ࠠศๆฯ๋ฬุࠠ࠯࠰๋้ࠣࠦสา์าࠤฯ์ุ๋ใࠣห้า็ศิࠣห้ศๆࠡมࠤࠫࡲ"))
	if I6CT1aAzBWbp9xyRZHvolu!=PFSq79oLVW(u"࠱ࣀ"): return
	ZRM0gOJNQbuWhC7U = k6DPHGL3YsCJFSulbnzf4OxMw(u"ࠧ࠰ࡦࡤࡸࡦ࠵ࡳࡺࡵࡷࡩࡲ࠵ࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠪࡳ")
	iR0TmoutPM1 = JGbk7cLp86WdgVIK0OqUuZrtT(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡴࡻࡶࡸࡪࡳ࠯ࡥࡴࡲࡴࡧࡵࡸࠨࡴ")
	qO1NInbVA6ZTRvrFdgC2M5cJf = zL0B7IsJmuFaDfXKOh81Sjr2ot6(u"ࠩ࠲ࡨࡦࡺࡡ࠰ࡶࡲࡱࡧࡹࡴࡰࡰࡨࡷࠬࡵ")
	f0rt6QB7m3lAxwP4nFsiKqD = k6DPHGL3YsCJFSulbnzf4OxMw(u"ࠪ࠳ࡩࡧࡴࡢ࠱࡯ࡳ࡬࡭ࡥࡳࠩࡶ")
	no1S0g4yd6XEbBrs9YmZ = DuZFQnVcMjrPw6Cbo(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡰࡴ࡭ࠧࡷ")
	JOkc32UuPW1psKTLxYyiqoVe = SxV9NtHj1wIlPifcJO3m(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡦࡴࡲࠨࡸ")
	ww1qzMmYxR6GFBjs84ouQJE7Vrh = zUqauR5C9dVBb(ZRM0gOJNQbuWhC7U,DuZFQnVcMjrPw6Cbo(u"࡙ࡸࡵࡦ࣡"),Djp41MUYzvsPNnHBmfESwA6otC(u"ࡊࡦࡲࡳࡦ࣠"),Djp41MUYzvsPNnHBmfESwA6otC(u"ࡊࡦࡲࡳࡦ࣠"))
	aGlgPA1tsqRI2WbSQ7yjX8cL9kd = zUqauR5C9dVBb(iR0TmoutPM1,SxV9NtHj1wIlPifcJO3m(u"ࡔࡳࡷࡨࣣ"),mETzRscblNZtFni96YjD2u(u"ࡌࡡ࡭ࡵࡨ࣢"),mETzRscblNZtFni96YjD2u(u"ࡌࡡ࡭ࡵࡨ࣢"))
	q8qZjWsVtgieAfR = zUqauR5C9dVBb(qO1NInbVA6ZTRvrFdgC2M5cJf,rPDnOfLo0sxFt6ip4Hl(u"ࡖࡵࡹࡪࣥ"),eejESDzCBYfOQvWrqT295lui(u"ࡇࡣ࡯ࡷࡪࣤ"),eejESDzCBYfOQvWrqT295lui(u"ࡇࡣ࡯ࡷࡪࣤ"))
	NNaXizY5MWJ2y = zUqauR5C9dVBb(f0rt6QB7m3lAxwP4nFsiKqD,PFSq79oLVW(u"ࡘࡷࡻࡥࣧ"),HHl2Um8jMn5CwSGt1K0E(u"ࡉࡥࡱࡹࡥࣦ"),HHl2Um8jMn5CwSGt1K0E(u"ࡉࡥࡱࡹࡥࣦ"))
	fBW0oGxrjYXKS = zUqauR5C9dVBb(no1S0g4yd6XEbBrs9YmZ,oOmsEUA7vGcMFbRuBnf9r(u"࡚ࡲࡶࡧࣩ"),QgBbGdzYRqIHvAChS(u"ࡋࡧ࡬ࡴࡧࣨ"),QgBbGdzYRqIHvAChS(u"ࡋࡧ࡬ࡴࡧࣨ"))
	SB3cyQr28j = zUqauR5C9dVBb(JOkc32UuPW1psKTLxYyiqoVe,DuZFQnVcMjrPw6Cbo(u"ࡕࡴࡸࡩ࣫"),W1gPyQCncoE9jbu04(u"ࡆࡢ࡮ࡶࡩ࣪"),W1gPyQCncoE9jbu04(u"ࡆࡢ࡮ࡶࡩ࣪"))
	N5vMaR4sIdwQ0mXFiPne = all([ww1qzMmYxR6GFBjs84ouQJE7Vrh,aGlgPA1tsqRI2WbSQ7yjX8cL9kd,q8qZjWsVtgieAfR,NNaXizY5MWJ2y,fBW0oGxrjYXKS,SB3cyQr28j])
	if N5vMaR4sIdwQ0mXFiPne: QCGMcS62wiZg(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,vTsPg1YO5qzWJd2Sbytn(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หࠣฮ๋฾๊โࠢส่ัํวำࠩࡹ"))
	else: QCGMcS62wiZg(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,dZl53Dzscvr7TNSPBFQb(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦส็ฺํๅࠥอไอ้สึࠬࡺ"))
	return
def RYONlbhVs1capqCQWxBGPeu(sDiWb3jZ9o):
	N5vMaR4sIdwQ0mXFiPne = Djp41MUYzvsPNnHBmfESwA6otC(u"ࡖࡵࡹࡪ࣬")
	if sDiWb3jZ9o:
		I6CT1aAzBWbp9xyRZHvolu = wFbvm7h6HEgN8Gf(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,l8LsywaCXm75Nog(u"ࠨ้็ࠤฯื๊ะ่ࠢืาࠦๅฮฬ๋๎ฬะࠠๆๆไࠤฺ๎ัࠡษ็ะ้ีࠠภࠣࠤࠫࡻ"))
		if I6CT1aAzBWbp9xyRZHvolu!=oOmsEUA7vGcMFbRuBnf9r(u"࠲ࣁ"): return
	try:
		import sqlite3 as ZVw5jvCY4mxkFfBXTJN1DE
		O26kc0KNJ314MwYFxCWp5iPs9SI = ZVw5jvCY4mxkFfBXTJN1DE.connect(LLcRQGItiABq6KOkrMVeYy)
		O26kc0KNJ314MwYFxCWp5iPs9SI.text_factory = str
		wfCZMcBXTOlU9mFjY0uAIdLSh = O26kc0KNJ314MwYFxCWp5iPs9SI.cursor()
		wfCZMcBXTOlU9mFjY0uAIdLSh.execute(dZl53Dzscvr7TNSPBFQb(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࡱࡣࡷ࡬ࡀ࠭ࡼ"))
		wfCZMcBXTOlU9mFjY0uAIdLSh.execute(Djp41MUYzvsPNnHBmfESwA6otC(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࡵ࡬ࡾࡪࡹ࠻ࠨࡽ"))
		wfCZMcBXTOlU9mFjY0uAIdLSh.execute(HrstEm2RLMPUD7bTXyCup6fVg3c0(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡷࡩࡽࡺࡵࡳࡧ࠾ࠫࡾ"))
		O26kc0KNJ314MwYFxCWp5iPs9SI.commit()
		wfCZMcBXTOlU9mFjY0uAIdLSh.execute(LQh1lmqxOoFbiAKseW9nE7DrSyNc8(u"ࠬ࡜ࡁࡄࡗࡘࡑࡀ࠭ࡿ"))
		O26kc0KNJ314MwYFxCWp5iPs9SI.close()
	except: N5vMaR4sIdwQ0mXFiPne = nXIve0m9criy7tgNR2EoJVzqMuP1C(u"ࡉࡥࡱࡹࡥ࣭")
	if sDiWb3jZ9o and N5vMaR4sIdwQ0mXFiPne: QCGMcS62wiZg(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,yfrj12mSutPMJ4EVe93TxFgbk(u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧࢀ"))
	return N5vMaR4sIdwQ0mXFiPne
def l1PvNVeZ2AFn5MuDp0():
	N5vMaR4sIdwQ0mXFiPne = Nl3vfawn0KkHL5QtA2rdMZF4xByiq(u"ࡘࡷࡻࡥ࣮")
	for file in G8JViHtf6CMocK0bu.listdir(YYR6Q3sTNacMLtF92zlq0Amjf):
		if QgBbGdzYRqIHvAChS(u"ࠧ࡬ࡱࡧ࡭ࡤࡹࡴࡢࡥ࡮ࡸࡷࡧࡣࡦࠩࢁ") not in file or Nl3vfawn0KkHL5QtA2rdMZF4xByiq(u"ࠨ࡭ࡲࡨ࡮ࡥࡣࡳࡣࡶ࡬ࡱࡵࡧࠨࢂ") not in file: continue
		w2LughZYqP = G8JViHtf6CMocK0bu.path.join(YYR6Q3sTNacMLtF92zlq0Amjf,file)
		try:
			G8JViHtf6CMocK0bu.remove(w2LughZYqP)
		except Exception as ToNpC9zamHPshcGr4jk3KS2LD:
			N5vMaR4sIdwQ0mXFiPne = V94cA3xQFW(u"ࡋࡧ࡬ࡴࡧ࣯")
			if sDiWb3jZ9o and N5vMaR4sIdwQ0mXFiPne: QCGMcS62wiZg(TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,TySbPRlcpakUfQmgoeNW52vIt,str(ToNpC9zamHPshcGr4jk3KS2LD))
	return N5vMaR4sIdwQ0mXFiPne
ubW3w4KCP0ei8tApVYOsjBg75TJZUr(SxV9NtHj1wIlPifcJO3m(u"ࠩࡶࡸࡦࡸࡴࠨࢃ"))
oCda0n2mrqefPRshKOWDyB = eCw7Jk26zZUYbWOis.argv[erQ31Yx4wX59(u"࠳ࣂ")]
YwJL1B84sj9tM05pe7KSAXfU = mmZuHe4QrVN9MWSnyK02A(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨࢄ")
A1Ah4CI5VJeBzy7LsOT8ZStF93Rr = YmawkKSRDIrP1ygz6i3lVC59n.getInfoLabel(V94cA3xQFW(u"ࠦࡘࡿࡳࡵࡧࡰ࠲ࡇࡻࡩ࡭ࡦ࡙ࡩࡷࡹࡩࡰࡰࠥࢅ"))
bBhEqgk6AMFGz7Qsorpt1WP8 = k41kuEIK0YeWBgVyMoF.findall(nQOd8oBjEytHXh0VplK(u"ࠬ࠮࡜ࡥ࡞ࡧࡠ࠳ࡢࡤࠪࠩࢆ"),A1Ah4CI5VJeBzy7LsOT8ZStF93Rr,k41kuEIK0YeWBgVyMoF.DOTALL)
bBhEqgk6AMFGz7Qsorpt1WP8 = float(bBhEqgk6AMFGz7Qsorpt1WP8[oOmsEUA7vGcMFbRuBnf9r(u"࠳ࣃ")])
bY5mXEDZPKpy = bBhEqgk6AMFGz7Qsorpt1WP8<vTsPg1YO5qzWJd2Sbytn(u"࠵࠾ࣄ")
bq8VPOWUADiNhpZQKXRajM7J0mGu3 = bBhEqgk6AMFGz7Qsorpt1WP8>nXIve0m9criy7tgNR2EoJVzqMuP1C(u"࠶࠾࠮࠺࠻ࣅ")
if bq8VPOWUADiNhpZQKXRajM7J0mGu3:
	YYR6Q3sTNacMLtF92zlq0Amjf = Z0pr6LOG9mHW5h7eRiXoBNEnjYc.translatePath(zL0B7IsJmuFaDfXKOh81Sjr2ot6(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡯ࡳ࡬ࡶࡡࡵࡪࠪࢇ"))
	WYT9ixQzDV0nJekKB3fb5a2d41Gv = Z0pr6LOG9mHW5h7eRiXoBNEnjYc.translatePath(PFSq79oLVW(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨ࢈"))
	DjHpMS9bAKFaWeu = Z0pr6LOG9mHW5h7eRiXoBNEnjYc.translatePath(ClIwBW87oZ9G6OU2(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡹ࡫࡭ࡱࠩࢉ"))
	UVvyPa4lurO = G8JViHtf6CMocK0bu.path.join(WYT9ixQzDV0nJekKB3fb5a2d41Gv,eejESDzCBYfOQvWrqT295lui(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫࢊ"),mmZuHe4QrVN9MWSnyK02A(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬࢋ"),k6DPHGL3YsCJFSulbnzf4OxMw(u"ࠫࡆࡪࡤࡰࡰࡶ࠷࠸࠴ࡤࡣࠩࢌ"))
else:
	YYR6Q3sTNacMLtF92zlq0Amjf = YmawkKSRDIrP1ygz6i3lVC59n.translatePath(V94cA3xQFW(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩࢍ"))
	WYT9ixQzDV0nJekKB3fb5a2d41Gv = YmawkKSRDIrP1ygz6i3lVC59n.translatePath(yfrj12mSutPMJ4EVe93TxFgbk(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧࢎ"))
	DjHpMS9bAKFaWeu = YmawkKSRDIrP1ygz6i3lVC59n.translatePath(JGbk7cLp86WdgVIK0OqUuZrtT(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡸࡪࡳࡰࠨ࢏"))
	UVvyPa4lurO = G8JViHtf6CMocK0bu.path.join(WYT9ixQzDV0nJekKB3fb5a2d41Gv,dZl53Dzscvr7TNSPBFQb(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ࢐"),xvHaIZD5QqhzREbi(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ࢑"),mmZuHe4QrVN9MWSnyK02A(u"ࠪࡅࡩࡪ࡯࡯ࡵ࠵࠻࠳ࡪࡢࠨ࢒"))
JXD3qhKVTbLU = G8JViHtf6CMocK0bu.path.join(WYT9ixQzDV0nJekKB3fb5a2d41Gv,nQOd8oBjEytHXh0VplK(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭࢓"),oOmsEUA7vGcMFbRuBnf9r(u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ࢔"),YwJL1B84sj9tM05pe7KSAXfU)
SUrgJH4BtpKXQczO3h = G8JViHtf6CMocK0bu.path.join(JXD3qhKVTbLU,DuZFQnVcMjrPw6Cbo(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ࢕"))
pT0emE8XBW4SLrvDHOAzh9fUI2c = G8JViHtf6CMocK0bu.path.join(DjHpMS9bAKFaWeu,YwJL1B84sj9tM05pe7KSAXfU)
wP1LuxSZvio = G8JViHtf6CMocK0bu.path.join(WYT9ixQzDV0nJekKB3fb5a2d41Gv,yfrj12mSutPMJ4EVe93TxFgbk(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ࢖"),W1gPyQCncoE9jbu04(u"ࠨࡖ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࢗ"))
pcHiPsBjADkOtFbVGmXlT7I = G8JViHtf6CMocK0bu.path.join(WYT9ixQzDV0nJekKB3fb5a2d41Gv,nXIve0m9criy7tgNR2EoJVzqMuP1C(u"ࠩࡤࡨࡩࡵ࡮ࡴࠩ࢘"))
b92lMukFmgw = G8JViHtf6CMocK0bu.path.join(pcHiPsBjADkOtFbVGmXlT7I,YwJL1B84sj9tM05pe7KSAXfU)
phjbXFfJTrDsCEIeiLklPG = G8JViHtf6CMocK0bu.path.join(pcHiPsBjADkOtFbVGmXlT7I,RjGs6Fgq8tur5m3M2S(u"ࠪࡸࡪࡳࡰࠨ࢙"))
PMhuJEI98TR5gpcU2aHs3QF = G8JViHtf6CMocK0bu.path.join(pcHiPsBjADkOtFbVGmXlT7I,eevFjkGECQywctRaSm9Tsrz(u"ࠫࡵࡧࡣ࡬ࡣࡪࡩࡸ࢚࠭"))
LLcRQGItiABq6KOkrMVeYy = G8JViHtf6CMocK0bu.path.join(WYT9ixQzDV0nJekKB3fb5a2d41Gv,JGbk7cLp86WdgVIK0OqUuZrtT(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧ࢛ࠧ"),JGbk7cLp86WdgVIK0OqUuZrtT(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ࢜"),ClIwBW87oZ9G6OU2(u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧ࢝"))
d27lzZAFfHJVN = G8JViHtf6CMocK0bu.path.join(pT0emE8XBW4SLrvDHOAzh9fUI2c,eevFjkGECQywctRaSm9Tsrz(u"ࠨ࡫ࡰࡥ࡬࡫ࡳࠨ࢞"))
vv1PiKf5x9alTbr6JLRE = G8JViHtf6CMocK0bu.path.join(YYR6Q3sTNacMLtF92zlq0Amjf,nQOd8oBjEytHXh0VplK(u"ࠩ࡮ࡳࡩ࡯࠮࡭ࡱࡪࠫ࢟"))
oXuhG6UeANpHI09KD = G8JViHtf6CMocK0bu.path.join(YYR6Q3sTNacMLtF92zlq0Amjf,eejESDzCBYfOQvWrqT295lui(u"ࠪ࡯ࡴࡪࡩ࠯ࡱ࡯ࡨ࠳ࡲ࡯ࡨࠩࢠ"))
if   oCda0n2mrqefPRshKOWDyB==fb3vLFDQ9q7Pckldt2AJiE(u"ࠫࡸ࡫࡮ࡥࡡ࡯ࡳ࡬࡬ࡩ࡭ࡧࠪࢡ")		: UUIHyVCWKXxGm92(vv1PiKf5x9alTbr6JLRE)
elif oCda0n2mrqefPRshKOWDyB==eevFjkGECQywctRaSm9Tsrz(u"ࠬࡹࡥ࡯ࡦࡢࡳࡱࡪ࡟࡭ࡱࡪࡪ࡮ࡲࡥࠨࢢ")	: UUIHyVCWKXxGm92(oXuhG6UeANpHI09KD)
elif oCda0n2mrqefPRshKOWDyB==ClIwBW87oZ9G6OU2(u"࠭ࡤࡦ࡮ࡨࡸࡪࡥࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠨࢣ")		: LYwebougHm()
elif oCda0n2mrqefPRshKOWDyB==rPDnOfLo0sxFt6ip4Hl(u"ࠧࡥࡧ࡯ࡩࡹ࡫࡟ࡤࡣࡦ࡬ࡪ࠭ࢤ")		: KHp5F7g2wAVJkvPIysOrjfeo()
elif oCda0n2mrqefPRshKOWDyB==erQ31Yx4wX59(u"ࠨࡥ࡯ࡩࡦࡴ࡟࡬ࡱࡧ࡭ࠬࢥ")			: cR7eaFmfWNukK1TzV3()
elif oCda0n2mrqefPRshKOWDyB==fb3vLFDQ9q7Pckldt2AJiE(u"ࠩࡦࡰࡪࡧ࡮ࡠࡦࡨࡺ࡮ࡩࡥࡠࡱࡶࠫࢦ")		: PPHe3i2InUYfkvrG6K05XypSWF()
elif oCda0n2mrqefPRshKOWDyB==DuZFQnVcMjrPw6Cbo(u"ࠪ࡭ࡳࡹࡴࡢ࡮࡯ࡣࡴࡲࡤࡠࡸࡨࡶࡸ࡯࡯࡯ࠩࢧ")	: zOb5jyaXY78LGwAFhcZMqInlKu()
elif oCda0n2mrqefPRshKOWDyB==yfrj12mSutPMJ4EVe93TxFgbk(u"ࠫࡲࡵࡤࡪࡨࡼࡣࡦࡻࡴࡰࡷࡳࡨࡦࡺࡥࠨࢨ")	: MxaUuLQ87G4ThiK2qSDreoVN9ZI()
elif oCda0n2mrqefPRshKOWDyB==HrstEm2RLMPUD7bTXyCup6fVg3c0(u"ࠬࡪࡥ࡭ࡧࡷࡩࡤࡳࡥ࡯ࡷࡶࡣ࡮ࡳࡡࡨࡧࡶࠫࢩ")	: EJAWkxwrHnYmUvBDXfLq6()
ubW3w4KCP0ei8tApVYOsjBg75TJZUr(HrstEm2RLMPUD7bTXyCup6fVg3c0(u"࠭ࡳࡵࡱࡳࠫࢪ"))
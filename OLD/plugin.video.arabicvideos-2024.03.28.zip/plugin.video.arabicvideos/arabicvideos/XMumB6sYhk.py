# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'EGYBEST3'
tiCRYyX1bWd40Ir3PafQu = '_EB3_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['المصارعة الحرة','ايجي بست','التصميم الجديد','عروض المصارعة','مكتبتي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست','موقع نتفليكس']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,BzbaC0qYjMr2WXwsO,text):
	if   mode==790: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==791: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,BzbaC0qYjMr2WXwsO)
	elif mode==792: vS7JufTVsBxw52 = GQsDp6PWFHRE1ki2odqrwjB0ISTLh(url)
	elif mode==793: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==796: vS7JufTVsBxw52 = ZN3Wh7HABLwRIkFmyEd1Jq(url,BzbaC0qYjMr2WXwsO)
	elif mode==799: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',yONJxHER9BIDPpTV4YsWmc0n,'','','','','EGYBEST3-MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('list-pages(.*?)fa-folder',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?<span>(.*?)</span>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			title = title.strip(' ')
			if any(c2eEflztvIX in title for c2eEflztvIX in WLI5tgXRbUPNGJCSVz0vKjBDei3): continue
			if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,791)
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('main-article(.*?)social-box',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('main-title.*?">(.*?)<.*?href="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for title,ekTrZlFMu0Kf5QztEnhAs in items:
			title = title.strip(' ')
			if any(c2eEflztvIX in title for c2eEflztvIX in WLI5tgXRbUPNGJCSVz0vKjBDei3): continue
			if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,791,'','mainmenu')
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('main-menu(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			title = title.strip(' ')
			if any(c2eEflztvIX in title for c2eEflztvIX in WLI5tgXRbUPNGJCSVz0vKjBDei3): continue
			if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,791)
	return oo9SgGkiDbs3HRn7z8
def ZN3Wh7HABLwRIkFmyEd1Jq(url,type=''):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','EGYBEST3-SEASONS_EPISODES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('main-article".*?">(.*?)<(.*?)article',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		EKhwoNlubG5A7xaJW2UOg1,Ez1AbVgerRU0YimHu45t9DI7qM,items = '','',[]
		for name,lmO2YJGr6tCV in cWafzb4HoG1Em3Jwxu6C7vZsVi:
			if 'حلقات' in name: Ez1AbVgerRU0YimHu45t9DI7qM = lmO2YJGr6tCV
			if 'مواسم' in name: EKhwoNlubG5A7xaJW2UOg1 = lmO2YJGr6tCV
		if EKhwoNlubG5A7xaJW2UOg1 and not type:
			items = u5h2Rckvw1E.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',EKhwoNlubG5A7xaJW2UOg1,u5h2Rckvw1E.DOTALL)
			if len(items)>1:
				for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,796,pGjsvdyHfM,'season')
		if Ez1AbVgerRU0YimHu45t9DI7qM and len(items)<2:
			items = u5h2Rckvw1E.findall('href="(.*?)".*?data-src="(.*?)".*?class="title">(.*?)<',Ez1AbVgerRU0YimHu45t9DI7qM,u5h2Rckvw1E.DOTALL)
			if items:
				for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
					uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,793,pGjsvdyHfM)
			else:
				items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',Ez1AbVgerRU0YimHu45t9DI7qM,u5h2Rckvw1E.DOTALL)
				for ekTrZlFMu0Kf5QztEnhAs,title in items:
					uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,793)
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,type=''):
	J8BSTexfgwYvhPW1dGV,start,v6YLr90gxdTVfyG83J1XAzjiF,select,d6Toh7rjW5GDQzkJBqAnKwpPu3a = 0,0,'','',''
	if 'pagination' in type:
		Gk2NaZLCuXw3bR,data = ykfj6Qb9Fc5GiJIvelp84rHDn(url)
		J8BSTexfgwYvhPW1dGV = int(data['limit'])
		start = int(data['start'])
		v6YLr90gxdTVfyG83J1XAzjiF = data['type']
		select = data['select']
		XfOb4VIcPY = 'limit='+str(J8BSTexfgwYvhPW1dGV)+'&start='+str(start)+'&type='+v6YLr90gxdTVfyG83J1XAzjiF+'&select='+select
		emrzEIsMWO2GLw9lpKxSY7n0F = {'Content-Type':'application/x-www-form-urlencoded'}
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'POST',Gk2NaZLCuXw3bR,XfOb4VIcPY,emrzEIsMWO2GLw9lpKxSY7n0F,'','','EGYBEST3-TITLES-1st')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		ZCOosjaQ8x9HDKSVGM6LwW2vy = 'blocks'+oo9SgGkiDbs3HRn7z8+'article'
	else:
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','EGYBEST3-TITLES-2nd')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		ZCOosjaQ8x9HDKSVGM6LwW2vy = oo9SgGkiDbs3HRn7z8
		code = u5h2Rckvw1E.findall("<script>(var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?);</script>",oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if code:
			code = code[0].replace('var','').replace(' ','').replace("'",'').replace(';','&')
			qBdHbiaM0lmk5GNsfrXCIYyugR,data = ykfj6Qb9Fc5GiJIvelp84rHDn('?'+code)
			J8BSTexfgwYvhPW1dGV = int(data['limit'])
			start = int(data['start'])
			v6YLr90gxdTVfyG83J1XAzjiF = data['type']
			select = data['select']
			d6Toh7rjW5GDQzkJBqAnKwpPu3a = data['ajaxurl']
			XfOb4VIcPY = 'limit='+str(J8BSTexfgwYvhPW1dGV)+'&start='+str(start)+'&type='+v6YLr90gxdTVfyG83J1XAzjiF+'&select='+select
			Gk2NaZLCuXw3bR = yONJxHER9BIDPpTV4YsWmc0n+d6Toh7rjW5GDQzkJBqAnKwpPu3a
			emrzEIsMWO2GLw9lpKxSY7n0F = {'Content-Type':'application/x-www-form-urlencoded'}
			RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'POST',Gk2NaZLCuXw3bR,XfOb4VIcPY,emrzEIsMWO2GLw9lpKxSY7n0F,'','','EGYBEST3-TITLES-3rd')
			ZCOosjaQ8x9HDKSVGM6LwW2vy = RoQL91PphqCJg4W0e6Fnsl.content
			ZCOosjaQ8x9HDKSVGM6LwW2vy = 'blocks'+ZCOosjaQ8x9HDKSVGM6LwW2vy+'article'
	items,wanHtPNKCfxdoyLFQV3j2RrSmvpBZ,cGYIMSHDj85d3f4ZW2t0bnNkKP = [],False,False
	if not type:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('main-content(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('href="(.*?)".*?</i>(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,title in items:
				title = title.strip(' ')
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,791,'','submenu')
				wanHtPNKCfxdoyLFQV3j2RrSmvpBZ = True
	if not type:
		cGYIMSHDj85d3f4ZW2t0bnNkKP = bbMyD8BfJLk5GT1HwIP9(oo9SgGkiDbs3HRn7z8)
	if not wanHtPNKCfxdoyLFQV3j2RrSmvpBZ and not cGYIMSHDj85d3f4ZW2t0bnNkKP:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('blocks(.*?)article',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
				pGjsvdyHfM = pGjsvdyHfM.strip('\n')
				ekTrZlFMu0Kf5QztEnhAs = P2o6ZDHeW790pSQqucvnxzILVUX(ekTrZlFMu0Kf5QztEnhAs)
				if '/selary/' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,791,pGjsvdyHfM)
				elif 'مسلسل' in ekTrZlFMu0Kf5QztEnhAs and 'حلقة' not in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,796,pGjsvdyHfM)
				elif 'موسم' in ekTrZlFMu0Kf5QztEnhAs and 'حلقة' not in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,796,pGjsvdyHfM)
				else: uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,793,pGjsvdyHfM)
		o7fQkCxH9djRYJlsFI = 12
		data = u5h2Rckvw1E.findall('class="(load-more.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if len(items)==o7fQkCxH9djRYJlsFI and (data or 'pagination' in type):
			XfOb4VIcPY = 'limit='+str(o7fQkCxH9djRYJlsFI)+'&start='+str(start+o7fQkCxH9djRYJlsFI)+'&type='+v6YLr90gxdTVfyG83J1XAzjiF+'&select='+select
			gANn35esloKUydOipfSMC6RD2 = Gk2NaZLCuXw3bR+'?next=page&'+XfOb4VIcPY
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'المزيد',gANn35esloKUydOipfSMC6RD2,791,'','pagination_'+type)
	return
def bbMyD8BfJLk5GT1HwIP9(oo9SgGkiDbs3HRn7z8):
	cGYIMSHDj85d3f4ZW2t0bnNkKP = False
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('main-article(.*?)article',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		ppZ9muD1GkPnFRX52jxBUIy = u5h2Rckvw1E.findall('data-tax="(.*?)".*?<span>(.*?)<(.*?)</ul>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if ppZ9muD1GkPnFRX52jxBUIy: uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		for oPrhaMp7AqmNnRjlXGI,name,lmO2YJGr6tCV in ppZ9muD1GkPnFRX52jxBUIy:
			name = name.strip(' ')
			items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,c2eEflztvIX in items:
				title = name+':  '+c2eEflztvIX
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,791,'','filter')
				cGYIMSHDj85d3f4ZW2t0bnNkKP = True
	return cGYIMSHDj85d3f4ZW2t0bnNkKP
def N5AOlmb8u1y4FHxvJXU(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'GET',url,'','','','','EGYBEST3-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	GnuaoT9MxiCg,ZIB1Cc3wFoi5xYNgOThn2mAM = [],[]
	items = u5h2Rckvw1E.findall('server-item.*?data-code="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	for nWxJ9ZDlByIVfYc1MiFtGp in items:
		vW3DbCl7jpyuIwe89T4AqG = yB3NPc2ZhbwFEi1X0dv.b64decode(nWxJ9ZDlByIVfYc1MiFtGp)
		if VVGRN7xiyj: vW3DbCl7jpyuIwe89T4AqG = vW3DbCl7jpyuIwe89T4AqG.decode('utf8')
		ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('src="(.*?)"',vW3DbCl7jpyuIwe89T4AqG,u5h2Rckvw1E.DOTALL)
		if ekTrZlFMu0Kf5QztEnhAs:
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs[0]
			if ekTrZlFMu0Kf5QztEnhAs not in ZIB1Cc3wFoi5xYNgOThn2mAM:
				ZIB1Cc3wFoi5xYNgOThn2mAM.append(ekTrZlFMu0Kf5QztEnhAs)
				NDwLctrHpYz3JBP = hmcFWJUgiAuGk(ekTrZlFMu0Kf5QztEnhAs,'name')
				GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs+'?named='+NDwLctrHpYz3JBP+'__watch')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="downloads(.*?)</section>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('"tr flex-start".*?<div>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</div>.*?href="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ohAHUqdbWFi8D1L4Xwzus0f3RYv,ekTrZlFMu0Kf5QztEnhAs in items:
			if ekTrZlFMu0Kf5QztEnhAs not in ZIB1Cc3wFoi5xYNgOThn2mAM:
				if '/?url=' in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.split('/?url=')[1]
				ZIB1Cc3wFoi5xYNgOThn2mAM.append(ekTrZlFMu0Kf5QztEnhAs)
				NDwLctrHpYz3JBP = hmcFWJUgiAuGk(ekTrZlFMu0Kf5QztEnhAs,'name')
				GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs+'?named='+NDwLctrHpYz3JBP+'__download____'+ohAHUqdbWFi8D1L4Xwzus0f3RYv)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(GnuaoT9MxiCg,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(text):
	return
# -*- coding: utf-8 -*-
from LXgKztbkOf import *
from PIL import ImageDraw as XXt3yJYkxgvLsRBpuhZPOH7wMIo,ImageFont as U0ecS5D43xq1XngdI97rjVThBf8,Image as ss4Y30c7iC
from arabic_reshaper import ArabicReshaper as cOXskFxRdQP
ERLBl7fGCXQYchpgj6d = 'EXCLUDES'
def t3tcrzZRal7pMJ1kvOWXU(WGy8jZubInXc7zRBJ5p,McKAIxa0FmojZk):
	McKAIxa0FmojZk = McKAIxa0FmojZk.replace('[COLOR FFC89008]','').replace(' [/COLOR]','')[1:]
	uQAv6RIznYGDjToPBd0b4K2x = u5h2Rckvw1E.findall('[a-zA-Z]',WGy8jZubInXc7zRBJ5p,u5h2Rckvw1E.DOTALL)
	if 'بحث IPTV - ' in WGy8jZubInXc7zRBJ5p: WGy8jZubInXc7zRBJ5p = WGy8jZubInXc7zRBJ5p.replace('بحث IPTV - ',RQ0HpOfhFDoJdtl+'بحث IPTV - '+RQ0HpOfhFDoJdtl)
	elif ' IPTV' in WGy8jZubInXc7zRBJ5p and McKAIxa0FmojZk=='IPT': WGy8jZubInXc7zRBJ5p = RQ0HpOfhFDoJdtl+WGy8jZubInXc7zRBJ5p
	elif 'بحث M3U - ' in WGy8jZubInXc7zRBJ5p: WGy8jZubInXc7zRBJ5p = WGy8jZubInXc7zRBJ5p.replace('بحث M3U - ',RQ0HpOfhFDoJdtl+'بحث M3U - '+RQ0HpOfhFDoJdtl)
	elif ' M3U' in WGy8jZubInXc7zRBJ5p and McKAIxa0FmojZk=='M3U': WGy8jZubInXc7zRBJ5p = RQ0HpOfhFDoJdtl+WGy8jZubInXc7zRBJ5p
	elif 'بحث ' in WGy8jZubInXc7zRBJ5p and ' - ' in WGy8jZubInXc7zRBJ5p: WGy8jZubInXc7zRBJ5p = RQ0HpOfhFDoJdtl+WGy8jZubInXc7zRBJ5p
	elif not uQAv6RIznYGDjToPBd0b4K2x:
		juSgZ4QF7GeX = u5h2Rckvw1E.findall('^( *?)(.*?)( *?)$',WGy8jZubInXc7zRBJ5p)
		MtvldDV4HobTJr1pW5jhwSZ0Ky9c,qqO7KEr3Hc,jjZ8cDLOC6sJ32iTm = juSgZ4QF7GeX[0]
		acxgkO3CLqdzjlinMsYmW7Xf = u5h2Rckvw1E.findall('^([!-~])',qqO7KEr3Hc)
		if acxgkO3CLqdzjlinMsYmW7Xf: WGy8jZubInXc7zRBJ5p = MtvldDV4HobTJr1pW5jhwSZ0Ky9c+Qa68jZXt0gBH+qqO7KEr3Hc+jjZ8cDLOC6sJ32iTm
		else: WGy8jZubInXc7zRBJ5p = jjZ8cDLOC6sJ32iTm+RQ0HpOfhFDoJdtl+qqO7KEr3Hc+MtvldDV4HobTJr1pW5jhwSZ0Ky9c
	else:
		if 1:
			tdKGqYQWzTHiflSBwrh1 = WGy8jZubInXc7zRBJ5p
			polPVE7Jmg5GcWA8tOqiCfF = k4rNW6UOwPBVDfblusx.get_display(WGy8jZubInXc7zRBJ5p,base_dir='L')
			if bdptXFc8UlIhA5jnGwPmKuv2L: tdKGqYQWzTHiflSBwrh1 = tdKGqYQWzTHiflSBwrh1.decode('utf8')
			if bdptXFc8UlIhA5jnGwPmKuv2L: polPVE7Jmg5GcWA8tOqiCfF = polPVE7Jmg5GcWA8tOqiCfF.decode('utf8')
			OonfbTpR4E2CmSvJZidItVky = tdKGqYQWzTHiflSBwrh1.split(' ')
			giwNVZhqPGYva5lcDxMI64QXpeS2rB = polPVE7Jmg5GcWA8tOqiCfF.split(' ')
			IkafXV1zYFjO2y3hG7,l4mfZ6UEdW7iKQ19NLqGebpugBaR,anf3pZYzQuLsyXAkw4qdNIxhOgD,wwoiNsbfI0B2n73cZ = [],[],'',''
			mmKHhnq0gMtbSpWz9sxkrjRYCJ = zip(OonfbTpR4E2CmSvJZidItVky,giwNVZhqPGYva5lcDxMI64QXpeS2rB)
			for rLdDmJ7OxushBE0cIS6nAUeifjW,e6boUuF9E3 in mmKHhnq0gMtbSpWz9sxkrjRYCJ:
				if rLdDmJ7OxushBE0cIS6nAUeifjW==e6boUuF9E3=='' and wwoiNsbfI0B2n73cZ:
					anf3pZYzQuLsyXAkw4qdNIxhOgD += ' '
					continue
				if rLdDmJ7OxushBE0cIS6nAUeifjW==e6boUuF9E3:
					OOiy8zcVsBAY = 'EN'
					if wwoiNsbfI0B2n73cZ==OOiy8zcVsBAY: anf3pZYzQuLsyXAkw4qdNIxhOgD += ' '+rLdDmJ7OxushBE0cIS6nAUeifjW
					elif rLdDmJ7OxushBE0cIS6nAUeifjW:
						if anf3pZYzQuLsyXAkw4qdNIxhOgD:
							l4mfZ6UEdW7iKQ19NLqGebpugBaR.append(anf3pZYzQuLsyXAkw4qdNIxhOgD)
							IkafXV1zYFjO2y3hG7.append('')
						anf3pZYzQuLsyXAkw4qdNIxhOgD = rLdDmJ7OxushBE0cIS6nAUeifjW
				else:
					OOiy8zcVsBAY = 'AR'
					if wwoiNsbfI0B2n73cZ==OOiy8zcVsBAY: anf3pZYzQuLsyXAkw4qdNIxhOgD += ' '+rLdDmJ7OxushBE0cIS6nAUeifjW
					elif rLdDmJ7OxushBE0cIS6nAUeifjW:
						if anf3pZYzQuLsyXAkw4qdNIxhOgD:
							IkafXV1zYFjO2y3hG7.append(anf3pZYzQuLsyXAkw4qdNIxhOgD)
							l4mfZ6UEdW7iKQ19NLqGebpugBaR.append('')
						anf3pZYzQuLsyXAkw4qdNIxhOgD = rLdDmJ7OxushBE0cIS6nAUeifjW
				wwoiNsbfI0B2n73cZ = OOiy8zcVsBAY
			if OOiy8zcVsBAY=='EN':
				IkafXV1zYFjO2y3hG7.append(anf3pZYzQuLsyXAkw4qdNIxhOgD)
				l4mfZ6UEdW7iKQ19NLqGebpugBaR.append('')
			else:
				l4mfZ6UEdW7iKQ19NLqGebpugBaR.append(anf3pZYzQuLsyXAkw4qdNIxhOgD)
				IkafXV1zYFjO2y3hG7.append('')
			zZANXY68IsSrR9KG54cDL0JubUHP3 = ''
			mmKHhnq0gMtbSpWz9sxkrjRYCJ = zip(IkafXV1zYFjO2y3hG7,l4mfZ6UEdW7iKQ19NLqGebpugBaR)
			for Cek85ryxsJ9cqwDb7,XB6UE1Iwh8xZPMDta5dbi29zAsr in mmKHhnq0gMtbSpWz9sxkrjRYCJ:
				if Cek85ryxsJ9cqwDb7: zZANXY68IsSrR9KG54cDL0JubUHP3 += ' '+Cek85ryxsJ9cqwDb7
				else:
					acxgkO3CLqdzjlinMsYmW7Xf = u5h2Rckvw1E.findall('([!-~]) *$',XB6UE1Iwh8xZPMDta5dbi29zAsr)
					if acxgkO3CLqdzjlinMsYmW7Xf:
						acxgkO3CLqdzjlinMsYmW7Xf = acxgkO3CLqdzjlinMsYmW7Xf[0]
						try:
							EeBbcCUhKX0Z89WfjH6wS7M = A1hKHsUSl405QF6rGyIiPWEBpk.MIRRORED[acxgkO3CLqdzjlinMsYmW7Xf]
							juSgZ4QF7GeX = u5h2Rckvw1E.findall('^( *?)(.*?)( *?)$',XB6UE1Iwh8xZPMDta5dbi29zAsr)
							if juSgZ4QF7GeX: MtvldDV4HobTJr1pW5jhwSZ0Ky9c,XB6UE1Iwh8xZPMDta5dbi29zAsr,jjZ8cDLOC6sJ32iTm = juSgZ4QF7GeX[0]
							XB6UE1Iwh8xZPMDta5dbi29zAsr = MtvldDV4HobTJr1pW5jhwSZ0Ky9c+EeBbcCUhKX0Z89WfjH6wS7M+XB6UE1Iwh8xZPMDta5dbi29zAsr[:-1]+jjZ8cDLOC6sJ32iTm
						except: pass
					zZANXY68IsSrR9KG54cDL0JubUHP3 += ' '+XB6UE1Iwh8xZPMDta5dbi29zAsr
			WGy8jZubInXc7zRBJ5p = zZANXY68IsSrR9KG54cDL0JubUHP3[1:]
			if bdptXFc8UlIhA5jnGwPmKuv2L: WGy8jZubInXc7zRBJ5p = WGy8jZubInXc7zRBJ5p.encode('utf8')
		else:
			if bdptXFc8UlIhA5jnGwPmKuv2L: WGy8jZubInXc7zRBJ5p = WGy8jZubInXc7zRBJ5p.decode('utf8')
			WGy8jZubInXc7zRBJ5p = k4rNW6UOwPBVDfblusx.get_display(WGy8jZubInXc7zRBJ5p)
			tdKGqYQWzTHiflSBwrh1,polPVE7Jmg5GcWA8tOqiCfF = WGy8jZubInXc7zRBJ5p,WGy8jZubInXc7zRBJ5p
			if 1:
				wwoiNsbfI0B2n73cZ,FAqkflJsb9cVadNEixMSD5oWK = '',[]
				yyLHXxIQDj2S10f = WGy8jZubInXc7zRBJ5p.split(' ')
				for l8lTcPnLqj6Y2QpmyrJ in yyLHXxIQDj2S10f:
					if not l8lTcPnLqj6Y2QpmyrJ:
						if FAqkflJsb9cVadNEixMSD5oWK: FAqkflJsb9cVadNEixMSD5oWK[-1] += ' '
						else: FAqkflJsb9cVadNEixMSD5oWK.append('')
						continue
					TTagnc6HzNAi7MEXL = u5h2Rckvw1E.findall('[!-~]',l8lTcPnLqj6Y2QpmyrJ[0])
					if TTagnc6HzNAi7MEXL==wwoiNsbfI0B2n73cZ and FAqkflJsb9cVadNEixMSD5oWK: FAqkflJsb9cVadNEixMSD5oWK[-1] += ' '+l8lTcPnLqj6Y2QpmyrJ
					else:
						if FAqkflJsb9cVadNEixMSD5oWK:
							GnVysxSwcWiXIMHtP8jeEgTao = u5h2Rckvw1E.findall('[^!-~]',FAqkflJsb9cVadNEixMSD5oWK[-1])
							if GnVysxSwcWiXIMHtP8jeEgTao:
								FAqkflJsb9cVadNEixMSD5oWK[-1] = k4rNW6UOwPBVDfblusx.get_display(FAqkflJsb9cVadNEixMSD5oWK[-1])
								zz3LYAl9dXyBUw = u5h2Rckvw1E.findall('^ +',FAqkflJsb9cVadNEixMSD5oWK[-1])
								if zz3LYAl9dXyBUw: FAqkflJsb9cVadNEixMSD5oWK[-1] = FAqkflJsb9cVadNEixMSD5oWK[-1].lstrip(' ')+zz3LYAl9dXyBUw[0]
						FAqkflJsb9cVadNEixMSD5oWK.append(l8lTcPnLqj6Y2QpmyrJ)
					wwoiNsbfI0B2n73cZ = TTagnc6HzNAi7MEXL
				if FAqkflJsb9cVadNEixMSD5oWK: FAqkflJsb9cVadNEixMSD5oWK[-1] = k4rNW6UOwPBVDfblusx.get_display(FAqkflJsb9cVadNEixMSD5oWK[-1])
				WGy8jZubInXc7zRBJ5p = ' '.join(FAqkflJsb9cVadNEixMSD5oWK)
			if bdptXFc8UlIhA5jnGwPmKuv2L: WGy8jZubInXc7zRBJ5p = WGy8jZubInXc7zRBJ5p.encode('utf8')
	return WGy8jZubInXc7zRBJ5p
def hUXKd31miaLR7D5n(j57TcVZpeogCman,dF3oUjzt0GykPQV2gs,DhLHgCwaQT):
	f0QP7qXsU4L9xtB,WGy8jZubInXc7zRBJ5p,GZdtFyDU0caf89r,wMCm6g9qFyPT0xpneDUNc2lEhaZY,qRSNaY0t83hO9ofLEnJuAM1,xHsnNCykrO3R54D8Z,ChO2Gxyb3zZnAKqmtRcsuP,wWXVYjrFaCg9zpboThAMQBU8iHJc,isbQc5EtyP76zR = j57TcVZpeogCman
	wMCm6g9qFyPT0xpneDUNc2lEhaZY = int(wMCm6g9qFyPT0xpneDUNc2lEhaZY)
	UJnsuIybhNQZaoqXexmL30AdRB6MpH = u5h2Rckvw1E.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',WGy8jZubInXc7zRBJ5p,u5h2Rckvw1E.DOTALL)
	if UJnsuIybhNQZaoqXexmL30AdRB6MpH:
		UJnsuIybhNQZaoqXexmL30AdRB6MpH,vYEKtBnNyLl0J6dDMH8CGQwkZ,cThosMPpJLZ158m3UVASzntja = UJnsuIybhNQZaoqXexmL30AdRB6MpH[0]
		WGy8jZubInXc7zRBJ5p = WGy8jZubInXc7zRBJ5p.replace(UJnsuIybhNQZaoqXexmL30AdRB6MpH,'')
	MCYgdHEux2 = WGy8jZubInXc7zRBJ5p
	McKAIxa0FmojZk = u5h2Rckvw1E.findall('^_(\w\w\w)_(.*?)$',WGy8jZubInXc7zRBJ5p,u5h2Rckvw1E.DOTALL)
	if McKAIxa0FmojZk:
		McKAIxa0FmojZk,WGy8jZubInXc7zRBJ5p = McKAIxa0FmojZk[0]
		L3U5HZsQajGYh24P1tmfewlMWJyx9 = '_MOD_' in WGy8jZubInXc7zRBJ5p
		nCSJkub4hZM3dH1KpRIUr8a7tBNevE = f0QP7qXsU4L9xtB=='folder'
		if L3U5HZsQajGYh24P1tmfewlMWJyx9 and nCSJkub4hZM3dH1KpRIUr8a7tBNevE: kRnixKJ5qH2LF9I = ';'
		elif L3U5HZsQajGYh24P1tmfewlMWJyx9 and not nCSJkub4hZM3dH1KpRIUr8a7tBNevE: kRnixKJ5qH2LF9I = Rzh5Iv8cO0AGFq9D
		elif not L3U5HZsQajGYh24P1tmfewlMWJyx9 and nCSJkub4hZM3dH1KpRIUr8a7tBNevE: kRnixKJ5qH2LF9I = ','
		elif not L3U5HZsQajGYh24P1tmfewlMWJyx9 and not nCSJkub4hZM3dH1KpRIUr8a7tBNevE: kRnixKJ5qH2LF9I = ' '
		WGy8jZubInXc7zRBJ5p = WGy8jZubInXc7zRBJ5p.replace('_MOD_','')
		McKAIxa0FmojZk = kRnixKJ5qH2LF9I+'[COLOR FFC89008]'+McKAIxa0FmojZk+' [/COLOR]'
	else: McKAIxa0FmojZk = ''
	if UJnsuIybhNQZaoqXexmL30AdRB6MpH:
		if bdptXFc8UlIhA5jnGwPmKuv2L:
			UJnsuIybhNQZaoqXexmL30AdRB6MpH = '[COLOR FFFFFF00]'+vYEKtBnNyLl0J6dDMH8CGQwkZ+' '+cThosMPpJLZ158m3UVASzntja+'[/COLOR]'
			if McKAIxa0FmojZk: WGy8jZubInXc7zRBJ5p = UJnsuIybhNQZaoqXexmL30AdRB6MpH+' '+RQ0HpOfhFDoJdtl+McKAIxa0FmojZk+WGy8jZubInXc7zRBJ5p
			else: WGy8jZubInXc7zRBJ5p = UJnsuIybhNQZaoqXexmL30AdRB6MpH+RQ0HpOfhFDoJdtl+WGy8jZubInXc7zRBJ5p+' '
		elif VVGRN7xiyj:
			if McKAIxa0FmojZk:
				UJnsuIybhNQZaoqXexmL30AdRB6MpH = '[COLOR FFFFFF00]'+vYEKtBnNyLl0J6dDMH8CGQwkZ+' '+cThosMPpJLZ158m3UVASzntja+'[/COLOR]'
				WGy8jZubInXc7zRBJ5p = UJnsuIybhNQZaoqXexmL30AdRB6MpH+' '+McKAIxa0FmojZk+WGy8jZubInXc7zRBJ5p
			else:
				UJnsuIybhNQZaoqXexmL30AdRB6MpH = '[COLOR FFFFFF00]'+cThosMPpJLZ158m3UVASzntja+' '+vYEKtBnNyLl0J6dDMH8CGQwkZ+'[/COLOR]'
				WGy8jZubInXc7zRBJ5p = WGy8jZubInXc7zRBJ5p+' '+RQ0HpOfhFDoJdtl+UJnsuIybhNQZaoqXexmL30AdRB6MpH
	elif McKAIxa0FmojZk:
		WGy8jZubInXc7zRBJ5p = t3tcrzZRal7pMJ1kvOWXU(WGy8jZubInXc7zRBJ5p,McKAIxa0FmojZk)
		WGy8jZubInXc7zRBJ5p = McKAIxa0FmojZk+WGy8jZubInXc7zRBJ5p
	j57TcVZpeogCman = f0QP7qXsU4L9xtB,MCYgdHEux2,GZdtFyDU0caf89r,str(wMCm6g9qFyPT0xpneDUNc2lEhaZY),qRSNaY0t83hO9ofLEnJuAM1,xHsnNCykrO3R54D8Z,ChO2Gxyb3zZnAKqmtRcsuP,wWXVYjrFaCg9zpboThAMQBU8iHJc,isbQc5EtyP76zR
	OTngJvae8UQ = {'type':'','mode':'','url':'','text':'','page':'','name':'','image':'','context':'','infodict':''}
	OTngJvae8UQ['name'] = QQXTVNve6DMHBp4scG170kR2lWY(MCYgdHEux2)
	OTngJvae8UQ['type'] = f0QP7qXsU4L9xtB.strip(' ')
	OTngJvae8UQ['mode'] = str(wMCm6g9qFyPT0xpneDUNc2lEhaZY).strip(' ')
	if f0QP7qXsU4L9xtB=='folder' and xHsnNCykrO3R54D8Z: OTngJvae8UQ['page'] = QQXTVNve6DMHBp4scG170kR2lWY(xHsnNCykrO3R54D8Z.strip(' '))
	if wWXVYjrFaCg9zpboThAMQBU8iHJc: OTngJvae8UQ['context'] = wWXVYjrFaCg9zpboThAMQBU8iHJc.strip(' ')
	if ChO2Gxyb3zZnAKqmtRcsuP: OTngJvae8UQ['text'] = QQXTVNve6DMHBp4scG170kR2lWY(ChO2Gxyb3zZnAKqmtRcsuP.strip(' '))
	if qRSNaY0t83hO9ofLEnJuAM1: OTngJvae8UQ['image'] = QQXTVNve6DMHBp4scG170kR2lWY(qRSNaY0t83hO9ofLEnJuAM1.strip(' '))
	if isbQc5EtyP76zR:
		isbQc5EtyP76zR = str(isbQc5EtyP76zR)
		OTngJvae8UQ['infodict'] = QQXTVNve6DMHBp4scG170kR2lWY(isbQc5EtyP76zR.strip(' '))
		isbQc5EtyP76zR = eval(isbQc5EtyP76zR)
	else: isbQc5EtyP76zR = {}
	if GZdtFyDU0caf89r: OTngJvae8UQ['url'] = QQXTVNve6DMHBp4scG170kR2lWY(GZdtFyDU0caf89r.strip(' '))
	HTnUrN6eW9 = {'name':'','context_menu':'','plot':'','stars':'','image':'','type':'','isFolder':'','newpath':'','duration':''}
	mAboFLiZsCfr6c = []
	CPNXrI4FLo = 'plugin://'+lY0rst72uGVZ1NkgvpjfA6x+'/?type='+OTngJvae8UQ['type']+'&mode='+OTngJvae8UQ['mode']
	if OTngJvae8UQ['page']: CPNXrI4FLo += '&page='+OTngJvae8UQ['page']
	if OTngJvae8UQ['name']: CPNXrI4FLo += '&name='+OTngJvae8UQ['name']
	if OTngJvae8UQ['text']: CPNXrI4FLo += '&text='+OTngJvae8UQ['text']
	if OTngJvae8UQ['infodict']: CPNXrI4FLo += '&infodict='+OTngJvae8UQ['infodict']
	if OTngJvae8UQ['image']: CPNXrI4FLo += '&image='+OTngJvae8UQ['image']
	if OTngJvae8UQ['url']: CPNXrI4FLo += '&url='+OTngJvae8UQ['url']
	if wMCm6g9qFyPT0xpneDUNc2lEhaZY!=265: HTnUrN6eW9['favorites'] = True
	else: HTnUrN6eW9['favorites'] = False
	if OTngJvae8UQ['context']: CPNXrI4FLo += '&context='+OTngJvae8UQ['context']
	if wMCm6g9qFyPT0xpneDUNc2lEhaZY in [235,238] and f0QP7qXsU4L9xtB=='live' and 'EPG' in wWXVYjrFaCg9zpboThAMQBU8iHJc:
		buTjCQHI6ZdPpraUzn2 = 'plugin://'+lY0rst72uGVZ1NkgvpjfA6x+'?mode=238&text=SHORT_EPG&url='+GZdtFyDU0caf89r
		MhVc738bea2zf5gySpnI4ZOY = '[COLOR FFFFFF00]البرامج القادمة[/COLOR]'
		t6hsORq7MaLnVrzo39TmX4 = (MhVc738bea2zf5gySpnI4ZOY,'RunPlugin('+buTjCQHI6ZdPpraUzn2+')')
		mAboFLiZsCfr6c.append(t6hsORq7MaLnVrzo39TmX4)
	if wMCm6g9qFyPT0xpneDUNc2lEhaZY==265:
		kZNrfX1yVc3n0jl8wOEx7 = dF3oUjzt0GykPQV2gs(ChO2Gxyb3zZnAKqmtRcsuP,True)
		if kZNrfX1yVc3n0jl8wOEx7>0:
			buTjCQHI6ZdPpraUzn2 = 'plugin://'+lY0rst72uGVZ1NkgvpjfA6x+'?mode=266&text='+ChO2Gxyb3zZnAKqmtRcsuP
			MhVc738bea2zf5gySpnI4ZOY = '[COLOR FFFFFF00]مسح قائمة آخر 50 '+wSH84vUOuxYjoQ3aPBeAEZ(ChO2Gxyb3zZnAKqmtRcsuP)+'[/COLOR]'
			t6hsORq7MaLnVrzo39TmX4 = (MhVc738bea2zf5gySpnI4ZOY,'RunPlugin('+buTjCQHI6ZdPpraUzn2+')')
			mAboFLiZsCfr6c.append(t6hsORq7MaLnVrzo39TmX4)
	if f0QP7qXsU4L9xtB=='video' and wMCm6g9qFyPT0xpneDUNc2lEhaZY!=331:
		buTjCQHI6ZdPpraUzn2 = CPNXrI4FLo+'&context=6_DOWNLOAD'
		MhVc738bea2zf5gySpnI4ZOY = '[COLOR FFFFFF00]تحميل ملف الفيديو[/COLOR]'
		t6hsORq7MaLnVrzo39TmX4 = (MhVc738bea2zf5gySpnI4ZOY,'RunPlugin('+buTjCQHI6ZdPpraUzn2+')')
		mAboFLiZsCfr6c.append(t6hsORq7MaLnVrzo39TmX4)
	if wMCm6g9qFyPT0xpneDUNc2lEhaZY==331:
		buTjCQHI6ZdPpraUzn2 = CPNXrI4FLo+'&context=6_DELETE'
		MhVc738bea2zf5gySpnI4ZOY = '[COLOR FFFFFF00]حذف ملف الفيديو[/COLOR]'
		t6hsORq7MaLnVrzo39TmX4 = (MhVc738bea2zf5gySpnI4ZOY,'RunPlugin('+buTjCQHI6ZdPpraUzn2+')')
		mAboFLiZsCfr6c.append(t6hsORq7MaLnVrzo39TmX4)
	if f0QP7qXsU4L9xtB=='folder' and wMCm6g9qFyPT0xpneDUNc2lEhaZY==540:
		pp2evmc8B0LdjgHfrYFKMOawJlC = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,'list','GLOBALSEARCH_SITES')
		if pp2evmc8B0LdjgHfrYFKMOawJlC:
			buTjCQHI6ZdPpraUzn2 = 'plugin://'+lY0rst72uGVZ1NkgvpjfA6x+'?context=7'
			MhVc738bea2zf5gySpnI4ZOY = '[COLOR FFFFFF00]مسح جميع كلمات البحث[/COLOR]'
			t6hsORq7MaLnVrzo39TmX4 = (MhVc738bea2zf5gySpnI4ZOY,'RunPlugin('+buTjCQHI6ZdPpraUzn2+')')
			mAboFLiZsCfr6c.append(t6hsORq7MaLnVrzo39TmX4)
	PnjfidLaBUxK = [9990,2,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,540,710,719,761,762]
	if wMCm6g9qFyPT0xpneDUNc2lEhaZY not in PnjfidLaBUxK:
		buTjCQHI6ZdPpraUzn2 = 'plugin://'+lY0rst72uGVZ1NkgvpjfA6x+'?context=8&mode=260'
		MhVc738bea2zf5gySpnI4ZOY = '[COLOR FFFFFF00]ذهاب للقائمة الرئيسية[/COLOR]'
		t6hsORq7MaLnVrzo39TmX4 = (MhVc738bea2zf5gySpnI4ZOY,'RunPlugin('+buTjCQHI6ZdPpraUzn2+')')
		mAboFLiZsCfr6c.append(t6hsORq7MaLnVrzo39TmX4)
	fZWM16z8KxiyNnF = [0,150,160,170,190,260,280,330,340,410,500,520,530,560,760]
	if wMCm6g9qFyPT0xpneDUNc2lEhaZY%10 and wMCm6g9qFyPT0xpneDUNc2lEhaZY!=9990:
		Gg26WlvhRTS4xdbfiP = wMCm6g9qFyPT0xpneDUNc2lEhaZY-wMCm6g9qFyPT0xpneDUNc2lEhaZY%10
		if Gg26WlvhRTS4xdbfiP==280: Gg26WlvhRTS4xdbfiP = 230
		if Gg26WlvhRTS4xdbfiP==410: Gg26WlvhRTS4xdbfiP = 400
		if Gg26WlvhRTS4xdbfiP==520: Gg26WlvhRTS4xdbfiP = 510
		if Gg26WlvhRTS4xdbfiP not in fZWM16z8KxiyNnF:
			buTjCQHI6ZdPpraUzn2 = 'plugin://'+lY0rst72uGVZ1NkgvpjfA6x+'?context=8&mode='+str(Gg26WlvhRTS4xdbfiP)
			MhVc738bea2zf5gySpnI4ZOY = '[COLOR FFFFFF00]ذهاب لبداية الموقع[/COLOR]'
			t6hsORq7MaLnVrzo39TmX4 = (MhVc738bea2zf5gySpnI4ZOY,'RunPlugin('+buTjCQHI6ZdPpraUzn2+')')
			mAboFLiZsCfr6c.append(t6hsORq7MaLnVrzo39TmX4)
	buTjCQHI6ZdPpraUzn2 = CPNXrI4FLo+'&context=9'
	MhVc738bea2zf5gySpnI4ZOY = '[COLOR FFFFFF00]تحديث القائمة الحالية[/COLOR]'
	t6hsORq7MaLnVrzo39TmX4 = (MhVc738bea2zf5gySpnI4ZOY,'RunPlugin('+buTjCQHI6ZdPpraUzn2+')')
	mAboFLiZsCfr6c.append(t6hsORq7MaLnVrzo39TmX4)
	if f0QP7qXsU4L9xtB in ['link','video','live']: Ma8QoD2eqZiUjpv6I = False
	elif f0QP7qXsU4L9xtB=='folder': Ma8QoD2eqZiUjpv6I = True
	HTnUrN6eW9['name'] = WGy8jZubInXc7zRBJ5p
	HTnUrN6eW9['context_menu'] = mAboFLiZsCfr6c
	if 'plot' in list(isbQc5EtyP76zR.keys()): HTnUrN6eW9['plot'] = isbQc5EtyP76zR['plot']
	if 'stars' in list(isbQc5EtyP76zR.keys()): HTnUrN6eW9['stars'] = isbQc5EtyP76zR['stars']
	if qRSNaY0t83hO9ofLEnJuAM1: HTnUrN6eW9['image'] = qRSNaY0t83hO9ofLEnJuAM1
	if f0QP7qXsU4L9xtB=='video' and xHsnNCykrO3R54D8Z:
		WoZL2urv9CfqaGN08w3mTMcE7SQJ = u5h2Rckvw1E.findall('[\d:]+',xHsnNCykrO3R54D8Z,u5h2Rckvw1E.DOTALL)
		if WoZL2urv9CfqaGN08w3mTMcE7SQJ:
			WoZL2urv9CfqaGN08w3mTMcE7SQJ = '0:0:0:0:0:'+WoZL2urv9CfqaGN08w3mTMcE7SQJ[0]
			ir74YTmhPq,loa8N64jInDtwVGgJShumW17,m0ScdNoPinY3hEQ,gzOk2jsAw4oSW8bdJ,yqNz3axHLIpiFT0EMBJ2cfZolC = WoZL2urv9CfqaGN08w3mTMcE7SQJ.rsplit(':',4)
			xjifa96n7btVIYSU1C2 = int(loa8N64jInDtwVGgJShumW17)*24*PPC3GlfZAh68+int(m0ScdNoPinY3hEQ)*PPC3GlfZAh68+int(gzOk2jsAw4oSW8bdJ)*60+int(yqNz3axHLIpiFT0EMBJ2cfZolC)
			HTnUrN6eW9['duration'] = xjifa96n7btVIYSU1C2
	HTnUrN6eW9['type'] = f0QP7qXsU4L9xtB
	HTnUrN6eW9['isFolder'] = Ma8QoD2eqZiUjpv6I
	HTnUrN6eW9['newpath'] = CPNXrI4FLo
	HTnUrN6eW9['menuItem'] = j57TcVZpeogCman
	HTnUrN6eW9['mode'] = wMCm6g9qFyPT0xpneDUNc2lEhaZY
	return HTnUrN6eW9
def HHiE1gsb4RkfK6VdI9(dF3oUjzt0GykPQV2gs):
	YxWBk13jlNRXnAie4FvI = []
	from UdzJNcmQS6 import ZIm7yNwq0DtAUbXso9Rd5hOPK,ffgDZB3bA9jHxR
	DhLHgCwaQT = ZIm7yNwq0DtAUbXso9Rd5hOPK()
	for j57TcVZpeogCman in YD56nkJmsd:
		HTnUrN6eW9 = hUXKd31miaLR7D5n(j57TcVZpeogCman,dF3oUjzt0GykPQV2gs,DhLHgCwaQT)
		if HTnUrN6eW9['favorites']:
			llRZIPHfDvAEbNhBOFcXs = ffgDZB3bA9jHxR(DhLHgCwaQT,HTnUrN6eW9['menuItem'],HTnUrN6eW9['newpath'])
			HTnUrN6eW9['context_menu'] = llRZIPHfDvAEbNhBOFcXs+HTnUrN6eW9['context_menu']
		YxWBk13jlNRXnAie4FvI.append(HTnUrN6eW9)
	return YxWBk13jlNRXnAie4FvI
def frFK84pCo1VZwd6AnabHLDSP(Dxe4mO65obSHMKrlWsjwvX):
	kRnixKJ5qH2LF9I,cR5ebBnQaqCO1pjKUx9gWuizE, = [],''
	for Bx1JlohpcEg in Dxe4mO65obSHMKrlWsjwvX:
		if not Bx1JlohpcEg: kRnixKJ5qH2LF9I.append('')
		else: break
	Dxe4mO65obSHMKrlWsjwvX = Dxe4mO65obSHMKrlWsjwvX[len(kRnixKJ5qH2LF9I):]
	kc57B93HrojbDIXVipY = '\n\n\n\n'.join(Dxe4mO65obSHMKrlWsjwvX)
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('===== ===== =====','000001')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('[COLOR FFC89008]','000002')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('[COLOR FFFFFF00]','000003')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('[/COLOR]','000004')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('[RIGHT]','000005')
	R2RD7JlOtrWXIFNgVnY0a5iwZp = 100000
	m1xTWDucesHFKajI7B = {}
	O6liEYFwuNXdHM1aWVg = u5h2Rckvw1E.findall('http.*?[\r\n ]',kc57B93HrojbDIXVipY,u5h2Rckvw1E.DOTALL)
	for prSkFtBQJmjZbv59hUsx6 in O6liEYFwuNXdHM1aWVg:
		R2RD7JlOtrWXIFNgVnY0a5iwZp += 1
		kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace(prSkFtBQJmjZbv59hUsx6,str(R2RD7JlOtrWXIFNgVnY0a5iwZp))
		m1xTWDucesHFKajI7B[str(R2RD7JlOtrWXIFNgVnY0a5iwZp)] = prSkFtBQJmjZbv59hUsx6
	for OTxp2K4Vayb8CoUFJSWA in range(0,len(kc57B93HrojbDIXVipY),4800):
		uZKf6t78BCsn2H = kc57B93HrojbDIXVipY[OTxp2K4Vayb8CoUFJSWA:OTxp2K4Vayb8CoUFJSWA+4800]
		m7gcw3bAeD4 = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.language.code')
		GZdtFyDU0caf89r = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+m7gcw3bAeD4
		v1vaBXhQE6tsCjV73HkrNUpgI9DZK = {'Content-Type':'text/plain'}
		TvaUZzcHJK = uZKf6t78BCsn2H.encode('utf8')
		UyA2NgE6DjKsBRqMILZv5tXJ = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'POST',GZdtFyDU0caf89r,TvaUZzcHJK,v1vaBXhQE6tsCjV73HkrNUpgI9DZK,'','','LIBRARY-GLOSBE_TRANSLATE-1st')
		if UyA2NgE6DjKsBRqMILZv5tXJ.succeeded:
			AxqI1TVGKPOjaYfE7F2ZH = UyA2NgE6DjKsBRqMILZv5tXJ.content
			kkGcjiLDWaQHN7v1PUxOMS4 = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('str',AxqI1TVGKPOjaYfE7F2ZH)
			if kkGcjiLDWaQHN7v1PUxOMS4:
				kkGcjiLDWaQHN7v1PUxOMS4 = kkGcjiLDWaQHN7v1PUxOMS4['translation']
				kkGcjiLDWaQHN7v1PUxOMS4 = ffbxegm1XPSqIwp8i(kkGcjiLDWaQHN7v1PUxOMS4)
				for z5GRTewnrMpxQLjKoE in range(len(kkGcjiLDWaQHN7v1PUxOMS4)):
					cR5ebBnQaqCO1pjKUx9gWuizE += kkGcjiLDWaQHN7v1PUxOMS4[z5GRTewnrMpxQLjKoE][0]
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.replace('000001','===== ===== =====')
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.replace('000002','[COLOR FFC89008]')
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.replace('000003','[COLOR FFFFFF00]')
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.replace('000004','[/COLOR]')
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.replace('000005','[RIGHT]')
	for R2RD7JlOtrWXIFNgVnY0a5iwZp in list(m1xTWDucesHFKajI7B.keys()):
		prSkFtBQJmjZbv59hUsx6 = m1xTWDucesHFKajI7B[R2RD7JlOtrWXIFNgVnY0a5iwZp]
		cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.replace(R2RD7JlOtrWXIFNgVnY0a5iwZp,prSkFtBQJmjZbv59hUsx6)
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.split('\n\n\n\n')
	return kRnixKJ5qH2LF9I+cR5ebBnQaqCO1pjKUx9gWuizE
def f1fkE8oPt5Ili4dOevG0bjwWcAZDX(Dxe4mO65obSHMKrlWsjwvX):
	kRnixKJ5qH2LF9I,cR5ebBnQaqCO1pjKUx9gWuizE, = [],''
	for Bx1JlohpcEg in Dxe4mO65obSHMKrlWsjwvX:
		if not Bx1JlohpcEg: kRnixKJ5qH2LF9I.append('')
		else: break
	Dxe4mO65obSHMKrlWsjwvX = Dxe4mO65obSHMKrlWsjwvX[len(kRnixKJ5qH2LF9I):]
	kc57B93HrojbDIXVipY = '\\n\\n\\n\\n'.join(Dxe4mO65obSHMKrlWsjwvX)
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('كلا','no')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('استمرار','continue')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('===== ===== =====','000001')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('[COLOR FFC89008]','000002')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('[COLOR FFFFFF00]','000003')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('[/COLOR]','000004')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('[RIGHT]','000005')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('[CENTER]','000006')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('[RTL]','000007')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace("'","\\\\\\'")
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('"','\\\\\\"')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('\n','\\n')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('\r','\\\\r')
	for OTxp2K4Vayb8CoUFJSWA in range(0,len(kc57B93HrojbDIXVipY),4800):
		uZKf6t78BCsn2H = kc57B93HrojbDIXVipY[OTxp2K4Vayb8CoUFJSWA:OTxp2K4Vayb8CoUFJSWA+4800]
		GZdtFyDU0caf89r = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		v1vaBXhQE6tsCjV73HkrNUpgI9DZK = {'Content-Type':'application/x-www-form-urlencoded'}
		m7gcw3bAeD4 = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.language.code')
		TvaUZzcHJK = 'f.req='+QQXTVNve6DMHBp4scG170kR2lWY('[[["MkEWBc","[[\\"'+uZKf6t78BCsn2H+'\\",\\"ar\\",\\"'+m7gcw3bAeD4+'\\",1],[]]",null,"generic"]]]','')
		TvaUZzcHJK = TvaUZzcHJK.replace('%5Cn','%5C%5Cn')
		UyA2NgE6DjKsBRqMILZv5tXJ = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'POST',GZdtFyDU0caf89r,TvaUZzcHJK,v1vaBXhQE6tsCjV73HkrNUpgI9DZK,'','','LIBRARY-GOOGLE_TRANSLATE-1st')
		if UyA2NgE6DjKsBRqMILZv5tXJ.succeeded:
			AxqI1TVGKPOjaYfE7F2ZH = UyA2NgE6DjKsBRqMILZv5tXJ.content
			AxqI1TVGKPOjaYfE7F2ZH = AxqI1TVGKPOjaYfE7F2ZH.split('\n')[-1]
			kkGcjiLDWaQHN7v1PUxOMS4 = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('str',AxqI1TVGKPOjaYfE7F2ZH)[0][2]
			if kkGcjiLDWaQHN7v1PUxOMS4:
				kkGcjiLDWaQHN7v1PUxOMS4 = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('str',kkGcjiLDWaQHN7v1PUxOMS4)[1][0][0][5]
				kkGcjiLDWaQHN7v1PUxOMS4 = ffbxegm1XPSqIwp8i(kkGcjiLDWaQHN7v1PUxOMS4)
				for z5GRTewnrMpxQLjKoE in range(len(kkGcjiLDWaQHN7v1PUxOMS4)):
					cR5ebBnQaqCO1pjKUx9gWuizE += kkGcjiLDWaQHN7v1PUxOMS4[z5GRTewnrMpxQLjKoE][0]
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.replace('00000','0000').replace('0000','000')
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.replace('0001','===== ===== =====')
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.replace('0002','[COLOR FFC89008]')
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.replace('0003','[COLOR FFFFFF00]')
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.replace('0004','[/COLOR]')
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.replace('0005','[RIGHT]')
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.replace('0006','[CENTER]')
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.replace('0007','[RTL]')
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.split('\n\n\n\n')
	return kRnixKJ5qH2LF9I+cR5ebBnQaqCO1pjKUx9gWuizE
def nxmGVbvWlg(Dxe4mO65obSHMKrlWsjwvX):
	kRnixKJ5qH2LF9I,AANSbMO8jqdz5JVrEIDKFim = [],[]
	for Bx1JlohpcEg in Dxe4mO65obSHMKrlWsjwvX:
		if not Bx1JlohpcEg: kRnixKJ5qH2LF9I.append('')
		else: break
	Dxe4mO65obSHMKrlWsjwvX = Dxe4mO65obSHMKrlWsjwvX[len(kRnixKJ5qH2LF9I):]
	kc57B93HrojbDIXVipY = '\n\n\n\n'.join(Dxe4mO65obSHMKrlWsjwvX)
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('كلا','no')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('استمرار','continue')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('أدناه','below')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('[COLOR FFC89008]','00001')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('[COLOR FFFFFF00]','00002')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('[/COLOR]','00003')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('=====','00004')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace(',','00005')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('[RTL]','00009')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('[CENTER]','0000A')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('\r','0000B')
	Dxe4mO65obSHMKrlWsjwvX = kc57B93HrojbDIXVipY.split('\n')
	kc57B93HrojbDIXVipY,cR5ebBnQaqCO1pjKUx9gWuizE = '',''
	for Bx1JlohpcEg in Dxe4mO65obSHMKrlWsjwvX:
		if len(kc57B93HrojbDIXVipY+Bx1JlohpcEg)<1800: kc57B93HrojbDIXVipY += '\n'+Bx1JlohpcEg
		else:
			AANSbMO8jqdz5JVrEIDKFim.append(kc57B93HrojbDIXVipY)
			kc57B93HrojbDIXVipY = Bx1JlohpcEg
	AANSbMO8jqdz5JVrEIDKFim.append(kc57B93HrojbDIXVipY)
	from json import dumps as fegvwY5HC43GbZn
	for Bx1JlohpcEg in AANSbMO8jqdz5JVrEIDKFim:
		v1vaBXhQE6tsCjV73HkrNUpgI9DZK = {'Content-Type':'application/json','User-Agent':''}
		GZdtFyDU0caf89r = 'https://api.reverso.net/translate/v1/translation'
		m7gcw3bAeD4 = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.language.code')
		TvaUZzcHJK = {"format":"text","from":"ara","to":m7gcw3bAeD4,"input":Bx1JlohpcEg,"options":{"sentenceSplitter":True,"origin":"translation.web","contextResults":False,"languageDetection":False}}
		TvaUZzcHJK = fegvwY5HC43GbZn(TvaUZzcHJK)
		UyA2NgE6DjKsBRqMILZv5tXJ = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'POST',GZdtFyDU0caf89r,TvaUZzcHJK,v1vaBXhQE6tsCjV73HkrNUpgI9DZK,'','','LIBRARY-REVERSO_TRANSLATE-1st')
		if UyA2NgE6DjKsBRqMILZv5tXJ.succeeded:
			AxqI1TVGKPOjaYfE7F2ZH = UyA2NgE6DjKsBRqMILZv5tXJ.content
			AxqI1TVGKPOjaYfE7F2ZH = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('dict',AxqI1TVGKPOjaYfE7F2ZH)
			cR5ebBnQaqCO1pjKUx9gWuizE += '\n'+''.join(AxqI1TVGKPOjaYfE7F2ZH['translation'])
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE[2:]
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.replace('000000','00000').replace('00000','0000').replace('0000','000')
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.replace('0001','[COLOR FFC89008]')
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.replace('0002','[COLOR FFFFFF00]')
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.replace('0003','[/COLOR]')
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.replace('0004','=====')
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.replace('0005',',')
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.replace('0009','[RTL]')
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.replace('000A','[CENTER]')
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.replace('000B','\r')
	cR5ebBnQaqCO1pjKUx9gWuizE = cR5ebBnQaqCO1pjKUx9gWuizE.split('\n\n\n\n')
	return kRnixKJ5qH2LF9I+cR5ebBnQaqCO1pjKUx9gWuizE
def UJj7YFLa2MNX3b8gxqOE5ytfS(Dxe4mO65obSHMKrlWsjwvX):
	DDEzfiOcZAbshd7MVkJgTqn5juGlt = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.language.translate')
	if not DDEzfiOcZAbshd7MVkJgTqn5juGlt or not Dxe4mO65obSHMKrlWsjwvX: return Dxe4mO65obSHMKrlWsjwvX
	uSxj0QfnGUrARgqkZ = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.language.provider')
	m7gcw3bAeD4 = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.language.code')
	ZXaLMphB1mk3wuceltsHPYG = m7gcw3bAeD4+'__'+str(Dxe4mO65obSHMKrlWsjwvX)
	LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting('av.language.translate','')
	cR5ebBnQaqCO1pjKUx9gWuizE = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,'list','TRANSLATE_'+uSxj0QfnGUrARgqkZ,ZXaLMphB1mk3wuceltsHPYG)
	if not cR5ebBnQaqCO1pjKUx9gWuizE:
		if uSxj0QfnGUrARgqkZ=='GOOGLE': cR5ebBnQaqCO1pjKUx9gWuizE = f1fkE8oPt5Ili4dOevG0bjwWcAZDX(Dxe4mO65obSHMKrlWsjwvX)
		elif uSxj0QfnGUrARgqkZ=='REVERSO': cR5ebBnQaqCO1pjKUx9gWuizE = nxmGVbvWlg(Dxe4mO65obSHMKrlWsjwvX)
		elif uSxj0QfnGUrARgqkZ=='GLOSBE': cR5ebBnQaqCO1pjKUx9gWuizE = frFK84pCo1VZwd6AnabHLDSP(Dxe4mO65obSHMKrlWsjwvX)
		if len(Dxe4mO65obSHMKrlWsjwvX)==len(cR5ebBnQaqCO1pjKUx9gWuizE):
			OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,'TRANSLATE_'+uSxj0QfnGUrARgqkZ,ZXaLMphB1mk3wuceltsHPYG,cR5ebBnQaqCO1pjKUx9gWuizE,we9acVgv5HE0mdlXCSj6n7DQ4)
		else:
			cR5ebBnQaqCO1pjKUx9gWuizE = Dxe4mO65obSHMKrlWsjwvX
			dnS80F92qtLi4vw1('الترجمة فشلت','Translation Failed')
	LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting('av.language.translate','1')
	return cR5ebBnQaqCO1pjKUx9gWuizE
def Eh4YzQ9pVM5ABfikCJqcZtj(j57TcVZpeogCman,YxWBk13jlNRXnAie4FvI,JJG0EdY1NQXfSRwm,vm6w3tDhRbsyBpo5,OouwZ6UNaAC):
	f0QP7qXsU4L9xtB,WGy8jZubInXc7zRBJ5p,GZdtFyDU0caf89r,wMCm6g9qFyPT0xpneDUNc2lEhaZY,qRSNaY0t83hO9ofLEnJuAM1,Iy4bwu3m6qORhDrQSd19HYo8,kc57B93HrojbDIXVipY,wWXVYjrFaCg9zpboThAMQBU8iHJc,isbQc5EtyP76zR = j57TcVZpeogCman
	tQUAGTjJYFzI = []
	DDEzfiOcZAbshd7MVkJgTqn5juGlt = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.language.translate')
	if DDEzfiOcZAbshd7MVkJgTqn5juGlt:
		RKQx37VBOyom4sakePT,zVq3vIUf9RWAZ52,On8u25hNlP4 = [],[],[]
		if not tQUAGTjJYFzI:
			for HTnUrN6eW9 in YxWBk13jlNRXnAie4FvI:
				WGy8jZubInXc7zRBJ5p = HTnUrN6eW9['name'].replace(RQ0HpOfhFDoJdtl,'').replace(Qa68jZXt0gBH,'')
				UJnsuIybhNQZaoqXexmL30AdRB6MpH = u5h2Rckvw1E.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',WGy8jZubInXc7zRBJ5p,u5h2Rckvw1E.DOTALL)
				if UJnsuIybhNQZaoqXexmL30AdRB6MpH:
					kRnixKJ5qH2LF9I,vYEKtBnNyLl0J6dDMH8CGQwkZ,cThosMPpJLZ158m3UVASzntja,vH6Uxo8MJbPK4kWXz9CYBmE,WGy8jZubInXc7zRBJ5p = UJnsuIybhNQZaoqXexmL30AdRB6MpH[0]
					UJnsuIybhNQZaoqXexmL30AdRB6MpH = kRnixKJ5qH2LF9I+vYEKtBnNyLl0J6dDMH8CGQwkZ+' '+cThosMPpJLZ158m3UVASzntja+vH6Uxo8MJbPK4kWXz9CYBmE+' '
				else:
					UJnsuIybhNQZaoqXexmL30AdRB6MpH = u5h2Rckvw1E.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',WGy8jZubInXc7zRBJ5p,u5h2Rckvw1E.DOTALL)
					if UJnsuIybhNQZaoqXexmL30AdRB6MpH:
						WGy8jZubInXc7zRBJ5p,kRnixKJ5qH2LF9I,cThosMPpJLZ158m3UVASzntja,vYEKtBnNyLl0J6dDMH8CGQwkZ,vH6Uxo8MJbPK4kWXz9CYBmE = UJnsuIybhNQZaoqXexmL30AdRB6MpH[0]
						UJnsuIybhNQZaoqXexmL30AdRB6MpH = kRnixKJ5qH2LF9I+vYEKtBnNyLl0J6dDMH8CGQwkZ+' '+cThosMPpJLZ158m3UVASzntja+vH6Uxo8MJbPK4kWXz9CYBmE+' '
					else: UJnsuIybhNQZaoqXexmL30AdRB6MpH = ''
				McKAIxa0FmojZk = u5h2Rckvw1E.findall('^(.\[COLOR FFC89008\]\w\w\w \[/COLOR\])(.*?)$',WGy8jZubInXc7zRBJ5p,u5h2Rckvw1E.DOTALL)
				if McKAIxa0FmojZk: McKAIxa0FmojZk,WGy8jZubInXc7zRBJ5p = McKAIxa0FmojZk[0]
				else: McKAIxa0FmojZk = ''
				RKQx37VBOyom4sakePT.append(UJnsuIybhNQZaoqXexmL30AdRB6MpH+McKAIxa0FmojZk)
				zVq3vIUf9RWAZ52.append(WGy8jZubInXc7zRBJ5p)
			On8u25hNlP4 = UJj7YFLa2MNX3b8gxqOE5ytfS(zVq3vIUf9RWAZ52)
			if On8u25hNlP4:
				for OTxp2K4Vayb8CoUFJSWA in range(len(YxWBk13jlNRXnAie4FvI)):
					HTnUrN6eW9 = YxWBk13jlNRXnAie4FvI[OTxp2K4Vayb8CoUFJSWA]
					HTnUrN6eW9['name'] = RKQx37VBOyom4sakePT[OTxp2K4Vayb8CoUFJSWA]+On8u25hNlP4[OTxp2K4Vayb8CoUFJSWA]
					tQUAGTjJYFzI.append(HTnUrN6eW9)
	if tQUAGTjJYFzI: YxWBk13jlNRXnAie4FvI = tQUAGTjJYFzI
	oWVh0yZqRkX5u8zT7bmYL,BNO5ZdApgkjtT2,X8ocJb9VyARnwGPgpK = [],0,0
	mS3T4VzXkloHadCZ5yN6LA = k1t0JLRsCQ.path.join(yZKq8SbJduiIwcHMOz6gN,wMCm6g9qFyPT0xpneDUNc2lEhaZY)
	try: HPLWu82xoIUSAnjY7GbDsM = k1t0JLRsCQ.listdir(mS3T4VzXkloHadCZ5yN6LA)
	except:
		try: k1t0JLRsCQ.makedirs(mS3T4VzXkloHadCZ5yN6LA)
		except: pass
		HPLWu82xoIUSAnjY7GbDsM = []
	oRv8N1BTHDcwmPA = VXxBgF6Rl0kPOdjvEeJz83L2I7sy4r('menu_item')
	for HTnUrN6eW9 in YxWBk13jlNRXnAie4FvI:
		WGy8jZubInXc7zRBJ5p = HTnUrN6eW9['name']
		mAboFLiZsCfr6c = HTnUrN6eW9['context_menu']
		jsglQuMpyhm0w2GK = HTnUrN6eW9['plot']
		JVBUPRb5IW7GYfur9tAMCKDLeXislg = HTnUrN6eW9['stars']
		qRSNaY0t83hO9ofLEnJuAM1 = HTnUrN6eW9['image']
		f0QP7qXsU4L9xtB = HTnUrN6eW9['type']
		WoZL2urv9CfqaGN08w3mTMcE7SQJ = HTnUrN6eW9['duration']
		Ma8QoD2eqZiUjpv6I = HTnUrN6eW9['isFolder']
		CPNXrI4FLo = HTnUrN6eW9['newpath']
		AC5SrNWEs8gdOMRFqXwIh7 = XuWPVcQ13oDq5swf0S.ListItem(WGy8jZubInXc7zRBJ5p)
		AC5SrNWEs8gdOMRFqXwIh7.addContextMenuItems(mAboFLiZsCfr6c)
		if qRSNaY0t83hO9ofLEnJuAM1: AC5SrNWEs8gdOMRFqXwIh7.setArt({'icon':qRSNaY0t83hO9ofLEnJuAM1,'thumb':qRSNaY0t83hO9ofLEnJuAM1,'fanart':qRSNaY0t83hO9ofLEnJuAM1,'banner':qRSNaY0t83hO9ofLEnJuAM1,'clearart':qRSNaY0t83hO9ofLEnJuAM1,'poster':qRSNaY0t83hO9ofLEnJuAM1,'clearlogo':qRSNaY0t83hO9ofLEnJuAM1,'landscape':qRSNaY0t83hO9ofLEnJuAM1})
		else:
			WGy8jZubInXc7zRBJ5p = eoblnvIyaChYrkj(WGy8jZubInXc7zRBJ5p)
			WGy8jZubInXc7zRBJ5p = nkV8dCRtNgiBYMJTxLI(WGy8jZubInXc7zRBJ5p)
			PSgjTlMBuz86pkVY1Q = WGy8jZubInXc7zRBJ5p+'.png'
			default = True
			if PSgjTlMBuz86pkVY1Q in HPLWu82xoIUSAnjY7GbDsM:
				LhN8RFiJEr = k1t0JLRsCQ.path.join(mS3T4VzXkloHadCZ5yN6LA,PSgjTlMBuz86pkVY1Q)
				AC5SrNWEs8gdOMRFqXwIh7.setArt({'icon':LhN8RFiJEr,'thumb':LhN8RFiJEr,'fanart':LhN8RFiJEr,'banner':LhN8RFiJEr,'clearart':LhN8RFiJEr,'poster':LhN8RFiJEr,'clearlogo':LhN8RFiJEr,'landscape':LhN8RFiJEr})
				default = False
			elif BNO5ZdApgkjtT2<60 and X8ocJb9VyARnwGPgpK<5:
				LhN8RFiJEr = k1t0JLRsCQ.path.join(mS3T4VzXkloHadCZ5yN6LA,PSgjTlMBuz86pkVY1Q)
				try:
					MVlaCtubcNxHIJDZYFSi4Azo = qElCxFVMcSPZzb6irp7X4gLNv1(oRv8N1BTHDcwmPA,'','','','',WGy8jZubInXc7zRBJ5p,'menu_item','center',False,LhN8RFiJEr)
					AC5SrNWEs8gdOMRFqXwIh7.setArt({'icon':LhN8RFiJEr,'thumb':LhN8RFiJEr,'fanart':LhN8RFiJEr,'banner':LhN8RFiJEr,'clearart':LhN8RFiJEr,'poster':LhN8RFiJEr,'clearlogo':LhN8RFiJEr,'landscape':LhN8RFiJEr})
					BNO5ZdApgkjtT2 += 1
					default = False
				except: X8ocJb9VyARnwGPgpK += 1
			if default: AC5SrNWEs8gdOMRFqXwIh7.setArt({'icon':bDYdui4a8EqFLe7JG,'thumb':FfCI72d4MXZk0Pme,'fanart':FTeZjcG8Cd30bytv2Oo6S1JWMQ,'banner':uWf4o3Mc2wBK,'clearart':toh5NRrqjA4dmG8M1IFwEl,'poster':c5KtQb01CnB,'clearlogo':Hc93WG6a1ZP7srEwmyApNtlq,'landscape':IkxsXLotRmAMNUG65YZv9DF})
		if njGgmsD1k7cE60drxHCyVh2YN3P<20:
			if jsglQuMpyhm0w2GK: AC5SrNWEs8gdOMRFqXwIh7.setInfo('video',{'Plot':jsglQuMpyhm0w2GK,'PlotOutline':jsglQuMpyhm0w2GK})
			if JVBUPRb5IW7GYfur9tAMCKDLeXislg: AC5SrNWEs8gdOMRFqXwIh7.setInfo('video',{'Rating':JVBUPRb5IW7GYfur9tAMCKDLeXislg})
			if not qRSNaY0t83hO9ofLEnJuAM1:
				AC5SrNWEs8gdOMRFqXwIh7.setInfo('video',{'Title':WGy8jZubInXc7zRBJ5p})
			if f0QP7qXsU4L9xtB=='video':
				AC5SrNWEs8gdOMRFqXwIh7.setInfo('video',{'mediatype':'movie'})
				if WoZL2urv9CfqaGN08w3mTMcE7SQJ: AC5SrNWEs8gdOMRFqXwIh7.setInfo('video',{'duration':WoZL2urv9CfqaGN08w3mTMcE7SQJ})
				AC5SrNWEs8gdOMRFqXwIh7.setProperty('IsPlayable','true')
		else:
			PeNuCWDGZQ = AC5SrNWEs8gdOMRFqXwIh7.getVideoInfoTag()
			if JVBUPRb5IW7GYfur9tAMCKDLeXislg: PeNuCWDGZQ.setRating(float(JVBUPRb5IW7GYfur9tAMCKDLeXislg))
			if not qRSNaY0t83hO9ofLEnJuAM1:
				PeNuCWDGZQ.setTitle(WGy8jZubInXc7zRBJ5p)
			if f0QP7qXsU4L9xtB=='video':
				PeNuCWDGZQ.setMediaType('tvshow')
				if WoZL2urv9CfqaGN08w3mTMcE7SQJ: PeNuCWDGZQ.setDuration(WoZL2urv9CfqaGN08w3mTMcE7SQJ)
				AC5SrNWEs8gdOMRFqXwIh7.setProperty('IsPlayable','true')
		oWVh0yZqRkX5u8zT7bmYL.append((CPNXrI4FLo,AC5SrNWEs8gdOMRFqXwIh7,Ma8QoD2eqZiUjpv6I))
	oejGsrTCZ05k2X7LlHnPa3h8vzAbJy.setContent(Y40Szd1kTwqQxFXm6HO8tRlAvepK,'tvshows')
	JqGSj4UsihoFCbnfZ0Rd = oejGsrTCZ05k2X7LlHnPa3h8vzAbJy.addDirectoryItems(Y40Szd1kTwqQxFXm6HO8tRlAvepK,oWVh0yZqRkX5u8zT7bmYL)
	oejGsrTCZ05k2X7LlHnPa3h8vzAbJy.endOfDirectory(Y40Szd1kTwqQxFXm6HO8tRlAvepK,JJG0EdY1NQXfSRwm,vm6w3tDhRbsyBpo5,OouwZ6UNaAC)
	return JqGSj4UsihoFCbnfZ0Rd
def uQNUfbZx9yj0F(f0QP7qXsU4L9xtB,WGy8jZubInXc7zRBJ5p,GZdtFyDU0caf89r,wMCm6g9qFyPT0xpneDUNc2lEhaZY,qRSNaY0t83hO9ofLEnJuAM1='',Iy4bwu3m6qORhDrQSd19HYo8='',kc57B93HrojbDIXVipY='',wWXVYjrFaCg9zpboThAMQBU8iHJc='',isbQc5EtyP76zR={}):
	WGy8jZubInXc7zRBJ5p = WGy8jZubInXc7zRBJ5p.replace('\r','').replace('\n','').replace('\t','')
	GZdtFyDU0caf89r = GZdtFyDU0caf89r.replace('\r','').replace('\n','').replace('\t','')
	if '_SCRIPT_' in WGy8jZubInXc7zRBJ5p: ERLBl7fGCXQYchpgj6d,WGy8jZubInXc7zRBJ5p = WGy8jZubInXc7zRBJ5p.split('_SCRIPT_',1)
	else: ERLBl7fGCXQYchpgj6d,WGy8jZubInXc7zRBJ5p = '',WGy8jZubInXc7zRBJ5p
	if ERLBl7fGCXQYchpgj6d:
		kcYFJBHDQO56a0ZLRye = WGy8jZubInXc7zRBJ5p
		if not kcYFJBHDQO56a0ZLRye: kcYFJBHDQO56a0ZLRye = '....'
		elif kcYFJBHDQO56a0ZLRye.count('_')>1: kcYFJBHDQO56a0ZLRye = kcYFJBHDQO56a0ZLRye.split('_',2)[2]
		kcYFJBHDQO56a0ZLRye = kcYFJBHDQO56a0ZLRye.replace(' ','')
		kcYFJBHDQO56a0ZLRye = kcYFJBHDQO56a0ZLRye.replace('ـ','').replace('ة','ه').replace('ؤ','و')
		kcYFJBHDQO56a0ZLRye = kcYFJBHDQO56a0ZLRye.replace('أ','ا').replace('إ','ا').replace('آ','ا')
		kcYFJBHDQO56a0ZLRye = kcYFJBHDQO56a0ZLRye.replace('لأ','لا').replace('لإ','لا').replace('لآ','لا')
		kcYFJBHDQO56a0ZLRye = kcYFJBHDQO56a0ZLRye.replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
		kcYFJBHDQO56a0ZLRye = kcYFJBHDQO56a0ZLRye.replace('ِ','').replace('ٍ','').replace('ْ','').replace('ّ','')
		kcYFJBHDQO56a0ZLRye = kcYFJBHDQO56a0ZLRye.replace('|','').replace('~','')
		kcYFJBHDQO56a0ZLRye = kcYFJBHDQO56a0ZLRye.replace('اون لاين','').replace('سيما لايت','')
		AjreXJ0BiSaf = ['العاب','خيال','البوم','الان','اطفال','حاليه','الغاز','صالح','الدين','مواليد','العالم','اعمال']
		if not any(yypNIclXCGvB7WHsuYk409 in kcYFJBHDQO56a0ZLRye for yypNIclXCGvB7WHsuYk409 in AjreXJ0BiSaf): kcYFJBHDQO56a0ZLRye = kcYFJBHDQO56a0ZLRye.replace('ال','')
		kcYFJBHDQO56a0ZLRye = kcYFJBHDQO56a0ZLRye.replace('اخري','اخرى').replace('اجنبى','اجنبي').replace('عائليه','عائلي')
		kcYFJBHDQO56a0ZLRye = kcYFJBHDQO56a0ZLRye.replace('اجنبيه','اجنبي').replace('عربيه','عربي').replace('رومانسيه','رومانسي')
		kcYFJBHDQO56a0ZLRye = kcYFJBHDQO56a0ZLRye.replace('غربيه','غربي').replace('و مسلسلات','مسلسلات').replace('اغانى','اغاني')
		kcYFJBHDQO56a0ZLRye = kcYFJBHDQO56a0ZLRye.replace('تاريخي','تاريخ').replace('خيال علمي','خيال').replace('موسيقيه','موسيقى')
		kcYFJBHDQO56a0ZLRye = kcYFJBHDQO56a0ZLRye.replace('هندى','هندي').replace('هنديه','هندي').replace('وثائقيه','وثائقي')
		kcYFJBHDQO56a0ZLRye = kcYFJBHDQO56a0ZLRye.replace('تليفزيونيه','تلفزيون').replace('تلفزيونيه','تلفزيون').replace('و كرتون','وكرتون')
		kcYFJBHDQO56a0ZLRye = kcYFJBHDQO56a0ZLRye.replace('الحاليه','حاليه').replace('موسیقي','موسيقى').replace('الانمي','انمي')
		kcYFJBHDQO56a0ZLRye = kcYFJBHDQO56a0ZLRye.replace('المسلسلات','مسلسلات').replace('البرامج','برامج').replace('كارتون','كرتون')
		kcYFJBHDQO56a0ZLRye = kcYFJBHDQO56a0ZLRye.replace('حروب','حرب').replace('الاناشيد','اناشيد').replace('اسيويه','اسيوي')
		kcYFJBHDQO56a0ZLRye = kcYFJBHDQO56a0ZLRye.replace('عربى','عربي').replace('تركى','تركي').replace('تركيه','تركي')
		kcYFJBHDQO56a0ZLRye = kcYFJBHDQO56a0ZLRye.replace('رياضي','رياضة').replace('رياضه','رياضة').replace('اسيويه','اسيوي')
		kcYFJBHDQO56a0ZLRye = kcYFJBHDQO56a0ZLRye.replace('كوميدى','كوميدي').replace('كوميديه','كوميدي').replace('انيمي','انمي')
		kcYFJBHDQO56a0ZLRye = kcYFJBHDQO56a0ZLRye.replace('انيميشن','انميشن').replace('انمى','انميشن').replace('انمي','انميشن')
		kcYFJBHDQO56a0ZLRye = kcYFJBHDQO56a0ZLRye.replace('انميشنشن','انميشن').replace('الانميشن','انميشن').replace('افلام مسلسلات','افلام ومسلسلات')
		kcYFJBHDQO56a0ZLRye = kcYFJBHDQO56a0ZLRye.replace('  ',' ').strip(' ')
		ERLBl7fGCXQYchpgj6d = '_LST_'+wSH84vUOuxYjoQ3aPBeAEZ(ERLBl7fGCXQYchpgj6d)
		if kcYFJBHDQO56a0ZLRye not in list(NW1z9Mg8T2.keys()): NW1z9Mg8T2[kcYFJBHDQO56a0ZLRye] = {}
		NW1z9Mg8T2[kcYFJBHDQO56a0ZLRye][ERLBl7fGCXQYchpgj6d] = [f0QP7qXsU4L9xtB,WGy8jZubInXc7zRBJ5p,GZdtFyDU0caf89r,wMCm6g9qFyPT0xpneDUNc2lEhaZY,qRSNaY0t83hO9ofLEnJuAM1,Iy4bwu3m6qORhDrQSd19HYo8,kc57B93HrojbDIXVipY,wWXVYjrFaCg9zpboThAMQBU8iHJc,isbQc5EtyP76zR]
	YD56nkJmsd.append([f0QP7qXsU4L9xtB,WGy8jZubInXc7zRBJ5p,GZdtFyDU0caf89r,wMCm6g9qFyPT0xpneDUNc2lEhaZY,qRSNaY0t83hO9ofLEnJuAM1,Iy4bwu3m6qORhDrQSd19HYo8,kc57B93HrojbDIXVipY,wWXVYjrFaCg9zpboThAMQBU8iHJc,isbQc5EtyP76zR])
	return
def uTUNPkVwCMKiD5gHLaj(ujk7xAp2Dw3hKr):
	if VVGRN7xiyj: from html import unescape as _w2bCkTYQNJZoUvts1pg
	else:
		from HTMLParser import HTMLParser as TKV6mZH8RlIbSEDpO7ug
		_w2bCkTYQNJZoUvts1pg = TKV6mZH8RlIbSEDpO7ug().unescape
	if '&' in ujk7xAp2Dw3hKr and ';' in ujk7xAp2Dw3hKr:
		if bdptXFc8UlIhA5jnGwPmKuv2L: ujk7xAp2Dw3hKr = ujk7xAp2Dw3hKr.decode('utf8')
		ujk7xAp2Dw3hKr = _w2bCkTYQNJZoUvts1pg(ujk7xAp2Dw3hKr)
		if bdptXFc8UlIhA5jnGwPmKuv2L: ujk7xAp2Dw3hKr = ujk7xAp2Dw3hKr.encode('utf8')
	return ujk7xAp2Dw3hKr
def ffbxegm1XPSqIwp8i(ujk7xAp2Dw3hKr):
	if '\\u' in ujk7xAp2Dw3hKr:
		if bdptXFc8UlIhA5jnGwPmKuv2L: ujk7xAp2Dw3hKr = ujk7xAp2Dw3hKr.decode('unicode_escape','ignore').encode('utf8')
		elif VVGRN7xiyj: ujk7xAp2Dw3hKr = ujk7xAp2Dw3hKr.encode('utf8').decode('unicode_escape','ignore')
	return ujk7xAp2Dw3hKr
def WedGKhM8a0(YDuVHvM5cWC8aP2zoTtZmKyRi3qGp,vm5oH810DdpOTNQ,BA6DPe4zKN1qOUh,DD9uHpBxXWrEvS,kc57B93HrojbDIXVipY,SmTnypJH7G,ffl0qAazk1GEPcsb,VivlhtXCUmd6,OhIiJR8kLZYKg5Qj64FSqoUCN17l):
	QQsF6mYN3wqDIurkyGCxRMb9A8zTHE = VXxBgF6Rl0kPOdjvEeJz83L2I7sy4r(SmTnypJH7G)
	MVlaCtubcNxHIJDZYFSi4Azo = qElCxFVMcSPZzb6irp7X4gLNv1(QQsF6mYN3wqDIurkyGCxRMb9A8zTHE,YDuVHvM5cWC8aP2zoTtZmKyRi3qGp,vm5oH810DdpOTNQ,BA6DPe4zKN1qOUh,DD9uHpBxXWrEvS,kc57B93HrojbDIXVipY,SmTnypJH7G,ffl0qAazk1GEPcsb,VivlhtXCUmd6,OhIiJR8kLZYKg5Qj64FSqoUCN17l)
	return MVlaCtubcNxHIJDZYFSi4Azo
def VXxBgF6Rl0kPOdjvEeJz83L2I7sy4r(SmTnypJH7G):
	fC215RhQGx6KA = 5
	cGXhMSJ3NLlsKrAn7V9ewZtyWCH = 20
	BJeoUFu6RnSj3APpiag = 20
	UsVIq6ivlm504jP = 0
	EPBVq8tvCk5UY0xg74Xc = 'center'
	wWEsQANz0McVmyxFU = 0
	U9MzoVFx8bur37KeX4EIlsftOmi0 = 19
	nVkXORUe1qyB6wlo = 30
	PLHEeYUXjD = 8
	zzgcGluitONAH = True
	TBc0bHY7gMPRr = 375
	KKyDldNeLCGO = 410
	D8zv7OxN6dsBpoc = 50
	JcpyzXTVeZBaln9E3N0WL26G = 280
	uumyIokdrsYD6w7fitMX9h2OxGV = 28
	w73ODtngboQl9MLBdk = 5
	TfnzJio9XEkK2tvW5wZ = 0
	OZxB8nzg7oIDQKmrV = 31
	c4CmhZLfGsizFDwnIWXr6M7B = [36,32,28]
	if SmTnypJH7G in ['notification','notification_twohalfs']:
		if SmTnypJH7G=='notification_twohalfs':
			kUw3ZjSv7gi2TVQo,MMBSXLkbq6YVcuFCU = 'UPPER',720
			EPBVq8tvCk5UY0xg74Xc = 'right'
			zzgcGluitONAH = True
			UsVIq6ivlm504jP = 10
		else:
			kUw3ZjSv7gi2TVQo,MMBSXLkbq6YVcuFCU = 97+20,720
			EPBVq8tvCk5UY0xg74Xc = 'left'
			zzgcGluitONAH = False
		c4CmhZLfGsizFDwnIWXr6M7B = [33,33,33]
		BJeoUFu6RnSj3APpiag = 20
		cGXhMSJ3NLlsKrAn7V9ewZtyWCH = 0
		nVkXORUe1qyB6wlo = 20
		U9MzoVFx8bur37KeX4EIlsftOmi0 = 25+10
	elif SmTnypJH7G=='menu_item':
		c4CmhZLfGsizFDwnIWXr6M7B,kUw3ZjSv7gi2TVQo,MMBSXLkbq6YVcuFCU = [48,44,40],200,400
		nVkXORUe1qyB6wlo,U9MzoVFx8bur37KeX4EIlsftOmi0,cGXhMSJ3NLlsKrAn7V9ewZtyWCH = 0,0,-16
		jMfFQ6CH1ZungPrJq3RkpBWo2 = ss4Y30c7iC.open(TvNMR1USOYBhm06dtWyGg)
		N967UTMqGLjElWpSrg = ss4Y30c7iC.new('RGBA',(200,200),(255,0,0,255))
	elif SmTnypJH7G=='confirm_smallfont': c4CmhZLfGsizFDwnIWXr6M7B,kUw3ZjSv7gi2TVQo,MMBSXLkbq6YVcuFCU = [28,24,20],500,900
	elif SmTnypJH7G=='confirm_mediumfont': c4CmhZLfGsizFDwnIWXr6M7B,kUw3ZjSv7gi2TVQo,MMBSXLkbq6YVcuFCU = [32,28,24],500,900
	elif SmTnypJH7G=='confirm_bigfont': c4CmhZLfGsizFDwnIWXr6M7B,kUw3ZjSv7gi2TVQo,MMBSXLkbq6YVcuFCU = [36,32,28],500,900
	elif SmTnypJH7G=='textview_bigfont': kUw3ZjSv7gi2TVQo,MMBSXLkbq6YVcuFCU = 740,1270
	elif SmTnypJH7G=='textview_bigfont_long': kUw3ZjSv7gi2TVQo,MMBSXLkbq6YVcuFCU = 'UPPER',1270
	elif SmTnypJH7G=='textview_smallfont': c4CmhZLfGsizFDwnIWXr6M7B,kUw3ZjSv7gi2TVQo,MMBSXLkbq6YVcuFCU = [28,23,18],740,1270
	elif SmTnypJH7G=='textview_smallfont_long': c4CmhZLfGsizFDwnIWXr6M7B,kUw3ZjSv7gi2TVQo,MMBSXLkbq6YVcuFCU = [28,23,18],'UPPER',1270
	bbY74KsldTAJmRzXkHDF3hv = c4CmhZLfGsizFDwnIWXr6M7B[0]
	yyXaP6EdzrDsNvBO29po1m = c4CmhZLfGsizFDwnIWXr6M7B[1]
	L0tTIhqCicMgFrzfeJR5ab47SV = c4CmhZLfGsizFDwnIWXr6M7B[2]
	xSjn5trNvL2as8Aw = U0ecS5D43xq1XngdI97rjVThBf8.truetype(JH6Z129abNsUoj8xG,size=bbY74KsldTAJmRzXkHDF3hv)
	pWqjt9CO3QMgoXSvIF4 = U0ecS5D43xq1XngdI97rjVThBf8.truetype(JH6Z129abNsUoj8xG,size=yyXaP6EdzrDsNvBO29po1m)
	ZM7a9te0Nj8l2UmXdCOf = U0ecS5D43xq1XngdI97rjVThBf8.truetype(JH6Z129abNsUoj8xG,size=L0tTIhqCicMgFrzfeJR5ab47SV)
	TWtIXrysgQ = ss4Y30c7iC.new('RGBA',(100,100),(255,255,255,0))
	gwkz9DOuNCF = XXt3yJYkxgvLsRBpuhZPOH7wMIo.Draw(TWtIXrysgQ)
	aizq5NukjySt9LFV01CI,JvFyrpU4Hfm21VGSkEh3 = gwkz9DOuNCF.textsize('HHH BBB 888 000',font=pWqjt9CO3QMgoXSvIF4)
	t2Ko1ykaDQfU,eZUFtoTGbQuJIl1AkBdv = gwkz9DOuNCF.textsize('HHH BBB 888 000',font=xSjn5trNvL2as8Aw)
	aqR9SwCDONYWKIV = {'delete_harakat':False,'support_ligatures':True,'ARABIC LIGATURE ALLAH':False}
	zlWsegnp0V5qbNaHKtvEBZL2S8c = cOXskFxRdQP(configuration=aqR9SwCDONYWKIV)
	QQsF6mYN3wqDIurkyGCxRMb9A8zTHE = {}
	Bji1uJnNZwvH0maT67RlyXz3M = locals()
	for bbqxQZ2thM0 in Bji1uJnNZwvH0maT67RlyXz3M: QQsF6mYN3wqDIurkyGCxRMb9A8zTHE[bbqxQZ2thM0] = Bji1uJnNZwvH0maT67RlyXz3M[bbqxQZ2thM0]
	return QQsF6mYN3wqDIurkyGCxRMb9A8zTHE
def qElCxFVMcSPZzb6irp7X4gLNv1(QQsF6mYN3wqDIurkyGCxRMb9A8zTHE,YDuVHvM5cWC8aP2zoTtZmKyRi3qGp,vm5oH810DdpOTNQ,BA6DPe4zKN1qOUh,DD9uHpBxXWrEvS,kc57B93HrojbDIXVipY,SmTnypJH7G,ffl0qAazk1GEPcsb,VivlhtXCUmd6,OhIiJR8kLZYKg5Qj64FSqoUCN17l):
	for bbqxQZ2thM0 in QQsF6mYN3wqDIurkyGCxRMb9A8zTHE: globals()[bbqxQZ2thM0] = QQsF6mYN3wqDIurkyGCxRMb9A8zTHE[bbqxQZ2thM0]
	global uumyIokdrsYD6w7fitMX9h2OxGV,w73ODtngboQl9MLBdk
	DDEzfiOcZAbshd7MVkJgTqn5juGlt = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.language.translate')
	if DDEzfiOcZAbshd7MVkJgTqn5juGlt:
		if YDuVHvM5cWC8aP2zoTtZmKyRi3qGp=='نعم  Yes': YDuVHvM5cWC8aP2zoTtZmKyRi3qGp = 'Yes'
		elif YDuVHvM5cWC8aP2zoTtZmKyRi3qGp=='كلا  No': YDuVHvM5cWC8aP2zoTtZmKyRi3qGp = 'No'
		if vm5oH810DdpOTNQ=='نعم  Yes': vm5oH810DdpOTNQ = 'Yes'
		elif vm5oH810DdpOTNQ=='كلا  No': vm5oH810DdpOTNQ = 'No'
		if BA6DPe4zKN1qOUh=='نعم  Yes': BA6DPe4zKN1qOUh = 'Yes'
		elif BA6DPe4zKN1qOUh=='كلا  No': BA6DPe4zKN1qOUh = 'No'
		QZSU5eYbuF2miCW8Dh67yHnMtOA = UJj7YFLa2MNX3b8gxqOE5ytfS([YDuVHvM5cWC8aP2zoTtZmKyRi3qGp,vm5oH810DdpOTNQ,BA6DPe4zKN1qOUh,DD9uHpBxXWrEvS,kc57B93HrojbDIXVipY])
		if QZSU5eYbuF2miCW8Dh67yHnMtOA: YDuVHvM5cWC8aP2zoTtZmKyRi3qGp,vm5oH810DdpOTNQ,BA6DPe4zKN1qOUh,DD9uHpBxXWrEvS,kc57B93HrojbDIXVipY = QZSU5eYbuF2miCW8Dh67yHnMtOA
	if bdptXFc8UlIhA5jnGwPmKuv2L:
		kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.decode('utf8')
		DD9uHpBxXWrEvS = DD9uHpBxXWrEvS.decode('utf8')
		YDuVHvM5cWC8aP2zoTtZmKyRi3qGp = YDuVHvM5cWC8aP2zoTtZmKyRi3qGp.decode('utf8')
		vm5oH810DdpOTNQ = vm5oH810DdpOTNQ.decode('utf8')
		BA6DPe4zKN1qOUh = BA6DPe4zKN1qOUh.decode('utf8')
	e7ekOzhV9uAT0 = DD9uHpBxXWrEvS.count('\n')+1
	s8pjWMqFfy3EckwX = cGXhMSJ3NLlsKrAn7V9ewZtyWCH+e7ekOzhV9uAT0*(eZUFtoTGbQuJIl1AkBdv+UsVIq6ivlm504jP)-UsVIq6ivlm504jP
	if kc57B93HrojbDIXVipY:
		oKf0SyP2huITrBOsgLv81CV = MMBSXLkbq6YVcuFCU-nVkXORUe1qyB6wlo*2
		oM5KBp8tfd6zvk0 = JvFyrpU4Hfm21VGSkEh3+PLHEeYUXjD
		ggBbMu08NJiSlnL = zlWsegnp0V5qbNaHKtvEBZL2S8c.reshape(kc57B93HrojbDIXVipY)
		if zzgcGluitONAH:
			UsdTuGkX51JZt6NraAx = gBPEpQVGSwXA(ggBbMu08NJiSlnL,yyXaP6EdzrDsNvBO29po1m,oKf0SyP2huITrBOsgLv81CV,oM5KBp8tfd6zvk0)
			pFVt6OHx7jW = DZXlerKn1bzfIs5yBFN8dgjhCT0vQ(UsdTuGkX51JZt6NraAx)
			cFEX54lpwMtuCGfo3Y60H8BbK2A = pFVt6OHx7jW.count('\n')+1
			if cFEX54lpwMtuCGfo3Y60H8BbK2A<6:
				nhjOFE8WGDYz1yNsu0fpx7wv = oKf0SyP2huITrBOsgLv81CV
				UsdTuGkX51JZt6NraAx = gBPEpQVGSwXA(ggBbMu08NJiSlnL,yyXaP6EdzrDsNvBO29po1m,nhjOFE8WGDYz1yNsu0fpx7wv,oM5KBp8tfd6zvk0)
				pFVt6OHx7jW = DZXlerKn1bzfIs5yBFN8dgjhCT0vQ(UsdTuGkX51JZt6NraAx)
				cFEX54lpwMtuCGfo3Y60H8BbK2A = pFVt6OHx7jW.count('\n')+1
			tL9bQCZydc = U9MzoVFx8bur37KeX4EIlsftOmi0+cFEX54lpwMtuCGfo3Y60H8BbK2A*oM5KBp8tfd6zvk0-PLHEeYUXjD
		else:
			tL9bQCZydc = U9MzoVFx8bur37KeX4EIlsftOmi0+JvFyrpU4Hfm21VGSkEh3
			pFVt6OHx7jW = ggBbMu08NJiSlnL.split('\n')[0]
			UsdTuGkX51JZt6NraAx = ggBbMu08NJiSlnL.split('\n')[0]
	else: tL9bQCZydc = U9MzoVFx8bur37KeX4EIlsftOmi0
	sr7owSPa1Qc = TfnzJio9XEkK2tvW5wZ+OZxB8nzg7oIDQKmrV
	if VivlhtXCUmd6:
		eenDXqB7pYskOlMzZgyx0 = KKyDldNeLCGO-TBc0bHY7gMPRr
		sr7owSPa1Qc += eenDXqB7pYskOlMzZgyx0
	else: eenDXqB7pYskOlMzZgyx0 = 0
	if YDuVHvM5cWC8aP2zoTtZmKyRi3qGp or vm5oH810DdpOTNQ or BA6DPe4zKN1qOUh: sr7owSPa1Qc += D8zv7OxN6dsBpoc
	if kUw3ZjSv7gi2TVQo!='UPPER': MVlaCtubcNxHIJDZYFSi4Azo = kUw3ZjSv7gi2TVQo
	else: MVlaCtubcNxHIJDZYFSi4Azo = s8pjWMqFfy3EckwX+tL9bQCZydc+sr7owSPa1Qc
	SI2s47tAdwb = MVlaCtubcNxHIJDZYFSi4Azo-s8pjWMqFfy3EckwX-sr7owSPa1Qc-U9MzoVFx8bur37KeX4EIlsftOmi0
	TWtIXrysgQ = ss4Y30c7iC.new('RGBA',(MMBSXLkbq6YVcuFCU,MVlaCtubcNxHIJDZYFSi4Azo),(255,255,255,0))
	gwkz9DOuNCF = XXt3yJYkxgvLsRBpuhZPOH7wMIo.Draw(TWtIXrysgQ)
	if not vm5oH810DdpOTNQ and YDuVHvM5cWC8aP2zoTtZmKyRi3qGp and BA6DPe4zKN1qOUh:
		uumyIokdrsYD6w7fitMX9h2OxGV += 105
		w73ODtngboQl9MLBdk -= 110
	if DD9uHpBxXWrEvS:
		wxtjUncSrp0d = cGXhMSJ3NLlsKrAn7V9ewZtyWCH
		DD9uHpBxXWrEvS = k4rNW6UOwPBVDfblusx.get_display(zlWsegnp0V5qbNaHKtvEBZL2S8c.reshape(DD9uHpBxXWrEvS))
		Dxe4mO65obSHMKrlWsjwvX = DD9uHpBxXWrEvS.splitlines()
		for Bx1JlohpcEg in Dxe4mO65obSHMKrlWsjwvX:
			if Bx1JlohpcEg:
				qyAn75RzIgCV8LbQU3S2wiEJTk09G,cdN60sYWKyn = gwkz9DOuNCF.textsize(Bx1JlohpcEg,font=xSjn5trNvL2as8Aw)
				if EPBVq8tvCk5UY0xg74Xc=='center': WmX4nBbwIqMjgtRFG7fH6Qvp9oy = fC215RhQGx6KA+(MMBSXLkbq6YVcuFCU-qyAn75RzIgCV8LbQU3S2wiEJTk09G)/2
				elif EPBVq8tvCk5UY0xg74Xc=='right': WmX4nBbwIqMjgtRFG7fH6Qvp9oy = fC215RhQGx6KA+MMBSXLkbq6YVcuFCU-qyAn75RzIgCV8LbQU3S2wiEJTk09G-BJeoUFu6RnSj3APpiag
				elif EPBVq8tvCk5UY0xg74Xc=='left': WmX4nBbwIqMjgtRFG7fH6Qvp9oy = fC215RhQGx6KA+BJeoUFu6RnSj3APpiag
				gwkz9DOuNCF.text((WmX4nBbwIqMjgtRFG7fH6Qvp9oy,wxtjUncSrp0d),Bx1JlohpcEg,font=xSjn5trNvL2as8Aw,fill='yellow')
			wxtjUncSrp0d += bbY74KsldTAJmRzXkHDF3hv+UsVIq6ivlm504jP
	if YDuVHvM5cWC8aP2zoTtZmKyRi3qGp or vm5oH810DdpOTNQ or BA6DPe4zKN1qOUh:
		TtXlo0xjkr6DPaAfKBN8hpH2 = s8pjWMqFfy3EckwX+SI2s47tAdwb+U9MzoVFx8bur37KeX4EIlsftOmi0+eenDXqB7pYskOlMzZgyx0+TfnzJio9XEkK2tvW5wZ
		if YDuVHvM5cWC8aP2zoTtZmKyRi3qGp:
			YDuVHvM5cWC8aP2zoTtZmKyRi3qGp = k4rNW6UOwPBVDfblusx.get_display(zlWsegnp0V5qbNaHKtvEBZL2S8c.reshape(YDuVHvM5cWC8aP2zoTtZmKyRi3qGp))
			tlJRsXkbjoG6wv4,nGMYqPguChxEvyer3ojTA57W = gwkz9DOuNCF.textsize(YDuVHvM5cWC8aP2zoTtZmKyRi3qGp,font=ZM7a9te0Nj8l2UmXdCOf)
			ulbTqcYNS9 = uumyIokdrsYD6w7fitMX9h2OxGV+0*(w73ODtngboQl9MLBdk+JcpyzXTVeZBaln9E3N0WL26G)+(JcpyzXTVeZBaln9E3N0WL26G-tlJRsXkbjoG6wv4)/2
			gwkz9DOuNCF.text((ulbTqcYNS9,TtXlo0xjkr6DPaAfKBN8hpH2),YDuVHvM5cWC8aP2zoTtZmKyRi3qGp,font=ZM7a9te0Nj8l2UmXdCOf,fill='yellow')
		if vm5oH810DdpOTNQ:
			vm5oH810DdpOTNQ = k4rNW6UOwPBVDfblusx.get_display(zlWsegnp0V5qbNaHKtvEBZL2S8c.reshape(vm5oH810DdpOTNQ))
			CohiIYMQV6Ssxenb4T2N,kwKmltG1QPu4LXyM70Jazroe = gwkz9DOuNCF.textsize(vm5oH810DdpOTNQ,font=ZM7a9te0Nj8l2UmXdCOf)
			UUh4nuIbOEl = uumyIokdrsYD6w7fitMX9h2OxGV+1*(w73ODtngboQl9MLBdk+JcpyzXTVeZBaln9E3N0WL26G)+(JcpyzXTVeZBaln9E3N0WL26G-CohiIYMQV6Ssxenb4T2N)/2
			gwkz9DOuNCF.text((UUh4nuIbOEl,TtXlo0xjkr6DPaAfKBN8hpH2),vm5oH810DdpOTNQ,font=ZM7a9te0Nj8l2UmXdCOf,fill='yellow')
		if BA6DPe4zKN1qOUh:
			BA6DPe4zKN1qOUh = k4rNW6UOwPBVDfblusx.get_display(zlWsegnp0V5qbNaHKtvEBZL2S8c.reshape(BA6DPe4zKN1qOUh))
			pncj6JHWgiDRelQT5sPdvOC0oFwzt,PPErW8bG06Z7cBXlUzpwQg = gwkz9DOuNCF.textsize(BA6DPe4zKN1qOUh,font=ZM7a9te0Nj8l2UmXdCOf)
			zcxWrpOwFPG3KNYQfs4jJbUd2m = uumyIokdrsYD6w7fitMX9h2OxGV+2*(w73ODtngboQl9MLBdk+JcpyzXTVeZBaln9E3N0WL26G)+(JcpyzXTVeZBaln9E3N0WL26G-pncj6JHWgiDRelQT5sPdvOC0oFwzt)/2
			gwkz9DOuNCF.text((zcxWrpOwFPG3KNYQfs4jJbUd2m,TtXlo0xjkr6DPaAfKBN8hpH2),BA6DPe4zKN1qOUh,font=ZM7a9te0Nj8l2UmXdCOf,fill='yellow')
	if kc57B93HrojbDIXVipY:
		m4l5kPNxg937HcUM2f0ERYXTevAFs,Xiuj7SIHn9Cgopbv0h = [],[]
		UsdTuGkX51JZt6NraAx = mPecIVr5lK7HnRwhAz2LpYdQ3Ba(UsdTuGkX51JZt6NraAx)
		ATsJ62cNX9PDwIj = UsdTuGkX51JZt6NraAx.split('_sss__newline_')
		for VXp2WSi19Z in ATsJ62cNX9PDwIj:
			TDGpbUicndfM0LsIO = ffl0qAazk1GEPcsb
			if   '_sss__lineleft_' in VXp2WSi19Z: TDGpbUicndfM0LsIO = 'left'
			elif '_sss__lineright_' in VXp2WSi19Z: TDGpbUicndfM0LsIO = 'right'
			elif '_sss__linecenter_' in VXp2WSi19Z: TDGpbUicndfM0LsIO = 'center'
			hdWeTluS05xQUzZj7yib61KqNmEk3 = VXp2WSi19Z
			yb1cYkrjaOB5KVZUJDRehQnX6W = u5h2Rckvw1E.findall('_sss__.*?_',VXp2WSi19Z,u5h2Rckvw1E.DOTALL)
			for IgxrQGC7lci26R43Mw in yb1cYkrjaOB5KVZUJDRehQnX6W: hdWeTluS05xQUzZj7yib61KqNmEk3 = hdWeTluS05xQUzZj7yib61KqNmEk3.replace(IgxrQGC7lci26R43Mw,'')
			if hdWeTluS05xQUzZj7yib61KqNmEk3=='': qyAn75RzIgCV8LbQU3S2wiEJTk09G,cdN60sYWKyn = 0,oM5KBp8tfd6zvk0
			else: qyAn75RzIgCV8LbQU3S2wiEJTk09G,cdN60sYWKyn = gwkz9DOuNCF.textsize(hdWeTluS05xQUzZj7yib61KqNmEk3,font=pWqjt9CO3QMgoXSvIF4)
			if   TDGpbUicndfM0LsIO=='left': h1at2SrRCvF73zAu4jcJLWY = wWEsQANz0McVmyxFU+nVkXORUe1qyB6wlo
			elif TDGpbUicndfM0LsIO=='right': h1at2SrRCvF73zAu4jcJLWY = wWEsQANz0McVmyxFU+nVkXORUe1qyB6wlo+oKf0SyP2huITrBOsgLv81CV-qyAn75RzIgCV8LbQU3S2wiEJTk09G
			elif TDGpbUicndfM0LsIO=='center': h1at2SrRCvF73zAu4jcJLWY = wWEsQANz0McVmyxFU+nVkXORUe1qyB6wlo+(oKf0SyP2huITrBOsgLv81CV-qyAn75RzIgCV8LbQU3S2wiEJTk09G)/2
			if h1at2SrRCvF73zAu4jcJLWY<nVkXORUe1qyB6wlo: h1at2SrRCvF73zAu4jcJLWY = wWEsQANz0McVmyxFU+nVkXORUe1qyB6wlo
			m4l5kPNxg937HcUM2f0ERYXTevAFs.append(h1at2SrRCvF73zAu4jcJLWY)
			Xiuj7SIHn9Cgopbv0h.append(qyAn75RzIgCV8LbQU3S2wiEJTk09G)
		h1at2SrRCvF73zAu4jcJLWY = m4l5kPNxg937HcUM2f0ERYXTevAFs[0]
		BwX2iNCL5V6cxk8IFs1HvMjrJOp = UsdTuGkX51JZt6NraAx.split('_sss_')
		q5jWA0ERwhiUlkY = (255,255,255,255)
		qqeRPc9hNFQSl1EBwjMb8 = q5jWA0ERwhiUlkY
		not9sQTXLNWVC6ywm1u,jPE7qHILX5lD6 = 0,0
		ZKLDiwfy1lr9SWRp = False
		EkaKQqmbWCNM0Hin6vDRcIVpfFJ = 0
		Tp9A4gDveYrkIiczsMXjO = s8pjWMqFfy3EckwX+U9MzoVFx8bur37KeX4EIlsftOmi0/2
		if tL9bQCZydc<(SI2s47tAdwb+U9MzoVFx8bur37KeX4EIlsftOmi0):
			M2cbjeElUta = (SI2s47tAdwb+U9MzoVFx8bur37KeX4EIlsftOmi0-tL9bQCZydc)/2
			Tp9A4gDveYrkIiczsMXjO = s8pjWMqFfy3EckwX+U9MzoVFx8bur37KeX4EIlsftOmi0+M2cbjeElUta-JvFyrpU4Hfm21VGSkEh3/2
		for Bx1JlohpcEg in BwX2iNCL5V6cxk8IFs1HvMjrJOp:
			if not Bx1JlohpcEg or (Bx1JlohpcEg and ord(Bx1JlohpcEg[0])==65279): continue
			aaIFUMNYL02RwJtxDb3h1rSum8 = Bx1JlohpcEg.split('_newline_',1)
			VZSs7ALxRHMmk = Bx1JlohpcEg.split('_newcolor',1)
			mKXRgzw4ZJjL3tN = Bx1JlohpcEg.split('_endcolor_',1)
			fUid8ex5OP0Kul9cnHGErYVmD = Bx1JlohpcEg.split('_linertl_',1)
			Z6wosSLKFBIcbEX7jinqlJrayf9z = Bx1JlohpcEg.split('_lineleft_',1)
			b14WuUIcrzpX5dVshiD = Bx1JlohpcEg.split('_lineright_',1)
			wcyPAku7eidrOIvC9mF6Xh = Bx1JlohpcEg.split('_linecenter_',1)
			if len(aaIFUMNYL02RwJtxDb3h1rSum8)>1:
				EkaKQqmbWCNM0Hin6vDRcIVpfFJ += 1
				Bx1JlohpcEg = aaIFUMNYL02RwJtxDb3h1rSum8[1]
				not9sQTXLNWVC6ywm1u = 0
				h1at2SrRCvF73zAu4jcJLWY = m4l5kPNxg937HcUM2f0ERYXTevAFs[EkaKQqmbWCNM0Hin6vDRcIVpfFJ]
				jPE7qHILX5lD6 += oM5KBp8tfd6zvk0
				ZKLDiwfy1lr9SWRp = False
			elif len(VZSs7ALxRHMmk)>1:
				Bx1JlohpcEg = VZSs7ALxRHMmk[1]
				qqeRPc9hNFQSl1EBwjMb8 = Bx1JlohpcEg[0:8]
				qqeRPc9hNFQSl1EBwjMb8 = '#'+qqeRPc9hNFQSl1EBwjMb8[2:]
				Bx1JlohpcEg = Bx1JlohpcEg[9:]
			elif len(mKXRgzw4ZJjL3tN)>1:
				Bx1JlohpcEg = mKXRgzw4ZJjL3tN[1]
				qqeRPc9hNFQSl1EBwjMb8 = q5jWA0ERwhiUlkY
			elif len(fUid8ex5OP0Kul9cnHGErYVmD)>1:
				Bx1JlohpcEg = fUid8ex5OP0Kul9cnHGErYVmD[1]
				ZKLDiwfy1lr9SWRp = True
				not9sQTXLNWVC6ywm1u = Xiuj7SIHn9Cgopbv0h[EkaKQqmbWCNM0Hin6vDRcIVpfFJ]
			elif len(Z6wosSLKFBIcbEX7jinqlJrayf9z)>1: Bx1JlohpcEg = Z6wosSLKFBIcbEX7jinqlJrayf9z[1]
			elif len(b14WuUIcrzpX5dVshiD)>1: Bx1JlohpcEg = b14WuUIcrzpX5dVshiD[1]
			elif len(wcyPAku7eidrOIvC9mF6Xh)>1: Bx1JlohpcEg = wcyPAku7eidrOIvC9mF6Xh[1]
			if Bx1JlohpcEg:
				lZSUQYuGeE1HcztqRjN = Tp9A4gDveYrkIiczsMXjO+jPE7qHILX5lD6
				Bx1JlohpcEg = k4rNW6UOwPBVDfblusx.get_display(Bx1JlohpcEg)
				qyAn75RzIgCV8LbQU3S2wiEJTk09G,cdN60sYWKyn = gwkz9DOuNCF.textsize(Bx1JlohpcEg,font=pWqjt9CO3QMgoXSvIF4)
				if ZKLDiwfy1lr9SWRp: not9sQTXLNWVC6ywm1u -= qyAn75RzIgCV8LbQU3S2wiEJTk09G
				esQ6jHNTWoD9YPyM0dL = h1at2SrRCvF73zAu4jcJLWY+not9sQTXLNWVC6ywm1u
				gwkz9DOuNCF.text((esQ6jHNTWoD9YPyM0dL,lZSUQYuGeE1HcztqRjN),Bx1JlohpcEg,font=pWqjt9CO3QMgoXSvIF4,fill=qqeRPc9hNFQSl1EBwjMb8)
				if SmTnypJH7G=='menu_item':
					gwkz9DOuNCF.text((esQ6jHNTWoD9YPyM0dL+1,lZSUQYuGeE1HcztqRjN+1),Bx1JlohpcEg,font=pWqjt9CO3QMgoXSvIF4,fill=qqeRPc9hNFQSl1EBwjMb8)
				if not ZKLDiwfy1lr9SWRp: not9sQTXLNWVC6ywm1u += qyAn75RzIgCV8LbQU3S2wiEJTk09G
				if lZSUQYuGeE1HcztqRjN>SI2s47tAdwb+oM5KBp8tfd6zvk0: break
	if SmTnypJH7G=='menu_item':
		TWtIXrysgQ = TWtIXrysgQ.resize((200,200))
		umBFHKR9I4rj0Ebs6aozf5w8gAk1 = jMfFQ6CH1ZungPrJq3RkpBWo2.copy()
		umBFHKR9I4rj0Ebs6aozf5w8gAk1.paste(N967UTMqGLjElWpSrg,(0,0),mask=TWtIXrysgQ)
	else: umBFHKR9I4rj0Ebs6aozf5w8gAk1 = TWtIXrysgQ
	if bdptXFc8UlIhA5jnGwPmKuv2L: OhIiJR8kLZYKg5Qj64FSqoUCN17l = OhIiJR8kLZYKg5Qj64FSqoUCN17l.decode('utf8')
	try: umBFHKR9I4rj0Ebs6aozf5w8gAk1.save(OhIiJR8kLZYKg5Qj64FSqoUCN17l)
	except:
		ct3IwWuXlCLvzdym1hH = k1t0JLRsCQ.path.dirname(OhIiJR8kLZYKg5Qj64FSqoUCN17l)
		try: k1t0JLRsCQ.makedirs(ct3IwWuXlCLvzdym1hH)
		except: pass
		umBFHKR9I4rj0Ebs6aozf5w8gAk1.save(OhIiJR8kLZYKg5Qj64FSqoUCN17l)
	return MVlaCtubcNxHIJDZYFSi4Azo
def gBPEpQVGSwXA(Ipn2iQe6KwMSZrfDWVJqBN,Bb4hZc2mwdqPIzNoRKEOWl,hkelKVQOyo9zFncq6LwAr0G18vCH,GHs1EnNzvpY8cTMeK6VLf):
	gTFGkLnC3UzowjiW,mJKSkQPFLGjIZp58V7lXBt,JOA78E5Gby0wx6cqKPRZCNHBaUV = '',0,15000
	Ipn2iQe6KwMSZrfDWVJqBN = Ipn2iQe6KwMSZrfDWVJqBN.replace('[COLOR ','[COLOR:::')
	gTxAtWqhFavl = U0ecS5D43xq1XngdI97rjVThBf8.truetype(JH6Z129abNsUoj8xG,size=Bb4hZc2mwdqPIzNoRKEOWl)
	hkelKVQOyo9zFncq6LwAr0G18vCH -= Bb4hZc2mwdqPIzNoRKEOWl*2
	TWtIXrysgQ = ss4Y30c7iC.new('RGBA',(hkelKVQOyo9zFncq6LwAr0G18vCH,99),(255,255,255,0))
	gwkz9DOuNCF = XXt3yJYkxgvLsRBpuhZPOH7wMIo.Draw(TWtIXrysgQ)
	for S8xT261YIBPJnXldKkF5b in Ipn2iQe6KwMSZrfDWVJqBN.splitlines():
		mJKSkQPFLGjIZp58V7lXBt += GHs1EnNzvpY8cTMeK6VLf
		fYq617lUxoVnpFOKeGM0zrQ,JJrNfMLhm0li5cxD2IFvB6OjPosApt = 0,''
		for l8lTcPnLqj6Y2QpmyrJ in S8xT261YIBPJnXldKkF5b.split(' '):
			CXkrK6os7p14j5nd3 = DZXlerKn1bzfIs5yBFN8dgjhCT0vQ(' '+l8lTcPnLqj6Y2QpmyrJ)
			hVoqjd8KPZFi4RgAIvLtrW3bmHOX1,lrt86qZf2QbH = gwkz9DOuNCF.textsize(CXkrK6os7p14j5nd3,font=gTxAtWqhFavl)
			if fYq617lUxoVnpFOKeGM0zrQ+hVoqjd8KPZFi4RgAIvLtrW3bmHOX1<hkelKVQOyo9zFncq6LwAr0G18vCH:
				if not JJrNfMLhm0li5cxD2IFvB6OjPosApt: JJrNfMLhm0li5cxD2IFvB6OjPosApt += l8lTcPnLqj6Y2QpmyrJ
				else: JJrNfMLhm0li5cxD2IFvB6OjPosApt += ' '+l8lTcPnLqj6Y2QpmyrJ
				fYq617lUxoVnpFOKeGM0zrQ += hVoqjd8KPZFi4RgAIvLtrW3bmHOX1
			else:
				if hVoqjd8KPZFi4RgAIvLtrW3bmHOX1<hkelKVQOyo9zFncq6LwAr0G18vCH:
					JJrNfMLhm0li5cxD2IFvB6OjPosApt += '\n '+l8lTcPnLqj6Y2QpmyrJ
					mJKSkQPFLGjIZp58V7lXBt += GHs1EnNzvpY8cTMeK6VLf
					fYq617lUxoVnpFOKeGM0zrQ = hVoqjd8KPZFi4RgAIvLtrW3bmHOX1
				else:
					while hVoqjd8KPZFi4RgAIvLtrW3bmHOX1>hkelKVQOyo9zFncq6LwAr0G18vCH:
						for OTxp2K4Vayb8CoUFJSWA in range(1,len(' '+l8lTcPnLqj6Y2QpmyrJ),1):
							yXpBPzQmlkF3T1reqHbL = ' '+l8lTcPnLqj6Y2QpmyrJ[:OTxp2K4Vayb8CoUFJSWA]
							N0d9T3SVlhD = l8lTcPnLqj6Y2QpmyrJ[OTxp2K4Vayb8CoUFJSWA:]
							Z0ZOphUHsV5d = DZXlerKn1bzfIs5yBFN8dgjhCT0vQ(yXpBPzQmlkF3T1reqHbL)
							agmGLdOh6YMJuUrHpA9Pl,emsILBMVj5AG2kFZ = gwkz9DOuNCF.textsize(Z0ZOphUHsV5d,font=gTxAtWqhFavl)
							if fYq617lUxoVnpFOKeGM0zrQ+agmGLdOh6YMJuUrHpA9Pl>hkelKVQOyo9zFncq6LwAr0G18vCH:
								TTt1BXJaACGsvjh7N5mq = hVoqjd8KPZFi4RgAIvLtrW3bmHOX1-agmGLdOh6YMJuUrHpA9Pl
								JJrNfMLhm0li5cxD2IFvB6OjPosApt += yXpBPzQmlkF3T1reqHbL+'\n'
								mJKSkQPFLGjIZp58V7lXBt += GHs1EnNzvpY8cTMeK6VLf
								hVoqjd8KPZFi4RgAIvLtrW3bmHOX1 = TTt1BXJaACGsvjh7N5mq
								if TTt1BXJaACGsvjh7N5mq>hkelKVQOyo9zFncq6LwAr0G18vCH:
									fYq617lUxoVnpFOKeGM0zrQ = 0
									l8lTcPnLqj6Y2QpmyrJ = N0d9T3SVlhD
								else:
									fYq617lUxoVnpFOKeGM0zrQ = TTt1BXJaACGsvjh7N5mq
									JJrNfMLhm0li5cxD2IFvB6OjPosApt += N0d9T3SVlhD
								break
				if mJKSkQPFLGjIZp58V7lXBt>JOA78E5Gby0wx6cqKPRZCNHBaUV: break
		gTFGkLnC3UzowjiW += '\n'+JJrNfMLhm0li5cxD2IFvB6OjPosApt
		if mJKSkQPFLGjIZp58V7lXBt>JOA78E5Gby0wx6cqKPRZCNHBaUV: break
	gTFGkLnC3UzowjiW = gTFGkLnC3UzowjiW[1:]
	gTFGkLnC3UzowjiW = gTFGkLnC3UzowjiW.replace('[COLOR:::','[COLOR ')
	return gTFGkLnC3UzowjiW
def DZXlerKn1bzfIs5yBFN8dgjhCT0vQ(l8lTcPnLqj6Y2QpmyrJ):
	if '[' in l8lTcPnLqj6Y2QpmyrJ and ']' in l8lTcPnLqj6Y2QpmyrJ:
		yb1cYkrjaOB5KVZUJDRehQnX6W = ['[/COLOR]','[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		pTD95eVMrOPZwBgzls6IK1 = u5h2Rckvw1E.findall('\[COLOR .*?\]',l8lTcPnLqj6Y2QpmyrJ,u5h2Rckvw1E.DOTALL)
		XpAWyML1YUH = u5h2Rckvw1E.findall('\[COLOR:::.*?\]',l8lTcPnLqj6Y2QpmyrJ,u5h2Rckvw1E.DOTALL)
		MUjhKNColPmxyutEIpArJZO31 = yb1cYkrjaOB5KVZUJDRehQnX6W+pTD95eVMrOPZwBgzls6IK1+XpAWyML1YUH
		for IgxrQGC7lci26R43Mw in MUjhKNColPmxyutEIpArJZO31: l8lTcPnLqj6Y2QpmyrJ = l8lTcPnLqj6Y2QpmyrJ.replace(IgxrQGC7lci26R43Mw,'')
	return l8lTcPnLqj6Y2QpmyrJ
def mPecIVr5lK7HnRwhAz2LpYdQ3Ba(kc57B93HrojbDIXVipY):
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('\n','_sss__newline_')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('[RTL]','_sss__linertl_')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('[LEFT]','_sss__lineleft_')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('[RIGHT]','_sss__lineright_')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('[CENTER]','_sss__linecenter_')
	kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('[/COLOR]','_sss__endcolor_')
	qu3sbdPvU1w7oMSID5lkeAynVFQJX2 = u5h2Rckvw1E.findall('\[COLOR (.*?)\]',kc57B93HrojbDIXVipY,u5h2Rckvw1E.DOTALL)
	for EA4f3Usa6bIkGt in qu3sbdPvU1w7oMSID5lkeAynVFQJX2: kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.replace('[COLOR '+EA4f3Usa6bIkGt+']','_sss__newcolor'+EA4f3Usa6bIkGt+'_')
	return kc57B93HrojbDIXVipY
def eoblnvIyaChYrkj(WGy8jZubInXc7zRBJ5p=''):
	if not WGy8jZubInXc7zRBJ5p: WGy8jZubInXc7zRBJ5p = bMIascyFJ2x43E0C7glTB91h8qz.getInfoLabel('ListItem.Label')
	WGy8jZubInXc7zRBJ5p = WGy8jZubInXc7zRBJ5p.replace('[/COLOR]','')
	WGy8jZubInXc7zRBJ5p = WGy8jZubInXc7zRBJ5p.replace('    ',' ').replace('   ',' ').replace('  ',' ').strip(' ')
	WGy8jZubInXc7zRBJ5p = WGy8jZubInXc7zRBJ5p.replace('[COLOR FFFFFF00]','').replace('[COLOR FFC89008]','')
	hTkQuRrVocYC2APE7bWq3 = u5h2Rckvw1E.findall('\d\d:\d\d ',WGy8jZubInXc7zRBJ5p,u5h2Rckvw1E.DOTALL)
	if hTkQuRrVocYC2APE7bWq3: WGy8jZubInXc7zRBJ5p = WGy8jZubInXc7zRBJ5p.split(hTkQuRrVocYC2APE7bWq3[0],1)[1]
	if not WGy8jZubInXc7zRBJ5p: WGy8jZubInXc7zRBJ5p = 'Main Menu'
	return WGy8jZubInXc7zRBJ5p
def nkV8dCRtNgiBYMJTxLI(gn7mjNUzap):
	qqZu05MG3fzc9dTeOAwbLo = ''.join(OTxp2K4Vayb8CoUFJSWA for OTxp2K4Vayb8CoUFJSWA in gn7mjNUzap if OTxp2K4Vayb8CoUFJSWA not in '\/":*?<>|'+Rzh5Iv8cO0AGFq9D)
	return qqZu05MG3fzc9dTeOAwbLo
def zz4hcMfiyUwxHgBDt(Iy4bwu3m6qORhDrQSd19HYo8):
	TvaUZzcHJK = u5h2Rckvw1E.findall("adilbo_HTML_encoder(.*?)/g.....(.*?)\)",Iy4bwu3m6qORhDrQSd19HYo8,u5h2Rckvw1E.S)
	if TvaUZzcHJK:
		P8KUZlHByc61i5jrN,Nr9zDIpSwlQ58WngyCbUoq1j2H = TvaUZzcHJK[0]
		P8KUZlHByc61i5jrN = u5h2Rckvw1E.findall("=[\r\n\s\t]+'(.*?)';", P8KUZlHByc61i5jrN, u5h2Rckvw1E.S)[0]
		if P8KUZlHByc61i5jrN and Nr9zDIpSwlQ58WngyCbUoq1j2H:
			KTdrhEqFmgabBW4isQ9O = P8KUZlHByc61i5jrN.replace("'",'').replace("+",'').replace("\n",'').replace("\r",'')
			aMH0GOIov8nPC = KTdrhEqFmgabBW4isQ9O.split('.')
			Iy4bwu3m6qORhDrQSd19HYo8 = ''
			for R0lMWqO9oVbAKZ6uIs54irUyCdj1L8 in aMH0GOIov8nPC:
				hdjLKgiUQ7DB4Zf = yB3NPc2ZhbwFEi1X0dv.b64decode(R0lMWqO9oVbAKZ6uIs54irUyCdj1L8+'==').decode('utf8')
				Qm0GaWlCOw6oPnz1uBRtpi = u5h2Rckvw1E.findall('\d+', hdjLKgiUQ7DB4Zf, u5h2Rckvw1E.S)
				if Qm0GaWlCOw6oPnz1uBRtpi:
					ppdcYXrH7GDve = int(Qm0GaWlCOw6oPnz1uBRtpi[0])
					ppdcYXrH7GDve += int(Nr9zDIpSwlQ58WngyCbUoq1j2H)
					Iy4bwu3m6qORhDrQSd19HYo8 = Iy4bwu3m6qORhDrQSd19HYo8 + chr(ppdcYXrH7GDve)
			if VVGRN7xiyj: Iy4bwu3m6qORhDrQSd19HYo8 = Iy4bwu3m6qORhDrQSd19HYo8.encode('iso-8859-1').decode('utf8')
	return Iy4bwu3m6qORhDrQSd19HYo8
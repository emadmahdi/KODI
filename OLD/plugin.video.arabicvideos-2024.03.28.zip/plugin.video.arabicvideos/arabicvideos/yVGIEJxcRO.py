# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'FAJERSHOW'
tiCRYyX1bWd40Ir3PafQu = '_FJS_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['التصنيفات','انشاء حساب','طلبات الزوّار']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==390: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==391: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,text)
	elif mode==392: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==393: vS7JufTVsBxw52 = GA2KIlbOsoYtxpkDF71(url)
	elif mode==399: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',399,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',yONJxHER9BIDPpTV4YsWmc0n,'','','','','FAJERSHOW-MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	items = u5h2Rckvw1E.findall('<header>.*?<h2>(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	for bHMj0q6zaN in range(len(items)):
		title = items[bHMj0q6zaN]
		uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,yONJxHER9BIDPpTV4YsWmc0n,391,'','','latest'+str(bHMj0q6zaN))
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'مختارات عشوائية',yONJxHER9BIDPpTV4YsWmc0n,391,'','','randoms')
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'أعلى الأفلام تقييماً',yONJxHER9BIDPpTV4YsWmc0n,391,'','','top_imdb_movies')
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'أعلى المسلسلات تقييماً',yONJxHER9BIDPpTV4YsWmc0n,391,'','','top_imdb_series')
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'أفلام مميزة',yONJxHER9BIDPpTV4YsWmc0n+'/movies',391,'','','featured_movies')
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'مسلسلات مميزة',yONJxHER9BIDPpTV4YsWmc0n+'/tvshows',391,'','','featured_tvshows')
	lmO2YJGr6tCV = ''
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="menu"(.*?)id="contenedor"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi: lmO2YJGr6tCV += cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',yONJxHER9BIDPpTV4YsWmc0n+'/movies','','','','','FAJERSHOW-MENU-2nd')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="releases"(.*?)aside',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi: lmO2YJGr6tCV += cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	mgka3ynHUhDN1 = True
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		title = uTUNPkVwCMKiD5gHLaj(title)
		if title=='الأعلى مشاهدة':
			if mgka3ynHUhDN1:
				title = 'الافلام '+title
				mgka3ynHUhDN1 = False
			else: title = 'المسلسلات '+title
		if title not in WLI5tgXRbUPNGJCSVz0vKjBDei3:
			if title=='أفلام': uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,yONJxHER9BIDPpTV4YsWmc0n+'/movies',391,'','','all_movies_tvshows')
			elif title=='مسلسلات': uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,yONJxHER9BIDPpTV4YsWmc0n+'/tvshows',391,'','','all_movies_tvshows')
			else: uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,391)
	return oo9SgGkiDbs3HRn7z8
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,type):
	lmO2YJGr6tCV,items = [],[]
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','FAJERSHOW-TITLES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	if type in ['featured_movies','featured_tvshows']:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="content"(.*?)id="archive-content"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi: lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	elif type=='all_movies_tvshows':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('id="archive-content"(.*?)class="pagination"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi: lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	elif type=='top_imdb_movies':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall("class='top-imdb-list tleft(.*?)class='top-imdb-list tright",oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	elif type=='top_imdb_series':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall("class='top-imdb-list tright(.*?)footer",oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	elif type=='search':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="search-page"(.*?)class="sidebar',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	elif type=='sider':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="widget(.*?)class="widget',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		Cme2tRqGfkrX = u5h2Rckvw1E.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		EaBeVhOsHYg8wub,uix8pDMdNJZ6VFQzcOPWX,hVby8e3aQkFfuE = zip(*Cme2tRqGfkrX)
		items = zip(uix8pDMdNJZ6VFQzcOPWX,EaBeVhOsHYg8wub,hVby8e3aQkFfuE)
	elif type=='randoms':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('id="slider-movies-tvshows"(.*?)<header>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	elif 'latest' in type:
		bHMj0q6zaN = int(type[-1:])
		oo9SgGkiDbs3HRn7z8 = oo9SgGkiDbs3HRn7z8.replace('<header>','<end><start>')
		oo9SgGkiDbs3HRn7z8 = oo9SgGkiDbs3HRn7z8.replace('</div></div></div>','</div></div></div><end>')
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('<start>(.*?)<end>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[bHMj0q6zaN]
		if bHMj0q6zaN==6:
			Cme2tRqGfkrX = u5h2Rckvw1E.findall('img src="(.*?)" alt="(.*?)".*?href="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			uix8pDMdNJZ6VFQzcOPWX,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = zip(*Cme2tRqGfkrX)
			items = zip(uix8pDMdNJZ6VFQzcOPWX,EaBeVhOsHYg8wub,hVby8e3aQkFfuE)
	else:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="content"(.*?)class="(pagination|sidebar)',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0][0]
			if '/collection/' in url:
				items = u5h2Rckvw1E.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			elif '/quality/' in url:
				items = u5h2Rckvw1E.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	if not items and lmO2YJGr6tCV:
		items = u5h2Rckvw1E.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	yn8DkpE5etF3WiUmfSO = []
	for pGjsvdyHfM,ekTrZlFMu0Kf5QztEnhAs,title in items:
		if 'src=' in title: continue
		if 'serie' in title:
			title = u5h2Rckvw1E.findall('^(.*?)<.*?serie">(.*?)<',title,u5h2Rckvw1E.DOTALL)
			title = title[0][1]
			if title in yn8DkpE5etF3WiUmfSO: continue
			yn8DkpE5etF3WiUmfSO.append(title)
			title = '_MOD_'+title
		cMpjL2oavyVwKHBPn8EdhYqxSUk = u5h2Rckvw1E.findall('^(.*?)<',title,u5h2Rckvw1E.DOTALL)
		if cMpjL2oavyVwKHBPn8EdhYqxSUk: title = cMpjL2oavyVwKHBPn8EdhYqxSUk[0]
		title = uTUNPkVwCMKiD5gHLaj(title)
		if '/tvshows/' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,393,pGjsvdyHfM)
		elif '/episodes/' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,393,pGjsvdyHfM)
		elif '/seasons/' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,393,pGjsvdyHfM)
		elif '/collection/' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,391,pGjsvdyHfM)
		else: uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,392,pGjsvdyHfM)
	if type not in ['featured_movies','featured_tvshows']:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"pagination"(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,title in items:
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+title,ekTrZlFMu0Kf5QztEnhAs,391,'','',type)
	return
def GA2KIlbOsoYtxpkDF71(url):
	NDwLctrHpYz3JBP = hmcFWJUgiAuGk(url,'url')
	url = url.replace(NDwLctrHpYz3JBP,yONJxHER9BIDPpTV4YsWmc0n)
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','FAJERSHOW-EPISODES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	PmF0XjQN51GpKACfLgnyTv7 = u5h2Rckvw1E.findall('class="C rated".*?>(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if PmF0XjQN51GpKACfLgnyTv7 and dQorkS3qBhIMDWKHl(aUVSgO2ebjwX5iqPykC,url,PmF0XjQN51GpKACfLgnyTv7): return
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('<ul class="episodios">(.*?)</ul></div></div></div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('src="(.*?)".*?href="(.*?)">(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for pGjsvdyHfM,ekTrZlFMu0Kf5QztEnhAs,title in items:
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,392,pGjsvdyHfM)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	oo9SgGkiDbs3HRn7z8 = lVwNyt5c8I1HzOdKinf4(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','FAJERSHOW-PLAY-1st')
	PmF0XjQN51GpKACfLgnyTv7 = u5h2Rckvw1E.findall('class="C rated".*?>(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if PmF0XjQN51GpKACfLgnyTv7 and dQorkS3qBhIMDWKHl(aUVSgO2ebjwX5iqPykC,url,PmF0XjQN51GpKACfLgnyTv7): return
	EaBeVhOsHYg8wub = []
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('id="player-option-1"(.*?)class=["|\'](sheader|pag_episodes)["|\']',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0][0]
		items = u5h2Rckvw1E.findall('data-type="(.*?)" data-post="(.*?)" data-nume="(.*?)".*?class="vid_title">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for type,iXJGxum8sYHFrU,bvNCGlPHYIfFQ143dWRTMSE0tZ5nj,title in items:
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/wp-admin/admin-ajax.php?action=doo_player_ajax&post='+iXJGxum8sYHFrU+'&nume='+bvNCGlPHYIfFQ143dWRTMSE0tZ5nj+'&type='+type
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+title+'__watch'
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('''id=["']download["'] class(.*?)class=["']sbox["']''',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('''img src=["'](.*?)["'].*?href=["'](.*?)["'].*?["']quality["']>(.*?)<.*?<td>(.*?)<''',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for pGjsvdyHfM,ekTrZlFMu0Kf5QztEnhAs,ohAHUqdbWFi8D1L4Xwzus0f3RYv,AAj0QysJwULt1ha8gBXZTR in items:
			if '=' in pGjsvdyHfM:
				gH8XUubef1v5 = pGjsvdyHfM.split('=')[1]
				title = hmcFWJUgiAuGk(gH8XUubef1v5,'host')
			else: title = ''
			title = AAj0QysJwULt1ha8gBXZTR+' '+title
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+title+'__download____'+ohAHUqdbWFi8D1L4Xwzus0f3RYv
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(EaBeVhOsHYg8wub,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	search = search.replace(' ','+')
	url = yONJxHER9BIDPpTV4YsWmc0n+'/?s='+search
	ll0a2AwztChcpsDUMi4rGW3b61XZES(url,'search')
	return
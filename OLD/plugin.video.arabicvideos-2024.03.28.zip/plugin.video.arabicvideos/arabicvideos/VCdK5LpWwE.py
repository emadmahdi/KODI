# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'MOVS4U'
tiCRYyX1bWd40Ir3PafQu = '_M4U_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['انواع افلام','جودات افلام']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==380: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==381: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,text)
	elif mode==382: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==383: vS7JufTVsBxw52 = GA2KIlbOsoYtxpkDF71(url)
	elif mode==389: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',389,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'المميزة',yONJxHER9BIDPpTV4YsWmc0n,381,'','','featured')
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'الجانبية',yONJxHER9BIDPpTV4YsWmc0n,381,'','','sider')
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',yONJxHER9BIDPpTV4YsWmc0n,'','','','','MOVS4U-MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	items = u5h2Rckvw1E.findall('<header>.*?<h2>(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	for bHMj0q6zaN in range(len(items)):
		title = items[bHMj0q6zaN]
		uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,yONJxHER9BIDPpTV4YsWmc0n,381,'','','latest'+str(bHMj0q6zaN))
	lmO2YJGr6tCV = ''
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="menu"(.*?)id="contenedor"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi: lmO2YJGr6tCV += cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="sidebar(.*?)aside',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi: lmO2YJGr6tCV += cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	mgka3ynHUhDN1 = True
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		title = uTUNPkVwCMKiD5gHLaj(title)
		if title=='الأعلى مشاهدة':
			if mgka3ynHUhDN1:
				title = 'الافلام '+title
				mgka3ynHUhDN1 = False
			else: title = 'المسلسلات '+title
		if title not in WLI5tgXRbUPNGJCSVz0vKjBDei3:
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,381)
	return oo9SgGkiDbs3HRn7z8
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,type):
	lmO2YJGr6tCV,items = [],[]
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','MOVS4U-TITLES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	if type=='search':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="search-page"(.*?)class="sidebar',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	elif type=='sider':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="widget(.*?)class="widget',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		kkMHDhGo0UpisnOJfKgAQbq2Z = u5h2Rckvw1E.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		EaBeVhOsHYg8wub,uix8pDMdNJZ6VFQzcOPWX,hVby8e3aQkFfuE = zip(*kkMHDhGo0UpisnOJfKgAQbq2Z)
		items = zip(uix8pDMdNJZ6VFQzcOPWX,EaBeVhOsHYg8wub,hVby8e3aQkFfuE)
	elif type=='featured':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('id="slider-movies-tvshows"(.*?)<header>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	elif 'latest' in type:
		bHMj0q6zaN = int(type[-1:])
		oo9SgGkiDbs3HRn7z8 = oo9SgGkiDbs3HRn7z8.replace('<header>','<end><start>')
		oo9SgGkiDbs3HRn7z8 = oo9SgGkiDbs3HRn7z8.replace('<div class="sidebar','<end><div class="sidebar')
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('<start>(.*?)<end>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[bHMj0q6zaN]
		if bHMj0q6zaN==2: items = u5h2Rckvw1E.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	else:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="content"(.*?)class="(pagination|sidebar)',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0][0]
			if '/collection/' in url:
				items = u5h2Rckvw1E.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			elif '/quality/' in url:
				items = u5h2Rckvw1E.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	if not items and lmO2YJGr6tCV:
		items = u5h2Rckvw1E.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	yn8DkpE5etF3WiUmfSO = []
	for pGjsvdyHfM,ekTrZlFMu0Kf5QztEnhAs,title in items:
		if 'serie' in title:
			title = u5h2Rckvw1E.findall('^(.*?)<.*?serie">(.*?)<',title,u5h2Rckvw1E.DOTALL)
			title = title[0][1]
			if title in yn8DkpE5etF3WiUmfSO: continue
			yn8DkpE5etF3WiUmfSO.append(title)
			title = '_MOD_'+title
		cMpjL2oavyVwKHBPn8EdhYqxSUk = u5h2Rckvw1E.findall('^(.*?)<',title,u5h2Rckvw1E.DOTALL)
		if cMpjL2oavyVwKHBPn8EdhYqxSUk: title = cMpjL2oavyVwKHBPn8EdhYqxSUk[0]
		title = uTUNPkVwCMKiD5gHLaj(title)
		if '/tvshows/' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,383,pGjsvdyHfM)
		elif '/episodes/' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,383,pGjsvdyHfM)
		elif '/seasons/' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,383,pGjsvdyHfM)
		elif '/collection/' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,381,pGjsvdyHfM)
		else: uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,382,pGjsvdyHfM)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		Fpo3A0NXhuZ = cWafzb4HoG1Em3Jwxu6C7vZsVi[0][0]
		C9fubSOQEdJ0FV7t5ZBn421yxXjAmI = cWafzb4HoG1Em3Jwxu6C7vZsVi[0][1]
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0][2]
		items = u5h2Rckvw1E.findall("href='(.*?)'.*?>(.*?)<",lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if title=='' or title==C9fubSOQEdJ0FV7t5ZBn421yxXjAmI: continue
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+title,ekTrZlFMu0Kf5QztEnhAs,381,'','',type)
		ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.replace('/page/'+title+'/','/page/'+C9fubSOQEdJ0FV7t5ZBn421yxXjAmI+'/')
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'اخر صفحة '+C9fubSOQEdJ0FV7t5ZBn421yxXjAmI,ekTrZlFMu0Kf5QztEnhAs,381,'','',type)
	return
def GA2KIlbOsoYtxpkDF71(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','MOVS4U-EPISODES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	PmF0XjQN51GpKACfLgnyTv7 = u5h2Rckvw1E.findall('class="C rated".*?>(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if PmF0XjQN51GpKACfLgnyTv7 and dQorkS3qBhIMDWKHl(aUVSgO2ebjwX5iqPykC,url,PmF0XjQN51GpKACfLgnyTv7,False):
		uQNUfbZx9yj0F('link',tiCRYyX1bWd40Ir3PafQu+'المسلسل للكبار والمبرمج منعه','',9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		gANn35esloKUydOipfSMC6RD2 = u5h2Rckvw1E.findall('''class='item'><a href="(.*?)"''',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if gANn35esloKUydOipfSMC6RD2:
			gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2[1]
			GA2KIlbOsoYtxpkDF71(gANn35esloKUydOipfSMC6RD2)
			return
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('''class='episodios'(.*?)id="cast"''',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for pGjsvdyHfM,zAjwuoRY98mXN6xvE,ekTrZlFMu0Kf5QztEnhAs,name in items:
			title = zAjwuoRY98mXN6xvE+' : '+name+' الحلقة'
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,382)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','MOVS4U-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	PmF0XjQN51GpKACfLgnyTv7 = u5h2Rckvw1E.findall('class="C rated".*?>(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if PmF0XjQN51GpKACfLgnyTv7 and dQorkS3qBhIMDWKHl(aUVSgO2ebjwX5iqPykC,url,PmF0XjQN51GpKACfLgnyTv7): return
	EaBeVhOsHYg8wub = []
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0][0]
		items = u5h2Rckvw1E.findall("data-url='(.*?)'.*?class='server'>(.*?)<",lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+title+'__watch'
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="remodal"(.*?)class="remodal-close"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+title+'__download'
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(EaBeVhOsHYg8wub,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	search = search.replace(' ','+')
	url = yONJxHER9BIDPpTV4YsWmc0n+'/?s='+search
	ll0a2AwztChcpsDUMi4rGW3b61XZES(url,'search')
	return
# -*- coding: utf-8 -*-
import sys as vdo2FnhPmAVRMJQZ0EIG8
XzBpdMGJhHZKC8Yveki5qb1jT4nQUg = vdo2FnhPmAVRMJQZ0EIG8.version_info [0] == 2
vykERrdZlF5K = 2048
GG02h4EolRYTs3iv = 7
def tci7BbCy6gT9MXkOEzhm (xVtfmzjd6RSsBEk2o34aHWC):
	global jMo7iTRkq0n1NPa35xheAVlbt
	oAJijr7NHwnfUGqyd8Ru6EImOtv = ord (xVtfmzjd6RSsBEk2o34aHWC [-1])
	wwpaJlB3bkXySOHFWUfoILC = xVtfmzjd6RSsBEk2o34aHWC [:-1]
	lqXRut6PnL = oAJijr7NHwnfUGqyd8Ru6EImOtv % len (wwpaJlB3bkXySOHFWUfoILC)
	rmaU71pZj3X = wwpaJlB3bkXySOHFWUfoILC [:lqXRut6PnL] + wwpaJlB3bkXySOHFWUfoILC [lqXRut6PnL:]
	if XzBpdMGJhHZKC8Yveki5qb1jT4nQUg:
		bbsiU0a49tw2dy = unicode () .join ([unichr (ord (Q9QUIWH6rK2BlmC) - vykERrdZlF5K - (ZXwWfDc9AF4yr2P + oAJijr7NHwnfUGqyd8Ru6EImOtv) % GG02h4EolRYTs3iv) for ZXwWfDc9AF4yr2P, Q9QUIWH6rK2BlmC in enumerate (rmaU71pZj3X)])
	else:
		bbsiU0a49tw2dy = str () .join ([chr (ord (Q9QUIWH6rK2BlmC) - vykERrdZlF5K - (ZXwWfDc9AF4yr2P + oAJijr7NHwnfUGqyd8Ru6EImOtv) % GG02h4EolRYTs3iv) for ZXwWfDc9AF4yr2P, Q9QUIWH6rK2BlmC in enumerate (rmaU71pZj3X)])
	return eval (bbsiU0a49tw2dy)
r3flT0zQPa5H7yXEgxJOt92Vc4Ao,cgtRBdXxSOk7WUfyDhPCls,cNaVb1vsT4qWOL0rpE=tci7BbCy6gT9MXkOEzhm,tci7BbCy6gT9MXkOEzhm,tci7BbCy6gT9MXkOEzhm
yruHDQOcB97ig,drHLAY5ENQFe2q9ptKGabo,qnPgZ9N15G6Oa8UpMASvLk=cNaVb1vsT4qWOL0rpE,cgtRBdXxSOk7WUfyDhPCls,r3flT0zQPa5H7yXEgxJOt92Vc4Ao
KKbpxUZnMcj6AJ4QdD,ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB,ggDRehOModi=qnPgZ9N15G6Oa8UpMASvLk,drHLAY5ENQFe2q9ptKGabo,yruHDQOcB97ig
xuztI5QWEKG70CPNdhk4vo6,bcgZJWV6UeNSkRA,shZ9eOcN2dJnPj=ggDRehOModi,ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB,KKbpxUZnMcj6AJ4QdD
BGhdkWsEvJjiMFTr3NLn1flU,nKLEi8CJumazx4qT,pcWq35MED2dtK=shZ9eOcN2dJnPj,bcgZJWV6UeNSkRA,xuztI5QWEKG70CPNdhk4vo6
yF29Xdsx35wI07Ce4,XikqnGVSK4v9d3uUICLhDxJyt1M,JLoPRXt93dpAB=pcWq35MED2dtK,nKLEi8CJumazx4qT,BGhdkWsEvJjiMFTr3NLn1flU
wwplD0tEehqH3kYQXs,tZ3gsrTEdzA1S6LXa9WI5px,Nqj35AXg06euY1G2d4bSUMQ8wlr=JLoPRXt93dpAB,XikqnGVSK4v9d3uUICLhDxJyt1M,yF29Xdsx35wI07Ce4
bbw2eajMlG,M6PIj8gl1fno7wcqTksDEBK4bU,CgG4PuyxsLA8WDzh3FfteZvKQMdom9=Nqj35AXg06euY1G2d4bSUMQ8wlr,tZ3gsrTEdzA1S6LXa9WI5px,wwplD0tEehqH3kYQXs
iifPEY9ABNzTQp,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ,PtXn0k9G3ocHRg=CgG4PuyxsLA8WDzh3FfteZvKQMdom9,M6PIj8gl1fno7wcqTksDEBK4bU,bbw2eajMlG
Tgoa16jMxvYX2,vvBChXmSty,InKG0i2r6hHDvgd=PtXn0k9G3ocHRg,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ,iifPEY9ABNzTQp
OyJ1o4AvmWlB75UkFRX,usaZLwSGe1k6VDp570yhB4bzWPiFq,oUlIcGH2JuWFLvimMXyBQdzK06ge=InKG0i2r6hHDvgd,vvBChXmSty,Tgoa16jMxvYX2
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔࠩᶈ")
def cc03CYPLaxRfUKJb9eynFTr(wMCm6g9qFyPT0xpneDUNc2lEhaZY,kc57B93HrojbDIXVipY=oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠨࠩᶉ")):
	if   wMCm6g9qFyPT0xpneDUNc2lEhaZY==  r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠰৑"): do2ZFbNCYvwuT(kc57B93HrojbDIXVipY)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==  qnPgZ9N15G6Oa8UpMASvLk(u"࠳৒"): V23iQNjwDUgHl9SFO6h8kbeY(kc57B93HrojbDIXVipY)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==  r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠵৓"): rNIXLajxonpFeP()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==  n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠷৔"): gYUJEp5XQMGC0PjLTdO7BV(kc57B93HrojbDIXVipY)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==  ggDRehOModi(u"࠹৕"): KlbnsSuMmTyxYFt75qaHe0No()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==  shZ9eOcN2dJnPj(u"࠻৖"): MPlbH8aQIhq0C2RdS()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==  cgtRBdXxSOk7WUfyDhPCls(u"࠽ৗ"): NZ0pBCdgQs(yF29Xdsx35wI07Ce4(u"ࡘࡷࡻࡥ઄"),yF29Xdsx35wI07Ce4(u"ࡘࡷࡻࡥ઄"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==  cNaVb1vsT4qWOL0rpE(u"࠸৘"): qhZNrGWaxzEFetmfivAj3n()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==  OyJ1o4AvmWlB75UkFRX(u"࠺৙"): NVtHZIkPqR61()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==cNaVb1vsT4qWOL0rpE(u"࠳࠸࠴৚"): I9OdoE1NHg8M5vx()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==vvBChXmSty(u"࠴࠹࠶৛"): tg09qzI1unZAhidsrfGLc()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==iifPEY9ABNzTQp(u"࠵࠺࠸ড়"): ENPz63e52B()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==bcgZJWV6UeNSkRA(u"࠶࠻࠳ঢ়"): hrTqGJbFIWQlSoPKXswzRM4Z3Vm()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠷࠵࠵৞"): nAV2iYB3LK1Oq()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==cgtRBdXxSOk7WUfyDhPCls(u"࠱࠶࠷য়"): TOICSdzuAfYDUK()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==JLoPRXt93dpAB(u"࠲࠷࠹ৠ"): NLvbHFaBcK5SD()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==vvBChXmSty(u"࠳࠸࠻ৡ"): eFJBGbkH72CwoSTRNAPfv5cW()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==ggDRehOModi(u"࠴࠹࠽ৢ"): ZqWCJrlIaN4TVSzAMj6()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==vvBChXmSty(u"࠵࠺࠿ৣ"): qzko6eUs95i3TuQ8vIWwa(M6PIj8gl1fno7wcqTksDEBK4bU(u"࡙ࡸࡵࡦઅ"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠶࠽࠰৤"): JNQtIWOi0ojMDEY6a7RCr()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠷࠷࠲৥"): rnsqFCN6VESDUPM2HXGobkQ7L9eO()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==cNaVb1vsT4qWOL0rpE(u"࠱࠸࠴০"): DyiGnpNLWIXeFUw(kc57B93HrojbDIXVipY,usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࡚ࡲࡶࡧઆ"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࡚ࡲࡶࡧઆ"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠲࠹࠶১"): tj2FJQMlTw(wwplD0tEehqH3kYQXs(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩᶊ"),cNaVb1vsT4qWOL0rpE(u"ࡔࡳࡷࡨઇ"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==iifPEY9ABNzTQp(u"࠳࠺࠸২"): tj2FJQMlTw(M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡴࡷࡱࡵ࠭ᶋ"),Tgoa16jMxvYX2(u"ࡕࡴࡸࡩઈ"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==InKG0i2r6hHDvgd(u"࠴࠻࠺৩"): wt5Jhmcp0RszHAnQ8XeGlWvk4()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==InKG0i2r6hHDvgd(u"࠵࠼࠼৪"): V0pvqEginmDMuQdAZ()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==pcWq35MED2dtK(u"࠶࠽࠷৫"): oWCT6jn2xKwqrAONSe9(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡷ࡫ࡳࡰ࡮ࡹࡩࡺࡸ࡬ࠨᶌ"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==qnPgZ9N15G6Oa8UpMASvLk(u"࠷࠷࠹৬"): oWCT6jn2xKwqrAONSe9(InKG0i2r6hHDvgd(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤ࡭ࠩᶍ"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==tZ3gsrTEdzA1S6LXa9WI5px(u"࠱࠸࠻৭"): oWCT6jn2xKwqrAONSe9(yF29Xdsx35wI07Ce4(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠭ᶎ"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==ggDRehOModi(u"࠲࠻࠳৮"): ZHmiTvsIR3fCwjhQYdKqlPLaD6EWMx()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==JLoPRXt93dpAB(u"࠳࠼࠵৯"): CDUkvJQISBTZ0Rre()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠴࠽࠷ৰ"): O8AdHNs6l3Ut9v()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==xuztI5QWEKG70CPNdhk4vo6(u"࠵࠾࠹ৱ"): TY3cHO0GawUDZk2usA()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==iifPEY9ABNzTQp(u"࠶࠿࠴৲"): FmM63fBtsoXaK5Ukn()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==cgtRBdXxSOk7WUfyDhPCls(u"࠷࠹࠶৳"): YSWxU2DjBTgNfOR85qECJlzopQh()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==bbw2eajMlG(u"࠱࠺࠸৴"): Tr6zPEU3LKyNRw59VqsMZjn()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==PtXn0k9G3ocHRg(u"࠲࠻࠺৵"): Klsc4JW3hE0Aom()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==BGhdkWsEvJjiMFTr3NLn1flU(u"࠳࠼࠼৶"): tlLQWjHzgnXEDq3Y8COdK4vk9bS2oa()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==PtXn0k9G3ocHRg(u"࠴࠽࠾৷"): LVW5QDqlmafJPF9ZNOBojRCc1kIM()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠷࠹࠶৸"): cJUdZ92Fpu0hTb(kc57B93HrojbDIXVipY)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==iifPEY9ABNzTQp(u"࠸࠺࠱৹"): Z9XBVaT4mCf8sSn1yLidrOvj()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==tZ3gsrTEdzA1S6LXa9WI5px(u"࠹࠴࠳৺"): tEKiexC9OT28r()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==wwplD0tEehqH3kYQXs(u"࠳࠵࠵৻"): RXYo7Vbwr8uM()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠴࠶࠷ৼ"): NXS34upO9xUFQbJjahAWT2I6mVt(cgtRBdXxSOk7WUfyDhPCls(u"ࡖࡵࡹࡪઉ"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==tZ3gsrTEdzA1S6LXa9WI5px(u"࠵࠷࠹৽"): pkg2O3XsHqGhLzY7vnVNUKP()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠶࠸࠻৾"): bDowgWRO58xMB4G3Su7Ac9VICqmKnf(qnPgZ9N15G6Oa8UpMASvLk(u"ࡉࡥࡱࡹࡥઊ"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==KKbpxUZnMcj6AJ4QdD(u"࠷࠹࠽৿"): UOit806xldSDeARyX1waB5Jqs(OyJ1o4AvmWlB75UkFRX(u"ࡘࡷࡻࡥઋ"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==yF29Xdsx35wI07Ce4(u"࠸࠺࠸਀"): EnP0WCjMqFOUyfR5()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠹࠴࠺ਁ"): pass
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠵࠱࠲ਂ"): cTvunr2DqXdoCe46a9Lgkp7HtZz0()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠶࠲࠴ਃ"): DnFVaiKU70YXB6()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==shZ9eOcN2dJnPj(u"࠷࠳࠶਄"): HJaziOsSXQok4uZtRKg2ITfr3bUFEn(PtXn0k9G3ocHRg(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ᶏ"),wwplD0tEehqH3kYQXs(u"࡙ࡸࡵࡦઌ"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==tZ3gsrTEdzA1S6LXa9WI5px(u"࠸࠴࠸ਅ"): xpQtEDjh0vry4mfF3oYkC5(s1KMjlEIH9vd)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==qnPgZ9N15G6Oa8UpMASvLk(u"࠹࠵࠺ਆ"): xpQtEDjh0vry4mfF3oYkC5(MZabdxfVE5WJwUu)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠺࠶࠵ਇ"): DB9YQjko7WUzSLp3ObuECPsamN4X()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠻࠰࠷ਈ"): tBUYedV3Q4FcLRwEx2DnMilz6(InKG0i2r6hHDvgd(u"࡚ࡲࡶࡧઍ"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==cNaVb1vsT4qWOL0rpE(u"࠵࠱࠹ਉ"): uckn8TNJ3yijvBF(kc57B93HrojbDIXVipY,yruHDQOcB97ig(u"ࠨࠩᶐ"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࡔࡳࡷࡨ઎"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==yF29Xdsx35wI07Ce4(u"࠶࠲࠻ਊ"): G1qOXwWd69BHF3MRIhukjgprE04i()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠷࠳࠽਋"): TEYjbkap7MWsKycINRt59qvC2()
	return
def TEYjbkap7MWsKycINRt59qvC2():
	iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠩࠪᶑ"),nKLEi8CJumazx4qT(u"ࠪࠫᶒ"),shZ9eOcN2dJnPj(u"ࠫࠬᶓ"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᶔ"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠭็ๅࠢอี๏ีࠠโ฻็ห๋ࠥำฮࠢฯ้๏฿ࠠฦ฻าหิอสࠡษ็ฬึ์วๆฮࠣ࠲࠳่ࠦๆีะࠤัฺ๋๊่่ࠢๆอสࠡษ็ฬึ์วๆฮࠣห้่ฯ๋็ฬࠤ࠳࠴ࠠๅๅํࠤ๏฿่ะࠢส่อืๆศ็ฯࠤส๊้ࠡฯส่ฮࠦวๅืไีࠥ࠴࠮ࠡ์฼๊๏ࠦสอัํำࠥอไษำ้ห๊า้ࠠฬุๅ๏ื็ฺ๊๋ࠡ฾ํࠠษฯส่ฮࠦวๅ็ุ๊฾ࠦวๅฬํࠤํ฼ู่ษࠣห้๋ศา็ฯࠤฤࠧࠡࠨᶕ"))
	if iZL6cN3OkM5:
		NXS34upO9xUFQbJjahAWT2I6mVt(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࡇࡣ࡯ࡷࡪએ"))
		DzIGOoUJcZT9tQeuX3RyY(OxWkR7Eu9Pm3IAvTp0q,xuztI5QWEKG70CPNdhk4vo6(u"ࡗࡶࡺ࡫ઑ"),shZ9eOcN2dJnPj(u"ࡈࡤࡰࡸ࡫ઐ"))
		xl9MFt1AmY0GrkENug8n(KKbpxUZnMcj6AJ4QdD(u"ࠧࠨᶖ"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠨࠩᶗ"),vvBChXmSty(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᶘ"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࠪฮ๊ࠦๅิฯࠣะ๊๐ูࠡษ็้้็วหࠢส่็ี๊ๆห่้ࠣฮั็ษ่ะࠥ࠴࠮๊ࠡ฼หิࠦวๅสิ๊ฬ๋ฬࠡว็ํࠥ๎ึฺ์ฬࠤฬ๊ีโำࠣ࠲࠳่ࠦื฻ํอࠥอไๆื้฽ࠬᶙ"))
	return
def uckn8TNJ3yijvBF(lY0rst72uGVZ1NkgvpjfA6x,kkvFsou9D5G8RZw1fmH3ynrNT,showDialogs):
	AO76Z1XEaSDjomRwK = Xmn7ZoOHiUB2fKvd6Y8ALct3GsNT.connect(UrA7SvnaILc)
	AO76Z1XEaSDjomRwK.text_factory = str
	BVYESNuJMxlmDo5WXdaFP6r = AO76Z1XEaSDjomRwK.cursor()
	if bdptXFc8UlIhA5jnGwPmKuv2L: ccme3blRKJUW8tVgYCv = JLoPRXt93dpAB(u"ࠫࡧࡲࡡࡤ࡭࡯࡭ࡸࡺࠧᶚ")
	else: ccme3blRKJUW8tVgYCv = bbw2eajMlG(u"ࠬࡻࡰࡥࡣࡷࡩࡤࡸࡵ࡭ࡧࡶࠫᶛ")
	BVYESNuJMxlmDo5WXdaFP6r.execute(KKbpxUZnMcj6AJ4QdD(u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࠪࠡࡈࡕࡓࡒࠦࠧᶜ")+ccme3blRKJUW8tVgYCv+oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࡙ࠧࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬᶝ")+lY0rst72uGVZ1NkgvpjfA6x+Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠨࠤࠣ࠿ࠬᶞ"))
	CVRQsZFOWHvK7SpkroU15eyAn = BVYESNuJMxlmDo5WXdaFP6r.fetchall()
	if CVRQsZFOWHvK7SpkroU15eyAn and kkvFsou9D5G8RZw1fmH3ynrNT in [usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩࠪᶟ"),OyJ1o4AvmWlB75UkFRX(u"ࠪࡩࡳࡧࡢ࡭ࡧࠪᶠ")]:
		iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠫࠬᶡ"),ggDRehOModi(u"ࠬ࠭ᶢ"),wwplD0tEehqH3kYQXs(u"࠭ࠧᶣ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᶤ"),ggDRehOModi(u"ࠨษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆศฺฬ็ษࠡ࡞ࡱࠤࠬᶥ")+lY0rst72uGVZ1NkgvpjfA6x+XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠩࠣࡠࡳࡢ࡮ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤ๊ะ่ใใࠣ์้อ๋ࠠ฻่่ࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢอๅ฾๐ไ่ࠢส่ว์ࠠภࠣࠤࠤࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࡜࡯࡞ࡱࠤฯูสุ์฼ࠤส๐โศใ๊ࠤอู็้ๆฬࠤ฾์ฯࠡษ็฽ํีษࠡว็ํࠥํะ่ࠢสู่อิสࠢส่๊๎ฬ้ัฬࠤๆ๐ࠠใษษ้ฮࠦฮะ็สฮࠥฮั็ษ่ะࠥ฿ๅศัࠪᶦ"))
		if iZL6cN3OkM5!=pcWq35MED2dtK(u"࠴਌"): return
		BVYESNuJMxlmDo5WXdaFP6r.execute(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠩᶧ")+ccme3blRKJUW8tVgYCv+n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠫࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩᶨ")+lY0rst72uGVZ1NkgvpjfA6x+M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠬࠨࠠ࠼ࠩᶩ"))
	elif kkvFsou9D5G8RZw1fmH3ynrNT in [tZ3gsrTEdzA1S6LXa9WI5px(u"࠭ࠧᶪ"),nKLEi8CJumazx4qT(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࠨᶫ")]:
		iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠨࠩᶬ"),vvBChXmSty(u"ࠩࠪᶭ"),ggDRehOModi(u"ࠪࠫᶮ"),cNaVb1vsT4qWOL0rpE(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᶯ"),shZ9eOcN2dJnPj(u"ࠬอไหฯา๎ะࠦวๅล๋ฮํ๋วห์ๆ๎๊ࠥลืษไอࠥࡢ࡮ࠡࠩᶰ")+lY0rst72uGVZ1NkgvpjfA6x+CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠭ࠠ࡝ࡰ࡟ࡲࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ็ไ฽้่๋ࠦ฻่่ࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢศ๎็อแ่ࠢส่ว์ࠠภࠣࠤࠤࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࡜࡯࡞ࡱࠤฯูสุ์฼ࠤฯ็ู๋ๆ๊ࠤอู็้ๆฬࠤ฾์ฯࠡษ็฽ํีษࠡว็ํࠥํะ่ࠢสู่อิสࠢส่๊๎ฬ้ัฬࠤๆ๐ࠠใษษ้ฮࠦฮะ็สฮࠥฮั็ษ่ะࠥ฿ๅศัࠪᶱ"))
		if iZL6cN3OkM5!=cgtRBdXxSOk7WUfyDhPCls(u"࠵਍"): return
		if bdptXFc8UlIhA5jnGwPmKuv2L: BVYESNuJMxlmDo5WXdaFP6r.execute(bcgZJWV6UeNSkRA(u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥࡨ࡬ࡢࡥ࡮ࡰ࡮ࡹࡴࠡࠪࡤࡨࡩࡵ࡮ࡊࡆࠬࠤ࡛ࡇࡌࡖࡇࡖࠤ࠭ࠨࠧᶲ")+lY0rst72uGVZ1NkgvpjfA6x+iifPEY9ABNzTQp(u"ࠨࠤࠬࠤࡀ࠭ᶳ"))
		else: BVYESNuJMxlmDo5WXdaFP6r.execute(KKbpxUZnMcj6AJ4QdD(u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࡶࡲࡧࡥࡹ࡫࡟ࡳࡷ࡯ࡩࡸࠦࠨࡢࡦࡧࡳࡳࡏࡄ࠭ࡷࡳࡨࡦࡺࡥࡓࡷ࡯ࡩ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩᶴ")+lY0rst72uGVZ1NkgvpjfA6x+iifPEY9ABNzTQp(u"ࠪࠦ࠱࠷ࠩࠡ࠽ࠪᶵ"))
	AO76Z1XEaSDjomRwK.commit()
	AO76Z1XEaSDjomRwK.close()
	YVJPFvuI2CS5KObiZt.sleep(qnPgZ9N15G6Oa8UpMASvLk(u"࠶਎"))
	bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(xuztI5QWEKG70CPNdhk4vo6(u"࡚ࠫࡶࡤࡢࡶࡨࡐࡴࡩࡡ࡭ࡃࡧࡨࡴࡴࡳࠨᶶ"))
	YVJPFvuI2CS5KObiZt.sleep(BGhdkWsEvJjiMFTr3NLn1flU(u"࠷ਏ"))
	if showDialogs: xl9MFt1AmY0GrkENug8n(cgtRBdXxSOk7WUfyDhPCls(u"ࠬ࠭ᶷ"),yF29Xdsx35wI07Ce4(u"࠭ࠧᶸ"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᶹ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠨฬ่ฮࠥอไฺ็็๎ฮࠦศ็ฮสัࠬᶺ"))
	if kkvFsou9D5G8RZw1fmH3ynrNT in [pcWq35MED2dtK(u"ࠩࠪᶻ"),cgtRBdXxSOk7WUfyDhPCls(u"ࠪࡩࡳࡧࡢ࡭ࡧࠪᶼ")]: qzko6eUs95i3TuQ8vIWwa(showDialogs)
	return
def DB9YQjko7WUzSLp3ObuECPsamN4X():
	ZqlR5BFQ6pm0asCHLUc(bpNSygerL10j4IOkEfuVw,yF29Xdsx35wI07Ce4(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧᶽ"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨᶾ"))
	ebSw1pNJXjWAHQFlUKY = J4W2ubDzKxd7hUsQTZOl1Gn(yF29Xdsx35wI07Ce4(u"ࡊࡦࡲࡳࡦ઒"))
	jTzfcLU4KGmNP = tZ3gsrTEdzA1S6LXa9WI5px(u"࠭࡜࡯ࠩᶿ")
	tOvA5Xx12H8S = cNaVb1vsT4qWOL0rpE(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠣ࠱࠲࠳࠭࠮ࠢ࠰࠱࠲࠳࠭ࠡ࠯࠰࠱࠲࠳ࠠ࠮࠯࠰࠱࠲ࠦ࠭࠮࠯࠰࠱ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ᷀")
	NEK8xJnI3M4OaZp2UuRHh = n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࡡࡴࠧ᷁")
	for id,hGdKt2jR8SN1z5TrZkuU,FR2iK8BzPhInGx,Oi8pLbT4W12ortZkhIaMRym3YlXcdq,wB1aszFGrQMiZXNPqSbpoL79hE,reason in reversed(ebSw1pNJXjWAHQFlUKY):
		if id==PtXn0k9G3ocHRg(u"ࠩ࠳᷂ࠫ"):
			exspAP9JOoRbmKcn,LzZprQVsSl8u6Wo5d4MPnF = Oi8pLbT4W12ortZkhIaMRym3YlXcdq.split(pcWq35MED2dtK(u"ࠪࡠࡳࡁ࠻ࠨ᷃"))
			continue
		if jTzfcLU4KGmNP!=ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠫࡡࡴࠧ᷄"): jTzfcLU4KGmNP += NEK8xJnI3M4OaZp2UuRHh
		cLzOaV56rHkXKmxCy = drHLAY5ENQFe2q9ptKGabo(u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭᷅")+id+M6PIj8gl1fno7wcqTksDEBK4bU(u"࠭ࠠ࠻ࠢࠪ᷆")+yF29Xdsx35wI07Ce4(u"ࠧศๆึศฬ๊ࠠ࠻ࠢࠪ᷇")+xuztI5QWEKG70CPNdhk4vo6(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ᷈")+FR2iK8BzPhInGx
		Yw6S1bOqLcECfji7RJetgD = qnPgZ9N15G6Oa8UpMASvLk(u"ࠩ࡟ࡲࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ฬ้ษหࠤ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ᷉")+Oi8pLbT4W12ortZkhIaMRym3YlXcdq
		H48QNMCzRXUI1eioTPunZFEdYsG = nKLEi8CJumazx4qT(u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้ิืฤࠢ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ᷊࠭")+wB1aszFGrQMiZXNPqSbpoL79hE
		HDP1ZJ2jWoQnTcAi = PtXn0k9G3ocHRg(u"ࠫࡡࡴ࡛ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅีหฬࠥࡀࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ᷋")+reason
		jTzfcLU4KGmNP += cLzOaV56rHkXKmxCy+Yw6S1bOqLcECfji7RJetgD+iifPEY9ABNzTQp(u"ࠬࡢ࡮ࠨ᷌")+tOvA5Xx12H8S+usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠭࡜࡯ࠩ᷍")+H48QNMCzRXUI1eioTPunZFEdYsG+HDP1ZJ2jWoQnTcAi+PtXn0k9G3ocHRg(u"ࠧ࡝ࡰ᷎ࠪ")
	RZo7IGjqXfiAnrWtlHcbNDuF9hP(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠨࡴ࡬࡫࡭ࡺ᷏ࠧ"),LzZprQVsSl8u6Wo5d4MPnF,jTzfcLU4KGmNP,JLoPRXt93dpAB(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩ᷐ࠪ"))
	return
def xpQtEDjh0vry4mfF3oYkC5(file):
	if file==MZabdxfVE5WJwUu: mRHDNO2JBUAg = yruHDQOcB97ig(u"ࠪๆํอฦๆࠢส่๊็ึๅหࠪ᷑")
	elif file==s1KMjlEIH9vd: mRHDNO2JBUAg = pcWq35MED2dtK(u"ࠫ็๎วว็ࠣฦำืࠠศๆไ๎ิ๐่่ษอࠫ᷒")
	aZ06RtK7TfOop52BJg4 = lRwnVNxCZXGgkqd390(nKLEi8CJumazx4qT(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᷓ"),bbw2eajMlG(u"࠭ๅิฯࠪᷔ"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠧฦื็หา࠭ᷕ"),JLoPRXt93dpAB(u"ࠨะิ์ั࠭ᷖ"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᷗ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"๋้ࠪࠦสา์าࠤส฻ไศฯ้้ࠣ็ࠠࠨᷘ")+mRHDNO2JBUAg+Tgoa16jMxvYX2(u"ࠫࠥษๅࠡฬิ๎ิࠦๅิฯࠣห้๋ไโࠢยࠫᷙ"))
	if aZ06RtK7TfOop52BJg4==ggDRehOModi(u"࠰ਐ"):
		if k1t0JLRsCQ.path.exists(file):
			try: k1t0JLRsCQ.remove(file)
			except: pass
		xl9MFt1AmY0GrkENug8n(XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠬ࠭ᷚ"),vvBChXmSty(u"࠭ࠧᷛ"),cNaVb1vsT4qWOL0rpE(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᷜ"),xuztI5QWEKG70CPNdhk4vo6(u"ࠨฬ่ࠤู๊อࠡ็็ๅࠥ࠭ᷝ")+mRHDNO2JBUAg)
	elif aZ06RtK7TfOop52BJg4==cgtRBdXxSOk7WUfyDhPCls(u"࠲਑"):
		data = kI2poxnvzLZ0Yg8e1scBKy(file)
		xl9MFt1AmY0GrkENug8n(KKbpxUZnMcj6AJ4QdD(u"ࠩࠪᷞ"),bcgZJWV6UeNSkRA(u"ࠪࠫᷟ"),drHLAY5ENQFe2q9ptKGabo(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᷠ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠬะๅࠡวุ่ฬำࠠๆๆไࠤࠬᷡ")+mRHDNO2JBUAg)
	return
def DnFVaiKU70YXB6():
	if njGgmsD1k7cE60drxHCyVh2YN3P<yF29Xdsx35wI07Ce4(u"࠳࠻਒"):
		MLPwxur5kaYlBtqcn = nKLEi8CJumazx4qT(u"࠭ไๅลึๅࠥษๆหࠢอืฯิฯๆࠢศูิอัࠡๅ๋ำ๏ࠦโะ์่ࠤึ่ๅࠡࠩᷢ")+str(njGgmsD1k7cE60drxHCyVh2YN3P)+oUlIcGH2JuWFLvimMXyBQdzK06ge(u"๊ࠧࠡ็๋ีอࠠศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢ็หࠥะูๆๆࠣ฽๋ีใࠡ࠰๋ࠣีํࠠศๆ่๎ืฯࠠห็ๆ๊่ࠦๅ็ࠢิศ๏ฯࠠใ๊สส๊ࠦวๅใํำ๏๎็ศฬࠣๅ๏ࠦศา่ส้ัูࠦๆษาࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠡ࠰่ࠣส฻ไศฯࠣห้๋ิไๆฬࠤ็๋ࠠษฬะำ๏ัࠠษำ้ห๊าࠠไ๊า๎ࠥหไ๊ࠢศ๎ࠥหีะษิࠤึ่ๅ่ࠢฦ฽้๏ࠠๆ่ࠣ࠵࠽࠴࠰ࠨᷣ")
		xl9MFt1AmY0GrkENug8n(InKG0i2r6hHDvgd(u"ࠨࠩᷤ"),bcgZJWV6UeNSkRA(u"ࠩࠪᷥ"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᷦ"),MLPwxur5kaYlBtqcn)
		return
	sWXx2MJmLGl = bMIascyFJ2x43E0C7glTB91h8qz.executeJSONRPC(drHLAY5ENQFe2q9ptKGabo(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧᷧ"))
	u9q1RZQYpdDUA = FWagyi9bX8LRexDPmArjVZfdNK([CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫᷨ")])
	ic2VMr7wJYbK3x6RSlOW,gGN0QMojIz9BPylV8LwmqXe2fhK,sXD3icxn75CWUufNPzqpKHYVhaS,d2DpfSRUIiLMtja0WmqY,Op0DhErcql,fM4jDQixmqeywNl3aAOoHRzE5VYkBc,Mih6Nf1yzqbKxrtnvwu = u9q1RZQYpdDUA[drHLAY5ENQFe2q9ptKGabo(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬᷩ")]
	if ic2VMr7wJYbK3x6RSlOW or JLoPRXt93dpAB(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ᷪ") not in str(sWXx2MJmLGl):
		xl9MFt1AmY0GrkENug8n(drHLAY5ENQFe2q9ptKGabo(u"ࠨࠩᷫ"),yF29Xdsx35wI07Ce4(u"ࠩࠪᷬ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᷭ"),bbw2eajMlG(u"ࠫฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦสฺ็็ࠤๆ่ืࠡ็฼ࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠰๋ࠣีํࠠศๆๅ์ฬฬๅࠡฬ่็๋้ࠠๆ่ࠣีษ๐ษࠡไ๋หห๋ࠠษำ้ห๊าฺࠠ็สำࠥฮิไๆูࠣํืࠠษั็ห๋ࠥๆࠡษ็็ฯอศสࠩᷮ"))
		V5VXz0j3oa6t = HJaziOsSXQok4uZtRKg2ITfr3bUFEn(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫᷯ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࡙ࡸࡵࡦઓ"))
		if not V5VXz0j3oa6t: return
	GUYNM7h6W4QOlH208ZyiTnRJP3rBm(yruHDQOcB97ig(u"࡚ࡲࡶࡧઔ"))
	return
def GUYNM7h6W4QOlH208ZyiTnRJP3rBm(showDialogs=M6PIj8gl1fno7wcqTksDEBK4bU(u"ࡔࡳࡷࡨક")):
	sWXx2MJmLGl = bMIascyFJ2x43E0C7glTB91h8qz.executeJSONRPC(usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾࠩᷰ"))
	if ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ᷱ") not in str(sWXx2MJmLGl):
		if showDialogs:
			xl9MFt1AmY0GrkENug8n(JLoPRXt93dpAB(u"ࠨࠩᷲ"),PtXn0k9G3ocHRg(u"ࠩࠪᷳ"),KKbpxUZnMcj6AJ4QdD(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᷴ"),tZ3gsrTEdzA1S6LXa9WI5px(u"้๊ࠫริใࠣะ์อาไࠢ็หࠥ๐ำหะา้ࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦสฺ็็ࠤๆ่ืࠡ็฼ࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠰๋ࠣีํࠠศๆๅ์ฬฬๅࠡฬ่็๋้ࠠๆ่ࠣีษ๐ษࠡไ๋หห๋ࠠษำ้ห๊าฺࠠ็สำࠥฮิไๆูࠣํืࠠษั็ห๋ࠥๆࠡษ็็ฯอศสࠩ᷵"))
		return
	QNoUWz4wTkYlEhdPbM68VIS5sKCc = k1t0JLRsCQ.path.join(r4roga1DYEwG,Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠬࡧࡤࡥࡱࡱࡷࠬ᷶"),ggDRehOModi(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈ᷷ࠬ"),InKG0i2r6hHDvgd(u"ࠧ࠸࠴࠳ࡴ᷸ࠬ"),Tgoa16jMxvYX2(u"ࠨࡏࡼ࡚࡮ࡪࡥࡰࡐࡤࡺ࠳ࡾ࡭࡭᷹ࠩ"))
	if not k1t0JLRsCQ.path.exists(QNoUWz4wTkYlEhdPbM68VIS5sKCc): return
	QQM3clG5VWTxqhBUSJYoOf6avpPwy = open(QNoUWz4wTkYlEhdPbM68VIS5sKCc,qnPgZ9N15G6Oa8UpMASvLk(u"ࠩࡵࡦ᷺ࠬ")).read()
	if VVGRN7xiyj: QQM3clG5VWTxqhBUSJYoOf6avpPwy = QQM3clG5VWTxqhBUSJYoOf6avpPwy.decode(oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠪࡹࡹ࡬࠸ࠨ᷻"))
	jDaboP43RE1nxXruY = u5h2Rckvw1E.findall(drHLAY5ENQFe2q9ptKGabo(u"ࠫࡁࡼࡩࡦࡹࡶࡂ࠭ࡢࡤࠬ࠮࡟ࡨ࠰࠲࡜ࡥ࠭ࠬ࠰࠭࠴ࠪࡀࠫ࠿࠳ࡻ࡯ࡥࡸࡵࡁࠫ᷼"),QQM3clG5VWTxqhBUSJYoOf6avpPwy,u5h2Rckvw1E.DOTALL)
	GKMTkesgUy2c8wv4Q,LLw6QxZUJVz7v2pT9rbnhH = jDaboP43RE1nxXruY[JLoPRXt93dpAB(u"࠳ਓ")]
	djx2NaLnMYOlChXGE9Iqk = yruHDQOcB97ig(u"ࠬࡂࡶࡪࡧࡺࡷࡃ᷽࠭")+GKMTkesgUy2c8wv4Q+KKbpxUZnMcj6AJ4QdD(u"࠭ࠬࠨ᷾")+LLw6QxZUJVz7v2pT9rbnhH+vvBChXmSty(u"ࠧ࠽࠱ࡹ࡭ࡪࡽࡳ࠿᷿ࠩ")
	if showDialogs:
		Si0oWczOPtUCY8HVnslTu7gLGaw6jN = bMIascyFJ2x43E0C7glTB91h8qz.getInfoLabel(yruHDQOcB97ig(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡛࡯ࡥࡸ࡯ࡲࡨࡪ࠭Ḁ"))
		if Si0oWczOPtUCY8HVnslTu7gLGaw6jN==ggDRehOModi(u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬḁ"): yyTVN1vPAmSjgKLsur8i5Fz = tZ3gsrTEdzA1S6LXa9WI5px(u"ࠪๆํอฦๆࠢส่่ะวษหࠪḂ")
		elif Si0oWczOPtUCY8HVnslTu7gLGaw6jN==cNaVb1vsT4qWOL0rpE(u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪḃ"): yyTVN1vPAmSjgKLsur8i5Fz = shZ9eOcN2dJnPj(u"่่ࠬศศ่ࠤฬ๊ี้ำࠪḄ")
		else: yyTVN1vPAmSjgKLsur8i5Fz = Tgoa16jMxvYX2(u"࠭โ้ษษ้ࠥษฮา๋ࠪḅ")
		aZ06RtK7TfOop52BJg4 = lRwnVNxCZXGgkqd390(bbw2eajMlG(u"ࠧࡤࡧࡱࡸࡪࡸࠧḆ"),bcgZJWV6UeNSkRA(u"ࠨไ๋หห๋ࠠฤะิํࠬḇ"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࠩๅ์ฬฬๅࠡษ็็ฯอศสࠩḈ"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠪๆํอฦๆࠢสฺ่๎ัࠨḉ"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠫฬ์สࠡฯส่๏อࠠหีอาิ๋ࠠࠨḊ")+yyTVN1vPAmSjgKLsur8i5Fz,ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠬอๆหࠢส่ว์ࠠหีอาิ๋ࠠศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮๊๊ࠡิฬࠦๅฺ่ส๋ࠥอๆไࠢอืฯ฽ฺ๊ࠢสืฯิฯศ็ࠣห้่่ศศ่ࠤฬ๊ๅึ๊ิอࠥฮฯๅษ้๋ࠣࠦโ้ษษ้ࠥอไไฬสฬฮࠦ࠮๊ࠡฦ๎฻อࠠหีอ฻๏฿ࠠฦ์ๅหๆํวࠡใํࠤศ๐้ࠠไอࠤฯฺวยࠢ࡟ࡲࡡࡴࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠣวำะัࠡษ็ฦ๋ࠦๆ้฻ࠣห้่่ศศ่ࠤฬ๊ส๋ࠢอี๏ีࠠฤีอาิอๅ่ษࠣรࠦࡡ࠯ࡄࡑࡏࡓࡗࡣࠧḋ"))
		if aZ06RtK7TfOop52BJg4==n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠵ਔ"): enWO59lqudzB4kQix = shZ9eOcN2dJnPj(u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩḌ")
		elif aZ06RtK7TfOop52BJg4==M6PIj8gl1fno7wcqTksDEBK4bU(u"࠷ਕ"): enWO59lqudzB4kQix = drHLAY5ENQFe2q9ptKGabo(u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭ḍ")
		else: enWO59lqudzB4kQix = cNaVb1vsT4qWOL0rpE(u"ࠨࠩḎ")
	else:
		Si0oWczOPtUCY8HVnslTu7gLGaw6jN = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(cNaVb1vsT4qWOL0rpE(u"ࠩࡤࡺ࠳ࡳࡹࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡰࡳࡩ࡫ࠧḏ"))
		if   Si0oWczOPtUCY8HVnslTu7gLGaw6jN==qnPgZ9N15G6Oa8UpMASvLk(u"ࠪࠫḐ"): aZ06RtK7TfOop52BJg4 = shZ9eOcN2dJnPj(u"࠶ਖ")
		elif Si0oWczOPtUCY8HVnslTu7gLGaw6jN==OyJ1o4AvmWlB75UkFRX(u"ࠫࡊࡓࡁࡅࠢࡏ࡭ࡸࡺࠧḑ"): aZ06RtK7TfOop52BJg4 = wwplD0tEehqH3kYQXs(u"࠱ਗ")
		elif Si0oWczOPtUCY8HVnslTu7gLGaw6jN==drHLAY5ENQFe2q9ptKGabo(u"ࠬࡋࡍࡂࡆࠣࡋࡦࡲ࡬ࡦࡴࡼࠫḒ"): aZ06RtK7TfOop52BJg4 = cgtRBdXxSOk7WUfyDhPCls(u"࠳ਘ")
		enWO59lqudzB4kQix = Si0oWczOPtUCY8HVnslTu7gLGaw6jN
	if   aZ06RtK7TfOop52BJg4==nKLEi8CJumazx4qT(u"࠲ਙ"): hU9ufHIyECzqbrWA3RVgj5xolNnF = vvBChXmSty(u"࠭࠵࠶࠮࠸࠸࠹࠲࠵࠶࠷ࠪḓ")
	elif aZ06RtK7TfOop52BJg4==qnPgZ9N15G6Oa8UpMASvLk(u"࠴ਚ"): hU9ufHIyECzqbrWA3RVgj5xolNnF = wwplD0tEehqH3kYQXs(u"ࠧ࠶࠶࠷࠰࠺࠻࠵࠭࠷࠸ࠫḔ")
	elif aZ06RtK7TfOop52BJg4==cNaVb1vsT4qWOL0rpE(u"࠶ਛ"): hU9ufHIyECzqbrWA3RVgj5xolNnF = BGhdkWsEvJjiMFTr3NLn1flU(u"ࠨ࠷࠸࠹࠱࠻࠵࠭࠷࠷࠸ࠬḕ")
	else: return
	LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠩࡤࡺ࠳ࡳࡹࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡰࡳࡩ࡫ࠧḖ"),enWO59lqudzB4kQix)
	sX92gq6F7DGzdNhkpLBE3 = oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠪࡀࡻ࡯ࡥࡸࡵࡁࠫḗ")+hU9ufHIyECzqbrWA3RVgj5xolNnF+M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠫ࠱࠭Ḙ")+LLw6QxZUJVz7v2pT9rbnhH+JLoPRXt93dpAB(u"ࠬࡂ࠯ࡷ࡫ࡨࡻࡸࡄࠧḙ")
	zzSfX1AF0D = QQM3clG5VWTxqhBUSJYoOf6avpPwy.replace(djx2NaLnMYOlChXGE9Iqk,sX92gq6F7DGzdNhkpLBE3)
	if VVGRN7xiyj: zzSfX1AF0D = zzSfX1AF0D.encode(PtXn0k9G3ocHRg(u"࠭ࡵࡵࡨ࠻ࠫḚ"))
	open(QNoUWz4wTkYlEhdPbM68VIS5sKCc,bcgZJWV6UeNSkRA(u"ࠧࡸࡤࠪḛ")).write(zzSfX1AF0D)
	l0SAerv8zGH2Wa(bcgZJWV6UeNSkRA(u"ࠨࡐࡒࡘࡎࡉࡅࠨḜ"),vvBChXmSty(u"ࠩ࠱ࠤ࡙ࠥ࡫ࡪࡰࠣࡈࡪ࡬ࡡࡶ࡮ࡷࠤ࡛࡯ࡥࡸࡵ࠽ࠤࡠࠦࠧḝ")+hU9ufHIyECzqbrWA3RVgj5xolNnF+KKbpxUZnMcj6AJ4QdD(u"ࠪࠤࡢ࠭Ḟ"))
	if showDialogs: bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(PtXn0k9G3ocHRg(u"ࠫࡗ࡫࡬ࡰࡣࡧࡗࡰ࡯࡮ࠩࠫࠪḟ"))
	return
def cTvunr2DqXdoCe46a9Lgkp7HtZz0():
	iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(xuztI5QWEKG70CPNdhk4vo6(u"ࠬ࠭Ḡ"),vvBChXmSty(u"࠭ࠧḡ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧࠨḢ"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫḣ"),ggDRehOModi(u"ࠩหี๋อๅอࠢ฼้ฬีࠠโ์๊ࠤฺ๊ใๅหࠣ฽๋ีใࠡ࠰࠱࠲ࠥหๅศࠢฦ่ส฻ฯศำࠣๆิ๐ๅࠡ࠰࠱࠲ࠥษ่ࠡษ้ฮ๋ࠥๅ็๊฼ࠤ๊์ࠠศีอาิอๅࠡษ็ฬึ์วๆฮࠣ࠲࠳࠴ࠠฤ๊่ࠣิ๐ใࠡ็ื็้ฯࠠฤะิํࠥะฮึࠢฯ๋ฬุใࠡล้ฮࠥ๎ไศࠢอาฺࠦศใ์ฬࠤำ๊โࠡษ็่์ࠦ࡜࡯࡞ࡱࠤาอ่ๅࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣวํࠦวหื็ࠤออไๆสิ้ัࠦไๆ฻ิๅฮࠦำษสࠣห้๋ิไๆฬࠤ฾์ฯไࠢ࠱࠲࠳ࠦ็ๅࠢอี๏ีࠠโฯุࠤฬ๊สฮัํฯฬะࠠศๆล๊ࠥลࠧḤ"))
	if iZL6cN3OkM5==drHLAY5ENQFe2q9ptKGabo(u"࠶ਜ"): NZ0pBCdgQs(iifPEY9ABNzTQp(u"ࡕࡴࡸࡩખ"),iifPEY9ABNzTQp(u"ࡕࡴࡸࡩખ"))
	return
def qhZNrGWaxzEFetmfivAj3n():
	xl9MFt1AmY0GrkENug8n(yruHDQOcB97ig(u"ࠪࠫḥ"),Tgoa16jMxvYX2(u"ࠫࠬḦ"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨḧ"),xuztI5QWEKG70CPNdhk4vo6(u"࠭็ัษࠣห้๋่ใ฻้ࠣ฿๊โࠡ็้ࠤฬ๊ๅึัิࠤํเ๊า่ࠢ฽ึ๎แࠡ็อ๎ࠥ๐ัอ฻่้ࠣ฿ๅๅࠩḨ"))
	return
def EnP0WCjMqFOUyfR5():
	cLzOaV56rHkXKmxCy = pcWq35MED2dtK(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟อ฽ิอฯࠡึํ฽ฮࠦยๅ่ࠢั๊ีࠠๅี้อࠥ࠸࠰࠳࠳ࠣ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧḩ")
	cLzOaV56rHkXKmxCy += drHLAY5ENQFe2q9ptKGabo(u"ࠨษ็้ํู่ࠡลา๊ฬํࠠโ์๊ࠤสำีศศํอู๊ࠥะัࠣหฺฺ้๊หࠣๅ๏ࠦวๅ฻ส่๊ࠦสๆࠢฯ้฾ํวࠡ็้ࠤัฺ๋๊ࠢส่๊฻วะำࠣห้๋ส้ใิอࠥ็๊ࠡษ็ษ๋ะั็ฬࠣห้่ฯ๋็ฬࠤํอไอัํำฮࠦวๅฯๆ์๊๐ษ๊ࠡส่฿๐ัࠡฯๆ์๊๐ษ๊่๊ࠡࠥาๅ๋฻ࠣำํ๊ࠠศๆ฼ห้๋ࠠฬ็ࠣฮ๊ࠦส้ฯํำ์อ้ࠠฯึหอࠦวๅ็฼ำ้ࠦอิสࠣื่อๆࠡั๋่ࠥอไฺษ็้๊ࠥำ็หࠣ࠶࠵࠸࠱๊๊ࠡ๎ࠥอไฦฯุหห๐ษࠡษ็วาีห๊ࠡส่ศฺๅๅࠢส่ฯ๐ࠠห็ࠣ฽๊๊็ศࠢไ๎ࠥอไิ่๋หฯࠦวๅ฻ืีฮࠦวๅ็สฺ๏ฯࠧḪ")
	cLzOaV56rHkXKmxCy += qnPgZ9N15G6Oa8UpMASvLk(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࡨࡵࡶࡳࡷ࠿࠵࠯ࡵ࡫ࡱࡽ࠳ࡩࡣ࠰ࡵ࡫࡭ࡦࡩ࡯ࡶࡰࡷ࡟࠴ࡉࡏࡍࡑࡕࡡࠬḫ")
	Yw6S1bOqLcECfji7RJetgD = drHLAY5ENQFe2q9ptKGabo(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢฮั็ษ่ะฺࠥัู๋ࠣห้๋ำๅ็ࠣ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧḬ")
	Yw6S1bOqLcECfji7RJetgD += nKLEi8CJumazx4qT(u"ࠫ์๎ฺࠠสสีฮูࠦ็ࠢหี๋อๅอࠢํ์ๆืࠠๆ฻็์๊อสࠡฯึหอ๐ษࠡๅฮ๎ึฯࠠห้่ࠤัฺ๋๊ࠢสู่๊ไๆ์้ࠤ๊ัไࠡล๋ๆฬะࠠศๆุ่ฬฯ้ࠠล๋ๆฬะࠠศๆๆืํ็้ࠠษ็าุ๎แ๊ࠡื็้ࠦวๅไ่ีࠥ๎ร้ไสฮࠥอไใ็ิࠤํษ๊ืษࠣ๎ํ็ัࠡำว๎ฮࠦวๅ้็ห้ࠦแ๋ࠢฯ้๏฿ࠠะ๊็ࠤฬู๊ศๆ่ࠤํษ๊ืษࠣๅ๏ํࠠหไ๋๎๊ࠦๅ๋ๆสำ๏่่ࠦฮิ๎ࠥ๎แ๋้ࠣว๏฼วࠡสะฯࠥ๎โาษฤอࠥอไใำล๊ࠥ๎รุ๋สࠤๆ๐็ࠡษึฮำอัส๋ࠢฮๆอฤๅ๋ࠢๅ๏ํࠠฤไ๋ห้ࠦๅ็ี๋ฬฮࠦไๅล่หู๊ࠦๅ์ࠣ์ศ๋่าࠢฦาึ๏ࠠห้่ࠤ่๊ࠠๆี็้ࠥ࠴ࠠศๆหี๋อๅอ่ࠢ็ฯ๎ศࠡส็฾ฮࠦฬศใสࠤุ้ัษฬࠣ์๏ูสฯั่ࠤ๋฾วๆ๋ࠢ๎๋ี่ำࠢอัฯࠦศ๋ศฬࠤํ๐ๆะ๊ีࠤ่อฬ๋ฬࠣ์๊ิีึࠢไๆ฼ࠦไฤฮ๊ึฮࠦวๅ๊ํ๊ิ๎าࠡ࠰ࠣห้๋่ใ฻ࠣห้ืำๆ์่้ࠣฮั็ษ่ะࠥํ่ࠨḭ")
	Yw6S1bOqLcECfji7RJetgD += oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡲࡻࡳ࡭࡫ࡰࡶࡺࡲࡥࡳ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪḮ")
	MLPwxur5kaYlBtqcn = xuztI5QWEKG70CPNdhk4vo6(u"࡛࠭ࡓࡖࡏࡡࠬḯ")+cLzOaV56rHkXKmxCy+n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠧ࡝ࡰ࡟ࡲࡡࡴ࡛ࡓࡖࡏࡡࠬḰ")+Yw6S1bOqLcECfji7RJetgD
	RZo7IGjqXfiAnrWtlHcbNDuF9hP(InKG0i2r6hHDvgd(u"ࠨࡴ࡬࡫࡭ࡺࠧḱ"),yruHDQOcB97ig(u"ࠩࠪḲ"),MLPwxur5kaYlBtqcn)
	return
def bDowgWRO58xMB4G3Su7Ac9VICqmKnf(EqVPHSM8fKuTaxh20WkNLd):
	b0jYpTOlAEoGF(EqVPHSM8fKuTaxh20WkNLd,bcgZJWV6UeNSkRA(u"ࡈࡤࡰࡸ࡫ગ"))
	ebSw1pNJXjWAHQFlUKY = J4W2ubDzKxd7hUsQTZOl1Gn(EqVPHSM8fKuTaxh20WkNLd)
	id,hGdKt2jR8SN1z5TrZkuU,FR2iK8BzPhInGx,Oi8pLbT4W12ortZkhIaMRym3YlXcdq,wB1aszFGrQMiZXNPqSbpoL79hE,reason = ebSw1pNJXjWAHQFlUKY[CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠶ਝ")]
	exspAP9JOoRbmKcn,LzZprQVsSl8u6Wo5d4MPnF = Oi8pLbT4W12ortZkhIaMRym3YlXcdq.split(pcWq35MED2dtK(u"ࠪࡠࡳࡁ࠻ࠨḳ"))
	Yw6S1bOqLcECfji7RJetgD,H48QNMCzRXUI1eioTPunZFEdYsG,HDP1ZJ2jWoQnTcAi = wB1aszFGrQMiZXNPqSbpoL79hE.split(wwplD0tEehqH3kYQXs(u"ࠫࡡࡴ࠻࠼ࠩḴ"))
	KMCqvkt8LP95hzAnHbTXDuVclmWFx = xuztI5QWEKG70CPNdhk4vo6(u"ࡗࡶࡺ࡫ઘ")
	while KMCqvkt8LP95hzAnHbTXDuVclmWFx:
		tJ2VsZOaM7PyEXu6lUHC0qRedBLK = lRwnVNxCZXGgkqd390(nKLEi8CJumazx4qT(u"ࠬ࠭ḵ"),bbw2eajMlG(u"࠭ฮา๊ฯࠫḶ"),yruHDQOcB97ig(u"ࠧฦำึห้ࠦัิษ็อ๊ࠥไๆสิ้ั࠭ḷ"),Tgoa16jMxvYX2(u"ࠨไสส๊ฯࠠศๆอฬึ฿วหࠩḸ"),cgtRBdXxSOk7WUfyDhPCls(u"ࠩ็ษ๏่วโࠢส่ส฿ไศ่สฮࠥࡀࠠࠡฬหี฾ࠦร้ࠢสุ้ำࠠศๆหี๋อๅอࠩḹ"),Yw6S1bOqLcECfji7RJetgD)
		if tJ2VsZOaM7PyEXu6lUHC0qRedBLK==cNaVb1vsT4qWOL0rpE(u"࠲ਞ"): gGAR0O5Xi1LT38NkIrBYmuU = lRwnVNxCZXGgkqd390(pcWq35MED2dtK(u"ࠪࠫḺ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠫࠬḻ"),pcWq35MED2dtK(u"ࠬ฿่ะหࠪḼ"),BGhdkWsEvJjiMFTr3NLn1flU(u"࠭ࠧḽ"),KKbpxUZnMcj6AJ4QdD(u"ࠧๆสาวࠥอไหสิ฽ࠥเ๊าࠢๅหอ๊ࠠๅๆ้ๆฬฺࠧḾ"),H48QNMCzRXUI1eioTPunZFEdYsG,cgtRBdXxSOk7WUfyDhPCls(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࠬḿ"))
		elif tJ2VsZOaM7PyEXu6lUHC0qRedBLK==bcgZJWV6UeNSkRA(u"࠲ਟ"): V23iQNjwDUgHl9SFO6h8kbeY()
		else: KMCqvkt8LP95hzAnHbTXDuVclmWFx = wwplD0tEehqH3kYQXs(u"ࡊࡦࡲࡳࡦઙ")
	bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(ggDRehOModi(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭Ṁ"))
	return
def NXS34upO9xUFQbJjahAWT2I6mVt(showDialogs):
	iZL6cN3OkM5 = bbw2eajMlG(u"࡙ࡸࡵࡦચ")
	if showDialogs: iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(ggDRehOModi(u"ࠪࡧࡪࡴࡴࡦࡴࠪṁ"),yF29Xdsx35wI07Ce4(u"ࠫࠬṂ"),ggDRehOModi(u"ࠬ࠭ṃ"),cNaVb1vsT4qWOL0rpE(u"࠭ำลษ็ࠫṄ"),bcgZJWV6UeNSkRA(u"่ࠧๆࠣว๋ะࠠๆฬฦ็ิ่ࠦหำํำ๋ࠥำฮ๋ࠢฮฺ็๊าࠢฯ้๏฿ࠠฦ฻าหิอสࠡสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠤ࠳ࠦอ๋อࠣฮ฾๎ฯࠡฮ่๎฾ࠦวๅว฼ำฬีวหࠢศ่๎่ࠦื฻ํอࠥะหษ์อࠤฬ๊ศา่ส้ัࠦฟࠨṅ"))
	if iZL6cN3OkM5:
		V5VXz0j3oa6t = bcgZJWV6UeNSkRA(u"࡚ࡲࡶࡧછ")
		if k1t0JLRsCQ.path.exists(bFWt9xADQYV7hU3neC):
			try: k1t0JLRsCQ.remove(bFWt9xADQYV7hU3neC)
			except: V5VXz0j3oa6t = yF29Xdsx35wI07Ce4(u"ࡆࡢ࡮ࡶࡩજ")
		if showDialogs:
			if V5VXz0j3oa6t: xl9MFt1AmY0GrkENug8n(Tgoa16jMxvYX2(u"ࠨࠩṆ"),InKG0i2r6hHDvgd(u"ࠩࠪṇ"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠪࠫṈ"),cgtRBdXxSOk7WUfyDhPCls(u"ࠫฯ๋ࠠษ่ฯหาࠦๅิฯࠣ์ฯ฻แ๋ำ้้ࠣ็ࠠฦ฻าหิอสࠡสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠫṉ"))
			else: xl9MFt1AmY0GrkENug8n(xuztI5QWEKG70CPNdhk4vo6(u"ࠬ࠭Ṋ"),xuztI5QWEKG70CPNdhk4vo6(u"࠭ࠧṋ"),KKbpxUZnMcj6AJ4QdD(u"ࠧࠨṌ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็็ๅࠥอไฦ฻าหิอสࠨṍ"))
	return
def pkg2O3XsHqGhLzY7vnVNUKP():
	ZHmiTvsIR3fCwjhQYdKqlPLaD6EWMx()
	uu1dgl8YS2Qi = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(vvBChXmSty(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨṎ"))
	MLPwxur5kaYlBtqcn = {}
	MLPwxur5kaYlBtqcn[wwplD0tEehqH3kYQXs(u"ࠪࡅ࡚࡚ࡏࠨṏ")] = M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠫฬ๊ใศึࠣห้ะไใษษ๎ࠥ๐ูๆๆࠪṐ")
	MLPwxur5kaYlBtqcn[usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࡙ࠬࡔࡐࡒࠪṑ")] = cgtRBdXxSOk7WUfyDhPCls(u"࠭วๅๅสุ๋ࠥส้ไไࠤฯ๋วๆษࠣ์ออไไษ่่ࠬṒ")
	MLPwxur5kaYlBtqcn[Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨṓ")] = ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠨๅสุࠥาฯศࠢๅู๏ืࠠศๆ่ำ๎ࠦ࠮ࠡࠩṔ")+str(IDbT7Aya2hB180SvVUXFYc/OyJ1o4AvmWlB75UkFRX(u"࠸࠳ਠ"))+ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠩࠣำ็๐โสࠢไๆ฼࠭ṕ")
	KKty7kOjZC8MguQ = MLPwxur5kaYlBtqcn[uu1dgl8YS2Qi]
	aZ06RtK7TfOop52BJg4 = lRwnVNxCZXGgkqd390(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠪࠫṖ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"่ࠫอิࠡࠩṗ")+str(IDbT7Aya2hB180SvVUXFYc/n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠹࠴ਡ"))+yruHDQOcB97ig(u"ࠬࠦฯใ์ๅอࠬṘ"),bbw2eajMlG(u"࠭สี฼ํ่ࠥะไใษษ๎ࠬṙ"),yF29Xdsx35wI07Ce4(u"ࠧฦ์ๅหๆࠦใศ็็ࠫṚ"),KKty7kOjZC8MguQ,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠨ้็ࠤฯื๊ะࠢสืฯิฯศ็ࠣห้้วีࠢส่ี้๊ࠡษ็ฮ้่วว์ࠣว๊ࠦสา์าࠤส๐โศใࠣห้้วีࠢหห้้วๆๆࠣว๊ࠦสา์าࠤ่อิࠡ฻่ี์ࠦโึ์ิࠤัีวࠡมࠤࠫṛ"))
	if aZ06RtK7TfOop52BJg4==cgtRBdXxSOk7WUfyDhPCls(u"࠴ਢ"): AmeYCpn4Tx = Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪṜ")
	elif aZ06RtK7TfOop52BJg4==M6PIj8gl1fno7wcqTksDEBK4bU(u"࠶ਣ"): AmeYCpn4Tx = M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠪࡅ࡚࡚ࡏࠨṝ")
	elif aZ06RtK7TfOop52BJg4==usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠸ਤ"): AmeYCpn4Tx = cNaVb1vsT4qWOL0rpE(u"ࠫࡘ࡚ࡏࡑࠩṞ")
	else: AmeYCpn4Tx = nKLEi8CJumazx4qT(u"ࠬ࠭ṟ")
	if AmeYCpn4Tx:
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(xuztI5QWEKG70CPNdhk4vo6(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬṠ"),AmeYCpn4Tx)
		yyt8PD4F3YaQRmjCSzi2wr9ZvlA7O = MLPwxur5kaYlBtqcn[AmeYCpn4Tx]
		xl9MFt1AmY0GrkENug8n(yruHDQOcB97ig(u"ࠧࠨṡ"),InKG0i2r6hHDvgd(u"ࠨࠩṢ"),Tgoa16jMxvYX2(u"ࠩࠪṣ"),yyt8PD4F3YaQRmjCSzi2wr9ZvlA7O)
	return
def RXYo7Vbwr8uM():
	MLPwxur5kaYlBtqcn = {}
	MLPwxur5kaYlBtqcn[wwplD0tEehqH3kYQXs(u"ࠪࡅ࡚࡚ࡏࠨṤ")] = yF29Xdsx35wI07Ce4(u"ุࠫ๐ัโำࠣࡈࡓ࡙ࠠศๆอ่็อฦ๋ࠢํ฽๊๊࠺ࠡࠩṥ")
	MLPwxur5kaYlBtqcn[drHLAY5ENQFe2q9ptKGabo(u"ࠬࡇࡓࡌࠩṦ")] = usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠭ำ๋ำไีࠥࡊࡎࡔࠢึ๎฾๋ไࠡส฼ำࠥอไิ็สั๊ࠥ็࠻ࠢࠪṧ")
	MLPwxur5kaYlBtqcn[r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠧࡔࡖࡒࡔࠬṨ")] = drHLAY5ENQFe2q9ptKGabo(u"ࠨีํีๆืࠠࡅࡐࡖࠤ๊ะ่ใใࠣฮ๊อๅศ๋ࠢฬฬ๊ใศ็็ࠫṩ")
	PMwc6NTnxF = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠩࡤࡺ࠳ࡪ࡮ࡴࠩṪ"))
	uu1dgl8YS2Qi = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ṫ"))
	KKty7kOjZC8MguQ = MLPwxur5kaYlBtqcn[uu1dgl8YS2Qi]+PMwc6NTnxF
	aZ06RtK7TfOop52BJg4 = lRwnVNxCZXGgkqd390(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠫࠬṬ"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠬะิ฻์็ࠤ฾์ฯࠡษ็้ํอแใหࠪṭ"),cgtRBdXxSOk7WUfyDhPCls(u"࠭สี฼ํ่ࠥะไใษษ๎ࠬṮ"),cNaVb1vsT4qWOL0rpE(u"ࠧฦ์ๅหๆࠦใศ็็ࠫṯ"),KKty7kOjZC8MguQ,M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠨีํีๆืࠠࡅࡐࡖࠤ์๎ࠠอ้สึࠥ็๊ࠡษ็ษ๋ะั็์อࠤ๏่่ๆࠢหฮา๎๊ๅࠢฦื๊อมࠡษ็้ํอโฺ๋ࠢหู้๊าใิหฯࠦลๅ๋ࠣวึ่วๆ๋ࠢ฽๋ีࠠษ฻ูࠤฬ๊ๆศีࠣ๎็๎ๅࠡสะะอ่ࠦๆ่฼ࠤํำึาࠢห฽฻ࠦวๅ็๋ห็฿ࠠ࠯ࠢ็ฮูเ๊ๅࠢึ๎ึ็ัࠡࡆࡑࡗ่ࠥๅࠡสสาฯ๐วาࠢสุ่๐ัโำࠣห้๋ๆศีหࠤศ๎ࠠใ็ࠣฬส๐โศใ๊ࠤออไไษ่่ࠬṰ"))
	if aZ06RtK7TfOop52BJg4==vvBChXmSty(u"࠰ਥ"): AmeYCpn4Tx = r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠩࡄࡗࡐ࠭ṱ")
	elif aZ06RtK7TfOop52BJg4==wwplD0tEehqH3kYQXs(u"࠲ਦ"): AmeYCpn4Tx = wwplD0tEehqH3kYQXs(u"ࠪࡅ࡚࡚ࡏࠨṲ")
	elif aZ06RtK7TfOop52BJg4==OyJ1o4AvmWlB75UkFRX(u"࠴ਧ"): AmeYCpn4Tx = CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠫࡘ࡚ࡏࡑࠩṳ")
	if aZ06RtK7TfOop52BJg4 in [drHLAY5ENQFe2q9ptKGabo(u"࠴਩"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠴ਨ")]:
		iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬṴ"),JLoPRXt93dpAB(u"࠭ำ๋ำไี࠿ࠦࠧṵ")+kH5Khue7Fic[InKG0i2r6hHDvgd(u"࠶ਪ")],tZ3gsrTEdzA1S6LXa9WI5px(u"ࠧิ์ิๅึࡀࠠࠨṶ")+kH5Khue7Fic[CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠶ਫ")],ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠨࠩṷ"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩฦาฯอัࠡีํีๆืࠠࡅࡐࡖࠤฬ๊ๅ็ษึฬ๊ࠥใࠨṸ"))
		if iZL6cN3OkM5==JLoPRXt93dpAB(u"࠱ਬ"): DhKsd97QlxBSRwGNPHt56yFzgr = kH5Khue7Fic[tZ3gsrTEdzA1S6LXa9WI5px(u"࠱ਭ")]
		else: DhKsd97QlxBSRwGNPHt56yFzgr = kH5Khue7Fic[shZ9eOcN2dJnPj(u"࠳ਮ")]
	elif aZ06RtK7TfOop52BJg4==BGhdkWsEvJjiMFTr3NLn1flU(u"࠵ਯ"): DhKsd97QlxBSRwGNPHt56yFzgr = usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠪࠫṹ")
	else: AmeYCpn4Tx = shZ9eOcN2dJnPj(u"ࠫࠬṺ")
	if AmeYCpn4Tx:
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨṻ"),AmeYCpn4Tx)
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(bcgZJWV6UeNSkRA(u"࠭ࡡࡷ࠰ࡧࡲࡸ࠭Ṽ"),DhKsd97QlxBSRwGNPHt56yFzgr)
		yyt8PD4F3YaQRmjCSzi2wr9ZvlA7O = MLPwxur5kaYlBtqcn[AmeYCpn4Tx]+DhKsd97QlxBSRwGNPHt56yFzgr
		xl9MFt1AmY0GrkENug8n(OyJ1o4AvmWlB75UkFRX(u"ࠧࠨṽ"),KKbpxUZnMcj6AJ4QdD(u"ࠨࠩṾ"),iifPEY9ABNzTQp(u"ࠩࠪṿ"),yyt8PD4F3YaQRmjCSzi2wr9ZvlA7O)
	return
def tEKiexC9OT28r():
	uu1dgl8YS2Qi = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(OyJ1o4AvmWlB75UkFRX(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨẀ"))
	MLPwxur5kaYlBtqcn = {}
	MLPwxur5kaYlBtqcn[PtXn0k9G3ocHRg(u"ࠫࡆ࡛ࡔࡐࠩẁ")] = pcWq35MED2dtK(u"ࠬอไษำ๋็ุ๐ࠠศๆอ่็อฦ๋ࠢฯห์ุࠠๅๆ฼้้࠭Ẃ")
	MLPwxur5kaYlBtqcn[yF29Xdsx35wI07Ce4(u"࠭ࡁࡔࡍࠪẃ")] = JLoPRXt93dpAB(u"ࠧศๆหีํ้ำ๋ࠢึ๎฾๋ไࠡส฼ำࠥอไิ็สั๊ࠥ็ࠨẄ")
	MLPwxur5kaYlBtqcn[drHLAY5ENQFe2q9ptKGabo(u"ࠨࡕࡗࡓࡕ࠭ẅ")] = M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠩส่อื่ไีํࠤ๊ะ่ใใࠣฮ๊อๅศ๋ࠢฬฬ๊ใศ็็ࠫẆ")
	KKty7kOjZC8MguQ = MLPwxur5kaYlBtqcn[uu1dgl8YS2Qi]
	aZ06RtK7TfOop52BJg4 = lRwnVNxCZXGgkqd390(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠪࠫẇ"),wwplD0tEehqH3kYQXs(u"ࠫฯฺฺ๋ๆࠣ฽๋ีࠠศๆ่์ฬ็โสࠩẈ"),JLoPRXt93dpAB(u"ࠬะิ฻์็ࠤฯ๊โศศํࠫẉ"),yruHDQOcB97ig(u"࠭ล๋ไสๅ้ࠥวๆๆࠪẊ"),KKty7kOjZC8MguQ,wwplD0tEehqH3kYQXs(u"ࠧศๆหีํ้ำ๋๊ࠢ์ࠥา็ศิࠣๅ๏ࠦวๅว้ฮึ์๊หࠢํ฽๊๊้ࠠีํ฻ࠥฮ๊็ࠢฯ๋ฬุใ๊ࠡส่ส์สา่ํฮࠥ࠴่๊ࠠࠣ๎ุะไๆฺ่ࠢออสไ๋ࠢ๎็๎ๅࠡสึัอํวࠡสา่ฬࠦๅ็ๅࠣฯ๊๊ࠦษ฻ฮ๋ฬࠦไไࠢ࠱ࠤ์๊ࠠหำํำࠥะิ฻์็ࠤศ๋ࠠฦ์ๅหๆࠦวๅสิ์ู่๊ࠡมࠪẋ"))
	if aZ06RtK7TfOop52BJg4==bcgZJWV6UeNSkRA(u"࠴ਰ"): AmeYCpn4Tx = iifPEY9ABNzTQp(u"ࠨࡃࡖࡏࠬẌ")
	elif aZ06RtK7TfOop52BJg4==InKG0i2r6hHDvgd(u"࠶਱"): AmeYCpn4Tx = yF29Xdsx35wI07Ce4(u"ࠩࡄ࡙࡙ࡕࠧẍ")
	elif aZ06RtK7TfOop52BJg4==drHLAY5ENQFe2q9ptKGabo(u"࠸ਲ"): AmeYCpn4Tx = shZ9eOcN2dJnPj(u"ࠪࡗ࡙ࡕࡐࠨẎ")
	else: AmeYCpn4Tx = ggDRehOModi(u"ࠫࠬẏ")
	if AmeYCpn4Tx:
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(xuztI5QWEKG70CPNdhk4vo6(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪẐ"),AmeYCpn4Tx)
		yyt8PD4F3YaQRmjCSzi2wr9ZvlA7O = MLPwxur5kaYlBtqcn[AmeYCpn4Tx]
		xl9MFt1AmY0GrkENug8n(wwplD0tEehqH3kYQXs(u"࠭ࠧẑ"),ggDRehOModi(u"ࠧࠨẒ"),nKLEi8CJumazx4qT(u"ࠨࠩẓ"),yyt8PD4F3YaQRmjCSzi2wr9ZvlA7O)
	return
def G1qOXwWd69BHF3MRIhukjgprE04i():
	pu2Fh4BUxasY = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥ࡯ࡷࡶࡧࡦࡩࡨࡦࠩẔ"))
	if pu2Fh4BUxasY==BGhdkWsEvJjiMFTr3NLn1flU(u"ࠪࡗ࡙ࡕࡐࠨẕ"): header = xuztI5QWEKG70CPNdhk4vo6(u"ࠫฯิา๋่ࠣห้่่ศศ่ࠤ๊ะ่ใใࠪẖ")
	else: header = oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠬะฮำ์้ࠤฬ๊โ้ษษ้๋ࠥแฺๆࠪẗ")
	iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(vvBChXmSty(u"࠭ࠧẘ"),ggDRehOModi(u"ࠧฦ์ๅหๆ࠭ẙ"),nKLEi8CJumazx4qT(u"ࠨฬไ฽๏๊ࠧẚ"),header,ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠩๅ์ฬฬๅࠡษ็ฬึ์วๆฮࠣ๎ฯ๋ࠠหฯา๎ะํวࠡล๋ฮํ๋วห์ๆ๎ฬࠦศฺัࠣ࠵࠻ࠦำศ฻ฬࠤ๊์ࠠฤ๊็ࠤศูสฯัส้ࠥ࠴࠮๊ࠡศ๎็อแࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠡ์วำ๏ࠦลๅ๋ࠣฮาี๊ฬ้สࠤๆ๐ࠠไๆ้ࠣึฯ๋ࠠฬ่ࠤฬูสฯัส้ࠥอไใ๊สส๊ࠦ࠮࠯๋๋ࠢีอ๋ࠠีหฬࠥฮืวࠢไ๎ࠥ็สฮࠢๅ์ฬฬๅࠡษ็ฬึ์วๆฮ࡟ࡲࡡࡴ่ࠠๆࠣฮึ๐ฯࠡฬไ฽๏๊ࠠฤ็ࠣษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠢยࠥࠦ࠭ẛ"))
	if iZL6cN3OkM5==-wwplD0tEehqH3kYQXs(u"࠱ਲ਼"): return
	elif iZL6cN3OkM5:
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(OyJ1o4AvmWlB75UkFRX(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡨࡧࡣࡩࡧࠪẜ"),JLoPRXt93dpAB(u"ࠫࡆ࡛ࡔࡐࠩẝ"))
		xl9MFt1AmY0GrkENug8n(yruHDQOcB97ig(u"ࠬ࠭ẞ"),bcgZJWV6UeNSkRA(u"࠭ࠧẟ"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪẠ"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠨฬ่ࠤฯ็ู๋ๆࠣฮำุ๊็ࠢส่็๎วว็ࠪạ"))
	else:
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥ࡯ࡷࡶࡧࡦࡩࡨࡦࠩẢ"),pcWq35MED2dtK(u"ࠪࡗ࡙ࡕࡐࠨả"))
		xl9MFt1AmY0GrkENug8n(nKLEi8CJumazx4qT(u"ࠫࠬẤ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠬ࠭ấ"),JLoPRXt93dpAB(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩẦ"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠧห็ࠣษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠩầ"))
	return
def do2ZFbNCYvwuT(kc57B93HrojbDIXVipY):
	if kc57B93HrojbDIXVipY!=Tgoa16jMxvYX2(u"ࠨࠩẨ"):
		kc57B93HrojbDIXVipY = KvSsHlYxGB7Dz5uMcbdJ2wt9hyCRj1(kc57B93HrojbDIXVipY)
		kc57B93HrojbDIXVipY = kc57B93HrojbDIXVipY.decode(yF29Xdsx35wI07Ce4(u"ࠩࡸࡸ࡫࠾ࠧẩ")).encode(shZ9eOcN2dJnPj(u"ࠪࡹࡹ࡬࠸ࠨẪ"))
		WoB2cq63nPylkp9iNEdxzC8 = n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠲࠲࠴࠴࠸਴")
		ddZk0oiBCfS4GzO6t8XUq31bWRcQA = XuWPVcQ13oDq5swf0S.Window(WoB2cq63nPylkp9iNEdxzC8)
		ddZk0oiBCfS4GzO6t8XUq31bWRcQA.getControl(PtXn0k9G3ocHRg(u"࠵࠴࠵ਵ")).setLabel(kc57B93HrojbDIXVipY)
	return
rRc7ePxbDHz = [
			 bcgZJWV6UeNSkRA(u"ࠦࡪࡾࡴࡦࡰࡶ࡭ࡴࡴࠠࠨࠩࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡧࡺࡸࡲࡦࡰࡷࡰࡾࠦࡳࡶࡲࡳࡳࡷࡺࡥࡥࠤẫ")
			,cNaVb1vsT4qWOL0rpE(u"ࠬࡉࡨࡦࡥ࡮࡭ࡳ࡭ࠠࡧࡱࡵࠤࡒࡧ࡬ࡪࡥ࡬ࡳࡺࡹࠠࡴࡥࡵ࡭ࡵࡺࡳࠨẬ")
			,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠭ࡐࡗࡔࠣࡍࡕ࡚ࡖࠡࡕ࡬ࡱࡵࡲࡥࠡࡅ࡯࡭ࡪࡴࡴࠨậ")
			,XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡘ࡬ࡨࡪࡵࠠࡊࡰࡩࡳࠥࡑࡥࡺࠩẮ")
			,yF29Xdsx35wI07Ce4(u"ࠨࡶ࡫࡭ࡸࠦࡨࡢࡵ࡫ࠤ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࠦࡩࡴࠢࡥࡶࡴࡱࡥ࡯ࠩắ")
			,KKbpxUZnMcj6AJ4QdD(u"ࠩࡸࡷࡪࡹࠠࡱ࡮ࡤ࡭ࡳࠦࡈࡕࡖࡓࠤ࡫ࡵࡲࠡࡣࡧࡨ࠲ࡵ࡮ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡶࠫẰ")
			,nKLEi8CJumazx4qT(u"ࠪࡥࡩࡼࡡ࡯ࡥࡨࡨ࠲ࡻࡳࡢࡩࡨ࠲࡭ࡺ࡭࡭ࠩằ")+OyJ1o4AvmWlB75UkFRX(u"ࠫࠨ࠭Ẳ")+yF29Xdsx35wI07Ce4(u"ࠬࡹࡳ࡭࠯ࡺࡥࡷࡴࡩ࡯ࡩࡶࠫẳ")
			,yruHDQOcB97ig(u"࠭ࡉ࡯ࡵࡨࡧࡺࡸࡥࡓࡧࡴࡹࡪࡹࡴࡘࡣࡵࡲ࡮ࡴࡧ࠭ࠩẴ")
			,BGhdkWsEvJjiMFTr3NLn1flU(u"ࠧࡆࡴࡵࡳࡷࠦࡧࡦࡶࡷ࡭ࡳ࡭ࠠࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄ࠰ࡁࡰࡳࡩ࡫ࡥ࠾࠲ࠩࡸࡪࡾࡴࡵ࠿ࠪẵ")
			,XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠨࡹࡤࡶࡳ࡯࡮ࡨࡵ࠱ࡻࡦࡸ࡮ࠩࠩẶ")
			,bbw2eajMlG(u"ࠩࡡࡢࡣࡤ࡞ࠨặ")
			,wwplD0tEehqH3kYQXs(u"ࠪࡐࡴࡧࡤࡪࡰࡪࠤࡸࡱࡩ࡯ࠢࡩ࡭ࡱ࡫࠺ࠨẸ")
			]
def b6iN7IJas42B01GQ3jULqdE8FuASzZ(mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ):
	if wwplD0tEehqH3kYQXs(u"ࠫࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡹ࡫ࡪࡰࠣࡪ࡮ࡲࡥ࠻ࠩẹ") in mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ and cNaVb1vsT4qWOL0rpE(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪẺ") in mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ: return drHLAY5ENQFe2q9ptKGabo(u"ࡕࡴࡸࡩઝ")
	for kc57B93HrojbDIXVipY in rRc7ePxbDHz:
		if kc57B93HrojbDIXVipY in mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ: return qnPgZ9N15G6Oa8UpMASvLk(u"ࡖࡵࡹࡪઞ")
	return shZ9eOcN2dJnPj(u"ࡉࡥࡱࡹࡥટ")
def XQbMWBe0VF3q9pPw(data):
	data = data.replace(cgtRBdXxSOk7WUfyDhPCls(u"࠭࡜ࡳ࡞ࡱࠫẻ")+bcgZJWV6UeNSkRA(u"࠸࠵ਸ਼")*iifPEY9ABNzTQp(u"ࠧࠡࠩẼ")+Tgoa16jMxvYX2(u"ࠨ࡞ࡵࡠࡳ࠭ẽ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠩ࡟ࡶࡡࡴࠧẾ"))
	data = data.replace(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠪࡠࡳ࠭ế")+nKLEi8CJumazx4qT(u"࠹࠶਷")*tZ3gsrTEdzA1S6LXa9WI5px(u"ࠫࠥ࠭Ề")+yruHDQOcB97ig(u"ࠬࡢࡲ࡝ࡰࠪề"),shZ9eOcN2dJnPj(u"࠭࡜ࡳ࡞ࡱࠫỂ"))
	data = data.replace(InKG0i2r6hHDvgd(u"ࠧ࡝ࡰࠪể")+yruHDQOcB97ig(u"࠺࠷ਸ")*XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠨࠢࠪỄ")+CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠩ࡟ࡲࠬễ"),ggDRehOModi(u"ࠪࡠࡳ࠭Ệ"))
	data = data.replace(yruHDQOcB97ig(u"ࠫࡡࡴࠧệ")+InKG0i2r6hHDvgd(u"࠵࠲਺")*drHLAY5ENQFe2q9ptKGabo(u"ࠬࠦࠧỈ"),qnPgZ9N15G6Oa8UpMASvLk(u"࠭࡜࡯ࠩỉ")+bbw2eajMlG(u"࠹࠱ਹ")*oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠧࠡࠩỊ"))
	data = data.replace(vvBChXmSty(u"ࠨࠢ࠿࡫ࡪࡴࡥࡳࡣ࡯ࡂ࠿ࠦࠧị"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠩ࠽ࠤࠬỌ"))
	XfOb4VIcPY = bcgZJWV6UeNSkRA(u"ࠪࠫọ")
	for mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ in data.splitlines():
		X3XmSZ8iB4fgCGuPb7xp = u5h2Rckvw1E.findall(KKbpxUZnMcj6AJ4QdD(u"ࠫࠥࠦࠠࠡࠢࡉ࡭ࡱ࡫ࠠࠣࠪ࠱࠮ࡄࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠱࠭ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪỎ"),mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ,u5h2Rckvw1E.DOTALL)
		if X3XmSZ8iB4fgCGuPb7xp: mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ = mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ.replace(X3XmSZ8iB4fgCGuPb7xp[cgtRBdXxSOk7WUfyDhPCls(u"࠱਻")],bcgZJWV6UeNSkRA(u"ࠬ࠭ỏ"))
		XfOb4VIcPY += OyJ1o4AvmWlB75UkFRX(u"࠭࡜࡯ࠩỐ")+mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ
	return XfOb4VIcPY
def cJUdZ92Fpu0hTb(RREOKInUF8lHNsa7AyB0PJMomteWv4):
	if KKbpxUZnMcj6AJ4QdD(u"ࠧࡐࡎࡇࠫố") in RREOKInUF8lHNsa7AyB0PJMomteWv4:
		pbwBduR50Oqfy1EsmKZ7tAI = t3IjC1ycv0XgoRUF6mZiLeT8Dz
		header = ggDRehOModi(u"ࠨไิหฦฯࠠศๆึะ้ࠦวๅไา๎๊ࠦฟࠨỒ")
	else:
		pbwBduR50Oqfy1EsmKZ7tAI = T1guYOxGi3ClA0d2s7kZf4J5b
		header = cgtRBdXxSOk7WUfyDhPCls(u"ࠩๅีฬวษࠡษ็ืั๊ࠠศๆะห้๐ࠠภࠩồ")
	iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(vvBChXmSty(u"ࠪࠫỔ"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠫࠬổ"),OyJ1o4AvmWlB75UkFRX(u"ࠬ࠭Ỗ"),header,KKbpxUZnMcj6AJ4QdD(u"࠭ำอๆࠣห้ษฮุษฤࠤ๏ำส้์ࠣว๏฼วࠡ฻็ํูࠥฬๅࠢส่ฬูสฯัส้ࠥ࠴้ࠠษ็หะ์๊็ูࠢีํื๊สࠢ็้฾ืแสࠢๆ๎ๆࠦอะออࠤฬ๊ๅีๅ็อࠥ๎ๅศ๊ࠢ์ࠥอไๆๅส๊ࠥอไั์ࠣือฮࠠฮั๋ฯࠥอไๆึๆ่ฮࠦ࠮ࠡๅ๋ำ๏๊ࠦฮฬไ฼ࠥฮำอๆํ๊ࠥ࠴ࠠศๆฦ์้ࠦ็้ࠢสุ่าไࠡษ็ัฬ๊๊๊ࠡไ๎์ࠦๅฺๆ๋้ฬะࠠหสาว๋ࠥๆัࠢหำฬ๐ษࠡษ็ฮูเ๊ๅࠢส่าอไ๋ࠢ็ฬึ์วๆฮࠣ็ํี๊๊ࠡส่๎ࠦวๅฤ้ࠤ࠳ࠦรๆษࠣหู้ฬๅࠢส่็ี๊ๆࠢไ๋ํࠦวๅีฯ่ࠥอไิษหๆࠥอไั์ࠣฮ๊ࠦฬๆ฻๊ࠤ๊์ࠠษำ้ห๊าࠠไ๊า๎่ࠥศๅࠢลาึࠦลุใสล๊ࠥ็ࠡ࠰๋้ࠣࠦสา์าࠤฬ๊วิฬ่ีฬืࠠภࠩỗ"))
	if iZL6cN3OkM5!=pcWq35MED2dtK(u"࠳਼"): return
	wGHtPnMczSE4LiICr3p70qy9,s2YQCOWqLAFlKT1bvGco3t8x96fnrp = [],iifPEY9ABNzTQp(u"࠳਽")
	size,count = FLTvHN0VMOGiZ29(pbwBduR50Oqfy1EsmKZ7tAI)
	file = open(pbwBduR50Oqfy1EsmKZ7tAI,yF29Xdsx35wI07Ce4(u"ࠧࡳࡤࠪỘ"))
	if size>r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠶࠶࠰࠳࠲࠳ਿ"): file.seek(-vvBChXmSty(u"࠵࠵࠶࠱࠱࠲ਾ"),k1t0JLRsCQ.SEEK_END)
	data = file.read()
	file.close()
	if VVGRN7xiyj: data = data.decode(ggDRehOModi(u"ࠨࡷࡷࡪ࠽࠭ộ"))
	data = XQbMWBe0VF3q9pPw(data)
	dvulfaW1UAFZ2JSrPxOYyeMHqn = data.split(bcgZJWV6UeNSkRA(u"ࠩ࡟ࡲࠬỚ"))
	for mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ in reversed(dvulfaW1UAFZ2JSrPxOYyeMHqn):
		MG1SvZdDqne0xwERVglC8 = b6iN7IJas42B01GQ3jULqdE8FuASzZ(mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ)
		if MG1SvZdDqne0xwERVglC8: continue
		mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ = mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ.replace(yF29Xdsx35wI07Ce4(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡣࠬớ"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪỜ"))
		mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ = mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ.replace(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠬࡋࡒࡓࡑࡕ࠾ࠬờ"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉ࠴࠵࠶࠰࡞ࡇࡕࡖࡔࡘ࠺࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩỞ"))
		d48xa3jKT1IvyXP = n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠧࠨở")
		jRw7qabV3cBf8iU0 = u5h2Rckvw1E.findall(BGhdkWsEvJjiMFTr3NLn1flU(u"ࠨࡠࠫࡠࡩ࠱࠭ࠩ࡞ࡧ࠯࠲ࡢࡤࠬࠢ࡟ࡨ࠰ࡀ࡜ࡥ࠭࠽ࡠࡩ࠱࡜࠯࡞ࡧ࠯࠮࠯ࠨࠡࡖ࠽ࡠࡩ࠱ࠩࠨỠ"),mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ,u5h2Rckvw1E.DOTALL)
		if jRw7qabV3cBf8iU0:
			mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ = mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ.replace(jRw7qabV3cBf8iU0[xuztI5QWEKG70CPNdhk4vo6(u"࠰ੁ")][xuztI5QWEKG70CPNdhk4vo6(u"࠰ੁ")],jRw7qabV3cBf8iU0[xuztI5QWEKG70CPNdhk4vo6(u"࠰ੁ")][yruHDQOcB97ig(u"࠷ੀ")]).replace(jRw7qabV3cBf8iU0[xuztI5QWEKG70CPNdhk4vo6(u"࠰ੁ")][xuztI5QWEKG70CPNdhk4vo6(u"࠳ੂ")],ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠩࠪỡ"))
			d48xa3jKT1IvyXP = jRw7qabV3cBf8iU0[usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠳੄")][nKLEi8CJumazx4qT(u"࠳੃")]
		else:
			jRw7qabV3cBf8iU0 = u5h2Rckvw1E.findall(nKLEi8CJumazx4qT(u"ࠪࡢ࠭ࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪỢ"),mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ,u5h2Rckvw1E.DOTALL)
			if jRw7qabV3cBf8iU0:
				mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ = mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ.replace(jRw7qabV3cBf8iU0[JLoPRXt93dpAB(u"࠵੆")][bbw2eajMlG(u"࠵੅")],vvBChXmSty(u"ࠫࠬợ"))
				d48xa3jKT1IvyXP = jRw7qabV3cBf8iU0[shZ9eOcN2dJnPj(u"࠶ੇ")][shZ9eOcN2dJnPj(u"࠶ੇ")]
		if d48xa3jKT1IvyXP: mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ = mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ.replace(d48xa3jKT1IvyXP,XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨỤ")+d48xa3jKT1IvyXP+CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨụ"))
		wGHtPnMczSE4LiICr3p70qy9.append(mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ)
		if len(str(wGHtPnMczSE4LiICr3p70qy9))>BGhdkWsEvJjiMFTr3NLn1flU(u"࠵࠱࠳࠳࠴ੈ"): break
	wGHtPnMczSE4LiICr3p70qy9 = reversed(wGHtPnMczSE4LiICr3p70qy9)
	JazGjMSk654 = qnPgZ9N15G6Oa8UpMASvLk(u"ࠧ࡝ࡰࠪỦ").join(wGHtPnMczSE4LiICr3p70qy9)
	RZo7IGjqXfiAnrWtlHcbNDuF9hP(nKLEi8CJumazx4qT(u"ࠨ࡮ࡨࡪࡹ࠭ủ"),drHLAY5ENQFe2q9ptKGabo(u"ࠩลาึࠦริูิࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊࠭Ứ"),JazGjMSk654,xuztI5QWEKG70CPNdhk4vo6(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡹ࡭ࡢ࡮࡯ࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭ứ"))
	return
def LVW5QDqlmafJPF9ZNOBojRCc1kIM():
	vpZUQNGewKhj8nq3mOf = open(m5w4leUWqAOQgh9Sf,usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠫࡷࡨࠧỪ")).read()
	if VVGRN7xiyj: vpZUQNGewKhj8nq3mOf = vpZUQNGewKhj8nq3mOf.decode(yruHDQOcB97ig(u"ࠬࡻࡴࡧ࠺ࠪừ"))
	vpZUQNGewKhj8nq3mOf = vpZUQNGewKhj8nq3mOf.replace(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠭࡜ࡵࠩỬ"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠧࠡࠢࠣࠤࠥࠦࠠࠡࠩử"))
	u9q1RZQYpdDUA = u5h2Rckvw1E.findall(yruHDQOcB97ig(u"ࠨࠪࡹࡠࡩ࠴ࠪࡀࠫ࡞ࡠࡳࡢࡲ࡞ࠩỮ"),vpZUQNGewKhj8nq3mOf,u5h2Rckvw1E.DOTALL)
	for mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ in u9q1RZQYpdDUA:
		vpZUQNGewKhj8nq3mOf = vpZUQNGewKhj8nq3mOf.replace(mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ,bcgZJWV6UeNSkRA(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬữ")+mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ+BGhdkWsEvJjiMFTr3NLn1flU(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬỰ"))
	r57bsFUQ9l83v4tq(JLoPRXt93dpAB(u"ࠫฬ๊ส฻์ํีฬะࠠศๆฦา๏ืษࠡใํࠤฬ๊ศาษ่ะࠬự"),vpZUQNGewKhj8nq3mOf)
	return
def tlLQWjHzgnXEDq3Y8COdK4vk9bS2oa():
	cLzOaV56rHkXKmxCy = iifPEY9ABNzTQp(u"ࠬฮูืࠢส่ศุัศำࠣ฽้๏ࠠศๆิ๎๊๎สࠡๅ๋๊ฯื่ๅࠢอ์ๆืࠠฦ็ๆห๋๐ษࠡฬๅำ๏๋้ࠠฬฦา๏ืࠠศๆไ๎ิ๐่๊๊ࠡิ์ࠦวๅลีีฬื่ࠠ์ࠣห้ษำ่็ࠣ์ฬ๊ราไสู้๋ࠥࠡส฼ฺࠥ๎ใศๆอห้๐ࠧỲ")
	Yw6S1bOqLcECfji7RJetgD = bbw2eajMlG(u"࠭ไหไา๎๊ࠦวๅใํำ๏๎ࠠศีอาิ๋ࠠศๆึ๋๊ࠦวๅ์่๎๋่ࠦๅฬฦา๏ื็ࠡษึฮำีๅࠡษ็ื์๋ࠠศๆํืฬืࠠ࠯ࠢฦ้ฬูࠦะหࠣหุํๅࠡ็อฮฬ๊๊สࠢไ๋ีํࠠหไ๋้ࠥฮสฮำํ็ࠥอไโ์า๎ํࠦศ้ไอࠤฬ้ศา่๊ࠢࠥ๎โหࠢสุ่ํๅࠡษ็์ฬำฯࠡ࠰ࠣว๊อࠠศๆึ๋๊ࠦวๅล฼่๎่ࠦศๆฦืๆ๊ࠠโ้๋ࠤ๏ำัไࠢส่ๆ๐ฯ๋๊ࠣษ้๏ࠠศๆฦ้ฬ๋ࠠฤ๊ࠣษ้๏ࠠศๆ๋ีฬว้ࠠๆๆ๊ࠥฮโโิฬࠤ่ฮ๊าหࠪỳ")
	H48QNMCzRXUI1eioTPunZFEdYsG = pcWq35MED2dtK(u"ࠧฤ็สࠤฬ๊ราไส้ࠥ็็๋ࠢอืฯิฯๆࠢ็่ฯ่ฯ๋็ࠣ์ฬ๊สฤะํีࠥ๎ไไ่ࠣฬ๊่ฯศำࠣ฽ิีࠠศๆฮ์ฬ์๊๊ࠡส่ิ่ววไࠣ࠲๋ࠥหๅษࠣี็๋ࠠ࠶࠶࠷ࠤฯ฿ๆ๋ࠢ࠸ࠤิ่ววไࠣ์ࠥ࠺࠴ࠡอส๊๏ฯࠠฦๆ์ࠤฬ๊รๆษ่ࠤศ๎ࠠฦๆ์ࠤฬ๊่าษฤࠤอำำษࠢสืฯิฯศ็ๆࠤ้๊ำ่็ࠣห้๐ๅ๋่ࠣวํࠦำ่็ࠣห้๐ำศำࠪỴ")
	MLPwxur5kaYlBtqcn = cLzOaV56rHkXKmxCy+oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠨ࠼ࠣࠫỵ")+Yw6S1bOqLcECfji7RJetgD+InKG0i2r6hHDvgd(u"ࠩࠣ࠲ࠥ࠭Ỷ")+H48QNMCzRXUI1eioTPunZFEdYsG
	RZo7IGjqXfiAnrWtlHcbNDuF9hP(cNaVb1vsT4qWOL0rpE(u"ࠪࡧࡪࡴࡴࡦࡴࠪỷ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧỸ"),MLPwxur5kaYlBtqcn,PtXn0k9G3ocHRg(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨỹ"))
	return
def X2XWUFPVMDugaGkehc4EYlp(type,MLPwxur5kaYlBtqcn,showDialogs=KKbpxUZnMcj6AJ4QdD(u"ࡘࡷࡻࡥઠ"),url=Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠭ࠧỺ"),BYGZC29KJ5Piag36Dl=InKG0i2r6hHDvgd(u"ࠧࠨỻ"),kc57B93HrojbDIXVipY=yruHDQOcB97ig(u"ࠨࠩỼ"),jWYvO6grcHt4fdT7VXEZu=n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠩࠪỽ")):
	EMUrj3HflPtx1XYKmwaQF5CAv4 = wwplD0tEehqH3kYQXs(u"࡙ࡸࡵࡦડ")
	if not yrPav1tl5MQcfEBhsXk2o(r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠪࡇ࡙ࡋ࠹ࡅࡕ࠴࠽࡛࡛࠰ࡗࡕ࡛ࠫỾ")):
		if showDialogs:
			HzKEs7IUu4pGRfhDyj9oYiNvOr6Q = (vvBChXmSty(u"ࠫฬ๊ำุำ࠽ࠫỿ") in MLPwxur5kaYlBtqcn and Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠬอไๆๅส๊࠿࠭ἀ") in MLPwxur5kaYlBtqcn and M6PIj8gl1fno7wcqTksDEBK4bU(u"࠭วๅ็็ๅ࠿࠭ἁ") in MLPwxur5kaYlBtqcn and yF29Xdsx35wI07Ce4(u"ࠧศๆั฻ศ࠭ἂ") in MLPwxur5kaYlBtqcn and yF29Xdsx35wI07Ce4(u"ࠨษ็ฺ้ีั࠻ࠩἃ") in MLPwxur5kaYlBtqcn)
			if not HzKEs7IUu4pGRfhDyj9oYiNvOr6Q: EMUrj3HflPtx1XYKmwaQF5CAv4 = lLPSDywfu4axrUhvX9RQEpGtso6H0(iifPEY9ABNzTQp(u"ࠩࡦࡩࡳࡺࡥࡳࠩἄ"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࠪࠫἅ"),wwplD0tEehqH3kYQXs(u"ࠫࠬἆ"),shZ9eOcN2dJnPj(u"ࠬํไࠡฬิื้ࠦ็ั้ࠣห้ืำศๆฬࠤส๊้ࠡษ็้อืๅอࠩἇ"),MLPwxur5kaYlBtqcn.replace(xuztI5QWEKG70CPNdhk4vo6(u"࠭࡜࡝ࡰࠪἈ"),shZ9eOcN2dJnPj(u"ࠧ࡝ࡰࠪἉ")))
	elif showDialogs:
		MLPwxur5kaYlBtqcn = KKbpxUZnMcj6AJ4QdD(u"ࠨ࡞࡟ࡲฯ๋ࠠๆีะࠤฬ๊ัิษ็อࡡࡢ࡮ห็ุ้ࠣำࠠาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไส࡞࡟ࡲฯ๋ࠠๆีะࠤฬ๊ัิษ็อࡡࡢ࡮ห็ุ้ࠣำࠠศๆิืฬ๊ษࠨἊ")
		mJUgh9ZX45vTyEDVl0S7zWRfI1bcCp = lLPSDywfu4axrUhvX9RQEpGtso6H0(XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠩࡦࡩࡳࡺࡥࡳࠩἋ"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠪࠫἌ"),yF29Xdsx35wI07Ce4(u"ࠫࠬἍ"),yF29Xdsx35wI07Ce4(u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬἎ")+cNaVb1vsT4qWOL0rpE(u"࠭ࠠࠡ࠳࠲࠹ࠬἏ"),ggDRehOModi(u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬἐ"))
		nR0IV25GrHOCdDXge = lLPSDywfu4axrUhvX9RQEpGtso6H0(cNaVb1vsT4qWOL0rpE(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨἑ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠩࠪἒ"),Tgoa16jMxvYX2(u"ࠪࠫἓ"),KKbpxUZnMcj6AJ4QdD(u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫἔ")+ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠬࠦࠠ࠳࠱࠸ࠫἕ"),xuztI5QWEKG70CPNdhk4vo6(u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫ἖"))
		SPGRYB3zmUZMtsD0l79LwNV = lLPSDywfu4axrUhvX9RQEpGtso6H0(bbw2eajMlG(u"ࠧࡤࡧࡱࡸࡪࡸࠧ἗"),bbw2eajMlG(u"ࠨࠩἘ"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࠩࠪἙ"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪἚ")+XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠫࠥࠦ࠳࠰࠷ࠪἛ"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪἜ"))
		XzbUdny2tM9Th5gYFIsiOrDJ80 = lLPSDywfu4axrUhvX9RQEpGtso6H0(bcgZJWV6UeNSkRA(u"࠭ࡣࡦࡰࡷࡩࡷ࠭Ἕ"),xuztI5QWEKG70CPNdhk4vo6(u"ࠧࠨ἞"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠨࠩ἟"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩἠ")+yruHDQOcB97ig(u"ࠪࠤࠥ࠺࠯࠶ࠩἡ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩἢ"))
		EMUrj3HflPtx1XYKmwaQF5CAv4 = lLPSDywfu4axrUhvX9RQEpGtso6H0(xuztI5QWEKG70CPNdhk4vo6(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬἣ"),yruHDQOcB97ig(u"࠭ࠧἤ"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠧࠨἥ"),KKbpxUZnMcj6AJ4QdD(u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨἦ")+iifPEY9ABNzTQp(u"ࠩࠣࠤ࠺࠵࠵ࠨἧ"),iifPEY9ABNzTQp(u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨἨ"))
	hGdKt2jR8SN1z5TrZkuU = lbFixEt3BK9YGMyWIQZuSsp1V7JTL8(shZ9eOcN2dJnPj(u"࠴࠴੉"),yruHDQOcB97ig(u"ࡌࡡ࡭ࡵࡨઢ"))
	ccAkpldSQO5mTFeUaovwPM = n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠫࡆ࡜࠺ࠡࠩἩ")+hGdKt2jR8SN1z5TrZkuU+r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠬ࠳ࠧἪ")+type
	LLvAUFN4fXhlZ = qnPgZ9N15G6Oa8UpMASvLk(u"ࡕࡴࡸࡩત") if yruHDQOcB97ig(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩἫ") in kc57B93HrojbDIXVipY else cgtRBdXxSOk7WUfyDhPCls(u"ࡆࡢ࡮ࡶࡩણ")
	if not EMUrj3HflPtx1XYKmwaQF5CAv4:
		if showDialogs: xl9MFt1AmY0GrkENug8n(iifPEY9ABNzTQp(u"ࠧࠨἬ"),shZ9eOcN2dJnPj(u"ࠨࠩἭ"),cNaVb1vsT4qWOL0rpE(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬἮ"),PtXn0k9G3ocHRg(u"ࠪฮ๊ࠦลๅ฼สลࠥอไฦำึห้ࠦศ็ษฤࠤ฾ู๊้ࠡ็ฬ่࠭Ἧ"))
		return bbw2eajMlG(u"ࡈࡤࡰࡸ࡫થ")
	YpXUoGsTklaNFRL6iqtOQZ = bMIascyFJ2x43E0C7glTB91h8qz.getInfoLabel(cgtRBdXxSOk7WUfyDhPCls(u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡋࡸࡩࡦࡰࡧࡰࡾࡔࡡ࡮ࡧࠪἰ"))
	MLPwxur5kaYlBtqcn += usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠬࠦ࡜࡝ࡰ࡟ࡠࡳࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࠦ࡜࡝ࡰࡄࡨࡩࡵ࡮ࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠫἱ")+qkSQU3saP0D7OvynNzH4F2BKJuilT+XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠭ࠠ࠻࡞࡟ࡲࠬἲ")
	MLPwxur5kaYlBtqcn += iifPEY9ABNzTQp(u"ࠧࡆ࡯ࡤ࡭ࡱࠦࡓࡦࡰࡧࡩࡷࡀࠠࠨἳ")+hGdKt2jR8SN1z5TrZkuU+nKLEi8CJumazx4qT(u"ࠨࠢ࠽ࡠࡡࡴࡋࡰࡦ࡬ࠤ࡛࡫ࡲࡴ࡫ࡲࡲ࠿ࠦࠧἴ")+UFdmsKIGAx0JrVCe+yruHDQOcB97ig(u"ࠩࠣ࠾ࡡࡢ࡮ࠨἵ")
	MLPwxur5kaYlBtqcn += PtXn0k9G3ocHRg(u"ࠪࡏࡴࡪࡩࠡࡐࡤࡱࡪࡀࠠࠨἶ")+YpXUoGsTklaNFRL6iqtOQZ
	OOjM98q7XuSQl = COnauLbjTwX31YoPgxNlcJ()
	OOjM98q7XuSQl = QQXTVNve6DMHBp4scG170kR2lWY(OOjM98q7XuSQl)
	if OOjM98q7XuSQl: MLPwxur5kaYlBtqcn += BGhdkWsEvJjiMFTr3NLn1flU(u"ࠫࠥࡀ࡜࡝ࡰࡏࡳࡨࡧࡴࡪࡱࡱ࠾ࠥ࠭ἷ")+OOjM98q7XuSQl
	if url: MLPwxur5kaYlBtqcn += InKG0i2r6hHDvgd(u"ࠬࠦ࠺࡝࡞ࡱ࡙ࡗࡒ࠺ࠡࠩἸ")+url
	if BYGZC29KJ5Piag36Dl: MLPwxur5kaYlBtqcn += wwplD0tEehqH3kYQXs(u"࠭ࠠ࠻࡞࡟ࡲࡘࡵࡵࡳࡥࡨ࠾ࠥ࠭Ἱ")+BYGZC29KJ5Piag36Dl
	MLPwxur5kaYlBtqcn += pcWq35MED2dtK(u"ࠧࠡ࠼࡟ࡠࡳ࠭Ἲ")
	if showDialogs: dnS80F92qtLi4vw1(bbw2eajMlG(u"ࠨฮสี๏ࠦวๅวิืฬ๊ࠧἻ"),bcgZJWV6UeNSkRA(u"ࠩส่ึาวยࠢส่ฬ์สูษิࠫἼ"))
	if jWYvO6grcHt4fdT7VXEZu:
		JazGjMSk654 = jWYvO6grcHt4fdT7VXEZu
		if VVGRN7xiyj: JazGjMSk654 = JazGjMSk654.encode(M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠪࡹࡹ࡬࠸ࠨἽ"))
		JazGjMSk654 = yB3NPc2ZhbwFEi1X0dv.b64encode(JazGjMSk654)
	elif LLvAUFN4fXhlZ:
		if KKbpxUZnMcj6AJ4QdD(u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࡏࡍࡆࡢࠫἾ") in kc57B93HrojbDIXVipY: h1WSNslJoZ73qAuR = t3IjC1ycv0XgoRUF6mZiLeT8Dz
		else: h1WSNslJoZ73qAuR = T1guYOxGi3ClA0d2s7kZf4J5b
		if not k1t0JLRsCQ.path.exists(h1WSNslJoZ73qAuR):
			xl9MFt1AmY0GrkENug8n(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠬ࠭Ἷ"),pcWq35MED2dtK(u"࠭ࠧὀ"),shZ9eOcN2dJnPj(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪὁ"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠨีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣ฾๏ืࠠๆ๊ฯ์ิ࠭ὂ"))
			return cNaVb1vsT4qWOL0rpE(u"ࡉࡥࡱࡹࡥદ")
		wGHtPnMczSE4LiICr3p70qy9,s2YQCOWqLAFlKT1bvGco3t8x96fnrp = [],xuztI5QWEKG70CPNdhk4vo6(u"࠲੊")
		size,count = FLTvHN0VMOGiZ29(h1WSNslJoZ73qAuR)
		file = open(h1WSNslJoZ73qAuR,yruHDQOcB97ig(u"ࠩࡵࡦࠬὃ"))
		if size>shZ9eOcN2dJnPj(u"࠶࠺࠶࠲࠱࠲ੌ"): file.seek(-tZ3gsrTEdzA1S6LXa9WI5px(u"࠵࠹࠵࠷࠰࠱ੋ"),k1t0JLRsCQ.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠪࡹࡹ࡬࠸ࠨὄ"))
		data = XQbMWBe0VF3q9pPw(data)
		dvulfaW1UAFZ2JSrPxOYyeMHqn = data.splitlines()
		for mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ in reversed(dvulfaW1UAFZ2JSrPxOYyeMHqn):
			MG1SvZdDqne0xwERVglC8 = b6iN7IJas42B01GQ3jULqdE8FuASzZ(mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ)
			if MG1SvZdDqne0xwERVglC8: continue
			jRw7qabV3cBf8iU0 = u5h2Rckvw1E.findall(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠫࡣ࠮࡜ࡥ࠭࠰ࠬࡡࡪࠫ࠮࡞ࡧ࠯ࠥࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫὅ"),mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ,u5h2Rckvw1E.DOTALL)
			if jRw7qabV3cBf8iU0:
				mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ = mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ.replace(jRw7qabV3cBf8iU0[wwplD0tEehqH3kYQXs(u"࠶੎")][wwplD0tEehqH3kYQXs(u"࠶੎")],jRw7qabV3cBf8iU0[wwplD0tEehqH3kYQXs(u"࠶੎")][ggDRehOModi(u"࠶੍")]).replace(jRw7qabV3cBf8iU0[wwplD0tEehqH3kYQXs(u"࠶੎")][r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠲੏")],yF29Xdsx35wI07Ce4(u"ࠬ࠭὆"))
			else:
				jRw7qabV3cBf8iU0 = u5h2Rckvw1E.findall(iifPEY9ABNzTQp(u"࠭࡞ࠩ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠭ࠦࡔ࠻࡞ࡧ࠯࠮࠭὇"),mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ,u5h2Rckvw1E.DOTALL)
				if jRw7qabV3cBf8iU0: mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ = mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ.replace(jRw7qabV3cBf8iU0[iifPEY9ABNzTQp(u"࠲ੑ")][bbw2eajMlG(u"࠲੐")],bbw2eajMlG(u"ࠧࠨὈ"))
			wGHtPnMczSE4LiICr3p70qy9.append(mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ)
			if len(str(wGHtPnMczSE4LiICr3p70qy9))>drHLAY5ENQFe2q9ptKGabo(u"࠴࠶࠶࠶࠰࠱੒"): break
		wGHtPnMczSE4LiICr3p70qy9 = reversed(wGHtPnMczSE4LiICr3p70qy9)
		JazGjMSk654 = pcWq35MED2dtK(u"ࠨ࡞ࡵࡠࡳ࠭Ὁ").join(wGHtPnMczSE4LiICr3p70qy9)
		JazGjMSk654 = JazGjMSk654.encode(KKbpxUZnMcj6AJ4QdD(u"ࠩࡸࡸ࡫࠾ࠧὊ"))
		JazGjMSk654 = yB3NPc2ZhbwFEi1X0dv.b64encode(JazGjMSk654)
	else: JazGjMSk654 = usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠪࠫὋ")
	url = pgPfwZleTHVQ9a[M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫὌ")][r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠶੓")]
	nD70jhRb8C9Gi = {bcgZJWV6UeNSkRA(u"ࠬࡹࡵࡣ࡬ࡨࡧࡹ࠭Ὅ"):ccAkpldSQO5mTFeUaovwPM,vvBChXmSty(u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࡥࠨ὎"):MLPwxur5kaYlBtqcn,nKLEi8CJumazx4qT(u"ࠧ࡭ࡱࡪࡪ࡮ࡲࡥࠨ὏"):JazGjMSk654}
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,InKG0i2r6hHDvgd(u"ࠨࡒࡒࡗ࡙࠭ὐ"),url,nD70jhRb8C9Gi,qnPgZ9N15G6Oa8UpMASvLk(u"ࠩࠪὑ"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠪࠫὒ"),shZ9eOcN2dJnPj(u"ࠫࠬὓ"),InKG0i2r6hHDvgd(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡔࡇࡑࡈࡤࡋࡍࡂࡋࡏ࠱࠶ࡹࡴࠨὔ"))
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	if qnPgZ9N15G6Oa8UpMASvLk(u"࠭ࠢࡴࡷࡦࡧࡪ࡫ࡤࡦࡦࠥ࠾ࠥ࠷ࠬࠨὕ") in oo9SgGkiDbs3HRn7z8: V5VXz0j3oa6t = qnPgZ9N15G6Oa8UpMASvLk(u"ࡘࡷࡻࡥધ")
	else: V5VXz0j3oa6t = OyJ1o4AvmWlB75UkFRX(u"ࡋࡧ࡬ࡴࡧન")
	if showDialogs:
		if V5VXz0j3oa6t:
			dnS80F92qtLi4vw1(bbw2eajMlG(u"ࠧห็ࠣห้หัิษ็ࠫὖ"),cgtRBdXxSOk7WUfyDhPCls(u"ࠨส้ะฬำࠧὗ"))
			xl9MFt1AmY0GrkENug8n(InKG0i2r6hHDvgd(u"ࠩࠪ὘"),wwplD0tEehqH3kYQXs(u"ࠪࠫὙ"),pcWq35MED2dtK(u"ࠫࡒ࡫ࡳࡴࡣࡪࡩࠥࡹࡥ࡯ࡶࠪ὚"),JLoPRXt93dpAB(u"ࠬะๅࠡวิืฬ๊ࠠศๆิืฬ๊ษࠡส้ะฬำࠧὛ"))
		else:
			dnS80F92qtLi4vw1(BGhdkWsEvJjiMFTr3NLn1flU(u"࠭ไๅลึๅࠬ὜"),xuztI5QWEKG70CPNdhk4vo6(u"ࠧโึ็ࠤๆ๐ࠠศๆศีุอไࠨὝ"))
			xl9MFt1AmY0GrkENug8n(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠨࠩ὞"),yF29Xdsx35wI07Ce4(u"ࠩࠪὟ"),cgtRBdXxSOk7WUfyDhPCls(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ὠ"),InKG0i2r6hHDvgd(u"ࠫำ฽ร๊ࠡไุ้ࠦแ๋ࠢศีุอไࠡษ็ีุอไสࠩὡ"))
	return V5VXz0j3oa6t
def tg09qzI1unZAhidsrfGLc():
	cLzOaV56rHkXKmxCy = Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠬ࠷࠮ࠡࠢࠣࡍ࡫ࠦࡹࡰࡷࠣ࡬ࡦࡼࡥࠡࡲࡵࡳࡧࡲࡥ࡮ࠢࡺ࡭ࡹ࡮ࠠࡂࡴࡤࡦ࡮ࡩࠠࡵࡧࡻࡸࡹࠦࡴࡩࡧࡱࠤ࡬ࡵࠠࡵࡱࠣࠦࡐࡵࡤࡪࠢࡌࡲࡹ࡫ࡲࡧࡣࡦࡩ࡙ࠥࡥࡵࡶ࡬ࡲ࡬ࡹࠢࠡࡣࡱࡨࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡩࡳࡳࡺࠠࡵࡱࠣࠦࡆࡸࡩࡢ࡮ࠥࠫὢ")
	Yw6S1bOqLcECfji7RJetgD = yF29Xdsx35wI07Ce4(u"࠭࠱࠯ࠢࠣࠤสึวࠡๆา๎่ࠦๅีๅ็อࠥ็๊ࠡษ็วาืแࠡษ็฽ึฮ๊สࠢไหีํศࠡว็ํࠥหูะษาหฯ่ࠦศฮ๊อ้่ࠥะ์ࠣฯฺ๊๋ࠦำࠣห้ิืࠡษ็ุ้ะฮะ็ࠣษ้๏ࠠࠣࡃࡵ࡭ࡦࡲࠢࠨὣ")
	xl9MFt1AmY0GrkENug8n(cgtRBdXxSOk7WUfyDhPCls(u"ࠧࠨὤ"),iifPEY9ABNzTQp(u"ࠨࠩὥ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠩࡄࡶࡦࡨࡩࡤࠢࡓࡶࡴࡨ࡬ࡦ࡯ࠪὦ"),cLzOaV56rHkXKmxCy+wwplD0tEehqH3kYQXs(u"ࠪࡠࡳࡢ࡮ࠨὧ")+Yw6S1bOqLcECfji7RJetgD)
	cLzOaV56rHkXKmxCy = yruHDQOcB97ig(u"ࠫ࠷࠴ࠠࠡࠢࡌࡪࠥࡿ࡯ࡶࠢࡦࡥࡳࡢࠧࡵࠢࡩ࡭ࡳࡪࠠࠣࡃࡵ࡭ࡦࡲࠢࠡࡨࡲࡲࡹࠦࡴࡩࡧࡱࠤࡨ࡮ࡡ࡯ࡩࡨࠤࡹ࡮ࡥࠡࡵ࡮࡭ࡳࠦࡡ࡯ࡦࠣࡸ࡭࡫࡮ࠡࡥ࡫ࡥࡳ࡭ࡥࠡࡶ࡫ࡩࠥ࡬࡯࡯ࡶࠪὨ")
	Yw6S1bOqLcECfji7RJetgD = yF29Xdsx35wI07Ce4(u"ࠬ࠸࠮ࠡࠢࠣษีอࠠๅ็ࠣฮัีࠠศๆั฻ࠥࠨࡁࡳ࡫ࡤࡰࠧࠦแใ็ࠣฬฯเ๊๋ำࠣห้าไะࠢฮ้่ࠥๅࠡสอ฾๏ืࠠศๆั฻ࠥอไๆีอาิ๋ࠠฦๆ์ࠤࠧࡇࡲࡪࡣ࡯ࠦࠬὩ")
	xl9MFt1AmY0GrkENug8n(iifPEY9ABNzTQp(u"࠭ࠧὪ"),drHLAY5ENQFe2q9ptKGabo(u"ࠧࠨὫ"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠨࡈࡲࡲࡹࠦࡐࡳࡱࡥࡰࡪࡳࠧὬ"),cLzOaV56rHkXKmxCy+n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠩ࡟ࡲࡡࡴࠧὭ")+Yw6S1bOqLcECfji7RJetgD)
	cLzOaV56rHkXKmxCy = cgtRBdXxSOk7WUfyDhPCls(u"ࠪ࠷࠳ࠦࠠࠡࡋࡩࠤࡾࡵࡵࠡࡦࡲࡲࡡ࠭ࡴࠡࡪࡤࡺࡪࠦࡁࡳࡣࡥ࡭ࡨࠦࡋࡦࡻࡥࡳࡦࡸࡤࠡࡶ࡫ࡩࡳࠦࡧࡰࠢࡷࡳࠥࠨࡋࡰࡦ࡬ࠤࡎࡴࡴࡦࡴࡩࡥࡨ࡫ࠠࡔࡧࡷࡸ࡮ࡴࡧࡴࠤࠣࡥࡳࡪࠠࡤࡪࡤࡲ࡬࡫ࠠࡵࡪࡨࠤࡷ࡫ࡧࡪࡱࡱࡥࡱࠦࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠨὮ")
	Yw6S1bOqLcECfji7RJetgD = usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠫ࠸࠴ࠠࠡࠢศิฬࠦไๆࠢํ็๋ࠦไะ์ๆࠤ้๎อส่ࠢๅฬะ๊ฮࠢ฼ีอ๐ษࠡใสิ์ฮࠠฦๆ์ࠤส฿ฯศัสฮࠥ๎วอ้ฬࠤ่๎ฯ๋ࠢฮ้ࠥเ๊าࠢศ฽ิอฯศฬࠣห้๋ๆุไฬࠤฬ๊ฬ฻ำสๅ๏ฯࠧὯ")
	xl9MFt1AmY0GrkENug8n(KKbpxUZnMcj6AJ4QdD(u"ࠬ࠭ὰ"),InKG0i2r6hHDvgd(u"࠭ࠧά"),yruHDQOcB97ig(u"ࠧࡇࡱࡱࡸࠥࡖࡲࡰࡤ࡯ࡩࡲ࠭ὲ"),cLzOaV56rHkXKmxCy+wwplD0tEehqH3kYQXs(u"ࠨ࡞ࡱࡠࡳ࠭έ")+Yw6S1bOqLcECfji7RJetgD)
	iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(qnPgZ9N15G6Oa8UpMASvLk(u"ࠩࡦࡩࡳࡺࡥࡳࠩὴ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠪࠫή"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠫࠬὶ"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠬࡌ࡯࡯ࡶࠣࡷࡪࡺࡴࡪࡰࡪࡷࠬί"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠭ࡄࡰࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡨࡱࠣࡸࡴࠦࠢࡌࡱࡧ࡭ࠥࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࠡࡕࡨࡸࡹ࡯࡮ࡨࡵࠥࠤࡳࡵࡷࠡࡁࠪὸ")+r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠧ࡝ࡰ࡟ࡲࠬό")+BGhdkWsEvJjiMFTr3NLn1flU(u"ࠨ้็ࠤฯื๊ะࠢส่ีํวษࠢศ่๎ࠦไ้ฯฬࠤส฿ฯศัสฮࠥ๎วอ้ฬࠤ่๎ฯ๋ࠢฦ่ว์ฟࠨὺ"))
	if iZL6cN3OkM5==JLoPRXt93dpAB(u"࠶੔"): MPlbH8aQIhq0C2RdS()
	return
def hrTqGJbFIWQlSoPKXswzRM4Z3Vm():
	xl9MFt1AmY0GrkENug8n(drHLAY5ENQFe2q9ptKGabo(u"ࠩࠪύ"),KKbpxUZnMcj6AJ4QdD(u"ࠪࠫὼ"),Tgoa16jMxvYX2(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧώ"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠬเวๅสสࠤฬ๊ำษส๋ࠣํࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢส่๊เะ๋ࠢ็่อืๆศ็ฯࠤํ๊ไหลๆำ่ࠥๅࠡสอุ฿๐ไࠡษ็ีฬฮืࠡษ็ิ๏ࠦไศࠢํ฽๊๊ࠠฬ็ࠣๆ๊ࠦศฦำึห้ࠦๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮ้๋ࠣࠦวๅไสส๊ฯࠠศๆิส๏ู๊สࠢ็่อืๆศ็ฯࠫ὾"))
	return
def nAV2iYB3LK1Oq():
	MLPwxur5kaYlBtqcn = wwplD0tEehqH3kYQXs(u"࠭็ัษࠣห้ฮั็ษ่ะ๋ࠥฮึืࠣๅ็฽ࠠๅๆ฽อࠥอไฺำห๎ฮ่ࠦๅๅ้ࠤ์ึวࠡๆสࠤ๏๋ๆฺ๋ࠢะํีࠠๆ๊สๆ฾ࠦแ๋้สࠤศ็ไศ็ࠣ์ู๊ไิๆสฮ๋ࠥสาฮ่อࠥษ่ࠡ็าฬ้าษࠡว็ํࠥอไๅ฼ฬࠤฬู๊าสํอࠥ๎วๅ๋่ࠣ฿อสࠡษัี๎่ࠦๅษࠣ๎ําฯࠡีหฬ๊ࠥไหๅิหึ࠭὿")
	xl9MFt1AmY0GrkENug8n(usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠧࠨᾀ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠨࠩᾁ"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᾂ"),MLPwxur5kaYlBtqcn)
	return
def TOICSdzuAfYDUK():
	MLPwxur5kaYlBtqcn = xuztI5QWEKG70CPNdhk4vo6(u"ࠪห้ื่ศสฺࠤฬ๊ศุ์ษอ๊ࠥวࠡ฻็ห็ฯࠠๅ้สࠤออไษำ้ห๊า้ࠠ฼ส่ออࠠศๆึฬอࠦ็้่๊ࠢࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥอไๆ฼ำ๎๊ࠥไษำ้ห๊าࠧᾃ")
	xl9MFt1AmY0GrkENug8n(Tgoa16jMxvYX2(u"ࠫࠬᾄ"),yruHDQOcB97ig(u"ࠬ࠭ᾅ"),pcWq35MED2dtK(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᾆ"),MLPwxur5kaYlBtqcn)
	return
def NLvbHFaBcK5SD():
	MLPwxur5kaYlBtqcn = r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"่ࠧ์ࠣื๏ืแาษอࠤ้อ๋ࠠีอ฻๏฿ࠠศๆหี๋อๅอࠢสืฯิฯศ็๊หࠥฮำษสࠣ็ํ์็ศ่ࠢั๊๐ษࠡ็้ࠤฬ๊ๅึัิࠤศ๎ࠠษฯสะฮࠦลๅ๋ࠣหูะัศๅࠣีุ๋๊ࠡล๋ࠤัี๊ะหࠣวํࠦไศࠢํ฽ึ็็ศࠢส่อืๆศ็ฯࠫᾇ")
	xl9MFt1AmY0GrkENug8n(pcWq35MED2dtK(u"ࠨࠩᾈ"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩࠪᾉ"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᾊ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ุࠫ๐ัโำสฮู๊ࠥวหࠣวํࠦๅอ้๋่ฮ࠭ᾋ"),MLPwxur5kaYlBtqcn)
	return
def eFJBGbkH72CwoSTRNAPfv5cW():
	MLPwxur5kaYlBtqcn = Tgoa16jMxvYX2(u"ࠬอไิ์ิๅึอสࠡษ็฽ฬ๋ษ้ࠡํࠤุ๐ัโำสฮࠥิวาฮํอࠥ๎ฺ๋ำࠣฮฬฮูสࠢ็่๊๎โฺࠢส่ศ฻ไ๋๋ࠢะ๊๐ูࠡษ็้ํอโฺࠢอืฯิฯๆ้สࠤํ฿วะหࠣฮ่๎ๆࠡ็ฯห๋๐ษุ๊่ࠡฬ้ไ่ษࠣ็ะ๐ัสࠢ็ห๋ࠦวๅใํำ๏๎็ศฬࠣๅ๏ํวࠡว่หࠥฮื๋ศฬࠤศ๎ࠠๆ็้์฾ฯࠠฤ๊้ࠣาึ่โหࠣวํࠦแ๋้สࠤฺ๊ใๅหࠣั็๎โࠡษ็้้้๊ส࡞ࡱࡠࡳࡢ࡮ศๆึ๎ึ็ัศฬࠣห้ิวึห๋ࠣ๏ࠦำ๋ำไีฬะࠠหษห฽ฮࠦไๅ็๋ๆ฾ࠦวๅลุ่๏่ࠦๆีอาิ๋ษࠡใํࠤ๊๎วใ฻ࠣๆ้๐ไสࠢฯำฬฺ่ࠦษาอࠥะใ้่้ࠣิ็ฺ่หࠣห้ษฬาࠢฦ์ࠥ๐ๅๅๅ๊หࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥ๎ไ่าสࠤๆํ๊ࠡฮํำฮࠦๆิสํหࠥ๎ำา์฼อࠥ๎ๅีษๆ่์อࠠใๆํ่ฮࠦฬะษࠪᾌ")
	RZo7IGjqXfiAnrWtlHcbNDuF9hP(InKG0i2r6hHDvgd(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᾍ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᾎ"),MLPwxur5kaYlBtqcn,iifPEY9ABNzTQp(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫᾏ"))
	return
def ZqWCJrlIaN4TVSzAMj6():
	cLzOaV56rHkXKmxCy = wwplD0tEehqH3kYQXs(u"ࠩสฬฯ฿ฯࠡ฻้ࠤ๊๊แศฬࠣห้ีโสࠢส่฾อไ๋หࠪᾐ")
	Yw6S1bOqLcECfji7RJetgD = KKbpxUZnMcj6AJ4QdD(u"ࠪหอะูะࠢ฼๊๋ࠥไโษอࠤศ๊ࠠ࡮࠵ࡸ࠼ࠬᾑ")
	H48QNMCzRXUI1eioTPunZFEdYsG = vvBChXmSty(u"ࠫฬฮสฺัࠣ฽๋ࠦๅๅใสฮࠥอไหฯ่๎้่ࠦศๆาหํ์ไ้ัࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠬᾒ")
	xl9MFt1AmY0GrkENug8n(oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠬ࠭ᾓ"),Tgoa16jMxvYX2(u"࠭ࠧᾔ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᾕ"),cLzOaV56rHkXKmxCy,Yw6S1bOqLcECfji7RJetgD,H48QNMCzRXUI1eioTPunZFEdYsG)
	return
def ZHmiTvsIR3fCwjhQYdKqlPLaD6EWMx():
	Yw6S1bOqLcECfji7RJetgD = oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠨษ็็ฬฺ่๊้ࠠࠣำุๆࠡ็วๆฯࠦไๅ็฼่ํ๋วหࠢํืฯิฯๆ้ࠣห้ฮั็ษ่ะ๊ࠥฮำู่ࠣๆำวหࠢส่ส์สา่ํฮࠥ๎ั้ษห฻ࠥอไโ์า๎ํํวหࠢ็่ํ฻่ๅࠢศ่๏ํวࠡสึี฾ฯ้ࠠสา์๋ࠦล็ฬิ๊๏ะ้ࠠษ็ฬึ์วๆฮࠣ๎ู๊อ่ษࠣฮ้่วว์สࠤอ฿ฯࠡษ้ฮ์อมࠡ฻่ี์อ้ࠠลํฺฬูࠦ็ัࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤ࠳่่ࠦาสࠤฬ๊ศา่ส้ั๊ࠦิฬัำ๊ࠦำษ฻ฬࠤศ์่ศ฻่ࠣ฾๋ัࠡษ็็ฬฺࠠ࠻ࠩᾖ")
	Yw6S1bOqLcECfji7RJetgD += KKbpxUZnMcj6AJ4QdD(u"ࠩ࡟ࡲࡡࡴࠧᾗ") + yruHDQOcB97ig(u"ࠪ࠵࠳ࠦหศสอࠤ้๊ีโฯสฮࠥอไห์้ࠣ฾ื่โࠢฦ๊์อࠠๅษࠣฮฯเ๊า้๋ࠢฬฬ๊ศ๋้ࠢิะ็ࠡࠩᾘ") + str(NVbfv48oh3M6U/oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠼࠰੕")/oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠼࠰੕")/OyJ1o4AvmWlB75UkFRX(u"࠲࠵੖")/usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠴࠲੗")) + pcWq35MED2dtK(u"ฺࠫࠥ็าࠩᾙ")
	Yw6S1bOqLcECfji7RJetgD += M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠬࡢ࡮ࠨᾚ") + wwplD0tEehqH3kYQXs(u"࠭࠲࠯ࠢฯำฬࠦื้์็ࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ๅโำฺ๋ࠥษๆ่ษ่ࠣฬࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬᾛ") + str(we9acVgv5HE0mdlXCSj6n7DQ4/vvBChXmSty(u"࠸࠳੘")/vvBChXmSty(u"࠸࠳੘")/InKG0i2r6hHDvgd(u"࠵࠸ਖ਼")) + ggDRehOModi(u"ࠧࠡ์๋้ࠬᾜ")
	Yw6S1bOqLcECfji7RJetgD += cNaVb1vsT4qWOL0rpE(u"ࠨ࡞ࡱࠫᾝ") + InKG0i2r6hHDvgd(u"ࠩ࠶࠲ࠥ฽่๋ๆࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้ะ๊่ࠡสำึอࠠหฬ฽๎ึ่ࠦๆัอ๋ࠥ࠭ᾞ") + str(ebm0Z72CDaBzUq/CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠺࠵ਗ਼")/CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠺࠵ਗ਼")/qnPgZ9N15G6Oa8UpMASvLk(u"࠷࠺ਜ਼")) + tZ3gsrTEdzA1S6LXa9WI5px(u"ࠪࠤ๏๎ๅࠨᾟ")
	Yw6S1bOqLcECfji7RJetgD += vvBChXmSty(u"ࠫࡡࡴࠧᾠ") + yruHDQOcB97ig(u"ࠬ࠺࠮ࠡ็อ์ุ฽ࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎่ࠥฯࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧᾡ") + str(QQJtZ6rMvS1wdDsHnahT7/wwplD0tEehqH3kYQXs(u"࠼࠰ੜ")/wwplD0tEehqH3kYQXs(u"࠼࠰ੜ")) + Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠭ࠠิษ฼อࠬᾢ")
	Yw6S1bOqLcECfji7RJetgD += oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠧ࡝ࡰࠪᾣ") + usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠨ࠷࠱ࠤ็฻๊าࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠหฬ฽๎ึࠦฯศศ่หࠥ๎ๅะฬ๊ࠤࠬᾤ") + str(hs8IDEMn0YuCHwk/bbw2eajMlG(u"࠶࠱੝")/bbw2eajMlG(u"࠶࠱੝")) + oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠩࠣืฬ฿ษࠨᾥ")
	Yw6S1bOqLcECfji7RJetgD += n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠪࡠࡳ࠭ᾦ") + usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠫ࠻࠴ࠠอัสࠤ็฻๊าࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠหฬ฽๎ึࠦใฬ์ิหࠥ๎ๅะฬ๊ࠤࠬᾧ") + str(Iu3GUD84WyEqQjPFTYeh1SL9J/iifPEY9ABNzTQp(u"࠷࠲ਫ਼")) + yruHDQOcB97ig(u"ࠬࠦฯใ์ๅอࠬᾨ")
	Yw6S1bOqLcECfji7RJetgD += xuztI5QWEKG70CPNdhk4vo6(u"࠭࡜࡯ࠩᾩ") + ggDRehOModi(u"ࠧ࠸࠰ࠣฬิ๎ๆࠡๅสุ๊ࠥไึใะหฯࠦวๅฬํࠤฯะฺ๋ำࠣฬุืูส๋้ࠢิะ็ࠡࠩᾪ") + str(a2VuAbpQkGfMwSIcsP1XH6mletyzx) + BGhdkWsEvJjiMFTr3NLn1flU(u"ࠨࠢาๆ๏่ษࠨᾫ")
	Yw6S1bOqLcECfji7RJetgD += oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠩ࡟ࡲࡡࡴࠧᾬ") + qnPgZ9N15G6Oa8UpMASvLk(u"้ࠪะ๊ว࠻ุࠢๅาอสࠡไ๋หห๋ࠠศๆฦๅ้อๅ๊ࠡสู่๊ไิๆสฮࠥ๎วๅฯ็ๆฬะฺࠠ็ิ๋ฬࠦࠧᾭ") + str(QQJtZ6rMvS1wdDsHnahT7/KKbpxUZnMcj6AJ4QdD(u"࠸࠳੟")/KKbpxUZnMcj6AJ4QdD(u"࠸࠳੟")) + Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ูࠫࠥวฺหࠣ࠲ࠥษๅศࠢๅ์ฬฬๅࠡล้์ฬ฿ࠠศๆไ๎ิ๐่่ษอࠤๆ฿ๅา้สࠤࠬᾮ") + str(ebm0Z72CDaBzUq/KKbpxUZnMcj6AJ4QdD(u"࠸࠳੟")/KKbpxUZnMcj6AJ4QdD(u"࠸࠳੟")/xuztI5QWEKG70CPNdhk4vo6(u"࠵࠸੠")) + PtXn0k9G3ocHRg(u"ࠬࠦร๋ษ่ࠤ࠳ࠦรๆษ้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣๅ฾๋ั่ษࠣࠫᾯ") + str(hs8IDEMn0YuCHwk/KKbpxUZnMcj6AJ4QdD(u"࠸࠳੟")/KKbpxUZnMcj6AJ4QdD(u"࠸࠳੟")) + CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠭ࠠิษ฼อࠥ็โุࠢ࠱ࠤศ๋วࠡใะูࠥืโๆࠢส่ส฻ฯศำࠣๅ฾๋ั่ࠢࠪᾰ") + str(Iu3GUD84WyEqQjPFTYeh1SL9J/KKbpxUZnMcj6AJ4QdD(u"࠸࠳੟")) + bbw2eajMlG(u"ࠧࠡัๅ๎็ฯࠠ࠯ࠢฦ้ฬࠦแฮืࠣหูะัศๅࠣไࡎࡖࡔࡗࠢไ฽๊ื็ࠡࠩᾱ") + str(a2VuAbpQkGfMwSIcsP1XH6mletyzx) + XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠨࠢาๆ๏่ษࠨᾲ")
	RZo7IGjqXfiAnrWtlHcbNDuF9hP(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠩࡵ࡭࡬࡮ࡴࠨᾳ"),drHLAY5ENQFe2q9ptKGabo(u"้ࠪฬࠦ็้ࠢส่่อิࠡษ็ุ้ะฮะ็ࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨᾴ"),Yw6S1bOqLcECfji7RJetgD,JLoPRXt93dpAB(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ᾵"))
	return
def CDUkvJQISBTZ0Rre():
	MLPwxur5kaYlBtqcn = vvBChXmSty(u"ࠬอไโษุ่ฮࠦสฺ่ํࠤ๊าไะࠢห๊ๆูࠠศี่๋ࠥอไฤื็๎ࠥ๎วๅ่ๅ฻ฮࠦสฺ่ํࠤศ์ࠠศๆสื๊ࠦวๅลุ่๏ࠦสๆࠢอ฽ิ๐ไ่๋ࠢๅฬ฻ไส๋๊ࠢ็฽ษࠡฬ฼๊๎ࠦๅอๆาࠤํะๅࠡฬ฼ำ๏๊ࠠศี่๋ࠥ๎ศะ๊้ࠤ฾๊วๆหࠣฮ฾์๊ࠡ็็ๅࠥฮๆโีࠣหุ๋็ࠡษ็วฺ๊๊ࠨᾶ")
	xl9MFt1AmY0GrkENug8n(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠭ࠧᾷ"),cgtRBdXxSOk7WUfyDhPCls(u"ࠧࠨᾸ"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᾹ"),MLPwxur5kaYlBtqcn)
	return
def O8AdHNs6l3Ut9v():
	MLPwxur5kaYlBtqcn = XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠩศิฬ่ࠦศฮ๊ฮ่ࠦๅีๅ็อࠥ็๊ࠡษ็ุอ้ษ๊ࠡอ้ࠥำไ่ษࠣ࠲࠳࠴ࠠฤ๊ࠣห๋้ࠠหฺ้ࠤศ์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠไษ้ࠤๆ๐็ࠡ็ื็้ฯࠠๆฦๅฮ์่ࠦห็ࠣั้ํวࠡ࠰࠱࠲ࠥ็ลั่ࠣะึฮࠠๆีะࠤ่อิࠡษ็ฬึ์วๆฮ่่ࠣ๐๋ࠠไ๋้ࠥอไษำ้ห๊าࠠษู็ฬࠥอไึใะอࠥอไึฯํัฮ่ࠦหะี๎๋ํวࠡสา่ฬࠦๅ็ࠢสฺ่็อสࠢส่็ี๊ๆหࠪᾺ")
	xl9MFt1AmY0GrkENug8n(bcgZJWV6UeNSkRA(u"ࠪࠫΆ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠫࠬᾼ"),ggDRehOModi(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ᾽"),MLPwxur5kaYlBtqcn)
	return
def TY3cHO0GawUDZk2usA():
	MLPwxur5kaYlBtqcn = M6PIj8gl1fno7wcqTksDEBK4bU(u"࠭วๅ฼ิฺ๋ࠥๆࠡึ๊หิฯࠠศๆอุๆ๐ั้๋ࠡࠤ฻๋ว็ุࠢัฮ่ࠦิำํอࠥอไๆ฻็์๊อสࠡษ็้ฯฮวะๆฬࠤอ๐ๆࠡษ็ฬึ์วๆฮࠣ์ฬ๊ๅ้ไ฼ࠤฬ๊ๅีใิࠤํํะศࠢส่฻๋ว็ࠢ฽๎ึࠦๅุๆ๋ฬࠥ๎ไศࠢะหัฯࠠๅ้ࠣ฽๋ีࠠศๆสฮฺอไࠡษ๋ࠤฬ๊ัษู้ࠣ฾ࠦๅ้ษๅ฽ࠥอไโ์า๎ํํวหࠢสฺ่๊แาหࠪι")
	xl9MFt1AmY0GrkENug8n(BGhdkWsEvJjiMFTr3NLn1flU(u"ࠧࠨ᾿"),xuztI5QWEKG70CPNdhk4vo6(u"ࠨࠩ῀"),wwplD0tEehqH3kYQXs(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ῁"),MLPwxur5kaYlBtqcn)
	return
def FmM63fBtsoXaK5Ukn():
	xl9MFt1AmY0GrkENug8n(bcgZJWV6UeNSkRA(u"ࠪࠫῂ"),OyJ1o4AvmWlB75UkFRX(u"ࠫࠬῃ"),iifPEY9ABNzTQp(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨῄ"),bbw2eajMlG(u"࠭ไไ์ࠣ๎฾๋ไ้ࠡำหࠥอไ็๊฼ࠤ๊์ࠠศๆไ๎ิ๐่่ษอࠤࡡࡴ๋ࠠฮหࠤฯ็ู๋ๆࠣษ฻อแสࠢสื๊ํวࠡ࡞ࡱࠤ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫ῅"))
	tj2FJQMlTw(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧῆ"),tZ3gsrTEdzA1S6LXa9WI5px(u"࡚ࡲࡶࡧ઩"))
	return
def YSWxU2DjBTgNfOR85qECJlzopQh():
	MLPwxur5kaYlBtqcn  = cNaVb1vsT4qWOL0rpE(u"ࠨ็วาึอࠠใษ่ฮࠥฮูืࠢืี่อสࠡษ็ษ๋ะั็ฬࠣห้ี่ๅ์ࠣฬํ฼ูࠡ฻สส็ࠦึะࠢส่อืวๆฮ้ࠣะ๊ࠠไ๊า๎๊ࠥสิ็ะࠤๆ่ืࠡๆห฽฻ࠦๅิฬัำ๊๐ࠠศๆ่ฮฺ็อࠡสส่ิิ่ๅࠢ็้ํอโฺࠢส่ๆ๐ฯ๋๊ࠪῇ")
	MLPwxur5kaYlBtqcn += nKLEi8CJumazx4qT(u"ࠩࠣ์๋ะ๊อห่ࠣ์ึวࠡษ็฽ฬฬโࠡใส๊์ࠦสใำํฬฬࠦฬๆ์฼ࠤู๊สฯั่๎ࠥฮั็ษ่ะ้่ࠥะ์่ࠣฬ๊ࠦิฬฺ๎฾๎ๆࠡษ็ำำ๎ไࠡๆฯ้๏฿ࠠๆ๊สๆ฾ࠦวๅสิ๊ฬ๋ฬࠡฯอํู๋ࠥࠡษึฮำีวๆࠩῈ")
	MLPwxur5kaYlBtqcn += xuztI5QWEKG70CPNdhk4vo6(u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝แ࡚ࠢࠣࡕࡔࠠࠡล๋ࠤࠥࡖࡲࡰࡺࡼࠤࠥษ่ࠡࠢࡇࡒࡘࠦࠠฤ๊ࠣว๏ࠦอๅࠢหื๏฽ࠠระิ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴࠧΈ")
	MLPwxur5kaYlBtqcn += bcgZJWV6UeNSkRA(u"ࠫࡡࡴไศ่๋ࠣีอࠠๅ่ࠣ๎า๊ࠠศๆุ่่๊ษ๊ࠡศ๊๊อࠠโไฺࠤุ๐โ้็ࠣฬส฻ไศฯࠣฬ฾฼ࠠศๆ่์ฬู่๊ࠡศ฽ฬ่ษࠡ็๋ห็฿ࠠศะิํ้ࠥว็ฬࠣฮ฾๋ไࠡีสฬ็อࠠษั๋๊๋ࠥิศๅ็ࠫῊ")
	RZo7IGjqXfiAnrWtlHcbNDuF9hP(ggDRehOModi(u"ࠬࡸࡩࡨࡪࡷࠫΉ"),InKG0i2r6hHDvgd(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩῌ"),MLPwxur5kaYlBtqcn,drHLAY5ENQFe2q9ptKGabo(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ῍"))
	MLPwxur5kaYlBtqcn = iifPEY9ABNzTQp(u"ࠨษ็้ํอโฺࠢส่ฯ๐ࠠหลฮีฯࠦศศๆ฼หหฺ่่ࠠาࠤอ฿ึࠡษ็๊ฬู่ࠠ์࠽ࠫ῎")
	MLPwxur5kaYlBtqcn += PtXn0k9G3ocHRg(u"ࠩ࡟ࡲࠬ῏")+BGhdkWsEvJjiMFTr3NLn1flU(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡧ࡫ࡰࡣࡰࠤࠥ࡫ࡧࡺࡤࡨࡷࡹࠦࠠࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠤࠥࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤࠡࠢࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨࠡࠢࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸ࡟࠴ࡉࡏࡍࡑࡕࡡࠬῐ")
	MLPwxur5kaYlBtqcn += r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠫࡡࡴ࡜࡯ࠩῑ")+wwplD0tEehqH3kYQXs(u"ࠬอไะ๊็ࠤฬ๊ส๋ࠢอวะืสࠡสส่฾อฦใࠢ฼๊ิࠦศฺุࠣห้์วิ๊ࠢ๎࠿࠭ῒ")
	MLPwxur5kaYlBtqcn += drHLAY5ENQFe2q9ptKGabo(u"࠭࡜࡯ࠩΐ")+XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ู่ึࠦࠠศๆๆ์๏ะࠠࠡล่๎ึ้วࠡࠢๆ๊ิอࠠࠡใิุ๊อࠠࠡษ็๎ํ์ว็ࠢࠣฬึ๐ืศ่ํหࠥอไฦ็สีฬะࠠฤๆ่ห๋๐วࠡำ๋ื๏อࠠศๆํหออๆࠡษ็ื฾๎ฯ๋หࠣีํ๋ว็์สࠤ์๎ไ็ัส࡟࠴ࡉࡏࡍࡑࡕࡡࠬ῔")
	MLPwxur5kaYlBtqcn += tZ3gsrTEdzA1S6LXa9WI5px(u"ࠨ࡞ࡱࡠࡳ࠭῕")+usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩส่๊ฮัๆฮࠣ์ัีุࠠำํๆฮࠦไหฮส์ืࠦวๅ฻สส็่ࠦๅๅ้๋ฬࠦสฮฬสะࠥา็ะࠢๆฬ๏ื้ࠠษ็้อืๅอࠢํ฼๋ࠦวๅ็ื็้ฯࠠึ฼ํีฮ่ࠦๅษࠣฮุะอใࠢส่ฯ฿ศࠡใศิฬࠦไะ์ๆࠤฺ๊ใๅหࠣฬฬ๊ฯฯ๊็ࠤ้ฮูืࠢส่๊๎วใ฻ࠣ์ศ๐ึศࠢ็็๏๊ࠦหุะࠤาาๅࠡษ็ู้้ไสࠢࠪῖ")
	MLPwxur5kaYlBtqcn += ggDRehOModi(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢอัิๆࠣีุอไส่ࠢศิฮษࠡว็ํࠥอไๆสิ้ั่ࠦศๅอฬࠥ็๊่ษࠣหุ๋ࠠษๆา็ࠥ๎ริ็สลࠥอไๆ๊สๆ฾ࠦวๅฬํࠤ้อࠠหีอ฻๏฿ࠠะะ๋่์อ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨῗ")
	RZo7IGjqXfiAnrWtlHcbNDuF9hP(qnPgZ9N15G6Oa8UpMASvLk(u"ࠫࡷ࡯ࡧࡩࡶࠪῘ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨῙ"),MLPwxur5kaYlBtqcn,ggDRehOModi(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩῚ"))
	return
def Tr6zPEU3LKyNRw59VqsMZjn():
	xl9MFt1AmY0GrkENug8n(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠧࠨΊ"),vvBChXmSty(u"ࠨࠩ῜"),OyJ1o4AvmWlB75UkFRX(u"ࠩฮ่ฬัุࠠำๅࠤ้๊ส้ษุู่๋ࠥࠡษ็้อืๅอࠩ῝"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠪวึูไࠡำึห้ฯࠠฤู๊้้ࠣไส่๊่ࠢࠥวว็ฬࠤำีๅศฬ๋ࠣีอࠠศๆหี๋อๅอ࡞ࡱࡠࡳษ่ࠡสสืฯิฯศ็ࠣห้็๊ิส๋็ࠥษฯ็ษ๊ࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡩࡶࡷࡴ࠿࠵࠯ࡧࡣࡦࡩࡧࡵ࡯࡬࠰ࡦࡳࡲ࠵ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠷࠶࠱࠹࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࡡࡴร้ࠢหหึูวๅࠢส๎๊๐ไࠡษ็ํࠥษฯ็ษ๊ࠤࠥࡢ࡮ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠴࠳࠵࠽ࡆࡧ࡮ࡣ࡬ࡰ࠳ࡩ࡯࡮࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ῞"))
	return
def NVtHZIkPqR61():
	ZHmiTvsIR3fCwjhQYdKqlPLaD6EWMx()
	iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ῟"),ggDRehOModi(u"ࠬ࠭ῠ"),bbw2eajMlG(u"࠭ࠧῡ"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"่ࠧๆࠣฮึ๐ฯࠡ็ึัࠥาๅ๋฻ࠣห้้วีࠢยࠫῢ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠨษ็็ฬฺ๋ࠠีิ฽ࠥ฿ๅๅࠢส่อืๆศ็ฯࠤํ๋ำฮ้ࠣ๎฾๐ฯࠡีะฬࠥอไึใะหฯࠦๅ็ࠢส่ส์สา่อࠤ฾์ฯࠡษ็ัฬาษࠡว็๎์อ้ࠠษ็ุ้ำ๋ࠠฬ่ࠤฯ๊โศศํหࠥ฿ๆะࠢส๊ฯํวยࠢ฼้ึࠦวๅืไัฬะ้ࠠษ็ุ้ำࠠๅษࠣ๎฻ื้ࠠ็่็๋๊ࠦฮๆࠣฬ฾฼ࠠศๆุ่ฬ้ไࠨΰ"))
	if iZL6cN3OkM5==ggDRehOModi(u"࠵੡"):
		Ng2cPah6pJKD3YTjFX0lyfVbs5(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࡔࡳࡷࡨપ"))
		xl9MFt1AmY0GrkENug8n(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠩࠪῤ"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠪࠫῥ"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠫฯ๋ࠠๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠣฬฬ๊ใศ็็ࠫῦ"),OyJ1o4AvmWlB75UkFRX(u"ࠬหะศࠢๆห๋ะฺ่ࠠา็๋ࠥิไๆฬࠤๆ๐ࠠศฯาࠤฬ๊ๅ้ษๅ฽ࠥ็ฬาสࠣห้๋่ใ฻ࠣห้ศๆࠡ࠰࠱࠲ࠥ๎รัษࠣห้๋ิไๆฬࠤู๊สๆำฬࠤๆหะ็ࠢสีุ๊ࠠศๆุ่่๊ษࠡว็ํࠥอไๆสิ้ั࠭ῧ"))
	return iZL6cN3OkM5
def gYUJEp5XQMGC0PjLTdO7BV(showDialogs=OyJ1o4AvmWlB75UkFRX(u"ࡕࡴࡸࡩફ")):
	if not showDialogs: showDialogs = XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࡖࡵࡹࡪબ")
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,wwplD0tEehqH3kYQXs(u"࠭ࡇࡆࡖࠪῨ"),yruHDQOcB97ig(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡻࡥࡲࡶ࡬ࡦ࠰ࡦࡳࡲ࠭Ῡ"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠨࠩῪ"),yruHDQOcB97ig(u"ࠩࠪΎ"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࡉࡥࡱࡹࡥભ"),Tgoa16jMxvYX2(u"ࠪࠫῬ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡈࡕࡖࡓࡗࡤ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧ῭"))
	if not RoQL91PphqCJg4W0e6Fnsl.succeeded:
		LgcDTWSnH0OZblCw78dEsr3GVAox = qnPgZ9N15G6Oa8UpMASvLk(u"ࡊࡦࡲࡳࡦમ")
		HjxmCcWZQhX8zaJNUvsg5yGib0P = eoblnvIyaChYrkj()
		l0SAerv8zGH2Wa(yF29Xdsx35wI07Ce4(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ΅"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+cNaVb1vsT4qWOL0rpE(u"࠭ࠠࠡࠢࡋࡘ࡙ࡖࡓࠡࡈࡤ࡭ࡱ࡫ࡤࠡࠢࠣࡐࡦࡨࡥ࡭࠼࡞ࠫ`")+HjxmCcWZQhX8zaJNUvsg5yGib0P+Tgoa16jMxvYX2(u"ࠧ࡞ࠩ῰"))
		if showDialogs: xl9MFt1AmY0GrkENug8n(cNaVb1vsT4qWOL0rpE(u"ࠨࠩ῱"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠩࠪῲ"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ῳ"),Tgoa16jMxvYX2(u"ࠫๆำีࠡษ็หฯ฻วๅࠢสฺ่๊แาࠢ࠱࠲࠳ࠦๅีๅ็อࠥ࠴࠮࠯ࠢส่ฬะีศๆࠣห้๋ิโำࠣࠬฬ๊ัษูࠣห้๋ิโำࠬࠤ้อ๋ࠠ฻่่ࠥ฿ๆะๅࠣ฽้๏ࠠไ๊า๎ࠥ࠴࠮࠯๋ࠢ฽๋ีใࠡๅ๋ำ๏ฺ๋ࠦำࠣๆฬีัࠡ฻็ํࠥอำหะาห๊ࠦวๅ็๋ห็฿ࠠศๆุ่ๆืษࠨῴ"))
	else:
		LgcDTWSnH0OZblCw78dEsr3GVAox = usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࡙ࡸࡵࡦય")
		if showDialogs: xl9MFt1AmY0GrkENug8n(pcWq35MED2dtK(u"ࠬ࠭῵"),shZ9eOcN2dJnPj(u"࠭ࠧῶ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪῷ"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠨฮํำࠥาฯศࠢ࠱࠲࠳ࠦวๅษอูฬ๊ࠠศๆุ่ๆืࠠࠩษ็ีอ฽ࠠศๆุ่ๆืࠩࠡ์฼ู้้ࠦ็ัๆࠤํอไษำ้ห๊าࠠใษาีࠥ฿ไ๊ࠢสืฯิฯศ็ࠣห้๋่ศไ฼ࠤฬ๊ๅีใิอࠬῸ"))
	if not LgcDTWSnH0OZblCw78dEsr3GVAox and showDialogs: ENPz63e52B()
	return LgcDTWSnH0OZblCw78dEsr3GVAox
def ENPz63e52B():
	xl9MFt1AmY0GrkENug8n(cgtRBdXxSOk7WUfyDhPCls(u"ࠩࠪΌ"),Tgoa16jMxvYX2(u"ࠪࠫῺ"),PtXn0k9G3ocHRg(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧΏ"),OyJ1o4AvmWlB75UkFRX(u"ࠬฮูืࠢส่๊๎วใ฻ࠣฮาะวอࠢิฬ฼ࠦๅีใิࠤํ่ฯࠡ์ๆ์๋ࠦฬ่ษี็ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬ๊ัษูࠣห้๋ิโำࠣวํࠦ็็ษๆࠤฺ๊ใๅหࠣๅ๏ࠦิ่ษาอࠥอไหึไ๎ึࠦวๅะสูฮࠦศไ๊า๎ࠥ฿ๆะๅࠣ฽้๋วࠡษ้๋ࠥะๅࠡใะูࠥอไษำ้ห๊าฺࠠๆ์ࠤ่๎ฯ๋ࠢส่ส฻ฯศำสฮࠥࡢ࡮ࠡ࠳࠺࠲࠻ࠦࠠࠧࠢࠣ࠵࠽࠴࡛࠱࠯࠼ࡡࠥࠦࠦࠡࠢ࠴࠽࠳ࡡ࠰࠮࠵ࡠࠫῼ"))
	Ct2ZlYo9qO6BKJLzAVxGd84Mc()
	return
def V23iQNjwDUgHl9SFO6h8kbeY(kc57B93HrojbDIXVipY=wwplD0tEehqH3kYQXs(u"࠭ࠧ´")):
	LLvAUFN4fXhlZ = tZ3gsrTEdzA1S6LXa9WI5px(u"࡚ࡲࡶࡧર")
	if M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࠪ῾") not in kc57B93HrojbDIXVipY:
		LLvAUFN4fXhlZ = Tgoa16jMxvYX2(u"ࡆࡢ࡮ࡶࡩ઱")
		aZ06RtK7TfOop52BJg4 = lRwnVNxCZXGgkqd390(shZ9eOcN2dJnPj(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ῿"),bcgZJWV6UeNSkRA(u"ࠫำื่อࠩࠀ"),KKbpxUZnMcj6AJ4QdD(u"ࠬหัิษ็ࠤฺ๊ใๅหࠪࠁ"),cNaVb1vsT4qWOL0rpE(u"࠭ลาีส่ࠥืำศๆฬࠫࠂ"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࠃ"),Tgoa16jMxvYX2(u"ࠨ้็ࠤฯื๊ะࠢฦ๊ࠥะัิๆࠣีุอไสࠢศ่๎ࠦวๅ็หี๊าࠠ࠯࠰ࠣว๊ࠦสา์าࠤศ์ࠠหำึ่๋ࠥิไๆฬࠤ๊๎ฬ้ัฬࠤๆ๐ࠠศๆหี๋อๅอࠢยࠫࠄ"))
		if aZ06RtK7TfOop52BJg4 in [-ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠶੢"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠶੣")]: return
		elif aZ06RtK7TfOop52BJg4==ggDRehOModi(u"࠱੤"):
			LLvAUFN4fXhlZ = KKbpxUZnMcj6AJ4QdD(u"ࡕࡴࡸࡩલ")
			kc57B93HrojbDIXVipY = usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬࠅ")
	if LLvAUFN4fXhlZ:
		if XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤࡕࡌࡅࡡࠪࠆ") not in kc57B93HrojbDIXVipY:
			iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(pcWq35MED2dtK(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫࠇ"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠬ࠭ࠈ"),shZ9eOcN2dJnPj(u"࠭ࠧࠉ"),yruHDQOcB97ig(u"ุ้ࠧ฼ࠤฬ๊ๅีๅ็อࠥ็๊ࠡษ็ืั๊ࠧࠊ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠨไห่ࠥหัิษ็ࠤฬ๊ำอๆࠣ฽้๐ใࠡล้ࠤฯ้ัา๊ࠢࠣๆูࠠศๆไ฽้ࠦวๅาํࠤศ฿ืศๅࠣห้๋ิไๆฬࠤ࠳ࠦไไ์ࠣ๎ฯ๋ࠠหีฯ๎้ࠦ็ั้ࠣห้๋ิไๆฬࠤๆ๐ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢ࠱ࠤํฮฯ้่๋ࠣีอࠠศๆอืั๐ไࠡี๋ๅࠥะัิๆ้้ࠣ็ࠠๅษࠣๅฬฬฯส่๊ࠢ์ࠦไฦ่๊ࠤ้อ๋ࠠฯอ์๏ูࠦๅ๋ࠣห้๋ิไๆฬࠤฬ๊ส๋ࠢอี๏ีࠠศ่อࠤฬ๊ลษๆส฾ࠥ฿ๆ่ษࠣ࠲ࠥํไࠡไ่ฮࠥฮสไำสีࠥอไๆึๆ่ฮࠦฟࠨࠋ"))
			if iZL6cN3OkM5!=xuztI5QWEKG70CPNdhk4vo6(u"࠲੥"):
				xl9MFt1AmY0GrkENug8n(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠩࠪࠌ"),cgtRBdXxSOk7WUfyDhPCls(u"ࠪࠫࠍ"),wwplD0tEehqH3kYQXs(u"ࠫฯ๋ࠠฦๆ฽หฦࠦวๅวิืฬ๊ࠧࠎ"),Tgoa16jMxvYX2(u"๊ࠬไฤีไࠤอี่็ࠢอืั๐ไࠡษ็ู้้ไสࠢไ๎ูࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠโษ้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์ึฮ฼๐ูࠡ็฼ีๆฯࠠศๆุ่่๊ษ๊ࠡ็หࠥำไ่ษ่ࠣฬ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศࠨࠏ"))
				return
	xl9MFt1AmY0GrkENug8n(OyJ1o4AvmWlB75UkFRX(u"࠭ࠧࠐ"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࠧࠨࠑ"),InKG0i2r6hHDvgd(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࠒ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠩไ๎ࠥอไีษือࠥอไใษา้ฮࠦอศ๊็ࠤศ์ࠠหๅอฬࠥืำศๆฬࠤส๊้ࠡษ็้อืๅอ๋ࠢหูือࠡใํ๋ฬࠦวๅ็ื็้ฯࠠฤ๊ࠣห้๋่ื๊฼ࠤํหะศࠢฦีิะࠠอ๊สฬ๋ࠥๆࠡษ็้อืๅอࠢไษี์ࠠฤๅอฬࠥ฿ๆ้ษ้ࠤอื๊ะๅࠣว้หไไฬิ์๋๐ࠠศๆศ๎๊๐ไ๊ࠡอิ่ื้ࠠๆสࠤฯ์ำ๊ࠢฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ࠭ࠓ"))
	search = FBrXsYeCEp3(header=qnPgZ9N15G6Oa8UpMASvLk(u"࡛ࠪࡷ࡯ࡴࡦࠢࡤࠤࡲ࡫ࡳࡴࡣࡪࡩࡪࠦࠠࠡษๆฮอࠦัิษ็อࠬࠔ"),source=aUVSgO2ebjwX5iqPykC)
	if not search: return
	MLPwxur5kaYlBtqcn = search
	if LLvAUFN4fXhlZ: type = xuztI5QWEKG70CPNdhk4vo6(u"ࠫࡕࡸ࡯ࡣ࡮ࡨࡱࠬࠕ")
	else: type = yruHDQOcB97ig(u"ࠬࡓࡥࡴࡵࡤ࡫ࡪ࠭ࠖ")
	V5VXz0j3oa6t = X2XWUFPVMDugaGkehc4EYlp(type,MLPwxur5kaYlBtqcn,drHLAY5ENQFe2q9ptKGabo(u"ࡖࡵࡹࡪળ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠭ࠧࠗ"),vvBChXmSty(u"ࠧࡆࡏࡄࡍࡑ࠳ࡆࡓࡑࡐ࠱࡚࡙ࡅࡓࡕࠪ࠘"),kc57B93HrojbDIXVipY)
	return
def rNIXLajxonpFeP():
	kc57B93HrojbDIXVipY = ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠨ้ำหࠥอไษำ้ห๊าࠠๅษࠣ๎ําฯࠡๆ๊ࠤศ๐ࠠิ์ิๅึ๊ࠦิฬู๎ๆࠦร๋่ࠢัฯ๎๊ศฬ࠱ࠤฬ๊ศา่ส้ั๊ࠦิฬัำ๊ࠦั้ษห฻ࠥ๎สื็ํ๊๊ࠥๅฮฬ๋๎ฬะࠠๆำไ์฾ฯฺࠠๆ์ࠤุ๐ัโำสฮࠥิวาฮํอ࠳ࠦวๅสิ๊ฬ๋ฬࠡ฼ํี๋ࠥำล๊็ࠤ฾์ࠠฤ์้ࠣาะ่๋ษอࠤฯ๋ࠠหฯ่๎้ํวࠡ฻็ํู๊ࠥาใิหฯ่ࠦๆ๊สๆ฾ࠦฮศำฯ๎ฮࠦࠢๆ๊สๆ฾ࠦืาใࠣฯฬ๊หࠣ࠰ࠣะ๊๐ูࠡษ็วุ๋วย๋ࠢห้๋วาๅสฮࠥ๎วๅื๋ีࠥ๎วๅ็ุ้ํืวห๊ࠢ๎ࠥิวึหࠣฬฬ฻อศส๊ห࠳ࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏์ส่ๅࠣั็๎โࠡษ็฻อ฿้ࠠษ็ู๊ื้ࠠไส๊ํ์ࠠศๆฦ่ๆ๐ษࠡๆ็้้้๊สࠢส่ึ่ๅ๋หࠣࡈࡒࡉࡁࠡวำห้ࠥว็ࠢ็ำ๏้ࠠีๅ๋ํࠥิวึหࠣฬฬ๊ั้ษห฻ࠥ๎วๅฬูห๊๐ๆࠡษ็าฬืฬ๋หࠣๅฬ๊ัอษฤࠤฬ๊ส้ษุู่๋ࠥࠡวาหึฯ่ࠠา๊ࠤฬ๊ำ๋ำไีฬะ้ࠠษ็้ํอโฺࠢส่ำอัอ์ฬ࠲ࠥํะศࠢส่อืๆศ็ฯࠤ์๎ࠠษสึห฼ฯࠠๆฬุๅาࠦไๆ๊สๆ฾ࠦวๅ๊ํฬࠬ࠙")
	RZo7IGjqXfiAnrWtlHcbNDuF9hP(wwplD0tEehqH3kYQXs(u"ࠩࡵ࡭࡬࡮ࡴࠨࠚ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠪั็๎โࠡษ็฻อ฿้ࠠษ็ู๊ื้ࠠไส๊ํ์ࠠศๆฦ่ๆ๐ษࠡๆ็้้้๊สࠢส่ึ่ๅ๋หࠪࠛ"),kc57B93HrojbDIXVipY,ggDRehOModi(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧࠜ"))
	kc57B93HrojbDIXVipY = BGhdkWsEvJjiMFTr3NLn1flU(u"࡚ࠬࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤࡩࡵࡥࡴࠢࡱࡳࡹࠦࡨࡰࡵࡷࠤࡦࡴࡹࠡࡥࡲࡲࡹ࡫࡮ࡵࠢࡲࡲࠥࡧ࡮ࡺࠢࡶࡩࡷࡼࡥࡳ࠰ࠣࡍࡹࠦ࡯࡯࡮ࡼࠤࡺࡹࡥࡴࠢ࡯࡭ࡳࡱࡳࠡࡶࡲࠤࡪࡳࡢࡦࡦࡧࡩࡩࠦࡣࡰࡰࡷࡩࡳࡺࠠࡵࡪࡤࡸࠥࡽࡡࡴࠢࡸࡴࡱࡵࡡࡥࡧࡧࠤࡹࡵࠠࡱࡱࡳࡹࡱࡧࡲࠡࡱࡱࡰ࡮ࡴࡥࠡࡸ࡬ࡨࡪࡵࠠࡩࡱࡶࡸ࡮ࡴࡧࠡࡵ࡬ࡸࡪࡹ࠮ࠡࡃ࡯ࡰࠥࡺࡲࡢࡦࡨࡱࡦࡸ࡫ࡴ࠮ࠣࡺ࡮ࡪࡥࡰࡵ࠯ࠤࡹࡸࡡࡥࡧࠣࡲࡦࡳࡥࡴ࠮ࠣࡷࡪࡸࡶࡪࡥࡨࠤࡲࡧࡲ࡬ࡵ࠯ࠤࡨࡵࡰࡺࡴ࡬࡫࡭ࡺࡥࡥࠢࡺࡳࡷࡱࠬࠡ࡮ࡲ࡫ࡴࡹࠠࡳࡧࡩࡩࡷ࡫࡮ࡤࡧࡧࠤ࡭࡫ࡲࡦ࡫ࡱࠤࡧ࡫࡬ࡰࡰࡪࠤࡹࡵࠠࡵࡪࡨ࡭ࡷࠦࡲࡦࡵࡳࡩࡨࡺࡩࡷࡧࠣࡳࡼࡴࡥࡳࡵࠣ࠳ࠥࡩ࡯࡮ࡲࡤࡲ࡮࡫ࡳ࠯ࠢࡗ࡬ࡪࠦࡰࡳࡱࡪࡶࡦࡳࠠࡪࡵࠣࡲࡴࡺࠠࡳࡧࡶࡴࡴࡴࡳࡪࡤ࡯ࡩࠥ࡬࡯ࡳࠢࡺ࡬ࡦࡺࠠࡰࡶ࡫ࡩࡷࠦࡰࡦࡱࡳࡰࡪࠦࡵࡱ࡮ࡲࡥࡩࠦࡴࡰࠢ࠶ࡶࡩࠦࡰࡢࡴࡷࡽࠥࡹࡩࡵࡧࡶ࠲ࠥ࡝ࡥࠡࡷࡵ࡫ࡪࠦࡡ࡭࡮ࠣࡧࡴࡶࡹࡳ࡫ࡪ࡬ࡹࠦ࡯ࡸࡰࡨࡶࡸ࠲ࠠࡵࡱࠣࡶࡪࡩ࡯ࡨࡰ࡬ࡾࡪࠦࡴࡩࡣࡷࠤࡹ࡮ࡥࠡ࡮࡬ࡲࡰࡹࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡦࠣࡻ࡮ࡺࡨࡪࡰࠣࡸ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢࡤࡶࡪࠦ࡬ࡰࡥࡤࡸࡪࡪࠠࡴࡱࡰࡩࡼ࡮ࡥࡳࡧࠣࡩࡱࡹࡥࠡࡱࡱࠤࡹ࡮ࡥࠡࡹࡨࡦࠥࡵࡲࠡࡸ࡬ࡨࡪࡵࠠࡦ࡯ࡥࡩࡩࡪࡥࡥࠢࡤࡶࡪࠦࡦࡳࡱࡰࠤࡴࡺࡨࡦࡴࠣࡺࡦࡸࡩࡰࡷࡶࠤࡸ࡯ࡴࡦࡵ࠱ࠤࡎ࡬ࠠࡺࡱࡸࠤ࡭ࡧࡶࡦࠢࡤࡲࡾࠦ࡬ࡦࡩࡤࡰࠥ࡯ࡳࡴࡷࡨࡷࠥࡶ࡬ࡦࡣࡶࡩࠥࡩ࡯࡯ࡶࡤࡧࡹࠦࡡࡱࡲࡵࡳࡵࡸࡩࡢࡶࡨࠤࡲ࡫ࡤࡪࡣࠣࡪ࡮ࡲࡥࠡࡱࡺࡲࡪࡸࡳࠡ࠱ࠣ࡬ࡴࡹࡴࡦࡴࡶ࠲࡚ࠥࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤ࡮ࡹࠠࡴ࡫ࡰࡴࡱࡿࠠࡢࠢࡺࡩࡧࠦࡢࡳࡱࡺࡷࡪࡸ࠮ࠨࠝ")
	RZo7IGjqXfiAnrWtlHcbNDuF9hP(bbw2eajMlG(u"࠭࡬ࡦࡨࡷࠫࠞ"),drHLAY5ENQFe2q9ptKGabo(u"ࠧࡅ࡫ࡪ࡭ࡹࡧ࡬ࠡࡏ࡬ࡰࡱ࡫࡮࡯࡫ࡸࡱࠥࡉ࡯ࡱࡻࡵ࡭࡬࡮ࡴࠡࡃࡦࡸࠥ࠮ࡄࡎࡅࡄ࠭ࠬࠟ"),kc57B93HrojbDIXVipY,ggDRehOModi(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫࠠ"))
	return
def Na4XIJeuf7LRYBcK21TMs6QVz(lY0rst72uGVZ1NkgvpjfA6x):
	FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy = bMIascyFJ2x43E0C7glTB91h8qz.executeJSONRPC(yF29Xdsx35wI07Ce4(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬࠡ")+lY0rst72uGVZ1NkgvpjfA6x+ggDRehOModi(u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡨࡤࡰࡸ࡫ࡽࡾࠩࠢ"))
	hPvDUWG0xTNq6kC = r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࡗࡶࡺ࡫઴")
	if hPvDUWG0xTNq6kC:
		YVJPFvuI2CS5KObiZt.sleep(xuztI5QWEKG70CPNdhk4vo6(u"࠳੦"))
		bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࡚ࠫࡶࡤࡢࡶࡨࡐࡴࡩࡡ࡭ࡃࡧࡨࡴࡴࡳࠨࠣ"))
		YVJPFvuI2CS5KObiZt.sleep(pcWq35MED2dtK(u"࠴੧"))
	return
def rnsqFCN6VESDUPM2HXGobkQ7L9eO():
	xl9MFt1AmY0GrkENug8n(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠬ࠭ࠤ"),drHLAY5ENQFe2q9ptKGabo(u"࠭ࠧࠥ"),nKLEi8CJumazx4qT(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࠦ"),nKLEi8CJumazx4qT(u"ࠨษ็ฬึ์วๆฮ่ࠣฬ๊ࠦโฯุࠤูํวะหࠣห้ะิโ์ิࠤ฾์ฯࠡษ็หฯ฻วๅࠢหห้๋่ศไ฼ࠤฬ๊ๅีใิอࠥ๎ไ่าสࠤๆ๐ࠠฮษ็ࠤํา่ะࠢื๋ฬีษࠡ฼ํีࠥ฻อ๋ฯฬࠤศ๎ࠠๆ่อ๋๏ฯࠠศๆุ่ฬำ๊สࠢฦ์๋ࠥา๋ใฬࠤๆอๆ้ࠡำห๊ࠥๆࠡ์๋ๆๆࠦวๅำห฻ࠥอไๆึไีࠥ๎ไ็ࠢํ์็็ฺࠠ็็ࠤฬ๊ศา่ส้ั࠭ࠧ"))
	TY3cHO0GawUDZk2usA()
	return
def Ct2ZlYo9qO6BKJLzAVxGd84Mc():
	url = r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡰ࡭ࡷࡸ࡯ࡳࡵ࠱࡯ࡴࡪࡩ࠯ࡶࡹ࠳ࡷ࡫࡬ࡦࡣࡶࡩࡸ࠵ࡷࡪࡰࡧࡳࡼࡹ࠯ࡸ࡫ࡱ࠺࠹࠵ࠧࠨ")
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠪࡋࡊ࡚ࠧࠩ"),url,xuztI5QWEKG70CPNdhk4vo6(u"ࠫࠬࠪ"),cgtRBdXxSOk7WUfyDhPCls(u"ࠬ࠭ࠫ"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠭ࠧࠬ"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠧࠨ࠭"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡗࡍࡕࡗࡠࡎࡄࡘࡊ࡙ࡔࡠࡍࡒࡈࡎࡥࡖࡆࡔࡖࡍࡔࡔ࠭࠲ࡵࡷࠫ࠮"))
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	MQdnH2bv9OC3 = u5h2Rckvw1E.findall(XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠩࡷ࡭ࡹࡲࡥ࠾ࠤ࡮ࡳࡩ࡯࠭ࠩ࡞ࡧ࠯ࡡ࠴࡜ࡥ࠭࠰࡟ࡦ࠳ࡺࡂ࠯࡝ࡡ࠰࠯࠭ࠨ࠯"),oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	MQdnH2bv9OC3 = MQdnH2bv9OC3[n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠴੨")].split(cNaVb1vsT4qWOL0rpE(u"ࠪ࠱ࠬ࠰"))[n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠴੨")]
	yB3X9sUgEko = str(njGgmsD1k7cE60drxHCyVh2YN3P)
	HDP1ZJ2jWoQnTcAi = n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠫࡠࡘࡔࡍ࡟ศูิอัࠡๅ๋ำ๏ࠦวๅลั๎ึࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥ࠭࠱")+oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ࠲")+MQdnH2bv9OC3+ggDRehOModi(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ࠳")
	HDP1ZJ2jWoQnTcAi += OyJ1o4AvmWlB75UkFRX(u"ࠧ࡝ࡰ࡟ࡲࠬ࠴")+vvBChXmSty(u"ࠨ࡝ࡕࡘࡑࡣลึัสี้่ࠥะ์ࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦ็้ࠢ࠽ࠤࠥࠦࠧ࠵")+drHLAY5ENQFe2q9ptKGabo(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ࠶")+yB3X9sUgEko+PtXn0k9G3ocHRg(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ࠷")
	xl9MFt1AmY0GrkENug8n(yF29Xdsx35wI07Ce4(u"ࠫࠬ࠸"),cNaVb1vsT4qWOL0rpE(u"ࠬ࠭࠹"),ggDRehOModi(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ࠺"),HDP1ZJ2jWoQnTcAi)
	return
def V0pvqEginmDMuQdAZ():
	cLzOaV56rHkXKmxCy,Yw6S1bOqLcECfji7RJetgD,H48QNMCzRXUI1eioTPunZFEdYsG,HDP1ZJ2jWoQnTcAi,FFrNeJ5Amvh,VJdgFE0GUQjYe8Z6wP2z1,O9EcmHDT2wLdg = M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠧࠨ࠻"),shZ9eOcN2dJnPj(u"ࠨࠩ࠼"),yruHDQOcB97ig(u"ࠩࠪ࠽"),pcWq35MED2dtK(u"ࠪࠫ࠾"),nKLEi8CJumazx4qT(u"ࠫࠬ࠿"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠬ࠭ࡀ"),bcgZJWV6UeNSkRA(u"࠭ࠧࡁ")
	nD70jhRb8C9Gi,cuYmeSNrCAH9B2y3V4T5zax0P6jLg,aCH8yMW6YFiv7kfgeE9zxIDp,ORZwj8u0LSpP6U = {yruHDQOcB97ig(u"ࠧࡢࠩࡂ"):ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠨࡣࠪࡃ")},{},[],{}
	url = pgPfwZleTHVQ9a[xuztI5QWEKG70CPNdhk4vo6(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩࡄ")][r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠶੩")]
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(Iu3GUD84WyEqQjPFTYeh1SL9J,PtXn0k9G3ocHRg(u"ࠪࡔࡔ࡙ࡔࠨࡅ"),url,nD70jhRb8C9Gi,xuztI5QWEKG70CPNdhk4vo6(u"ࠫࠬࡆ"),yF29Xdsx35wI07Ce4(u"ࠬ࠭ࡇ"),qnPgZ9N15G6Oa8UpMASvLk(u"࠭ࠧࡈ"),drHLAY5ENQFe2q9ptKGabo(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡘࡗࡆࡍࡅࡠࡔࡈࡔࡔࡘࡔ࠮࠳ࡶࡸࠬࡉ"))
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	oo9SgGkiDbs3HRn7z8 = oo9SgGkiDbs3HRn7z8.replace(ggDRehOModi(u"ࠨࡗࡱ࡭ࡹ࡫ࡤࠡࡕࡷࡥࡹ࡫ࡳࠨࡊ"),shZ9eOcN2dJnPj(u"ࠩࡘࡗࡆ࠭ࡋ"))
	oo9SgGkiDbs3HRn7z8 = oo9SgGkiDbs3HRn7z8.replace(bcgZJWV6UeNSkRA(u"࡙ࠪࡳ࡯ࡴࡦࡦࠣࡏ࡮ࡴࡧࡥࡱࡰࠫࡌ"),InKG0i2r6hHDvgd(u"࡚ࠫࡑࠧࡍ"))
	oo9SgGkiDbs3HRn7z8 = oo9SgGkiDbs3HRn7z8.replace(shZ9eOcN2dJnPj(u"࡛ࠬ࡮ࡪࡶࡨࡨࠥࡇࡲࡢࡤࠣࡉࡲ࡯ࡲࡢࡶࡨࡷࠬࡎ"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠭ࡕࡂࡇࠪࡏ"))
	oo9SgGkiDbs3HRn7z8 = oo9SgGkiDbs3HRn7z8.replace(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠧࡔࡣࡸࡨ࡮ࠦࡁࡳࡣࡥ࡭ࡦ࠭ࡐ"),JLoPRXt93dpAB(u"ࠨࡍࡖࡅࠬࡑ"))
	oo9SgGkiDbs3HRn7z8 = oo9SgGkiDbs3HRn7z8.replace(drHLAY5ENQFe2q9ptKGabo(u"ࠩࡑࡳࡷࡺࡨࠡࡏࡤࡧࡪࡪ࡯࡯࡫ࡤࠫࡒ"),yF29Xdsx35wI07Ce4(u"ࠪࡒ࠳ࡓࡡࡤࡧࡧࡳࡳ࡯ࡡࠨࡓ"))
	oo9SgGkiDbs3HRn7z8 = oo9SgGkiDbs3HRn7z8.replace(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠫ࡜࡫ࡳࡵࡧࡵࡲ࡙ࠥࡡࡩࡣࡵࡥࠬࡔ"),nKLEi8CJumazx4qT(u"ࠬ࡝࠮ࡔࡣ࡫ࡥࡷࡧࠧࡕ"))
	oo9SgGkiDbs3HRn7z8 = oo9SgGkiDbs3HRn7z8.replace(InKG0i2r6hHDvgd(u"࠭࡟ࡠࡡࠪࡖ"),wwplD0tEehqH3kYQXs(u"ࠧࠡࠢࠪࡗ"))
	try: AKhaZBdnMrEkV = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ(KKbpxUZnMcj6AJ4QdD(u"ࠨ࡮࡬ࡷࡹ࠭ࡘ"),oo9SgGkiDbs3HRn7z8)
	except:
		xl9MFt1AmY0GrkENug8n(M6PIj8gl1fno7wcqTksDEBK4bU(u"࡙ࠩࠪ"),BGhdkWsEvJjiMFTr3NLn1flU(u"࡚ࠪࠫ"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊า࡛ࠧ"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࠬ็ิๅࠢไ๎ࠥาไษ่ࠢัฯ๎๊ศฬࠣฮ็ื๊าࠢส่ฬูสฯัส้ࠬ࡜"))
		return
	zuX9Rl7IoBwMd3eZajYGbsA6fHr,nxqQUzpmyPawlD0Lb8,ZzbrUTfW9m4wtqO = AKhaZBdnMrEkV
	ORZwj8u0LSpP6U = {}
	Tr7dWRwszqphiNXVL = [wwplD0tEehqH3kYQXs(u"࠭ࡃࡂࡒࡗࡇࡍࡇࡉࡅࠩ࡝"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠧࡄࡃࡓࡘࡈࡎࡁࡕࡑࡎࡉࡓ࠭࡞")]
	L6TovR2htF = [Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠨࡃࡏࡐࠬ࡟"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩࡠ"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠪࡍࡓ࡙ࡔࡂࡎࡏࠫࡡ"),vvBChXmSty(u"ࠫࡒࡋࡔࡓࡑࡓࡓࡑࡏࡓࠨࡢ"),ggDRehOModi(u"ࠬࡘࡅࡑࡑࡖࠫࡣ")]+Tr7dWRwszqphiNXVL+XzTni23psbetOyYc6HlGWBJgPmk5+sCXWyTFOq4fdm
	for tzVT6PXndWu0,rfgsve16NSaRBuO2FIDE7,rUx7Pcg0Fml2anYj6WfTekoZMXtJD in nxqQUzpmyPawlD0Lb8:
		rUx7Pcg0Fml2anYj6WfTekoZMXtJD = ffbxegm1XPSqIwp8i(rUx7Pcg0Fml2anYj6WfTekoZMXtJD)
		rUx7Pcg0Fml2anYj6WfTekoZMXtJD = rUx7Pcg0Fml2anYj6WfTekoZMXtJD.strip(wwplD0tEehqH3kYQXs(u"࠭ࠠࠨࡤ")).strip(qnPgZ9N15G6Oa8UpMASvLk(u"ࠧࠡ࠰ࠪࡥ"))
		HDP1ZJ2jWoQnTcAi += nKLEi8CJumazx4qT(u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ࡦ")+tzVT6PXndWu0+XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠩ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࡧ")+rUx7Pcg0Fml2anYj6WfTekoZMXtJD+oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠪࡠࡳ࠭ࡨ")
		if rfgsve16NSaRBuO2FIDE7.isdigit():
			ORZwj8u0LSpP6U[tzVT6PXndWu0] = int(rfgsve16NSaRBuO2FIDE7)
			if int(rfgsve16NSaRBuO2FIDE7)>KKbpxUZnMcj6AJ4QdD(u"࠷࠰࠱੪"): rfgsve16NSaRBuO2FIDE7 = n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠫ࡭࡯ࡧࡩࡷࡶࡥ࡬࡫ࠧࡩ")
			else: rfgsve16NSaRBuO2FIDE7 = nKLEi8CJumazx4qT(u"ࠬࡲ࡯ࡸࡷࡶࡥ࡬࡫ࠧࡪ")
		if tzVT6PXndWu0 not in L6TovR2htF:
			if   rfgsve16NSaRBuO2FIDE7==BGhdkWsEvJjiMFTr3NLn1flU(u"࠭ࡨࡪࡩ࡫ࡹࡸࡧࡧࡦࠩ࡫"): cLzOaV56rHkXKmxCy += pcWq35MED2dtK(u"ࠧࠡࠢࠪ࡬")+tzVT6PXndWu0
			elif rfgsve16NSaRBuO2FIDE7==xuztI5QWEKG70CPNdhk4vo6(u"ࠨ࡮ࡲࡻࡺࡹࡡࡨࡧࠪ࡭"): Yw6S1bOqLcECfji7RJetgD += yF29Xdsx35wI07Ce4(u"ࠩࠣࠤࠬ࡮")+tzVT6PXndWu0
	xK26imdJYjn7IrLoqU4DHav5PkX,lH2x4WTbG1dMitDyF9v3Y8fBSeK,TLMcPZhxGdQiF = list(zip(*nxqQUzpmyPawlD0Lb8))
	for tzVT6PXndWu0 in sorted(yxMRrnqoNS5GTCh4K):
		if tzVT6PXndWu0 not in xK26imdJYjn7IrLoqU4DHav5PkX:
			HDP1ZJ2jWoQnTcAi += bbw2eajMlG(u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ࡯")+tzVT6PXndWu0+xuztI5QWEKG70CPNdhk4vo6(u"ࠫ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨࡰ")+n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"๊ࠬวࠡ์๋ะิ࠭ࡱ")+cgtRBdXxSOk7WUfyDhPCls(u"࠭࡜࡯࡞ࡱࠫࡲ")
			if tzVT6PXndWu0 not in L6TovR2htF: H48QNMCzRXUI1eioTPunZFEdYsG += JLoPRXt93dpAB(u"ࠧࠡࠢࠪࡳ")+tzVT6PXndWu0
	for rUx7Pcg0Fml2anYj6WfTekoZMXtJD,s2YQCOWqLAFlKT1bvGco3t8x96fnrp in zuX9Rl7IoBwMd3eZajYGbsA6fHr:
		rUx7Pcg0Fml2anYj6WfTekoZMXtJD = ffbxegm1XPSqIwp8i(rUx7Pcg0Fml2anYj6WfTekoZMXtJD)
		FFrNeJ5Amvh += rUx7Pcg0Fml2anYj6WfTekoZMXtJD+bcgZJWV6UeNSkRA(u"ࠨ࠼ࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭ࡴ")+str(s2YQCOWqLAFlKT1bvGco3t8x96fnrp)+pcWq35MED2dtK(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࠥࠦࠧࡵ")
	cLzOaV56rHkXKmxCy = cLzOaV56rHkXKmxCy.strip(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠪࠤࠬࡶ"))
	Yw6S1bOqLcECfji7RJetgD = Yw6S1bOqLcECfji7RJetgD.strip(PtXn0k9G3ocHRg(u"ࠫࠥ࠭ࡷ"))
	H48QNMCzRXUI1eioTPunZFEdYsG = H48QNMCzRXUI1eioTPunZFEdYsG.strip(InKG0i2r6hHDvgd(u"ࠬࠦࠧࡸ"))
	DxJFHoOwmyBR = cLzOaV56rHkXKmxCy+drHLAY5ENQFe2q9ptKGabo(u"࠭ࠠࠡࠩࡹ")+Yw6S1bOqLcECfji7RJetgD
	EDtgXhfrJ7CLjxGZl0Ak9wevUN5  = cNaVb1vsT4qWOL0rpE(u"ࠧๆ๊สๆ฾ࠦๆอฯࠣห้ฮั็ษ่ะࠥฮสี฼ํ่ࠥ็๊ะ์๋๋ฬะࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠫࡺ")+XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠨ࡞ࡱࠫࡻ")+CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"๋๋ࠩีอࠠๆ฻้ห์ࠦลัษ่ࠣิ๐ใࠡ็ื็้ฯࠠโ้ํࠤ้๐ำห่๊ࠢࠥอไษำ้ห๊าࠧࡼ")+oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠪࡠࡳ࠭ࡽ")
	EDtgXhfrJ7CLjxGZl0Ak9wevUN5 += usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧࡾ")+DxJFHoOwmyBR+cgtRBdXxSOk7WUfyDhPCls(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱࠫࡿ")
	EDtgXhfrJ7CLjxGZl0Ak9wevUN5 += shZ9eOcN2dJnPj(u"࠭ๅ้ษๅ฽๊ࠥๅࠡ์ื฾้ࠦวๅสิ๊ฬ๋ฬࠡ็้๋ฬࠦแ๋ัํ์์อสࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠬࢀ")+shZ9eOcN2dJnPj(u"ࠧ࡝ࡰࠪࢁ")+InKG0i2r6hHDvgd(u"ࠨ๊๊ิฬࠦๅฺ่ส๋ࠥออห็ส่้ࠥศ๋ำࠣ์ั๎ฯࠡ็ื็้ฯࠠโ์ࠣห้ฮั็ษ่ะࠬࢂ")+r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠩ࡟ࡲࠬࢃ")
	EDtgXhfrJ7CLjxGZl0Ak9wevUN5 += iifPEY9ABNzTQp(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭ࢄ")+H48QNMCzRXUI1eioTPunZFEdYsG+r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࢅ")
	w0wYiSCpDf,Hmp4bLcGvPrASCRyhfao,Xi3jDC6K1QdxG,Grj56TeDhyivncQPX0SBNFx9I = pcWq35MED2dtK(u"࠰੫"),pcWq35MED2dtK(u"࠰੫"),pcWq35MED2dtK(u"࠰੫"),pcWq35MED2dtK(u"࠰੫")
	all = ORZwj8u0LSpP6U[KKbpxUZnMcj6AJ4QdD(u"ࠬࡇࡌࡍࠩࢆ")]
	if cgtRBdXxSOk7WUfyDhPCls(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ࢇ") in list(ORZwj8u0LSpP6U.keys()): w0wYiSCpDf = ORZwj8u0LSpP6U[shZ9eOcN2dJnPj(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ࢈")]
	if bbw2eajMlG(u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩࢉ") in list(ORZwj8u0LSpP6U.keys()): Hmp4bLcGvPrASCRyhfao = ORZwj8u0LSpP6U[OyJ1o4AvmWlB75UkFRX(u"ࠩࡌࡒࡘ࡚ࡁࡍࡎࠪࢊ")]
	if XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠪࡑࡊ࡚ࡒࡐࡒࡒࡐࡎ࡙ࠧࢋ") in list(ORZwj8u0LSpP6U.keys()): Xi3jDC6K1QdxG = ORZwj8u0LSpP6U[qnPgZ9N15G6Oa8UpMASvLk(u"ࠫࡒࡋࡔࡓࡑࡓࡓࡑࡏࡓࠨࢌ")]
	if shZ9eOcN2dJnPj(u"ࠬࡘࡅࡑࡑࡖࠫࢍ") in list(ORZwj8u0LSpP6U.keys()): Grj56TeDhyivncQPX0SBNFx9I = ORZwj8u0LSpP6U[xuztI5QWEKG70CPNdhk4vo6(u"࠭ࡒࡆࡒࡒࡗࠬࢎ")]
	fGctiqYO53gQa01MEux = all-w0wYiSCpDf-Hmp4bLcGvPrASCRyhfao-Xi3jDC6K1QdxG-Grj56TeDhyivncQPX0SBNFx9I
	qBdHbiaM0lmk5GNsfrXCIYyugR,jW2rABctNYPRUxfds0kOqy7wzX = ZzbrUTfW9m4wtqO[XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠱੬")]
	qBdHbiaM0lmk5GNsfrXCIYyugR,OS1lfPbXE7kZt = ZzbrUTfW9m4wtqO[yruHDQOcB97ig(u"࠳੭")]
	wlOx6dPGcEkK7JS = jW2rABctNYPRUxfds0kOqy7wzX-OS1lfPbXE7kZt
	O9EcmHDT2wLdg += drHLAY5ENQFe2q9ptKGabo(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ࢏")+str(OS1lfPbXE7kZt)+nKLEi8CJumazx4qT(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ࢐")+JLoPRXt93dpAB(u"ࠩส่฾ีฯࠡษ็ั็๐โ๋ࠢ็่ศา็ำหࠣ࠾ࠥ࠭࢑")
	O9EcmHDT2wLdg += Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ࢒")+str(wlOx6dPGcEkK7JS)+iifPEY9ABNzTQp(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭࢓")+drHLAY5ENQFe2q9ptKGabo(u"ࠬฮวิฬัำฬ๋ࠠࡱࡴࡲࡼࡾࠦร้ࠢࡹࡴࡳࠦ࠺ࠡࠩ࢔")
	O9EcmHDT2wLdg += xuztI5QWEKG70CPNdhk4vo6(u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ࢕")+str(jW2rABctNYPRUxfds0kOqy7wzX)+M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࢖")+InKG0i2r6hHDvgd(u"ࠨษ็฽ิีࠠศๆๆ่๏ࠦไอ็ํ฽ࠥอไฤฮ๊ึฮࠦ࠺ࠡࠩࢗ")
	O9EcmHDT2wLdg += usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ࢘")+str(len(ZzbrUTfW9m4wtqO[JLoPRXt93dpAB(u"࠵੮"):]))+tZ3gsrTEdzA1S6LXa9WI5px(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡ࢙ࠬ")+PtXn0k9G3ocHRg(u"ࠫ฾ีฯࠡษ็ำํ๊ࠠศๆอ๎ࠥ็๊่ษࠣวัําสࠢ࠽ࠤࡡࡴ࡜࡯࢚ࠩ")
	for Hqe1swvhCVTM2jYWKya0xSAUnbp,hGdKt2jR8SN1z5TrZkuU in ZzbrUTfW9m4wtqO[yF29Xdsx35wI07Ce4(u"࠶੯"):]:
		Hqe1swvhCVTM2jYWKya0xSAUnbp = ffbxegm1XPSqIwp8i(Hqe1swvhCVTM2jYWKya0xSAUnbp)
		Hqe1swvhCVTM2jYWKya0xSAUnbp = Hqe1swvhCVTM2jYWKya0xSAUnbp.strip(qnPgZ9N15G6Oa8UpMASvLk(u"࢛ࠬࠦࠧ")).strip(OyJ1o4AvmWlB75UkFRX(u"࠭ࠠ࠯ࠩ࢜"))
		O9EcmHDT2wLdg += Hqe1swvhCVTM2jYWKya0xSAUnbp+qnPgZ9N15G6Oa8UpMASvLk(u"ࠧ࠻ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ࢝")+str(hGdKt2jR8SN1z5TrZkuU)+pcWq35MED2dtK(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࠤࠥ࠭࢞")
	VJdgFE0GUQjYe8Z6wP2z1 += shZ9eOcN2dJnPj(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ࢟")+str(fGctiqYO53gQa01MEux)+cgtRBdXxSOk7WUfyDhPCls(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࢠ")+InKG0i2r6hHDvgd(u"ࠫๆ๐ฯ๋๊๊หฯࠦวีฬ฽่ฯࠦ࠺ࠡࠩࢡ")
	VJdgFE0GUQjYe8Z6wP2z1 += r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪࢢ")+str(w0wYiSCpDf)+OyJ1o4AvmWlB75UkFRX(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨࢣ")+iifPEY9ABNzTQp(u"ุࠧๆหหฯࠦำ๋ำไีࠥฮว๋อ๋๊ࠥࡀࠠࠨࢤ")
	VJdgFE0GUQjYe8Z6wP2z1 += shZ9eOcN2dJnPj(u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ࢥ")+str(Grj56TeDhyivncQPX0SBNFx9I)+nKLEi8CJumazx4qT(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࢦ")+n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠪ฻้ฮวหࠢึ๎ึ็ัࠡษ็ุ้ะ่ะ฻ࠣ࠾ࠥ࠭ࢧ")
	VJdgFE0GUQjYe8Z6wP2z1 += n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩࢨ")+str(Hmp4bLcGvPrASCRyhfao)+KKbpxUZnMcj6AJ4QdD(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࢩ")+ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠭สฬสํฮࠥะืษ์ๅࠤ่๎ฯ๋ࠢ฼้ฬีࠠ࠻ࠢࠪࢪ")
	VJdgFE0GUQjYe8Z6wP2z1 += CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬࢫ")+str(Xi3jDC6K1QdxG)+JLoPRXt93dpAB(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢬ")+qnPgZ9N15G6Oa8UpMASvLk(u"ࠩอฯอ๐สࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥࡀࠠࠨࢭ")
	VJdgFE0GUQjYe8Z6wP2z1 += InKG0i2r6hHDvgd(u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨࢮ")+str(len(zuX9Rl7IoBwMd3eZajYGbsA6fHr))+bcgZJWV6UeNSkRA(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࢯ")+cNaVb1vsT4qWOL0rpE(u"ࠬี่ๅࠢื฾้ะࠠโ์า๎ํํวหࠢ࠽ࠤࠬࢰ")
	VJdgFE0GUQjYe8Z6wP2z1 += drHLAY5ENQFe2q9ptKGabo(u"࠭࡜࡯࡞ࡱࠫࢱ")+FFrNeJ5Amvh
	RZo7IGjqXfiAnrWtlHcbNDuF9hP(bcgZJWV6UeNSkRA(u"ࠧࡤࡧࡱࡸࡪࡸࠧࢲ"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠨ฻าำࠥอไฤฮ๊ึฮࠦวๅฬํࠤฬูสฯั่ฮࠥํะศࠢส่อืๆศ็ฯࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠡใํࠤฬู๊ศๆ่ࠤ่๊็ࠨࢳ"),O9EcmHDT2wLdg,Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬࢴ"))
	RZo7IGjqXfiAnrWtlHcbNDuF9hP(BGhdkWsEvJjiMFTr3NLn1flU(u"ࠪࡧࡪࡴࡴࡦࡴࠪࢵ"),bcgZJWV6UeNSkRA(u"ࠫ฾ีฯࠡษ็ๅ๏ี๊้้สฮࠥอไห์ุࠣ฿๊็ศ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠥ็๊ࠡษ็฽ฬ๊ๅࠡๅ็๋ࠬࢶ"),VJdgFE0GUQjYe8Z6wP2z1,yF29Xdsx35wI07Ce4(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨࢷ"))
	RZo7IGjqXfiAnrWtlHcbNDuF9hP(qnPgZ9N15G6Oa8UpMASvLk(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ࢸ"),yruHDQOcB97ig(u"ࠧๆ๊สๆ฾ࠦวีฬ฽่ฯࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠣๅ๏ࠦวๅ฻ส่๊ࠦใๅ้ࠪࢹ"),EDtgXhfrJ7CLjxGZl0Ak9wevUN5,yF29Xdsx35wI07Ce4(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫࢺ"))
	RZo7IGjqXfiAnrWtlHcbNDuF9hP(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠩ࡯ࡩ࡫ࡺࠧࢻ"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࠪว฾๊้ࠡษ็ำํ๊ࠠศๆอ๎ࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠢสืฯิฯๆฬࠣห้ฮั็ษ่ะࠬࢼ"),HDP1ZJ2jWoQnTcAi,iifPEY9ABNzTQp(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬࢽ"))
	return
def Klsc4JW3hE0Aom():
	MLPwxur5kaYlBtqcn = KKbpxUZnMcj6AJ4QdD(u"ࠬํะศࠢส่อืๆศ็ฯࠤ๏฿ๅๅࠢสๅ฻๊ࠠษษึฮำีวๆࠢฯ่ิࠦใ้ัํࠤ࠭ࡑ࡯ࡥ࡫ࠣࡗࡰ࡯࡮ࠪࠢส่ี๐ࠠศี่๋ࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊ࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ࡟ࡲࡡࡴ้ࠠ็่็๋ࠦสฬสํฮ์ࠦศศีอาิอๅࠡ็ึฮํีูࠡ฻่หิࠦࡅࡎࡃࡇࠤࡗ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹࠡล๋ࠤฯำๅ๋ๆ๊ࠤ๊์࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯࡞ࡱࠤ์ึ็ࠡษ็ีุอไส๋ࠢ฾๏ื็ศࠢๆฯ๏ืࠠๆ๊ฯ์ิฯࠠโ์ࠣๆฬฬๅสࠢัำ๊อสࠡษ็ฬึ์วๆฮࠣ์ฬ๊ๅำ์าࠤศ๐ึศ่ࠢ์ั๎ฯࠡใํࠤ็อฦๆหࠣวั๎ศสࠢส่อืๆศ็ฯࠫࢾ")
	RZo7IGjqXfiAnrWtlHcbNDuF9hP(tZ3gsrTEdzA1S6LXa9WI5px(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ࢿ"),bbw2eajMlG(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࣀ"),MLPwxur5kaYlBtqcn,yF29Xdsx35wI07Ce4(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫࣁ"))
	return
def Z9XBVaT4mCf8sSn1yLidrOvj():
	MLPwxur5kaYlBtqcn = drHLAY5ENQFe2q9ptKGabo(u"ࠩส่ึอศุ์้ࠤศีๆศ้ࠣๅ๏ํๅศࠢอ฻อ๐โࠡๅ๋ำ๏ูࠦๆษาࠤํํ่ࠡ฻หหึฯฺ่ࠠࠣฮะฮ๊หࠢๆห๊๊ࠠศ๊อ์๊อส๋ๅํࠤ้ฮั็ษ่ะ้่ࠥะ์ࠣ์๊฿็ࠡษูหๆฯฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠣ์๊฿็ࠡษูหๆฯࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤํู๋่ࠢสฺฬ็ษࠡ็ึฮํีูࠡ฻่หิ่ࠦโ์๊ࠤศ๐ึศࠢฯ้๏฿ࠠศ฻าหิะࠠไ๊า๎ࠥอไๆู็์อฯࠠๅ฻่่ࠥฮั็ษ่ะࠥ฿ๅศัࠣ์่๊็ศࠢอฮ๊ࠦว้ฬ๋้ฬะ๊ไ์สࠤํ๊วࠡฬะฮฬาࠠฤ์๊ࠣํ฿ࠠๆ่ࠣห้ิศาหࠣๅ๏ࠦใ้ัํࠤศ๎ࠠศๆัฬึฯࠠโ์ࠣฮะฮ๊หࠢฦฺฬ็วหࠢๆ์ิ๐ࠧࣂ")+bcgZJWV6UeNSkRA(u"ࠪࡠࡳ࠭ࣃ")+oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧࣄ")+pgPfwZleTHVQ9a[JLoPRXt93dpAB(u"ࠬࡑࡏࡅࡋࡈࡑࡆࡊ࡟ࡂࡒࡓࠫࣅ")][XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠶ੱ")]+n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡࠢࠣࠤࠥࠦร้ࠢࠣࠤࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪࣆ")+pgPfwZleTHVQ9a[wwplD0tEehqH3kYQXs(u"ࠧࡌࡑࡇࡍࡊࡓࡁࡅࡡࡄࡔࡕ࠭ࣇ")][usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠶ੰ")]+r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࣈ")
	MLPwxur5kaYlBtqcn += shZ9eOcN2dJnPj(u"ࠩ࡟ࡲࡡࡴ࡜࡯ษ็ีฬฮืࠡลา๊ฬํ่๊ࠠࠣหู้่าีࠣห้ึ๊ࠡ์ะฮฬา็ࠡ็า๎ึࠦๅๅใสฮ้่ࠥะ์่ࠣฯัศ๋ฬࠣฬึ์วๆฮࠣ฽๊อฯࠡสส่฼ื๊ใหࠣห้ะโๅ์า๎ฮࠦวๅไา๎๊ฯ࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫࣉ")+pgPfwZleTHVQ9a[drHLAY5ENQFe2q9ptKGabo(u"ࠪࡗࡔ࡛ࡒࡄࡇࡖࠫ࣊")][Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠱ੲ")]+tZ3gsrTEdzA1S6LXa9WI5px(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭࣋")
	MLPwxur5kaYlBtqcn += CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠬࡢ࡮࡝ࡰ࡟ࡲัฺ๋๊่่ࠢๆอสࠡ฻่หิࠦๅ้ฮ๋ำฮࠦแ๋ࠢส่๊๎โฺࠢฦำ๋อ็ࠨ࣌")+tZ3gsrTEdzA1S6LXa9WI5px(u"࠭࡜࡯ࠩ࣍")+ggDRehOModi(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ࣎")+pgPfwZleTHVQ9a[qnPgZ9N15G6Oa8UpMASvLk(u"ࠨࡕࡒ࡙ࡗࡉࡅࡔ࣏ࠩ")][ggDRehOModi(u"࠳ੳ")]+XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠ࣐ࠫ")
	RZo7IGjqXfiAnrWtlHcbNDuF9hP(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠪࡧࡪࡴࡴࡦࡴ࣑ࠪ"),Tgoa16jMxvYX2(u"ࠫฬ๊ๅ้ษๅ฽ࠥอไาี่๎ฮࠦไษำ้ห๊าฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋ห࣒ࠪ"),MLPwxur5kaYlBtqcn,XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ࣓"))
	return
def oWCT6jn2xKwqrAONSe9(a8tPyRGc6zW):
	bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠭ࡁࡥࡦࡲࡲ࠳ࡕࡰࡦࡰࡖࡩࡹࡺࡩ࡯ࡩࡶࠬࠬࣔ")+a8tPyRGc6zW+cNaVb1vsT4qWOL0rpE(u"ࠧࠪࠩࣕ"), Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࡘࡷࡻࡥવ"))
	return
def MPlbH8aQIhq0C2RdS():
	vvZxzV4CkyoPTs(BGhdkWsEvJjiMFTr3NLn1flU(u"ࠨࡵࡷࡳࡵ࠭ࣖ"))
	bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(JLoPRXt93dpAB(u"ࠤࡄࡧࡹ࡯ࡶࡢࡶࡨ࡛࡮ࡴࡤࡰࡹࠫࡍࡳࡺࡥࡳࡨࡤࡧࡪ࡙ࡥࡵࡶ࡬ࡲ࡬ࡹࠩࠣࣗ"))
	return
def KlbnsSuMmTyxYFt75qaHe0No():
	bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(pcWq35MED2dtK(u"ࠪࡅࡩࡪ࡯࡯࠰ࡒࡴࡪࡴࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠩ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠪࠩࣘ"), bcgZJWV6UeNSkRA(u"࡙ࡸࡵࡦશ"))
	return
def qzko6eUs95i3TuQ8vIWwa(showDialogs):
	if not showDialogs: iZL6cN3OkM5 = Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࡚ࡲࡶࡧષ")
	else: iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(pcWq35MED2dtK(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫࣙ"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠬ࠭ࣚ"),Tgoa16jMxvYX2(u"࠭ࠧࣛ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࣜ"),pcWq35MED2dtK(u"ࠨสิ๊ฬ๋ฬࠡๅ๋ำ๏๊ࠦใ๊่ࠤอ฿ๅๅ์ฬࠤฯำฯ๋อࠣะ๊๐ูࠡษ็ษ฻อแศฬࠣฮ้่วว์สࠤ่๊ࠠ࠳࠶ࠣืฬ฿ษ๊ࠡ็็๋ࠦๅๆๅ้ࠤสาัศร๊หࠥอไร่ࠣ࠲ࠥํไࠡฬิ๎ิࠦสฮัํฯࠥาๅ๋฻ࠣษ฻อแศฬࠣ็ํี๊ࠡษ็ฦ๋ࠦฟࠨࣝ"))
	if iZL6cN3OkM5==n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠳ੴ"):
		bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠩࡘࡴࡩࡧࡴࡦࡃࡧࡨࡴࡴࡒࡦࡲࡲࡷࠬࣞ"))
		if showDialogs: xl9MFt1AmY0GrkENug8n(ggDRehOModi(u"ࠪࠫࣟ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠫࠬ࣠"),nKLEi8CJumazx4qT(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࣡"),InKG0i2r6hHDvgd(u"࠭สๆࠢศีุอไูࠡ็ฬࠥหไ๊ࠢหี๋อๅอࠢๆ์ิ๐ࠠศๆำ๎ࠥ็๊ࠡฮ๊หื้ࠠๅๅํࠤ๏่่ๆࠢหฮาี๊ฬࠢฯ้๏฿ࠠฦุสๅฬะࠠไ๊า๎ࠥ࠴ࠠษ็สࠤๆ๐็ศࠢอัิ๐ห้ࠡำหࠥอไษำ้ห๊า้ࠠฬะำ๏ัࠠๆีอ์ิ฿ฺࠠ็สำࠥ࠴๋ࠠำฯํࠥหูุษฤࠤ่๎ฯ๋ࠢ࠸ࠤิ่ววไࠣวํࠦรไอิࠤ้้๊ࠡ์้๋๏ูࠦๆๆํอࠥอไหฯา๎ะ࠭࣢"))
		bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(cgtRBdXxSOk7WUfyDhPCls(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࣣࠫ"))
	return
def JNQtIWOi0ojMDEY6a7RCr():
	xl9MFt1AmY0GrkENug8n(xuztI5QWEKG70CPNdhk4vo6(u"ࠨࠩࣤ"),JLoPRXt93dpAB(u"ࠩࠪࣥ"),OyJ1o4AvmWlB75UkFRX(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ัࣦ࠭"),M6PIj8gl1fno7wcqTksDEBK4bU(u"้๋ࠫำฮ่ࠢัฯ๎๊ศฬࠣๆฬฬๅสࠢ࠱ࠤฬึ็ษࠢศ่๎ࠦวๅไสส๊ฯࠠศๆอ๎ࠥะั๋ัุ้ࠣำ็ศ๋่ࠢฬࠦสะะ็ࠤส๊๊่ษࠣ์้้ๆࠡสสืฯิฯศ็ࠣࠦฬ๊ๅศ๊ึࠦࠥษ่ࠡࠤส่ึ๐ๅ้ฬࠥࠤฬ฼ฺุࠢ฼่๎ࠦวๅิิࠤัํษࠡษ็๎๊๐ๆࠡล๋ࠤฬูสฯั่ࠤࠧอไไ์ห์ึี๊ࠢࠡสฺ฿฽ฺࠠๆ์ࠤาืแࠡࠤࡆࠦࠥษ่ࠡ฻็ํࠥอึ฻ูࠣ฽้๏ࠠำำࠣࠦฬ๊โศศ่อࠧࠦวๅาํࠤๆ๐ࠠอ้ฬࠤฬ๊๊ๆ์้ࠫࣧ"))
	return
def I9OdoE1NHg8M5vx():
	xl9MFt1AmY0GrkENug8n(KKbpxUZnMcj6AJ4QdD(u"ࠬ࠭ࣨ"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࣩ࠭ࠧ"),drHLAY5ENQFe2q9ptKGabo(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࣪"),yruHDQOcB97ig(u"ࠨๆ็ฮ฾อๅๅ่ࠢ฽ࠥอไๆใู่ฮࠦ࠮ࠡษำ๋อࠦลๅ๋ࠣห้ืวษูࠣห้ึ๊ࠡฬิ๎ิࠦลืษไฮ์ࠦร้่ࠢืาํࠠๆ่ࠣࠤ็อฦๆหࠣห้๋แืๆฬࠤํ๊ใ็ࠢ็หࠥะๆใำࠣ฽้๐็๊ࠡ็หࠥะิ฻ๆ๊ࠤ࠳่ࠦษษึฮำีวๆࠢࠥห้๋ว้ีࠥࠤศ๎ࠠࠣษ็ี๏๋่หࠤࠣห฻เืࠡ฻็ํࠥอไำำࠣะ์ฯࠠศๆํ้๏์ࠠ࠯๋ࠢว๊อࠠษษึฮำีวๆࠢࠥห้้๊ษ๊ิำࠧࠦแศุ฽฻ࠥ฿ไ๊ࠢะีๆࠦࠢࡄࠤࠣวํูࠦๅ๋ࠣึึࠦࠢศๆๅหห๋ษࠣࠢส่ี๐ࠠโ์ࠣะ์ฯࠠศๆํ้๏์ࠠ࠯๋๊ࠢๆูࠠศๆๆ่ฬ๋้ࠠษ็฻ึ๐โสࠢ฼๊ิࠦวๅฬ฼ห๊๊ࠠๆ฻้ࠣาะ่๋ษอࠤ็๎วว็ࠣห้๋แืๆฬࠫ࣫"))
	return
def UOit806xldSDeARyX1waB5Jqs(showDialogs=nKLEi8CJumazx4qT(u"ࡔࡳࡷࡨસ")):
	pUlJPo9ADiw0YLh = [XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲ࡴࡺࡨࡦࡴࡶࠫ࣬"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡧࡨ࣭ࠫ"),bcgZJWV6UeNSkRA(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࣮ࠧ"),drHLAY5ENQFe2q9ptKGabo(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡨ࡫ࡷ࡬ࡺࡨ࣯ࠧ"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡩ࡬ࡸࡪࡧࣰࠧ"),KKbpxUZnMcj6AJ4QdD(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡦࡳࡩ࡫ࡢࡦࡴࡪࣱࠫ")]
	gvWFwcZxLBj4ps7RN = pUlJPo9ADiw0YLh+[M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࣲࠪ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧࣳ"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩࣴ"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪࣵ"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠬࡹ࡫ࡪࡰ࠱ࡴ࡭࡫࡮ࡰ࡯ࡨࡲࡦࡲࡅࡎࡃࡇࣶࠫ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪࣷ"),KKbpxUZnMcj6AJ4QdD(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦ࡯ࠫࣸ")]
	u9q1RZQYpdDUA = FWagyi9bX8LRexDPmArjVZfdNK([nKLEi8CJumazx4qT(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࣹࠪ")])
	fZPQTkHFwJ4MKoN63BWtSR2ipbx9 = []
	for lY0rst72uGVZ1NkgvpjfA6x in [qnPgZ9N15G6Oa8UpMASvLk(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࣺࠫ")]:
		if lY0rst72uGVZ1NkgvpjfA6x not in list(u9q1RZQYpdDUA.keys()): continue
		ic2VMr7wJYbK3x6RSlOW,j0Bh7vkYJtpCSP,sXD3icxn75CWUufNPzqpKHYVhaS,d2DpfSRUIiLMtja0WmqY,Op0DhErcql,fM4jDQixmqeywNl3aAOoHRzE5VYkBc,Mih6Nf1yzqbKxrtnvwu = u9q1RZQYpdDUA[lY0rst72uGVZ1NkgvpjfA6x]
		if not j0Bh7vkYJtpCSP or (j0Bh7vkYJtpCSP and ic2VMr7wJYbK3x6RSlOW): fZPQTkHFwJ4MKoN63BWtSR2ipbx9.append(lY0rst72uGVZ1NkgvpjfA6x)
	pRB5zIx1reYmD7FtLQ0C = len(fZPQTkHFwJ4MKoN63BWtSR2ipbx9)>drHLAY5ENQFe2q9ptKGabo(u"࠳ੵ")
	AO76Z1XEaSDjomRwK = Xmn7ZoOHiUB2fKvd6Y8ALct3GsNT.connect(UrA7SvnaILc)
	AO76Z1XEaSDjomRwK.text_factory = str
	BVYESNuJMxlmDo5WXdaFP6r = AO76Z1XEaSDjomRwK.cursor()
	KK843WprVCh = []
	for lY0rst72uGVZ1NkgvpjfA6x in pUlJPo9ADiw0YLh:
		BVYESNuJMxlmDo5WXdaFP6r.execute(yruHDQOcB97ig(u"ࠪࡗࡊࡒࡅࡄࡖࠣ࠮ࠥࡌࡒࡐࡏࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡗࡉࡇࡕࡉࠥ࡫࡮ࡢࡤ࡯ࡩࡩࠦ࠽ࠡࠤ࠴ࠦࠥࡧ࡮ࡥࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧࣻ")+lY0rst72uGVZ1NkgvpjfA6x+ggDRehOModi(u"ࠫࠧࠦ࠻ࠨࣼ"))
		CVRQsZFOWHvK7SpkroU15eyAn = BVYESNuJMxlmDo5WXdaFP6r.fetchall()
		if CVRQsZFOWHvK7SpkroU15eyAn: KK843WprVCh.append(lY0rst72uGVZ1NkgvpjfA6x)
	yidFP8hKwtkgQLW94xUmBeHXJs = len(KK843WprVCh)>InKG0i2r6hHDvgd(u"࠴੶")
	for lY0rst72uGVZ1NkgvpjfA6x in gvWFwcZxLBj4ps7RN:
		BVYESNuJMxlmDo5WXdaFP6r.execute(ggDRehOModi(u"࡙ࠬࡅࡍࡇࡆࡘࠥࡵࡲࡪࡩ࡬ࡲࠥࡌࡒࡐࡏࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪࣽ")+lY0rst72uGVZ1NkgvpjfA6x+yruHDQOcB97ig(u"࠭ࠢࠡ࠽ࠪࣾ"))
		I7jTpUCscnBvxE = BVYESNuJMxlmDo5WXdaFP6r.fetchall()
		if I7jTpUCscnBvxE and KKbpxUZnMcj6AJ4QdD(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩࣿ") not in str(I7jTpUCscnBvxE): fZPQTkHFwJ4MKoN63BWtSR2ipbx9.append(lY0rst72uGVZ1NkgvpjfA6x)
	CvEfOqLKunHUlRXAs5N4M1I6Z79c = len(fZPQTkHFwJ4MKoN63BWtSR2ipbx9)>yF29Xdsx35wI07Ce4(u"࠵੷")
	fZPQTkHFwJ4MKoN63BWtSR2ipbx9 = list(set(fZPQTkHFwJ4MKoN63BWtSR2ipbx9))
	AO76Z1XEaSDjomRwK.close()
	ic2VMr7wJYbK3x6RSlOW = shZ9eOcN2dJnPj(u"ࡇࡣ࡯ࡷࡪહ")
	if yidFP8hKwtkgQLW94xUmBeHXJs or CvEfOqLKunHUlRXAs5N4M1I6Z79c:
		iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(cNaVb1vsT4qWOL0rpE(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨऀ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠩࠪँ"),OyJ1o4AvmWlB75UkFRX(u"ࠪࠫं"),bbw2eajMlG(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧः"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠬอไษำ้ห๊า้ࠠฮาࠤฺ๊ใๅหࠣๅ๏ࠦๅิฬ๋ำ฾ูࠦๆษาࠤศ๎ࠠๆึๆ่ฮࠦแ๋ࠢส่ฯำฯ๋อࠣห้ะไใษษ๎๊ࠥลืษไหฯࠦศา่ส้ัูࠦๆษาࠤࡡࡴ࡜࡯ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠥํไࠡฬิ๎ิࠦลึๆสัࠥํะ่ࠢสฺ่๊ใๅหࠣห้ศๆࠡม࡞࠳ࡈࡕࡌࡐࡔࡠࠫऄ"))
		if iZL6cN3OkM5==wwplD0tEehqH3kYQXs(u"࠷੸"):
			GO3aTxVN6erUu58qngA = yF29Xdsx35wI07Ce4(u"ࡖࡵࡹࡪ઺")
			if pRB5zIx1reYmD7FtLQ0C:
				GO3aTxVN6erUu58qngA = DyiGnpNLWIXeFUw(cgtRBdXxSOk7WUfyDhPCls(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨअ"),yruHDQOcB97ig(u"ࡉࡥࡱࡹࡥ઻"),yruHDQOcB97ig(u"ࡉࡥࡱࡹࡥ઻"))
			p2ZB65nEjfUcNeq8SumsW = oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࡘࡷࡻࡥ઼")
			if yidFP8hKwtkgQLW94xUmBeHXJs:
				for lY0rst72uGVZ1NkgvpjfA6x in KK843WprVCh: Na4XIJeuf7LRYBcK21TMs6QVz(lY0rst72uGVZ1NkgvpjfA6x)
				p2ZB65nEjfUcNeq8SumsW = bcgZJWV6UeNSkRA(u"࡙ࡸࡵࡦઽ")
			u9QAGcExyM1veKDBwWikd = n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࡚ࡲࡶࡧા")
			if CvEfOqLKunHUlRXAs5N4M1I6Z79c:
				AO76Z1XEaSDjomRwK = Xmn7ZoOHiUB2fKvd6Y8ALct3GsNT.connect(UrA7SvnaILc)
				AO76Z1XEaSDjomRwK.text_factory = str
				BVYESNuJMxlmDo5WXdaFP6r = AO76Z1XEaSDjomRwK.cursor()
				for lY0rst72uGVZ1NkgvpjfA6x in fZPQTkHFwJ4MKoN63BWtSR2ipbx9:
					if M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࠪआ") in lY0rst72uGVZ1NkgvpjfA6x: I7jTpUCscnBvxE = lY0rst72uGVZ1NkgvpjfA6x
					else: I7jTpUCscnBvxE = yF29Xdsx35wI07Ce4(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪइ")
					try: BVYESNuJMxlmDo5WXdaFP6r.execute(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠩࡘࡔࡉࡇࡔࡆࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࡙ࠥࡅࡕࠢࡲࡶ࡮࡭ࡩ࡯ࠢࡀࠤࠧ࠭ई")+I7jTpUCscnBvxE+pcWq35MED2dtK(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩउ")+lY0rst72uGVZ1NkgvpjfA6x+BGhdkWsEvJjiMFTr3NLn1flU(u"ࠫࠧࠦ࠻ࠨऊ"))
					except: u9QAGcExyM1veKDBwWikd = shZ9eOcN2dJnPj(u"ࡆࡢ࡮ࡶࡩિ")
				AO76Z1XEaSDjomRwK.commit()
				AO76Z1XEaSDjomRwK.close()
			YVJPFvuI2CS5KObiZt.sleep(M6PIj8gl1fno7wcqTksDEBK4bU(u"࠱੹"))
			bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(XikqnGVSK4v9d3uUICLhDxJyt1M(u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩऋ"))
			YVJPFvuI2CS5KObiZt.sleep(yruHDQOcB97ig(u"࠲੺"))
			if GO3aTxVN6erUu58qngA or p2ZB65nEjfUcNeq8SumsW or u9QAGcExyM1veKDBwWikd:
				ic2VMr7wJYbK3x6RSlOW = xuztI5QWEKG70CPNdhk4vo6(u"ࡇࡣ࡯ࡷࡪી")
				xl9MFt1AmY0GrkENug8n(JLoPRXt93dpAB(u"࠭ࠧऌ"),yruHDQOcB97ig(u"ࠧࠨऍ"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫऎ"),KKbpxUZnMcj6AJ4QdD(u"ࠩฯ๎ิࠦ࠮࠯ࠢอ้ࠥฮๆอษะࠤฯ็ู๋ๆࠣ์ส฻ไศฯࠣห้๋ำห๊า฽ࠥ๎วๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢ็ะ๊๐ูࠡวูหๆอสࠡสิ๊ฬ๋ฬࠡ฻่หิ࠭ए"))
			else:
				ic2VMr7wJYbK3x6RSlOW = iifPEY9ABNzTQp(u"ࡖࡵࡹࡪુ")
				xl9MFt1AmY0GrkENug8n(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠪࠫऐ"),bbw2eajMlG(u"ࠫࠬऑ"),Tgoa16jMxvYX2(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨऒ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"࠭ไๅลึๅࠥ࠴࠮ࠡใื่ฯูࠦๆๆํอࠥหีๅษะࠤู๊ส้ั฼ࠤ฾๋วะ๋ࠢษฺ๊วฮࠢส่ฯำฯ๋อࠣห้ะไใษษ๎๊ࠥลืษไหฯࠦศา่ส้ัูࠦๆษาࠫओ"))
	elif showDialogs: xl9MFt1AmY0GrkENug8n(InKG0i2r6hHDvgd(u"ࠧࠨऔ"),yF29Xdsx35wI07Ce4(u"ࠨࠩक"),pcWq35MED2dtK(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬख"),InKG0i2r6hHDvgd(u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠศๆหี๋อๅอࠢ็้ࠥ๐ฬะุ่่๊ࠢษࠡใํࠤู๊ส้ั฼ࠤ฾๋วะࠢฦ์ࠥ็๊ࠡษ็ฮาี๊ฬࠢส่ฯ๊โศศํࠤ้หึศใสฮࠥฮั็ษ่ะࠥ฿ๅศัࠪग"))
	return ic2VMr7wJYbK3x6RSlOW
def SGUyo5X3M8AkO64Kri7vW0BcdbCPxa():
	jkAb9dqU26KGNBRpQVwHfC0sZxJ4,wQcZKN2UtJDT,vC0RynN9DF = qnPgZ9N15G6Oa8UpMASvLk(u"ࡉࡥࡱࡹࡥૂ"),drHLAY5ENQFe2q9ptKGabo(u"ࠫࠬघ"),iifPEY9ABNzTQp(u"ࠬ࠭ङ")
	YYBlqph6oT3xeD,y3ZG0w4F8o9m6vKXT7kEeVz,Xa2dzkh9eKxR4t = ggDRehOModi(u"ࡊࡦࡲࡳࡦૃ"),KKbpxUZnMcj6AJ4QdD(u"࠭ࠧच"),xuztI5QWEKG70CPNdhk4vo6(u"ࠧࠨछ")
	SOVvLIUhYqMB0gkezRxcdwa = [ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ज"),InKG0i2r6hHDvgd(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨझ"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬञ"),bcgZJWV6UeNSkRA(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪट")]
	u9q1RZQYpdDUA = FWagyi9bX8LRexDPmArjVZfdNK(SOVvLIUhYqMB0gkezRxcdwa)
	for lY0rst72uGVZ1NkgvpjfA6x in SOVvLIUhYqMB0gkezRxcdwa:
		if lY0rst72uGVZ1NkgvpjfA6x not in list(u9q1RZQYpdDUA.keys()): continue
		ic2VMr7wJYbK3x6RSlOW,j0Bh7vkYJtpCSP,GN8LC7cw5iUyv3QnfKMTE41kOe,lpTcW8Oy4mNKED31JP7oX,dsNK9gGzmxLD786vyC,ZeLkvRsNmVzWg5Fdj,UUXu9aqOcSC = u9q1RZQYpdDUA[lY0rst72uGVZ1NkgvpjfA6x]
		if lY0rst72uGVZ1NkgvpjfA6x==xuztI5QWEKG70CPNdhk4vo6(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪठ"):
			YYBlqph6oT3xeD = ic2VMr7wJYbK3x6RSlOW
			y3ZG0w4F8o9m6vKXT7kEeVz = r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠭ࠨࠨड")+j0Bh7vkYJtpCSP+bbw2eajMlG(u"ࠧࠡࠩढ")+wSH84vUOuxYjoQ3aPBeAEZ(ZeLkvRsNmVzWg5Fdj)+OyJ1o4AvmWlB75UkFRX(u"ࠨࠫࠪण")
			Xa2dzkh9eKxR4t = lpTcW8Oy4mNKED31JP7oX
		elif lY0rst72uGVZ1NkgvpjfA6x==xuztI5QWEKG70CPNdhk4vo6(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫत"):
			jkAb9dqU26KGNBRpQVwHfC0sZxJ4 = jkAb9dqU26KGNBRpQVwHfC0sZxJ4 or ic2VMr7wJYbK3x6RSlOW
			wQcZKN2UtJDT += cgtRBdXxSOk7WUfyDhPCls(u"ࠪࠤࠥ࠲ࠠࠡࠪࠪथ")+j0Bh7vkYJtpCSP+yruHDQOcB97ig(u"ࠫࠥ࠭द")+wSH84vUOuxYjoQ3aPBeAEZ(ZeLkvRsNmVzWg5Fdj)+Tgoa16jMxvYX2(u"ࠬ࠯ࠧध")
			vC0RynN9DF += nKLEi8CJumazx4qT(u"࠭ࠠࠡ࠮ࠣࠤࠬन")+lpTcW8Oy4mNKED31JP7oX
		elif lY0rst72uGVZ1NkgvpjfA6x==yF29Xdsx35wI07Ce4(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ऩ"):
			ms0bxWY3LPNA = ic2VMr7wJYbK3x6RSlOW
			O2maASqcECxs4fHK65n9i = tZ3gsrTEdzA1S6LXa9WI5px(u"ࠨࠪࠪप")+j0Bh7vkYJtpCSP+ggDRehOModi(u"ࠩࠣࠫफ")+wSH84vUOuxYjoQ3aPBeAEZ(ZeLkvRsNmVzWg5Fdj)+ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠪ࠭ࠬब")
			BBIXunHhV5kGPZvYr = lpTcW8Oy4mNKED31JP7oX
	wQcZKN2UtJDT = wQcZKN2UtJDT.strip(vvBChXmSty(u"ࠫࠥࠦࠬࠡࠢࠪभ"))
	vC0RynN9DF = vC0RynN9DF.strip(ggDRehOModi(u"ࠬࠦࠠ࠭ࠢࠣࠫम"))
	ASpYQV56F8DxvUwly0cmoaqPLh1Tu  = ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไฤะํี๊ࠥศา่ส้ัูࠦๆษาࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭य")+Xa2dzkh9eKxR4t+ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩर")
	ASpYQV56F8DxvUwly0cmoaqPLh1Tu += bbw2eajMlG(u"ࠨ࡞ࡱࠫऱ")+tZ3gsrTEdzA1S6LXa9WI5px(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ้ฮั็ษ่ะࠥ฿ๅศั๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ल")+y3ZG0w4F8o9m6vKXT7kEeVz+qnPgZ9N15G6Oa8UpMASvLk(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬळ")
	ASpYQV56F8DxvUwly0cmoaqPLh1Tu += pcWq35MED2dtK(u"ࠫࡡࡴ࡜࡯ࠩऴ")+oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊รฯ์ิࠤ้๋ำห๊า฽ࠥ฿ๅศัࠣห้๋ส้ใิࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬव")+vC0RynN9DF+shZ9eOcN2dJnPj(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨश")
	ASpYQV56F8DxvUwly0cmoaqPLh1Tu += qnPgZ9N15G6Oa8UpMASvLk(u"ࠧ࡝ࡰࠪष")+cNaVb1vsT4qWOL0rpE(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆู้่๊ࠣส้ั฼ࠤ฾๋วะ๊ࠢ์ࠥࡀࠠࠡࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬस")+wQcZKN2UtJDT+cgtRBdXxSOk7WUfyDhPCls(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫह")
	ASpYQV56F8DxvUwly0cmoaqPLh1Tu += drHLAY5ENQFe2q9ptKGabo(u"ࠪࡠࡳࡢ࡮ࠨऺ")+n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡษ็้ฯ๎แาࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪऻ")+BBIXunHhV5kGPZvYr+shZ9eOcN2dJnPj(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣ़ࠧ")
	ASpYQV56F8DxvUwly0cmoaqPLh1Tu += bbw2eajMlG(u"࠭࡜࡯ࠩऽ")+ggDRehOModi(u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅาํࠤฬ์สࠡฬึฮำีๅ่ࠢ็ะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬี่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪा")+O2maASqcECxs4fHK65n9i+KKbpxUZnMcj6AJ4QdD(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪि")
	ic2VMr7wJYbK3x6RSlOW = (YYBlqph6oT3xeD or jkAb9dqU26KGNBRpQVwHfC0sZxJ4)
	if ic2VMr7wJYbK3x6RSlOW:
		header = nKLEi8CJumazx4qT(u"ࠩส่ึาวยࠢอัิ๐หࠡวูหๆอสࠡๅ๋ำ๏ࠦไฮๆࠣห้๋ิศๅ็ࠫी")
		lxLX0WcduZFq2y7j6SVMvw = xuztI5QWEKG70CPNdhk4vo6(u"ࠪห๋ะࠠษฯสะฮࠦไหฯา๎ะࠦศา่ส้ัูࠦๆษาࠤศ๎ࠠหฯา๎ะࠦๅิฬ๋ำ฾ูࠦๆษาࠫु")
	else:
		header = nKLEi8CJumazx4qT(u"ࠫาอไ๋ษ่ࠣฬ๊้ࠦฮาࠤฯำฯ๋อสฮ๊ࠥศา่ส้ัูࠦๆษาࠤศ๎ࠠๆีอ์ิ฿ฺࠠ็สำࠬू")
		lxLX0WcduZFq2y7j6SVMvw = nKLEi8CJumazx4qT(u"ࠬอไาฮสลࠥหศๅษ฽ࠤฬ๊ๅษำ่ะࠥ฿ๆࠡษ็ู้้ไสࠢส่ฯ๐ࠠห๊สะ์้ࠧृ")
	sfDMbT5Q8z = oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠭ไไ์ࠣ๎฾๋ไࠡ฻้ำ่ࠦวๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢํะอࠦร็ࠢํ็ํ์ࠠๅัํ็ࠥ็๊ࠡๅ๋ำ๏ࡢ࡮ๆีอ์ิ฿ฺࠠ็สำࠥࡋࡍࡂࡆࠣࡖࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿࠧॄ")
	I2IFEDkensK19fSihqgM = ASpYQV56F8DxvUwly0cmoaqPLh1Tu+qnPgZ9N15G6Oa8UpMASvLk(u"ࠧ࡝ࡰ࡟ࡲࠬॅ")+lxLX0WcduZFq2y7j6SVMvw+usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠨ࡞ࡱࡠࡳ࠭ॆ")+sfDMbT5Q8z
	RZo7IGjqXfiAnrWtlHcbNDuF9hP(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠩࡵ࡭࡬࡮ࡴࠨे"),header,I2IFEDkensK19fSihqgM,InKG0i2r6hHDvgd(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ै"))
	return
def NZ0pBCdgQs(showDialogs,JeLfqGmjwNQbHK7r56):
	ZqlR5BFQ6pm0asCHLUc(bpNSygerL10j4IOkEfuVw,M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧॉ"),iifPEY9ABNzTQp(u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭ॊ"))
	if showDialogs:
		SGUyo5X3M8AkO64Kri7vW0BcdbCPxa()
		Ct2ZlYo9qO6BKJLzAVxGd84Mc()
	if JeLfqGmjwNQbHK7r56:
		UOit806xldSDeARyX1waB5Jqs(PtXn0k9G3ocHRg(u"ࡋࡧ࡬ࡴࡧૄ"))
		QJukqyrKmI4GwDTzAthNpxFfvcBVi2 = [cgtRBdXxSOk7WUfyDhPCls(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫो"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ौ"),cgtRBdXxSOk7WUfyDhPCls(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ्ࠪ"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭ॎ"),ggDRehOModi(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡲࠧॏ")]
		for BpRbqo0yr4Xf in QJukqyrKmI4GwDTzAthNpxFfvcBVi2:
			V5VXz0j3oa6t,UueF2YJP9akb7Z,j0Bh7vkYJtpCSP = DyiGnpNLWIXeFUw(BpRbqo0yr4Xf,iifPEY9ABNzTQp(u"ࡔࡳࡷࡨ૆"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࡌࡡ࡭ࡵࡨૅ"))
		qzko6eUs95i3TuQ8vIWwa(showDialogs)
		bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(OyJ1o4AvmWlB75UkFRX(u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨॐ"))
	return
def HJaziOsSXQok4uZtRKg2ITfr3bUFEn(AoWlXmK9s3bck7GJTgC=cNaVb1vsT4qWOL0rpE(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ॑"),showDialogs=BGhdkWsEvJjiMFTr3NLn1flU(u"ࡕࡴࡸࡩે")):
	sWXx2MJmLGl = bMIascyFJ2x43E0C7glTB91h8qz.executeJSONRPC(InKG0i2r6hHDvgd(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾ॒ࠩ"))
	import json as Kq1vtcn0VUo4CaebZuWYHpPJ7l
	data = Kq1vtcn0VUo4CaebZuWYHpPJ7l.loads(sWXx2MJmLGl)
	Fuy4Kqpc9Z2oIRMObrwTVPmnk = data[drHLAY5ENQFe2q9ptKGabo(u"ࠧࡳࡧࡶࡹࡱࡺࠧ॓")][cgtRBdXxSOk7WUfyDhPCls(u"ࠨࡸࡤࡰࡺ࡫ࠧ॔")]
	if bdptXFc8UlIhA5jnGwPmKuv2L: Fuy4Kqpc9Z2oIRMObrwTVPmnk = Fuy4Kqpc9Z2oIRMObrwTVPmnk.encode(drHLAY5ENQFe2q9ptKGabo(u"ࠩࡸࡸ࡫࠾ࠧॕ"))
	if showDialogs:
		iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(cNaVb1vsT4qWOL0rpE(u"ࠪࠫॖ"),JLoPRXt93dpAB(u"ࠫࠬॗ"),cNaVb1vsT4qWOL0rpE(u"ࠬ࠭क़"),yF29Xdsx35wI07Ce4(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩख़"),drHLAY5ENQFe2q9ptKGabo(u"่ࠧๆࠣฮึ๐ฯࠡฬ฽๎๏ืࠠอๆาࠤࠬग़")+Fuy4Kqpc9Z2oIRMObrwTVPmnk+oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠨࠢส่ี๐ࠠๆีอาิ๋ࠠศๆล๊ࠥ็๊ࠡๅ๋ำ๏ࠦลๅ๋ࠣห้หีะษิࠤฬ๊รฯ์ิࠤ้าไะࠢࠪज़")+AoWlXmK9s3bck7GJTgC+Tgoa16jMxvYX2(u"ࠩࠣรࠦ࠭ड़"))
		if iZL6cN3OkM5!=ggDRehOModi(u"࠳੻"): return r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࡈࡤࡰࡸ࡫ૈ")
	V5VXz0j3oa6t,UueF2YJP9akb7Z,cWgh89MNuEofHTz1bVZlkQUYDndm = DyiGnpNLWIXeFUw(AoWlXmK9s3bck7GJTgC,drHLAY5ENQFe2q9ptKGabo(u"ࡉࡥࡱࡹࡥૉ"),drHLAY5ENQFe2q9ptKGabo(u"ࡉࡥࡱࡹࡥૉ"))
	if V5VXz0j3oa6t:
		if showDialogs: xl9MFt1AmY0GrkENug8n(r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠪࠫढ़"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠫࠬफ़"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨय़"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠭สๆฬࠣ฽๊๊๊สࠢอฯอ๐สࠡษ็ะ้ีࠠศๆฯำ๏ี้้๋ࠠࠤัอ็ำࠢ็่ฬูสฯัส้ࠥ࠴ࠠิ๊ไࠤ๏ะๅࠡษ็ฦ๋ࠦส฻์ํีࠥหูะษาหฯࠦใ้ัํࠤ้้๊ࠡ์ึฮ฾๋ไࠡษ็ะ้ีࠠศๆฯำ๏ีࠠษั็ห๋ࠥๆࠡษ็ๆิ๐ๅࠨॠ"))
		FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy = bMIascyFJ2x43E0C7glTB91h8qz.executeJSONRPC(qnPgZ9N15G6Oa8UpMASvLk(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡕࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢ࠭ࠤࡹࡥࡱࡻࡥࠣ࠼ࠥࠫॡ")+AoWlXmK9s3bck7GJTgC+yruHDQOcB97ig(u"ࠨࠤࢀࢁࠬॢ"))
		if usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩࡒࡏࠬॣ") in FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy: V5VXz0j3oa6t = JLoPRXt93dpAB(u"ࡘࡷࡻࡥ૊")
		YVJPFvuI2CS5KObiZt.sleep(tZ3gsrTEdzA1S6LXa9WI5px(u"࠴੼"))
		bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(shZ9eOcN2dJnPj(u"ࠪࡗࡪࡴࡤࡄ࡮࡬ࡧࡰ࠮࠱࠲ࠫࠪ।"))
	elif showDialogs: xl9MFt1AmY0GrkENug8n(cgtRBdXxSOk7WUfyDhPCls(u"ࠫࠬ॥"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠬ࠭०"),iifPEY9ABNzTQp(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ१"),yF29Xdsx35wI07Ce4(u"ࠧๅๆฦืๆࠦแีๆอࠤ฾๋ไ๋หࠣฮะฮ๊ห๋ࠢฮๆ฿๊ๅࠢส่ั๊ฯࠡษ็้฼๊่ษࠩ२"))
	return V5VXz0j3oa6t
def tj2FJQMlTw(lY0rst72uGVZ1NkgvpjfA6x,showDialogs=iifPEY9ABNzTQp(u"࡙ࡸࡵࡦો")):
	if showDialogs==usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠨࠩ३"): showDialogs = bcgZJWV6UeNSkRA(u"࡚ࡲࡶࡧૌ")
	LaIRncQCmt4xW = VynDoGKfztCiWeI([lY0rst72uGVZ1NkgvpjfA6x])
	lbyFcn5LvHCQ7a3sBD2I10iY9X,ZLRXMGfkUA = LaIRncQCmt4xW[lY0rst72uGVZ1NkgvpjfA6x]
	if ZLRXMGfkUA:
		V5VXz0j3oa6t = ggDRehOModi(u"ࡔࡳࡷࡨ્")
		if showDialogs: xl9MFt1AmY0GrkENug8n(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠩࠪ४"),drHLAY5ENQFe2q9ptKGabo(u"ࠪࠫ५"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ६"),bcgZJWV6UeNSkRA(u"ࠬ็อึࠢส่ส฼วโหࠣࡠࡳࠦࠧ७")+lY0rst72uGVZ1NkgvpjfA6x+vvBChXmSty(u"࠭ࠠ࡝ࡰ๋ࠣีํࠠฤๆศฺฬ็ษࠡ฻้ำ่ࠦๅ้ฮ๋ำฮ่ࠦๆใ฼่ฮ่ࠦอษ๊ึฮࠦไๅษึฮำีวๆࠩ८"))
	else:
		V5VXz0j3oa6t = nKLEi8CJumazx4qT(u"ࡇࡣ࡯ࡷࡪ૎")
		iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠧࡤࡧࡱࡸࡪࡸࠧ९"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠨࠩ॰"),nKLEi8CJumazx4qT(u"ࠩࠪॱ"),Tgoa16jMxvYX2(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ॲ"),Tgoa16jMxvYX2(u"ࠫࠬॳ")+lY0rst72uGVZ1NkgvpjfA6x+InKG0i2r6hHDvgd(u"ࠬࠦ࡜࡯๊ࠢิ์ࠦรๅวูหๆฯฺ่ࠠา็ࠥเ๊า่ࠢๅ฾๊ษࠡล๋ࠤ฿๐ัࠡ็๋ะํีษࠡ࠰ࠣ๎ัฮࠠหอห๎ฯํว๊ࠡอๅ฾๐ไ่ษ่่ࠣ๐๋ࠠ฻่่ࠥอไษำ้ห๊าฺ่ࠠา็ࠥฮี้ำฬࠤฺำ๊ฮหࠣ࠲ࠥํไࠡฬิ๎ิࠦสฬสํฮࠥ๎สโ฻ํ่ࠥํะ่ࠢส่ส฼วโหࠣห้ศๆࠡมࠪॴ"))
		if iZL6cN3OkM5==Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠵੽"):
			bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(nKLEi8CJumazx4qT(u"࠭ࡉ࡯ࡵࡷࡥࡱࡲࡁࡥࡦࡲࡲ࠭࠭ॵ")+lY0rst72uGVZ1NkgvpjfA6x+M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠧࠪࠩॶ"))
			YVJPFvuI2CS5KObiZt.sleep(cgtRBdXxSOk7WUfyDhPCls(u"࠶੾"))
			bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(ggDRehOModi(u"ࠨࡕࡨࡲࡩࡉ࡬ࡪࡥ࡮ࠬ࠶࠷ࠩࠨॷ"))
			YVJPFvuI2CS5KObiZt.sleep(cgtRBdXxSOk7WUfyDhPCls(u"࠷੿"))
			while bMIascyFJ2x43E0C7glTB91h8qz.getCondVisibility(xuztI5QWEKG70CPNdhk4vo6(u"࡚ࠩ࡭ࡳࡪ࡯ࡸ࠰ࡌࡷࡆࡩࡴࡪࡸࡨࠬࡵࡸ࡯ࡨࡴࡨࡷࡸࡪࡩࡢ࡮ࡲ࡫࠮࠭ॸ")): YVJPFvuI2CS5KObiZt.sleep(bbw2eajMlG(u"࠱઀"))
			FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy = bMIascyFJ2x43E0C7glTB91h8qz.executeJSONRPC(nKLEi8CJumazx4qT(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡄࡨࡩࡵ࡮ࡴ࠰ࡖࡩࡹࡇࡤࡥࡱࡱࡉࡳࡧࡢ࡭ࡧࡧࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡤࡨࡩࡵ࡮ࡪࡦࠥ࠾ࠧ࠭ॹ")+lY0rst72uGVZ1NkgvpjfA6x+pcWq35MED2dtK(u"ࠫࠧ࠲ࠢࡦࡰࡤࡦࡱ࡫ࡤࠣ࠼ࡷࡶࡺ࡫ࡽࡾࠩॺ"))
			if CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠬࡕࡋࠨॻ") in FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy:
				V5VXz0j3oa6t = XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࡖࡵࡹࡪ૏")
				if showDialogs: xl9MFt1AmY0GrkENug8n(nKLEi8CJumazx4qT(u"࠭ࠧॼ"),Tgoa16jMxvYX2(u"ࠧࠨॽ"),pcWq35MED2dtK(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫॾ"),bcgZJWV6UeNSkRA(u"ࠩอ้ࠥ็อึࠢฦ์ࠥะหษ์อࠤศ๎ࠠหใ฼๎้ࠦร้ࠢอัิ๐หࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠤํํ๊ࠡษ็ฦ๋ࠦฬศ้ีอ๊ࠥไศีอาิอๅࠨॿ"))
			elif showDialogs: xl9MFt1AmY0GrkENug8n(qnPgZ9N15G6Oa8UpMASvLk(u"ࠪࠫঀ"),xuztI5QWEKG70CPNdhk4vo6(u"ࠫࠬঁ"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨং"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠭แีๆࠣๅ๏ࠦสฬสํฮࠥษ่ࠡฬไ฽๏๊ࠠฤ๊ࠣฮาี๊ฬࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠥ࠴้ࠠษ็ั้ࠦ็้ࠢอฯอ๐ส่ษࠣ์ฯ็ู๋ๆ๊ห๋ࠥๆࠡะสีัࠦวๅสิ๊ฬ๋ฬࠨঃ"))
	return V5VXz0j3oa6t
def aaIjlCWSmUcANoDtLqH60d(lY0rst72uGVZ1NkgvpjfA6x,UUXu9aqOcSC,showDialogs):
	V5VXz0j3oa6t = OyJ1o4AvmWlB75UkFRX(u"ࡉࡥࡱࡹࡥૐ")
	if showDialogs:
		iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠧࠨ঄"),yF29Xdsx35wI07Ce4(u"ࠨࠩঅ"),shZ9eOcN2dJnPj(u"ࠩࠪআ"),yruHDQOcB97ig(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ই"),InKG0i2r6hHDvgd(u"ุࠫ๎แࠡ์อ้ࠥอไร่ࠣะ้ฮࠠศๆ่่ๆࠦวๅ็ู฾ํ฽ࠠๅๆศฺฬ็ษࠡษ็้฼๊่ษห่่ࠣ๐๋ࠠฬ่ࠤฯัศ๋ฬ๊ࠤ฾๊้ࠡๅ๋ำ๏ࠦ࠮ࠡษ็้้็ࠠใัࠣ๎่๎ๆࠡๅห๎ึ่ࠦใัࠣ๎าะวอࠢห฽฻ࠦวๅ๊ๅฮࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬะ้๏๊ࠠศๆ่่ๆࠦวๅฤ้ࠤฤࠧࠧঈ"))
		if iZL6cN3OkM5!=M6PIj8gl1fno7wcqTksDEBK4bU(u"࠲ઁ"): return cgtRBdXxSOk7WUfyDhPCls(u"ࡊࡦࡲࡳࡦ૑")
	vgDkBwA9SJlFHWba5ZEuVh = sG6DJ2IAY17EbZceRVF(UUXu9aqOcSC,{},showDialogs)
	if vgDkBwA9SJlFHWba5ZEuVh:
		dAQI96bVKJcu2FwjCYiyfU50BN = k1t0JLRsCQ.path.join(gDC5Zva1sxhpHLP8SwoIe3fRlB7t,lY0rst72uGVZ1NkgvpjfA6x)
		DzIGOoUJcZT9tQeuX3RyY(dAQI96bVKJcu2FwjCYiyfU50BN,bcgZJWV6UeNSkRA(u"࡚ࡲࡶࡧ૓"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࡋࡧ࡬ࡴࡧ૒"))
		import zipfile as AMVZfRqdO5KmeH,io as nqxTZ31F4tgeocvCsbU9Wy6
		E3rKgzck0qZJY = nqxTZ31F4tgeocvCsbU9Wy6.BytesIO(vgDkBwA9SJlFHWba5ZEuVh)
		try:
			Wyd96fINtOxvhLZJrn2Qcw54YFRAE = AMVZfRqdO5KmeH.ZipFile(E3rKgzck0qZJY)
			Wyd96fINtOxvhLZJrn2Qcw54YFRAE.extractall(gDC5Zva1sxhpHLP8SwoIe3fRlB7t)
			YVJPFvuI2CS5KObiZt.sleep(XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠳ં"))
			bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(yF29Xdsx35wI07Ce4(u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩউ"))
			YVJPFvuI2CS5KObiZt.sleep(nKLEi8CJumazx4qT(u"࠵ઃ"))
			FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy = bMIascyFJ2x43E0C7glTB91h8qz.executeJSONRPC(cgtRBdXxSOk7WUfyDhPCls(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡇࡤࡥࡱࡱࡷ࠳࡙ࡥࡵࡃࡧࡨࡴࡴࡅ࡯ࡣࡥࡰࡪࡪࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡧࡤࡥࡱࡱ࡭ࡩࠨ࠺ࠣࠩঊ")+lY0rst72uGVZ1NkgvpjfA6x+KKbpxUZnMcj6AJ4QdD(u"ࠧࠣ࠮ࠥࡩࡳࡧࡢ࡭ࡧࡧࠦ࠿ࡺࡲࡶࡧࢀࢁࠬঋ"))
			if cgtRBdXxSOk7WUfyDhPCls(u"ࠨࡑࡎࠫঌ") in FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy: V5VXz0j3oa6t = pcWq35MED2dtK(u"ࡔࡳࡷࡨ૔")
			ZqlR5BFQ6pm0asCHLUc(bpNSygerL10j4IOkEfuVw,usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ঍"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠪࡅࡉࡊࡏࡏࡕࡢࡈࡊ࡚ࡁࡊࡎࡖࠫ঎"))
		except: V5VXz0j3oa6t = nKLEi8CJumazx4qT(u"ࡇࡣ࡯ࡷࡪ૕")
	if showDialogs:
		if V5VXz0j3oa6t: xl9MFt1AmY0GrkENug8n(ggDRehOModi(u"ࠫࠬএ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠬ࠭ঐ"),OyJ1o4AvmWlB75UkFRX(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ঑"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠧห็ࠣฬ๋าวฮࠢอฯอ๐สࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠫ঒"))
		else: xl9MFt1AmY0GrkENug8n(cgtRBdXxSOk7WUfyDhPCls(u"ࠨࠩও"),ggDRehOModi(u"ࠩࠪঔ"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ক"),bcgZJWV6UeNSkRA(u"้๊ࠫริใࠣๅู๊สࠡ฻่่๏ฯࠠหอห๎ฯࠦวๅวูหๆฯࠠศๆ่฻้๎ศสࠩখ"))
	return V5VXz0j3oa6t
def DyiGnpNLWIXeFUw(lY0rst72uGVZ1NkgvpjfA6x,showDialogs,FFsCkmPu970WoRMBO2):
	iZL6cN3OkM5,V5VXz0j3oa6t,UueF2YJP9akb7Z,j0Bh7vkYJtpCSP = usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࡗࡶࡺ࡫૗"),xuztI5QWEKG70CPNdhk4vo6(u"ࡈࡤࡰࡸ࡫૖"),pcWq35MED2dtK(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬগ"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠭ࠧঘ")
	u9q1RZQYpdDUA = FWagyi9bX8LRexDPmArjVZfdNK([lY0rst72uGVZ1NkgvpjfA6x])
	if lY0rst72uGVZ1NkgvpjfA6x in list(u9q1RZQYpdDUA.keys()):
		ic2VMr7wJYbK3x6RSlOW,j0Bh7vkYJtpCSP,GN8LC7cw5iUyv3QnfKMTE41kOe,lpTcW8Oy4mNKED31JP7oX,dsNK9gGzmxLD786vyC,ZeLkvRsNmVzWg5Fdj,UUXu9aqOcSC = u9q1RZQYpdDUA[lY0rst72uGVZ1NkgvpjfA6x]
		if ZeLkvRsNmVzWg5Fdj==M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠧࡨࡱࡲࡨࠬঙ"):
			V5VXz0j3oa6t,UueF2YJP9akb7Z = cgtRBdXxSOk7WUfyDhPCls(u"ࡘࡷࡻࡥ૘"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠨࡰࡲࡸ࡭࡯࡮ࡨࠩচ")
			if FFsCkmPu970WoRMBO2: xl9MFt1AmY0GrkENug8n(pcWq35MED2dtK(u"ࠩࠪছ"),pcWq35MED2dtK(u"ࠪࠫজ"),bcgZJWV6UeNSkRA(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧঝ"),cgtRBdXxSOk7WUfyDhPCls(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢๆ์ิ๐๋ࠠีอาิ๋ࠠฤะิࠤส฻ฯศำ้ࠣฯ๎แาࠢไ๎๋่ࠥศไ฼ࠤู๊ส้ั฼ࠤ฾๋วะࠢ็๋ีํࠠศๆศฺฬ็ษ࡝ࡰ࡟ࡲࠬঞ")+lY0rst72uGVZ1NkgvpjfA6x)
		else:
			if showDialogs:
				if ZeLkvRsNmVzWg5Fdj==ggDRehOModi(u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࡤࠨট"): MLPwxur5kaYlBtqcn = xuztI5QWEKG70CPNdhk4vo6(u"ࠧๆฬ๋ๆๆฯࠧঠ")
				elif ZeLkvRsNmVzWg5Fdj==qnPgZ9N15G6Oa8UpMASvLk(u"ࠨࡱ࡯ࡨࠬড"): MLPwxur5kaYlBtqcn = pcWq35MED2dtK(u"ࠩๅำ๏๋ษࠨঢ")
				elif ZeLkvRsNmVzWg5Fdj==cgtRBdXxSOk7WUfyDhPCls(u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫণ"): MLPwxur5kaYlBtqcn = cgtRBdXxSOk7WUfyDhPCls(u"ࠫ฿๐ัࠡ็ฮฬฯฯࠧত")
				iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠬ࠭থ"),pcWq35MED2dtK(u"࠭ࠧদ"),bbw2eajMlG(u"ࠧࠨধ"),cgtRBdXxSOk7WUfyDhPCls(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫন"),drHLAY5ENQFe2q9ptKGabo(u"๊ࠩิ์ࠦวๅวูหๆฯࠠࠨ঩")+MLPwxur5kaYlBtqcn+JLoPRXt93dpAB(u"ࠪࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡวุ่ฬำ่ࠠา๊ࠤฬ๊ๅีๅ็อࠥลࠡ࡝ࡰ࡟ࡲࠬপ")+lY0rst72uGVZ1NkgvpjfA6x)
			if not iZL6cN3OkM5: UueF2YJP9akb7Z = wwplD0tEehqH3kYQXs(u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠭ফ")
			else:
				if ZeLkvRsNmVzWg5Fdj==iifPEY9ABNzTQp(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧব"):
					vS7JufTVsBxw52 = bMIascyFJ2x43E0C7glTB91h8qz.executeJSONRPC(OyJ1o4AvmWlB75UkFRX(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡇࡤࡥࡱࡱࡷ࠳࡙ࡥࡵࡃࡧࡨࡴࡴࡅ࡯ࡣࡥࡰࡪࡪࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡧࡤࡥࡱࡱ࡭ࡩࠨ࠺ࠣࠩভ")+lY0rst72uGVZ1NkgvpjfA6x+qnPgZ9N15G6Oa8UpMASvLk(u"ࠧࠣ࠮ࠥࡩࡳࡧࡢ࡭ࡧࡧࠦ࠿ࡺࡲࡶࡧࢀࢁࠬম"))
					if tZ3gsrTEdzA1S6LXa9WI5px(u"ࠨࡑࡎࠫয") in vS7JufTVsBxw52:
						V5VXz0j3oa6t,UueF2YJP9akb7Z = iifPEY9ABNzTQp(u"࡙ࡸࡵࡦ૙"),cgtRBdXxSOk7WUfyDhPCls(u"ࠩࡨࡲࡦࡨ࡬ࡦࡦࠪর")
						if showDialogs: xl9MFt1AmY0GrkENug8n(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠪࠫ঱"),PtXn0k9G3ocHRg(u"ࠫࠬল"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ঳"),BGhdkWsEvJjiMFTr3NLn1flU(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้หึศใฬࠤ่อๆห่ࠢฮํ่แสࠢ࠱࠲ࠥ๎โศ็ࠣห้ฮั็ษ่ะࠥฮสี฼ํ่์อ࡜࡯࡞ࡱࠫ঴")+lY0rst72uGVZ1NkgvpjfA6x)
					elif showDialogs: xl9MFt1AmY0GrkENug8n(iifPEY9ABNzTQp(u"ࠧࠨ঵"),xuztI5QWEKG70CPNdhk4vo6(u"ࠨࠩশ"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬষ"),bbw2eajMlG(u"่้ࠪษำโࠢ࠱࠲ࠥอไฦุสๅฮࠦๅห๊ๅๅฮࠦ࠮࠯๋่๊๊ࠢࠦิฬฺ๎฾ࠦวๅสิ๊ฬ๋ฬࠡฬื฾๏๊็ศ࡞ࡱࡠࡳ࠭স")+lY0rst72uGVZ1NkgvpjfA6x)
				elif ZeLkvRsNmVzWg5Fdj in [iifPEY9ABNzTQp(u"ࠫࡴࡲࡤࠨহ"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࠬࡳࡩࡴࡵ࡬ࡲ࡬࠭঺")]:
					V5VXz0j3oa6t = aaIjlCWSmUcANoDtLqH60d(lY0rst72uGVZ1NkgvpjfA6x,UUXu9aqOcSC,PtXn0k9G3ocHRg(u"ࡌࡡ࡭ࡵࡨ૚"))
					if V5VXz0j3oa6t:
						if ZeLkvRsNmVzWg5Fdj==tZ3gsrTEdzA1S6LXa9WI5px(u"࠭࡯࡭ࡦࠪ঻"): UueF2YJP9akb7Z = InKG0i2r6hHDvgd(u"ࠧࡶࡲࡧࡥࡹ࡫ࡤࠨ়")
						elif ZeLkvRsNmVzWg5Fdj==KKbpxUZnMcj6AJ4QdD(u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩঽ"): UueF2YJP9akb7Z = yruHDQOcB97ig(u"ࠩ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠬা")
						j0Bh7vkYJtpCSP = lpTcW8Oy4mNKED31JP7oX
						if showDialogs:
							if UueF2YJP9akb7Z==usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠪࡹࡵࡪࡡࡵࡧࡧࠫি"): xl9MFt1AmY0GrkENug8n(pcWq35MED2dtK(u"ࠫࠬী"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠬ࠭ু"),yruHDQOcB97ig(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩূ"),PtXn0k9G3ocHRg(u"ࠧอ์าࠤัีวࠡ࠰࠱ࠤฬ๊ลืษไอ้ࠥว็ฬࠣๆิ๐ๅสࠢ࠱࠲ࠥ๎วๅสิ๊ฬ๋ฬࠡไส้ࠥฮสฮัํฯ์อ࡜࡯࡞ࡱࠫৃ")+lY0rst72uGVZ1NkgvpjfA6x)
							elif UueF2YJP9akb7Z==tZ3gsrTEdzA1S6LXa9WI5px(u"ࠨ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠫৄ"): xl9MFt1AmY0GrkENug8n(usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩࠪ৅"),shZ9eOcN2dJnPj(u"ࠪࠫ৆"),OyJ1o4AvmWlB75UkFRX(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧে"),Tgoa16jMxvYX2(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢส่ส฼วโห่๊ࠣࠦสไ่้ࠣํา่ะหࠣๅ๏ࠦใ้ัํࠤ࠳࠴้ࠠษ็ฬึ์วๆฮࠣๆฬ๋ࠠษฬฮฬ๏ะ็ศ࡞ࡱࡠࡳ࠭ৈ")+lY0rst72uGVZ1NkgvpjfA6x)
					elif showDialogs: xl9MFt1AmY0GrkENug8n(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠭ࠧ৉"),nKLEi8CJumazx4qT(u"ࠧࠨ৊"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫো"),Tgoa16jMxvYX2(u"ࠩ็่ศูแࠡ࠰࠱ࠤฬ๊ศา่ส้ัࠦไๆࠢํืฯ฽ฺ๊ࠢอัิ๐หࠡล๋ࠤฯัศ๋ฬ๋ࠣีํࠠศๆศฺฬ็ษ࡝ࡰ࡟ࡲࠬৌ")+lY0rst72uGVZ1NkgvpjfA6x)
	elif showDialogs: xl9MFt1AmY0GrkENug8n(iifPEY9ABNzTQp(u"্ࠪࠫ"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࠫࠬৎ"),wwplD0tEehqH3kYQXs(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ৏"),M6PIj8gl1fno7wcqTksDEBK4bU(u"࠭ไๅลึๅࠥ࠴࠮้ࠡำ๋ࠥอไฦุสๅฮฺ๋ࠦำ้ࠣํา่ะหࠣๅ๏ࠦๅ้ษๅ฽๋ࠥำห๊า฽ࠥ฿ๅศัࠣ࠲࠳่ࠦๅ้ำห๊ࠥวࠡ์ึฮ฼๐ูࠡษ็ฬึ์วๆฮࠣว๋๊ࠦใ๊่ࠤอะหษ์อࠤ์ึ็ࠡษ็ษ฻อแสࠢฦ์ࠥะอะ์ฮ๋ฬࡢ࡮࡝ࡰࠪ৐")+lY0rst72uGVZ1NkgvpjfA6x)
	return V5VXz0j3oa6t,UueF2YJP9akb7Z,j0Bh7vkYJtpCSP
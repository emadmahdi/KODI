# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'ARABICTOONS'
tiCRYyX1bWd40Ir3PafQu = '_ART_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==730: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==731: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url)
	elif mode==732: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==733: vS7JufTVsBxw52 = GA2KIlbOsoYtxpkDF71(url)
	elif mode==734: vS7JufTVsBxw52 = KKxHo4mlMk3RyngJALtYESwcI0OpZ(url)
	elif mode==735: vS7JufTVsBxw52 = GIaY5rUTDMbvup(url)
	elif mode==739: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',739,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'مسلسلات مميزة',yONJxHER9BIDPpTV4YsWmc0n+'/top.php',735)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'مسلسلات',yONJxHER9BIDPpTV4YsWmc0n+'/cartoon.php',734)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'افلام',yONJxHER9BIDPpTV4YsWmc0n+'/movies.php',731)
	return
def KKxHo4mlMk3RyngJALtYESwcI0OpZ(url):
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الكل',url,731)
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','ARABICTOONS-SERIES_SUBMENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('label="navigation"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall("href='(.*?)'>(.*?)</a>",lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/'+ekTrZlFMu0Kf5QztEnhAs
			title = 'حرف '+title
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,731)
	return
def GIaY5rUTDMbvup(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','ARABICTOONS-SERIES_FEATURED-2nd')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="slider"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for title,ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM in items:
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/'+ekTrZlFMu0Kf5QztEnhAs
			pGjsvdyHfM = yONJxHER9BIDPpTV4YsWmc0n+'/'+pGjsvdyHfM
			title = title.strip(' ')
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,733,pGjsvdyHfM)
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','ARABICTOONS-TITLES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall("class='moviesBlocks(.*?)navigation",oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('class="movie".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
		ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/'+ekTrZlFMu0Kf5QztEnhAs
		pGjsvdyHfM = yONJxHER9BIDPpTV4YsWmc0n+'/'+pGjsvdyHfM
		title = title.strip(' ')
		if 'movies.php' in url: uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,732,pGjsvdyHfM)
		else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,733,pGjsvdyHfM)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"pagination(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[-1]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/'+ekTrZlFMu0Kf5QztEnhAs
			title = title.strip(' ')
			title = uTUNPkVwCMKiD5gHLaj(title)
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+title,ekTrZlFMu0Kf5QztEnhAs,731)
	return
def GA2KIlbOsoYtxpkDF71(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','ARABICTOONS-EPISODES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall("class='moviesBlocks(.*?)script",oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('class="movie".*?title="(.*?)".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for title,ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,AqX02CoEgnyVTHYWJ in items:
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/'+ekTrZlFMu0Kf5QztEnhAs
			pGjsvdyHfM = yONJxHER9BIDPpTV4YsWmc0n+'/'+pGjsvdyHfM
			title = title.strip(' ')
			title = title+' '+AqX02CoEgnyVTHYWJ.strip(' ')
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,732,pGjsvdyHfM)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	GnuaoT9MxiCg = []
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','ARABICTOONS-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	lQUf3AY258LeWch = u5h2Rckvw1E.findall('source src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if lQUf3AY258LeWch:
		ekTrZlFMu0Kf5QztEnhAs = lQUf3AY258LeWch[0]
		if 'Referer=' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'|Referer=https://www.arabic-toons.com'
		GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs+'?named=__embed')
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(GnuaoT9MxiCg,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	search = search.replace(' ','%20')
	EaBeVhOsHYg8wub = ['','m']
	qUTPXnBoegj5QybG1t0VNJxv6u = ['مسلسلات','افلام']
	if showDialogs:
		u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = tYysxJLreEBDdXMIjz4OPa('اختر النوع المطلوب:', qUTPXnBoegj5QybG1t0VNJxv6u)
		if u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo==-1: return
	else: u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = 0
	type = EaBeVhOsHYg8wub[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
	url = yONJxHER9BIDPpTV4YsWmc0n+'/livesearch.php?'+type+'&q='+search
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','ARABICTOONS-SEARCH-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/'+ekTrZlFMu0Kf5QztEnhAs
		title = title.strip(' ')
		if type=='m': uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,732)
		else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,733)
	return
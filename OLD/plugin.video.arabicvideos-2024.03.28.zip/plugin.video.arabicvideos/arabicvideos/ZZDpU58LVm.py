# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'CIMACLUB'
tiCRYyX1bWd40Ir3PafQu = '_CCB_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['عروض المصارعه','للكبار فقط +18','الرئيسية','افلام للكبار فقط','DMCA']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,BzbaC0qYjMr2WXwsO,text):
	if   mode==820: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==821: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,BzbaC0qYjMr2WXwsO)
	elif mode==822: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==823: vS7JufTVsBxw52 = ZN3Wh7HABLwRIkFmyEd1Jq(url,text)
	elif mode==824: vS7JufTVsBxw52 = WYxFZIrRp6b(url,'FULL_FILTER___'+text)
	elif mode==825: vS7JufTVsBxw52 = WYxFZIrRp6b(url,'DEFINED_FILTER___'+text)
	elif mode==829: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',yONJxHER9BIDPpTV4YsWmc0n,'','','','','CIMACLUB-MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	NDwLctrHpYz3JBP = RoQL91PphqCJg4W0e6Fnsl.url
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع',NDwLctrHpYz3JBP,829,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'المميزة',NDwLctrHpYz3JBP+'/sliderhome.php',821,'','featured','_REMEMBERRESULTS_')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"Tabs"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('get="(.*?)".*?<span>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for data,title in items:
			ekTrZlFMu0Kf5QztEnhAs = NDwLctrHpYz3JBP+'/getposts?type=one&data='+data
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,821,'','highest')
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('navigation-menu(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if '/' not in ekTrZlFMu0Kf5QztEnhAs: continue
			if title in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
			ekTrZlFMu0Kf5QztEnhAs = NDwLctrHpYz3JBP+ekTrZlFMu0Kf5QztEnhAs
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,821)
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,type=''):
	NDwLctrHpYz3JBP = hmcFWJUgiAuGk(url,'url')
	lmO2YJGr6tCV,items = '',[]
	if type=='featured':
		headers = {'Content-Type':'application/x-www-form-urlencoded'}
		nD70jhRb8C9Gi = 'get'
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'POST',url,nD70jhRb8C9Gi,headers,'','','CIMACLUB-TITLES-1st')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		items = u5h2Rckvw1E.findall('"image":"(.*?)".*?"title":"(.*?)".*?"url":"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		IaCMxb1GnU6ijWscL,YMpoGJSqdLFkvb4WRuZNa65,lQUf3AY258LeWch = zip(*items)
		items = zip(lQUf3AY258LeWch,IaCMxb1GnU6ijWscL,YMpoGJSqdLFkvb4WRuZNa65)
	elif type=='highest':
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','CIMACLUB-TITLES-2nd')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	else:
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','CIMACLUB-TITLES-3rd')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('media-block(.*?)footer-menu',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi: lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	if not lmO2YJGr6tCV: lmO2YJGr6tCV = oo9SgGkiDbs3HRn7z8
	if not items: items = u5h2Rckvw1E.findall('content-box.*?href="(.*?)".*?src="(.*?)".*?<h3>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	qAXDbplxsjnd3JLTV5eO = []
	for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
		ekTrZlFMu0Kf5QztEnhAs = NDwLctrHpYz3JBP+ekTrZlFMu0Kf5QztEnhAs.replace('\/','/')
		pGjsvdyHfM = pGjsvdyHfM.replace('\/','/')
		ekTrZlFMu0Kf5QztEnhAs = ffbxegm1XPSqIwp8i(ekTrZlFMu0Kf5QztEnhAs)
		title = ffbxegm1XPSqIwp8i(title)
		if '/episode/' in ekTrZlFMu0Kf5QztEnhAs:
			UwQK685R0SpOCmVIagWJ = u5h2Rckvw1E.findall('(.*?) (موسم|الموسم)',title,u5h2Rckvw1E.DOTALL)
			if UwQK685R0SpOCmVIagWJ: title = UwQK685R0SpOCmVIagWJ[0][0]
			else:
				zAjwuoRY98mXN6xvE = u5h2Rckvw1E.findall('(.*?) (حلقة|الحلقة)',title,u5h2Rckvw1E.DOTALL)
				if zAjwuoRY98mXN6xvE: title = zAjwuoRY98mXN6xvE[0][0]
			if title in qAXDbplxsjnd3JLTV5eO: continue
			qAXDbplxsjnd3JLTV5eO.append(title)
			title = '_MOD_'+title.strip(' – ')
		if '/episodes' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,821,pGjsvdyHfM)
		elif '/seasons' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,821,pGjsvdyHfM)
		elif '/serie/' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,823,pGjsvdyHfM)
		elif '/anime-serie/' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,823,pGjsvdyHfM)
		elif '/season/' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,823,pGjsvdyHfM)
		elif '/episode/' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,823,pGjsvdyHfM)
		else: uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,822,pGjsvdyHfM)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('pagination(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			ekTrZlFMu0Kf5QztEnhAs = NDwLctrHpYz3JBP+ekTrZlFMu0Kf5QztEnhAs
			if title: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+title,ekTrZlFMu0Kf5QztEnhAs,821)
	return
def ZN3Wh7HABLwRIkFmyEd1Jq(url,rBOCITLay7XvDlcnjf5):
	NDwLctrHpYz3JBP = hmcFWJUgiAuGk(url,'url')
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','CIMACLUB-SEASONS_EPISODES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	pGjsvdyHfM = u5h2Rckvw1E.findall('poster-image.*?src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	pGjsvdyHfM = pGjsvdyHfM[0] if pGjsvdyHfM else ''
	items = []
	if not rBOCITLay7XvDlcnjf5:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"Seasons"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('<li.*?data-season="(.*?)" data-S="(.*?)" data-B="(.*?)".*?title="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			if len(items)>1:
				for rBOCITLay7XvDlcnjf5,oOFwhezDTMIiJ69NgQa,x39YIprMgBLbCS2oATNEsKXJ5RtqG7,title in items:
					title = title.replace('  ',' ')
					ekTrZlFMu0Kf5QztEnhAs = NDwLctrHpYz3JBP+'/ajaxCenter?_action=GetSeasonEp&_season='+rBOCITLay7XvDlcnjf5+'&_S='+oOFwhezDTMIiJ69NgQa+'&_B='+x39YIprMgBLbCS2oATNEsKXJ5RtqG7
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,823,pGjsvdyHfM,'',rBOCITLay7XvDlcnjf5)
	if len(items)<2:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"Episodes selected"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi: kRC5TbjVpri6nwQxvgzSOhLEsql2UH,lmO2YJGr6tCV = '',cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		else: kRC5TbjVpri6nwQxvgzSOhLEsql2UH,lmO2YJGr6tCV = 'موسم '+rBOCITLay7XvDlcnjf5,oo9SgGkiDbs3HRn7z8
		items = u5h2Rckvw1E.findall('href="(.*?)" title="(.*?)"><em>(.*?)</em>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title,zAjwuoRY98mXN6xvE in items:
			ekTrZlFMu0Kf5QztEnhAs = NDwLctrHpYz3JBP+ekTrZlFMu0Kf5QztEnhAs
			title = kRC5TbjVpri6nwQxvgzSOhLEsql2UH+' حلقة '+zAjwuoRY98mXN6xvE.strip(' ')
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,822,pGjsvdyHfM)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	url = url.replace('/episode/','/watch/').replace('/anime/','/watch/').replace('/movie/','/watch/')
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','CIMACLUB-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	GnuaoT9MxiCg,ZIB1Cc3wFoi5xYNgOThn2mAM = [],[]
	ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('player-wraper.*?src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if ekTrZlFMu0Kf5QztEnhAs:
		ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs[0]
		ZIB1Cc3wFoi5xYNgOThn2mAM.append(ekTrZlFMu0Kf5QztEnhAs)
		NDwLctrHpYz3JBP = hmcFWJUgiAuGk(ekTrZlFMu0Kf5QztEnhAs,'name')
		GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs+'?named='+NDwLctrHpYz3JBP+'__embed')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('servers-tabs(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('data-embedd="(.*?)".*?<em>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.split('&img=',1)[0]
			title = title.strip(' ')
			if ekTrZlFMu0Kf5QztEnhAs not in ZIB1Cc3wFoi5xYNgOThn2mAM:
				ZIB1Cc3wFoi5xYNgOThn2mAM.append(ekTrZlFMu0Kf5QztEnhAs)
				GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs+'?named='+title+'__watch')
	items = u5h2Rckvw1E.findall('download-block.*?href="(.*?)".*?<h3>(.*?)</h3>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		if ekTrZlFMu0Kf5QztEnhAs not in ZIB1Cc3wFoi5xYNgOThn2mAM:
			ZIB1Cc3wFoi5xYNgOThn2mAM.append(ekTrZlFMu0Kf5QztEnhAs)
			title = title.replace('<span>',' ').replace('</span>','').replace('<i>','').replace('</i>',' ')
			title = title.strip(' ')
			GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs+'?named='+title+'__download')
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(GnuaoT9MxiCg,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if not search: search = FBrXsYeCEp3()
	if not search: return
	search = search.replace(' ','+')
	url = yONJxHER9BIDPpTV4YsWmc0n+'/search?s='+search
	ll0a2AwztChcpsDUMi4rGW3b61XZES(url,'search')
	return
def C50mPGacMg7V34she6UR8LjfSt1(url):
	url = url.split('/smartemadfilter?')[0]
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',url,'','','','','CIMACLUB-GET_FILTERS_BLOCKS-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cGdHRiwvptVXQlzE8ZUgB0aJo9x = []
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('advanced-search(.*?)</form>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		cGdHRiwvptVXQlzE8ZUgB0aJo9x = u5h2Rckvw1E.findall('select-menu">.*?">(.*?)<.*?data-tax="(.*?)"(.*?)</ul>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		woSL8eJ219qdksrZFIaPA,r502OcNXkfwEI1suJF8mWTK9Vp7RlA,ppZ9muD1GkPnFRX52jxBUIy = zip(*cGdHRiwvptVXQlzE8ZUgB0aJo9x)
		cGdHRiwvptVXQlzE8ZUgB0aJo9x = zip(woSL8eJ219qdksrZFIaPA,r502OcNXkfwEI1suJF8mWTK9Vp7RlA,ppZ9muD1GkPnFRX52jxBUIy)
	return cGdHRiwvptVXQlzE8ZUgB0aJo9x
def zzsLCt0FpUQEeMoYWBqGlZJP6rn4(lmO2YJGr6tCV):
	items = u5h2Rckvw1E.findall('cat="(.*?)".*?bold">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	return items
def BiOwcEL7XY1Fa5nWJ(url):
	NDwLctrHpYz3JBP = hmcFWJUgiAuGk(url,'url')
	if '/smartemadfilter?' in url:
		url,cGYIMSHDj85d3f4ZW2t0bnNkKP = url.split('/smartemadfilter?')
		ekTrZlFMu0Kf5QztEnhAs = NDwLctrHpYz3JBP+'/getposts?'+cGYIMSHDj85d3f4ZW2t0bnNkKP
	else: ekTrZlFMu0Kf5QztEnhAs = NDwLctrHpYz3JBP
	return ekTrZlFMu0Kf5QztEnhAs
lKLq39dBYWsOr7kGypxM6Dw = ['category','release-year','genre','quality']
FAbV2PnyJD8M0UowB9hRS4TkN = ['category','release-year','genre']
def WYxFZIrRp6b(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': lvUP2GeNjyVOHKJxcBoun3Z,MoELTBDgQeaJrl0zYUmKCH = '',''
	else: lvUP2GeNjyVOHKJxcBoun3Z,MoELTBDgQeaJrl0zYUmKCH = filter.split('___')
	if type=='DEFINED_FILTER':
		if FAbV2PnyJD8M0UowB9hRS4TkN[0]+'=' not in lvUP2GeNjyVOHKJxcBoun3Z: oPrhaMp7AqmNnRjlXGI = FAbV2PnyJD8M0UowB9hRS4TkN[0]
		for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(len(FAbV2PnyJD8M0UowB9hRS4TkN[0:-1])):
			if FAbV2PnyJD8M0UowB9hRS4TkN[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE]+'=' in lvUP2GeNjyVOHKJxcBoun3Z: oPrhaMp7AqmNnRjlXGI = FAbV2PnyJD8M0UowB9hRS4TkN[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE+1]
		WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&'+oPrhaMp7AqmNnRjlXGI+'=0'
		z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&'+oPrhaMp7AqmNnRjlXGI+'=0'
		bIYSyA3BD1o4 = WGiMcqkRetEJVrSI.strip('&')+'___'+z3wGSEWqVy1Qh5N.strip('&')
		TBFfiRI52ZmKwO1JLSD = mltWBSPJz5H4VRdCAa1(MoELTBDgQeaJrl0zYUmKCH,'modified_filters')
		gANn35esloKUydOipfSMC6RD2 = url+'/smartemadfilter?'+TBFfiRI52ZmKwO1JLSD
	elif type=='FULL_FILTER':
		lv2uANOtVxE8RTa7bYHqLog1Bd = mltWBSPJz5H4VRdCAa1(lvUP2GeNjyVOHKJxcBoun3Z,'modified_values')
		lv2uANOtVxE8RTa7bYHqLog1Bd = P2o6ZDHeW790pSQqucvnxzILVUX(lv2uANOtVxE8RTa7bYHqLog1Bd)
		if MoELTBDgQeaJrl0zYUmKCH: MoELTBDgQeaJrl0zYUmKCH = mltWBSPJz5H4VRdCAa1(MoELTBDgQeaJrl0zYUmKCH,'modified_filters')
		if not MoELTBDgQeaJrl0zYUmKCH: gANn35esloKUydOipfSMC6RD2 = url
		else: gANn35esloKUydOipfSMC6RD2 = url+'/smartemadfilter?'+MoELTBDgQeaJrl0zYUmKCH
		UcmHDPlLWaSf = BiOwcEL7XY1Fa5nWJ(gANn35esloKUydOipfSMC6RD2)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'أظهار قائمة الفيديو التي تم اختيارها ',UcmHDPlLWaSf,821,'','filter')
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+' [[   '+lv2uANOtVxE8RTa7bYHqLog1Bd+'   ]]',UcmHDPlLWaSf,821,'','filter')
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cGdHRiwvptVXQlzE8ZUgB0aJo9x = C50mPGacMg7V34she6UR8LjfSt1(url)
	dict = {}
	for name,Uiy0XwPusDg4vAFc35oYdfGnOrV,lmO2YJGr6tCV in cGdHRiwvptVXQlzE8ZUgB0aJo9x:
		name = name.replace('كل ','')
		items = zzsLCt0FpUQEeMoYWBqGlZJP6rn4(lmO2YJGr6tCV)
		if '=' not in gANn35esloKUydOipfSMC6RD2: gANn35esloKUydOipfSMC6RD2 = url
		if type=='DEFINED_FILTER':
			if oPrhaMp7AqmNnRjlXGI!=Uiy0XwPusDg4vAFc35oYdfGnOrV: continue
			elif len(items)<2:
				if Uiy0XwPusDg4vAFc35oYdfGnOrV==FAbV2PnyJD8M0UowB9hRS4TkN[-1]:
					UcmHDPlLWaSf = BiOwcEL7XY1Fa5nWJ(gANn35esloKUydOipfSMC6RD2)
					ll0a2AwztChcpsDUMi4rGW3b61XZES(UcmHDPlLWaSf,'filter')
				else: WYxFZIrRp6b(gANn35esloKUydOipfSMC6RD2,'DEFINED_FILTER___'+bIYSyA3BD1o4)
				return
			else:
				if Uiy0XwPusDg4vAFc35oYdfGnOrV==FAbV2PnyJD8M0UowB9hRS4TkN[-1]:
					UcmHDPlLWaSf = BiOwcEL7XY1Fa5nWJ(gANn35esloKUydOipfSMC6RD2)
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع ',UcmHDPlLWaSf,821,'','filter')
				else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع ',gANn35esloKUydOipfSMC6RD2,825,'','',bIYSyA3BD1o4)
		elif type=='FULL_FILTER':
			WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'=0'
			z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'=0'
			bIYSyA3BD1o4 = WGiMcqkRetEJVrSI+'___'+z3wGSEWqVy1Qh5N
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع :'+name,gANn35esloKUydOipfSMC6RD2,824,'','',bIYSyA3BD1o4)
		dict[Uiy0XwPusDg4vAFc35oYdfGnOrV] = {}
		for c2eEflztvIX,q1rVywkMcKftIioS43LY in items:
			if not c2eEflztvIX: continue
			if q1rVywkMcKftIioS43LY in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
			dict[Uiy0XwPusDg4vAFc35oYdfGnOrV][c2eEflztvIX] = q1rVywkMcKftIioS43LY
			WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'='+q1rVywkMcKftIioS43LY
			z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'='+c2eEflztvIX
			eoaO40TC7VF1tEuwjQp2x = WGiMcqkRetEJVrSI+'___'+z3wGSEWqVy1Qh5N
			title = q1rVywkMcKftIioS43LY+' :'#+dict[Uiy0XwPusDg4vAFc35oYdfGnOrV]['0']
			title = q1rVywkMcKftIioS43LY+' :'+name
			if type=='FULL_FILTER': uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,824,'','',eoaO40TC7VF1tEuwjQp2x)
			elif type=='DEFINED_FILTER' and FAbV2PnyJD8M0UowB9hRS4TkN[-2]+'=' in lvUP2GeNjyVOHKJxcBoun3Z:
				TBFfiRI52ZmKwO1JLSD = mltWBSPJz5H4VRdCAa1(z3wGSEWqVy1Qh5N,'modified_filters')
				gANn35esloKUydOipfSMC6RD2 = url+'/smartemadfilter?'+TBFfiRI52ZmKwO1JLSD
				UcmHDPlLWaSf = BiOwcEL7XY1Fa5nWJ(gANn35esloKUydOipfSMC6RD2)
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,UcmHDPlLWaSf,821,'','filter')
			else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,825,'','',eoaO40TC7VF1tEuwjQp2x)
	return
def mltWBSPJz5H4VRdCAa1(cGYIMSHDj85d3f4ZW2t0bnNkKP,mode):
	cGYIMSHDj85d3f4ZW2t0bnNkKP = cGYIMSHDj85d3f4ZW2t0bnNkKP.replace('=&','=0&')
	cGYIMSHDj85d3f4ZW2t0bnNkKP = cGYIMSHDj85d3f4ZW2t0bnNkKP.strip('&')
	OXjBliFSwIQCmg47 = {}
	if '=' in cGYIMSHDj85d3f4ZW2t0bnNkKP:
		items = cGYIMSHDj85d3f4ZW2t0bnNkKP.split('&')
		for TMaJdc0xOFKNf in items:
			b1EWu6sYaRk0FXUx8HVvNBQort43,c2eEflztvIX = TMaJdc0xOFKNf.split('=')
			OXjBliFSwIQCmg47[b1EWu6sYaRk0FXUx8HVvNBQort43] = c2eEflztvIX
	LL3oamJbwkYcNDrH5 = ''
	for key in lKLq39dBYWsOr7kGypxM6Dw:
		if key in list(OXjBliFSwIQCmg47.keys()): c2eEflztvIX = OXjBliFSwIQCmg47[key]
		else: c2eEflztvIX = '0'
		if '%' not in c2eEflztvIX: c2eEflztvIX = QQXTVNve6DMHBp4scG170kR2lWY(c2eEflztvIX)
		if mode=='modified_values' and c2eEflztvIX!='0': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+' + '+c2eEflztvIX
		elif mode=='modified_filters' and c2eEflztvIX!='0': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+'&'+key+'='+c2eEflztvIX
		elif mode=='all': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+'&'+key+'='+c2eEflztvIX
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.strip(' + ')
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.strip('&')
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.replace('=0','=')
	return LL3oamJbwkYcNDrH5
# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'CIMACLUP'
tiCRYyX1bWd40Ir3PafQu = '_CMC_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['موقع نتفليكس']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==490: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==491: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,text)
	elif mode==492: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==493: vS7JufTVsBxw52 = GA2KIlbOsoYtxpkDF71(url)
	elif mode==494: vS7JufTVsBxw52 = GQsDp6PWFHRE1ki2odqrwjB0ISTLh(url)
	elif mode==499: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text,url)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',yONJxHER9BIDPpTV4YsWmc0n,'','','','','CIMACLUP-MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	jGX4sfdrWaeZpA1VyvTK = u5h2Rckvw1E.findall('href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	jGX4sfdrWaeZpA1VyvTK = jGX4sfdrWaeZpA1VyvTK[0].strip('/')
	jGX4sfdrWaeZpA1VyvTK = hmcFWJUgiAuGk(jGX4sfdrWaeZpA1VyvTK,'url')
	RfTOHSzgpA = u5h2Rckvw1E.findall('"filter AjaxifyFilter"(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if RfTOHSzgpA:
		lmO2YJGr6tCV = RfTOHSzgpA[0]
		items = u5h2Rckvw1E.findall('data-filter="(.*?)".*?>(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if title in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
			ekTrZlFMu0Kf5QztEnhAs = jGX4sfdrWaeZpA1VyvTK+'/wp-content/themes/old/filter/'+ekTrZlFMu0Kf5QztEnhAs+'.php'
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,491)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'أفلام',jGX4sfdrWaeZpA1VyvTK+'/category/افلام-movies-filme/foreign-hd-افلام-اجنبى-2',494,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'مسلسلات',jGX4sfdrWaeZpA1VyvTK+'/category/مسلسلات/مسلسلات-اجنبى',494,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="navigation-menu"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		if ekTrZlFMu0Kf5QztEnhAs=='/': continue
		if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = jGX4sfdrWaeZpA1VyvTK+ekTrZlFMu0Kf5QztEnhAs
		if title in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
		uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,491)
	return oo9SgGkiDbs3HRn7z8
def GQsDp6PWFHRE1ki2odqrwjB0ISTLh(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','CIMACLUP-SUBMENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	kQ7LGm5DPnH8hUdtWY = u5h2Rckvw1E.findall('"filter"(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if kQ7LGm5DPnH8hUdtWY:
		lmO2YJGr6tCV = kQ7LGm5DPnH8hUdtWY[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if title in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,491)
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,lcOov4Kz0uBairTpLxXgAqIt72mk=''):
	items = []
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','CIMACLUP-TITLES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	lmO2YJGr6tCV = ''
	if '.php' in url: lmO2YJGr6tCV = oo9SgGkiDbs3HRn7z8
	elif '?s=' in url:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"blocks(.*?)"manifest"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	else:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"Blocks(.*?)"manifest"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	if not lmO2YJGr6tCV: return
	yn8DkpE5etF3WiUmfSO = []
	dR94SHEmDA8nflN = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
		title = uTUNPkVwCMKiD5gHLaj(title)
		zAjwuoRY98mXN6xvE = u5h2Rckvw1E.findall('(.*?) حلقة \d+',title,u5h2Rckvw1E.DOTALL)
		if not zAjwuoRY98mXN6xvE: zAjwuoRY98mXN6xvE = u5h2Rckvw1E.findall('(.*?) الحلقة \d+',title,u5h2Rckvw1E.DOTALL)
		if not zAjwuoRY98mXN6xvE or any(c2eEflztvIX in title for c2eEflztvIX in dR94SHEmDA8nflN):
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,492,pGjsvdyHfM)
		elif zAjwuoRY98mXN6xvE and 'حلقة' in title:
			title = '_MOD_' + zAjwuoRY98mXN6xvE[0]
			if title not in yn8DkpE5etF3WiUmfSO:
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,493,pGjsvdyHfM)
				yn8DkpE5etF3WiUmfSO.append(title)
		else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,493,pGjsvdyHfM)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"pagination"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('<li><a href="(.*?)".*?>(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			title = uTUNPkVwCMKiD5gHLaj(title)
			title = title.replace('الصفحة ','')
			if title!='': uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+title,ekTrZlFMu0Kf5QztEnhAs,491)
	return
def GA2KIlbOsoYtxpkDF71(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','CIMACLUP-EPISODES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	gANn35esloKUydOipfSMC6RD2 = u5h2Rckvw1E.findall('"ButtonsBarCo".*?href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if gANn35esloKUydOipfSMC6RD2:
		gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2[0]
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',gANn35esloKUydOipfSMC6RD2,'','','','','CIMACLUP-EPISODES-2nd')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	pGjsvdyHfM = u5h2Rckvw1E.findall('"img-responsive" src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if pGjsvdyHfM: pGjsvdyHfM = pGjsvdyHfM[0]
	else: pGjsvdyHfM = bMIascyFJ2x43E0C7glTB91h8qz.getInfoLabel('ListItem.Thumb')
	kQ7LGm5DPnH8hUdtWY = u5h2Rckvw1E.findall('"filter"(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	RfTOHSzgpA = u5h2Rckvw1E.findall('"Blocks(.*?)class="pagination"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if kQ7LGm5DPnH8hUdtWY and '/series/' not in url:
		lmO2YJGr6tCV = kQ7LGm5DPnH8hUdtWY[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,493,pGjsvdyHfM)
	elif RfTOHSzgpA:
		lmO2YJGr6tCV = RfTOHSzgpA[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?image\:url\((.*?)\).*?"boxtitle">(.*?)</div>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if items:
			for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
				title = title.strip(' ')
				uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,492,pGjsvdyHfM)
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"pagination"(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,title in items:
				title = uTUNPkVwCMKiD5gHLaj(title)
				title = title.replace('الصفحة ','')
				if title!='': uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+title,ekTrZlFMu0Kf5QztEnhAs,491)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	gANn35esloKUydOipfSMC6RD2 = url.strip('/')+'/?view=1'
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',gANn35esloKUydOipfSMC6RD2,'','','','','CIMACLUP-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	EaBeVhOsHYg8wub = []
	jGX4sfdrWaeZpA1VyvTK = hmcFWJUgiAuGk(url,'url')
	DnkhMBRTKpAvOsyJruQX8bo3aHNjzI = u5h2Rckvw1E.findall("data: 'q=(.*?)&",oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	DnkhMBRTKpAvOsyJruQX8bo3aHNjzI = DnkhMBRTKpAvOsyJruQX8bo3aHNjzI[0]
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"serversList"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('data-server="(.*?)">(.*?)</li>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for Vj0lraYRgKsPMJbitwoNIhe1E,title in items:
			title = title.strip(' ')
			ekTrZlFMu0Kf5QztEnhAs = jGX4sfdrWaeZpA1VyvTK+'/wp-content/themes/old/servers/server.php?q='+DnkhMBRTKpAvOsyJruQX8bo3aHNjzI+'&i='+Vj0lraYRgKsPMJbitwoNIhe1E+'?named='+title+'__watch'
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('"embedServer".*?SRC="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if ekTrZlFMu0Kf5QztEnhAs:
		title = 'مفضل'
		ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs[0]+'?named=__embed__'+title
		EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"downloadsList"(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('<td>(.*?)</td>.*?href="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for title,ekTrZlFMu0Kf5QztEnhAs in items:
			title = title.strip(' ')
			if 'anavidz' in ekTrZlFMu0Kf5QztEnhAs: cMpjL2oavyVwKHBPn8EdhYqxSUk = '__خاص'
			else: cMpjL2oavyVwKHBPn8EdhYqxSUk = ''
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+title+'__download'+cMpjL2oavyVwKHBPn8EdhYqxSUk
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(EaBeVhOsHYg8wub,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search,jGX4sfdrWaeZpA1VyvTK=''):
	if not jGX4sfdrWaeZpA1VyvTK: jGX4sfdrWaeZpA1VyvTK = yONJxHER9BIDPpTV4YsWmc0n
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if not search:
		search = FBrXsYeCEp3()
		if not search: return
	search = search.replace(' ','+')
	url = jGX4sfdrWaeZpA1VyvTK+'/index.php?s='+search
	ll0a2AwztChcpsDUMi4rGW3b61XZES(url)
	return
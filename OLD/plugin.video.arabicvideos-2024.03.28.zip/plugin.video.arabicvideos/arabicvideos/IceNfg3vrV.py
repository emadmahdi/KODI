# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'GLOBALSEARCH'
tiCRYyX1bWd40Ir3PafQu = '_GLS_'
def cc03CYPLaxRfUKJb9eynFTr(wMCm6g9qFyPT0xpneDUNc2lEhaZY,GZdtFyDU0caf89r,kc57B93HrojbDIXVipY,BzbaC0qYjMr2WXwsO):
	if   wMCm6g9qFyPT0xpneDUNc2lEhaZY==540: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==541: vS7JufTVsBxw52 = oLMC8dJSiyXOUxvsQ91Yp2(kc57B93HrojbDIXVipY)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==542: vS7JufTVsBxw52 = vvQGBEjVbCfoZM5LW(kc57B93HrojbDIXVipY,GZdtFyDU0caf89r,BzbaC0qYjMr2WXwsO)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==549: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(kc57B93HrojbDIXVipY)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	uQNUfbZx9yj0F('folder','بحث جديد','',549)
	uQNUfbZx9yj0F('link','[COLOR FFC89008]==== كلمات مخزنة ====[/COLOR]','',9999)
	UJkBKy5vmdu3jrs7ZflgSt = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,'dict','GLOBALSEARCH_SITES')
	if UJkBKy5vmdu3jrs7ZflgSt:
		UJkBKy5vmdu3jrs7ZflgSt = UJkBKy5vmdu3jrs7ZflgSt['__SEQUENCED_COLUMNS__']
		for NweZkm8EIQjpDMUY9XasFGrPicJRb in reversed(UJkBKy5vmdu3jrs7ZflgSt):
			uQNUfbZx9yj0F('folder',NweZkm8EIQjpDMUY9XasFGrPicJRb,'',549,'','',NweZkm8EIQjpDMUY9XasFGrPicJRb)
	return
def bB8m3r5asjpdG0ulEJg(NweZkm8EIQjpDMUY9XasFGrPicJRb):
	if not NweZkm8EIQjpDMUY9XasFGrPicJRb:
		NweZkm8EIQjpDMUY9XasFGrPicJRb = FBrXsYeCEp3()
		if not NweZkm8EIQjpDMUY9XasFGrPicJRb: return
		NweZkm8EIQjpDMUY9XasFGrPicJRb = NweZkm8EIQjpDMUY9XasFGrPicJRb.lower()
	Sel8j25hvodwrVDaGFWKnHcuN3i = NweZkm8EIQjpDMUY9XasFGrPicJRb.replace(tiCRYyX1bWd40Ir3PafQu,'')
	pJxf82SduH7sU(Sel8j25hvodwrVDaGFWKnHcuN3i)
	uQNUfbZx9yj0F('link','عمل بحث جماعي - '+Sel8j25hvodwrVDaGFWKnHcuN3i,'search_sites',542,'','',Sel8j25hvodwrVDaGFWKnHcuN3i)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder','نتائج البحث مفصلة - '+Sel8j25hvodwrVDaGFWKnHcuN3i,'opened_sites',542,'','',Sel8j25hvodwrVDaGFWKnHcuN3i)
	uQNUfbZx9yj0F('folder','نتائج البحث مقسمة - '+Sel8j25hvodwrVDaGFWKnHcuN3i,'listed_sites',542,'','',Sel8j25hvodwrVDaGFWKnHcuN3i)
	uQNUfbZx9yj0F('folder','بحث منفرد - '+Sel8j25hvodwrVDaGFWKnHcuN3i,'',541,'','',Sel8j25hvodwrVDaGFWKnHcuN3i)
	return
def pJxf82SduH7sU(NHA53ydF4xWRwGvCtSJ68eoXcTzj):
	NBRFiTjIDWql4c6SMw0sfQa = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,'list','GLOBALSEARCH_SITES',NHA53ydF4xWRwGvCtSJ68eoXcTzj)
	xNzdA9BUfbg40KHyu6Xjv8QsVplqMW = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,'list','GLOBALSEARCH_SITES',tiCRYyX1bWd40Ir3PafQu+NHA53ydF4xWRwGvCtSJ68eoXcTzj)
	ZqlR5BFQ6pm0asCHLUc(bpNSygerL10j4IOkEfuVw,'GLOBALSEARCH_SITES',NHA53ydF4xWRwGvCtSJ68eoXcTzj)
	ZqlR5BFQ6pm0asCHLUc(bpNSygerL10j4IOkEfuVw,'GLOBALSEARCH_SITES',tiCRYyX1bWd40Ir3PafQu+NHA53ydF4xWRwGvCtSJ68eoXcTzj)
	NLsBcz0PT2V75y = NBRFiTjIDWql4c6SMw0sfQa+xNzdA9BUfbg40KHyu6Xjv8QsVplqMW
	if NLsBcz0PT2V75y: NHA53ydF4xWRwGvCtSJ68eoXcTzj = tiCRYyX1bWd40Ir3PafQu+NHA53ydF4xWRwGvCtSJ68eoXcTzj
	OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,'GLOBALSEARCH_SITES',NHA53ydF4xWRwGvCtSJ68eoXcTzj,NLsBcz0PT2V75y,we9acVgv5HE0mdlXCSj6n7DQ4)
	return
def h0Gl65VT1eROIbY():
	iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0('','','','رسالة من المبرمج','هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if iZL6cN3OkM5!=1: return
	ZqlR5BFQ6pm0asCHLUc(bpNSygerL10j4IOkEfuVw,'GLOBALSEARCH_SITES')
	ZqlR5BFQ6pm0asCHLUc(bpNSygerL10j4IOkEfuVw,'GLOBALSEARCH_OPENED')
	ZqlR5BFQ6pm0asCHLUc(bpNSygerL10j4IOkEfuVw,'GLOBALSEARCH_CLOSED')
	xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def vvQGBEjVbCfoZM5LW(bbyc1giYGsj,jBlCSXIN19a,tzVT6PXndWu0=''):
	RyWsivLcVATGOxmBa9kuUo1H8gnh,jpwrJztXgbn3uVm2Ye,msoDkYg3PfAVW4cSHlIEXB,nFcfLxCbhzKI4SQv,U2Bcu6FWDnIxQOtAmYZgPE,mEL75DWt9kgy,wOBjpc5WV8LoRfTQeFSg73Y = [],[],[],{},{},{},{}
	if jBlCSXIN19a!='search_sites':
		if jBlCSXIN19a=='listed_sites': msoDkYg3PfAVW4cSHlIEXB = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,'list','GLOBALSEARCH_SITES',tiCRYyX1bWd40Ir3PafQu+bbyc1giYGsj)
		elif jBlCSXIN19a=='opened_sites': msoDkYg3PfAVW4cSHlIEXB = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,'list','GLOBALSEARCH_OPENED',bbyc1giYGsj)
		elif jBlCSXIN19a=='closed_sites': msoDkYg3PfAVW4cSHlIEXB = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,'list','GLOBALSEARCH_CLOSED',(tzVT6PXndWu0,bbyc1giYGsj))
	if not msoDkYg3PfAVW4cSHlIEXB:
		cLzOaV56rHkXKmxCy = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		Yw6S1bOqLcECfji7RJetgD = 'هل تريد الآن البحث في جميع المواقع عن \n "[COLOR FFFFFF00] '+bbyc1giYGsj+' [/COLOR]" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if jBlCSXIN19a=='search_sites': MLPwxur5kaYlBtqcn = Yw6S1bOqLcECfji7RJetgD
		else: MLPwxur5kaYlBtqcn = cLzOaV56rHkXKmxCy+Yw6S1bOqLcECfji7RJetgD
		iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0('','','','رسالة من المبرمج',MLPwxur5kaYlBtqcn)
		if iZL6cN3OkM5!=1: return
		PPIXEhN6ofSZLVdJ2wRBHvKCMrx3u(False,False,False)
		l0SAerv8zGH2Wa('NOTICE',CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+'   Search For: [ '+bbyc1giYGsj+' ]')
		YR0S4pjBhdKaN = 1
		for tzVT6PXndWu0 in qqhYHtCpnN:
			nFcfLxCbhzKI4SQv[tzVT6PXndWu0] = []
			O9AyF2MRjI = '_NODIALOGS_'
			if '-' in tzVT6PXndWu0: O9AyF2MRjI = O9AyF2MRjI+'_REMEMBERRESULTS__'+tzVT6PXndWu0+'_'
			lKC9tsMTk1xeVIDmUjwrZzvhP50,lfXd1GQTyCkVSUzAeO,gprYWX3BPb7EVuv4wmlc = BZ60Cr5qARSJYjkD(tzVT6PXndWu0)
			if YR0S4pjBhdKaN:
				YVJPFvuI2CS5KObiZt.sleep(0.5)
				wOBjpc5WV8LoRfTQeFSg73Y[tzVT6PXndWu0] = onVDrgLUpFsqOPkxId9BwW6Rtc5A.Thread(target=lfXd1GQTyCkVSUzAeO,args=(bbyc1giYGsj+O9AyF2MRjI,))
				wOBjpc5WV8LoRfTQeFSg73Y[tzVT6PXndWu0].start()
			else: lfXd1GQTyCkVSUzAeO(bbyc1giYGsj+O9AyF2MRjI)
			dnS80F92qtLi4vw1(wSH84vUOuxYjoQ3aPBeAEZ(tzVT6PXndWu0),'',YVJPFvuI2CS5KObiZt=1000)
		if YR0S4pjBhdKaN:
			YVJPFvuI2CS5KObiZt.sleep(2)
			for tzVT6PXndWu0 in qqhYHtCpnN:
				wOBjpc5WV8LoRfTQeFSg73Y[tzVT6PXndWu0].join(10)
			YVJPFvuI2CS5KObiZt.sleep(2)
		for tzVT6PXndWu0 in qqhYHtCpnN:
			lKC9tsMTk1xeVIDmUjwrZzvhP50,lfXd1GQTyCkVSUzAeO,gprYWX3BPb7EVuv4wmlc = BZ60Cr5qARSJYjkD(tzVT6PXndWu0)
			for ttpQZRUwEjhfdOqn in YD56nkJmsd:
				f0QP7qXsU4L9xtB,WGy8jZubInXc7zRBJ5p,GZdtFyDU0caf89r,wMCm6g9qFyPT0xpneDUNc2lEhaZY,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,kc57B93HrojbDIXVipY,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv = ttpQZRUwEjhfdOqn
				if gprYWX3BPb7EVuv4wmlc in WGy8jZubInXc7zRBJ5p:
					if 'IPTV-' in tzVT6PXndWu0 and (239>=wMCm6g9qFyPT0xpneDUNc2lEhaZY>=230 or 289>=wMCm6g9qFyPT0xpneDUNc2lEhaZY>=280):
						if ttpQZRUwEjhfdOqn in nFcfLxCbhzKI4SQv['IPTV-LIVE']: continue
						if ttpQZRUwEjhfdOqn in nFcfLxCbhzKI4SQv['IPTV-MOVIES']: continue
						if ttpQZRUwEjhfdOqn in nFcfLxCbhzKI4SQv['IPTV-SERIES']: continue
						if 'صفحة' not in WGy8jZubInXc7zRBJ5p:
							if   f0QP7qXsU4L9xtB=='live': tzVT6PXndWu0 = 'IPTV-LIVE'
							elif f0QP7qXsU4L9xtB=='video': tzVT6PXndWu0 = 'IPTV-MOVIES'
							elif f0QP7qXsU4L9xtB=='folder': tzVT6PXndWu0 = 'IPTV-SERIES'
						else:
							if   'LIVE' in GZdtFyDU0caf89r: tzVT6PXndWu0 = 'IPTV-LIVE'
							elif 'MOVIES' in GZdtFyDU0caf89r: tzVT6PXndWu0 = 'IPTV-MOVIES'
							elif 'SERIES' in GZdtFyDU0caf89r: tzVT6PXndWu0 = 'IPTV-SERIES'
					elif 'M3U-' in tzVT6PXndWu0 and 729>=wMCm6g9qFyPT0xpneDUNc2lEhaZY>=710:
						if ttpQZRUwEjhfdOqn in nFcfLxCbhzKI4SQv['M3U-LIVE']: continue
						if ttpQZRUwEjhfdOqn in nFcfLxCbhzKI4SQv['M3U-MOVIES']: continue
						if ttpQZRUwEjhfdOqn in nFcfLxCbhzKI4SQv['M3U-SERIES']: continue
						if 'صفحة' not in WGy8jZubInXc7zRBJ5p:
							if   f0QP7qXsU4L9xtB=='live': tzVT6PXndWu0 = 'M3U-LIVE'
							elif f0QP7qXsU4L9xtB=='video': tzVT6PXndWu0 = 'M3U-MOVIES'
							elif f0QP7qXsU4L9xtB=='folder': tzVT6PXndWu0 = 'M3U-SERIES'
						else:
							if   'LIVE' in GZdtFyDU0caf89r: tzVT6PXndWu0 = 'M3U-LIVE'
							elif 'MOVIES' in GZdtFyDU0caf89r: tzVT6PXndWu0 = 'M3U-MOVIES'
							elif 'SERIES' in GZdtFyDU0caf89r: tzVT6PXndWu0 = 'M3U-SERIES'
					elif 'YOUTUBE-' in tzVT6PXndWu0 and 149>=wMCm6g9qFyPT0xpneDUNc2lEhaZY>=140:
						if ttpQZRUwEjhfdOqn in nFcfLxCbhzKI4SQv['YOUTUBE-CHANNELS']: continue
						if ttpQZRUwEjhfdOqn in nFcfLxCbhzKI4SQv['YOUTUBE-PLAYLISTS']: continue
						if ttpQZRUwEjhfdOqn in nFcfLxCbhzKI4SQv['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in WGy8jZubInXc7zRBJ5p or ':: ' in WGy8jZubInXc7zRBJ5p:
							continue
						else:
							if   wMCm6g9qFyPT0xpneDUNc2lEhaZY==144 and 'USER' in WGy8jZubInXc7zRBJ5p: tzVT6PXndWu0 = 'YOUTUBE-CHANNELS'
							elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==144 and 'CHNL' in WGy8jZubInXc7zRBJ5p: tzVT6PXndWu0 = 'YOUTUBE-CHANNELS'
							elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==144 and 'LIST' in WGy8jZubInXc7zRBJ5p: tzVT6PXndWu0 = 'YOUTUBE-PLAYLISTS'
							elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==143: tzVT6PXndWu0 = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in tzVT6PXndWu0 and 419>=wMCm6g9qFyPT0xpneDUNc2lEhaZY>=400:
						if ttpQZRUwEjhfdOqn in nFcfLxCbhzKI4SQv['DAILYMOTION-PLAYLISTS']: continue
						if ttpQZRUwEjhfdOqn in nFcfLxCbhzKI4SQv['DAILYMOTION-CHANNELS']: continue
						if ttpQZRUwEjhfdOqn in nFcfLxCbhzKI4SQv['DAILYMOTION-VIDEOS']: continue
						if ttpQZRUwEjhfdOqn in nFcfLxCbhzKI4SQv['DAILYMOTION-TOPICS']: continue
						if   wMCm6g9qFyPT0xpneDUNc2lEhaZY in [401,405]: tzVT6PXndWu0 = 'DAILYMOTION-PLAYLISTS'
						elif wMCm6g9qFyPT0xpneDUNc2lEhaZY in [402,406]: tzVT6PXndWu0 = 'DAILYMOTION-CHANNELS'
						elif wMCm6g9qFyPT0xpneDUNc2lEhaZY in [404]: tzVT6PXndWu0 = 'DAILYMOTION-VIDEOS'
						elif wMCm6g9qFyPT0xpneDUNc2lEhaZY in [415]: tzVT6PXndWu0 = 'DAILYMOTION-LIVES'
						elif wMCm6g9qFyPT0xpneDUNc2lEhaZY in [412,413]: tzVT6PXndWu0 = 'DAILYMOTION-TOPICS'
					elif 'PANET-' in tzVT6PXndWu0 and 39>=wMCm6g9qFyPT0xpneDUNc2lEhaZY>=30:
						if ttpQZRUwEjhfdOqn in nFcfLxCbhzKI4SQv['PANET-SERIES']: continue
						if ttpQZRUwEjhfdOqn in nFcfLxCbhzKI4SQv['PANET-MOVIES']: continue
						if   wMCm6g9qFyPT0xpneDUNc2lEhaZY in [32,39]: tzVT6PXndWu0 = 'PANET-SERIES'
						elif wMCm6g9qFyPT0xpneDUNc2lEhaZY in [33,39]: tzVT6PXndWu0 = 'PANET-MOVIES'
					elif 'IFILM-' in tzVT6PXndWu0 and 29>=wMCm6g9qFyPT0xpneDUNc2lEhaZY>=20:
						if ttpQZRUwEjhfdOqn in nFcfLxCbhzKI4SQv['IFILM-ARABIC']: continue
						if ttpQZRUwEjhfdOqn in nFcfLxCbhzKI4SQv['IFILM-ENGLISH']: continue
						if   '/ar.' in GZdtFyDU0caf89r: tzVT6PXndWu0 = 'IFILM-ARABIC'
						elif '/en.' in GZdtFyDU0caf89r: tzVT6PXndWu0 = 'IFILM-ENGLISH'
					nFcfLxCbhzKI4SQv[tzVT6PXndWu0].append(ttpQZRUwEjhfdOqn)
		YD56nkJmsd[:] = []
		for tzVT6PXndWu0 in list(nFcfLxCbhzKI4SQv.keys()):
			U2Bcu6FWDnIxQOtAmYZgPE[tzVT6PXndWu0] = []
			mEL75DWt9kgy[tzVT6PXndWu0] = []
			for f0QP7qXsU4L9xtB,WGy8jZubInXc7zRBJ5p,GZdtFyDU0caf89r,wMCm6g9qFyPT0xpneDUNc2lEhaZY,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,kc57B93HrojbDIXVipY,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv in nFcfLxCbhzKI4SQv[tzVT6PXndWu0]:
				ttpQZRUwEjhfdOqn = (f0QP7qXsU4L9xtB,WGy8jZubInXc7zRBJ5p,GZdtFyDU0caf89r,wMCm6g9qFyPT0xpneDUNc2lEhaZY,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,kc57B93HrojbDIXVipY,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv)
				if 'صفحة' in WGy8jZubInXc7zRBJ5p and f0QP7qXsU4L9xtB=='folder': mEL75DWt9kgy[tzVT6PXndWu0].append(ttpQZRUwEjhfdOqn)
				else: U2Bcu6FWDnIxQOtAmYZgPE[tzVT6PXndWu0].append(ttpQZRUwEjhfdOqn)
		EEU7Jlz0cw8yPL3K = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157,'','','','','')]
		for tzVT6PXndWu0 in N8lWK1vg4nwZAt2iFskB6:
			if tzVT6PXndWu0==SMAjf2CH1wmrhnDg[0]: EEU7Jlz0cw8yPL3K = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة وعامة - كثيرة المشاكل[/COLOR]','',157,'','','','','')]
			elif tzVT6PXndWu0==YExQh9CZ4ioRUmr8e1nqHl5[0]: EEU7Jlz0cw8yPL3K = [('link','[COLOR FFC89008]مواقع سيرفرات عامة - كثيرة المشاكل[/COLOR]','',157,'','','','','')]
			elif tzVT6PXndWu0==AlYMjfIewb0v3n6hq8sHiCpR[0]: EEU7Jlz0cw8yPL3K = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157,'','','','','')]
			if tzVT6PXndWu0 not in U2Bcu6FWDnIxQOtAmYZgPE.keys(): continue
			if U2Bcu6FWDnIxQOtAmYZgPE[tzVT6PXndWu0]:
				XmN9UvjgiFo = wSH84vUOuxYjoQ3aPBeAEZ(tzVT6PXndWu0)
				I3bZV0ABK2duD7 = [('link','[COLOR FFFFFF00]===== '+XmN9UvjgiFo+' =====[/COLOR]','',9999,'','','','','')]
				if 0: TqHhaZibzW = bbyc1giYGsj+' - '+'بحث'+' '+XmN9UvjgiFo
				else: TqHhaZibzW = 'بحث'+' '+XmN9UvjgiFo+' - '+bbyc1giYGsj
				if len(U2Bcu6FWDnIxQOtAmYZgPE[tzVT6PXndWu0])<8: g7lWrDfIQ4aN = []
				else:
					VAT7jEXz1DYorC2HSPLZKfcqg4 = '[COLOR FFC89008]'+TqHhaZibzW+'[/COLOR]'
					g7lWrDfIQ4aN = [('folder',tiCRYyX1bWd40Ir3PafQu+VAT7jEXz1DYorC2HSPLZKfcqg4,'closed_sites',542,'',tzVT6PXndWu0,bbyc1giYGsj,'','')]
				ZXF17JAPjfQnaThwWpksOYN9Sec = U2Bcu6FWDnIxQOtAmYZgPE[tzVT6PXndWu0]+mEL75DWt9kgy[tzVT6PXndWu0]
				jpwrJztXgbn3uVm2Ye += EEU7Jlz0cw8yPL3K+I3bZV0ABK2duD7+ZXF17JAPjfQnaThwWpksOYN9Sec[:7]+g7lWrDfIQ4aN
				VXsfx27JlqDjcpTyYU9o58QCm = [('folder',tiCRYyX1bWd40Ir3PafQu+TqHhaZibzW,'closed_sites',542,'',tzVT6PXndWu0,bbyc1giYGsj,'','')]
				RyWsivLcVATGOxmBa9kuUo1H8gnh += EEU7Jlz0cw8yPL3K+VXsfx27JlqDjcpTyYU9o58QCm
				EEU7Jlz0cw8yPL3K = []
				OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,'GLOBALSEARCH_CLOSED',(tzVT6PXndWu0,bbyc1giYGsj),ZXF17JAPjfQnaThwWpksOYN9Sec,we9acVgv5HE0mdlXCSj6n7DQ4)
		OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,'GLOBALSEARCH_OPENED',bbyc1giYGsj,jpwrJztXgbn3uVm2Ye,we9acVgv5HE0mdlXCSj6n7DQ4)
		ZqlR5BFQ6pm0asCHLUc(bpNSygerL10j4IOkEfuVw,'GLOBALSEARCH_SITES',bbyc1giYGsj)
		OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,'GLOBALSEARCH_SITES',tiCRYyX1bWd40Ir3PafQu+bbyc1giYGsj,RyWsivLcVATGOxmBa9kuUo1H8gnh,we9acVgv5HE0mdlXCSj6n7DQ4)
		xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم لكي تستطيع العودة إليها بدون عمل بحث جديد')
		if jBlCSXIN19a=='listed_sites' and RyWsivLcVATGOxmBa9kuUo1H8gnh: msoDkYg3PfAVW4cSHlIEXB = RyWsivLcVATGOxmBa9kuUo1H8gnh
		else: msoDkYg3PfAVW4cSHlIEXB = jpwrJztXgbn3uVm2Ye
	if jBlCSXIN19a!='search_sites':
		for f0QP7qXsU4L9xtB,WGy8jZubInXc7zRBJ5p,GZdtFyDU0caf89r,wMCm6g9qFyPT0xpneDUNc2lEhaZY,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,kc57B93HrojbDIXVipY,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv in msoDkYg3PfAVW4cSHlIEXB:
			if jBlCSXIN19a in ['listed_sites','opened_sites'] and 'صفحة' in WGy8jZubInXc7zRBJ5p and f0QP7qXsU4L9xtB=='folder': continue
			uQNUfbZx9yj0F(f0QP7qXsU4L9xtB,WGy8jZubInXc7zRBJ5p,GZdtFyDU0caf89r,wMCm6g9qFyPT0xpneDUNc2lEhaZY,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,kc57B93HrojbDIXVipY,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv)
	PPIXEhN6ofSZLVdJ2wRBHvKCMrx3u('','','')
	return
def oLMC8dJSiyXOUxvsQ91Yp2(bbyc1giYGsj=''):
	NweZkm8EIQjpDMUY9XasFGrPicJRb,O9AyF2MRjI,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(bbyc1giYGsj)
	if not NweZkm8EIQjpDMUY9XasFGrPicJRb:
		NweZkm8EIQjpDMUY9XasFGrPicJRb = FBrXsYeCEp3()
		if not NweZkm8EIQjpDMUY9XasFGrPicJRb: return
		NweZkm8EIQjpDMUY9XasFGrPicJRb = NweZkm8EIQjpDMUY9XasFGrPicJRb.lower()
	l0SAerv8zGH2Wa('NOTICE',CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+'   Search For: [ '+NweZkm8EIQjpDMUY9XasFGrPicJRb+' ]')
	GHFUMEOSrvhmIoVWxwN8j4 = NweZkm8EIQjpDMUY9XasFGrPicJRb+O9AyF2MRjI
	if 0: KvY5ikgtDXZl90z7TSxAQn,Sel8j25hvodwrVDaGFWKnHcuN3i = NweZkm8EIQjpDMUY9XasFGrPicJRb+' - ',''
	else: KvY5ikgtDXZl90z7TSxAQn,Sel8j25hvodwrVDaGFWKnHcuN3i = '',' - '+NweZkm8EIQjpDMUY9XasFGrPicJRb
	uQNUfbZx9yj0F('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157)
	uQNUfbZx9yj0F('folder','_M3U_'+KvY5ikgtDXZl90z7TSxAQn+'بحث M3U'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',719,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_IPT_'+KvY5ikgtDXZl90z7TSxAQn+'بحث IPTV'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',239,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_BKR_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع بكرا'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',379,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_KLA_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع كل العرب'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',19,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_ART_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع تونز عربية'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',739,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_KRB_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع قناة كربلاء'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',329,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_FH1_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع فاصل الأول'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',579,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_KTV_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع كتكوت تيفي'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',819,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_EB1_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع ايجي بيست 1'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',779,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_EB2_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع ايجي بيست 2'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',789,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_IFL_'+KvY5ikgtDXZl90z7TSxAQn+'  بحث موقع قناة آي فيلم'+Sel8j25hvodwrVDaGFWKnHcuN3i+'  ','',29,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_AKO_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع أكوام القديم'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',79,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_AKW_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع أكوام الجديد'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',249,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_MRF_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع قناة المعارف'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',49,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_SHM_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع شوف ماكس'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',59,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('link','[COLOR FFC89008]مواقع سيرفرات خاصة وعامة - كثيرة المشاكل[/COLOR]','',157)
	uQNUfbZx9yj0F('folder','_FJS_'+KvY5ikgtDXZl90z7TSxAQn+' بحث موقع فجر شو'+Sel8j25hvodwrVDaGFWKnHcuN3i+' ','',399,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_TVF_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع تيفي فان'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',469,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_LDN_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع لودي نت'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',459,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_CMN_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع سيما ناو'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',309,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_WCM_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع وي سيما'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',569,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_SHN_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع شاهد نيوز'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',589,'','',GHFUMEOSrvhmIoVWxwN8j4+'_NODIALOGS_')
	uQNUfbZx9yj0F('folder','_ARS_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع عرب سييد'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',259,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_CCB_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع سيما كلوب'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',829,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_SH4_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع شاهد فوريو'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',119,'','',GHFUMEOSrvhmIoVWxwN8j4+'_NODIALOGS_')
	uQNUfbZx9yj0F('folder','_SHT_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع شوفها تيفي'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',649,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('link','[COLOR FFC89008]مواقع سيرفرات عامة - كثيرة المشاكل[/COLOR]','',157)
	uQNUfbZx9yj0F('folder','_FST_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع فوستا'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',609,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_FBK_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع فبركة'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',629,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_YQT_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع ياقوت'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',669,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_BRS_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع برستيج'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',659,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_HLC_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع هلا سيما'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',89,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_DR7_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع دراما صح'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',689,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_CMF_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع سيما فانز'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',99,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_CML_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع سيما لايت'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',479,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_ABD_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع سيما عبدو'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',559,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_C4H_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع سيما 400'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',699,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_AHK_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع أهواك تيفي'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',619,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_EB4_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع ايجي بيست 4'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',809,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157)
	uQNUfbZx9yj0F('folder','_YUT_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع يوتيوب'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',149,'','',GHFUMEOSrvhmIoVWxwN8j4)
	uQNUfbZx9yj0F('folder','_DLM_'+KvY5ikgtDXZl90z7TSxAQn+'بحث موقع ديلي موشن'+Sel8j25hvodwrVDaGFWKnHcuN3i,'',409,'','',GHFUMEOSrvhmIoVWxwN8j4)
	return
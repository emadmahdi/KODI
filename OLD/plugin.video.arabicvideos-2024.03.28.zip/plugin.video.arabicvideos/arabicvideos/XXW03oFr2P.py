# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'FASELHD1'
headers = {'User-Agent':''}
tiCRYyX1bWd40Ir3PafQu = '_FH1_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['جوائز الأوسكار','المراجعات','wwe']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==570: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==571: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,text)
	elif mode==572: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==573: vS7JufTVsBxw52 = ZN3Wh7HABLwRIkFmyEd1Jq(url,text)
	elif mode==576: vS7JufTVsBxw52 = eyXMZC4cbdVOjG6J201qPNrQ()
	elif mode==579: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	uQNUfbZx9yj0F('link',tiCRYyX1bWd40Ir3PafQu+'لماذا الموقع بطيء','',576)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	jGX4sfdrWaeZpA1VyvTK,url,RoQL91PphqCJg4W0e6Fnsl = Td6K1l0UMsxXZQf8yGLVF7bokN9tJq(QQJtZ6rMvS1wdDsHnahT7,'GET',yONJxHER9BIDPpTV4YsWmc0n,'faselhd1','فاصل إعلاني','dubbed-movies')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع',jGX4sfdrWaeZpA1VyvTK,579,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'المميزة',jGX4sfdrWaeZpA1VyvTK,571,'','','featured1')
	items = u5h2Rckvw1E.findall('class="h3">(.*?)<.*?href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not items:
		xl9MFt1AmY0GrkENug8n('','','موقع فاصل الأول','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	for title,ekTrZlFMu0Kf5QztEnhAs in items:
		uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,571,'','','details1')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"menu-primary"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		iQVYwCHLhIS3DdbutWjp42AZEy8Tr = u5h2Rckvw1E.findall('<li (.*?)</li>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		DinIPs0ZcfSNBKFCzwt74 = ['','أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		k0G4LTYt93po = 0
		for GGOfdq3ejKzUl6xAuN7WsSMEJv in iQVYwCHLhIS3DdbutWjp42AZEy8Tr:
			if k0G4LTYt93po>0: uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)<',GGOfdq3ejKzUl6xAuN7WsSMEJv,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,title in items:
				if ekTrZlFMu0Kf5QztEnhAs=='#': continue
				if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = jGX4sfdrWaeZpA1VyvTK+ekTrZlFMu0Kf5QztEnhAs
				if title=='': continue
				if any(c2eEflztvIX in title.lower() for c2eEflztvIX in WLI5tgXRbUPNGJCSVz0vKjBDei3): continue
				title = DinIPs0ZcfSNBKFCzwt74[k0G4LTYt93po]+title
				uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,571,'','','details2')
			k0G4LTYt93po += 1
	return
def eyXMZC4cbdVOjG6J201qPNrQ():
	xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,type=''):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','FASELHD1-TITLES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	RfTOHSzgpA = u5h2Rckvw1E.findall('class="h4">(.*?)</div>(.*?)"container"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not RfTOHSzgpA: return
	if type=='filters':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = [oo9SgGkiDbs3HRn7z8.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"homeSlide"(.*?)"container"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		zzPpxcaALmojyheWSG,lQUf3AY258LeWch,YMpoGJSqdLFkvb4WRuZNa65 = zip(*items)
		items = zip(lQUf3AY258LeWch,zzPpxcaALmojyheWSG,YMpoGJSqdLFkvb4WRuZNa65)
	elif type=='featured2':
		title,lmO2YJGr6tCV = RfTOHSzgpA[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	elif type=='details2' and len(RfTOHSzgpA)>1:
		title = RfTOHSzgpA[0][0]
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,571,'','','featured2')
		title = RfTOHSzgpA[1][0]
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,571,'','','details3')
		return
	else:
		title,lmO2YJGr6tCV = RfTOHSzgpA[-1]
		items = u5h2Rckvw1E.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	yn8DkpE5etF3WiUmfSO = []
	for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
		if any(c2eEflztvIX in title.lower() for c2eEflztvIX in WLI5tgXRbUPNGJCSVz0vKjBDei3): continue
		pGjsvdyHfM = ffbxegm1XPSqIwp8i(pGjsvdyHfM)
		pGjsvdyHfM = pGjsvdyHfM.split('?resize=')[0]
		title = uTUNPkVwCMKiD5gHLaj(title)
		zAjwuoRY98mXN6xvE = u5h2Rckvw1E.findall('(.*?) (الحلقة|حلقة).\d+',title,u5h2Rckvw1E.DOTALL)
		if '/collections/' in ekTrZlFMu0Kf5QztEnhAs:
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,571,pGjsvdyHfM)
		elif zAjwuoRY98mXN6xvE and type=='':
			title = '_MOD_'+zAjwuoRY98mXN6xvE[0][0]
			title = title.strip(' –')
			if title not in yn8DkpE5etF3WiUmfSO:
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,573,pGjsvdyHfM)
				yn8DkpE5etF3WiUmfSO.append(title)
		elif 'episodes/' in ekTrZlFMu0Kf5QztEnhAs or 'movies/' in ekTrZlFMu0Kf5QztEnhAs or 'hindi/' in ekTrZlFMu0Kf5QztEnhAs:
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,572,pGjsvdyHfM)
		else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,573,pGjsvdyHfM)
	if type=='filters':
		LTIzl7GJ3StWsN = u5h2Rckvw1E.findall('"more_button_page":(.*?),',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if LTIzl7GJ3StWsN:
			count = LTIzl7GJ3StWsN[0]
			ekTrZlFMu0Kf5QztEnhAs = url+'/offset/'+count
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة أخرى',ekTrZlFMu0Kf5QztEnhAs,571,'','','filters')
	elif 'details' in type:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall("class='pagination(.*?)</div>",oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall("href='(.*?)'.*?>(.*?)<",lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,title in items:
				title = 'صفحة '+uTUNPkVwCMKiD5gHLaj(title)
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,571,'','','details4')
	return
def ZN3Wh7HABLwRIkFmyEd1Jq(url,type=''):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','FASELHD1-SEASONS_EPISODES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	EKhwoNlubG5A7xaJW2UOg1 = False
	if not type:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"seasonList"(.*?)"container"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			if len(items)>1:
				jGX4sfdrWaeZpA1VyvTK = hmcFWJUgiAuGk(url,'url')
				EKhwoNlubG5A7xaJW2UOg1 = True
				for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,name,title in items:
					name = uTUNPkVwCMKiD5gHLaj(name)
					if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = jGX4sfdrWaeZpA1VyvTK+ekTrZlFMu0Kf5QztEnhAs
					title = name+' - '+title
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,573,pGjsvdyHfM,'','episodes')
	if type=='episodes' or not EKhwoNlubG5A7xaJW2UOg1:
		ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx = u5h2Rckvw1E.findall('"posterImg".*?src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx: pGjsvdyHfM = ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx[0]
		else: pGjsvdyHfM = ''
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"epAll"(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,title in items:
				title = title.strip(' ')
				title = uTUNPkVwCMKiD5gHLaj(title)
				uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,572,pGjsvdyHfM)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	GnuaoT9MxiCg,BX7QKUdExCo9eGFy2iTlhMutZ08LP,vvspXO2tJ6ikETcV7o1jPW0xmg = [],[],[]
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',url,'','','','','FASELHD1-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	lZ5R0cxUOYX = u5h2Rckvw1E.findall('مستوى المشاهدة.*?">(.*?)</span>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if lZ5R0cxUOYX:
		PmF0XjQN51GpKACfLgnyTv7 = u5h2Rckvw1E.findall('"tag">(.*?)</a>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if PmF0XjQN51GpKACfLgnyTv7 and dQorkS3qBhIMDWKHl(aUVSgO2ebjwX5iqPykC,url,PmF0XjQN51GpKACfLgnyTv7): return
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"videoRow"(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('src="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs in items:
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.split('&img=')[0]
			GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs+'?named=__embed')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="streamHeader(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall("href = '(.*?)'.*?</i>(.*?)</a>",lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,name in items:
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.split('&img=')[0]
			name = name.strip(' ')
			GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs+'?named='+name+'__watch')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="downloadLinks(.*?)blackwindow',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?</span>(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,name in items:
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.split('&img=')[0]
			GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs+'?named='+name+'__download')
	for GGjzV7mCfQHnsqBZhASo8 in GnuaoT9MxiCg:
		ekTrZlFMu0Kf5QztEnhAs,name = GGjzV7mCfQHnsqBZhASo8.split('?named')
		if ekTrZlFMu0Kf5QztEnhAs not in BX7QKUdExCo9eGFy2iTlhMutZ08LP:
			BX7QKUdExCo9eGFy2iTlhMutZ08LP.append(ekTrZlFMu0Kf5QztEnhAs)
			vvspXO2tJ6ikETcV7o1jPW0xmg.append(GGjzV7mCfQHnsqBZhASo8)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(vvspXO2tJ6ikETcV7o1jPW0xmg,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	search = search.replace(' ','+')
	url = yONJxHER9BIDPpTV4YsWmc0n+'/?s='+search
	jGX4sfdrWaeZpA1VyvTK,gANn35esloKUydOipfSMC6RD2,p8HVUxN5v3WZfF4Gt7o0gLOdSiI = Td6K1l0UMsxXZQf8yGLVF7bokN9tJq(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'faselhd1','فاصل إعلاني','dubbed-movies')
	ll0a2AwztChcpsDUMi4rGW3b61XZES(gANn35esloKUydOipfSMC6RD2,'details5')
	return
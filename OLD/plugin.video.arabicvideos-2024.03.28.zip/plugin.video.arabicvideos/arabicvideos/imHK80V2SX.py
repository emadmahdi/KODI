# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'RANDOMS'
tiCRYyX1bWd40Ir3PafQu = '_LST_'
PgiWfI5So2e80LDzFVJtdvpOA = 4
DDmAhJ9ZjxoYasWbke7N3IHlR2PtG = 10
def cc03CYPLaxRfUKJb9eynFTr(wMCm6g9qFyPT0xpneDUNc2lEhaZY,url,kc57B93HrojbDIXVipY,BzbaC0qYjMr2WXwsO,aiSY4yFdLmPH2zenlMpv):
	try: VhIGD8gM4BpZ3wsCPqQvK5L = str(aiSY4yFdLmPH2zenlMpv['folder'])
	except: VhIGD8gM4BpZ3wsCPqQvK5L = ''
	if   wMCm6g9qFyPT0xpneDUNc2lEhaZY==160: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==161: vS7JufTVsBxw52 = QA7p61PXjC(kc57B93HrojbDIXVipY)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==162: vS7JufTVsBxw52 = ipFyMGOmXzWPnHJV4NlYab50sRUTK7(kc57B93HrojbDIXVipY,162)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==163: vS7JufTVsBxw52 = ipFyMGOmXzWPnHJV4NlYab50sRUTK7(kc57B93HrojbDIXVipY,163)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==164: vS7JufTVsBxw52 = J8pm9UHCnhOkVZ(kc57B93HrojbDIXVipY)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==165: vS7JufTVsBxw52 = rINg2h7wvF1H3OlWeXn0(url,kc57B93HrojbDIXVipY)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==166: vS7JufTVsBxw52 = ieTElnByYba9rsMtPpG(url,kc57B93HrojbDIXVipY)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==167: vS7JufTVsBxw52 = MMAd6CQGWNPIuDjE(url,kc57B93HrojbDIXVipY)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==168: vS7JufTVsBxw52 = FjnzX6skMeGYdC2UwJRZ7tWQc(url,kc57B93HrojbDIXVipY)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==761: vS7JufTVsBxw52 = sR6oe2kMiJTcEh()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==762: vS7JufTVsBxw52 = dH8O4ciYzZI()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==763: vS7JufTVsBxw52 = wl47hTtBKNJMa5ARW6fZ08YC9ieL(VhIGD8gM4BpZ3wsCPqQvK5L,kc57B93HrojbDIXVipY,BzbaC0qYjMr2WXwsO)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==764: vS7JufTVsBxw52 = xDmYsfkU2Q7M3wpERjB(VhIGD8gM4BpZ3wsCPqQvK5L,kc57B93HrojbDIXVipY)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==765: vS7JufTVsBxw52 = m38mFGEHjrc(VhIGD8gM4BpZ3wsCPqQvK5L,kc57B93HrojbDIXVipY)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	uQNUfbZx9yj0F('folder','قنوات تلفزيون عشوائية','',161,'','','_LIVETV__RANDOM__REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder','قسم عشوائي','',162,'','','_SITES__REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder','فيديوهات عشوائية','',163,'','','_SITES__RANDOM__REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder','فيديوهات بحث عشوائي','',164,'','','_SITES__RANDOM__REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder','فيديوهات عشوائية من قسم','',763,'','','_SITES__RANDOM_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder','قنوات M3U عشوائية','',163,'','','_M3U__LIVE__RANDOM__REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder','فيديوهات M3U عشوائية','',163,'','','_M3U__VOD__RANDOM__REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder','قسم قنوات M3U عشوائي','',162,'','','_M3U__LIVE__REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder','قسم فيديو M3U عشوائي','',162,'','','_M3U__VOD__REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder','فيديوهات M3U بحث عشوائي','',164,'','','_M3U__RANDOM__REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder','فيديوهات M3U عشوائية من قسم','',765,'','','_M3U__RANDOM__REMEMBERRESULTS_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder','قنوات IPTV عشوائية','',163,'','','_IPTV__LIVE__RANDOM__REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder','فيديوهات IPTV عشوائية','',163,'','','_IPTV__VOD__RANDOM__REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder','قسم قنوات IPTV عشوائي','',162,'','','_IPTV__LIVE__REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder','قسم فيديو IPTV عشوائي','',162,'','','_IPTV__VOD__REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder','فيديوهات IPTV بحث عشوائي','',164,'','','_IPTV__RANDOM__REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder','فيديوهات IPTV عشوائية من قسم','',764,'','','_IPTV__RANDOM__REMEMBERRESULTS_')
	return
def sR6oe2kMiJTcEh():
	uQNUfbZx9yj0F('folder','_IPT_'+'فيديوهات جميع IPTV','',764)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for VhIGD8gM4BpZ3wsCPqQvK5L in range(1,vMrXCkF9Kmu+1):
		tiCRYyX1bWd40Ir3PafQu = '_IP'+str(VhIGD8gM4BpZ3wsCPqQvK5L)+'_'
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+' فيديوهات مجلد '+r5tHLX2ZFS1Kz9jRba0fsc[VhIGD8gM4BpZ3wsCPqQvK5L],'',764,'','','','',{'folder':VhIGD8gM4BpZ3wsCPqQvK5L})
	return
def dH8O4ciYzZI():
	uQNUfbZx9yj0F('folder','_M3U_'+'فيديوهات جميع M3U','',765)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for VhIGD8gM4BpZ3wsCPqQvK5L in range(1,vMrXCkF9Kmu+1):
		tiCRYyX1bWd40Ir3PafQu = '_MU'+str(VhIGD8gM4BpZ3wsCPqQvK5L)+'_'
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+' فيديوهات مجلد '+r5tHLX2ZFS1Kz9jRba0fsc[VhIGD8gM4BpZ3wsCPqQvK5L],'',765,'','','','',{'folder':VhIGD8gM4BpZ3wsCPqQvK5L})
	return
def Hv3YZqXtCW1KyuG8NMsS9PoBbnU5F(tzVT6PXndWu0):
	global CgO5YABnqTEpuLy6Kmdr73vlPtGiVH,mxePjsKDn4
	lKC9tsMTk1xeVIDmUjwrZzvhP50,lfXd1GQTyCkVSUzAeO,gprYWX3BPb7EVuv4wmlc = BZ60Cr5qARSJYjkD(tzVT6PXndWu0)
	try:
		if 'IFILM' in tzVT6PXndWu0: lKC9tsMTk1xeVIDmUjwrZzvhP50(tzVT6PXndWu0)
		else: lKC9tsMTk1xeVIDmUjwrZzvhP50()
		kkmNlhv9jPXrnC4DzgbIWBH0 = False
	except:
		OEZ5f7K4jQpUJDnFaHNCdhPc()
		kkmNlhv9jPXrnC4DzgbIWBH0 = True
	tzVT6PXndWu0 = wSH84vUOuxYjoQ3aPBeAEZ(tzVT6PXndWu0)
	if kkmNlhv9jPXrnC4DzgbIWBH0:
		dnS80F92qtLi4vw1(tzVT6PXndWu0,'فشل للأسف',YVJPFvuI2CS5KObiZt=2000)
		CgO5YABnqTEpuLy6Kmdr73vlPtGiVH += 1
		mxePjsKDn4 += ' '+tzVT6PXndWu0
	else: dnS80F92qtLi4vw1(tzVT6PXndWu0,'',YVJPFvuI2CS5KObiZt=1000)
	return
def w4wedGRiInz1Xm6Dro7UNjLHcKx(oGOK9b3keFUPuDYgw0y2IZqMAEnS=True):
	global CgO5YABnqTEpuLy6Kmdr73vlPtGiVH,mxePjsKDn4
	if not oGOK9b3keFUPuDYgw0y2IZqMAEnS:
		global NW1z9Mg8T2
		vS7JufTVsBxw52 = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,'dict','SECTIONS_SITES','SECTIONS_SITES_ALL')
		if vS7JufTVsBxw52:
			NW1z9Mg8T2 = vS7JufTVsBxw52
			return
	iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0('center','','','رسالة من المبرمج','لكي تملئ هذه القائمة . البرنامج يحتاج أن يفحص جميع مواقع الفيديو التي في البرنامج لكي يستخرج منها فقط الأقسام الرئيسية . ثم يقوم البرنامج بخزن هذه الأقسام حتى لا تحتاج أن تملئها مرة أخرى . عملية ملئ جميع الأقسام تحتاج عادة أقل من 3 دقائق . هل تريد أن تجمع قائمة الأقسام الآن ؟')
	if iZL6cN3OkM5!=1: return
	PPIXEhN6ofSZLVdJ2wRBHvKCMrx3u(False,False,False)
	N1Plv4xa7KnXjyYg = YD56nkJmsd
	CgO5YABnqTEpuLy6Kmdr73vlPtGiVH,mxePjsKDn4,threads = 0,'',{}
	for tzVT6PXndWu0 in Hkum8ZFvxPhXWl:
		YVJPFvuI2CS5KObiZt.sleep(0.5)
		threads[tzVT6PXndWu0] = onVDrgLUpFsqOPkxId9BwW6Rtc5A.Thread(target=Hv3YZqXtCW1KyuG8NMsS9PoBbnU5F,args=(tzVT6PXndWu0,))
		threads[tzVT6PXndWu0].start()
		if CgO5YABnqTEpuLy6Kmdr73vlPtGiVH>=DDmAhJ9ZjxoYasWbke7N3IHlR2PtG: break
	else:
		for tzVT6PXndWu0 in list(threads.keys()):
			threads[tzVT6PXndWu0].join()
	YD56nkJmsd[:] = N1Plv4xa7KnXjyYg
	if CgO5YABnqTEpuLy6Kmdr73vlPtGiVH>=DDmAhJ9ZjxoYasWbke7N3IHlR2PtG: xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','لديك مشكلة في '+str(CgO5YABnqTEpuLy6Kmdr73vlPtGiVH)+' مواقع من مواقع البرنامج ... وسببها قد يكون عدم وجود إنترنيت في جهازك وهي:'+mxePjsKDn4)
	else:
		OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,'SECTIONS_SITES','SECTIONS_SITES_ALL',NW1z9Mg8T2,NVbfv48oh3M6U)
		xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','تم جلب جميع الأقسام المتوفرة في البرنامج')
	PPIXEhN6ofSZLVdJ2wRBHvKCMrx3u('','','')
	return
def eYjkOB7G2aq5E3yfLlFNIV(VhIGD8gM4BpZ3wsCPqQvK5L,O9AyF2MRjI):
	EqVPHSM8fKuTaxh20WkNLd = False
	jciMOQ6EWwadrYe = YD56nkJmsd
	YD56nkJmsd[:] = []
	if EqVPHSM8fKuTaxh20WkNLd and '_CREATENEW_' not in O9AyF2MRjI:
		vS7JufTVsBxw52 = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,'list','SECTIONS_IPTV','SECTIONS_IPTV_'+VhIGD8gM4BpZ3wsCPqQvK5L)
	elif '_LIVE_' not in O9AyF2MRjI or '_VOD_' not in O9AyF2MRjI:
		import BSdmDzviZG
		MLPwxur5kaYlBtqcn = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in O9AyF2MRjI:
			try: BSdmDzviZG.dK9CqzeR1asO(VhIGD8gM4BpZ3wsCPqQvK5L,'VOD_UNKNOWN_GROUPED_SORTED','','',O9AyF2MRjI+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: xl9MFt1AmY0GrkENug8n('','','موقع ـIPTV للفيديوهات',MLPwxur5kaYlBtqcn)
			try: BSdmDzviZG.dK9CqzeR1asO(VhIGD8gM4BpZ3wsCPqQvK5L,'VOD_MOVIES_GROUPED_SORTED','','',O9AyF2MRjI+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: xl9MFt1AmY0GrkENug8n('','','موقع ـIPTV للفيديوهات',MLPwxur5kaYlBtqcn)
			try: BSdmDzviZG.dK9CqzeR1asO(VhIGD8gM4BpZ3wsCPqQvK5L,'VOD_SERIES_GROUPED_SORTED','','',O9AyF2MRjI+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: xl9MFt1AmY0GrkENug8n('','','موقع ـIPTV للفيديوهات',MLPwxur5kaYlBtqcn)
		if '_VOD_' not in O9AyF2MRjI:
			try: BSdmDzviZG.dK9CqzeR1asO(VhIGD8gM4BpZ3wsCPqQvK5L,'LIVE_UNKNOWN_GROUPED_SORTED','','',O9AyF2MRjI+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: xl9MFt1AmY0GrkENug8n('','','موقع ـIPTV للقنوات',MLPwxur5kaYlBtqcn)
			try: BSdmDzviZG.dK9CqzeR1asO(VhIGD8gM4BpZ3wsCPqQvK5L,'LIVE_GROUPED_SORTED','','',O9AyF2MRjI+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: xl9MFt1AmY0GrkENug8n('','','موقع ـIPTV للقنوات',MLPwxur5kaYlBtqcn)
		vS7JufTVsBxw52 = YD56nkJmsd
		if EqVPHSM8fKuTaxh20WkNLd: OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,'SECTIONS_IPTV','SECTIONS_IPTV_'+VhIGD8gM4BpZ3wsCPqQvK5L,vS7JufTVsBxw52,NVbfv48oh3M6U)
	YD56nkJmsd[:] = jciMOQ6EWwadrYe
	return vS7JufTVsBxw52
def FDzNAnIqkU0TL5tdMRaGb8jgBKYe(VhIGD8gM4BpZ3wsCPqQvK5L,O9AyF2MRjI):
	EqVPHSM8fKuTaxh20WkNLd = False
	jciMOQ6EWwadrYe = YD56nkJmsd
	YD56nkJmsd[:] = []
	if EqVPHSM8fKuTaxh20WkNLd and '_CREATENEW_' not in O9AyF2MRjI:
		vS7JufTVsBxw52 = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,'list','SECTIONS_M3U','SECTIONS_M3U_'+VhIGD8gM4BpZ3wsCPqQvK5L)
	elif '_LIVE_' not in O9AyF2MRjI or '_VOD_' not in O9AyF2MRjI:
		import kS9c6phm0W
		MLPwxur5kaYlBtqcn = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in O9AyF2MRjI:
			try: kS9c6phm0W.dK9CqzeR1asO(VhIGD8gM4BpZ3wsCPqQvK5L,'VOD_UNKNOWN_GROUPED_SORTED','','',O9AyF2MRjI+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: xl9MFt1AmY0GrkENug8n('','','موقع ـM3U للفيديوهات',MLPwxur5kaYlBtqcn)
			try: kS9c6phm0W.dK9CqzeR1asO(VhIGD8gM4BpZ3wsCPqQvK5L,'VOD_MOVIES_GROUPED_SORTED','','',O9AyF2MRjI+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: xl9MFt1AmY0GrkENug8n('','','موقع ـM3U للفيديوهات',MLPwxur5kaYlBtqcn)
			try: kS9c6phm0W.dK9CqzeR1asO(VhIGD8gM4BpZ3wsCPqQvK5L,'VOD_SERIES_GROUPED_SORTED','','',O9AyF2MRjI+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: xl9MFt1AmY0GrkENug8n('','','موقع ـM3U للفيديوهات',MLPwxur5kaYlBtqcn)
		if '_VOD_' not in O9AyF2MRjI:
			try: kS9c6phm0W.dK9CqzeR1asO(VhIGD8gM4BpZ3wsCPqQvK5L,'LIVE_UNKNOWN_GROUPED_SORTED','','',O9AyF2MRjI+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: xl9MFt1AmY0GrkENug8n('','','موقع ـM3U للقنوات',MLPwxur5kaYlBtqcn)
			try: kS9c6phm0W.dK9CqzeR1asO(VhIGD8gM4BpZ3wsCPqQvK5L,'LIVE_GROUPED_SORTED','','',O9AyF2MRjI+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: xl9MFt1AmY0GrkENug8n('','','موقع ـM3U للقنوات',MLPwxur5kaYlBtqcn)
		vS7JufTVsBxw52 = YD56nkJmsd
		if EqVPHSM8fKuTaxh20WkNLd: OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,'SECTIONS_M3U','SECTIONS_M3U_'+VhIGD8gM4BpZ3wsCPqQvK5L,vS7JufTVsBxw52,NVbfv48oh3M6U)
	YD56nkJmsd[:] = jciMOQ6EWwadrYe
	return vS7JufTVsBxw52
def wl47hTtBKNJMa5ARW6fZ08YC9ieL(VhIGD8gM4BpZ3wsCPqQvK5L,O9AyF2MRjI,znisT7ZhrGk86NM):
	if '_CREATENEW_' in O9AyF2MRjI and znisT7ZhrGk86NM=='': w4wedGRiInz1Xm6Dro7UNjLHcKx(True)
	elif znisT7ZhrGk86NM: w4wedGRiInz1Xm6Dro7UNjLHcKx(False)
	PJnZMvWOpRNy3jI = O9AyF2MRjI.replace('_CREATENEW_','').replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	if not znisT7ZhrGk86NM:
		uQNUfbZx9yj0F('link','تحديث هذه القائمة','',763,'','','_CREATENEW_'+PJnZMvWOpRNy3jI,'',{'folder':VhIGD8gM4BpZ3wsCPqQvK5L})
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	F6y9DB5gKWSdpzmju = ['أفلام','مسلسلات','مسرحيات','برامج','أطفال وكرتون','رمضان','أحدث-أخر','سلاسل','موسيقى','أشهر-أكثر','الآن','ضحك','رياضة','نيتفلكس','ممثلين','بث حي','دينية','سنوات','أخرى']
	QDRB3YzPrcd = ['افلام','movie','فيلم','فلم']
	s9FEySUQa8q = ['مسلسل','series']
	uz7vESXUsAhtTRJcnLi = ['مسارح','مسرحيات']
	GGTJBfq1ngorSF483m0pR = ['برامج','show','تلفزيون','تليفزيون']
	ZZqNQ7Yec1 = ['انمي','كرتون','كارتون','kids','طفل','اطفال']
	IFuMBwgZdi9WScPXKVkfzp0NT7CYt = ['رمضان']
	VCio1EXzNgM8WLmYbxtBdw = ['احدث','اخر','موخر','جديد','مضاف','حديث']
	aEk6rv3plzoPmdfyI5Nx = ['سلاسل','سلسله']
	heWOUKDtZE0zBMLIR4qYs6rX3m = ['اغاني','موسيقى','كليب','حفل','music']
	K37aCG2WnNiBfEt6emzcy9I5xjhS = ['اكثر','اشهر','مميزه','اعلى','مختاره','مختارات','اقوى']
	mk5CvI9aU6c7zKl = ['الان','حالي','مثبت','رائج']
	Hl9snNaBiWSPV5 = ['ضحك','كوميدي']
	mmPgR98BrOVYHquhSCaZ3bNfMKws = ['رياضه','كوره','مصارعه','شوت','رياضة']
	ad4gOovV7RsjKfpJL5mXbyQSFcUzx = ['نيتفلكس','netflix','نيتفليكس']
	IFSsc7pMQ5LV3ProbUtJ0ni = ['ممثلين','اشخاص','نجوم']
	SotcYExj3mF2Cn4dGKA = ['بث حي','live','قناه','قنوات']
	KOJL1GMpxbSYI2H96PAw = ['دين','ادعيه','زيارات','لطميات','دعاء','قران','قصائد','رثاء','مرجعيه','اذان','اسلام','تواشيح','خطب','حوزوي','عتبات','مواليد','نواعي','عقائد','اناشيد']
	WWyQ8acljsu1R = ['19','20','21','22','23','24','25','26']
	if not znisT7ZhrGk86NM:
		znisT7ZhrGk86NM = 0
		for gQAThjV2yD1K5IJ7Bixerf4abvGoHL in F6y9DB5gKWSdpzmju:
			znisT7ZhrGk86NM += 1
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+gQAThjV2yD1K5IJ7Bixerf4abvGoHL,'',763,'',str(znisT7ZhrGk86NM),PJnZMvWOpRNy3jI,'',{'folder':VhIGD8gM4BpZ3wsCPqQvK5L})
	else:
		for WGy8jZubInXc7zRBJ5p in sorted(list(NW1z9Mg8T2.keys())):
			yGAtUBdJLngm = WGy8jZubInXc7zRBJ5p.lower()
			oPrhaMp7AqmNnRjlXGI = []
			if any(c2eEflztvIX in yGAtUBdJLngm for c2eEflztvIX in QDRB3YzPrcd): oPrhaMp7AqmNnRjlXGI.append(1)
			if any(c2eEflztvIX in yGAtUBdJLngm for c2eEflztvIX in s9FEySUQa8q): oPrhaMp7AqmNnRjlXGI.append(2)
			if any(c2eEflztvIX in yGAtUBdJLngm for c2eEflztvIX in uz7vESXUsAhtTRJcnLi): oPrhaMp7AqmNnRjlXGI.append(3)
			if any(c2eEflztvIX in yGAtUBdJLngm for c2eEflztvIX in GGTJBfq1ngorSF483m0pR): oPrhaMp7AqmNnRjlXGI.append(4)
			if any(c2eEflztvIX in yGAtUBdJLngm for c2eEflztvIX in ZZqNQ7Yec1): oPrhaMp7AqmNnRjlXGI.append(5)
			if any(c2eEflztvIX in yGAtUBdJLngm for c2eEflztvIX in IFuMBwgZdi9WScPXKVkfzp0NT7CYt): oPrhaMp7AqmNnRjlXGI.append(6)
			if any(c2eEflztvIX in yGAtUBdJLngm for c2eEflztvIX in VCio1EXzNgM8WLmYbxtBdw) and yGAtUBdJLngm not in ['اخرى']: oPrhaMp7AqmNnRjlXGI.append(7)
			if any(c2eEflztvIX in yGAtUBdJLngm for c2eEflztvIX in aEk6rv3plzoPmdfyI5Nx): oPrhaMp7AqmNnRjlXGI.append(8)
			if any(c2eEflztvIX in yGAtUBdJLngm for c2eEflztvIX in heWOUKDtZE0zBMLIR4qYs6rX3m): oPrhaMp7AqmNnRjlXGI.append(9)
			if any(c2eEflztvIX in yGAtUBdJLngm for c2eEflztvIX in K37aCG2WnNiBfEt6emzcy9I5xjhS): oPrhaMp7AqmNnRjlXGI.append(10)
			if any(c2eEflztvIX in yGAtUBdJLngm for c2eEflztvIX in mk5CvI9aU6c7zKl): oPrhaMp7AqmNnRjlXGI.append(11)
			if any(c2eEflztvIX in yGAtUBdJLngm for c2eEflztvIX in Hl9snNaBiWSPV5): oPrhaMp7AqmNnRjlXGI.append(12)
			if any(c2eEflztvIX in yGAtUBdJLngm for c2eEflztvIX in mmPgR98BrOVYHquhSCaZ3bNfMKws): oPrhaMp7AqmNnRjlXGI.append(13)
			if any(c2eEflztvIX in yGAtUBdJLngm for c2eEflztvIX in ad4gOovV7RsjKfpJL5mXbyQSFcUzx): oPrhaMp7AqmNnRjlXGI.append(14)
			if any(c2eEflztvIX in yGAtUBdJLngm for c2eEflztvIX in IFSsc7pMQ5LV3ProbUtJ0ni): oPrhaMp7AqmNnRjlXGI.append(15)
			if any(c2eEflztvIX in yGAtUBdJLngm for c2eEflztvIX in SotcYExj3mF2Cn4dGKA): oPrhaMp7AqmNnRjlXGI.append(16)
			if any(c2eEflztvIX in yGAtUBdJLngm for c2eEflztvIX in KOJL1GMpxbSYI2H96PAw): oPrhaMp7AqmNnRjlXGI.append(17)
			if any(c2eEflztvIX in yGAtUBdJLngm for c2eEflztvIX in WWyQ8acljsu1R): oPrhaMp7AqmNnRjlXGI.append(18)
			if not oPrhaMp7AqmNnRjlXGI: oPrhaMp7AqmNnRjlXGI = [19]
			for rZgRWIsuSjpim7cMAnLfhHEx5 in oPrhaMp7AqmNnRjlXGI:
				if str(rZgRWIsuSjpim7cMAnLfhHEx5)==znisT7ZhrGk86NM:
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+WGy8jZubInXc7zRBJ5p,WGy8jZubInXc7zRBJ5p,166,'','',PJnZMvWOpRNy3jI+'_REMEMBERRESULTS_')
	return
def xDmYsfkU2Q7M3wpERjB(VhIGD8gM4BpZ3wsCPqQvK5L,O9AyF2MRjI):
	EqVPHSM8fKuTaxh20WkNLd = False
	if EqVPHSM8fKuTaxh20WkNLd:
		uQNUfbZx9yj0F('link','تحديث هذه القائمة','',764,'','','_CREATENEW_','',{'folder':VhIGD8gM4BpZ3wsCPqQvK5L})
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	jciMOQ6EWwadrYe = YD56nkJmsd[:]
	import BSdmDzviZG
	if VhIGD8gM4BpZ3wsCPqQvK5L:
		if not BSdmDzviZG.OSDp6mYAsavhl0boq(VhIGD8gM4BpZ3wsCPqQvK5L,True): return
		ools3I2JVZrti8UPSXuxOFGeR6Yq = eYjkOB7G2aq5E3yfLlFNIV(VhIGD8gM4BpZ3wsCPqQvK5L,O9AyF2MRjI)
		agupMjtTxhzvJcLZ8DklEOW34B = sorted(ools3I2JVZrti8UPSXuxOFGeR6Yq,reverse=False,key=lambda key: key[1].lower())
	else:
		if not BSdmDzviZG.OSDp6mYAsavhl0boq('',True): return
		if EqVPHSM8fKuTaxh20WkNLd and '_CREATENEW_' not in O9AyF2MRjI:
			agupMjtTxhzvJcLZ8DklEOW34B = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,'list','SECTIONS_IPTV','SECTIONS_IPTV_ALL')
		else:
			FucflUgB8b6DqkiywNSvtTodh1eXz,agupMjtTxhzvJcLZ8DklEOW34B,ools3I2JVZrti8UPSXuxOFGeR6Yq = [],[],[]
			for biA3YCgo42yxeQaf0LJKmFhRD in range(1,vMrXCkF9Kmu+1):
				agupMjtTxhzvJcLZ8DklEOW34B += eYjkOB7G2aq5E3yfLlFNIV(str(biA3YCgo42yxeQaf0LJKmFhRD),O9AyF2MRjI)
			for type,WGy8jZubInXc7zRBJ5p,url,wMCm6g9qFyPT0xpneDUNc2lEhaZY,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,kc57B93HrojbDIXVipY,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv in agupMjtTxhzvJcLZ8DklEOW34B:
				if kc57B93HrojbDIXVipY not in FucflUgB8b6DqkiywNSvtTodh1eXz:
					FucflUgB8b6DqkiywNSvtTodh1eXz.append(kc57B93HrojbDIXVipY)
					WmuFH5VSIroyBUqtOkhTg = type,WGy8jZubInXc7zRBJ5p,kc57B93HrojbDIXVipY,165,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,O9AyF2MRjI,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv
					ools3I2JVZrti8UPSXuxOFGeR6Yq.append(WmuFH5VSIroyBUqtOkhTg)
			agupMjtTxhzvJcLZ8DklEOW34B = sorted(ools3I2JVZrti8UPSXuxOFGeR6Yq,reverse=False,key=lambda key: key[1].lower())
			if EqVPHSM8fKuTaxh20WkNLd: OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,'SECTIONS_IPTV','SECTIONS_IPTV_ALL',agupMjtTxhzvJcLZ8DklEOW34B,NVbfv48oh3M6U)
	YD56nkJmsd[:] = jciMOQ6EWwadrYe+agupMjtTxhzvJcLZ8DklEOW34B
	bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin('Container.Refresh')
	return
def m38mFGEHjrc(VhIGD8gM4BpZ3wsCPqQvK5L,O9AyF2MRjI):
	EqVPHSM8fKuTaxh20WkNLd = False
	if EqVPHSM8fKuTaxh20WkNLd:
		uQNUfbZx9yj0F('link','تحديث هذه القائمة','',765,'','','_CREATENEW_','',{'folder':VhIGD8gM4BpZ3wsCPqQvK5L})
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	jciMOQ6EWwadrYe = YD56nkJmsd[:]
	import kS9c6phm0W
	if VhIGD8gM4BpZ3wsCPqQvK5L:
		if not kS9c6phm0W.OSDp6mYAsavhl0boq(VhIGD8gM4BpZ3wsCPqQvK5L,True): return
		ools3I2JVZrti8UPSXuxOFGeR6Yq = FDzNAnIqkU0TL5tdMRaGb8jgBKYe(VhIGD8gM4BpZ3wsCPqQvK5L,O9AyF2MRjI)
		agupMjtTxhzvJcLZ8DklEOW34B = sorted(ools3I2JVZrti8UPSXuxOFGeR6Yq,reverse=False,key=lambda key: key[1].lower())
	else:
		if not kS9c6phm0W.OSDp6mYAsavhl0boq('',True): return
		if EqVPHSM8fKuTaxh20WkNLd and '_CREATENEW_' not in O9AyF2MRjI:
			agupMjtTxhzvJcLZ8DklEOW34B = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,'list','SECTIONS_M3U','SECTIONS_M3U_ALL')
		else:
			FucflUgB8b6DqkiywNSvtTodh1eXz,agupMjtTxhzvJcLZ8DklEOW34B,ools3I2JVZrti8UPSXuxOFGeR6Yq = [],[],[]
			for biA3YCgo42yxeQaf0LJKmFhRD in range(1,vMrXCkF9Kmu+1):
				agupMjtTxhzvJcLZ8DklEOW34B += FDzNAnIqkU0TL5tdMRaGb8jgBKYe(str(biA3YCgo42yxeQaf0LJKmFhRD),O9AyF2MRjI)
			for type,WGy8jZubInXc7zRBJ5p,url,wMCm6g9qFyPT0xpneDUNc2lEhaZY,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,kc57B93HrojbDIXVipY,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv in agupMjtTxhzvJcLZ8DklEOW34B:
				if kc57B93HrojbDIXVipY not in FucflUgB8b6DqkiywNSvtTodh1eXz:
					FucflUgB8b6DqkiywNSvtTodh1eXz.append(kc57B93HrojbDIXVipY)
					WmuFH5VSIroyBUqtOkhTg = type,WGy8jZubInXc7zRBJ5p,kc57B93HrojbDIXVipY,165,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,O9AyF2MRjI,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv
					ools3I2JVZrti8UPSXuxOFGeR6Yq.append(WmuFH5VSIroyBUqtOkhTg)
			agupMjtTxhzvJcLZ8DklEOW34B = sorted(ools3I2JVZrti8UPSXuxOFGeR6Yq,reverse=False,key=lambda key: key[1].lower())
			if EqVPHSM8fKuTaxh20WkNLd: OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,'SECTIONS_M3U','SECTIONS_M3U_ALL',agupMjtTxhzvJcLZ8DklEOW34B,NVbfv48oh3M6U)
	YD56nkJmsd[:] = jciMOQ6EWwadrYe+agupMjtTxhzvJcLZ8DklEOW34B
	bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin('Container.Refresh')
	return
def rINg2h7wvF1H3OlWeXn0(group,O9AyF2MRjI):
	EqVPHSM8fKuTaxh20WkNLd = False
	vS7JufTVsBxw52 = []
	xPEKByXj1tWn0SVl85Rdu2i = '_IPTV_' if 'IPTV' in O9AyF2MRjI else '_M3U_'
	if EqVPHSM8fKuTaxh20WkNLd: vS7JufTVsBxw52 = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,'list','SECTIONS'+xPEKByXj1tWn0SVl85Rdu2i[:-1],group)
	if not vS7JufTVsBxw52:
		for VhIGD8gM4BpZ3wsCPqQvK5L in range(1,vMrXCkF9Kmu+1):
			if EqVPHSM8fKuTaxh20WkNLd: vS7JufTVsBxw52 += AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,'list','SECTIONS'+xPEKByXj1tWn0SVl85Rdu2i[:-1],'SECTIONS'+xPEKByXj1tWn0SVl85Rdu2i+str(VhIGD8gM4BpZ3wsCPqQvK5L))
			elif xPEKByXj1tWn0SVl85Rdu2i=='_IPTV_': vS7JufTVsBxw52 += eYjkOB7G2aq5E3yfLlFNIV(str(VhIGD8gM4BpZ3wsCPqQvK5L),'_CREATENEW_')
			elif xPEKByXj1tWn0SVl85Rdu2i=='_M3U_': vS7JufTVsBxw52 += FDzNAnIqkU0TL5tdMRaGb8jgBKYe(str(VhIGD8gM4BpZ3wsCPqQvK5L),'_CREATENEW_')
		for type,WGy8jZubInXc7zRBJ5p,url,wMCm6g9qFyPT0xpneDUNc2lEhaZY,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,kc57B93HrojbDIXVipY,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv in vS7JufTVsBxw52:
			if kc57B93HrojbDIXVipY==group: JJGMsAH0CE5dbT1zpDeLWfR96Y8NXy(type,WGy8jZubInXc7zRBJ5p,url,wMCm6g9qFyPT0xpneDUNc2lEhaZY,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,kc57B93HrojbDIXVipY,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv)
		items,EbnzqW0GvY2dNMBpshU6fugi = [],[]
		for type,WGy8jZubInXc7zRBJ5p,url,wMCm6g9qFyPT0xpneDUNc2lEhaZY,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,kc57B93HrojbDIXVipY,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv in YD56nkJmsd:
			aE1d6CrXtHQNwVj07pzm5vR = type,WGy8jZubInXc7zRBJ5p[4:],url,wMCm6g9qFyPT0xpneDUNc2lEhaZY,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,kc57B93HrojbDIXVipY,Dm9TblyAjE0tFeO,''
			if aE1d6CrXtHQNwVj07pzm5vR not in EbnzqW0GvY2dNMBpshU6fugi:
				EbnzqW0GvY2dNMBpshU6fugi.append(aE1d6CrXtHQNwVj07pzm5vR)
				TMaJdc0xOFKNf = type,WGy8jZubInXc7zRBJ5p,url,wMCm6g9qFyPT0xpneDUNc2lEhaZY,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,kc57B93HrojbDIXVipY,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv
				items.append(TMaJdc0xOFKNf)
		vS7JufTVsBxw52 = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if EqVPHSM8fKuTaxh20WkNLd: OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,'SECTIONS'+xPEKByXj1tWn0SVl85Rdu2i[:-1],group,vS7JufTVsBxw52,NVbfv48oh3M6U)
	if '_RANDOM_' in O9AyF2MRjI and len(vS7JufTVsBxw52)>PgiWfI5So2e80LDzFVJtdvpOA:
		YD56nkJmsd[:] = []
		uQNUfbZx9yj0F('folder','[[COLOR FFC89008]'+group+'[/COLOR] :القسم]',group,165,'','',xPEKByXj1tWn0SVl85Rdu2i+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		uQNUfbZx9yj0F('folder','إعادة الطلب العشوائي من نفس القسم',group,165,'','',xPEKByXj1tWn0SVl85Rdu2i+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		vS7JufTVsBxw52 = YD56nkJmsd+jjyW6FTEOn3sSMo1G5LxBiA.sample(vS7JufTVsBxw52,PgiWfI5So2e80LDzFVJtdvpOA)
	YD56nkJmsd[:] = vS7JufTVsBxw52
	bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin('Container.Refresh')
	return
def QA7p61PXjC(O9AyF2MRjI):
	uQNUfbZx9yj0F('folder','إعادة طلب قنوات عشوائية','',161,'','','_FORGETRESULTS__REMEMBERRESULTS__LIVETV__RANDOM_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	PHc9jCB31E7 = YD56nkJmsd[:]
	YD56nkJmsd[:] = []
	import ssPnNR3VqA
	ssPnNR3VqA.tZwPW2bEz6S0OLXK84IjDYFqkde('0',False)
	ssPnNR3VqA.tZwPW2bEz6S0OLXK84IjDYFqkde('1',False)
	ssPnNR3VqA.tZwPW2bEz6S0OLXK84IjDYFqkde('2',False)
	if '_RANDOM_' in O9AyF2MRjI:
		YD56nkJmsd[:] = ooDinlFNQB(YD56nkJmsd)
		if len(YD56nkJmsd)>PgiWfI5So2e80LDzFVJtdvpOA: YD56nkJmsd[:] = jjyW6FTEOn3sSMo1G5LxBiA.sample(YD56nkJmsd,PgiWfI5So2e80LDzFVJtdvpOA)
	YD56nkJmsd[:] = PHc9jCB31E7+YD56nkJmsd
	return
def J8pm9UHCnhOkVZ(O9AyF2MRjI):
	O9AyF2MRjI = O9AyF2MRjI.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	headers = { 'User-Agent' : '' }
	url = 'https://www.bestrandoms.com/random-arabic-words'
	data = {'quantity':'50'}
	data = x1SKFacgifEdUthsYBbnC5XyTj(data)
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(Iu3GUD84WyEqQjPFTYeh1SL9J,'GET',url,data,headers,'','','RANDOMS-RANDOM_VIDEOS_FROM_WORDS-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="content"(.*?)class="clearfix"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('<span>(.*?)</span>.*?<span>(.*?)</span>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	IIEbR5TaZlHK,VrkL8eWuRXzZ5wxjC1KgMBUoF0mH = list(zip(*items))
	cIspaDv1hYNKgZ8M = []
	jDbqzv1RgC0apkiM = [' ','"','`',',','.',':',';',"'",'-']
	PehCSJXm79tL3kpKFlbdGTiZaQn4Ww = VrkL8eWuRXzZ5wxjC1KgMBUoF0mH+IIEbR5TaZlHK
	for wsKXgQY2cyuUfRdP in PehCSJXm79tL3kpKFlbdGTiZaQn4Ww:
		if wsKXgQY2cyuUfRdP in VrkL8eWuRXzZ5wxjC1KgMBUoF0mH: X481zKCWhS = 2
		if wsKXgQY2cyuUfRdP in IIEbR5TaZlHK: X481zKCWhS = 4
		B4R0FJmsKTl15yoLH = [Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in wsKXgQY2cyuUfRdP for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in jDbqzv1RgC0apkiM]
		if any(B4R0FJmsKTl15yoLH):
			M4Feb15G0QtrDlW6sPh9xNBnC3j = B4R0FJmsKTl15yoLH.index(True)
			xCT1GdwFo3XWZM9aHyip0f7KEb = jDbqzv1RgC0apkiM[M4Feb15G0QtrDlW6sPh9xNBnC3j]
			xxEwe2GjLUCTXpq = ''
			if wsKXgQY2cyuUfRdP.count(xCT1GdwFo3XWZM9aHyip0f7KEb)>1: VVYS3eRur45EDBqinLm8MWdOZg0Us,qqOf5ja0uov,xxEwe2GjLUCTXpq = wsKXgQY2cyuUfRdP.split(xCT1GdwFo3XWZM9aHyip0f7KEb,2)
			else: VVYS3eRur45EDBqinLm8MWdOZg0Us,qqOf5ja0uov = wsKXgQY2cyuUfRdP.split(xCT1GdwFo3XWZM9aHyip0f7KEb,1)
			if len(VVYS3eRur45EDBqinLm8MWdOZg0Us)>X481zKCWhS: cIspaDv1hYNKgZ8M.append(VVYS3eRur45EDBqinLm8MWdOZg0Us.lower())
			if len(qqOf5ja0uov)>X481zKCWhS: cIspaDv1hYNKgZ8M.append(qqOf5ja0uov.lower())
			if len(xxEwe2GjLUCTXpq)>X481zKCWhS: cIspaDv1hYNKgZ8M.append(xxEwe2GjLUCTXpq.lower())
		elif len(wsKXgQY2cyuUfRdP)>X481zKCWhS: cIspaDv1hYNKgZ8M.append(wsKXgQY2cyuUfRdP.lower())
	for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(9): jjyW6FTEOn3sSMo1G5LxBiA.shuffle(cIspaDv1hYNKgZ8M)
	if '_SITES_' in O9AyF2MRjI:
		If7FYO02ycn1Ao83kRxgueDB6ZN = yxMRrnqoNS5GTCh4K
	elif '_IPTV_' in O9AyF2MRjI:
		If7FYO02ycn1Ao83kRxgueDB6ZN = ['IPTV']
		import BSdmDzviZG
		if not BSdmDzviZG.OSDp6mYAsavhl0boq('',True): return
	elif '_M3U_' in O9AyF2MRjI:
		If7FYO02ycn1Ao83kRxgueDB6ZN = ['M3U']
		import kS9c6phm0W
		if not kS9c6phm0W.OSDp6mYAsavhl0boq('',True): return
	count,R2c5ueWa8rYyozCAq = 0,0
	uQNUfbZx9yj0F('folder','[  ] :البحث عن','',164,'','','_FORGETRESULTS__REMEMBERRESULTS_'+O9AyF2MRjI)
	uQNUfbZx9yj0F('folder','إعادة البحث العشوائي','',164,'','','_FORGETRESULTS__REMEMBERRESULTS_'+O9AyF2MRjI)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	MU8BmPgsbJ1hudHIjk = YD56nkJmsd[:]
	YD56nkJmsd[:] = []
	XSQlGEvDL0 = []
	for wsKXgQY2cyuUfRdP in cIspaDv1hYNKgZ8M:
		qqOf5ja0uov = u5h2Rckvw1E.findall('[ \,\;\:\-\+\=\"\'\[\]\(\)\{\}\!\@'+'#'+'\$\%\^\&\*\_\<\>]',wsKXgQY2cyuUfRdP,u5h2Rckvw1E.DOTALL)
		if qqOf5ja0uov: wsKXgQY2cyuUfRdP = wsKXgQY2cyuUfRdP.split(qqOf5ja0uov[0],1)[0]
		DJVs1582IaQ = wsKXgQY2cyuUfRdP.replace('ّ','').replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
		DJVs1582IaQ = DJVs1582IaQ.replace('ِ','').replace('ٍ','').replace('ْ','').replace('،','').replace('ـ','')
		if DJVs1582IaQ: XSQlGEvDL0.append(DJVs1582IaQ)
	BFMX1THNACOLsG4E5bqn0 = []
	for k0G4LTYt93po in range(0,20):
		search = jjyW6FTEOn3sSMo1G5LxBiA.sample(XSQlGEvDL0,1)[0]
		if search in BFMX1THNACOLsG4E5bqn0: continue
		BFMX1THNACOLsG4E5bqn0.append(search)
		tzVT6PXndWu0 = jjyW6FTEOn3sSMo1G5LxBiA.sample(If7FYO02ycn1Ao83kRxgueDB6ZN,1)[0]
		l0SAerv8zGH2Wa('NOTICE',CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+'   Random Video Search   site:'+str(tzVT6PXndWu0)+'  search:'+search)
		lKC9tsMTk1xeVIDmUjwrZzvhP50,lfXd1GQTyCkVSUzAeO,gprYWX3BPb7EVuv4wmlc = BZ60Cr5qARSJYjkD(tzVT6PXndWu0)
		lfXd1GQTyCkVSUzAeO(search+'_NODIALOGS_')
		if len(YD56nkJmsd)>0: break
	search = search.replace('_MOD_','')
	MU8BmPgsbJ1hudHIjk[0][1] = '[[COLOR FFC89008]'+search+'[/COLOR] :بحث عن]'
	YD56nkJmsd[:] = ooDinlFNQB(YD56nkJmsd)
	if len(YD56nkJmsd)>PgiWfI5So2e80LDzFVJtdvpOA: YD56nkJmsd[:] = jjyW6FTEOn3sSMo1G5LxBiA.sample(YD56nkJmsd,PgiWfI5So2e80LDzFVJtdvpOA)
	YD56nkJmsd[:] = MU8BmPgsbJ1hudHIjk+YD56nkJmsd
	return
def ieTElnByYba9rsMtPpG(DvPHnkSL0RJNd,O9AyF2MRjI):
	DvPHnkSL0RJNd = DvPHnkSL0RJNd.replace('_MOD_','')
	O9AyF2MRjI = O9AyF2MRjI.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	w4wedGRiInz1Xm6Dro7UNjLHcKx(False)
	if NW1z9Mg8T2=={}: return
	if '_RANDOM_' in O9AyF2MRjI:
		uQNUfbZx9yj0F('folder','[[COLOR FFC89008]'+DvPHnkSL0RJNd+'[/COLOR] :القسم]',DvPHnkSL0RJNd,166,'','','_FORGETRESULTS__REMEMBERRESULTS_'+O9AyF2MRjI)
		uQNUfbZx9yj0F('folder','إعادة الطلب العشوائي من نفس القسم',DvPHnkSL0RJNd,166,'','','_FORGETRESULTS__REMEMBERRESULTS_'+O9AyF2MRjI)
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for website in sorted(list(NW1z9Mg8T2[DvPHnkSL0RJNd].keys())):
		type,WGy8jZubInXc7zRBJ5p,url,NjQaSix1UCsEclTfwRX,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,kc57B93HrojbDIXVipY,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv = NW1z9Mg8T2[DvPHnkSL0RJNd][website]
		if '_RANDOM_' in O9AyF2MRjI or len(NW1z9Mg8T2[DvPHnkSL0RJNd])==1:
			JJGMsAH0CE5dbT1zpDeLWfR96Y8NXy(type,'',url,NjQaSix1UCsEclTfwRX,'',BzbaC0qYjMr2WXwsO,kc57B93HrojbDIXVipY,'','')
			YD56nkJmsd[:] = ooDinlFNQB(YD56nkJmsd)
			jciMOQ6EWwadrYe,agupMjtTxhzvJcLZ8DklEOW34B = YD56nkJmsd[:3],YD56nkJmsd[3:]
			for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(9): jjyW6FTEOn3sSMo1G5LxBiA.shuffle(agupMjtTxhzvJcLZ8DklEOW34B)
			if '_RANDOM_' in O9AyF2MRjI: YD56nkJmsd[:] = jciMOQ6EWwadrYe+agupMjtTxhzvJcLZ8DklEOW34B[:PgiWfI5So2e80LDzFVJtdvpOA]
			else: YD56nkJmsd[:] = jciMOQ6EWwadrYe+agupMjtTxhzvJcLZ8DklEOW34B
		elif '_SITES_' in O9AyF2MRjI: uQNUfbZx9yj0F('folder',website,url,NjQaSix1UCsEclTfwRX,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,kc57B93HrojbDIXVipY,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv)
	return
def ipFyMGOmXzWPnHJV4NlYab50sRUTK7(O9AyF2MRjI,wMCm6g9qFyPT0xpneDUNc2lEhaZY):
	O9AyF2MRjI = O9AyF2MRjI.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	WGy8jZubInXc7zRBJ5p,qP8bYalvjxTkwNn = '',[]
	uQNUfbZx9yj0F('folder','[[COLOR FFC89008]'+WGy8jZubInXc7zRBJ5p+'[/COLOR] :القسم]','',wMCm6g9qFyPT0xpneDUNc2lEhaZY,'','','_FORGETRESULTS__REMEMBERRESULTS_'+O9AyF2MRjI)
	uQNUfbZx9yj0F('folder','إعادة طلب قسم عشوائي','',wMCm6g9qFyPT0xpneDUNc2lEhaZY,'','','_FORGETRESULTS__REMEMBERRESULTS_'+O9AyF2MRjI)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	jciMOQ6EWwadrYe = YD56nkJmsd[:]
	YD56nkJmsd[:] = []
	vS7JufTVsBxw52 = []
	if '_SITES_' in O9AyF2MRjI:
		w4wedGRiInz1Xm6Dro7UNjLHcKx(False)
		if NW1z9Mg8T2=={}: return
		HJZuyoN81j6A2 = list(NW1z9Mg8T2.keys())
		DvPHnkSL0RJNd = jjyW6FTEOn3sSMo1G5LxBiA.sample(HJZuyoN81j6A2,1)[0]
		cIspaDv1hYNKgZ8M = list(NW1z9Mg8T2[DvPHnkSL0RJNd].keys())
		website = jjyW6FTEOn3sSMo1G5LxBiA.sample(cIspaDv1hYNKgZ8M,1)[0]
		type,WGy8jZubInXc7zRBJ5p,url,NjQaSix1UCsEclTfwRX,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,kc57B93HrojbDIXVipY,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv = NW1z9Mg8T2[DvPHnkSL0RJNd][website]
		l0SAerv8zGH2Wa('NOTICE',CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+'   Random Category   website: '+website+'   name: '+WGy8jZubInXc7zRBJ5p+'   url: '+url+'   mode: '+str(NjQaSix1UCsEclTfwRX))
	elif '_IPTV_' in O9AyF2MRjI:
		import BSdmDzviZG
		if not BSdmDzviZG.OSDp6mYAsavhl0boq('',True): return
		for VhIGD8gM4BpZ3wsCPqQvK5L in range(1,vMrXCkF9Kmu+1):
			vS7JufTVsBxw52 += eYjkOB7G2aq5E3yfLlFNIV(str(VhIGD8gM4BpZ3wsCPqQvK5L),O9AyF2MRjI)
		if not vS7JufTVsBxw52: return
		type,WGy8jZubInXc7zRBJ5p,url,NjQaSix1UCsEclTfwRX,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,kc57B93HrojbDIXVipY,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv = jjyW6FTEOn3sSMo1G5LxBiA.sample(vS7JufTVsBxw52,1)[0]
		l0SAerv8zGH2Wa('NOTICE',CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+'   Random Category   name: '+WGy8jZubInXc7zRBJ5p+'   url: '+url+'   mode: '+str(NjQaSix1UCsEclTfwRX))
	elif '_M3U_' in O9AyF2MRjI:
		import kS9c6phm0W
		if not kS9c6phm0W.OSDp6mYAsavhl0boq('',True): return
		for VhIGD8gM4BpZ3wsCPqQvK5L in range(1,vMrXCkF9Kmu+1):
			vS7JufTVsBxw52 += FDzNAnIqkU0TL5tdMRaGb8jgBKYe(str(VhIGD8gM4BpZ3wsCPqQvK5L),O9AyF2MRjI)
		if not vS7JufTVsBxw52: return
		type,WGy8jZubInXc7zRBJ5p,url,NjQaSix1UCsEclTfwRX,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,kc57B93HrojbDIXVipY,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv = jjyW6FTEOn3sSMo1G5LxBiA.sample(vS7JufTVsBxw52,1)[0]
		l0SAerv8zGH2Wa('NOTICE',CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+'   Random Category   name: '+WGy8jZubInXc7zRBJ5p+'   url: '+url+'   mode: '+str(NjQaSix1UCsEclTfwRX))
	O6utD3YZiLQ0npfXToE2qmwGcxayM = WGy8jZubInXc7zRBJ5p
	YYAEmMiXoteuvPGFwQbaIy6nLl = []
	for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(0,10):
		if Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE>0: l0SAerv8zGH2Wa('NOTICE',CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+'   Random Category   name: '+WGy8jZubInXc7zRBJ5p+'   url: '+url+'   mode: '+str(NjQaSix1UCsEclTfwRX))
		YD56nkJmsd[:] = []
		if NjQaSix1UCsEclTfwRX==234 and '__IPTVSeries__' in kc57B93HrojbDIXVipY: NjQaSix1UCsEclTfwRX = 233
		if NjQaSix1UCsEclTfwRX==714 and '__M3USeries__' in kc57B93HrojbDIXVipY: NjQaSix1UCsEclTfwRX = 713
		if NjQaSix1UCsEclTfwRX==144: NjQaSix1UCsEclTfwRX = 291
		qBdHbiaM0lmk5GNsfrXCIYyugR = JJGMsAH0CE5dbT1zpDeLWfR96Y8NXy(type,WGy8jZubInXc7zRBJ5p,url,NjQaSix1UCsEclTfwRX,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,kc57B93HrojbDIXVipY,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv)
		if '_IPTV_' in O9AyF2MRjI and NjQaSix1UCsEclTfwRX==167: del YD56nkJmsd[:3]
		if '_M3U_' in O9AyF2MRjI and NjQaSix1UCsEclTfwRX==168: del YD56nkJmsd[:3]
		qP8bYalvjxTkwNn[:] = ooDinlFNQB(YD56nkJmsd)
		if YYAEmMiXoteuvPGFwQbaIy6nLl and XSuCEhVPZvBIfwyFjipYaRks0(u'حلقة') in str(qP8bYalvjxTkwNn) or XSuCEhVPZvBIfwyFjipYaRks0(u'حلقه') in str(qP8bYalvjxTkwNn):
			WGy8jZubInXc7zRBJ5p = O6utD3YZiLQ0npfXToE2qmwGcxayM
			qP8bYalvjxTkwNn[:] = YYAEmMiXoteuvPGFwQbaIy6nLl
			break
		O6utD3YZiLQ0npfXToE2qmwGcxayM = WGy8jZubInXc7zRBJ5p
		YYAEmMiXoteuvPGFwQbaIy6nLl = qP8bYalvjxTkwNn
		if str(qP8bYalvjxTkwNn).count('video')>0: break
		if str(qP8bYalvjxTkwNn).count('live')>0: break
		if NjQaSix1UCsEclTfwRX==233: break
		if NjQaSix1UCsEclTfwRX==713: break
		if NjQaSix1UCsEclTfwRX==291: break
		if qP8bYalvjxTkwNn: type,WGy8jZubInXc7zRBJ5p,url,NjQaSix1UCsEclTfwRX,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,kc57B93HrojbDIXVipY,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv = jjyW6FTEOn3sSMo1G5LxBiA.sample(qP8bYalvjxTkwNn,1)[0]
	if not WGy8jZubInXc7zRBJ5p: WGy8jZubInXc7zRBJ5p = '....'
	elif WGy8jZubInXc7zRBJ5p.count('_')>1: WGy8jZubInXc7zRBJ5p = WGy8jZubInXc7zRBJ5p.split('_',2)[2]
	WGy8jZubInXc7zRBJ5p = WGy8jZubInXc7zRBJ5p.replace('UNKNOWN: ','')
	WGy8jZubInXc7zRBJ5p = WGy8jZubInXc7zRBJ5p.replace('_MOD_','')
	jciMOQ6EWwadrYe[0][1] = '[[COLOR FFC89008]'+WGy8jZubInXc7zRBJ5p+'[/COLOR] :القسم]'
	for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(9): jjyW6FTEOn3sSMo1G5LxBiA.shuffle(qP8bYalvjxTkwNn)
	if '_RANDOM_' in O9AyF2MRjI: YD56nkJmsd[:] = jciMOQ6EWwadrYe+qP8bYalvjxTkwNn[:PgiWfI5So2e80LDzFVJtdvpOA]
	else: YD56nkJmsd[:] = jciMOQ6EWwadrYe+qP8bYalvjxTkwNn
	return
def MMAd6CQGWNPIuDjE(fmWnlGZaoLDF1SBYuKbV78XCj325h9,Ixjy1kagUP2WeMHXEhbpTYzK0ftDV):
	Ixjy1kagUP2WeMHXEhbpTYzK0ftDV = Ixjy1kagUP2WeMHXEhbpTYzK0ftDV.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	aRnu1v2K0TJLPkGqAZ6Q34wFxEsWiy = Ixjy1kagUP2WeMHXEhbpTYzK0ftDV
	if '__IPTVSeries__' in Ixjy1kagUP2WeMHXEhbpTYzK0ftDV:
		aRnu1v2K0TJLPkGqAZ6Q34wFxEsWiy = Ixjy1kagUP2WeMHXEhbpTYzK0ftDV.split('__IPTVSeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in fmWnlGZaoLDF1SBYuKbV78XCj325h9: type = ',VIDEOS: '
	elif 'LIVE' in fmWnlGZaoLDF1SBYuKbV78XCj325h9: type = ',LIVE: '
	uQNUfbZx9yj0F('folder','[[COLOR FFC89008]'+type+aRnu1v2K0TJLPkGqAZ6Q34wFxEsWiy+'[/COLOR] :القسم]',fmWnlGZaoLDF1SBYuKbV78XCj325h9,167,'','','_FORGETRESULTS__REMEMBERRESULTS_'+Ixjy1kagUP2WeMHXEhbpTYzK0ftDV)
	uQNUfbZx9yj0F('folder','إعادة الطلب العشوائي من نفس القسم',fmWnlGZaoLDF1SBYuKbV78XCj325h9,167,'','','_FORGETRESULTS__REMEMBERRESULTS_'+Ixjy1kagUP2WeMHXEhbpTYzK0ftDV)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	import BSdmDzviZG
	for VhIGD8gM4BpZ3wsCPqQvK5L in range(1,vMrXCkF9Kmu+1):
		if '__IPTVSeries__' in Ixjy1kagUP2WeMHXEhbpTYzK0ftDV: BSdmDzviZG.dK9CqzeR1asO(str(VhIGD8gM4BpZ3wsCPqQvK5L),fmWnlGZaoLDF1SBYuKbV78XCj325h9,Ixjy1kagUP2WeMHXEhbpTYzK0ftDV,'',False)
		else: BSdmDzviZG.tZwPW2bEz6S0OLXK84IjDYFqkde(str(VhIGD8gM4BpZ3wsCPqQvK5L),fmWnlGZaoLDF1SBYuKbV78XCj325h9,Ixjy1kagUP2WeMHXEhbpTYzK0ftDV,'',False)
	YD56nkJmsd[:] = ooDinlFNQB(YD56nkJmsd)
	if len(YD56nkJmsd)>(PgiWfI5So2e80LDzFVJtdvpOA+3): YD56nkJmsd[:] = YD56nkJmsd[:3]+jjyW6FTEOn3sSMo1G5LxBiA.sample(YD56nkJmsd[3:],PgiWfI5So2e80LDzFVJtdvpOA)
	return
def FjnzX6skMeGYdC2UwJRZ7tWQc(fmWnlGZaoLDF1SBYuKbV78XCj325h9,Ixjy1kagUP2WeMHXEhbpTYzK0ftDV):
	Ixjy1kagUP2WeMHXEhbpTYzK0ftDV = Ixjy1kagUP2WeMHXEhbpTYzK0ftDV.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	aRnu1v2K0TJLPkGqAZ6Q34wFxEsWiy = Ixjy1kagUP2WeMHXEhbpTYzK0ftDV
	if '__M3USeries__' in Ixjy1kagUP2WeMHXEhbpTYzK0ftDV:
		aRnu1v2K0TJLPkGqAZ6Q34wFxEsWiy = Ixjy1kagUP2WeMHXEhbpTYzK0ftDV.split('__M3USeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in fmWnlGZaoLDF1SBYuKbV78XCj325h9: type = ',VIDEOS: '
	elif 'LIVE' in fmWnlGZaoLDF1SBYuKbV78XCj325h9: type = ',LIVE: '
	uQNUfbZx9yj0F('folder','[[COLOR FFC89008]'+type+aRnu1v2K0TJLPkGqAZ6Q34wFxEsWiy+'[/COLOR] :القسم]',fmWnlGZaoLDF1SBYuKbV78XCj325h9,168,'','','_FORGETRESULTS__REMEMBERRESULTS_'+Ixjy1kagUP2WeMHXEhbpTYzK0ftDV)
	uQNUfbZx9yj0F('folder','إعادة الطلب العشوائي من نفس القسم',fmWnlGZaoLDF1SBYuKbV78XCj325h9,168,'','','_FORGETRESULTS__REMEMBERRESULTS_'+Ixjy1kagUP2WeMHXEhbpTYzK0ftDV)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	import kS9c6phm0W
	for VhIGD8gM4BpZ3wsCPqQvK5L in range(1,vMrXCkF9Kmu+1):
		if '__M3USeries__' in Ixjy1kagUP2WeMHXEhbpTYzK0ftDV: kS9c6phm0W.dK9CqzeR1asO(str(VhIGD8gM4BpZ3wsCPqQvK5L),fmWnlGZaoLDF1SBYuKbV78XCj325h9,Ixjy1kagUP2WeMHXEhbpTYzK0ftDV,'',False)
		else: kS9c6phm0W.tZwPW2bEz6S0OLXK84IjDYFqkde(str(VhIGD8gM4BpZ3wsCPqQvK5L),fmWnlGZaoLDF1SBYuKbV78XCj325h9,Ixjy1kagUP2WeMHXEhbpTYzK0ftDV,'',False)
	YD56nkJmsd[:] = ooDinlFNQB(YD56nkJmsd)
	if len(YD56nkJmsd)>(PgiWfI5So2e80LDzFVJtdvpOA+3): YD56nkJmsd[:] = YD56nkJmsd[:3]+jjyW6FTEOn3sSMo1G5LxBiA.sample(YD56nkJmsd[3:],PgiWfI5So2e80LDzFVJtdvpOA)
	return
def ooDinlFNQB(YD56nkJmsd):
	qP8bYalvjxTkwNn = []
	for type,WGy8jZubInXc7zRBJ5p,url,wMCm6g9qFyPT0xpneDUNc2lEhaZY,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,kc57B93HrojbDIXVipY,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv in YD56nkJmsd:
		if 'صفحة' in WGy8jZubInXc7zRBJ5p or 'صفحه' in WGy8jZubInXc7zRBJ5p or 'page' in WGy8jZubInXc7zRBJ5p.lower(): continue
		qP8bYalvjxTkwNn.append([type,WGy8jZubInXc7zRBJ5p,url,wMCm6g9qFyPT0xpneDUNc2lEhaZY,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,kc57B93HrojbDIXVipY,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv])
	return qP8bYalvjxTkwNn
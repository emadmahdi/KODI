# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'LODYNET'
tiCRYyX1bWd40Ir3PafQu = '_LDN_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['الرئيسية','استفسارتكم و الطلبات']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==450: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==451: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,text)
	elif mode==452: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==453: vS7JufTVsBxw52 = xxWn9XKlJmchkHrLUMugIFySa7(url)
	elif mode==454: vS7JufTVsBxw52 = GA2KIlbOsoYtxpkDF71(url)
	elif mode==459: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',yONJxHER9BIDPpTV4YsWmc0n,'','','','','LODYNET-MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	jGX4sfdrWaeZpA1VyvTK = hmcFWJUgiAuGk(yONJxHER9BIDPpTV4YsWmc0n,'url')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',459,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'مثبتات لودي نت',jGX4sfdrWaeZpA1VyvTK,451,'','','featured')
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'المضاف حديثا',jGX4sfdrWaeZpA1VyvTK,451,'','','latest')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"MainMenu"(.*?)"SiteSlider"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if ekTrZlFMu0Kf5QztEnhAs=='#': continue
			if title in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,451)
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,lcOov4Kz0uBairTpLxXgAqIt72mk=''):
	items = []
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','LODYNET-TITLES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	if lcOov4Kz0uBairTpLxXgAqIt72mk=='featured':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"SiteSlider"(.*?)"waves"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	elif lcOov4Kz0uBairTpLxXgAqIt72mk=='latest':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"RecentPosts"(.*?)"pagination"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	elif '"ActorsList"' in oo9SgGkiDbs3HRn7z8:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"ActorsList"(.*?)"text/javascript"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)"(.*?)"ActorName">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	elif lcOov4Kz0uBairTpLxXgAqIt72mk in ['0','1','2']:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"Section"(.*?)</li></ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[int(lcOov4Kz0uBairTpLxXgAqIt72mk)]
	else:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"BlocksArea"(.*?)"text/javascript"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	if not items: items = u5h2Rckvw1E.findall('href="(.*?)".*?src="(.*?)".*?<h2>(.*?)</h2>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	yn8DkpE5etF3WiUmfSO = []
	dR94SHEmDA8nflN = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
		if '"ActorsList"' in oo9SgGkiDbs3HRn7z8 and 'src=' in pGjsvdyHfM:
			pGjsvdyHfM = u5h2Rckvw1E.findall('src="(.*?)"',pGjsvdyHfM,u5h2Rckvw1E.DOTALL)
			pGjsvdyHfM = pGjsvdyHfM[0]
		ekTrZlFMu0Kf5QztEnhAs = P2o6ZDHeW790pSQqucvnxzILVUX(ekTrZlFMu0Kf5QztEnhAs).strip('/')
		zAjwuoRY98mXN6xvE = u5h2Rckvw1E.findall('(.*?) حلقة \d+',title,u5h2Rckvw1E.DOTALL)
		if not zAjwuoRY98mXN6xvE: zAjwuoRY98mXN6xvE = u5h2Rckvw1E.findall('(.*?) الحلقة \d+',title,u5h2Rckvw1E.DOTALL)
		if set(title.split()) & set(dR94SHEmDA8nflN) and 'مسلسل' not in title:
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,452,pGjsvdyHfM)
		elif zAjwuoRY98mXN6xvE and 'حلقة' in title:
			title = '_MOD_' + zAjwuoRY98mXN6xvE[0]
			if title not in yn8DkpE5etF3WiUmfSO:
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,453,pGjsvdyHfM)
				yn8DkpE5etF3WiUmfSO.append(title)
		else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,453,pGjsvdyHfM)
	if lcOov4Kz0uBairTpLxXgAqIt72mk in ['','latest']:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"pagination"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,title in items:
				title = uTUNPkVwCMKiD5gHLaj(title)
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+title,ekTrZlFMu0Kf5QztEnhAs,451)
	return
def xxWn9XKlJmchkHrLUMugIFySa7(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','LODYNET-SEASONS-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	kQ7LGm5DPnH8hUdtWY = u5h2Rckvw1E.findall('"CategorySubLinks"(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if kQ7LGm5DPnH8hUdtWY and 'href=' in str(kQ7LGm5DPnH8hUdtWY):
		title = u5h2Rckvw1E.findall('<title>(.*?)-',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		title = title[0].strip(' ')
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,454)
		lmO2YJGr6tCV = kQ7LGm5DPnH8hUdtWY[0]
		items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,454)
	else: GA2KIlbOsoYtxpkDF71(url)
	return
def GA2KIlbOsoYtxpkDF71(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','LODYNET-EPISODES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	RfTOHSzgpA = u5h2Rckvw1E.findall('"BlocksArea"(.*?)"text/javascript"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if RfTOHSzgpA:
		lmO2YJGr6tCV = RfTOHSzgpA[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?src="(.*?)".*?<h2>(.*?)</h2>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,452,pGjsvdyHfM)
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"pagination"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,title in items:
				title = uTUNPkVwCMKiD5gHLaj(title)
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+title,ekTrZlFMu0Kf5QztEnhAs,454)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	gANn35esloKUydOipfSMC6RD2 = url.replace('/movies/','/watch_movies/')
	gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2.replace('/episodes/','/watch_episodes/')
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',gANn35esloKUydOipfSMC6RD2,'','','','','LODYNET-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	jGX4sfdrWaeZpA1VyvTK = hmcFWJUgiAuGk(gANn35esloKUydOipfSMC6RD2,'url')
	EaBeVhOsHYg8wub = []
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"WatchTitle"(.*?)</aside>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('data-embed="(.*?)">(.*?)</li>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+title+'__watch'
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"DownloadLinks"(.*?)"selary"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?<span>(.*?)</span>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,name in items:
			name = uTUNPkVwCMKiD5gHLaj(name)
			ohAHUqdbWFi8D1L4Xwzus0f3RYv = u5h2Rckvw1E.findall('\d\d\d+',name,u5h2Rckvw1E.DOTALL)
			if ohAHUqdbWFi8D1L4Xwzus0f3RYv:
				ohAHUqdbWFi8D1L4Xwzus0f3RYv = '____'+ohAHUqdbWFi8D1L4Xwzus0f3RYv[0]
				name = ''
			else: ohAHUqdbWFi8D1L4Xwzus0f3RYv = ''
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+name+'__download'+ohAHUqdbWFi8D1L4Xwzus0f3RYv
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(EaBeVhOsHYg8wub,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	search = search.replace(' ','+')
	url = yONJxHER9BIDPpTV4YsWmc0n+'/search/'+search
	ll0a2AwztChcpsDUMi4rGW3b61XZES(url)
	return
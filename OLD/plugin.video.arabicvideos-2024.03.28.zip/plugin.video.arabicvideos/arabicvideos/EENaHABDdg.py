# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'CIMA400'
tiCRYyX1bWd40Ir3PafQu = '_C4H_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['الصفحة الرئيسية','Sign in','الاقسام','عرض المزيد','Categories','']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==690: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==691: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,text)
	elif mode==692: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==693: vS7JufTVsBxw52 = GUqAucke4iYjoRn7X(url,text)
	elif mode==694: vS7JufTVsBxw52 = GQsDp6PWFHRE1ki2odqrwjB0ISTLh(url)
	elif mode==699: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',yONJxHER9BIDPpTV4YsWmc0n,'','','','','CIMA400-MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',699,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"navslide-divider"(.*?)"navslide-divider"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)</',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		if title in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
		title = title.replace('<b>','').strip(' ')
		uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,694)
	return
def GQsDp6PWFHRE1ki2odqrwjB0ISTLh(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','CIMA400-SUBMENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	kQ7LGm5DPnH8hUdtWY = u5h2Rckvw1E.findall('"caret"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if kQ7LGm5DPnH8hUdtWY:
		lmO2YJGr6tCV = kQ7LGm5DPnH8hUdtWY[0]
		lmO2YJGr6tCV = lmO2YJGr6tCV.replace('"presentation"','</ul>')
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if not cWafzb4HoG1Em3Jwxu6C7vZsVi: cWafzb4HoG1Em3Jwxu6C7vZsVi = [('',lmO2YJGr6tCV)]
		uQNUfbZx9yj0F('link','[COLOR FFC89008] فرز أو فلتر أو ترتيب [/COLOR]','',9999)
		for TG4VYSm6McPxR,lmO2YJGr6tCV in cWafzb4HoG1Em3Jwxu6C7vZsVi:
			items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			if TG4VYSm6McPxR: TG4VYSm6McPxR = TG4VYSm6McPxR+': '
			for ekTrZlFMu0Kf5QztEnhAs,title in items:
				title = TG4VYSm6McPxR+title
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,691)
	RfTOHSzgpA = u5h2Rckvw1E.findall('"pm-category-subcats"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if RfTOHSzgpA:
		lmO2YJGr6tCV = RfTOHSzgpA[0]
		items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if len(items)<30:
			uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			for ekTrZlFMu0Kf5QztEnhAs,title in items:
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,691)
	if not kQ7LGm5DPnH8hUdtWY and not RfTOHSzgpA: ll0a2AwztChcpsDUMi4rGW3b61XZES(url)
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,VemfsE32zgI=''):
	if VemfsE32zgI=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'POST',url,data,headers,'','','CIMA400-TITLES-1st')
	else:
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','CIMA400-TITLES-2nd')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	lmO2YJGr6tCV,items = '',[]
	jGX4sfdrWaeZpA1VyvTK = hmcFWJUgiAuGk(url,'url')
	if VemfsE32zgI=='ajax-search':
		lmO2YJGr6tCV = oo9SgGkiDbs3HRn7z8
		EbnzqW0GvY2dNMBpshU6fugi = u5h2Rckvw1E.findall('href="(.*?)">(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in EbnzqW0GvY2dNMBpshU6fugi: items.append(('',ekTrZlFMu0Kf5QztEnhAs,title))
	elif VemfsE32zgI=='featured':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"pm-video-watch-featured"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi: lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	elif VemfsE32zgI=='new_episodes':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"row pm-ul-browse-videos(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi: lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	elif VemfsE32zgI=='new_movies':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"row pm-ul-browse-videos(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if len(cWafzb4HoG1Em3Jwxu6C7vZsVi)>1: lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[1]
	elif VemfsE32zgI=='featured_series':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"ba mgb table full"(.*?)"clearfix"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi: lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		EbnzqW0GvY2dNMBpshU6fugi = u5h2Rckvw1E.findall('href="(.*?)" title="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in EbnzqW0GvY2dNMBpshU6fugi: items.append(('',ekTrZlFMu0Kf5QztEnhAs,title))
	else:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('(data-echo=".*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi: lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	if lmO2YJGr6tCV and not items: items = u5h2Rckvw1E.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	if not items: return
	yn8DkpE5etF3WiUmfSO = []
	dR94SHEmDA8nflN = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for pGjsvdyHfM,ekTrZlFMu0Kf5QztEnhAs,title in items:
		zAjwuoRY98mXN6xvE = u5h2Rckvw1E.findall('(.*?) (الحلقة|حلقة).\d+',title,u5h2Rckvw1E.DOTALL)
		if any(c2eEflztvIX in title for c2eEflztvIX in dR94SHEmDA8nflN):
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,692,pGjsvdyHfM)
		elif VemfsE32zgI=='new_episodes':
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,692,pGjsvdyHfM)
		elif zAjwuoRY98mXN6xvE:
			title = '_MOD_' + zAjwuoRY98mXN6xvE[0][0]
			if title not in yn8DkpE5etF3WiUmfSO:
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,693,pGjsvdyHfM)
				yn8DkpE5etF3WiUmfSO.append(title)
		else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,693,pGjsvdyHfM)
	if 1:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"pagination(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,title in items:
				if ekTrZlFMu0Kf5QztEnhAs=='#': continue
				ekTrZlFMu0Kf5QztEnhAs = jGX4sfdrWaeZpA1VyvTK+'/'+ekTrZlFMu0Kf5QztEnhAs.strip('/')
				title = uTUNPkVwCMKiD5gHLaj(title)
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+title,ekTrZlFMu0Kf5QztEnhAs,691)
	return
def GUqAucke4iYjoRn7X(url,rBOCITLay7XvDlcnjf5):
	jGX4sfdrWaeZpA1VyvTK = hmcFWJUgiAuGk(url,'url')
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','CIMA400-EPISODES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	kQ7LGm5DPnH8hUdtWY = u5h2Rckvw1E.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx = u5h2Rckvw1E.findall('"series-header".*?src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx: pGjsvdyHfM = ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx[0]
	else: pGjsvdyHfM = ''
	items = []
	Y3Wy9jGn71QESi = False
	if kQ7LGm5DPnH8hUdtWY and not rBOCITLay7XvDlcnjf5:
		lmO2YJGr6tCV = kQ7LGm5DPnH8hUdtWY[0]
		items = u5h2Rckvw1E.findall('''openCity\(event, '(.*?)'\).*?">(.*?)</button>''',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if not items: items = u5h2Rckvw1E.findall('data-serie="(.*?)".*?">(.*?)</',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for rBOCITLay7XvDlcnjf5,title in items:
			rBOCITLay7XvDlcnjf5 = rBOCITLay7XvDlcnjf5.strip('#')
			if len(items)>1: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,693,pGjsvdyHfM,'',rBOCITLay7XvDlcnjf5)
			else: Y3Wy9jGn71QESi = True
	else: Y3Wy9jGn71QESi = True
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"SeasonsEpisodesMain(.*?</div>).</div>.</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	RfTOHSzgpA = u5h2Rckvw1E.findall('id="'+rBOCITLay7XvDlcnjf5+'"(.*?)</ul>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	if not RfTOHSzgpA: RfTOHSzgpA = u5h2Rckvw1E.findall('data-serie="'+rBOCITLay7XvDlcnjf5+'"(.*?)</div>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	if not RfTOHSzgpA: RfTOHSzgpA = u5h2Rckvw1E.findall('id="Season'+rBOCITLay7XvDlcnjf5+'"(.*?)</ul>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	if RfTOHSzgpA and Y3Wy9jGn71QESi:
		lmO2YJGr6tCV = RfTOHSzgpA[0]
		EbnzqW0GvY2dNMBpshU6fugi = u5h2Rckvw1E.findall("href='(.*?)'><li><em>(.*?)</span>",lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if not EbnzqW0GvY2dNMBpshU6fugi: EbnzqW0GvY2dNMBpshU6fugi = u5h2Rckvw1E.findall('href="(.*?)".*?<em>(.*?)</span>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		items = []
		for ekTrZlFMu0Kf5QztEnhAs,title in EbnzqW0GvY2dNMBpshU6fugi: items.append((ekTrZlFMu0Kf5QztEnhAs,title,pGjsvdyHfM))
		if not items: items = u5h2Rckvw1E.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title,pGjsvdyHfM in items:
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.strip('./')
			ekTrZlFMu0Kf5QztEnhAs = jGX4sfdrWaeZpA1VyvTK+'/'+ekTrZlFMu0Kf5QztEnhAs.strip('/')
			title = title.replace('</em><span>',' ')
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,692,pGjsvdyHfM)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	EaBeVhOsHYg8wub,qUTPXnBoegj5QybG1t0VNJxv6u,GnuaoT9MxiCg = [],[],[]
	gANn35esloKUydOipfSMC6RD2 = url.replace('/watch.php','/see.php')
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',gANn35esloKUydOipfSMC6RD2,'','','','','CIMA400-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"WatchList"(.*?)</div>.</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('<iframe src="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if ekTrZlFMu0Kf5QztEnhAs:
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs[0]
			qUTPXnBoegj5QybG1t0VNJxv6u.append('?named=__embed')
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
		lQUf3AY258LeWch = u5h2Rckvw1E.findall('data-embed-url="(.*?)".*?onclick.*?">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in lQUf3AY258LeWch:
			title = title.strip(' ')
			if ekTrZlFMu0Kf5QztEnhAs not in EaBeVhOsHYg8wub:
				qUTPXnBoegj5QybG1t0VNJxv6u.append('?named='+title+'__watch')
				EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
		lQUf3AY258LeWch = u5h2Rckvw1E.findall('href="(http.*?)".*?</i>(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in lQUf3AY258LeWch:
			if ekTrZlFMu0Kf5QztEnhAs not in EaBeVhOsHYg8wub:
				title = title.strip('\n')
				qUTPXnBoegj5QybG1t0VNJxv6u.append('?named='+title+'__download')
				EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	Cme2tRqGfkrX = zip(EaBeVhOsHYg8wub,qUTPXnBoegj5QybG1t0VNJxv6u)
	for ekTrZlFMu0Kf5QztEnhAs,name in Cme2tRqGfkrX: GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs+name)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(GnuaoT9MxiCg,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	search = search.replace(' ','+')
	url = yONJxHER9BIDPpTV4YsWmc0n+'/search.php?keywords='+search
	ll0a2AwztChcpsDUMi4rGW3b61XZES(url,'search')
	return
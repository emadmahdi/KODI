# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'SHIAVOICE'
tiCRYyX1bWd40Ir3PafQu = '_SHV_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
headers = {'User-Agent':None}
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==310: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==311: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url)
	elif mode==312: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==313: vS7JufTVsBxw52 = qBXKTp7h5vAUV1xjgb4i9Ws(url)
	elif mode==314: vS7JufTVsBxw52 = VCio1EXzNgM8WLmYbxtBdw(text)
	elif mode==319: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',319,'','','_REMEMBERRESULTS_')
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',yONJxHER9BIDPpTV4YsWmc0n,'','','','','SHIAVOICE-MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('id="menulinks"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = u5h2Rckvw1E.findall('<h5>(.*?)</h5>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.IGNORECASE)
	for bHMj0q6zaN in range(len(items)):
		title = items[bHMj0q6zaN].strip(' ')
		uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,yONJxHER9BIDPpTV4YsWmc0n,314,'','',str(bHMj0q6zaN+1))
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'مقاطع شهر',yONJxHER9BIDPpTV4YsWmc0n,314,'','','0')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = u5h2Rckvw1E.findall('href="(.*?)".*?<B>(.*?)</B>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/'+ekTrZlFMu0Kf5QztEnhAs
		uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,311)
	return oo9SgGkiDbs3HRn7z8
def VCio1EXzNgM8WLmYbxtBdw(bHMj0q6zaN):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',yONJxHER9BIDPpTV4YsWmc0n,'','','','','SHIAVOICE-LATEST-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	if bHMj0q6zaN=='0':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="tab-content"(.*?)</table>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,name,title in items:
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/'+ekTrZlFMu0Kf5QztEnhAs
			title = title.strip(' ')
			name = name.strip(' ')
			title = title+' ('+name+')'
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,312)
	elif bHMj0q6zaN in ['1','2','3']:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('(<h5>.*?)<div class="col-lg',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		iuUoThAdkGwFS = int(bHMj0q6zaN)-1
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[iuUoThAdkGwFS]
		if bHMj0q6zaN=='1': items = u5h2Rckvw1E.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		else: items = u5h2Rckvw1E.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title,name in items:
			pGjsvdyHfM = yONJxHER9BIDPpTV4YsWmc0n+'/'+pGjsvdyHfM
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/'+ekTrZlFMu0Kf5QztEnhAs
			title = title.strip(' ')
			name = name.strip(' ')
			title = title+' ('+name+')'
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,311,pGjsvdyHfM)
	elif bHMj0q6zaN in ['4','5','6']:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('(<h5>.*?)</table>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		bHMj0q6zaN = int(bHMj0q6zaN)-4
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[bHMj0q6zaN]
		items = u5h2Rckvw1E.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for pGjsvdyHfM,ekTrZlFMu0Kf5QztEnhAs,SkhRwop2bcUdC9,title,yGAtUBdJLngm in items:
			pGjsvdyHfM = yONJxHER9BIDPpTV4YsWmc0n+'/'+pGjsvdyHfM
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/'+ekTrZlFMu0Kf5QztEnhAs
			title = title.strip(' ')
			SkhRwop2bcUdC9 = SkhRwop2bcUdC9.strip(' ')
			yGAtUBdJLngm = yGAtUBdJLngm.strip(' ')
			if SkhRwop2bcUdC9: name = SkhRwop2bcUdC9
			else: name = yGAtUBdJLngm
			title = title+' ('+name+')'
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,312,pGjsvdyHfM)
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','SHIAVOICE-TITLES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('ibox-heading"(.*?)class="float-right',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	if 'catsum-mobile' in lmO2YJGr6tCV:
		items = u5h2Rckvw1E.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if items:
			for pGjsvdyHfM,ekTrZlFMu0Kf5QztEnhAs,title,count in items:
				pGjsvdyHfM = yONJxHER9BIDPpTV4YsWmc0n+'/'+pGjsvdyHfM
				ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/'+ekTrZlFMu0Kf5QztEnhAs
				count = count.replace(' الصوتية: ',':')
				title = title.strip(' ')
				title = title+' ('+count+')'
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,311,pGjsvdyHfM)
	else:
		items = u5h2Rckvw1E.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title,jfQm4G6VdIBoxpgyui,vNbeHULAy6gc4iE in items:
			if title=='' or jfQm4G6VdIBoxpgyui=='': continue
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/'+ekTrZlFMu0Kf5QztEnhAs
			title = title+' ('+vNbeHULAy6gc4iE+')'
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,312)
	if not items: GA2KIlbOsoYtxpkDF71(oo9SgGkiDbs3HRn7z8)
	return
def GA2KIlbOsoYtxpkDF71(oo9SgGkiDbs3HRn7z8):
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="ibox-content"(.*?)class="pagination',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,title,name,count,vNbeHULAy6gc4iE in items:
		ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/'+ekTrZlFMu0Kf5QztEnhAs
		title = title.strip(' ')
		name = name.strip(' ')
		title = title+' ('+name+')'
		uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,312,'',vNbeHULAy6gc4iE)
	return
def qBXKTp7h5vAUV1xjgb4i9Ws(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','SHIAVOICE-SEARCH_ITEMS-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="ibox-content p-1"(.*?)class="ibox-content"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not cWafzb4HoG1Em3Jwxu6C7vZsVi:
		ll0a2AwztChcpsDUMi4rGW3b61XZES(url)
		return
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('href="(.*?)".*?<strong>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/'+ekTrZlFMu0Kf5QztEnhAs
		title = title.strip(' ')
		if '/play-' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,312)
		else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,311)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',url,'','','','','SHIAVOICE-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('<audio.*?src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('<video.*?src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs[0]
	om1iZDWnrhGa2SLB9O4kfxYbqU(ekTrZlFMu0Kf5QztEnhAs,aUVSgO2ebjwX5iqPykC,'video')
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	search = search.replace(' ','+')
	V8ur0gbf35GxlXY = ['&t=a','&t=c','&t=s']
	if showDialogs:
		JJrvMLhNZTUcW2itg = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = tYysxJLreEBDdXMIjz4OPa('موقع صوت الشيعة - أختر البحث', JJrvMLhNZTUcW2itg)
		if u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo == -1: return
	elif '_SHIAVOICE-PERSONS_' in dza2VO9NvX: u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = 0
	elif '_SHIAVOICE-ALBUMS_' in dza2VO9NvX: u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = 1
	elif '_SHIAVOICE-AUDIOS_' in dza2VO9NvX: u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = 2
	else: return
	type = V8ur0gbf35GxlXY[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
	url = yONJxHER9BIDPpTV4YsWmc0n+'/search.php?q='+search+type
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','SHIAVOICE-SEARCH-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="ibox-content"(.*?)class="ibox-content"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		if u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo in [0,1]:
			items = u5h2Rckvw1E.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title,name in items:
				title = title.strip(' ')
				name = name.strip(' ')
				title = title+' ('+name+')'
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,313,pGjsvdyHfM)
		elif u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo==2:
			items = u5h2Rckvw1E.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,title,name in items:
				title = title.strip(' ')
				name = name.strip(' ')
				title = title+' ('+name+')'
				uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,312)
	return
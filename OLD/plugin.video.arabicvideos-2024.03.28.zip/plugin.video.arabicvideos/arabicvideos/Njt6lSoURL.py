# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'CIMALIGHT'
tiCRYyX1bWd40Ir3PafQu = '_CML_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['قنوات فضائية']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==470: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==471: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,text)
	elif mode==472: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==473: vS7JufTVsBxw52 = GA2KIlbOsoYtxpkDF71(url,text)
	elif mode==474: vS7JufTVsBxw52 = GQsDp6PWFHRE1ki2odqrwjB0ISTLh(url)
	elif mode==479: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',yONJxHER9BIDPpTV4YsWmc0n,'','','','','CIMALIGHT-MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	jGX4sfdrWaeZpA1VyvTK = u5h2Rckvw1E.findall('"url": "(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	jGX4sfdrWaeZpA1VyvTK = jGX4sfdrWaeZpA1VyvTK[0].strip('/')
	jGX4sfdrWaeZpA1VyvTK = hmcFWJUgiAuGk(jGX4sfdrWaeZpA1VyvTK,'url')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',479,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'أفلام مميزة',jGX4sfdrWaeZpA1VyvTK,471,'','','featured_movies')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"content"(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('href="(.*?)".*?</i>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		title = title.replace('  ','').strip(' ')
		ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.replace('cat=online-movies1','cat=online-movies')
		uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,474)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('/category.php">(.*?)"navslide-divider"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall("'dropdown-menu'(.*?)</ul>",oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		if title in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,474)
	return
def GQsDp6PWFHRE1ki2odqrwjB0ISTLh(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','CIMALIGHT-TITLES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	if 'topvideos.php' in url: cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"caret"(.*?)id="pm-grid"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	else: cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"caret"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if 'topvideos.php' in ekTrZlFMu0Kf5QztEnhAs:
				if 'topvideos.php?c=english-movies' in ekTrZlFMu0Kf5QztEnhAs: continue
				if 'topvideos.php?c=online-movies1' in ekTrZlFMu0Kf5QztEnhAs: continue
				if 'topvideos.php?c=misc' in ekTrZlFMu0Kf5QztEnhAs: continue
				if 'topvideos.php?c=tv-channel' in ekTrZlFMu0Kf5QztEnhAs: continue
				if 'منذ البداية' in title and 'do=rating' not in ekTrZlFMu0Kf5QztEnhAs: continue
			else: title = 'ترتيب باستخدام:  '+title
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,471)
	else: ll0a2AwztChcpsDUMi4rGW3b61XZES(url)
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,VemfsE32zgI=''):
	jGX4sfdrWaeZpA1VyvTK = hmcFWJUgiAuGk(url,'url')
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','CIMALIGHT-TITLES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	items = []
	if VemfsE32zgI=='featured_movies':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"container-fluid"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		lQUf3AY258LeWch,YMpoGJSqdLFkvb4WRuZNa65,IaCMxb1GnU6ijWscL = zip(*items)
		items = zip(IaCMxb1GnU6ijWscL,lQUf3AY258LeWch,YMpoGJSqdLFkvb4WRuZNa65)
	elif VemfsE32zgI=='featured_series':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('المسلسلات المميزة(.*?)<style>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		lQUf3AY258LeWch,YMpoGJSqdLFkvb4WRuZNa65,IaCMxb1GnU6ijWscL = zip(*items)
		items = zip(IaCMxb1GnU6ijWscL,lQUf3AY258LeWch,YMpoGJSqdLFkvb4WRuZNa65)
	else:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('(data-echo=".*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if not cWafzb4HoG1Em3Jwxu6C7vZsVi: cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"BlocksList"(.*?)"titleSectionCon"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if not cWafzb4HoG1Em3Jwxu6C7vZsVi: cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('id="pm-grid"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if not cWafzb4HoG1Em3Jwxu6C7vZsVi: cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('id="pm-related"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if not cWafzb4HoG1Em3Jwxu6C7vZsVi: return
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	if not items: items = u5h2Rckvw1E.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	if not items: items = u5h2Rckvw1E.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	yn8DkpE5etF3WiUmfSO = []
	dR94SHEmDA8nflN = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for pGjsvdyHfM,ekTrZlFMu0Kf5QztEnhAs,title in items:
		ekTrZlFMu0Kf5QztEnhAs = P2o6ZDHeW790pSQqucvnxzILVUX(ekTrZlFMu0Kf5QztEnhAs).strip('/')
		title = title.replace('ماي سيما','').replace('مشاهدة','').strip(' ').replace('  ',' ')
		if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = jGX4sfdrWaeZpA1VyvTK+'/'+ekTrZlFMu0Kf5QztEnhAs.strip('/')
		if 'http' not in pGjsvdyHfM: pGjsvdyHfM = jGX4sfdrWaeZpA1VyvTK+'/'+pGjsvdyHfM.strip('/')
		zAjwuoRY98mXN6xvE = u5h2Rckvw1E.findall('(.*?) الحلقة \d+',title,u5h2Rckvw1E.DOTALL)
		if any(c2eEflztvIX in title for c2eEflztvIX in dR94SHEmDA8nflN):
			title = '_MOD_'+title
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,472,pGjsvdyHfM)
		elif zAjwuoRY98mXN6xvE and 'الحلقة' in title:
			title = '_MOD_'+zAjwuoRY98mXN6xvE[0]
			if title not in yn8DkpE5etF3WiUmfSO:
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,473,pGjsvdyHfM)
				yn8DkpE5etF3WiUmfSO.append(title)
		elif '/movseries/' in ekTrZlFMu0Kf5QztEnhAs:
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,471,pGjsvdyHfM)
		else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,473,pGjsvdyHfM)
	if VemfsE32zgI not in ['featured_movies','featured_series']:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"pagination(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,title in items:
				if ekTrZlFMu0Kf5QztEnhAs=='#': continue
				ekTrZlFMu0Kf5QztEnhAs = jGX4sfdrWaeZpA1VyvTK+'/'+ekTrZlFMu0Kf5QztEnhAs.strip('/')
				title = uTUNPkVwCMKiD5gHLaj(title)
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+title,ekTrZlFMu0Kf5QztEnhAs,471)
		OUmHIFcEJsxtj = u5h2Rckvw1E.findall('showmore" href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if OUmHIFcEJsxtj:
			ekTrZlFMu0Kf5QztEnhAs = OUmHIFcEJsxtj[0]
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مشاهدة المزيد',ekTrZlFMu0Kf5QztEnhAs,471)
	return
def GA2KIlbOsoYtxpkDF71(url,rBOCITLay7XvDlcnjf5):
	jGX4sfdrWaeZpA1VyvTK = hmcFWJUgiAuGk(url,'url')
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','CIMALIGHT-EPISODES-2nd')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	kQ7LGm5DPnH8hUdtWY = u5h2Rckvw1E.findall('"SeasonsBox"(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	RfTOHSzgpA = u5h2Rckvw1E.findall('id="'+rBOCITLay7XvDlcnjf5+'"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	items = []
	if kQ7LGm5DPnH8hUdtWY and not rBOCITLay7XvDlcnjf5:
		pGjsvdyHfM = u5h2Rckvw1E.findall('"series-header".*?src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		pGjsvdyHfM = pGjsvdyHfM[0]
		lmO2YJGr6tCV = kQ7LGm5DPnH8hUdtWY[0]
		items = u5h2Rckvw1E.findall('openCity\(event\, \'(.*?)\'\)">(.*?)</button>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for rBOCITLay7XvDlcnjf5,title in items: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,473,pGjsvdyHfM,'',rBOCITLay7XvDlcnjf5)
	elif RfTOHSzgpA:
		pGjsvdyHfM = u5h2Rckvw1E.findall('"series-header".*?src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		pGjsvdyHfM = pGjsvdyHfM[0]
		lmO2YJGr6tCV = RfTOHSzgpA[0]
		items = u5h2Rckvw1E.findall("title='(.*?)' href='(.*?)'",lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if items:
			for title,ekTrZlFMu0Kf5QztEnhAs in items:
				ekTrZlFMu0Kf5QztEnhAs = jGX4sfdrWaeZpA1VyvTK+'/'+ekTrZlFMu0Kf5QztEnhAs.strip('/')
				uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,472,pGjsvdyHfM)
		else:
			items = u5h2Rckvw1E.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,title,pGjsvdyHfM in items:
				if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = jGX4sfdrWaeZpA1VyvTK+'/'+ekTrZlFMu0Kf5QztEnhAs.strip('/')
				uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,472,pGjsvdyHfM)
	if 'id="pm-related"' in oo9SgGkiDbs3HRn7z8:
		if items: uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مواضيع ذات صلة',url,471)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	EaBeVhOsHYg8wub = []
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','CIMALIGHT-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('<div itemprop="description">(.*?)href=',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		PmF0XjQN51GpKACfLgnyTv7 = u5h2Rckvw1E.findall('<p>(.*?)</p>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if PmF0XjQN51GpKACfLgnyTv7 and dQorkS3qBhIMDWKHl(aUVSgO2ebjwX5iqPykC,url,PmF0XjQN51GpKACfLgnyTv7,True): return
	gANn35esloKUydOipfSMC6RD2 = url.replace('/watch.php','/play.php')
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',gANn35esloKUydOipfSMC6RD2,'','','','','CIMALIGHT-PLAY-2nd')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	PSxOYTAl2h = []
	ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('"embedURL" href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if ekTrZlFMu0Kf5QztEnhAs:
		ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs[0]
		if ekTrZlFMu0Kf5QztEnhAs and ekTrZlFMu0Kf5QztEnhAs not in PSxOYTAl2h:
			PSxOYTAl2h.append(ekTrZlFMu0Kf5QztEnhAs)
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named=__embed'
			if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = 'http:'+ekTrZlFMu0Kf5QztEnhAs
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	items = u5h2Rckvw1E.findall("<iframe src='(.*?)'.*?<strong>(.*?)</strong>",oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		if ekTrZlFMu0Kf5QztEnhAs not in PSxOYTAl2h:
			PSxOYTAl2h.append(ekTrZlFMu0Kf5QztEnhAs)
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+title+'__watch'
			if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = 'http:'+ekTrZlFMu0Kf5QztEnhAs
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	gANn35esloKUydOipfSMC6RD2 = url.replace('/watch.php','/downloads.php')
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',gANn35esloKUydOipfSMC6RD2,'','','','','CIMALIGHT-PLAY-3rd')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"downloadlist"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?<strong>(.*?)</strong>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if ekTrZlFMu0Kf5QztEnhAs not in PSxOYTAl2h:
				PSxOYTAl2h.append(ekTrZlFMu0Kf5QztEnhAs)
				ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+title+'__download'
				if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = 'http:'+ekTrZlFMu0Kf5QztEnhAs
				EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(EaBeVhOsHYg8wub,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	search = search.replace(' ','+')
	url = yONJxHER9BIDPpTV4YsWmc0n+'/search.php?keywords='+search
	ll0a2AwztChcpsDUMi4rGW3b61XZES(url)
	return
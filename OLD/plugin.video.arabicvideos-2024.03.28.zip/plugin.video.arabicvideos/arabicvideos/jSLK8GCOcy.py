# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'RESOLVERS'
HtNqcixdmGa90rAXnRDkvWoLY = []
headers = {'User-Agent':''}
Nc782RLF3ZzeHrTpsi = ['AKWAM','SHOOFMAX','IFILM','KARBALATV','ALMAAREF','SHIAVOICE','IPTV','M3U']
def FkL7g4ob1HyAeIMcw5jQKmr(GnuaoT9MxiCg,source,type,url):
	if not GnuaoT9MxiCg:
		l0SAerv8zGH2Wa('ERROR_LINES',CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+'   Failed finding video files    Site: [ '+source+' ]    Type: [ '+type+' ]')
		VHac4319jsmAQp5FzltqSJb = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,'dict','MISC_PERM','SITES_ERRORS')
		QgUks6eVXEmu7iH = YVJPFvuI2CS5KObiZt.strftime('%Y.%m.%d %H:%M',YVJPFvuI2CS5KObiZt.gmtime(s8bXSagYdim62TwIpQzGtUqeLhA1J))
		mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ = QgUks6eVXEmu7iH,url
		key = source+'    '+qkSQU3saP0D7OvynNzH4F2BKJuilT+'    '+str(njGgmsD1k7cE60drxHCyVh2YN3P)
		MLPwxur5kaYlBtqcn = ''
		if key not in list(VHac4319jsmAQp5FzltqSJb.keys()): VHac4319jsmAQp5FzltqSJb[key] = [mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ]
		else:
			if url not in str(VHac4319jsmAQp5FzltqSJb[key]): VHac4319jsmAQp5FzltqSJb[key].append(mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ)
			else: MLPwxur5kaYlBtqcn = '\n هذا الفيديو موجود في قائمة الفيديوهات التي لم تعمل'
		nEpRemx1ylSXo0vg6QjVLsKtbOZTBW = 0
		for key in list(VHac4319jsmAQp5FzltqSJb.keys()):
			VHac4319jsmAQp5FzltqSJb[key] = list(set(VHac4319jsmAQp5FzltqSJb[key]))
			nEpRemx1ylSXo0vg6QjVLsKtbOZTBW += len(VHac4319jsmAQp5FzltqSJb[key])
		xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','للأسف البرنامج لم يجد ملفات الفيديو'+MLPwxur5kaYlBtqcn+'\n\n للعلم البرنامج يقوم بجمع قائمة بالفيديوهات التي لم يجد لها ملفات فيديو وسوف يعرض عليك البرنامج أن ترسل هذه القائمة إلى المبرمج عندما يصبح عددها 5 فيديوهات'+'\n\n'+'عدد الفيديوهات في القائمة الآن هو :  '+str(nEpRemx1ylSXo0vg6QjVLsKtbOZTBW))
		if nEpRemx1ylSXo0vg6QjVLsKtbOZTBW>=5:
			iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0('','','','رسالة من المبرمج','البرنامج جمع قائمة فيها 5 فيديوهات لم يجد البرنامج لها ملفات فيديو .. سوف يقوم البرنامج الآن بمسح هذه القائمة \n\n هل تريد إرسال هذه القائمة قبل مسحها إلى المبرمج لكي يقوم المبرمج بفحص هذه الفيديوهات ؟!!')
			if iZL6cN3OkM5==1:
				jWYvO6grcHt4fdT7VXEZu = ''
				for key in list(VHac4319jsmAQp5FzltqSJb.keys()):
					jWYvO6grcHt4fdT7VXEZu += '\n'+key
					aaFTupAGsYDkVKX = sorted(VHac4319jsmAQp5FzltqSJb[key],reverse=False,key=lambda ttXQih3Y2pcuy: ttXQih3Y2pcuy[0])
					for QgUks6eVXEmu7iH,url in aaFTupAGsYDkVKX:
						jWYvO6grcHt4fdT7VXEZu += '\n'+QgUks6eVXEmu7iH+'    '+P2o6ZDHeW790pSQqucvnxzILVUX(url)
					jWYvO6grcHt4fdT7VXEZu += '\n\n'
				import y5yjS2UFkc
				V5VXz0j3oa6t = y5yjS2UFkc.X2XWUFPVMDugaGkehc4EYlp('Videos','',False,'','RESOLVERS-PLAY_RESOLVERS','',jWYvO6grcHt4fdT7VXEZu)
				if V5VXz0j3oa6t: xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','تم الإرسال بنجاح')
				else: xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','فشلت عملية الإرسال')
			if iZL6cN3OkM5!=-1:
				VHac4319jsmAQp5FzltqSJb = {}
				ZqlR5BFQ6pm0asCHLUc(bpNSygerL10j4IOkEfuVw,'MISC_PERM','SITES_ERRORS')
		if VHac4319jsmAQp5FzltqSJb: OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,'MISC_PERM','SITES_ERRORS',VHac4319jsmAQp5FzltqSJb,NVbfv48oh3M6U)
		return
	GnuaoT9MxiCg = list(set(GnuaoT9MxiCg))
	hVby8e3aQkFfuE,EaBeVhOsHYg8wub = EEfeC7IAnRiTYu2hgD(GnuaoT9MxiCg,source)
	s8sqlYv2UwA = str(EaBeVhOsHYg8wub).count('__watch')
	MZ96JUp2k41 = str(EaBeVhOsHYg8wub).count('__download')
	Q3F5ZwRl7UmbSiyh1V8gPG = len(EaBeVhOsHYg8wub)-s8sqlYv2UwA-MZ96JUp2k41
	k4p1XaHwzr6PAIyGh8s5 = 'مشاهدة:'+str(s8sqlYv2UwA)+'    تحميل:'+str(MZ96JUp2k41)+'    أخرى:'+str(Q3F5ZwRl7UmbSiyh1V8gPG)
	if not EaBeVhOsHYg8wub: FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy,ruqEoR69TUCy = 'unresolved',''
	else:
		add = 0
		if not any(c2eEflztvIX in source for c2eEflztvIX in Nc782RLF3ZzeHrTpsi):
			add = 1
			EaBeVhOsHYg8wub = ['RESOLVE_ALL_LINKS']+list(EaBeVhOsHYg8wub)
			hVby8e3aQkFfuE = ['فحص جميع السيرفرات']+list(hVby8e3aQkFfuE)
		while True:
			ruqEoR69TUCy,FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy = '',''
			if add and len(EaBeVhOsHYg8wub)==2: u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = 1
			else: u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = tYysxJLreEBDdXMIjz4OPa(k4p1XaHwzr6PAIyGh8s5,hVby8e3aQkFfuE)
			if u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo==-1: FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy = 'canceled_1st_menu'
			elif add and u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo==0:
				FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy = 'canceled_2nd_menu'
				vS7JufTVsBxw52 = g6b7lFOeHGXmrnDYI3Uhvsk(hVby8e3aQkFfuE[add:],EaBeVhOsHYg8wub[add:],source)
				if vS7JufTVsBxw52:
					fb5IOAyS9HWU = []
					for qOECRifjx9rLg0MDk,UFaSM8n5uZVHNCJvBPOgA3j6,uXE81HKP7nkyjSJwiYsTLB,DEdqlSCRjtAGZMuc8Okx,FoS1RKs4P6BQ2IxH in vS7JufTVsBxw52:
						if FoS1RKs4P6BQ2IxH: fb5IOAyS9HWU.append((qOECRifjx9rLg0MDk,UFaSM8n5uZVHNCJvBPOgA3j6,uXE81HKP7nkyjSJwiYsTLB,DEdqlSCRjtAGZMuc8Okx,FoS1RKs4P6BQ2IxH))
					if fb5IOAyS9HWU: hVby8e3aQkFfuE,EaBeVhOsHYg8wub,errors,YMpoGJSqdLFkvb4WRuZNa65,lQUf3AY258LeWch = zip(*fb5IOAyS9HWU)
					else:
						xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','للأسف لم يتم إيجاد سيرفرات جيدة في هذا الفيديو .. حاول أن تبحث عن هذا الفيديو في مواقع أخرى')
						FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy = 'failed'
						break
					k4p1XaHwzr6PAIyGh8s5 = 'السيرفرات الجيدة ( '+str(len(EaBeVhOsHYg8wub))+' )'
					add = 0
					continue
			else:
				vS7JufTVsBxw52 = g6b7lFOeHGXmrnDYI3Uhvsk([hVby8e3aQkFfuE[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]],[EaBeVhOsHYg8wub[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]],source)
				if vS7JufTVsBxw52:
					title,ekTrZlFMu0Kf5QztEnhAs,errors,YMpoGJSqdLFkvb4WRuZNa65,lQUf3AY258LeWch = vS7JufTVsBxw52[0]
					if not lQUf3AY258LeWch and not any(c2eEflztvIX in source for c2eEflztvIX in Nc782RLF3ZzeHrTpsi):
						errors,YMpoGJSqdLFkvb4WRuZNa65,lQUf3AY258LeWch = UB7bYnaoMvwJ0pPEfu6ASXd(ekTrZlFMu0Kf5QztEnhAs,source)
					if 'سيرفر' in title and '2مجهول2' in title:
						l0SAerv8zGH2Wa('ERROR_LINES',CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+'   Unknown Selected Server   Server: [ '+title+' ]   Link: [ '+ekTrZlFMu0Kf5QztEnhAs+' ]')
						import y5yjS2UFkc
						y5yjS2UFkc.NLvbHFaBcK5SD()
						FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy = 'unresolved'
					else:
						l0SAerv8zGH2Wa('NOTICE',CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+'   Playing Selected Server   Server: [ '+title+' ]   Link: [ '+ekTrZlFMu0Kf5QztEnhAs+' ]')
						FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy,ruqEoR69TUCy,QJmOuSTlKhFXVnPo2M5x81qjsAfLbI = ddhsZOp3zk8rvXUaLBtQK6bRSP(title,ekTrZlFMu0Kf5QztEnhAs,errors,YMpoGJSqdLFkvb4WRuZNa65,lQUf3AY258LeWch,source,type)
			if FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy in ['EXIT_RESOLVER','download','playing','testing','canceled_1st_menu'] or len(EaBeVhOsHYg8wub)==1+add: break
			elif FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy in ['failed','timeout','tried']: break
			elif FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy not in ['canceled_2nd_menu','https']:
				if '\n' in ruqEoR69TUCy: ruqEoR69TUCy = '[LEFT]  '+ruqEoR69TUCy.replace('\n','\n[LEFT]  ')
				xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','السيرفر لم يعمل جرب سيرفر غيره'+'\n'+ruqEoR69TUCy,profile='confirm_mediumfont')
	if FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy=='unresolved' and len(hVby8e3aQkFfuE)>0: xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','سيرفر هذا الفيديو لم يعمل جرب فيديو غيره'+'\n'+ruqEoR69TUCy,profile='confirm_mediumfont')
	elif FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy in ['failed','timeout'] and ruqEoR69TUCy!='': xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج',ruqEoR69TUCy,profile='confirm_mediumfont')
	return FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy
def g6b7lFOeHGXmrnDYI3Uhvsk(kPpGr0QERz4tyh3C,GnuaoT9MxiCg,source):
	global VeOjzRF30n1xT
	VeOjzRF30n1xT,vS7JufTVsBxw52,bbwmVgz1jfSTxp,new = [],[],[],[]
	PPIXEhN6ofSZLVdJ2wRBHvKCMrx3u(False,False,False)
	count = len(GnuaoT9MxiCg)
	for Q0BmlkHz4Dn1pq9EPJeGwWMt in range(count):
		VeOjzRF30n1xT.append(None)
		title = kPpGr0QERz4tyh3C[Q0BmlkHz4Dn1pq9EPJeGwWMt]
		ekTrZlFMu0Kf5QztEnhAs = GnuaoT9MxiCg[Q0BmlkHz4Dn1pq9EPJeGwWMt].strip(' ').strip('&').strip('?').strip('/')
		if count>1: dnS80F92qtLi4vw1('فحص سيرفر رقم  '+str(Q0BmlkHz4Dn1pq9EPJeGwWMt+1),title)
		itQ79k3sM1E = ekTrZlFMu0Kf5QztEnhAs.split('?named=',1)[0]
		uVBEF3gYUHbdjRfKx = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,'list','RESOLVED',itQ79k3sM1E)
		if uVBEF3gYUHbdjRfKx and 'AKWAM' not in source:
			VeOjzRF30n1xT[Q0BmlkHz4Dn1pq9EPJeGwWMt] = uVBEF3gYUHbdjRfKx
		else:
			zYxJ5g9uar = onVDrgLUpFsqOPkxId9BwW6Rtc5A.Thread(target=UB7bYnaoMvwJ0pPEfu6ASXd,args=(ekTrZlFMu0Kf5QztEnhAs,source,Q0BmlkHz4Dn1pq9EPJeGwWMt))
			zYxJ5g9uar.start()
			YVJPFvuI2CS5KObiZt.sleep(0.5)
			bbwmVgz1jfSTxp.append(zYxJ5g9uar)
			new.append(Q0BmlkHz4Dn1pq9EPJeGwWMt)
	timeout = 60 if source=='AKWAM' else 20
	for zYxJ5g9uar in bbwmVgz1jfSTxp: zYxJ5g9uar.join(timeout)
	for Q0BmlkHz4Dn1pq9EPJeGwWMt in range(count):
		title = kPpGr0QERz4tyh3C[Q0BmlkHz4Dn1pq9EPJeGwWMt]
		ekTrZlFMu0Kf5QztEnhAs = GnuaoT9MxiCg[Q0BmlkHz4Dn1pq9EPJeGwWMt].strip(' ').strip('&').strip('?').strip('/')
		if VeOjzRF30n1xT[Q0BmlkHz4Dn1pq9EPJeGwWMt]: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = VeOjzRF30n1xT[Q0BmlkHz4Dn1pq9EPJeGwWMt]
		else: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = '\nFailed:  Timeout ('+str(timeout)+' seconds)',[],[]
		vS7JufTVsBxw52.append([title,ekTrZlFMu0Kf5QztEnhAs,ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub])
		if Q0BmlkHz4Dn1pq9EPJeGwWMt in new:
			itQ79k3sM1E = ekTrZlFMu0Kf5QztEnhAs.split('?named=',1)[0]
			OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,'RESOLVED',itQ79k3sM1E,[ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub],QQJtZ6rMvS1wdDsHnahT7)
	PPIXEhN6ofSZLVdJ2wRBHvKCMrx3u('','','')
	return vS7JufTVsBxw52
def UB7bYnaoMvwJ0pPEfu6ASXd(url,source,R2RD7JlOtrWXIFNgVnY0a5iwZp=0):
	global VeOjzRF30n1xT
	l0SAerv8zGH2Wa('NOTICE',CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+'   Resolving started   Original: [ '+url+' ]')
	ekTrZlFMu0Kf5QztEnhAs,Kjg0NWazhkZQcqdt3mb15uL7vsUl2 = url,''
	CgHyJphj8vEb1AYm4o = 'INTERNAL_RESOLVER'
	ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = tYyguHKcsvbmlVTkxzEFJU317DQ(url,source)
	if ruqEoR69TUCy=='EXIT_RESOLVER':
		Kjg0NWazhkZQcqdt3mb15uL7vsUl2 = '\nResolver 1:  Exit'
		VeOjzRF30n1xT[R2RD7JlOtrWXIFNgVnY0a5iwZp] = Kjg0NWazhkZQcqdt3mb15uL7vsUl2,hVby8e3aQkFfuE,EaBeVhOsHYg8wub
		return Kjg0NWazhkZQcqdt3mb15uL7vsUl2,hVby8e3aQkFfuE,EaBeVhOsHYg8wub
	elif 'NEED_EXTERNAL_RESOLVERS' in ruqEoR69TUCy:
		Kjg0NWazhkZQcqdt3mb15uL7vsUl2 = '\nResolver 1:  Need External Resolver'
		ekTrZlFMu0Kf5QztEnhAs = zzAU9YGyaT5XqPlw6FrWeiKd(EaBeVhOsHYg8wub)[0]
		VeOjzRF30n1xT[R2RD7JlOtrWXIFNgVnY0a5iwZp] = Kjg0NWazhkZQcqdt3mb15uL7vsUl2,hVby8e3aQkFfuE,EaBeVhOsHYg8wub
		CgHyJphj8vEb1AYm4o,Kjg0NWazhkZQcqdt3mb15uL7vsUl2,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = UKF9DzCbIk1TyAEg(Kjg0NWazhkZQcqdt3mb15uL7vsUl2,ekTrZlFMu0Kf5QztEnhAs,source,R2RD7JlOtrWXIFNgVnY0a5iwZp)
	elif ruqEoR69TUCy: Kjg0NWazhkZQcqdt3mb15uL7vsUl2 = 'Resolver 1:  '+ruqEoR69TUCy.replace('\n','').replace('\r','')[:80]
	if EaBeVhOsHYg8wub:
		EaBeVhOsHYg8wub = zzAU9YGyaT5XqPlw6FrWeiKd(EaBeVhOsHYg8wub)
		l0SAerv8zGH2Wa('NOTICE',CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+'   Resolving succeeded   Resolver: [ '+CgHyJphj8vEb1AYm4o+' ]   Original: [ '+url+' ]   Link: [ '+ekTrZlFMu0Kf5QztEnhAs+' ]   Results: [ '+str(EaBeVhOsHYg8wub)+' ]')
	else: l0SAerv8zGH2Wa('ERROR_LINES',CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+'   Resolving failed   Original: [ '+url+' ]   Link: [ '+ekTrZlFMu0Kf5QztEnhAs+' ]   Errors: [ '+Kjg0NWazhkZQcqdt3mb15uL7vsUl2+' ]')
	Kjg0NWazhkZQcqdt3mb15uL7vsUl2 = P2o6ZDHeW790pSQqucvnxzILVUX(Kjg0NWazhkZQcqdt3mb15uL7vsUl2)
	VeOjzRF30n1xT[R2RD7JlOtrWXIFNgVnY0a5iwZp] = Kjg0NWazhkZQcqdt3mb15uL7vsUl2,hVby8e3aQkFfuE,EaBeVhOsHYg8wub
	return Kjg0NWazhkZQcqdt3mb15uL7vsUl2,hVby8e3aQkFfuE,EaBeVhOsHYg8wub
def UKF9DzCbIk1TyAEg(Kjg0NWazhkZQcqdt3mb15uL7vsUl2,url,source,R2RD7JlOtrWXIFNgVnY0a5iwZp):
	global VeOjzRF30n1xT
	CgHyJphj8vEb1AYm4o = 'EXTERNAL_RESOLVER_2'
	ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = ggNFJuUBRHaGmXh8qts7AModKwfS6(url,source)
	EaBeVhOsHYg8wub = zzAU9YGyaT5XqPlw6FrWeiKd(EaBeVhOsHYg8wub)
	VeOjzRF30n1xT[R2RD7JlOtrWXIFNgVnY0a5iwZp] = Kjg0NWazhkZQcqdt3mb15uL7vsUl2,hVby8e3aQkFfuE,EaBeVhOsHYg8wub
	if ruqEoR69TUCy=='EXIT_RESOLVER': return ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub
	elif 'Failed:' in ruqEoR69TUCy:
		Kjg0NWazhkZQcqdt3mb15uL7vsUl2 += '\nResolver 2:  '+ruqEoR69TUCy.replace('\n','').replace('\r','')[:80]
		CgHyJphj8vEb1AYm4o = 'EXTERNAL_RESOLVER_3'
		ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = N2jn19odYcsqfFGBxPZpm40A7(url,source)
		EaBeVhOsHYg8wub = zzAU9YGyaT5XqPlw6FrWeiKd(EaBeVhOsHYg8wub)
		VeOjzRF30n1xT[R2RD7JlOtrWXIFNgVnY0a5iwZp] = Kjg0NWazhkZQcqdt3mb15uL7vsUl2,hVby8e3aQkFfuE,EaBeVhOsHYg8wub
		if ruqEoR69TUCy=='EXIT_RESOLVER': return ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub
		elif 'Failed:' in ruqEoR69TUCy:
			Kjg0NWazhkZQcqdt3mb15uL7vsUl2 += '\nResolver 3:  '+ruqEoR69TUCy.replace('\n','').replace('\r','')[:80]
			CgHyJphj8vEb1AYm4o = 'EXTERNAL_RESOLVER_4'
			ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = Zv3rM0FDaQyxb1kCB(url,source)
			EaBeVhOsHYg8wub = zzAU9YGyaT5XqPlw6FrWeiKd(EaBeVhOsHYg8wub)
			VeOjzRF30n1xT[R2RD7JlOtrWXIFNgVnY0a5iwZp] = Kjg0NWazhkZQcqdt3mb15uL7vsUl2,hVby8e3aQkFfuE,EaBeVhOsHYg8wub
			if ruqEoR69TUCy=='EXIT_RESOLVER': return ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub
			elif 'Failed:' in ruqEoR69TUCy:
				Kjg0NWazhkZQcqdt3mb15uL7vsUl2 += '\nResolver 4:  '+ruqEoR69TUCy.replace('\n','').replace('\r','')[:80]
				CgHyJphj8vEb1AYm4o = 'EXTERNAL_RESOLVER_5'
				ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = JvujFazHgnrV(url,source)
				EaBeVhOsHYg8wub = zzAU9YGyaT5XqPlw6FrWeiKd(EaBeVhOsHYg8wub)
				VeOjzRF30n1xT[R2RD7JlOtrWXIFNgVnY0a5iwZp] = Kjg0NWazhkZQcqdt3mb15uL7vsUl2,hVby8e3aQkFfuE,EaBeVhOsHYg8wub
				if ruqEoR69TUCy=='EXIT_RESOLVER': return ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub
				elif 'Failed:' in ruqEoR69TUCy:
					Kjg0NWazhkZQcqdt3mb15uL7vsUl2 += '\nResolver 5:  '+ruqEoR69TUCy.replace('\n','').replace('\r','')[:80]
	VeOjzRF30n1xT[R2RD7JlOtrWXIFNgVnY0a5iwZp] = Kjg0NWazhkZQcqdt3mb15uL7vsUl2,hVby8e3aQkFfuE,EaBeVhOsHYg8wub
	return CgHyJphj8vEb1AYm4o,Kjg0NWazhkZQcqdt3mb15uL7vsUl2,hVby8e3aQkFfuE,EaBeVhOsHYg8wub
def ddhsZOp3zk8rvXUaLBtQK6bRSP(title,ekTrZlFMu0Kf5QztEnhAs,ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub,source,type=''):
	if ruqEoR69TUCy=='EXIT_RESOLVER': return ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub
	elif EaBeVhOsHYg8wub:
		while True:
			if len(EaBeVhOsHYg8wub)==1: u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = 0
			else: u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = tYysxJLreEBDdXMIjz4OPa('اختر الملف المناسب:', hVby8e3aQkFfuE)
			if u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo==-1: FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy = 'tried'
			else:
				oSuGblrJOCtxIEip2vMQd9 = EaBeVhOsHYg8wub[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
				title = hVby8e3aQkFfuE[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
				l0SAerv8zGH2Wa('NOTICE',CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+'   Playing selected video   Selected: [ '+title+' ]   URL: [ '+str(oSuGblrJOCtxIEip2vMQd9)+' ]')
				if 'moshahda.' in oSuGblrJOCtxIEip2vMQd9 and 'download_orig' in oSuGblrJOCtxIEip2vMQd9:
					hhycXifbZ2P5n3HWlAB4Tv,NSf4FLmepCv6,QJmOuSTlKhFXVnPo2M5x81qjsAfLbI = LQAazgklTtUdwhic8X3u9(oSuGblrJOCtxIEip2vMQd9)
					if QJmOuSTlKhFXVnPo2M5x81qjsAfLbI: oSuGblrJOCtxIEip2vMQd9 = QJmOuSTlKhFXVnPo2M5x81qjsAfLbI[0]
					else: oSuGblrJOCtxIEip2vMQd9 = ''
				if not oSuGblrJOCtxIEip2vMQd9: FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy = 'unresolved'
				else: FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy = om1iZDWnrhGa2SLB9O4kfxYbqU(oSuGblrJOCtxIEip2vMQd9,source,type)
			if FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy in ['playing','testing','canceled_2nd_menu'] or len(EaBeVhOsHYg8wub)==1: break
			elif FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy in ['failed','timeout','tried']: break
			else: xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','الملف لم يعمل جرب ملف غيره')
	else:
		FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy = 'unresolved'
		if XS8G7Ljnkut(ekTrZlFMu0Kf5QztEnhAs): FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy = om1iZDWnrhGa2SLB9O4kfxYbqU(ekTrZlFMu0Kf5QztEnhAs,source,type)
	return FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy,ruqEoR69TUCy,EaBeVhOsHYg8wub
def hOCfg5bPX96xEdtr(url,source):
	gANn35esloKUydOipfSMC6RD2,aQy9D1EMV0w,NDwLctrHpYz3JBP,nxizr6jtEUpPl72y04adwC8,WGy8jZubInXc7zRBJ5p,type,GvoaR8HMyTDxF0fz5cwu1JnSNWP,ohAHUqdbWFi8D1L4Xwzus0f3RYv = url,'','','','','','',''
	if '?named=' in url:
		gANn35esloKUydOipfSMC6RD2,aQy9D1EMV0w = url.split('?named=',1)
		aQy9D1EMV0w = aQy9D1EMV0w+'__'+'__'+'__'+'__'
		aQy9D1EMV0w = aQy9D1EMV0w.lower()
		WGy8jZubInXc7zRBJ5p,type,GvoaR8HMyTDxF0fz5cwu1JnSNWP,ohAHUqdbWFi8D1L4Xwzus0f3RYv,GLlgdCvO48Y = aQy9D1EMV0w.split('__')[:5]
	if ohAHUqdbWFi8D1L4Xwzus0f3RYv=='': ohAHUqdbWFi8D1L4Xwzus0f3RYv = '0'
	else: ohAHUqdbWFi8D1L4Xwzus0f3RYv = ohAHUqdbWFi8D1L4Xwzus0f3RYv.replace('p','').replace(' ','')
	gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2.strip('?').strip('/').strip('&')
	NDwLctrHpYz3JBP = hmcFWJUgiAuGk(gANn35esloKUydOipfSMC6RD2,'host')
	if WGy8jZubInXc7zRBJ5p: nxizr6jtEUpPl72y04adwC8 = WGy8jZubInXc7zRBJ5p
	else: nxizr6jtEUpPl72y04adwC8 = NDwLctrHpYz3JBP
	nxizr6jtEUpPl72y04adwC8 = hmcFWJUgiAuGk(nxizr6jtEUpPl72y04adwC8,'name')
	WGy8jZubInXc7zRBJ5p = WGy8jZubInXc7zRBJ5p.replace('مباشر','').replace('سيرفر','').replace('ال ',' ').replace('  ',' ')
	aQy9D1EMV0w = aQy9D1EMV0w.replace('مباشر','').replace('سيرفر','').replace('ال ',' ').replace('  ',' ')
	nxizr6jtEUpPl72y04adwC8 = nxizr6jtEUpPl72y04adwC8.replace('مباشر','').replace('سيرفر','').replace('ال ',' ').replace('  ',' ')
	return gANn35esloKUydOipfSMC6RD2,aQy9D1EMV0w,NDwLctrHpYz3JBP,nxizr6jtEUpPl72y04adwC8,WGy8jZubInXc7zRBJ5p,type,GvoaR8HMyTDxF0fz5cwu1JnSNWP,ohAHUqdbWFi8D1L4Xwzus0f3RYv
def Aq4ByugiT2LUjYR(url,source):
	mOG9xu3sQLRbEeXhBMCzA1Sag,WGy8jZubInXc7zRBJ5p,ZZYWLruGiP8Vt3nzBs0UwSD,I5J0qSRjc6pWC9r3QbOhKtF2Ylv,d5jJRSryBV,vKXgBPWH9OfZ2SVpYhsr3imn5Jjl,CgHyJphj8vEb1AYm4o = '','',None,None,None,None,None
	gANn35esloKUydOipfSMC6RD2,aQy9D1EMV0w,NDwLctrHpYz3JBP,nxizr6jtEUpPl72y04adwC8,WGy8jZubInXc7zRBJ5p,type,GvoaR8HMyTDxF0fz5cwu1JnSNWP,ohAHUqdbWFi8D1L4Xwzus0f3RYv = hOCfg5bPX96xEdtr(url,source)
	if '?named=' in url:
		if   type=='embed': type = ' '+'مفضل'
		elif type=='watch': type = ' '+'%مشاهدة'
		elif type=='both': type = ' '+'%%مشاهدة وتحميل'
		elif type=='download': type = ' '+'%%%تحميل'
		elif type=='': type = ' '+'%%%%'
		if GvoaR8HMyTDxF0fz5cwu1JnSNWP!='':
			if 'mp4' not in GvoaR8HMyTDxF0fz5cwu1JnSNWP: GvoaR8HMyTDxF0fz5cwu1JnSNWP = '%'+GvoaR8HMyTDxF0fz5cwu1JnSNWP
			GvoaR8HMyTDxF0fz5cwu1JnSNWP = ' '+GvoaR8HMyTDxF0fz5cwu1JnSNWP
		if ohAHUqdbWFi8D1L4Xwzus0f3RYv!='':
			ohAHUqdbWFi8D1L4Xwzus0f3RYv = '%%%%%%%%%'+ohAHUqdbWFi8D1L4Xwzus0f3RYv
			ohAHUqdbWFi8D1L4Xwzus0f3RYv = ' '+ohAHUqdbWFi8D1L4Xwzus0f3RYv[-9:]
	if   'AKOAM'		in source: vKXgBPWH9OfZ2SVpYhsr3imn5Jjl	= nxizr6jtEUpPl72y04adwC8
	elif 'AKWAM'		in source: ZZYWLruGiP8Vt3nzBs0UwSD	= 'akwam'
	elif 'katkoute'		in NDwLctrHpYz3JBP: ZZYWLruGiP8Vt3nzBs0UwSD	= nxizr6jtEUpPl72y04adwC8
	elif 'photos.app.g'	in NDwLctrHpYz3JBP: ZZYWLruGiP8Vt3nzBs0UwSD	= nxizr6jtEUpPl72y04adwC8
	elif 'arabseed'		in source: ZZYWLruGiP8Vt3nzBs0UwSD	= nxizr6jtEUpPl72y04adwC8
	elif 'alarab'		in NDwLctrHpYz3JBP: ZZYWLruGiP8Vt3nzBs0UwSD	= nxizr6jtEUpPl72y04adwC8
	elif 'fasel'		in NDwLctrHpYz3JBP: ZZYWLruGiP8Vt3nzBs0UwSD	= nxizr6jtEUpPl72y04adwC8
	elif 't7meel'		in NDwLctrHpYz3JBP: ZZYWLruGiP8Vt3nzBs0UwSD	= nxizr6jtEUpPl72y04adwC8
	elif 'movs4u'		in WGy8jZubInXc7zRBJ5p:   ZZYWLruGiP8Vt3nzBs0UwSD	= nxizr6jtEUpPl72y04adwC8
	elif 'myegyvip'		in WGy8jZubInXc7zRBJ5p:   ZZYWLruGiP8Vt3nzBs0UwSD	= nxizr6jtEUpPl72y04adwC8
	elif 'fajer'		in WGy8jZubInXc7zRBJ5p:   ZZYWLruGiP8Vt3nzBs0UwSD	= nxizr6jtEUpPl72y04adwC8
	elif 'فجر'			in WGy8jZubInXc7zRBJ5p:   ZZYWLruGiP8Vt3nzBs0UwSD	= 'fajer'
	elif 'فلسطين'		in WGy8jZubInXc7zRBJ5p:   ZZYWLruGiP8Vt3nzBs0UwSD	= 'palestine'
	elif 'gdrive'		in gANn35esloKUydOipfSMC6RD2:   ZZYWLruGiP8Vt3nzBs0UwSD	= 'google'
	elif 'mycima'		in WGy8jZubInXc7zRBJ5p:   ZZYWLruGiP8Vt3nzBs0UwSD	= nxizr6jtEUpPl72y04adwC8
	elif 'wecima'		in WGy8jZubInXc7zRBJ5p:   ZZYWLruGiP8Vt3nzBs0UwSD	= nxizr6jtEUpPl72y04adwC8
	elif 'cimanow'		in WGy8jZubInXc7zRBJ5p:   ZZYWLruGiP8Vt3nzBs0UwSD	= nxizr6jtEUpPl72y04adwC8
	elif 'newcima'		in WGy8jZubInXc7zRBJ5p:   ZZYWLruGiP8Vt3nzBs0UwSD	= nxizr6jtEUpPl72y04adwC8
	elif 'dailymotion'	in NDwLctrHpYz3JBP: ZZYWLruGiP8Vt3nzBs0UwSD	= nxizr6jtEUpPl72y04adwC8
	elif 'bokra'		in NDwLctrHpYz3JBP: ZZYWLruGiP8Vt3nzBs0UwSD	= nxizr6jtEUpPl72y04adwC8
	elif 'tvfun'		in NDwLctrHpYz3JBP: ZZYWLruGiP8Vt3nzBs0UwSD	= nxizr6jtEUpPl72y04adwC8
	elif 'tvksa'		in NDwLctrHpYz3JBP: ZZYWLruGiP8Vt3nzBs0UwSD	= nxizr6jtEUpPl72y04adwC8
	elif 'anavidz'		in NDwLctrHpYz3JBP: ZZYWLruGiP8Vt3nzBs0UwSD	= nxizr6jtEUpPl72y04adwC8
	elif 'shoofpro'		in NDwLctrHpYz3JBP: ZZYWLruGiP8Vt3nzBs0UwSD	= nxizr6jtEUpPl72y04adwC8
	elif 'shahid4u'		in NDwLctrHpYz3JBP: vKXgBPWH9OfZ2SVpYhsr3imn5Jjl	= nxizr6jtEUpPl72y04adwC8
	elif 'shahed4u'		in NDwLctrHpYz3JBP: vKXgBPWH9OfZ2SVpYhsr3imn5Jjl	= nxizr6jtEUpPl72y04adwC8
	elif 'cima4u'		in NDwLctrHpYz3JBP: vKXgBPWH9OfZ2SVpYhsr3imn5Jjl	= nxizr6jtEUpPl72y04adwC8
	elif 'egynow'		in NDwLctrHpYz3JBP: vKXgBPWH9OfZ2SVpYhsr3imn5Jjl	= nxizr6jtEUpPl72y04adwC8
	elif 'halacima'		in NDwLctrHpYz3JBP: vKXgBPWH9OfZ2SVpYhsr3imn5Jjl	= nxizr6jtEUpPl72y04adwC8
	elif 'cimaabdo'		in NDwLctrHpYz3JBP: vKXgBPWH9OfZ2SVpYhsr3imn5Jjl	= nxizr6jtEUpPl72y04adwC8
	elif 'youtu'	 	in NDwLctrHpYz3JBP: ZZYWLruGiP8Vt3nzBs0UwSD	= 'youtube'
	elif 'y2u.be'	 	in NDwLctrHpYz3JBP: ZZYWLruGiP8Vt3nzBs0UwSD	= 'youtube'
	elif 'd.egybest.d'	in NDwLctrHpYz3JBP: ZZYWLruGiP8Vt3nzBs0UwSD	= 'egybestvip'
	elif 'egy.best'		in NDwLctrHpYz3JBP: ZZYWLruGiP8Vt3nzBs0UwSD	= 'egybest1'
	elif 'egybest'		in NDwLctrHpYz3JBP: ZZYWLruGiP8Vt3nzBs0UwSD	= 'egybest3'
	elif 'moshahda'		in NDwLctrHpYz3JBP: ZZYWLruGiP8Vt3nzBs0UwSD	= 'moshahda'
	elif 'facultybooks'	in NDwLctrHpYz3JBP: ZZYWLruGiP8Vt3nzBs0UwSD	= 'facultybooks'
	elif 'inflam.cc'	in NDwLctrHpYz3JBP: ZZYWLruGiP8Vt3nzBs0UwSD	= 'inflam'
	elif 'buzzvrl'		in NDwLctrHpYz3JBP: ZZYWLruGiP8Vt3nzBs0UwSD	= 'buzzvrl'
	elif 'arabloads'	in NDwLctrHpYz3JBP: I5J0qSRjc6pWC9r3QbOhKtF2Ylv	= 'arabloads'
	elif 'archive'		in NDwLctrHpYz3JBP: I5J0qSRjc6pWC9r3QbOhKtF2Ylv	= 'archive'
	elif 'catch.is'	 	in NDwLctrHpYz3JBP: I5J0qSRjc6pWC9r3QbOhKtF2Ylv	= 'catch'
	elif 'filerio'		in NDwLctrHpYz3JBP: I5J0qSRjc6pWC9r3QbOhKtF2Ylv	= 'filerio'
	elif 'vidbm'		in NDwLctrHpYz3JBP: I5J0qSRjc6pWC9r3QbOhKtF2Ylv	= 'vidbm'
	elif 'vidhd'		in NDwLctrHpYz3JBP: vKXgBPWH9OfZ2SVpYhsr3imn5Jjl	= nxizr6jtEUpPl72y04adwC8
	elif 'myvid'		in NDwLctrHpYz3JBP: vKXgBPWH9OfZ2SVpYhsr3imn5Jjl	= nxizr6jtEUpPl72y04adwC8
	elif 'myviid'		in NDwLctrHpYz3JBP: vKXgBPWH9OfZ2SVpYhsr3imn5Jjl	= nxizr6jtEUpPl72y04adwC8
	elif 'videobin'		in NDwLctrHpYz3JBP: I5J0qSRjc6pWC9r3QbOhKtF2Ylv	= 'videobin'
	elif 'govid'		in NDwLctrHpYz3JBP: I5J0qSRjc6pWC9r3QbOhKtF2Ylv	= 'govid'
	elif 'liivideo' 	in NDwLctrHpYz3JBP: I5J0qSRjc6pWC9r3QbOhKtF2Ylv	= 'liivideo'
	elif 'mp4upload'	in NDwLctrHpYz3JBP: I5J0qSRjc6pWC9r3QbOhKtF2Ylv	= 'mp4upload'
	elif 'publicvideo'	in NDwLctrHpYz3JBP: I5J0qSRjc6pWC9r3QbOhKtF2Ylv	= 'publicvideo'
	elif 'rapidvideo' 	in NDwLctrHpYz3JBP: I5J0qSRjc6pWC9r3QbOhKtF2Ylv	= 'rapidvideo'
	elif 'top4top'		in NDwLctrHpYz3JBP: I5J0qSRjc6pWC9r3QbOhKtF2Ylv	= 'top4top'
	elif 'upp' 			in NDwLctrHpYz3JBP: I5J0qSRjc6pWC9r3QbOhKtF2Ylv	= 'upbom'
	elif 'upb' 			in NDwLctrHpYz3JBP: I5J0qSRjc6pWC9r3QbOhKtF2Ylv	= 'upbom'
	elif 'uqload' 		in NDwLctrHpYz3JBP: I5J0qSRjc6pWC9r3QbOhKtF2Ylv	= 'uqload'
	elif 'vcstream' 	in NDwLctrHpYz3JBP: I5J0qSRjc6pWC9r3QbOhKtF2Ylv	= 'vcstream'
	elif 'vidbob'		in NDwLctrHpYz3JBP: I5J0qSRjc6pWC9r3QbOhKtF2Ylv	= 'vidbob'
	elif 'vidoza' 		in NDwLctrHpYz3JBP: I5J0qSRjc6pWC9r3QbOhKtF2Ylv	= 'vidoza'
	elif 'watchvideo' 	in NDwLctrHpYz3JBP: I5J0qSRjc6pWC9r3QbOhKtF2Ylv	= 'watchvideo'
	elif 'wintv.live'	in NDwLctrHpYz3JBP: I5J0qSRjc6pWC9r3QbOhKtF2Ylv	= 'wintv.live'
	elif 'zippyshare'	in NDwLctrHpYz3JBP: I5J0qSRjc6pWC9r3QbOhKtF2Ylv	= 'zippyshare'
	elif 'hd-cdn'		in NDwLctrHpYz3JBP: I5J0qSRjc6pWC9r3QbOhKtF2Ylv	= 'hd-cdn'
	if   ZZYWLruGiP8Vt3nzBs0UwSD:	mOG9xu3sQLRbEeXhBMCzA1Sag,WGy8jZubInXc7zRBJ5p = 'خاص',ZZYWLruGiP8Vt3nzBs0UwSD
	elif vKXgBPWH9OfZ2SVpYhsr3imn5Jjl:		mOG9xu3sQLRbEeXhBMCzA1Sag,WGy8jZubInXc7zRBJ5p = '%محدد',vKXgBPWH9OfZ2SVpYhsr3imn5Jjl
	elif I5J0qSRjc6pWC9r3QbOhKtF2Ylv:		mOG9xu3sQLRbEeXhBMCzA1Sag,WGy8jZubInXc7zRBJ5p = '%%عام معروف',I5J0qSRjc6pWC9r3QbOhKtF2Ylv
	elif d5jJRSryBV:	mOG9xu3sQLRbEeXhBMCzA1Sag,WGy8jZubInXc7zRBJ5p = '%%%عام خارجي',d5jJRSryBV
	elif CgHyJphj8vEb1AYm4o:	mOG9xu3sQLRbEeXhBMCzA1Sag,WGy8jZubInXc7zRBJ5p = '%%%%عام خارجي',nxizr6jtEUpPl72y04adwC8
	else:			mOG9xu3sQLRbEeXhBMCzA1Sag,WGy8jZubInXc7zRBJ5p = '%%%%%عام مجهول',nxizr6jtEUpPl72y04adwC8
	return mOG9xu3sQLRbEeXhBMCzA1Sag,WGy8jZubInXc7zRBJ5p,type,GvoaR8HMyTDxF0fz5cwu1JnSNWP,ohAHUqdbWFi8D1L4Xwzus0f3RYv
def tYyguHKcsvbmlVTkxzEFJU317DQ(url,source):
	gANn35esloKUydOipfSMC6RD2,vKXgBPWH9OfZ2SVpYhsr3imn5Jjl,NDwLctrHpYz3JBP,nxizr6jtEUpPl72y04adwC8,WGy8jZubInXc7zRBJ5p,type,GvoaR8HMyTDxF0fz5cwu1JnSNWP,ohAHUqdbWFi8D1L4Xwzus0f3RYv = hOCfg5bPX96xEdtr(url,source)
	if   'AKOAM'		in source: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = EnzcoUOKkg(gANn35esloKUydOipfSMC6RD2,WGy8jZubInXc7zRBJ5p)
	elif 'AKWAM'		in source: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = Jn5W8Lt2m3(gANn35esloKUydOipfSMC6RD2,type,ohAHUqdbWFi8D1L4Xwzus0f3RYv)
	elif 'FASELHD1'		in source: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = XXW03oFr2P(gANn35esloKUydOipfSMC6RD2)
	elif 'CIMA4U'		in source: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = nklwYcfzev(gANn35esloKUydOipfSMC6RD2)
	elif 'CIMACLUB'		in source: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = ZZDpU58LVm(gANn35esloKUydOipfSMC6RD2)
	elif 'ARABSEED'		in source: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = MmeOUju29E(gANn35esloKUydOipfSMC6RD2)
	elif 'CIMAABDO'		in source: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = e0WXjywiOS(gANn35esloKUydOipfSMC6RD2)
	elif 'SHOFHA'		in source: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = hjCIaSDtTE(gANn35esloKUydOipfSMC6RD2)
	elif 'katkoute'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = MWGsQ2BUeR(gANn35esloKUydOipfSMC6RD2)
	elif 'akoam.cam'	in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = kmsGWLvufP(gANn35esloKUydOipfSMC6RD2)
	elif 'alarab'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = QQDiaFuTYwb2Wy(gANn35esloKUydOipfSMC6RD2)
	elif 'shahid4u'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = tFWb48mphv(gANn35esloKUydOipfSMC6RD2)
	elif 'shahed4u'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = tFWb48mphv(gANn35esloKUydOipfSMC6RD2)
	elif 'egynow'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = LLf3XgyDNA(gANn35esloKUydOipfSMC6RD2)
	elif 'tvfun'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = pQabjHLJut(gANn35esloKUydOipfSMC6RD2)
	elif 'tvksa'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = pQabjHLJut(gANn35esloKUydOipfSMC6RD2)
	elif 'tv-f.com'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = pQabjHLJut(gANn35esloKUydOipfSMC6RD2)
	elif 'halacima'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = YHsR9TjoQK(gANn35esloKUydOipfSMC6RD2)
	elif 'shoofpro'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = NLFpfGkys5(gANn35esloKUydOipfSMC6RD2)
	elif 'myegyvip'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = caYyemB7EVN98wFJdvKIL0tGkD(gANn35esloKUydOipfSMC6RD2)
	elif 'vs4u'			in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = VCdK5LpWwE(gANn35esloKUydOipfSMC6RD2)
	elif 'fajer'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = yVGIEJxcRO(gANn35esloKUydOipfSMC6RD2)
	elif 'cimanow'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = QW5xFpg0rX(gANn35esloKUydOipfSMC6RD2)
	elif 'newcima'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = QW5xFpg0rX(gANn35esloKUydOipfSMC6RD2)
	elif 'cima-light'	in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = Njt6lSoURL(gANn35esloKUydOipfSMC6RD2)
	elif 'cimalight'	in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = Njt6lSoURL(gANn35esloKUydOipfSMC6RD2)
	elif 'mycima'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = W9RI8wqtK2(gANn35esloKUydOipfSMC6RD2)
	elif 'wecima'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = yyFkTgEfoX(gANn35esloKUydOipfSMC6RD2)
	elif 'bokra'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = Doxsw2Anyd(gANn35esloKUydOipfSMC6RD2)
	elif 'dailymotion'	in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = Idq3R2HptB(gANn35esloKUydOipfSMC6RD2)
	elif 'arblionz'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = uCxKbgU9pj(gANn35esloKUydOipfSMC6RD2)
	elif 'd.egybest.d'	in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = '',[''],[gANn35esloKUydOipfSMC6RD2]
	elif 'egy.best'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = LLZ6q2UV4K(url)
	elif 'egybest'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = XMumB6sYhk(gANn35esloKUydOipfSMC6RD2)
	elif 'series4watch'	in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = hyDITNRzH6(gANn35esloKUydOipfSMC6RD2)
	elif 'upbam' 		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = '',[''],[gANn35esloKUydOipfSMC6RD2]
	else: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = 'NEED_EXTERNAL_RESOLVERS',[''],[gANn35esloKUydOipfSMC6RD2]
	return 'Failed:  '+ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub
def ggNFJuUBRHaGmXh8qts7AModKwfS6(url,source):
	NDwLctrHpYz3JBP = hmcFWJUgiAuGk(url,'name')
	EaBeVhOsHYg8wub = []
	if   'youtu'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = bFeRWshMkt(url)
	elif 'y2u.be'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = bFeRWshMkt(url)
	elif 'googleuserco' in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = PDkGzRoUNAhKl(url)
	elif 'photos.app.g'	in url   : ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = vvAIaKGqTspNO92UDP1fjo7LQWJBCY(url)
	elif 'dailymotion'	in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = Idq3R2HptB(url)
	elif 'moshahda'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = LQAazgklTtUdwhic8X3u9(url)
	elif 'faselhd'		in url   : ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = XXW03oFr2P(url)
	elif 'arabloads'	in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = N4NMYLOxeP(url)
	elif 'archive'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = xJLyoRK9dtClbmqzhgYk1Gviu(url)
	elif 'buzzvrl'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = G9A2QgW4j5eKwD3Joicnpu(url)
	elif 'e5tsar'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = IiPRq3Tp87QthG1HWZY(url)
	elif 'facultybooks'	in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = jbzpI0Ku2UQOFNJ1cAl5mL6(url)
	elif 'inflam.cc'	in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = jbzpI0Ku2UQOFNJ1cAl5mL6(url)
	elif 'upbam' 		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = '',[''],[url]
	elif 'liivideo' 	in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = rwT3HU7odyYm5F9Vi82CWA(url)
	elif 'mp4upload'	in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = wnUxLPbMDs4N5qFg(url)
	elif 'rapidvideo' 	in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = nnBd54cZaIeCb1Krl(url)
	elif 'top4top'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = bshEiAGUuDr6jY3FNWBzx(url)
	elif 'upb' 			in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = cvdiB9kzt3xW0NJ6joa1LS(url)
	elif 'upp' 			in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = cvdiB9kzt3xW0NJ6joa1LS(url)
	elif 'uqload' 		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = SCg9BVyhGKv0olU7T(url)
	elif 'vcstream' 	in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = hqekIf7CB4twRPM6bEcYylQH9D8Z(url)
	elif 'vidbob'		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = NyeiXSpjYK78bRw01GUvxr9a4H(url)
	elif 'vidoza' 		in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = uaGq6Qcv3RAyTrm4dHLejfl9on(url)
	elif 'watchvideo' 	in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = tIZpFGWquaD3gXVCz1869edKUJM(url)
	elif 'wintv.live'	in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = aCEZSMAszPItmkyUhOGfgFv1B0iw7(url)
	elif 'zippyshare'	in NDwLctrHpYz3JBP: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = RxijYfWZwMNnvV1(url)
	if EaBeVhOsHYg8wub: return 'Failed: '+ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub
	return 'Failed:  ',[],[]
def PPLuToI8S4RBn0Cbl9W(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',url,'','','',False,'RESOLVERS-URL_REDIRECT-1st')
	headers = RoQL91PphqCJg4W0e6Fnsl.headers
	if 'Location' in list(headers.keys()):
		ekTrZlFMu0Kf5QztEnhAs = RoQL91PphqCJg4W0e6Fnsl.headers['Location']
		if XS8G7Ljnkut(ekTrZlFMu0Kf5QztEnhAs): return '',[''],[ekTrZlFMu0Kf5QztEnhAs]
	return 'Failed:  ',[],[]
def N2jn19odYcsqfFGBxPZpm40A7(url,source):
	ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = '',[],[]
	if XS8G7Ljnkut(url): ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = '',[''],[url]
	if not EaBeVhOsHYg8wub: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = PPLuToI8S4RBn0Cbl9W(url)
	if not EaBeVhOsHYg8wub: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = LbXeDMhs3i(url)
	if not EaBeVhOsHYg8wub:
		if ruqEoR69TUCy=='EXIT_RESOLVER': ruqEoR69TUCy = ''
		return 'Failed:  '+ruqEoR69TUCy,[],[]
	return ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub
def zzAU9YGyaT5XqPlw6FrWeiKd(LonTW5tCBx1Hrg7vRkl0Yp32Dyu):
	if 'list' in str(type(LonTW5tCBx1Hrg7vRkl0Yp32Dyu)):
		lQUf3AY258LeWch = []
		for ekTrZlFMu0Kf5QztEnhAs in LonTW5tCBx1Hrg7vRkl0Yp32Dyu:
			if 'str' in str(type(ekTrZlFMu0Kf5QztEnhAs)):
				ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.replace('\r','').replace('\n','').strip(' ')
			lQUf3AY258LeWch.append(ekTrZlFMu0Kf5QztEnhAs)
	else: lQUf3AY258LeWch = LonTW5tCBx1Hrg7vRkl0Yp32Dyu.replace('\r','').replace('\n','').strip(' ')
	return lQUf3AY258LeWch
def EEfeC7IAnRiTYu2hgD(QJmOuSTlKhFXVnPo2M5x81qjsAfLbI,source):
	SrH1lwftenFsM5CQDbOIqG7jpg3 = ebm0Z72CDaBzUq
	data = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,'list','SERVERS',QJmOuSTlKhFXVnPo2M5x81qjsAfLbI)
	if data:
		hVby8e3aQkFfuE,EaBeVhOsHYg8wub = list(zip(*data))
		return hVby8e3aQkFfuE,EaBeVhOsHYg8wub
	hVby8e3aQkFfuE,EaBeVhOsHYg8wub,PPc2xW5psAey4 = [],[],[]
	for ekTrZlFMu0Kf5QztEnhAs in QJmOuSTlKhFXVnPo2M5x81qjsAfLbI:
		if '//' not in ekTrZlFMu0Kf5QztEnhAs: continue
		mOG9xu3sQLRbEeXhBMCzA1Sag,WGy8jZubInXc7zRBJ5p,type,GvoaR8HMyTDxF0fz5cwu1JnSNWP,ohAHUqdbWFi8D1L4Xwzus0f3RYv = Aq4ByugiT2LUjYR(ekTrZlFMu0Kf5QztEnhAs,source)
		ohAHUqdbWFi8D1L4Xwzus0f3RYv = u5h2Rckvw1E.findall('\d+',ohAHUqdbWFi8D1L4Xwzus0f3RYv,u5h2Rckvw1E.DOTALL)
		if ohAHUqdbWFi8D1L4Xwzus0f3RYv: ohAHUqdbWFi8D1L4Xwzus0f3RYv = int(ohAHUqdbWFi8D1L4Xwzus0f3RYv[0])
		else: ohAHUqdbWFi8D1L4Xwzus0f3RYv = 0
		NDwLctrHpYz3JBP = hmcFWJUgiAuGk(ekTrZlFMu0Kf5QztEnhAs,'name')
		PPc2xW5psAey4.append([mOG9xu3sQLRbEeXhBMCzA1Sag,WGy8jZubInXc7zRBJ5p,type,GvoaR8HMyTDxF0fz5cwu1JnSNWP,ohAHUqdbWFi8D1L4Xwzus0f3RYv,ekTrZlFMu0Kf5QztEnhAs,NDwLctrHpYz3JBP])
	if PPc2xW5psAey4:
		vWkjN9h2O7pH58mXunlVAMRJ0fgr = sorted(PPc2xW5psAey4,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		Ak4xpSK8TM90zlst = []
		for mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ in vWkjN9h2O7pH58mXunlVAMRJ0fgr:
			if mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ not in Ak4xpSK8TM90zlst:
				Ak4xpSK8TM90zlst.append(mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ)
		for mOG9xu3sQLRbEeXhBMCzA1Sag,WGy8jZubInXc7zRBJ5p,type,GvoaR8HMyTDxF0fz5cwu1JnSNWP,ohAHUqdbWFi8D1L4Xwzus0f3RYv,ekTrZlFMu0Kf5QztEnhAs,NDwLctrHpYz3JBP in Ak4xpSK8TM90zlst:
			if ohAHUqdbWFi8D1L4Xwzus0f3RYv: ohAHUqdbWFi8D1L4Xwzus0f3RYv = str(ohAHUqdbWFi8D1L4Xwzus0f3RYv)
			else: ohAHUqdbWFi8D1L4Xwzus0f3RYv = ''
			title = 'سيرفر'+' '+type+' '+mOG9xu3sQLRbEeXhBMCzA1Sag+' '+ohAHUqdbWFi8D1L4Xwzus0f3RYv+' '+GvoaR8HMyTDxF0fz5cwu1JnSNWP+' '+WGy8jZubInXc7zRBJ5p
			if NDwLctrHpYz3JBP not in title: title = title+' '+NDwLctrHpYz3JBP
			title = title.replace('%','').strip(' ').replace('  ',' ').replace('  ',' ').replace('  ',' ')
			if ekTrZlFMu0Kf5QztEnhAs not in EaBeVhOsHYg8wub:
				hVby8e3aQkFfuE.append(title)
				EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
		if EaBeVhOsHYg8wub:
			data = list(zip(hVby8e3aQkFfuE,EaBeVhOsHYg8wub))
			if data: OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,'SERVERS',QJmOuSTlKhFXVnPo2M5x81qjsAfLbI,data,SrH1lwftenFsM5CQDbOIqG7jpg3)
	return hVby8e3aQkFfuE,EaBeVhOsHYg8wub
def Zv3rM0FDaQyxb1kCB(url,source):
	LdvB61qxSDsOWlhmXnAgozEfPp4Ky = ''
	vS7JufTVsBxw52 = False
	try:
		import resolveurl as Sp307riIGjs
		vS7JufTVsBxw52 = Sp307riIGjs.resolve(url)
	except Exception as qZlW4saokbmPnLv7pzcGFQ5H: LdvB61qxSDsOWlhmXnAgozEfPp4Ky = str(qZlW4saokbmPnLv7pzcGFQ5H)
	if not vS7JufTVsBxw52:
		if LdvB61qxSDsOWlhmXnAgozEfPp4Ky=='':
			LdvB61qxSDsOWlhmXnAgozEfPp4Ky = BPSEU6WvQRnxV.format_exc()
			if LdvB61qxSDsOWlhmXnAgozEfPp4Ky!='NoneType: None\n': vdo2FnhPmAVRMJQZ0EIG8.stderr.write(LdvB61qxSDsOWlhmXnAgozEfPp4Ky)
		ruqEoR69TUCy = LdvB61qxSDsOWlhmXnAgozEfPp4Ky.splitlines()[-1]
		return 'Failed:  '+ruqEoR69TUCy,[],[]
	return '',[''],[vS7JufTVsBxw52]
def JvujFazHgnrV(url,source):
	LdvB61qxSDsOWlhmXnAgozEfPp4Ky = ''
	vS7JufTVsBxw52 = False
	try:
		import youtube_dl as JKUsOB3G0mZWznut8
		za5ukjW3mdi7 = JKUsOB3G0mZWznut8.YoutubeDL({'no_color': True})
		vS7JufTVsBxw52 = za5ukjW3mdi7.extract_info(url,download=False)
	except Exception as qZlW4saokbmPnLv7pzcGFQ5H: LdvB61qxSDsOWlhmXnAgozEfPp4Ky = str(qZlW4saokbmPnLv7pzcGFQ5H)
	if not vS7JufTVsBxw52 or 'formats' not in list(vS7JufTVsBxw52.keys()):
		if LdvB61qxSDsOWlhmXnAgozEfPp4Ky=='':
			LdvB61qxSDsOWlhmXnAgozEfPp4Ky = BPSEU6WvQRnxV.format_exc()
			if LdvB61qxSDsOWlhmXnAgozEfPp4Ky!='NoneType: None\n': vdo2FnhPmAVRMJQZ0EIG8.stderr.write(LdvB61qxSDsOWlhmXnAgozEfPp4Ky)
		ruqEoR69TUCy = LdvB61qxSDsOWlhmXnAgozEfPp4Ky.splitlines()[-1]
		return 'Failed:  '+ruqEoR69TUCy,[],[]
	else:
		hVby8e3aQkFfuE,EaBeVhOsHYg8wub = [],[]
		for ekTrZlFMu0Kf5QztEnhAs in vS7JufTVsBxw52['formats']:
			hVby8e3aQkFfuE.append(ekTrZlFMu0Kf5QztEnhAs['format'])
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs['url'])
		return '',hVby8e3aQkFfuE,EaBeVhOsHYg8wub
def QQDiaFuTYwb2Wy(url):
	if '.m3u8' in url:
		hVby8e3aQkFfuE,EaBeVhOsHYg8wub = bkz2aCFLpWqGUcPolSXA980O(url)
		if EaBeVhOsHYg8wub: return '',hVby8e3aQkFfuE,EaBeVhOsHYg8wub
		return 'Error: Resolver Failed M3U8',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def MWGsQ2BUeR(url):
	GnuaoT9MxiCg,kPpGr0QERz4tyh3C = [],[]
	if '/videos.mp4?vid=' in url:
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','',False,'','RESOLVERS-KATKOUTE-1st')
		if 'Location' in RoQL91PphqCJg4W0e6Fnsl.headers:
			ekTrZlFMu0Kf5QztEnhAs = RoQL91PphqCJg4W0e6Fnsl.headers['Location']
			GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs)
			NDwLctrHpYz3JBP = hmcFWJUgiAuGk(ekTrZlFMu0Kf5QztEnhAs,'name')
			kPpGr0QERz4tyh3C.append(NDwLctrHpYz3JBP)
	elif 'katkoute.com' in url:
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','RESOLVERS-KATKOUTE-2nd')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		BZ3r6t4XFPSRq = u5h2Rckvw1E.findall('(eval\(function\(p,a,c,k,e,d\).*?\)\)).</script>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if BZ3r6t4XFPSRq:
			BZ3r6t4XFPSRq = BZ3r6t4XFPSRq[0]
			hhUwzgWifrTC9mBl0V = qd36ueWAYg(BZ3r6t4XFPSRq)
			ZRt1hdJLAcr = u5h2Rckvw1E.findall('sources:(\[.*?\]),',hhUwzgWifrTC9mBl0V,u5h2Rckvw1E.DOTALL)
			if ZRt1hdJLAcr:
				ZRt1hdJLAcr = ZRt1hdJLAcr[0]
				ZRt1hdJLAcr = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('list',ZRt1hdJLAcr)
				for dict in ZRt1hdJLAcr:
					ekTrZlFMu0Kf5QztEnhAs = dict['file']
					ohAHUqdbWFi8D1L4Xwzus0f3RYv = dict['label']
					GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs)
					NDwLctrHpYz3JBP = hmcFWJUgiAuGk(ekTrZlFMu0Kf5QztEnhAs,'name')
					kPpGr0QERz4tyh3C.append(ohAHUqdbWFi8D1L4Xwzus0f3RYv+' '+NDwLctrHpYz3JBP)
		elif 'Location' in RoQL91PphqCJg4W0e6Fnsl.headers:
			ekTrZlFMu0Kf5QztEnhAs = RoQL91PphqCJg4W0e6Fnsl.headers['Location']
			GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs)
			NDwLctrHpYz3JBP = hmcFWJUgiAuGk(ekTrZlFMu0Kf5QztEnhAs,'name')
			kPpGr0QERz4tyh3C.append(NDwLctrHpYz3JBP)
		if '?url=https://photos.app.goo' in url:
			ekTrZlFMu0Kf5QztEnhAs = url.split('?url=')[1]
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.split('&')[0]
			if ekTrZlFMu0Kf5QztEnhAs:
				GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs)
				kPpGr0QERz4tyh3C.append('photos google')
	else:
		GnuaoT9MxiCg.append(url)
		NDwLctrHpYz3JBP = hmcFWJUgiAuGk(url,'name')
		kPpGr0QERz4tyh3C.append(NDwLctrHpYz3JBP)
	if not GnuaoT9MxiCg: return 'Error: Resolver Failed KATKOUTE',[],[]
	elif len(GnuaoT9MxiCg)==1: ekTrZlFMu0Kf5QztEnhAs = GnuaoT9MxiCg[0]
	else:
		u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = tYysxJLreEBDdXMIjz4OPa('أختر الملف المناسب',kPpGr0QERz4tyh3C)
		if u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo==-1: return 'EXIT_RESOLVER',[],[]
		ekTrZlFMu0Kf5QztEnhAs = GnuaoT9MxiCg[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ekTrZlFMu0Kf5QztEnhAs]
def PDkGzRoUNAhKl(url):
	headers = {'User-Agent':'Kodi/'+str(njGgmsD1k7cE60drxHCyVh2YN3P)}
	for k0G4LTYt93po in range(50):
		YVJPFvuI2CS5KObiZt.sleep(0.100)
		RoQL91PphqCJg4W0e6Fnsl = uuv2D4mrsyY('GET',url,'',headers,False,'','RESOLVERS-GOOGLEUSERCONTENT-1st')
		if 'Location' in list(RoQL91PphqCJg4W0e6Fnsl.headers.keys()):
			ekTrZlFMu0Kf5QztEnhAs = RoQL91PphqCJg4W0e6Fnsl.headers['Location']
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'|User-Agent='+headers['User-Agent']
			return '',[''],[ekTrZlFMu0Kf5QztEnhAs]
		if RoQL91PphqCJg4W0e6Fnsl.code!=429: break
	return 'Error: Resolver Failed GOOGLEUSERCONTENT',[],[]
def vvAIaKGqTspNO92UDP1fjo7LQWJBCY(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','RESOLVERS-PHOTOSGOOGLE-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('"(https://video-downloads.*?)",.*?,.*?,(.*?),',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if ekTrZlFMu0Kf5QztEnhAs:
		ekTrZlFMu0Kf5QztEnhAs,ohAHUqdbWFi8D1L4Xwzus0f3RYv = ekTrZlFMu0Kf5QztEnhAs[0]
		return '',[ohAHUqdbWFi8D1L4Xwzus0f3RYv],[ekTrZlFMu0Kf5QztEnhAs]
	return 'Error: Resolver Failed PHOTOSGOOGLE',[],[]
def XXW03oFr2P(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',url,'','','','','RESOLVERS-FASELHD1-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	oo9SgGkiDbs3HRn7z8 = zz4hcMfiyUwxHgBDt(oo9SgGkiDbs3HRn7z8)
	ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('"file":"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if ekTrZlFMu0Kf5QztEnhAs: return '',[''],[ekTrZlFMu0Kf5QztEnhAs[0]]
	return 'Error: Resolver Failed FASELHD1',[],[]
def hjCIaSDtTE(url):
	if '/down.php' in url:
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',url,'','','','','RESOLVERS-SHOFHA-1st')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('video-wrapper.*?href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		url = ekTrZlFMu0Kf5QztEnhAs[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def nklwYcfzev(url):
	if 'server.php' in url:
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',url,'','','','','RESOLVERS-CIMA4U-1st')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs[0]
		if 'http' in ekTrZlFMu0Kf5QztEnhAs: return 'NEED_EXTERNAL_RESOLVERS',[''],[ekTrZlFMu0Kf5QztEnhAs]
		return 'Error: Resolver Failed CIMA4U',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def LLf3XgyDNA(url):
	gANn35esloKUydOipfSMC6RD2,XfOb4VIcPY = ykfj6Qb9Fc5GiJIvelp84rHDn(url)
	emrzEIsMWO2GLw9lpKxSY7n0F = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'POST',gANn35esloKUydOipfSMC6RD2,XfOb4VIcPY,emrzEIsMWO2GLw9lpKxSY7n0F,'','','RESOLVERS-EGYNOW-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not ekTrZlFMu0Kf5QztEnhAs: return 'Error: Resolver Failed EGYNOW',[],[]
	ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ekTrZlFMu0Kf5QztEnhAs]
def NLFpfGkys5(url):
	headers = {'X-Requested-With':'XMLHttpRequest'}
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'',headers,'','','RESOLVERS-SHOOFPRO-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.IGNORECASE)
	if not ekTrZlFMu0Kf5QztEnhAs: return 'Error: Resolver Failed SHOOFPRO',[],[]
	ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ekTrZlFMu0Kf5QztEnhAs]
def YHsR9TjoQK(url):
	gANn35esloKUydOipfSMC6RD2,XfOb4VIcPY = ykfj6Qb9Fc5GiJIvelp84rHDn(url)
	emrzEIsMWO2GLw9lpKxSY7n0F = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'POST',gANn35esloKUydOipfSMC6RD2,XfOb4VIcPY,emrzEIsMWO2GLw9lpKxSY7n0F,'','','RESOLVERS-HALACIMA-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('''<iframe src=["'](.*?)["']''',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.IGNORECASE)
	if not ekTrZlFMu0Kf5QztEnhAs: return 'Error: Resolver Failed HALACIMA',[],[]
	ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs[0]
	if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = 'http:'+ekTrZlFMu0Kf5QztEnhAs
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ekTrZlFMu0Kf5QztEnhAs]
def e0WXjywiOS(url):
	gANn35esloKUydOipfSMC6RD2,XfOb4VIcPY = ykfj6Qb9Fc5GiJIvelp84rHDn(url)
	emrzEIsMWO2GLw9lpKxSY7n0F = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'POST',gANn35esloKUydOipfSMC6RD2,XfOb4VIcPY,emrzEIsMWO2GLw9lpKxSY7n0F,'','','RESOLVERS-CIMAABDO-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('''<iframe src=["'](.*?)["']''',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.IGNORECASE)
	if ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs[0]
	else: ekTrZlFMu0Kf5QztEnhAs = url
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ekTrZlFMu0Kf5QztEnhAs]
def pQabjHLJut(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','RESOLVERS-TVFUN-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	iXPdqKVTHsCb8AOxe5 = u5h2Rckvw1E.findall("var fserv =.*?'(.*?)'",oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.IGNORECASE)
	if iXPdqKVTHsCb8AOxe5:
		iXPdqKVTHsCb8AOxe5 = iXPdqKVTHsCb8AOxe5[0][2:]
		iXPdqKVTHsCb8AOxe5 = yB3NPc2ZhbwFEi1X0dv.b64decode(iXPdqKVTHsCb8AOxe5)
		if VVGRN7xiyj: iXPdqKVTHsCb8AOxe5 = iXPdqKVTHsCb8AOxe5.decode('utf8')
		ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('src="(.*?)"',iXPdqKVTHsCb8AOxe5,u5h2Rckvw1E.DOTALL)
	else: ekTrZlFMu0Kf5QztEnhAs = ''
	if not ekTrZlFMu0Kf5QztEnhAs: return 'Error: Resolver Failed TVFUN',[],[]
	ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs[0]
	if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = 'http:'+ekTrZlFMu0Kf5QztEnhAs
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ekTrZlFMu0Kf5QztEnhAs]
def caYyemB7EVN98wFJdvKIL0tGkD(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',url,'','','','','RESOLVERS-MYEGYVIP-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('class="col-sm-12".*?href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not ekTrZlFMu0Kf5QztEnhAs: return 'Error: Resolver Failed MYEGYVIP',[],[]
	ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ekTrZlFMu0Kf5QztEnhAs]
def Idq3R2HptB(url):
	id = url.split('/')[-1]
	if '/embed' in url: url = url.replace('/embed','')
	url = url.replace('.com/','.com/player/metadata/')
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',url,'','','','','RESOLVERS-DAILYMOTION-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	ruqEoR69TUCy = 'Error: Resolver Failed DAILYMOTION'
	qZlW4saokbmPnLv7pzcGFQ5H = u5h2Rckvw1E.findall('"error".*?"messagee":"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if qZlW4saokbmPnLv7pzcGFQ5H: ruqEoR69TUCy = qZlW4saokbmPnLv7pzcGFQ5H[0]
	url = u5h2Rckvw1E.findall('x-mpegURL","url":"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not url and ruqEoR69TUCy:
		return ruqEoR69TUCy,[],[]
	ekTrZlFMu0Kf5QztEnhAs = url[0].replace('\\','')
	NSf4FLmepCv6,QJmOuSTlKhFXVnPo2M5x81qjsAfLbI = bkz2aCFLpWqGUcPolSXA980O(ekTrZlFMu0Kf5QztEnhAs)
	FRov4fbHu7K = u5h2Rckvw1E.findall('"owner":{"id":"(.*?)","screenname":"(.*?)","url":"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if FRov4fbHu7K: q1duyw8FOJ52x,MEhzjJF3SUWNPmtaviDTIKfqrAOux,tuWwBZYzUaeSHmAGOXlRKQghkcy4bM = FRov4fbHu7K[0]
	else: q1duyw8FOJ52x,MEhzjJF3SUWNPmtaviDTIKfqrAOux,tuWwBZYzUaeSHmAGOXlRKQghkcy4bM = '','',''
	tuWwBZYzUaeSHmAGOXlRKQghkcy4bM = tuWwBZYzUaeSHmAGOXlRKQghkcy4bM.replace('\/','/')
	MEhzjJF3SUWNPmtaviDTIKfqrAOux = ffbxegm1XPSqIwp8i(MEhzjJF3SUWNPmtaviDTIKfqrAOux)
	hVby8e3aQkFfuE = ['[COLOR FFC89008]OWNER:  '+MEhzjJF3SUWNPmtaviDTIKfqrAOux+'[/COLOR]']+NSf4FLmepCv6
	EaBeVhOsHYg8wub = [tuWwBZYzUaeSHmAGOXlRKQghkcy4bM]+QJmOuSTlKhFXVnPo2M5x81qjsAfLbI
	u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = tYysxJLreEBDdXMIjz4OPa('اختر الملف المناسب: ('+str(len(EaBeVhOsHYg8wub)-1)+' ملف)',hVby8e3aQkFfuE)
	if u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo==-1: return 'EXIT_RESOLVER',[],[]
	elif u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo==0:
		HKf2QLIX3NVl94GDEJvmtoBr1dS = vdo2FnhPmAVRMJQZ0EIG8.argv[0]+'?type=folder&mode=402&url='+tuWwBZYzUaeSHmAGOXlRKQghkcy4bM+'&textt='+MEhzjJF3SUWNPmtaviDTIKfqrAOux
		bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin("Container.Update("+HKf2QLIX3NVl94GDEJvmtoBr1dS+")")
		return 'EXIT_RESOLVER',[],[]
	ekTrZlFMu0Kf5QztEnhAs =  EaBeVhOsHYg8wub[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
	return '',[''],[ekTrZlFMu0Kf5QztEnhAs]
def Doxsw2Anyd(ekTrZlFMu0Kf5QztEnhAs):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',ekTrZlFMu0Kf5QztEnhAs,'','','','','RESOLVERS-BOKRA-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	if '.json' in ekTrZlFMu0Kf5QztEnhAs: url = u5h2Rckvw1E.findall('"src":"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	else: url = u5h2Rckvw1E.findall('source src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not url: return 'Error: Resolver Failed BOKRA',[],[]
	url = url[0]
	if 'http' not in url: url = 'http:'+url
	return '',[''],[url]
def LQAazgklTtUdwhic8X3u9(url):
	headers = { 'User-Agent' : '' }
	if 'op=download_orig' in url:
		oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(hs8IDEMn0YuCHwk,url,'',headers,'','RESOLVERS-MOSHAHDA-1st')
		items = u5h2Rckvw1E.findall('direct link.*?href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if items: return '',[''],[items[0]]
		else:
			MLPwxur5kaYlBtqcn = u5h2Rckvw1E.findall('class="err">(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
			if MLPwxur5kaYlBtqcn:
				xl9MFt1AmY0GrkENug8n('','','رسالة من الموقع الاصلي',MLPwxur5kaYlBtqcn[0])
				return 'Error: '+MLPwxur5kaYlBtqcn[0],[],[]
	else:
		yGAtUBdJLngm = 'movizland'
		oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(hs8IDEMn0YuCHwk,url,'',headers,'','RESOLVERS-MOSHAHDA-2nd')
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('Form method="POST" action=\'(.*?)\'(.*?)div',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if not cWafzb4HoG1Em3Jwxu6C7vZsVi: return 'Error: Resolver Failed MOSHAHDA',[],[]
		olm59qifJbWpRsr1a3X7zBEIA = cWafzb4HoG1Em3Jwxu6C7vZsVi[0][0]
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0][1]
		if '.rar' in lmO2YJGr6tCV or '.zip' in lmO2YJGr6tCV: return 'Error: MOSHAHDA Not a video file',[],[]
		items = u5h2Rckvw1E.findall('name="(.*?)".*?value="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		nD70jhRb8C9Gi = {}
		for WGy8jZubInXc7zRBJ5p,c2eEflztvIX in items:
			nD70jhRb8C9Gi[WGy8jZubInXc7zRBJ5p] = c2eEflztvIX
		data = x1SKFacgifEdUthsYBbnC5XyTj(nD70jhRb8C9Gi)
		oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(hs8IDEMn0YuCHwk,olm59qifJbWpRsr1a3X7zBEIA,data,headers,'','RESOLVERS-MOSHAHDA-3rd')
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('Download Video.*?get\(\'(.*?)\'.*?sources:(.*?)image:',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if not cWafzb4HoG1Em3Jwxu6C7vZsVi: return 'Error: Resolver Failed MOSHAHDA',[],[]
		download = cWafzb4HoG1Em3Jwxu6C7vZsVi[0][0]
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0][1]
		items = u5h2Rckvw1E.findall('file:"(.*?)"(,label:".*?"|)',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		Z5FySkDLAlm,hVby8e3aQkFfuE,aaybUwAWp2NGnesRYcFqBfkd,EaBeVhOsHYg8wub,D6kiFW8bS7qJtoZua9 = [],[],[],[],[]
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if '.m3u8' in ekTrZlFMu0Kf5QztEnhAs:
				Z5FySkDLAlm,aaybUwAWp2NGnesRYcFqBfkd = bkz2aCFLpWqGUcPolSXA980O(ekTrZlFMu0Kf5QztEnhAs)
				EaBeVhOsHYg8wub = EaBeVhOsHYg8wub + aaybUwAWp2NGnesRYcFqBfkd
				if Z5FySkDLAlm[0]=='-1': hVby8e3aQkFfuE.append(' سيرفر خاص '+'m3u8 '+yGAtUBdJLngm)
				else:
					for title in Z5FySkDLAlm:
						hVby8e3aQkFfuE.append(' سيرفر خاص '+'m3u8 '+yGAtUBdJLngm+' '+title)
			else:
				title = title.replace(',label:"','')
				title = title.strip('"')
				title = ' سيرفر  خاص '+' mp4 '+yGAtUBdJLngm+' '+title
				hVby8e3aQkFfuE.append(title)
				EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
		ekTrZlFMu0Kf5QztEnhAs = 'http://moshahda.online' + download
		oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(hs8IDEMn0YuCHwk,ekTrZlFMu0Kf5QztEnhAs,'',headers,'','RESOLVERS-MOSHAHDA-5th')
		items = u5h2Rckvw1E.findall("download_video\('(.*?)','(.*?)','(.*?)'.*?<td>(.*?),",oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		for id,wMCm6g9qFyPT0xpneDUNc2lEhaZY,hash,oo8X36PUtVj7LJKsDdkMblEgCZYWn in items:
			title = ' سيرفر تحميل خاص '+' mp4 '+yGAtUBdJLngm+' '+oo8X36PUtVj7LJKsDdkMblEgCZYWn.split('x')[1]
			ekTrZlFMu0Kf5QztEnhAs = 'http://moshahda.online/dl?op=download_orig&id='+id+'&mode='+wMCm6g9qFyPT0xpneDUNc2lEhaZY+'&hash='+hash
			D6kiFW8bS7qJtoZua9.append(oo8X36PUtVj7LJKsDdkMblEgCZYWn)
			hVby8e3aQkFfuE.append(title)
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
		D6kiFW8bS7qJtoZua9 = set(D6kiFW8bS7qJtoZua9)
		RBdGAf4VtOF,UTfg8DSm1z = [],[]
		for title in hVby8e3aQkFfuE:
			RpaTdKDBzjvIX7kQ6GuFMyH = u5h2Rckvw1E.findall(" (\d*x|\d*)&&",title+'&&',u5h2Rckvw1E.DOTALL)
			for oo8X36PUtVj7LJKsDdkMblEgCZYWn in D6kiFW8bS7qJtoZua9:
				if RpaTdKDBzjvIX7kQ6GuFMyH[0] in oo8X36PUtVj7LJKsDdkMblEgCZYWn:
					title = title.replace(RpaTdKDBzjvIX7kQ6GuFMyH[0],oo8X36PUtVj7LJKsDdkMblEgCZYWn.split('x')[1])
			RBdGAf4VtOF.append(title)
		for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(len(EaBeVhOsHYg8wub)):
			items = u5h2Rckvw1E.findall("&&(.*?)(\d*)&&",'&&'+RBdGAf4VtOF[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE]+'&&',u5h2Rckvw1E.DOTALL)
			UTfg8DSm1z.append( [RBdGAf4VtOF[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE],EaBeVhOsHYg8wub[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE],items[0][0],items[0][1]] )
		UTfg8DSm1z = sorted(UTfg8DSm1z, key=lambda oVMbrsQjklpC0EeX6: oVMbrsQjklpC0EeX6[3], reverse=True)
		UTfg8DSm1z = sorted(UTfg8DSm1z, key=lambda oVMbrsQjklpC0EeX6: oVMbrsQjklpC0EeX6[2], reverse=False)
		hVby8e3aQkFfuE,EaBeVhOsHYg8wub = [],[]
		for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(len(UTfg8DSm1z)):
			hVby8e3aQkFfuE.append(UTfg8DSm1z[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE][0])
			EaBeVhOsHYg8wub.append(UTfg8DSm1z[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE][1])
	if len(EaBeVhOsHYg8wub)==0: return 'Error: Resolver Failed MOSHAHDA',[],[]
	return '',hVby8e3aQkFfuE,EaBeVhOsHYg8wub
def IiPRq3Tp87QthG1HWZY(url):
	KKSjuTY20EibkGc413C = url.split('?')
	gANn35esloKUydOipfSMC6RD2 = KKSjuTY20EibkGc413C[0]
	headers = { 'User-Agent' : '' }
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(hs8IDEMn0YuCHwk,gANn35esloKUydOipfSMC6RD2,'',headers,'','RESOLVERS-E5TSAR-1st')
	items = u5h2Rckvw1E.findall('Please wait.*?href=\'(.*?)\'',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	url = items[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def G9A2QgW4j5eKwD3Joicnpu(url):
	hVby8e3aQkFfuE,EaBeVhOsHYg8wub = [],[]
	headers = { 'User-Agent' : '' }
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,url,'',headers,'','RESOLVERS-FACULTYBOOKS-1st')
	gANn35esloKUydOipfSMC6RD2 = u5h2Rckvw1E.findall('redirect_url.*?href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if gANn35esloKUydOipfSMC6RD2: return '',[''],[gANn35esloKUydOipfSMC6RD2[0]]
	else: return 'Error: Resolver Failed BUZZVRL',[],[]
def jbzpI0Ku2UQOFNJ1cAl5mL6(url):
	hVby8e3aQkFfuE,EaBeVhOsHYg8wub = [],[]
	headers = { 'User-Agent' : '' }
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,url,'',headers,'','RESOLVERS-FACULTYBOOKS-1st')
	gANn35esloKUydOipfSMC6RD2 = u5h2Rckvw1E.findall('href","(htt.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if gANn35esloKUydOipfSMC6RD2: return '',[''],[gANn35esloKUydOipfSMC6RD2[0]]
	else: return 'Error: Resolver Failed FACULTYBOOKS',[],[]
def yVGIEJxcRO(url):
	hVby8e3aQkFfuE,EaBeVhOsHYg8wub,errno = [],[],''
	if '/wp-admin/' in url:
		gANn35esloKUydOipfSMC6RD2,XfOb4VIcPY = ykfj6Qb9Fc5GiJIvelp84rHDn(url)
		emrzEIsMWO2GLw9lpKxSY7n0F = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'POST',gANn35esloKUydOipfSMC6RD2,XfOb4VIcPY,emrzEIsMWO2GLw9lpKxSY7n0F,'','','RESOLVERS-FAJERSHOW-2nd')
		ZCOosjaQ8x9HDKSVGM6LwW2vy = RoQL91PphqCJg4W0e6Fnsl.content
		if ZCOosjaQ8x9HDKSVGM6LwW2vy.startswith('http'): gANn35esloKUydOipfSMC6RD2 = ZCOosjaQ8x9HDKSVGM6LwW2vy
		else:
			UcmHDPlLWaSf = u5h2Rckvw1E.findall('''src=['"](.*?)['"]''',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)
			if UcmHDPlLWaSf:
				gANn35esloKUydOipfSMC6RD2 = UcmHDPlLWaSf[0]
				UcmHDPlLWaSf = u5h2Rckvw1E.findall('source=(.*?)[&$]',gANn35esloKUydOipfSMC6RD2,u5h2Rckvw1E.DOTALL)
				if UcmHDPlLWaSf:
					gANn35esloKUydOipfSMC6RD2 = P2o6ZDHeW790pSQqucvnxzILVUX(UcmHDPlLWaSf[0])
					return '',[''],[gANn35esloKUydOipfSMC6RD2]
	elif '/links/' in url:
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',url,'','',True,'','RESOLVERS-FAJERSHOW-1st')
		ZCOosjaQ8x9HDKSVGM6LwW2vy = RoQL91PphqCJg4W0e6Fnsl.content
		if 'Location' in list(RoQL91PphqCJg4W0e6Fnsl.headers.keys()): gANn35esloKUydOipfSMC6RD2 = RoQL91PphqCJg4W0e6Fnsl.headers['Location']
		else: gANn35esloKUydOipfSMC6RD2 = u5h2Rckvw1E.findall('id="link".*?href="(.*?)"',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)[0]
	if '/v/' in gANn35esloKUydOipfSMC6RD2 or '/f/' in gANn35esloKUydOipfSMC6RD2:
		gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2.replace('/f/','/api/source/')
		gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2.replace('/v/','/api/source/')
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'POST',gANn35esloKUydOipfSMC6RD2,'','','','','RESOLVERS-FAJERSHOW-3rd')
		ZCOosjaQ8x9HDKSVGM6LwW2vy = RoQL91PphqCJg4W0e6Fnsl.content
		items = u5h2Rckvw1E.findall('"file":"(.*?)","label":"(.*?)"',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)
		if items:
			for ekTrZlFMu0Kf5QztEnhAs,title in items:
				ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.replace('\\','')
				hVby8e3aQkFfuE.append(title)
				EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
		else:
			items = u5h2Rckvw1E.findall('"file":"(.*?)"',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)
			if items:
				ekTrZlFMu0Kf5QztEnhAs = items[0]
				ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.replace('\\','')
				hVby8e3aQkFfuE.append('')
				EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	else: return 'NEED_EXTERNAL_RESOLVERS',[''],[gANn35esloKUydOipfSMC6RD2]
	if len(EaBeVhOsHYg8wub)==0: return 'Error: Resolver Failed FAJERSHOW',[],[]
	return '',hVby8e3aQkFfuE,EaBeVhOsHYg8wub
def VCdK5LpWwE(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',url,'','','','','RESOLVERS-MOVS4U-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	hVby8e3aQkFfuE,EaBeVhOsHYg8wub,errno = [],[],''
	if 'player_embed.php' in url or '/embed/' in url:
		if 'player_embed.php' in url:
			gANn35esloKUydOipfSMC6RD2 = u5h2Rckvw1E.findall('src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
			gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2[0]
		else: gANn35esloKUydOipfSMC6RD2 = url
		if 'movs4u' not in gANn35esloKUydOipfSMC6RD2: return 'NEED_EXTERNAL_RESOLVERS',[''],[gANn35esloKUydOipfSMC6RD2]
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',gANn35esloKUydOipfSMC6RD2,'','','','','RESOLVERS-MOVS4U-2nd')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('id="player"(.*?)videojs',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('<source src="(.*?)".*?label="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if items:
			for ekTrZlFMu0Kf5QztEnhAs,eDvzfWdXZnlMEiboY5j1P in items:
				hVby8e3aQkFfuE.append(eDvzfWdXZnlMEiboY5j1P)
				EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	elif 'main_player.php' in url:
		gANn35esloKUydOipfSMC6RD2 = u5h2Rckvw1E.findall('url=(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2[0]
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',gANn35esloKUydOipfSMC6RD2,'','','','','RESOLVERS-MOVS4U-3rd')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		UcmHDPlLWaSf = u5h2Rckvw1E.findall('"file": "(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		UcmHDPlLWaSf = UcmHDPlLWaSf[0]
		hVby8e3aQkFfuE.append('')
		EaBeVhOsHYg8wub.append(UcmHDPlLWaSf)
	elif 'download_link' in url:
		gANn35esloKUydOipfSMC6RD2 = u5h2Rckvw1E.findall('<center><a href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if gANn35esloKUydOipfSMC6RD2:
			gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2[0]
			return 'NEED_EXTERNAL_RESOLVERS',[''],[gANn35esloKUydOipfSMC6RD2]
	if len(EaBeVhOsHYg8wub)==0: return 'Error: Resolver Failed MOVS4U',[],[]
	return '',hVby8e3aQkFfuE,EaBeVhOsHYg8wub
def ZZDpU58LVm(url):
	website = pgPfwZleTHVQ9a['CIMACLUB'][0]
	headers = {'Referer':website}
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'GET',url,'',headers,'','','RESOLVERS-CIMACLUB-2nd')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	NDwLctrHpYz3JBP = hmcFWJUgiAuGk(url,'url')
	ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('download=.*?href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall("sources: \['(.*?)'",oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall("file:'(.*?)'",oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if ekTrZlFMu0Kf5QztEnhAs:
		ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs[0]+'|Referer='+website
		return '',[''],[ekTrZlFMu0Kf5QztEnhAs]
	if 'name="Xtoken"' in oo9SgGkiDbs3HRn7z8:
		FFHUOPvZTQ = u5h2Rckvw1E.findall('name="Xtoken" content="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if FFHUOPvZTQ:
			ekTrZlFMu0Kf5QztEnhAs = FFHUOPvZTQ[0]
			ekTrZlFMu0Kf5QztEnhAs = yB3NPc2ZhbwFEi1X0dv.b64decode(ekTrZlFMu0Kf5QztEnhAs)
			if VVGRN7xiyj: ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.decode('utf8','ignore')
			ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('http.*?(http.*?),',ekTrZlFMu0Kf5QztEnhAs,u5h2Rckvw1E.DOTALL)
			if ekTrZlFMu0Kf5QztEnhAs:
				ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs[0]+'|Referer='+website
				return '',[''],[ekTrZlFMu0Kf5QztEnhAs]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def LLZ6q2UV4K(url):
	kPpGr0QERz4tyh3C,GnuaoT9MxiCg = [],[]
	if '/1/' in url:
		ekTrZlFMu0Kf5QztEnhAs = url.replace('/1/','/4/')
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'GET',ekTrZlFMu0Kf5QztEnhAs,'','',False,'','RESOLVERS-EGYBEST1-1st')
		ZCOosjaQ8x9HDKSVGM6LwW2vy = RoQL91PphqCJg4W0e6Fnsl.content
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('<video(.*?)</video>',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('src="(.*?)".*?size="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,ohAHUqdbWFi8D1L4Xwzus0f3RYv in items:
				if ekTrZlFMu0Kf5QztEnhAs not in GnuaoT9MxiCg:
					GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs)
					NDwLctrHpYz3JBP = hmcFWJUgiAuGk(ekTrZlFMu0Kf5QztEnhAs,'name')
					kPpGr0QERz4tyh3C.append(NDwLctrHpYz3JBP+'  '+ohAHUqdbWFi8D1L4Xwzus0f3RYv)
			return '',kPpGr0QERz4tyh3C,GnuaoT9MxiCg
	elif '/d/' in url:
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'GET',url,'','','','','RESOLVERS-EGYBEST1-2nd')
		ZCOosjaQ8x9HDKSVGM6LwW2vy = RoQL91PphqCJg4W0e6Fnsl.content
		ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('<iframe.*?src="(.*?)"',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)
		if ekTrZlFMu0Kf5QztEnhAs:
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs[0].replace('/1/','/4/')
			RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'GET',ekTrZlFMu0Kf5QztEnhAs,'','',False,'','RESOLVERS-EGYBEST1-3rd')
			ZCOosjaQ8x9HDKSVGM6LwW2vy = RoQL91PphqCJg4W0e6Fnsl.content
			ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('class.*?href="(.*?)"',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)
			if ekTrZlFMu0Kf5QztEnhAs: return 'NEED_EXTERNAL_RESOLVERS',[''],[ekTrZlFMu0Kf5QztEnhAs[0]]
	return 'Error: Resolver Failed EGYBEST1',[],[]
def XMumB6sYhk(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'GET',url,'','','','','RESOLVERS-EGYBEST3-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	data = u5h2Rckvw1E.findall('"action".*?value="(.*?)".*?value="(.*?)".*?value="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if data:
		JUVfw8xALW,id,UUXH23jLE7sfv5dagS8 = data[0]
		data = 'op='+JUVfw8xALW+'&id='+id+'&fname='+UUXH23jLE7sfv5dagS8
		headers = {'Content-Type':'application/x-www-form-urlencoded'}
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'POST',url,data,headers,'','','RESOLVERS-EGYBEST3-2nd')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('"referer" value="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if ekTrZlFMu0Kf5QztEnhAs: return 'NEED_EXTERNAL_RESOLVERS',[''],[ekTrZlFMu0Kf5QztEnhAs[0]]
	return 'Error: Resolver Failed EGYBEST1',[],[]
def Hfp1lCym08(url):
	gANn35esloKUydOipfSMC6RD2 = url.split('?named=',1)[0].strip('?').strip('/').strip('&')
	hVby8e3aQkFfuE,EaBeVhOsHYg8wub,items,UcmHDPlLWaSf = [],[],[],''
	headers = { 'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' }
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',gANn35esloKUydOipfSMC6RD2,'',headers,True,'','RESOLVERS-EGYBEST-1st')
	if 'Location' in list(RoQL91PphqCJg4W0e6Fnsl.headers.keys()): UcmHDPlLWaSf = RoQL91PphqCJg4W0e6Fnsl.headers['Location']
	if 'http' in UcmHDPlLWaSf:
		if '__watch' in url: UcmHDPlLWaSf = UcmHDPlLWaSf.replace('/f/','/v/')
		giK6QLuxNZpmnhYOla45Sd = gANn35esloKUydOipfSMC6RD2.split('?PHPSID=')[1]
		headers = { 'User-Agent':headers['User-Agent'] , 'Cookie':'PHPSID='+giK6QLuxNZpmnhYOla45Sd }
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',UcmHDPlLWaSf,'',headers,False,'','EGYBEST-PLAY-3rd')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		if '/f/' in UcmHDPlLWaSf: items = u5h2Rckvw1E.findall('<h2>.*?href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		elif '/v/' in UcmHDPlLWaSf: items = u5h2Rckvw1E.findall('id="video".*?src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if items: return [],[''],[ items[0] ]
		elif '<h1>404</h1>' in oo9SgGkiDbs3HRn7z8:
			return 'Error: سيرفر الفيديو فيه حجب ضد كودي ومصدره من الإنترنت الخاصة بك',[],[]
	else: return 'Error: Resolver Failed EGYBEST',[],[]
def hyDITNRzH6(ekTrZlFMu0Kf5QztEnhAs):
	KKSjuTY20EibkGc413C = u5h2Rckvw1E.findall('postid=(.*?)&serverid=(.*?)&&',ekTrZlFMu0Kf5QztEnhAs+'&&',u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.IGNORECASE)
	QKdSLIz9q017ARY,bbLlyzvIcPRU7e4pGBD = KKSjuTY20EibkGc413C[0]
	url = 'https://series4watch.net/ajaxCenter?_action=getserver&_post_id='+QKdSLIz9q017ARY+'&serverid='+bbLlyzvIcPRU7e4pGBD
	headers = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' }
	gANn35esloKUydOipfSMC6RD2 = wANetMq45ZG2EhvL38HgfYCBzn1o(hs8IDEMn0YuCHwk,url,'',headers,'','RESOLVERS-SERIES4WATCH-1st')
	return 'NEED_EXTERNAL_RESOLVERS',[''],[gANn35esloKUydOipfSMC6RD2]
def W9RI8wqtK2(url):
	NDwLctrHpYz3JBP = hmcFWJUgiAuGk(url,'url')
	emrzEIsMWO2GLw9lpKxSY7n0F = {'Referer':NDwLctrHpYz3JBP,'Accept-Encoding':'gzip, deflate'}
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(Iu3GUD84WyEqQjPFTYeh1SL9J,'GET',url,'',emrzEIsMWO2GLw9lpKxSY7n0F,'','','RESOLVERS-MYCIMA-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('player.qualityselector(.*?)formats:',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	gANn35esloKUydOipfSMC6RD2 = ''
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('format: \'(\d.*?)\', src: "(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		hVby8e3aQkFfuE,EaBeVhOsHYg8wub = [],[]
		for title,ekTrZlFMu0Kf5QztEnhAs in items:
			hVby8e3aQkFfuE.append(title)
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
		if len(EaBeVhOsHYg8wub)==1: gANn35esloKUydOipfSMC6RD2 = EaBeVhOsHYg8wub[0]
		elif len(EaBeVhOsHYg8wub)>1:
			u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = tYysxJLreEBDdXMIjz4OPa('أختر الملف المناسب', hVby8e3aQkFfuE)
			if u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo==-1: return '',[],[]
			gANn35esloKUydOipfSMC6RD2 = EaBeVhOsHYg8wub[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
	else:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('source src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi: gANn35esloKUydOipfSMC6RD2 = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	if not gANn35esloKUydOipfSMC6RD2: return 'Error: Resolver Failed MYCIMA',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[gANn35esloKUydOipfSMC6RD2]
def yyFkTgEfoX(url):
	NDwLctrHpYz3JBP = hmcFWJUgiAuGk(url,'url')
	emrzEIsMWO2GLw9lpKxSY7n0F = {'Referer':NDwLctrHpYz3JBP,'Accept-Encoding':'gzip, deflate'}
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(Iu3GUD84WyEqQjPFTYeh1SL9J,'GET',url,'',emrzEIsMWO2GLw9lpKxSY7n0F,'','','RESOLVERS-WECIMA-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('player.qualityselector(.*?)formats:',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	gANn35esloKUydOipfSMC6RD2 = ''
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('format: \'(\d.*?)\', src: "(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		hVby8e3aQkFfuE,EaBeVhOsHYg8wub = [],[]
		for title,ekTrZlFMu0Kf5QztEnhAs in items:
			hVby8e3aQkFfuE.append(title)
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
		if len(EaBeVhOsHYg8wub)==1: gANn35esloKUydOipfSMC6RD2 = EaBeVhOsHYg8wub[0]
		elif len(EaBeVhOsHYg8wub)>1:
			u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = tYysxJLreEBDdXMIjz4OPa('أختر الملف المناسب', hVby8e3aQkFfuE)
			if u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo==-1: return '',[],[]
			gANn35esloKUydOipfSMC6RD2 = EaBeVhOsHYg8wub[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
	if not gANn35esloKUydOipfSMC6RD2:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('source src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi: gANn35esloKUydOipfSMC6RD2 = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	if not gANn35esloKUydOipfSMC6RD2: return 'Error: Resolver Failed WECIMA',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[gANn35esloKUydOipfSMC6RD2]
def kmsGWLvufP(ekTrZlFMu0Kf5QztEnhAs):
	KKSjuTY20EibkGc413C = u5h2Rckvw1E.findall('(http.*?)\?postid=(.*?)&serverid=(.*?)&&',ekTrZlFMu0Kf5QztEnhAs+'&&',u5h2Rckvw1E.DOTALL)
	url,QKdSLIz9q017ARY,bbLlyzvIcPRU7e4pGBD = KKSjuTY20EibkGc413C[0]
	data = {'post_id':QKdSLIz9q017ARY,'server':bbLlyzvIcPRU7e4pGBD}
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'POST',url,data,'','','','RESOLVERS-AKOAMCAM-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	gANn35esloKUydOipfSMC6RD2 = u5h2Rckvw1E.findall('iframe src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[gANn35esloKUydOipfSMC6RD2]
def Njt6lSoURL(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','RESOLVERS-CIMALIGHT-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('<iframe.*?src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if ekTrZlFMu0Kf5QztEnhAs:
		ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs[0]
		if ekTrZlFMu0Kf5QztEnhAs: return 'NEED_EXTERNAL_RESOLVERS',[''],[ekTrZlFMu0Kf5QztEnhAs]
	return 'Error: Resolver Failed CIMALIGHT',[],[]
def JB0xjSXlDZ(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','RESOLVERS-CIMACLUP-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('<IFRAME SRC="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ekTrZlFMu0Kf5QztEnhAs]
def QW5xFpg0rX(url):
	TImV9B8wLag3trpRZWvAqQPN5 = hmcFWJUgiAuGk(url,'url')
	if 'index=' in url:
		headers = {'Referer':TImV9B8wLag3trpRZWvAqQPN5}
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'',headers,'','','RESOLVERS-CIMANOW-1st')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		gANn35esloKUydOipfSMC6RD2 = u5h2Rckvw1E.findall('src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if gANn35esloKUydOipfSMC6RD2:
			gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2[0]
			if 'cimanow' in gANn35esloKUydOipfSMC6RD2:
				gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2.replace('https://','http://')
				RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',gANn35esloKUydOipfSMC6RD2,'',headers,'','','RESOLVERS-CIMANOW-2nd')
				ZCOosjaQ8x9HDKSVGM6LwW2vy = RoQL91PphqCJg4W0e6Fnsl.content
				items = u5h2Rckvw1E.findall('source src="(.*?)".*?size="(.*?)"',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)
				hVby8e3aQkFfuE,EaBeVhOsHYg8wub = [],[]
				GDJeByAH5fRS9I = hmcFWJUgiAuGk(gANn35esloKUydOipfSMC6RD2,'url')
				for ekTrZlFMu0Kf5QztEnhAs,ohAHUqdbWFi8D1L4Xwzus0f3RYv in reversed(items):
					ekTrZlFMu0Kf5QztEnhAs = GDJeByAH5fRS9I+ekTrZlFMu0Kf5QztEnhAs+'|Referer='+GDJeByAH5fRS9I
					hVby8e3aQkFfuE.append(ohAHUqdbWFi8D1L4Xwzus0f3RYv)
					EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
				return '',hVby8e3aQkFfuE,EaBeVhOsHYg8wub
			else: return 'NEED_EXTERNAL_RESOLVERS',[''],[gANn35esloKUydOipfSMC6RD2]
	gANn35esloKUydOipfSMC6RD2 = url+'|Referer='+TImV9B8wLag3trpRZWvAqQPN5
	return '',[''],[gANn35esloKUydOipfSMC6RD2]
def UYnHJmAwjFypZq(ekTrZlFMu0Kf5QztEnhAs):
	TImV9B8wLag3trpRZWvAqQPN5 = hmcFWJUgiAuGk(ekTrZlFMu0Kf5QztEnhAs,'url')
	if 'postid' in ekTrZlFMu0Kf5QztEnhAs:
		KKSjuTY20EibkGc413C = u5h2Rckvw1E.findall('(http.*?)\?postid=(.*?)&serverid=(.*?)&&',ekTrZlFMu0Kf5QztEnhAs+'&&',u5h2Rckvw1E.DOTALL)
		url,QKdSLIz9q017ARY,bbLlyzvIcPRU7e4pGBD = KKSjuTY20EibkGc413C[0]
		data = {'id':QKdSLIz9q017ARY,'server':bbLlyzvIcPRU7e4pGBD}
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'POST',url,data,'','','','RESOLVERS-CIMANOW-1st')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		gANn35esloKUydOipfSMC6RD2 = u5h2Rckvw1E.findall('iframe src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)[0]
		if 'cimanow' in gANn35esloKUydOipfSMC6RD2:
			headers = {'Referer':TImV9B8wLag3trpRZWvAqQPN5,'User-Agent':''}
			RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',gANn35esloKUydOipfSMC6RD2,'',headers,'','','RESOLVERS-CIMANOW-2nd')
			ZCOosjaQ8x9HDKSVGM6LwW2vy = RoQL91PphqCJg4W0e6Fnsl.content
			items = u5h2Rckvw1E.findall('src="(.*?)".*?size="(.*?)"',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)
			hVby8e3aQkFfuE,EaBeVhOsHYg8wub = [],[]
			GDJeByAH5fRS9I = hmcFWJUgiAuGk(gANn35esloKUydOipfSMC6RD2,'url')
			for ekTrZlFMu0Kf5QztEnhAs,ohAHUqdbWFi8D1L4Xwzus0f3RYv in reversed(items):
				ekTrZlFMu0Kf5QztEnhAs = GDJeByAH5fRS9I+ekTrZlFMu0Kf5QztEnhAs+'|Referer='+GDJeByAH5fRS9I
				hVby8e3aQkFfuE.append(ohAHUqdbWFi8D1L4Xwzus0f3RYv)
				EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
			return '',hVby8e3aQkFfuE,EaBeVhOsHYg8wub
		else: return 'NEED_EXTERNAL_RESOLVERS',[''],[gANn35esloKUydOipfSMC6RD2]
	else:
		ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'|Referer='+TImV9B8wLag3trpRZWvAqQPN5
		return '',[''],[ekTrZlFMu0Kf5QztEnhAs]
def uCxKbgU9pj(ekTrZlFMu0Kf5QztEnhAs):
	if 'postid' in ekTrZlFMu0Kf5QztEnhAs:
		KKSjuTY20EibkGc413C = u5h2Rckvw1E.findall('postid=(.*?)&serverid=(.*?)&&',ekTrZlFMu0Kf5QztEnhAs+'&&',u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.IGNORECASE)
		QKdSLIz9q017ARY,bbLlyzvIcPRU7e4pGBD = KKSjuTY20EibkGc413C[0]
		gH8XUubef1v5 = hmcFWJUgiAuGk(ekTrZlFMu0Kf5QztEnhAs,'url')
		url = gH8XUubef1v5+'/ajaxCenter?_action=getserver&_post_id='+QKdSLIz9q017ARY+'&serverid='+bbLlyzvIcPRU7e4pGBD
		headers = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' }
		gANn35esloKUydOipfSMC6RD2 = wANetMq45ZG2EhvL38HgfYCBzn1o(hs8IDEMn0YuCHwk,url,'',headers,'','RESOLVERS-ARBLIONZ-1st')
		gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2.replace('\n','').replace('\r','')
		return 'NEED_EXTERNAL_RESOLVERS',[''],[gANn35esloKUydOipfSMC6RD2]
	elif '/redirect/' in ekTrZlFMu0Kf5QztEnhAs:
		s2YQCOWqLAFlKT1bvGco3t8x96fnrp = 0
		while '/redirect/' in ekTrZlFMu0Kf5QztEnhAs and s2YQCOWqLAFlKT1bvGco3t8x96fnrp<5:
			RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',ekTrZlFMu0Kf5QztEnhAs,'','','','','RESOLVERS-ARBLIONZ-2nd')
			if 'Location' in list(RoQL91PphqCJg4W0e6Fnsl.headers.keys()): ekTrZlFMu0Kf5QztEnhAs = RoQL91PphqCJg4W0e6Fnsl.headers['Location']
			s2YQCOWqLAFlKT1bvGco3t8x96fnrp += 1
		return '',[''],[ekTrZlFMu0Kf5QztEnhAs]
	else: return 'Error: Resolver Failed ARBLIONZ',[],[]
def MmeOUju29E(url):
	NDwLctrHpYz3JBP = hmcFWJUgiAuGk(url,'url')
	headers = {'Referer':NDwLctrHpYz3JBP,'User-Agent':ncgQBtRa7qT2GJ3Wpd()}
	if '/embed-' in url:
		oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(hs8IDEMn0YuCHwk,url,'',headers,'','RESOLVERS-ARABSEED-2nd')
		ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('<source src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if ekTrZlFMu0Kf5QztEnhAs:
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs[0].replace('https','http')
			return '',[''],[ekTrZlFMu0Kf5QztEnhAs]
	else:
		IJfHL08Dj5cC41VmZvUkBrwNFtY = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',url,'',headers,'','','RESOLVERS-ARABSEED-3rd')
		oo9SgGkiDbs3HRn7z8 = IJfHL08Dj5cC41VmZvUkBrwNFtY.content
		emrzEIsMWO2GLw9lpKxSY7n0F = headers.copy()
		if '_lnk_' in str(IJfHL08Dj5cC41VmZvUkBrwNFtY.cookies):
			cookies = IJfHL08Dj5cC41VmZvUkBrwNFtY.cookies
			emrzEIsMWO2GLw9lpKxSY7n0F['Cookie'] = P2o6ZDHeW790pSQqucvnxzILVUX(x1SKFacgifEdUthsYBbnC5XyTj(cookies))
		ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('link.href = "(http.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if not ekTrZlFMu0Kf5QztEnhAs: return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
		else:
			ekTrZlFMu0Kf5QztEnhAs = P2o6ZDHeW790pSQqucvnxzILVUX(ekTrZlFMu0Kf5QztEnhAs[0])+'&d=1'
			p8HVUxN5v3WZfF4Gt7o0gLOdSiI = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',ekTrZlFMu0Kf5QztEnhAs,'',emrzEIsMWO2GLw9lpKxSY7n0F,'','','RESOLVERS-ARABSEED-4th')
			oo9SgGkiDbs3HRn7z8 = p8HVUxN5v3WZfF4Gt7o0gLOdSiI.content
			ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('id="btn".*?href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
			if ekTrZlFMu0Kf5QztEnhAs:
				ekTrZlFMu0Kf5QztEnhAs = P2o6ZDHeW790pSQqucvnxzILVUX(ekTrZlFMu0Kf5QztEnhAs[0])
				if 'mp4' in ekTrZlFMu0Kf5QztEnhAs and '/d/' in ekTrZlFMu0Kf5QztEnhAs: return '',[''],[ekTrZlFMu0Kf5QztEnhAs]
				else: return 'NEED_EXTERNAL_RESOLVERS',[''],[ekTrZlFMu0Kf5QztEnhAs]
	return 'Error: Resolver Failed ARABSEED',[],[]
def tFWb48mphv(ekTrZlFMu0Kf5QztEnhAs):
	if '_action=getserver' in ekTrZlFMu0Kf5QztEnhAs:
		headers = {'X-Requested-With':'XMLHttpRequest'}
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',ekTrZlFMu0Kf5QztEnhAs,'',headers,'','','RESOLVERS-SHAHID4U-1st')
		url = RoQL91PphqCJg4W0e6Fnsl.content
		if url: return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
	else:
		KKSjuTY20EibkGc413C = u5h2Rckvw1E.findall('postid=(.*?)&serverid=(.*?)$',ekTrZlFMu0Kf5QztEnhAs,u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.IGNORECASE)
		if not KKSjuTY20EibkGc413C: KKSjuTY20EibkGc413C = u5h2Rckvw1E.findall('_post_id=(.*?)&serverid=(.*?)$',ekTrZlFMu0Kf5QztEnhAs,u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.IGNORECASE)
		QKdSLIz9q017ARY,bbLlyzvIcPRU7e4pGBD = KKSjuTY20EibkGc413C[0]
		NDwLctrHpYz3JBP = hmcFWJUgiAuGk(ekTrZlFMu0Kf5QztEnhAs,'url')
		url = NDwLctrHpYz3JBP+'/wp-content/themes/theme/Ajaxat/Single/Server.php'
		data = {'id':QKdSLIz9q017ARY,'i':bbLlyzvIcPRU7e4pGBD}
		headers = {'X-Requested-With':'XMLHttpRequest','Referer':ekTrZlFMu0Kf5QztEnhAs}
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'POST',url,data,headers,'','','RESOLVERS-SHAHID4U-2nd')
		ZCOosjaQ8x9HDKSVGM6LwW2vy = RoQL91PphqCJg4W0e6Fnsl.content
		gANn35esloKUydOipfSMC6RD2 = u5h2Rckvw1E.findall('src="(.*?)"',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.IGNORECASE)
		if gANn35esloKUydOipfSMC6RD2:
			gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2[0]
			return 'NEED_EXTERNAL_RESOLVERS',[''],[gANn35esloKUydOipfSMC6RD2]
	return 'Error: Resolver Failed SHAHID4U',[],[]
def R3RaECkpTbMDln45d2Vrq(UBLWuYCQ4TofptSnjv6V2sNRZ):
	hTijEO6kvoWQCJp = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.akwam.verification')
	headers = {'Cookie':hTijEO6kvoWQCJp} if hTijEO6kvoWQCJp else ''
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',UBLWuYCQ4TofptSnjv6V2sNRZ,'',headers,'','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-1st')
	KIbodwB39AMh0CrHDNlesW = RoQL91PphqCJg4W0e6Fnsl.content
	r6hneF0Wjm8dyplH = str(RoQL91PphqCJg4W0e6Fnsl.headers)
	g5VPMRnj2pqEQoSFOHWz = r6hneF0Wjm8dyplH+KIbodwB39AMh0CrHDNlesW
	if '.mp4' in g5VPMRnj2pqEQoSFOHWz: Hxpd2wePZUyLtJk1hm = True
	else:
		nPyDXYcrhVFQflZe3q,dh1veN6mVBg7pQ,HI1YDpJ6SZ5APuNrC7OV9tzf,YGsXbxM0ag8ZNzywhL3UA,Hxpd2wePZUyLtJk1hm = '','','','',False
		captcha = u5h2Rckvw1E.findall('page-redirect.*?action="(.*?)".*?data-sitekey="(.*?)"',KIbodwB39AMh0CrHDNlesW,u5h2Rckvw1E.DOTALL)
		if captcha: HI1YDpJ6SZ5APuNrC7OV9tzf,YGsXbxM0ag8ZNzywhL3UA = captcha[0]
		LLhKvrMRaC2wS7 = pgPfwZleTHVQ9a['PYTHON'][7]
		hGdKt2jR8SN1z5TrZkuU = lbFixEt3BK9YGMyWIQZuSsp1V7JTL8(32)
		if 0:
			data = {'user':hGdKt2jR8SN1z5TrZkuU,'version':qkSQU3saP0D7OvynNzH4F2BKJuilT,'url':UBLWuYCQ4TofptSnjv6V2sNRZ,'key':YGsXbxM0ag8ZNzywhL3UA,'id':'','job':'geturls'}
			RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'POST',LLhKvrMRaC2wS7,data,'','','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-2nd')
			oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		oo9SgGkiDbs3HRn7z8 = ''
		if oo9SgGkiDbs3HRn7z8.startswith('URLS='):
			LonTW5tCBx1Hrg7vRkl0Yp32Dyu = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('list',oo9SgGkiDbs3HRn7z8.split('URLS=',1)[1])
			for VemfsE32zgI in LonTW5tCBx1Hrg7vRkl0Yp32Dyu:
				url = VemfsE32zgI['url']
				TbXq0ongLPZszic6rHaI5dG8AWCh = VemfsE32zgI['method']
				data = VemfsE32zgI['data']
				headers = VemfsE32zgI['headers']
				RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,TbXq0ongLPZszic6rHaI5dG8AWCh,url,data,headers,'','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-3rd')
				KIbodwB39AMh0CrHDNlesW = RoQL91PphqCJg4W0e6Fnsl.content
				if '.mp4' in KIbodwB39AMh0CrHDNlesW:
					Hxpd2wePZUyLtJk1hm = True
					break
				r6hneF0Wjm8dyplH = str(RoQL91PphqCJg4W0e6Fnsl.headers)
				g5VPMRnj2pqEQoSFOHWz = r6hneF0Wjm8dyplH+KIbodwB39AMh0CrHDNlesW
				nPyDXYcrhVFQflZe3q = u5h2Rckvw1E.findall('(akwamVerification\w+).*?"(eyJ.*?)"',g5VPMRnj2pqEQoSFOHWz,u5h2Rckvw1E.DOTALL)
				dh1veN6mVBg7pQ = u5h2Rckvw1E.findall('recaptcha-token.*?"(03A.*?)"',g5VPMRnj2pqEQoSFOHWz,u5h2Rckvw1E.DOTALL)
				if dh1veN6mVBg7pQ: dh1veN6mVBg7pQ = dh1veN6mVBg7pQ[0]
				if nPyDXYcrhVFQflZe3q or dh1veN6mVBg7pQ: break
		if not Hxpd2wePZUyLtJk1hm:
			if not nPyDXYcrhVFQflZe3q:
				if captcha and not dh1veN6mVBg7pQ:
					if 1: dh1veN6mVBg7pQ = Z57WneruOJP1IHT(YGsXbxM0ag8ZNzywhL3UA,'ar',UBLWuYCQ4TofptSnjv6V2sNRZ)
					else:
						if not oo9SgGkiDbs3HRn7z8.startswith('ID='):
							data = {'user':hGdKt2jR8SN1z5TrZkuU,'version':qkSQU3saP0D7OvynNzH4F2BKJuilT,'url':UBLWuYCQ4TofptSnjv6V2sNRZ,'key':YGsXbxM0ag8ZNzywhL3UA,'id':'','job':'getid'}
							RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'POST',LLhKvrMRaC2wS7,data,'','','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-4th')
							oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
						else: oo9SgGkiDbs3HRn7z8 = 'ID=1234::::TIMEOUT=45'
						if oo9SgGkiDbs3HRn7z8.startswith('ID='):
							zOsbRwYcfoEGk = u5h2Rckvw1E.findall('ID=(.*?)::::TIMEOUT=(.*?)$',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
							lZxKi5UECpG6L1P9D,pKOBP5j4yJQIxsUENle9VR2YDwT = zOsbRwYcfoEGk[0]
							MLPwxur5kaYlBtqcn = 'هذه العملية تحتاج وقت من 10 إلى '+pKOBP5j4yJQIxsUENle9VR2YDwT+' ثانية'
							l3OLD1gEfNXtm = zzLBYaEcM1jlKqX5FyONiRJ()
							l3OLD1gEfNXtm.create('محاولة تجاوز فحص أنا أنسان ولست برنامج كومبيوتر',MLPwxur5kaYlBtqcn)
							o5HAlp2P8x = YVJPFvuI2CS5KObiZt.time()
							bmuXg59MErhPfHInd4T8QB,j6JG24d17N3tiHkoRgsnaLyY = 0,0
							while bmuXg59MErhPfHInd4T8QB<int(pKOBP5j4yJQIxsUENle9VR2YDwT):
								hyCqU2Ns4B1J3EH7fQVe6DXtzgFuI(l3OLD1gEfNXtm,int(bmuXg59MErhPfHInd4T8QB/int(pKOBP5j4yJQIxsUENle9VR2YDwT)*100),MLPwxur5kaYlBtqcn,'',pKOBP5j4yJQIxsUENle9VR2YDwT+' / '+str(int(bmuXg59MErhPfHInd4T8QB))+'  ثانية')
								if bmuXg59MErhPfHInd4T8QB>j6JG24d17N3tiHkoRgsnaLyY+10:
									data = {'user':hGdKt2jR8SN1z5TrZkuU,'version':qkSQU3saP0D7OvynNzH4F2BKJuilT,'url':UBLWuYCQ4TofptSnjv6V2sNRZ,'key':YGsXbxM0ag8ZNzywhL3UA,'id':lZxKi5UECpG6L1P9D,'job':'gettoken'}
									RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'POST',LLhKvrMRaC2wS7,data,'','','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-5th')
									oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
									if oo9SgGkiDbs3HRn7z8.startswith('TOKEN='):
										dh1veN6mVBg7pQ = oo9SgGkiDbs3HRn7z8.split('TOKEN=',1)[1]
										break
									j6JG24d17N3tiHkoRgsnaLyY = bmuXg59MErhPfHInd4T8QB
								else: YVJPFvuI2CS5KObiZt.sleep(1)
								bmuXg59MErhPfHInd4T8QB = YVJPFvuI2CS5KObiZt.time()-o5HAlp2P8x
							l3OLD1gEfNXtm.close()
				if dh1veN6mVBg7pQ:
					dXcFTBjHLDbs2RGImN5yJU = RoQL91PphqCJg4W0e6Fnsl.cookies
					mmf4Q2J8sWg = u5h2Rckvw1E.findall('akwam_session=(.*?);',g5VPMRnj2pqEQoSFOHWz,u5h2Rckvw1E.DOTALL)
					if 'akwam_session' in list(dXcFTBjHLDbs2RGImN5yJU.keys()): mmf4Q2J8sWg = dXcFTBjHLDbs2RGImN5yJU['akwam_session']
					elif mmf4Q2J8sWg: mmf4Q2J8sWg = mmf4Q2J8sWg[0]
					captcha = u5h2Rckvw1E.findall('page-redirect.*?action="(.*?)".*?data-sitekey="(.*?)"',KIbodwB39AMh0CrHDNlesW,u5h2Rckvw1E.DOTALL)
					if captcha: HI1YDpJ6SZ5APuNrC7OV9tzf,YGsXbxM0ag8ZNzywhL3UA = captcha[0]
					if mmf4Q2J8sWg and captcha:
						headers = {'Cookie':'akwam_session='+mmf4Q2J8sWg,'Referer':UBLWuYCQ4TofptSnjv6V2sNRZ,'Content-Type':'application/x-www-form-urlencoded'}
						data = 'g-recaptcha-response='+dh1veN6mVBg7pQ
						RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'POST',HI1YDpJ6SZ5APuNrC7OV9tzf,data,headers,False,'','RESOLVERS-BYPASS_AKWAM_CAPTCHA-6th')
						KIbodwB39AMh0CrHDNlesW = RoQL91PphqCJg4W0e6Fnsl.content
						try: cookies = RoQL91PphqCJg4W0e6Fnsl.cookies
						except: cookies = {}
						nPyDXYcrhVFQflZe3q = u5h2Rckvw1E.findall("'(akwamVerification.*?)': '(.*?)'",str(cookies),u5h2Rckvw1E.DOTALL)
			if nPyDXYcrhVFQflZe3q:
				WGy8jZubInXc7zRBJ5p,nPyDXYcrhVFQflZe3q = nPyDXYcrhVFQflZe3q[0]
				hTijEO6kvoWQCJp = WGy8jZubInXc7zRBJ5p+'='+nPyDXYcrhVFQflZe3q
				LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting('av.akwam.verification',hTijEO6kvoWQCJp)
				xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','نجحت عملية فحص أنا إنسان .. وقام البرنامج بخزن نتائج هذا الفحص لكي يستخدمها لاحقا .. ولا توجد حاجة لإعادة هذا الفحص لعدة أشهر \n\n علما أن هذا الفحص سوف يتكرر في حالة تغير ربط الجهاز بالإنترنت .. أو إطفاء راوتر الإنترنت .. أو فصل سلك الراوتر .. أو استخدام VPN أو بروكسي')
				if '.mp4' not in KIbodwB39AMh0CrHDNlesW:
					headers = {'Cookie':hTijEO6kvoWQCJp}
					RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',UBLWuYCQ4TofptSnjv6V2sNRZ,'',headers,'','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-7th')
					KIbodwB39AMh0CrHDNlesW = RoQL91PphqCJg4W0e6Fnsl.content
	if not Hxpd2wePZUyLtJk1hm and not hTijEO6kvoWQCJp: xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','فشلت عملية فحص أنا أنسان .. حاول إعادة العملية مرة أخرى باستخدام نفس الفيديو أو فيديو غيره من نفس الموقع')
	return KIbodwB39AMh0CrHDNlesW
def Jn5W8Lt2m3(url,type,ohAHUqdbWFi8D1L4Xwzus0f3RYv):
	GnuaoT9MxiCg,kPpGr0QERz4tyh3C = [],[]
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',url,'','','','','RESOLVERS-AKWAM-1st')
	ZCOosjaQ8x9HDKSVGM6LwW2vy = RoQL91PphqCJg4W0e6Fnsl.content
	ppZ9muD1GkPnFRX52jxBUIy = u5h2Rckvw1E.findall('<a href=".*?</a>',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)
	for lmO2YJGr6tCV in ppZ9muD1GkPnFRX52jxBUIy:
		lQUf3AY258LeWch = u5h2Rckvw1E.findall('href="(http.*?)".*?<span.*?">(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in lQUf3AY258LeWch:
			if ekTrZlFMu0Kf5QztEnhAs in GnuaoT9MxiCg: continue
			if '/watch/' not in ekTrZlFMu0Kf5QztEnhAs and '/download/' not in ekTrZlFMu0Kf5QztEnhAs: continue
			title = title.replace('</span>','').replace(' - ','').strip(' ').replace('  ',' ')
			GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs)
			kPpGr0QERz4tyh3C.append(title)
	if len(GnuaoT9MxiCg)>1:
		u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = tYysxJLreEBDdXMIjz4OPa('بعضها يحتاج 60 ثانية',kPpGr0QERz4tyh3C)
		if u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo==-1: return 'Error: Resolver Canceled AKWAM',[],[]
	elif len(GnuaoT9MxiCg)==1: u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = 0
	else: return 'Error: Resolver Failed AKWAM',[],[]
	UBLWuYCQ4TofptSnjv6V2sNRZ = GnuaoT9MxiCg[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
	KIbodwB39AMh0CrHDNlesW = R3RaECkpTbMDln45d2Vrq(UBLWuYCQ4TofptSnjv6V2sNRZ)
	EaBeVhOsHYg8wub,hVby8e3aQkFfuE = [],[]
	if type=='download':
		CVsNp7iIE3dvM = u5h2Rckvw1E.findall('btn-loader.*?href="(.*?)"',KIbodwB39AMh0CrHDNlesW,u5h2Rckvw1E.DOTALL)
		if CVsNp7iIE3dvM:
			ekTrZlFMu0Kf5QztEnhAs = P2o6ZDHeW790pSQqucvnxzILVUX(CVsNp7iIE3dvM[0])
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
			hVby8e3aQkFfuE.append(ohAHUqdbWFi8D1L4Xwzus0f3RYv)
	elif type=='watch':
		lQUf3AY258LeWch = u5h2Rckvw1E.findall('<source.*?src="(.*?)".*?size="(.*?)"',KIbodwB39AMh0CrHDNlesW,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,size in lQUf3AY258LeWch:
			if not ekTrZlFMu0Kf5QztEnhAs: continue
			if ohAHUqdbWFi8D1L4Xwzus0f3RYv in size:
				hVby8e3aQkFfuE.append(size)
				EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
				break
		if not EaBeVhOsHYg8wub:
			for ekTrZlFMu0Kf5QztEnhAs,size in lQUf3AY258LeWch:
				if not ekTrZlFMu0Kf5QztEnhAs: continue
				hVby8e3aQkFfuE.append(size)
				EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	if not EaBeVhOsHYg8wub: return 'Error: Resolver Failed AKWAM',[],[]
	return '',hVby8e3aQkFfuE,EaBeVhOsHYg8wub
def EnzcoUOKkg(url,WGy8jZubInXc7zRBJ5p):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','',True,'','RESOLVERS-AKOAM-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cookies = RoQL91PphqCJg4W0e6Fnsl.cookies
	if 'golink' in list(cookies.keys()):
		hTijEO6kvoWQCJp = cookies['golink']
		hTijEO6kvoWQCJp = P2o6ZDHeW790pSQqucvnxzILVUX(ffbxegm1XPSqIwp8i(hTijEO6kvoWQCJp))
		items = u5h2Rckvw1E.findall('route":"(.*?)"',hTijEO6kvoWQCJp,u5h2Rckvw1E.DOTALL)
		gANn35esloKUydOipfSMC6RD2 = items[0].replace('\/','/')
		gANn35esloKUydOipfSMC6RD2 = ffbxegm1XPSqIwp8i(gANn35esloKUydOipfSMC6RD2)
	else: gANn35esloKUydOipfSMC6RD2 = url
	if 'catch.is' in gANn35esloKUydOipfSMC6RD2:
		id = gANn35esloKUydOipfSMC6RD2.split('%2F')[-1]
		gANn35esloKUydOipfSMC6RD2 = 'http://catch.is/'+id
		return 'NEED_EXTERNAL_RESOLVERS',[''],[gANn35esloKUydOipfSMC6RD2]
	else:
		website = pgPfwZleTHVQ9a['AKOAM'][0]
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',website,'','',True,'','RESOLVERS-AKOAM-2nd')
		PMtgKDNH6fZ2Qsh1 = RoQL91PphqCJg4W0e6Fnsl.url
		S94hBnyK68ulztjTeJfAk3i5YrU1 = gANn35esloKUydOipfSMC6RD2.split('/')[2]
		DD27qeNBvp = PMtgKDNH6fZ2Qsh1.split('/')[2]
		UcmHDPlLWaSf = gANn35esloKUydOipfSMC6RD2.replace(S94hBnyK68ulztjTeJfAk3i5YrU1,DD27qeNBvp)
		headers = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' , 'Referer':UcmHDPlLWaSf }
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'POST', UcmHDPlLWaSf, '', headers, False,'','RESOLVERS-AKOAM-3rd')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		items = u5h2Rckvw1E.findall('direct_link":"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.IGNORECASE)
		if not items:
			items = u5h2Rckvw1E.findall('<iframe.*?src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.IGNORECASE)
			if not items:
				items = u5h2Rckvw1E.findall('<embed.*?src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.IGNORECASE)
		if items:
			ekTrZlFMu0Kf5QztEnhAs = items[0].replace('\/','/')
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.rstrip('/')
			if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = 'http:' + ekTrZlFMu0Kf5QztEnhAs
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.replace('http://','https://')
			if WGy8jZubInXc7zRBJ5p=='': ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = '',[''],[ekTrZlFMu0Kf5QztEnhAs]
			else: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = 'NEED_EXTERNAL_RESOLVERS',[''],[ekTrZlFMu0Kf5QztEnhAs]
		else: ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = 'Error: Resolver Failed AKOAM',[],[]
		return ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub
def nnBd54cZaIeCb1Krl(url):
	headers = { 'User-Agent' : '' }
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(hs8IDEMn0YuCHwk,url,'',headers,'','RESOLVERS-RAPIDVIDEO-1st')
	items = u5h2Rckvw1E.findall('<source src="(.*?)".*?label="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	hVby8e3aQkFfuE,EaBeVhOsHYg8wub,errno = [],[],''
	if items:
		for ekTrZlFMu0Kf5QztEnhAs,eDvzfWdXZnlMEiboY5j1P in items:
			hVby8e3aQkFfuE.append(eDvzfWdXZnlMEiboY5j1P)
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	if len(EaBeVhOsHYg8wub)==0: return 'Error: Resolver Failed RAPIDVIDEO',[],[]
	return '',hVby8e3aQkFfuE,EaBeVhOsHYg8wub
def SCg9BVyhGKv0olU7T(url):
	headers = {'User-Agent':''}
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(hs8IDEMn0YuCHwk,url,'',headers,'','RESOLVERS-UQLOAD-1st')
	items = u5h2Rckvw1E.findall('sources: \["(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if items:
		url = items[0]+'|Referer='+url
		return '',[''],[url]
	else: return 'Error: Resolver Failed UQLOAD',[],[]
def hqekIf7CB4twRPM6bEcYylQH9D8Z(url):
	url = url.strip('/')
	if '/embed/' in url: id = url.split('/')[4]
	else: id = url.split('/')[-1]
	url = 'https://vcstream.to/player?fid=' + id
	headers = { 'User-Agent' : '' }
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(hs8IDEMn0YuCHwk,url,'',headers,'','RESOLVERS-VCSTREAM-1st')
	oo9SgGkiDbs3HRn7z8 = oo9SgGkiDbs3HRn7z8.replace('\\','')
	items = u5h2Rckvw1E.findall('file":"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if items: return '',[''],[ items[0] ]
	else: return 'Error: Resolver Failed VCSTREAM',[],[]
def uaGq6Qcv3RAyTrm4dHLejfl9on(url):
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(hs8IDEMn0YuCHwk,url,'','','','RESOLVERS-VIDOZA-1st')
	items = u5h2Rckvw1E.findall('src: "(.*?)".*?label:"(.*?)", res:"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	hVby8e3aQkFfuE,EaBeVhOsHYg8wub = [],[]
	for ekTrZlFMu0Kf5QztEnhAs,eDvzfWdXZnlMEiboY5j1P,RpaTdKDBzjvIX7kQ6GuFMyH in items:
		hVby8e3aQkFfuE.append(eDvzfWdXZnlMEiboY5j1P+' '+RpaTdKDBzjvIX7kQ6GuFMyH)
		EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	if len(EaBeVhOsHYg8wub)==0: return 'Error: Resolver Failed VIDOZA',[],[]
	return '',hVby8e3aQkFfuE,EaBeVhOsHYg8wub
def tIZpFGWquaD3gXVCz1869edKUJM(url):
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(hs8IDEMn0YuCHwk,url,'','','','RESOLVERS-WATCHVIDEO-1st')
	items = u5h2Rckvw1E.findall("download_video\('(.*?)','(.*?)','(.*?)'\)\">(.*?)</a>.*?<td>(.*?),.*?</td>",oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	items = set(items)
	hVby8e3aQkFfuE,EaBeVhOsHYg8wub = [],[]
	for id,wMCm6g9qFyPT0xpneDUNc2lEhaZY,hash,eDvzfWdXZnlMEiboY5j1P,RpaTdKDBzjvIX7kQ6GuFMyH in items:
		url = 'https://watchvideo.us/dl?op=download_orig&id='+id+'&mode='+wMCm6g9qFyPT0xpneDUNc2lEhaZY+'&hash='+hash
		oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(hs8IDEMn0YuCHwk,url,'','','','RESOLVERS-WATCHVIDEO-2nd')
		items = u5h2Rckvw1E.findall('direct link.*?href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs in items:
			hVby8e3aQkFfuE.append(eDvzfWdXZnlMEiboY5j1P+' '+RpaTdKDBzjvIX7kQ6GuFMyH)
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	if len(EaBeVhOsHYg8wub)==0: return 'Error: Resolver Failed WATCHVIDEO',[],[]
	return '',hVby8e3aQkFfuE,EaBeVhOsHYg8wub
def cvdiB9kzt3xW0NJ6joa1LS(url):
	ekTrZlFMu0Kf5QztEnhAs = ''
	if 1 or 'Key=' not in url:
		gANn35esloKUydOipfSMC6RD2 = url.replace('upbom.live','uppom.live')
		gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2.split('/')
		id = gANn35esloKUydOipfSMC6RD2[3]
		gANn35esloKUydOipfSMC6RD2 = '/'.join(gANn35esloKUydOipfSMC6RD2[0:4])
		nD70jhRb8C9Gi = {'id':id,'op':'download2','method_free':'Free+Download+%3E%3E'}
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'POST',gANn35esloKUydOipfSMC6RD2,nD70jhRb8C9Gi,'','','','RESOLVERS-UPBOM-1st')
		if 'Location' in list(RoQL91PphqCJg4W0e6Fnsl.headers.keys()): ekTrZlFMu0Kf5QztEnhAs = RoQL91PphqCJg4W0e6Fnsl.headers['Location']
		if not ekTrZlFMu0Kf5QztEnhAs and RoQL91PphqCJg4W0e6Fnsl.succeeded:
			oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
			ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('id="direct_link".*?href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
			if ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs[0]
	else:
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',url,'','','','','RESOLVERS-UPBOM-2nd')
		if 'location' in list(RoQL91PphqCJg4W0e6Fnsl.headers.keys()): ekTrZlFMu0Kf5QztEnhAs = RoQL91PphqCJg4W0e6Fnsl.headers['location']
	if ekTrZlFMu0Kf5QztEnhAs: return '',[''],[ekTrZlFMu0Kf5QztEnhAs]
	return 'Error: Resolver Failed UPBOM',[],[]
def rwT3HU7odyYm5F9Vi82CWA(url):
	headers = { 'User-Agent' : '' }
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(hs8IDEMn0YuCHwk,url,'',headers,'','RESOLVERS-LIIVIDEO-1st')
	items = u5h2Rckvw1E.findall('sources:.*?"(.*?)","(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	hVby8e3aQkFfuE,EaBeVhOsHYg8wub = [],[]
	if items:
		hVby8e3aQkFfuE.append('mp4')
		EaBeVhOsHYg8wub.append(items[0][1])
		hVby8e3aQkFfuE.append('m3u8')
		EaBeVhOsHYg8wub.append(items[0][0])
		return '',hVby8e3aQkFfuE,EaBeVhOsHYg8wub
	else: return 'Error: Resolver Failed LIIVIDEO',[],[]
def bFeRWshMkt(url):
	id = url.split('/')[-1]
	id = id.split('&')[0]
	id = id.replace('watch?v=','')
	gANn35esloKUydOipfSMC6RD2 = pgPfwZleTHVQ9a['YOUTUBE'][0]+'/watch?v='+id
	CXLlPMJSpD2BcYeUQK9htHys = 'http://youtu.be/'+id
	AcQYKlxVJarHsWoGCzNUjO,UrZC6JMyNXxl,hxGgAjyZn18sz36VkbUr,jjaiDCSKceWOkEI9oRTZJgzB = '','','',''
	for k0G4LTYt93po in range(5):
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'GET',gANn35esloKUydOipfSMC6RD2,'','','','','RESOLVERS-YOUTUBE-1st')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		if 'itag' in oo9SgGkiDbs3HRn7z8: break
		YVJPFvuI2CS5KObiZt.sleep(2)
	p30JfYmwhcv = u5h2Rckvw1E.findall('var ytInitialPlayerResponse = (.*?);</script>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if p30JfYmwhcv: p30JfYmwhcv = p30JfYmwhcv[0]
	else: p30JfYmwhcv = oo9SgGkiDbs3HRn7z8
	p30JfYmwhcv = p30JfYmwhcv.replace('\\u0026','&')
	LLcxBD1tpquzVm2oC8kdWaZvP5rAG = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('dict',p30JfYmwhcv)
	hVby8e3aQkFfuE,EaBeVhOsHYg8wub = ['بدون ترجمة يوتيوب'],['']
	try:
		e4G2HckAF8yYKd5tzrEVLI1 = LLcxBD1tpquzVm2oC8kdWaZvP5rAG['captions']['playerCaptionsTracklistRenderer']['captionTracks']
		for rNfPg3BuAK6Sw4Ldt2FUX1 in e4G2HckAF8yYKd5tzrEVLI1:
			ekTrZlFMu0Kf5QztEnhAs = rNfPg3BuAK6Sw4Ldt2FUX1['baseUrl']
			try: title = rNfPg3BuAK6Sw4Ldt2FUX1['name']['simpleText']
			except: title = rNfPg3BuAK6Sw4Ldt2FUX1['name']['runs'][0]['textt']
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
			hVby8e3aQkFfuE.append(title)
	except: pass
	if len(hVby8e3aQkFfuE)>1:
		u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = tYysxJLreEBDdXMIjz4OPa('اختر الترجمة المناسبة:', hVby8e3aQkFfuE)
		if u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo==-1: return 'EXIT_RESOLVER',[],[]
		elif u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo!=0:
			ekTrZlFMu0Kf5QztEnhAs = EaBeVhOsHYg8wub[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]+'&'
			yp6ErgkmHquUxn1O7AJwPB3hM = u5h2Rckvw1E.findall('&(fmt=.*?)&',ekTrZlFMu0Kf5QztEnhAs)
			if yp6ErgkmHquUxn1O7AJwPB3hM: ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.replace(yp6ErgkmHquUxn1O7AJwPB3hM[0],'fmt=vtt')
			else: ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'fmt=vtt'
			AcQYKlxVJarHsWoGCzNUjO = ekTrZlFMu0Kf5QztEnhAs.strip('&')
	LLx7iXgZStf,eHPUvCVInR3aJzb5xLYSl47o,Q4kXc25p3uyCdUB7zTJqe,PyFC75xLzB2pGJbeH,tM43LZJa17 = [],[],[],[],[]
	try: UrZC6JMyNXxl = LLcxBD1tpquzVm2oC8kdWaZvP5rAG['streamingData']['dashManifestUrl']
	except: pass
	try: hxGgAjyZn18sz36VkbUr = LLcxBD1tpquzVm2oC8kdWaZvP5rAG['streamingData']['hlsManifestUrl']
	except: pass
	try: LLx7iXgZStf = LLcxBD1tpquzVm2oC8kdWaZvP5rAG['streamingData']['formats']
	except: pass
	try: eHPUvCVInR3aJzb5xLYSl47o = LLcxBD1tpquzVm2oC8kdWaZvP5rAG['streamingData']['adaptiveFormats']
	except: pass
	al7jFnhTqfcYt6s = LLx7iXgZStf+eHPUvCVInR3aJzb5xLYSl47o
	for dict in al7jFnhTqfcYt6s:
		if 'itag' in list(dict.keys()): dict['itag'] = str(dict['itag'])
		if 'fps' in list(dict.keys()): dict['fps'] = str(dict['fps'])
		if 'mimeType' in list(dict.keys()): dict['type'] = dict['mimeType']
		if 'audioSampleRate' in list(dict.keys()): dict['audio_sample_rate'] = str(dict['audioSampleRate'])
		if 'audioChannels' in list(dict.keys()): dict['audio_channels'] = str(dict['audioChannels'])
		if 'width' in list(dict.keys()): dict['size'] = str(dict['width'])+'x'+str(dict['height'])
		if 'initRange' in list(dict.keys()): dict['init'] = dict['initRange']['start']+'-'+dict['initRange']['end']
		if 'indexRange' in list(dict.keys()): dict['index'] = dict['indexRange']['start']+'-'+dict['indexRange']['end']
		if 'averageBitrate' in list(dict.keys()): dict['bitrate'] = dict['averageBitrate']
		if 'bitrate' in list(dict.keys()) and int(dict['bitrate'])>111222333: del dict['bitrate']
		if 'signatureCipher' in list(dict.keys()):
			gNbeWIPR6nCTQkXVBDScE0mJv = dict['signatureCipher'].split('&')
			for TMaJdc0xOFKNf in gNbeWIPR6nCTQkXVBDScE0mJv:
				key,c2eEflztvIX = TMaJdc0xOFKNf.split('=',1)
				dict[key] = P2o6ZDHeW790pSQqucvnxzILVUX(c2eEflztvIX)
		if 'url' in list(dict.keys()): dict['url'] = P2o6ZDHeW790pSQqucvnxzILVUX(dict['url'])
		Q4kXc25p3uyCdUB7zTJqe.append(dict)
	F6FPo5twUOzMC = ''
	if 'sp=sig' in p30JfYmwhcv:
		rL3N8wSc4avnxg = u5h2Rckvw1E.findall('src="(/s/player/\w*?/player_ias.vflset/en_../base.js)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if rL3N8wSc4avnxg:
			rL3N8wSc4avnxg = pgPfwZleTHVQ9a['YOUTUBE'][0]+rL3N8wSc4avnxg[0]
			RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'GET',rL3N8wSc4avnxg,'','','','','RESOLVERS-YOUTUBE-2nd')
			F6FPo5twUOzMC = RoQL91PphqCJg4W0e6Fnsl.content
			import youtube_signature.cipher as O6EHpioNacL8xhkVtP1Qy7m,youtube_signature.json_script_engine as wjm9QOb4GrA0tqRFIHPiphaCx
			gNbeWIPR6nCTQkXVBDScE0mJv = SczUaHrOge3f.gNbeWIPR6nCTQkXVBDScE0mJv.Cipher()
			gNbeWIPR6nCTQkXVBDScE0mJv._object_cache = {}
			acGsvrnVb5lU17Kih6Yt8 = gNbeWIPR6nCTQkXVBDScE0mJv._load_javascript(F6FPo5twUOzMC)
			OGo6rSezvLq = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('str',str(acGsvrnVb5lU17Kih6Yt8))
			erQxOu0K1yDnXEF8 = SczUaHrOge3f.MAvjHGibKU9ns6dLPph.JsonScriptEngine(OGo6rSezvLq)
	for dict in Q4kXc25p3uyCdUB7zTJqe:
		url = dict['url']
		if 'signature=' in url or url.count('sig=')>1:
			PyFC75xLzB2pGJbeH.append(dict)
		elif F6FPo5twUOzMC and 's' in list(dict.keys()) and 'sp' in list(dict.keys()):
			BiHJvwC3DKqzAMpbIWXjOre = erQxOu0K1yDnXEF8.execute(dict['s'])
			if BiHJvwC3DKqzAMpbIWXjOre!=dict['s']:
				dict['url'] = url+'&'+dict['sp']+'='+BiHJvwC3DKqzAMpbIWXjOre
				PyFC75xLzB2pGJbeH.append(dict)
	for dict in PyFC75xLzB2pGJbeH:
		GvoaR8HMyTDxF0fz5cwu1JnSNWP,DoE3yqwaQNxvtJ290rmO4kY,hINtAnWkVKdRpPvZzf0r3SLwEc4iD1,v6YLr90gxdTVfyG83J1XAzjiF,LKt8I9Vor1,pClJ13jXB4NmPg0WsHI = 'unknown','unknown','unknown','Unknown','','0'
		try:
			wUzCxarKm9nRSXcqv5W0bGHhLI3y = dict['type']
			wUzCxarKm9nRSXcqv5W0bGHhLI3y = wUzCxarKm9nRSXcqv5W0bGHhLI3y.replace('+','')
			items = u5h2Rckvw1E.findall('(.*?)/(.*?);.*?"(.*?)"',wUzCxarKm9nRSXcqv5W0bGHhLI3y,u5h2Rckvw1E.DOTALL)
			v6YLr90gxdTVfyG83J1XAzjiF,GvoaR8HMyTDxF0fz5cwu1JnSNWP,LKt8I9Vor1 = items[0]
			Tyvd0B9LoU7G6Mh = LKt8I9Vor1.split(',')
			DoE3yqwaQNxvtJ290rmO4kY = ''
			for TMaJdc0xOFKNf in Tyvd0B9LoU7G6Mh: DoE3yqwaQNxvtJ290rmO4kY += TMaJdc0xOFKNf.split('.')[0]+','
			DoE3yqwaQNxvtJ290rmO4kY = DoE3yqwaQNxvtJ290rmO4kY.strip(',')
			if 'bitrate' in list(dict.keys()): pClJ13jXB4NmPg0WsHI = str(float(dict['bitrate']*10)//1024/10)+'kbps  '
			else: pClJ13jXB4NmPg0WsHI = ''
			if v6YLr90gxdTVfyG83J1XAzjiF=='textt': continue
			elif ',' in wUzCxarKm9nRSXcqv5W0bGHhLI3y:
				v6YLr90gxdTVfyG83J1XAzjiF = 'A+V'
				hINtAnWkVKdRpPvZzf0r3SLwEc4iD1 = GvoaR8HMyTDxF0fz5cwu1JnSNWP+'  '+pClJ13jXB4NmPg0WsHI+dict['size'].split('x')[1]
			elif v6YLr90gxdTVfyG83J1XAzjiF=='video':
				v6YLr90gxdTVfyG83J1XAzjiF = 'Video'
				hINtAnWkVKdRpPvZzf0r3SLwEc4iD1 = pClJ13jXB4NmPg0WsHI+dict['size'].split('x')[1]+'  '+dict['fps']+'fps'+'  '+GvoaR8HMyTDxF0fz5cwu1JnSNWP
			elif v6YLr90gxdTVfyG83J1XAzjiF=='audio':
				v6YLr90gxdTVfyG83J1XAzjiF = 'Audio'
				hINtAnWkVKdRpPvZzf0r3SLwEc4iD1 = pClJ13jXB4NmPg0WsHI+str(int(dict['audio_sample_rate'])/1000)+'khz  '+dict['audio_channels']+'ch'+'  '+GvoaR8HMyTDxF0fz5cwu1JnSNWP
		except:
			LdvB61qxSDsOWlhmXnAgozEfPp4Ky = BPSEU6WvQRnxV.format_exc()
			if LdvB61qxSDsOWlhmXnAgozEfPp4Ky!='NoneType: None\n': vdo2FnhPmAVRMJQZ0EIG8.stderr.write(LdvB61qxSDsOWlhmXnAgozEfPp4Ky)
		if 'dur=' in dict['url']: vNbeHULAy6gc4iE = round(0.5+float(dict['url'].split('dur=',1)[1].split('&',1)[0]))
		elif 'approxDurationMs' in list(dict.keys()): vNbeHULAy6gc4iE = round(0.5+float(dict['approxDurationMs'])/1000)
		else: vNbeHULAy6gc4iE = '0'
		if 'bitrate' not in list(dict.keys()): pClJ13jXB4NmPg0WsHI = dict['size'].split('x')[1]
		else: pClJ13jXB4NmPg0WsHI = dict['bitrate']
		if 'init' not in list(dict.keys()): dict['init'] = '0-0'
		dict['title'] = v6YLr90gxdTVfyG83J1XAzjiF+':  '+hINtAnWkVKdRpPvZzf0r3SLwEc4iD1+'  ('+DoE3yqwaQNxvtJ290rmO4kY+','+dict['itag']+')'
		dict['quality'] = hINtAnWkVKdRpPvZzf0r3SLwEc4iD1.split('  ')[0].split('kbps')[0]
		dict['type2'] = v6YLr90gxdTVfyG83J1XAzjiF
		dict['filetype'] = GvoaR8HMyTDxF0fz5cwu1JnSNWP
		dict['codecs'] = LKt8I9Vor1
		dict['duration'] = vNbeHULAy6gc4iE
		dict['bitrate'] = pClJ13jXB4NmPg0WsHI
		tM43LZJa17.append(dict)
	U3O5CuQbZteIv0l1oMqSRxjEwsTD2m,liFA5a8Q6xDTRBI,weSM3k8bTPif9ZVF2Kj,L5CPGDel8kTBI,QQP0fEn3M8p9eLWaj2rkCZlcbiqI = [],[],[],[],[]
	Q5QErbuAWRmKytITp8sVUPCH,iiG1FENMAmRO3cDoYyv2zq,KX687UlGSanTIsm,DOE9SMkJbveBmAoVqH7ZWzfP1gdrp,QQSYAE8bF91Hi7DR4UM = [],[],[],[],[]
	if UrZC6JMyNXxl:
		dict = {}
		dict['type2'] = 'A+V'
		dict['filetype'] = 'mpd'
		dict['title'] = dict['type2']+':  '+dict['filetype']+'  '+'جودة ذكية'
		dict['url'] = UrZC6JMyNXxl
		dict['quality'] = '0'
		dict['bitrate'] = '9876543210'
		tM43LZJa17.append(dict)
	if hxGgAjyZn18sz36VkbUr:
		Z5FySkDLAlm,aaybUwAWp2NGnesRYcFqBfkd = bkz2aCFLpWqGUcPolSXA980O(hxGgAjyZn18sz36VkbUr)
		WYrBEJtzeQ6xc = list(zip(Z5FySkDLAlm,aaybUwAWp2NGnesRYcFqBfkd))
		for title,ekTrZlFMu0Kf5QztEnhAs in WYrBEJtzeQ6xc:
			dict = {}
			dict['type2'] = 'A+V'
			dict['filetype'] = 'm3u8'
			dict['url'] = ekTrZlFMu0Kf5QztEnhAs
			if 'kbps' in title: dict['bitrate'] = title.split('kbps')[0].rsplit('  ')[-1]
			else: dict['bitrate'] = '10'
			if title.count('  ')>1:
				ohAHUqdbWFi8D1L4Xwzus0f3RYv = title.rsplit('  ')[-3]
				if ohAHUqdbWFi8D1L4Xwzus0f3RYv.isdigit(): dict['quality'] = ohAHUqdbWFi8D1L4Xwzus0f3RYv
				else: dict['quality'] = '0000'
			if title=='-1': dict['title'] = dict['type2']+':  '+dict['filetype']+'  '+'جودة ذكية'
			else: dict['title'] = dict['type2']+':  '+dict['filetype']+'  '+dict['bitrate']+'kbps  '+dict['quality']
			tM43LZJa17.append(dict)
	tM43LZJa17 = sorted(tM43LZJa17,reverse=True,key=lambda key: float(key['bitrate']))
	if not tM43LZJa17:
		cLzOaV56rHkXKmxCy = u5h2Rckvw1E.findall('class="messagee">(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		Yw6S1bOqLcECfji7RJetgD = u5h2Rckvw1E.findall('"playerErrorMessageRenderer":\{"subreason":\{"runs":\[\{"textt":"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		H48QNMCzRXUI1eioTPunZFEdYsG = u5h2Rckvw1E.findall('"playerErrorMessageRenderer":\{"reason":{"simpleText":"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		HDP1ZJ2jWoQnTcAi = u5h2Rckvw1E.findall('"playerErrorMessageRenderer":\{"subreason":{"simpleText":"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		try: EDtgXhfrJ7CLjxGZl0Ak9wevUN5 = LLcxBD1tpquzVm2oC8kdWaZvP5rAG['playabilityStatus']['errorScreen']['confirmDialogRenderer']['title']['runs'][0]['textt']
		except: EDtgXhfrJ7CLjxGZl0Ak9wevUN5 = ''
		try: DxJFHoOwmyBR = LLcxBD1tpquzVm2oC8kdWaZvP5rAG['playabilityStatus']['errorScreen']['confirmDialogRenderer']['dialogMessages'][0]['runs'][0]['textt']
		except: DxJFHoOwmyBR = ''
		try: SClFymDvZtU = LLcxBD1tpquzVm2oC8kdWaZvP5rAG['playabilityStatus']['reason']
		except: SClFymDvZtU = ''
		if cLzOaV56rHkXKmxCy or Yw6S1bOqLcECfji7RJetgD or H48QNMCzRXUI1eioTPunZFEdYsG or HDP1ZJ2jWoQnTcAi or EDtgXhfrJ7CLjxGZl0Ak9wevUN5 or DxJFHoOwmyBR or SClFymDvZtU:
			if   cLzOaV56rHkXKmxCy: MLPwxur5kaYlBtqcn = cLzOaV56rHkXKmxCy[0]
			elif Yw6S1bOqLcECfji7RJetgD: MLPwxur5kaYlBtqcn = Yw6S1bOqLcECfji7RJetgD[0]
			elif H48QNMCzRXUI1eioTPunZFEdYsG: MLPwxur5kaYlBtqcn = H48QNMCzRXUI1eioTPunZFEdYsG[0]
			elif HDP1ZJ2jWoQnTcAi: MLPwxur5kaYlBtqcn = HDP1ZJ2jWoQnTcAi[0]
			elif EDtgXhfrJ7CLjxGZl0Ak9wevUN5: MLPwxur5kaYlBtqcn = EDtgXhfrJ7CLjxGZl0Ak9wevUN5
			elif DxJFHoOwmyBR: MLPwxur5kaYlBtqcn = DxJFHoOwmyBR
			elif SClFymDvZtU: MLPwxur5kaYlBtqcn = SClFymDvZtU
			D07vijwdoeJXLhTluz9nBW = MLPwxur5kaYlBtqcn.replace('\n','').strip(' ')
			yfYmXD6ABQ28TNFopL4G = '[COLOR FFC89008]هذا الفيديو فيه مشكلة وقد يكون غير ملائم لبعض المستخدمين أو غير متوفر الآن[/COLOR]'
			xl9MFt1AmY0GrkENug8n('','','رسالة من الموقع والمبرمج',yfYmXD6ABQ28TNFopL4G+'\n\n'+D07vijwdoeJXLhTluz9nBW)
			return 'Error    : Resolver YOUTUBE Failed: '+D07vijwdoeJXLhTluz9nBW,[],[]
		else: return 'Error    : Resolver YOUTUBE Failed',[],[]
	gYld1oZ9WLiOu4TR0aKw2rsbvzM,pRgFvuDtbQaiJUYP7S96Z1H,SIokzNw57Hq2RJAW = [],[],[]
	for dict in tM43LZJa17:
		if dict['type2']=='Video':
			U3O5CuQbZteIv0l1oMqSRxjEwsTD2m.append(dict['title'])
			Q5QErbuAWRmKytITp8sVUPCH.append(dict)
		elif dict['type2']=='Audio':
			liFA5a8Q6xDTRBI.append(dict['title'])
			iiG1FENMAmRO3cDoYyv2zq.append(dict)
		elif dict['filetype']=='mpd':
			title = dict['title'].replace('A+V:  ','')
			if 'bitrate' not in list(dict.keys()): pClJ13jXB4NmPg0WsHI = '0'
			else: pClJ13jXB4NmPg0WsHI = dict['bitrate']
			gYld1oZ9WLiOu4TR0aKw2rsbvzM.append([dict,{},title,pClJ13jXB4NmPg0WsHI])
		else:
			title = dict['title'].replace('A+V:  ','')
			if 'bitrate' not in list(dict.keys()): pClJ13jXB4NmPg0WsHI = '0'
			else: pClJ13jXB4NmPg0WsHI = dict['bitrate']
			gYld1oZ9WLiOu4TR0aKw2rsbvzM.append([dict,{},title,pClJ13jXB4NmPg0WsHI])
			weSM3k8bTPif9ZVF2Kj.append(title)
			KX687UlGSanTIsm.append(dict)
		rCjStnGusHleVm4fg0RcK = True
		if 'codecs' in list(dict.keys()):
			if 'av0' in dict['codecs']: rCjStnGusHleVm4fg0RcK = False
			elif njGgmsD1k7cE60drxHCyVh2YN3P<18:
				if 'avc' not in dict['codecs'] and 'mp4a' not in dict['codecs']: rCjStnGusHleVm4fg0RcK = False
		if dict['type2']=='Video' and dict['init']!='0-0' and rCjStnGusHleVm4fg0RcK==True:
			QQP0fEn3M8p9eLWaj2rkCZlcbiqI.append(dict['title'])
			QQSYAE8bF91Hi7DR4UM.append(dict)
		elif dict['type2']=='Audio' and dict['init']!='0-0' and rCjStnGusHleVm4fg0RcK==True:
			L5CPGDel8kTBI.append(dict['title'])
			DOE9SMkJbveBmAoVqH7ZWzfP1gdrp.append(dict)
	for oQdtHsR4Way8K in DOE9SMkJbveBmAoVqH7ZWzfP1gdrp:
		UfCWv4tsu8Q6rMZEGBR1b = oQdtHsR4Way8K['bitrate']
		for nnfdosTBDrz in QQSYAE8bF91Hi7DR4UM:
			ahQxeRmrT6dMEJPiFg2H1Xw5v = nnfdosTBDrz['bitrate']
			pClJ13jXB4NmPg0WsHI = ahQxeRmrT6dMEJPiFg2H1Xw5v+UfCWv4tsu8Q6rMZEGBR1b
			title = nnfdosTBDrz['title'].replace('Video:  ','mpd  ')
			title = title.replace(nnfdosTBDrz['filetype']+'  ','')
			title = title.replace(str((float(ahQxeRmrT6dMEJPiFg2H1Xw5v*10)//1024/10))+'kbps',str((float(pClJ13jXB4NmPg0WsHI*10)//1024/10))+'kbps')
			title = title+'('+oQdtHsR4Way8K['title'].split('(',1)[1]
			gYld1oZ9WLiOu4TR0aKw2rsbvzM.append([nnfdosTBDrz,oQdtHsR4Way8K,title,pClJ13jXB4NmPg0WsHI])
	gYld1oZ9WLiOu4TR0aKw2rsbvzM = sorted(gYld1oZ9WLiOu4TR0aKw2rsbvzM, reverse=True, key=lambda key: float(key[3]))
	for nnfdosTBDrz,oQdtHsR4Way8K,title,pClJ13jXB4NmPg0WsHI in gYld1oZ9WLiOu4TR0aKw2rsbvzM:
		m2u9GPxECziHQno14FSg86IJOTklY = nnfdosTBDrz['filetype']
		if 'filetype' in list(oQdtHsR4Way8K.keys()):
			m2u9GPxECziHQno14FSg86IJOTklY = 'mpd'
		if m2u9GPxECziHQno14FSg86IJOTklY not in SIokzNw57Hq2RJAW:
			SIokzNw57Hq2RJAW.append(m2u9GPxECziHQno14FSg86IJOTklY)
			pRgFvuDtbQaiJUYP7S96Z1H.append([nnfdosTBDrz,oQdtHsR4Way8K,title,pClJ13jXB4NmPg0WsHI])
	wwq4Cmgrsc,BY6qc5o8O3a29W,jckmqWyECDxJgbhzlVa1uX6LG23 = [],[],0
	MEhzjJF3SUWNPmtaviDTIKfqrAOux,uurqjQSzi3wYLtgJxp = '',''
	try: MEhzjJF3SUWNPmtaviDTIKfqrAOux = LLcxBD1tpquzVm2oC8kdWaZvP5rAG['videoDetails']['author']
	except: MEhzjJF3SUWNPmtaviDTIKfqrAOux = ''
	try: Ncz16oPVqn = LLcxBD1tpquzVm2oC8kdWaZvP5rAG['videoDetails']['channelId']
	except: Ncz16oPVqn = ''
	if MEhzjJF3SUWNPmtaviDTIKfqrAOux and Ncz16oPVqn:
		jckmqWyECDxJgbhzlVa1uX6LG23 += 1
		title = '[COLOR FFC89008]OWNER:  '+MEhzjJF3SUWNPmtaviDTIKfqrAOux+'[/COLOR]'
		ekTrZlFMu0Kf5QztEnhAs = pgPfwZleTHVQ9a['YOUTUBE'][0]+'/channel/'+Ncz16oPVqn
		wwq4Cmgrsc.append(title)
		BY6qc5o8O3a29W.append(ekTrZlFMu0Kf5QztEnhAs)
		try: uurqjQSzi3wYLtgJxp = LLcxBD1tpquzVm2oC8kdWaZvP5rAG['videoDetails']['thumbnail']['thumbnails'][-1]['url']
		except: pass
	for nnfdosTBDrz,oQdtHsR4Way8K,title,pClJ13jXB4NmPg0WsHI in pRgFvuDtbQaiJUYP7S96Z1H:
		wwq4Cmgrsc.append(title) ; BY6qc5o8O3a29W.append('highest')
	if weSM3k8bTPif9ZVF2Kj: wwq4Cmgrsc.append('صورة وصوت محددة') ; BY6qc5o8O3a29W.append('muxed')
	if gYld1oZ9WLiOu4TR0aKw2rsbvzM: wwq4Cmgrsc.append('صورة وصوت المتوفر') ; BY6qc5o8O3a29W.append('all')
	if QQP0fEn3M8p9eLWaj2rkCZlcbiqI: wwq4Cmgrsc.append('mpd اختر الصورة والصوت') ; BY6qc5o8O3a29W.append('mpd')
	if U3O5CuQbZteIv0l1oMqSRxjEwsTD2m: wwq4Cmgrsc.append('صورة بدون صوت') ; BY6qc5o8O3a29W.append('video')
	if liFA5a8Q6xDTRBI: wwq4Cmgrsc.append('صوت بدون صورة') ; BY6qc5o8O3a29W.append('audio')
	YUlVFPrLxbSW1ZdJpHmyG = False
	while True:
		u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = tYysxJLreEBDdXMIjz4OPa(CXLlPMJSpD2BcYeUQK9htHys, wwq4Cmgrsc)
		if u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo==-1: return 'EXIT_RESOLVER',[],[]
		elif u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo==0 and MEhzjJF3SUWNPmtaviDTIKfqrAOux:
			ekTrZlFMu0Kf5QztEnhAs = BY6qc5o8O3a29W[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
			HKf2QLIX3NVl94GDEJvmtoBr1dS = vdo2FnhPmAVRMJQZ0EIG8.argv[0]+'?type=folder&mode=141&name='+QQXTVNve6DMHBp4scG170kR2lWY(MEhzjJF3SUWNPmtaviDTIKfqrAOux)+'&url='+ekTrZlFMu0Kf5QztEnhAs
			if uurqjQSzi3wYLtgJxp: HKf2QLIX3NVl94GDEJvmtoBr1dS = HKf2QLIX3NVl94GDEJvmtoBr1dS+'&image='+QQXTVNve6DMHBp4scG170kR2lWY(uurqjQSzi3wYLtgJxp)
			bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin("Container.Update("+HKf2QLIX3NVl94GDEJvmtoBr1dS+")")
			return 'EXIT_RESOLVER',[],[]
		aZ06RtK7TfOop52BJg4 = BY6qc5o8O3a29W[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
		yyqg4Eh1K7ksmoHSTNirXpQGxfaeb = wwq4Cmgrsc[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
		if aZ06RtK7TfOop52BJg4=='dash':
			jjaiDCSKceWOkEI9oRTZJgzB = UrZC6JMyNXxl
			break
		elif aZ06RtK7TfOop52BJg4 in ['audio','video','muxed']:
			if aZ06RtK7TfOop52BJg4=='muxed': hVby8e3aQkFfuE,NL78SuckAs3PtzRV0vaiZBEf1MO = weSM3k8bTPif9ZVF2Kj,KX687UlGSanTIsm
			elif aZ06RtK7TfOop52BJg4=='video': hVby8e3aQkFfuE,NL78SuckAs3PtzRV0vaiZBEf1MO = U3O5CuQbZteIv0l1oMqSRxjEwsTD2m,Q5QErbuAWRmKytITp8sVUPCH
			elif aZ06RtK7TfOop52BJg4=='audio': hVby8e3aQkFfuE,NL78SuckAs3PtzRV0vaiZBEf1MO = liFA5a8Q6xDTRBI,iiG1FENMAmRO3cDoYyv2zq
			u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = tYysxJLreEBDdXMIjz4OPa('اختر الملف المناسب:', hVby8e3aQkFfuE)
			if u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo!=-1:
				jjaiDCSKceWOkEI9oRTZJgzB = NL78SuckAs3PtzRV0vaiZBEf1MO[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]['url']
				yyqg4Eh1K7ksmoHSTNirXpQGxfaeb = hVby8e3aQkFfuE[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
				break
		elif aZ06RtK7TfOop52BJg4=='mpd':
			u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = tYysxJLreEBDdXMIjz4OPa('اختر جودة الصورة:', QQP0fEn3M8p9eLWaj2rkCZlcbiqI)
			if u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo!=-1:
				yyqg4Eh1K7ksmoHSTNirXpQGxfaeb = QQP0fEn3M8p9eLWaj2rkCZlcbiqI[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
				vvipTNbXWQML8u79EnKgqG2OS = QQSYAE8bF91Hi7DR4UM[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
				u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = tYysxJLreEBDdXMIjz4OPa('اختر جودة الصوت:', L5CPGDel8kTBI)
				if u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo!=-1:
					yyqg4Eh1K7ksmoHSTNirXpQGxfaeb += ' + '+L5CPGDel8kTBI[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
					tZGqlXdcrsCv = DOE9SMkJbveBmAoVqH7ZWzfP1gdrp[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
					YUlVFPrLxbSW1ZdJpHmyG = True
					break
		elif aZ06RtK7TfOop52BJg4=='all':
			bAwhqnOrWec,TxhjWf7dvUV4Z,jCzKV7b6s5HxNkuLARwfemiUpE3J,iy0jwKtmb14 = list(zip(*gYld1oZ9WLiOu4TR0aKw2rsbvzM))
			u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = tYysxJLreEBDdXMIjz4OPa('اختر الملف المناسب:', jCzKV7b6s5HxNkuLARwfemiUpE3J)
			if u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo!=-1:
				yyqg4Eh1K7ksmoHSTNirXpQGxfaeb = jCzKV7b6s5HxNkuLARwfemiUpE3J[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
				vvipTNbXWQML8u79EnKgqG2OS = bAwhqnOrWec[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
				if 'mpd' in jCzKV7b6s5HxNkuLARwfemiUpE3J[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo] and vvipTNbXWQML8u79EnKgqG2OS['url']!=UrZC6JMyNXxl:
					tZGqlXdcrsCv = TxhjWf7dvUV4Z[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
					YUlVFPrLxbSW1ZdJpHmyG = True
				else: jjaiDCSKceWOkEI9oRTZJgzB = vvipTNbXWQML8u79EnKgqG2OS['url']
				break
		elif aZ06RtK7TfOop52BJg4=='highest':
			bAwhqnOrWec,TxhjWf7dvUV4Z,jCzKV7b6s5HxNkuLARwfemiUpE3J,iy0jwKtmb14 = list(zip(*pRgFvuDtbQaiJUYP7S96Z1H))
			vvipTNbXWQML8u79EnKgqG2OS = bAwhqnOrWec[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo-jckmqWyECDxJgbhzlVa1uX6LG23]
			if 'mpd' in jCzKV7b6s5HxNkuLARwfemiUpE3J[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo-jckmqWyECDxJgbhzlVa1uX6LG23] and vvipTNbXWQML8u79EnKgqG2OS['url']!=UrZC6JMyNXxl:
				tZGqlXdcrsCv = TxhjWf7dvUV4Z[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo-jckmqWyECDxJgbhzlVa1uX6LG23]
				YUlVFPrLxbSW1ZdJpHmyG = True
			else: jjaiDCSKceWOkEI9oRTZJgzB = vvipTNbXWQML8u79EnKgqG2OS['url']
			yyqg4Eh1K7ksmoHSTNirXpQGxfaeb = jCzKV7b6s5HxNkuLARwfemiUpE3J[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo-jckmqWyECDxJgbhzlVa1uX6LG23]
			break
	if not YUlVFPrLxbSW1ZdJpHmyG: CoxBFimO9Q = jjaiDCSKceWOkEI9oRTZJgzB
	else: CoxBFimO9Q = 'Video: '+vvipTNbXWQML8u79EnKgqG2OS['url']+' + Audio: '+tZGqlXdcrsCv['url']
	if YUlVFPrLxbSW1ZdJpHmyG:
		Q1YryDRLv7joce0XliHV = int(vvipTNbXWQML8u79EnKgqG2OS['duration'])
		XvFT1tmsJd = int(tZGqlXdcrsCv['duration'])
		vNbeHULAy6gc4iE = str(max(Q1YryDRLv7joce0XliHV,XvFT1tmsJd))
		zNBURoW04LpPX = vvipTNbXWQML8u79EnKgqG2OS['url'].replace('&','&amp;')
		H9ajF2Ieg43 = tZGqlXdcrsCv['url'].replace('&','&amp;')
		mpd = '<?xml version="1.0" encoding="UTF-8"?>\n'
		mpd += '<MPD xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="urn:mpeg:dash:schema:mpd:2011" xmlns:xlink="http://www.w3.org/1999/xlink" xsi:schemaLocation="urn:mpeg:dash:schema:mpd:2011 http://standards.iso.org/ittf/PubliclyAvailableStandards/MPEG-DASH_schema_files/DASH-MPD.xsd" minBufferTime="PT1.5S" mediaPresentationDuration="PT'+vNbeHULAy6gc4iE+'S" type="static" profiles="urn:mpeg:dash:profile:isoff-main:2011">\n'
		mpd += '<Period>\n'
		mpd += '<AdaptationSet id="0" mimeType="video/'+vvipTNbXWQML8u79EnKgqG2OS['filetype']+'" subsegmentAlignment="true">\n'
		mpd += '<Role schemeIdUri="urn:mpeg:DASH:role:2011" value="main"/>\n'
		mpd += '<Representation id="'+vvipTNbXWQML8u79EnKgqG2OS['itag']+'" codecs="'+vvipTNbXWQML8u79EnKgqG2OS['codecs']+'" startWithSAP="1" bandwidth="'+str(vvipTNbXWQML8u79EnKgqG2OS['bitrate'])+'" width="'+str(vvipTNbXWQML8u79EnKgqG2OS['width'])+'" height="'+str(vvipTNbXWQML8u79EnKgqG2OS['height'])+'" frameRate="'+vvipTNbXWQML8u79EnKgqG2OS['fps']+'">\n'
		mpd += '<BaseURL>'+zNBURoW04LpPX+'</BaseURL>\n'
		mpd += '<SegmentBase indexRange="'+vvipTNbXWQML8u79EnKgqG2OS['index']+'">\n'
		mpd += '<Initialization range="'+vvipTNbXWQML8u79EnKgqG2OS['init']+'" />\n'
		mpd += '</SegmentBase>\n'
		mpd += '</Representation>\n'
		mpd += '</AdaptationSet>\n'
		mpd += '<AdaptationSet id="1" mimeType="audio/'+tZGqlXdcrsCv['filetype']+'" subsegmentAlignment="true">\n'
		mpd += '<Role schemeIdUri="urn:mpeg:DASH:role:2011" value="main"/>\n'
		mpd += '<Representation id="'+tZGqlXdcrsCv['itag']+'" codecs="'+tZGqlXdcrsCv['codecs']+'" bandwidth="130475">\n'
		mpd += '<AudioChannelConfiguration schemeIdUri="urn:mpeg:dash:23003:3:audio_channel_configuration:2011" value="'+tZGqlXdcrsCv['audio_channels']+'"/>\n'
		mpd += '<BaseURL>'+H9ajF2Ieg43+'</BaseURL>\n'
		mpd += '<SegmentBase indexRange="'+tZGqlXdcrsCv['index']+'">\n'
		mpd += '<Initialization range="'+tZGqlXdcrsCv['init']+'" />\n'
		mpd += '</SegmentBase>\n'
		mpd += '</Representation>\n'
		mpd += '</AdaptationSet>\n'
		mpd += '</Period>\n'
		mpd += '</MPD>\n'
		if VVGRN7xiyj:
			import http.server as ECRiBQbszS8WpL
			import http.client as xIz1gYBcDXoLV9u6JSqfOF83AR0
		else:
			import BaseHTTPServer as ECRiBQbszS8WpL
			import httplib as xIz1gYBcDXoLV9u6JSqfOF83AR0
		class o4L9t6YhqarkPG183(ECRiBQbszS8WpL.HTTPServer):
			def __init__(hw0T9dumKLZOUkBgtJN,ip='localhost',port=55055,mpd='<>'):
				hw0T9dumKLZOUkBgtJN.ip = ip
				hw0T9dumKLZOUkBgtJN.port = port
				hw0T9dumKLZOUkBgtJN.mpd = mpd
				ECRiBQbszS8WpL.HTTPServer.__init__(hw0T9dumKLZOUkBgtJN,(hw0T9dumKLZOUkBgtJN.ip,hw0T9dumKLZOUkBgtJN.port),XkUq31CfnNFYoPOtB2mD0)
				hw0T9dumKLZOUkBgtJN.mpdurl = 'http://'+ip+':'+str(port)+'/youtube.mpd'
			def start(hw0T9dumKLZOUkBgtJN):
				hw0T9dumKLZOUkBgtJN.threads = NNdsp2w4g0ObWUVv7(False)
				hw0T9dumKLZOUkBgtJN.threads.H3bQD56wsB(1,hw0T9dumKLZOUkBgtJN.RRMbfupve4wcWroPCSKJG5ai720)
			def RRMbfupve4wcWroPCSKJG5ai720(hw0T9dumKLZOUkBgtJN):
				hw0T9dumKLZOUkBgtJN.keeprunning = True
				while hw0T9dumKLZOUkBgtJN.keeprunning:
					hw0T9dumKLZOUkBgtJN.handle_request()
			def stop(hw0T9dumKLZOUkBgtJN):
				hw0T9dumKLZOUkBgtJN.keeprunning = False
				hw0T9dumKLZOUkBgtJN.uubAdGUPBLo6D8Et()
			def CnGSVOw0lj72g5ZvQtKIq3AbYoE9eL(hw0T9dumKLZOUkBgtJN):
				hw0T9dumKLZOUkBgtJN.stop()
				hw0T9dumKLZOUkBgtJN.mJNCKBxoGEw5X1tAfLOhgMivQzeI9c.close()
				hw0T9dumKLZOUkBgtJN.server_close()
			def RYB2UowMSq(hw0T9dumKLZOUkBgtJN,mpd):
				hw0T9dumKLZOUkBgtJN.mpd = mpd
			def uubAdGUPBLo6D8Et(hw0T9dumKLZOUkBgtJN):
				AO76Z1XEaSDjomRwK = xIz1gYBcDXoLV9u6JSqfOF83AR0.HTTPConnection(hw0T9dumKLZOUkBgtJN.ip+':'+str(hw0T9dumKLZOUkBgtJN.port))
				AO76Z1XEaSDjomRwK.request("HEAD", "/")
		class XkUq31CfnNFYoPOtB2mD0(ECRiBQbszS8WpL.BaseHTTPRequestHandler):
			def k5vtqlQbepOcgLVIGaTENr7os(hw0T9dumKLZOUkBgtJN):
				hw0T9dumKLZOUkBgtJN.send_response(200)
				hw0T9dumKLZOUkBgtJN.send_header('Content-type','textt/plain')
				hw0T9dumKLZOUkBgtJN.end_headers()
				hw0T9dumKLZOUkBgtJN.wfile.write(hw0T9dumKLZOUkBgtJN.NDwLctrHpYz3JBP.mpd.encode('utf8'))
				YVJPFvuI2CS5KObiZt.sleep(1)
				if hw0T9dumKLZOUkBgtJN.path=='/youtube.mpd': hw0T9dumKLZOUkBgtJN.NDwLctrHpYz3JBP.CnGSVOw0lj72g5ZvQtKIq3AbYoE9eL()
				if hw0T9dumKLZOUkBgtJN.path=='/shutdown': hw0T9dumKLZOUkBgtJN.NDwLctrHpYz3JBP.CnGSVOw0lj72g5ZvQtKIq3AbYoE9eL()
			def b2gmtp6T3xR(hw0T9dumKLZOUkBgtJN):
				hw0T9dumKLZOUkBgtJN.send_response(200)
				hw0T9dumKLZOUkBgtJN.end_headers()
		Xt1l6aQjeqWuJY7HFDowCGb = o4L9t6YhqarkPG183('127.0.0.1',55055,mpd)
		jjaiDCSKceWOkEI9oRTZJgzB = Xt1l6aQjeqWuJY7HFDowCGb.mpdurl
		Xt1l6aQjeqWuJY7HFDowCGb.start()
	else: Xt1l6aQjeqWuJY7HFDowCGb = ''
	if not jjaiDCSKceWOkEI9oRTZJgzB: return 'Error    : Resolver YOUTUBE Failed',[],[]
	return '',[''],[[jjaiDCSKceWOkEI9oRTZJgzB,AcQYKlxVJarHsWoGCzNUjO,Xt1l6aQjeqWuJY7HFDowCGb]]
def NyeiXSpjYK78bRw01GUvxr9a4H(url):
	headers = { 'User-Agent' : '' }
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(hs8IDEMn0YuCHwk,url,'',headers,'','RESOLVERS-VIDBOB-1st')
	items = u5h2Rckvw1E.findall('file:"(.*?)"(,label:"(.*?)"|)\}',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	Z5FySkDLAlm,hVby8e3aQkFfuE,aaybUwAWp2NGnesRYcFqBfkd,EaBeVhOsHYg8wub = [],[],[],[]
	if not items: return 'Error: Resolver Failed VIDBOB',[],[]
	for ekTrZlFMu0Kf5QztEnhAs,qBdHbiaM0lmk5GNsfrXCIYyugR,eDvzfWdXZnlMEiboY5j1P in items:
		ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.replace('https:','http:')
		if '.m3u8' in ekTrZlFMu0Kf5QztEnhAs:
			Z5FySkDLAlm,aaybUwAWp2NGnesRYcFqBfkd = bkz2aCFLpWqGUcPolSXA980O(ekTrZlFMu0Kf5QztEnhAs)
			EaBeVhOsHYg8wub = EaBeVhOsHYg8wub + aaybUwAWp2NGnesRYcFqBfkd
			if Z5FySkDLAlm[0]=='-1': hVby8e3aQkFfuE.append('سيرفر خاص'+'   m3u8')
			else:
				for title in Z5FySkDLAlm:
					hVby8e3aQkFfuE.append('سيرفر خاص'+'   '+title)
		else:
			title = 'سيرفر خاص'+'   mp4   '+eDvzfWdXZnlMEiboY5j1P
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
			hVby8e3aQkFfuE.append(title)
	return '',hVby8e3aQkFfuE,EaBeVhOsHYg8wub
def Pun84kX30FwNAExW2lt(url,oo9SgGkiDbs3HRn7z8):
	kPpGr0QERz4tyh3C,GnuaoT9MxiCg,Uj5oOF90eHZ8yigcqQMr1nl24P,vvspXO2tJ6ikETcV7o1jPW0xmg,lQUf3AY258LeWch = [],[],[],[],[]
	ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('<video preload.*?src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('<source src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('direct_link.*?href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if ekTrZlFMu0Kf5QztEnhAs:
		ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs[0]
		title = ekTrZlFMu0Kf5QztEnhAs.rsplit('.',1)[1]
		kPpGr0QERz4tyh3C.append(title)
		GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs)
	else:
		ppZ9muD1GkPnFRX52jxBUIy = u5h2Rckvw1E.findall('sources: *(\[.*?\])',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if not ppZ9muD1GkPnFRX52jxBUIy: ppZ9muD1GkPnFRX52jxBUIy = u5h2Rckvw1E.findall('var sources = (\{.*?\})',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if not ppZ9muD1GkPnFRX52jxBUIy: ppZ9muD1GkPnFRX52jxBUIy = u5h2Rckvw1E.findall('var jw = (\{.*?\})',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if not ppZ9muD1GkPnFRX52jxBUIy: ppZ9muD1GkPnFRX52jxBUIy = u5h2Rckvw1E.findall('var player = .*?\((\{.*?\})\)',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if ppZ9muD1GkPnFRX52jxBUIy:
			ppZ9muD1GkPnFRX52jxBUIy = ppZ9muD1GkPnFRX52jxBUIy[0]
			NxwMDnLHv5RlJAS27WZcOf9PyU = u5h2Rckvw1E.findall('[,\{] *(\w+):',ppZ9muD1GkPnFRX52jxBUIy,u5h2Rckvw1E.DOTALL)
			for key in list(set(NxwMDnLHv5RlJAS27WZcOf9PyU)): ppZ9muD1GkPnFRX52jxBUIy = ppZ9muD1GkPnFRX52jxBUIy.replace(key+':','"'+key+'":')
			ppZ9muD1GkPnFRX52jxBUIy = eval(ppZ9muD1GkPnFRX52jxBUIy)
			if isinstance(ppZ9muD1GkPnFRX52jxBUIy,dict): ppZ9muD1GkPnFRX52jxBUIy = [ppZ9muD1GkPnFRX52jxBUIy]
			for lmO2YJGr6tCV in ppZ9muD1GkPnFRX52jxBUIy:
				if isinstance(lmO2YJGr6tCV,dict):
					keys = list(lmO2YJGr6tCV.keys())
					if 'file' in keys: ekTrZlFMu0Kf5QztEnhAs = lmO2YJGr6tCV['file']
					elif 'hls' in keys: ekTrZlFMu0Kf5QztEnhAs = lmO2YJGr6tCV['hls']
					if 'label' in keys: title = str(lmO2YJGr6tCV['label'])
					elif 'video_height' in keys: title = str(lmO2YJGr6tCV['video_height'])
					else: title = ekTrZlFMu0Kf5QztEnhAs.rsplit('.',1)[1]
				elif isinstance(lmO2YJGr6tCV,str):
					ekTrZlFMu0Kf5QztEnhAs = lmO2YJGr6tCV
					title = ekTrZlFMu0Kf5QztEnhAs.rsplit('.',1)[1]
				kPpGr0QERz4tyh3C.append(title)
				GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs)
	for ekTrZlFMu0Kf5QztEnhAs,title in zip(GnuaoT9MxiCg,kPpGr0QERz4tyh3C):
		ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.replace('\\/','/')
		A3oYrN6fkB9PX4ian = hmcFWJUgiAuGk(url,'url')
		UUSPoh1ckMtVexN6u = ncgQBtRa7qT2GJ3Wpd()
		if '.m3u8' in ekTrZlFMu0Kf5QztEnhAs:
			headers = {'User-Agent':UUSPoh1ckMtVexN6u,'Referer':A3oYrN6fkB9PX4ian}
			VzsFhdaxo9QSZTptriv,jgEwP58m4V = bkz2aCFLpWqGUcPolSXA980O(ekTrZlFMu0Kf5QztEnhAs,headers)
			vvspXO2tJ6ikETcV7o1jPW0xmg += jgEwP58m4V
			Uj5oOF90eHZ8yigcqQMr1nl24P += VzsFhdaxo9QSZTptriv
		else:
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'|User-Agent='+UUSPoh1ckMtVexN6u+'&Referer='+A3oYrN6fkB9PX4ian
			vvspXO2tJ6ikETcV7o1jPW0xmg.append(ekTrZlFMu0Kf5QztEnhAs)
			Uj5oOF90eHZ8yigcqQMr1nl24P.append(title)
	ruqEoR69TUCy,kPpGr0QERz4tyh3C,GnuaoT9MxiCg = '',[],[]
	if vvspXO2tJ6ikETcV7o1jPW0xmg: ruqEoR69TUCy,kPpGr0QERz4tyh3C,GnuaoT9MxiCg = '',Uj5oOF90eHZ8yigcqQMr1nl24P,vvspXO2tJ6ikETcV7o1jPW0xmg
	else:
		if '<' not in oo9SgGkiDbs3HRn7z8 and len(oo9SgGkiDbs3HRn7z8)<100 and oo9SgGkiDbs3HRn7z8: ruqEoR69TUCy = oo9SgGkiDbs3HRn7z8
		else:
			msg = u5h2Rckvw1E.findall('<div style=".*?">(File.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
			if not msg: msg = u5h2Rckvw1E.findall('<div class="vp_video_stub_txt">(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
			if not msg: msg = u5h2Rckvw1E.findall('<h2>(Sorry.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
			if msg: ruqEoR69TUCy = msg[0]
	return ruqEoR69TUCy,kPpGr0QERz4tyh3C,GnuaoT9MxiCg
def AYkh3LZKS1iGpvdtM2JC(FDHseLGOZtzdX1,url):
	global bbzrh8lgpjo
	url = url.strip('/')
	hhUwzgWifrTC9mBl0V,nD70jhRb8C9Gi = '',{}
	headers = {'User-Agent':ncgQBtRa7qT2GJ3Wpd(),'Accept-Language':'en-US,en;q=0.9','Sec-Fetch-Dest':'iframe'}
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',url,'',headers,'',False,'RESOLVERS-XSHARING-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	pS1FZURXzhBCLMlA0HItTfwQxcmNjn = RoQL91PphqCJg4W0e6Fnsl.code
	if not isinstance(oo9SgGkiDbs3HRn7z8,str): oo9SgGkiDbs3HRn7z8 = oo9SgGkiDbs3HRn7z8.decode('utf8','ignore')
	if 'function(p,a,c,k,e,' in oo9SgGkiDbs3HRn7z8:
		BZ3r6t4XFPSRq = u5h2Rckvw1E.findall('(eval\(function\(p,a,c,k,e,[dr].*?)</script>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if BZ3r6t4XFPSRq:
			try: hhUwzgWifrTC9mBl0V = qd36ueWAYg(BZ3r6t4XFPSRq[0])
			except: hhUwzgWifrTC9mBl0V = ''
	ZCOosjaQ8x9HDKSVGM6LwW2vy = oo9SgGkiDbs3HRn7z8+hhUwzgWifrTC9mBl0V
	if '"id2"' in ZCOosjaQ8x9HDKSVGM6LwW2vy or '"id"' in ZCOosjaQ8x9HDKSVGM6LwW2vy:
		AXJq7rhoI4ceRZnxsPfmH15 = url.split('/')[3].replace('embed-','').replace('.html','')
		if '"id2"' in ZCOosjaQ8x9HDKSVGM6LwW2vy: nD70jhRb8C9Gi = {'id2':AXJq7rhoI4ceRZnxsPfmH15,'op':'download2'}
		elif '"id"' in ZCOosjaQ8x9HDKSVGM6LwW2vy: nD70jhRb8C9Gi = {'id':AXJq7rhoI4ceRZnxsPfmH15,'op':'download2'}
		emrzEIsMWO2GLw9lpKxSY7n0F = headers.copy()
		emrzEIsMWO2GLw9lpKxSY7n0F['Content-Type'] = 'application/x-www-form-urlencoded'
		p8HVUxN5v3WZfF4Gt7o0gLOdSiI = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'POST',url,nD70jhRb8C9Gi,emrzEIsMWO2GLw9lpKxSY7n0F,'',False,'RESOLVERS-XSHARING-2nd')
		ZCOosjaQ8x9HDKSVGM6LwW2vy = p8HVUxN5v3WZfF4Gt7o0gLOdSiI.content
	XYjSguKRVBeaqLcMU76Z3wstfd1FCx,RPAHTvhsOYyKpFXb0tdqjGLS4m,NNIpDc130xTwlyviRqkju = Pun84kX30FwNAExW2lt(url,ZCOosjaQ8x9HDKSVGM6LwW2vy)
	bbzrh8lgpjo[FDHseLGOZtzdX1] = XYjSguKRVBeaqLcMU76Z3wstfd1FCx,RPAHTvhsOYyKpFXb0tdqjGLS4m,NNIpDc130xTwlyviRqkju,pS1FZURXzhBCLMlA0HItTfwQxcmNjn
	return
bbzrh8lgpjo,se9o4LyRVBvmjzkwCJ0ZYn = {},0
def LbXeDMhs3i(url):
	global bbzrh8lgpjo,se9o4LyRVBvmjzkwCJ0ZYn
	lQUf3AY258LeWch,threads = [],[]
	se9o4LyRVBvmjzkwCJ0ZYn += 100
	yO85tSHTEDWalPrk = se9o4LyRVBvmjzkwCJ0ZYn
	lQUf3AY258LeWch.append([1,url])
	bbzrh8lgpjo[yO85tSHTEDWalPrk+1] = [None,None,None,None]
	SsMLRwfpr67KB4HX3Wli8ChY = onVDrgLUpFsqOPkxId9BwW6Rtc5A.Thread(target=AYkh3LZKS1iGpvdtM2JC,args=(yO85tSHTEDWalPrk+1,url))
	SsMLRwfpr67KB4HX3Wli8ChY.start()
	SsMLRwfpr67KB4HX3Wli8ChY.join(10)
	if not bbzrh8lgpjo[yO85tSHTEDWalPrk+1][2]:
		gANn35esloKUydOipfSMC6RD2 = url.replace('/embed-','/')
		KKSjuTY20EibkGc413C = u5h2Rckvw1E.findall('^(.*?://.*?)/(.*?)/(.*?)$',gANn35esloKUydOipfSMC6RD2+'/',u5h2Rckvw1E.DOTALL)
		start,BSIzL7kDe9r0oGqtp,end = KKSjuTY20EibkGc413C[0]
		end = end.strip('/')
		uXn4IpzJP68 = len(BSIzL7kDe9r0oGqtp)<4 or BSIzL7kDe9r0oGqtp in ['file','video','videoembed']
		if not uXn4IpzJP68: lQUf3AY258LeWch.append([2,start+'/embed-'+BSIzL7kDe9r0oGqtp+'/'+end])
		if end: lQUf3AY258LeWch.append([3,start+'/'+BSIzL7kDe9r0oGqtp+'/embed-'+end])
		if '.html' in BSIzL7kDe9r0oGqtp:
			lLMGovHfsVxezdIqE9rcPju1ZF8b2y = BSIzL7kDe9r0oGqtp.replace('.html','')
			lQUf3AY258LeWch.append([4,start+'/'+lLMGovHfsVxezdIqE9rcPju1ZF8b2y+'/'+end])
			lQUf3AY258LeWch.append([5,start+'/embed-'+lLMGovHfsVxezdIqE9rcPju1ZF8b2y+'/'+end])
			if end: lQUf3AY258LeWch.append([6,start+'/'+lLMGovHfsVxezdIqE9rcPju1ZF8b2y+'/embed-'+end])
		elif '.html' in end:
			mSOiygBF9kDKJYfZ4oQV = end.replace('.html','')
			lQUf3AY258LeWch.append([7,start+'/'+BSIzL7kDe9r0oGqtp+'/'+mSOiygBF9kDKJYfZ4oQV])
			if not uXn4IpzJP68: lQUf3AY258LeWch.append([8,start+'/embed-'+BSIzL7kDe9r0oGqtp+'/'+mSOiygBF9kDKJYfZ4oQV])
			lQUf3AY258LeWch.append([9,start+'/'+BSIzL7kDe9r0oGqtp+'/embed-'+mSOiygBF9kDKJYfZ4oQV])
		else:
			if not uXn4IpzJP68: lQUf3AY258LeWch.append([10,start+'/'+BSIzL7kDe9r0oGqtp+'.html'])
			if not uXn4IpzJP68: lQUf3AY258LeWch.append([11,start+'/embed-'+BSIzL7kDe9r0oGqtp+'.html'])
			if end: lQUf3AY258LeWch.append([12,start+'/'+BSIzL7kDe9r0oGqtp+'/'+end+'.html'])
			if end: lQUf3AY258LeWch.append([13,start+'/'+BSIzL7kDe9r0oGqtp+'/embed-'+end+'.html'])
		if uXn4IpzJP68 and end:
			end = end.replace('/embed-','/')
			lQUf3AY258LeWch.append([14,start+'/'+end])
			lQUf3AY258LeWch.append([15,start+'/embed-'+end])
			if '.html' in end:
				mSOiygBF9kDKJYfZ4oQV = end.replace('.html','')
				lQUf3AY258LeWch.append([16,start+'/'+mSOiygBF9kDKJYfZ4oQV])
				lQUf3AY258LeWch.append([17,start+'/embed-'+mSOiygBF9kDKJYfZ4oQV])
			else:
				lQUf3AY258LeWch.append([18,start+'/'+end+'.html'])
				lQUf3AY258LeWch.append([19,start+'/embed-'+end+'.html'])
		for eitKAc89owDhTpUWvmBrxM6RI,ekTrZlFMu0Kf5QztEnhAs in lQUf3AY258LeWch[1:]:
			bbzrh8lgpjo[yO85tSHTEDWalPrk+eitKAc89owDhTpUWvmBrxM6RI] = [None,None,None,None]
			SsMLRwfpr67KB4HX3Wli8ChY = onVDrgLUpFsqOPkxId9BwW6Rtc5A.Thread(target=AYkh3LZKS1iGpvdtM2JC,args=(yO85tSHTEDWalPrk+eitKAc89owDhTpUWvmBrxM6RI,ekTrZlFMu0Kf5QztEnhAs))
			SsMLRwfpr67KB4HX3Wli8ChY.start()
			YVJPFvuI2CS5KObiZt.sleep(0.5)
			threads.append(SsMLRwfpr67KB4HX3Wli8ChY)
		for SsMLRwfpr67KB4HX3Wli8ChY in threads: SsMLRwfpr67KB4HX3Wli8ChY.join(10)
	ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub = '',[],[]
	OhoV69LaZRgyp7wNGHJ5xd = []
	for eitKAc89owDhTpUWvmBrxM6RI,ekTrZlFMu0Kf5QztEnhAs in lQUf3AY258LeWch:
		oIFwebX2EWyfz8qJ756g03m1Rl,UY2aIHbc58sv3,u7atKgzGSc59dXWiZPYpeqnyl0sCkj,NAyQC1XgbxOLrIFBovK9Y8pGjeztw4 = bbzrh8lgpjo[yO85tSHTEDWalPrk+eitKAc89owDhTpUWvmBrxM6RI]
		if not EaBeVhOsHYg8wub and u7atKgzGSc59dXWiZPYpeqnyl0sCkj: hVby8e3aQkFfuE,EaBeVhOsHYg8wub = UY2aIHbc58sv3,u7atKgzGSc59dXWiZPYpeqnyl0sCkj
		if not ruqEoR69TUCy and oIFwebX2EWyfz8qJ756g03m1Rl: ruqEoR69TUCy = oIFwebX2EWyfz8qJ756g03m1Rl
		if NAyQC1XgbxOLrIFBovK9Y8pGjeztw4: OhoV69LaZRgyp7wNGHJ5xd.append(NAyQC1XgbxOLrIFBovK9Y8pGjeztw4)
	OhoV69LaZRgyp7wNGHJ5xd = list(set(OhoV69LaZRgyp7wNGHJ5xd))
	if not ruqEoR69TUCy and len(OhoV69LaZRgyp7wNGHJ5xd)==1:
		pS1FZURXzhBCLMlA0HItTfwQxcmNjn = OhoV69LaZRgyp7wNGHJ5xd[0]
		if pS1FZURXzhBCLMlA0HItTfwQxcmNjn!=200:
			if pS1FZURXzhBCLMlA0HItTfwQxcmNjn<0: ruqEoR69TUCy = 'Video page/server is not accessible'
			else:
				ruqEoR69TUCy = 'HTTP Error: '+str(pS1FZURXzhBCLMlA0HItTfwQxcmNjn)
				if VVGRN7xiyj: import http.client as xIz1gYBcDXoLV9u6JSqfOF83AR0
				else: import httplib as xIz1gYBcDXoLV9u6JSqfOF83AR0
				ruqEoR69TUCy += ' ( '+xIz1gYBcDXoLV9u6JSqfOF83AR0.responses[pS1FZURXzhBCLMlA0HItTfwQxcmNjn]+' )'
	YVJPFvuI2CS5KObiZt.sleep(1)
	return ruqEoR69TUCy,hVby8e3aQkFfuE,EaBeVhOsHYg8wub
class B5Lwk7fn1Ng(XuWPVcQ13oDq5swf0S.WindowDialog):
	def __init__(hw0T9dumKLZOUkBgtJN, *args, **lu21g7RLsN4F9XEftVKB8TG6Py):
		rucv0dISf3ULxzJ9iV = k1t0JLRsCQ.path.join(b69iT7LWwrfXzGYPMvBCsteVHDQK, 'resources', 'recaptcha', 'background.png')
		x9CtivngGYkzer8q6ZNFQ = k1t0JLRsCQ.path.join(b69iT7LWwrfXzGYPMvBCsteVHDQK, 'resources', 'recaptcha', 'checked.png')
		IIWspQqgfv6AUaNwh3rBT2 = k1t0JLRsCQ.path.join(b69iT7LWwrfXzGYPMvBCsteVHDQK, 'resources', 'recaptcha', 'button-fo.png')
		NzyenXOLoiW8RkS4V5wEvGY = k1t0JLRsCQ.path.join(b69iT7LWwrfXzGYPMvBCsteVHDQK, 'resources', 'recaptcha', 'button-nofo.png')
		hw0T9dumKLZOUkBgtJN.cancelled = False
		hw0T9dumKLZOUkBgtJN.chk = [0] * 9
		hw0T9dumKLZOUkBgtJN.chkbutton = [0] * 9
		hw0T9dumKLZOUkBgtJN.chkstate = [False] * 9
		DDoLHZ9Otbhrf, BCKTpW3alg7NjfLvVSe8Xk, wcI0BZqNAh2k9, wwZjFR85doaVsJ = 436, 210, 408, 300
		LxEjWegdpN0U, TrOHdSNCo1mMahWB7QDL03Ew = wwZjFR85doaVsJ // 3, wcI0BZqNAh2k9 // 3
		RBkVA9OgUjc5o6nHbzSTfI1m8 = 70
		m0juWvekR6hFZObwnCKAztgBf24VP3 = 70
		wqfTUAh45OEzQ0F = 40
		VLXuTR5jIH = 40
		ZANTyuDztEH3Pe7pgxX = BCKTpW3alg7NjfLvVSe8Xk + wwZjFR85doaVsJ + wqfTUAh45OEzQ0F
		BSIzL7kDe9r0oGqtp = DDoLHZ9Otbhrf + (wcI0BZqNAh2k9 // 2)
		ggCnKTyWZfzu = DDoLHZ9Otbhrf - RBkVA9OgUjc5o6nHbzSTfI1m8
		iGvZQ7kRCh2 = BCKTpW3alg7NjfLvVSe8Xk - m0juWvekR6hFZObwnCKAztgBf24VP3
		OOPug8RFh5ebDqQ2xCVs0XwYEZU = wwZjFR85doaVsJ + 2 * m0juWvekR6hFZObwnCKAztgBf24VP3 + VLXuTR5jIH + wqfTUAh45OEzQ0F
		xX7cRMm2OJ9IA8sy = wcI0BZqNAh2k9 + 2 * RBkVA9OgUjc5o6nHbzSTfI1m8
		NFjTPJaZVO6rB8 = XuWPVcQ13oDq5swf0S.ControlImage(ggCnKTyWZfzu, iGvZQ7kRCh2, xX7cRMm2OJ9IA8sy, OOPug8RFh5ebDqQ2xCVs0XwYEZU, rucv0dISf3ULxzJ9iV)
		hw0T9dumKLZOUkBgtJN.addControl(NFjTPJaZVO6rB8)
		hw0T9dumKLZOUkBgtJN.msg = '[COLOR FFFFFF00]'+lu21g7RLsN4F9XEftVKB8TG6Py.get('msg')+'[/COLOR]'
		hw0T9dumKLZOUkBgtJN.strActionInfo = XuWPVcQ13oDq5swf0S.ControlLabel(DDoLHZ9Otbhrf - 20 , BCKTpW3alg7NjfLvVSe8Xk - 40, wcI0BZqNAh2k9 + 40 , 20, hw0T9dumKLZOUkBgtJN.msg, 'font13')
		hw0T9dumKLZOUkBgtJN.addControl(hw0T9dumKLZOUkBgtJN.strActionInfo)
		pGjsvdyHfM = XuWPVcQ13oDq5swf0S.ControlImage(DDoLHZ9Otbhrf, BCKTpW3alg7NjfLvVSe8Xk, wcI0BZqNAh2k9, wwZjFR85doaVsJ, lu21g7RLsN4F9XEftVKB8TG6Py.get('captcha'))
		hw0T9dumKLZOUkBgtJN.addControl(pGjsvdyHfM)
		hw0T9dumKLZOUkBgtJN.iteration = lu21g7RLsN4F9XEftVKB8TG6Py.get('iteration')
		hw0T9dumKLZOUkBgtJN.strActionInfo = XuWPVcQ13oDq5swf0S.ControlLabel(DDoLHZ9Otbhrf, BCKTpW3alg7NjfLvVSe8Xk + wwZjFR85doaVsJ, wcI0BZqNAh2k9, 20, 'المحاولة رقم: '+str(hw0T9dumKLZOUkBgtJN.iteration), 'font40')
		hw0T9dumKLZOUkBgtJN.addControl(hw0T9dumKLZOUkBgtJN.strActionInfo)
		hw0T9dumKLZOUkBgtJN.cancelbutton = XuWPVcQ13oDq5swf0S.ControlButton(BSIzL7kDe9r0oGqtp - 110, ZANTyuDztEH3Pe7pgxX, 100, VLXuTR5jIH, 'خروج', focusTexture=IIWspQqgfv6AUaNwh3rBT2, noFocusTexture=NzyenXOLoiW8RkS4V5wEvGY, alignment=2)
		hw0T9dumKLZOUkBgtJN.okbutton = XuWPVcQ13oDq5swf0S.ControlButton(BSIzL7kDe9r0oGqtp + 10, ZANTyuDztEH3Pe7pgxX, 100, VLXuTR5jIH, 'استمرار', focusTexture=IIWspQqgfv6AUaNwh3rBT2, noFocusTexture=NzyenXOLoiW8RkS4V5wEvGY, alignment=2)
		hw0T9dumKLZOUkBgtJN.addControl(hw0T9dumKLZOUkBgtJN.okbutton)
		hw0T9dumKLZOUkBgtJN.addControl(hw0T9dumKLZOUkBgtJN.cancelbutton)
		for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(9):
			mRV7TObHvK2isMeaz = Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE // 3
			asUWX0lPbR2f9vdBLhVreGt43 = Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE % 3
			xcj3zpgvOZY27hl50n6dMaNsWwr = DDoLHZ9Otbhrf + (TrOHdSNCo1mMahWB7QDL03Ew * asUWX0lPbR2f9vdBLhVreGt43)
			fAa2xorOn5 = BCKTpW3alg7NjfLvVSe8Xk + (LxEjWegdpN0U * mRV7TObHvK2isMeaz)
			hw0T9dumKLZOUkBgtJN.chk[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE] = XuWPVcQ13oDq5swf0S.ControlImage(xcj3zpgvOZY27hl50n6dMaNsWwr-10, fAa2xorOn5-15, TrOHdSNCo1mMahWB7QDL03Ew+20, LxEjWegdpN0U+30, x9CtivngGYkzer8q6ZNFQ)
			hw0T9dumKLZOUkBgtJN.addControl(hw0T9dumKLZOUkBgtJN.chk[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE])
			hw0T9dumKLZOUkBgtJN.chk[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE].setVisible(False)
			hw0T9dumKLZOUkBgtJN.chkbutton[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE] = XuWPVcQ13oDq5swf0S.ControlButton(xcj3zpgvOZY27hl50n6dMaNsWwr-10, fAa2xorOn5-15, TrOHdSNCo1mMahWB7QDL03Ew+20, LxEjWegdpN0U+30, str(Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE + 1), font='font1', focusTexture=IIWspQqgfv6AUaNwh3rBT2, noFocusTexture=NzyenXOLoiW8RkS4V5wEvGY)
			hw0T9dumKLZOUkBgtJN.addControl(hw0T9dumKLZOUkBgtJN.chkbutton[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE])
		for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(9):
			yes5B471GARaQhTMuUmFYpilfVPNL = (Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE // 3) * 3
			qAF2SJ9shPCgv31OwyKQLz5Ruo6IDE = yes5B471GARaQhTMuUmFYpilfVPNL + (Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE + 1) % 3
			HejWC8RVos = yes5B471GARaQhTMuUmFYpilfVPNL + (Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE - 1) % 3
			VrCWK98g4ITOMP = (Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE - 3) % 9
			BVwhHjGpDlAZdvSYmgUFq1y = (Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE + 3) % 9
			hw0T9dumKLZOUkBgtJN.chkbutton[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE].controlRight(hw0T9dumKLZOUkBgtJN.chkbutton[qAF2SJ9shPCgv31OwyKQLz5Ruo6IDE])
			hw0T9dumKLZOUkBgtJN.chkbutton[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE].controlLeft(hw0T9dumKLZOUkBgtJN.chkbutton[HejWC8RVos])
			if Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE <= 2:
				hw0T9dumKLZOUkBgtJN.chkbutton[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE].controlUp(hw0T9dumKLZOUkBgtJN.okbutton)
			else:
				hw0T9dumKLZOUkBgtJN.chkbutton[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE].controlUp(hw0T9dumKLZOUkBgtJN.chkbutton[VrCWK98g4ITOMP])
			if Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE >= 6:
				hw0T9dumKLZOUkBgtJN.chkbutton[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE].controlDown(hw0T9dumKLZOUkBgtJN.okbutton)
			else:
				hw0T9dumKLZOUkBgtJN.chkbutton[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE].controlDown(hw0T9dumKLZOUkBgtJN.chkbutton[BVwhHjGpDlAZdvSYmgUFq1y])
		hw0T9dumKLZOUkBgtJN.okbutton.controlLeft(hw0T9dumKLZOUkBgtJN.cancelbutton)
		hw0T9dumKLZOUkBgtJN.okbutton.controlRight(hw0T9dumKLZOUkBgtJN.cancelbutton)
		hw0T9dumKLZOUkBgtJN.cancelbutton.controlLeft(hw0T9dumKLZOUkBgtJN.okbutton)
		hw0T9dumKLZOUkBgtJN.cancelbutton.controlRight(hw0T9dumKLZOUkBgtJN.okbutton)
		hw0T9dumKLZOUkBgtJN.okbutton.controlDown(hw0T9dumKLZOUkBgtJN.chkbutton[2])
		hw0T9dumKLZOUkBgtJN.okbutton.controlUp(hw0T9dumKLZOUkBgtJN.chkbutton[8])
		hw0T9dumKLZOUkBgtJN.cancelbutton.controlDown(hw0T9dumKLZOUkBgtJN.chkbutton[0])
		hw0T9dumKLZOUkBgtJN.cancelbutton.controlUp(hw0T9dumKLZOUkBgtJN.chkbutton[6])
		hw0T9dumKLZOUkBgtJN.setFocus(hw0T9dumKLZOUkBgtJN.okbutton)
	def get(hw0T9dumKLZOUkBgtJN):
		hw0T9dumKLZOUkBgtJN.doModal()
		hw0T9dumKLZOUkBgtJN.close()
		if not hw0T9dumKLZOUkBgtJN.cancelled:
			return [Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(9) if hw0T9dumKLZOUkBgtJN.chkstate[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE]]
	def MBbLctuyXzO7(hw0T9dumKLZOUkBgtJN, EKlWymxAoGMFwnRhJc7abf3X24B):
		if EKlWymxAoGMFwnRhJc7abf3X24B.getId() == hw0T9dumKLZOUkBgtJN.okbutton.getId() and any(hw0T9dumKLZOUkBgtJN.chkstate):
			hw0T9dumKLZOUkBgtJN.close()
		elif EKlWymxAoGMFwnRhJc7abf3X24B.getId() == hw0T9dumKLZOUkBgtJN.cancelbutton.getId():
			hw0T9dumKLZOUkBgtJN.cancelled = True
			hw0T9dumKLZOUkBgtJN.close()
		else:
			eDvzfWdXZnlMEiboY5j1P = EKlWymxAoGMFwnRhJc7abf3X24B.getLabel()
			if eDvzfWdXZnlMEiboY5j1P.isnumeric():
				index = int(eDvzfWdXZnlMEiboY5j1P) - 1
				hw0T9dumKLZOUkBgtJN.chkstate[index] = not hw0T9dumKLZOUkBgtJN.chkstate[index]
				hw0T9dumKLZOUkBgtJN.chk[index].setVisible(hw0T9dumKLZOUkBgtJN.chkstate[index])
	def AHz2lNqUJG84ergYV0jIx(hw0T9dumKLZOUkBgtJN, xQ258PaXGnuBcfUNL6D):
		if xQ258PaXGnuBcfUNL6D == 10:
			hw0T9dumKLZOUkBgtJN.cancelled = True
			hw0T9dumKLZOUkBgtJN.close()
def Z57WneruOJP1IHT(key,AAj0QysJwULt1ha8gBXZTR,url):
	headers = {'Referer':url,'Accept-Language':AAj0QysJwULt1ha8gBXZTR}
	o7sBJrnETHtciAZRfw8YSO4gy = 'http://www.google.com/recaptcha/api/fallback?k='+key
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',o7sBJrnETHtciAZRfw8YSO4gy,'',headers,'','','RESOLVERS-GET_RECAPTCHA2_TOKEN-1st')
	dh1veN6mVBg7pQ,iteration = '',0
	while True:
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		nD70jhRb8C9Gi = u5h2Rckvw1E.findall('"(/recaptcha/api2/payload[^"]+)', oo9SgGkiDbs3HRn7z8)
		iteration += 1
		message = u5h2Rckvw1E.findall('<label[^>]+class="fbc-imageselect-message-text"[^>]*>(.*?)</label>', oo9SgGkiDbs3HRn7z8)
		if not message: message = u5h2Rckvw1E.findall('<div[^>]+class="fbc-imageselect-message-error">(.*?)</div>', oo9SgGkiDbs3HRn7z8)
		if not message:
			dh1veN6mVBg7pQ = u5h2Rckvw1E.findall('readonly>(.*?)<', oo9SgGkiDbs3HRn7z8)[0]
			break
		else:
			message = message[0]
			nD70jhRb8C9Gi = nD70jhRb8C9Gi[0]
		ALpDCMPx8Iq = u5h2Rckvw1E.findall(r'name="c"\s+value="([^"]+)', oo9SgGkiDbs3HRn7z8)[0]
		VsA3eqKaNYoluvJQ = 'https://www.google.com%s' % (nD70jhRb8C9Gi.replace('&amp;', '&'))
		message = u5h2Rckvw1E.sub('</?(div|strong)[^>]*>', '', message)
		EsqcMJSjTgdar7KVH = B5Lwk7fn1Ng(captcha=VsA3eqKaNYoluvJQ, msg=message, iteration=iteration)
		gEGUBne6RXzo4irNh5W7dsqP93f = EsqcMJSjTgdar7KVH.get()
		if not gEGUBne6RXzo4irNh5W7dsqP93f: break
		data = {'c': ALpDCMPx8Iq, 'response': gEGUBne6RXzo4irNh5W7dsqP93f}
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'POST',o7sBJrnETHtciAZRfw8YSO4gy,data,headers,'','','RESOLVERS-GET_RECAPTCHA2_TOKEN-2nd')
	return dh1veN6mVBg7pQ
def N4NMYLOxeP(url):
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(hs8IDEMn0YuCHwk,url,'','','','RESOLVERS-ARABLOADS-1st')
	items = u5h2Rckvw1E.findall('color="red">(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if items: return '',[''],[ items[0] ]
	else: return 'Error: Resolver Failed ARABLOADS',[],[]
def bshEiAGUuDr6jY3FNWBzx(url):
	return '',[''],[ url ]
def RxijYfWZwMNnvV1(url):
	NDwLctrHpYz3JBP = url.split('/')
	MdvYUWHRFDu1zfgPkhlyq5w = '/'.join(NDwLctrHpYz3JBP[0:3])
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(hs8IDEMn0YuCHwk,url,'','','','RESOLVERS-ZIPPYSHARE-1st')
	items = u5h2Rckvw1E.findall('dlbutton\'\).href = "(.*?)" \+ \((.*?) \% (.*?) \+ (.*?) \% (.*?)\) \+ "(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if items:
		riQnIlkHK86L4PSM,mOTzUAv73S1yDHg,XSdDoaOlnLtz,QagioSACGTMWlu,UUeQdB4j8plKbtyC,CORHI0MxVFf = items[0]
		b1EWu6sYaRk0FXUx8HVvNBQort43 = int(mOTzUAv73S1yDHg) % int(XSdDoaOlnLtz) + int(QagioSACGTMWlu) % int(UUeQdB4j8plKbtyC)
		url = MdvYUWHRFDu1zfgPkhlyq5w + riQnIlkHK86L4PSM + str(b1EWu6sYaRk0FXUx8HVvNBQort43) + CORHI0MxVFf
		return '',[''],[url]
	else: return 'Error: Resolver Failed ZIPPYSHARE',[],[]
def wnUxLPbMDs4N5qFg(url):
	id = url.split('/')[-1]
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	nD70jhRb8C9Gi = { "id":id , "op":"download2" }
	VemfsE32zgI = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'POST', url, nD70jhRb8C9Gi, headers, '','','RESOLVERS-MP4UPLOAD-1st')
	if 'Location' in list(VemfsE32zgI.headers.keys()): ekTrZlFMu0Kf5QztEnhAs = VemfsE32zgI.headers['Location']
	else: ekTrZlFMu0Kf5QztEnhAs = url
	if ekTrZlFMu0Kf5QztEnhAs: return '',[''],[ekTrZlFMu0Kf5QztEnhAs]
	else: return 'Error: Resolver Failed MP4UPLOAD',[],[]
def aCEZSMAszPItmkyUhOGfgFv1B0iw7(url):
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(hs8IDEMn0YuCHwk,url,'','','','RESOLVERS-WINTVLIVE-1st')
	items = u5h2Rckvw1E.findall('mp4: \[\'(.*?)\'',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if items: return '',[''],[ items[0] ]
	else: return 'Error: Resolver Failed WINTVLIVE',[],[]
def xJLyoRK9dtClbmqzhgYk1Gviu(url):
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(hs8IDEMn0YuCHwk,url,'','','','RESOLVERS-ARCHIVE-1st')
	items = u5h2Rckvw1E.findall('source src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if items:
		url = url = 'https://archive.org' + items[0]
		return '',[''],[ url ]
	else: return 'Error: Resolver Failed ARCHIVE',[],[]
def Dpb7tOcHEdP9waG46xze(url):
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(hs8IDEMn0YuCHwk,url,'','','','RESOLVERS-ESTREAM-1st')
	items = u5h2Rckvw1E.findall('video preload.*?src=.*?src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if items: return '',[''],[ items[0] ]
	else: return 'Error: Resolver Failed ESTREAM',[],[]
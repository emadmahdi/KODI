# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'TVFUN'
tiCRYyX1bWd40Ir3PafQu = '_TVF_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['بث مباشر']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==460: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==461: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,text)
	elif mode==462: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==463: vS7JufTVsBxw52 = GA2KIlbOsoYtxpkDF71(url)
	elif mode==469: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',yONJxHER9BIDPpTV4YsWmc0n,'','','','','TVFUN-MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',469,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"menu-btn"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?<span>(.*?)</span>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
			if title=='الرئيسية': title = 'جديد حلقات تيفي فان'
			if title in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,461)
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,lcOov4Kz0uBairTpLxXgAqIt72mk=''):
	items = []
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','TVFUN-TITLES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="head-title"(.*?)id="footer"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		yn8DkpE5etF3WiUmfSO = []
		dR94SHEmDA8nflN = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
		for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
			if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
			ekTrZlFMu0Kf5QztEnhAs = P2o6ZDHeW790pSQqucvnxzILVUX(ekTrZlFMu0Kf5QztEnhAs)
			zAjwuoRY98mXN6xvE = u5h2Rckvw1E.findall('(.*?) الحلقة \d+',title,u5h2Rckvw1E.DOTALL)
			if any(c2eEflztvIX in title for c2eEflztvIX in dR94SHEmDA8nflN):
				uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,462,pGjsvdyHfM)
			elif zAjwuoRY98mXN6xvE and 'الحلقة' in title:
				title = '_MOD_' + zAjwuoRY98mXN6xvE[0]
				if title not in yn8DkpE5etF3WiUmfSO:
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,463,pGjsvdyHfM)
					yn8DkpE5etF3WiUmfSO.append(title)
			else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,463,pGjsvdyHfM)
	if lcOov4Kz0uBairTpLxXgAqIt72mk!='latest':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"pagination"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('<a href="(.*?)".*?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,title in items:
				ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.strip(' ')
				if ekTrZlFMu0Kf5QztEnhAs=="": continue
				if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
				if title!='': uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+title,ekTrZlFMu0Kf5QztEnhAs,461)
	return
def GA2KIlbOsoYtxpkDF71(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','TVFUN-EPISODES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="head-title"(.*?)id="footer"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
			if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,462,pGjsvdyHfM)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"pagination"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.strip(' ')
			if ekTrZlFMu0Kf5QztEnhAs=="": continue
			if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
			if title!='': uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+title,ekTrZlFMu0Kf5QztEnhAs,463)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	EaBeVhOsHYg8wub = []
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','TVFUN-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	tJDmqZV5RXajPHg4eYprTW6 = u5h2Rckvw1E.findall('"embedUrl": "(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if tJDmqZV5RXajPHg4eYprTW6:
		tJDmqZV5RXajPHg4eYprTW6 = tJDmqZV5RXajPHg4eYprTW6[0]
		if 'http' not in tJDmqZV5RXajPHg4eYprTW6:
			if '//' in tJDmqZV5RXajPHg4eYprTW6: tJDmqZV5RXajPHg4eYprTW6 = 'http:'+tJDmqZV5RXajPHg4eYprTW6
			else: tJDmqZV5RXajPHg4eYprTW6 = yONJxHER9BIDPpTV4YsWmc0n+tJDmqZV5RXajPHg4eYprTW6
		tJDmqZV5RXajPHg4eYprTW6 = tJDmqZV5RXajPHg4eYprTW6+'?named=__embed'
		EaBeVhOsHYg8wub.append(tJDmqZV5RXajPHg4eYprTW6)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('VideoServers"(.*?)"Play"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		lQUf3AY258LeWch = u5h2Rckvw1E.findall('''setVideo\('(.*?)'\).*?">(.*?)<''',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for iXPdqKVTHsCb8AOxe5,name in lQUf3AY258LeWch:
			iXPdqKVTHsCb8AOxe5 = iXPdqKVTHsCb8AOxe5[2:]
			if bdptXFc8UlIhA5jnGwPmKuv2L: iXPdqKVTHsCb8AOxe5 = iXPdqKVTHsCb8AOxe5.decode('utf8')
			iXPdqKVTHsCb8AOxe5 = yB3NPc2ZhbwFEi1X0dv.b64decode(iXPdqKVTHsCb8AOxe5)
			if VVGRN7xiyj: iXPdqKVTHsCb8AOxe5 = iXPdqKVTHsCb8AOxe5.decode('utf8')
			ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('src="(.*?)"',iXPdqKVTHsCb8AOxe5,u5h2Rckvw1E.DOTALL)
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs[0]
			if 'http' not in ekTrZlFMu0Kf5QztEnhAs:
				if '//' in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = 'http:'+ekTrZlFMu0Kf5QztEnhAs
				else: ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+name+'__watch'
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(EaBeVhOsHYg8wub,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if not search:
		search = FBrXsYeCEp3()
		if not search: return
	if ' ' in search:
		if showDialogs: xl9MFt1AmY0GrkENug8n('','','TVFUN موقع تيفي فان','للأسف البحث في هذا الموقع لا يعمل عند طلب أكثر من كلمة واحدة ... يرجى البحث عن كلمة واحدة فقط')
		return
	url = yONJxHER9BIDPpTV4YsWmc0n+'/q/'+search+'/'
	ll0a2AwztChcpsDUMi4rGW3b61XZES(url)
	return
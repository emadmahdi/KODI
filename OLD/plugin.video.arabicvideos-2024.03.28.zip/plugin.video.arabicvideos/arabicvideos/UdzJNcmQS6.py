# -*- coding: utf-8 -*-
from LXgKztbkOf import *
ERLBl7fGCXQYchpgj6d = 'FAVORITES'
def LNa8zbTyOvDQ5M(wMCm6g9qFyPT0xpneDUNc2lEhaZY,vw47K0zWuGNZpPd9R):
	if   wMCm6g9qFyPT0xpneDUNc2lEhaZY==270: QZSU5eYbuF2miCW8Dh67yHnMtOA = TWdJepU45bz2MXCBPrY1Km0Sfouwv9(vw47K0zWuGNZpPd9R)
	else: QZSU5eYbuF2miCW8Dh67yHnMtOA = False
	return QZSU5eYbuF2miCW8Dh67yHnMtOA
def eevqQpU5hZNB1VFjPHC6kIoTn(wWXVYjrFaCg9zpboThAMQBU8iHJc):
	if not wWXVYjrFaCg9zpboThAMQBU8iHJc: return
	if '_' in wWXVYjrFaCg9zpboThAMQBU8iHJc: vw47K0zWuGNZpPd9R,LL9RNIDJFkMS3a5OvsmfhCgowzQ4 = wWXVYjrFaCg9zpboThAMQBU8iHJc.split('_',1)
	else: vw47K0zWuGNZpPd9R,LL9RNIDJFkMS3a5OvsmfhCgowzQ4 = wWXVYjrFaCg9zpboThAMQBU8iHJc,''
	if   LL9RNIDJFkMS3a5OvsmfhCgowzQ4=='UP1'	: P19uFhRgXalQ0oZ(vw47K0zWuGNZpPd9R,True,1)
	elif LL9RNIDJFkMS3a5OvsmfhCgowzQ4=='DOWN1'	: P19uFhRgXalQ0oZ(vw47K0zWuGNZpPd9R,False,1)
	elif LL9RNIDJFkMS3a5OvsmfhCgowzQ4=='UP4'	: P19uFhRgXalQ0oZ(vw47K0zWuGNZpPd9R,True,4)
	elif LL9RNIDJFkMS3a5OvsmfhCgowzQ4=='DOWN4'	: P19uFhRgXalQ0oZ(vw47K0zWuGNZpPd9R,False,4)
	elif LL9RNIDJFkMS3a5OvsmfhCgowzQ4=='ADD1'	: TbEL7VfMaIsB2zOJuP18cnd3DmW(vw47K0zWuGNZpPd9R)
	elif LL9RNIDJFkMS3a5OvsmfhCgowzQ4=='REMOVE1': gYpQDWVmUxrFuo0lbI79JBk(vw47K0zWuGNZpPd9R)
	elif LL9RNIDJFkMS3a5OvsmfhCgowzQ4=='DELETELIST': hTFEgCZ5Uksfo1rPOW3qD4(vw47K0zWuGNZpPd9R)
	return
def TWdJepU45bz2MXCBPrY1Km0Sfouwv9(vw47K0zWuGNZpPd9R):
	aURMtGEAsq2kCQpigrL = ZIm7yNwq0DtAUbXso9Rd5hOPK()
	if vw47K0zWuGNZpPd9R in list(aURMtGEAsq2kCQpigrL.keys()):
		try:
			HHfEKOqizWArSwnGC = aURMtGEAsq2kCQpigrL[vw47K0zWuGNZpPd9R]
			for f0QP7qXsU4L9xtB,WGy8jZubInXc7zRBJ5p,GZdtFyDU0caf89r,wMCm6g9qFyPT0xpneDUNc2lEhaZY,qRSNaY0t83hO9ofLEnJuAM1,Iy4bwu3m6qORhDrQSd19HYo8,kc57B93HrojbDIXVipY,wWXVYjrFaCg9zpboThAMQBU8iHJc,isbQc5EtyP76zR in HHfEKOqizWArSwnGC:
				uQNUfbZx9yj0F(f0QP7qXsU4L9xtB,WGy8jZubInXc7zRBJ5p,GZdtFyDU0caf89r,wMCm6g9qFyPT0xpneDUNc2lEhaZY,qRSNaY0t83hO9ofLEnJuAM1,Iy4bwu3m6qORhDrQSd19HYo8,kc57B93HrojbDIXVipY,wWXVYjrFaCg9zpboThAMQBU8iHJc,isbQc5EtyP76zR)
		except:
			aURMtGEAsq2kCQpigrL = kI2poxnvzLZ0Yg8e1scBKy(MZabdxfVE5WJwUu)
			HHfEKOqizWArSwnGC = aURMtGEAsq2kCQpigrL[vw47K0zWuGNZpPd9R]
			for f0QP7qXsU4L9xtB,WGy8jZubInXc7zRBJ5p,GZdtFyDU0caf89r,wMCm6g9qFyPT0xpneDUNc2lEhaZY,qRSNaY0t83hO9ofLEnJuAM1,Iy4bwu3m6qORhDrQSd19HYo8,kc57B93HrojbDIXVipY,wWXVYjrFaCg9zpboThAMQBU8iHJc,isbQc5EtyP76zR in HHfEKOqizWArSwnGC:
				uQNUfbZx9yj0F(f0QP7qXsU4L9xtB,WGy8jZubInXc7zRBJ5p,GZdtFyDU0caf89r,wMCm6g9qFyPT0xpneDUNc2lEhaZY,qRSNaY0t83hO9ofLEnJuAM1,Iy4bwu3m6qORhDrQSd19HYo8,kc57B93HrojbDIXVipY,wWXVYjrFaCg9zpboThAMQBU8iHJc,isbQc5EtyP76zR)
	return
def TbEL7VfMaIsB2zOJuP18cnd3DmW(vw47K0zWuGNZpPd9R):
	f0QP7qXsU4L9xtB,WGy8jZubInXc7zRBJ5p,GZdtFyDU0caf89r,wMCm6g9qFyPT0xpneDUNc2lEhaZY,qRSNaY0t83hO9ofLEnJuAM1,Iy4bwu3m6qORhDrQSd19HYo8,kc57B93HrojbDIXVipY,wWXVYjrFaCg9zpboThAMQBU8iHJc,isbQc5EtyP76zR = QPTqwDCWalLdRB9jrkAbIz(O0Dm45eTJi8rlWUCQLbMducERHp)
	j57TcVZpeogCman = f0QP7qXsU4L9xtB,WGy8jZubInXc7zRBJ5p,GZdtFyDU0caf89r,wMCm6g9qFyPT0xpneDUNc2lEhaZY,qRSNaY0t83hO9ofLEnJuAM1,Iy4bwu3m6qORhDrQSd19HYo8,kc57B93HrojbDIXVipY,'',isbQc5EtyP76zR
	aURMtGEAsq2kCQpigrL = ZIm7yNwq0DtAUbXso9Rd5hOPK()
	eD3T5KkiJ4 = {}
	for u8uxGtmdZf6oScDb in list(aURMtGEAsq2kCQpigrL.keys()):
		if u8uxGtmdZf6oScDb!=vw47K0zWuGNZpPd9R: eD3T5KkiJ4[u8uxGtmdZf6oScDb] = aURMtGEAsq2kCQpigrL[u8uxGtmdZf6oScDb]
		else:
			if WGy8jZubInXc7zRBJ5p and WGy8jZubInXc7zRBJ5p!='..':
				QIJWFjftyhNolG9aH375DOpbY2w = aURMtGEAsq2kCQpigrL[u8uxGtmdZf6oScDb]
				if j57TcVZpeogCman in QIJWFjftyhNolG9aH375DOpbY2w:
					SSfJATEZOF025lG7 = QIJWFjftyhNolG9aH375DOpbY2w.index(j57TcVZpeogCman)
					del QIJWFjftyhNolG9aH375DOpbY2w[SSfJATEZOF025lG7]
				kdh2V8aSn9py1WstU6HBjM = QIJWFjftyhNolG9aH375DOpbY2w+[j57TcVZpeogCman]
				eD3T5KkiJ4[u8uxGtmdZf6oScDb] = kdh2V8aSn9py1WstU6HBjM
			else: eD3T5KkiJ4[u8uxGtmdZf6oScDb] = aURMtGEAsq2kCQpigrL[u8uxGtmdZf6oScDb]
	if vw47K0zWuGNZpPd9R not in list(eD3T5KkiJ4.keys()): eD3T5KkiJ4[vw47K0zWuGNZpPd9R] = [j57TcVZpeogCman]
	bboWlcAvVeEgFGatSy = str(eD3T5KkiJ4)
	if VVGRN7xiyj: bboWlcAvVeEgFGatSy = bboWlcAvVeEgFGatSy.encode('utf8')
	open(MZabdxfVE5WJwUu,'wb').write(bboWlcAvVeEgFGatSy)
	return
def gYpQDWVmUxrFuo0lbI79JBk(vw47K0zWuGNZpPd9R):
	f0QP7qXsU4L9xtB,WGy8jZubInXc7zRBJ5p,GZdtFyDU0caf89r,wMCm6g9qFyPT0xpneDUNc2lEhaZY,qRSNaY0t83hO9ofLEnJuAM1,Iy4bwu3m6qORhDrQSd19HYo8,kc57B93HrojbDIXVipY,wWXVYjrFaCg9zpboThAMQBU8iHJc,isbQc5EtyP76zR = QPTqwDCWalLdRB9jrkAbIz(O0Dm45eTJi8rlWUCQLbMducERHp)
	j57TcVZpeogCman = f0QP7qXsU4L9xtB,WGy8jZubInXc7zRBJ5p,GZdtFyDU0caf89r,wMCm6g9qFyPT0xpneDUNc2lEhaZY,qRSNaY0t83hO9ofLEnJuAM1,Iy4bwu3m6qORhDrQSd19HYo8,kc57B93HrojbDIXVipY,'',isbQc5EtyP76zR
	aURMtGEAsq2kCQpigrL = ZIm7yNwq0DtAUbXso9Rd5hOPK()
	if vw47K0zWuGNZpPd9R in list(aURMtGEAsq2kCQpigrL.keys()) and j57TcVZpeogCman in aURMtGEAsq2kCQpigrL[vw47K0zWuGNZpPd9R]:
		aURMtGEAsq2kCQpigrL[vw47K0zWuGNZpPd9R].remove(j57TcVZpeogCman)
		if len(aURMtGEAsq2kCQpigrL[vw47K0zWuGNZpPd9R])==0: del aURMtGEAsq2kCQpigrL[vw47K0zWuGNZpPd9R]
		bboWlcAvVeEgFGatSy = str(aURMtGEAsq2kCQpigrL)
		if VVGRN7xiyj: bboWlcAvVeEgFGatSy = bboWlcAvVeEgFGatSy.encode('utf8')
		open(MZabdxfVE5WJwUu,'wb').write(bboWlcAvVeEgFGatSy)
	return
def P19uFhRgXalQ0oZ(vw47K0zWuGNZpPd9R,iQeW3XIY0NjVJloDZrHhnK,aC14Uph7H2TKEvZ6qliuDQjOSRbc):
	f0QP7qXsU4L9xtB,WGy8jZubInXc7zRBJ5p,GZdtFyDU0caf89r,wMCm6g9qFyPT0xpneDUNc2lEhaZY,qRSNaY0t83hO9ofLEnJuAM1,Iy4bwu3m6qORhDrQSd19HYo8,kc57B93HrojbDIXVipY,wWXVYjrFaCg9zpboThAMQBU8iHJc,isbQc5EtyP76zR = QPTqwDCWalLdRB9jrkAbIz(O0Dm45eTJi8rlWUCQLbMducERHp)
	j57TcVZpeogCman = f0QP7qXsU4L9xtB,WGy8jZubInXc7zRBJ5p,GZdtFyDU0caf89r,wMCm6g9qFyPT0xpneDUNc2lEhaZY,qRSNaY0t83hO9ofLEnJuAM1,Iy4bwu3m6qORhDrQSd19HYo8,kc57B93HrojbDIXVipY,'',isbQc5EtyP76zR
	aURMtGEAsq2kCQpigrL = ZIm7yNwq0DtAUbXso9Rd5hOPK()
	if vw47K0zWuGNZpPd9R in list(aURMtGEAsq2kCQpigrL.keys()):
		QIJWFjftyhNolG9aH375DOpbY2w = aURMtGEAsq2kCQpigrL[vw47K0zWuGNZpPd9R]
		if j57TcVZpeogCman not in QIJWFjftyhNolG9aH375DOpbY2w: return
		MAGXcEdvBh = len(QIJWFjftyhNolG9aH375DOpbY2w)
		for OTxp2K4Vayb8CoUFJSWA in range(0,aC14Uph7H2TKEvZ6qliuDQjOSRbc):
			p1wZPbk9qLR3CjHfy76nGJi4rE8SKg = QIJWFjftyhNolG9aH375DOpbY2w.index(j57TcVZpeogCman)
			if iQeW3XIY0NjVJloDZrHhnK: e7gk3KvyxopT6EdhnuHFYcDZ5P1ql = p1wZPbk9qLR3CjHfy76nGJi4rE8SKg-1
			else: e7gk3KvyxopT6EdhnuHFYcDZ5P1ql = p1wZPbk9qLR3CjHfy76nGJi4rE8SKg+1
			if e7gk3KvyxopT6EdhnuHFYcDZ5P1ql>=MAGXcEdvBh: e7gk3KvyxopT6EdhnuHFYcDZ5P1ql = e7gk3KvyxopT6EdhnuHFYcDZ5P1ql-MAGXcEdvBh
			if e7gk3KvyxopT6EdhnuHFYcDZ5P1ql<0: e7gk3KvyxopT6EdhnuHFYcDZ5P1ql = e7gk3KvyxopT6EdhnuHFYcDZ5P1ql+MAGXcEdvBh
			QIJWFjftyhNolG9aH375DOpbY2w.insert(e7gk3KvyxopT6EdhnuHFYcDZ5P1ql, QIJWFjftyhNolG9aH375DOpbY2w.pop(p1wZPbk9qLR3CjHfy76nGJi4rE8SKg))
		aURMtGEAsq2kCQpigrL[vw47K0zWuGNZpPd9R] = QIJWFjftyhNolG9aH375DOpbY2w
		bboWlcAvVeEgFGatSy = str(aURMtGEAsq2kCQpigrL)
		if VVGRN7xiyj: bboWlcAvVeEgFGatSy = bboWlcAvVeEgFGatSy.encode('utf8')
		open(MZabdxfVE5WJwUu,'wb').write(bboWlcAvVeEgFGatSy)
	return
def hTFEgCZ5Uksfo1rPOW3qD4(vw47K0zWuGNZpPd9R):
	TTGDytYoQjb9OlFRzK1Ln = lLPSDywfu4axrUhvX9RQEpGtso6H0('center','','','رسالة من المبرمج','هل تريد فعلا مسح جميع محتويات قائمة المفضلة '+vw47K0zWuGNZpPd9R+' ؟!')
	if TTGDytYoQjb9OlFRzK1Ln!=1: return
	aURMtGEAsq2kCQpigrL = ZIm7yNwq0DtAUbXso9Rd5hOPK()
	if vw47K0zWuGNZpPd9R in list(aURMtGEAsq2kCQpigrL.keys()):
		del aURMtGEAsq2kCQpigrL[vw47K0zWuGNZpPd9R]
		bboWlcAvVeEgFGatSy = str(aURMtGEAsq2kCQpigrL)
		if VVGRN7xiyj: bboWlcAvVeEgFGatSy = bboWlcAvVeEgFGatSy.encode('utf8')
		open(MZabdxfVE5WJwUu,'wb').write(bboWlcAvVeEgFGatSy)
		xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','تم مسح جميع محتويات قائمة المفضلة '+vw47K0zWuGNZpPd9R)
	return
def ZIm7yNwq0DtAUbXso9Rd5hOPK():
	aURMtGEAsq2kCQpigrL = {}
	if k1t0JLRsCQ.path.exists(MZabdxfVE5WJwUu):
		tVrw4MoZXhJHvsudDl = open(MZabdxfVE5WJwUu,'rb').read()
		if VVGRN7xiyj: tVrw4MoZXhJHvsudDl = tVrw4MoZXhJHvsudDl.decode('utf8')
		aURMtGEAsq2kCQpigrL = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('dict',tVrw4MoZXhJHvsudDl)
	return aURMtGEAsq2kCQpigrL
def ffgDZB3bA9jHxR(aURMtGEAsq2kCQpigrL,j57TcVZpeogCman,qPjeYZQlprTwdH7n9K2gS0):
	f0QP7qXsU4L9xtB,WGy8jZubInXc7zRBJ5p,GZdtFyDU0caf89r,wMCm6g9qFyPT0xpneDUNc2lEhaZY,qRSNaY0t83hO9ofLEnJuAM1,Iy4bwu3m6qORhDrQSd19HYo8,kc57B93HrojbDIXVipY,wWXVYjrFaCg9zpboThAMQBU8iHJc,isbQc5EtyP76zR = j57TcVZpeogCman
	if not wMCm6g9qFyPT0xpneDUNc2lEhaZY: f0QP7qXsU4L9xtB,wMCm6g9qFyPT0xpneDUNc2lEhaZY = 'folder','260'
	VVzBMfHi5sPj,vw47K0zWuGNZpPd9R = [],''
	if 'context=' in O0Dm45eTJi8rlWUCQLbMducERHp:
		hTkQuRrVocYC2APE7bWq3 = u5h2Rckvw1E.findall('context=(\d+)',O0Dm45eTJi8rlWUCQLbMducERHp,u5h2Rckvw1E.DOTALL)
		if hTkQuRrVocYC2APE7bWq3: vw47K0zWuGNZpPd9R = str(hTkQuRrVocYC2APE7bWq3[0])
	if wMCm6g9qFyPT0xpneDUNc2lEhaZY=='270':
		vw47K0zWuGNZpPd9R = wWXVYjrFaCg9zpboThAMQBU8iHJc
		if vw47K0zWuGNZpPd9R in list(aURMtGEAsq2kCQpigrL.keys()):
			VVzBMfHi5sPj.append(('مسح قائمة مفضلة '+vw47K0zWuGNZpPd9R,'RunPlugin('+qPjeYZQlprTwdH7n9K2gS0+'&context='+vw47K0zWuGNZpPd9R+'_DELETELIST'+')'))
	else:
		if vw47K0zWuGNZpPd9R in list(aURMtGEAsq2kCQpigrL.keys()):
			count = len(aURMtGEAsq2kCQpigrL[vw47K0zWuGNZpPd9R])
			if count>1: VVzBMfHi5sPj.append(('تحريك 1 للأعلى','RunPlugin('+qPjeYZQlprTwdH7n9K2gS0+'&context='+vw47K0zWuGNZpPd9R+'_UP1)'))
			if count>4: VVzBMfHi5sPj.append(('تحريك 4 للأعلى','RunPlugin('+qPjeYZQlprTwdH7n9K2gS0+'&context='+vw47K0zWuGNZpPd9R+'_UP4)'))
			if count>1: VVzBMfHi5sPj.append(('تحريك 1 للأسفل','RunPlugin('+qPjeYZQlprTwdH7n9K2gS0+'&context='+vw47K0zWuGNZpPd9R+'_DOWN1)'))
			if count>4: VVzBMfHi5sPj.append(('تحريك 4 للأسفل','RunPlugin('+qPjeYZQlprTwdH7n9K2gS0+'&context='+vw47K0zWuGNZpPd9R+'_DOWN4)'))
		for vw47K0zWuGNZpPd9R in ['1','2','3','4','5']:
			if vw47K0zWuGNZpPd9R in list(aURMtGEAsq2kCQpigrL.keys()) and j57TcVZpeogCman in aURMtGEAsq2kCQpigrL[vw47K0zWuGNZpPd9R]:
				VVzBMfHi5sPj.append(('مسح من مفضلة '+vw47K0zWuGNZpPd9R,'RunPlugin('+qPjeYZQlprTwdH7n9K2gS0+'&context='+vw47K0zWuGNZpPd9R+'_REMOVE1)'))
			else: VVzBMfHi5sPj.append(('إضافة إلى مفضلة '+vw47K0zWuGNZpPd9R,'RunPlugin('+qPjeYZQlprTwdH7n9K2gS0+'&context='+vw47K0zWuGNZpPd9R+'_ADD1)'))
	Ovp9rLHW5mcBk = []
	for F5hUTnNL30lt68BaIHAfKgbJQo,kTQFE8xlpnAeI1fRUCiJ0m65Ltgh in VVzBMfHi5sPj:
		F5hUTnNL30lt68BaIHAfKgbJQo = '[COLOR FFFFFF00]'+F5hUTnNL30lt68BaIHAfKgbJQo+'[/COLOR]'
		Ovp9rLHW5mcBk.append((F5hUTnNL30lt68BaIHAfKgbJQo,kTQFE8xlpnAeI1fRUCiJ0m65Ltgh,))
	return Ovp9rLHW5mcBk
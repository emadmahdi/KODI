# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'WECIMA'
headers = {'User-Agent':''}
tiCRYyX1bWd40Ir3PafQu = '_WCM_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['مصارعة حرة','wwe']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==560: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==561: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,text)
	elif mode==562: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==563: vS7JufTVsBxw52 = GA2KIlbOsoYtxpkDF71(url,text)
	elif mode==564: vS7JufTVsBxw52 = WYxFZIrRp6b(url,'CATEGORIES___'+text)
	elif mode==565: vS7JufTVsBxw52 = WYxFZIrRp6b(url,'FILTERS___'+text)
	elif mode==566: vS7JufTVsBxw52 = GQsDp6PWFHRE1ki2odqrwjB0ISTLh(url)
	elif mode==569: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text,url)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع',yONJxHER9BIDPpTV4YsWmc0n,569,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فلتر محدد',yONJxHER9BIDPpTV4YsWmc0n+'/AjaxCenter/RightBar',564)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فلتر كامل',yONJxHER9BIDPpTV4YsWmc0n+'/AjaxCenter/RightBar',565)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',yONJxHER9BIDPpTV4YsWmc0n,'','','','','WECIMA-MENU-2nd')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="NavigationMenu"(.*?)class="ProductionsListButton"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('class="menu-item.*?href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if title=='': continue
			if any(c2eEflztvIX in title.lower() for c2eEflztvIX in WLI5tgXRbUPNGJCSVz0vKjBDei3): continue
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,566)
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('hoverable activable(.*?)hoverable activable',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?url\((.*?)\).*?span>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,566,pGjsvdyHfM)
	return oo9SgGkiDbs3HRn7z8
def GQsDp6PWFHRE1ki2odqrwjB0ISTLh(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',url,'','','','','WECIMA-SUBMENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	if 'class="Slider--Grid"' in oo9SgGkiDbs3HRn7z8:
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'المميزة',url,561,'','','featured')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="list--Tabsui"(.*?)div',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?i>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,561)
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(w351bKEYgZaQSUfn,type=''):
	if '::' in w351bKEYgZaQSUfn:
		UcmHDPlLWaSf,url = w351bKEYgZaQSUfn.split('::')
		NDwLctrHpYz3JBP = hmcFWJUgiAuGk(UcmHDPlLWaSf,'url')
		url = NDwLctrHpYz3JBP+url
	else: url,UcmHDPlLWaSf = w351bKEYgZaQSUfn,w351bKEYgZaQSUfn
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','WECIMA-TITLES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	if type=='featured':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="Slider--Grid"(.*?)class="list--Tabsui"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	elif type in ['filters','search']:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = [oo9SgGkiDbs3HRn7z8.replace('\\/','/').replace('\\"','"')]
	else:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"Grid--WecimaPosts"(.*?)"RightUI"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	yn8DkpE5etF3WiUmfSO = []
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('"Thumb--GridItem".*?href="(.*?)" title="(.*?)".*?url\((.*?)\)',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title,pGjsvdyHfM in items:
			if any(c2eEflztvIX in title.lower() for c2eEflztvIX in WLI5tgXRbUPNGJCSVz0vKjBDei3): continue
			pGjsvdyHfM = ffbxegm1XPSqIwp8i(pGjsvdyHfM)
			ekTrZlFMu0Kf5QztEnhAs = ffbxegm1XPSqIwp8i(ekTrZlFMu0Kf5QztEnhAs)
			title = uTUNPkVwCMKiD5gHLaj(title)
			title = ffbxegm1XPSqIwp8i(title)
			title = title.replace('مشاهدة ','')
			if '/series/' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,563,pGjsvdyHfM)
			elif 'حلقة' in title:
				zAjwuoRY98mXN6xvE = u5h2Rckvw1E.findall('(.*?) +حلقة +\d+',title,u5h2Rckvw1E.DOTALL)
				if zAjwuoRY98mXN6xvE: title = '_MOD_' + zAjwuoRY98mXN6xvE[0]
				if title not in yn8DkpE5etF3WiUmfSO:
					yn8DkpE5etF3WiUmfSO.append(title)
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,563,pGjsvdyHfM)
			else:
				uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,562,pGjsvdyHfM)
		if type=='filters':
			LTIzl7GJ3StWsN = u5h2Rckvw1E.findall('"more_button_page":(.*?),',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			if LTIzl7GJ3StWsN:
				count = LTIzl7GJ3StWsN[0]
				ekTrZlFMu0Kf5QztEnhAs = url+'/offset/'+count
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة أخرى',ekTrZlFMu0Kf5QztEnhAs,561,'','','filters')
		elif type=='':
			cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="pagination(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
			if cWafzb4HoG1Em3Jwxu6C7vZsVi:
				lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
				items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
				for ekTrZlFMu0Kf5QztEnhAs,title in items:
					if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
					title = 'صفحة '+uTUNPkVwCMKiD5gHLaj(title)
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,561)
	return
def GA2KIlbOsoYtxpkDF71(url,type=''):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','WECIMA-EPISODES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	oo9SgGkiDbs3HRn7z8 = P2o6ZDHeW790pSQqucvnxzILVUX(oo9SgGkiDbs3HRn7z8)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="Seasons--Episodes"(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not type and cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if len(items)>1:
			for ekTrZlFMu0Kf5QztEnhAs,title in items:
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,563,'','','episodes')
			return
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="Episodes--Seasons--Episodes(.*?)</singlesections>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?<episodeTitle>(.*?)</episodeTitle>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.IGNORECASE)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			title = title.strip(' ')
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,562)
	if not YD56nkJmsd:
		title = u5h2Rckvw1E.findall('<title>(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if title: title = title[0].replace(' - ماي سيما','').replace('مشاهدة ','')
		else: title = 'ملف التشغيل'
		uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,url,562)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	EaBeVhOsHYg8wub = []
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',url,'','','','','WECIMA-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	PmF0XjQN51GpKACfLgnyTv7 = u5h2Rckvw1E.findall('<span>التصنيف<.*?<a.*?">(.*?)<.*?">(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if PmF0XjQN51GpKACfLgnyTv7:
		PmF0XjQN51GpKACfLgnyTv7 = [PmF0XjQN51GpKACfLgnyTv7[0][0],PmF0XjQN51GpKACfLgnyTv7[0][1]]
		if PmF0XjQN51GpKACfLgnyTv7 and dQorkS3qBhIMDWKHl(aUVSgO2ebjwX5iqPykC,url,PmF0XjQN51GpKACfLgnyTv7): return
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="WatchServersList"(.*?)class="WatchServersEmbed"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('data-url="(.*?)".*?strong>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,name in items:
			if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
			if name=='سيرفر وي سيما': name = 'wecima'
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+name+'__watch'
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.replace('\n','').replace('\r','')
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="List--Download(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?</i>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,ohAHUqdbWFi8D1L4Xwzus0f3RYv in items:
			if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
			ohAHUqdbWFi8D1L4Xwzus0f3RYv = u5h2Rckvw1E.findall('\d\d\d+',ohAHUqdbWFi8D1L4Xwzus0f3RYv,u5h2Rckvw1E.DOTALL)
			if ohAHUqdbWFi8D1L4Xwzus0f3RYv: ohAHUqdbWFi8D1L4Xwzus0f3RYv = '____'+ohAHUqdbWFi8D1L4Xwzus0f3RYv[0]
			else: ohAHUqdbWFi8D1L4Xwzus0f3RYv = ''
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named=wecima'+'__download'+ohAHUqdbWFi8D1L4Xwzus0f3RYv
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.replace('\n','').replace('\r','')
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(EaBeVhOsHYg8wub,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search,DRcThsXYj6klruiBAVoH=''):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	search = search.replace(' ','+')
	if not DRcThsXYj6klruiBAVoH:
		DRcThsXYj6klruiBAVoH = yONJxHER9BIDPpTV4YsWmc0n
	gANn35esloKUydOipfSMC6RD2 = DRcThsXYj6klruiBAVoH+'/AjaxCenter/Searching/'+search+'/'
	ll0a2AwztChcpsDUMi4rGW3b61XZES(gANn35esloKUydOipfSMC6RD2,'search')
	return
def WYxFZIrRp6b(w351bKEYgZaQSUfn,filter):
	if '??' in w351bKEYgZaQSUfn: url = w351bKEYgZaQSUfn.split('//getposts??')[0]
	else: url = w351bKEYgZaQSUfn
	filter = filter.replace('_FORGETRESULTS_','')
	type,filter = filter.split('___',1)
	if filter=='': lvUP2GeNjyVOHKJxcBoun3Z,MoELTBDgQeaJrl0zYUmKCH = '',''
	else: lvUP2GeNjyVOHKJxcBoun3Z,MoELTBDgQeaJrl0zYUmKCH = filter.split('___')
	if type=='CATEGORIES':
		if dz05Ioe7UxDagwylQqtkVjBi[0]+'==' not in lvUP2GeNjyVOHKJxcBoun3Z: oPrhaMp7AqmNnRjlXGI = dz05Ioe7UxDagwylQqtkVjBi[0]
		for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(len(dz05Ioe7UxDagwylQqtkVjBi[0:-1])):
			if dz05Ioe7UxDagwylQqtkVjBi[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE]+'==' in lvUP2GeNjyVOHKJxcBoun3Z: oPrhaMp7AqmNnRjlXGI = dz05Ioe7UxDagwylQqtkVjBi[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE+1]
		WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&&'+oPrhaMp7AqmNnRjlXGI+'==0'
		z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&&'+oPrhaMp7AqmNnRjlXGI+'==0'
		bIYSyA3BD1o4 = WGiMcqkRetEJVrSI.strip('&&')+'___'+z3wGSEWqVy1Qh5N.strip('&&')
		TBFfiRI52ZmKwO1JLSD = mltWBSPJz5H4VRdCAa1(MoELTBDgQeaJrl0zYUmKCH,'modified_filters')
		gANn35esloKUydOipfSMC6RD2 = url+'//getposts??'+TBFfiRI52ZmKwO1JLSD
	elif type=='FILTERS':
		lv2uANOtVxE8RTa7bYHqLog1Bd = mltWBSPJz5H4VRdCAa1(lvUP2GeNjyVOHKJxcBoun3Z,'modified_values')
		lv2uANOtVxE8RTa7bYHqLog1Bd = P2o6ZDHeW790pSQqucvnxzILVUX(lv2uANOtVxE8RTa7bYHqLog1Bd)
		if MoELTBDgQeaJrl0zYUmKCH!='': MoELTBDgQeaJrl0zYUmKCH = mltWBSPJz5H4VRdCAa1(MoELTBDgQeaJrl0zYUmKCH,'modified_filters')
		if MoELTBDgQeaJrl0zYUmKCH=='': gANn35esloKUydOipfSMC6RD2 = url
		else: gANn35esloKUydOipfSMC6RD2 = url+'//getposts??'+MoELTBDgQeaJrl0zYUmKCH
		EvwpgrXHuA7nMDUz9RyGhaTOQJWZ = sw6W1OIUQSJLFHbl(gANn35esloKUydOipfSMC6RD2,w351bKEYgZaQSUfn)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'أظهار قائمة الفيديو التي تم اختيارها ',EvwpgrXHuA7nMDUz9RyGhaTOQJWZ,561,'','','filters')
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+' [[   '+lv2uANOtVxE8RTa7bYHqLog1Bd+'   ]]',EvwpgrXHuA7nMDUz9RyGhaTOQJWZ,561,'','','filters')
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',url,'','','','','WECIMA-FILTERS_MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	oo9SgGkiDbs3HRn7z8 = oo9SgGkiDbs3HRn7z8.replace('\\"','"').replace('\\/','/')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('<wecima--filter(.*?)</wecima--filter>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not cWafzb4HoG1Em3Jwxu6C7vZsVi: return
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	cGdHRiwvptVXQlzE8ZUgB0aJo9x = u5h2Rckvw1E.findall('taxonomy="(.*?)".*?<span>(.*?)<(.*?)<filterbox',lmO2YJGr6tCV+'<filterbox',u5h2Rckvw1E.DOTALL)
	dict = {}
	for Uiy0XwPusDg4vAFc35oYdfGnOrV,name,lmO2YJGr6tCV in cGdHRiwvptVXQlzE8ZUgB0aJo9x:
		name = ffbxegm1XPSqIwp8i(name)
		if 'interest' in Uiy0XwPusDg4vAFc35oYdfGnOrV: continue
		items = u5h2Rckvw1E.findall('data-term="(.*?)".*?<txt>(.*?)</txt>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if '==' not in gANn35esloKUydOipfSMC6RD2: gANn35esloKUydOipfSMC6RD2 = url
		if type=='CATEGORIES':
			if oPrhaMp7AqmNnRjlXGI!=Uiy0XwPusDg4vAFc35oYdfGnOrV: continue
			elif len(items)<=1:
				if Uiy0XwPusDg4vAFc35oYdfGnOrV==dz05Ioe7UxDagwylQqtkVjBi[-1]: ll0a2AwztChcpsDUMi4rGW3b61XZES(gANn35esloKUydOipfSMC6RD2)
				else: WYxFZIrRp6b(gANn35esloKUydOipfSMC6RD2,'CATEGORIES___'+bIYSyA3BD1o4)
				return
			else:
				EvwpgrXHuA7nMDUz9RyGhaTOQJWZ = sw6W1OIUQSJLFHbl(gANn35esloKUydOipfSMC6RD2,w351bKEYgZaQSUfn)
				if Uiy0XwPusDg4vAFc35oYdfGnOrV==dz05Ioe7UxDagwylQqtkVjBi[-1]:
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع',EvwpgrXHuA7nMDUz9RyGhaTOQJWZ,561,'','','filters')
				else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع',gANn35esloKUydOipfSMC6RD2,564,'','',bIYSyA3BD1o4)
		elif type=='FILTERS':
			WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'==0'
			z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'==0'
			bIYSyA3BD1o4 = WGiMcqkRetEJVrSI+'___'+z3wGSEWqVy1Qh5N
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+name+': الجميع',gANn35esloKUydOipfSMC6RD2,565,'','',bIYSyA3BD1o4+'_FORGETRESULTS_')
		dict[Uiy0XwPusDg4vAFc35oYdfGnOrV] = {}
		for c2eEflztvIX,q1rVywkMcKftIioS43LY in items:
			name = ffbxegm1XPSqIwp8i(name)
			q1rVywkMcKftIioS43LY = ffbxegm1XPSqIwp8i(q1rVywkMcKftIioS43LY)
			if c2eEflztvIX=='r' or c2eEflztvIX=='nc-17': continue
			if any(c2eEflztvIX in q1rVywkMcKftIioS43LY.lower() for c2eEflztvIX in WLI5tgXRbUPNGJCSVz0vKjBDei3): continue
			if 'http' in q1rVywkMcKftIioS43LY: continue
			if 'الكل' in q1rVywkMcKftIioS43LY: continue
			if 'n-a' in c2eEflztvIX: continue
			if q1rVywkMcKftIioS43LY=='': q1rVywkMcKftIioS43LY = c2eEflztvIX
			OzY3XIhgiZJsGHMkKmSj = q1rVywkMcKftIioS43LY
			SkhRwop2bcUdC9 = u5h2Rckvw1E.findall('<name>(.*?)</name>',q1rVywkMcKftIioS43LY,u5h2Rckvw1E.DOTALL)
			if SkhRwop2bcUdC9: OzY3XIhgiZJsGHMkKmSj = SkhRwop2bcUdC9[0]
			cMpjL2oavyVwKHBPn8EdhYqxSUk = name+': '+OzY3XIhgiZJsGHMkKmSj
			dict[Uiy0XwPusDg4vAFc35oYdfGnOrV][c2eEflztvIX] = cMpjL2oavyVwKHBPn8EdhYqxSUk
			WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'=='+OzY3XIhgiZJsGHMkKmSj
			z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'=='+c2eEflztvIX
			eoaO40TC7VF1tEuwjQp2x = WGiMcqkRetEJVrSI+'___'+z3wGSEWqVy1Qh5N
			if type=='FILTERS':
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+cMpjL2oavyVwKHBPn8EdhYqxSUk,url,565,'','',eoaO40TC7VF1tEuwjQp2x+'_FORGETRESULTS_')
			elif type=='CATEGORIES' and dz05Ioe7UxDagwylQqtkVjBi[-2]+'==' in lvUP2GeNjyVOHKJxcBoun3Z:
				TBFfiRI52ZmKwO1JLSD = mltWBSPJz5H4VRdCAa1(z3wGSEWqVy1Qh5N,'modified_filters')
				UcmHDPlLWaSf = url+'//getposts??'+TBFfiRI52ZmKwO1JLSD
				EvwpgrXHuA7nMDUz9RyGhaTOQJWZ = sw6W1OIUQSJLFHbl(UcmHDPlLWaSf,w351bKEYgZaQSUfn)
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+cMpjL2oavyVwKHBPn8EdhYqxSUk,EvwpgrXHuA7nMDUz9RyGhaTOQJWZ,561,'','','filters')
			else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+cMpjL2oavyVwKHBPn8EdhYqxSUk,url,564,'','',eoaO40TC7VF1tEuwjQp2x)
	return
dz05Ioe7UxDagwylQqtkVjBi = ['genre','release-year','nation']
fXdYgek4Pnc = ['mpaa','genre','release-year','category','Quality','interest','nation','language']
def sw6W1OIUQSJLFHbl(gANn35esloKUydOipfSMC6RD2,UcmHDPlLWaSf):
	if '/AjaxCenter/RightBar' in gANn35esloKUydOipfSMC6RD2: gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2.replace('/AjaxCenter/RightBar','/AjaxCenter/Filtering')
	gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2.replace('//getposts??','::/AjaxCenter/Filtering/')
	gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2.replace('==','/')
	gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2.replace('&&','/')
	return gANn35esloKUydOipfSMC6RD2
def mltWBSPJz5H4VRdCAa1(cGYIMSHDj85d3f4ZW2t0bnNkKP,mode):
	cGYIMSHDj85d3f4ZW2t0bnNkKP = cGYIMSHDj85d3f4ZW2t0bnNkKP.strip('&&')
	OXjBliFSwIQCmg47,LL3oamJbwkYcNDrH5 = {},''
	if '==' in cGYIMSHDj85d3f4ZW2t0bnNkKP:
		items = cGYIMSHDj85d3f4ZW2t0bnNkKP.split('&&')
		for TMaJdc0xOFKNf in items:
			b1EWu6sYaRk0FXUx8HVvNBQort43,c2eEflztvIX = TMaJdc0xOFKNf.split('==')
			OXjBliFSwIQCmg47[b1EWu6sYaRk0FXUx8HVvNBQort43] = c2eEflztvIX
	for key in fXdYgek4Pnc:
		if key in list(OXjBliFSwIQCmg47.keys()): c2eEflztvIX = OXjBliFSwIQCmg47[key]
		else: c2eEflztvIX = '0'
		if '%' not in c2eEflztvIX: c2eEflztvIX = QQXTVNve6DMHBp4scG170kR2lWY(c2eEflztvIX)
		if mode=='modified_values' and c2eEflztvIX!='0': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+' + '+c2eEflztvIX
		elif mode=='modified_filters' and c2eEflztvIX!='0': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+'&&'+key+'=='+c2eEflztvIX
		elif mode=='all': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+'&&'+key+'=='+c2eEflztvIX
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.strip(' + ')
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.strip('&&')
	return LL3oamJbwkYcNDrH5
# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'KATKOTTV'
tiCRYyX1bWd40Ir3PafQu = '_KTV_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
WLI5tgXRbUPNGJCSVz0vKjBDei3 = []
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==810: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==811: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,text)
	elif mode==812: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==813: vS7JufTVsBxw52 = s9FEySUQa8q(url)
	elif mode==819: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',yONJxHER9BIDPpTV4YsWmc0n,'','','','','KATKOTTV-MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',819,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"primary-links"(.*?)"most-viewed"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('href="(.*?)".*?<span>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		if title in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
		uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,811)
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,type=''):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','KATKOTTV-TITLES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"home-content"(.*?)"footer"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('"thumb".*?data-src="(.*?)".*?href="(.*?)".*?title="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		yn8DkpE5etF3WiUmfSO = []
		for pGjsvdyHfM,ekTrZlFMu0Kf5QztEnhAs,title in items:
			zAjwuoRY98mXN6xvE = u5h2Rckvw1E.findall('(.*?) (الحلقة|حلقة).\d+',title,u5h2Rckvw1E.DOTALL)
			if 'episodes' not in type and zAjwuoRY98mXN6xvE:
				title = '_MOD_' + zAjwuoRY98mXN6xvE[0][0]
				title = title.replace('اون لاين','')
				if title not in yn8DkpE5etF3WiUmfSO:
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,813,pGjsvdyHfM)
					yn8DkpE5etF3WiUmfSO.append(title)
			else: uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,812,pGjsvdyHfM)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall("'pagination'(.*?)footer",oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			title = uTUNPkVwCMKiD5gHLaj(title)
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+title,ekTrZlFMu0Kf5QztEnhAs,811,'','',type)
	return
def s9FEySUQa8q(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','KATKOTTV-SERIES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('"category".*?href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if ekTrZlFMu0Kf5QztEnhAs: ll0a2AwztChcpsDUMi4rGW3b61XZES(ekTrZlFMu0Kf5QztEnhAs[0],'episodes')
	return
def N5AOlmb8u1y4FHxvJXU(url):
	GnuaoT9MxiCg = []
	gANn35esloKUydOipfSMC6RD2 = url+'?do=watch'
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',gANn35esloKUydOipfSMC6RD2,'','','','','KATKOTTV-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('" src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if ekTrZlFMu0Kf5QztEnhAs:
		ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs[0]
		GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs)
	else:
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','KATKOTTV-PLAY-2nd')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		iXJGxum8sYHFrU = u5h2Rckvw1E.findall('post=(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if iXJGxum8sYHFrU:
			iXJGxum8sYHFrU = yB3NPc2ZhbwFEi1X0dv.b64decode(iXJGxum8sYHFrU[0])
			if VVGRN7xiyj: iXJGxum8sYHFrU = iXJGxum8sYHFrU.decode('utf8')
			iXJGxum8sYHFrU = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('dict',iXJGxum8sYHFrU)
			lQUf3AY258LeWch = iXJGxum8sYHFrU['servers']
			YMpoGJSqdLFkvb4WRuZNa65 = list(lQUf3AY258LeWch.keys())
			lQUf3AY258LeWch = list(lQUf3AY258LeWch.values())
			Cme2tRqGfkrX = zip(YMpoGJSqdLFkvb4WRuZNa65,lQUf3AY258LeWch)
			for title,ekTrZlFMu0Kf5QztEnhAs in Cme2tRqGfkrX:
				ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+title+'__watch'
				GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(GnuaoT9MxiCg,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	search = search.replace(' ','+')
	url = yONJxHER9BIDPpTV4YsWmc0n+'/?s='+search
	ll0a2AwztChcpsDUMi4rGW3b61XZES(url,'search')
	return
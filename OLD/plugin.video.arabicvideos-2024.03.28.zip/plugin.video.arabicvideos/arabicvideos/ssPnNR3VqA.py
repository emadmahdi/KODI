# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'LIVETV'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a['PYTHON'][0]
def cc03CYPLaxRfUKJb9eynFTr(mode,url):
	if   mode==100: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==101: vS7JufTVsBxw52 = tZwPW2bEz6S0OLXK84IjDYFqkde('0',True)
	elif mode==102: vS7JufTVsBxw52 = tZwPW2bEz6S0OLXK84IjDYFqkde('1',True)
	elif mode==103: vS7JufTVsBxw52 = tZwPW2bEz6S0OLXK84IjDYFqkde('2',True)
	elif mode==104: vS7JufTVsBxw52 = tZwPW2bEz6S0OLXK84IjDYFqkde('3',True)
	elif mode==105: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==106: vS7JufTVsBxw52 = tZwPW2bEz6S0OLXK84IjDYFqkde('4',True)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	uQNUfbZx9yj0F('folder','_M3U_'+'قوائم فيديوهات M3U','',762)
	uQNUfbZx9yj0F('folder','_IPT_'+'قوائم فيديوهات IPTV','',761)
	uQNUfbZx9yj0F('folder','_TV0_'+'قنوات من مواقعها الأصلية','',101)
	uQNUfbZx9yj0F('folder','_TV4_'+'قنوات مختارة من يوتيوب','',106)
	uQNUfbZx9yj0F('folder','_YUT_'+'قنوات عربية من يوتيوب','',147)
	uQNUfbZx9yj0F('folder','_YUT_'+'قنوات أجنبية من يوتيوب','',148)
	uQNUfbZx9yj0F('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ','',28)
	uQNUfbZx9yj0F('live','_MRF_'+'قناة المعارف من موقعهم','',41)
	uQNUfbZx9yj0F('live','_PNT_'+'قناة هلا من موقع بانيت','',38)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder','_TV1_'+'قنوات تلفزيونية عامة','',102)
	uQNUfbZx9yj0F('folder','_TV2_'+'قنوات تلفزيونية خاصة','',103)
	uQNUfbZx9yj0F('folder','_TV3_'+'قنوات تلفزيونية للفحص','',104)
	return
def tZwPW2bEz6S0OLXK84IjDYFqkde(GGOfdq3ejKzUl6xAuN7WsSMEJv,showDialogs=True):
	tiCRYyX1bWd40Ir3PafQu = '_TV'+GGOfdq3ejKzUl6xAuN7WsSMEJv+'_'
	hGdKt2jR8SN1z5TrZkuU = lbFixEt3BK9YGMyWIQZuSsp1V7JTL8(32)
	nD70jhRb8C9Gi = {'id':'','user':hGdKt2jR8SN1z5TrZkuU,'function':'list','menu':GGOfdq3ejKzUl6xAuN7WsSMEJv}
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'POST',yONJxHER9BIDPpTV4YsWmc0n,nD70jhRb8C9Gi,'','','','LIVETV-ITEMS-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	items = u5h2Rckvw1E.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if items:
		for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(len(items)):
			name = items[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE] = items[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE][0],items[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE][1],items[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE][2],name,items[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for BYGZC29KJ5Piag36Dl,NDwLctrHpYz3JBP,eitKAc89owDhTpUWvmBrxM6RI,name,pGjsvdyHfM in items:
			if '#' in BYGZC29KJ5Piag36Dl: continue
			if BYGZC29KJ5Piag36Dl!='URL': name = name+'[COLOR FFC89008]   '+BYGZC29KJ5Piag36Dl+'[/COLOR]'
			url = BYGZC29KJ5Piag36Dl+';;'+NDwLctrHpYz3JBP+';;'+eitKAc89owDhTpUWvmBrxM6RI+';;'+GGOfdq3ejKzUl6xAuN7WsSMEJv
			uQNUfbZx9yj0F('live',tiCRYyX1bWd40Ir3PafQu+''+name,url,105,pGjsvdyHfM)
	else:
		if showDialogs: uQNUfbZx9yj0F('link',tiCRYyX1bWd40Ir3PafQu+'هذه الخدمة مخصصة للمبرمج فقط','',9999)
	return
def N5AOlmb8u1y4FHxvJXU(id):
	BYGZC29KJ5Piag36Dl,NDwLctrHpYz3JBP,eitKAc89owDhTpUWvmBrxM6RI,GGOfdq3ejKzUl6xAuN7WsSMEJv = id.split(';;')
	url = ''
	hGdKt2jR8SN1z5TrZkuU = lbFixEt3BK9YGMyWIQZuSsp1V7JTL8(32)
	if BYGZC29KJ5Piag36Dl=='URL': url = eitKAc89owDhTpUWvmBrxM6RI
	elif BYGZC29KJ5Piag36Dl=='YOUTUBE':
		url = pgPfwZleTHVQ9a['YOUTUBE'][0]+'/watch?v='+eitKAc89owDhTpUWvmBrxM6RI
		import jSLK8GCOcy
		jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr([url],aUVSgO2ebjwX5iqPykC,'live',url)
		return
	elif BYGZC29KJ5Piag36Dl=='GA':
		nD70jhRb8C9Gi = { 'id' : '', 'user' : hGdKt2jR8SN1z5TrZkuU , 'function' : 'playGA1' , 'menu' : '' }
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',yONJxHER9BIDPpTV4YsWmc0n,nD70jhRb8C9Gi,'',False,'','LIVETV-PLAY-1st')
		if not RoQL91PphqCJg4W0e6Fnsl.succeeded:
			xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		cookies = RoQL91PphqCJg4W0e6Fnsl.cookies
		mmf4Q2J8sWg = cookies['ASP.NET_SessionId']
		url = RoQL91PphqCJg4W0e6Fnsl.headers['Location']
		nD70jhRb8C9Gi = { 'id' : eitKAc89owDhTpUWvmBrxM6RI , 'user' : hGdKt2jR8SN1z5TrZkuU , 'function' : 'playGA2' , 'menu' : '' }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+mmf4Q2J8sWg }
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',yONJxHER9BIDPpTV4YsWmc0n,nD70jhRb8C9Gi,headers,'','','LIVETV-PLAY-2nd')
		if not RoQL91PphqCJg4W0e6Fnsl.succeeded:
			xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		url = u5h2Rckvw1E.findall('resp":"(http.*?m3u8)(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		ekTrZlFMu0Kf5QztEnhAs = url[0][0]
		DDwGRHIjFzs = url[0][1]
		qNzPY3wVWnQFEp = 'http://38.'+NDwLctrHpYz3JBP+'777/'+eitKAc89owDhTpUWvmBrxM6RI+'_HD.m3u8'+DDwGRHIjFzs
		THOmnVyjqES8doAZ1IDc = qNzPY3wVWnQFEp.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		j8jRUK4eoO3nhGzME7xB5gw = qNzPY3wVWnQFEp.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		hVby8e3aQkFfuE = ['HD','SD1','SD2']
		EaBeVhOsHYg8wub = [qNzPY3wVWnQFEp,THOmnVyjqES8doAZ1IDc,j8jRUK4eoO3nhGzME7xB5gw]
		u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = 0
		if u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo == -1: return
		else: url = EaBeVhOsHYg8wub[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
	elif BYGZC29KJ5Piag36Dl=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		nD70jhRb8C9Gi = { 'id' : eitKAc89owDhTpUWvmBrxM6RI , 'user' : hGdKt2jR8SN1z5TrZkuU , 'function' : 'playNT' , 'menu' : GGOfdq3ejKzUl6xAuN7WsSMEJv }
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'POST', yONJxHER9BIDPpTV4YsWmc0n, nD70jhRb8C9Gi, headers, False,'','LIVETV-PLAY-3rd')
		if not RoQL91PphqCJg4W0e6Fnsl.succeeded:
			xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		url = RoQL91PphqCJg4W0e6Fnsl.headers['Location']
		url = url.replace('%20',' ')
		url = url.replace('%3D','=')
		if 'Learn' in eitKAc89owDhTpUWvmBrxM6RI:
			url = url.replace('NTNNile','')
			url = url.replace('learning1','Learning')
	elif BYGZC29KJ5Piag36Dl=='PL':
		nD70jhRb8C9Gi = { 'id' : eitKAc89owDhTpUWvmBrxM6RI , 'user' : hGdKt2jR8SN1z5TrZkuU , 'function' : 'playPL' , 'menu' : GGOfdq3ejKzUl6xAuN7WsSMEJv }
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'POST', yONJxHER9BIDPpTV4YsWmc0n, nD70jhRb8C9Gi, '',False,'','LIVETV-PLAY-4th')
		if not RoQL91PphqCJg4W0e6Fnsl.succeeded:
			xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		url = RoQL91PphqCJg4W0e6Fnsl.headers['Location']
		headers = {'Referer':RoQL91PphqCJg4W0e6Fnsl.headers['Referer']}
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'POST',url, '',headers , '','','LIVETV-PLAY-5th')
		if not RoQL91PphqCJg4W0e6Fnsl.succeeded:
			xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		items = u5h2Rckvw1E.findall('source src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		url = items[0]
	elif BYGZC29KJ5Piag36Dl in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if BYGZC29KJ5Piag36Dl=='TA': eitKAc89owDhTpUWvmBrxM6RI = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		nD70jhRb8C9Gi = { 'id' : eitKAc89owDhTpUWvmBrxM6RI , 'user' : hGdKt2jR8SN1z5TrZkuU , 'function' : 'play'+BYGZC29KJ5Piag36Dl , 'menu' : GGOfdq3ejKzUl6xAuN7WsSMEJv }
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'POST',yONJxHER9BIDPpTV4YsWmc0n,nD70jhRb8C9Gi,headers,'','','LIVETV-PLAY-6th')
		if not RoQL91PphqCJg4W0e6Fnsl.succeeded:
			xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		url = RoQL91PphqCJg4W0e6Fnsl.headers['Location']
		if BYGZC29KJ5Piag36Dl=='FM':
			RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'GET', url, '', '', False,'','LIVETV-PLAY-7th')
			url = RoQL91PphqCJg4W0e6Fnsl.headers['Location']
			url = url.replace('https','http')
	om1iZDWnrhGa2SLB9O4kfxYbqU(url,aUVSgO2ebjwX5iqPykC,'live')
	return
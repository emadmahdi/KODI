# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'CIMAABDO'
tiCRYyX1bWd40Ir3PafQu = '_ABD_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['الرئيسية']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==550: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==551: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,text)
	elif mode==552: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==553: vS7JufTVsBxw52 = GA2KIlbOsoYtxpkDF71(url)
	elif mode==559: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',yONJxHER9BIDPpTV4YsWmc0n+'/home','','','','','CIMAABDO-MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	jGX4sfdrWaeZpA1VyvTK = hmcFWJUgiAuGk(yONJxHER9BIDPpTV4YsWmc0n,'url')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',559,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'اخترنا لك',jGX4sfdrWaeZpA1VyvTK+'/home',551,'','','featured')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('main-content(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('data-name="(.*?)".*?</i>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for lcOov4Kz0uBairTpLxXgAqIt72mk,title in items:
		ekTrZlFMu0Kf5QztEnhAs = jGX4sfdrWaeZpA1VyvTK+'/ajax/getItem?item='+lcOov4Kz0uBairTpLxXgAqIt72mk+'&Ajax=1'
		uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,551)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"nav-main"(.*?)</nav>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		if ekTrZlFMu0Kf5QztEnhAs=='#': continue
		if title in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' in title: uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,551)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		if ekTrZlFMu0Kf5QztEnhAs=='#': continue
		if title in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' not in title: uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,551)
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,lcOov4Kz0uBairTpLxXgAqIt72mk=''):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		gANn35esloKUydOipfSMC6RD2,XfOb4VIcPY = ykfj6Qb9Fc5GiJIvelp84rHDn(url)
		emrzEIsMWO2GLw9lpKxSY7n0F = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'POST',gANn35esloKUydOipfSMC6RD2,XfOb4VIcPY,emrzEIsMWO2GLw9lpKxSY7n0F,'','','CIMAABDO-TITLES-1st')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		cWafzb4HoG1Em3Jwxu6C7vZsVi = [oo9SgGkiDbs3HRn7z8]
	else:
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','CIMAABDO-TITLES-2nd')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		if lcOov4Kz0uBairTpLxXgAqIt72mk=='featured':
			cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"container"(.*?)"container"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		elif '"section-post mb-10"' in oo9SgGkiDbs3HRn7z8:
			cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"section-post mb-10"(.*?)"container"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		else:
			cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('<article(.*?)"pagination"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not cWafzb4HoG1Em3Jwxu6C7vZsVi: return
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	if not items:
		items = u5h2Rckvw1E.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if not items: items = u5h2Rckvw1E.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	yn8DkpE5etF3WiUmfSO = []
	dR94SHEmDA8nflN = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for ekTrZlFMu0Kf5QztEnhAs,title,pGjsvdyHfM in items:
		ekTrZlFMu0Kf5QztEnhAs = P2o6ZDHeW790pSQqucvnxzILVUX(ekTrZlFMu0Kf5QztEnhAs).strip('/')
		zAjwuoRY98mXN6xvE = u5h2Rckvw1E.findall('(.*?) الحلقة \d+',title,u5h2Rckvw1E.DOTALL)
		if 'سلاسل' not in url and any(c2eEflztvIX in title for c2eEflztvIX in dR94SHEmDA8nflN):
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,552,pGjsvdyHfM)
		elif zAjwuoRY98mXN6xvE and 'الحلقة' in title:
			title = '_MOD_' + zAjwuoRY98mXN6xvE[0]
			if title not in yn8DkpE5etF3WiUmfSO:
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,553,pGjsvdyHfM)
				yn8DkpE5etF3WiUmfSO.append(title)
		elif '/movies/' in ekTrZlFMu0Kf5QztEnhAs:
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,551,pGjsvdyHfM)
		else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,553,pGjsvdyHfM)
	if lcOov4Kz0uBairTpLxXgAqIt72mk=='':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"pagination"(.*?)<footer',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,title in items:
				if ekTrZlFMu0Kf5QztEnhAs=="": continue
				if title!='': uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+title,ekTrZlFMu0Kf5QztEnhAs,551)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'هناك المزيد',url,551)
	return
def GA2KIlbOsoYtxpkDF71(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','CIMAABDO-EPISODES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	kQ7LGm5DPnH8hUdtWY = u5h2Rckvw1E.findall('"getSeasonsBySeries(.*?)"container"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	RfTOHSzgpA = u5h2Rckvw1E.findall('"list-episodes"(.*?)"container"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if kQ7LGm5DPnH8hUdtWY and '/series/' not in url:
		lmO2YJGr6tCV = kQ7LGm5DPnH8hUdtWY[0]
		items = u5h2Rckvw1E.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title,pGjsvdyHfM in items:
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,553,pGjsvdyHfM)
	elif RfTOHSzgpA:
		pGjsvdyHfM = u5h2Rckvw1E.findall('"image" src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		pGjsvdyHfM = pGjsvdyHfM[0]
		lmO2YJGr6tCV = RfTOHSzgpA[0]
		items = u5h2Rckvw1E.findall('href="(.*?)" title="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,552,pGjsvdyHfM)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	gANn35esloKUydOipfSMC6RD2 = url.replace('/movies/','/watch_movies/')
	gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2.replace('/episodes/','/watch_episodes/')
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',gANn35esloKUydOipfSMC6RD2,'','','','','CIMAABDO-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	jGX4sfdrWaeZpA1VyvTK = hmcFWJUgiAuGk(gANn35esloKUydOipfSMC6RD2,'url')
	EaBeVhOsHYg8wub = []
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"servers"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		QKdSLIz9q017ARY = u5h2Rckvw1E.findall('postID = "(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		QKdSLIz9q017ARY = QKdSLIz9q017ARY[0]
		items = u5h2Rckvw1E.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if items:
			for NDwLctrHpYz3JBP,title in items:
				title = title.replace('\n','').strip(' ')
				ekTrZlFMu0Kf5QztEnhAs = jGX4sfdrWaeZpA1VyvTK+'/ajax/getPlayer?server='+NDwLctrHpYz3JBP+'&postID='+QKdSLIz9q017ARY+'&Ajax=1'
				ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+title+'__watch'
				EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
		else:
			items = u5h2Rckvw1E.findall("getPlayerByName\('(.*?)','(.*?)'.*?\"server\">(.*?)</a>",lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for NDwLctrHpYz3JBP,y3jOMWmPYvzG,title in items:
				title = title.replace('\n','').strip(' ')
				ekTrZlFMu0Kf5QztEnhAs = jGX4sfdrWaeZpA1VyvTK+'/ajax/getPlayerByName?server='+NDwLctrHpYz3JBP+'&multipleServers='+y3jOMWmPYvzG+'&postID='+QKdSLIz9q017ARY+'&Ajax=1'
				ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+title+'__watch'
				EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"downs"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)" title="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,name in items:
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+name+'__download'
			if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = 'http:'+ekTrZlFMu0Kf5QztEnhAs
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(EaBeVhOsHYg8wub,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	search = search.replace(' ','-')
	url = yONJxHER9BIDPpTV4YsWmc0n+'/search/'+search+'.html'
	ll0a2AwztChcpsDUMi4rGW3b61XZES(url)
	return
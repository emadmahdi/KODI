# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'EGYBEST1'
tiCRYyX1bWd40Ir3PafQu = '_EB1_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['مكتبتي','ايجي بست']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,BzbaC0qYjMr2WXwsO,text):
	if   mode==770: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==771: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,BzbaC0qYjMr2WXwsO)
	elif mode==772: vS7JufTVsBxw52 = GQsDp6PWFHRE1ki2odqrwjB0ISTLh(url)
	elif mode==773: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==774: vS7JufTVsBxw52 = WYxFZIrRp6b(url,'FULL_FILTER___'+text)
	elif mode==775: vS7JufTVsBxw52 = WYxFZIrRp6b(url,'DEFINED_FILTER___'+text)
	elif mode==776: vS7JufTVsBxw52 = ZN3Wh7HABLwRIkFmyEd1Jq(url,BzbaC0qYjMr2WXwsO)
	elif mode==779: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text,url)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',779,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',yONJxHER9BIDPpTV4YsWmc0n,'','','','','EGYBEST1-MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('nav-list(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?<span>(.*?)</span>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			title = title.strip(' ')
			if any(c2eEflztvIX in title for c2eEflztvIX in WLI5tgXRbUPNGJCSVz0vKjBDei3): continue
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,771)
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('main-article(.*?)social-box',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('main-title.*?">(.*?)<.*?href="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for title,ekTrZlFMu0Kf5QztEnhAs in items:
			title = title.strip(' ')
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,771,'','mainmenu')
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('main-menu(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			title = title.strip(' ')
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,771)
	return oo9SgGkiDbs3HRn7z8
def ZN3Wh7HABLwRIkFmyEd1Jq(url,type=''):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','EGYBEST1-SEASONS_EPISODES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('main-article".*?">(.*?)<(.*?)article',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		EKhwoNlubG5A7xaJW2UOg1,Ez1AbVgerRU0YimHu45t9DI7qM,items = '','',[]
		for name,lmO2YJGr6tCV in cWafzb4HoG1Em3Jwxu6C7vZsVi:
			if 'حلقات' in name: Ez1AbVgerRU0YimHu45t9DI7qM = lmO2YJGr6tCV
			if 'مواسم' in name: EKhwoNlubG5A7xaJW2UOg1 = lmO2YJGr6tCV
		if EKhwoNlubG5A7xaJW2UOg1 and not type:
			items = u5h2Rckvw1E.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',EKhwoNlubG5A7xaJW2UOg1,u5h2Rckvw1E.DOTALL)
			if len(items)>1:
				for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,776,pGjsvdyHfM,'season')
		if Ez1AbVgerRU0YimHu45t9DI7qM and len(items)<2:
			items = u5h2Rckvw1E.findall('href="(.*?)".*?data-src="(.*?)".*?title="(.*?)"',Ez1AbVgerRU0YimHu45t9DI7qM,u5h2Rckvw1E.DOTALL)
			if items:
				for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
					uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,773,pGjsvdyHfM)
			else:
				items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',Ez1AbVgerRU0YimHu45t9DI7qM,u5h2Rckvw1E.DOTALL)
				for ekTrZlFMu0Kf5QztEnhAs,title in items:
					uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,773)
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,type=''):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','EGYBEST1-TITLES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	items,wanHtPNKCfxdoyLFQV3j2RrSmvpBZ,cGYIMSHDj85d3f4ZW2t0bnNkKP = [],False,False
	if not type:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('main-content(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('href="(.*?)".*?</i>(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,title in items:
				title = title.strip(' ')
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,771,'','submenu')
				wanHtPNKCfxdoyLFQV3j2RrSmvpBZ = True
	if not type and 'p=' not in url:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('searchform(.*?)</form>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			if wanHtPNKCfxdoyLFQV3j2RrSmvpBZ: uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فلتر محدد',url,775,'','filter')
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فلتر كامل',url,774,'','filter')
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث',url,779)
			uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			cGYIMSHDj85d3f4ZW2t0bnNkKP = True
	if not wanHtPNKCfxdoyLFQV3j2RrSmvpBZ:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('blocks(.*?)article',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
				pGjsvdyHfM = pGjsvdyHfM.strip('\n')
				ekTrZlFMu0Kf5QztEnhAs = P2o6ZDHeW790pSQqucvnxzILVUX(ekTrZlFMu0Kf5QztEnhAs)
				if '/serie/' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,776,pGjsvdyHfM,'season')
				else: uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,773,pGjsvdyHfM)
			BzbaC0qYjMr2WXwsO = '1'
			if 'p=' in url: url,BzbaC0qYjMr2WXwsO = url.split('p=',1)
			AO76Z1XEaSDjomRwK = '&' if '?' in url else '?'
			url = url+AO76Z1XEaSDjomRwK
			url = url.replace('?&','?')
			if len(items)==40:
				url = url+'p='+str(int(BzbaC0qYjMr2WXwsO)+1)
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الصفحة التالية',url,771)
			elif BzbaC0qYjMr2WXwsO!='1':
				url = url+'p='+str(int(BzbaC0qYjMr2WXwsO)-1)
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الصفحة السابقة',url,771)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'GET',url,'','','','','EGYBEST1-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	PmF0XjQN51GpKACfLgnyTv7 = u5h2Rckvw1E.findall('<label>التصنيف</label>.*?">(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if PmF0XjQN51GpKACfLgnyTv7 and dQorkS3qBhIMDWKHl(aUVSgO2ebjwX5iqPykC,url,PmF0XjQN51GpKACfLgnyTv7): return
	kPpGr0QERz4tyh3C,GnuaoT9MxiCg,ZIB1Cc3wFoi5xYNgOThn2mAM = [],[],[]
	ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('video-play-iframe.*?src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if ekTrZlFMu0Kf5QztEnhAs:
		ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs[0]
		if ekTrZlFMu0Kf5QztEnhAs not in ZIB1Cc3wFoi5xYNgOThn2mAM:
			ZIB1Cc3wFoi5xYNgOThn2mAM.append(ekTrZlFMu0Kf5QztEnhAs)
			GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs+'?named=__embed')
	items = u5h2Rckvw1E.findall('"tr flex-start".*?<div>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</div>.*?href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	for ohAHUqdbWFi8D1L4Xwzus0f3RYv,ekTrZlFMu0Kf5QztEnhAs in items:
		if ekTrZlFMu0Kf5QztEnhAs not in ZIB1Cc3wFoi5xYNgOThn2mAM:
			ZIB1Cc3wFoi5xYNgOThn2mAM.append(ekTrZlFMu0Kf5QztEnhAs)
			ohAHUqdbWFi8D1L4Xwzus0f3RYv = ohAHUqdbWFi8D1L4Xwzus0f3RYv.strip(' ')
			NDwLctrHpYz3JBP = hmcFWJUgiAuGk(ekTrZlFMu0Kf5QztEnhAs,'name')
			GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs+'?named='+NDwLctrHpYz3JBP+'__download____'+ohAHUqdbWFi8D1L4Xwzus0f3RYv)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(GnuaoT9MxiCg,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search,url=''):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if not search: search = FBrXsYeCEp3()
	if not search: return
	GHFUMEOSrvhmIoVWxwN8j4 = search.replace(' ','%20')
	if not url: url = yONJxHER9BIDPpTV4YsWmc0n+'/search?query='+GHFUMEOSrvhmIoVWxwN8j4
	else: url = url+'?title='+GHFUMEOSrvhmIoVWxwN8j4+'&genre=&year=&lang='
	ll0a2AwztChcpsDUMi4rGW3b61XZES(url,'search')
	return
def C50mPGacMg7V34she6UR8LjfSt1(url):
	url = url.split('/smartemadfilter?')[0]
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',url,'','','','','EGYBEST1-GET_FILTERS_BLOCKS-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cGdHRiwvptVXQlzE8ZUgB0aJo9x = []
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('form-row(.*?)</form>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		cGdHRiwvptVXQlzE8ZUgB0aJo9x = u5h2Rckvw1E.findall('select name="(.*?)".*?value>(.*?)<(.*?)</select',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		r502OcNXkfwEI1suJF8mWTK9Vp7RlA,woSL8eJ219qdksrZFIaPA,ppZ9muD1GkPnFRX52jxBUIy = zip(*cGdHRiwvptVXQlzE8ZUgB0aJo9x)
		cGdHRiwvptVXQlzE8ZUgB0aJo9x = zip(woSL8eJ219qdksrZFIaPA,r502OcNXkfwEI1suJF8mWTK9Vp7RlA,ppZ9muD1GkPnFRX52jxBUIy)
	return cGdHRiwvptVXQlzE8ZUgB0aJo9x
def zzsLCt0FpUQEeMoYWBqGlZJP6rn4(lmO2YJGr6tCV):
	items = u5h2Rckvw1E.findall('value="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	return items
def BiOwcEL7XY1Fa5nWJ(url):
	url = url.replace('/smartemadfilter?','?title=&')
	return url
lKLq39dBYWsOr7kGypxM6Dw = ['year','lang','genre']
FAbV2PnyJD8M0UowB9hRS4TkN = ['year','lang','genre']
def WYxFZIrRp6b(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': lvUP2GeNjyVOHKJxcBoun3Z,MoELTBDgQeaJrl0zYUmKCH = '',''
	else: lvUP2GeNjyVOHKJxcBoun3Z,MoELTBDgQeaJrl0zYUmKCH = filter.split('___')
	if type=='DEFINED_FILTER':
		if FAbV2PnyJD8M0UowB9hRS4TkN[0]+'=' not in lvUP2GeNjyVOHKJxcBoun3Z: oPrhaMp7AqmNnRjlXGI = FAbV2PnyJD8M0UowB9hRS4TkN[0]
		for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(len(FAbV2PnyJD8M0UowB9hRS4TkN[0:-1])):
			if FAbV2PnyJD8M0UowB9hRS4TkN[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE]+'=' in lvUP2GeNjyVOHKJxcBoun3Z: oPrhaMp7AqmNnRjlXGI = FAbV2PnyJD8M0UowB9hRS4TkN[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE+1]
		WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&'+oPrhaMp7AqmNnRjlXGI+'=0'
		z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&'+oPrhaMp7AqmNnRjlXGI+'=0'
		bIYSyA3BD1o4 = WGiMcqkRetEJVrSI.strip('&')+'___'+z3wGSEWqVy1Qh5N.strip('&')
		TBFfiRI52ZmKwO1JLSD = mltWBSPJz5H4VRdCAa1(MoELTBDgQeaJrl0zYUmKCH,'all')
		gANn35esloKUydOipfSMC6RD2 = url+'/smartemadfilter?'+TBFfiRI52ZmKwO1JLSD
	elif type=='FULL_FILTER':
		lv2uANOtVxE8RTa7bYHqLog1Bd = mltWBSPJz5H4VRdCAa1(lvUP2GeNjyVOHKJxcBoun3Z,'modified_values')
		lv2uANOtVxE8RTa7bYHqLog1Bd = P2o6ZDHeW790pSQqucvnxzILVUX(lv2uANOtVxE8RTa7bYHqLog1Bd)
		if MoELTBDgQeaJrl0zYUmKCH: MoELTBDgQeaJrl0zYUmKCH = mltWBSPJz5H4VRdCAa1(MoELTBDgQeaJrl0zYUmKCH,'all')
		if not MoELTBDgQeaJrl0zYUmKCH: gANn35esloKUydOipfSMC6RD2 = url
		else: gANn35esloKUydOipfSMC6RD2 = url+'/smartemadfilter?'+MoELTBDgQeaJrl0zYUmKCH
		UcmHDPlLWaSf = BiOwcEL7XY1Fa5nWJ(gANn35esloKUydOipfSMC6RD2)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'أظهار قائمة الفيديو التي تم اختيارها ',UcmHDPlLWaSf,771,'','filter')
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+' [[   '+lv2uANOtVxE8RTa7bYHqLog1Bd+'   ]]',UcmHDPlLWaSf,771,'','filter')
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cGdHRiwvptVXQlzE8ZUgB0aJo9x = C50mPGacMg7V34she6UR8LjfSt1(url)
	dict = {}
	for name,Uiy0XwPusDg4vAFc35oYdfGnOrV,lmO2YJGr6tCV in cGdHRiwvptVXQlzE8ZUgB0aJo9x:
		name = name.replace('كل ','')
		items = zzsLCt0FpUQEeMoYWBqGlZJP6rn4(lmO2YJGr6tCV)
		if '=' not in gANn35esloKUydOipfSMC6RD2: gANn35esloKUydOipfSMC6RD2 = url
		if type=='DEFINED_FILTER':
			if oPrhaMp7AqmNnRjlXGI!=Uiy0XwPusDg4vAFc35oYdfGnOrV: continue
			elif len(items)<2:
				if Uiy0XwPusDg4vAFc35oYdfGnOrV==FAbV2PnyJD8M0UowB9hRS4TkN[-1]:
					UcmHDPlLWaSf = BiOwcEL7XY1Fa5nWJ(gANn35esloKUydOipfSMC6RD2)
					ll0a2AwztChcpsDUMi4rGW3b61XZES(UcmHDPlLWaSf)
				else: WYxFZIrRp6b(gANn35esloKUydOipfSMC6RD2,'DEFINED_FILTER___'+bIYSyA3BD1o4)
				return
			else:
				if Uiy0XwPusDg4vAFc35oYdfGnOrV==FAbV2PnyJD8M0UowB9hRS4TkN[-1]:
					UcmHDPlLWaSf = BiOwcEL7XY1Fa5nWJ(gANn35esloKUydOipfSMC6RD2)
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع ',UcmHDPlLWaSf,771,'','filter')
				else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع ',gANn35esloKUydOipfSMC6RD2,775,'','',bIYSyA3BD1o4)
		elif type=='FULL_FILTER':
			WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'=0'
			z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'=0'
			bIYSyA3BD1o4 = WGiMcqkRetEJVrSI+'___'+z3wGSEWqVy1Qh5N
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع :'+name,gANn35esloKUydOipfSMC6RD2,774,'','',bIYSyA3BD1o4)
		dict[Uiy0XwPusDg4vAFc35oYdfGnOrV] = {}
		for c2eEflztvIX,q1rVywkMcKftIioS43LY in items:
			if not c2eEflztvIX: continue
			if q1rVywkMcKftIioS43LY in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
			dict[Uiy0XwPusDg4vAFc35oYdfGnOrV][c2eEflztvIX] = q1rVywkMcKftIioS43LY
			WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'='+q1rVywkMcKftIioS43LY
			z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'='+c2eEflztvIX
			eoaO40TC7VF1tEuwjQp2x = WGiMcqkRetEJVrSI+'___'+z3wGSEWqVy1Qh5N
			title = q1rVywkMcKftIioS43LY+' :'#+dict[Uiy0XwPusDg4vAFc35oYdfGnOrV]['0']
			title = q1rVywkMcKftIioS43LY+' :'+name
			if type=='FULL_FILTER': uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,774,'','',eoaO40TC7VF1tEuwjQp2x)
			elif type=='DEFINED_FILTER' and FAbV2PnyJD8M0UowB9hRS4TkN[-2]+'=' in lvUP2GeNjyVOHKJxcBoun3Z:
				TBFfiRI52ZmKwO1JLSD = mltWBSPJz5H4VRdCAa1(z3wGSEWqVy1Qh5N,'modified_filters')
				gANn35esloKUydOipfSMC6RD2 = url+'/smartemadfilter?'+TBFfiRI52ZmKwO1JLSD
				UcmHDPlLWaSf = BiOwcEL7XY1Fa5nWJ(gANn35esloKUydOipfSMC6RD2)
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,UcmHDPlLWaSf,771,'','filter')
			elif type=='DEFINED_FILTER': uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,775,'','',eoaO40TC7VF1tEuwjQp2x)
	return
def mltWBSPJz5H4VRdCAa1(cGYIMSHDj85d3f4ZW2t0bnNkKP,mode):
	cGYIMSHDj85d3f4ZW2t0bnNkKP = cGYIMSHDj85d3f4ZW2t0bnNkKP.replace('=&','=0&')
	cGYIMSHDj85d3f4ZW2t0bnNkKP = cGYIMSHDj85d3f4ZW2t0bnNkKP.strip('&')
	OXjBliFSwIQCmg47 = {}
	if '=' in cGYIMSHDj85d3f4ZW2t0bnNkKP:
		items = cGYIMSHDj85d3f4ZW2t0bnNkKP.split('&')
		for TMaJdc0xOFKNf in items:
			b1EWu6sYaRk0FXUx8HVvNBQort43,c2eEflztvIX = TMaJdc0xOFKNf.split('=')
			OXjBliFSwIQCmg47[b1EWu6sYaRk0FXUx8HVvNBQort43] = c2eEflztvIX
	LL3oamJbwkYcNDrH5 = ''
	for key in lKLq39dBYWsOr7kGypxM6Dw:
		if key in list(OXjBliFSwIQCmg47.keys()): c2eEflztvIX = OXjBliFSwIQCmg47[key]
		else: c2eEflztvIX = '0'
		if '%' not in c2eEflztvIX: c2eEflztvIX = QQXTVNve6DMHBp4scG170kR2lWY(c2eEflztvIX)
		if mode=='modified_values' and c2eEflztvIX!='0': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+' + '+c2eEflztvIX
		elif mode=='modified_filters' and c2eEflztvIX!='0': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+'&'+key+'='+c2eEflztvIX
		elif mode=='all': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+'&'+key+'='+c2eEflztvIX
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.strip(' + ')
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.strip('&')
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.replace('=0','=')
	return LL3oamJbwkYcNDrH5
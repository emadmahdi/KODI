# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'EGYBEST'
tiCRYyX1bWd40Ir3PafQu = '_EGB_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
headers = {'User-Agent':'Mozilla/5.0'}
def cc03CYPLaxRfUKJb9eynFTr(mode,url,BzbaC0qYjMr2WXwsO,text):
	if   mode==120: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==121: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,BzbaC0qYjMr2WXwsO)
	elif mode==122: vS7JufTVsBxw52 = GQsDp6PWFHRE1ki2odqrwjB0ISTLh(url)
	elif mode==123: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==124: vS7JufTVsBxw52 = WYxFZIrRp6b(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==125: vS7JufTVsBxw52 = WYxFZIrRp6b(url,'SPECIFIED_FILTER___'+text)
	elif mode==129: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',129,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',yONJxHER9BIDPpTV4YsWmc0n,'',headers,'','','EGYBEST-MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="i i-home"(.*?)class="i i-folder"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if 'المصارعة' in title: continue
			title = title.rsplit('>',1)[1]
			title = title.strip(' ')
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.rstrip('/')
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,122)
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('id="mainLoad"(.*?)class="verticalDynamic"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		for title,ekTrZlFMu0Kf5QztEnhAs in items:
			title = title.strip(' ')
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.rstrip('/')
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
			if 'المصارعة' in title: continue
			if 'facebook' in ekTrZlFMu0Kf5QztEnhAs: continue
			if not title and '/tv/arabic' in ekTrZlFMu0Kf5QztEnhAs: title = 'مسلسلات عربية'
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,121)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="ba(.*?)>EgyBest</a>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
			title = title.strip(' ')
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,121)
	return oo9SgGkiDbs3HRn7z8
def GQsDp6PWFHRE1ki2odqrwjB0ISTLh(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',url,'',headers,'','','EGYBEST-SUBMENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="rs_scroll"(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('href="(.*?)".*?</i>(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	if 'trending' not in url:
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فلتر محدد',url,125)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فلتر كامل',url,124)
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,121)
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,BzbaC0qYjMr2WXwsO='1'):
	if not BzbaC0qYjMr2WXwsO: BzbaC0qYjMr2WXwsO = '1'
	if '/explore/' in url or '?' in url: gANn35esloKUydOipfSMC6RD2 = url + '&'
	else: gANn35esloKUydOipfSMC6RD2 = url + '?'
	gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2 + 'output_format=json&output_mode=movies_list&page='+BzbaC0qYjMr2WXwsO
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',gANn35esloKUydOipfSMC6RD2,'',headers,'','','EGYBEST-TITLES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	name,items = '',[]
	if '/season/' in url:
		name = u5h2Rckvw1E.findall('<h1>(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if name: name = ffbxegm1XPSqIwp8i(name[0]).strip(' ') + ' - '
		else: name = bMIascyFJ2x43E0C7glTB91h8qz.getInfoLabel( "ListItem.Label" ) + ' - '
	if '/season' not in url: items = u5h2Rckvw1E.findall('<a href=\\\\"(\\\\\/season.*?)\\\\".*?src=\\\\"(.*?)\\\\".*?"title\\\\">(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not items: items = u5h2Rckvw1E.findall('<a href=\\\\"(.*?)\\\\".*?src=\\\\"(.*?)\\\\".*?title\\\\">(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
		if '/series/' in url and '/season\/' not in ekTrZlFMu0Kf5QztEnhAs: continue
		if '/season/' in url and '/episode\/' not in ekTrZlFMu0Kf5QztEnhAs: continue
		title = name+ffbxegm1XPSqIwp8i(title).strip(' ')
		ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.replace('\/','/')
		pGjsvdyHfM = pGjsvdyHfM.replace('\/','/')
		if 'http' not in pGjsvdyHfM: pGjsvdyHfM = 'http:'+pGjsvdyHfM
		gANn35esloKUydOipfSMC6RD2 = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
		if '/movie/' in gANn35esloKUydOipfSMC6RD2 or '/episode/' in gANn35esloKUydOipfSMC6RD2 or '/masrahiyat/' in url:
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,gANn35esloKUydOipfSMC6RD2.rstrip('/'),123,pGjsvdyHfM)
		else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,gANn35esloKUydOipfSMC6RD2,121,pGjsvdyHfM)
	if len(items)>=12:
		ZaGAhxzl74FSMXYN = ['/movies/','/tv/','/explore/','/trending/','/masrahiyat/']
		BzbaC0qYjMr2WXwsO = int(BzbaC0qYjMr2WXwsO)
		if any(c2eEflztvIX in url for c2eEflztvIX in ZaGAhxzl74FSMXYN):
			for Tv6UAQeCoMS in range(0,1100,100):
				if int(BzbaC0qYjMr2WXwsO/100)*100==Tv6UAQeCoMS:
					for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(Tv6UAQeCoMS,Tv6UAQeCoMS+100,10):
						if int(BzbaC0qYjMr2WXwsO/10)*10==Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE:
							for SusDjNO9Kv4rIx in range(Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE,Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE+10,1):
								if not BzbaC0qYjMr2WXwsO==SusDjNO9Kv4rIx and SusDjNO9Kv4rIx!=0:
									uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+str(SusDjNO9Kv4rIx),url,121,'',str(SusDjNO9Kv4rIx))
						elif Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE!=0: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+str(Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE),url,121,'',str(Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE))
						else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+str(1),url,121,'',str(1))
				elif Tv6UAQeCoMS!=0: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+str(Tv6UAQeCoMS),url,121,'',str(Tv6UAQeCoMS))
				else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+str(1),url,121)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	headers = {'User-Agent':'Mozilla/5.0'}
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'GET',url,'',headers,'','','EGYBEST-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	PmF0XjQN51GpKACfLgnyTv7 = u5h2Rckvw1E.findall('<td>التصنيف</td>.*?">(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if PmF0XjQN51GpKACfLgnyTv7 and dQorkS3qBhIMDWKHl(aUVSgO2ebjwX5iqPykC,url,PmF0XjQN51GpKACfLgnyTv7): return
	xf9RPF4uksKyc = u5h2Rckvw1E.findall('"og:url" content="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if xf9RPF4uksKyc: NDwLctrHpYz3JBP = hmcFWJUgiAuGk(xf9RPF4uksKyc[0],'url')
	else: NDwLctrHpYz3JBP = hmcFWJUgiAuGk(url,'url')
	hVby8e3aQkFfuE,EaBeVhOsHYg8wub = [],[]
	tJDmqZV5RXajPHg4eYprTW6 = u5h2Rckvw1E.findall('class="auto-size" src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if tJDmqZV5RXajPHg4eYprTW6:
		tJDmqZV5RXajPHg4eYprTW6 = NDwLctrHpYz3JBP+tJDmqZV5RXajPHg4eYprTW6[0]
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'GET',tJDmqZV5RXajPHg4eYprTW6,'',headers,'','','EGYBEST-PLAY-2nd')
		ZCOosjaQ8x9HDKSVGM6LwW2vy = RoQL91PphqCJg4W0e6Fnsl.content
		if 'dostream' not in ZCOosjaQ8x9HDKSVGM6LwW2vy:
			jefaP85NcF = u5h2Rckvw1E.findall('<script.*?>function(.*?)</script>',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)
			jefaP85NcF = jefaP85NcF[0]
			FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy = X2Bex86hmdrnC1Y(jefaP85NcF)
			try: PpsJ7iruhS5vEH9NxfGUVdjID,G7GiTQLgBHYhqzpvJa46dMARkcNm8,QZv5aMm1GhiL = FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy
			except:
				xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','للأسف البرنامج لم يجد ملفات الفيديو . قد يكون الموقع الأصلي قام بتحديث صفحاته والبرنامج غير قادر على قراءة الصفحات الجديدة')
				return
			G7GiTQLgBHYhqzpvJa46dMARkcNm8 = NDwLctrHpYz3JBP+G7GiTQLgBHYhqzpvJa46dMARkcNm8
			PpsJ7iruhS5vEH9NxfGUVdjID = NDwLctrHpYz3JBP+PpsJ7iruhS5vEH9NxfGUVdjID
			cookies = RoQL91PphqCJg4W0e6Fnsl.cookies
			if 'PSSID' in cookies.keys():
				pz8BToZknabmuRjYlO = cookies['PSSID']
				headers['Cookie'] = 'PSSID='+pz8BToZknabmuRjYlO
				RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'GET',PpsJ7iruhS5vEH9NxfGUVdjID,'',headers,'','','EGYBEST-PLAY-3rd')
				RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'POST',G7GiTQLgBHYhqzpvJa46dMARkcNm8,QZv5aMm1GhiL,headers,'','','EGYBEST-PLAY-4th')
				RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'GET',tJDmqZV5RXajPHg4eYprTW6,'',headers,'','','EGYBEST-PLAY-5th')
				ZCOosjaQ8x9HDKSVGM6LwW2vy = RoQL91PphqCJg4W0e6Fnsl.content
		StjGOQVA4dui5h = u5h2Rckvw1E.findall('source src="(.*?)"',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)
		if StjGOQVA4dui5h:
			StjGOQVA4dui5h = NDwLctrHpYz3JBP+StjGOQVA4dui5h[0]
			hVby8e3aQkFfuE,EaBeVhOsHYg8wub = bkz2aCFLpWqGUcPolSXA980O(StjGOQVA4dui5h,headers)
			ZmWIcGhdFzNivK29EuB70DVC5Q = zip(hVby8e3aQkFfuE,EaBeVhOsHYg8wub)
			hVby8e3aQkFfuE,EaBeVhOsHYg8wub = [],[]
			for title,ekTrZlFMu0Kf5QztEnhAs in ZmWIcGhdFzNivK29EuB70DVC5Q:
				ohAHUqdbWFi8D1L4Xwzus0f3RYv = title.split('  ')[1]
				EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs+'?named=vidstream__watch__m3u8__'+ohAHUqdbWFi8D1L4Xwzus0f3RYv)
				cRnMDKgET5ySzox7aO6JZAqN9fk = ekTrZlFMu0Kf5QztEnhAs.replace('/stream/','/dl/').replace('/stream.m3u8','')
				EaBeVhOsHYg8wub.append(cRnMDKgET5ySzox7aO6JZAqN9fk+'?named=vidstream__download__mp4__'+ohAHUqdbWFi8D1L4Xwzus0f3RYv)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(EaBeVhOsHYg8wub,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	GHFUMEOSrvhmIoVWxwN8j4 = search.replace(' ','+')
	url = yONJxHER9BIDPpTV4YsWmc0n + '/explore/?q=' + GHFUMEOSrvhmIoVWxwN8j4
	ll0a2AwztChcpsDUMi4rGW3b61XZES(url)
	return
BVNnjYeCa3AfgTv0u6R = ['النوع','السنة','البلد']
mwqMBcOe2Lj = ['السنة','اللغة','البلد','الدقة','الجودة','الترجمة','النوع','التصنيف']
WLI5tgXRbUPNGJCSVz0vKjBDei3 = []
def C50mPGacMg7V34she6UR8LjfSt1(url):
	url = url.split('/smartemadfilter?')[0]
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',url,'',headers,'','','EGYBEST-GET_FILTERS_BLOCKS-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="dropdown"(.*?)id="movies"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	ZmWIcGhdFzNivK29EuB70DVC5Q = u5h2Rckvw1E.findall('class="current_opt">(.*?)<(.*?)</div></div>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	UoA3QGS895qNfMV4,dR8WhH7kNtYLuiQOlayvJ6VZAGM13p = zip(*ZmWIcGhdFzNivK29EuB70DVC5Q)
	cGdHRiwvptVXQlzE8ZUgB0aJo9x = zip(UoA3QGS895qNfMV4,dR8WhH7kNtYLuiQOlayvJ6VZAGM13p,UoA3QGS895qNfMV4)
	return cGdHRiwvptVXQlzE8ZUgB0aJo9x
def zzsLCt0FpUQEeMoYWBqGlZJP6rn4(lmO2YJGr6tCV):
	items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	hjEQkrAf4V3D = []
	for ekTrZlFMu0Kf5QztEnhAs,name in items:
		name = name.strip(' ')
		c2eEflztvIX = ekTrZlFMu0Kf5QztEnhAs.rsplit('/',1)[1]
		if name in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
		if 'للكبار' in name: continue
		if 'TV-MA' in name: continue
		if 'TV-14' in name: continue
		hjEQkrAf4V3D.append((c2eEflztvIX,name))
	return hjEQkrAf4V3D
def VVTeCG1Jbu7B(z3wGSEWqVy1Qh5N,url):
	url = url.split('/smartemadfilter?',1)[0]
	url = url.strip('/')
	TBFfiRI52ZmKwO1JLSD = mltWBSPJz5H4VRdCAa1(z3wGSEWqVy1Qh5N,'modified_values')
	TBFfiRI52ZmKwO1JLSD = TBFfiRI52ZmKwO1JLSD.replace(' + ','-')
	url = url+'/'+TBFfiRI52ZmKwO1JLSD
	return url
def WYxFZIrRp6b(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': lvUP2GeNjyVOHKJxcBoun3Z,MoELTBDgQeaJrl0zYUmKCH = '',''
	else: lvUP2GeNjyVOHKJxcBoun3Z,MoELTBDgQeaJrl0zYUmKCH = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if BVNnjYeCa3AfgTv0u6R[0]+'=' not in lvUP2GeNjyVOHKJxcBoun3Z: oPrhaMp7AqmNnRjlXGI = BVNnjYeCa3AfgTv0u6R[0]
		for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(len(BVNnjYeCa3AfgTv0u6R[0:-1])):
			if BVNnjYeCa3AfgTv0u6R[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE]+'=' in lvUP2GeNjyVOHKJxcBoun3Z: oPrhaMp7AqmNnRjlXGI = BVNnjYeCa3AfgTv0u6R[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE+1]
		WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&'+oPrhaMp7AqmNnRjlXGI+'=0'
		z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&'+oPrhaMp7AqmNnRjlXGI+'=0'
		bIYSyA3BD1o4 = WGiMcqkRetEJVrSI.strip('&')+'___'+z3wGSEWqVy1Qh5N.strip('&')
		TBFfiRI52ZmKwO1JLSD = mltWBSPJz5H4VRdCAa1(MoELTBDgQeaJrl0zYUmKCH,'modified_filters')
		gANn35esloKUydOipfSMC6RD2 = url+'/smartemadfilter?'+TBFfiRI52ZmKwO1JLSD
	elif type=='ALL_ITEMS_FILTER':
		lv2uANOtVxE8RTa7bYHqLog1Bd = mltWBSPJz5H4VRdCAa1(lvUP2GeNjyVOHKJxcBoun3Z,'modified_values')
		lv2uANOtVxE8RTa7bYHqLog1Bd = P2o6ZDHeW790pSQqucvnxzILVUX(lv2uANOtVxE8RTa7bYHqLog1Bd)
		if MoELTBDgQeaJrl0zYUmKCH: MoELTBDgQeaJrl0zYUmKCH = mltWBSPJz5H4VRdCAa1(MoELTBDgQeaJrl0zYUmKCH,'modified_filters')
		if not MoELTBDgQeaJrl0zYUmKCH: gANn35esloKUydOipfSMC6RD2 = url
		else: gANn35esloKUydOipfSMC6RD2 = url+'/smartemadfilter?'+MoELTBDgQeaJrl0zYUmKCH
		UcmHDPlLWaSf = VVTeCG1Jbu7B(MoELTBDgQeaJrl0zYUmKCH,gANn35esloKUydOipfSMC6RD2)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'أظهار قائمة الفيديو التي تم اختيارها ',UcmHDPlLWaSf,121)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+' [[   '+lv2uANOtVxE8RTa7bYHqLog1Bd+'   ]]',UcmHDPlLWaSf,121)
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cGdHRiwvptVXQlzE8ZUgB0aJo9x = C50mPGacMg7V34she6UR8LjfSt1(url)
	dict = {}
	for name,lmO2YJGr6tCV,Uiy0XwPusDg4vAFc35oYdfGnOrV in cGdHRiwvptVXQlzE8ZUgB0aJo9x:
		Uiy0XwPusDg4vAFc35oYdfGnOrV = Uiy0XwPusDg4vAFc35oYdfGnOrV.strip(' ')
		name = name.strip(' ')
		name = name.replace('--','')
		items = zzsLCt0FpUQEeMoYWBqGlZJP6rn4(lmO2YJGr6tCV)
		if '=' not in gANn35esloKUydOipfSMC6RD2: gANn35esloKUydOipfSMC6RD2 = url
		if type=='SPECIFIED_FILTER':
			if oPrhaMp7AqmNnRjlXGI!=Uiy0XwPusDg4vAFc35oYdfGnOrV: continue
			elif len(items)<2:
				if Uiy0XwPusDg4vAFc35oYdfGnOrV==BVNnjYeCa3AfgTv0u6R[-1]:
					UcmHDPlLWaSf = VVTeCG1Jbu7B(MoELTBDgQeaJrl0zYUmKCH,url)
					ll0a2AwztChcpsDUMi4rGW3b61XZES(UcmHDPlLWaSf)
				else: WYxFZIrRp6b(gANn35esloKUydOipfSMC6RD2,'SPECIFIED_FILTER___'+bIYSyA3BD1o4)
				return
			else:
				UcmHDPlLWaSf = VVTeCG1Jbu7B(MoELTBDgQeaJrl0zYUmKCH,gANn35esloKUydOipfSMC6RD2)
				if Uiy0XwPusDg4vAFc35oYdfGnOrV==BVNnjYeCa3AfgTv0u6R[-1]: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع ',UcmHDPlLWaSf,121)
				else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع ',gANn35esloKUydOipfSMC6RD2,125,'','',bIYSyA3BD1o4)
		elif type=='ALL_ITEMS_FILTER':
			WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'=0'
			z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'=0'
			bIYSyA3BD1o4 = WGiMcqkRetEJVrSI+'___'+z3wGSEWqVy1Qh5N
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع :'+name,gANn35esloKUydOipfSMC6RD2,124,'','',bIYSyA3BD1o4)
		dict[Uiy0XwPusDg4vAFc35oYdfGnOrV] = {}
		for c2eEflztvIX,q1rVywkMcKftIioS43LY in items:
			dict[Uiy0XwPusDg4vAFc35oYdfGnOrV][c2eEflztvIX] = q1rVywkMcKftIioS43LY
			WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'='+q1rVywkMcKftIioS43LY
			z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'='+c2eEflztvIX
			eoaO40TC7VF1tEuwjQp2x = WGiMcqkRetEJVrSI+'___'+z3wGSEWqVy1Qh5N
			title = q1rVywkMcKftIioS43LY+' :'+name
			if type=='ALL_ITEMS_FILTER': uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,124,'','',eoaO40TC7VF1tEuwjQp2x)
			elif type=='SPECIFIED_FILTER' and BVNnjYeCa3AfgTv0u6R[-2]+'=' in lvUP2GeNjyVOHKJxcBoun3Z:
				UcmHDPlLWaSf = VVTeCG1Jbu7B(z3wGSEWqVy1Qh5N,url)
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,UcmHDPlLWaSf,121)
			else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,125,'','',eoaO40TC7VF1tEuwjQp2x)
	return
def mltWBSPJz5H4VRdCAa1(cGYIMSHDj85d3f4ZW2t0bnNkKP,mode):
	cGYIMSHDj85d3f4ZW2t0bnNkKP = cGYIMSHDj85d3f4ZW2t0bnNkKP.replace('=&','=0&')
	cGYIMSHDj85d3f4ZW2t0bnNkKP = cGYIMSHDj85d3f4ZW2t0bnNkKP.strip('&')
	OXjBliFSwIQCmg47 = {}
	if '=' in cGYIMSHDj85d3f4ZW2t0bnNkKP:
		items = cGYIMSHDj85d3f4ZW2t0bnNkKP.split('&')
		for TMaJdc0xOFKNf in items:
			b1EWu6sYaRk0FXUx8HVvNBQort43,c2eEflztvIX = TMaJdc0xOFKNf.split('=')
			OXjBliFSwIQCmg47[b1EWu6sYaRk0FXUx8HVvNBQort43] = c2eEflztvIX
	LL3oamJbwkYcNDrH5 = ''
	for key in mwqMBcOe2Lj:
		if key in list(OXjBliFSwIQCmg47.keys()): c2eEflztvIX = OXjBliFSwIQCmg47[key]
		else: c2eEflztvIX = '0'
		if '%' not in c2eEflztvIX: c2eEflztvIX = QQXTVNve6DMHBp4scG170kR2lWY(c2eEflztvIX)
		if mode=='modified_values' and c2eEflztvIX!='0': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+' + '+c2eEflztvIX
		elif mode=='modified_filters' and c2eEflztvIX!='0': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+'&'+key+'='+c2eEflztvIX
		elif mode=='all_filters': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+'&'+key+'='+c2eEflztvIX
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.strip(' + ')
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.strip('&')
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.replace('=0','=')
	return LL3oamJbwkYcNDrH5
def v2KxZUmECw9uFT5flPLd6(EHqBRSkwnZJ6eA0UG9):
	OiEwjXGAM5W60f = u5h2Rckvw1E.search(r'^(\d+)[.,]?\d*?', str(EHqBRSkwnZJ6eA0UG9))
	return int(OiEwjXGAM5W60f.groups()[-1]) if OiEwjXGAM5W60f and not callable(EHqBRSkwnZJ6eA0UG9) else 0
def HoBQfKYO3Ppn1Zs5lRbT2uNvFmk6z(DG8SXh4agibp):
	try:
		RwHC2OXESe9brGF6odtMDgihP = yB3NPc2ZhbwFEi1X0dv.b64decode(DG8SXh4agibp)
	except:
		try:
			RwHC2OXESe9brGF6odtMDgihP = yB3NPc2ZhbwFEi1X0dv.b64decode(DG8SXh4agibp+'=')
		except:
			try:
				RwHC2OXESe9brGF6odtMDgihP = yB3NPc2ZhbwFEi1X0dv.b64decode(DG8SXh4agibp+'==')
			except:
				RwHC2OXESe9brGF6odtMDgihP = 'ERR: base64 decode error'
	if VVGRN7xiyj: RwHC2OXESe9brGF6odtMDgihP = RwHC2OXESe9brGF6odtMDgihP.decode('utf8')
	return RwHC2OXESe9brGF6odtMDgihP
def nqguckdJFs8EKpS1l3(oSDMibwR2Fd0TG6COs9yvlBLm4jEa5,nx3v9l1067QD4AjefozgZwIs,s0lS5pNYIn):
	s0lS5pNYIn = s0lS5pNYIn - nx3v9l1067QD4AjefozgZwIs
	if s0lS5pNYIn<0:
		wqOY7uh8HXIfTVJ = 'undefined'
	else:
		wqOY7uh8HXIfTVJ = oSDMibwR2Fd0TG6COs9yvlBLm4jEa5[s0lS5pNYIn]
	return wqOY7uh8HXIfTVJ
def oVMbrsQjklpC0EeX6(oSDMibwR2Fd0TG6COs9yvlBLm4jEa5,nx3v9l1067QD4AjefozgZwIs,s0lS5pNYIn):
	return(nqguckdJFs8EKpS1l3(oSDMibwR2Fd0TG6COs9yvlBLm4jEa5,nx3v9l1067QD4AjefozgZwIs,s0lS5pNYIn))
def JTS9iW6x2E(wUl8IbFH1DYO,step,nx3v9l1067QD4AjefozgZwIs,acrBNT5x8Y6iCJleUQEG329h):
	acrBNT5x8Y6iCJleUQEG329h = acrBNT5x8Y6iCJleUQEG329h.replace('var ','global d; ')
	acrBNT5x8Y6iCJleUQEG329h = acrBNT5x8Y6iCJleUQEG329h.replace('x(','x(tab,step2,')
	acrBNT5x8Y6iCJleUQEG329h = acrBNT5x8Y6iCJleUQEG329h.replace('global d; d=','')
	MfTdV953F7Jrx = eval(acrBNT5x8Y6iCJleUQEG329h,{'parseInt':v2KxZUmECw9uFT5flPLd6,'x':oVMbrsQjklpC0EeX6,'tab':wUl8IbFH1DYO,'step2':nx3v9l1067QD4AjefozgZwIs})
	vGW4t381dmqby=0
	while True:
		vGW4t381dmqby=vGW4t381dmqby+1
		wUl8IbFH1DYO.append(wUl8IbFH1DYO[0])
		del wUl8IbFH1DYO[0]
		MfTdV953F7Jrx = eval(acrBNT5x8Y6iCJleUQEG329h,{'parseInt':v2KxZUmECw9uFT5flPLd6,'x':oVMbrsQjklpC0EeX6,'tab':wUl8IbFH1DYO,'step2':nx3v9l1067QD4AjefozgZwIs})
		if ((MfTdV953F7Jrx == step) or (vGW4t381dmqby>10000)): break
	return
def X2Bex86hmdrnC1Y(jefaP85NcF):
	LkKHrN2Stnw0avfuWO = u5h2Rckvw1E.findall('var.*?=(.{2,4})\(\)', jefaP85NcF, u5h2Rckvw1E.S)
	if not LkKHrN2Stnw0avfuWO: return 'ERR:Varconst Not Found'
	FBDURspNbivxZtlYAhGjqoV = LkKHrN2Stnw0avfuWO[0].strip()
	_k2uS4U8WzpmAnfdBtoQ0YvH('Varconst     = %s' % FBDURspNbivxZtlYAhGjqoV)
	LkKHrN2Stnw0avfuWO = u5h2Rckvw1E.findall('}\('+FBDURspNbivxZtlYAhGjqoV+'?,(0x[0-9a-f]{1,10})\)\);', jefaP85NcF)
	if not LkKHrN2Stnw0avfuWO: return 'ERR: Step1 Not Found'
	step = eval(LkKHrN2Stnw0avfuWO[0])
	_k2uS4U8WzpmAnfdBtoQ0YvH('Step1        = 0x%s' % '{:02X}'.format(step).lower())
	LkKHrN2Stnw0avfuWO = u5h2Rckvw1E.findall('d=d-(0x[0-9a-f]{1,10});', jefaP85NcF)
	if not LkKHrN2Stnw0avfuWO: return 'ERR:Step2 Not Found'
	nx3v9l1067QD4AjefozgZwIs = eval(LkKHrN2Stnw0avfuWO[0])
	_k2uS4U8WzpmAnfdBtoQ0YvH('Step2        = 0x%s' % '{:02X}'.format(nx3v9l1067QD4AjefozgZwIs).lower())
	LkKHrN2Stnw0avfuWO = u5h2Rckvw1E.findall("try{(var.*?);", jefaP85NcF)
	if not LkKHrN2Stnw0avfuWO: return 'ERR:decal_fnc Not Found'
	acrBNT5x8Y6iCJleUQEG329h = LkKHrN2Stnw0avfuWO[0]
	_k2uS4U8WzpmAnfdBtoQ0YvH('Decal func   = " %s..."' % acrBNT5x8Y6iCJleUQEG329h[0:135])
	LkKHrN2Stnw0avfuWO = u5h2Rckvw1E.findall("'data':{'(_[0-9a-zA-Z]{10,20})':'ok'", jefaP85NcF)
	if not LkKHrN2Stnw0avfuWO: return 'ERR:PostKey Not Found'
	XXWqsCUuNebRP3KVcEGdmn = LkKHrN2Stnw0avfuWO[0]
	_k2uS4U8WzpmAnfdBtoQ0YvH('PostKey      = %s' % XXWqsCUuNebRP3KVcEGdmn)
	LkKHrN2Stnw0avfuWO = u5h2Rckvw1E.findall("function "+FBDURspNbivxZtlYAhGjqoV+".*?var.*?=(\[.*?])", jefaP85NcF)
	if not LkKHrN2Stnw0avfuWO: return 'ERR:TabList Not Found'
	nAGboxgCIXwT = LkKHrN2Stnw0avfuWO[0]
	nAGboxgCIXwT = FBDURspNbivxZtlYAhGjqoV + "=" + nAGboxgCIXwT
	exec(nAGboxgCIXwT) in globals(), locals()
	oSDMibwR2Fd0TG6COs9yvlBLm4jEa5 = locals()[FBDURspNbivxZtlYAhGjqoV]
	_k2uS4U8WzpmAnfdBtoQ0YvH(FBDURspNbivxZtlYAhGjqoV+'          = %.90s...'%str(oSDMibwR2Fd0TG6COs9yvlBLm4jEa5))
	JTS9iW6x2E(oSDMibwR2Fd0TG6COs9yvlBLm4jEa5,step,nx3v9l1067QD4AjefozgZwIs,acrBNT5x8Y6iCJleUQEG329h)
	_k2uS4U8WzpmAnfdBtoQ0YvH(FBDURspNbivxZtlYAhGjqoV+'          = %.90s...'%str(oSDMibwR2Fd0TG6COs9yvlBLm4jEa5))
	LkKHrN2Stnw0avfuWO = u5h2Rckvw1E.findall("\(\);(var .*?)\$\('\*'\)", jefaP85NcF, u5h2Rckvw1E.S)
	if not LkKHrN2Stnw0avfuWO:
		LkKHrN2Stnw0avfuWO = u5h2Rckvw1E.findall("a0a\(\);(.*?)\$\('\*'\)", jefaP85NcF, u5h2Rckvw1E.S)
		if not LkKHrN2Stnw0avfuWO:
			return 'ERR:List_Var Not Found'
	OLz4v0IkpPFd9SByM = LkKHrN2Stnw0avfuWO[0]
	OLz4v0IkpPFd9SByM = u5h2Rckvw1E.sub("(function .*?}.*?})", "", OLz4v0IkpPFd9SByM)
	_k2uS4U8WzpmAnfdBtoQ0YvH('List_Var     = %.90s...' % OLz4v0IkpPFd9SByM)
	LkKHrN2Stnw0avfuWO = u5h2Rckvw1E.findall("(_[a-zA-z0-9]{4,8})=\[\]" , OLz4v0IkpPFd9SByM)
	if not LkKHrN2Stnw0avfuWO: return 'ERR:3Vars Not Found'
	_3w7GmjztnZXFqhTC = LkKHrN2Stnw0avfuWO
	_k2uS4U8WzpmAnfdBtoQ0YvH('3Vars        = %s'%str(_3w7GmjztnZXFqhTC))
	MpRFVwPXIquxstY9 = _3w7GmjztnZXFqhTC[1]
	_k2uS4U8WzpmAnfdBtoQ0YvH('big_str_var  = %s'%MpRFVwPXIquxstY9)
	OLz4v0IkpPFd9SByM = OLz4v0IkpPFd9SByM.replace(',',';').split(';')
	for DG8SXh4agibp in OLz4v0IkpPFd9SByM:
		DG8SXh4agibp = DG8SXh4agibp.strip()
		if 'ismob' in DG8SXh4agibp: DG8SXh4agibp=''
		if '=[]'   in DG8SXh4agibp: DG8SXh4agibp = DG8SXh4agibp.replace('=[]','={}')
		DG8SXh4agibp = u5h2Rckvw1E.sub("(a0.\()", "a0d(main_tab,step2,", DG8SXh4agibp)
		if DG8SXh4agibp!='':
			DG8SXh4agibp = DG8SXh4agibp.replace('!![]','True');
			DG8SXh4agibp = DG8SXh4agibp.replace('![]','False');
			DG8SXh4agibp = DG8SXh4agibp.replace('var ','');
			try:
				exec(DG8SXh4agibp,{'parseInt':v2KxZUmECw9uFT5flPLd6,'atob':HoBQfKYO3Ppn1Zs5lRbT2uNvFmk6z,'a0d':nqguckdJFs8EKpS1l3,'x':oVMbrsQjklpC0EeX6,'main_tab':oSDMibwR2Fd0TG6COs9yvlBLm4jEa5,'step2':nx3v9l1067QD4AjefozgZwIs},locals())
			except:
				pass
	rOZXB1oWLdgSUFCyKflz = ''
	for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(0,len(locals()[_3w7GmjztnZXFqhTC[2]])):
		if locals()[_3w7GmjztnZXFqhTC[2]][Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE] in locals()[_3w7GmjztnZXFqhTC[1]]:
			rOZXB1oWLdgSUFCyKflz = rOZXB1oWLdgSUFCyKflz + locals()[_3w7GmjztnZXFqhTC[1]][locals()[_3w7GmjztnZXFqhTC[2]][Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE]]
	_k2uS4U8WzpmAnfdBtoQ0YvH('bigString    = %.90s...'%rOZXB1oWLdgSUFCyKflz)
	LkKHrN2Stnw0avfuWO = u5h2Rckvw1E.findall('var b=\'/\'\+(.*?)(?:,|;)', jefaP85NcF, u5h2Rckvw1E.S)
	if not LkKHrN2Stnw0avfuWO: return 'ERR: GetUrl Not Found'
	Ae0bdTVFjNqJL2DIChEQGP = str(LkKHrN2Stnw0avfuWO[0])
	_k2uS4U8WzpmAnfdBtoQ0YvH('GetUrl       = %s' % Ae0bdTVFjNqJL2DIChEQGP)
	LkKHrN2Stnw0avfuWO = u5h2Rckvw1E.findall('(_.*?)\[', Ae0bdTVFjNqJL2DIChEQGP, u5h2Rckvw1E.S)
	if not LkKHrN2Stnw0avfuWO: return 'ERR: GetVar Not Found'
	M24MvJZLFoHBCpPha = LkKHrN2Stnw0avfuWO[0]
	_k2uS4U8WzpmAnfdBtoQ0YvH('GetVar       = %s' % M24MvJZLFoHBCpPha)
	gIAD0t6OuPsbfqZM = locals()[M24MvJZLFoHBCpPha][0]
	gIAD0t6OuPsbfqZM = HoBQfKYO3Ppn1Zs5lRbT2uNvFmk6z(gIAD0t6OuPsbfqZM)
	_k2uS4U8WzpmAnfdBtoQ0YvH('GetVal       = %s' % gIAD0t6OuPsbfqZM)
	LkKHrN2Stnw0avfuWO = u5h2Rckvw1E.findall('}var (f=.*?);', jefaP85NcF, u5h2Rckvw1E.S)
	if not LkKHrN2Stnw0avfuWO: return 'ERR: PostUrl Not Found'
	gdD8ivy4KLIaN3Rxj = str(LkKHrN2Stnw0avfuWO[0])
	_k2uS4U8WzpmAnfdBtoQ0YvH('PostUrl      = %s' % gdD8ivy4KLIaN3Rxj)
	gdD8ivy4KLIaN3Rxj = u5h2Rckvw1E.sub("(window\[.*?\])", "atob", gdD8ivy4KLIaN3Rxj)
	gdD8ivy4KLIaN3Rxj = u5h2Rckvw1E.sub("([A-Z]{1,2}\()", "a0d(main_tab,step2,", gdD8ivy4KLIaN3Rxj)
	gdD8ivy4KLIaN3Rxj = 'global f; '+gdD8ivy4KLIaN3Rxj
	verify = u5h2Rckvw1E.findall('\+(_.*?)$',gdD8ivy4KLIaN3Rxj,u5h2Rckvw1E.DOTALL)[0]
	Vvz75a0PfTDdtryb4e = eval(verify)
	gdD8ivy4KLIaN3Rxj = gdD8ivy4KLIaN3Rxj.replace('global f; f=','')
	eetfV7gvSH8qOEJAyn = eval(gdD8ivy4KLIaN3Rxj,{'atob':HoBQfKYO3Ppn1Zs5lRbT2uNvFmk6z,'a0d':nqguckdJFs8EKpS1l3,'main_tab':oSDMibwR2Fd0TG6COs9yvlBLm4jEa5,'step2':nx3v9l1067QD4AjefozgZwIs,verify:Vvz75a0PfTDdtryb4e})
	_k2uS4U8WzpmAnfdBtoQ0YvH('/'+gIAD0t6OuPsbfqZM+'    '+eetfV7gvSH8qOEJAyn+rOZXB1oWLdgSUFCyKflz+'    '+XXWqsCUuNebRP3KVcEGdmn)
	return(['/'+gIAD0t6OuPsbfqZM,eetfV7gvSH8qOEJAyn+rOZXB1oWLdgSUFCyKflz,{ XXWqsCUuNebRP3KVcEGdmn : 'ok'}])
def _k2uS4U8WzpmAnfdBtoQ0YvH(text):
	return
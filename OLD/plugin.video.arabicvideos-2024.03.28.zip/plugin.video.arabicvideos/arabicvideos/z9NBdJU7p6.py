# -*- coding: utf-8 -*-
import sys as vdo2FnhPmAVRMJQZ0EIG8
XzBpdMGJhHZKC8Yveki5qb1jT4nQUg = vdo2FnhPmAVRMJQZ0EIG8.version_info [0] == 2
vykERrdZlF5K = 2048
GG02h4EolRYTs3iv = 7
def tci7BbCy6gT9MXkOEzhm (xVtfmzjd6RSsBEk2o34aHWC):
	global jMo7iTRkq0n1NPa35xheAVlbt
	oAJijr7NHwnfUGqyd8Ru6EImOtv = ord (xVtfmzjd6RSsBEk2o34aHWC [-1])
	wwpaJlB3bkXySOHFWUfoILC = xVtfmzjd6RSsBEk2o34aHWC [:-1]
	lqXRut6PnL = oAJijr7NHwnfUGqyd8Ru6EImOtv % len (wwpaJlB3bkXySOHFWUfoILC)
	rmaU71pZj3X = wwpaJlB3bkXySOHFWUfoILC [:lqXRut6PnL] + wwpaJlB3bkXySOHFWUfoILC [lqXRut6PnL:]
	if XzBpdMGJhHZKC8Yveki5qb1jT4nQUg:
		bbsiU0a49tw2dy = unicode () .join ([unichr (ord (Q9QUIWH6rK2BlmC) - vykERrdZlF5K - (ZXwWfDc9AF4yr2P + oAJijr7NHwnfUGqyd8Ru6EImOtv) % GG02h4EolRYTs3iv) for ZXwWfDc9AF4yr2P, Q9QUIWH6rK2BlmC in enumerate (rmaU71pZj3X)])
	else:
		bbsiU0a49tw2dy = str () .join ([chr (ord (Q9QUIWH6rK2BlmC) - vykERrdZlF5K - (ZXwWfDc9AF4yr2P + oAJijr7NHwnfUGqyd8Ru6EImOtv) % GG02h4EolRYTs3iv) for ZXwWfDc9AF4yr2P, Q9QUIWH6rK2BlmC in enumerate (rmaU71pZj3X)])
	return eval (bbsiU0a49tw2dy)
r3flT0zQPa5H7yXEgxJOt92Vc4Ao,cgtRBdXxSOk7WUfyDhPCls,cNaVb1vsT4qWOL0rpE=tci7BbCy6gT9MXkOEzhm,tci7BbCy6gT9MXkOEzhm,tci7BbCy6gT9MXkOEzhm
yruHDQOcB97ig,drHLAY5ENQFe2q9ptKGabo,qnPgZ9N15G6Oa8UpMASvLk=cNaVb1vsT4qWOL0rpE,cgtRBdXxSOk7WUfyDhPCls,r3flT0zQPa5H7yXEgxJOt92Vc4Ao
KKbpxUZnMcj6AJ4QdD,ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB,ggDRehOModi=qnPgZ9N15G6Oa8UpMASvLk,drHLAY5ENQFe2q9ptKGabo,yruHDQOcB97ig
xuztI5QWEKG70CPNdhk4vo6,bcgZJWV6UeNSkRA,shZ9eOcN2dJnPj=ggDRehOModi,ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB,KKbpxUZnMcj6AJ4QdD
BGhdkWsEvJjiMFTr3NLn1flU,nKLEi8CJumazx4qT,pcWq35MED2dtK=shZ9eOcN2dJnPj,bcgZJWV6UeNSkRA,xuztI5QWEKG70CPNdhk4vo6
yF29Xdsx35wI07Ce4,XikqnGVSK4v9d3uUICLhDxJyt1M,JLoPRXt93dpAB=pcWq35MED2dtK,nKLEi8CJumazx4qT,BGhdkWsEvJjiMFTr3NLn1flU
wwplD0tEehqH3kYQXs,tZ3gsrTEdzA1S6LXa9WI5px,Nqj35AXg06euY1G2d4bSUMQ8wlr=JLoPRXt93dpAB,XikqnGVSK4v9d3uUICLhDxJyt1M,yF29Xdsx35wI07Ce4
bbw2eajMlG,M6PIj8gl1fno7wcqTksDEBK4bU,CgG4PuyxsLA8WDzh3FfteZvKQMdom9=Nqj35AXg06euY1G2d4bSUMQ8wlr,tZ3gsrTEdzA1S6LXa9WI5px,wwplD0tEehqH3kYQXs
iifPEY9ABNzTQp,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ,PtXn0k9G3ocHRg=CgG4PuyxsLA8WDzh3FfteZvKQMdom9,M6PIj8gl1fno7wcqTksDEBK4bU,bbw2eajMlG
Tgoa16jMxvYX2,vvBChXmSty,InKG0i2r6hHDvgd=PtXn0k9G3ocHRg,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ,iifPEY9ABNzTQp
OyJ1o4AvmWlB75UkFRX,usaZLwSGe1k6VDp570yhB4bzWPiFq,oUlIcGH2JuWFLvimMXyBQdzK06ge=InKG0i2r6hHDvgd,vvBChXmSty,Tgoa16jMxvYX2
import xbmc as bMIascyFJ2x43E0C7glTB91h8qz,re as u5h2Rckvw1E,sys as vdo2FnhPmAVRMJQZ0EIG8,xbmcaddon as kmUVwglqCI7Q,random as jjyW6FTEOn3sSMo1G5LxBiA,os as k1t0JLRsCQ,xbmcvfs as vJI3jtCwe5WL1OinmNgys,time as YVJPFvuI2CS5KObiZt,pickle as W7BTz1R3wkMn9,zlib as apKJA5QDiybZeGBk,xbmcgui as XuWPVcQ13oDq5swf0S,xbmcplugin as oejGsrTCZ05k2X7LlHnPa3h8vzAbJy,sqlite3 as Xmn7ZoOHiUB2fKvd6Y8ALct3GsNT,traceback as BPSEU6WvQRnxV,threading as onVDrgLUpFsqOPkxId9BwW6Rtc5A
aUVSgO2ebjwX5iqPykC = r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠫࡑࡏࡂࡔࡑࡑࡉࠬਰ")
b69iT7LWwrfXzGYPMvBCsteVHDQK = kmUVwglqCI7Q.Addon().getAddonInfo(shZ9eOcN2dJnPj(u"ࠬࡶࡡࡵࡪࠪ਱"))
jeLPnzgsC1i5vrMudm8ARHh2Dco = k1t0JLRsCQ.path.join(b69iT7LWwrfXzGYPMvBCsteVHDQK,yruHDQOcB97ig(u"࠭ࡰࡢࡥ࡮ࡥ࡬࡫ࡳࠨਲ"))
vdo2FnhPmAVRMJQZ0EIG8.path.append(jeLPnzgsC1i5vrMudm8ARHh2Dco)
UFdmsKIGAx0JrVCe = bMIascyFJ2x43E0C7glTB91h8qz.getInfoLabel(M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠢࡔࡻࡶࡸࡪࡳ࠮ࡃࡷ࡬ࡰࡩ࡜ࡥࡳࡵ࡬ࡳࡳࠨਲ਼"))
njGgmsD1k7cE60drxHCyVh2YN3P = u5h2Rckvw1E.findall(vvBChXmSty(u"ࠨࠪ࡟ࡨࡡࡪ࡜࠯࡞ࡧ࠭ࠬ਴"),UFdmsKIGAx0JrVCe,u5h2Rckvw1E.DOTALL)
njGgmsD1k7cE60drxHCyVh2YN3P = float(njGgmsD1k7cE60drxHCyVh2YN3P[n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠱௴")])
OXS0K38lYtj = bMIascyFJ2x43E0C7glTB91h8qz.Player
qZzjySC63LWVAovla2TIUfpF9uxg0i = XuWPVcQ13oDq5swf0S.WindowXMLDialog
bdptXFc8UlIhA5jnGwPmKuv2L = njGgmsD1k7cE60drxHCyVh2YN3P<XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠳࠼௵")
VVGRN7xiyj = njGgmsD1k7cE60drxHCyVh2YN3P>wwplD0tEehqH3kYQXs(u"࠴࠼࠳࠿࠹௶")
if VVGRN7xiyj:
	Q3bunCwypTEx2q7oR845V = bMIascyFJ2x43E0C7glTB91h8qz.LOGINFO
	Qa68jZXt0gBH,RQ0HpOfhFDoJdtl = qnPgZ9N15G6Oa8UpMASvLk(u"ࡷࠪࡠࡺ࠸࠰࠳ࡣࠪਵ"),bbw2eajMlG(u"ࡸࠫࡡࡻ࠲࠱࠴ࡥࠫਸ਼")
	JdlHjqsCMQNyXt2 = vJI3jtCwe5WL1OinmNgys.translatePath(InKG0i2r6hHDvgd(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡵࡧࡰࡴࠬ਷"))
	from urllib.parse import unquote as _Gd5gCNO0EiykFlM
else:
	Q3bunCwypTEx2q7oR845V = bMIascyFJ2x43E0C7glTB91h8qz.LOGNOTICE
	Qa68jZXt0gBH,RQ0HpOfhFDoJdtl = yF29Xdsx35wI07Ce4(u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡦ࠭ਸ").encode(ggDRehOModi(u"࠭ࡵࡵࡨ࠻ࠫਹ")),BGhdkWsEvJjiMFTr3NLn1flU(u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡢࠨ਺").encode(cgtRBdXxSOk7WUfyDhPCls(u"ࠨࡷࡷࡪ࠽࠭਻"))
	JdlHjqsCMQNyXt2 = bMIascyFJ2x43E0C7glTB91h8qz.translatePath(InKG0i2r6hHDvgd(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡺࡥ࡮ࡲ਼ࠪ"))
	from urllib import unquote as _Gd5gCNO0EiykFlM
sWOeP7NLZSqioT6Xa8Hr = usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠺࠵௷")
PPC3GlfZAh68 = yF29Xdsx35wI07Ce4(u"࠻࠶௸")*sWOeP7NLZSqioT6Xa8Hr
hhOBpfy1WNgdLIzXEF7Su = r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠸࠴௹")*PPC3GlfZAh68
d9KqcHYDbO27B = JLoPRXt93dpAB(u"࠳࠱௺")*hhOBpfy1WNgdLIzXEF7Su
a2VuAbpQkGfMwSIcsP1XH6mletyzx = InKG0i2r6hHDvgd(u"࠱௻")
Iu3GUD84WyEqQjPFTYeh1SL9J = KKbpxUZnMcj6AJ4QdD(u"࠵࠳௼")*sWOeP7NLZSqioT6Xa8Hr
hs8IDEMn0YuCHwk = JLoPRXt93dpAB(u"࠵௽")*PPC3GlfZAh68
QQJtZ6rMvS1wdDsHnahT7 = xuztI5QWEKG70CPNdhk4vo6(u"࠵࠻௾")*PPC3GlfZAh68
ebm0Z72CDaBzUq = PtXn0k9G3ocHRg(u"࠸௿")*hhOBpfy1WNgdLIzXEF7Su
we9acVgv5HE0mdlXCSj6n7DQ4 = OyJ1o4AvmWlB75UkFRX(u"࠹࠰ఀ")*hhOBpfy1WNgdLIzXEF7Su
NVbfv48oh3M6U = BGhdkWsEvJjiMFTr3NLn1flU(u"࠱࠳ఁ")*d9KqcHYDbO27B
IDbT7Aya2hB180SvVUXFYc = cNaVb1vsT4qWOL0rpE(u"࠲ం")*PPC3GlfZAh68
lY0rst72uGVZ1NkgvpjfA6x = vdo2FnhPmAVRMJQZ0EIG8.argv[M6PIj8gl1fno7wcqTksDEBK4bU(u"࠲ః")].split(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠪ࠳ࠬ਽"))[xuztI5QWEKG70CPNdhk4vo6(u"࠵ఄ")]
Y40Szd1kTwqQxFXm6HO8tRlAvepK = int(vdo2FnhPmAVRMJQZ0EIG8.argv[XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠵అ")])
O0Dm45eTJi8rlWUCQLbMducERHp = vdo2FnhPmAVRMJQZ0EIG8.argv[CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠷ఆ")]
Afo5xTmMkRn08IjJ = lY0rst72uGVZ1NkgvpjfA6x.split(cNaVb1vsT4qWOL0rpE(u"ࠫ࠳࠭ਾ"))[yruHDQOcB97ig(u"࠸ఇ")]
qkSQU3saP0D7OvynNzH4F2BKJuilT = bMIascyFJ2x43E0C7glTB91h8qz.getInfoLabel(iifPEY9ABNzTQp(u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡇࡤࡥࡱࡱ࡚ࡪࡸࡳࡪࡱࡱࠬࠬਿ")+lY0rst72uGVZ1NkgvpjfA6x+ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠭ࠩࠨੀ"))
OxWkR7Eu9Pm3IAvTp0q = k1t0JLRsCQ.path.join(JdlHjqsCMQNyXt2,lY0rst72uGVZ1NkgvpjfA6x)
bpNSygerL10j4IOkEfuVw = k1t0JLRsCQ.path.join(OxWkR7Eu9Pm3IAvTp0q,bcgZJWV6UeNSkRA(u"ࠧ࡮ࡣ࡬ࡲࡩࡧࡴࡢ࠰ࡧࡦࠬੁ"))
s1KMjlEIH9vd = k1t0JLRsCQ.path.join(OxWkR7Eu9Pm3IAvTp0q,XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠨ࡮ࡤࡷࡹࡼࡩࡥࡧࡲࡷ࠳ࡪࡡࡵࠩੂ"))
s8bXSagYdim62TwIpQzGtUqeLhA1J = int(YVJPFvuI2CS5KObiZt.time())
LLwCINEyZT9GHP7QMA1VlukcDjh = kmUVwglqCI7Q.Addon(id=lY0rst72uGVZ1NkgvpjfA6x)
def ykfj6Qb9Fc5GiJIvelp84rHDn(GMfo7WypIsRin9HKEZQduYhDetFJOS,nngdtHAZwB5o=tZ3gsrTEdzA1S6LXa9WI5px(u"ࠩࡂࠫ੃")):
	if tZ3gsrTEdzA1S6LXa9WI5px(u"ࠪࡁࠬ੄") in GMfo7WypIsRin9HKEZQduYhDetFJOS:
		if nngdtHAZwB5o in GMfo7WypIsRin9HKEZQduYhDetFJOS: gANn35esloKUydOipfSMC6RD2,zO1vCbD8W24eyGMfNxuohrd9qw = GMfo7WypIsRin9HKEZQduYhDetFJOS.split(nngdtHAZwB5o,yF29Xdsx35wI07Ce4(u"࠱ఈ"))
		else: gANn35esloKUydOipfSMC6RD2,zO1vCbD8W24eyGMfNxuohrd9qw = ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠫࠬ੅"),GMfo7WypIsRin9HKEZQduYhDetFJOS
		zO1vCbD8W24eyGMfNxuohrd9qw = zO1vCbD8W24eyGMfNxuohrd9qw.split(cgtRBdXxSOk7WUfyDhPCls(u"ࠬࠬࠧ੆"))
		XfOb4VIcPY = {}
		for llWqSnghXE in zO1vCbD8W24eyGMfNxuohrd9qw:
			LLalIEnYqHb01Kzs6uo3XvOt8MSV,XApzCr15jdx9YK6nRfBq0Q4m = llWqSnghXE.split(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠭࠽ࠨੇ"),cgtRBdXxSOk7WUfyDhPCls(u"࠲ఉ"))
			XfOb4VIcPY[LLalIEnYqHb01Kzs6uo3XvOt8MSV] = XApzCr15jdx9YK6nRfBq0Q4m
	else: gANn35esloKUydOipfSMC6RD2,XfOb4VIcPY = GMfo7WypIsRin9HKEZQduYhDetFJOS,{}
	return gANn35esloKUydOipfSMC6RD2,XfOb4VIcPY
def P2o6ZDHeW790pSQqucvnxzILVUX(GMfo7WypIsRin9HKEZQduYhDetFJOS):
	return _Gd5gCNO0EiykFlM(GMfo7WypIsRin9HKEZQduYhDetFJOS)
def QPTqwDCWalLdRB9jrkAbIz(kf6SHY3vcJBV9Pb2QMNUlpGz58hAt):
	y1Q7AbcPmutfRXC6dEN32MLgOjpa = {cgtRBdXxSOk7WUfyDhPCls(u"ࠧࡵࡻࡳࡩࠬੈ"):bcgZJWV6UeNSkRA(u"ࠨࠩ੉"),drHLAY5ENQFe2q9ptKGabo(u"ࠩࡰࡳࡩ࡫ࠧ੊"):pcWq35MED2dtK(u"ࠪࠫੋ"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠫࡺࡸ࡬ࠨੌ"):Nqj35AXg06euY1G2d4bSUMQ8wlr(u"੍ࠬ࠭"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠭ࡴࡦࡺࡷࠫ੎"):pcWq35MED2dtK(u"ࠧࠨ੏"),KKbpxUZnMcj6AJ4QdD(u"ࠨࡲࡤ࡫ࡪ࠭੐"):nKLEi8CJumazx4qT(u"ࠩࠪੑ"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠪࡲࡦࡳࡥࠨ੒"):CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠫࠬ੓"),drHLAY5ENQFe2q9ptKGabo(u"ࠬ࡯࡭ࡢࡩࡨࠫ੔"):Tgoa16jMxvYX2(u"࠭ࠧ੕"),bcgZJWV6UeNSkRA(u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ੖"):InKG0i2r6hHDvgd(u"ࠨࠩ੗"),PtXn0k9G3ocHRg(u"ࠩ࡬ࡲ࡫ࡵࡤࡪࡥࡷࠫ੘"):r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠪࠫਖ਼")}
	if drHLAY5ENQFe2q9ptKGabo(u"ࠫࡄ࠭ਗ਼") in kf6SHY3vcJBV9Pb2QMNUlpGz58hAt: kf6SHY3vcJBV9Pb2QMNUlpGz58hAt = kf6SHY3vcJBV9Pb2QMNUlpGz58hAt.split(cgtRBdXxSOk7WUfyDhPCls(u"ࠬࡅࠧਜ਼"),wwplD0tEehqH3kYQXs(u"࠳ఊ"))[wwplD0tEehqH3kYQXs(u"࠳ఊ")]
	gANn35esloKUydOipfSMC6RD2,whjeFRtB1u = ykfj6Qb9Fc5GiJIvelp84rHDn(kf6SHY3vcJBV9Pb2QMNUlpGz58hAt)
	aargs = dict(list(y1Q7AbcPmutfRXC6dEN32MLgOjpa.items())+list(whjeFRtB1u.items()))
	DCSjNrcfWakGO2yVo9LXt8Fg4JZxPK = aargs[XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠭࡭ࡰࡦࡨࠫੜ")]
	nJZr96iD14wfebYudRShUFyHjkzAo = P2o6ZDHeW790pSQqucvnxzILVUX(aargs[nKLEi8CJumazx4qT(u"ࠧࡶࡴ࡯ࠫ੝")])
	FT0vADQCPhzUnOZsLGk = P2o6ZDHeW790pSQqucvnxzILVUX(aargs[tZ3gsrTEdzA1S6LXa9WI5px(u"ࠨࡶࡨࡼࡹ࠭ਫ਼")])
	gwiP7zvsEaOMJnkBHpAqy8eYNR = P2o6ZDHeW790pSQqucvnxzILVUX(aargs[ggDRehOModi(u"ࠩࡳࡥ࡬࡫ࠧ੟")])
	EWgxGbZUsCLOPTD4BJId2afR7oHk9N = P2o6ZDHeW790pSQqucvnxzILVUX(aargs[PtXn0k9G3ocHRg(u"ࠪࡸࡾࡶࡥࠨ੠")])
	QG4JKD1kYXNazgnxlPr9WFRZ = P2o6ZDHeW790pSQqucvnxzILVUX(aargs[CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠫࡳࡧ࡭ࡦࠩ੡")])
	E6T9RGlrWixPbQVMBIJzh8eYHwkAL = P2o6ZDHeW790pSQqucvnxzILVUX(aargs[drHLAY5ENQFe2q9ptKGabo(u"ࠬ࡯࡭ࡢࡩࡨࠫ੢")])
	VM0ekQbdFrifC = aargs[wwplD0tEehqH3kYQXs(u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ੣")]
	ZbuUnz90tsTRAkXm = P2o6ZDHeW790pSQqucvnxzILVUX(aargs[Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠧࡪࡰࡩࡳࡩ࡯ࡣࡵࠩ੤")])
	if ZbuUnz90tsTRAkXm: ZbuUnz90tsTRAkXm = eval(ZbuUnz90tsTRAkXm)
	else: ZbuUnz90tsTRAkXm = {}
	if not DCSjNrcfWakGO2yVo9LXt8Fg4JZxPK: EWgxGbZUsCLOPTD4BJId2afR7oHk9N = InKG0i2r6hHDvgd(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ੥") ; DCSjNrcfWakGO2yVo9LXt8Fg4JZxPK = bbw2eajMlG(u"ࠩ࠵࠺࠵࠭੦")
	return EWgxGbZUsCLOPTD4BJId2afR7oHk9N,QG4JKD1kYXNazgnxlPr9WFRZ,nJZr96iD14wfebYudRShUFyHjkzAo,DCSjNrcfWakGO2yVo9LXt8Fg4JZxPK,E6T9RGlrWixPbQVMBIJzh8eYHwkAL,gwiP7zvsEaOMJnkBHpAqy8eYNR,FT0vADQCPhzUnOZsLGk,VM0ekQbdFrifC,ZbuUnz90tsTRAkXm
def CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC):
	OBXaDmQ3hyVixzdlNtvMP = vdo2FnhPmAVRMJQZ0EIG8._getframe(ggDRehOModi(u"࠴ఋ")).f_code.co_name
	if not aUVSgO2ebjwX5iqPykC or not OBXaDmQ3hyVixzdlNtvMP or OBXaDmQ3hyVixzdlNtvMP==ggDRehOModi(u"ࠪࡀࡲࡵࡤࡶ࡮ࡨࡂࠬ੧"):
		return yF29Xdsx35wI07Ce4(u"ࠫࡠࠦࠧ੨")+Afo5xTmMkRn08IjJ.upper()+PtXn0k9G3ocHRg(u"ࠬ࠳ࠧ੩")+qkSQU3saP0D7OvynNzH4F2BKJuilT+wwplD0tEehqH3kYQXs(u"࠭࠭ࠨ੪")+str(njGgmsD1k7cE60drxHCyVh2YN3P)+KKbpxUZnMcj6AJ4QdD(u"ࠧࠡ࡟ࠪ੫")
	return bcgZJWV6UeNSkRA(u"ࠨ࠰ࠣࠤࠬ੬")+OBXaDmQ3hyVixzdlNtvMP
def l0SAerv8zGH2Wa(FdVs5WLb7xutnjB,CWL8J3MFDRmtk029PKhsp6Zgbv):
	if bdptXFc8UlIhA5jnGwPmKuv2L: CWL8J3MFDRmtk029PKhsp6Zgbv = CWL8J3MFDRmtk029PKhsp6Zgbv.decode(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠩࡸࡸ࡫࠾ࠧ੭")).encode(nKLEi8CJumazx4qT(u"ࠪࡹࡹ࡬࠸ࠨ੮"))
	wjlrQvLhbmNi5zVI0 = Q3bunCwypTEx2q7oR845V
	dvulfaW1UAFZ2JSrPxOYyeMHqn = [bcgZJWV6UeNSkRA(u"ࠫࠬ੯"),OyJ1o4AvmWlB75UkFRX(u"ࠬ࠭ੰ")]
	if FdVs5WLb7xutnjB: CWL8J3MFDRmtk029PKhsp6Zgbv = CWL8J3MFDRmtk029PKhsp6Zgbv.replace(wwplD0tEehqH3kYQXs(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩੱ"),shZ9eOcN2dJnPj(u"ࠧࠨੲ")).replace(KKbpxUZnMcj6AJ4QdD(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫੳ"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࠩࠪੴ")).replace(cgtRBdXxSOk7WUfyDhPCls(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬੵ"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠫࠬ੶"))
	else: FdVs5WLb7xutnjB = yruHDQOcB97ig(u"ࠬࡔࡏࡕࡋࡆࡉࠬ੷")
	wUl8IbFH1DYO,nngdtHAZwB5o,jckmqWyECDxJgbhzlVa1uX6LG23 = XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠭ࠠࠡࠢࠣࠫ੸"),wwplD0tEehqH3kYQXs(u"ࠧࠡࠢࠣࠫ੹"),Tgoa16jMxvYX2(u"ࠨࠩ੺")
	if ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠩࡈࡖࡗࡕࡒࠨ੻") in FdVs5WLb7xutnjB: wjlrQvLhbmNi5zVI0 = bMIascyFJ2x43E0C7glTB91h8qz.LOGERROR
	if FdVs5WLb7xutnjB==wwplD0tEehqH3kYQXs(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ੼"):
		CWL8J3MFDRmtk029PKhsp6Zgbv = CWL8J3MFDRmtk029PKhsp6Zgbv+nngdtHAZwB5o
		dvulfaW1UAFZ2JSrPxOYyeMHqn = CWL8J3MFDRmtk029PKhsp6Zgbv.split(nngdtHAZwB5o)
		jckmqWyECDxJgbhzlVa1uX6LG23 = wUl8IbFH1DYO
	elif FdVs5WLb7xutnjB==ggDRehOModi(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ੽"):
		CWL8J3MFDRmtk029PKhsp6Zgbv = CWL8J3MFDRmtk029PKhsp6Zgbv.replace(bbw2eajMlG(u"ࠬ࠴ࠧ੾")+nngdtHAZwB5o,CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠭࠮ࠡࠢࠪ੿"))
		dvulfaW1UAFZ2JSrPxOYyeMHqn = CWL8J3MFDRmtk029PKhsp6Zgbv.split(nngdtHAZwB5o)
		dvulfaW1UAFZ2JSrPxOYyeMHqn[n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠵఍")] = M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠧ࠯ࠩ઀")+dvulfaW1UAFZ2JSrPxOYyeMHqn[n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠵఍")][vvBChXmSty(u"࠵ఌ"):]
		jckmqWyECDxJgbhzlVa1uX6LG23 = wUl8IbFH1DYO+nngdtHAZwB5o
	elif FdVs5WLb7xutnjB in [Tgoa16jMxvYX2(u"ࠨࡐࡒࡘࡎࡉࡅࠨઁ"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠩࡈࡖࡗࡕࡒࠨં")]: dvulfaW1UAFZ2JSrPxOYyeMHqn = CWL8J3MFDRmtk029PKhsp6Zgbv.split(wUl8IbFH1DYO)
	jckmqWyECDxJgbhzlVa1uX6LG23 += xuztI5QWEKG70CPNdhk4vo6(u"࠼ఎ")*wUl8IbFH1DYO
	TDKUBpcVl8Q0nRj1X3fzdiJEab = PtXn0k9G3ocHRg(u"࠳ఏ")*wUl8IbFH1DYO
	if njGgmsD1k7cE60drxHCyVh2YN3P>InKG0i2r6hHDvgd(u"࠳࠺࠲࠾࠿఑"): jckmqWyECDxJgbhzlVa1uX6LG23 += bcgZJWV6UeNSkRA(u"࠲࠳ఐ")*yruHDQOcB97ig(u"ࠪࠤࠬઃ")
	vLsuNOqjyadJ = dvulfaW1UAFZ2JSrPxOYyeMHqn[ggDRehOModi(u"࠳ఒ")]
	for ZaVCxBWH36wEyto4jnusNL1gTmJ0 in dvulfaW1UAFZ2JSrPxOYyeMHqn[wwplD0tEehqH3kYQXs(u"࠵ఓ"):]:
		if shZ9eOcN2dJnPj(u"ࠫࡡࡴࠧ઄") in ZaVCxBWH36wEyto4jnusNL1gTmJ0: ZaVCxBWH36wEyto4jnusNL1gTmJ0 = ZaVCxBWH36wEyto4jnusNL1gTmJ0.replace(qnPgZ9N15G6Oa8UpMASvLk(u"ࠬࡢ࡮ࠨઅ"),InKG0i2r6hHDvgd(u"࠭࡜࡯ࠩઆ")+wUl8IbFH1DYO+wUl8IbFH1DYO)
		TDKUBpcVl8Q0nRj1X3fzdiJEab += wUl8IbFH1DYO
		vLsuNOqjyadJ += usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠧ࡝ࡴࠪઇ")+jckmqWyECDxJgbhzlVa1uX6LG23+TDKUBpcVl8Q0nRj1X3fzdiJEab+ZaVCxBWH36wEyto4jnusNL1gTmJ0
	vLsuNOqjyadJ += wwplD0tEehqH3kYQXs(u"ࠨࠢࡢࠫઈ")
	if InKG0i2r6hHDvgd(u"ࠩࠨࠫઉ") in vLsuNOqjyadJ: vLsuNOqjyadJ = P2o6ZDHeW790pSQqucvnxzILVUX(vLsuNOqjyadJ)
	bMIascyFJ2x43E0C7glTB91h8qz.log(vLsuNOqjyadJ,level=wjlrQvLhbmNi5zVI0)
	return
def YWjf06dGFXDTm(efpI3jkhR8bCtBXr):
	AO76Z1XEaSDjomRwK = Xmn7ZoOHiUB2fKvd6Y8ALct3GsNT.connect(efpI3jkhR8bCtBXr)
	BVYESNuJMxlmDo5WXdaFP6r = AO76Z1XEaSDjomRwK.cursor()
	BVYESNuJMxlmDo5WXdaFP6r.execute(Tgoa16jMxvYX2(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡥࡺࡺ࡯࡮ࡣࡷ࡭ࡨࡥࡩ࡯ࡦࡨࡼࡂࡴ࡯࠼ࠩઊ"))
	BVYESNuJMxlmDo5WXdaFP6r.execute(bbw2eajMlG(u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡫ࡵࡲࡦ࡫ࡪࡲࡤࡱࡥࡺࡵࡀࡲࡴࡁࠧઋ"))
	BVYESNuJMxlmDo5WXdaFP6r.execute(cNaVb1vsT4qWOL0rpE(u"ࠬࡖࡒࡂࡉࡐࡅࠥ࡯ࡧ࡯ࡱࡵࡩࡤࡩࡨࡦࡥ࡮ࡣࡨࡵ࡮ࡴࡶࡵࡥ࡮ࡴࡴࡴ࠿ࡼࡩࡸࡁࠧઌ"))
	BVYESNuJMxlmDo5WXdaFP6r.execute(M6PIj8gl1fno7wcqTksDEBK4bU(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡪࡰࡷࡵࡲࡦࡲ࡟࡮ࡱࡧࡩࡂࡕࡆࡇ࠽ࠪઍ"))
	BVYESNuJMxlmDo5WXdaFP6r.execute(bcgZJWV6UeNSkRA(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡵࡧࡰࡴࡤࡹࡴࡰࡴࡨࡁࡒࡋࡍࡐࡔ࡜࠿ࠬ઎"))
	BVYESNuJMxlmDo5WXdaFP6r.execute(iifPEY9ABNzTQp(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡵࡼࡲࡨ࡮ࡲࡰࡰࡲࡹࡸࡃࡏࡇࡈ࠾ࠫએ"))
	AO76Z1XEaSDjomRwK.text_factory = str
	return AO76Z1XEaSDjomRwK,BVYESNuJMxlmDo5WXdaFP6r
def ZqlR5BFQ6pm0asCHLUc(efpI3jkhR8bCtBXr,yywEV0s2I3hRKlS6qj,wv2Ve0xF3UW9c1ABubZ=None):
	try: AO76Z1XEaSDjomRwK,BVYESNuJMxlmDo5WXdaFP6r = YWjf06dGFXDTm(efpI3jkhR8bCtBXr)
	except: return
	if wv2Ve0xF3UW9c1ABubZ==None: BVYESNuJMxlmDo5WXdaFP6r.execute(xuztI5QWEKG70CPNdhk4vo6(u"ࠩࡇࡖࡔࡖࠠࡕࡃࡅࡐࡊࠦࡉࡇࠢࡈ࡜ࡎ࡙ࡔࡔࠢࠥࠫઐ")+yywEV0s2I3hRKlS6qj+drHLAY5ENQFe2q9ptKGabo(u"ࠪࠦࠥࡁࠧઑ"))
	else:
		fzGPBZRpVXv504s = (str(wv2Ve0xF3UW9c1ABubZ),)
		try:
			if M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠫࠪ࠭઒") in wv2Ve0xF3UW9c1ABubZ: BVYESNuJMxlmDo5WXdaFP6r.execute(cNaVb1vsT4qWOL0rpE(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬઓ")+yywEV0s2I3hRKlS6qj+ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࡭࡫࡮ࡩࠥࡅࠠ࠼ࠩઔ"),fzGPBZRpVXv504s)
			else: BVYESNuJMxlmDo5WXdaFP6r.execute(qnPgZ9N15G6Oa8UpMASvLk(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧક")+yywEV0s2I3hRKlS6qj+OyJ1o4AvmWlB75UkFRX(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨખ"),fzGPBZRpVXv504s)
		except: pass
	AO76Z1XEaSDjomRwK.commit()
	AO76Z1XEaSDjomRwK.close()
	return
class Z1bltau8WkOFP(): pass
class fZio7hAJNCV1stDnvWaQX0cLFjwqHS(Z1bltau8WkOFP):
	def __init__(fXCnj1ABdeRWiHUE9a8F0gwTrqS):
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.url = usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩࠪગ")
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.code = -nKLEi8CJumazx4qT(u"࠾࠿ఔ")
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.reason = M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠪࠫઘ")
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.content = qnPgZ9N15G6Oa8UpMASvLk(u"ࠫࠬઙ")
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.headers = {}
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.cookies = {}
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.succeeded = tZ3gsrTEdzA1S6LXa9WI5px(u"ࡆࡢ࡮ࡶࡩ౜")
def ddLvyNFVhnZsrCa1WlJwKj(afxYgsnGTdAHePVBK):
	if afxYgsnGTdAHePVBK==oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠬࡪࡩࡤࡶࠪચ"): MNWrTo98GZHn = {}
	elif afxYgsnGTdAHePVBK==Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠭࡬ࡪࡵࡷࠫછ"): MNWrTo98GZHn = []
	elif afxYgsnGTdAHePVBK==r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠧࡴࡶࡵࠫજ"): MNWrTo98GZHn = nKLEi8CJumazx4qT(u"ࠨࠩઝ")
	elif afxYgsnGTdAHePVBK==InKG0i2r6hHDvgd(u"ࠩ࡬ࡲࡹ࠭ઞ"): MNWrTo98GZHn = usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠶క")
	elif afxYgsnGTdAHePVBK==pcWq35MED2dtK(u"ࠪࡶࡪࡹࡰࡰࡰࡶࡩࠬટ"): MNWrTo98GZHn = fZio7hAJNCV1stDnvWaQX0cLFjwqHS()
	elif not afxYgsnGTdAHePVBK: MNWrTo98GZHn = None
	else: MNWrTo98GZHn = None
	return MNWrTo98GZHn
def yrPav1tl5MQcfEBhsXk2o(zzbVLlso57C):
	from hashlib import md5 as XXt3yJYkxgvLsRBpuhZPOH7wMIo
	s4MbKCZQhlRore0L = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠭ઠ"))
	ZIwsUVaiTx0fCXMHcezrLRDQvY = lbFixEt3BK9YGMyWIQZuSsp1V7JTL8(XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠳࠳ఖ")).splitlines()
	efdrTtNzZ8aPpcq = usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠱గ")
	for RQpN21TPvh648u3g7iZskSC5orM in [s8bXSagYdim62TwIpQzGtUqeLhA1J,s8bXSagYdim62TwIpQzGtUqeLhA1J-hs8IDEMn0YuCHwk]:
		PXk8W4RSBMam6lsorYg7yQhed = str(RQpN21TPvh648u3g7iZskSC5orM*bbw2eajMlG(u"࠵࠵࠶࠰࠱࠲࠱࠴చ")/xuztI5QWEKG70CPNdhk4vo6(u"࠷࠷࠷࠶࠰࠱ఙ"))[InKG0i2r6hHDvgd(u"࠲ఘ"):cgtRBdXxSOk7WUfyDhPCls(u"࠹ఛ")]
		if PXk8W4RSBMam6lsorYg7yQhed!=efdrTtNzZ8aPpcq:
			for LLTHJsQdGUq in ZIwsUVaiTx0fCXMHcezrLRDQvY:
				Du8jZhbyYHplfOM9KCwn4aFNBxIsPm = XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠬ࡞࠱࠺ࠩડ")+zzbVLlso57C+cgtRBdXxSOk7WUfyDhPCls(u"࠭࠱࠹࠿ࠪઢ")+LLTHJsQdGUq[-BGhdkWsEvJjiMFTr3NLn1flU(u"࠸࠴జ"):]+qkSQU3saP0D7OvynNzH4F2BKJuilT+PXk8W4RSBMam6lsorYg7yQhed
				Du8jZhbyYHplfOM9KCwn4aFNBxIsPm = XXt3yJYkxgvLsRBpuhZPOH7wMIo(Du8jZhbyYHplfOM9KCwn4aFNBxIsPm.encode(PtXn0k9G3ocHRg(u"ࠧࡶࡶࡩ࠼ࠬણ"))).hexdigest()[:drHLAY5ENQFe2q9ptKGabo(u"࠳࠳ఝ")]
				if Du8jZhbyYHplfOM9KCwn4aFNBxIsPm in s4MbKCZQhlRore0L: return r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࡕࡴࡸࡩౝ")
			efdrTtNzZ8aPpcq = PXk8W4RSBMam6lsorYg7yQhed
	return yF29Xdsx35wI07Ce4(u"ࡈࡤࡰࡸ࡫౞")
def AsTbx64cCEi1(efpI3jkhR8bCtBXr,nnai7yHSxtPWANgbqZUzdeXKuJ1CRc,yywEV0s2I3hRKlS6qj,wv2Ve0xF3UW9c1ABubZ=None):
	MNWrTo98GZHn = ddLvyNFVhnZsrCa1WlJwKj(nnai7yHSxtPWANgbqZUzdeXKuJ1CRc)
	nO1lCyXmdAfQa0MBkEg7I5DGbN2jc = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(BGhdkWsEvJjiMFTr3NLn1flU(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧત"))
	if yywEV0s2I3hRKlS6qj!=KKbpxUZnMcj6AJ4QdD(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬથ") and efpI3jkhR8bCtBXr==bpNSygerL10j4IOkEfuVw:
		if nO1lCyXmdAfQa0MBkEg7I5DGbN2jc==shZ9eOcN2dJnPj(u"ࠪࡗ࡙ࡕࡐࠨદ"): return MNWrTo98GZHn
		hPvDUWG0xTNq6kC = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(pcWq35MED2dtK(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨધ"))
		if hPvDUWG0xTNq6kC==drHLAY5ENQFe2q9ptKGabo(u"ࠬࡘࡅࡇࡔࡈࡗࡍࡋࡄࠨન"):
			ZqlR5BFQ6pm0asCHLUc(efpI3jkhR8bCtBXr,yywEV0s2I3hRKlS6qj,wv2Ve0xF3UW9c1ABubZ)
			return MNWrTo98GZHn
	DZOScCdtBmbIkP48hwL = n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠱ఞ")
	if nO1lCyXmdAfQa0MBkEg7I5DGbN2jc==r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧ઩"): DZOScCdtBmbIkP48hwL = IDbT7Aya2hB180SvVUXFYc
	try: AO76Z1XEaSDjomRwK,BVYESNuJMxlmDo5WXdaFP6r = YWjf06dGFXDTm(efpI3jkhR8bCtBXr)
	except: return MNWrTo98GZHn
	BlmaIXAxDL1Q9FHTiWgn5 = vvBChXmSty(u"ࡗࡶࡺ࡫౟")
	try: BVYESNuJMxlmDo5WXdaFP6r.execute(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࠣࠩપ")+yywEV0s2I3hRKlS6qj+oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠨࠤࠣࡐࡎࡓࡉࡕࠢ࠴ࠤࡀ࠭ફ"))
	except: BlmaIXAxDL1Q9FHTiWgn5 = shZ9eOcN2dJnPj(u"ࡊࡦࡲࡳࡦౠ")
	if BlmaIXAxDL1Q9FHTiWgn5:
		if DZOScCdtBmbIkP48hwL: BVYESNuJMxlmDo5WXdaFP6r.execute(cgtRBdXxSOk7WUfyDhPCls(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩબ")+yywEV0s2I3hRKlS6qj+Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡪࡾࡰࡪࡴࡼࡂࠬભ")+str(s8bXSagYdim62TwIpQzGtUqeLhA1J+DZOScCdtBmbIkP48hwL)+Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠫࠥࡁࠧમ"))
		AO76Z1XEaSDjomRwK.commit()
		BVYESNuJMxlmDo5WXdaFP6r.execute(iifPEY9ABNzTQp(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬય")+yywEV0s2I3hRKlS6qj+n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡦࡺࡳ࡭ࡷࡿ࠼ࠨર")+str(s8bXSagYdim62TwIpQzGtUqeLhA1J)+pcWq35MED2dtK(u"ࠧࠡ࠽ࠪ઱"))
		AO76Z1XEaSDjomRwK.commit()
		if wv2Ve0xF3UW9c1ABubZ:
			fzGPBZRpVXv504s = (str(wv2Ve0xF3UW9c1ABubZ),)
			BVYESNuJMxlmDo5WXdaFP6r.execute(shZ9eOcN2dJnPj(u"ࠨࡕࡈࡐࡊࡉࡔࠡࡦࡤࡸࡦࠦࡆࡓࡑࡐࠤࠧ࠭લ")+yywEV0s2I3hRKlS6qj+ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡧࡴࡲࡵ࡮ࡰࠣࡁࠥࡅࠠ࠼ࠩળ"),fzGPBZRpVXv504s)
			CVRQsZFOWHvK7SpkroU15eyAn = BVYESNuJMxlmDo5WXdaFP6r.fetchall()
			if CVRQsZFOWHvK7SpkroU15eyAn:
				try:
					TwPt5qAHlrOsQ = apKJA5QDiybZeGBk.decompress(CVRQsZFOWHvK7SpkroU15eyAn[pcWq35MED2dtK(u"࠲ట")][pcWq35MED2dtK(u"࠲ట")])
					MNWrTo98GZHn = W7BTz1R3wkMn9.loads(TwPt5qAHlrOsQ)
				except: pass
		else:
			BVYESNuJMxlmDo5WXdaFP6r.execute(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡧࡴࡲࡵ࡮ࡰ࠯ࡨࡦࡺࡡࠡࡈࡕࡓࡒࠦࠢࠨ઴")+yywEV0s2I3hRKlS6qj+Tgoa16jMxvYX2(u"ࠫࠧࠦ࠻ࠨવ"))
			CVRQsZFOWHvK7SpkroU15eyAn = BVYESNuJMxlmDo5WXdaFP6r.fetchall()
			if CVRQsZFOWHvK7SpkroU15eyAn:
				MNWrTo98GZHn,RRVMQHZn0y93kw7A = {},[]
				for U2lhiS4WFPp,XfOb4VIcPY in CVRQsZFOWHvK7SpkroU15eyAn:
					lxLX0WcduZFq2y7j6SVMvw = apKJA5QDiybZeGBk.decompress(XfOb4VIcPY)
					XfOb4VIcPY = W7BTz1R3wkMn9.loads(lxLX0WcduZFq2y7j6SVMvw)
					MNWrTo98GZHn[U2lhiS4WFPp] = XfOb4VIcPY
					RRVMQHZn0y93kw7A.append(U2lhiS4WFPp)
				if RRVMQHZn0y93kw7A:
					MNWrTo98GZHn[wwplD0tEehqH3kYQXs(u"ࠬࡥ࡟ࡔࡇࡔ࡙ࡊࡔࡃࡆࡆࡢࡇࡔࡒࡕࡎࡐࡖࡣࡤ࠭શ")] = RRVMQHZn0y93kw7A
					if nnai7yHSxtPWANgbqZUzdeXKuJ1CRc==CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠭࡬ࡪࡵࡷࠫષ"): MNWrTo98GZHn = RRVMQHZn0y93kw7A
	AO76Z1XEaSDjomRwK.close()
	return MNWrTo98GZHn
class nxekaDlSMp8XFNdEI2G4uC76Ac(OXS0K38lYtj):
	def __init__(fXCnj1ABdeRWiHUE9a8F0gwTrqS):
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.ZlYIFydptHUo5 = yrPav1tl5MQcfEBhsXk2o(JLoPRXt93dpAB(u"ࠧࡄࡖࡈ࠽ࡉ࡙࠱࠺ࡘࡘ࠴࡛࡙ࡘࠨસ"))
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.DkQhl7JM9EVy68ZTc5vGCnSBORf1X = yrPav1tl5MQcfEBhsXk2o(drHLAY5ENQFe2q9ptKGabo(u"ࠨ࡙ࡖ࡙ࡗࡌࡔ࠲࠻ࡔࡘࡊࡌ࡚࡙ࠩહ"))
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.ceqAvtYpB4nO8Cd0HEQmRJuaX = yrPav1tl5MQcfEBhsXk2o(PtXn0k9G3ocHRg(u"ࠩࡅࡘࡊࡾࡐࡗ࠳࠼࡙ࡗ࡜ࡎࡖࡕࡘ࠹ࡍ࡞ࠧ઺"))
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.cjqtyo0Q6niPmCDEzaNKr7IV9 = wwplD0tEehqH3kYQXs(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ઻") if fXCnj1ABdeRWiHUE9a8F0gwTrqS.ZlYIFydptHUo5 else n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"઼ࠫࠬ")
	def YSD4HlZngPAKU(fXCnj1ABdeRWiHUE9a8F0gwTrqS,tzVrBNnMEWYU2eJ0hs1S): fXCnj1ABdeRWiHUE9a8F0gwTrqS.tzVrBNnMEWYU2eJ0hs1S = tzVrBNnMEWYU2eJ0hs1S
	def onPlayBackStopped(fXCnj1ABdeRWiHUE9a8F0gwTrqS): fXCnj1ABdeRWiHUE9a8F0gwTrqS.cjqtyo0Q6niPmCDEzaNKr7IV9 = tZ3gsrTEdzA1S6LXa9WI5px(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬઽ")
	def onPlayBackError(fXCnj1ABdeRWiHUE9a8F0gwTrqS): fXCnj1ABdeRWiHUE9a8F0gwTrqS.cjqtyo0Q6niPmCDEzaNKr7IV9 = PtXn0k9G3ocHRg(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ા")
	def onPlayBackEnded(fXCnj1ABdeRWiHUE9a8F0gwTrqS): fXCnj1ABdeRWiHUE9a8F0gwTrqS.cjqtyo0Q6niPmCDEzaNKr7IV9 = bbw2eajMlG(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧિ")
	def onPlayBackStarted(fXCnj1ABdeRWiHUE9a8F0gwTrqS):
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.cjqtyo0Q6niPmCDEzaNKr7IV9 = tZ3gsrTEdzA1S6LXa9WI5px(u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩી")
		DGCfg8z0FcqHdn = onVDrgLUpFsqOPkxId9BwW6Rtc5A.Thread(target=fXCnj1ABdeRWiHUE9a8F0gwTrqS.P2PUpvxhdzmDC,args=())
		DGCfg8z0FcqHdn.start()
	def onAVStarted(fXCnj1ABdeRWiHUE9a8F0gwTrqS):
		if fXCnj1ABdeRWiHUE9a8F0gwTrqS.DkQhl7JM9EVy68ZTc5vGCnSBORf1X: fXCnj1ABdeRWiHUE9a8F0gwTrqS.cjqtyo0Q6niPmCDEzaNKr7IV9 = InKG0i2r6hHDvgd(u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪુ")
		else: fXCnj1ABdeRWiHUE9a8F0gwTrqS.cjqtyo0Q6niPmCDEzaNKr7IV9 = wwplD0tEehqH3kYQXs(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫૂ")
	def P2PUpvxhdzmDC(fXCnj1ABdeRWiHUE9a8F0gwTrqS):
		from LXgKztbkOf import NNR12uCXPn3V,VGZkudOFTQHgCiM7vY5oezcP,vvZxzV4CkyoPTs
		vvZxzV4CkyoPTs(ggDRehOModi(u"ࠫࡸࡺ࡯ࡱࠩૃ"))
		uJMrhGTaAst = CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠳ఠ")
		while not eval(wwplD0tEehqH3kYQXs(u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳࡯ࡳࡑ࡮ࡤࡽ࡮ࡴࡧࡗ࡫ࡧࡩࡴ࠮ࠩࠨૄ"),{cNaVb1vsT4qWOL0rpE(u"࠭ࡸࡣ࡯ࡦࠫૅ"):bMIascyFJ2x43E0C7glTB91h8qz}) and fXCnj1ABdeRWiHUE9a8F0gwTrqS.cjqtyo0Q6niPmCDEzaNKr7IV9==iifPEY9ABNzTQp(u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࠨ૆"):
			bMIascyFJ2x43E0C7glTB91h8qz.sleep(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠵࠵࠶࠰డ"))
			uJMrhGTaAst += usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠶ఢ")
			if uJMrhGTaAst>Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠼࠰ణ"): return
		if fXCnj1ABdeRWiHUE9a8F0gwTrqS.ZlYIFydptHUo5: fXCnj1ABdeRWiHUE9a8F0gwTrqS.cjqtyo0Q6niPmCDEzaNKr7IV9 = yruHDQOcB97ig(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠩે")
		elif fXCnj1ABdeRWiHUE9a8F0gwTrqS.DkQhl7JM9EVy68ZTc5vGCnSBORf1X: fXCnj1ABdeRWiHUE9a8F0gwTrqS.cjqtyo0Q6niPmCDEzaNKr7IV9 = tZ3gsrTEdzA1S6LXa9WI5px(u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪૈ")
		elif fXCnj1ABdeRWiHUE9a8F0gwTrqS.ceqAvtYpB4nO8Cd0HEQmRJuaX:
			fXCnj1ABdeRWiHUE9a8F0gwTrqS.cjqtyo0Q6niPmCDEzaNKr7IV9 = OyJ1o4AvmWlB75UkFRX(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫૉ")
			RdUQ2TmovCIO6tEp4 = onVDrgLUpFsqOPkxId9BwW6Rtc5A.Thread(target=NNR12uCXPn3V,args=(fXCnj1ABdeRWiHUE9a8F0gwTrqS.tzVrBNnMEWYU2eJ0hs1S,))
			RdUQ2TmovCIO6tEp4.start()
			rvxhTj7t96 = onVDrgLUpFsqOPkxId9BwW6Rtc5A.Thread(target=VGZkudOFTQHgCiM7vY5oezcP,args=())
			rvxhTj7t96.start()
		else: fXCnj1ABdeRWiHUE9a8F0gwTrqS.cjqtyo0Q6niPmCDEzaNKr7IV9 = yF29Xdsx35wI07Ce4(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬ૊")
def kVlD4bJNiLto75IO():
	e4ZvhicJMmKuRWTy1r,nLGvkZwDo02OqSjzHT = tZ3gsrTEdzA1S6LXa9WI5px(u"ࠬ࠭ો"),xuztI5QWEKG70CPNdhk4vo6(u"࠭ࠧૌ")
	aHySYLrifwmjEG3z = bMIascyFJ2x43E0C7glTB91h8qz.getInfoLabel(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴ࡬ࡩࡳࡪ࡬ࡺࡐࡤࡱࡪ્࠭"))
	try:
		GBRx4qUoFAnb1XlIDfdugrHLaeyVc = open(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠨ࠱ࡳࡶࡴࡩ࠯ࡤࡲࡸ࡭ࡳ࡬࡯ࠨ૎"),bcgZJWV6UeNSkRA(u"ࠩࡵࡦࠬ૏")).read()
		if VVGRN7xiyj: GBRx4qUoFAnb1XlIDfdugrHLaeyVc = GBRx4qUoFAnb1XlIDfdugrHLaeyVc.decode(cgtRBdXxSOk7WUfyDhPCls(u"ࠪࡹࡹ࡬࠸ࠨૐ"))
		AGQt8iWy75N4fL3m0eHIgBMPRx = u5h2Rckvw1E.findall(yF29Xdsx35wI07Ce4(u"ࠫࡘ࡫ࡲࡪࡣ࡯࠲࠯ࡅ࠺ࠡࠪ࠱࠮ࡄ࠯ࠤࠨ૑"),GBRx4qUoFAnb1XlIDfdugrHLaeyVc,u5h2Rckvw1E.IGNORECASE)
		if AGQt8iWy75N4fL3m0eHIgBMPRx: e4ZvhicJMmKuRWTy1r = AGQt8iWy75N4fL3m0eHIgBMPRx[iifPEY9ABNzTQp(u"࠰త")]
	except: pass
	try:
		import subprocess as uukUBLq6zE74
		csgwhY93Q0D2MCZmeKWkqH8 = uukUBLq6zE74.Popen(XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠬࡹࡴࡢࡶࠣ࠱ࡨ࡛ࠦࠢࠡࠧࠤࠧࠦ࠯ࡴࡶࡲࡶࡦ࡭ࡥ࠰ࡧࡰࡹࡱࡧࡴࡦࡦ࠲࠴ࠥࡁࠠࡴࡶࡤࡸࠥ࠳ࡣࠡࠤࠣࠩ࡜ࠦࠢࠡ࠱ࡹࡥࡷ࠵࡬ࡰࡩࠪ૒"),shell=bbw2eajMlG(u"࡙ࡸࡵࡦౡ"),stdin=uukUBLq6zE74.PIPE,stdout=uukUBLq6zE74.PIPE,stderr=uukUBLq6zE74.PIPE)
		jWT5mNlUgsbFiBpA9fdy7unkoPwK = csgwhY93Q0D2MCZmeKWkqH8.stdout.read()
		if jWT5mNlUgsbFiBpA9fdy7unkoPwK:
			if VVGRN7xiyj:
				jWT5mNlUgsbFiBpA9fdy7unkoPwK = jWT5mNlUgsbFiBpA9fdy7unkoPwK.decode(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠭ࡵࡵࡨ࠻ࠫ૓"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧ૔"))
			aaBlevFGWDI = u5h2Rckvw1E.findall(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠨࠢࠫࡠࡩࢁ࠱࠱ࡿࠬࠤࠬ૕"),jWT5mNlUgsbFiBpA9fdy7unkoPwK,u5h2Rckvw1E.IGNORECASE)
			if aaBlevFGWDI: nLGvkZwDo02OqSjzHT = min(aaBlevFGWDI)
	except: pass
	return aHySYLrifwmjEG3z,e4ZvhicJMmKuRWTy1r,nLGvkZwDo02OqSjzHT
def lbFixEt3BK9YGMyWIQZuSsp1V7JTL8(RQm6Y8H3oV,FeqGLBOkTEi1=bcgZJWV6UeNSkRA(u"࡚ࡲࡶࡧౢ")):
	Zqn02DHzxMVa6r5bgi = vvBChXmSty(u"ࡔࡳࡷࡨౣ")
	if FeqGLBOkTEi1:
		WW703EDhenLcU6Qu1 = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,qnPgZ9N15G6Oa8UpMASvLk(u"ࠩ࡯࡭ࡸࡺࠧ૖"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭૗"),shZ9eOcN2dJnPj(u"ࠫࡘࡏࡔࡆࡕࡢࡇࡍࡋࡃࡌࠩ૘"))
		if WW703EDhenLcU6Qu1:
			ZIwsUVaiTx0fCXMHcezrLRDQvY,dB97J4mtlriV6wRP,VNbExB2lJpy4YmeWdTgGHOvciK,CsAohFxt8yrbBw = WW703EDhenLcU6Qu1
			Zqn02DHzxMVa6r5bgi = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠬࡲࡩࡴࡶࠪ૙"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ૚"),drHLAY5ENQFe2q9ptKGabo(u"ࠧࡔࡋࡗࡉࡘࡥࡖࡆࡔࡌࡊ࡞࠭૛"))
			if Zqn02DHzxMVa6r5bgi: aHySYLrifwmjEG3z,e4ZvhicJMmKuRWTy1r,nLGvkZwDo02OqSjzHT = Zqn02DHzxMVa6r5bgi
			else: aHySYLrifwmjEG3z,e4ZvhicJMmKuRWTy1r,nLGvkZwDo02OqSjzHT = kVlD4bJNiLto75IO()
			if (dB97J4mtlriV6wRP,VNbExB2lJpy4YmeWdTgGHOvciK,CsAohFxt8yrbBw)==(aHySYLrifwmjEG3z,e4ZvhicJMmKuRWTy1r,nLGvkZwDo02OqSjzHT): return tZ3gsrTEdzA1S6LXa9WI5px(u"ࠨ࡞ࡱࠫ૜").join(ZIwsUVaiTx0fCXMHcezrLRDQvY)
	if Zqn02DHzxMVa6r5bgi: aHySYLrifwmjEG3z,e4ZvhicJMmKuRWTy1r,nLGvkZwDo02OqSjzHT = kVlD4bJNiLto75IO()
	global tO8cCB7jRY9fKh4iZ,J1P6ZeEwNQCVadpnv
	tO8cCB7jRY9fKh4iZ,J1P6ZeEwNQCVadpnv,SMLlu8EqFtkmYJ0gr = oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠩࠪ૝"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࠪࠫ૞"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠫࠬ૟")
	RQm6Y8H3oV = RQm6Y8H3oV//BGhdkWsEvJjiMFTr3NLn1flU(u"࠳థ")
	onVDrgLUpFsqOPkxId9BwW6Rtc5A.Thread(target=F8mIcptnlJ9bGTXORvWVr0A5u).start()
	onVDrgLUpFsqOPkxId9BwW6Rtc5A.Thread(target=cP5Msp3mko0XOFSflYr29).start()
	for k0G4LTYt93po in range(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠳࠳ద")):
		YVJPFvuI2CS5KObiZt.sleep(nKLEi8CJumazx4qT(u"࠳࠲࠺ధ"))
		if not SMLlu8EqFtkmYJ0gr:
			try:
				PKJCrF81BtTAIZiogL7dDkOQ = bMIascyFJ2x43E0C7glTB91h8qz.getInfoLabel(JLoPRXt93dpAB(u"ࠬࡔࡥࡵࡹࡲࡶࡰ࠴ࡍࡢࡥࡄࡨࡩࡸࡥࡴࡵࠪૠ"))
				if PKJCrF81BtTAIZiogL7dDkOQ.count(shZ9eOcN2dJnPj(u"࠭࠺ࠨૡ"))==n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠺఩") and PKJCrF81BtTAIZiogL7dDkOQ.count(Tgoa16jMxvYX2(u"ࠧ࠱ࠩૢ"))<JLoPRXt93dpAB(u"࠽న"):
					PKJCrF81BtTAIZiogL7dDkOQ = PKJCrF81BtTAIZiogL7dDkOQ.lower().replace(OyJ1o4AvmWlB75UkFRX(u"ࠨ࠼ࠪૣ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠩࠪ૤"))
					SMLlu8EqFtkmYJ0gr = str(int(PKJCrF81BtTAIZiogL7dDkOQ,InKG0i2r6hHDvgd(u"࠷࠶ప")))
			except: pass
		if tO8cCB7jRY9fKh4iZ and J1P6ZeEwNQCVadpnv and SMLlu8EqFtkmYJ0gr: break
	CySrs6ucTMKwqUd2QODv7JiflhIX = [tO8cCB7jRY9fKh4iZ,J1P6ZeEwNQCVadpnv,SMLlu8EqFtkmYJ0gr,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠪࠫ૥"),JLoPRXt93dpAB(u"ࠫࠬ૦"),xuztI5QWEKG70CPNdhk4vo6(u"ࠬ࠶࠰࠲࠳࠵࠶࠸࠹࠴࠵࠷࠸࠺࠻࠽࠷ࠨ૧")]
	if e4ZvhicJMmKuRWTy1r or nLGvkZwDo02OqSjzHT:
		from hashlib import md5 as XXt3yJYkxgvLsRBpuhZPOH7wMIo
		vWP4wDAro62jS9ulLtY1sUyxO = [(vvBChXmSty(u"࠵బ"),e4ZvhicJMmKuRWTy1r),(Tgoa16jMxvYX2(u"࠵ఫ"),nLGvkZwDo02OqSjzHT)]
		for LLalIEnYqHb01Kzs6uo3XvOt8MSV,XApzCr15jdx9YK6nRfBq0Q4m in vWP4wDAro62jS9ulLtY1sUyxO:
			XApzCr15jdx9YK6nRfBq0Q4m = XApzCr15jdx9YK6nRfBq0Q4m.strip(yruHDQOcB97ig(u"࠭࠰ࠨ૨"))
			if XApzCr15jdx9YK6nRfBq0Q4m:
				if VVGRN7xiyj: XApzCr15jdx9YK6nRfBq0Q4m = XApzCr15jdx9YK6nRfBq0Q4m.encode(cgtRBdXxSOk7WUfyDhPCls(u"ࠧࡶࡶࡩ࠼ࠬ૩"))
				XApzCr15jdx9YK6nRfBq0Q4m = str(int(XXt3yJYkxgvLsRBpuhZPOH7wMIo(XApzCr15jdx9YK6nRfBq0Q4m).hexdigest(),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠵࠹భ")))
				biHs7p0LWGQ4SR = [int(XApzCr15jdx9YK6nRfBq0Q4m[XG9ncsKyVfZNjHLB2omISJMd51Pae:XG9ncsKyVfZNjHLB2omISJMd51Pae+M6PIj8gl1fno7wcqTksDEBK4bU(u"࠵࠺య")]) for XG9ncsKyVfZNjHLB2omISJMd51Pae in range(len(XApzCr15jdx9YK6nRfBq0Q4m)) if XG9ncsKyVfZNjHLB2omISJMd51Pae%M6PIj8gl1fno7wcqTksDEBK4bU(u"࠵࠺య")==CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠳మ")]
				CySrs6ucTMKwqUd2QODv7JiflhIX[LLalIEnYqHb01Kzs6uo3XvOt8MSV-cgtRBdXxSOk7WUfyDhPCls(u"࠶ర")] = str(sum(biHs7p0LWGQ4SR))
	ZIwsUVaiTx0fCXMHcezrLRDQvY,THSdEtgRsJjkZ3c4uPnolQCFf = [],qnPgZ9N15G6Oa8UpMASvLk(u"ࡇࡣ࡯ࡷࡪ౤")
	for rwWyOkNl6X71Y8 in range(len(CySrs6ucTMKwqUd2QODv7JiflhIX)):
		biHs7p0LWGQ4SR = CySrs6ucTMKwqUd2QODv7JiflhIX[rwWyOkNl6X71Y8]
		if not biHs7p0LWGQ4SR: continue
		if THSdEtgRsJjkZ3c4uPnolQCFf and biHs7p0LWGQ4SR==CySrs6ucTMKwqUd2QODv7JiflhIX[-yF29Xdsx35wI07Ce4(u"࠷ఱ")]: continue
		THSdEtgRsJjkZ3c4uPnolQCFf = bcgZJWV6UeNSkRA(u"ࡖࡵࡹࡪ౥")
		biHs7p0LWGQ4SR = RQm6Y8H3oV*CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠨ࠲ࠪ૪")+biHs7p0LWGQ4SR
		biHs7p0LWGQ4SR = biHs7p0LWGQ4SR[-RQm6Y8H3oV:]
		AxUOHGmdhNlXRq,BGYdPn73JkpK4RD = Tgoa16jMxvYX2(u"ࠩࠪ૫"),nKLEi8CJumazx4qT(u"ࠪࠫ૬")
		P6C5XvAxmrhn8Otkqzo10ufc7yw = str(int(bbw2eajMlG(u"ࠫ࠾࠭૭")*(RQm6Y8H3oV+yF29Xdsx35wI07Ce4(u"࠱ల")))-int(biHs7p0LWGQ4SR))[-RQm6Y8H3oV:]
		for Q0BmlkHz4Dn1pq9EPJeGwWMt in list(range(ggDRehOModi(u"࠱ళ"),RQm6Y8H3oV,Tgoa16jMxvYX2(u"࠶ఴ"))):
			f5Ih2yDVG9x = P6C5XvAxmrhn8Otkqzo10ufc7yw[Q0BmlkHz4Dn1pq9EPJeGwWMt:Q0BmlkHz4Dn1pq9EPJeGwWMt+shZ9eOcN2dJnPj(u"࠷వ")]
			AxUOHGmdhNlXRq += f5Ih2yDVG9x+Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠬ࠳ࠧ૮")
			BGYdPn73JkpK4RD += str(sum(map(int,biHs7p0LWGQ4SR[Q0BmlkHz4Dn1pq9EPJeGwWMt:Q0BmlkHz4Dn1pq9EPJeGwWMt+yruHDQOcB97ig(u"࠹ష")]))%bbw2eajMlG(u"࠵࠵శ"))
		LLTHJsQdGUq = str(rwWyOkNl6X71Y8)+AxUOHGmdhNlXRq+BGYdPn73JkpK4RD
		ZIwsUVaiTx0fCXMHcezrLRDQvY.append(LLTHJsQdGUq)
	OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,M6PIj8gl1fno7wcqTksDEBK4bU(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ૯"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠧࡔࡋࡗࡉࡘࡥࡖࡆࡔࡌࡊ࡞࠭૰"),[aHySYLrifwmjEG3z,e4ZvhicJMmKuRWTy1r,nLGvkZwDo02OqSjzHT],QQJtZ6rMvS1wdDsHnahT7)
	OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,cNaVb1vsT4qWOL0rpE(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ૱"),yruHDQOcB97ig(u"ࠩࡖࡍ࡙ࡋࡓࡠࡅࡋࡉࡈࡑࠧ૲"),[ZIwsUVaiTx0fCXMHcezrLRDQvY,aHySYLrifwmjEG3z,e4ZvhicJMmKuRWTy1r,nLGvkZwDo02OqSjzHT],ebm0Z72CDaBzUq)
	return r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠪࡠࡳ࠭૳").join(ZIwsUVaiTx0fCXMHcezrLRDQvY)
def u5VpIfdK9HTnYk(afxYgsnGTdAHePVBK,GMfo7WypIsRin9HKEZQduYhDetFJOS,MNWrTo98GZHn,vSj57P0g4mF2Bp,BYGZC29KJ5Piag36Dl,Fu63RmidlUsQIgCcOypVYeo):
	emrzEIsMWO2GLw9lpKxSY7n0F = str(vSj57P0g4mF2Bp)[iifPEY9ABNzTQp(u"࠶స"):n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠲࠶࠲హ")].replace(iifPEY9ABNzTQp(u"ࠫࡡࡴࠧ૴"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࠬࡢ࡜࡯ࠩ૵")).replace(M6PIj8gl1fno7wcqTksDEBK4bU(u"࠭࡜ࡳࠩ૶"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠧ࡝࡞ࡵࠫ૷")).replace(cgtRBdXxSOk7WUfyDhPCls(u"ࠨࠢࠣࠤࠥ࠭૸"),shZ9eOcN2dJnPj(u"ࠩࠣࠫૹ")).replace(oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠪࠤࠥࠦࠧૺ"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠫࠥ࠭ૻ"))
	if len(str(vSj57P0g4mF2Bp))>tZ3gsrTEdzA1S6LXa9WI5px(u"࠳࠷࠳఺"): emrzEIsMWO2GLw9lpKxSY7n0F = emrzEIsMWO2GLw9lpKxSY7n0F+oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠬࠦ࠮࠯࠰ࠪૼ")
	XfOb4VIcPY = str(MNWrTo98GZHn)[tZ3gsrTEdzA1S6LXa9WI5px(u"࠲఻"):BGhdkWsEvJjiMFTr3NLn1flU(u"࠵࠹࠵఼")].replace(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠭࡜࡯ࠩ૽"),nKLEi8CJumazx4qT(u"ࠧ࡝࡞ࡱࠫ૾")).replace(KKbpxUZnMcj6AJ4QdD(u"ࠨ࡞ࡵࠫ૿"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠩ࡟ࡠࡷ࠭଀")).replace(KKbpxUZnMcj6AJ4QdD(u"ࠪࠤࠥࠦࠠࠨଁ"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࠫࠥ࠭ଂ")).replace(ggDRehOModi(u"ࠬࠦࠠࠡࠩଃ"),vvBChXmSty(u"࠭ࠠࠨ଄"))
	if len(str(MNWrTo98GZHn))>Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠶࠺࠶ఽ"): XfOb4VIcPY = XfOb4VIcPY+usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠧࠡ࠰࠱࠲ࠬଅ")
	l0SAerv8zGH2Wa(pcWq35MED2dtK(u"ࠨࡐࡒࡘࡎࡉࡅࠨଆ"),cNaVb1vsT4qWOL0rpE(u"ࠩ࠱ࠤࠥࡕࡐࡆࡐࡘࡖࡑࡥࠧଇ")+afxYgsnGTdAHePVBK+ggDRehOModi(u"ࠪࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ଈ")+GMfo7WypIsRin9HKEZQduYhDetFJOS+nKLEi8CJumazx4qT(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ଉ")+BYGZC29KJ5Piag36Dl+cgtRBdXxSOk7WUfyDhPCls(u"ࠬࠦ࡝ࠡࠢࠣࡑࡪࡺࡨࡰࡦ࠽ࠤࡠࠦࠧଊ")+Fu63RmidlUsQIgCcOypVYeo+yruHDQOcB97ig(u"࠭ࠠ࡞ࠢࠣࠤࡍ࡫ࡡࡥࡧࡵࡷ࠿࡛ࠦࠡࠩଋ")+str(emrzEIsMWO2GLw9lpKxSY7n0F)+JLoPRXt93dpAB(u"ࠧࠡ࡟ࠣࠤࠥࡊࡡࡵࡣ࠽ࠤࡠࠦࠧଌ")+XfOb4VIcPY+wwplD0tEehqH3kYQXs(u"ࠨࠢࡠࠫ଍"))
	return
def F8mIcptnlJ9bGTXORvWVr0A5u():
	global tO8cCB7jRY9fKh4iZ
	import getmac82 as BNKbjMUiCORDrI3eHEVX1kt2y6gS
	try:
		HNvriYLtfRy = BNKbjMUiCORDrI3eHEVX1kt2y6gS.get_mac_address()
		if HNvriYLtfRy.count(ggDRehOModi(u"ࠩ࠽ࠫ଎"))==ggDRehOModi(u"࠻ి") and HNvriYLtfRy.count(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠪ࠴ࠬଏ"))<yF29Xdsx35wI07Ce4(u"࠾ా"):
			HNvriYLtfRy = HNvriYLtfRy.lower().replace(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠫ࠿࠭ଐ"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠬ࠭଑"))
			tO8cCB7jRY9fKh4iZ = str(int(HNvriYLtfRy,ggDRehOModi(u"࠱࠷ీ")))
	except: pass
	return
def cP5Msp3mko0XOFSflYr29():
	global J1P6ZeEwNQCVadpnv
	import getmac94 as NN7aCxJLtEz6FbnDWB3dSI
	try:
		EqLDR8GnpOkVmUQCucTslg4SW = NN7aCxJLtEz6FbnDWB3dSI.get_mac_address()
		if EqLDR8GnpOkVmUQCucTslg4SW.count(tZ3gsrTEdzA1S6LXa9WI5px(u"࠭࠺ࠨ଒"))==yF29Xdsx35wI07Ce4(u"࠷ూ") and EqLDR8GnpOkVmUQCucTslg4SW.count(M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠧ࠱ࠩଓ"))<yruHDQOcB97ig(u"࠺ు"):
			EqLDR8GnpOkVmUQCucTslg4SW = EqLDR8GnpOkVmUQCucTslg4SW.lower().replace(shZ9eOcN2dJnPj(u"ࠨ࠼ࠪଔ"),yF29Xdsx35wI07Ce4(u"ࠩࠪକ"))
			J1P6ZeEwNQCVadpnv = str(int(EqLDR8GnpOkVmUQCucTslg4SW,Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠴࠺ృ")))
	except: pass
	return
def LOe4X6kYET(Fu63RmidlUsQIgCcOypVYeo,GMfo7WypIsRin9HKEZQduYhDetFJOS,MNWrTo98GZHn=bbw2eajMlG(u"ࠪࠫଖ"),vSj57P0g4mF2Bp=pcWq35MED2dtK(u"ࠫࠬଗ"),BYGZC29KJ5Piag36Dl=Tgoa16jMxvYX2(u"ࠬ࠭ଘ")):
	u5VpIfdK9HTnYk(bcgZJWV6UeNSkRA(u"࠭ࡕࡓࡎࡏࡍࡇࠦࠠࡐࡒࡈࡒࡤ࡛ࡒࡍࠩଙ"),GMfo7WypIsRin9HKEZQduYhDetFJOS,MNWrTo98GZHn,vSj57P0g4mF2Bp,BYGZC29KJ5Piag36Dl,Fu63RmidlUsQIgCcOypVYeo)
	if VVGRN7xiyj: import urllib.request as ZNOGA8HFVby26mudge73SK
	else: import urllib2 as ZNOGA8HFVby26mudge73SK
	if not vSj57P0g4mF2Bp: vSj57P0g4mF2Bp = {xuztI5QWEKG70CPNdhk4vo6(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫଚ"):wwplD0tEehqH3kYQXs(u"ࠨࠩଛ")}
	if not MNWrTo98GZHn: MNWrTo98GZHn = {}
	if Fu63RmidlUsQIgCcOypVYeo==KKbpxUZnMcj6AJ4QdD(u"ࠩࡊࡉ࡙࠭ଜ"):
		GMfo7WypIsRin9HKEZQduYhDetFJOS = GMfo7WypIsRin9HKEZQduYhDetFJOS+n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠪࡃࠬଝ")+x1SKFacgifEdUthsYBbnC5XyTj(MNWrTo98GZHn)
		MNWrTo98GZHn = None
	elif Fu63RmidlUsQIgCcOypVYeo==Tgoa16jMxvYX2(u"ࠫࡕࡕࡓࡕࠩଞ") and KKbpxUZnMcj6AJ4QdD(u"ࠬࡰࡳࡰࡰࠪଟ") in str(vSj57P0g4mF2Bp):
		from json import dumps as U0ecS5D43xq1XngdI97rjVThBf8
		MNWrTo98GZHn = U0ecS5D43xq1XngdI97rjVThBf8(MNWrTo98GZHn)
		MNWrTo98GZHn = str(MNWrTo98GZHn).encode(KKbpxUZnMcj6AJ4QdD(u"࠭ࡵࡵࡨ࠻ࠫଠ"))
	elif Fu63RmidlUsQIgCcOypVYeo==JLoPRXt93dpAB(u"ࠧࡑࡑࡖࡘࠬଡ"):
		MNWrTo98GZHn = x1SKFacgifEdUthsYBbnC5XyTj(MNWrTo98GZHn)
		MNWrTo98GZHn = MNWrTo98GZHn.encode(drHLAY5ENQFe2q9ptKGabo(u"ࠨࡷࡷࡪ࠽࠭ଢ"))
	try:
		mqzWceUbxvyZ = ZNOGA8HFVby26mudge73SK.Request(GMfo7WypIsRin9HKEZQduYhDetFJOS,headers=vSj57P0g4mF2Bp,data=MNWrTo98GZHn)
		l3lOuS56hyIdjACkcweb1WDrHQgYfa = ZNOGA8HFVby26mudge73SK.urlopen(mqzWceUbxvyZ)
		DMqcCpg8GmefYtWJZITSP29x3nLzO = l3lOuS56hyIdjACkcweb1WDrHQgYfa.read()
		xIj15Wv4h9fOnX,rreason = nKLEi8CJumazx4qT(u"࠶࠵࠶ౄ"),pcWq35MED2dtK(u"ࠩࡒࡏࠬଣ")
	except:
		DMqcCpg8GmefYtWJZITSP29x3nLzO = oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠪࠫତ")
		xIj15Wv4h9fOnX,rreason = -OyJ1o4AvmWlB75UkFRX(u"࠶౅"),BGhdkWsEvJjiMFTr3NLn1flU(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥࡋࡲࡳࡱࡵࠫଥ")
	l0SAerv8zGH2Wa(cNaVb1vsT4qWOL0rpE(u"ࠬࡔࡏࡕࡋࡆࡉࠬଦ"),tZ3gsrTEdzA1S6LXa9WI5px(u"࠭࠮ࠡࠢࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄࠣࠤࡗࡋࡓࡑࡑࡑࡗࡊࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩଧ")+str(xIj15Wv4h9fOnX)+CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩନ")+rreason+tZ3gsrTEdzA1S6LXa9WI5px(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ଩")+BYGZC29KJ5Piag36Dl+ggDRehOModi(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨପ")+GMfo7WypIsRin9HKEZQduYhDetFJOS+qnPgZ9N15G6Oa8UpMASvLk(u"ࠪࠤࡢ࠭ଫ"))
	if DMqcCpg8GmefYtWJZITSP29x3nLzO and VVGRN7xiyj: DMqcCpg8GmefYtWJZITSP29x3nLzO = DMqcCpg8GmefYtWJZITSP29x3nLzO.decode(ggDRehOModi(u"ࠫࡺࡺࡦ࠹ࠩବ"))
	return DMqcCpg8GmefYtWJZITSP29x3nLzO
def sLY7qyAOM6zCSv(K2ipg69nR0XWMumvIlUY5Fo,j7jOnkKYptANdZ9RorHgcW0=KKbpxUZnMcj6AJ4QdD(u"ࠬ࠭ଭ")):
	nBCRa1LI82xMec6 = str(jjyW6FTEOn3sSMo1G5LxBiA.randrange(vvBChXmSty(u"࠷࠱࠲࠳࠴࠵࠶࠷࠱࠲࠳࠴ె"),JLoPRXt93dpAB(u"࠹࠺࠻࠼࠽࠾࠿࠹࠺࠻࠼࠽ే")))
	vSj57P0g4mF2Bp = {r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬମ"):BGhdkWsEvJjiMFTr3NLn1flU(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡰࡳࡰࡰࠪଯ")}
	bYOrisloCV64uXWkHjZe = {	drHLAY5ENQFe2q9ptKGabo(u"ࠣࡷࡶࡩࡷࡥࡩࡥࠤର"):lbFixEt3BK9YGMyWIQZuSsp1V7JTL8(Tgoa16jMxvYX2(u"࠵࠵౉")).splitlines()[wwplD0tEehqH3kYQXs(u"࠳ొ")][-yF29Xdsx35wI07Ce4(u"࠳࠶ై"):],
				OyJ1o4AvmWlB75UkFRX(u"ࠤࡲࡷࡤࡼࡥࡳࡵ࡬ࡳࡳࠨ଱"):str(njGgmsD1k7cE60drxHCyVh2YN3P),
				yruHDQOcB97ig(u"ࠥࡥࡵࡶ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠣଲ"):qkSQU3saP0D7OvynNzH4F2BKJuilT,
				drHLAY5ENQFe2q9ptKGabo(u"ࠦࡩ࡫ࡶࡪࡥࡨࡣ࡫ࡧ࡭ࡪ࡮ࡼࠦଳ"):qkSQU3saP0D7OvynNzH4F2BKJuilT,
				PtXn0k9G3ocHRg(u"ࠧ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠤ଴"):K2ipg69nR0XWMumvIlUY5Fo,
				yF29Xdsx35wI07Ce4(u"ࠨࡰ࡭ࡣࡷࡪࡴࡸ࡭ࠣଵ"): qkSQU3saP0D7OvynNzH4F2BKJuilT,
				InKG0i2r6hHDvgd(u"ࠢࡤࡣࡵࡶ࡮࡫ࡲࠣଶ"):yF29Xdsx35wI07Ce4(u"ࠣࡃࡕࡅࡇࡏࡃࡠࡘࡌࡈࡊࡕࡓࠣଷ"),
				nKLEi8CJumazx4qT(u"ࠤࡨࡺࡪࡴࡴࡠࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷࠧସ"):{usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠥࡉࡻ࡫࡮ࡵࡡࡑࡥࡲ࡫ࠢହ"):K2ipg69nR0XWMumvIlUY5Fo},
				bbw2eajMlG(u"ࠦࡺࡹࡥࡳࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸࠨ଺"): {cgtRBdXxSOk7WUfyDhPCls(u"࡛ࠧࡳࡦࡴࡢࡉࡻ࡫࡮ࡵࡡࡑࡥࡲ࡫ࠢ଻"):K2ipg69nR0XWMumvIlUY5Fo},
				usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠨࠤࡴ࡭࡬ࡴࡤࡻࡳࡦࡴࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹ࡟ࡴࡻࡱࡧ଼ࠧ"):drHLAY5ENQFe2q9ptKGabo(u"ࡉࡥࡱࡹࡥ౦"),
				drHLAY5ENQFe2q9ptKGabo(u"ࠢࡪࡲࠥଽ"): tZ3gsrTEdzA1S6LXa9WI5px(u"ࠣࠦࡵࡩࡲࡵࡴࡦࠤା")
			}
	if not j7jOnkKYptANdZ9RorHgcW0: W0gD4i3CUY = [bYOrisloCV64uXWkHjZe]
	else:
		NfAGzqnTwKSJXa8CE = bYOrisloCV64uXWkHjZe.copy()
		NfAGzqnTwKSJXa8CE[iifPEY9ABNzTQp(u"ࠩࡨࡺࡪࡴࡴࡠࡶࡼࡴࡪ࠭ି")] = j7jOnkKYptANdZ9RorHgcW0
		NfAGzqnTwKSJXa8CE[drHLAY5ENQFe2q9ptKGabo(u"ࠪࡩࡻ࡫࡮ࡵࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸ࠭ୀ")] = {ggDRehOModi(u"ࠦࡊࡼࡥ࡯ࡶࡢࡒࡦࡳࡥࠣୁ"):j7jOnkKYptANdZ9RorHgcW0}
		NfAGzqnTwKSJXa8CE[KKbpxUZnMcj6AJ4QdD(u"ࠬࡻࡳࡦࡴࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠧୂ")] = {r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠨࡕࡴࡧࡵࡣࡊࡼࡥ࡯ࡶࡢࡒࡦࡳࡥࠣୃ"):j7jOnkKYptANdZ9RorHgcW0}
		W0gD4i3CUY = [bYOrisloCV64uXWkHjZe,NfAGzqnTwKSJXa8CE]
	MNWrTo98GZHn = {vvBChXmSty(u"ࠢࡢࡲ࡬ࡣࡰ࡫ࡹࠣୄ"):iifPEY9ABNzTQp(u"ࠨ࠴࠸࠸ࡩࡪ࠳ࡢ࠶࠳࠽ࡩ࠾ࡢ࠷࠺࠴ࡨ࠹࡫࠱࠲࠹ࡨࡩ࠼࠾ࡣࡦࡤࡩ࠶࠾࠭୅"),
			bbw2eajMlG(u"ࠤ࡬ࡲࡸ࡫ࡲࡵࡡ࡬ࡨࠧ୆"):nBCRa1LI82xMec6,
			M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠥࡩࡻ࡫࡮ࡵࡵࠥେ"): W0gD4i3CUY
		}
	GMfo7WypIsRin9HKEZQduYhDetFJOS = n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡰࡪ࠴࠱ࡥࡲࡶ࡬ࡪࡶࡸࡨࡪ࠴ࡣࡰ࡯࠲࠶࠴࡮ࡴࡵࡲࡤࡴ࡮࠭ୈ")
	DMqcCpg8GmefYtWJZITSP29x3nLzO = LOe4X6kYET(InKG0i2r6hHDvgd(u"ࠬࡖࡏࡔࡖࠪ୉"),GMfo7WypIsRin9HKEZQduYhDetFJOS,MNWrTo98GZHn,vSj57P0g4mF2Bp,iifPEY9ABNzTQp(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡇࡑࡈࡤࡇࡎࡂࡎ࡜ࡘࡎࡉࡓࡠࡇ࡙ࡉࡓ࡚࠭࠲ࡵࡷࠫ୊"))
	return DMqcCpg8GmefYtWJZITSP29x3nLzO
def TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ(nnai7yHSxtPWANgbqZUzdeXKuJ1CRc,TwPt5qAHlrOsQ):
	TwPt5qAHlrOsQ = TwPt5qAHlrOsQ.replace(Tgoa16jMxvYX2(u"ࠧ࡯ࡷ࡯ࡰࠬୋ"),JLoPRXt93dpAB(u"ࠨࡐࡲࡲࡪ࠭ୌ"))
	TwPt5qAHlrOsQ = TwPt5qAHlrOsQ.replace(ggDRehOModi(u"ࠩࡷࡶࡺ࡫୍ࠧ"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠪࡘࡷࡻࡥࠨ୎"))
	TwPt5qAHlrOsQ = TwPt5qAHlrOsQ.replace(nKLEi8CJumazx4qT(u"ࠫ࡫ࡧ࡬ࡴࡧࠪ୏"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠬࡌࡡ࡭ࡵࡨࠫ୐"))
	TwPt5qAHlrOsQ = TwPt5qAHlrOsQ.replace(Tgoa16jMxvYX2(u"࠭࡜࠰ࠩ୑"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠧ࠰ࠩ୒"))
	try: lxLX0WcduZFq2y7j6SVMvw = eval(TwPt5qAHlrOsQ)
	except: lxLX0WcduZFq2y7j6SVMvw = ddLvyNFVhnZsrCa1WlJwKj(nnai7yHSxtPWANgbqZUzdeXKuJ1CRc)
	return lxLX0WcduZFq2y7j6SVMvw
def IUxZkrcGM6bJulvQhX():
	afxYgsnGTdAHePVBK,ffAnyTIUapotW4dS6sbC,GMfo7WypIsRin9HKEZQduYhDetFJOS,Fx86vaQXEZeSBDAhmgC9zl7j2fs,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,TwPt5qAHlrOsQ,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv = QPTqwDCWalLdRB9jrkAbIz(O0Dm45eTJi8rlWUCQLbMducERHp)
	LkKHrN2Stnw0avfuWO = u5h2Rckvw1E.findall(BGhdkWsEvJjiMFTr3NLn1flU(u"ࠨ࡞ࡧࡠࡩࡀ࡜ࡥ࡞ࡧࠤࡡࡡ࠯ࡄࡑࡏࡓࡗࡢ࡝ࠨ୓"),ffAnyTIUapotW4dS6sbC,u5h2Rckvw1E.DOTALL)
	if LkKHrN2Stnw0avfuWO: ffAnyTIUapotW4dS6sbC = ffAnyTIUapotW4dS6sbC.split(LkKHrN2Stnw0avfuWO[r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠵ౌ")],PtXn0k9G3ocHRg(u"࠵ో"))[PtXn0k9G3ocHRg(u"࠵ో")]
	QgUks6eVXEmu7iH = YVJPFvuI2CS5KObiZt.strftime(XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠩࡢࠩࡲ࠴ࠥࡥࡡࠨࡌ࠿ࠫࡍࡠࠩ୔"),YVJPFvuI2CS5KObiZt.localtime(s8bXSagYdim62TwIpQzGtUqeLhA1J))
	ffAnyTIUapotW4dS6sbC = ffAnyTIUapotW4dS6sbC+QgUks6eVXEmu7iH
	ttpQZRUwEjhfdOqn = afxYgsnGTdAHePVBK,ffAnyTIUapotW4dS6sbC,GMfo7WypIsRin9HKEZQduYhDetFJOS,Fx86vaQXEZeSBDAhmgC9zl7j2fs,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,TwPt5qAHlrOsQ,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv
	if k1t0JLRsCQ.path.exists(s1KMjlEIH9vd):
		QQM3clG5VWTxqhBUSJYoOf6avpPwy = open(s1KMjlEIH9vd,vvBChXmSty(u"ࠪࡶࡧ࠭୕")).read()
		if VVGRN7xiyj: QQM3clG5VWTxqhBUSJYoOf6avpPwy = QQM3clG5VWTxqhBUSJYoOf6avpPwy.decode(shZ9eOcN2dJnPj(u"ࠫࡺࡺࡦ࠹ࠩୖ"))
		QQM3clG5VWTxqhBUSJYoOf6avpPwy = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ(xuztI5QWEKG70CPNdhk4vo6(u"ࠬࡪࡩࡤࡶࠪୗ"),QQM3clG5VWTxqhBUSJYoOf6avpPwy)
	else: QQM3clG5VWTxqhBUSJYoOf6avpPwy = {}
	zzSfX1AF0D = {}
	for jHfFPgvTYODy0RUENKpB in list(QQM3clG5VWTxqhBUSJYoOf6avpPwy.keys()):
		if jHfFPgvTYODy0RUENKpB!=afxYgsnGTdAHePVBK: zzSfX1AF0D[jHfFPgvTYODy0RUENKpB] = QQM3clG5VWTxqhBUSJYoOf6avpPwy[jHfFPgvTYODy0RUENKpB]
		else:
			if ffAnyTIUapotW4dS6sbC and ffAnyTIUapotW4dS6sbC!=cgtRBdXxSOk7WUfyDhPCls(u"࠭࠮࠯ࠩ୘"):
				Hb3uMNXSBwWYn6VvDt9 = QQM3clG5VWTxqhBUSJYoOf6avpPwy[jHfFPgvTYODy0RUENKpB]
				if ttpQZRUwEjhfdOqn in Hb3uMNXSBwWYn6VvDt9:
					M4Feb15G0QtrDlW6sPh9xNBnC3j = Hb3uMNXSBwWYn6VvDt9.index(ttpQZRUwEjhfdOqn)
					del Hb3uMNXSBwWYn6VvDt9[M4Feb15G0QtrDlW6sPh9xNBnC3j]
				agupMjtTxhzvJcLZ8DklEOW34B = [ttpQZRUwEjhfdOqn]+Hb3uMNXSBwWYn6VvDt9
				agupMjtTxhzvJcLZ8DklEOW34B = agupMjtTxhzvJcLZ8DklEOW34B[:PtXn0k9G3ocHRg(u"࠻࠰్")]
				zzSfX1AF0D[jHfFPgvTYODy0RUENKpB] = agupMjtTxhzvJcLZ8DklEOW34B
			else: zzSfX1AF0D[jHfFPgvTYODy0RUENKpB] = QQM3clG5VWTxqhBUSJYoOf6avpPwy[jHfFPgvTYODy0RUENKpB]
	if afxYgsnGTdAHePVBK not in list(zzSfX1AF0D.keys()): zzSfX1AF0D[afxYgsnGTdAHePVBK] = [ttpQZRUwEjhfdOqn]
	zzSfX1AF0D = str(zzSfX1AF0D)
	if VVGRN7xiyj: zzSfX1AF0D = zzSfX1AF0D.encode(usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠧࡶࡶࡩ࠼ࠬ୙"))
	open(s1KMjlEIH9vd,BGhdkWsEvJjiMFTr3NLn1flU(u"ࠨࡹࡥࠫ୚")).write(zzSfX1AF0D)
	return
def OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(efpI3jkhR8bCtBXr,yywEV0s2I3hRKlS6qj,wv2Ve0xF3UW9c1ABubZ,MNWrTo98GZHn,SrH1lwftenFsM5CQDbOIqG7jpg3,HMU2xNt8ahZfTy9voDijO3A5VI=xuztI5QWEKG70CPNdhk4vo6(u"ࡊࡦࡲࡳࡦ౧")):
	nO1lCyXmdAfQa0MBkEg7I5DGbN2jc = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(OyJ1o4AvmWlB75UkFRX(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨ୛"))
	if nO1lCyXmdAfQa0MBkEg7I5DGbN2jc==XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫଡ଼") and SrH1lwftenFsM5CQDbOIqG7jpg3>IDbT7Aya2hB180SvVUXFYc: SrH1lwftenFsM5CQDbOIqG7jpg3 = IDbT7Aya2hB180SvVUXFYc
	if HMU2xNt8ahZfTy9voDijO3A5VI:
		OlDEqB68KZdI5fsipUJzuavcn,wCcUeBxEHG0YR = [],[]
		for k0G4LTYt93po in range(len(wv2Ve0xF3UW9c1ABubZ)):
			TwPt5qAHlrOsQ = W7BTz1R3wkMn9.dumps(MNWrTo98GZHn[k0G4LTYt93po])
			mmuLyzGPYc = apKJA5QDiybZeGBk.compress(TwPt5qAHlrOsQ)
			OlDEqB68KZdI5fsipUJzuavcn.append((wv2Ve0xF3UW9c1ABubZ[k0G4LTYt93po],))
			wCcUeBxEHG0YR.append((SrH1lwftenFsM5CQDbOIqG7jpg3+s8bXSagYdim62TwIpQzGtUqeLhA1J,str(wv2Ve0xF3UW9c1ABubZ[k0G4LTYt93po]),mmuLyzGPYc))
	else:
		TwPt5qAHlrOsQ = W7BTz1R3wkMn9.dumps(MNWrTo98GZHn)
		XRw6ypJCYTolEkbnftQLIrzq5gSj = apKJA5QDiybZeGBk.compress(TwPt5qAHlrOsQ)
	try: AO76Z1XEaSDjomRwK,BVYESNuJMxlmDo5WXdaFP6r = YWjf06dGFXDTm(efpI3jkhR8bCtBXr)
	except: return
	while wwplD0tEehqH3kYQXs(u"࡙ࡸࡵࡦ౨"):
		try:
			BVYESNuJMxlmDo5WXdaFP6r.execute(iifPEY9ABNzTQp(u"ࠫࡇࡋࡇࡊࡐࠣࡍࡒࡓࡅࡅࡋࡄࡘࡊࠦࡔࡓࡃࡑࡗࡆࡉࡔࡊࡑࡑࠤࡀ࠭ଢ଼"))
			break
		except: YVJPFvuI2CS5KObiZt.sleep(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠰࠯࠷౎"))
	BVYESNuJMxlmDo5WXdaFP6r.execute(KKbpxUZnMcj6AJ4QdD(u"ࠬࡉࡒࡆࡃࡗࡉ࡚ࠥࡁࡃࡎࡈࠤࡎࡌࠠࡏࡑࡗࠤࡊ࡞ࡉࡔࡖࡖࠤࠧ࠭୞")+yywEV0s2I3hRKlS6qj+yruHDQOcB97ig(u"࠭ࠢࠡࠪࡨࡼࡵ࡯ࡲࡺ࠮ࡦࡳࡱࡻ࡭࡯࠮ࡧࡥࡹࡧࠩࠡ࠽ࠪୟ"))
	if HMU2xNt8ahZfTy9voDijO3A5VI:
		BVYESNuJMxlmDo5WXdaFP6r.executemany(Tgoa16jMxvYX2(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧୠ")+yywEV0s2I3hRKlS6qj+nKLEi8CJumazx4qT(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨୡ"),OlDEqB68KZdI5fsipUJzuavcn)
		BVYESNuJMxlmDo5WXdaFP6r.executemany(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࠣࠩୢ")+yywEV0s2I3hRKlS6qj+oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠪࠦࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮࠿࠭ࡁ࠯ࡃ࠮ࠦ࠻ࠨୣ"),wCcUeBxEHG0YR)
	else:
		if SrH1lwftenFsM5CQDbOIqG7jpg3:
			fzGPBZRpVXv504s = (str(wv2Ve0xF3UW9c1ABubZ),)
			BVYESNuJMxlmDo5WXdaFP6r.execute(KKbpxUZnMcj6AJ4QdD(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫ୤")+yywEV0s2I3hRKlS6qj+xuztI5QWEKG70CPNdhk4vo6(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࠽ࠡࡁࠣ࠿ࠬ୥"),fzGPBZRpVXv504s)
			fzGPBZRpVXv504s = (SrH1lwftenFsM5CQDbOIqG7jpg3+s8bXSagYdim62TwIpQzGtUqeLhA1J,str(wv2Ve0xF3UW9c1ABubZ),XRw6ypJCYTolEkbnftQLIrzq5gSj)
			BVYESNuJMxlmDo5WXdaFP6r.execute(yruHDQOcB97ig(u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࠧ࠭୦")+yywEV0s2I3hRKlS6qj+yruHDQOcB97ig(u"࡙ࠧࠣࠢࡅࡑ࡛ࡅࡔࠢࠫࡃ࠱ࡅࠬࡀࠫࠣ࠿ࠬ୧"),fzGPBZRpVXv504s)
		else:
			fzGPBZRpVXv504s = (XRw6ypJCYTolEkbnftQLIrzq5gSj,str(wv2Ve0xF3UW9c1ABubZ))
			BVYESNuJMxlmDo5WXdaFP6r.execute(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠨࡗࡓࡈࡆ࡚ࡅࠡࠤࠪ୨")+yywEV0s2I3hRKlS6qj+drHLAY5ENQFe2q9ptKGabo(u"ࠩࠥࠤࡘࡋࡔࠡࡦࡤࡸࡦࠦ࠽ࠡࡁ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨ୩"),fzGPBZRpVXv504s)
	AO76Z1XEaSDjomRwK.commit()
	AO76Z1XEaSDjomRwK.close()
	return
def x1SKFacgifEdUthsYBbnC5XyTj(MNWrTo98GZHn):
	if VVGRN7xiyj: import urllib.parse as s0FjrxhcW4oGuCiN5
	else: import urllib as s0FjrxhcW4oGuCiN5
	NDwKeuf1pO = s0FjrxhcW4oGuCiN5.urlencode(MNWrTo98GZHn)
	return NDwKeuf1pO
cjqtyo0Q6niPmCDEzaNKr7IV9 = qnPgZ9N15G6Oa8UpMASvLk(u"ࠪࠫ୪")
def om1iZDWnrhGa2SLB9O4kfxYbqU(UcmHDPlLWaSf,d60XNEgVHxC3quhUoZnk9rsRTWDG=n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠫࠬ୫"),EWgxGbZUsCLOPTD4BJId2afR7oHk9N=ggDRehOModi(u"ࠬ࠭୬")):
	XzBe74OInf1RVJtc3TiWp = d60XNEgVHxC3quhUoZnk9rsRTWDG not in [nKLEi8CJumazx4qT(u"࠭ࡍ࠴ࡗࠪ୭"),KKbpxUZnMcj6AJ4QdD(u"ࠧࡊࡒࡗ࡚ࠬ୮")]
	global cjqtyo0Q6niPmCDEzaNKr7IV9
	if not EWgxGbZUsCLOPTD4BJId2afR7oHk9N: EWgxGbZUsCLOPTD4BJId2afR7oHk9N = JLoPRXt93dpAB(u"ࠨࡸ࡬ࡨࡪࡵࠧ୯")
	cjqtyo0Q6niPmCDEzaNKr7IV9,SdzvCxbHh6tUcPW1Tm3O4EN5Q,Xt1l6aQjeqWuJY7HFDowCGb = shZ9eOcN2dJnPj(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧ࠴ࠬ୰"),drHLAY5ENQFe2q9ptKGabo(u"ࠪࠫୱ"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠫࠬ୲")
	if len(UcmHDPlLWaSf)==InKG0i2r6hHDvgd(u"࠴౏"):
		GMfo7WypIsRin9HKEZQduYhDetFJOS,S62xm7qsR9CI,Xt1l6aQjeqWuJY7HFDowCGb = UcmHDPlLWaSf
		if S62xm7qsR9CI: SdzvCxbHh6tUcPW1Tm3O4EN5Q = tZ3gsrTEdzA1S6LXa9WI5px(u"ࠬࠦࠠࠡࡕࡸࡦࡹ࡯ࡴ࡭ࡧ࠽ࠤࡠࠦࠧ୳")+S62xm7qsR9CI+yF29Xdsx35wI07Ce4(u"࠭ࠠ࡞ࠩ୴")
	else: GMfo7WypIsRin9HKEZQduYhDetFJOS,S62xm7qsR9CI,Xt1l6aQjeqWuJY7HFDowCGb = UcmHDPlLWaSf,cgtRBdXxSOk7WUfyDhPCls(u"ࠧࠨ୵"),yF29Xdsx35wI07Ce4(u"ࠨࠩ୶")
	GMfo7WypIsRin9HKEZQduYhDetFJOS = GMfo7WypIsRin9HKEZQduYhDetFJOS.replace(cgtRBdXxSOk7WUfyDhPCls(u"ࠩࠨ࠶࠵࠭୷"),InKG0i2r6hHDvgd(u"ࠪࠤࠬ୸"))
	ViRnO0m8fUScTNauvW = XS8G7Ljnkut(GMfo7WypIsRin9HKEZQduYhDetFJOS)
	if d60XNEgVHxC3quhUoZnk9rsRTWDG not in [PtXn0k9G3ocHRg(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭୹"),yruHDQOcB97ig(u"ࠬࡏࡐࡕࡘࠪ୺")]:
		if d60XNEgVHxC3quhUoZnk9rsRTWDG!=Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ୻"): GMfo7WypIsRin9HKEZQduYhDetFJOS = GMfo7WypIsRin9HKEZQduYhDetFJOS.replace(cgtRBdXxSOk7WUfyDhPCls(u"ࠧࠡࠩ୼"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠨࠧ࠵࠴ࠬ୽"))
		l0SAerv8zGH2Wa(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ୾"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+pcWq35MED2dtK(u"ࠪࠤࠥࠦࡐࡳࡧࡳࡥࡷ࡯࡮ࡨࠢࡷࡳࠥࡶ࡬ࡢࡻ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡼࡩࡥࡧࡲࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ୿")+GMfo7WypIsRin9HKEZQduYhDetFJOS+bbw2eajMlG(u"ࠫࠥࡣࠧ஀")+SdzvCxbHh6tUcPW1Tm3O4EN5Q)
		if ViRnO0m8fUScTNauvW==usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ஁") and d60XNEgVHxC3quhUoZnk9rsRTWDG not in [qnPgZ9N15G6Oa8UpMASvLk(u"࠭ࡉࡑࡖ࡙ࠫஂ"),xuztI5QWEKG70CPNdhk4vo6(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨஃ")]:
			from LXgKztbkOf import bkz2aCFLpWqGUcPolSXA980O,tYysxJLreEBDdXMIjz4OPa,dnS80F92qtLi4vw1
			hVby8e3aQkFfuE,EaBeVhOsHYg8wub = bkz2aCFLpWqGUcPolSXA980O(GMfo7WypIsRin9HKEZQduYhDetFJOS)
			tDlfOHiebr0MUx765c = len(EaBeVhOsHYg8wub)
			if tDlfOHiebr0MUx765c>ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠳౐"):
				u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = tYysxJLreEBDdXMIjz4OPa(XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠠࠩࠩ஄")+str(tDlfOHiebr0MUx765c)+pcWq35MED2dtK(u"้้ࠩࠣ็ࠩࠨஅ"), hVby8e3aQkFfuE)
				if u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo==-pcWq35MED2dtK(u"࠴౑"):
					dnS80F92qtLi4vw1(OyJ1o4AvmWlB75UkFRX(u"ࠪฮ๊ࠦลๅ฼สลࠥอไหึ฽๎้࠭ஆ"),JLoPRXt93dpAB(u"ࠫࠬஇ"))
					return cjqtyo0Q6niPmCDEzaNKr7IV9
			else: u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = bbw2eajMlG(u"࠴౒")
			GMfo7WypIsRin9HKEZQduYhDetFJOS = EaBeVhOsHYg8wub[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
			if hVby8e3aQkFfuE[usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠵౓")]!=PtXn0k9G3ocHRg(u"ࠬ࠳࠱ࠨஈ"):
				l0SAerv8zGH2Wa(qnPgZ9N15G6Oa8UpMASvLk(u"࠭ࡎࡐࡖࡌࡇࡊ࠭உ"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+shZ9eOcN2dJnPj(u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡖࡩࡱ࡫ࡣࡵࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡯࡯࡯࠼ࠣ࡟ࠥ࠭ஊ")+hVby8e3aQkFfuE[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]+cgtRBdXxSOk7WUfyDhPCls(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ஋")+GMfo7WypIsRin9HKEZQduYhDetFJOS+shZ9eOcN2dJnPj(u"ࠩࠣࡡࠬ஌"))
		if drHLAY5ENQFe2q9ptKGabo(u"ࠪ࠳࡮࡬ࡩ࡭࡯࠲ࠫ஍") in GMfo7WypIsRin9HKEZQduYhDetFJOS: GMfo7WypIsRin9HKEZQduYhDetFJOS = GMfo7WypIsRin9HKEZQduYhDetFJOS+OyJ1o4AvmWlB75UkFRX(u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠩࠫஎ")
		elif M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠬ࡮ࡴࡵࡲࠪஏ") in GMfo7WypIsRin9HKEZQduYhDetFJOS.lower() and r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠭࠯ࡥࡣࡶ࡬࠴࠭ஐ") not in GMfo7WypIsRin9HKEZQduYhDetFJOS and oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ஑") not in GMfo7WypIsRin9HKEZQduYhDetFJOS:
			if InKG0i2r6hHDvgd(u"ࠨࡸࡨࡶ࡮࡬ࡹࡱࡧࡨࡶࡂ࠭ஒ") not in GMfo7WypIsRin9HKEZQduYhDetFJOS and tZ3gsrTEdzA1S6LXa9WI5px(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫஓ") in GMfo7WypIsRin9HKEZQduYhDetFJOS.lower():
				if M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠪࢀࠬஔ") not in GMfo7WypIsRin9HKEZQduYhDetFJOS: GMfo7WypIsRin9HKEZQduYhDetFJOS = GMfo7WypIsRin9HKEZQduYhDetFJOS+cNaVb1vsT4qWOL0rpE(u"ࠫࢁࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࡩࡥࡱࡹࡥࠨக")
				else: GMfo7WypIsRin9HKEZQduYhDetFJOS = GMfo7WypIsRin9HKEZQduYhDetFJOS+vvBChXmSty(u"ࠬࠬࡶࡦࡴ࡬ࡪࡾࡶࡥࡦࡴࡀࡪࡦࡲࡳࡦࠩ஖")
			if JLoPRXt93dpAB(u"࠭ࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࠪ஗") not in GMfo7WypIsRin9HKEZQduYhDetFJOS.lower() and d60XNEgVHxC3quhUoZnk9rsRTWDG not in [r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠧࡊࡒࡗ࡚ࠬ஘"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠨࡏ࠶࡙ࠬங")]:
				if BGhdkWsEvJjiMFTr3NLn1flU(u"ࠩࡿࠫச") not in GMfo7WypIsRin9HKEZQduYhDetFJOS: GMfo7WypIsRin9HKEZQduYhDetFJOS = GMfo7WypIsRin9HKEZQduYhDetFJOS+yF29Xdsx35wI07Ce4(u"ࠪࢀ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠨࠪ஛")
				else: GMfo7WypIsRin9HKEZQduYhDetFJOS = GMfo7WypIsRin9HKEZQduYhDetFJOS+yruHDQOcB97ig(u"࡛ࠫࠫࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠩࠫஜ")
	l0SAerv8zGH2Wa(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ஝"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+bcgZJWV6UeNSkRA(u"࠭ࠠࠡࠢࡊࡳࡹࠦࡦࡪࡰࡤࡰࠥࡻࡲ࡭ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬஞ")+GMfo7WypIsRin9HKEZQduYhDetFJOS+wwplD0tEehqH3kYQXs(u"ࠧࠡ࡟ࠪட"))
	MrU5Awj34OmQHEo = XuWPVcQ13oDq5swf0S.ListItem()
	EWgxGbZUsCLOPTD4BJId2afR7oHk9N,QG4JKD1kYXNazgnxlPr9WFRZ,nJZr96iD14wfebYudRShUFyHjkzAo,DCSjNrcfWakGO2yVo9LXt8Fg4JZxPK,E6T9RGlrWixPbQVMBIJzh8eYHwkAL,gwiP7zvsEaOMJnkBHpAqy8eYNR,FT0vADQCPhzUnOZsLGk,VM0ekQbdFrifC,ZbuUnz90tsTRAkXm = QPTqwDCWalLdRB9jrkAbIz(O0Dm45eTJi8rlWUCQLbMducERHp)
	if d60XNEgVHxC3quhUoZnk9rsRTWDG not in [usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ஠"),PtXn0k9G3ocHRg(u"ࠩࡌࡔ࡙࡜ࠧ஡")]:
		if bdptXFc8UlIhA5jnGwPmKuv2L: fiDxJE2IYFylG3vNszwuCe = JLoPRXt93dpAB(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭ࡢࡦࡧࡳࡳ࠭஢")
		else: fiDxJE2IYFylG3vNszwuCe = cgtRBdXxSOk7WUfyDhPCls(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮ࠩண")
		MrU5Awj34OmQHEo.setProperty(fiDxJE2IYFylG3vNszwuCe, vvBChXmSty(u"ࠬ࠭த"))
		MrU5Awj34OmQHEo.setMimeType(drHLAY5ENQFe2q9ptKGabo(u"࠭࡭ࡪ࡯ࡨ࠳ࡽ࠳ࡴࡺࡲࡨࠫ஥"))
		if njGgmsD1k7cE60drxHCyVh2YN3P<BGhdkWsEvJjiMFTr3NLn1flU(u"࠸࠰౔"): MrU5Awj34OmQHEo.setInfo(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠧࡷ࡫ࡧࡩࡴ࠭஦"),{tZ3gsrTEdzA1S6LXa9WI5px(u"ࠨ࡯ࡨࡨ࡮ࡧࡴࡺࡲࡨࠫ஧"):qnPgZ9N15G6Oa8UpMASvLk(u"ࠩࡰࡳࡻ࡯ࡥࠨந")})
		else:
			tDpQaoxdUP1KZbTNSyEczX2IJRnLF9 = MrU5Awj34OmQHEo.getVideoInfoTag()
			tDpQaoxdUP1KZbTNSyEczX2IJRnLF9.setMediaType(InKG0i2r6hHDvgd(u"ࠪࡱࡴࡼࡩࡦࠩன"))
		MrU5Awj34OmQHEo.setArt({JLoPRXt93dpAB(u"ࠫࡹ࡮ࡵ࡮ࡤࠪப"):E6T9RGlrWixPbQVMBIJzh8eYHwkAL,OyJ1o4AvmWlB75UkFRX(u"ࠬࡶ࡯ࡴࡶࡨࡶࠬ஫"):E6T9RGlrWixPbQVMBIJzh8eYHwkAL,yruHDQOcB97ig(u"࠭ࡢࡢࡰࡱࡩࡷ࠭஬"):E6T9RGlrWixPbQVMBIJzh8eYHwkAL,usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠧࡧࡣࡱࡥࡷࡺࠧ஭"):E6T9RGlrWixPbQVMBIJzh8eYHwkAL,nKLEi8CJumazx4qT(u"ࠨࡥ࡯ࡩࡦࡸࡡࡳࡶࠪம"):E6T9RGlrWixPbQVMBIJzh8eYHwkAL,nKLEi8CJumazx4qT(u"ࠩࡦࡰࡪࡧࡲ࡭ࡱࡪࡳࠬய"):E6T9RGlrWixPbQVMBIJzh8eYHwkAL,KKbpxUZnMcj6AJ4QdD(u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭ர"):E6T9RGlrWixPbQVMBIJzh8eYHwkAL,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠫ࡮ࡩ࡯࡯ࠩற"):E6T9RGlrWixPbQVMBIJzh8eYHwkAL})
		if ViRnO0m8fUScTNauvW in [Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠬ࠴࡭ࡱࡦࠪல"),bbw2eajMlG(u"࠭࠮࡮࠵ࡸ࠼ࠬள")]: MrU5Awj34OmQHEo.setContentLookup(r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࡚ࡲࡶࡧ౩"))
		else: MrU5Awj34OmQHEo.setContentLookup(r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࡆࡢ࡮ࡶࡩ౪"))
		from y5yjS2UFkc import tj2FJQMlTw
		if xuztI5QWEKG70CPNdhk4vo6(u"ࠧࡳࡶࡰࡴࠬழ") in GMfo7WypIsRin9HKEZQduYhDetFJOS:
			tj2FJQMlTw(shZ9eOcN2dJnPj(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫவ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࡇࡣ࡯ࡷࡪ౫"))
		elif ViRnO0m8fUScTNauvW==r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠩ࠱ࡱࡵࡪࠧஶ") or n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠪ࠳ࡩࡧࡳࡩ࠱ࠪஷ") in GMfo7WypIsRin9HKEZQduYhDetFJOS:
			tj2FJQMlTw(vvBChXmSty(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫஸ"),OyJ1o4AvmWlB75UkFRX(u"ࡈࡤࡰࡸ࡫౬"))
			MrU5Awj34OmQHEo.setProperty(fiDxJE2IYFylG3vNszwuCe,bbw2eajMlG(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬஹ"))
			MrU5Awj34OmQHEo.setProperty(cgtRBdXxSOk7WUfyDhPCls(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠴࡭ࡢࡰ࡬ࡪࡪࡹࡴࡠࡶࡼࡴࡪ࠭஺"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࠧ࡮ࡲࡧࠫ஻"))
		if S62xm7qsR9CI:
			MrU5Awj34OmQHEo.setSubtitles([S62xm7qsR9CI])
	if EWgxGbZUsCLOPTD4BJId2afR7oHk9N==Tgoa16jMxvYX2(u"ࠨࡸ࡬ࡨࡪࡵࠧ஼") and d60XNEgVHxC3quhUoZnk9rsRTWDG==cgtRBdXxSOk7WUfyDhPCls(u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ஽"):
		cjqtyo0Q6niPmCDEzaNKr7IV9 = bcgZJWV6UeNSkRA(u"ࠪࡴࡱࡧࡹࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪா")
		d60XNEgVHxC3quhUoZnk9rsRTWDG = pcWq35MED2dtK(u"ࠫࡕࡒࡁ࡚ࡡࡇࡐࡤࡌࡉࡍࡇࡖࠫி")
	elif EWgxGbZUsCLOPTD4BJId2afR7oHk9N==nKLEi8CJumazx4qT(u"ࠬࡼࡩࡥࡧࡲࠫீ") and VM0ekQbdFrifC.startswith(OyJ1o4AvmWlB75UkFRX(u"࠭࠶ࠨு")):
		cjqtyo0Q6niPmCDEzaNKr7IV9 = bcgZJWV6UeNSkRA(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩூ")
		d60XNEgVHxC3quhUoZnk9rsRTWDG = d60XNEgVHxC3quhUoZnk9rsRTWDG+KKbpxUZnMcj6AJ4QdD(u"ࠨࡡࡇࡐࠬ௃")
	if cjqtyo0Q6niPmCDEzaNKr7IV9!=yF29Xdsx35wI07Ce4(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ௄"): IUxZkrcGM6bJulvQhX()
	OoTmVhFNzWk = nxekaDlSMp8XFNdEI2G4uC76Ac()
	if OoTmVhFNzWk.cjqtyo0Q6niPmCDEzaNKr7IV9: return wwplD0tEehqH3kYQXs(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ௅")
	OoTmVhFNzWk.YSD4HlZngPAKU(d60XNEgVHxC3quhUoZnk9rsRTWDG)
	if EWgxGbZUsCLOPTD4BJId2afR7oHk9N==InKG0i2r6hHDvgd(u"ࠫࡻ࡯ࡤࡦࡱࠪெ") and not VM0ekQbdFrifC.startswith(M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠬ࠼ࠧே")):
		MrU5Awj34OmQHEo.setPath(GMfo7WypIsRin9HKEZQduYhDetFJOS)
		l0SAerv8zGH2Wa(cNaVb1vsT4qWOL0rpE(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ை"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+nKLEi8CJumazx4qT(u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡳࡰࡦࡿࠠࡶࡵ࡬ࡲ࡬ࠦࡳࡦࡶࡕࡩࡸࡵ࡬ࡷࡧࡧ࡙ࡷࡲࠨࠪࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ௉")+GMfo7WypIsRin9HKEZQduYhDetFJOS+pcWq35MED2dtK(u"ࠨࠢࡠࠫொ"))
		oejGsrTCZ05k2X7LlHnPa3h8vzAbJy.setResolvedUrl(Y40Szd1kTwqQxFXm6HO8tRlAvepK,cgtRBdXxSOk7WUfyDhPCls(u"ࡗࡶࡺ࡫౭"),MrU5Awj34OmQHEo)
	elif EWgxGbZUsCLOPTD4BJId2afR7oHk9N==r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠩ࡯࡭ࡻ࡫ࠧோ"):
		l0SAerv8zGH2Wa(vvBChXmSty(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪௌ"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+drHLAY5ENQFe2q9ptKGabo(u"ࠫࠥࠦࠠࡍ࡫ࡹࡩࠥࡶ࡬ࡢࡻࠣࡹࡸ࡯࡮ࡨࠢࡳࡰࡦࡿࠨࠪࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤ்ࠬ")+GMfo7WypIsRin9HKEZQduYhDetFJOS+xuztI5QWEKG70CPNdhk4vo6(u"ࠬࠦ࡝ࠨ௎"))
		OoTmVhFNzWk.play(GMfo7WypIsRin9HKEZQduYhDetFJOS,MrU5Awj34OmQHEo)
	V5VXz0j3oa6t = PtXn0k9G3ocHRg(u"ࡊࡦࡲࡳࡦ౮")
	if cjqtyo0Q6niPmCDEzaNKr7IV9==BGhdkWsEvJjiMFTr3NLn1flU(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ௏"):
		from HwvICGKDxB import IpLtBvKCrhfo2
		V5VXz0j3oa6t = IpLtBvKCrhfo2(GMfo7WypIsRin9HKEZQduYhDetFJOS,ViRnO0m8fUScTNauvW,d60XNEgVHxC3quhUoZnk9rsRTWDG)
		if V5VXz0j3oa6t: IUxZkrcGM6bJulvQhX()
	else:
		pKOBP5j4yJQIxsUENle9VR2YDwT,cjqtyo0Q6niPmCDEzaNKr7IV9,r8l1jPxV5F4gITWC7,OTU5FgQ1rK23WB9G0NqVuci,x1xzj7oOpJKBRdEY = cNaVb1vsT4qWOL0rpE(u"࠰ౕ"),vvBChXmSty(u"ࠧࡵࡴ࡬ࡩࡩ࠭ௐ"),KKbpxUZnMcj6AJ4QdD(u"ࡋࡧ࡬ࡴࡧ౯"),JLoPRXt93dpAB(u"࠳࠳࠴࠵౗"),PtXn0k9G3ocHRg(u"࠴࠲࠳࠴࠵ౖ")
		if XzBe74OInf1RVJtc3TiWp: from LXgKztbkOf import dnS80F92qtLi4vw1
		while pKOBP5j4yJQIxsUENle9VR2YDwT<x1xzj7oOpJKBRdEY:
			bMIascyFJ2x43E0C7glTB91h8qz.sleep(OTU5FgQ1rK23WB9G0NqVuci)
			pKOBP5j4yJQIxsUENle9VR2YDwT += OTU5FgQ1rK23WB9G0NqVuci
			if OoTmVhFNzWk.cjqtyo0Q6niPmCDEzaNKr7IV9==xuztI5QWEKG70CPNdhk4vo6(u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩ௑") and not r8l1jPxV5F4gITWC7:
				if XzBe74OInf1RVJtc3TiWp: dnS80F92qtLi4vw1(yruHDQOcB97ig(u"้ࠩะาࠦสี฼ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪ௒"),iifPEY9ABNzTQp(u"ࠪࠫ௓"),YVJPFvuI2CS5KObiZt=xuztI5QWEKG70CPNdhk4vo6(u"࠺࠹࠵ౘ"))
				l0SAerv8zGH2Wa(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ௔"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+ggDRehOModi(u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࠤ࡛࡯ࡤࡦࡱࠣࡷࡹࡧࡲࡵࡧࡧࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ௕")+GMfo7WypIsRin9HKEZQduYhDetFJOS+drHLAY5ENQFe2q9ptKGabo(u"࠭ࠠ࡞ࠩ௖")+SdzvCxbHh6tUcPW1Tm3O4EN5Q)
				r8l1jPxV5F4gITWC7 = yruHDQOcB97ig(u"࡚ࡲࡶࡧ౰")
			elif OoTmVhFNzWk.cjqtyo0Q6niPmCDEzaNKr7IV9 in [BGhdkWsEvJjiMFTr3NLn1flU(u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨௗ"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠨࡶࡨࡷࡹ࡯࡮ࡨࠩ௘")]:
				l0SAerv8zGH2Wa(drHLAY5ENQFe2q9ptKGabo(u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ௙"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+cgtRBdXxSOk7WUfyDhPCls(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺࡙ࠡࠢ࡭ࡩ࡫࡯ࠡࡲ࡯ࡥࡾ࡯࡮ࡨࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ௚")+GMfo7WypIsRin9HKEZQduYhDetFJOS+PtXn0k9G3ocHRg(u"ࠫࠥࡣࠧ௛")+SdzvCxbHh6tUcPW1Tm3O4EN5Q)
				break
			elif OoTmVhFNzWk.cjqtyo0Q6niPmCDEzaNKr7IV9==bbw2eajMlG(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ௜"):
				l0SAerv8zGH2Wa(yF29Xdsx35wI07Ce4(u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ௝"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+yF29Xdsx35wI07Ce4(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡴࡱࡧࡹࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭௞")+GMfo7WypIsRin9HKEZQduYhDetFJOS+M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠨࠢࡠࠫ௟")+SdzvCxbHh6tUcPW1Tm3O4EN5Q)
				if XzBe74OInf1RVJtc3TiWp: dnS80F92qtLi4vw1(oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠩไุ้ࠦสี฼ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪ௠"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠪࠫ௡"),YVJPFvuI2CS5KObiZt=vvBChXmSty(u"࠵࠷࠻࠰ౙ"))
				break
			elif OoTmVhFNzWk.cjqtyo0Q6niPmCDEzaNKr7IV9==tZ3gsrTEdzA1S6LXa9WI5px(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬ௢"):
				l0SAerv8zGH2Wa(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠬࡋࡒࡓࡑࡕࠫ௣"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+cgtRBdXxSOk7WUfyDhPCls(u"࠭ࠠࠡࠢࡇࡩࡻ࡯ࡣࡦࠢ࡬ࡷࠥࡨ࡬ࡰࡥ࡮ࡩࡩࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ௤")+GMfo7WypIsRin9HKEZQduYhDetFJOS+qnPgZ9N15G6Oa8UpMASvLk(u"ࠧࠡ࡟ࠪ௥"))
				break
		else:
			if XzBe74OInf1RVJtc3TiWp: dnS80F92qtLi4vw1(vvBChXmSty(u"ࠨใื่ࠥะิ฻์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩ௦"),yruHDQOcB97ig(u"ࠩࠪ௧"),YVJPFvuI2CS5KObiZt=cNaVb1vsT4qWOL0rpE(u"࠶࠸࠵࠱ౚ"))
			l0SAerv8zGH2Wa(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ௨"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+cNaVb1vsT4qWOL0rpE(u"ࠫࠥࠦࠠࡕ࡫ࡰࡩࡴࡻࡴ࠻࡙ࠢࠣࡳࡱ࡮ࡰࡹࡱࠤࡵࡸ࡯ࡣ࡮ࡨࡱࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ௩")+GMfo7WypIsRin9HKEZQduYhDetFJOS+xuztI5QWEKG70CPNdhk4vo6(u"ࠬࠦ࡝ࠨ௪")+SdzvCxbHh6tUcPW1Tm3O4EN5Q)
			cjqtyo0Q6niPmCDEzaNKr7IV9 = OyJ1o4AvmWlB75UkFRX(u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ௫")
	if cjqtyo0Q6niPmCDEzaNKr7IV9 in [cgtRBdXxSOk7WUfyDhPCls(u"ࠧࡱ࡮ࡤࡽࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ௬")] or OoTmVhFNzWk.cjqtyo0Q6niPmCDEzaNKr7IV9 in [vvBChXmSty(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ௭"),pcWq35MED2dtK(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪ௮")] or V5VXz0j3oa6t:
		if OoTmVhFNzWk.cjqtyo0Q6niPmCDEzaNKr7IV9==Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫ௯"): d60XNEgVHxC3quhUoZnk9rsRTWDG = d60XNEgVHxC3quhUoZnk9rsRTWDG+PtXn0k9G3ocHRg(u"ࠫࡤ࡚ࡓࠨ௰")
		l3lOuS56hyIdjACkcweb1WDrHQgYfa = sLY7qyAOM6zCSv(d60XNEgVHxC3quhUoZnk9rsRTWDG)
	else: exec(InKG0i2r6hHDvgd(u"ࠬ࡯࡭ࡱࡱࡵࡸࠥࡾࡢ࡮ࡥ࠾ࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱ࡷࡹࡵࡰࠩࠫࠪ௱"))
	return OoTmVhFNzWk.cjqtyo0Q6niPmCDEzaNKr7IV9
def XS8G7Ljnkut(GMfo7WypIsRin9HKEZQduYhDetFJOS):
	ViRnO0m8fUScTNauvW = u5h2Rckvw1E.findall(nKLEi8CJumazx4qT(u"࠭ࠨ࡝࠰ࡤࡺ࡮ࢂ࡜࠯ࡶࡶࢀࡡ࠴ࡡࡢࡥࡿࡠ࠳ࡳࡰ࠵ࡾ࡟࠲ࡲ࠹ࡵࡽ࡞࠱ࡱ࠸ࡻ࠸ࡽ࡞࠱ࡱࡵࡪࡼ࡝࠰ࡰ࡯ࡻࢂ࡜࠯ࡨ࡯ࡺࢁࡢ࠮࡮ࡲ࠶ࢀࡡ࠴ࡷࡦࡤࡰ࠭࠭ࢂ࡜ࡀ࠰࠭ࡃࢁ࠵࡜ࡀ࠰࠭ࡃࢁࡢࡼ࠯ࠬࡂ࠭ࠩ࠭௲"),GMfo7WypIsRin9HKEZQduYhDetFJOS.lower(),u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.IGNORECASE)
	ViRnO0m8fUScTNauvW = ViRnO0m8fUScTNauvW[yF29Xdsx35wI07Ce4(u"࠶౛")][yF29Xdsx35wI07Ce4(u"࠶౛")] if ViRnO0m8fUScTNauvW else OyJ1o4AvmWlB75UkFRX(u"ࠧࠨ௳")
	return ViRnO0m8fUScTNauvW
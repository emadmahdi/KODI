# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'DAILYMOTION'
tiCRYyX1bWd40Ir3PafQu = '_DLM_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
nIo981YOgF2lx7JNevV4b0K6shuzA = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][1]
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text,type,BzbaC0qYjMr2WXwsO):
	if	 mode==400: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==401: vS7JufTVsBxw52 = GOrHALhMKgUi3R70QwV6NEfktjyc(url,text)
	elif mode==402: vS7JufTVsBxw52 = dd708amoqEwRTgJCZ(url,text)
	elif mode==403: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url,text)
	elif mode==404: vS7JufTVsBxw52 = eNYdwGrCvjKLi219snyHchfFo(text,BzbaC0qYjMr2WXwsO)
	elif mode==405: vS7JufTVsBxw52 = BPr8StvTIigjRHf3U(text,BzbaC0qYjMr2WXwsO)
	elif mode==406: vS7JufTVsBxw52 = rPDtdioMLEvA7VcZe3by1xfJS(text,BzbaC0qYjMr2WXwsO)
	elif mode==407: vS7JufTVsBxw52 = Orcs6oqjbyKeWZwQS870(url,BzbaC0qYjMr2WXwsO)
	elif mode==408: vS7JufTVsBxw52 = mGBn69FKE0SiMLJoqQ4IlusjCTtw(url,BzbaC0qYjMr2WXwsO)
	elif mode==409: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text,BzbaC0qYjMr2WXwsO)
	elif mode==411: vS7JufTVsBxw52 = HHE6h2WkpxAZdYL5eVKfOJbyB8jr(url,text)
	elif mode==412: vS7JufTVsBxw52 = lluFay1zsMUPZIShjN7tokQm(text,BzbaC0qYjMr2WXwsO)
	elif mode==413: vS7JufTVsBxw52 = GDIdrMtu2U0vV7fWeiLFKnp6Ns9(url,BzbaC0qYjMr2WXwsO)
	elif mode==414: vS7JufTVsBxw52 = sYz28eRqgtUXHVEMpL5lTF(text)
	elif mode==415: vS7JufTVsBxw52 = UtRoJx0hVYBAsNGpbDdjWiwf(text,BzbaC0qYjMr2WXwsO)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الرئيسية','',414)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',409,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث عن فيديوهات','',409,'','videos?sortBy=','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث عن آخر الفيديوهات','',409,'','videos?sortBy=RECENT','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث عن الفيديوهات الأكثر مشاهدة','',409,'','videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث عن قوائم التشغيل','',409,'','playlists','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث عن قنوات','',409,'','channels','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث عن مواضيع','',409,'','topics','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث عن بث حي','',409,'','lives','_REMEMBERRESULTS_')
	return
def dd708amoqEwRTgJCZ(url,zawKLhDJey6dvZxo):
	if '/dm_' in url:
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',url,'','',False,'','DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = RoQL91PphqCJg4W0e6Fnsl.headers
		if 'Location' in list(headers.keys()): url = yONJxHER9BIDPpTV4YsWmc0n+headers['Location']
	zawKLhDJey6dvZxo = '[COLOR FFC89008]'+zawKLhDJey6dvZxo+'[/COLOR]'
	zawKLhDJey6dvZxo = x81xRtwz3YyspILvC(zawKLhDJey6dvZxo)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+':: بث حي',url,411,'','','channel_lives_now')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+':: آخر الفيديوهات',url+'/videos',408)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+':: المميزة',url,411,'','','channel_featured_videos')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+':: قوائم التشغيل',url+'/playlists',407)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+':: قنوات ذات صلة',url,411,'','','channel_related_channel')
	return
def x81xRtwz3YyspILvC(title):
	title = title.rstrip('\\').strip(' ').replace('\\\\','\\')
	title = ffbxegm1XPSqIwp8i(title)
	return title
def N5AOlmb8u1y4FHxvJXU(url,FRov4fbHu7K):
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr([url],aUVSgO2ebjwX5iqPykC,'video',url)
	return
def eNYdwGrCvjKLi219snyHchfFo(search,BzbaC0qYjMr2WXwsO=''):
	if BzbaC0qYjMr2WXwsO=='': BzbaC0qYjMr2WXwsO = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = ''
	search = search.split('/videos')[0]
	VemfsE32zgI = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	VemfsE32zgI = VemfsE32zgI.replace('mysearchwords',search)
	VemfsE32zgI = VemfsE32zgI.replace('mypagelimit','40')
	VemfsE32zgI = VemfsE32zgI.replace('mypagenumber',BzbaC0qYjMr2WXwsO)
	if sort=='': VemfsE32zgI = VemfsE32zgI.replace('mysortmethod','')
	else: VemfsE32zgI = VemfsE32zgI.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = yONJxHER9BIDPpTV4YsWmc0n+'/search/'+search+'/videos'
	oo9SgGkiDbs3HRn7z8 = hGN5i12oWLnzIqfc(VemfsE32zgI)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"videos"(.*?)"VideoConnection"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('"node".*?"xid":"(.*?)","title":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for id,title,wvaNQfiJShLGmIrVMp50Ke89ZPb,zawKLhDJey6dvZxo,vNbeHULAy6gc4iE,pGjsvdyHfM in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in pGjsvdyHfM: pGjsvdyHfM = pGjsvdyHfM.replace('"','')
			if '"' in vNbeHULAy6gc4iE: vNbeHULAy6gc4iE = vNbeHULAy6gc4iE.replace('"','')
			if '"' in wvaNQfiJShLGmIrVMp50Ke89ZPb: wvaNQfiJShLGmIrVMp50Ke89ZPb = wvaNQfiJShLGmIrVMp50Ke89ZPb.replace('"','')
			if '"' in zawKLhDJey6dvZxo: zawKLhDJey6dvZxo = zawKLhDJey6dvZxo.replace('"','')
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/video/'+id
			title = x81xRtwz3YyspILvC(title)
			FRov4fbHu7K = wvaNQfiJShLGmIrVMp50Ke89ZPb+'::'+zawKLhDJey6dvZxo
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,403,pGjsvdyHfM,vNbeHULAy6gc4iE,FRov4fbHu7K)
		if '"hasNextPage":true' in oo9SgGkiDbs3HRn7z8:
			BzbaC0qYjMr2WXwsO = str(int(BzbaC0qYjMr2WXwsO)+1)
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+BzbaC0qYjMr2WXwsO,url,404,'',BzbaC0qYjMr2WXwsO,search)
	return
def BPr8StvTIigjRHf3U(search,BzbaC0qYjMr2WXwsO=''):
	if BzbaC0qYjMr2WXwsO=='': BzbaC0qYjMr2WXwsO = '1'
	VemfsE32zgI = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	VemfsE32zgI = VemfsE32zgI.replace('mysearchwords',search)
	VemfsE32zgI = VemfsE32zgI.replace('mypagelimit','40')
	VemfsE32zgI = VemfsE32zgI.replace('mypagenumber',BzbaC0qYjMr2WXwsO)
	url = yONJxHER9BIDPpTV4YsWmc0n+'/search/'+search+'/playlists'
	oo9SgGkiDbs3HRn7z8 = hGN5i12oWLnzIqfc(VemfsE32zgI)
	items = u5h2Rckvw1E.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)".*?"total":(.*?),',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	for id,name,bDEvG1tsKWAj2CkQoJ,wvaNQfiJShLGmIrVMp50Ke89ZPb,zawKLhDJey6dvZxo,pGjsvdyHfM,count in items:
		if '"' in bDEvG1tsKWAj2CkQoJ: bDEvG1tsKWAj2CkQoJ = bDEvG1tsKWAj2CkQoJ.replace('"','')
		if '"' in wvaNQfiJShLGmIrVMp50Ke89ZPb: wvaNQfiJShLGmIrVMp50Ke89ZPb = wvaNQfiJShLGmIrVMp50Ke89ZPb.replace('"','')
		if '"' in zawKLhDJey6dvZxo: zawKLhDJey6dvZxo = zawKLhDJey6dvZxo.replace('"','')
		if '"' in id: id = id.replace('"','')
		if '"' in name: name = name.replace('"','')
		if '"' in pGjsvdyHfM: pGjsvdyHfM = pGjsvdyHfM.replace('"','')
		if '"' in count: count = count.replace('"','')
		ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = x81xRtwz3YyspILvC(title)
		FRov4fbHu7K = wvaNQfiJShLGmIrVMp50Ke89ZPb+'::'+zawKLhDJey6dvZxo
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,401,pGjsvdyHfM,'',FRov4fbHu7K)
	if '"hasNextPage":true' in oo9SgGkiDbs3HRn7z8:
		BzbaC0qYjMr2WXwsO = str(int(BzbaC0qYjMr2WXwsO)+1)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+BzbaC0qYjMr2WXwsO,url,405,'',BzbaC0qYjMr2WXwsO,search)
	return
def rPDtdioMLEvA7VcZe3by1xfJS(search,BzbaC0qYjMr2WXwsO=''):
	if BzbaC0qYjMr2WXwsO=='': BzbaC0qYjMr2WXwsO = '1'
	VemfsE32zgI = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	VemfsE32zgI = VemfsE32zgI.replace('mysearchwords',search)
	VemfsE32zgI = VemfsE32zgI.replace('mypagelimit','40')
	VemfsE32zgI = VemfsE32zgI.replace('mypagenumber',BzbaC0qYjMr2WXwsO)
	url = yONJxHER9BIDPpTV4YsWmc0n+'/search/'+search+'/channels'
	oo9SgGkiDbs3HRn7z8 = hGN5i12oWLnzIqfc(VemfsE32zgI)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"channels"(.*?)"ChannelConnection"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('"node".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for id,name,pGjsvdyHfM in items:
			if '"' in id: id = id.replace('"','')
			if '"' in name: name = name.replace('"','')
			if '"' in pGjsvdyHfM: pGjsvdyHfM = pGjsvdyHfM.replace('"','')
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/'+id
			title = 'CHNL:  '+name
			title = x81xRtwz3YyspILvC(title)
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,402,pGjsvdyHfM,'',name)
		if '"hasNextPage":true' in oo9SgGkiDbs3HRn7z8:
			BzbaC0qYjMr2WXwsO = str(int(BzbaC0qYjMr2WXwsO)+1)
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+BzbaC0qYjMr2WXwsO,url,406,'',BzbaC0qYjMr2WXwsO,search)
	return
def sYz28eRqgtUXHVEMpL5lTF(OU1N43IGgQsVbZ):
	VemfsE32zgI = '{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  thumbnail: coverURL(size: \"x532\")\n  coverURL: coverURL(size: \"x532\")\n  isFollowed\n  whitelistStatus {\n    id\n    isWhitelisted\n    __typename\n  }\n  __typename\n}\n\nquery HOME_QUERY($space: String!) {\n  home: views {\n    id\n    neon {\n      id\n      sections(space: $space) {\n        edges {\n          node {\n            id\n            name\n            title\n            description\n            groupingType\n            type\n            relatedComponent {\n              __typename\n              ... on Collection {\n                id\n                xid\n                __typename\n              }\n              ... on Channel {\n                id\n                xid\n                name\n                displayName\n                logoURL(size: \"x60\")\n                __typename\n              }\n              ... on Topic {\n                id\n                __typename\n                ...TOPIC_BASE_FRAG\n              }\n            }\n            components {\n              edges {\n                node {\n                  __typename\n                  ... on Video {\n                    id\n                    xid\n                    title\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx360: thumbnailURL(size: \"x360\")\n                    thumbnailx480: thumbnailURL(size: \"x480\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    aspectRatio\n                    createdAt\n                    channel {\n                      id\n                      xid\n                      name\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      accountType\n                      __typename\n                    }\n                    description\n                    duration\n                    __typename\n                  }\n                  ... on Live {\n                    id\n                    xid\n                    title\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx360: thumbnailURL(size: \"x360\")\n                    thumbnailx480: thumbnailURL(size: \"x480\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    aspectRatio\n                    createdAt\n                    channel {\n                      id\n                      xid\n                      name\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      accountType\n                      __typename\n                    }\n                    startAt\n                    __typename\n                  }\n                }\n                __typename\n              }\n              __typename\n            }\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	p30JfYmwhcv = hGN5i12oWLnzIqfc(VemfsE32zgI)
	if p30JfYmwhcv:
		HnohvruzPSM3Eyq = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('dict',p30JfYmwhcv)
		n8lJNd3viuQWS42hCwTBx = HnohvruzPSM3Eyq['data']['home']['neon']['sections']['edges']
		if not OU1N43IGgQsVbZ:
			Y3HKjSROrz2m = []
			for zzKshqHt7QD30nIOgW6NTcE in n8lJNd3viuQWS42hCwTBx:
				tiO2xz94yEPGepRkoSsl = zzKshqHt7QD30nIOgW6NTcE['node']['title']
				if tiO2xz94yEPGepRkoSsl not in Y3HKjSROrz2m: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+tiO2xz94yEPGepRkoSsl,'',414,'','',tiO2xz94yEPGepRkoSsl)
				Y3HKjSROrz2m.append(tiO2xz94yEPGepRkoSsl)
		else:
			for zzKshqHt7QD30nIOgW6NTcE in n8lJNd3viuQWS42hCwTBx:
				tiO2xz94yEPGepRkoSsl = zzKshqHt7QD30nIOgW6NTcE['node']['title']
				if tiO2xz94yEPGepRkoSsl==OU1N43IGgQsVbZ:
					NtZBOpPj7h1iKa = zzKshqHt7QD30nIOgW6NTcE['node']['components']['edges']
					for cckamqsB8Pn0 in NtZBOpPj7h1iKa:
						vNbeHULAy6gc4iE = str(cckamqsB8Pn0['node']['duration'])
						title = ffbxegm1XPSqIwp8i(cckamqsB8Pn0['node']['title'])
						title = title.replace('\/','/')
						kXgmjIq7TM8 = cckamqsB8Pn0['node']['xid']
						pGjsvdyHfM = cckamqsB8Pn0['node']['thumbnailx480']
						pGjsvdyHfM = pGjsvdyHfM.replace('\/','/')
						ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/video/'+kXgmjIq7TM8
						uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,403,pGjsvdyHfM,vNbeHULAy6gc4iE)
	return
def UtRoJx0hVYBAsNGpbDdjWiwf(search,BzbaC0qYjMr2WXwsO=''):
	if BzbaC0qYjMr2WXwsO=='': BzbaC0qYjMr2WXwsO = '1'
	VemfsE32zgI = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  aspectRatio\n  __typename\n}\n\nfragment VIDEO_FAVORITES_FRAGMENT on Media {\n  __typename\n  ... on Video {\n    id\n    viewerEngagement {\n      id\n      favorited\n      __typename\n    }\n    __typename\n  }\n  ... on Live {\n    id\n    viewerEngagement {\n      id\n      favorited\n      __typename\n    }\n    __typename\n  }\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  videos(sort: \"recent\", first: 5) {\n    pageInfo {\n      hasNextPage\n      nextPage\n      __typename\n    }\n    edges {\n      node {\n        id\n        ...VIDEO_BASE_FRAGMENT\n        ...VIDEO_FAVORITES_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(\n      query: $query\n      first: $limit\n      page: $page\n      sort: $sortByVideos\n      durationMin: $durationMinVideos\n      durationMax: $durationMaxVideos\n      createdAfter: $createdAfterVideos\n    ) @include(if: $shouldIncludeVideos) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_FAVORITES_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          xid\n          title\n          thumbnail: thumbnailURL(size: \"x240\")\n          thumbnailx60: thumbnailURL(size: \"x60\")\n          thumbnailx120: thumbnailURL(size: \"x120\")\n          thumbnailx240: thumbnailURL(size: \"x240\")\n          thumbnailx720: thumbnailURL(size: \"x720\")\n          audienceCount\n          aspectRatio\n          isOnAir\n          channel {\n            id\n            xid\n            name\n            displayName\n            accountType\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...TOPIC_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	VemfsE32zgI = VemfsE32zgI.replace('mysearchwords',search)
	VemfsE32zgI = VemfsE32zgI.replace('mypagelimit','40')
	VemfsE32zgI = VemfsE32zgI.replace('mypagenumber',BzbaC0qYjMr2WXwsO)
	url = yONJxHER9BIDPpTV4YsWmc0n+'/search/'+search+'/lives'
	p30JfYmwhcv = hGN5i12oWLnzIqfc(VemfsE32zgI)
	if p30JfYmwhcv:
		HnohvruzPSM3Eyq = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('dict',p30JfYmwhcv)
		try: n8lJNd3viuQWS42hCwTBx = HnohvruzPSM3Eyq['data']['search']['lives']['edges']
		except: n8lJNd3viuQWS42hCwTBx = []
		for zzKshqHt7QD30nIOgW6NTcE in n8lJNd3viuQWS42hCwTBx:
			name = zzKshqHt7QD30nIOgW6NTcE['node']['title']
			kXgmjIq7TM8 = zzKshqHt7QD30nIOgW6NTcE['node']['xid']
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/video/'+kXgmjIq7TM8
			uQNUfbZx9yj0F('live',tiCRYyX1bWd40Ir3PafQu+'LIVE: '+name,ekTrZlFMu0Kf5QztEnhAs,403)
		if '"hasNextPage":true' in p30JfYmwhcv:
			BzbaC0qYjMr2WXwsO = str(int(BzbaC0qYjMr2WXwsO)+1)
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+BzbaC0qYjMr2WXwsO,url,415,'',BzbaC0qYjMr2WXwsO,search)
	return
def lluFay1zsMUPZIShjN7tokQm(search,BzbaC0qYjMr2WXwsO=''):
	if BzbaC0qYjMr2WXwsO=='': BzbaC0qYjMr2WXwsO = '1'
	VemfsE32zgI = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  aspectRatio\n  __typename\n}\n\nfragment VIDEO_FAVORITES_FRAGMENT on Media {\n  __typename\n  ... on Video {\n    id\n    isInWatchLater\n    __typename\n  }\n  ... on Live {\n    id\n    isInWatchLater\n    __typename\n  }\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  videos(sort: \"recent\", first: 5) {\n    pageInfo {\n      hasNextPage\n      nextPage\n      __typename\n    }\n    edges {\n      node {\n        id\n        ...VIDEO_BASE_FRAGMENT\n        ...VIDEO_FAVORITES_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(\n      query: $query\n      first: $limit\n      page: $page\n      sort: $sortByVideos\n      durationMin: $durationMinVideos\n      durationMax: $durationMaxVideos\n      createdAfter: $createdAfterVideos\n    ) @include(if: $shouldIncludeVideos) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_FAVORITES_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...TOPIC_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	VemfsE32zgI = VemfsE32zgI.replace('mysearchwords',search)
	VemfsE32zgI = VemfsE32zgI.replace('mypagelimit','40')
	VemfsE32zgI = VemfsE32zgI.replace('mypagenumber',BzbaC0qYjMr2WXwsO)
	url = yONJxHER9BIDPpTV4YsWmc0n+'/search/'+search+'/topics'
	p30JfYmwhcv = hGN5i12oWLnzIqfc(VemfsE32zgI)
	if p30JfYmwhcv:
		HnohvruzPSM3Eyq = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('dict',p30JfYmwhcv)
		try: n8lJNd3viuQWS42hCwTBx = HnohvruzPSM3Eyq['data']['search']['topics']['edges']
		except: n8lJNd3viuQWS42hCwTBx = []
		for zzKshqHt7QD30nIOgW6NTcE in n8lJNd3viuQWS42hCwTBx:
			name = zzKshqHt7QD30nIOgW6NTcE['node']['name']
			kXgmjIq7TM8 = zzKshqHt7QD30nIOgW6NTcE['node']['xid']
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/topic/'+kXgmjIq7TM8
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'TOPIC: '+name,ekTrZlFMu0Kf5QztEnhAs,413)
		if '"hasNextPage":true' in p30JfYmwhcv:
			BzbaC0qYjMr2WXwsO = str(int(BzbaC0qYjMr2WXwsO)+1)
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+BzbaC0qYjMr2WXwsO,url,412,'',BzbaC0qYjMr2WXwsO,search)
	return
def GDIdrMtu2U0vV7fWeiLFKnp6Ns9(url,BzbaC0qYjMr2WXwsO=''):
	if BzbaC0qYjMr2WXwsO=='': BzbaC0qYjMr2WXwsO = '1'
	kXgmjIq7TM8 = url.split('/')[-1]
	VemfsE32zgI = '{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  duration\n  isLiked\n  isInWatchLater\n  isCreatedForKids\n  createdAt\n  isExplicit\n  videoHeight: height\n  videoWidth: width\n  category\n  channel {\n    id\n    xid\n    name\n    displayName\n    logoURLx25: logoURL(size: \"x25\")\n    logoURL(size: \"x60\")\n    accountType\n    __typename\n  }\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  language {\n    id\n    codeAlpha2\n    __typename\n  }\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  bestAvailableQuality\n  aspectRatio\n  isPublished\n  __typename\n}\n\nquery DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {\n  topic(xid: $xid) {\n    id\n    xid\n    name\n    videos(sort: \"recent\", first: 30, page: $page) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          ...TOPIC_VIDEO_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	VemfsE32zgI = VemfsE32zgI.replace('mytopicid',kXgmjIq7TM8)
	VemfsE32zgI = VemfsE32zgI.replace('mypagenumber',BzbaC0qYjMr2WXwsO)
	p30JfYmwhcv = hGN5i12oWLnzIqfc(VemfsE32zgI)
	if p30JfYmwhcv:
		HnohvruzPSM3Eyq = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('dict',p30JfYmwhcv)
		n8lJNd3viuQWS42hCwTBx = HnohvruzPSM3Eyq['data']['topic']['videos']['edges']
		for zzKshqHt7QD30nIOgW6NTcE in n8lJNd3viuQWS42hCwTBx:
			vNbeHULAy6gc4iE = str(zzKshqHt7QD30nIOgW6NTcE['node']['duration'])
			title = ffbxegm1XPSqIwp8i(zzKshqHt7QD30nIOgW6NTcE['node']['title'])
			title = title.replace('\/','/')
			kXgmjIq7TM8 = zzKshqHt7QD30nIOgW6NTcE['node']['xid']
			pGjsvdyHfM = zzKshqHt7QD30nIOgW6NTcE['node']['thumbnailx480']
			pGjsvdyHfM = pGjsvdyHfM.replace('\/','/')
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/video/'+kXgmjIq7TM8
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,403,pGjsvdyHfM,vNbeHULAy6gc4iE)
		if '"hasNextPage":true' in p30JfYmwhcv:
			BzbaC0qYjMr2WXwsO = str(int(BzbaC0qYjMr2WXwsO)+1)
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+BzbaC0qYjMr2WXwsO,url,413,'',BzbaC0qYjMr2WXwsO)
	return
def GOrHALhMKgUi3R70QwV6NEfktjyc(url,FRov4fbHu7K):
	id = url.split('/')[-1]
	wvaNQfiJShLGmIrVMp50Ke89ZPb,zawKLhDJey6dvZxo = FRov4fbHu7K.split('::',1)
	ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/'+wvaNQfiJShLGmIrVMp50Ke89ZPb
	zawKLhDJey6dvZxo = x81xRtwz3YyspILvC(zawKLhDJey6dvZxo)
	title = '[COLOR FFC89008]OWNER:  '+zawKLhDJey6dvZxo+'[/COLOR]'
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,402,'','',zawKLhDJey6dvZxo)
	VemfsE32zgI = '{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {\n  views {\n    id\n    neon {\n      id\n      sections(device: $device, space: \"watching\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {\n        edges {\n          node {\n            id\n            name\n            groupingType\n            relatedComponent {\n              ... on Channel {\n                __typename\n                id\n                xid\n                name\n                displayName\n                logoURL(size: \"x60\")\n                logoURLx25: logoURL(size: \"x25\")\n              }\n              ... on Topic {\n                __typename\n                id\n                xid\n                name\n                names {\n                  edges {\n                    node {\n                      id\n                      name\n                      language {\n                        id\n                        codeAlpha2\n                        __typename\n                      }\n                      __typename\n                    }\n                    __typename\n                  }\n                  __typename\n                }\n              }\n              ... on Collection {\n                __typename\n                id\n                xid\n                name\n              }\n              __typename\n            }\n            components(first: $videoCountPerSection) {\n              metadata {\n                algorithm {\n                  name\n                  version\n                  uuid\n                  __typename\n                }\n                __typename\n              }\n              edges {\n                node {\n                  ... on Video {\n                    __typename\n                    id\n                    xid\n                    title\n                    duration\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    channel {\n                      id\n                      xid\n                      accountType\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      logoURL(size: \"x60\")\n                      __typename\n                    }\n                  }\n                  ... on Channel {\n                    __typename\n                    id\n                    xid\n                    name\n                    displayName\n                    accountType\n                    logoURL(size: \"x60\")\n                  }\n                  __typename\n                }\n                __typename\n              }\n              __typename\n            }\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	VemfsE32zgI = VemfsE32zgI.replace('myplaylistid',id)
	oo9SgGkiDbs3HRn7z8 = hGN5i12oWLnzIqfc(VemfsE32zgI)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"collection_videos"(.*?)"SectionEdge"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)".*?"xid":"(.*?)".*?"displayName":"(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for id,title,vNbeHULAy6gc4iE,pGjsvdyHfM,wvaNQfiJShLGmIrVMp50Ke89ZPb,zawKLhDJey6dvZxo in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in pGjsvdyHfM: pGjsvdyHfM = pGjsvdyHfM.replace('"','')
			if '"' in vNbeHULAy6gc4iE: vNbeHULAy6gc4iE = vNbeHULAy6gc4iE.replace('"','')
			if '"' in wvaNQfiJShLGmIrVMp50Ke89ZPb: wvaNQfiJShLGmIrVMp50Ke89ZPb = wvaNQfiJShLGmIrVMp50Ke89ZPb.replace('"','')
			if '"' in zawKLhDJey6dvZxo: zawKLhDJey6dvZxo = zawKLhDJey6dvZxo.replace('"','')
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/video/'+id
			title = x81xRtwz3YyspILvC(title)
			FRov4fbHu7K = wvaNQfiJShLGmIrVMp50Ke89ZPb+'::'+zawKLhDJey6dvZxo
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,403,pGjsvdyHfM,vNbeHULAy6gc4iE,FRov4fbHu7K)
	return
def mGBn69FKE0SiMLJoqQ4IlusjCTtw(url,BzbaC0qYjMr2WXwsO=''):
	if BzbaC0qYjMr2WXwsO=='': BzbaC0qYjMr2WXwsO = '1'
	eitKAc89owDhTpUWvmBrxM6RI = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	VemfsE32zgI = '{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  isFollowed\n  accountType\n  __typename\n}\n\nfragment CHANNEL_IMAGES_FRAGMENT on Channel {\n  id\n  coverURLx375: coverURL(size: \"x375\")\n  __typename\n}\n\nfragment CHANNEL_UPDATED_FRAGMENT on Channel {\n  id\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_COMPLETE_FRAGMENT on Channel {\n  id\n  ...CHANNEL_BASE_FRAGMENT\n  ...CHANNEL_IMAGES_FRAGMENT\n  ...CHANNEL_UPDATED_FRAGMENT\n  description\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  externalLinks {\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  viewCount\n  duration\n  createdAt\n  isInWatchLater\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  thumbURLx240: thumbnailURL(size: \"x240\")\n  thumbURLx360: thumbnailURL(size: \"x360\")\n  thumbURLx480: thumbnailURL(size: \"x480\")\n  thumbURLx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nquery CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {\n  channel(xid: $channel_xid) {\n    id\n    ...CHANNEL_COMPLETE_FRAGMENT\n    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          ...VIDEO_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	VemfsE32zgI = VemfsE32zgI.replace('mychannelid',eitKAc89owDhTpUWvmBrxM6RI)
	VemfsE32zgI = VemfsE32zgI.replace('mypagelimit','40')
	VemfsE32zgI = VemfsE32zgI.replace('mypagenumber',BzbaC0qYjMr2WXwsO)
	VemfsE32zgI = VemfsE32zgI.replace('mysortmethod',sort)
	oo9SgGkiDbs3HRn7z8 = hGN5i12oWLnzIqfc(VemfsE32zgI)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbURLx240":"(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for id,title,vNbeHULAy6gc4iE,wvaNQfiJShLGmIrVMp50Ke89ZPb,zawKLhDJey6dvZxo,pGjsvdyHfM in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in pGjsvdyHfM: pGjsvdyHfM = pGjsvdyHfM.replace('"','')
			if '"' in vNbeHULAy6gc4iE: vNbeHULAy6gc4iE = vNbeHULAy6gc4iE.replace('"','')
			if '"' in wvaNQfiJShLGmIrVMp50Ke89ZPb: wvaNQfiJShLGmIrVMp50Ke89ZPb = wvaNQfiJShLGmIrVMp50Ke89ZPb.replace('"','')
			if '"' in zawKLhDJey6dvZxo: zawKLhDJey6dvZxo = zawKLhDJey6dvZxo.replace('"','')
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/video/'+id
			title = x81xRtwz3YyspILvC(title)
			FRov4fbHu7K = wvaNQfiJShLGmIrVMp50Ke89ZPb+'::'+zawKLhDJey6dvZxo
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,403,pGjsvdyHfM,vNbeHULAy6gc4iE,FRov4fbHu7K)
		if '"hasNextPage":true' in oo9SgGkiDbs3HRn7z8:
			BzbaC0qYjMr2WXwsO = str(int(BzbaC0qYjMr2WXwsO)+1)
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+BzbaC0qYjMr2WXwsO,url,408,'',BzbaC0qYjMr2WXwsO)
	return
def Orcs6oqjbyKeWZwQS870(url,BzbaC0qYjMr2WXwsO=''):
	if BzbaC0qYjMr2WXwsO=='': BzbaC0qYjMr2WXwsO = '1'
	eitKAc89owDhTpUWvmBrxM6RI = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	VemfsE32zgI = '{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  isFollowed\n  accountType\n  __typename\n}\n\nfragment CHANNEL_IMAGES_FRAGMENT on Channel {\n  id\n  coverURLx375: coverURL(size: \"x375\")\n  __typename\n}\n\nfragment CHANNEL_UPDATED_FRAGMENT on Channel {\n  id\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_COMPLETE_FRAGMENT on Channel {\n  id\n  ...CHANNEL_BASE_FRAGMENT\n  ...CHANNEL_IMAGES_FRAGMENT\n  ...CHANNEL_UPDATED_FRAGMENT\n  description\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  externalLinks {\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {\n  channel(xid: $channel_xid) {\n    id\n    ...CHANNEL_COMPLETE_FRAGMENT\n    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          xid\n          updatedAt\n          name\n          description\n          thumbURLx240: thumbnailURL(size: \"x240\")\n          thumbURLx360: thumbnailURL(size: \"x360\")\n          thumbURLx480: thumbnailURL(size: \"x480\")\n          stats {\n            videos {\n              total\n              __typename\n            }\n            __typename\n          }\n          channel {\n            id\n            ...CHANNEL_FRAGMENT\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	VemfsE32zgI = VemfsE32zgI.replace('mychannelid',eitKAc89owDhTpUWvmBrxM6RI)
	VemfsE32zgI = VemfsE32zgI.replace('mypagelimit','40')
	VemfsE32zgI = VemfsE32zgI.replace('mypagenumber',BzbaC0qYjMr2WXwsO)
	VemfsE32zgI = VemfsE32zgI.replace('mysortmethod',sort)
	oo9SgGkiDbs3HRn7z8 = hGN5i12oWLnzIqfc(VemfsE32zgI)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"thumbURLx240":"(.*?)".*?"total":(.*?),.*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for id,name,pGjsvdyHfM,count,bDEvG1tsKWAj2CkQoJ,wvaNQfiJShLGmIrVMp50Ke89ZPb,zawKLhDJey6dvZxo in items:
			if '"' in id: id = id.replace('"','')
			if '"' in name: name = name.replace('"','')
			if '"' in pGjsvdyHfM: pGjsvdyHfM = pGjsvdyHfM.replace('"','')
			if '"' in count: count = count.replace('"','')
			if '"' in bDEvG1tsKWAj2CkQoJ: bDEvG1tsKWAj2CkQoJ = bDEvG1tsKWAj2CkQoJ.replace('"','')
			if '"' in wvaNQfiJShLGmIrVMp50Ke89ZPb: wvaNQfiJShLGmIrVMp50Ke89ZPb = wvaNQfiJShLGmIrVMp50Ke89ZPb.replace('"','')
			if '"' in zawKLhDJey6dvZxo: zawKLhDJey6dvZxo = zawKLhDJey6dvZxo.replace('"','')
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = x81xRtwz3YyspILvC(title)
			FRov4fbHu7K = wvaNQfiJShLGmIrVMp50Ke89ZPb+'::'+zawKLhDJey6dvZxo
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,401,pGjsvdyHfM,'',FRov4fbHu7K)
		if '"hasNextPage":true' in oo9SgGkiDbs3HRn7z8:
			BzbaC0qYjMr2WXwsO = str(int(BzbaC0qYjMr2WXwsO)+1)
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+BzbaC0qYjMr2WXwsO,url,407,'',BzbaC0qYjMr2WXwsO)
	return
def HHE6h2WkpxAZdYL5eVKfOJbyB8jr(url,LNewr2MfEqRT3BPbYIv):
	eitKAc89owDhTpUWvmBrxM6RI = url.split('/')[3]
	VemfsE32zgI = '{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    followers {\n      id\n      total\n      __typename\n    }\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment LIVE_FRAGMENT on Live {\n  id\n  xid\n  title\n  startAt\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  __typename\n}\n\nfragment VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  viewCount\n  duration\n  createdAt\n  isInWatchLater\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment CHANNEL_MAIN_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  description\n  accountType\n  isArtist\n  logoURL(size: \"x60\")\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  isFollowed\n  tagline\n  country {\n    id\n    codeAlpha2\n    __typename\n  }\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    followers {\n      id\n      total\n      __typename\n    }\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  externalLinks {\n    id\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    pinterestURL\n    __typename\n  }\n  channel_lives_now: lives(first: 4, isOnAir: true) {\n    edges {\n      node {\n        id\n        ...LIVE_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_lives_scheduled: lives(first: 4, startIn: 7200) {\n    edges {\n      node {\n        id\n        ...LIVE_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_featured_videos: videos(first: 4, isFeatured: true) {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_all_videos: videos(first: 4) {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_most_viewed: videos(first: 4, sort: \"visited\") {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_collections: collections(first: 4) {\n    edges {\n      node {\n        id\n        xid\n        name\n        description\n        stats {\n          id\n          videos {\n            id\n            total\n            __typename\n          }\n          __typename\n        }\n        thumbnailx240: thumbnailURL(size: \"x240\")\n        thumbnailx360: thumbnailURL(size: \"x360\")\n        thumbnailx480: thumbnailURL(size: \"x480\")\n        channel {\n          id\n          ...CHANNEL_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_related_channel: networkChannels(\n    hasPublicVideos: true\n    first: $relatedChannels\n  ) {\n    edges {\n      node {\n        id\n        ...CHANNEL_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {\n  channel(name: $channel_name) {\n    id\n    ...CHANNEL_MAIN_FRAGMENT\n    __typename\n  }\n}\n"}'
	VemfsE32zgI = VemfsE32zgI.replace('mychannelid',eitKAc89owDhTpUWvmBrxM6RI)
	oo9SgGkiDbs3HRn7z8 = hGN5i12oWLnzIqfc(VemfsE32zgI)
	import json as Kq1vtcn0VUo4CaebZuWYHpPJ7l
	ImTYAQdhkxi1lrXL4aVwHn8WDMN = Kq1vtcn0VUo4CaebZuWYHpPJ7l.loads(oo9SgGkiDbs3HRn7z8)
	try: items = ImTYAQdhkxi1lrXL4aVwHn8WDMN['data']['channel'][LNewr2MfEqRT3BPbYIv]['edges']
	except: items = []
	if not items: uQNUfbZx9yj0F('link',tiCRYyX1bWd40Ir3PafQu+'لا توجد نتائج','',9999)
	else:
		for TMaJdc0xOFKNf in items:
			wHWq2AgmniBsZf = TMaJdc0xOFKNf['node']
			kXgmjIq7TM8 = wHWq2AgmniBsZf['xid']
			keys = list(wHWq2AgmniBsZf.keys())
			s5sidVOSZ6KIDCjqlaJ7Mc = wHWq2AgmniBsZf['__typename'].lower()
			if s5sidVOSZ6KIDCjqlaJ7Mc=='channel':
				name = wHWq2AgmniBsZf['name']
				INUEPh1ZM65aXr38zDywQWJLBf24pG = wHWq2AgmniBsZf['displayName']
				title = 'CHNL:  '+INUEPh1ZM65aXr38zDywQWJLBf24pG
				pGjsvdyHfM = wHWq2AgmniBsZf['coverURLx375']
			else:
				name = wHWq2AgmniBsZf['channel']['name']
				INUEPh1ZM65aXr38zDywQWJLBf24pG = wHWq2AgmniBsZf['channel']['displayName']
				title = wHWq2AgmniBsZf['title']
				pGjsvdyHfM = wHWq2AgmniBsZf['thumbnailx360']
				if s5sidVOSZ6KIDCjqlaJ7Mc=='live': title = 'LIVE:  '+title
			title = x81xRtwz3YyspILvC(title)
			FRov4fbHu7K = name+'::'+INUEPh1ZM65aXr38zDywQWJLBf24pG
			if bdptXFc8UlIhA5jnGwPmKuv2L:
				title = title.encode('utf8')
				FRov4fbHu7K = FRov4fbHu7K.encode('utf8')
			if s5sidVOSZ6KIDCjqlaJ7Mc=='channel':
				ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/'+kXgmjIq7TM8
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,402,pGjsvdyHfM,'',FRov4fbHu7K)
			else:
				if s5sidVOSZ6KIDCjqlaJ7Mc=='video': vNbeHULAy6gc4iE = str(wHWq2AgmniBsZf['duration'])
				else: vNbeHULAy6gc4iE = ''
				ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/video/'+kXgmjIq7TM8
				uQNUfbZx9yj0F(s5sidVOSZ6KIDCjqlaJ7Mc,tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,403,pGjsvdyHfM,vNbeHULAy6gc4iE,FRov4fbHu7K)
	return
def hGN5i12oWLnzIqfc(VemfsE32zgI):
	VemfsE32zgI = VemfsE32zgI.replace(' \"',' \\"')
	VemfsE32zgI = VemfsE32zgI.replace('\", ','\\", ')
	VemfsE32zgI = VemfsE32zgI.replace('\n','\\n')
	VemfsE32zgI = VemfsE32zgI.replace('")','\\")')
	y7P1E4TR6fOYoacFk = OOeELKW5gcTC()
	headers = {"Authorization":y7P1E4TR6fOYoacFk,"Origin":yONJxHER9BIDPpTV4YsWmc0n}
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'POST',nIo981YOgF2lx7JNevV4b0K6shuzA,VemfsE32zgI,headers,'','','DAILYMOTION-GET_PAGEDATA-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	return oo9SgGkiDbs3HRn7z8
def OOeELKW5gcTC():
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',yONJxHER9BIDPpTV4YsWmc0n,'','','','','DAILYMOTION-GET_AUTHINTICATION-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	kBGdVRCh084L3s = u5h2Rckvw1E.findall('var r="(.*?)",o="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	FOJtiPWIVRCf1xh,hhdewScO97gK3 = kBGdVRCh084L3s[-1]
	LjkvzC95pRV0g7ScKbt = 'https://graphql.api.dailymotion.com/oauth/token'
	ax7K8qRHsl5j9ETG = 'client_credentials'
	data = {'client_id':FOJtiPWIVRCf1xh,'client_secret':hhdewScO97gK3,'grant_type':ax7K8qRHsl5j9ETG}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'POST',LjkvzC95pRV0g7ScKbt,data,headers,'','','DAILYMOTION-GET_AUTHINTICATION-2nd')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	kBGdVRCh084L3s = u5h2Rckvw1E.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	ssK7fDGJqhyQ65jvbgUu,fflPaZIHWupMD6BntwVKNYLQy3x1 = kBGdVRCh084L3s[0]
	y7P1E4TR6fOYoacFk = fflPaZIHWupMD6BntwVKNYLQy3x1+" "+ssK7fDGJqhyQ65jvbgUu
	return y7P1E4TR6fOYoacFk
def bB8m3r5asjpdG0ulEJg(search,type=''):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if not type and showDialogs:
		IWBEjPlFuQYs2giA8q6NOy0mMhXUT = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن قنوات','بحث عن مواضيع','بحث عن بث حي']
		u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = tYysxJLreEBDdXMIjz4OPa('موقع ديلي موشن - اختر البحث',IWBEjPlFuQYs2giA8q6NOy0mMhXUT)
		if u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo==-1: return
		elif u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo==0: type = 'videos?sortBy='
		elif u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo==1: type = 'videos?sortBy=RECENT'
		elif u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo==2: type = 'videos?sortBy=VIEW_COUNT'
		elif u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo==3: type = 'playlists'
		elif u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo==4: type = 'channels'
		elif u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo==5: type = 'topics'
		elif u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo==6: type = 'lives'
	elif '_DAILYMOTION-VIDEOS_' in dza2VO9NvX: type = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in dza2VO9NvX: type = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in dza2VO9NvX: type = 'channels'
	elif '_DAILYMOTION-TOPICS_' in dza2VO9NvX: type = 'topics'
	elif '_DAILYMOTION-LIVES_' in dza2VO9NvX: type = 'lives'
	if not search:
		search = FBrXsYeCEp3()
		if not search: return
	if VVGRN7xiyj: search = search.encode('utf8').decode('raw_unicode_escape')
	if 'videos' in type: eNYdwGrCvjKLi219snyHchfFo(search+'/'+type)
	elif 'playlists' in type: BPr8StvTIigjRHf3U(search)
	elif 'channels' in type: rPDtdioMLEvA7VcZe3by1xfJS(search)
	elif 'topics' in type: lluFay1zsMUPZIShjN7tokQm(search)
	elif 'lives' in type: UtRoJx0hVYBAsNGpbDdjWiwf(search)
	return
# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'BOKRA'
tiCRYyX1bWd40Ir3PafQu = '_BKR_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
headers = {'User-Agent':''}
WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['افلام للكبار','بكرا TV']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==370: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==371: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,text)
	elif mode==372: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==374: vS7JufTVsBxw52 = VU6egCJNBEjpIDcmdlx(url)
	elif mode==375: vS7JufTVsBxw52 = K37aCG2WnNiBfEt6emzcy9I5xjhS(url)
	elif mode==376: vS7JufTVsBxw52 = uN6Ibnkxacfi5Y3XJ(0,url)
	elif mode==377: vS7JufTVsBxw52 = uN6Ibnkxacfi5Y3XJ(1,url)
	elif mode==379: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',yONJxHER9BIDPpTV4YsWmc0n,'','','','','BOKRA-MENU-1st')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',379,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('right-side(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
			if not any(c2eEflztvIX in title for c2eEflztvIX in WLI5tgXRbUPNGJCSVz0vKjBDei3):
				uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,371)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'المميزة',yONJxHER9BIDPpTV4YsWmc0n,375)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'الأحدث',yONJxHER9BIDPpTV4YsWmc0n,376)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'قائمة الممثلين',yONJxHER9BIDPpTV4YsWmc0n,374)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="container"(.*?)top-menu',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items[7:]:
			title = title.strip(' ')
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
			if not any(c2eEflztvIX in title for c2eEflztvIX in WLI5tgXRbUPNGJCSVz0vKjBDei3):
				uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,371)
		for ekTrZlFMu0Kf5QztEnhAs,title in items[0:7]:
			title = title.strip(' ')
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
			if not any(c2eEflztvIX in title for c2eEflztvIX in WLI5tgXRbUPNGJCSVz0vKjBDei3):
				uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,371)
	return
def VU6egCJNBEjpIDcmdlx(website=''):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',yONJxHER9BIDPpTV4YsWmc0n,'','','','','BOKRA-ACTORSMENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="row cat Tags"(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)" title="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if 'http' in ekTrZlFMu0Kf5QztEnhAs: continue
			else: ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
			if not any(c2eEflztvIX in title for c2eEflztvIX in WLI5tgXRbUPNGJCSVz0vKjBDei3):
				uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,371)
	return
def K37aCG2WnNiBfEt6emzcy9I5xjhS(website=''):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',yONJxHER9BIDPpTV4YsWmc0n,'','','','','BOKRA-FEATURED-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"MainContent"(.*?)main-title2',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
			if not any(c2eEflztvIX in title for c2eEflztvIX in WLI5tgXRbUPNGJCSVz0vKjBDei3):
				pGjsvdyHfM = pGjsvdyHfM.replace('://',':///').replace('//','/').replace(' ','%20')
				uQNUfbZx9yj0F('video',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,372,pGjsvdyHfM)
	return
def uN6Ibnkxacfi5Y3XJ(id,website=''):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',yONJxHER9BIDPpTV4YsWmc0n,'','','','','BOKRA-WATCHINGNOW-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('main-title2(.*?)class="row',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[id]
		items = u5h2Rckvw1E.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
			if not any(c2eEflztvIX in title for c2eEflztvIX in WLI5tgXRbUPNGJCSVz0vKjBDei3):
				pGjsvdyHfM = pGjsvdyHfM.replace('://',':///').replace('//','/').replace(' ','%20')
				uQNUfbZx9yj0F('video',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,372,pGjsvdyHfM)
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,v94eWpjgbPaZKECiA7J=''):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','BOKRA-TITLES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	if 'vidpage_' in url:
		ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('href="(/Album-.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if ekTrZlFMu0Kf5QztEnhAs:
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs[0]
			ll0a2AwztChcpsDUMi4rGW3b61XZES(ekTrZlFMu0Kf5QztEnhAs)
			return
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class=" subcats"(.*?)class="col-md-3',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if v94eWpjgbPaZKECiA7J=='' and cWafzb4HoG1Em3Jwxu6C7vZsVi and cWafzb4HoG1Em3Jwxu6C7vZsVi[0].count('href')>1:
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع',url,371,'','','titles')
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)" title="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/'+ekTrZlFMu0Kf5QztEnhAs
			title = title.strip(' ')
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,371)
	else:
		yn8DkpE5etF3WiUmfSO = []
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="col-md-3(.*?)col-xs-12',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if not cWafzb4HoG1Em3Jwxu6C7vZsVi: cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="col-sm-8"(.*?)col-xs-12',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
				ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
				title = title.strip(' ')
				pGjsvdyHfM = pGjsvdyHfM.replace('://',':///').replace('//','/').replace(' ','%20')
				if '/al_' in ekTrZlFMu0Kf5QztEnhAs:
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,371,pGjsvdyHfM)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					zAjwuoRY98mXN6xvE = u5h2Rckvw1E.findall('(.*?) - +الحلقة +\d+',title,u5h2Rckvw1E.DOTALL)
					if zAjwuoRY98mXN6xvE: title = '_MOD_مسلسل '+zAjwuoRY98mXN6xvE[0]
					if title not in yn8DkpE5etF3WiUmfSO:
						yn8DkpE5etF3WiUmfSO.append(title)
						uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,371,pGjsvdyHfM)
				else: uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,372,pGjsvdyHfM)
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="pagination(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('class="".*?href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,title in items:
				ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
				title = 'صفحة '+uTUNPkVwCMKiD5gHLaj(title)
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,371,'','','titles')
	return
def N5AOlmb8u1y4FHxvJXU(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',url,'','','','','BOKRA-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	PmF0XjQN51GpKACfLgnyTv7 = u5h2Rckvw1E.findall('label-success mrg-btm-5 ">(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if PmF0XjQN51GpKACfLgnyTv7 and dQorkS3qBhIMDWKHl(aUVSgO2ebjwX5iqPykC,url,PmF0XjQN51GpKACfLgnyTv7): return
	UcmHDPlLWaSf = ''
	gANn35esloKUydOipfSMC6RD2 = u5h2Rckvw1E.findall('var url = "(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if gANn35esloKUydOipfSMC6RD2: gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2[0]
	else: gANn35esloKUydOipfSMC6RD2 = url.replace('/vidpage_','/Play/')
	if 'http' not in gANn35esloKUydOipfSMC6RD2: gANn35esloKUydOipfSMC6RD2 = yONJxHER9BIDPpTV4YsWmc0n+gANn35esloKUydOipfSMC6RD2
	gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2.strip('-')
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',gANn35esloKUydOipfSMC6RD2,'','','','','BOKRA-PLAY-2nd')
	ZCOosjaQ8x9HDKSVGM6LwW2vy = RoQL91PphqCJg4W0e6Fnsl.content
	UcmHDPlLWaSf = u5h2Rckvw1E.findall('src="(.*?)"',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)
	if UcmHDPlLWaSf:
		UcmHDPlLWaSf = UcmHDPlLWaSf[-1]
		if 'http' not in UcmHDPlLWaSf: UcmHDPlLWaSf = 'http:'+UcmHDPlLWaSf
		if '/PLAY/' not in gANn35esloKUydOipfSMC6RD2:
			if 'embed.min.js' in UcmHDPlLWaSf:
				QEZShimrXtc = u5h2Rckvw1E.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)
				if QEZShimrXtc:
					m0aVQviJbDKc3xF9Xgpe, EjkXNH20wpPV7KI = QEZShimrXtc[0]
					UcmHDPlLWaSf = hmcFWJUgiAuGk(UcmHDPlLWaSf,'url')+'/v2/'+m0aVQviJbDKc3xF9Xgpe+'/config/'+EjkXNH20wpPV7KI+'.json'
		import jSLK8GCOcy
		jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr([UcmHDPlLWaSf],aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	search = search.replace(' ','+')
	url = yONJxHER9BIDPpTV4YsWmc0n+'/Search/'+search
	ll0a2AwztChcpsDUMi4rGW3b61XZES(url)
	return
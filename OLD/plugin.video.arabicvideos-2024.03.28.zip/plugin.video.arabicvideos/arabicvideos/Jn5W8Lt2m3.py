# -*- coding: utf-8 -*-
from LXgKztbkOf import *
headers = { 'User-Agent' : '' }
aUVSgO2ebjwX5iqPykC = 'AKWAM'
tiCRYyX1bWd40Ir3PafQu = '_AKW_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
G6NYJZnFW0e = ''
WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==240: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==241: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,text)
	elif mode==242: vS7JufTVsBxw52 = GA2KIlbOsoYtxpkDF71(url)
	elif mode==243: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==244: vS7JufTVsBxw52 = WYxFZIrRp6b(url,'FILTERS___'+text)
	elif mode==245: vS7JufTVsBxw52 = WYxFZIrRp6b(url,'CATEGORIES___'+text)
	elif mode==246: vS7JufTVsBxw52 = KWCsyjAr073LzMqDaJ2UeB(url)
	elif mode==247: vS7JufTVsBxw52 = ea5qUyg04wIMVZdPCkfJbviFOH1(url)
	elif mode==248: vS7JufTVsBxw52 = OInG8CqlDf6H7Ye()
	elif mode==249: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def OInG8CqlDf6H7Ye():
	xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def LitkEX0THgZadBAYn3hUIRoFC():
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',yONJxHER9BIDPpTV4YsWmc0n,'',headers,'','','AKWAM-MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	vP8lwF3zAiBZXCgtkRo4LOWhbEs65 = u5h2Rckvw1E.findall('home-site-btn-container.*?href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if vP8lwF3zAiBZXCgtkRo4LOWhbEs65: vP8lwF3zAiBZXCgtkRo4LOWhbEs65 = vP8lwF3zAiBZXCgtkRo4LOWhbEs65[0]
	else: vP8lwF3zAiBZXCgtkRo4LOWhbEs65 = yONJxHER9BIDPpTV4YsWmc0n
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',vP8lwF3zAiBZXCgtkRo4LOWhbEs65,'',headers,'','','AKWAM-MENU-2nd')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',249,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فلتر محدد',yONJxHER9BIDPpTV4YsWmc0n,246)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فلتر كامل',yONJxHER9BIDPpTV4YsWmc0n,247)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'المميزة',vP8lwF3zAiBZXCgtkRo4LOWhbEs65,241,'','','featured')
	recent = u5h2Rckvw1E.findall('recently-container.*?href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	ekTrZlFMu0Kf5QztEnhAs = recent[0]
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'أضيف حديثا',ekTrZlFMu0Kf5QztEnhAs,241)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,name,lmO2YJGr6tCV in cWafzb4HoG1Em3Jwxu6C7vZsVi:
		if name in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
		uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+name,ekTrZlFMu0Kf5QztEnhAs,241)
		items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if title in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
			title = name+' '+title
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,241)
	return
def KWCsyjAr073LzMqDaJ2UeB(website=''):
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,yONJxHER9BIDPpTV4YsWmc0n,'',headers,'','AKWAM-MENU-1st')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="menu(.*?)<nav',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?text">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if title not in WLI5tgXRbUPNGJCSVz0vKjBDei3:
				title = title+' مصنفة'
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,245)
		if website=='': uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return oo9SgGkiDbs3HRn7z8
def ea5qUyg04wIMVZdPCkfJbviFOH1(website=''):
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,yONJxHER9BIDPpTV4YsWmc0n,'',headers,'','AKWAM-MENU-1st')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="menu(.*?)<nav',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?text">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if title not in WLI5tgXRbUPNGJCSVz0vKjBDei3:
				title = title+' مفلترة'
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,244)
		if website=='': uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return oo9SgGkiDbs3HRn7z8
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,type=''):
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,url,'',headers,True,'AKWAM-TITLES-1st')
	if type=='featured': cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('swiper-container(.*?)swiper-button-prev',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	else: cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="widget"(.*?)main-footer',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if not items:
			items = u5h2Rckvw1E.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for pGjsvdyHfM,ekTrZlFMu0Kf5QztEnhAs,title in items:
			if '/series/' in ekTrZlFMu0Kf5QztEnhAs or '/shows/' in ekTrZlFMu0Kf5QztEnhAs:
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,242,pGjsvdyHfM)
			elif '/movies/' in ekTrZlFMu0Kf5QztEnhAs:
				uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,243,pGjsvdyHfM)
			elif '/games/' not in ekTrZlFMu0Kf5QztEnhAs:
				uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,243,pGjsvdyHfM)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('pagination(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			ekTrZlFMu0Kf5QztEnhAs = uTUNPkVwCMKiD5gHLaj(ekTrZlFMu0Kf5QztEnhAs)
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+title,ekTrZlFMu0Kf5QztEnhAs,241)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	GHFUMEOSrvhmIoVWxwN8j4 = search.replace(' ','%20')
	url = yONJxHER9BIDPpTV4YsWmc0n + '/search?q='+GHFUMEOSrvhmIoVWxwN8j4
	vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url)
	return
def GA2KIlbOsoYtxpkDF71(url):
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,url,'',headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in oo9SgGkiDbs3HRn7z8:
		pGjsvdyHfM = bMIascyFJ2x43E0C7glTB91h8qz.getInfoLabel('ListItem.Icon')
		uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+'رابط التشغيل',url,243,pGjsvdyHfM)
	else:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('-episodes">(.*?)<div class="widget-4',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		Ez1AbVgerRU0YimHu45t9DI7qM = u5h2Rckvw1E.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title,pGjsvdyHfM in Ez1AbVgerRU0YimHu45t9DI7qM:
			title = title.replace('  ',' ')
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,242,pGjsvdyHfM)
			else: uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,243,pGjsvdyHfM)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,url,'',headers,True,'AKWAM-PLAY-1st')
	PmF0XjQN51GpKACfLgnyTv7 = u5h2Rckvw1E.findall('badge-danger.*?>(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if PmF0XjQN51GpKACfLgnyTv7 and dQorkS3qBhIMDWKHl(aUVSgO2ebjwX5iqPykC,url,PmF0XjQN51GpKACfLgnyTv7): return
	kTGfqid1whF2sxBKy7X3YmE45g = u5h2Rckvw1E.findall('li><a href="#(.*?)".*?>(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	EaBeVhOsHYg8wub,hVby8e3aQkFfuE,ppZ9muD1GkPnFRX52jxBUIy,mAxtBGFlLX2UzJ5sjc = [],[],[],[]
	if kTGfqid1whF2sxBKy7X3YmE45g:
		GvoaR8HMyTDxF0fz5cwu1JnSNWP = 'mp4'
		for FDCNhjGdpW1Loa2JOlrb0vS,ohAHUqdbWFi8D1L4Xwzus0f3RYv in kTGfqid1whF2sxBKy7X3YmE45g:
			cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('tab-content quality" id="'+FDCNhjGdpW1Loa2JOlrb0vS+'".*?</div>.\s*</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			ppZ9muD1GkPnFRX52jxBUIy.append(lmO2YJGr6tCV)
			mAxtBGFlLX2UzJ5sjc.append(ohAHUqdbWFi8D1L4Xwzus0f3RYv)
	else:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="qualities(.*?)<h3.*?>(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if not cWafzb4HoG1Em3Jwxu6C7vZsVi:
			xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			lmO2YJGr6tCV,filename = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			J6cUpuMRDSr = ['zip','rar','txt','pdf','htm','tar','iso','html']
			GvoaR8HMyTDxF0fz5cwu1JnSNWP = filename.rsplit('.',1)[1].strip(' ')
			if GvoaR8HMyTDxF0fz5cwu1JnSNWP in J6cUpuMRDSr:
				xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','الملف ليس فيديو ولا صوت')
				return
		ppZ9muD1GkPnFRX52jxBUIy.append(lmO2YJGr6tCV)
		mAxtBGFlLX2UzJ5sjc.append('')
	for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(len(ppZ9muD1GkPnFRX52jxBUIy)):
		lQUf3AY258LeWch = u5h2Rckvw1E.findall('href="(.*?)".*?icon-(.*?)"',ppZ9muD1GkPnFRX52jxBUIy[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE],u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,Aq1VhBP9nsvciIFfxk6wH7RzQW8Y in lQUf3AY258LeWch:
			if 'torrent' in Aq1VhBP9nsvciIFfxk6wH7RzQW8Y: continue
			elif 'download' in Aq1VhBP9nsvciIFfxk6wH7RzQW8Y: type = 'download'
			elif 'play' in Aq1VhBP9nsvciIFfxk6wH7RzQW8Y: type = 'watch'
			else: type = 'unknown'
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named=__'+type+'____'+mAxtBGFlLX2UzJ5sjc[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE]+'__akwam'
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(EaBeVhOsHYg8wub,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def WYxFZIrRp6b(url,filter):
	BVNnjYeCa3AfgTv0u6R = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter=='': lvUP2GeNjyVOHKJxcBoun3Z,MoELTBDgQeaJrl0zYUmKCH = '',''
	else: lvUP2GeNjyVOHKJxcBoun3Z,MoELTBDgQeaJrl0zYUmKCH = filter.split('___')
	if type=='CATEGORIES':
		if BVNnjYeCa3AfgTv0u6R[0]+'=' not in lvUP2GeNjyVOHKJxcBoun3Z: oPrhaMp7AqmNnRjlXGI = BVNnjYeCa3AfgTv0u6R[0]
		for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(len(BVNnjYeCa3AfgTv0u6R[0:-1])):
			if BVNnjYeCa3AfgTv0u6R[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE]+'=' in lvUP2GeNjyVOHKJxcBoun3Z: oPrhaMp7AqmNnRjlXGI = BVNnjYeCa3AfgTv0u6R[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE+1]
		WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&'+oPrhaMp7AqmNnRjlXGI+'=0'
		z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&'+oPrhaMp7AqmNnRjlXGI+'=0'
		bIYSyA3BD1o4 = WGiMcqkRetEJVrSI.strip('&')+'___'+z3wGSEWqVy1Qh5N.strip('&')
		TBFfiRI52ZmKwO1JLSD = mltWBSPJz5H4VRdCAa1(MoELTBDgQeaJrl0zYUmKCH,'all')
		gANn35esloKUydOipfSMC6RD2 = url+'?'+TBFfiRI52ZmKwO1JLSD
	elif type=='FILTERS':
		lv2uANOtVxE8RTa7bYHqLog1Bd = mltWBSPJz5H4VRdCAa1(lvUP2GeNjyVOHKJxcBoun3Z,'modified_values')
		lv2uANOtVxE8RTa7bYHqLog1Bd = P2o6ZDHeW790pSQqucvnxzILVUX(lv2uANOtVxE8RTa7bYHqLog1Bd)
		if MoELTBDgQeaJrl0zYUmKCH!='': MoELTBDgQeaJrl0zYUmKCH = mltWBSPJz5H4VRdCAa1(MoELTBDgQeaJrl0zYUmKCH,'all')
		if MoELTBDgQeaJrl0zYUmKCH=='': gANn35esloKUydOipfSMC6RD2 = url
		else: gANn35esloKUydOipfSMC6RD2 = url+'?'+MoELTBDgQeaJrl0zYUmKCH
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'أظهار قائمة الفيديو التي تم اختيارها',gANn35esloKUydOipfSMC6RD2,241,'','1')
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+' [[   '+lv2uANOtVxE8RTa7bYHqLog1Bd+'   ]]',gANn35esloKUydOipfSMC6RD2,241,'','1')
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,url,'',headers,True,'AKWAM-FILTERS_MENU-1st')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('<form id(.*?)</form>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	cGdHRiwvptVXQlzE8ZUgB0aJo9x = u5h2Rckvw1E.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	dict = {}
	for Uiy0XwPusDg4vAFc35oYdfGnOrV,name,lmO2YJGr6tCV in cGdHRiwvptVXQlzE8ZUgB0aJo9x:
		items = u5h2Rckvw1E.findall('<option(.*?)>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if '=' not in gANn35esloKUydOipfSMC6RD2: gANn35esloKUydOipfSMC6RD2 = url
		if type=='CATEGORIES':
			if oPrhaMp7AqmNnRjlXGI!=Uiy0XwPusDg4vAFc35oYdfGnOrV: continue
			elif len(items)<=1:
				if Uiy0XwPusDg4vAFc35oYdfGnOrV==BVNnjYeCa3AfgTv0u6R[-1]: ll0a2AwztChcpsDUMi4rGW3b61XZES(gANn35esloKUydOipfSMC6RD2)
				else: WYxFZIrRp6b(gANn35esloKUydOipfSMC6RD2,'CATEGORIES___'+bIYSyA3BD1o4)
				return
			else:
				if Uiy0XwPusDg4vAFc35oYdfGnOrV==BVNnjYeCa3AfgTv0u6R[-1]: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع',gANn35esloKUydOipfSMC6RD2,241,'','1')
				else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع',gANn35esloKUydOipfSMC6RD2,245,'','',bIYSyA3BD1o4)
		elif type=='FILTERS':
			WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'=0'
			z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'=0'
			bIYSyA3BD1o4 = WGiMcqkRetEJVrSI+'___'+z3wGSEWqVy1Qh5N
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع : '+name,gANn35esloKUydOipfSMC6RD2,244,'','',bIYSyA3BD1o4)
		dict[Uiy0XwPusDg4vAFc35oYdfGnOrV] = {}
		for c2eEflztvIX,q1rVywkMcKftIioS43LY in items:
			if q1rVywkMcKftIioS43LY in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
			if 'value' not in c2eEflztvIX: c2eEflztvIX = q1rVywkMcKftIioS43LY
			else: c2eEflztvIX = u5h2Rckvw1E.findall('"(.*?)"',c2eEflztvIX,u5h2Rckvw1E.DOTALL)[0]
			dict[Uiy0XwPusDg4vAFc35oYdfGnOrV][c2eEflztvIX] = q1rVywkMcKftIioS43LY
			WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'='+q1rVywkMcKftIioS43LY
			z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'='+c2eEflztvIX
			eoaO40TC7VF1tEuwjQp2x = WGiMcqkRetEJVrSI+'___'+z3wGSEWqVy1Qh5N
			title = q1rVywkMcKftIioS43LY+' : '#+dict[Uiy0XwPusDg4vAFc35oYdfGnOrV]['0']
			title = q1rVywkMcKftIioS43LY+' : '+name
			if type=='FILTERS': uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,244,'','',eoaO40TC7VF1tEuwjQp2x)
			elif type=='CATEGORIES' and BVNnjYeCa3AfgTv0u6R[-2]+'=' in lvUP2GeNjyVOHKJxcBoun3Z:
				TBFfiRI52ZmKwO1JLSD = mltWBSPJz5H4VRdCAa1(z3wGSEWqVy1Qh5N,'all')
				UcmHDPlLWaSf = url+'?'+TBFfiRI52ZmKwO1JLSD
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,UcmHDPlLWaSf,241,'','1')
			else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,245,'','',eoaO40TC7VF1tEuwjQp2x)
	return
def mltWBSPJz5H4VRdCAa1(cGYIMSHDj85d3f4ZW2t0bnNkKP,mode):
	cGYIMSHDj85d3f4ZW2t0bnNkKP = cGYIMSHDj85d3f4ZW2t0bnNkKP.strip('&')
	OXjBliFSwIQCmg47 = {}
	if '=' in cGYIMSHDj85d3f4ZW2t0bnNkKP:
		items = cGYIMSHDj85d3f4ZW2t0bnNkKP.split('&')
		for TMaJdc0xOFKNf in items:
			b1EWu6sYaRk0FXUx8HVvNBQort43,c2eEflztvIX = TMaJdc0xOFKNf.split('=')
			OXjBliFSwIQCmg47[b1EWu6sYaRk0FXUx8HVvNBQort43] = c2eEflztvIX
	LL3oamJbwkYcNDrH5 = ''
	mwqMBcOe2Lj = ['section','category','rating','year','language','formats','quality']
	for key in mwqMBcOe2Lj:
		if key in list(OXjBliFSwIQCmg47.keys()): c2eEflztvIX = OXjBliFSwIQCmg47[key]
		else: c2eEflztvIX = '0'
		if mode=='modified_values' and c2eEflztvIX!='0': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+' + '+c2eEflztvIX
		elif mode=='modified_filters' and c2eEflztvIX!='0': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+'&'+key+'='+c2eEflztvIX
		elif mode=='all': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+'&'+key+'='+c2eEflztvIX
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.strip(' + ')
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.strip('&')
	return LL3oamJbwkYcNDrH5
# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'SERIES4WATCH'
headers = { 'User-Agent' : '' }
tiCRYyX1bWd40Ir3PafQu = '_SFW_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==210: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==211: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url)
	elif mode==212: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==213: vS7JufTVsBxw52 = GA2KIlbOsoYtxpkDF71(url)
	elif mode==214: vS7JufTVsBxw52 = qVzgjvMALDKCwBH1JQr6ocSsi9ly(url)
	elif mode==215: vS7JufTVsBxw52 = f480fCXKWUjLmH(url)
	elif mode==218: vS7JufTVsBxw52 = D4DIs0jXMti8lkcKVTLpb7GoZSB()
	elif mode==219: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def D4DIs0jXMti8lkcKVTLpb7GoZSB():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','الموقع تغير بالكامل',message)
	return
def LitkEX0THgZadBAYn3hUIRoFC():
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',219,'','','_REMEMBERRESULTS_')
	url = yONJxHER9BIDPpTV4YsWmc0n+'/getpostsPin?type=one&data=pin&limit=25'
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'المميزة',url,211)
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,yONJxHER9BIDPpTV4YsWmc0n,'',headers,'','SERIES4WATCH-MENU-1st')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('FiltersButtons(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('data-get="(.*?)".*?</i>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		url = yONJxHER9BIDPpTV4YsWmc0n+'/getposts?type=one&data='+ekTrZlFMu0Kf5QztEnhAs
		uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,url,211)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('navigation-menu(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('href="(http.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['مسلسلات انمي','الرئيسية']
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		title = title.strip(' ')
		if not any(c2eEflztvIX in title for c2eEflztvIX in WLI5tgXRbUPNGJCSVz0vKjBDei3):
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,211)
	return oo9SgGkiDbs3HRn7z8
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url):
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,url,'',headers,'','SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: lmO2YJGr6tCV = oo9SgGkiDbs3HRn7z8
	else:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('MediaGrid"(.*?)class="pagination"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi: lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		else: return
	items = u5h2Rckvw1E.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	yn8DkpE5etF3WiUmfSO = []
	A1Ap6NmJ7oIqV05uEdhcHLQwsDtYF = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for pGjsvdyHfM,ekTrZlFMu0Kf5QztEnhAs,title in items:
		if '/series/' in ekTrZlFMu0Kf5QztEnhAs: continue
		ekTrZlFMu0Kf5QztEnhAs = P2o6ZDHeW790pSQqucvnxzILVUX(ekTrZlFMu0Kf5QztEnhAs).strip('/')
		title = uTUNPkVwCMKiD5gHLaj(title)
		title = title.strip(' ')
		if '/film/' in ekTrZlFMu0Kf5QztEnhAs or any(c2eEflztvIX in title for c2eEflztvIX in A1Ap6NmJ7oIqV05uEdhcHLQwsDtYF):
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,212,pGjsvdyHfM)
		elif '/episode/' in ekTrZlFMu0Kf5QztEnhAs and 'الحلقة' in title:
			zAjwuoRY98mXN6xvE = u5h2Rckvw1E.findall('(.*?) الحلقة \d+',title,u5h2Rckvw1E.DOTALL)
			if zAjwuoRY98mXN6xvE:
				title = '_MOD_' + zAjwuoRY98mXN6xvE[0]
				if title not in yn8DkpE5etF3WiUmfSO:
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,213,pGjsvdyHfM)
					yn8DkpE5etF3WiUmfSO.append(title)
		else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,213,pGjsvdyHfM)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="pagination(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			ekTrZlFMu0Kf5QztEnhAs = uTUNPkVwCMKiD5gHLaj(ekTrZlFMu0Kf5QztEnhAs)
			title = uTUNPkVwCMKiD5gHLaj(title)
			title = title.replace('الصفحة ','')
			if title!='': uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+title,ekTrZlFMu0Kf5QztEnhAs,211)
	return
def GA2KIlbOsoYtxpkDF71(url):
	Ige6apyuM8WvzqO,items,UqAvrMlX2btuFSYIs7O3WohDR = -1,[],[]
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,url,'',headers,'','SERIES4WATCH-EPISODES-1st')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('ti-list-numbered(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		ppZ9muD1GkPnFRX52jxBUIy = ''.join(cWafzb4HoG1Em3Jwxu6C7vZsVi)
		items = u5h2Rckvw1E.findall('href="(.*?)"',ppZ9muD1GkPnFRX52jxBUIy,u5h2Rckvw1E.DOTALL)
	items.append(url)
	items = set(items)
	for ekTrZlFMu0Kf5QztEnhAs in items:
		ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.strip('/')
		title = '_MOD_' + ekTrZlFMu0Kf5QztEnhAs.split('/')[-1].replace('-',' ')
		FFkUYlfHsK2W5VzbAZjMvmCSE43 = u5h2Rckvw1E.findall('الحلقة-(\d+)',ekTrZlFMu0Kf5QztEnhAs.split('/')[-1],u5h2Rckvw1E.DOTALL)
		if FFkUYlfHsK2W5VzbAZjMvmCSE43: FFkUYlfHsK2W5VzbAZjMvmCSE43 = FFkUYlfHsK2W5VzbAZjMvmCSE43[0]
		else: FFkUYlfHsK2W5VzbAZjMvmCSE43 = '0'
		UqAvrMlX2btuFSYIs7O3WohDR.append([ekTrZlFMu0Kf5QztEnhAs,title,FFkUYlfHsK2W5VzbAZjMvmCSE43])
	items = sorted(UqAvrMlX2btuFSYIs7O3WohDR, reverse=False, key=lambda key: int(key[2]))
	bb3PyVzA2RUtBGYxo9iMQ = str(items).count('/season/')
	Ige6apyuM8WvzqO = str(items).count('/episode/')
	if bb3PyVzA2RUtBGYxo9iMQ>1 and Ige6apyuM8WvzqO>0 and '/season/' not in url:
		for ekTrZlFMu0Kf5QztEnhAs,title,FFkUYlfHsK2W5VzbAZjMvmCSE43 in items:
			if '/season/' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,213)
	else:
		for ekTrZlFMu0Kf5QztEnhAs,title,FFkUYlfHsK2W5VzbAZjMvmCSE43 in items:
			if '/season/' not in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,212)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	EaBeVhOsHYg8wub = []
	KKSjuTY20EibkGc413C = url.split('/')
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,url,'',headers,'','SERIES4WATCH-PLAY-1st')
	if '/watch/' in oo9SgGkiDbs3HRn7z8:
		gANn35esloKUydOipfSMC6RD2 = url.replace(KKSjuTY20EibkGc413C[3],'watch')
		ZCOosjaQ8x9HDKSVGM6LwW2vy = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,gANn35esloKUydOipfSMC6RD2,'',headers,'','SERIES4WATCH-PLAY-2nd')
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="servers-list(.*?)</div>',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			if items:
				id = u5h2Rckvw1E.findall('post_id=(.*?)"',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)
				if id:
					eitKAc89owDhTpUWvmBrxM6RI = id[0]
					for ekTrZlFMu0Kf5QztEnhAs,title in items:
						ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/?postid='+eitKAc89owDhTpUWvmBrxM6RI+'&serverid='+ekTrZlFMu0Kf5QztEnhAs+'?named='+title+'__watch'
						EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
			else:
				items = u5h2Rckvw1E.findall('data-embedd=".*?(http.*?)("|&quot;)',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
				for ekTrZlFMu0Kf5QztEnhAs,qBdHbiaM0lmk5GNsfrXCIYyugR in items:
					EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	if '/download/' in oo9SgGkiDbs3HRn7z8:
		gANn35esloKUydOipfSMC6RD2 = url.replace(KKSjuTY20EibkGc413C[3],'download')
		ZCOosjaQ8x9HDKSVGM6LwW2vy = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,gANn35esloKUydOipfSMC6RD2,'',headers,'','SERIES4WATCH-PLAY-3rd')
		id = u5h2Rckvw1E.findall('postId:"(.*?)"',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)
		if id:
			eitKAc89owDhTpUWvmBrxM6RI = id[0]
			emrzEIsMWO2GLw9lpKxSY7n0F = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' }
			gANn35esloKUydOipfSMC6RD2 = yONJxHER9BIDPpTV4YsWmc0n + '/ajaxCenter?_action=getdownloadlinks&postId='+eitKAc89owDhTpUWvmBrxM6RI
			ZCOosjaQ8x9HDKSVGM6LwW2vy = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,gANn35esloKUydOipfSMC6RD2,'',emrzEIsMWO2GLw9lpKxSY7n0F,'','SERIES4WATCH-PLAY-4th')
			cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('<h3.*?(\d+)(.*?)</div>',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)
			if cWafzb4HoG1Em3Jwxu6C7vZsVi:
				for oo8X36PUtVj7LJKsDdkMblEgCZYWn,lmO2YJGr6tCV in cWafzb4HoG1Em3Jwxu6C7vZsVi:
					items = u5h2Rckvw1E.findall('<td>(.*?)<.*?href="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
					for name,ekTrZlFMu0Kf5QztEnhAs in items:
						EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs+'?named='+name+'__download'+'____'+oo8X36PUtVj7LJKsDdkMblEgCZYWn)
			else:
				cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('<h6(.*?)</table>',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)
				if not cWafzb4HoG1Em3Jwxu6C7vZsVi: cWafzb4HoG1Em3Jwxu6C7vZsVi = [ZCOosjaQ8x9HDKSVGM6LwW2vy]
				for lmO2YJGr6tCV in cWafzb4HoG1Em3Jwxu6C7vZsVi:
					name = ''
					items = u5h2Rckvw1E.findall('href="(http.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
					for ekTrZlFMu0Kf5QztEnhAs in items:
						NDwLctrHpYz3JBP = '&&' + ekTrZlFMu0Kf5QztEnhAs.split('/')[2].lower() + '&&'
						NDwLctrHpYz3JBP = NDwLctrHpYz3JBP.replace('.com&&','').replace('.co&&','')
						NDwLctrHpYz3JBP = NDwLctrHpYz3JBP.replace('.net&&','').replace('.org&&','')
						NDwLctrHpYz3JBP = NDwLctrHpYz3JBP.replace('.live&&','').replace('.online&&','')
						NDwLctrHpYz3JBP = NDwLctrHpYz3JBP.replace('&&hd.','').replace('&&www.','')
						NDwLctrHpYz3JBP = NDwLctrHpYz3JBP.replace('&&','')
						ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs + '?named=' + name + NDwLctrHpYz3JBP + '__download'
						EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(EaBeVhOsHYg8wub,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	search = search.replace(' ','+')
	url = yONJxHER9BIDPpTV4YsWmc0n + '/search?s='+search
	ll0a2AwztChcpsDUMi4rGW3b61XZES(url)
	return
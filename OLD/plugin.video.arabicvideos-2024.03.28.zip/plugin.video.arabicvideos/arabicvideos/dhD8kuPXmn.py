# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'EGYBESTVIP'
tiCRYyX1bWd40Ir3PafQu = '_EGV_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
def cc03CYPLaxRfUKJb9eynFTr(mode,url,BzbaC0qYjMr2WXwsO,text):
	if   mode==220: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==221: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,BzbaC0qYjMr2WXwsO)
	elif mode==222: vS7JufTVsBxw52 = GQsDp6PWFHRE1ki2odqrwjB0ISTLh(url)
	elif mode==223: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==224: vS7JufTVsBxw52 = WYxFZIrRp6b(url)
	elif mode==229: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',229,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',yONJxHER9BIDPpTV4YsWmc0n,'','','','','EGYBEST-MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="i i-home"(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)"(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,222)
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="ba(.*?)<script',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		for title,ekTrZlFMu0Kf5QztEnhAs in items:
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,221)
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if 'html' not in ekTrZlFMu0Kf5QztEnhAs: continue
			if not ekTrZlFMu0Kf5QztEnhAs.endswith('/'): uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,221)
	return oo9SgGkiDbs3HRn7z8
def GQsDp6PWFHRE1ki2odqrwjB0ISTLh(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',url,'','','','','EGYBESTVIP-SUBMENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="rs_scroll"(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('href="(.*?)".*?</i>(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,224)
	return
def WYxFZIrRp6b(url):
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع',url,221)
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,url,'','','','EGYBESTVIP-FILTERS_MENU-1st')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="sub_nav(.*?)id="movies',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".+?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if ekTrZlFMu0Kf5QztEnhAs=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,221)
	else: ll0a2AwztChcpsDUMi4rGW3b61XZES(url)
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,BzbaC0qYjMr2WXwsO='1'):
	if BzbaC0qYjMr2WXwsO=='': BzbaC0qYjMr2WXwsO = '1'
	if '/search' in url or '?' in url: gANn35esloKUydOipfSMC6RD2 = url + '&'
	else: gANn35esloKUydOipfSMC6RD2 = url + '?'
	gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2 + 'page=' + BzbaC0qYjMr2WXwsO
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,gANn35esloKUydOipfSMC6RD2,'','','','EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		cWafzb4HoG1Em3Jwxu6C7vZsVi=u5h2Rckvw1E.findall('class="pda"(.*?)div',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[-1]
	elif '/series/' in url:
		cWafzb4HoG1Em3Jwxu6C7vZsVi=u5h2Rckvw1E.findall('class="owl-carousel owl-carousel(.*?)div',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	else:
		cWafzb4HoG1Em3Jwxu6C7vZsVi=u5h2Rckvw1E.findall('id="movies(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[-1]
	items = u5h2Rckvw1E.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
		title = uTUNPkVwCMKiD5gHLaj(title)
		if '/movie/' in ekTrZlFMu0Kf5QztEnhAs or '/episode' in ekTrZlFMu0Kf5QztEnhAs:
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs.rstrip('/'),223,pGjsvdyHfM)
		else:
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,221,pGjsvdyHfM)
	if len(items)>=16:
		ZaGAhxzl74FSMXYN = ['/movies','/tv','/search','/trending']
		BzbaC0qYjMr2WXwsO = int(BzbaC0qYjMr2WXwsO)
		if any(c2eEflztvIX in url for c2eEflztvIX in ZaGAhxzl74FSMXYN):
			for Tv6UAQeCoMS in range(0,1000,100):
				if int(BzbaC0qYjMr2WXwsO/100)*100==Tv6UAQeCoMS:
					for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(Tv6UAQeCoMS,Tv6UAQeCoMS+100,10):
						if int(BzbaC0qYjMr2WXwsO/10)*10==Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE:
							for SusDjNO9Kv4rIx in range(Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE,Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE+10,1):
								if not BzbaC0qYjMr2WXwsO==SusDjNO9Kv4rIx and SusDjNO9Kv4rIx!=0:
									uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+str(SusDjNO9Kv4rIx),url,221,'',str(SusDjNO9Kv4rIx))
						elif Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE!=0: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+str(Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE),url,221,'',str(Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE))
						else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+str(1),url,221,'',str(1))
				elif Tv6UAQeCoMS!=0: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+str(Tv6UAQeCoMS),url,221,'',str(Tv6UAQeCoMS))
				else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+str(1),url,221)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	hVby8e3aQkFfuE,EaBeVhOsHYg8wub = [],[]
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,url,'','','','EGYBESTVIP-PLAY-1st')
	PmF0XjQN51GpKACfLgnyTv7 = u5h2Rckvw1E.findall('<td>التصنيف</td>.*?">(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if PmF0XjQN51GpKACfLgnyTv7 and dQorkS3qBhIMDWKHl(aUVSgO2ebjwX5iqPykC,url,PmF0XjQN51GpKACfLgnyTv7): return
	jCdtcqaFQ4p,vduAMOjFeso = '',''
	G2yHuFf876XlWtj,hhw4sHVjPB8p = oo9SgGkiDbs3HRn7z8,oo9SgGkiDbs3HRn7z8
	u8lMpqWdUR = u5h2Rckvw1E.findall('show_dl api" href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if u8lMpqWdUR:
		for ekTrZlFMu0Kf5QztEnhAs in u8lMpqWdUR:
			if '/watch/' in ekTrZlFMu0Kf5QztEnhAs: jCdtcqaFQ4p = ekTrZlFMu0Kf5QztEnhAs
			elif '/download/' in ekTrZlFMu0Kf5QztEnhAs: vduAMOjFeso = ekTrZlFMu0Kf5QztEnhAs
		if jCdtcqaFQ4p!='': G2yHuFf876XlWtj = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,jCdtcqaFQ4p,'','','','EGYBESTVIP-PLAY-2nd')
		if vduAMOjFeso!='': hhw4sHVjPB8p = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,vduAMOjFeso,'','','','EGYBESTVIP-PLAY-3rd')
	iqN2KkSLbFW0AR6MnmOPCh5j = u5h2Rckvw1E.findall('id="video".*?data-src="(.*?)"',G2yHuFf876XlWtj,u5h2Rckvw1E.DOTALL)
	if iqN2KkSLbFW0AR6MnmOPCh5j:
		gANn35esloKUydOipfSMC6RD2 = iqN2KkSLbFW0AR6MnmOPCh5j[0]
		if gANn35esloKUydOipfSMC6RD2!='' and 'uploaded.egybest.download' in gANn35esloKUydOipfSMC6RD2 and '/?id=_' not in gANn35esloKUydOipfSMC6RD2:
			ZCOosjaQ8x9HDKSVGM6LwW2vy = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,gANn35esloKUydOipfSMC6RD2,'','','','EGYBESTVIP-PLAY-4th')
			WKqaFuETNUZmoxI7p9Mtv = u5h2Rckvw1E.findall('source src="(.*?)" title="(.*?)"',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)
			if WKqaFuETNUZmoxI7p9Mtv:
				for ekTrZlFMu0Kf5QztEnhAs,ohAHUqdbWFi8D1L4Xwzus0f3RYv in WKqaFuETNUZmoxI7p9Mtv:
					EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs+'?named=ed.egybest.do__watch__mp4__'+ohAHUqdbWFi8D1L4Xwzus0f3RYv)
			else:
				NDwLctrHpYz3JBP = gANn35esloKUydOipfSMC6RD2.split('/')[2]
				EaBeVhOsHYg8wub.append(gANn35esloKUydOipfSMC6RD2+'?named='+NDwLctrHpYz3JBP+'__watch')
		elif gANn35esloKUydOipfSMC6RD2!='':
			NDwLctrHpYz3JBP = gANn35esloKUydOipfSMC6RD2.split('/')[2]
			EaBeVhOsHYg8wub.append(gANn35esloKUydOipfSMC6RD2+'?named='+NDwLctrHpYz3JBP+'__watch')
	PPe61Z3x2Gt = u5h2Rckvw1E.findall('<table class="dls_table(.*?)</table>',hhw4sHVjPB8p,u5h2Rckvw1E.DOTALL)
	if PPe61Z3x2Gt:
		PPe61Z3x2Gt = PPe61Z3x2Gt[0]
		W7ZMH2mPFax3d = u5h2Rckvw1E.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',PPe61Z3x2Gt,u5h2Rckvw1E.DOTALL)
		if W7ZMH2mPFax3d:
			for ohAHUqdbWFi8D1L4Xwzus0f3RYv,ekTrZlFMu0Kf5QztEnhAs in W7ZMH2mPFax3d:
				if 'myegyvip' not in ekTrZlFMu0Kf5QztEnhAs: continue
				if ekTrZlFMu0Kf5QztEnhAs.count('/')>=2:
					NDwLctrHpYz3JBP = ekTrZlFMu0Kf5QztEnhAs.split('/')[2]
					EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs+'?named='+NDwLctrHpYz3JBP+'__download__mp4__'+ohAHUqdbWFi8D1L4Xwzus0f3RYv)
	agupMjtTxhzvJcLZ8DklEOW34B = []
	for ekTrZlFMu0Kf5QztEnhAs in EaBeVhOsHYg8wub:
		agupMjtTxhzvJcLZ8DklEOW34B.append(ekTrZlFMu0Kf5QztEnhAs)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(agupMjtTxhzvJcLZ8DklEOW34B,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	GHFUMEOSrvhmIoVWxwN8j4 = search.replace(' ','+')
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(hs8IDEMn0YuCHwk,yONJxHER9BIDPpTV4YsWmc0n,'','','','EGYBESTVIP-SEARCH-1st')
	dh1veN6mVBg7pQ = u5h2Rckvw1E.findall('name="_token" value="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if dh1veN6mVBg7pQ:
		url = yONJxHER9BIDPpTV4YsWmc0n+'/search?_token='+dh1veN6mVBg7pQ[0]+'&q='+GHFUMEOSrvhmIoVWxwN8j4
		ll0a2AwztChcpsDUMi4rGW3b61XZES(url)
	return
# -*- coding: utf-8 -*-
import sys as vdo2FnhPmAVRMJQZ0EIG8
XzBpdMGJhHZKC8Yveki5qb1jT4nQUg = vdo2FnhPmAVRMJQZ0EIG8.version_info [0] == 2
vykERrdZlF5K = 2048
GG02h4EolRYTs3iv = 7
def tci7BbCy6gT9MXkOEzhm (xVtfmzjd6RSsBEk2o34aHWC):
	global jMo7iTRkq0n1NPa35xheAVlbt
	oAJijr7NHwnfUGqyd8Ru6EImOtv = ord (xVtfmzjd6RSsBEk2o34aHWC [-1])
	wwpaJlB3bkXySOHFWUfoILC = xVtfmzjd6RSsBEk2o34aHWC [:-1]
	lqXRut6PnL = oAJijr7NHwnfUGqyd8Ru6EImOtv % len (wwpaJlB3bkXySOHFWUfoILC)
	rmaU71pZj3X = wwpaJlB3bkXySOHFWUfoILC [:lqXRut6PnL] + wwpaJlB3bkXySOHFWUfoILC [lqXRut6PnL:]
	if XzBpdMGJhHZKC8Yveki5qb1jT4nQUg:
		bbsiU0a49tw2dy = unicode () .join ([unichr (ord (Q9QUIWH6rK2BlmC) - vykERrdZlF5K - (ZXwWfDc9AF4yr2P + oAJijr7NHwnfUGqyd8Ru6EImOtv) % GG02h4EolRYTs3iv) for ZXwWfDc9AF4yr2P, Q9QUIWH6rK2BlmC in enumerate (rmaU71pZj3X)])
	else:
		bbsiU0a49tw2dy = str () .join ([chr (ord (Q9QUIWH6rK2BlmC) - vykERrdZlF5K - (ZXwWfDc9AF4yr2P + oAJijr7NHwnfUGqyd8Ru6EImOtv) % GG02h4EolRYTs3iv) for ZXwWfDc9AF4yr2P, Q9QUIWH6rK2BlmC in enumerate (rmaU71pZj3X)])
	return eval (bbsiU0a49tw2dy)
r3flT0zQPa5H7yXEgxJOt92Vc4Ao,cgtRBdXxSOk7WUfyDhPCls,cNaVb1vsT4qWOL0rpE=tci7BbCy6gT9MXkOEzhm,tci7BbCy6gT9MXkOEzhm,tci7BbCy6gT9MXkOEzhm
yruHDQOcB97ig,drHLAY5ENQFe2q9ptKGabo,qnPgZ9N15G6Oa8UpMASvLk=cNaVb1vsT4qWOL0rpE,cgtRBdXxSOk7WUfyDhPCls,r3flT0zQPa5H7yXEgxJOt92Vc4Ao
KKbpxUZnMcj6AJ4QdD,ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB,ggDRehOModi=qnPgZ9N15G6Oa8UpMASvLk,drHLAY5ENQFe2q9ptKGabo,yruHDQOcB97ig
xuztI5QWEKG70CPNdhk4vo6,bcgZJWV6UeNSkRA,shZ9eOcN2dJnPj=ggDRehOModi,ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB,KKbpxUZnMcj6AJ4QdD
BGhdkWsEvJjiMFTr3NLn1flU,nKLEi8CJumazx4qT,pcWq35MED2dtK=shZ9eOcN2dJnPj,bcgZJWV6UeNSkRA,xuztI5QWEKG70CPNdhk4vo6
yF29Xdsx35wI07Ce4,XikqnGVSK4v9d3uUICLhDxJyt1M,JLoPRXt93dpAB=pcWq35MED2dtK,nKLEi8CJumazx4qT,BGhdkWsEvJjiMFTr3NLn1flU
wwplD0tEehqH3kYQXs,tZ3gsrTEdzA1S6LXa9WI5px,Nqj35AXg06euY1G2d4bSUMQ8wlr=JLoPRXt93dpAB,XikqnGVSK4v9d3uUICLhDxJyt1M,yF29Xdsx35wI07Ce4
bbw2eajMlG,M6PIj8gl1fno7wcqTksDEBK4bU,CgG4PuyxsLA8WDzh3FfteZvKQMdom9=Nqj35AXg06euY1G2d4bSUMQ8wlr,tZ3gsrTEdzA1S6LXa9WI5px,wwplD0tEehqH3kYQXs
iifPEY9ABNzTQp,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ,PtXn0k9G3ocHRg=CgG4PuyxsLA8WDzh3FfteZvKQMdom9,M6PIj8gl1fno7wcqTksDEBK4bU,bbw2eajMlG
Tgoa16jMxvYX2,vvBChXmSty,InKG0i2r6hHDvgd=PtXn0k9G3ocHRg,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ,iifPEY9ABNzTQp
OyJ1o4AvmWlB75UkFRX,usaZLwSGe1k6VDp570yhB4bzWPiFq,oUlIcGH2JuWFLvimMXyBQdzK06ge=InKG0i2r6hHDvgd,vvBChXmSty,Tgoa16jMxvYX2
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = nKLEi8CJumazx4qT(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
tiCRYyX1bWd40Ir3PafQu = nKLEi8CJumazx4qT(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
AS7HdrNWtlG0hOJsju8EbYDapwqT = k1t0JLRsCQ.path.join(gDC5Zva1sxhpHLP8SwoIe3fRlB7t,nKLEi8CJumazx4qT(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
ZEjh3uy2D5Qg7lSPqKBr4OsfJ6Lm = k1t0JLRsCQ.path.join(gDC5Zva1sxhpHLP8SwoIe3fRlB7t,wwplD0tEehqH3kYQXs(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
bQ9OUj6gsRucqW = k1t0JLRsCQ.path.join(r4roga1DYEwG,nKLEi8CJumazx4qT(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),bcgZJWV6UeNSkRA(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
oo6iV7uP1FeANbnwJDgpxlZ3LM4HyK = vRsq07Q8nmCxVTWJ
oYHbwGN4u25OWS3rg1nqyaPUId0tsR = M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
zlrfHDbVh78pe3xtI = drHLAY5ENQFe2q9ptKGabo(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
ccSZXHkxYJgDuzCBh2TyrF = Tgoa16jMxvYX2(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
q8ZlP1pTnWGL = oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
mUnqX1Tk4QvGHS6BDa8LzP = Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
fB9aqU16v3TIkwep50NrhS = cgtRBdXxSOk7WUfyDhPCls(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
def cc03CYPLaxRfUKJb9eynFTr(mode):
	if   wMCm6g9qFyPT0xpneDUNc2lEhaZY==Tgoa16jMxvYX2(u"࠹࠷࠴ࣉ"): vS7JufTVsBxw52 = iqrDX95ex1URJyaoE38()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==PtXn0k9G3ocHRg(u"࠺࠸࠶࣊"): vS7JufTVsBxw52 = DzIGOoUJcZT9tQeuX3RyY(AS7HdrNWtlG0hOJsju8EbYDapwqT,CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࡖࡵࡹࡪࣳ"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࡖࡵࡹࡪࣳ"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==OyJ1o4AvmWlB75UkFRX(u"࠻࠹࠸࣋"): vS7JufTVsBxw52 = DzIGOoUJcZT9tQeuX3RyY(ZEjh3uy2D5Qg7lSPqKBr4OsfJ6Lm,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࡗࡶࡺ࡫ࣴ"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࡗࡶࡺ࡫ࣴ"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==JLoPRXt93dpAB(u"࠼࠺࠳࣌"): vS7JufTVsBxw52 = DzIGOoUJcZT9tQeuX3RyY(bQ9OUj6gsRucqW,XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࡋࡧ࡬ࡴࡧࣶ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࡘࡷࡻࡥࣵ"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==tZ3gsrTEdzA1S6LXa9WI5px(u"࠽࠴࠵࣍"): vS7JufTVsBxw52 = m2kcIHqhia98ByvTAE0lgJR3GP(oo6iV7uP1FeANbnwJDgpxlZ3LM4HyK,wwplD0tEehqH3kYQXs(u"࡚ࡲࡶࡧࣷ"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==wwplD0tEehqH3kYQXs(u"࠷࠵࠷࣎"): vS7JufTVsBxw52 = ileksM7vTVHrcCLWz91hOZgAES5yf(nKLEi8CJumazx4qT(u"ࡔࡳࡷࡨࣸ"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==cNaVb1vsT4qWOL0rpE(u"࠸࠷࠳࣏"): vS7JufTVsBxw52 = LAzCJtqgv3()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==tZ3gsrTEdzA1S6LXa9WI5px(u"࠹࠸࠵࣐"): vS7JufTVsBxw52 = DzIGOoUJcZT9tQeuX3RyY(oYHbwGN4u25OWS3rg1nqyaPUId0tsR,Tgoa16jMxvYX2(u"ࡈࡤࡰࡸ࡫ࣺ"),pcWq35MED2dtK(u"ࡕࡴࡸࡩࣹ"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠺࠹࠷࣑"): vS7JufTVsBxw52 = DzIGOoUJcZT9tQeuX3RyY(zlrfHDbVh78pe3xtI,wwplD0tEehqH3kYQXs(u"ࡊࡦࡲࡳࡦࣼ"),vvBChXmSty(u"ࡗࡶࡺ࡫ࣻ"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠻࠺࠹࣒"): vS7JufTVsBxw52 = DzIGOoUJcZT9tQeuX3RyY(ccSZXHkxYJgDuzCBh2TyrF,tZ3gsrTEdzA1S6LXa9WI5px(u"ࡌࡡ࡭ࡵࡨࣾ"),cNaVb1vsT4qWOL0rpE(u"࡙ࡸࡵࡦࣽ"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==xuztI5QWEKG70CPNdhk4vo6(u"࠼࠻࠴࣓"): vS7JufTVsBxw52 = DzIGOoUJcZT9tQeuX3RyY(q8ZlP1pTnWGL,M6PIj8gl1fno7wcqTksDEBK4bU(u"ࡇࡣ࡯ࡷࡪऀ"),pcWq35MED2dtK(u"ࡔࡳࡷࡨࣿ"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==bcgZJWV6UeNSkRA(u"࠽࠵࠶ࣔ"): vS7JufTVsBxw52 = DzIGOoUJcZT9tQeuX3RyY(mUnqX1Tk4QvGHS6BDa8LzP,bcgZJWV6UeNSkRA(u"ࡉࡥࡱࡹࡥं"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࡖࡵࡹࡪँ"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠷࠶࠸ࣕ"): vS7JufTVsBxw52 = DzIGOoUJcZT9tQeuX3RyY(fB9aqU16v3TIkwep50NrhS,Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࡋࡧ࡬ࡴࡧऄ"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࡘࡷࡻࡥः"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==nKLEi8CJumazx4qT(u"࠸࠷࠺ࣖ"): vS7JufTVsBxw52 = Y9YSKfNB1GD2deXMjsI(BGhdkWsEvJjiMFTr3NLn1flU(u"࡚ࡲࡶࡧअ"))
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==qnPgZ9N15G6Oa8UpMASvLk(u"࠹࠸࠼ࣗ"): vS7JufTVsBxw52 = G7LkaHvsDmldN()
	else: vS7JufTVsBxw52 = pcWq35MED2dtK(u"ࡆࡢ࡮ࡶࡩआ")
	return vS7JufTVsBxw52
def iqrDX95ex1URJyaoE38():
	ASQrfKb16zglOMihIxkj3nuva4Vp,JJvFAVE6hkGfgMqxBw4yHo0U = GeJubBzCto(AS7HdrNWtlG0hOJsju8EbYDapwqT)
	pXrDBWP34YwGlonE9f,RUI86WhV143yDBjSxEJTFgtHf7G2 = GeJubBzCto(ZEjh3uy2D5Qg7lSPqKBr4OsfJ6Lm)
	IKP24uoxatRm1l,NoYMwqPse2ub6RpCLIZ0y9dvn = GeJubBzCto(bQ9OUj6gsRucqW)
	yyiuJCF4SN6Iq9o83KT,oqPK7NFmTayt5hRp2zux9Jj = FLTvHN0VMOGiZ29(oo6iV7uP1FeANbnwJDgpxlZ3LM4HyK)
	yyiuJCF4SN6Iq9o83KT -= iifPEY9ABNzTQp(u"࠶࠺࠽࠼࠴ࣘ")
	oqPK7NFmTayt5hRp2zux9Jj -= cNaVb1vsT4qWOL0rpE(u"࠵ࣙ")
	ASpYQV56F8DxvUwly0cmoaqPLh1Tu = BGhdkWsEvJjiMFTr3NLn1flU(u"ࠩࠣࠬࠬࠌ")+Q4aVEf9xMPFu(ASQrfKb16zglOMihIxkj3nuva4Vp)+qnPgZ9N15G6Oa8UpMASvLk(u"ࠪࠤ࠲ࠦࠧࠍ")+str(JJvFAVE6hkGfgMqxBw4yHo0U)+KKbpxUZnMcj6AJ4QdD(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠎ")
	lxLX0WcduZFq2y7j6SVMvw = PtXn0k9G3ocHRg(u"ࠬࠦࠨࠨࠏ")+Q4aVEf9xMPFu(pXrDBWP34YwGlonE9f)+PtXn0k9G3ocHRg(u"࠭ࠠ࠮ࠢࠪࠐ")+str(RUI86WhV143yDBjSxEJTFgtHf7G2)+xuztI5QWEKG70CPNdhk4vo6(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠑ")
	sfDMbT5Q8z = xuztI5QWEKG70CPNdhk4vo6(u"ࠨࠢࠫࠫࠒ")+Q4aVEf9xMPFu(IKP24uoxatRm1l)+wwplD0tEehqH3kYQXs(u"ࠩࠣ࠱ࠥ࠭ࠓ")+str(NoYMwqPse2ub6RpCLIZ0y9dvn)+wwplD0tEehqH3kYQXs(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠔ")
	I2IFEDkensK19fSihqgM = shZ9eOcN2dJnPj(u"ࠫࠥ࠮ࠧࠕ")+Q4aVEf9xMPFu(yyiuJCF4SN6Iq9o83KT)+shZ9eOcN2dJnPj(u"ࠬ࠯ࠧࠖ")
	MAGXcEdvBh = ASQrfKb16zglOMihIxkj3nuva4Vp+pXrDBWP34YwGlonE9f+IKP24uoxatRm1l+yyiuJCF4SN6Iq9o83KT
	TVYMxjoz0i1myUWNdAclErwZ6I3PC = JJvFAVE6hkGfgMqxBw4yHo0U+RUI86WhV143yDBjSxEJTFgtHf7G2+NoYMwqPse2ub6RpCLIZ0y9dvn+oqPK7NFmTayt5hRp2zux9Jj
	kc57B93HrojbDIXVipY = drHLAY5ENQFe2q9ptKGabo(u"࠭ࠠࠩࠩࠗ")+Q4aVEf9xMPFu(MAGXcEdvBh)+XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧࠡ࠯ࠣࠫ࠘")+str(TVYMxjoz0i1myUWNdAclErwZ6I3PC)+yruHDQOcB97ig(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠙")
	uQNUfbZx9yj0F(KKbpxUZnMcj6AJ4QdD(u"ࠩ࡯࡭ࡳࡱࠧࠚ"),tiCRYyX1bWd40Ir3PafQu+wwplD0tEehqH3kYQXs(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࠛ")+kc57B93HrojbDIXVipY,cgtRBdXxSOk7WUfyDhPCls(u"ࠫࠬࠜ"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠼࠺࠵ࣚ"))
	uQNUfbZx9yj0F(PtXn0k9G3ocHRg(u"ࠬࡲࡩ࡯࡭ࠪࠝ"),yruHDQOcB97ig(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨࠞ"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠧࠨࠟ"),OyJ1o4AvmWlB75UkFRX(u"࠿࠹࠺࠻ࣛ"))
	uQNUfbZx9yj0F(shZ9eOcN2dJnPj(u"ࠨ࡮࡬ࡲࡰ࠭ࠠ"),tiCRYyX1bWd40Ir3PafQu+vvBChXmSty(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠨࠡ")+ASpYQV56F8DxvUwly0cmoaqPLh1Tu,ggDRehOModi(u"ࠪࠫࠢ"),yF29Xdsx35wI07Ce4(u"࠷࠵࠳ࣜ"))
	uQNUfbZx9yj0F(JLoPRXt93dpAB(u"ࠫࡱ࡯࡮࡬ࠩࠣ"),tiCRYyX1bWd40Ir3PafQu+Nqj35AXg06euY1G2d4bSUMQ8wlr(u"๋ࠬำฮࠢส่๊๊แศฬࠣห้๋ึ฻ฺ๊อࠬࠤ")+lxLX0WcduZFq2y7j6SVMvw,BGhdkWsEvJjiMFTr3NLn1flU(u"࠭ࠧࠥ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠸࠶࠵ࣝ"))
	uQNUfbZx9yj0F(cNaVb1vsT4qWOL0rpE(u"ࠧ࡭࡫ࡱ࡯ࠬࠦ"),tiCRYyX1bWd40Ir3PafQu+usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠨ็ึัࠥอไึ๊ิࠤฬ๊โะ์่อࠬࠧ")+sfDMbT5Q8z,xuztI5QWEKG70CPNdhk4vo6(u"ࠩࠪࠨ"),Tgoa16jMxvYX2(u"࠹࠷࠷ࣞ"))
	uQNUfbZx9yj0F(M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠪࡰ࡮ࡴ࡫ࠨࠩ"),tiCRYyX1bWd40Ir3PafQu+KKbpxUZnMcj6AJ4QdD(u"ࠫฯ็ั๋฼้้ࠣ็ࠠึ๊ิࠤฬ๊ลืษไหฯ࠭ࠪ")+I2IFEDkensK19fSihqgM,yruHDQOcB97ig(u"ࠬ࠭ࠫ"),pcWq35MED2dtK(u"࠺࠸࠹ࣟ"))
	LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࠬ"),cNaVb1vsT4qWOL0rpE(u"ࠧࠨ࠭"))
	return
def LAzCJtqgv3():
	d9kPCJHez8x0bOIlXcFLMNsRg = OyJ1o4AvmWlB75UkFRX(u"ࡖࡵࡹࡪई") if n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠨ࠱ࠪ࠮") in r4roga1DYEwG else Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࡇࡣ࡯ࡷࡪइ")
	if not d9kPCJHez8x0bOIlXcFLMNsRg:
		xl9MFt1AmY0GrkENug8n(cNaVb1vsT4qWOL0rpE(u"ࠩࠪ࠯"),InKG0i2r6hHDvgd(u"ࠪࠫ࠰"),bbw2eajMlG(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ࠱"),cgtRBdXxSOk7WUfyDhPCls(u"ࠬ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣห้า็ศิ้ࠣฯ๎แาหࠣๅ็฽ࠠๅลฯ๋ืฯ๋๊้ࠠ็ุࠦ࠮࠯๋ࠢะ์อาไࠢ็๎ุࠦๅ็้ࠢ์฾๊้่ࠦๆืࠬ࠲"))
		return
	hPvDUWG0xTNq6kC = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(shZ9eOcN2dJnPj(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪ࠳"))
	if not hPvDUWG0xTNq6kC: G7LkaHvsDmldN()
	ASQrfKb16zglOMihIxkj3nuva4Vp,JJvFAVE6hkGfgMqxBw4yHo0U = GeJubBzCto(oYHbwGN4u25OWS3rg1nqyaPUId0tsR)
	pXrDBWP34YwGlonE9f,RUI86WhV143yDBjSxEJTFgtHf7G2 = GeJubBzCto(zlrfHDbVh78pe3xtI)
	IKP24uoxatRm1l,NoYMwqPse2ub6RpCLIZ0y9dvn = GeJubBzCto(ccSZXHkxYJgDuzCBh2TyrF)
	yyiuJCF4SN6Iq9o83KT,oqPK7NFmTayt5hRp2zux9Jj = GeJubBzCto(q8ZlP1pTnWGL)
	ppUrstRLATFCQ7Pj,QC1iv6OJytDY43IeXqVGfkEjcKnA = GeJubBzCto(mUnqX1Tk4QvGHS6BDa8LzP)
	ttoiFR3E2cVgm4,AAyjFbf1YiWO6mx5LKVUBRNPDoQw = GeJubBzCto(fB9aqU16v3TIkwep50NrhS)
	ASpYQV56F8DxvUwly0cmoaqPLh1Tu = Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠧࠡࠪࠪ࠴")+Q4aVEf9xMPFu(ASQrfKb16zglOMihIxkj3nuva4Vp)+ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠨࠢ࠰ࠤࠬ࠵")+str(JJvFAVE6hkGfgMqxBw4yHo0U)+cgtRBdXxSOk7WUfyDhPCls(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪ࠶")
	lxLX0WcduZFq2y7j6SVMvw = xuztI5QWEKG70CPNdhk4vo6(u"ࠪࠤ࠭࠭࠷")+Q4aVEf9xMPFu(pXrDBWP34YwGlonE9f)+shZ9eOcN2dJnPj(u"ࠫࠥ࠳ࠠࠨ࠸")+str(RUI86WhV143yDBjSxEJTFgtHf7G2)+wwplD0tEehqH3kYQXs(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭࠹")
	sfDMbT5Q8z = PtXn0k9G3ocHRg(u"࠭ࠠࠩࠩ࠺")+Q4aVEf9xMPFu(IKP24uoxatRm1l)+OyJ1o4AvmWlB75UkFRX(u"ࠧࠡ࠯ࠣࠫ࠻")+str(NoYMwqPse2ub6RpCLIZ0y9dvn)+nKLEi8CJumazx4qT(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠼")
	I2IFEDkensK19fSihqgM = cNaVb1vsT4qWOL0rpE(u"ࠩࠣࠬࠬ࠽")+Q4aVEf9xMPFu(yyiuJCF4SN6Iq9o83KT)+usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠪࠤ࠲ࠦࠧ࠾")+str(oqPK7NFmTayt5hRp2zux9Jj)+cNaVb1vsT4qWOL0rpE(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬ࠿")
	NNdxsKUWb6cS5T = PtXn0k9G3ocHRg(u"ࠬࠦࠨࠨࡀ")+Q4aVEf9xMPFu(ppUrstRLATFCQ7Pj)+XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠭ࠠ࠮ࠢࠪࡁ")+str(QC1iv6OJytDY43IeXqVGfkEjcKnA)+xuztI5QWEKG70CPNdhk4vo6(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࡂ")
	QPXF4yIL5f3 = tZ3gsrTEdzA1S6LXa9WI5px(u"ࠨࠢࠫࠫࡃ")+Q4aVEf9xMPFu(ttoiFR3E2cVgm4)+KKbpxUZnMcj6AJ4QdD(u"ࠩࠣ࠱ࠥ࠭ࡄ")+str(AAyjFbf1YiWO6mx5LKVUBRNPDoQw)+n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡅ")
	MAGXcEdvBh = ASQrfKb16zglOMihIxkj3nuva4Vp+pXrDBWP34YwGlonE9f+IKP24uoxatRm1l+yyiuJCF4SN6Iq9o83KT+ppUrstRLATFCQ7Pj+ttoiFR3E2cVgm4
	TVYMxjoz0i1myUWNdAclErwZ6I3PC = JJvFAVE6hkGfgMqxBw4yHo0U+RUI86WhV143yDBjSxEJTFgtHf7G2+NoYMwqPse2ub6RpCLIZ0y9dvn+oqPK7NFmTayt5hRp2zux9Jj+QC1iv6OJytDY43IeXqVGfkEjcKnA+AAyjFbf1YiWO6mx5LKVUBRNPDoQw
	kc57B93HrojbDIXVipY = BGhdkWsEvJjiMFTr3NLn1flU(u"ࠫࠥ࠮ࠧࡆ")+Q4aVEf9xMPFu(MAGXcEdvBh)+tZ3gsrTEdzA1S6LXa9WI5px(u"ࠬࠦ࠭ࠡࠩࡇ")+str(TVYMxjoz0i1myUWNdAclErwZ6I3PC)+Tgoa16jMxvYX2(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࡈ")
	uQNUfbZx9yj0F(PtXn0k9G3ocHRg(u"ࠧ࡭࡫ࡱ࡯ࠬࡉ"),tiCRYyX1bWd40Ir3PafQu+InKG0i2r6hHDvgd(u"ࠨว฼฻ฬวࠠาะุอ่ࠥัศรฬࠤํ้สศสฬࠫࡊ"),PtXn0k9G3ocHRg(u"ࠩࠪࡋ"),vvBChXmSty(u"࠻࠺࠾࣠"))
	uQNUfbZx9yj0F(M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠪࡰ࡮ࡴ࡫ࠨࡌ"),tiCRYyX1bWd40Ir3PafQu+iifPEY9ABNzTQp(u"ู๊ࠫอࠡษ็ะ๊๐ูࠨࡍ")+kc57B93HrojbDIXVipY,usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠬ࠭ࡎ"),Tgoa16jMxvYX2(u"࠼࠻࠷࣡"))
	uQNUfbZx9yj0F(InKG0i2r6hHDvgd(u"࠭࡬ࡪࡰ࡮ࠫࡏ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࡐ"),OyJ1o4AvmWlB75UkFRX(u"ࠨࠩࡑ"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠿࠹࠺࠻࣢"))
	uQNUfbZx9yj0F(vvBChXmSty(u"ࠩ࡯࡭ࡳࡱࠧࡒ"),tiCRYyX1bWd40Ir3PafQu+xuztI5QWEKG70CPNdhk4vo6(u"ุ้ࠪำࠠๆๆไหฯࠦࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠪࡓ")+ASpYQV56F8DxvUwly0cmoaqPLh1Tu,ggDRehOModi(u"ࠫࠬࡔ"),wwplD0tEehqH3kYQXs(u"࠷࠶࠳ࣣ"))
	uQNUfbZx9yj0F(nKLEi8CJumazx4qT(u"ࠬࡲࡩ࡯࡭ࠪࡕ"),tiCRYyX1bWd40Ir3PafQu+ggDRehOModi(u"࠭ๅิฯ้้ࠣ็วหࠢࡧࡶࡴࡶࡢࡰࡺࠪࡖ")+lxLX0WcduZFq2y7j6SVMvw,cgtRBdXxSOk7WUfyDhPCls(u"ࠧࠨࡗ"),pcWq35MED2dtK(u"࠸࠷࠵ࣤ"))
	uQNUfbZx9yj0F(ggDRehOModi(u"ࠨ࡮࡬ࡲࡰ࠭ࡘ"),tiCRYyX1bWd40Ir3PafQu+cgtRBdXxSOk7WUfyDhPCls(u"่ࠩืาࠦๅๅใสฮࠥࡺ࡯࡮ࡤࡶࡸࡴࡴࡥࡴ࡙ࠩ")+sfDMbT5Q8z,qnPgZ9N15G6Oa8UpMASvLk(u"࡚ࠪࠫ"),shZ9eOcN2dJnPj(u"࠹࠸࠷ࣥ"))
	uQNUfbZx9yj0F(drHLAY5ENQFe2q9ptKGabo(u"ࠫࡱ࡯࡮࡬࡛ࠩ"),tiCRYyX1bWd40Ir3PafQu+pcWq35MED2dtK(u"๋ࠬำฮ่่ࠢๆอสࠡ࡮ࡲ࡫࡬࡫ࡲࠨ࡜")+I2IFEDkensK19fSihqgM,nKLEi8CJumazx4qT(u"࠭ࠧ࡝"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠺࠹࠹ࣦ"))
	uQNUfbZx9yj0F(JLoPRXt93dpAB(u"ࠧ࡭࡫ࡱ࡯ࠬ࡞"),tiCRYyX1bWd40Ir3PafQu+Tgoa16jMxvYX2(u"ࠨ็ึั๋ࠥไโษอࠤࡱࡵࡧࠨ࡟")+NNdxsKUWb6cS5T,M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠩࠪࡠ"),KKbpxUZnMcj6AJ4QdD(u"࠻࠺࠻ࣧ"))
	uQNUfbZx9yj0F(wwplD0tEehqH3kYQXs(u"ࠪࡰ࡮ࡴ࡫ࠨࡡ"),tiCRYyX1bWd40Ir3PafQu+KKbpxUZnMcj6AJ4QdD(u"ู๊ࠫอࠡ็็ๅฬะࠠࡢࡰࡵࠫࡢ")+QPXF4yIL5f3,XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠬ࠭ࡣ"),KKbpxUZnMcj6AJ4QdD(u"࠼࠻࠶ࣨ"))
	LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(bcgZJWV6UeNSkRA(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࡤ"),Tgoa16jMxvYX2(u"ࠧࠨࡥ"))
	return
def G7LkaHvsDmldN():
	iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠨࠩࡦ"),xuztI5QWEKG70CPNdhk4vo6(u"ࠩࠪࡧ"),InKG0i2r6hHDvgd(u"ࠪࠫࡨ"),yF29Xdsx35wI07Ce4(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࡩ"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"๊ࠬใ๋ࠢํ฽๊๊ࠠศๆอ๊฽๐แࠡ฻้ำ่ࠦ࠮࠯ࠢหี๋อๅอࠢ฼้ฬีࠠษฯสะฮࠦลๅ๋ࠣษ฾฽วยࠢิาฺฯࠠศๆๅีฬวษ๊ࠡส่่ะวษห่้๋ࠣไโษอࠤํอไๆฮ็ำฬะࠠศๆอ๎ู่ࠥโࠢํุ้ำ็ศࠢส่อืๆศ็ฯࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡว฼฻ฬว่ࠠา๊ࠤฬ๊ัฯืฬࠤฬ๊ย็ࠢยࠥࠬࡪ"))
	if iZL6cN3OkM5==-Tgoa16jMxvYX2(u"࠷ࣩ"): return
	if iZL6cN3OkM5:
		import subprocess as uukUBLq6zE74
		try:
			uukUBLq6zE74.Popen(yruHDQOcB97ig(u"࠭ࡳࡶࠩ࡫"))
			C2dWfsRnuNbhm = wwplD0tEehqH3kYQXs(u"ࡗࡶࡺ࡫उ")
		except: C2dWfsRnuNbhm = yF29Xdsx35wI07Ce4(u"ࡊࡦࡲࡳࡦऊ")
		if C2dWfsRnuNbhm:
			OSGgWJbyP7Uw6tIMDj = oYHbwGN4u25OWS3rg1nqyaPUId0tsR+n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠧࠡࠩ࡬")+zlrfHDbVh78pe3xtI+Tgoa16jMxvYX2(u"ࠨࠢࠪ࡭")+ccSZXHkxYJgDuzCBh2TyrF+ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠩࠣࠫ࡮")+q8ZlP1pTnWGL+ggDRehOModi(u"ࠪࠤࠬ࡯")+mUnqX1Tk4QvGHS6BDa8LzP+BGhdkWsEvJjiMFTr3NLn1flU(u"ࠫࠥ࠭ࡰ")+fB9aqU16v3TIkwep50NrhS
			kk89fdveMO = uukUBLq6zE74.Popen(usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠬࡹࡵࠡ࠯ࡦࠤࠧࡩࡨ࡮ࡱࡧࠤ࠲ࡘࠠ࠱࠹࠺࠻ࠥ࠭ࡱ")+OSGgWJbyP7Uw6tIMDj+wwplD0tEehqH3kYQXs(u"࠭ࠢࠨࡲ"),shell=nKLEi8CJumazx4qT(u"࡙ࡸࡵࡦऋ"),stdin=uukUBLq6zE74.PIPE,stdout=uukUBLq6zE74.PIPE,stderr=uukUBLq6zE74.PIPE)
			xl9MFt1AmY0GrkENug8n(Tgoa16jMxvYX2(u"ࠧࠨࡳ"),xuztI5QWEKG70CPNdhk4vo6(u"ࠨࠩࡴ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡵ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"๊ࠪัำสࠡ฻่่๏ฯࠠฦ฻ฺหฦࠦวๅำัูฮ࠭ࡶ"))
			LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(vvBChXmSty(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨࡷ"),JLoPRXt93dpAB(u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨࡸ"))
			bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(KKbpxUZnMcj6AJ4QdD(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪࡹ"))
		else: xl9MFt1AmY0GrkENug8n(OyJ1o4AvmWlB75UkFRX(u"ࠧࠨࡺ"),cgtRBdXxSOk7WUfyDhPCls(u"ࠨࠩࡻ"),ggDRehOModi(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡼ"),bcgZJWV6UeNSkRA(u"ࠪ฽๊๊๊สࠢศ฽฼อมࠡำัูฮࠦวๅไิหฦฯ้ࠠษ็็ฯอศสࠢอัฯอฬࠡสิ๊ฬ๋ฬࠡࠢࡵࡳࡴࡺࠠࠡล๋ࠤࠥࡹࡵࡱࡧࡵࡹࡸ࡫ࡲࠡࠢฦ์ࠥࠦࡳࡶࠢࠣ์ัํวำๅ่ࠣฬ๊้ࠦฮาࠤๆ๐็้ࠡำหࠥอไษำ้ห๊าࠠ࠯࠰ࠣวํࠦใ้ัํࠤ฿๐ัࠡไสำึูࠦๅ๋ࠣหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠪࡽ"))
	return
def Q4aVEf9xMPFu(MAGXcEdvBh):
	for oVMbrsQjklpC0EeX6 in [yruHDQOcB97ig(u"ࠫࡇ࠭ࡾ"),shZ9eOcN2dJnPj(u"ࠬࡑࡂࠨࡿ"),pcWq35MED2dtK(u"࠭ࡍࡃࠩࢀ"),nKLEi8CJumazx4qT(u"ࠧࡈࡄࠪࢁ"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠨࡖࡅࠫࢂ")]:
		if MAGXcEdvBh<vvBChXmSty(u"࠱࠱࠴࠷࣪"): break
		else: MAGXcEdvBh /= shZ9eOcN2dJnPj(u"࠲࠲࠵࠸࠳࠶࣫")
	kc57B93HrojbDIXVipY = oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠤࠨ࠷࠳࠷ࡦࠡࠧࡶࠦࢃ")%(MAGXcEdvBh,oVMbrsQjklpC0EeX6)
	return kc57B93HrojbDIXVipY
def GeJubBzCto(OalNGwAPQVgE19L0qXWJfeCYBm=PtXn0k9G3ocHRg(u"ࠪ࠲ࠬࢄ")):
	global HBNekW2qFLTC1gor7mQaKX9GjJS,StCKFI7b5G6vfgVDe
	HBNekW2qFLTC1gor7mQaKX9GjJS,StCKFI7b5G6vfgVDe = M6PIj8gl1fno7wcqTksDEBK4bU(u"࠲࣬"),M6PIj8gl1fno7wcqTksDEBK4bU(u"࠲࣬")
	def YuOh4wA6RijK0M5Bcxd3(OalNGwAPQVgE19L0qXWJfeCYBm):
		global HBNekW2qFLTC1gor7mQaKX9GjJS,StCKFI7b5G6vfgVDe
		if k1t0JLRsCQ.path.exists(OalNGwAPQVgE19L0qXWJfeCYBm):
			if XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠳࣭") and PtXn0k9G3ocHRg(u"ࠫࡸࡩࡡ࡯ࡦ࡬ࡶࠬࢅ") in dir(k1t0JLRsCQ):
				for zjbkL5DxX901QRpfTshneG in k1t0JLRsCQ.scandir(OalNGwAPQVgE19L0qXWJfeCYBm):
					if zjbkL5DxX901QRpfTshneG.is_dir(follow_symlinks=drHLAY5ENQFe2q9ptKGabo(u"ࡌࡡ࡭ࡵࡨऌ")):
						YuOh4wA6RijK0M5Bcxd3(zjbkL5DxX901QRpfTshneG.path)
					elif zjbkL5DxX901QRpfTshneG.is_file(follow_symlinks=oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࡆࡢ࡮ࡶࡩऍ")):
						HBNekW2qFLTC1gor7mQaKX9GjJS += zjbkL5DxX901QRpfTshneG.stat().st_size
						StCKFI7b5G6vfgVDe += shZ9eOcN2dJnPj(u"࠵࣮")
			else:
				for zjbkL5DxX901QRpfTshneG in k1t0JLRsCQ.listdir(OalNGwAPQVgE19L0qXWJfeCYBm):
					mmig3SVutfToID1wq4NxPLMcvp8zRC = k1t0JLRsCQ.path.abspath(k1t0JLRsCQ.path.join(OalNGwAPQVgE19L0qXWJfeCYBm,zjbkL5DxX901QRpfTshneG))
					if k1t0JLRsCQ.path.isdir(mmig3SVutfToID1wq4NxPLMcvp8zRC):
						YuOh4wA6RijK0M5Bcxd3(mmig3SVutfToID1wq4NxPLMcvp8zRC)
					elif k1t0JLRsCQ.path.isfile(mmig3SVutfToID1wq4NxPLMcvp8zRC):
						MAGXcEdvBh,TVYMxjoz0i1myUWNdAclErwZ6I3PC = FLTvHN0VMOGiZ29(mmig3SVutfToID1wq4NxPLMcvp8zRC)
						HBNekW2qFLTC1gor7mQaKX9GjJS += MAGXcEdvBh
						StCKFI7b5G6vfgVDe += TVYMxjoz0i1myUWNdAclErwZ6I3PC
		return
	try: YuOh4wA6RijK0M5Bcxd3(OalNGwAPQVgE19L0qXWJfeCYBm)
	except: pass
	return HBNekW2qFLTC1gor7mQaKX9GjJS,StCKFI7b5G6vfgVDe
def U5UfT0DdBLJOQpny1WbrhMxa4qR2(OqD9h7QZ3Sgd1Fk,showDialogs):
	if showDialogs:
		iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(yF29Xdsx35wI07Ce4(u"ࠬ࠭ࢆ"),qnPgZ9N15G6Oa8UpMASvLk(u"࠭ࠧࢇ"),cNaVb1vsT4qWOL0rpE(u"ࠧࠨ࢈"),PtXn0k9G3ocHRg(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࢉ"),OqD9h7QZ3Sgd1Fk+OyJ1o4AvmWlB75UkFRX(u"ࠩ࡟ࡲࡡࡴࠧࢊ")+XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่่ๆࠦฟࠢ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢋ"))
		if iZL6cN3OkM5!=XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠶࣯"): return
	msIaGyDgPtv = Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࡇࡣ࡯ࡷࡪऎ")
	if k1t0JLRsCQ.path.exists(OqD9h7QZ3Sgd1Fk):
		try: k1t0JLRsCQ.remove(OqD9h7QZ3Sgd1Fk)
		except Exception as M0TkYNERP4AU7BdX:
			if showDialogs: xl9MFt1AmY0GrkENug8n(M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠫࠬࢌ"),iifPEY9ABNzTQp(u"ࠬ࠭ࢍ"),cgtRBdXxSOk7WUfyDhPCls(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢎ"),str(M0TkYNERP4AU7BdX))
			msIaGyDgPtv = yruHDQOcB97ig(u"ࡖࡵࡹࡪए")
	if showDialogs and not msIaGyDgPtv:
		xl9MFt1AmY0GrkENug8n(usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠧࠨ࢏"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠨࠩ࢐"),OyJ1o4AvmWlB75UkFRX(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࢑"),iifPEY9ABNzTQp(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫ࢒"))
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(cNaVb1vsT4qWOL0rpE(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨ࢓"),yruHDQOcB97ig(u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨ࢔"))
		bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(iifPEY9ABNzTQp(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ࢕"))
	return
def ileksM7vTVHrcCLWz91hOZgAES5yf(showDialogs):
	if showDialogs:
		iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(OyJ1o4AvmWlB75UkFRX(u"ࠧࠨ࢖"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠨࠩࢗ"),ggDRehOModi(u"ࠩࠪ࢘"),nKLEi8CJumazx4qT(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࢙࠭"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ็ๅࠢอี๏ีࠠๆีะ࢚ࠫ")+iifPEY9ABNzTQp(u"ࠬࡢ࡮ࠨ࢛")+r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠭ๅอๆาࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮࠦ࠮࠯๋้ࠢั๊ฯࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠤ࠳࠴้ࠠ็ฯ่ิࠦวๅื๋ีࠥอไใัํ้ฮࠦ࠮࠯๋ࠢฮๆื๊฻่่ࠢๆࠦี้ำࠣห้หึศใสฮࠬ࢜")+wwplD0tEehqH3kYQXs(u"ࠧ࡝ࡰࠪ࢝")+CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠨมࠤࠥࠬ࢞")+InKG0i2r6hHDvgd(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࢟"))
		if iZL6cN3OkM5!=bbw2eajMlG(u"࠷ࣰ"): return
	DzIGOoUJcZT9tQeuX3RyY(AS7HdrNWtlG0hOJsju8EbYDapwqT,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࡘࡷࡻࡥऑ"),qnPgZ9N15G6Oa8UpMASvLk(u"ࡉࡥࡱࡹࡥऐ"))
	DzIGOoUJcZT9tQeuX3RyY(ZEjh3uy2D5Qg7lSPqKBr4OsfJ6Lm,wwplD0tEehqH3kYQXs(u"࡚ࡲࡶࡧओ"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࡋࡧ࡬ࡴࡧऒ"))
	DzIGOoUJcZT9tQeuX3RyY(bQ9OUj6gsRucqW,pcWq35MED2dtK(u"ࡆࡢ࡮ࡶࡩऔ"),pcWq35MED2dtK(u"ࡆࡢ࡮ࡶࡩऔ"))
	m2kcIHqhia98ByvTAE0lgJR3GP(oo6iV7uP1FeANbnwJDgpxlZ3LM4HyK,iifPEY9ABNzTQp(u"ࡇࡣ࡯ࡷࡪक"))
	if showDialogs:
		xl9MFt1AmY0GrkENug8n(cNaVb1vsT4qWOL0rpE(u"ࠪࠫࢠ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠫࠬࢡ"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࢢ"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧࢣ"))
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(wwplD0tEehqH3kYQXs(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫࢤ"),cNaVb1vsT4qWOL0rpE(u"ࠨࡕࡒࡑࡊ࡚ࡈࡊࡐࡊࠫࢥ"))
		bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(ggDRehOModi(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭ࢦ"))
	return
def Y9YSKfNB1GD2deXMjsI(showDialogs):
	if showDialogs:
		iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(JLoPRXt93dpAB(u"ࠪࠫࢧ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠫࠬࢨ"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠬ࠭ࢩ"),KKbpxUZnMcj6AJ4QdD(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢪ"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๊่ࠥะั๋ัุ้ࠣำࠠๆๆไหฯ࠭ࢫ")+bbw2eajMlG(u"ࠨ࡞ࡱࠫࢬ")+Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠩࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸࠦ࠮࠯ࠢࡧࡶࡴࡶࡢࡰࡺࠣ࠲࠳ࠦࡴࡰ࡯ࡥࡷࡹࡵ࡮ࡦࡵࠣ࠲࠳ࠦ࡬ࡰࡩࡪࡩࡷࠦ࠮࠯ࠢ࡯ࡳ࡬ࠦ࠮࠯ࠢࡤࡲࡷ࠭ࢭ")+nKLEi8CJumazx4qT(u"ࠪࡠࡳ࠭ࢮ")+PtXn0k9G3ocHRg(u"ࠫࡄࠧࠡࠨࢯ")+InKG0i2r6hHDvgd(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࢰ"))
		if iZL6cN3OkM5!=cNaVb1vsT4qWOL0rpE(u"࠱ࣱ"): return
	DzIGOoUJcZT9tQeuX3RyY(oYHbwGN4u25OWS3rg1nqyaPUId0tsR,r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࡈࡤࡰࡸ࡫ख"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࡈࡤࡰࡸ࡫ख"))
	DzIGOoUJcZT9tQeuX3RyY(zlrfHDbVh78pe3xtI,usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࡉࡥࡱࡹࡥग"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࡉࡥࡱࡹࡥग"))
	DzIGOoUJcZT9tQeuX3RyY(ccSZXHkxYJgDuzCBh2TyrF,CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࡊࡦࡲࡳࡦघ"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࡊࡦࡲࡳࡦघ"))
	DzIGOoUJcZT9tQeuX3RyY(q8ZlP1pTnWGL,bbw2eajMlG(u"ࡋࡧ࡬ࡴࡧङ"),bbw2eajMlG(u"ࡋࡧ࡬ࡴࡧङ"))
	DzIGOoUJcZT9tQeuX3RyY(mUnqX1Tk4QvGHS6BDa8LzP,tZ3gsrTEdzA1S6LXa9WI5px(u"ࡌࡡ࡭ࡵࡨच"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࡌࡡ࡭ࡵࡨच"))
	DzIGOoUJcZT9tQeuX3RyY(fB9aqU16v3TIkwep50NrhS,bbw2eajMlG(u"ࡆࡢ࡮ࡶࡩछ"),bbw2eajMlG(u"ࡆࡢ࡮ࡶࡩछ"))
	if showDialogs:
		xl9MFt1AmY0GrkENug8n(wwplD0tEehqH3kYQXs(u"࠭ࠧࢱ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧࠨࢲ"),yruHDQOcB97ig(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࢳ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪࢴ"))
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(BGhdkWsEvJjiMFTr3NLn1flU(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧࢵ"),PtXn0k9G3ocHRg(u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧࢶ"))
		bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩࢷ"))
	return
def m2kcIHqhia98ByvTAE0lgJR3GP(efpI3jkhR8bCtBXr,showDialogs):
	if showDialogs:
		iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(wwplD0tEehqH3kYQXs(u"࠭ࠧࢸ"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠧࠨࢹ"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠨࠩࢺ"),ggDRehOModi(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࢻ"),Tgoa16jMxvYX2(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ้ࠣาะ่๋ษอࠤ๊๊แࠡื๋ีࠥอไอๆาࠤฤࠧࠡࠨࢼ")+drHLAY5ENQFe2q9ptKGabo(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࢽ"))
		if iZL6cN3OkM5!=M6PIj8gl1fno7wcqTksDEBK4bU(u"࠲ࣲ"): return
	AO76Z1XEaSDjomRwK = Xmn7ZoOHiUB2fKvd6Y8ALct3GsNT.connect(efpI3jkhR8bCtBXr)
	AO76Z1XEaSDjomRwK.text_factory = str
	BVYESNuJMxlmDo5WXdaFP6r = AO76Z1XEaSDjomRwK.cursor()
	BVYESNuJMxlmDo5WXdaFP6r.execute(nKLEi8CJumazx4qT(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡴࡦࡺࡨ࠼ࠩࢾ"))
	BVYESNuJMxlmDo5WXdaFP6r.execute(OyJ1o4AvmWlB75UkFRX(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡸ࡯ࡺࡦࡵ࠾ࠫࢿ"))
	BVYESNuJMxlmDo5WXdaFP6r.execute(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡺࡥࡹࡶࡸࡶࡪࡁࠧࣀ"))
	AO76Z1XEaSDjomRwK.commit()
	BVYESNuJMxlmDo5WXdaFP6r.execute(wwplD0tEehqH3kYQXs(u"ࠨࡘࡄࡇ࡚࡛ࡍ࠼ࠩࣁ"))
	AO76Z1XEaSDjomRwK.close()
	if showDialogs:
		xl9MFt1AmY0GrkENug8n(bbw2eajMlG(u"ࠩࠪࣂ"),PtXn0k9G3ocHRg(u"ࠪࠫࣃ"),OyJ1o4AvmWlB75UkFRX(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࣄ"),wwplD0tEehqH3kYQXs(u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ࣅ"))
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࣆ"),nKLEi8CJumazx4qT(u"ࠧࡔࡑࡐࡉ࡙ࡎࡉࡏࡉࠪࣇ"))
		bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(OyJ1o4AvmWlB75UkFRX(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬࣈ"))
	return
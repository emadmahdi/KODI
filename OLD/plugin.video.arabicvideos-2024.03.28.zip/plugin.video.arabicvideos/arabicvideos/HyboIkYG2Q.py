# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'ALARAB'
headers = {'User-Agent':''}
tiCRYyX1bWd40Ir3PafQu = '_KLA_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==10: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==11: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url)
	elif mode==12: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==13: vS7JufTVsBxw52 = GA2KIlbOsoYtxpkDF71(url)
	elif mode==14: vS7JufTVsBxw52 = VCio1EXzNgM8WLmYbxtBdw()
	elif mode==15: vS7JufTVsBxw52 = iXUeOdc10MRYVz()
	elif mode==16: vS7JufTVsBxw52 = IFuMBwgZdi9WScPXKVkfzp0NT7CYt()
	elif mode==19: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',19,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'آخر الإضافات','',14)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'مسلسلات رمضان','',15)
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,yONJxHER9BIDPpTV4YsWmc0n,'',headers,'','ALARAB-MENU-1st')
	cWafzb4HoG1Em3Jwxu6C7vZsVi=u5h2Rckvw1E.findall('id="nav-slider"(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	eKOHAP95Bgxav6opdJfWq8u = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)<',eKOHAP95Bgxav6opdJfWq8u,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
		title = title.strip(' ')
		uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,11)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('id="navbar"(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	CyEMW1Sh3GtsbRUzN = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)<',CyEMW1Sh3GtsbRUzN,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
		uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,11)
	return oo9SgGkiDbs3HRn7z8
def iXUeOdc10MRYVz():
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'جميع المسلسلات العربية',yONJxHER9BIDPpTV4YsWmc0n+'/view-8/مسلسلات-عربية',11)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مسلسلات السنة الأخيرة','',16)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مسلسلات رمضان الأخيرة 1',yONJxHER9BIDPpTV4YsWmc0n+'/view-8/مسلسلات-رمضان-2022',11)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مسلسلات رمضان الأخيرة 2',yONJxHER9BIDPpTV4YsWmc0n+'/view-8/مسلسلات-رمضان-2023',11)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مسلسلات رمضان 2023',yONJxHER9BIDPpTV4YsWmc0n+'/ramadan2023/مصرية',11)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مسلسلات رمضان 2022',yONJxHER9BIDPpTV4YsWmc0n+'/ramadan2022/مصرية',11)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مسلسلات رمضان 2021',yONJxHER9BIDPpTV4YsWmc0n+'/ramadan2021/مصرية',11)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مسلسلات رمضان 2020',yONJxHER9BIDPpTV4YsWmc0n+'/ramadan2020/مصرية',11)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مسلسلات رمضان 2019',yONJxHER9BIDPpTV4YsWmc0n+'/ramadan2019/مصرية',11)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مسلسلات رمضان 2018',yONJxHER9BIDPpTV4YsWmc0n+'/ramadan2018/مصرية',11)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مسلسلات رمضان 2017',yONJxHER9BIDPpTV4YsWmc0n+'/ramadan2017/مصرية',11)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مسلسلات رمضان 2016',yONJxHER9BIDPpTV4YsWmc0n+'/ramadan2016/مصرية',11)
	return
def VCio1EXzNgM8WLmYbxtBdw():
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,yONJxHER9BIDPpTV4YsWmc0n,'',headers,True,'ALARAB-LATEST-1st')
	cWafzb4HoG1Em3Jwxu6C7vZsVi=u5h2Rckvw1E.findall('heading-top(.*?)div class=',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]+cWafzb4HoG1Em3Jwxu6C7vZsVi[1]
	items=u5h2Rckvw1E.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
		url = yONJxHER9BIDPpTV4YsWmc0n + ekTrZlFMu0Kf5QztEnhAs
		if 'series' in url: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,11,pGjsvdyHfM)
		else: uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,url,12,pGjsvdyHfM)
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'',headers,True,True,'ALARAB-TITLES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('video-category(.*?)right_content',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not cWafzb4HoG1Em3Jwxu6C7vZsVi: return
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	Hxpd2wePZUyLtJk1hm = False
	items = u5h2Rckvw1E.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	yn8DkpE5etF3WiUmfSO,UqAvrMlX2btuFSYIs7O3WohDR = [],[]
	for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
		if title=='': title = ekTrZlFMu0Kf5QztEnhAs.split('/')[-1].replace('-',' ')
		FFkUYlfHsK2W5VzbAZjMvmCSE43 = u5h2Rckvw1E.findall('(\d+)',title,u5h2Rckvw1E.DOTALL)
		if FFkUYlfHsK2W5VzbAZjMvmCSE43: FFkUYlfHsK2W5VzbAZjMvmCSE43 = int(FFkUYlfHsK2W5VzbAZjMvmCSE43[0])
		else: FFkUYlfHsK2W5VzbAZjMvmCSE43 = 0
		UqAvrMlX2btuFSYIs7O3WohDR.append([pGjsvdyHfM,ekTrZlFMu0Kf5QztEnhAs,title,FFkUYlfHsK2W5VzbAZjMvmCSE43])
	UqAvrMlX2btuFSYIs7O3WohDR = sorted(UqAvrMlX2btuFSYIs7O3WohDR, reverse=True, key=lambda key: key[3])
	for pGjsvdyHfM,ekTrZlFMu0Kf5QztEnhAs,title,FFkUYlfHsK2W5VzbAZjMvmCSE43 in UqAvrMlX2btuFSYIs7O3WohDR:
		ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n + ekTrZlFMu0Kf5QztEnhAs
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي','')
		title = title.replace('عالية على العرب','')
		title = title.replace('مشاهدة مباشرة','')
		title = title.replace('اون لاين','')
		title = title.replace('اونلاين','')
		title = title.replace('بجودة عالية','')
		title = title.replace('جودة عالية','')
		title = title.replace('بدون تحميل','')
		title = title.replace('على العرب','')
		title = title.replace('مباشرة','')
		title = title.strip(' ').replace('  ',' ').replace('  ',' ')
		title = '_MOD_'+title
		cMpjL2oavyVwKHBPn8EdhYqxSUk = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			zAjwuoRY98mXN6xvE = u5h2Rckvw1E.findall('(.*?) الحلقة \d+',title,u5h2Rckvw1E.DOTALL)
			if zAjwuoRY98mXN6xvE: cMpjL2oavyVwKHBPn8EdhYqxSUk = zAjwuoRY98mXN6xvE[0]
		if cMpjL2oavyVwKHBPn8EdhYqxSUk not in yn8DkpE5etF3WiUmfSO:
			yn8DkpE5etF3WiUmfSO.append(cMpjL2oavyVwKHBPn8EdhYqxSUk)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+cMpjL2oavyVwKHBPn8EdhYqxSUk,ekTrZlFMu0Kf5QztEnhAs,13,pGjsvdyHfM)
				Hxpd2wePZUyLtJk1hm = True
			elif 'series' in ekTrZlFMu0Kf5QztEnhAs:
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,11,pGjsvdyHfM)
				Hxpd2wePZUyLtJk1hm = True
			else:
				uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,12,pGjsvdyHfM)
				Hxpd2wePZUyLtJk1hm = True
	if Hxpd2wePZUyLtJk1hm:
		items = u5h2Rckvw1E.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,BzbaC0qYjMr2WXwsO in items:
			url = yONJxHER9BIDPpTV4YsWmc0n + ekTrZlFMu0Kf5QztEnhAs
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+BzbaC0qYjMr2WXwsO,url,11)
	return
def GA2KIlbOsoYtxpkDF71(url):
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,url,'',headers,True,'ALARAB-EPISODES-1st')
	UwQK685R0SpOCmVIagWJ = u5h2Rckvw1E.findall('href="(/series.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	gANn35esloKUydOipfSMC6RD2 = yONJxHER9BIDPpTV4YsWmc0n+UwQK685R0SpOCmVIagWJ[0]
	vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(gANn35esloKUydOipfSMC6RD2)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	EaBeVhOsHYg8wub = []
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(hs8IDEMn0YuCHwk,url,'',headers,True,'ALARAB-PLAY-1st')
	gANn35esloKUydOipfSMC6RD2 = u5h2Rckvw1E.findall('class="resp-iframe" src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if gANn35esloKUydOipfSMC6RD2:
		gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2[0]
		lQUf3AY258LeWch = u5h2Rckvw1E.findall('^(http.*?)(http.*?)$',gANn35esloKUydOipfSMC6RD2,u5h2Rckvw1E.DOTALL)
		if lQUf3AY258LeWch:
			mgka3ynHUhDN1 = lQUf3AY258LeWch[0][0]
			J4QjycNqT5oDh,PnqG6E59iMJKL0lN21QftmezByTvI = lQUf3AY258LeWch[0][1].rsplit('/',1)
			UcmHDPlLWaSf = J4QjycNqT5oDh+'?named=__watch'
			EaBeVhOsHYg8wub.append(UcmHDPlLWaSf)
			EvwpgrXHuA7nMDUz9RyGhaTOQJWZ = mgka3ynHUhDN1+PnqG6E59iMJKL0lN21QftmezByTvI
		else:
			ZCOosjaQ8x9HDKSVGM6LwW2vy = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,gANn35esloKUydOipfSMC6RD2,'',headers,False,'ALARAB-PLAY-2nd')
			gANn35esloKUydOipfSMC6RD2 = u5h2Rckvw1E.findall('"src": "(.*?)"',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)
			if gANn35esloKUydOipfSMC6RD2:
				gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2[0]+'?named=__watch__m3u8'
				EaBeVhOsHYg8wub.append(gANn35esloKUydOipfSMC6RD2)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('searchBox(.*?)<style>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		gANn35esloKUydOipfSMC6RD2 = u5h2Rckvw1E.findall('href="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if gANn35esloKUydOipfSMC6RD2:
			gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2[0]+'?named=__watch'
			EaBeVhOsHYg8wub.append(gANn35esloKUydOipfSMC6RD2)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(EaBeVhOsHYg8wub,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def IFuMBwgZdi9WScPXKVkfzp0NT7CYt():
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,yONJxHER9BIDPpTV4YsWmc0n,'',headers,True,'ALARAB-RAMADAN-1st')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('id="content_sec"(.*?)id="left_content"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	DUnm4AWcZLjuadqwG2lYO5rX = u5h2Rckvw1E.findall('/ramadan([0-9]+)/',str(items),u5h2Rckvw1E.DOTALL)
	DUnm4AWcZLjuadqwG2lYO5rX = DUnm4AWcZLjuadqwG2lYO5rX[0]
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		url = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
		title = title.strip(' ')+' '+DUnm4AWcZLjuadqwG2lYO5rX
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,11)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	GHFUMEOSrvhmIoVWxwN8j4 = search.replace(' ','+')
	url = yONJxHER9BIDPpTV4YsWmc0n + "/q/" + GHFUMEOSrvhmIoVWxwN8j4
	vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url)
	return
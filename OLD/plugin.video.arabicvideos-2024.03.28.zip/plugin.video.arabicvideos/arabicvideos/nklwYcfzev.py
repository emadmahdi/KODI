# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'CIMA4U'
headers = {'User-Agent':''}
tiCRYyX1bWd40Ir3PafQu = '_C4U_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==420: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==421: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,text)
	elif mode==422: vS7JufTVsBxw52 = xxWn9XKlJmchkHrLUMugIFySa7(url)
	elif mode==423: vS7JufTVsBxw52 = GA2KIlbOsoYtxpkDF71(url)
	elif mode==424: vS7JufTVsBxw52 = WYxFZIrRp6b(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: vS7JufTVsBxw52 = WYxFZIrRp6b(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==427: vS7JufTVsBxw52 = uNnmCz9ARldeY68B5x3WDrXTa(url)
	elif mode==429: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',yONJxHER9BIDPpTV4YsWmc0n,'','','','','CIMA4U-MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	jGX4sfdrWaeZpA1VyvTK = u5h2Rckvw1E.findall('href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	jGX4sfdrWaeZpA1VyvTK = jGX4sfdrWaeZpA1VyvTK[0].strip('/')
	jGX4sfdrWaeZpA1VyvTK = hmcFWJUgiAuGk(jGX4sfdrWaeZpA1VyvTK,'url')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',429,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فلتر محدد',jGX4sfdrWaeZpA1VyvTK,425)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فلتر كامل',jGX4sfdrWaeZpA1VyvTK,424)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'الرئيسية',jGX4sfdrWaeZpA1VyvTK,421)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('NavigationMenu(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('href="*(.*?)"*>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		if title in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
		if '/actors' in ekTrZlFMu0Kf5QztEnhAs: title = 'أفلام النجوم'
		elif '/netflix' in ekTrZlFMu0Kf5QztEnhAs: title = 'أفلام ومسلسلات نيتفلكس'
		uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,421)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'قائمة تفصيلية',jGX4sfdrWaeZpA1VyvTK,427)
	return
def uNnmCz9ARldeY68B5x3WDrXTa(website=''):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',yONJxHER9BIDPpTV4YsWmc0n,'','','','','CIMA4U-MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('FilteringTitle(.*?)PageTitle',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for oPrhaMp7AqmNnRjlXGI,id,ekTrZlFMu0Kf5QztEnhAs,title in items:
		if title in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
		if 'netflix-movies' in ekTrZlFMu0Kf5QztEnhAs: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in ekTrZlFMu0Kf5QztEnhAs: title = 'مسلسلات نيتفلكس'
		uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,421,'','',oPrhaMp7AqmNnRjlXGI+'|'+id)
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,lcOov4Kz0uBairTpLxXgAqIt72mk=''):
	if '/HomepageLoader/' in url: url = url.strip('/')+'/mpaa/family/'
	items = []
	jGX4sfdrWaeZpA1VyvTK = hmcFWJUgiAuGk(url,'url')
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'',headers,'','','CIMA4U-TITLES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	if not lcOov4Kz0uBairTpLxXgAqIt72mk or '|' in lcOov4Kz0uBairTpLxXgAqIt72mk:
		if '|' not in lcOov4Kz0uBairTpLxXgAqIt72mk: c5c6vKAfmYRFdboWkjNITMXt4EL = ''
		else: c5c6vKAfmYRFdboWkjNITMXt4EL = '/archive/'+lcOov4Kz0uBairTpLxXgAqIt72mk
		nngdtHAZwB5o = False
		if 'PinSlider' in oo9SgGkiDbs3HRn7z8:
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'المميزة',url,421,'','','featured')
			nngdtHAZwB5o = True
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('PageTitle(.*?)PageContent',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			CyEMW1Sh3GtsbRUzN = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			EbnzqW0GvY2dNMBpshU6fugi = u5h2Rckvw1E.findall('data-tab="(.*?)".*?<span>(.*?)<',CyEMW1Sh3GtsbRUzN,u5h2Rckvw1E.DOTALL)
			for JZkjCQTKr6cabO12g,cMpjL2oavyVwKHBPn8EdhYqxSUk in EbnzqW0GvY2dNMBpshU6fugi:
				olm59qifJbWpRsr1a3X7zBEIA = jGX4sfdrWaeZpA1VyvTK+'/ajaxcenter/action/HomepageLoader/tab/'+JZkjCQTKr6cabO12g+c5c6vKAfmYRFdboWkjNITMXt4EL+'/'
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+cMpjL2oavyVwKHBPn8EdhYqxSUk,olm59qifJbWpRsr1a3X7zBEIA,421)
				nngdtHAZwB5o = True
		if nngdtHAZwB5o: uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	if lcOov4Kz0uBairTpLxXgAqIt72mk=='featured':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('PinSlider(.*?)MultiFilter',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if not cWafzb4HoG1Em3Jwxu6C7vZsVi: cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('PinSlider(.*?)PageTitle',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi: lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		else: lmO2YJGr6tCV = ''
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		lmO2YJGr6tCV = oo9SgGkiDbs3HRn7z8
	elif '/filter/' in url:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('PageContent(.*?)class="*pagination"*',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	elif '/actors' in url:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('PageContent(.*?)class="*pagination"*',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	else:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('Cima4uBlocks(.*?)</li></ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi: lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		else: lmO2YJGr6tCV = ''
	if not items: items = u5h2Rckvw1E.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	if not items: items = u5h2Rckvw1E.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	yn8DkpE5etF3WiUmfSO = []
	for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
		if not title: continue
		if '?news=' in ekTrZlFMu0Kf5QztEnhAs: continue
		title = title.replace('مشاهدة ','')
		title = uTUNPkVwCMKiD5gHLaj(title)
		zAjwuoRY98mXN6xvE = u5h2Rckvw1E.findall('(.*?) حلقة \d+',title,u5h2Rckvw1E.DOTALL)
		if zAjwuoRY98mXN6xvE and 'حلقة' in title:
			title = '_MOD_' + zAjwuoRY98mXN6xvE[0]
			if title not in yn8DkpE5etF3WiUmfSO:
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,422,pGjsvdyHfM)
				yn8DkpE5etF3WiUmfSO.append(title)
		elif '/actor/' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,421,pGjsvdyHfM)
		else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,422,pGjsvdyHfM)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('pagination(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi and lcOov4Kz0uBairTpLxXgAqIt72mk!='featured':
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			title = uTUNPkVwCMKiD5gHLaj(title)
			title = title.replace('الصفحة ','')
			if title!='': uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+title,ekTrZlFMu0Kf5QztEnhAs,421)
	OUmHIFcEJsxtj = u5h2Rckvw1E.findall('</li><a href="(.*?)".*?>(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if OUmHIFcEJsxtj:
		ekTrZlFMu0Kf5QztEnhAs,title = OUmHIFcEJsxtj[0]
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,421)
	return
def xxWn9XKlJmchkHrLUMugIFySa7(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','CIMA4U-SEASONS-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="WatchNow".*?href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		url = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','CIMA4U-SEASONS-2nd')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('SeasonsSections(.*?)</div></div></div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if '/tag/' in url or '/actor' in url:
		ll0a2AwztChcpsDUMi4rGW3b61XZES(url)
	elif cWafzb4HoG1Em3Jwxu6C7vZsVi:
		pGjsvdyHfM = bMIascyFJ2x43E0C7glTB91h8qz.getInfoLabel('ListItem.Thumb')
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall("href='(.*?)'>(.*?)<",lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		SwvIg6ankRr1eGuK = ['مسلسل','موسم','برنامج','حلقة']
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if any(c2eEflztvIX in title for c2eEflztvIX in SwvIg6ankRr1eGuK):
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,423,pGjsvdyHfM)
			else: uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,426,pGjsvdyHfM)
	else: GA2KIlbOsoYtxpkDF71(url)
	return
def GA2KIlbOsoYtxpkDF71(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','CIMA4U-EPISODES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	pGjsvdyHfM = u5h2Rckvw1E.findall('"background-image:url\((.*?)\)',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if pGjsvdyHfM: pGjsvdyHfM = pGjsvdyHfM[0]
	else: pGjsvdyHfM = ''
	ZO5xPgV6Si8IuTa9sb = u5h2Rckvw1E.findall('EpisodesSection(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if ZO5xPgV6Si8IuTa9sb:
		lmO2YJGr6tCV = ZO5xPgV6Si8IuTa9sb[0]
		items = u5h2Rckvw1E.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title,zAjwuoRY98mXN6xvE in items:
			title = title+' '+zAjwuoRY98mXN6xvE
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,426,pGjsvdyHfM)
	else: uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+'رابط التشغيل',url,426,pGjsvdyHfM)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'',headers,'','','CIMA4U-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	Cy0zbfKMN8qQIpie9Pmg2Fw = RoQL91PphqCJg4W0e6Fnsl.url
	if bdptXFc8UlIhA5jnGwPmKuv2L: Cy0zbfKMN8qQIpie9Pmg2Fw = Cy0zbfKMN8qQIpie9Pmg2Fw.encode('utf8')
	jGX4sfdrWaeZpA1VyvTK = hmcFWJUgiAuGk(Cy0zbfKMN8qQIpie9Pmg2Fw,'url')
	EaBeVhOsHYg8wub = []
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('WatchSection(.*?)</div></div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('data-link="(.*?)".*? />(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for bbLlyzvIcPRU7e4pGBD,title in items:
			title = title.strip(' ')
			if 'myvid' in title.lower(): title = 'خاص '+title
			ekTrZlFMu0Kf5QztEnhAs = jGX4sfdrWaeZpA1VyvTK+'/structure/server.php?id='+bbLlyzvIcPRU7e4pGBD+'?named='+title+'__watch'
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.replace('\r','')
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('DownloadServers(.*?)</div></div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*? />(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			title = title.strip(' ')
			if 'myvid' in title.lower(): cMpjL2oavyVwKHBPn8EdhYqxSUk = '__خاص'
			else: cMpjL2oavyVwKHBPn8EdhYqxSUk = ''
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+title+'__download'+cMpjL2oavyVwKHBPn8EdhYqxSUk
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.replace('\r','')
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(EaBeVhOsHYg8wub,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	search = search.replace(' ','+')
	url = yONJxHER9BIDPpTV4YsWmc0n+'/Search?q='+search
	ll0a2AwztChcpsDUMi4rGW3b61XZES(url,'search')
	return
def C50mPGacMg7V34she6UR8LjfSt1(url):
	if 'smartemadfilter' not in url: url = hmcFWJUgiAuGk(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','CIMA4U-GET_FILTERS_BLOCKS-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('MultiFilter(.*?)PageTitle',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	cGdHRiwvptVXQlzE8ZUgB0aJo9x = u5h2Rckvw1E.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	return cGdHRiwvptVXQlzE8ZUgB0aJo9x
def zzsLCt0FpUQEeMoYWBqGlZJP6rn4(lmO2YJGr6tCV):
	items = u5h2Rckvw1E.findall('data-id="(.*?)".*?</div>(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	return items
def l9GNIMkR6FbWzpQZsYwEyAaU17v(url):
	TImV9B8wLag3trpRZWvAqQPN5 = url.split('/smartemadfilter?')[0]
	GDJeByAH5fRS9I = hmcFWJUgiAuGk(url,'url')
	url = url.replace(TImV9B8wLag3trpRZWvAqQPN5,GDJeByAH5fRS9I)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=','/').replace('&','/')
	url = url+'/'
	return url
BVNnjYeCa3AfgTv0u6R = ['category','types','release-year']
mwqMBcOe2Lj = ['Quality','release-year','types','category']
def WYxFZIrRp6b(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': lvUP2GeNjyVOHKJxcBoun3Z,MoELTBDgQeaJrl0zYUmKCH = '',''
	else: lvUP2GeNjyVOHKJxcBoun3Z,MoELTBDgQeaJrl0zYUmKCH = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global BVNnjYeCa3AfgTv0u6R
			BVNnjYeCa3AfgTv0u6R = BVNnjYeCa3AfgTv0u6R[1:]
		if BVNnjYeCa3AfgTv0u6R[0]+'=' not in lvUP2GeNjyVOHKJxcBoun3Z: oPrhaMp7AqmNnRjlXGI = BVNnjYeCa3AfgTv0u6R[0]
		for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(len(BVNnjYeCa3AfgTv0u6R[0:-1])):
			if BVNnjYeCa3AfgTv0u6R[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE]+'=' in lvUP2GeNjyVOHKJxcBoun3Z: oPrhaMp7AqmNnRjlXGI = BVNnjYeCa3AfgTv0u6R[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE+1]
		WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&'+oPrhaMp7AqmNnRjlXGI+'=0'
		z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&'+oPrhaMp7AqmNnRjlXGI+'=0'
		bIYSyA3BD1o4 = WGiMcqkRetEJVrSI.strip('&')+'___'+z3wGSEWqVy1Qh5N.strip('&')
		TBFfiRI52ZmKwO1JLSD = mltWBSPJz5H4VRdCAa1(MoELTBDgQeaJrl0zYUmKCH,'modified_filters')
		gANn35esloKUydOipfSMC6RD2 = url+'/smartemadfilter?'+TBFfiRI52ZmKwO1JLSD
	elif type=='ALL_ITEMS_FILTER':
		lv2uANOtVxE8RTa7bYHqLog1Bd = mltWBSPJz5H4VRdCAa1(lvUP2GeNjyVOHKJxcBoun3Z,'modified_values')
		lv2uANOtVxE8RTa7bYHqLog1Bd = P2o6ZDHeW790pSQqucvnxzILVUX(lv2uANOtVxE8RTa7bYHqLog1Bd)
		if MoELTBDgQeaJrl0zYUmKCH!='': MoELTBDgQeaJrl0zYUmKCH = mltWBSPJz5H4VRdCAa1(MoELTBDgQeaJrl0zYUmKCH,'modified_filters')
		if MoELTBDgQeaJrl0zYUmKCH=='': gANn35esloKUydOipfSMC6RD2 = url
		else: gANn35esloKUydOipfSMC6RD2 = url+'/smartemadfilter?'+MoELTBDgQeaJrl0zYUmKCH
		gANn35esloKUydOipfSMC6RD2 = l9GNIMkR6FbWzpQZsYwEyAaU17v(gANn35esloKUydOipfSMC6RD2)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'أظهار قائمة الفيديو التي تم اختيارها ',gANn35esloKUydOipfSMC6RD2,421,'','','filter')
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+' [[   '+lv2uANOtVxE8RTa7bYHqLog1Bd+'   ]]',gANn35esloKUydOipfSMC6RD2,421,'','','filter')
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cGdHRiwvptVXQlzE8ZUgB0aJo9x = C50mPGacMg7V34she6UR8LjfSt1(url)
	dict = {}
	for name,lmO2YJGr6tCV,Uiy0XwPusDg4vAFc35oYdfGnOrV in cGdHRiwvptVXQlzE8ZUgB0aJo9x:
		if '/category/' in url and Uiy0XwPusDg4vAFc35oYdfGnOrV=='category': continue
		name = name.replace('--','')
		items = zzsLCt0FpUQEeMoYWBqGlZJP6rn4(lmO2YJGr6tCV)
		if '=' not in gANn35esloKUydOipfSMC6RD2: gANn35esloKUydOipfSMC6RD2 = url
		if type=='SPECIFIED_FILTER':
			if oPrhaMp7AqmNnRjlXGI!=Uiy0XwPusDg4vAFc35oYdfGnOrV: continue
			elif len(items)<2:
				if Uiy0XwPusDg4vAFc35oYdfGnOrV==BVNnjYeCa3AfgTv0u6R[-1]:
					url = l9GNIMkR6FbWzpQZsYwEyAaU17v(url)
					ll0a2AwztChcpsDUMi4rGW3b61XZES(url)
				else: WYxFZIrRp6b(gANn35esloKUydOipfSMC6RD2,'SPECIFIED_FILTER___'+bIYSyA3BD1o4)
				return
			else:
				gANn35esloKUydOipfSMC6RD2 = l9GNIMkR6FbWzpQZsYwEyAaU17v(gANn35esloKUydOipfSMC6RD2)
				if Uiy0XwPusDg4vAFc35oYdfGnOrV==BVNnjYeCa3AfgTv0u6R[-1]: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع',gANn35esloKUydOipfSMC6RD2,421,'','','filter')
				else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع',gANn35esloKUydOipfSMC6RD2,425,'','',bIYSyA3BD1o4)
		elif type=='ALL_ITEMS_FILTER':
			WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'=0'
			z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'=0'
			bIYSyA3BD1o4 = WGiMcqkRetEJVrSI+'___'+z3wGSEWqVy1Qh5N
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع :'+name,gANn35esloKUydOipfSMC6RD2,424,'','',bIYSyA3BD1o4)
		dict[Uiy0XwPusDg4vAFc35oYdfGnOrV] = {}
		for c2eEflztvIX,q1rVywkMcKftIioS43LY in items:
			if c2eEflztvIX=='196533': q1rVywkMcKftIioS43LY = 'أفلام نيتفلكس'
			elif c2eEflztvIX=='196531': q1rVywkMcKftIioS43LY = 'مسلسلات نيتفلكس'
			if q1rVywkMcKftIioS43LY in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
			dict[Uiy0XwPusDg4vAFc35oYdfGnOrV][c2eEflztvIX] = q1rVywkMcKftIioS43LY
			WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'='+q1rVywkMcKftIioS43LY
			z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'='+c2eEflztvIX
			eoaO40TC7VF1tEuwjQp2x = WGiMcqkRetEJVrSI+'___'+z3wGSEWqVy1Qh5N
			title = q1rVywkMcKftIioS43LY+' :'#+dict[Uiy0XwPusDg4vAFc35oYdfGnOrV]['0']
			title = q1rVywkMcKftIioS43LY+' :'+name
			if type=='ALL_ITEMS_FILTER': uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,424,'','',eoaO40TC7VF1tEuwjQp2x)
			elif type=='SPECIFIED_FILTER' and BVNnjYeCa3AfgTv0u6R[-2]+'=' in lvUP2GeNjyVOHKJxcBoun3Z:
				TBFfiRI52ZmKwO1JLSD = mltWBSPJz5H4VRdCAa1(z3wGSEWqVy1Qh5N,'modified_filters')
				UcmHDPlLWaSf = url+'/smartemadfilter?'+TBFfiRI52ZmKwO1JLSD
				UcmHDPlLWaSf = l9GNIMkR6FbWzpQZsYwEyAaU17v(UcmHDPlLWaSf)
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,UcmHDPlLWaSf,421,'','','filter')
			else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,425,'','',eoaO40TC7VF1tEuwjQp2x)
	return
def mltWBSPJz5H4VRdCAa1(cGYIMSHDj85d3f4ZW2t0bnNkKP,mode):
	cGYIMSHDj85d3f4ZW2t0bnNkKP = cGYIMSHDj85d3f4ZW2t0bnNkKP.replace('=&','=0&')
	cGYIMSHDj85d3f4ZW2t0bnNkKP = cGYIMSHDj85d3f4ZW2t0bnNkKP.strip('&')
	OXjBliFSwIQCmg47 = {}
	if '=' in cGYIMSHDj85d3f4ZW2t0bnNkKP:
		items = cGYIMSHDj85d3f4ZW2t0bnNkKP.split('&')
		for TMaJdc0xOFKNf in items:
			b1EWu6sYaRk0FXUx8HVvNBQort43,c2eEflztvIX = TMaJdc0xOFKNf.split('=')
			OXjBliFSwIQCmg47[b1EWu6sYaRk0FXUx8HVvNBQort43] = c2eEflztvIX
	LL3oamJbwkYcNDrH5 = ''
	for key in mwqMBcOe2Lj:
		if key in list(OXjBliFSwIQCmg47.keys()): c2eEflztvIX = OXjBliFSwIQCmg47[key]
		else: c2eEflztvIX = '0'
		if '%' not in c2eEflztvIX: c2eEflztvIX = QQXTVNve6DMHBp4scG170kR2lWY(c2eEflztvIX)
		if mode=='modified_values' and c2eEflztvIX!='0': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+' + '+c2eEflztvIX
		elif mode=='modified_filters' and c2eEflztvIX!='0': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+'&'+key+'='+c2eEflztvIX
		elif mode=='all': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+'&'+key+'='+c2eEflztvIX
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.strip(' + ')
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.strip('&')
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.replace('=0','=')
	return LL3oamJbwkYcNDrH5
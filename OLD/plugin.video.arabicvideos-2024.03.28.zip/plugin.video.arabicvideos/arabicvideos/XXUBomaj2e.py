# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'YOUTUBE'
tiCRYyX1bWd40Ir3PafQu = '_YUT_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text,type,BzbaC0qYjMr2WXwsO):
	if	 mode==140: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==143: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url,type)
	elif mode==144: vS7JufTVsBxw52 = tZwPW2bEz6S0OLXK84IjDYFqkde(url,text,BzbaC0qYjMr2WXwsO)
	elif mode==145: vS7JufTVsBxw52 = fa7kLtYT91BbFHiDh4UqWPK(url)
	elif mode==146: vS7JufTVsBxw52 = PvQ8SIVrDTuOUqpne(url)
	elif mode==147: vS7JufTVsBxw52 = i35iGPxr0dtX1jNl268Uz9C()
	elif mode==148: vS7JufTVsBxw52 = T3TUfali2jrzHD()
	elif mode==149: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',149,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+'_YTC_'+'مواقع اختارها المبرمج','',290)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'مواقع اختارها يوتيوب',yONJxHER9BIDPpTV4YsWmc0n+'/feed/guide_builder',144)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'الصفحة الرئيسية',yONJxHER9BIDPpTV4YsWmc0n,144,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'المحتوى الرائج',yONJxHER9BIDPpTV4YsWmc0n+'/feed/trending',146)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'بحث: قنوات عربية','',147)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'بحث: قنوات أجنبية','',148)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'بحث: افلام عربية',yONJxHER9BIDPpTV4YsWmc0n+'/results?search_query=فيلم',144)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'بحث: افلام اجنبية',yONJxHER9BIDPpTV4YsWmc0n+'/results?search_query=movie',144)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'بحث: مسرحيات عربية',yONJxHER9BIDPpTV4YsWmc0n+'/results?search_query=مسرحية',144)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'بحث: مسلسلات عربية',yONJxHER9BIDPpTV4YsWmc0n+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'بحث: مسلسلات اجنبية',yONJxHER9BIDPpTV4YsWmc0n+'/results?search_query=series&sp=EgIQAw==',144)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'بحث: مسلسلات كارتون',yONJxHER9BIDPpTV4YsWmc0n+'/results?search_query=كارتون&sp=EgIQAw==',144)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'بحث: خطبة المرجعية',yONJxHER9BIDPpTV4YsWmc0n+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def i35iGPxr0dtX1jNl268Uz9C():
	tZwPW2bEz6S0OLXK84IjDYFqkde(yONJxHER9BIDPpTV4YsWmc0n+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def T3TUfali2jrzHD():
	tZwPW2bEz6S0OLXK84IjDYFqkde(yONJxHER9BIDPpTV4YsWmc0n+'/results?search_query=tv&sp=EgJAAQ==')
	return
def N5AOlmb8u1y4FHxvJXU(url,type):
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr([url],aUVSgO2ebjwX5iqPykC,type,url)
	return
def PvQ8SIVrDTuOUqpne(url):
	oo9SgGkiDbs3HRn7z8,BVYESNuJMxlmDo5WXdaFP6r,data = p0aw4UgTIeO5Pv92XZCkJcDNlu(url)
	uN0nKcIMbtCPa5zymqL = BVYESNuJMxlmDo5WXdaFP6r['contents']['twoColumnBrowseResultsRenderer']['tabs']
	for k0G4LTYt93po in range(len(uN0nKcIMbtCPa5zymqL)):
		TMaJdc0xOFKNf = uN0nKcIMbtCPa5zymqL[k0G4LTYt93po]
		ClLwQZGizU1IVYmDydTAfFqkxJE(TMaJdc0xOFKNf,url,str(k0G4LTYt93po))
	pXS1wt0h6LNW4jeEP7 = uN0nKcIMbtCPa5zymqL[0]['tabRenderer']['content']['sectionListRenderer']['contents']
	OrmQMGb3tkJun1LwaTY8SZW7 = 0
	for k0G4LTYt93po in range(len(pXS1wt0h6LNW4jeEP7)):
		TMaJdc0xOFKNf = pXS1wt0h6LNW4jeEP7[k0G4LTYt93po]['itemSectionRenderer']['contents'][0]
		if list(TMaJdc0xOFKNf['shelfRenderer']['content'].keys())[0]=='horizontalListRenderer': continue
		JJG0EdY1NQXfSRwm,title,ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,count,vNbeHULAy6gc4iE,ssynRZt81lpVjmFk,JJjdqk87RSrNfTD9BzixM = U1UI9JX6HdbYza7t4rZSP(TMaJdc0xOFKNf)
		if not title:
			OrmQMGb3tkJun1LwaTY8SZW7 += 1
			title = 'فيديوهات رائجة '+str(OrmQMGb3tkJun1LwaTY8SZW7)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,144,'',str(k0G4LTYt93po))
	key = u5h2Rckvw1E.findall('"innertubeApiKey":"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	gANn35esloKUydOipfSMC6RD2 = 'https://www.youtube.com/youtubei/v1/guide?key='+key[0]
	oo9SgGkiDbs3HRn7z8,BVYESNuJMxlmDo5WXdaFP6r,XfOb4VIcPY = p0aw4UgTIeO5Pv92XZCkJcDNlu(gANn35esloKUydOipfSMC6RD2)
	for dMAitcV9p76wr5CDW0G1eIX in range(3,4):
		uN0nKcIMbtCPa5zymqL = BVYESNuJMxlmDo5WXdaFP6r['items'][dMAitcV9p76wr5CDW0G1eIX]['guideSectionRenderer']['items']
		for k0G4LTYt93po in range(len(uN0nKcIMbtCPa5zymqL)):
			TMaJdc0xOFKNf = uN0nKcIMbtCPa5zymqL[k0G4LTYt93po]
			if 'YouTube Premium' in str(TMaJdc0xOFKNf): continue
			ClLwQZGizU1IVYmDydTAfFqkxJE(TMaJdc0xOFKNf)
	return
def tZwPW2bEz6S0OLXK84IjDYFqkde(url,data='',index=0):
	global LLwCINEyZT9GHP7QMA1VlukcDjh
	if not data: data = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.youtube.data')
	if index: index = int(index)
	else: index = 0
	data = data.replace('_REMEMBERRESULTS_','')
	oo9SgGkiDbs3HRn7z8,BVYESNuJMxlmDo5WXdaFP6r,XfOb4VIcPY = p0aw4UgTIeO5Pv92XZCkJcDNlu(url,data)
	zawKLhDJey6dvZxo,GxTbuoaplM2eO = '',''
	FRov4fbHu7K = u5h2Rckvw1E.findall('"ownerName".*?":"(.*?)".*?"url":"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not FRov4fbHu7K: FRov4fbHu7K = u5h2Rckvw1E.findall('"videoOwner".*?"text":"(.*?)".*?"url":"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not FRov4fbHu7K: FRov4fbHu7K = u5h2Rckvw1E.findall('"channelMetadataRenderer":\{"title":"(.*?)".*?"ownerUrls":\["(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if FRov4fbHu7K:
		zawKLhDJey6dvZxo = '[COLOR FFC89008]'+FRov4fbHu7K[0][0]+'[/COLOR]'
		ekTrZlFMu0Kf5QztEnhAs = FRov4fbHu7K[0][1]
		if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
		if 'list=' in url: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+zawKLhDJey6dvZxo,ekTrZlFMu0Kf5QztEnhAs,144)
	YrFRyobLkpjidaGXTZW1g = ['/search','/videos','/channels','/playlists','/featured','ss=','ctoken=','key=','bp=','shelf_id=']
	Ld0RxliAfG7QI = not any(c2eEflztvIX in url for c2eEflztvIX in YrFRyobLkpjidaGXTZW1g)
	if Ld0RxliAfG7QI and zawKLhDJey6dvZxo:
		OzY3XIhgiZJsGHMkKmSj = 'البحث'
		cMpjL2oavyVwKHBPn8EdhYqxSUk = 'قوائم التشغيل'
		qOECRifjx9rLg0MDk = 'الفيديوهات'
		UY2aIHbc58sv3 = 'القنوات'
		uQNUfbZx9yj0F('link',tiCRYyX1bWd40Ir3PafQu+zawKLhDJey6dvZxo,url,9999)
		if '"title":"بحث"' in oo9SgGkiDbs3HRn7z8: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+OzY3XIhgiZJsGHMkKmSj,url,145,'','','_REMEMBERRESULTS_')
		if '"title":"قوائم التشغيل"' in oo9SgGkiDbs3HRn7z8: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+cMpjL2oavyVwKHBPn8EdhYqxSUk,url+'/playlists',144)
		if '"title":"الفيديوهات"' in oo9SgGkiDbs3HRn7z8: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+qOECRifjx9rLg0MDk,url+'/videos',144)
		if '"title":"القنوات"' in oo9SgGkiDbs3HRn7z8: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+UY2aIHbc58sv3,url+'/channels',144)
		if '"title":"Search"' in oo9SgGkiDbs3HRn7z8: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+OzY3XIhgiZJsGHMkKmSj,url,145,'','','_REMEMBERRESULTS_')
		if '"title":"Playlists"' in oo9SgGkiDbs3HRn7z8: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+cMpjL2oavyVwKHBPn8EdhYqxSUk,url+'/playlists',144)
		if '"title":"Videos"' in oo9SgGkiDbs3HRn7z8: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+qOECRifjx9rLg0MDk,url+'/videos',144)
		if '"title":"Channels"' in oo9SgGkiDbs3HRn7z8: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+UY2aIHbc58sv3,url+'/channels',144)
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	if 'search_query' in url:
		uN0nKcIMbtCPa5zymqL = BVYESNuJMxlmDo5WXdaFP6r['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']
		vY3LeTCrjPuo4B = 0
		for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(len(uN0nKcIMbtCPa5zymqL)):
			if 'itemSectionRenderer' in list(uN0nKcIMbtCPa5zymqL[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE].keys()):
				lJ67PapxScj8ybZDduQn4oEgN92XY = uN0nKcIMbtCPa5zymqL[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE]['itemSectionRenderer']
				o7fQkCxH9djRYJlsFI = len(str(lJ67PapxScj8ybZDduQn4oEgN92XY))
				if o7fQkCxH9djRYJlsFI>vY3LeTCrjPuo4B:
					vY3LeTCrjPuo4B = o7fQkCxH9djRYJlsFI
					GxTbuoaplM2eO = lJ67PapxScj8ybZDduQn4oEgN92XY
		if vY3LeTCrjPuo4B==0: return
	elif '&list=' in url or '/search?key=' in url or '/browse?key=' in url or 'ctoken=' in url or '/search' in url or url==yONJxHER9BIDPpTV4YsWmc0n:
		QuMmSnj1FDg7YUysd0AbWE = []
		QuMmSnj1FDg7YUysd0AbWE.append("cc['onResponseReceivedCommands'][0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']")
		QuMmSnj1FDg7YUysd0AbWE.append("cc['onResponseReceivedActions'][0]['appendContinuationItemsAction']['continuationItems']")
		QuMmSnj1FDg7YUysd0AbWE.append("cc[1]['response']['continuationContents']['sectionListContinuation']")
		QuMmSnj1FDg7YUysd0AbWE.append("cc[1]['response']['continuationContents']['gridContinuation']['items']")
		QuMmSnj1FDg7YUysd0AbWE.append("cc[1]['response']['continuationContents']['playlistVideoListContinuation']")
		QuMmSnj1FDg7YUysd0AbWE.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][-1]['expandableTabRenderer']['content']['sectionListRenderer']")
		QuMmSnj1FDg7YUysd0AbWE.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']")
		QuMmSnj1FDg7YUysd0AbWE.append("cc['contents']['twoColumnWatchNextResults']['playlist']['playlist']")
		GChtc1NdTj723g6rDopZWU0PzFuxS,GxTbuoaplM2eO = QD6m7VECvAWiPqaSg(BVYESNuJMxlmDo5WXdaFP6r,'',QuMmSnj1FDg7YUysd0AbWE)
	if not GxTbuoaplM2eO:
		try:
			uN0nKcIMbtCPa5zymqL = BVYESNuJMxlmDo5WXdaFP6r['contents']['twoColumnBrowseResultsRenderer']['tabs']
			m0whqS5EkyiTjOIpvKZPM87r6 = '/videos' in url or '/playlists' in url or '/channels' in url
			hFTGbvlHqymR8pZKDU = '"title":"الفيديوهات"' in oo9SgGkiDbs3HRn7z8 or '"title":"قوائم التشغيل"' in oo9SgGkiDbs3HRn7z8 or '"title":"القنوات"' in oo9SgGkiDbs3HRn7z8
			NNodXgI8jastz1L7UerxYHZwTqk = '"title":"Videos"' in oo9SgGkiDbs3HRn7z8 or '"title":"Playlists"' in oo9SgGkiDbs3HRn7z8 or '"title":"Channels"' in oo9SgGkiDbs3HRn7z8
			if m0whqS5EkyiTjOIpvKZPM87r6 and (hFTGbvlHqymR8pZKDU or NNodXgI8jastz1L7UerxYHZwTqk):
				for k0G4LTYt93po in range(len(uN0nKcIMbtCPa5zymqL)):
					if 'tabRenderer' not in list(uN0nKcIMbtCPa5zymqL[k0G4LTYt93po].keys()): continue
					pXS1wt0h6LNW4jeEP7 = uN0nKcIMbtCPa5zymqL[k0G4LTYt93po]['tabRenderer']
					try: GxfFOvgHytjer5CPnBQszco = pXS1wt0h6LNW4jeEP7['content']['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems'][k0G4LTYt93po]
					except: GxfFOvgHytjer5CPnBQszco = pXS1wt0h6LNW4jeEP7
					try: ekTrZlFMu0Kf5QztEnhAs = GxfFOvgHytjer5CPnBQszco['endpoint']['commandMetadata']['webCommandMetadata']['url']
					except: continue
					if   '/videos'		in ekTrZlFMu0Kf5QztEnhAs	and '/videos'		in url: pXS1wt0h6LNW4jeEP7 = uN0nKcIMbtCPa5zymqL[k0G4LTYt93po] ; break
					elif '/playlists'	in ekTrZlFMu0Kf5QztEnhAs	and '/playlists'	in url: pXS1wt0h6LNW4jeEP7 = uN0nKcIMbtCPa5zymqL[k0G4LTYt93po] ; break
					elif '/channels'	in ekTrZlFMu0Kf5QztEnhAs	and '/channels'		in url: pXS1wt0h6LNW4jeEP7 = uN0nKcIMbtCPa5zymqL[k0G4LTYt93po] ; break
					else: pXS1wt0h6LNW4jeEP7 = uN0nKcIMbtCPa5zymqL[0]
			elif 'bp=' in url: pXS1wt0h6LNW4jeEP7 = uN0nKcIMbtCPa5zymqL[index]
			else: pXS1wt0h6LNW4jeEP7 = uN0nKcIMbtCPa5zymqL[0]
			GxTbuoaplM2eO = pXS1wt0h6LNW4jeEP7['tabRenderer']['content']
		except: pass
	if not GxTbuoaplM2eO: return
	QuMmSnj1FDg7YUysd0AbWE = []
	QuMmSnj1FDg7YUysd0AbWE.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	QuMmSnj1FDg7YUysd0AbWE.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	QuMmSnj1FDg7YUysd0AbWE.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	QuMmSnj1FDg7YUysd0AbWE.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	QuMmSnj1FDg7YUysd0AbWE.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['cards']")
	QuMmSnj1FDg7YUysd0AbWE.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	QuMmSnj1FDg7YUysd0AbWE.append("ff['sectionListRenderer']['contents'][int(index)]['richSectionRenderer']['content']")
	if 'view=' not in url: QuMmSnj1FDg7YUysd0AbWE.append("ff['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems']")
	QuMmSnj1FDg7YUysd0AbWE.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	QuMmSnj1FDg7YUysd0AbWE.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	QuMmSnj1FDg7YUysd0AbWE.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	QuMmSnj1FDg7YUysd0AbWE.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	QuMmSnj1FDg7YUysd0AbWE.append("ff['sectionListRenderer']['contents']")
	QuMmSnj1FDg7YUysd0AbWE.append("ff['sectionListRenderer']")
	QuMmSnj1FDg7YUysd0AbWE.append("ff['richGridRenderer']['contents']")
	QuMmSnj1FDg7YUysd0AbWE.append("ff['contents']")
	QuMmSnj1FDg7YUysd0AbWE.append("ff")
	Vwks790B1WaMbmYZSeHqLEP = XSuCEhVPZvBIfwyFjipYaRks0(u'كل قوائم التشغيل')
	HF1rON7ZYuJ0Usmdk6leDovtIi = XSuCEhVPZvBIfwyFjipYaRks0(u'كل الفيديوهات')
	jCiwB7ysXUMODrg6 = XSuCEhVPZvBIfwyFjipYaRks0(u'كل القنوات')
	HJZuyoN81j6A2 = [Vwks790B1WaMbmYZSeHqLEP,HF1rON7ZYuJ0Usmdk6leDovtIi,jCiwB7ysXUMODrg6,'All playlists','All videos','All channels']
	UzBD8bqRhftGAClaKEQP,GxfFOvgHytjer5CPnBQszco = QD6m7VECvAWiPqaSg(GxTbuoaplM2eO,index,QuMmSnj1FDg7YUysd0AbWE)
	if 'list' in str(type(GxfFOvgHytjer5CPnBQszco)) and any(c2eEflztvIX in str(GxfFOvgHytjer5CPnBQszco[0]) for c2eEflztvIX in HJZuyoN81j6A2): del GxfFOvgHytjer5CPnBQszco[0]
	for AApLx5QJvGswtVh9lFDNKZ2y1PSbOr in range(len(GxfFOvgHytjer5CPnBQszco)):
		QuMmSnj1FDg7YUysd0AbWE = []
		QuMmSnj1FDg7YUysd0AbWE.append("gg[index2]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
		QuMmSnj1FDg7YUysd0AbWE.append("gg[index2]['itemSectionRenderer']['header']")
		QuMmSnj1FDg7YUysd0AbWE.append("gg[index2]['horizontalCardListRenderer']['header']")
		QuMmSnj1FDg7YUysd0AbWE.append("gg[index2]['itemSectionRenderer']['contents'][0]")
		QuMmSnj1FDg7YUysd0AbWE.append("gg[index2]['richSectionRenderer']['content']")
		QuMmSnj1FDg7YUysd0AbWE.append("gg[index2]['richItemRenderer']['content']")
		QuMmSnj1FDg7YUysd0AbWE.append("gg[index2]['gameCardRenderer']['game']")
		QuMmSnj1FDg7YUysd0AbWE.append("gg[index2]")
		GChtc1NdTj723g6rDopZWU0PzFuxS,TMaJdc0xOFKNf = QD6m7VECvAWiPqaSg(GxfFOvgHytjer5CPnBQszco,AApLx5QJvGswtVh9lFDNKZ2y1PSbOr,QuMmSnj1FDg7YUysd0AbWE)
		ClLwQZGizU1IVYmDydTAfFqkxJE(TMaJdc0xOFKNf,url,str(AApLx5QJvGswtVh9lFDNKZ2y1PSbOr))
		if GChtc1NdTj723g6rDopZWU0PzFuxS=='4':
			try:
				PZ1fhUy6F53YsGHCwMbkvgKj2 = TMaJdc0xOFKNf['shelfRenderer']['content']['horizontalMovieListRenderer']['items']
				for cf34hOSkPbyeIK29x5Xu in range(len(PZ1fhUy6F53YsGHCwMbkvgKj2)):
					aE1d6CrXtHQNwVj07pzm5vR = PZ1fhUy6F53YsGHCwMbkvgKj2[cf34hOSkPbyeIK29x5Xu]
					ClLwQZGizU1IVYmDydTAfFqkxJE(aE1d6CrXtHQNwVj07pzm5vR)
			except: pass
	wanHtPNKCfxdoyLFQV3j2RrSmvpBZ = False
	if 'view=' not in url and UzBD8bqRhftGAClaKEQP=='8': wanHtPNKCfxdoyLFQV3j2RrSmvpBZ = True
	if ':::' in XfOb4VIcPY: ea0MVzhDifcQnxt,key,hzpImM2tD9gaKZdV1,oufJnhglF8iLZHKUAxRp,dh1veN6mVBg7pQ,tX4O1q5ICGu9n8mMYZHwF = XfOb4VIcPY.split(':::')
	else: ea0MVzhDifcQnxt,key,hzpImM2tD9gaKZdV1,oufJnhglF8iLZHKUAxRp,dh1veN6mVBg7pQ,tX4O1q5ICGu9n8mMYZHwF = '','','','','',''
	gANn35esloKUydOipfSMC6RD2,LTIzl7GJ3StWsN = '',''
	if YD56nkJmsd:
		uQbnLdBJygHXIWOva9G2DM1fSN = str(YD56nkJmsd[-1][1])
		if   tiCRYyX1bWd40Ir3PafQu+'CHNL' in uQbnLdBJygHXIWOva9G2DM1fSN: LTIzl7GJ3StWsN = 'CHANNELS'
		elif tiCRYyX1bWd40Ir3PafQu+'USER' in uQbnLdBJygHXIWOva9G2DM1fSN: LTIzl7GJ3StWsN = 'CHANNELS'
		elif tiCRYyX1bWd40Ir3PafQu+'LIST' in uQbnLdBJygHXIWOva9G2DM1fSN: LTIzl7GJ3StWsN = 'PLAYLISTS'
	if '"continuations"' in oo9SgGkiDbs3HRn7z8 and '&list=' not in url and not wanHtPNKCfxdoyLFQV3j2RrSmvpBZ and 'shelf_id' not in url:
		gANn35esloKUydOipfSMC6RD2 = yONJxHER9BIDPpTV4YsWmc0n+'/browse_ajax?ctoken='+hzpImM2tD9gaKZdV1
	elif '"token"' in oo9SgGkiDbs3HRn7z8 and 'bp=' not in url and 'search_query' in url or 'search?key=' in url:
		gANn35esloKUydOipfSMC6RD2 = yONJxHER9BIDPpTV4YsWmc0n+'/youtubei/v1/search?key='+key
	elif '"token"' in oo9SgGkiDbs3HRn7z8 and 'bp=' not in url:
		gANn35esloKUydOipfSMC6RD2 = yONJxHER9BIDPpTV4YsWmc0n+'/youtubei/v1/browse?key='+key
	if gANn35esloKUydOipfSMC6RD2: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة أخرى',gANn35esloKUydOipfSMC6RD2,144,LTIzl7GJ3StWsN,'',XfOb4VIcPY)
	return
def QD6m7VECvAWiPqaSg(riQnIlkHK86L4PSM,mOTzUAv73S1yDHg,gIpEL7clt4P8CFzSosihR):
	BVYESNuJMxlmDo5WXdaFP6r = riQnIlkHK86L4PSM
	GxTbuoaplM2eO,index = riQnIlkHK86L4PSM,mOTzUAv73S1yDHg
	GxfFOvgHytjer5CPnBQszco,AApLx5QJvGswtVh9lFDNKZ2y1PSbOr = riQnIlkHK86L4PSM,mOTzUAv73S1yDHg
	TMaJdc0xOFKNf,EEdPXSD45WZw2eYaB36qJ = riQnIlkHK86L4PSM,mOTzUAv73S1yDHg
	count = len(gIpEL7clt4P8CFzSosihR)
	for k0G4LTYt93po in range(count):
		try:
			f0QDK67Ctxg3 = eval(gIpEL7clt4P8CFzSosihR[k0G4LTYt93po])
			return str(k0G4LTYt93po+1),f0QDK67Ctxg3
		except: pass
	return '',''
def U1UI9JX6HdbYza7t4rZSP(TMaJdc0xOFKNf):
	try: Yiw73zqpMdXT8A0PmLUSDVQ6a9N4jZ = list(TMaJdc0xOFKNf.keys())[0]
	except: return False,'','','','','','',''
	JJG0EdY1NQXfSRwm,title,ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,count,vNbeHULAy6gc4iE,ssynRZt81lpVjmFk,JJjdqk87RSrNfTD9BzixM = False,'','','','','','',''
	EEdPXSD45WZw2eYaB36qJ = TMaJdc0xOFKNf[Yiw73zqpMdXT8A0PmLUSDVQ6a9N4jZ]
	QuMmSnj1FDg7YUysd0AbWE = []
	QuMmSnj1FDg7YUysd0AbWE.append("render['unplayableText']['simpleText']")
	QuMmSnj1FDg7YUysd0AbWE.append("render['formattedTitle']['simpleText']")
	QuMmSnj1FDg7YUysd0AbWE.append("render['title']['simpleText']")
	QuMmSnj1FDg7YUysd0AbWE.append("render['title']['runs'][0]['text']")
	QuMmSnj1FDg7YUysd0AbWE.append("render['text']['simpleText']")
	QuMmSnj1FDg7YUysd0AbWE.append("render['text']['runs'][0]['text']")
	QuMmSnj1FDg7YUysd0AbWE.append("render['title']")
	QuMmSnj1FDg7YUysd0AbWE.append("item['title']")
	GChtc1NdTj723g6rDopZWU0PzFuxS,title = QD6m7VECvAWiPqaSg(TMaJdc0xOFKNf,EEdPXSD45WZw2eYaB36qJ,QuMmSnj1FDg7YUysd0AbWE)
	QuMmSnj1FDg7YUysd0AbWE = []
	QuMmSnj1FDg7YUysd0AbWE.append("render['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	QuMmSnj1FDg7YUysd0AbWE.append("render['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	QuMmSnj1FDg7YUysd0AbWE.append("render['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	QuMmSnj1FDg7YUysd0AbWE.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	GChtc1NdTj723g6rDopZWU0PzFuxS,ekTrZlFMu0Kf5QztEnhAs = QD6m7VECvAWiPqaSg(TMaJdc0xOFKNf,EEdPXSD45WZw2eYaB36qJ,QuMmSnj1FDg7YUysd0AbWE)
	QuMmSnj1FDg7YUysd0AbWE = []
	QuMmSnj1FDg7YUysd0AbWE.append("render['thumbnail']['thumbnails'][0]['url']")
	QuMmSnj1FDg7YUysd0AbWE.append("render['thumbnails'][0]['thumbnails'][0]['url']")
	GChtc1NdTj723g6rDopZWU0PzFuxS,pGjsvdyHfM = QD6m7VECvAWiPqaSg(TMaJdc0xOFKNf,EEdPXSD45WZw2eYaB36qJ,QuMmSnj1FDg7YUysd0AbWE)
	QuMmSnj1FDg7YUysd0AbWE = []
	QuMmSnj1FDg7YUysd0AbWE.append("render['videoCount']")
	QuMmSnj1FDg7YUysd0AbWE.append("render['videoCountText']['runs'][0]['text']")
	QuMmSnj1FDg7YUysd0AbWE.append("render['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	GChtc1NdTj723g6rDopZWU0PzFuxS,count = QD6m7VECvAWiPqaSg(TMaJdc0xOFKNf,EEdPXSD45WZw2eYaB36qJ,QuMmSnj1FDg7YUysd0AbWE)
	QuMmSnj1FDg7YUysd0AbWE = []
	QuMmSnj1FDg7YUysd0AbWE.append("render['lengthText']['simpleText']")
	QuMmSnj1FDg7YUysd0AbWE.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	QuMmSnj1FDg7YUysd0AbWE.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	GChtc1NdTj723g6rDopZWU0PzFuxS,vNbeHULAy6gc4iE = QD6m7VECvAWiPqaSg(TMaJdc0xOFKNf,EEdPXSD45WZw2eYaB36qJ,QuMmSnj1FDg7YUysd0AbWE)
	if 'LIVE' in vNbeHULAy6gc4iE: vNbeHULAy6gc4iE,ssynRZt81lpVjmFk = '','LIVE:  '
	if 'مباشر' in vNbeHULAy6gc4iE: vNbeHULAy6gc4iE,ssynRZt81lpVjmFk = '','LIVE:  '
	if 'badges' in list(EEdPXSD45WZw2eYaB36qJ.keys()):
		xxUdv3DQoWAlIBEcbsfNhuJ1qka09L = str(EEdPXSD45WZw2eYaB36qJ['badges'])
		if 'Free with Ads' in xxUdv3DQoWAlIBEcbsfNhuJ1qka09L: JJjdqk87RSrNfTD9BzixM = '$:'
		if 'LIVE NOW' in xxUdv3DQoWAlIBEcbsfNhuJ1qka09L: ssynRZt81lpVjmFk = 'LIVE:  '
		if 'Buy' in xxUdv3DQoWAlIBEcbsfNhuJ1qka09L or 'Rent' in xxUdv3DQoWAlIBEcbsfNhuJ1qka09L: JJjdqk87RSrNfTD9BzixM = '$$:'
		if XSuCEhVPZvBIfwyFjipYaRks0(u'مباشر') in xxUdv3DQoWAlIBEcbsfNhuJ1qka09L: ssynRZt81lpVjmFk = 'LIVE:  '
		if XSuCEhVPZvBIfwyFjipYaRks0(u'شراء') in xxUdv3DQoWAlIBEcbsfNhuJ1qka09L: JJjdqk87RSrNfTD9BzixM = '$$:'
		if XSuCEhVPZvBIfwyFjipYaRks0(u'استئجار') in xxUdv3DQoWAlIBEcbsfNhuJ1qka09L: JJjdqk87RSrNfTD9BzixM = '$$:'
		if XSuCEhVPZvBIfwyFjipYaRks0(u'إعلانات') in xxUdv3DQoWAlIBEcbsfNhuJ1qka09L: JJjdqk87RSrNfTD9BzixM = '$:'
	ekTrZlFMu0Kf5QztEnhAs = ffbxegm1XPSqIwp8i(ekTrZlFMu0Kf5QztEnhAs)
	if ekTrZlFMu0Kf5QztEnhAs and 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
	pGjsvdyHfM = pGjsvdyHfM.split('?')[0]
	if  pGjsvdyHfM and 'http' not in pGjsvdyHfM: pGjsvdyHfM = 'https:'+pGjsvdyHfM
	title = ffbxegm1XPSqIwp8i(title)
	if JJjdqk87RSrNfTD9BzixM: title = JJjdqk87RSrNfTD9BzixM+'  '+title
	vNbeHULAy6gc4iE = vNbeHULAy6gc4iE.replace(',','')
	count = count.replace(',','')
	count = u5h2Rckvw1E.findall('\d+',count)
	if count: count = count[0]
	else: count = ''
	return True,title,ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,count,vNbeHULAy6gc4iE,ssynRZt81lpVjmFk,JJjdqk87RSrNfTD9BzixM
def ClLwQZGizU1IVYmDydTAfFqkxJE(TMaJdc0xOFKNf,url='',index=''):
	JJG0EdY1NQXfSRwm,title,ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,count,vNbeHULAy6gc4iE,ssynRZt81lpVjmFk,JJjdqk87RSrNfTD9BzixM = U1UI9JX6HdbYza7t4rZSP(TMaJdc0xOFKNf)
	if not JJG0EdY1NQXfSRwm: return
	elif 'continuationItemRenderer' in str(TMaJdc0xOFKNf): return
	elif 'searchPyvRenderer' in str(TMaJdc0xOFKNf): return
	elif not ekTrZlFMu0Kf5QztEnhAs and 'search_query' in url: return
	elif title and not ekTrZlFMu0Kf5QztEnhAs and ('search_query' in url or 'horizontalMovieListRenderer' in str(TMaJdc0xOFKNf) or url==yONJxHER9BIDPpTV4YsWmc0n):
		title = '=== '+title+' ==='
		uQNUfbZx9yj0F('link',tiCRYyX1bWd40Ir3PafQu+title,'',9999)
	elif title and 'messageRenderer' in str(TMaJdc0xOFKNf):
		uQNUfbZx9yj0F('link',tiCRYyX1bWd40Ir3PafQu+title,'',9999)
	elif '/feed/trending' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,144,pGjsvdyHfM,index)
	elif not title: return
	elif ssynRZt81lpVjmFk: uQNUfbZx9yj0F('live',tiCRYyX1bWd40Ir3PafQu+ssynRZt81lpVjmFk+title,ekTrZlFMu0Kf5QztEnhAs,143,pGjsvdyHfM)
	elif 'watch?v=' in ekTrZlFMu0Kf5QztEnhAs or '/shorts/' in ekTrZlFMu0Kf5QztEnhAs:
		if '&list=' in ekTrZlFMu0Kf5QztEnhAs and 'index=' not in ekTrZlFMu0Kf5QztEnhAs:
			dUu9Hma1y6P0 = ekTrZlFMu0Kf5QztEnhAs.split('&list=',1)[1]
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/playlist?list='+dUu9Hma1y6P0
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'LIST'+count+':  '+title,ekTrZlFMu0Kf5QztEnhAs,144,pGjsvdyHfM)
		else:
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.split('&list=',1)[0]
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,143,pGjsvdyHfM,vNbeHULAy6gc4iE)
	else:
		type = ''
		if not ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = url
		elif not any(c2eEflztvIX in ekTrZlFMu0Kf5QztEnhAs for c2eEflztvIX in ['/videos','/playlists','/channels','/featured','ss=','bp=']):
			if '/channel/'	in ekTrZlFMu0Kf5QztEnhAs or '/c/' in ekTrZlFMu0Kf5QztEnhAs: type = 'CHNL'+count+':  '
			if '/user/' in ekTrZlFMu0Kf5QztEnhAs: type = 'USER'+count+':  '
			index,qdWMXBVDoeZIrP3CphGNA6 = '',''
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+type+title,ekTrZlFMu0Kf5QztEnhAs,144,pGjsvdyHfM,index)
	return
def p0aw4UgTIeO5Pv92XZCkJcDNlu(url,data='',VemfsE32zgI=''):
	global LLwCINEyZT9GHP7QMA1VlukcDjh
	if not data: data = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.youtube.data')
	if VemfsE32zgI=='': VemfsE32zgI = 'ytInitialData'
	UUSPoh1ckMtVexN6u = ncgQBtRa7qT2GJ3Wpd()
	emrzEIsMWO2GLw9lpKxSY7n0F = {'User-Agent':UUSPoh1ckMtVexN6u,'Cookie':'PREF=hl=ar'}
	if ':::' in data: ea0MVzhDifcQnxt,key,hzpImM2tD9gaKZdV1,oufJnhglF8iLZHKUAxRp,dh1veN6mVBg7pQ,tX4O1q5ICGu9n8mMYZHwF = data.split(':::')
	else: ea0MVzhDifcQnxt,key,hzpImM2tD9gaKZdV1,oufJnhglF8iLZHKUAxRp,dh1veN6mVBg7pQ,tX4O1q5ICGu9n8mMYZHwF = '','','','','',''
	if 'guide?key=' in url:
		XfOb4VIcPY = {}
		XfOb4VIcPY['context'] = {"client":{"hl":"ar","clientName":"WEB","clientVersion":oufJnhglF8iLZHKUAxRp}}
		XfOb4VIcPY = str(XfOb4VIcPY)
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'POST',url,XfOb4VIcPY,emrzEIsMWO2GLw9lpKxSY7n0F,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif 'key=' in url and ea0MVzhDifcQnxt:
		XfOb4VIcPY = {'continuation':dh1veN6mVBg7pQ}
		XfOb4VIcPY['context'] = {"client":{"visitorData":ea0MVzhDifcQnxt,"clientName":"WEB","clientVersion":oufJnhglF8iLZHKUAxRp}}
		XfOb4VIcPY = str(XfOb4VIcPY)
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'POST',url,XfOb4VIcPY,emrzEIsMWO2GLw9lpKxSY7n0F,True,True,'YOUTUBE-GET_PAGE_DATA-2nd')
	elif 'ctoken=' in url and tX4O1q5ICGu9n8mMYZHwF:
		emrzEIsMWO2GLw9lpKxSY7n0F.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':oufJnhglF8iLZHKUAxRp})
		emrzEIsMWO2GLw9lpKxSY7n0F.update({'Cookie':'VISITOR_INFO1_LIVE='+tX4O1q5ICGu9n8mMYZHwF})
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',url,'',emrzEIsMWO2GLw9lpKxSY7n0F,'','','YOUTUBE-GET_PAGE_DATA-3rd')
	else:
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',url,'',emrzEIsMWO2GLw9lpKxSY7n0F,'','','YOUTUBE-GET_PAGE_DATA-4th')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	UVnDeTGCM0s627IZEaLwr = u5h2Rckvw1E.findall('"innertubeApiKey".*?"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.I)
	if UVnDeTGCM0s627IZEaLwr: key = UVnDeTGCM0s627IZEaLwr[0]
	UVnDeTGCM0s627IZEaLwr = u5h2Rckvw1E.findall('"cver".*?"value".*?"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.I)
	if UVnDeTGCM0s627IZEaLwr: oufJnhglF8iLZHKUAxRp = UVnDeTGCM0s627IZEaLwr[0]
	UVnDeTGCM0s627IZEaLwr = u5h2Rckvw1E.findall('"token".*?"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.I)
	if UVnDeTGCM0s627IZEaLwr: dh1veN6mVBg7pQ = UVnDeTGCM0s627IZEaLwr[0]
	UVnDeTGCM0s627IZEaLwr = u5h2Rckvw1E.findall('"visitorData".*?"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.I)
	if UVnDeTGCM0s627IZEaLwr: ea0MVzhDifcQnxt = UVnDeTGCM0s627IZEaLwr[0]
	UVnDeTGCM0s627IZEaLwr = u5h2Rckvw1E.findall('"continuation".*?"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.I)
	if UVnDeTGCM0s627IZEaLwr: hzpImM2tD9gaKZdV1 = UVnDeTGCM0s627IZEaLwr[0]
	cookies = RoQL91PphqCJg4W0e6Fnsl.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): tX4O1q5ICGu9n8mMYZHwF = cookies['VISITOR_INFO1_LIVE']
	data = ea0MVzhDifcQnxt+':::'+key+':::'+hzpImM2tD9gaKZdV1+':::'+oufJnhglF8iLZHKUAxRp+':::'+dh1veN6mVBg7pQ+':::'+tX4O1q5ICGu9n8mMYZHwF
	if VemfsE32zgI=='ytInitialData' and 'ytInitialData' in oo9SgGkiDbs3HRn7z8:
		vGW4t381dmqby = u5h2Rckvw1E.findall('window\["ytInitialData"\] = ({.*?});',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if not vGW4t381dmqby: vGW4t381dmqby = u5h2Rckvw1E.findall('var ytInitialData = ({.*?});',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		w03Ic9Zd7ACfJRE15M8FkYGP = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('str',vGW4t381dmqby[0])
	elif VemfsE32zgI=='ytInitialGuideData' and 'ytInitialGuideData' in oo9SgGkiDbs3HRn7z8:
		vGW4t381dmqby = u5h2Rckvw1E.findall('var ytInitialGuideData = ({.*?});',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		w03Ic9Zd7ACfJRE15M8FkYGP = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('str',vGW4t381dmqby[0])
	elif '</script>' not in oo9SgGkiDbs3HRn7z8: w03Ic9Zd7ACfJRE15M8FkYGP = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('str',oo9SgGkiDbs3HRn7z8)
	else: w03Ic9Zd7ACfJRE15M8FkYGP = ''
	LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting('av.youtube.data',data)
	return oo9SgGkiDbs3HRn7z8,w03Ic9Zd7ACfJRE15M8FkYGP,data
def fa7kLtYT91BbFHiDh4UqWPK(url):
	search = FBrXsYeCEp3()
	if not search: return
	search = search.replace(' ','+')
	gANn35esloKUydOipfSMC6RD2 = url+'/search?query='+search
	tZwPW2bEz6S0OLXK84IjDYFqkde(gANn35esloKUydOipfSMC6RD2)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if not search:
		search = FBrXsYeCEp3()
		if not search: return
	search = search.replace(' ','+')
	gANn35esloKUydOipfSMC6RD2 = yONJxHER9BIDPpTV4YsWmc0n+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in dza2VO9NvX: MMCHjyWK6X7JbregkiEUBdGV1m = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in dza2VO9NvX: MMCHjyWK6X7JbregkiEUBdGV1m = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in dza2VO9NvX: MMCHjyWK6X7JbregkiEUBdGV1m = '&sp=EgIQAg%253D%253D'
		UcmHDPlLWaSf = gANn35esloKUydOipfSMC6RD2+MMCHjyWK6X7JbregkiEUBdGV1m
	else:
		G1F9EODkaMb6,iiLV5pgokTOdKScmvWXP,cMpjL2oavyVwKHBPn8EdhYqxSUk = [],[],''
		NNwH6oz0qhPSCu49 = ['بدون ترتيب','ترتيب حسب مدى الصلة','ترتيب حسب تاريخ التحميل','ترتيب حسب عدد المشاهدات','ترتيب حسب التقييم']
		jGNuKw7hOBPbIXmUn = ['','&sp=CAA%253D','&sp=CAI%253D','&sp=CAM%253D','&sp=CAE%253D']
		KMpi961QXxmc = tYysxJLreEBDdXMIjz4OPa('موقع يوتيوب - اختر الترتيب',NNwH6oz0qhPSCu49)
		if KMpi961QXxmc == -1: return
		oa63NHmdVbGFBZfvR9J4j8Pq1 = jGNuKw7hOBPbIXmUn[KMpi961QXxmc]
		oo9SgGkiDbs3HRn7z8,wqOY7uh8HXIfTVJ,data = p0aw4UgTIeO5Pv92XZCkJcDNlu(gANn35esloKUydOipfSMC6RD2+oa63NHmdVbGFBZfvR9J4j8Pq1)
		if wqOY7uh8HXIfTVJ:
			MfTdV953F7Jrx = wqOY7uh8HXIfTVJ['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
			for uC2p0awmkK7NWvY8zS1A3gUiDG9 in range(len(MfTdV953F7Jrx)):
				group = MfTdV953F7Jrx[uC2p0awmkK7NWvY8zS1A3gUiDG9]['searchFilterGroupRenderer']['filters']
				for gkeICa30v4FNhzV9HdrYtmwsEfW in range(len(group)):
					EEdPXSD45WZw2eYaB36qJ = group[gkeICa30v4FNhzV9HdrYtmwsEfW]['searchFilterRenderer']
					if 'navigationEndpoint' in list(EEdPXSD45WZw2eYaB36qJ.keys()):
						ekTrZlFMu0Kf5QztEnhAs = EEdPXSD45WZw2eYaB36qJ['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
						ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.replace('\u0026','&')
						title = EEdPXSD45WZw2eYaB36qJ['tooltip']
						title = title.replace('البحث عن ','')
						if 'إزالة الفلتر' in title: continue
						if 'قائمة تشغيل' in title:
							title = 'جيد للمسلسلات '+title
							cMpjL2oavyVwKHBPn8EdhYqxSUk = title
							olm59qifJbWpRsr1a3X7zBEIA = ekTrZlFMu0Kf5QztEnhAs
						if 'ترتيب حسب' in title: continue
						title = title.replace('Search for ','')
						if 'Remove' in title: continue
						if 'Playlist' in title:
							title = 'جيد للمسلسلات '+title
							cMpjL2oavyVwKHBPn8EdhYqxSUk = title
							olm59qifJbWpRsr1a3X7zBEIA = ekTrZlFMu0Kf5QztEnhAs
						if 'Sort by' in title: continue
						G1F9EODkaMb6.append(ffbxegm1XPSqIwp8i(title))
						iiLV5pgokTOdKScmvWXP.append(ekTrZlFMu0Kf5QztEnhAs)
		if not cMpjL2oavyVwKHBPn8EdhYqxSUk: D67C1ZpcT8g = ''
		else:
			G1F9EODkaMb6 = ['بدون فلتر',cMpjL2oavyVwKHBPn8EdhYqxSUk]+G1F9EODkaMb6
			iiLV5pgokTOdKScmvWXP = ['',olm59qifJbWpRsr1a3X7zBEIA]+iiLV5pgokTOdKScmvWXP
			ibzhVx8fr4aSntUw0cHu = tYysxJLreEBDdXMIjz4OPa('موقع يوتيوب - اختر الفلتر',G1F9EODkaMb6)
			if ibzhVx8fr4aSntUw0cHu == -1: return
			D67C1ZpcT8g = iiLV5pgokTOdKScmvWXP[ibzhVx8fr4aSntUw0cHu]
		if D67C1ZpcT8g: UcmHDPlLWaSf = yONJxHER9BIDPpTV4YsWmc0n+D67C1ZpcT8g
		elif oa63NHmdVbGFBZfvR9J4j8Pq1: UcmHDPlLWaSf = gANn35esloKUydOipfSMC6RD2+oa63NHmdVbGFBZfvR9J4j8Pq1
		else: UcmHDPlLWaSf = gANn35esloKUydOipfSMC6RD2
	tZwPW2bEz6S0OLXK84IjDYFqkde(UcmHDPlLWaSf)
	return
# -*- coding: utf-8 -*-
from LXgKztbkOf import *
import bs4 as ggDO7rZJTlX3wx8
aUVSgO2ebjwX5iqPykC = 'ELCINEMA'
tiCRYyX1bWd40Ir3PafQu = '_ELC_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
headers = {'Referer':yONJxHER9BIDPpTV4YsWmc0n}
WLI5tgXRbUPNGJCSVz0vKjBDei3 = []
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==510: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==511: vS7JufTVsBxw52 = MwmHWfp4jxROn89(url)
	elif mode==512: vS7JufTVsBxw52 = u4umKHwecFUQAZo1YiBtC9baRlE(url)
	elif mode==513: vS7JufTVsBxw52 = odubYMqZLzV(url)
	elif mode==514: vS7JufTVsBxw52 = eePSyGF5Yfi4L0(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: vS7JufTVsBxw52 = eePSyGF5Yfi4L0(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: vS7JufTVsBxw52 = B2VZ9TK7cOm8AgatufHj4MWUIr1nz(text)
	elif mode==517: vS7JufTVsBxw52 = cdPk0ov4ueDKgTOn3yQZMN(url)
	elif mode==518: vS7JufTVsBxw52 = OKJGUw04PQ9(url)
	elif mode==519: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	elif mode==520: vS7JufTVsBxw52 = f3obDtq1gc4pV8WYO9P(url)
	elif mode==521: vS7JufTVsBxw52 = STbjfrqyO39WIk4n15MxHzQgFmps6(url)
	elif mode==522: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==523: vS7JufTVsBxw52 = qDo2ZtG8lJOKgM(text)
	elif mode==524: vS7JufTVsBxw52 = BQaq7wiWJOnCmELypF2jsevX9b()
	elif mode==525: vS7JufTVsBxw52 = wHVSkDpRB09em()
	elif mode==526: vS7JufTVsBxw52 = m9mJfrhYNSlRsnZB()
	elif mode==527: vS7JufTVsBxw52 = hbSAdqYuVnrljJtI()
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث بموسوعة السينما','',519)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'موسوعة الأعمال','',525)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'موسوعة الأشخاص','',526)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'موسوعة المصنفات','',527)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'موسوعة المنوعات','',524)
	return
def BQaq7wiWJOnCmELypF2jsevX9b():
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+' فيديوهات - خاصة',yONJxHER9BIDPpTV4YsWmc0n+'/video',520)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فيديوهات - أحدث',yONJxHER9BIDPpTV4YsWmc0n+'/video/latest',521)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فيديوهات - أقدم',yONJxHER9BIDPpTV4YsWmc0n+'/video/oldest',521)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فيديوهات - أكثر مشاهدة',yONJxHER9BIDPpTV4YsWmc0n+'/video/views',521)
	return
def wHVSkDpRB09em():
	QjDiOGAX6g71nmSRFwVNvf8M = yONJxHER9BIDPpTV4YsWmc0n+'/lineup?utf8=%E2%9C%93'
	MWvzh0FlUsC5fynKLrwYkZX6 = QjDiOGAX6g71nmSRFwVNvf8M+'&type=2&category=1&foreign=false&tag='
	yWjsv9So6cLzfaTUmpCVKJgD = QjDiOGAX6g71nmSRFwVNvf8M+'&type=2&category=3&foreign=false&tag='
	IjpgVRmLF5WKSbfZNrzuaM6xsY = QjDiOGAX6g71nmSRFwVNvf8M+'&type=2&category=1&foreign=true&tag='
	J2LTWRaDMAlgcubvtK5pIoPOf = QjDiOGAX6g71nmSRFwVNvf8M+'&type=2&category=3&foreign=true&tag='
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مصنفات أفلام عربي',MWvzh0FlUsC5fynKLrwYkZX6,511)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مصنفات مسلسلات عربي',yWjsv9So6cLzfaTUmpCVKJgD,511)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مصنفات أفلام اجنبي',IjpgVRmLF5WKSbfZNrzuaM6xsY,511)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مصنفات مسلسلات اجنبي',J2LTWRaDMAlgcubvtK5pIoPOf,511)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فهرس أعمال أبجدي',yONJxHER9BIDPpTV4YsWmc0n+'/index/work/alphabet',517)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فهرس  بلد الإنتاج',yONJxHER9BIDPpTV4YsWmc0n+'/index/work/country',517)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فهرس اللغة',yONJxHER9BIDPpTV4YsWmc0n+'/index/work/language',517)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فهرس مصنفات العمل',yONJxHER9BIDPpTV4YsWmc0n+'/index/work/genre',517)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فهرس سنة الإصدار',yONJxHER9BIDPpTV4YsWmc0n+'/index/work/release_year',517)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مواسم - فلتر محدد',yONJxHER9BIDPpTV4YsWmc0n+'/seasonals',515)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مواسم - فلتر كامل',yONJxHER9BIDPpTV4YsWmc0n+'/seasonals',514)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مصنفات - فلتر محدد',yONJxHER9BIDPpTV4YsWmc0n+'/lineup',515)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مصنفات - فلتر كامل',yONJxHER9BIDPpTV4YsWmc0n+'/lineup',514)
	return
def hbSAdqYuVnrljJtI():
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',yONJxHER9BIDPpTV4YsWmc0n+'/lineup','',headers,'','','ELCINEMA-MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	reqI7a2BnDHREYQh1oGUiJFWTkPd = ggDO7rZJTlX3wx8.BeautifulSoup(oo9SgGkiDbs3HRn7z8,'html.parser',multi_valued_attributes=None)
	lmO2YJGr6tCV = reqI7a2BnDHREYQh1oGUiJFWTkPd.find('select',attrs={'name':'tag'})
	dza2VO9NvX = lmO2YJGr6tCV.find_all('option')
	for q1rVywkMcKftIioS43LY in dza2VO9NvX:
		c2eEflztvIX = q1rVywkMcKftIioS43LY.get('value')
		if not c2eEflztvIX: continue
		title = q1rVywkMcKftIioS43LY.text
		if bdptXFc8UlIhA5jnGwPmKuv2L:
			title = title.encode('utf8')
			c2eEflztvIX = c2eEflztvIX.encode('utf8')
		ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+c2eEflztvIX
		title = title.replace('قائمة ','')
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,511)
	return
def m9mJfrhYNSlRsnZB():
	QjDiOGAX6g71nmSRFwVNvf8M = yONJxHER9BIDPpTV4YsWmc0n+'/lineup?utf8=%E2%9C%93'
	JAw7cCozDp6Ts5Sm3n = QjDiOGAX6g71nmSRFwVNvf8M+'&type=1&category=&foreign=&tag='
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مصنفات أشخاص',JAw7cCozDp6Ts5Sm3n,511)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فهرس أشخاص أبجدي',yONJxHER9BIDPpTV4YsWmc0n+'/index/person/alphabet',517)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فهرس موطن',yONJxHER9BIDPpTV4YsWmc0n+'/index/person/nationality',517)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فهرس  تاريخ الميلاد',yONJxHER9BIDPpTV4YsWmc0n+'/index/person/birth_year',517)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فهرس  تاريخ الوفاة',yONJxHER9BIDPpTV4YsWmc0n+'/index/person/death_year',517)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مصنفات - فلتر محدد',yONJxHER9BIDPpTV4YsWmc0n+'/lineup',515)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مصنفات - فلتر كامل',yONJxHER9BIDPpTV4YsWmc0n+'/lineup',514)
	return
def MwmHWfp4jxROn89(url):
	if '/seasonals' in url: M4Feb15G0QtrDlW6sPh9xNBnC3j = 0
	elif '/lineup' in url: M4Feb15G0QtrDlW6sPh9xNBnC3j = 1
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',url,'',headers,'','','ELCINEMA-LISTS-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	reqI7a2BnDHREYQh1oGUiJFWTkPd = ggDO7rZJTlX3wx8.BeautifulSoup(oo9SgGkiDbs3HRn7z8,'html.parser',multi_valued_attributes=None)
	ppZ9muD1GkPnFRX52jxBUIy = reqI7a2BnDHREYQh1oGUiJFWTkPd.find_all(class_='jumbo-theater clearfix')
	for lmO2YJGr6tCV in ppZ9muD1GkPnFRX52jxBUIy:
		title = lmO2YJGr6tCV.find_all('a')[M4Feb15G0QtrDlW6sPh9xNBnC3j].text
		ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+lmO2YJGr6tCV.find_all('a')[M4Feb15G0QtrDlW6sPh9xNBnC3j].get('href')
		if bdptXFc8UlIhA5jnGwPmKuv2L:
			title = title.encode('utf8')
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.encode('utf8')
		if not ppZ9muD1GkPnFRX52jxBUIy:
			u4umKHwecFUQAZo1YiBtC9baRlE(ekTrZlFMu0Kf5QztEnhAs)
			return
		else:
			title = title.replace('قائمة ','')
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,512)
	AAF5lDV1fcPn2T8(reqI7a2BnDHREYQh1oGUiJFWTkPd,511)
	return
def AAF5lDV1fcPn2T8(reqI7a2BnDHREYQh1oGUiJFWTkPd,mode):
	lmO2YJGr6tCV = reqI7a2BnDHREYQh1oGUiJFWTkPd.find(class_='pagination')
	if lmO2YJGr6tCV:
		Jk6nDFazhW9vPK = lmO2YJGr6tCV.find_all('a')
		tHZLAqlhRsy6Fp = lmO2YJGr6tCV.find_all('li')
		b3uVXNrDOMSvxUdRsHIhC = list(zip(Jk6nDFazhW9vPK,tHZLAqlhRsy6Fp))
		k0G4LTYt93po = -1
		o7fQkCxH9djRYJlsFI = len(b3uVXNrDOMSvxUdRsHIhC)
		for GRM9OPVoZmIu1fgQiX,FCX325HZyKWbBf in b3uVXNrDOMSvxUdRsHIhC:
			k0G4LTYt93po += 1
			FCX325HZyKWbBf = FCX325HZyKWbBf['class']
			if 'unavailable' in FCX325HZyKWbBf or 'current' in FCX325HZyKWbBf: continue
			yGAtUBdJLngm = GRM9OPVoZmIu1fgQiX.text
			olm59qifJbWpRsr1a3X7zBEIA = yONJxHER9BIDPpTV4YsWmc0n+GRM9OPVoZmIu1fgQiX.get('href')
			if bdptXFc8UlIhA5jnGwPmKuv2L:
				yGAtUBdJLngm = yGAtUBdJLngm.encode('utf8')
				olm59qifJbWpRsr1a3X7zBEIA = olm59qifJbWpRsr1a3X7zBEIA.encode('utf8')
			if   k0G4LTYt93po==0: yGAtUBdJLngm = 'أولى'
			elif k0G4LTYt93po==1: yGAtUBdJLngm = 'سابقة'
			elif k0G4LTYt93po==o7fQkCxH9djRYJlsFI-2: yGAtUBdJLngm = 'لاحقة'
			elif k0G4LTYt93po==o7fQkCxH9djRYJlsFI-1: yGAtUBdJLngm = 'أخيرة'
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+yGAtUBdJLngm,olm59qifJbWpRsr1a3X7zBEIA,mode)
	return
def u4umKHwecFUQAZo1YiBtC9baRlE(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',url,'',headers,'','','ELCINEMA-TITLES1-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	reqI7a2BnDHREYQh1oGUiJFWTkPd = ggDO7rZJTlX3wx8.BeautifulSoup(oo9SgGkiDbs3HRn7z8,'html.parser',multi_valued_attributes=None)
	ppZ9muD1GkPnFRX52jxBUIy = reqI7a2BnDHREYQh1oGUiJFWTkPd.find_all(class_='row')
	items,mgka3ynHUhDN1 = [],True
	for lmO2YJGr6tCV in ppZ9muD1GkPnFRX52jxBUIy:
		if not lmO2YJGr6tCV.find(class_='thumbnail-wrapper'): continue
		if mgka3ynHUhDN1: mgka3ynHUhDN1 = False ; continue
		YZ0B7iTF1WM4xhlbc3J8Htyako = []
		twQ3TGXRUuSV0n5oFMjK9iecgrC4y = lmO2YJGr6tCV.find_all(class_=['censorship red','censorship purple'])
		for zHmTLVAsbYyaU7xfnM in twQ3TGXRUuSV0n5oFMjK9iecgrC4y:
			KS8ZsVdAjf = zHmTLVAsbYyaU7xfnM.find_all('li')[1].text
			if bdptXFc8UlIhA5jnGwPmKuv2L:
				KS8ZsVdAjf = KS8ZsVdAjf.encode('utf8')
			YZ0B7iTF1WM4xhlbc3J8Htyako.append(KS8ZsVdAjf)
		if not dQorkS3qBhIMDWKHl(aUVSgO2ebjwX5iqPykC,'',YZ0B7iTF1WM4xhlbc3J8Htyako,False):
			ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx = lmO2YJGr6tCV.find('img').get('data-src')
			title = lmO2YJGr6tCV.find('h3')
			name = title.find('a').text
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+title.find('a').get('href')
			fCVHuAR4M6Pbrkqw2poy = lmO2YJGr6tCV.find(class_='no-margin')
			CqL0t1kGw9JYlPxz3p = lmO2YJGr6tCV.find(class_='legend')
			if fCVHuAR4M6Pbrkqw2poy: fCVHuAR4M6Pbrkqw2poy = fCVHuAR4M6Pbrkqw2poy.text
			if CqL0t1kGw9JYlPxz3p: CqL0t1kGw9JYlPxz3p = CqL0t1kGw9JYlPxz3p.text
			if bdptXFc8UlIhA5jnGwPmKuv2L:
				ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx = ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx.encode('utf8')
				name = name.encode('utf8')
				ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.encode('utf8')
				if fCVHuAR4M6Pbrkqw2poy: fCVHuAR4M6Pbrkqw2poy = fCVHuAR4M6Pbrkqw2poy.encode('utf8')
			aiSY4yFdLmPH2zenlMpv = {}
			if CqL0t1kGw9JYlPxz3p: aiSY4yFdLmPH2zenlMpv['stars'] = CqL0t1kGw9JYlPxz3p
			if fCVHuAR4M6Pbrkqw2poy:
				fCVHuAR4M6Pbrkqw2poy = fCVHuAR4M6Pbrkqw2poy.replace('\n',' .. ')
				aiSY4yFdLmPH2zenlMpv['plot'] = fCVHuAR4M6Pbrkqw2poy.replace('...اقرأ المزيد','')
			if '/work/' in ekTrZlFMu0Kf5QztEnhAs:
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+name,ekTrZlFMu0Kf5QztEnhAs,516,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,'',name,'',aiSY4yFdLmPH2zenlMpv)
			elif '/person/' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+name,ekTrZlFMu0Kf5QztEnhAs,513,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,'',name,'',aiSY4yFdLmPH2zenlMpv)
	AAF5lDV1fcPn2T8(reqI7a2BnDHREYQh1oGUiJFWTkPd,512)
	return
def odubYMqZLzV(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',url,'',headers,'','','ELCINEMA-TITLES2-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	reqI7a2BnDHREYQh1oGUiJFWTkPd = ggDO7rZJTlX3wx8.BeautifulSoup(oo9SgGkiDbs3HRn7z8,'html.parser',multi_valued_attributes=None)
	ppZ9muD1GkPnFRX52jxBUIy = reqI7a2BnDHREYQh1oGUiJFWTkPd.find_all('li')
	woSL8eJ219qdksrZFIaPA,items = [],[]
	for lmO2YJGr6tCV in ppZ9muD1GkPnFRX52jxBUIy:
		if not lmO2YJGr6tCV.find(class_='thumbnail-wrapper'): continue
		if not lmO2YJGr6tCV.find(class_=['unstyled','unstyled text-center']): continue
		if lmO2YJGr6tCV.find(class_='hide'): continue
		title = lmO2YJGr6tCV.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in woSL8eJ219qdksrZFIaPA: continue
		woSL8eJ219qdksrZFIaPA.append(name)
		ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+title.find('a').get('href')
		if '/search/work/' in url: ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx = lmO2YJGr6tCV.find('img').get('src')
		elif '/search/person/' in url: ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx = lmO2YJGr6tCV.find('img').get('data-src')
		elif '/search/video/' in url: ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx = lmO2YJGr6tCV.find('img').get('data-src')
		else: ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx = lmO2YJGr6tCV.find('img').get('src')
		if bdptXFc8UlIhA5jnGwPmKuv2L:
			name = name.encode('utf8')
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.encode('utf8')
			ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx = ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx.encode('utf8')
		name = name.strip(' ')
		items.append((name,ekTrZlFMu0Kf5QztEnhAs,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,ekTrZlFMu0Kf5QztEnhAs,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx in items:
		if '/search/video/' in url: uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+name,ekTrZlFMu0Kf5QztEnhAs,522,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx)
		elif '/search/person/' in url: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+name,ekTrZlFMu0Kf5QztEnhAs,513,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,'',name)
		else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+name,ekTrZlFMu0Kf5QztEnhAs,516,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,'',name)
	return
def B2VZ9TK7cOm8AgatufHj4MWUIr1nz(text):
	text = text.replace('الإعلان','').replace('لفيلم','').replace('الرسمي','')
	text = text.replace('إعلان','').replace('فيلم','').replace('البرومو','')
	text = text.replace('التشويقي','').replace('لمسلسل','').replace('مسلسل','')
	text = text.replace(':','').replace(')','').replace('(','').replace(',','')
	text = text.replace('_','').replace(';','').replace('-','').replace('.','')
	text = text.replace('\'','').replace('\"','')
	text = text.replace('    ',' ').replace('   ',' ').replace('  ',' ')
	text = text.strip(' ')
	Nbz7DKeraoLGHi08nkw = text.count(' ')+1
	if Nbz7DKeraoLGHi08nkw==1:
		qDo2ZtG8lJOKgM(text)
		return
	uQNUfbZx9yj0F('link',tiCRYyX1bWd40Ir3PafQu+'[COLOR FFC89008]==== كلمات للبحث ====[/COLOR]','',9999)
	kJU7ohaDTfmRO = text.split(' ')
	aBw5N0qYiL8xJMnO = pow(2,Nbz7DKeraoLGHi08nkw)
	qAXDbplxsjnd3JLTV5eO = []
	def zzuDcCWVyA1kreJR4YmZ(s0lS5pNYIn,YQqjFT3SdEIR0bDLp2vkAHC):
		if s0lS5pNYIn=='1': return YQqjFT3SdEIR0bDLp2vkAHC
		return ''
	for k0G4LTYt93po in range(aBw5N0qYiL8xJMnO,0,-1):
		IsedFbw0hz4 = list(Nbz7DKeraoLGHi08nkw*'0'+bin(k0G4LTYt93po)[2:])[-Nbz7DKeraoLGHi08nkw:]
		IsedFbw0hz4 = reversed(IsedFbw0hz4)
		FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy = map(zzuDcCWVyA1kreJR4YmZ,IsedFbw0hz4,kJU7ohaDTfmRO)
		title = ' '.join(filter(None,FFUbDlmCgpjrJXNtwc0LaHdOPQK8vy))
		if bdptXFc8UlIhA5jnGwPmKuv2L: cMpjL2oavyVwKHBPn8EdhYqxSUk = title.decode('utf8')
		else: cMpjL2oavyVwKHBPn8EdhYqxSUk = title
		if len(cMpjL2oavyVwKHBPn8EdhYqxSUk)>2 and title not in qAXDbplxsjnd3JLTV5eO:
			qAXDbplxsjnd3JLTV5eO.append(title)
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,'',523,'','',title)
	return
def qDo2ZtG8lJOKgM(Sel8j25hvodwrVDaGFWKnHcuN3i):
	if bdptXFc8UlIhA5jnGwPmKuv2L:
		Sel8j25hvodwrVDaGFWKnHcuN3i = Sel8j25hvodwrVDaGFWKnHcuN3i.decode('utf8')
		import arabic_reshaper as fgUHCJMeYhSa2IXQtu90jOTV
		Sel8j25hvodwrVDaGFWKnHcuN3i = fgUHCJMeYhSa2IXQtu90jOTV.ArabicReshaper().reshape(Sel8j25hvodwrVDaGFWKnHcuN3i)
		Sel8j25hvodwrVDaGFWKnHcuN3i = k4rNW6UOwPBVDfblusx.get_display(Sel8j25hvodwrVDaGFWKnHcuN3i)
	import IceNfg3vrV
	Sel8j25hvodwrVDaGFWKnHcuN3i = FBrXsYeCEp3(default=Sel8j25hvodwrVDaGFWKnHcuN3i)
	IceNfg3vrV.bB8m3r5asjpdG0ulEJg(Sel8j25hvodwrVDaGFWKnHcuN3i)
	return
def cdPk0ov4ueDKgTOn3yQZMN(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',url,'',headers,'','','ELCINEMA-INDEXES_LISTS-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	reqI7a2BnDHREYQh1oGUiJFWTkPd = ggDO7rZJTlX3wx8.BeautifulSoup(oo9SgGkiDbs3HRn7z8,'html.parser',multi_valued_attributes=None)
	lmO2YJGr6tCV = reqI7a2BnDHREYQh1oGUiJFWTkPd.find(class_='list-separator list-title')
	YMpoGJSqdLFkvb4WRuZNa65 = lmO2YJGr6tCV.find_all('a')
	items = []
	for title in YMpoGJSqdLFkvb4WRuZNa65:
		name = title.text
		ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+title.get('href')
		if bdptXFc8UlIhA5jnGwPmKuv2L:
			name = name.encode('utf8')
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.encode('utf8')
		if '#' not in ekTrZlFMu0Kf5QztEnhAs: items.append((name,ekTrZlFMu0Kf5QztEnhAs))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for TMaJdc0xOFKNf in items:
		name,ekTrZlFMu0Kf5QztEnhAs = TMaJdc0xOFKNf
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+name,ekTrZlFMu0Kf5QztEnhAs,518)
	return
def OKJGUw04PQ9(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',url,'',headers,'','','ELCINEMA-INDEXES_TITLES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	reqI7a2BnDHREYQh1oGUiJFWTkPd = ggDO7rZJTlX3wx8.BeautifulSoup(oo9SgGkiDbs3HRn7z8,'html.parser',multi_valued_attributes=None)
	ppZ9muD1GkPnFRX52jxBUIy = reqI7a2BnDHREYQh1oGUiJFWTkPd.find(class_='expand').find_all('tr')
	for lmO2YJGr6tCV in ppZ9muD1GkPnFRX52jxBUIy:
		KUCj0gZVB2nWbDeXwSY = lmO2YJGr6tCV.find_all('a')
		if not KUCj0gZVB2nWbDeXwSY: continue
		ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx = lmO2YJGr6tCV.find('img').get('data-src')
		name = KUCj0gZVB2nWbDeXwSY[1].text
		ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+KUCj0gZVB2nWbDeXwSY[1].get('href')
		CqL0t1kGw9JYlPxz3p = lmO2YJGr6tCV.find(class_='legend')
		if CqL0t1kGw9JYlPxz3p: CqL0t1kGw9JYlPxz3p = CqL0t1kGw9JYlPxz3p.text
		if bdptXFc8UlIhA5jnGwPmKuv2L:
			name = name.encode('utf8')
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.encode('utf8')
			ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx = ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx.encode('utf8')
		aiSY4yFdLmPH2zenlMpv = {}
		if CqL0t1kGw9JYlPxz3p: aiSY4yFdLmPH2zenlMpv['stars'] = CqL0t1kGw9JYlPxz3p
		if '/work/' in ekTrZlFMu0Kf5QztEnhAs:
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+name,ekTrZlFMu0Kf5QztEnhAs,516,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,'',name,'',aiSY4yFdLmPH2zenlMpv)
		elif '/person/' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+name,ekTrZlFMu0Kf5QztEnhAs,513,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,'',name,'',aiSY4yFdLmPH2zenlMpv)
	AAF5lDV1fcPn2T8(reqI7a2BnDHREYQh1oGUiJFWTkPd,518)
	return
def f3obDtq1gc4pV8WYO9P(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',url,'',headers,'','','ELCINEMA-VIDEOS_LISTS-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	reqI7a2BnDHREYQh1oGUiJFWTkPd = ggDO7rZJTlX3wx8.BeautifulSoup(oo9SgGkiDbs3HRn7z8,'html.parser',multi_valued_attributes=None)
	YMpoGJSqdLFkvb4WRuZNa65 = reqI7a2BnDHREYQh1oGUiJFWTkPd.find_all(class_='section-title inline')
	lQUf3AY258LeWch = reqI7a2BnDHREYQh1oGUiJFWTkPd.find_all(class_='button green small right')
	items = zip(YMpoGJSqdLFkvb4WRuZNa65,lQUf3AY258LeWch)
	for title,ekTrZlFMu0Kf5QztEnhAs in items:
		title = title.text
		ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs.get('href')
		if bdptXFc8UlIhA5jnGwPmKuv2L:
			title = title.encode('utf8')
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.encode('utf8')
		title = title.replace('    ',' ').replace('   ',' ').replace('  ',' ')
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,521)
	return
def STbjfrqyO39WIk4n15MxHzQgFmps6(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',url,'',headers,'','','ELCINEMA-VIDEOS_TITLES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	reqI7a2BnDHREYQh1oGUiJFWTkPd = ggDO7rZJTlX3wx8.BeautifulSoup(oo9SgGkiDbs3HRn7z8,'html.parser',multi_valued_attributes=None)
	aypYwPb3I1DZQ4rHl = reqI7a2BnDHREYQh1oGUiJFWTkPd.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	ppZ9muD1GkPnFRX52jxBUIy = aypYwPb3I1DZQ4rHl.find_all('li')
	for lmO2YJGr6tCV in ppZ9muD1GkPnFRX52jxBUIy:
		title = lmO2YJGr6tCV.find(class_='title').text
		ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+lmO2YJGr6tCV.find('a').get('href')
		ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx = lmO2YJGr6tCV.find('img').get('data-src')
		vNbeHULAy6gc4iE = lmO2YJGr6tCV.find(class_='duration').text
		if bdptXFc8UlIhA5jnGwPmKuv2L:
			title = title.encode('utf8')
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.encode('utf8')
			ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx = ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx.encode('utf8')
			vNbeHULAy6gc4iE = vNbeHULAy6gc4iE.encode('utf8')
		vNbeHULAy6gc4iE = vNbeHULAy6gc4iE.replace('\n','').strip(' ')
		uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,522,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,vNbeHULAy6gc4iE)
	AAF5lDV1fcPn2T8(reqI7a2BnDHREYQh1oGUiJFWTkPd,521)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',url,'',headers,'','','ELCINEMA-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	reqI7a2BnDHREYQh1oGUiJFWTkPd = ggDO7rZJTlX3wx8.BeautifulSoup(oo9SgGkiDbs3HRn7z8,'html.parser',multi_valued_attributes=None)
	ekTrZlFMu0Kf5QztEnhAs = reqI7a2BnDHREYQh1oGUiJFWTkPd.find(class_='flex-video').find('iframe').get('src')
	if bdptXFc8UlIhA5jnGwPmKuv2L: ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.encode('utf8')
	om1iZDWnrhGa2SLB9O4kfxYbqU(ekTrZlFMu0Kf5QztEnhAs,aUVSgO2ebjwX5iqPykC,'video')
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	search = search.replace(' ','%20')
	url = yONJxHER9BIDPpTV4YsWmc0n+'/search/?q='+search
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',url,'',headers,'','','ELCINEMA-SEARCH-1st')
	if not RoQL91PphqCJg4W0e6Fnsl.succeeded:
		JAw7cCozDp6Ts5Sm3n = yONJxHER9BIDPpTV4YsWmc0n+'/search_entity/?q='+search+'&entity=work'
		olm59qifJbWpRsr1a3X7zBEIA = yONJxHER9BIDPpTV4YsWmc0n+'/search_entity/?q='+search+'&entity=person'
		UFaSM8n5uZVHNCJvBPOgA3j6 = yONJxHER9BIDPpTV4YsWmc0n+'/search_entity/?q='+search+'&entity=video'
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث عن أعمال',JAw7cCozDp6Ts5Sm3n,513,'',search)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث عن أشخاص',olm59qifJbWpRsr1a3X7zBEIA,513,'',search)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث عن فيديوهات',UFaSM8n5uZVHNCJvBPOgA3j6,513,'',search)
		return
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	reqI7a2BnDHREYQh1oGUiJFWTkPd = ggDO7rZJTlX3wx8.BeautifulSoup(oo9SgGkiDbs3HRn7z8,'html.parser',multi_valued_attributes=None)
	ppZ9muD1GkPnFRX52jxBUIy = reqI7a2BnDHREYQh1oGUiJFWTkPd.find_all(class_='section-title left')
	for lmO2YJGr6tCV in ppZ9muD1GkPnFRX52jxBUIy:
		title = lmO2YJGr6tCV.text
		if bdptXFc8UlIhA5jnGwPmKuv2L:
			title = title.encode('utf8')
		title = title.split('(',1)[0].strip(' ')
		if   'أعمال' in title: ekTrZlFMu0Kf5QztEnhAs = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: ekTrZlFMu0Kf5QztEnhAs = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: ekTrZlFMu0Kf5QztEnhAs = url.replace('/search/','/search/video/')
		else: continue
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,513)
	return
def eePSyGF5Yfi4L0(url,text):
	global BVNnjYeCa3AfgTv0u6R,mwqMBcOe2Lj
	if '/seasonals' in url:
		BVNnjYeCa3AfgTv0u6R = ['seasonal','year','category']
		mwqMBcOe2Lj = ['seasonal','year','category']
	elif '/lineup' in url:
		BVNnjYeCa3AfgTv0u6R = ['category','foreign','type']
		mwqMBcOe2Lj = ['category','foreign','type']
	WYxFZIrRp6b(url,text)
	return
def C50mPGacMg7V34she6UR8LjfSt1(url):
	url = url.split('/smartemadfilter?')[0]
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',url,'',headers,'','','ELCINEMA-GET_FILTERS_BLOCKS-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('form action="/(.*?)</form>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	cGdHRiwvptVXQlzE8ZUgB0aJo9x = u5h2Rckvw1E.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	return cGdHRiwvptVXQlzE8ZUgB0aJo9x
def zzsLCt0FpUQEeMoYWBqGlZJP6rn4(lmO2YJGr6tCV):
	items = u5h2Rckvw1E.findall('<option value="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	return items
def l9GNIMkR6FbWzpQZsYwEyAaU17v(url):
	TImV9B8wLag3trpRZWvAqQPN5 = url.split('/smartemadfilter?')[0]
	GDJeByAH5fRS9I = hmcFWJUgiAuGk(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def VVTeCG1Jbu7B(z3wGSEWqVy1Qh5N,url):
	TBFfiRI52ZmKwO1JLSD = mltWBSPJz5H4VRdCAa1(z3wGSEWqVy1Qh5N,'all_filters')
	UcmHDPlLWaSf = url+'/smartemadfilter?'+TBFfiRI52ZmKwO1JLSD
	UcmHDPlLWaSf = l9GNIMkR6FbWzpQZsYwEyAaU17v(UcmHDPlLWaSf)
	return UcmHDPlLWaSf
def WYxFZIrRp6b(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': lvUP2GeNjyVOHKJxcBoun3Z,MoELTBDgQeaJrl0zYUmKCH = '',''
	else: lvUP2GeNjyVOHKJxcBoun3Z,MoELTBDgQeaJrl0zYUmKCH = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if BVNnjYeCa3AfgTv0u6R[0]+'=' not in lvUP2GeNjyVOHKJxcBoun3Z: oPrhaMp7AqmNnRjlXGI = BVNnjYeCa3AfgTv0u6R[0]
		for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(len(BVNnjYeCa3AfgTv0u6R[0:-1])):
			if BVNnjYeCa3AfgTv0u6R[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE]+'=' in lvUP2GeNjyVOHKJxcBoun3Z: oPrhaMp7AqmNnRjlXGI = BVNnjYeCa3AfgTv0u6R[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE+1]
		WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&'+oPrhaMp7AqmNnRjlXGI+'=0'
		z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&'+oPrhaMp7AqmNnRjlXGI+'=0'
		bIYSyA3BD1o4 = WGiMcqkRetEJVrSI.strip('&')+'___'+z3wGSEWqVy1Qh5N.strip('&')
		TBFfiRI52ZmKwO1JLSD = mltWBSPJz5H4VRdCAa1(MoELTBDgQeaJrl0zYUmKCH,'modified_filters')
		gANn35esloKUydOipfSMC6RD2 = url+'/smartemadfilter?'+TBFfiRI52ZmKwO1JLSD
	elif type=='ALL_ITEMS_FILTER':
		lv2uANOtVxE8RTa7bYHqLog1Bd = mltWBSPJz5H4VRdCAa1(lvUP2GeNjyVOHKJxcBoun3Z,'modified_values')
		lv2uANOtVxE8RTa7bYHqLog1Bd = P2o6ZDHeW790pSQqucvnxzILVUX(lv2uANOtVxE8RTa7bYHqLog1Bd)
		if MoELTBDgQeaJrl0zYUmKCH!='': MoELTBDgQeaJrl0zYUmKCH = mltWBSPJz5H4VRdCAa1(MoELTBDgQeaJrl0zYUmKCH,'modified_filters')
		if MoELTBDgQeaJrl0zYUmKCH=='': gANn35esloKUydOipfSMC6RD2 = url
		else: gANn35esloKUydOipfSMC6RD2 = url+'/smartemadfilter?'+MoELTBDgQeaJrl0zYUmKCH
		gANn35esloKUydOipfSMC6RD2 = l9GNIMkR6FbWzpQZsYwEyAaU17v(gANn35esloKUydOipfSMC6RD2)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'أظهار قائمة الفيديو التي تم اختيارها ',gANn35esloKUydOipfSMC6RD2,511)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+' [[   '+lv2uANOtVxE8RTa7bYHqLog1Bd+'   ]]',gANn35esloKUydOipfSMC6RD2,511)
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cGdHRiwvptVXQlzE8ZUgB0aJo9x = C50mPGacMg7V34she6UR8LjfSt1(url)
	dict = {}
	for name,Uiy0XwPusDg4vAFc35oYdfGnOrV,lmO2YJGr6tCV in cGdHRiwvptVXQlzE8ZUgB0aJo9x:
		name = name.replace('--','')
		items = zzsLCt0FpUQEeMoYWBqGlZJP6rn4(lmO2YJGr6tCV)
		if '=' not in gANn35esloKUydOipfSMC6RD2: gANn35esloKUydOipfSMC6RD2 = url
		if type=='SPECIFIED_FILTER':
			if Uiy0XwPusDg4vAFc35oYdfGnOrV not in BVNnjYeCa3AfgTv0u6R: continue
			if oPrhaMp7AqmNnRjlXGI!=Uiy0XwPusDg4vAFc35oYdfGnOrV: continue
			elif len(items)<2:
				if Uiy0XwPusDg4vAFc35oYdfGnOrV==BVNnjYeCa3AfgTv0u6R[-1]:
					url = l9GNIMkR6FbWzpQZsYwEyAaU17v(url)
					u4umKHwecFUQAZo1YiBtC9baRlE(url)
				else: WYxFZIrRp6b(gANn35esloKUydOipfSMC6RD2,'SPECIFIED_FILTER___'+bIYSyA3BD1o4)
				return
			else:
				gANn35esloKUydOipfSMC6RD2 = l9GNIMkR6FbWzpQZsYwEyAaU17v(gANn35esloKUydOipfSMC6RD2)
				if Uiy0XwPusDg4vAFc35oYdfGnOrV==BVNnjYeCa3AfgTv0u6R[-1]: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع',gANn35esloKUydOipfSMC6RD2,511)
				else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع',gANn35esloKUydOipfSMC6RD2,515,'','',bIYSyA3BD1o4)
		elif type=='ALL_ITEMS_FILTER':
			if Uiy0XwPusDg4vAFc35oYdfGnOrV not in mwqMBcOe2Lj: continue
			WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'=0'
			z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'=0'
			bIYSyA3BD1o4 = WGiMcqkRetEJVrSI+'___'+z3wGSEWqVy1Qh5N
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع: '+name,gANn35esloKUydOipfSMC6RD2,514,'','',bIYSyA3BD1o4)
		dict[Uiy0XwPusDg4vAFc35oYdfGnOrV] = {}
		for c2eEflztvIX,q1rVywkMcKftIioS43LY in items:
			if q1rVywkMcKftIioS43LY in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
			if 'مصنفات أخرى' in q1rVywkMcKftIioS43LY: continue
			if 'الكل' in q1rVywkMcKftIioS43LY: continue
			if 'اللغة' in q1rVywkMcKftIioS43LY: continue
			q1rVywkMcKftIioS43LY = q1rVywkMcKftIioS43LY.replace('قائمة ','')
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[Uiy0XwPusDg4vAFc35oYdfGnOrV][c2eEflztvIX] = q1rVywkMcKftIioS43LY
			WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'='+q1rVywkMcKftIioS43LY
			z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'='+c2eEflztvIX
			eoaO40TC7VF1tEuwjQp2x = WGiMcqkRetEJVrSI+'___'+z3wGSEWqVy1Qh5N
			if name: title = q1rVywkMcKftIioS43LY+' :'+name
			else: title = q1rVywkMcKftIioS43LY
			if type=='ALL_ITEMS_FILTER': uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,514,'','',eoaO40TC7VF1tEuwjQp2x)
			elif type=='SPECIFIED_FILTER' and BVNnjYeCa3AfgTv0u6R[-2]+'=' in lvUP2GeNjyVOHKJxcBoun3Z:
				UcmHDPlLWaSf = VVTeCG1Jbu7B(z3wGSEWqVy1Qh5N,url)
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,UcmHDPlLWaSf,511)
			else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,515,'','',eoaO40TC7VF1tEuwjQp2x)
	return
def mltWBSPJz5H4VRdCAa1(cGYIMSHDj85d3f4ZW2t0bnNkKP,mode):
	cGYIMSHDj85d3f4ZW2t0bnNkKP = cGYIMSHDj85d3f4ZW2t0bnNkKP.replace('=&','=0&')
	cGYIMSHDj85d3f4ZW2t0bnNkKP = cGYIMSHDj85d3f4ZW2t0bnNkKP.strip('&')
	OXjBliFSwIQCmg47 = {}
	if '=' in cGYIMSHDj85d3f4ZW2t0bnNkKP:
		items = cGYIMSHDj85d3f4ZW2t0bnNkKP.split('&')
		for TMaJdc0xOFKNf in items:
			b1EWu6sYaRk0FXUx8HVvNBQort43,c2eEflztvIX = TMaJdc0xOFKNf.split('=')
			OXjBliFSwIQCmg47[b1EWu6sYaRk0FXUx8HVvNBQort43] = c2eEflztvIX
	LL3oamJbwkYcNDrH5 = ''
	for key in mwqMBcOe2Lj:
		if key in list(OXjBliFSwIQCmg47.keys()): c2eEflztvIX = OXjBliFSwIQCmg47[key]
		else: c2eEflztvIX = '0'
		if '%' not in c2eEflztvIX: c2eEflztvIX = QQXTVNve6DMHBp4scG170kR2lWY(c2eEflztvIX)
		if mode=='modified_values' and c2eEflztvIX!='0': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+' + '+c2eEflztvIX
		elif mode=='modified_filters' and c2eEflztvIX!='0': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+'&'+key+'='+c2eEflztvIX
		elif mode=='all_filters': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+'&'+key+'='+c2eEflztvIX
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.strip(' + ')
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.strip('&')
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.replace('=0','=')
	return LL3oamJbwkYcNDrH5
BVNnjYeCa3AfgTv0u6R = []
mwqMBcOe2Lj = []
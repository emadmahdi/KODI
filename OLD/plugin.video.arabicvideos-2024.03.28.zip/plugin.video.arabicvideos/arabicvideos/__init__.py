# -*- coding: utf-8 -*-
import sys as vdo2FnhPmAVRMJQZ0EIG8
XzBpdMGJhHZKC8Yveki5qb1jT4nQUg = vdo2FnhPmAVRMJQZ0EIG8.version_info [0] == 2
vykERrdZlF5K = 2048
GG02h4EolRYTs3iv = 7
def tci7BbCy6gT9MXkOEzhm (xVtfmzjd6RSsBEk2o34aHWC):
	global jMo7iTRkq0n1NPa35xheAVlbt
	oAJijr7NHwnfUGqyd8Ru6EImOtv = ord (xVtfmzjd6RSsBEk2o34aHWC [-1])
	wwpaJlB3bkXySOHFWUfoILC = xVtfmzjd6RSsBEk2o34aHWC [:-1]
	lqXRut6PnL = oAJijr7NHwnfUGqyd8Ru6EImOtv % len (wwpaJlB3bkXySOHFWUfoILC)
	rmaU71pZj3X = wwpaJlB3bkXySOHFWUfoILC [:lqXRut6PnL] + wwpaJlB3bkXySOHFWUfoILC [lqXRut6PnL:]
	if XzBpdMGJhHZKC8Yveki5qb1jT4nQUg:
		bbsiU0a49tw2dy = unicode () .join ([unichr (ord (Q9QUIWH6rK2BlmC) - vykERrdZlF5K - (ZXwWfDc9AF4yr2P + oAJijr7NHwnfUGqyd8Ru6EImOtv) % GG02h4EolRYTs3iv) for ZXwWfDc9AF4yr2P, Q9QUIWH6rK2BlmC in enumerate (rmaU71pZj3X)])
	else:
		bbsiU0a49tw2dy = str () .join ([chr (ord (Q9QUIWH6rK2BlmC) - vykERrdZlF5K - (ZXwWfDc9AF4yr2P + oAJijr7NHwnfUGqyd8Ru6EImOtv) % GG02h4EolRYTs3iv) for ZXwWfDc9AF4yr2P, Q9QUIWH6rK2BlmC in enumerate (rmaU71pZj3X)])
	return eval (bbsiU0a49tw2dy)
r3flT0zQPa5H7yXEgxJOt92Vc4Ao,cgtRBdXxSOk7WUfyDhPCls,cNaVb1vsT4qWOL0rpE=tci7BbCy6gT9MXkOEzhm,tci7BbCy6gT9MXkOEzhm,tci7BbCy6gT9MXkOEzhm
yruHDQOcB97ig,drHLAY5ENQFe2q9ptKGabo,qnPgZ9N15G6Oa8UpMASvLk=cNaVb1vsT4qWOL0rpE,cgtRBdXxSOk7WUfyDhPCls,r3flT0zQPa5H7yXEgxJOt92Vc4Ao
KKbpxUZnMcj6AJ4QdD,ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB,ggDRehOModi=qnPgZ9N15G6Oa8UpMASvLk,drHLAY5ENQFe2q9ptKGabo,yruHDQOcB97ig
xuztI5QWEKG70CPNdhk4vo6,bcgZJWV6UeNSkRA,shZ9eOcN2dJnPj=ggDRehOModi,ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB,KKbpxUZnMcj6AJ4QdD
BGhdkWsEvJjiMFTr3NLn1flU,nKLEi8CJumazx4qT,pcWq35MED2dtK=shZ9eOcN2dJnPj,bcgZJWV6UeNSkRA,xuztI5QWEKG70CPNdhk4vo6
yF29Xdsx35wI07Ce4,XikqnGVSK4v9d3uUICLhDxJyt1M,JLoPRXt93dpAB=pcWq35MED2dtK,nKLEi8CJumazx4qT,BGhdkWsEvJjiMFTr3NLn1flU
wwplD0tEehqH3kYQXs,tZ3gsrTEdzA1S6LXa9WI5px,Nqj35AXg06euY1G2d4bSUMQ8wlr=JLoPRXt93dpAB,XikqnGVSK4v9d3uUICLhDxJyt1M,yF29Xdsx35wI07Ce4
bbw2eajMlG,M6PIj8gl1fno7wcqTksDEBK4bU,CgG4PuyxsLA8WDzh3FfteZvKQMdom9=Nqj35AXg06euY1G2d4bSUMQ8wlr,tZ3gsrTEdzA1S6LXa9WI5px,wwplD0tEehqH3kYQXs
iifPEY9ABNzTQp,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ,PtXn0k9G3ocHRg=CgG4PuyxsLA8WDzh3FfteZvKQMdom9,M6PIj8gl1fno7wcqTksDEBK4bU,bbw2eajMlG
Tgoa16jMxvYX2,vvBChXmSty,InKG0i2r6hHDvgd=PtXn0k9G3ocHRg,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ,iifPEY9ABNzTQp
OyJ1o4AvmWlB75UkFRX,usaZLwSGe1k6VDp570yhB4bzWPiFq,oUlIcGH2JuWFLvimMXyBQdzK06ge=InKG0i2r6hHDvgd,vvBChXmSty,Tgoa16jMxvYX2
from z9NBdJU7p6 import *
aUVSgO2ebjwX5iqPykC = vvBChXmSty(u"ࠧࡊࡐࡌࡘࠬૢ")
l0SAerv8zGH2Wa(pcWq35MED2dtK(u"ࠨࡐࡒࡘࡎࡉࡅࠨૣ"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠩ૤"))
ttpQZRUwEjhfdOqn = QPTqwDCWalLdRB9jrkAbIz(O0Dm45eTJi8rlWUCQLbMducERHp)
afxYgsnGTdAHePVBK,ffAnyTIUapotW4dS6sbC,GMfo7WypIsRin9HKEZQduYhDetFJOS,Fx86vaQXEZeSBDAhmgC9zl7j2fs,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,TwPt5qAHlrOsQ,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv = ttpQZRUwEjhfdOqn
KalY9RbZWxhOsV0 = int(Fx86vaQXEZeSBDAhmgC9zl7j2fs)
eDvzfWdXZnlMEiboY5j1P = bMIascyFJ2x43E0C7glTB91h8qz.getInfoLabel(ggDRehOModi(u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫ૥"))
eDvzfWdXZnlMEiboY5j1P = eDvzfWdXZnlMEiboY5j1P.replace(Qa68jZXt0gBH,vvBChXmSty(u"ࠫࠬ૦")).replace(RQ0HpOfhFDoJdtl,Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠬ࠭૧"))
if KalY9RbZWxhOsV0==xuztI5QWEKG70CPNdhk4vo6(u"࠵࠺࠵ଏ"): CWL8J3MFDRmtk029PKhsp6Zgbv = ggDRehOModi(u"࡙࠭ࠠࠡࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࡠࠦࠧ૨")+qkSQU3saP0D7OvynNzH4F2BKJuilT+XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧࠡ࡟ࠣࠤࠥࡑ࡯ࡥ࡫࠽ࠤࡠࠦࠧ૩")+UFdmsKIGAx0JrVCe+XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠨࠢࡠࠫ૪")
else:
	NN7wZQiD1dMWIXca4Oozrb38gn = P2o6ZDHeW790pSQqucvnxzILVUX(O0Dm45eTJi8rlWUCQLbMducERHp).replace(Tgoa16jMxvYX2(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ૫"),cgtRBdXxSOk7WUfyDhPCls(u"ࠪࠫ૬")).replace(cNaVb1vsT4qWOL0rpE(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ૭"),cgtRBdXxSOk7WUfyDhPCls(u"ࠬ࠭૮"))
	NN7wZQiD1dMWIXca4Oozrb38gn = NN7wZQiD1dMWIXca4Oozrb38gn.replace(bcgZJWV6UeNSkRA(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ૯"),cgtRBdXxSOk7WUfyDhPCls(u"ࠧࠨ૰")).strip(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠨࠢࠪ૱"))
	NN7wZQiD1dMWIXca4Oozrb38gn = NN7wZQiD1dMWIXca4Oozrb38gn.replace(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠩࠣࠤࠥࠦࠧ૲"),Tgoa16jMxvYX2(u"ࠪࠤࠬ૳")).replace(pcWq35MED2dtK(u"ࠫࠥࠦࠠࠨ૴"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠬࠦࠧ૵")).replace(KKbpxUZnMcj6AJ4QdD(u"࠭ࠠࠡࠩ૶"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠧࠡࠩ૷"))
	CWL8J3MFDRmtk029PKhsp6Zgbv = shZ9eOcN2dJnPj(u"ࠨࠢࠣࠤࡑࡧࡢࡦ࡮࠽ࠤࡠࠦࠧ૸")+eDvzfWdXZnlMEiboY5j1P+r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠩࠣࡡࠥࠦࠠࡎࡱࡧࡩ࠿࡛ࠦࠡࠩૹ")+Fx86vaQXEZeSBDAhmgC9zl7j2fs+wwplD0tEehqH3kYQXs(u"ࠪࠤࡢࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪૺ")+NN7wZQiD1dMWIXca4Oozrb38gn+yruHDQOcB97ig(u"ࠫࠥࡣࠧૻ")
l0SAerv8zGH2Wa(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠬࡔࡏࡕࡋࡆࡉࠬૼ"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+CWL8J3MFDRmtk029PKhsp6Zgbv)
qsweAy3DUxWL = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(tZ3gsrTEdzA1S6LXa9WI5px(u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪ૽"))
eeYoW6fXUyO0rCSkz = r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࡈࡤࡰࡸ࡫କ") if qsweAy3DUxWL==qkSQU3saP0D7OvynNzH4F2BKJuilT else Tgoa16jMxvYX2(u"ࡕࡴࡸࡩଔ")
if not eeYoW6fXUyO0rCSkz and KalY9RbZWxhOsV0 in [r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠶࠸࠻ଐ"),wwplD0tEehqH3kYQXs(u"࠼࠷࠵଑")]:
	VhIGD8gM4BpZ3wsCPqQvK5L = str(aiSY4yFdLmPH2zenlMpv[XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ૾")])
	aUVSgO2ebjwX5iqPykC = qnPgZ9N15G6Oa8UpMASvLk(u"ࠨ࡫ࡳࡸࡻ࠭૿") if KalY9RbZWxhOsV0==XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠸࠳࠶଒") else iifPEY9ABNzTQp(u"ࠩࡰ࠷ࡺ࠭଀")
	UUSPoh1ckMtVexN6u = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠪࡥࡻ࠴ࠧଁ")+aUVSgO2ebjwX5iqPykC+tZ3gsrTEdzA1S6LXa9WI5px(u"ࠫ࠳ࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡠࠩଂ")+VhIGD8gM4BpZ3wsCPqQvK5L)
	A3oYrN6fkB9PX4ian = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(vvBChXmSty(u"ࠬࡧࡶ࠯ࠩଃ")+aUVSgO2ebjwX5iqPykC+qnPgZ9N15G6Oa8UpMASvLk(u"࠭࠮ࡳࡧࡩࡩࡷ࡫ࡲࡠࠩ଄")+VhIGD8gM4BpZ3wsCPqQvK5L)
	if UUSPoh1ckMtVexN6u or A3oYrN6fkB9PX4ian:
		GMfo7WypIsRin9HKEZQduYhDetFJOS += cgtRBdXxSOk7WUfyDhPCls(u"ࠧࡽࠩଅ")
		if UUSPoh1ckMtVexN6u: GMfo7WypIsRin9HKEZQduYhDetFJOS += cNaVb1vsT4qWOL0rpE(u"ࠨࠨࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧଆ")+UUSPoh1ckMtVexN6u
		if A3oYrN6fkB9PX4ian: GMfo7WypIsRin9HKEZQduYhDetFJOS += wwplD0tEehqH3kYQXs(u"ࠩࠩࡖࡪ࡬ࡥࡳࡧࡵࡁࠬଇ")+A3oYrN6fkB9PX4ian
		GMfo7WypIsRin9HKEZQduYhDetFJOS = GMfo7WypIsRin9HKEZQduYhDetFJOS.replace(JLoPRXt93dpAB(u"ࠪࢀࠫ࠭ଈ"),wwplD0tEehqH3kYQXs(u"ࠫࢁ࠭ଉ"))
	xf9RPF4uksKyc = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(PtXn0k9G3ocHRg(u"ࠬࡧࡶ࠯ࠩଊ")+aUVSgO2ebjwX5iqPykC+JLoPRXt93dpAB(u"࠭࠮ࡴࡧࡵࡺࡪࡸ࡟ࠨଋ")+VhIGD8gM4BpZ3wsCPqQvK5L)
	if xf9RPF4uksKyc:
		T2TYow5r1aludEQvXiHZA = u5h2Rckvw1E.findall(Tgoa16jMxvYX2(u"ࠧ࠻࠱࠲ࠬ࠳࠰࠿ࠪ࠱ࠪଌ"),GMfo7WypIsRin9HKEZQduYhDetFJOS,u5h2Rckvw1E.DOTALL)
		GMfo7WypIsRin9HKEZQduYhDetFJOS = GMfo7WypIsRin9HKEZQduYhDetFJOS.replace(T2TYow5r1aludEQvXiHZA[usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠰ଓ")],xf9RPF4uksKyc)
	aUVSgO2ebjwX5iqPykC = aUVSgO2ebjwX5iqPykC.upper()
	om1iZDWnrhGa2SLB9O4kfxYbqU(GMfo7WypIsRin9HKEZQduYhDetFJOS,aUVSgO2ebjwX5iqPykC,afxYgsnGTdAHePVBK)
else:
	from LXgKztbkOf import vvZxzV4CkyoPTs,DB4TY9qlwEJ,DFuBiZvslcm94Ia
	LdvB61qxSDsOWlhmXnAgozEfPp4Ky = n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠨࠩ଍")
	vvZxzV4CkyoPTs(shZ9eOcN2dJnPj(u"ࠩࡶࡸࡦࡸࡴࠨ଎"))
	try: DB4TY9qlwEJ(ttpQZRUwEjhfdOqn,eDvzfWdXZnlMEiboY5j1P)
	except Exception as lHqTf6UMy5pvbe0nK: LdvB61qxSDsOWlhmXnAgozEfPp4Ky = BPSEU6WvQRnxV.format_exc()
	DFuBiZvslcm94Ia(LdvB61qxSDsOWlhmXnAgozEfPp4Ky)
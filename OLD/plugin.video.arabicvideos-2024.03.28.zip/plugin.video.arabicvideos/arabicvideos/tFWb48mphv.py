# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'SHAHID4U'
headers = ''
tiCRYyX1bWd40Ir3PafQu = '_SH4_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==110: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==111: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,text)
	elif mode==112: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==113: vS7JufTVsBxw52 = GA2KIlbOsoYtxpkDF71(url,True)
	elif mode==114: vS7JufTVsBxw52 = WYxFZIrRp6b(url,'FULL_FILTER___'+text)
	elif mode==115: vS7JufTVsBxw52 = WYxFZIrRp6b(url,'DEFINED_FILTER___'+text)
	elif mode==116: vS7JufTVsBxw52 = GA2KIlbOsoYtxpkDF71(url,False)
	elif mode==119: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	jGX4sfdrWaeZpA1VyvTK,url,RoQL91PphqCJg4W0e6Fnsl = Td6K1l0UMsxXZQf8yGLVF7bokN9tJq(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'GET',yONJxHER9BIDPpTV4YsWmc0n,'shahid4u','شاهد فوريو - Shahid 4u','facebook.com/shahid4u.net',headers)
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',119,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فلتر محدد',jGX4sfdrWaeZpA1VyvTK,115)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فلتر كامل',jGX4sfdrWaeZpA1VyvTK,114)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'المميزة',jGX4sfdrWaeZpA1VyvTK,111,'','','featured')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('simple-filter(.*?)adv-filter',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not cWafzb4HoG1Em3Jwxu6C7vZsVi:
		xl9MFt1AmY0GrkENug8n('','','موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for filter,pGjsvdyHfM,title in items:
			url = jGX4sfdrWaeZpA1VyvTK+filter
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,url,111,pGjsvdyHfM,'',filter)
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="dropdown"(.*?)<script>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			title = title.replace('\n','').replace('\r','').strip(' ')
			if title in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
			if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = jGX4sfdrWaeZpA1VyvTK+ekTrZlFMu0Kf5QztEnhAs
			if 'netflix' in ekTrZlFMu0Kf5QztEnhAs: title = 'نيتفلكس'
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,111)
	return oo9SgGkiDbs3HRn7z8
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,lcOov4Kz0uBairTpLxXgAqIt72mk='',RoQL91PphqCJg4W0e6Fnsl=''):
	if not RoQL91PphqCJg4W0e6Fnsl: RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'',headers,'','','SHAHID4U-TITLES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi,items,yn8DkpE5etF3WiUmfSO = [],[],[]
	if lcOov4Kz0uBairTpLxXgAqIt72mk=='featured': cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('glide__slides(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	else: cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('shows-container(.*?)pagination',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not cWafzb4HoG1Em3Jwxu6C7vZsVi: return
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	if not items: items = u5h2Rckvw1E.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)</h4>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	dR94SHEmDA8nflN = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
		if 'javascript' in ekTrZlFMu0Kf5QztEnhAs: continue
		ekTrZlFMu0Kf5QztEnhAs = P2o6ZDHeW790pSQqucvnxzILVUX(ekTrZlFMu0Kf5QztEnhAs).strip('/')
		title = uTUNPkVwCMKiD5gHLaj(title)
		title = title.strip(' ')
		zAjwuoRY98mXN6xvE = u5h2Rckvw1E.findall('(.*?) الحلقة \d+',title,u5h2Rckvw1E.DOTALL)
		if '/film/' in ekTrZlFMu0Kf5QztEnhAs or 'فيلم' in ekTrZlFMu0Kf5QztEnhAs or any(c2eEflztvIX in title for c2eEflztvIX in dR94SHEmDA8nflN):
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,112,pGjsvdyHfM)
		elif zAjwuoRY98mXN6xvE and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + zAjwuoRY98mXN6xvE[0]
			if title not in yn8DkpE5etF3WiUmfSO:
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,113,pGjsvdyHfM)
				yn8DkpE5etF3WiUmfSO.append(title)
		elif '/actor/' in ekTrZlFMu0Kf5QztEnhAs:
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,111,pGjsvdyHfM)
		elif '/series/' in ekTrZlFMu0Kf5QztEnhAs and '/list' not in url:
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'/list'
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,111,pGjsvdyHfM)
		elif '/list' in url and 'حلقة' in title:
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,112,pGjsvdyHfM)
		else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,113,pGjsvdyHfM)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"pagination"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		if lcOov4Kz0uBairTpLxXgAqIt72mk!='search': items = u5h2Rckvw1E.findall('(updateQuery).*?>(.+?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		else: items = u5h2Rckvw1E.findall('<li>.*?href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if lcOov4Kz0uBairTpLxXgAqIt72mk!='search':
				title = title.replace('\n','').replace('\r','')
				if '?' in url: ekTrZlFMu0Kf5QztEnhAs = url+'&page='+title
				else: ekTrZlFMu0Kf5QztEnhAs = url+'?page='+title
			title = uTUNPkVwCMKiD5gHLaj(title)
			if title: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+title,ekTrZlFMu0Kf5QztEnhAs,111,'','',lcOov4Kz0uBairTpLxXgAqIt72mk)
	return
def GA2KIlbOsoYtxpkDF71(url,nUOvdIy2Wq):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'',headers,'','','SHAHID4U-EPISODES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('items d-flex(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if len(cWafzb4HoG1Em3Jwxu6C7vZsVi)>1:
		if '/season/' in cWafzb4HoG1Em3Jwxu6C7vZsVi[0]: EKhwoNlubG5A7xaJW2UOg1,Ez1AbVgerRU0YimHu45t9DI7qM = cWafzb4HoG1Em3Jwxu6C7vZsVi[0],cWafzb4HoG1Em3Jwxu6C7vZsVi[1]
		else: EKhwoNlubG5A7xaJW2UOg1,Ez1AbVgerRU0YimHu45t9DI7qM = cWafzb4HoG1Em3Jwxu6C7vZsVi[1],cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	else: EKhwoNlubG5A7xaJW2UOg1,Ez1AbVgerRU0YimHu45t9DI7qM = cWafzb4HoG1Em3Jwxu6C7vZsVi[0],cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	for k0G4LTYt93po in range(2):
		if nUOvdIy2Wq: mode,type,lmO2YJGr6tCV = 116,'folder',EKhwoNlubG5A7xaJW2UOg1
		else: mode,type,lmO2YJGr6tCV = 112,'video',Ez1AbVgerRU0YimHu45t9DI7qM
		items = u5h2Rckvw1E.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if nUOvdIy2Wq and len(items)<2:
			nUOvdIy2Wq = False
			continue
		for ekTrZlFMu0Kf5QztEnhAs,OzY3XIhgiZJsGHMkKmSj,cMpjL2oavyVwKHBPn8EdhYqxSUk in items:
			title = OzY3XIhgiZJsGHMkKmSj+' '+cMpjL2oavyVwKHBPn8EdhYqxSUk
			uQNUfbZx9yj0F(type,tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,mode)
		break
	if not items and '/episodes' in oo9SgGkiDbs3HRn7z8:
		ZO5xPgV6Si8IuTa9sb = u5h2Rckvw1E.findall('class="breadcrumb"(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if ZO5xPgV6Si8IuTa9sb:
			lmO2YJGr6tCV = ZO5xPgV6Si8IuTa9sb[0]
			lQUf3AY258LeWch = u5h2Rckvw1E.findall('href="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			if len(lQUf3AY258LeWch)>2:
				ekTrZlFMu0Kf5QztEnhAs = lQUf3AY258LeWch[2]+'list'
				ll0a2AwztChcpsDUMi4rGW3b61XZES(ekTrZlFMu0Kf5QztEnhAs)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	EaBeVhOsHYg8wub = []
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',url,'',headers,'','','SHAHID4U-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="actions(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not cWafzb4HoG1Em3Jwxu6C7vZsVi: return
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	lQUf3AY258LeWch = u5h2Rckvw1E.findall('href="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	Wa9rqEzB40DHg = '/watch/' in lmO2YJGr6tCV
	download = '/download/' in lmO2YJGr6tCV
	if   Wa9rqEzB40DHg and not download: EEi1VJmKpd3fn5Bl,cilAPFqQruEj4Hekotb = lQUf3AY258LeWch[0],''
	elif not Wa9rqEzB40DHg and download: EEi1VJmKpd3fn5Bl,cilAPFqQruEj4Hekotb = '',lQUf3AY258LeWch[0]
	elif Wa9rqEzB40DHg and download: EEi1VJmKpd3fn5Bl,cilAPFqQruEj4Hekotb = lQUf3AY258LeWch[0],lQUf3AY258LeWch[1]
	else: EEi1VJmKpd3fn5Bl,cilAPFqQruEj4Hekotb = '',''
	if Wa9rqEzB40DHg:
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',EEi1VJmKpd3fn5Bl,'',headers,'','','SHAHID4U-PLAY-2nd')
		ZCOosjaQ8x9HDKSVGM6LwW2vy = RoQL91PphqCJg4W0e6Fnsl.content
		RfTOHSzgpA = u5h2Rckvw1E.findall('let servers(.*?)player',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.IGNORECASE)
		if RfTOHSzgpA:
			CyEMW1Sh3GtsbRUzN = RfTOHSzgpA[0]
			EbnzqW0GvY2dNMBpshU6fugi = u5h2Rckvw1E.findall('"name":"(.*?)".*?"url":"(.*?)"',CyEMW1Sh3GtsbRUzN,u5h2Rckvw1E.DOTALL)
			for title,ekTrZlFMu0Kf5QztEnhAs in EbnzqW0GvY2dNMBpshU6fugi:
				ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.replace('\\/','/')
				ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+title+'__watch'
				EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	if download:
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',cilAPFqQruEj4Hekotb,'',headers,'','','SHAHID4U-PLAY-3rd')
		ZCOosjaQ8x9HDKSVGM6LwW2vy = RoQL91PphqCJg4W0e6Fnsl.content
		RfTOHSzgpA = u5h2Rckvw1E.findall('"servers"(.*?)info-container',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)
		if RfTOHSzgpA:
			CyEMW1Sh3GtsbRUzN = RfTOHSzgpA[0]
			EbnzqW0GvY2dNMBpshU6fugi = u5h2Rckvw1E.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',CyEMW1Sh3GtsbRUzN,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,title,ohAHUqdbWFi8D1L4Xwzus0f3RYv in EbnzqW0GvY2dNMBpshU6fugi:
				ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+title+'__download'+'____'+ohAHUqdbWFi8D1L4Xwzus0f3RYv
				EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(EaBeVhOsHYg8wub,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if not search:
		search = FBrXsYeCEp3()
		if not search: return
	search = search.replace(' ','+')
	url = yONJxHER9BIDPpTV4YsWmc0n+'/search?s='+search
	jGX4sfdrWaeZpA1VyvTK,gANn35esloKUydOipfSMC6RD2,p8HVUxN5v3WZfF4Gt7o0gLOdSiI = Td6K1l0UMsxXZQf8yGLVF7bokN9tJq(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'GET',url,'shahid4u','شاهد فوريو - Shahid 4u','facebook.com/shahid4u.net',headers)
	ll0a2AwztChcpsDUMi4rGW3b61XZES(gANn35esloKUydOipfSMC6RD2,'search',p8HVUxN5v3WZfF4Gt7o0gLOdSiI)
	return
def C50mPGacMg7V34she6UR8LjfSt1(url):
	url = url.split('/smartemadfilter?')[0]
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',url,'',headers,'','','SHAHID4U-GET_FILTERS_BLOCKS-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cGdHRiwvptVXQlzE8ZUgB0aJo9x = []
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('adv-filter(.*?)shows-container',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		cGdHRiwvptVXQlzE8ZUgB0aJo9x = u5h2Rckvw1E.findall('''updateQuery\('(.*?)'.*?value>(.*?)<(.*?)</select''',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		r502OcNXkfwEI1suJF8mWTK9Vp7RlA,woSL8eJ219qdksrZFIaPA,ppZ9muD1GkPnFRX52jxBUIy = zip(*cGdHRiwvptVXQlzE8ZUgB0aJo9x)
		cGdHRiwvptVXQlzE8ZUgB0aJo9x = zip(woSL8eJ219qdksrZFIaPA,r502OcNXkfwEI1suJF8mWTK9Vp7RlA,ppZ9muD1GkPnFRX52jxBUIy)
	return cGdHRiwvptVXQlzE8ZUgB0aJo9x
def zzsLCt0FpUQEeMoYWBqGlZJP6rn4(lmO2YJGr6tCV):
	items = u5h2Rckvw1E.findall('value="(.*?)".*?>\s*(.*?)\s*<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	return items
def BiOwcEL7XY1Fa5nWJ(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	TImV9B8wLag3trpRZWvAqQPN5 = url.split('/smartemadfilter?')[0]
	GDJeByAH5fRS9I = hmcFWJUgiAuGk(url,'url')
	url = url.replace(TImV9B8wLag3trpRZWvAqQPN5,GDJeByAH5fRS9I)
	url = url.replace('/smartemadfilter?','/?')
	return url
lKLq39dBYWsOr7kGypxM6Dw = ['quality','year','genre','category']
FAbV2PnyJD8M0UowB9hRS4TkN = ['category','genre','year']
def WYxFZIrRp6b(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': lvUP2GeNjyVOHKJxcBoun3Z,MoELTBDgQeaJrl0zYUmKCH = '',''
	else: lvUP2GeNjyVOHKJxcBoun3Z,MoELTBDgQeaJrl0zYUmKCH = filter.split('___')
	if type=='DEFINED_FILTER':
		if FAbV2PnyJD8M0UowB9hRS4TkN[0]+'=' not in lvUP2GeNjyVOHKJxcBoun3Z: oPrhaMp7AqmNnRjlXGI = FAbV2PnyJD8M0UowB9hRS4TkN[0]
		for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(len(FAbV2PnyJD8M0UowB9hRS4TkN[0:-1])):
			if FAbV2PnyJD8M0UowB9hRS4TkN[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE]+'=' in lvUP2GeNjyVOHKJxcBoun3Z: oPrhaMp7AqmNnRjlXGI = FAbV2PnyJD8M0UowB9hRS4TkN[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE+1]
		WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&'+oPrhaMp7AqmNnRjlXGI+'=0'
		z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&'+oPrhaMp7AqmNnRjlXGI+'=0'
		bIYSyA3BD1o4 = WGiMcqkRetEJVrSI.strip('&')+'___'+z3wGSEWqVy1Qh5N.strip('&')
		TBFfiRI52ZmKwO1JLSD = mltWBSPJz5H4VRdCAa1(MoELTBDgQeaJrl0zYUmKCH,'modified_filters')
		gANn35esloKUydOipfSMC6RD2 = url+'/smartemadfilter?'+TBFfiRI52ZmKwO1JLSD
	elif type=='FULL_FILTER':
		lv2uANOtVxE8RTa7bYHqLog1Bd = mltWBSPJz5H4VRdCAa1(lvUP2GeNjyVOHKJxcBoun3Z,'modified_values')
		lv2uANOtVxE8RTa7bYHqLog1Bd = P2o6ZDHeW790pSQqucvnxzILVUX(lv2uANOtVxE8RTa7bYHqLog1Bd)
		if MoELTBDgQeaJrl0zYUmKCH!='': MoELTBDgQeaJrl0zYUmKCH = mltWBSPJz5H4VRdCAa1(MoELTBDgQeaJrl0zYUmKCH,'modified_filters')
		if MoELTBDgQeaJrl0zYUmKCH=='': gANn35esloKUydOipfSMC6RD2 = url
		else: gANn35esloKUydOipfSMC6RD2 = url+'/smartemadfilter?'+MoELTBDgQeaJrl0zYUmKCH
		UcmHDPlLWaSf = BiOwcEL7XY1Fa5nWJ(gANn35esloKUydOipfSMC6RD2)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'أظهار قائمة الفيديو التي تم اختيارها ',UcmHDPlLWaSf,111)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+' [[   '+lv2uANOtVxE8RTa7bYHqLog1Bd+'   ]]',UcmHDPlLWaSf,111)
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cGdHRiwvptVXQlzE8ZUgB0aJo9x = C50mPGacMg7V34she6UR8LjfSt1(url)
	dict = {}
	for name,Uiy0XwPusDg4vAFc35oYdfGnOrV,lmO2YJGr6tCV in cGdHRiwvptVXQlzE8ZUgB0aJo9x:
		name = name.replace('كل ','')
		items = zzsLCt0FpUQEeMoYWBqGlZJP6rn4(lmO2YJGr6tCV)
		if '=' not in gANn35esloKUydOipfSMC6RD2: gANn35esloKUydOipfSMC6RD2 = url
		if type=='DEFINED_FILTER':
			if oPrhaMp7AqmNnRjlXGI!=Uiy0XwPusDg4vAFc35oYdfGnOrV: continue
			elif len(items)<2:
				if Uiy0XwPusDg4vAFc35oYdfGnOrV==FAbV2PnyJD8M0UowB9hRS4TkN[-1]:
					UcmHDPlLWaSf = BiOwcEL7XY1Fa5nWJ(gANn35esloKUydOipfSMC6RD2)
					ll0a2AwztChcpsDUMi4rGW3b61XZES(UcmHDPlLWaSf)
				else: WYxFZIrRp6b(gANn35esloKUydOipfSMC6RD2,'DEFINED_FILTER___'+bIYSyA3BD1o4)
				return
			else:
				if Uiy0XwPusDg4vAFc35oYdfGnOrV==FAbV2PnyJD8M0UowB9hRS4TkN[-1]:
					UcmHDPlLWaSf = BiOwcEL7XY1Fa5nWJ(gANn35esloKUydOipfSMC6RD2)
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع',UcmHDPlLWaSf,111)
				else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع',gANn35esloKUydOipfSMC6RD2,115,'','',bIYSyA3BD1o4)
		elif type=='FULL_FILTER':
			WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'=0'
			z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'=0'
			bIYSyA3BD1o4 = WGiMcqkRetEJVrSI+'___'+z3wGSEWqVy1Qh5N
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع :'+name,gANn35esloKUydOipfSMC6RD2,114,'','',bIYSyA3BD1o4)
		dict[Uiy0XwPusDg4vAFc35oYdfGnOrV] = {}
		for c2eEflztvIX,q1rVywkMcKftIioS43LY in items:
			if c2eEflztvIX=='196533': q1rVywkMcKftIioS43LY = 'أفلام نيتفلكس'
			elif c2eEflztvIX=='196531': q1rVywkMcKftIioS43LY = 'مسلسلات نيتفلكس'
			if q1rVywkMcKftIioS43LY in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
			dict[Uiy0XwPusDg4vAFc35oYdfGnOrV][c2eEflztvIX] = q1rVywkMcKftIioS43LY
			WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'='+q1rVywkMcKftIioS43LY
			z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'='+c2eEflztvIX
			eoaO40TC7VF1tEuwjQp2x = WGiMcqkRetEJVrSI+'___'+z3wGSEWqVy1Qh5N
			title = q1rVywkMcKftIioS43LY+' :'#+dict[Uiy0XwPusDg4vAFc35oYdfGnOrV]['0']
			title = q1rVywkMcKftIioS43LY+' :'+name
			if type=='FULL_FILTER': uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,114,'','',eoaO40TC7VF1tEuwjQp2x)
			elif type=='DEFINED_FILTER' and FAbV2PnyJD8M0UowB9hRS4TkN[-2]+'=' in lvUP2GeNjyVOHKJxcBoun3Z:
				TBFfiRI52ZmKwO1JLSD = mltWBSPJz5H4VRdCAa1(z3wGSEWqVy1Qh5N,'modified_filters')
				gANn35esloKUydOipfSMC6RD2 = url+'/smartemadfilter?'+TBFfiRI52ZmKwO1JLSD
				UcmHDPlLWaSf = BiOwcEL7XY1Fa5nWJ(gANn35esloKUydOipfSMC6RD2)
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,UcmHDPlLWaSf,111)
			else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,115,'','',eoaO40TC7VF1tEuwjQp2x)
	return
def mltWBSPJz5H4VRdCAa1(cGYIMSHDj85d3f4ZW2t0bnNkKP,mode):
	cGYIMSHDj85d3f4ZW2t0bnNkKP = cGYIMSHDj85d3f4ZW2t0bnNkKP.replace('=&','=0&')
	cGYIMSHDj85d3f4ZW2t0bnNkKP = cGYIMSHDj85d3f4ZW2t0bnNkKP.strip('&')
	OXjBliFSwIQCmg47 = {}
	if '=' in cGYIMSHDj85d3f4ZW2t0bnNkKP:
		items = cGYIMSHDj85d3f4ZW2t0bnNkKP.split('&')
		for TMaJdc0xOFKNf in items:
			b1EWu6sYaRk0FXUx8HVvNBQort43,c2eEflztvIX = TMaJdc0xOFKNf.split('=')
			OXjBliFSwIQCmg47[b1EWu6sYaRk0FXUx8HVvNBQort43] = c2eEflztvIX
	LL3oamJbwkYcNDrH5 = ''
	for key in lKLq39dBYWsOr7kGypxM6Dw:
		if key in list(OXjBliFSwIQCmg47.keys()): c2eEflztvIX = OXjBliFSwIQCmg47[key]
		else: c2eEflztvIX = '0'
		if '%' not in c2eEflztvIX: c2eEflztvIX = QQXTVNve6DMHBp4scG170kR2lWY(c2eEflztvIX)
		if mode=='modified_values' and c2eEflztvIX!='0': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+' + '+c2eEflztvIX
		elif mode=='modified_filters' and c2eEflztvIX!='0': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+'&'+key+'='+c2eEflztvIX
		elif mode=='all': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+'&'+key+'='+c2eEflztvIX
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.strip(' + ')
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.strip('&')
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.replace('=0','=')
	return LL3oamJbwkYcNDrH5
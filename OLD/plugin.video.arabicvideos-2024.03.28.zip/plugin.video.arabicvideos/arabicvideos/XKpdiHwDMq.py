# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'IFILM'
tiCRYyX1bWd40Ir3PafQu = '_IFL_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
nIo981YOgF2lx7JNevV4b0K6shuzA = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][1]
bhstdnoCPNl0KmF1QZOwBeq = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][2]
Ef3IMjWzo25Cv = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][3]
def cc03CYPLaxRfUKJb9eynFTr(mode,url,BzbaC0qYjMr2WXwsO,text):
	if   mode==20: vS7JufTVsBxw52 = DfTG60daj9snSUz1hKItqBOr3g()
	elif mode==21: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC(url)
	elif mode==22: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,BzbaC0qYjMr2WXwsO)
	elif mode==23: vS7JufTVsBxw52 = GA2KIlbOsoYtxpkDF71(url,BzbaC0qYjMr2WXwsO)
	elif mode==24: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url,text)
	elif mode==25: vS7JufTVsBxw52 = uOIQVtrnMSsCvHWqZh2jF30JdfPw(url)
	elif mode==27: vS7JufTVsBxw52 = SotcYExj3mF2Cn4dGKA(url)
	elif mode==28: vS7JufTVsBxw52 = Db7jhfi0NRdJp6a()
	elif mode==29: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def DfTG60daj9snSUz1hKItqBOr3g():
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'عربي',yONJxHER9BIDPpTV4YsWmc0n,21,'','101')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'English',nIo981YOgF2lx7JNevV4b0K6shuzA,21,'','101')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فارسى',bhstdnoCPNl0KmF1QZOwBeq,21,'','101')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فارسى 2',Ef3IMjWzo25Cv,21,'','101')
	return
def Db7jhfi0NRdJp6a():
	uQNUfbZx9yj0F('live',tiCRYyX1bWd40Ir3PafQu+'عربي',yONJxHER9BIDPpTV4YsWmc0n,27)
	uQNUfbZx9yj0F('live',tiCRYyX1bWd40Ir3PafQu+'English',nIo981YOgF2lx7JNevV4b0K6shuzA,27)
	uQNUfbZx9yj0F('live',tiCRYyX1bWd40Ir3PafQu+'فارسى',bhstdnoCPNl0KmF1QZOwBeq,27)
	uQNUfbZx9yj0F('live',tiCRYyX1bWd40Ir3PafQu+'فارسى 2',Ef3IMjWzo25Cv,27)
	return
def LitkEX0THgZadBAYn3hUIRoFC(PzufmMvpxolDQ57nbAGdkeWUsrw):
	aUVSgO2ebjwX5iqPykC = PzufmMvpxolDQ57nbAGdkeWUsrw
	if PzufmMvpxolDQ57nbAGdkeWUsrw=='IFILM-ARABIC': PzufmMvpxolDQ57nbAGdkeWUsrw = yONJxHER9BIDPpTV4YsWmc0n
	elif PzufmMvpxolDQ57nbAGdkeWUsrw=='IFILM-ENGLISH': PzufmMvpxolDQ57nbAGdkeWUsrw = nIo981YOgF2lx7JNevV4b0K6shuzA
	else: aUVSgO2ebjwX5iqPykC = ''
	AAj0QysJwULt1ha8gBXZTR = XgJPHjhAKR3sYe90D(PzufmMvpxolDQ57nbAGdkeWUsrw)
	if AAj0QysJwULt1ha8gBXZTR=='ar' or aUVSgO2ebjwX5iqPykC=='IFILM-ARABIC':
		l7ioqjZNXw0MPeWhpbxBAkfHrtsG = 'بحث في الموقع'
		SkhRwop2bcUdC9 = 'مسلسلات - حالية'
		yGAtUBdJLngm = 'مسلسلات - أحدث'
		HpzYh3NVQBJOPm297ivnRZ = 'مسلسلات - أبجدي'
		d679DQePJWclNAiSq1xkOMYFwhf = 'بث حي آي فيلم'
		XfAHRrIYSOG6sl = 'أفلام'
		U1FiYd8mr7szPDAt5vxMehBkRnub = 'موسيقى'
		F4jYyetWrz = 'برامج'
	elif AAj0QysJwULt1ha8gBXZTR=='en' or aUVSgO2ebjwX5iqPykC=='IFILM-ENGLISH':
		l7ioqjZNXw0MPeWhpbxBAkfHrtsG = 'Search in site'
		SkhRwop2bcUdC9 = 'Series - Current'
		yGAtUBdJLngm = 'Series - Latest'
		HpzYh3NVQBJOPm297ivnRZ = 'Series - Alphabet'
		d679DQePJWclNAiSq1xkOMYFwhf = 'Live iFilm channel'
		XfAHRrIYSOG6sl = 'Movies'
		U1FiYd8mr7szPDAt5vxMehBkRnub = 'Music'
		F4jYyetWrz = 'Shows'
	elif AAj0QysJwULt1ha8gBXZTR in ['fa','fa2']:
		l7ioqjZNXw0MPeWhpbxBAkfHrtsG = 'جستجو در سایت'
		SkhRwop2bcUdC9 = 'سريال - جاری'
		yGAtUBdJLngm = 'سريال - آخرین'
		HpzYh3NVQBJOPm297ivnRZ = 'سريال - الفبا'
		d679DQePJWclNAiSq1xkOMYFwhf = 'پخش زنده اي فيلم'
		XfAHRrIYSOG6sl = 'فيلم'
		U1FiYd8mr7szPDAt5vxMehBkRnub = 'موسيقى'
		F4jYyetWrz = 'برنامه ها'
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+l7ioqjZNXw0MPeWhpbxBAkfHrtsG,PzufmMvpxolDQ57nbAGdkeWUsrw,29,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('live',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+d679DQePJWclNAiSq1xkOMYFwhf,PzufmMvpxolDQ57nbAGdkeWUsrw,27)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	GGOfdq3ejKzUl6xAuN7WsSMEJv = ['Series','Program','Music']
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,PzufmMvpxolDQ57nbAGdkeWUsrw+'/home','','','','IFILM-MENU-1st')
	cWafzb4HoG1Em3Jwxu6C7vZsVi=u5h2Rckvw1E.findall('button-menu(.*?)/Contact',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if any(c2eEflztvIX in ekTrZlFMu0Kf5QztEnhAs for c2eEflztvIX in GGOfdq3ejKzUl6xAuN7WsSMEJv):
				url = PzufmMvpxolDQ57nbAGdkeWUsrw+ekTrZlFMu0Kf5QztEnhAs
				if 'Series' in ekTrZlFMu0Kf5QztEnhAs:
					uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+SkhRwop2bcUdC9,url,22,'','100')
					uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+yGAtUBdJLngm,url,22,'','101')
					uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+HpzYh3NVQBJOPm297ivnRZ,url,22,'','201')
				elif 'Film' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+XfAHRrIYSOG6sl,url,22,'','100')
				elif 'Music' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+U1FiYd8mr7szPDAt5vxMehBkRnub,url,25,'','101')
				elif 'Program' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+F4jYyetWrz,url,22,'','101')
	return oo9SgGkiDbs3HRn7z8
def uOIQVtrnMSsCvHWqZh2jF30JdfPw(url):
	PzufmMvpxolDQ57nbAGdkeWUsrw = pxXEuYRZnaBFrlf2Tv1(url)
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,url,'','','','IFILM-MUSIC_MENU-1st')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('Music-tools-header(.*?)Music-body',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	title = u5h2Rckvw1E.findall('<p>(.*?)</p>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)[0]
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,22,'','101')
	items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		ekTrZlFMu0Kf5QztEnhAs = PzufmMvpxolDQ57nbAGdkeWUsrw + ekTrZlFMu0Kf5QztEnhAs
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,23,'','101')
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,BzbaC0qYjMr2WXwsO):
	PzufmMvpxolDQ57nbAGdkeWUsrw = pxXEuYRZnaBFrlf2Tv1(url)
	AAj0QysJwULt1ha8gBXZTR = XgJPHjhAKR3sYe90D(url)
	type = url.split('/')[-1]
	Vs8Qe3ThflML2c4RjDxGyw = str(int(BzbaC0qYjMr2WXwsO)//100)
	BzbaC0qYjMr2WXwsO = str(int(BzbaC0qYjMr2WXwsO)%100)
	if type=='Series' and BzbaC0qYjMr2WXwsO=='0':
		oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,url,'','','','IFILM-TITLES-1st')
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('serial-body(.*?)class="row',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
			title = ffbxegm1XPSqIwp8i(title)
			title = uTUNPkVwCMKiD5gHLaj(title)
			ekTrZlFMu0Kf5QztEnhAs = PzufmMvpxolDQ57nbAGdkeWUsrw + ekTrZlFMu0Kf5QztEnhAs
			pGjsvdyHfM = PzufmMvpxolDQ57nbAGdkeWUsrw + QQXTVNve6DMHBp4scG170kR2lWY(pGjsvdyHfM)
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,23,pGjsvdyHfM,Vs8Qe3ThflML2c4RjDxGyw+'01')
	JeXvk7FjGa5CnU8TWDBP3EAItfHN=0
	if type=='Series': oPrhaMp7AqmNnRjlXGI='3'
	if type=='Film': oPrhaMp7AqmNnRjlXGI='5'
	if type=='Program': oPrhaMp7AqmNnRjlXGI='7'
	if type in ['Series','Program','Film'] and BzbaC0qYjMr2WXwsO!='0':
		gANn35esloKUydOipfSMC6RD2 = PzufmMvpxolDQ57nbAGdkeWUsrw+'/Home/PageingItem?category='+oPrhaMp7AqmNnRjlXGI+'&page='+BzbaC0qYjMr2WXwsO+'&size=30&orderby='+Vs8Qe3ThflML2c4RjDxGyw
		oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,gANn35esloKUydOipfSMC6RD2,'','','','IFILM-TITLES-2nd')
		items = u5h2Rckvw1E.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		for id,title,pGjsvdyHfM in items:
			title = ffbxegm1XPSqIwp8i(title)
			title = title.replace('\\','')
			title = title.replace('"','')
			JeXvk7FjGa5CnU8TWDBP3EAItfHN += 1
			ekTrZlFMu0Kf5QztEnhAs = PzufmMvpxolDQ57nbAGdkeWUsrw + '/' + type + '/Content/' + id
			pGjsvdyHfM = PzufmMvpxolDQ57nbAGdkeWUsrw + QQXTVNve6DMHBp4scG170kR2lWY(pGjsvdyHfM)
			if type=='Film': uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,24,pGjsvdyHfM,Vs8Qe3ThflML2c4RjDxGyw+'01')
			else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,23,pGjsvdyHfM,Vs8Qe3ThflML2c4RjDxGyw+'01')
	if type=='Music':
		oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,PzufmMvpxolDQ57nbAGdkeWUsrw+'/Music/Index?page='+BzbaC0qYjMr2WXwsO,'','','','IFILM-TITLES-3rd')
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('pagination-demo(.*?)pagination-demo',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
			JeXvk7FjGa5CnU8TWDBP3EAItfHN += 1
			pGjsvdyHfM = PzufmMvpxolDQ57nbAGdkeWUsrw + pGjsvdyHfM
			ekTrZlFMu0Kf5QztEnhAs = PzufmMvpxolDQ57nbAGdkeWUsrw + ekTrZlFMu0Kf5QztEnhAs
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,23,pGjsvdyHfM,'101')
	if JeXvk7FjGa5CnU8TWDBP3EAItfHN>20:
		title='صفحة '
		if AAj0QysJwULt1ha8gBXZTR=='en': title = 'Page '
		if AAj0QysJwULt1ha8gBXZTR=='fa': title = 'صفحه '
		if AAj0QysJwULt1ha8gBXZTR=='fa2': title = 'صفحه '
		for NNtAMv1eYUgKifTSrajGlmC in range(1,11) :
			if not BzbaC0qYjMr2WXwsO==str(NNtAMv1eYUgKifTSrajGlmC):
				KBzrJb7yeYoZdCI = '0'+str(NNtAMv1eYUgKifTSrajGlmC)
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title+str(NNtAMv1eYUgKifTSrajGlmC),url,22,'',Vs8Qe3ThflML2c4RjDxGyw+KBzrJb7yeYoZdCI[-2:])
	return
def GA2KIlbOsoYtxpkDF71(url,BzbaC0qYjMr2WXwsO):
	if not BzbaC0qYjMr2WXwsO: BzbaC0qYjMr2WXwsO = 0
	PzufmMvpxolDQ57nbAGdkeWUsrw = pxXEuYRZnaBFrlf2Tv1(url)
	d60XNEgVHxC3quhUoZnk9rsRTWDG = pxXEuYRZnaBFrlf2Tv1(url)
	AAj0QysJwULt1ha8gBXZTR = XgJPHjhAKR3sYe90D(url)
	KKSjuTY20EibkGc413C = url.split('/')
	id,type = KKSjuTY20EibkGc413C[-1],KKSjuTY20EibkGc413C[3]
	Vs8Qe3ThflML2c4RjDxGyw = str(int(BzbaC0qYjMr2WXwsO)//100)
	BzbaC0qYjMr2WXwsO = str(int(BzbaC0qYjMr2WXwsO)%100)
	JeXvk7FjGa5CnU8TWDBP3EAItfHN = 0
	if type=='Series':
		oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,url,'','','','IFILM-EPISODES-1st')
		items = u5h2Rckvw1E.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		title = ' - الحلقة '
		if AAj0QysJwULt1ha8gBXZTR=='en': title = ' - Episode '
		if AAj0QysJwULt1ha8gBXZTR=='fa': title = ' - قسمت '
		if AAj0QysJwULt1ha8gBXZTR=='fa2': title = ' - قسمت '
		if AAj0QysJwULt1ha8gBXZTR=='fa': AAtRnXCzaQUFyZV = ''
		else: AAtRnXCzaQUFyZV = AAj0QysJwULt1ha8gBXZTR
		ITO2qn5KBWf7MhYQ4riDmzkvU = u5h2Rckvw1E.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		for name,count,pGjsvdyHfM,ekTrZlFMu0Kf5QztEnhAs in items:
			for zAjwuoRY98mXN6xvE in range(int(count),0,-1):
				Rj2pa9yBIMoqeCPKiwh = pGjsvdyHfM + AAtRnXCzaQUFyZV + id + '/' + str(zAjwuoRY98mXN6xvE) + '.png'
				SkhRwop2bcUdC9 = name + title + str(zAjwuoRY98mXN6xvE)
				SkhRwop2bcUdC9 = uTUNPkVwCMKiD5gHLaj(SkhRwop2bcUdC9)
				uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+SkhRwop2bcUdC9,url,24,Rj2pa9yBIMoqeCPKiwh,'',str(zAjwuoRY98mXN6xvE))
	elif type=='Program':
		gANn35esloKUydOipfSMC6RD2 = PzufmMvpxolDQ57nbAGdkeWUsrw+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+BzbaC0qYjMr2WXwsO+'&size=30&orderby=1'
		oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,gANn35esloKUydOipfSMC6RD2,'','','','IFILM-EPISODES-2nd')
		items = u5h2Rckvw1E.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		title = ' - الحلقة '
		if AAj0QysJwULt1ha8gBXZTR=='en': title = ' - Episode '
		if AAj0QysJwULt1ha8gBXZTR=='fa': title = ' - قسمت '
		if AAj0QysJwULt1ha8gBXZTR=='fa2': title = ' - قسمت '
		for zAjwuoRY98mXN6xvE,pGjsvdyHfM,ekTrZlFMu0Kf5QztEnhAs,wJzvVgYC3hy,name in items:
			JeXvk7FjGa5CnU8TWDBP3EAItfHN += 1
			Rj2pa9yBIMoqeCPKiwh = d60XNEgVHxC3quhUoZnk9rsRTWDG + QQXTVNve6DMHBp4scG170kR2lWY(pGjsvdyHfM)
			name = ffbxegm1XPSqIwp8i(name)
			SkhRwop2bcUdC9 = name + title + str(zAjwuoRY98mXN6xvE)
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+SkhRwop2bcUdC9,gANn35esloKUydOipfSMC6RD2,24,Rj2pa9yBIMoqeCPKiwh,'',str(JeXvk7FjGa5CnU8TWDBP3EAItfHN))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			gANn35esloKUydOipfSMC6RD2 = PzufmMvpxolDQ57nbAGdkeWUsrw+'/Music/GetTracksBy?id='+str(id)+'&page='+BzbaC0qYjMr2WXwsO+'&size=30&type=0'
			oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,gANn35esloKUydOipfSMC6RD2,'','','','IFILM-EPISODES-3rd')
			items = u5h2Rckvw1E.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
			for pGjsvdyHfM,ekTrZlFMu0Kf5QztEnhAs,name,title in items:
				JeXvk7FjGa5CnU8TWDBP3EAItfHN += 1
				Rj2pa9yBIMoqeCPKiwh = d60XNEgVHxC3quhUoZnk9rsRTWDG + QQXTVNve6DMHBp4scG170kR2lWY(pGjsvdyHfM)
				SkhRwop2bcUdC9 = name + ' - ' + title
				SkhRwop2bcUdC9 = SkhRwop2bcUdC9.strip(' ')
				SkhRwop2bcUdC9 = ffbxegm1XPSqIwp8i(SkhRwop2bcUdC9)
				uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+SkhRwop2bcUdC9,gANn35esloKUydOipfSMC6RD2,24,Rj2pa9yBIMoqeCPKiwh,'',str(JeXvk7FjGa5CnU8TWDBP3EAItfHN))
		elif 'Clips' in url:
			gANn35esloKUydOipfSMC6RD2 = PzufmMvpxolDQ57nbAGdkeWUsrw+'/Music/GetTracksBy?id=0&page='+BzbaC0qYjMr2WXwsO+'&size=30&type=15'
			oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,gANn35esloKUydOipfSMC6RD2,'','','','IFILM-EPISODES-4th')
			items = u5h2Rckvw1E.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
			for pGjsvdyHfM,title,ekTrZlFMu0Kf5QztEnhAs in items:
				JeXvk7FjGa5CnU8TWDBP3EAItfHN += 1
				Rj2pa9yBIMoqeCPKiwh = d60XNEgVHxC3quhUoZnk9rsRTWDG + QQXTVNve6DMHBp4scG170kR2lWY(pGjsvdyHfM)
				SkhRwop2bcUdC9 = title.strip(' ')
				SkhRwop2bcUdC9 = ffbxegm1XPSqIwp8i(SkhRwop2bcUdC9)
				uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+SkhRwop2bcUdC9,gANn35esloKUydOipfSMC6RD2,24,Rj2pa9yBIMoqeCPKiwh,'',str(JeXvk7FjGa5CnU8TWDBP3EAItfHN))
		elif 'category' in url:
			if 'category=6' in url:
				gANn35esloKUydOipfSMC6RD2 = PzufmMvpxolDQ57nbAGdkeWUsrw+'/Music/GetTracksBy?id=0&page='+BzbaC0qYjMr2WXwsO+'&size=30&type=6'
				oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,gANn35esloKUydOipfSMC6RD2,'','','','IFILM-EPISODES-5th')
			elif 'category=4' in url:
				gANn35esloKUydOipfSMC6RD2 = PzufmMvpxolDQ57nbAGdkeWUsrw+'/Music/GetTracksBy?id=0&page='+BzbaC0qYjMr2WXwsO+'&size=30&type=4'
				oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,gANn35esloKUydOipfSMC6RD2,'','','','IFILM-EPISODES-6th')
			items = u5h2Rckvw1E.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
			for pGjsvdyHfM,ekTrZlFMu0Kf5QztEnhAs,name,title in items:
				JeXvk7FjGa5CnU8TWDBP3EAItfHN += 1
				Rj2pa9yBIMoqeCPKiwh = d60XNEgVHxC3quhUoZnk9rsRTWDG + QQXTVNve6DMHBp4scG170kR2lWY(pGjsvdyHfM)
				SkhRwop2bcUdC9 = name + ' - ' + title
				SkhRwop2bcUdC9 = SkhRwop2bcUdC9.strip(' ')
				SkhRwop2bcUdC9 = ffbxegm1XPSqIwp8i(SkhRwop2bcUdC9)
				uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+SkhRwop2bcUdC9,gANn35esloKUydOipfSMC6RD2,24,Rj2pa9yBIMoqeCPKiwh,'',str(JeXvk7FjGa5CnU8TWDBP3EAItfHN))
	if type=='Music' or type=='Program':
		if JeXvk7FjGa5CnU8TWDBP3EAItfHN>25:
			title='صفحة '
			if AAj0QysJwULt1ha8gBXZTR=='en': title = ' Page '
			if AAj0QysJwULt1ha8gBXZTR=='fa': title = ' صفحه '
			if AAj0QysJwULt1ha8gBXZTR=='fa2': title = ' صفحه '
			for NNtAMv1eYUgKifTSrajGlmC in range(1,11):
				if not BzbaC0qYjMr2WXwsO==str(NNtAMv1eYUgKifTSrajGlmC):
					KBzrJb7yeYoZdCI = '0'+str(NNtAMv1eYUgKifTSrajGlmC)
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title+str(NNtAMv1eYUgKifTSrajGlmC),url,23,'',Vs8Qe3ThflML2c4RjDxGyw+KBzrJb7yeYoZdCI[-2:])
	return
def N5AOlmb8u1y4FHxvJXU(url,zAjwuoRY98mXN6xvE):
	d60XNEgVHxC3quhUoZnk9rsRTWDG = pxXEuYRZnaBFrlf2Tv1(url)
	hVby8e3aQkFfuE,EaBeVhOsHYg8wub = [],[]
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,url,'','','','IFILM-PLAY-1st')
	items = u5h2Rckvw1E.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if items:
		AAj0QysJwULt1ha8gBXZTR = XgJPHjhAKR3sYe90D(url)
		KKSjuTY20EibkGc413C = url.split('/')
		id,type = KKSjuTY20EibkGc413C[-1],KKSjuTY20EibkGc413C[3]
		ekTrZlFMu0Kf5QztEnhAs = items[0][0]+AAj0QysJwULt1ha8gBXZTR+id+'/,'+zAjwuoRY98mXN6xvE+','+zAjwuoRY98mXN6xvE+'_'+items[0][2]
		hVby8e3aQkFfuE.append('m3u8')
		EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	items = u5h2Rckvw1E.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if items:
		AAj0QysJwULt1ha8gBXZTR = XgJPHjhAKR3sYe90D(url)
		KKSjuTY20EibkGc413C = url.split('/')
		id,type = KKSjuTY20EibkGc413C[-1],KKSjuTY20EibkGc413C[3]
		ekTrZlFMu0Kf5QztEnhAs = items[0][0]+AAj0QysJwULt1ha8gBXZTR+id+'/'+zAjwuoRY98mXN6xvE+items[0][2]
		hVby8e3aQkFfuE.append('mp4 url')
		EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	items = u5h2Rckvw1E.findall('source src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs in items:
		ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.replace('//','/')
		hVby8e3aQkFfuE.append('mp4 src')
		EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	items = u5h2Rckvw1E.findall('VideoAddress":"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if items:
		ekTrZlFMu0Kf5QztEnhAs = items[int(zAjwuoRY98mXN6xvE)-1]
		ekTrZlFMu0Kf5QztEnhAs = d60XNEgVHxC3quhUoZnk9rsRTWDG+QQXTVNve6DMHBp4scG170kR2lWY(ekTrZlFMu0Kf5QztEnhAs)
		hVby8e3aQkFfuE.append('mp4 address')
		EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	items = u5h2Rckvw1E.findall('VoiceAddress":"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if items:
		ekTrZlFMu0Kf5QztEnhAs = items[int(zAjwuoRY98mXN6xvE)-1]
		ekTrZlFMu0Kf5QztEnhAs = d60XNEgVHxC3quhUoZnk9rsRTWDG+QQXTVNve6DMHBp4scG170kR2lWY(ekTrZlFMu0Kf5QztEnhAs)
		hVby8e3aQkFfuE.append('mp3 address')
		EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	if len(EaBeVhOsHYg8wub)==1: ekTrZlFMu0Kf5QztEnhAs = EaBeVhOsHYg8wub[0]
	else:
		u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = tYysxJLreEBDdXMIjz4OPa('اختر الفيديو المناسب:', hVby8e3aQkFfuE)
		if u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo == -1 : return
		ekTrZlFMu0Kf5QztEnhAs = EaBeVhOsHYg8wub[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
	om1iZDWnrhGa2SLB9O4kfxYbqU(ekTrZlFMu0Kf5QztEnhAs,aUVSgO2ebjwX5iqPykC,'video')
	return
def pxXEuYRZnaBFrlf2Tv1(url):
	if yONJxHER9BIDPpTV4YsWmc0n in url: tzVT6PXndWu0 = yONJxHER9BIDPpTV4YsWmc0n
	elif nIo981YOgF2lx7JNevV4b0K6shuzA in url: tzVT6PXndWu0 = nIo981YOgF2lx7JNevV4b0K6shuzA
	elif bhstdnoCPNl0KmF1QZOwBeq in url: tzVT6PXndWu0 = bhstdnoCPNl0KmF1QZOwBeq
	elif Ef3IMjWzo25Cv in url: tzVT6PXndWu0 = Ef3IMjWzo25Cv
	else: tzVT6PXndWu0 = ''
	return tzVT6PXndWu0
def XgJPHjhAKR3sYe90D(url):
	if   yONJxHER9BIDPpTV4YsWmc0n in url: AAj0QysJwULt1ha8gBXZTR = 'ar'
	elif nIo981YOgF2lx7JNevV4b0K6shuzA in url: AAj0QysJwULt1ha8gBXZTR = 'en'
	elif bhstdnoCPNl0KmF1QZOwBeq in url: AAj0QysJwULt1ha8gBXZTR = 'fa'
	elif Ef3IMjWzo25Cv in url: AAj0QysJwULt1ha8gBXZTR = 'fa2'
	else: AAj0QysJwULt1ha8gBXZTR = ''
	return AAj0QysJwULt1ha8gBXZTR
def SotcYExj3mF2Cn4dGKA(url):
	AAj0QysJwULt1ha8gBXZTR = XgJPHjhAKR3sYe90D(url)
	gANn35esloKUydOipfSMC6RD2 = url + '/Home/Live'
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',gANn35esloKUydOipfSMC6RD2,'','','','','IFILM-LIVE-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	items = u5h2Rckvw1E.findall('source src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	UcmHDPlLWaSf = items[0]
	om1iZDWnrhGa2SLB9O4kfxYbqU(UcmHDPlLWaSf,aUVSgO2ebjwX5iqPykC,'live')
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if not search:
		search = FBrXsYeCEp3()
		if not search: return
	GHFUMEOSrvhmIoVWxwN8j4 = search.replace(' ','+')
	if showDialogs:
		QFR60urSVcksg9JimUNL = [ yONJxHER9BIDPpTV4YsWmc0n , nIo981YOgF2lx7JNevV4b0K6shuzA , bhstdnoCPNl0KmF1QZOwBeq , Ef3IMjWzo25Cv ]
		qUTPXnBoegj5QybG1t0VNJxv6u = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = tYysxJLreEBDdXMIjz4OPa('اختر اللغة المناسبة:', qUTPXnBoegj5QybG1t0VNJxv6u)
		if u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo == -1 : return
		website = QFR60urSVcksg9JimUNL[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
	else:
		if '_IFILM-ARABIC_' in dza2VO9NvX: website = yONJxHER9BIDPpTV4YsWmc0n
		elif '_IFILM-ENGLISH_' in dza2VO9NvX: website = nIo981YOgF2lx7JNevV4b0K6shuzA
		else: website = ''
	if not website: return
	AAj0QysJwULt1ha8gBXZTR = XgJPHjhAKR3sYe90D(website)
	gANn35esloKUydOipfSMC6RD2 = website + "/Home/Search?searchstring=" + GHFUMEOSrvhmIoVWxwN8j4
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,gANn35esloKUydOipfSMC6RD2,'','','','IFILM-SEARCH-1st')
	items = u5h2Rckvw1E.findall('"ImageAddress_S":"(.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if items:
		for pGjsvdyHfM,oPrhaMp7AqmNnRjlXGI,id,title in items:
			if oPrhaMp7AqmNnRjlXGI in ['3','7']:
				title = title.replace('\\','')
				title = title.replace('"','')
				if oPrhaMp7AqmNnRjlXGI=='3':
					type = 'Series'
					if AAj0QysJwULt1ha8gBXZTR=='ar': name = 'مسلسل : '
					elif AAj0QysJwULt1ha8gBXZTR=='en': name = 'Series : '
					elif AAj0QysJwULt1ha8gBXZTR=='fa': name = 'سريال ها : '
					elif AAj0QysJwULt1ha8gBXZTR=='fa2': name = 'سريال ها : '
				elif oPrhaMp7AqmNnRjlXGI=='5':
					type = 'Film'
					if AAj0QysJwULt1ha8gBXZTR=='ar': name = 'فيلم : '
					elif AAj0QysJwULt1ha8gBXZTR=='en': name = 'Movie : '
					elif AAj0QysJwULt1ha8gBXZTR=='fa': name = 'فيلم : '
					elif AAj0QysJwULt1ha8gBXZTR=='fa2': name = 'فلم ها : '
				elif oPrhaMp7AqmNnRjlXGI=='7':
					type = 'Program'
					if AAj0QysJwULt1ha8gBXZTR=='ar': name = 'برنامج : '
					elif AAj0QysJwULt1ha8gBXZTR=='en': name = 'Program : '
					elif AAj0QysJwULt1ha8gBXZTR=='fa': name = 'برنامه ها : '
					elif AAj0QysJwULt1ha8gBXZTR=='fa2': name = 'برنامه ها : '
				title = name + title
				ekTrZlFMu0Kf5QztEnhAs = website + '/' + type + '/Content/' + id
				pGjsvdyHfM = QQXTVNve6DMHBp4scG170kR2lWY(pGjsvdyHfM)
				pGjsvdyHfM = website+pGjsvdyHfM
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,23,pGjsvdyHfM,'101')
	return
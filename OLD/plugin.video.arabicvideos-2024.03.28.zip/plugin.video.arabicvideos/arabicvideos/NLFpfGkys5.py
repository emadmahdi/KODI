# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'SHOOFPRO'
tiCRYyX1bWd40Ir3PafQu = '_SHP_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['مصارعة','بث مباشر']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==480: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==481: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,text)
	elif mode==482: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==483: vS7JufTVsBxw52 = GA2KIlbOsoYtxpkDF71(url,text)
	elif mode==489: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text,url)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',yONJxHER9BIDPpTV4YsWmc0n,'','','','','SHOOFPRO-MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	jGX4sfdrWaeZpA1VyvTK = u5h2Rckvw1E.findall('href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	jGX4sfdrWaeZpA1VyvTK = jGX4sfdrWaeZpA1VyvTK[0].strip('/')
	jGX4sfdrWaeZpA1VyvTK = hmcFWJUgiAuGk(jGX4sfdrWaeZpA1VyvTK,'url')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع',jGX4sfdrWaeZpA1VyvTK,489,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'أحدث المواضيع',jGX4sfdrWaeZpA1VyvTK,481)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"navigation"(.*?)"myAccount"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('href="(.*?)".*?</span>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		if ekTrZlFMu0Kf5QztEnhAs=='#': continue
		if title in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
		title = uTUNPkVwCMKiD5gHLaj(title)
		uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,481)
	return oo9SgGkiDbs3HRn7z8
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,ApNczOwYsl0LhEoB7UMmDi5y9):
	items = []
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','SHOOFPRO-TITLES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"post(.*?)"footer"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not cWafzb4HoG1Em3Jwxu6C7vZsVi: return
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('href="(.*?)" title="(.*?)".*?image:url\((.*?)\)',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	yn8DkpE5etF3WiUmfSO = []
	dR94SHEmDA8nflN = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	pae3PEMhjTOQ8LufIkcAgWxq = '/'.join(ApNczOwYsl0LhEoB7UMmDi5y9.strip('/').split('/')[4:]).split('-')
	for ekTrZlFMu0Kf5QztEnhAs,title,pGjsvdyHfM in items:
		title = uTUNPkVwCMKiD5gHLaj(title)
		zAjwuoRY98mXN6xvE = u5h2Rckvw1E.findall('(.*?) حلقة \d+',title,u5h2Rckvw1E.DOTALL)
		if ApNczOwYsl0LhEoB7UMmDi5y9:
			olm59qifJbWpRsr1a3X7zBEIA = '/'.join(ekTrZlFMu0Kf5QztEnhAs.strip('/').split('/')[4:]).split('-')
			TCJ7Ph3Vgzm41q9Ayc = len([oVMbrsQjklpC0EeX6 for oVMbrsQjklpC0EeX6 in pae3PEMhjTOQ8LufIkcAgWxq if oVMbrsQjklpC0EeX6 in olm59qifJbWpRsr1a3X7zBEIA])
			if TCJ7Ph3Vgzm41q9Ayc>2 and '/episodes/' in ekTrZlFMu0Kf5QztEnhAs:
				uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,482,pGjsvdyHfM)
		else:
			if not zAjwuoRY98mXN6xvE: zAjwuoRY98mXN6xvE = u5h2Rckvw1E.findall('(.*?) الحلقة \d+',title,u5h2Rckvw1E.DOTALL)
			if set(title.split()) & set(dR94SHEmDA8nflN) and 'مسلسل' not in title:
				uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,482,pGjsvdyHfM)
			elif zAjwuoRY98mXN6xvE and 'حلقة' in title:
				title = '_MOD_' + zAjwuoRY98mXN6xvE[0]
				if title not in yn8DkpE5etF3WiUmfSO:
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,483,pGjsvdyHfM,'',url)
					yn8DkpE5etF3WiUmfSO.append(title)
			else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,483,pGjsvdyHfM,'',url)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall("'pagination'(.*?)</div>",oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall("href='(.*?)'.*?>(.*?)</a>",lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			title = uTUNPkVwCMKiD5gHLaj(title)
			title = title.replace('الصفحة ','')
			if title!='': uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+title,ekTrZlFMu0Kf5QztEnhAs,481,'','',ApNczOwYsl0LhEoB7UMmDi5y9)
	return
def GA2KIlbOsoYtxpkDF71(url,gANn35esloKUydOipfSMC6RD2):
	headers = {'X-Requested-With':'XMLHttpRequest'}
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'',headers,'','','SHOOFPRO-EPISODES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	jGX4sfdrWaeZpA1VyvTK = hmcFWJUgiAuGk(url,'url')
	pGjsvdyHfM = u5h2Rckvw1E.findall('"img-responsive" src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if pGjsvdyHfM: pGjsvdyHfM = pGjsvdyHfM[0]
	else: pGjsvdyHfM = bMIascyFJ2x43E0C7glTB91h8qz.getInfoLabel('ListItem.Thumb')
	TyJgdt9V38bK2SoqLIRXGh4Q = True
	kQ7LGm5DPnH8hUdtWY = u5h2Rckvw1E.findall('"listSeasons(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if kQ7LGm5DPnH8hUdtWY and '/ajax/seasons' not in url:
		lmO2YJGr6tCV = kQ7LGm5DPnH8hUdtWY[0]
		count = lmO2YJGr6tCV.count('data-slug=')
		if count==0: count = lmO2YJGr6tCV.count('data-season=')
		if count>1:
			TyJgdt9V38bK2SoqLIRXGh4Q = False
			if 'data-slug="' in lmO2YJGr6tCV:
				items = u5h2Rckvw1E.findall('data-slug="(.*?)">(.*?)</li>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
				for id,title in items:
					ekTrZlFMu0Kf5QztEnhAs = jGX4sfdrWaeZpA1VyvTK+'/wp-content/themes/vo2021/temp/ajax/seasons2.php?slug='+id
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,483,pGjsvdyHfM)
			else:
				items = u5h2Rckvw1E.findall('data-season="(.*?)">(.*?)</li>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
				for id,title in items:
					ekTrZlFMu0Kf5QztEnhAs = jGX4sfdrWaeZpA1VyvTK+'/wp-content/themes/vo2021/temp/ajax/seasons.php?seriesID='+id
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,483,pGjsvdyHfM)
	if TyJgdt9V38bK2SoqLIRXGh4Q:
		lmO2YJGr6tCV = ''
		if '/ajax/seasons' in url: lmO2YJGr6tCV = oo9SgGkiDbs3HRn7z8
		else:
			RfTOHSzgpA = u5h2Rckvw1E.findall('"eplist"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
			if RfTOHSzgpA: lmO2YJGr6tCV = RfTOHSzgpA[0]
		items = u5h2Rckvw1E.findall('href="(.*?)" title="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if items:
			for ekTrZlFMu0Kf5QztEnhAs,title in items:
				title = title.strip(' ')
				uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,482,pGjsvdyHfM)
	if not YD56nkJmsd: ll0a2AwztChcpsDUMi4rGW3b61XZES(gANn35esloKUydOipfSMC6RD2,url)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	gANn35esloKUydOipfSMC6RD2 = url.strip('/')+'/?do=watch'
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',gANn35esloKUydOipfSMC6RD2,'','','','','SHOOFPRO-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	EaBeVhOsHYg8wub = []
	jGX4sfdrWaeZpA1VyvTK = hmcFWJUgiAuGk(url,'url')
	DnkhMBRTKpAvOsyJruQX8bo3aHNjzI = u5h2Rckvw1E.findall('vo_postID = "(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not DnkhMBRTKpAvOsyJruQX8bo3aHNjzI: DnkhMBRTKpAvOsyJruQX8bo3aHNjzI = u5h2Rckvw1E.findall('\(this\.id\,0\,(.*?)\)',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	DnkhMBRTKpAvOsyJruQX8bo3aHNjzI = DnkhMBRTKpAvOsyJruQX8bo3aHNjzI[0]
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"serversList"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('id="(.*?)".*?">(.*?)</li>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for Vj0lraYRgKsPMJbitwoNIhe1E,title in items:
			title = title.strip(' ')
			ekTrZlFMu0Kf5QztEnhAs = jGX4sfdrWaeZpA1VyvTK+'/wp-content/themes/vo2021/temp/ajax/iframe2.php?id='+DnkhMBRTKpAvOsyJruQX8bo3aHNjzI+'&video='+Vj0lraYRgKsPMJbitwoNIhe1E[2:]+'?named='+title+'__watch'
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('"getEmbed".*?src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if ekTrZlFMu0Kf5QztEnhAs:
		title = hmcFWJUgiAuGk(ekTrZlFMu0Kf5QztEnhAs[0],'url')
		ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs[0]+'?named='+title+'__embed'
		EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	gANn35esloKUydOipfSMC6RD2 = url.strip('/')+'/?do=download'
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',gANn35esloKUydOipfSMC6RD2,'','','','','SHOOFPRO-PLAY-2nd')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"table-responsive"(.*?)</table>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('<td>(.*?)</td>.*?href="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for title,ekTrZlFMu0Kf5QztEnhAs in items:
			title = title.strip(' ')
			if 'anavidz' in ekTrZlFMu0Kf5QztEnhAs: cMpjL2oavyVwKHBPn8EdhYqxSUk = '__خاص'
			else: cMpjL2oavyVwKHBPn8EdhYqxSUk = ''
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+title+'__download'+cMpjL2oavyVwKHBPn8EdhYqxSUk
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(EaBeVhOsHYg8wub,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search,jGX4sfdrWaeZpA1VyvTK=''):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	search = search.replace(' ','+')
	if jGX4sfdrWaeZpA1VyvTK=='': jGX4sfdrWaeZpA1VyvTK = yONJxHER9BIDPpTV4YsWmc0n
	url = jGX4sfdrWaeZpA1VyvTK+'/search/'+search+'/'
	ll0a2AwztChcpsDUMi4rGW3b61XZES(url,'')
	return
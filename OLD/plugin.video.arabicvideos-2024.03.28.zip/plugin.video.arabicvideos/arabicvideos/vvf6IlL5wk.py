# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'ALFATIMI'
tiCRYyX1bWd40Ir3PafQu = '_FTM_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
YBN75vnmgu4bIKyiZTPj8FlMsRWCL = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
uP1fc4SeibrGI9aovsjmA06 = ['3030','628']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==60: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==61: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,text)
	elif mode==62: vS7JufTVsBxw52 = GA2KIlbOsoYtxpkDF71(url)
	elif mode==63: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==64: vS7JufTVsBxw52 = YoMa30pFkZfWbCRychmPxuA81qw75B(text)
	elif mode==69: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',69,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'ما يتم مشاهدته الان',yONJxHER9BIDPpTV4YsWmc0n,64,'','','recent_viewed_vids')
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'الاكثر مشاهدة',yONJxHER9BIDPpTV4YsWmc0n,64,'','','most_viewed_vids')
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'اضيفت مؤخرا',yONJxHER9BIDPpTV4YsWmc0n,64,'','','recently_added_vids')
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'فيديو عشوائي',yONJxHER9BIDPpTV4YsWmc0n,64,'','','random_vids')
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'افلام ومسلسلات',yONJxHER9BIDPpTV4YsWmc0n,61,'','','-1')
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'البرامج الدينية',yONJxHER9BIDPpTV4YsWmc0n,61,'','','-2')
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'English Videos',yONJxHER9BIDPpTV4YsWmc0n,61,'','','-3')
	return ''
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,oPrhaMp7AqmNnRjlXGI):
	rZgRWIsuSjpim7cMAnLfhHEx5 = ''
	if oPrhaMp7AqmNnRjlXGI not in ['-1','-2','-3']: rZgRWIsuSjpim7cMAnLfhHEx5 = '?cat='+oPrhaMp7AqmNnRjlXGI
	gANn35esloKUydOipfSMC6RD2 = yONJxHER9BIDPpTV4YsWmc0n+'/menu_level.php'+rZgRWIsuSjpim7cMAnLfhHEx5
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,gANn35esloKUydOipfSMC6RD2,'','','','ALFATIMI-TITLES-1st')
	items = u5h2Rckvw1E.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	grRwZPSnDYBOi3Kqy2,Hxpd2wePZUyLtJk1hm = False,False
	for ekTrZlFMu0Kf5QztEnhAs,title,count in items:
		title = uTUNPkVwCMKiD5gHLaj(title)
		title = title.strip(' ')
		if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = 'http:'+ekTrZlFMu0Kf5QztEnhAs
		rZgRWIsuSjpim7cMAnLfhHEx5 = u5h2Rckvw1E.findall('cat=(.*?)&',ekTrZlFMu0Kf5QztEnhAs,u5h2Rckvw1E.DOTALL)[0]
		if oPrhaMp7AqmNnRjlXGI==rZgRWIsuSjpim7cMAnLfhHEx5: grRwZPSnDYBOi3Kqy2 = True
		elif grRwZPSnDYBOi3Kqy2 	or (oPrhaMp7AqmNnRjlXGI=='-1' and rZgRWIsuSjpim7cMAnLfhHEx5 in YBN75vnmgu4bIKyiZTPj8FlMsRWCL)  						or (oPrhaMp7AqmNnRjlXGI=='-2' and rZgRWIsuSjpim7cMAnLfhHEx5 not in uP1fc4SeibrGI9aovsjmA06 and rZgRWIsuSjpim7cMAnLfhHEx5 not in YBN75vnmgu4bIKyiZTPj8FlMsRWCL)  						or (oPrhaMp7AqmNnRjlXGI=='-3' and rZgRWIsuSjpim7cMAnLfhHEx5 in uP1fc4SeibrGI9aovsjmA06):
							if count=='1': uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,63)
							else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,61,'','',rZgRWIsuSjpim7cMAnLfhHEx5)
							Hxpd2wePZUyLtJk1hm = True
	if not Hxpd2wePZUyLtJk1hm: GA2KIlbOsoYtxpkDF71(url)
	return
def GA2KIlbOsoYtxpkDF71(url):
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,url,'','',True,'ALFATIMI-EPISODES-1st')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('pagination(.*?)id="footer',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	ekTrZlFMu0Kf5QztEnhAs = ''
	for pGjsvdyHfM,title,ekTrZlFMu0Kf5QztEnhAs in items:
		title = title.replace('Add','').replace('to Quicklist','').strip(' ')
		if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = 'http:'+ekTrZlFMu0Kf5QztEnhAs
		uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,63,pGjsvdyHfM)
	cWafzb4HoG1Em3Jwxu6C7vZsVi=u5h2Rckvw1E.findall('(.*?)div',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV=cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	lmO2YJGr6tCV=u5h2Rckvw1E.findall('pagination(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)[0]
	items=u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	gANn35esloKUydOipfSMC6RD2 = url.split('?')[0]
	for ekTrZlFMu0Kf5QztEnhAs,GRM9OPVoZmIu1fgQiX in items:
		ekTrZlFMu0Kf5QztEnhAs = gANn35esloKUydOipfSMC6RD2 + ekTrZlFMu0Kf5QztEnhAs
		title = uTUNPkVwCMKiD5gHLaj(GRM9OPVoZmIu1fgQiX)
		title = 'صفحة ' + title
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,62)
	return ekTrZlFMu0Kf5QztEnhAs
def N5AOlmb8u1y4FHxvJXU(url):
	if 'videos.php' in url: url = GA2KIlbOsoYtxpkDF71(url)
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,url,'','',True,'ALFATIMI-PLAY-1st')
	items = u5h2Rckvw1E.findall('playlistfile:"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	om1iZDWnrhGa2SLB9O4kfxYbqU(url,aUVSgO2ebjwX5iqPykC,'video')
	return
def YoMa30pFkZfWbCRychmPxuA81qw75B(oPrhaMp7AqmNnRjlXGI):
	nD70jhRb8C9Gi = { 'mode' : oPrhaMp7AqmNnRjlXGI }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = x1SKFacgifEdUthsYBbnC5XyTj(nD70jhRb8C9Gi)
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(hs8IDEMn0YuCHwk,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = u5h2Rckvw1E.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,title,pGjsvdyHfM in items:
		title = title.strip(' ')
		if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = 'http:'+ekTrZlFMu0Kf5QztEnhAs
		uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,63,pGjsvdyHfM)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	GHFUMEOSrvhmIoVWxwN8j4 = search.replace(' ','+')
	url = yONJxHER9BIDPpTV4YsWmc0n + '/search_result.php?query=' + GHFUMEOSrvhmIoVWxwN8j4
	GA2KIlbOsoYtxpkDF71(url)
	return
﻿# -*- coding: utf-8 -*-
from LXgKztbkOf import *
def cc03CYPLaxRfUKJb9eynFTr(wMCm6g9qFyPT0xpneDUNc2lEhaZY,ZaChxtQIlXdmvMNg):
	if ZaChxtQIlXdmvMNg=='': return
	if wMCm6g9qFyPT0xpneDUNc2lEhaZY==1:
		WoB2cq63nPylkp9iNEdxzC8 = XuWPVcQ13oDq5swf0S.getCurrentWindowDialogId()
		ddZk0oiBCfS4GzO6t8XUq31bWRcQA = XuWPVcQ13oDq5swf0S.Window(WoB2cq63nPylkp9iNEdxzC8)
		ZaChxtQIlXdmvMNg = KvSsHlYxGB7Dz5uMcbdJ2wt9hyCRj1(ZaChxtQIlXdmvMNg)
		ddZk0oiBCfS4GzO6t8XUq31bWRcQA.getControl(311).setLabel(ZaChxtQIlXdmvMNg)
	if wMCm6g9qFyPT0xpneDUNc2lEhaZY==0:
		afxYgsnGTdAHePVBK='X'
		if VVGRN7xiyj: qGOC2Ih1XuZU = isinstance(ZaChxtQIlXdmvMNg,str)
		else: qGOC2Ih1XuZU = isinstance(ZaChxtQIlXdmvMNg,unicode)
		if qGOC2Ih1XuZU==True: afxYgsnGTdAHePVBK='U'
		JM2xrRIhOj6zFsgS=str(type(ZaChxtQIlXdmvMNg))+' '+ZaChxtQIlXdmvMNg+' '+afxYgsnGTdAHePVBK+' '
		for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(0,len(ZaChxtQIlXdmvMNg),1):
			JM2xrRIhOj6zFsgS += hex(ord(ZaChxtQIlXdmvMNg[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE])).replace('0x','')+' '
		ZaChxtQIlXdmvMNg = KvSsHlYxGB7Dz5uMcbdJ2wt9hyCRj1(ZaChxtQIlXdmvMNg)
		afxYgsnGTdAHePVBK='X'
		if VVGRN7xiyj: qGOC2Ih1XuZU = isinstance(ZaChxtQIlXdmvMNg, str)
		else: qGOC2Ih1XuZU = isinstance(ZaChxtQIlXdmvMNg, unicode)
		if qGOC2Ih1XuZU==True: afxYgsnGTdAHePVBK='U'
		M4ZtQe9J3HvX0IUbS5cnDrsECd=str(type(ZaChxtQIlXdmvMNg))+' '+ZaChxtQIlXdmvMNg+' '+afxYgsnGTdAHePVBK+' '
		for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(0,len(ZaChxtQIlXdmvMNg),1):
			M4ZtQe9J3HvX0IUbS5cnDrsECd += hex(ord(ZaChxtQIlXdmvMNg[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE])).replace('0x','')+' '
	return
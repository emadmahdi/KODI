# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'YOUTUBE'
tiCRYyX1bWd40Ir3PafQu = '_YUT_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
x1JgcflnTFAwXmRMoIZ = 0
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text,type,BzbaC0qYjMr2WXwsO,name,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx):
	if	 mode==140: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==141: vS7JufTVsBxw52 = T3YkbKEvL6gzJsPAFtZH(url,name,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx)
	elif mode==143: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url,type)
	elif mode==144: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,BzbaC0qYjMr2WXwsO,text)
	elif mode==145: vS7JufTVsBxw52 = fa7kLtYT91BbFHiDh4UqWPK(url,BzbaC0qYjMr2WXwsO)
	elif mode==147: vS7JufTVsBxw52 = i35iGPxr0dtX1jNl268Uz9C()
	elif mode==148: vS7JufTVsBxw52 = T3TUfali2jrzHD()
	elif mode==149: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	if 0:
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'قائمة',yONJxHER9BIDPpTV4YsWmc0n+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'شخص',yONJxHER9BIDPpTV4YsWmc0n+'/user/TCNofficial',144)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'موقع',yONJxHER9BIDPpTV4YsWmc0n+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'حساب',yONJxHER9BIDPpTV4YsWmc0n+'/@TheSocialCTV',144)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'العاب',yONJxHER9BIDPpTV4YsWmc0n+'/gaming',144)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'افلام',yONJxHER9BIDPpTV4YsWmc0n+'/feed/storefront',144)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مختارات',yONJxHER9BIDPpTV4YsWmc0n+'/feed/guide_builder',144)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'قصيرة',yONJxHER9BIDPpTV4YsWmc0n+'/shorts',144,'','','_REMEMBERRESULTS_')
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'تصفح',yONJxHER9BIDPpTV4YsWmc0n+'/youtubei/v1/guide?key=',144)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'رئيسية',yONJxHER9BIDPpTV4YsWmc0n+'',144)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'رائج',yONJxHER9BIDPpTV4YsWmc0n+'/feed/trending?bp=',144)
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',149,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الرئيسية',yONJxHER9BIDPpTV4YsWmc0n+'',144)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الرائجة',yONJxHER9BIDPpTV4YsWmc0n+'/feed/trending',144)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'التصفح',yONJxHER9BIDPpTV4YsWmc0n+'/youtubei/v1/guide?key=',144)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'القصيرة',yONJxHER9BIDPpTV4YsWmc0n+'/shorts',144,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مختارات يوتيوب',yONJxHER9BIDPpTV4YsWmc0n+'/feed/guide_builder',144)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مختارات البرنامج','',290)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث: قنوات عربية','',147)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث: قنوات أجنبية','',148)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث: افلام عربية',yONJxHER9BIDPpTV4YsWmc0n+'/results?search_query=فيلم',144)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث: افلام اجنبية',yONJxHER9BIDPpTV4YsWmc0n+'/results?search_query=movie',144)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث: مسرحيات عربية',yONJxHER9BIDPpTV4YsWmc0n+'/results?search_query=مسرحية',144)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث: مسلسلات عربية',yONJxHER9BIDPpTV4YsWmc0n+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث: مسلسلات اجنبية',yONJxHER9BIDPpTV4YsWmc0n+'/results?search_query=series&sp=EgIQAw==',144)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث: مسلسلات كارتون',yONJxHER9BIDPpTV4YsWmc0n+'/results?search_query=كارتون&sp=EgIQAw==',144)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث: خطبة المرجعية',yONJxHER9BIDPpTV4YsWmc0n+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def T3YkbKEvL6gzJsPAFtZH(url,name,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx):
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'CHNL:  '+name,url,144,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx)
	return
def i35iGPxr0dtX1jNl268Uz9C():
	ll0a2AwztChcpsDUMi4rGW3b61XZES(yONJxHER9BIDPpTV4YsWmc0n+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def T3TUfali2jrzHD():
	ll0a2AwztChcpsDUMi4rGW3b61XZES(yONJxHER9BIDPpTV4YsWmc0n+'/results?search_query=tv&sp=EgJAAQ==')
	return
def N5AOlmb8u1y4FHxvJXU(url,type):
	url = url.split('&',1)[0]
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr([url],aUVSgO2ebjwX5iqPykC,type,url)
	return
def MOZBkwhY1sf9pILCoGceD3xbE(FLoRu67q9wjsnipY2ZX,url,M4Feb15G0QtrDlW6sPh9xNBnC3j):
	level,milR6aMZ3O8y,AApLx5QJvGswtVh9lFDNKZ2y1PSbOr,cf34hOSkPbyeIK29x5Xu = M4Feb15G0QtrDlW6sPh9xNBnC3j.split('::')
	QuMmSnj1FDg7YUysd0AbWE,LbR5Z9fygsPKjo = [],[]
	if '/youtubei/v1/browse' in url: QuMmSnj1FDg7YUysd0AbWE.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: QuMmSnj1FDg7YUysd0AbWE.append("yccc['onResponseReceivedCommands']")
	if level=='1': QuMmSnj1FDg7YUysd0AbWE.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	QuMmSnj1FDg7YUysd0AbWE.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	QuMmSnj1FDg7YUysd0AbWE.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	QuMmSnj1FDg7YUysd0AbWE.append("yccc['entries']")
	QuMmSnj1FDg7YUysd0AbWE.append("yccc['items'][3]['guideSectionRenderer']['items']")
	LpJnQgRVb2YX31Ica0HCtAMKh,YTCDh7u6WGyHP,MM8GBAafuJUe4xYyXEchCItFmkrl = Vlo5rATYdGPczsejuhN8JL2kwn0X(FLoRu67q9wjsnipY2ZX,'',QuMmSnj1FDg7YUysd0AbWE)
	if level=='1' and LpJnQgRVb2YX31Ica0HCtAMKh:
		if len(YTCDh7u6WGyHP)>1 and 'search_query' not in url:
			for ZmWIcGhdFzNivK29EuB70DVC5Q in range(len(YTCDh7u6WGyHP)):
				milR6aMZ3O8y = str(ZmWIcGhdFzNivK29EuB70DVC5Q)
				QuMmSnj1FDg7YUysd0AbWE = []
				QuMmSnj1FDg7YUysd0AbWE.append("yddd["+milR6aMZ3O8y+"]['reloadContinuationItemsCommand']['continuationItems']")
				QuMmSnj1FDg7YUysd0AbWE.append("yddd["+milR6aMZ3O8y+"]['command']")
				QuMmSnj1FDg7YUysd0AbWE.append("yddd["+milR6aMZ3O8y+"]")
				V5VXz0j3oa6t,TMaJdc0xOFKNf,FFkUYlfHsK2W5VzbAZjMvmCSE43 = Vlo5rATYdGPczsejuhN8JL2kwn0X(YTCDh7u6WGyHP,'',QuMmSnj1FDg7YUysd0AbWE)
				if V5VXz0j3oa6t: LbR5Z9fygsPKjo.append([TMaJdc0xOFKNf,url,'2::'+milR6aMZ3O8y+'::0::0'])
			QuMmSnj1FDg7YUysd0AbWE.append("yccc['continuationEndpoint']")
			V5VXz0j3oa6t,TMaJdc0xOFKNf,FFkUYlfHsK2W5VzbAZjMvmCSE43 = Vlo5rATYdGPczsejuhN8JL2kwn0X(FLoRu67q9wjsnipY2ZX,'',QuMmSnj1FDg7YUysd0AbWE)
			if V5VXz0j3oa6t and LbR5Z9fygsPKjo and 'continuationCommand' in list(TMaJdc0xOFKNf.keys()):
				ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/my_main_page_shorts_link'
				LbR5Z9fygsPKjo.append([TMaJdc0xOFKNf,ekTrZlFMu0Kf5QztEnhAs,'1::0::0::0'])
	return YTCDh7u6WGyHP,LpJnQgRVb2YX31Ica0HCtAMKh,LbR5Z9fygsPKjo,MM8GBAafuJUe4xYyXEchCItFmkrl
def BNcyY9bDs6rqS0dmFuKHpei(FLoRu67q9wjsnipY2ZX,YTCDh7u6WGyHP,url,M4Feb15G0QtrDlW6sPh9xNBnC3j):
	level,milR6aMZ3O8y,AApLx5QJvGswtVh9lFDNKZ2y1PSbOr,cf34hOSkPbyeIK29x5Xu = M4Feb15G0QtrDlW6sPh9xNBnC3j.split('::')
	QuMmSnj1FDg7YUysd0AbWE,XNC2PZSLf96WMApwH = [],[]
	QuMmSnj1FDg7YUysd0AbWE.append("yddd[0]['itemSectionRenderer']['contents']")
	QuMmSnj1FDg7YUysd0AbWE.append("yddd["+milR6aMZ3O8y+"]['reloadContinuationItemsCommand']['continuationItems']")
	QuMmSnj1FDg7YUysd0AbWE.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: QuMmSnj1FDg7YUysd0AbWE.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: QuMmSnj1FDg7YUysd0AbWE.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	QuMmSnj1FDg7YUysd0AbWE.append("yddd["+milR6aMZ3O8y+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		QuMmSnj1FDg7YUysd0AbWE.append("yddd["+milR6aMZ3O8y+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	QuMmSnj1FDg7YUysd0AbWE.append("yddd["+milR6aMZ3O8y+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	QuMmSnj1FDg7YUysd0AbWE.append("yddd["+milR6aMZ3O8y+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	QuMmSnj1FDg7YUysd0AbWE.append("yddd["+milR6aMZ3O8y+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	QuMmSnj1FDg7YUysd0AbWE.append("yddd["+milR6aMZ3O8y+"]")
	Qa4GP7WYcILg9,lloZWS9qf7eIpNnyPdDmG4,TMoYrXjeRk = Vlo5rATYdGPczsejuhN8JL2kwn0X(YTCDh7u6WGyHP,'',QuMmSnj1FDg7YUysd0AbWE)
	if level=='2' and Qa4GP7WYcILg9:
		if len(lloZWS9qf7eIpNnyPdDmG4)>1:
			for ZmWIcGhdFzNivK29EuB70DVC5Q in range(len(lloZWS9qf7eIpNnyPdDmG4)):
				AApLx5QJvGswtVh9lFDNKZ2y1PSbOr = str(ZmWIcGhdFzNivK29EuB70DVC5Q)
				QuMmSnj1FDg7YUysd0AbWE = []
				QuMmSnj1FDg7YUysd0AbWE.append("yeee["+AApLx5QJvGswtVh9lFDNKZ2y1PSbOr+"]['richSectionRenderer']['content']")
				QuMmSnj1FDg7YUysd0AbWE.append("yeee["+AApLx5QJvGswtVh9lFDNKZ2y1PSbOr+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				QuMmSnj1FDg7YUysd0AbWE.append("yeee["+AApLx5QJvGswtVh9lFDNKZ2y1PSbOr+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				QuMmSnj1FDg7YUysd0AbWE.append("yeee["+AApLx5QJvGswtVh9lFDNKZ2y1PSbOr+"]['itemSectionRenderer']['contents'][0]")
				QuMmSnj1FDg7YUysd0AbWE.append("yeee["+AApLx5QJvGswtVh9lFDNKZ2y1PSbOr+"]['richItemRenderer']['content']")
				QuMmSnj1FDg7YUysd0AbWE.append("yeee["+AApLx5QJvGswtVh9lFDNKZ2y1PSbOr+"]")
				V5VXz0j3oa6t,TMaJdc0xOFKNf,FFkUYlfHsK2W5VzbAZjMvmCSE43 = Vlo5rATYdGPczsejuhN8JL2kwn0X(lloZWS9qf7eIpNnyPdDmG4,'',QuMmSnj1FDg7YUysd0AbWE)
				if V5VXz0j3oa6t: XNC2PZSLf96WMApwH.append([TMaJdc0xOFKNf,url,'3::'+milR6aMZ3O8y+'::'+AApLx5QJvGswtVh9lFDNKZ2y1PSbOr+'::0'])
			QuMmSnj1FDg7YUysd0AbWE.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			QuMmSnj1FDg7YUysd0AbWE.append("yddd[1]")
			V5VXz0j3oa6t,TMaJdc0xOFKNf,FFkUYlfHsK2W5VzbAZjMvmCSE43 = Vlo5rATYdGPczsejuhN8JL2kwn0X(YTCDh7u6WGyHP,'',QuMmSnj1FDg7YUysd0AbWE)
			if V5VXz0j3oa6t and XNC2PZSLf96WMApwH and 'continuationItemRenderer' in list(TMaJdc0xOFKNf.keys()):
				XNC2PZSLf96WMApwH.append([TMaJdc0xOFKNf,url,'3::0::0::0'])
	return lloZWS9qf7eIpNnyPdDmG4,Qa4GP7WYcILg9,XNC2PZSLf96WMApwH,TMoYrXjeRk
def nLw23OWJmp9jcQ0UGCigRSlXY5yMHZ(FLoRu67q9wjsnipY2ZX,lloZWS9qf7eIpNnyPdDmG4,url,M4Feb15G0QtrDlW6sPh9xNBnC3j):
	level,milR6aMZ3O8y,AApLx5QJvGswtVh9lFDNKZ2y1PSbOr,cf34hOSkPbyeIK29x5Xu = M4Feb15G0QtrDlW6sPh9xNBnC3j.split('::')
	QuMmSnj1FDg7YUysd0AbWE,pIoLqZEV4QHaX8 = [],[]
	QuMmSnj1FDg7YUysd0AbWE.append("yeee["+AApLx5QJvGswtVh9lFDNKZ2y1PSbOr+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	QuMmSnj1FDg7YUysd0AbWE.append("yeee["+AApLx5QJvGswtVh9lFDNKZ2y1PSbOr+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	QuMmSnj1FDg7YUysd0AbWE.append("yeee["+AApLx5QJvGswtVh9lFDNKZ2y1PSbOr+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	QuMmSnj1FDg7YUysd0AbWE.append("yeee["+AApLx5QJvGswtVh9lFDNKZ2y1PSbOr+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	QuMmSnj1FDg7YUysd0AbWE.append("yeee["+AApLx5QJvGswtVh9lFDNKZ2y1PSbOr+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	QuMmSnj1FDg7YUysd0AbWE.append("yeee["+AApLx5QJvGswtVh9lFDNKZ2y1PSbOr+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	QuMmSnj1FDg7YUysd0AbWE.append("yeee["+AApLx5QJvGswtVh9lFDNKZ2y1PSbOr+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	QuMmSnj1FDg7YUysd0AbWE.append("yeee["+AApLx5QJvGswtVh9lFDNKZ2y1PSbOr+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	QuMmSnj1FDg7YUysd0AbWE.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	QuMmSnj1FDg7YUysd0AbWE.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	QuMmSnj1FDg7YUysd0AbWE.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	QuMmSnj1FDg7YUysd0AbWE.append("yeee["+AApLx5QJvGswtVh9lFDNKZ2y1PSbOr+"]['reelShelfRenderer']['items']")
	QuMmSnj1FDg7YUysd0AbWE.append("yeee["+AApLx5QJvGswtVh9lFDNKZ2y1PSbOr+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	QuMmSnj1FDg7YUysd0AbWE.append("yeee")
	LtOrla64EbCxB80fRk3s,eBDnYNFz604WiqwPXrTOfcx,m3SKkYfVgLoWzBt86JnIXZ4 = Vlo5rATYdGPczsejuhN8JL2kwn0X(lloZWS9qf7eIpNnyPdDmG4,'',QuMmSnj1FDg7YUysd0AbWE)
	if level=='3' and LtOrla64EbCxB80fRk3s:
		if len(eBDnYNFz604WiqwPXrTOfcx)>0:
			for ZmWIcGhdFzNivK29EuB70DVC5Q in range(len(eBDnYNFz604WiqwPXrTOfcx)):
				cf34hOSkPbyeIK29x5Xu = str(ZmWIcGhdFzNivK29EuB70DVC5Q)
				QuMmSnj1FDg7YUysd0AbWE = []
				QuMmSnj1FDg7YUysd0AbWE.append("yfff["+cf34hOSkPbyeIK29x5Xu+"]['richItemRenderer']['content']")
				QuMmSnj1FDg7YUysd0AbWE.append("yfff["+cf34hOSkPbyeIK29x5Xu+"]['gameCardRenderer']['game']")
				QuMmSnj1FDg7YUysd0AbWE.append("yfff["+cf34hOSkPbyeIK29x5Xu+"]['itemSectionRenderer']['contents'][0]")
				QuMmSnj1FDg7YUysd0AbWE.append("yfff["+cf34hOSkPbyeIK29x5Xu+"]")
				V5VXz0j3oa6t,TMaJdc0xOFKNf,FFkUYlfHsK2W5VzbAZjMvmCSE43 = Vlo5rATYdGPczsejuhN8JL2kwn0X(eBDnYNFz604WiqwPXrTOfcx,'',QuMmSnj1FDg7YUysd0AbWE)
				if V5VXz0j3oa6t: pIoLqZEV4QHaX8.append([TMaJdc0xOFKNf,url,'4::'+milR6aMZ3O8y+'::'+AApLx5QJvGswtVh9lFDNKZ2y1PSbOr+'::'+cf34hOSkPbyeIK29x5Xu])
	return eBDnYNFz604WiqwPXrTOfcx,LtOrla64EbCxB80fRk3s,pIoLqZEV4QHaX8,m3SKkYfVgLoWzBt86JnIXZ4
def Vlo5rATYdGPczsejuhN8JL2kwn0X(riQnIlkHK86L4PSM,mOTzUAv73S1yDHg,gIpEL7clt4P8CFzSosihR):
	FLoRu67q9wjsnipY2ZX,mOTzUAv73S1yDHg = riQnIlkHK86L4PSM,mOTzUAv73S1yDHg
	YTCDh7u6WGyHP,mOTzUAv73S1yDHg = riQnIlkHK86L4PSM,mOTzUAv73S1yDHg
	lloZWS9qf7eIpNnyPdDmG4,mOTzUAv73S1yDHg = riQnIlkHK86L4PSM,mOTzUAv73S1yDHg
	eBDnYNFz604WiqwPXrTOfcx,mOTzUAv73S1yDHg = riQnIlkHK86L4PSM,mOTzUAv73S1yDHg
	TMaJdc0xOFKNf,hgcpXsMYiH3uW = riQnIlkHK86L4PSM,mOTzUAv73S1yDHg
	count = len(gIpEL7clt4P8CFzSosihR)
	for k0G4LTYt93po in range(count):
		try:
			f0QDK67Ctxg3 = eval(gIpEL7clt4P8CFzSosihR[k0G4LTYt93po])
			return True,f0QDK67Ctxg3,k0G4LTYt93po+1
		except: pass
	return False,'',0
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,M4Feb15G0QtrDlW6sPh9xNBnC3j='',data=''):
	LbR5Z9fygsPKjo,XNC2PZSLf96WMApwH,pIoLqZEV4QHaX8 = [],[],[]
	if '::' not in M4Feb15G0QtrDlW6sPh9xNBnC3j: M4Feb15G0QtrDlW6sPh9xNBnC3j = '1::0::0::0'
	level,milR6aMZ3O8y,AApLx5QJvGswtVh9lFDNKZ2y1PSbOr,cf34hOSkPbyeIK29x5Xu = M4Feb15G0QtrDlW6sPh9xNBnC3j.split('::')
	if level=='4': level,milR6aMZ3O8y,AApLx5QJvGswtVh9lFDNKZ2y1PSbOr,cf34hOSkPbyeIK29x5Xu = '1',milR6aMZ3O8y,AApLx5QJvGswtVh9lFDNKZ2y1PSbOr,cf34hOSkPbyeIK29x5Xu
	data = data.replace('_REMEMBERRESULTS_','')
	oo9SgGkiDbs3HRn7z8,FLoRu67q9wjsnipY2ZX,XfOb4VIcPY = p0aw4UgTIeO5Pv92XZCkJcDNlu(url,data)
	M4Feb15G0QtrDlW6sPh9xNBnC3j = level+'::'+milR6aMZ3O8y+'::'+AApLx5QJvGswtVh9lFDNKZ2y1PSbOr+'::'+cf34hOSkPbyeIK29x5Xu
	if level in ['1','2','3']:
		YTCDh7u6WGyHP,LpJnQgRVb2YX31Ica0HCtAMKh,LbR5Z9fygsPKjo,MM8GBAafuJUe4xYyXEchCItFmkrl = MOZBkwhY1sf9pILCoGceD3xbE(FLoRu67q9wjsnipY2ZX,url,M4Feb15G0QtrDlW6sPh9xNBnC3j)
		if not LpJnQgRVb2YX31Ica0HCtAMKh: return
		JJvFAVE6hkGfgMqxBw4yHo0U = len(LbR5Z9fygsPKjo)
		if JJvFAVE6hkGfgMqxBw4yHo0U<2:
			if level=='1': level = '2'
			LbR5Z9fygsPKjo = []
	M4Feb15G0QtrDlW6sPh9xNBnC3j = level+'::'+milR6aMZ3O8y+'::'+AApLx5QJvGswtVh9lFDNKZ2y1PSbOr+'::'+cf34hOSkPbyeIK29x5Xu
	if level in ['2','3']:
		lloZWS9qf7eIpNnyPdDmG4,Qa4GP7WYcILg9,XNC2PZSLf96WMApwH,TMoYrXjeRk = BNcyY9bDs6rqS0dmFuKHpei(FLoRu67q9wjsnipY2ZX,YTCDh7u6WGyHP,url,M4Feb15G0QtrDlW6sPh9xNBnC3j)
		if not Qa4GP7WYcILg9: return
		RUI86WhV143yDBjSxEJTFgtHf7G2 = len(XNC2PZSLf96WMApwH)
		if RUI86WhV143yDBjSxEJTFgtHf7G2<2:
			if level=='2': level = '3'
			XNC2PZSLf96WMApwH = []
	M4Feb15G0QtrDlW6sPh9xNBnC3j = level+'::'+milR6aMZ3O8y+'::'+AApLx5QJvGswtVh9lFDNKZ2y1PSbOr+'::'+cf34hOSkPbyeIK29x5Xu
	if level in ['3']:
		eBDnYNFz604WiqwPXrTOfcx,LtOrla64EbCxB80fRk3s,pIoLqZEV4QHaX8,m3SKkYfVgLoWzBt86JnIXZ4 = nLw23OWJmp9jcQ0UGCigRSlXY5yMHZ(FLoRu67q9wjsnipY2ZX,lloZWS9qf7eIpNnyPdDmG4,url,M4Feb15G0QtrDlW6sPh9xNBnC3j)
		if not LtOrla64EbCxB80fRk3s: return
		NoYMwqPse2ub6RpCLIZ0y9dvn = len(pIoLqZEV4QHaX8)
	for TMaJdc0xOFKNf,url,M4Feb15G0QtrDlW6sPh9xNBnC3j in LbR5Z9fygsPKjo+XNC2PZSLf96WMApwH+pIoLqZEV4QHaX8:
		Mpq961BPTAfkrC0t5 = ClLwQZGizU1IVYmDydTAfFqkxJE(TMaJdc0xOFKNf,url,M4Feb15G0QtrDlW6sPh9xNBnC3j)
	return
def ClLwQZGizU1IVYmDydTAfFqkxJE(TMaJdc0xOFKNf,url='',M4Feb15G0QtrDlW6sPh9xNBnC3j=''):
	if '::' in M4Feb15G0QtrDlW6sPh9xNBnC3j: level,milR6aMZ3O8y,AApLx5QJvGswtVh9lFDNKZ2y1PSbOr,cf34hOSkPbyeIK29x5Xu = M4Feb15G0QtrDlW6sPh9xNBnC3j.split('::')
	else: level,milR6aMZ3O8y,AApLx5QJvGswtVh9lFDNKZ2y1PSbOr,cf34hOSkPbyeIK29x5Xu = '1','0','0','0'
	V5VXz0j3oa6t,title,ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,count,vNbeHULAy6gc4iE,ssynRZt81lpVjmFk,JJjdqk87RSrNfTD9BzixM,Ns51bKrOnmj8F7MHdWA = U1UI9JX6HdbYza7t4rZSP(TMaJdc0xOFKNf)
	m0whqS5EkyiTjOIpvKZPM87r6 = '/videos?' in ekTrZlFMu0Kf5QztEnhAs or '/streams?' in ekTrZlFMu0Kf5QztEnhAs or '/playlists?' in ekTrZlFMu0Kf5QztEnhAs
	tAEPZIX3RKJul4V7 = '/channels?' in ekTrZlFMu0Kf5QztEnhAs or '/shorts?' in ekTrZlFMu0Kf5QztEnhAs
	if m0whqS5EkyiTjOIpvKZPM87r6 or tAEPZIX3RKJul4V7: ekTrZlFMu0Kf5QztEnhAs = url
	m0whqS5EkyiTjOIpvKZPM87r6 = 'watch?v=' not in ekTrZlFMu0Kf5QztEnhAs and '/playlist?list=' not in ekTrZlFMu0Kf5QztEnhAs
	tAEPZIX3RKJul4V7 = '/gaming' not in ekTrZlFMu0Kf5QztEnhAs  and '/feed/storefront' not in ekTrZlFMu0Kf5QztEnhAs
	if M4Feb15G0QtrDlW6sPh9xNBnC3j[0:5]=='3::0::' and m0whqS5EkyiTjOIpvKZPM87r6 and tAEPZIX3RKJul4V7: ekTrZlFMu0Kf5QztEnhAs = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in ekTrZlFMu0Kf5QztEnhAs:
		level,milR6aMZ3O8y,AApLx5QJvGswtVh9lFDNKZ2y1PSbOr,cf34hOSkPbyeIK29x5Xu = '1','0','0','0'
		M4Feb15G0QtrDlW6sPh9xNBnC3j = ''
	XfOb4VIcPY = ''
	if '/youtubei/v1/browse' in ekTrZlFMu0Kf5QztEnhAs or '/youtubei/v1/search' in ekTrZlFMu0Kf5QztEnhAs or '/my_main_page_shorts_link' in url:
		data = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.youtube.data')
		if data.count(':::')==4:
			ea0MVzhDifcQnxt,key,oufJnhglF8iLZHKUAxRp,tX4O1q5ICGu9n8mMYZHwF,dh1veN6mVBg7pQ = data.split(':::')
			XfOb4VIcPY = ea0MVzhDifcQnxt+':::'+key+':::'+oufJnhglF8iLZHKUAxRp+':::'+tX4O1q5ICGu9n8mMYZHwF+':::'+Ns51bKrOnmj8F7MHdWA
			if '/my_main_page_shorts_link' in url and not ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = url
			else: ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?key='+key
	if not title:
		global x1JgcflnTFAwXmRMoIZ
		x1JgcflnTFAwXmRMoIZ += 1
		title = 'فيديوهات '+str(x1JgcflnTFAwXmRMoIZ)
		M4Feb15G0QtrDlW6sPh9xNBnC3j = '3'+'::'+milR6aMZ3O8y+'::'+AApLx5QJvGswtVh9lFDNKZ2y1PSbOr+'::'+cf34hOSkPbyeIK29x5Xu
	if not V5VXz0j3oa6t: return False
	elif 'searchPyvRenderer' in str(TMaJdc0xOFKNf): return False
	elif '/about' in ekTrZlFMu0Kf5QztEnhAs: return False
	elif '/community' in ekTrZlFMu0Kf5QztEnhAs: return False
	elif 'continuationItemRenderer' in list(TMaJdc0xOFKNf.keys()) or 'continuationCommand' in list(TMaJdc0xOFKNf.keys()):
		if int(level)>1: level = str(int(level)-1)
		M4Feb15G0QtrDlW6sPh9xNBnC3j = level+'::'+milR6aMZ3O8y+'::'+AApLx5QJvGswtVh9lFDNKZ2y1PSbOr+'::'+cf34hOSkPbyeIK29x5Xu
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+':: '+'صفحة أخرى',ekTrZlFMu0Kf5QztEnhAs,144,pGjsvdyHfM,M4Feb15G0QtrDlW6sPh9xNBnC3j,XfOb4VIcPY)
	elif '/search' in ekTrZlFMu0Kf5QztEnhAs:
		title = ':: '+title
		M4Feb15G0QtrDlW6sPh9xNBnC3j = '3'+'::'+milR6aMZ3O8y+'::'+AApLx5QJvGswtVh9lFDNKZ2y1PSbOr+'::'+cf34hOSkPbyeIK29x5Xu
		url = url.replace('/search','')
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,145,'',M4Feb15G0QtrDlW6sPh9xNBnC3j,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not ekTrZlFMu0Kf5QztEnhAs:
		M4Feb15G0QtrDlW6sPh9xNBnC3j = '3'+'::'+milR6aMZ3O8y+'::'+AApLx5QJvGswtVh9lFDNKZ2y1PSbOr+'::'+cf34hOSkPbyeIK29x5Xu
		title = ':: '+title
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,144,pGjsvdyHfM,M4Feb15G0QtrDlW6sPh9xNBnC3j,XfOb4VIcPY)
	elif '/browse' in ekTrZlFMu0Kf5QztEnhAs and url==yONJxHER9BIDPpTV4YsWmc0n:
		title = ':: '+title
		M4Feb15G0QtrDlW6sPh9xNBnC3j = '2::0::0::0'
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,144,pGjsvdyHfM,M4Feb15G0QtrDlW6sPh9xNBnC3j,XfOb4VIcPY)
	elif not ekTrZlFMu0Kf5QztEnhAs and 'horizontalMovieListRenderer' in str(TMaJdc0xOFKNf):
		title = ':: '+title
		M4Feb15G0QtrDlW6sPh9xNBnC3j = '3::0::0::0'
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,144,pGjsvdyHfM,M4Feb15G0QtrDlW6sPh9xNBnC3j)
	elif 'messageRenderer' in str(TMaJdc0xOFKNf):
		uQNUfbZx9yj0F('link',tiCRYyX1bWd40Ir3PafQu+title,'',9999)
	elif ssynRZt81lpVjmFk:
		uQNUfbZx9yj0F('live',tiCRYyX1bWd40Ir3PafQu+ssynRZt81lpVjmFk+title,ekTrZlFMu0Kf5QztEnhAs,143,pGjsvdyHfM)
	elif '/playlist?list=' in ekTrZlFMu0Kf5QztEnhAs:
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'LIST'+count+':  '+title,ekTrZlFMu0Kf5QztEnhAs,144,pGjsvdyHfM,M4Feb15G0QtrDlW6sPh9xNBnC3j)
	elif '/shorts/' in ekTrZlFMu0Kf5QztEnhAs:
		ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.split('&list=',1)[0]
		uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,143,pGjsvdyHfM,vNbeHULAy6gc4iE)
	elif '/watch?v=' in ekTrZlFMu0Kf5QztEnhAs:
		if '&list=' in ekTrZlFMu0Kf5QztEnhAs and count:
			dUu9Hma1y6P0 = ekTrZlFMu0Kf5QztEnhAs.split('&list=',1)[1]
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+'/playlist?list='+dUu9Hma1y6P0
			M4Feb15G0QtrDlW6sPh9xNBnC3j = '3::0::0::0'
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'LIST'+count+':  '+title,ekTrZlFMu0Kf5QztEnhAs,144,pGjsvdyHfM,M4Feb15G0QtrDlW6sPh9xNBnC3j)
		else:
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.split('&list=',1)[0]
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,143,pGjsvdyHfM,vNbeHULAy6gc4iE)
	elif '/channel/' in ekTrZlFMu0Kf5QztEnhAs or '/c/' in ekTrZlFMu0Kf5QztEnhAs or ('/@' in ekTrZlFMu0Kf5QztEnhAs and ekTrZlFMu0Kf5QztEnhAs.count('/')==3):
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'CHNL'+count+':  '+title,ekTrZlFMu0Kf5QztEnhAs,144,pGjsvdyHfM,M4Feb15G0QtrDlW6sPh9xNBnC3j)
	elif '/user/' in ekTrZlFMu0Kf5QztEnhAs:
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'USER'+count+':  '+title,ekTrZlFMu0Kf5QztEnhAs,144,pGjsvdyHfM,M4Feb15G0QtrDlW6sPh9xNBnC3j)
	else:
		if not ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = url
		title = ':: '+title
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,144,pGjsvdyHfM,M4Feb15G0QtrDlW6sPh9xNBnC3j,XfOb4VIcPY)
	return True
def U1UI9JX6HdbYza7t4rZSP(TMaJdc0xOFKNf):
	V5VXz0j3oa6t,title,ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,count,vNbeHULAy6gc4iE,ssynRZt81lpVjmFk,JJjdqk87RSrNfTD9BzixM,dh1veN6mVBg7pQ = False,'','','','','','','',''
	if not isinstance(TMaJdc0xOFKNf,dict): return V5VXz0j3oa6t,title,ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,count,vNbeHULAy6gc4iE,ssynRZt81lpVjmFk,JJjdqk87RSrNfTD9BzixM,dh1veN6mVBg7pQ
	for Yiw73zqpMdXT8A0PmLUSDVQ6a9N4jZ in list(TMaJdc0xOFKNf.keys()):
		hgcpXsMYiH3uW = TMaJdc0xOFKNf[Yiw73zqpMdXT8A0PmLUSDVQ6a9N4jZ]
		if isinstance(hgcpXsMYiH3uW,dict): break
	QuMmSnj1FDg7YUysd0AbWE = []
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['header']['richListHeaderRenderer']['title']")
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['headline']['simpleText']")
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['unplayableText']['simpleText']")
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['formattedTitle']['simpleText']")
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['title']['simpleText']")
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['title']['runs'][0]['text']")
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['text']['simpleText']")
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['text']['runs'][0]['text']")
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['title']")
	QuMmSnj1FDg7YUysd0AbWE.append("item['title']")
	QuMmSnj1FDg7YUysd0AbWE.append("item['reelWatchEndpoint']['videoId']")
	V5VXz0j3oa6t,title,FFkUYlfHsK2W5VzbAZjMvmCSE43 = Vlo5rATYdGPczsejuhN8JL2kwn0X(TMaJdc0xOFKNf,hgcpXsMYiH3uW,QuMmSnj1FDg7YUysd0AbWE)
	QuMmSnj1FDg7YUysd0AbWE = []
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	QuMmSnj1FDg7YUysd0AbWE.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	QuMmSnj1FDg7YUysd0AbWE.append("item['commandMetadata']['webCommandMetadata']['url']")
	V5VXz0j3oa6t,ekTrZlFMu0Kf5QztEnhAs,FFkUYlfHsK2W5VzbAZjMvmCSE43 = Vlo5rATYdGPczsejuhN8JL2kwn0X(TMaJdc0xOFKNf,hgcpXsMYiH3uW,QuMmSnj1FDg7YUysd0AbWE)
	QuMmSnj1FDg7YUysd0AbWE = []
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['thumbnail']['thumbnails'][0]['url']")
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	QuMmSnj1FDg7YUysd0AbWE.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	V5VXz0j3oa6t,pGjsvdyHfM,FFkUYlfHsK2W5VzbAZjMvmCSE43 = Vlo5rATYdGPczsejuhN8JL2kwn0X(TMaJdc0xOFKNf,hgcpXsMYiH3uW,QuMmSnj1FDg7YUysd0AbWE)
	QuMmSnj1FDg7YUysd0AbWE = []
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['videoCount']")
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['videoCountText']['runs'][0]['text']")
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	V5VXz0j3oa6t,count,FFkUYlfHsK2W5VzbAZjMvmCSE43 = Vlo5rATYdGPczsejuhN8JL2kwn0X(TMaJdc0xOFKNf,hgcpXsMYiH3uW,QuMmSnj1FDg7YUysd0AbWE)
	QuMmSnj1FDg7YUysd0AbWE = []
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['lengthText']['simpleText']")
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	V5VXz0j3oa6t,vNbeHULAy6gc4iE,FFkUYlfHsK2W5VzbAZjMvmCSE43 = Vlo5rATYdGPczsejuhN8JL2kwn0X(TMaJdc0xOFKNf,hgcpXsMYiH3uW,QuMmSnj1FDg7YUysd0AbWE)
	QuMmSnj1FDg7YUysd0AbWE = []
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	QuMmSnj1FDg7YUysd0AbWE.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	V5VXz0j3oa6t,dh1veN6mVBg7pQ,FFkUYlfHsK2W5VzbAZjMvmCSE43 = Vlo5rATYdGPczsejuhN8JL2kwn0X(TMaJdc0xOFKNf,hgcpXsMYiH3uW,QuMmSnj1FDg7YUysd0AbWE)
	if 'LIVE' in vNbeHULAy6gc4iE: vNbeHULAy6gc4iE,ssynRZt81lpVjmFk = '','LIVE:  '
	if 'مباشر' in vNbeHULAy6gc4iE: vNbeHULAy6gc4iE,ssynRZt81lpVjmFk = '','LIVE:  '
	if 'badges' in list(hgcpXsMYiH3uW.keys()):
		xxUdv3DQoWAlIBEcbsfNhuJ1qka09L = str(hgcpXsMYiH3uW['badges'])
		if 'Free with Ads' in xxUdv3DQoWAlIBEcbsfNhuJ1qka09L: JJjdqk87RSrNfTD9BzixM = '$:  '
		if 'LIVE' in xxUdv3DQoWAlIBEcbsfNhuJ1qka09L: ssynRZt81lpVjmFk = 'LIVE:  '
		if 'Buy' in xxUdv3DQoWAlIBEcbsfNhuJ1qka09L or 'Rent' in xxUdv3DQoWAlIBEcbsfNhuJ1qka09L: JJjdqk87RSrNfTD9BzixM = '$$:  '
		if XSuCEhVPZvBIfwyFjipYaRks0(u'مباشر') in xxUdv3DQoWAlIBEcbsfNhuJ1qka09L: ssynRZt81lpVjmFk = 'LIVE:  '
		if XSuCEhVPZvBIfwyFjipYaRks0(u'شراء') in xxUdv3DQoWAlIBEcbsfNhuJ1qka09L: JJjdqk87RSrNfTD9BzixM = '$$:  '
		if XSuCEhVPZvBIfwyFjipYaRks0(u'استئجار') in xxUdv3DQoWAlIBEcbsfNhuJ1qka09L: JJjdqk87RSrNfTD9BzixM = '$$:  '
		if XSuCEhVPZvBIfwyFjipYaRks0(u'إعلانات') in xxUdv3DQoWAlIBEcbsfNhuJ1qka09L: JJjdqk87RSrNfTD9BzixM = '$:  '
	ekTrZlFMu0Kf5QztEnhAs = ffbxegm1XPSqIwp8i(ekTrZlFMu0Kf5QztEnhAs)
	if ekTrZlFMu0Kf5QztEnhAs and 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
	pGjsvdyHfM = pGjsvdyHfM.split('?')[0]
	if  pGjsvdyHfM and 'http' not in pGjsvdyHfM: pGjsvdyHfM = 'https:'+pGjsvdyHfM
	title = ffbxegm1XPSqIwp8i(title)
	if JJjdqk87RSrNfTD9BzixM: title = JJjdqk87RSrNfTD9BzixM+title
	vNbeHULAy6gc4iE = vNbeHULAy6gc4iE.replace(',','')
	count = count.replace(',','')
	count = u5h2Rckvw1E.findall('\d+',count)
	if count: count = count[0]
	else: count = ''
	return True,title,ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,count,vNbeHULAy6gc4iE,ssynRZt81lpVjmFk,JJjdqk87RSrNfTD9BzixM,dh1veN6mVBg7pQ
def p0aw4UgTIeO5Pv92XZCkJcDNlu(url,data='',VemfsE32zgI=''):
	if VemfsE32zgI=='': VemfsE32zgI = 'ytInitialData'
	UUSPoh1ckMtVexN6u = ncgQBtRa7qT2GJ3Wpd()
	emrzEIsMWO2GLw9lpKxSY7n0F = {'User-Agent':UUSPoh1ckMtVexN6u,'Cookie':'PREF=hl=ar'}
	global LLwCINEyZT9GHP7QMA1VlukcDjh
	if not data: data = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.youtube.data')
	if data.count(':::')==4: ea0MVzhDifcQnxt,key,oufJnhglF8iLZHKUAxRp,tX4O1q5ICGu9n8mMYZHwF,dh1veN6mVBg7pQ = data.split(':::')
	else: ea0MVzhDifcQnxt,key,oufJnhglF8iLZHKUAxRp,tX4O1q5ICGu9n8mMYZHwF,dh1veN6mVBg7pQ = '','','','',''
	XfOb4VIcPY = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":oufJnhglF8iLZHKUAxRp}}}
	if url==yONJxHER9BIDPpTV4YsWmc0n+'/shorts' or '/my_main_page_shorts_link' in url:
		url = yONJxHER9BIDPpTV4YsWmc0n+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		XfOb4VIcPY['sequenceParams'] = ea0MVzhDifcQnxt
		XfOb4VIcPY = str(XfOb4VIcPY)
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'POST',url,XfOb4VIcPY,emrzEIsMWO2GLw9lpKxSY7n0F,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = yONJxHER9BIDPpTV4YsWmc0n+'/youtubei/v1/guide?key='+key
		XfOb4VIcPY = str(XfOb4VIcPY)
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'POST',url,XfOb4VIcPY,emrzEIsMWO2GLw9lpKxSY7n0F,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and ea0MVzhDifcQnxt:
		XfOb4VIcPY['continuation'] = dh1veN6mVBg7pQ
		XfOb4VIcPY['context']['client']['visitorData'] = ea0MVzhDifcQnxt
		XfOb4VIcPY = str(XfOb4VIcPY)
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'POST',url,XfOb4VIcPY,emrzEIsMWO2GLw9lpKxSY7n0F,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and tX4O1q5ICGu9n8mMYZHwF:
		emrzEIsMWO2GLw9lpKxSY7n0F.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':oufJnhglF8iLZHKUAxRp})
		emrzEIsMWO2GLw9lpKxSY7n0F.update({'Cookie':'VISITOR_INFO1_LIVE='+tX4O1q5ICGu9n8mMYZHwF})
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',url,'',emrzEIsMWO2GLw9lpKxSY7n0F,'','','YOUTUBE-GET_PAGE_DATA-5th')
	else:
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',url,'',emrzEIsMWO2GLw9lpKxSY7n0F,'','','YOUTUBE-GET_PAGE_DATA-6th')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	LkKHrN2Stnw0avfuWO = u5h2Rckvw1E.findall('"innertubeApiKey".*?"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.I)
	if LkKHrN2Stnw0avfuWO: key = LkKHrN2Stnw0avfuWO[0]
	LkKHrN2Stnw0avfuWO = u5h2Rckvw1E.findall('"cver".*?"value".*?"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.I)
	if LkKHrN2Stnw0avfuWO: oufJnhglF8iLZHKUAxRp = LkKHrN2Stnw0avfuWO[0]
	LkKHrN2Stnw0avfuWO = u5h2Rckvw1E.findall('"visitorData".*?"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.I)
	if LkKHrN2Stnw0avfuWO: ea0MVzhDifcQnxt = LkKHrN2Stnw0avfuWO[0]
	cookies = RoQL91PphqCJg4W0e6Fnsl.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): tX4O1q5ICGu9n8mMYZHwF = cookies['VISITOR_INFO1_LIVE']
	hiBasuLtw8FnNYfO03IRxoHcWU = ea0MVzhDifcQnxt+':::'+key+':::'+oufJnhglF8iLZHKUAxRp+':::'+tX4O1q5ICGu9n8mMYZHwF+':::'+dh1veN6mVBg7pQ
	if VemfsE32zgI=='ytInitialData' and 'ytInitialData' in oo9SgGkiDbs3HRn7z8:
		vGW4t381dmqby = u5h2Rckvw1E.findall('window\["ytInitialData"\] = ({.*?});',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if not vGW4t381dmqby: vGW4t381dmqby = u5h2Rckvw1E.findall('var ytInitialData = ({.*?});',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		w03Ic9Zd7ACfJRE15M8FkYGP = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('str',vGW4t381dmqby[0])
	elif VemfsE32zgI=='ytInitialGuideData' and 'ytInitialGuideData' in oo9SgGkiDbs3HRn7z8:
		vGW4t381dmqby = u5h2Rckvw1E.findall('var ytInitialGuideData = ({.*?});',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		w03Ic9Zd7ACfJRE15M8FkYGP = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('str',vGW4t381dmqby[0])
	elif '</script>' not in oo9SgGkiDbs3HRn7z8: w03Ic9Zd7ACfJRE15M8FkYGP = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('str',oo9SgGkiDbs3HRn7z8)
	else: w03Ic9Zd7ACfJRE15M8FkYGP = ''
	if 0:
		FLoRu67q9wjsnipY2ZX = str(w03Ic9Zd7ACfJRE15M8FkYGP)
		if VVGRN7xiyj: FLoRu67q9wjsnipY2ZX = FLoRu67q9wjsnipY2ZX.encode('utf8')
		open('S:\\0000emad.dat','wb').write(FLoRu67q9wjsnipY2ZX)
	LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting('av.youtube.data',hiBasuLtw8FnNYfO03IRxoHcWU)
	return oo9SgGkiDbs3HRn7z8,w03Ic9Zd7ACfJRE15M8FkYGP,hiBasuLtw8FnNYfO03IRxoHcWU
def fa7kLtYT91BbFHiDh4UqWPK(url,M4Feb15G0QtrDlW6sPh9xNBnC3j):
	search = FBrXsYeCEp3()
	if not search: return
	search = search.replace(' ','+')
	gANn35esloKUydOipfSMC6RD2 = url+'/search?query='+search
	ll0a2AwztChcpsDUMi4rGW3b61XZES(gANn35esloKUydOipfSMC6RD2,M4Feb15G0QtrDlW6sPh9xNBnC3j)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if not search:
		search = FBrXsYeCEp3()
		if not search: return
	search = search.replace(' ','+')
	gANn35esloKUydOipfSMC6RD2 = yONJxHER9BIDPpTV4YsWmc0n+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in dza2VO9NvX: MMCHjyWK6X7JbregkiEUBdGV1m = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in dza2VO9NvX: MMCHjyWK6X7JbregkiEUBdGV1m = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in dza2VO9NvX: MMCHjyWK6X7JbregkiEUBdGV1m = '&sp=EgIQAg%253D%253D'
		else: MMCHjyWK6X7JbregkiEUBdGV1m = ''
		UcmHDPlLWaSf = gANn35esloKUydOipfSMC6RD2+MMCHjyWK6X7JbregkiEUBdGV1m
	else:
		G1F9EODkaMb6,iiLV5pgokTOdKScmvWXP,cMpjL2oavyVwKHBPn8EdhYqxSUk = [],[],''
		NNwH6oz0qhPSCu49 = ['بدون ترتيب','ترتيب حسب مدى الصلة','ترتيب حسب تاريخ التحميل','ترتيب حسب عدد المشاهدات','ترتيب حسب التقييم']
		jGNuKw7hOBPbIXmUn = ['','&sp=CAA%253D','&sp=CAI%253D','&sp=CAM%253D','&sp=CAE%253D']
		KMpi961QXxmc = tYysxJLreEBDdXMIjz4OPa('موقع يوتيوب - اختر الترتيب',NNwH6oz0qhPSCu49)
		if KMpi961QXxmc == -1: return
		oa63NHmdVbGFBZfvR9J4j8Pq1 = jGNuKw7hOBPbIXmUn[KMpi961QXxmc]
		oo9SgGkiDbs3HRn7z8,wqOY7uh8HXIfTVJ,data = p0aw4UgTIeO5Pv92XZCkJcDNlu(gANn35esloKUydOipfSMC6RD2+oa63NHmdVbGFBZfvR9J4j8Pq1)
		if wqOY7uh8HXIfTVJ:
			try:
				MfTdV953F7Jrx = wqOY7uh8HXIfTVJ['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for uC2p0awmkK7NWvY8zS1A3gUiDG9 in range(len(MfTdV953F7Jrx)):
					group = MfTdV953F7Jrx[uC2p0awmkK7NWvY8zS1A3gUiDG9]['searchFilterGroupRenderer']['filters']
					for gkeICa30v4FNhzV9HdrYtmwsEfW in range(len(group)):
						hgcpXsMYiH3uW = group[gkeICa30v4FNhzV9HdrYtmwsEfW]['searchFilterRenderer']
						if 'navigationEndpoint' in list(hgcpXsMYiH3uW.keys()):
							ekTrZlFMu0Kf5QztEnhAs = hgcpXsMYiH3uW['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.replace('\u0026','&')
							title = hgcpXsMYiH3uW['tooltip']
							title = title.replace('البحث عن ','')
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								cMpjL2oavyVwKHBPn8EdhYqxSUk = title
								olm59qifJbWpRsr1a3X7zBEIA = ekTrZlFMu0Kf5QztEnhAs
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ','')
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								cMpjL2oavyVwKHBPn8EdhYqxSUk = title
								olm59qifJbWpRsr1a3X7zBEIA = ekTrZlFMu0Kf5QztEnhAs
							if 'Sort by' in title: continue
							G1F9EODkaMb6.append(ffbxegm1XPSqIwp8i(title))
							iiLV5pgokTOdKScmvWXP.append(ekTrZlFMu0Kf5QztEnhAs)
			except: pass
		if not cMpjL2oavyVwKHBPn8EdhYqxSUk: D67C1ZpcT8g = ''
		else:
			G1F9EODkaMb6 = ['بدون فلتر',cMpjL2oavyVwKHBPn8EdhYqxSUk]+G1F9EODkaMb6
			iiLV5pgokTOdKScmvWXP = ['',olm59qifJbWpRsr1a3X7zBEIA]+iiLV5pgokTOdKScmvWXP
			ibzhVx8fr4aSntUw0cHu = tYysxJLreEBDdXMIjz4OPa('موقع يوتيوب - اختر الفلتر',G1F9EODkaMb6)
			if ibzhVx8fr4aSntUw0cHu == -1: return
			D67C1ZpcT8g = iiLV5pgokTOdKScmvWXP[ibzhVx8fr4aSntUw0cHu]
		if D67C1ZpcT8g: UcmHDPlLWaSf = yONJxHER9BIDPpTV4YsWmc0n+D67C1ZpcT8g
		elif oa63NHmdVbGFBZfvR9J4j8Pq1: UcmHDPlLWaSf = gANn35esloKUydOipfSMC6RD2+oa63NHmdVbGFBZfvR9J4j8Pq1
		else: UcmHDPlLWaSf = gANn35esloKUydOipfSMC6RD2
	ll0a2AwztChcpsDUMi4rGW3b61XZES(UcmHDPlLWaSf)
	return
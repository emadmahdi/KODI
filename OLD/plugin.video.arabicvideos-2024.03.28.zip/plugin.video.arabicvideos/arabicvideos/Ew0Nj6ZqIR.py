# -*- coding: utf-8 -*-
import sys as vdo2FnhPmAVRMJQZ0EIG8
XzBpdMGJhHZKC8Yveki5qb1jT4nQUg = vdo2FnhPmAVRMJQZ0EIG8.version_info [0] == 2
vykERrdZlF5K = 2048
GG02h4EolRYTs3iv = 7
def tci7BbCy6gT9MXkOEzhm (xVtfmzjd6RSsBEk2o34aHWC):
	global jMo7iTRkq0n1NPa35xheAVlbt
	oAJijr7NHwnfUGqyd8Ru6EImOtv = ord (xVtfmzjd6RSsBEk2o34aHWC [-1])
	wwpaJlB3bkXySOHFWUfoILC = xVtfmzjd6RSsBEk2o34aHWC [:-1]
	lqXRut6PnL = oAJijr7NHwnfUGqyd8Ru6EImOtv % len (wwpaJlB3bkXySOHFWUfoILC)
	rmaU71pZj3X = wwpaJlB3bkXySOHFWUfoILC [:lqXRut6PnL] + wwpaJlB3bkXySOHFWUfoILC [lqXRut6PnL:]
	if XzBpdMGJhHZKC8Yveki5qb1jT4nQUg:
		bbsiU0a49tw2dy = unicode () .join ([unichr (ord (Q9QUIWH6rK2BlmC) - vykERrdZlF5K - (ZXwWfDc9AF4yr2P + oAJijr7NHwnfUGqyd8Ru6EImOtv) % GG02h4EolRYTs3iv) for ZXwWfDc9AF4yr2P, Q9QUIWH6rK2BlmC in enumerate (rmaU71pZj3X)])
	else:
		bbsiU0a49tw2dy = str () .join ([chr (ord (Q9QUIWH6rK2BlmC) - vykERrdZlF5K - (ZXwWfDc9AF4yr2P + oAJijr7NHwnfUGqyd8Ru6EImOtv) % GG02h4EolRYTs3iv) for ZXwWfDc9AF4yr2P, Q9QUIWH6rK2BlmC in enumerate (rmaU71pZj3X)])
	return eval (bbsiU0a49tw2dy)
r3flT0zQPa5H7yXEgxJOt92Vc4Ao,cgtRBdXxSOk7WUfyDhPCls,cNaVb1vsT4qWOL0rpE=tci7BbCy6gT9MXkOEzhm,tci7BbCy6gT9MXkOEzhm,tci7BbCy6gT9MXkOEzhm
yruHDQOcB97ig,drHLAY5ENQFe2q9ptKGabo,qnPgZ9N15G6Oa8UpMASvLk=cNaVb1vsT4qWOL0rpE,cgtRBdXxSOk7WUfyDhPCls,r3flT0zQPa5H7yXEgxJOt92Vc4Ao
KKbpxUZnMcj6AJ4QdD,ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB,ggDRehOModi=qnPgZ9N15G6Oa8UpMASvLk,drHLAY5ENQFe2q9ptKGabo,yruHDQOcB97ig
xuztI5QWEKG70CPNdhk4vo6,bcgZJWV6UeNSkRA,shZ9eOcN2dJnPj=ggDRehOModi,ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB,KKbpxUZnMcj6AJ4QdD
BGhdkWsEvJjiMFTr3NLn1flU,nKLEi8CJumazx4qT,pcWq35MED2dtK=shZ9eOcN2dJnPj,bcgZJWV6UeNSkRA,xuztI5QWEKG70CPNdhk4vo6
yF29Xdsx35wI07Ce4,XikqnGVSK4v9d3uUICLhDxJyt1M,JLoPRXt93dpAB=pcWq35MED2dtK,nKLEi8CJumazx4qT,BGhdkWsEvJjiMFTr3NLn1flU
wwplD0tEehqH3kYQXs,tZ3gsrTEdzA1S6LXa9WI5px,Nqj35AXg06euY1G2d4bSUMQ8wlr=JLoPRXt93dpAB,XikqnGVSK4v9d3uUICLhDxJyt1M,yF29Xdsx35wI07Ce4
bbw2eajMlG,M6PIj8gl1fno7wcqTksDEBK4bU,CgG4PuyxsLA8WDzh3FfteZvKQMdom9=Nqj35AXg06euY1G2d4bSUMQ8wlr,tZ3gsrTEdzA1S6LXa9WI5px,wwplD0tEehqH3kYQXs
iifPEY9ABNzTQp,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ,PtXn0k9G3ocHRg=CgG4PuyxsLA8WDzh3FfteZvKQMdom9,M6PIj8gl1fno7wcqTksDEBK4bU,bbw2eajMlG
Tgoa16jMxvYX2,vvBChXmSty,InKG0i2r6hHDvgd=PtXn0k9G3ocHRg,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ,iifPEY9ABNzTQp
OyJ1o4AvmWlB75UkFRX,usaZLwSGe1k6VDp570yhB4bzWPiFq,oUlIcGH2JuWFLvimMXyBQdzK06ge=InKG0i2r6hHDvgd,vvBChXmSty,Tgoa16jMxvYX2
from LXgKztbkOf import *
dnS80F92qtLi4vw1(Tgoa16jMxvYX2(u"ࠧࡕࡇࡖࡘࠬ૛"),vvBChXmSty(u"ࠨࡖࡈࡗ࡙࠭૜"))
vwc2nNCU60eHkyPWB3qbYmxMhV7Dg = bcgZJWV6UeNSkRA(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡬ࡴࡻ࠺࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡷ࡬࡮ࡴ࡫ࡣࡴࡲࡥࡩࡨࡡ࡯ࡦ࠱ࡧࡴࡳ࠯࠲࠲ࡐࡆ࠳ࢀࡩࡱࠩ૝")
vwc2nNCU60eHkyPWB3qbYmxMhV7Dg = shZ9eOcN2dJnPj(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡵ࡫ࡥࡥࡶࡨࡷࡹ࠴ࡦࡵࡲ࠱ࡳࡹ࡫࡮ࡦࡶ࠱࡫ࡷ࠵ࡦࡪ࡮ࡨࡷ࠴ࡺࡥࡴࡶ࠴࠴࠵ࡱ࠮ࡥࡤࠪ૞")
sG6DJ2IAY17EbZceRVF(vwc2nNCU60eHkyPWB3qbYmxMhV7Dg,{},cNaVb1vsT4qWOL0rpE(u"࡚ࡲࡶࡧૡ"))
GZdtFyDU0caf89r = xuztI5QWEKG70CPNdhk4vo6(u"ࠫࡈࡀ࡜࡝ࡖࡈࡑࡕࡢ࡜ࡵࡧࡰࡴࡡࡢࡡࡢࠢࡥࡦࡡࡢแฮื࠱ࡱࡵ࠹ࠧ૟")
GZdtFyDU0caf89r = PtXn0k9G3ocHRg(u"ࠬࡉ࠺࡝࡞ࡗࡉࡒࡖ࡜࡝ࡶࡨࡱࡵࡢ࡜ࡢࡣࠣࡦࡧࡢ࡜ࡧ࡫࡯ࡩࡤ࠺࠸࠴࠶ࡢࡗࡍ࡜࡟ำ์สีฮࡥวๅำึ์้ࡥวๅล฼฼๊ࡥࠨึࠫࡢࠬศฮวัำࡢห้ำไ้ษฯ๎࠮࠴࡭ࡱ࠵ࠪૠ")
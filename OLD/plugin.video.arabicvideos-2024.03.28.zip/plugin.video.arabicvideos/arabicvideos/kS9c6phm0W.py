# -*- coding: utf-8 -*-
from LXgKztbkOf import *
ERLBl7fGCXQYchpgj6d = 'M3U'
unXlPWCM9EdmRAsybwT = '_M3U_'
aEcb9iDHs8ySolrwe1UYNt035 = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
isk5jc4tK0QuOhDUX3xRVqBp9vl = 4
def LNa8zbTyOvDQ5M(wMCm6g9qFyPT0xpneDUNc2lEhaZY,GZdtFyDU0caf89r,kc57B93HrojbDIXVipY,f0QP7qXsU4L9xtB,Iy4bwu3m6qORhDrQSd19HYo8,isbQc5EtyP76zR):
	global unXlPWCM9EdmRAsybwT
	try:
		nCSJkub4hZM3dH1KpRIUr8a7tBNevE = str(isbQc5EtyP76zR['folder'])
		unXlPWCM9EdmRAsybwT = '_MU'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE+'_'
	except: nCSJkub4hZM3dH1KpRIUr8a7tBNevE = ''
	try: IKBpN0ZXVri = str(isbQc5EtyP76zR['sequence'])
	except: IKBpN0ZXVri = ''
	if   wMCm6g9qFyPT0xpneDUNc2lEhaZY==710: QZSU5eYbuF2miCW8Dh67yHnMtOA = n5bS7jD0e3U8pkL()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==711: QZSU5eYbuF2miCW8Dh67yHnMtOA = ueMYIa0pJrsKtw(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,IKBpN0ZXVri)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==712: QZSU5eYbuF2miCW8Dh67yHnMtOA = jLA9FpzV52dQN1Zg(nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==713: QZSU5eYbuF2miCW8Dh67yHnMtOA = dK9CqzeR1asO(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,GZdtFyDU0caf89r,kc57B93HrojbDIXVipY,Iy4bwu3m6qORhDrQSd19HYo8)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==714: QZSU5eYbuF2miCW8Dh67yHnMtOA = tZwPW2bEz6S0OLXK84IjDYFqkde(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,GZdtFyDU0caf89r,kc57B93HrojbDIXVipY,Iy4bwu3m6qORhDrQSd19HYo8)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==715: QZSU5eYbuF2miCW8Dh67yHnMtOA = N5AOlmb8u1y4FHxvJXU(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,GZdtFyDU0caf89r,f0QP7qXsU4L9xtB)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==716: QZSU5eYbuF2miCW8Dh67yHnMtOA = Vdz0k1iSNQG9ReHhKUt(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,True)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==717: QZSU5eYbuF2miCW8Dh67yHnMtOA = NJntF2jX4Mk(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,True)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==718: QZSU5eYbuF2miCW8Dh67yHnMtOA = c39kB4yu7bDMCKwWexTq0UAI2(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,GZdtFyDU0caf89r,kc57B93HrojbDIXVipY)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==719: QZSU5eYbuF2miCW8Dh67yHnMtOA = GnJ5vKxzWhoYXw0IFyi6TSEVsNHaMp(kc57B93HrojbDIXVipY,nCSJkub4hZM3dH1KpRIUr8a7tBNevE,GZdtFyDU0caf89r,Iy4bwu3m6qORhDrQSd19HYo8)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==720: QZSU5eYbuF2miCW8Dh67yHnMtOA = TWdJepU45bz2MXCBPrY1Km0Sfouwv9(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,True)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==721: QZSU5eYbuF2miCW8Dh67yHnMtOA = BZplfFUgwNTyk8ID3(nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==722: QZSU5eYbuF2miCW8Dh67yHnMtOA = J526vqC8ctbVSOQfeiZa93(nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==723: QZSU5eYbuF2miCW8Dh67yHnMtOA = StWAhN0O3Vxw9lajrzfkpyRTeH8L(nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==726: QZSU5eYbuF2miCW8Dh67yHnMtOA = urlx3BIvK7di8PtOqhH(nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==729: QZSU5eYbuF2miCW8Dh67yHnMtOA = PPOcQHKRGS0eMz8tqdn(kc57B93HrojbDIXVipY,nCSJkub4hZM3dH1KpRIUr8a7tBNevE,GZdtFyDU0caf89r,Iy4bwu3m6qORhDrQSd19HYo8)
	else: QZSU5eYbuF2miCW8Dh67yHnMtOA = False
	return QZSU5eYbuF2miCW8Dh67yHnMtOA
def n5bS7jD0e3U8pkL():
	for nCSJkub4hZM3dH1KpRIUr8a7tBNevE in range(1,vMrXCkF9Kmu+1):
		unXlPWCM9EdmRAsybwT = '_MU'+str(nCSJkub4hZM3dH1KpRIUr8a7tBNevE)+'_'
		uQNUfbZx9yj0F('folder',unXlPWCM9EdmRAsybwT+'قائمة مجلد '+r5tHLX2ZFS1Kz9jRba0fsc[nCSJkub4hZM3dH1KpRIUr8a7tBNevE],'',720,'','','','',{'folder':nCSJkub4hZM3dH1KpRIUr8a7tBNevE})
	return
def TWdJepU45bz2MXCBPrY1Km0Sfouwv9(nCSJkub4hZM3dH1KpRIUr8a7tBNevE='',Na1U7ZMp3yQbhuOdcwS=''):
	if nCSJkub4hZM3dH1KpRIUr8a7tBNevE:
		xxBotuWjIY = {'folder':nCSJkub4hZM3dH1KpRIUr8a7tBNevE}
		C6Od2gzwh1pnmDuBNTaxQve3 = ''
	else:
		xxBotuWjIY = ''
		C6Od2gzwh1pnmDuBNTaxQve3 = ''
	Zvyq2rmzGh1MlpX = OSDp6mYAsavhl0boq(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,Na1U7ZMp3yQbhuOdcwS)
	if not Zvyq2rmzGh1MlpX:
		uQNUfbZx9yj0F('link',unXlPWCM9EdmRAsybwT+'[COLOR FFFFFF00] إضافة وتغيير رابط'+C6Od2gzwh1pnmDuBNTaxQve3+' '+r5tHLX2ZFS1Kz9jRba0fsc[1]+' [/COLOR]','',711,'','','','',{'folder':nCSJkub4hZM3dH1KpRIUr8a7tBNevE,'sequence':1})
		uQNUfbZx9yj0F('link',unXlPWCM9EdmRAsybwT+'[COLOR FFFFFF00] جلب ملفات'+C6Od2gzwh1pnmDuBNTaxQve3+' [/COLOR]','',712,'','','','',xxBotuWjIY)
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	else:
		uQNUfbZx9yj0F('folder',unXlPWCM9EdmRAsybwT+'بحث في الملفات'+C6Od2gzwh1pnmDuBNTaxQve3,'',729,'','','_REMEMBERRESULTS_','',xxBotuWjIY)
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		uQNUfbZx9yj0F('folder',unXlPWCM9EdmRAsybwT+'قنوات مصنفة مرتبة'+C6Od2gzwh1pnmDuBNTaxQve3,'LIVE_GROUPED_SORTED',713,'','','','',xxBotuWjIY)
		uQNUfbZx9yj0F('folder',unXlPWCM9EdmRAsybwT+'قنوات مصنفة من القسم'+C6Od2gzwh1pnmDuBNTaxQve3,'LIVE_FROM_GROUP_SORTED',713,'','','','',xxBotuWjIY)
		uQNUfbZx9yj0F('folder',unXlPWCM9EdmRAsybwT+'قنوات مصنفة من الاسم'+C6Od2gzwh1pnmDuBNTaxQve3,'LIVE_FROM_NAME_SORTED',713,'','','','',xxBotuWjIY)
		uQNUfbZx9yj0F('folder',unXlPWCM9EdmRAsybwT+'قنوات مصنفة بلا ترتيب'+C6Od2gzwh1pnmDuBNTaxQve3,'LIVE_GROUPED',713,'','','','',xxBotuWjIY)
		uQNUfbZx9yj0F('folder',unXlPWCM9EdmRAsybwT+'قنوات بلا ترتيب'+C6Od2gzwh1pnmDuBNTaxQve3,'LIVE_ORIGINAL_GROUPED',713,'','','','',xxBotuWjIY)
		uQNUfbZx9yj0F('folder',unXlPWCM9EdmRAsybwT+'قنوات مجهولة مرتبة'+C6Od2gzwh1pnmDuBNTaxQve3,'LIVE_UNKNOWN_GROUPED_SORTED',713,'','','','',xxBotuWjIY)
		uQNUfbZx9yj0F('folder',unXlPWCM9EdmRAsybwT+'قنوات مجهولة بلا ترتيب'+C6Od2gzwh1pnmDuBNTaxQve3,'LIVE_UNKNOWN_GROUPED',713,'','','','',xxBotuWjIY)
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		uQNUfbZx9yj0F('folder',unXlPWCM9EdmRAsybwT+'فيديوهات بلا ترتيب'+C6Od2gzwh1pnmDuBNTaxQve3,'VOD_ORIGINAL_GROUPED',713,'','','','',xxBotuWjIY)
		uQNUfbZx9yj0F('folder',unXlPWCM9EdmRAsybwT+'فيديوهات مصنفة القسم'+C6Od2gzwh1pnmDuBNTaxQve3,'VOD_FROM_GROUP_SORTED',713,'','','','',xxBotuWjIY)
		uQNUfbZx9yj0F('folder',unXlPWCM9EdmRAsybwT+'فيديوهات مصنفة من الاسم'+C6Od2gzwh1pnmDuBNTaxQve3,'VOD_FROM_NAME_SORTED',713,'','','','',xxBotuWjIY)
		uQNUfbZx9yj0F('folder',unXlPWCM9EdmRAsybwT+'فيديوهات مجهولة بلا ترتيب'+C6Od2gzwh1pnmDuBNTaxQve3,'VOD_UNKNOWN_GROUPED',713,'','','','',xxBotuWjIY)
		uQNUfbZx9yj0F('folder',unXlPWCM9EdmRAsybwT+'فيديوهات مجهولة مرتبة'+C6Od2gzwh1pnmDuBNTaxQve3,'VOD_UNKNOWN_GROUPED_SORTED',713,'','','','',xxBotuWjIY)
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for R2RD7JlOtrWXIFNgVnY0a5iwZp in range(1,isk5jc4tK0QuOhDUX3xRVqBp9vl+1):
		uQNUfbZx9yj0F('link',unXlPWCM9EdmRAsybwT+'إضافة وتغيير رابط'+C6Od2gzwh1pnmDuBNTaxQve3+' '+r5tHLX2ZFS1Kz9jRba0fsc[R2RD7JlOtrWXIFNgVnY0a5iwZp],'',711,'','','','',{'folder':nCSJkub4hZM3dH1KpRIUr8a7tBNevE,'sequence':R2RD7JlOtrWXIFNgVnY0a5iwZp})
	uQNUfbZx9yj0F('link',unXlPWCM9EdmRAsybwT+'جلب ملفات'+C6Od2gzwh1pnmDuBNTaxQve3,'',712,'','','','',xxBotuWjIY)
	uQNUfbZx9yj0F('link',unXlPWCM9EdmRAsybwT+'مسح ملفات'+C6Od2gzwh1pnmDuBNTaxQve3,'',717,'','','','',xxBotuWjIY)
	uQNUfbZx9yj0F('link',unXlPWCM9EdmRAsybwT+'عدد فيديوهات'+C6Od2gzwh1pnmDuBNTaxQve3,'',721,'','','','',xxBotuWjIY)
	uQNUfbZx9yj0F('link',unXlPWCM9EdmRAsybwT+'Referer تغيير'+C6Od2gzwh1pnmDuBNTaxQve3,'',726,'','','','',xxBotuWjIY)
	uQNUfbZx9yj0F('link',unXlPWCM9EdmRAsybwT+'User-Agent تغيير'+C6Od2gzwh1pnmDuBNTaxQve3,'',723,'','','','',xxBotuWjIY)
	return
def Vdz0k1iSNQG9ReHhKUt(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,Na1U7ZMp3yQbhuOdcwS=True):
	BeIEwVZ36k4Pc9TU,QiSdK6hOzeGJERC2FA4fnluT3mYNI = False,''
	jvQ4NfxUODpMY1Z5P,SSkBVzmeFbafMLotrGN7JwY = '',''
	uuiBFDtpqZyOAcaTEobsz4Khje,S0EXKGMckjfszwYLH69qtP8,Q6lqZnWMrDsj,Fm20Po1nGKWHQNrZAOgER57dJjp,lEDfqRNOxhUJBt3MGkK06o = G16y4pxhBjuKDrbw5FvNz(nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	if Fm20Po1nGKWHQNrZAOgER57dJjp=='': return False,'',''
	v1vaBXhQE6tsCjV73HkrNUpgI9DZK = JkqQF1cXCRKvsgiGmeLna9tO8ydN(nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	if uuiBFDtpqZyOAcaTEobsz4Khje:
		UyA2NgE6DjKsBRqMILZv5tXJ = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'GET',uuiBFDtpqZyOAcaTEobsz4Khje,'',v1vaBXhQE6tsCjV73HkrNUpgI9DZK,False,'','M3U-CHECK_ACCOUNT-1st')
		AxqI1TVGKPOjaYfE7F2ZH = UyA2NgE6DjKsBRqMILZv5tXJ.content
		if UyA2NgE6DjKsBRqMILZv5tXJ.succeeded:
			MrLbk4EPw1elvfK,UxXmA2qaHL,x57geAoQNSKYLmi1rBbfX,RutE87VLOWT04lmizcMPvUZHbSk,wVpsUkhxALMdN1tT6 = 0,0,'','',''
			try:
				w3yv48p5i7rRgPk6nO9AhlzZCLc = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('dict',AxqI1TVGKPOjaYfE7F2ZH)
				QiSdK6hOzeGJERC2FA4fnluT3mYNI = w3yv48p5i7rRgPk6nO9AhlzZCLc['user_info']['status']
				BeIEwVZ36k4Pc9TU = True
				x57geAoQNSKYLmi1rBbfX = w3yv48p5i7rRgPk6nO9AhlzZCLc['server_info']['time_now']
			except: pass
			if x57geAoQNSKYLmi1rBbfX:
				try:
					con6vrO4DRYp5AVzIBsNeW72FM8qZP = YVJPFvuI2CS5KObiZt.strptime(x57geAoQNSKYLmi1rBbfX,'%Y.%m.%d %H:%M:%S')
					MrLbk4EPw1elvfK = int(YVJPFvuI2CS5KObiZt.mktime(con6vrO4DRYp5AVzIBsNeW72FM8qZP))
					UxXmA2qaHL = int(s8bXSagYdim62TwIpQzGtUqeLhA1J-MrLbk4EPw1elvfK)
					UxXmA2qaHL = int((UxXmA2qaHL+900)/1800)*1800
				except: pass
				try:
					con6vrO4DRYp5AVzIBsNeW72FM8qZP = YVJPFvuI2CS5KObiZt.localtime(int(w3yv48p5i7rRgPk6nO9AhlzZCLc['user_info']['created_at']))
					RutE87VLOWT04lmizcMPvUZHbSk = YVJPFvuI2CS5KObiZt.strftime('%Y.%m.%d %H:%M:%S',con6vrO4DRYp5AVzIBsNeW72FM8qZP)
				except: pass
				try:
					con6vrO4DRYp5AVzIBsNeW72FM8qZP = YVJPFvuI2CS5KObiZt.localtime(int(w3yv48p5i7rRgPk6nO9AhlzZCLc['user_info']['exp_date']))
					wVpsUkhxALMdN1tT6 = YVJPFvuI2CS5KObiZt.strftime('%Y.%m.%d %H:%M:%S',con6vrO4DRYp5AVzIBsNeW72FM8qZP)
				except: pass
			LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting('av.m3u.timestamp_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE,str(s8bXSagYdim62TwIpQzGtUqeLhA1J))
			LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting('av.m3u.timediff_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE,str(UxXmA2qaHL))
			try:
				BpJD7w50dxMKCoEgzLirbWSVea6AnZ = '"server_info":'+AxqI1TVGKPOjaYfE7F2ZH.split('"server_info":')[1]
				BpJD7w50dxMKCoEgzLirbWSVea6AnZ = BpJD7w50dxMKCoEgzLirbWSVea6AnZ.replace(':',': ').replace(',',', ').replace('}}','}')
				WFjrM2Cp7kJose0 = u5h2Rckvw1E.findall('"url": "(.*?)", "port": "(.*?)"',BpJD7w50dxMKCoEgzLirbWSVea6AnZ,u5h2Rckvw1E.DOTALL)
				jvQ4NfxUODpMY1Z5P,SSkBVzmeFbafMLotrGN7JwY = WFjrM2Cp7kJose0[0]
			except: BeIEwVZ36k4Pc9TU = False
			if BeIEwVZ36k4Pc9TU and Na1U7ZMp3yQbhuOdcwS:
				max = w3yv48p5i7rRgPk6nO9AhlzZCLc['user_info']['max_connections']
				YQJreMglBwOj6DUx7XcLtEAdiq = w3yv48p5i7rRgPk6nO9AhlzZCLc['user_info']['active_cons']
				GA56UIzFrLugD0c7y = w3yv48p5i7rRgPk6nO9AhlzZCLc['user_info']['is_trial']
				oJ0bVk32Mftxe7FpNRQs = uuiBFDtpqZyOAcaTEobsz4Khje.split('?',1)
				MLPwxur5kaYlBtqcn = 'URL:  [COLOR FFC89008]'+uuiBFDtpqZyOAcaTEobsz4Khje+'[/COLOR]'
				MLPwxur5kaYlBtqcn += '\n\nStatus:  '+'[COLOR FFC89008]'+QiSdK6hOzeGJERC2FA4fnluT3mYNI+'[/COLOR]'
				MLPwxur5kaYlBtqcn += '\nTrial:    '+'[COLOR FFC89008]'+str(GA56UIzFrLugD0c7y=='1')+'[/COLOR]'
				MLPwxur5kaYlBtqcn += '\nCreated  At:  '+'[COLOR FFC89008]'+RutE87VLOWT04lmizcMPvUZHbSk+'[/COLOR]'
				MLPwxur5kaYlBtqcn += '\nExpiry Date:  '+'[COLOR FFC89008]'+wVpsUkhxALMdN1tT6+'[/COLOR]'
				MLPwxur5kaYlBtqcn += '\nConnections   ( Active / Maximum ) :  '+'[COLOR FFC89008]'+YQJreMglBwOj6DUx7XcLtEAdiq+' / '+max+'[/COLOR]'
				MLPwxur5kaYlBtqcn += '\nAllowed Outputs:   '+'[COLOR FFC89008]'+" , ".join(w3yv48p5i7rRgPk6nO9AhlzZCLc['user_info']['allowed_output_formats'])+'[/COLOR]'
				MLPwxur5kaYlBtqcn += '\n\n'+BpJD7w50dxMKCoEgzLirbWSVea6AnZ
				if QiSdK6hOzeGJERC2FA4fnluT3mYNI=='Active': r57bsFUQ9l83v4tq('الاشتراك يعمل بدون مشاكل',MLPwxur5kaYlBtqcn)
				else: r57bsFUQ9l83v4tq('يبدو أن هناك مشكلة في الاشتراك',MLPwxur5kaYlBtqcn)
	if uuiBFDtpqZyOAcaTEobsz4Khje and BeIEwVZ36k4Pc9TU and QiSdK6hOzeGJERC2FA4fnluT3mYNI=='Active':
		l0SAerv8zGH2Wa('NOTICE','.  Checking M3U URL   [ M3U account is OK ]   [ '+uuiBFDtpqZyOAcaTEobsz4Khje+' ]')
		JJG0EdY1NQXfSRwm = True
	else:
		l0SAerv8zGH2Wa('ERROR_LINES','Checking M3U URL   [ Does not work ]   [ '+uuiBFDtpqZyOAcaTEobsz4Khje+' ]')
		if Na1U7ZMp3yQbhuOdcwS: xl9MFt1AmY0GrkENug8n('','','فحص اشتراك ـM3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		JJG0EdY1NQXfSRwm = False
	return JJG0EdY1NQXfSRwm,jvQ4NfxUODpMY1Z5P,SSkBVzmeFbafMLotrGN7JwY
def tZwPW2bEz6S0OLXK84IjDYFqkde(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,Dmj48aHieZnxWPEgC,yyq0WdrjtC4XMfOTI,EnvI67ZlRzSyjegGuxi2kC9,Na1U7ZMp3yQbhuOdcwS=True):
	if not EnvI67ZlRzSyjegGuxi2kC9: EnvI67ZlRzSyjegGuxi2kC9 = '1'
	if not OSDp6mYAsavhl0boq(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,Na1U7ZMp3yQbhuOdcwS): return
	Hj0zNOTDePKkIviZqFm2oQrVwp4hC3 = keRHziQrENXZW07oBwTm(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,Dmj48aHieZnxWPEgC)
	GHZEu6VbXDjk5sCmohY4M2c1p = AsTbx64cCEi1(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,'list',Dmj48aHieZnxWPEgC,yyq0WdrjtC4XMfOTI)
	vH6Uxo8MJbPK4kWXz9CYBmE = int(EnvI67ZlRzSyjegGuxi2kC9)*100
	kRnixKJ5qH2LF9I = vH6Uxo8MJbPK4kWXz9CYBmE-100
	for wWXVYjrFaCg9zpboThAMQBU8iHJc,ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,GZdtFyDU0caf89r,f8dLQuoR4E3Kalqn in GHZEu6VbXDjk5sCmohY4M2c1p[kRnixKJ5qH2LF9I:vH6Uxo8MJbPK4kWXz9CYBmE]:
		px9VuPiXvHrO1o0hJStC = ('GROUPED' in Dmj48aHieZnxWPEgC or Dmj48aHieZnxWPEgC=='ALL')
		piQR1mFk7DuCl2fbW = ('GROUPED' not in Dmj48aHieZnxWPEgC and Dmj48aHieZnxWPEgC!='ALL')
		if px9VuPiXvHrO1o0hJStC or piQR1mFk7DuCl2fbW:
			if   'ARCHIVED'  in Dmj48aHieZnxWPEgC: YD56nkJmsd.append(['folder',unXlPWCM9EdmRAsybwT+ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,GZdtFyDU0caf89r,718,f8dLQuoR4E3Kalqn,'','ARCHIVED','',{'folder':nCSJkub4hZM3dH1KpRIUr8a7tBNevE}])
			elif 'EPG' 		 in Dmj48aHieZnxWPEgC: YD56nkJmsd.append(['folder',unXlPWCM9EdmRAsybwT+ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,GZdtFyDU0caf89r,718,f8dLQuoR4E3Kalqn,'','FULL_EPG','',{'folder':nCSJkub4hZM3dH1KpRIUr8a7tBNevE}])
			elif 'TIMESHIFT' in Dmj48aHieZnxWPEgC: YD56nkJmsd.append(['folder',unXlPWCM9EdmRAsybwT+ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,GZdtFyDU0caf89r,718,f8dLQuoR4E3Kalqn,'','TIMESHIFT','',{'folder':nCSJkub4hZM3dH1KpRIUr8a7tBNevE}])
			elif 'LIVE' 	 in Dmj48aHieZnxWPEgC: YD56nkJmsd.append(['live',unXlPWCM9EdmRAsybwT+ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,GZdtFyDU0caf89r,715,f8dLQuoR4E3Kalqn,'','',wWXVYjrFaCg9zpboThAMQBU8iHJc,{'folder':nCSJkub4hZM3dH1KpRIUr8a7tBNevE}])
			else: YD56nkJmsd.append(['video',unXlPWCM9EdmRAsybwT+ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,GZdtFyDU0caf89r,715,f8dLQuoR4E3Kalqn,'','','',{'folder':nCSJkub4hZM3dH1KpRIUr8a7tBNevE}])
	NiW1bXUTvQyzq4rBJeDaEShIC = len(GHZEu6VbXDjk5sCmohY4M2c1p)
	AAF5lDV1fcPn2T8(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,EnvI67ZlRzSyjegGuxi2kC9,Dmj48aHieZnxWPEgC,714,NiW1bXUTvQyzq4rBJeDaEShIC,yyq0WdrjtC4XMfOTI)
	return
def tKgEo0kFnfMiQCY2RuZ3yH(oKgRXzDpSWeFP6CENGr3UcItJvfL):
	uQNUfbZx9yj0F('link',oKgRXzDpSWeFP6CENGr3UcItJvfL+'هذه القائمة إما فارغة أو غير موجودة','',9999)
	uQNUfbZx9yj0F('link',oKgRXzDpSWeFP6CENGr3UcItJvfL+'أو الخدمة غير موجودة في اشتراكك','',9999)
	uQNUfbZx9yj0F('link',oKgRXzDpSWeFP6CENGr3UcItJvfL+'أو رابط M3U الذي أنت أضفته غير صحيح','',9999)
	return
def dK9CqzeR1asO(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,Dmj48aHieZnxWPEgC,yyq0WdrjtC4XMfOTI,EnvI67ZlRzSyjegGuxi2kC9,ssMXQpFfOGcNYWq1='',Na1U7ZMp3yQbhuOdcwS=True):
	if not EnvI67ZlRzSyjegGuxi2kC9: EnvI67ZlRzSyjegGuxi2kC9 = '1'
	oKgRXzDpSWeFP6CENGr3UcItJvfL = unXlPWCM9EdmRAsybwT
	if not OSDp6mYAsavhl0boq(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,Na1U7ZMp3yQbhuOdcwS): return False
	if '__SERIES__' in yyq0WdrjtC4XMfOTI: eWGKDLlZrS2,GrN4sPXHeJB9EcIivLfkMYulb = yyq0WdrjtC4XMfOTI.split('__SERIES__')
	else: eWGKDLlZrS2,GrN4sPXHeJB9EcIivLfkMYulb = yyq0WdrjtC4XMfOTI,''
	Hj0zNOTDePKkIviZqFm2oQrVwp4hC3 = keRHziQrENXZW07oBwTm(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,Dmj48aHieZnxWPEgC)
	mMQpxAPsLXUIR1k6Jd5E74GSYl = AsTbx64cCEi1(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,'list',Dmj48aHieZnxWPEgC,'__GROUPS__')
	if not mMQpxAPsLXUIR1k6Jd5E74GSYl: return False
	M43qv7StXLy = []
	for HwuFsvM9jV8yY,f8dLQuoR4E3Kalqn in mMQpxAPsLXUIR1k6Jd5E74GSYl:
		if '===== ===== =====' in HwuFsvM9jV8yY:
			uQNUfbZx9yj0F('link',oKgRXzDpSWeFP6CENGr3UcItJvfL+HwuFsvM9jV8yY,'',9999)
			uQNUfbZx9yj0F('link',oKgRXzDpSWeFP6CENGr3UcItJvfL+HwuFsvM9jV8yY,'',9999)
			continue
		if ssMXQpFfOGcNYWq1:
			if '__SERIES__' in HwuFsvM9jV8yY: oKgRXzDpSWeFP6CENGr3UcItJvfL = 'SERIES'
			elif '!!__UNKNOWN__!!' in HwuFsvM9jV8yY: oKgRXzDpSWeFP6CENGr3UcItJvfL = 'UNKNOWN'
			elif 'LIVE' in Dmj48aHieZnxWPEgC: oKgRXzDpSWeFP6CENGr3UcItJvfL = 'LIVE'
			else: oKgRXzDpSWeFP6CENGr3UcItJvfL = 'VIDEOS'
			oKgRXzDpSWeFP6CENGr3UcItJvfL = ',[COLOR FFC89008]'+oKgRXzDpSWeFP6CENGr3UcItJvfL+': [/COLOR]'
		if '__SERIES__' in HwuFsvM9jV8yY: UpiJN4usedRHZ,ikI0pbhtcGe = HwuFsvM9jV8yY.split('__SERIES__')
		else: UpiJN4usedRHZ,ikI0pbhtcGe = HwuFsvM9jV8yY,''
		if not yyq0WdrjtC4XMfOTI:
			if UpiJN4usedRHZ in M43qv7StXLy: continue
			M43qv7StXLy.append(UpiJN4usedRHZ)
			if 'RANDOM' in ssMXQpFfOGcNYWq1: uQNUfbZx9yj0F('folder',oKgRXzDpSWeFP6CENGr3UcItJvfL+UpiJN4usedRHZ,Dmj48aHieZnxWPEgC,168,'','1',HwuFsvM9jV8yY,'',{'folder':nCSJkub4hZM3dH1KpRIUr8a7tBNevE})
			elif '__SERIES__' in HwuFsvM9jV8yY: uQNUfbZx9yj0F('folder',oKgRXzDpSWeFP6CENGr3UcItJvfL+UpiJN4usedRHZ,Dmj48aHieZnxWPEgC,713,'','1',HwuFsvM9jV8yY,'',{'folder':nCSJkub4hZM3dH1KpRIUr8a7tBNevE})
			else: uQNUfbZx9yj0F('folder',oKgRXzDpSWeFP6CENGr3UcItJvfL+UpiJN4usedRHZ,Dmj48aHieZnxWPEgC,714,'','1',HwuFsvM9jV8yY,'',{'folder':nCSJkub4hZM3dH1KpRIUr8a7tBNevE})
		elif '__SERIES__' in HwuFsvM9jV8yY and UpiJN4usedRHZ==eWGKDLlZrS2:
			if ikI0pbhtcGe in M43qv7StXLy: continue
			M43qv7StXLy.append(ikI0pbhtcGe)
			if 'RANDOM' in ssMXQpFfOGcNYWq1: uQNUfbZx9yj0F('folder',oKgRXzDpSWeFP6CENGr3UcItJvfL+ikI0pbhtcGe,Dmj48aHieZnxWPEgC,168,'','1',HwuFsvM9jV8yY,'',{'folder':nCSJkub4hZM3dH1KpRIUr8a7tBNevE})
			else: uQNUfbZx9yj0F('folder',oKgRXzDpSWeFP6CENGr3UcItJvfL+ikI0pbhtcGe,Dmj48aHieZnxWPEgC,714,f8dLQuoR4E3Kalqn,'1',HwuFsvM9jV8yY,'',{'folder':nCSJkub4hZM3dH1KpRIUr8a7tBNevE})
	YD56nkJmsd[:] = sorted(YD56nkJmsd,reverse=False,key=lambda bbqxQZ2thM0: bbqxQZ2thM0[1].lower())
	if not ssMXQpFfOGcNYWq1:
		vH6Uxo8MJbPK4kWXz9CYBmE = int(EnvI67ZlRzSyjegGuxi2kC9)*100
		kRnixKJ5qH2LF9I = vH6Uxo8MJbPK4kWXz9CYBmE-100
		NiW1bXUTvQyzq4rBJeDaEShIC = len(YD56nkJmsd)
		YD56nkJmsd[:] = YD56nkJmsd[kRnixKJ5qH2LF9I:vH6Uxo8MJbPK4kWXz9CYBmE]
		AAF5lDV1fcPn2T8(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,EnvI67ZlRzSyjegGuxi2kC9,Dmj48aHieZnxWPEgC,713,NiW1bXUTvQyzq4rBJeDaEShIC,yyq0WdrjtC4XMfOTI)
	return True
def c39kB4yu7bDMCKwWexTq0UAI2(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,GZdtFyDU0caf89r,cBL40TneKajfkb5hqCAxQZyJzYiRO):
	if not OSDp6mYAsavhl0boq(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,True): return
	v1vaBXhQE6tsCjV73HkrNUpgI9DZK = JkqQF1cXCRKvsgiGmeLna9tO8ydN(nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	MrLbk4EPw1elvfK = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.m3u.timestamp_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	if not MrLbk4EPw1elvfK or s8bXSagYdim62TwIpQzGtUqeLhA1J-int(MrLbk4EPw1elvfK)>24*PPC3GlfZAh68:
		JJG0EdY1NQXfSRwm,jvQ4NfxUODpMY1Z5P,SSkBVzmeFbafMLotrGN7JwY = Vdz0k1iSNQG9ReHhKUt(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,False)
		if not JJG0EdY1NQXfSRwm: return
	UxXmA2qaHL = int(LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.m3u.timediff_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE))
	Q6lqZnWMrDsj = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.m3u.server_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	Fm20Po1nGKWHQNrZAOgER57dJjp = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.m3u.username_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	lEDfqRNOxhUJBt3MGkK06o = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.m3u.password_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	i1uY8ICOPgldFBeKR74 = GZdtFyDU0caf89r.split('/')
	v8FtmIMa9QGw7bXOUr5jC = i1uY8ICOPgldFBeKR74[-1].replace('.ts','').replace('.m3u8','')
	if cBL40TneKajfkb5hqCAxQZyJzYiRO=='SHORT_EPG': I05aW7USxVj = 'get_short_epg'
	else: I05aW7USxVj = 'get_simple_data_table'
	uuiBFDtpqZyOAcaTEobsz4Khje,S0EXKGMckjfszwYLH69qtP8,Q6lqZnWMrDsj,Fm20Po1nGKWHQNrZAOgER57dJjp,lEDfqRNOxhUJBt3MGkK06o = G16y4pxhBjuKDrbw5FvNz(nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	if not Fm20Po1nGKWHQNrZAOgER57dJjp: return
	PSwA6poUkyaqmFsHirWR4NjZVD9T8 = uuiBFDtpqZyOAcaTEobsz4Khje+'&action='+I05aW7USxVj+'&stream_id='+v8FtmIMa9QGw7bXOUr5jC
	AxqI1TVGKPOjaYfE7F2ZH = fxJ4gsLbnu6(a2VuAbpQkGfMwSIcsP1XH6mletyzx,PSwA6poUkyaqmFsHirWR4NjZVD9T8,'',v1vaBXhQE6tsCjV73HkrNUpgI9DZK,'','M3U-EPG_ITEMS-2nd')
	LMfjkTYpFGOxtd50s = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('dict',AxqI1TVGKPOjaYfE7F2ZH)
	WiLQg9nCG106oscb4NPkzZOI = LMfjkTYpFGOxtd50s['epg_listings']
	ddfB6KUu1pxSTLHgG3bXNwV80mlq = []
	if cBL40TneKajfkb5hqCAxQZyJzYiRO in ['ARCHIVED','TIMESHIFT']:
		for w3yv48p5i7rRgPk6nO9AhlzZCLc in WiLQg9nCG106oscb4NPkzZOI:
			if w3yv48p5i7rRgPk6nO9AhlzZCLc['has_archive']==1:
				ddfB6KUu1pxSTLHgG3bXNwV80mlq.append(w3yv48p5i7rRgPk6nO9AhlzZCLc)
				if cBL40TneKajfkb5hqCAxQZyJzYiRO in ['TIMESHIFT']: break
		if not ddfB6KUu1pxSTLHgG3bXNwV80mlq: return
		uQNUfbZx9yj0F('link',unXlPWCM9EdmRAsybwT+'[COLOR FFC89008]الملفات الأولي بهذه القائمة قد لا تعمل[/COLOR]','',9999)
		if cBL40TneKajfkb5hqCAxQZyJzYiRO in ['TIMESHIFT']:
			v7OIRiE3mPj28nK9Vh = 2
			vrmnj4oxIV = v7OIRiE3mPj28nK9Vh*PPC3GlfZAh68
			ddfB6KUu1pxSTLHgG3bXNwV80mlq = []
			o64ZsYcqUOD0twRlLn8SuWPKXbd = int(int(w3yv48p5i7rRgPk6nO9AhlzZCLc['start_timestamp'])/vrmnj4oxIV)*vrmnj4oxIV
			eXm0FHGyxRoLr9SQTJv = s8bXSagYdim62TwIpQzGtUqeLhA1J+vrmnj4oxIV
			IVA5NB1R7CywazY8PgvD6XOJ4den = int((eXm0FHGyxRoLr9SQTJv-o64ZsYcqUOD0twRlLn8SuWPKXbd)/PPC3GlfZAh68)
			for TVYMxjoz0i1myUWNdAclErwZ6I3PC in range(IVA5NB1R7CywazY8PgvD6XOJ4den):
				if TVYMxjoz0i1myUWNdAclErwZ6I3PC>=6:
					if TVYMxjoz0i1myUWNdAclErwZ6I3PC%v7OIRiE3mPj28nK9Vh!=0: continue
					WoZL2urv9CfqaGN08w3mTMcE7SQJ = vrmnj4oxIV
				else: WoZL2urv9CfqaGN08w3mTMcE7SQJ = vrmnj4oxIV//2
				PlYOI5EdC4bGezVfNBgW = o64ZsYcqUOD0twRlLn8SuWPKXbd+TVYMxjoz0i1myUWNdAclErwZ6I3PC*PPC3GlfZAh68
				w3yv48p5i7rRgPk6nO9AhlzZCLc = {}
				w3yv48p5i7rRgPk6nO9AhlzZCLc['title'] = ''
				con6vrO4DRYp5AVzIBsNeW72FM8qZP = YVJPFvuI2CS5KObiZt.localtime(PlYOI5EdC4bGezVfNBgW-UxXmA2qaHL-PPC3GlfZAh68)
				w3yv48p5i7rRgPk6nO9AhlzZCLc['start'] = YVJPFvuI2CS5KObiZt.strftime('%Y.%m.%d %H:%M:%S',con6vrO4DRYp5AVzIBsNeW72FM8qZP)
				w3yv48p5i7rRgPk6nO9AhlzZCLc['start_timestamp'] = str(PlYOI5EdC4bGezVfNBgW)
				w3yv48p5i7rRgPk6nO9AhlzZCLc['stop_timestamp'] = str(PlYOI5EdC4bGezVfNBgW+WoZL2urv9CfqaGN08w3mTMcE7SQJ)
				ddfB6KUu1pxSTLHgG3bXNwV80mlq.append(w3yv48p5i7rRgPk6nO9AhlzZCLc)
	elif cBL40TneKajfkb5hqCAxQZyJzYiRO in ['SHORT_EPG','FULL_EPG']: ddfB6KUu1pxSTLHgG3bXNwV80mlq = WiLQg9nCG106oscb4NPkzZOI
	if cBL40TneKajfkb5hqCAxQZyJzYiRO=='FULL_EPG' and len(ddfB6KUu1pxSTLHgG3bXNwV80mlq)>0:
		uQNUfbZx9yj0F('link',unXlPWCM9EdmRAsybwT+'[COLOR FFC89008]هذه قائمة برامج القنوات (جدول فقط)ـ[/COLOR]','',9999)
	Z5LA6UW3tNg = []
	f8dLQuoR4E3Kalqn = bMIascyFJ2x43E0C7glTB91h8qz.getInfoLabel('ListItem.Icon')
	for w3yv48p5i7rRgPk6nO9AhlzZCLc in ddfB6KUu1pxSTLHgG3bXNwV80mlq:
		ii7WOEjQFIHwgKhlDbtYdT13Anz4GC = yB3NPc2ZhbwFEi1X0dv.b64decode(w3yv48p5i7rRgPk6nO9AhlzZCLc['title'])
		if VVGRN7xiyj: ii7WOEjQFIHwgKhlDbtYdT13Anz4GC = ii7WOEjQFIHwgKhlDbtYdT13Anz4GC.decode('utf8')
		PlYOI5EdC4bGezVfNBgW = int(w3yv48p5i7rRgPk6nO9AhlzZCLc['start_timestamp'])
		Z8Z7DxtkYO = int(w3yv48p5i7rRgPk6nO9AhlzZCLc['stop_timestamp'])
		VeBHFw0QzSTPgrRI62YX4WMhxNv5c = str(int((Z8Z7DxtkYO-PlYOI5EdC4bGezVfNBgW+59)/60))
		b2bJ9YHhZEwMm3UKSWDtxaoA = w3yv48p5i7rRgPk6nO9AhlzZCLc['start'].replace(' ',':')
		con6vrO4DRYp5AVzIBsNeW72FM8qZP = YVJPFvuI2CS5KObiZt.localtime(PlYOI5EdC4bGezVfNBgW-PPC3GlfZAh68)
		tgEU3RzcI4YWZC0wMB = YVJPFvuI2CS5KObiZt.strftime('%H:%M',con6vrO4DRYp5AVzIBsNeW72FM8qZP)
		ytWoLdlnwMv9Chus62Gm4azTN85 = YVJPFvuI2CS5KObiZt.strftime('%a',con6vrO4DRYp5AVzIBsNeW72FM8qZP)
		if cBL40TneKajfkb5hqCAxQZyJzYiRO=='SHORT_EPG': ii7WOEjQFIHwgKhlDbtYdT13Anz4GC = '[COLOR FFFFFF00]'+tgEU3RzcI4YWZC0wMB+' ـ '+ii7WOEjQFIHwgKhlDbtYdT13Anz4GC+'[/COLOR]'
		elif cBL40TneKajfkb5hqCAxQZyJzYiRO=='TIMESHIFT': ii7WOEjQFIHwgKhlDbtYdT13Anz4GC = ytWoLdlnwMv9Chus62Gm4azTN85+' '+tgEU3RzcI4YWZC0wMB+' ('+VeBHFw0QzSTPgrRI62YX4WMhxNv5c+'min)'
		else: ii7WOEjQFIHwgKhlDbtYdT13Anz4GC = ytWoLdlnwMv9Chus62Gm4azTN85+' '+tgEU3RzcI4YWZC0wMB+' ('+VeBHFw0QzSTPgrRI62YX4WMhxNv5c+'min)   '+ii7WOEjQFIHwgKhlDbtYdT13Anz4GC+' ـ'
		if cBL40TneKajfkb5hqCAxQZyJzYiRO in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			HBcs5KPgNU6bQryLoAeVa7xM0 = Q6lqZnWMrDsj+'/timeshift/'+Fm20Po1nGKWHQNrZAOgER57dJjp+'/'+lEDfqRNOxhUJBt3MGkK06o+'/'+VeBHFw0QzSTPgrRI62YX4WMhxNv5c+'/'+b2bJ9YHhZEwMm3UKSWDtxaoA+'/'+v8FtmIMa9QGw7bXOUr5jC+'.m3u8'
			if cBL40TneKajfkb5hqCAxQZyJzYiRO=='FULL_EPG': uQNUfbZx9yj0F('link',unXlPWCM9EdmRAsybwT+ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,HBcs5KPgNU6bQryLoAeVa7xM0,9999,f8dLQuoR4E3Kalqn,'','','',{'folder':nCSJkub4hZM3dH1KpRIUr8a7tBNevE})
			else: uQNUfbZx9yj0F('video',unXlPWCM9EdmRAsybwT+ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,HBcs5KPgNU6bQryLoAeVa7xM0,715,f8dLQuoR4E3Kalqn,'','','',{'folder':nCSJkub4hZM3dH1KpRIUr8a7tBNevE})
		Z5LA6UW3tNg.append(ii7WOEjQFIHwgKhlDbtYdT13Anz4GC)
	if cBL40TneKajfkb5hqCAxQZyJzYiRO=='SHORT_EPG' and Z5LA6UW3tNg: D46jL1SJ7tnBW5hoFNCVqOeHfpzb = oSmbjV25zMhflkrs8W9K(Z5LA6UW3tNg)
	return Z5LA6UW3tNg
def J526vqC8ctbVSOQfeiZa93(nCSJkub4hZM3dH1KpRIUr8a7tBNevE):
	if not OSDp6mYAsavhl0boq(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,True): return
	Q6lqZnWMrDsj,c1tbGhVvT86oOqArgMEwIni4aRLU,ppM3AsuFPHnOet = '',0,0
	JJG0EdY1NQXfSRwm,jvQ4NfxUODpMY1Z5P,SSkBVzmeFbafMLotrGN7JwY = Vdz0k1iSNQG9ReHhKUt(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,False)
	if JJG0EdY1NQXfSRwm:
		ggaJM2ivW0zXLBbw8KflqjVDF9UEA = d346GzJPjvka9xSbMADlnsQgu52L(jvQ4NfxUODpMY1Z5P)
		c1tbGhVvT86oOqArgMEwIni4aRLU = mVBR2YlHrT(ggaJM2ivW0zXLBbw8KflqjVDF9UEA[0],int(SSkBVzmeFbafMLotrGN7JwY))
		Hj0zNOTDePKkIviZqFm2oQrVwp4hC3 = keRHziQrENXZW07oBwTm(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,'LIVE_GROUPED')
		LakNgBAzD4R7CV3tFdfne = AsTbx64cCEi1(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,'list','LIVE_GROUPED')
		GHZEu6VbXDjk5sCmohY4M2c1p = AsTbx64cCEi1(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,'list','LIVE_GROUPED',LakNgBAzD4R7CV3tFdfne[1])
		GZdtFyDU0caf89r = GHZEu6VbXDjk5sCmohY4M2c1p[0][2]
		StMUR98vPYidWQ70HozDB4qIxa2k5T = u5h2Rckvw1E.findall('://(.*?)/',GZdtFyDU0caf89r,u5h2Rckvw1E.DOTALL)
		StMUR98vPYidWQ70HozDB4qIxa2k5T = StMUR98vPYidWQ70HozDB4qIxa2k5T[0]
		if ':' in StMUR98vPYidWQ70HozDB4qIxa2k5T: gZ9vTS6smNOzGu4,HNC8khRwpJGSyD = StMUR98vPYidWQ70HozDB4qIxa2k5T.split(':')
		else: gZ9vTS6smNOzGu4,HNC8khRwpJGSyD = StMUR98vPYidWQ70HozDB4qIxa2k5T,'80'
		sukwFCQoz0PZt = d346GzJPjvka9xSbMADlnsQgu52L(gZ9vTS6smNOzGu4)
		ppM3AsuFPHnOet = mVBR2YlHrT(sukwFCQoz0PZt[0],int(HNC8khRwpJGSyD))
	if c1tbGhVvT86oOqArgMEwIni4aRLU and ppM3AsuFPHnOet:
		MLPwxur5kaYlBtqcn = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		MLPwxur5kaYlBtqcn += '\n\n'+'وقت ضائع في السيرفر الأصلي'+'\n'+str(int(ppM3AsuFPHnOet*1000))+' ملي ثانية'
		MLPwxur5kaYlBtqcn += '\n\n'+'وقت ضائع في السيرفر البديل'+'\n'+str(int(c1tbGhVvT86oOqArgMEwIni4aRLU*1000))+' ملي ثانية'
		TTGDytYoQjb9OlFRzK1Ln = lLPSDywfu4axrUhvX9RQEpGtso6H0('center','السيرفر الأصلي','السيرفر الأسرع','رسالة من المبرمج',MLPwxur5kaYlBtqcn)
		if TTGDytYoQjb9OlFRzK1Ln==1 and c1tbGhVvT86oOqArgMEwIni4aRLU<ppM3AsuFPHnOet: Q6lqZnWMrDsj = jvQ4NfxUODpMY1Z5P+':'+SSkBVzmeFbafMLotrGN7JwY
	else: xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','البرنامج لم يجد السيرفر البديل')
	LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting('av.m3u.server_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE,Q6lqZnWMrDsj)
	return
def N5AOlmb8u1y4FHxvJXU(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,GZdtFyDU0caf89r,f0QP7qXsU4L9xtB):
	iIOfXrKxkzhYd = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.m3u.useragent_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	e3KLTRzOsrqaCju17lnG5BNJkv = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.m3u.referer_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	if iIOfXrKxkzhYd or e3KLTRzOsrqaCju17lnG5BNJkv:
		GZdtFyDU0caf89r += '|'
		if iIOfXrKxkzhYd: GZdtFyDU0caf89r += '&User-Agent='+iIOfXrKxkzhYd
		if e3KLTRzOsrqaCju17lnG5BNJkv: GZdtFyDU0caf89r += '&Referer='+e3KLTRzOsrqaCju17lnG5BNJkv
		GZdtFyDU0caf89r = GZdtFyDU0caf89r.replace('|&','|')
	om1iZDWnrhGa2SLB9O4kfxYbqU(GZdtFyDU0caf89r,ERLBl7fGCXQYchpgj6d,f0QP7qXsU4L9xtB)
	return
def StWAhN0O3Vxw9lajrzfkpyRTeH8L(nCSJkub4hZM3dH1KpRIUr8a7tBNevE):
	xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـUser-Agent خاص')
	iIOfXrKxkzhYd = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.m3u.useragent_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	RpwKUtaOC1uVxNZePbIS2LXhloTYBm = lLPSDywfu4axrUhvX9RQEpGtso6H0('center','استخدام الأصلي','تعديل القديم',iIOfXrKxkzhYd,'هذا هو ـUser-Agent المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if RpwKUtaOC1uVxNZePbIS2LXhloTYBm==1: iIOfXrKxkzhYd = FBrXsYeCEp3('أكتب ـM3U User-Agent جديد',iIOfXrKxkzhYd,True)
	else: iIOfXrKxkzhYd = 'Unknown'
	if iIOfXrKxkzhYd==' ':
		xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	RpwKUtaOC1uVxNZePbIS2LXhloTYBm = lLPSDywfu4axrUhvX9RQEpGtso6H0('center','','',iIOfXrKxkzhYd,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if RpwKUtaOC1uVxNZePbIS2LXhloTYBm!=1:
		xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','تم الإلغاء')
		return
	LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting('av.m3u.useragent_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE,iIOfXrKxkzhYd)
	Q6PTy5fRhWxcn(nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	return
def urlx3BIvK7di8PtOqhH(nCSJkub4hZM3dH1KpRIUr8a7tBNevE):
	xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـReferer خاص')
	e3KLTRzOsrqaCju17lnG5BNJkv = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.m3u.referer_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	RpwKUtaOC1uVxNZePbIS2LXhloTYBm = lLPSDywfu4axrUhvX9RQEpGtso6H0('center','استخدام الأصلي','تعديل القديم',e3KLTRzOsrqaCju17lnG5BNJkv,'هذا هو ـReferer المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if RpwKUtaOC1uVxNZePbIS2LXhloTYBm==1: e3KLTRzOsrqaCju17lnG5BNJkv = FBrXsYeCEp3('أكتب ـM3U Referer جديد',e3KLTRzOsrqaCju17lnG5BNJkv,True)
	else: e3KLTRzOsrqaCju17lnG5BNJkv = ''
	if e3KLTRzOsrqaCju17lnG5BNJkv==' ':
		xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	RpwKUtaOC1uVxNZePbIS2LXhloTYBm = lLPSDywfu4axrUhvX9RQEpGtso6H0('center','','',e3KLTRzOsrqaCju17lnG5BNJkv,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if RpwKUtaOC1uVxNZePbIS2LXhloTYBm!=1:
		xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','تم الإلغاء')
		return
	LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting('av.m3u.referer_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE,e3KLTRzOsrqaCju17lnG5BNJkv)
	Q6PTy5fRhWxcn(nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	return
def G16y4pxhBjuKDrbw5FvNz(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,ci2kb3zDSaGlFC1INnj4KdmQv=''):
	if not vdx2wmSZYg9LPOnEX: vdx2wmSZYg9LPOnEX = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.m3u.url_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	Q6lqZnWMrDsj = hmcFWJUgiAuGk(vdx2wmSZYg9LPOnEX,'url')
	Fm20Po1nGKWHQNrZAOgER57dJjp = u5h2Rckvw1E.findall('username=(.*?)&',vdx2wmSZYg9LPOnEX+'&',u5h2Rckvw1E.DOTALL)
	lEDfqRNOxhUJBt3MGkK06o = u5h2Rckvw1E.findall('password=(.*?)&',vdx2wmSZYg9LPOnEX+'&',u5h2Rckvw1E.DOTALL)
	if not Fm20Po1nGKWHQNrZAOgER57dJjp or not lEDfqRNOxhUJBt3MGkK06o:
		xl9MFt1AmY0GrkENug8n('','','فحص اشتراك M3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		return '','','','',''
	Fm20Po1nGKWHQNrZAOgER57dJjp = Fm20Po1nGKWHQNrZAOgER57dJjp[0]
	lEDfqRNOxhUJBt3MGkK06o = lEDfqRNOxhUJBt3MGkK06o[0]
	uuiBFDtpqZyOAcaTEobsz4Khje = Q6lqZnWMrDsj+'/player_api.php?username='+Fm20Po1nGKWHQNrZAOgER57dJjp+'&password='+lEDfqRNOxhUJBt3MGkK06o
	S0EXKGMckjfszwYLH69qtP8 = Q6lqZnWMrDsj+'/get.php?username='+Fm20Po1nGKWHQNrZAOgER57dJjp+'&password='+lEDfqRNOxhUJBt3MGkK06o+'&type=m3u_plus'
	return uuiBFDtpqZyOAcaTEobsz4Khje,S0EXKGMckjfszwYLH69qtP8,Q6lqZnWMrDsj,Fm20Po1nGKWHQNrZAOgER57dJjp,lEDfqRNOxhUJBt3MGkK06o
def MMpd3TKwR6LGxH(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,uCWYdR5IwT01V7ac3KPpoG=''):
	QQtKsFu2cdnf = uCWYdR5IwT01V7ac3KPpoG.replace('/','_').replace(':','_').replace('.','_')
	QQtKsFu2cdnf = QQtKsFu2cdnf.replace('?','_').replace('=','_').replace('&','_')
	QQtKsFu2cdnf = k1t0JLRsCQ.path.join(OxWkR7Eu9Pm3IAvTp0q,QQtKsFu2cdnf).strip('.m3u')+'.m3u'
	return QQtKsFu2cdnf
def ueMYIa0pJrsKtw(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,IKBpN0ZXVri):
	ox074IWHTYUaMLlDG5O8pQvdVshB = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.m3u.url_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE+'_'+IKBpN0ZXVri)
	CCmj0e8tDOZH = True
	if ox074IWHTYUaMLlDG5O8pQvdVshB:
		RpwKUtaOC1uVxNZePbIS2LXhloTYBm = lRwnVNxCZXGgkqd390('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:','[COLOR FFC89008]'+ox074IWHTYUaMLlDG5O8pQvdVshB+'[/COLOR]'+'\n\n هذا هو رابط M3U المسجل في البرنامج .. هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if RpwKUtaOC1uVxNZePbIS2LXhloTYBm==-1: return
		elif RpwKUtaOC1uVxNZePbIS2LXhloTYBm==0: ox074IWHTYUaMLlDG5O8pQvdVshB = ''
		elif RpwKUtaOC1uVxNZePbIS2LXhloTYBm==2:
			RpwKUtaOC1uVxNZePbIS2LXhloTYBm = lLPSDywfu4axrUhvX9RQEpGtso6H0('center','','','رسالة من المبرمج','هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if RpwKUtaOC1uVxNZePbIS2LXhloTYBm in [-1,0]: return
			xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','تم مسح الرابط')
			CCmj0e8tDOZH = False
			uZKsdYw4JqkH = ''
	if CCmj0e8tDOZH:
		uZKsdYw4JqkH = FBrXsYeCEp3('اكتب رابط M3U كاملا',ox074IWHTYUaMLlDG5O8pQvdVshB)
		uZKsdYw4JqkH = uZKsdYw4JqkH.strip(' ')
		if not uZKsdYw4JqkH:
			RpwKUtaOC1uVxNZePbIS2LXhloTYBm = lLPSDywfu4axrUhvX9RQEpGtso6H0('center','','','رسالة من المبرمج','لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if RpwKUtaOC1uVxNZePbIS2LXhloTYBm in [-1,0]: return
			xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','تم مسح الرابط')
		else:
			MLPwxur5kaYlBtqcn = 'هذه المعلومات تم أخذها من رابط ـM3U الذي انت كتبته . هل تريد استخدامها ؟!\n'
			RpwKUtaOC1uVxNZePbIS2LXhloTYBm = lLPSDywfu4axrUhvX9RQEpGtso6H0('','','','الرابط الجديد هو:','[COLOR FFC89008]'+uZKsdYw4JqkH+'[/COLOR]'+'\n\n'+MLPwxur5kaYlBtqcn)
			if RpwKUtaOC1uVxNZePbIS2LXhloTYBm!=1:
				xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','تم الإلغاء')
				return
	LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting('av.m3u.url_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE+'_'+IKBpN0ZXVri,uZKsdYw4JqkH)
	iIOfXrKxkzhYd = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.m3u.useragent_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	if not iIOfXrKxkzhYd: LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting('av.m3u.useragent_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE,'Unknown')
	Q6PTy5fRhWxcn(nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	return
def tcFhYb3wQGmJRkvzfPon6DsujM1W(Dxe4mO65obSHMKrlWsjwvX,ggGaEKquH6DV0WIAChXv4y5J,b1k64DBqh9,zRuPtc6Sb2pidExYJwQGLqsMvU7o,kZNrfX1yVc3n0jl8wOEx7,z5GRTewnrMpxQLjKoE,S0EXKGMckjfszwYLH69qtP8):
	GHZEu6VbXDjk5sCmohY4M2c1p,FbsrBETNDKSn5lPk1 = [],[]
	QqgyNe17WbZjLipdGHnP4Jt6zF08B = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for Bx1JlohpcEg in Dxe4mO65obSHMKrlWsjwvX:
		if z5GRTewnrMpxQLjKoE%473==0:
			hyCqU2Ns4B1J3EH7fQVe6DXtzgFuI(zRuPtc6Sb2pidExYJwQGLqsMvU7o,40+int(10*z5GRTewnrMpxQLjKoE/kZNrfX1yVc3n0jl8wOEx7),'قراءة الفيديوهات','الفيديو رقم:-',str(z5GRTewnrMpxQLjKoE)+' / '+str(kZNrfX1yVc3n0jl8wOEx7))
			if zRuPtc6Sb2pidExYJwQGLqsMvU7o.iscanceled():
				zRuPtc6Sb2pidExYJwQGLqsMvU7o.close()
				return None,None,None
		GZdtFyDU0caf89r = u5h2Rckvw1E.findall('^(.*?)\n+((http|https|rtmp).*?)$',Bx1JlohpcEg,u5h2Rckvw1E.DOTALL)
		if GZdtFyDU0caf89r:
			Bx1JlohpcEg,GZdtFyDU0caf89r,ir74YTmhPq = GZdtFyDU0caf89r[0]
			GZdtFyDU0caf89r = GZdtFyDU0caf89r.replace('\n','')
			Bx1JlohpcEg = Bx1JlohpcEg.replace('\n','')
		else:
			FbsrBETNDKSn5lPk1.append({'line':Bx1JlohpcEg})
			continue
		mmxS2HR1voGjeUM5XCgqsTtNFDa9r,wWXVYjrFaCg9zpboThAMQBU8iHJc,HwuFsvM9jV8yY,ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,f0QP7qXsU4L9xtB,JpCyXRBdisKYgLzqk5wUmvb2jAV = {},'','','','',False
		try:
			Bx1JlohpcEg,ii7WOEjQFIHwgKhlDbtYdT13Anz4GC = Bx1JlohpcEg.rsplit('",',1)
			Bx1JlohpcEg = Bx1JlohpcEg+'"'
		except:
			try: Bx1JlohpcEg,ii7WOEjQFIHwgKhlDbtYdT13Anz4GC = Bx1JlohpcEg.rsplit('1,',1)
			except: ii7WOEjQFIHwgKhlDbtYdT13Anz4GC = ''
		mmxS2HR1voGjeUM5XCgqsTtNFDa9r['url'] = GZdtFyDU0caf89r
		LkNinVfYFyQ7j9SAcUO5egv34 = u5h2Rckvw1E.findall(' (.*?)="(.*?)"',Bx1JlohpcEg,u5h2Rckvw1E.DOTALL)
		for bbqxQZ2thM0,yypNIclXCGvB7WHsuYk409 in LkNinVfYFyQ7j9SAcUO5egv34:
			bbqxQZ2thM0 = bbqxQZ2thM0.replace('"','').strip(' ')
			mmxS2HR1voGjeUM5XCgqsTtNFDa9r[bbqxQZ2thM0] = yypNIclXCGvB7WHsuYk409.strip(' ')
		mKAZQ26TyxiLnpDEl = list(mmxS2HR1voGjeUM5XCgqsTtNFDa9r.keys())
		if not ii7WOEjQFIHwgKhlDbtYdT13Anz4GC:
			if 'name' in mKAZQ26TyxiLnpDEl and mmxS2HR1voGjeUM5XCgqsTtNFDa9r['name']: ii7WOEjQFIHwgKhlDbtYdT13Anz4GC = mmxS2HR1voGjeUM5XCgqsTtNFDa9r['name']
		mmxS2HR1voGjeUM5XCgqsTtNFDa9r['title'] = ii7WOEjQFIHwgKhlDbtYdT13Anz4GC.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'logo' in mKAZQ26TyxiLnpDEl:
			mmxS2HR1voGjeUM5XCgqsTtNFDa9r['img'] = mmxS2HR1voGjeUM5XCgqsTtNFDa9r['logo']
			del mmxS2HR1voGjeUM5XCgqsTtNFDa9r['logo']
		else: mmxS2HR1voGjeUM5XCgqsTtNFDa9r['img'] = ''
		if 'group' in mKAZQ26TyxiLnpDEl and mmxS2HR1voGjeUM5XCgqsTtNFDa9r['group']: HwuFsvM9jV8yY = mmxS2HR1voGjeUM5XCgqsTtNFDa9r['group']
		if any(c2eEflztvIX in GZdtFyDU0caf89r.lower() for c2eEflztvIX in QqgyNe17WbZjLipdGHnP4Jt6zF08B):
			JpCyXRBdisKYgLzqk5wUmvb2jAV = True if 'm3u' not in GZdtFyDU0caf89r else False
		if JpCyXRBdisKYgLzqk5wUmvb2jAV or '__SERIES__' in HwuFsvM9jV8yY or '__MOVIES__' in HwuFsvM9jV8yY:
			f0QP7qXsU4L9xtB = 'VOD'
			if '__SERIES__' in HwuFsvM9jV8yY: f0QP7qXsU4L9xtB = f0QP7qXsU4L9xtB+'_SERIES'
			elif '__MOVIES__' in HwuFsvM9jV8yY: f0QP7qXsU4L9xtB = f0QP7qXsU4L9xtB+'_MOVIES'
			else: f0QP7qXsU4L9xtB = f0QP7qXsU4L9xtB+'_UNKNOWN'
			HwuFsvM9jV8yY = HwuFsvM9jV8yY.replace('__SERIES__','').replace('__MOVIES__','')
		else:
			f0QP7qXsU4L9xtB = 'LIVE'
			if ii7WOEjQFIHwgKhlDbtYdT13Anz4GC in ggGaEKquH6DV0WIAChXv4y5J: wWXVYjrFaCg9zpboThAMQBU8iHJc = wWXVYjrFaCg9zpboThAMQBU8iHJc+'_EPG'
			if ii7WOEjQFIHwgKhlDbtYdT13Anz4GC in b1k64DBqh9: wWXVYjrFaCg9zpboThAMQBU8iHJc = wWXVYjrFaCg9zpboThAMQBU8iHJc+'_ARCHIVED'
			if not HwuFsvM9jV8yY: f0QP7qXsU4L9xtB = f0QP7qXsU4L9xtB+'_UNKNOWN'
			else: f0QP7qXsU4L9xtB = f0QP7qXsU4L9xtB+wWXVYjrFaCg9zpboThAMQBU8iHJc
		HwuFsvM9jV8yY = HwuFsvM9jV8yY.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'LIVE_UNKNOWN' in f0QP7qXsU4L9xtB: HwuFsvM9jV8yY = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in f0QP7qXsU4L9xtB: HwuFsvM9jV8yY = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in f0QP7qXsU4L9xtB:
			RRCkE7yonuVZsSewLXGBgA4fPr2cY = u5h2Rckvw1E.findall('(.*?) [Ss]\d+ +[Ee]\d+',mmxS2HR1voGjeUM5XCgqsTtNFDa9r['title'],u5h2Rckvw1E.DOTALL)
			if RRCkE7yonuVZsSewLXGBgA4fPr2cY: RRCkE7yonuVZsSewLXGBgA4fPr2cY = RRCkE7yonuVZsSewLXGBgA4fPr2cY[0]
			else: RRCkE7yonuVZsSewLXGBgA4fPr2cY = '!!__UNKNOWN_SERIES__!!'
			HwuFsvM9jV8yY = HwuFsvM9jV8yY+'__SERIES__'+RRCkE7yonuVZsSewLXGBgA4fPr2cY
		if 'id' in mKAZQ26TyxiLnpDEl: del mmxS2HR1voGjeUM5XCgqsTtNFDa9r['id']
		if 'ID' in mKAZQ26TyxiLnpDEl: del mmxS2HR1voGjeUM5XCgqsTtNFDa9r['ID']
		if 'name' in mKAZQ26TyxiLnpDEl: del mmxS2HR1voGjeUM5XCgqsTtNFDa9r['name']
		ii7WOEjQFIHwgKhlDbtYdT13Anz4GC = mmxS2HR1voGjeUM5XCgqsTtNFDa9r['title']
		ii7WOEjQFIHwgKhlDbtYdT13Anz4GC = ffbxegm1XPSqIwp8i(ii7WOEjQFIHwgKhlDbtYdT13Anz4GC)
		ii7WOEjQFIHwgKhlDbtYdT13Anz4GC = hhJT4DWRxjV2uFgL7yO1lkCImGSiPX(ii7WOEjQFIHwgKhlDbtYdT13Anz4GC)
		HavZWxPw5sAEejXfkrJz7GqC3yS,HwuFsvM9jV8yY = MnkGc1OzQ8lj(HwuFsvM9jV8yY)
		Th9Ioupv0X,ii7WOEjQFIHwgKhlDbtYdT13Anz4GC = MnkGc1OzQ8lj(ii7WOEjQFIHwgKhlDbtYdT13Anz4GC)
		mmxS2HR1voGjeUM5XCgqsTtNFDa9r['type'] = f0QP7qXsU4L9xtB
		mmxS2HR1voGjeUM5XCgqsTtNFDa9r['context'] = wWXVYjrFaCg9zpboThAMQBU8iHJc
		mmxS2HR1voGjeUM5XCgqsTtNFDa9r['group'] = HwuFsvM9jV8yY.upper()
		mmxS2HR1voGjeUM5XCgqsTtNFDa9r['title'] = ii7WOEjQFIHwgKhlDbtYdT13Anz4GC.upper()
		mmxS2HR1voGjeUM5XCgqsTtNFDa9r['country'] = Th9Ioupv0X.upper()
		mmxS2HR1voGjeUM5XCgqsTtNFDa9r['language'] = HavZWxPw5sAEejXfkrJz7GqC3yS.upper()
		GHZEu6VbXDjk5sCmohY4M2c1p.append(mmxS2HR1voGjeUM5XCgqsTtNFDa9r)
		z5GRTewnrMpxQLjKoE += 1
	return GHZEu6VbXDjk5sCmohY4M2c1p,z5GRTewnrMpxQLjKoE,FbsrBETNDKSn5lPk1
def hhJT4DWRxjV2uFgL7yO1lkCImGSiPX(ii7WOEjQFIHwgKhlDbtYdT13Anz4GC):
	ii7WOEjQFIHwgKhlDbtYdT13Anz4GC = ii7WOEjQFIHwgKhlDbtYdT13Anz4GC.replace('  ',' ').replace('  ',' ').replace('  ',' ')
	ii7WOEjQFIHwgKhlDbtYdT13Anz4GC = ii7WOEjQFIHwgKhlDbtYdT13Anz4GC.replace('||','|').replace('___',':').replace('--','-')
	ii7WOEjQFIHwgKhlDbtYdT13Anz4GC = ii7WOEjQFIHwgKhlDbtYdT13Anz4GC.replace('[[','[').replace(']]',']')
	ii7WOEjQFIHwgKhlDbtYdT13Anz4GC = ii7WOEjQFIHwgKhlDbtYdT13Anz4GC.replace('((','(').replace('))',')')
	ii7WOEjQFIHwgKhlDbtYdT13Anz4GC = ii7WOEjQFIHwgKhlDbtYdT13Anz4GC.replace('<<','<').replace('>>','>')
	ii7WOEjQFIHwgKhlDbtYdT13Anz4GC = ii7WOEjQFIHwgKhlDbtYdT13Anz4GC.strip(' ')
	return ii7WOEjQFIHwgKhlDbtYdT13Anz4GC
def uvtfGJLPsI6K3Wkg8l(iiqb3WMPNKmpctEI,zRuPtc6Sb2pidExYJwQGLqsMvU7o,IKBpN0ZXVri):
	logFO0JZhCEBYts9yQHW = {}
	for LYXj68I03A2y in aEcb9iDHs8ySolrwe1UYNt035: logFO0JZhCEBYts9yQHW[LYXj68I03A2y+'_'+IKBpN0ZXVri] = []
	kZNrfX1yVc3n0jl8wOEx7 = len(iiqb3WMPNKmpctEI)
	KB72pFM3lIrajwdJtemTL8iPsv = str(kZNrfX1yVc3n0jl8wOEx7)
	z5GRTewnrMpxQLjKoE = 0
	FbsrBETNDKSn5lPk1 = []
	for mmxS2HR1voGjeUM5XCgqsTtNFDa9r in iiqb3WMPNKmpctEI:
		if z5GRTewnrMpxQLjKoE%873==0:
			hyCqU2Ns4B1J3EH7fQVe6DXtzgFuI(zRuPtc6Sb2pidExYJwQGLqsMvU7o,50+int(5*z5GRTewnrMpxQLjKoE/kZNrfX1yVc3n0jl8wOEx7),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(z5GRTewnrMpxQLjKoE)+' / '+KB72pFM3lIrajwdJtemTL8iPsv)
			if zRuPtc6Sb2pidExYJwQGLqsMvU7o.iscanceled():
				zRuPtc6Sb2pidExYJwQGLqsMvU7o.close()
				return None,None
		HwuFsvM9jV8yY,wWXVYjrFaCg9zpboThAMQBU8iHJc,ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,GZdtFyDU0caf89r,f8dLQuoR4E3Kalqn = mmxS2HR1voGjeUM5XCgqsTtNFDa9r['group'],mmxS2HR1voGjeUM5XCgqsTtNFDa9r['context'],mmxS2HR1voGjeUM5XCgqsTtNFDa9r['title'],mmxS2HR1voGjeUM5XCgqsTtNFDa9r['url'],mmxS2HR1voGjeUM5XCgqsTtNFDa9r['img']
		Th9Ioupv0X,HavZWxPw5sAEejXfkrJz7GqC3yS,LYXj68I03A2y = mmxS2HR1voGjeUM5XCgqsTtNFDa9r['country'],mmxS2HR1voGjeUM5XCgqsTtNFDa9r['language'],mmxS2HR1voGjeUM5XCgqsTtNFDa9r['type']
		pEv8QjVwztLTYNuKdoBa = (HwuFsvM9jV8yY,wWXVYjrFaCg9zpboThAMQBU8iHJc,ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,GZdtFyDU0caf89r,f8dLQuoR4E3Kalqn)
		EIzS3pbNsFRKxndyk8XrZl2 = False
		if 'LIVE' in LYXj68I03A2y:
			if 'UNKNOWN' in LYXj68I03A2y: logFO0JZhCEBYts9yQHW['LIVE_UNKNOWN_GROUPED_'+IKBpN0ZXVri].append(pEv8QjVwztLTYNuKdoBa)
			elif 'LIVE' in LYXj68I03A2y: logFO0JZhCEBYts9yQHW['LIVE_GROUPED_'+IKBpN0ZXVri].append(pEv8QjVwztLTYNuKdoBa)
			else: EIzS3pbNsFRKxndyk8XrZl2 = True
			logFO0JZhCEBYts9yQHW['LIVE_ORIGINAL_GROUPED_'+IKBpN0ZXVri].append(pEv8QjVwztLTYNuKdoBa)
		elif 'VOD' in LYXj68I03A2y:
			if 'UNKNOWN' in LYXj68I03A2y: logFO0JZhCEBYts9yQHW['VOD_UNKNOWN_GROUPED_'+IKBpN0ZXVri].append(pEv8QjVwztLTYNuKdoBa)
			elif 'MOVIES' in LYXj68I03A2y: logFO0JZhCEBYts9yQHW['VOD_MOVIES_GROUPED_'+IKBpN0ZXVri].append(pEv8QjVwztLTYNuKdoBa)
			elif 'SERIES' in LYXj68I03A2y: logFO0JZhCEBYts9yQHW['VOD_SERIES_GROUPED_'+IKBpN0ZXVri].append(pEv8QjVwztLTYNuKdoBa)
			else: EIzS3pbNsFRKxndyk8XrZl2 = True
			logFO0JZhCEBYts9yQHW['VOD_ORIGINAL_GROUPED_'+IKBpN0ZXVri].append(pEv8QjVwztLTYNuKdoBa)
		else: EIzS3pbNsFRKxndyk8XrZl2 = True
		if EIzS3pbNsFRKxndyk8XrZl2: FbsrBETNDKSn5lPk1.append(mmxS2HR1voGjeUM5XCgqsTtNFDa9r)
		z5GRTewnrMpxQLjKoE += 1
	CSHkRKzPLnGVTyrq8o4vMu2 = sorted(iiqb3WMPNKmpctEI,reverse=False,key=lambda bbqxQZ2thM0: bbqxQZ2thM0['title'].lower())
	del iiqb3WMPNKmpctEI
	KB72pFM3lIrajwdJtemTL8iPsv = str(kZNrfX1yVc3n0jl8wOEx7)
	z5GRTewnrMpxQLjKoE = 0
	for mmxS2HR1voGjeUM5XCgqsTtNFDa9r in CSHkRKzPLnGVTyrq8o4vMu2:
		z5GRTewnrMpxQLjKoE += 1
		if z5GRTewnrMpxQLjKoE%873==0:
			hyCqU2Ns4B1J3EH7fQVe6DXtzgFuI(zRuPtc6Sb2pidExYJwQGLqsMvU7o,55+int(5*z5GRTewnrMpxQLjKoE/kZNrfX1yVc3n0jl8wOEx7),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(z5GRTewnrMpxQLjKoE)+' / '+KB72pFM3lIrajwdJtemTL8iPsv)
			if zRuPtc6Sb2pidExYJwQGLqsMvU7o.iscanceled():
				zRuPtc6Sb2pidExYJwQGLqsMvU7o.close()
				return None,None
		LYXj68I03A2y = mmxS2HR1voGjeUM5XCgqsTtNFDa9r['type']
		HwuFsvM9jV8yY,wWXVYjrFaCg9zpboThAMQBU8iHJc,ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,GZdtFyDU0caf89r,f8dLQuoR4E3Kalqn = mmxS2HR1voGjeUM5XCgqsTtNFDa9r['group'],mmxS2HR1voGjeUM5XCgqsTtNFDa9r['context'],mmxS2HR1voGjeUM5XCgqsTtNFDa9r['title'],mmxS2HR1voGjeUM5XCgqsTtNFDa9r['url'],mmxS2HR1voGjeUM5XCgqsTtNFDa9r['img']
		Th9Ioupv0X,HavZWxPw5sAEejXfkrJz7GqC3yS = mmxS2HR1voGjeUM5XCgqsTtNFDa9r['country'],mmxS2HR1voGjeUM5XCgqsTtNFDa9r['language']
		fT5VplnUNegs809mk34LcRHy1odGhx = (HwuFsvM9jV8yY,wWXVYjrFaCg9zpboThAMQBU8iHJc+'_TIMESHIFT',ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,GZdtFyDU0caf89r,f8dLQuoR4E3Kalqn)
		pEv8QjVwztLTYNuKdoBa = (HwuFsvM9jV8yY,wWXVYjrFaCg9zpboThAMQBU8iHJc,ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,GZdtFyDU0caf89r,f8dLQuoR4E3Kalqn)
		UFZ4oyaY6ILT0hEJbOP8DGmj = (Th9Ioupv0X,wWXVYjrFaCg9zpboThAMQBU8iHJc,ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,GZdtFyDU0caf89r,f8dLQuoR4E3Kalqn)
		vd1jROq9iz6IlYnPU3mtEhap = (HavZWxPw5sAEejXfkrJz7GqC3yS,wWXVYjrFaCg9zpboThAMQBU8iHJc,ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,GZdtFyDU0caf89r,f8dLQuoR4E3Kalqn)
		if 'LIVE' in LYXj68I03A2y:
			if 'UNKNOWN' in LYXj68I03A2y: logFO0JZhCEBYts9yQHW['LIVE_UNKNOWN_GROUPED_SORTED_'+IKBpN0ZXVri].append(pEv8QjVwztLTYNuKdoBa)
			else: logFO0JZhCEBYts9yQHW['LIVE_GROUPED_SORTED_'+IKBpN0ZXVri].append(pEv8QjVwztLTYNuKdoBa)
			if 'EPG'		in LYXj68I03A2y: logFO0JZhCEBYts9yQHW['LIVE_EPG_GROUPED_SORTED_'+IKBpN0ZXVri].append(pEv8QjVwztLTYNuKdoBa)
			if 'ARCHIVED'	in LYXj68I03A2y: logFO0JZhCEBYts9yQHW['LIVE_ARCHIVED_GROUPED_SORTED_'+IKBpN0ZXVri].append(pEv8QjVwztLTYNuKdoBa)
			if 'ARCHIVED'	in LYXj68I03A2y: logFO0JZhCEBYts9yQHW['LIVE_TIMESHIFT_GROUPED_SORTED_'+IKBpN0ZXVri].append(fT5VplnUNegs809mk34LcRHy1odGhx)
			logFO0JZhCEBYts9yQHW['LIVE_FROM_NAME_SORTED_'+IKBpN0ZXVri].append(UFZ4oyaY6ILT0hEJbOP8DGmj)
			logFO0JZhCEBYts9yQHW['LIVE_FROM_GROUP_SORTED_'+IKBpN0ZXVri].append(vd1jROq9iz6IlYnPU3mtEhap)
		elif 'VOD' in LYXj68I03A2y:
			if   'UNKNOWN'	in LYXj68I03A2y: logFO0JZhCEBYts9yQHW['VOD_UNKNOWN_GROUPED_SORTED_'+IKBpN0ZXVri].append(pEv8QjVwztLTYNuKdoBa)
			elif 'MOVIES'	in LYXj68I03A2y: logFO0JZhCEBYts9yQHW['VOD_MOVIES_GROUPED_SORTED_'+IKBpN0ZXVri].append(pEv8QjVwztLTYNuKdoBa)
			elif 'SERIES'	in LYXj68I03A2y: logFO0JZhCEBYts9yQHW['VOD_SERIES_GROUPED_SORTED_'+IKBpN0ZXVri].append(pEv8QjVwztLTYNuKdoBa)
			logFO0JZhCEBYts9yQHW['VOD_FROM_NAME_SORTED_'+IKBpN0ZXVri].append(UFZ4oyaY6ILT0hEJbOP8DGmj)
			logFO0JZhCEBYts9yQHW['VOD_FROM_GROUP_SORTED_'+IKBpN0ZXVri].append(vd1jROq9iz6IlYnPU3mtEhap)
	return logFO0JZhCEBYts9yQHW,FbsrBETNDKSn5lPk1
def MnkGc1OzQ8lj(ii7WOEjQFIHwgKhlDbtYdT13Anz4GC):
	if len(ii7WOEjQFIHwgKhlDbtYdT13Anz4GC)<3: return ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,ii7WOEjQFIHwgKhlDbtYdT13Anz4GC
	OOiy8zcVsBAY,rq1wz4GK7xZFUe8bjMu0WtOC = '',''
	eeVHAO09a2jT3y8o5XMGJBmUzIElgk = ii7WOEjQFIHwgKhlDbtYdT13Anz4GC
	IYh82kKwaomBtVlOeusrNLn9GvyQ0R = ii7WOEjQFIHwgKhlDbtYdT13Anz4GC[:1]
	nHzGmMEX2IS8WeCbf3y7P = ii7WOEjQFIHwgKhlDbtYdT13Anz4GC[1:]
	if   IYh82kKwaomBtVlOeusrNLn9GvyQ0R=='(': rq1wz4GK7xZFUe8bjMu0WtOC = ')'
	elif IYh82kKwaomBtVlOeusrNLn9GvyQ0R=='[': rq1wz4GK7xZFUe8bjMu0WtOC = ']'
	elif IYh82kKwaomBtVlOeusrNLn9GvyQ0R=='<': rq1wz4GK7xZFUe8bjMu0WtOC = '>'
	elif IYh82kKwaomBtVlOeusrNLn9GvyQ0R=='|': rq1wz4GK7xZFUe8bjMu0WtOC = '|'
	if rq1wz4GK7xZFUe8bjMu0WtOC and (rq1wz4GK7xZFUe8bjMu0WtOC in nHzGmMEX2IS8WeCbf3y7P):
		V59q81u7WgU4ypIvnGZMDCPJkj,KrJvd61ZIyNAQ = nHzGmMEX2IS8WeCbf3y7P.split(rq1wz4GK7xZFUe8bjMu0WtOC,1)
		OOiy8zcVsBAY = V59q81u7WgU4ypIvnGZMDCPJkj
		eeVHAO09a2jT3y8o5XMGJBmUzIElgk = IYh82kKwaomBtVlOeusrNLn9GvyQ0R+V59q81u7WgU4ypIvnGZMDCPJkj+rq1wz4GK7xZFUe8bjMu0WtOC+' '+KrJvd61ZIyNAQ
	elif ii7WOEjQFIHwgKhlDbtYdT13Anz4GC.count('|')>=2:
		V59q81u7WgU4ypIvnGZMDCPJkj,KrJvd61ZIyNAQ = ii7WOEjQFIHwgKhlDbtYdT13Anz4GC.split('|',1)
		OOiy8zcVsBAY = V59q81u7WgU4ypIvnGZMDCPJkj
		eeVHAO09a2jT3y8o5XMGJBmUzIElgk = V59q81u7WgU4ypIvnGZMDCPJkj+' |'+KrJvd61ZIyNAQ
	else:
		rq1wz4GK7xZFUe8bjMu0WtOC = u5h2Rckvw1E.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,u5h2Rckvw1E.DOTALL)
		if not rq1wz4GK7xZFUe8bjMu0WtOC: rq1wz4GK7xZFUe8bjMu0WtOC = u5h2Rckvw1E.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,u5h2Rckvw1E.DOTALL)
		if not rq1wz4GK7xZFUe8bjMu0WtOC: rq1wz4GK7xZFUe8bjMu0WtOC = u5h2Rckvw1E.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,u5h2Rckvw1E.DOTALL)
		if rq1wz4GK7xZFUe8bjMu0WtOC:
			V59q81u7WgU4ypIvnGZMDCPJkj,KrJvd61ZIyNAQ = ii7WOEjQFIHwgKhlDbtYdT13Anz4GC.split(rq1wz4GK7xZFUe8bjMu0WtOC[0],1)
			OOiy8zcVsBAY = V59q81u7WgU4ypIvnGZMDCPJkj
			eeVHAO09a2jT3y8o5XMGJBmUzIElgk = V59q81u7WgU4ypIvnGZMDCPJkj+' '+rq1wz4GK7xZFUe8bjMu0WtOC[0]+' '+KrJvd61ZIyNAQ
	eeVHAO09a2jT3y8o5XMGJBmUzIElgk = eeVHAO09a2jT3y8o5XMGJBmUzIElgk.replace('   ',' ').replace('  ',' ')
	OOiy8zcVsBAY = OOiy8zcVsBAY.replace('  ',' ')
	if not OOiy8zcVsBAY: OOiy8zcVsBAY = '!!__UNKNOWN__!!'
	OOiy8zcVsBAY = OOiy8zcVsBAY.strip(' ')
	eeVHAO09a2jT3y8o5XMGJBmUzIElgk = eeVHAO09a2jT3y8o5XMGJBmUzIElgk.strip(' ')
	return OOiy8zcVsBAY,eeVHAO09a2jT3y8o5XMGJBmUzIElgk
def JkqQF1cXCRKvsgiGmeLna9tO8ydN(nCSJkub4hZM3dH1KpRIUr8a7tBNevE):
	v1vaBXhQE6tsCjV73HkrNUpgI9DZK = {}
	iIOfXrKxkzhYd = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.m3u.useragent_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	if iIOfXrKxkzhYd: v1vaBXhQE6tsCjV73HkrNUpgI9DZK['User-Agent'] = iIOfXrKxkzhYd
	e3KLTRzOsrqaCju17lnG5BNJkv = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.m3u.referer_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	if e3KLTRzOsrqaCju17lnG5BNJkv: v1vaBXhQE6tsCjV73HkrNUpgI9DZK['Referer'] = e3KLTRzOsrqaCju17lnG5BNJkv
	return v1vaBXhQE6tsCjV73HkrNUpgI9DZK
def nnDKsZWdeEAhLf(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,IKBpN0ZXVri):
	global zRuPtc6Sb2pidExYJwQGLqsMvU7o,logFO0JZhCEBYts9yQHW,N3huw4lo1bxgJDjKfzQXpL0rUaR,i6jQ5CUoRgtEvIqzJaPs,UVzHc7EDFpd5xfLhPjsZ0oG,LakNgBAzD4R7CV3tFdfne,VAlXQdbWpi7G,EtrNchixRjVB304FDSou6fzY,kTC4PIFr2vmJLqlsGQMKR31Vz
	S0EXKGMckjfszwYLH69qtP8 = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.m3u.url_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE+'_'+IKBpN0ZXVri)
	iIOfXrKxkzhYd = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.m3u.useragent_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	v1vaBXhQE6tsCjV73HkrNUpgI9DZK = {'User-Agent':iIOfXrKxkzhYd}
	QQtKsFu2cdnf = ttyjfLqbA1VJNOu.replace('___','_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE+'_'+IKBpN0ZXVri)
	if 1:
		JJG0EdY1NQXfSRwm,jvQ4NfxUODpMY1Z5P,SSkBVzmeFbafMLotrGN7JwY = True,'',''
		if not JJG0EdY1NQXfSRwm:
			xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','فشل بسحب ملفات ـM3U . أحتمال رابط ـM3U غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـM3U الموجودة بهذا البرنامج')
			if not S0EXKGMckjfszwYLH69qtP8: l0SAerv8zGH2Wa('ERROR_LINES',CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+'   No M3U URL found to download M3U files')
			else: l0SAerv8zGH2Wa('ERROR_LINES',CC7Td6HzItGeMfumSaxDEZchp(ERLBl7fGCXQYchpgj6d)+'   Failed to download M3U files')
			return
		D94gwA1Z5JrIx2BiPyHobXuhM3n = sG6DJ2IAY17EbZceRVF(S0EXKGMckjfszwYLH69qtP8,v1vaBXhQE6tsCjV73HkrNUpgI9DZK,True)
		if not D94gwA1Z5JrIx2BiPyHobXuhM3n: return
		open(QQtKsFu2cdnf,'wb').write(D94gwA1Z5JrIx2BiPyHobXuhM3n)
	else: D94gwA1Z5JrIx2BiPyHobXuhM3n = open(QQtKsFu2cdnf,'rb').read()
	if VVGRN7xiyj and D94gwA1Z5JrIx2BiPyHobXuhM3n: D94gwA1Z5JrIx2BiPyHobXuhM3n = D94gwA1Z5JrIx2BiPyHobXuhM3n.decode('utf8')
	zRuPtc6Sb2pidExYJwQGLqsMvU7o = zzLBYaEcM1jlKqX5FyONiRJ()
	zRuPtc6Sb2pidExYJwQGLqsMvU7o.create('جلب ملفات M3U جديدة','')
	hyCqU2Ns4B1J3EH7fQVe6DXtzgFuI(zRuPtc6Sb2pidExYJwQGLqsMvU7o,15,'تنظيف الملف الرئيسي','')
	D94gwA1Z5JrIx2BiPyHobXuhM3n = D94gwA1Z5JrIx2BiPyHobXuhM3n.replace('"tvg-','" tvg-')
	D94gwA1Z5JrIx2BiPyHobXuhM3n = D94gwA1Z5JrIx2BiPyHobXuhM3n.replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
	D94gwA1Z5JrIx2BiPyHobXuhM3n = D94gwA1Z5JrIx2BiPyHobXuhM3n.replace('ّ','').replace('ِ','').replace('ٍ','').replace('ْ','')
	D94gwA1Z5JrIx2BiPyHobXuhM3n = D94gwA1Z5JrIx2BiPyHobXuhM3n.replace('group-title=','group=').replace('tvg-','')
	b1k64DBqh9,ggGaEKquH6DV0WIAChXv4y5J = [],[]
	D94gwA1Z5JrIx2BiPyHobXuhM3n = D94gwA1Z5JrIx2BiPyHobXuhM3n.replace('\r','\n')
	Dxe4mO65obSHMKrlWsjwvX = u5h2Rckvw1E.findall('NF:(.+?)'+'#'+'EXTI',D94gwA1Z5JrIx2BiPyHobXuhM3n+'\n+'+'#'+'EXTINF:',u5h2Rckvw1E.DOTALL)
	if not Dxe4mO65obSHMKrlWsjwvX:
		l0SAerv8zGH2Wa('ERROR_LINES',CC7Td6HzItGeMfumSaxDEZchp(ERLBl7fGCXQYchpgj6d)+'   Folder:'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE+'  Sequence:'+IKBpN0ZXVri+'   No video links found in M3U file')
		xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','رابط ـM3U الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـM3U غير صحيح'+'\n'+'[COLOR FFFFFF00]'+'مجلد رقم '+nCSJkub4hZM3dH1KpRIUr8a7tBNevE+'      رابط رقم '+IKBpN0ZXVri+'[/COLOR]')
		zRuPtc6Sb2pidExYJwQGLqsMvU7o.close()
		return
	FJNpobkCSnLmGe6aU0EM = []
	for Bx1JlohpcEg in Dxe4mO65obSHMKrlWsjwvX:
		MS5u4xwr3zG6RvJkg1qby = Bx1JlohpcEg.lower()
		if 'adult' in MS5u4xwr3zG6RvJkg1qby: continue
		if 'xxx' in MS5u4xwr3zG6RvJkg1qby: continue
		FJNpobkCSnLmGe6aU0EM.append(Bx1JlohpcEg)
	Dxe4mO65obSHMKrlWsjwvX = FJNpobkCSnLmGe6aU0EM
	del FJNpobkCSnLmGe6aU0EM
	if 'iptv-org' in S0EXKGMckjfszwYLH69qtP8:
		FJNpobkCSnLmGe6aU0EM,wa9dMg3UWfqvh1KGDeIQzEmBxpJ = [],[]
		for Bx1JlohpcEg in Dxe4mO65obSHMKrlWsjwvX:
			LakNgBAzD4R7CV3tFdfne = u5h2Rckvw1E.findall('group="(.*?)"',Bx1JlohpcEg,u5h2Rckvw1E.DOTALL)
			if LakNgBAzD4R7CV3tFdfne:
				LakNgBAzD4R7CV3tFdfne = LakNgBAzD4R7CV3tFdfne[0]
				TOE4efRUPpsyxtNAJQ = LakNgBAzD4R7CV3tFdfne.split(';')
				if 'region' in S0EXKGMckjfszwYLH69qtP8: TcrQRD62a9XjvlnJGphUC15NOFZ = '1_'
				elif 'category' in S0EXKGMckjfszwYLH69qtP8: TcrQRD62a9XjvlnJGphUC15NOFZ = '2_'
				elif 'language' in S0EXKGMckjfszwYLH69qtP8: TcrQRD62a9XjvlnJGphUC15NOFZ = '3_'
				elif 'country' in S0EXKGMckjfszwYLH69qtP8: TcrQRD62a9XjvlnJGphUC15NOFZ = '4_'
				else: TcrQRD62a9XjvlnJGphUC15NOFZ = '5_'
				w1zsJaNrdAhg46j5D3yQIeP = Bx1JlohpcEg.replace('group="'+LakNgBAzD4R7CV3tFdfne+'"','group="'+TcrQRD62a9XjvlnJGphUC15NOFZ+'~[COLOR FFC89008] ===== ===== ===== [/COLOR]'+'"')
				FJNpobkCSnLmGe6aU0EM.append(w1zsJaNrdAhg46j5D3yQIeP)
				for HwuFsvM9jV8yY in TOE4efRUPpsyxtNAJQ:
					w1zsJaNrdAhg46j5D3yQIeP = Bx1JlohpcEg.replace('group="'+LakNgBAzD4R7CV3tFdfne+'"','group="'+TcrQRD62a9XjvlnJGphUC15NOFZ+HwuFsvM9jV8yY+'"')
					FJNpobkCSnLmGe6aU0EM.append(w1zsJaNrdAhg46j5D3yQIeP)
			else: FJNpobkCSnLmGe6aU0EM.append(Bx1JlohpcEg)
		Dxe4mO65obSHMKrlWsjwvX = FJNpobkCSnLmGe6aU0EM
		del FJNpobkCSnLmGe6aU0EM,wa9dMg3UWfqvh1KGDeIQzEmBxpJ
	EKRaAsI8gx = 1024*1024
	T5Cyxj8UrV6HqRW2Jvw = 1+len(D94gwA1Z5JrIx2BiPyHobXuhM3n)//EKRaAsI8gx//10
	del D94gwA1Z5JrIx2BiPyHobXuhM3n
	xtBPfdiAXbH25VceLqpDGowZhE = len(Dxe4mO65obSHMKrlWsjwvX)
	wa9dMg3UWfqvh1KGDeIQzEmBxpJ = DofFeEVCk8B4rucUyJKPLZx(Dxe4mO65obSHMKrlWsjwvX,T5Cyxj8UrV6HqRW2Jvw)
	del Dxe4mO65obSHMKrlWsjwvX
	for OTxp2K4Vayb8CoUFJSWA in range(T5Cyxj8UrV6HqRW2Jvw):
		hyCqU2Ns4B1J3EH7fQVe6DXtzgFuI(zRuPtc6Sb2pidExYJwQGLqsMvU7o,35+int(5*OTxp2K4Vayb8CoUFJSWA/T5Cyxj8UrV6HqRW2Jvw),'تقطيع الملف الرئيسي','الجزء رقم:-',str(OTxp2K4Vayb8CoUFJSWA+1)+' / '+str(T5Cyxj8UrV6HqRW2Jvw))
		if zRuPtc6Sb2pidExYJwQGLqsMvU7o.iscanceled():
			zRuPtc6Sb2pidExYJwQGLqsMvU7o.close()
			return
		pBRwdOxV0UrhGeIZMDfabN2gjStocC = str(wa9dMg3UWfqvh1KGDeIQzEmBxpJ[OTxp2K4Vayb8CoUFJSWA])
		if VVGRN7xiyj: pBRwdOxV0UrhGeIZMDfabN2gjStocC = pBRwdOxV0UrhGeIZMDfabN2gjStocC.encode('utf8')
		open(QQtKsFu2cdnf+'.00'+str(OTxp2K4Vayb8CoUFJSWA),'wb').write(pBRwdOxV0UrhGeIZMDfabN2gjStocC)
	del wa9dMg3UWfqvh1KGDeIQzEmBxpJ,pBRwdOxV0UrhGeIZMDfabN2gjStocC
	lLX3F1Wmugck4vDH02yqEIT5Ga,iiqb3WMPNKmpctEI,z5GRTewnrMpxQLjKoE = [],[],0
	for OTxp2K4Vayb8CoUFJSWA in range(T5Cyxj8UrV6HqRW2Jvw):
		if zRuPtc6Sb2pidExYJwQGLqsMvU7o.iscanceled():
			zRuPtc6Sb2pidExYJwQGLqsMvU7o.close()
			return
		pBRwdOxV0UrhGeIZMDfabN2gjStocC = open(QQtKsFu2cdnf+'.00'+str(OTxp2K4Vayb8CoUFJSWA),'rb').read()
		YVJPFvuI2CS5KObiZt.sleep(1)
		try: k1t0JLRsCQ.remove(QQtKsFu2cdnf+'.00'+str(OTxp2K4Vayb8CoUFJSWA))
		except: pass
		if VVGRN7xiyj: pBRwdOxV0UrhGeIZMDfabN2gjStocC = pBRwdOxV0UrhGeIZMDfabN2gjStocC.decode('utf8')
		l0ftmXdxCiceYDFswNa29rBM34 = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('list',pBRwdOxV0UrhGeIZMDfabN2gjStocC)
		del pBRwdOxV0UrhGeIZMDfabN2gjStocC
		GHZEu6VbXDjk5sCmohY4M2c1p,z5GRTewnrMpxQLjKoE,FbsrBETNDKSn5lPk1 = tcFhYb3wQGmJRkvzfPon6DsujM1W(l0ftmXdxCiceYDFswNa29rBM34,ggGaEKquH6DV0WIAChXv4y5J,b1k64DBqh9,zRuPtc6Sb2pidExYJwQGLqsMvU7o,xtBPfdiAXbH25VceLqpDGowZhE,z5GRTewnrMpxQLjKoE,S0EXKGMckjfszwYLH69qtP8)
		if zRuPtc6Sb2pidExYJwQGLqsMvU7o.iscanceled():
			zRuPtc6Sb2pidExYJwQGLqsMvU7o.close()
			return
		if not GHZEu6VbXDjk5sCmohY4M2c1p:
			zRuPtc6Sb2pidExYJwQGLqsMvU7o.close()
			return
		iiqb3WMPNKmpctEI += GHZEu6VbXDjk5sCmohY4M2c1p
		lLX3F1Wmugck4vDH02yqEIT5Ga += FbsrBETNDKSn5lPk1
	del l0ftmXdxCiceYDFswNa29rBM34,GHZEu6VbXDjk5sCmohY4M2c1p
	logFO0JZhCEBYts9yQHW,FbsrBETNDKSn5lPk1 = uvtfGJLPsI6K3Wkg8l(iiqb3WMPNKmpctEI,zRuPtc6Sb2pidExYJwQGLqsMvU7o,IKBpN0ZXVri)
	if zRuPtc6Sb2pidExYJwQGLqsMvU7o.iscanceled():
		zRuPtc6Sb2pidExYJwQGLqsMvU7o.close()
		return
	lLX3F1Wmugck4vDH02yqEIT5Ga += FbsrBETNDKSn5lPk1
	del iiqb3WMPNKmpctEI,FbsrBETNDKSn5lPk1
	i6jQ5CUoRgtEvIqzJaPs,UVzHc7EDFpd5xfLhPjsZ0oG,LakNgBAzD4R7CV3tFdfne,VAlXQdbWpi7G,EtrNchixRjVB304FDSou6fzY = {},{},{},0,0
	e3hW9DtqrVf = list(logFO0JZhCEBYts9yQHW.keys())
	kTC4PIFr2vmJLqlsGQMKR31Vz = len(e3hW9DtqrVf)*3
	if 1:
		wOBjpc5WV8LoRfTQeFSg73Y = {}
		for Dmj48aHieZnxWPEgC in e3hW9DtqrVf:
			wOBjpc5WV8LoRfTQeFSg73Y[Dmj48aHieZnxWPEgC] = onVDrgLUpFsqOPkxId9BwW6Rtc5A.Thread(target=Ua87AwqprD9vPgYBZlORdceLMXj,args=(Dmj48aHieZnxWPEgC,))
			wOBjpc5WV8LoRfTQeFSg73Y[Dmj48aHieZnxWPEgC].start()
		for Dmj48aHieZnxWPEgC in e3hW9DtqrVf:
			wOBjpc5WV8LoRfTQeFSg73Y[Dmj48aHieZnxWPEgC].join()
		if zRuPtc6Sb2pidExYJwQGLqsMvU7o.iscanceled():
			zRuPtc6Sb2pidExYJwQGLqsMvU7o.close()
			return
	else:
		for Dmj48aHieZnxWPEgC in e3hW9DtqrVf:
			Ua87AwqprD9vPgYBZlORdceLMXj(Dmj48aHieZnxWPEgC)
			if zRuPtc6Sb2pidExYJwQGLqsMvU7o.iscanceled():
				zRuPtc6Sb2pidExYJwQGLqsMvU7o.close()
				return
	yhmLnwqdg3f0KQl4V9CH1Utz(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,IKBpN0ZXVri,False)
	e3hW9DtqrVf = list(i6jQ5CUoRgtEvIqzJaPs.keys())
	N3huw4lo1bxgJDjKfzQXpL0rUaR = 0
	if 1:
		wOBjpc5WV8LoRfTQeFSg73Y = {}
		for Dmj48aHieZnxWPEgC in e3hW9DtqrVf:
			wOBjpc5WV8LoRfTQeFSg73Y[Dmj48aHieZnxWPEgC] = onVDrgLUpFsqOPkxId9BwW6Rtc5A.Thread(target=q3y7okBM9CKJXsPcv8xQIgYdLen15t,args=(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,Dmj48aHieZnxWPEgC))
			wOBjpc5WV8LoRfTQeFSg73Y[Dmj48aHieZnxWPEgC].start()
		for Dmj48aHieZnxWPEgC in e3hW9DtqrVf:
			wOBjpc5WV8LoRfTQeFSg73Y[Dmj48aHieZnxWPEgC].join()
		if zRuPtc6Sb2pidExYJwQGLqsMvU7o.iscanceled():
			zRuPtc6Sb2pidExYJwQGLqsMvU7o.close()
			return
	else:
		for Dmj48aHieZnxWPEgC in e3hW9DtqrVf:
			q3y7okBM9CKJXsPcv8xQIgYdLen15t(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,Dmj48aHieZnxWPEgC)
			if zRuPtc6Sb2pidExYJwQGLqsMvU7o.iscanceled():
				zRuPtc6Sb2pidExYJwQGLqsMvU7o.close()
				return
	OTxp2K4Vayb8CoUFJSWA = 0
	d4iFPaMgrWE = len(lLX3F1Wmugck4vDH02yqEIT5Ga)
	Hj0zNOTDePKkIviZqFm2oQrVwp4hC3 = keRHziQrENXZW07oBwTm(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,'IGNORED')
	for UxhDlkNpcz1P4oEWa2Fn069V in lLX3F1Wmugck4vDH02yqEIT5Ga:
		if OTxp2K4Vayb8CoUFJSWA%27==0:
			hyCqU2Ns4B1J3EH7fQVe6DXtzgFuI(zRuPtc6Sb2pidExYJwQGLqsMvU7o,95+int(5*OTxp2K4Vayb8CoUFJSWA//d4iFPaMgrWE),'تخزين المهملة','الفيديو رقم:-',str(OTxp2K4Vayb8CoUFJSWA)+' / '+str(d4iFPaMgrWE))
			if zRuPtc6Sb2pidExYJwQGLqsMvU7o.iscanceled():
				zRuPtc6Sb2pidExYJwQGLqsMvU7o.close()
				return
		OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,'IGNORED_'+IKBpN0ZXVri,str(UxhDlkNpcz1P4oEWa2Fn069V),'',NVbfv48oh3M6U)
		OTxp2K4Vayb8CoUFJSWA += 1
	OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,'IGNORED_'+IKBpN0ZXVri,'__COUNT__',str(d4iFPaMgrWE),NVbfv48oh3M6U)
	zRuPtc6Sb2pidExYJwQGLqsMvU7o.close()
	YVJPFvuI2CS5KObiZt.sleep(1)
	Q6PTy5fRhWxcn(nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	return
def Ua87AwqprD9vPgYBZlORdceLMXj(Dmj48aHieZnxWPEgC):
	global zRuPtc6Sb2pidExYJwQGLqsMvU7o,logFO0JZhCEBYts9yQHW,N3huw4lo1bxgJDjKfzQXpL0rUaR,i6jQ5CUoRgtEvIqzJaPs,UVzHc7EDFpd5xfLhPjsZ0oG,LakNgBAzD4R7CV3tFdfne,VAlXQdbWpi7G,EtrNchixRjVB304FDSou6fzY,kTC4PIFr2vmJLqlsGQMKR31Vz
	i6jQ5CUoRgtEvIqzJaPs[Dmj48aHieZnxWPEgC] = {}
	ssaR0lv4ZU,GfOQUymJR7FTqhvYStXnbBP1uK = {},[]
	NNH80pkDRuT3fyexqjF1lZU = len(logFO0JZhCEBYts9yQHW[Dmj48aHieZnxWPEgC])
	i6jQ5CUoRgtEvIqzJaPs[Dmj48aHieZnxWPEgC]['__COUNT__'] = NNH80pkDRuT3fyexqjF1lZU
	if NNH80pkDRuT3fyexqjF1lZU>0:
		aEBO6C3MsDVl4cnvheSgxjY,LaZI65VStAU39PKHc4dNj8GfQE2,UsDqfLOByXtxcKNJTpPdCbvIrRYh,V7Vf91qrPlEAkmFLdx32eIg,jjG6qRLB1UnJpEbzg5AXoedl = zip(*logFO0JZhCEBYts9yQHW[Dmj48aHieZnxWPEgC])
		del LaZI65VStAU39PKHc4dNj8GfQE2,UsDqfLOByXtxcKNJTpPdCbvIrRYh,V7Vf91qrPlEAkmFLdx32eIg
		TOE4efRUPpsyxtNAJQ = list(set(aEBO6C3MsDVl4cnvheSgxjY))
		for HwuFsvM9jV8yY in TOE4efRUPpsyxtNAJQ:
			ssaR0lv4ZU[HwuFsvM9jV8yY] = ''
			i6jQ5CUoRgtEvIqzJaPs[Dmj48aHieZnxWPEgC][HwuFsvM9jV8yY] = []
		hyCqU2Ns4B1J3EH7fQVe6DXtzgFuI(zRuPtc6Sb2pidExYJwQGLqsMvU7o,60+int(15*EtrNchixRjVB304FDSou6fzY//kTC4PIFr2vmJLqlsGQMKR31Vz),'تصنيع القوائم','الجزء رقم:-',str(EtrNchixRjVB304FDSou6fzY)+' / '+str(kTC4PIFr2vmJLqlsGQMKR31Vz))
		if zRuPtc6Sb2pidExYJwQGLqsMvU7o.iscanceled(): return
		EtrNchixRjVB304FDSou6fzY += 1
		ooVcpT0SaxE7 = len(TOE4efRUPpsyxtNAJQ)
		del TOE4efRUPpsyxtNAJQ
		GfOQUymJR7FTqhvYStXnbBP1uK = list(set(zip(aEBO6C3MsDVl4cnvheSgxjY,jjG6qRLB1UnJpEbzg5AXoedl)))
		del aEBO6C3MsDVl4cnvheSgxjY,jjG6qRLB1UnJpEbzg5AXoedl
		for HwuFsvM9jV8yY,qRSNaY0t83hO9ofLEnJuAM1 in GfOQUymJR7FTqhvYStXnbBP1uK:
			if not ssaR0lv4ZU[HwuFsvM9jV8yY] and qRSNaY0t83hO9ofLEnJuAM1: ssaR0lv4ZU[HwuFsvM9jV8yY] = qRSNaY0t83hO9ofLEnJuAM1
		hyCqU2Ns4B1J3EH7fQVe6DXtzgFuI(zRuPtc6Sb2pidExYJwQGLqsMvU7o,60+int(15*EtrNchixRjVB304FDSou6fzY//kTC4PIFr2vmJLqlsGQMKR31Vz),'تصنيع القوائم','الجزء رقم:-',str(EtrNchixRjVB304FDSou6fzY)+' / '+str(kTC4PIFr2vmJLqlsGQMKR31Vz))
		if zRuPtc6Sb2pidExYJwQGLqsMvU7o.iscanceled(): return
		EtrNchixRjVB304FDSou6fzY += 1
		ARHsdkMK4B0L9z = list(ssaR0lv4ZU.keys())
		yn34CLKzFeg9RQSJ = list(ssaR0lv4ZU.values())
		del ssaR0lv4ZU
		GfOQUymJR7FTqhvYStXnbBP1uK = list(zip(ARHsdkMK4B0L9z,yn34CLKzFeg9RQSJ))
		del ARHsdkMK4B0L9z,yn34CLKzFeg9RQSJ
		GfOQUymJR7FTqhvYStXnbBP1uK = sorted(GfOQUymJR7FTqhvYStXnbBP1uK)
	else: EtrNchixRjVB304FDSou6fzY += 2
	i6jQ5CUoRgtEvIqzJaPs[Dmj48aHieZnxWPEgC]['__GROUPS__'] = GfOQUymJR7FTqhvYStXnbBP1uK
	del GfOQUymJR7FTqhvYStXnbBP1uK
	for HwuFsvM9jV8yY,wWXVYjrFaCg9zpboThAMQBU8iHJc,ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,GZdtFyDU0caf89r,f8dLQuoR4E3Kalqn in logFO0JZhCEBYts9yQHW[Dmj48aHieZnxWPEgC]:
		i6jQ5CUoRgtEvIqzJaPs[Dmj48aHieZnxWPEgC][HwuFsvM9jV8yY].append((wWXVYjrFaCg9zpboThAMQBU8iHJc,ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,GZdtFyDU0caf89r,f8dLQuoR4E3Kalqn))
	hyCqU2Ns4B1J3EH7fQVe6DXtzgFuI(zRuPtc6Sb2pidExYJwQGLqsMvU7o,60+int(15*EtrNchixRjVB304FDSou6fzY//kTC4PIFr2vmJLqlsGQMKR31Vz),'تصنيع القوائم','الجزء رقم:-',str(EtrNchixRjVB304FDSou6fzY)+' / '+str(kTC4PIFr2vmJLqlsGQMKR31Vz))
	if zRuPtc6Sb2pidExYJwQGLqsMvU7o.iscanceled(): return
	EtrNchixRjVB304FDSou6fzY += 1
	del logFO0JZhCEBYts9yQHW[Dmj48aHieZnxWPEgC]
	LakNgBAzD4R7CV3tFdfne[Dmj48aHieZnxWPEgC] = list(i6jQ5CUoRgtEvIqzJaPs[Dmj48aHieZnxWPEgC].keys())
	UVzHc7EDFpd5xfLhPjsZ0oG[Dmj48aHieZnxWPEgC] = len(LakNgBAzD4R7CV3tFdfne[Dmj48aHieZnxWPEgC])
	VAlXQdbWpi7G += UVzHc7EDFpd5xfLhPjsZ0oG[Dmj48aHieZnxWPEgC]
	return
def q3y7okBM9CKJXsPcv8xQIgYdLen15t(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,Dmj48aHieZnxWPEgC):
	global zRuPtc6Sb2pidExYJwQGLqsMvU7o,logFO0JZhCEBYts9yQHW,N3huw4lo1bxgJDjKfzQXpL0rUaR,i6jQ5CUoRgtEvIqzJaPs,UVzHc7EDFpd5xfLhPjsZ0oG,LakNgBAzD4R7CV3tFdfne,VAlXQdbWpi7G,EtrNchixRjVB304FDSou6fzY,kTC4PIFr2vmJLqlsGQMKR31Vz
	Hj0zNOTDePKkIviZqFm2oQrVwp4hC3 = keRHziQrENXZW07oBwTm(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,Dmj48aHieZnxWPEgC)
	for z5GRTewnrMpxQLjKoE in range(1+UVzHc7EDFpd5xfLhPjsZ0oG[Dmj48aHieZnxWPEgC]//273):
		r3BqXfM4wN = []
		ztR3gXCrZnovO2Spq1muQ5if7Ih = LakNgBAzD4R7CV3tFdfne[Dmj48aHieZnxWPEgC][0:273]
		for HwuFsvM9jV8yY in ztR3gXCrZnovO2Spq1muQ5if7Ih:
			r3BqXfM4wN.append(i6jQ5CUoRgtEvIqzJaPs[Dmj48aHieZnxWPEgC][HwuFsvM9jV8yY])
		OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,Dmj48aHieZnxWPEgC,ztR3gXCrZnovO2Spq1muQ5if7Ih,r3BqXfM4wN,NVbfv48oh3M6U,True)
		N3huw4lo1bxgJDjKfzQXpL0rUaR += len(ztR3gXCrZnovO2Spq1muQ5if7Ih)
		hyCqU2Ns4B1J3EH7fQVe6DXtzgFuI(zRuPtc6Sb2pidExYJwQGLqsMvU7o,75+int(20*N3huw4lo1bxgJDjKfzQXpL0rUaR//VAlXQdbWpi7G),'تخزين القوائم','القائمة رقم:-',str(N3huw4lo1bxgJDjKfzQXpL0rUaR)+' / '+str(VAlXQdbWpi7G))
		if zRuPtc6Sb2pidExYJwQGLqsMvU7o.iscanceled(): return
		del LakNgBAzD4R7CV3tFdfne[Dmj48aHieZnxWPEgC][0:273]
	del i6jQ5CUoRgtEvIqzJaPs[Dmj48aHieZnxWPEgC],LakNgBAzD4R7CV3tFdfne[Dmj48aHieZnxWPEgC],UVzHc7EDFpd5xfLhPjsZ0oG[Dmj48aHieZnxWPEgC]
	return
def ooUBXG6Mx58tIE3SiC1VT2ef(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,IKBpN0ZXVri,Na1U7ZMp3yQbhuOdcwS=True):
	ppsSnODBlEFrLhdKG4MmJWgw7fvZio = 'عدد فيديوهات جميع الروابط'
	AbGSaqVMdwBW9 = keRHziQrENXZW07oBwTm(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,'LIVE_ORIGINAL_GROUPED')
	vZQjx8J1HpqnD2 = keRHziQrENXZW07oBwTm(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,'VOD_ORIGINAL_GROUPED')
	if IKBpN0ZXVri:
		ppsSnODBlEFrLhdKG4MmJWgw7fvZio = 'عدد فيديوهات رابط '+r5tHLX2ZFS1Kz9jRba0fsc[int(IKBpN0ZXVri)]
		IKBpN0ZXVri = '_'+IKBpN0ZXVri
	d4iFPaMgrWE = AsTbx64cCEi1(AbGSaqVMdwBW9,'int','IGNORED'+IKBpN0ZXVri,'__COUNT__')
	D1yQ6q0T7lNCAs = AsTbx64cCEi1(AbGSaqVMdwBW9,'int','LIVE_ORIGINAL_GROUPED'+IKBpN0ZXVri,'__COUNT__')
	W3ownrtXxJyKeu7ZNd0AGDP4SUh1Y = AsTbx64cCEi1(vZQjx8J1HpqnD2,'int','VOD_ORIGINAL_GROUPED'+IKBpN0ZXVri,'__COUNT__')
	h9GsEr4BzP = AsTbx64cCEi1(AbGSaqVMdwBW9,'int','LIVE_GROUPED'+IKBpN0ZXVri,'__COUNT__')
	gqR3WUhjfsSTX5tI0CbyOiVP = AsTbx64cCEi1(AbGSaqVMdwBW9,'int','LIVE_UNKNOWN_GROUPED'+IKBpN0ZXVri,'__COUNT__')
	irLvoZe6gj23hV = AsTbx64cCEi1(AbGSaqVMdwBW9,'int','VOD_MOVIES_GROUPED'+IKBpN0ZXVri,'__COUNT__')
	uEIa3N51dYKV8HWDpbSZTC4 = AsTbx64cCEi1(vZQjx8J1HpqnD2,'int','VOD_SERIES_GROUPED'+IKBpN0ZXVri,'__COUNT__')
	LGdVXb0jsMlPuti3zoxNqAngh = AsTbx64cCEi1(AbGSaqVMdwBW9,'int','VOD_UNKNOWN_GROUPED'+IKBpN0ZXVri,'__COUNT__')
	LakNgBAzD4R7CV3tFdfne = AsTbx64cCEi1(vZQjx8J1HpqnD2,'list','VOD_SERIES_GROUPED'+IKBpN0ZXVri,'__GROUPS__')
	YaNtBkFT5Vh2KzHQS0P6s = []
	for HwuFsvM9jV8yY,f8dLQuoR4E3Kalqn in LakNgBAzD4R7CV3tFdfne:
		bsd64GoM9ivceahF = HwuFsvM9jV8yY.split('__SERIES__')[1]
		YaNtBkFT5Vh2KzHQS0P6s.append(bsd64GoM9ivceahF)
	NiPCAErm3p4juJw8 = len(YaNtBkFT5Vh2KzHQS0P6s)
	NiW1bXUTvQyzq4rBJeDaEShIC = int(irLvoZe6gj23hV)+int(uEIa3N51dYKV8HWDpbSZTC4)+int(LGdVXb0jsMlPuti3zoxNqAngh)+int(gqR3WUhjfsSTX5tI0CbyOiVP)+int(h9GsEr4BzP)
	xyBvTnNeHrX6b0IuEQKfL = ''
	xyBvTnNeHrX6b0IuEQKfL += 'قنوات: '+str(h9GsEr4BzP)
	xyBvTnNeHrX6b0IuEQKfL += '   .   أفلام: '+str(irLvoZe6gj23hV)
	xyBvTnNeHrX6b0IuEQKfL += '\nمسلسلات: '+str(NiPCAErm3p4juJw8)
	xyBvTnNeHrX6b0IuEQKfL += '   .   حلقات: '+str(uEIa3N51dYKV8HWDpbSZTC4)
	xyBvTnNeHrX6b0IuEQKfL += '\nقنوات مجهولة: '+str(gqR3WUhjfsSTX5tI0CbyOiVP)
	xyBvTnNeHrX6b0IuEQKfL += '   .   فيدوهات مجهولة: '+str(LGdVXb0jsMlPuti3zoxNqAngh)
	xyBvTnNeHrX6b0IuEQKfL += '\nمجموع القنوات: '+str(D1yQ6q0T7lNCAs)
	xyBvTnNeHrX6b0IuEQKfL += '   .   مجموع الفيديوهات: '+str(W3ownrtXxJyKeu7ZNd0AGDP4SUh1Y)
	xyBvTnNeHrX6b0IuEQKfL += '\n\nمجموع المضافة: '+str(NiW1bXUTvQyzq4rBJeDaEShIC)
	xyBvTnNeHrX6b0IuEQKfL += '   .   مجموع المهملة: '+str(d4iFPaMgrWE)
	if Na1U7ZMp3yQbhuOdcwS: xl9MFt1AmY0GrkENug8n('center','',ppsSnODBlEFrLhdKG4MmJWgw7fvZio,xyBvTnNeHrX6b0IuEQKfL)
	ssj0rJGt6d4iVMcD9e = xyBvTnNeHrX6b0IuEQKfL.replace('\n\n','\n')
	if not IKBpN0ZXVri: IKBpN0ZXVri = 'All'
	else: IKBpN0ZXVri = IKBpN0ZXVri[1]
	l0SAerv8zGH2Wa('NOTICE','.  Counts of M3U videos   Folder: '+nCSJkub4hZM3dH1KpRIUr8a7tBNevE+'   Sequence: '+IKBpN0ZXVri+'\n'+ssj0rJGt6d4iVMcD9e)
	return xyBvTnNeHrX6b0IuEQKfL
def yhmLnwqdg3f0KQl4V9CH1Utz(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,IKBpN0ZXVri,Na1U7ZMp3yQbhuOdcwS=True):
	if Na1U7ZMp3yQbhuOdcwS:
		TTGDytYoQjb9OlFRzK1Ln = lLPSDywfu4axrUhvX9RQEpGtso6H0('center','','','مسح ملفات M3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if TTGDytYoQjb9OlFRzK1Ln!=1: return
		SGQt1BPyaUme3EZqDk = ttyjfLqbA1VJNOu.replace('___','_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE+'_'+IKBpN0ZXVri)
		try: k1t0JLRsCQ.remove(SGQt1BPyaUme3EZqDk)
		except: pass
	Hj0zNOTDePKkIviZqFm2oQrVwp4hC3 = keRHziQrENXZW07oBwTm(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,'')
	if IKBpN0ZXVri:
		tQP523cuD9XqnoTrwdNmO = []
		for PbYVHJoN0w3FiDEsxvdpMl4TU2 in aEcb9iDHs8ySolrwe1UYNt035:
			tQP523cuD9XqnoTrwdNmO.append(PbYVHJoN0w3FiDEsxvdpMl4TU2+'_'+IKBpN0ZXVri)
		ZqlR5BFQ6pm0asCHLUc(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,'LINK_'+IKBpN0ZXVri)
	else:
		tQP523cuD9XqnoTrwdNmO = aEcb9iDHs8ySolrwe1UYNt035
		ZqlR5BFQ6pm0asCHLUc(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,'DUMMY')
		ZqlR5BFQ6pm0asCHLUc(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,'GROUPS')
		ZqlR5BFQ6pm0asCHLUc(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,'ITEMS')
		ZqlR5BFQ6pm0asCHLUc(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,'SEARCH')
	ZqlR5BFQ6pm0asCHLUc(bpNSygerL10j4IOkEfuVw,'SECTIONS_M3U','SECTIONS_M3U_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	ZqlR5BFQ6pm0asCHLUc(bpNSygerL10j4IOkEfuVw,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	for Dmj48aHieZnxWPEgC in tQP523cuD9XqnoTrwdNmO:
		ZqlR5BFQ6pm0asCHLUc(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,Dmj48aHieZnxWPEgC)
	tBUYedV3Q4FcLRwEx2DnMilz6(False)
	Q6PTy5fRhWxcn(nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	if Na1U7ZMp3yQbhuOdcwS: xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
	return
def OSDp6mYAsavhl0boq(nCSJkub4hZM3dH1KpRIUr8a7tBNevE='',Na1U7ZMp3yQbhuOdcwS=True):
	if nCSJkub4hZM3dH1KpRIUr8a7tBNevE:
		Hj0zNOTDePKkIviZqFm2oQrVwp4hC3 = keRHziQrENXZW07oBwTm(str(nCSJkub4hZM3dH1KpRIUr8a7tBNevE),'DUMMY')
		ir74YTmhPq = AsTbx64cCEi1(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,'str','DUMMY','__DUMMY__')
		if ir74YTmhPq: return True
	else:
		nCSJkub4hZM3dH1KpRIUr8a7tBNevE = '1'
		for C6Od2gzwh1pnmDuBNTaxQve3 in range(1,vMrXCkF9Kmu+1):
			Hj0zNOTDePKkIviZqFm2oQrVwp4hC3 = keRHziQrENXZW07oBwTm(str(C6Od2gzwh1pnmDuBNTaxQve3),'DUMMY')
			ir74YTmhPq = AsTbx64cCEi1(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,'str','DUMMY','__DUMMY__')
			if ir74YTmhPq: return True
	if Na1U7ZMp3yQbhuOdcwS:
		uYdHVhTP3p = 'https://iptv-org.github.io/iptv/index.region.m3u'
		wKnVtXcsgGbAaR2OY4I = 'https://iptv-org.github.io/iptv/index.category.m3u'
		LYby8emIBN46p0HXE3 = 'https://iptv-org.github.io/iptv/index.language.m3u'
		hZLza05yTfuRtsQpAPm286KeOBb = 'https://iptv-org.github.io/iptv/index.country.m3u'
		mCKhwfbDQXR1zlYvj = uYdHVhTP3p+'\n'+wKnVtXcsgGbAaR2OY4I+'\n'+LYby8emIBN46p0HXE3+'\n'+hZLza05yTfuRtsQpAPm286KeOBb
		TTGDytYoQjb9OlFRzK1Ln = lLPSDywfu4axrUhvX9RQEpGtso6H0('','','','رسالة من المبرمج','هذا الجزء من البرنامج يحتاج رابط فيديوهات نوعه M3U ومتوفر في الإنترنت مجانا وأيضا ممكن شراءه من الشركات المختصة . الموقع أدناه فيه روابط مجانية وهي ليست ملك المبرمج (صاحب هذا البرنامج) . ولا علاقة للمبرمج بمحتوياتها . والمبرمج لا يتحمل أي مسؤولية بسبب استخدام أي روابط مجانية أو غير مجانية\n [COLOR FFC89008]http://github.com/iptv-org/iptv[/COLOR]\nالروابط أدناه مجانية ومأخوذة من الموقع أعلاه هل تريد استخدامها\n [COLOR FFC89008]'+mCKhwfbDQXR1zlYvj+'[/COLOR]',profile='confirm_mediumfont')
		if TTGDytYoQjb9OlFRzK1Ln==1:
			LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting('av.m3u.url_'+str(nCSJkub4hZM3dH1KpRIUr8a7tBNevE)+'_1',uYdHVhTP3p)
			LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting('av.m3u.url_'+str(nCSJkub4hZM3dH1KpRIUr8a7tBNevE)+'_2',wKnVtXcsgGbAaR2OY4I)
			LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting('av.m3u.url_'+str(nCSJkub4hZM3dH1KpRIUr8a7tBNevE)+'_3',LYby8emIBN46p0HXE3)
			LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting('av.m3u.url_'+str(nCSJkub4hZM3dH1KpRIUr8a7tBNevE)+'_4',hZLza05yTfuRtsQpAPm286KeOBb)
			TTGDytYoQjb9OlFRzK1Ln = lLPSDywfu4axrUhvX9RQEpGtso6H0('','','','رسالة من المبرمج','للاستفادة من روابط M3U التي أنت أضفتها للبرنامج .. أنت بحاجة إلى جلب ملفات هذه الروابط الجديدة .. هل تريد الآن جلب ملفات روابط M3U التي أنت أضفتها للبرنامج ؟!')
			if TTGDytYoQjb9OlFRzK1Ln==1:
				Sz4yfB8rZqYTdH3DKMUhObR5uNEavP = jLA9FpzV52dQN1Zg(nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
				return Sz4yfB8rZqYTdH3DKMUhObR5uNEavP
		else:
			ppsSnODBlEFrLhdKG4MmJWgw7fvZio = 'إضافة وتغيير رابط '+r5tHLX2ZFS1Kz9jRba0fsc[1]+' (مجلد '+r5tHLX2ZFS1Kz9jRba0fsc[int(nCSJkub4hZM3dH1KpRIUr8a7tBNevE)]+')'
			TTGDytYoQjb9OlFRzK1Ln = lLPSDywfu4axrUhvX9RQEpGtso6H0('','','',ppsSnODBlEFrLhdKG4MmJWgw7fvZio,'لإضافة رابط M3U .. أولا أفتح قائمة M3U .. وثانيا أنقر على إضافة رابط أو اشتراك M3U .. وثالثا أنقر على جلب ملفات ـM3U \n\n هل تريد إضافة أو تغيير رابط M3U الآن ؟!')
			if TTGDytYoQjb9OlFRzK1Ln==1: ueMYIa0pJrsKtw(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,'1')
	return False
def GnJ5vKxzWhoYXw0IFyi6TSEVsNHaMp(ZjyBIfXLwGQTAz7hkDPv,nCSJkub4hZM3dH1KpRIUr8a7tBNevE='',Dmj48aHieZnxWPEgC='',EnvI67ZlRzSyjegGuxi2kC9=''):
	if not EnvI67ZlRzSyjegGuxi2kC9: EnvI67ZlRzSyjegGuxi2kC9 = '1'
	NweZkm8EIQjpDMUY9XasFGrPicJRb,O9AyF2MRjI,Na1U7ZMp3yQbhuOdcwS = kh9lHs2cCOInRLBDJiofTVwSv6(ZjyBIfXLwGQTAz7hkDPv)
	if not OSDp6mYAsavhl0boq(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,Na1U7ZMp3yQbhuOdcwS): return
	if not NweZkm8EIQjpDMUY9XasFGrPicJRb:
		NweZkm8EIQjpDMUY9XasFGrPicJRb = FBrXsYeCEp3()
		if not NweZkm8EIQjpDMUY9XasFGrPicJRb: return
	FIcs3CNbKUvrJ = ['','LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not Dmj48aHieZnxWPEgC:
		if not Na1U7ZMp3yQbhuOdcwS:
			if   '_M3U-LIVE_' in O9AyF2MRjI: Dmj48aHieZnxWPEgC = FIcs3CNbKUvrJ[1]
			elif '_M3U-MOVIES' in O9AyF2MRjI: Dmj48aHieZnxWPEgC = FIcs3CNbKUvrJ[2]
			elif '_M3U-SERIES' in O9AyF2MRjI: Dmj48aHieZnxWPEgC = FIcs3CNbKUvrJ[3]
			else: Dmj48aHieZnxWPEgC = FIcs3CNbKUvrJ[0]
		else:
			xX3bjwPQClg5Rt = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			aZ06RtK7TfOop52BJg4 = tYysxJLreEBDdXMIjz4OPa('أختر البحث المناسب', xX3bjwPQClg5Rt)
			if aZ06RtK7TfOop52BJg4==-1: return
			Dmj48aHieZnxWPEgC = FIcs3CNbKUvrJ[aZ06RtK7TfOop52BJg4]
	NweZkm8EIQjpDMUY9XasFGrPicJRb = NweZkm8EIQjpDMUY9XasFGrPicJRb+'_NODIALOGS_'
	if nCSJkub4hZM3dH1KpRIUr8a7tBNevE: PPOcQHKRGS0eMz8tqdn(NweZkm8EIQjpDMUY9XasFGrPicJRb,nCSJkub4hZM3dH1KpRIUr8a7tBNevE,Dmj48aHieZnxWPEgC,EnvI67ZlRzSyjegGuxi2kC9)
	else:
		for nCSJkub4hZM3dH1KpRIUr8a7tBNevE in range(1,vMrXCkF9Kmu+1):
			PPOcQHKRGS0eMz8tqdn(NweZkm8EIQjpDMUY9XasFGrPicJRb,str(nCSJkub4hZM3dH1KpRIUr8a7tBNevE),Dmj48aHieZnxWPEgC,EnvI67ZlRzSyjegGuxi2kC9)
		YD56nkJmsd[:] = sorted(YD56nkJmsd,reverse=False,key=lambda bbqxQZ2thM0: bbqxQZ2thM0[1].lower())
	return
def PPOcQHKRGS0eMz8tqdn(ZjyBIfXLwGQTAz7hkDPv,nCSJkub4hZM3dH1KpRIUr8a7tBNevE,Dmj48aHieZnxWPEgC='',EnvI67ZlRzSyjegGuxi2kC9=''):
	if not EnvI67ZlRzSyjegGuxi2kC9: EnvI67ZlRzSyjegGuxi2kC9 = '1'
	NweZkm8EIQjpDMUY9XasFGrPicJRb,O9AyF2MRjI,Na1U7ZMp3yQbhuOdcwS = kh9lHs2cCOInRLBDJiofTVwSv6(ZjyBIfXLwGQTAz7hkDPv)
	if not nCSJkub4hZM3dH1KpRIUr8a7tBNevE: return
	if not OSDp6mYAsavhl0boq(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,Na1U7ZMp3yQbhuOdcwS): return
	if not NweZkm8EIQjpDMUY9XasFGrPicJRb:
		NweZkm8EIQjpDMUY9XasFGrPicJRb = FBrXsYeCEp3()
		if not NweZkm8EIQjpDMUY9XasFGrPicJRb: return
	FIcs3CNbKUvrJ = ['','LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not Dmj48aHieZnxWPEgC:
		if not Na1U7ZMp3yQbhuOdcwS:
			if   '_M3U-LIVE_' in O9AyF2MRjI: Dmj48aHieZnxWPEgC = FIcs3CNbKUvrJ[1]
			elif '_M3U-MOVIES' in O9AyF2MRjI: Dmj48aHieZnxWPEgC = FIcs3CNbKUvrJ[2]
			elif '_M3U-SERIES' in O9AyF2MRjI: Dmj48aHieZnxWPEgC = FIcs3CNbKUvrJ[3]
			else: Dmj48aHieZnxWPEgC = FIcs3CNbKUvrJ[0]
		else:
			xX3bjwPQClg5Rt = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			aZ06RtK7TfOop52BJg4 = tYysxJLreEBDdXMIjz4OPa('أختر البحث المناسب', xX3bjwPQClg5Rt)
			if aZ06RtK7TfOop52BJg4==-1: return
			Dmj48aHieZnxWPEgC = FIcs3CNbKUvrJ[aZ06RtK7TfOop52BJg4]
	CnKW7HJLMlwY3 = NweZkm8EIQjpDMUY9XasFGrPicJRb.lower()
	Hj0zNOTDePKkIviZqFm2oQrVwp4hC3 = keRHziQrENXZW07oBwTm(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,'SEARCH')
	QZSU5eYbuF2miCW8Dh67yHnMtOA = AsTbx64cCEi1(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,'list','SEARCH',(Dmj48aHieZnxWPEgC,CnKW7HJLMlwY3))
	if not QZSU5eYbuF2miCW8Dh67yHnMtOA:
		QOajwM6ETsnJUedl2BiqKZGcRy,hg0KNjB1cC58UrTiqxpJOXLPf = [],[]
		if not Dmj48aHieZnxWPEgC: R8AxBpKys5zofgki6PVutm = [1,2,3,4,5]
		else: R8AxBpKys5zofgki6PVutm = [FIcs3CNbKUvrJ.index(Dmj48aHieZnxWPEgC)]
		for OTxp2K4Vayb8CoUFJSWA in R8AxBpKys5zofgki6PVutm:
			if OTxp2K4Vayb8CoUFJSWA!=3:
				GHZEu6VbXDjk5sCmohY4M2c1p = AsTbx64cCEi1(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,'dict',FIcs3CNbKUvrJ[OTxp2K4Vayb8CoUFJSWA])
				del GHZEu6VbXDjk5sCmohY4M2c1p['__COUNT__']
				del GHZEu6VbXDjk5sCmohY4M2c1p['__GROUPS__']
				del GHZEu6VbXDjk5sCmohY4M2c1p['__SEQUENCED_COLUMNS__']
				LakNgBAzD4R7CV3tFdfne = list(GHZEu6VbXDjk5sCmohY4M2c1p.keys())
				for HwuFsvM9jV8yY in LakNgBAzD4R7CV3tFdfne:
					for wWXVYjrFaCg9zpboThAMQBU8iHJc,ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,GZdtFyDU0caf89r,f8dLQuoR4E3Kalqn in GHZEu6VbXDjk5sCmohY4M2c1p[HwuFsvM9jV8yY]:
						if CnKW7HJLMlwY3 in ii7WOEjQFIHwgKhlDbtYdT13Anz4GC.lower(): hg0KNjB1cC58UrTiqxpJOXLPf.append((ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,GZdtFyDU0caf89r,f8dLQuoR4E3Kalqn))
					del GHZEu6VbXDjk5sCmohY4M2c1p[HwuFsvM9jV8yY]
				del GHZEu6VbXDjk5sCmohY4M2c1p
			else: LakNgBAzD4R7CV3tFdfne = AsTbx64cCEi1(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,'list',FIcs3CNbKUvrJ[OTxp2K4Vayb8CoUFJSWA],'__GROUPS__')
			for HwuFsvM9jV8yY in LakNgBAzD4R7CV3tFdfne:
				try: HwuFsvM9jV8yY,f8dLQuoR4E3Kalqn = HwuFsvM9jV8yY
				except: f8dLQuoR4E3Kalqn = ''
				if CnKW7HJLMlwY3 in HwuFsvM9jV8yY.lower():
					if OTxp2K4Vayb8CoUFJSWA!=3: GYHjebrZqWuUDdsRyFiwS5JOE0LTz = HwuFsvM9jV8yY
					else:
						UpiJN4usedRHZ,ikI0pbhtcGe = HwuFsvM9jV8yY.split('__SERIES__')
						if CnKW7HJLMlwY3 in UpiJN4usedRHZ.lower(): GYHjebrZqWuUDdsRyFiwS5JOE0LTz = UpiJN4usedRHZ
						else: GYHjebrZqWuUDdsRyFiwS5JOE0LTz = ikI0pbhtcGe
					QOajwM6ETsnJUedl2BiqKZGcRy.append((HwuFsvM9jV8yY,GYHjebrZqWuUDdsRyFiwS5JOE0LTz,FIcs3CNbKUvrJ[OTxp2K4Vayb8CoUFJSWA],f8dLQuoR4E3Kalqn))
			del LakNgBAzD4R7CV3tFdfne
		QOajwM6ETsnJUedl2BiqKZGcRy = set(QOajwM6ETsnJUedl2BiqKZGcRy)
		hg0KNjB1cC58UrTiqxpJOXLPf = set(hg0KNjB1cC58UrTiqxpJOXLPf)
		QOajwM6ETsnJUedl2BiqKZGcRy = sorted(QOajwM6ETsnJUedl2BiqKZGcRy,reverse=False,key=lambda bbqxQZ2thM0: bbqxQZ2thM0[1])
		hg0KNjB1cC58UrTiqxpJOXLPf = sorted(hg0KNjB1cC58UrTiqxpJOXLPf,reverse=False,key=lambda bbqxQZ2thM0: bbqxQZ2thM0[0])
		OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,'SEARCH',(Dmj48aHieZnxWPEgC,CnKW7HJLMlwY3),(QOajwM6ETsnJUedl2BiqKZGcRy,hg0KNjB1cC58UrTiqxpJOXLPf),NVbfv48oh3M6U)
	else: QOajwM6ETsnJUedl2BiqKZGcRy,hg0KNjB1cC58UrTiqxpJOXLPf = QZSU5eYbuF2miCW8Dh67yHnMtOA
	LakNgBAzD4R7CV3tFdfne = len(QOajwM6ETsnJUedl2BiqKZGcRy)
	HOZ4puqFEIt92SGCL0sUxlDrmiQanA = len(hg0KNjB1cC58UrTiqxpJOXLPf)
	Iy4bwu3m6qORhDrQSd19HYo8 = int(EnvI67ZlRzSyjegGuxi2kC9)
	Ix9NY2gOVhXDWum3AJ = max(0,(Iy4bwu3m6qORhDrQSd19HYo8-1)*100)
	RXWBzVM0T8te2cCIbuAy1hSaY = max(0,Iy4bwu3m6qORhDrQSd19HYo8*100)
	X0VIwZlHroY9 = max(0,Ix9NY2gOVhXDWum3AJ-LakNgBAzD4R7CV3tFdfne)
	AA3GlcpUOZhBLorKnwTv2PY65ysM = max(0,RXWBzVM0T8te2cCIbuAy1hSaY-LakNgBAzD4R7CV3tFdfne)
	for HwuFsvM9jV8yY,GYHjebrZqWuUDdsRyFiwS5JOE0LTz,sBJIhSno4pzefA,f8dLQuoR4E3Kalqn in QOajwM6ETsnJUedl2BiqKZGcRy[Ix9NY2gOVhXDWum3AJ:RXWBzVM0T8te2cCIbuAy1hSaY]:
		uQNUfbZx9yj0F('folder',unXlPWCM9EdmRAsybwT+GYHjebrZqWuUDdsRyFiwS5JOE0LTz,sBJIhSno4pzefA,714,f8dLQuoR4E3Kalqn,'1',HwuFsvM9jV8yY,'',{'folder':nCSJkub4hZM3dH1KpRIUr8a7tBNevE})
	del QOajwM6ETsnJUedl2BiqKZGcRy
	for ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,GZdtFyDU0caf89r,f8dLQuoR4E3Kalqn in hg0KNjB1cC58UrTiqxpJOXLPf[X0VIwZlHroY9:AA3GlcpUOZhBLorKnwTv2PY65ysM]:
		i5YT61IuenOcs8BPjFM4L90V = XS8G7Ljnkut(GZdtFyDU0caf89r)
		f0QP7qXsU4L9xtB = 'live'
		if '.mkv' in i5YT61IuenOcs8BPjFM4L90V or 'VOD' in Dmj48aHieZnxWPEgC: f0QP7qXsU4L9xtB = 'video'
		uQNUfbZx9yj0F(f0QP7qXsU4L9xtB,unXlPWCM9EdmRAsybwT+ii7WOEjQFIHwgKhlDbtYdT13Anz4GC,GZdtFyDU0caf89r,715,f8dLQuoR4E3Kalqn,'','','',{'folder':nCSJkub4hZM3dH1KpRIUr8a7tBNevE})
	del hg0KNjB1cC58UrTiqxpJOXLPf
	AAF5lDV1fcPn2T8(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,EnvI67ZlRzSyjegGuxi2kC9,Dmj48aHieZnxWPEgC,719,LakNgBAzD4R7CV3tFdfne+HOZ4puqFEIt92SGCL0sUxlDrmiQanA,NweZkm8EIQjpDMUY9XasFGrPicJRb+'_NODIALOGS_')
	return
def AAF5lDV1fcPn2T8(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,EnvI67ZlRzSyjegGuxi2kC9,Dmj48aHieZnxWPEgC,wMCm6g9qFyPT0xpneDUNc2lEhaZY,NiW1bXUTvQyzq4rBJeDaEShIC,kc57B93HrojbDIXVipY):
	if not EnvI67ZlRzSyjegGuxi2kC9: EnvI67ZlRzSyjegGuxi2kC9 = '1'
	if EnvI67ZlRzSyjegGuxi2kC9!='1': uQNUfbZx9yj0F('folder',unXlPWCM9EdmRAsybwT+'صفحة '+str(1),Dmj48aHieZnxWPEgC,wMCm6g9qFyPT0xpneDUNc2lEhaZY,'',str(1),kc57B93HrojbDIXVipY,'',{'folder':nCSJkub4hZM3dH1KpRIUr8a7tBNevE})
	if not NiW1bXUTvQyzq4rBJeDaEShIC: NiW1bXUTvQyzq4rBJeDaEShIC = 0
	boXDRtlaNvcMHPj2zhVrFk6qx = int(NiW1bXUTvQyzq4rBJeDaEShIC/100)+1
	for Iy4bwu3m6qORhDrQSd19HYo8 in range(2,boXDRtlaNvcMHPj2zhVrFk6qx):
		px9VuPiXvHrO1o0hJStC = (Iy4bwu3m6qORhDrQSd19HYo8%10==0 or int(EnvI67ZlRzSyjegGuxi2kC9)-4<Iy4bwu3m6qORhDrQSd19HYo8<int(EnvI67ZlRzSyjegGuxi2kC9)+4)
		piQR1mFk7DuCl2fbW = (px9VuPiXvHrO1o0hJStC and int(EnvI67ZlRzSyjegGuxi2kC9)-40<Iy4bwu3m6qORhDrQSd19HYo8<int(EnvI67ZlRzSyjegGuxi2kC9)+40)
		if str(Iy4bwu3m6qORhDrQSd19HYo8)!=EnvI67ZlRzSyjegGuxi2kC9 and (Iy4bwu3m6qORhDrQSd19HYo8%100==0 or piQR1mFk7DuCl2fbW):
			uQNUfbZx9yj0F('folder',unXlPWCM9EdmRAsybwT+'صفحة '+str(Iy4bwu3m6qORhDrQSd19HYo8),Dmj48aHieZnxWPEgC,wMCm6g9qFyPT0xpneDUNc2lEhaZY,'',str(Iy4bwu3m6qORhDrQSd19HYo8),kc57B93HrojbDIXVipY,'',{'folder':nCSJkub4hZM3dH1KpRIUr8a7tBNevE})
	if str(boXDRtlaNvcMHPj2zhVrFk6qx)!=EnvI67ZlRzSyjegGuxi2kC9: uQNUfbZx9yj0F('folder',unXlPWCM9EdmRAsybwT+'أخر صفحة '+str(boXDRtlaNvcMHPj2zhVrFk6qx),Dmj48aHieZnxWPEgC,wMCm6g9qFyPT0xpneDUNc2lEhaZY,'',str(boXDRtlaNvcMHPj2zhVrFk6qx),kc57B93HrojbDIXVipY,'',{'folder':nCSJkub4hZM3dH1KpRIUr8a7tBNevE})
	return
def keRHziQrENXZW07oBwTm(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,Dmj48aHieZnxWPEgC):
	Hj0zNOTDePKkIviZqFm2oQrVwp4hC3 = QOeNYP5hpm4iI8r.replace('___','_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	return Hj0zNOTDePKkIviZqFm2oQrVwp4hC3
def jLA9FpzV52dQN1Zg(nCSJkub4hZM3dH1KpRIUr8a7tBNevE):
	Hj0zNOTDePKkIviZqFm2oQrVwp4hC3 = keRHziQrENXZW07oBwTm(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,'')
	TTGDytYoQjb9OlFRzK1Ln = lLPSDywfu4axrUhvX9RQEpGtso6H0('center','','','رسالة من المبرمج','جلب ملفات M3U جديدة قد تحتاج عدة دقائق .. هل تريد أن تجلب الملفات الآن ؟!')
	if TTGDytYoQjb9OlFRzK1Ln!=1: return False
	NJntF2jX4Mk(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,False)
	JF2o7kQvA0jNf81Uz9aROT = [0]
	for R2RD7JlOtrWXIFNgVnY0a5iwZp in range(1,isk5jc4tK0QuOhDUX3xRVqBp9vl+1):
		uCWYdR5IwT01V7ac3KPpoG = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.m3u.url_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE+'_'+str(R2RD7JlOtrWXIFNgVnY0a5iwZp))
		if uCWYdR5IwT01V7ac3KPpoG: nnDKsZWdeEAhLf(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,str(R2RD7JlOtrWXIFNgVnY0a5iwZp))
		JF2o7kQvA0jNf81Uz9aROT.append(0)
	for Dmj48aHieZnxWPEgC in aEcb9iDHs8ySolrwe1UYNt035:
		tJ9ZjMiQaUryz,lPvJaHDh851puWit9cYdj2OCSVgm,nFeOHzBNZ1X9alPQ2RyLdEqcMj5,jv0QJ4HLDNKWPAof6dgnZhuM,ssaR0lv4ZU = 0,{},[],[],[]
		for R2RD7JlOtrWXIFNgVnY0a5iwZp in range(1,isk5jc4tK0QuOhDUX3xRVqBp9vl+1):
			sBJIhSno4pzefA = Dmj48aHieZnxWPEgC+'_'+str(R2RD7JlOtrWXIFNgVnY0a5iwZp)
			logFO0JZhCEBYts9yQHW = AsTbx64cCEi1(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,'dict',sBJIhSno4pzefA)
			try:
				xtc7IZNjua = logFO0JZhCEBYts9yQHW['__GROUPS__']
				TVYMxjoz0i1myUWNdAclErwZ6I3PC = logFO0JZhCEBYts9yQHW['__COUNT__']
			except: xtc7IZNjua,TVYMxjoz0i1myUWNdAclErwZ6I3PC = [],'0'
			for JmGSAsetWfkxnF8y3BoQ5XEL in xtc7IZNjua:
				HwuFsvM9jV8yY,qRSNaY0t83hO9ofLEnJuAM1 = JmGSAsetWfkxnF8y3BoQ5XEL
				GHZEu6VbXDjk5sCmohY4M2c1p = logFO0JZhCEBYts9yQHW[HwuFsvM9jV8yY]
				if HwuFsvM9jV8yY not in jv0QJ4HLDNKWPAof6dgnZhuM:
					jv0QJ4HLDNKWPAof6dgnZhuM.append(HwuFsvM9jV8yY)
					ssaR0lv4ZU.append(JmGSAsetWfkxnF8y3BoQ5XEL)
					lPvJaHDh851puWit9cYdj2OCSVgm[HwuFsvM9jV8yY] = []
				lPvJaHDh851puWit9cYdj2OCSVgm[HwuFsvM9jV8yY] += GHZEu6VbXDjk5sCmohY4M2c1p
			ZqlR5BFQ6pm0asCHLUc(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,sBJIhSno4pzefA)
			OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,sBJIhSno4pzefA,'__COUNT__',TVYMxjoz0i1myUWNdAclErwZ6I3PC,NVbfv48oh3M6U)
			JF2o7kQvA0jNf81Uz9aROT[R2RD7JlOtrWXIFNgVnY0a5iwZp] += int(TVYMxjoz0i1myUWNdAclErwZ6I3PC)
		for HwuFsvM9jV8yY in jv0QJ4HLDNKWPAof6dgnZhuM:
			GHZEu6VbXDjk5sCmohY4M2c1p = list(set(lPvJaHDh851puWit9cYdj2OCSVgm[HwuFsvM9jV8yY]))
			if 'SORTED' in Dmj48aHieZnxWPEgC: GHZEu6VbXDjk5sCmohY4M2c1p = sorted(GHZEu6VbXDjk5sCmohY4M2c1p,reverse=False,key=lambda key: key[1].lower())
			tJ9ZjMiQaUryz += len(GHZEu6VbXDjk5sCmohY4M2c1p)
			nFeOHzBNZ1X9alPQ2RyLdEqcMj5.append(GHZEu6VbXDjk5sCmohY4M2c1p)
		OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,Dmj48aHieZnxWPEgC,'__COUNT__',str(tJ9ZjMiQaUryz),NVbfv48oh3M6U)
		OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,Dmj48aHieZnxWPEgC,'__GROUPS__',ssaR0lv4ZU,NVbfv48oh3M6U)
		OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,Dmj48aHieZnxWPEgC,jv0QJ4HLDNKWPAof6dgnZhuM,nFeOHzBNZ1X9alPQ2RyLdEqcMj5,NVbfv48oh3M6U,True)
	EHqZvXQd14iK7nDtwzCBycOFmR = False
	for R2RD7JlOtrWXIFNgVnY0a5iwZp in range(1,isk5jc4tK0QuOhDUX3xRVqBp9vl+1):
		if int(JF2o7kQvA0jNf81Uz9aROT[R2RD7JlOtrWXIFNgVnY0a5iwZp])>0:
			uCWYdR5IwT01V7ac3KPpoG = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.m3u.url_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE+'_'+str(R2RD7JlOtrWXIFNgVnY0a5iwZp))
			OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,'LINK_'+str(R2RD7JlOtrWXIFNgVnY0a5iwZp),'__LINK__',uCWYdR5IwT01V7ac3KPpoG,NVbfv48oh3M6U)
			EHqZvXQd14iK7nDtwzCBycOFmR = True
	OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,'DUMMY','__DUMMY__','DUMMY',NVbfv48oh3M6U)
	if not EHqZvXQd14iK7nDtwzCBycOFmR:
		xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','فشل بسحب ملفات M3U .. أحتمال روابط M3U التي أنت أضفتها للبرنامج غير صحيحة .. علما أن هذه الخدمة تحتاج منك أن تضيف الرابط بنفسك للبرنامج باستخدام قائمة M3U الموجودة في هذا البرنامج')
		return False
	xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','تم جلب ملفات M3U جديدة')
	BZplfFUgwNTyk8ID3(nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin('Container.Refresh')
	return True
def BZplfFUgwNTyk8ID3(nCSJkub4hZM3dH1KpRIUr8a7tBNevE):
	Hj0zNOTDePKkIviZqFm2oQrVwp4hC3 = keRHziQrENXZW07oBwTm(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,'')
	if not OSDp6mYAsavhl0boq(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,True): return
	for R2RD7JlOtrWXIFNgVnY0a5iwZp in range(1,isk5jc4tK0QuOhDUX3xRVqBp9vl+1):
		uCWYdR5IwT01V7ac3KPpoG = AsTbx64cCEi1(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3,'str','LINK_'+str(R2RD7JlOtrWXIFNgVnY0a5iwZp),'__LINK__')
		if uCWYdR5IwT01V7ac3KPpoG: xyBvTnNeHrX6b0IuEQKfL = ooUBXG6Mx58tIE3SiC1VT2ef(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,str(R2RD7JlOtrWXIFNgVnY0a5iwZp))
	ooUBXG6Mx58tIE3SiC1VT2ef(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,'')
	return
def NJntF2jX4Mk(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,Na1U7ZMp3yQbhuOdcwS):
	if Na1U7ZMp3yQbhuOdcwS:
		TTGDytYoQjb9OlFRzK1Ln = lLPSDywfu4axrUhvX9RQEpGtso6H0('center','','','مسح ملفات ـM3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if TTGDytYoQjb9OlFRzK1Ln!=1: return
	Hj0zNOTDePKkIviZqFm2oQrVwp4hC3 = keRHziQrENXZW07oBwTm(nCSJkub4hZM3dH1KpRIUr8a7tBNevE,'')
	try: k1t0JLRsCQ.remove(Hj0zNOTDePKkIviZqFm2oQrVwp4hC3)
	except: pass
	for R2RD7JlOtrWXIFNgVnY0a5iwZp in range(1,isk5jc4tK0QuOhDUX3xRVqBp9vl+1):
		gn7mjNUzap = ttyjfLqbA1VJNOu.replace('___','_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE+'_'+str(R2RD7JlOtrWXIFNgVnY0a5iwZp))
		AzE64iJPMfY2 = k1t0JLRsCQ.path.join(OxWkR7Eu9Pm3IAvTp0q,gn7mjNUzap)
		try: k1t0JLRsCQ.remove(AzE64iJPMfY2)
		except: pass
	ZqlR5BFQ6pm0asCHLUc(bpNSygerL10j4IOkEfuVw,'SECTIONS_M3U','SECTIONS_M3U_'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE)
	ZqlR5BFQ6pm0asCHLUc(bpNSygerL10j4IOkEfuVw,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	if Na1U7ZMp3yQbhuOdcwS:
		xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
		bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin('Container.Refresh')
	return
def Q6PTy5fRhWxcn(nCSJkub4hZM3dH1KpRIUr8a7tBNevE):
	uSxj0QfnGUrARgqkZ = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.language.provider')
	m7gcw3bAeD4 = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting('av.language.code')
	ZqlR5BFQ6pm0asCHLUc(bpNSygerL10j4IOkEfuVw,'MENUS_CACHE_'+uSxj0QfnGUrARgqkZ+'_'+m7gcw3bAeD4,'%_MU'+nCSJkub4hZM3dH1KpRIUr8a7tBNevE+'_%')
	return
vcGsRPLrH1T3d = {
		 'AF':'Afghanistan'
		,'AL':'Albania'
		,'DZ':'Algeria'
		,'AS':'American Samoa'
		,'AD':'Andorra'
		,'AO':'Angola'
		,'AI':'Anguilla'
		,'AQ':'Antarctica'
		,'AG':'Antigua and Barbuda'
		,'AR':'Argentina'
		,'AM':'Armenia'
		,'AW':'Aruba'
		,'AU':'Australia'
		,'AT':'Austria'
		,'AZ':'Azerbaijan'
		,'BS':'Bahamas'
		,'BH':'Bahrain'
		,'BD':'Bangladesh'
		,'BB':'Barbados'
		,'BY':'Belarus'
		,'BE':'Belgium'
		,'BZ':'Belize'
		,'BJ':'Benin'
		,'BM':'Bermuda'
		,'BT':'Bhutan'
		,'BO':'Bolivia'
		,'BQ':'Bonaire'
		,'BA':'Bosnia and Herzegovina'
		,'BW':'Botswana'
		,'BV':'Bouvet Island'
		,'BR':'Brazil'
		,'IO':'British Indian Ocean Territory'
		,'VG':'British Virgin Islands'
		,'BN':'Brunei'
		,'BG':'Bulgaria'
		,'BF':'Burkina Faso'
		,'BI':'Burundi'
		,'KH':'Cambodia'
		,'CM':'Cameroon'
		,'CA':'Canada'
		,'CV':'Cape Verde'
		,'KY':'Cayman Islands'
		,'CF':'Central African Republic'
		,'TD':'Chad'
		,'CL':'Chile'
		,'CN':'China'
		,'CX':'Christmas Island'
		,'CC':'Cocos (Keeling) Islands'
		,'CO':'Colombia'
		,'KM':'Comoros'
		,'CK':'Cook Islands'
		,'CR':'Costa Rica'
		,'HR':'Croatia'
		,'CU':'Cuba'
		,'CW':'Curacao'
		,'CY':'Cyprus'
		,'CZ':'Czech Republic'
		,'CD':'Democratic Republic of the Congo'
		,'DK':'Denmark'
		,'DJ':'Djibouti'
		,'DM':'Dominica'
		,'DO':'Dominican Republic'
		,'TL':'East Timor'
		,'EC':'Ecuador'
		,'EG':'Egypt'
		,'SV':'El Salvador'
		,'GQ':'Equatorial Guinea'
		,'ER':'Eritrea'
		,'EE':'Estonia'
		,'ET':'Ethiopia'
		,'FK':'Falkland Islands'
		,'FO':'Faroe Islands'
		,'FJ':'Fiji'
		,'FI':'Finland'
		,'FR':'France'
		,'GF':'French Guiana'
		,'PF':'French Polynesia'
		,'TF':'French Southern Territories'
		,'GA':'Gabon'
		,'GM':'Gambia'
		,'GE':'Georgia'
		,'DE':'Germany'
		,'GH':'Ghana'
		,'GI':'Gibraltar'
		,'GR':'Greece'
		,'GL':'Greenland'
		,'GD':'Grenada'
		,'GP':'Guadeloupe'
		,'GU':'Guam'
		,'GT':'Guatemala'
		,'GG':'Guernsey'
		,'GN':'Guinea'
		,'GW':'Guinea-Bissau'
		,'GY':'Guyana'
		,'HT':'Haiti'
		,'HM':'Heard Island and McDonald Islands'
		,'HN':'Honduras'
		,'HK':'Hong Kong'
		,'HU':'Hungary'
		,'IS':'Iceland'
		,'IN':'India'
		,'ID':'Indonesia'
		,'IR':'Iran'
		,'IQ':'Iraq'
		,'IE':'Ireland'
		,'IM':'Isle of Man'
		,'IL':'Israel'
		,'IT':'Italy'
		,'CI':'Ivory Coast'
		,'JM':'Jamaica'
		,'JP':'Japan'
		,'JE':'Jersey'
		,'JO':'Jordan'
		,'KZ':'Kazakhstan'
		,'KE':'Kenya'
		,'KI':'Kiribati'
		,'XK':'Kosovo'
		,'KW':'Kuwait'
		,'KG':'Kyrgyzstan'
		,'LA':'Laos'
		,'LV':'Latvia'
		,'LB':'Lebanon'
		,'LS':'Lesotho'
		,'LR':'Liberia'
		,'LY':'Libya'
		,'LI':'Liechtenstein'
		,'LT':'Lithuania'
		,'LU':'Luxembourg'
		,'MO':'Macao'
		,'MG':'Madagascar'
		,'MW':'Malawi'
		,'MY':'Malaysia'
		,'MV':'Maldives'
		,'ML':'Mali'
		,'MT':'Malta'
		,'MH':'Marshall Islands'
		,'MQ':'Martinique'
		,'MR':'Mauritania'
		,'MU':'Mauritius'
		,'YT':'Mayotte'
		,'MX':'Mexico'
		,'FM':'Micronesia'
		,'MD':'Moldova'
		,'MC':'Monaco'
		,'MN':'Mongolia'
		,'ME':'Montenegro'
		,'MS':'Montserrat'
		,'MA':'Morocco'
		,'MZ':'Mozambique'
		,'MM':'Myanmar (Burma)'
		,'NA':'Namibia'
		,'NR':'Nauru'
		,'NP':'Nepal'
		,'NL':'Netherlands'
		,'NC':'New Caledonia'
		,'NZ':'New Zealand'
		,'NI':'Nicaragua'
		,'NE':'Niger'
		,'NG':'Nigeria'
		,'NU':'Niue'
		,'NF':'Norfolk Island'
		,'KP':'North Korea'
		,'MK':'North Macedonia'
		,'MP':'Northern Mariana Islands'
		,'NO':'Norway'
		,'OM':'Oman'
		,'PK':'Pakistan'
		,'PW':'Palau'
		,'PS':'Palestine'
		,'PA':'Panama'
		,'PG':'Papua New Guinea'
		,'PY':'Paraguay'
		,'PE':'Peru'
		,'PH':'Philippines'
		,'PN':'Pitcairn Islands'
		,'PL':'Poland'
		,'PT':'Portugal'
		,'PR':'Puerto Rico'
		,'QA':'Qatar'
		,'CG':'Republic of the Congo'
		,'RO':'Romania'
		,'RU':'Russia'
		,'RW':'Rwanda'
		,'RE':'Réunion'
		,'BL':'Saint Barthélemy'
		,'SH':'Saint Helena'
		,'KN':'Saint Kitts and Nevis'
		,'LC':'Saint Lucia'
		,'MF':'Saint Martin'
		,'PM':'Saint Pierre and Miquelon'
		,'VC':'Saint Vincent and the Grenadines'
		,'WS':'Samoa'
		,'SM':'San Marino'
		,'SA':'Saudi Arabia'
		,'SN':'Senegal'
		,'RS':'Serbia'
		,'SC':'Seychelles'
		,'SL':'Sierra Leone'
		,'SG':'Singapore'
		,'SX':'Sint Maarten'
		,'SK':'Slovakia'
		,'SI':'Slovenia'
		,'SB':'Solomon Islands'
		,'SO':'Somalia'
		,'ZA':'South Africa'
		,'GS':'South Georgia and the South Sandwich Islands'
		,'KR':'South Korea'
		,'SS':'South Sudan'
		,'ES':'Spain'
		,'LK':'Sri Lanka'
		,'SD':'Sudan'
		,'SR':'Suriname'
		,'SJ':'Svalbard and Jan Mayen'
		,'SZ':'Swaziland'
		,'SE':'Sweden'
		,'CH':'Switzerland'
		,'SY':'Syria'
		,'ST':'São Tomé and Príncipe'
		,'TW':'Taiwan'
		,'TJ':'Tajikistan'
		,'TZ':'Tanzania'
		,'TH':'Thailand'
		,'TG':'Togo'
		,'TK':'Tokelau'
		,'TO':'Tonga'
		,'TT':'Trinidad and Tobago'
		,'TN':'Tunisia'
		,'TR':'Turkey'
		,'TM':'Turkmenistan'
		,'TC':'Turks and Caicos Islands'
		,'TV':'Tuvalu'
		,'UM':'U.S. Minor Outlying Islands'
		,'VI':'U.S. Virgin Islands'
		,'UG':'Uganda'
		,'UA':'Ukraine'
		,'AE':'United Arab Emirates'
		,'UK':'United Kingdom'
		,'US':'United States'
		,'UY':'Uruguay'
		,'UZ':'Uzbekistan'
		,'VU':'Vanuatu'
		,'VA':'Vatican City'
		,'VE':'Venezuela'
		,'VN':'Vietnam'
		,'WF':'Wallis and Futuna'
		,'EH':'Western Sahara'
		,'YE':'Yemen'
		,'ZM':'Zambia'
		,'ZW':'Zimbabwe'
		,'AX':'Åland'
		}
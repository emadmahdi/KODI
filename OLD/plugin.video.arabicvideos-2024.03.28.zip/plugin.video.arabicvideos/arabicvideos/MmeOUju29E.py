# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'ARABSEED'
headers = {'User-Agent':ncgQBtRa7qT2GJ3Wpd()}
tiCRYyX1bWd40Ir3PafQu = '_ARS_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==250: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==251: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,text)
	elif mode==252: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==253: vS7JufTVsBxw52 = GA2KIlbOsoYtxpkDF71(url)
	elif mode==254: vS7JufTVsBxw52 = WYxFZIrRp6b(url,'CATEGORIES___'+text)
	elif mode==255: vS7JufTVsBxw52 = WYxFZIrRp6b(url,'FILTERS___'+text)
	elif mode==256: vS7JufTVsBxw52 = GQsDp6PWFHRE1ki2odqrwjB0ISTLh(url,text)
	elif mode==259: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',yONJxHER9BIDPpTV4YsWmc0n+'/main','',headers,'','','ARABSEED-MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',259,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فلتر محدد',yONJxHER9BIDPpTV4YsWmc0n+'/category/اخرى',254)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فلتر كامل',yONJxHER9BIDPpTV4YsWmc0n+'/category/اخرى',255)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'المميزة',yONJxHER9BIDPpTV4YsWmc0n+'/main',251,'','','featured_main')
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'جديد الأفلام',yONJxHER9BIDPpTV4YsWmc0n+'/main',251,'','','new_movies')
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'جديد الحلقات',yONJxHER9BIDPpTV4YsWmc0n+'/main',251,'','','new_episodes')
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'المضاف حديثاً',yONJxHER9BIDPpTV4YsWmc0n+'/latest',251,'','','lastest')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	RfTOHSzgpA = u5h2Rckvw1E.findall('class="MenuHeader"(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	CyEMW1Sh3GtsbRUzN = RfTOHSzgpA[0]
	EbnzqW0GvY2dNMBpshU6fugi = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)<',CyEMW1Sh3GtsbRUzN,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,title in EbnzqW0GvY2dNMBpshU6fugi:
		title = uTUNPkVwCMKiD5gHLaj(title)
		if title not in WLI5tgXRbUPNGJCSVz0vKjBDei3 and title!='':
			if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,256)
	return oo9SgGkiDbs3HRn7z8
def GQsDp6PWFHRE1ki2odqrwjB0ISTLh(url,type):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'',headers,'','','ARABSEED-SUBMENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	if 'class="SliderInSection' in oo9SgGkiDbs3HRn7z8: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الأكثر مشاهدة',url,251,'','','most')
	if 'class="MainSlides' in oo9SgGkiDbs3HRn7z8: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'المميزة',url,251,'','','featured')
	if 'class="LinksList' in oo9SgGkiDbs3HRn7z8:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="LinksList(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			if len(cWafzb4HoG1Em3Jwxu6C7vZsVi)>1 and type=='new_episodes': lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[1]
			items = u5h2Rckvw1E.findall('href="(.*?)"(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,title in items:
				cMpjL2oavyVwKHBPn8EdhYqxSUk = u5h2Rckvw1E.findall('</i>(.*?)<span>(.*?)<',title,u5h2Rckvw1E.DOTALL)
				try: OlDEqB68KZdI5fsipUJzuavcn = cMpjL2oavyVwKHBPn8EdhYqxSUk[0][0]
				except: OlDEqB68KZdI5fsipUJzuavcn = ''
				try: wCcUeBxEHG0YR = cMpjL2oavyVwKHBPn8EdhYqxSUk[0][1]
				except: wCcUeBxEHG0YR = ''
				cMpjL2oavyVwKHBPn8EdhYqxSUk = OlDEqB68KZdI5fsipUJzuavcn+wCcUeBxEHG0YR
				cMpjL2oavyVwKHBPn8EdhYqxSUk = cMpjL2oavyVwKHBPn8EdhYqxSUk.replace('\n','')
				if '<strong>' in title:
					qOECRifjx9rLg0MDk = u5h2Rckvw1E.findall('</i>(.*?)<',title,u5h2Rckvw1E.DOTALL)
					if qOECRifjx9rLg0MDk: cMpjL2oavyVwKHBPn8EdhYqxSUk = qOECRifjx9rLg0MDk[0]
				if not cMpjL2oavyVwKHBPn8EdhYqxSUk:
					qOECRifjx9rLg0MDk = u5h2Rckvw1E.findall('alt="(.*?)"',title,u5h2Rckvw1E.DOTALL)
					if qOECRifjx9rLg0MDk: cMpjL2oavyVwKHBPn8EdhYqxSUk = qOECRifjx9rLg0MDk[0]
				if cMpjL2oavyVwKHBPn8EdhYqxSUk:
					if 'key=' in ekTrZlFMu0Kf5QztEnhAs: type = ekTrZlFMu0Kf5QztEnhAs.split('key=')[1]
					else: type = 'newest'
					cMpjL2oavyVwKHBPn8EdhYqxSUk = cMpjL2oavyVwKHBPn8EdhYqxSUk.strip(' ')
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+cMpjL2oavyVwKHBPn8EdhYqxSUk,ekTrZlFMu0Kf5QztEnhAs,251,'','',type)
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,type):
	TbXq0ongLPZszic6rHaI5dG8AWCh,data,items = 'GET','',[]
	if type=='filters':
		if '?' in url:
			QGFHpjRbqDSnIaL4y3CW,XfOb4VIcPY = 'POST',{}
			gANn35esloKUydOipfSMC6RD2,hiBasuLtw8FnNYfO03IRxoHcWU = url.split('?')
			dvulfaW1UAFZ2JSrPxOYyeMHqn = hiBasuLtw8FnNYfO03IRxoHcWU.split('&')
			for mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ in dvulfaW1UAFZ2JSrPxOYyeMHqn:
				key,c2eEflztvIX = mOPcjeMYSoi4blk3tQxyzNB7UJfnXZ.split('=')
				XfOb4VIcPY[key] = c2eEflztvIX
			if dvulfaW1UAFZ2JSrPxOYyeMHqn: TbXq0ongLPZszic6rHaI5dG8AWCh,url,data = QGFHpjRbqDSnIaL4y3CW,gANn35esloKUydOipfSMC6RD2,XfOb4VIcPY
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,TbXq0ongLPZszic6rHaI5dG8AWCh,url,data,headers,'','','ARABSEED-TITLES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	if type=='filters': cWafzb4HoG1Em3Jwxu6C7vZsVi = [oo9SgGkiDbs3HRn7z8]
	elif 'featured' in type: cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="MainSlides(.*?)class="LinksList',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	elif type=='new_movies': cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('جديد الافلام.*?class="SliderInSection"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	elif type=='new_episodes': cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('جديد الحلقات.*?class="SliderInSection"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	elif type=='most': cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="SliderInSection(.*?)class="LinksList',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	else: cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="Blocks-UL"(.*?)class="AboElSeed"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if 'featured' in type:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		ZmWIcGhdFzNivK29EuB70DVC5Q = u5h2Rckvw1E.findall('href="(.*?)" title="(.*?)".*?data-lazy.*? (src|data-image)="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if ZmWIcGhdFzNivK29EuB70DVC5Q:
			EaBeVhOsHYg8wub,hVby8e3aQkFfuE,Oc0LoABmIp4nV6NsaDF,uix8pDMdNJZ6VFQzcOPWX = zip(*ZmWIcGhdFzNivK29EuB70DVC5Q)
			items = zip(EaBeVhOsHYg8wub,uix8pDMdNJZ6VFQzcOPWX,hVby8e3aQkFfuE)
	else:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('LoadingArea.*? href="(.*?)".*? data-\w{3,5}="(.*?)".*? alt="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	yn8DkpE5etF3WiUmfSO = []
	for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
		if 'WWE' in title: continue
		title = uTUNPkVwCMKiD5gHLaj(title)
		if 'الحلقة' in title:
			zAjwuoRY98mXN6xvE = u5h2Rckvw1E.findall('(.*?) الحلقة \d+',title,u5h2Rckvw1E.DOTALL)
			if zAjwuoRY98mXN6xvE:
				title = '_MOD_' + zAjwuoRY98mXN6xvE[0]
				if title not in yn8DkpE5etF3WiUmfSO:
					yn8DkpE5etF3WiUmfSO.append(title)
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,253,pGjsvdyHfM)
			else: uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,252,pGjsvdyHfM)
		elif '/selary/' in ekTrZlFMu0Kf5QztEnhAs or 'مسلسل' in title:
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,253,pGjsvdyHfM)
		else:
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,252,pGjsvdyHfM)
	if type in ['newest','best','most']:
		items = u5h2Rckvw1E.findall('page-numbers" href="(.*?)">(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
			ekTrZlFMu0Kf5QztEnhAs = uTUNPkVwCMKiD5gHLaj(ekTrZlFMu0Kf5QztEnhAs)
			title = uTUNPkVwCMKiD5gHLaj(title)
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+title,ekTrZlFMu0Kf5QztEnhAs,251,'','',type)
	return
def GA2KIlbOsoYtxpkDF71(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'',headers,'','','ARABSEED-EPISODES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	oo9SgGkiDbs3HRn7z8 = oo9SgGkiDbs3HRn7z8[10000:]
	items = u5h2Rckvw1E.findall('data-src="(.*?)".*?alt="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not items: return
	pGjsvdyHfM,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(' ')
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(' ')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="ContainerEpisodesList"(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?<em>(.*?)</em>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,zAjwuoRY98mXN6xvE in items:
			title = name+' - الحلقة رقم '+zAjwuoRY98mXN6xvE
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,252,pGjsvdyHfM)
	else: uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+'ملف التشغيل',url,252,pGjsvdyHfM)
	return
def rxHADuJY36o(title,ekTrZlFMu0Kf5QztEnhAs):
	cMpjL2oavyVwKHBPn8EdhYqxSUk = u5h2Rckvw1E.findall('[a-zA-Z-]+',title,u5h2Rckvw1E.DOTALL)
	if cMpjL2oavyVwKHBPn8EdhYqxSUk: title = cMpjL2oavyVwKHBPn8EdhYqxSUk[0]
	else: title = title+' '+hmcFWJUgiAuGk(ekTrZlFMu0Kf5QztEnhAs,'name')
	title = title.replace('عرب سيد','').replace('مباشر','').replace('مشاهدة','')
	title = title.replace('ٍ','')
	title = title.replace('  ',' ').replace('  ',' ')
	return title
def N5AOlmb8u1y4FHxvJXU(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',url,'',headers,'','','ARABSEED-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	gANn35esloKUydOipfSMC6RD2 = RoQL91PphqCJg4W0e6Fnsl.url
	NDwLctrHpYz3JBP = hmcFWJUgiAuGk(gANn35esloKUydOipfSMC6RD2,'url')
	headers['Referer'] = NDwLctrHpYz3JBP+'/'
	jCdtcqaFQ4p,vduAMOjFeso,EaBeVhOsHYg8wub = '','',[]
	c9Rv15BuJOnzxWhSKja = u5h2Rckvw1E.findall('class="WatchButtons".*?href="(.*?)" class="(watch.*?)".*?href="(.*?)" class="(download.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if c9Rv15BuJOnzxWhSKja: jCdtcqaFQ4p,v94eWpjgbPaZKECiA7J,vduAMOjFeso,v6YLr90gxdTVfyG83J1XAzjiF = c9Rv15BuJOnzxWhSKja[0]
	else:
		c9Rv15BuJOnzxWhSKja = u5h2Rckvw1E.findall('class="WatchButtons".*?href="(.*?)" class="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if c9Rv15BuJOnzxWhSKja:
			ekTrZlFMu0Kf5QztEnhAs,v94eWpjgbPaZKECiA7J = c9Rv15BuJOnzxWhSKja[0]
			if 'watch' in v94eWpjgbPaZKECiA7J: jCdtcqaFQ4p = ekTrZlFMu0Kf5QztEnhAs
			else: vduAMOjFeso = ekTrZlFMu0Kf5QztEnhAs
	if jCdtcqaFQ4p:
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',jCdtcqaFQ4p,'',headers,'','','ARABSEED-PLAY-2nd')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="WatcherArea"(.*?</ul>)',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			VZdjIie6Mx = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			VZdjIie6Mx = VZdjIie6Mx.replace('</ul>','<h3>')
			VZdjIie6Mx = VZdjIie6Mx.replace('<h3>','<h3><h3>')
			ppZ9muD1GkPnFRX52jxBUIy = u5h2Rckvw1E.findall('<h3>.*?(\d+)(.*?)<h3>',VZdjIie6Mx,u5h2Rckvw1E.DOTALL)
			if not ppZ9muD1GkPnFRX52jxBUIy: ppZ9muD1GkPnFRX52jxBUIy = [('',VZdjIie6Mx)]
			for ohAHUqdbWFi8D1L4Xwzus0f3RYv,lmO2YJGr6tCV in ppZ9muD1GkPnFRX52jxBUIy:
				if ohAHUqdbWFi8D1L4Xwzus0f3RYv: ohAHUqdbWFi8D1L4Xwzus0f3RYv = '____'+ohAHUqdbWFi8D1L4Xwzus0f3RYv
				items = u5h2Rckvw1E.findall('data-link="(.*?)".*?<span>(.*?)</span>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
				for ekTrZlFMu0Kf5QztEnhAs,name in items:
					if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = 'http:'+ekTrZlFMu0Kf5QztEnhAs
					ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+name+'__watch'+ohAHUqdbWFi8D1L4Xwzus0f3RYv
					EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
		lQUf3AY258LeWch = u5h2Rckvw1E.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if not lQUf3AY258LeWch: lQUf3AY258LeWch = u5h2Rckvw1E.findall('class="containerIframe".*? SRC="(.*?)".*? HEIGHT="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if lQUf3AY258LeWch:
			ekTrZlFMu0Kf5QztEnhAs,ohAHUqdbWFi8D1L4Xwzus0f3RYv = lQUf3AY258LeWch[0]
			name = hmcFWJUgiAuGk(ekTrZlFMu0Kf5QztEnhAs,'name')
			if '%' in ohAHUqdbWFi8D1L4Xwzus0f3RYv: ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+name+'__embed__'
			else: ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+name+'__embed____'+ohAHUqdbWFi8D1L4Xwzus0f3RYv
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	if vduAMOjFeso:
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',vduAMOjFeso,'',headers,'','','ARABSEED-PLAY-3rd')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="DownloadArea"(.*?)function',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,title,ohAHUqdbWFi8D1L4Xwzus0f3RYv in items:
				if not ekTrZlFMu0Kf5QztEnhAs: continue
				if 'reviewstation' in ekTrZlFMu0Kf5QztEnhAs: continue
				ekTrZlFMu0Kf5QztEnhAs = P2o6ZDHeW790pSQqucvnxzILVUX(ekTrZlFMu0Kf5QztEnhAs)
				ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+title+'__download____'+ohAHUqdbWFi8D1L4Xwzus0f3RYv
				EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	R68abMkpcvig0QtoB = str(EaBeVhOsHYg8wub)
	J6cUpuMRDSr = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(c2eEflztvIX in R68abMkpcvig0QtoB for c2eEflztvIX in J6cUpuMRDSr):
		xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(EaBeVhOsHYg8wub,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if not search: search = FBrXsYeCEp3()
	if not search: return
	search = search.replace(' ','+')
	url = yONJxHER9BIDPpTV4YsWmc0n+'/find/?find='+search
	ll0a2AwztChcpsDUMi4rGW3b61XZES(url,'search')
	return
def WYxFZIrRp6b(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter=='': lvUP2GeNjyVOHKJxcBoun3Z,MoELTBDgQeaJrl0zYUmKCH = '',''
	else: lvUP2GeNjyVOHKJxcBoun3Z,MoELTBDgQeaJrl0zYUmKCH = filter.split('___')
	if type=='CATEGORIES':
		if dz05Ioe7UxDagwylQqtkVjBi[0]+'==' not in lvUP2GeNjyVOHKJxcBoun3Z: oPrhaMp7AqmNnRjlXGI = dz05Ioe7UxDagwylQqtkVjBi[0]
		for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(len(dz05Ioe7UxDagwylQqtkVjBi[0:-1])):
			if dz05Ioe7UxDagwylQqtkVjBi[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE]+'==' in lvUP2GeNjyVOHKJxcBoun3Z: oPrhaMp7AqmNnRjlXGI = dz05Ioe7UxDagwylQqtkVjBi[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE+1]
		WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&&'+oPrhaMp7AqmNnRjlXGI+'==0'
		z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&&'+oPrhaMp7AqmNnRjlXGI+'==0'
		bIYSyA3BD1o4 = WGiMcqkRetEJVrSI.strip('&&')+'___'+z3wGSEWqVy1Qh5N.strip('&&')
		TBFfiRI52ZmKwO1JLSD = mltWBSPJz5H4VRdCAa1(MoELTBDgQeaJrl0zYUmKCH,'modified_filters')
		gANn35esloKUydOipfSMC6RD2 = url+'//getposts??'+TBFfiRI52ZmKwO1JLSD
	elif type=='FILTERS':
		lv2uANOtVxE8RTa7bYHqLog1Bd = mltWBSPJz5H4VRdCAa1(lvUP2GeNjyVOHKJxcBoun3Z,'modified_values')
		lv2uANOtVxE8RTa7bYHqLog1Bd = P2o6ZDHeW790pSQqucvnxzILVUX(lv2uANOtVxE8RTa7bYHqLog1Bd)
		if MoELTBDgQeaJrl0zYUmKCH!='': MoELTBDgQeaJrl0zYUmKCH = mltWBSPJz5H4VRdCAa1(MoELTBDgQeaJrl0zYUmKCH,'modified_filters')
		if MoELTBDgQeaJrl0zYUmKCH=='': gANn35esloKUydOipfSMC6RD2 = url
		else: gANn35esloKUydOipfSMC6RD2 = url+'//getposts??'+MoELTBDgQeaJrl0zYUmKCH
		EvwpgrXHuA7nMDUz9RyGhaTOQJWZ = sw6W1OIUQSJLFHbl(gANn35esloKUydOipfSMC6RD2)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'أظهار قائمة الفيديو التي تم اختيارها ',EvwpgrXHuA7nMDUz9RyGhaTOQJWZ,251,'','','filters')
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+' [[   '+lv2uANOtVxE8RTa7bYHqLog1Bd+'   ]]',EvwpgrXHuA7nMDUz9RyGhaTOQJWZ,251,'','','filters')
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'POST',url,'',headers,'','','ARABSEED-FILTERS_MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	SRcZx0FVyl = u5h2Rckvw1E.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	Iwv03CrpDHVz = u5h2Rckvw1E.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	cGdHRiwvptVXQlzE8ZUgB0aJo9x = SRcZx0FVyl+Iwv03CrpDHVz
	dict = {}
	for name,Uiy0XwPusDg4vAFc35oYdfGnOrV,lmO2YJGr6tCV in cGdHRiwvptVXQlzE8ZUgB0aJo9x:
		items = u5h2Rckvw1E.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			EbnzqW0GvY2dNMBpshU6fugi = u5h2Rckvw1E.findall('data-rate="(.*?)".*?<em>(.*?)</em>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			items = []
			for q1rVywkMcKftIioS43LY,c2eEflztvIX in EbnzqW0GvY2dNMBpshU6fugi: items.append([q1rVywkMcKftIioS43LY,'',c2eEflztvIX])
			Uiy0XwPusDg4vAFc35oYdfGnOrV = 'rate'
			name = 'التقييم'
		else: Uiy0XwPusDg4vAFc35oYdfGnOrV = items[0][1]
		if '==' not in gANn35esloKUydOipfSMC6RD2: gANn35esloKUydOipfSMC6RD2 = url
		if type=='CATEGORIES':
			if oPrhaMp7AqmNnRjlXGI!=Uiy0XwPusDg4vAFc35oYdfGnOrV: continue
			elif len(items)<=1:
				if Uiy0XwPusDg4vAFc35oYdfGnOrV==dz05Ioe7UxDagwylQqtkVjBi[-1]: ll0a2AwztChcpsDUMi4rGW3b61XZES(gANn35esloKUydOipfSMC6RD2)
				else: WYxFZIrRp6b(gANn35esloKUydOipfSMC6RD2,'CATEGORIES___'+bIYSyA3BD1o4)
				return
			else:
				EvwpgrXHuA7nMDUz9RyGhaTOQJWZ = sw6W1OIUQSJLFHbl(gANn35esloKUydOipfSMC6RD2)
				if Uiy0XwPusDg4vAFc35oYdfGnOrV==dz05Ioe7UxDagwylQqtkVjBi[-1]: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع ',EvwpgrXHuA7nMDUz9RyGhaTOQJWZ,251,'','','filters')
				else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع ',gANn35esloKUydOipfSMC6RD2,254,'','',bIYSyA3BD1o4)
		elif type=='FILTERS':
			WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'==0'
			z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'==0'
			bIYSyA3BD1o4 = WGiMcqkRetEJVrSI+'___'+z3wGSEWqVy1Qh5N
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع :'+name,gANn35esloKUydOipfSMC6RD2,255,'','',bIYSyA3BD1o4)
		dict[Uiy0XwPusDg4vAFc35oYdfGnOrV] = {}
		for q1rVywkMcKftIioS43LY,qBdHbiaM0lmk5GNsfrXCIYyugR,c2eEflztvIX in items:
			if q1rVywkMcKftIioS43LY in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
			if 'الكل' in q1rVywkMcKftIioS43LY: continue
			q1rVywkMcKftIioS43LY = uTUNPkVwCMKiD5gHLaj(q1rVywkMcKftIioS43LY)
			OzY3XIhgiZJsGHMkKmSj,cMpjL2oavyVwKHBPn8EdhYqxSUk = q1rVywkMcKftIioS43LY,q1rVywkMcKftIioS43LY
			cMpjL2oavyVwKHBPn8EdhYqxSUk = name+': '+OzY3XIhgiZJsGHMkKmSj
			dict[Uiy0XwPusDg4vAFc35oYdfGnOrV][c2eEflztvIX] = cMpjL2oavyVwKHBPn8EdhYqxSUk
			WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'=='+OzY3XIhgiZJsGHMkKmSj
			z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'=='+c2eEflztvIX
			eoaO40TC7VF1tEuwjQp2x = WGiMcqkRetEJVrSI+'___'+z3wGSEWqVy1Qh5N
			if type=='FILTERS':
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+cMpjL2oavyVwKHBPn8EdhYqxSUk,url,255,'','',eoaO40TC7VF1tEuwjQp2x)
			elif type=='CATEGORIES' and dz05Ioe7UxDagwylQqtkVjBi[-2]+'==' in lvUP2GeNjyVOHKJxcBoun3Z:
				TBFfiRI52ZmKwO1JLSD = mltWBSPJz5H4VRdCAa1(z3wGSEWqVy1Qh5N,'modified_filters')
				UcmHDPlLWaSf = url+'//getposts??'+TBFfiRI52ZmKwO1JLSD
				EvwpgrXHuA7nMDUz9RyGhaTOQJWZ = sw6W1OIUQSJLFHbl(UcmHDPlLWaSf)
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+cMpjL2oavyVwKHBPn8EdhYqxSUk,EvwpgrXHuA7nMDUz9RyGhaTOQJWZ,251,'','','filters')
			else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+cMpjL2oavyVwKHBPn8EdhYqxSUk,url,254,'','',eoaO40TC7VF1tEuwjQp2x)
	return
dz05Ioe7UxDagwylQqtkVjBi = ['category','country','release-year']
fXdYgek4Pnc = ['category','country','genre','release-year','language','quality','rate']
def sw6W1OIUQSJLFHbl(url):
	pILDtRKn7j = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',pILDtRKn7j)
	url = url.replace('/category/اخرى','')
	if pILDtRKn7j not in url: url = url+pILDtRKn7j
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def mltWBSPJz5H4VRdCAa1(cGYIMSHDj85d3f4ZW2t0bnNkKP,mode):
	cGYIMSHDj85d3f4ZW2t0bnNkKP = cGYIMSHDj85d3f4ZW2t0bnNkKP.strip('&&')
	OXjBliFSwIQCmg47,LL3oamJbwkYcNDrH5 = {},''
	if '==' in cGYIMSHDj85d3f4ZW2t0bnNkKP:
		items = cGYIMSHDj85d3f4ZW2t0bnNkKP.split('&&')
		for TMaJdc0xOFKNf in items:
			b1EWu6sYaRk0FXUx8HVvNBQort43,c2eEflztvIX = TMaJdc0xOFKNf.split('==')
			OXjBliFSwIQCmg47[b1EWu6sYaRk0FXUx8HVvNBQort43] = c2eEflztvIX
	for key in fXdYgek4Pnc:
		if key in list(OXjBliFSwIQCmg47.keys()): c2eEflztvIX = OXjBliFSwIQCmg47[key]
		else: c2eEflztvIX = '0'
		if '%' not in c2eEflztvIX: c2eEflztvIX = QQXTVNve6DMHBp4scG170kR2lWY(c2eEflztvIX)
		if mode=='modified_values' and c2eEflztvIX!='0': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+' + '+c2eEflztvIX
		elif mode=='modified_filters' and c2eEflztvIX!='0': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+'&&'+key+'=='+c2eEflztvIX
		elif mode=='all': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+'&&'+key+'=='+c2eEflztvIX
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.strip(' + ')
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.strip('&&')
	return LL3oamJbwkYcNDrH5
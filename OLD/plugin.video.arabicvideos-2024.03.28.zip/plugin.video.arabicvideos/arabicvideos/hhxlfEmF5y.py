# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'FASELHD2'
headers = {'User-Agent':''}
tiCRYyX1bWd40Ir3PafQu = '_FH2_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['wwe']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==590: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==591: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,text)
	elif mode==592: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==593: vS7JufTVsBxw52 = ZN3Wh7HABLwRIkFmyEd1Jq(url,text)
	elif mode==599: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	jGX4sfdrWaeZpA1VyvTK = yONJxHER9BIDPpTV4YsWmc0n
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',jGX4sfdrWaeZpA1VyvTK,'','','','','FASELHD2-MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع',jGX4sfdrWaeZpA1VyvTK,599,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'المميزة',jGX4sfdrWaeZpA1VyvTK,591,'','','featured1')
	items = u5h2Rckvw1E.findall('<strong>(.*?)</strong>.*?href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	for title,ekTrZlFMu0Kf5QztEnhAs in items:
		uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,591,'','','details1')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('main-menu"(.*?)header-social',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		iQVYwCHLhIS3DdbutWjp42AZEy8Tr = u5h2Rckvw1E.findall('<li (.*?)</li>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for GGOfdq3ejKzUl6xAuN7WsSMEJv in iQVYwCHLhIS3DdbutWjp42AZEy8Tr:
			items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)<',GGOfdq3ejKzUl6xAuN7WsSMEJv,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,title in items:
				if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = jGX4sfdrWaeZpA1VyvTK+ekTrZlFMu0Kf5QztEnhAs
				uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,591,'','','details2')
	return oo9SgGkiDbs3HRn7z8
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,type=''):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','FASELHD2-TITLES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	EXuOsjH9Smbyk7FdI13Aa8 = 0
	RfTOHSzgpA = u5h2Rckvw1E.findall('"archive-slider(.*?)<h4>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if RfTOHSzgpA: CyEMW1Sh3GtsbRUzN = RfTOHSzgpA[0]
	else: CyEMW1Sh3GtsbRUzN = ''
	if type=='featured1':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"slider-carousel"(.*?)</container>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall(' src="(.*?)".*?"slider-title">(.*?)<.*?<a href="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		zzPpxcaALmojyheWSG,YMpoGJSqdLFkvb4WRuZNa65,lQUf3AY258LeWch = zip(*items)
		items = zip(lQUf3AY258LeWch,zzPpxcaALmojyheWSG,YMpoGJSqdLFkvb4WRuZNa65)
	elif type=='featured2':
		items = u5h2Rckvw1E.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',CyEMW1Sh3GtsbRUzN,u5h2Rckvw1E.DOTALL)
	elif type=='filters':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = [oo9SgGkiDbs3HRn7z8.replace('\\/','/').replace('\\"','"')]
	elif type=='details2' and 'href' in CyEMW1Sh3GtsbRUzN:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('<h4>(.*?)</h4>(.*?)</container>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مميزة',url,591,'','','featured2')
		title = cWafzb4HoG1Em3Jwxu6C7vZsVi[0][0]
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,591,'','','details3')
		return
	else:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('<h4>(.*?)</h4>(.*?)</container>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		title,lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	dR94SHEmDA8nflN = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	yn8DkpE5etF3WiUmfSO = []
	for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
		if any(c2eEflztvIX in title.lower() for c2eEflztvIX in WLI5tgXRbUPNGJCSVz0vKjBDei3): continue
		title = title.strip(' ')
		title = uTUNPkVwCMKiD5gHLaj(title)
		zAjwuoRY98mXN6xvE = u5h2Rckvw1E.findall('(.*?) (الحلقة|حلقة).\d+',title,u5h2Rckvw1E.DOTALL)
		if '/movseries/' in ekTrZlFMu0Kf5QztEnhAs:
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,591,pGjsvdyHfM)
		elif zAjwuoRY98mXN6xvE and type=='':
			title = '_MOD_'+zAjwuoRY98mXN6xvE[0][0]
			if title not in yn8DkpE5etF3WiUmfSO:
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,593,pGjsvdyHfM)
				yn8DkpE5etF3WiUmfSO.append(title)
		elif any(c2eEflztvIX in title for c2eEflztvIX in dR94SHEmDA8nflN):
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,592,pGjsvdyHfM)
		else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,593,pGjsvdyHfM)
	if type=='filters':
		LTIzl7GJ3StWsN = u5h2Rckvw1E.findall('"more_button_page":(.*?),',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if LTIzl7GJ3StWsN:
			count = LTIzl7GJ3StWsN[0]
			ekTrZlFMu0Kf5QztEnhAs = url+'/offset/'+count
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة أخرى',ekTrZlFMu0Kf5QztEnhAs,591,'','','filters')
	elif 'details' in type:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="pagination(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,title in items:
				title = 'صفحة '+uTUNPkVwCMKiD5gHLaj(title)
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,591,'','','details4')
	return
def ZN3Wh7HABLwRIkFmyEd1Jq(url,type=''):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','FASELHD2-SEASONS_EPISODES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	EKhwoNlubG5A7xaJW2UOg1 = False
	if not type:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('<seasons(.*?)</seasons>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3>(.*?)</h3>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			if len(items)>1:
				jGX4sfdrWaeZpA1VyvTK = hmcFWJUgiAuGk(url,'url')
				EKhwoNlubG5A7xaJW2UOg1 = True
				for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
					title = uTUNPkVwCMKiD5gHLaj(title)
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,593,pGjsvdyHfM,'','episodes')
	if type=='episodes' or not EKhwoNlubG5A7xaJW2UOg1:
		ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx = u5h2Rckvw1E.findall('<bkز*?image:url\((.*?)\)"></bk>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx: pGjsvdyHfM = ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx[0]
		else: pGjsvdyHfM = ''
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('<all-episodes(.*?)</all-episodes>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,title in items:
				title = title.strip(' ')
				title = uTUNPkVwCMKiD5gHLaj(title)
				uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,592,pGjsvdyHfM)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	GnuaoT9MxiCg,BX7QKUdExCo9eGFy2iTlhMutZ08LP,vvspXO2tJ6ikETcV7o1jPW0xmg = [],[],[]
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',url,'','','','','FASELHD2-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	lZ5R0cxUOYX = u5h2Rckvw1E.findall('العمر :.*?<strong">(.*?)</strong>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if lZ5R0cxUOYX and dQorkS3qBhIMDWKHl(aUVSgO2ebjwX5iqPykC,url,lZ5R0cxUOYX): return
	ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('<iframe src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if ekTrZlFMu0Kf5QztEnhAs:
		ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs[0]
		GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs+'?named=__embed')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('<slice-title(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('data-url="(.*?)".*?</i>(.*?)</li>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,name in items:
			name = name.strip(' ')
			GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs+'?named='+name+'__watch')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('<downloads(.*?)</downloads>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?</div>(.*?)</div>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,name in items:
			GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs+'?named='+name+'__download')
	for GGjzV7mCfQHnsqBZhASo8 in GnuaoT9MxiCg:
		ekTrZlFMu0Kf5QztEnhAs,name = GGjzV7mCfQHnsqBZhASo8.split('?named')
		if ekTrZlFMu0Kf5QztEnhAs not in BX7QKUdExCo9eGFy2iTlhMutZ08LP:
			BX7QKUdExCo9eGFy2iTlhMutZ08LP.append(ekTrZlFMu0Kf5QztEnhAs)
			vvspXO2tJ6ikETcV7o1jPW0xmg.append(GGjzV7mCfQHnsqBZhASo8)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(vvspXO2tJ6ikETcV7o1jPW0xmg,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	search = search.replace(' ','+')
	jGX4sfdrWaeZpA1VyvTK = yONJxHER9BIDPpTV4YsWmc0n
	url = jGX4sfdrWaeZpA1VyvTK+'/?s='+search
	ll0a2AwztChcpsDUMi4rGW3b61XZES(url,'details5')
	return
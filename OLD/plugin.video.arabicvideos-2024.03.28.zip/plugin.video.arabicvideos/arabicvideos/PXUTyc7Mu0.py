# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'SHOOFMAX'
tiCRYyX1bWd40Ir3PafQu = '_SHM_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
nIo981YOgF2lx7JNevV4b0K6shuzA = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][1]
bhstdnoCPNl0KmF1QZOwBeq = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][2]
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==50: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==51: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url)
	elif mode==52: vS7JufTVsBxw52 = GA2KIlbOsoYtxpkDF71(url)
	elif mode==53: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==55: vS7JufTVsBxw52 = o1CSNF6rk5zEiYZfRbXgj4Bm()
	elif mode==56: vS7JufTVsBxw52 = vvKGpBO2i0zofeb9ygC6()
	elif mode==57: vS7JufTVsBxw52 = bbMyD8BfJLk5GT1HwIP9(url,1)
	elif mode==58: vS7JufTVsBxw52 = bbMyD8BfJLk5GT1HwIP9(url,2)
	elif mode==59: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',59,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'المسلسلات','',56)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'الافلام','',55)
	return ''
def o1CSNF6rk5zEiYZfRbXgj4Bm():
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'احدث الافلام',yONJxHER9BIDPpTV4YsWmc0n+'/movie/1/newest',51)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'افلام رائجة',yONJxHER9BIDPpTV4YsWmc0n+'/movie/1/popular',51)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'اخر اضافات الافلام',yONJxHER9BIDPpTV4YsWmc0n+'/movie/1/latest',51)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'افلام كلاسيكية',yONJxHER9BIDPpTV4YsWmc0n+'/movie/1/classic',51)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'اختيار افلام مرتبة بسنة الانتاج',yONJxHER9BIDPpTV4YsWmc0n+'/movie/1/yop',57)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'اختيار افلام مرتبة بالافضل تقييم',yONJxHER9BIDPpTV4YsWmc0n+'/movie/1/review',57)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'اختيار افلام مرتبة بالاكثر مشاهدة',yONJxHER9BIDPpTV4YsWmc0n+'/movie/1/views',57)
	return
def vvKGpBO2i0zofeb9ygC6():
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'احدث المسلسلات',yONJxHER9BIDPpTV4YsWmc0n+'/series/1/newest',51)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مسلسلات رائجة',yONJxHER9BIDPpTV4YsWmc0n+'/series/1/popular',51)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'اخر اضافات المسلسلات',yONJxHER9BIDPpTV4YsWmc0n+'/series/1/latest',51)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مسلسلات كلاسيكية',yONJxHER9BIDPpTV4YsWmc0n+'/series/1/classic',51)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'اختيار مسلسلات مرتبة بسنة الانتاج',yONJxHER9BIDPpTV4YsWmc0n+'/series/1/yop',57)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'اختيار مسلسلات مرتبة بالافضل تقييم',yONJxHER9BIDPpTV4YsWmc0n+'/series/1/review',57)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'اختيار مسلسلات مرتبة بالاكثر مشاهدة',yONJxHER9BIDPpTV4YsWmc0n+'/series/1/views',57)
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url):
	if '?' in url:
		KKSjuTY20EibkGc413C = url.split('?')
		url = KKSjuTY20EibkGc413C[0]
		filter = '?' + QQXTVNve6DMHBp4scG170kR2lWY(KKSjuTY20EibkGc413C[1],'=&:/%')
	else: filter = ''
	KKSjuTY20EibkGc413C = url.split('/')
	sort,BzbaC0qYjMr2WXwsO,type = KKSjuTY20EibkGc413C[-1],KKSjuTY20EibkGc413C[-2],KKSjuTY20EibkGc413C[-3]
	if sort in ['yop','review','views']:
		if type=='movie': v94eWpjgbPaZKECiA7J='فيلم'
		elif type=='series': v94eWpjgbPaZKECiA7J='مسلسل'
		url = yONJxHER9BIDPpTV4YsWmc0n + '/genre/filter/' + QQXTVNve6DMHBp4scG170kR2lWY(v94eWpjgbPaZKECiA7J) + '/' + BzbaC0qYjMr2WXwsO + '/' + sort + filter
		oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,url,'','','','SHOOFMAX-TITLES-1st')
		items = u5h2Rckvw1E.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		JeXvk7FjGa5CnU8TWDBP3EAItfHN=0
		for id,title,AdV48Lo03U,pGjsvdyHfM in items:
			JeXvk7FjGa5CnU8TWDBP3EAItfHN += 1
			pGjsvdyHfM = bhstdnoCPNl0KmF1QZOwBeq + '/v2/img/program/main/' + pGjsvdyHfM + '-2.jpg'
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n + '/program/' + id
			if type=='movie': uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,53,pGjsvdyHfM)
			if type=='series': uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مسلسل '+title,ekTrZlFMu0Kf5QztEnhAs+'?ep='+AdV48Lo03U+'='+title+'='+pGjsvdyHfM,52,pGjsvdyHfM)
	else:
		if type=='movie': v94eWpjgbPaZKECiA7J='movies'
		elif type=='series': v94eWpjgbPaZKECiA7J='series'
		url = nIo981YOgF2lx7JNevV4b0K6shuzA + '/json/selected/' + sort + '-' + v94eWpjgbPaZKECiA7J + '-WW.json'
		oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,url,'','','','SHOOFMAX-TITLES-2nd')
		items = u5h2Rckvw1E.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		JeXvk7FjGa5CnU8TWDBP3EAItfHN=0
		for id,AdV48Lo03U,pGjsvdyHfM,title in items:
			JeXvk7FjGa5CnU8TWDBP3EAItfHN += 1
			pGjsvdyHfM = nIo981YOgF2lx7JNevV4b0K6shuzA + '/img/program/' + pGjsvdyHfM + '-2.jpg'
			ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n + '/program/' + id
			if type=='movie': uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,53,pGjsvdyHfM)
			elif type=='series': uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'مسلسل '+title,ekTrZlFMu0Kf5QztEnhAs+'?ep='+AdV48Lo03U+'='+title+'='+pGjsvdyHfM,52,pGjsvdyHfM)
	title='صفحة '
	if JeXvk7FjGa5CnU8TWDBP3EAItfHN==16:
		for NNtAMv1eYUgKifTSrajGlmC in range(1,13) :
			if not BzbaC0qYjMr2WXwsO==str(NNtAMv1eYUgKifTSrajGlmC):
				url = yONJxHER9BIDPpTV4YsWmc0n+'/genre/filter/'+type+'/'+str(NNtAMv1eYUgKifTSrajGlmC)+'/'+sort + filter
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title+str(NNtAMv1eYUgKifTSrajGlmC),url,51)
	return
def GA2KIlbOsoYtxpkDF71(url):
	KKSjuTY20EibkGc413C = url.split('=')
	AdV48Lo03U = int(KKSjuTY20EibkGc413C[1])
	name = P2o6ZDHeW790pSQqucvnxzILVUX(KKSjuTY20EibkGc413C[2])
	name = name.replace('_MOD_مسلسل ','')
	pGjsvdyHfM = KKSjuTY20EibkGc413C[3]
	url = url.split('?')[0]
	if AdV48Lo03U==0:
		oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,url,'','','','SHOOFMAX-EPISODES-1st')
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('<select(.*?)</select>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('option value="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		AdV48Lo03U = int(items[-1])
	for zAjwuoRY98mXN6xvE in range(AdV48Lo03U,0,-1):
		ekTrZlFMu0Kf5QztEnhAs = url + '?ep=' + str(zAjwuoRY98mXN6xvE)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(zAjwuoRY98mXN6xvE)
		uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,53,pGjsvdyHfM)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,url,'','','','SHOOFMAX-PLAY-1st')
	OXvAcNy2h6sIdk8gGzWBVrFQKL417 = u5h2Rckvw1E.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if OXvAcNy2h6sIdk8gGzWBVrFQKL417:
		YVJPFvuI2CS5KObiZt = OXvAcNy2h6sIdk8gGzWBVrFQKL417[1].replace('T','    ')
		xl9MFt1AmY0GrkENug8n('','','رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+'\n'+YVJPFvuI2CS5KObiZt)
		return
	IP9heCMkjZ4lwRnzY0Usp,O2qph1YZ4n = [],[]
	vzNEP8GAa0gU = u5h2Rckvw1E.findall('var origin_link = "(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)[0]
	JJW1ic69x2ynm4DvANZHI3K7q = u5h2Rckvw1E.findall('var backup_origin_link = "(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)[0]
	lQUf3AY258LeWch = u5h2Rckvw1E.findall('hls: (.*?)_link\+"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	for NDwLctrHpYz3JBP,ekTrZlFMu0Kf5QztEnhAs in lQUf3AY258LeWch:
		if 'backup' in NDwLctrHpYz3JBP:
			NDwLctrHpYz3JBP = 'backup server'
			url = JJW1ic69x2ynm4DvANZHI3K7q + ekTrZlFMu0Kf5QztEnhAs
		else:
			NDwLctrHpYz3JBP = 'main server'
			url = vzNEP8GAa0gU + ekTrZlFMu0Kf5QztEnhAs
		if '.m3u8' in url:
			IP9heCMkjZ4lwRnzY0Usp.append(url)
			O2qph1YZ4n.append('m3u8  '+NDwLctrHpYz3JBP)
	lQUf3AY258LeWch = u5h2Rckvw1E.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lQUf3AY258LeWch += u5h2Rckvw1E.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	for NDwLctrHpYz3JBP,ekTrZlFMu0Kf5QztEnhAs in lQUf3AY258LeWch:
		filename = ekTrZlFMu0Kf5QztEnhAs.split('/')[-1]
		filename = filename.replace('fallback','')
		filename = filename.replace('.mp4','')
		filename = filename.replace('-','')
		if 'backup' in NDwLctrHpYz3JBP:
			NDwLctrHpYz3JBP = 'backup server'
			url = JJW1ic69x2ynm4DvANZHI3K7q + ekTrZlFMu0Kf5QztEnhAs
		else:
			NDwLctrHpYz3JBP = 'main server'
			url = vzNEP8GAa0gU + ekTrZlFMu0Kf5QztEnhAs
		IP9heCMkjZ4lwRnzY0Usp.append(url)
		O2qph1YZ4n.append('mp4  '+NDwLctrHpYz3JBP+'  '+filename)
	u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = tYysxJLreEBDdXMIjz4OPa('Select Video Quality:', O2qph1YZ4n)
	if u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo == -1 : return
	url = IP9heCMkjZ4lwRnzY0Usp[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
	om1iZDWnrhGa2SLB9O4kfxYbqU(url,aUVSgO2ebjwX5iqPykC,'video')
	return
def bbMyD8BfJLk5GT1HwIP9(url,type):
	if 'series' in url: gANn35esloKUydOipfSMC6RD2 = yONJxHER9BIDPpTV4YsWmc0n + '/genre/مسلسل'
	else: gANn35esloKUydOipfSMC6RD2 = yONJxHER9BIDPpTV4YsWmc0n + '/genre/فيلم'
	gANn35esloKUydOipfSMC6RD2 = QQXTVNve6DMHBp4scG170kR2lWY(gANn35esloKUydOipfSMC6RD2)
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,gANn35esloKUydOipfSMC6RD2,'','','','SHOOFMAX-FILTERS-1st')
	if type==1: cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('subgenre(.*?)div',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	elif type==2: cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('country(.*?)div',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('option value="(.*?)">(.*?)</option',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	if type==1:
		for pZg6VUel2ErXbk4LNydn5ORq,title in items:
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url+'?subgenre='+pZg6VUel2ErXbk4LNydn5ORq,58)
	elif type==2:
		url,pZg6VUel2ErXbk4LNydn5ORq = url.split('?')
		for Hqe1swvhCVTM2jYWKya0xSAUnbp,title in items:
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url+'?country='+Hqe1swvhCVTM2jYWKya0xSAUnbp+'&'+pZg6VUel2ErXbk4LNydn5ORq,51)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if not search: search = FBrXsYeCEp3()
	if not search: return
	GHFUMEOSrvhmIoVWxwN8j4 = search.replace(' ','%20')
	url = yONJxHER9BIDPpTV4YsWmc0n+'/search?q='+GHFUMEOSrvhmIoVWxwN8j4
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','',True,'','SHOOFMAX-SEARCH-2nd')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('general-body(.*?)search-bottom-padding',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	if items:
		for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
			url = yONJxHER9BIDPpTV4YsWmc0n + ekTrZlFMu0Kf5QztEnhAs
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+QQXTVNve6DMHBp4scG170kR2lWY(title)+'='+pGjsvdyHfM
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,52,pGjsvdyHfM)
				else:
					title = '_MOD_فيلم '+title
					uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,url,53,pGjsvdyHfM)
	return
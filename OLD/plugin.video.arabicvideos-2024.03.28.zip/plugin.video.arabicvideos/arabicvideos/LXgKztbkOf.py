# -*- coding: utf-8 -*-
import sys as vdo2FnhPmAVRMJQZ0EIG8
XzBpdMGJhHZKC8Yveki5qb1jT4nQUg = vdo2FnhPmAVRMJQZ0EIG8.version_info [0] == 2
vykERrdZlF5K = 2048
GG02h4EolRYTs3iv = 7
def tci7BbCy6gT9MXkOEzhm (xVtfmzjd6RSsBEk2o34aHWC):
	global jMo7iTRkq0n1NPa35xheAVlbt
	oAJijr7NHwnfUGqyd8Ru6EImOtv = ord (xVtfmzjd6RSsBEk2o34aHWC [-1])
	wwpaJlB3bkXySOHFWUfoILC = xVtfmzjd6RSsBEk2o34aHWC [:-1]
	lqXRut6PnL = oAJijr7NHwnfUGqyd8Ru6EImOtv % len (wwpaJlB3bkXySOHFWUfoILC)
	rmaU71pZj3X = wwpaJlB3bkXySOHFWUfoILC [:lqXRut6PnL] + wwpaJlB3bkXySOHFWUfoILC [lqXRut6PnL:]
	if XzBpdMGJhHZKC8Yveki5qb1jT4nQUg:
		bbsiU0a49tw2dy = unicode () .join ([unichr (ord (Q9QUIWH6rK2BlmC) - vykERrdZlF5K - (ZXwWfDc9AF4yr2P + oAJijr7NHwnfUGqyd8Ru6EImOtv) % GG02h4EolRYTs3iv) for ZXwWfDc9AF4yr2P, Q9QUIWH6rK2BlmC in enumerate (rmaU71pZj3X)])
	else:
		bbsiU0a49tw2dy = str () .join ([chr (ord (Q9QUIWH6rK2BlmC) - vykERrdZlF5K - (ZXwWfDc9AF4yr2P + oAJijr7NHwnfUGqyd8Ru6EImOtv) % GG02h4EolRYTs3iv) for ZXwWfDc9AF4yr2P, Q9QUIWH6rK2BlmC in enumerate (rmaU71pZj3X)])
	return eval (bbsiU0a49tw2dy)
r3flT0zQPa5H7yXEgxJOt92Vc4Ao,cgtRBdXxSOk7WUfyDhPCls,cNaVb1vsT4qWOL0rpE=tci7BbCy6gT9MXkOEzhm,tci7BbCy6gT9MXkOEzhm,tci7BbCy6gT9MXkOEzhm
yruHDQOcB97ig,drHLAY5ENQFe2q9ptKGabo,qnPgZ9N15G6Oa8UpMASvLk=cNaVb1vsT4qWOL0rpE,cgtRBdXxSOk7WUfyDhPCls,r3flT0zQPa5H7yXEgxJOt92Vc4Ao
KKbpxUZnMcj6AJ4QdD,ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB,ggDRehOModi=qnPgZ9N15G6Oa8UpMASvLk,drHLAY5ENQFe2q9ptKGabo,yruHDQOcB97ig
xuztI5QWEKG70CPNdhk4vo6,bcgZJWV6UeNSkRA,shZ9eOcN2dJnPj=ggDRehOModi,ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB,KKbpxUZnMcj6AJ4QdD
BGhdkWsEvJjiMFTr3NLn1flU,nKLEi8CJumazx4qT,pcWq35MED2dtK=shZ9eOcN2dJnPj,bcgZJWV6UeNSkRA,xuztI5QWEKG70CPNdhk4vo6
yF29Xdsx35wI07Ce4,XikqnGVSK4v9d3uUICLhDxJyt1M,JLoPRXt93dpAB=pcWq35MED2dtK,nKLEi8CJumazx4qT,BGhdkWsEvJjiMFTr3NLn1flU
wwplD0tEehqH3kYQXs,tZ3gsrTEdzA1S6LXa9WI5px,Nqj35AXg06euY1G2d4bSUMQ8wlr=JLoPRXt93dpAB,XikqnGVSK4v9d3uUICLhDxJyt1M,yF29Xdsx35wI07Ce4
bbw2eajMlG,M6PIj8gl1fno7wcqTksDEBK4bU,CgG4PuyxsLA8WDzh3FfteZvKQMdom9=Nqj35AXg06euY1G2d4bSUMQ8wlr,tZ3gsrTEdzA1S6LXa9WI5px,wwplD0tEehqH3kYQXs
iifPEY9ABNzTQp,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ,PtXn0k9G3ocHRg=CgG4PuyxsLA8WDzh3FfteZvKQMdom9,M6PIj8gl1fno7wcqTksDEBK4bU,bbw2eajMlG
Tgoa16jMxvYX2,vvBChXmSty,InKG0i2r6hHDvgd=PtXn0k9G3ocHRg,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ,iifPEY9ABNzTQp
OyJ1o4AvmWlB75UkFRX,usaZLwSGe1k6VDp570yhB4bzWPiFq,oUlIcGH2JuWFLvimMXyBQdzK06ge=InKG0i2r6hHDvgd,vvBChXmSty,Tgoa16jMxvYX2
from z9NBdJU7p6 import *
import bidi.algorithm as k4rNW6UOwPBVDfblusx,bidi.mirror as A1hKHsUSl405QF6rGyIiPWEBpk,base64 as yB3NPc2ZhbwFEi1X0dv,requests as RduBx91EMtZDLn
aUVSgO2ebjwX5iqPykC = oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠧࡍࡋࡅࡗ࡙࡝ࡏࠨ౱")
NW1z9Mg8T2 = {}
YD56nkJmsd = []
if VVGRN7xiyj:
	tylMP5dsXWJO = vJI3jtCwe5WL1OinmNgys.translatePath(InKG0i2r6hHDvgd(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡽࡨ࡭ࡤࠩ౲"))
	r4roga1DYEwG = vJI3jtCwe5WL1OinmNgys.translatePath(drHLAY5ENQFe2q9ptKGabo(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴࡮࡯࡮ࡧࠪ౳"))
	ewsHG1doa9L = vJI3jtCwe5WL1OinmNgys.translatePath(wwplD0tEehqH3kYQXs(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵࡬ࡰࡩࡳࡥࡹ࡮ࠧ౴"))
	UrA7SvnaILc = k1t0JLRsCQ.path.join(r4roga1DYEwG,CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭౵"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ౶"),vvBChXmSty(u"࠭ࡁࡥࡦࡲࡲࡸ࠹࠳࠯ࡦࡥࠫ౷"))
	jpqsbI5XON = k1t0JLRsCQ.path.join(r4roga1DYEwG,cgtRBdXxSOk7WUfyDhPCls(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ౸"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ౹"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࡙ࠩ࡭ࡪࡽࡍࡰࡦࡨࡷ࠻࠴ࡤࡣࠩ౺"))
	vRsq07Q8nmCxVTWJ = k1t0JLRsCQ.path.join(r4roga1DYEwG,pcWq35MED2dtK(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ౻"),xuztI5QWEKG70CPNdhk4vo6(u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭౼"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࡚ࠬࡥࡹࡶࡸࡶࡪࡹ࠱࠴࠰ࡧࡦࠬ౽"))
	Rzh5Iv8cO0AGFq9D = xuztI5QWEKG70CPNdhk4vo6(u"ࡻࠧ࡝ࡷ࠳࠶ࡩ࠷ࠧ౾")
	from urllib.parse import quote as _EfPkWJ8SLvZuBRj2nY
else:
	tylMP5dsXWJO = bMIascyFJ2x43E0C7glTB91h8qz.translatePath(InKG0i2r6hHDvgd(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡼࡧࡳࡣࠨ౿"))
	r4roga1DYEwG = bMIascyFJ2x43E0C7glTB91h8qz.translatePath(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳࡭ࡵ࡭ࡦࠩಀ"))
	ewsHG1doa9L = bMIascyFJ2x43E0C7glTB91h8qz.translatePath(usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡲ࡯ࡨࡲࡤࡸ࡭࠭ಁ"))
	UrA7SvnaILc = k1t0JLRsCQ.path.join(r4roga1DYEwG,PtXn0k9G3ocHRg(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬಂ"),yF29Xdsx35wI07Ce4(u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭ಃ"),yF29Xdsx35wI07Ce4(u"ࠬࡇࡤࡥࡱࡱࡷ࠷࠽࠮ࡥࡤࠪ಄"))
	jpqsbI5XON = k1t0JLRsCQ.path.join(r4roga1DYEwG,CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨಅ"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩಆ"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠨࡘ࡬ࡩࡼࡓ࡯ࡥࡧࡶ࠺࠳ࡪࡢࠨಇ"))
	vRsq07Q8nmCxVTWJ = k1t0JLRsCQ.path.join(r4roga1DYEwG,qnPgZ9N15G6Oa8UpMASvLk(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫಈ"),yF29Xdsx35wI07Ce4(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬಉ"),yruHDQOcB97ig(u"࡙ࠫ࡫ࡸࡵࡷࡵࡩࡸ࠷࠳࠯ࡦࡥࠫಊ"))
	Rzh5Iv8cO0AGFq9D = Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࡺ࠭࡜ࡶ࠲࠵ࡨ࠶࠭ಋ").encode(KKbpxUZnMcj6AJ4QdD(u"࠭ࡵࡵࡨ࠻ࠫಌ"))
	from urllib import quote as _EfPkWJ8SLvZuBRj2nY
T1guYOxGi3ClA0d2s7kZf4J5b = k1t0JLRsCQ.path.join(ewsHG1doa9L,xuztI5QWEKG70CPNdhk4vo6(u"ࠧ࡬ࡱࡧ࡭࠳ࡲ࡯ࡨࠩ಍"))
t3IjC1ycv0XgoRUF6mZiLeT8Dz = k1t0JLRsCQ.path.join(ewsHG1doa9L,PtXn0k9G3ocHRg(u"ࠨ࡭ࡲࡨ࡮࠴࡯࡭ࡦ࠱ࡰࡴ࡭ࠧಎ"))
zCpti8OAPJHYfVj5WSTRwakscUeE = k1t0JLRsCQ.path.join(OxWkR7Eu9Pm3IAvTp0q,usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩ࡬ࡴࡹࡼ࠱ࡥࡣࡷࡥࡤࡥ࡟࠯ࡦࡥࠫಏ"))
jTsve4S0KNIXEhQp2Hr = k1t0JLRsCQ.path.join(OxWkR7Eu9Pm3IAvTp0q,cgtRBdXxSOk7WUfyDhPCls(u"ࠪ࡭ࡵࡺࡶ࠳ࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬಐ"))
QOeNYP5hpm4iI8r = k1t0JLRsCQ.path.join(OxWkR7Eu9Pm3IAvTp0q,usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠫࡲ࠹ࡵࡥࡣࡷࡥࡤࡥ࡟࠯ࡦࡥࠫ಑"))
MZabdxfVE5WJwUu = k1t0JLRsCQ.path.join(OxWkR7Eu9Pm3IAvTp0q,nKLEi8CJumazx4qT(u"ࠬ࡬ࡡࡷࡱࡸࡶ࡮ࡺࡥࡴ࠰ࡧࡥࡹ࠭ಒ"))
JeBhHfUsXbwmLNQcD = k1t0JLRsCQ.path.join(OxWkR7Eu9Pm3IAvTp0q,cNaVb1vsT4qWOL0rpE(u"࠭ࡩࡱࡶࡹࡪ࡮ࡲࡥࡠࡡࡢ࠲ࡩࡧࡴࠨಓ"))
ttyjfLqbA1VJNOu = k1t0JLRsCQ.path.join(OxWkR7Eu9Pm3IAvTp0q,XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧ࡮࠵ࡸࡪ࡮ࡲࡥࡠࡡࡢ࠲ࡩࡧࡴࠨಔ"))
yZKq8SbJduiIwcHMOz6gN = k1t0JLRsCQ.path.join(OxWkR7Eu9Pm3IAvTp0q,drHLAY5ENQFe2q9ptKGabo(u"ࠨ࡫ࡰࡥ࡬࡫ࡳࠨಕ"))
kUcM6FIhbr1W38pKzgOy = k1t0JLRsCQ.path.join(yZKq8SbJduiIwcHMOz6gN,M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡵࠪಖ"))
Wgy3rdVP0HqnsA2N59FfbITu6Bh = k1t0JLRsCQ.path.join(kUcM6FIhbr1W38pKzgOy,ggDRehOModi(u"ࠪࡨ࡮ࡧ࡬ࡰࡩࡢ࠴࠵࠶࠰ࡠ࠰ࡳࡲ࡬࠭ಗ"))
b69iT7LWwrfXzGYPMvBCsteVHDQK = kmUVwglqCI7Q.Addon().getAddonInfo(yruHDQOcB97ig(u"ࠫࡵࡧࡴࡩࠩಘ"))
bDYdui4a8EqFLe7JG = k1t0JLRsCQ.path.join(b69iT7LWwrfXzGYPMvBCsteVHDQK,shZ9eOcN2dJnPj(u"ࠬ࡯ࡣࡰࡰ࠱ࡴࡳ࡭ࠧಙ"))
FfCI72d4MXZk0Pme = k1t0JLRsCQ.path.join(b69iT7LWwrfXzGYPMvBCsteVHDQK,xuztI5QWEKG70CPNdhk4vo6(u"࠭ࡴࡩࡷࡰࡦ࠳ࡶ࡮ࡨࠩಚ"))
FTeZjcG8Cd30bytv2Oo6S1JWMQ = k1t0JLRsCQ.path.join(b69iT7LWwrfXzGYPMvBCsteVHDQK,yF29Xdsx35wI07Ce4(u"ࠧࡧࡣࡱࡥࡷࡺ࠮ࡱࡰࡪࠫಛ"))
uWf4o3Mc2wBK = k1t0JLRsCQ.path.join(b69iT7LWwrfXzGYPMvBCsteVHDQK,ggDRehOModi(u"ࠨࡤࡤࡲࡳ࡫ࡲ࠯ࡲࡱ࡫ࠬಜ"))
IkxsXLotRmAMNUG65YZv9DF = k1t0JLRsCQ.path.join(b69iT7LWwrfXzGYPMvBCsteVHDQK,KKbpxUZnMcj6AJ4QdD(u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩ࠳ࡶ࡮ࡨࠩಝ"))
c5KtQb01CnB = k1t0JLRsCQ.path.join(b69iT7LWwrfXzGYPMvBCsteVHDQK,JLoPRXt93dpAB(u"ࠪࡴࡴࡹࡴࡦࡴ࠱ࡴࡳ࡭ࠧಞ"))
Hc93WG6a1ZP7srEwmyApNtlq = k1t0JLRsCQ.path.join(b69iT7LWwrfXzGYPMvBCsteVHDQK,cgtRBdXxSOk7WUfyDhPCls(u"ࠫࡨࡲࡥࡢࡴ࡯ࡳ࡬ࡵ࠮ࡱࡰࡪࠫಟ"))
toh5NRrqjA4dmG8M1IFwEl = k1t0JLRsCQ.path.join(b69iT7LWwrfXzGYPMvBCsteVHDQK,BGhdkWsEvJjiMFTr3NLn1flU(u"ࠬࡩ࡬ࡦࡣࡵࡥࡷࡺ࠮ࡱࡰࡪࠫಠ"))
TvNMR1USOYBhm06dtWyGg = k1t0JLRsCQ.path.join(b69iT7LWwrfXzGYPMvBCsteVHDQK,r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠭࡭ࡦࡰࡸ࠲ࡵࡴࡧࠨಡ"))
m5w4leUWqAOQgh9Sf = k1t0JLRsCQ.path.join(b69iT7LWwrfXzGYPMvBCsteVHDQK,cgtRBdXxSOk7WUfyDhPCls(u"ࠧࡤࡪࡤࡲ࡬࡫࡬ࡰࡩ࠱ࡸࡽࡺࠧಢ"))
gDC5Zva1sxhpHLP8SwoIe3fRlB7t = k1t0JLRsCQ.path.join(r4roga1DYEwG,Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠨࡣࡧࡨࡴࡴࡳࠨಣ"))
bFWt9xADQYV7hU3neC = k1t0JLRsCQ.path.join(r4roga1DYEwG,drHLAY5ENQFe2q9ptKGabo(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫತ"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧಥ"),lY0rst72uGVZ1NkgvpjfA6x,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪದ"))
JH6Z129abNsUoj8xG = k1t0JLRsCQ.path.join(tylMP5dsXWJO,bbw2eajMlG(u"ࠬࡳࡥࡥ࡫ࡤࠫಧ"),tZ3gsrTEdzA1S6LXa9WI5px(u"࠭ࡆࡰࡰࡷࡷࠬನ"),pcWq35MED2dtK(u"ࠧࡢࡴ࡬ࡥࡱ࠴ࡴࡵࡨࠪ಩"))
vMrXCkF9Kmu = yruHDQOcB97ig(u"࠵ᒞ")
r5tHLX2ZFS1Kz9jRba0fsc = [M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠨืไีࠬಪ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠩฦ์้࠭ಫ"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠪฯฬ์๊ࠨಬ"),xuztI5QWEKG70CPNdhk4vo6(u"ࠫะอไฬࠩಭ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠬืวษ฻ࠪಮ"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠭ฮศ็ึࠫಯ"),cNaVb1vsT4qWOL0rpE(u"ࠧิษาืࠬರ"),JLoPRXt93dpAB(u"ࠨีสฬ฾࠭ಱ"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩฮห๊์ࠧಲ"),xuztI5QWEKG70CPNdhk4vo6(u"ࠪฮฬููࠨಳ"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠫ฾อิาࠩ಴")]
dL95pmrlhDJe6 = ggDRehOModi(u"ࠬ⹁ࠠ⼞ࠢ⸭ࠤ⹀࠭ವ")
Q0cg5bo8CTv4 = [n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬಶ")]
SdZxjbJQHuf9GK6z8DTRWha4ti = [BGhdkWsEvJjiMFTr3NLn1flU(u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛ࠩಷ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕࠫಸ"),ggDRehOModi(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠭ಹ"),yF29Xdsx35wI07Ce4(u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫ಺"),pcWq35MED2dtK(u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊࠧ಻"),yF29Xdsx35wI07Ce4(u"ࠬࡓࡏࡗࡕ࠷಼࡙ࠬ"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭ಽ"),drHLAY5ENQFe2q9ptKGabo(u"ࠧࡍࡃࡕࡓ࡟ࡇࠧಾ"),yF29Xdsx35wI07Ce4(u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋࠪಿ"),xuztI5QWEKG70CPNdhk4vo6(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶ࠫೀ")]
SdZxjbJQHuf9GK6z8DTRWha4ti += [PtXn0k9G3ocHRg(u"ࠪࡌࡊࡒࡁࡍࠩು"),Tgoa16jMxvYX2(u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊࠪೂ"),yF29Xdsx35wI07Ce4(u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓࠧೃ"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࠧೄ"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑࠩ೅"),InKG0i2r6hHDvgd(u"ࠨࡇࡊ࡝ࡓࡕࡗࠨೆ"),cgtRBdXxSOk7WUfyDhPCls(u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒࠫೇ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠪࡔࡆࡔࡅࡕࠩೈ"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ೉"),cgtRBdXxSOk7WUfyDhPCls(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࡗࡐࡔࡎࠫೊ")]
bT5n6i8yjme1tP = [Tgoa16jMxvYX2(u"࠭ࡉࡑࡖ࡙ࠫೋ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧࡊࡒࡗ࡚࠲ࡒࡉࡗࡇࠪೌ"),PtXn0k9G3ocHRg(u"ࠨࡋࡓࡘ࡛࠳ࡍࡐࡘࡌࡉࡘ್࠭"),drHLAY5ENQFe2q9ptKGabo(u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧ೎")]
bT5n6i8yjme1tP += [BGhdkWsEvJjiMFTr3NLn1flU(u"ࠪࡑ࠸࡛ࠧ೏"),KKbpxUZnMcj6AJ4QdD(u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭೐"),pcWq35MED2dtK(u"ࠬࡓ࠳ࡖ࠯ࡐࡓ࡛ࡏࡅࡔࠩ೑"),PtXn0k9G3ocHRg(u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪ೒")]
bT5n6i8yjme1tP += [M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠧࡊࡈࡌࡐࡒ࠭೓"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࠨࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉࠧ೔"),iifPEY9ABNzTQp(u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡑࡋࡑࡏࡓࡉࠩೕ")]
bT5n6i8yjme1tP += [wwplD0tEehqH3kYQXs(u"ࠪࡅࡑࡇࡒࡂࡄࠪೖ"),cNaVb1vsT4qWOL0rpE(u"ࠫࡆࡑࡗࡂࡏࠪ೗"),vvBChXmSty(u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧ೘"),pcWq35MED2dtK(u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨ೙"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠧࡂࡍࡒࡅࡒ࠭೚"),OyJ1o4AvmWlB75UkFRX(u"ࠨࡍࡄࡘࡐࡕࡔࡕࡘࠪ೛")]
bT5n6i8yjme1tP += [wwplD0tEehqH3kYQXs(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ೜"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠪࡆࡔࡑࡒࡂࠩೝ"),xuztI5QWEKG70CPNdhk4vo6(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭ೞ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕࠪ೟"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨೠ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳ࠩೡ")]
AlYMjfIewb0v3n6hq8sHiCpR = [tZ3gsrTEdzA1S6LXa9WI5px(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩೢ"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࠪೣ"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ೤"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ೥")]
AlYMjfIewb0v3n6hq8sHiCpR += [iifPEY9ABNzTQp(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ೦"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡛ࡏࡄࡆࡑࡖࠫ೧"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ೨"),vvBChXmSty(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ೩"),iifPEY9ABNzTQp(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡕࡑࡓࡍࡈ࡙ࠧ೪"),bcgZJWV6UeNSkRA(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡎࡌ࡚ࡊ࡙ࠧ೫")]
SMAjf2CH1wmrhnDg = [bbw2eajMlG(u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ೬"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭೭"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧ೮"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ೯"),bcgZJWV6UeNSkRA(u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗࠬ೰")]
SMAjf2CH1wmrhnDg += [usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫೱ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠪࡘ࡛ࡌࡕࡏࠩೲ"),shZ9eOcN2dJnPj(u"ࠫ࡜ࡋࡃࡊࡏࡄࠫೳ"),yruHDQOcB97ig(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ೴")]
YExQh9CZ4ioRUmr8e1nqHl5 = [usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨ೵"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩ೶"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫ೷"),vvBChXmSty(u"ࠩࡉࡓࡘ࡚ࡁࠨ೸"),vvBChXmSty(u"ࠪࡅࡍ࡝ࡁࡌࠩ೹"),vvBChXmSty(u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬ೺")]
YExQh9CZ4ioRUmr8e1nqHl5 += [cgtRBdXxSOk7WUfyDhPCls(u"࡙ࠬࡈࡐࡈࡋࡅࠬ೻"),BGhdkWsEvJjiMFTr3NLn1flU(u"࠭ࡂࡓࡕࡗࡉࡏ࠭೼"),bcgZJWV6UeNSkRA(u"࡚ࠧࡃࡔࡓ࡙࠭೽"),nKLEi8CJumazx4qT(u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩ೾"),ggDRehOModi(u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪ೿"),bbw2eajMlG(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬഀ"),ggDRehOModi(u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭ഁ")]
CodyfR8zIB4JS96UPivW5kXGrHa3  = [xuztI5QWEKG70CPNdhk4vo6(u"ࠬࡇࡋࡘࡃࡐࠫം"),yruHDQOcB97ig(u"࠭ࡁࡍࡃࡕࡅࡇ࠭ഃ"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩഄ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠨࡄࡒࡏࡗࡇࠧഅ"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠩࡄࡏࡔࡇࡍࠨആ"),Tgoa16jMxvYX2(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬഇ"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭ഈ"),bcgZJWV6UeNSkRA(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭ഉ")]
CodyfR8zIB4JS96UPivW5kXGrHa3 += [KKbpxUZnMcj6AJ4QdD(u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨഊ"),bbw2eajMlG(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪഋ"),bbw2eajMlG(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩഌ"),drHLAY5ENQFe2q9ptKGabo(u"࡚ࠩࡉࡈࡏࡍࡂࠩ഍"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧഎ"),nKLEi8CJumazx4qT(u"ࠫࡋࡕࡓࡕࡃࠪഏ"),ggDRehOModi(u"ࠬࡇࡈࡘࡃࡎࠫഐ")]
CodyfR8zIB4JS96UPivW5kXGrHa3 += [qnPgZ9N15G6Oa8UpMASvLk(u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩ഑"),OyJ1o4AvmWlB75UkFRX(u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪഒ"),iifPEY9ABNzTQp(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪഓ"),OyJ1o4AvmWlB75UkFRX(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠵ࠫഔ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬക"),wwplD0tEehqH3kYQXs(u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭ഖ")]
CodyfR8zIB4JS96UPivW5kXGrHa3 += [qnPgZ9N15G6Oa8UpMASvLk(u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭ഗ"),JLoPRXt93dpAB(u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨഘ"),yruHDQOcB97ig(u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩങ"),cNaVb1vsT4qWOL0rpE(u"ࠨࡖ࡙ࡊ࡚ࡔࠧച"),bcgZJWV6UeNSkRA(u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫഛ"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠪࡗࡍࡕࡆࡉࡃࠪജ")]
CodyfR8zIB4JS96UPivW5kXGrHa3 += [KKbpxUZnMcj6AJ4QdD(u"ࠫࡇࡘࡓࡕࡇࡍࠫഝ"),yF29Xdsx35wI07Ce4(u"ࠬ࡟ࡁࡒࡑࡗࠫഞ"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧട"),InKG0i2r6hHDvgd(u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨഠ"),yF29Xdsx35wI07Ce4(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭ഡ"),shZ9eOcN2dJnPj(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫഢ"),drHLAY5ENQFe2q9ptKGabo(u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚ࠬണ")]
YXGHgQkalMIW78q1KDFTPo  = [qnPgZ9N15G6Oa8UpMASvLk(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࡙ࡍࡉࡋࡏࡔࠩത"),yruHDQOcB97ig(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭ഥ"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭ദ"),iifPEY9ABNzTQp(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡚ࡏࡑࡋࡆࡗࠬധ"),xuztI5QWEKG70CPNdhk4vo6(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡌࡊࡘࡈࡗࠬന")]
YXGHgQkalMIW78q1KDFTPo += [InKG0i2r6hHDvgd(u"ࠩࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࠨഩ"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࠪപ")]
YXGHgQkalMIW78q1KDFTPo += [XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲࡜ࡉࡅࡇࡒࡗࠬഫ"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩബ"),tZ3gsrTEdzA1S6LXa9WI5px(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩഭ")]
YXGHgQkalMIW78q1KDFTPo += [nKLEi8CJumazx4qT(u"ࠧࡊࡒࡗ࡚࠲ࡒࡉࡗࡇࠪമ"),bbw2eajMlG(u"ࠨࡋࡓࡘ࡛࠳ࡍࡐࡘࡌࡉࡘ࠭യ"),Tgoa16jMxvYX2(u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧര")]
YXGHgQkalMIW78q1KDFTPo += [ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠪࡑ࠸࡛࠭ࡍࡋ࡙ࡉࠬറ"),OyJ1o4AvmWlB75UkFRX(u"ࠫࡒ࠹ࡕ࠮ࡏࡒ࡚ࡎࡋࡓࠨല"),nKLEi8CJumazx4qT(u"ࠬࡓ࠳ࡖ࠯ࡖࡉࡗࡏࡅࡔࠩള")]
pmJgTDsQvXLqCn9ocyBwG2 = [drHLAY5ENQFe2q9ptKGabo(u"࠭ࡍ࠴ࡗࠪഴ"),nKLEi8CJumazx4qT(u"ࠧࡊࡒࡗ࡚ࠬവ"),JLoPRXt93dpAB(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭ശ"),iifPEY9ABNzTQp(u"ࠩࡌࡊࡎࡒࡍࠨഷ"),JLoPRXt93dpAB(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫസ")]
qqhYHtCpnN = CodyfR8zIB4JS96UPivW5kXGrHa3+YXGHgQkalMIW78q1KDFTPo
yxMRrnqoNS5GTCh4K = CodyfR8zIB4JS96UPivW5kXGrHa3+pmJgTDsQvXLqCn9ocyBwG2
Hkum8ZFvxPhXWl = CodyfR8zIB4JS96UPivW5kXGrHa3+YXGHgQkalMIW78q1KDFTPo
N8lWK1vg4nwZAt2iFskB6 = bT5n6i8yjme1tP+SMAjf2CH1wmrhnDg+YExQh9CZ4ioRUmr8e1nqHl5+AlYMjfIewb0v3n6hq8sHiCpR
CUqMFh49o5xjl = [
						BGhdkWsEvJjiMFTr3NLn1flU(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭ഹ")
						,OyJ1o4AvmWlB75UkFRX(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠶ࡳࡪࠧഺ")
						,bbw2eajMlG(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐ࡙ࡑ࡚ࡉࡠ࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺ഻ࠧ")
						]
Rrwi83IBX0D2hEkmWOGa51A = [
						wwplD0tEehqH3kYQXs(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡕࡈࡒࡉࡥࡁࡏࡃࡏ࡝࡙ࡏࡃࡔࡡࡈ࡚ࡊࡔࡔ࠮࠳ࡶࡸ഼ࠬ")
						,CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡈ࡜࡙ࡘࡁࡄࡖࡢࡑ࠸࡛࠸࠮࠳ࡶࡸࠬഽ")
						,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡆࡔࡄࡐࡏࡢ࡙ࡘࡋࡒࡂࡉࡈࡒ࡙࠳࠱ࡴࡶࠪാ")
						,ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡒࡕࡓ࡝ࡏࡅࡔࡡࡏࡍࡘ࡚࠭࠲ࡵࡷࠫി")
						,pcWq35MED2dtK(u"ࠫࡎࡖࡔࡗ࠯ࡆࡌࡊࡉࡋࡠࡃࡆࡇࡔ࡛ࡎࡕ࠯࠴ࡷࡹ࠭ീ")
						,iifPEY9ABNzTQp(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡑࡏࡓࡈࡇࡔࡊࡑࡑ࠱࠶ࡹࡴࠨു")
						,ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠱ࡴࡶࠪൂ")
						,BGhdkWsEvJjiMFTr3NLn1flU(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠴ࡴࡧࠫൃ")
						,ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡉࡆࡊ࡟ࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌ࠮࠳ࡶࡸࠬൄ")
						,cNaVb1vsT4qWOL0rpE(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕ࠯࠴ࡷࡹ࠭൅")
						,XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠳ࡳࡦࠪെ")
						,drHLAY5ENQFe2q9ptKGabo(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠶ࡶ࡫ࠫേ")
						,JLoPRXt93dpAB(u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫൈ")
						]
b5vp1YMUGnxw6JtRdoDusW = Rrwi83IBX0D2hEkmWOGa51A+[
				 xuztI5QWEKG70CPNdhk4vo6(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡑࡔࡒ࡜࡞ࡥࡔࡆࡕࡗ࠱࠶ࡹࡴࠨ൉")
				,tZ3gsrTEdzA1S6LXa9WI5px(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡋࡘ࡙ࡖࡓࡑࡔࡒ࡜ࡎࡋࡓ࠮࠳ࡶࡸࠬൊ")
				,r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛ࡍࡊ࡙࠭࠲ࡵࡷࠫോ")
				,pcWq35MED2dtK(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜ࡎࡋࡓ࠮࠴ࡱࡨࠬൌ")
				,cNaVb1vsT4qWOL0rpE(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤ࡝ࡅࡃࡒࡕࡓ࡝࡟ࡔࡐ࠯࠴ࡷࡹ്࠭")
				,usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞࡙ࡕࡑ࠰࠶ࡳࡪࠧൎ")
				,bbw2eajMlG(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠵ࡸࡺࠧ൏")
				,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡍࡓࡖࡔ࡞࡙ࡄࡑࡐ࠱࠷ࡴࡤࠨ൐")
				,OyJ1o4AvmWlB75UkFRX(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡎࡔࡗࡕࡘ࡚ࡅࡒࡑ࠲࠹ࡲࡥࠩ൑")
				,qnPgZ9N15G6Oa8UpMASvLk(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡆࡌࡊࡉࡋࡠࡊࡗࡘࡕ࡙࡟ࡑࡔࡒ࡜ࡎࡋࡓ࠮࠳ࡶࡸࠬ൒")
				,CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡍ࡚ࡔࡑࡕࡢࡘࡊ࡙ࡔ࠮࠳ࡶࡸࠬ൓")
				,bbw2eajMlG(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡚ࡅࡔࡖࡢࡅࡑࡒ࡟ࡘࡇࡅࡗࡎ࡚ࡅࡔ࠯࠴ࡷࡹ࠭ൔ")
				,ggDRehOModi(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡔࡆࡕࡗࡣࡆࡒࡌࡠ࡙ࡈࡆࡘࡏࡔࡆࡕ࠰࠶ࡳࡪࠧൕ")
				,drHLAY5ENQFe2q9ptKGabo(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡖࡕࡄࡋࡊࡥࡒࡆࡒࡒࡖ࡙࠳࠱ࡴࡶࠪൖ")
				,drHLAY5ENQFe2q9ptKGabo(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡕࡔࡄࡒࡘࡒࡁࡕࡇ࠰࠵ࡸࡺࠧൗ")
				,JLoPRXt93dpAB(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈ࡚ࡊࡘࡓࡐࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩ൘")
				]
kH5Khue7Fic = [tZ3gsrTEdzA1S6LXa9WI5px(u"ࠨ࠺࠱࠼࠳࠾࠮࠹ࠩ൙"),xuztI5QWEKG70CPNdhk4vo6(u"ࠩ࠴࠲࠶࠴࠱࠯࠳ࠪ൚"),pcWq35MED2dtK(u"ࠪ࠵࠳࠶࠮࠱࠰࠴ࠫ൛"),bcgZJWV6UeNSkRA(u"ࠫ࠽࠴࠸࠯࠶࠱࠸ࠬ൜"),bbw2eajMlG(u"ࠬ࠸࠰࠹࠰࠹࠻࠳࠸࠲࠳࠰࠵࠶࠷࠭൝"),ggDRehOModi(u"࠭࠲࠱࠺࠱࠺࠼࠴࠲࠳࠲࠱࠶࠷࠶ࠧ൞")]
pgPfwZleTHVQ9a = {
			 XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧࡂࡍࡒࡅࡒ࠭ൟ")		:[yF29Xdsx35wI07Ce4(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯࠳ࡹࡶ࠰ࡱ࡯ࡨࠬൠ")]
			,tZ3gsrTEdzA1S6LXa9WI5px(u"ࠩࡄࡌ࡜ࡇࡋࠨൡ")		:[BGhdkWsEvJjiMFTr3NLn1flU(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡹ࠮ࡢࡪࡺࡥࡰࡺࡶ࠯ࡰࡨࡸࠬൢ")]
			,r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠫࡆࡑࡗࡂࡏࠪൣ")		:[Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡬࠰ࡶࡺࠬ൤")]
			,vvBChXmSty(u"࠭ࡁࡍࡃࡕࡅࡇ࠭൥")		:[XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡸࡲࡨ࠳ࡧ࡬ࡢࡴࡤࡦ࠳ࡩ࡯࡮ࠩ൦")]
			,vvBChXmSty(u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋࠪ൧")		:[bcgZJWV6UeNSkRA(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡰ࡫ࡧࡴࡪ࡯࡬࠲ࡹࡼࠧ൨")]
			,BGhdkWsEvJjiMFTr3NLn1flU(u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬ൩")		:[OyJ1o4AvmWlB75UkFRX(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡬࡮ࡣࡤࡶࡪ࡬࠮ࡤࡪࠪ൪")]
			,KKbpxUZnMcj6AJ4QdD(u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕࠪ൫")	:[qnPgZ9N15G6Oa8UpMASvLk(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡥࡷࡧࡢࡪࡥ࠰ࡸࡴࡵ࡮ࡴ࠰ࡦࡳࡲ࠭൬")]
			,BGhdkWsEvJjiMFTr3NLn1flU(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ൭")		:[cgtRBdXxSOk7WUfyDhPCls(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡦࡨࡳࡦࡧࡧ࠲ࡳ࡫ࡴࠨ൮")]
			,JLoPRXt93dpAB(u"ࠩࡅࡓࡐࡘࡁࠨ൯")		:[bbw2eajMlG(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷ࡭ࡵ࡯ࡧࡸࡲࡨ࠳ࡩ࡯࡮ࠩ൰")]
			,cgtRBdXxSOk7WUfyDhPCls(u"ࠫࡇࡘࡓࡕࡇࡍࠫ൱")		:[xuztI5QWEKG70CPNdhk4vo6(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡢࡳࡵࡷࡩ࡯࠴ࡣࡰ࡯ࠪ൲")]
			,cNaVb1vsT4qWOL0rpE(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧ൳")		:[ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠺࠰࠱࠰ࡦࡳࡲ࠭൴")]
			,PtXn0k9G3ocHRg(u"ࠨࡅࡌࡑࡆ࠺ࡕࠨ൵")		:[yruHDQOcB97ig(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࠵ࡨ࡯࡭ࡢ࠶ࡸ࠲ࡨࡵ࡭ࠨ൶")]
			,pcWq35MED2dtK(u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬ൷")		:[drHLAY5ENQFe2q9ptKGabo(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣ࠶ࡦࡩࡵ࠮ࡤࡱࡰࠫ൸")]
			,BGhdkWsEvJjiMFTr3NLn1flU(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ൹")		:[ggDRehOModi(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥࡨࡲࡵࡣ࠰ࡶ࡯࡮ࡴࠧൺ")]
			,OyJ1o4AvmWlB75UkFRX(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭ൻ")	:[pcWq35MED2dtK(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷࡺࡻ࠴ࡣࡪ࡯ࡤࡧࡱࡻࡢ࠯ࡵ࡫ࡳࡵ࠭ർ")]
			,nKLEi8CJumazx4qT(u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫൽ")		:[Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡥ࡬ࡱࡦ࡬ࡡ࡯ࡵ࠱ࡧࡴࡳࠧൾ")]
			,Tgoa16jMxvYX2(u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧൿ")	:[iifPEY9ABNzTQp(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷ࠳࠸࠱ࡱࡾ࠳ࡣࡪ࡯ࡤ࠲ࡳ࡫ࡴࠨ඀")]
			,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧඁ")		:[XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦࡴ࡯ࡸ࠰ࡦࡧࠬං")]
			,OyJ1o4AvmWlB75UkFRX(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭ඃ")	:[ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠳ࡩ࡯࡮ࠩ඄"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬ࡸࡡࡱࡪࡴࡰ࠳ࡧࡰࡪ࠰ࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠮ࡤࡱࡰࠫඅ")]
			,JLoPRXt93dpAB(u"ࠫࡉࡘࡁࡎࡃࡖ࠻ࠬආ")		:[cNaVb1vsT4qWOL0rpE(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡤ࠰ࡧࡶࡦࡳࡡࡴ࠹࠱ࡧࡴࡳࠧඇ")]
			,CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨඈ")		:[vvBChXmSty(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡰ࠰ࡩ࡬ࡿ࠮ࡣࡧࡶࡸࠬඉ")]
			,PtXn0k9G3ocHRg(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴ࠪඊ")		:[drHLAY5ENQFe2q9ptKGabo(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡦࡩࡴࡰࡴࠪඋ")]
			,nKLEi8CJumazx4qT(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷ࠬඌ")		:[cNaVb1vsT4qWOL0rpE(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡯ࡥࡨࡻࡥࡩࡸࡺ࠮ࡣ࡫ࡧࠫඍ")]
			,tZ3gsrTEdzA1S6LXa9WI5px(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧඎ")		:[pcWq35MED2dtK(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼ࠱ࡧ࡫ࡳࡵ࠰ࡱࡩࡹ࠭ඏ")]
			,cgtRBdXxSOk7WUfyDhPCls(u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨඐ")		:[InKG0i2r6hHDvgd(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾࡪࡥࡢࡦ࠱ࡰ࡮ࡼࡥࠨඑ")]
			,Tgoa16jMxvYX2(u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄࠫඒ")		:[usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡲࡣࡪࡰࡨࡱࡦ࠴ࡣࡰ࡯ࠪඓ")]
			,cNaVb1vsT4qWOL0rpE(u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬඔ")		:[CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢࡤࡵ࡯ࡦ࠴ࡣࡰ࡯ࠪඕ")]
			,qnPgZ9N15G6Oa8UpMASvLk(u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩඖ")	:[wwplD0tEehqH3kYQXs(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤ࡮ࡪࡸ࠮ࡴࡪࡲࡻࠬ඗")]
			,Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ඘")		:[r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡧࡣࡶࡩࡱ࡮ࡤ࠯࡮࡬ࡲࡰ࠭඙")]
			,Tgoa16jMxvYX2(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶ࠬක")		:[InKG0i2r6hHDvgd(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡳ࡭ࡣ࠱ࡪࡦࡹࡥ࡭ࡪࡧ࠲ࡨࡲ࡯ࡶࡦࠪඛ")]
			,vvBChXmSty(u"ࠬࡌࡏࡔࡖࡄࠫග")		:[M6PIj8gl1fno7wcqTksDEBK4bU(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹ࡭࠲࡫ࡵࡳࡵࡣ࠰ࡸࡻ࠴࡮ࡦࡶࠪඝ")]
			,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩඞ")		:[n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡫ࡥࡱࡧࡣࡪ࡯ࡤ࠲ࡲ࡫ࡤࡪࡣࠪඟ")]
			,PtXn0k9G3ocHRg(u"ࠩࡌࡊࡎࡒࡍࠨච")		:[oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸ࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫඡ"),iifPEY9ABNzTQp(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡮࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬජ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢ࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭ඣ"),cgtRBdXxSOk7WUfyDhPCls(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣ࠵࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨඤ"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠺࠵࠱࠵࠾࠶࠮࠳࠶࠱࠵࠷࠸ࠧඥ")]
			,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫඦ")	:[JLoPRXt93dpAB(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡦࡸࡢࡢ࡮ࡤ࠱ࡹࡼ࠮ࡪࡳࠪට")]
			,XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚ࠬඨ")		:[CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡭࡯ࡰ࠰࡮࡭ࡹࡱ࡯ࡵ࠰ࡷࡺࠬඩ")]
			,OyJ1o4AvmWlB75UkFRX(u"ࠬࡑࡏࡅࡋࡈࡑࡆࡊ࡟ࡂࡒࡓࠫඪ")	:[n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡵ࡫ࡱࡽ࠳ࡩࡣ࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦࠪණ"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠸࠰࠲࠺࠱ࡪࡼࡹ࠮ࡴࡶࡲࡶࡪ࠭ඬ")]
			,yruHDQOcB97ig(u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩත")		:[M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡰࡴࡪࡹ࡯ࡧࡷ࠲ࡨࡧ࡭ࠨථ")]
			,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠪࡔࡆࡔࡅࡕࠩද")		:[Tgoa16jMxvYX2(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡲࡤࡲࡪࡺ࠮ࡤࡱ࠱࡭ࡱ࠭ධ")]
			,drHLAY5ENQFe2q9ptKGabo(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧන")		:[Tgoa16jMxvYX2(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡤࡥ࠳ࡩࡡ࡮ࠩ඲")]
			,qnPgZ9N15G6Oa8UpMASvLk(u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫඳ")	:[cNaVb1vsT4qWOL0rpE(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࠲ࡸ࡮࠴ࡶ࠰ࡱࡩࡼࡹࠧප")]
			,OyJ1o4AvmWlB75UkFRX(u"ࠩࡖࡌࡔࡌࡈࡂࠩඵ")		:[Tgoa16jMxvYX2(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻ࡯ࡤ࠯ࡵ࡫ࡳ࡫࡮ࡡ࠯ࡶࡹࠫබ")]
			,usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭භ")		:[wwplD0tEehqH3kYQXs(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡥࡲࡱࠬම"),cgtRBdXxSOk7WUfyDhPCls(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡶࡤࡸ࡮ࡩ࠮ࡴࡪࡲࡳ࡫ࡳࡡࡹ࠰ࡦࡳࡲ࠭ඹ"),drHLAY5ENQFe2q9ptKGabo(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫ࡳࡴ࡬࡭ࡢࡺ࠱ࡥࡿࡻࡲࡦࡧࡧ࡫ࡪ࠴࡮ࡦࡶࠪය")]
			,tZ3gsrTEdzA1S6LXa9WI5px(u"ࠨࡖ࡙ࡊ࡚ࡔࠧර")		:[usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࠳ࡺࡶࡧࡷࡱ࠲ࡲ࡫ࠧ඼")]
			,oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࡛ࠪࡊࡉࡉࡎࡃࠪල")		:[qnPgZ9N15G6Oa8UpMASvLk(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡾ࡮࠮࠯࠰࠱࠲࠳࡮ࡻࡧࡥࡧࡦ࠻ࡧࡥ࠹ࡲࡨࡪ࠶ࡢࡪࡩ࡯࡬࠳ࡳࡹࡤ࡫࡬ࡱࡦ࠳ࡷࡦࡥ࡬࡭ࡲࡧ࠮ࡴࡪࡲࡴࠬ඾")]
			,OyJ1o4AvmWlB75UkFRX(u"ࠬ࡟ࡁࡒࡑࡗࠫ඿")		:[OyJ1o4AvmWlB75UkFRX(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡺ࠰ࡼࡥࡶࡵࡴ࠯ࡶࡹࠫව")]
			,XikqnGVSK4v9d3uUICLhDxJyt1M(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨශ")		:[ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰࠫෂ")]
			,cNaVb1vsT4qWOL0rpE(u"ࠩࡕࡉࡕࡕࡓࠨස")		:[bbw2eajMlG(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪහ"),iifPEY9ABNzTQp(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠱࠹࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠻࠲ࡽࡳ࡬ࠨළ"),cgtRBdXxSOk7WUfyDhPCls(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠲࠻࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠽࠳ࡾ࡭࡭ࠩෆ")]
			,r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠭ࡒࡆࡒࡒࡗࡤࡈࡋࡑࠩ෇")	:[tZ3gsrTEdzA1S6LXa9WI5px(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡸ࡯࠳ࡺ࡯࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬ෈"),InKG0i2r6hHDvgd(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰ࠱ࡄࡈࡉࡕࡎࡔ࠳࠻࠳ࡦࡪࡤࡰࡰࡶ࠵࠽࠴ࡸ࡮࡮ࠪ෉"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠴࠽࠴ࡧࡤࡥࡱࡱࡷ࠶࠿࠮ࡹ࡯࡯්ࠫ")]
			,drHLAY5ENQFe2q9ptKGabo(u"ࠪࡗࡔ࡛ࡒࡄࡇࡖࠫ෋")		:[ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵࡫ࡰࡦ࡬ࠫ෌"),Tgoa16jMxvYX2(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡵࡸࡶ࡬࡫࠮ࡴࡪࠪ෍"),OyJ1o4AvmWlB75UkFRX(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶ࠯ࡌࡑࡇࡍࡗࡋࡐࡐࠩ෎")]
			}
if cgtRBdXxSOk7WUfyDhPCls(u"࠲ᒟ"):
	pgPfwZleTHVQ9a[OyJ1o4AvmWlB75UkFRX(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧා")] = [InKG0i2r6hHDvgd(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪැ"),drHLAY5ENQFe2q9ptKGabo(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧෑ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭ි"),JLoPRXt93dpAB(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩී"),xuztI5QWEKG70CPNdhk4vo6(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩු"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ෕"),nKLEi8CJumazx4qT(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨූ"),yruHDQOcB97ig(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡥࡤࡴࡹࡩࡨࡢࠩ෗"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪෘ")]
	pgPfwZleTHVQ9a[ggDRehOModi(u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖࠧෙ")] = [r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧේ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫෛ"),wwplD0tEehqH3kYQXs(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪො"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭ෝ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭ෞ"),shZ9eOcN2dJnPj(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩෟ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬ෠"),InKG0i2r6hHDvgd(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭෡"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧ෢")]
else:
	pgPfwZleTHVQ9a[tZ3gsrTEdzA1S6LXa9WI5px(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭෣")] = [n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ෤"),cNaVb1vsT4qWOL0rpE(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ෥"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭෦"),PtXn0k9G3ocHRg(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ෧"),nKLEi8CJumazx4qT(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩ෨"),iifPEY9ABNzTQp(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ෩"),JLoPRXt93dpAB(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ෪"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡥࡤࡴࡹࡩࡨࡢࠩ෫"),iifPEY9ABNzTQp(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪ෬")]
	pgPfwZleTHVQ9a[r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠭෭")] = [usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭෮"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ෯"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ෰"),InKG0i2r6hHDvgd(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬ෱"),PtXn0k9G3ocHRg(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬෲ"),Tgoa16jMxvYX2(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨෳ"),xuztI5QWEKG70CPNdhk4vo6(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫ෴"),ggDRehOModi(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬ෵"),cNaVb1vsT4qWOL0rpE(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭෶")]
XzTni23psbetOyYc6HlGWBJgPmk5 = [cgtRBdXxSOk7WUfyDhPCls(u"ࠬࡒࡉࡔࡖࡓࡐࡆ࡟ࠧ෷"),bbw2eajMlG(u"࠭ࡒࡆࡒࡒࡖ࡙࡙ࠧ෸"),bcgZJWV6UeNSkRA(u"ࠧࡆࡏࡄࡍࡑ࡙ࠧ෹"),KKbpxUZnMcj6AJ4QdD(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪ෺"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩࡌࡗࡑࡇࡍࡊࡅࡖࠫ෻"),OyJ1o4AvmWlB75UkFRX(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭෼"),nKLEi8CJumazx4qT(u"ࠫࡐࡔࡏࡘࡐࡈࡖࡗࡕࡒࡔࠩ෽"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠬࡉࡁࡑࡖࡆࡌࡆ࠭෾"),OyJ1o4AvmWlB75UkFRX(u"࠭ࡔࡆࡕࡗࡍࡓࡍࠧ෿")]
sCXWyTFOq4fdm = [Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠧࡂࡆࡇࡓࡓ࡙ࠧ฀"),PtXn0k9G3ocHRg(u"ࠨࡃࡇࡈࡔࡔࡓ࠲࠺ࠪก"),pcWq35MED2dtK(u"ࠩࡄࡈࡉࡕࡎࡔ࠳࠼ࠫข")]
class vkDgHOlZEhR8TJG4A(qZzjySC63LWVAovla2TIUfpF9uxg0i):
	def __init__(fXCnj1ABdeRWiHUE9a8F0gwTrqS,*aargs,**kkwargs):
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.choiceID = -bcgZJWV6UeNSkRA(u"࠳ᒠ")
	def onClick(fXCnj1ABdeRWiHUE9a8F0gwTrqS,yEusHOnzwmgR1Xrf):
		if yEusHOnzwmgR1Xrf>=wwplD0tEehqH3kYQXs(u"࠼࠴࠶࠶ᒡ"): fXCnj1ABdeRWiHUE9a8F0gwTrqS.choiceID = yEusHOnzwmgR1Xrf-wwplD0tEehqH3kYQXs(u"࠼࠴࠶࠶ᒡ")
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.X3XmSZ8iB4fgCGuPb7xp()
	def sLJfQm8Zgp5WxOo7FKHRYlqt1(fXCnj1ABdeRWiHUE9a8F0gwTrqS,*aargs):
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.button0,fXCnj1ABdeRWiHUE9a8F0gwTrqS.button1,fXCnj1ABdeRWiHUE9a8F0gwTrqS.button2 = aargs[pcWq35MED2dtK(u"࠵ᒣ")],aargs[r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠵ᒢ")],aargs[shZ9eOcN2dJnPj(u"࠸ᒤ")]
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.header,fXCnj1ABdeRWiHUE9a8F0gwTrqS.text = aargs[vvBChXmSty(u"࠳ᒥ")],aargs[xuztI5QWEKG70CPNdhk4vo6(u"࠵ᒦ")]
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.profile,fXCnj1ABdeRWiHUE9a8F0gwTrqS.direction = aargs[vvBChXmSty(u"࠷ᒧ")],aargs[XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠹ᒨ")]
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.buttonstimeout,fXCnj1ABdeRWiHUE9a8F0gwTrqS.closetimeout = aargs[ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠼ᒪ")],aargs[wwplD0tEehqH3kYQXs(u"࠼ᒩ")]
		if fXCnj1ABdeRWiHUE9a8F0gwTrqS.buttonstimeout>PtXn0k9G3ocHRg(u"࠶ᒫ") or fXCnj1ABdeRWiHUE9a8F0gwTrqS.closetimeout>PtXn0k9G3ocHRg(u"࠶ᒫ"): fXCnj1ABdeRWiHUE9a8F0gwTrqS.enable_progressbar = n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࡙ࡸࡵࡦᛨ")
		else: fXCnj1ABdeRWiHUE9a8F0gwTrqS.enable_progressbar = JLoPRXt93dpAB(u"ࡌࡡ࡭ࡵࡨᛩ")
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.image_filename = Wgy3rdVP0HqnsA2N59FfbITu6Bh.replace(bcgZJWV6UeNSkRA(u"ࠪࡣ࠵࠶࠰࠱ࡡࠪฃ"),Tgoa16jMxvYX2(u"ࠫࡤ࠭ค")+str(YVJPFvuI2CS5KObiZt.time())+usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠬࡥࠧฅ"))
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.image_filename = fXCnj1ABdeRWiHUE9a8F0gwTrqS.image_filename.replace(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠭࡜࡝ࠩฆ"),Tgoa16jMxvYX2(u"ࠧ࡝࡞࡟ࡠࠬง")).replace(usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠨ࠱࠲ࠫจ"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࠩ࠲࠳࠴࠵ࠧฉ"))
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.image_height = WedGKhM8a0(fXCnj1ABdeRWiHUE9a8F0gwTrqS.button0,fXCnj1ABdeRWiHUE9a8F0gwTrqS.button1,fXCnj1ABdeRWiHUE9a8F0gwTrqS.button2,fXCnj1ABdeRWiHUE9a8F0gwTrqS.header,fXCnj1ABdeRWiHUE9a8F0gwTrqS.text,fXCnj1ABdeRWiHUE9a8F0gwTrqS.profile,fXCnj1ABdeRWiHUE9a8F0gwTrqS.direction,fXCnj1ABdeRWiHUE9a8F0gwTrqS.enable_progressbar,fXCnj1ABdeRWiHUE9a8F0gwTrqS.image_filename)
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.show()
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.getControl(PtXn0k9G3ocHRg(u"࠹࠱࠷࠳ᒬ")).setImage(fXCnj1ABdeRWiHUE9a8F0gwTrqS.image_filename)
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.getControl(r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠺࠲࠸࠴ᒭ")).setHeight(fXCnj1ABdeRWiHUE9a8F0gwTrqS.image_height)
		if not fXCnj1ABdeRWiHUE9a8F0gwTrqS.button1 and fXCnj1ABdeRWiHUE9a8F0gwTrqS.button0 and fXCnj1ABdeRWiHUE9a8F0gwTrqS.button2: fXCnj1ABdeRWiHUE9a8F0gwTrqS.getControl(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠼࠴࠶࠸ᒯ")).setPosition(-yF29Xdsx35wI07Ce4(u"࠶࠷࠶ᒰ"),cNaVb1vsT4qWOL0rpE(u"࠲ᒮ"))
		return fXCnj1ABdeRWiHUE9a8F0gwTrqS.image_filename,fXCnj1ABdeRWiHUE9a8F0gwTrqS.image_height
	def KevQcPqyEp0ITOo2mV6(fXCnj1ABdeRWiHUE9a8F0gwTrqS):
		if fXCnj1ABdeRWiHUE9a8F0gwTrqS.buttonstimeout:
			fXCnj1ABdeRWiHUE9a8F0gwTrqS.th1 = onVDrgLUpFsqOPkxId9BwW6Rtc5A.Thread(target=fXCnj1ABdeRWiHUE9a8F0gwTrqS.vYklWZVSC2juzTm5K1DNXw7h,args=())
			fXCnj1ABdeRWiHUE9a8F0gwTrqS.th1.start()
		else: fXCnj1ABdeRWiHUE9a8F0gwTrqS.MQsITquyAlLcf5xw43gpYan1()
	def vYklWZVSC2juzTm5K1DNXw7h(fXCnj1ABdeRWiHUE9a8F0gwTrqS):
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.getControl(yruHDQOcB97ig(u"࠾࠶࠲࠱ᒱ")).setEnabled(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࡔࡳࡷࡨᛪ"))
		for k0G4LTYt93po in range(bbw2eajMlG(u"࠷ᒲ"),fXCnj1ABdeRWiHUE9a8F0gwTrqS.buttonstimeout+bbw2eajMlG(u"࠷ᒲ")):
			YVJPFvuI2CS5KObiZt.sleep(qnPgZ9N15G6Oa8UpMASvLk(u"࠱ᒳ"))
			qjgaQ3kPMsm4NoEyYdulW6tbXV = int(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠲࠲࠳ᒴ")*k0G4LTYt93po/fXCnj1ABdeRWiHUE9a8F0gwTrqS.buttonstimeout)
			fXCnj1ABdeRWiHUE9a8F0gwTrqS.jjYSBI9rVQlGECvaw(qjgaQ3kPMsm4NoEyYdulW6tbXV)
			if fXCnj1ABdeRWiHUE9a8F0gwTrqS.choiceID>oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠲ᒵ"): break
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.MQsITquyAlLcf5xw43gpYan1()
	def yXRLJVDAWUGrCZ9a3(fXCnj1ABdeRWiHUE9a8F0gwTrqS):
		if fXCnj1ABdeRWiHUE9a8F0gwTrqS.closetimeout:
			fXCnj1ABdeRWiHUE9a8F0gwTrqS.th2 = onVDrgLUpFsqOPkxId9BwW6Rtc5A.Thread(target=fXCnj1ABdeRWiHUE9a8F0gwTrqS.U2O1cmw7YHlhQzok4P9Lb5SAtxRTI,args=())
			fXCnj1ABdeRWiHUE9a8F0gwTrqS.th2.start()
		else: fXCnj1ABdeRWiHUE9a8F0gwTrqS.MQsITquyAlLcf5xw43gpYan1()
	def U2O1cmw7YHlhQzok4P9Lb5SAtxRTI(fXCnj1ABdeRWiHUE9a8F0gwTrqS):
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.getControl(BGhdkWsEvJjiMFTr3NLn1flU(u"࠼࠴࠷࠶ᒶ")).setEnabled(bbw2eajMlG(u"ࡕࡴࡸࡩ᛫"))
		YVJPFvuI2CS5KObiZt.sleep(fXCnj1ABdeRWiHUE9a8F0gwTrqS.buttonstimeout)
		for k0G4LTYt93po in range(fXCnj1ABdeRWiHUE9a8F0gwTrqS.closetimeout-wwplD0tEehqH3kYQXs(u"࠵ᒷ"),-wwplD0tEehqH3kYQXs(u"࠵ᒷ"),-wwplD0tEehqH3kYQXs(u"࠵ᒷ")):
			YVJPFvuI2CS5KObiZt.sleep(yF29Xdsx35wI07Ce4(u"࠶ᒸ"))
			qjgaQ3kPMsm4NoEyYdulW6tbXV = int(PtXn0k9G3ocHRg(u"࠷࠰࠱ᒹ")*k0G4LTYt93po/fXCnj1ABdeRWiHUE9a8F0gwTrqS.closetimeout)
			fXCnj1ABdeRWiHUE9a8F0gwTrqS.jjYSBI9rVQlGECvaw(qjgaQ3kPMsm4NoEyYdulW6tbXV)
			if fXCnj1ABdeRWiHUE9a8F0gwTrqS.choiceID>PtXn0k9G3ocHRg(u"࠰ᒺ"): break
		if fXCnj1ABdeRWiHUE9a8F0gwTrqS.closetimeout>CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠱ᒻ"): fXCnj1ABdeRWiHUE9a8F0gwTrqS.choiceID = InKG0i2r6hHDvgd(u"࠳࠳ᒼ")
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.X3XmSZ8iB4fgCGuPb7xp()
	def jjYSBI9rVQlGECvaw(fXCnj1ABdeRWiHUE9a8F0gwTrqS,qjgaQ3kPMsm4NoEyYdulW6tbXV):
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.precent = qjgaQ3kPMsm4NoEyYdulW6tbXV
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.getControl(shZ9eOcN2dJnPj(u"࠼࠴࠷࠶ᒽ")).setPercent(fXCnj1ABdeRWiHUE9a8F0gwTrqS.precent)
	def MQsITquyAlLcf5xw43gpYan1(fXCnj1ABdeRWiHUE9a8F0gwTrqS):
		if fXCnj1ABdeRWiHUE9a8F0gwTrqS.button0: fXCnj1ABdeRWiHUE9a8F0gwTrqS.getControl(wwplD0tEehqH3kYQXs(u"࠽࠵࠷࠰ᒾ")).setEnabled(BGhdkWsEvJjiMFTr3NLn1flU(u"ࡖࡵࡹࡪ᛬"))
		if fXCnj1ABdeRWiHUE9a8F0gwTrqS.button1: fXCnj1ABdeRWiHUE9a8F0gwTrqS.getControl(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠾࠶࠱࠲ᒿ")).setEnabled(qnPgZ9N15G6Oa8UpMASvLk(u"ࡗࡶࡺ࡫᛭"))
		if fXCnj1ABdeRWiHUE9a8F0gwTrqS.button2: fXCnj1ABdeRWiHUE9a8F0gwTrqS.getControl(drHLAY5ENQFe2q9ptKGabo(u"࠿࠰࠲࠴ᓀ")).setEnabled(pcWq35MED2dtK(u"ࡘࡷࡻࡥᛮ"))
	def X3XmSZ8iB4fgCGuPb7xp(fXCnj1ABdeRWiHUE9a8F0gwTrqS):
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.close()
		try: k1t0JLRsCQ.remove(fXCnj1ABdeRWiHUE9a8F0gwTrqS.image_filename)
		except: pass
class NNdsp2w4g0ObWUVv7():
	def __init__(fXCnj1ABdeRWiHUE9a8F0gwTrqS,showDialogs=ggDRehOModi(u"ࡌࡡ࡭ࡵࡨᛰ"),logErrors=JLoPRXt93dpAB(u"࡙ࡸࡵࡦᛯ")):
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.showDialogs = showDialogs
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.logErrors = logErrors
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.finishedLIST,fXCnj1ABdeRWiHUE9a8F0gwTrqS.failedLIST = [],[]
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.statusDICT,fXCnj1ABdeRWiHUE9a8F0gwTrqS.resultsDICT = {},{}
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.processesLIST = []
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.starttimeDICT,fXCnj1ABdeRWiHUE9a8F0gwTrqS.finishtimeDICT,fXCnj1ABdeRWiHUE9a8F0gwTrqS.elpasedtimeDICT = {},{},{}
	def WJXV7aSiyDcORrlC(fXCnj1ABdeRWiHUE9a8F0gwTrqS,oSXwLI6yv7E8RPW9h,zE2sXM7W31tB8UJk9Q,*aargs):
		oSXwLI6yv7E8RPW9h = str(oSXwLI6yv7E8RPW9h)
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.statusDICT[oSXwLI6yv7E8RPW9h] = InKG0i2r6hHDvgd(u"ࠪࡶࡺࡴ࡮ࡪࡰࡪࠫช")
		if fXCnj1ABdeRWiHUE9a8F0gwTrqS.showDialogs: dnS80F92qtLi4vw1(InKG0i2r6hHDvgd(u"ࠫࠬซ"),oSXwLI6yv7E8RPW9h)
		wGq2JfjSiF = onVDrgLUpFsqOPkxId9BwW6Rtc5A.Thread(target=fXCnj1ABdeRWiHUE9a8F0gwTrqS.ga3TAKMd29uOliDWkr,args=(oSXwLI6yv7E8RPW9h,zE2sXM7W31tB8UJk9Q,aargs))
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.processesLIST.append(wGq2JfjSiF)
		return wGq2JfjSiF
	def H3bQD56wsB(fXCnj1ABdeRWiHUE9a8F0gwTrqS,oSXwLI6yv7E8RPW9h,zE2sXM7W31tB8UJk9Q,*aargs):
		wGq2JfjSiF = fXCnj1ABdeRWiHUE9a8F0gwTrqS.WJXV7aSiyDcORrlC(oSXwLI6yv7E8RPW9h,zE2sXM7W31tB8UJk9Q,*aargs)
		wGq2JfjSiF.start()
	def ga3TAKMd29uOliDWkr(fXCnj1ABdeRWiHUE9a8F0gwTrqS,oSXwLI6yv7E8RPW9h,zE2sXM7W31tB8UJk9Q,aargs):
		oSXwLI6yv7E8RPW9h = str(oSXwLI6yv7E8RPW9h)
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.starttimeDICT[oSXwLI6yv7E8RPW9h] = YVJPFvuI2CS5KObiZt.time()
		try:
			fXCnj1ABdeRWiHUE9a8F0gwTrqS.resultsDICT[oSXwLI6yv7E8RPW9h] = zE2sXM7W31tB8UJk9Q(*aargs)
			if Tgoa16jMxvYX2(u"ࠬࡕࡐࡆࡐࡘࡖࡑ࠭ฌ") in str(zE2sXM7W31tB8UJk9Q) and not fXCnj1ABdeRWiHUE9a8F0gwTrqS.resultsDICT[oSXwLI6yv7E8RPW9h].succeeded:
				vS1seWj2c0tKyZ(JLoPRXt93dpAB(u"࠭ࡆࡰࡴࡦࡩࡩࠦࡥࡹ࡫ࡷࠤࡩࡻࡥࠡࡶࡲࠤࡹ࡮ࡲࡦࡣࡧࡩࡩࠦࡏࡑࡇࡑ࡙ࡗࡒࠠࡧࡣ࡬ࡰࠬญ"))
			fXCnj1ABdeRWiHUE9a8F0gwTrqS.finishedLIST.append(oSXwLI6yv7E8RPW9h)
			fXCnj1ABdeRWiHUE9a8F0gwTrqS.statusDICT[oSXwLI6yv7E8RPW9h] = nKLEi8CJumazx4qT(u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࠩฎ")
		except Exception as PqOkienNW3ToVcX1ZM8Q:
			if fXCnj1ABdeRWiHUE9a8F0gwTrqS.logErrors:
				LdvB61qxSDsOWlhmXnAgozEfPp4Ky = BPSEU6WvQRnxV.format_exc()
				if LdvB61qxSDsOWlhmXnAgozEfPp4Ky!=XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠨࡐࡲࡲࡪ࡚ࡹࡱࡧ࠽ࠤࡓࡵ࡮ࡦ࡞ࡱࠫฏ"): vdo2FnhPmAVRMJQZ0EIG8.stderr.write(LdvB61qxSDsOWlhmXnAgozEfPp4Ky)
			fXCnj1ABdeRWiHUE9a8F0gwTrqS.failedLIST.append(oSXwLI6yv7E8RPW9h)
			fXCnj1ABdeRWiHUE9a8F0gwTrqS.statusDICT[oSXwLI6yv7E8RPW9h] = wwplD0tEehqH3kYQXs(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩฐ")
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.finishtimeDICT[oSXwLI6yv7E8RPW9h] = YVJPFvuI2CS5KObiZt.time()
		fXCnj1ABdeRWiHUE9a8F0gwTrqS.elpasedtimeDICT[oSXwLI6yv7E8RPW9h] = fXCnj1ABdeRWiHUE9a8F0gwTrqS.finishtimeDICT[oSXwLI6yv7E8RPW9h] - fXCnj1ABdeRWiHUE9a8F0gwTrqS.starttimeDICT[oSXwLI6yv7E8RPW9h]
	def K5TIauFsC1A(fXCnj1ABdeRWiHUE9a8F0gwTrqS):
		for csgwhY93Q0D2MCZmeKWkqH8 in fXCnj1ABdeRWiHUE9a8F0gwTrqS.processesLIST:
			csgwhY93Q0D2MCZmeKWkqH8.start()
	def QGIoepSDgO9s(fXCnj1ABdeRWiHUE9a8F0gwTrqS):
		while vvBChXmSty(u"ࠪࡶࡺࡴ࡮ࡪࡰࡪࠫฑ") in list(fXCnj1ABdeRWiHUE9a8F0gwTrqS.statusDICT.values()): YVJPFvuI2CS5KObiZt.sleep(InKG0i2r6hHDvgd(u"࠱࠯࠲࠳࠴ᓁ"))
def MYXlJV9eHk8my4ZEICfu0iKrT2q():
	qsweAy3DUxWL = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠫࡦࡼ࠮ࡷࡧࡵࡷ࡮ࡵ࡮ࠨฒ"))
	if qsweAy3DUxWL==qkSQU3saP0D7OvynNzH4F2BKJuilT:
		ovhCxDdpsaMyezP82wT3j9Jq,eeYoW6fXUyO0rCSkz = oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠬࡔࡏࡠࡗࡓࡈࡆ࡚ࡅࠨณ"),bcgZJWV6UeNSkRA(u"ࡆࡢ࡮ࡶࡩᛱ")
		return ovhCxDdpsaMyezP82wT3j9Jq,eeYoW6fXUyO0rCSkz
	try: k1t0JLRsCQ.makedirs(OxWkR7Eu9Pm3IAvTp0q)
	except: pass
	ovhCxDdpsaMyezP82wT3j9Jq,eeYoW6fXUyO0rCSkz = oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠭ࡆࡖࡎࡏࡣ࡚ࡖࡄࡂࡖࡈࠫด"),yF29Xdsx35wI07Ce4(u"ࡕࡴࡸࡩᛲ")
	wcrGEjqNdk4RWQL = [oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠧ࠹࠰࠸࠲࠵࠭ต"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠨ࠴࠳࠶࠶࠴࠱࠱࠰࠴࠽ࠬถ"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠩ࠵࠴࠷࠷࠮࠲࠳࠱࠶࠹ࡧࠧท"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠪ࠶࠵࠸࠱࠯࠳࠵࠲࠸࠶ࠧธ"),vvBChXmSty(u"ࠫ࠷࠶࠲࠳࠰࠳࠶࠳࠶࠲ࠨน"),pcWq35MED2dtK(u"ࠬ࠸࠰࠳࠴࠱࠵࠵࠴࠲࠳ࠩบ"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠭࠲࠱࠴࠶࠲࠵࠹࠮࠱࠸ࠪป"),OyJ1o4AvmWlB75UkFRX(u"ࠧ࠳࠲࠵࠷࠳࠶࠵࠯࠳࠹ࠫผ"),pcWq35MED2dtK(u"ࠨ࠴࠳࠶࠸࠴࠰࠷࠰࠳࠺ࠬฝ"),yruHDQOcB97ig(u"ࠩ࠵࠴࠷࠹࠮࠲࠲࠱࠶࠽࠭พ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠪ࠶࠵࠸࠴࠯࠲࠴࠲࠶࠺ࠧฟ")]
	FJLnSUaHtVNcyjsiEABKZpM48XuC = wcrGEjqNdk4RWQL[-oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠲ᓂ")]
	VVoqeREi3lhZFBujpW5TdQfx1M = jMVWv8Hnk5Z6Ibhz2uYQomafJrg(FJLnSUaHtVNcyjsiEABKZpM48XuC)
	mvye8AjLC2wpZn1UYt = jMVWv8Hnk5Z6Ibhz2uYQomafJrg(qkSQU3saP0D7OvynNzH4F2BKJuilT)
	if mvye8AjLC2wpZn1UYt>VVoqeREi3lhZFBujpW5TdQfx1M:
		ovhCxDdpsaMyezP82wT3j9Jq = iifPEY9ABNzTQp(u"ࠫࡘࡏࡍࡑࡎࡈࡣ࡚ࡖࡄࡂࡖࡈࠫภ")
	return ovhCxDdpsaMyezP82wT3j9Jq,eeYoW6fXUyO0rCSkz
def NLB1OnfGmhoFMd5u94tzesi():
	if BGhdkWsEvJjiMFTr3NLn1flU(u"࠳ᓃ"):
		StCKFI7b5G6vfgVDe = cgtRBdXxSOk7WUfyDhPCls(u"࠳ᓄ")
		for D9sahrGnjl,zzO5Jhgo8A,Yugbp5vmkGExP3BwhcJ0Z14Hzyf in k1t0JLRsCQ.walk(yZKq8SbJduiIwcHMOz6gN,topdown=iifPEY9ABNzTQp(u"ࡈࡤࡰࡸ࡫ᛳ")):
			StCKFI7b5G6vfgVDe += len(Yugbp5vmkGExP3BwhcJ0Z14Hzyf)
	if StCKFI7b5G6vfgVDe>Tgoa16jMxvYX2(u"࠹࠵࠶࠰ᓅ"): DzIGOoUJcZT9tQeuX3RyY(yZKq8SbJduiIwcHMOz6gN,xuztI5QWEKG70CPNdhk4vo6(u"ࡘࡷࡻࡥᛵ"),shZ9eOcN2dJnPj(u"ࡉࡥࡱࡹࡥᛴ"))
	return
def DB4TY9qlwEJ(ttpQZRUwEjhfdOqn,eDvzfWdXZnlMEiboY5j1P):
	V5VXz0j3oa6t,mJXMyc9qFDbnif8LEz0hgSt3w5,e3jIULCymkiwXQG = CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࡚ࡲࡶࡧᛷ"),vvBChXmSty(u"ࡋࡧ࡬ࡴࡧᛶ"),vvBChXmSty(u"ࡋࡧ࡬ࡴࡧᛶ")
	afxYgsnGTdAHePVBK,ffAnyTIUapotW4dS6sbC,nJZr96iD14wfebYudRShUFyHjkzAo,Fx86vaQXEZeSBDAhmgC9zl7j2fs,E6T9RGlrWixPbQVMBIJzh8eYHwkAL,gwiP7zvsEaOMJnkBHpAqy8eYNR,TwPt5qAHlrOsQ,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv = ttpQZRUwEjhfdOqn
	G5praJPWcqo = afxYgsnGTdAHePVBK,ffAnyTIUapotW4dS6sbC,nJZr96iD14wfebYudRShUFyHjkzAo,Fx86vaQXEZeSBDAhmgC9zl7j2fs,E6T9RGlrWixPbQVMBIJzh8eYHwkAL,gwiP7zvsEaOMJnkBHpAqy8eYNR,TwPt5qAHlrOsQ,Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠬ࠭ม"),aiSY4yFdLmPH2zenlMpv
	KalY9RbZWxhOsV0 = int(Fx86vaQXEZeSBDAhmgC9zl7j2fs)
	DRpoVrUhjslEz2Otwn60J = int(KalY9RbZWxhOsV0%ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠶࠶ᓆ"))
	NjQaSix1UCsEclTfwRX = int(KalY9RbZWxhOsV0/nKLEi8CJumazx4qT(u"࠷࠰ᓇ"))
	pu2Fh4BUxasY = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(qnPgZ9N15G6Oa8UpMASvLk(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭ย"))
	if not pu2Fh4BUxasY: LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫ࠧร"),drHLAY5ENQFe2q9ptKGabo(u"ࠨࡃࡘࡘࡔ࠭ฤ"))
	mC5pfMaeJql,eeYoW6fXUyO0rCSkz = MYXlJV9eHk8my4ZEICfu0iKrT2q()
	if eeYoW6fXUyO0rCSkz:
		xl9MFt1AmY0GrkENug8n(drHLAY5ENQFe2q9ptKGabo(u"ࠩࠪล"),ggDRehOModi(u"ࠪࠫฦ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧว"),xuztI5QWEKG70CPNdhk4vo6(u"ࠬะๅࠡฬะำ๏ัࠠศๆหี๋อๅอࠢไ๎ࠥา็ศิๆࡠࡳหไ๊ࠢส่ส฻ฯศำࠣี็๋࠺࡝ࡰ࡟ࡲࠬศ")+qkSQU3saP0D7OvynNzH4F2BKJuilT)
		ZqlR5BFQ6pm0asCHLUc(bpNSygerL10j4IOkEfuVw,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩษ"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪส"))
		ZqlR5BFQ6pm0asCHLUc(bpNSygerL10j4IOkEfuVw,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫห"),yruHDQOcB97ig(u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪฬ"))
		ZqlR5BFQ6pm0asCHLUc(bpNSygerL10j4IOkEfuVw,Tgoa16jMxvYX2(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭อ"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࠫࡘࡏࡔࡆࡕࡢࡒࡆࡓࡅࡔࠩฮ"))
		ZqlR5BFQ6pm0asCHLUc(bpNSygerL10j4IOkEfuVw,r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨฯ"),yruHDQOcB97ig(u"࠭ࡓࡊࡖࡈࡗࡤࡉࡈࡆࡅࡎࠫะ"))
		ZqlR5BFQ6pm0asCHLUc(bpNSygerL10j4IOkEfuVw,Tgoa16jMxvYX2(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪั"),bcgZJWV6UeNSkRA(u"ࠨࡕࡌࡘࡊ࡙࡟ࡗࡇࡕࡍࡋ࡟ࠧา"))
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(KKbpxUZnMcj6AJ4QdD(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡪࡴࡹࡴࡢࠩำ"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠪࠫิ"))
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(bbw2eajMlG(u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࡬ࡡࡣࡴࡤ࡯ࡦ࠭ี"),cNaVb1vsT4qWOL0rpE(u"ࠬ࠭ึ"))
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(bcgZJWV6UeNSkRA(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩื"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠧࠨุ"))
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡩࡥࡸ࡫࡬ࡩࡦ࠴ูࠫ"),pcWq35MED2dtK(u"ฺࠩࠪ"))
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(yruHDQOcB97ig(u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷࠬ฻"),bbw2eajMlG(u"ࠫࠬ฼"))
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(cNaVb1vsT4qWOL0rpE(u"ࠬࡧࡶ࠯ࡲࡨࡶ࡮ࡵࡤ࠯࡫ࡱࡪࡴࡹࠧ฽"),PtXn0k9G3ocHRg(u"࠭ࠧ฾"))
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡬ࡰࡰࡪࠫ฿"),InKG0i2r6hHDvgd(u"ࠨࠩเ"))
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡴࡨ࡫ࡺࡲࡡࡳࠩแ"),bbw2eajMlG(u"ࠪࠫโ"))
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡱࡪࡹࡳࡢࡩࡨࡷࠬใ"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠬ࠭ไ"))
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(vvBChXmSty(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨๅ"),vvBChXmSty(u"ࠧࠨๆ"))
		import y5yjS2UFkc
		if mC5pfMaeJql==iifPEY9ABNzTQp(u"ࠨࡕࡌࡑࡕࡒࡅࡠࡗࡓࡈࡆ࡚ࡅࠨ็"):
			l0SAerv8zGH2Wa(M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠩࡑࡓ࡙ࡏࡃࡆ่ࠩ"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠪ࠲ࠥࠦࡁࡳࡣࡥ࡭ࡨ࡜ࡩࡥࡧࡲࡷ࡛ࠥࡰࡥࡣࡷࡩ࡚ࠥࡹࡱࡧ࠽ࠤ࡙ࠥࡉࡎࡒࡏࡉ࡛ࠥࡐࡅࡃࡗࡉࠥࠦࠠࡑࡣࡷ࡬࠿้࡛ࠦࠡࠩ")+O0Dm45eTJi8rlWUCQLbMducERHp+ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠫࠥࡣ๊ࠧ"))
			ZqlR5BFQ6pm0asCHLUc(bpNSygerL10j4IOkEfuVw,xuztI5QWEKG70CPNdhk4vo6(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘ๋࠭"))
			ZqlR5BFQ6pm0asCHLUc(bpNSygerL10j4IOkEfuVw,yF29Xdsx35wI07Ce4(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛࠭์"))
			ZqlR5BFQ6pm0asCHLUc(bpNSygerL10j4IOkEfuVw,iifPEY9ABNzTQp(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚࠭ํ"))
			Ng2cPah6pJKD3YTjFX0lyfVbs5(vvBChXmSty(u"ࡔࡳࡷࡨᛸ"),[bpNSygerL10j4IOkEfuVw])
		else:
			l0SAerv8zGH2Wa(pcWq35MED2dtK(u"ࠨࡐࡒࡘࡎࡉࡅࠨ๎"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠩ࠱ࠤࠥࡇࡲࡢࡤ࡬ࡧ࡛࡯ࡤࡦࡱࡶࠤ࡚ࡶࡤࡢࡶࡨࠤ࡙ࡿࡰࡦ࠼ࠣࠤࡋ࡛ࡌࡍࠢࡘࡔࡉࡇࡔࡆࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭๏")+O0Dm45eTJi8rlWUCQLbMducERHp+bbw2eajMlG(u"ࠪࠤࡢ࠭๐"))
			xl9MFt1AmY0GrkENug8n(pcWq35MED2dtK(u"ࠫࠬ๑"),InKG0i2r6hHDvgd(u"ࠬ࠭๒"),bcgZJWV6UeNSkRA(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ๓"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠧห็ࠣฮะฮ๊หࠢฦ์ࠥะอะ์ฮࠤฬ๊ลึัสีࠥอไอัํำ๊ࠥศา่ส้ัࠦวๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠤ࠳ࠦร้ࠢอ้๋ࠥำฮࠢๆหูࠦวๅสิ๊ฬ๋ฬࠡ࡞ࡱࡠࡳࠦำ๋ไ๋้ࠥอไร่ࠣห้ฮั็ษ่ะࠥฮศฺุࠣห้็อ้ืสฮ๊ࠥึๆษ้ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣฬฺ๎ัสุࠢั๏ำษ๊่ࠡฮ่อๅๅหࠪ๔"))
			Ng2cPah6pJKD3YTjFX0lyfVbs5(M6PIj8gl1fno7wcqTksDEBK4bU(u"ࡇࡣ࡯ࡷࡪ᛹"),[])
			tBUYedV3Q4FcLRwEx2DnMilz6(cNaVb1vsT4qWOL0rpE(u"ࡈࡤࡰࡸ࡫᛺"))
			y5yjS2UFkc.Z9XBVaT4mCf8sSn1yLidrOvj()
			y5yjS2UFkc.tj2FJQMlTw(drHLAY5ENQFe2q9ptKGabo(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ๕"),yF29Xdsx35wI07Ce4(u"ࡉࡥࡱࡹࡥ᛻"))
			y5yjS2UFkc.tj2FJQMlTw(vvBChXmSty(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡳࡶࡰࡴࠬ๖"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࡊࡦࡲࡳࡦ᛼"))
			y5yjS2UFkc.gYUJEp5XQMGC0PjLTdO7BV(yruHDQOcB97ig(u"ࡋࡧ࡬ࡴࡧ᛽"))
			y5yjS2UFkc.UOit806xldSDeARyX1waB5Jqs(OyJ1o4AvmWlB75UkFRX(u"ࡌࡡ࡭ࡵࡨ᛾"))
			y5yjS2UFkc.uckn8TNJ3yijvBF(PtXn0k9G3ocHRg(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ๗"),pcWq35MED2dtK(u"ࠫࡪࡴࡡࡣ࡮ࡨࠫ๘"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࡆࡢ࡮ࡶࡩ᛿"))
			try:
				kk1RoQWbLzYIxSD2hdgcKUGZaTlAn = k1t0JLRsCQ.path.join(r4roga1DYEwG,yF29Xdsx35wI07Ce4(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ๙"),M6PIj8gl1fno7wcqTksDEBK4bU(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ๚"),yF29Xdsx35wI07Ce4(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫ๛"),KKbpxUZnMcj6AJ4QdD(u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧ๜"))
				ahQ1SHV8fo5CzqdIXEysBZpDGi6PxO = kmUVwglqCI7Q.Addon(id=ggDRehOModi(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭๝"))
				ahQ1SHV8fo5CzqdIXEysBZpDGi6PxO.setSetting(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠪࡥࡻ࠴ࡡࡶࡶࡲࡣࡵ࡯ࡣ࡬ࠩ๞"),PtXn0k9G3ocHRg(u"ࠫ࡫ࡧ࡬ࡴࡧࠪ๟"))
			except: pass
			try:
				kk1RoQWbLzYIxSD2hdgcKUGZaTlAn = k1t0JLRsCQ.path.join(r4roga1DYEwG,XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ๠"),JLoPRXt93dpAB(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ๡"),xuztI5QWEKG70CPNdhk4vo6(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦ࡯ࠫ๢"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧ๣"))
				ahQ1SHV8fo5CzqdIXEysBZpDGi6PxO = kmUVwglqCI7Q.Addon(id=qnPgZ9N15G6Oa8UpMASvLk(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡱ࠭๤"))
				ahQ1SHV8fo5CzqdIXEysBZpDGi6PxO.setSetting(iifPEY9ABNzTQp(u"ࠪࡥࡻ࠴ࡶࡪࡦࡨࡳࡤࡷࡵࡢ࡮࡬ࡸࡾ࠭๥"),yruHDQOcB97ig(u"ࠫ࠸࠭๦"))
			except: pass
			try:
				kk1RoQWbLzYIxSD2hdgcKUGZaTlAn = k1t0JLRsCQ.path.join(r4roga1DYEwG,r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ๧"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ๨"),wwplD0tEehqH3kYQXs(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ๩"),bbw2eajMlG(u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧ๪"))
				ahQ1SHV8fo5CzqdIXEysBZpDGi6PxO = kmUVwglqCI7Q.Addon(id=KKbpxUZnMcj6AJ4QdD(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ๫"))
				ahQ1SHV8fo5CzqdIXEysBZpDGi6PxO.setSetting(BGhdkWsEvJjiMFTr3NLn1flU(u"ࠪࡥࡻ࠴ࡓࡕࡔࡈࡅࡒ࡙ࡅࡍࡇࡆࡘࡎࡕࡎࠨ๬"),shZ9eOcN2dJnPj(u"ࠫ࠷࠭๭"))
			except: pass
		MNWrTo98GZHn = kI2poxnvzLZ0Yg8e1scBKy(s1KMjlEIH9vd)
		MNWrTo98GZHn = kI2poxnvzLZ0Yg8e1scBKy(MZabdxfVE5WJwUu)
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(bbw2eajMlG(u"ࠬࡧࡶ࠯ࡸࡨࡶࡸ࡯࡯࡯ࠩ๮"),qkSQU3saP0D7OvynNzH4F2BKJuilT)
		y5yjS2UFkc.GUYNM7h6W4QOlH208ZyiTnRJP3rBm(cNaVb1vsT4qWOL0rpE(u"ࡇࡣ࡯ࡷࡪᜀ"))
		return
	hPvDUWG0xTNq6kC = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(BGhdkWsEvJjiMFTr3NLn1flU(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪ๯"))
	HjxmCcWZQhX8zaJNUvsg5yGib0P = XuE2yABLxYP(eDvzfWdXZnlMEiboY5j1P)
	QG4JKD1kYXNazgnxlPr9WFRZ = XuE2yABLxYP(ffAnyTIUapotW4dS6sbC)
	PSWD68pnCMqXV3UJeAcQyo = [BGhdkWsEvJjiMFTr3NLn1flU(u"࠰ᓏ"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠲࠷ᓉ"),pcWq35MED2dtK(u"࠳࠺ᓊ"),qnPgZ9N15G6Oa8UpMASvLk(u"࠴࠽ᓋ"),BGhdkWsEvJjiMFTr3NLn1flU(u"࠲࠷ᓈ"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠹࠴ᓎ"),ggDRehOModi(u"࠹࠵ᓌ"),tZ3gsrTEdzA1S6LXa9WI5px(u"࠺࠹ᓍ")]
	FickHJQh03oUynIW5p = [iifPEY9ABNzTQp(u"࠱ᓗ"),bcgZJWV6UeNSkRA(u"࠳࠸ᓑ"),pcWq35MED2dtK(u"࠴࠻ᓒ"),OyJ1o4AvmWlB75UkFRX(u"࠵࠾ᓓ"),cgtRBdXxSOk7WUfyDhPCls(u"࠳࠸ᓐ"),iifPEY9ABNzTQp(u"࠳࠵ᓖ"),drHLAY5ENQFe2q9ptKGabo(u"࠺࠶ᓔ"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠻࠳ᓕ")]
	C5IHhQb0xFtdceGk = NjQaSix1UCsEclTfwRX not in FickHJQh03oUynIW5p
	fayPcCVQA3HD5 = NjQaSix1UCsEclTfwRX in [cNaVb1vsT4qWOL0rpE(u"࠷࠹ᓛ"),cNaVb1vsT4qWOL0rpE(u"࠴࠻ᓘ"),BGhdkWsEvJjiMFTr3NLn1flU(u"࠻࠶ᓚ"),InKG0i2r6hHDvgd(u"࠺࠶ᓙ")]
	zufU5kAr9NScaCM76Km8lFeO3BHG = KalY9RbZWxhOsV0 in [cgtRBdXxSOk7WUfyDhPCls(u"࠲࠷࠷ᓝ"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠸࠷࠱ᓜ")]
	ZdQBVeW2693O8v = (C5IHhQb0xFtdceGk or fayPcCVQA3HD5) and not zufU5kAr9NScaCM76Km8lFeO3BHG
	YolX0ad96AsHPSBG = hPvDUWG0xTNq6kC!=cgtRBdXxSOk7WUfyDhPCls(u"ࠧࡓࡇࡉࡖࡊ࡙ࡈࡆࡆࠪ๰") and (hPvDUWG0xTNq6kC or not Dm9TblyAjE0tFeO)
	bxCRN0SQLHDuWj4pUG = pcWq35MED2dtK(u"ࠨࡶࡼࡴࡪࡃࠧ๱") in hPvDUWG0xTNq6kC
	imHK80V2SX = KalY9RbZWxhOsV0 in [JLoPRXt93dpAB(u"࠵࠻࠷ᓨ"),yF29Xdsx35wI07Ce4(u"࠶࠼࠲ᓩ"),wwplD0tEehqH3kYQXs(u"࠷࠶࠴ᓪ"),yF29Xdsx35wI07Ce4(u"࠱࠷࠶ᓤ"),cNaVb1vsT4qWOL0rpE(u"࠲࠸࠸ᓥ"),Tgoa16jMxvYX2(u"࠳࠹࠺ᓦ"),BGhdkWsEvJjiMFTr3NLn1flU(u"࠴࠺࠼ᓧ"),cNaVb1vsT4qWOL0rpE(u"࠷࠶࠹ᓣ"),ggDRehOModi(u"࠺࠺࠶ᓠ"),nKLEi8CJumazx4qT(u"࠸࠸࠵ᓞ"),wwplD0tEehqH3kYQXs(u"࠹࠹࠷ᓟ"),BGhdkWsEvJjiMFTr3NLn1flU(u"࠻࠻࠺ᓡ"),bcgZJWV6UeNSkRA(u"࠼࠼࠵ᓢ")]
	bB8m3r5asjpdG0ulEJg = DRpoVrUhjslEz2Otwn60J==shZ9eOcN2dJnPj(u"࠹ᓫ") or KalY9RbZWxhOsV0 in [bcgZJWV6UeNSkRA(u"࠳࠷࠹ᓭ"),nKLEi8CJumazx4qT(u"࠹࠶࠼ᓯ"),BGhdkWsEvJjiMFTr3NLn1flU(u"࠸࠶࠸ᓮ"),InKG0i2r6hHDvgd(u"࠵࠷ᓬ")]
	NBVcKPHDyRYaEXS9sx = not imHK80V2SX
	OOsk2nfzgpV9YaCJ = not bB8m3r5asjpdG0ulEJg
	gf16rveC0DjTqx7VW = HjxmCcWZQhX8zaJNUvsg5yGib0P in [OyJ1o4AvmWlB75UkFRX(u"ࠩࠪ๲"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠪ࠲࠳࠭๳")]
	G0GineCjXgsFhSTd3PO7pt = gf16rveC0DjTqx7VW or NBVcKPHDyRYaEXS9sx
	CPEWriztI1KFQ5 = gf16rveC0DjTqx7VW or OOsk2nfzgpV9YaCJ or bxCRN0SQLHDuWj4pUG
	JuEsRLq2aNvdC = KalY9RbZWxhOsV0 not in [ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠴࠹࠴ᓴ"),OyJ1o4AvmWlB75UkFRX(u"࠷࠼࠱ᓰ"),shZ9eOcN2dJnPj(u"࠵࠺࠺ᓵ"),yruHDQOcB97ig(u"࠲࠸࠲ᓲ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠹࠳࠱ᓱ"),nKLEi8CJumazx4qT(u"࠶࠶࠳ᓳ")]
	if pu2Fh4BUxasY==r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠫࡘ࡚ࡏࡑࠩ๴"): WWHczRGVbf4p5 = bB8m3r5asjpdG0ulEJg or imHK80V2SX
	else: WWHczRGVbf4p5 = Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࡖࡵࡹࡪᜁ")
	E6KGMNTcHU = NjQaSix1UCsEclTfwRX in [oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠼࠺ᓷ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠻࠺ᓶ")]
	Ibo9Y2mu6eTjdkPFgxGEKraVB = KalY9RbZWxhOsV0 in [vvBChXmSty(u"࠸࠸࠱ᓸ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"࠷࠳࠲ᓹ")]
	MiAEK6gyIx8LpGZaFwnCsmTouUd = not E6KGMNTcHU and not Ibo9Y2mu6eTjdkPFgxGEKraVB
	jAYb2eymJCu5UMngp4 = G0GineCjXgsFhSTd3PO7pt and CPEWriztI1KFQ5 and JuEsRLq2aNvdC and WWHczRGVbf4p5 and MiAEK6gyIx8LpGZaFwnCsmTouUd
	nelub6CUwAY1z2aNIhEcGR8P = JuEsRLq2aNvdC and WWHczRGVbf4p5 and MiAEK6gyIx8LpGZaFwnCsmTouUd
	QQHMWh5jJUGVmcq = nelub6CUwAY1z2aNIhEcGR8P
	ORvMaKtIbmEH = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(BGhdkWsEvJjiMFTr3NLn1flU(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡴࡷࡵࡶࡪࡦࡨࡶࠬ๵"))
	Lv7eDbPj9Fmix2yq = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡨࡵࡤࡦࠩ๶"))
	if CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠲ᓺ") and YolX0ad96AsHPSBG and jAYb2eymJCu5UMngp4:
		JjyQCKHRfG70L9B2zM = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,qnPgZ9N15G6Oa8UpMASvLk(u"ࠧ࡭࡫ࡶࡸࠬ๷"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧ๸")+ORvMaKtIbmEH+CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠩࡢࠫ๹")+Lv7eDbPj9Fmix2yq,G5praJPWcqo)
		if JjyQCKHRfG70L9B2zM:
			l0SAerv8zGH2Wa(iifPEY9ABNzTQp(u"ࠪࠫ๺"),bbw2eajMlG(u"ࠫ࠳ࠦࠠࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭๻")+ORvMaKtIbmEH+Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠬࡥࠧ๼")+Lv7eDbPj9Fmix2yq+tZ3gsrTEdzA1S6LXa9WI5px(u"࠭ࠠࠡࠢࡏࡳࡦࡪࡩ࡯ࡩࠣࡱࡪࡴࡵࠡࡨࡵࡳࡲࠦࡣࡢࡥ࡫ࡩࠬ๽"))
			if Tgoa16jMxvYX2(u"࠳ᓻ") and bxCRN0SQLHDuWj4pUG:
				JzbgMUDYVITmh14Cs = []
				from dbPMW8QD4U import j86dLMkfrv9sEp
				from UdzJNcmQS6 import ZIm7yNwq0DtAUbXso9Rd5hOPK,ffgDZB3bA9jHxR
				rLodAPvnKI6GjC589lX2Na = j86dLMkfrv9sEp
				k7iLEMp54trJP = ZIm7yNwq0DtAUbXso9Rd5hOPK()
				Ir4ndUtA0mL79Czxy = hPvDUWG0xTNq6kC
				yNk2jMKJn1So,KB6xnbQeJv,w351bKEYgZaQSUfn,pOALaz7Vl5j1xrTCRoS43XcGBed,go0cN6FsCbjrwWx295aelnJ,jdHotBi64YRPQ,eBoGr2pmgf,Jp2tfAdXIVUBQkg4Y7O1cmT,WTwl1aUCsN2qnf = QPTqwDCWalLdRB9jrkAbIz(Ir4ndUtA0mL79Czxy)
				nafAR4Pq2kt0dMm = yNk2jMKJn1So,KB6xnbQeJv,w351bKEYgZaQSUfn,pOALaz7Vl5j1xrTCRoS43XcGBed,go0cN6FsCbjrwWx295aelnJ,jdHotBi64YRPQ,eBoGr2pmgf,M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠧࠨ๾"),WTwl1aUCsN2qnf
				for ovwAOMGNWK0SJRsge in JjyQCKHRfG70L9B2zM:
					grbDOkFh8B4t = ovwAOMGNWK0SJRsge[bcgZJWV6UeNSkRA(u"ࠨ࡯ࡨࡲࡺࡏࡴࡦ࡯ࠪ๿")]
					if grbDOkFh8B4t==nafAR4Pq2kt0dMm or ovwAOMGNWK0SJRsge[yF29Xdsx35wI07Ce4(u"ࠩࡰࡳࡩ࡫ࠧ຀")] in [cNaVb1vsT4qWOL0rpE(u"࠶࠻࠻ᓽ"),pcWq35MED2dtK(u"࠵࠻࠵ᓼ")]:
						ovwAOMGNWK0SJRsge = hUXKd31miaLR7D5n(grbDOkFh8B4t,rLodAPvnKI6GjC589lX2Na,k7iLEMp54trJP)
						if ovwAOMGNWK0SJRsge[OyJ1o4AvmWlB75UkFRX(u"ࠪࡪࡦࡼ࡯ࡳ࡫ࡷࡩࡸ࠭ກ")]:
							awV7bX4yKR = ffgDZB3bA9jHxR(k7iLEMp54trJP,grbDOkFh8B4t,ovwAOMGNWK0SJRsge[ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠫࡳ࡫ࡷࡱࡣࡷ࡬ࠬຂ")])
							ovwAOMGNWK0SJRsge[CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠬࡩ࡯࡯ࡶࡨࡼࡹࡥ࡭ࡦࡰࡸࠫ຃")] = awV7bX4yKR+ovwAOMGNWK0SJRsge[KKbpxUZnMcj6AJ4QdD(u"࠭ࡣࡰࡰࡷࡩࡽࡺ࡟࡮ࡧࡱࡹࠬຄ")]
					JzbgMUDYVITmh14Cs.append(ovwAOMGNWK0SJRsge)
				LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫ຅"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠨࠩຆ"))
				if afxYgsnGTdAHePVBK==PtXn0k9G3ocHRg(u"ࠩࡩࡳࡱࡪࡥࡳࠩງ"): OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,BGhdkWsEvJjiMFTr3NLn1flU(u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩຈ")+ORvMaKtIbmEH+nKLEi8CJumazx4qT(u"ࠫࡤ࠭ຉ")+Lv7eDbPj9Fmix2yq,G5praJPWcqo,JzbgMUDYVITmh14Cs,QQJtZ6rMvS1wdDsHnahT7)
			else: JzbgMUDYVITmh14Cs = JjyQCKHRfG70L9B2zM
			if afxYgsnGTdAHePVBK==bcgZJWV6UeNSkRA(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬຊ") and HjxmCcWZQhX8zaJNUvsg5yGib0P!=OyJ1o4AvmWlB75UkFRX(u"࠭࠮࠯ࠩ຋") and ZdQBVeW2693O8v: IUxZkrcGM6bJulvQhX()
			I6Pk9Ke5WmirsZ2FBa = Eh4YzQ9pVM5ABfikCJqcZtj(G5praJPWcqo,JzbgMUDYVITmh14Cs,V5VXz0j3oa6t,mJXMyc9qFDbnif8LEz0hgSt3w5,e3jIULCymkiwXQG)
			return
	elif afxYgsnGTdAHePVBK==drHLAY5ENQFe2q9ptKGabo(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧຌ") and hPvDUWG0xTNq6kC==shZ9eOcN2dJnPj(u"ࠨࡔࡈࡊࡗࡋࡓࡉࡇࡇࠫຍ") and nelub6CUwAY1z2aNIhEcGR8P:
		ZqlR5BFQ6pm0asCHLUc(bpNSygerL10j4IOkEfuVw,yruHDQOcB97ig(u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨຎ")+ORvMaKtIbmEH+cgtRBdXxSOk7WUfyDhPCls(u"ࠪࡣࠬຏ")+Lv7eDbPj9Fmix2yq,G5praJPWcqo)
	if Dm9TblyAjE0tFeO:
		if M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠫࡤ࠭ຐ") in Dm9TblyAjE0tFeO: wNFQCPUhqcau6GLSKJTo2OimZ,TqJLsMv0bpl = Dm9TblyAjE0tFeO.split(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠬࡥࠧຑ"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠶ᓾ"))
		else: wNFQCPUhqcau6GLSKJTo2OimZ,TqJLsMv0bpl = Dm9TblyAjE0tFeO,OyJ1o4AvmWlB75UkFRX(u"࠭ࠧຒ")
		if wNFQCPUhqcau6GLSKJTo2OimZ in [ggDRehOModi(u"ࠧ࠲ࠩຓ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠨ࠴ࠪດ"),Tgoa16jMxvYX2(u"ࠩ࠶ࠫຕ"),cgtRBdXxSOk7WUfyDhPCls(u"ࠪ࠸ࠬຖ"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠫ࠺࠭ທ")] and TqJLsMv0bpl:
			from UdzJNcmQS6 import eevqQpU5hZNB1VFjPHC6kIoTn
			eevqQpU5hZNB1VFjPHC6kIoTn(Dm9TblyAjE0tFeO)
			LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(iifPEY9ABNzTQp(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩຘ"),O0Dm45eTJi8rlWUCQLbMducERHp)
			bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(JLoPRXt93dpAB(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪນ"))
			return
		elif wNFQCPUhqcau6GLSKJTo2OimZ==bcgZJWV6UeNSkRA(u"ࠧ࠷ࠩບ"):
			if TqJLsMv0bpl==cgtRBdXxSOk7WUfyDhPCls(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪປ"): dnS80F92qtLi4vw1(nKLEi8CJumazx4qT(u"ࠩํีั๏ࠠศๆส๊ฯ฾วาࠩຜ"),yF29Xdsx35wI07Ce4(u"ࠪะฬื๊ࠡใะู๋ࠥไโࠢส่ฯำๅ๋ๆࠪຝ"))
			elif TqJLsMv0bpl==vvBChXmSty(u"ࠫࡉࡋࡌࡆࡖࡈࠫພ"): KalY9RbZWxhOsV0 = oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠹࠳࠵ᓿ")
			vS7JufTVsBxw52 = JJGMsAH0CE5dbT1zpDeLWfR96Y8NXy(afxYgsnGTdAHePVBK,QG4JKD1kYXNazgnxlPr9WFRZ,nJZr96iD14wfebYudRShUFyHjkzAo,KalY9RbZWxhOsV0,E6T9RGlrWixPbQVMBIJzh8eYHwkAL,gwiP7zvsEaOMJnkBHpAqy8eYNR,TwPt5qAHlrOsQ,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv)
			bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩຟ"))
			return
		elif Dm9TblyAjE0tFeO==r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠭࠷ࠨຠ"):
			from IceNfg3vrV import h0Gl65VT1eROIbY
			h0Gl65VT1eROIbY()
			bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫມ"))
			return
		elif Dm9TblyAjE0tFeO==xuztI5QWEKG70CPNdhk4vo6(u"ࠨ࠺ࠪຢ"):
			bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨຣ")+lY0rst72uGVZ1NkgvpjfA6x+cNaVb1vsT4qWOL0rpE(u"ࠪࡃࡲࡵࡤࡦ࠿ࠪ຤")+str(Fx86vaQXEZeSBDAhmgC9zl7j2fs)+yruHDQOcB97ig(u"ࠫࠫࡺࡹࡱࡧࡀࡪࡴࡲࡤࡦࡴࠬࠫລ"))
			return
		elif Dm9TblyAjE0tFeO==KKbpxUZnMcj6AJ4QdD(u"ࠬ࠿ࠧ຦"):
			LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(yruHDQOcB97ig(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪວ"),PtXn0k9G3ocHRg(u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡆࡆࠪຨ"))
			bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬຩ"))
			return
	if LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(JLoPRXt93dpAB(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨສ")) not in [wwplD0tEehqH3kYQXs(u"ࠪࡅ࡚࡚ࡏࠨຫ"),InKG0i2r6hHDvgd(u"ࠫࡘ࡚ࡏࡑࠩຬ"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭ອ")]:
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(InKG0i2r6hHDvgd(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬຮ"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠧࡂࡗࡗࡓࠬຯ"))
	if not LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(BGhdkWsEvJjiMFTr3NLn1flU(u"ࠨࡣࡹ࠲ࡩࡴࡳࠨະ")): LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(yruHDQOcB97ig(u"ࠩࡤࡺ࠳ࡪ࡮ࡴࠩັ"),kH5Khue7Fic[XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠰ᔀ")])
	I7UOVyrGnz4v = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(drHLAY5ENQFe2q9ptKGabo(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡵࡩ࡬ࡻ࡬ࡢࡴࠪາ"))
	I7UOVyrGnz4v = nKLEi8CJumazx4qT(u"࠱ᔁ") if not I7UOVyrGnz4v else int(I7UOVyrGnz4v)
	if not I7UOVyrGnz4v or not yF29Xdsx35wI07Ce4(u"࠲ᔂ")<=s8bXSagYdim62TwIpQzGtUqeLhA1J-I7UOVyrGnz4v<=QQJtZ6rMvS1wdDsHnahT7:
		wGq2JfjSiF = onVDrgLUpFsqOPkxId9BwW6Rtc5A.Thread(target=NLB1OnfGmhoFMd5u94tzesi)
		wGq2JfjSiF.start()
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(drHLAY5ENQFe2q9ptKGabo(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡶࡪ࡭ࡵ࡭ࡣࡵࠫຳ"),str(s8bXSagYdim62TwIpQzGtUqeLhA1J))
	uURX0h8ZDQfMHJG = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(KKbpxUZnMcj6AJ4QdD(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡱࡵ࡮ࡨࠩິ"))
	uURX0h8ZDQfMHJG = ggDRehOModi(u"࠳ᔃ") if not uURX0h8ZDQfMHJG else int(uURX0h8ZDQfMHJG)
	if not uURX0h8ZDQfMHJG or not ggDRehOModi(u"࠴ᔄ")<=s8bXSagYdim62TwIpQzGtUqeLhA1J-uURX0h8ZDQfMHJG<=ebm0Z72CDaBzUq:
		import y5yjS2UFkc
		y5yjS2UFkc.NZ0pBCdgQs(ggDRehOModi(u"ࡊࡦࡲࡳࡦᜃ"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࡗࡶࡺ࡫ᜂ"))
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡲ࡯࡯ࡩࠪີ"),str(s8bXSagYdim62TwIpQzGtUqeLhA1J))
	YUb9mOJK7naxRLXM1 = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡹࡳࡢࡩࡨࡷࠬຶ"))
	JH2jAIe4ZPfgDndvMswuzlk1m6Y = pwVLbTukP0lCNQWg7Bz64v(LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩື")))
	JH2jAIe4ZPfgDndvMswuzlk1m6Y = KKbpxUZnMcj6AJ4QdD(u"࠵ᔅ") if not JH2jAIe4ZPfgDndvMswuzlk1m6Y else int(JH2jAIe4ZPfgDndvMswuzlk1m6Y)
	if YUb9mOJK7naxRLXM1 in [PtXn0k9G3ocHRg(u"ຸࠩࠪ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠪࡉࡗࡘࡏࡓູࠩ")] or not JH2jAIe4ZPfgDndvMswuzlk1m6Y or not yF29Xdsx35wI07Ce4(u"࠶ᔆ")<=s8bXSagYdim62TwIpQzGtUqeLhA1J-JH2jAIe4ZPfgDndvMswuzlk1m6Y<=hs8IDEMn0YuCHwk:
		AA8KSg59IphuYbzUG3syTknrMaV = b0jYpTOlAEoGF(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࡋࡧ࡬ࡴࡧᜄ"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࡋࡧ࡬ࡴࡧᜄ"))
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(xuztI5QWEKG70CPNdhk4vo6(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡱࡪࡹࡳࡢࡩࡨࡷ຺ࠬ"),ZAFhioq91YfduILWljSNxHDOB7(s8bXSagYdim62TwIpQzGtUqeLhA1J))
		if AA8KSg59IphuYbzUG3syTknrMaV:
			dnS80F92qtLi4vw1(bcgZJWV6UeNSkRA(u"ࠬาัษ่ࠢีฮࠦรฯำ์ࠫົ"),InKG0i2r6hHDvgd(u"࠭ࡔࡳࡻࠣࡥ࡬ࡧࡩ࡯ࠩຼ"),YVJPFvuI2CS5KObiZt=vvBChXmSty(u"࠱࠱࠲࠳ᔇ"))
			return
	YY9jE5KL6qrQcTRXvN = pwVLbTukP0lCNQWg7Bz64v(LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(yruHDQOcB97ig(u"ࠧࡢࡸ࠱ࡴࡪࡸࡩࡰࡦ࠱࡭ࡳ࡬࡯ࡴࠩຽ")))
	YY9jE5KL6qrQcTRXvN = Tgoa16jMxvYX2(u"࠱ᔈ") if not YY9jE5KL6qrQcTRXvN else int(YY9jE5KL6qrQcTRXvN)
	OO5g834vVzxXEofGFNkDwcyaeuQJ0 = pwVLbTukP0lCNQWg7Bz64v(LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ຾")))
	OO5g834vVzxXEofGFNkDwcyaeuQJ0 = InKG0i2r6hHDvgd(u"࠲ᔉ") if not OO5g834vVzxXEofGFNkDwcyaeuQJ0 else int(OO5g834vVzxXEofGFNkDwcyaeuQJ0)
	if not YY9jE5KL6qrQcTRXvN or not OO5g834vVzxXEofGFNkDwcyaeuQJ0 or not XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠳ᔊ")<=s8bXSagYdim62TwIpQzGtUqeLhA1J-OO5g834vVzxXEofGFNkDwcyaeuQJ0<=YY9jE5KL6qrQcTRXvN:
		ZZUWPJ9oh17cq0bvdLm3 = CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠵ᔋ")
		oeZaGCfSQHuR246P1sD5MmO = tZ3gsrTEdzA1S6LXa9WI5px(u"ࡆࡢ࡮ࡶࡩᜆ") if yrPav1tl5MQcfEBhsXk2o(XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠩࡒࡘ࠶࠿ࡊࡖ࠲ࡻࡆ࡙࡛࡬ࡅ࡚ࠪ຿")) else BGhdkWsEvJjiMFTr3NLn1flU(u"࡚ࡲࡶࡧᜅ")
		if oeZaGCfSQHuR246P1sD5MmO:
			ebSw1pNJXjWAHQFlUKY = J4W2ubDzKxd7hUsQTZOl1Gn(iifPEY9ABNzTQp(u"ࡕࡴࡸࡩᜇ"))
			if len(ebSw1pNJXjWAHQFlUKY)>tZ3gsrTEdzA1S6LXa9WI5px(u"࠶ᔌ"):
				l0SAerv8zGH2Wa(BGhdkWsEvJjiMFTr3NLn1flU(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪເ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠫ࠳ࠦࠠࡔࡪࡲࡻ࡮ࡴࡧࠡࡓࡸࡩࡸࡺࡩࡰࡰࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧແ")+O0Dm45eTJi8rlWUCQLbMducERHp+KKbpxUZnMcj6AJ4QdD(u"ࠬࠦ࡝ࠨໂ"))
				oSXwLI6yv7E8RPW9h,hGdKt2jR8SN1z5TrZkuU,FR2iK8BzPhInGx,Oi8pLbT4W12ortZkhIaMRym3YlXcdq,wB1aszFGrQMiZXNPqSbpoL79hE,rreason = ebSw1pNJXjWAHQFlUKY[drHLAY5ENQFe2q9ptKGabo(u"࠶ᔍ")]
				exspAP9JOoRbmKcn,LzZprQVsSl8u6Wo5d4MPnF = Oi8pLbT4W12ortZkhIaMRym3YlXcdq.split(M6PIj8gl1fno7wcqTksDEBK4bU(u"࠭࡜࡯࠽࠾ࠫໃ"))
				del ebSw1pNJXjWAHQFlUKY[InKG0i2r6hHDvgd(u"࠰ᔎ")]
				YpuPHVaJrS8d6BZm9CLo7hn = jjyW6FTEOn3sSMo1G5LxBiA.sample(ebSw1pNJXjWAHQFlUKY,Tgoa16jMxvYX2(u"࠲ᔏ"))
				oSXwLI6yv7E8RPW9h,hGdKt2jR8SN1z5TrZkuU,FR2iK8BzPhInGx,Oi8pLbT4W12ortZkhIaMRym3YlXcdq,wB1aszFGrQMiZXNPqSbpoL79hE,rreason = YpuPHVaJrS8d6BZm9CLo7hn[drHLAY5ENQFe2q9ptKGabo(u"࠲ᔐ")]
				FR2iK8BzPhInGx = ggDRehOModi(u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠡ࠼ࠣࠫໄ")+oSXwLI6yv7E8RPW9h+KKbpxUZnMcj6AJ4QdD(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ໅")+FR2iK8BzPhInGx
				wB1aszFGrQMiZXNPqSbpoL79hE = XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠩศีุอไࠡำึห้ฯࠠๅๆ่ฬึ๋ฬࠨໆ")
				dL95pmrlhDJe6 = JLoPRXt93dpAB(u"ࠪห้ะศา฻สฮࠬ໇")
				button0,button1 = Oi8pLbT4W12ortZkhIaMRym3YlXcdq,wB1aszFGrQMiZXNPqSbpoL79hE
				kTGfqid1whF2sxBKy7X3YmE45g = [button0,button1,dL95pmrlhDJe6]
				bcwWseHn2jBxI5AC0DJ = CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠴ᔑ") if yrPav1tl5MQcfEBhsXk2o(drHLAY5ENQFe2q9ptKGabo(u"ࠫ࡜࡙ࡕࡓࡈࡗ࠵࠾ࡗࡔࡆࡈ࡝࡜່ࠬ")) else bcgZJWV6UeNSkRA(u"࠵࠵ᔒ")
				OdN8EyB3LDqfoJCg = -usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠾ᔓ")
				while OdN8EyB3LDqfoJCg<PtXn0k9G3ocHRg(u"࠶ᔔ"):
					nQoV4rEKxi1UmwZHkNOT5vBdWuCIG = jjyW6FTEOn3sSMo1G5LxBiA.sample(kTGfqid1whF2sxBKy7X3YmE45g,XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠳ᔕ"))
					OdN8EyB3LDqfoJCg = lRwnVNxCZXGgkqd390(OyJ1o4AvmWlB75UkFRX(u"້ࠬ࠭"),nQoV4rEKxi1UmwZHkNOT5vBdWuCIG[qnPgZ9N15G6Oa8UpMASvLk(u"࠲ᔗ")],nQoV4rEKxi1UmwZHkNOT5vBdWuCIG[cNaVb1vsT4qWOL0rpE(u"࠲ᔖ")],nQoV4rEKxi1UmwZHkNOT5vBdWuCIG[Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠵ᔘ")],exspAP9JOoRbmKcn,FR2iK8BzPhInGx,xuztI5QWEKG70CPNdhk4vo6(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ໊"),bcwWseHn2jBxI5AC0DJ,tZ3gsrTEdzA1S6LXa9WI5px(u"࠺࠵ᔙ"))
					if OdN8EyB3LDqfoJCg==JLoPRXt93dpAB(u"࠶࠶ᔚ"): break
					from y5yjS2UFkc import V23iQNjwDUgHl9SFO6h8kbeY,bDowgWRO58xMB4G3Su7Ac9VICqmKnf
					if OdN8EyB3LDqfoJCg>=shZ9eOcN2dJnPj(u"࠰ᔜ") and nQoV4rEKxi1UmwZHkNOT5vBdWuCIG[OdN8EyB3LDqfoJCg]==kTGfqid1whF2sxBKy7X3YmE45g[nKLEi8CJumazx4qT(u"࠷ᔛ")]:
						V23iQNjwDUgHl9SFO6h8kbeY()
						if OdN8EyB3LDqfoJCg>=Tgoa16jMxvYX2(u"࠲ᔞ"): OdN8EyB3LDqfoJCg = -oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠺ᔝ")
					elif OdN8EyB3LDqfoJCg>=xuztI5QWEKG70CPNdhk4vo6(u"࠳ᔟ") and nQoV4rEKxi1UmwZHkNOT5vBdWuCIG[OdN8EyB3LDqfoJCg]==kTGfqid1whF2sxBKy7X3YmE45g[drHLAY5ENQFe2q9ptKGabo(u"࠶ᔠ")]:
						bDowgWRO58xMB4G3Su7Ac9VICqmKnf(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࡈࡤࡰࡸ࡫ᜈ"))
					if OdN8EyB3LDqfoJCg==-ggDRehOModi(u"࠶ᔡ"): xl9MFt1AmY0GrkENug8n(M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠧࠨ໋"),PtXn0k9G3ocHRg(u"ࠨࠩ໌"),cNaVb1vsT4qWOL0rpE(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬໍ"),bbw2eajMlG(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢิั้ฮࠣา฼ษ࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ่้ࠣิั้ฮࠣห้฻อ๋ฯࠣวำะั๊ࠡสัิࠦๅ็ࠢส่ศา่ษหࠣห้๋ส้ใิอࠬ໎"))
				ZZUWPJ9oh17cq0bvdLm3 = KKbpxUZnMcj6AJ4QdD(u"࠷ᔢ")
			else: ZZUWPJ9oh17cq0bvdLm3 = oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠰ᔣ")
		OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,JLoPRXt93dpAB(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ໏"),JLoPRXt93dpAB(u"࡙ࠬࡉࡕࡇࡖࡣࡓࡇࡍࡆࡕࠪ໐"),ZZUWPJ9oh17cq0bvdLm3,NVbfv48oh3M6U)
	vS7JufTVsBxw52 = JJGMsAH0CE5dbT1zpDeLWfR96Y8NXy(afxYgsnGTdAHePVBK,QG4JKD1kYXNazgnxlPr9WFRZ,nJZr96iD14wfebYudRShUFyHjkzAo,Fx86vaQXEZeSBDAhmgC9zl7j2fs,E6T9RGlrWixPbQVMBIJzh8eYHwkAL,gwiP7zvsEaOMJnkBHpAqy8eYNR,TwPt5qAHlrOsQ,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv)
	if iifPEY9ABNzTQp(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ໑") in TwPt5qAHlrOsQ: mJXMyc9qFDbnif8LEz0hgSt3w5 = xuztI5QWEKG70CPNdhk4vo6(u"ࡗࡶࡺ࡫ᜉ")
	if afxYgsnGTdAHePVBK==XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ໒"):
		if HjxmCcWZQhX8zaJNUvsg5yGib0P!=XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠨ࠰࠱ࠫ໓") and ZdQBVeW2693O8v: IUxZkrcGM6bJulvQhX()
		if Y40Szd1kTwqQxFXm6HO8tRlAvepK>-vvBChXmSty(u"࠲ᔤ"):
			if (AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,cNaVb1vsT4qWOL0rpE(u"ࠩ࡬ࡲࡹ࠭໔"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭໕"),cgtRBdXxSOk7WUfyDhPCls(u"ࠫࡘࡏࡔࡆࡕࡢࡒࡆࡓࡅࡔࠩ໖")) or KalY9RbZWxhOsV0 not in PSWD68pnCMqXV3UJeAcQyo) and not yrPav1tl5MQcfEBhsXk2o(nKLEi8CJumazx4qT(u"ࠬࡉࡔࡆ࠻ࡇࡗ࠶࠿ࡖࡖ࠲࡙ࡗ࡝࠭໗")):
				from dbPMW8QD4U import j86dLMkfrv9sEp
				JjyQCKHRfG70L9B2zM = HHiE1gsb4RkfK6VdI9(j86dLMkfrv9sEp)
				I6Pk9Ke5WmirsZ2FBa = Eh4YzQ9pVM5ABfikCJqcZtj(G5praJPWcqo,JjyQCKHRfG70L9B2zM,V5VXz0j3oa6t,mJXMyc9qFDbnif8LEz0hgSt3w5,e3jIULCymkiwXQG)
				if qnPgZ9N15G6Oa8UpMASvLk(u"࠳ᔥ") and JjyQCKHRfG70L9B2zM and QQHMWh5jJUGVmcq:
					OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,qnPgZ9N15G6Oa8UpMASvLk(u"࠭ࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࡣࠬ໘")+ORvMaKtIbmEH+tZ3gsrTEdzA1S6LXa9WI5px(u"ࠧࡠࠩ໙")+Lv7eDbPj9Fmix2yq,G5praJPWcqo,JjyQCKHRfG70L9B2zM,QQJtZ6rMvS1wdDsHnahT7)
			else:
				oejGsrTCZ05k2X7LlHnPa3h8vzAbJy.addDirectoryItem(Y40Szd1kTwqQxFXm6HO8tRlAvepK,drHLAY5ENQFe2q9ptKGabo(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫ໚")+lY0rst72uGVZ1NkgvpjfA6x+InKG0i2r6hHDvgd(u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿࡯࡭ࡳࡱࠦ࡮ࡱࡧࡩࡂ࠻࠰࠱ࠩ໛"),XuWPVcQ13oDq5swf0S.ListItem(M6PIj8gl1fno7wcqTksDEBK4bU(u"่ࠪิ๐ใࠡ็ื็้ฯࠠๆ่ࠣะ์อาไࠩໜ")))
				oejGsrTCZ05k2X7LlHnPa3h8vzAbJy.addDirectoryItem(Y40Szd1kTwqQxFXm6HO8tRlAvepK,Tgoa16jMxvYX2(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧໝ")+lY0rst72uGVZ1NkgvpjfA6x+Tgoa16jMxvYX2(u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡲࡩ࡯࡭ࠩࡱࡴࡪࡥ࠾࠷࠳࠴ࠬໞ"),XuWPVcQ13oDq5swf0S.ListItem(nKLEi8CJumazx4qT(u"࠭รโฬะࠤ้ะโาลࠣห้ะแศืํ่ࠬໟ")))
			oejGsrTCZ05k2X7LlHnPa3h8vzAbJy.endOfDirectory(Y40Szd1kTwqQxFXm6HO8tRlAvepK,V5VXz0j3oa6t,mJXMyc9qFDbnif8LEz0hgSt3w5,e3jIULCymkiwXQG)
	return
def JJGMsAH0CE5dbT1zpDeLWfR96Y8NXy(afxYgsnGTdAHePVBK,ffAnyTIUapotW4dS6sbC,GMfo7WypIsRin9HKEZQduYhDetFJOS,Fx86vaQXEZeSBDAhmgC9zl7j2fs,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,TwPt5qAHlrOsQ,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv):
	KalY9RbZWxhOsV0 = int(Fx86vaQXEZeSBDAhmgC9zl7j2fs)
	NjQaSix1UCsEclTfwRX = int(KalY9RbZWxhOsV0//InKG0i2r6hHDvgd(u"࠴࠴ᔦ"))
	if   NjQaSix1UCsEclTfwRX==bcgZJWV6UeNSkRA(u"࠴ᔧ"):  from y5yjS2UFkc 		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==shZ9eOcN2dJnPj(u"࠶ᔨ"):  from HyboIkYG2Q 		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==M6PIj8gl1fno7wcqTksDEBK4bU(u"࠸ᔩ"):  from XKpdiHwDMq 			import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,BzbaC0qYjMr2WXwsO,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==qnPgZ9N15G6Oa8UpMASvLk(u"࠳ᔪ"):  from PwRegaCVSl 			import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,BzbaC0qYjMr2WXwsO,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==PtXn0k9G3ocHRg(u"࠵ᔫ"):  from kyRNVzKZds 		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ,BzbaC0qYjMr2WXwsO)
	elif NjQaSix1UCsEclTfwRX==oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠷ᔬ"):  from PXUTyc7Mu0 		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==OyJ1o4AvmWlB75UkFRX(u"࠹ᔭ"):  from vvf6IlL5wk 		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠻ᔮ"):  from EnzcoUOKkg 			import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==PtXn0k9G3ocHRg(u"࠽ᔯ"):  from YHsR9TjoQK 		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==bcgZJWV6UeNSkRA(u"࠿ᔰ"):  from a8xkLvbS5l		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==KKbpxUZnMcj6AJ4QdD(u"࠱࠱ᔱ"): from ssPnNR3VqA 		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS)
	elif NjQaSix1UCsEclTfwRX==Tgoa16jMxvYX2(u"࠲࠳ᔲ"): from tFWb48mphv 		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==vvBChXmSty(u"࠳࠵ᔳ"): from Hfp1lCym08 		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,BzbaC0qYjMr2WXwsO,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠴࠷ᔴ"): from g6wcionfLm		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,BzbaC0qYjMr2WXwsO,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==yruHDQOcB97ig(u"࠵࠹ᔵ"): from bFeRWshMkt 		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ,afxYgsnGTdAHePVBK,BzbaC0qYjMr2WXwsO,ffAnyTIUapotW4dS6sbC,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx)
	elif NjQaSix1UCsEclTfwRX==PtXn0k9G3ocHRg(u"࠶࠻ᔶ"): from y5yjS2UFkc 		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠷࠶ᔷ"): from imHK80V2SX		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ,BzbaC0qYjMr2WXwsO,aiSY4yFdLmPH2zenlMpv)
	elif NjQaSix1UCsEclTfwRX==bcgZJWV6UeNSkRA(u"࠱࠸ᔸ"): from y5yjS2UFkc 		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==Tgoa16jMxvYX2(u"࠲࠺ᔹ"): from Y5UwkWIM8D		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==OyJ1o4AvmWlB75UkFRX(u"࠳࠼ᔺ"): from y5yjS2UFkc 		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==BGhdkWsEvJjiMFTr3NLn1flU(u"࠵࠴ᔻ"): from uCxKbgU9pj		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==drHLAY5ENQFe2q9ptKGabo(u"࠶࠶ᔼ"): from hyDITNRzH6	import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠷࠸ᔽ"): from dhD8kuPXmn		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,BzbaC0qYjMr2WXwsO,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==OyJ1o4AvmWlB75UkFRX(u"࠸࠳ᔾ"): from BSdmDzviZG	import LNa8zbTyOvDQ5M	; vS7JufTVsBxw52 = LNa8zbTyOvDQ5M(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ,afxYgsnGTdAHePVBK,BzbaC0qYjMr2WXwsO,aiSY4yFdLmPH2zenlMpv)
	elif NjQaSix1UCsEclTfwRX==JLoPRXt93dpAB(u"࠲࠵ᔿ"): from Jn5W8Lt2m3 			import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==Tgoa16jMxvYX2(u"࠳࠷ᕀ"): from MmeOUju29E 		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==tZ3gsrTEdzA1S6LXa9WI5px(u"࠴࠹ᕁ"): from dbPMW8QD4U 			import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==bcgZJWV6UeNSkRA(u"࠵࠻ᕂ"): from UdzJNcmQS6	import LNa8zbTyOvDQ5M	; vS7JufTVsBxw52 = LNa8zbTyOvDQ5M(KalY9RbZWxhOsV0,Dm9TblyAjE0tFeO)
	elif NjQaSix1UCsEclTfwRX==M6PIj8gl1fno7wcqTksDEBK4bU(u"࠶࠽ᕃ"): from BSdmDzviZG	import LNa8zbTyOvDQ5M	; vS7JufTVsBxw52 = LNa8zbTyOvDQ5M(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ,afxYgsnGTdAHePVBK,BzbaC0qYjMr2WXwsO,aiSY4yFdLmPH2zenlMpv)
	elif NjQaSix1UCsEclTfwRX==Tgoa16jMxvYX2(u"࠷࠿ᕄ"): from PYNkI4rj60	import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,BzbaC0qYjMr2WXwsO,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==wwplD0tEehqH3kYQXs(u"࠹࠰ᕅ"): from QW5xFpg0rX		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠳࠲ᕆ"): from wv8ZzdB62P		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==vvBChXmSty(u"࠴࠴ᕇ"): from oTPdVYaLtF		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==pcWq35MED2dtK(u"࠵࠶ᕈ"): from HwvICGKDxB		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS)
	elif NjQaSix1UCsEclTfwRX==yruHDQOcB97ig(u"࠶࠸ᕉ"): from y5yjS2UFkc 		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠷࠺ᕊ"): from kmsGWLvufP		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠸࠼ᕋ"): from W9RI8wqtK2			import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==pcWq35MED2dtK(u"࠹࠷ᕌ"): from Doxsw2Anyd			import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==KKbpxUZnMcj6AJ4QdD(u"࠳࠹ᕍ"): from VCdK5LpWwE 		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠴࠻ᕎ"): from yVGIEJxcRO		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==tZ3gsrTEdzA1S6LXa9WI5px(u"࠶࠳ᕏ"): from Idq3R2HptB	import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ,afxYgsnGTdAHePVBK,BzbaC0qYjMr2WXwsO)
	elif NjQaSix1UCsEclTfwRX==ggDRehOModi(u"࠷࠵ᕐ"): from Idq3R2HptB	import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ,afxYgsnGTdAHePVBK,BzbaC0qYjMr2WXwsO)
	elif NjQaSix1UCsEclTfwRX==drHLAY5ENQFe2q9ptKGabo(u"࠸࠷ᕑ"): from nklwYcfzev			import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==xuztI5QWEKG70CPNdhk4vo6(u"࠹࠹ᕒ"): from LLf3XgyDNA			import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==BGhdkWsEvJjiMFTr3NLn1flU(u"࠺࠴ᕓ"): from ysKtT73ARW		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==tZ3gsrTEdzA1S6LXa9WI5px(u"࠴࠶ᕔ"): from GFERWCcHYQ		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==iifPEY9ABNzTQp(u"࠵࠸ᕕ"): from pQabjHLJut			import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==cNaVb1vsT4qWOL0rpE(u"࠶࠺ᕖ"): from Njt6lSoURL		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==BGhdkWsEvJjiMFTr3NLn1flU(u"࠷࠼ᕗ"): from NLFpfGkys5		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==PtXn0k9G3ocHRg(u"࠸࠾ᕘ"): from JB0xjSXlDZ		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠺࠶ᕙ"): from y5yjS2UFkc 		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==M6PIj8gl1fno7wcqTksDEBK4bU(u"࠻࠱ᕚ"): from huRm2wvSzc 		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠵࠳ᕛ"): from huRm2wvSzc 		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠶࠵ᕜ"): from dbPMW8QD4U 			import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠷࠷ᕝ"): from IceNfg3vrV	import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ,BzbaC0qYjMr2WXwsO)
	elif NjQaSix1UCsEclTfwRX==Tgoa16jMxvYX2(u"࠸࠹ᕞ"): from e0WXjywiOS 		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==BGhdkWsEvJjiMFTr3NLn1flU(u"࠹࠻ᕟ"): from yyFkTgEfoX			import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==qnPgZ9N15G6Oa8UpMASvLk(u"࠺࠽ᕠ"): from XXW03oFr2P		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==yF29Xdsx35wI07Ce4(u"࠻࠸ᕡ"): from yJYQHXlE6h		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==InKG0i2r6hHDvgd(u"࠵࠺ᕢ"): from hhxlfEmF5y		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠷࠲ᕣ"): from gbfv9GxH4C			import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==nKLEi8CJumazx4qT(u"࠸࠴ᕤ"): from R6fiTqZm2X			import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==OyJ1o4AvmWlB75UkFRX(u"࠹࠶ᕥ"): from Bt21p86GIl		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠺࠸ᕦ"): from YcKLFTJ16g	import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠻࠺ᕧ"): from hjCIaSDtTE			import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠼࠵ᕨ"): from CrAY5GRxTW			import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==PtXn0k9G3ocHRg(u"࠶࠷ᕩ"): from ggHV1wT6n3			import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠷࠹ᕪ"): from MWGsQ2BUeR		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠸࠻ᕫ"): from b3JOnBIZkU		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠹࠽ᕬ"): from EENaHABDdg		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==Tgoa16jMxvYX2(u"࠻࠵ᕭ"): from TAEIfQ8l7t			import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==OyJ1o4AvmWlB75UkFRX(u"࠼࠷ᕮ"): from kS9c6phm0W	import LNa8zbTyOvDQ5M	; vS7JufTVsBxw52 = LNa8zbTyOvDQ5M(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ,afxYgsnGTdAHePVBK,BzbaC0qYjMr2WXwsO,aiSY4yFdLmPH2zenlMpv)
	elif NjQaSix1UCsEclTfwRX==bbw2eajMlG(u"࠽࠲ᕯ"): from kS9c6phm0W	import LNa8zbTyOvDQ5M	; vS7JufTVsBxw52 = LNa8zbTyOvDQ5M(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ,afxYgsnGTdAHePVBK,BzbaC0qYjMr2WXwsO,aiSY4yFdLmPH2zenlMpv)
	elif NjQaSix1UCsEclTfwRX==shZ9eOcN2dJnPj(u"࠷࠴ᕰ"): from ssdmqca2DG	import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==xuztI5QWEKG70CPNdhk4vo6(u"࠸࠶ᕱ"): from E6KGMNTcHU		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0)
	elif NjQaSix1UCsEclTfwRX==BGhdkWsEvJjiMFTr3NLn1flU(u"࠹࠸ᕲ"): from E6KGMNTcHU		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0)
	elif NjQaSix1UCsEclTfwRX==JLoPRXt93dpAB(u"࠺࠺ᕳ"): from imHK80V2SX		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ,BzbaC0qYjMr2WXwsO,aiSY4yFdLmPH2zenlMpv)
	elif NjQaSix1UCsEclTfwRX==xuztI5QWEKG70CPNdhk4vo6(u"࠻࠼ᕴ"): from LLZ6q2UV4K 		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,BzbaC0qYjMr2WXwsO,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==InKG0i2r6hHDvgd(u"࠼࠾ᕵ"): from tPsajGVDki 		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,BzbaC0qYjMr2WXwsO,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠽࠹ᕶ"): from XMumB6sYhk 		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,BzbaC0qYjMr2WXwsO,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠸࠱ᕷ"): from jQHBZOt3Up 		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,BzbaC0qYjMr2WXwsO,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠹࠳ᕸ"): from UOm9eZlMCQ 		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,TwPt5qAHlrOsQ)
	elif NjQaSix1UCsEclTfwRX==InKG0i2r6hHDvgd(u"࠺࠵ᕹ"): from ZZDpU58LVm		import cc03CYPLaxRfUKJb9eynFTr	; vS7JufTVsBxw52 = cc03CYPLaxRfUKJb9eynFTr(KalY9RbZWxhOsV0,GMfo7WypIsRin9HKEZQduYhDetFJOS,BzbaC0qYjMr2WXwsO,TwPt5qAHlrOsQ)
	else: vS7JufTVsBxw52 = None
	return vS7JufTVsBxw52
def AQScIze3YONX4h7(xIj15Wv4h9fOnX,rreason,BYGZC29KJ5Piag36Dl,showDialogs):
	E8qsiIj175HeVBgFQ = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(ggDRehOModi(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨ໠"))
	LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩ໡"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠩࠪ໢"))
	if vvBChXmSty(u"ࠪ࠱ࠬ໣") in BYGZC29KJ5Piag36Dl: tzVT6PXndWu0 = BYGZC29KJ5Piag36Dl.split(r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠫ࠲࠭໤"),Tgoa16jMxvYX2(u"࠴ᕺ"))[CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠴ᕻ")]
	else: tzVT6PXndWu0 = BYGZC29KJ5Piag36Dl
	alIVUYSmi8fAojXx1CuTF = xIj15Wv4h9fOnX in [iifPEY9ABNzTQp(u"࠸ᕿ"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠷࠱࠱࠲࠴ᕽ"),BGhdkWsEvJjiMFTr3NLn1flU(u"࠶࠷࠰࠱࠴ᕼ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠱࠱࠲࠸࠸ᕾ")]
	y5T8IgiaBvHwzplrnhuZFMNO0V2 = rreason.lower()
	cL86ejRxyUzJdwBnmib3TQCIKWHk = xIj15Wv4h9fOnX in [bbw2eajMlG(u"࠲ᖀ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠶࠶࠴ᖃ"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠴࠴࠵࠼࠱ᖁ"),yF29Xdsx35wI07Ce4(u"࠵࠶࠷ᖂ")]
	oCnzFHqGUN6ht = M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪ࠭໥") in y5T8IgiaBvHwzplrnhuZFMNO0V2
	AdES81lpf0gmQtDuLjzTnYHyrqxs = vvBChXmSty(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣ࠹ࠥࡹࡥࡤࡱࡱࡨࡸࠦࡢࡳࡱࡺࡷࡪࡸࠠࡤࡪࡨࡧࡰ࠭໦") in y5T8IgiaBvHwzplrnhuZFMNO0V2
	UFE5Rvni0f = KKbpxUZnMcj6AJ4QdD(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧࠧ໧") in y5T8IgiaBvHwzplrnhuZFMNO0V2
	CC0lvXKbst7F6Nm1VDhU = BGhdkWsEvJjiMFTr3NLn1flU(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠢࡶࡩࡨࡻࡲࡪࡶࡼࠤࡨ࡮ࡥࡤ࡭ࠪ໨") in y5T8IgiaBvHwzplrnhuZFMNO0V2
	XmfRZkAC8K3VnH75 = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧ໩"))
	JGfwh16Q4pYj3saRHZFiTeVNoW = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭໪"))
	uFLRTkC1mc72asJ3 = bbw2eajMlG(u"ࠫๆฺไࠡใํࠤุำศࠡษ็ูๆำษࠡ็้ࠤฬ๊ล็ฬิ๊ฯ࠭໫")
	m80dtukGaFCn = shZ9eOcN2dJnPj(u"ࠬࡋࡲࡳࡱࡵࠤࠬ໬")+str(xIj15Wv4h9fOnX)+cgtRBdXxSOk7WUfyDhPCls(u"࠭࠺ࠡࠩ໭")+rreason
	m80dtukGaFCn = P2o6ZDHeW790pSQqucvnxzILVUX(m80dtukGaFCn)
	if cL86ejRxyUzJdwBnmib3TQCIKWHk or oCnzFHqGUN6ht or AdES81lpf0gmQtDuLjzTnYHyrqxs or UFE5Rvni0f or CC0lvXKbst7F6Nm1VDhU:
		uFLRTkC1mc72asJ3 += nKLEi8CJumazx4qT(u"ࠧࠡ࠰ࠣห้๋่ใ฻ࠣๅ๏ํࠠฮฮหࠤ฻ีࠠไ๊า๎๋ࠥีะำ๊ࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูࠥฮใࠡล๋ࠤออไๆ๊ๅ฽ࡡࡴࠧ໮")
	if alIVUYSmi8fAojXx1CuTF: uFLRTkC1mc72asJ3 += JLoPRXt93dpAB(u"ࠨࠢ࠱ࠤ้ี๊ไࠢั฻ศࠦࡄࡏࡕࠣ์๊฿ๆศ้ࠣฮ฾ึัࠡฬิะ๊ฯࠠศี่ࠤฬ๊ๅ้ไ฼ࠤส๊้ࠡำๅ้์ࡢ࡮ࠨ໯")
	m80dtukGaFCn = qnPgZ9N15G6Oa8UpMASvLk(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ໰")+m80dtukGaFCn+drHLAY5ENQFe2q9ptKGabo(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ໱")
	if XmfRZkAC8K3VnH75==bbw2eajMlG(u"ࠫࡆ࡙ࡋࠨ໲") or JGfwh16Q4pYj3saRHZFiTeVNoW==pcWq35MED2dtK(u"ࠬࡇࡓࡌࠩ໳"):
		uFLRTkC1mc72asJ3 += KKbpxUZnMcj6AJ4QdD(u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠ๋้ࠦสา์าࠤศ์๋ࠠฯส์้ࠦวๅสิ๊ฬ๋ฬࠡวุ่ฬำࠠศๆุ่่๊ษࠡ࠰࠱ࠤศ๋ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣวํࠦฮุลࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡมࠤࠥࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭໴")
	ZOAWTyIzDR0hpc8Jm9 = iifPEY9ABNzTQp(u"ࡊࡦࡲࡳࡦᜊ")
	if showDialogs and BYGZC29KJ5Piag36Dl not in Rrwi83IBX0D2hEkmWOGa51A:
		if XmfRZkAC8K3VnH75==Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠧࡂࡕࡎࠫ໵") or JGfwh16Q4pYj3saRHZFiTeVNoW==n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠨࡃࡖࡏࠬ໶"):
			OdN8EyB3LDqfoJCg = lRwnVNxCZXGgkqd390(cgtRBdXxSOk7WUfyDhPCls(u"ࠩࡦࡩࡳࡺࡥࡳࠩ໷"),bcgZJWV6UeNSkRA(u"ࠪาึ๎ฬࠨ໸"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠫสืำศๆࠣีุอไสࠢ็่๊ฮัๆฮࠪ໹"),ggDRehOModi(u"ࠬหีๅษะࠤฬ๊ๅีๅ็อࠬ໺"),tzVT6PXndWu0+BGhdkWsEvJjiMFTr3NLn1flU(u"࠭ࠠࠡࠢࠪ໻")+wSH84vUOuxYjoQ3aPBeAEZ(tzVT6PXndWu0),uFLRTkC1mc72asJ3+M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠧ࡝ࡰࠪ໼")+m80dtukGaFCn)
			if OdN8EyB3LDqfoJCg==JLoPRXt93dpAB(u"࠷ᖄ"):
				from y5yjS2UFkc import V23iQNjwDUgHl9SFO6h8kbeY
				V23iQNjwDUgHl9SFO6h8kbeY()
			elif OdN8EyB3LDqfoJCg==tZ3gsrTEdzA1S6LXa9WI5px(u"࠲ᖅ"): ZOAWTyIzDR0hpc8Jm9 = InKG0i2r6hHDvgd(u"࡙ࡸࡵࡦᜋ")
		else: xl9MFt1AmY0GrkENug8n(xuztI5QWEKG70CPNdhk4vo6(u"ࠨࠩ໽"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠩࠪ໾"),tzVT6PXndWu0+bbw2eajMlG(u"ࠪࠤࠥࠦࠧ໿")+wSH84vUOuxYjoQ3aPBeAEZ(tzVT6PXndWu0),uFLRTkC1mc72asJ3,m80dtukGaFCn)
	LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(iifPEY9ABNzTQp(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬༀ"),E8qsiIj175HeVBgFQ)
	return ZOAWTyIzDR0hpc8Jm9
def Ng2cPah6pJKD3YTjFX0lyfVbs5(cNmD2HRn6BrG=OyJ1o4AvmWlB75UkFRX(u"ࡌࡡ࡭ࡵࡨᜌ"),YZPyB0DSLdmqIpW79=[]):
	ffIYJloB25VzcS7 = [s1KMjlEIH9vd,MZabdxfVE5WJwUu]+YZPyB0DSLdmqIpW79
	for i60vZtVrPYoD in k1t0JLRsCQ.listdir(OxWkR7Eu9Pm3IAvTp0q):
		if cNmD2HRn6BrG and (i60vZtVrPYoD.startswith(usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠬ࡯ࡰࡵࡸࠪ༁")) or i60vZtVrPYoD.startswith(yruHDQOcB97ig(u"࠭࡭࠴ࡷࠪ༂"))): continue
		if i60vZtVrPYoD.startswith(yruHDQOcB97ig(u"ࠧࡧ࡫࡯ࡩࡤ࠭༃")): continue
		jNnpEATedbVGyX = k1t0JLRsCQ.path.join(OxWkR7Eu9Pm3IAvTp0q,i60vZtVrPYoD)
		if jNnpEATedbVGyX in ffIYJloB25VzcS7: continue
		try: k1t0JLRsCQ.remove(jNnpEATedbVGyX)
		except: pass
	if yZKq8SbJduiIwcHMOz6gN not in ffIYJloB25VzcS7: DzIGOoUJcZT9tQeuX3RyY(yZKq8SbJduiIwcHMOz6gN,nKLEi8CJumazx4qT(u"ࡕࡴࡸࡩᜎ"),cNaVb1vsT4qWOL0rpE(u"ࡆࡢ࡮ࡶࡩᜍ"))
	YVJPFvuI2CS5KObiZt.sleep(qnPgZ9N15G6Oa8UpMASvLk(u"࠲ᖆ"))
	return
def kxfLdrPsO9Wa0w3oNmyFzg(VX7jIaJySxHunNKfz,Fu63RmidlUsQIgCcOypVYeo,GMfo7WypIsRin9HKEZQduYhDetFJOS,MNWrTo98GZHn,vSj57P0g4mF2Bp,ZAQPeI2BlmFr4MHR6agVtGWJjfsTL,showDialogs,BYGZC29KJ5Piag36Dl,ks3VNwMlLPIHt=r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࡖࡵࡹࡪᜏ"),AhpCS7wYsW3PO6Q9=r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࡖࡵࡹࡪᜏ")):
	GMfo7WypIsRin9HKEZQduYhDetFJOS = GMfo7WypIsRin9HKEZQduYhDetFJOS+InKG0i2r6hHDvgd(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨ༄")+VX7jIaJySxHunNKfz
	l3lOuS56hyIdjACkcweb1WDrHQgYfa = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,Fu63RmidlUsQIgCcOypVYeo,GMfo7WypIsRin9HKEZQduYhDetFJOS,MNWrTo98GZHn,vSj57P0g4mF2Bp,ZAQPeI2BlmFr4MHR6agVtGWJjfsTL,showDialogs,BYGZC29KJ5Piag36Dl,ks3VNwMlLPIHt,AhpCS7wYsW3PO6Q9)
	if GMfo7WypIsRin9HKEZQduYhDetFJOS in l3lOuS56hyIdjACkcweb1WDrHQgYfa.content: l3lOuS56hyIdjACkcweb1WDrHQgYfa.succeeded = nKLEi8CJumazx4qT(u"ࡉࡥࡱࡹࡥᜐ")
	if not l3lOuS56hyIdjACkcweb1WDrHQgYfa.succeeded:
		vS1seWj2c0tKyZ(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠩࡋࡘ࡙ࡖࠠࡓࡧࡴࡹࡪࡹࡴࠡࡈࡤ࡭ࡱࡻࡲࡦࠩ༅"))
	return l3lOuS56hyIdjACkcweb1WDrHQgYfa
def NfPcijsTgS5Ub9uDo4vRxt(GMfo7WypIsRin9HKEZQduYhDetFJOS):
	l3lOuS56hyIdjACkcweb1WDrHQgYfa = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠪࡋࡊ࡚ࠧ༆"),GMfo7WypIsRin9HKEZQduYhDetFJOS,usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠫࠬ༇"),yF29Xdsx35wI07Ce4(u"ࠬ࠭༈"),OyJ1o4AvmWlB75UkFRX(u"࡙ࡸࡵࡦᜒ"),InKG0i2r6hHDvgd(u"࠭ࠧ༉"),drHLAY5ENQFe2q9ptKGabo(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡘࡤࡖࡒࡐ࡚ࡌࡉࡘࡥࡌࡊࡕࡗ࠱࠶ࡹࡴࠨ༊"),OyJ1o4AvmWlB75UkFRX(u"࡙ࡸࡵࡦᜒ"),yF29Xdsx35wI07Ce4(u"ࡊࡦࡲࡳࡦᜑ"))
	yI238OMW1PtSLVBgmifkR7cEzK = []
	if l3lOuS56hyIdjACkcweb1WDrHQgYfa.succeeded:
		DMqcCpg8GmefYtWJZITSP29x3nLzO = l3lOuS56hyIdjACkcweb1WDrHQgYfa.content
		MyBTkUswR53zorPt = u5h2Rckvw1E.findall(bbw2eajMlG(u"ࠨࠢࠫ࠲࠯ࡅࠩࠡ࡞ࡧࡿ࠶࠲࠳ࡾ࡯ࡶࠫ་"),DMqcCpg8GmefYtWJZITSP29x3nLzO)
		if MyBTkUswR53zorPt: DMqcCpg8GmefYtWJZITSP29x3nLzO = qnPgZ9N15G6Oa8UpMASvLk(u"ࠩ࡟ࡲࠬ༌").join(MyBTkUswR53zorPt)
		HbKyS4dCBvEo = DMqcCpg8GmefYtWJZITSP29x3nLzO.replace(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠪࡠࡷ࠭།"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠫࠬ༎")).strip(BGhdkWsEvJjiMFTr3NLn1flU(u"ࠬࡢ࡮ࠨ༏")).split(bcgZJWV6UeNSkRA(u"࠭࡜࡯ࠩ༐"))
		yI238OMW1PtSLVBgmifkR7cEzK = []
		for VX7jIaJySxHunNKfz in HbKyS4dCBvEo:
			if VX7jIaJySxHunNKfz.count(r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠧ࠯ࠩ༑"))==n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠵ᖇ"): yI238OMW1PtSLVBgmifkR7cEzK.append(VX7jIaJySxHunNKfz)
	return yI238OMW1PtSLVBgmifkR7cEzK
def ccu04ZfBCIxUajMp(*aargs):
	jjMY2cx1eGdlw8o0nCKL = Tgoa16jMxvYX2(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡴ࡮࠴ࡰࡳࡱࡻࡽࡸࡩࡲࡢࡲࡨ࠲ࡨࡵ࡭࠰ࡸ࠵࠳ࡄࡸࡥࡲࡷࡨࡷࡹࡃࡤࡪࡵࡳࡰࡦࡿࡰࡳࡱࡻ࡭ࡪࡹࠦࡱࡴࡲࡼࡾࡺࡹࡱࡧࡀ࡬ࡹࡺࡰࠧࡶ࡬ࡱࡪࡵࡵࡵ࠿࠴࠴࠵࠶࠰ࠧࡵࡶࡰࡂࡿࡥࡴࠨ࡯࡭ࡲ࡯ࡴ࠾࠳࠳ࠪࡨࡵࡵ࡯ࡶࡵࡽࡂࡔࡌ࠭ࡄࡈ࠰ࡉࡋࠬࡇࡔ࠯ࡋࡇ࠲ࡔࡓࠩ༒")
	EQ2DX8lCqRifVxudc = XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡶࡦࡽ࠮ࡨ࡫ࡷ࡬ࡺࡨࡵࡴࡧࡵࡧࡴࡴࡴࡦࡰࡷ࠲ࡨࡵ࡭࠰ࡴࡲࡳࡸࡺࡥࡳ࡭࡬ࡨ࠴ࡵࡰࡦࡰࡳࡶࡴࡾࡹ࡭࡫ࡶࡸ࠴ࡳࡡࡪࡰ࠲ࡌ࡙࡚ࡐࡔ࠰ࡷࡼࡹ࠭༓")
	y5KWqHzDTbCEIX7pr1JQ92t4 = NfPcijsTgS5Ub9uDo4vRxt(EQ2DX8lCqRifVxudc)
	yI238OMW1PtSLVBgmifkR7cEzK = NfPcijsTgS5Ub9uDo4vRxt(jjMY2cx1eGdlw8o0nCKL)
	ULK7pafArj1Ci06D9YnSvqd = y5KWqHzDTbCEIX7pr1JQ92t4+yI238OMW1PtSLVBgmifkR7cEzK
	l0SAerv8zGH2Wa(cgtRBdXxSOk7WUfyDhPCls(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ༔"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+OyJ1o4AvmWlB75UkFRX(u"ࠫࠥࠦࠠࡈࡱࡷࠤࡵࡸ࡯ࡹ࡫ࡨࡷࠥࡲࡩࡴࡶࠣࠤࠥ࠷ࡳࡵ࠭࠵ࡲࡩࡀࠠ࡜ࠢࠪ༕")+str(len(y5KWqHzDTbCEIX7pr1JQ92t4))+cNaVb1vsT4qWOL0rpE(u"ࠬ࠱ࠧ༖")+str(len(yI238OMW1PtSLVBgmifkR7cEzK))+nKLEi8CJumazx4qT(u"࠭ࠠ࡞ࠩ༗"))
	VX7jIaJySxHunNKfz = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺ༘ࠧ"))
	l3lOuS56hyIdjACkcweb1WDrHQgYfa = fZio7hAJNCV1stDnvWaQX0cLFjwqHS()
	LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(xuztI5QWEKG70CPNdhk4vo6(u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨ༙"),pcWq35MED2dtK(u"ࠩࠪ༚"))
	if VX7jIaJySxHunNKfz or ULK7pafArj1Ci06D9YnSvqd:
		oSXwLI6yv7E8RPW9h,pKOBP5j4yJQIxsUENle9VR2YDwT = n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠳ᖈ"),bbw2eajMlG(u"࠵࠵ᖉ")
		YE3hTmyu2cRj = len(ULK7pafArj1Ci06D9YnSvqd)
		bRzT59DMLU = pKOBP5j4yJQIxsUENle9VR2YDwT
		if YE3hTmyu2cRj>bRzT59DMLU: SZXqzdFLKTeMw9p0iNl1 = bRzT59DMLU
		else: SZXqzdFLKTeMw9p0iNl1 = YE3hTmyu2cRj
		zz1wXNV4UkZYGTnAC08y = jjyW6FTEOn3sSMo1G5LxBiA.sample(ULK7pafArj1Ci06D9YnSvqd,SZXqzdFLKTeMw9p0iNl1)
		if VX7jIaJySxHunNKfz: zz1wXNV4UkZYGTnAC08y = [VX7jIaJySxHunNKfz]+zz1wXNV4UkZYGTnAC08y
		QrVeSIhoaAbE = NNdsp2w4g0ObWUVv7(InKG0i2r6hHDvgd(u"ࡌࡡ࡭ࡵࡨᜓ"),InKG0i2r6hHDvgd(u"ࡌࡡ࡭ࡵࡨᜓ"))
		OlDEqB68KZdI5fsipUJzuavcn = YVJPFvuI2CS5KObiZt.time()
		while YVJPFvuI2CS5KObiZt.time()-OlDEqB68KZdI5fsipUJzuavcn<=pKOBP5j4yJQIxsUENle9VR2YDwT and not QrVeSIhoaAbE.finishedLIST:
			if oSXwLI6yv7E8RPW9h<SZXqzdFLKTeMw9p0iNl1:
				VX7jIaJySxHunNKfz = zz1wXNV4UkZYGTnAC08y[oSXwLI6yv7E8RPW9h]
				QrVeSIhoaAbE.H3bQD56wsB(oSXwLI6yv7E8RPW9h,kxfLdrPsO9Wa0w3oNmyFzg,VX7jIaJySxHunNKfz,*aargs)
			YVJPFvuI2CS5KObiZt.sleep(xuztI5QWEKG70CPNdhk4vo6(u"࠶ᖊ"))
			oSXwLI6yv7E8RPW9h += wwplD0tEehqH3kYQXs(u"࠷ᖋ")
			l0SAerv8zGH2Wa(JLoPRXt93dpAB(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ༛"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+PtXn0k9G3ocHRg(u"ࠫࠥࠦࠠࡕࡴࡼ࡭ࡳ࡭࠺ࠡࠢࠣࡔࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭༜")+VX7jIaJySxHunNKfz+wwplD0tEehqH3kYQXs(u"ࠬࠦ࡝ࠨ༝"))
		finishedLIST = QrVeSIhoaAbE.finishedLIST
		if finishedLIST:
			resultsDICT = QrVeSIhoaAbE.resultsDICT
			kQHiSMs62VrqROnFfXPJlW7cyu = finishedLIST[yruHDQOcB97ig(u"࠰ᖌ")]
			l3lOuS56hyIdjACkcweb1WDrHQgYfa = resultsDICT[kQHiSMs62VrqROnFfXPJlW7cyu]
			VX7jIaJySxHunNKfz = zz1wXNV4UkZYGTnAC08y[int(kQHiSMs62VrqROnFfXPJlW7cyu)]
			LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯࡮ࡤࡷࡹ࠭༞"),VX7jIaJySxHunNKfz)
			if kQHiSMs62VrqROnFfXPJlW7cyu!=InKG0i2r6hHDvgd(u"࠱ᖍ"): l0SAerv8zGH2Wa(r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭༟"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+BGhdkWsEvJjiMFTr3NLn1flU(u"ࠨࠢࠣࠤࡘࡻࡣࡤࡧࡶࡷ࠿ࠦࠠࠡࡒࡵࡳࡽࡿ࠺ࠡ࡝ࠣࠫ༠")+VX7jIaJySxHunNKfz+usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩࠣࡡࠬ༡"))
			else: l0SAerv8zGH2Wa(InKG0i2r6hHDvgd(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ༢"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+pcWq35MED2dtK(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪࡹࡳ࠻ࠢࠣࠤࡘࡧࡶࡦࡦࠣࡴࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭༣")+VX7jIaJySxHunNKfz+r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠬࠦ࡝ࠨ༤"))
	return l3lOuS56hyIdjACkcweb1WDrHQgYfa
def KEB3dTbiq6XhM8OuxAPl0H9Ynoz2F(zT19EnD4McGxWr3YwBa,b409vpr8PJYsiZaOxRdVko):
	eoQKMv8XSL = zT19EnD4McGxWr3YwBa.create_connection
	def SWjcBJtAlU6Ey(bVCeKTyMZ1Alf,*aargs,**kkwargs):
		j8K3TBfiH1GgXJmC,M3MzY0BOyDCSj1gPmIe6Rc = bVCeKTyMZ1Alf
		ip = d346GzJPjvka9xSbMADlnsQgu52L(j8K3TBfiH1GgXJmC,b409vpr8PJYsiZaOxRdVko)
		if ip: j8K3TBfiH1GgXJmC = ip[wwplD0tEehqH3kYQXs(u"࠲ᖎ")]
		else:
			if b409vpr8PJYsiZaOxRdVko in kH5Khue7Fic: kH5Khue7Fic.remove(b409vpr8PJYsiZaOxRdVko)
			if kH5Khue7Fic:
				jjN4cgRnETvfG8zo5A7HbLmuYUr0qS = kH5Khue7Fic[vvBChXmSty(u"࠳ᖏ")]
				ip = d346GzJPjvka9xSbMADlnsQgu52L(j8K3TBfiH1GgXJmC,jjN4cgRnETvfG8zo5A7HbLmuYUr0qS)
				if ip: j8K3TBfiH1GgXJmC = ip[usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠴ᖐ")]
		bVCeKTyMZ1Alf = (j8K3TBfiH1GgXJmC,M3MzY0BOyDCSj1gPmIe6Rc)
		return eoQKMv8XSL(bVCeKTyMZ1Alf,*aargs,**kkwargs)
	zT19EnD4McGxWr3YwBa.create_connection = SWjcBJtAlU6Ey
	return eoQKMv8XSL
def lhjXy7g6tvWRx8ZFQL(GMfo7WypIsRin9HKEZQduYhDetFJOS):
	PfWu6Hg3Ek,KKV40hLeP5jFrkYaQ61SldxIEMn = GMfo7WypIsRin9HKEZQduYhDetFJOS.split(iifPEY9ABNzTQp(u"࠭࠯ࠨ༥"))[nKLEi8CJumazx4qT(u"࠸ᖒ")],Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠽࠶ᖑ")
	if n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠧ࠻ࠩ༦") in PfWu6Hg3Ek: PfWu6Hg3Ek,KKV40hLeP5jFrkYaQ61SldxIEMn = PfWu6Hg3Ek.split(M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠨ࠼ࠪ༧"))
	Spg1IoiD2KGt5VRswEvrum = BGhdkWsEvJjiMFTr3NLn1flU(u"ࠩ࠲ࠫ༨")+pcWq35MED2dtK(u"ࠪ࠳ࠬ༩").join(GMfo7WypIsRin9HKEZQduYhDetFJOS.split(shZ9eOcN2dJnPj(u"ࠫ࠴࠭༪"))[r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠳ᖓ"):])
	VemfsE32zgI = shZ9eOcN2dJnPj(u"ࠬࡍࡅࡕࠢࠪ༫")+Spg1IoiD2KGt5VRswEvrum+shZ9eOcN2dJnPj(u"࠭ࠠࡉࡖࡗࡔ࠴࠷࠮࠲࡞ࡵࡠࡳ࠭༬")
	VemfsE32zgI += InKG0i2r6hHDvgd(u"ࠧࡉࡱࡶࡸ࠿ࠦࠧ༭")+PfWu6Hg3Ek+cgtRBdXxSOk7WUfyDhPCls(u"ࠨ࡞ࡵࡠࡳ࠭༮")
	VemfsE32zgI += BGhdkWsEvJjiMFTr3NLn1flU(u"ࠩ࡟ࡶࡡࡴࠧ༯")
	from socket import socket as mJNCKBxoGEw5X1tAfLOhgMivQzeI9c,AF_INET as U0ecS5D43xq1XngdI97rjVThBf8,SOCK_STREAM as ss4Y30c7iC
	try:
		McPg073FIdwXCurso2NBY = mJNCKBxoGEw5X1tAfLOhgMivQzeI9c(U0ecS5D43xq1XngdI97rjVThBf8,ss4Y30c7iC)
		McPg073FIdwXCurso2NBY.connect((PfWu6Hg3Ek,KKV40hLeP5jFrkYaQ61SldxIEMn))
		McPg073FIdwXCurso2NBY.send(VemfsE32zgI.encode(nKLEi8CJumazx4qT(u"ࠪࡹࡹ࡬࠸ࠨ༰")))
		iCFd06HxXhODSwe3mQZBnsz = McPg073FIdwXCurso2NBY.recv(ggDRehOModi(u"࠶࠳࠽࠻ᖕ")*JLoPRXt93dpAB(u"࠲࠲࠵࠸ᖔ"))
		DMqcCpg8GmefYtWJZITSP29x3nLzO = repr(iCFd06HxXhODSwe3mQZBnsz)
	except: DMqcCpg8GmefYtWJZITSP29x3nLzO = cNaVb1vsT4qWOL0rpE(u"ࠫࠬ༱")
	return DMqcCpg8GmefYtWJZITSP29x3nLzO
def hmcFWJUgiAuGk(j0zi47my8EYnhALDIS,afxYgsnGTdAHePVBK):
	if usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠬ࠴ࠧ༲") not in j0zi47my8EYnhALDIS: return j0zi47my8EYnhALDIS
	j0zi47my8EYnhALDIS = j0zi47my8EYnhALDIS+Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠭࠯ࠨ༳")
	CWuzcftYlwOye3GPTAoijkHQSFZXqU,CzmkHU9jDutVsZBYy = j0zi47my8EYnhALDIS.split(shZ9eOcN2dJnPj(u"ࠧ࠯ࠩ༴"),drHLAY5ENQFe2q9ptKGabo(u"࠴ᖖ"))
	HdjGzug4nm8,kQ1w3liNTYDUP = CzmkHU9jDutVsZBYy.split(M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠨ࠱༵ࠪ"),Tgoa16jMxvYX2(u"࠵ᖗ"))
	Fb57I1fr9EYSgOQ60UoksjHL83y = CWuzcftYlwOye3GPTAoijkHQSFZXqU+yruHDQOcB97ig(u"ࠩ࠱ࠫ༶")+HdjGzug4nm8
	if afxYgsnGTdAHePVBK in [iifPEY9ABNzTQp(u"ࠪ࡬ࡴࡹࡴࠨ༷"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠫࡳࡧ࡭ࡦࠩ༸")] and InKG0i2r6hHDvgd(u"ࠬ࠵༹ࠧ") in Fb57I1fr9EYSgOQ60UoksjHL83y: Fb57I1fr9EYSgOQ60UoksjHL83y = Fb57I1fr9EYSgOQ60UoksjHL83y.rsplit(InKG0i2r6hHDvgd(u"࠭࠯ࠨ༺"),tZ3gsrTEdzA1S6LXa9WI5px(u"࠶ᖘ"))[tZ3gsrTEdzA1S6LXa9WI5px(u"࠶ᖘ")]
	if afxYgsnGTdAHePVBK==yruHDQOcB97ig(u"ࠧ࡯ࡣࡰࡩࠬ༻") and bbw2eajMlG(u"ࠨ࠰ࠪ༼") in Fb57I1fr9EYSgOQ60UoksjHL83y:
		X6FbW1Z2iHaRpP = Fb57I1fr9EYSgOQ60UoksjHL83y.split(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠩ࠱ࠫ༽"))
		RQm6Y8H3oV = len(X6FbW1Z2iHaRpP)
		if RQm6Y8H3oV<=BGhdkWsEvJjiMFTr3NLn1flU(u"࠲ᖚ") or Tgoa16jMxvYX2(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨ༾") in Fb57I1fr9EYSgOQ60UoksjHL83y: X6FbW1Z2iHaRpP = X6FbW1Z2iHaRpP[vvBChXmSty(u"࠶ᖙ")]
		elif RQm6Y8H3oV>=wwplD0tEehqH3kYQXs(u"࠵ᖜ"): X6FbW1Z2iHaRpP = X6FbW1Z2iHaRpP[ggDRehOModi(u"࠲ᖛ")]
		if len(X6FbW1Z2iHaRpP)>KKbpxUZnMcj6AJ4QdD(u"࠴ᖝ"): Fb57I1fr9EYSgOQ60UoksjHL83y = X6FbW1Z2iHaRpP
	return Fb57I1fr9EYSgOQ60UoksjHL83y
def XSuCEhVPZvBIfwyFjipYaRks0(Vwks790B1WaMbmYZSeHqLEP):
	HF1rON7ZYuJ0Usmdk6leDovtIi = repr(Vwks790B1WaMbmYZSeHqLEP.encode(cgtRBdXxSOk7WUfyDhPCls(u"ࠫࡺࡺࡦ࠹ࠩ༿"))).replace(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠧ࠭ࠢཀ"),Tgoa16jMxvYX2(u"࠭ࠧཁ"))
	return HF1rON7ZYuJ0Usmdk6leDovtIi
def KvSsHlYxGB7Dz5uMcbdJ2wt9hyCRj1(AMy6LxUSX0luvJz5KPQa4tVgH):
	FsTOjb9dkpxS3HJMUWc2o = shZ9eOcN2dJnPj(u"ࠧࠨག")
	if bdptXFc8UlIhA5jnGwPmKuv2L: AMy6LxUSX0luvJz5KPQa4tVgH = AMy6LxUSX0luvJz5KPQa4tVgH.decode(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠨࡷࡷࡪ࠽࠭གྷ"))
	from unicodedata import decomposition as cOXskFxRdQP
	for TViO9DFYIBU0GbKy5hZlr3 in AMy6LxUSX0luvJz5KPQa4tVgH:
		if   TViO9DFYIBU0GbKy5hZlr3==nKLEi8CJumazx4qT(u"ࡷࠪฦࠬང"): ohyHq3uBnJpMNW8VLSv7PGRE = ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠪࡠࡡࡻ࠰࠷࠴࠵ࠫཅ")
		elif TViO9DFYIBU0GbKy5hZlr3==bcgZJWV6UeNSkRA(u"ࡹࠬษࠧཆ"): ohyHq3uBnJpMNW8VLSv7PGRE = ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠬࡢ࡜ࡶ࠲࠹࠶࠸࠭ཇ")
		elif TViO9DFYIBU0GbKy5hZlr3==BGhdkWsEvJjiMFTr3NLn1flU(u"ࡻࠧลࠩ཈"): ohyHq3uBnJpMNW8VLSv7PGRE = nKLEi8CJumazx4qT(u"ࠧ࡝࡞ࡸ࠴࠻࠸࠴ࠨཉ")
		elif TViO9DFYIBU0GbKy5hZlr3==yruHDQOcB97ig(u"ࡶࠩศࠫཊ"): ohyHq3uBnJpMNW8VLSv7PGRE = OyJ1o4AvmWlB75UkFRX(u"ࠩ࡟ࡠࡺ࠶࠶࠳࠷ࠪཋ")
		elif TViO9DFYIBU0GbKy5hZlr3==CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࡸࠫห࠭ཌ"): ohyHq3uBnJpMNW8VLSv7PGRE = iifPEY9ABNzTQp(u"ࠫࡡࡢࡵ࠱࠸࠵࠺ࠬཌྷ")
		else:
			CwWn28diYZ1Fh = cOXskFxRdQP(TViO9DFYIBU0GbKy5hZlr3)
			if KKbpxUZnMcj6AJ4QdD(u"ࠬࠦࠧཎ") in CwWn28diYZ1Fh: ohyHq3uBnJpMNW8VLSv7PGRE = M6PIj8gl1fno7wcqTksDEBK4bU(u"࠭࡜࡝ࡷࠪཏ")+CwWn28diYZ1Fh.split(BGhdkWsEvJjiMFTr3NLn1flU(u"ࠧࠡࠩཐ"),wwplD0tEehqH3kYQXs(u"࠵ᖞ"))[wwplD0tEehqH3kYQXs(u"࠵ᖞ")]
			else:
				ohyHq3uBnJpMNW8VLSv7PGRE = usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠨ࠲࠳࠴࠵࠭ད")+hex(ord(TViO9DFYIBU0GbKy5hZlr3)).replace(qnPgZ9N15G6Oa8UpMASvLk(u"ࠩ࠳ࡼࠬདྷ"),PtXn0k9G3ocHRg(u"ࠪࠫན"))
				ohyHq3uBnJpMNW8VLSv7PGRE = XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠫࡡࡢࡵࠨཔ")+ohyHq3uBnJpMNW8VLSv7PGRE[-BGhdkWsEvJjiMFTr3NLn1flU(u"࠹ᖟ"):]
		FsTOjb9dkpxS3HJMUWc2o += ohyHq3uBnJpMNW8VLSv7PGRE
	FsTOjb9dkpxS3HJMUWc2o = FsTOjb9dkpxS3HJMUWc2o.replace(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠬࡢ࡜ࡶ࠲࠹ࡇࡈ࠭ཕ"),yF29Xdsx35wI07Ce4(u"࠭࡜࡝ࡷ࠳࠺࠹࠿ࠧབ"))
	if bdptXFc8UlIhA5jnGwPmKuv2L: FsTOjb9dkpxS3HJMUWc2o = FsTOjb9dkpxS3HJMUWc2o.decode(shZ9eOcN2dJnPj(u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨབྷ")).encode(yruHDQOcB97ig(u"ࠨࡷࡷࡪ࠽࠭མ"))
	else: FsTOjb9dkpxS3HJMUWc2o = FsTOjb9dkpxS3HJMUWc2o.encode(bcgZJWV6UeNSkRA(u"ࠩࡸࡸ࡫࠾ࠧཙ")).decode(pcWq35MED2dtK(u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫཚ"))
	return FsTOjb9dkpxS3HJMUWc2o
def FBrXsYeCEp3(header=CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"้ࠫ๎อสࠢส่๊็วห์ะࠫཛ"),default=cNaVb1vsT4qWOL0rpE(u"ࠬ࠭ཛྷ"),gcsvynDXAJG8lUHfI=vvBChXmSty(u"ࡆࡢ࡮ࡶࡩ᜔"),source=usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠭ࠧཝ")):
	TwPt5qAHlrOsQ = vKl0w97S4DkyqaGmeFsUARoErLOgP(header,default,type=XuWPVcQ13oDq5swf0S.INPUT_ALPHANUM)
	TwPt5qAHlrOsQ = TwPt5qAHlrOsQ.replace(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠧࠡࠢࠪཞ"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠨࠢࠪཟ")).replace(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠩࠣࠤࠬའ"),yF29Xdsx35wI07Ce4(u"ࠪࠤࠬཡ")).replace(BGhdkWsEvJjiMFTr3NLn1flU(u"ࠫࠥࠦࠧར"),wwplD0tEehqH3kYQXs(u"ࠬࠦࠧལ"))
	if not TwPt5qAHlrOsQ and not gcsvynDXAJG8lUHfI:
		l0SAerv8zGH2Wa(yruHDQOcB97ig(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ཤ"),bbw2eajMlG(u"ࠧ࠯ࠢࠣࡏࡪࡿࡢࡰࡣࡵࡨࠥ࡫࡮ࡵࡴࡼࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡀࠠࠡࠢࠥࠫཥ")+TwPt5qAHlrOsQ+bbw2eajMlG(u"ࠨࠤࠪས"))
		xl9MFt1AmY0GrkENug8n(yruHDQOcB97ig(u"ࠩࠪཧ"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠪࠫཨ"),xuztI5QWEKG70CPNdhk4vo6(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧཀྵ"),PtXn0k9G3ocHRg(u"ࠬะๅࠡว็฾ฬวࠠศๆศำำอไࠨཪ"))
		return M6PIj8gl1fno7wcqTksDEBK4bU(u"࠭ࠧཫ")
	if TwPt5qAHlrOsQ not in [bbw2eajMlG(u"ࠧࠨཬ"),PtXn0k9G3ocHRg(u"ࠨࠢࠪ཭")]:
		TwPt5qAHlrOsQ = TwPt5qAHlrOsQ.strip(JLoPRXt93dpAB(u"ࠩࠣࠫ཮"))
		TwPt5qAHlrOsQ = KvSsHlYxGB7Dz5uMcbdJ2wt9hyCRj1(TwPt5qAHlrOsQ)
	if source!=n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗࠬ཯") and dQorkS3qBhIMDWKHl(ggDRehOModi(u"ࠫࡐࡋ࡙ࡃࡑࡄࡖࡉ࠭཰"),bbw2eajMlG(u"ཱࠬ࠭"),[TwPt5qAHlrOsQ],BGhdkWsEvJjiMFTr3NLn1flU(u"ࡇࡣ࡯ࡷࡪ᜕")):
		l0SAerv8zGH2Wa(usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠭ࡎࡐࡖࡌࡇࡊི࠭"),JLoPRXt93dpAB(u"ࠧ࠯ࠢࠣࡏࡪࡿࡢࡰࡣࡵࡨࠥ࡫࡮ࡵࡴࡼࠤࡧࡲ࡯ࡤ࡭ࡨࡨ࠿ࠦࠠࠡࠤཱིࠪ")+TwPt5qAHlrOsQ+XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠨࠤུࠪ"))
		xl9MFt1AmY0GrkENug8n(bcgZJWV6UeNSkRA(u"ཱུࠩࠪ"),bbw2eajMlG(u"ࠪࠫྲྀ"),cgtRBdXxSOk7WUfyDhPCls(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧཷ"),vvBChXmSty(u"ࠬอๆหࠢๆฮอะࠠไๆ่อࠥษ่ࠡำๅ้๊ࠥ็ࠡ฻็ห็ฯࠠษลไ่ฬ๋ࠠๅๆๆฬฬืࠠโไฺࠤ࠳࠴้้ࠠำหࠥอไษำ้ห๊าࠠๅษࠣ๎ุ๋อࠡสสืฯิฯศ็๋่ࠣึวࠡๅ็้ฬะࠧླྀ"))
		return tZ3gsrTEdzA1S6LXa9WI5px(u"࠭ࠧཹ")
	l0SAerv8zGH2Wa(nKLEi8CJumazx4qT(u"ࠧࡏࡑࡗࡍࡈࡋེࠧ"),bbw2eajMlG(u"ࠨ࠰ࠣࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡧ࡬࡭ࡱࡺࡩࡩࡀཻࠠࠡࠢࠥࠫ")+TwPt5qAHlrOsQ+ggDRehOModi(u"ོࠩࠥࠫ"))
	return TwPt5qAHlrOsQ
def bkz2aCFLpWqGUcPolSXA980O(gANn35esloKUydOipfSMC6RD2,emrzEIsMWO2GLw9lpKxSY7n0F={}):
	GMfo7WypIsRin9HKEZQduYhDetFJOS,J7NQRqHziSUr9L0oIZp5Pyej2K,icl3UZqswuGLIHaPyQfjJh2Wp51V,LUfiTovSRszaXI = gANn35esloKUydOipfSMC6RD2,{},{},XikqnGVSK4v9d3uUICLhDxJyt1M(u"ཽࠪࠫ")
	if vvBChXmSty(u"ࠫࢁ࠭ཾ") in gANn35esloKUydOipfSMC6RD2: GMfo7WypIsRin9HKEZQduYhDetFJOS,J7NQRqHziSUr9L0oIZp5Pyej2K = ykfj6Qb9Fc5GiJIvelp84rHDn(gANn35esloKUydOipfSMC6RD2,Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠬࢂࠧཿ"))
	Z6N49UMvBjG71t = list(set(list(emrzEIsMWO2GLw9lpKxSY7n0F.keys())+list(J7NQRqHziSUr9L0oIZp5Pyej2K.keys())))
	for LLalIEnYqHb01Kzs6uo3XvOt8MSV in Z6N49UMvBjG71t:
		if LLalIEnYqHb01Kzs6uo3XvOt8MSV in list(J7NQRqHziSUr9L0oIZp5Pyej2K.keys()): icl3UZqswuGLIHaPyQfjJh2Wp51V[LLalIEnYqHb01Kzs6uo3XvOt8MSV] = J7NQRqHziSUr9L0oIZp5Pyej2K[LLalIEnYqHb01Kzs6uo3XvOt8MSV]
		else: icl3UZqswuGLIHaPyQfjJh2Wp51V[LLalIEnYqHb01Kzs6uo3XvOt8MSV] = emrzEIsMWO2GLw9lpKxSY7n0F[LLalIEnYqHb01Kzs6uo3XvOt8MSV]
	if nKLEi8CJumazx4qT(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶྀࠪ") not in Z6N49UMvBjG71t: icl3UZqswuGLIHaPyQfjJh2Wp51V[bcgZJWV6UeNSkRA(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷཱྀࠫ")] = ncgQBtRa7qT2GJ3Wpd()
	if CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩྂ") not in Z6N49UMvBjG71t: icl3UZqswuGLIHaPyQfjJh2Wp51V[bcgZJWV6UeNSkRA(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪྃ")] = hmcFWJUgiAuGk(GMfo7WypIsRin9HKEZQduYhDetFJOS,yruHDQOcB97ig(u"ࠪࡹࡷࡲ྄ࠧ"))
	for LLalIEnYqHb01Kzs6uo3XvOt8MSV in list(icl3UZqswuGLIHaPyQfjJh2Wp51V.keys()): LUfiTovSRszaXI += xuztI5QWEKG70CPNdhk4vo6(u"ࠫࠫ࠭྅")+LLalIEnYqHb01Kzs6uo3XvOt8MSV+CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠬࡃࠧ྆")+icl3UZqswuGLIHaPyQfjJh2Wp51V[LLalIEnYqHb01Kzs6uo3XvOt8MSV]
	if LUfiTovSRszaXI: LUfiTovSRszaXI = xuztI5QWEKG70CPNdhk4vo6(u"࠭ࡼࠨ྇")+LUfiTovSRszaXI[nKLEi8CJumazx4qT(u"࠷ᖠ"):]
	l3lOuS56hyIdjACkcweb1WDrHQgYfa = zIKYyon9QjcvP8RbpqN4TVC3g(Iu3GUD84WyEqQjPFTYeh1SL9J,cgtRBdXxSOk7WUfyDhPCls(u"ࠧࡈࡇࡗࠫྈ"),GMfo7WypIsRin9HKEZQduYhDetFJOS,wwplD0tEehqH3kYQXs(u"ࠨࠩྉ"),icl3UZqswuGLIHaPyQfjJh2Wp51V,yruHDQOcB97ig(u"ࠩࠪྊ"),shZ9eOcN2dJnPj(u"ࠪࠫྋ"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡕࡔࡄࡇ࡙ࡥࡍ࠴ࡗ࠻࠱࠶ࡹࡴࠨྌ"),Tgoa16jMxvYX2(u"ࡈࡤࡰࡸ࡫᜖"),Tgoa16jMxvYX2(u"ࡈࡤࡰࡸ࡫᜖"))
	DMqcCpg8GmefYtWJZITSP29x3nLzO = l3lOuS56hyIdjACkcweb1WDrHQgYfa.content
	if ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࡙ࠬࡔࡓࡇࡄࡑ࠲ࡏࡎࡇࠩྍ") not in DMqcCpg8GmefYtWJZITSP29x3nLzO: return [n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠭࠭࠲ࠩྎ")],[GMfo7WypIsRin9HKEZQduYhDetFJOS+LUfiTovSRszaXI]
	if XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧࡕ࡛ࡓࡉࡂࡇࡕࡅࡋࡒࠫྏ") in DMqcCpg8GmefYtWJZITSP29x3nLzO: return [xuztI5QWEKG70CPNdhk4vo6(u"ࠨ࠯࠴ࠫྐ")],[GMfo7WypIsRin9HKEZQduYhDetFJOS+LUfiTovSRszaXI]
	if cNaVb1vsT4qWOL0rpE(u"ࠩࡗ࡝ࡕࡋ࠽ࡗࡋࡇࡉࡔ࠭ྑ") in DMqcCpg8GmefYtWJZITSP29x3nLzO: return [yruHDQOcB97ig(u"ࠪ࠱࠶࠭ྒ")],[GMfo7WypIsRin9HKEZQduYhDetFJOS+LUfiTovSRszaXI]
	hVby8e3aQkFfuE,EaBeVhOsHYg8wub,ZxEp7urz93HgG8LKFhla,QVIh9M7CFLJ8AxalifTY2 = [],[],[],[]
	dvulfaW1UAFZ2JSrPxOYyeMHqn = u5h2Rckvw1E.findall(Tgoa16jMxvYX2(u"ࠫࠨࡋࡘࡕ࠯࡛࠱ࡘ࡚ࡒࡆࡃࡐ࠱ࡎࡔࡆ࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱ࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯ࠬྒྷ"),DMqcCpg8GmefYtWJZITSP29x3nLzO+Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠬࡢ࡮ࠨྔ"),u5h2Rckvw1E.DOTALL)
	if not dvulfaW1UAFZ2JSrPxOYyeMHqn: return [yruHDQOcB97ig(u"࠭࠭࠲ࠩྕ")],[GMfo7WypIsRin9HKEZQduYhDetFJOS+LUfiTovSRszaXI]
	for ZaVCxBWH36wEyto4jnusNL1gTmJ0,j0zi47my8EYnhALDIS in dvulfaW1UAFZ2JSrPxOYyeMHqn:
		ddehaksOboRmES,pClJ13jXB4NmPg0WsHI,ohAHUqdbWFi8D1L4Xwzus0f3RYv = {},-yruHDQOcB97ig(u"࠱ᖡ"),-yruHDQOcB97ig(u"࠱ᖡ")
		nG4C3pKLl70QuyvRm = M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠧࠨྖ")
		J3QsyI9w67hK2AF = ZaVCxBWH36wEyto4jnusNL1gTmJ0.split(qnPgZ9N15G6Oa8UpMASvLk(u"ࠨ࠮ࠪྗ"))
		for YI2m5zkZ3ASWF8jK in J3QsyI9w67hK2AF:
			if nKLEi8CJumazx4qT(u"ࠩࡀࠫ྘") in YI2m5zkZ3ASWF8jK:
				LLalIEnYqHb01Kzs6uo3XvOt8MSV,XApzCr15jdx9YK6nRfBq0Q4m = YI2m5zkZ3ASWF8jK.split(oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠪࡁࠬྙ"),iifPEY9ABNzTQp(u"࠲ᖢ"))
				ddehaksOboRmES[LLalIEnYqHb01Kzs6uo3XvOt8MSV.lower()] = XApzCr15jdx9YK6nRfBq0Q4m
		if JLoPRXt93dpAB(u"ࠫࡦࡼࡥࡳࡣࡪࡩ࠲ࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨࠨྚ") in ZaVCxBWH36wEyto4jnusNL1gTmJ0.lower():
			pClJ13jXB4NmPg0WsHI = int(ddehaksOboRmES[xuztI5QWEKG70CPNdhk4vo6(u"ࠬࡧࡶࡦࡴࡤ࡫ࡪ࠳ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩྛ")])//ggDRehOModi(u"࠳࠳࠶࠹ᖣ")
			nG4C3pKLl70QuyvRm += str(pClJ13jXB4NmPg0WsHI)+cNaVb1vsT4qWOL0rpE(u"࠭࡫ࡣࡲࡶࠤࠥ࠭ྜ")
		elif ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠧࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪྜྷ") in ZaVCxBWH36wEyto4jnusNL1gTmJ0.lower():
			pClJ13jXB4NmPg0WsHI = int(ddehaksOboRmES[M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠨࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫྞ")])//cNaVb1vsT4qWOL0rpE(u"࠴࠴࠷࠺ᖤ")
			nG4C3pKLl70QuyvRm += str(pClJ13jXB4NmPg0WsHI)+cNaVb1vsT4qWOL0rpE(u"ࠩ࡮ࡦࡵࡹࠠࠡࠩྟ")
		if xuztI5QWEKG70CPNdhk4vo6(u"ࠪࡶࡪࡹ࡯࡭ࡷࡷ࡭ࡴࡴࠧྠ") in ZaVCxBWH36wEyto4jnusNL1gTmJ0.lower():
			ohAHUqdbWFi8D1L4Xwzus0f3RYv = int(ddehaksOboRmES[qnPgZ9N15G6Oa8UpMASvLk(u"ࠫࡷ࡫ࡳࡰ࡮ࡸࡸ࡮ࡵ࡮ࠨྡ")].split(M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠬࡾࠧྡྷ"))[cgtRBdXxSOk7WUfyDhPCls(u"࠵ᖥ")])
			nG4C3pKLl70QuyvRm += str(ohAHUqdbWFi8D1L4Xwzus0f3RYv)+bcgZJWV6UeNSkRA(u"࠭ࠠࠡࠩྣ")
		nG4C3pKLl70QuyvRm = nG4C3pKLl70QuyvRm.strip(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠧࠡࠢࠪྤ"))
		if not nG4C3pKLl70QuyvRm: nG4C3pKLl70QuyvRm = BGhdkWsEvJjiMFTr3NLn1flU(u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩྥ")
		if not j0zi47my8EYnhALDIS.startswith(oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠩ࡫ࡸࡹࡶࠧྦ")):
			if j0zi47my8EYnhALDIS.startswith(yF29Xdsx35wI07Ce4(u"ࠪ࠳࠴࠭ྦྷ")): j0zi47my8EYnhALDIS = GMfo7WypIsRin9HKEZQduYhDetFJOS.split(usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠫ࠿࠭ྨ"),iifPEY9ABNzTQp(u"࠶ᖦ"))[qnPgZ9N15G6Oa8UpMASvLk(u"࠶ᖧ")]+OyJ1o4AvmWlB75UkFRX(u"ࠬࡀࠧྩ")+j0zi47my8EYnhALDIS
			elif j0zi47my8EYnhALDIS.startswith(vvBChXmSty(u"࠭࠯ࠨྪ")): j0zi47my8EYnhALDIS = hmcFWJUgiAuGk(GMfo7WypIsRin9HKEZQduYhDetFJOS,yruHDQOcB97ig(u"ࠧࡶࡴ࡯ࠫྫ"))+j0zi47my8EYnhALDIS
			else: j0zi47my8EYnhALDIS = GMfo7WypIsRin9HKEZQduYhDetFJOS.rsplit(BGhdkWsEvJjiMFTr3NLn1flU(u"ࠨ࠱ࠪྫྷ"),yruHDQOcB97ig(u"࠱ᖨ"))[iifPEY9ABNzTQp(u"࠱ᖩ")]+usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩ࠲ࠫྭ")+j0zi47my8EYnhALDIS
		if nKLEi8CJumazx4qT(u"ࠪࡴࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥ࠮ࡷࡵ࡭ࠬྮ") in list(ddehaksOboRmES.keys()):
			olm59qifJbWpRsr1a3X7zBEIA = ddehaksOboRmES[ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠫࡵࡸ࡯ࡨࡴࡨࡷࡸ࡯ࡶࡦ࠯ࡸࡶ࡮࠭ྯ")]
			olm59qifJbWpRsr1a3X7zBEIA = olm59qifJbWpRsr1a3X7zBEIA.replace(bcgZJWV6UeNSkRA(u"ࠬࠨࠧྰ"),pcWq35MED2dtK(u"࠭ࠧྱ")).replace(PtXn0k9G3ocHRg(u"ࠢࠨࠤྲ"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠨࠩླ")).split(KKbpxUZnMcj6AJ4QdD(u"ࠩࠦࠫྴ"),tZ3gsrTEdzA1S6LXa9WI5px(u"࠳ᖪ"))[XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠳ᖫ")]
			ViRnO0m8fUScTNauvW = XS8G7Ljnkut(olm59qifJbWpRsr1a3X7zBEIA)
			if ViRnO0m8fUScTNauvW: cMpjL2oavyVwKHBPn8EdhYqxSUk = nG4C3pKLl70QuyvRm+bbw2eajMlG(u"ࠪࠤࠥ࠭ྵ")+ViRnO0m8fUScTNauvW
			else: cMpjL2oavyVwKHBPn8EdhYqxSUk = nG4C3pKLl70QuyvRm
			cMpjL2oavyVwKHBPn8EdhYqxSUk = cMpjL2oavyVwKHBPn8EdhYqxSUk+KKbpxUZnMcj6AJ4QdD(u"ࠫࠥࠦࡐࡳࡱࡪࡶࡪࡹࡳࡪࡸࡨࠫྶ")
			cMpjL2oavyVwKHBPn8EdhYqxSUk = cMpjL2oavyVwKHBPn8EdhYqxSUk+qnPgZ9N15G6Oa8UpMASvLk(u"ࠬࠦࠠࠨྷ")+hmcFWJUgiAuGk(olm59qifJbWpRsr1a3X7zBEIA,ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠭࡮ࡢ࡯ࡨࠫྸ"))
			hVby8e3aQkFfuE.append(cMpjL2oavyVwKHBPn8EdhYqxSUk)
			EaBeVhOsHYg8wub.append(olm59qifJbWpRsr1a3X7zBEIA)
			ZxEp7urz93HgG8LKFhla.append(ohAHUqdbWFi8D1L4Xwzus0f3RYv)
			QVIh9M7CFLJ8AxalifTY2.append(pClJ13jXB4NmPg0WsHI)
		j0zi47my8EYnhALDIS = j0zi47my8EYnhALDIS.split(shZ9eOcN2dJnPj(u"ࠧࠤࠩྐྵ"),iifPEY9ABNzTQp(u"࠵ᖬ"))[bcgZJWV6UeNSkRA(u"࠵ᖭ")]
		ViRnO0m8fUScTNauvW = XS8G7Ljnkut(j0zi47my8EYnhALDIS)
		if ViRnO0m8fUScTNauvW: nG4C3pKLl70QuyvRm = nG4C3pKLl70QuyvRm+Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠨࠢࠣࠫྺ")+ViRnO0m8fUScTNauvW
		nG4C3pKLl70QuyvRm = nG4C3pKLl70QuyvRm+r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠩࠣࠤࠬྻ")+hmcFWJUgiAuGk(j0zi47my8EYnhALDIS,nKLEi8CJumazx4qT(u"ࠪࡲࡦࡳࡥࠨྼ"))
		hVby8e3aQkFfuE.append(nG4C3pKLl70QuyvRm)
		EaBeVhOsHYg8wub.append(j0zi47my8EYnhALDIS)
		ZxEp7urz93HgG8LKFhla.append(ohAHUqdbWFi8D1L4Xwzus0f3RYv)
		QVIh9M7CFLJ8AxalifTY2.append(pClJ13jXB4NmPg0WsHI)
	Cme2tRqGfkrX = list(zip(hVby8e3aQkFfuE,EaBeVhOsHYg8wub,ZxEp7urz93HgG8LKFhla,QVIh9M7CFLJ8AxalifTY2))
	Cme2tRqGfkrX = sorted(Cme2tRqGfkrX, reverse=xuztI5QWEKG70CPNdhk4vo6(u"ࡗࡶࡺ࡫᜗"), key=lambda key: key[vvBChXmSty(u"࠹ᖮ")])
	hVby8e3aQkFfuE,EaBeVhOsHYg8wub,ZxEp7urz93HgG8LKFhla,QVIh9M7CFLJ8AxalifTY2 = list(zip(*Cme2tRqGfkrX))
	hVby8e3aQkFfuE,EaBeVhOsHYg8wub = list(hVby8e3aQkFfuE),list(EaBeVhOsHYg8wub)
	QJmOuSTlKhFXVnPo2M5x81qjsAfLbI = []
	for j0zi47my8EYnhALDIS in EaBeVhOsHYg8wub: QJmOuSTlKhFXVnPo2M5x81qjsAfLbI.append(j0zi47my8EYnhALDIS+LUfiTovSRszaXI)
	return hVby8e3aQkFfuE,QJmOuSTlKhFXVnPo2M5x81qjsAfLbI
def d346GzJPjvka9xSbMADlnsQgu52L(j8K3TBfiH1GgXJmC,b409vpr8PJYsiZaOxRdVko=M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠫࠬ྽")):
	if not b409vpr8PJYsiZaOxRdVko: b409vpr8PJYsiZaOxRdVko = kH5Khue7Fic[tZ3gsrTEdzA1S6LXa9WI5px(u"࠰ᖯ")]
	if j8K3TBfiH1GgXJmC.replace(shZ9eOcN2dJnPj(u"ࠬ࠴ࠧ྾"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠭ࠧ྿")).isdigit(): return [j8K3TBfiH1GgXJmC]
	from struct import pack as fegvwY5HC43GbZn,unpack_from as q7gYAhzyCTFBEdx
	from socket import socket as mJNCKBxoGEw5X1tAfLOhgMivQzeI9c,AF_INET as U0ecS5D43xq1XngdI97rjVThBf8,SOCK_DGRAM as c8kJEntvwodRYrAPblQX57f
	try:
		RnGw4rO820vheNEmpK63Q = fegvwY5HC43GbZn(bbw2eajMlG(u"ࠢ࠿ࡊࠥ࿀"), n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠲࠴࠳࠸࠾ᖰ"))
		RnGw4rO820vheNEmpK63Q += fegvwY5HC43GbZn(bbw2eajMlG(u"ࠣࡀࡋࠦ࿁"), oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠴࠸࠺ᖱ"))
		RnGw4rO820vheNEmpK63Q += fegvwY5HC43GbZn(r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠤࡁࡌࠧ࿂"), tZ3gsrTEdzA1S6LXa9WI5px(u"࠴ᖲ"))
		RnGw4rO820vheNEmpK63Q += fegvwY5HC43GbZn(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠥࡂࡍࠨ࿃"), ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠴ᖳ"))
		RnGw4rO820vheNEmpK63Q += fegvwY5HC43GbZn(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠦࡃࡎࠢ࿄"), pcWq35MED2dtK(u"࠵ᖴ"))
		RnGw4rO820vheNEmpK63Q += fegvwY5HC43GbZn(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠧࡄࡈࠣ࿅"), wwplD0tEehqH3kYQXs(u"࠶ᖵ"))
		if VVGRN7xiyj: cxKHI28zMtU17 = j8K3TBfiH1GgXJmC.split(tZ3gsrTEdzA1S6LXa9WI5px(u"࠭࠮ࠨ࿆"))
		else: cxKHI28zMtU17 = j8K3TBfiH1GgXJmC.decode(shZ9eOcN2dJnPj(u"ࠧࡶࡶࡩ࠼ࠬ࿇")).split(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠨ࠰ࠪ࿈"))
		for i6ZJAIgpx8S4wCL1FnPDqy5coKGHdV in cxKHI28zMtU17:
			To8FtWcDkAI7e0w = i6ZJAIgpx8S4wCL1FnPDqy5coKGHdV.encode(PtXn0k9G3ocHRg(u"ࠩࡸࡸ࡫࠾ࠧ࿉"))
			RnGw4rO820vheNEmpK63Q += fegvwY5HC43GbZn(BGhdkWsEvJjiMFTr3NLn1flU(u"ࠥࡆࠧ࿊"), len(i6ZJAIgpx8S4wCL1FnPDqy5coKGHdV))
			for cF0rHNhwzk in i6ZJAIgpx8S4wCL1FnPDqy5coKGHdV:
				RnGw4rO820vheNEmpK63Q += fegvwY5HC43GbZn(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠦࡨࠨ࿋"), cF0rHNhwzk.encode(qnPgZ9N15G6Oa8UpMASvLk(u"ࠬࡻࡴࡧ࠺ࠪ࿌")))
		RnGw4rO820vheNEmpK63Q += fegvwY5HC43GbZn(usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠨࡂࠣ࿍"), yruHDQOcB97ig(u"࠰ᖶ"))
		RnGw4rO820vheNEmpK63Q += fegvwY5HC43GbZn(cgtRBdXxSOk7WUfyDhPCls(u"ࠢ࠿ࡊࠥ࿎"), XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠲ᖷ"))
		RnGw4rO820vheNEmpK63Q += fegvwY5HC43GbZn(nKLEi8CJumazx4qT(u"ࠣࡀࡋࠦ࿏"), qnPgZ9N15G6Oa8UpMASvLk(u"࠳ᖸ"))
		F7ALO3mQs1a = mJNCKBxoGEw5X1tAfLOhgMivQzeI9c(U0ecS5D43xq1XngdI97rjVThBf8,c8kJEntvwodRYrAPblQX57f)
		F7ALO3mQs1a.sendto(bytes(RnGw4rO820vheNEmpK63Q), (b409vpr8PJYsiZaOxRdVko, iifPEY9ABNzTQp(u"࠸࠷ᖹ")))
		F7ALO3mQs1a.settimeout(drHLAY5ENQFe2q9ptKGabo(u"࠺ᖺ"))
		MNWrTo98GZHn, O6zpZNGrIxtBcJAeX5 = F7ALO3mQs1a.recvfrom(yF29Xdsx35wI07Ce4(u"࠶࠶࠲࠵ᖻ"))
		F7ALO3mQs1a.close()
		Q0QaVWPtoGmDFZc8Kj = q7gYAhzyCTFBEdx(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠤࡁࡌࡍࡎࡈࡉࡊࠥ࿐"), MNWrTo98GZHn, nKLEi8CJumazx4qT(u"࠶ᖼ"))
		lHwFoIxGTtdusvO4EaVB0WX5My = Q0QaVWPtoGmDFZc8Kj[bcgZJWV6UeNSkRA(u"࠳ᖽ")]
		ppRmIVcqfBT2Y5F4hOytNu = len(j8K3TBfiH1GgXJmC)+r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠲࠺ᖾ")
		Oi8pLbT4W12ortZkhIaMRym3YlXcdq = []
		for _BuLsTZJ0liFj5mSgUWp7z in range(lHwFoIxGTtdusvO4EaVB0WX5My):
			PFotMx1J8rkOUyDnm7azALEZsH = ppRmIVcqfBT2Y5F4hOytNu
			ZjeirM16AbzmJgyvQSq8pGE = pcWq35MED2dtK(u"࠳ᖿ")
			GzWkCjVfEbsp = Tgoa16jMxvYX2(u"ࡊࡦࡲࡳࡦ᜘")
			while KKbpxUZnMcj6AJ4QdD(u"࡙ࡸࡵࡦ᜙"):
				cF0rHNhwzk = q7gYAhzyCTFBEdx(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠥࡂࡇࠨ࿑"), MNWrTo98GZHn, PFotMx1J8rkOUyDnm7azALEZsH)[qnPgZ9N15G6Oa8UpMASvLk(u"࠳ᗀ")]
				if cF0rHNhwzk == cgtRBdXxSOk7WUfyDhPCls(u"࠴ᗁ"):
					PFotMx1J8rkOUyDnm7azALEZsH += qnPgZ9N15G6Oa8UpMASvLk(u"࠶ᗂ")
					break
				if cF0rHNhwzk >= OyJ1o4AvmWlB75UkFRX(u"࠷࠹࠳ᗃ"):
					ymxcCfPz5gunNVO4lkiv = q7gYAhzyCTFBEdx(BGhdkWsEvJjiMFTr3NLn1flU(u"ࠦࡃࡈࠢ࿒"), MNWrTo98GZHn, PFotMx1J8rkOUyDnm7azALEZsH + yruHDQOcB97ig(u"࠱ᗄ"))[tZ3gsrTEdzA1S6LXa9WI5px(u"࠱ᗅ")]
					PFotMx1J8rkOUyDnm7azALEZsH = ((cF0rHNhwzk << yF29Xdsx35wI07Ce4(u"࠻ᗇ")) + ymxcCfPz5gunNVO4lkiv - 0xc000) - CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠳ᗆ")
					GzWkCjVfEbsp = bbw2eajMlG(u"࡚ࡲࡶࡧ᜚")
				PFotMx1J8rkOUyDnm7azALEZsH += CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠵ᗈ")
				if GzWkCjVfEbsp == oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࡆࡢ࡮ࡶࡩ᜛"): ZjeirM16AbzmJgyvQSq8pGE += cgtRBdXxSOk7WUfyDhPCls(u"࠶ᗉ")
			if GzWkCjVfEbsp == n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࡕࡴࡸࡩ᜜"): ZjeirM16AbzmJgyvQSq8pGE += vvBChXmSty(u"࠷ᗊ")
			ppRmIVcqfBT2Y5F4hOytNu = ppRmIVcqfBT2Y5F4hOytNu + ZjeirM16AbzmJgyvQSq8pGE
			OBUmjhIk4YVaRXMfte8r7sqKH2z = q7gYAhzyCTFBEdx(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠧࡄࡈࡉࡋࡋࠦ࿓"), MNWrTo98GZHn, ppRmIVcqfBT2Y5F4hOytNu)
			ppRmIVcqfBT2Y5F4hOytNu = ppRmIVcqfBT2Y5F4hOytNu + BGhdkWsEvJjiMFTr3NLn1flU(u"࠱࠱ᗋ")
			CoeTmUzObxtEDryH2wK65gdJcu7 = OBUmjhIk4YVaRXMfte8r7sqKH2z[XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠱ᗌ")]
			c09b1DpNRomleujsEOkU26 = OBUmjhIk4YVaRXMfte8r7sqKH2z[qnPgZ9N15G6Oa8UpMASvLk(u"࠵ᗍ")]
			if CoeTmUzObxtEDryH2wK65gdJcu7 == tZ3gsrTEdzA1S6LXa9WI5px(u"࠴ᗎ"):
				pHAN5Kzuiyk = q7gYAhzyCTFBEdx(bbw2eajMlG(u"ࠨ࠾ࠣ࿔")+Tgoa16jMxvYX2(u"ࠢࡃࠤ࿕")*c09b1DpNRomleujsEOkU26, MNWrTo98GZHn, ppRmIVcqfBT2Y5F4hOytNu)
				ip = wwplD0tEehqH3kYQXs(u"ࠨࠩ࿖")
				for cF0rHNhwzk in pHAN5Kzuiyk: ip += str(cF0rHNhwzk) + usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩ࠱ࠫ࿗")
				ip = ip[M6PIj8gl1fno7wcqTksDEBK4bU(u"࠵ᗐ"):-oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠵ᗏ")]
				Oi8pLbT4W12ortZkhIaMRym3YlXcdq.append(ip)
			if CoeTmUzObxtEDryH2wK65gdJcu7 in [vvBChXmSty(u"࠲ᗓ"),cgtRBdXxSOk7WUfyDhPCls(u"࠴ᗔ"),pcWq35MED2dtK(u"࠸ᗕ"),InKG0i2r6hHDvgd(u"࠺ᗖ"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠷࠵ᗑ"),wwplD0tEehqH3kYQXs(u"࠲࠹ᗒ")]: ppRmIVcqfBT2Y5F4hOytNu = ppRmIVcqfBT2Y5F4hOytNu + c09b1DpNRomleujsEOkU26
	except: Oi8pLbT4W12ortZkhIaMRym3YlXcdq = []
	if not Oi8pLbT4W12ortZkhIaMRym3YlXcdq: l0SAerv8zGH2Wa(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ࿘"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+bbw2eajMlG(u"ࠫࠥࠦࠠࡅࡐࡖࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡊࡲࡷࡹࡀࠠ࡜ࠢࠪ࿙")+j8K3TBfiH1GgXJmC+Tgoa16jMxvYX2(u"ࠬࠦ࡝ࠨ࿚"))
	return Oi8pLbT4W12ortZkhIaMRym3YlXcdq
def dQorkS3qBhIMDWKHl(aUVSgO2ebjwX5iqPykC,GMfo7WypIsRin9HKEZQduYhDetFJOS,PmF0XjQN51GpKACfLgnyTv7,showDialogs=yF29Xdsx35wI07Ce4(u"ࡖࡵࡹࡪ᜝")):
	if PmF0XjQN51GpKACfLgnyTv7:
		kkd0IvZGCmblORKp7UWA9afYo = [ggDRehOModi(u"࠭ใษษิࠫ࿛"),xuztI5QWEKG70CPNdhk4vo6(u"ࠧษษ็฾ࠬ࿜"),KKbpxUZnMcj6AJ4QdD(u"ࠨࡣࡧࡹࡱࡺࠧ࿝"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠩࡻࡼࠬ࿞"),wwplD0tEehqH3kYQXs(u"ࠪࡷࡪࡾࠧ࿟")]
		if aUVSgO2ebjwX5iqPykC!=XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠫࡇࡕࡋࡓࡃࠪ࿠"):
			kkd0IvZGCmblORKp7UWA9afYo += [drHLAY5ENQFe2q9ptKGabo(u"ࠬࡸ࠺ࠨ࿡"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠭ࡲ࠮ࠩ࿢"),shZ9eOcN2dJnPj(u"ࠧ࠮࡯ࡤࠫ࿣")]
			kkd0IvZGCmblORKp7UWA9afYo += [oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠨ࠼ࡵࠫ࿤"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠩ࠰ࡶࠬ࿥"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠪࡱࡦ࠳ࠧ࿦")]
		for KS8ZsVdAjf in PmF0XjQN51GpKACfLgnyTv7:
			if n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠫ࡬࡫ࡴ࠯ࡲ࡫ࡴࡄ࠭࿧") in KS8ZsVdAjf: continue
			if InKG0i2r6hHDvgd(u"ࠬำไใหࠪ࿨") in KS8ZsVdAjf: continue
			KS8ZsVdAjf = KS8ZsVdAjf.lower()
			if bdptXFc8UlIhA5jnGwPmKuv2L: KS8ZsVdAjf = KS8ZsVdAjf.decode(nKLEi8CJumazx4qT(u"࠭ࡵࡵࡨ࠻ࠫ࿩")).encode(PtXn0k9G3ocHRg(u"ࠧࡶࡶࡩ࠼ࠬ࿪"))
			KS8ZsVdAjf = KS8ZsVdAjf.replace(pcWq35MED2dtK(u"ࠨ࠼ࠪ࿫"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠩࠪ࿬"))
			zchAjxOkFE7KMpnt36vPa85QUXCY = u5h2Rckvw1E.findall(bbw2eajMlG(u"ࠪࠬ࠶ࡡ࠵࠮࠻ࡠ࠯ࢁ࠸࡛࠱࠯࠶ࡡ࠰࠯ࠧ࿭"),KS8ZsVdAjf,u5h2Rckvw1E.DOTALL)
			wm40Lo3M2nlP9Qx = shZ9eOcN2dJnPj(u"ࡉࡥࡱࡹࡥ᜞")
			for QXzMJTZlnAdctuD in zchAjxOkFE7KMpnt36vPa85QUXCY:
				if len(QXzMJTZlnAdctuD)==tZ3gsrTEdzA1S6LXa9WI5px(u"࠷ᗗ"):
					wm40Lo3M2nlP9Qx = ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࡘࡷࡻࡥᜟ")
					break
			if tZ3gsrTEdzA1S6LXa9WI5px(u"ࠫࡳࡵࡴࠡࡴࡤࡸࡪࡪࠧ࿮") in KS8ZsVdAjf: continue
			elif usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠬࡻ࡮ࡳࡣࡷࡩࡩ࠭࿯") in KS8ZsVdAjf: continue
			elif bcgZJWV6UeNSkRA(u"ฺ๋࠭ำฺ้ࠣ์แࠨ࿰") in KS8ZsVdAjf: continue
			elif yrPav1tl5MQcfEBhsXk2o(xuztI5QWEKG70CPNdhk4vo6(u"ࠧࡃࡖࡈࡼࡕ࡜࠱࠺ࡕࡕ࡚ࡓ࡛ࡕ࡭ࡘࡇ࡚ࡊ࡜ࡅ࡙ࠩ࿱")): continue
			elif KS8ZsVdAjf in [InKG0i2r6hHDvgd(u"ࠨࡴࠪ࿲")] or wm40Lo3M2nlP9Qx or any(c2eEflztvIX in KS8ZsVdAjf for c2eEflztvIX in kkd0IvZGCmblORKp7UWA9afYo):
				l0SAerv8zGH2Wa(usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ࿳"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+yF29Xdsx35wI07Ce4(u"ࠪࠤࠥࠦࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡢࡦࡸࡰࡹࡹࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ࿴")+GMfo7WypIsRin9HKEZQduYhDetFJOS+BGhdkWsEvJjiMFTr3NLn1flU(u"ࠫࠥࡣࠧ࿵"))
				if showDialogs: dnS80F92qtLi4vw1(iifPEY9ABNzTQp(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࿶"),qnPgZ9N15G6Oa8UpMASvLk(u"࠭วๅใํำ๏๎ࠠๅๆๆฬฬืࠠโไฺࠤํษๆศ่๊ࠢ฾ะ็ࠨ࿷"))
				return tZ3gsrTEdzA1S6LXa9WI5px(u"࡙ࡸࡵࡦᜠ")
	return xuztI5QWEKG70CPNdhk4vo6(u"ࡌࡡ࡭ࡵࡨᜡ")
def xl9MFt1AmY0GrkENug8n(*aargs,**kkwargs):
	if aargs:
		direction = aargs[cNaVb1vsT4qWOL0rpE(u"࠶ᗘ")]
		FDCNhjGdpW1Loa2JOlrb0vS = aargs[xuztI5QWEKG70CPNdhk4vo6(u"࠱ᗙ")]
		if not direction: direction = yruHDQOcB97ig(u"ࠧࡤࡧࡱࡸࡪࡸࠧ࿸")
		if not FDCNhjGdpW1Loa2JOlrb0vS: FDCNhjGdpW1Loa2JOlrb0vS = iifPEY9ABNzTQp(u"ࠨษึฮ๊ืวาࠩ࿹")
		rD8sEn7jzheBQqfH = aargs[oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠳ᗚ")]
		TwPt5qAHlrOsQ = yruHDQOcB97ig(u"ࠩ࡟ࡲࠬ࿺").join(aargs[ggDRehOModi(u"࠵ᗛ"):])
	else: direction,FDCNhjGdpW1Loa2JOlrb0vS,rD8sEn7jzheBQqfH,TwPt5qAHlrOsQ = bbw2eajMlG(u"ࠪࠫ࿻"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠫࡔࡑࠧ࿼"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࠬ࠭࿽"),nKLEi8CJumazx4qT(u"࠭ࠧ࿾")
	lRwnVNxCZXGgkqd390(direction,xuztI5QWEKG70CPNdhk4vo6(u"ࠧࠨ࿿"),FDCNhjGdpW1Loa2JOlrb0vS,JLoPRXt93dpAB(u"ࠨࠩက"),rD8sEn7jzheBQqfH,TwPt5qAHlrOsQ,**kkwargs)
	return
def lLPSDywfu4axrUhvX9RQEpGtso6H0(*aargs,**kkwargs):
	direction = aargs[ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠳ᗜ")]
	MwrNG0pDjfy9uzE435BtTUAWLcJOX = aargs[tZ3gsrTEdzA1S6LXa9WI5px(u"࠵ᗝ")]
	FkeV75DmlpOtABTsyXdQ8YzC = aargs[Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠷ᗞ")]
	if FkeV75DmlpOtABTsyXdQ8YzC or MwrNG0pDjfy9uzE435BtTUAWLcJOX: vv3rKYp4nVTcjRDGNfl0MwqJIeX = yF29Xdsx35wI07Ce4(u"ࡔࡳࡷࡨᜢ")
	else: vv3rKYp4nVTcjRDGNfl0MwqJIeX = ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࡇࡣ࡯ࡷࡪᜣ")
	rD8sEn7jzheBQqfH = aargs[pcWq35MED2dtK(u"࠹ᗟ")]
	TwPt5qAHlrOsQ = aargs[qnPgZ9N15G6Oa8UpMASvLk(u"࠴ᗠ")]
	if not direction: direction = cgtRBdXxSOk7WUfyDhPCls(u"ࠩࡦࡩࡳࡺࡥࡳࠩခ")
	if not MwrNG0pDjfy9uzE435BtTUAWLcJOX: MwrNG0pDjfy9uzE435BtTUAWLcJOX = nKLEi8CJumazx4qT(u"ࠪ็้อࠠࠡࡐࡲࠫဂ")
	if not FkeV75DmlpOtABTsyXdQ8YzC: FkeV75DmlpOtABTsyXdQ8YzC = bcgZJWV6UeNSkRA(u"๋ࠫ฿ๅࠡࠢ࡜ࡩࡸ࠭ဃ")
	if len(aargs)>=ggDRehOModi(u"࠸ᗢ"): TwPt5qAHlrOsQ += XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠬࡢ࡮ࠨင")+aargs[InKG0i2r6hHDvgd(u"࠶ᗡ")]
	if len(aargs)>=cgtRBdXxSOk7WUfyDhPCls(u"࠺ᗣ"): TwPt5qAHlrOsQ += JLoPRXt93dpAB(u"࠭࡜࡯ࠩစ")+aargs[CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠺ᗤ")]
	OdN8EyB3LDqfoJCg = lRwnVNxCZXGgkqd390(direction,MwrNG0pDjfy9uzE435BtTUAWLcJOX,JLoPRXt93dpAB(u"ࠧࠨဆ"),FkeV75DmlpOtABTsyXdQ8YzC,rD8sEn7jzheBQqfH,TwPt5qAHlrOsQ,**kkwargs)
	if OdN8EyB3LDqfoJCg==-BGhdkWsEvJjiMFTr3NLn1flU(u"࠶ᗥ") and vv3rKYp4nVTcjRDGNfl0MwqJIeX: OdN8EyB3LDqfoJCg = -BGhdkWsEvJjiMFTr3NLn1flU(u"࠶ᗥ")
	elif OdN8EyB3LDqfoJCg==-Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠷ᗦ") and not vv3rKYp4nVTcjRDGNfl0MwqJIeX: OdN8EyB3LDqfoJCg = cgtRBdXxSOk7WUfyDhPCls(u"ࡈࡤࡰࡸ࡫ᜤ")
	elif OdN8EyB3LDqfoJCg==Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠰ᗧ"): OdN8EyB3LDqfoJCg = wwplD0tEehqH3kYQXs(u"ࡉࡥࡱࡹࡥᜥ")
	elif OdN8EyB3LDqfoJCg==pcWq35MED2dtK(u"࠳ᗨ"): OdN8EyB3LDqfoJCg = XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࡘࡷࡻࡥᜦ")
	return OdN8EyB3LDqfoJCg
def tYysxJLreEBDdXMIjz4OPa(*aargs,**kkwargs):
	return XuWPVcQ13oDq5swf0S.Dialog().select(*aargs,**kkwargs)
def dnS80F92qtLi4vw1(*aargs,**kkwargs):
	rD8sEn7jzheBQqfH = aargs[drHLAY5ENQFe2q9ptKGabo(u"࠲ᗩ")]
	TwPt5qAHlrOsQ = aargs[qnPgZ9N15G6Oa8UpMASvLk(u"࠴ᗪ")]
	if shZ9eOcN2dJnPj(u"ࠨࡶ࡬ࡱࡪ࠭ဇ") in list(kkwargs.keys()): nZhOPB7evJE8XVN6FagWCsKUc = kkwargs[qnPgZ9N15G6Oa8UpMASvLk(u"ࠩࡷ࡭ࡲ࡫ࠧဈ")]
	else: nZhOPB7evJE8XVN6FagWCsKUc = cgtRBdXxSOk7WUfyDhPCls(u"࠵࠵࠶࠰ᗫ")
	if len(aargs)>yruHDQOcB97ig(u"࠷ᗬ") and BGhdkWsEvJjiMFTr3NLn1flU(u"ࠪࡸ࡮ࡳࡥࠨဉ") not in aargs[yruHDQOcB97ig(u"࠷ᗬ")]: profile = aargs[yruHDQOcB97ig(u"࠷ᗬ")]
	else: profile = iifPEY9ABNzTQp(u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࠪည")
	PoLaNz8hdcUIrFgv = qZzjySC63LWVAovla2TIUfpF9uxg0i(drHLAY5ENQFe2q9ptKGabo(u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡓࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡌࡱࡦ࡭ࡥ࠯ࡺࡰࡰࠬဋ"),b69iT7LWwrfXzGYPMvBCsteVHDQK,M6PIj8gl1fno7wcqTksDEBK4bU(u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧဌ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠧ࠸࠴࠳ࡴࠬဍ"))
	image_filename = Wgy3rdVP0HqnsA2N59FfbITu6Bh.replace(JLoPRXt93dpAB(u"ࠨࡡ࠳࠴࠵࠶࡟ࠨဎ"),vvBChXmSty(u"ࠩࡢࠫဏ")+str(YVJPFvuI2CS5KObiZt.time())+M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠪࡣࠬတ"))
	image_filename = image_filename.replace(iifPEY9ABNzTQp(u"ࠫࡡࡢࠧထ"),xuztI5QWEKG70CPNdhk4vo6(u"ࠬࡢ࡜࡝࡞ࠪဒ")).replace(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠭࠯࠰ࠩဓ"),nKLEi8CJumazx4qT(u"ࠧ࠰࠱࠲࠳ࠬန"))
	image_height = WedGKhM8a0(oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠨࠩပ"),OyJ1o4AvmWlB75UkFRX(u"ࠩࠪဖ"),yruHDQOcB97ig(u"ࠪࠫဗ"),rD8sEn7jzheBQqfH,TwPt5qAHlrOsQ,profile,yruHDQOcB97ig(u"ࠫࡱ࡫ࡦࡵࠩဘ"),yruHDQOcB97ig(u"ࡋࡧ࡬ࡴࡧᜧ"),image_filename)
	PoLaNz8hdcUIrFgv.show()
	if profile==bbw2eajMlG(u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡣࡹࡽ࡯ࡩࡣ࡯ࡪࡸ࠭မ"):
		PoLaNz8hdcUIrFgv.getControl(iifPEY9ABNzTQp(u"࠹࠱࠶࠳ᗮ")).setHeight(cNaVb1vsT4qWOL0rpE(u"࠸࠱࠶ᗭ"))
		PoLaNz8hdcUIrFgv.getControl(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠼࠴࠹࠶ᗱ")).setPosition(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠶࠷ᗯ"),-drHLAY5ENQFe2q9ptKGabo(u"࠺࠳ᗰ"))
		PoLaNz8hdcUIrFgv.getControl(M6PIj8gl1fno7wcqTksDEBK4bU(u"࠽࠵࠻࠰ᗲ")).setPosition(qnPgZ9N15G6Oa8UpMASvLk(u"࠶࠸࠰ᗳ"),-yruHDQOcB97ig(u"࠼࠰ᗴ"))
		PoLaNz8hdcUIrFgv.getControl(r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠶࠳࠴ᗷ")).setPosition(cNaVb1vsT4qWOL0rpE(u"࠹࠱ᗵ"),-bbw2eajMlG(u"࠴࠷ᗶ"))
	PoLaNz8hdcUIrFgv.getControl(qnPgZ9N15G6Oa8UpMASvLk(u"࠷࠴࠶ᗸ")).setVisible(ggDRehOModi(u"ࡌࡡ࡭ࡵࡨᜨ"))
	PoLaNz8hdcUIrFgv.getControl(KKbpxUZnMcj6AJ4QdD(u"࠸࠵࠸ᗹ")).setVisible(iifPEY9ABNzTQp(u"ࡆࡢ࡮ࡶࡩᜩ"))
	PoLaNz8hdcUIrFgv.getControl(xuztI5QWEKG70CPNdhk4vo6(u"࠾࠶࠵࠱ᗺ")).setImage(image_filename)
	PoLaNz8hdcUIrFgv.getControl(shZ9eOcN2dJnPj(u"࠿࠰࠶࠲ᗻ")).setHeight(image_height)
	wGq2JfjSiF = onVDrgLUpFsqOPkxId9BwW6Rtc5A.Thread(target=gmIt6l1eoqRGyDczMj7T,args=(PoLaNz8hdcUIrFgv,image_filename,nZhOPB7evJE8XVN6FagWCsKUc))
	wGq2JfjSiF.start()
	return
def gmIt6l1eoqRGyDczMj7T(PoLaNz8hdcUIrFgv,image_filename,nZhOPB7evJE8XVN6FagWCsKUc):
	YVJPFvuI2CS5KObiZt.sleep(nZhOPB7evJE8XVN6FagWCsKUc//KKbpxUZnMcj6AJ4QdD(u"࠱࠱࠲࠳࠲࠵ᗼ"))
	YVJPFvuI2CS5KObiZt.sleep(yF29Xdsx35wI07Ce4(u"࠱࠰࠴࠴࠵ᗽ"))
	if k1t0JLRsCQ.path.exists(image_filename):
		try: k1t0JLRsCQ.remove(image_filename)
		except: pass
	return
def r57bsFUQ9l83v4tq(*aargs,**kkwargs):
	rD8sEn7jzheBQqfH,TwPt5qAHlrOsQ,profile,direction = KKbpxUZnMcj6AJ4QdD(u"࠭ࠧယ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠧࠨရ"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩလ"),yF29Xdsx35wI07Ce4(u"ࠩ࡯ࡩ࡫ࡺࠧဝ")
	if len(aargs)>=bcgZJWV6UeNSkRA(u"࠳ᗾ"): rD8sEn7jzheBQqfH = aargs[n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠳ᗿ")]
	if len(aargs)>=CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠷ᘁ"): TwPt5qAHlrOsQ = aargs[bcgZJWV6UeNSkRA(u"࠵ᘀ")]
	if len(aargs)>=xuztI5QWEKG70CPNdhk4vo6(u"࠹ᘂ"): profile = aargs[iifPEY9ABNzTQp(u"࠲ᘃ")]
	if len(aargs)>=pcWq35MED2dtK(u"࠶ᘅ"): direction = aargs[shZ9eOcN2dJnPj(u"࠴ᘄ")]
	return RZo7IGjqXfiAnrWtlHcbNDuF9hP(direction,rD8sEn7jzheBQqfH,TwPt5qAHlrOsQ,profile)
def oSmbjV25zMhflkrs8W9K(*aargs,**kkwargs):
	return XuWPVcQ13oDq5swf0S.Dialog().contextmenu(*aargs,**kkwargs)
def AAPgLr9vUYZSRQMKJV(*aargs,**kkwargs):
	return XuWPVcQ13oDq5swf0S.Dialog().browseSingle(*aargs,**kkwargs)
def vKl0w97S4DkyqaGmeFsUARoErLOgP(*aargs,**kkwargs):
	return XuWPVcQ13oDq5swf0S.Dialog().input(*aargs,**kkwargs)
def zzLBYaEcM1jlKqX5FyONiRJ(*aargs,**kkwargs):
	return XuWPVcQ13oDq5swf0S.DialogProgress(*aargs,**kkwargs)
def vvZxzV4CkyoPTs(mPbjOek1iChtn6p0DqV9cxS):
	if njGgmsD1k7cE60drxHCyVh2YN3P>yF29Xdsx35wI07Ce4(u"࠴࠻࠳࠿࠹ᘆ"): PoLaNz8hdcUIrFgv = M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠪࡦࡺࡹࡹࡥ࡫ࡤࡰࡴ࡭࡮ࡰࡥࡤࡲࡨ࡫࡬ࠨသ")
	else: PoLaNz8hdcUIrFgv = XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠫࡧࡻࡳࡺࡦ࡬ࡥࡱࡵࡧࠨဟ")
	mPbjOek1iChtn6p0DqV9cxS = mPbjOek1iChtn6p0DqV9cxS.lower()
	if mPbjOek1iChtn6p0DqV9cxS==OyJ1o4AvmWlB75UkFRX(u"ࠬࡹࡴࡢࡴࡷࠫဠ"): bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(InKG0i2r6hHDvgd(u"࠭ࡁࡤࡶ࡬ࡺࡦࡺࡥࡘ࡫ࡱࡨࡴࡽࠨࠨအ")+PoLaNz8hdcUIrFgv+JLoPRXt93dpAB(u"ࠧࠪࠩဢ"))
	elif mPbjOek1iChtn6p0DqV9cxS==ggDRehOModi(u"ࠨࡵࡷࡳࡵ࠭ဣ"): bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(bcgZJWV6UeNSkRA(u"ࠩࡇ࡭ࡦࡲ࡯ࡨ࠰ࡆࡰࡴࡹࡥࠩࠩဤ")+PoLaNz8hdcUIrFgv+vvBChXmSty(u"ࠪ࠭ࠬဥ"))
	return
def lRwnVNxCZXGgkqd390(direction,button0=pcWq35MED2dtK(u"ࠫࠬဦ"),button1=n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠬ࠭ဧ"),button2=qnPgZ9N15G6Oa8UpMASvLk(u"࠭ࠧဨ"),rD8sEn7jzheBQqfH=PtXn0k9G3ocHRg(u"ࠧࠨဩ"),TwPt5qAHlrOsQ=JLoPRXt93dpAB(u"ࠨࠩဪ"),profile=yruHDQOcB97ig(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫါ"),f8CmHjFLeWDvnO=bcgZJWV6UeNSkRA(u"࠴ᘇ"),VBawdptfiT3UIG9H1NbYkCojmzXvrn=bcgZJWV6UeNSkRA(u"࠴ᘇ")):
	if not direction: direction = shZ9eOcN2dJnPj(u"ࠪࡧࡪࡴࡴࡦࡴࠪာ")
	PoLaNz8hdcUIrFgv = vkDgHOlZEhR8TJG4A(yF29Xdsx35wI07Ce4(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡇࡴࡴࡦࡪࡴࡰࡘ࡭ࡸࡥࡦࡄࡸࡸࡹࡵ࡮ࡴ࠰ࡻࡱࡱ࠭ိ"),b69iT7LWwrfXzGYPMvBCsteVHDQK,Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭ီ"),ggDRehOModi(u"࠭࠷࠳࠲ࡳࠫု"))
	PoLaNz8hdcUIrFgv.sLJfQm8Zgp5WxOo7FKHRYlqt1(button0,button1,button2,rD8sEn7jzheBQqfH,TwPt5qAHlrOsQ,profile,direction,f8CmHjFLeWDvnO,VBawdptfiT3UIG9H1NbYkCojmzXvrn)
	if f8CmHjFLeWDvnO>cNaVb1vsT4qWOL0rpE(u"࠵ᘈ"): PoLaNz8hdcUIrFgv.KevQcPqyEp0ITOo2mV6()
	if VBawdptfiT3UIG9H1NbYkCojmzXvrn>Tgoa16jMxvYX2(u"࠶ᘉ"): PoLaNz8hdcUIrFgv.yXRLJVDAWUGrCZ9a3()
	if f8CmHjFLeWDvnO==wwplD0tEehqH3kYQXs(u"࠰ᘊ") and VBawdptfiT3UIG9H1NbYkCojmzXvrn==wwplD0tEehqH3kYQXs(u"࠰ᘊ"): PoLaNz8hdcUIrFgv.MQsITquyAlLcf5xw43gpYan1()
	PoLaNz8hdcUIrFgv.doModal()
	OdN8EyB3LDqfoJCg = PoLaNz8hdcUIrFgv.choiceID
	return OdN8EyB3LDqfoJCg
def RZo7IGjqXfiAnrWtlHcbNDuF9hP(direction,rD8sEn7jzheBQqfH,TwPt5qAHlrOsQ,profile=yruHDQOcB97ig(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨူ")):
	if not direction: direction = ggDRehOModi(u"ࠨ࡮ࡨࡪࡹ࠭ေ")
	PoLaNz8hdcUIrFgv = qZzjySC63LWVAovla2TIUfpF9uxg0i(M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡖࡨࡼࡹ࡜ࡩࡦࡹࡨࡶࡋࡻ࡬࡭ࡕࡦࡶࡪ࡫࡮࠯ࡺࡰࡰࠬဲ"),b69iT7LWwrfXzGYPMvBCsteVHDQK,oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫဳ"),PtXn0k9G3ocHRg(u"ࠫ࠼࠸࠰ࡱࠩဴ"))
	image_filename = Wgy3rdVP0HqnsA2N59FfbITu6Bh.replace(KKbpxUZnMcj6AJ4QdD(u"ࠬࡥ࠰࠱࠲࠳ࡣࠬဵ"),PtXn0k9G3ocHRg(u"࠭࡟ࠨံ")+str(YVJPFvuI2CS5KObiZt.time())+iifPEY9ABNzTQp(u"ࠧࡠ့ࠩ"))
	image_filename = image_filename.replace(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠨ࡞࡟ࠫး"),yF29Xdsx35wI07Ce4(u"ࠩ࡟ࡠࡡࡢ္ࠧ")).replace(M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠪ࠳࠴်࠭"),bcgZJWV6UeNSkRA(u"ࠫ࠴࠵࠯࠰ࠩျ"))
	image_height = WedGKhM8a0(oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠬ࠭ြ"),tZ3gsrTEdzA1S6LXa9WI5px(u"࠭ࠧွ"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠧࠨှ"),rD8sEn7jzheBQqfH,TwPt5qAHlrOsQ,profile,direction,bcgZJWV6UeNSkRA(u"ࡇࡣ࡯ࡷࡪᜪ"),image_filename)
	PoLaNz8hdcUIrFgv.show()
	PoLaNz8hdcUIrFgv.getControl(M6PIj8gl1fno7wcqTksDEBK4bU(u"࠺࠲࠸࠴ᘋ")).setHeight(image_height)
	PoLaNz8hdcUIrFgv.getControl(shZ9eOcN2dJnPj(u"࠻࠳࠹࠵ᘌ")).setImage(image_filename)
	Pyk9zObnlCBGiM6mUo = PoLaNz8hdcUIrFgv.doModal()
	try: k1t0JLRsCQ.remove(image_filename)
	except: pass
	return Pyk9zObnlCBGiM6mUo
def ncgQBtRa7qT2GJ3Wpd(t9eILVgsfScCrq4=M6PIj8gl1fno7wcqTksDEBK4bU(u"ࡖࡵࡹࡪᜫ")):
	if t9eILVgsfScCrq4:
		UUSPoh1ckMtVexN6u = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,JLoPRXt93dpAB(u"ࠨࡵࡷࡶࠬဿ"),bcgZJWV6UeNSkRA(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ၀"),tZ3gsrTEdzA1S6LXa9WI5px(u"࡙ࠪࡘࡋࡒࡂࡉࡈࡒ࡙࠭၁"))
		if UUSPoh1ckMtVexN6u: return UUSPoh1ckMtVexN6u
	TwPt5qAHlrOsQ = ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠫࠬ၂")
	if iifPEY9ABNzTQp(u"࠳ᘍ") and l3lOuS56hyIdjACkcweb1WDrHQgYfa.succeeded:
		DMqcCpg8GmefYtWJZITSP29x3nLzO = l3lOuS56hyIdjACkcweb1WDrHQgYfa.content
		tDlfOHiebr0MUx765c = DMqcCpg8GmefYtWJZITSP29x3nLzO.count(shZ9eOcN2dJnPj(u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠭၃"))
		if tDlfOHiebr0MUx765c>yruHDQOcB97ig(u"࠼࠵ᘎ"):
			TwPt5qAHlrOsQ = u5h2Rckvw1E.findall(wwplD0tEehqH3kYQXs(u"࠭ࡧࡦࡶ࠰ࡸ࡭࡫࠭࡭࡫ࡶࡸ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ၄"),DMqcCpg8GmefYtWJZITSP29x3nLzO,u5h2Rckvw1E.DOTALL)
			TwPt5qAHlrOsQ = TwPt5qAHlrOsQ[usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠵ᘏ")]
	if not TwPt5qAHlrOsQ:
		qWoIA0Z4DMXCQjgw5P = k1t0JLRsCQ.path.join(b69iT7LWwrfXzGYPMvBCsteVHDQK,r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭၅"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠨࡷࡶࡩࡷࡧࡧࡦࡰࡷࡷ࠳ࡺࡸࡵࠩ၆"))
		TwPt5qAHlrOsQ = open(qWoIA0Z4DMXCQjgw5P,nKLEi8CJumazx4qT(u"ࠩࡵࡦࠬ၇")).read()
		if VVGRN7xiyj: TwPt5qAHlrOsQ = TwPt5qAHlrOsQ.decode(wwplD0tEehqH3kYQXs(u"ࠪࡹࡹ࡬࠸ࠨ၈"))
		TwPt5qAHlrOsQ = TwPt5qAHlrOsQ.replace(iifPEY9ABNzTQp(u"ࠫࡡࡸࠧ၉"),iifPEY9ABNzTQp(u"ࠬ࠭၊"))
	o2G7i59ARtec3TgmkyfnvPbCYp = u5h2Rckvw1E.findall(oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠭ࠨࡎࡱࡽ࡭ࡱࡲࡡ࠯ࠬࡂ࠭ࡡࡴࠧ။"),TwPt5qAHlrOsQ,u5h2Rckvw1E.DOTALL)
	TEbtURL5yirY = []
	for ZaVCxBWH36wEyto4jnusNL1gTmJ0 in o2G7i59ARtec3TgmkyfnvPbCYp:
		wnu0fos8HB = ZaVCxBWH36wEyto4jnusNL1gTmJ0.lower()
		if yF29Xdsx35wI07Ce4(u"ࠧࡢࡰࡧࡶࡴ࡯ࡤࠨ၌") in wnu0fos8HB: continue
		if cNaVb1vsT4qWOL0rpE(u"ࠨࡷࡥࡹࡳࡺࡵࠨ၍") in wnu0fos8HB: continue
		if vvBChXmSty(u"ࠩ࡬ࡴ࡭ࡵ࡮ࡦࠩ၎") in wnu0fos8HB: continue
		if bcgZJWV6UeNSkRA(u"ࠪࡧࡷࡵࡳࠨ၏") in wnu0fos8HB: continue
		TEbtURL5yirY.append(ZaVCxBWH36wEyto4jnusNL1gTmJ0)
	UUSPoh1ckMtVexN6u = jjyW6FTEOn3sSMo1G5LxBiA.sample(TEbtURL5yirY,pcWq35MED2dtK(u"࠷ᘐ"))
	UUSPoh1ckMtVexN6u = UUSPoh1ckMtVexN6u[ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠰ᘑ")]
	OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,xuztI5QWEKG70CPNdhk4vo6(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧၐ"),bcgZJWV6UeNSkRA(u"࡛ࠬࡓࡆࡔࡄࡋࡊࡔࡔࠨၑ"),UUSPoh1ckMtVexN6u,QQJtZ6rMvS1wdDsHnahT7)
	return UUSPoh1ckMtVexN6u
def OEZ5f7K4jQpUJDnFaHNCdhPc(LdvB61qxSDsOWlhmXnAgozEfPp4Ky=PtXn0k9G3ocHRg(u"࠭ࠧၒ")):
	if not LdvB61qxSDsOWlhmXnAgozEfPp4Ky: LdvB61qxSDsOWlhmXnAgozEfPp4Ky = BPSEU6WvQRnxV.format_exc()
	if LdvB61qxSDsOWlhmXnAgozEfPp4Ky!=pcWq35MED2dtK(u"ࠧࡏࡱࡱࡩ࡙ࡿࡰࡦ࠼ࠣࡒࡴࡴࡥ࡝ࡰࠪၓ"): vdo2FnhPmAVRMJQZ0EIG8.stderr.write(LdvB61qxSDsOWlhmXnAgozEfPp4Ky)
	dvulfaW1UAFZ2JSrPxOYyeMHqn = LdvB61qxSDsOWlhmXnAgozEfPp4Ky.splitlines()
	lHqTf6UMy5pvbe0nK = dvulfaW1UAFZ2JSrPxOYyeMHqn[-PtXn0k9G3ocHRg(u"࠲ᘒ")]
	q2q57bg4RDF3LGcwItdChTa = open(T1guYOxGi3ClA0d2s7kZf4J5b,cNaVb1vsT4qWOL0rpE(u"ࠨࡴࡥࠫၔ")).read()
	if VVGRN7xiyj: q2q57bg4RDF3LGcwItdChTa = q2q57bg4RDF3LGcwItdChTa.decode(vvBChXmSty(u"ࠩࡸࡸ࡫࠾ࠧၕ"))
	q2q57bg4RDF3LGcwItdChTa = q2q57bg4RDF3LGcwItdChTa[-pcWq35MED2dtK(u"࠺࠳࠴࠵ᘓ"):]
	nngdtHAZwB5o = KKbpxUZnMcj6AJ4QdD(u"ࠪࡁࠬၖ")*pcWq35MED2dtK(u"࠴࠴࠵ᘔ")
	if nngdtHAZwB5o in q2q57bg4RDF3LGcwItdChTa: q2q57bg4RDF3LGcwItdChTa = q2q57bg4RDF3LGcwItdChTa.rsplit(nngdtHAZwB5o,qnPgZ9N15G6Oa8UpMASvLk(u"࠵ᘕ"))[qnPgZ9N15G6Oa8UpMASvLk(u"࠵ᘕ")]
	if lHqTf6UMy5pvbe0nK in q2q57bg4RDF3LGcwItdChTa: q2q57bg4RDF3LGcwItdChTa = q2q57bg4RDF3LGcwItdChTa.rsplit(lHqTf6UMy5pvbe0nK,Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠶ᘖ"))[wwplD0tEehqH3kYQXs(u"࠶ᘗ")]
	ZRt1hdJLAcr = u5h2Rckvw1E.findall(drHLAY5ENQFe2q9ptKGabo(u"࡙ࠫ࠭࡯ࡶࡴࡦࡩࢁࡓ࡯ࡥࡧࠬ࠾ࠥࡢ࡛ࠡࠪ࠱࠮ࡄ࠯ࠠ࡝࡟ࠪၗ"),q2q57bg4RDF3LGcwItdChTa,u5h2Rckvw1E.DOTALL)
	for LL9QUIctRHqaNEP0b,BYGZC29KJ5Piag36Dl in reversed(ZRt1hdJLAcr):
		if BYGZC29KJ5Piag36Dl: break
	else: BYGZC29KJ5Piag36Dl = CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠬࡔࡏࡕࠢࡖࡔࡊࡉࡉࡇࡋࡈࡈࠬၘ")
	lqTODkKeBU3zhrPXwxa57idC8,ZaVCxBWH36wEyto4jnusNL1gTmJ0,zE2sXM7W31tB8UJk9Q = Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠭ࠧၙ"),nKLEi8CJumazx4qT(u"ࠧࠨၚ"),vvBChXmSty(u"ࠨࠩၛ")
	acx45dJY8IEsvzO0yXb = cNaVb1vsT4qWOL0rpE(u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่ำ฽ร࠻ࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬၜ")+lHqTf6UMy5pvbe0nK
	GLlgdCvO48Y = BGhdkWsEvJjiMFTr3NLn1flU(u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้๋ีะำ࠽ࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧၝ")+BYGZC29KJ5Piag36Dl
	for fkiqyesZhSovHbzMl3RL46 in reversed(dvulfaW1UAFZ2JSrPxOYyeMHqn):
		if qnPgZ9N15G6Oa8UpMASvLk(u"ࠫࡋ࡯࡬ࡦࠢࠥࠫၞ") in fkiqyesZhSovHbzMl3RL46 and bbw2eajMlG(u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫၟ") in fkiqyesZhSovHbzMl3RL46: break
	fkiqyesZhSovHbzMl3RL46 = u5h2Rckvw1E.findall(shZ9eOcN2dJnPj(u"࠭ࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࠬࠦࡡ࠲ࠠ࡭࡫ࡱࡩࠥ࠮࠮ࠫࡁࠬࡠ࠱ࠦࡩ࡯ࠢࠫ࠲࠯ࡅࠩࠥࠩၠ"),fkiqyesZhSovHbzMl3RL46,u5h2Rckvw1E.DOTALL)
	if fkiqyesZhSovHbzMl3RL46:
		lqTODkKeBU3zhrPXwxa57idC8,ZaVCxBWH36wEyto4jnusNL1gTmJ0,zE2sXM7W31tB8UJk9Q = fkiqyesZhSovHbzMl3RL46[yF29Xdsx35wI07Ce4(u"࠰ᘘ")]
		if drHLAY5ENQFe2q9ptKGabo(u"ࠧ࠰ࠩၡ") in lqTODkKeBU3zhrPXwxa57idC8: lqTODkKeBU3zhrPXwxa57idC8 = lqTODkKeBU3zhrPXwxa57idC8.rsplit(nKLEi8CJumazx4qT(u"ࠨ࠱ࠪၢ"),cgtRBdXxSOk7WUfyDhPCls(u"࠲ᘙ"))[cgtRBdXxSOk7WUfyDhPCls(u"࠲ᘙ")]
		else: lqTODkKeBU3zhrPXwxa57idC8 = lqTODkKeBU3zhrPXwxa57idC8.rsplit(bcgZJWV6UeNSkRA(u"ࠩ࡟ࡠࠬၣ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"࠳ᘚ"))[M6PIj8gl1fno7wcqTksDEBK4bU(u"࠳ᘚ")]
		QWD9I8Lifwy5puorGYcbSRvFz3ahBk = oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้๋ไโ࠼ࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ၤ")+lqTODkKeBU3zhrPXwxa57idC8
		AmUprLgMj1fc4OhF7eoIwt = Tgoa16jMxvYX2(u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ำุำ࠽ࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧၥ")+ZaVCxBWH36wEyto4jnusNL1gTmJ0
		CZMiesf4dWPVD6NBSa = usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไๆๅส๊࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩၦ")+zE2sXM7W31tB8UJk9Q
		OOsK8SuZHa7EcW6Y2Ao5IpwLClmU = QWD9I8Lifwy5puorGYcbSRvFz3ahBk+cgtRBdXxSOk7WUfyDhPCls(u"࠭࡜࡯ࠩၧ")+AmUprLgMj1fc4OhF7eoIwt+oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠧ࡝ࡰࠪၨ")+CZMiesf4dWPVD6NBSa+pcWq35MED2dtK(u"ࠨ࡞ࡱࠫၩ")+GLlgdCvO48Y+PtXn0k9G3ocHRg(u"ࠩ࡟ࡲࠬၪ")+acx45dJY8IEsvzO0yXb
		XfCThMjVcNKHgUiGO = AmUprLgMj1fc4OhF7eoIwt+KKbpxUZnMcj6AJ4QdD(u"ࠪࡠࡳ࠭ၫ")+GLlgdCvO48Y+M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠫࡡࡴࠧၬ")+acx45dJY8IEsvzO0yXb+KKbpxUZnMcj6AJ4QdD(u"ࠬࡢ࡮ࠨၭ")+QWD9I8Lifwy5puorGYcbSRvFz3ahBk+vvBChXmSty(u"࠭࡜࡯ࠩၮ")+CZMiesf4dWPVD6NBSa
		f76lP9xkyeA3 = AmUprLgMj1fc4OhF7eoIwt+nKLEi8CJumazx4qT(u"ࠧ࡝ࡰࠪၯ")+acx45dJY8IEsvzO0yXb+XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠨ࡞ࡱࠫၰ")+QWD9I8Lifwy5puorGYcbSRvFz3ahBk+Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠩ࡟ࡲࠬၱ")+CZMiesf4dWPVD6NBSa
	else:
		QWD9I8Lifwy5puorGYcbSRvFz3ahBk,AmUprLgMj1fc4OhF7eoIwt,CZMiesf4dWPVD6NBSa = ggDRehOModi(u"ࠪࠫၲ"),yruHDQOcB97ig(u"ࠫࠬၳ"),vvBChXmSty(u"ࠬ࠭ၴ")
		OOsK8SuZHa7EcW6Y2Ao5IpwLClmU = GLlgdCvO48Y+Tgoa16jMxvYX2(u"࠭࡜࡯࡞ࡱࠫၵ")+acx45dJY8IEsvzO0yXb
		XfCThMjVcNKHgUiGO = GLlgdCvO48Y+r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠧ࡝ࡰ࡟ࡲࠬၶ")+acx45dJY8IEsvzO0yXb
		f76lP9xkyeA3 = acx45dJY8IEsvzO0yXb
	gZT0dpMJmfshiIHxAbaoYEq3XeNyO8 = ggDRehOModi(u"ࠨฯาฯࠥิืฤࠢ฽๎ึࠦๅใื๋ำࠬၷ")+drHLAY5ENQFe2q9ptKGabo(u"ࠩ࡟ࡲࠬၸ")
	CxYkviDPANObF0LsMdJ = WY4NwzXs3TEgUJMK1hFaQbCxtn0iS()
	Tm4DwWKRYtXyqb = []
	vS7JufTVsBxw52 = CxYkviDPANObF0LsMdJ[oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨၹ")]
	mvye8AjLC2wpZn1UYt = jMVWv8Hnk5Z6Ibhz2uYQomafJrg(qkSQU3saP0D7OvynNzH4F2BKJuilT)
	if usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩၺ") in list(CxYkviDPANObF0LsMdJ.keys()):
		for qsweAy3DUxWL,cSiFP8fb3krIz6XBL,R6RYNyl31xWtgfKaHFG4j5 in vS7JufTVsBxw52: Tm4DwWKRYtXyqb = max(Tm4DwWKRYtXyqb,cSiFP8fb3krIz6XBL)
		if mvye8AjLC2wpZn1UYt<Tm4DwWKRYtXyqb:
			rD8sEn7jzheBQqfH = iifPEY9ABNzTQp(u"่ࠬๅࠡสอัิ๐หࠡษ็ฬึ์วๆฮࠣๆอ๊ࠠฦำึห้ࠦวๅลั฻ฬวࠠๅๆ่ฬึ๋ฬࠨၻ")
			OdN8EyB3LDqfoJCg = lRwnVNxCZXGgkqd390(r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠭ࡲࡪࡩ࡫ࡸࠬၼ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧฦำึห้ࠦลๅ๋ࠣห้๋ศา็ฯࠫၽ"),KKbpxUZnMcj6AJ4QdD(u"ࠨฬะำ๏ัࠧၾ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠩัีําࠧၿ"),gZT0dpMJmfshiIHxAbaoYEq3XeNyO8+rD8sEn7jzheBQqfH,OOsK8SuZHa7EcW6Y2Ao5IpwLClmU)
			if OdN8EyB3LDqfoJCg==Tgoa16jMxvYX2(u"࠳ᘛ"):
				iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠪࡧࡪࡴࡴࡦࡴࠪႀ"),xuztI5QWEKG70CPNdhk4vo6(u"ࠫำื่อࠩႁ"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࠬะอะ์ฮࠫႂ"),cNaVb1vsT4qWOL0rpE(u"࠭ࠧႃ"),rD8sEn7jzheBQqfH)
				if iZL6cN3OkM5==tZ3gsrTEdzA1S6LXa9WI5px(u"࠵ᘜ"): OdN8EyB3LDqfoJCg = tZ3gsrTEdzA1S6LXa9WI5px(u"࠵ᘜ")
			if OdN8EyB3LDqfoJCg==vvBChXmSty(u"࠶ᘝ"):
				import y5yjS2UFkc
				y5yjS2UFkc.NZ0pBCdgQs(oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࡗࡶࡺ࡫ᜬ"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࡗࡶࡺ࡫ᜬ"))
			return
	n3j82BoXeb = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,vvBChXmSty(u"ࠧ࡭࡫ࡶࡸࠬႄ"),KKbpxUZnMcj6AJ4QdD(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫႅ"),vvBChXmSty(u"ࠩࡄࡐࡑࡥࡓࡆࡐࡗࡣࡊࡘࡒࡐࡔࡖࠫႆ"))
	if not n3j82BoXeb: n3j82BoXeb = []
	XfCThMjVcNKHgUiGO = XfCThMjVcNKHgUiGO.replace(shZ9eOcN2dJnPj(u"ࠪࡠࡳ࠭ႇ"),Tgoa16jMxvYX2(u"ࠫࡡࡢ࡮ࠨႈ")).replace(bcgZJWV6UeNSkRA(u"ࠬࡡࡒࡕࡎࡠࠫႉ"),cgtRBdXxSOk7WUfyDhPCls(u"࠭ࠧႊ")).replace(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪႋ"),Tgoa16jMxvYX2(u"ࠨࠩႌ")).replace(shZ9eOcN2dJnPj(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠႍࠫ"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠪࠫႎ"))
	f76lP9xkyeA3 = f76lP9xkyeA3.replace(yruHDQOcB97ig(u"ࠫࡡࡴࠧႏ"),JLoPRXt93dpAB(u"ࠬࡢ࡜࡯ࠩ႐")).replace(cgtRBdXxSOk7WUfyDhPCls(u"࡛࠭ࡓࡖࡏࡡࠬ႑"),Tgoa16jMxvYX2(u"ࠧࠨ႒")).replace(KKbpxUZnMcj6AJ4QdD(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ႓"),KKbpxUZnMcj6AJ4QdD(u"ࠩࠪ႔")).replace(nKLEi8CJumazx4qT(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ႕"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠫࠬ႖"))
	gRUVlhFNjBIO = qkSQU3saP0D7OvynNzH4F2BKJuilT+yF29Xdsx35wI07Ce4(u"ࠬࡀ࠺ࠨ႗")+f76lP9xkyeA3
	if gRUVlhFNjBIO in n3j82BoXeb:
		rD8sEn7jzheBQqfH = JLoPRXt93dpAB(u"࠭ไใัࠣๆ๊ะࠠศ่อࠤุอศใษࠣฬสืำศๆ๋ࠣีอࠠศๆั฻ศࠦลๅ๋ࠣห้๋ศา็ฯࠫ႘")
		xl9MFt1AmY0GrkENug8n(qnPgZ9N15G6Oa8UpMASvLk(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭႙"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠨࠩႚ"),gZT0dpMJmfshiIHxAbaoYEq3XeNyO8+rD8sEn7jzheBQqfH,OOsK8SuZHa7EcW6Y2Ao5IpwLClmU)
		return
	FwBkHKzhGMy = str(njGgmsD1k7cE60drxHCyVh2YN3P).split(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠩ࠱ࠫႛ"))[PtXn0k9G3ocHRg(u"࠶ᘞ")]
	GMfo7WypIsRin9HKEZQduYhDetFJOS = pgPfwZleTHVQ9a[wwplD0tEehqH3kYQXs(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪႜ")][vvBChXmSty(u"࠶ᘟ")]
	l3lOuS56hyIdjACkcweb1WDrHQgYfa = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠫࡕࡕࡓࡕࠩႝ"),GMfo7WypIsRin9HKEZQduYhDetFJOS,JLoPRXt93dpAB(u"ࠬ࠭႞"),nKLEi8CJumazx4qT(u"࠭ࠧ႟"),ggDRehOModi(u"ࠧࠨႠ"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠨࠩႡ"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡍࡕࡗࡠࡇ࡛ࡍ࡙ࡥࡅࡓࡔࡒࡖࡘ࠳࠱ࡴࡶࠪႢ"),yF29Xdsx35wI07Ce4(u"ࡊࡦࡲࡳࡦᜭ"),yF29Xdsx35wI07Ce4(u"ࡊࡦࡲࡳࡦᜭ"))
	DMqcCpg8GmefYtWJZITSP29x3nLzO = l3lOuS56hyIdjACkcweb1WDrHQgYfa.content
	NIFBGHfQl3SsaZkhdim0coKPEbe = u5h2Rckvw1E.findall(yruHDQOcB97ig(u"ࠪࡗ࡙ࡇࡒࡕ࠼࠽ࡗ࡙ࡇࡒࡕ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬࡇࡑࡈ࠿ࡀࡅࡏࡆࠪႣ"),DMqcCpg8GmefYtWJZITSP29x3nLzO,u5h2Rckvw1E.DOTALL)
	for Z2cxNn6DSK3ClewW,EVJ5MwjPrLhCDT,x6hfzIebtE1gJWnMDo5LCUHjkB3r7,mXcDwB9IueiNQ3UYfjx in NIFBGHfQl3SsaZkhdim0coKPEbe:
		Z2cxNn6DSK3ClewW = Z2cxNn6DSK3ClewW.split(r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠫ࠰࠭Ⴄ"))
		x6hfzIebtE1gJWnMDo5LCUHjkB3r7 = x6hfzIebtE1gJWnMDo5LCUHjkB3r7.split(Tgoa16jMxvYX2(u"ࠬ࠱ࠧႥ"))
		mXcDwB9IueiNQ3UYfjx = mXcDwB9IueiNQ3UYfjx.split(yF29Xdsx35wI07Ce4(u"࠭ࠫࠨႦ"))
		if ZaVCxBWH36wEyto4jnusNL1gTmJ0 in Z2cxNn6DSK3ClewW and lHqTf6UMy5pvbe0nK==EVJ5MwjPrLhCDT and qkSQU3saP0D7OvynNzH4F2BKJuilT in x6hfzIebtE1gJWnMDo5LCUHjkB3r7 and FwBkHKzhGMy in mXcDwB9IueiNQ3UYfjx:
			rD8sEn7jzheBQqfH = yF29Xdsx35wI07Ce4(u"่ࠧาสࠤฬ๊ฮุล้ࠣ฾ื่โ๋ࠢื๏฿วๅฮࠣฬฬ๊ลึัสีࠥอไใษา้ࠬႧ")
			iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(InKG0i2r6hHDvgd(u"ࠨࡴ࡬࡫࡭ࡺࠧႨ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠩัีําࠧႩ"),shZ9eOcN2dJnPj(u"ࠪษึูวๅࠢศ่๎ࠦวๅ็หี๊าࠧႪ"),gZT0dpMJmfshiIHxAbaoYEq3XeNyO8+rD8sEn7jzheBQqfH,OOsK8SuZHa7EcW6Y2Ao5IpwLClmU)
			if iZL6cN3OkM5==qnPgZ9N15G6Oa8UpMASvLk(u"࠲ᘠ"): xl9MFt1AmY0GrkENug8n(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫႫ"),cNaVb1vsT4qWOL0rpE(u"ࠬ࠭Ⴌ"),iifPEY9ABNzTQp(u"࠭ࠧႭ"),rD8sEn7jzheBQqfH)
			return
	rD8sEn7jzheBQqfH = Tgoa16jMxvYX2(u"ࠧศๆิะฬวࠠฦำึห้ࠦ็ัษࠣห้ิืฤࠢศ่๎ࠦวๅ็หี๊าࠧႮ")
	xl9MFt1AmY0GrkENug8n(drHLAY5ENQFe2q9ptKGabo(u"ࠨࡴ࡬࡫࡭ࡺࠧႯ"),drHLAY5ENQFe2q9ptKGabo(u"ࠩศีุอไࠡว็ํࠥอไๆสิ้ั࠭Ⴐ"),gZT0dpMJmfshiIHxAbaoYEq3XeNyO8+rD8sEn7jzheBQqfH,OOsK8SuZHa7EcW6Y2Ao5IpwLClmU)
	iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(nKLEi8CJumazx4qT(u"ࠪࡧࡪࡴࡴࡦࡴࠪႱ"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠫࠬႲ"),JLoPRXt93dpAB(u"ࠬ࠭Ⴓ"),pcWq35MED2dtK(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩႴ"),yF29Xdsx35wI07Ce4(u"ࠧิ๊ไࠤ๏ะๅࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢศ่๎ࠦวๅ็หี๊าࠠๅๅํࠤ๏฿ัโࠢส่๊ฮัๆฮࠣว๏์้ࠠ็อํࠥ๎ใ๋ใࠣ์้๋วัษࠣัฺ๊ส้ࠡำ๋ࠥอไๆึๆ่ฮࠦไฤ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠤํ๊วࠡ์ึฮ฼๐ูࠡษุ่ฬำࠠๆึๆ่ฮ่่๊่ࠦࠣฬฺ๊ࠦำไࠤ่๐แฺ๊ࠡีฯ่ࠦๅ็สิฬุ่ࠦำอࠤํ๋ส๊ࠢ฻๋ึะ่ࠠา๊ࠤฬ๊ๅีๅ็อࠥ࠴่ࠠๆࠣฮึ๐ฯࠡลิืฬ๊ࠠศๆึะ้ࠦฟࠨႵ"))
	if iZL6cN3OkM5==ggDRehOModi(u"࠳ᘡ"): LLvAUFN4fXhlZ = bbw2eajMlG(u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࠫႶ")
	else:
		xl9MFt1AmY0GrkENug8n(ggDRehOModi(u"ࠩࡦࡩࡳࡺࡥࡳࠩႷ"),wwplD0tEehqH3kYQXs(u"ࠪࠫႸ"),drHLAY5ENQFe2q9ptKGabo(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧႹ"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ห็ࠣษ้เวยࠢศีุอไࠡษ็า฼ษ࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ็ว๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮ้ࠠๆสࠤ๏ูสุ์฼ࠤส฻ไศฯࠣห้ิืฤࠢหำํ์ࠠิฮ็ࠤฬ๊รฯูสลࠥอไั์้่ࠣะ่ษࠢไ๎์ࠦฬๆ์฼ࠤฯ็วึ์็ࠤ์ึวࠡษ็า฼ษ้ࠠ฼ํี์ࠦๅ็ࠢส่ศิืศรࠪႺ"))
		return
	CWL8J3MFDRmtk029PKhsp6Zgbv = XfCThMjVcNKHgUiGO
	from y5yjS2UFkc import X2XWUFPVMDugaGkehc4EYlp
	V5VXz0j3oa6t = X2XWUFPVMDugaGkehc4EYlp(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠭ࡅࡳࡴࡲࡶࡸ࠭Ⴛ"),CWL8J3MFDRmtk029PKhsp6Zgbv,oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࡙ࡸࡵࡦᜮ"),nKLEi8CJumazx4qT(u"ࠧࠨႼ"),bbw2eajMlG(u"ࠨࡇࡐࡅࡎࡒ࠭ࡇࡔࡒࡑ࠲࡙ࡈࡐ࡙ࡢࡉ࡝ࡏࡔࡠࡇࡕࡖࡔࡘࡓࠨႽ"),LLvAUFN4fXhlZ)
	if V5VXz0j3oa6t and LLvAUFN4fXhlZ:
		n3j82BoXeb.append(gRUVlhFNjBIO)
		OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬႾ"),JLoPRXt93dpAB(u"ࠪࡅࡑࡒ࡟ࡔࡇࡑࡘࡤࡋࡒࡓࡑࡕࡗࠬႿ"),n3j82BoXeb,NVbfv48oh3M6U)
	return
def CNdraDU2kzKsmg74WOcV1j(MNWrTo98GZHn):
	if VVGRN7xiyj: MNWrTo98GZHn = MNWrTo98GZHn.encode(iifPEY9ABNzTQp(u"ࠫࡺࡺࡦ࠹ࠩჀ"))
	i60vZtVrPYoD = iifPEY9ABNzTQp(u"ࠬࡹ࠺࡝࡞࠳࠴࠵࠶ࡥ࡮ࡣࡧࡣࠬჁ")+str(YVJPFvuI2CS5KObiZt.time())+ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠭࠮ࡥࡣࡷࠫჂ")
	open(i60vZtVrPYoD,M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠧࡸࡤࠪჃ")).write(MNWrTo98GZHn)
	return
def J4W2ubDzKxd7hUsQTZOl1Gn(EqVPHSM8fKuTaxh20WkNLd):
	if EqVPHSM8fKuTaxh20WkNLd:
		ebSw1pNJXjWAHQFlUKY = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠨ࡮࡬ࡷࡹ࠭Ⴤ"),ggDRehOModi(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬჅ"),JLoPRXt93dpAB(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭჆"))
		if ebSw1pNJXjWAHQFlUKY: return ebSw1pNJXjWAHQFlUKY
	GMfo7WypIsRin9HKEZQduYhDetFJOS = pgPfwZleTHVQ9a[drHLAY5ENQFe2q9ptKGabo(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫჇ")][ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠸ᘢ")]
	hGdKt2jR8SN1z5TrZkuU = lbFixEt3BK9YGMyWIQZuSsp1V7JTL8(OyJ1o4AvmWlB75UkFRX(u"࠷࠷ᘣ"),EqVPHSM8fKuTaxh20WkNLd)
	OOjM98q7XuSQl = COnauLbjTwX31YoPgxNlcJ()
	Hqe1swvhCVTM2jYWKya0xSAUnbp = OOjM98q7XuSQl.split(bbw2eajMlG(u"ࠬ࠲ࠧ჈"))[Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠷ᘤ")]
	AuIMdgopB61q5C = k1t0JLRsCQ.path.join(b69iT7LWwrfXzGYPMvBCsteVHDQK,r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ჉"))
	rho4q6SYxUg0F = R1JETwpUnMuKXAh2Sl6vxOaF7()
	gXFeIu3GW2vzkqyfQxw6lMiBcLHsU = {XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧࡶࡵࡨࡶࠬ჊"):hGdKt2jR8SN1z5TrZkuU,drHLAY5ENQFe2q9ptKGabo(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩ჋"):qkSQU3saP0D7OvynNzH4F2BKJuilT,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪ჌"):Hqe1swvhCVTM2jYWKya0xSAUnbp,KKbpxUZnMcj6AJ4QdD(u"ࠪ࡭ࡩࡹࠧჍ"):ZAFhioq91YfduILWljSNxHDOB7(rho4q6SYxUg0F)}
	l3lOuS56hyIdjACkcweb1WDrHQgYfa = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,vvBChXmSty(u"ࠫࡕࡕࡓࡕࠩ჎"),GMfo7WypIsRin9HKEZQduYhDetFJOS,gXFeIu3GW2vzkqyfQxw6lMiBcLHsU,BGhdkWsEvJjiMFTr3NLn1flU(u"ࠬ࠭჏"),KKbpxUZnMcj6AJ4QdD(u"࠭ࠧა"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧࠨბ"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉ࡙ࡥࡑࡖࡇࡖࡘࡎࡕࡎࡔ࠯࠴ࡷࡹ࠭გ"))
	ebSw1pNJXjWAHQFlUKY = []
	if l3lOuS56hyIdjACkcweb1WDrHQgYfa.succeeded:
		DMqcCpg8GmefYtWJZITSP29x3nLzO = l3lOuS56hyIdjACkcweb1WDrHQgYfa.content
		ebSw1pNJXjWAHQFlUKY = DMqcCpg8GmefYtWJZITSP29x3nLzO.replace(iifPEY9ABNzTQp(u"ࠩ࡟ࡠࡷ࠭დ"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠪࡠࡳ࠭ე")).replace(shZ9eOcN2dJnPj(u"ࠫࡡࡢ࡮ࠨვ"),KKbpxUZnMcj6AJ4QdD(u"ࠬࡢ࡮ࠨზ")).replace(wwplD0tEehqH3kYQXs(u"࠭࡜ࡳ࡞ࡱࠫთ"),yruHDQOcB97ig(u"ࠧ࡝ࡰࠪი")).replace(BGhdkWsEvJjiMFTr3NLn1flU(u"ࠨ࡞ࡵࠫკ"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠩ࡟ࡲࠬლ"))
		ebSw1pNJXjWAHQFlUKY = u5h2Rckvw1E.findall(Tgoa16jMxvYX2(u"ࠪࡗ࡙ࡇࡒࡕ࠼࠽ࡗ࡙ࡇࡒࡕ࠼࠽ࠬࡡࡪࠫࠪ࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲࡊࡔࡄ࠻࠼ࡈࡒࡉ࠭მ"),ebSw1pNJXjWAHQFlUKY,u5h2Rckvw1E.DOTALL)
		if ebSw1pNJXjWAHQFlUKY:
			ebSw1pNJXjWAHQFlUKY = sorted(ebSw1pNJXjWAHQFlUKY,reverse=cgtRBdXxSOk7WUfyDhPCls(u"ࡌࡡ࡭ࡵࡨᜯ"),key=lambda key: int(key[PtXn0k9G3ocHRg(u"࠶ᘥ")]))
			oSXwLI6yv7E8RPW9h,hGdKt2jR8SN1z5TrZkuU,FR2iK8BzPhInGx,Oi8pLbT4W12ortZkhIaMRym3YlXcdq,wB1aszFGrQMiZXNPqSbpoL79hE,rreason = ebSw1pNJXjWAHQFlUKY[ggDRehOModi(u"࠰ᘦ")]
			mVFUoOqYhCp50QgtnGraXwEc2DB = rreason if yrPav1tl5MQcfEBhsXk2o(KKbpxUZnMcj6AJ4QdD(u"ࠫࡒ࡚࠰࠶ࡊ࡛࠴ࡱ࡚ࡔࡆࡈࡑࡗ࡚ࡔࡦࡖࡇ࡙ࡗࡘ࡛࠹ࡆ࡚ࠪნ")) else FR2iK8BzPhInGx
			LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(shZ9eOcN2dJnPj(u"ࠬࡧࡶ࠯ࡲࡨࡶ࡮ࡵࡤ࠯࡫ࡱࡪࡴࡹࠧო"),mVFUoOqYhCp50QgtnGraXwEc2DB)
			OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,vvBChXmSty(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩპ"),iifPEY9ABNzTQp(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪჟ"),ebSw1pNJXjWAHQFlUKY,QQJtZ6rMvS1wdDsHnahT7)
			LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(Tgoa16jMxvYX2(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪრ"),ZAFhioq91YfduILWljSNxHDOB7(s8bXSagYdim62TwIpQzGtUqeLhA1J))
	return ebSw1pNJXjWAHQFlUKY
def DofFeEVCk8B4rucUyJKPLZx(J3QsyI9w67hK2AF,p4NtI96EiOUXh=cNaVb1vsT4qWOL0rpE(u"࠱ᘧ"),ffXWuNVsiDvkz3MxgAlEZK4j6=cNaVb1vsT4qWOL0rpE(u"࠱ᘧ")):
	if p4NtI96EiOUXh and not ffXWuNVsiDvkz3MxgAlEZK4j6: ffXWuNVsiDvkz3MxgAlEZK4j6 = len(J3QsyI9w67hK2AF)//p4NtI96EiOUXh
	vX6H2ci50qwaFn,k0G4LTYt93po,dMAitcV9p76wr5CDW0G1eIX = [],-Tgoa16jMxvYX2(u"࠳ᘨ"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠳ᘩ")
	for YI2m5zkZ3ASWF8jK in J3QsyI9w67hK2AF:
		if dMAitcV9p76wr5CDW0G1eIX%ffXWuNVsiDvkz3MxgAlEZK4j6==PtXn0k9G3ocHRg(u"࠴ᘪ"):
			k0G4LTYt93po += BGhdkWsEvJjiMFTr3NLn1flU(u"࠶ᘫ")
			vX6H2ci50qwaFn.append([])
		vX6H2ci50qwaFn[k0G4LTYt93po].append(YI2m5zkZ3ASWF8jK)
		dMAitcV9p76wr5CDW0G1eIX += usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠷ᘬ")
	return vX6H2ci50qwaFn
def XE9lCh61r2jOH5qifS(i60vZtVrPYoD,MNWrTo98GZHn):
	bS0aA1YrmwCj8fpLdXt = k1t0JLRsCQ.path.join(OxWkR7Eu9Pm3IAvTp0q,i60vZtVrPYoD)
	if XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠱ᘭ") or ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠩࡌࡔ࡙࡜࡟ࠨს") not in i60vZtVrPYoD or M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠪࡑ࠸࡛࡟ࠨტ") not in i60vZtVrPYoD: TwPt5qAHlrOsQ = str(MNWrTo98GZHn)
	else:
		vX6H2ci50qwaFn = DofFeEVCk8B4rucUyJKPLZx(MNWrTo98GZHn,oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠹ᘮ"))
		TwPt5qAHlrOsQ = nKLEi8CJumazx4qT(u"ࠫࠬუ")
		for nPQ2WMzXtYwc9fhRVmraUDlC in vX6H2ci50qwaFn:
			TwPt5qAHlrOsQ += str(nPQ2WMzXtYwc9fhRVmraUDlC)+pcWq35MED2dtK(u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫფ")
		TwPt5qAHlrOsQ = TwPt5qAHlrOsQ.strip(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬქ"))
	XRw6ypJCYTolEkbnftQLIrzq5gSj = apKJA5QDiybZeGBk.compress(TwPt5qAHlrOsQ)
	open(bS0aA1YrmwCj8fpLdXt,Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠧࡸࡤࠪღ")).write(XRw6ypJCYTolEkbnftQLIrzq5gSj)
	return
def A9URt2ydgmL1x5BNsOzFH6QleZ(nnai7yHSxtPWANgbqZUzdeXKuJ1CRc,i60vZtVrPYoD):
	if nnai7yHSxtPWANgbqZUzdeXKuJ1CRc==bbw2eajMlG(u"ࠨࡦ࡬ࡧࡹ࠭ყ"): MNWrTo98GZHn = {}
	elif nnai7yHSxtPWANgbqZUzdeXKuJ1CRc==drHLAY5ENQFe2q9ptKGabo(u"ࠩ࡯࡭ࡸࡺࠧშ"): MNWrTo98GZHn = []
	elif nnai7yHSxtPWANgbqZUzdeXKuJ1CRc==cgtRBdXxSOk7WUfyDhPCls(u"ࠪࡷࡹࡸࠧჩ"): MNWrTo98GZHn = oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠫࠬც")
	elif nnai7yHSxtPWANgbqZUzdeXKuJ1CRc==oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠬ࡯࡮ࡵࠩძ"): MNWrTo98GZHn = cNaVb1vsT4qWOL0rpE(u"࠲ᘯ")
	else: MNWrTo98GZHn = None
	bS0aA1YrmwCj8fpLdXt = k1t0JLRsCQ.path.join(OxWkR7Eu9Pm3IAvTp0q,i60vZtVrPYoD)
	XRw6ypJCYTolEkbnftQLIrzq5gSj = open(bS0aA1YrmwCj8fpLdXt,qnPgZ9N15G6Oa8UpMASvLk(u"࠭ࡲࡣࠩწ")).read()
	TwPt5qAHlrOsQ = apKJA5QDiybZeGBk.decompress(XRw6ypJCYTolEkbnftQLIrzq5gSj)
	if tZ3gsrTEdzA1S6LXa9WI5px(u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭ჭ") not in TwPt5qAHlrOsQ: MNWrTo98GZHn = eval(TwPt5qAHlrOsQ)
	else:
		vX6H2ci50qwaFn = TwPt5qAHlrOsQ.split(OyJ1o4AvmWlB75UkFRX(u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧხ"))
		del TwPt5qAHlrOsQ
		MNWrTo98GZHn = []
		llmMg3bVOuXJG74E9oCdQrtYKpTW = NNdsp2w4g0ObWUVv7()
		oSXwLI6yv7E8RPW9h = shZ9eOcN2dJnPj(u"࠳ᘰ")
		for nPQ2WMzXtYwc9fhRVmraUDlC in vX6H2ci50qwaFn:
			llmMg3bVOuXJG74E9oCdQrtYKpTW.WJXV7aSiyDcORrlC(str(oSXwLI6yv7E8RPW9h),eval,nPQ2WMzXtYwc9fhRVmraUDlC)
			oSXwLI6yv7E8RPW9h += XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠵ᘱ")
		del vX6H2ci50qwaFn
		llmMg3bVOuXJG74E9oCdQrtYKpTW.K5TIauFsC1A()
		llmMg3bVOuXJG74E9oCdQrtYKpTW.QGIoepSDgO9s()
		R2RdhSVnBZirTYJ6K38qAU9N1FG = list(llmMg3bVOuXJG74E9oCdQrtYKpTW.resultsDICT.keys())
		BBD0Jb5R472VjLxAdSoK8MFh1z = sorted(R2RdhSVnBZirTYJ6K38qAU9N1FG,reverse=bbw2eajMlG(u"ࡆࡢ࡮ࡶࡩᜰ"),key=lambda key: int(key))
		for oSXwLI6yv7E8RPW9h in BBD0Jb5R472VjLxAdSoK8MFh1z:
			MNWrTo98GZHn += llmMg3bVOuXJG74E9oCdQrtYKpTW.resultsDICT[oSXwLI6yv7E8RPW9h]
	return MNWrTo98GZHn
def vvzmtZp4xRylqknJrSiPF3bQ0C(lY0rst72uGVZ1NkgvpjfA6x):
	TTvZlJ6qdxiNFCX3bGhtg = k1t0JLRsCQ.path.join(r4roga1DYEwG,cgtRBdXxSOk7WUfyDhPCls(u"ࠩࡤࡨࡩࡵ࡮ࡴࠩჯ"),lY0rst72uGVZ1NkgvpjfA6x,PtXn0k9G3ocHRg(u"ࠪࡥࡩࡪ࡯࡯࠰ࡻࡱࡱ࠭ჰ"))
	try: pdH9rPqYB3tDb1SagKEuIn8GRjkoc = open(TTvZlJ6qdxiNFCX3bGhtg,BGhdkWsEvJjiMFTr3NLn1flU(u"ࠫࡷࡨࠧჱ")).read()
	except:
		nUHKEpV3XxjIBvPMkci = k1t0JLRsCQ.path.join(tylMP5dsXWJO,yruHDQOcB97ig(u"ࠬࡧࡤࡥࡱࡱࡷࠬჲ"),lY0rst72uGVZ1NkgvpjfA6x,bbw2eajMlG(u"࠭ࡡࡥࡦࡲࡲ࠳ࡾ࡭࡭ࠩჳ"))
		try: pdH9rPqYB3tDb1SagKEuIn8GRjkoc = open(nUHKEpV3XxjIBvPMkci,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠧࡳࡤࠪჴ")).read()
		except: return n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠨࠩჵ"),[]
	if VVGRN7xiyj: pdH9rPqYB3tDb1SagKEuIn8GRjkoc = pdH9rPqYB3tDb1SagKEuIn8GRjkoc.decode(yruHDQOcB97ig(u"ࠩࡸࡸ࡫࠾ࠧჶ"))
	kkcJsIeLEofATzZ7DKnUvSuNG = u5h2Rckvw1E.findall(nKLEi8CJumazx4qT(u"ࠪ࡭ࡩࡃ࠮ࠫࡁࡹࡩࡷࡹࡩࡰࡰࡀ࡟ࡡࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅࠩ࡜࡞ࠥࡠࠬࡣࠧჷ"),pdH9rPqYB3tDb1SagKEuIn8GRjkoc,u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.IGNORECASE)
	if not kkcJsIeLEofATzZ7DKnUvSuNG: return ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠫࠬჸ"),[]
	RsxDLPlSgr7oUY6H98ei0mpKfTC1E,xUlkVeB0uMiEFLvrd1g8Cj = kkcJsIeLEofATzZ7DKnUvSuNG[drHLAY5ENQFe2q9ptKGabo(u"࠵ᘲ")],jMVWv8Hnk5Z6Ibhz2uYQomafJrg(kkcJsIeLEofATzZ7DKnUvSuNG[drHLAY5ENQFe2q9ptKGabo(u"࠵ᘲ")])
	return RsxDLPlSgr7oUY6H98ei0mpKfTC1E,xUlkVeB0uMiEFLvrd1g8Cj
def WY4NwzXs3TEgUJMK1hFaQbCxtn0iS():
	meUgDPidHNVr = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠬࡪࡩࡤࡶࠪჹ"),JLoPRXt93dpAB(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩჺ"),yruHDQOcB97ig(u"ࠧࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌࠨ჻"))
	if meUgDPidHNVr: return meUgDPidHNVr
	CxYkviDPANObF0LsMdJ,meUgDPidHNVr = {},{}
	ZRt1hdJLAcr = [pgPfwZleTHVQ9a[r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠨࡔࡈࡔࡔ࡙ࠧჼ")][wwplD0tEehqH3kYQXs(u"࠶ᘳ")]]
	if njGgmsD1k7cE60drxHCyVh2YN3P>PtXn0k9G3ocHRg(u"࠲࠹࠱࠽࠾ᘵ"): ZRt1hdJLAcr.append(pgPfwZleTHVQ9a[n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠩࡕࡉࡕࡕࡓࠨჽ")][yruHDQOcB97ig(u"࠱ᘴ")])
	if VVGRN7xiyj: ZRt1hdJLAcr.append(pgPfwZleTHVQ9a[JLoPRXt93dpAB(u"ࠪࡖࡊࡖࡏࡔࠩჾ")][bbw2eajMlG(u"࠴ᘶ")])
	for c354rYIiOoVUCRzM in ZRt1hdJLAcr:
		l3lOuS56hyIdjACkcweb1WDrHQgYfa = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,cgtRBdXxSOk7WUfyDhPCls(u"ࠫࡌࡋࡔࠨჿ"),c354rYIiOoVUCRzM,XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠬ࠭ᄀ"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠭ࠧᄁ"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠧࠨᄂ"),yruHDQOcB97ig(u"ࠨࠩᄃ"),shZ9eOcN2dJnPj(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊࡇࡄࡠࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍ࠯࠴ࡷࡹ࠭ᄄ"))
		if l3lOuS56hyIdjACkcweb1WDrHQgYfa.succeeded:
			DMqcCpg8GmefYtWJZITSP29x3nLzO = l3lOuS56hyIdjACkcweb1WDrHQgYfa.content
			J4kaqxIuYKn = c354rYIiOoVUCRzM.rsplit(oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠪ࠳ࠬᄅ"),xuztI5QWEKG70CPNdhk4vo6(u"࠴ᘷ"))[pcWq35MED2dtK(u"࠴ᘸ")]
			fSc5j7p49iIYUMhnt1oeOaWq = u5h2Rckvw1E.findall(nKLEi8CJumazx4qT(u"ࠫ࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡺࡪࡸࡳࡪࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᄆ"),DMqcCpg8GmefYtWJZITSP29x3nLzO,u5h2Rckvw1E.DOTALL|u5h2Rckvw1E.IGNORECASE)
			for lY0rst72uGVZ1NkgvpjfA6x,kmLd10EVgBp62rWv5KSf7QiMtsCzF in fSc5j7p49iIYUMhnt1oeOaWq:
				AiMvWL6ZSK3 = J4kaqxIuYKn+yF29Xdsx35wI07Ce4(u"ࠬ࠵ࠧᄇ")+lY0rst72uGVZ1NkgvpjfA6x+bbw2eajMlG(u"࠭࠯ࠨᄈ")+lY0rst72uGVZ1NkgvpjfA6x+bcgZJWV6UeNSkRA(u"ࠧ࠮ࠩᄉ")+kmLd10EVgBp62rWv5KSf7QiMtsCzF+oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠨ࠰ࡽ࡭ࡵ࠭ᄊ")
				if lY0rst72uGVZ1NkgvpjfA6x not in list(CxYkviDPANObF0LsMdJ.keys()):
					CxYkviDPANObF0LsMdJ[lY0rst72uGVZ1NkgvpjfA6x] = []
					meUgDPidHNVr[lY0rst72uGVZ1NkgvpjfA6x] = []
				hRoPeaG4sM3Iv1BKfUA9djiOHY = jMVWv8Hnk5Z6Ibhz2uYQomafJrg(kmLd10EVgBp62rWv5KSf7QiMtsCzF)
				CxYkviDPANObF0LsMdJ[lY0rst72uGVZ1NkgvpjfA6x].append((kmLd10EVgBp62rWv5KSf7QiMtsCzF,hRoPeaG4sM3Iv1BKfUA9djiOHY,AiMvWL6ZSK3))
	for lY0rst72uGVZ1NkgvpjfA6x in list(CxYkviDPANObF0LsMdJ.keys()):
		meUgDPidHNVr[lY0rst72uGVZ1NkgvpjfA6x] = sorted(CxYkviDPANObF0LsMdJ[lY0rst72uGVZ1NkgvpjfA6x],reverse=InKG0i2r6hHDvgd(u"ࡕࡴࡸࡩᜱ"),key=lambda key: key[JLoPRXt93dpAB(u"࠶ᘹ")])
	OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,nKLEi8CJumazx4qT(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬᄋ"),ggDRehOModi(u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫᄌ"),meUgDPidHNVr,QQJtZ6rMvS1wdDsHnahT7)
	return meUgDPidHNVr
def jMVWv8Hnk5Z6Ibhz2uYQomafJrg(kmLd10EVgBp62rWv5KSf7QiMtsCzF):
	hRoPeaG4sM3Iv1BKfUA9djiOHY = []
	DinIPs0ZcfSNBKFCzwt74 = kmLd10EVgBp62rWv5KSf7QiMtsCzF.split(InKG0i2r6hHDvgd(u"ࠫ࠳࠭ᄍ"))
	for tiO2xz94yEPGepRkoSsl in DinIPs0ZcfSNBKFCzwt74:
		To8FtWcDkAI7e0w = u5h2Rckvw1E.findall(r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠬࡢࡤࠬࡾ࡞ࡠ࠰ࡢ࠭ࡢ࠯ࡽࡅ࠲ࡠ࡝ࠬࠩᄎ"),tiO2xz94yEPGepRkoSsl,u5h2Rckvw1E.DOTALL)
		Qf5zKMcdFeVilERHxqJDZsA82C7hYn = []
		for i6ZJAIgpx8S4wCL1FnPDqy5coKGHdV in To8FtWcDkAI7e0w:
			if i6ZJAIgpx8S4wCL1FnPDqy5coKGHdV.isdigit(): i6ZJAIgpx8S4wCL1FnPDqy5coKGHdV = int(i6ZJAIgpx8S4wCL1FnPDqy5coKGHdV)
			Qf5zKMcdFeVilERHxqJDZsA82C7hYn.append(i6ZJAIgpx8S4wCL1FnPDqy5coKGHdV)
		hRoPeaG4sM3Iv1BKfUA9djiOHY.append(Qf5zKMcdFeVilERHxqJDZsA82C7hYn)
	return hRoPeaG4sM3Iv1BKfUA9djiOHY
def uBq0HrFwjMAxesPQStdcgfEKIWDYZR(hRoPeaG4sM3Iv1BKfUA9djiOHY):
	kmLd10EVgBp62rWv5KSf7QiMtsCzF = pcWq35MED2dtK(u"࠭ࠧᄏ")
	for tiO2xz94yEPGepRkoSsl in hRoPeaG4sM3Iv1BKfUA9djiOHY:
		for i6ZJAIgpx8S4wCL1FnPDqy5coKGHdV in tiO2xz94yEPGepRkoSsl: kmLd10EVgBp62rWv5KSf7QiMtsCzF += str(i6ZJAIgpx8S4wCL1FnPDqy5coKGHdV)
		kmLd10EVgBp62rWv5KSf7QiMtsCzF += qnPgZ9N15G6Oa8UpMASvLk(u"ࠧ࠯ࠩᄐ")
	kmLd10EVgBp62rWv5KSf7QiMtsCzF = kmLd10EVgBp62rWv5KSf7QiMtsCzF.strip(iifPEY9ABNzTQp(u"ࠨ࠰ࠪᄑ"))
	return kmLd10EVgBp62rWv5KSf7QiMtsCzF
def FWagyi9bX8LRexDPmArjVZfdNK(SOVvLIUhYqMB0gkezRxcdwa):
	u9q1RZQYpdDUA = {}
	CxYkviDPANObF0LsMdJ = WY4NwzXs3TEgUJMK1hFaQbCxtn0iS()
	LaIRncQCmt4xW = VynDoGKfztCiWeI(SOVvLIUhYqMB0gkezRxcdwa)
	for lY0rst72uGVZ1NkgvpjfA6x in SOVvLIUhYqMB0gkezRxcdwa:
		if lY0rst72uGVZ1NkgvpjfA6x not in list(CxYkviDPANObF0LsMdJ.keys()): continue
		meUgDPidHNVr = CxYkviDPANObF0LsMdJ[lY0rst72uGVZ1NkgvpjfA6x]
		lpTcW8Oy4mNKED31JP7oX,dsNK9gGzmxLD786vyC,UUXu9aqOcSC = meUgDPidHNVr[shZ9eOcN2dJnPj(u"࠶ᘺ")]
		j0Bh7vkYJtpCSP,GN8LC7cw5iUyv3QnfKMTE41kOe = vvzmtZp4xRylqknJrSiPF3bQ0C(lY0rst72uGVZ1NkgvpjfA6x)
		lbyFcn5LvHCQ7a3sBD2I10iY9X,ZLRXMGfkUA = LaIRncQCmt4xW[lY0rst72uGVZ1NkgvpjfA6x]
		DXCY3JzOwf8cMqna6ApQ1PetHFvsig = dsNK9gGzmxLD786vyC>GN8LC7cw5iUyv3QnfKMTE41kOe and lbyFcn5LvHCQ7a3sBD2I10iY9X
		ic2VMr7wJYbK3x6RSlOW = Tgoa16jMxvYX2(u"ࡖࡵࡹࡪᜲ")
		if not lbyFcn5LvHCQ7a3sBD2I10iY9X: ZeLkvRsNmVzWg5Fdj = cNaVb1vsT4qWOL0rpE(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪᄒ")
		elif not ZLRXMGfkUA: ZeLkvRsNmVzWg5Fdj = yruHDQOcB97ig(u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬᄓ")
		elif DXCY3JzOwf8cMqna6ApQ1PetHFvsig: ZeLkvRsNmVzWg5Fdj = shZ9eOcN2dJnPj(u"ࠫࡴࡲࡤࠨᄔ")
		else:
			ZeLkvRsNmVzWg5Fdj = CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠬ࡭࡯ࡰࡦࠪᄕ")
			ic2VMr7wJYbK3x6RSlOW = XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࡉࡥࡱࡹࡥᜳ")
		u9q1RZQYpdDUA[lY0rst72uGVZ1NkgvpjfA6x] = (ic2VMr7wJYbK3x6RSlOW,j0Bh7vkYJtpCSP,GN8LC7cw5iUyv3QnfKMTE41kOe,lpTcW8Oy4mNKED31JP7oX,dsNK9gGzmxLD786vyC,ZeLkvRsNmVzWg5Fdj,UUXu9aqOcSC)
	return u9q1RZQYpdDUA
def hyCqU2Ns4B1J3EH7fQVe6DXtzgFuI(l3OLD1gEfNXtm,g9g6YElnGqWZX,s8TC07I6dZzc1lr4=XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠭ࠧᄖ"),AmUprLgMj1fc4OhF7eoIwt=KKbpxUZnMcj6AJ4QdD(u"ࠧࠨᄗ"),Z2cxNn6DSK3ClewW=XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠨࠩᄘ")):
	if bdptXFc8UlIhA5jnGwPmKuv2L: l3OLD1gEfNXtm.update(g9g6YElnGqWZX,s8TC07I6dZzc1lr4,AmUprLgMj1fc4OhF7eoIwt,Z2cxNn6DSK3ClewW)
	else: l3OLD1gEfNXtm.update(g9g6YElnGqWZX,s8TC07I6dZzc1lr4+ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠩ࡟ࡲࠬᄙ")+AmUprLgMj1fc4OhF7eoIwt+XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠪࡠࡳ࠭ᄚ")+Z2cxNn6DSK3ClewW)
	return
def qd36ueWAYg(BZ3r6t4XFPSRq):
	def bb7wKmfGxi985IPsOWao(a6IKqA40cUlXy7tif9,YQqjFT3SdEIR0bDLp2vkAHC,CvcPsDjhXRyAmqJTnE4pQfrUN9dkt=XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠦ࠵࠷࠲࠴࠶࠸࠺࠼࠾࠹ࡢࡤࡦࡨࡪ࡬ࡧࡩ࡫࡭࡯ࡱࡳ࡮ࡰࡲࡴࡶࡸࡺࡵࡷࡹࡻࡽࡿࡇࡂࡄࡆࡈࡊࡌࡎࡉࡋࡍࡏࡑࡓࡕࡐࡒࡔࡖࡘ࡚࡜ࡗ࡙࡛࡝ࠦᄛ")):
		return ((a6IKqA40cUlXy7tif9 == wwplD0tEehqH3kYQXs(u"࠰ᘻ")) and CvcPsDjhXRyAmqJTnE4pQfrUN9dkt[wwplD0tEehqH3kYQXs(u"࠰ᘻ")]) or (bb7wKmfGxi985IPsOWao(a6IKqA40cUlXy7tif9 // YQqjFT3SdEIR0bDLp2vkAHC, YQqjFT3SdEIR0bDLp2vkAHC, CvcPsDjhXRyAmqJTnE4pQfrUN9dkt).lstrip(CvcPsDjhXRyAmqJTnE4pQfrUN9dkt[wwplD0tEehqH3kYQXs(u"࠰ᘻ")]) + CvcPsDjhXRyAmqJTnE4pQfrUN9dkt[a6IKqA40cUlXy7tif9 % YQqjFT3SdEIR0bDLp2vkAHC])
	def DSETgo3XpUsjrfkl2duz7R4Jywxq(nqju26apkfFmDHY8lMVg75Xz, s0lS5pNYIn, wqOY7uh8HXIfTVJ, iyaVsPJowM, j4e1zZroMduAXHhWnaJm0gbE=None, MfTdV953F7Jrx=None, SJqbV75DvU8=None):
		while (wqOY7uh8HXIfTVJ):
			wqOY7uh8HXIfTVJ-=iifPEY9ABNzTQp(u"࠲ᘼ")
			if (iyaVsPJowM[wqOY7uh8HXIfTVJ]): nqju26apkfFmDHY8lMVg75Xz = u5h2Rckvw1E.sub(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠧࡢ࡜ࡣࠤᄜ") + bb7wKmfGxi985IPsOWao(wqOY7uh8HXIfTVJ, s0lS5pNYIn) + n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠨ࡜࡝ࡤࠥᄝ"),  iyaVsPJowM[wqOY7uh8HXIfTVJ], nqju26apkfFmDHY8lMVg75Xz)
		return nqju26apkfFmDHY8lMVg75Xz
	BZ3r6t4XFPSRq = BZ3r6t4XFPSRq.split(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠧࡾࠪࠪᄞ"))[drHLAY5ENQFe2q9ptKGabo(u"࠳ᘽ")]
	BZ3r6t4XFPSRq = BZ3r6t4XFPSRq.rsplit(oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠨࡵࡳࡰ࡮ࡺࠧᄟ"))[KKbpxUZnMcj6AJ4QdD(u"࠳ᘾ")]+tZ3gsrTEdzA1S6LXa9WI5px(u"ࠤࡶࡴࡱ࡯ࡴࠩࠩࡿࠫ࠮࠯ࠢᄠ")
	hhUwzgWifrTC9mBl0V = eval(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠪࡹࡳࡶࡡࡤ࡭ࠫࠫᄡ")+BZ3r6t4XFPSRq,{cNaVb1vsT4qWOL0rpE(u"ࠫࡧࡧࡳࡦࡐࠪᄢ"):bb7wKmfGxi985IPsOWao,yruHDQOcB97ig(u"ࠬࡻ࡮ࡱࡣࡦ࡯ࠬᄣ"):DSETgo3XpUsjrfkl2duz7R4Jywxq})
	return hhUwzgWifrTC9mBl0V
def sjVm79bByxdrQDSH(GMfo7WypIsRin9HKEZQduYhDetFJOS,e3ct9DQ64xgviVAHsGIpUJ=ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠭ࠧᄤ")):
	if e3ct9DQ64xgviVAHsGIpUJ==vvBChXmSty(u"ࠧ࡭ࡱࡺࡩࡷ࠭ᄥ"): GMfo7WypIsRin9HKEZQduYhDetFJOS = u5h2Rckvw1E.sub(drHLAY5ENQFe2q9ptKGabo(u"ࡳࠩࠨ࡟࠵࠳࠹ࡂ࠯࡝ࡡࢀ࠸ࡽࠨᄦ"),lambda tiHOSEbsyZr: tiHOSEbsyZr.group(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠴ᘿ")).lower(),GMfo7WypIsRin9HKEZQduYhDetFJOS)
	elif e3ct9DQ64xgviVAHsGIpUJ==cgtRBdXxSOk7WUfyDhPCls(u"ࠩࡸࡴࡵ࡫ࡲࠨᄧ"): GMfo7WypIsRin9HKEZQduYhDetFJOS = u5h2Rckvw1E.sub(cNaVb1vsT4qWOL0rpE(u"ࡵࠫࠪࡡ࠰࠮࠻ࡤ࠱ࡿࡣࡻ࠳ࡿࠪᄨ"),lambda tiHOSEbsyZr: tiHOSEbsyZr.group(pcWq35MED2dtK(u"࠵ᙀ")).upper(),GMfo7WypIsRin9HKEZQduYhDetFJOS)
	return GMfo7WypIsRin9HKEZQduYhDetFJOS
def VynDoGKfztCiWeI(SOVvLIUhYqMB0gkezRxcdwa):
	Emqh7Fn4Hpo9TY1bW,HkvfZ5rmNgISc6i28bhPdlX7Jq0 = bbw2eajMlG(u"ࡊࡦࡲࡳࡦ᜴"),bbw2eajMlG(u"ࡊࡦࡲࡳࡦ᜴")
	AO76Z1XEaSDjomRwK = Xmn7ZoOHiUB2fKvd6Y8ALct3GsNT.connect(UrA7SvnaILc)
	AO76Z1XEaSDjomRwK.text_factory = str
	BVYESNuJMxlmDo5WXdaFP6r = AO76Z1XEaSDjomRwK.cursor()
	if len(SOVvLIUhYqMB0gkezRxcdwa)==xuztI5QWEKG70CPNdhk4vo6(u"࠷ᙁ"): VoOTaWFbJ6SACRXr2 = JLoPRXt93dpAB(u"ࠫ࠭ࠨࠧᄩ")+SOVvLIUhYqMB0gkezRxcdwa[InKG0i2r6hHDvgd(u"࠰ᙂ")]+oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠬࠨࠩࠨᄪ")
	else: VoOTaWFbJ6SACRXr2 = str(tuple(SOVvLIUhYqMB0gkezRxcdwa))
	BVYESNuJMxlmDo5WXdaFP6r.execute(KKbpxUZnMcj6AJ4QdD(u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࡡࡥࡦࡲࡲࡎࡊࠬࡦࡰࡤࡦࡱ࡫ࡤࠡࡈࡕࡓࡒࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡌࡒࠥ࠭ᄫ")+VoOTaWFbJ6SACRXr2+bcgZJWV6UeNSkRA(u"ࠧࠡ࠽ࠪᄬ"))
	CVRQsZFOWHvK7SpkroU15eyAn = BVYESNuJMxlmDo5WXdaFP6r.fetchall()
	LaIRncQCmt4xW = {}
	for lY0rst72uGVZ1NkgvpjfA6x in SOVvLIUhYqMB0gkezRxcdwa: LaIRncQCmt4xW[lY0rst72uGVZ1NkgvpjfA6x] = (wwplD0tEehqH3kYQXs(u"ࡋࡧ࡬ࡴࡧ᜵"),wwplD0tEehqH3kYQXs(u"ࡋࡧ࡬ࡴࡧ᜵"))
	for lY0rst72uGVZ1NkgvpjfA6x,HkvfZ5rmNgISc6i28bhPdlX7Jq0 in CVRQsZFOWHvK7SpkroU15eyAn:
		Emqh7Fn4Hpo9TY1bW = pcWq35MED2dtK(u"࡚ࡲࡶࡧ᜶")
		HkvfZ5rmNgISc6i28bhPdlX7Jq0 = HkvfZ5rmNgISc6i28bhPdlX7Jq0==bbw2eajMlG(u"࠲ᙃ")
		LaIRncQCmt4xW[lY0rst72uGVZ1NkgvpjfA6x] = (Emqh7Fn4Hpo9TY1bW,HkvfZ5rmNgISc6i28bhPdlX7Jq0)
	AO76Z1XEaSDjomRwK.close()
	return LaIRncQCmt4xW
def kI2poxnvzLZ0Yg8e1scBKy(lqTODkKeBU3zhrPXwxa57idC8):
	vS7JufTVsBxw52 = drHLAY5ENQFe2q9ptKGabo(u"ࠨࠩᄭ")
	if k1t0JLRsCQ.path.exists(lqTODkKeBU3zhrPXwxa57idC8):
		QQM3clG5VWTxqhBUSJYoOf6avpPwy = open(lqTODkKeBU3zhrPXwxa57idC8,ggDRehOModi(u"ࠩࡵࡦࠬᄮ")).read()
		if VVGRN7xiyj: QQM3clG5VWTxqhBUSJYoOf6avpPwy = QQM3clG5VWTxqhBUSJYoOf6avpPwy.decode(wwplD0tEehqH3kYQXs(u"ࠪࡹࡹ࡬࠸ࠨᄯ"))
		fruS8qL3tQw92lH = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ(wwplD0tEehqH3kYQXs(u"ࠫࡩ࡯ࡣࡵࠩᄰ"),QQM3clG5VWTxqhBUSJYoOf6avpPwy)
		if fruS8qL3tQw92lH:
			vS7JufTVsBxw52 = {}
			for LLalIEnYqHb01Kzs6uo3XvOt8MSV in fruS8qL3tQw92lH.keys():
				vS7JufTVsBxw52[LLalIEnYqHb01Kzs6uo3XvOt8MSV] = []
				for U54HQdLliv6ABPjGYxZeVyJW3MKcp in fruS8qL3tQw92lH[LLalIEnYqHb01Kzs6uo3XvOt8MSV]:
					afxYgsnGTdAHePVBK,ffAnyTIUapotW4dS6sbC,GMfo7WypIsRin9HKEZQduYhDetFJOS,Fx86vaQXEZeSBDAhmgC9zl7j2fs,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,TwPt5qAHlrOsQ,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv = CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠬ࠭ᄱ"),yruHDQOcB97ig(u"࠭ࠧᄲ"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠧࠨᄳ"),bbw2eajMlG(u"ࠨࠩᄴ"),xuztI5QWEKG70CPNdhk4vo6(u"ࠩࠪᄵ"),KKbpxUZnMcj6AJ4QdD(u"ࠪࠫᄶ"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠫࠬᄷ"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠬ࠭ᄸ"),bcgZJWV6UeNSkRA(u"࠭ࠧᄹ")
					afxYgsnGTdAHePVBK = U54HQdLliv6ABPjGYxZeVyJW3MKcp[CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠲ᙄ")]
					ffAnyTIUapotW4dS6sbC = U54HQdLliv6ABPjGYxZeVyJW3MKcp[nKLEi8CJumazx4qT(u"࠴ᙅ")]
					ffAnyTIUapotW4dS6sbC = XuE2yABLxYP(ffAnyTIUapotW4dS6sbC)
					GMfo7WypIsRin9HKEZQduYhDetFJOS = U54HQdLliv6ABPjGYxZeVyJW3MKcp[n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠶ᙆ")]
					Fx86vaQXEZeSBDAhmgC9zl7j2fs = U54HQdLliv6ABPjGYxZeVyJW3MKcp[cgtRBdXxSOk7WUfyDhPCls(u"࠸ᙇ")]
					ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx = U54HQdLliv6ABPjGYxZeVyJW3MKcp[M6PIj8gl1fno7wcqTksDEBK4bU(u"࠺ᙈ")]
					BzbaC0qYjMr2WXwsO = U54HQdLliv6ABPjGYxZeVyJW3MKcp[yF29Xdsx35wI07Ce4(u"࠵ᙉ")]
					if len(U54HQdLliv6ABPjGYxZeVyJW3MKcp)>cgtRBdXxSOk7WUfyDhPCls(u"࠷ᙊ"): TwPt5qAHlrOsQ = U54HQdLliv6ABPjGYxZeVyJW3MKcp[cgtRBdXxSOk7WUfyDhPCls(u"࠷ᙊ")]
					if len(U54HQdLliv6ABPjGYxZeVyJW3MKcp)>usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠹ᙋ"): Dm9TblyAjE0tFeO = U54HQdLliv6ABPjGYxZeVyJW3MKcp[usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠹ᙋ")]
					if len(U54HQdLliv6ABPjGYxZeVyJW3MKcp)>XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠻ᙌ"): aiSY4yFdLmPH2zenlMpv = U54HQdLliv6ABPjGYxZeVyJW3MKcp[XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠻ᙌ")]
					if lqTODkKeBU3zhrPXwxa57idC8==MZabdxfVE5WJwUu: Gx7p1QS89JOnF3eT5 = afxYgsnGTdAHePVBK,ffAnyTIUapotW4dS6sbC,GMfo7WypIsRin9HKEZQduYhDetFJOS,Fx86vaQXEZeSBDAhmgC9zl7j2fs,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,TwPt5qAHlrOsQ,yruHDQOcB97ig(u"ࠧࠨᄺ"),aiSY4yFdLmPH2zenlMpv
					else: Gx7p1QS89JOnF3eT5 = afxYgsnGTdAHePVBK,ffAnyTIUapotW4dS6sbC,GMfo7WypIsRin9HKEZQduYhDetFJOS,Fx86vaQXEZeSBDAhmgC9zl7j2fs,ddMRDz1qv3CXKb2Z6ySE9nO4NUcLx,BzbaC0qYjMr2WXwsO,TwPt5qAHlrOsQ,Dm9TblyAjE0tFeO,aiSY4yFdLmPH2zenlMpv
					vS7JufTVsBxw52[LLalIEnYqHb01Kzs6uo3XvOt8MSV].append(Gx7p1QS89JOnF3eT5)
		zzSfX1AF0D = str(vS7JufTVsBxw52)
		if VVGRN7xiyj: zzSfX1AF0D = zzSfX1AF0D.encode(r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠨࡷࡷࡪ࠽࠭ᄻ"))
		open(lqTODkKeBU3zhrPXwxa57idC8,oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠩࡺࡦࠬᄼ")).write(zzSfX1AF0D)
	return vS7JufTVsBxw52
def BZ60Cr5qARSJYjkD(tzVT6PXndWu0):
	MpN3OCATW1QE8ib6BsY7z = tzVT6PXndWu0.split(xuztI5QWEKG70CPNdhk4vo6(u"ࠪ࠱ࠬᄽ"),KKbpxUZnMcj6AJ4QdD(u"࠵ᙍ"))[vvBChXmSty(u"࠵ᙎ")]
	lKC9tsMTk1xeVIDmUjwrZzvhP50,lfXd1GQTyCkVSUzAeO,gprYWX3BPb7EVuv4wmlc = wwplD0tEehqH3kYQXs(u"ࠫࠬᄾ"),nKLEi8CJumazx4qT(u"ࠬ࠭ᄿ"),cgtRBdXxSOk7WUfyDhPCls(u"࠭ࠧᅀ")
	if   MpN3OCATW1QE8ib6BsY7z==bbw2eajMlG(u"ࠧࡂࡊ࡚ࡅࡐ࠭ᅁ")		:	from R6fiTqZm2X			import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==PtXn0k9G3ocHRg(u"ࠨࡃࡎࡓࡆࡓࠧᅂ")		:	from EnzcoUOKkg			import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==yruHDQOcB97ig(u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐࠫᅃ")	:	from kmsGWLvufP		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠪࡅࡐ࡝ࡁࡎࠩᅄ")		:	from Jn5W8Lt2m3			import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==shZ9eOcN2dJnPj(u"ࠫࡆࡒࡁࡓࡃࡅࠫᅅ")	:	from HyboIkYG2Q			import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==yruHDQOcB97ig(u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏࠧᅆ")	:	from vvf6IlL5wk		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==qnPgZ9N15G6Oa8UpMASvLk(u"࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓࠩᅇ")	: 	from g6wcionfLm		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==bcgZJWV6UeNSkRA(u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇࠩᅈ")	:	from kyRNVzKZds		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==bbw2eajMlG(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭ᅉ"):	from ssdmqca2DG	import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==ggDRehOModi(u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫᅊ")	:	from MmeOUju29E		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠪࡆࡔࡑࡒࡂࠩᅋ")		:	from Doxsw2Anyd			import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==qnPgZ9N15G6Oa8UpMASvLk(u"ࠫࡇࡘࡓࡕࡇࡍࠫᅌ")	:	from CrAY5GRxTW			import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==OyJ1o4AvmWlB75UkFRX(u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭ᅍ")	:	from EENaHABDdg		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==tZ3gsrTEdzA1S6LXa9WI5px(u"࠭ࡃࡊࡏࡄ࠸࡚࠭ᅎ")	:	from nklwYcfzev			import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==shZ9eOcN2dJnPj(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩᅏ")	:	from e0WXjywiOS		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࡚ࡓࡗࡑࠧᅐ"):	from YcKLFTJ16g	import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==bbw2eajMlG(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫᅑ"):		from ZZDpU58LVm		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==bcgZJWV6UeNSkRA(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔࠬᅒ")	:	from JB0xjSXlDZ		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==bbw2eajMlG(u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭ᅓ")	:	from a8xkLvbS5l		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==xuztI5QWEKG70CPNdhk4vo6(u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨᅔ")	:	from Njt6lSoURL		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧᅕ")	:	from QW5xFpg0rX		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬᅖ"):	from Idq3R2HptB	import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==drHLAY5ENQFe2q9ptKGabo(u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩᅗ")	:	from b3JOnBIZkU		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖࠪᅘ")	:	from Hfp1lCym08		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬᅙ")	:	from LLZ6q2UV4K		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==InKG0i2r6hHDvgd(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭ᅚ")	:	from tPsajGVDki		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==nKLEi8CJumazx4qT(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧᅛ")	:	from XMumB6sYhk		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==JLoPRXt93dpAB(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴ࠨᅜ")	:	from jQHBZOt3Up		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==iifPEY9ABNzTQp(u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨᅝ")	:	from ysKtT73ARW		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠨࡇࡊ࡝ࡓࡕࡗࠨᅞ")	:	from LLf3XgyDNA			import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==yF29Xdsx35wI07Ce4(u"ࠩࡉࡅࡇࡘࡁࡌࡃࠪᅟ")	:	from Bt21p86GIl		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==tZ3gsrTEdzA1S6LXa9WI5px(u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭ᅠ")	:	from yVGIEJxcRO		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭ᅡ")	:	from XXW03oFr2P		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==PtXn0k9G3ocHRg(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸ࠧᅢ")	:	from hhxlfEmF5y		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==ggDRehOModi(u"࠭ࡆࡐࡕࡗࡅࠬᅣ")		:	from gbfv9GxH4C			import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩᅤ")	:	from YHsR9TjoQK		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠨࡋࡉࡍࡑࡓࠧᅥ")		:	from XKpdiHwDMq			import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩࡌࡔ࡙࡜ࠧᅦ")		:	from BSdmDzviZG	import TWdJepU45bz2MXCBPrY1Km0Sfouwv9 as lKC9tsMTk1xeVIDmUjwrZzvhP50,GnJ5vKxzWhoYXw0IFyi6TSEVsNHaMp as lfXd1GQTyCkVSUzAeO,unXlPWCM9EdmRAsybwT as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==yruHDQOcB97ig(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭ᅧ")	:	from oTPdVYaLtF		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==cgtRBdXxSOk7WUfyDhPCls(u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭ᅨ")	:	from UOm9eZlMCQ		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==KKbpxUZnMcj6AJ4QdD(u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋࠧᅩ")	:	from MWGsQ2BUeR		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==bbw2eajMlG(u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭ᅪ")	:	from TAEIfQ8l7t			import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨᅫ")	:	from GFERWCcHYQ		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==yruHDQOcB97ig(u"ࠨࡏ࠶࡙ࠬᅬ")		:	from kS9c6phm0W	import TWdJepU45bz2MXCBPrY1Km0Sfouwv9 as lKC9tsMTk1xeVIDmUjwrZzvhP50,GnJ5vKxzWhoYXw0IFyi6TSEVsNHaMp as lfXd1GQTyCkVSUzAeO,unXlPWCM9EdmRAsybwT as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==pcWq35MED2dtK(u"ࠩࡐࡓ࡛࡙࠴ࡖࠩᅭ")	:	from VCdK5LpWwE			import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠪࡑ࡞ࡉࡉࡎࡃࠪᅮ")	:	from W9RI8wqtK2			import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==nKLEi8CJumazx4qT(u"ࠫࡕࡇࡎࡆࡖࠪᅯ")		:	from PwRegaCVSl			import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==drHLAY5ENQFe2q9ptKGabo(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧᅰ")	:	from tFWb48mphv		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==iifPEY9ABNzTQp(u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪᅱ"):	from yJYQHXlE6h		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==KKbpxUZnMcj6AJ4QdD(u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇࠪᅲ")	:	from wv8ZzdB62P		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==bbw2eajMlG(u"ࠨࡕࡋࡓࡋࡎࡁࠨᅳ")	:	from hjCIaSDtTE			import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==qnPgZ9N15G6Oa8UpMASvLk(u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫᅴ")	:	from PXUTyc7Mu0		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==nKLEi8CJumazx4qT(u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓࠬᅵ")	:	from NLFpfGkys5		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==xuztI5QWEKG70CPNdhk4vo6(u"࡙ࠫ࡜ࡆࡖࡐࠪᅶ")		:	from pQabjHLJut			import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==bcgZJWV6UeNSkRA(u"ࠬ࡝ࡅࡄࡋࡐࡅࠬᅷ")	:	from yyFkTgEfoX			import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࡙࠭ࡂࡓࡒࡘࠬᅸ")		:	from ggHV1wT6n3			import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==OyJ1o4AvmWlB75UkFRX(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨᅹ")	:	from bFeRWshMkt		import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50,bB8m3r5asjpdG0ulEJg as lfXd1GQTyCkVSUzAeO,tiCRYyX1bWd40Ir3PafQu as gprYWX3BPb7EVuv4wmlc
	elif MpN3OCATW1QE8ib6BsY7z==oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠨ࡛ࡗࡆࡤࡉࡈࡂࡐࡑࡉࡑ࡙ࠧᅺ"):	from PYNkI4rj60	import LitkEX0THgZadBAYn3hUIRoFC as lKC9tsMTk1xeVIDmUjwrZzvhP50
	return lKC9tsMTk1xeVIDmUjwrZzvhP50,lfXd1GQTyCkVSUzAeO,gprYWX3BPb7EVuv4wmlc
def sG6DJ2IAY17EbZceRVF(vwc2nNCU60eHkyPWB3qbYmxMhV7Dg,vSj57P0g4mF2Bp,showDialogs):
	l0SAerv8zGH2Wa(JLoPRXt93dpAB(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩᅻ"),shZ9eOcN2dJnPj(u"ࠪ࠲ࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪ࠾ࠥࡡࠠࠨᅼ")+vwc2nNCU60eHkyPWB3qbYmxMhV7Dg+pcWq35MED2dtK(u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧᅽ")+str(vSj57P0g4mF2Bp)+bcgZJWV6UeNSkRA(u"ࠬࠦ࡝ࠨᅾ"))
	l3OLD1gEfNXtm = zzLBYaEcM1jlKqX5FyONiRJ()
	l3OLD1gEfNXtm.create(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᅿ"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"๋ࠧฮิ๎ࠥอไร่ࠣๅา฻ࠠศๆ่่ๆࠦวๅ็ฺ่ํฮࠠหฯ่๎้ํ้ࠠส฼ำ์อࠠิ๊ไࠤฯฮฯฤࠢ฼้้๐ษࠡฮ็ฬࠥอไๆๆไࠤ๊์ࠠศๆศ๊ฯืๆหࠩᆀ"))
	hbHgfvqG16IPoFiANjCa = M6PIj8gl1fno7wcqTksDEBK4bU(u"࠷࠰࠳࠶ᙏ")*M6PIj8gl1fno7wcqTksDEBK4bU(u"࠷࠰࠳࠶ᙏ")
	aviTBV4X02MQ = JLoPRXt93dpAB(u"࠱ᙐ")*hbHgfvqG16IPoFiANjCa
	l3lOuS56hyIdjACkcweb1WDrHQgYfa = RduBx91EMtZDLn.get(vwc2nNCU60eHkyPWB3qbYmxMhV7Dg,stream=usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࡔࡳࡷࡨ᜷"),headers=vSj57P0g4mF2Bp)
	fLXKDh2FcVdo60IqrYs = l3lOuS56hyIdjACkcweb1WDrHQgYfa.headers
	l3lOuS56hyIdjACkcweb1WDrHQgYfa.close()
	HHph6yCLmq3lxBOn2c = bytes()
	if not fLXKDh2FcVdo60IqrYs:
		if showDialogs: xl9MFt1AmY0GrkENug8n(qnPgZ9N15G6Oa8UpMASvLk(u"ࠨࠩᆁ"),vvBChXmSty(u"ࠩࠪᆂ"),cgtRBdXxSOk7WUfyDhPCls(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᆃ"),nKLEi8CJumazx4qT(u"ࠫฬ๊ศา่ส้ัࠦไๆࠢํฮ๊้ๆࠡ็้ࠤฯำๅ๋ๆࠣห้๋ไโࠢส่๊฽ไ้สࠣ์ฬ๊ำษสࠣๆิ๊ࠦไ๊้ࠤ฾์ฯไุ่่๊ࠢษࠡใํࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูࠥฮใࠡ࠰ࠣะึฮࠠหฯ่๎้ࠦวๅ็็ๅ๋ࠥัสࠢฦาึ๏ࠧᆄ"))
		l3OLD1gEfNXtm.close()
	else:
		if bbw2eajMlG(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡌࡦࡰࡪࡸ࡭࠭ᆅ") not in list(fLXKDh2FcVdo60IqrYs.keys()): ttO8Cx0kT6N4JSYVfPGc52ALs3v = drHLAY5ENQFe2q9ptKGabo(u"࠱ᙑ")
		else: ttO8Cx0kT6N4JSYVfPGc52ALs3v = int(fLXKDh2FcVdo60IqrYs[bcgZJWV6UeNSkRA(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡍࡧࡱ࡫ࡹ࡮ࠧᆆ")])
		tBSELDxbI1z53WUuXnCaN6oydc40PG = str(int(cNaVb1vsT4qWOL0rpE(u"࠴࠴࠵࠶ᙓ")*ttO8Cx0kT6N4JSYVfPGc52ALs3v/hbHgfvqG16IPoFiANjCa)/Tgoa16jMxvYX2(u"࠳࠳࠴࠵࠴࠰ᙒ"))
		ooanBu213hZr = int(ttO8Cx0kT6N4JSYVfPGc52ALs3v/aviTBV4X02MQ)+cgtRBdXxSOk7WUfyDhPCls(u"࠵ᙔ")
		if Tgoa16jMxvYX2(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡔࡤࡲ࡬࡫ࠧᆇ") in list(fLXKDh2FcVdo60IqrYs.keys()) and ttO8Cx0kT6N4JSYVfPGc52ALs3v>hbHgfvqG16IPoFiANjCa:
			q0qkjLfMzE = KKbpxUZnMcj6AJ4QdD(u"ࡕࡴࡸࡩ᜸")
			gV6ZIS18pf2r = []
			P1nyad9vGkq0rUQ3iTpfKlbMY = CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠶࠶ᙕ")
			gV6ZIS18pf2r.append(str(yruHDQOcB97ig(u"࠰ᙗ")*ttO8Cx0kT6N4JSYVfPGc52ALs3v//P1nyad9vGkq0rUQ3iTpfKlbMY)+nKLEi8CJumazx4qT(u"ࠨ࠯ࠪᆈ")+str(JLoPRXt93dpAB(u"࠷ᙖ")*ttO8Cx0kT6N4JSYVfPGc52ALs3v//P1nyad9vGkq0rUQ3iTpfKlbMY-JLoPRXt93dpAB(u"࠷ᙖ")))
			gV6ZIS18pf2r.append(str(M6PIj8gl1fno7wcqTksDEBK4bU(u"࠲ᙘ")*ttO8Cx0kT6N4JSYVfPGc52ALs3v//P1nyad9vGkq0rUQ3iTpfKlbMY)+ggDRehOModi(u"ࠩ࠰ࠫᆉ")+str(BGhdkWsEvJjiMFTr3NLn1flU(u"࠴ᙙ")*ttO8Cx0kT6N4JSYVfPGc52ALs3v//P1nyad9vGkq0rUQ3iTpfKlbMY-M6PIj8gl1fno7wcqTksDEBK4bU(u"࠲ᙘ")))
			gV6ZIS18pf2r.append(str(PtXn0k9G3ocHRg(u"࠷ᙜ")*ttO8Cx0kT6N4JSYVfPGc52ALs3v//P1nyad9vGkq0rUQ3iTpfKlbMY)+Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠪ࠱ࠬᆊ")+str(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠷ᙛ")*ttO8Cx0kT6N4JSYVfPGc52ALs3v//P1nyad9vGkq0rUQ3iTpfKlbMY-InKG0i2r6hHDvgd(u"࠴ᙚ")))
			gV6ZIS18pf2r.append(str(cgtRBdXxSOk7WUfyDhPCls(u"࠳ᙞ")*ttO8Cx0kT6N4JSYVfPGc52ALs3v//P1nyad9vGkq0rUQ3iTpfKlbMY)+Tgoa16jMxvYX2(u"ࠫ࠲࠭ᆋ")+str(cgtRBdXxSOk7WUfyDhPCls(u"࠵ᙟ")*ttO8Cx0kT6N4JSYVfPGc52ALs3v//P1nyad9vGkq0rUQ3iTpfKlbMY-yF29Xdsx35wI07Ce4(u"࠷ᙝ")))
			gV6ZIS18pf2r.append(str(M6PIj8gl1fno7wcqTksDEBK4bU(u"࠸ᙢ")*ttO8Cx0kT6N4JSYVfPGc52ALs3v//P1nyad9vGkq0rUQ3iTpfKlbMY)+bcgZJWV6UeNSkRA(u"ࠬ࠳ࠧᆌ")+str(vvBChXmSty(u"࠸ᙡ")*ttO8Cx0kT6N4JSYVfPGc52ALs3v//P1nyad9vGkq0rUQ3iTpfKlbMY-XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠳ᙠ")))
			gV6ZIS18pf2r.append(str(qnPgZ9N15G6Oa8UpMASvLk(u"࠻ᙤ")*ttO8Cx0kT6N4JSYVfPGc52ALs3v//P1nyad9vGkq0rUQ3iTpfKlbMY)+JLoPRXt93dpAB(u"࠭࠭ࠨᆍ")+str(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠶ᙥ")*ttO8Cx0kT6N4JSYVfPGc52ALs3v//P1nyad9vGkq0rUQ3iTpfKlbMY-xuztI5QWEKG70CPNdhk4vo6(u"࠶ᙣ")))
			gV6ZIS18pf2r.append(str(ggDRehOModi(u"࠹ᙨ")*ttO8Cx0kT6N4JSYVfPGc52ALs3v//P1nyad9vGkq0rUQ3iTpfKlbMY)+M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠧ࠮ࠩᆎ")+str(oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠹ᙧ")*ttO8Cx0kT6N4JSYVfPGc52ALs3v//P1nyad9vGkq0rUQ3iTpfKlbMY-Tgoa16jMxvYX2(u"࠲ᙦ")))
			gV6ZIS18pf2r.append(str(ggDRehOModi(u"࠽ᙫ")*ttO8Cx0kT6N4JSYVfPGc52ALs3v//P1nyad9vGkq0rUQ3iTpfKlbMY)+bcgZJWV6UeNSkRA(u"ࠨ࠯ࠪᆏ")+str(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠽ᙪ")*ttO8Cx0kT6N4JSYVfPGc52ALs3v//P1nyad9vGkq0rUQ3iTpfKlbMY-OyJ1o4AvmWlB75UkFRX(u"࠵ᙩ")))
			gV6ZIS18pf2r.append(str(cNaVb1vsT4qWOL0rpE(u"࠹᙭")*ttO8Cx0kT6N4JSYVfPGc52ALs3v//P1nyad9vGkq0rUQ3iTpfKlbMY)+nKLEi8CJumazx4qT(u"ࠩ࠰ࠫᆐ")+str(pcWq35MED2dtK(u"࠹ᙬ")*ttO8Cx0kT6N4JSYVfPGc52ALs3v//P1nyad9vGkq0rUQ3iTpfKlbMY-bcgZJWV6UeNSkRA(u"࠳᙮")))
			gV6ZIS18pf2r.append(str(cNaVb1vsT4qWOL0rpE(u"࠼ᙯ")*ttO8Cx0kT6N4JSYVfPGc52ALs3v//P1nyad9vGkq0rUQ3iTpfKlbMY)+vvBChXmSty(u"ࠪ࠱ࠬᆑ"))
			Rxsnwjl2O0WIqhrAz = float(ooanBu213hZr)/P1nyad9vGkq0rUQ3iTpfKlbMY
			hdHv6oIucb87jEypG = Rxsnwjl2O0WIqhrAz/int(cNaVb1vsT4qWOL0rpE(u"࠵ᙰ")+Rxsnwjl2O0WIqhrAz)
		else:
			q0qkjLfMzE = ggDRehOModi(u"ࡈࡤࡰࡸ࡫᜹")
			P1nyad9vGkq0rUQ3iTpfKlbMY = shZ9eOcN2dJnPj(u"࠶ᙱ")
			hdHv6oIucb87jEypG = tZ3gsrTEdzA1S6LXa9WI5px(u"࠷ᙲ")
		l0SAerv8zGH2Wa(xuztI5QWEKG70CPNdhk4vo6(u"ࠫࡓࡕࡔࡊࡅࡈࠫᆒ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠬ࠴ࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡹࡸ࡯࡮ࡨࠢࡵࡥࡳ࡭ࡥࡴ࠼ࠣ࡟ࠥ࠭ᆓ")+str(q0qkjLfMzE)+BGhdkWsEvJjiMFTr3NLn1flU(u"࠭ࠠ࡞ࠢࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨᆔ")+str(ttO8Cx0kT6N4JSYVfPGc52ALs3v)+cNaVb1vsT4qWOL0rpE(u"ࠧࠡ࡟ࠪᆕ"))
		k0G4LTYt93po,WP9NthMjEOoHwvmz2S = cgtRBdXxSOk7WUfyDhPCls(u"࠰ᙳ"),cgtRBdXxSOk7WUfyDhPCls(u"࠰ᙳ")
		for dMAitcV9p76wr5CDW0G1eIX in range(P1nyad9vGkq0rUQ3iTpfKlbMY):
			emrzEIsMWO2GLw9lpKxSY7n0F = vSj57P0g4mF2Bp.copy()
			if q0qkjLfMzE: emrzEIsMWO2GLw9lpKxSY7n0F[ggDRehOModi(u"ࠨࡔࡤࡲ࡬࡫ࠧᆖ")] = PtXn0k9G3ocHRg(u"ࠩࡥࡽࡹ࡫ࡳ࠾ࠩᆗ")+gV6ZIS18pf2r[dMAitcV9p76wr5CDW0G1eIX]
			l3lOuS56hyIdjACkcweb1WDrHQgYfa = RduBx91EMtZDLn.get(vwc2nNCU60eHkyPWB3qbYmxMhV7Dg,stream=tZ3gsrTEdzA1S6LXa9WI5px(u"ࡗࡶࡺ࡫᜺"),headers=emrzEIsMWO2GLw9lpKxSY7n0F,timeout=Tgoa16jMxvYX2(u"࠴࠲࠳ᙴ"))
			for GqeLb6R728VUtuCW5N in l3lOuS56hyIdjACkcweb1WDrHQgYfa.iter_content(chunk_size=aviTBV4X02MQ):
				if l3OLD1gEfNXtm.iscanceled():
					l0SAerv8zGH2Wa(oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪᆘ"),shZ9eOcN2dJnPj(u"ࠫ࠳ࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡆࡥࡳࡩࡥ࡭ࡧࡧࠫᆙ"))
					break
				k0G4LTYt93po += hdHv6oIucb87jEypG
				HHph6yCLmq3lxBOn2c += GqeLb6R728VUtuCW5N
				if not WP9NthMjEOoHwvmz2S: WP9NthMjEOoHwvmz2S = len(GqeLb6R728VUtuCW5N)
				if ttO8Cx0kT6N4JSYVfPGc52ALs3v: hyCqU2Ns4B1J3EH7fQVe6DXtzgFuI(l3OLD1gEfNXtm,InKG0i2r6hHDvgd(u"࠳࠳࠴ᙵ")*k0G4LTYt93po//ooanBu213hZr,KKbpxUZnMcj6AJ4QdD(u"ࠬาไษࠢส่๊๊แ࠻࠯ࠣห้าายࠢิๆ๊࠭ᆚ"),str(pcWq35MED2dtK(u"࠴࠴࠵࠴࠰ᙶ")*WP9NthMjEOoHwvmz2S*k0G4LTYt93po//aviTBV4X02MQ//pcWq35MED2dtK(u"࠴࠴࠵࠴࠰ᙶ"))+n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠭ࠠ࠰ࠢࠪᆛ")+tBSELDxbI1z53WUuXnCaN6oydc40PG+cNaVb1vsT4qWOL0rpE(u"ࠧࠡࡏࡅࠫᆜ"))
				else: hyCqU2Ns4B1J3EH7fQVe6DXtzgFuI(l3OLD1gEfNXtm,WP9NthMjEOoHwvmz2S*k0G4LTYt93po//aviTBV4X02MQ,InKG0i2r6hHDvgd(u"ࠨฮ็ฬࠥอไๆๆไ࠾࠲࠭ᆝ"),str(nKLEi8CJumazx4qT(u"࠵࠵࠶࠮࠱ᙷ")*WP9NthMjEOoHwvmz2S*k0G4LTYt93po//aviTBV4X02MQ//nKLEi8CJumazx4qT(u"࠵࠵࠶࠮࠱ᙷ"))+ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠩࠣࡑࡇ࠭ᆞ"))
			l3lOuS56hyIdjACkcweb1WDrHQgYfa.close()
		l3OLD1gEfNXtm.close()
		if len(HHph6yCLmq3lxBOn2c)<ttO8Cx0kT6N4JSYVfPGc52ALs3v and ttO8Cx0kT6N4JSYVfPGc52ALs3v>bbw2eajMlG(u"࠵ᙸ"):
			l0SAerv8zGH2Wa(shZ9eOcN2dJnPj(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪᆟ"),drHLAY5ENQFe2q9ptKGabo(u"ࠫ࠳ࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡩࡥ࡮ࡲࡥࡥࠢࡲࡶࠥࡩࡡ࡯ࡥࡨࡰࡪࡪࠠࡢࡶ࠽ࠤࡠࠦࠧᆠ")+str(len(HHph6yCLmq3lxBOn2c)//hbHgfvqG16IPoFiANjCa)+wwplD0tEehqH3kYQXs(u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡳࡱࡰࠤࡹࡵࡴࡢ࡮ࠣࡳ࡫ࡀࠠ࡜ࠢࠪᆡ")+tBSELDxbI1z53WUuXnCaN6oydc40PG+Tgoa16jMxvYX2(u"࠭ࠠࡎࡄࠣࡡࠬᆢ"))
			OdN8EyB3LDqfoJCg = lRwnVNxCZXGgkqd390(nKLEi8CJumazx4qT(u"ࠧࠨᆣ"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠨว็฾ฬว้ࠠะิ์ั࠭ᆤ"),yF29Xdsx35wI07Ce4(u"ࠩสืฯิฯศ็ࠣห้๋ไโࠢส่๋อโึࠩᆥ"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠪษ฾อฯสࠢฯ่อࠦวๅ็็ๅࠬᆦ"),nKLEi8CJumazx4qT(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᆧ"),yF29Xdsx35wI07Ce4(u"ࠬ็ิๅࠢไ๎ࠥาไษࠢส่๊๊แࠡ࡞ࡱࠤ้๊ริใࠣัิัࠠฯูฦࠤๆ๐ࠠหฯ่๎้ࠦวๅ็็ๅࠥࡢ࡮ࠡฬ่ࠤั๊ศࠡࠩᆨ")+str(len(HHph6yCLmq3lxBOn2c)//hbHgfvqG16IPoFiANjCa)+InKG0i2r6hHDvgd(u"࠭ࠠๆ์฽หออ๊ห่๊๋ࠢࠥฬๆ๊฼ࠤࠬᆩ")+tBSELDxbI1z53WUuXnCaN6oydc40PG+KKbpxUZnMcj6AJ4QdD(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣࡠࡳࠦฬาสࠣะ้ฮࠠศๆ่่ๆࠦๅาหࠣวำื้ࠡ࡞ࡱࠤ์๊ࠠหำํำࠥอำหะาห๊ࠦวๅ็็ๅࠥอไ็ษๅูࠥลࠡࠢࠩᆪ"))
			if OdN8EyB3LDqfoJCg==r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠸ᙹ"): HHph6yCLmq3lxBOn2c = sG6DJ2IAY17EbZceRVF(vwc2nNCU60eHkyPWB3qbYmxMhV7Dg,vSj57P0g4mF2Bp,showDialogs)
			elif OdN8EyB3LDqfoJCg==KKbpxUZnMcj6AJ4QdD(u"࠱ᙺ"): l0SAerv8zGH2Wa(r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠨࡐࡒࡘࡎࡉࡅࠨᆫ"),cgtRBdXxSOk7WUfyDhPCls(u"ࠩ࠱ࠤࠥࡔ࡯ࡵࠢࡦࡳࡲࡶ࡬ࡦࡶࡨࡨࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡥࡥࠢࡩ࡭ࡱ࡫ࠠࡪࡵࠣࡥࡨࡩࡥࡱࡶࡨࡨࠥࡧ࡮ࡥࠢࡺ࡭ࡱࡲࠠࡣࡧࠣࡹࡸ࡫ࡤࠨᆬ"))
			else: return CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠪࠫᆭ")
			if not HHph6yCLmq3lxBOn2c: return CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠫࠬᆮ")
		else: l0SAerv8zGH2Wa(iifPEY9ABNzTQp(u"ࠬࡔࡏࡕࡋࡆࡉࠬᆯ"),BGhdkWsEvJjiMFTr3NLn1flU(u"࠭࠮ࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡘࡻࡣࡤࡧࡨࡨࡪࡪ࠮ࠡࠢࠣࡊ࡮ࡲࡥࠡࡕ࡬ࡾࡪࡀࠠ࡜ࠢࠪᆰ")+tBSELDxbI1z53WUuXnCaN6oydc40PG+wwplD0tEehqH3kYQXs(u"ࠧࠡࡏࡅࠤࡢ࠭ᆱ"))
	return HHph6yCLmq3lxBOn2c
def ooeA9fZg7FVqs8rEPNwR(aUVSgO2ebjwX5iqPykC):
	return l3lOuS56hyIdjACkcweb1WDrHQgYfa
def COnauLbjTwX31YoPgxNlcJ(ip=shZ9eOcN2dJnPj(u"ࠨࠩᆲ")):
	LLuWg4HJbUDjX1v,Hqe1swvhCVTM2jYWKya0xSAUnbp,Oo814jC5Bx3QvNnPFH,bToL1eIWPGVFU4,EsHQmuDNS9I4g3njoAfWLORaTtdGiF,zwQuFoLAP2T8acYH6pl7vN1fr5D = bbw2eajMlG(u"ࠩࠪᆳ"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠪࠫᆴ"),cgtRBdXxSOk7WUfyDhPCls(u"ࠫࠬᆵ"),iifPEY9ABNzTQp(u"ࠬ࠭ᆶ"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠭ࠧᆷ"),OyJ1o4AvmWlB75UkFRX(u"ࠧࠨᆸ")
	GMfo7WypIsRin9HKEZQduYhDetFJOS = Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡫ࡳࡻ࡭ࡵ࠮ࡪࡵ࠲ࠫᆹ")+ip+oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠩࡂࡳࡺࡺࡰࡶࡶࡀ࡮ࡸࡵ࡮ࠧࡨ࡬ࡩࡱࡪࡳ࠾࡫ࡳ࠰ࡨࡵ࡮ࡵ࡫ࡱࡩࡳࡺࠬࡤࡱࡸࡲࡹࡸࡹ࠭ࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫ࠬࡳࡧࡪ࡭ࡴࡴࠬࡤ࡫ࡷࡽ࠱ࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧᆺ")
	vSj57P0g4mF2Bp = {yF29Xdsx35wI07Ce4(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᆻ"):wwplD0tEehqH3kYQXs(u"ࠫࠬᆼ")}
	l3lOuS56hyIdjACkcweb1WDrHQgYfa = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,cgtRBdXxSOk7WUfyDhPCls(u"ࠬࡍࡅࡕࠩᆽ"),GMfo7WypIsRin9HKEZQduYhDetFJOS,CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠭ࠧᆾ"),vSj57P0g4mF2Bp,wwplD0tEehqH3kYQXs(u"ࠧࠨᆿ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠨࠩᇀ"),bbw2eajMlG(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊࡕࡌࡐࡅࡄࡘࡎࡕࡎ࠮࠳ࡶࡸࠬᇁ"))
	if not l3lOuS56hyIdjACkcweb1WDrHQgYfa.succeeded: OOjM98q7XuSQl = ip+CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠪ࠰ࠬᇂ")+LLuWg4HJbUDjX1v+iifPEY9ABNzTQp(u"ࠫ࠱࠭ᇃ")+Hqe1swvhCVTM2jYWKya0xSAUnbp+pcWq35MED2dtK(u"ࠬ࠲ࠧᇄ")+bToL1eIWPGVFU4+KKbpxUZnMcj6AJ4QdD(u"࠭ࠬࠨᇅ")+EsHQmuDNS9I4g3njoAfWLORaTtdGiF+vvBChXmSty(u"ࠧ࠭ࠩᇆ")+zwQuFoLAP2T8acYH6pl7vN1fr5D
	else:
		DMqcCpg8GmefYtWJZITSP29x3nLzO = l3lOuS56hyIdjACkcweb1WDrHQgYfa.content
		DMqcCpg8GmefYtWJZITSP29x3nLzO = u5h2Rckvw1E.findall(yF29Xdsx35wI07Ce4(u"ࠨ࡞ࡾ࠲࠯ࡅ࡜ࡾ࡞ࢀࠫᇇ"),DMqcCpg8GmefYtWJZITSP29x3nLzO,u5h2Rckvw1E.DOTALL)
		if DMqcCpg8GmefYtWJZITSP29x3nLzO:
			DMqcCpg8GmefYtWJZITSP29x3nLzO = DMqcCpg8GmefYtWJZITSP29x3nLzO[n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠱ᙻ")]
			AoW1mDOpkbZw5F0nqNQKu = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ(drHLAY5ENQFe2q9ptKGabo(u"ࠩࡧ࡭ࡨࡺࠧᇈ"),DMqcCpg8GmefYtWJZITSP29x3nLzO)
			YYwjatHrFLils8DPZfmG6bX = list(AoW1mDOpkbZw5F0nqNQKu.keys())
			if usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠪ࡭ࡵ࠭ᇉ") in YYwjatHrFLils8DPZfmG6bX: ip = AoW1mDOpkbZw5F0nqNQKu[vvBChXmSty(u"ࠫ࡮ࡶࠧᇊ")]
			if CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴࠨᇋ") in YYwjatHrFLils8DPZfmG6bX: LLuWg4HJbUDjX1v = AoW1mDOpkbZw5F0nqNQKu[qnPgZ9N15G6Oa8UpMASvLk(u"࠭ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵࠩᇌ")]
			if PtXn0k9G3ocHRg(u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨᇍ") in YYwjatHrFLils8DPZfmG6bX: Hqe1swvhCVTM2jYWKya0xSAUnbp = AoW1mDOpkbZw5F0nqNQKu[JLoPRXt93dpAB(u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩᇎ")]
			if PtXn0k9G3ocHRg(u"ࠩࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥࠨᇏ") in YYwjatHrFLils8DPZfmG6bX: Oo814jC5Bx3QvNnPFH = AoW1mDOpkbZw5F0nqNQKu[yruHDQOcB97ig(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦࠩᇐ")]
			if iifPEY9ABNzTQp(u"ࠫࡷ࡫ࡧࡪࡱࡱࠫᇑ") in YYwjatHrFLils8DPZfmG6bX: bToL1eIWPGVFU4 = AoW1mDOpkbZw5F0nqNQKu[ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠬࡸࡥࡨ࡫ࡲࡲࠬᇒ")]
			if XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠭ࡣࡪࡶࡼࠫᇓ") in YYwjatHrFLils8DPZfmG6bX: EsHQmuDNS9I4g3njoAfWLORaTtdGiF = AoW1mDOpkbZw5F0nqNQKu[usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠧࡤ࡫ࡷࡽࠬᇔ")]
			if ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠨࡶ࡬ࡱࡪࢀ࡯࡯ࡧࠪᇕ") in YYwjatHrFLils8DPZfmG6bX:
				zwQuFoLAP2T8acYH6pl7vN1fr5D = AoW1mDOpkbZw5F0nqNQKu[n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠩࡷ࡭ࡲ࡫ࡺࡰࡰࡨࠫᇖ")][nKLEi8CJumazx4qT(u"ࠪࡹࡹࡩࠧᇗ")]
				if zwQuFoLAP2T8acYH6pl7vN1fr5D[InKG0i2r6hHDvgd(u"࠲ᙼ")] not in [PtXn0k9G3ocHRg(u"ࠫ࠲࠭ᇘ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠬ࠱ࠧᇙ")]: zwQuFoLAP2T8acYH6pl7vN1fr5D = usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠭ࠫࠨᇚ")+zwQuFoLAP2T8acYH6pl7vN1fr5D
			OOjM98q7XuSQl = ip+cgtRBdXxSOk7WUfyDhPCls(u"ࠧ࠭ࠩᇛ")+LLuWg4HJbUDjX1v+n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠨ࠮ࠪᇜ")+Hqe1swvhCVTM2jYWKya0xSAUnbp+drHLAY5ENQFe2q9ptKGabo(u"ࠩ࠯ࠫᇝ")+bToL1eIWPGVFU4+usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠪ࠰ࠬᇞ")+EsHQmuDNS9I4g3njoAfWLORaTtdGiF+cNaVb1vsT4qWOL0rpE(u"ࠫ࠱࠭ᇟ")+zwQuFoLAP2T8acYH6pl7vN1fr5D
			if VVGRN7xiyj: OOjM98q7XuSQl = OOjM98q7XuSQl.encode(iifPEY9ABNzTQp(u"ࠬࡻࡴࡧ࠺ࠪᇠ")).decode(BGhdkWsEvJjiMFTr3NLn1flU(u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧᇡ"))
	OOjM98q7XuSQl = ffbxegm1XPSqIwp8i(OOjM98q7XuSQl)
	return OOjM98q7XuSQl
def kh9lHs2cCOInRLBDJiofTVwSv6(lxSZ2ImUuAToy4FcEwPCbYXNk5qjHO):
	ocdTw4SeYv90r8kxzI,showDialogs = Tgoa16jMxvYX2(u"ࠧࠨᇢ"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࡘࡷࡻࡥ᜻")
	if lxSZ2ImUuAToy4FcEwPCbYXNk5qjHO.count(shZ9eOcN2dJnPj(u"ࠨࡡࠪᇣ"))>=usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠵ᙽ"):
		lxSZ2ImUuAToy4FcEwPCbYXNk5qjHO,ocdTw4SeYv90r8kxzI = lxSZ2ImUuAToy4FcEwPCbYXNk5qjHO.split(usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩࡢࠫᇤ"),bbw2eajMlG(u"࠵ᙾ"))
		ocdTw4SeYv90r8kxzI = CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠪࡣࠬᇥ")+ocdTw4SeYv90r8kxzI
		if JLoPRXt93dpAB(u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩᇦ") in ocdTw4SeYv90r8kxzI: showDialogs = InKG0i2r6hHDvgd(u"ࡋࡧ࡬ࡴࡧ᜼")
		else: showDialogs = xuztI5QWEKG70CPNdhk4vo6(u"࡚ࡲࡶࡧ᜽")
	return lxSZ2ImUuAToy4FcEwPCbYXNk5qjHO,ocdTw4SeYv90r8kxzI,showDialogs
def R1JETwpUnMuKXAh2Sl6vxOaF7():
	AuIMdgopB61q5C = k1t0JLRsCQ.path.join(b69iT7LWwrfXzGYPMvBCsteVHDQK,xuztI5QWEKG70CPNdhk4vo6(u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫᇧ"))
	rho4q6SYxUg0F = oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠵ᙿ")
	if k1t0JLRsCQ.path.exists(AuIMdgopB61q5C):
		for i60vZtVrPYoD in k1t0JLRsCQ.listdir(AuIMdgopB61q5C):
			if nKLEi8CJumazx4qT(u"࠭࠮ࡱࡻࡲࠫᇨ") in i60vZtVrPYoD: continue
			if cgtRBdXxSOk7WUfyDhPCls(u"ࠧࡠࡡࡳࡽࡨࡧࡣࡩࡧࡢࡣࠬᇩ") in i60vZtVrPYoD: continue
			mmig3SVutfToID1wq4NxPLMcvp8zRC = k1t0JLRsCQ.path.join(AuIMdgopB61q5C,i60vZtVrPYoD)
			Csy20FI6uMQ38cpR,tDlfOHiebr0MUx765c = FLTvHN0VMOGiZ29(mmig3SVutfToID1wq4NxPLMcvp8zRC)
			rho4q6SYxUg0F += Csy20FI6uMQ38cpR
	return rho4q6SYxUg0F
def b0jYpTOlAEoGF(EqVPHSM8fKuTaxh20WkNLd,showDialogs):
	A4MV6ouFKpQ2facewiDTqEPOZ9mnC5 = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭ᇪ"))
	cL0weimpJqOPRo2gQZ8S1VjXFG = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠩࡶࡸࡷ࠭ᇫ"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ᇬ"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭ᇭ"))
	m8qGBvVb5S,u4lpwnjTrOQ3h = A4MV6ouFKpQ2facewiDTqEPOZ9mnC5,cL0weimpJqOPRo2gQZ8S1VjXFG
	nemQDPUAIWjh5RMGk,FSR4hOmvVcoGJQgLjXnz8qyYUKk1iP = vvBChXmSty(u"ࠬ࠭ᇮ"),vvBChXmSty(u"࠭ࠧᇯ")
	if not EqVPHSM8fKuTaxh20WkNLd or not cL0weimpJqOPRo2gQZ8S1VjXFG or A4MV6ouFKpQ2facewiDTqEPOZ9mnC5 in [n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠧࠨᇰ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠨࡇࡕࡖࡔࡘࠧᇱ")]:
		GMfo7WypIsRin9HKEZQduYhDetFJOS = pgPfwZleTHVQ9a[ggDRehOModi(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩᇲ")][tZ3gsrTEdzA1S6LXa9WI5px(u"࠹ ")]
		hGdKt2jR8SN1z5TrZkuU = lbFixEt3BK9YGMyWIQZuSsp1V7JTL8(pcWq35MED2dtK(u"࠳࠳ᚁ"),EqVPHSM8fKuTaxh20WkNLd)
		OOjM98q7XuSQl = COnauLbjTwX31YoPgxNlcJ()
		Hqe1swvhCVTM2jYWKya0xSAUnbp = OOjM98q7XuSQl.split(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠪ࠰ࠬᇳ"))[Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠳ᚂ")]
		rho4q6SYxUg0F = R1JETwpUnMuKXAh2Sl6vxOaF7()
		gXFeIu3GW2vzkqyfQxw6lMiBcLHsU = {r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠫࡺࡹࡥࡳࠩᇴ"):hGdKt2jR8SN1z5TrZkuU,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭ᇵ"):qkSQU3saP0D7OvynNzH4F2BKJuilT,ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧᇶ"):Hqe1swvhCVTM2jYWKya0xSAUnbp,InKG0i2r6hHDvgd(u"ࠧࡪࡦࡶࠫᇷ"):ZAFhioq91YfduILWljSNxHDOB7(rho4q6SYxUg0F)}
		l3lOuS56hyIdjACkcweb1WDrHQgYfa = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,BGhdkWsEvJjiMFTr3NLn1flU(u"ࠨࡒࡒࡗ࡙࠭ᇸ"),GMfo7WypIsRin9HKEZQduYhDetFJOS,gXFeIu3GW2vzkqyfQxw6lMiBcLHsU,xuztI5QWEKG70CPNdhk4vo6(u"ࠩࠪᇹ"),bbw2eajMlG(u"ࠪࠫᇺ"),nKLEi8CJumazx4qT(u"ࠫࠬᇻ"),OyJ1o4AvmWlB75UkFRX(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡑࡊ࡙ࡓࡂࡉࡈࡗ࠲࠷ࡳࡵࠩᇼ"))
		if not l3lOuS56hyIdjACkcweb1WDrHQgYfa.succeeded: m8qGBvVb5S = xuztI5QWEKG70CPNdhk4vo6(u"࠭ࡅࡓࡔࡒࡖࠬᇽ")
		else:
			uKfIokeEaz = l3lOuS56hyIdjACkcweb1WDrHQgYfa.content
			uKfIokeEaz = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ(yF29Xdsx35wI07Ce4(u"ࠧ࡭࡫ࡶࡸࠬᇾ"),uKfIokeEaz)
			uKfIokeEaz = sorted(uKfIokeEaz,reverse=Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࡔࡳࡷࡨ᜾"),key=lambda key: int(key[n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠲ᚃ")]))
			FSR4hOmvVcoGJQgLjXnz8qyYUKk1iP,u4lpwnjTrOQ3h = Tgoa16jMxvYX2(u"ࠨࠩᇿ"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩࠪሀ")
			for uu7ynVjmbZxWkSsON,PLrkofcpDO6Q3WVhn,CWL8J3MFDRmtk029PKhsp6Zgbv in uKfIokeEaz:
				if uu7ynVjmbZxWkSsON==pcWq35MED2dtK(u"ࠪ࠴ࠬሁ"):
					FSR4hOmvVcoGJQgLjXnz8qyYUKk1iP += CWL8J3MFDRmtk029PKhsp6Zgbv+tZ3gsrTEdzA1S6LXa9WI5px(u"ࠫ࠿ࡀࠧሂ")
					continue
				if u4lpwnjTrOQ3h: u4lpwnjTrOQ3h += yF29Xdsx35wI07Ce4(u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࡠࡳ࠭ሃ")
				lZMci0ENnhYLryHFX = CWL8J3MFDRmtk029PKhsp6Zgbv.split(wwplD0tEehqH3kYQXs(u"࠭࡜࡯ࠩሄ"))[shZ9eOcN2dJnPj(u"࠳ᚄ")]
				ZZYWLruGiP8Vt3nzBs0UwSD = bcgZJWV6UeNSkRA(u"ࠧาีส่ฮࠦฮศืฬࠤ้้ࠠโไฺࠫህ") if PLrkofcpDO6Q3WVhn else yF29Xdsx35wI07Ce4(u"ࠨࠩሆ")
				u4lpwnjTrOQ3h += CWL8J3MFDRmtk029PKhsp6Zgbv.replace(lZMci0ENnhYLryHFX,cNaVb1vsT4qWOL0rpE(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬሇ")+lZMci0ENnhYLryHFX+ZZYWLruGiP8Vt3nzBs0UwSD+Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬለ"))+PtXn0k9G3ocHRg(u"ࠫࡡࡴࠧሉ")
			u4lpwnjTrOQ3h = cgtRBdXxSOk7WUfyDhPCls(u"ࠬࡢ࡮ࠨሊ")+u4lpwnjTrOQ3h+usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠭࡜࡯࡞ࡱࠫላ")
			FSR4hOmvVcoGJQgLjXnz8qyYUKk1iP = FSR4hOmvVcoGJQgLjXnz8qyYUKk1iP.strip(nKLEi8CJumazx4qT(u"ࠧ࠻࠼ࠪሌ"))
			nemQDPUAIWjh5RMGk = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠨࡣࡹ࠲ࡵࡸࡩࡷࡵࠪል"))
			if u4lpwnjTrOQ3h!=cL0weimpJqOPRo2gQZ8S1VjXFG or A4MV6ouFKpQ2facewiDTqEPOZ9mnC5 in [ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠩࠪሎ"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠪࡉࡗࡘࡏࡓࠩሏ")]: m8qGBvVb5S = shZ9eOcN2dJnPj(u"ࠫࡓࡋࡗࠨሐ")
			OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,KKbpxUZnMcj6AJ4QdD(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨሑ"),cgtRBdXxSOk7WUfyDhPCls(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨሒ"),u4lpwnjTrOQ3h,NVbfv48oh3M6U)
			LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(cgtRBdXxSOk7WUfyDhPCls(u"ࠧࡢࡸ࠱ࡴࡷ࡯ࡶࡴࠩሓ"),FSR4hOmvVcoGJQgLjXnz8qyYUKk1iP)
			LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩሔ"),ZAFhioq91YfduILWljSNxHDOB7(s8bXSagYdim62TwIpQzGtUqeLhA1J))
	if showDialogs:
		if m8qGBvVb5S==CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠩࡈࡖࡗࡕࡒࠨሕ"):
			xl9MFt1AmY0GrkENug8n(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠪࠫሖ"),vvBChXmSty(u"ࠫࠬሗ"),vvBChXmSty(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨመ"),InKG0i2r6hHDvgd(u"࠭็็ษๆࠤฺ๊ใๅหࠣๅ๏ࠦฬ่ษี็ࠥ๎็๋ࠢ็๎ุะࠠๆ่ࠣห้ฮั็ษ่ะࠥ࠴࠮้ࠡำ๋ࠥอไๆึๆ่ฮࠦโะࠢํ็ํ์ࠠิสห๋ฬࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅࠣวํࠦวๅำส์ฯืࠠศๆัหฺࠦศไࠢฦ์๋ࠥิไๆฬࠤๆ๐ࠠศๆฦื้อใࠡ฻้ำ่࠭ሙ"))
		else:
			RZo7IGjqXfiAnrWtlHcbNDuF9hP(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ሚ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠨำึหห๊ࠠๆ่ࠣห้๋ศา็ฯࠤส๊้ࠡ็ึฮำีๅ๋ࠢส่อืๆศ็ฯࠫማ"),u4lpwnjTrOQ3h,drHLAY5ENQFe2q9ptKGabo(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪሜ"))
			m8qGBvVb5S = KKbpxUZnMcj6AJ4QdD(u"ࠪࡓࡑࡊࠧም")
	if m8qGBvVb5S!=A4MV6ouFKpQ2facewiDTqEPOZ9mnC5:
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(OyJ1o4AvmWlB75UkFRX(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩሞ"),m8qGBvVb5S)
		bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(bbw2eajMlG(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩሟ"))
	AA8KSg59IphuYbzUG3syTknrMaV = JLoPRXt93dpAB(u"ࡖࡵࡹࡪᝀ") if FSR4hOmvVcoGJQgLjXnz8qyYUKk1iP!=nemQDPUAIWjh5RMGk else InKG0i2r6hHDvgd(u"ࡇࡣ࡯ࡷࡪ᜿")
	return AA8KSg59IphuYbzUG3syTknrMaV
def mVBR2YlHrT(j8K3TBfiH1GgXJmC,M3MzY0BOyDCSj1gPmIe6Rc):
	from socket import socket as mJNCKBxoGEw5X1tAfLOhgMivQzeI9c,AF_INET as U0ecS5D43xq1XngdI97rjVThBf8,SOCK_STREAM as ss4Y30c7iC
	F7ALO3mQs1a = mJNCKBxoGEw5X1tAfLOhgMivQzeI9c(U0ecS5D43xq1XngdI97rjVThBf8,ss4Y30c7iC)
	F7ALO3mQs1a.settimeout(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠵ᚅ"))
	Mpq961BPTAfkrC0t5,Dyrfa6WjgC8lGSNopmqMBQ = shZ9eOcN2dJnPj(u"ࡗࡶࡺ࡫ᝁ"),cNaVb1vsT4qWOL0rpE(u"࠵ᚆ")
	OlDEqB68KZdI5fsipUJzuavcn = YVJPFvuI2CS5KObiZt.time()
	try: F7ALO3mQs1a.connect((j8K3TBfiH1GgXJmC,M3MzY0BOyDCSj1gPmIe6Rc))
	except: Mpq961BPTAfkrC0t5 = cNaVb1vsT4qWOL0rpE(u"ࡊࡦࡲࡳࡦᝂ")
	vKqjFY4TE8lfuSdxUMz1aRc = YVJPFvuI2CS5KObiZt.time()
	if Mpq961BPTAfkrC0t5: Dyrfa6WjgC8lGSNopmqMBQ = vKqjFY4TE8lfuSdxUMz1aRc-OlDEqB68KZdI5fsipUJzuavcn
	return Dyrfa6WjgC8lGSNopmqMBQ
def tBUYedV3Q4FcLRwEx2DnMilz6(showDialogs):
	if showDialogs:
		iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(cgtRBdXxSOk7WUfyDhPCls(u"࠭ࠧሠ"),InKG0i2r6hHDvgd(u"ࠧࠨሡ"),wwplD0tEehqH3kYQXs(u"ࠨࠩሢ"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬሣ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠪืํ็๋ࠠไ๋้ࠥอไษำ้ห๊าࠠศๆล๊ࠥฮลึๆสัࠥ๎ส็ฺํๅࠥาๅ๋฻ࠣๆํอูะࠢส่อ๐ว็ษอࠤํอไไษืࠤฬ๊ๅิฬัำ๊ฯࠠโ์ࠣห้ฮั็ษ่ะࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢอุ฿๐ไࠡ฻่่๏ฯࠠศๆอ๊฽๐แࠡษ็ฦ๋ࠦฟࠢࠩሤ"))
	else: iZL6cN3OkM5 = vvBChXmSty(u"࡙ࡸࡵࡦᝃ")
	if iZL6cN3OkM5==OyJ1o4AvmWlB75UkFRX(u"࠷ᚇ"):
		for i60vZtVrPYoD in k1t0JLRsCQ.listdir(OxWkR7Eu9Pm3IAvTp0q):
			if i60vZtVrPYoD.endswith(yF29Xdsx35wI07Ce4(u"ࠫ࠳ࡪࡢࠨሥ")) and bcgZJWV6UeNSkRA(u"ࠬࡪࡡࡵࡣࠪሦ") in i60vZtVrPYoD:
				efpI3jkhR8bCtBXr = k1t0JLRsCQ.path.join(OxWkR7Eu9Pm3IAvTp0q,i60vZtVrPYoD)
				try: AO76Z1XEaSDjomRwK,BVYESNuJMxlmDo5WXdaFP6r = YWjf06dGFXDTm(efpI3jkhR8bCtBXr)
				except: return
				BVYESNuJMxlmDo5WXdaFP6r.execute(M6PIj8gl1fno7wcqTksDEBK4bU(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡩ࡯ࡶࡨ࡫ࡷ࡯ࡴࡺࡡࡦ࡬ࡪࡩ࡫࠼ࠩሧ"))
				BVYESNuJMxlmDo5WXdaFP6r.execute(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡰࡲࡷ࡭ࡲ࡯ࡺࡦ࠽ࠪረ"))
				BVYESNuJMxlmDo5WXdaFP6r.execute(wwplD0tEehqH3kYQXs(u"ࠨࡘࡄࡇ࡚࡛ࡍ࠼ࠩሩ"))
				AO76Z1XEaSDjomRwK.commit()
				AO76Z1XEaSDjomRwK.close()
		if showDialogs:
			xl9MFt1AmY0GrkENug8n(pcWq35MED2dtK(u"ࠩࠪሪ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠪࠫራ"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧሬ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠬะๅหࠢห๊ัออࠡ฻่่๏ฯࠠฦื็หา่ࠦห่฻๎ๆࠦฬๆ์฼ࠤ็๎วฺัࠣห้ฮ๊ศ่สฮࠥ๎วๅๅสุࠥอไๆีอาิ๋ษࠡใํࠤฬ๊ศา่ส้ั࠭ር"))
	return
def PPIXEhN6ofSZLVdJ2wRBHvKCMrx3u(kxgVEPbM4NHo2WDXcR0,YaOXCb0Z483NwgLVnPri,showDialogs):
	if kxgVEPbM4NHo2WDXcR0!=None:
		global rN2hcfHmuqXJgSy9pUIC
		rN2hcfHmuqXJgSy9pUIC = kxgVEPbM4NHo2WDXcR0
	if YaOXCb0Z483NwgLVnPri!=None:
		global JQFjAzhitdW8pHEw
		JQFjAzhitdW8pHEw = YaOXCb0Z483NwgLVnPri
	if showDialogs!=None:
		global gg4uMKYP1XlbE
		gg4uMKYP1XlbE = showDialogs
	return
rN2hcfHmuqXJgSy9pUIC,JQFjAzhitdW8pHEw,gg4uMKYP1XlbE = KKbpxUZnMcj6AJ4QdD(u"࠭ࠧሮ"),drHLAY5ENQFe2q9ptKGabo(u"ࠧࠨሯ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠨࠩሰ")
def uuv2D4mrsyY(Fu63RmidlUsQIgCcOypVYeo,GMfo7WypIsRin9HKEZQduYhDetFJOS,MNWrTo98GZHn,vSj57P0g4mF2Bp,ZAQPeI2BlmFr4MHR6agVtGWJjfsTL,showDialogs,BYGZC29KJ5Piag36Dl,ks3VNwMlLPIHt=r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠩࠪሱ"),AhpCS7wYsW3PO6Q9=pcWq35MED2dtK(u"ࠪࠫሲ")):
	global pgPfwZleTHVQ9a
	if showDialogs==vvBChXmSty(u"ࠫࠬሳ"): showDialogs = vvBChXmSty(u"࡚ࡲࡶࡧᝄ") if gg4uMKYP1XlbE==qnPgZ9N15G6Oa8UpMASvLk(u"ࠬ࠭ሴ") else gg4uMKYP1XlbE
	if AhpCS7wYsW3PO6Q9==XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠭ࠧስ"): AhpCS7wYsW3PO6Q9 = XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࡔࡳࡷࡨᝅ") if JQFjAzhitdW8pHEw==bbw2eajMlG(u"ࠧࠨሶ") else JQFjAzhitdW8pHEw
	if ks3VNwMlLPIHt==ggDRehOModi(u"ࠨࠩሷ"): ks3VNwMlLPIHt = n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࡕࡴࡸࡩᝆ") if rN2hcfHmuqXJgSy9pUIC==bcgZJWV6UeNSkRA(u"ࠩࠪሸ") else rN2hcfHmuqXJgSy9pUIC
	if ZAQPeI2BlmFr4MHR6agVtGWJjfsTL==xuztI5QWEKG70CPNdhk4vo6(u"ࠪࠫሹ"): aj0yB6Wi1M9fJTtz2wSxXuVvNL75YH = BGhdkWsEvJjiMFTr3NLn1flU(u"ࡖࡵࡹࡪᝇ")
	else: aj0yB6Wi1M9fJTtz2wSxXuVvNL75YH = ZAQPeI2BlmFr4MHR6agVtGWJjfsTL
	if MNWrTo98GZHn==None: XfOb4VIcPY = None
	elif MNWrTo98GZHn==yruHDQOcB97ig(u"ࠫࠬሺ"): XfOb4VIcPY = {}
	else: XfOb4VIcPY = MNWrTo98GZHn
	if vSj57P0g4mF2Bp==None: emrzEIsMWO2GLw9lpKxSY7n0F = None
	elif vSj57P0g4mF2Bp==ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠬ࠭ሻ"): emrzEIsMWO2GLw9lpKxSY7n0F = {}
	else: emrzEIsMWO2GLw9lpKxSY7n0F = vSj57P0g4mF2Bp
	Wnfp3FPL5M0eyc1xKVAYNm = list(emrzEIsMWO2GLw9lpKxSY7n0F.keys())
	if vvBChXmSty(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪሼ") not in Wnfp3FPL5M0eyc1xKVAYNm: emrzEIsMWO2GLw9lpKxSY7n0F[bcgZJWV6UeNSkRA(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫሽ")] = cNaVb1vsT4qWOL0rpE(u"ࠨࡂࡃࡄࡘࡑࡉࡑࡡࡋࡉࡆࡊࡅࡓࡂࡃࡄࠬሾ")
	gANn35esloKUydOipfSMC6RD2,UdvjsK7fcmtokh8z,G9OmMTVLjrK5su6Yvt8XUx,MsqPuhEKTC39NDwxZd = rRjtH4UFBNVayeEYwl6dobvg(GMfo7WypIsRin9HKEZQduYhDetFJOS)
	b409vpr8PJYsiZaOxRdVko = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(Tgoa16jMxvYX2(u"ࠩࡤࡺ࠳ࡪ࡮ࡴࠩሿ"))
	JGfwh16Q4pYj3saRHZFiTeVNoW = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(OyJ1o4AvmWlB75UkFRX(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ቀ"))
	XmfRZkAC8K3VnH75 = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(iifPEY9ABNzTQp(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩቁ"))
	sLRJdtUwiNMO6b4 = (UdvjsK7fcmtokh8z==None and G9OmMTVLjrK5su6Yvt8XUx==None)
	SuCZ9ILlw25fNzPxsbcKnmv8 = pgPfwZleTHVQ9a[pcWq35MED2dtK(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬቂ")]
	eeNKmOawtoDfS34bX = gANn35esloKUydOipfSMC6RD2 in SuCZ9ILlw25fNzPxsbcKnmv8
	tKqy7TNuFwb = pgPfwZleTHVQ9a[PtXn0k9G3ocHRg(u"࠭ࡒࡆࡒࡒࡗࠬቃ")]
	uoHhFmrYByGRJgPkteV0IUsE6jSAX5 = gANn35esloKUydOipfSMC6RD2 in tKqy7TNuFwb
	tRxVyNPf2gp1Gkm3ECU8naA = eeNKmOawtoDfS34bX or uoHhFmrYByGRJgPkteV0IUsE6jSAX5
	if sLRJdtUwiNMO6b4 and tRxVyNPf2gp1Gkm3ECU8naA:
		if eeNKmOawtoDfS34bX:
			PvoWTV5GKcLrtl1QAbmDd9z3RJMS = SuCZ9ILlw25fNzPxsbcKnmv8.index(gANn35esloKUydOipfSMC6RD2)
			lWtT7XHdmFPpo4csEOZAU = pgPfwZleTHVQ9a[nKLEi8CJumazx4qT(u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓࠫቄ")][PvoWTV5GKcLrtl1QAbmDd9z3RJMS]
			saX7exkw84EhcH2Cl01M6SURVfzFnT = XzTni23psbetOyYc6HlGWBJgPmk5[PvoWTV5GKcLrtl1QAbmDd9z3RJMS]
		elif uoHhFmrYByGRJgPkteV0IUsE6jSAX5:
			PvoWTV5GKcLrtl1QAbmDd9z3RJMS = tKqy7TNuFwb.index(gANn35esloKUydOipfSMC6RD2)
			lWtT7XHdmFPpo4csEOZAU = pgPfwZleTHVQ9a[bbw2eajMlG(u"ࠨࡔࡈࡔࡔ࡙࡟ࡃࡍࡓࠫቅ")][PvoWTV5GKcLrtl1QAbmDd9z3RJMS]
			saX7exkw84EhcH2Cl01M6SURVfzFnT = sCXWyTFOq4fdm[PvoWTV5GKcLrtl1QAbmDd9z3RJMS]
	if G9OmMTVLjrK5su6Yvt8XUx==nKLEi8CJumazx4qT(u"ࠩࠪቆ"): G9OmMTVLjrK5su6Yvt8XUx = b409vpr8PJYsiZaOxRdVko
	elif G9OmMTVLjrK5su6Yvt8XUx==None and JGfwh16Q4pYj3saRHZFiTeVNoW in [oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠪࡅ࡚࡚ࡏࠨቇ"),wwplD0tEehqH3kYQXs(u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭ቈ")] and ks3VNwMlLPIHt: G9OmMTVLjrK5su6Yvt8XUx = b409vpr8PJYsiZaOxRdVko
	bbVLR29yMreaskmU = gANn35esloKUydOipfSMC6RD2==pgPfwZleTHVQ9a[pcWq35MED2dtK(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ቉")][iifPEY9ABNzTQp(u"࠷ᚈ")]
	ClcvkWVg3BRHI = UdvjsK7fcmtokh8z and XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠭ࡳࡤࡴࡤࡴࡪ࠭ቊ") in UdvjsK7fcmtokh8z
	if ClcvkWVg3BRHI: pKOBP5j4yJQIxsUENle9VR2YDwT = tZ3gsrTEdzA1S6LXa9WI5px(u"࠷࠲ᚉ")
	elif eeNKmOawtoDfS34bX or uoHhFmrYByGRJgPkteV0IUsE6jSAX5: pKOBP5j4yJQIxsUENle9VR2YDwT = ggDRehOModi(u"࠳࠸ᚊ")
	elif BYGZC29KJ5Piag36Dl in Rrwi83IBX0D2hEkmWOGa51A: pKOBP5j4yJQIxsUENle9VR2YDwT = iifPEY9ABNzTQp(u"࠴࠴ᚋ")
	elif BYGZC29KJ5Piag36Dl==ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈ࡚ࡊࡘࡓࡐࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩቋ"): pKOBP5j4yJQIxsUENle9VR2YDwT = bbw2eajMlG(u"࠶࠵ᚌ")
	elif BYGZC29KJ5Piag36Dl==PtXn0k9G3ocHRg(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩቌ"): pKOBP5j4yJQIxsUENle9VR2YDwT = ggDRehOModi(u"࠷࠶ᚍ")
	elif ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡘࡃࡐࠫቍ") in BYGZC29KJ5Piag36Dl: pKOBP5j4yJQIxsUENle9VR2YDwT = bbw2eajMlG(u"࠽࠰ᚎ")
	elif bbw2eajMlG(u"ࠪࡗࡍࡕࡆࡉࡃࠪ቎") in BYGZC29KJ5Piag36Dl: pKOBP5j4yJQIxsUENle9VR2YDwT = oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠷࠶ᚏ")
	elif wwplD0tEehqH3kYQXs(u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ቏") in BYGZC29KJ5Piag36Dl: pKOBP5j4yJQIxsUENle9VR2YDwT = nKLEi8CJumazx4qT(u"࠳࠷ᚐ")
	elif M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠬࡇࡈࡘࡃࡎࠫቐ") in BYGZC29KJ5Piag36Dl: pKOBP5j4yJQIxsUENle9VR2YDwT = PtXn0k9G3ocHRg(u"࠴࠳ᚑ")
	elif InKG0i2r6hHDvgd(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩቑ") in BYGZC29KJ5Piag36Dl: pKOBP5j4yJQIxsUENle9VR2YDwT = pcWq35MED2dtK(u"࠵࠴ᚒ")
	elif iifPEY9ABNzTQp(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭ቒ") in BYGZC29KJ5Piag36Dl: pKOBP5j4yJQIxsUENle9VR2YDwT = bcgZJWV6UeNSkRA(u"࠷࠵ᚓ")
	elif PtXn0k9G3ocHRg(u"ࠨࡃࡎࡓࡆࡓࠧቓ") in BYGZC29KJ5Piag36Dl: pKOBP5j4yJQIxsUENle9VR2YDwT = Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠷࠻ᚔ")
	elif bbw2eajMlG(u"ࠩࡄࡏ࡜ࡇࡍࠨቔ") in BYGZC29KJ5Piag36Dl: pKOBP5j4yJQIxsUENle9VR2YDwT = r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠹࠰ᚕ")
	elif nKLEi8CJumazx4qT(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬቕ") in BYGZC29KJ5Piag36Dl: pKOBP5j4yJQIxsUENle9VR2YDwT = shZ9eOcN2dJnPj(u"࠲࠱ᚖ")
	elif vvBChXmSty(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠭ቖ") in BYGZC29KJ5Piag36Dl: pKOBP5j4yJQIxsUENle9VR2YDwT = tZ3gsrTEdzA1S6LXa9WI5px(u"࠷࠲ᚗ")
	else: pKOBP5j4yJQIxsUENle9VR2YDwT = pcWq35MED2dtK(u"࠳࠸ᚘ")
	if bbw2eajMlG(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ቗") in BYGZC29KJ5Piag36Dl and not XfOb4VIcPY and M6PIj8gl1fno7wcqTksDEBK4bU(u"࠭ࠦࠨቘ") not in gANn35esloKUydOipfSMC6RD2 and Tgoa16jMxvYX2(u"ࠧࡀࠩ቙") not in gANn35esloKUydOipfSMC6RD2: gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2.rstrip(M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠨ࠱ࠪቚ"))+ggDRehOModi(u"ࠩ࠲ࠫቛ")
	zziIpFWDlkvnsM4wKaZV58EU = (UdvjsK7fcmtokh8z!=None)
	lMS6LIwNv8qPQE = (G9OmMTVLjrK5su6Yvt8XUx!=None and JGfwh16Q4pYj3saRHZFiTeVNoW!=tZ3gsrTEdzA1S6LXa9WI5px(u"ࠪࡗ࡙ࡕࡐࠨቜ"))
	if zziIpFWDlkvnsM4wKaZV58EU and not ClcvkWVg3BRHI: dnS80F92qtLi4vw1(InKG0i2r6hHDvgd(u"ࠫฯ็ู๋ๆࠣฬึ๎ใิ์ࠣี็๋ࠧቝ"),UdvjsK7fcmtokh8z)
	elif lMS6LIwNv8qPQE: dnS80F92qtLi4vw1(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠬะแฺ์็ࠤࡉࡔࡓࠡำๅ้ࠬ቞"),G9OmMTVLjrK5su6Yvt8XUx)
	if zziIpFWDlkvnsM4wKaZV58EU:
		HbKyS4dCBvEo = {CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠨࡨࡵࡶࡳࠦ቟"):UdvjsK7fcmtokh8z,JLoPRXt93dpAB(u"ࠢࡩࡶࡷࡴࡸࠨበ"):UdvjsK7fcmtokh8z}
		UQY02Sp1R8EhXIN5ykd4Wn = UdvjsK7fcmtokh8z
	else: HbKyS4dCBvEo,UQY02Sp1R8EhXIN5ykd4Wn = {},JLoPRXt93dpAB(u"ࠨࠩቡ")
	if lMS6LIwNv8qPQE:
		import urllib3.util.connection as zT19EnD4McGxWr3YwBa
		eoQKMv8XSL = KEB3dTbiq6XhM8OuxAPl0H9Ynoz2F(zT19EnD4McGxWr3YwBa,b409vpr8PJYsiZaOxRdVko)
	lIsjcHAEpJvxeu73z1nyrY8RD2,GLlgdCvO48Y,QGFHpjRbqDSnIaL4y3CW,p3w25qr7TMWa,Pa3AqSVL9ZXRDQ,verify = aj0yB6Wi1M9fJTtz2wSxXuVvNL75YH,BYGZC29KJ5Piag36Dl,Fu63RmidlUsQIgCcOypVYeo,oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࡉࡥࡱࡹࡥᝈ"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࡉࡥࡱࡹࡥᝈ"),MsqPuhEKTC39NDwxZd
	if bbVLR29yMreaskmU: Pa3AqSVL9ZXRDQ = yruHDQOcB97ig(u"ࡘࡷࡻࡥᝉ")
	if tRxVyNPf2gp1Gkm3ECU8naA or aj0yB6Wi1M9fJTtz2wSxXuVvNL75YH: lIsjcHAEpJvxeu73z1nyrY8RD2 = ggDRehOModi(u"ࡋࡧ࡬ࡴࡧᝊ")
	if eeNKmOawtoDfS34bX: QGFHpjRbqDSnIaL4y3CW = yF29Xdsx35wI07Ce4(u"ࠩࡓࡓࡘ࡚ࠧቢ")
	xIj15Wv4h9fOnX,rreason = -ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠴ᚙ"),drHLAY5ENQFe2q9ptKGabo(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤࡊࡸࡲࡰࡴࠪባ")
	for k0G4LTYt93po in range(JLoPRXt93dpAB(u"࠽ᚚ")):
		TAkdOX8HoQawZ = vvBChXmSty(u"࡚ࡲࡶࡧᝋ")
		V5VXz0j3oa6t = oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࡆࡢ࡮ࡶࡩᝌ")
		try:
			if k0G4LTYt93po: GLlgdCvO48Y = Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓ࠮࠳ࡶࡸࠬቤ")
			if ClcvkWVg3BRHI or not zziIpFWDlkvnsM4wKaZV58EU: u5VpIfdK9HTnYk(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠬࡘࡅࡒࡗࡈࡗ࡙࡙ࠠࠡࡑࡓࡉࡓࡥࡕࡓࡎࠪብ"),gANn35esloKUydOipfSMC6RD2,XfOb4VIcPY,emrzEIsMWO2GLw9lpKxSY7n0F,GLlgdCvO48Y,QGFHpjRbqDSnIaL4y3CW)
			try: l3lOuS56hyIdjACkcweb1WDrHQgYfa.close()
			except: pass
			UcmHDPlLWaSf = gANn35esloKUydOipfSMC6RD2
			l3lOuS56hyIdjACkcweb1WDrHQgYfa = RduBx91EMtZDLn.request(QGFHpjRbqDSnIaL4y3CW,gANn35esloKUydOipfSMC6RD2,data=XfOb4VIcPY,headers=emrzEIsMWO2GLw9lpKxSY7n0F,verify=verify,allow_redirects=lIsjcHAEpJvxeu73z1nyrY8RD2,timeout=pKOBP5j4yJQIxsUENle9VR2YDwT,proxies=HbKyS4dCBvEo)
			if ggDRehOModi(u"࠸࠶࠰᚛")<=l3lOuS56hyIdjACkcweb1WDrHQgYfa.status_code<=nKLEi8CJumazx4qT(u"࠹࠹࠺᚜"):
				if not p3w25qr7TMWa:
					p38M9T17BfnwKcrhy = list(l3lOuS56hyIdjACkcweb1WDrHQgYfa.headers.keys())
					if xuztI5QWEKG70CPNdhk4vo6(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨቦ") in p38M9T17BfnwKcrhy: gANn35esloKUydOipfSMC6RD2 = l3lOuS56hyIdjACkcweb1WDrHQgYfa.headers[XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩቧ")]
					elif cgtRBdXxSOk7WUfyDhPCls(u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠪቨ") in p38M9T17BfnwKcrhy: gANn35esloKUydOipfSMC6RD2 = l3lOuS56hyIdjACkcweb1WDrHQgYfa.headers[Tgoa16jMxvYX2(u"ࠩ࡯ࡳࡨࡧࡴࡪࡱࡱࠫቩ")]
					else: p3w25qr7TMWa = ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࡕࡴࡸࡩᝍ")
					if not p3w25qr7TMWa: gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2.encode(JLoPRXt93dpAB(u"ࠪࡰࡦࡺࡩ࡯࠯࠴ࠫቪ"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫቫ")).decode(JLoPRXt93dpAB(u"ࠬࡻࡴࡧ࠺ࠪቬ"),InKG0i2r6hHDvgd(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ቭ"))
					if tRxVyNPf2gp1Gkm3ECU8naA and l3lOuS56hyIdjACkcweb1WDrHQgYfa.status_code==Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠳࠱࠹᚝"):
						lIsjcHAEpJvxeu73z1nyrY8RD2 = aj0yB6Wi1M9fJTtz2wSxXuVvNL75YH
						QGFHpjRbqDSnIaL4y3CW = Fu63RmidlUsQIgCcOypVYeo
						p3w25qr7TMWa = KKbpxUZnMcj6AJ4QdD(u"ࡖࡵࡹࡪᝎ")
						TM8cVOS9Ba
				if not p3w25qr7TMWa or aj0yB6Wi1M9fJTtz2wSxXuVvNL75YH:
					if shZ9eOcN2dJnPj(u"ࠧࡩࡶࡷࡴࠬቮ") not in gANn35esloKUydOipfSMC6RD2:
						Fb57I1fr9EYSgOQ60UoksjHL83y = hmcFWJUgiAuGk(UcmHDPlLWaSf,yruHDQOcB97ig(u"ࠨࡷࡵࡰࠬቯ"))
						gANn35esloKUydOipfSMC6RD2 = Fb57I1fr9EYSgOQ60UoksjHL83y+cNaVb1vsT4qWOL0rpE(u"ࠩ࠲ࠫተ")+gANn35esloKUydOipfSMC6RD2.lstrip(wwplD0tEehqH3kYQXs(u"ࠪ࠳ࠬቱ"))
				if not p3w25qr7TMWa and aj0yB6Wi1M9fJTtz2wSxXuVvNL75YH and not XS8G7Ljnkut(gANn35esloKUydOipfSMC6RD2): k1QJEizZ49s8nY3PRCmN
			elif ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠷࠸࠴᚟")<=l3lOuS56hyIdjACkcweb1WDrHQgYfa.status_code<=oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠶࠻࠼᚞"):
				l3lOuS56hyIdjACkcweb1WDrHQgYfa.rreason = l3lOuS56hyIdjACkcweb1WDrHQgYfa.content
				Pa3AqSVL9ZXRDQ = M6PIj8gl1fno7wcqTksDEBK4bU(u"ࡗࡶࡺ࡫ᝏ")
			UcmHDPlLWaSf = l3lOuS56hyIdjACkcweb1WDrHQgYfa.url
			xIj15Wv4h9fOnX = l3lOuS56hyIdjACkcweb1WDrHQgYfa.status_code
			rreason = l3lOuS56hyIdjACkcweb1WDrHQgYfa.reason
			l3lOuS56hyIdjACkcweb1WDrHQgYfa.raise_for_status()
			V5VXz0j3oa6t = Tgoa16jMxvYX2(u"ࡘࡷࡻࡥᝐ")
		except RduBx91EMtZDLn.exceptions.HTTPError as PqOkienNW3ToVcX1ZM8Q:
			pass
		except RduBx91EMtZDLn.exceptions.Timeout as PqOkienNW3ToVcX1ZM8Q:
			if bdptXFc8UlIhA5jnGwPmKuv2L: rreason = str(PqOkienNW3ToVcX1ZM8Q.message).split(yruHDQOcB97ig(u"ࠫ࠿ࠦࠧቲ"))[usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠴ᚠ")]
			else: rreason = str(PqOkienNW3ToVcX1ZM8Q).split(cNaVb1vsT4qWOL0rpE(u"ࠬࡀࠠࠨታ"))[XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠵ᚡ")]
		except RduBx91EMtZDLn.exceptions.ConnectionError as PqOkienNW3ToVcX1ZM8Q:
			try:
				lHqTf6UMy5pvbe0nK = PqOkienNW3ToVcX1ZM8Q.message[xuztI5QWEKG70CPNdhk4vo6(u"࠵ᚢ")]
				rreason = lHqTf6UMy5pvbe0nK
				if PtXn0k9G3ocHRg(u"࠭ࡅࡳࡴࡱࡳࠬቴ") in lHqTf6UMy5pvbe0nK: xIj15Wv4h9fOnX,rreason = u5h2Rckvw1E.findall(cNaVb1vsT4qWOL0rpE(u"ࠢ࡝࡝ࡈࡶࡷࡴ࡯ࠡࠪ࡟ࡨ࠰࠯࡜࡞ࠢࠫ࠲࠯ࡅࠩࠨࠤት"),lHqTf6UMy5pvbe0nK)[nKLEi8CJumazx4qT(u"࠶ᚣ")]
				elif pcWq35MED2dtK(u"ࠨ࠮ࠣࡩࡷࡸ࡯ࡳࠪࠪቶ") in lHqTf6UMy5pvbe0nK: xIj15Wv4h9fOnX,rreason = u5h2Rckvw1E.findall(bbw2eajMlG(u"ࠤ࠯ࠤࡪࡸࡲࡰࡴ࡟ࠬ࠭ࡢࡤࠬࠫ࠯ࠤࠬ࠮࠮ࠫࡁࠬࠫࠧቷ"),lHqTf6UMy5pvbe0nK)[r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠰ᚤ")]
				elif lHqTf6UMy5pvbe0nK.count(xuztI5QWEKG70CPNdhk4vo6(u"ࠪ࠾ࠬቸ"))>=nKLEi8CJumazx4qT(u"࠴ᚦ"): rreason,xIj15Wv4h9fOnX = u5h2Rckvw1E.findall(BGhdkWsEvJjiMFTr3NLn1flU(u"ࠫ࠿ࠦࠨ࠯ࠬࡂ࠭࠿࠴ࠪࡀࠪ࡟ࡨ࠰࠯ࠧቹ"),lHqTf6UMy5pvbe0nK)[r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠱ᚥ")]
			except: pass
		except RduBx91EMtZDLn.exceptions.RequestException as PqOkienNW3ToVcX1ZM8Q:
			if bdptXFc8UlIhA5jnGwPmKuv2L: rreason = PqOkienNW3ToVcX1ZM8Q.message
			else: rreason = str(PqOkienNW3ToVcX1ZM8Q)
		except:
			TAkdOX8HoQawZ = cNaVb1vsT4qWOL0rpE(u"ࡋࡧ࡬ࡴࡧᝑ")
			try: xIj15Wv4h9fOnX = l3lOuS56hyIdjACkcweb1WDrHQgYfa.status_code
			except: pass
			try: rreason = l3lOuS56hyIdjACkcweb1WDrHQgYfa.reason
			except: pass
		rreason = str(rreason)
		l0SAerv8zGH2Wa(ggDRehOModi(u"ࠬࡔࡏࡕࡋࡆࡉࠬቺ"),tZ3gsrTEdzA1S6LXa9WI5px(u"࠭࠮ࠡࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠥࠦࡒࡆࡕࡓࡓࡓ࡙ࡅࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫቻ")+str(xIj15Wv4h9fOnX)+bcgZJWV6UeNSkRA(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩቼ")+rreason+xuztI5QWEKG70CPNdhk4vo6(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪች")+BYGZC29KJ5Piag36Dl+M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨቾ")+GMfo7WypIsRin9HKEZQduYhDetFJOS+XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠪࠤࡢ࠭ቿ"))
		if sLRJdtUwiNMO6b4 and tRxVyNPf2gp1Gkm3ECU8naA and TAkdOX8HoQawZ and not Pa3AqSVL9ZXRDQ and xIj15Wv4h9fOnX!=ggDRehOModi(u"࠵࠴࠵ᚧ"):
			gANn35esloKUydOipfSMC6RD2 = lWtT7XHdmFPpo4csEOZAU
			Pa3AqSVL9ZXRDQ = shZ9eOcN2dJnPj(u"࡚ࡲࡶࡧᝒ")
			continue
		if TAkdOX8HoQawZ: break
	if G9OmMTVLjrK5su6Yvt8XUx!=None and JGfwh16Q4pYj3saRHZFiTeVNoW!=OyJ1o4AvmWlB75UkFRX(u"ࠫࡘ࡚ࡏࡑࠩኀ"): zT19EnD4McGxWr3YwBa.create_connection = eoQKMv8XSL
	if JGfwh16Q4pYj3saRHZFiTeVNoW==cgtRBdXxSOk7WUfyDhPCls(u"ࠬࡇࡌࡘࡃ࡜ࡗࠬኁ") and ks3VNwMlLPIHt: G9OmMTVLjrK5su6Yvt8XUx = None
	if not V5VXz0j3oa6t and UdvjsK7fcmtokh8z==None and BYGZC29KJ5Piag36Dl not in Rrwi83IBX0D2hEkmWOGa51A:
		LdvB61qxSDsOWlhmXnAgozEfPp4Ky = BPSEU6WvQRnxV.format_exc()
		if LdvB61qxSDsOWlhmXnAgozEfPp4Ky!=OyJ1o4AvmWlB75UkFRX(u"࠭ࡎࡰࡰࡨࡘࡾࡶࡥ࠻ࠢࡑࡳࡳ࡫࡜࡯ࠩኂ"): vdo2FnhPmAVRMJQZ0EIG8.stderr.write(LdvB61qxSDsOWlhmXnAgozEfPp4Ky)
	p8HVUxN5v3WZfF4Gt7o0gLOdSiI = fZio7hAJNCV1stDnvWaQX0cLFjwqHS()
	p8HVUxN5v3WZfF4Gt7o0gLOdSiI.url = UcmHDPlLWaSf
	try: wE6UaNgRu0dCjMPXD = l3lOuS56hyIdjACkcweb1WDrHQgYfa.content
	except: wE6UaNgRu0dCjMPXD = Tgoa16jMxvYX2(u"ࠧࠨኃ")
	try: icl3UZqswuGLIHaPyQfjJh2Wp51V = l3lOuS56hyIdjACkcweb1WDrHQgYfa.headers
	except: icl3UZqswuGLIHaPyQfjJh2Wp51V = {}
	try: Jlr5ojiYzpqM4Fa = l3lOuS56hyIdjACkcweb1WDrHQgYfa.cookies.get_dict()
	except: Jlr5ojiYzpqM4Fa = {}
	try: l3lOuS56hyIdjACkcweb1WDrHQgYfa.close()
	except: pass
	if VVGRN7xiyj:
		try: wE6UaNgRu0dCjMPXD = wE6UaNgRu0dCjMPXD.decode(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠨࡷࡷࡪ࠽࠭ኄ"))
		except: pass
	xIj15Wv4h9fOnX = int(xIj15Wv4h9fOnX)
	p8HVUxN5v3WZfF4Gt7o0gLOdSiI.code = xIj15Wv4h9fOnX
	p8HVUxN5v3WZfF4Gt7o0gLOdSiI.reason = rreason
	p8HVUxN5v3WZfF4Gt7o0gLOdSiI.content = wE6UaNgRu0dCjMPXD
	p8HVUxN5v3WZfF4Gt7o0gLOdSiI.headers = icl3UZqswuGLIHaPyQfjJh2Wp51V
	p8HVUxN5v3WZfF4Gt7o0gLOdSiI.cookies = Jlr5ojiYzpqM4Fa
	p8HVUxN5v3WZfF4Gt7o0gLOdSiI.succeeded = V5VXz0j3oa6t
	if bdptXFc8UlIhA5jnGwPmKuv2L or isinstance(p8HVUxN5v3WZfF4Gt7o0gLOdSiI.content,str): t7CNYov10qn6IVQhjJgPwiEdFz9rR = p8HVUxN5v3WZfF4Gt7o0gLOdSiI.content.lower()
	else: t7CNYov10qn6IVQhjJgPwiEdFz9rR = JLoPRXt93dpAB(u"ࠩࠪኅ")
	m0whqS5EkyiTjOIpvKZPM87r6 = (yF29Xdsx35wI07Ce4(u"ࠪࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧኆ") in t7CNYov10qn6IVQhjJgPwiEdFz9rR or KKbpxUZnMcj6AJ4QdD(u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࠫኇ") in t7CNYov10qn6IVQhjJgPwiEdFz9rR) and t7CNYov10qn6IVQhjJgPwiEdFz9rR.count(usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡࠨኈ"))>vvBChXmSty(u"࠶ᚨ") and bcgZJWV6UeNSkRA(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨ኉") not in BYGZC29KJ5Piag36Dl and OyJ1o4AvmWlB75UkFRX(u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠰ࡸࡴࡱࡥ࡯ࠩኊ") not in t7CNYov10qn6IVQhjJgPwiEdFz9rR and not ClcvkWVg3BRHI
	if xIj15Wv4h9fOnX==cNaVb1vsT4qWOL0rpE(u"࠷࠶࠰ᚩ") and m0whqS5EkyiTjOIpvKZPM87r6: p8HVUxN5v3WZfF4Gt7o0gLOdSiI.succeeded = ggDRehOModi(u"ࡆࡢ࡮ࡶࡩᝓ")
	if p8HVUxN5v3WZfF4Gt7o0gLOdSiI.succeeded and sLRJdtUwiNMO6b4 and tRxVyNPf2gp1Gkm3ECU8naA:
		if bbVLR29yMreaskmU: saX7exkw84EhcH2Cl01M6SURVfzFnT = InKG0i2r6hHDvgd(u"ࠨࡅࡄࡔ࡙ࡉࡈࡂࠩኋ")+XfOb4VIcPY[CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠩ࡭ࡳࡧ࠭ኌ")].upper().replace(JLoPRXt93dpAB(u"ࠪࡋࡊ࡚ࠧኍ"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠫࠬ኎"))
		BB3L0UYDEvif = sLY7qyAOM6zCSv(saX7exkw84EhcH2Cl01M6SURVfzFnT)
	if not p8HVUxN5v3WZfF4Gt7o0gLOdSiI.succeeded and sLRJdtUwiNMO6b4:
		tAEPZIX3RKJul4V7 = (M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠬࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩ኏") in t7CNYov10qn6IVQhjJgPwiEdFz9rR and yF29Xdsx35wI07Ce4(u"࠭ࡲࡢࡻࠣ࡭ࡩࡀࠠࠨነ") in t7CNYov10qn6IVQhjJgPwiEdFz9rR)
		TTPzNluhU1LenVJoG6swCi = (qnPgZ9N15G6Oa8UpMASvLk(u"ࠧ࠶ࠢࡶࡩࡨ࠭ኑ") in t7CNYov10qn6IVQhjJgPwiEdFz9rR and iifPEY9ABNzTQp(u"ࠨࡤࡵࡳࡼࡹࡥࡳࠩኒ") in t7CNYov10qn6IVQhjJgPwiEdFz9rR)
		PW7QmYC6ptBHFLV21DOMZ9ybvcAGE = (xIj15Wv4h9fOnX in [cgtRBdXxSOk7WUfyDhPCls(u"࠺࠰࠴ᚪ")] and shZ9eOcN2dJnPj(u"ࠩࡨࡶࡷࡵࡲࠡࡥࡲࡨࡪࡀࠠ࠲࠲࠵࠴ࠬና") in t7CNYov10qn6IVQhjJgPwiEdFz9rR)
		anp2wfGmuKU7S1 = (ggDRehOModi(u"ࠪࡣࡨ࡬࡟ࡤࡪ࡯ࡣࠬኔ") in t7CNYov10qn6IVQhjJgPwiEdFz9rR and KKbpxUZnMcj6AJ4QdD(u"ࠫࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࠭ࠨን") in t7CNYov10qn6IVQhjJgPwiEdFz9rR)
		if   m0whqS5EkyiTjOIpvKZPM87r6: rreason = yruHDQOcB97ig(u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡵࡩࡨࡧࡰࡵࡥ࡫ࡥࠬኖ")
		elif tAEPZIX3RKJul4V7: rreason = M6PIj8gl1fno7wcqTksDEBK4bU(u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧኗ")
		elif TTPzNluhU1LenVJoG6swCi: rreason = XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤ࠺ࠦࡳࡦࡥࡲࡲࡩࡹࠠࡣࡴࡲࡻࡸ࡫ࡲࠡࡥ࡫ࡩࡨࡱࠧኘ")
		elif PW7QmYC6ptBHFLV21DOMZ9ybvcAGE: rreason = BGhdkWsEvJjiMFTr3NLn1flU(u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠢࡤࡧࡨ࡫ࡳࡴࠢࡧࡩࡳ࡯ࡥࡥࠩኙ")
		elif anp2wfGmuKU7S1: rreason = yruHDQOcB97ig(u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠣࡷࡪࡩࡵࡳ࡫ࡷࡽࠥࡩࡨࡦࡥ࡮ࠫኚ")
		else: rreason = str(rreason)
		if BYGZC29KJ5Piag36Dl in CUqMFh49o5xjl: pass
		elif BYGZC29KJ5Piag36Dl in Rrwi83IBX0D2hEkmWOGa51A:
			l0SAerv8zGH2Wa(bcgZJWV6UeNSkRA(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩኛ"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+yF29Xdsx35wI07Ce4(u"ࠫࠥࠦࡄࡪࡴࡨࡧࡹࠦࡣࡰࡰࡱࡩࡨࡺࡩࡰࡰࠣࡪࡦ࡯࡬ࡦࡦࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧኜ")+str(xIj15Wv4h9fOnX)+iifPEY9ABNzTQp(u"ࠬࠦ࡝ࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭ኝ")+rreason+bbw2eajMlG(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨኞ")+BYGZC29KJ5Piag36Dl+wwplD0tEehqH3kYQXs(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ኟ")+gANn35esloKUydOipfSMC6RD2+XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠨࠢࡠࠫአ"))
		else: l0SAerv8zGH2Wa(OyJ1o4AvmWlB75UkFRX(u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧኡ"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠪࠤࠥࠦࡄࡪࡴࡨࡧࡹࠦࡣࡰࡰࡱࡩࡨࡺࡩࡰࡰࠣࡪࡦ࡯࡬ࡦࡦࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧኢ")+str(xIj15Wv4h9fOnX)+ggDRehOModi(u"ࠫࠥࡣࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬኣ")+rreason+nKLEi8CJumazx4qT(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧኤ")+BYGZC29KJ5Piag36Dl+shZ9eOcN2dJnPj(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬእ")+gANn35esloKUydOipfSMC6RD2+ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠧࠡ࡟ࠪኦ"))
		J5CAkT7PwhD9lbfg8rncqv4od = P2o6ZDHeW790pSQqucvnxzILVUX(gANn35esloKUydOipfSMC6RD2)
		if bdptXFc8UlIhA5jnGwPmKuv2L and isinstance(J5CAkT7PwhD9lbfg8rncqv4od,unicode): J5CAkT7PwhD9lbfg8rncqv4od = J5CAkT7PwhD9lbfg8rncqv4od.encode(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠨࡷࡷࡪ࠽࠭ኧ"))
		if tRxVyNPf2gp1Gkm3ECU8naA: J5CAkT7PwhD9lbfg8rncqv4od = J5CAkT7PwhD9lbfg8rncqv4od.split(BGhdkWsEvJjiMFTr3NLn1flU(u"ࠩ࠲ࠫከ"))[-XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠱ᚫ")]
		gUajr3JwQLKSiCRhEcd = rreason
		rreason = str(rreason)+nKLEi8CJumazx4qT(u"ࠪࡠࡳ࠮ࠠࠨኩ")+J5CAkT7PwhD9lbfg8rncqv4od+n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠫࠥ࠯ࠧኪ")
		if m0whqS5EkyiTjOIpvKZPM87r6 or tAEPZIX3RKJul4V7 or TTPzNluhU1LenVJoG6swCi or PW7QmYC6ptBHFLV21DOMZ9ybvcAGE or anp2wfGmuKU7S1:
			xIj15Wv4h9fOnX = -BGhdkWsEvJjiMFTr3NLn1flU(u"࠳ᚬ")
			p8HVUxN5v3WZfF4Gt7o0gLOdSiI.code = xIj15Wv4h9fOnX
			p8HVUxN5v3WZfF4Gt7o0gLOdSiI.reason = rreason
			if AhpCS7wYsW3PO6Q9:
				l0SAerv8zGH2Wa(OyJ1o4AvmWlB75UkFRX(u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫካ"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+yruHDQOcB97ig(u"࠭ࠠࠡࠢࠣࡘࡷࡿࡩ࡯ࡩࠣࡦࡾࡶࡡࡴࡵࠣࡷࡪࡩࡵࡳ࡫ࡷࡽࠥࡩࡨࡦࡥ࡮ࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨኬ")+str(xIj15Wv4h9fOnX)+cNaVb1vsT4qWOL0rpE(u"ࠧࠡ࡟ࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨክ")+gUajr3JwQLKSiCRhEcd+PtXn0k9G3ocHRg(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪኮ")+BYGZC29KJ5Piag36Dl+xuztI5QWEKG70CPNdhk4vo6(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨኯ")+gANn35esloKUydOipfSMC6RD2+xuztI5QWEKG70CPNdhk4vo6(u"ࠪࠤࡢ࠭ኰ"))
				dnS80F92qtLi4vw1(Tgoa16jMxvYX2(u"๊ࠫำว้ๆฬࠤฯาว้ิࠣห้็อึࠢส่ศ๋ๆ๋ࠩ኱"),ggDRehOModi(u"ࠬ࠭ኲ"),YVJPFvuI2CS5KObiZt=r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠳࠸࠴࠵ᚭ"))
				LVxIk6H4c9aSBA3zTZ7mPl = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(yF29Xdsx35wI07Ce4(u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥࡥࡱ࠴ࠫኳ"))
				kn2aIzbyXutv = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡦࡦࡲ࠶ࠬኴ"))
				LVxIk6H4c9aSBA3zTZ7mPl = Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠼࠽࠾࠿ᚮ") if not LVxIk6H4c9aSBA3zTZ7mPl else int(LVxIk6H4c9aSBA3zTZ7mPl)
				kn2aIzbyXutv = n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠽࠾࠿࠹ᚯ") if not kn2aIzbyXutv else int(kn2aIzbyXutv)
				PPZsYOCBdFKT39DJ62f5lNr8oy = []
				if LVxIk6H4c9aSBA3zTZ7mPl>yruHDQOcB97ig(u"࠷࠰ᚱ"): PPZsYOCBdFKT39DJ62f5lNr8oy.append(r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠶ᚰ"))
				if kn2aIzbyXutv>usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠱࠱ᚲ"): PPZsYOCBdFKT39DJ62f5lNr8oy.append(shZ9eOcN2dJnPj(u"࠳ᚳ"))
				PPZsYOCBdFKT39DJ62f5lNr8oy.append(cgtRBdXxSOk7WUfyDhPCls(u"࠵ᚴ"))
				iYdPmOf7QSoXn8JlH53jNg = jjyW6FTEOn3sSMo1G5LxBiA.sample(PPZsYOCBdFKT39DJ62f5lNr8oy,M6PIj8gl1fno7wcqTksDEBK4bU(u"࠴ᚵ"))[JLoPRXt93dpAB(u"࠴ᚶ")]
				if iYdPmOf7QSoXn8JlH53jNg==iifPEY9ABNzTQp(u"࠶ᚷ"):
					bWN4JVhTjXHfenDsp7xKEGi = InKG0i2r6hHDvgd(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡥࡦ࠶࠻࠹ࡡࡣ࠳ࡨ࠹࠵࠺࠴ࡥ࠴ࡦࡥ࠺ࡪ࠵ࡥ࠵ࡩ࠽ࡪ࠹ࡣ࠴࠺࠹ࡩࡨࡧ࠱࠲࠲࠻࠷࠽࠿ࡡ࠸࠵࠽ࡄࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱࡧ࠱ࡨࡴࡀ࠸࠱࠺࠳ࠫኵ")
					EvwpgrXHuA7nMDUz9RyGhaTOQJWZ = gANn35esloKUydOipfSMC6RD2+usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩ኶")+bWN4JVhTjXHfenDsp7xKEGi+CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪ኷")
					U4Mi9VJtPkK53Xd0rFSqIswOCGRo = uuv2D4mrsyY(Fu63RmidlUsQIgCcOypVYeo,EvwpgrXHuA7nMDUz9RyGhaTOQJWZ,MNWrTo98GZHn,vSj57P0g4mF2Bp,ZAQPeI2BlmFr4MHR6agVtGWJjfsTL,pcWq35MED2dtK(u"ࡇࡣ࡯ࡷࡪ᝔"),cNaVb1vsT4qWOL0rpE(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓ࠮࠴ࡱࡨࠬኸ"),pcWq35MED2dtK(u"ࡇࡣ࡯ࡷࡪ᝔"),pcWq35MED2dtK(u"ࡇࡣ࡯ࡷࡪ᝔"))
				elif iYdPmOf7QSoXn8JlH53jNg==pcWq35MED2dtK(u"࠸ᚸ"):
					bWN4JVhTjXHfenDsp7xKEGi = OyJ1o4AvmWlB75UkFRX(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷ࡣ࠴ࡦ࠶ࡥࡪ࠷࠸࠶ࡦࡩ࠸ࡧ࡬࠶ࡢࡨ࠸࠷࠸ࡩ࠷࠱࠶࠳ࡦ࠸࠺࠷ࡤ࠻ࡨ࠽࠾ࡨࡥ࠵࠸࠹ࡥࡪ࠿࠺ࡁࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫࠮ࡥࡱ࠽࠼࠵࠾࠰ࠨኹ")
					EvwpgrXHuA7nMDUz9RyGhaTOQJWZ = gANn35esloKUydOipfSMC6RD2+usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭ኺ")+bWN4JVhTjXHfenDsp7xKEGi+cNaVb1vsT4qWOL0rpE(u"ࠧࡽࡾࡑࡳ࡛࡫ࡲࡪࡨࡼࡗࡘࡒࠧኻ")
					U4Mi9VJtPkK53Xd0rFSqIswOCGRo = uuv2D4mrsyY(Fu63RmidlUsQIgCcOypVYeo,EvwpgrXHuA7nMDUz9RyGhaTOQJWZ,MNWrTo98GZHn,vSj57P0g4mF2Bp,ZAQPeI2BlmFr4MHR6agVtGWJjfsTL,xuztI5QWEKG70CPNdhk4vo6(u"ࡈࡤࡰࡸ࡫᝕"),KKbpxUZnMcj6AJ4QdD(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗ࠲࠹ࡲࡥࠩኼ"),xuztI5QWEKG70CPNdhk4vo6(u"ࡈࡤࡰࡸ࡫᝕"),xuztI5QWEKG70CPNdhk4vo6(u"ࡈࡤࡰࡸ࡫᝕"))
				elif iYdPmOf7QSoXn8JlH53jNg==drHLAY5ENQFe2q9ptKGabo(u"࠳ᚹ"):
					bWN4JVhTjXHfenDsp7xKEGi = PtXn0k9G3ocHRg(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡧࡷࡧࡰࡦࡴࡤࡴ࡮ࡀ࠷࠷ࡤ࠷ࡪࡨ࠹࠴ࡧࡥࡧ࠵࠾ࡪ࠹ࡤ࠷࠸ࡥ࠶࠻ࡦ࠴࠸࠳࠸ࡨࡪ࠹࠲࠶ࡦࡄࡵࡸ࡯ࡹࡻ࠰ࡷࡪࡸࡶࡦࡴ࠱ࡷࡨࡸࡡࡱࡧࡵࡥࡵ࡯࠮ࡤࡱࡰ࠾࠽࠶࠰࠲ࠩኽ")
					EvwpgrXHuA7nMDUz9RyGhaTOQJWZ = gANn35esloKUydOipfSMC6RD2+iifPEY9ABNzTQp(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪኾ")+bWN4JVhTjXHfenDsp7xKEGi+bcgZJWV6UeNSkRA(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫ኿")
					U4Mi9VJtPkK53Xd0rFSqIswOCGRo = uuv2D4mrsyY(Fu63RmidlUsQIgCcOypVYeo,EvwpgrXHuA7nMDUz9RyGhaTOQJWZ,MNWrTo98GZHn,vSj57P0g4mF2Bp,ZAQPeI2BlmFr4MHR6agVtGWJjfsTL,showDialogs,Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࠯࠷ࡸ࡭࠭ዀ"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࡉࡥࡱࡹࡥ᝖"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࡉࡥࡱࡹࡥ᝖"))
				else: U4Mi9VJtPkK53Xd0rFSqIswOCGRo = p8HVUxN5v3WZfF4Gt7o0gLOdSiI
				xIj15Wv4h9fOnX,rreason = U4Mi9VJtPkK53Xd0rFSqIswOCGRo.code,U4Mi9VJtPkK53Xd0rFSqIswOCGRo.reason
				if not U4Mi9VJtPkK53Xd0rFSqIswOCGRo.succeeded:
					l0SAerv8zGH2Wa(xuztI5QWEKG70CPNdhk4vo6(u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ዁"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+KKbpxUZnMcj6AJ4QdD(u"ࠧࠡࠢࠣࠤࡋࡧࡩ࡭ࡧࡧࠤࡧࡿࡰࡢࡵࡶࠤࡸ࡫ࡣࡶࡴ࡬ࡸࡾࠦࡣࡩࡧࡦ࡯ࠥࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩዂ")+str(xIj15Wv4h9fOnX)+yruHDQOcB97ig(u"ࠨࠢࡠࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩዃ")+rreason+xuztI5QWEKG70CPNdhk4vo6(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫዄ")+BYGZC29KJ5Piag36Dl+nKLEi8CJumazx4qT(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩዅ")+EvwpgrXHuA7nMDUz9RyGhaTOQJWZ+qnPgZ9N15G6Oa8UpMASvLk(u"ࠫࠥࡣࠧ዆"))
					dnS80F92qtLi4vw1(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"๊ࠬไฤีไࠤๆฺไࠡษ็ๅา฻ࠠศๆฦ้๋๐ࠧ዇"),cNaVb1vsT4qWOL0rpE(u"࠭ฬาส้ࠣึฯࠠฤะิํࠬወ"),YVJPFvuI2CS5KObiZt=qnPgZ9N15G6Oa8UpMASvLk(u"࠳࠲࠳࠴ᚺ"))
				else:
					l0SAerv8zGH2Wa(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭ዉ"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠨࠢࠣࡗࡺࡩࡣࡦࡧࡧࡩࡩࠦࡢࡺࡲࡤࡷࡸࠦࡳࡦࡥࡸࡶ࡮ࡺࡹࠡࡥ࡫ࡩࡨࡱࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ዊ")+BYGZC29KJ5Piag36Dl+r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨዋ")+EvwpgrXHuA7nMDUz9RyGhaTOQJWZ+shZ9eOcN2dJnPj(u"ࠪࠤࡢ࠭ዌ"))
					if iYdPmOf7QSoXn8JlH53jNg in [qnPgZ9N15G6Oa8UpMASvLk(u"࠳ᚻ"),bcgZJWV6UeNSkRA(u"࠵ᚼ")]:
						bJlscqHiweNrtKWQM3 = U4Mi9VJtPkK53Xd0rFSqIswOCGRo.headers[cgtRBdXxSOk7WUfyDhPCls(u"ࠫࡘࡩࡲࡢࡲࡨ࠲ࡩࡵ࠭ࡓࡧࡰࡥ࡮ࡴࡩ࡯ࡩ࠰ࡇࡷ࡫ࡤࡪࡶࡶࠫው")]
						if iYdPmOf7QSoXn8JlH53jNg==xuztI5QWEKG70CPNdhk4vo6(u"࠵ᚽ"): LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(KKbpxUZnMcj6AJ4QdD(u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫ࡤࡰ࠳ࠪዎ"),bJlscqHiweNrtKWQM3)
						if iYdPmOf7QSoXn8JlH53jNg==M6PIj8gl1fno7wcqTksDEBK4bU(u"࠷ᚾ"): LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(M6PIj8gl1fno7wcqTksDEBK4bU(u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥࡥࡱ࠵ࠫዏ"),bJlscqHiweNrtKWQM3)
					dnS80F92qtLi4vw1(pcWq35MED2dtK(u"ࠧ็ฮะࠤฬ๊แฮืࠣห้ษๅ็์ࠪዐ"),cgtRBdXxSOk7WUfyDhPCls(u"ࠨࡕࡸࡧࡨ࡫ࡳࡴࠩዑ"),YVJPFvuI2CS5KObiZt=ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠸࠰࠱࠲ᚿ"))
					return U4Mi9VJtPkK53Xd0rFSqIswOCGRo
		iZL6cN3OkM5 = Tgoa16jMxvYX2(u"ࡘࡷࡻࡥ᝗")
		if (JGfwh16Q4pYj3saRHZFiTeVNoW==r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠩࡄࡗࡐ࠭ዒ") or XmfRZkAC8K3VnH75==XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠪࡅࡘࡑࠧዓ")) and (ks3VNwMlLPIHt or AhpCS7wYsW3PO6Q9):
			iZL6cN3OkM5 = AQScIze3YONX4h7(xIj15Wv4h9fOnX,rreason,BYGZC29KJ5Piag36Dl,showDialogs)
			if iZL6cN3OkM5 and JGfwh16Q4pYj3saRHZFiTeVNoW==nKLEi8CJumazx4qT(u"ࠫࡆ࡙ࡋࠨዔ"): JGfwh16Q4pYj3saRHZFiTeVNoW = cNaVb1vsT4qWOL0rpE(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧዕ")
			else: JGfwh16Q4pYj3saRHZFiTeVNoW = n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠭ࡒࡆࡌࡈࡇ࡙ࡋࡄࠨዖ")
			if iZL6cN3OkM5 and XmfRZkAC8K3VnH75==bcgZJWV6UeNSkRA(u"ࠧࡂࡕࡎࠫ዗"): XmfRZkAC8K3VnH75 = pcWq35MED2dtK(u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪዘ")
			else: XmfRZkAC8K3VnH75 = n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫዙ")
			LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ዚ"),JGfwh16Q4pYj3saRHZFiTeVNoW)
			LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(wwplD0tEehqH3kYQXs(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩዛ"),XmfRZkAC8K3VnH75)
		if iZL6cN3OkM5:
			IVlZg2yCLopM5jWz3dGN = shZ9eOcN2dJnPj(u"࡙ࡸࡵࡦ᝘")
			if xIj15Wv4h9fOnX==bbw2eajMlG(u"࠸ᛀ") and cNaVb1vsT4qWOL0rpE(u"ࠬ࡮ࡴࡵࡲࡶࠫዜ") in gANn35esloKUydOipfSMC6RD2 and IVlZg2yCLopM5jWz3dGN:
				if showDialogs: dnS80F92qtLi4vw1(cNaVb1vsT4qWOL0rpE(u"࠭สโ฻ํ่ࠥ็อึࠢื๋ฬีษࠡษ็ฮู็๊าࠢࡖࡗࡑ࠭ዝ"),yF29Xdsx35wI07Ce4(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩዞ"),YVJPFvuI2CS5KObiZt=yF29Xdsx35wI07Ce4(u"࠳࠲࠳࠴ᛁ"))
				UcmHDPlLWaSf = gANn35esloKUydOipfSMC6RD2+nKLEi8CJumazx4qT(u"ࠨࡾࡿࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨዟ")
				BB3L0UYDEvif = uuv2D4mrsyY(Fu63RmidlUsQIgCcOypVYeo,UcmHDPlLWaSf,MNWrTo98GZHn,vSj57P0g4mF2Bp,ZAQPeI2BlmFr4MHR6agVtGWJjfsTL,showDialogs,PtXn0k9G3ocHRg(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠳࠵ࡵࡪࠪዠ"))
				if BB3L0UYDEvif.succeeded:
					p8HVUxN5v3WZfF4Gt7o0gLOdSiI = BB3L0UYDEvif
					l0SAerv8zGH2Wa(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩዡ"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+BGhdkWsEvJjiMFTr3NLn1flU(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪ࡫ࡤࡦࡦࠣࡹࡸ࡯࡮ࡨࠢࡖࡗࡑࡀࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ዢ")+BYGZC29KJ5Piag36Dl+M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫዣ")+GMfo7WypIsRin9HKEZQduYhDetFJOS+shZ9eOcN2dJnPj(u"࠭ࠠ࡞ࠩዤ"))
					if showDialogs: dnS80F92qtLi4vw1(oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠧ็ฮสัࠥฮวิฬัำฬ๋ࠠࡔࡕࡏࠫዥ"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪዦ"),YVJPFvuI2CS5KObiZt=Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠴࠳࠴࠵ᛂ"))
				else:
					l0SAerv8zGH2Wa(pcWq35MED2dtK(u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧዧ"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+tZ3gsrTEdzA1S6LXa9WI5px(u"ࠪࠤࠥࠦࡆࡢ࡫࡯ࡩࡩࠦࡵࡴ࡫ࡱ࡫࡙ࠥࡓࡍ࠼ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩየ")+BYGZC29KJ5Piag36Dl+n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪዩ")+GMfo7WypIsRin9HKEZQduYhDetFJOS+XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠬࠦ࡝ࠨዪ"))
					if showDialogs: dnS80F92qtLi4vw1(yF29Xdsx35wI07Ce4(u"࠭แีๆࠣฬฬูสฯัส้࡙ࠥࡓࡍࠩያ"),drHLAY5ENQFe2q9ptKGabo(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩዬ"),YVJPFvuI2CS5KObiZt=OyJ1o4AvmWlB75UkFRX(u"࠵࠴࠵࠶ᛃ"))
			if not p8HVUxN5v3WZfF4Gt7o0gLOdSiI.succeeded and XmfRZkAC8K3VnH75 in [drHLAY5ENQFe2q9ptKGabo(u"ࠨࡃࡘࡘࡔ࠭ይ"),CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠩࡄࡇࡈࡋࡐࡕࡇࡇࠫዮ")] and AhpCS7wYsW3PO6Q9:
				if showDialogs: dnS80F92qtLi4vw1(qnPgZ9N15G6Oa8UpMASvLk(u"ࠪฮๆ฿๊ๅࠢึ๎ึ็ัศฬࠣฬึ๎ใิ์ࠪዯ"),wwplD0tEehqH3kYQXs(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ደ"),YVJPFvuI2CS5KObiZt=yF29Xdsx35wI07Ce4(u"࠶࠵࠶࠰ᛄ"))
				BB3L0UYDEvif = ccu04ZfBCIxUajMp(Fu63RmidlUsQIgCcOypVYeo,gANn35esloKUydOipfSMC6RD2,MNWrTo98GZHn,vSj57P0g4mF2Bp,ZAQPeI2BlmFr4MHR6agVtGWJjfsTL,showDialogs,KKbpxUZnMcj6AJ4QdD(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࠯࠹ࡸ࡭࠭ዱ"))
				if BB3L0UYDEvif.succeeded:
					p8HVUxN5v3WZfF4Gt7o0gLOdSiI = BB3L0UYDEvif
					l0SAerv8zGH2Wa(tZ3gsrTEdzA1S6LXa9WI5px(u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬዲ"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+xuztI5QWEKG70CPNdhk4vo6(u"ࠧࠡࠢࠣࡔࡷࡵࡸࡪࡧࡶࠤࡸࡻࡣࡤࡧࡨࡨࡪࡪ࠺ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧዳ")+BYGZC29KJ5Piag36Dl+bbw2eajMlG(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧዴ")+GMfo7WypIsRin9HKEZQduYhDetFJOS+M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠩࠣࡡࠬድ"))
					if showDialogs: dnS80F92qtLi4vw1(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"๊ࠪัออࠡีํีๆืวหࠢหีํ้ำ๋ࠩዶ"),KKbpxUZnMcj6AJ4QdD(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ዷ"),YVJPFvuI2CS5KObiZt=M6PIj8gl1fno7wcqTksDEBK4bU(u"࠷࠶࠰࠱ᛅ"))
				else:
					l0SAerv8zGH2Wa(BGhdkWsEvJjiMFTr3NLn1flU(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪዸ"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+vvBChXmSty(u"࠭ࠠࠡࠢࡓࡶࡴࡾࡩࡦࡵࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪዹ")+BYGZC29KJ5Piag36Dl+usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ዺ")+GMfo7WypIsRin9HKEZQduYhDetFJOS+KKbpxUZnMcj6AJ4QdD(u"ࠨࠢࡠࠫዻ"))
					if showDialogs: dnS80F92qtLi4vw1(yF29Xdsx35wI07Ce4(u"ࠩไุ้ࠦำ๋ำไีฬะࠠษำ๋็ุ๐ࠧዼ"),vvBChXmSty(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬዽ"),YVJPFvuI2CS5KObiZt=qnPgZ9N15G6Oa8UpMASvLk(u"࠸࠰࠱࠲ᛆ"))
			if not p8HVUxN5v3WZfF4Gt7o0gLOdSiI.succeeded and JGfwh16Q4pYj3saRHZFiTeVNoW in [r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠫࡆ࡛ࡔࡐࠩዾ"),pcWq35MED2dtK(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧዿ")] and ks3VNwMlLPIHt:
				if showDialogs: dnS80F92qtLi4vw1(yF29Xdsx35wI07Ce4(u"࠭สโ฻ํู่๊ࠥาใิࠤࡉࡔࡓࠨጀ"),nKLEi8CJumazx4qT(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩጁ"),YVJPFvuI2CS5KObiZt=iifPEY9ABNzTQp(u"࠲࠱࠲࠳ᛇ"))
				UcmHDPlLWaSf = gANn35esloKUydOipfSMC6RD2+ggDRehOModi(u"ࠨࡾࡿࡑࡾࡊࡎࡔࡗࡵࡰࡂ࠭ጂ")
				BB3L0UYDEvif = uuv2D4mrsyY(Fu63RmidlUsQIgCcOypVYeo,UcmHDPlLWaSf,MNWrTo98GZHn,vSj57P0g4mF2Bp,ZAQPeI2BlmFr4MHR6agVtGWJjfsTL,showDialogs,iifPEY9ABNzTQp(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠳࠷ࡵࡪࠪጃ"))
				if BB3L0UYDEvif.succeeded:
					p8HVUxN5v3WZfF4Gt7o0gLOdSiI = BB3L0UYDEvif
					l0SAerv8zGH2Wa(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩጄ"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+JLoPRXt93dpAB(u"ࠫࠥࠦࠠࡅࡐࡖࠤࡸࡻࡣࡤࡧࡨࡨࡪࡪ࠺ࠡࠢࠣࡈࡓ࡙࠺ࠡ࡝ࠣࠫጅ")+b409vpr8PJYsiZaOxRdVko+drHLAY5ENQFe2q9ptKGabo(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧጆ")+BYGZC29KJ5Piag36Dl+yruHDQOcB97ig(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬጇ")+GMfo7WypIsRin9HKEZQduYhDetFJOS+Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠧࠡ࡟ࠪገ"))
					if showDialogs: dnS80F92qtLi4vw1(yF29Xdsx35wI07Ce4(u"ࠨ่ฯหาࠦำ๋ำไีࠥࡊࡎࡔࠩጉ"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫጊ"),YVJPFvuI2CS5KObiZt=drHLAY5ENQFe2q9ptKGabo(u"࠳࠲࠳࠴ᛈ"))
				else:
					l0SAerv8zGH2Wa(shZ9eOcN2dJnPj(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨጋ"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠫࠥࠦࠠࡅࡐࡖࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠠࡅࡐࡖ࠾ࠥࡡࠠࠨጌ")+b409vpr8PJYsiZaOxRdVko+cgtRBdXxSOk7WUfyDhPCls(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧግ")+BYGZC29KJ5Piag36Dl+iifPEY9ABNzTQp(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬጎ")+GMfo7WypIsRin9HKEZQduYhDetFJOS+ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠧࠡ࡟ࠪጏ"))
					if showDialogs: dnS80F92qtLi4vw1(InKG0i2r6hHDvgd(u"ࠨใืู่๊ࠥาใิࠤࡉࡔࡓࠨጐ"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ጑"),YVJPFvuI2CS5KObiZt=iifPEY9ABNzTQp(u"࠴࠳࠴࠵ᛉ"))
		if XmfRZkAC8K3VnH75==iifPEY9ABNzTQp(u"ࠪࡖࡊࡐࡅࡄࡖࡈࡈࠬጒ") or JGfwh16Q4pYj3saRHZFiTeVNoW==OyJ1o4AvmWlB75UkFRX(u"ࠫࡗࡋࡊࡆࡅࡗࡉࡉ࠭ጓ"): showDialogs = n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࡌࡡ࡭ࡵࡨ᝙")
		if not p8HVUxN5v3WZfF4Gt7o0gLOdSiI.succeeded:
			if showDialogs: ZOAWTyIzDR0hpc8Jm9 = AQScIze3YONX4h7(xIj15Wv4h9fOnX,rreason,BYGZC29KJ5Piag36Dl,showDialogs)
			if xIj15Wv4h9fOnX!=BGhdkWsEvJjiMFTr3NLn1flU(u"࠵࠴࠵ᛊ") and BYGZC29KJ5Piag36Dl not in b5vp1YMUGnxw6JtRdoDusW and cNaVb1vsT4qWOL0rpE(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࠩጔ") not in BYGZC29KJ5Piag36Dl:
				vS1seWj2c0tKyZ(yF29Xdsx35wI07Ce4(u"࠭ࡆࡰࡴࡦࡩࡩࠦࡥࡹ࡫ࡷࠤࡩࡻࡥࠡࡶࡲࠤࡳ࡫ࡴࡸࡱࡵ࡯ࠥ࡯ࡳࡴࡷࡨࡷࠥࡽࡩࡵࡪ࠽ࠤࠬጕ")+BYGZC29KJ5Piag36Dl)
	if LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪ጖")) not in [bbw2eajMlG(u"ࠨࡃࡘࡘࡔ࠭጗"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠩࡖࡘࡔࡖࠧጘ"),bbw2eajMlG(u"ࠪࡅࡘࡑࠧጙ")]: LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(KKbpxUZnMcj6AJ4QdD(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧጚ"),yF29Xdsx35wI07Ce4(u"ࠬࡇࡓࡌࠩጛ"))
	if LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫጜ")) not in [cgtRBdXxSOk7WUfyDhPCls(u"ࠧࡂࡗࡗࡓࠬጝ"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠨࡕࡗࡓࡕ࠭ጞ"),ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠩࡄࡗࡐ࠭ጟ")]: LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(xuztI5QWEKG70CPNdhk4vo6(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨጠ"),ggDRehOModi(u"ࠫࡆ࡙ࡋࠨጡ"))
	return p8HVUxN5v3WZfF4Gt7o0gLOdSiI
def zIKYyon9QjcvP8RbpqN4TVC3g(nO1lCyXmdAfQa0MBkEg7I5DGbN2jc,Fu63RmidlUsQIgCcOypVYeo,GMfo7WypIsRin9HKEZQduYhDetFJOS,MNWrTo98GZHn,vSj57P0g4mF2Bp,ZAQPeI2BlmFr4MHR6agVtGWJjfsTL,showDialogs,BYGZC29KJ5Piag36Dl,ks3VNwMlLPIHt=ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠬ࠭ጢ"),AhpCS7wYsW3PO6Q9=OyJ1o4AvmWlB75UkFRX(u"࠭ࠧጣ")):
	gANn35esloKUydOipfSMC6RD2,UdvjsK7fcmtokh8z,G9OmMTVLjrK5su6Yvt8XUx,MsqPuhEKTC39NDwxZd = rRjtH4UFBNVayeEYwl6dobvg(GMfo7WypIsRin9HKEZQduYhDetFJOS)
	YI2m5zkZ3ASWF8jK = Fu63RmidlUsQIgCcOypVYeo,gANn35esloKUydOipfSMC6RD2,MNWrTo98GZHn,vSj57P0g4mF2Bp,ZAQPeI2BlmFr4MHR6agVtGWJjfsTL
	if nO1lCyXmdAfQa0MBkEg7I5DGbN2jc:
		l3lOuS56hyIdjACkcweb1WDrHQgYfa = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,pcWq35MED2dtK(u"ࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩጤ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࠫጥ"),YI2m5zkZ3ASWF8jK)
		if l3lOuS56hyIdjACkcweb1WDrHQgYfa.succeeded:
			u5VpIfdK9HTnYk(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡖࠤࠥࡘࡅࡂࡆࡢࡇࡆࡉࡈࡆࠩጦ"),gANn35esloKUydOipfSMC6RD2,MNWrTo98GZHn,vSj57P0g4mF2Bp,BYGZC29KJ5Piag36Dl,Fu63RmidlUsQIgCcOypVYeo)
			return l3lOuS56hyIdjACkcweb1WDrHQgYfa
	l3lOuS56hyIdjACkcweb1WDrHQgYfa = uuv2D4mrsyY(Fu63RmidlUsQIgCcOypVYeo,GMfo7WypIsRin9HKEZQduYhDetFJOS,MNWrTo98GZHn,vSj57P0g4mF2Bp,ZAQPeI2BlmFr4MHR6agVtGWJjfsTL,showDialogs,BYGZC29KJ5Piag36Dl,ks3VNwMlLPIHt,AhpCS7wYsW3PO6Q9)
	if l3lOuS56hyIdjACkcweb1WDrHQgYfa.succeeded:
		if M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫጧ") in BYGZC29KJ5Piag36Dl: l3lOuS56hyIdjACkcweb1WDrHQgYfa.content = zz4hcMfiyUwxHgBDt(l3lOuS56hyIdjACkcweb1WDrHQgYfa.content)
		if nO1lCyXmdAfQa0MBkEg7I5DGbN2jc: OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,BGhdkWsEvJjiMFTr3NLn1flU(u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙ࠧጨ"),YI2m5zkZ3ASWF8jK,l3lOuS56hyIdjACkcweb1WDrHQgYfa,nO1lCyXmdAfQa0MBkEg7I5DGbN2jc)
	return l3lOuS56hyIdjACkcweb1WDrHQgYfa
def wANetMq45ZG2EhvL38HgfYCBzn1o(nO1lCyXmdAfQa0MBkEg7I5DGbN2jc,GMfo7WypIsRin9HKEZQduYhDetFJOS,MNWrTo98GZHn,vSj57P0g4mF2Bp,showDialogs,BYGZC29KJ5Piag36Dl):
	if not MNWrTo98GZHn or isinstance(MNWrTo98GZHn,dict): Fu63RmidlUsQIgCcOypVYeo = BGhdkWsEvJjiMFTr3NLn1flU(u"ࠬࡍࡅࡕࠩጩ")
	else:
		Fu63RmidlUsQIgCcOypVYeo = n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠭ࡐࡐࡕࡗࠫጪ")
		MNWrTo98GZHn = P2o6ZDHeW790pSQqucvnxzILVUX(MNWrTo98GZHn)
		SL67VjaRrvQx1ClPcKGz0pBXAT,MNWrTo98GZHn = ykfj6Qb9Fc5GiJIvelp84rHDn(MNWrTo98GZHn)
	l3lOuS56hyIdjACkcweb1WDrHQgYfa = zIKYyon9QjcvP8RbpqN4TVC3g(nO1lCyXmdAfQa0MBkEg7I5DGbN2jc,Fu63RmidlUsQIgCcOypVYeo,GMfo7WypIsRin9HKEZQduYhDetFJOS,MNWrTo98GZHn,vSj57P0g4mF2Bp,wwplD0tEehqH3kYQXs(u"ࡔࡳࡷࡨ᝚"),showDialogs,BYGZC29KJ5Piag36Dl)
	DMqcCpg8GmefYtWJZITSP29x3nLzO = l3lOuS56hyIdjACkcweb1WDrHQgYfa.content
	DMqcCpg8GmefYtWJZITSP29x3nLzO = str(DMqcCpg8GmefYtWJZITSP29x3nLzO)
	return DMqcCpg8GmefYtWJZITSP29x3nLzO
def rRjtH4UFBNVayeEYwl6dobvg(GMfo7WypIsRin9HKEZQduYhDetFJOS):
	yyCRbxFJeEYwO4StGTMnX = GMfo7WypIsRin9HKEZQduYhDetFJOS.split(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠧࡽࡾࠪጫ"))
	gANn35esloKUydOipfSMC6RD2,UdvjsK7fcmtokh8z,G9OmMTVLjrK5su6Yvt8XUx,MsqPuhEKTC39NDwxZd = yyCRbxFJeEYwO4StGTMnX[yruHDQOcB97ig(u"࠴ᛋ")],None,None,bcgZJWV6UeNSkRA(u"ࡕࡴࡸࡩ᝛")
	for YI2m5zkZ3ASWF8jK in yyCRbxFJeEYwO4StGTMnX:
		if cNaVb1vsT4qWOL0rpE(u"ࠨࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭ጬ") in YI2m5zkZ3ASWF8jK: UdvjsK7fcmtokh8z = YI2m5zkZ3ASWF8jK.split(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠩࡀࠫጭ"))[ggDRehOModi(u"࠶ᛌ")]
		elif xuztI5QWEKG70CPNdhk4vo6(u"ࠪࡑࡾࡊࡎࡔࡗࡵࡰࡂ࠭ጮ") in YI2m5zkZ3ASWF8jK: G9OmMTVLjrK5su6Yvt8XUx = YI2m5zkZ3ASWF8jK.split(JLoPRXt93dpAB(u"ࠫࡂ࠭ጯ"))[nKLEi8CJumazx4qT(u"࠷ᛍ")]
		elif shZ9eOcN2dJnPj(u"ࠬࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪጰ") in YI2m5zkZ3ASWF8jK: MsqPuhEKTC39NDwxZd = ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࡈࡤࡰࡸ࡫᝜")
	return gANn35esloKUydOipfSMC6RD2,UdvjsK7fcmtokh8z,G9OmMTVLjrK5su6Yvt8XUx,MsqPuhEKTC39NDwxZd
def XuE2yABLxYP(ffAnyTIUapotW4dS6sbC):
	g12gqJky0MotVTFHWxl4fPv9n,tzVT6PXndWu0,ZmiOVG1J4AytscSDFW2ECx9e = InKG0i2r6hHDvgd(u"࠭ࠧጱ"),InKG0i2r6hHDvgd(u"ࠧࠨጲ"),ggDRehOModi(u"ࠨࠩጳ")
	ffAnyTIUapotW4dS6sbC = ffAnyTIUapotW4dS6sbC.replace(Qa68jZXt0gBH,iifPEY9ABNzTQp(u"ࠩࠪጴ")).replace(RQ0HpOfhFDoJdtl,tZ3gsrTEdzA1S6LXa9WI5px(u"ࠪࠫጵ"))
	LkKHrN2Stnw0avfuWO = u5h2Rckvw1E.findall(XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠫ࠭࠴ࠩ࡝࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺࡟ࡡ࠭ࡢࡷ࡝ࡹ࡟ࡻ࠮ࠦࠫ࡝࡝࡟࠳ࡈࡕࡌࡐࡔ࡟ࡡ࠭࠴ࠪࡀࠫࠧࠫጶ"),ffAnyTIUapotW4dS6sbC,u5h2Rckvw1E.DOTALL)
	if LkKHrN2Stnw0avfuWO: g12gqJky0MotVTFHWxl4fPv9n,tzVT6PXndWu0,ffAnyTIUapotW4dS6sbC = LkKHrN2Stnw0avfuWO[PtXn0k9G3ocHRg(u"࠰ᛎ")]
	if g12gqJky0MotVTFHWxl4fPv9n not in [OyJ1o4AvmWlB75UkFRX(u"ࠬࠦࠧጷ"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠭ࠬࠨጸ"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠧࠨጹ")]: ZmiOVG1J4AytscSDFW2ECx9e = JLoPRXt93dpAB(u"ࠨࡡࡐࡓࡉࡥࠧጺ")
	if tzVT6PXndWu0: tzVT6PXndWu0 = oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠩࡢࠫጻ")+tzVT6PXndWu0+bcgZJWV6UeNSkRA(u"ࠪࡣࠬጼ")
	ffAnyTIUapotW4dS6sbC = tzVT6PXndWu0+ZmiOVG1J4AytscSDFW2ECx9e+ffAnyTIUapotW4dS6sbC
	return ffAnyTIUapotW4dS6sbC
def Td6K1l0UMsxXZQf8yGLVF7bokN9tJq(nO1lCyXmdAfQa0MBkEg7I5DGbN2jc,Fu63RmidlUsQIgCcOypVYeo,GMfo7WypIsRin9HKEZQduYhDetFJOS,IkUx0SR4WlzPeKMJXw,iNwzmDqHFJhod1cAsg0SLpUrPxa5,xiCJpEBY8m4gI1KzSTAvcsQXGk,vSj57P0g4mF2Bp=JLoPRXt93dpAB(u"ࠫࠬጽ")):
	e9Yk3QRFBJUzsCSjc2api = hmcFWJUgiAuGk(GMfo7WypIsRin9HKEZQduYhDetFJOS,JLoPRXt93dpAB(u"ࠬࡻࡲ࡭ࠩጾ"))
	DhKsd97QlxBSRwGNPHt56yFzgr = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(qnPgZ9N15G6Oa8UpMASvLk(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨጿ")+IkUx0SR4WlzPeKMJXw)
	if e9Yk3QRFBJUzsCSjc2api==DhKsd97QlxBSRwGNPHt56yFzgr: LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩፀ")+IkUx0SR4WlzPeKMJXw,vvBChXmSty(u"ࠨࠩፁ"))
	if DhKsd97QlxBSRwGNPHt56yFzgr: UcmHDPlLWaSf = GMfo7WypIsRin9HKEZQduYhDetFJOS.replace(e9Yk3QRFBJUzsCSjc2api,DhKsd97QlxBSRwGNPHt56yFzgr)
	else:
		UcmHDPlLWaSf = GMfo7WypIsRin9HKEZQduYhDetFJOS
		DhKsd97QlxBSRwGNPHt56yFzgr = e9Yk3QRFBJUzsCSjc2api
	BB3L0UYDEvif = zIKYyon9QjcvP8RbpqN4TVC3g(nO1lCyXmdAfQa0MBkEg7I5DGbN2jc,Fu63RmidlUsQIgCcOypVYeo,UcmHDPlLWaSf,KKbpxUZnMcj6AJ4QdD(u"ࠩࠪፂ"),vSj57P0g4mF2Bp,PtXn0k9G3ocHRg(u"ࠪࠫፃ"),OyJ1o4AvmWlB75UkFRX(u"ࠫࠬፄ"),yF29Xdsx35wI07Ce4(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠷ࡳࡵࠩፅ"))
	DMqcCpg8GmefYtWJZITSP29x3nLzO = BB3L0UYDEvif.content
	if VVGRN7xiyj:
		try: DMqcCpg8GmefYtWJZITSP29x3nLzO = DMqcCpg8GmefYtWJZITSP29x3nLzO.decode(bbw2eajMlG(u"࠭ࡵࡵࡨ࠻ࠫፆ"),bcgZJWV6UeNSkRA(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧፇ"))
		except: pass
	xIj15Wv4h9fOnX = BB3L0UYDEvif.code
	if xIj15Wv4h9fOnX!=-PtXn0k9G3ocHRg(u"࠳ᛏ") and (not BB3L0UYDEvif.succeeded or xiCJpEBY8m4gI1KzSTAvcsQXGk not in DMqcCpg8GmefYtWJZITSP29x3nLzO):
		iNwzmDqHFJhod1cAsg0SLpUrPxa5 = iNwzmDqHFJhod1cAsg0SLpUrPxa5.replace(M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠨࠢࠪፈ"),cNaVb1vsT4qWOL0rpE(u"ࠩ࠮ࠫፉ"))
		gANn35esloKUydOipfSMC6RD2 = PtXn0k9G3ocHRg(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡩࡲࡳ࡬ࡲࡥ࠯ࡥࡲࡱ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡷ࠽ࠨፊ")+iNwzmDqHFJhod1cAsg0SLpUrPxa5
		emrzEIsMWO2GLw9lpKxSY7n0F = {r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨፋ"):drHLAY5ENQFe2q9ptKGabo(u"ࠬ࠭ፌ")}
		p8HVUxN5v3WZfF4Gt7o0gLOdSiI = zIKYyon9QjcvP8RbpqN4TVC3g(nO1lCyXmdAfQa0MBkEg7I5DGbN2jc,Fu63RmidlUsQIgCcOypVYeo,gANn35esloKUydOipfSMC6RD2,xuztI5QWEKG70CPNdhk4vo6(u"࠭ࠧፍ"),emrzEIsMWO2GLw9lpKxSY7n0F,KKbpxUZnMcj6AJ4QdD(u"ࠧࠨፎ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠨࠩፏ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠵ࡲࡩ࠭ፐ"))
		if p8HVUxN5v3WZfF4Gt7o0gLOdSiI.succeeded:
			DMqcCpg8GmefYtWJZITSP29x3nLzO = p8HVUxN5v3WZfF4Gt7o0gLOdSiI.content
			if VVGRN7xiyj:
				try: DMqcCpg8GmefYtWJZITSP29x3nLzO = DMqcCpg8GmefYtWJZITSP29x3nLzO.decode(qnPgZ9N15G6Oa8UpMASvLk(u"ࠪࡹࡹ࡬࠸ࠨፑ"),InKG0i2r6hHDvgd(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫፒ"))
				except: pass
			lQUf3AY258LeWch = u5h2Rckvw1E.findall(yruHDQOcB97ig(u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢ࠰࡞ࡺ࠮ࡡࡅ࠮ࠫࡁࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠭ፓ"),DMqcCpg8GmefYtWJZITSP29x3nLzO,u5h2Rckvw1E.DOTALL)
			BawYkoIej6WLKM20A = [DhKsd97QlxBSRwGNPHt56yFzgr]
			g0nV5Hw6BfUtldQYxq3m = [bbw2eajMlG(u"࠭ࡡࡱ࡭ࠪፔ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠧࡨࡱࡲ࡫ࡱ࡫ࠧፕ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠨࡶࡺ࡭ࡹࡺࡥࡳࠩፖ"),wwplD0tEehqH3kYQXs(u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪፗ"),bbw2eajMlG(u"ࠪࡪࡦࡩࡥࡣࡱࡲ࡯ࠬፘ"),iifPEY9ABNzTQp(u"ࠫࡵ࡮ࡰࠨፙ"),cNaVb1vsT4qWOL0rpE(u"ࠬࡧࡴ࡭ࡣࡴࠫፚ"),cgtRBdXxSOk7WUfyDhPCls(u"࠭ࡳࡪࡶࡨ࡭ࡳࡪࡩࡤࡧࡶࠫ፛"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠧࡴࡷࡵ࠲ࡱࡿࠧ፜"),iifPEY9ABNzTQp(u"ࠨࡤ࡯ࡳ࡬ࡹࡰࡰࡶࠪ፝"),JLoPRXt93dpAB(u"ࠩ࡬ࡲ࡫ࡵࡲ࡮ࡧࡵࠫ፞"),wwplD0tEehqH3kYQXs(u"ࠪࡷ࡮ࡺࡥ࡭࡫࡮ࡩࠬ፟"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠫ࡮ࡴࡳࡵࡣࡪࡶࡦࡳࠧ፠"),InKG0i2r6hHDvgd(u"ࠬࡹ࡮ࡢࡲࡦ࡬ࡦࡺࠧ፡"),M6PIj8gl1fno7wcqTksDEBK4bU(u"࠭ࡨࡵࡶࡳ࠱ࡪࡷࡵࡪࡸࠪ።"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠧࡧࡣࡶࡩࡱࡶ࡬ࡶࡵࠪ፣")]
			for j0zi47my8EYnhALDIS in lQUf3AY258LeWch:
				if any(c2eEflztvIX in j0zi47my8EYnhALDIS for c2eEflztvIX in g0nV5Hw6BfUtldQYxq3m): continue
				DhKsd97QlxBSRwGNPHt56yFzgr = hmcFWJUgiAuGk(j0zi47my8EYnhALDIS,tZ3gsrTEdzA1S6LXa9WI5px(u"ࠨࡷࡵࡰࠬ፤"))
				if DhKsd97QlxBSRwGNPHt56yFzgr in BawYkoIej6WLKM20A: continue
				if len(BawYkoIej6WLKM20A)==qnPgZ9N15G6Oa8UpMASvLk(u"࠻ᛐ"):
					l0SAerv8zGH2Wa(ggDRehOModi(u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ፥"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+JLoPRXt93dpAB(u"ࠪࠤࠥࠦࡇࡰࡱࡪࡰࡪࠦࡤࡪࡦࠣࡲࡴࡺࠠࡧ࡫ࡱࡨࠥࡧࠠ࡯ࡧࡺࠤ࡭ࡵࡳࡵࡰࡤࡱࡪࠦࠠࠡࡕ࡬ࡸࡪࡀࠠ࡜ࠢࠪ፦")+IkUx0SR4WlzPeKMJXw+iifPEY9ABNzTQp(u"ࠫࠥࡣࠠࠡࡑ࡯ࡨ࠿࡛ࠦࠡࠩ፧")+e9Yk3QRFBJUzsCSjc2api+qnPgZ9N15G6Oa8UpMASvLk(u"ࠬࠦ࡝ࠨ፨"))
					LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(cgtRBdXxSOk7WUfyDhPCls(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨ፩")+IkUx0SR4WlzPeKMJXw,InKG0i2r6hHDvgd(u"ࠧࠨ፪"))
					break
				BawYkoIej6WLKM20A.append(DhKsd97QlxBSRwGNPHt56yFzgr)
				UcmHDPlLWaSf = GMfo7WypIsRin9HKEZQduYhDetFJOS.replace(e9Yk3QRFBJUzsCSjc2api,DhKsd97QlxBSRwGNPHt56yFzgr)
				BB3L0UYDEvif = zIKYyon9QjcvP8RbpqN4TVC3g(nO1lCyXmdAfQa0MBkEg7I5DGbN2jc,Fu63RmidlUsQIgCcOypVYeo,UcmHDPlLWaSf,CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠨࠩ፫"),vSj57P0g4mF2Bp,ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠩࠪ፬"),bbw2eajMlG(u"ࠪࠫ፭"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤࡔࡅࡘࡡࡋࡓࡘ࡚ࡎࡂࡏࡈ࠱࠸ࡸࡤࠨ፮"))
				DMqcCpg8GmefYtWJZITSP29x3nLzO = BB3L0UYDEvif.content
				if BB3L0UYDEvif.succeeded and xiCJpEBY8m4gI1KzSTAvcsQXGk in DMqcCpg8GmefYtWJZITSP29x3nLzO:
					l0SAerv8zGH2Wa(iifPEY9ABNzTQp(u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ፯"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠭ࠠࠡࠢࡊࡳࡴ࡭࡬ࡦࠢࡩࡳࡺࡴࡤࠡࡣࠣࡲࡪࡽࠠࡩࡱࡶࡸࡳࡧ࡭ࡦࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭፰")+IkUx0SR4WlzPeKMJXw+Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠧࠡ࡟ࠣࠤࠥࡔࡥࡸ࠼ࠣ࡟ࠥ࠭፱")+DhKsd97QlxBSRwGNPHt56yFzgr+XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠨࠢࡠࠤࠥࡕ࡬ࡥ࠼ࠣ࡟ࠥ࠭፲")+e9Yk3QRFBJUzsCSjc2api+nKLEi8CJumazx4qT(u"ࠩࠣࡡࠬ፳"))
					LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(JLoPRXt93dpAB(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࠬ፴")+IkUx0SR4WlzPeKMJXw,DhKsd97QlxBSRwGNPHt56yFzgr)
					break
	return DhKsd97QlxBSRwGNPHt56yFzgr,UcmHDPlLWaSf,BB3L0UYDEvif
def wSH84vUOuxYjoQ3aPBeAEZ(TwPt5qAHlrOsQ):
	XbnadV39UWNhzI2oqKiCOc5rfPmp0S = {
	 CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠫࡴࡲࡤࠨ፵")			:ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"่ࠬฯ๋็ࠪ፶")
	,wwplD0tEehqH3kYQXs(u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࡤࠨ፷")		:cgtRBdXxSOk7WUfyDhPCls(u"ࠧๆฬ๋ๆๆ࠭፸")
	,Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩ፹")		:cgtRBdXxSOk7WUfyDhPCls(u"่ࠩๅ็๎ฯࠨ፺")
	,wwplD0tEehqH3kYQXs(u"ࠪ࡫ࡴࡵࡤࠨ፻")			:oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠫั๐ฯࠨ፼")
	,M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ፽")		:JLoPRXt93dpAB(u"࠭แีๆࠪ፾")
	,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ፿")		:BGhdkWsEvJjiMFTr3NLn1flU(u"ࠨ็ฯ่ิ࠭ᎀ")
	,pcWq35MED2dtK(u"ࠩࡹ࡭ࡩ࡫࡯ࠨᎁ")		:Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠪๅ๏ี๊้ࠩᎂ")
	,wwplD0tEehqH3kYQXs(u"ࠫࡱ࡯ࡶࡦࠩᎃ")			:r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"่ࠬๆศหࠪᎄ")
	,BGhdkWsEvJjiMFTr3NLn1flU(u"࠭ࡡ࡬ࡱࡤࡱࠬᎅ")		:CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠧๆ๊ๅ฽ࠥษใ้ษ่ࠤฬ๊โะ์่ࠫᎆ")
	,wwplD0tEehqH3kYQXs(u"ࠨࡣ࡮ࡻࡦࡳࠧᎇ")		:iifPEY9ABNzTQp(u"่ࠩ์็฿ࠠฤๅ๋ห๊ࠦวๅฮา๎ิ࠭ᎈ")
	,OyJ1o4AvmWlB75UkFRX(u"ࠪࡥࡰࡵࡡ࡮ࡥࡤࡱࠬᎉ")		:yF29Xdsx35wI07Ce4(u"๊ࠫ๎โฺࠢฦ็ํอๅࠡๅส้ࠬᎊ")
	,tZ3gsrTEdzA1S6LXa9WI5px(u"ࠬࡧ࡬ࡢࡴࡤࡦࠬᎋ")		:vvBChXmSty(u"࠭ๅ้ไ฼ࠤ่๊ࠠศๆ฼ีอ࠭ᎌ")
	,JLoPRXt93dpAB(u"ࠧࡢ࡮ࡩࡥࡹ࡯࡭ࡪࠩᎍ")		:n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠨ็๋ๆ฾ࠦวๅ็้ฬึࠦวๅใส฻๊๐ࠧᎎ")
	,oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠩࡤࡰࡰࡧࡷࡵࡪࡤࡶࠬᎏ")	:tZ3gsrTEdzA1S6LXa9WI5px(u"้ࠪํู่ࠡไ้หฮࠦวๅๅ๋ฯึ࠭᎐")
	,xuztI5QWEKG70CPNdhk4vo6(u"ࠫࡦࡲ࡭ࡢࡣࡵࡩ࡫࠭᎑")		:M6PIj8gl1fno7wcqTksDEBK4bU(u"๋่ࠬใ฻ࠣๆ๋อษࠡษ็้฾อัโࠩ᎒")
	,InKG0i2r6hHDvgd(u"࠭ࡡࡳࡤ࡯࡭ࡴࡴࡺࠨ᎓")		:yF29Xdsx35wI07Ce4(u"ࠧๆ๊ๅ฽ࠥ฿ัษࠢ็๎ํ์าࠨ᎔")
	,nKLEi8CJumazx4qT(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࡸ࡬ࡴࠬ᎕")	:pcWq35MED2dtK(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣࡺ࡮ࡶࠧ᎖")
	,KKbpxUZnMcj6AJ4QdD(u"ࠪࡩࡱࡩࡩ࡯ࡧࡰࡥࠬ᎗")		:CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"๊ࠫ๎โฺࠢสุ่๐ๆๆษࠪ᎘")
	,bcgZJWV6UeNSkRA(u"ࠬ࡮ࡥ࡭ࡣ࡯ࠫ᎙")		:cNaVb1vsT4qWOL0rpE(u"࠭ๅ้ไ฼ࠤ์๊วๅࠢํ์ฯ๐่ษࠩ᎚")
	,BGhdkWsEvJjiMFTr3NLn1flU(u"ࠧࡤ࡫ࡰࡥ࡫ࡧ࡮ࡴࠩ᎛")		:M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤๆอๆำࠩ᎜")
	,JLoPRXt93dpAB(u"ࠩࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫ᎝")		:CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"้ࠪํู่ࠡึส๋ิࠦแ้ำํ์ࠬ᎞")
	,XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠫࡸ࡮࡯ࡰࡨࡰࡥࡽ࠭᎟")		:yF29Xdsx35wI07Ce4(u"๋่ࠬใ฻ุࠣํ็ࠠๆษๆืࠬᎠ")
	,oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨᎡ")		:qnPgZ9N15G6Oa8UpMASvLk(u"ࠧๆ๊ๅ฽ࠥ฿ัษࠢึ๎๏ีࠧᎢ")
	,Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩᎣ")		:shZ9eOcN2dJnPj(u"่ࠩ์็฿ࠠิ์่หࠥ์ว้ࠩᎤ")
	,InKG0i2r6hHDvgd(u"ࠪ࡯ࡦࡸࡢࡢ࡮ࡤࡸࡻ࠭Ꭵ")	:wwplD0tEehqH3kYQXs(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠไำห่ฬวࠧᎦ")
	,BGhdkWsEvJjiMFTr3NLn1flU(u"ࠬࡿࡴࡣࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫᎧ")	:shZ9eOcN2dJnPj(u"࠭ๅ้ษๅ฽ࠥ๐่ห์๋ฬࠬᎨ")
	,PtXn0k9G3ocHRg(u"ࠧ࡮ࡻࡦ࡭ࡲࡧࠧᎩ")		:Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠨ็๋ๆ฾ࠦๅศ์ࠣื๏๋วࠨᎪ")
	,ggDRehOModi(u"ࠩࡺࡩࡨ࡯࡭ࡢࠩᎫ")		:yruHDQOcB97ig(u"้ࠪํู่๊ࠡํࠤุ๐ๅศࠩᎬ")
	,wwplD0tEehqH3kYQXs(u"ࠫ࡫ࡧࡳࡦ࡮࡫ࡨ࠶࠭Ꭽ")		:wwplD0tEehqH3kYQXs(u"๋่ࠬใ฻ࠣๅฬ฻ไࠡษ็วํ๊ࠧᎮ")
	,yF29Xdsx35wI07Ce4(u"࠭ࡦࡢࡵࡨࡰ࡭ࡪ࠲ࠨᎯ")		:yF29Xdsx35wI07Ce4(u"ࠧๆ๊ๅ฽ࠥ็วึๆࠣห้ัว็์ࠪᎰ")
	,usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠨࡤࡲ࡯ࡷࡧࠧᎱ")		:yF29Xdsx35wI07Ce4(u"่ࠩ์็฿ࠠษๅิหࠬᎲ")
	,drHLAY5ENQFe2q9ptKGabo(u"ࠪࡧ࡮ࡳࡡࡢࡤࡧࡳࠬᎳ")		:OyJ1o4AvmWlB75UkFRX(u"๊ࠫ๎โฺࠢึ๎๊อฺࠠสา์ࠬᎴ")
	,r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠬࡲࡩࡷࡧࡷࡺࠬᎵ")		:XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠭ๅๅใࠪᎶ")
	,oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠧ࡭࡫ࡥࡶࡦࡸࡹࠨᎷ")		:Tgoa16jMxvYX2(u"ࠨ็็ๅࠬᎸ")
	,bbw2eajMlG(u"ࠩࡰࡳࡻࡹ࠴ࡶࠩᎹ")		:usaZLwSGe1k6VDp570yhB4bzWPiFq(u"้ࠪํู่ࠡ็๋ๅืࠦแ้ำํ์ࠬᎺ")
	,CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠫ࡫ࡧࡪࡦࡴࡶ࡬ࡴࡽࠧᎻ")	:drHLAY5ENQFe2q9ptKGabo(u"๋่ࠬใ฻ࠣๅัืࠠี๊ࠪᎼ")
	,PtXn0k9G3ocHRg(u"࠭ࡥࡨࡻࡥࡩࡸࡺࠧᎽ")		:bbw2eajMlG(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠨᎾ")
	,cNaVb1vsT4qWOL0rpE(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠳ࠪᎿ")		:bbw2eajMlG(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠵ࠬᏀ")
	,cgtRBdXxSOk7WUfyDhPCls(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠶ࠬᏁ")		:XikqnGVSK4v9d3uUICLhDxJyt1M(u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠸ࠧᏂ")
	,cNaVb1vsT4qWOL0rpE(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠹ࠧᏃ")		:bcgZJWV6UeNSkRA(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠴ࠩᏄ")
	,ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠵ࠩᏅ")		:yruHDQOcB97ig(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠷ࠫᏆ")
	,yruHDQOcB97ig(u"ࠩࡦ࡭ࡲࡧ࠴ࡶࠩᏇ")		:drHLAY5ENQFe2q9ptKGabo(u"้ࠪํู่ࠡีํ้ฬࠦแ้ำํ์ࠬᏈ")
	,nKLEi8CJumazx4qT(u"ࠫࡪ࡭ࡹ࡯ࡱࡺࠫᏉ")		:qnPgZ9N15G6Oa8UpMASvLk(u"๋่ࠬใ฻ࠣษ๏า๊่ࠡส์ࠬᏊ")
	,cgtRBdXxSOk7WUfyDhPCls(u"࠭ࡥࡨࡻࡧࡩࡦࡪࠧᏋ")		:yF29Xdsx35wI07Ce4(u"ࠧๆ๊ๅ฽ࠥห๊อ์ࠣำ๏ีࠧᏌ")
	,r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠨࡪࡤࡰࡦࡩࡩ࡮ࡣࠪᏍ")		:ggDRehOModi(u"่ࠩ์็฿่ࠠๆสࠤุ๐ๅศࠩᏎ")
	,Tgoa16jMxvYX2(u"ࠪࡰࡴࡪࡹ࡯ࡧࡷࠫᏏ")		:tZ3gsrTEdzA1S6LXa9WI5px(u"๊ࠫ๎โฺࠢ็์ิ๐ࠠ็ฬࠪᏐ")
	,iifPEY9ABNzTQp(u"ࠬࡺࡶࡧࡷࡱࠫᏑ")		:cNaVb1vsT4qWOL0rpE(u"࠭ๅ้ไ฼ࠤฯ๐แ๋ࠢไห๋࠭Ꮢ")
	,cNaVb1vsT4qWOL0rpE(u"ࠧࡤ࡫ࡰࡥࡱ࡯ࡧࡩࡶࠪᏓ")	:oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ้อ๊หࠩᏔ")
	,CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠩࡶ࡬ࡦ࡮ࡩࡥࡰࡨࡻࡸ࠭Ꮥ")	:pcWq35MED2dtK(u"้ࠪํู่ࠡึส๋ิࠦๆ๋๊ีࠫᏖ")
	,iifPEY9ABNzTQp(u"ࠫ࡫ࡵࡳࡵࡣࠪᏗ")		:usaZLwSGe1k6VDp570yhB4bzWPiFq(u"๋่ࠬใ฻ࠣๅํูสศࠩᏘ")
	,ggDRehOModi(u"࠭ࡡࡩࡹࡤ࡯ࠬᏙ")		:qnPgZ9N15G6Oa8UpMASvLk(u"ࠧๆ๊ๅ฽ࠥษ็้ษๆࠤฯ๐แ๋ࠩᏚ")
	,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠨࡨࡤࡦࡷࡧ࡫ࡢࠩᏛ")		:InKG0i2r6hHDvgd(u"่ࠩ์็฿ࠠโสิ็ฮ࠭Ꮬ")
	,Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠪࡧ࡮ࡳࡡࡤ࡮ࡸࡦࡼࡵࡲ࡬ࠩᏝ")	:r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"๊ࠫ๎โฺࠢึ๎๊อࠠไๆ๋ฬࠥ฿ๅๅࠩᏞ")
	,wwplD0tEehqH3kYQXs(u"ࠬࡩࡩ࡮ࡣࡦࡰࡺࡨࠧᏟ")		:CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢๆ่ํฮࠧᏠ")
	,KKbpxUZnMcj6AJ4QdD(u"ࠧࡴࡪࡲࡪ࡭ࡧࠧᏡ")		:iifPEY9ABNzTQp(u"ࠨ็๋ๆ฾ࠦิ้ใ๊หࠥะ๊โ์ࠪᏢ")
	,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠩࡥࡶࡸࡺࡥ࡫ࠩᏣ")		:cgtRBdXxSOk7WUfyDhPCls(u"้ࠪํู่ࠡสิืฯ๐ฬࠨᏤ")
	,r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠫࡨ࡯࡭ࡢ࠶࠳࠴ࠬᏥ")		:drHLAY5ENQFe2q9ptKGabo(u"๋่ࠬใ฻ࠣื๏๋วࠡ࠶࠳࠴ࠬᏦ")
	,bbw2eajMlG(u"࠭࡬ࡢࡴࡲࡾࡦ࠭Ꮷ")		:XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧๆ๊ๅ฽๊ࠥวา๊ีหࠬᏨ")
	,nKLEi8CJumazx4qT(u"ࠨࡻࡤࡵࡴࡺࠧᏩ")		:CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"่ࠩ์็฿๋ࠠษๅ์ฯ࠭Ꮺ")
	,iifPEY9ABNzTQp(u"ࠪ࡯ࡦࡺ࡫ࡰࡷࡷࡩࠬᏫ")		:M6PIj8gl1fno7wcqTksDEBK4bU(u"๊ࠫ๎โฺࠢๆฮ่๎สࠨᏬ")
	,shZ9eOcN2dJnPj(u"ࠬࡱࡡࡵ࡭ࡲࡸࡹࡼࠧᏭ")		:nKLEi8CJumazx4qT(u"࠭ๅ้ไ฼ࠤ่ะใ้ฬࠣฮ๏็๊ࠨᏮ")
	,usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠧࡢࡴࡤࡦ࡮ࡩࡴࡰࡱࡱࡷࠬᏯ")	:pcWq35MED2dtK(u"ࠨ็๋ๆ฾ࠦส้่ีࠤ฾ืศ๋หࠪᏰ")
	,ggDRehOModi(u"ࠩࡧࡶࡦࡳࡡࡴ࠹ࠪᏱ")		:ggDRehOModi(u"้ࠪํู่ࠡัิห๊อࠠึฯࠪᏲ")
	,CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠫࡸ࡮࡯ࡰࡨࡳࡶࡴ࠭Ᏻ")		:ggDRehOModi(u"๋่ࠬใ฻ุࠣํ็ࠠษำ๋ࠫᏴ")
	,M6PIj8gl1fno7wcqTksDEBK4bU(u"࠭ࡩࡧ࡫࡯ࡱࠬᏵ")				:oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠧๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠫ᏶")
	,yruHDQOcB97ig(u"ࠨ࡫ࡩ࡭ࡱࡳ࠭ࡢࡴࡤࡦ࡮ࡩࠧ᏷")			:ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"่ࠩ์็฿ࠠใ่สอࠥศ๊ࠡใํู่๊ࠦาสํࠫᏸ")
	,usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠪ࡭࡫࡯࡬࡮࠯ࡨࡲ࡬ࡲࡩࡴࡪࠪᏹ")		:nKLEi8CJumazx4qT(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠡษ้ะ้๐า๋ࠩᏺ")
	,ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠬࡶࡡ࡯ࡧࡷࠫᏻ")				:cNaVb1vsT4qWOL0rpE(u"࠭ๅ้ไ฼ࠤออๆ๋ฬࠪᏼ")
	,r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠧࡱࡣࡱࡩࡹ࠳࡭ࡰࡸ࡬ࡩࡸ࠭ᏽ")			:wwplD0tEehqH3kYQXs(u"ࠨ็๋ๆ฾ࠦศศ่ํฮࠥอแๅษ่ࠫ᏾")
	,iifPEY9ABNzTQp(u"ࠩࡳࡥࡳ࡫ࡴ࠮ࡵࡨࡶ࡮࡫ࡳࠨ᏿")			:r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"้ࠪํู่ࠡสส๊๏ะࠠๆี็ื้อสࠨ᐀")
	,yF29Xdsx35wI07Ce4(u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬᐁ")				:BGhdkWsEvJjiMFTr3NLn1flU(u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠪᐂ")
	,drHLAY5ENQFe2q9ptKGabo(u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠧᐃ")		:bbw2eajMlG(u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠥ็๊ะ์๋๋ฬะࠧᐄ")
	,qnPgZ9N15G6Oa8UpMASvLk(u"ࠨࡻࡲࡹࡹࡻࡢࡦ࠯ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬᐅ")	:yruHDQOcB97ig(u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠใ๊สส๊࠭ᐆ")
	,tZ3gsrTEdzA1S6LXa9WI5px(u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠱ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ᐇ")		:ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢๅ๊ํอสࠨᐈ")
	,XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥࠨᐉ")			:bbw2eajMlG(u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠨᐊ")
	,XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧࡴࡪ࡬ࡥࡻࡵࡩࡤࡧ࠰ࡴࡪࡸࡳࡰࡰࡶࠫᐋ")	:M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠣๆฬืฦࠨᐌ")
	,Tgoa16jMxvYX2(u"ࠩࡶ࡬࡮ࡧࡶࡰ࡫ࡦࡩ࠲ࡧ࡬ࡣࡷࡰࡷࠬᐍ")		:yruHDQOcB97ig(u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠥอไษ๊่ࠫᐎ")
	,vvBChXmSty(u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫࠭ࡢࡷࡧ࡭ࡴࡹࠧᐏ")		:yruHDQOcB97ig(u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠠึ๊อ๎ฬะࠧᐐ")
	,Tgoa16jMxvYX2(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫᐑ")			:yruHDQOcB97ig(u"ࠧๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠨᐒ")
	,shZ9eOcN2dJnPj(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡶࡪࡦࡨࡳࡸ࠭ᐓ")	:wwplD0tEehqH3kYQXs(u"่ࠩ์็฿ࠠะ์็๎๋่ࠥี่ࠣๅ๏ี๊้้สฮࠬᐔ")
	,shZ9eOcN2dJnPj(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫᐕ"):KKbpxUZnMcj6AJ4QdD(u"๊ࠫ๎โฺࠢา๎้๐ࠠๆ๊ื๊่่ࠥศศ่ࠫᐖ")
	,tZ3gsrTEdzA1S6LXa9WI5px(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬᐗ")	:yF29Xdsx35wI07Ce4(u"࠭ๅ้ไ฼ࠤิ๐ไ๋่ࠢ์ู์ࠠใ่๋หฯ࠭ᐘ")
	,yF29Xdsx35wI07Ce4(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡺ࡯ࡱ࡫ࡦࡷࠬᐙ")	:wwplD0tEehqH3kYQXs(u"ࠨ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็่ࠢ์ฬ฼ฺ๊ࠩᐚ")
	,vvBChXmSty(u"ࠩ࡬ࡴࡹࡼࠧᐛ")					:yruHDQOcB97ig(u"ࠪࡍࡕ࡚ࡖࠨᐜ")
	,shZ9eOcN2dJnPj(u"ࠫ࡮ࡶࡴࡷ࠯࡯࡭ࡻ࡫ࠧᐝ")			:XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠬࡏࡐࡕࡘࠣๆ๋๎วหࠩᐞ")
	,KKbpxUZnMcj6AJ4QdD(u"࠭ࡩࡱࡶࡹ࠱ࡲࡵࡶࡪࡧࡶࠫᐟ")			:KKbpxUZnMcj6AJ4QdD(u"ࠧࡊࡒࡗ࡚ࠥษแๅษ่ࠫᐠ")
	,vvBChXmSty(u"ࠨ࡫ࡳࡸࡻ࠳ࡳࡦࡴ࡬ࡩࡸ࠭ᐡ")			:Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠩࡌࡔ࡙࡜ࠠๆี็ื้อสࠨᐢ")
	,Tgoa16jMxvYX2(u"ࠪࡱ࠸ࡻࠧᐣ")					:pcWq35MED2dtK(u"ࠫࡒ࠹ࡕࠨᐤ")
	,JLoPRXt93dpAB(u"ࠬࡳ࠳ࡶ࠯࡯࡭ࡻ࡫ࠧᐥ")				:n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠭ࡍ࠴ࡗࠣๆ๋๎วหࠩᐦ")
	,BGhdkWsEvJjiMFTr3NLn1flU(u"ࠧ࡮࠵ࡸ࠱ࡲࡵࡶࡪࡧࡶࠫᐧ")			:InKG0i2r6hHDvgd(u"ࠨࡏ࠶࡙ࠥษแๅษ่ࠫᐨ")
	,xuztI5QWEKG70CPNdhk4vo6(u"ࠩࡰ࠷ࡺ࠳ࡳࡦࡴ࡬ࡩࡸ࠭ᐩ")			:M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠪࡑ࠸࡛ࠠๆี็ื้อสࠨᐪ")
	}
	try: Pyk9zObnlCBGiM6mUo = XbnadV39UWNhzI2oqKiCOc5rfPmp0S[TwPt5qAHlrOsQ.lower()]
	except: Pyk9zObnlCBGiM6mUo = BGhdkWsEvJjiMFTr3NLn1flU(u"ࠫࠬᐫ")
	return Pyk9zObnlCBGiM6mUo
def vS1seWj2c0tKyZ(CWL8J3MFDRmtk029PKhsp6Zgbv=drHLAY5ENQFe2q9ptKGabo(u"ࠬ࠭ᐬ")):
	DFuBiZvslcm94Ia()
	if not CWL8J3MFDRmtk029PKhsp6Zgbv: CWL8J3MFDRmtk029PKhsp6Zgbv = bcgZJWV6UeNSkRA(u"࠭ࡆࡰࡴࡦࡩࡩࠦࡅࡹ࡫ࡷࠫᐭ")
	l0SAerv8zGH2Wa(bbw2eajMlG(u"ࠧࠨᐮ"),iifPEY9ABNzTQp(u"ࠨ࡞ࡱࠫᐯ")+CWL8J3MFDRmtk029PKhsp6Zgbv+shZ9eOcN2dJnPj(u"ࠩ࡟ࡲࠬᐰ"))
	try: vdo2FnhPmAVRMJQZ0EIG8.exit()
	except: pass
	return
def QQXTVNve6DMHBp4scG170kR2lWY(GMfo7WypIsRin9HKEZQduYhDetFJOS,hDlUiIR58qLKQpauSgcsezYZnJ=qnPgZ9N15G6Oa8UpMASvLk(u"ࠪ࠾࠴࠭ᐱ")):
	return _EfPkWJ8SLvZuBRj2nY(GMfo7WypIsRin9HKEZQduYhDetFJOS,hDlUiIR58qLKQpauSgcsezYZnJ)
def FdvQAqsfEcMjgkXpax3zJ4V1(AqX02CoEgnyVTHYWJ):
	if AqX02CoEgnyVTHYWJ in [M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠫࠬᐲ"),shZ9eOcN2dJnPj(u"ࠬ࠶ࠧᐳ"),pcWq35MED2dtK(u"࠳ᛑ")]: return r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠭ࠧᐴ")
	AqX02CoEgnyVTHYWJ = int(AqX02CoEgnyVTHYWJ)
	ovn3UFahLxg = AqX02CoEgnyVTHYWJ^ebm0Z72CDaBzUq
	g1bWOK2wDCrl4cY = AqX02CoEgnyVTHYWJ^QQJtZ6rMvS1wdDsHnahT7
	PnqG6E59iMJKL0lN21QftmezByTvI = AqX02CoEgnyVTHYWJ^hs8IDEMn0YuCHwk
	Pyk9zObnlCBGiM6mUo = str(ovn3UFahLxg)+str(g1bWOK2wDCrl4cY)+str(PnqG6E59iMJKL0lN21QftmezByTvI)
	return Pyk9zObnlCBGiM6mUo
def Oebo9ud6ji3GrWnY0NIK8pMAXgtBl(AqX02CoEgnyVTHYWJ):
	if AqX02CoEgnyVTHYWJ in [XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧࠨᐵ"),xuztI5QWEKG70CPNdhk4vo6(u"ࠨ࠲ࠪᐶ"),ggDRehOModi(u"࠴ᛒ")]: return XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠩࠪᐷ")
	AqX02CoEgnyVTHYWJ = str(AqX02CoEgnyVTHYWJ)
	Pyk9zObnlCBGiM6mUo = nKLEi8CJumazx4qT(u"ࠪࠫᐸ")
	if len(AqX02CoEgnyVTHYWJ)==M6PIj8gl1fno7wcqTksDEBK4bU(u"࠶࠻ᛓ"):
		ovn3UFahLxg,g1bWOK2wDCrl4cY,PnqG6E59iMJKL0lN21QftmezByTvI = AqX02CoEgnyVTHYWJ[tZ3gsrTEdzA1S6LXa9WI5px(u"࠰ᛕ"):Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠵ᛖ")],AqX02CoEgnyVTHYWJ[Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠵ᛖ"):KKbpxUZnMcj6AJ4QdD(u"࠿ᛔ")],AqX02CoEgnyVTHYWJ[KKbpxUZnMcj6AJ4QdD(u"࠿ᛔ"):]
		ovn3UFahLxg = int(ovn3UFahLxg)^hs8IDEMn0YuCHwk
		g1bWOK2wDCrl4cY = int(g1bWOK2wDCrl4cY)^QQJtZ6rMvS1wdDsHnahT7
		PnqG6E59iMJKL0lN21QftmezByTvI = int(PnqG6E59iMJKL0lN21QftmezByTvI)^ebm0Z72CDaBzUq
		if ovn3UFahLxg==g1bWOK2wDCrl4cY==PnqG6E59iMJKL0lN21QftmezByTvI: Pyk9zObnlCBGiM6mUo = str(ovn3UFahLxg*shZ9eOcN2dJnPj(u"࠸࠳ᛗ"))
	return Pyk9zObnlCBGiM6mUo
def ZAFhioq91YfduILWljSNxHDOB7(AqX02CoEgnyVTHYWJ,TT9UtOdEeIy7rzY23=pcWq35MED2dtK(u"ࠫ࠻࠹࠸࠵࠳࠻࠶࠸࠭ᐹ")):
	if AqX02CoEgnyVTHYWJ==JLoPRXt93dpAB(u"ࠬ࠭ᐺ"): return shZ9eOcN2dJnPj(u"࠭ࠧᐻ")
	AqX02CoEgnyVTHYWJ = int(AqX02CoEgnyVTHYWJ)+int(TT9UtOdEeIy7rzY23)
	ovn3UFahLxg = AqX02CoEgnyVTHYWJ^ebm0Z72CDaBzUq
	g1bWOK2wDCrl4cY = AqX02CoEgnyVTHYWJ^QQJtZ6rMvS1wdDsHnahT7
	PnqG6E59iMJKL0lN21QftmezByTvI = AqX02CoEgnyVTHYWJ^hs8IDEMn0YuCHwk
	Pyk9zObnlCBGiM6mUo = str(ovn3UFahLxg)+str(g1bWOK2wDCrl4cY)+str(PnqG6E59iMJKL0lN21QftmezByTvI)
	return Pyk9zObnlCBGiM6mUo
def pwVLbTukP0lCNQWg7Bz64v(AqX02CoEgnyVTHYWJ,TT9UtOdEeIy7rzY23=InKG0i2r6hHDvgd(u"ࠧ࠷࠵࠻࠸࠶࠾࠲࠴ࠩᐼ")):
	if AqX02CoEgnyVTHYWJ==qnPgZ9N15G6Oa8UpMASvLk(u"ࠨࠩᐽ"): return OyJ1o4AvmWlB75UkFRX(u"ࠩࠪᐾ")
	AqX02CoEgnyVTHYWJ = str(AqX02CoEgnyVTHYWJ)
	RQm6Y8H3oV = int(len(AqX02CoEgnyVTHYWJ)/PtXn0k9G3ocHRg(u"࠶ᛘ"))
	ovn3UFahLxg = int(AqX02CoEgnyVTHYWJ[yF29Xdsx35wI07Ce4(u"࠴ᛙ"):RQm6Y8H3oV])^ebm0Z72CDaBzUq
	g1bWOK2wDCrl4cY = int(AqX02CoEgnyVTHYWJ[RQm6Y8H3oV:xuztI5QWEKG70CPNdhk4vo6(u"࠷ᛚ")*RQm6Y8H3oV])^QQJtZ6rMvS1wdDsHnahT7
	PnqG6E59iMJKL0lN21QftmezByTvI = int(AqX02CoEgnyVTHYWJ[ggDRehOModi(u"࠲ᛜ")*RQm6Y8H3oV:BGhdkWsEvJjiMFTr3NLn1flU(u"࠹ᛛ")*RQm6Y8H3oV])^hs8IDEMn0YuCHwk
	Pyk9zObnlCBGiM6mUo = BGhdkWsEvJjiMFTr3NLn1flU(u"ࠪࠫᐿ")
	if ovn3UFahLxg==g1bWOK2wDCrl4cY==PnqG6E59iMJKL0lN21QftmezByTvI: Pyk9zObnlCBGiM6mUo = str(int(ovn3UFahLxg)-int(TT9UtOdEeIy7rzY23))
	return Pyk9zObnlCBGiM6mUo
def NNR12uCXPn3V(tzVrBNnMEWYU2eJ0hs1S):
	vUmgRZJaPNQ0Md241EjV8 = pgPfwZleTHVQ9a[iifPEY9ABNzTQp(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫᑀ")][Tgoa16jMxvYX2(u"࠹ᛝ")]
	GP3y0z7oxbmF = lbFixEt3BK9YGMyWIQZuSsp1V7JTL8(nKLEi8CJumazx4qT(u"࠵࠵ᛞ"))
	D90f3i8SbCgdKGRrhXBvOTLuFUAnZj = k1t0JLRsCQ.path.join(b69iT7LWwrfXzGYPMvBCsteVHDQK,yF29Xdsx35wI07Ce4(u"ࠬࡸࡥࡴࡱࡸࡶࡨ࡫ࡳࠨᑁ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"࠭ࡳ࡬࡫ࡱࡷࠬᑂ"),vvBChXmSty(u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨᑃ"),cgtRBdXxSOk7WUfyDhPCls(u"ࠨ࠹࠵࠴ࡵ࠭ᑄ"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡅࡲࡲ࡫࡯ࡲ࡮ࡖ࡫ࡶࡪ࡫ࡂࡶࡶࡷࡳࡳࡹ࠮ࡹ࡯࡯ࠫᑅ"))
	bHqJwkjAh3Of7isCET0,fCaeBFwmx8Zl6DbvtW7 = FLTvHN0VMOGiZ29(D90f3i8SbCgdKGRrhXBvOTLuFUAnZj)
	bHqJwkjAh3Of7isCET0 = ZAFhioq91YfduILWljSNxHDOB7(bHqJwkjAh3Of7isCET0,nKLEi8CJumazx4qT(u"ࠪ࠵࠷࠷࠸࠴࠳࠻࠹࠸࠭ᑆ"))
	bmiAPZUdS2okXFqhWEG8ML5v9lzp = {wwplD0tEehqH3kYQXs(u"ࠫ࡮ࡪࡳࠨᑇ"):shZ9eOcN2dJnPj(u"ࠬࡊࡉࡂࡎࡒࡋࠬᑈ"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠭ࡵࡴࡴࠪᑉ"):GP3y0z7oxbmF,xuztI5QWEKG70CPNdhk4vo6(u"ࠧࡷࡧࡵࠫᑊ"):qkSQU3saP0D7OvynNzH4F2BKJuilT,M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠨࡵࡦࡶࠬᑋ"):tzVrBNnMEWYU2eJ0hs1S,wwplD0tEehqH3kYQXs(u"ࠩࡶ࡭ࡿ࠭ᑌ"):bHqJwkjAh3Of7isCET0}
	d7I8Hthp9r2bza = {n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩᑍ"):r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪᑎ")}
	x4VubU6w0ih1NtSo3zQkKBCcO5 = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,KKbpxUZnMcj6AJ4QdD(u"ࠬࡖࡏࡔࡖࠪᑏ"),vUmgRZJaPNQ0Md241EjV8,bmiAPZUdS2okXFqhWEG8ML5v9lzp,d7I8Hthp9r2bza,ggDRehOModi(u"࠭ࠧᑐ"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠧࠨᑑ"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡌࡔ࡝࡟ࡑࡎࡄ࡝ࡤࡊࡉࡂࡎࡒࡋ࠲࠷ࡳࡵࠩᑒ"))
	pC9LPc3UVo8zErOZK7mRNDXdH6 = x4VubU6w0ih1NtSo3zQkKBCcO5.content
	try:
		if not pC9LPc3UVo8zErOZK7mRNDXdH6: FFG8k3vKSer9hN25TVJPLwsR
		XXJCTR1LY0ynxbuN6kpW5 = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ(shZ9eOcN2dJnPj(u"ࠩࡧ࡭ࡨࡺࠧᑓ"),pC9LPc3UVo8zErOZK7mRNDXdH6)
		JJpeL53QAVZm6 = XXJCTR1LY0ynxbuN6kpW5[oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠪࡱࡸ࡭ࠧᑔ")]
		vIenq5sz9X = XXJCTR1LY0ynxbuN6kpW5[wwplD0tEehqH3kYQXs(u"ࠫࡸ࡫ࡣࠨᑕ")]
		HFNgEv38Xyn059p = XXJCTR1LY0ynxbuN6kpW5[xuztI5QWEKG70CPNdhk4vo6(u"ࠬࡹࡴࡱࠩᑖ")]
		vIenq5sz9X = int(pwVLbTukP0lCNQWg7Bz64v(vIenq5sz9X,r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠭࠱࠳࠳࠻࠷࠶࠾࠵࠴ࠩᑗ")))
		HFNgEv38Xyn059p = int(pwVLbTukP0lCNQWg7Bz64v(HFNgEv38Xyn059p,Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠧ࠲࠴࠴࠼࠸࠷࠸࠶࠵ࠪᑘ")))
		for Xz4VB5HEpLD in range(vIenq5sz9X,iifPEY9ABNzTQp(u"࠳ᛟ"),-HFNgEv38Xyn059p):
			if not eval(usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠨࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯࡫ࡶࡔࡱࡧࡹࡪࡰࡪ࡚࡮ࡪࡥࡰࠪࠬࠫᑙ"),{bcgZJWV6UeNSkRA(u"ࠩࡻࡦࡲࡩࠧᑚ"):bMIascyFJ2x43E0C7glTB91h8qz}): FFG8k3vKSer9hN25TVJPLwsR
			dnS80F92qtLi4vw1(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠪฬฬ่๊ࠡๆ็ฮัืศส๋ࠢห้็อึࠩᑛ"),str(Xz4VB5HEpLD)+yruHDQOcB97ig(u"ࠫࠥࠦหศ่ํอࠬᑜ"),YVJPFvuI2CS5KObiZt=vvBChXmSty(u"࠷࠵࠶ᛠ")*HFNgEv38Xyn059p)
			bMIascyFJ2x43E0C7glTB91h8qz.sleep(InKG0i2r6hHDvgd(u"࠶࠶࠰࠱ᛡ")*HFNgEv38Xyn059p)
		if eval(JLoPRXt93dpAB(u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳࡯ࡳࡑ࡮ࡤࡽ࡮ࡴࡧࡗ࡫ࡧࡩࡴ࠮ࠩࠨᑝ"),{M6PIj8gl1fno7wcqTksDEBK4bU(u"࠭ࡸࡣ࡯ࡦࠫᑞ"):bMIascyFJ2x43E0C7glTB91h8qz}):
			JJpeL53QAVZm6 = JJpeL53QAVZm6.replace(yF29Xdsx35wI07Ce4(u"ࠧ࡝ࡰࠪᑟ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠨ࡞࡟ࡲࠬᑠ")).replace(vvBChXmSty(u"ࠩ࡟ࡶࠬᑡ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠪࡠࡡࡸࠧᑢ"))
			xl9MFt1AmY0GrkENug8n(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠫࠬᑣ"),vvBChXmSty(u"ࠬิั้ฮࠪᑤ"),tZ3gsrTEdzA1S6LXa9WI5px(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᑥ"),JJpeL53QAVZm6)
		FFG8k3vKSer9hN25TVJPLwsR
	except: exec(xuztI5QWEKG70CPNdhk4vo6(u"ࠧࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡴࡶࡲࡴ࠭࠯ࠧᑦ"),{BGhdkWsEvJjiMFTr3NLn1flU(u"ࠨࡺࡥࡱࡨ࠭ᑧ"):bMIascyFJ2x43E0C7glTB91h8qz})
	return
def VGZkudOFTQHgCiM7vY5oezcP():
	exec(nKLEi8CJumazx4qT(u"ࠩࠪࠫࠒࠐࡴࡳࡻ࠽ࠑࠏࠏࡷࡪࡰࡧࡳࡼ࠷࠲࠴ࠢࡀࠤࡽࡨ࡭ࡤࡩࡸ࡭࠳࡝ࡩ࡯ࡦࡲࡻ࠭࠷࠰࠱࠴࠸࠭ࠒࠐࠉࡸࡪ࡬ࡰࡪࠦࡔࡳࡷࡨ࠾ࠒࠐࠉࠊࡺࡥࡱࡨ࠴ࡳ࡭ࡧࡨࡴ࠭࠷࠰࠱࠲ࠬࠑࠏࠏࠉࡵࡴࡼ࠾ࠥࡽࡩ࡯ࡦࡲࡻ࠶࠸࠳࠯ࡩࡨࡸࡋࡵࡣࡶࡵࠫ࠵࠵࠶࠲࠶ࠫࠐࠎࠎࠏࡥࡹࡥࡨࡴࡹࡀࠠࡣࡴࡨࡥࡰࠓࠊࠊࡼࡦࡶࡪࡧࡴࡦࡡࡨࡶࡴࡸࡲࠎࠌࡨࡼࡨ࡫ࡰࡵ࠼ࠣࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱ࡷࡹࡵࡰࠩࠫࠐࠎࠬ࠭ࠧᑨ"),{Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠪࡼࡧࡳࡣࡨࡷ࡬ࠫᑩ"):XuWPVcQ13oDq5swf0S,ggDRehOModi(u"ࠫࡽࡨ࡭ࡤࠩᑪ"):bMIascyFJ2x43E0C7glTB91h8qz})
	return
def FLTvHN0VMOGiZ29(lqTODkKeBU3zhrPXwxa57idC8):
	Csy20FI6uMQ38cpR,tDlfOHiebr0MUx765c = r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠶ᛢ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠶ᛢ")
	if k1t0JLRsCQ.path.exists(lqTODkKeBU3zhrPXwxa57idC8):
		try: Csy20FI6uMQ38cpR = k1t0JLRsCQ.path.getsize(lqTODkKeBU3zhrPXwxa57idC8)
		except: pass
		if not Csy20FI6uMQ38cpR:
			try: Csy20FI6uMQ38cpR = k1t0JLRsCQ.stat(lqTODkKeBU3zhrPXwxa57idC8).st_size
			except: pass
		if not Csy20FI6uMQ38cpR:
			try:
				from pathlib import Path as zQRmNADoMIlt5XF1xdV0746CgfwG
				Csy20FI6uMQ38cpR = zQRmNADoMIlt5XF1xdV0746CgfwG(lqTODkKeBU3zhrPXwxa57idC8).stat().st_size
			except: pass
		if Csy20FI6uMQ38cpR: tDlfOHiebr0MUx765c = XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠱ᛣ")
	return Csy20FI6uMQ38cpR,tDlfOHiebr0MUx765c
def DzIGOoUJcZT9tQeuX3RyY(LjAEBFNTQD8oZ1r4hWO,DxUlAgLiv0ozXwYKOqBcEVF2,showDialogs):
	if showDialogs:
		iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(drHLAY5ENQFe2q9ptKGabo(u"ࠬ࠭ᑫ"),Tgoa16jMxvYX2(u"࠭ࠧᑬ"),vvBChXmSty(u"ࠧࠨᑭ"),JLoPRXt93dpAB(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᑮ"),LjAEBFNTQD8oZ1r4hWO+xuztI5QWEKG70CPNdhk4vo6(u"ࠩ࡟ࡲࡡࡴࠧᑯ")+yF29Xdsx35wI07Ce4(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่ะ้ีࠠภࠣ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᑰ"))
		if iZL6cN3OkM5!=KKbpxUZnMcj6AJ4QdD(u"࠲ᛤ"): return
	lHqTf6UMy5pvbe0nK = r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࡉࡥࡱࡹࡥ᝝")
	if k1t0JLRsCQ.path.exists(LjAEBFNTQD8oZ1r4hWO):
		for D9sahrGnjl,zzO5Jhgo8A,Yugbp5vmkGExP3BwhcJ0Z14Hzyf in k1t0JLRsCQ.walk(LjAEBFNTQD8oZ1r4hWO,topdown=wwplD0tEehqH3kYQXs(u"ࡊࡦࡲࡳࡦ᝞")):
			for lqTODkKeBU3zhrPXwxa57idC8 in Yugbp5vmkGExP3BwhcJ0Z14Hzyf:
				bS0aA1YrmwCj8fpLdXt = k1t0JLRsCQ.path.join(D9sahrGnjl,lqTODkKeBU3zhrPXwxa57idC8)
				try: k1t0JLRsCQ.remove(bS0aA1YrmwCj8fpLdXt)
				except Exception as PqOkienNW3ToVcX1ZM8Q:
					if showDialogs and not lHqTf6UMy5pvbe0nK: xl9MFt1AmY0GrkENug8n(OyJ1o4AvmWlB75UkFRX(u"ࠫࠬᑱ"),Tgoa16jMxvYX2(u"ࠬ࠭ᑲ"),wwplD0tEehqH3kYQXs(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᑳ"),str(PqOkienNW3ToVcX1ZM8Q))
					lHqTf6UMy5pvbe0nK = Tgoa16jMxvYX2(u"࡙ࡸࡵࡦ᝟")
			if DxUlAgLiv0ozXwYKOqBcEVF2:
				for dir in zzO5Jhgo8A:
					dAQI96bVKJcu2FwjCYiyfU50BN = k1t0JLRsCQ.path.join(D9sahrGnjl,dir)
					try: k1t0JLRsCQ.rmdir(dAQI96bVKJcu2FwjCYiyfU50BN)
					except: pass
		if DxUlAgLiv0ozXwYKOqBcEVF2:
			try: k1t0JLRsCQ.rmdir(D9sahrGnjl)
			except: pass
	if showDialogs and not lHqTf6UMy5pvbe0nK:
		xl9MFt1AmY0GrkENug8n(cNaVb1vsT4qWOL0rpE(u"ࠧࠨᑴ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠨࠩᑵ"),bcgZJWV6UeNSkRA(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᑶ"),wwplD0tEehqH3kYQXs(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫᑷ"))
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(yruHDQOcB97ig(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨᑸ"),Tgoa16jMxvYX2(u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨᑹ"))
		bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(OyJ1o4AvmWlB75UkFRX(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪᑺ"))
	return
def DFuBiZvslcm94Ia(LdvB61qxSDsOWlhmXnAgozEfPp4Ky=tZ3gsrTEdzA1S6LXa9WI5px(u"ࠧࠨᑻ")):
	vvZxzV4CkyoPTs(r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠨࡵࡷࡳࡵ࠭ᑼ"))
	if LdvB61qxSDsOWlhmXnAgozEfPp4Ky:
		E8qsiIj175HeVBgFQ = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪᑽ"))
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(iifPEY9ABNzTQp(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫᑾ"),bcgZJWV6UeNSkRA(u"ࠫࠬᑿ"))
		OEZ5f7K4jQpUJDnFaHNCdhPc(LdvB61qxSDsOWlhmXnAgozEfPp4Ky)
		LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(InKG0i2r6hHDvgd(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭ᒀ"),E8qsiIj175HeVBgFQ)
	hPvDUWG0xTNq6kC = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(iifPEY9ABNzTQp(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪᒁ"))
	if hPvDUWG0xTNq6kC==InKG0i2r6hHDvgd(u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡆࡆࠪᒂ"): LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬᒃ"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡈࡈࠬᒄ"))
	elif hPvDUWG0xTNq6kC==shZ9eOcN2dJnPj(u"ࠪࡖࡊࡌࡒࡆࡕࡋࡉࡉ࠭ᒅ"): LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(KKbpxUZnMcj6AJ4QdD(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨᒆ"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠬ࠭ᒇ"))
	if LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(PtXn0k9G3ocHRg(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩᒈ")) not in [bbw2eajMlG(u"ࠧࡂࡗࡗࡓࠬᒉ"),shZ9eOcN2dJnPj(u"ࠨࡕࡗࡓࡕ࠭ᒊ"),Tgoa16jMxvYX2(u"ࠩࡄࡗࡐ࠭ᒋ")]: LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(nKLEi8CJumazx4qT(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ᒌ"),cNaVb1vsT4qWOL0rpE(u"ࠫࡆ࡙ࡋࠨᒍ"))
	if LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪᒎ")) not in [XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠭ࡁࡖࡖࡒࠫᒏ"),cNaVb1vsT4qWOL0rpE(u"ࠧࡔࡖࡒࡔࠬᒐ"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠨࡃࡖࡏࠬᒑ")]: LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(shZ9eOcN2dJnPj(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧᒒ"),cgtRBdXxSOk7WUfyDhPCls(u"ࠪࡅࡘࡑࠧᒓ"))
	yyTVN1vPAmSjgKLsur8i5Fz = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(cgtRBdXxSOk7WUfyDhPCls(u"ࠫࡦࡼ࠮࡮ࡻࡶ࡯࡮ࡴ࠮ࡷ࡫ࡨࡻࡲࡵࡤࡦࠩᒔ"))
	sWXx2MJmLGl = bMIascyFJ2x43E0C7glTB91h8qz.executeJSONRPC(cgtRBdXxSOk7WUfyDhPCls(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨᒕ"))
	if tZ3gsrTEdzA1S6LXa9WI5px(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬᒖ") in str(sWXx2MJmLGl) and yyTVN1vPAmSjgKLsur8i5Fz in [yF29Xdsx35wI07Ce4(u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪᒗ"),n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧᒘ")]:
		YVJPFvuI2CS5KObiZt.sleep(usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠲࠱࠵࠵࠶ᛥ"))
		bMIascyFJ2x43E0C7glTB91h8qz.executebuiltin(usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡙ࡥࡵࡘ࡬ࡩࡼࡓ࡯ࡥࡧࠫ࠴࠮࠭ᒙ"))
	if nKLEi8CJumazx4qT(u"࠴ᛧ") and Y40Szd1kTwqQxFXm6HO8tRlAvepK>-xuztI5QWEKG70CPNdhk4vo6(u"࠴ᛦ"):
		oejGsrTCZ05k2X7LlHnPa3h8vzAbJy.setResolvedUrl(Y40Szd1kTwqQxFXm6HO8tRlAvepK,qnPgZ9N15G6Oa8UpMASvLk(u"ࡌࡡ࡭ࡵࡨᝠ"),XuWPVcQ13oDq5swf0S.ListItem())
		V5VXz0j3oa6t,mJXMyc9qFDbnif8LEz0hgSt3w5,e3jIULCymkiwXQG = usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࡆࡢ࡮ࡶࡩᝡ"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࡆࡢ࡮ࡶࡩᝡ"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࡆࡢ࡮ࡶࡩᝡ")
		oejGsrTCZ05k2X7LlHnPa3h8vzAbJy.endOfDirectory(Y40Szd1kTwqQxFXm6HO8tRlAvepK,V5VXz0j3oa6t,mJXMyc9qFDbnif8LEz0hgSt3w5,e3jIULCymkiwXQG)
	return
def lVwNyt5c8I1HzOdKinf4(nO1lCyXmdAfQa0MBkEg7I5DGbN2jc,Fu63RmidlUsQIgCcOypVYeo,GMfo7WypIsRin9HKEZQduYhDetFJOS,MNWrTo98GZHn,vSj57P0g4mF2Bp,BYGZC29KJ5Piag36Dl):
	gANn35esloKUydOipfSMC6RD2,UdvjsK7fcmtokh8z,G9OmMTVLjrK5su6Yvt8XUx,MsqPuhEKTC39NDwxZd = rRjtH4UFBNVayeEYwl6dobvg(GMfo7WypIsRin9HKEZQduYhDetFJOS)
	YI2m5zkZ3ASWF8jK = Fu63RmidlUsQIgCcOypVYeo,gANn35esloKUydOipfSMC6RD2,MNWrTo98GZHn,vSj57P0g4mF2Bp
	if nO1lCyXmdAfQa0MBkEg7I5DGbN2jc:
		DMqcCpg8GmefYtWJZITSP29x3nLzO = AsTbx64cCEi1(bpNSygerL10j4IOkEfuVw,wwplD0tEehqH3kYQXs(u"ࠪࡷࡹࡸࠧᒚ"),vvBChXmSty(u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤ࡛ࡒࡍࡎࡌࡆࠬᒛ"),YI2m5zkZ3ASWF8jK)
		if DMqcCpg8GmefYtWJZITSP29x3nLzO:
			u5VpIfdK9HTnYk(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࡛ࠬࡒࡍࡎࡌࡆࠥࠦࡒࡆࡃࡇࡣࡈࡇࡃࡉࡇࠪᒜ"),GMfo7WypIsRin9HKEZQduYhDetFJOS,MNWrTo98GZHn,vSj57P0g4mF2Bp,BYGZC29KJ5Piag36Dl,Fu63RmidlUsQIgCcOypVYeo)
			return DMqcCpg8GmefYtWJZITSP29x3nLzO
	DMqcCpg8GmefYtWJZITSP29x3nLzO = LOe4X6kYET(Fu63RmidlUsQIgCcOypVYeo,GMfo7WypIsRin9HKEZQduYhDetFJOS,MNWrTo98GZHn,vSj57P0g4mF2Bp,BYGZC29KJ5Piag36Dl)
	if DMqcCpg8GmefYtWJZITSP29x3nLzO and nO1lCyXmdAfQa0MBkEg7I5DGbN2jc: OtQdRGpqKfBYkElSb0v9hsPrJ3DZ8(bpNSygerL10j4IOkEfuVw,JLoPRXt93dpAB(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡖࡔࡏࡐࡎࡈࠧᒝ"),YI2m5zkZ3ASWF8jK,DMqcCpg8GmefYtWJZITSP29x3nLzO,nO1lCyXmdAfQa0MBkEg7I5DGbN2jc)
	return DMqcCpg8GmefYtWJZITSP29x3nLzO
from XnQDyzrw2j import *
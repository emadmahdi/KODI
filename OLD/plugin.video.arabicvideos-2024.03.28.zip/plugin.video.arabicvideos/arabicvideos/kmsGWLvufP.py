# -*- coding: utf-8 -*-
from LXgKztbkOf import *
headers = { 'User-Agent' : '' }
aUVSgO2ebjwX5iqPykC = 'AKOAMCAM'
tiCRYyX1bWd40Ir3PafQu = '_AKC_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['مصارعة']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==350: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==351: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,text)
	elif mode==352: vS7JufTVsBxw52 = GA2KIlbOsoYtxpkDF71(url)
	elif mode==353: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==354: vS7JufTVsBxw52 = WYxFZIrRp6b(url,'FILTERS___'+text)
	elif mode==355: vS7JufTVsBxw52 = WYxFZIrRp6b(url,'CATEGORIES___'+text)
	elif mode==356: vS7JufTVsBxw52 = KWCsyjAr073LzMqDaJ2UeB(url)
	elif mode==357: vS7JufTVsBxw52 = ea5qUyg04wIMVZdPCkfJbviFOH1(url)
	elif mode==359: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	uQNUfbZx9yj0F('link',tiCRYyX1bWd40Ir3PafQu+'[COLOR FFFFFF00]هذا الموقع مغلق[/COLOR]','',8)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',359,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فلتر محدد',yONJxHER9BIDPpTV4YsWmc0n,356)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فلتر كامل',yONJxHER9BIDPpTV4YsWmc0n,357)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,yONJxHER9BIDPpTV4YsWmc0n,'',headers,'','AKOAMCAM-MENU-1st')
	gANn35esloKUydOipfSMC6RD2 = u5h2Rckvw1E.findall('recently-container.*?href="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if gANn35esloKUydOipfSMC6RD2: gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2[0]
	else: gANn35esloKUydOipfSMC6RD2 = yONJxHER9BIDPpTV4YsWmc0n
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'اضيف حديثا',gANn35esloKUydOipfSMC6RD2,351)
	gANn35esloKUydOipfSMC6RD2 = u5h2Rckvw1E.findall('@id":"(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if gANn35esloKUydOipfSMC6RD2: gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2[0]
	else: gANn35esloKUydOipfSMC6RD2 = yONJxHER9BIDPpTV4YsWmc0n
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'المميزة',gANn35esloKUydOipfSMC6RD2,351,'','','featured')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('main-categories-list(.*?)main-categories-list',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?class="font.*?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if title not in WLI5tgXRbUPNGJCSVz0vKjBDei3: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,351)
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="categories-box(.*?)<footer',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			ekTrZlFMu0Kf5QztEnhAs = uTUNPkVwCMKiD5gHLaj(ekTrZlFMu0Kf5QztEnhAs)
			if title not in WLI5tgXRbUPNGJCSVz0vKjBDei3: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,351)
	return oo9SgGkiDbs3HRn7z8
def KWCsyjAr073LzMqDaJ2UeB(website=''):
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,yONJxHER9BIDPpTV4YsWmc0n,'',headers,'','AKOAMCAM-MENU-1st')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="menu(.*?)<nav',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?text">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if title not in WLI5tgXRbUPNGJCSVz0vKjBDei3:
				title = title+' مصنفة'
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,355)
		if website=='': uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return oo9SgGkiDbs3HRn7z8
def ea5qUyg04wIMVZdPCkfJbviFOH1(website=''):
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,yONJxHER9BIDPpTV4YsWmc0n,'',headers,'','AKOAMCAM-MENU-1st')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="menu(.*?)<nav',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?text">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if title not in WLI5tgXRbUPNGJCSVz0vKjBDei3:
				title = title+' مفلترة'
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,354)
		if website=='': uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return oo9SgGkiDbs3HRn7z8
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,type=''):
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(a2VuAbpQkGfMwSIcsP1XH6mletyzx,url,'',headers,True,'AKOAMCAM-TITLES-1st')
	if type=='featured': cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('swiper-container(.*?)swiper-button-prev',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	else: cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="container"(.*?)main-footer',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('xlink:href="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		yn8DkpE5etF3WiUmfSO = []
		for pGjsvdyHfM,ekTrZlFMu0Kf5QztEnhAs,title in items:
			title = uTUNPkVwCMKiD5gHLaj(title)
			if 'الحلقة' in title or 'الحلقه' in title:
				zAjwuoRY98mXN6xvE = u5h2Rckvw1E.findall('(.*?) (الحلقة|الحلقه) \d+',title,u5h2Rckvw1E.DOTALL)
				if zAjwuoRY98mXN6xvE:
					title = '_MOD_' + zAjwuoRY98mXN6xvE[0][0]
					if title not in yn8DkpE5etF3WiUmfSO:
						uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,352,pGjsvdyHfM)
						yn8DkpE5etF3WiUmfSO.append(title)
			elif 'مسلسل' in title:
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,352,pGjsvdyHfM)
			else: uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,353,pGjsvdyHfM)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('pagination(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href=["\'](.*?)["\'].*?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			ekTrZlFMu0Kf5QztEnhAs = uTUNPkVwCMKiD5gHLaj(ekTrZlFMu0Kf5QztEnhAs)
			title = uTUNPkVwCMKiD5gHLaj(title)
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+title,ekTrZlFMu0Kf5QztEnhAs,351)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	GHFUMEOSrvhmIoVWxwN8j4 = search.replace(' ','+')
	url = yONJxHER9BIDPpTV4YsWmc0n + '/?s='+GHFUMEOSrvhmIoVWxwN8j4
	vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url)
	return
def GA2KIlbOsoYtxpkDF71(url):
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,url,'',headers,True,'AKOAMCAM-EPISODES-1st')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('text-white">الحلقات(.*?)<header',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		Ez1AbVgerRU0YimHu45t9DI7qM = u5h2Rckvw1E.findall('href="(http.*?)".*?src="(.*?)".*?alt="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in Ez1AbVgerRU0YimHu45t9DI7qM:
			if 'الحلقة' in title or 'الحلقه' in title: uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,353,pGjsvdyHfM)
	else:
		pGjsvdyHfM = bMIascyFJ2x43E0C7glTB91h8qz.getInfoLabel('ListItem.Icon')
		if oo9SgGkiDbs3HRn7z8.count('<title>')>1: title = u5h2Rckvw1E.findall('<title>(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)[1]
		else: title = 'رابط التشغيل'
		uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,url,353,pGjsvdyHfM)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	EaBeVhOsHYg8wub,hVby8e3aQkFfuE = [],[]
	v0vy7OlUSEen4tqNKBafwzkMsch = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',url,'','','','','AKOAMCAM-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = v0vy7OlUSEen4tqNKBafwzkMsch.content
	QKdSLIz9q017ARY = u5h2Rckvw1E.findall('post_id=(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if QKdSLIz9q017ARY:
		QKdSLIz9q017ARY = QKdSLIz9q017ARY[0]
		headers = {'User-Agent':'','Content-Type':'application/x-www-form-urlencoded'}
		data = {'post_id':QKdSLIz9q017ARY}
		gANn35esloKUydOipfSMC6RD2 = yONJxHER9BIDPpTV4YsWmc0n+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Watch.php'
		wgv2ARQPW3 = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'POST',gANn35esloKUydOipfSMC6RD2,data,headers,'','','AKOAMCAM-PLAY-1st')
		ZCOosjaQ8x9HDKSVGM6LwW2vy = wgv2ARQPW3.content
		items = u5h2Rckvw1E.findall('data-server="(.*?)".*?class="text">(.*?)<',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)
		for bbLlyzvIcPRU7e4pGBD,name in items:
			ekTrZlFMu0Kf5QztEnhAs = 'https://w.akoam.cam/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Server.php'
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?postid='+QKdSLIz9q017ARY+'&serverid='+bbLlyzvIcPRU7e4pGBD+'?named='+name+'__watch'
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
			hVby8e3aQkFfuE.append(name)
		gANn35esloKUydOipfSMC6RD2 = yONJxHER9BIDPpTV4YsWmc0n+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Download.php'
		wgv2ARQPW3 = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'POST',gANn35esloKUydOipfSMC6RD2,data,headers,'','','AKOAMCAM-PLAY-1st')
		ZCOosjaQ8x9HDKSVGM6LwW2vy = wgv2ARQPW3.content
		items = u5h2Rckvw1E.findall('href="(.*?)".*?class="text">(.*?)<',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.strip(' ')
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+title+'__download'
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
			hVby8e3aQkFfuE.append(title)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(EaBeVhOsHYg8wub,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def WYxFZIrRp6b(url,filter):
	BVNnjYeCa3AfgTv0u6R = ['cat','genre','release-year','quality','orderby']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter=='': lvUP2GeNjyVOHKJxcBoun3Z,MoELTBDgQeaJrl0zYUmKCH = '',''
	else: lvUP2GeNjyVOHKJxcBoun3Z,MoELTBDgQeaJrl0zYUmKCH = filter.split('___')
	if type=='CATEGORIES':
		if BVNnjYeCa3AfgTv0u6R[0]+'=' not in lvUP2GeNjyVOHKJxcBoun3Z: oPrhaMp7AqmNnRjlXGI = BVNnjYeCa3AfgTv0u6R[0]
		for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in range(len(BVNnjYeCa3AfgTv0u6R[0:-1])):
			if BVNnjYeCa3AfgTv0u6R[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE]+'=' in lvUP2GeNjyVOHKJxcBoun3Z: oPrhaMp7AqmNnRjlXGI = BVNnjYeCa3AfgTv0u6R[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE+1]
		WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&'+oPrhaMp7AqmNnRjlXGI+'=0'
		z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&'+oPrhaMp7AqmNnRjlXGI+'=0'
		bIYSyA3BD1o4 = WGiMcqkRetEJVrSI.strip('&')+'___'+z3wGSEWqVy1Qh5N.strip('&')
		TBFfiRI52ZmKwO1JLSD = mltWBSPJz5H4VRdCAa1(MoELTBDgQeaJrl0zYUmKCH,'all')
		gANn35esloKUydOipfSMC6RD2 = url+'?'+TBFfiRI52ZmKwO1JLSD
	elif type=='FILTERS':
		lv2uANOtVxE8RTa7bYHqLog1Bd = mltWBSPJz5H4VRdCAa1(lvUP2GeNjyVOHKJxcBoun3Z,'modified_values')
		lv2uANOtVxE8RTa7bYHqLog1Bd = P2o6ZDHeW790pSQqucvnxzILVUX(lv2uANOtVxE8RTa7bYHqLog1Bd)
		if MoELTBDgQeaJrl0zYUmKCH!='': MoELTBDgQeaJrl0zYUmKCH = mltWBSPJz5H4VRdCAa1(MoELTBDgQeaJrl0zYUmKCH,'all')
		if MoELTBDgQeaJrl0zYUmKCH=='': gANn35esloKUydOipfSMC6RD2 = url
		else: gANn35esloKUydOipfSMC6RD2 = url+'?'+MoELTBDgQeaJrl0zYUmKCH
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'أظهار قائمة الفيديو التي تم اختيارها',gANn35esloKUydOipfSMC6RD2,351,'','1')
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+' [[   '+lv2uANOtVxE8RTa7bYHqLog1Bd+'   ]]',gANn35esloKUydOipfSMC6RD2,351,'','1')
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,url,'',headers,True,'AKOAMCAM-FILTERS_MENU-1st')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('<form id(.*?)</form>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	cGdHRiwvptVXQlzE8ZUgB0aJo9x = u5h2Rckvw1E.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	dict = {}
	for Uiy0XwPusDg4vAFc35oYdfGnOrV,name,lmO2YJGr6tCV in cGdHRiwvptVXQlzE8ZUgB0aJo9x:
		items = u5h2Rckvw1E.findall('<option(.*?)>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if '=' not in gANn35esloKUydOipfSMC6RD2: gANn35esloKUydOipfSMC6RD2 = url
		if type=='CATEGORIES':
			if oPrhaMp7AqmNnRjlXGI!=Uiy0XwPusDg4vAFc35oYdfGnOrV: continue
			elif len(items)<=1:
				if Uiy0XwPusDg4vAFc35oYdfGnOrV==BVNnjYeCa3AfgTv0u6R[-1]: ll0a2AwztChcpsDUMi4rGW3b61XZES(gANn35esloKUydOipfSMC6RD2)
				else: WYxFZIrRp6b(gANn35esloKUydOipfSMC6RD2,'CATEGORIES___'+bIYSyA3BD1o4)
				return
			else:
				if Uiy0XwPusDg4vAFc35oYdfGnOrV==BVNnjYeCa3AfgTv0u6R[-1]: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع',gANn35esloKUydOipfSMC6RD2,351,'','1')
				else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع',gANn35esloKUydOipfSMC6RD2,355,'','',bIYSyA3BD1o4)
		elif type=='FILTERS':
			WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'=0'
			z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'=0'
			bIYSyA3BD1o4 = WGiMcqkRetEJVrSI+'___'+z3wGSEWqVy1Qh5N
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'الجميع : '+name,gANn35esloKUydOipfSMC6RD2,354,'','',bIYSyA3BD1o4)
		dict[Uiy0XwPusDg4vAFc35oYdfGnOrV] = {}
		for c2eEflztvIX,q1rVywkMcKftIioS43LY in items:
			if q1rVywkMcKftIioS43LY in WLI5tgXRbUPNGJCSVz0vKjBDei3: continue
			if 'value' not in c2eEflztvIX: c2eEflztvIX = q1rVywkMcKftIioS43LY
			else: c2eEflztvIX = u5h2Rckvw1E.findall('"(.*?)"',c2eEflztvIX,u5h2Rckvw1E.DOTALL)[0]
			dict[Uiy0XwPusDg4vAFc35oYdfGnOrV][c2eEflztvIX] = q1rVywkMcKftIioS43LY
			WGiMcqkRetEJVrSI = lvUP2GeNjyVOHKJxcBoun3Z+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'='+q1rVywkMcKftIioS43LY
			z3wGSEWqVy1Qh5N = MoELTBDgQeaJrl0zYUmKCH+'&'+Uiy0XwPusDg4vAFc35oYdfGnOrV+'='+c2eEflztvIX
			eoaO40TC7VF1tEuwjQp2x = WGiMcqkRetEJVrSI+'___'+z3wGSEWqVy1Qh5N
			title = q1rVywkMcKftIioS43LY+' : '#+dict[Uiy0XwPusDg4vAFc35oYdfGnOrV]['0']
			title = q1rVywkMcKftIioS43LY+' : '+name
			if type=='FILTERS': uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,354,'','',eoaO40TC7VF1tEuwjQp2x)
			elif type=='CATEGORIES' and BVNnjYeCa3AfgTv0u6R[-2]+'=' in lvUP2GeNjyVOHKJxcBoun3Z:
				TBFfiRI52ZmKwO1JLSD = mltWBSPJz5H4VRdCAa1(z3wGSEWqVy1Qh5N,'all')
				UcmHDPlLWaSf = url+'?'+TBFfiRI52ZmKwO1JLSD
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,UcmHDPlLWaSf,351,'','1')
			else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,url,355,'','',eoaO40TC7VF1tEuwjQp2x)
	return
def mltWBSPJz5H4VRdCAa1(cGYIMSHDj85d3f4ZW2t0bnNkKP,mode):
	cGYIMSHDj85d3f4ZW2t0bnNkKP = cGYIMSHDj85d3f4ZW2t0bnNkKP.strip('&')
	OXjBliFSwIQCmg47 = {}
	if '=' in cGYIMSHDj85d3f4ZW2t0bnNkKP:
		items = cGYIMSHDj85d3f4ZW2t0bnNkKP.split('&')
		for TMaJdc0xOFKNf in items:
			b1EWu6sYaRk0FXUx8HVvNBQort43,c2eEflztvIX = TMaJdc0xOFKNf.split('=')
			OXjBliFSwIQCmg47[b1EWu6sYaRk0FXUx8HVvNBQort43] = c2eEflztvIX
	LL3oamJbwkYcNDrH5 = ''
	mwqMBcOe2Lj = ['cat','genre','release-year','quality','orderby']
	for key in mwqMBcOe2Lj:
		if key in list(OXjBliFSwIQCmg47.keys()): c2eEflztvIX = OXjBliFSwIQCmg47[key]
		else: c2eEflztvIX = '0'
		if mode=='modified_values' and c2eEflztvIX!='0': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+' + '+c2eEflztvIX
		elif mode=='modified_filters' and c2eEflztvIX!='0': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+'&'+key+'='+c2eEflztvIX
		elif mode=='all': LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5+'&'+key+'='+c2eEflztvIX
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.strip(' + ')
	LL3oamJbwkYcNDrH5 = LL3oamJbwkYcNDrH5.strip('&')
	return LL3oamJbwkYcNDrH5
﻿# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'ALMAAREF'
headers = {'User-Agent':''}
tiCRYyX1bWd40Ir3PafQu = '_MRF_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text,BzbaC0qYjMr2WXwsO):
	if   mode==40: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==41: vS7JufTVsBxw52 = SotcYExj3mF2Cn4dGKA()
	elif mode==42: vS7JufTVsBxw52 = t85QkluBcy6SMwgZV(text,BzbaC0qYjMr2WXwsO)
	elif mode==43: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==44: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(text,BzbaC0qYjMr2WXwsO)
	elif mode==49: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	uQNUfbZx9yj0F('live',tiCRYyX1bWd40Ir3PafQu+'البث الحي لقناة المعارف','',41)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',49)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	t85QkluBcy6SMwgZV('','1')
	return
def aaH64PlwNR0L(dza2VO9NvX,PPEyL9NfwY1pRXuxGS3H):
	search,sort,UwQK685R0SpOCmVIagWJ,oPrhaMp7AqmNnRjlXGI,fngYPy64vOK35 = '',[],[],[],[]
	qBdHbiaM0lmk5GNsfrXCIYyugR,szEd4Nopky6l9jMfwZcFHe = ykfj6Qb9Fc5GiJIvelp84rHDn(dza2VO9NvX)
	for q1rVywkMcKftIioS43LY in list(szEd4Nopky6l9jMfwZcFHe.keys()):
		c2eEflztvIX = szEd4Nopky6l9jMfwZcFHe[q1rVywkMcKftIioS43LY]
		if not c2eEflztvIX: continue
		if   q1rVywkMcKftIioS43LY=='sort': sort = [c2eEflztvIX]
		elif q1rVywkMcKftIioS43LY=='series': UwQK685R0SpOCmVIagWJ = [c2eEflztvIX]
		elif q1rVywkMcKftIioS43LY=='search': search = c2eEflztvIX
		elif q1rVywkMcKftIioS43LY=='category': oPrhaMp7AqmNnRjlXGI = [c2eEflztvIX]
		elif q1rVywkMcKftIioS43LY=='specialist': fngYPy64vOK35 = [c2eEflztvIX]
	nD70jhRb8C9Gi = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":oPrhaMp7AqmNnRjlXGI,"specialist":fngYPy64vOK35,"series":UwQK685R0SpOCmVIagWJ,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(PPEyL9NfwY1pRXuxGS3H)}}
	import json as Kq1vtcn0VUo4CaebZuWYHpPJ7l
	nD70jhRb8C9Gi = Kq1vtcn0VUo4CaebZuWYHpPJ7l.dumps(nD70jhRb8C9Gi)
	ekTrZlFMu0Kf5QztEnhAs = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'POST',ekTrZlFMu0Kf5QztEnhAs,nD70jhRb8C9Gi,'','','','ALMAAREF-REQUEST_DATA_PAGE-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	data = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('dict',oo9SgGkiDbs3HRn7z8)
	return data
def t85QkluBcy6SMwgZV(dza2VO9NvX,level):
	ppZ9muD1GkPnFRX52jxBUIy = aaH64PlwNR0L(dza2VO9NvX,'1')
	lmO2YJGr6tCV = ppZ9muD1GkPnFRX52jxBUIy['facets']
	if level=='1':
		lmO2YJGr6tCV = lmO2YJGr6tCV['video_categories']
		items = u5h2Rckvw1E.findall('<div(.*?)/div>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for TMaJdc0xOFKNf in items:
			LkKHrN2Stnw0avfuWO = u5h2Rckvw1E.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',TMaJdc0xOFKNf+'<',u5h2Rckvw1E.DOTALL)
			if not LkKHrN2Stnw0avfuWO: LkKHrN2Stnw0avfuWO = u5h2Rckvw1E.findall('data-value=\\"(.*?)\\">(.*?)<',TMaJdc0xOFKNf+'<',u5h2Rckvw1E.DOTALL)
			oPrhaMp7AqmNnRjlXGI,title = LkKHrN2Stnw0avfuWO[0]
			if not dza2VO9NvX: uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,'',42,'','2','?category='+oPrhaMp7AqmNnRjlXGI)
			else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,'',42,'','2',dza2VO9NvX+'&category='+oPrhaMp7AqmNnRjlXGI)
	if level=='2':
		lmO2YJGr6tCV = lmO2YJGr6tCV['specialist']
		items = u5h2Rckvw1E.findall('value="(.*?)".*?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for fngYPy64vOK35,title in items:
			if not fngYPy64vOK35: title = title = 'الجميع'
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,'',42,'','3',dza2VO9NvX+'&specialist='+fngYPy64vOK35)
	elif level=='3':
		lmO2YJGr6tCV = lmO2YJGr6tCV['series']
		items = u5h2Rckvw1E.findall('value="(.*?)".*?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for UwQK685R0SpOCmVIagWJ,title in items:
			if not UwQK685R0SpOCmVIagWJ: title = title = 'الجميع'
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,'',42,'','4',dza2VO9NvX+'&series='+UwQK685R0SpOCmVIagWJ)
	elif level=='4':
		lmO2YJGr6tCV = lmO2YJGr6tCV['sort_video']
		items = u5h2Rckvw1E.findall('value="(.*?)".*?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for sort,title in items:
			if not sort: continue
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,'',44,'','1',dza2VO9NvX+'&sort='+sort)
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(dza2VO9NvX,PPEyL9NfwY1pRXuxGS3H):
	ppZ9muD1GkPnFRX52jxBUIy = aaH64PlwNR0L(dza2VO9NvX,PPEyL9NfwY1pRXuxGS3H)
	lmO2YJGr6tCV = ppZ9muD1GkPnFRX52jxBUIy['template']
	items = u5h2Rckvw1E.findall('src="(.*?)".*?href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for pGjsvdyHfM,ekTrZlFMu0Kf5QztEnhAs,title in items:
		uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,43,pGjsvdyHfM)
	lmO2YJGr6tCV = ppZ9muD1GkPnFRX52jxBUIy['facets']['pagination']
	items = u5h2Rckvw1E.findall('data-page="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for BzbaC0qYjMr2WXwsO,title in items:
		if PPEyL9NfwY1pRXuxGS3H==BzbaC0qYjMr2WXwsO: continue
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+title,'',44,'',BzbaC0qYjMr2WXwsO,dza2VO9NvX)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','ALMAAREF-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('<video src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = u5h2Rckvw1E.findall('youtube_url.*?(http.*?)&',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	GnuaoT9MxiCg = []
	if ekTrZlFMu0Kf5QztEnhAs:
		ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs[0].replace('\/','/')
		GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(GnuaoT9MxiCg,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def SotcYExj3mF2Cn4dGKA():
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',yONJxHER9BIDPpTV4YsWmc0n+'/بث-مباشر','','','','','ALMAAREF-LIVE-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	items = u5h2Rckvw1E.findall('source src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	url = P2o6ZDHeW790pSQqucvnxzILVUX(items[0])
	om1iZDWnrhGa2SLB9O4kfxYbqU(url,aUVSgO2ebjwX5iqPykC,'live')
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	KohP0LUCSpE8Fq9MeHO = False
	if search=='':
		search = FBrXsYeCEp3()
		KohP0LUCSpE8Fq9MeHO = True
	if search=='': return
	if not KohP0LUCSpE8Fq9MeHO: ll0a2AwztChcpsDUMi4rGW3b61XZES('?search='+search,'1')
	else: t85QkluBcy6SMwgZV('?search='+search,'1')
	return
# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'CIMAFANS'
headers = { 'User-Agent' : '' }
tiCRYyX1bWd40Ir3PafQu = '_CMF_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==90: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==91: vS7JufTVsBxw52 = tZwPW2bEz6S0OLXK84IjDYFqkde(url)
	elif mode==92: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==94: vS7JufTVsBxw52 = VCio1EXzNgM8WLmYbxtBdw()
	elif mode==95: vS7JufTVsBxw52 = GA2KIlbOsoYtxpkDF71(url)
	elif mode==99: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',99,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'المضاف حديثا','',94)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'الأحدث',yONJxHER9BIDPpTV4YsWmc0n+'/?type=latest',91)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'الأعلى تقيماً',yONJxHER9BIDPpTV4YsWmc0n+'/?type=imdb',91)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'الأكثر مشاهدة',yONJxHER9BIDPpTV4YsWmc0n+'/?type=view',91)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'المثبت',yONJxHER9BIDPpTV4YsWmc0n+'/?type=pin',91)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'جديد الأفلام',yONJxHER9BIDPpTV4YsWmc0n+'/?type=newMovies',91)
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'جديد الحلقات',yONJxHER9BIDPpTV4YsWmc0n+'/?type=newEpisodes',91)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,yONJxHER9BIDPpTV4YsWmc0n,'',headers,'','CIMAFANS-MENU-1st')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="mainmenu(.*?)nav',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('<li><a href="(.*?)".*?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['افلام للكبار فقط']
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		title = title.strip(' ')
		if not any(c2eEflztvIX in title for c2eEflztvIX in WLI5tgXRbUPNGJCSVz0vKjBDei3):
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,91)
	return oo9SgGkiDbs3HRn7z8
def tZwPW2bEz6S0OLXK84IjDYFqkde(url):
	if '/search.php' in url:
		url,search = url.split('?t=')
		headers = { 'User-Agent' : '' , 'Content-Type' : 'application/x-www-form-urlencoded' }
		data = { 't' : search }
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'POST',url,data,headers,'','','CIMAFANS-ITEMS-1st')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	else:
		headers = { 'User-Agent' : '' }
		oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,url,'',headers,'','CIMAFANS-ITEMS-2nd')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('id="movies-items(.*?)class="listfoot"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi: lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	else: lmO2YJGr6tCV = ''
	items = u5h2Rckvw1E.findall('background-image:url\((.*?)\).*?href="(.*?)".*?movie-title">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	yn8DkpE5etF3WiUmfSO = []
	for pGjsvdyHfM,ekTrZlFMu0Kf5QztEnhAs,title in items:
		if 'الحلقة' in title and '/c/' not in url and '/cat/' not in url:
			zAjwuoRY98mXN6xvE = u5h2Rckvw1E.findall('(.*?) الحلقة [0-9]+',title,u5h2Rckvw1E.DOTALL)
			if zAjwuoRY98mXN6xvE:
				title = '_MOD_'+zAjwuoRY98mXN6xvE[0]
				if title not in yn8DkpE5etF3WiUmfSO:
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,95,pGjsvdyHfM)
					yn8DkpE5etF3WiUmfSO.append(title)
		elif '/video/' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,92,pGjsvdyHfM)
		else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,91,pGjsvdyHfM)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="pagination(.*?)div',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('<a href="(.*?)".*?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			title = uTUNPkVwCMKiD5gHLaj(title)
			title = title.replace('الصفحة ','')
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+title,ekTrZlFMu0Kf5QztEnhAs,91)
	return
def GA2KIlbOsoYtxpkDF71(url):
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,url,'',headers,'','CIMAFANS-EPISODES-1st')
	pGjsvdyHfM = u5h2Rckvw1E.findall('img src="(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	pGjsvdyHfM = pGjsvdyHfM[0]
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('id="episodes-panel(.*?)div',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		name = u5h2Rckvw1E.findall('itemprop="title">(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if name: name = name[1]
		else:
			name = bMIascyFJ2x43E0C7glTB91h8qz.getInfoLabel('ListItem.Label')
			if '[/COLOR]' in name: name = name.split('[/COLOR]',1)[1]
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?name">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+name+' - '+title,ekTrZlFMu0Kf5QztEnhAs,92,pGjsvdyHfM)
	else:
		LkKHrN2Stnw0avfuWO = u5h2Rckvw1E.findall('class="movietitle"><a href="(.*?)">(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if LkKHrN2Stnw0avfuWO: ekTrZlFMu0Kf5QztEnhAs,title = LkKHrN2Stnw0avfuWO[0]
		else: ekTrZlFMu0Kf5QztEnhAs,title = url,name
		uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,92,pGjsvdyHfM)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	EaBeVhOsHYg8wub,QFR60urSVcksg9JimUNL = [],[]
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,url,'',headers,'','CIMAFANS-PLAY-1st')
	PmF0XjQN51GpKACfLgnyTv7 = u5h2Rckvw1E.findall('text-shadow: none;">(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if PmF0XjQN51GpKACfLgnyTv7 and dQorkS3qBhIMDWKHl(aUVSgO2ebjwX5iqPykC,url,PmF0XjQN51GpKACfLgnyTv7): return
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('id="links-panel(.*?)div',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs in items:
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?__download'
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('nav-tabs"(.*?)video-panel-more',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('id="(.*?)".*?embed src="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for id,ekTrZlFMu0Kf5QztEnhAs in items:
			title = 'سيرفر '+id
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+title+'__watch'
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
		items = u5h2Rckvw1E.findall('data-server-src="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs in items:
			if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = 'http:'+ekTrZlFMu0Kf5QztEnhAs
			ekTrZlFMu0Kf5QztEnhAs = P2o6ZDHeW790pSQqucvnxzILVUX(ekTrZlFMu0Kf5QztEnhAs)
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(EaBeVhOsHYg8wub,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def VCio1EXzNgM8WLmYbxtBdw():
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,yONJxHER9BIDPpTV4YsWmc0n,'',headers,'','CIMAFANS-LATEST-1st')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('id="index-last-movie(.*?)id="index-slider-movie',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('src="(.*?)".*?href="(.*?)" title="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for pGjsvdyHfM,ekTrZlFMu0Kf5QztEnhAs,title in items:
		if '/video/' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,92,pGjsvdyHfM)
		else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,91,pGjsvdyHfM)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	search = search.replace(' ','+')
	url = yONJxHER9BIDPpTV4YsWmc0n + '/search.php?t='+search
	tZwPW2bEz6S0OLXK84IjDYFqkde(url)
	return
# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'CIMANOW'
tiCRYyX1bWd40Ir3PafQu = '_CMN_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['قائمتي']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==300: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==301: vS7JufTVsBxw52 = GQsDp6PWFHRE1ki2odqrwjB0ISTLh(url)
	elif mode==302: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url)
	elif mode==303: vS7JufTVsBxw52 = xxWn9XKlJmchkHrLUMugIFySa7(url)
	elif mode==304: vS7JufTVsBxw52 = GA2KIlbOsoYtxpkDF71(url)
	elif mode==305: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==306: vS7JufTVsBxw52 = eyXMZC4cbdVOjG6J201qPNrQ()
	elif mode==309: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	uQNUfbZx9yj0F('link',tiCRYyX1bWd40Ir3PafQu+'لماذا الموقع بطيء','',306)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',309,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',yONJxHER9BIDPpTV4YsWmc0n+'/home','','','','','CIMANOW-MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('<header>(.*?)</header>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('<li><a href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		title = title.strip(' ')
		if not any(c2eEflztvIX in title for c2eEflztvIX in WLI5tgXRbUPNGJCSVz0vKjBDei3):
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,301)
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	GQsDp6PWFHRE1ki2odqrwjB0ISTLh(yONJxHER9BIDPpTV4YsWmc0n+'/home',oo9SgGkiDbs3HRn7z8)
	return oo9SgGkiDbs3HRn7z8
def eyXMZC4cbdVOjG6J201qPNrQ():
	xl9MFt1AmY0GrkENug8n('','','رسالة من المبرمج','موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def GQsDp6PWFHRE1ki2odqrwjB0ISTLh(url,oo9SgGkiDbs3HRn7z8=''):
	if not oo9SgGkiDbs3HRn7z8:
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',url,'','','','','CIMANOW-SUBMENU-1st')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	bHMj0q6zaN = 0
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('(<section>.*?</section>)',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		for lmO2YJGr6tCV in cWafzb4HoG1Em3Jwxu6C7vZsVi:
			bHMj0q6zaN += 1
			items = u5h2Rckvw1E.findall('<section>.<span>(.*?)<(.*?)href="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for title,eib6NmIJWL,ekTrZlFMu0Kf5QztEnhAs in items:
				title = title.strip(' ')
				if title=='': title = 'بووووو'
				if 'em><a' not in eib6NmIJWL:
					if lmO2YJGr6tCV.count('/category/')>0:
						F6y9DB5gKWSdpzmju = u5h2Rckvw1E.findall('href="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
						for ekTrZlFMu0Kf5QztEnhAs in F6y9DB5gKWSdpzmju:
							title = ekTrZlFMu0Kf5QztEnhAs.split('/')[-2]
							uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,301)
						continue
					else: ekTrZlFMu0Kf5QztEnhAs = url+'?sequence='+str(bHMj0q6zaN)
				if not any(c2eEflztvIX in title for c2eEflztvIX in WLI5tgXRbUPNGJCSVz0vKjBDei3):
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,302)
	else: ll0a2AwztChcpsDUMi4rGW3b61XZES(url,oo9SgGkiDbs3HRn7z8)
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,oo9SgGkiDbs3HRn7z8=''):
	if oo9SgGkiDbs3HRn7z8=='':
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','CIMANOW-TITLES-1st')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	if '?sequence=' in url:
		url,bHMj0q6zaN = url.split('?sequence=')
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('(<section>.*?</section>)',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[int(bHMj0q6zaN)-1]
	else:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"posts"(.*?)</body>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	items = u5h2Rckvw1E.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	yn8DkpE5etF3WiUmfSO = []
	for ekTrZlFMu0Kf5QztEnhAs,data,pGjsvdyHfM in items:
		title = u5h2Rckvw1E.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,u5h2Rckvw1E.DOTALL)
		if title: title = title[0][2].replace('\n','').strip(' ')
		if not title or title=='':
			title = u5h2Rckvw1E.findall('title">.*?</em>(.*?)<',data,u5h2Rckvw1E.DOTALL)
			if title: title = title[0].replace('\n','').strip(' ')
			if not title or title=='':
				title = u5h2Rckvw1E.findall('title">(.*?)<',data,u5h2Rckvw1E.DOTALL)
				title = title[0].replace('\n','').strip(' ')
		title = uTUNPkVwCMKiD5gHLaj(title)
		if title not in yn8DkpE5etF3WiUmfSO:
			yn8DkpE5etF3WiUmfSO.append(title)
			CyEMW1Sh3GtsbRUzN = ekTrZlFMu0Kf5QztEnhAs+data+pGjsvdyHfM
			if '/selary/' in CyEMW1Sh3GtsbRUzN or 'مسلسل' in CyEMW1Sh3GtsbRUzN or '"episode"' in CyEMW1Sh3GtsbRUzN:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,303,pGjsvdyHfM)
			else: uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,305,pGjsvdyHfM)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"pagination"(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('<li><a href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+title,ekTrZlFMu0Kf5QztEnhAs,302)
	return
def xxWn9XKlJmchkHrLUMugIFySa7(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','CIMANOW-SEASONS-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	name = u5h2Rckvw1E.findall('<title>(.*?)</title>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	name = name[0].replace('| سيما ناو','').replace('Cima Now','').strip(' ').replace('  ',' ')
	name = name.split('الحلقة')[0].strip(' ')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('<section(.*?)</section>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if len(items)>1:
			for ekTrZlFMu0Kf5QztEnhAs,title in items:
				title = name+' - '+title.replace('\n','').strip(' ')
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,304)
		else: GA2KIlbOsoYtxpkDF71(url)
	return
def GA2KIlbOsoYtxpkDF71(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','CIMANOW-EPISODES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	if '/selary/' not in url:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"episodes"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			title = title.replace('\n','').strip(' ')
			title = 'الحلقة '+title
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,305)
	else:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"details"(.*?)"related"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
			title = title.replace('\n','').strip(' ')
			uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,305,pGjsvdyHfM)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	gANn35esloKUydOipfSMC6RD2 = url+'watching/'
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,'GET',gANn35esloKUydOipfSMC6RD2,'','','','','CIMANOW-PLAY-5th')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	EaBeVhOsHYg8wub = []
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"download"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?</i>(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			title = title.replace('\n','').strip(' ')
			ohAHUqdbWFi8D1L4Xwzus0f3RYv = u5h2Rckvw1E.findall('\d\d\d+',title,u5h2Rckvw1E.DOTALL)
			if ohAHUqdbWFi8D1L4Xwzus0f3RYv:
				ohAHUqdbWFi8D1L4Xwzus0f3RYv = '____'+ohAHUqdbWFi8D1L4Xwzus0f3RYv[0]
				title = hmcFWJUgiAuGk(ekTrZlFMu0Kf5QztEnhAs,'name')
			else: ohAHUqdbWFi8D1L4Xwzus0f3RYv = ''
			olm59qifJbWpRsr1a3X7zBEIA = ekTrZlFMu0Kf5QztEnhAs+'?named='+title+'__download'+ohAHUqdbWFi8D1L4Xwzus0f3RYv
			EaBeVhOsHYg8wub.append(olm59qifJbWpRsr1a3X7zBEIA)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('"watch"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		lQUf3AY258LeWch = u5h2Rckvw1E.findall('"embed".*?src="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs in lQUf3AY258LeWch:
			if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = 'http:'+ekTrZlFMu0Kf5QztEnhAs
			title = hmcFWJUgiAuGk(ekTrZlFMu0Kf5QztEnhAs,'name')
			ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs+'?named='+title+'__embed'
			EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
		lQUf3AY258LeWch = [yONJxHER9BIDPpTV4YsWmc0n+'/wp-content/themes/Cima%20Now%20New/core.php']
		if lQUf3AY258LeWch:
			items = u5h2Rckvw1E.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for M4Feb15G0QtrDlW6sPh9xNBnC3j,id,title in items:
				title = title.replace('\n','').strip(' ')
				ekTrZlFMu0Kf5QztEnhAs = lQUf3AY258LeWch[0]+'?action=switch&index='+M4Feb15G0QtrDlW6sPh9xNBnC3j+'&id='+id+'?named='+title+'__watch'
				EaBeVhOsHYg8wub.append(ekTrZlFMu0Kf5QztEnhAs)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(EaBeVhOsHYg8wub,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	search = search.replace(' ','+')
	url = yONJxHER9BIDPpTV4YsWmc0n + '/?s='+search
	ll0a2AwztChcpsDUMi4rGW3b61XZES(url)
	return
# -*- coding: utf-8 -*-
import sys as vdo2FnhPmAVRMJQZ0EIG8
XzBpdMGJhHZKC8Yveki5qb1jT4nQUg = vdo2FnhPmAVRMJQZ0EIG8.version_info [0] == 2
vykERrdZlF5K = 2048
GG02h4EolRYTs3iv = 7
def tci7BbCy6gT9MXkOEzhm (xVtfmzjd6RSsBEk2o34aHWC):
	global jMo7iTRkq0n1NPa35xheAVlbt
	oAJijr7NHwnfUGqyd8Ru6EImOtv = ord (xVtfmzjd6RSsBEk2o34aHWC [-1])
	wwpaJlB3bkXySOHFWUfoILC = xVtfmzjd6RSsBEk2o34aHWC [:-1]
	lqXRut6PnL = oAJijr7NHwnfUGqyd8Ru6EImOtv % len (wwpaJlB3bkXySOHFWUfoILC)
	rmaU71pZj3X = wwpaJlB3bkXySOHFWUfoILC [:lqXRut6PnL] + wwpaJlB3bkXySOHFWUfoILC [lqXRut6PnL:]
	if XzBpdMGJhHZKC8Yveki5qb1jT4nQUg:
		bbsiU0a49tw2dy = unicode () .join ([unichr (ord (Q9QUIWH6rK2BlmC) - vykERrdZlF5K - (ZXwWfDc9AF4yr2P + oAJijr7NHwnfUGqyd8Ru6EImOtv) % GG02h4EolRYTs3iv) for ZXwWfDc9AF4yr2P, Q9QUIWH6rK2BlmC in enumerate (rmaU71pZj3X)])
	else:
		bbsiU0a49tw2dy = str () .join ([chr (ord (Q9QUIWH6rK2BlmC) - vykERrdZlF5K - (ZXwWfDc9AF4yr2P + oAJijr7NHwnfUGqyd8Ru6EImOtv) % GG02h4EolRYTs3iv) for ZXwWfDc9AF4yr2P, Q9QUIWH6rK2BlmC in enumerate (rmaU71pZj3X)])
	return eval (bbsiU0a49tw2dy)
r3flT0zQPa5H7yXEgxJOt92Vc4Ao,cgtRBdXxSOk7WUfyDhPCls,cNaVb1vsT4qWOL0rpE=tci7BbCy6gT9MXkOEzhm,tci7BbCy6gT9MXkOEzhm,tci7BbCy6gT9MXkOEzhm
yruHDQOcB97ig,drHLAY5ENQFe2q9ptKGabo,qnPgZ9N15G6Oa8UpMASvLk=cNaVb1vsT4qWOL0rpE,cgtRBdXxSOk7WUfyDhPCls,r3flT0zQPa5H7yXEgxJOt92Vc4Ao
KKbpxUZnMcj6AJ4QdD,ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB,ggDRehOModi=qnPgZ9N15G6Oa8UpMASvLk,drHLAY5ENQFe2q9ptKGabo,yruHDQOcB97ig
xuztI5QWEKG70CPNdhk4vo6,bcgZJWV6UeNSkRA,shZ9eOcN2dJnPj=ggDRehOModi,ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB,KKbpxUZnMcj6AJ4QdD
BGhdkWsEvJjiMFTr3NLn1flU,nKLEi8CJumazx4qT,pcWq35MED2dtK=shZ9eOcN2dJnPj,bcgZJWV6UeNSkRA,xuztI5QWEKG70CPNdhk4vo6
yF29Xdsx35wI07Ce4,XikqnGVSK4v9d3uUICLhDxJyt1M,JLoPRXt93dpAB=pcWq35MED2dtK,nKLEi8CJumazx4qT,BGhdkWsEvJjiMFTr3NLn1flU
wwplD0tEehqH3kYQXs,tZ3gsrTEdzA1S6LXa9WI5px,Nqj35AXg06euY1G2d4bSUMQ8wlr=JLoPRXt93dpAB,XikqnGVSK4v9d3uUICLhDxJyt1M,yF29Xdsx35wI07Ce4
bbw2eajMlG,M6PIj8gl1fno7wcqTksDEBK4bU,CgG4PuyxsLA8WDzh3FfteZvKQMdom9=Nqj35AXg06euY1G2d4bSUMQ8wlr,tZ3gsrTEdzA1S6LXa9WI5px,wwplD0tEehqH3kYQXs
iifPEY9ABNzTQp,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ,PtXn0k9G3ocHRg=CgG4PuyxsLA8WDzh3FfteZvKQMdom9,M6PIj8gl1fno7wcqTksDEBK4bU,bbw2eajMlG
Tgoa16jMxvYX2,vvBChXmSty,InKG0i2r6hHDvgd=PtXn0k9G3ocHRg,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ,iifPEY9ABNzTQp
OyJ1o4AvmWlB75UkFRX,usaZLwSGe1k6VDp570yhB4bzWPiFq,oUlIcGH2JuWFLvimMXyBQdzK06ge=InKG0i2r6hHDvgd,vvBChXmSty,Tgoa16jMxvYX2
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = KKbpxUZnMcj6AJ4QdD(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪज")
def cc03CYPLaxRfUKJb9eynFTr(wMCm6g9qFyPT0xpneDUNc2lEhaZY,GZdtFyDU0caf89r):
	if   wMCm6g9qFyPT0xpneDUNc2lEhaZY==pcWq35MED2dtK(u"࠷࠸࠶৪"): vS7JufTVsBxw52 = dXrlnWTtHZJk2MVxoKyLwO3()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==iifPEY9ABNzTQp(u"࠸࠹࠱৫"): vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(GZdtFyDU0caf89r)
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==Tgoa16jMxvYX2(u"࠹࠳࠳৬"): vS7JufTVsBxw52 = nJrGyP7OECFIm2()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠳࠴࠵৭"): vS7JufTVsBxw52 = HRjSGiT9zw()
	elif wMCm6g9qFyPT0xpneDUNc2lEhaZY==yF29Xdsx35wI07Ce4(u"࠴࠵࠷৮"): vS7JufTVsBxw52 = U5UfT0DdBLJOQpny1WbrhMxa4qR2(GZdtFyDU0caf89r)
	else: vS7JufTVsBxw52 = CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࡋࡧ࡬ࡴࡧਜ")
	return vS7JufTVsBxw52
def U5UfT0DdBLJOQpny1WbrhMxa4qR2(rJUc4y6CBpLe8dV3Auo0DM1):
	try: k1t0JLRsCQ.remove(rJUc4y6CBpLe8dV3Auo0DM1.decode(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠩࡸࡸ࡫࠾ࠧझ")))
	except: k1t0JLRsCQ.remove(rJUc4y6CBpLe8dV3Auo0DM1)
	return
def N5AOlmb8u1y4FHxvJXU(GZdtFyDU0caf89r):
	om1iZDWnrhGa2SLB9O4kfxYbqU(GZdtFyDU0caf89r,aUVSgO2ebjwX5iqPykC,XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠪࡺ࡮ࡪࡥࡰࠩञ"))
	return
def HRjSGiT9zw():
	MLPwxur5kaYlBtqcn = r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠫศึ็ษࠢศ่๎ࠦัศสฺࠤฬ๊แ๋ัํ์ࠥษ่ࠡษ็ูํะࠠโ์ࠣห้๋่ใ฻ࠣห้๋ืๅ๊หࠤะ๋ࠠฤุ฽฻ࠥ฿ไ๊ࠢีีࠥอไใษษ้ฮࠦวๅ์่๎๋ࠦหๆࠢฦาฯอัࠡࠤอั๊๐ไࠡ็็ๅฬะࠠโ์า๎ํࠨࠠฬ็ࠣหำะวาࠢาๆฮࠦวๅื๋ีฮ่ࠦศะอหึࠦๆ้฻้้ࠣ็ࠠศๆุ์ึฯ้ࠠส฼ำ์อࠠิ๊ไࠤ๏ฮฯฤࠢส่ฯำๅ๋ๆࠪट")
	xl9MFt1AmY0GrkENug8n(qnPgZ9N15G6Oa8UpMASvLk(u"ࠬ࠭ठ"),xuztI5QWEKG70CPNdhk4vo6(u"࠭ࠧड"),ggDRehOModi(u"ุࠧำํๆฮࠦสฮ็ํ่ࠥอไๆๆไหฯ࠭ढ"),MLPwxur5kaYlBtqcn)
	return
def dXrlnWTtHZJk2MVxoKyLwO3():
	uQNUfbZx9yj0F(yF29Xdsx35wI07Ce4(u"ࠨ࡮࡬ࡲࡰ࠭ण"),cgtRBdXxSOk7WUfyDhPCls(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ฼ื๊ใหࠣฮา๋๊ๅ่่ࠢๆอสࠡษ็ๅ๏ี๊้࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪत"),xuztI5QWEKG70CPNdhk4vo6(u"ࠪࠫथ"),JLoPRXt93dpAB(u"࠵࠶࠷৯"))
	uQNUfbZx9yj0F(yF29Xdsx35wI07Ce4(u"ࠫࡱ࡯࡮࡬ࠩद"),InKG0i2r6hHDvgd(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ห฼ํ๎ึࠦๅไษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨध"),Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠭ࠧन"),bcgZJWV6UeNSkRA(u"࠶࠷࠷ৰ"))
	uQNUfbZx9yj0F(cNaVb1vsT4qWOL0rpE(u"ࠧ࡭࡫ࡱ࡯ࠬऩ"),KKbpxUZnMcj6AJ4QdD(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪप"),XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠩࠪफ"),pcWq35MED2dtK(u"࠽࠾࠿࠹ৱ"))
	pD9aV6WL1cUbTsFdQ = llIkJQn2qvM()
	xhHAwZbyoRgrP0QKqcpl = k1t0JLRsCQ.stat(pD9aV6WL1cUbTsFdQ).st_mtime
	Yugbp5vmkGExP3BwhcJ0Z14Hzyf = []
	if VVGRN7xiyj: rrcUB3LGtwPsSJ = k1t0JLRsCQ.listdir(pD9aV6WL1cUbTsFdQ.encode(usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠪࡹࡹ࡬࠸ࠨब")))
	else: rrcUB3LGtwPsSJ = k1t0JLRsCQ.listdir(pD9aV6WL1cUbTsFdQ.decode(JLoPRXt93dpAB(u"ࠫࡺࡺࡦ࠹ࠩभ")))
	for gn7mjNUzap in rrcUB3LGtwPsSJ:
		if VVGRN7xiyj: gn7mjNUzap = gn7mjNUzap.decode(InKG0i2r6hHDvgd(u"ࠬࡻࡴࡧ࠺ࠪम"))
		if not gn7mjNUzap.startswith(yruHDQOcB97ig(u"࠭ࡦࡪ࡮ࡨࡣࠬय")): continue
		JK1iIQ3LhHzGvADsS2Zm46Fo0k = k1t0JLRsCQ.path.join(pD9aV6WL1cUbTsFdQ,gn7mjNUzap)
		xhHAwZbyoRgrP0QKqcpl = k1t0JLRsCQ.path.getmtime(JK1iIQ3LhHzGvADsS2Zm46Fo0k)
		Yugbp5vmkGExP3BwhcJ0Z14Hzyf.append([gn7mjNUzap,xhHAwZbyoRgrP0QKqcpl])
	Yugbp5vmkGExP3BwhcJ0Z14Hzyf = sorted(Yugbp5vmkGExP3BwhcJ0Z14Hzyf,reverse=iifPEY9ABNzTQp(u"࡚ࡲࡶࡧਝ"),key=lambda key: key[qnPgZ9N15G6Oa8UpMASvLk(u"࠶৲")])
	for gn7mjNUzap,xhHAwZbyoRgrP0QKqcpl in Yugbp5vmkGExP3BwhcJ0Z14Hzyf:
		if bdptXFc8UlIhA5jnGwPmKuv2L:
			try: gn7mjNUzap = gn7mjNUzap.decode(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠧࡶࡶࡩ࠼ࠬर"))
			except: pass
			gn7mjNUzap = gn7mjNUzap.encode(M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠨࡷࡷࡪ࠽࠭ऱ"))
		JK1iIQ3LhHzGvADsS2Zm46Fo0k = k1t0JLRsCQ.path.join(pD9aV6WL1cUbTsFdQ,gn7mjNUzap)
		uQNUfbZx9yj0F(pcWq35MED2dtK(u"ࠩࡹ࡭ࡩ࡫࡯ࠨल"),gn7mjNUzap,JK1iIQ3LhHzGvADsS2Zm46Fo0k,InKG0i2r6hHDvgd(u"࠹࠳࠲৳"))
	return
def llIkJQn2qvM():
	pD9aV6WL1cUbTsFdQ = LLwCINEyZT9GHP7QMA1VlukcDjh.getSetting(Tgoa16jMxvYX2(u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭ळ"))
	if pD9aV6WL1cUbTsFdQ: return pD9aV6WL1cUbTsFdQ
	LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠫࡦࡼ࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧऴ"),OxWkR7Eu9Pm3IAvTp0q)
	return OxWkR7Eu9Pm3IAvTp0q
def nJrGyP7OECFIm2():
	pD9aV6WL1cUbTsFdQ = llIkJQn2qvM()
	DL86nWagz7P9tXiUxZdmyw0VHhk1B = lLPSDywfu4axrUhvX9RQEpGtso6H0(bbw2eajMlG(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬव"),Tgoa16jMxvYX2(u"࠭ࠧश"),ggDRehOModi(u"ࠧࠨष"),Tgoa16jMxvYX2(u"ࠨ็ๆห๋ࠦสฯิํ๊๋ࠥไโษอࠤฬ๊สฮ็ํ่ࠬस"),drHLAY5ENQFe2q9ptKGabo(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬह")+pD9aV6WL1cUbTsFdQ+vvBChXmSty(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯้ำหࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮา๋ไ่ษࠣห๋ะࠠษษึฮำีวๆ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰๋้ࠣࠦสา์าࠤฯเ๊๋ำࠣห้๋ใศ่ࠣรࠬऺ"))
	if DL86nWagz7P9tXiUxZdmyw0VHhk1B==yruHDQOcB97ig(u"࠱৴"):
		PW47y5JBk9GLgwboTOv = AAPgLr9vUYZSRQMKJV(OyJ1o4AvmWlB75UkFRX(u"࠴৵"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"๊้ࠫว็ࠢอั๊๐ไࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠨऻ"),PtXn0k9G3ocHRg(u"ࠬࡲ࡯ࡤࡣ࡯़ࠫ"),InKG0i2r6hHDvgd(u"࠭ࠧऽ"),pcWq35MED2dtK(u"ࡇࡣ࡯ࡷࡪਟ"),bbw2eajMlG(u"ࡔࡳࡷࡨਞ"),pD9aV6WL1cUbTsFdQ)
		iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(yF29Xdsx35wI07Ce4(u"ࠧࡤࡧࡱࡸࡪࡸࠧा"),shZ9eOcN2dJnPj(u"ࠨࠩि"),cgtRBdXxSOk7WUfyDhPCls(u"ࠩࠪी"),iifPEY9ABNzTQp(u"้่ࠪอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅฬะ้๏๊ࠧु"),cgtRBdXxSOk7WUfyDhPCls(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧू")+pD9aV6WL1cUbTsFdQ+usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱ๋ีอ่๊ࠠࠣห้๋ใศ่ࠣห้าฯ๋ั่ࠣฯิา๋่้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬะ้้ํวࠡษ้ฮࠥฮวิฬัำฬ๋่ࠠาสࠤฬ๊ศา่ส้ัࠦ࠮้ࠡ็ࠤฯื๊ะࠢสืฯิฯศ็๊ࠤอีไศ่๊ࠢࠥอไๆๅส๊ࠥอไใัํ้ࠥลࠧृ"))
		if iZL6cN3OkM5==tZ3gsrTEdzA1S6LXa9WI5px(u"࠳৶"):
			LLwCINEyZT9GHP7QMA1VlukcDjh.setSetting(vvBChXmSty(u"࠭ࡡࡷ࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵࡧࡴࡩࠩॄ"),PW47y5JBk9GLgwboTOv)
			xl9MFt1AmY0GrkENug8n(KKbpxUZnMcj6AJ4QdD(u"ࠧࠨॅ"),vvBChXmSty(u"ࠨࠩॆ"),oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬे"),InKG0i2r6hHDvgd(u"ࠪฮ๊ࠦส฻์ํี๋ࠥใศ่ࠣฮำุ๊็ࠢส่๊๊แศฬࠣห้๋อๆๆฬࠫै"))
	return
def IpLtBvKCrhfo2(GZdtFyDU0caf89r,ViRnO0m8fUScTNauvW=xuztI5QWEKG70CPNdhk4vo6(u"ࠫࠬॉ"),website=tZ3gsrTEdzA1S6LXa9WI5px(u"ࠬ࠭ॊ")):
	l0SAerv8zGH2Wa(tZ3gsrTEdzA1S6LXa9WI5px(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ो"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+yruHDQOcB97ig(u"ࠧࠡࠢࠣࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧौ")+GZdtFyDU0caf89r+iifPEY9ABNzTQp(u"ࠨࠢࡠ्ࠫ"))
	if not ViRnO0m8fUScTNauvW: ViRnO0m8fUScTNauvW = XS8G7Ljnkut(GZdtFyDU0caf89r)
	pD9aV6WL1cUbTsFdQ = llIkJQn2qvM()
	HjxmCcWZQhX8zaJNUvsg5yGib0P = eoblnvIyaChYrkj()
	gn7mjNUzap = HjxmCcWZQhX8zaJNUvsg5yGib0P.replace(n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠩࠣࠫॎ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠪࡣࠬॏ"))
	gn7mjNUzap = nkV8dCRtNgiBYMJTxLI(gn7mjNUzap)
	gn7mjNUzap = xuztI5QWEKG70CPNdhk4vo6(u"ࠫ࡫࡯࡬ࡦࡡࠪॐ")+str(int(s8bXSagYdim62TwIpQzGtUqeLhA1J))[-usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠷৷"):]+OyJ1o4AvmWlB75UkFRX(u"ࠬࡥࠧ॑")+gn7mjNUzap+ViRnO0m8fUScTNauvW
	Ub1mqOAXNIMK4f6c = k1t0JLRsCQ.path.join(pD9aV6WL1cUbTsFdQ,gn7mjNUzap)
	v1vaBXhQE6tsCjV73HkrNUpgI9DZK = {}
	v1vaBXhQE6tsCjV73HkrNUpgI9DZK[yruHDQOcB97ig(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ॒")] = ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠧࠨ॓")
	v1vaBXhQE6tsCjV73HkrNUpgI9DZK[usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠨࡃࡦࡧࡪࡶࡴࠨ॔")] = OyJ1o4AvmWlB75UkFRX(u"ࠩ࠭࠳࠯࠭ॕ")
	GZdtFyDU0caf89r = GZdtFyDU0caf89r.replace(drHLAY5ENQFe2q9ptKGabo(u"ࠪࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡧࡣ࡯ࡷࡪ࠭ॖ"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠫࠬॗ"))
	if ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪक़") in GZdtFyDU0caf89r:
		gANn35esloKUydOipfSMC6RD2,UUSPoh1ckMtVexN6u = GZdtFyDU0caf89r.rsplit(tZ3gsrTEdzA1S6LXa9WI5px(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫख़"),BGhdkWsEvJjiMFTr3NLn1flU(u"࠵৸"))
		UUSPoh1ckMtVexN6u = UUSPoh1ckMtVexN6u.replace(yruHDQOcB97ig(u"ࠧࡽࠩग़"),JLoPRXt93dpAB(u"ࠨࠩज़")).replace(KKbpxUZnMcj6AJ4QdD(u"ࠩࠩࠫड़"),drHLAY5ENQFe2q9ptKGabo(u"ࠪࠫढ़"))
	else: gANn35esloKUydOipfSMC6RD2,UUSPoh1ckMtVexN6u = GZdtFyDU0caf89r,None
	if not UUSPoh1ckMtVexN6u: UUSPoh1ckMtVexN6u = ncgQBtRa7qT2GJ3Wpd()
	if UUSPoh1ckMtVexN6u: v1vaBXhQE6tsCjV73HkrNUpgI9DZK[qnPgZ9N15G6Oa8UpMASvLk(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨफ़")] = UUSPoh1ckMtVexN6u
	if KKbpxUZnMcj6AJ4QdD(u"ࠬࡘࡥࡧࡧࡵࡩࡷࡃࠧय़") in gANn35esloKUydOipfSMC6RD2: gANn35esloKUydOipfSMC6RD2,A3oYrN6fkB9PX4ian = gANn35esloKUydOipfSMC6RD2.rsplit(PtXn0k9G3ocHRg(u"࠭ࡒࡦࡨࡨࡶࡪࡸ࠽ࠨॠ"),BGhdkWsEvJjiMFTr3NLn1flU(u"࠶৹"))
	else: gANn35esloKUydOipfSMC6RD2,A3oYrN6fkB9PX4ian = gANn35esloKUydOipfSMC6RD2,iifPEY9ABNzTQp(u"ࠧࠨॡ")
	gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2.strip(vvBChXmSty(u"ࠨࡾࠪॢ")).strip(KKbpxUZnMcj6AJ4QdD(u"ࠩࠩࠫॣ")).strip(M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠪࢀࠬ।")).strip(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠫࠫ࠭॥"))
	A3oYrN6fkB9PX4ian = A3oYrN6fkB9PX4ian.replace(XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠬࢂࠧ०"),bcgZJWV6UeNSkRA(u"࠭ࠧ१")).replace(Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠧࠧࠩ२"),cgtRBdXxSOk7WUfyDhPCls(u"ࠨࠩ३"))
	if A3oYrN6fkB9PX4ian:	v1vaBXhQE6tsCjV73HkrNUpgI9DZK[KKbpxUZnMcj6AJ4QdD(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ४")] = A3oYrN6fkB9PX4ian
	l0SAerv8zGH2Wa(cgtRBdXxSOk7WUfyDhPCls(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ५"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠫࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫ࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ६")+gANn35esloKUydOipfSMC6RD2+JLoPRXt93dpAB(u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨ७")+str(v1vaBXhQE6tsCjV73HkrNUpgI9DZK)+BGhdkWsEvJjiMFTr3NLn1flU(u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭८")+Ub1mqOAXNIMK4f6c+tZ3gsrTEdzA1S6LXa9WI5px(u"ࠧࠡ࡟ࠪ९"))
	hbHgfvqG16IPoFiANjCa = bbw2eajMlG(u"࠷࠰࠳࠶৺")*bbw2eajMlG(u"࠷࠰࠳࠶৺")
	omex4Hq8abjGE = pcWq35MED2dtK(u"࠰৻")
	try:
		jjnJTqGfPuzQXLMeEmowi94 =	bMIascyFJ2x43E0C7glTB91h8qz.getInfoLabel(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡈࡵࡩࡪ࡙ࡰࡢࡥࡨࠫ॰"))
		jjnJTqGfPuzQXLMeEmowi94 = u5h2Rckvw1E.findall(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠩ࡟ࡨ࠰࠭ॱ"),jjnJTqGfPuzQXLMeEmowi94)
		omex4Hq8abjGE = int(jjnJTqGfPuzQXLMeEmowi94[M6PIj8gl1fno7wcqTksDEBK4bU(u"࠱ৼ")])
	except: pass
	if not omex4Hq8abjGE:
		try:
			pEmFrnYzgZP9Av6DNITGKsBhia = k1t0JLRsCQ.statvfs(pD9aV6WL1cUbTsFdQ)
			omex4Hq8abjGE = pEmFrnYzgZP9Av6DNITGKsBhia.f_frsize*pEmFrnYzgZP9Av6DNITGKsBhia.f_bavail//hbHgfvqG16IPoFiANjCa
		except: pass
	if not omex4Hq8abjGE:
		try:
			pEmFrnYzgZP9Av6DNITGKsBhia = k1t0JLRsCQ.fstatvfs(pD9aV6WL1cUbTsFdQ)
			omex4Hq8abjGE = pEmFrnYzgZP9Av6DNITGKsBhia.f_frsize*pEmFrnYzgZP9Av6DNITGKsBhia.f_bavail//hbHgfvqG16IPoFiANjCa
		except: pass
	if not omex4Hq8abjGE:
		try:
			import shutil as kfBF6eUPKx
			nEpRemx1ylSXo0vg6QjVLsKtbOZTBW,LogO59N2f0x1FXl3m,eYSNJ1rbXKCDg8tI = kfBF6eUPKx.disk_usage(pD9aV6WL1cUbTsFdQ)
			omex4Hq8abjGE = eYSNJ1rbXKCDg8tI//hbHgfvqG16IPoFiANjCa
		except: pass
	if not omex4Hq8abjGE:
		RZo7IGjqXfiAnrWtlHcbNDuF9hP(JLoPRXt93dpAB(u"ࠪࡶ࡮࡭ࡨࡵࠩॲ"),nKLEi8CJumazx4qT(u"ู๊ࠫวฮหࠣห้ะฮำ์้ࠤ๊า็้ๆฬࠫॳ"),yF29Xdsx35wI07Ce4(u"๊ࠬไฤีไࠤฬ๊ศา่ส้ัฺ๋ࠦำࠣๆฬีัࠡล้ࠤ๏ำฯะ่ࠢๆิอัࠡ็ึหาฯࠠศๆอาื๐ๆࠡษ็ๅฬืฺสࠢไ๎ࠥา็ศิๆࠤํ฿ไ๋้ࠣๅฬ์ࠠหฯ่๎้ࠦวๅใํำ๏๎็ศฬฺ่๋๊ࠣࠦ็็ࠤ฾์ฯไࠢศ่๎ࠦร็ࠢํๆํ๋ࠠๆสิ้ั๐ࠠษำ้ห๊าࠠไ๊า๎ࠥฮอๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠๅษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠠใัࠣ๎ุฮศࠡษ่ฮ้อมࠡฮ๊หื้ࠠษษ็้้็วห๋๋ࠢีอࠠโ์๊ࠤำ฽่าหࠣ฽้๏ฺࠠ็็ࠤัํวำๅࠣฬฺ๎ัสุࠢั๏ำษ๊ࠡ็๋ีอࠠศๆึฬอࠦโศ็ࠣห้๋ศา็ฯࠤ๊สโหษࠣฬ๊์ูࠡษ็ฬึ์วๆฮ้๋ࠣࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠩॴ"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩॵ"))
		l0SAerv8zGH2Wa(xuztI5QWEKG70CPNdhk4vo6(u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬॶ"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+ggDRehOModi(u"ࠨࠢࠣࠤ࡚ࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡥࡧࡷࡩࡷࡳࡩ࡯ࡧࠣࡸ࡭࡫ࠠࡥ࡫ࡶ࡯ࠥ࡬ࡲࡦࡧࠣࡷࡵࡧࡣࡦࠩॷ"))
		return n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࡈࡤࡰࡸ࡫ਠ")
	if ViRnO0m8fUScTNauvW==InKG0i2r6hHDvgd(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨॸ"):
		hVby8e3aQkFfuE,EaBeVhOsHYg8wub = bkz2aCFLpWqGUcPolSXA980O(gANn35esloKUydOipfSMC6RD2,v1vaBXhQE6tsCjV73HkrNUpgI9DZK)
		if len(hVby8e3aQkFfuE)==wwplD0tEehqH3kYQXs(u"࠲৽"):
			dnS80F92qtLi4vw1(bcgZJWV6UeNSkRA(u"ࠪๅู๊ࠠโ์ࠣษ๏าวะ่่ࠢๆࠦวๅฬะ้๏๊ࠧॹ"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠫࠬॺ"))
			return drHLAY5ENQFe2q9ptKGabo(u"ࡉࡥࡱࡹࡥਡ")
		elif len(hVby8e3aQkFfuE)==wwplD0tEehqH3kYQXs(u"࠴৾"): u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = InKG0i2r6hHDvgd(u"࠴৿")
		elif len(hVby8e3aQkFfuE)>qnPgZ9N15G6Oa8UpMASvLk(u"࠶਀"):
			u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = tYysxJLreEBDdXMIjz4OPa(drHLAY5ENQFe2q9ptKGabo(u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิสࠪॻ"), hVby8e3aQkFfuE)
			if u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo == -nKLEi8CJumazx4qT(u"࠷ਁ") :
				dnS80F92qtLi4vw1(cNaVb1vsT4qWOL0rpE(u"࠭สๆࠢศ่฿อมࠡษ็ฮา๋๊ๅࠩॼ"),iifPEY9ABNzTQp(u"ࠧࠨॽ"))
				return bcgZJWV6UeNSkRA(u"ࡊࡦࡲࡳࡦਢ")
		gANn35esloKUydOipfSMC6RD2 = EaBeVhOsHYg8wub[u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo]
	Zvhon7S5WN8OKk = oUlIcGH2JuWFLvimMXyBQdzK06ge(u"࠰ਂ")
	if ViRnO0m8fUScTNauvW==CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧॾ"):
		Ub1mqOAXNIMK4f6c = Ub1mqOAXNIMK4f6c.rsplit(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨॿ"))[n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"࠱ਃ")]+CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠪ࠲ࡲࡶ࠴ࠨঀ")
		UyA2NgE6DjKsBRqMILZv5tXJ = zIKYyon9QjcvP8RbpqN4TVC3g(hs8IDEMn0YuCHwk,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠫࡌࡋࡔࠨঁ"),gANn35esloKUydOipfSMC6RD2,wwplD0tEehqH3kYQXs(u"ࠬ࠭ং"),v1vaBXhQE6tsCjV73HkrNUpgI9DZK,bcgZJWV6UeNSkRA(u"࠭ࠧঃ"),cNaVb1vsT4qWOL0rpE(u"ࠧࠨ঄"),Tgoa16jMxvYX2(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆ࠰ࡈࡔ࡝ࡎࡍࡑࡄࡈࡤ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨঅ"))
		StjGOQVA4dui5h = UyA2NgE6DjKsBRqMILZv5tXJ.content
		lQUf3AY258LeWch = u5h2Rckvw1E.findall(r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠩࠦࡉ࡝࡚ࡉࡏࡈ࠽࠲࠯ࡅ࡛࡝ࡰ࡟ࡶࡢ࠮࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪআ"),StjGOQVA4dui5h+BGhdkWsEvJjiMFTr3NLn1flU(u"ࠪࡠࡳࡢࡲࠨই"),u5h2Rckvw1E.DOTALL)
		if not lQUf3AY258LeWch:
			l0SAerv8zGH2Wa(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩঈ"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+qnPgZ9N15G6Oa8UpMASvLk(u"ࠬࠦࠠࠡࡖ࡫ࡩࠥࡳ࠳ࡶ࠺ࠣࡪ࡮ࡲࡥࠡࡦ࡬ࡨࠥࡴ࡯ࡵࠢ࡫ࡥࡻ࡫ࠠࡵࡪࡨࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࠦ࡬ࡪࡰ࡮ࡷࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨউ")+gANn35esloKUydOipfSMC6RD2+nKLEi8CJumazx4qT(u"࠭ࠠ࡞ࠩঊ"))
			return n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࡋࡧ࡬ࡴࡧਣ")
		ekTrZlFMu0Kf5QztEnhAs = lQUf3AY258LeWch[xuztI5QWEKG70CPNdhk4vo6(u"࠲਄")]
		if not ekTrZlFMu0Kf5QztEnhAs.startswith(BGhdkWsEvJjiMFTr3NLn1flU(u"ࠧࡩࡶࡷࡴࠬঋ")):
			if ekTrZlFMu0Kf5QztEnhAs.startswith(Tgoa16jMxvYX2(u"ࠨ࠱࠲ࠫঌ")): ekTrZlFMu0Kf5QztEnhAs = gANn35esloKUydOipfSMC6RD2.split(cgtRBdXxSOk7WUfyDhPCls(u"ࠩ࠽ࠫ঍"),iifPEY9ABNzTQp(u"࠴ਅ"))[tZ3gsrTEdzA1S6LXa9WI5px(u"࠴ਆ")]+Tgoa16jMxvYX2(u"ࠪ࠾ࠬ঎")+ekTrZlFMu0Kf5QztEnhAs
			elif ekTrZlFMu0Kf5QztEnhAs.startswith(OyJ1o4AvmWlB75UkFRX(u"ࠫ࠴࠭এ")): ekTrZlFMu0Kf5QztEnhAs = hmcFWJUgiAuGk(gANn35esloKUydOipfSMC6RD2,wwplD0tEehqH3kYQXs(u"ࠬࡻࡲ࡭ࠩঐ"))+ekTrZlFMu0Kf5QztEnhAs
			else: ekTrZlFMu0Kf5QztEnhAs = gANn35esloKUydOipfSMC6RD2.rsplit(yF29Xdsx35wI07Ce4(u"࠭࠯ࠨ঑"),pcWq35MED2dtK(u"࠶ਇ"))[shZ9eOcN2dJnPj(u"࠶ਈ")]+ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠧ࠰ࠩ঒")+ekTrZlFMu0Kf5QztEnhAs
		UyA2NgE6DjKsBRqMILZv5tXJ = RduBx91EMtZDLn.request(cgtRBdXxSOk7WUfyDhPCls(u"ࠨࡉࡈࡘࠬও"),ekTrZlFMu0Kf5QztEnhAs,headers=v1vaBXhQE6tsCjV73HkrNUpgI9DZK,verify=ggDRehOModi(u"ࡌࡡ࡭ࡵࡨਤ"))
		g4gCpE7xW2f = UyA2NgE6DjKsBRqMILZv5tXJ.content
		uHdrxiCg79t = len(g4gCpE7xW2f)
		ooanBu213hZr = len(lQUf3AY258LeWch)
		Zvhon7S5WN8OKk = uHdrxiCg79t*ooanBu213hZr
	else:
		uHdrxiCg79t = r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"࠱ਉ")*hbHgfvqG16IPoFiANjCa
		UyA2NgE6DjKsBRqMILZv5tXJ = RduBx91EMtZDLn.request(wwplD0tEehqH3kYQXs(u"ࠩࡊࡉ࡙࠭ঔ"),gANn35esloKUydOipfSMC6RD2,headers=v1vaBXhQE6tsCjV73HkrNUpgI9DZK,verify=shZ9eOcN2dJnPj(u"ࡇࡣ࡯ࡷࡪਦ"),stream=ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࡔࡳࡷࡨਥ"))
		if usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫক") in UyA2NgE6DjKsBRqMILZv5tXJ.headers: Zvhon7S5WN8OKk = int(UyA2NgE6DjKsBRqMILZv5tXJ.headers[wwplD0tEehqH3kYQXs(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬখ")])
		ooanBu213hZr = int(Zvhon7S5WN8OKk//uHdrxiCg79t)
	tBSELDxbI1z53WUuXnCaN6oydc40PG = int(Zvhon7S5WN8OKk//hbHgfvqG16IPoFiANjCa)+Tgoa16jMxvYX2(u"࠲ਊ")
	if Zvhon7S5WN8OKk<CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠴࠴࠴࠵࠶਋"):
		l0SAerv8zGH2Wa(usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪগ"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+M6PIj8gl1fno7wcqTksDEBK4bU(u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡩࡴࠢࡷࡳࡴࠦࡳ࡮ࡣ࡯ࡰࠥࡵࡲࠡ࡫ࡷࠤ࡮ࡹࠠ࡮࠵ࡸ࠼ࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨঘ")+gANn35esloKUydOipfSMC6RD2+shZ9eOcN2dJnPj(u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫঙ")+str(tBSELDxbI1z53WUuXnCaN6oydc40PG)+yF29Xdsx35wI07Ce4(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡄࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧচ")+str(omex4Hq8abjGE)+InKG0i2r6hHDvgd(u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬছ")+Ub1mqOAXNIMK4f6c+oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠪࠤࡢ࠭জ"))
		xl9MFt1AmY0GrkENug8n(InKG0i2r6hHDvgd(u"ࠫࠬঝ"),cgtRBdXxSOk7WUfyDhPCls(u"ࠬ࠭ঞ"),qnPgZ9N15G6Oa8UpMASvLk(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩট"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠧโึ็ࠤๆ๐ࠠๆ฻ิๅฮࠦออ็้้ࠣ็ࠠศๆไ๎ิ๐่ࠡล๋ࠤฬ๊ๅๅใูࠣ฿๐ัࠡฮาหࠥ๎ไ่าสࠤ้อ๋ࠠ็ๆ๊๊ࠥไษำ้ห๊าࠠหฯ่๎้ࠦ็ัษࠣห้๋ไโࠩঠ"))
		return cgtRBdXxSOk7WUfyDhPCls(u"ࡈࡤࡰࡸ࡫ਧ")
	oMVPjbKDkRW71EYv2ihUIqBL = CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠷࠴࠵਌")
	GQLZC4ezBmqcO6Xkx = omex4Hq8abjGE-tBSELDxbI1z53WUuXnCaN6oydc40PG
	if GQLZC4ezBmqcO6Xkx<oMVPjbKDkRW71EYv2ihUIqBL:
		l0SAerv8zGH2Wa(xuztI5QWEKG70CPNdhk4vo6(u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭ড"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+wwplD0tEehqH3kYQXs(u"ࠩࠣࠤࠥࡔ࡯ࡵࠢࡨࡲࡴࡻࡧࡩࠢࡧ࡭ࡸࡱࠠࡴࡲࡤࡧࡪࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡹ࡮ࡥࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨঢ")+gANn35esloKUydOipfSMC6RD2+iifPEY9ABNzTQp(u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧণ")+str(tBSELDxbI1z53WUuXnCaN6oydc40PG)+OyJ1o4AvmWlB75UkFRX(u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡇࡶࡢ࡫࡯ࡥࡧࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪত")+str(omex4Hq8abjGE)+ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠬࠦࡍࡃࠢ࠰ࠤࠬথ")+str(oMVPjbKDkRW71EYv2ihUIqBL)+PtXn0k9G3ocHRg(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩদ")+Ub1mqOAXNIMK4f6c+XikqnGVSK4v9d3uUICLhDxJyt1M(u"ࠧࠡ࡟ࠪধ"))
		xl9MFt1AmY0GrkENug8n(InKG0i2r6hHDvgd(u"ࠨࠩন"),InKG0i2r6hHDvgd(u"ࠩࠪ঩"),drHLAY5ENQFe2q9ptKGabo(u"่ࠪฬ๊้ࠦฮาࠤู๊วฮหࠣ็ฬ็๊สࠢ็่ฯำๅ๋ๆࠪপ"),JLoPRXt93dpAB(u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤฯำๅ๋ๆ๊ࠤาาๅ่ࠢࠪফ")+str(tBSELDxbI1z53WUuXnCaN6oydc40PG)+bcgZJWV6UeNSkRA(u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣࠫব")+str(omex4Hq8abjGE)+XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠭ࠠๆ์฽หออ๊ห๋่้๋ࠢอศใ฻อࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮฯู้่้ࠣอใๅࠢํะอࠦลษไสลࠥ࠭ভ")+str(oMVPjbKDkRW71EYv2ihUIqBL)+oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣๅฬืฺสࠢาหห๋ว๊๊ࠡิฬࠦๅฺ่ส๋ࠥษๆࠡฮ๊หื้ࠠๅษࠣฮําฯࠡใํ๋๋ࠥำศฯฬࠤ่อแ๋ห่ࠣฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡษ็้฼๊่ษࠩম"))
		return pcWq35MED2dtK(u"ࡉࡥࡱࡹࡥਨ")
	iZL6cN3OkM5 = lLPSDywfu4axrUhvX9RQEpGtso6H0(vvBChXmSty(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨয"),tZ3gsrTEdzA1S6LXa9WI5px(u"ࠩࠪর"),OyJ1o4AvmWlB75UkFRX(u"ࠪࠫ঱"),cNaVb1vsT4qWOL0rpE(u"ࠫ์๊ࠠหำํำࠥะอๆ์็ࠤฬ๊ๅๅใࠣรࠬল"),r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠬอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥำฬๆ้ࠣฮ็ื๊ษษࠣࠫ঳")+str(tBSELDxbI1z53WUuXnCaN6oydc40PG)+cNaVb1vsT4qWOL0rpE(u"࠭ࠠๆ์฽หออ๊ห๋ࠢะ์อาไࠢไ๎์ࠦๅิษะอࠥ็วา฼ฬࠤฯ่ั๋สสࠤࠬ঴")+str(omex4Hq8abjGE)+xuztI5QWEKG70CPNdhk4vo6(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์์ึวࠡษ็้้็ࠠใัࠣ๎าะวอࠢห฽฻ࠦวๅ๊ๅฮ๊ࠥไหฯ่๎้ࠦๅ็ࠢส่ส์สา่อࠤส๊้ࠡฮ๊หื้ࠠ࠯๊่ࠢࠥอๆห่ࠢฮศ้ฯ๊ࠡอี๏ีࠠศๆสืฯ๋ัศำࠣฬฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡมࠪ঵"))
	if iZL6cN3OkM5!=InKG0i2r6hHDvgd(u"࠵਍"):
		xl9MFt1AmY0GrkENug8n(Tgoa16jMxvYX2(u"ࠨࠩশ"),wwplD0tEehqH3kYQXs(u"ࠩࠪষ"),drHLAY5ENQFe2q9ptKGabo(u"ࠪࠫস"),yF29Xdsx35wI07Ce4(u"ࠫฯ๋ࠠฦๆ฽หฦูࠦๆๆํอࠥะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩহ"))
		l0SAerv8zGH2Wa(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠬࡔࡏࡕࡋࡆࡉࠬ঺"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+yF29Xdsx35wI07Ce4(u"࠭ࠠࠡࠢࡘࡷࡪࡸࠠࡳࡧࡩࡹࡸ࡫ࡤࠡࡶࡲࠤࡸࡺࡡࡳࡶࠣࡸ࡭࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡲࡪࠥࡺࡨࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ঻")+gANn35esloKUydOipfSMC6RD2+xuztI5QWEKG70CPNdhk4vo6(u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠ়ࠦࠧ")+Ub1mqOAXNIMK4f6c+CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"ࠨࠢࡠࠫঽ"))
		return iifPEY9ABNzTQp(u"ࡊࡦࡲࡳࡦ਩")
	l0SAerv8zGH2Wa(tZ3gsrTEdzA1S6LXa9WI5px(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩা"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵࡷࡥࡷࡺࡥࡥࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹࠨি"))
	l3OLD1gEfNXtm = zzLBYaEcM1jlKqX5FyONiRJ()
	l3OLD1gEfNXtm.create(Ub1mqOAXNIMK4f6c,Tgoa16jMxvYX2(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬী"))
	xESpd8rtoNqeDwfIVPX6lYmHZy = OyJ1o4AvmWlB75UkFRX(u"࡙ࡸࡵࡦਪ")
	OlDEqB68KZdI5fsipUJzuavcn = YVJPFvuI2CS5KObiZt.time()
	if VVGRN7xiyj: SGQt1BPyaUme3EZqDk = open(Ub1mqOAXNIMK4f6c,n4AkRr7UKxIN9g1vcVETtOdHDz3BCJ(u"ࠬࡽࡢࠨু"))
	else: SGQt1BPyaUme3EZqDk = open(Ub1mqOAXNIMK4f6c.decode(iifPEY9ABNzTQp(u"࠭ࡵࡵࡨ࠻ࠫূ")),pcWq35MED2dtK(u"ࠧࡸࡤࠪৃ"))
	if ViRnO0m8fUScTNauvW==BGhdkWsEvJjiMFTr3NLn1flU(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧৄ"):
		for k0G4LTYt93po in range(tZ3gsrTEdzA1S6LXa9WI5px(u"࠶਎"),ooanBu213hZr+tZ3gsrTEdzA1S6LXa9WI5px(u"࠶਎")):
			ekTrZlFMu0Kf5QztEnhAs = lQUf3AY258LeWch[k0G4LTYt93po-CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠷ਏ")]
			if not ekTrZlFMu0Kf5QztEnhAs.startswith(KKbpxUZnMcj6AJ4QdD(u"ࠩ࡫ࡸࡹࡶࠧ৅")):
				if ekTrZlFMu0Kf5QztEnhAs.startswith(iifPEY9ABNzTQp(u"ࠪ࠳࠴࠭৆")): ekTrZlFMu0Kf5QztEnhAs = gANn35esloKUydOipfSMC6RD2.split(bbw2eajMlG(u"ࠫ࠿࠭ে"),wwplD0tEehqH3kYQXs(u"࠱ਐ"))[drHLAY5ENQFe2q9ptKGabo(u"࠱਑")]+iifPEY9ABNzTQp(u"ࠬࡀࠧৈ")+ekTrZlFMu0Kf5QztEnhAs
				elif ekTrZlFMu0Kf5QztEnhAs.startswith(CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠭࠯ࠨ৉")): ekTrZlFMu0Kf5QztEnhAs = hmcFWJUgiAuGk(gANn35esloKUydOipfSMC6RD2,r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࠧࡶࡴ࡯ࠫ৊"))+ekTrZlFMu0Kf5QztEnhAs
				else: ekTrZlFMu0Kf5QztEnhAs = gANn35esloKUydOipfSMC6RD2.rsplit(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠨ࠱ࠪো"),bbw2eajMlG(u"࠳਒"))[vvBChXmSty(u"࠳ਓ")]+xuztI5QWEKG70CPNdhk4vo6(u"ࠩ࠲ࠫৌ")+ekTrZlFMu0Kf5QztEnhAs
			UyA2NgE6DjKsBRqMILZv5tXJ = RduBx91EMtZDLn.request(bbw2eajMlG(u"ࠪࡋࡊ্࡚ࠧ"),ekTrZlFMu0Kf5QztEnhAs,headers=v1vaBXhQE6tsCjV73HkrNUpgI9DZK,verify=r3flT0zQPa5H7yXEgxJOt92Vc4Ao(u"ࡌࡡ࡭ࡵࡨਫ"))
			g4gCpE7xW2f = UyA2NgE6DjKsBRqMILZv5tXJ.content
			UyA2NgE6DjKsBRqMILZv5tXJ.close()
			SGQt1BPyaUme3EZqDk.write(g4gCpE7xW2f)
			vKqjFY4TE8lfuSdxUMz1aRc = YVJPFvuI2CS5KObiZt.time()
			sCwUMGr2gpBuK6SfVj = vKqjFY4TE8lfuSdxUMz1aRc-OlDEqB68KZdI5fsipUJzuavcn
			QgJnsqpyOYKxXwPBSrAie10bvhWuo = sCwUMGr2gpBuK6SfVj//k0G4LTYt93po
			yDUQaVcH8GF0 = QgJnsqpyOYKxXwPBSrAie10bvhWuo*(ooanBu213hZr+cNaVb1vsT4qWOL0rpE(u"࠵ਔ"))
			HVMNeDUB51LG8cmrO = yDUQaVcH8GF0-sCwUMGr2gpBuK6SfVj
			hyCqU2Ns4B1J3EH7fQVe6DXtzgFuI(l3OLD1gEfNXtm,int(drHLAY5ENQFe2q9ptKGabo(u"࠷࠰࠱ਖ")*k0G4LTYt93po//(ooanBu213hZr+CgG4PuyxsLA8WDzh3FfteZvKQMdom9(u"࠶ਕ"))),vvBChXmSty(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬৎ"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠬาไษ่่ࠢๆࠦวๅใํำ๏๎࠺࠮ࠢส่ัุมࠡำๅ้ࠬ৏"),str(k0G4LTYt93po*uHdrxiCg79t//hbHgfvqG16IPoFiANjCa)+XikqnGVSK4v9d3uUICLhDxJyt1M(u"࠭࠯ࠨ৐")+str(tBSELDxbI1z53WUuXnCaN6oydc40PG)+shZ9eOcN2dJnPj(u"ࠧࠡࡏࡅࠤ้ࠥࠦࠠไอࠤ๊ะศใ์࠽ࠤࠬ৑")+YVJPFvuI2CS5KObiZt.strftime(yF29Xdsx35wI07Ce4(u"ࠣࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥ৒"),YVJPFvuI2CS5KObiZt.gmtime(HVMNeDUB51LG8cmrO))+yF29Xdsx35wI07Ce4(u"ࠩࠣไࠬ৓"))
			if l3OLD1gEfNXtm.iscanceled():
				xESpd8rtoNqeDwfIVPX6lYmHZy = xuztI5QWEKG70CPNdhk4vo6(u"ࡆࡢ࡮ࡶࡩਬ")
				break
	else:
		k0G4LTYt93po = Nqj35AXg06euY1G2d4bSUMQ8wlr(u"࠰ਗ")
		for g4gCpE7xW2f in UyA2NgE6DjKsBRqMILZv5tXJ.iter_content(chunk_size=uHdrxiCg79t):
			SGQt1BPyaUme3EZqDk.write(g4gCpE7xW2f)
			k0G4LTYt93po = k0G4LTYt93po+M6PIj8gl1fno7wcqTksDEBK4bU(u"࠲ਘ")
			vKqjFY4TE8lfuSdxUMz1aRc = YVJPFvuI2CS5KObiZt.time()
			sCwUMGr2gpBuK6SfVj = vKqjFY4TE8lfuSdxUMz1aRc-OlDEqB68KZdI5fsipUJzuavcn
			QgJnsqpyOYKxXwPBSrAie10bvhWuo = sCwUMGr2gpBuK6SfVj/k0G4LTYt93po
			yDUQaVcH8GF0 = QgJnsqpyOYKxXwPBSrAie10bvhWuo*(ooanBu213hZr+JLoPRXt93dpAB(u"࠳ਙ"))
			HVMNeDUB51LG8cmrO = yDUQaVcH8GF0-sCwUMGr2gpBuK6SfVj
			hyCqU2Ns4B1J3EH7fQVe6DXtzgFuI(l3OLD1gEfNXtm,int(bcgZJWV6UeNSkRA(u"࠵࠵࠶ਛ")*k0G4LTYt93po/(ooanBu213hZr+wwplD0tEehqH3kYQXs(u"࠴ਚ"))),nKLEi8CJumazx4qT(u"ࠪหู้ืาࠢไ์็ࠦ็้่ࠢ็ฬ์ࠠหะี๎๋ࠦๅๅใࠣห้็๊ะ์๋ࠫ৔"),qnPgZ9N15G6Oa8UpMASvLk(u"ࠫั๊ศࠡ็็ๅࠥอไโ์า๎ํࡀ࠭ࠡษ็ะืวࠠาไ่ࠫ৕"),str(k0G4LTYt93po*uHdrxiCg79t//hbHgfvqG16IPoFiANjCa)+usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠬ࠵ࠧ৖")+str(tBSELDxbI1z53WUuXnCaN6oydc40PG)+ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"࠭ࠠࡎࡄࠣࠤ่ࠥࠦใฬ้ࠣฯฮโ๋࠼ࠣࠫৗ")+YVJPFvuI2CS5KObiZt.strftime(bcgZJWV6UeNSkRA(u"ࠢࠦࡊ࠽ࠩࡒࡀࠥࡔࠤ৘"),YVJPFvuI2CS5KObiZt.gmtime(HVMNeDUB51LG8cmrO))+xuztI5QWEKG70CPNdhk4vo6(u"ࠨࠢใࠫ৙"))
			if l3OLD1gEfNXtm.iscanceled():
				xESpd8rtoNqeDwfIVPX6lYmHZy = Tgoa16jMxvYX2(u"ࡇࡣ࡯ࡷࡪਭ")
				break
		UyA2NgE6DjKsBRqMILZv5tXJ.close()
	SGQt1BPyaUme3EZqDk.close()
	l3OLD1gEfNXtm.close()
	if not xESpd8rtoNqeDwfIVPX6lYmHZy:
		l0SAerv8zGH2Wa(ffk5ntH2rDZC0xjiLJpAmoRKsTeSOB(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ৚"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠪࠤࠥࠦࡕࡴࡧࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠵ࡩ࡯ࡶࡨࡶࡷࡻࡰࡵࡧࡧࠤࡹ࡮ࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡴࡷࡵࡣࡦࡵࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ৛")+gANn35esloKUydOipfSMC6RD2+OyJ1o4AvmWlB75UkFRX(u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫড়")+Ub1mqOAXNIMK4f6c+tZ3gsrTEdzA1S6LXa9WI5px(u"ࠬࠦ࡝ࠨঢ়"))
		xl9MFt1AmY0GrkENug8n(wwplD0tEehqH3kYQXs(u"࠭ࠧ৞"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠧࠨয়"),M6PIj8gl1fno7wcqTksDEBK4bU(u"ࠨࠩৠ"),BGhdkWsEvJjiMFTr3NLn1flU(u"ࠩอ้ࠥหไ฻ษฤࠤ฾๋ไ๋หࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧৡ"))
		return iifPEY9ABNzTQp(u"ࡖࡵࡹࡪਮ")
	l0SAerv8zGH2Wa(bcgZJWV6UeNSkRA(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪৢ"),CC7Td6HzItGeMfumSaxDEZchp(aUVSgO2ebjwX5iqPykC)+Nqj35AXg06euY1G2d4bSUMQ8wlr(u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࡩࡵࡷ࡯࡮ࡲࡥࡩ࡫ࡤࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࡱࡿࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪৣ")+gANn35esloKUydOipfSMC6RD2+Tgoa16jMxvYX2(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬ৤")+Ub1mqOAXNIMK4f6c+vvBChXmSty(u"࠭ࠠ࡞ࠩ৥"))
	xl9MFt1AmY0GrkENug8n(drHLAY5ENQFe2q9ptKGabo(u"ࠧࠨ০"),iifPEY9ABNzTQp(u"ࠨࠩ১"),usaZLwSGe1k6VDp570yhB4bzWPiFq(u"ࠩࠪ২"),cNaVb1vsT4qWOL0rpE(u"ࠪฮ๊ࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠣฬ๋าวฮࠩ৩"))
	return oUlIcGH2JuWFLvimMXyBQdzK06ge(u"ࡗࡶࡺ࡫ਯ")
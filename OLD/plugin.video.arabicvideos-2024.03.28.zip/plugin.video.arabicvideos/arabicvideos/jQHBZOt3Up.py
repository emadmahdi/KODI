# -*- coding: utf-8 -*-
from LXgKztbkOf import *
aUVSgO2ebjwX5iqPykC = 'EGYBEST4'
tiCRYyX1bWd40Ir3PafQu = '_EB4_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['ايجي بست','اتصل بنا','ايجي بست الاصلي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,BzbaC0qYjMr2WXwsO,text):
	if   mode==800: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==801: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,BzbaC0qYjMr2WXwsO)
	elif mode==802: vS7JufTVsBxw52 = GQsDp6PWFHRE1ki2odqrwjB0ISTLh(url)
	elif mode==803: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==804: vS7JufTVsBxw52 = bbMyD8BfJLk5GT1HwIP9(url)
	elif mode==806: vS7JufTVsBxw52 = ZN3Wh7HABLwRIkFmyEd1Jq(url,BzbaC0qYjMr2WXwsO)
	elif mode==809: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',809,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'فلتر',yONJxHER9BIDPpTV4YsWmc0n+'/trending',804,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(ebm0Z72CDaBzUq,'GET',yONJxHER9BIDPpTV4YsWmc0n,'','','','','EGYBEST4-MENU-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('nav-categories(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			title = title.strip(' ')
			if any(c2eEflztvIX in title for c2eEflztvIX in WLI5tgXRbUPNGJCSVz0vKjBDei3): continue
			if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,801)
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('mainContent(.*?)<footer>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('mainTitle.*?href="(.*?)".*?title="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			title = title.strip(' ')
			if any(c2eEflztvIX in title for c2eEflztvIX in WLI5tgXRbUPNGJCSVz0vKjBDei3): continue
			if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,801,'','mainmenu')
		uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('main-menu(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			title = title.strip(' ')
			if any(c2eEflztvIX in title for c2eEflztvIX in WLI5tgXRbUPNGJCSVz0vKjBDei3): continue
			if 'http' not in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = yONJxHER9BIDPpTV4YsWmc0n+ekTrZlFMu0Kf5QztEnhAs
			uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,801)
	return oo9SgGkiDbs3HRn7z8
def ZN3Wh7HABLwRIkFmyEd1Jq(url,type=''):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','EGYBEST4-SEASONS_EPISODES-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('mainTitle.*?>(.*?)<(.*?)pageContent',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		EKhwoNlubG5A7xaJW2UOg1,Ez1AbVgerRU0YimHu45t9DI7qM,items = '','',[]
		for name,lmO2YJGr6tCV in cWafzb4HoG1Em3Jwxu6C7vZsVi:
			if 'حلقات' in name: Ez1AbVgerRU0YimHu45t9DI7qM = lmO2YJGr6tCV
			if 'مواسم' in name: EKhwoNlubG5A7xaJW2UOg1 = lmO2YJGr6tCV
		if EKhwoNlubG5A7xaJW2UOg1 and not type:
			items = u5h2Rckvw1E.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',EKhwoNlubG5A7xaJW2UOg1,u5h2Rckvw1E.DOTALL)
			if len(items)>1:
				for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
					uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,806,pGjsvdyHfM,'season')
		if Ez1AbVgerRU0YimHu45t9DI7qM and len(items)<2:
			items = u5h2Rckvw1E.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',Ez1AbVgerRU0YimHu45t9DI7qM,u5h2Rckvw1E.DOTALL)
			if items:
				for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
					uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,803,pGjsvdyHfM)
			else:
				items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',Ez1AbVgerRU0YimHu45t9DI7qM,u5h2Rckvw1E.DOTALL)
				for ekTrZlFMu0Kf5QztEnhAs,title in items:
					uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,803)
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,type=''):
	J8BSTexfgwYvhPW1dGV,start,v6YLr90gxdTVfyG83J1XAzjiF,select,d6Toh7rjW5GDQzkJBqAnKwpPu3a = 0,0,'','',''
	if 'pagination' in type:
		Gk2NaZLCuXw3bR,XfOb4VIcPY = url.split('?next=page&')
		emrzEIsMWO2GLw9lpKxSY7n0F = {'Content-Type':'application/x-www-form-urlencoded'}
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'POST',Gk2NaZLCuXw3bR,XfOb4VIcPY,emrzEIsMWO2GLw9lpKxSY7n0F,'','','EGYBEST4-TITLES-1st')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		ZCOosjaQ8x9HDKSVGM6LwW2vy = 'secContent'+oo9SgGkiDbs3HRn7z8+'<footer>'
	else:
		RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','EGYBEST4-TITLES-2nd')
		oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
		ZCOosjaQ8x9HDKSVGM6LwW2vy = oo9SgGkiDbs3HRn7z8
	items,wanHtPNKCfxdoyLFQV3j2RrSmvpBZ,cGYIMSHDj85d3f4ZW2t0bnNkKP = [],False,False
	if not type and '/collections' not in url:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('mainContent(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('href="(.*?)".*?</i>(.*?)</a>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,title in items:
				title = title.strip(' ')
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,801,'','submenu')
				wanHtPNKCfxdoyLFQV3j2RrSmvpBZ = True
	if not wanHtPNKCfxdoyLFQV3j2RrSmvpBZ:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('secContent(.*?)mainContent',ZCOosjaQ8x9HDKSVGM6LwW2vy,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			items = u5h2Rckvw1E.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
				ekTrZlFMu0Kf5QztEnhAs = P2o6ZDHeW790pSQqucvnxzILVUX(ekTrZlFMu0Kf5QztEnhAs)
				pGjsvdyHfM = pGjsvdyHfM.strip('\n')
				title = uTUNPkVwCMKiD5gHLaj(title)
				if '/series/' in ekTrZlFMu0Kf5QztEnhAs and type=='season': uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,806,pGjsvdyHfM,'season')
				elif '/series/' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,806,pGjsvdyHfM)
				elif '/seasons/' in ekTrZlFMu0Kf5QztEnhAs: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,801,pGjsvdyHfM,'season')
				elif '/collections' in url: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,801,pGjsvdyHfM,'collections')
				else: uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,803,pGjsvdyHfM)
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('loadMoreParams = (.*?);',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		if cWafzb4HoG1Em3Jwxu6C7vZsVi:
			lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
			DDwGRHIjFzs = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('dict',lmO2YJGr6tCV)
			d6Toh7rjW5GDQzkJBqAnKwpPu3a = DDwGRHIjFzs['ajaxurl']
			LTIzl7GJ3StWsN = int(DDwGRHIjFzs['current_page'])+1
			tw4oiljgmkFa8E9XNzGsB1eTWJC = int(DDwGRHIjFzs['max_page'])
			hcb92vtUy4u0r = DDwGRHIjFzs['posts'].replace('False','false').replace('True','true').replace('None','null')
			if LTIzl7GJ3StWsN<tw4oiljgmkFa8E9XNzGsB1eTWJC:
				XfOb4VIcPY = 'action=loadmore&query='+QQXTVNve6DMHBp4scG170kR2lWY(hcb92vtUy4u0r,'')+'&page='+str(LTIzl7GJ3StWsN)
				gANn35esloKUydOipfSMC6RD2 = d6Toh7rjW5GDQzkJBqAnKwpPu3a+'?next=page&'+XfOb4VIcPY
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'جلب المزيد',gANn35esloKUydOipfSMC6RD2,801,'','pagination_'+type)
		elif '?next=page&' in url:
			XfOb4VIcPY,GRM9OPVoZmIu1fgQiX = XfOb4VIcPY.rsplit('=',1)
			GRM9OPVoZmIu1fgQiX = int(GRM9OPVoZmIu1fgQiX)+1
			gANn35esloKUydOipfSMC6RD2 = Gk2NaZLCuXw3bR+'?next=page&'+XfOb4VIcPY+'='+str(GRM9OPVoZmIu1fgQiX)
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'جلب المزيد',gANn35esloKUydOipfSMC6RD2,801,'','pagination_'+type)
	return
def bbMyD8BfJLk5GT1HwIP9(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',url,'','','','','EGYBEST4-FILTERS-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('sub_nav(.*?)secContent ',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		ppZ9muD1GkPnFRX52jxBUIy = u5h2Rckvw1E.findall('"current_opt">(.*?)<(.*?)</div>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for name,lmO2YJGr6tCV in ppZ9muD1GkPnFRX52jxBUIy:
			if 'التصنيف' in name: continue
			name = name.strip(' ')
			items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
			for ekTrZlFMu0Kf5QztEnhAs,c2eEflztvIX in items:
				title = name+':  '+c2eEflztvIX
				uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,801,'','filter')
	return
def N5AOlmb8u1y4FHxvJXU(url):
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(a2VuAbpQkGfMwSIcsP1XH6mletyzx,'GET',url,'','','','','EGYBEST4-PLAY-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	PmF0XjQN51GpKACfLgnyTv7 = u5h2Rckvw1E.findall('<td>التصنيف</td>.*?">(.*?)<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if PmF0XjQN51GpKACfLgnyTv7 and dQorkS3qBhIMDWKHl(aUVSgO2ebjwX5iqPykC,url,PmF0XjQN51GpKACfLgnyTv7): return
	GnuaoT9MxiCg,ZIB1Cc3wFoi5xYNgOThn2mAM = [],[]
	nWxJ9ZDlByIVfYc1MiFtGp = u5h2Rckvw1E.findall('postEmbed.*?post=(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if nWxJ9ZDlByIVfYc1MiFtGp:
		lQUf3AY258LeWch = yB3NPc2ZhbwFEi1X0dv.b64decode(nWxJ9ZDlByIVfYc1MiFtGp[0])
		if VVGRN7xiyj: lQUf3AY258LeWch = lQUf3AY258LeWch.decode('utf8')
		lQUf3AY258LeWch = TKNHcPBVEYIRmyD8fxuSUrhg5bJswZ('dict',lQUf3AY258LeWch)
		lQUf3AY258LeWch = list(lQUf3AY258LeWch.values())
		for ekTrZlFMu0Kf5QztEnhAs in lQUf3AY258LeWch:
			if ekTrZlFMu0Kf5QztEnhAs not in ZIB1Cc3wFoi5xYNgOThn2mAM:
				ZIB1Cc3wFoi5xYNgOThn2mAM.append(ekTrZlFMu0Kf5QztEnhAs)
				NDwLctrHpYz3JBP = hmcFWJUgiAuGk(ekTrZlFMu0Kf5QztEnhAs,'name')
				GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs+'?named='+NDwLctrHpYz3JBP+'__watch')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('pageContentDown(.*?)</table>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('<tr>.*?<td>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</td>.*?href="(.*?)"',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ohAHUqdbWFi8D1L4Xwzus0f3RYv,ekTrZlFMu0Kf5QztEnhAs in items:
			if ekTrZlFMu0Kf5QztEnhAs not in ZIB1Cc3wFoi5xYNgOThn2mAM:
				if '/?url=' in ekTrZlFMu0Kf5QztEnhAs: ekTrZlFMu0Kf5QztEnhAs = ekTrZlFMu0Kf5QztEnhAs.split('/?url=')[1]
				ZIB1Cc3wFoi5xYNgOThn2mAM.append(ekTrZlFMu0Kf5QztEnhAs)
				NDwLctrHpYz3JBP = hmcFWJUgiAuGk(ekTrZlFMu0Kf5QztEnhAs,'name')
				GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs+'?named='+NDwLctrHpYz3JBP+'__download____'+ohAHUqdbWFi8D1L4Xwzus0f3RYv)
	import jSLK8GCOcy
	jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(GnuaoT9MxiCg,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if not search: search = FBrXsYeCEp3()
	if not search: return
	GHFUMEOSrvhmIoVWxwN8j4 = search.replace(' ','+')
	url = yONJxHER9BIDPpTV4YsWmc0n+'/?s='+GHFUMEOSrvhmIoVWxwN8j4
	ll0a2AwztChcpsDUMi4rGW3b61XZES(url,'search')
	return
# -*- coding: utf-8 -*-
from LXgKztbkOf import *
headers = { 'User-Agent' : '' }
aUVSgO2ebjwX5iqPykC = 'AKOAM'
tiCRYyX1bWd40Ir3PafQu = '_AKO_'
yONJxHER9BIDPpTV4YsWmc0n = pgPfwZleTHVQ9a[aUVSgO2ebjwX5iqPykC][0]
KLoNd0ah2bCr5j1lAU = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def cc03CYPLaxRfUKJb9eynFTr(mode,url,text):
	if   mode==70: vS7JufTVsBxw52 = LitkEX0THgZadBAYn3hUIRoFC()
	elif mode==71: vS7JufTVsBxw52 = PCK6HYUAzqoscN0rFp8TamQ4y3hEMV(url)
	elif mode==72: vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,text)
	elif mode==73: vS7JufTVsBxw52 = Hym54KhQCnTuMrwj(url)
	elif mode==74: vS7JufTVsBxw52 = N5AOlmb8u1y4FHxvJXU(url)
	elif mode==79: vS7JufTVsBxw52 = bB8m3r5asjpdG0ulEJg(text)
	else: vS7JufTVsBxw52 = False
	return vS7JufTVsBxw52
def LitkEX0THgZadBAYn3hUIRoFC():
	uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'بحث في الموقع','',79,'','','_REMEMBERRESULTS_')
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'سلسلة افلام','',79,'','','سلسلة افلام')
	uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+'سلاسل منوعة','',79,'','','سلسلة')
	uQNUfbZx9yj0F('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	WLI5tgXRbUPNGJCSVz0vKjBDei3 = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,yONJxHER9BIDPpTV4YsWmc0n,'',headers,'','AKOAM-MENU-1st')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="partions"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)">(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			if title not in WLI5tgXRbUPNGJCSVz0vKjBDei3:
				uQNUfbZx9yj0F('folder',aUVSgO2ebjwX5iqPykC+'_SCRIPT_'+tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,71)
	return oo9SgGkiDbs3HRn7z8
def PCK6HYUAzqoscN0rFp8TamQ4y3hEMV(url):
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,url,'',headers,'','AKOAM-CATEGORIES-1st')
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('sect_parts(.*?)</div>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			title = title.strip(' ')
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,72)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'جميع الفروع',url,72)
	else: ll0a2AwztChcpsDUMi4rGW3b61XZES(url,'')
	return
def ll0a2AwztChcpsDUMi4rGW3b61XZES(url,type):
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,url,'',headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('section_title featured_title(.*?)subjects-crousel',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	elif type=='search':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('akoam_result(.*?)<script',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	elif type=='more':
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('section_title more_title(.*?)footer_bottom_services',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	else:
		cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('navigation(.*?)<script',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not items and cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,pGjsvdyHfM,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace('\n','').strip(' ')
		title = uTUNPkVwCMKiD5gHLaj(title)
		if any(c2eEflztvIX in title for c2eEflztvIX in KLoNd0ah2bCr5j1lAU): uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,73,pGjsvdyHfM)
		else: uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,73,pGjsvdyHfM)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="pagination"(.*?)</ul>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if cWafzb4HoG1Em3Jwxu6C7vZsVi:
		lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
		items = u5h2Rckvw1E.findall("</li><li >.*?href='(.*?)'>(.*?)<",lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		for ekTrZlFMu0Kf5QztEnhAs,title in items:
			uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+'صفحة '+title,ekTrZlFMu0Kf5QztEnhAs,72,'','',type)
	return
def BtvMUDQdiAVc(url):
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(ebm0Z72CDaBzUq,url,'',headers,True,'AKOAM-SECTIONS-2nd')
	gANn35esloKUydOipfSMC6RD2 = u5h2Rckvw1E.findall('"href","(.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	gANn35esloKUydOipfSMC6RD2 = gANn35esloKUydOipfSMC6RD2[1]
	return gANn35esloKUydOipfSMC6RD2
def Hym54KhQCnTuMrwj(url):
	oo9SgGkiDbs3HRn7z8 = wANetMq45ZG2EhvL38HgfYCBzn1o(QQJtZ6rMvS1wdDsHnahT7,url,'',headers,True,'AKOAM-SECTIONS-1st')
	jodANqG9Qe5IVXwa3SZh1tPkJp2DrR = u5h2Rckvw1E.findall('"(https*://akwam.net/\w+.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	ogRiLDvSft9OCIx5GzF = u5h2Rckvw1E.findall('"(https*://underurl.com/\w+.*?)"',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if jodANqG9Qe5IVXwa3SZh1tPkJp2DrR or ogRiLDvSft9OCIx5GzF:
		if jodANqG9Qe5IVXwa3SZh1tPkJp2DrR: UcmHDPlLWaSf = jodANqG9Qe5IVXwa3SZh1tPkJp2DrR[0]
		elif ogRiLDvSft9OCIx5GzF: UcmHDPlLWaSf = BtvMUDQdiAVc(ogRiLDvSft9OCIx5GzF[0])
		UcmHDPlLWaSf = P2o6ZDHeW790pSQqucvnxzILVUX(UcmHDPlLWaSf)
		import Jn5W8Lt2m3
		if '/series/' in UcmHDPlLWaSf or '/shows/' in UcmHDPlLWaSf: Jn5W8Lt2m3.GA2KIlbOsoYtxpkDF71(UcmHDPlLWaSf)
		else: Jn5W8Lt2m3.N5AOlmb8u1y4FHxvJXU(UcmHDPlLWaSf)
		return
	PmF0XjQN51GpKACfLgnyTv7 = u5h2Rckvw1E.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if PmF0XjQN51GpKACfLgnyTv7 and dQorkS3qBhIMDWKHl(aUVSgO2ebjwX5iqPykC,url,PmF0XjQN51GpKACfLgnyTv7): return
	items = u5h2Rckvw1E.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs,title in items:
		title = uTUNPkVwCMKiD5gHLaj(title)
		uQNUfbZx9yj0F('folder',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,73)
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	if not cWafzb4HoG1Em3Jwxu6C7vZsVi:
		dnS80F92qtLi4vw1('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,pGjsvdyHfM,lmO2YJGr6tCV = cWafzb4HoG1Em3Jwxu6C7vZsVi[0]
	name = name.strip(' ')
	if 'sub_epsiode_title' in lmO2YJGr6tCV:
		items = u5h2Rckvw1E.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	else:
		WViD4NFm2uCX = u5h2Rckvw1E.findall('sub_file_title\'>(.*?) - <i>',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		items = []
		for filename in WViD4NFm2uCX:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل','') ]
	count = 0
	hVby8e3aQkFfuE,YH8KpsQCgic579Tw3eUAZLDXrqWG = [],[]
	size = len(items)
	for title,filename in items:
		GvoaR8HMyTDxF0fz5cwu1JnSNWP = ''
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: GvoaR8HMyTDxF0fz5cwu1JnSNWP = filename.split('.')[-1]
		title = title.replace('\n','').strip(' ')
		hVby8e3aQkFfuE.append(title)
		YH8KpsQCgic579Tw3eUAZLDXrqWG.append(count)
		count += 1
	if size>0:
		if any(c2eEflztvIX in name for c2eEflztvIX in KLoNd0ah2bCr5j1lAU):
			if size==1:
				u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = 0
			else:
				u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo = tYysxJLreEBDdXMIjz4OPa('اختر الفيديو المناسب:', hVby8e3aQkFfuE)
				if u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo == -1: return
			N5AOlmb8u1y4FHxvJXU(url+'?section='+str(1+YH8KpsQCgic579Tw3eUAZLDXrqWG[size-u3u8AlHPwYpmcvjxXyR2NgBOdQE9Zo-1]))
		else:
			for Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE in reversed(range(size)):
				title = name + ' - ' + hVby8e3aQkFfuE[Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE]
				title = title.replace('\n','').strip(' ')
				ekTrZlFMu0Kf5QztEnhAs = url + '?section='+str(size-Gg4ChsbTi5AjNutr9PWDaQw3HxVqeE)
				uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+title,ekTrZlFMu0Kf5QztEnhAs,74,pGjsvdyHfM)
	else:
		uQNUfbZx9yj0F('video',tiCRYyX1bWd40Ir3PafQu+'الرابط ليس فيديو','',9999,pGjsvdyHfM)
	return
def N5AOlmb8u1y4FHxvJXU(url):
	gANn35esloKUydOipfSMC6RD2,zAjwuoRY98mXN6xvE = url.split('?section=')
	RoQL91PphqCJg4W0e6Fnsl = zIKYyon9QjcvP8RbpqN4TVC3g(QQJtZ6rMvS1wdDsHnahT7,'GET',gANn35esloKUydOipfSMC6RD2,'',headers,True,'','AKOAM-PLAY_AKOAM-1st')
	oo9SgGkiDbs3HRn7z8 = RoQL91PphqCJg4W0e6Fnsl.content
	cWafzb4HoG1Em3Jwxu6C7vZsVi = u5h2Rckvw1E.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',oo9SgGkiDbs3HRn7z8,u5h2Rckvw1E.DOTALL)
	x6rvcyQLgDAP4Fo7n = cWafzb4HoG1Em3Jwxu6C7vZsVi[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	x6rvcyQLgDAP4Fo7n = x6rvcyQLgDAP4Fo7n + 'direct_link_box'
	ppZ9muD1GkPnFRX52jxBUIy = u5h2Rckvw1E.findall('epsoide_box(.*?)direct_link_box',x6rvcyQLgDAP4Fo7n,u5h2Rckvw1E.DOTALL)
	zAjwuoRY98mXN6xvE = len(ppZ9muD1GkPnFRX52jxBUIy)-int(zAjwuoRY98mXN6xvE)
	lmO2YJGr6tCV = ppZ9muD1GkPnFRX52jxBUIy[zAjwuoRY98mXN6xvE]
	GnuaoT9MxiCg = []
	sP91CSiMONbJhy7p3 = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = u5h2Rckvw1E.findall("class='download_btn.*?href='(.*?)'",lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for ekTrZlFMu0Kf5QztEnhAs in items:
		GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs+'?named=________akoam')
	items = u5h2Rckvw1E.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
	for OOCR8trYdzKv9q1yTls,ekTrZlFMu0Kf5QztEnhAs in items:
		OOCR8trYdzKv9q1yTls = OOCR8trYdzKv9q1yTls.split('/')[-1]
		OOCR8trYdzKv9q1yTls = OOCR8trYdzKv9q1yTls.split('.')[0]
		if OOCR8trYdzKv9q1yTls in sP91CSiMONbJhy7p3:
			GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs+'?named='+sP91CSiMONbJhy7p3[OOCR8trYdzKv9q1yTls]+'________akoam')
		else: GnuaoT9MxiCg.append(ekTrZlFMu0Kf5QztEnhAs+'?named='+OOCR8trYdzKv9q1yTls+'________akoam')
	if not GnuaoT9MxiCg:
		message = u5h2Rckvw1E.findall('sub-no-file.*?\n(.*?)\n',lmO2YJGr6tCV,u5h2Rckvw1E.DOTALL)
		if message: xl9MFt1AmY0GrkENug8n('','','رسالة من الموقع الاصلي',message[0])
	else:
		import jSLK8GCOcy
		jSLK8GCOcy.FkL7g4ob1HyAeIMcw5jQKmr(GnuaoT9MxiCg,aUVSgO2ebjwX5iqPykC,'video',url)
	return
def bB8m3r5asjpdG0ulEJg(search):
	search,dza2VO9NvX,showDialogs = kh9lHs2cCOInRLBDJiofTVwSv6(search)
	if search=='': search = FBrXsYeCEp3()
	if search=='': return
	GHFUMEOSrvhmIoVWxwN8j4 = search.replace(' ','%20')
	url = yONJxHER9BIDPpTV4YsWmc0n + '/search/'+GHFUMEOSrvhmIoVWxwN8j4
	vS7JufTVsBxw52 = ll0a2AwztChcpsDUMi4rGW3b61XZES(url,'search')
	return
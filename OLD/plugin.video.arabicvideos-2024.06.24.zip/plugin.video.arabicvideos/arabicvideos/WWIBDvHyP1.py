﻿# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'ALMAAREF'
headers = {'User-Agent':''}
mmDwMlfoHtG5XT19VLIWqCR8i = '_MRF_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
DDXTwbRBaj3e2rSsPQ = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text,EfNzW3kLhcMTu07HrP28X9nFA6vpGd):
	if   mode==40: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==41: zpXG3Ky6ou8ndWHkb4 = jvAw2XIh981zBbtonQELUFmfdyiJa()
	elif mode==42: zpXG3Ky6ou8ndWHkb4 = t7VNhj3OGR0ycekDm5aXUYSgzfsi(text,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif mode==43: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==44: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(text,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif mode==49: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',49)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('live',mmDwMlfoHtG5XT19VLIWqCR8i+'البث الحي لقناة المعارف','',41)
	t7VNhj3OGR0ycekDm5aXUYSgzfsi('','1')
	return
def FHyUEhc1tK2n7s96vRzZLNYroDWq(tY3Dfrp6cMKFj,Hqkx8T9PXZiVf):
	search,sort,kdMqIHf49N15m8OgBoaE,BBskpK6cGZJ,yyE1NuUMd9Y = '',[],[],[],[]
	X4XyOPCEu65AMYebxwaVW,flQUjgE7z4Xo82VnJG = xlk0nsAXjIrvOQFL4Vi1MJG5TChu(tY3Dfrp6cMKFj)
	for RHb9zAjcuTIoyZ0aDgS1pQYmUs8 in list(flQUjgE7z4Xo82VnJG.keys()):
		hieW1zRUG5w9AykJjv0X = flQUjgE7z4Xo82VnJG[RHb9zAjcuTIoyZ0aDgS1pQYmUs8]
		if not hieW1zRUG5w9AykJjv0X: continue
		if   RHb9zAjcuTIoyZ0aDgS1pQYmUs8=='sort': sort = [hieW1zRUG5w9AykJjv0X]
		elif RHb9zAjcuTIoyZ0aDgS1pQYmUs8=='series': kdMqIHf49N15m8OgBoaE = [hieW1zRUG5w9AykJjv0X]
		elif RHb9zAjcuTIoyZ0aDgS1pQYmUs8=='search': search = hieW1zRUG5w9AykJjv0X
		elif RHb9zAjcuTIoyZ0aDgS1pQYmUs8=='category': BBskpK6cGZJ = [hieW1zRUG5w9AykJjv0X]
		elif RHb9zAjcuTIoyZ0aDgS1pQYmUs8=='specialist': yyE1NuUMd9Y = [hieW1zRUG5w9AykJjv0X]
	vpWXJDC4lTByaqcn56OFwUmieV = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":BBskpK6cGZJ,"specialist":yyE1NuUMd9Y,"series":kdMqIHf49N15m8OgBoaE,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(Hqkx8T9PXZiVf)}}
	import json as IsRfCubK4FeYlZgEcXn6U5PNa0
	vpWXJDC4lTByaqcn56OFwUmieV = IsRfCubK4FeYlZgEcXn6U5PNa0.dumps(vpWXJDC4lTByaqcn56OFwUmieV)
	ELbNB92cOh5dqtpVmi40kY = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'POST',ELbNB92cOh5dqtpVmi40kY,vpWXJDC4lTByaqcn56OFwUmieV,'','','','ALMAAREF-REQUEST_DATA_PAGE-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	data = JKw5OWktPZB('dict',BBlXpmUyhFDwNtCVAHoE)
	return data
def t7VNhj3OGR0ycekDm5aXUYSgzfsi(tY3Dfrp6cMKFj,level):
	EHDeldN7L2k19JBUqhmsuSXiwV = FHyUEhc1tK2n7s96vRzZLNYroDWq(tY3Dfrp6cMKFj,'1')
	UCEFMfKbgpd = EHDeldN7L2k19JBUqhmsuSXiwV['facets']
	if level=='1':
		UCEFMfKbgpd = UCEFMfKbgpd['video_categories']
		items = GGvHJKP9LUxEk10Fw.findall('<div(.*?)/div>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for BrVNsC72UYWES4A in items:
			rYgcPZ9wVdDF = GGvHJKP9LUxEk10Fw.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',BrVNsC72UYWES4A+'<',GGvHJKP9LUxEk10Fw.DOTALL)
			if not rYgcPZ9wVdDF: rYgcPZ9wVdDF = GGvHJKP9LUxEk10Fw.findall('data-value=\\"(.*?)\\">(.*?)<',BrVNsC72UYWES4A+'<',GGvHJKP9LUxEk10Fw.DOTALL)
			BBskpK6cGZJ,title = rYgcPZ9wVdDF[0]
			if not tY3Dfrp6cMKFj: cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,'',42,'','2','?category='+BBskpK6cGZJ)
			else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,'',42,'','2',tY3Dfrp6cMKFj+'&category='+BBskpK6cGZJ)
	if level=='2':
		UCEFMfKbgpd = UCEFMfKbgpd['specialist']
		items = GGvHJKP9LUxEk10Fw.findall('value="(.*?)".*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for yyE1NuUMd9Y,title in items:
			if not yyE1NuUMd9Y: title = title = 'الجميع'
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,'',42,'','3',tY3Dfrp6cMKFj+'&specialist='+yyE1NuUMd9Y)
	elif level=='3':
		UCEFMfKbgpd = UCEFMfKbgpd['series']
		items = GGvHJKP9LUxEk10Fw.findall('value="(.*?)".*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for kdMqIHf49N15m8OgBoaE,title in items:
			if not kdMqIHf49N15m8OgBoaE: title = title = 'الجميع'
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,'',42,'','4',tY3Dfrp6cMKFj+'&series='+kdMqIHf49N15m8OgBoaE)
	elif level=='4':
		UCEFMfKbgpd = UCEFMfKbgpd['sort_video']
		items = GGvHJKP9LUxEk10Fw.findall('value="(.*?)".*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for sort,title in items:
			if not sort: continue
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,'',44,'','1',tY3Dfrp6cMKFj+'&sort='+sort)
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(tY3Dfrp6cMKFj,Hqkx8T9PXZiVf):
	EHDeldN7L2k19JBUqhmsuSXiwV = FHyUEhc1tK2n7s96vRzZLNYroDWq(tY3Dfrp6cMKFj,Hqkx8T9PXZiVf)
	UCEFMfKbgpd = EHDeldN7L2k19JBUqhmsuSXiwV['template']
	items = GGvHJKP9LUxEk10Fw.findall('src="(.*?)".*?href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for VFqpJjRySZvgi,ELbNB92cOh5dqtpVmi40kY,title in items:
		cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,43,VFqpJjRySZvgi)
	UCEFMfKbgpd = EHDeldN7L2k19JBUqhmsuSXiwV['facets']['pagination']
	items = GGvHJKP9LUxEk10Fw.findall('data-page="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for EfNzW3kLhcMTu07HrP28X9nFA6vpGd,title in items:
		if Hqkx8T9PXZiVf==EfNzW3kLhcMTu07HrP28X9nFA6vpGd: continue
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,'',44,'',EfNzW3kLhcMTu07HrP28X9nFA6vpGd,tY3Dfrp6cMKFj)
	return
def SUfe4unWoXBNFz90xqy(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','ALMAAREF-PLAY-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall('<video src="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall('youtube_url.*?(http.*?)&',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	uuIjMn1YTf687WlRcOmhq4G23H = []
	if ELbNB92cOh5dqtpVmi40kY:
		ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY[0].replace('\/','/')
		uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY)
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(uuIjMn1YTf687WlRcOmhq4G23H,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def jvAw2XIh981zBbtonQELUFmfdyiJa():
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',NBm2aWhPzoTpdYn+'/بث-مباشر','','','','','ALMAAREF-LIVE-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	url = GGvHJKP9LUxEk10Fw.findall('"svpPlayer".*?(http.*?)&',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	url = url[0].replace('\\','')
	ICifW6hdKqxkAJ02XZgHysOwoV9Dc5(url,cTJphS1nFz5EUgNWm86C,'live')
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	h5nARXQO2GMVLtoqK3kZNb = False
	if search=='':
		search = yMRXZIpKxlSkaE6iCO()
		h5nARXQO2GMVLtoqK3kZNb = True
	if search=='': return
	if not h5nARXQO2GMVLtoqK3kZNb: xoiXMWjJC3pnQqurIGPkRSl8e('?search='+search,'1')
	else: t7VNhj3OGR0ycekDm5aXUYSgzfsi('?search='+search,'1')
	return
# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'BOKRA'
mmDwMlfoHtG5XT19VLIWqCR8i = '_BKR_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
headers = {'User-Agent':''}
DDXTwbRBaj3e2rSsPQ = ['افلام للكبار','بكرا TV']
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==370: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==371: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,text)
	elif mode==372: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==374: zpXG3Ky6ou8ndWHkb4 = R9jWaFECyOLwBJkseYc57z(url)
	elif mode==375: zpXG3Ky6ou8ndWHkb4 = JaftLv58zYbRK2MAQZ(url)
	elif mode==376: zpXG3Ky6ou8ndWHkb4 = nOFfJj2zuvx5MEqapyR(0,url)
	elif mode==377: zpXG3Ky6ou8ndWHkb4 = nOFfJj2zuvx5MEqapyR(1,url)
	elif mode==379: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',NBm2aWhPzoTpdYn,'','','','','BOKRA-MENU-1st')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',379,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('right-side(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
			if not any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in DDXTwbRBaj3e2rSsPQ):
				cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,371)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'المميزة',NBm2aWhPzoTpdYn,375)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'الأحدث',NBm2aWhPzoTpdYn,376)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'قائمة الممثلين',NBm2aWhPzoTpdYn,374)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="container"(.*?)top-menu',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items[7:]:
			title = title.strip(' ')
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
			if not any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in DDXTwbRBaj3e2rSsPQ):
				cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,371)
		for ELbNB92cOh5dqtpVmi40kY,title in items[0:7]:
			title = title.strip(' ')
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
			if not any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in DDXTwbRBaj3e2rSsPQ):
				cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,371)
	return
def R9jWaFECyOLwBJkseYc57z(website=''):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',NBm2aWhPzoTpdYn,'','','','','BOKRA-ACTORSMENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="row cat Tags"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)" title="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			if 'http' in ELbNB92cOh5dqtpVmi40kY: continue
			else: ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
			if not any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in DDXTwbRBaj3e2rSsPQ):
				cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,371)
	return
def JaftLv58zYbRK2MAQZ(website=''):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'GET',NBm2aWhPzoTpdYn,'','','','','BOKRA-FEATURED-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"MainContent"(.*?)main-title2',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
			if not any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in DDXTwbRBaj3e2rSsPQ):
				VFqpJjRySZvgi = VFqpJjRySZvgi.replace('://',':///').replace('//','/').replace(' ','%20')
				cd0aGwCPExbFU5pYNu8r('video',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,372,VFqpJjRySZvgi)
	return
def nOFfJj2zuvx5MEqapyR(id,website=''):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'GET',NBm2aWhPzoTpdYn,'','','','','BOKRA-WATCHINGNOW-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('main-title2(.*?)class="row',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[id]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
			if not any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in DDXTwbRBaj3e2rSsPQ):
				VFqpJjRySZvgi = VFqpJjRySZvgi.replace('://',':///').replace('//','/').replace(' ','%20')
				cd0aGwCPExbFU5pYNu8r('video',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,372,VFqpJjRySZvgi)
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(url,co2tTWeh79bO=''):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','BOKRA-TITLES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	if 'vidpage_' in url:
		ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall('href="(/Album-.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if ELbNB92cOh5dqtpVmi40kY:
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY[0]
			xoiXMWjJC3pnQqurIGPkRSl8e(ELbNB92cOh5dqtpVmi40kY)
			return
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class=" subcats"(.*?)class="col-md-3',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if co2tTWeh79bO=='' and EeQqAGc0W5r6nlBbChwfZL and EeQqAGc0W5r6nlBbChwfZL[0].count('href')>1:
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع',url,371,'','','titles')
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)" title="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/'+ELbNB92cOh5dqtpVmi40kY
			title = title.strip(' ')
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,371)
	else:
		IcJOGsq3Ff7EmkiLx = []
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="col-md-3(.*?)col-xs-12',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if not EeQqAGc0W5r6nlBbChwfZL: EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="col-sm-8"(.*?)col-xs-12',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
				ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
				title = title.strip(' ')
				VFqpJjRySZvgi = VFqpJjRySZvgi.replace('://',':///').replace('//','/').replace(' ','%20')
				if '/al_' in ELbNB92cOh5dqtpVmi40kY:
					cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,371,VFqpJjRySZvgi)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					qUGxSK2VwsiBAdkDZnJ605vQeg = GGvHJKP9LUxEk10Fw.findall('(.*?) - +الحلقة +\d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
					if qUGxSK2VwsiBAdkDZnJ605vQeg: title = '_MOD_مسلسل '+qUGxSK2VwsiBAdkDZnJ605vQeg[0]
					if title not in IcJOGsq3Ff7EmkiLx:
						IcJOGsq3Ff7EmkiLx.append(title)
						cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,371,VFqpJjRySZvgi)
				else: cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,372,VFqpJjRySZvgi)
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="pagination(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
			items = GGvHJKP9LUxEk10Fw.findall('class="".*?href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
				title = 'صفحة '+DwNC3gEonizsB6a0v1F(title)
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,371,'','','titles')
	return
def SUfe4unWoXBNFz90xqy(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'GET',url,'','','','','BOKRA-PLAY-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	NbE4qnzmPKGWtjYpoRL3HTS1A = GGvHJKP9LUxEk10Fw.findall('label-success mrg-btm-5 ">(.*?)<',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if NbE4qnzmPKGWtjYpoRL3HTS1A and hNCJPTucIV7GOSR0HytZ6eQrqEUpw(cTJphS1nFz5EUgNWm86C,url,NbE4qnzmPKGWtjYpoRL3HTS1A): return
	XwyU6PQgprMI0 = ''
	dR2vHyAtl8pJN1 = GGvHJKP9LUxEk10Fw.findall('var url = "(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if dR2vHyAtl8pJN1: dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1[0]
	else: dR2vHyAtl8pJN1 = url.replace('/vidpage_','/Play/')
	if 'http' not in dR2vHyAtl8pJN1: dR2vHyAtl8pJN1 = NBm2aWhPzoTpdYn+dR2vHyAtl8pJN1
	dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1.strip('-')
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'GET',dR2vHyAtl8pJN1,'','','','','BOKRA-PLAY-2nd')
	X3in5vNhqwWEG2TafmVCrFbSYDxjoK = WbTGMHnDysdYZ2lFA.content
	XwyU6PQgprMI0 = GGvHJKP9LUxEk10Fw.findall('src="(.*?)"',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
	if XwyU6PQgprMI0:
		XwyU6PQgprMI0 = XwyU6PQgprMI0[-1]
		if 'http' not in XwyU6PQgprMI0: XwyU6PQgprMI0 = 'http:'+XwyU6PQgprMI0
		if '/PLAY/' not in dR2vHyAtl8pJN1:
			if 'embed.min.js' in XwyU6PQgprMI0:
				GGh2O5jEVcpNiKMlnbD = GGvHJKP9LUxEk10Fw.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
				if GGh2O5jEVcpNiKMlnbD:
					gaeJuOn7XZm298cSMBGI4FY, ylFqG1bgUZzr6W = GGh2O5jEVcpNiKMlnbD[0]
					XwyU6PQgprMI0 = RfKuIXwPAiWtmyF(XwyU6PQgprMI0,'url')+'/v2/'+gaeJuOn7XZm298cSMBGI4FY+'/config/'+ylFqG1bgUZzr6W+'.json'
		import XXPcDGxLdW
		XXPcDGxLdW.YguVs5RJFwDK6X8E([XwyU6PQgprMI0],cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	search = search.replace(' ','+')
	url = NBm2aWhPzoTpdYn+'/Search/'+search
	xoiXMWjJC3pnQqurIGPkRSl8e(url)
	return
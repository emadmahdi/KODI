# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'WECIMA'
headers = {'User-Agent':''}
mmDwMlfoHtG5XT19VLIWqCR8i = '_WCM_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
DDXTwbRBaj3e2rSsPQ = ['مصارعة حرة','wwe']
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==560: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==561: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,text)
	elif mode==562: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==563: zpXG3Ky6ou8ndWHkb4 = hWPvGlXZ5arzV7(url,text)
	elif mode==564: zpXG3Ky6ou8ndWHkb4 = hWJg9P6lEYT5aGDizcb(url,'CATEGORIES___'+text)
	elif mode==565: zpXG3Ky6ou8ndWHkb4 = hWJg9P6lEYT5aGDizcb(url,'FILTERS___'+text)
	elif mode==566: zpXG3Ky6ou8ndWHkb4 = i7pbAuodvX3(url)
	elif mode==569: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text,url)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع',NBm2aWhPzoTpdYn,569,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فلتر محدد',NBm2aWhPzoTpdYn+'/AjaxCenter/RightBar',564)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فلتر كامل',NBm2aWhPzoTpdYn+'/AjaxCenter/RightBar',565)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',NBm2aWhPzoTpdYn,'','','','','WECIMA-MENU-2nd')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="NavigationMenu"(.*?)class="ProductionsListButton"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('class="menu-item.*?href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			if title=='': continue
			if any(hieW1zRUG5w9AykJjv0X in title.lower() for hieW1zRUG5w9AykJjv0X in DDXTwbRBaj3e2rSsPQ): continue
			cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,566)
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('hoverable activable(.*?)hoverable activable',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?url\((.*?)\).*?span>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
			cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,566,VFqpJjRySZvgi)
	return BBlXpmUyhFDwNtCVAHoE
def i7pbAuodvX3(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',url,'','','','','WECIMA-SUBMENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	if 'class="Slider--Grid"' in BBlXpmUyhFDwNtCVAHoE:
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'المميزة',url,561,'','','featured')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="list--Tabsui"(.*?)div',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?i>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,561)
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(Zi5AuP7kLVfqF6pIXn,type=''):
	if '::' in Zi5AuP7kLVfqF6pIXn:
		XwyU6PQgprMI0,url = Zi5AuP7kLVfqF6pIXn.split('::')
		C83UXWf15zdwLA0 = RfKuIXwPAiWtmyF(XwyU6PQgprMI0,'url')
		url = C83UXWf15zdwLA0+url
	else: url,XwyU6PQgprMI0 = Zi5AuP7kLVfqF6pIXn,Zi5AuP7kLVfqF6pIXn
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','WECIMA-TITLES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	if type=='featured':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="Slider--Grid"(.*?)class="list--Tabsui"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	elif type in ['filters','search']:
		EeQqAGc0W5r6nlBbChwfZL = [BBlXpmUyhFDwNtCVAHoE.replace('\\/','/').replace('\\"','"')]
	else:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"Grid--WecimaPosts"(.*?)"RightUI"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	IcJOGsq3Ff7EmkiLx = []
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('"Thumb--GridItem".*?href="(.*?)" title="(.*?)".*?url\((.*?)\)',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title,VFqpJjRySZvgi in items:
			if any(hieW1zRUG5w9AykJjv0X in title.lower() for hieW1zRUG5w9AykJjv0X in DDXTwbRBaj3e2rSsPQ): continue
			VFqpJjRySZvgi = ptMqV54oKJhQ8CH(VFqpJjRySZvgi)
			ELbNB92cOh5dqtpVmi40kY = ptMqV54oKJhQ8CH(ELbNB92cOh5dqtpVmi40kY)
			title = DwNC3gEonizsB6a0v1F(title)
			title = ptMqV54oKJhQ8CH(title)
			title = title.replace('مشاهدة ','')
			if '/series/' in ELbNB92cOh5dqtpVmi40kY: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,563,VFqpJjRySZvgi)
			elif 'حلقة' in title:
				qUGxSK2VwsiBAdkDZnJ605vQeg = GGvHJKP9LUxEk10Fw.findall('(.*?) +حلقة +\d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
				if qUGxSK2VwsiBAdkDZnJ605vQeg: title = '_MOD_' + qUGxSK2VwsiBAdkDZnJ605vQeg[0]
				if title not in IcJOGsq3Ff7EmkiLx:
					IcJOGsq3Ff7EmkiLx.append(title)
					cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,563,VFqpJjRySZvgi)
			else:
				cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,562,VFqpJjRySZvgi)
		if type=='filters':
			WgtDJdf7CrpxK41GQAMkyjSF8bu = GGvHJKP9LUxEk10Fw.findall('"more_button_page":(.*?),',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			if WgtDJdf7CrpxK41GQAMkyjSF8bu:
				count = WgtDJdf7CrpxK41GQAMkyjSF8bu[0]
				ELbNB92cOh5dqtpVmi40kY = url+'/offset/'+count
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة أخرى',ELbNB92cOh5dqtpVmi40kY,561,'','','filters')
		elif type=='':
			EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="pagination(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
			if EeQqAGc0W5r6nlBbChwfZL:
				UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
				items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
				for ELbNB92cOh5dqtpVmi40kY,title in items:
					if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
					title = 'صفحة '+DwNC3gEonizsB6a0v1F(title)
					cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,561)
	return
def hWPvGlXZ5arzV7(url,type=''):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','WECIMA-EPISODES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	BBlXpmUyhFDwNtCVAHoE = GhPlajzTxY8(BBlXpmUyhFDwNtCVAHoE)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="Seasons--Episodes"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not type and EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if len(items)>1:
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,563,'','','episodes')
			return
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="Episodes--Seasons--Episodes(.*?)</singlesections>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?<episodeTitle>(.*?)</episodeTitle>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.IGNORECASE)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			title = title.strip(' ')
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,562)
	if not D6DrJsclfY:
		title = GGvHJKP9LUxEk10Fw.findall('<title>(.*?)<',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if title: title = title[0].replace(' - ماي سيما','').replace('مشاهدة ','')
		else: title = 'ملف التشغيل'
		cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,562)
	return
def SUfe4unWoXBNFz90xqy(url):
	zzvBg3ShiamAZ = []
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'GET',url,'','','','','WECIMA-PLAY-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	NbE4qnzmPKGWtjYpoRL3HTS1A = GGvHJKP9LUxEk10Fw.findall('<span>التصنيف<.*?<a.*?">(.*?)<.*?">(.*?)<',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if NbE4qnzmPKGWtjYpoRL3HTS1A:
		NbE4qnzmPKGWtjYpoRL3HTS1A = [NbE4qnzmPKGWtjYpoRL3HTS1A[0][0],NbE4qnzmPKGWtjYpoRL3HTS1A[0][1]]
		if NbE4qnzmPKGWtjYpoRL3HTS1A and hNCJPTucIV7GOSR0HytZ6eQrqEUpw(cTJphS1nFz5EUgNWm86C,url,NbE4qnzmPKGWtjYpoRL3HTS1A): return
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="WatchServersList"(.*?)class="WatchServersEmbed"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('data-url="(.*?)".*?strong>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,name in items:
			if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
			if name=='سيرفر وي سيما': name = 'wecima'
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named='+name+'__watch'
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.replace('\n','').replace('\r','')
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="List--Download(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?</i>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,dDZQSEGRTo9g85x1C in items:
			if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
			dDZQSEGRTo9g85x1C = GGvHJKP9LUxEk10Fw.findall('\d\d\d+',dDZQSEGRTo9g85x1C,GGvHJKP9LUxEk10Fw.DOTALL)
			if dDZQSEGRTo9g85x1C: dDZQSEGRTo9g85x1C = '____'+dDZQSEGRTo9g85x1C[0]
			else: dDZQSEGRTo9g85x1C = ''
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named=wecima'+'__download'+dDZQSEGRTo9g85x1C
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.replace('\n','').replace('\r','')
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(zzvBg3ShiamAZ,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search,gYaBcv86kLS=''):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	search = search.replace(' ','+')
	if not gYaBcv86kLS:
		gYaBcv86kLS = NBm2aWhPzoTpdYn
	dR2vHyAtl8pJN1 = gYaBcv86kLS+'/AjaxCenter/Searching/'+search+'/'
	xoiXMWjJC3pnQqurIGPkRSl8e(dR2vHyAtl8pJN1,'search')
	return
def hWJg9P6lEYT5aGDizcb(Zi5AuP7kLVfqF6pIXn,filter):
	if '??' in Zi5AuP7kLVfqF6pIXn: url = Zi5AuP7kLVfqF6pIXn.split('//getposts??')[0]
	else: url = Zi5AuP7kLVfqF6pIXn
	filter = filter.replace('_FORGETRESULTS_','')
	type,filter = filter.split('___',1)
	if filter=='': zTi1IvPRBr,CcMQl4P9H8SkouF7srzBYdDKUNA = '',''
	else: zTi1IvPRBr,CcMQl4P9H8SkouF7srzBYdDKUNA = filter.split('___')
	if type=='CATEGORIES':
		if RFlSKD5EAaCb[0]+'==' not in zTi1IvPRBr: BBskpK6cGZJ = RFlSKD5EAaCb[0]
		for umP72LtwzUTWHFAlJVyheEp5 in range(len(RFlSKD5EAaCb[0:-1])):
			if RFlSKD5EAaCb[umP72LtwzUTWHFAlJVyheEp5]+'==' in zTi1IvPRBr: BBskpK6cGZJ = RFlSKD5EAaCb[umP72LtwzUTWHFAlJVyheEp5+1]
		i2i6oT5O34GLAgyPs8DdIfV = zTi1IvPRBr+'&&'+BBskpK6cGZJ+'==0'
		WtVSCYeOJDGQf5sq8KZxkzyXwvBF = CcMQl4P9H8SkouF7srzBYdDKUNA+'&&'+BBskpK6cGZJ+'==0'
		sDnjCtlaGyxmr9fqK = i2i6oT5O34GLAgyPs8DdIfV.strip('&&')+'___'+WtVSCYeOJDGQf5sq8KZxkzyXwvBF.strip('&&')
		BnNGcaxDl0pPVdmq3j1kQu6HJEs4 = fx0tQnZhGieDkA(CcMQl4P9H8SkouF7srzBYdDKUNA,'modified_filters')
		dR2vHyAtl8pJN1 = url+'//getposts??'+BnNGcaxDl0pPVdmq3j1kQu6HJEs4
	elif type=='FILTERS':
		QHWZwB3stnOp5SghLfl2zir6YCI = fx0tQnZhGieDkA(zTi1IvPRBr,'modified_values')
		QHWZwB3stnOp5SghLfl2zir6YCI = GhPlajzTxY8(QHWZwB3stnOp5SghLfl2zir6YCI)
		if CcMQl4P9H8SkouF7srzBYdDKUNA!='': CcMQl4P9H8SkouF7srzBYdDKUNA = fx0tQnZhGieDkA(CcMQl4P9H8SkouF7srzBYdDKUNA,'modified_filters')
		if CcMQl4P9H8SkouF7srzBYdDKUNA=='': dR2vHyAtl8pJN1 = url
		else: dR2vHyAtl8pJN1 = url+'//getposts??'+CcMQl4P9H8SkouF7srzBYdDKUNA
		gmFNXM58sV6qH = kzawTQoulG7PJW8jt3CEnpx(dR2vHyAtl8pJN1,Zi5AuP7kLVfqF6pIXn)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'أظهار قائمة الفيديو التي تم اختيارها ',gmFNXM58sV6qH,561,'','','filters')
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+' [[   '+QHWZwB3stnOp5SghLfl2zir6YCI+'   ]]',gmFNXM58sV6qH,561,'','','filters')
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',url,'','','','','WECIMA-FILTERS_MENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	BBlXpmUyhFDwNtCVAHoE = BBlXpmUyhFDwNtCVAHoE.replace('\\"','"').replace('\\/','/')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('<wecima--filter(.*?)</wecima--filter>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not EeQqAGc0W5r6nlBbChwfZL: return
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	nQKyI93hUT2ZGl6zimxDWe04ckj = GGvHJKP9LUxEk10Fw.findall('taxonomy="(.*?)".*?<span>(.*?)<(.*?)<filterbox',UCEFMfKbgpd+'<filterbox',GGvHJKP9LUxEk10Fw.DOTALL)
	dict = {}
	for mmRDx1Zhfjq4oFdsNey2EwCBlUOQv,name,UCEFMfKbgpd in nQKyI93hUT2ZGl6zimxDWe04ckj:
		name = ptMqV54oKJhQ8CH(name)
		if 'interest' in mmRDx1Zhfjq4oFdsNey2EwCBlUOQv: continue
		items = GGvHJKP9LUxEk10Fw.findall('data-term="(.*?)".*?<txt>(.*?)</txt>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if '==' not in dR2vHyAtl8pJN1: dR2vHyAtl8pJN1 = url
		if type=='CATEGORIES':
			if BBskpK6cGZJ!=mmRDx1Zhfjq4oFdsNey2EwCBlUOQv: continue
			elif len(items)<=1:
				if mmRDx1Zhfjq4oFdsNey2EwCBlUOQv==RFlSKD5EAaCb[-1]: xoiXMWjJC3pnQqurIGPkRSl8e(dR2vHyAtl8pJN1)
				else: hWJg9P6lEYT5aGDizcb(dR2vHyAtl8pJN1,'CATEGORIES___'+sDnjCtlaGyxmr9fqK)
				return
			else:
				gmFNXM58sV6qH = kzawTQoulG7PJW8jt3CEnpx(dR2vHyAtl8pJN1,Zi5AuP7kLVfqF6pIXn)
				if mmRDx1Zhfjq4oFdsNey2EwCBlUOQv==RFlSKD5EAaCb[-1]:
					cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع',gmFNXM58sV6qH,561,'','','filters')
				else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع',dR2vHyAtl8pJN1,564,'','',sDnjCtlaGyxmr9fqK)
		elif type=='FILTERS':
			i2i6oT5O34GLAgyPs8DdIfV = zTi1IvPRBr+'&&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'==0'
			WtVSCYeOJDGQf5sq8KZxkzyXwvBF = CcMQl4P9H8SkouF7srzBYdDKUNA+'&&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'==0'
			sDnjCtlaGyxmr9fqK = i2i6oT5O34GLAgyPs8DdIfV+'___'+WtVSCYeOJDGQf5sq8KZxkzyXwvBF
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+name+': الجميع',dR2vHyAtl8pJN1,565,'','',sDnjCtlaGyxmr9fqK+'_FORGETRESULTS_')
		dict[mmRDx1Zhfjq4oFdsNey2EwCBlUOQv] = {}
		for hieW1zRUG5w9AykJjv0X,RHb9zAjcuTIoyZ0aDgS1pQYmUs8 in items:
			name = ptMqV54oKJhQ8CH(name)
			RHb9zAjcuTIoyZ0aDgS1pQYmUs8 = ptMqV54oKJhQ8CH(RHb9zAjcuTIoyZ0aDgS1pQYmUs8)
			if hieW1zRUG5w9AykJjv0X=='r' or hieW1zRUG5w9AykJjv0X=='nc-17': continue
			if any(hieW1zRUG5w9AykJjv0X in RHb9zAjcuTIoyZ0aDgS1pQYmUs8.lower() for hieW1zRUG5w9AykJjv0X in DDXTwbRBaj3e2rSsPQ): continue
			if 'http' in RHb9zAjcuTIoyZ0aDgS1pQYmUs8: continue
			if 'الكل' in RHb9zAjcuTIoyZ0aDgS1pQYmUs8: continue
			if 'n-a' in hieW1zRUG5w9AykJjv0X: continue
			if RHb9zAjcuTIoyZ0aDgS1pQYmUs8=='': RHb9zAjcuTIoyZ0aDgS1pQYmUs8 = hieW1zRUG5w9AykJjv0X
			now0UFQXvPyWA8TNluJ53M = RHb9zAjcuTIoyZ0aDgS1pQYmUs8
			yCcvQk8BMijebJlaHfhgKux = GGvHJKP9LUxEk10Fw.findall('<name>(.*?)</name>',RHb9zAjcuTIoyZ0aDgS1pQYmUs8,GGvHJKP9LUxEk10Fw.DOTALL)
			if yCcvQk8BMijebJlaHfhgKux: now0UFQXvPyWA8TNluJ53M = yCcvQk8BMijebJlaHfhgKux[0]
			qPmCp1Q4gRekdAH = name+': '+now0UFQXvPyWA8TNluJ53M
			dict[mmRDx1Zhfjq4oFdsNey2EwCBlUOQv][hieW1zRUG5w9AykJjv0X] = qPmCp1Q4gRekdAH
			i2i6oT5O34GLAgyPs8DdIfV = zTi1IvPRBr+'&&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'=='+now0UFQXvPyWA8TNluJ53M
			WtVSCYeOJDGQf5sq8KZxkzyXwvBF = CcMQl4P9H8SkouF7srzBYdDKUNA+'&&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'=='+hieW1zRUG5w9AykJjv0X
			KPcDQTE3e8duMHO6Lbgo1n = i2i6oT5O34GLAgyPs8DdIfV+'___'+WtVSCYeOJDGQf5sq8KZxkzyXwvBF
			if type=='FILTERS':
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+qPmCp1Q4gRekdAH,url,565,'','',KPcDQTE3e8duMHO6Lbgo1n+'_FORGETRESULTS_')
			elif type=='CATEGORIES' and RFlSKD5EAaCb[-2]+'==' in zTi1IvPRBr:
				BnNGcaxDl0pPVdmq3j1kQu6HJEs4 = fx0tQnZhGieDkA(WtVSCYeOJDGQf5sq8KZxkzyXwvBF,'modified_filters')
				XwyU6PQgprMI0 = url+'//getposts??'+BnNGcaxDl0pPVdmq3j1kQu6HJEs4
				gmFNXM58sV6qH = kzawTQoulG7PJW8jt3CEnpx(XwyU6PQgprMI0,Zi5AuP7kLVfqF6pIXn)
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+qPmCp1Q4gRekdAH,gmFNXM58sV6qH,561,'','','filters')
			else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+qPmCp1Q4gRekdAH,url,564,'','',KPcDQTE3e8duMHO6Lbgo1n)
	return
RFlSKD5EAaCb = ['genre','release-year','nation']
FLB7zJRpxn8g26ehaD4udskE9tc = ['mpaa','genre','release-year','category','Quality','interest','nation','language']
def kzawTQoulG7PJW8jt3CEnpx(dR2vHyAtl8pJN1,XwyU6PQgprMI0):
	if '/AjaxCenter/RightBar' in dR2vHyAtl8pJN1: dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1.replace('/AjaxCenter/RightBar','/AjaxCenter/Filtering')
	dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1.replace('//getposts??','::/AjaxCenter/Filtering/')
	dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1.replace('==','/')
	dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1.replace('&&','/')
	return dR2vHyAtl8pJN1
def fx0tQnZhGieDkA(FZj067Q2PlC8EsG9c5yiWpzNRq,mode):
	FZj067Q2PlC8EsG9c5yiWpzNRq = FZj067Q2PlC8EsG9c5yiWpzNRq.strip('&&')
	HG4gSjopqQwsPeivrcmn,BbgO8pxWfVA41KGzed = {},''
	if '==' in FZj067Q2PlC8EsG9c5yiWpzNRq:
		items = FZj067Q2PlC8EsG9c5yiWpzNRq.split('&&')
		for BrVNsC72UYWES4A in items:
			RRSq2Qx0MfkFHLt,hieW1zRUG5w9AykJjv0X = BrVNsC72UYWES4A.split('==')
			HG4gSjopqQwsPeivrcmn[RRSq2Qx0MfkFHLt] = hieW1zRUG5w9AykJjv0X
	for key in FLB7zJRpxn8g26ehaD4udskE9tc:
		if key in list(HG4gSjopqQwsPeivrcmn.keys()): hieW1zRUG5w9AykJjv0X = HG4gSjopqQwsPeivrcmn[key]
		else: hieW1zRUG5w9AykJjv0X = '0'
		if '%' not in hieW1zRUG5w9AykJjv0X: hieW1zRUG5w9AykJjv0X = mGfdCk4Hyclg9RjD(hieW1zRUG5w9AykJjv0X)
		if mode=='modified_values' and hieW1zRUG5w9AykJjv0X!='0': BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed+' + '+hieW1zRUG5w9AykJjv0X
		elif mode=='modified_filters' and hieW1zRUG5w9AykJjv0X!='0': BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed+'&&'+key+'=='+hieW1zRUG5w9AykJjv0X
		elif mode=='all': BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed+'&&'+key+'=='+hieW1zRUG5w9AykJjv0X
	BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed.strip(' + ')
	BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed.strip('&&')
	return BbgO8pxWfVA41KGzed
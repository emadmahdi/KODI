# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'DAILYMOTION'
mmDwMlfoHtG5XT19VLIWqCR8i = '_DLM_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
msL09WzMG3c86RAqkXpY7yn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][1]
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text,type,EfNzW3kLhcMTu07HrP28X9nFA6vpGd):
	if	 mode==400: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==401: zpXG3Ky6ou8ndWHkb4 = QU4b0yFrmeXkBWs7(url,text)
	elif mode==402: zpXG3Ky6ou8ndWHkb4 = pcYkO35N7xI09RME2hmiyStgaLvBrX(url,text)
	elif mode==403: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url,text)
	elif mode==404: zpXG3Ky6ou8ndWHkb4 = ryYAOUhg6p875Rw0fG(text,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif mode==405: zpXG3Ky6ou8ndWHkb4 = BBb2ueJ9amqoVHL(text,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif mode==406: zpXG3Ky6ou8ndWHkb4 = OugBEMPU0Hjt(text,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif mode==407: zpXG3Ky6ou8ndWHkb4 = xnZskv1BN5zymYLXiWIwTre2(url,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif mode==408: zpXG3Ky6ou8ndWHkb4 = IhRJl54HM7aSQBPWCYA81tu2Z(url,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif mode==409: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif mode==411: zpXG3Ky6ou8ndWHkb4 = dZ3ODNqCATsxGEe1n0oQ9(url,text)
	elif mode==412: zpXG3Ky6ou8ndWHkb4 = KI4NyW73o2uQRmgjkTCZBrlf(text,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif mode==413: zpXG3Ky6ou8ndWHkb4 = Bgr82pEh3Tin5Ry(url,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif mode==414: zpXG3Ky6ou8ndWHkb4 = kqeH3gcPv4YCx9QwUSR5ONut2Flfp(text)
	elif mode==415: zpXG3Ky6ou8ndWHkb4 = NFxCXUkyGJfiju5cn04T7Qp9vt2H(text,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الرئيسية','',414)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',409,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث عن فيديوهات','',409,'','videos?sortBy=','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث عن آخر الفيديوهات','',409,'','videos?sortBy=RECENT','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث عن الفيديوهات الأكثر مشاهدة','',409,'','videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث عن قوائم التشغيل','',409,'','playlists','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث عن قنوات','',409,'','channels','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث عن مواضيع','',409,'','topics','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث عن بث حي','',409,'','lives','_REMEMBERRESULTS_')
	return
def pcYkO35N7xI09RME2hmiyStgaLvBrX(url,ms2eq39LGR5ZluDtoVQ):
	if '/dm_' in url:
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'GET',url,'','',False,'','DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = WbTGMHnDysdYZ2lFA.headers
		if 'Location' in list(headers.keys()): url = NBm2aWhPzoTpdYn+headers['Location']
	ms2eq39LGR5ZluDtoVQ = '[COLOR FFC89008]'+ms2eq39LGR5ZluDtoVQ+'[/COLOR]'
	ms2eq39LGR5ZluDtoVQ = Pi3u6H9QAm0x4yDMGBr(ms2eq39LGR5ZluDtoVQ)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+':: بث حي',url,411,'','','channel_lives_now')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+':: آخر الفيديوهات',url+'/videos',408)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+':: المميزة',url,411,'','','channel_featured_videos')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+':: قوائم التشغيل',url+'/playlists',407)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+':: قنوات ذات صلة',url,411,'','','channel_related_channel')
	return
def Pi3u6H9QAm0x4yDMGBr(title):
	title = title.rstrip('\\').strip(' ').replace('\\\\','\\')
	title = ptMqV54oKJhQ8CH(title)
	return title
def SUfe4unWoXBNFz90xqy(url,X5byeYgp1hrD0jGKf7wNUT2ZmquI):
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E([url],cTJphS1nFz5EUgNWm86C,'video',url)
	return
def ryYAOUhg6p875Rw0fG(search,EfNzW3kLhcMTu07HrP28X9nFA6vpGd=''):
	if EfNzW3kLhcMTu07HrP28X9nFA6vpGd=='': EfNzW3kLhcMTu07HrP28X9nFA6vpGd = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = ''
	search = search.split('/videos')[0]
	hD6se2E307NcI = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	hD6se2E307NcI = hD6se2E307NcI.replace('mysearchwords',search)
	hD6se2E307NcI = hD6se2E307NcI.replace('mypagelimit','40')
	hD6se2E307NcI = hD6se2E307NcI.replace('mypagenumber',EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	if sort=='': hD6se2E307NcI = hD6se2E307NcI.replace('mysortmethod','')
	else: hD6se2E307NcI = hD6se2E307NcI.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = NBm2aWhPzoTpdYn+'/search/'+search+'/videos'
	BBlXpmUyhFDwNtCVAHoE = fyoi4XahAvEQH3qjS5(hD6se2E307NcI)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"videos"(.*?)"VideoConnection"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('"node".*?"xid":"(.*?)","title":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for id,title,V4RNmuKT5dEebS,ms2eq39LGR5ZluDtoVQ,EDL3rwcivsR9W0pdTfygmOYUoVSb,VFqpJjRySZvgi in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in VFqpJjRySZvgi: VFqpJjRySZvgi = VFqpJjRySZvgi.replace('"','')
			if '"' in EDL3rwcivsR9W0pdTfygmOYUoVSb: EDL3rwcivsR9W0pdTfygmOYUoVSb = EDL3rwcivsR9W0pdTfygmOYUoVSb.replace('"','')
			if '"' in V4RNmuKT5dEebS: V4RNmuKT5dEebS = V4RNmuKT5dEebS.replace('"','')
			if '"' in ms2eq39LGR5ZluDtoVQ: ms2eq39LGR5ZluDtoVQ = ms2eq39LGR5ZluDtoVQ.replace('"','')
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/video/'+id
			title = Pi3u6H9QAm0x4yDMGBr(title)
			X5byeYgp1hrD0jGKf7wNUT2ZmquI = V4RNmuKT5dEebS+'::'+ms2eq39LGR5ZluDtoVQ
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,403,VFqpJjRySZvgi,EDL3rwcivsR9W0pdTfygmOYUoVSb,X5byeYgp1hrD0jGKf7wNUT2ZmquI)
		if '"hasNextPage":true' in BBlXpmUyhFDwNtCVAHoE:
			EfNzW3kLhcMTu07HrP28X9nFA6vpGd = str(int(EfNzW3kLhcMTu07HrP28X9nFA6vpGd)+1)
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+EfNzW3kLhcMTu07HrP28X9nFA6vpGd,url,404,'',EfNzW3kLhcMTu07HrP28X9nFA6vpGd,search)
	return
def BBb2ueJ9amqoVHL(search,EfNzW3kLhcMTu07HrP28X9nFA6vpGd=''):
	if EfNzW3kLhcMTu07HrP28X9nFA6vpGd=='': EfNzW3kLhcMTu07HrP28X9nFA6vpGd = '1'
	hD6se2E307NcI = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	hD6se2E307NcI = hD6se2E307NcI.replace('mysearchwords',search)
	hD6se2E307NcI = hD6se2E307NcI.replace('mypagelimit','40')
	hD6se2E307NcI = hD6se2E307NcI.replace('mypagenumber',EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	url = NBm2aWhPzoTpdYn+'/search/'+search+'/playlists'
	BBlXpmUyhFDwNtCVAHoE = fyoi4XahAvEQH3qjS5(hD6se2E307NcI)
	items = GGvHJKP9LUxEk10Fw.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)".*?"total":(.*?),',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	for id,name,Ksh08Er2x3dfaNH4l5MjXJu,V4RNmuKT5dEebS,ms2eq39LGR5ZluDtoVQ,VFqpJjRySZvgi,count in items:
		if '"' in Ksh08Er2x3dfaNH4l5MjXJu: Ksh08Er2x3dfaNH4l5MjXJu = Ksh08Er2x3dfaNH4l5MjXJu.replace('"','')
		if '"' in V4RNmuKT5dEebS: V4RNmuKT5dEebS = V4RNmuKT5dEebS.replace('"','')
		if '"' in ms2eq39LGR5ZluDtoVQ: ms2eq39LGR5ZluDtoVQ = ms2eq39LGR5ZluDtoVQ.replace('"','')
		if '"' in id: id = id.replace('"','')
		if '"' in name: name = name.replace('"','')
		if '"' in VFqpJjRySZvgi: VFqpJjRySZvgi = VFqpJjRySZvgi.replace('"','')
		if '"' in count: count = count.replace('"','')
		ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = Pi3u6H9QAm0x4yDMGBr(title)
		X5byeYgp1hrD0jGKf7wNUT2ZmquI = V4RNmuKT5dEebS+'::'+ms2eq39LGR5ZluDtoVQ
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,401,VFqpJjRySZvgi,'',X5byeYgp1hrD0jGKf7wNUT2ZmquI)
	if '"hasNextPage":true' in BBlXpmUyhFDwNtCVAHoE:
		EfNzW3kLhcMTu07HrP28X9nFA6vpGd = str(int(EfNzW3kLhcMTu07HrP28X9nFA6vpGd)+1)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+EfNzW3kLhcMTu07HrP28X9nFA6vpGd,url,405,'',EfNzW3kLhcMTu07HrP28X9nFA6vpGd,search)
	return
def OugBEMPU0Hjt(search,EfNzW3kLhcMTu07HrP28X9nFA6vpGd=''):
	if EfNzW3kLhcMTu07HrP28X9nFA6vpGd=='': EfNzW3kLhcMTu07HrP28X9nFA6vpGd = '1'
	hD6se2E307NcI = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	hD6se2E307NcI = hD6se2E307NcI.replace('mysearchwords',search)
	hD6se2E307NcI = hD6se2E307NcI.replace('mypagelimit','40')
	hD6se2E307NcI = hD6se2E307NcI.replace('mypagenumber',EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	url = NBm2aWhPzoTpdYn+'/search/'+search+'/channels'
	BBlXpmUyhFDwNtCVAHoE = fyoi4XahAvEQH3qjS5(hD6se2E307NcI)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"channels"(.*?)"ChannelConnection"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('"node".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for id,name,VFqpJjRySZvgi in items:
			if '"' in id: id = id.replace('"','')
			if '"' in name: name = name.replace('"','')
			if '"' in VFqpJjRySZvgi: VFqpJjRySZvgi = VFqpJjRySZvgi.replace('"','')
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/'+id
			title = 'CHNL:  '+name
			title = Pi3u6H9QAm0x4yDMGBr(title)
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,402,VFqpJjRySZvgi,'',name)
		if '"hasNextPage":true' in BBlXpmUyhFDwNtCVAHoE:
			EfNzW3kLhcMTu07HrP28X9nFA6vpGd = str(int(EfNzW3kLhcMTu07HrP28X9nFA6vpGd)+1)
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+EfNzW3kLhcMTu07HrP28X9nFA6vpGd,url,406,'',EfNzW3kLhcMTu07HrP28X9nFA6vpGd,search)
	return
def kqeH3gcPv4YCx9QwUSR5ONut2Flfp(oZGOJsNn7qkQUiY):
	hD6se2E307NcI = '{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  thumbnail: coverURL(size: \"x532\")\n  coverURL: coverURL(size: \"x532\")\n  isFollowed\n  whitelistStatus {\n    id\n    isWhitelisted\n    __typename\n  }\n  __typename\n}\n\nquery HOME_QUERY($space: String!) {\n  home: views {\n    id\n    neon {\n      id\n      sections(space: $space) {\n        edges {\n          node {\n            id\n            name\n            title\n            description\n            groupingType\n            type\n            relatedComponent {\n              __typename\n              ... on Collection {\n                id\n                xid\n                __typename\n              }\n              ... on Channel {\n                id\n                xid\n                name\n                displayName\n                logoURL(size: \"x60\")\n                __typename\n              }\n              ... on Topic {\n                id\n                __typename\n                ...TOPIC_BASE_FRAG\n              }\n            }\n            components {\n              edges {\n                node {\n                  __typename\n                  ... on Video {\n                    id\n                    xid\n                    title\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx360: thumbnailURL(size: \"x360\")\n                    thumbnailx480: thumbnailURL(size: \"x480\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    aspectRatio\n                    createdAt\n                    channel {\n                      id\n                      xid\n                      name\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      accountType\n                      __typename\n                    }\n                    description\n                    duration\n                    __typename\n                  }\n                  ... on Live {\n                    id\n                    xid\n                    title\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx360: thumbnailURL(size: \"x360\")\n                    thumbnailx480: thumbnailURL(size: \"x480\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    aspectRatio\n                    createdAt\n                    channel {\n                      id\n                      xid\n                      name\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      accountType\n                      __typename\n                    }\n                    startAt\n                    __typename\n                  }\n                }\n                __typename\n              }\n              __typename\n            }\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	JWPYA5r2liu0zQTHwhXfDay4 = fyoi4XahAvEQH3qjS5(hD6se2E307NcI)
	if JWPYA5r2liu0zQTHwhXfDay4:
		tc42qhBTbEVujiopfDgwA = JKw5OWktPZB('dict',JWPYA5r2liu0zQTHwhXfDay4)
		BLCKGeofZ5TqQyb0gS2lcaVhxOAj = tc42qhBTbEVujiopfDgwA['data']['home']['neon']['sections']['edges']
		if not oZGOJsNn7qkQUiY:
			rmMU12AjQzSpfEXRvceV = []
			for OEke2ltQC6LRhvpT93sn7yrijbWN in BLCKGeofZ5TqQyb0gS2lcaVhxOAj:
				Sfug7s90teZTcO = OEke2ltQC6LRhvpT93sn7yrijbWN['node']['title']
				if Sfug7s90teZTcO not in rmMU12AjQzSpfEXRvceV: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+Sfug7s90teZTcO,'',414,'','',Sfug7s90teZTcO)
				rmMU12AjQzSpfEXRvceV.append(Sfug7s90teZTcO)
		else:
			for OEke2ltQC6LRhvpT93sn7yrijbWN in BLCKGeofZ5TqQyb0gS2lcaVhxOAj:
				Sfug7s90teZTcO = OEke2ltQC6LRhvpT93sn7yrijbWN['node']['title']
				if Sfug7s90teZTcO==oZGOJsNn7qkQUiY:
					AD2LzyvukJqb4Ze = OEke2ltQC6LRhvpT93sn7yrijbWN['node']['components']['edges']
					for zDSWVKHn8o7xN in AD2LzyvukJqb4Ze:
						EDL3rwcivsR9W0pdTfygmOYUoVSb = str(zDSWVKHn8o7xN['node']['duration'])
						title = ptMqV54oKJhQ8CH(zDSWVKHn8o7xN['node']['title'])
						title = title.replace('\/','/')
						Vr04uqBf35KGSnE = zDSWVKHn8o7xN['node']['xid']
						VFqpJjRySZvgi = zDSWVKHn8o7xN['node']['thumbnailx480']
						VFqpJjRySZvgi = VFqpJjRySZvgi.replace('\/','/')
						ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/video/'+Vr04uqBf35KGSnE
						cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,403,VFqpJjRySZvgi,EDL3rwcivsR9W0pdTfygmOYUoVSb)
	return
def NFxCXUkyGJfiju5cn04T7Qp9vt2H(search,EfNzW3kLhcMTu07HrP28X9nFA6vpGd=''):
	if EfNzW3kLhcMTu07HrP28X9nFA6vpGd=='': EfNzW3kLhcMTu07HrP28X9nFA6vpGd = '1'
	hD6se2E307NcI = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  aspectRatio\n  __typename\n}\n\nfragment VIDEO_FAVORITES_FRAGMENT on Media {\n  __typename\n  ... on Video {\n    id\n    viewerEngagement {\n      id\n      favorited\n      __typename\n    }\n    __typename\n  }\n  ... on Live {\n    id\n    viewerEngagement {\n      id\n      favorited\n      __typename\n    }\n    __typename\n  }\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  videos(sort: \"recent\", first: 5) {\n    pageInfo {\n      hasNextPage\n      nextPage\n      __typename\n    }\n    edges {\n      node {\n        id\n        ...VIDEO_BASE_FRAGMENT\n        ...VIDEO_FAVORITES_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(\n      query: $query\n      first: $limit\n      page: $page\n      sort: $sortByVideos\n      durationMin: $durationMinVideos\n      durationMax: $durationMaxVideos\n      createdAfter: $createdAfterVideos\n    ) @include(if: $shouldIncludeVideos) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_FAVORITES_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          xid\n          title\n          thumbnail: thumbnailURL(size: \"x240\")\n          thumbnailx60: thumbnailURL(size: \"x60\")\n          thumbnailx120: thumbnailURL(size: \"x120\")\n          thumbnailx240: thumbnailURL(size: \"x240\")\n          thumbnailx720: thumbnailURL(size: \"x720\")\n          audienceCount\n          aspectRatio\n          isOnAir\n          channel {\n            id\n            xid\n            name\n            displayName\n            accountType\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...TOPIC_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	hD6se2E307NcI = hD6se2E307NcI.replace('mysearchwords',search)
	hD6se2E307NcI = hD6se2E307NcI.replace('mypagelimit','40')
	hD6se2E307NcI = hD6se2E307NcI.replace('mypagenumber',EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	url = NBm2aWhPzoTpdYn+'/search/'+search+'/lives'
	JWPYA5r2liu0zQTHwhXfDay4 = fyoi4XahAvEQH3qjS5(hD6se2E307NcI)
	if JWPYA5r2liu0zQTHwhXfDay4:
		tc42qhBTbEVujiopfDgwA = JKw5OWktPZB('dict',JWPYA5r2liu0zQTHwhXfDay4)
		try: BLCKGeofZ5TqQyb0gS2lcaVhxOAj = tc42qhBTbEVujiopfDgwA['data']['search']['lives']['edges']
		except: BLCKGeofZ5TqQyb0gS2lcaVhxOAj = []
		for OEke2ltQC6LRhvpT93sn7yrijbWN in BLCKGeofZ5TqQyb0gS2lcaVhxOAj:
			name = OEke2ltQC6LRhvpT93sn7yrijbWN['node']['title']
			Vr04uqBf35KGSnE = OEke2ltQC6LRhvpT93sn7yrijbWN['node']['xid']
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/video/'+Vr04uqBf35KGSnE
			cd0aGwCPExbFU5pYNu8r('live',mmDwMlfoHtG5XT19VLIWqCR8i+'LIVE: '+name,ELbNB92cOh5dqtpVmi40kY,403)
		if '"hasNextPage":true' in JWPYA5r2liu0zQTHwhXfDay4:
			EfNzW3kLhcMTu07HrP28X9nFA6vpGd = str(int(EfNzW3kLhcMTu07HrP28X9nFA6vpGd)+1)
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+EfNzW3kLhcMTu07HrP28X9nFA6vpGd,url,415,'',EfNzW3kLhcMTu07HrP28X9nFA6vpGd,search)
	return
def KI4NyW73o2uQRmgjkTCZBrlf(search,EfNzW3kLhcMTu07HrP28X9nFA6vpGd=''):
	if EfNzW3kLhcMTu07HrP28X9nFA6vpGd=='': EfNzW3kLhcMTu07HrP28X9nFA6vpGd = '1'
	hD6se2E307NcI = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  aspectRatio\n  __typename\n}\n\nfragment VIDEO_FAVORITES_FRAGMENT on Media {\n  __typename\n  ... on Video {\n    id\n    isInWatchLater\n    __typename\n  }\n  ... on Live {\n    id\n    isInWatchLater\n    __typename\n  }\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  videos(sort: \"recent\", first: 5) {\n    pageInfo {\n      hasNextPage\n      nextPage\n      __typename\n    }\n    edges {\n      node {\n        id\n        ...VIDEO_BASE_FRAGMENT\n        ...VIDEO_FAVORITES_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(\n      query: $query\n      first: $limit\n      page: $page\n      sort: $sortByVideos\n      durationMin: $durationMinVideos\n      durationMax: $durationMaxVideos\n      createdAfter: $createdAfterVideos\n    ) @include(if: $shouldIncludeVideos) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_FAVORITES_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...TOPIC_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	hD6se2E307NcI = hD6se2E307NcI.replace('mysearchwords',search)
	hD6se2E307NcI = hD6se2E307NcI.replace('mypagelimit','40')
	hD6se2E307NcI = hD6se2E307NcI.replace('mypagenumber',EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	url = NBm2aWhPzoTpdYn+'/search/'+search+'/topics'
	JWPYA5r2liu0zQTHwhXfDay4 = fyoi4XahAvEQH3qjS5(hD6se2E307NcI)
	if JWPYA5r2liu0zQTHwhXfDay4:
		tc42qhBTbEVujiopfDgwA = JKw5OWktPZB('dict',JWPYA5r2liu0zQTHwhXfDay4)
		try: BLCKGeofZ5TqQyb0gS2lcaVhxOAj = tc42qhBTbEVujiopfDgwA['data']['search']['topics']['edges']
		except: BLCKGeofZ5TqQyb0gS2lcaVhxOAj = []
		for OEke2ltQC6LRhvpT93sn7yrijbWN in BLCKGeofZ5TqQyb0gS2lcaVhxOAj:
			name = OEke2ltQC6LRhvpT93sn7yrijbWN['node']['name']
			Vr04uqBf35KGSnE = OEke2ltQC6LRhvpT93sn7yrijbWN['node']['xid']
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/topic/'+Vr04uqBf35KGSnE
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'TOPIC: '+name,ELbNB92cOh5dqtpVmi40kY,413)
		if '"hasNextPage":true' in JWPYA5r2liu0zQTHwhXfDay4:
			EfNzW3kLhcMTu07HrP28X9nFA6vpGd = str(int(EfNzW3kLhcMTu07HrP28X9nFA6vpGd)+1)
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+EfNzW3kLhcMTu07HrP28X9nFA6vpGd,url,412,'',EfNzW3kLhcMTu07HrP28X9nFA6vpGd,search)
	return
def Bgr82pEh3Tin5Ry(url,EfNzW3kLhcMTu07HrP28X9nFA6vpGd=''):
	if EfNzW3kLhcMTu07HrP28X9nFA6vpGd=='': EfNzW3kLhcMTu07HrP28X9nFA6vpGd = '1'
	Vr04uqBf35KGSnE = url.split('/')[-1]
	hD6se2E307NcI = '{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  duration\n  isLiked\n  isInWatchLater\n  isCreatedForKids\n  createdAt\n  isExplicit\n  videoHeight: height\n  videoWidth: width\n  category\n  channel {\n    id\n    xid\n    name\n    displayName\n    logoURLx25: logoURL(size: \"x25\")\n    logoURL(size: \"x60\")\n    accountType\n    __typename\n  }\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  language {\n    id\n    codeAlpha2\n    __typename\n  }\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  bestAvailableQuality\n  aspectRatio\n  isPublished\n  __typename\n}\n\nquery DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {\n  topic(xid: $xid) {\n    id\n    xid\n    name\n    videos(sort: \"recent\", first: 30, page: $page) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          ...TOPIC_VIDEO_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	hD6se2E307NcI = hD6se2E307NcI.replace('mytopicid',Vr04uqBf35KGSnE)
	hD6se2E307NcI = hD6se2E307NcI.replace('mypagenumber',EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	JWPYA5r2liu0zQTHwhXfDay4 = fyoi4XahAvEQH3qjS5(hD6se2E307NcI)
	if JWPYA5r2liu0zQTHwhXfDay4:
		tc42qhBTbEVujiopfDgwA = JKw5OWktPZB('dict',JWPYA5r2liu0zQTHwhXfDay4)
		BLCKGeofZ5TqQyb0gS2lcaVhxOAj = tc42qhBTbEVujiopfDgwA['data']['topic']['videos']['edges']
		for OEke2ltQC6LRhvpT93sn7yrijbWN in BLCKGeofZ5TqQyb0gS2lcaVhxOAj:
			EDL3rwcivsR9W0pdTfygmOYUoVSb = str(OEke2ltQC6LRhvpT93sn7yrijbWN['node']['duration'])
			title = ptMqV54oKJhQ8CH(OEke2ltQC6LRhvpT93sn7yrijbWN['node']['title'])
			title = title.replace('\/','/')
			Vr04uqBf35KGSnE = OEke2ltQC6LRhvpT93sn7yrijbWN['node']['xid']
			VFqpJjRySZvgi = OEke2ltQC6LRhvpT93sn7yrijbWN['node']['thumbnailx480']
			VFqpJjRySZvgi = VFqpJjRySZvgi.replace('\/','/')
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/video/'+Vr04uqBf35KGSnE
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,403,VFqpJjRySZvgi,EDL3rwcivsR9W0pdTfygmOYUoVSb)
		if '"hasNextPage":true' in JWPYA5r2liu0zQTHwhXfDay4:
			EfNzW3kLhcMTu07HrP28X9nFA6vpGd = str(int(EfNzW3kLhcMTu07HrP28X9nFA6vpGd)+1)
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+EfNzW3kLhcMTu07HrP28X9nFA6vpGd,url,413,'',EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	return
def QU4b0yFrmeXkBWs7(url,X5byeYgp1hrD0jGKf7wNUT2ZmquI):
	id = url.split('/')[-1]
	V4RNmuKT5dEebS,ms2eq39LGR5ZluDtoVQ = X5byeYgp1hrD0jGKf7wNUT2ZmquI.split('::',1)
	ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/'+V4RNmuKT5dEebS
	ms2eq39LGR5ZluDtoVQ = Pi3u6H9QAm0x4yDMGBr(ms2eq39LGR5ZluDtoVQ)
	title = '[COLOR FFC89008]OWNER:  '+ms2eq39LGR5ZluDtoVQ+'[/COLOR]'
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,402,'','',ms2eq39LGR5ZluDtoVQ)
	hD6se2E307NcI = '{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {\n  views {\n    id\n    neon {\n      id\n      sections(device: $device, space: \"watching\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {\n        edges {\n          node {\n            id\n            name\n            groupingType\n            relatedComponent {\n              ... on Channel {\n                __typename\n                id\n                xid\n                name\n                displayName\n                logoURL(size: \"x60\")\n                logoURLx25: logoURL(size: \"x25\")\n              }\n              ... on Topic {\n                __typename\n                id\n                xid\n                name\n                names {\n                  edges {\n                    node {\n                      id\n                      name\n                      language {\n                        id\n                        codeAlpha2\n                        __typename\n                      }\n                      __typename\n                    }\n                    __typename\n                  }\n                  __typename\n                }\n              }\n              ... on Collection {\n                __typename\n                id\n                xid\n                name\n              }\n              __typename\n            }\n            components(first: $videoCountPerSection) {\n              metadata {\n                algorithm {\n                  name\n                  version\n                  uuid\n                  __typename\n                }\n                __typename\n              }\n              edges {\n                node {\n                  ... on Video {\n                    __typename\n                    id\n                    xid\n                    title\n                    duration\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    channel {\n                      id\n                      xid\n                      accountType\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      logoURL(size: \"x60\")\n                      __typename\n                    }\n                  }\n                  ... on Channel {\n                    __typename\n                    id\n                    xid\n                    name\n                    displayName\n                    accountType\n                    logoURL(size: \"x60\")\n                  }\n                  __typename\n                }\n                __typename\n              }\n              __typename\n            }\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	hD6se2E307NcI = hD6se2E307NcI.replace('myplaylistid',id)
	BBlXpmUyhFDwNtCVAHoE = fyoi4XahAvEQH3qjS5(hD6se2E307NcI)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"collection_videos"(.*?)"SectionEdge"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)".*?"xid":"(.*?)".*?"displayName":"(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for id,title,EDL3rwcivsR9W0pdTfygmOYUoVSb,VFqpJjRySZvgi,V4RNmuKT5dEebS,ms2eq39LGR5ZluDtoVQ in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in VFqpJjRySZvgi: VFqpJjRySZvgi = VFqpJjRySZvgi.replace('"','')
			if '"' in EDL3rwcivsR9W0pdTfygmOYUoVSb: EDL3rwcivsR9W0pdTfygmOYUoVSb = EDL3rwcivsR9W0pdTfygmOYUoVSb.replace('"','')
			if '"' in V4RNmuKT5dEebS: V4RNmuKT5dEebS = V4RNmuKT5dEebS.replace('"','')
			if '"' in ms2eq39LGR5ZluDtoVQ: ms2eq39LGR5ZluDtoVQ = ms2eq39LGR5ZluDtoVQ.replace('"','')
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/video/'+id
			title = Pi3u6H9QAm0x4yDMGBr(title)
			X5byeYgp1hrD0jGKf7wNUT2ZmquI = V4RNmuKT5dEebS+'::'+ms2eq39LGR5ZluDtoVQ
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,403,VFqpJjRySZvgi,EDL3rwcivsR9W0pdTfygmOYUoVSb,X5byeYgp1hrD0jGKf7wNUT2ZmquI)
	return
def IhRJl54HM7aSQBPWCYA81tu2Z(url,EfNzW3kLhcMTu07HrP28X9nFA6vpGd=''):
	if EfNzW3kLhcMTu07HrP28X9nFA6vpGd=='': EfNzW3kLhcMTu07HrP28X9nFA6vpGd = '1'
	jayps2bqRW6CEVl9IY8LdB5e = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	hD6se2E307NcI = '{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  isFollowed\n  accountType\n  __typename\n}\n\nfragment CHANNEL_IMAGES_FRAGMENT on Channel {\n  id\n  coverURLx375: coverURL(size: \"x375\")\n  __typename\n}\n\nfragment CHANNEL_UPDATED_FRAGMENT on Channel {\n  id\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_COMPLETE_FRAGMENT on Channel {\n  id\n  ...CHANNEL_BASE_FRAGMENT\n  ...CHANNEL_IMAGES_FRAGMENT\n  ...CHANNEL_UPDATED_FRAGMENT\n  description\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  externalLinks {\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  viewCount\n  duration\n  createdAt\n  isInWatchLater\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  thumbURLx240: thumbnailURL(size: \"x240\")\n  thumbURLx360: thumbnailURL(size: \"x360\")\n  thumbURLx480: thumbnailURL(size: \"x480\")\n  thumbURLx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nquery CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {\n  channel(xid: $channel_xid) {\n    id\n    ...CHANNEL_COMPLETE_FRAGMENT\n    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          ...VIDEO_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	hD6se2E307NcI = hD6se2E307NcI.replace('mychannelid',jayps2bqRW6CEVl9IY8LdB5e)
	hD6se2E307NcI = hD6se2E307NcI.replace('mypagelimit','40')
	hD6se2E307NcI = hD6se2E307NcI.replace('mypagenumber',EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	hD6se2E307NcI = hD6se2E307NcI.replace('mysortmethod',sort)
	BBlXpmUyhFDwNtCVAHoE = fyoi4XahAvEQH3qjS5(hD6se2E307NcI)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbURLx240":"(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for id,title,EDL3rwcivsR9W0pdTfygmOYUoVSb,V4RNmuKT5dEebS,ms2eq39LGR5ZluDtoVQ,VFqpJjRySZvgi in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in VFqpJjRySZvgi: VFqpJjRySZvgi = VFqpJjRySZvgi.replace('"','')
			if '"' in EDL3rwcivsR9W0pdTfygmOYUoVSb: EDL3rwcivsR9W0pdTfygmOYUoVSb = EDL3rwcivsR9W0pdTfygmOYUoVSb.replace('"','')
			if '"' in V4RNmuKT5dEebS: V4RNmuKT5dEebS = V4RNmuKT5dEebS.replace('"','')
			if '"' in ms2eq39LGR5ZluDtoVQ: ms2eq39LGR5ZluDtoVQ = ms2eq39LGR5ZluDtoVQ.replace('"','')
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/video/'+id
			title = Pi3u6H9QAm0x4yDMGBr(title)
			X5byeYgp1hrD0jGKf7wNUT2ZmquI = V4RNmuKT5dEebS+'::'+ms2eq39LGR5ZluDtoVQ
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,403,VFqpJjRySZvgi,EDL3rwcivsR9W0pdTfygmOYUoVSb,X5byeYgp1hrD0jGKf7wNUT2ZmquI)
		if '"hasNextPage":true' in BBlXpmUyhFDwNtCVAHoE:
			EfNzW3kLhcMTu07HrP28X9nFA6vpGd = str(int(EfNzW3kLhcMTu07HrP28X9nFA6vpGd)+1)
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+EfNzW3kLhcMTu07HrP28X9nFA6vpGd,url,408,'',EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	return
def xnZskv1BN5zymYLXiWIwTre2(url,EfNzW3kLhcMTu07HrP28X9nFA6vpGd=''):
	if EfNzW3kLhcMTu07HrP28X9nFA6vpGd=='': EfNzW3kLhcMTu07HrP28X9nFA6vpGd = '1'
	jayps2bqRW6CEVl9IY8LdB5e = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	hD6se2E307NcI = '{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  isFollowed\n  accountType\n  __typename\n}\n\nfragment CHANNEL_IMAGES_FRAGMENT on Channel {\n  id\n  coverURLx375: coverURL(size: \"x375\")\n  __typename\n}\n\nfragment CHANNEL_UPDATED_FRAGMENT on Channel {\n  id\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_COMPLETE_FRAGMENT on Channel {\n  id\n  ...CHANNEL_BASE_FRAGMENT\n  ...CHANNEL_IMAGES_FRAGMENT\n  ...CHANNEL_UPDATED_FRAGMENT\n  description\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  externalLinks {\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {\n  channel(xid: $channel_xid) {\n    id\n    ...CHANNEL_COMPLETE_FRAGMENT\n    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          xid\n          updatedAt\n          name\n          description\n          thumbURLx240: thumbnailURL(size: \"x240\")\n          thumbURLx360: thumbnailURL(size: \"x360\")\n          thumbURLx480: thumbnailURL(size: \"x480\")\n          stats {\n            videos {\n              total\n              __typename\n            }\n            __typename\n          }\n          channel {\n            id\n            ...CHANNEL_FRAGMENT\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	hD6se2E307NcI = hD6se2E307NcI.replace('mychannelid',jayps2bqRW6CEVl9IY8LdB5e)
	hD6se2E307NcI = hD6se2E307NcI.replace('mypagelimit','40')
	hD6se2E307NcI = hD6se2E307NcI.replace('mypagenumber',EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	hD6se2E307NcI = hD6se2E307NcI.replace('mysortmethod',sort)
	BBlXpmUyhFDwNtCVAHoE = fyoi4XahAvEQH3qjS5(hD6se2E307NcI)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"thumbURLx240":"(.*?)".*?"total":(.*?),.*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for id,name,VFqpJjRySZvgi,count,Ksh08Er2x3dfaNH4l5MjXJu,V4RNmuKT5dEebS,ms2eq39LGR5ZluDtoVQ in items:
			if '"' in id: id = id.replace('"','')
			if '"' in name: name = name.replace('"','')
			if '"' in VFqpJjRySZvgi: VFqpJjRySZvgi = VFqpJjRySZvgi.replace('"','')
			if '"' in count: count = count.replace('"','')
			if '"' in Ksh08Er2x3dfaNH4l5MjXJu: Ksh08Er2x3dfaNH4l5MjXJu = Ksh08Er2x3dfaNH4l5MjXJu.replace('"','')
			if '"' in V4RNmuKT5dEebS: V4RNmuKT5dEebS = V4RNmuKT5dEebS.replace('"','')
			if '"' in ms2eq39LGR5ZluDtoVQ: ms2eq39LGR5ZluDtoVQ = ms2eq39LGR5ZluDtoVQ.replace('"','')
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = Pi3u6H9QAm0x4yDMGBr(title)
			X5byeYgp1hrD0jGKf7wNUT2ZmquI = V4RNmuKT5dEebS+'::'+ms2eq39LGR5ZluDtoVQ
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,401,VFqpJjRySZvgi,'',X5byeYgp1hrD0jGKf7wNUT2ZmquI)
		if '"hasNextPage":true' in BBlXpmUyhFDwNtCVAHoE:
			EfNzW3kLhcMTu07HrP28X9nFA6vpGd = str(int(EfNzW3kLhcMTu07HrP28X9nFA6vpGd)+1)
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+EfNzW3kLhcMTu07HrP28X9nFA6vpGd,url,407,'',EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	return
def dZ3ODNqCATsxGEe1n0oQ9(url,GikAOC1UjFY8hHuIW):
	jayps2bqRW6CEVl9IY8LdB5e = url.split('/')[3]
	hD6se2E307NcI = '{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    followers {\n      id\n      total\n      __typename\n    }\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment LIVE_FRAGMENT on Live {\n  id\n  xid\n  title\n  startAt\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  __typename\n}\n\nfragment VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  viewCount\n  duration\n  createdAt\n  isInWatchLater\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment CHANNEL_MAIN_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  description\n  accountType\n  isArtist\n  logoURL(size: \"x60\")\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  isFollowed\n  tagline\n  country {\n    id\n    codeAlpha2\n    __typename\n  }\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    followers {\n      id\n      total\n      __typename\n    }\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  externalLinks {\n    id\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    pinterestURL\n    __typename\n  }\n  channel_lives_now: lives(first: 4, isOnAir: true) {\n    edges {\n      node {\n        id\n        ...LIVE_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_lives_scheduled: lives(first: 4, startIn: 7200) {\n    edges {\n      node {\n        id\n        ...LIVE_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_featured_videos: videos(first: 4, isFeatured: true) {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_all_videos: videos(first: 4) {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_most_viewed: videos(first: 4, sort: \"visited\") {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_collections: collections(first: 4) {\n    edges {\n      node {\n        id\n        xid\n        name\n        description\n        stats {\n          id\n          videos {\n            id\n            total\n            __typename\n          }\n          __typename\n        }\n        thumbnailx240: thumbnailURL(size: \"x240\")\n        thumbnailx360: thumbnailURL(size: \"x360\")\n        thumbnailx480: thumbnailURL(size: \"x480\")\n        channel {\n          id\n          ...CHANNEL_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_related_channel: networkChannels(\n    hasPublicVideos: true\n    first: $relatedChannels\n  ) {\n    edges {\n      node {\n        id\n        ...CHANNEL_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {\n  channel(name: $channel_name) {\n    id\n    ...CHANNEL_MAIN_FRAGMENT\n    __typename\n  }\n}\n"}'
	hD6se2E307NcI = hD6se2E307NcI.replace('mychannelid',jayps2bqRW6CEVl9IY8LdB5e)
	BBlXpmUyhFDwNtCVAHoE = fyoi4XahAvEQH3qjS5(hD6se2E307NcI)
	import json as IsRfCubK4FeYlZgEcXn6U5PNa0
	ybsxAutV8KT = IsRfCubK4FeYlZgEcXn6U5PNa0.loads(BBlXpmUyhFDwNtCVAHoE)
	try: items = ybsxAutV8KT['data']['channel'][GikAOC1UjFY8hHuIW]['edges']
	except: items = []
	if not items: cd0aGwCPExbFU5pYNu8r('link',mmDwMlfoHtG5XT19VLIWqCR8i+'لا توجد نتائج','',9999)
	else:
		for BrVNsC72UYWES4A in items:
			D6pARVZYMr18SykFaX2fWvJ = BrVNsC72UYWES4A['node']
			Vr04uqBf35KGSnE = D6pARVZYMr18SykFaX2fWvJ['xid']
			keys = list(D6pARVZYMr18SykFaX2fWvJ.keys())
			onmNpDqfPRzuSi9A7sKXOG8H5WMg = D6pARVZYMr18SykFaX2fWvJ['__typename'].lower()
			if onmNpDqfPRzuSi9A7sKXOG8H5WMg=='channel':
				name = D6pARVZYMr18SykFaX2fWvJ['name']
				qqdAnYkyavNrolJ831zK = D6pARVZYMr18SykFaX2fWvJ['displayName']
				title = 'CHNL:  '+qqdAnYkyavNrolJ831zK
				VFqpJjRySZvgi = D6pARVZYMr18SykFaX2fWvJ['coverURLx375']
			else:
				name = D6pARVZYMr18SykFaX2fWvJ['channel']['name']
				qqdAnYkyavNrolJ831zK = D6pARVZYMr18SykFaX2fWvJ['channel']['displayName']
				title = D6pARVZYMr18SykFaX2fWvJ['title']
				VFqpJjRySZvgi = D6pARVZYMr18SykFaX2fWvJ['thumbnailx360']
				if onmNpDqfPRzuSi9A7sKXOG8H5WMg=='live': title = 'LIVE:  '+title
			title = Pi3u6H9QAm0x4yDMGBr(title)
			X5byeYgp1hrD0jGKf7wNUT2ZmquI = name+'::'+qqdAnYkyavNrolJ831zK
			if HHosl5fRdhtEDAYyP:
				title = title.encode('utf8')
				X5byeYgp1hrD0jGKf7wNUT2ZmquI = X5byeYgp1hrD0jGKf7wNUT2ZmquI.encode('utf8')
			if onmNpDqfPRzuSi9A7sKXOG8H5WMg=='channel':
				ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/'+Vr04uqBf35KGSnE
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,402,VFqpJjRySZvgi,'',X5byeYgp1hrD0jGKf7wNUT2ZmquI)
			else:
				if onmNpDqfPRzuSi9A7sKXOG8H5WMg=='video': EDL3rwcivsR9W0pdTfygmOYUoVSb = str(D6pARVZYMr18SykFaX2fWvJ['duration'])
				else: EDL3rwcivsR9W0pdTfygmOYUoVSb = ''
				ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/video/'+Vr04uqBf35KGSnE
				cd0aGwCPExbFU5pYNu8r(onmNpDqfPRzuSi9A7sKXOG8H5WMg,mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,403,VFqpJjRySZvgi,EDL3rwcivsR9W0pdTfygmOYUoVSb,X5byeYgp1hrD0jGKf7wNUT2ZmquI)
	return
def fyoi4XahAvEQH3qjS5(hD6se2E307NcI):
	hD6se2E307NcI = hD6se2E307NcI.replace(' \"',' \\"')
	hD6se2E307NcI = hD6se2E307NcI.replace('\", ','\\", ')
	hD6se2E307NcI = hD6se2E307NcI.replace('\n','\\n')
	hD6se2E307NcI = hD6se2E307NcI.replace('")','\\")')
	f5KHTjLcuVaODMX2ie9R = Y4C20j56T8km()
	headers = {"Authorization":f5KHTjLcuVaODMX2ie9R,"Origin":NBm2aWhPzoTpdYn}
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'POST',msL09WzMG3c86RAqkXpY7yn,hD6se2E307NcI,headers,'','','DAILYMOTION-GET_PAGEDATA-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	return BBlXpmUyhFDwNtCVAHoE
def Y4C20j56T8km():
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'GET',NBm2aWhPzoTpdYn,'','','','','DAILYMOTION-GET_AUTHINTICATION-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	sTB6LmkjPVJnuzhOZaog = GGvHJKP9LUxEk10Fw.findall('var r="(.*?)",o="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	yDhTmFMlSU8YX7AcdwCPp,uzTPMZk50KyHgaGYrDEq = sTB6LmkjPVJnuzhOZaog[-1]
	fJtbUNuFPc4mZ = 'https://graphql.api.dailymotion.com/oauth/token'
	hq0UKxkBGCr5t7TNbWePXdomYy = 'client_credentials'
	data = {'client_id':yDhTmFMlSU8YX7AcdwCPp,'client_secret':uzTPMZk50KyHgaGYrDEq,'grant_type':hq0UKxkBGCr5t7TNbWePXdomYy}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'POST',fJtbUNuFPc4mZ,data,headers,'','','DAILYMOTION-GET_AUTHINTICATION-2nd')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	sTB6LmkjPVJnuzhOZaog = GGvHJKP9LUxEk10Fw.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	u8HGrhf0J2qv,xxwhkRDmzXVQca9qt3NYj = sTB6LmkjPVJnuzhOZaog[0]
	f5KHTjLcuVaODMX2ie9R = xxwhkRDmzXVQca9qt3NYj+" "+u8HGrhf0J2qv
	return f5KHTjLcuVaODMX2ie9R
def szwTAdaBt4FiXO(search,type=''):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if not type and showDialogs:
		vmdFPAK1WHjCMw = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن قنوات','بحث عن مواضيع','بحث عن بث حي']
		z0jyetbQwKrIclL9vJW = D1DJtzviFZSrA('موقع ديلي موشن - اختر البحث',vmdFPAK1WHjCMw)
		if z0jyetbQwKrIclL9vJW==-1: return
		elif z0jyetbQwKrIclL9vJW==0: type = 'videos?sortBy='
		elif z0jyetbQwKrIclL9vJW==1: type = 'videos?sortBy=RECENT'
		elif z0jyetbQwKrIclL9vJW==2: type = 'videos?sortBy=VIEW_COUNT'
		elif z0jyetbQwKrIclL9vJW==3: type = 'playlists'
		elif z0jyetbQwKrIclL9vJW==4: type = 'channels'
		elif z0jyetbQwKrIclL9vJW==5: type = 'topics'
		elif z0jyetbQwKrIclL9vJW==6: type = 'lives'
	elif '_DAILYMOTION-VIDEOS_' in tY3Dfrp6cMKFj: type = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in tY3Dfrp6cMKFj: type = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in tY3Dfrp6cMKFj: type = 'channels'
	elif '_DAILYMOTION-TOPICS_' in tY3Dfrp6cMKFj: type = 'topics'
	elif '_DAILYMOTION-LIVES_' in tY3Dfrp6cMKFj: type = 'lives'
	if not search:
		search = yMRXZIpKxlSkaE6iCO()
		if not search: return
	if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: search = search.encode('utf8').decode('raw_unicode_escape')
	if 'videos' in type: ryYAOUhg6p875Rw0fG(search+'/'+type)
	elif 'playlists' in type: BBb2ueJ9amqoVHL(search)
	elif 'channels' in type: OugBEMPU0Hjt(search)
	elif 'topics' in type: KI4NyW73o2uQRmgjkTCZBrlf(search)
	elif 'lives' in type: NFxCXUkyGJfiju5cn04T7Qp9vt2H(search)
	return
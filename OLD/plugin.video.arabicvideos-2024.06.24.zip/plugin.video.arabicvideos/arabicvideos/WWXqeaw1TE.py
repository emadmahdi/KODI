# -*- coding: utf-8 -*-
import sys as GGtWyVoJReUuEBCdAagiL1YXO8
ggqTOXpCEcQD68f3oxrKilaSvkdtN = GGtWyVoJReUuEBCdAagiL1YXO8.version_info [0] == 2
pQ14eMnbYBK0xGywR7SuFChJdONj6 = 2048
y65ArzSx9RZh = 7
def MUzuWiALbXp6w5 (TMw2a0zHkY9lcdIvLFZXrS):
	global ynv9hpqlRAJuN0gXrEscaoP5dMWYDO
	Icnd5Dq4krBK3iYg2xNZHF = ord (TMw2a0zHkY9lcdIvLFZXrS [-1])
	u05ustK47xXQZbyFerWTROY = TMw2a0zHkY9lcdIvLFZXrS [:-1]
	BXAu3ZJQ9IPLg7kiy4K06ha = Icnd5Dq4krBK3iYg2xNZHF % len (u05ustK47xXQZbyFerWTROY)
	nRXUw1Fg0DSrkYGL = u05ustK47xXQZbyFerWTROY [:BXAu3ZJQ9IPLg7kiy4K06ha] + u05ustK47xXQZbyFerWTROY [BXAu3ZJQ9IPLg7kiy4K06ha:]
	if ggqTOXpCEcQD68f3oxrKilaSvkdtN:
		sW7Qyn32Zidt5TE4w96 = unicode () .join ([unichr (ord (Lk9Jh0wu7aNAE) - pQ14eMnbYBK0xGywR7SuFChJdONj6 - (Ebxc6eiUkyVNfMBs3CRIOArQ4h + Icnd5Dq4krBK3iYg2xNZHF) % y65ArzSx9RZh) for Ebxc6eiUkyVNfMBs3CRIOArQ4h, Lk9Jh0wu7aNAE in enumerate (nRXUw1Fg0DSrkYGL)])
	else:
		sW7Qyn32Zidt5TE4w96 = str () .join ([chr (ord (Lk9Jh0wu7aNAE) - pQ14eMnbYBK0xGywR7SuFChJdONj6 - (Ebxc6eiUkyVNfMBs3CRIOArQ4h + Icnd5Dq4krBK3iYg2xNZHF) % y65ArzSx9RZh) for Ebxc6eiUkyVNfMBs3CRIOArQ4h, Lk9Jh0wu7aNAE in enumerate (nRXUw1Fg0DSrkYGL)])
	return eval (sW7Qyn32Zidt5TE4w96)
Cu1704YofAbr3QTm,oh5Ptv7RjM3qLk1eEZJbcVzKis4d,LiRcTVUWuth70DmPy=MUzuWiALbXp6w5,MUzuWiALbXp6w5,MUzuWiALbXp6w5
pq3Z6xaELn0NW7PgAeI1bCRwdu,UTelCo0ihE1d5R,Me28A1sBLNIgUp5YCDyvT=LiRcTVUWuth70DmPy,oh5Ptv7RjM3qLk1eEZJbcVzKis4d,Cu1704YofAbr3QTm
kEhAHvti6Vnsfx,g4g6bfkPtVGU5lIM3,E6MIKdpBomef=Me28A1sBLNIgUp5YCDyvT,UTelCo0ihE1d5R,pq3Z6xaELn0NW7PgAeI1bCRwdu
wRxoKs10Syj7V4edYhtP,yA5z6LIXBlo41PRVMY87wOisFp,iUeoLOsbHqP=E6MIKdpBomef,g4g6bfkPtVGU5lIM3,kEhAHvti6Vnsfx
iRoLg2m47tnDATBHGCSPNyx,xW2Arao7YVOemw,l30iT7pjzmXk8dvwSNyUR1aZO4tWh=iUeoLOsbHqP,yA5z6LIXBlo41PRVMY87wOisFp,wRxoKs10Syj7V4edYhtP
dshJSmRqeiP9nap2,FnBiAjthS8MkXs67W,FvNyZqaLKw=l30iT7pjzmXk8dvwSNyUR1aZO4tWh,xW2Arao7YVOemw,iRoLg2m47tnDATBHGCSPNyx
SO94xq1RAkMm2uF,bUdr5Hahw6sY8xJ,XzrqbGDIy54juixkMA=FvNyZqaLKw,FnBiAjthS8MkXs67W,dshJSmRqeiP9nap2
p72fnFtcPix5UKwr9YNzW,sTcr7iDp5eFt4RoLMhuwq1A,SyENPzdOon6uxcLXMhqb14aDlB9r=XzrqbGDIy54juixkMA,bUdr5Hahw6sY8xJ,SO94xq1RAkMm2uF
zqdvcbP5L8BHh,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF,lc0dpSmwoPDjLnk=SyENPzdOon6uxcLXMhqb14aDlB9r,sTcr7iDp5eFt4RoLMhuwq1A,p72fnFtcPix5UKwr9YNzW
QVZl0O8yUIzdGDTfYcn5H37uWmb2,hRNlWkwDitzVpbSO3TIdAm5YGjaZ,fprnld4CZo=lc0dpSmwoPDjLnk,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF,zqdvcbP5L8BHh
hBvsQ7oCkKUdwjx58ml3EN,G5DeRbUpFj8E9OtJLvlo2fWmZC,S4SOKF2QbBhjCd3RrVMuHIzE=fprnld4CZo,hRNlWkwDitzVpbSO3TIdAm5YGjaZ,QVZl0O8yUIzdGDTfYcn5H37uWmb2
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕࠪᅺ")
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(VRnfEFmJzUrSljM8,MMupPCxqkenwt6FlsbRILV37EAmB=G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩࠪᅻ")):
	if   VRnfEFmJzUrSljM8==  oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠶ᗑ"): D1HpItnzANhSreR5lOfCx3(MMupPCxqkenwt6FlsbRILV37EAmB)
	elif VRnfEFmJzUrSljM8==  XzrqbGDIy54juixkMA(u"࠲ᗒ"): eimszEapSbIurqvN3c5hk4VylDCH(MMupPCxqkenwt6FlsbRILV37EAmB)
	elif VRnfEFmJzUrSljM8==  sTcr7iDp5eFt4RoLMhuwq1A(u"࠴ᗓ"): mHqa9szk4E5()
	elif VRnfEFmJzUrSljM8==  wRxoKs10Syj7V4edYhtP(u"࠶ᗔ"): hD80GrKP5fMgRtdA9BYlHpCsk(MMupPCxqkenwt6FlsbRILV37EAmB)
	elif VRnfEFmJzUrSljM8==  hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠸ᗕ"): xxVPwvkAgDcLtqanG()
	elif VRnfEFmJzUrSljM8==  QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠺ᗖ"): RvV9ztgAFkJIL8a7CXxhq()
	elif VRnfEFmJzUrSljM8==  kEhAHvti6Vnsfx(u"࠼ᗗ"): WrEwOCRSaplo7iy6ZDxIJ2teL0Tf(fprnld4CZo(u"ࡖࡵࡹࡪᚃ"),fprnld4CZo(u"ࡖࡵࡹࡪᚃ"))
	elif VRnfEFmJzUrSljM8==  UTelCo0ihE1d5R(u"࠾ᗘ"): vM2yUHSRn1IdthZl8rA4OLCc()
	elif VRnfEFmJzUrSljM8==  FnBiAjthS8MkXs67W(u"࠹ᗙ"): BcrwHJOChQvkmqyLEg4U28()
	elif VRnfEFmJzUrSljM8==YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠲࠷࠳ᗚ"): v75riERgl6ec()
	elif VRnfEFmJzUrSljM8==dshJSmRqeiP9nap2(u"࠳࠸࠵ᗛ"): IZYxewht7RETNr8vGqWi()
	elif VRnfEFmJzUrSljM8==G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠴࠹࠷ᗜ"): G0tHfLFAN3Jqeugi()
	elif VRnfEFmJzUrSljM8==hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠵࠺࠹ᗝ"): hvq04Ted9RHKpiFVQtw()
	elif VRnfEFmJzUrSljM8==Me28A1sBLNIgUp5YCDyvT(u"࠶࠻࠴ᗞ"): Z1H2kgnfodwDWv5EUi6ytpA7xQlbR()
	elif VRnfEFmJzUrSljM8==oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠷࠵࠶ᗟ"): YYkLbjIEdrxVGh()
	elif VRnfEFmJzUrSljM8==SO94xq1RAkMm2uF(u"࠱࠶࠸ᗠ"): xpGg082CRzFKyBklQebhI()
	elif VRnfEFmJzUrSljM8==Me28A1sBLNIgUp5YCDyvT(u"࠲࠷࠺ᗡ"): iox5GqmLNMR2Sz98dDaYw6Fgh1Wn()
	elif VRnfEFmJzUrSljM8==S4SOKF2QbBhjCd3RrVMuHIzE(u"࠳࠸࠼ᗢ"): medGTENZQsk2nAP4H1uDJfW0I()
	elif VRnfEFmJzUrSljM8==p72fnFtcPix5UKwr9YNzW(u"࠴࠹࠾ᗣ"): zisvklMRxwE0TudAe3fQJ(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࡗࡶࡺ࡫ᚄ"))
	elif VRnfEFmJzUrSljM8==hBvsQ7oCkKUdwjx58ml3EN(u"࠵࠼࠶ᗤ"): RlKVPn5e1EI72()
	elif VRnfEFmJzUrSljM8==UTelCo0ihE1d5R(u"࠶࠽࠱ᗥ"): H5QDuUbft4NilgahprLAx()
	elif VRnfEFmJzUrSljM8==bUdr5Hahw6sY8xJ(u"࠷࠷࠳ᗦ"): mGVePOXw1YfpdJzqUM9a4Atr(MMupPCxqkenwt6FlsbRILV37EAmB,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࡘࡷࡻࡥᚅ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࡘࡷࡻࡥᚅ"))
	elif VRnfEFmJzUrSljM8==LiRcTVUWuth70DmPy(u"࠱࠸࠵ᗧ"): KmIlXVwgsFZxEdh1b(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪᅼ"),yA5z6LIXBlo41PRVMY87wOisFp(u"࡙ࡸࡵࡦᚆ"))
	elif VRnfEFmJzUrSljM8==E6MIKdpBomef(u"࠲࠹࠷ᗨ"): KmIlXVwgsFZxEdh1b(lc0dpSmwoPDjLnk(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡵࡸࡲࡶࠧᅽ"),UTelCo0ihE1d5R(u"࡚ࡲࡶࡧᚇ"))
	elif VRnfEFmJzUrSljM8==oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠳࠺࠹ᗩ"): ZgriCAIUS0c4TjN8luwD3od()
	elif VRnfEFmJzUrSljM8==wRxoKs10Syj7V4edYhtP(u"࠴࠻࠻ᗪ"): Vhbvf1XcqnE7TUksM28PLC()
	elif VRnfEFmJzUrSljM8==p72fnFtcPix5UKwr9YNzW(u"࠵࠼࠽ᗫ"): ZKDzFVhQgT08BRSvu7wWGOAn(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠩᅾ"))
	elif VRnfEFmJzUrSljM8==g4g6bfkPtVGU5lIM3(u"࠶࠽࠸ᗬ"): ZKDzFVhQgT08BRSvu7wWGOAn(hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡵ࠯ࡧࡰࡵ࠭ᅿ"))
	elif VRnfEFmJzUrSljM8==UTelCo0ihE1d5R(u"࠷࠷࠺ᗭ"): ZKDzFVhQgT08BRSvu7wWGOAn(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡹࡰࡷࡷࡹࡧ࡫ࠧᆀ"))
	elif VRnfEFmJzUrSljM8==iUeoLOsbHqP(u"࠱࠺࠲ᗮ"): JEwT6SyBWQnl()
	elif VRnfEFmJzUrSljM8==zqdvcbP5L8BHh(u"࠲࠻࠴ᗯ"): jjF4Xi2ToqYEmKu8()
	elif VRnfEFmJzUrSljM8==SO94xq1RAkMm2uF(u"࠳࠼࠶ᗰ"): BGHWTD4nJsOq9c2ICpafoK1z()
	elif VRnfEFmJzUrSljM8==zqdvcbP5L8BHh(u"࠴࠽࠸ᗱ"): UAYdBOy7iFb2nQVfJk()
	elif VRnfEFmJzUrSljM8==yA5z6LIXBlo41PRVMY87wOisFp(u"࠵࠾࠺ᗲ"): PeUX4o7xmuLVYtyBwZjbR()
	elif VRnfEFmJzUrSljM8==zqdvcbP5L8BHh(u"࠶࠿࠵ᗳ"): r7rWDudx1p8()
	elif VRnfEFmJzUrSljM8==lc0dpSmwoPDjLnk(u"࠷࠹࠷ᗴ"): lwjFYHeGCfrbuaB2zWIgEyRp3cP9()
	elif VRnfEFmJzUrSljM8==SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠱࠺࠹ᗵ"): kRXgjTnwVeoJ0PD()
	elif VRnfEFmJzUrSljM8==G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠲࠻࠻ᗶ"): kgXCoOxBI3bDyNmhp481MY()
	elif VRnfEFmJzUrSljM8==wRxoKs10Syj7V4edYhtP(u"࠳࠼࠽ᗷ"): I5wp1m68J3NhaDvubAYOtTrWG9cyZ()
	elif VRnfEFmJzUrSljM8==Cu1704YofAbr3QTm(u"࠶࠸࠵ᗸ"): l56CsZUJoONMLdq(MMupPCxqkenwt6FlsbRILV37EAmB)
	elif VRnfEFmJzUrSljM8==yA5z6LIXBlo41PRVMY87wOisFp(u"࠷࠹࠷ᗹ"): AA6dYxswFGyI1zcN7kB82Rh9O()
	elif VRnfEFmJzUrSljM8==Cu1704YofAbr3QTm(u"࠸࠺࠲ᗺ"): cxsSYuvBHL()
	elif VRnfEFmJzUrSljM8==bUdr5Hahw6sY8xJ(u"࠹࠴࠴ᗻ"): B74SXWm68Hb5sQR()
	elif VRnfEFmJzUrSljM8==E6MIKdpBomef(u"࠳࠵࠶ᗼ"): wwVGpkZzinfRcTLKYF8eOW(FvNyZqaLKw(u"ࡔࡳࡷࡨᚈ"))
	elif VRnfEFmJzUrSljM8==l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠴࠶࠸ᗽ"): e6e7BfQyCUrcqjJD()
	elif VRnfEFmJzUrSljM8==XzrqbGDIy54juixkMA(u"࠵࠷࠺ᗾ"): JuKwpjEMF0O8sC(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࡇࡣ࡯ࡷࡪᚉ"))
	elif VRnfEFmJzUrSljM8==FnBiAjthS8MkXs67W(u"࠶࠸࠼ᗿ"): hEg3ps5mkl9i(Cu1704YofAbr3QTm(u"ࡖࡵࡹࡪᚊ"))
	elif VRnfEFmJzUrSljM8==p72fnFtcPix5UKwr9YNzW(u"࠷࠹࠾ᘀ"): QJlFsfjgHWPyEOUd()
	elif VRnfEFmJzUrSljM8==UTelCo0ihE1d5R(u"࠸࠺࠹ᘁ"): pass
	elif VRnfEFmJzUrSljM8==G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠻࠰࠱ᘂ"): yyaW5PZg19QHTz7VMpL()
	elif VRnfEFmJzUrSljM8==hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠵࠱࠳ᘃ"): XdBvx93YjAGHzSCOFPp()
	elif VRnfEFmJzUrSljM8==yA5z6LIXBlo41PRVMY87wOisFp(u"࠶࠲࠵ᘄ"): wadYxypc8umjFENRvq0r(UTelCo0ihE1d5R(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧᆁ"),iRoLg2m47tnDATBHGCSPNyx(u"ࡗࡶࡺ࡫ᚋ"))
	elif VRnfEFmJzUrSljM8==iUeoLOsbHqP(u"࠷࠳࠷ᘅ"): odE5wYAD0Pe(J2M15kw7Rdv0rQZxITaNuXeyWc)
	elif VRnfEFmJzUrSljM8==E6MIKdpBomef(u"࠸࠴࠹ᘆ"): odE5wYAD0Pe(PGIWHNLQuRoK1M)
	elif VRnfEFmJzUrSljM8==lc0dpSmwoPDjLnk(u"࠹࠵࠻ᘇ"): gkO25elvu7FU6r3()
	elif VRnfEFmJzUrSljM8==fprnld4CZo(u"࠺࠶࠶ᘈ"): LKE5PBr2XSg0ZYlMCV(sTcr7iDp5eFt4RoLMhuwq1A(u"ࡘࡷࡻࡥᚌ"))
	elif VRnfEFmJzUrSljM8==Me28A1sBLNIgUp5YCDyvT(u"࠻࠰࠸ᘉ"): pozVO4qafduDiX2WmYcN3w(MMupPCxqkenwt6FlsbRILV37EAmB,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩࠪᆂ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"࡙ࡸࡵࡦᚍ"))
	elif VRnfEFmJzUrSljM8==kEhAHvti6Vnsfx(u"࠵࠱࠺ᘊ"): IfsoKtyn7iarS1cCGB83bYPAzFZQUO()
	elif VRnfEFmJzUrSljM8==g4g6bfkPtVGU5lIM3(u"࠶࠲࠼ᘋ"): XHczJtdVfIy6oTEwkp0Fbv7W()
	return
def XHczJtdVfIy6oTEwkp0Fbv7W():
	o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(UTelCo0ihE1d5R(u"ࠪࠫᆃ"),wRxoKs10Syj7V4edYhtP(u"ࠫࠬᆄ"),LiRcTVUWuth70DmPy(u"ࠬ࠭ᆅ"),kEhAHvti6Vnsfx(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᆆ"),LiRcTVUWuth70DmPy(u"่ࠧๆࠣฮึ๐ฯࠡใ฼่ฬࠦๅิฯࠣะ๊๐ูࠡว฼ำฬีวหࠢส่อืๆศ็ฯࠤ࠳࠴้ࠠ็ึัࠥาๅ๋฻้้ࠣ็วหࠢส่อืๆศ็ฯࠤฬ๊โะ์่อࠥ࠴࠮ࠡๆๆ๎ࠥ๐ู้ัࠣห้ฮั็ษ่ะࠥหไ๊ࠢะห้ฯࠠศๆุๅึࠦ࠮࠯ࠢํ฽๋๐ࠠหฮา๎ิࠦวๅสิ๊ฬ๋ฬ๊ࠡอูๆ๐ั่๋ࠢ์฻฿็ࠡสะห้ฯࠠศๆู่๋฿ࠠศๆอ๎ࠥ๎ึฺ้สࠤฬ๊ๅษำ่ะࠥลࠡࠢࠩᆇ"))
	if o07Z1tEB4n3ARCkVNu:
		wwVGpkZzinfRcTLKYF8eOW(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࡌࡡ࡭ࡵࡨᚎ"))
		OOy4gzCqrV382ctPa(JXUQZHLxEgTFbrRC7n9,iUeoLOsbHqP(u"ࡕࡴࡸࡩᚐ"),p72fnFtcPix5UKwr9YNzW(u"ࡆࡢ࡮ࡶࡩᚏ"))
		aHKzv76JCVnprbY8w(Me28A1sBLNIgUp5YCDyvT(u"ࠨࠩᆈ"),E6MIKdpBomef(u"ࠩࠪᆉ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᆊ"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫฯ๋ࠠๆีะࠤัฺ๋๊ࠢส่๊๊แศฬࠣห้่ฯ๋็ฬࠤ้๊ศา่ส้ัࠦ࠮࠯๋ࠢ฽ฬีࠠศๆหี๋อๅอࠢศ่๎่ࠦื฻ํอࠥอไึใิࠤ࠳࠴ุ้ࠠ฼๎ฮࠦวๅ็ุ๊฾࠭ᆋ"))
	return
def pozVO4qafduDiX2WmYcN3w(ssZLBRtgnMkc7dSouQeGCx3r8m,ZKYkxJlSc2E8e1m,showDialogs):
	QAlb96UhsVG = j5cfNmnkuUA.connect(QLmA1IVR5dvG)
	QAlb96UhsVG.text_factory = str
	PYRN3CLTut = QAlb96UhsVG.cursor()
	if HHosl5fRdhtEDAYyP: KFH1XJcfwqgBIvTrWt5GAms6 = Cu1704YofAbr3QTm(u"ࠬࡨ࡬ࡢࡥ࡮ࡰ࡮ࡹࡴࠨᆌ")
	else: KFH1XJcfwqgBIvTrWt5GAms6 = fprnld4CZo(u"࠭ࡵࡱࡦࡤࡸࡪࡥࡲࡶ࡮ࡨࡷࠬᆍ")
	PYRN3CLTut.execute(FnBiAjthS8MkXs67W(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࠨᆎ")+KFH1XJcfwqgBIvTrWt5GAms6+xW2Arao7YVOemw(u"ࠨ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭ᆏ")+ssZLBRtgnMkc7dSouQeGCx3r8m+xW2Arao7YVOemw(u"ࠩࠥࠤࡀ࠭ᆐ"))
	NOpl1LBIvGax8oHDbj9 = PYRN3CLTut.fetchall()
	if NOpl1LBIvGax8oHDbj9 and ZKYkxJlSc2E8e1m in [l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࠫᆑ"),SO94xq1RAkMm2uF(u"ࠫࡪࡴࡡࡣ࡮ࡨࠫᆒ")]:
		o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(fprnld4CZo(u"ࠬ࠭ᆓ"),FvNyZqaLKw(u"࠭ࠧᆔ"),fprnld4CZo(u"ࠧࠨᆕ"),iUeoLOsbHqP(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᆖ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩส่ฯำฯ๋อࠣห้ษ่ห๊่หฯ๐ใ๋ࠢ็ษ฻อแสࠢ࡟ࡲࠥ࠭ᆗ")+ssZLBRtgnMkc7dSouQeGCx3r8m+hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪࠤࡡࡴ࡜࡯ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๋ࠥส้ไไࠤํ๊วࠡ์฼้้ࠦ࠮࠯๊่ࠢࠥะั๋ัࠣฮๆ฿๊ๅ้ࠣห้ศๆࠡมࠤࠥࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࡝ࡰ࡟ࡲࠥะำหูํ฽ࠥห๊ใษไ๋ࠥฮำ่๊็อࠥ฿ๆะࠢส่฾๎ฯสࠢศ่๎ࠦ็ั้ࠣหฺ้วีหࠣห้๋่อ๊าอࠥ็๊ࠡไสส๊ฯࠠฯั่หฯࠦศา่ส้ัูࠦๆษาࠫᆘ"))
		if o07Z1tEB4n3ARCkVNu!=oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠳ᘌ"): return
		PYRN3CLTut.execute(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠪᆙ")+KFH1XJcfwqgBIvTrWt5GAms6+p72fnFtcPix5UKwr9YNzW(u"ࠬࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪᆚ")+ssZLBRtgnMkc7dSouQeGCx3r8m+fprnld4CZo(u"࠭ࠢࠡ࠽ࠪᆛ"))
	elif ZKYkxJlSc2E8e1m in [FvNyZqaLKw(u"ࠧࠨᆜ"),FnBiAjthS8MkXs67W(u"ࠨࡦ࡬ࡷࡦࡨ࡬ࡦࠩᆝ")]:
		o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(bUdr5Hahw6sY8xJ(u"ࠩࠪᆞ"),XzrqbGDIy54juixkMA(u"ࠪࠫᆟ"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࠬᆠ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᆡ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭วๅฬะำ๏ัࠠศๆฦ์ฯ๎ๅศฬํ็๏ࠦไฦุสๅฮࠦ࡜࡯ࠢࠪᆢ")+ssZLBRtgnMkc7dSouQeGCx3r8m+Cu1704YofAbr3QTm(u"ࠧࠡ࡞ࡱࡠࡳ࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞่ࠢๅ฾๊้ࠠ์฼้้ࠦ࠮࠯๊่ࠢࠥะั๋ัࠣษ๏่วโ้ࠣห้ศๆࠡมࠤࠥࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࡝ࡰ࡟ࡲࠥะำหูํ฽ࠥะแฺ์็๋ࠥฮำ่๊็อࠥ฿ๆะࠢส่฾๎ฯสࠢศ่๎ࠦ็ั้ࠣหฺ้วีหࠣห้๋่อ๊าอࠥ็๊ࠡไสส๊ฯࠠฯั่หฯࠦศา่ส้ัูࠦๆษาࠫᆣ"))
		if o07Z1tEB4n3ARCkVNu!=FnBiAjthS8MkXs67W(u"࠴ᘍ"): return
		if HHosl5fRdhtEDAYyP: PYRN3CLTut.execute(lc0dpSmwoPDjLnk(u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࡢ࡭ࡣࡦ࡯ࡱ࡯ࡳࡵࠢࠫࡥࡩࡪ࡯࡯ࡋࡇ࠭ࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮ࠢࠨᆤ")+ssZLBRtgnMkc7dSouQeGCx3r8m+XzrqbGDIy54juixkMA(u"ࠩࠥ࠭ࠥࡁࠧᆥ"))
		else: PYRN3CLTut.execute(UTelCo0ihE1d5R(u"ࠪࡍࡓ࡙ࡅࡓࡖࠣࡍࡓ࡚ࡏࠡࡷࡳࡨࡦࡺࡥࡠࡴࡸࡰࡪࡹࠠࠩࡣࡧࡨࡴࡴࡉࡅ࠮ࡸࡴࡩࡧࡴࡦࡔࡸࡰࡪ࠯ࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࠤࠪᆦ")+ssZLBRtgnMkc7dSouQeGCx3r8m+zqdvcbP5L8BHh(u"ࠫࠧ࠲࠱ࠪࠢ࠾ࠫᆧ"))
	QAlb96UhsVG.commit()
	QAlb96UhsVG.close()
	MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠵ᘎ"))
	cEZpW924rqNYm5.executebuiltin(sTcr7iDp5eFt4RoLMhuwq1A(u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩᆨ"))
	MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(FnBiAjthS8MkXs67W(u"࠶ᘏ"))
	if showDialogs: aHKzv76JCVnprbY8w(kEhAHvti6Vnsfx(u"࠭ࠧᆩ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࠨᆪ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᆫ"),zqdvcbP5L8BHh(u"ࠩอ้ฯࠦวๅ฻่่๏ฯࠠษ่ฯหา࠭ᆬ"))
	if ZKYkxJlSc2E8e1m in [SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪࠫᆭ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫࡪࡴࡡࡣ࡮ࡨࠫᆮ")]: zisvklMRxwE0TudAe3fQJ(showDialogs)
	return
def gkO25elvu7FU6r3():
	HHg0f8U75SdzxEcbt1JN(UkFh2OXjuTZEaexC,bUdr5Hahw6sY8xJ(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨᆯ"),zqdvcbP5L8BHh(u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩᆰ"))
	LysGAMozW185TVxl = AE8MedoFXQNrYhRvW(dshJSmRqeiP9nap2(u"ࡈࡤࡰࡸ࡫ᚑ"))
	WuQdrqR9m1ZI0BN7pXiK = sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧ࡝ࡰࠪᆱ")
	zQB4g6WsMu8GtVnqf5CeZLj3mS = FnBiAjthS8MkXs67W(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠤ࠲࠳࠭࠮࠯ࠣ࠱࠲࠳࠭࠮ࠢ࠰࠱࠲࠳࠭ࠡ࠯࠰࠱࠲࠳ࠠ࠮࠯࠰࠱࠲࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᆲ")
	f21h3WIGQHOrP5TUikave9 = iRoLg2m47tnDATBHGCSPNyx(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳࡢ࡮ࠨᆳ")
	for id,exOIZnGECcR2p3WV4TPY06BNDo7,Tg1CAnZtj9MNe5wS,RuSqTgGZ7tlerwK9pWYf16Ln,tcopCZGnbdvY8r,reason in reversed(LysGAMozW185TVxl):
		if id==FvNyZqaLKw(u"ࠪ࠴ࠬᆴ"):
			uLrdWC8tUFHm52Sbo07I,vvuP2MEINoUGtKT5 = RuSqTgGZ7tlerwK9pWYf16Ln.split(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࡡࡴ࠻࠼ࠩᆵ"))
			continue
		if WuQdrqR9m1ZI0BN7pXiK!=XzrqbGDIy54juixkMA(u"ࠬࡢ࡮ࠨᆶ"): WuQdrqR9m1ZI0BN7pXiK += f21h3WIGQHOrP5TUikave9
		Wu6THcbvsRZdXSz4nwlCVy = FnBiAjthS8MkXs67W(u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧᆷ")+id+FvNyZqaLKw(u"ࠧࠡ࠼ࠣࠫᆸ")+sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨษ็ืษอไࠡ࠼ࠣࠫᆹ")+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᆺ")+Tg1CAnZtj9MNe5wS
		bdzvPE1KBTfkMj04QAG5hY7ouqZD = UTelCo0ihE1d5R(u"ࠪࡠࡳࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไอ๊สฬࠥࡀࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᆻ")+RuSqTgGZ7tlerwK9pWYf16Ln
		eFQXmOopl5Gfd = oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ฮุลࠣ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᆼ")+tcopCZGnbdvY8r
		ZIGlKA0aOBfFuonWj = Me28A1sBLNIgUp5YCDyvT(u"ࠬࡢ࡮࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆึฬอࠦ࠺ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᆽ")+reason
		WuQdrqR9m1ZI0BN7pXiK += Wu6THcbvsRZdXSz4nwlCVy+bdzvPE1KBTfkMj04QAG5hY7ouqZD+Cu1704YofAbr3QTm(u"࠭࡜࡯ࠩᆾ")+zQB4g6WsMu8GtVnqf5CeZLj3mS+FvNyZqaLKw(u"ࠧ࡝ࡰࠪᆿ")+eFQXmOopl5Gfd+ZIGlKA0aOBfFuonWj+E6MIKdpBomef(u"ࠨ࡞ࡱࠫᇀ")
	d0tNlv4Lbu2pqDaO1JfSEC9QIP5Xc(LiRcTVUWuth70DmPy(u"ࠩࡵ࡭࡬࡮ࡴࠨᇁ"),vvuP2MEINoUGtKT5,WuQdrqR9m1ZI0BN7pXiK,fprnld4CZo(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫᇂ"))
	return
def odE5wYAD0Pe(file):
	if file==PGIWHNLQuRoK1M: xINnzCFRWQK9PBEwb5caJ6 = iRoLg2m47tnDATBHGCSPNyx(u"ࠫ็๎วว็ࠣห้๋แืๆฬࠫᇃ")
	elif file==J2M15kw7Rdv0rQZxITaNuXeyWc: xINnzCFRWQK9PBEwb5caJ6 = hBvsQ7oCkKUdwjx58ml3EN(u"่่ࠬศศ่ࠤวิัࠡษ็ๅ๏ี๊้้สฮࠬᇄ")
	w0g6SxLJBqDUl9cNIE52VMkR = CCQOct8zmrKMuP6ZEkxq7oaf1BeRv(wRxoKs10Syj7V4edYhtP(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᇅ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠧๆีะࠫᇆ"),FnBiAjthS8MkXs67W(u"ࠨวุ่ฬำࠧᇇ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩัีําࠧᇈ"),zqdvcbP5L8BHh(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᇉ"),g4g6bfkPtVGU5lIM3(u"ࠫ์๊ࠠหำํำࠥหีๅษะࠤ๊๊แࠡࠩᇊ")+xINnzCFRWQK9PBEwb5caJ6+FvNyZqaLKw(u"ࠬࠦรๆࠢอี๏ีࠠๆีะࠤฬ๊ๅๅใࠣรࠬᇋ"))
	if w0g6SxLJBqDUl9cNIE52VMkR==UTelCo0ihE1d5R(u"࠶ᘐ"):
		if WpgZTyqoMAPhwGiXF.path.exists(file):
			try: WpgZTyqoMAPhwGiXF.remove(file)
			except: pass
		aHKzv76JCVnprbY8w(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠭ࠧᇌ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࠨᇍ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᇎ"),p72fnFtcPix5UKwr9YNzW(u"ࠩอ้๋ࠥำฮ่่ࠢๆࠦࠧᇏ")+xINnzCFRWQK9PBEwb5caJ6)
	elif w0g6SxLJBqDUl9cNIE52VMkR==zqdvcbP5L8BHh(u"࠱ᘑ"):
		data = iiZBqA90yC(file)
		aHKzv76JCVnprbY8w(fprnld4CZo(u"ࠪࠫᇐ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫࠬᇑ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᇒ"),fprnld4CZo(u"࠭สๆࠢศู้ออࠡ็็ๅࠥ࠭ᇓ")+xINnzCFRWQK9PBEwb5caJ6)
	return
def XdBvx93YjAGHzSCOFPp():
	if yMvF9GoTjhU5biA<zqdvcbP5L8BHh(u"࠲࠺ᘒ"):
		LpdKxnIsY3Sy6qP = p72fnFtcPix5UKwr9YNzW(u"ࠧๅๆฦืๆࠦร็ฬࠣฮุะฮะ็ࠣษฺีวาࠢๆ์ิ๐ࠠใัํ้ࠥืโๆࠢࠪᇔ")+str(yMvF9GoTjhU5biA)+UTelCo0ihE1d5R(u"ࠨ๋่ࠢ์ึวࠡษ็ๆํอฦๆࠢส่๊฻่าห่ࠣฬࠦสฺ็็ࠤ฾์ฯไࠢ࠱ࠤ์ึ็ࠡษ็้๏ุษࠡฬ่็๋้ࠠๆ่ࠣีษ๐ษࠡไ๋หห๋ࠠศๆไ๎ิ๐่่ษอࠤๆ๐ࠠษำ้ห๊าฺࠠ็สำࠥฮิไๆูࠣํืࠠษั็ห๋ࠥๆࠡษ็็ฯอศสࠢ࠱ࠤ้หีๅษะࠤฬ๊ๅีๅ็อ่ࠥๅࠡสอัิ๐หࠡสิ๊ฬ๋ฬࠡๅ๋ำ๏ࠦลๅ๋ࠣษ๏ࠦลึัสีࠥืโๆ้ࠣว฾๊้ࠡ็้ࠤ࠶࠾࠮࠱ࠩᇕ")
		aHKzv76JCVnprbY8w(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩࠪᇖ"),Me28A1sBLNIgUp5YCDyvT(u"ࠪࠫᇗ"),E6MIKdpBomef(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᇘ"),LpdKxnIsY3Sy6qP)
		return
	Rbnv9164DBGdE = cEZpW924rqNYm5.executeJSONRPC(hBvsQ7oCkKUdwjx58ml3EN(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨᇙ"))
	YEROUgQ5Gkj1 = AwsCLr4K3zH1P6tg5cYxQJB7doFm([bUdr5Hahw6sY8xJ(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬᇚ")])
	CUjgrXvYcl71xbIV5TWkzfBonD,IMbyUXvoVhtNisZOmcGwTAL56g2R,LsCN1IjMaBuHe3U,I9IFHKb6nMrByTxRhJLWPdG2pfkX,GGkOI2rHDlgwcLvSTmob3QZV,e4uGRIEMXzLn7diVsQxOhZwv,eelTrkDfR8YVm = YEROUgQ5Gkj1[bUdr5Hahw6sY8xJ(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ᇛ")]
	if CUjgrXvYcl71xbIV5TWkzfBonD or hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧᇜ") not in str(Rbnv9164DBGdE):
		aHKzv76JCVnprbY8w(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩࠪᇝ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠪࠫᇞ"),FvNyZqaLKw(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᇟ"),FnBiAjthS8MkXs67W(u"ࠬอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠห฻่่ࠥ็โุ่ࠢ฽ࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤ์ึ็ࠡษ็ๆํอฦๆࠢอ้่์ใࠡ็้ࠤึส๊สࠢๅ์ฬฬๅࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศีๅ็ࠤฺ๎ัࠡสา่ฬࠦๅ็ࠢส่่ะวษหࠪᇠ"))
		Tr8iRxJmbcEhftU5DSHzA = wadYxypc8umjFENRvq0r(g4g6bfkPtVGU5lIM3(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬᇡ"),Cu1704YofAbr3QTm(u"ࡗࡶࡺ࡫ᚒ"))
		if not Tr8iRxJmbcEhftU5DSHzA: return
	cXkCR4jw3qv6(lc0dpSmwoPDjLnk(u"ࡘࡷࡻࡥᚓ"))
	return
def cXkCR4jw3qv6(showDialogs=QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࡙ࡸࡵࡦᚔ")):
	Rbnv9164DBGdE = cEZpW924rqNYm5.executeJSONRPC(wRxoKs10Syj7V4edYhtP(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪᇢ"))
	if Me28A1sBLNIgUp5YCDyvT(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧᇣ") not in str(Rbnv9164DBGdE):
		if showDialogs:
			aHKzv76JCVnprbY8w(XzrqbGDIy54juixkMA(u"ࠩࠪᇤ"),dshJSmRqeiP9nap2(u"ࠪࠫᇥ"),FvNyZqaLKw(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᇦ"),p72fnFtcPix5UKwr9YNzW(u"๊ࠬไฤีไࠤัํวำๅ่ࠣฬ๊ࠦิฬัำ๊ࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠲ࠥอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠห฻่่ࠥ็โุ่ࠢ฽ࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤ์ึ็ࠡษ็ๆํอฦๆࠢอ้่์ใࠡ็้ࠤึส๊สࠢๅ์ฬฬๅࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศีๅ็ࠤฺ๎ัࠡสา่ฬࠦๅ็ࠢส่่ะวษหࠪᇧ"))
		return
	C3u7N6ew1Ysp8gFIX = WpgZTyqoMAPhwGiXF.path.join(mjaho7R5dY6eg,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭ࡡࡥࡦࡲࡲࡸ࠭ᇨ"),p72fnFtcPix5UKwr9YNzW(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ᇩ"),g4g6bfkPtVGU5lIM3(u"ࠨ࠹࠵࠴ࡵ࠭ᇪ"),Me28A1sBLNIgUp5YCDyvT(u"ࠩࡐࡽ࡛࡯ࡤࡦࡱࡑࡥࡻ࠴ࡸ࡮࡮ࠪᇫ"))
	if not WpgZTyqoMAPhwGiXF.path.exists(C3u7N6ew1Ysp8gFIX): return
	aeYlBOMguvy = open(C3u7N6ew1Ysp8gFIX,FnBiAjthS8MkXs67W(u"ࠪࡶࡧ࠭ᇬ")).read()
	if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: aeYlBOMguvy = aeYlBOMguvy.decode(iRoLg2m47tnDATBHGCSPNyx(u"ࠫࡺࡺࡦ࠹ࠩᇭ"))
	mFTE19S6QZ = GGvHJKP9LUxEk10Fw.findall(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠬࡂࡶࡪࡧࡺࡷࡃ࠮࡜ࡥ࠭࠯ࡠࡩ࠱ࠬ࡝ࡦ࠮࠭࠱࠮࠮ࠫࡁࠬࡀ࠴ࡼࡩࡦࡹࡶࡂࠬᇮ"),aeYlBOMguvy,GGvHJKP9LUxEk10Fw.DOTALL)
	VbGS5nx6H7mTw8CW,jUAdrmnQstq3COD = mFTE19S6QZ[fprnld4CZo(u"࠲ᘓ")]
	Ke5MQ9TGvJmloykVXxZzh3c2A7 = QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭࠼ࡷ࡫ࡨࡻࡸࡄࠧᇯ")+VbGS5nx6H7mTw8CW+wRxoKs10Syj7V4edYhtP(u"ࠧ࠭ࠩᇰ")+jUAdrmnQstq3COD+S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠨ࠾࠲ࡺ࡮࡫ࡷࡴࡀࠪᇱ")
	if showDialogs:
		tGRNDnYQIcU7J = cEZpW924rqNYm5.getInfoLabel(SO94xq1RAkMm2uF(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡜ࡩࡦࡹࡰࡳࡩ࡫ࠧᇲ"))
		if tGRNDnYQIcU7J==g4g6bfkPtVGU5lIM3(u"ࠪࡉࡒࡇࡄࠡࡎ࡬ࡷࡹ࠭ᇳ"): a05jnRr3dgyslHwzK814XGQCiYIbp = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠫ็๎วว็ࠣห้้สศสฬࠫᇴ")
		elif tGRNDnYQIcU7J==xW2Arao7YVOemw(u"ࠬࡋࡍࡂࡆࠣࡋࡦࡲ࡬ࡦࡴࡼࠫᇵ"): a05jnRr3dgyslHwzK814XGQCiYIbp = FvNyZqaLKw(u"࠭โ้ษษ้ࠥอไึ๊ิࠫᇶ")
		else: a05jnRr3dgyslHwzK814XGQCiYIbp = FnBiAjthS8MkXs67W(u"ࠧใ๊สส๊ࠦรฯำ์ࠫᇷ")
		w0g6SxLJBqDUl9cNIE52VMkR = CCQOct8zmrKMuP6ZEkxq7oaf1BeRv(xW2Arao7YVOemw(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᇸ"),iRoLg2m47tnDATBHGCSPNyx(u"ࠩๅ์ฬฬๅࠡลัี๎࠭ᇹ"),LiRcTVUWuth70DmPy(u"ࠪๆํอฦๆࠢส่่ะวษหࠪᇺ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠫ็๎วว็ࠣห้฻่าࠩᇻ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠬอๆหࠢะห้๐วࠡฬึฮำีๅࠡࠩᇼ")+a05jnRr3dgyslHwzK814XGQCiYIbp,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ว็ฬࠣห้ศๆࠡฬึฮำีๅࠡษ็ษฺีวาࠢส่ศิ๊าࠢ็ะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠯๋๋ࠢีอࠠๆ฻้ห์ࠦว็ๅࠣฮุะื๋฻ࠣหุะฮะษ่ࠤฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦศะๆสࠤ๊์ࠠใ๊สส๊ࠦวๅๅอหอฯࠠ࠯๋ࠢว๏฼วࠡฬึฮ฼๐ูࠡวํๆฬ็็ศࠢไ๎ࠥษ๊๊ࠡๅฮࠥะิศรࠣࡠࡳࡢ࡮ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠤศิสาࠢส่ว์ࠠ็๊฼ࠤฬ๊โ้ษษ้ࠥอไห์ࠣฮึ๐ฯࠡลึฮำีวๆ้สࠤฤ࡛ࠧ࠰ࡅࡒࡐࡔࡘ࡝ࠨᇽ"))
		if w0g6SxLJBqDUl9cNIE52VMkR==kEhAHvti6Vnsfx(u"࠴ᘔ"): q3UY2D4JaP9dTkznKoj = XzrqbGDIy54juixkMA(u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪᇾ")
		elif w0g6SxLJBqDUl9cNIE52VMkR==FvNyZqaLKw(u"࠶ᘕ"): q3UY2D4JaP9dTkznKoj = iRoLg2m47tnDATBHGCSPNyx(u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧᇿ")
		else: q3UY2D4JaP9dTkznKoj = hBvsQ7oCkKUdwjx58ml3EN(u"ࠩࠪሀ")
	else:
		tGRNDnYQIcU7J = jHevARrF7lS.getSetting(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪࡥࡻ࠴࡭ࡺࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨሁ"))
		if   tGRNDnYQIcU7J==QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫࠬሂ"): w0g6SxLJBqDUl9cNIE52VMkR = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠵ᘖ")
		elif tGRNDnYQIcU7J==pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬࡋࡍࡂࡆࠣࡐ࡮ࡹࡴࠨሃ"): w0g6SxLJBqDUl9cNIE52VMkR = iUeoLOsbHqP(u"࠷ᘗ")
		elif tGRNDnYQIcU7J==bUdr5Hahw6sY8xJ(u"࠭ࡅࡎࡃࡇࠤࡌࡧ࡬࡭ࡧࡵࡽࠬሄ"): w0g6SxLJBqDUl9cNIE52VMkR = UTelCo0ihE1d5R(u"࠲ᘘ")
		q3UY2D4JaP9dTkznKoj = tGRNDnYQIcU7J
	if   w0g6SxLJBqDUl9cNIE52VMkR==UTelCo0ihE1d5R(u"࠱ᘙ"): PShHxEpyOJDl = Me28A1sBLNIgUp5YCDyvT(u"ࠧ࠶࠷࠯࠹࠹࠺ࠬ࠶࠷࠸ࠫህ")
	elif w0g6SxLJBqDUl9cNIE52VMkR==Me28A1sBLNIgUp5YCDyvT(u"࠳ᘚ"): PShHxEpyOJDl = FnBiAjthS8MkXs67W(u"ࠨ࠷࠷࠸࠱࠻࠵࠶࠮࠸࠹ࠬሆ")
	elif w0g6SxLJBqDUl9cNIE52VMkR==UTelCo0ihE1d5R(u"࠵ᘛ"): PShHxEpyOJDl = UTelCo0ihE1d5R(u"ࠩ࠸࠹࠺࠲࠵࠶࠮࠸࠸࠹࠭ሇ")
	else: return
	jHevARrF7lS.setSetting(fprnld4CZo(u"ࠪࡥࡻ࠴࡭ࡺࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨለ"),q3UY2D4JaP9dTkznKoj)
	x4cNutXLdrSq9O = SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࡁࡼࡩࡦࡹࡶࡂࠬሉ")+PShHxEpyOJDl+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬ࠲ࠧሊ")+jUAdrmnQstq3COD+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭࠼࠰ࡸ࡬ࡩࡼࡹ࠾ࠨላ")
	jkum9pHGXvV1TB03Z6ULaAiMJyFKrf = aeYlBOMguvy.replace(Ke5MQ9TGvJmloykVXxZzh3c2A7,x4cNutXLdrSq9O)
	if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: jkum9pHGXvV1TB03Z6ULaAiMJyFKrf = jkum9pHGXvV1TB03Z6ULaAiMJyFKrf.encode(fprnld4CZo(u"ࠧࡶࡶࡩ࠼ࠬሌ"))
	open(C3u7N6ew1Ysp8gFIX,S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠨࡹࡥࠫል")).write(jkum9pHGXvV1TB03Z6ULaAiMJyFKrf)
	LOHZ4o9m7p6ebfTYXGIdz5PWs3q(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩሎ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪ࠲ࠥࠦࡓ࡬࡫ࡱࠤࡉ࡫ࡦࡢࡷ࡯ࡸࠥ࡜ࡩࡦࡹࡶ࠾ࠥࡡࠠࠨሏ")+PShHxEpyOJDl+dshJSmRqeiP9nap2(u"ࠫࠥࡣࠧሐ"))
	if showDialogs: cEZpW924rqNYm5.executebuiltin(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬࡘࡥ࡭ࡱࡤࡨࡘࡱࡩ࡯ࠪࠬࠫሑ"))
	return
def yyaW5PZg19QHTz7VMpL():
	o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭ࠧሒ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠧࠨሓ"),FvNyZqaLKw(u"ࠨࠩሔ"),FnBiAjthS8MkXs67W(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬሕ"),E6MIKdpBomef(u"ࠪฬึ์วๆฮࠣ฽๊อฯࠡใํ๋๋ࠥิไๆฬࠤ฾์ฯไࠢ࠱࠲࠳ࠦลๆษࠣว้หีะษิࠤ็ี๊ๆࠢ࠱࠲࠳ࠦร้ࠢส๊ฯࠦๅๆ่๋฽๋ࠥๆࠡษึฮำีวๆࠢส่อืๆศ็ฯࠤ࠳࠴࠮ࠡล๋ࠤ้ี๊ไุ่่๊ࠢษࠡลัี๎ࠦสฯืࠣะ์อาไࠢฦ๊ฯ่ࠦๅษࠣฮำ฻ࠠษไํอࠥิไใࠢส่้ํࠠ࡝ࡰ࡟ࡲࠥำว้ๆࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤศ๎ࠠศฬุ่ࠥฮวๅ็หี๊าࠠๅ็฼ีๆฯࠠิสหࠤฬ๊ๅีๅ็อࠥ฿ๆะๅࠣ࠲࠳࠴่ࠠๆࠣฮึ๐ฯࠡใะูࠥอไหฯา๎ะอสࠡษ็ฦ๋ࠦฟࠨሖ"))
	if o07Z1tEB4n3ARCkVNu==YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠵ᘜ"): WrEwOCRSaplo7iy6ZDxIJ2teL0Tf(g4g6bfkPtVGU5lIM3(u"࡚ࡲࡶࡧᚕ"),g4g6bfkPtVGU5lIM3(u"࡚ࡲࡶࡧᚕ"))
	return
def vM2yUHSRn1IdthZl8rA4OLCc():
	aHKzv76JCVnprbY8w(Me28A1sBLNIgUp5YCDyvT(u"ࠫࠬሗ"),wRxoKs10Syj7V4edYhtP(u"ࠬ࠭መ"),SO94xq1RAkMm2uF(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩሙ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"่ࠧาสࠤฬ๊ๅ้ไ฼ࠤ๊เไใ่๊ࠢࠥอไๆืาีࠥ๎ฺ๋ำ้ࠣ฾ื่โ่ࠢฮ๏๊ࠦาฮ฼ࠤู้๊ๆๆࠪሚ"))
	return
def QJlFsfjgHWPyEOUd():
	Wu6THcbvsRZdXSz4nwlCVy = hBvsQ7oCkKUdwjx58ml3EN(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠฮ฾ีวะࠢื๎฾ฯࠠรๆ้ࠣา๋ฯࠡๆึ๊ฮࠦ࠲࠱࠴࠴ࠤ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨማ")
	Wu6THcbvsRZdXSz4nwlCVy += pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩส่๊๎โฺࠢฦำ๋อ็ࠡใํ๋ࠥหอึษษ๎ฮࠦไฺัาࠤฬ๊ิ๋฻ฬࠤๆ๐ࠠศๆ฼ห้๋ࠠห็ࠣะ๊฿็ศ่๊ࠢࠥาๅ๋฻ࠣห้๋ีศัิࠤฬ๊ๅห๊ไีฮࠦแ๋ࠢส่ส์สา่อࠤฬ๊โะ์่อࠥ๎วๅฮา๎ิฯࠠศๆะ็ํ๋๊ส๋ࠢห้เ๊าࠢะ็ํ๋๊ส๋้๋ࠢࠦฬๆ์฼ࠤิ๎ไࠡษ็฽ฬ๊ๅࠡอ่ࠤฯ๋ࠠห๊ะ๎ิํว๊ࠡะืฬฮࠠศๆ่฽ิ๊ࠠฮีหࠤุ้ว็ࠢา์้ࠦวๅ฻ส่๊ࠦไิ่ฬࠤ࠷࠶࠲࠲๋๋ࠢ๏ࠦวๅวะูฬฬ๊สࠢส่ศำฯฬ๋ࠢห้ษิๆๆࠣห้ะ๊ࠡฬ่ࠤ฾๋ไ่ษࠣๅ๏ࠦวๅี้์ฬะࠠศๆ฼ุึฯࠠศๆ่ห฻๐ษࠨሜ")
	Wu6THcbvsRZdXSz4nwlCVy += FvNyZqaLKw(u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࡩࡶࡷࡴࡸࡀ࠯࠰ࡶ࡬ࡲࡾ࠴ࡣࡤ࠱ࡶ࡬࡮ࡧࡣࡰࡷࡱࡸࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ም")
	bdzvPE1KBTfkMj04QAG5hY7ouqZD = SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣศา่ส้ัࠦิา์ฺࠤฬ๊ๅิๆ่ࠤ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨሞ")
	bdzvPE1KBTfkMj04QAG5hY7ouqZD += Cu1704YofAbr3QTm(u"ࠬํ่ࠡ฻หหึฯฺ่ࠠࠣฬึ์วๆฮࠣ๎ํ็ัࠡ็฼่ํ๋วหࠢะืฬฮ๊สࠢๆฯ๏ืษࠡฬ๊้ࠥาๅ๋฻ࠣห้๋ำๅ็ํ๊๋ࠥหๅࠢฦ์็อสࠡษ็ู้อษ๊ࠡฦ์็อสࠡษ็็ุ๎แ๊ࠡส่ำู่โุ๋่๊ࠢࠠศๆๅ้ึ่ࠦฤ๊ๅหฯࠦวๅไ่ีࠥ๎รุ๋สࠤ๏๎แาࠢิศ๏ฯࠠศๆ๊่ฬ๊ࠠโ์ࠣะ๊๐ูࠡั๋่ࠥอไฺษ็้ࠥ๎รุ๋สࠤๆ๐็ࠡฬๅ์๏๋ࠠๆ์็หิ๐้้ࠠฯี๏่ࠦโ์๊ࠤศ๐ึศࠢหัะ่ࠦใำสลฮࠦวๅไิฦ๋่ࠦฤ์ูหࠥ็๊่ࠢสืฯิวาหࠣ์ฯ็วลๆࠣ์ๆ๐็ࠡลๅ์ฬ๊ࠠๆ่ึ์อฯࠠๅๆฦ้ฬฺ๋ࠠๆํࠤํษๅ้ำࠣวำื้ࠡฬ๊้้ࠥไࠡ็ึ่๊ࠦ࠮ࠡษ็ฬึ์วๆฮ้่ࠣะ่ษࠢห่฿ฯࠠอษไหูࠥใาสอࠤํ๐ำหะา้ࠥ์ุศ็ࠣ์๏์ฯ้ิࠣฮาะࠠษ์ษอࠥ๎๊็ั๋ึ้ࠥวอ์อࠤํ๋ฮึืࠣๅ็฽ࠠๅลฯ๋ืฯࠠศๆ๋๎๋ี่ำࠢ࠱ࠤฬ๊ๅ้ไ฼ࠤฬ๊ัิ็ํࠤ้๊ศา่ส้ัࠦ็้ࠩሟ")
	bdzvPE1KBTfkMj04QAG5hY7ouqZD += pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹ࡯࡮ࡺ࠰ࡦࡧ࠴ࡳࡵࡴ࡮࡬ࡱࡷࡻ࡬ࡦࡴ࡞࠳ࡈࡕࡌࡐࡔࡠࠫሠ")
	LpdKxnIsY3Sy6qP = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧ࡜ࡔࡗࡐࡢ࠭ሡ")+Wu6THcbvsRZdXSz4nwlCVy+SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨ࡞ࡱࡠࡳࡢ࡮࡜ࡔࡗࡐࡢ࠭ሢ")+bdzvPE1KBTfkMj04QAG5hY7ouqZD
	d0tNlv4Lbu2pqDaO1JfSEC9QIP5Xc(iUeoLOsbHqP(u"ࠩࡵ࡭࡬࡮ࡴࠨሣ"),fprnld4CZo(u"ࠪࠫሤ"),LpdKxnIsY3Sy6qP)
	return
def JuKwpjEMF0O8sC(nXl0o4fesWvCbZ):
	o05ntqDmjf3OZBLgNlckQH(BXnrZSgERcxHvbVQ4)
	LysGAMozW185TVxl = AE8MedoFXQNrYhRvW(nXl0o4fesWvCbZ)
	id,exOIZnGECcR2p3WV4TPY06BNDo7,Tg1CAnZtj9MNe5wS,RuSqTgGZ7tlerwK9pWYf16Ln,tcopCZGnbdvY8r,reason = LysGAMozW185TVxl[iUeoLOsbHqP(u"࠵ᘝ")]
	uLrdWC8tUFHm52Sbo07I,vvuP2MEINoUGtKT5 = RuSqTgGZ7tlerwK9pWYf16Ln.split(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࡡࡴ࠻࠼ࠩሥ"))
	bdzvPE1KBTfkMj04QAG5hY7ouqZD,eFQXmOopl5Gfd,ZIGlKA0aOBfFuonWj = tcopCZGnbdvY8r.split(g4g6bfkPtVGU5lIM3(u"ࠬࡢ࡮࠼࠽ࠪሦ"))
	thU9b5jSInroGXgO = FnBiAjthS8MkXs67W(u"ࡔࡳࡷࡨᚖ")
	while thU9b5jSInroGXgO:
		nV3iN9hHcQ5ruYoMjt6w8041lRyTsd = CCQOct8zmrKMuP6ZEkxq7oaf1BeRv(hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࠧሧ"),zqdvcbP5L8BHh(u"ࠧฯำ๋ะࠬረ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨวิืฬ๊ࠠาีส่ฮࠦไๅ็หี๊าࠧሩ"),bUdr5Hahw6sY8xJ(u"ࠩๅหห๋ษࠡษ็ฮอืูศฬࠪሪ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"่ࠪส๐โศใࠣห้หูๅษ้หฯࠦ࠺ࠡࠢอฬึ฿ࠠฤ๊ࠣหู๊อࠡษ็ฬึ์วๆฮࠪራ"),bdzvPE1KBTfkMj04QAG5hY7ouqZD)
		if nV3iN9hHcQ5ruYoMjt6w8041lRyTsd==hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠸ᘞ"): gARlZTuSP5BN = CCQOct8zmrKMuP6ZEkxq7oaf1BeRv(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫࠬሬ"),kEhAHvti6Vnsfx(u"ࠬ࠭ር"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ู้࠭ัฬࠫሮ"),wRxoKs10Syj7V4edYhtP(u"ࠧࠨሯ"),LiRcTVUWuth70DmPy(u"ࠨ็หำศࠦวๅฬหี฾ฺ๋ࠦำࠣๆฬฮไࠡๆ็๊็อิࠨሰ"),eFQXmOopl5Gfd,UTelCo0ihE1d5R(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡷࡲࡧ࡬࡭ࡨࡲࡲࡹ࠭ሱ"))
		elif nV3iN9hHcQ5ruYoMjt6w8041lRyTsd==hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠱ᘟ"): eimszEapSbIurqvN3c5hk4VylDCH()
		else: thU9b5jSInroGXgO = g4g6bfkPtVGU5lIM3(u"ࡇࡣ࡯ࡷࡪᚗ")
	cEZpW924rqNYm5.executebuiltin(LiRcTVUWuth70DmPy(u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧሲ"))
	return
def wwVGpkZzinfRcTLKYF8eOW(showDialogs):
	o07Z1tEB4n3ARCkVNu = zqdvcbP5L8BHh(u"ࡖࡵࡹࡪᚘ")
	if showDialogs: o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(XzrqbGDIy54juixkMA(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫሳ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬ࠭ሴ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࠧስ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠧิฦส่ࠬሶ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨ้็ࠤศ์สࠡ็อว่ี้ࠠฬิ๎ิࠦๅิฯࠣ์ฯ฻แ๋ำࠣะ๊๐ูࠡว฼ำฬีวหࠢหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ࠴ࠠฮ์ฮࠤฯ฿่ะࠢฯ้๏฿ࠠศๆศ฽ิอฯศฬࠣษ้๏ุ้ࠠ฼๎ฮࠦสฬสํฮࠥอไษำ้ห๊าࠠภࠩሷ"))
	if o07Z1tEB4n3ARCkVNu:
		Tr8iRxJmbcEhftU5DSHzA = S4SOKF2QbBhjCd3RrVMuHIzE(u"ࡗࡶࡺ࡫ᚙ")
		if WpgZTyqoMAPhwGiXF.path.exists(EIAamxotvSk7BR6QM):
			try: WpgZTyqoMAPhwGiXF.remove(EIAamxotvSk7BR6QM)
			except: Tr8iRxJmbcEhftU5DSHzA = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࡊࡦࡲࡳࡦᚚ")
		if showDialogs:
			if Tr8iRxJmbcEhftU5DSHzA: aHKzv76JCVnprbY8w(hBvsQ7oCkKUdwjx58ml3EN(u"ࠩࠪሸ"),zqdvcbP5L8BHh(u"ࠪࠫሹ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࠬሺ"),LiRcTVUWuth70DmPy(u"ࠬะๅࠡส้ะฬำࠠๆีะࠤํะีโ์ิࠤ๊๊แࠡว฼ำฬีวหࠢหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠬሻ"))
			else: aHKzv76JCVnprbY8w(fprnld4CZo(u"࠭ࠧሼ"),UTelCo0ihE1d5R(u"ࠧࠨሽ"),bUdr5Hahw6sY8xJ(u"ࠨࠩሾ"),zqdvcbP5L8BHh(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอ๋ࠥำฮ่่ࠢๆࠦวๅว฼ำฬีวหࠩሿ"))
	return
def e6e7BfQyCUrcqjJD():
	JEwT6SyBWQnl()
	UqFQ9kRNcbgZam = jHevARrF7lS.getSetting(E6MIKdpBomef(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡨࡵࡶࡳࡧࡦࡩࡨࡦࠩቀ"))
	LpdKxnIsY3Sy6qP = {}
	LpdKxnIsY3Sy6qP[l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫࡆ࡛ࡔࡐࠩቁ")] = xW2Arao7YVOemw(u"ࠬอไไษืࠤฬ๊สๅไสส๏ฺ๊ࠦ็็ࠫቂ")
	LpdKxnIsY3Sy6qP[pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭ࡓࡕࡑࡓࠫቃ")] = S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠧศๆๆหูࠦๅห๊ๅๅࠥะๅศ็สࠤํฮวๅๅส้้࠭ቄ")
	LpdKxnIsY3Sy6qP[XzrqbGDIy54juixkMA(u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩቅ")] = zqdvcbP5L8BHh(u"ࠩๆหูࠦฬะษࠣๆฺ๐ัࠡษ็้ิ๏ࠠ࠯ࠢࠪቆ")+str(BBDQiGNydYaPqxEv/SO94xq1RAkMm2uF(u"࠷࠲ᘠ"))+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠪࠤิ่๊ใหࠣๅ็฽ࠧቇ")
	hwkAVu6qUjSY0m2 = LpdKxnIsY3Sy6qP[UqFQ9kRNcbgZam]
	w0g6SxLJBqDUl9cNIE52VMkR = CCQOct8zmrKMuP6ZEkxq7oaf1BeRv(p72fnFtcPix5UKwr9YNzW(u"ࠫࠬቈ"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"้ࠬวีࠢࠪ቉")+str(BBDQiGNydYaPqxEv/SO94xq1RAkMm2uF(u"࠸࠳ᘡ"))+p72fnFtcPix5UKwr9YNzW(u"࠭ࠠะไํๆฮ࠭ቊ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠧหึ฽๎้ࠦสๅไสส๏࠭ቋ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨวํๆฬ็ࠠไษ่่ࠬቌ"),hwkAVu6qUjSY0m2,g4g6bfkPtVGU5lIM3(u"๊่ࠩࠥะั๋ัࠣหุะฮะษ่ࠤฬ๊ใศึࠣห้ึใ๋ࠢส่ฯ๊โศศํࠤศ๋ࠠหำํำࠥห๊ใษไࠤฬ๊ใศึࠣฬฬ๊ใศ็็ࠤศ๋ࠠหำํำ้ࠥวีࠢ฼้ึํࠠใืํีࠥาฯศࠢยࠥࠬቍ"))
	if w0g6SxLJBqDUl9cNIE52VMkR==SO94xq1RAkMm2uF(u"࠳ᘢ"): yyeYHA4ctKTUmJn = Cu1704YofAbr3QTm(u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫ቎")
	elif w0g6SxLJBqDUl9cNIE52VMkR==S4SOKF2QbBhjCd3RrVMuHIzE(u"࠵ᘣ"): yyeYHA4ctKTUmJn = lc0dpSmwoPDjLnk(u"ࠫࡆ࡛ࡔࡐࠩ቏")
	elif w0g6SxLJBqDUl9cNIE52VMkR==wRxoKs10Syj7V4edYhtP(u"࠷ᘤ"): yyeYHA4ctKTUmJn = XzrqbGDIy54juixkMA(u"࡙ࠬࡔࡐࡒࠪቐ")
	else: yyeYHA4ctKTUmJn = YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ࠧቑ")
	if yyeYHA4ctKTUmJn:
		jHevARrF7lS.setSetting(xW2Arao7YVOemw(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱࡬ࡹࡺࡰࡤࡣࡦ࡬ࡪ࠭ቒ"),yyeYHA4ctKTUmJn)
		yLinKSMUbvJmPZ2cq = LpdKxnIsY3Sy6qP[yyeYHA4ctKTUmJn]
		aHKzv76JCVnprbY8w(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠨࠩቓ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩࠪቔ"),XzrqbGDIy54juixkMA(u"ࠪࠫቕ"),yLinKSMUbvJmPZ2cq)
	return
def B74SXWm68Hb5sQR():
	LpdKxnIsY3Sy6qP = {}
	LpdKxnIsY3Sy6qP[Me28A1sBLNIgUp5YCDyvT(u"ࠫࡆ࡛ࡔࡐࠩቖ")] = SO94xq1RAkMm2uF(u"ู๊ࠬาใิࠤࡉࡔࡓࠡษ็ฮ้่วว์ࠣ๎฾๋ไ࠻ࠢࠪ቗")
	LpdKxnIsY3Sy6qP[SO94xq1RAkMm2uF(u"࠭ࡁࡔࡍࠪቘ")] = QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧิ์ิๅึࠦࡄࡏࡕࠣื๏฿ๅๅࠢห฽ิࠦวๅี่หาࠦไ่࠼ࠣࠫ቙")
	LpdKxnIsY3Sy6qP[l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨࡕࡗࡓࡕ࠭ቚ")] = UTelCo0ihE1d5R(u"ࠩึ๎ึ็ัࠡࡆࡑࡗ๋ࠥส้ไไࠤฯ๋วๆษࠣ์ออไไษ่่ࠬቛ")
	sjxuH1JGqO6rZXgolE82cevAkpBwY = jHevARrF7lS.getSetting(Me28A1sBLNIgUp5YCDyvT(u"ࠪࡥࡻ࠴ࡤ࡯ࡵࠪቜ"))
	UqFQ9kRNcbgZam = jHevARrF7lS.getSetting(g4g6bfkPtVGU5lIM3(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧቝ"))
	hwkAVu6qUjSY0m2 = LpdKxnIsY3Sy6qP[UqFQ9kRNcbgZam]+sjxuH1JGqO6rZXgolE82cevAkpBwY
	w0g6SxLJBqDUl9cNIE52VMkR = CCQOct8zmrKMuP6ZEkxq7oaf1BeRv(FnBiAjthS8MkXs67W(u"ࠬ࠭቞"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭สี฼ํ่ࠥ฿ๆะࠢส่๊๎วโไฬࠫ቟"),xW2Arao7YVOemw(u"ࠧหึ฽๎้ࠦสๅไสส๏࠭በ"),SO94xq1RAkMm2uF(u"ࠨวํๆฬ็ࠠไษ่่ࠬቡ"),hwkAVu6qUjSY0m2,lc0dpSmwoPDjLnk(u"ࠩึ๎ึ็ัࠡࡆࡑࡗࠥํ่ࠡฮ๊หืࠦแ๋ࠢส่ส์สา่ํฮࠥ๐โ้็ࠣฬฯำ่๋ๆࠣวุ๋วยࠢส่๊๎วใ฻ࠣ์ฬ๊ำ๋ำไีฬะࠠฦๆ์ࠤศืโศ็ࠣ์฾์ฯࠡส฼ฺࠥอไ็ษึࠤ๏่่ๆࠢหััฮ้ࠠ็้฽ࠥ๎อืำࠣฬ฾฼ࠠศๆ่์ฬู่ࠡ࠰่ࠣฯฺฺ๋ๆࠣื๏ืแาࠢࡇࡒࡘࠦโๆࠢหหำะ๊ศำࠣหู้๊าใิࠤฬ๊ๅ็ษึฬࠥษ่ࠡไ่ࠤอห๊ใษไ๋ࠥฮวๅๅส้้࠭ቢ"))
	if w0g6SxLJBqDUl9cNIE52VMkR==G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠶ᘥ"): yyeYHA4ctKTUmJn = LiRcTVUWuth70DmPy(u"ࠪࡅࡘࡑࠧባ")
	elif w0g6SxLJBqDUl9cNIE52VMkR==l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠱ᘦ"): yyeYHA4ctKTUmJn = fprnld4CZo(u"ࠫࡆ࡛ࡔࡐࠩቤ")
	elif w0g6SxLJBqDUl9cNIE52VMkR==oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠳ᘧ"): yyeYHA4ctKTUmJn = oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࡙ࠬࡔࡐࡒࠪብ")
	if w0g6SxLJBqDUl9cNIE52VMkR in [XzrqbGDIy54juixkMA(u"࠳ᘩ"),fprnld4CZo(u"࠳ᘨ")]:
		o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(Me28A1sBLNIgUp5YCDyvT(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ቦ"),LiRcTVUWuth70DmPy(u"ࠧิ์ิๅึࡀࠠࠨቧ")+vNFPbXVJ7pmyWLen[E6MIKdpBomef(u"࠵ᘪ")],SO94xq1RAkMm2uF(u"ࠨีํีๆื࠺ࠡࠩቨ")+vNFPbXVJ7pmyWLen[l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠵ᘫ")],kEhAHvti6Vnsfx(u"ࠩࠪቩ"),Cu1704YofAbr3QTm(u"ࠪวำะวาࠢึ๎ึ็ัࠡࡆࡑࡗࠥอไๆ่สือࠦไไࠩቪ"))
		if o07Z1tEB4n3ARCkVNu==SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠷ᘬ"): hpRtseuJbF3cZfvQ5LD4Bkl = vNFPbXVJ7pmyWLen[yA5z6LIXBlo41PRVMY87wOisFp(u"࠰ᘭ")]
		else: hpRtseuJbF3cZfvQ5LD4Bkl = vNFPbXVJ7pmyWLen[xW2Arao7YVOemw(u"࠲ᘮ")]
	elif w0g6SxLJBqDUl9cNIE52VMkR==SO94xq1RAkMm2uF(u"࠴ᘯ"): hpRtseuJbF3cZfvQ5LD4Bkl = SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࠬቫ")
	else: yyeYHA4ctKTUmJn = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬ࠭ቬ")
	if yyeYHA4ctKTUmJn:
		jHevARrF7lS.setSetting(hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩቭ"),yyeYHA4ctKTUmJn)
		jHevARrF7lS.setSetting(Me28A1sBLNIgUp5YCDyvT(u"ࠧࡢࡸ࠱ࡨࡳࡹࠧቮ"),hpRtseuJbF3cZfvQ5LD4Bkl)
		yLinKSMUbvJmPZ2cq = LpdKxnIsY3Sy6qP[yyeYHA4ctKTUmJn]+hpRtseuJbF3cZfvQ5LD4Bkl
		aHKzv76JCVnprbY8w(Me28A1sBLNIgUp5YCDyvT(u"ࠨࠩቯ"),FnBiAjthS8MkXs67W(u"ࠩࠪተ"),kEhAHvti6Vnsfx(u"ࠪࠫቱ"),yLinKSMUbvJmPZ2cq)
	return
def cxsSYuvBHL():
	UqFQ9kRNcbgZam = jHevARrF7lS.getSetting(FvNyZqaLKw(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩቲ"))
	LpdKxnIsY3Sy6qP = {}
	LpdKxnIsY3Sy6qP[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠬࡇࡕࡕࡑࠪታ")] = hBvsQ7oCkKUdwjx58ml3EN(u"࠭วๅสิ์ู่๊ࠡษ็ฮ้่วว์ࠣะฬําࠡๆ็฽๊๊ࠧቴ")
	LpdKxnIsY3Sy6qP[oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧࡂࡕࡎࠫት")] = E6MIKdpBomef(u"ࠨษ็ฬึ๎ใิ์ࠣื๏฿ๅๅࠢห฽ิࠦวๅี่หาࠦไ่ࠩቶ")
	LpdKxnIsY3Sy6qP[UTelCo0ihE1d5R(u"ࠩࡖࡘࡔࡖࠧቷ")] = FnBiAjthS8MkXs67W(u"ࠪห้ฮั้ๅึ๎๋ࠥส้ไไࠤฯ๋วๆษࠣ์ออไไษ่่ࠬቸ")
	hwkAVu6qUjSY0m2 = LpdKxnIsY3Sy6qP[UqFQ9kRNcbgZam]
	w0g6SxLJBqDUl9cNIE52VMkR = CCQOct8zmrKMuP6ZEkxq7oaf1BeRv(Me28A1sBLNIgUp5YCDyvT(u"ࠫࠬቹ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠬะิ฻์็ࠤ฾์ฯࠡษ็้ํอแใหࠪቺ"),sTcr7iDp5eFt4RoLMhuwq1A(u"࠭สี฼ํ่ࠥะไใษษ๎ࠬቻ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧฦ์ๅหๆࠦใศ็็ࠫቼ"),hwkAVu6qUjSY0m2,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨษ็ฬึ๎ใิ์๋ࠣํࠦฬ่ษีࠤๆ๐ࠠศๆศ๊ฯืๆ๋ฬࠣ๎฾๋ไ๊ࠡึ๎฼ࠦศ๋่ࠣะ์อาไ๋ࠢห้หๆหำ้๎ฯࠦ࠮้๋ࠡࠤ๏ูสๅ็ࠣ฻้ฮวหๅࠣ์๏่่ๆࠢหืาฮ็ศࠢหำ้อࠠๆ่ๆࠤะ๋๋ࠠส฼ฯ์อࠠๅๅࠣ࠲ࠥํไࠡฬิ๎ิࠦสี฼ํ่ࠥษๅࠡวํๆฬ็ࠠศๆหีํ้ำ๋ࠢยࠫች"))
	if w0g6SxLJBqDUl9cNIE52VMkR==l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠳ᘰ"): yyeYHA4ctKTUmJn = p72fnFtcPix5UKwr9YNzW(u"ࠩࡄࡗࡐ࠭ቾ")
	elif w0g6SxLJBqDUl9cNIE52VMkR==SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠵ᘱ"): yyeYHA4ctKTUmJn = SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪࡅ࡚࡚ࡏࠨቿ")
	elif w0g6SxLJBqDUl9cNIE52VMkR==zqdvcbP5L8BHh(u"࠷ᘲ"): yyeYHA4ctKTUmJn = bUdr5Hahw6sY8xJ(u"ࠫࡘ࡚ࡏࡑࠩኀ")
	else: yyeYHA4ctKTUmJn = FvNyZqaLKw(u"ࠬ࠭ኁ")
	if yyeYHA4ctKTUmJn:
		jHevARrF7lS.setSetting(yA5z6LIXBlo41PRVMY87wOisFp(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫኂ"),yyeYHA4ctKTUmJn)
		yLinKSMUbvJmPZ2cq = LpdKxnIsY3Sy6qP[yyeYHA4ctKTUmJn]
		aHKzv76JCVnprbY8w(Me28A1sBLNIgUp5YCDyvT(u"ࠧࠨኃ"),kEhAHvti6Vnsfx(u"ࠨࠩኄ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠩࠪኅ"),yLinKSMUbvJmPZ2cq)
	return
def IfsoKtyn7iarS1cCGB83bYPAzFZQUO():
	JJTGFKEhWHfvNoA3trdlu7mZw = jHevARrF7lS.getSetting(E6MIKdpBomef(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡨࡧࡣࡩࡧࠪኆ"))
	if JJTGFKEhWHfvNoA3trdlu7mZw==SO94xq1RAkMm2uF(u"ࠫࡘ࡚ࡏࡑࠩኇ"): header = oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠬะฮำ์้ࠤฬ๊โ้ษษ้๋ࠥส้ไไࠫኈ")
	else: header = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭สฯิํ๊ࠥอไใ๊สส๊ࠦๅโ฻็ࠫ኉")
	o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(LiRcTVUWuth70DmPy(u"ࠧࠨኊ"),zqdvcbP5L8BHh(u"ࠨวํๆฬ็ࠧኋ"),zqdvcbP5L8BHh(u"ࠩอๅ฾๐ไࠨኌ"),header,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠪๆํอฦๆࠢส่อืๆศ็ฯࠤ๏ะๅࠡฬะำ๏ั็ศࠢฦ์ฯ๎ๅศฬํ็๏อࠠษ฻าࠤ࠶࠼ࠠิษ฼อ๋ࠥๆࠡล๋่ࠥษำหะาห๊ࠦ࠮࠯๋ࠢษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠢํศิ๐ࠠฦๆ์ࠤฯำฯ๋อ๊หࠥ็๊ࠡๅ็ࠤ๊ืษࠡ์อ้ࠥอำหะาห๊ࠦวๅไ๋หห๋ࠠ࠯࠰ࠣ์์ึวࠡ์ึฬอࠦศุศࠣๅ๏ࠦแหฯࠣๆํอฦๆࠢส่อืๆศ็ฯࡠࡳࡢ࡮้ࠡ็ࠤฯื๊ะࠢอๅ฾๐ไࠡล่ࠤส๐โศใࠣฮำุ๊็ࠢส่็๎วว็ࠣรࠦࠧࠧኍ"))
	if o07Z1tEB4n3ARCkVNu==-kEhAHvti6Vnsfx(u"࠷ᘳ"): return
	elif o07Z1tEB4n3ARCkVNu:
		jHevARrF7lS.setSetting(LiRcTVUWuth70DmPy(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡱࡹࡸࡩࡡࡤࡪࡨࠫ኎"),E6MIKdpBomef(u"ࠬࡇࡕࡕࡑࠪ኏"))
		aHKzv76JCVnprbY8w(iRoLg2m47tnDATBHGCSPNyx(u"࠭ࠧነ"),LiRcTVUWuth70DmPy(u"ࠧࠨኑ"),dshJSmRqeiP9nap2(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫኒ"),Cu1704YofAbr3QTm(u"ࠩอ้ࠥะแฺ์็ࠤฯิา๋่ࠣห้่่ศศ่ࠫና"))
	else:
		jHevARrF7lS.setSetting(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡨࡧࡣࡩࡧࠪኔ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠫࡘ࡚ࡏࡑࠩን"))
		aHKzv76JCVnprbY8w(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬ࠭ኖ"),p72fnFtcPix5UKwr9YNzW(u"࠭ࠧኗ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪኘ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨฬ่ࠤส๐โศใࠣฮำุ๊็ࠢส่็๎วว็ࠪኙ"))
	return
def D1HpItnzANhSreR5lOfCx3(MMupPCxqkenwt6FlsbRILV37EAmB):
	if MMupPCxqkenwt6FlsbRILV37EAmB!=yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩࠪኚ"):
		MMupPCxqkenwt6FlsbRILV37EAmB = e2N6JK0pzXdA4By(MMupPCxqkenwt6FlsbRILV37EAmB)
		MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.decode(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠪࡹࡹ࡬࠸ࠨኛ")).encode(zqdvcbP5L8BHh(u"ࠫࡺࡺࡦ࠹ࠩኜ"))
		Ii3JAtnvZlskgFYQ = bUdr5Hahw6sY8xJ(u"࠱࠱࠳࠳࠷ᘴ")
		zXVpvERrQx5jlWg6Zweit3fULMmYkq = zz2LJUB9kjnZqAeH.Window(Ii3JAtnvZlskgFYQ)
		zXVpvERrQx5jlWg6Zweit3fULMmYkq.getControl(SO94xq1RAkMm2uF(u"࠴࠳࠴ᘵ")).setLabel(MMupPCxqkenwt6FlsbRILV37EAmB)
	return
k1LQ9aM6PDVp3R = [
			 Me28A1sBLNIgUp5YCDyvT(u"ࠧ࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮ࠡࠩࠪࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡨࡻࡲࡳࡧࡱࡸࡱࡿࠠࡴࡷࡳࡴࡴࡸࡴࡦࡦࠥኝ")
			,g4g6bfkPtVGU5lIM3(u"࠭ࡃࡩࡧࡦ࡯࡮ࡴࡧࠡࡨࡲࡶࠥࡓࡡ࡭࡫ࡦ࡭ࡴࡻࡳࠡࡵࡦࡶ࡮ࡶࡴࡴࠩኞ")
			,iUeoLOsbHqP(u"ࠧࡑࡘࡕࠤࡎࡖࡔࡗࠢࡖ࡭ࡲࡶ࡬ࡦࠢࡆࡰ࡮࡫࡮ࡵࠩኟ")
			,bUdr5Hahw6sY8xJ(u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯࡙ࠢ࡭ࡩ࡫࡯ࠡࡋࡱࡪࡴࠦࡋࡦࡻࠪአ")
			,SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠩࡷ࡬࡮ࡹࠠࡩࡣࡶ࡬ࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡪࡵࠣࡦࡷࡵ࡫ࡦࡰࠪኡ")
			,lc0dpSmwoPDjLnk(u"ࠪࡹࡸ࡫ࡳࠡࡲ࡯ࡥ࡮ࡴࠠࡉࡖࡗࡔࠥ࡬࡯ࡳࠢࡤࡨࡩ࠳࡯࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࡷࠬኢ")
			,S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࡦࡪࡶࡢࡰࡦࡩࡩ࠳ࡵࡴࡣࡪࡩ࠳࡮ࡴ࡮࡮ࠪኣ")+lc0dpSmwoPDjLnk(u"ࠬࠩࠧኤ")+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭ࡳࡴ࡮࠰ࡻࡦࡸ࡮ࡪࡰࡪࡷࠬእ")
			,iUeoLOsbHqP(u"ࠧࡊࡰࡶࡩࡨࡻࡲࡦࡔࡨࡵࡺ࡫ࡳࡵ࡙ࡤࡶࡳ࡯࡮ࡨ࠮ࠪኦ")
			,lc0dpSmwoPDjLnk(u"ࠨࡇࡵࡶࡴࡸࠠࡨࡧࡷࡸ࡮ࡴࡧࠡࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅ࠱ࡂࡱࡴࡪࡥࡦ࠿࠳ࠪࡹ࡫ࡸࡵࡶࡀࠫኧ")
			,hBvsQ7oCkKUdwjx58ml3EN(u"ࠩࡺࡥࡷࡴࡩ࡯ࡩࡶ࠲ࡼࡧࡲ࡯ࠪࠪከ")
			,iRoLg2m47tnDATBHGCSPNyx(u"ࠪࡢࡣࡤ࡞࡟ࠩኩ")
			,Cu1704YofAbr3QTm(u"ࠫࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡹ࡫ࡪࡰࠣࡪ࡮ࡲࡥ࠻ࠩኪ")
			]
def lnITUQRrHYJ0A6shXkFg27uwtBV(WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej):
	if yA5z6LIXBlo41PRVMY87wOisFp(u"ࠬࡒ࡯ࡢࡦ࡬ࡲ࡬ࠦࡳ࡬࡫ࡱࠤ࡫࡯࡬ࡦ࠼ࠪካ") in WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej and QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫኬ") in WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej: return Me28A1sBLNIgUp5YCDyvT(u"࡙ࡸࡵࡦ᚛")
	for MMupPCxqkenwt6FlsbRILV37EAmB in k1LQ9aM6PDVp3R:
		if MMupPCxqkenwt6FlsbRILV37EAmB in WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej: return sTcr7iDp5eFt4RoLMhuwq1A(u"࡚ࡲࡶࡧ᚜")
	return UTelCo0ihE1d5R(u"ࡆࡢ࡮ࡶࡩ᚝")
def ccOZEIjQiqf3TLW(data):
	data = data.replace(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠧ࡝ࡴ࡟ࡲࠬክ")+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠷࠴ᘶ")*iRoLg2m47tnDATBHGCSPNyx(u"ࠨࠢࠪኮ")+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩ࡟ࡶࡡࡴࠧኯ"),zqdvcbP5L8BHh(u"ࠪࡠࡷࡢ࡮ࠨኰ"))
	data = data.replace(xW2Arao7YVOemw(u"ࠫࡡࡴࠧ኱")+zqdvcbP5L8BHh(u"࠸࠵ᘷ")*S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠬࠦࠧኲ")+YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭࡜ࡳ࡞ࡱࠫኳ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧ࡝ࡴ࡟ࡲࠬኴ"))
	data = data.replace(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨ࡞ࡱࠫኵ")+iUeoLOsbHqP(u"࠹࠶ᘸ")*g4g6bfkPtVGU5lIM3(u"ࠩࠣࠫ኶")+zqdvcbP5L8BHh(u"ࠪࡠࡳ࠭኷"),FvNyZqaLKw(u"ࠫࡡࡴࠧኸ"))
	data = data.replace(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠬࡢ࡮ࠨኹ")+FvNyZqaLKw(u"࠻࠱ᘺ")*FvNyZqaLKw(u"࠭ࠠࠨኺ"),Cu1704YofAbr3QTm(u"ࠧ࡝ࡰࠪኻ")+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠸࠷ᘹ")*zqdvcbP5L8BHh(u"ࠨࠢࠪኼ"))
	data = data.replace(iUeoLOsbHqP(u"ࠩࠣࡀ࡬࡫࡮ࡦࡴࡤࡰࡃࡀࠠࠨኽ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠪ࠾ࠥ࠭ኾ"))
	Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = fprnld4CZo(u"ࠫࠬ኿")
	for WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej in data.splitlines():
		dDCLRW7qB0Nm29 = GGvHJKP9LUxEk10Fw.findall(dshJSmRqeiP9nap2(u"ࠬࠦࠠࠡࠢࠣࡊ࡮ࡲࡥࠡࠤࠫ࠲࠯ࡅࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠲࠮ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫዀ"),WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej,GGvHJKP9LUxEk10Fw.DOTALL)
		if dDCLRW7qB0Nm29: WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej = WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej.replace(dDCLRW7qB0Nm29[FvNyZqaLKw(u"࠰ᘻ")],FnBiAjthS8MkXs67W(u"࠭ࠧ዁"))
		Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd += FvNyZqaLKw(u"ࠧ࡝ࡰࠪዂ")+WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej
	return Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd
def l56CsZUJoONMLdq(ofZbdVjzl32vO):
	if xW2Arao7YVOemw(u"ࠨࡑࡏࡈࠬዃ") in ofZbdVjzl32vO:
		Ep5t07BfcC = KKogQqwJNpkny6M71bS4fEc
		header = bUdr5Hahw6sY8xJ(u"ࠩๅีฬวษࠡษ็ืั๊ࠠศๆๅำ๏๋ࠠภࠩዄ")
	else:
		Ep5t07BfcC = KpkbcfSIir6dCFMjwZy4gTYGuR0UA9
		header = FnBiAjthS8MkXs67W(u"ࠪๆึอมสࠢสุ่าไࠡษ็ัฬ๊๊ࠡมࠪዅ")
	o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࠬ዆"),g4g6bfkPtVGU5lIM3(u"ࠬ࠭዇"),hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࠧወ"),header,wRxoKs10Syj7V4edYhtP(u"ࠧิฮ็ࠤฬ๊รฯูสลࠥ๐อห๊ํࠤศ๐ึศࠢ฼่๎ࠦำอๆࠣห้อำหะาห๊ࠦ࠮๊ࠡส่ฬัๆฺ๋่ࠣึ๎ั๋ห่๊ࠣ฿ัโหࠣ็๏็ࠠฮัฮฮࠥอไๆึๆ่ฮ่ࠦๆษ๋ࠣํࠦวๅ็ๆห๋ࠦวๅาํࠤุฮศࠡฯา์ะࠦวๅ็ื็้ฯࠠ࠯ࠢๆ์ิ๐๋ࠠฯอๅ฽ࠦศิฮ็๎๋ࠦ࠮ࠡษ็วํ๊่๊ࠠࠣหู้ฬๅࠢส่าอไ๋๋ࠢๅ๏ํࠠๆ฻็์๊อสࠡฬหำศࠦๅ็าࠣฬิอ๊สࠢส่ฯฺฺ๋ๆࠣห้ำวๅ์่ࠣอืๆศ็ฯࠤ่๎ฯ๋๋ࠢห้๏ࠠศๆล๊ࠥ࠴ࠠฤ็สࠤฬ๊ำอๆࠣห้่ฯ๋็ࠣๅ์๎ࠠศๆึะ้ࠦวๅีสฬ็ࠦวๅาํࠤฯ๋ࠠอ็฼๋๋ࠥๆࠡสิ๊ฬ๋ฬࠡๅ๋ำ๏ࠦโษๆࠣฦำืࠠฦูไหฦࠦไ่ࠢ࠱ࠤ์๊ࠠหำํำࠥอไศีอ้ึอัࠡมࠪዉ"))
	if o07Z1tEB4n3ARCkVNu!=Cu1704YofAbr3QTm(u"࠲ᘼ"): return
	D5BcyvIJaolVMEwxWGz,NOcFpG4d02xz = [],dshJSmRqeiP9nap2(u"࠲ᘽ")
	size,count = hYNG3tj5Xu2knZ7lowbS(Ep5t07BfcC)
	file = open(Ep5t07BfcC,dshJSmRqeiP9nap2(u"ࠨࡴࡥࠫዊ"))
	if size>YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠵࠵࠶࠲࠱࠲ᘿ"): file.seek(-UTelCo0ihE1d5R(u"࠴࠴࠵࠷࠰࠱ᘾ"),WpgZTyqoMAPhwGiXF.SEEK_END)
	data = file.read()
	file.close()
	if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: data = data.decode(wRxoKs10Syj7V4edYhtP(u"ࠩࡸࡸ࡫࠾ࠧዋ"))
	data = ccOZEIjQiqf3TLW(data)
	ExOjma9CSy2vQbPLhMUworYu = data.split(iRoLg2m47tnDATBHGCSPNyx(u"ࠪࡠࡳ࠭ዌ"))
	for WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej in reversed(ExOjma9CSy2vQbPLhMUworYu):
		EdncDtkXC58xSapeIsGHQWuhVgOv = lnITUQRrHYJ0A6shXkFg27uwtBV(WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej)
		if EdncDtkXC58xSapeIsGHQWuhVgOv: continue
		WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej = WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej.replace(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡤ࠭ው"),E6MIKdpBomef(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫዎ"))
		WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej = WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej.replace(kEhAHvti6Vnsfx(u"࠭ࡅࡓࡔࡒࡖ࠿࠭ዏ"),UTelCo0ihE1d5R(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊ࠵࠶࠰࠱࡟ࡈࡖࡗࡕࡒ࠻࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪዐ"))
		czTYOVRyPXZigDbumUndfe = UTelCo0ihE1d5R(u"ࠨࠩዑ")
		v7QJUnhd2j0squOw9W8PZk5rMRl = GGvHJKP9LUxEk10Fw.findall(XzrqbGDIy54juixkMA(u"ࠩࡡࠬࡡࡪࠫ࠮ࠪ࡟ࡨ࠰࠳࡜ࡥ࠭ࠣࡠࡩ࠱࠺࡝ࡦ࠮࠾ࡡࡪࠫ࡝࠰࡟ࡨ࠰࠯ࠩࠩࠢࡗ࠾ࡡࡪࠫࠪࠩዒ"),WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej,GGvHJKP9LUxEk10Fw.DOTALL)
		if v7QJUnhd2j0squOw9W8PZk5rMRl:
			WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej = WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej.replace(v7QJUnhd2j0squOw9W8PZk5rMRl[g4g6bfkPtVGU5lIM3(u"࠶ᙁ")][g4g6bfkPtVGU5lIM3(u"࠶ᙁ")],v7QJUnhd2j0squOw9W8PZk5rMRl[g4g6bfkPtVGU5lIM3(u"࠶ᙁ")][E6MIKdpBomef(u"࠶ᙀ")]).replace(v7QJUnhd2j0squOw9W8PZk5rMRl[g4g6bfkPtVGU5lIM3(u"࠶ᙁ")][YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠲ᙂ")],xW2Arao7YVOemw(u"ࠪࠫዓ"))
			czTYOVRyPXZigDbumUndfe = v7QJUnhd2j0squOw9W8PZk5rMRl[FvNyZqaLKw(u"࠲ᙄ")][iUeoLOsbHqP(u"࠲ᙃ")]
		else:
			v7QJUnhd2j0squOw9W8PZk5rMRl = GGvHJKP9LUxEk10Fw.findall(XzrqbGDIy54juixkMA(u"ࠫࡣ࠮࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤࠬࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫዔ"),WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej,GGvHJKP9LUxEk10Fw.DOTALL)
			if v7QJUnhd2j0squOw9W8PZk5rMRl:
				WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej = WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej.replace(v7QJUnhd2j0squOw9W8PZk5rMRl[iRoLg2m47tnDATBHGCSPNyx(u"࠴ᙆ")][fprnld4CZo(u"࠴ᙅ")],Me28A1sBLNIgUp5YCDyvT(u"ࠬ࠭ዕ"))
				czTYOVRyPXZigDbumUndfe = v7QJUnhd2j0squOw9W8PZk5rMRl[iRoLg2m47tnDATBHGCSPNyx(u"࠵ᙇ")][iRoLg2m47tnDATBHGCSPNyx(u"࠵ᙇ")]
		if czTYOVRyPXZigDbumUndfe: WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej = WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej.replace(czTYOVRyPXZigDbumUndfe,dshJSmRqeiP9nap2(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩዖ")+czTYOVRyPXZigDbumUndfe+hBvsQ7oCkKUdwjx58ml3EN(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ዗"))
		D5BcyvIJaolVMEwxWGz.append(WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej)
		if len(str(D5BcyvIJaolVMEwxWGz))>SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠻࠰࠲࠲࠳ᙈ"): break
	D5BcyvIJaolVMEwxWGz = reversed(D5BcyvIJaolVMEwxWGz)
	n73O46rfoGDB = E6MIKdpBomef(u"ࠨ࡞ࡱࠫዘ").join(D5BcyvIJaolVMEwxWGz)
	d0tNlv4Lbu2pqDaO1JfSEC9QIP5Xc(SO94xq1RAkMm2uF(u"ࠩ࡯ࡩ࡫ࡺࠧዙ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪฦำืࠠฤีฺีูࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠧዚ"),n73O46rfoGDB,iUeoLOsbHqP(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡳ࡮ࡣ࡯ࡰ࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧዛ"))
	return
def I5wp1m68J3NhaDvubAYOtTrWG9cyZ():
	eSctY1HmfBPjGUz9 = open(MMOICsmwlWaPz41YhFT2jpxJZy,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬࡸࡢࠨዜ")).read()
	if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: eSctY1HmfBPjGUz9 = eSctY1HmfBPjGUz9.decode(hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࡵࡵࡨ࠻ࠫዝ"))
	eSctY1HmfBPjGUz9 = eSctY1HmfBPjGUz9.replace(LiRcTVUWuth70DmPy(u"ࠧ࡝ࡶࠪዞ"),wRxoKs10Syj7V4edYhtP(u"ࠨࠢࠣࠤࠥࠦࠠࠡࠢࠪዟ"))
	YEROUgQ5Gkj1 = GGvHJKP9LUxEk10Fw.findall(FvNyZqaLKw(u"ࠩࠫࡺࡡࡪ࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪዠ"),eSctY1HmfBPjGUz9,GGvHJKP9LUxEk10Fw.DOTALL)
	for WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej in YEROUgQ5Gkj1:
		eSctY1HmfBPjGUz9 = eSctY1HmfBPjGUz9.replace(WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej,xW2Arao7YVOemw(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ዡ")+WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej+S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ዢ"))
	W2mX5R4ShoirfzdFaOukjHZIDpC8(E6MIKdpBomef(u"ࠬอไห฼ํ๎ึอสࠡษ็วำ๐ัสࠢไ๎ࠥอไษำส้ั࠭ዣ"),eSctY1HmfBPjGUz9)
	return
def kgXCoOxBI3bDyNmhp481MY():
	Wu6THcbvsRZdXSz4nwlCVy = SO94xq1RAkMm2uF(u"࠭ศฺุࠣห้ษาาษิࠤ฾๊้ࠡษ็ี๏๋่หࠢๆ์๋ะั้ๆࠣฮํ็ัࠡว่็ฬ์๊สࠢอๆิ๐ๅ๊ࠡอวำ๐ัࠡษ็ๅ๏ี๊้๋๋ࠢีํࠠศๆฦึึอั้ࠡํࠤฬ๊ริ้่ࠤํอไฤำๅห๊ࠦๅฺࠢห฽฻่ࠦไษ็ฮฬ๊๊ࠨዤ")
	bdzvPE1KBTfkMj04QAG5hY7ouqZD = g4g6bfkPtVGU5lIM3(u"ࠧๅฬๅำ๏๋ࠠศๆไ๎ิ๐่ࠡษึฮำีๅࠡษ็ื์๋ࠠศๆํ้๏์้ࠠๆอวำ๐ั่ࠢสืฯิฯๆࠢสุ่ํๅࠡษ็๎ุอัࠡ࠰ࠣว๊อฺࠠัฬࠤฬู็ๆ่ࠢฮฯอไ๋หࠣๅ์ึ็ࠡฬๅ์๊ࠦศหฯิ๎่ࠦวๅใํำ๏๎ࠠษ๊ๅฮࠥอใษำ้๋่ࠣࠦใฬࠣหู้็ๆࠢส่ํออะࠢ࠱ࠤศ๋วࠡษ็ื์๋ࠠศๆฦ฽้๏้ࠠษ็วุ็ไࠡใ๊์ࠥ๐อาๅࠣห้็๊ะ์๋ࠤส๊้ࠡษ็ว๊อๅࠡล๋ࠤส๊้ࠡษ็์ึอม๊ࠡ็็๋ࠦศใใีอ้ࠥศ๋ำฬࠫዥ")
	eFQXmOopl5Gfd = Cu1704YofAbr3QTm(u"ࠨล่หࠥอไฤำๅห๊ࠦแ่์ࠣฮุะฮะ็่้ࠣะโะ์่ࠤํอไหลั๎ึ่ࠦๅๅ้ࠤอ๋โะษิࠤ฾ีฯࠡษ็ฯํอๆ๋๋ࠢห้ีโศศๅࠤ࠳ࠦๅฬๆสࠤึ่ๅࠡ࠷࠷࠸ࠥะู็์ࠣ࠹ࠥีโศศๅࠤํࠦ࠴࠵ࠢฮห๋๐ษࠡว็ํࠥอไฤ็ส้ࠥษ่ࠡว็ํࠥอไ้ำสลࠥฮอิสࠣหุะฮะษ่็๊ࠥไิ้่ࠤฬ๊๊ๆ์้ࠤศ๎ࠠิ้่ࠤฬ๊๊ิษิࠫዦ")
	LpdKxnIsY3Sy6qP = Wu6THcbvsRZdXSz4nwlCVy+xW2Arao7YVOemw(u"ࠩ࠽ࠤࠬዧ")+bdzvPE1KBTfkMj04QAG5hY7ouqZD+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠪࠤ࠳ࠦࠧየ")+eFQXmOopl5Gfd
	d0tNlv4Lbu2pqDaO1JfSEC9QIP5Xc(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫዩ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨዪ"),LpdKxnIsY3Sy6qP,S4SOKF2QbBhjCd3RrVMuHIzE(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩያ"))
	return
def StXADUfOBwG413slo8VkK(type,LpdKxnIsY3Sy6qP,showDialogs=l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࡕࡴࡸࡩ᚞"),url=XzrqbGDIy54juixkMA(u"ࠧࠨዬ"),hayXA4TiLlPxcVSIoK2=wRxoKs10Syj7V4edYhtP(u"ࠨࠩይ"),MMupPCxqkenwt6FlsbRILV37EAmB=YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩࠪዮ"),XAP2xv0SYMCHuL3Ow=xW2Arao7YVOemw(u"ࠪࠫዯ")):
	nZuGrAeaUKWMHwslRVv9 = yA5z6LIXBlo41PRVMY87wOisFp(u"ࡖࡵࡹࡪ᚟")
	if not bkHiCyWXjdgvF9xE1DA6wQ48(Me28A1sBLNIgUp5YCDyvT(u"ࠫࡈ࡚ࡅ࠺ࡆࡖ࠵࠾࡜ࡕ࠱ࡘࡖ࡜ࠬደ")):
		if showDialogs:
			HbyJgUGlqSXjT9ekV = (iRoLg2m47tnDATBHGCSPNyx(u"ࠬอไิูิ࠾ࠬዱ") in LpdKxnIsY3Sy6qP and E6MIKdpBomef(u"࠭วๅ็ๆห๋ࡀࠧዲ") in LpdKxnIsY3Sy6qP and xW2Arao7YVOemw(u"ࠧศๆ่่ๆࡀࠧዳ") in LpdKxnIsY3Sy6qP and LiRcTVUWuth70DmPy(u"ࠨษ็า฼ษࠧዴ") in LpdKxnIsY3Sy6qP and pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩส่๊฻ฯา࠼ࠪድ") in LpdKxnIsY3Sy6qP)
			if not HbyJgUGlqSXjT9ekV: nZuGrAeaUKWMHwslRVv9 = ggi4vBsqHDArM1(kEhAHvti6Vnsfx(u"ࠪࡧࡪࡴࡴࡦࡴࠪዶ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫࠬዷ"),LiRcTVUWuth70DmPy(u"ࠬ࠭ዸ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭็ๅࠢอีุ๊่ࠠา๊ࠤฬ๊ัิษ็อࠥหไ๊ࠢส่๊ฮัๆฮࠪዹ"),LpdKxnIsY3Sy6qP.replace(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧ࡝࡞ࡱࠫዺ"),Cu1704YofAbr3QTm(u"ࠨ࡞ࡱࠫዻ")))
	elif showDialogs:
		LpdKxnIsY3Sy6qP = hBvsQ7oCkKUdwjx58ml3EN(u"ࠩ࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไสࠩዼ")
		PJ36UXwpOdW9KSDnGv = ggi4vBsqHDArM1(kEhAHvti6Vnsfx(u"ࠪࡧࡪࡴࡴࡦࡴࠪዽ"),lc0dpSmwoPDjLnk(u"ࠫࠬዾ"),Me28A1sBLNIgUp5YCDyvT(u"ࠬ࠭ዿ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭ጀ")+g4g6bfkPtVGU5lIM3(u"ࠧࠡࠢ࠴࠳࠺࠭ጁ"),FnBiAjthS8MkXs67W(u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭ጂ"))
		jNYIdySE8J2eOt = ggi4vBsqHDArM1(p72fnFtcPix5UKwr9YNzW(u"ࠩࡦࡩࡳࡺࡥࡳࠩጃ"),lc0dpSmwoPDjLnk(u"ࠪࠫጄ"),dshJSmRqeiP9nap2(u"ࠫࠬጅ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬጆ")+S4SOKF2QbBhjCd3RrVMuHIzE(u"࠭ࠠࠡ࠴࠲࠹ࠬጇ"),SO94xq1RAkMm2uF(u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬገ"))
		tW81u7rJpD = ggi4vBsqHDArM1(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨጉ"),bUdr5Hahw6sY8xJ(u"ࠩࠪጊ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠪࠫጋ"),UTelCo0ihE1d5R(u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫጌ")+hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬࠦࠠ࠴࠱࠸ࠫግ"),fprnld4CZo(u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫጎ"))
		i9CQ4ucohE8GOvYRe = ggi4vBsqHDArM1(kEhAHvti6Vnsfx(u"ࠧࡤࡧࡱࡸࡪࡸࠧጏ"),Cu1704YofAbr3QTm(u"ࠨࠩጐ"),LiRcTVUWuth70DmPy(u"ࠩࠪ጑"),xW2Arao7YVOemw(u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪጒ")+xW2Arao7YVOemw(u"ࠫࠥࠦ࠴࠰࠷ࠪጓ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪጔ"))
		nZuGrAeaUKWMHwslRVv9 = ggi4vBsqHDArM1(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ጕ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧࠨ጖"),wRxoKs10Syj7V4edYhtP(u"ࠨࠩ጗"),kEhAHvti6Vnsfx(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩጘ")+XzrqbGDIy54juixkMA(u"ࠪࠤࠥ࠻࠯࠶ࠩጙ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩጚ"))
	exOIZnGECcR2p3WV4TPY06BNDo7 = PW2xo0Kq3Tcprj9Ck(xW2Arao7YVOemw(u"࠳࠳ᙉ"),wRxoKs10Syj7V4edYhtP(u"ࡉࡥࡱࡹࡥᚠ"))
	jAP2GFDIsTkqMo4 = Me28A1sBLNIgUp5YCDyvT(u"ࠬࡇࡖ࠻ࠢࠪጛ")+exOIZnGECcR2p3WV4TPY06BNDo7+SO94xq1RAkMm2uF(u"࠭࠭ࠨጜ")+type
	gIQPxaThXNYtL = bUdr5Hahw6sY8xJ(u"࡙ࡸࡵࡦᚢ") if G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࠪጝ") in MMupPCxqkenwt6FlsbRILV37EAmB else fprnld4CZo(u"ࡊࡦࡲࡳࡦᚡ")
	if not nZuGrAeaUKWMHwslRVv9:
		if showDialogs: aHKzv76JCVnprbY8w(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࠩጞ"),Me28A1sBLNIgUp5YCDyvT(u"ࠩࠪጟ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ጠ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫฯ๋ࠠฦๆ฽หฦࠦวๅวิืฬ๊ࠠษ่สลࠥ฿ไฺ๊่ࠢอ้ࠧጡ"))
		return SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࡌࡡ࡭ࡵࡨᚣ")
	TTLoK4mF78zs = cEZpW924rqNYm5.getInfoLabel(g4g6bfkPtVGU5lIM3(u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡌࡲࡪࡧࡱࡨࡱࡿࡎࡢ࡯ࡨࠫጢ"))
	LpdKxnIsY3Sy6qP += SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࠠ࡝࡞ࡱࡠࡡࡴ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾ࠢࡀࡁࡂࡃࠠ࡝࡞ࡱࡅࡩࡪ࡯࡯࡙ࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࠬጣ")+mmn0lB2tFI7XTgVfESo+Me28A1sBLNIgUp5YCDyvT(u"ࠧࠡ࠼࡟ࡠࡳ࠭ጤ")
	LpdKxnIsY3Sy6qP += Me28A1sBLNIgUp5YCDyvT(u"ࠨࡇࡰࡥ࡮ࡲࠠࡔࡧࡱࡨࡪࡸ࠺ࠡࠩጥ")+exOIZnGECcR2p3WV4TPY06BNDo7+p72fnFtcPix5UKwr9YNzW(u"ࠩࠣ࠾ࡡࡢ࡮ࡌࡱࡧ࡭ࠥ࡜ࡥࡳࡵ࡬ࡳࡳࡀࠠࠨጦ")+cc3xyKurSgDZ9pHhLiFk2fjXbTnsN+FnBiAjthS8MkXs67W(u"ࠪࠤ࠿ࡢ࡜࡯ࠩጧ")
	LpdKxnIsY3Sy6qP += zqdvcbP5L8BHh(u"ࠫࡐࡵࡤࡪࠢࡑࡥࡲ࡫࠺ࠡࠩጨ")+TTLoK4mF78zs
	Ld4oBuRD29JgTmZcMkH16 = T0U4fwNGiQ()
	Ld4oBuRD29JgTmZcMkH16 = mGfdCk4Hyclg9RjD(Ld4oBuRD29JgTmZcMkH16)
	if Ld4oBuRD29JgTmZcMkH16: LpdKxnIsY3Sy6qP += YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠬࠦ࠺࡝࡞ࡱࡐࡴࡩࡡࡵ࡫ࡲࡲ࠿ࠦࠧጩ")+Ld4oBuRD29JgTmZcMkH16
	if url: LpdKxnIsY3Sy6qP += FnBiAjthS8MkXs67W(u"࠭ࠠ࠻࡞࡟ࡲ࡚ࡘࡌ࠻ࠢࠪጪ")+url
	if hayXA4TiLlPxcVSIoK2: LpdKxnIsY3Sy6qP += SO94xq1RAkMm2uF(u"ࠧࠡ࠼࡟ࡠࡳ࡙࡯ࡶࡴࡦࡩ࠿ࠦࠧጫ")+hayXA4TiLlPxcVSIoK2
	LpdKxnIsY3Sy6qP += dshJSmRqeiP9nap2(u"ࠨࠢ࠽ࡠࡡࡴࠧጬ")
	if showDialogs: From8aTqdhCbPs(zqdvcbP5L8BHh(u"ࠩฯหึ๐ࠠศๆศีุอไࠨጭ"),SO94xq1RAkMm2uF(u"ࠪห้ืฬศรࠣห้อๆหฺสีࠬጮ"))
	if XAP2xv0SYMCHuL3Ow:
		n73O46rfoGDB = XAP2xv0SYMCHuL3Ow
		if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: n73O46rfoGDB = n73O46rfoGDB.encode(bUdr5Hahw6sY8xJ(u"ࠫࡺࡺࡦ࠹ࠩጯ"))
		n73O46rfoGDB = hNe0ECZHr9B6.b64encode(n73O46rfoGDB)
	elif gIQPxaThXNYtL:
		if xW2Arao7YVOemw(u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࡐࡎࡇࡣࠬጰ") in MMupPCxqkenwt6FlsbRILV37EAmB: nozaXibp6h3CBIfY0vEt15 = KKogQqwJNpkny6M71bS4fEc
		else: nozaXibp6h3CBIfY0vEt15 = KpkbcfSIir6dCFMjwZy4gTYGuR0UA9
		if not WpgZTyqoMAPhwGiXF.path.exists(nozaXibp6h3CBIfY0vEt15):
			aHKzv76JCVnprbY8w(FvNyZqaLKw(u"࠭ࠧጱ"),E6MIKdpBomef(u"ࠧࠨጲ"),fprnld4CZo(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫጳ"),Cu1704YofAbr3QTm(u"ࠩึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤ฿๐ัࠡ็๋ะํีࠧጴ"))
			return XzrqbGDIy54juixkMA(u"ࡆࡢ࡮ࡶࡩᚤ")
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q(p72fnFtcPix5UKwr9YNzW(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪጵ"),FvNyZqaLKw(u"ࠫ࠳ࠦࠠࡑࡴࡨࡴࡦࡸࡩ࡯ࡩࠣࡸࡴࠦࡳࡦࡰࡧࠤࡹ࡮ࡥࠡ࡮ࡲ࡫࡫࡯࡬ࡦࠩጶ"))
		D5BcyvIJaolVMEwxWGz,NOcFpG4d02xz = [],xW2Arao7YVOemw(u"࠱ᙊ")
		file = open(nozaXibp6h3CBIfY0vEt15,FnBiAjthS8MkXs67W(u"ࠬࡸࡢࠨጷ"))
		size,count = hYNG3tj5Xu2knZ7lowbS(nozaXibp6h3CBIfY0vEt15)
		if size>iRoLg2m47tnDATBHGCSPNyx(u"࠵࠳࠵࠵࠶࠰ᙋ"): file.seek(-iRoLg2m47tnDATBHGCSPNyx(u"࠵࠳࠵࠵࠶࠰ᙋ"),WpgZTyqoMAPhwGiXF.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(yA5z6LIXBlo41PRVMY87wOisFp(u"࠭ࡵࡵࡨ࠻ࠫጸ"))
		data = ccOZEIjQiqf3TLW(data)
		ExOjma9CSy2vQbPLhMUworYu = data.splitlines()
		for WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej in reversed(ExOjma9CSy2vQbPLhMUworYu):
			EdncDtkXC58xSapeIsGHQWuhVgOv = lnITUQRrHYJ0A6shXkFg27uwtBV(WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej)
			if EdncDtkXC58xSapeIsGHQWuhVgOv: continue
			v7QJUnhd2j0squOw9W8PZk5rMRl = GGvHJKP9LUxEk10Fw.findall(Me28A1sBLNIgUp5YCDyvT(u"ࠧ࡟ࠪ࡟ࡨ࠰࠳ࠨ࡝ࡦ࠮࠱ࡡࡪࠫࠡ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠮࠮ࠠࡕ࠼࡟ࡨ࠰࠯ࠧጹ"),WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej,GGvHJKP9LUxEk10Fw.DOTALL)
			if v7QJUnhd2j0squOw9W8PZk5rMRl:
				WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej = WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej.replace(v7QJUnhd2j0squOw9W8PZk5rMRl[iRoLg2m47tnDATBHGCSPNyx(u"࠴ᙍ")][iRoLg2m47tnDATBHGCSPNyx(u"࠴ᙍ")],v7QJUnhd2j0squOw9W8PZk5rMRl[iRoLg2m47tnDATBHGCSPNyx(u"࠴ᙍ")][FnBiAjthS8MkXs67W(u"࠴ᙌ")]).replace(v7QJUnhd2j0squOw9W8PZk5rMRl[iRoLg2m47tnDATBHGCSPNyx(u"࠴ᙍ")][Cu1704YofAbr3QTm(u"࠷ᙎ")],iUeoLOsbHqP(u"ࠨࠩጺ"))
			else:
				v7QJUnhd2j0squOw9W8PZk5rMRl = GGvHJKP9LUxEk10Fw.findall(lc0dpSmwoPDjLnk(u"ࠩࡡࠬࡡࡪࠫ࠻࡞ࡧ࠯࠿ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠩࠢࡗ࠾ࡡࡪࠫࠪࠩጻ"),WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej,GGvHJKP9LUxEk10Fw.DOTALL)
				if v7QJUnhd2j0squOw9W8PZk5rMRl: WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej = WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej.replace(v7QJUnhd2j0squOw9W8PZk5rMRl[LiRcTVUWuth70DmPy(u"࠰ᙐ")][YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠷ᙏ")],yA5z6LIXBlo41PRVMY87wOisFp(u"ࠪࠫጼ"))
			D5BcyvIJaolVMEwxWGz.append(WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej)
			if len(str(D5BcyvIJaolVMEwxWGz))>yA5z6LIXBlo41PRVMY87wOisFp(u"࠳࠷࠴࠴࠵࠶ᙑ"): break
		D5BcyvIJaolVMEwxWGz = reversed(D5BcyvIJaolVMEwxWGz)
		n73O46rfoGDB = fprnld4CZo(u"ࠫࡡࡸ࡜࡯ࠩጽ").join(D5BcyvIJaolVMEwxWGz)
		n73O46rfoGDB = n73O46rfoGDB.encode(Cu1704YofAbr3QTm(u"ࠬࡻࡴࡧ࠺ࠪጾ"))
		n73O46rfoGDB = hNe0ECZHr9B6.b64encode(n73O46rfoGDB)
	else: n73O46rfoGDB = fprnld4CZo(u"࠭ࠧጿ")
	url = oSVpce1UQYrDqhuM6PT[yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧፀ")][hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠴ᙒ")]
	vpWXJDC4lTByaqcn56OFwUmieV = {zqdvcbP5L8BHh(u"ࠨࡵࡸࡦ࡯࡫ࡣࡵࠩፁ"):jAP2GFDIsTkqMo4,G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪፂ"):LpdKxnIsY3Sy6qP,xW2Arao7YVOemw(u"ࠪࡰࡴ࡭ࡦࡪ࡮ࡨࠫፃ"):n73O46rfoGDB}
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,Cu1704YofAbr3QTm(u"ࠫࡕࡕࡓࡕࠩፄ"),url,vpWXJDC4lTByaqcn56OFwUmieV,bUdr5Hahw6sY8xJ(u"ࠬ࠭ፅ"),FnBiAjthS8MkXs67W(u"࠭ࠧፆ"),LiRcTVUWuth70DmPy(u"ࠧࠨፇ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡗࡊࡔࡄࡠࡇࡐࡅࡎࡒ࠭࠲ࡵࡷࠫፈ"))
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	if FvNyZqaLKw(u"ࠩࠥࡷࡺࡩࡣࡦࡧࡧࡩࡩࠨ࠺ࠡ࠳࠯ࠫፉ") in BBlXpmUyhFDwNtCVAHoE: Tr8iRxJmbcEhftU5DSHzA = E6MIKdpBomef(u"ࡕࡴࡸࡩᚥ")
	else: Tr8iRxJmbcEhftU5DSHzA = sTcr7iDp5eFt4RoLMhuwq1A(u"ࡈࡤࡰࡸ࡫ᚦ")
	if showDialogs:
		if Tr8iRxJmbcEhftU5DSHzA:
			From8aTqdhCbPs(FnBiAjthS8MkXs67W(u"ࠪฮ๊ࠦวๅวิืฬ๊ࠠษ่ฯหา࠭ፊ"),XzrqbGDIy54juixkMA(u"ࠫࡘࡻࡣࡤࡧࡶࡷࠬፋ"))
			aHKzv76JCVnprbY8w(zqdvcbP5L8BHh(u"ࠬ࠭ፌ"),E6MIKdpBomef(u"࠭ࠧፍ"),g4g6bfkPtVGU5lIM3(u"ࠧࡎࡧࡶࡷࡦ࡭ࡥࠡࡵࡨࡲࡹ࠭ፎ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠨฬ่ࠤสืำศๆࠣห้ืำศๆฬࠤอ์ฬศฯࠪፏ"))
		else:
			From8aTqdhCbPs(xW2Arao7YVOemw(u"ࠩ็่ศูแࠡใื่ࠥอไฦำึห้࠭ፐ"),E6MIKdpBomef(u"ࠪࡊࡦ࡯࡬ࡶࡴࡨࠫፑ"))
			aHKzv76JCVnprbY8w(dshJSmRqeiP9nap2(u"ࠫࠬፒ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬ࠭ፓ"),iUeoLOsbHqP(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩፔ"),FvNyZqaLKw(u"ࠧฯูฦࠤํ็ิๅࠢไ๎ࠥหัิษ็ࠤฬ๊ัิษ็อࠬፕ"))
	return Tr8iRxJmbcEhftU5DSHzA
def IZYxewht7RETNr8vGqWi():
	Wu6THcbvsRZdXSz4nwlCVy = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨ࠳࠱ࠤࠥࠦࡉࡧࠢࡼࡳࡺࠦࡨࡢࡸࡨࠤࡵࡸ࡯ࡣ࡮ࡨࡱࠥࡽࡩࡵࡪࠣࡅࡷࡧࡢࡪࡥࠣࡸࡪࡾࡴࡵࠢࡷ࡬ࡪࡴࠠࡨࡱࠣࡸࡴࠦࠢࡌࡱࡧ࡭ࠥࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࠡࡕࡨࡸࡹ࡯࡮ࡨࡵࠥࠤࡦࡴࡤࠡࡥ࡫ࡥࡳ࡭ࡥࠡࡶ࡫ࡩࠥ࡬࡯࡯ࡶࠣࡸࡴࠦࠢࡂࡴ࡬ࡥࡱࠨࠧፖ")
	bdzvPE1KBTfkMj04QAG5hY7ouqZD = QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩ࠴࠲ࠥࠦࠠฦาสࠤ้ี๊ไุ่่๊ࠢษࠡใํࠤฬ๊รฮำไࠤฬู๊าสํอࠥ็วั้หࠤส๊้ࠡว฼ำฬีวห๋ࠢหัํษࠡๅ๋ำ๏ࠦหๆࠢ฽๎ึࠦวๅะฺࠤฬ๊ๅิฬัำ๊ࠦลๅ๋ࠣࠦࡆࡸࡩࡢ࡮ࠥࠫፗ")
	aHKzv76JCVnprbY8w(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࠫፘ"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࠬፙ"),p72fnFtcPix5UKwr9YNzW(u"ࠬࡇࡲࡢࡤ࡬ࡧࠥࡖࡲࡰࡤ࡯ࡩࡲ࠭ፚ"),Wu6THcbvsRZdXSz4nwlCVy+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠭࡜࡯࡞ࡱࠫ፛")+bdzvPE1KBTfkMj04QAG5hY7ouqZD)
	Wu6THcbvsRZdXSz4nwlCVy = oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧ࠳࠰ࠣࠤࠥࡏࡦࠡࡻࡲࡹࠥࡩࡡ࡯࡞ࠪࡸࠥ࡬ࡩ࡯ࡦࠣࠦࡆࡸࡩࡢ࡮ࠥࠤ࡫ࡵ࡮ࡵࠢࡷ࡬ࡪࡴࠠࡤࡪࡤࡲ࡬࡫ࠠࡵࡪࡨࠤࡸࡱࡩ࡯ࠢࡤࡲࡩࠦࡴࡩࡧࡱࠤࡨ࡮ࡡ࡯ࡩࡨࠤࡹ࡮ࡥࠡࡨࡲࡲࡹ࠭፜")
	bdzvPE1KBTfkMj04QAG5hY7ouqZD = UTelCo0ihE1d5R(u"ࠨ࠴࠱ࠤࠥࠦลัษ่๊ࠣࠦสอัࠣห้ิืࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢไๆ๊ࠦศห฼ํ๎ึࠦวๅฮ็ำࠥัๅࠡไ่ࠤอะฺ๋ำࠣห้ิืࠡษ็ุ้ะฮะ็ࠣษ้๏ࠠࠣࡃࡵ࡭ࡦࡲࠢࠨ፝")
	aHKzv76JCVnprbY8w(kEhAHvti6Vnsfx(u"ࠩࠪ፞"),SO94xq1RAkMm2uF(u"ࠪࠫ፟"),p72fnFtcPix5UKwr9YNzW(u"ࠫࡋࡵ࡮ࡵࠢࡓࡶࡴࡨ࡬ࡦ࡯ࠪ፠"),Wu6THcbvsRZdXSz4nwlCVy+LiRcTVUWuth70DmPy(u"ࠬࡢ࡮࡝ࡰࠪ፡")+bdzvPE1KBTfkMj04QAG5hY7ouqZD)
	Wu6THcbvsRZdXSz4nwlCVy = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭࠳࠯ࠢࠣࠤࡎ࡬ࠠࡺࡱࡸࠤࡩࡵ࡮࡝ࠩࡷࠤ࡭ࡧࡶࡦࠢࡄࡶࡦࡨࡩࡤࠢࡎࡩࡾࡨ࡯ࡢࡴࡧࠤࡹ࡮ࡥ࡯ࠢࡪࡳࠥࡺ࡯ࠡࠤࡎࡳࡩ࡯ࠠࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡗࡪࡺࡴࡪࡰࡪࡷࠧࠦࡡ࡯ࡦࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡳࡧࡪ࡭ࡴࡴࡡ࡭ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠫ።")
	bdzvPE1KBTfkMj04QAG5hY7ouqZD = g4g6bfkPtVGU5lIM3(u"ࠧ࠴࠰ࠣࠤࠥหะศࠢ็้ࠥ๐ใ็ࠢ็ำ๏้ࠠๅ๊ะอ๋ࠥแศฬํัࠥ฿ัษ์ฬࠤๆอะ่สࠣษ้๏ࠠฦ฻าหิอส๊ࠡสะ์ฯࠠไ๊า๎ࠥัๅࠡ฼ํีࠥหูะษาหฯࠦวๅ็้฻็ฯࠠศๆฯ฾ึอแ๋หࠪ፣")
	aHKzv76JCVnprbY8w(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨࠩ፤"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠩࠪ፥"),Cu1704YofAbr3QTm(u"ࠪࡊࡴࡴࡴࠡࡒࡵࡳࡧࡲࡥ࡮ࠩ፦"),Wu6THcbvsRZdXSz4nwlCVy+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࡡࡴ࡜࡯ࠩ፧")+bdzvPE1KBTfkMj04QAG5hY7ouqZD)
	o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(UTelCo0ihE1d5R(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ፨"),lc0dpSmwoPDjLnk(u"࠭ࠧ፩"),SO94xq1RAkMm2uF(u"ࠧࠨ፪"),SO94xq1RAkMm2uF(u"ࠨࡈࡲࡲࡹࠦࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠨ፫"),xW2Arao7YVOemw(u"ࠩࡇࡳࠥࡿ࡯ࡶࠢࡺࡥࡳࡺࠠࡵࡱࠣ࡫ࡴࠦࡴࡰࠢࠥࡏࡴࡪࡩࠡࡋࡱࡸࡪࡸࡦࡢࡥࡨࠤࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸࠨࠠ࡯ࡱࡺࠤࡄ࠭፬")+UTelCo0ihE1d5R(u"ࠪࡠࡳࡢ࡮ࠨ፭")+hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠫ์๊ࠠหำํำࠥอไั้สฬࠥหไ๊ࠢ็์าฯࠠฦ฻าหิอส๊ࠡสะ์ฯࠠไ๊า๎ࠥษไร่ยࠫ፮"))
	if o07Z1tEB4n3ARCkVNu==xW2Arao7YVOemw(u"࠴ᙓ"): RvV9ztgAFkJIL8a7CXxhq()
	return
def hvq04Ted9RHKpiFVQtw():
	aHKzv76JCVnprbY8w(XzrqbGDIy54juixkMA(u"ࠬ࠭፯"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠭ࠧ፰"),bUdr5Hahw6sY8xJ(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ፱"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠨ฼ส่ออࠠศๆึฬอࠦ็้่๊ࠢࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥอไๆ฼ำ๎๊ࠥไษำ้ห๊า้ࠠๆ็ฮศ้ฯࠡไ่ࠤอะิ฻์็ࠤฬ๊ัศสฺࠤฬ๊ะ๋ࠢ็หࠥ๐ูๆๆࠣฯ๊ࠦโๆࠢหษึูวๅุ่่๊ࠢษࠡว็ํࠥอไๆสิ้ัࠦๅ็ࠢส่็อฦๆหࠣห้ืฦ๋ีํอ๊ࠥไษำ้ห๊าࠧ፲"))
	return
def Z1H2kgnfodwDWv5EUi6ytpA7xQlbR():
	LpdKxnIsY3Sy6qP = XzrqbGDIy54juixkMA(u"๊ࠩิฬࠦวๅสิ๊ฬ๋ฬࠡ็ัฺูࠦแใู่้ࠣเษࠡษ็฽ึฮ๊ส๋่่ࠢ์่ࠠาสࠤ้อ๋ࠠ็้฽ࠥ๎ฬ้ั้ࠣํอโฺࠢไ๎์อࠠฤใ็ห๊่ࠦๆี็ื้อสࠡ็อีั๋ษࠡล๋ࠤ๊ีศๅฮฬࠤส๊้ࠡษ็่฿ฯࠠศๆ฼ีอ๐ษ๊ࠡส่๎ࠦไ฻ษอࠤฬิั๊๋่ࠢฬ๊้ࠦฮาࠤุฮศࠡๆ็ฮ่ืวาࠩ፳")
	aHKzv76JCVnprbY8w(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࠫ፴"),SO94xq1RAkMm2uF(u"ࠫࠬ፵"),zqdvcbP5L8BHh(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ፶"),LpdKxnIsY3Sy6qP)
	return
def YYkLbjIEdrxVGh():
	LpdKxnIsY3Sy6qP = G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠭วๅำ๋หอ฽ࠠศๆห฻๏ฬษࠡๆสࠤ฾๊วให่ࠣ์อࠠษษ็ฬึ์วๆฮࠣ์฿อไษษࠣหู้ศษ๊ࠢ์๋ࠥๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡษ็้฿ึ๊ࠡๆ็ฬึ์วๆฮࠪ፷")
	aHKzv76JCVnprbY8w(fprnld4CZo(u"ࠧࠨ፸"),LiRcTVUWuth70DmPy(u"ࠨࠩ፹"),LiRcTVUWuth70DmPy(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ፺"),LpdKxnIsY3Sy6qP)
	return
def xpGg082CRzFKyBklQebhI():
	LpdKxnIsY3Sy6qP = fprnld4CZo(u"๋ࠪ๏ࠦำ๋ำไีฬะࠠๅษࠣ๎ุะื๋฻ࠣห้ฮั็ษ่ะࠥอำหะาห๊ํวࠡสึฬอࠦใ้่๊ห๋ࠥอๆ์ฬࠤ๊์ࠠศๆู่ิืࠠฤ๊ࠣฬาอฬสࠢศ่๎ࠦวีฬิห่ࠦัิ็ํࠤศ๎ࠠอัํำฮࠦร้ࠢ็หࠥ๐ูาใ๊หࠥอไษำ้ห๊าࠧ፻")
	aHKzv76JCVnprbY8w(fprnld4CZo(u"ࠫࠬ፼"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠬ࠭፽"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ፾"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧิ์ิๅึอสࠡีํสฮࠦร้่ࠢะ์๎ไสࠩ፿"),LpdKxnIsY3Sy6qP)
	return
def iox5GqmLNMR2Sz98dDaYw6Fgh1Wn():
	LpdKxnIsY3Sy6qP = SO94xq1RAkMm2uF(u"ࠨษ็ื๏ืแาษอࠤฬู๊ศ็ฬࠤ์๐ࠠิ์ิๅึอสࠡะสีั๐ษ๊ࠡ฽๎ึࠦสศส฼อ๊ࠥไๆ๊ๅ฽ࠥอไฤื็๎ࠥ๎ฬๆ์฼ࠤฬ๊ๅ้ษๅ฽ࠥะำหะา้์อ้ࠠ฻สำฮࠦสไ๊้ࠤ๊าว็์ฬࠤํ๋ิศๅ็๋ฬࠦใฬ์ิอ๊ࠥว็ࠢส่ๆ๐ฯ๋๊๊หฯࠦแ๋้สࠤส๋วࠡสฺ๎หฯࠠฤ๊้๊ࠣ์ฺ่หࠣวํࠦๅฮา๋ๅฮࠦร้ࠢไ๎์อࠠๆึๆ่ฮࠦอใ๊ๅࠤฬ๊ๅๅๅํอࡡࡴ࡜࡯࡞ࡱหู้๊าใิหฯࠦวๅะสูฮࠦ็๋ࠢึ๎ึ็ัศฬࠣฮฬฮูสࠢ็่๊๎โฺࠢส่ศ฻ไุ๋๋้ࠢะฮะ็ฬࠤๆ๐ࠠๆ๊สๆ฾ࠦโๅ์็อࠥาฯศ๋ࠢ฽ฬีษࠡฬๆ์๋ࠦๅะใ๋฽ฮࠦวๅลฯีࠥษ่ࠡ์่่่ํวࠡษ็้ํู่ࠡษ็วฺ๊๊๊ࠡ็๋ีอࠠโ้ํࠤั๐ฯส้ࠢือ๐ว๊ࠡึี๏฿ษุ๊่ࠡฬ้ไ่ษࠣๆ้๐ไสࠢฯำฬ࠭ᎀ")
	d0tNlv4Lbu2pqDaO1JfSEC9QIP5Xc(Cu1704YofAbr3QTm(u"ࠩࡦࡩࡳࡺࡥࡳࠩᎁ"),g4g6bfkPtVGU5lIM3(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᎂ"),LpdKxnIsY3Sy6qP,kEhAHvti6Vnsfx(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧᎃ"))
	return
def medGTENZQsk2nAP4H1uDJfW0I():
	Wu6THcbvsRZdXSz4nwlCVy = p72fnFtcPix5UKwr9YNzW(u"ࠬอศห฻าࠤ฾์ࠠๆๆไหฯࠦวๅัๅอࠥอไฺษ็๎ฮ࠭ᎄ")
	bdzvPE1KBTfkMj04QAG5hY7ouqZD = Me28A1sBLNIgUp5YCDyvT(u"࠭วษฬ฼ำࠥ฿ๆࠡ็็ๅฬะࠠฤๆࠣࡱ࠸ࡻ࠸ࠨᎅ")
	eFQXmOopl5Gfd = g4g6bfkPtVGU5lIM3(u"ࠧศสอ฽ิูࠦ็่่ࠢๆอสࠡษ็ฮา๋๊ๅ๋ࠢห้ีว้่็์ิࠦࡤࡰࡹࡱࡰࡴࡧࡤࠨᎆ")
	aHKzv76JCVnprbY8w(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨࠩᎇ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠩࠪᎈ"),g4g6bfkPtVGU5lIM3(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᎉ"),Wu6THcbvsRZdXSz4nwlCVy,bdzvPE1KBTfkMj04QAG5hY7ouqZD,eFQXmOopl5Gfd)
	return
def JEwT6SyBWQnl():
	bdzvPE1KBTfkMj04QAG5hY7ouqZD = G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫฬ๊ใศึ๋ࠣํࠦๅฯิ้ࠤ๊สโหࠢ็่๊฿ไ้็สฮࠥ๐ำหะา้์ࠦวๅสิ๊ฬ๋ฬࠡๆัึ๋ࠦีโฯสฮࠥอไฦ่อี๋๐ส๊ࠡิ์ฬฮืࠡษ็ๅ๏ี๊้้สฮ๊ࠥไ้ื๋่ࠥหไ๋้สࠤอูัฺหࠣ์อี่็ࠢศ๊ฯืๆ๋ฬࠣ์ฬ๊ศา่ส้ั๊ࠦๆีะ๋ฬࠦสๅไสส๏อࠠษ฻าࠤฬ์ส่ษฤࠤ฾๋ั่ษࠣ์ศ๐ึศࠢ฼๊ิࠦสฮัํฯࠥอไษำ้ห๊าࠠ࠯๋๋ࠢีอࠠศๆหี๋อๅอࠢํืฯิฯๆࠢึฬ฾ฯࠠฤ่๋ห฾ࠦไฺ็ิࠤฬ๊ใศึࠣ࠾ࠬᎊ")
	bdzvPE1KBTfkMj04QAG5hY7ouqZD += QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬࡢ࡮࡝ࡰࠪᎋ") + sTcr7iDp5eFt4RoLMhuwq1A(u"࠭࠱࠯ࠢฮหอะࠠๅๆุๅาอสࠡษ็ฮ๏ࠦๅฺำ๋ๅࠥษๆ่ษ่ࠣฬࠦสห฼ํีࠥ์็ศศํหࠥ๎ๅะฬ๊ࠤࠬᎌ") + str(GOhVkMATsg4cJmfa0Enp6zSqCr/lc0dpSmwoPDjLnk(u"࠺࠵ᙔ")/lc0dpSmwoPDjLnk(u"࠺࠵ᙔ")/lc0dpSmwoPDjLnk(u"࠷࠺ᙕ")/g4g6bfkPtVGU5lIM3(u"࠹࠰ᙖ")) + kEhAHvti6Vnsfx(u"ࠧࠡึ๊ีࠬᎍ")
	bdzvPE1KBTfkMj04QAG5hY7ouqZD += hBvsQ7oCkKUdwjx58ml3EN(u"ࠨ࡞ࡱࠫᎎ") + S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠩ࠵࠲ࠥาฯศฺࠢ์๏๊ࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆ่ๅึ๎ึࠡล้๋ฬࠦไศࠢอฮ฿๐ั๊่ࠡำฯํࠠࠨᎏ") + str(OrZFej19nLcNdh2WKRuDJC/l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠶࠱ᙗ")/l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠶࠱ᙗ")/QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠳࠶ᙘ")) + SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪࠤ๏๎ๅࠨ᎐")
	bdzvPE1KBTfkMj04QAG5hY7ouqZD += YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠫࡡࡴࠧ᎑") + Me28A1sBLNIgUp5YCDyvT(u"ࠬ࠹࠮ู๋ࠡ๎้ࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅฬํࠤ๋อฯาษࠣฮฯเ๊า๋้ࠢิะ็ࠡࠩ᎒") + str(ZcdnQAJ3ltkoiPsyX5/g4g6bfkPtVGU5lIM3(u"࠸࠳ᙙ")/g4g6bfkPtVGU5lIM3(u"࠸࠳ᙙ")/wRxoKs10Syj7V4edYhtP(u"࠵࠸ᙚ")) + zqdvcbP5L8BHh(u"๋๊่࠭ࠠࠫ᎓")
	bdzvPE1KBTfkMj04QAG5hY7ouqZD += iUeoLOsbHqP(u"ࠧ࡝ࡰࠪ᎔") + lc0dpSmwoPDjLnk(u"ࠨ࠶࠱ࠤ๊ะ่ิูࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้ะ๊ࠡไาࠤฯะฺ๋ำࠣ์๊ีส่ࠢࠪ᎕") + str(Oa8xvPtmLZkBA43K0EzrdhXS/Cu1704YofAbr3QTm(u"࠺࠵ᙛ")/Cu1704YofAbr3QTm(u"࠺࠵ᙛ")) + iUeoLOsbHqP(u"ࠩࠣืฬ฿ษࠨ᎖")
	bdzvPE1KBTfkMj04QAG5hY7ouqZD += G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠪࡠࡳ࠭᎗") + XzrqbGDIy54juixkMA(u"ࠫ࠺࠴ࠠใืํีࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์ࠣฮฯเ๊าࠢาหห๋ว๊่ࠡำฯํࠠࠨ᎘") + str(xh9BXlAw0UoVsIZ4if3/oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠻࠶ᙜ")/oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠻࠶ᙜ")) + hBvsQ7oCkKUdwjx58ml3EN(u"ࠬࠦำศ฻ฬࠫ᎙")
	bdzvPE1KBTfkMj04QAG5hY7ouqZD += SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭࡜࡯ࠩ᎚") + FvNyZqaLKw(u"ࠧ࠷࠰ࠣะิอࠠใืํีࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์ࠣฮฯเ๊าࠢๆฯ๏ืว๊่ࠡำฯํࠠࠨ᎛") + str(X9mvsOYNPGeWdaIw01Mf4Jz5p/XzrqbGDIy54juixkMA(u"࠼࠰ᙝ")) + pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࠢาๆ๏่ษࠨ᎜")
	bdzvPE1KBTfkMj04QAG5hY7ouqZD += iUeoLOsbHqP(u"ࠩ࡟ࡲࠬ᎝") + fprnld4CZo(u"ࠪ࠻࠳ࠦศะ๊้ࠤ่อิࠡๆ็ูๆำวหࠢส่ฯ๐ࠠหฬ฽๎ึࠦศิำ฼อࠥ๎ๅะฬ๊ࠤࠬ᎞") + str(BXnrZSgERcxHvbVQ4) + p72fnFtcPix5UKwr9YNzW(u"ࠫࠥีโ๋ไฬࠫ᎟")
	bdzvPE1KBTfkMj04QAG5hY7ouqZD += lc0dpSmwoPDjLnk(u"ࠬࡢ࡮࡝ࡰࠪᎠ") + FnBiAjthS8MkXs67W(u"࠭ๅฬๆส࠾ࠥ฻แฮษอࠤ็๎วว็ࠣห้ษแๅษ่ࠤํอไๆี็ื้อส๊ࠡส่า๊โศฬࠣ฽๊ื็ศࠢࠪᎡ") + str(Oa8xvPtmLZkBA43K0EzrdhXS/hBvsQ7oCkKUdwjx58ml3EN(u"࠶࠱ᙞ")/hBvsQ7oCkKUdwjx58ml3EN(u"࠶࠱ᙞ")) + lc0dpSmwoPDjLnk(u"ࠧࠡีส฽ฮࠦ࠮ࠡล่ห่่ࠥศศ่ࠤศ์่ศ฻ࠣห้็๊ะ์๋๋ฬะࠠโ฻่ี์อࠠࠨᎢ") + str(ZcdnQAJ3ltkoiPsyX5/hBvsQ7oCkKUdwjx58ml3EN(u"࠶࠱ᙞ")/hBvsQ7oCkKUdwjx58ml3EN(u"࠶࠱ᙞ")/yA5z6LIXBlo41PRVMY87wOisFp(u"࠳࠶ᙟ")) + E6MIKdpBomef(u"ࠨࠢฦ๎ฬ๋ࠠ࠯ࠢฦ้ฬࠦๅๅใสฮࠥอไโ์า๎ํࠦแฺ็ิ๋ฬࠦࠧᎣ") + str(xh9BXlAw0UoVsIZ4if3/hBvsQ7oCkKUdwjx58ml3EN(u"࠶࠱ᙞ")/hBvsQ7oCkKUdwjx58ml3EN(u"࠶࠱ᙞ")) + lc0dpSmwoPDjLnk(u"ࠩࠣืฬ฿ษࠡใๅ฻ࠥ࠴ࠠฤ็สࠤๆำีࠡำๅ้ࠥอไฦืาหึࠦแฺ็ิ๋ࠥ࠭Ꭴ") + str(X9mvsOYNPGeWdaIw01Mf4Jz5p/hBvsQ7oCkKUdwjx58ml3EN(u"࠶࠱ᙞ")) + oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠪࠤิ่๊ใหࠣ࠲ࠥษๅศࠢไัฺࠦวีฬิห่ࠦเࡊࡒࡗ࡚ࠥ็ูๆำ๊ࠤࠬᎥ") + str(BXnrZSgERcxHvbVQ4) + zqdvcbP5L8BHh(u"ࠫࠥีโ๋ไฬࠫᎦ")
	d0tNlv4Lbu2pqDaO1JfSEC9QIP5Xc(iRoLg2m47tnDATBHGCSPNyx(u"ࠬࡸࡩࡨࡪࡷࠫᎧ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭ๅศ๊ࠢ์ࠥอไไษืࠤฬ๊ๅิฬัำ๊ࠦแ๋ࠢส่อืๆศ็ฯࠫᎨ"),bdzvPE1KBTfkMj04QAG5hY7ouqZD,S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪᎩ"))
	return
def jjF4Xi2ToqYEmKu8():
	LpdKxnIsY3Sy6qP = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨษ็ๅฬ฻ไสࠢอ฽๋๐ࠠๆฮ็ำࠥฮๆโีࠣหุ๋็ࠡษ็วฺ๊๊๊ࠡส่๋่ืสࠢอ฽๋๐ࠠฤ่ࠣห้อำๆࠢส่ศ฻ไ๋ࠢอ้ࠥะูะ์็๋ࠥ๎แศื็อࠥ๎ๆใูฬࠤฯ฿ๆ๊่ࠢะ้ี้ࠠฬ่ࠤฯ฿ฯ๋ๆࠣหุ๋็๊ࠡหำํ์ฺࠠๆส้ฮࠦสฺ่ํࠤ๊๊แࠡส้ๅุࠦวิ็๊ࠤฬ๊รึๆํࠫᎪ")
	aHKzv76JCVnprbY8w(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠩࠪᎫ"),LiRcTVUWuth70DmPy(u"ࠪࠫᎬ"),kEhAHvti6Vnsfx(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᎭ"),LpdKxnIsY3Sy6qP)
	return
def BGHWTD4nJsOq9c2ICpafoK1z():
	LpdKxnIsY3Sy6qP = p72fnFtcPix5UKwr9YNzW(u"ࠬหะศ๋ࠢหัํสไุ่่๊ࠢษࠡใํࠤฬ๊ิษๅฬࠤํะๅࠡฯ็๋ฬࠦ࠮࠯࠰ࠣวํࠦว็ๅࠣฮ฽์ࠠฤ่ࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣ็ฬ์ࠠโ์๊ࠤฺ๊ใๅห้ࠣษ่ส่๋ࠢฮ๊ࠦอๅ้สࠤ࠳࠴࠮ࠡใศิ๋ࠦฬาสุ้ࠣำࠠไษืࠤฬ๊ศา่ส้ัࠦไไ์ࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣฬ฼๊ศࠡษ็ูๆำษࠡษ็ูา๐อส๋ࠢฮำุ๊็้สࠤอีไศ่๊ࠢࠥอไึใะอࠥอไใัํ้ฮ࠭Ꭾ")
	aHKzv76JCVnprbY8w(Cu1704YofAbr3QTm(u"࠭ࠧᎯ"),SO94xq1RAkMm2uF(u"ࠧࠨᎰ"),xW2Arao7YVOemw(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᎱ"),LpdKxnIsY3Sy6qP)
	return
def UAYdBOy7iFb2nQVfJk():
	LpdKxnIsY3Sy6qP = Cu1704YofAbr3QTm(u"ࠩส่฿ืึࠡ็้ࠤูํวะหࠣห้ะิโ์ิࠤ์๎ࠠื็ส๊ࠥ฻อส๋ࠢืึ๐ษࠡษ็้฾๊่ๆษอࠤฬ๊ๅหสสำ้ฯࠠษ์้ࠤฬ๊ศา่ส้ั่ࠦศๆ่์็฿ࠠศๆุ่ๆื้้ࠠำหࠥอไื็ส๊ࠥเ๊า่ࠢ฻้๎ศ๊ࠡ็หࠥำวอห่ࠣ์ูࠦ็ัࠣห้อสึษ็ࠤฬ๎ࠠศๆิฬ฼ࠦๅฺ่ࠢ์ฬู่ࠡษ็ๅ๏ี๊้้สฮࠥอไๆึไีฮ࠭Ꮂ")
	aHKzv76JCVnprbY8w(SO94xq1RAkMm2uF(u"ࠪࠫᎳ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠫࠬᎴ"),UTelCo0ihE1d5R(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᎵ"),LpdKxnIsY3Sy6qP)
	return
def PeUX4o7xmuLVYtyBwZjbR():
	aHKzv76JCVnprbY8w(sTcr7iDp5eFt4RoLMhuwq1A(u"࠭ࠧᎶ"),wRxoKs10Syj7V4edYhtP(u"ࠧࠨᎷ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᎸ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠩ็็๏ฺ๊ࠦ็็ࠤ์ึวࠡษ็๊ํ฿ࠠๆ่ࠣห้็๊ะ์๋๋ฬะࠠ࡝ࡰࠣ๎ัฮࠠหใ฼๎้ࠦลืษไอࠥอำๆ้สࠤࡡࡴࠠࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧᎹ"))
	KmIlXVwgsFZxEdh1b(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪᎺ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࡗࡶࡺ࡫ᚧ"))
	return
def r7rWDudx1p8():
	LpdKxnIsY3Sy6qP  = oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"๊ࠫสฮาษࠣๆฬ๋สࠡส฼ฺฺࠥัไษอࠤฬ๊ล็ฬิ๊ฯࠦวๅั๋่๏ࠦศุ้฼ࠤ฾อฦใูࠢำࠥอไษำส้ัࠦๅฬๆࠣ็ํี๊ࠡๆอื๊ำࠠโไฺࠤ้ฮูื่ࠢืฯิฯๆ์ࠣห้๋สึใะࠤออไะะ๋่๊ࠥๅ้ษๅ฽ࠥอไโ์า๎ํ࠭Ꮋ")
	LpdKxnIsY3Sy6qP += Cu1704YofAbr3QTm(u"่ࠬࠦ็ฬํะฮࠦไ่าสࠤฬู๊ศศๅࠤๆอๆ่ࠢอๆึ๐ศศࠢฯ้๏฿ࠠๆีอาิ๋๊ࠡสิ๊ฬ๋ฬࠡๅ๋ำ๏ࠦไศࠢํืฯ฽ฺ๊๊้ࠤฬ๊ฯฯ๊็ࠤ้าๅ๋฻้ࠣํอโฺࠢส่อืๆศ็ฯࠤาะ้ࠡ็฼ࠤฬูสฯัส้ࠬᎼ")
	LpdKxnIsY3Sy6qP += UTelCo0ihE1d5R(u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠไࠥࠦࡖࡑࡐࠣࠤศ๎ࠠࠡࡒࡵࡳࡽࡿࠠࠡล๋ࠤࠥࡊࡎࡔࠢࠣวํࠦร๋ࠢะ่ࠥฮำู๋ࠣฦำื࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰࠪᎽ")
	LpdKxnIsY3Sy6qP += E6MIKdpBomef(u"ࠧ࡝ࡰ็ห๋ࠦ็ัษ่๋๊ࠣࠦฮๆࠣห้๋ิไๆฬࠤํหๆๆษࠣๅ็฽ࠠิ์ๅ์๊ࠦศฦื็หาࠦศฺุࠣห้๋่ศไ฼ࠤํหูศไฬࠤ๊๎วใ฻ࠣหำื้ࠡๅส๊ฯࠦสฺ็็ࠤุอศใษࠣฬิ๎ๆࠡ็ืห่๊ࠧᎾ")
	d0tNlv4Lbu2pqDaO1JfSEC9QIP5Xc(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠨࡴ࡬࡫࡭ࡺࠧᎿ"),iUeoLOsbHqP(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᏀ"),LpdKxnIsY3Sy6qP,lc0dpSmwoPDjLnk(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭Ꮑ"))
	LpdKxnIsY3Sy6qP = xW2Arao7YVOemw(u"ࠫฬ๊ๅ้ษๅ฽ࠥอไห์ࠣฮศััหࠢหห้฿ววไࠣ฽๋ีࠠษ฻ูࠤฬ๊ๆศี๋ࠣ๏ࡀࠧᏂ")
	LpdKxnIsY3Sy6qP += zqdvcbP5L8BHh(u"ࠬࡢ࡮ࠨᏃ")+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡣ࡮ࡳࡦࡳࠠࠡࡧࡪࡽࡧ࡫ࡳࡵࠢࠣࡩ࡬ࡿࡢࡦࡵࡷࡺ࡮ࡶࠠࠡ࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧࠤࠥࡹࡥࡳ࡫ࡨࡷ࠹ࡽࡡࡵࡥ࡫ࠤࠥࡹࡨࡢࡪ࡬ࡨ࠹ࡻ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨᏄ")
	LpdKxnIsY3Sy6qP += pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧ࡝ࡰ࡟ࡲࠬᏅ")+iRoLg2m47tnDATBHGCSPNyx(u"ࠨษ็ำํ๊ࠠศๆอ๎ࠥะรฬำอࠤออไฺษษๆࠥ฿ๆะࠢห฽฻ࠦวๅ่สืࠥํ๊࠻ࠩᏆ")
	LpdKxnIsY3Sy6qP += E6MIKdpBomef(u"ࠩ࡟ࡲࠬᏇ")+kEhAHvti6Vnsfx(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋ีาࠢࠣห้้่๋ฬࠣࠤศ๋๊าๅสࠤ้ࠥๆะษࠣࠤๆืๆิษࠣࠤฬ๊๊้่ส๊ࠥࠦศา์ฺห๋๐วࠡษ็ษ๊อัศฬࠣว้๋ว็์สࠤึ๎ำ๋ษࠣห้๐วษษ้ࠤฬ๊ำฺ๊า๎ฮࠦั้็ส๊๏อ่๊ࠠ็๊ิอ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨᏈ")
	LpdKxnIsY3Sy6qP += E6MIKdpBomef(u"ࠫࡡࡴ࡜࡯ࠩᏉ")+iRoLg2m47tnDATBHGCSPNyx(u"ࠬอไๆสิ้ั่ࠦอัࠣ฻ึ๐โสࠢ็ฮัอ่ำࠢส่฾อฦใ๋่่ࠢ์็ศࠢอัฯอฬࠡฮ๊ำ้ࠥศ๋ำࠣ์ฬ๊ๅษำ่ะࠥ๐ุ็ࠢสฺ่๊ใๅหูࠣ฿๐ัส๋่ࠢฬࠦสิฬะๆࠥอไห฻หࠤๆหะศࠢ็ำ๏้ࠠๆึๆ่ฮࠦศศๆาาํ๊ࠠๅส฼ฺࠥอไๆ๊สๆ฾่ࠦฤ์ูห๊ࠥใ๋ࠢํฮ฻ำࠠฮฮ่ࠤฬ๊ๅีๅ็อࠥ࠭Ꮚ")
	LpdKxnIsY3Sy6qP += FvNyZqaLKw(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ษิื้ࠦัิษ็อ๋ࠥฤะสฬࠤส๊้ࠡษ็้อืๅอ๋ࠢห่ะศࠡใํ๋ฬࠦวิ็ࠣฬ้ีใ๊ࠡฦื๊อมࠡษ็้ํอโฺࠢส่ฯ๐ࠠๅษࠣฮุะื๋฻ࠣำำ๎ไ่ษ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᏋ")
	d0tNlv4Lbu2pqDaO1JfSEC9QIP5Xc(xW2Arao7YVOemw(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭Ꮜ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᏍ"),LpdKxnIsY3Sy6qP,p72fnFtcPix5UKwr9YNzW(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬᏎ"))
	return
def lwjFYHeGCfrbuaB2zWIgEyRp3cP9():
	aHKzv76JCVnprbY8w(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪࠫᏏ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࠬᏐ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠬัไศอࠣ฻ึ่ࠠๅๆอ์ฬ฻ไࠡ็฼ࠤฬ๊ๅษำ่ะࠬᏑ"),p72fnFtcPix5UKwr9YNzW(u"࠭ราี็ࠤึูวๅหࠣวํࠦๅีๅ็อ๋ࠥๆࠡไสส๊ฯࠠฯั่หฯࠦ็ัษࠣห้ฮั็ษ่ะࡡࡴ࡜࡯ล๋ࠤออำหะาห๊ࠦวๅใํือ๎ใࠡลา๊ฬํ࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ࡬ࡹࡺࡰ࠻࠱࠲ࡪࡦࡩࡥࡣࡱࡲ࡯࠳ࡩ࡯࡮࠱ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠳࠲࠴࠼ࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮࡝ࡰฦ์ࠥฮวาีส่ࠥอ๊ๆ์็ࠤฬ๊้ࠡลา๊ฬํࠠࠡ࡞ࡱࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠷࠶࠱࠹ࡂࡪࡱࡦ࡯࡬࠯ࡥࡲࡱࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭Ꮢ"))
	return
def BcrwHJOChQvkmqyLEg4U28():
	JEwT6SyBWQnl()
	o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(fprnld4CZo(u"ࠧࡤࡧࡱࡸࡪࡸࠧᏓ"),Me28A1sBLNIgUp5YCDyvT(u"ࠨࠩᏔ"),wRxoKs10Syj7V4edYhtP(u"ࠩࠪᏕ"),wRxoKs10Syj7V4edYhtP(u"๋้ࠪࠦสา์าࠤู๊อࠡฮ่๎฾ࠦวๅๅสุࠥลࠧᏖ"),wRxoKs10Syj7V4edYhtP(u"ࠫฬ๊ใศึࠣ๎ุืูࠡ฻่่ࠥอไษำ้ห๊า้ࠠ็ึั์ฺ๊ࠦ์าࠤุำศࠡษ็ูๆำวห่๊ࠢࠥอไฦ่อี๋ะฺ่ࠠาࠤฬ๊อศฮฬࠤส๊๊่ษࠣ์ฬ๊ๅิฯࠣ๎ฯ๋ࠠหๆๅหห๐วࠡ฻้ำࠥอๆห้สลࠥ฿ๅาࠢสฺ่็อศฬࠣ์ฬ๊ๅิฯ่ࠣฬ๊ࠦืำࠣ์๊๋ใ็ࠢํั้ࠦศฺุࠣห้๋ิศๅ็ࠫᏗ"))
	if o07Z1tEB4n3ARCkVNu==S4SOKF2QbBhjCd3RrVMuHIzE(u"࠳ᙠ"):
		GcIxLR5v8p1YAleW2jkEu7nZqg(iUeoLOsbHqP(u"ࡘࡷࡻࡥᚨ"))
		aHKzv76JCVnprbY8w(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬ࠭Ꮨ"),hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࠧᏙ"),Me28A1sBLNIgUp5YCDyvT(u"ࠧห็ุ้ࠣำࠠไษืࠤฬ๊ศา่ส้ัࠦศศๆๆห๊๊ࠧᏚ"),FnBiAjthS8MkXs67W(u"ࠨวำห้ࠥว็ฬࠣ฽๋ีใࠡ็ื็้ฯࠠโ์ࠣหาีࠠศๆ่์ฬู่ࠡใฯีอࠦวๅ็๋ๆ฾ࠦวๅฤ้ࠤ࠳࠴࠮๊ࠡฦิฬࠦวๅ็ื็้ฯࠠๆีอ้ึฯࠠโวำ๊ࠥอัิๆࠣห้๋ิไๆฬࠤส๊้ࠡษ็้อืๅอࠩᏛ"))
	return o07Z1tEB4n3ARCkVNu
def hD80GrKP5fMgRtdA9BYlHpCsk(showDialogs=E6MIKdpBomef(u"࡙ࡸࡵࡦᚩ")):
	if not showDialogs: showDialogs = YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࡚ࡲࡶࡧᚪ")
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,Cu1704YofAbr3QTm(u"ࠩࡊࡉ࡙࠭Ꮬ"),FnBiAjthS8MkXs67W(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡾࡡ࡮ࡲ࡯ࡩ࠳ࡩ࡯࡮ࠩᏝ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠫࠬᏞ"),fprnld4CZo(u"ࠬ࠭Ꮯ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࡆࡢ࡮ࡶࡩᚫ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭ࠧᏠ"),fprnld4CZo(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡋࡘ࡙ࡖࡓࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪᏡ"))
	if not WbTGMHnDysdYZ2lFA.succeeded:
		eeGQMLsfBSqichCWk = iUeoLOsbHqP(u"ࡇࡣ࡯ࡷࡪᚬ")
		m5MfkiT7oUDbvHI43ByeY9FP = uHqQfiPTpJIj971nbGMs03LoyzwK()
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q(wRxoKs10Syj7V4edYhtP(u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭Ꮲ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+wRxoKs10Syj7V4edYhtP(u"ࠩࠣࠤࠥࡎࡔࡕࡒࡖࠤࡋࡧࡩ࡭ࡧࡧࠤࠥࠦࡌࡢࡤࡨࡰ࠿ࡡࠧᏣ")+m5MfkiT7oUDbvHI43ByeY9FP+XzrqbGDIy54juixkMA(u"ࠪࡡࠬᏤ"))
		if showDialogs: aHKzv76JCVnprbY8w(Me28A1sBLNIgUp5YCDyvT(u"ࠫࠬᏥ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬ࠭Ꮶ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᏧ"),FnBiAjthS8MkXs67W(u"ࠧโฯุࠤฬ๊วหืส่ࠥอไๆึไีࠥ࠴࠮࠯ุ่่๊ࠢษࠡ࠰࠱࠲ࠥอไศฬุห้ࠦวๅ็ืๅึࠦࠨศๆิฬ฼ࠦวๅ็ืๅึ࠯ࠠๅษࠣ๎฾๋ไࠡ฻้ำู่ࠦๅ๋ࠣ็ํี๊ࠡ࠰࠱࠲ࠥ๎ู็ัๆࠤ่๎ฯ๋ࠢ฽๎ึࠦโศัิࠤ฾๊้ࠡษึฮำีวๆࠢส่๊๎วใ฻ࠣห้๋ิโำฬࠫᏨ"))
	else:
		eeGQMLsfBSqichCWk = iUeoLOsbHqP(u"ࡖࡵࡹࡪᚭ")
		if showDialogs: aHKzv76JCVnprbY8w(FnBiAjthS8MkXs67W(u"ࠨࠩᏩ"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩࠪᏪ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭Ꮻ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮࠯ࠢส่ฬะีศๆࠣห้๋ิโำࠣࠬฬ๊ัษูࠣห้๋ิโำࠬࠤ๏฿ๅๅࠢ฼๊ิ้้ࠠษ็ฬึ์วๆฮࠣๆฬีัࠡ฻็ํࠥอำหะาห๊ࠦวๅ็๋ห็฿ࠠศๆุ่ๆืษࠨᏬ"))
	if not eeGQMLsfBSqichCWk and showDialogs: G0tHfLFAN3Jqeugi()
	return eeGQMLsfBSqichCWk
def G0tHfLFAN3Jqeugi():
	aHKzv76JCVnprbY8w(wRxoKs10Syj7V4edYhtP(u"ࠬ࠭Ꮽ"),bUdr5Hahw6sY8xJ(u"࠭ࠧᏮ"),UTelCo0ihE1d5R(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᏯ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨส฼ฺࠥอไๆ๊สๆ฾ࠦสฮฬสะࠥืศุุ่ࠢๆื้ࠠไาࠤ๏้่็ࠢฯ๋ฬุใࠡ฼ํี่ࠥวะำࠣ฽้๏ࠠศๆิฬ฼ࠦวๅ็ืๅึࠦร้๊๊ࠢฬ้ࠠๆึๆ่ฮࠦแ๋ࠢื๋ฬีษࠡษ็ฮู็๊าࠢส่ำอีสࠢห็ํี๊ࠡ฻้ำู่ࠦๅ็สࠤฬ์็ࠡฬ่ࠤๆำีࠡษ็ฬึ์วๆฮࠣ฽้๏ࠠไ๊า๎ࠥอไฦืาหึอสࠡ࡞ࡱࠤ࠶࠽࠮࠷ࠢࠣࠪࠥࠦ࠱࠹࠰࡞࠴࠲࠿࡝ࠡࠢࠩࠤࠥ࠷࠹࠯࡝࠳࠱࠸ࡣࠧᏰ"))
	q4OV92sRG3EfDedmwUpKAI()
	return
def eimszEapSbIurqvN3c5hk4VylDCH(MMupPCxqkenwt6FlsbRILV37EAmB=SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠩࠪᏱ")):
	gIQPxaThXNYtL = LiRcTVUWuth70DmPy(u"ࡗࡶࡺ࡫ᚮ")
	if YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭Ᏺ") not in MMupPCxqkenwt6FlsbRILV37EAmB:
		gIQPxaThXNYtL = g4g6bfkPtVGU5lIM3(u"ࡊࡦࡲࡳࡦᚯ")
		w0g6SxLJBqDUl9cNIE52VMkR = CCQOct8zmrKMuP6ZEkxq7oaf1BeRv(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᏳ"),SO94xq1RAkMm2uF(u"ࠬิั้ฮࠪᏴ"),dshJSmRqeiP9nap2(u"࠭ลาีส่๋ࠥิไๆฬࠫᏵ"),E6MIKdpBomef(u"ࠧฦำึห้ࠦัิษ็อࠬ᏶"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ᏷"),Me28A1sBLNIgUp5YCDyvT(u"๊่ࠩࠥะั๋ัࠣว๋ࠦสาี็ࠤึูวๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ࠰࠱ࠤศ๋ࠠหำํำࠥษๆࠡฬิื้ࠦๅีๅ็อ๋่ࠥอ๊าอࠥ็๊ࠡษ็ฬึ์วๆฮࠣรࠬᏸ"))
		if w0g6SxLJBqDUl9cNIE52VMkR in [-iRoLg2m47tnDATBHGCSPNyx(u"࠴ᙡ"),SO94xq1RAkMm2uF(u"࠴ᙢ")]: return
		elif w0g6SxLJBqDUl9cNIE52VMkR==fprnld4CZo(u"࠶ᙣ"):
			gIQPxaThXNYtL = zqdvcbP5L8BHh(u"࡙ࡸࡵࡦᚰ")
			MMupPCxqkenwt6FlsbRILV37EAmB = QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭ᏹ")
	if gIQPxaThXNYtL:
		if dshJSmRqeiP9nap2(u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࡏࡍࡆࡢࠫᏺ") not in MMupPCxqkenwt6FlsbRILV37EAmB:
			o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(UTelCo0ihE1d5R(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᏻ"),hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࠧᏼ"),wRxoKs10Syj7V4edYhtP(u"ࠧࠨᏽ"),fprnld4CZo(u"ࠨู๊฽ࠥอไๆึๆ่ฮࠦแ๋ࠢสุ่าไࠨ᏾"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠩๅฬ้ࠦลาีส่ࠥอไิฮ็ࠤ฾๊๊ไࠢฦ๊ࠥะใาำࠣࠤ๋็ำࠡษ็ๅ฾๊ࠠศๆำ๎ࠥษูุษๆࠤฬ๊ๅีๅ็อࠥ࠴ࠠๅๅํࠤ๏ะๅࠡฬึะ๏๊่ࠠา๊ࠤฬ๊ๅีๅ็อࠥ็๊ࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣ࠲ࠥ๎ศะ๊้ࠤ์ึวࠡษ็ฮุา๊ๅࠢึ์ๆࠦสาี็ࠤ๊๊แࠡๆสࠤๆอฦะห้๋ࠣํࠠๅว้๋๊ࠥวࠡ์ะฮํ๐ฺࠠๆ์ࠤฬ๊ๅีๅ็อࠥอไห์ࠣฮึ๐ฯࠡษ้ฮࠥอไฦส็ห฿ูࠦ็้สࠤ࠳ࠦ็ๅࠢๅ้ฯࠦศหๅิหึࠦวๅ็ื็้ฯࠠภࠩ᏿"))
			if o07Z1tEB4n3ARCkVNu!=wRxoKs10Syj7V4edYhtP(u"࠷ᙤ"):
				aHKzv76JCVnprbY8w(SO94xq1RAkMm2uF(u"ࠪࠫ᐀"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࠬᐁ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬะๅࠡว็฾ฬวࠠศๆศีุอไࠨᐂ"),Cu1704YofAbr3QTm(u"࠭ไๅลึๅࠥฮฯ้่ࠣฮุา๊ๅࠢสฺ่๊ใๅหࠣๅ๏ࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡใส๊ࠥอไๆสิ้ัࠦไศࠢํืฯ฽ฺ๊่ࠢ฽ึ็ษࠡษ็ู้้ไส๋่ࠢฬࠦอๅ้สࠤ้อๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษࠩᐃ"))
				return
	aHKzv76JCVnprbY8w(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠧࠨᐄ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠨࠩᐅ"),Me28A1sBLNIgUp5YCDyvT(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᐆ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪๅ๏ࠦวๅึสุฮࠦวๅไสำ๊ฯࠠฮษ๋่ࠥษๆࠡฬๆฮอࠦัิษ็อࠥหไ๊ࠢส่๊ฮัๆฮࠣ์ฬฺัฮࠢไ๎์อࠠศๆุ่่๊ษࠡล๋ࠤฬ๊ๅุ้๋฽ࠥ๎ลัษࠣวึีสࠡฮ๋หอࠦๅ็ࠢส่๊ฮัๆฮࠣๅสึๆࠡลๆฮอูࠦ็๊ส๊ࠥฮั๋ัๆࠤศ๊ลๅๅอีํ์๊ࠡษ็ษ๏๋๊ๅ๋ࠢฮี้ั๊ࠡ็หࠥะๆิ๋ࠣว๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮࠧᐇ"))
	search = yMRXZIpKxlSkaE6iCO(header=SO94xq1RAkMm2uF(u"ࠫ࡜ࡸࡩࡵࡧࠣࡥࠥࡳࡥࡴࡵࡤ࡫ࡪ࡫ࠠࠡࠢส็ฯฮࠠาีส่ฮ࠭ᐈ"),source=cTJphS1nFz5EUgNWm86C)
	if not search: return
	LpdKxnIsY3Sy6qP = search
	if gIQPxaThXNYtL: type = xW2Arao7YVOemw(u"ࠬࡖࡲࡰࡤ࡯ࡩࡲ࠭ᐉ")
	else: type = FnBiAjthS8MkXs67W(u"࠭ࡍࡦࡵࡶࡥ࡬࡫ࠧᐊ")
	Tr8iRxJmbcEhftU5DSHzA = StXADUfOBwG413slo8VkK(type,LpdKxnIsY3Sy6qP,UTelCo0ihE1d5R(u"࡚ࡲࡶࡧᚱ"),iUeoLOsbHqP(u"ࠧࠨᐋ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠨࡇࡐࡅࡎࡒ࠭ࡇࡔࡒࡑ࠲࡛ࡓࡆࡔࡖࠫᐌ"),MMupPCxqkenwt6FlsbRILV37EAmB)
	return
def mHqa9szk4E5():
	MMupPCxqkenwt6FlsbRILV37EAmB = zqdvcbP5L8BHh(u"๊ࠩิฬࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏๎ฬะࠢ็๋ࠥษ๊ࠡีํีๆื๋ࠠีอฺ๏็ࠠฤ์้ࠣาะ่๋ษอ࠲ࠥอไษำ้ห๊า๋ࠠีอาิ๋ࠠา๊สฬ฼่ࠦหุ่๎๋ࠦไๆฯอ์๏อสࠡ็ิๅํ฿ษࠡ฻็ํู๊ࠥาใิหฯࠦฮศำฯ๎ฮ࠴ࠠศๆหี๋อๅอࠢ฽๎ึࠦๅิฦ๋่ࠥ฿ๆࠡลํࠤ๊ำส้์สฮࠥะๅࠡฬะ้๏๊็ศࠢ฼่๎ࠦำ๋ำไีฬะ้ࠠ็๋ห็฿ࠠฯษิะ๏ฯࠠࠣ็๋ห็฿ุࠠำไࠤะอไฬࠤ࠱ࠤัฺ๋๊ࠢส่ศูๅศรࠣ์ฬ๊ๅศำๆหฯ่ࠦศๆุ์ึ่ࠦศๆู่๊๎ัศฬ๋ࠣ๏ࠦฮศืฬࠤออีฮษห๋ฬ࠴ࠠศๆหี๋อๅอࠢ็หࠥ๐ๆห้ๆࠤา่่ใࠢส่฼ฮู๊ࠡสฺ่๋ั๊ࠡๅห๋๎ๆࠡษ็ว้็๊สࠢ็่๊๊ใ๋หࠣห้ืโๆ์ฬࠤࡉࡓࡃࡂࠢศิฬࠦใศ่่ࠣิ๐ใࠡึๆ์๎ࠦฮศืฬࠤออไา๊สฬ฼่ࠦศๆอฺฬ๋๊็ࠢส่ำอัอ์ฬࠤๆอไาฮสลࠥอไห๊สู้ࠦๅฺࠢศำฬืษ้ࠡำ๋ࠥอไิ์ิๅึอส๊ࠡส่๊๎วใ฻ࠣห้ิวาฮํอ࠳ࠦ็ัษࠣห้ฮั็ษ่ะࠥํ่ࠡสหืฬ฽ษࠡ็อูๆำࠠๅ็๋ห็฿ࠠศๆ๋๎อ࠭ᐍ")
	d0tNlv4Lbu2pqDaO1JfSEC9QIP5Xc(bUdr5Hahw6sY8xJ(u"ࠪࡶ࡮࡭ࡨࡵࠩᐎ"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫา่่ใࠢส่฼ฮู๊ࠡสฺ่๋ั๊ࠡๅห๋๎ๆࠡษ็ว้็๊สࠢ็่๊๊ใ๋หࠣห้ืโๆ์ฬࠫᐏ"),MMupPCxqkenwt6FlsbRILV37EAmB,fprnld4CZo(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨᐐ"))
	MMupPCxqkenwt6FlsbRILV37EAmB = XzrqbGDIy54juixkMA(u"࠭ࡔࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱࠥࡪ࡯ࡦࡵࠣࡲࡴࡺࠠࡩࡱࡶࡸࠥࡧ࡮ࡺࠢࡦࡳࡳࡺࡥ࡯ࡶࠣࡳࡳࠦࡡ࡯ࡻࠣࡷࡪࡸࡶࡦࡴ࠱ࠤࡎࡺࠠࡰࡰ࡯ࡽࠥࡻࡳࡦࡵࠣࡰ࡮ࡴ࡫ࡴࠢࡷࡳࠥ࡫࡭ࡣࡧࡧࡨࡪࡪࠠࡤࡱࡱࡸࡪࡴࡴࠡࡶ࡫ࡥࡹࠦࡷࡢࡵࠣࡹࡵࡲ࡯ࡢࡦࡨࡨࠥࡺ࡯ࠡࡲࡲࡴࡺࡲࡡࡳࠢࡲࡲࡱ࡯࡮ࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡪࡲࡷࡹ࡯࡮ࡨࠢࡶ࡭ࡹ࡫ࡳ࠯ࠢࡄࡰࡱࠦࡴࡳࡣࡧࡩࡲࡧࡲ࡬ࡵ࠯ࠤࡻ࡯ࡤࡦࡱࡶ࠰ࠥࡺࡲࡢࡦࡨࠤࡳࡧ࡭ࡦࡵ࠯ࠤࡸ࡫ࡲࡷ࡫ࡦࡩࠥࡳࡡࡳ࡭ࡶ࠰ࠥࡩ࡯ࡱࡻࡵ࡭࡬࡮ࡴࡦࡦࠣࡻࡴࡸ࡫࠭ࠢ࡯ࡳ࡬ࡵࡳࠡࡴࡨࡪࡪࡸࡥ࡯ࡥࡨࡨࠥ࡮ࡥࡳࡧ࡬ࡲࠥࡨࡥ࡭ࡱࡱ࡫ࠥࡺ࡯ࠡࡶ࡫ࡩ࡮ࡸࠠࡳࡧࡶࡴࡪࡩࡴࡪࡸࡨࠤࡴࡽ࡮ࡦࡴࡶࠤ࠴ࠦࡣࡰ࡯ࡳࡥࡳ࡯ࡥࡴ࠰ࠣࡘ࡭࡫ࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡ࡫ࡶࠤࡳࡵࡴࠡࡴࡨࡷࡵࡵ࡮ࡴ࡫ࡥࡰࡪࠦࡦࡰࡴࠣࡻ࡭ࡧࡴࠡࡱࡷ࡬ࡪࡸࠠࡱࡧࡲࡴࡱ࡫ࠠࡶࡲ࡯ࡳࡦࡪࠠࡵࡱࠣ࠷ࡷࡪࠠࡱࡣࡵࡸࡾࠦࡳࡪࡶࡨࡷ࠳ࠦࡗࡦࠢࡸࡶ࡬࡫ࠠࡢ࡮࡯ࠤࡨࡵࡰࡺࡴ࡬࡫࡭ࡺࠠࡰࡹࡱࡩࡷࡹࠬࠡࡶࡲࠤࡷ࡫ࡣࡰࡩࡱ࡭ࡿ࡫ࠠࡵࡪࡤࡸࠥࡺࡨࡦࠢ࡯࡭ࡳࡱࡳࠡࡥࡲࡲࡹࡧࡩ࡯ࡧࡧࠤࡼ࡯ࡴࡩ࡫ࡱࠤࡹ࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠣࡥࡷ࡫ࠠ࡭ࡱࡦࡥࡹ࡫ࡤࠡࡵࡲࡱࡪࡽࡨࡦࡴࡨࠤࡪࡲࡳࡦࠢࡲࡲࠥࡺࡨࡦࠢࡺࡩࡧࠦ࡯ࡳࠢࡹ࡭ࡩ࡫࡯ࠡࡧࡰࡦࡪࡪࡤࡦࡦࠣࡥࡷ࡫ࠠࡧࡴࡲࡱࠥࡵࡴࡩࡧࡵࠤࡻࡧࡲࡪࡱࡸࡷࠥࡹࡩࡵࡧࡶ࠲ࠥࡏࡦࠡࡻࡲࡹࠥ࡮ࡡࡷࡧࠣࡥࡳࡿࠠ࡭ࡧࡪࡥࡱࠦࡩࡴࡵࡸࡩࡸࠦࡰ࡭ࡧࡤࡷࡪࠦࡣࡰࡰࡷࡥࡨࡺࠠࡢࡲࡳࡶࡴࡶࡲࡪࡣࡷࡩࠥࡳࡥࡥ࡫ࡤࠤ࡫࡯࡬ࡦࠢࡲࡻࡳ࡫ࡲࡴࠢ࠲ࠤ࡭ࡵࡳࡵࡧࡵࡷ࠳ࠦࡔࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱࠥ࡯ࡳࠡࡵ࡬ࡱࡵࡲࡹࠡࡣࠣࡻࡪࡨࠠࡣࡴࡲࡻࡸ࡫ࡲ࠯ࠩᐑ")
	d0tNlv4Lbu2pqDaO1JfSEC9QIP5Xc(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧ࡭ࡧࡩࡸࠬᐒ"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠨࡆ࡬࡫࡮ࡺࡡ࡭ࠢࡐ࡭ࡱࡲࡥ࡯ࡰ࡬ࡹࡲࠦࡃࡰࡲࡼࡶ࡮࡭ࡨࡵࠢࡄࡧࡹࠦࠨࡅࡏࡆࡅ࠮࠭ᐓ"),MMupPCxqkenwt6FlsbRILV37EAmB,Cu1704YofAbr3QTm(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬᐔ"))
	return
def EJiphk0Sbjn(ssZLBRtgnMkc7dSouQeGCx3r8m):
	IJuVYdzmgy1AUtiKGfqWcv = cEZpW924rqNYm5.executeJSONRPC(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡄࡨࡩࡵ࡮ࡴ࠰ࡖࡩࡹࡇࡤࡥࡱࡱࡉࡳࡧࡢ࡭ࡧࡧࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡤࡨࡩࡵ࡮ࡪࡦࠥ࠾ࠧ࠭ᐕ")+ssZLBRtgnMkc7dSouQeGCx3r8m+g4g6bfkPtVGU5lIM3(u"ࠫࠧ࠲ࠢࡦࡰࡤࡦࡱ࡫ࡤࠣ࠼ࡩࡥࡱࡹࡥࡾࡿࠪᐖ"))
	gGudVm2TlMnyh = SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࡔࡳࡷࡨᚲ")
	if gGudVm2TlMnyh:
		MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠱ᙥ"))
		cEZpW924rqNYm5.executebuiltin(lc0dpSmwoPDjLnk(u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩᐗ"))
		MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠲ᙦ"))
	return
def H5QDuUbft4NilgahprLAx():
	aHKzv76JCVnprbY8w(FvNyZqaLKw(u"࠭ࠧᐘ"),g4g6bfkPtVGU5lIM3(u"ࠧࠨᐙ"),UTelCo0ihE1d5R(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᐚ"),fprnld4CZo(u"ࠩส่อืๆศ็ฯࠤ้อ๋ࠠใะฺูࠥ็ศัฬࠤฬ๊สีใํีࠥ฿ๆะࠢส่ฬะีศๆࠣฬฬ๊ๅ้ษๅ฽ࠥอไๆึไีฮ่ࠦๅ้ำหࠥ็๊ࠡฯส่ࠥ๎ฬ้ัุࠣ์อฯสࠢ฽๎ึࠦีฮ์ะอࠥษ่ࠡ็้ฮ์๐ษࠡษ็ู้ออ๋หࠣวํࠦๅำ์ไอࠥ็ว็๊ࠢิฬࠦไ็ࠢํ์็็ࠠศๆิฬ฼ࠦวๅ็ืๅึ่ࠦๅ่ࠣ๎ํ่แࠡ฻่่ࠥอไษำ้ห๊าࠧᐛ"))
	UAYdBOy7iFb2nQVfJk()
	return
def q4OV92sRG3EfDedmwUpKAI():
	url = g4g6bfkPtVGU5lIM3(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱ࡮ࡸࡲࡰࡴࡶ࠲ࡰࡵࡤࡪ࠰ࡷࡺ࠴ࡸࡥ࡭ࡧࡤࡷࡪࡹ࠯ࡸ࡫ࡱࡨࡴࡽࡳ࠰ࡹ࡬ࡲ࠻࠺࠯ࠨᐜ")
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,zqdvcbP5L8BHh(u"ࠫࡌࡋࡔࠨᐝ"),url,sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬ࠭ᐞ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ࠧᐟ"),FnBiAjthS8MkXs67W(u"ࠧࠨᐠ"),SO94xq1RAkMm2uF(u"ࠨࠩᐡ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡘࡎࡏࡘࡡࡏࡅ࡙ࡋࡓࡕࡡࡎࡓࡉࡏ࡟ࡗࡇࡕࡗࡎࡕࡎ࠮࠳ࡶࡸࠬᐢ"))
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	DUZ51WhabwG = GGvHJKP9LUxEk10Fw.findall(dshJSmRqeiP9nap2(u"ࠪࡸ࡮ࡺ࡬ࡦ࠿ࠥ࡯ࡴࡪࡩ࠮ࠪ࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠱ࡠࡧ࠭ࡻࡃ࠰࡞ࡢ࠱ࠩ࠮ࠩᐣ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	DUZ51WhabwG = DUZ51WhabwG[lc0dpSmwoPDjLnk(u"࠲ᙧ")].split(hBvsQ7oCkKUdwjx58ml3EN(u"ࠫ࠲࠭ᐤ"))[lc0dpSmwoPDjLnk(u"࠲ᙧ")]
	P4aO0HujrfGM = str(yMvF9GoTjhU5biA)
	ZIGlKA0aOBfFuonWj = FnBiAjthS8MkXs67W(u"ࠬࡡࡒࡕࡎࡠษฺีวาࠢๆ์ิ๐ࠠศๆฦา๏ืࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤࠥࠦࠧᐥ")+xW2Arao7YVOemw(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩᐦ")+DUZ51WhabwG+UTelCo0ihE1d5R(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᐧ")
	ZIGlKA0aOBfFuonWj += sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨ࡞ࡱࡠࡳ࠭ᐨ")+yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩ࡞ࡖ࡙ࡒ࡝ฦืาหึࠦใ้ัํࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํ่๊ࠠࠣ࠾ࠥࠦࠠࠨᐩ")+LiRcTVUWuth70DmPy(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ᐪ")+P4aO0HujrfGM+sTcr7iDp5eFt4RoLMhuwq1A(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᐫ")
	aHKzv76JCVnprbY8w(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠬ࠭ᐬ"),UTelCo0ihE1d5R(u"࠭ࠧᐭ"),wRxoKs10Syj7V4edYhtP(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᐮ"),ZIGlKA0aOBfFuonWj)
	return
def Vhbvf1XcqnE7TUksM28PLC():
	Wu6THcbvsRZdXSz4nwlCVy,bdzvPE1KBTfkMj04QAG5hY7ouqZD,eFQXmOopl5Gfd,ZIGlKA0aOBfFuonWj,GukL4Sx2VNzF8jYn7T3qoOh1iwt,os7F5jD1OnkbZJxqmSGTazMg80vP,BSq5W6n8upGomKMj7Ets04rg1NkHYb = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࠩᐯ"),bUdr5Hahw6sY8xJ(u"ࠩࠪᐰ"),LiRcTVUWuth70DmPy(u"ࠪࠫᐱ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࠬᐲ"),Cu1704YofAbr3QTm(u"ࠬ࠭ᐳ"),lc0dpSmwoPDjLnk(u"࠭ࠧᐴ"),lc0dpSmwoPDjLnk(u"ࠧࠨᐵ")
	vpWXJDC4lTByaqcn56OFwUmieV,WiazdltShCXE5B4rqP2,r5XxH6oE4dyzNp2,cnCdw1NOlS26rax7h4MQiezDpvHgE = {FvNyZqaLKw(u"ࠨࡣࠪᐶ"):lc0dpSmwoPDjLnk(u"ࠩࡤࠫᐷ")},{},[],{}
	url = oSVpce1UQYrDqhuM6PT[bUdr5Hahw6sY8xJ(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪᐸ")][SO94xq1RAkMm2uF(u"࠴ᙨ")]
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(X9mvsOYNPGeWdaIw01Mf4Jz5p,S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࡕࡕࡓࡕࠩᐹ"),url,vpWXJDC4lTByaqcn56OFwUmieV,wRxoKs10Syj7V4edYhtP(u"ࠬ࠭ᐺ"),dshJSmRqeiP9nap2(u"࠭ࠧᐻ"),iUeoLOsbHqP(u"ࠧࠨᐼ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰࡙ࡘࡇࡇࡆࡡࡕࡉࡕࡕࡒࡕ࠯࠴ࡷࡹ࠭ᐽ"))
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	BBlXpmUyhFDwNtCVAHoE = BBlXpmUyhFDwNtCVAHoE.replace(hBvsQ7oCkKUdwjx58ml3EN(u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡖࡸࡦࡺࡥࡴࠩᐾ"),XzrqbGDIy54juixkMA(u"࡙ࠪࡘࡇࠧᐿ"))
	BBlXpmUyhFDwNtCVAHoE = BBlXpmUyhFDwNtCVAHoE.replace(dshJSmRqeiP9nap2(u"࡚ࠫࡴࡩࡵࡧࡧࠤࡐ࡯࡮ࡨࡦࡲࡱࠬᑀ"),LiRcTVUWuth70DmPy(u"࡛ࠬࡋࠨᑁ"))
	BBlXpmUyhFDwNtCVAHoE = BBlXpmUyhFDwNtCVAHoE.replace(dshJSmRqeiP9nap2(u"࠭ࡕ࡯࡫ࡷࡩࡩࠦࡁࡳࡣࡥࠤࡊࡳࡩࡳࡣࡷࡩࡸ࠭ᑂ"),xW2Arao7YVOemw(u"ࠧࡖࡃࡈࠫᑃ"))
	BBlXpmUyhFDwNtCVAHoE = BBlXpmUyhFDwNtCVAHoE.replace(iRoLg2m47tnDATBHGCSPNyx(u"ࠨࡕࡤࡹࡩ࡯ࠠࡂࡴࡤࡦ࡮ࡧࠧᑄ"),iUeoLOsbHqP(u"ࠩࡎࡗࡆ࠭ᑅ"))
	BBlXpmUyhFDwNtCVAHoE = BBlXpmUyhFDwNtCVAHoE.replace(zqdvcbP5L8BHh(u"ࠪࡒࡴࡸࡴࡩࠢࡐࡥࡨ࡫ࡤࡰࡰ࡬ࡥࠬᑆ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࡓ࠴ࡍࡢࡥࡨࡨࡴࡴࡩࡢࠩᑇ"))
	BBlXpmUyhFDwNtCVAHoE = BBlXpmUyhFDwNtCVAHoE.replace(hBvsQ7oCkKUdwjx58ml3EN(u"ࠬ࡝ࡥࡴࡶࡨࡶࡳࠦࡓࡢࡪࡤࡶࡦ࠭ᑈ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ࡗ࠯ࡕࡤ࡬ࡦࡸࡡࠨᑉ"))
	BBlXpmUyhFDwNtCVAHoE = BBlXpmUyhFDwNtCVAHoE.replace(FnBiAjthS8MkXs67W(u"ࠧࡠࡡࡢࠫᑊ"),XzrqbGDIy54juixkMA(u"ࠨࠢࠣࠫᑋ"))
	try: PhYGt9VE4kNFMbDqUfozjrd = JKw5OWktPZB(Me28A1sBLNIgUp5YCDyvT(u"ࠩ࡯࡭ࡸࡺࠧᑌ"),BBlXpmUyhFDwNtCVAHoE)
	except:
		aHKzv76JCVnprbY8w(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪࠫᑍ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫࠬᑎ"),p72fnFtcPix5UKwr9YNzW(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᑏ"),SO94xq1RAkMm2uF(u"࠭แีๆࠣๅ๏ࠦฬๅส้ࠣาะ่๋ษอࠤฯ่ั๋ำࠣห้อำหะาห๊࠭ᑐ"))
		return
	ZjVK8TRH56En1ikIX7sNSL,Xtn4FMkubl1LjmVUNKE2ex,CcfamnXqhEUMF6LBxktSOwzyV3ePpb = PhYGt9VE4kNFMbDqUfozjrd
	cnCdw1NOlS26rax7h4MQiezDpvHgE = {}
	PIA0WgYncKZOu1xrh6k = [hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࡄࡃࡓࡘࡈࡎࡁࡊࡆࠪᑑ"),zqdvcbP5L8BHh(u"ࠨࡅࡄࡔ࡙ࡉࡈࡂࡖࡒࡏࡊࡔࠧᑒ")]
	DcVrPLIWsNZ = [SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠩࡄࡐࡑ࠭ᑓ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪᑔ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠫࡎࡔࡓࡕࡃࡏࡐࠬᑕ"),LiRcTVUWuth70DmPy(u"ࠬࡓࡅࡕࡔࡒࡔࡔࡒࡉࡔࠩᑖ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"࠭ࡒࡆࡒࡒࡗࠬᑗ")]+PIA0WgYncKZOu1xrh6k+ZVrQewF1XiazvmI7oYnbMW+lZU9W7XhDxpeSA56vgQdi0
	for jXPWwl4aH0OR9ILzMT5usS,YK0l5yOPt3V,rskChBoQaLHJNKMwAidI4 in Xtn4FMkubl1LjmVUNKE2ex:
		rskChBoQaLHJNKMwAidI4 = ptMqV54oKJhQ8CH(rskChBoQaLHJNKMwAidI4)
		rskChBoQaLHJNKMwAidI4 = rskChBoQaLHJNKMwAidI4.strip(g4g6bfkPtVGU5lIM3(u"ࠧࠡࠩᑘ")).strip(Cu1704YofAbr3QTm(u"ࠨࠢ࠱ࠫᑙ"))
		ZIGlKA0aOBfFuonWj += Me28A1sBLNIgUp5YCDyvT(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧᑚ")+jXPWwl4aH0OR9ILzMT5usS+fprnld4CZo(u"ࠪ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᑛ")+rskChBoQaLHJNKMwAidI4+XzrqbGDIy54juixkMA(u"ࠫࡡࡴࠧᑜ")
		if YK0l5yOPt3V.isdigit():
			cnCdw1NOlS26rax7h4MQiezDpvHgE[jXPWwl4aH0OR9ILzMT5usS] = int(YK0l5yOPt3V)
			if int(YK0l5yOPt3V)>FnBiAjthS8MkXs67W(u"࠵࠵࠶ᙩ"): YK0l5yOPt3V = fprnld4CZo(u"ࠬ࡮ࡩࡨࡪࡸࡷࡦ࡭ࡥࠨᑝ")
			else: YK0l5yOPt3V = Me28A1sBLNIgUp5YCDyvT(u"࠭࡬ࡰࡹࡸࡷࡦ࡭ࡥࠨᑞ")
		if jXPWwl4aH0OR9ILzMT5usS not in DcVrPLIWsNZ:
			if   YK0l5yOPt3V==wRxoKs10Syj7V4edYhtP(u"ࠧࡩ࡫ࡪ࡬ࡺࡹࡡࡨࡧࠪᑟ"): Wu6THcbvsRZdXSz4nwlCVy += l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨࠢࠣࠫᑠ")+jXPWwl4aH0OR9ILzMT5usS
			elif YK0l5yOPt3V==sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩ࡯ࡳࡼࡻࡳࡢࡩࡨࠫᑡ"): bdzvPE1KBTfkMj04QAG5hY7ouqZD += l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࠤࠥ࠭ᑢ")+jXPWwl4aH0OR9ILzMT5usS
	T4Mrv5bL3VZ9sxjopPUl1aCW,FRfhyumljt,ttpiI05PJnTNUvxhr98CwFlSBH = list(zip(*Xtn4FMkubl1LjmVUNKE2ex))
	for jXPWwl4aH0OR9ILzMT5usS in sorted(jjJZia6HOo2xFudTmtsyDVM5):
		if jXPWwl4aH0OR9ILzMT5usS not in T4Mrv5bL3VZ9sxjopPUl1aCW:
			ZIGlKA0aOBfFuonWj += sTcr7iDp5eFt4RoLMhuwq1A(u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩᑣ")+jXPWwl4aH0OR9ILzMT5usS+Me28A1sBLNIgUp5YCDyvT(u"ࠬࡀࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᑤ")+Cu1704YofAbr3QTm(u"࠭ไศࠢํ์ัีࠧᑥ")+LiRcTVUWuth70DmPy(u"ࠧ࡝ࡰ࡟ࡲࠬᑦ")
			if jXPWwl4aH0OR9ILzMT5usS not in DcVrPLIWsNZ: eFQXmOopl5Gfd += E6MIKdpBomef(u"ࠨࠢࠣࠫᑧ")+jXPWwl4aH0OR9ILzMT5usS
	for rskChBoQaLHJNKMwAidI4,NOcFpG4d02xz in ZjVK8TRH56En1ikIX7sNSL:
		rskChBoQaLHJNKMwAidI4 = ptMqV54oKJhQ8CH(rskChBoQaLHJNKMwAidI4)
		GukL4Sx2VNzF8jYn7T3qoOh1iwt += rskChBoQaLHJNKMwAidI4+SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠩ࠽ࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧᑨ")+str(NOcFpG4d02xz)+YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࠦࠠࠨᑩ")
	Wu6THcbvsRZdXSz4nwlCVy = Wu6THcbvsRZdXSz4nwlCVy.strip(fprnld4CZo(u"ࠫࠥ࠭ᑪ"))
	bdzvPE1KBTfkMj04QAG5hY7ouqZD = bdzvPE1KBTfkMj04QAG5hY7ouqZD.strip(iRoLg2m47tnDATBHGCSPNyx(u"ࠬࠦࠧᑫ"))
	eFQXmOopl5Gfd = eFQXmOopl5Gfd.strip(dshJSmRqeiP9nap2(u"࠭ࠠࠨᑬ"))
	GMhYVPfz79To = Wu6THcbvsRZdXSz4nwlCVy+fprnld4CZo(u"ࠧࠡࠢࠪᑭ")+bdzvPE1KBTfkMj04QAG5hY7ouqZD
	FCkpbo9fVRaiHum3U  = E6MIKdpBomef(u"ࠨ็๋ห็฿ࠠ็ฮะࠤฬ๊ศา่ส้ัࠦศหึ฽๎้ࠦแ๋ัํ์์อสࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠬᑮ")+dshJSmRqeiP9nap2(u"ࠩ࡟ࡲࠬᑯ")+FnBiAjthS8MkXs67W(u"ࠪ์์ึวࠡ็฼๊ฬํࠠฦาสࠤ้ี๊ไุ่่๊ࠢษࠡใ๊๎๊๊ࠥิฬ้๋ࠣࠦวๅสิ๊ฬ๋ฬࠨᑰ")+fprnld4CZo(u"ࠫࡡࡴࠧᑱ")
	FCkpbo9fVRaiHum3U += FvNyZqaLKw(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨᑲ")+GMhYVPfz79To+Cu1704YofAbr3QTm(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ࡟ࡲࠬᑳ")
	FCkpbo9fVRaiHum3U += sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧๆ๊สๆ฾ࠦไๆࠢํุ฿๊ࠠศๆหี๋อๅอ่๊ࠢ์อࠠโ์า๎ํํวหࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮ࠭ᑴ")+SO94xq1RAkMm2uF(u"ࠨ࡞ࡱࠫᑵ")+hBvsQ7oCkKUdwjx58ml3EN(u"๋๋ࠩีอࠠๆ฻้ห์ࠦวฮฬ่ห้ࠦใษ์ิࠤํา่ะุ่่๊ࠢษࠡใํࠤฬ๊ศา่ส้ั࠭ᑶ")+xW2Arao7YVOemw(u"ࠪࡠࡳ࠭ᑷ")
	FCkpbo9fVRaiHum3U += zqdvcbP5L8BHh(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧᑸ")+eFQXmOopl5Gfd+wRxoKs10Syj7V4edYhtP(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᑹ")
	AnMsbQ6Ehkwf5Uq8dBxJT1Pu4YSD,cYUfIWnqPH41EsiF0T,heSxjQi4a8Kv2HOwmVuZcB7gCDT5b,kkqEshmoPwrxtRTvgIH = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠵ᙪ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠵ᙪ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠵ᙪ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠵ᙪ")
	all = cnCdw1NOlS26rax7h4MQiezDpvHgE[SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࡁࡍࡎࠪᑺ")]
	if hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧᑻ") in list(cnCdw1NOlS26rax7h4MQiezDpvHgE.keys()): AnMsbQ6Ehkwf5Uq8dBxJT1Pu4YSD = cnCdw1NOlS26rax7h4MQiezDpvHgE[sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨᑼ")]
	if l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠩࡌࡒࡘ࡚ࡁࡍࡎࠪᑽ") in list(cnCdw1NOlS26rax7h4MQiezDpvHgE.keys()): cYUfIWnqPH41EsiF0T = cnCdw1NOlS26rax7h4MQiezDpvHgE[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪࡍࡓ࡙ࡔࡂࡎࡏࠫᑾ")]
	if pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࡒࡋࡔࡓࡑࡓࡓࡑࡏࡓࠨᑿ") in list(cnCdw1NOlS26rax7h4MQiezDpvHgE.keys()): heSxjQi4a8Kv2HOwmVuZcB7gCDT5b = cnCdw1NOlS26rax7h4MQiezDpvHgE[kEhAHvti6Vnsfx(u"ࠬࡓࡅࡕࡔࡒࡔࡔࡒࡉࡔࠩᒀ")]
	if xW2Arao7YVOemw(u"࠭ࡒࡆࡒࡒࡗࠬᒁ") in list(cnCdw1NOlS26rax7h4MQiezDpvHgE.keys()): kkqEshmoPwrxtRTvgIH = cnCdw1NOlS26rax7h4MQiezDpvHgE[bUdr5Hahw6sY8xJ(u"ࠧࡓࡇࡓࡓࡘ࠭ᒂ")]
	xYAh3Bo5CNdmVyicrSq = all-AnMsbQ6Ehkwf5Uq8dBxJT1Pu4YSD-cYUfIWnqPH41EsiF0T-heSxjQi4a8Kv2HOwmVuZcB7gCDT5b-kkqEshmoPwrxtRTvgIH
	X4XyOPCEu65AMYebxwaVW,cLSK63uf4XapnCyW5vgobx2wMhVJr = CcfamnXqhEUMF6LBxktSOwzyV3ePpb[g4g6bfkPtVGU5lIM3(u"࠶ᙫ")]
	X4XyOPCEu65AMYebxwaVW,MM5T9tBNykuhar1SP8 = CcfamnXqhEUMF6LBxktSOwzyV3ePpb[Cu1704YofAbr3QTm(u"࠱ᙬ")]
	hBZ57S2LJzpYrCiVNf3 = cLSK63uf4XapnCyW5vgobx2wMhVJr-MM5T9tBNykuhar1SP8
	BSq5W6n8upGomKMj7Ets04rg1NkHYb += hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫᒃ")+str(MM5T9tBNykuhar1SP8)+E6MIKdpBomef(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᒄ")+lc0dpSmwoPDjLnk(u"ࠪห้฿ฯะࠢส่า่๊ใ์่้ࠣษฬ่ิฬࠤ࠿ࠦࠧᒅ")
	BSq5W6n8upGomKMj7Ets04rg1NkHYb += wRxoKs10Syj7V4edYhtP(u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩᒆ")+str(hBZ57S2LJzpYrCiVNf3)+SO94xq1RAkMm2uF(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᒇ")+YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ศศีอาิอๅࠡࡲࡵࡳࡽࡿࠠฤ๊ࠣࡺࡵࡴࠠ࠻ࠢࠪᒈ")
	BSq5W6n8upGomKMj7Ets04rg1NkHYb += l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬᒉ")+str(cLSK63uf4XapnCyW5vgobx2wMhVJr)+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᒊ")+fprnld4CZo(u"ࠩส่฾ีฯࠡษ็็้๐ࠠๅฮ่๎฾ࠦวๅลฯ๋ืฯࠠ࠻ࠢࠪᒋ")
	BSq5W6n8upGomKMj7Ets04rg1NkHYb += XzrqbGDIy54juixkMA(u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨᒌ")+str(len(CcfamnXqhEUMF6LBxktSOwzyV3ePpb[fprnld4CZo(u"࠳᙭"):]))+lc0dpSmwoPDjLnk(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᒍ")+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠬ฿ฯะࠢส่ิ๎ไࠡษ็ฮ๏ࠦแ๋้สࠤศา็ำหࠣ࠾ࠥࡢ࡮࡝ࡰࠪᒎ")
	for CP2iXvM97DK6ZcNwFl8B,exOIZnGECcR2p3WV4TPY06BNDo7 in CcfamnXqhEUMF6LBxktSOwzyV3ePpb[kEhAHvti6Vnsfx(u"࠴᙮"):]:
		CP2iXvM97DK6ZcNwFl8B = ptMqV54oKJhQ8CH(CP2iXvM97DK6ZcNwFl8B)
		CP2iXvM97DK6ZcNwFl8B = CP2iXvM97DK6ZcNwFl8B.strip(yA5z6LIXBlo41PRVMY87wOisFp(u"࠭ࠠࠨᒏ")).strip(wRxoKs10Syj7V4edYhtP(u"ࠧࠡ࠰ࠪᒐ"))
		BSq5W6n8upGomKMj7Ets04rg1NkHYb += CP2iXvM97DK6ZcNwFl8B+zqdvcbP5L8BHh(u"ࠨ࠼ࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭ᒑ")+str(exOIZnGECcR2p3WV4TPY06BNDo7)+Cu1704YofAbr3QTm(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࠥࠦࠧᒒ")
	os7F5jD1OnkbZJxqmSGTazMg80vP += UTelCo0ihE1d5R(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ᒓ")+str(xYAh3Bo5CNdmVyicrSq)+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᒔ")+kEhAHvti6Vnsfx(u"ࠬ็๊ะ์๋๋ฬะࠠศึอ฾้ะࠠ࠻ࠢࠪᒕ")
	os7F5jD1OnkbZJxqmSGTazMg80vP += zqdvcbP5L8BHh(u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫᒖ")+str(AnMsbQ6Ehkwf5Uq8dBxJT1Pu4YSD)+iUeoLOsbHqP(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᒗ")+kEhAHvti6Vnsfx(u"ࠨู็ฬฬะࠠิ์ิๅึࠦศศ์ฮ์๋ࠦ࠺ࠡࠩᒘ")
	os7F5jD1OnkbZJxqmSGTazMg80vP += lc0dpSmwoPDjLnk(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧᒙ")+str(kkqEshmoPwrxtRTvgIH)+iRoLg2m47tnDATBHGCSPNyx(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᒚ")+XzrqbGDIy54juixkMA(u"ࠫ฼๊ศศฬࠣื๏ืแาࠢสู่๊ส้ั฼ࠤ࠿ࠦࠧᒛ")
	os7F5jD1OnkbZJxqmSGTazMg80vP += Cu1704YofAbr3QTm(u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪᒜ")+str(cYUfIWnqPH41EsiF0T)+zqdvcbP5L8BHh(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨᒝ")+g4g6bfkPtVGU5lIM3(u"ࠧหอห๎ฯࠦสุสํๆ้่ࠥะ์ࠣ฽๊อฯࠡ࠼ࠣࠫᒞ")
	os7F5jD1OnkbZJxqmSGTazMg80vP += UTelCo0ihE1d5R(u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ᒟ")+str(heSxjQi4a8Kv2HOwmVuZcB7gCDT5b)+XzrqbGDIy54juixkMA(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᒠ")+UTelCo0ihE1d5R(u"ࠪฮะฮ๊หࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠺ࠡࠩᒡ")
	os7F5jD1OnkbZJxqmSGTazMg80vP += UTelCo0ihE1d5R(u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩᒢ")+str(len(ZjVK8TRH56En1ikIX7sNSL))+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᒣ")+zqdvcbP5L8BHh(u"࠭ฯ้ๆุࠣ฿๊สࠡใํำ๏๎็ศฬࠣ࠾ࠥ࠭ᒤ")
	os7F5jD1OnkbZJxqmSGTazMg80vP += xW2Arao7YVOemw(u"ࠧ࡝ࡰ࡟ࡲࠬᒥ")+GukL4Sx2VNzF8jYn7T3qoOh1iwt
	d0tNlv4Lbu2pqDaO1JfSEC9QIP5Xc(zqdvcbP5L8BHh(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᒦ"),wRxoKs10Syj7V4edYhtP(u"ࠩ฼ำิࠦวๅลฯ๋ืฯࠠศๆอ๎ࠥอำหะา้ฯࠦ็ัษࠣห้ฮั็ษ่ะࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠢไ๎ࠥอไฺษ็้้ࠥไ่ࠩᒧ"),BSq5W6n8upGomKMj7Ets04rg1NkHYb,kEhAHvti6Vnsfx(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ᒨ"))
	d0tNlv4Lbu2pqDaO1JfSEC9QIP5Xc(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᒩ"),g4g6bfkPtVGU5lIM3(u"ࠬ฿ฯะࠢส่ๆ๐ฯ๋๊๊หฯࠦวๅฬํࠤูเไ่ษ๋ࠣีอࠠศๆหี๋อๅอࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮࠦแ๋ࠢส่฾อไๆࠢๆ่์࠭ᒪ"),os7F5jD1OnkbZJxqmSGTazMg80vP,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩᒫ"))
	d0tNlv4Lbu2pqDaO1JfSEC9QIP5Xc(Me28A1sBLNIgUp5YCDyvT(u"ࠧࡤࡧࡱࡸࡪࡸࠧᒬ"),SO94xq1RAkMm2uF(u"ࠨ็๋ห็฿ࠠศึอ฾้ะࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠤๆ๐ࠠศๆ฼ห้๋ࠠไๆ๊ࠫᒭ"),FCkpbo9fVRaiHum3U,sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬᒮ"))
	d0tNlv4Lbu2pqDaO1JfSEC9QIP5Xc(lc0dpSmwoPDjLnk(u"ࠪࡰࡪ࡬ࡴࠨᒯ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠫศ฿ไ๊ࠢส่ิ๎ไࠡษ็ฮ๏ࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠣหุะฮะ็อࠤฬ๊ศา่ส้ั࠭ᒰ"),ZIGlKA0aOBfFuonWj,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭ᒱ"))
	return
def kRXgjTnwVeoJ0PD():
	LpdKxnIsY3Sy6qP = SO94xq1RAkMm2uF(u"࠭็ัษࠣห้ฮั็ษ่ะࠥ๐ูๆๆࠣหๆ฼ไࠡสสืฯิฯศ็ࠣะ้ีࠠไ๊า๎ࠥ࠮ࡋࡰࡦ࡬ࠤࡘࡱࡩ࡯ࠫࠣห้ึ๊ࠡษึ้์ࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄ࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࡠࡳࡢ࡮๊่้่ࠡ์ࠠหอห๎ฯํࠠษษึฮำีวๆ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠࡆࡏࡄࡈࠥࡘࡥࡱࡱࡶ࡭ࡹࡵࡲࡺࠢฦ์ࠥะอๆ์็๋๋ࠥๆ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮࡝ࡰ࡟ࡲࠥํะ่ࠢส่ึูวๅหࠣ์฿๐ั่ษࠣ็ะ๐ัࠡ็๋ะํีษࠡใํࠤ็อฦๆหࠣาิ๋วหࠢส่อืๆศ็ฯࠤํอไๆิํำࠥษ๊ืษ้ࠣํา่ะࠢไ๎่ࠥวว็ฬࠤศา่ษหࠣห้ฮั็ษ่ะࠬᒲ")
	d0tNlv4Lbu2pqDaO1JfSEC9QIP5Xc(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠧࡤࡧࡱࡸࡪࡸࠧᒳ"),xW2Arao7YVOemw(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᒴ"),LpdKxnIsY3Sy6qP,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬᒵ"))
	return
def AA6dYxswFGyI1zcN7kB82Rh9O():
	LpdKxnIsY3Sy6qP = Cu1704YofAbr3QTm(u"ࠪห้ืวษูํ๊ࠥษฯ็ษ๊ࠤๆ๐็ๆษࠣฮ฼ฮ๊ใࠢๆ์ิ๐ฺࠠ็สำࠥ๎็้ࠢ฼ฬฬืษࠡ฻้ࠤฯัศ๋ฬࠣ็ฬ๋ไࠡษ๋ฮํ๋วห์ๆ๎๊ࠥศา่ส้ัࠦใ้ัํࠤํู๋่ࠢสฺฬ็ษࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠤํู๋่ࠢสฺฬ็ษࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ๎ๅฺ้ࠣห฻อแส่ࠢืฯ๎ฯฺࠢ฼้ฬี้ࠠใํ๋ࠥษ๊ืษࠣะ๊๐ูࠡษ฼ำฬีสࠡๅ๋ำ๏ࠦวๅ็ฺ่ํฮษࠡๆ฼้้ࠦศา่ส้ัูࠦๆษาࠤํ้ไ่ษࠣฮฯ๋ࠠศ๊อ์๊อส๋ๅํหࠥ๎ไศࠢอัฯอฬࠡลํࠤ๋๎ูࠡ็้ࠤฬ๊ฮษำฬࠤๆ๐ࠠไ๊า๎ࠥษ่ࠡษ็าอืษࠡใํࠤฯัศ๋ฬࠣว฻อแศฬࠣ็ํี๊ࠨᒶ")+FvNyZqaLKw(u"ࠫࡡࡴࠧᒷ")+p72fnFtcPix5UKwr9YNzW(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨᒸ")+oSVpce1UQYrDqhuM6PT[lc0dpSmwoPDjLnk(u"࠭ࡋࡐࡆࡌࡉࡒࡇࡄࡠࡃࡓࡔࠬᒹ")][xW2Arao7YVOemw(u"࠴ᙰ")]+yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢࠣࠤࠥࠦࠠฤ๊ࠣࠤࠥࠦࠠࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫᒺ")+oSVpce1UQYrDqhuM6PT[fprnld4CZo(u"ࠨࡍࡒࡈࡎࡋࡍࡂࡆࡢࡅࡕࡖࠧᒻ")][E6MIKdpBomef(u"࠴ᙯ")]+iUeoLOsbHqP(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᒼ")
	LpdKxnIsY3Sy6qP += YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪࡠࡳࡢ࡮࡝ࡰส่ึอศุࠢฦำ๋อ็้๋ࠡࠤฬ๊ำ้ำึࠤฬ๊ะ๋ࠢํัฯอฬ่่ࠢำ๏ืࠠๆๆไหฯࠦใ้ัํࠤ้ะหษ์อࠤอืๆศ็ฯࠤ฾๋วะࠢหห้฽ั๋ไฬࠤฬ๊สใๆํำ๏ฯࠠศๆๅำ๏๋ษ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬᒽ")+oSVpce1UQYrDqhuM6PT[iRoLg2m47tnDATBHGCSPNyx(u"ࠫࡘࡕࡕࡓࡅࡈࡗࠬᒾ")][wRxoKs10Syj7V4edYhtP(u"࠶ᙱ")]+S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᒿ")
	LpdKxnIsY3Sy6qP += lc0dpSmwoPDjLnk(u"࠭࡜࡯࡞ࡱࡠࡳาๅ๋฻้้ࠣ็วหࠢ฼้ฬีࠠๆ๊ฯ์ิฯࠠโ์ࠣห้๋่ใ฻ࠣวิ์ว่ࠩᓀ")+Me28A1sBLNIgUp5YCDyvT(u"ࠧ࡝ࡰࠪᓁ")+SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫᓂ")+oSVpce1UQYrDqhuM6PT[SO94xq1RAkMm2uF(u"ࠩࡖࡓ࡚ࡘࡃࡆࡕࠪᓃ")][hBvsQ7oCkKUdwjx58ml3EN(u"࠸ᙲ")]+dshJSmRqeiP9nap2(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᓄ")
	d0tNlv4Lbu2pqDaO1JfSEC9QIP5Xc(FvNyZqaLKw(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᓅ"),g4g6bfkPtVGU5lIM3(u"ࠬอไๆ๊สๆ฾ࠦวๅำึ้๏ฯࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠫᓆ"),LpdKxnIsY3Sy6qP,hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩᓇ"))
	return
def ZKDzFVhQgT08BRSvu7wWGOAn(KWyMs72X0RSCBaNAVzfwF1v4jonb):
	cEZpW924rqNYm5.executebuiltin(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࡂࡦࡧࡳࡳ࠴ࡏࡱࡧࡱࡗࡪࡺࡴࡪࡰࡪࡷ࠭࠭ᓈ")+KWyMs72X0RSCBaNAVzfwF1v4jonb+oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨࠫࠪᓉ"), hBvsQ7oCkKUdwjx58ml3EN(u"ࡕࡴࡸࡩᚳ"))
	return
def RvV9ztgAFkJIL8a7CXxhq():
	Mrch2HElwVNnm9siDCkZIKFbYL6ao7(xW2Arao7YVOemw(u"ࠩࡶࡸࡴࡶࠧᓊ"))
	cEZpW924rqNYm5.executebuiltin(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠥࡅࡨࡺࡩࡷࡣࡷࡩ࡜࡯࡮ࡥࡱࡺࠬࡎࡴࡴࡦࡴࡩࡥࡨ࡫ࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠪࠤᓋ"))
	return
def xxVPwvkAgDcLtqanG():
	cEZpW924rqNYm5.executebuiltin(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠫࡆࡪࡤࡰࡰ࠱ࡓࡵ࡫࡮ࡔࡧࡷࡸ࡮ࡴࡧࡴࠪ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠫࠪᓌ"), G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࡖࡵࡹࡪᚴ"))
	return
def zisvklMRxwE0TudAe3fQJ(showDialogs):
	if not showDialogs: o07Z1tEB4n3ARCkVNu = zqdvcbP5L8BHh(u"ࡗࡶࡺ࡫ᚵ")
	else: o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᓍ"),hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࠧᓎ"),LiRcTVUWuth70DmPy(u"ࠧࠨᓏ"),zqdvcbP5L8BHh(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᓐ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩหี๋อๅอࠢๆ์ิ๐๋ࠠไ๋้ࠥฮูๆๆํอࠥะอะ์ฮࠤัฺ๋๊ࠢส่ส฼วโษอࠤฯ๊โศศํห้ࠥไࠡ࠴࠷ࠤุอูส๋่่ࠢ์ࠠๆ็ๆ๊ࠥหฬาษฤ๋ฬࠦวๅฤ้ࠤ࠳ࠦ็ๅࠢอี๏ีࠠหฯา๎ะࠦฬๆ์฼ࠤส฼วโษอࠤ่๎ฯ๋ࠢส่ว์ࠠภࠩᓑ"))
	if o07Z1tEB4n3ARCkVNu==FvNyZqaLKw(u"࠱ᙳ"):
		cEZpW924rqNYm5.executebuiltin(FvNyZqaLKw(u"࡙ࠪࡵࡪࡡࡵࡧࡄࡨࡩࡵ࡮ࡓࡧࡳࡳࡸ࠭ᓒ"))
		if showDialogs: aHKzv76JCVnprbY8w(dshJSmRqeiP9nap2(u"ࠫࠬᓓ"),bUdr5Hahw6sY8xJ(u"ࠬ࠭ᓔ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᓕ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧห็ࠣษึูวๅฺ่ࠢอࠦลๅ๋ࠣฬึ์วๆฮࠣ็ํี๊ࠡษ็ิ๏ࠦแ๋ࠢฯ๋ฬุใࠡๆๆ๎ࠥ๐โ้็ࠣฬฯำฯ๋อࠣะ๊๐ูࠡวูหๆอสࠡๅ๋ำ๏ࠦ࠮ࠡส่หࠥ็๊่ษࠣฮาี๊ฬ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬ๊ࠡอัิ๐หࠡ็ึฮํีูࠡ฻่หิࠦ࠮ࠡ์ิะ๎ࠦลฺูสล้่ࠥะ์ࠣ࠹ࠥีโศศๅࠤศ๎ࠠฤๅฮี๊ࠥใ๋ࠢํ๊์๐ฺࠠ็็๎ฮࠦวๅฬะำ๏ัࠧᓖ"))
		cEZpW924rqNYm5.executebuiltin(SO94xq1RAkMm2uF(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬᓗ"))
	return
def RlKVPn5e1EI72():
	aHKzv76JCVnprbY8w(FvNyZqaLKw(u"ࠩࠪᓘ"),kEhAHvti6Vnsfx(u"ࠪࠫᓙ"),XzrqbGDIy54juixkMA(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᓚ"),wRxoKs10Syj7V4edYhtP(u"๊ࠬๅิฯ้ࠣาะ่๋ษอࠤ็อฦๆหࠣ࠲ࠥอะ่สࠣษ้๏ࠠศๆๅหห๋ษࠡษ็ฮ๏ࠦสา์าࠤู๊อ่ษࠣ์้อࠠหัั่ࠥหไ๋้สࠤํ๊ใ็ࠢหหุะฮะษ่ࠤࠧอไๆษ๋ืࠧࠦร้ࠢࠥห้ื๊ๆ๊อࠦࠥอึ฻ูࠣ฽้๏ࠠศๆีีࠥา็สࠢส่๏๋๊็ࠢฦ์ࠥอำหะา้ࠥࠨวๅๅํฬํืฯ๋ࠣࠢห฻เืࠡ฻็ํࠥำัโࠢࠥࡇࠧࠦร้ࠢ฼่๎ࠦวื฼ฺࠤ฾๊้ࠡิิࠤࠧอไใษษ้ฮࠨࠠศๆำ๎ࠥ็๊ࠡฮ๊อࠥอไ๋็ํ๊ࠬᓛ"))
	return
def v75riERgl6ec():
	aHKzv76JCVnprbY8w(bUdr5Hahw6sY8xJ(u"࠭ࠧᓜ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠧࠨᓝ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᓞ"),FvNyZqaLKw(u"ࠩ็่ฯ฿วๆๆ้ࠣ฾ࠦวๅ็ไฺ้ฯࠠ࠯ࠢสิ์ฮࠠฦๆ์ࠤฬ๊ัศสฺࠤฬ๊ะ๋ࠢอี๏ีࠠฦุสๅฯํࠠฤุ๊้ࠣำ็ࠡ็้ࠤ่ࠥวว็ฬࠤฬ๊ๅโุ็อࠥ๎ไไ่่ࠣฬࠦส็ไิࠤ฾๊๊่๋่ࠢฬࠦสี฼็๋ࠥ࠴้ࠠสสืฯิฯศ็ࠣࠦฬ๊ๅศ๊ึࠦࠥษ่ࠡࠤส่ึ๐ๅ้ฬࠥࠤฬ฼ฺุࠢ฼่๎ࠦวๅิิࠤัํษࠡษ็๎๊๐ๆࠡ࠰ࠣ์ศ๋วࠡสสืฯิฯศ็ࠣࠦฬ๊ใ๋ส๋ีิࠨࠠโษู฾฼ูࠦๅ๋ࠣัึ็ࠠࠣࡅࠥࠤศ๎ฺࠠๆ์ࠤืืࠠࠣษ็ๆฬฬๅสࠤࠣห้ึ๊ࠡใํࠤัํษࠡษ็๎๊๐ๆࠡ࠰ࠣ์๋็ำࠡษ็็้อๅ๊ࠡส่฼ื๊ใหࠣ฽๋ีࠠศๆอ฽ฬ๋ไࠡ็฼ࠤ๊ำส้์สฮ่่ࠥศศ่ࠤฬ๊ๅโุ็อࠬᓟ"))
	return
def hEg3ps5mkl9i(showDialogs=sTcr7iDp5eFt4RoLMhuwq1A(u"ࡘࡷࡻࡥᚶ")):
	RRYZ1oL4uAwGtOgaIShcW8D2nUljV = [QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳ࡵࡴࡩࡧࡵࡷࠬᓠ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡧࡪࡶࡨࡩࠬᓡ"),xW2Arao7YVOemw(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥࠨᓢ"),E6MIKdpBomef(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡩ࡬ࡸ࡭ࡻࡢࠨᓣ"),UTelCo0ihE1d5R(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡪ࡭ࡹ࡫ࡡࠨᓤ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࡧࡴࡪࡥࡣࡧࡵ࡫ࠬᓥ")]
	KJpTBEjto0CQhOAyV3lFMPW96aDZ = RRYZ1oL4uAwGtOgaIShcW8D2nUljV+[g4g6bfkPtVGU5lIM3(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫᓦ"),FnBiAjthS8MkXs67W(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨᓧ"),LiRcTVUWuth70DmPy(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪᓨ"),lc0dpSmwoPDjLnk(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫᓩ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠭ࡳ࡬࡫ࡱ࠲ࡵ࡮ࡥ࡯ࡱࡰࡩࡳࡧ࡬ࡆࡏࡄࡈࠬᓪ"),SO94xq1RAkMm2uF(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫᓫ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡷ࠱ࡩࡲࡰࠨᓬ")]
	YEROUgQ5Gkj1 = AwsCLr4K3zH1P6tg5cYxQJB7doFm([S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫᓭ")])
	dW4DzoBkbj = []
	for ssZLBRtgnMkc7dSouQeGCx3r8m in [g4g6bfkPtVGU5lIM3(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬᓮ")]:
		if ssZLBRtgnMkc7dSouQeGCx3r8m not in list(YEROUgQ5Gkj1.keys()): continue
		CUjgrXvYcl71xbIV5TWkzfBonD,j0EsA2ZPvQrC,LsCN1IjMaBuHe3U,I9IFHKb6nMrByTxRhJLWPdG2pfkX,GGkOI2rHDlgwcLvSTmob3QZV,e4uGRIEMXzLn7diVsQxOhZwv,eelTrkDfR8YVm = YEROUgQ5Gkj1[ssZLBRtgnMkc7dSouQeGCx3r8m]
		if not j0EsA2ZPvQrC or (j0EsA2ZPvQrC and CUjgrXvYcl71xbIV5TWkzfBonD): dW4DzoBkbj.append(ssZLBRtgnMkc7dSouQeGCx3r8m)
	elk56RFgHxAOS0E192PLtB = len(dW4DzoBkbj)>fprnld4CZo(u"࠱ᙴ")
	QAlb96UhsVG = j5cfNmnkuUA.connect(QLmA1IVR5dvG)
	QAlb96UhsVG.text_factory = str
	PYRN3CLTut = QAlb96UhsVG.cursor()
	A6AY9XaUgN = []
	for ssZLBRtgnMkc7dSouQeGCx3r8m in RRYZ1oL4uAwGtOgaIShcW8D2nUljV:
		PYRN3CLTut.execute(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫࡘࡋࡌࡆࡅࡗࠤ࠯ࠦࡆࡓࡑࡐࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡘࡊࡈࡖࡊࠦࡥ࡯ࡣࡥࡰࡪࡪࠠ࠾ࠢࠥ࠵ࠧࠦࡡ࡯ࡦࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨᓯ")+ssZLBRtgnMkc7dSouQeGCx3r8m+SO94xq1RAkMm2uF(u"ࠬࠨࠠ࠼ࠩᓰ"))
		NOpl1LBIvGax8oHDbj9 = PYRN3CLTut.fetchall()
		if NOpl1LBIvGax8oHDbj9: A6AY9XaUgN.append(ssZLBRtgnMkc7dSouQeGCx3r8m)
	ttTy2LspoSRZn = len(A6AY9XaUgN)>sTcr7iDp5eFt4RoLMhuwq1A(u"࠲ᙵ")
	for ssZLBRtgnMkc7dSouQeGCx3r8m in KJpTBEjto0CQhOAyV3lFMPW96aDZ:
		PYRN3CLTut.execute(SO94xq1RAkMm2uF(u"࠭ࡓࡆࡎࡈࡇ࡙ࠦ࡯ࡳ࡫ࡪ࡭ࡳࠦࡆࡓࡑࡐࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫᓱ")+ssZLBRtgnMkc7dSouQeGCx3r8m+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧࠣࠢ࠾ࠫᓲ"))
		D0EqnazYGPuFlJprvVxIb89LCXQHdi = PYRN3CLTut.fetchall()
		if D0EqnazYGPuFlJprvVxIb89LCXQHdi and iRoLg2m47tnDATBHGCSPNyx(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪᓳ") not in str(D0EqnazYGPuFlJprvVxIb89LCXQHdi): dW4DzoBkbj.append(ssZLBRtgnMkc7dSouQeGCx3r8m)
	djZuJR4St3iHykrYmcIhaB8xg5TEVP = len(dW4DzoBkbj)>UTelCo0ihE1d5R(u"࠳ᙶ")
	dW4DzoBkbj = list(set(dW4DzoBkbj))
	QAlb96UhsVG.close()
	CUjgrXvYcl71xbIV5TWkzfBonD = iUeoLOsbHqP(u"ࡋࡧ࡬ࡴࡧᚷ")
	if ttTy2LspoSRZn or djZuJR4St3iHykrYmcIhaB8xg5TEVP:
		o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(iRoLg2m47tnDATBHGCSPNyx(u"ࠩࡦࡩࡳࡺࡥࡳࠩᓴ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠪࠫᓵ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠫࠬᓶ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᓷ"),FvNyZqaLKw(u"࠭วๅสิ๊ฬ๋ฬ๊ࠡฯำ๋ࠥิไๆฬࠤๆ๐ࠠๆีอ์ิ฿ฺࠠ็สำࠥษ่ࠡ็ื็้ฯࠠโ์ࠣห้ะอะ์ฮࠤฬ๊สๅไสส๏ࠦไฦุสๅฬะࠠษำ้ห๊าฺࠠ็สำࠥࡢ࡮࡝ࡰࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࠦ็ๅࠢอี๏ีࠠฦื็หาࠦ็ั้ࠣห้๋ิไๆฬࠤฬ๊ย็ࠢย࡟࠴ࡉࡏࡍࡑࡕࡡࠬᓸ"))
		if o07Z1tEB4n3ARCkVNu==sTcr7iDp5eFt4RoLMhuwq1A(u"࠵ᙷ"):
			cd4WOV0A3y6KhUFZH9nGEkzLIRSqpj = Cu1704YofAbr3QTm(u"࡚ࡲࡶࡧᚸ")
			if elk56RFgHxAOS0E192PLtB:
				cd4WOV0A3y6KhUFZH9nGEkzLIRSqpj = mGVePOXw1YfpdJzqUM9a4Atr(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩᓹ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࡆࡢ࡮ࡶࡩᚹ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࡆࡢ࡮ࡶࡩᚹ"))
			G73hX2x01NfgDT9iJVtwYZu = FvNyZqaLKw(u"ࡕࡴࡸࡩᚺ")
			if ttTy2LspoSRZn:
				for ssZLBRtgnMkc7dSouQeGCx3r8m in A6AY9XaUgN: EJiphk0Sbjn(ssZLBRtgnMkc7dSouQeGCx3r8m)
				G73hX2x01NfgDT9iJVtwYZu = YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࡖࡵࡹࡪᚻ")
			wbk4IK5OCtuov8pMd3Hs0BVcxZSnJy = xW2Arao7YVOemw(u"ࡗࡶࡺ࡫ᚼ")
			if djZuJR4St3iHykrYmcIhaB8xg5TEVP:
				QAlb96UhsVG = j5cfNmnkuUA.connect(QLmA1IVR5dvG)
				QAlb96UhsVG.text_factory = str
				PYRN3CLTut = QAlb96UhsVG.cursor()
				for ssZLBRtgnMkc7dSouQeGCx3r8m in dW4DzoBkbj:
					if S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࠫᓺ") in ssZLBRtgnMkc7dSouQeGCx3r8m: D0EqnazYGPuFlJprvVxIb89LCXQHdi = ssZLBRtgnMkc7dSouQeGCx3r8m
					else: D0EqnazYGPuFlJprvVxIb89LCXQHdi = QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫᓻ")
					try: PYRN3CLTut.execute(iRoLg2m47tnDATBHGCSPNyx(u"࡙ࠪࡕࡊࡁࡕࡇࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡓࡆࡖࠣࡳࡷ࡯ࡧࡪࡰࠣࡁࠥࠨࠧᓼ")+D0EqnazYGPuFlJprvVxIb89LCXQHdi+Cu1704YofAbr3QTm(u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪᓽ")+ssZLBRtgnMkc7dSouQeGCx3r8m+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬࠨࠠ࠼ࠩᓾ"))
					except: wbk4IK5OCtuov8pMd3Hs0BVcxZSnJy = SO94xq1RAkMm2uF(u"ࡊࡦࡲࡳࡦᚽ")
				QAlb96UhsVG.commit()
				QAlb96UhsVG.close()
			MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(xW2Arao7YVOemw(u"࠶ᙸ"))
			cEZpW924rqNYm5.executebuiltin(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪᓿ"))
			MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(S4SOKF2QbBhjCd3RrVMuHIzE(u"࠷ᙹ"))
			if cd4WOV0A3y6KhUFZH9nGEkzLIRSqpj or G73hX2x01NfgDT9iJVtwYZu or wbk4IK5OCtuov8pMd3Hs0BVcxZSnJy:
				CUjgrXvYcl71xbIV5TWkzfBonD = FvNyZqaLKw(u"ࡋࡧ࡬ࡴࡧᚾ")
				aHKzv76JCVnprbY8w(xW2Arao7YVOemw(u"ࠧࠨᔀ"),p72fnFtcPix5UKwr9YNzW(u"ࠨࠩᔁ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᔂ"),Me28A1sBLNIgUp5YCDyvT(u"ࠪะ๏ีࠠ࠯࠰ࠣฮ๊ࠦศ็ฮสัࠥะแฺ์็ࠤํหีๅษะࠤฬ๊ๅิฬ๋ำ฾่ࠦศๆอัิ๐หࠡษ็ฮ้่วว์่ࠣัฺ๋๊ࠢศฺฬ็วหࠢหี๋อๅอࠢ฼้ฬีࠧᔃ"))
			else:
				CUjgrXvYcl71xbIV5TWkzfBonD = lc0dpSmwoPDjLnk(u"࡚ࡲࡶࡧᚿ")
				aHKzv76JCVnprbY8w(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࠬᔄ"),Me28A1sBLNIgUp5YCDyvT(u"ࠬ࠭ᔅ"),hBvsQ7oCkKUdwjx58ml3EN(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᔆ"),dshJSmRqeiP9nap2(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦลึๆสั๋ࠥำห๊า฽ࠥ฿ๅศัࠣ์ส฻ไศฯࠣห้ะอะ์ฮࠤฬ๊สๅไสส๏ࠦไฦุสๅฬะࠠษำ้ห๊าฺࠠ็สำࠬᔇ"))
	elif showDialogs: aHKzv76JCVnprbY8w(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠨࠩᔈ"),iRoLg2m47tnDATBHGCSPNyx(u"ࠩࠪᔉ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᔊ"),lc0dpSmwoPDjLnk(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ฬึ์วๆฮ่๊๊ࠣࠦอัู้้ࠣไสࠢไ๎๋ࠥำห๊า฽ࠥ฿ๅศัࠣวํࠦแ๋ࠢส่ฯำฯ๋อࠣห้ะไใษษ๎๊ࠥลืษไหฯࠦศา่ส้ัูࠦๆษาࠫᔋ"))
	return CUjgrXvYcl71xbIV5TWkzfBonD
def w06qmQus8vWArxR1OtoXyGlECf():
	Sdmn4TiBwVf7CsPZ5jIrYF2,aaF0NC6VA4h8BmoX3xQUnslWebq,eKT1IDSiGEvHlzn = bUdr5Hahw6sY8xJ(u"ࡆࡢ࡮ࡶࡩᛀ"),XzrqbGDIy54juixkMA(u"ࠬ࠭ᔌ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠭ࠧᔍ")
	A4QaPChpow61ZH5eU3f,y6QwejZaUqopi5uzWXSM2,F9DSyvCltxRH4Y7BmpuiwqX = wRxoKs10Syj7V4edYhtP(u"ࡇࡣ࡯ࡷࡪᛁ"),XzrqbGDIy54juixkMA(u"ࠧࠨᔎ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨࠩᔏ")
	x8XIHdjPEoO4ezq51lwySr = [fprnld4CZo(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧᔐ"),SO94xq1RAkMm2uF(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩᔑ"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭ᔒ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫᔓ")]
	YEROUgQ5Gkj1 = AwsCLr4K3zH1P6tg5cYxQJB7doFm(x8XIHdjPEoO4ezq51lwySr)
	for ssZLBRtgnMkc7dSouQeGCx3r8m in x8XIHdjPEoO4ezq51lwySr:
		if ssZLBRtgnMkc7dSouQeGCx3r8m not in list(YEROUgQ5Gkj1.keys()): continue
		CUjgrXvYcl71xbIV5TWkzfBonD,j0EsA2ZPvQrC,txZLfeKroOcXwy4gnF70B,GujSHsyZOqkoWm8B7nLaXd9MpKPcUY,ViO2eHTQ0zIuwmKJ7gq4P,L5VnDolF9OviImp6dJrEB2huy,G30myqcjOuXhJHfK4 = YEROUgQ5Gkj1[ssZLBRtgnMkc7dSouQeGCx3r8m]
		if ssZLBRtgnMkc7dSouQeGCx3r8m==hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫᔔ"):
			A4QaPChpow61ZH5eU3f = CUjgrXvYcl71xbIV5TWkzfBonD
			y6QwejZaUqopi5uzWXSM2 = S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠧࠩࠩᔕ")+j0EsA2ZPvQrC+xW2Arao7YVOemw(u"ࠨࠢࠪᔖ")+wPGkbaD7x6(L5VnDolF9OviImp6dJrEB2huy)+UTelCo0ihE1d5R(u"ࠩࠬࠫᔗ")
			F9DSyvCltxRH4Y7BmpuiwqX = GujSHsyZOqkoWm8B7nLaXd9MpKPcUY
		elif ssZLBRtgnMkc7dSouQeGCx3r8m==iUeoLOsbHqP(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬᔘ"):
			Sdmn4TiBwVf7CsPZ5jIrYF2 = Sdmn4TiBwVf7CsPZ5jIrYF2 or CUjgrXvYcl71xbIV5TWkzfBonD
			aaF0NC6VA4h8BmoX3xQUnslWebq += g4g6bfkPtVGU5lIM3(u"ࠫࠥࠦࠬࠡࠢࠫࠫᔙ")+j0EsA2ZPvQrC+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠬࠦࠧᔚ")+wPGkbaD7x6(L5VnDolF9OviImp6dJrEB2huy)+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࠩࠨᔛ")
			eKT1IDSiGEvHlzn += kEhAHvti6Vnsfx(u"ࠧࠡࠢ࠯ࠤࠥ࠭ᔜ")+GujSHsyZOqkoWm8B7nLaXd9MpKPcUY
		elif ssZLBRtgnMkc7dSouQeGCx3r8m==l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧᔝ"):
			IbWQr3Uj0OlEaAB2 = CUjgrXvYcl71xbIV5TWkzfBonD
			hXmi8aqQ4zdgSM70u3jT9f = FnBiAjthS8MkXs67W(u"ࠩࠫࠫᔞ")+j0EsA2ZPvQrC+bUdr5Hahw6sY8xJ(u"ࠪࠤࠬᔟ")+wPGkbaD7x6(L5VnDolF9OviImp6dJrEB2huy)+yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫ࠮࠭ᔠ")
			gRt5HjGdYm = GujSHsyZOqkoWm8B7nLaXd9MpKPcUY
	aaF0NC6VA4h8BmoX3xQUnslWebq = aaF0NC6VA4h8BmoX3xQUnslWebq.strip(lc0dpSmwoPDjLnk(u"ࠬࠦࠠ࠭ࠢࠣࠫᔡ"))
	eKT1IDSiGEvHlzn = eKT1IDSiGEvHlzn.strip(Cu1704YofAbr3QTm(u"࠭ࠠࠡ࠮ࠣࠤࠬᔢ"))
	WudaQ1Cgy08NvYx5SZkzwVP4BDt  = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅลั๎ึࠦไษำ้ห๊าฺࠠ็สำࠥอไๆฬ๋ๅึࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧᔣ")+F9DSyvCltxRH4Y7BmpuiwqX+Cu1704YofAbr3QTm(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᔤ")
	WudaQ1Cgy08NvYx5SZkzwVP4BDt += xW2Arao7YVOemw(u"ࠩ࡟ࡲࠬᔥ")+sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋๊ࠥศา่ส้ัูࠦๆษาࠤ์๎ࠠ࠻ࠢࠣࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧᔦ")+y6QwejZaUqopi5uzWXSM2+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᔧ")
	WudaQ1Cgy08NvYx5SZkzwVP4BDt += G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠬࡢ࡮࡝ࡰࠪᔨ")+oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไฤะํี๊ࠥๅิฬ๋ำ฾ูࠦๆษาࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ᔩ")+eKT1IDSiGEvHlzn+hBvsQ7oCkKUdwjx58ml3EN(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᔪ")
	WudaQ1Cgy08NvYx5SZkzwVP4BDt += iRoLg2m47tnDATBHGCSPNyx(u"ࠨ࡞ࡱࠫᔫ")+p72fnFtcPix5UKwr9YNzW(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ้๋ำห๊า฽ࠥ฿ๅศั๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ᔬ")+aaF0NC6VA4h8BmoX3xQUnslWebq+iUeoLOsbHqP(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᔭ")
	WudaQ1Cgy08NvYx5SZkzwVP4BDt += sTcr7iDp5eFt4RoLMhuwq1A(u"ࠫࡡࡴ࡜࡯ࠩᔮ")+hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊รฯ์ิࠤ้าไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢส่๊ะ่โำࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫᔯ")+gRt5HjGdYm+iRoLg2m47tnDATBHGCSPNyx(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨᔰ")
	WudaQ1Cgy08NvYx5SZkzwVP4BDt += Me28A1sBLNIgUp5YCDyvT(u"ࠧ࡝ࡰࠪᔱ")+S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆ้่ࠣั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯ้๋ࠡࠤ࠿ࠦࠠࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫᔲ")+hXmi8aqQ4zdgSM70u3jT9f+g4g6bfkPtVGU5lIM3(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᔳ")
	CUjgrXvYcl71xbIV5TWkzfBonD = (A4QaPChpow61ZH5eU3f or Sdmn4TiBwVf7CsPZ5jIrYF2)
	if CUjgrXvYcl71xbIV5TWkzfBonD:
		header = XzrqbGDIy54juixkMA(u"ࠪห้ืฬศรࠣฮาี๊ฬࠢศฺฬ็วหࠢๆ์ิ๐ࠠๅฯ็ࠤฬ๊ๅีษๆ่ࠬᔴ")
		F2jvcEiRap8KbWh = hBvsQ7oCkKUdwjx58ml3EN(u"ࠫฬ์สࠡสะหัฯࠠๅฬะำ๏ัࠠษำ้ห๊าฺࠠ็สำࠥษ่ࠡฬะำ๏ัࠠๆีอ์ิ฿ฺࠠ็สำࠬᔵ")
	else:
		header = wRxoKs10Syj7V4edYhtP(u"ࠬำวๅ์สࠤ้อ๋๊ࠠฯำࠥะอะ์ฮหฯࠦไษำ้ห๊าฺࠠ็สำࠥษ่ࠡ็ึฮํีูࠡ฻่หิ࠭ᔶ")
		F2jvcEiRap8KbWh = XzrqbGDIy54juixkMA(u"࠭วๅำฯหฦࠦลษๆส฾ࠥอไๆสิ้ัูࠦ็ࠢสฺ่๊ใๅหࠣห้ะ๊ࠡฬ๋หัํใࠨᔷ")
	uuaHVcLxsdkXbqtY1fzRhi = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧๅๅํࠤ๏฿ๅๅࠢ฼๊ิ้ࠠศๆอัิ๐หࠡษ็ฮ้่วว์ࠣ๎ัฮࠠฤ่ࠣ๎่๎ๆࠡๆา๎่ࠦแ๋ࠢๆ์ิ๐࡜࡯็ึฮํีูࠡ฻่หิࠦࡅࡎࡃࡇࠤࡗ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹࠨᔸ")
	a0xUXYviFC8sb9Apt26mr = WudaQ1Cgy08NvYx5SZkzwVP4BDt+sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨ࡞ࡱࡠࡳ࠭ᔹ")+F2jvcEiRap8KbWh+hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩ࡟ࡲࡡࡴࠧᔺ")+uuaHVcLxsdkXbqtY1fzRhi
	d0tNlv4Lbu2pqDaO1JfSEC9QIP5Xc(SO94xq1RAkMm2uF(u"ࠪࡶ࡮࡭ࡨࡵࠩᔻ"),header,a0xUXYviFC8sb9Apt26mr,zqdvcbP5L8BHh(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧᔼ"))
	return
def WrEwOCRSaplo7iy6ZDxIJ2teL0Tf(showDialogs,vPtbKlM96Ea):
	HHg0f8U75SdzxEcbt1JN(UkFh2OXjuTZEaexC,E6MIKdpBomef(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨᔽ"),XzrqbGDIy54juixkMA(u"࠭ࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒࠧᔾ"))
	if showDialogs:
		w06qmQus8vWArxR1OtoXyGlECf()
		q4OV92sRG3EfDedmwUpKAI()
	if vPtbKlM96Ea:
		hEg3ps5mkl9i(SO94xq1RAkMm2uF(u"ࡈࡤࡰࡸ࡫ᛂ"))
		DAJdcmE9WCk = [iUeoLOsbHqP(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬᔿ"),wRxoKs10Syj7V4edYhtP(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧᕀ"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫᕁ"),bUdr5Hahw6sY8xJ(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧᕂ"),SO94xq1RAkMm2uF(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡾࡺ࠭ࡥ࡮ࡳࠫᕃ")]
		for NN4VFeBPRcOAEayQ0xfdb3iJLXuz8o in DAJdcmE9WCk:
			Tr8iRxJmbcEhftU5DSHzA,cyJHLQteCY7ns1DaIm,j0EsA2ZPvQrC = mGVePOXw1YfpdJzqUM9a4Atr(NN4VFeBPRcOAEayQ0xfdb3iJLXuz8o,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࡘࡷࡻࡥᛄ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࡉࡥࡱࡹࡥᛃ"))
		zisvklMRxwE0TudAe3fQJ(showDialogs)
		cEZpW924rqNYm5.executebuiltin(wRxoKs10Syj7V4edYhtP(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩᕄ"))
	return
def wadYxypc8umjFENRvq0r(KWFPHwI2Zvbpqf=bUdr5Hahw6sY8xJ(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬᕅ"),showDialogs=LiRcTVUWuth70DmPy(u"࡙ࡸࡵࡦᛅ")):
	Rbnv9164DBGdE = cEZpW924rqNYm5.executeJSONRPC(iUeoLOsbHqP(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪᕆ"))
	import json as IsRfCubK4FeYlZgEcXn6U5PNa0
	data = IsRfCubK4FeYlZgEcXn6U5PNa0.loads(Rbnv9164DBGdE)
	fYunOMbKk9iwo8VtByQq = data[FvNyZqaLKw(u"ࠨࡴࡨࡷࡺࡲࡴࠨᕇ")][S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠩࡹࡥࡱࡻࡥࠨᕈ")]
	if HHosl5fRdhtEDAYyP: fYunOMbKk9iwo8VtByQq = fYunOMbKk9iwo8VtByQq.encode(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠪࡹࡹ࡬࠸ࠨᕉ"))
	if showDialogs:
		o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࠬᕊ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠬ࠭ᕋ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࠧᕌ"),zqdvcbP5L8BHh(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᕍ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠨ้็ࠤฯื๊ะࠢอ฾๏๐ัࠡฮ็ำࠥ࠭ᕎ")+fYunOMbKk9iwo8VtByQq+lc0dpSmwoPDjLnk(u"ࠩࠣห้ึ๊ࠡ็ึฮำีๅࠡษ็ฦ๋ࠦแ๋ࠢๆ์ิ๐ࠠฦๆ์ࠤฬ๊ลึัสีࠥอไฤะํี๊ࠥฬๅัࠣࠫᕏ")+KWFPHwI2Zvbpqf+SO94xq1RAkMm2uF(u"ࠪࠤฤࠧࠧᕐ"))
		if o07Z1tEB4n3ARCkVNu!=iUeoLOsbHqP(u"࠱ᙺ"): return G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࡌࡡ࡭ࡵࡨᛆ")
	Tr8iRxJmbcEhftU5DSHzA,cyJHLQteCY7ns1DaIm,zYIxP2hyrdj9GKgtQZ8HBNw = mGVePOXw1YfpdJzqUM9a4Atr(KWFPHwI2Zvbpqf,G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࡆࡢ࡮ࡶࡩᛇ"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࡆࡢ࡮ࡶࡩᛇ"))
	if Tr8iRxJmbcEhftU5DSHzA:
		if showDialogs: aHKzv76JCVnprbY8w(bUdr5Hahw6sY8xJ(u"ࠫࠬᕑ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬ࠭ᕒ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᕓ"),FvNyZqaLKw(u"ࠧห็อࠤ฾๋ไ๋หࠣฮะฮ๊หࠢส่ั๊ฯࠡษ็ะิ๐ฯ๊๊ࠡ์ࠥาว่ิ่้ࠣอำหะาห๊ࠦ࠮ࠡี๋ๅࠥ๐สๆࠢส่ว์ࠠห฼ํ๎ึࠦลฺัสำฬะࠠไ๊า๎๊ࠥใ๋ࠢํืฯ฿ๅๅࠢส่ั๊ฯࠡษ็ะิ๐ฯࠡสา่ฬࠦๅ็ࠢส่็ี๊ๆࠩᕔ"))
		IJuVYdzmgy1AUtiKGfqWcv = cEZpW924rqNYm5.executeJSONRPC(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡖࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣ࠮ࠥࡺࡦࡲࡵࡦࠤ࠽ࠦࠬᕕ")+KWFPHwI2Zvbpqf+oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠩࠥࢁࢂ࠭ᕖ"))
		if FnBiAjthS8MkXs67W(u"ࠪࡓࡐ࠭ᕗ") in IJuVYdzmgy1AUtiKGfqWcv: Tr8iRxJmbcEhftU5DSHzA = zqdvcbP5L8BHh(u"ࡕࡴࡸࡩᛈ")
		MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠲ᙻ"))
		cEZpW924rqNYm5.executebuiltin(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫࡘ࡫࡮ࡥࡅ࡯࡭ࡨࡱࠨ࠲࠳ࠬࠫᕘ"))
	elif showDialogs: aHKzv76JCVnprbY8w(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬ࠭ᕙ"),p72fnFtcPix5UKwr9YNzW(u"࠭ࠧᕚ"),Me28A1sBLNIgUp5YCDyvT(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᕛ"),FvNyZqaLKw(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯัศ๋ฬࠣ์ฯ็ู๋ๆࠣห้าไะࠢส่๊฽ไ้สࠪᕜ"))
	return Tr8iRxJmbcEhftU5DSHzA
def KmIlXVwgsFZxEdh1b(ssZLBRtgnMkc7dSouQeGCx3r8m,showDialogs=hBvsQ7oCkKUdwjx58ml3EN(u"ࡖࡵࡹࡪᛉ")):
	if showDialogs==kEhAHvti6Vnsfx(u"ࠩࠪᕝ"): showDialogs = SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࡗࡶࡺ࡫ᛊ")
	mMOClDfZqYG42pVQtivPjN = wwCQF2Y0J5ZGg([ssZLBRtgnMkc7dSouQeGCx3r8m])
	cxb5RACHZY30rdfw9NE1,UU2A3ZKcRnv = mMOClDfZqYG42pVQtivPjN[ssZLBRtgnMkc7dSouQeGCx3r8m]
	if UU2A3ZKcRnv:
		Tr8iRxJmbcEhftU5DSHzA = dshJSmRqeiP9nap2(u"ࡘࡷࡻࡥᛋ")
		if showDialogs: aHKzv76JCVnprbY8w(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪࠫᕞ"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࠬᕟ"),Cu1704YofAbr3QTm(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᕠ"),fprnld4CZo(u"࠭แฮืࠣห้หึศใฬࠤࡡࡴࠠࠨᕡ")+ssZLBRtgnMkc7dSouQeGCx3r8m+SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠧࠡ࡞ࡱࠤ์ึ็ࠡล็ษ฻อแสࠢ฼๊ิ้ࠠๆ๊ฯ์ิฯ้ࠠ็ไ฽้ฯ้ࠠฮส๋ืฯࠠๅๆสืฯิฯศ็ࠪᕢ"))
	else:
		Tr8iRxJmbcEhftU5DSHzA = iUeoLOsbHqP(u"ࡋࡧ࡬ࡴࡧᛌ")
		o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(FvNyZqaLKw(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᕣ"),g4g6bfkPtVGU5lIM3(u"ࠩࠪᕤ"),SO94xq1RAkMm2uF(u"ࠪࠫᕥ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᕦ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠬ࠭ᕧ")+ssZLBRtgnMkc7dSouQeGCx3r8m+p72fnFtcPix5UKwr9YNzW(u"࠭ࠠ࡝ࡰ๋ࠣีํࠠฤๆศฺฬ็ษࠡ฻้ำฺ่๋ࠦำ้ࠣๆ฿ไสࠢฦ์ࠥเ๊า่ࠢ์ั๎ฯสࠢ࠱ࠤ๏าศࠡฬฮฬ๏ะ็ศ๋ࠢฮๆ฿๊ๅ้สࠤ้้๊ࠡ์฼้้ࠦวๅสิ๊ฬ๋ฬࠡ฻้ำ่ࠦศึ๊ิอࠥ฻อ๋ฯฬࠤ࠳ࠦ็ๅࠢอี๏ีࠠหอห๎ฯ่ࠦหใ฼๎้ࠦ็ั้ࠣห้หึศใฬࠤฬ๊ย็ࠢยࠫᕨ"))
		if o07Z1tEB4n3ARCkVNu==zqdvcbP5L8BHh(u"࠳ᙼ"):
			cEZpW924rqNYm5.executebuiltin(xW2Arao7YVOemw(u"ࠧࡊࡰࡶࡸࡦࡲ࡬ࡂࡦࡧࡳࡳ࠮ࠧᕩ")+ssZLBRtgnMkc7dSouQeGCx3r8m+FnBiAjthS8MkXs67W(u"ࠨࠫࠪᕪ"))
			MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(Cu1704YofAbr3QTm(u"࠴ᙽ"))
			cEZpW924rqNYm5.executebuiltin(wRxoKs10Syj7V4edYhtP(u"ࠩࡖࡩࡳࡪࡃ࡭࡫ࡦ࡯࠭࠷࠱ࠪࠩᕫ"))
			MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(kEhAHvti6Vnsfx(u"࠵ᙾ"))
			while cEZpW924rqNYm5.getCondVisibility(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࡛ࠪ࡮ࡴࡤࡰࡹ࠱ࡍࡸࡇࡣࡵ࡫ࡹࡩ࠭ࡶࡲࡰࡩࡵࡩࡸࡹࡤࡪࡣ࡯ࡳ࡬࠯ࠧᕬ")): MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(hBvsQ7oCkKUdwjx58ml3EN(u"࠶ᙿ"))
			IJuVYdzmgy1AUtiKGfqWcv = cEZpW924rqNYm5.executeJSONRPC(g4g6bfkPtVGU5lIM3(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡅࡩࡪ࡯࡯ࡵ࠱ࡗࡪࡺࡁࡥࡦࡲࡲࡊࡴࡡࡣ࡮ࡨࡨࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡥࡩࡪ࡯࡯࡫ࡧࠦ࠿ࠨࠧᕭ")+ssZLBRtgnMkc7dSouQeGCx3r8m+fprnld4CZo(u"ࠬࠨࠬࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡸࡷࡻࡥࡾࡿࠪᕮ"))
			if pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭ࡏࡌࠩᕯ") in IJuVYdzmgy1AUtiKGfqWcv:
				Tr8iRxJmbcEhftU5DSHzA = kEhAHvti6Vnsfx(u"࡚ࡲࡶࡧᛍ")
				if showDialogs: aHKzv76JCVnprbY8w(FnBiAjthS8MkXs67W(u"ࠧࠨᕰ"),FnBiAjthS8MkXs67W(u"ࠨࠩᕱ"),kEhAHvti6Vnsfx(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᕲ"),iRoLg2m47tnDATBHGCSPNyx(u"ࠪฮ๊ࠦแฮืࠣวํࠦสฬสํฮࠥษ่ࠡฬไ฽๏๊ࠠฤ๊ࠣฮาี๊ฬࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠥ๎็๋ࠢส่ว์ࠠอษ๊ึฮࠦไๅษึฮำีวๆࠩᕳ"))
			elif showDialogs: aHKzv76JCVnprbY8w(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠫࠬᕴ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬ࠭ᕵ"),Me28A1sBLNIgUp5YCDyvT(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᕶ"),iRoLg2m47tnDATBHGCSPNyx(u"ࠧโึ็ࠤๆ๐ࠠหอห๎ฯࠦร้ࠢอๅ฾๐ไࠡล๋ࠤฯำฯ๋อࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮࠦ࠮๊ࠡส่า๊่๊ࠠࠣฮะฮ๊ห้สࠤํะแฺ์็๋ฬࠦๅ็ࠢัหึาࠠศๆหี๋อๅอࠩᕷ"))
	return Tr8iRxJmbcEhftU5DSHzA
def BN5rqwZkpOzsxH6iVL7Dmg3ltU(ssZLBRtgnMkc7dSouQeGCx3r8m,G30myqcjOuXhJHfK4,showDialogs):
	Tr8iRxJmbcEhftU5DSHzA = g4g6bfkPtVGU5lIM3(u"ࡆࡢ࡮ࡶࡩᛎ")
	if showDialogs:
		o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(Me28A1sBLNIgUp5YCDyvT(u"ࠨࠩᕸ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࠪᕹ"),g4g6bfkPtVGU5lIM3(u"ࠪࠫᕺ"),XzrqbGDIy54juixkMA(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᕻ"),FnBiAjthS8MkXs67W(u"ู่ࠬโࠢํฮ๊ࠦวๅฤ้ࠤั๊ศࠡษ็้้็ࠠศๆฺ่฿๎ืࠡๆ็ษ฻อแสࠢส่๊฽ไ้สฬࠤ้้๊ࠡ์อ้ࠥะหษ์อ๋ࠥ฿ไ๊ࠢๆ์ิ๐ࠠ࠯ࠢส่๊๊แࠡไาࠤ๏้่็ࠢๆฬ๏ื้ࠠไาࠤ๏ำสศฮࠣฬ฾฼ࠠศๆ๋ๆฯࠦ࠮้ࠡ็ࠤฯื๊ะࠢอั๊๐ไࠡษ็้้็ࠠศๆล๊ࠥลࠡࠨᕼ"))
		if o07Z1tEB4n3ARCkVNu!=Cu1704YofAbr3QTm(u"࠷ "): return QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࡇࡣ࡯ࡷࡪᛏ")
	NgU6IjxK1VbFZ = wwJEoNAiDnIZgYS(G30myqcjOuXhJHfK4,{},showDialogs)
	if NgU6IjxK1VbFZ:
		ckbJ59nvm4BNXSsYMoi = WpgZTyqoMAPhwGiXF.path.join(verdwoPF9GcOh1psxjHB34lgRMI,ssZLBRtgnMkc7dSouQeGCx3r8m)
		OOy4gzCqrV382ctPa(ckbJ59nvm4BNXSsYMoi,UTelCo0ihE1d5R(u"ࡗࡶࡺ࡫ᛑ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࡈࡤࡰࡸ࡫ᛐ"))
		import zipfile as KKlhyBTU8Xfnas9zObVJEFCNePLW1S,io as Ci2YFpqRkA094JnHorLmZUNxvS
		ypAZIxc2wivYg3K94nROHD17GLbo5r = Ci2YFpqRkA094JnHorLmZUNxvS.BytesIO(NgU6IjxK1VbFZ)
		try:
			B2XLM0gmE6ZtiCGFT = KKlhyBTU8Xfnas9zObVJEFCNePLW1S.ZipFile(ypAZIxc2wivYg3K94nROHD17GLbo5r)
			B2XLM0gmE6ZtiCGFT.extractall(verdwoPF9GcOh1psxjHB34lgRMI)
			MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(iUeoLOsbHqP(u"࠱ᚁ"))
			cEZpW924rqNYm5.executebuiltin(kEhAHvti6Vnsfx(u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪᕽ"))
			MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(dshJSmRqeiP9nap2(u"࠳ᚂ"))
			IJuVYdzmgy1AUtiKGfqWcv = cEZpW924rqNYm5.executeJSONRPC(xW2Arao7YVOemw(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡁࡥࡦࡲࡲࡸ࠴ࡓࡦࡶࡄࡨࡩࡵ࡮ࡆࡰࡤࡦࡱ࡫ࡤࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡡࡥࡦࡲࡲ࡮ࡪࠢ࠻ࠤࠪᕾ")+ssZLBRtgnMkc7dSouQeGCx3r8m+wRxoKs10Syj7V4edYhtP(u"ࠨࠤ࠯ࠦࡪࡴࡡࡣ࡮ࡨࡨࠧࡀࡴࡳࡷࡨࢁࢂ࠭ᕿ"))
			if FnBiAjthS8MkXs67W(u"ࠩࡒࡏࠬᖀ") in IJuVYdzmgy1AUtiKGfqWcv: Tr8iRxJmbcEhftU5DSHzA = E6MIKdpBomef(u"ࡘࡷࡻࡥᛒ")
			HHg0f8U75SdzxEcbt1JN(UkFh2OXjuTZEaexC,Cu1704YofAbr3QTm(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ᖁ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫࡆࡊࡄࡐࡐࡖࡣࡉࡋࡔࡂࡋࡏࡗࠬᖂ"))
		except: Tr8iRxJmbcEhftU5DSHzA = bUdr5Hahw6sY8xJ(u"ࡋࡧ࡬ࡴࡧᛓ")
	if showDialogs:
		if Tr8iRxJmbcEhftU5DSHzA: aHKzv76JCVnprbY8w(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬ࠭ᖃ"),yA5z6LIXBlo41PRVMY87wOisFp(u"࠭ࠧᖄ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᖅ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨฬ่ࠤอ์ฬศฯࠣฮะฮ๊หࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠬᖆ"))
		else: aHKzv76JCVnprbY8w(lc0dpSmwoPDjLnk(u"ࠩࠪᖇ"),zqdvcbP5L8BHh(u"ࠪࠫᖈ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᖉ"),sTcr7iDp5eFt4RoLMhuwq1A(u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡฬฮฬ๏ะࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠪᖊ"))
	return Tr8iRxJmbcEhftU5DSHzA
def mGVePOXw1YfpdJzqUM9a4Atr(ssZLBRtgnMkc7dSouQeGCx3r8m,showDialogs,I0I4YHjx5kfJl8KsTdPEy9v):
	o07Z1tEB4n3ARCkVNu,Tr8iRxJmbcEhftU5DSHzA,cyJHLQteCY7ns1DaIm,j0EsA2ZPvQrC = Cu1704YofAbr3QTm(u"ࡔࡳࡷࡨᛕ"),g4g6bfkPtVGU5lIM3(u"ࡌࡡ࡭ࡵࡨᛔ"),E6MIKdpBomef(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ᖋ"),iUeoLOsbHqP(u"ࠧࠨᖌ")
	YEROUgQ5Gkj1 = AwsCLr4K3zH1P6tg5cYxQJB7doFm([ssZLBRtgnMkc7dSouQeGCx3r8m])
	if ssZLBRtgnMkc7dSouQeGCx3r8m in list(YEROUgQ5Gkj1.keys()):
		CUjgrXvYcl71xbIV5TWkzfBonD,j0EsA2ZPvQrC,txZLfeKroOcXwy4gnF70B,GujSHsyZOqkoWm8B7nLaXd9MpKPcUY,ViO2eHTQ0zIuwmKJ7gq4P,L5VnDolF9OviImp6dJrEB2huy,G30myqcjOuXhJHfK4 = YEROUgQ5Gkj1[ssZLBRtgnMkc7dSouQeGCx3r8m]
		if L5VnDolF9OviImp6dJrEB2huy==p72fnFtcPix5UKwr9YNzW(u"ࠨࡩࡲࡳࡩ࠭ᖍ"):
			Tr8iRxJmbcEhftU5DSHzA,cyJHLQteCY7ns1DaIm = SO94xq1RAkMm2uF(u"ࡕࡴࡸࡩᛖ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩࡱࡳࡹ࡮ࡩ࡯ࡩࠪᖎ")
			if I0I4YHjx5kfJl8KsTdPEy9v:
				o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(g4g6bfkPtVGU5lIM3(u"ࠪࠫᖏ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠫࠬᖐ"),Me28A1sBLNIgUp5YCDyvT(u"ࠬ࠭ᖑ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᖒ"),E6MIKdpBomef(u"ࠧอ์าࠤัีวࠡ࠰࠱ࠤ่๎ฯ๋ࠢํืฯิฯๆࠢฦาึࠦลึัสี๋ࠥส้ใิࠤๆ๐ࠠๆ๊สๆ฾ࠦๅิฬ๋ำ฾ูࠦๆษาࠤ้ํะ่ࠢส่ส฼วโห࡟ࡲࡡࡴࠧᖓ")+ssZLBRtgnMkc7dSouQeGCx3r8m+iRoLg2m47tnDATBHGCSPNyx(u"ࠨ࡞ࡱࡠࡳํไࠡฬิ๎ิࠦลฺษาอࠥะหษ์อࠤ์ึ็ࠡษ็ษ฻อแส่ࠢีฮࠦรฯำ์ࠫᖔ"))
				if o07Z1tEB4n3ARCkVNu:
					Tr8iRxJmbcEhftU5DSHzA = BN5rqwZkpOzsxH6iVL7Dmg3ltU(ssZLBRtgnMkc7dSouQeGCx3r8m,G30myqcjOuXhJHfK4,zqdvcbP5L8BHh(u"ࡈࡤࡰࡸ࡫ᛗ"))
					if Tr8iRxJmbcEhftU5DSHzA:
						cyJHLQteCY7ns1DaIm = yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩࡵࡩ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠧᖕ")
						if showDialogs: aHKzv76JCVnprbY8w(XzrqbGDIy54juixkMA(u"ࠪࠫᖖ"),E6MIKdpBomef(u"ࠫࠬᖗ"),Me28A1sBLNIgUp5YCDyvT(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᖘ"),Cu1704YofAbr3QTm(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้หึศใฬࠤ่อๆห่ࠢ์ั๎ฯสࠢ࠱࠲ࠥ๎โศ็ࠣห้ฮั็ษ่ะࠥฮลฺษาอࠥะหษ์อ๋ฬࡢ࡮࡝ࡰࠪᖙ")+ssZLBRtgnMkc7dSouQeGCx3r8m)
					else:
						cyJHLQteCY7ns1DaIm = fprnld4CZo(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧᖚ")
						aHKzv76JCVnprbY8w(g4g6bfkPtVGU5lIM3(u"ࠨࠩᖛ"),p72fnFtcPix5UKwr9YNzW(u"ࠩࠪᖜ"),LiRcTVUWuth70DmPy(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᖝ"),dshJSmRqeiP9nap2(u"้๊ࠫริใࠣ࠲࠳ࠦวๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏ูสุ์฼ࠤส฿วะหࠣฮะฮ๊ห๊ࠢิ์ࠦวๅวูหๆฯ࡜࡯࡞ࡱࠫᖞ")+ssZLBRtgnMkc7dSouQeGCx3r8m)
		else:
			if showDialogs:
				if L5VnDolF9OviImp6dJrEB2huy==QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧᖟ"): LpdKxnIsY3Sy6qP = yA5z6LIXBlo41PRVMY87wOisFp(u"࠭ๅห๊ๅๅฮ࠭ᖠ")
				elif L5VnDolF9OviImp6dJrEB2huy==Cu1704YofAbr3QTm(u"ࠧࡰ࡮ࡧࠫᖡ"): LpdKxnIsY3Sy6qP = iRoLg2m47tnDATBHGCSPNyx(u"ࠨไา๎๊ฯࠧᖢ")
				elif L5VnDolF9OviImp6dJrEB2huy==QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪᖣ"): LpdKxnIsY3Sy6qP = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪ฾๏ืࠠๆอหฮฮ࠭ᖤ")
				o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(zqdvcbP5L8BHh(u"ࠫࠬᖥ"),LiRcTVUWuth70DmPy(u"ࠬ࠭ᖦ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭ࠧᖧ"),bUdr5Hahw6sY8xJ(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᖨ"),FnBiAjthS8MkXs67W(u"ࠨ้ำ๋ࠥอไฦุสๅฮࠦࠧᖩ")+LpdKxnIsY3Sy6qP+dshJSmRqeiP9nap2(u"ࠩࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠฦื็หาࠦ็ั้ࠣห้๋ิไๆฬࠤฤࠧ࡜࡯࡞ࡱࠫᖪ")+ssZLBRtgnMkc7dSouQeGCx3r8m)
			if not o07Z1tEB4n3ARCkVNu: cyJHLQteCY7ns1DaIm = oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࠬᖫ")
			else:
				if L5VnDolF9OviImp6dJrEB2huy==wRxoKs10Syj7V4edYhtP(u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠭ᖬ"):
					zpXG3Ky6ou8ndWHkb4 = cEZpW924rqNYm5.executeJSONRPC(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡆࡪࡤࡰࡰࡶ࠲ࡘ࡫ࡴࡂࡦࡧࡳࡳࡋ࡮ࡢࡤ࡯ࡩࡩࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡦࡪࡤࡰࡰ࡬ࡨࠧࡀࠢࠨᖭ")+ssZLBRtgnMkc7dSouQeGCx3r8m+oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠭ࠢ࠭ࠤࡨࡲࡦࡨ࡬ࡦࡦࠥ࠾ࡹࡸࡵࡦࡿࢀࠫᖮ"))
					if wRxoKs10Syj7V4edYhtP(u"ࠧࡐࡍࠪᖯ") in zpXG3Ky6ou8ndWHkb4:
						Tr8iRxJmbcEhftU5DSHzA,cyJHLQteCY7ns1DaIm = S4SOKF2QbBhjCd3RrVMuHIzE(u"ࡗࡶࡺ࡫ᛘ"),SO94xq1RAkMm2uF(u"ࠨࡧࡱࡥࡧࡲࡥࡥࠩᖰ")
						if showDialogs: aHKzv76JCVnprbY8w(kEhAHvti6Vnsfx(u"ࠩࠪᖱ"),zqdvcbP5L8BHh(u"ࠪࠫᖲ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᖳ"),iUeoLOsbHqP(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢส่ส฼วโหࠣ็ฬ์สࠡ็อ์็็ษࠡ࠰࠱ࠤํ่วๆࠢส่อืๆศ็ฯࠤอะิ฻์็๋ฬࡢ࡮࡝ࡰࠪᖴ")+ssZLBRtgnMkc7dSouQeGCx3r8m)
					elif showDialogs: aHKzv76JCVnprbY8w(lc0dpSmwoPDjLnk(u"࠭ࠧᖵ"),FvNyZqaLKw(u"ࠧࠨᖶ"),SO94xq1RAkMm2uF(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᖷ"),E6MIKdpBomef(u"ࠩ็่ศูแࠡ࠰࠱ࠤฬ๊ลืษไอ๋ࠥส้ไไอࠥ࠴࠮๊ࠡ็้ࠥ๐ำหูํ฽ࠥอไษำ้ห๊าࠠหึ฽๎้ํว࡝ࡰ࡟ࡲࠬᖸ")+ssZLBRtgnMkc7dSouQeGCx3r8m)
				elif L5VnDolF9OviImp6dJrEB2huy in [iRoLg2m47tnDATBHGCSPNyx(u"ࠪࡳࡱࡪࠧᖹ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬᖺ")]:
					Tr8iRxJmbcEhftU5DSHzA = BN5rqwZkpOzsxH6iVL7Dmg3ltU(ssZLBRtgnMkc7dSouQeGCx3r8m,G30myqcjOuXhJHfK4,SO94xq1RAkMm2uF(u"ࡊࡦࡲࡳࡦᛙ"))
					if Tr8iRxJmbcEhftU5DSHzA:
						if L5VnDolF9OviImp6dJrEB2huy==hBvsQ7oCkKUdwjx58ml3EN(u"ࠬࡵ࡬ࡥࠩᖻ"): cyJHLQteCY7ns1DaIm = hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࡵࡱࡦࡤࡸࡪࡪࠧᖼ")
						elif L5VnDolF9OviImp6dJrEB2huy==bUdr5Hahw6sY8xJ(u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨᖽ"): cyJHLQteCY7ns1DaIm = SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠫᖾ")
						j0EsA2ZPvQrC = GujSHsyZOqkoWm8B7nLaXd9MpKPcUY
						if showDialogs:
							if cyJHLQteCY7ns1DaIm==LiRcTVUWuth70DmPy(u"ࠩࡸࡴࡩࡧࡴࡦࡦࠪᖿ"): aHKzv76JCVnprbY8w(iUeoLOsbHqP(u"ࠪࠫᗀ"),FnBiAjthS8MkXs67W(u"ࠫࠬᗁ"),wRxoKs10Syj7V4edYhtP(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᗂ"),xW2Arao7YVOemw(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้หึศใฬࠤ่อๆหࠢๅำ๏๋ษࠡ࠰࠱ࠤํอไษำ้ห๊าࠠใษ่ࠤอะอะ์ฮ๋ฬࡢ࡮࡝ࡰࠪᗃ")+ssZLBRtgnMkc7dSouQeGCx3r8m)
							elif cyJHLQteCY7ns1DaIm==YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠪᗄ"): aHKzv76JCVnprbY8w(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࠩᗅ"),FvNyZqaLKw(u"ࠩࠪᗆ"),zqdvcbP5L8BHh(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᗇ"),lc0dpSmwoPDjLnk(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢ็้ࠥะใ็่ࠢ์ั๎ฯสࠢไ๎้่ࠥะ์ࠣ࠲࠳่ࠦศๆหี๋อๅอࠢๅห๊ࠦศหอห๎ฯํว࡝ࡰ࡟ࡲࠬᗈ")+ssZLBRtgnMkc7dSouQeGCx3r8m)
					elif showDialogs: aHKzv76JCVnprbY8w(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬ࠭ᗉ"),sTcr7iDp5eFt4RoLMhuwq1A(u"࠭ࠧᗊ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᗋ"),g4g6bfkPtVGU5lIM3(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣห้ฮั็ษ่ะ๊ࠥๅࠡ์ึฮ฼๐ูࠡฬะำ๏ัࠠฤ๊ࠣฮะฮ๊ห๊ࠢิ์ࠦวๅวูหๆฯ࡜࡯࡞ࡱࠫᗌ")+ssZLBRtgnMkc7dSouQeGCx3r8m)
	elif showDialogs: aHKzv76JCVnprbY8w(g4g6bfkPtVGU5lIM3(u"ࠩࠪᗍ"),Me28A1sBLNIgUp5YCDyvT(u"ࠪࠫᗎ"),zqdvcbP5L8BHh(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᗏ"),FvNyZqaLKw(u"๊ࠬไฤีไࠤ࠳࠴่ࠠา๊ࠤฬ๊ลืษไอࠥเ๊า่ࠢ์ั๎ฯสࠢไ๎๋่ࠥศไ฼ࠤู๊ส้ั฼ࠤ฾๋วะࠢ࠱࠲ࠥ๎ไ่าสࠤ้อ๋ࠠีอ฻๏฿ࠠศๆหี๋อๅอࠢฦ๊ࠥ๐โ้็ࠣฬฯัศ๋ฬ๋ࠣีํࠠศๆศฺฬ็ษࠡล๋ࠤฯำฯ๋อ๊หࡡࡴ࡜࡯ࠩᗐ")+ssZLBRtgnMkc7dSouQeGCx3r8m)
	return Tr8iRxJmbcEhftU5DSHzA,cyJHLQteCY7ns1DaIm,j0EsA2ZPvQrC
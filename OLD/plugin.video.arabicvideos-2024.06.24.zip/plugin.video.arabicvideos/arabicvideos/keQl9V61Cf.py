# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'ARABICTOONS'
mmDwMlfoHtG5XT19VLIWqCR8i = '_ART_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==730: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==731: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url)
	elif mode==732: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==733: zpXG3Ky6ou8ndWHkb4 = hWPvGlXZ5arzV7(url)
	elif mode==734: zpXG3Ky6ou8ndWHkb4 = HL0knhNVMWSFXQAlGi9qxyZC(url)
	elif mode==735: zpXG3Ky6ou8ndWHkb4 = nxAv4S0ym7KBktgJhM9pc(url)
	elif mode==739: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',739,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'مسلسلات مميزة',NBm2aWhPzoTpdYn+'/top.php',735)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'مسلسلات',NBm2aWhPzoTpdYn+'/cartoon.php',734)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'افلام',NBm2aWhPzoTpdYn+'/movies.php',731)
	return
def HL0knhNVMWSFXQAlGi9qxyZC(url):
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الكل',url,731)
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','ARABICTOONS-SERIES_SUBMENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('label="navigation"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall("href='(.*?)'>(.*?)</a>",UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/'+ELbNB92cOh5dqtpVmi40kY
			title = 'حرف '+title
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,731)
	return
def nxAv4S0ym7KBktgJhM9pc(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','ARABICTOONS-SERIES_FEATURED-2nd')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="slider"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for title,ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi in items:
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/'+ELbNB92cOh5dqtpVmi40kY
			VFqpJjRySZvgi = NBm2aWhPzoTpdYn+'/'+VFqpJjRySZvgi
			title = title.strip(' ')
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,733,VFqpJjRySZvgi)
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','ARABICTOONS-TITLES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall("class='moviesBlocks(.*?)navigation",BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('class="movie".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
		ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/'+ELbNB92cOh5dqtpVmi40kY
		VFqpJjRySZvgi = NBm2aWhPzoTpdYn+'/'+VFqpJjRySZvgi
		title = title.strip(' ')
		if 'movies.php' in url: cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,732,VFqpJjRySZvgi)
		else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,733,VFqpJjRySZvgi)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"pagination(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[-1]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/'+ELbNB92cOh5dqtpVmi40kY
			title = title.strip(' ')
			title = DwNC3gEonizsB6a0v1F(title)
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,731)
	return
def hWPvGlXZ5arzV7(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','ARABICTOONS-EPISODES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall("class='moviesBlocks(.*?)script",BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('class="movie".*?title="(.*?)".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for title,ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,aLT5PozvdWkh in items:
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/'+ELbNB92cOh5dqtpVmi40kY
			VFqpJjRySZvgi = NBm2aWhPzoTpdYn+'/'+VFqpJjRySZvgi
			title = title.strip(' ')
			title = title+' '+aLT5PozvdWkh.strip(' ')
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,732,VFqpJjRySZvgi)
	return
def SUfe4unWoXBNFz90xqy(url):
	uuIjMn1YTf687WlRcOmhq4G23H = []
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','ARABICTOONS-PLAY-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	gI487voLsArVqW6Ffp = GGvHJKP9LUxEk10Fw.findall('source src="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if gI487voLsArVqW6Ffp:
		ELbNB92cOh5dqtpVmi40kY = gI487voLsArVqW6Ffp[0]
		if 'Referer=' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'|Referer=https://www.arabic-toons.com'
		uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY+'?named=__embed')
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(uuIjMn1YTf687WlRcOmhq4G23H,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	search = search.replace(' ','%20')
	zzvBg3ShiamAZ = ['','m']
	Y89Ig1NnB7SL4KJGPyXCQcdOoW = ['مسلسلات','افلام']
	if showDialogs:
		z0jyetbQwKrIclL9vJW = D1DJtzviFZSrA('اختر النوع المطلوب:', Y89Ig1NnB7SL4KJGPyXCQcdOoW)
		if z0jyetbQwKrIclL9vJW==-1: return
	else: z0jyetbQwKrIclL9vJW = 0
	type = zzvBg3ShiamAZ[z0jyetbQwKrIclL9vJW]
	url = NBm2aWhPzoTpdYn+'/livesearch.php?'+type+'&q='+search
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','ARABICTOONS-SEARCH-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)<',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/'+ELbNB92cOh5dqtpVmi40kY
		title = title.strip(' ')
		if type=='m': cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,732)
		else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,733)
	return
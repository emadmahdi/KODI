# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'ARABSEED'
headers = {'User-Agent':Y8Y6b7aLSUKjdE1Ae()}
mmDwMlfoHtG5XT19VLIWqCR8i = '_ARS_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
DDXTwbRBaj3e2rSsPQ = ['الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==250: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==251: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,text)
	elif mode==252: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==253: zpXG3Ky6ou8ndWHkb4 = hWPvGlXZ5arzV7(url)
	elif mode==254: zpXG3Ky6ou8ndWHkb4 = hWJg9P6lEYT5aGDizcb(url,'CATEGORIES___'+text)
	elif mode==255: zpXG3Ky6ou8ndWHkb4 = hWJg9P6lEYT5aGDizcb(url,'FILTERS___'+text)
	elif mode==256: zpXG3Ky6ou8ndWHkb4 = i7pbAuodvX3(url,text)
	elif mode==259: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',NBm2aWhPzoTpdYn+'/main','',headers,'','','ARABSEED-MENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',259,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فلتر محدد',NBm2aWhPzoTpdYn+'/category/اخرى',254)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فلتر كامل',NBm2aWhPzoTpdYn+'/category/اخرى',255)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'المميزة',NBm2aWhPzoTpdYn+'/main',251,'','','featured_main')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'جديد الأفلام',NBm2aWhPzoTpdYn+'/main',251,'','','new_movies')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'جديد الحلقات',NBm2aWhPzoTpdYn+'/main',251,'','','new_episodes')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'المضاف حديثاً',NBm2aWhPzoTpdYn+'/latest',251,'','','lastest')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb = GGvHJKP9LUxEk10Fw.findall('class="MenuHeader"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	jCxVUBZwAdOtIHM81rTJYiX3 = uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb[0]
	GzpIUylJrXRteaKPiNDLHuScmbgj = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)<',jCxVUBZwAdOtIHM81rTJYiX3,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in GzpIUylJrXRteaKPiNDLHuScmbgj:
		title = DwNC3gEonizsB6a0v1F(title)
		if title not in DDXTwbRBaj3e2rSsPQ and title!='':
			if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
			cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,256)
	return BBlXpmUyhFDwNtCVAHoE
def i7pbAuodvX3(url,type):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'',headers,'','','ARABSEED-SUBMENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	if 'class="SliderInSection' in BBlXpmUyhFDwNtCVAHoE: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الأكثر مشاهدة',url,251,'','','most')
	if 'class="MainSlides' in BBlXpmUyhFDwNtCVAHoE: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'المميزة',url,251,'','','featured')
	if 'class="LinksList' in BBlXpmUyhFDwNtCVAHoE:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="LinksList(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
			if len(EeQqAGc0W5r6nlBbChwfZL)>1 and type=='new_episodes': UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[1]
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)"(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				qPmCp1Q4gRekdAH = GGvHJKP9LUxEk10Fw.findall('</i>(.*?)<span>(.*?)<',title,GGvHJKP9LUxEk10Fw.DOTALL)
				try: LCaAcrp8R57YSD = qPmCp1Q4gRekdAH[0][0].replace('\n','').strip(' ')
				except: LCaAcrp8R57YSD = ''
				try: Ymsj3C2JhQEonLDA0wP4VbN = qPmCp1Q4gRekdAH[0][1].replace('\n','').strip(' ')
				except: Ymsj3C2JhQEonLDA0wP4VbN = ''
				qPmCp1Q4gRekdAH = LCaAcrp8R57YSD+' '+Ymsj3C2JhQEonLDA0wP4VbN
				if '<strong>' in title:
					Cyh9cRvbUW = GGvHJKP9LUxEk10Fw.findall('</i>(.*?)<',title,GGvHJKP9LUxEk10Fw.DOTALL)
					if Cyh9cRvbUW: qPmCp1Q4gRekdAH = Cyh9cRvbUW[0]
				if not qPmCp1Q4gRekdAH:
					Cyh9cRvbUW = GGvHJKP9LUxEk10Fw.findall('alt="(.*?)"',title,GGvHJKP9LUxEk10Fw.DOTALL)
					if Cyh9cRvbUW: qPmCp1Q4gRekdAH = Cyh9cRvbUW[0]
				if qPmCp1Q4gRekdAH:
					if 'key=' in ELbNB92cOh5dqtpVmi40kY: type = ELbNB92cOh5dqtpVmi40kY.split('key=')[1]
					else: type = 'newest'
					qPmCp1Q4gRekdAH = qPmCp1Q4gRekdAH.strip(' ')
					cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+qPmCp1Q4gRekdAH,ELbNB92cOh5dqtpVmi40kY,251,'','',type)
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(url,type):
	gSEirDUWV3,data,items = 'GET','',[]
	if type=='filters':
		if '?' in url:
			n7V8RZPHWqpy,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = 'POST',{}
			dR2vHyAtl8pJN1,IWPVYFU8cTixALJf = url.split('?')
			ExOjma9CSy2vQbPLhMUworYu = IWPVYFU8cTixALJf.split('&')
			for WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej in ExOjma9CSy2vQbPLhMUworYu:
				key,hieW1zRUG5w9AykJjv0X = WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej.split('=')
				Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd[key] = hieW1zRUG5w9AykJjv0X
			if ExOjma9CSy2vQbPLhMUworYu: gSEirDUWV3,url,data = n7V8RZPHWqpy,dR2vHyAtl8pJN1,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,gSEirDUWV3,url,data,headers,'','','ARABSEED-TITLES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	if type=='filters': EeQqAGc0W5r6nlBbChwfZL = [BBlXpmUyhFDwNtCVAHoE]
	elif 'featured' in type: EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="MainSlides(.*?)class="LinksList',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	elif type=='new_movies': EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('جديد الافلام.*?class="SliderInSection"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	elif type=='new_episodes': EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('جديد الحلقات.*?class="SliderInSection"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	elif type=='most': EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="SliderInSection(.*?)class="LinksList',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	else: EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="Blocks-UL"(.*?)class="AboElSeed"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if 'featured' in type:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		k9qOc0wRPHIJeB5 = GGvHJKP9LUxEk10Fw.findall('href="(.*?)" title="(.*?)".*?data-lazy.*? (src|data-image)="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if k9qOc0wRPHIJeB5:
			zzvBg3ShiamAZ,eyUmvNFiYsE,ia9mcUt3bwLQW7FTlrMdosG0P1yg4,o6SMpIvt0WjVymOxTeqE7A93Zindfr = zip(*k9qOc0wRPHIJeB5)
			items = zip(zzvBg3ShiamAZ,o6SMpIvt0WjVymOxTeqE7A93Zindfr,eyUmvNFiYsE)
	else:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('LoadingArea.*? href="(.*?)".*? data-\w{3,5}="(.*?)".*? alt="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	IcJOGsq3Ff7EmkiLx = []
	for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
		if 'WWE' in title: continue
		title = DwNC3gEonizsB6a0v1F(title)
		if 'الحلقة' in title:
			qUGxSK2VwsiBAdkDZnJ605vQeg = GGvHJKP9LUxEk10Fw.findall('(.*?) الحلقة \d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
			if qUGxSK2VwsiBAdkDZnJ605vQeg:
				title = '_MOD_' + qUGxSK2VwsiBAdkDZnJ605vQeg[0]
				if title not in IcJOGsq3Ff7EmkiLx:
					IcJOGsq3Ff7EmkiLx.append(title)
					cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,253,VFqpJjRySZvgi)
			else: cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,252,VFqpJjRySZvgi)
		elif '/selary/' in ELbNB92cOh5dqtpVmi40kY or 'مسلسل' in title:
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,253,VFqpJjRySZvgi)
		else:
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,252,VFqpJjRySZvgi)
	if type in ['newest','best','most']:
		items = GGvHJKP9LUxEk10Fw.findall('page-numbers" href="(.*?)">(.*?)<',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
			ELbNB92cOh5dqtpVmi40kY = DwNC3gEonizsB6a0v1F(ELbNB92cOh5dqtpVmi40kY)
			title = DwNC3gEonizsB6a0v1F(title)
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,251,'','',type)
	return
def hWPvGlXZ5arzV7(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'',headers,'','','ARABSEED-EPISODES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	BBlXpmUyhFDwNtCVAHoE = BBlXpmUyhFDwNtCVAHoE[10000:]
	items = GGvHJKP9LUxEk10Fw.findall('data-src="(.*?)".*?alt="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not items: return
	VFqpJjRySZvgi,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(' ')
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(' ')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="ContainerEpisodesList"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?<em>(.*?)</em>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,qUGxSK2VwsiBAdkDZnJ605vQeg in items:
			title = name+' - الحلقة رقم '+qUGxSK2VwsiBAdkDZnJ605vQeg
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,252,VFqpJjRySZvgi)
	else: cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+'ملف التشغيل',url,252,VFqpJjRySZvgi)
	return
def EEaiRwDrZlv0nUqBuepdFY2IL(title,ELbNB92cOh5dqtpVmi40kY):
	qPmCp1Q4gRekdAH = GGvHJKP9LUxEk10Fw.findall('[a-zA-Z-]+',title,GGvHJKP9LUxEk10Fw.DOTALL)
	if qPmCp1Q4gRekdAH: title = qPmCp1Q4gRekdAH[0]
	else: title = title+' '+RfKuIXwPAiWtmyF(ELbNB92cOh5dqtpVmi40kY,'name')
	title = title.replace('عرب سيد','').replace('مباشر','').replace('مشاهدة','')
	title = title.replace('ٍ','')
	title = title.replace('  ',' ').replace('  ',' ')
	return title
def SUfe4unWoXBNFz90xqy(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',url,'',headers,'','','ARABSEED-PLAY-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	dR2vHyAtl8pJN1 = WbTGMHnDysdYZ2lFA.url
	C83UXWf15zdwLA0 = RfKuIXwPAiWtmyF(dR2vHyAtl8pJN1,'url')
	headers['Referer'] = C83UXWf15zdwLA0+'/'
	nHECwv9lrspKxmdBMJgqZDFO,WdGuwqgVbJsHF80oSRDBy1,zzvBg3ShiamAZ = '','',[]
	JCXbm08kTvYOwBQH52Wt97 = GGvHJKP9LUxEk10Fw.findall('class="WatchButtons".*?href="(.*?)" class="(watch.*?)".*?href="(.*?)" class="(download.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if JCXbm08kTvYOwBQH52Wt97: nHECwv9lrspKxmdBMJgqZDFO,co2tTWeh79bO,WdGuwqgVbJsHF80oSRDBy1,kMZsFyP9qdmj5KXlJLA8xNeCg3f = JCXbm08kTvYOwBQH52Wt97[0]
	else:
		JCXbm08kTvYOwBQH52Wt97 = GGvHJKP9LUxEk10Fw.findall('class="WatchButtons".*?href="(.*?)" class="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if JCXbm08kTvYOwBQH52Wt97:
			ELbNB92cOh5dqtpVmi40kY,co2tTWeh79bO = JCXbm08kTvYOwBQH52Wt97[0]
			if 'watch' in co2tTWeh79bO: nHECwv9lrspKxmdBMJgqZDFO = ELbNB92cOh5dqtpVmi40kY
			else: WdGuwqgVbJsHF80oSRDBy1 = ELbNB92cOh5dqtpVmi40kY
	if nHECwv9lrspKxmdBMJgqZDFO:
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',nHECwv9lrspKxmdBMJgqZDFO,'',headers,'','','ARABSEED-PLAY-2nd')
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="WatcherArea"(.*?</ul>)',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			jdLl0wz4uC = EeQqAGc0W5r6nlBbChwfZL[0]
			jdLl0wz4uC = jdLl0wz4uC.replace('</ul>','<h3>')
			jdLl0wz4uC = jdLl0wz4uC.replace('<h3>','<h3><h3>')
			EHDeldN7L2k19JBUqhmsuSXiwV = GGvHJKP9LUxEk10Fw.findall('<h3>.*?(\d+)(.*?)<h3>',jdLl0wz4uC,GGvHJKP9LUxEk10Fw.DOTALL)
			if not EHDeldN7L2k19JBUqhmsuSXiwV: EHDeldN7L2k19JBUqhmsuSXiwV = [('',jdLl0wz4uC)]
			for dDZQSEGRTo9g85x1C,UCEFMfKbgpd in EHDeldN7L2k19JBUqhmsuSXiwV:
				if dDZQSEGRTo9g85x1C: dDZQSEGRTo9g85x1C = '____'+dDZQSEGRTo9g85x1C
				items = GGvHJKP9LUxEk10Fw.findall('data-link="(.*?)".*?<span>(.*?)</span>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
				for ELbNB92cOh5dqtpVmi40kY,name in items:
					if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = 'http:'+ELbNB92cOh5dqtpVmi40kY
					ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named='+name+'__watch'+dDZQSEGRTo9g85x1C
					zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
		gI487voLsArVqW6Ffp = GGvHJKP9LUxEk10Fw.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if not gI487voLsArVqW6Ffp: gI487voLsArVqW6Ffp = GGvHJKP9LUxEk10Fw.findall('class="containerIframe".*? SRC="(.*?)".*? HEIGHT="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if gI487voLsArVqW6Ffp:
			ELbNB92cOh5dqtpVmi40kY,dDZQSEGRTo9g85x1C = gI487voLsArVqW6Ffp[0]
			name = RfKuIXwPAiWtmyF(ELbNB92cOh5dqtpVmi40kY,'name')
			if '%' in dDZQSEGRTo9g85x1C: ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named='+name+'__embed__'
			else: ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named='+name+'__embed____'+dDZQSEGRTo9g85x1C
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	if WdGuwqgVbJsHF80oSRDBy1:
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',WdGuwqgVbJsHF80oSRDBy1,'',headers,'','','ARABSEED-PLAY-3rd')
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="DownloadArea"(.*?)function',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,title,dDZQSEGRTo9g85x1C in items:
				if not ELbNB92cOh5dqtpVmi40kY: continue
				if 'reviewstation' in ELbNB92cOh5dqtpVmi40kY: continue
				ELbNB92cOh5dqtpVmi40kY = GhPlajzTxY8(ELbNB92cOh5dqtpVmi40kY)
				ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named='+title+'__download____'+dDZQSEGRTo9g85x1C
				zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	OKzosLNcypn5RVdTHM14XGB3FChx = str(zzvBg3ShiamAZ)
	ItyhSWRVud = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(hieW1zRUG5w9AykJjv0X in OKzosLNcypn5RVdTHM14XGB3FChx for hieW1zRUG5w9AykJjv0X in ItyhSWRVud):
		aHKzv76JCVnprbY8w('','','رسالة من المبرمج','جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(zzvBg3ShiamAZ,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if not search: search = yMRXZIpKxlSkaE6iCO()
	if not search: return
	search = search.replace(' ','+')
	url = NBm2aWhPzoTpdYn+'/find/?find='+search
	xoiXMWjJC3pnQqurIGPkRSl8e(url,'search')
	return
def hWJg9P6lEYT5aGDizcb(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter=='': zTi1IvPRBr,CcMQl4P9H8SkouF7srzBYdDKUNA = '',''
	else: zTi1IvPRBr,CcMQl4P9H8SkouF7srzBYdDKUNA = filter.split('___')
	if type=='CATEGORIES':
		if RFlSKD5EAaCb[0]+'==' not in zTi1IvPRBr: BBskpK6cGZJ = RFlSKD5EAaCb[0]
		for umP72LtwzUTWHFAlJVyheEp5 in range(len(RFlSKD5EAaCb[0:-1])):
			if RFlSKD5EAaCb[umP72LtwzUTWHFAlJVyheEp5]+'==' in zTi1IvPRBr: BBskpK6cGZJ = RFlSKD5EAaCb[umP72LtwzUTWHFAlJVyheEp5+1]
		i2i6oT5O34GLAgyPs8DdIfV = zTi1IvPRBr+'&&'+BBskpK6cGZJ+'==0'
		WtVSCYeOJDGQf5sq8KZxkzyXwvBF = CcMQl4P9H8SkouF7srzBYdDKUNA+'&&'+BBskpK6cGZJ+'==0'
		sDnjCtlaGyxmr9fqK = i2i6oT5O34GLAgyPs8DdIfV.strip('&&')+'___'+WtVSCYeOJDGQf5sq8KZxkzyXwvBF.strip('&&')
		BnNGcaxDl0pPVdmq3j1kQu6HJEs4 = fx0tQnZhGieDkA(CcMQl4P9H8SkouF7srzBYdDKUNA,'modified_filters')
		dR2vHyAtl8pJN1 = url+'//getposts??'+BnNGcaxDl0pPVdmq3j1kQu6HJEs4
	elif type=='FILTERS':
		QHWZwB3stnOp5SghLfl2zir6YCI = fx0tQnZhGieDkA(zTi1IvPRBr,'modified_values')
		QHWZwB3stnOp5SghLfl2zir6YCI = GhPlajzTxY8(QHWZwB3stnOp5SghLfl2zir6YCI)
		if CcMQl4P9H8SkouF7srzBYdDKUNA!='': CcMQl4P9H8SkouF7srzBYdDKUNA = fx0tQnZhGieDkA(CcMQl4P9H8SkouF7srzBYdDKUNA,'modified_filters')
		if CcMQl4P9H8SkouF7srzBYdDKUNA=='': dR2vHyAtl8pJN1 = url
		else: dR2vHyAtl8pJN1 = url+'//getposts??'+CcMQl4P9H8SkouF7srzBYdDKUNA
		gmFNXM58sV6qH = kzawTQoulG7PJW8jt3CEnpx(dR2vHyAtl8pJN1)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'أظهار قائمة الفيديو التي تم اختيارها ',gmFNXM58sV6qH,251,'','','filters')
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+' [[   '+QHWZwB3stnOp5SghLfl2zir6YCI+'   ]]',gmFNXM58sV6qH,251,'','','filters')
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'POST',url,'',headers,'','','ARABSEED-FILTERS_MENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	uzsQS7qeryECAnf = GGvHJKP9LUxEk10Fw.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	toZnAUJfN3CslkjdayQ2gExp4rLK = GGvHJKP9LUxEk10Fw.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	nQKyI93hUT2ZGl6zimxDWe04ckj = uzsQS7qeryECAnf+toZnAUJfN3CslkjdayQ2gExp4rLK
	dict = {}
	for name,mmRDx1Zhfjq4oFdsNey2EwCBlUOQv,UCEFMfKbgpd in nQKyI93hUT2ZGl6zimxDWe04ckj:
		items = GGvHJKP9LUxEk10Fw.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			GzpIUylJrXRteaKPiNDLHuScmbgj = GGvHJKP9LUxEk10Fw.findall('data-rate="(.*?)".*?<em>(.*?)</em>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			items = []
			for RHb9zAjcuTIoyZ0aDgS1pQYmUs8,hieW1zRUG5w9AykJjv0X in GzpIUylJrXRteaKPiNDLHuScmbgj: items.append([RHb9zAjcuTIoyZ0aDgS1pQYmUs8,'',hieW1zRUG5w9AykJjv0X])
			mmRDx1Zhfjq4oFdsNey2EwCBlUOQv = 'rate'
			name = 'التقييم'
		else: mmRDx1Zhfjq4oFdsNey2EwCBlUOQv = items[0][1]
		if '==' not in dR2vHyAtl8pJN1: dR2vHyAtl8pJN1 = url
		if type=='CATEGORIES':
			if BBskpK6cGZJ!=mmRDx1Zhfjq4oFdsNey2EwCBlUOQv: continue
			elif len(items)<=1:
				if mmRDx1Zhfjq4oFdsNey2EwCBlUOQv==RFlSKD5EAaCb[-1]: xoiXMWjJC3pnQqurIGPkRSl8e(dR2vHyAtl8pJN1)
				else: hWJg9P6lEYT5aGDizcb(dR2vHyAtl8pJN1,'CATEGORIES___'+sDnjCtlaGyxmr9fqK)
				return
			else:
				gmFNXM58sV6qH = kzawTQoulG7PJW8jt3CEnpx(dR2vHyAtl8pJN1)
				if mmRDx1Zhfjq4oFdsNey2EwCBlUOQv==RFlSKD5EAaCb[-1]: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع ',gmFNXM58sV6qH,251,'','','filters')
				else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع ',dR2vHyAtl8pJN1,254,'','',sDnjCtlaGyxmr9fqK)
		elif type=='FILTERS':
			i2i6oT5O34GLAgyPs8DdIfV = zTi1IvPRBr+'&&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'==0'
			WtVSCYeOJDGQf5sq8KZxkzyXwvBF = CcMQl4P9H8SkouF7srzBYdDKUNA+'&&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'==0'
			sDnjCtlaGyxmr9fqK = i2i6oT5O34GLAgyPs8DdIfV+'___'+WtVSCYeOJDGQf5sq8KZxkzyXwvBF
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع :'+name,dR2vHyAtl8pJN1,255,'','',sDnjCtlaGyxmr9fqK)
		dict[mmRDx1Zhfjq4oFdsNey2EwCBlUOQv] = {}
		for RHb9zAjcuTIoyZ0aDgS1pQYmUs8,X4XyOPCEu65AMYebxwaVW,hieW1zRUG5w9AykJjv0X in items:
			if RHb9zAjcuTIoyZ0aDgS1pQYmUs8 in DDXTwbRBaj3e2rSsPQ: continue
			if 'الكل' in RHb9zAjcuTIoyZ0aDgS1pQYmUs8: continue
			RHb9zAjcuTIoyZ0aDgS1pQYmUs8 = DwNC3gEonizsB6a0v1F(RHb9zAjcuTIoyZ0aDgS1pQYmUs8)
			now0UFQXvPyWA8TNluJ53M,qPmCp1Q4gRekdAH = RHb9zAjcuTIoyZ0aDgS1pQYmUs8,RHb9zAjcuTIoyZ0aDgS1pQYmUs8
			qPmCp1Q4gRekdAH = name+': '+now0UFQXvPyWA8TNluJ53M
			dict[mmRDx1Zhfjq4oFdsNey2EwCBlUOQv][hieW1zRUG5w9AykJjv0X] = qPmCp1Q4gRekdAH
			i2i6oT5O34GLAgyPs8DdIfV = zTi1IvPRBr+'&&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'=='+now0UFQXvPyWA8TNluJ53M
			WtVSCYeOJDGQf5sq8KZxkzyXwvBF = CcMQl4P9H8SkouF7srzBYdDKUNA+'&&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'=='+hieW1zRUG5w9AykJjv0X
			KPcDQTE3e8duMHO6Lbgo1n = i2i6oT5O34GLAgyPs8DdIfV+'___'+WtVSCYeOJDGQf5sq8KZxkzyXwvBF
			if type=='FILTERS':
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+qPmCp1Q4gRekdAH,url,255,'','',KPcDQTE3e8duMHO6Lbgo1n)
			elif type=='CATEGORIES' and RFlSKD5EAaCb[-2]+'==' in zTi1IvPRBr:
				BnNGcaxDl0pPVdmq3j1kQu6HJEs4 = fx0tQnZhGieDkA(WtVSCYeOJDGQf5sq8KZxkzyXwvBF,'modified_filters')
				XwyU6PQgprMI0 = url+'//getposts??'+BnNGcaxDl0pPVdmq3j1kQu6HJEs4
				gmFNXM58sV6qH = kzawTQoulG7PJW8jt3CEnpx(XwyU6PQgprMI0)
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+qPmCp1Q4gRekdAH,gmFNXM58sV6qH,251,'','','filters')
			else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+qPmCp1Q4gRekdAH,url,254,'','',KPcDQTE3e8duMHO6Lbgo1n)
	return
RFlSKD5EAaCb = ['category','country','release-year']
FLB7zJRpxn8g26ehaD4udskE9tc = ['category','country','genre','release-year','language','quality','rate']
def kzawTQoulG7PJW8jt3CEnpx(url):
	AGzP83Nfi4DElBQwaCugnXU = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',AGzP83Nfi4DElBQwaCugnXU)
	url = url.replace('/category/اخرى','')
	if AGzP83Nfi4DElBQwaCugnXU not in url: url = url+AGzP83Nfi4DElBQwaCugnXU
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def fx0tQnZhGieDkA(FZj067Q2PlC8EsG9c5yiWpzNRq,mode):
	FZj067Q2PlC8EsG9c5yiWpzNRq = FZj067Q2PlC8EsG9c5yiWpzNRq.strip('&&')
	HG4gSjopqQwsPeivrcmn,BbgO8pxWfVA41KGzed = {},''
	if '==' in FZj067Q2PlC8EsG9c5yiWpzNRq:
		items = FZj067Q2PlC8EsG9c5yiWpzNRq.split('&&')
		for BrVNsC72UYWES4A in items:
			RRSq2Qx0MfkFHLt,hieW1zRUG5w9AykJjv0X = BrVNsC72UYWES4A.split('==')
			HG4gSjopqQwsPeivrcmn[RRSq2Qx0MfkFHLt] = hieW1zRUG5w9AykJjv0X
	for key in FLB7zJRpxn8g26ehaD4udskE9tc:
		if key in list(HG4gSjopqQwsPeivrcmn.keys()): hieW1zRUG5w9AykJjv0X = HG4gSjopqQwsPeivrcmn[key]
		else: hieW1zRUG5w9AykJjv0X = '0'
		if '%' not in hieW1zRUG5w9AykJjv0X: hieW1zRUG5w9AykJjv0X = mGfdCk4Hyclg9RjD(hieW1zRUG5w9AykJjv0X)
		if mode=='modified_values' and hieW1zRUG5w9AykJjv0X!='0': BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed+' + '+hieW1zRUG5w9AykJjv0X
		elif mode=='modified_filters' and hieW1zRUG5w9AykJjv0X!='0': BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed+'&&'+key+'=='+hieW1zRUG5w9AykJjv0X
		elif mode=='all': BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed+'&&'+key+'=='+hieW1zRUG5w9AykJjv0X
	BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed.strip(' + ')
	BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed.strip('&&')
	return BbgO8pxWfVA41KGzed
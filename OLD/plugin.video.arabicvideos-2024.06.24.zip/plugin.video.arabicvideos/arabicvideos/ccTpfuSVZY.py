# -*- coding: utf-8 -*-
import sys as GGtWyVoJReUuEBCdAagiL1YXO8
ggqTOXpCEcQD68f3oxrKilaSvkdtN = GGtWyVoJReUuEBCdAagiL1YXO8.version_info [0] == 2
pQ14eMnbYBK0xGywR7SuFChJdONj6 = 2048
y65ArzSx9RZh = 7
def MUzuWiALbXp6w5 (TMw2a0zHkY9lcdIvLFZXrS):
	global ynv9hpqlRAJuN0gXrEscaoP5dMWYDO
	Icnd5Dq4krBK3iYg2xNZHF = ord (TMw2a0zHkY9lcdIvLFZXrS [-1])
	u05ustK47xXQZbyFerWTROY = TMw2a0zHkY9lcdIvLFZXrS [:-1]
	BXAu3ZJQ9IPLg7kiy4K06ha = Icnd5Dq4krBK3iYg2xNZHF % len (u05ustK47xXQZbyFerWTROY)
	nRXUw1Fg0DSrkYGL = u05ustK47xXQZbyFerWTROY [:BXAu3ZJQ9IPLg7kiy4K06ha] + u05ustK47xXQZbyFerWTROY [BXAu3ZJQ9IPLg7kiy4K06ha:]
	if ggqTOXpCEcQD68f3oxrKilaSvkdtN:
		sW7Qyn32Zidt5TE4w96 = unicode () .join ([unichr (ord (Lk9Jh0wu7aNAE) - pQ14eMnbYBK0xGywR7SuFChJdONj6 - (Ebxc6eiUkyVNfMBs3CRIOArQ4h + Icnd5Dq4krBK3iYg2xNZHF) % y65ArzSx9RZh) for Ebxc6eiUkyVNfMBs3CRIOArQ4h, Lk9Jh0wu7aNAE in enumerate (nRXUw1Fg0DSrkYGL)])
	else:
		sW7Qyn32Zidt5TE4w96 = str () .join ([chr (ord (Lk9Jh0wu7aNAE) - pQ14eMnbYBK0xGywR7SuFChJdONj6 - (Ebxc6eiUkyVNfMBs3CRIOArQ4h + Icnd5Dq4krBK3iYg2xNZHF) % y65ArzSx9RZh) for Ebxc6eiUkyVNfMBs3CRIOArQ4h, Lk9Jh0wu7aNAE in enumerate (nRXUw1Fg0DSrkYGL)])
	return eval (sW7Qyn32Zidt5TE4w96)
Cu1704YofAbr3QTm,oh5Ptv7RjM3qLk1eEZJbcVzKis4d,LiRcTVUWuth70DmPy=MUzuWiALbXp6w5,MUzuWiALbXp6w5,MUzuWiALbXp6w5
pq3Z6xaELn0NW7PgAeI1bCRwdu,UTelCo0ihE1d5R,Me28A1sBLNIgUp5YCDyvT=LiRcTVUWuth70DmPy,oh5Ptv7RjM3qLk1eEZJbcVzKis4d,Cu1704YofAbr3QTm
kEhAHvti6Vnsfx,g4g6bfkPtVGU5lIM3,E6MIKdpBomef=Me28A1sBLNIgUp5YCDyvT,UTelCo0ihE1d5R,pq3Z6xaELn0NW7PgAeI1bCRwdu
wRxoKs10Syj7V4edYhtP,yA5z6LIXBlo41PRVMY87wOisFp,iUeoLOsbHqP=E6MIKdpBomef,g4g6bfkPtVGU5lIM3,kEhAHvti6Vnsfx
iRoLg2m47tnDATBHGCSPNyx,xW2Arao7YVOemw,l30iT7pjzmXk8dvwSNyUR1aZO4tWh=iUeoLOsbHqP,yA5z6LIXBlo41PRVMY87wOisFp,wRxoKs10Syj7V4edYhtP
dshJSmRqeiP9nap2,FnBiAjthS8MkXs67W,FvNyZqaLKw=l30iT7pjzmXk8dvwSNyUR1aZO4tWh,xW2Arao7YVOemw,iRoLg2m47tnDATBHGCSPNyx
SO94xq1RAkMm2uF,bUdr5Hahw6sY8xJ,XzrqbGDIy54juixkMA=FvNyZqaLKw,FnBiAjthS8MkXs67W,dshJSmRqeiP9nap2
p72fnFtcPix5UKwr9YNzW,sTcr7iDp5eFt4RoLMhuwq1A,SyENPzdOon6uxcLXMhqb14aDlB9r=XzrqbGDIy54juixkMA,bUdr5Hahw6sY8xJ,SO94xq1RAkMm2uF
zqdvcbP5L8BHh,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF,lc0dpSmwoPDjLnk=SyENPzdOon6uxcLXMhqb14aDlB9r,sTcr7iDp5eFt4RoLMhuwq1A,p72fnFtcPix5UKwr9YNzW
QVZl0O8yUIzdGDTfYcn5H37uWmb2,hRNlWkwDitzVpbSO3TIdAm5YGjaZ,fprnld4CZo=lc0dpSmwoPDjLnk,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF,zqdvcbP5L8BHh
hBvsQ7oCkKUdwjx58ml3EN,G5DeRbUpFj8E9OtJLvlo2fWmZC,S4SOKF2QbBhjCd3RrVMuHIzE=fprnld4CZo,hRNlWkwDitzVpbSO3TIdAm5YGjaZ,QVZl0O8yUIzdGDTfYcn5H37uWmb2
from euYNPkoBDm import *
import bidi.algorithm as Y5rNeFs8E7UJqRAQ9kP6,bidi.mirror as dPAWpDKx0TBlMJjy5E2fh,base64 as hNe0ECZHr9B6,requests as DJ1rx9fvXIgUS7sZkVlOeGHb
cTJphS1nFz5EUgNWm86C = dshJSmRqeiP9nap2(u"ࠩࡏࡍࡇ࡙ࡔࡘࡑࠪಏ")
InAzqY0hV5WkRsfgTmpoXQL4uCN = {}
D6DrJsclfY = []
if u4ChFMGf6K93tbDjJ12zi0YQsAHyP:
	E30Sy9afZK8Rd1uV4PkM2zLW = yynEsDtujBlKNcT0grm8FeLi92A.translatePath(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡸࡣ࡯ࡦࠫಐ"))
	mjaho7R5dY6eg = yynEsDtujBlKNcT0grm8FeLi92A.translatePath(fprnld4CZo(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩࠬ಑"))
	j2ByCaJDKcUiW5MdO = yynEsDtujBlKNcT0grm8FeLi92A.translatePath(bUdr5Hahw6sY8xJ(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩಒ"))
	QLmA1IVR5dvG = WpgZTyqoMAPhwGiXF.path.join(mjaho7R5dY6eg,hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨಓ"),Me28A1sBLNIgUp5YCDyvT(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩಔ"),LiRcTVUWuth70DmPy(u"ࠨࡃࡧࡨࡴࡴࡳ࠴࠵࠱ࡨࡧ࠭ಕ"))
	TKVanGt79Wev8mPO1BZjQASpJwfzI = WpgZTyqoMAPhwGiXF.path.join(mjaho7R5dY6eg,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫಖ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬಗ"),g4g6bfkPtVGU5lIM3(u"࡛ࠫ࡯ࡥࡸࡏࡲࡨࡪࡹ࠶࠯ࡦࡥࠫಘ"))
	OOP32CuaLYlWIscZg4tr19kMx = WpgZTyqoMAPhwGiXF.path.join(mjaho7R5dY6eg,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧಙ"),UTelCo0ihE1d5R(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨಚ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧಛ"))
	P4F7od5xLE0quekH3nSzXj92ThwINY = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࡶࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩಜ")
	from urllib.parse import quote as _ycmolWPUNz
else:
	E30Sy9afZK8Rd1uV4PkM2zLW = cEZpW924rqNYm5.translatePath(Cu1704YofAbr3QTm(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡾࡢ࡮ࡥࠪಝ"))
	mjaho7R5dY6eg = cEZpW924rqNYm5.translatePath(Cu1704YofAbr3QTm(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫಞ"))
	j2ByCaJDKcUiW5MdO = cEZpW924rqNYm5.translatePath(zqdvcbP5L8BHh(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯࡭ࡱࡪࡴࡦࡺࡨࠨಟ"))
	QLmA1IVR5dvG = WpgZTyqoMAPhwGiXF.path.join(mjaho7R5dY6eg,SO94xq1RAkMm2uF(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧಠ"),iRoLg2m47tnDATBHGCSPNyx(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨಡ"),bUdr5Hahw6sY8xJ(u"ࠧࡂࡦࡧࡳࡳࡹ࠲࠸࠰ࡧࡦࠬಢ"))
	TKVanGt79Wev8mPO1BZjQASpJwfzI = WpgZTyqoMAPhwGiXF.path.join(mjaho7R5dY6eg,Me28A1sBLNIgUp5YCDyvT(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪಣ"),zqdvcbP5L8BHh(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫತ"),sTcr7iDp5eFt4RoLMhuwq1A(u"࡚ࠪ࡮࡫ࡷࡎࡱࡧࡩࡸ࠼࠮ࡥࡤࠪಥ"))
	OOP32CuaLYlWIscZg4tr19kMx = WpgZTyqoMAPhwGiXF.path.join(mjaho7R5dY6eg,p72fnFtcPix5UKwr9YNzW(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭ದ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧಧ"),UTelCo0ihE1d5R(u"࠭ࡔࡦࡺࡷࡹࡷ࡫ࡳ࠲࠵࠱ࡨࡧ࠭ನ"))
	P4F7od5xLE0quekH3nSzXj92ThwINY = oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࡵࠨ࡞ࡸ࠴࠷ࡪ࠱ࠨ಩").encode(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨࡷࡷࡪ࠽࠭ಪ"))
	from urllib import quote as _ycmolWPUNz
KpkbcfSIir6dCFMjwZy4gTYGuR0UA9 = WpgZTyqoMAPhwGiXF.path.join(j2ByCaJDKcUiW5MdO,yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩ࡮ࡳࡩ࡯࠮࡭ࡱࡪࠫಫ"))
KKogQqwJNpkny6M71bS4fEc = WpgZTyqoMAPhwGiXF.path.join(j2ByCaJDKcUiW5MdO,hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪ࡯ࡴࡪࡩ࠯ࡱ࡯ࡨ࠳ࡲ࡯ࡨࠩಬ"))
QQB4Wufj98FOvHNUocVJ06RhMI = WpgZTyqoMAPhwGiXF.path.join(JXUQZHLxEgTFbrRC7n9,yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫ࡮ࡶࡴࡷ࠳ࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭ಭ"))
aahFmuA9BMNnCLbxV2yO1QtRG = WpgZTyqoMAPhwGiXF.path.join(JXUQZHLxEgTFbrRC7n9,dshJSmRqeiP9nap2(u"ࠬ࡯ࡰࡵࡸ࠵ࡨࡦࡺࡡࡠࡡࡢ࠲ࡩࡨࠧಮ"))
Uc2C9tgfhvOQxu = WpgZTyqoMAPhwGiXF.path.join(JXUQZHLxEgTFbrRC7n9,dshJSmRqeiP9nap2(u"࠭࡭࠴ࡷࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭ಯ"))
PGIWHNLQuRoK1M = WpgZTyqoMAPhwGiXF.path.join(JXUQZHLxEgTFbrRC7n9,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧࡧࡣࡹࡳࡺࡸࡩࡵࡧࡶ࠲ࡩࡧࡴࠨರ"))
yHIlrROtxSpB2u9wsKhG41bLcom = WpgZTyqoMAPhwGiXF.path.join(JXUQZHLxEgTFbrRC7n9,hBvsQ7oCkKUdwjx58ml3EN(u"ࠨ࡫ࡳࡸࡻ࡬ࡩ࡭ࡧࡢࡣࡤ࠴ࡤࡢࡶࠪಱ"))
ERFOPQbuZhdSDy1 = WpgZTyqoMAPhwGiXF.path.join(JXUQZHLxEgTFbrRC7n9,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࡰ࠷ࡺ࡬ࡩ࡭ࡧࡢࡣࡤ࠴ࡤࡢࡶࠪಲ"))
YYyD6xzmsKbBTkrqEC = WpgZTyqoMAPhwGiXF.path.join(JXUQZHLxEgTFbrRC7n9,Me28A1sBLNIgUp5YCDyvT(u"ࠪ࡭ࡲࡧࡧࡦࡵࠪಳ"))
SHbrM0UsieLa6xBZFlKPduDN4 = WpgZTyqoMAPhwGiXF.path.join(YYyD6xzmsKbBTkrqEC,hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡷࠬ಴"))
rJOGPocvjmQy1fSNHthMzRCuZ8D = WpgZTyqoMAPhwGiXF.path.join(SHbrM0UsieLa6xBZFlKPduDN4,SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠬࡪࡩࡢ࡮ࡲ࡫ࡤ࠶࠰࠱࠲ࡢ࠲ࡵࡴࡧࠨವ"))
bdmxngE9YGIeQ = utF79ZlYs0VjSMJkOv4UHdf.Addon().getAddonInfo(LiRcTVUWuth70DmPy(u"࠭ࡰࡢࡶ࡫ࠫಶ"))
IINvt3OAGhTLUm = WpgZTyqoMAPhwGiXF.path.join(bdmxngE9YGIeQ,FnBiAjthS8MkXs67W(u"ࠧࡪࡥࡲࡲ࠳ࡶ࡮ࡨࠩಷ"))
HX9MlF3SYzNv1OuGK = WpgZTyqoMAPhwGiXF.path.join(bdmxngE9YGIeQ,l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨࡶ࡫ࡹࡲࡨ࠮ࡱࡰࡪࠫಸ"))
a3m91diCBeJ2QYtho = WpgZTyqoMAPhwGiXF.path.join(bdmxngE9YGIeQ,G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩࡩࡥࡳࡧࡲࡵ࠰ࡳࡲ࡬࠭ಹ"))
A7WmPjRNeJHzEvutcGirYgFw1xD = WpgZTyqoMAPhwGiXF.path.join(bdmxngE9YGIeQ,SO94xq1RAkMm2uF(u"ࠪࡦࡦࡴ࡮ࡦࡴ࠱ࡴࡳ࡭ࠧ಺"))
VVwpTD6yaASd4lNQf5MxLU0K8 = WpgZTyqoMAPhwGiXF.path.join(bdmxngE9YGIeQ,dshJSmRqeiP9nap2(u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫࠮ࡱࡰࡪࠫ಻"))
iiAVemYJBSNUG4C8Mhvs = WpgZTyqoMAPhwGiXF.path.join(bdmxngE9YGIeQ,kEhAHvti6Vnsfx(u"ࠬࡶ࡯ࡴࡶࡨࡶ࠳ࡶ࡮ࡨ಼ࠩ"))
NMo5hwcf9esO3lVK1Z0u = WpgZTyqoMAPhwGiXF.path.join(bdmxngE9YGIeQ,E6MIKdpBomef(u"࠭ࡣ࡭ࡧࡤࡶࡱࡵࡧࡰ࠰ࡳࡲ࡬࠭ಽ"))
r6r3MYfl17dang2ZXwQ8zGCE = WpgZTyqoMAPhwGiXF.path.join(bdmxngE9YGIeQ,sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࡤ࡮ࡨࡥࡷࡧࡲࡵ࠰ࡳࡲ࡬࠭ಾ"))
L2M7I0quXgicoQF1k = WpgZTyqoMAPhwGiXF.path.join(bdmxngE9YGIeQ,oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨ࡯ࡨࡲࡺ࠴ࡰ࡯ࡩࠪಿ"))
MMOICsmwlWaPz41YhFT2jpxJZy = WpgZTyqoMAPhwGiXF.path.join(bdmxngE9YGIeQ,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࡦ࡬ࡦࡴࡧࡦ࡮ࡲ࡫࠳ࡺࡸࡵࠩೀ"))
verdwoPF9GcOh1psxjHB34lgRMI = WpgZTyqoMAPhwGiXF.path.join(mjaho7R5dY6eg,iRoLg2m47tnDATBHGCSPNyx(u"ࠪࡥࡩࡪ࡯࡯ࡵࠪು"))
EIAamxotvSk7BR6QM = WpgZTyqoMAPhwGiXF.path.join(mjaho7R5dY6eg,SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭ೂ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩೃ"),ssZLBRtgnMkc7dSouQeGCx3r8m,oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬೄ"))
LxI6HlyziFS = WpgZTyqoMAPhwGiXF.path.join(E30Sy9afZK8Rd1uV4PkM2zLW,kEhAHvti6Vnsfx(u"ࠧ࡮ࡧࡧ࡭ࡦ࠭೅"),XzrqbGDIy54juixkMA(u"ࠨࡈࡲࡲࡹࡹࠧೆ"),XzrqbGDIy54juixkMA(u"ࠩࡤࡶ࡮ࡧ࡬࠯ࡶࡷࡪࠬೇ"))
pyq71xCY26s8hNQ = dshJSmRqeiP9nap2(u"࠻ᔢ")
Ri7qe1L6bhlGz3cyst4KSj = [Me28A1sBLNIgUp5YCDyvT(u"ูࠪๆืࠧೈ"),kEhAHvti6Vnsfx(u"ࠫศ๎ไࠨ೉"),xW2Arao7YVOemw(u"ࠬัว็์ࠪೊ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"࠭หศๆฮࠫೋ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧาษห฽ࠬೌ"),fprnld4CZo(u"ࠨะส್ุ้࠭"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠩึหิูࠧ೎"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠪืฬฮูࠨ೏"),dshJSmRqeiP9nap2(u"ࠫะอๅ็ࠩ೐"),XzrqbGDIy54juixkMA(u"ࠬะวิ฻ࠪ೑"),kEhAHvti6Vnsfx(u"ู࠭ศึิࠫ೒")]
bKugLoHc61A7wqrmVs9G = wRxoKs10Syj7V4edYhtP(u"ࠧ⸼ࠢ⼠ࠤⸯࠦ⸻ࠨ೓")
gIQHnCBYeXj = [bUdr5Hahw6sY8xJ(u"ࠨ࡛ࡗࡆࡤࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ೔")]
CvE0fghAwDMPzj46ZdlJ3B9NeYs1u = [hBvsQ7oCkKUdwjx58ml3EN(u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝ࠫೕ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠭ೖ"),SO94xq1RAkMm2uF(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐࠨ೗"),g4g6bfkPtVGU5lIM3(u"ࠬࡋࡇ࡚ࡆࡈࡅࡉ࠭೘"),zqdvcbP5L8BHh(u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅࠩ೙"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࡎࡑ࡙ࡗ࠹࡛ࠧ೚"),LiRcTVUWuth70DmPy(u"ࠨࡏ࡜ࡇࡎࡓࡁࠨ೛"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠩࡏࡅࡗࡕ࡚ࡂࠩ೜"),zqdvcbP5L8BHh(u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍࠬೝ"),XzrqbGDIy54juixkMA(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠭ೞ"),zqdvcbP5L8BHh(u"ࠬࡇࡌࡂࡔࡄࡆࠬ೟")]
CvE0fghAwDMPzj46ZdlJ3B9NeYs1u += [LiRcTVUWuth70DmPy(u"࠭ࡈࡆࡎࡄࡐࠬೠ"),FvNyZqaLKw(u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠭ೡ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏࠪೢ"),LiRcTVUWuth70DmPy(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖࠪೣ"),SO94xq1RAkMm2uF(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔࠬ೤"),LiRcTVUWuth70DmPy(u"ࠫࡊࡍ࡙ࡏࡑ࡚ࠫ೥"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕࠧ೦"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࡐࡂࡐࡈࡘࠬ೧"),p72fnFtcPix5UKwr9YNzW(u"ࠧࡄࡋࡐࡅ࠹࡛ࠧ೨"),FvNyZqaLKw(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࡚ࡓࡗࡑࠧ೩")]
vvnUPVYd1mZHa9li = [lc0dpSmwoPDjLnk(u"ࠩࡌࡔ࡙࡜ࠧ೪"),Me28A1sBLNIgUp5YCDyvT(u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭೫"),bUdr5Hahw6sY8xJ(u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩ೬"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪ೭")]
vvnUPVYd1mZHa9li += [kEhAHvti6Vnsfx(u"࠭ࡍ࠴ࡗࠪ೮"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩ೯"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬ೰"),bUdr5Hahw6sY8xJ(u"ࠩࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭ೱ")]
vvnUPVYd1mZHa9li += [LiRcTVUWuth70DmPy(u"ࠪࡍࡋࡏࡌࡎࠩೲ"),Me28A1sBLNIgUp5YCDyvT(u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪೳ"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬ೴")]
vvnUPVYd1mZHa9li += [iRoLg2m47tnDATBHGCSPNyx(u"࠭ࡁࡌ࡙ࡄࡑࠬ೵"),fprnld4CZo(u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇࠩ೶"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ೷"),FvNyZqaLKw(u"ࠩࡄࡏࡔࡇࡍࠨ೸"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚ࠬ೹")]
vvnUPVYd1mZHa9li += [l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧ೺"),xW2Arao7YVOemw(u"ࠬࡈࡏࡌࡔࡄࠫ೻"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨ೼"),FvNyZqaLKw(u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗࠬ೽"),iUeoLOsbHqP(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪ೾"),lc0dpSmwoPDjLnk(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠵ࠫ೿")]
ylLUS9Wt8xE1uZ7Czcoba = [XzrqbGDIy54juixkMA(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫഀ"),dshJSmRqeiP9nap2(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲࡜ࡉࡅࡇࡒࡗࠬഁ"),xW2Arao7YVOemw(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩം"),S4SOKF2QbBhjCd3RrVMuHIzE(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩഃ")]
ylLUS9Wt8xE1uZ7Czcoba += [FnBiAjthS8MkXs67W(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬഄ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡖࡊࡆࡈࡓࡘ࠭അ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪആ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪഇ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡗࡓࡕࡏࡃࡔࠩഈ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡐࡎ࡜ࡅࡔࠩഉ")]
wAPUj1vGyWBcFlKDa8ikm2 = [yA5z6LIXBlo41PRVMY87wOisFp(u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩഊ"),FvNyZqaLKw(u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨഋ"),g4g6bfkPtVGU5lIM3(u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩഌ"),dshJSmRqeiP9nap2(u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫ഍"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧഎ")]
wAPUj1vGyWBcFlKDa8ikm2 += [pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭ഏ"),kEhAHvti6Vnsfx(u"࡚ࠬࡖࡇࡗࡑࠫഐ"),yA5z6LIXBlo41PRVMY87wOisFp(u"࠭ࡗࡆࡅࡌࡑࡆ࠭഑"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩഒ")]
isHEfxUCa24bR9kGtF7 = [FnBiAjthS8MkXs67W(u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑࠪഓ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫഔ"),iUeoLOsbHqP(u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭ക"),zqdvcbP5L8BHh(u"ࠫࡋࡕࡓࡕࡃࠪഖ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬࡇࡈࡘࡃࡎࠫഗ"),UTelCo0ihE1d5R(u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧഘ")]
isHEfxUCa24bR9kGtF7 += [iUeoLOsbHqP(u"ࠧࡔࡊࡒࡊࡍࡇࠧങ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠨࡄࡕࡗ࡙ࡋࡊࠨച"),kEhAHvti6Vnsfx(u"ࠩ࡜ࡅࡖࡕࡔࠨഛ"),iUeoLOsbHqP(u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫജ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬഝ"),LiRcTVUWuth70DmPy(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧഞ"),xW2Arao7YVOemw(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨട")]
Pme0MW6zX7FCHYcOngkE3SxjJ  = [oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧࡂࡍ࡚ࡅࡒ࠭ഠ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪഡ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࡅࡓࡐࡘࡁࠨഢ"),fprnld4CZo(u"ࠪࡅࡐࡕࡁࡎࠩണ"),XzrqbGDIy54juixkMA(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭ത"),wRxoKs10Syj7V4edYhtP(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧഥ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧദ")]
Pme0MW6zX7FCHYcOngkE3SxjJ += [YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩധ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫന"),iUeoLOsbHqP(u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪഩ"),E6MIKdpBomef(u"࡛ࠪࡊࡉࡉࡎࡃࠪപ"),kEhAHvti6Vnsfx(u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨഫ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠬࡌࡏࡔࡖࡄࠫബ"),iRoLg2m47tnDATBHGCSPNyx(u"࠭ࡁࡉ࡙ࡄࡏࠬഭ")]
Pme0MW6zX7FCHYcOngkE3SxjJ += [wRxoKs10Syj7V4edYhtP(u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪമ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫയ"),iUeoLOsbHqP(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫര"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬറ"),XzrqbGDIy54juixkMA(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭ല"),zqdvcbP5L8BHh(u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧള")]
Pme0MW6zX7FCHYcOngkE3SxjJ += [FvNyZqaLKw(u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧഴ"),FnBiAjthS8MkXs67W(u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩവ"),XzrqbGDIy54juixkMA(u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪശ"),g4g6bfkPtVGU5lIM3(u"ࠩࡗ࡚ࡋ࡛ࡎࠨഷ"),xW2Arao7YVOemw(u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬസ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫࡘࡎࡏࡇࡊࡄࠫഹ")]
Pme0MW6zX7FCHYcOngkE3SxjJ += [p72fnFtcPix5UKwr9YNzW(u"ࠬࡈࡒࡔࡖࡈࡎࠬഺ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"࡙࠭ࡂࡓࡒࡘ഻ࠬ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨ഼"),wRxoKs10Syj7V4edYhtP(u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩഽ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧാ"),xW2Arao7YVOemw(u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬി"),SO94xq1RAkMm2uF(u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭ീ")]
BeEfxQANkM2  = [xW2Arao7YVOemw(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࠪു"),UTelCo0ihE1d5R(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧൂ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧൃ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡔࡐࡒࡌࡇࡘ࠭ൄ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡍࡋ࡙ࡉࡘ࠭൅")]
BeEfxQANkM2 += [FnBiAjthS8MkXs67W(u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩെ"),xW2Arao7YVOemw(u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫേ")]
BeEfxQANkM2 += [wRxoKs10Syj7V4edYhtP(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭ൈ"),LiRcTVUWuth70DmPy(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ൉"),iRoLg2m47tnDATBHGCSPNyx(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪൊ")]
BeEfxQANkM2 += [iRoLg2m47tnDATBHGCSPNyx(u"ࠨࡋࡓࡘ࡛࠳ࡌࡊࡘࡈࠫോ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩࡌࡔ࡙࡜࠭ࡎࡑ࡙ࡍࡊ࡙ࠧൌ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪࡍࡕ࡚ࡖ࠮ࡕࡈࡖࡎࡋࡓࠨ്")]
BeEfxQANkM2 += [l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭ൎ"),E6MIKdpBomef(u"ࠬࡓ࠳ࡖ࠯ࡐࡓ࡛ࡏࡅࡔࠩ൏"),Me28A1sBLNIgUp5YCDyvT(u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪ൐")]
Zq6Yokv0F32ClbuQ9w8Xs1pf = [sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࡎ࠵ࡘࠫ൑"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨࡋࡓࡘ࡛࠭൒"),xW2Arao7YVOemw(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ൓"),iRoLg2m47tnDATBHGCSPNyx(u"ࠪࡍࡋࡏࡌࡎࠩൔ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬൕ")]
tKZCufmDlvG0jRQxE2JYyF = Pme0MW6zX7FCHYcOngkE3SxjJ+BeEfxQANkM2
jjJZia6HOo2xFudTmtsyDVM5 = Pme0MW6zX7FCHYcOngkE3SxjJ+Zq6Yokv0F32ClbuQ9w8Xs1pf
X9JDEugQKfOZt5Ylc2m4b = Pme0MW6zX7FCHYcOngkE3SxjJ+BeEfxQANkM2
TpKmsy5SzeW = vvnUPVYd1mZHa9li+wAPUj1vGyWBcFlKDa8ikm2+isHEfxUCa24bR9kGtF7+ylLUS9Wt8xE1uZ7Czcoba
QQaW5UTufZ8X06EqILi = [
						wRxoKs10Syj7V4edYhtP(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧൖ")
						,Me28A1sBLNIgUp5YCDyvT(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠷ࡴࡤࠨൗ")
						,hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑ࡚ࡒࡔࡊࡡ࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠶ࡹࡴࠨ൘")
						]
cqyx3WnkJKH2TIA = [
						g4g6bfkPtVGU5lIM3(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡉࡓࡊ࡟ࡂࡐࡄࡐ࡞࡚ࡉࡄࡕࡢࡉ࡛ࡋࡎࡕ࠯࠴ࡷࡹ࠭൙")
						,XzrqbGDIy54juixkMA(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡉ࡝࡚ࡒࡂࡅࡗࡣࡒ࠹ࡕ࠹࠯࠴ࡷࡹ࠭൚")
						,wRxoKs10Syj7V4edYhtP(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡇࡎࡅࡑࡐࡣ࡚࡙ࡅࡓࡃࡊࡉࡓ࡚࠭࠲ࡵࡷࠫ൛")
						,xW2Arao7YVOemw(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡕࡡࡓࡖࡔ࡞ࡉࡆࡕࡢࡐࡎ࡙ࡔ࠮࠳ࡶࡸࠬ൜")
						,wRxoKs10Syj7V4edYhtP(u"ࠬࡏࡐࡕࡘ࠰ࡇࡍࡋࡃࡌࡡࡄࡇࡈࡕࡕࡏࡖ࠰࠵ࡸࡺࠧ൝")
						,zqdvcbP5L8BHh(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡒࡐࡔࡉࡁࡕࡋࡒࡒ࠲࠷ࡳࡵࠩ൞")
						,wRxoKs10Syj7V4edYhtP(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠲ࡵࡷࠫൟ")
						,E6MIKdpBomef(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠵ࡵࡨࠬൠ")
						,UTelCo0ihE1d5R(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊࡇࡄࡠࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍ࠯࠴ࡷࡹ࠭ൡ")
						,Me28A1sBLNIgUp5YCDyvT(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡇࡐࡑࡊࡐࡊ࡛ࡓࡆࡔࡆࡓࡓ࡚ࡅࡏࡖ࠰࠵ࡸࡺࠧൢ")
						,Cu1704YofAbr3QTm(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠴ࡴࡧࠫൣ")
						,S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠷ࡷ࡬ࠬ൤")
						,iUeoLOsbHqP(u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ൥")
						,G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠷ࡳࡵࠩ൦")
						,oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝࡙ࡈࡂࡔࡌࡒࡌ࠳࠲࡯ࡦࠪ൧")
						]
zzagHLkrSt2 = cqyx3WnkJKH2TIA+[
				 oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡔࡗࡕࡘ࡚ࡡࡗࡉࡘ࡚࠭࠲ࡵࡷࠫ൨")
				,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡎࡔࡕࡒࡖࡔࡗࡕࡘࡊࡇࡖ࠱࠶ࡹࡴࠨ൩")
				,G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞ࡉࡆࡕ࠰࠵ࡸࡺࠧ൪")
				,S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘࡊࡇࡖ࠱࠷ࡴࡤࠨ൫")
				,wRxoKs10Syj7V4edYhtP(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙࡛ࡗࡓ࠲࠷ࡳࡵࠩ൬")
				,iUeoLOsbHqP(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚࡜ࡘࡔ࠳࠲࡯ࡦࠪ൭")
				,S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡏࡕࡘࡏ࡙࡛ࡆࡓࡒ࠳࠱ࡴࡶࠪ൮")
				,wRxoKs10Syj7V4edYhtP(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡐࡖࡒࡐ࡚࡜ࡇࡔࡓ࠭࠳ࡰࡧࠫ൯")
				,E6MIKdpBomef(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠵ࡵࡨࠬ൰")
				,SO94xq1RAkMm2uF(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡉࡈࡆࡅࡎࡣࡍ࡚ࡔࡑࡕࡢࡔࡗࡕࡘࡊࡇࡖ࠱࠶ࡹࡴࠨ൱")
				,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡉࡖࡗࡔࡘࡥࡔࡆࡕࡗ࠱࠶ࡹࡴࠨ൲")
				,SO94xq1RAkMm2uF(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡖࡈࡗ࡙ࡥࡁࡍࡎࡢ࡛ࡊࡈࡓࡊࡖࡈࡗ࠲࠷ࡳࡵࠩ൳")
				,Cu1704YofAbr3QTm(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡗࡉࡘ࡚࡟ࡂࡎࡏࡣ࡜ࡋࡂࡔࡋࡗࡉࡘ࠳࠲࡯ࡦࠪ൴")
				,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰࡙ࡘࡇࡇࡆࡡࡕࡉࡕࡕࡒࡕ࠯࠴ࡷࡹ࠭൵")
				,FvNyZqaLKw(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠳࠱ࡴࡶࠪ൶")
				,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡖࡆࡔࡖࡓࡤ࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅ࠮࠳ࡶࡸࠬ൷")
				]
vNFPbXVJ7pmyWLen = [LiRcTVUWuth70DmPy(u"ࠫ࠽࠴࠸࠯࠺࠱࠼ࠬ൸"),wRxoKs10Syj7V4edYhtP(u"ࠬ࠷࠮࠲࠰࠴࠲࠶࠭൹"),iRoLg2m47tnDATBHGCSPNyx(u"࠭࠱࠯࠲࠱࠴࠳࠷ࠧൺ"),LiRcTVUWuth70DmPy(u"ࠧ࠹࠰࠻࠲࠹࠴࠴ࠨൻ"),fprnld4CZo(u"ࠨ࠴࠳࠼࠳࠼࠷࠯࠴࠵࠶࠳࠸࠲࠳ࠩർ"),zqdvcbP5L8BHh(u"ࠩ࠵࠴࠽࠴࠶࠸࠰࠵࠶࠵࠴࠲࠳࠲ࠪൽ")]
oSVpce1UQYrDqhuM6PT = {
			 l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࡅࡐࡕࡁࡎࠩൾ")		:[QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡫࠯ࡵࡹ࠳ࡴࡲࡤࠨൿ")]
			,lc0dpSmwoPDjLnk(u"ࠬࡇࡈࡘࡃࡎࠫ඀")		:[xW2Arao7YVOemw(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡵ࠱ࡥ࡭ࡽࡡ࡬ࡶࡹ࠲ࡳ࡫ࡴࠨඁ")]
			,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧࡂࡍ࡚ࡅࡒ࠭ං")		:[SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯࠳ࡹࡶࠨඃ")]
			,UTelCo0ihE1d5R(u"ࠩࡄࡐࡆࡘࡁࡃࠩ඄")		:[yA5z6LIXBlo41PRVMY87wOisFp(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻࡵࡤ࠯ࡣ࡯ࡥࡷࡧࡢ࠯ࡥࡲࡱࠬඅ")]
			,wRxoKs10Syj7V4edYhtP(u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠭ආ")		:[yA5z6LIXBlo41PRVMY87wOisFp(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡧ࡬ࡧࡣࡷ࡭ࡲ࡯࠮ࡵࡸࠪඇ")]
			,SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨඈ")		:[LiRcTVUWuth70DmPy(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣ࡯ࡱࡦࡧࡲࡦࡨ࠱ࡧ࡭࠭ඉ")]
			,l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭ඊ")	:[hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡡࡳࡣࡥ࡭ࡨ࠳ࡴࡰࡱࡱࡷ࠳ࡩ࡯࡮ࠩඋ")]
			,G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬඌ")		:[FvNyZqaLKw(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡢࡤࡶࡩࡪࡪ࠮࡯ࡧࡷࠫඍ")]
			,SO94xq1RAkMm2uF(u"ࠬࡈࡏࡌࡔࡄࠫඎ")		:[xW2Arao7YVOemw(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡩࡱࡲࡪࡻࡵࡤ࠯ࡥࡲࡱࠬඏ")]
			,SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠧࡃࡔࡖࡘࡊࡐࠧඐ")		:[Cu1704YofAbr3QTm(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡥࡶࡸࡺࡥ࡫࠰ࡦࡳࡲ࠭එ")]
			,xW2Arao7YVOemw(u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪඒ")		:[iRoLg2m47tnDATBHGCSPNyx(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢ࠶࠳࠴࠳ࡩ࡯࡮ࠩඓ")]
			,LiRcTVUWuth70DmPy(u"ࠫࡈࡏࡍࡂ࠶ࡘࠫඔ")		:[iUeoLOsbHqP(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࠱ࡤ࡫ࡰࡥ࠹ࡻ࠮ࡤࡱࡰࠫඕ")]
			,bUdr5Hahw6sY8xJ(u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨඖ")		:[dshJSmRqeiP9nap2(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠹ࡢࡥࡱ࠱ࡧࡴࡳࠧ඗")]
			,E6MIKdpBomef(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪ඘")		:[FnBiAjthS8MkXs67W(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡࡤ࡮ࡸࡦ࠳ࡽࡡࡵࡥ࡫ࠫ඙")]
			,Me28A1sBLNIgUp5YCDyvT(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࡜ࡕࡒࡌࠩක")	:[lc0dpSmwoPDjLnk(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡺࡶࡷ࠰ࡦ࡭ࡲࡧࡣ࡭ࡷࡥ࠲ࡸ࡮࡯ࡱࠩඛ")]
			,E6MIKdpBomef(u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧග")		:[iUeoLOsbHqP(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡨ࡯࡭ࡢࡨࡤࡲࡸ࠴ࡣࡰ࡯ࠪඝ")]
			,fprnld4CZo(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪඞ")	:[Me28A1sBLNIgUp5YCDyvT(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺ࠶࠼࠴࡭ࡺ࠯ࡦ࡭ࡲࡧ࠮࡯ࡧࡷ࠳ࡲࡿࡣ࠲ࠩඟ")]
			,LiRcTVUWuth70DmPy(u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪච")		:[hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢࡰࡲࡻ࠳ࡩࡣࠨඡ")]
			,S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩජ")	:[Cu1704YofAbr3QTm(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠯ࡥࡲࡱࠬඣ"),yA5z6LIXBlo41PRVMY87wOisFp(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨࡴࡤࡴ࡭ࡷ࡬࠯ࡣࡳ࡭࠳ࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠱ࡧࡴࡳࠧඤ")]
			,hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨඥ")		:[iUeoLOsbHqP(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡧ࠳ࡪࡲࡢ࡯ࡤࡷ࠼࠴ࡣࡰ࡯ࠪඦ")]
			,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫට")		:[FnBiAjthS8MkXs67W(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡣࡧࡶࡸ࠳࡬ࡵ࡯ࠩඨ")]
			,hBvsQ7oCkKUdwjx58ml3EN(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭ඩ")		:[xW2Arao7YVOemw(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻࡥࡩࡸࡺ࠮ࡸࡧࡥࡧࡦࡳࠧඪ")]
			,hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠳ࠨණ")		:[zqdvcbP5L8BHh(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡫ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡦ࡮ࡪࠧඬ")]
			,Cu1704YofAbr3QTm(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶ࠪත")		:[yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿ࠭ࡣࡧࡶࡸ࠳ࡴࡥࡵࠩථ")]
			,sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫද")		:[oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡦࡨࡥࡩ࠴࡬ࡪࡸࡨࠫධ")]
			,E6MIKdpBomef(u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇࠧන")		:[hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡮ࡦ࡭ࡳ࡫࡭ࡢ࠰ࡦࡳࡲ࠭඲")]
			,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࡇࡃࡅࡖࡆࡑࡁࠨඳ")		:[iUeoLOsbHqP(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥࡧࡸ࡫ࡢ࠰ࡦࡳࡲ࠭ප")]
			,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬඵ")	:[G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧࡪࡦࡴ࠱ࡷ࡭ࡵࡷࠨබ")]
			,bUdr5Hahw6sY8xJ(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭භ")		:[oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡪࡦࡹࡥ࡭ࡪࡧࡷ࠳ࡽ࡯ࡳ࡮ࡧࠫම")]
			,yA5z6LIXBlo41PRVMY87wOisFp(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨඹ")		:[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡶࡰࡦ࠴ࡦࡢࡵࡨࡰ࡭ࡪ࠮ࡤ࡮ࡲࡹࡩ࠭ය")]
			,LiRcTVUWuth70DmPy(u"ࠨࡈࡒࡗ࡙ࡇࠧර")		:[UTelCo0ihE1d5R(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡰ࠮ࡧࡱࡶࡸࡦ࠳ࡴࡷ࠰ࡱࡩࡹ࠭඼")]
			,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬල")		:[QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡮ࡡ࡭ࡣࡦ࡭ࡲࡧ࠮࡮ࡧࡧ࡭ࡦ࠭඾")]
			,l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬࡏࡆࡊࡎࡐࠫ඿")		:[Me28A1sBLNIgUp5YCDyvT(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴ࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧව"),iRoLg2m47tnDATBHGCSPNyx(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡱ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨශ"),LiRcTVUWuth70DmPy(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥ࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩෂ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦ࠸࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫස"),XzrqbGDIy54juixkMA(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠽࠸࠴࠱࠺࠲࠱࠶࠹࠴࠱࠳࠴ࠪහ")]
			,lc0dpSmwoPDjLnk(u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧළ")	:[iRoLg2m47tnDATBHGCSPNyx(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡢࡴࡥࡥࡱࡧ࠭ࡵࡸ࠱࡭ࡶ࠭ෆ")]
			,hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ࡋࡂࡖࡎࡓ࡙࡚ࡖࠨ෇")		:[SO94xq1RAkMm2uF(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩࡲࡳ࠳ࡱࡩࡵ࡭ࡲࡸ࠳ࡺࡶࠨ෈")]
			,wRxoKs10Syj7V4edYhtP(u"ࠨࡍࡒࡈࡎࡋࡍࡂࡆࡢࡅࡕࡖࠧ෉")	:[LiRcTVUWuth70DmPy(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡰࡵࡤࡪࡧࡰࡥࡩ්࠭"),xW2Arao7YVOemw(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠴࠳࠵࠽࠴ࡦࡸࡵ࠱ࡷࡹࡵࡲࡦࠩ෋")]
			,bUdr5Hahw6sY8xJ(u"ࠫࡑࡕࡄ࡚ࡐࡈࡘࠬ෌")		:[QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡬ࡰࡦࡼࡲࡪࡺ࠮࡭࡫ࡱ࡯ࠬ෍")]
			,Me28A1sBLNIgUp5YCDyvT(u"࠭ࡐࡂࡐࡈࡘࠬ෎")		:[sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡵࡧ࡮ࡦࡶ࠱ࡧࡴ࠴ࡩ࡭ࠩා")]
			,l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪැ")		:[bUdr5Hahw6sY8xJ(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭࡯ࡤ࠵ࡷ࠱ࡧࡦࡳࠧෑ")]
			,lc0dpSmwoPDjLnk(u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧි")	:[pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࠮ࡴࡪ࠷ࡹ࠳ࡴࡥࡸࡵࠪී")]
			,S4SOKF2QbBhjCd3RrVMuHIzE(u"࡙ࠬࡈࡐࡈࡋࡅࠬු")		:[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷ࡫ࡧ࠲ࡸ࡮࡯ࡧࡪࡤ࠲ࡹࡼࠧ෕")]
			,bUdr5Hahw6sY8xJ(u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩූ")		:[hBvsQ7oCkKUdwjx58ml3EN(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡴࡵࡦ࡮ࡣࡻ࠲ࡨࡵ࡭ࠨ෗"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷࡹࡧࡴࡪࡥ࠱ࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼ࠳ࡩ࡯࡮ࠩෘ"),fprnld4CZo(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡡࡻࡷࡵࡩࡪࡪࡧࡦ࠰ࡱࡩࡹ࠭ෙ")]
			,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࡙ࠫ࡜ࡆࡖࡐࠪේ")		:[FvNyZqaLKw(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳ࠯ࡶࡹࡪࡺࡴ࠮࡮ࡧࠪෛ")]
			,hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ࡗࡆࡅࡌࡑࡆ࠭ො")		:[pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡺࡱ࠱࠲࠳࠭࠮࠯ࡱࡾࡪࡨࡣࡢ࠷ࡪࡨ࠼ࡵࡤࡦ࠲ࡥ࡭࡬ࡲࡨ࠯࡯ࡼࡧ࡮࡯࡭ࡢ࠯ࡺࡩࡨ࡯ࡩ࡮ࡣ࠱ࡷ࡭ࡵࡰࠨෝ")]
			,bUdr5Hahw6sY8xJ(u"ࠨ࡛ࡄࡕࡔ࡚ࠧෞ")		:[SO94xq1RAkMm2uF(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡽ࠳ࡿࡡࡲࡱࡷ࠲ࡹࡼࠧෟ")]
			,kEhAHvti6Vnsfx(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ෠")		:[S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳࠧ෡")]
			,hBvsQ7oCkKUdwjx58ml3EN(u"ࠬࡘࡅࡑࡑࡖࠫ෢")		:[kEhAHvti6Vnsfx(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶ࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭෣"),iUeoLOsbHqP(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑ࠲ࡅࡉࡊࡏࡏࡕ࠴࠼࠴ࡧࡤࡥࡱࡱࡷ࠶࠾࠮ࡹ࡯࡯ࠫ෤"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱ࠱ࡎࡓࡉࡏࡒࡆࡒࡒ࠳ࡆࡊࡄࡐࡐࡖ࠵࠾࠵ࡡࡥࡦࡲࡲࡸ࠷࠹࠯ࡺࡰࡰࠬ෥")]
			,hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩࡕࡉࡕࡕࡓࡠࡄࡎࡔࠬ෦")	:[kEhAHvti6Vnsfx(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨ෧"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠶࠾࠯ࡢࡦࡧࡳࡳࡹ࠱࠹࠰ࡻࡱࡱ࠭෨"),FnBiAjthS8MkXs67W(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮ࡶ࡭࠱ࡸࡴ࠵ࡁࡅࡆࡒࡒࡘ࠷࠹࠰ࡣࡧࡨࡴࡴࡳ࠲࠻࠱ࡼࡲࡲࠧ෩")]
			,SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࡓࡐࡗࡕࡇࡊ࡙ࠧ෪")		:[Cu1704YofAbr3QTm(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱࡮ࡳࡩ࡯ࠧ෫"),dshJSmRqeiP9nap2(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡸࡻࡲࡨࡧ࠱ࡷ࡭࠭෬"),g4g6bfkPtVGU5lIM3(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡴࡥࡵ࡮࡬ࡪࡾ࠴ࡡࡱࡲ࠲ࡏࡔࡊࡉࡓࡇࡓࡓࠬ෭")]
			}
if fprnld4CZo(u"࠱ᔣ"):
	oSVpce1UQYrDqhuM6PT[SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ෮")] = [bUdr5Hahw6sY8xJ(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭෯"),dshJSmRqeiP9nap2(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ෰"),lc0dpSmwoPDjLnk(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ෱"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬෲ"),iRoLg2m47tnDATBHGCSPNyx(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬෳ"),UTelCo0ihE1d5R(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ෴"),xW2Arao7YVOemw(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫ෵"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬ෶"),FvNyZqaLKw(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭෷"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶࡨࡼࡹࡸࡡࡱࡻࡷ࡬ࡴࡴࡣࡰࡦࡨࠫ෸")]
	oSVpce1UQYrDqhuM6PT[UTelCo0ihE1d5R(u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓࠫ෹")] = [pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ෺"),bUdr5Hahw6sY8xJ(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ෻"),bUdr5Hahw6sY8xJ(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ෼"),XzrqbGDIy54juixkMA(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ෽"),kEhAHvti6Vnsfx(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ෾"),lc0dpSmwoPDjLnk(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭෿"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ฀"),fprnld4CZo(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡦࡥࡵࡺࡣࡩࡣࠪก"),zqdvcbP5L8BHh(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡸࡪࡹࡴࡪࡰࡪࠫข"),bUdr5Hahw6sY8xJ(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴࡦࡺࡷࡶࡦࡶࡹࡵࡪࡲࡲࡨࡵࡤࡦࠩฃ")]
else:
	oSVpce1UQYrDqhuM6PT[xW2Arao7YVOemw(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫค")] = [iUeoLOsbHqP(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨฅ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬฆ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫง"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧจ"),E6MIKdpBomef(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧฉ"),wRxoKs10Syj7V4edYhtP(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪช"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭ซ"),E6MIKdpBomef(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧฌ"),lc0dpSmwoPDjLnk(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨญ"),Cu1704YofAbr3QTm(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡪࡾࡴࡳࡣࡳࡽࡹ࡮࡯࡯ࡥࡲࡨࡪ࠭ฎ")]
	oSVpce1UQYrDqhuM6PT[iUeoLOsbHqP(u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔࠬฏ")] = [oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬฐ"),fprnld4CZo(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩฑ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨฒ"),kEhAHvti6Vnsfx(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫณ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫด"),bUdr5Hahw6sY8xJ(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧต"),wRxoKs10Syj7V4edYhtP(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪถ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡧࡦࡶࡴࡤࡪࡤࠫท"),XzrqbGDIy54juixkMA(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬธ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡧࡻࡸࡷࡧࡰࡺࡶ࡫ࡳࡳࡩ࡯ࡥࡧࠪน")]
ZVrQewF1XiazvmI7oYnbMW = [fprnld4CZo(u"ࠬࡒࡉࡔࡖࡓࡐࡆ࡟ࠧบ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭ࡒࡆࡒࡒࡖ࡙࡙ࠧป"),fprnld4CZo(u"ࠧࡆࡏࡄࡍࡑ࡙ࠧผ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪฝ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩࡌࡗࡑࡇࡍࡊࡅࡖࠫพ"),bUdr5Hahw6sY8xJ(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭ฟ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠫࡐࡔࡏࡘࡐࡈࡖࡗࡕࡒࡔࠩภ"),zqdvcbP5L8BHh(u"ࠬࡉࡁࡑࡖࡆࡌࡆ࠭ม"),FvNyZqaLKw(u"࠭ࡔࡆࡕࡗࡍࡓࡍࠧย"),iRoLg2m47tnDATBHGCSPNyx(u"ࠧࡔࡋࡗࡉࡘ࡛ࡒࡍࡕࠪร")]
lZU9W7XhDxpeSA56vgQdi0 = [SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࡃࡇࡈࡔࡔࡓࠨฤ"),iRoLg2m47tnDATBHGCSPNyx(u"ࠩࡄࡈࡉࡕࡎࡔ࠳࠻ࠫล"),SO94xq1RAkMm2uF(u"ࠪࡅࡉࡊࡏࡏࡕ࠴࠽ࠬฦ")]
class hWUNalJAsv(PquO3SKtwbDmYLlvN5Jk9a2):
	def __init__(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2,*aargs,**kkwargs):
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.choiceID = -yA5z6LIXBlo41PRVMY87wOisFp(u"࠲ᔤ")
	def onClick(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2,P2GYsLrZnyDhp7HmazdEol0eAiURk):
		if P2GYsLrZnyDhp7HmazdEol0eAiURk>=YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠻࠳࠵࠵ᔥ"): UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.choiceID = P2GYsLrZnyDhp7HmazdEol0eAiURk-YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠻࠳࠵࠵ᔥ")
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.dDCLRW7qB0Nm29()
	def EOB7W1zJAsQFXMdLg(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2,*aargs):
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.button0,UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.button1,UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.button2 = aargs[FnBiAjthS8MkXs67W(u"࠴ᔧ")],aargs[pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠴ᔦ")],aargs[yA5z6LIXBlo41PRVMY87wOisFp(u"࠷ᔨ")]
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.header,UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.text = aargs[xW2Arao7YVOemw(u"࠹ᔩ")],aargs[LiRcTVUWuth70DmPy(u"࠴ᔪ")]
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.profile,UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.direction = aargs[l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠶ᔫ")],aargs[iUeoLOsbHqP(u"࠸ᔬ")]
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.buttonstimeout,UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.closetimeout = aargs[FvNyZqaLKw(u"࠻ᔮ")],aargs[SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠻ᔭ")]
		if UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.buttonstimeout>p72fnFtcPix5UKwr9YNzW(u"࠵ᔯ") or UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.closetimeout>p72fnFtcPix5UKwr9YNzW(u"࠵ᔯ"): UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.enable_progressbar = LiRcTVUWuth70DmPy(u"ࡘࡷࡻࡥឈ")
		else: UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.enable_progressbar = Me28A1sBLNIgUp5YCDyvT(u"ࡋࡧ࡬ࡴࡧញ")
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.image_filename = rJOGPocvjmQy1fSNHthMzRCuZ8D.replace(XzrqbGDIy54juixkMA(u"ࠫࡤ࠶࠰࠱࠲ࡢࠫว"),xW2Arao7YVOemw(u"ࠬࡥࠧศ")+str(MQbODJoPV2w8TEAg4zXZdjLxSW.time())+iUeoLOsbHqP(u"࠭࡟ࠨษ"))
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.image_filename = UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.image_filename.replace(E6MIKdpBomef(u"ࠧ࡝࡞ࠪส"),g4g6bfkPtVGU5lIM3(u"ࠨ࡞࡟ࡠࡡ࠭ห")).replace(g4g6bfkPtVGU5lIM3(u"ࠩ࠲࠳ࠬฬ"),iRoLg2m47tnDATBHGCSPNyx(u"ࠪ࠳࠴࠵࠯ࠨอ"))
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.image_height = EFo7dN1XkCJSI6sPzZO8cTRm9Aj3U5(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.button0,UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.button1,UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.button2,UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.header,UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.text,UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.profile,UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.direction,UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.enable_progressbar,UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.image_filename)
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.show()
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.getControl(g4g6bfkPtVGU5lIM3(u"࠿࠰࠶࠲ᔰ")).setImage(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.image_filename)
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.getControl(xW2Arao7YVOemw(u"࠹࠱࠷࠳ᔱ")).setHeight(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.image_height)
		if not UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.button1 and UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.button0 and UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.button2: UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.getControl(UTelCo0ihE1d5R(u"࠻࠳࠵࠷ᔳ")).setPosition(-Me28A1sBLNIgUp5YCDyvT(u"࠵࠶࠵ᔴ"),E6MIKdpBomef(u"࠱ᔲ"))
		return UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.image_filename,UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.image_height
	def LuFKZhcI46PHD(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2):
		if UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.buttonstimeout:
			UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.th1 = dM9DZS0pkxbqaf7W.Thread(target=UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.FV24goEW0av,args=())
			UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.th1.start()
		else: UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.FQqZchx01mCfBUvgLIKJlS()
	def FV24goEW0av(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2):
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.getControl(hBvsQ7oCkKUdwjx58ml3EN(u"࠽࠵࠸࠰ᔵ")).setEnabled(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࡚ࡲࡶࡧដ"))
		for CQMipytPbq in range(SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠶ᔶ"),UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.buttonstimeout+SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠶ᔶ")):
			MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(xW2Arao7YVOemw(u"࠷ᔷ"))
			nnCFB9bjh6NLwoO = int(hBvsQ7oCkKUdwjx58ml3EN(u"࠱࠱࠲ᔸ")*CQMipytPbq/UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.buttonstimeout)
			UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.qqnGjzJ2MBvIwyf6(nnCFB9bjh6NLwoO)
			if UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.choiceID>hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠱ᔹ"): break
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.FQqZchx01mCfBUvgLIKJlS()
	def qDPbv5OjaR(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2):
		if UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.closetimeout:
			UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.th2 = dM9DZS0pkxbqaf7W.Thread(target=UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.o0e7fVz1PcULEjbprCvG9H4DBFKy,args=())
			UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.th2.start()
		else: UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.FQqZchx01mCfBUvgLIKJlS()
	def o0e7fVz1PcULEjbprCvG9H4DBFKy(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2):
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.getControl(Me28A1sBLNIgUp5YCDyvT(u"࠻࠳࠶࠵ᔺ")).setEnabled(iRoLg2m47tnDATBHGCSPNyx(u"ࡔࡳࡷࡨឋ"))
		MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.buttonstimeout)
		for CQMipytPbq in range(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.closetimeout-xW2Arao7YVOemw(u"࠴ᔻ"),-xW2Arao7YVOemw(u"࠴ᔻ"),-xW2Arao7YVOemw(u"࠴ᔻ")):
			MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(Me28A1sBLNIgUp5YCDyvT(u"࠵ᔼ"))
			nnCFB9bjh6NLwoO = int(iRoLg2m47tnDATBHGCSPNyx(u"࠶࠶࠰ᔽ")*CQMipytPbq/UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.closetimeout)
			UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.qqnGjzJ2MBvIwyf6(nnCFB9bjh6NLwoO)
			if UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.choiceID>l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠶ᔾ"): break
		if UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.closetimeout>hBvsQ7oCkKUdwjx58ml3EN(u"࠰ᔿ"): UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.choiceID = Me28A1sBLNIgUp5YCDyvT(u"࠲࠲ᕀ")
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.dDCLRW7qB0Nm29()
	def qqnGjzJ2MBvIwyf6(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2,nnCFB9bjh6NLwoO):
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.precent = nnCFB9bjh6NLwoO
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.getControl(Cu1704YofAbr3QTm(u"࠻࠳࠶࠵ᕁ")).setPercent(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.precent)
	def FQqZchx01mCfBUvgLIKJlS(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2):
		if UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.button0: UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.getControl(SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠼࠴࠶࠶ᕂ")).setEnabled(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࡕࡴࡸࡩឌ"))
		if UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.button1: UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.getControl(SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠽࠵࠷࠱ᕃ")).setEnabled(iRoLg2m47tnDATBHGCSPNyx(u"ࡖࡵࡹࡪឍ"))
		if UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.button2: UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.getControl(zqdvcbP5L8BHh(u"࠾࠶࠱࠳ᕄ")).setEnabled(wRxoKs10Syj7V4edYhtP(u"ࡗࡶࡺ࡫ណ"))
	def dDCLRW7qB0Nm29(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2):
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.close()
		try: WpgZTyqoMAPhwGiXF.remove(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.image_filename)
		except: pass
class eWia5rknYzHm0J():
	def __init__(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2,showDialogs=xW2Arao7YVOemw(u"ࡋࡧ࡬ࡴࡧថ"),logErrors=iUeoLOsbHqP(u"ࡘࡷࡻࡥត")):
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.showDialogs = showDialogs
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.logErrors = logErrors
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.finishedLIST,UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.failedLIST = [],[]
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.statusDICT,UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.resultsDICT = {},{}
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.processesLIST = []
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.starttimeDICT,UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.finishtimeDICT,UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.elpasedtimeDICT = {},{},{}
	def ZgHxVpFyBDAibfOlo4(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2,ESIi4D0MAgOCWT3Rwobfq5Yh,G9mhYrgWZ1ckjR7ezNJXOL,*aargs):
		ESIi4D0MAgOCWT3Rwobfq5Yh = str(ESIi4D0MAgOCWT3Rwobfq5Yh)
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.statusDICT[ESIi4D0MAgOCWT3Rwobfq5Yh] = UTelCo0ihE1d5R(u"ࠫࡷࡻ࡮࡯࡫ࡱ࡫ࠬฮ")
		if UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.showDialogs: From8aTqdhCbPs(zqdvcbP5L8BHh(u"ࠬ࠭ฯ"),ESIi4D0MAgOCWT3Rwobfq5Yh)
		t2EpW9jLKaIm4i = dM9DZS0pkxbqaf7W.Thread(target=UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.XtNaPBFnT6jdQGhSwcmi,args=(ESIi4D0MAgOCWT3Rwobfq5Yh,G9mhYrgWZ1ckjR7ezNJXOL,aargs))
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.processesLIST.append(t2EpW9jLKaIm4i)
		return t2EpW9jLKaIm4i
	def IISJUtB5zhnRuCp39(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2,ESIi4D0MAgOCWT3Rwobfq5Yh,G9mhYrgWZ1ckjR7ezNJXOL,*aargs):
		t2EpW9jLKaIm4i = UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.ZgHxVpFyBDAibfOlo4(ESIi4D0MAgOCWT3Rwobfq5Yh,G9mhYrgWZ1ckjR7ezNJXOL,*aargs)
		t2EpW9jLKaIm4i.start()
	def XtNaPBFnT6jdQGhSwcmi(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2,ESIi4D0MAgOCWT3Rwobfq5Yh,G9mhYrgWZ1ckjR7ezNJXOL,aargs):
		ESIi4D0MAgOCWT3Rwobfq5Yh = str(ESIi4D0MAgOCWT3Rwobfq5Yh)
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.starttimeDICT[ESIi4D0MAgOCWT3Rwobfq5Yh] = MQbODJoPV2w8TEAg4zXZdjLxSW.time()
		try:
			UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.resultsDICT[ESIi4D0MAgOCWT3Rwobfq5Yh] = G9mhYrgWZ1ckjR7ezNJXOL(*aargs)
			if sTcr7iDp5eFt4RoLMhuwq1A(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒࠧะ") in str(G9mhYrgWZ1ckjR7ezNJXOL) and not UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.resultsDICT[ESIi4D0MAgOCWT3Rwobfq5Yh].succeeded:
				zrIWmJZh2CpVf8(Cu1704YofAbr3QTm(u"ࠧࡇࡱࡵࡧࡪࡪࠠࡦࡺ࡬ࡸࠥࡪࡵࡦࠢࡷࡳࠥࡺࡨࡳࡧࡤࡨࡪࡪࠠࡐࡒࡈࡒ࡚ࡘࡌࠡࡨࡤ࡭ࡱ࠭ั"))
			UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.finishedLIST.append(ESIi4D0MAgOCWT3Rwobfq5Yh)
			UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.statusDICT[ESIi4D0MAgOCWT3Rwobfq5Yh] = FnBiAjthS8MkXs67W(u"ࠨࡨ࡬ࡲ࡮ࡹࡨࡦࡦࠪา")
		except Exception as D2VbK9hH17PSolWyBT8Uu:
			if UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.logErrors:
				CCeZSJvsigLcq = FTYWns4Q7dSEXmBOAGlJ.format_exc()
				if CCeZSJvsigLcq!=iUeoLOsbHqP(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬำ"): GGtWyVoJReUuEBCdAagiL1YXO8.stderr.write(CCeZSJvsigLcq)
			UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.failedLIST.append(ESIi4D0MAgOCWT3Rwobfq5Yh)
			UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.statusDICT[ESIi4D0MAgOCWT3Rwobfq5Yh] = dshJSmRqeiP9nap2(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪิ")
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.finishtimeDICT[ESIi4D0MAgOCWT3Rwobfq5Yh] = MQbODJoPV2w8TEAg4zXZdjLxSW.time()
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.elpasedtimeDICT[ESIi4D0MAgOCWT3Rwobfq5Yh] = UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.finishtimeDICT[ESIi4D0MAgOCWT3Rwobfq5Yh] - UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.starttimeDICT[ESIi4D0MAgOCWT3Rwobfq5Yh]
	def qzUOT2k8StRbuF(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2):
		for QeCqwB5WU3TZ402yuDt in UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.processesLIST:
			QeCqwB5WU3TZ402yuDt.start()
	def EyUZYbCF4vXNfO6HzTx(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2):
		while QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫࡷࡻ࡮࡯࡫ࡱ࡫ࠬี") in list(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.statusDICT.values()): MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠷ᕅ"))
def dXg3T8BS127LJNaWHh9ecpAuR():
	if not fCQhRT4Nr3gvxstOoADJaY: return g4g6bfkPtVGU5lIM3(u"ࠬࡔࡏࡠࡗࡓࡈࡆ࡚ࡅࠨึ")
	try: WpgZTyqoMAPhwGiXF.makedirs(JXUQZHLxEgTFbrRC7n9)
	except: pass
	Tps23SOx8Zty = iRoLg2m47tnDATBHGCSPNyx(u"࠭ࡆࡖࡎࡏࡣ࡚ࡖࡄࡂࡖࡈࠫื")
	yUT0oIaGNLg7ilpZjQ6vK3 = [hBvsQ7oCkKUdwjx58ml3EN(u"ࠧ࠹࠰࠸࠲࠵ุ࠭"),g4g6bfkPtVGU5lIM3(u"ࠨ࠴࠳࠶࠶࠴࠱࠱࠰࠴࠽ูࠬ"),g4g6bfkPtVGU5lIM3(u"ࠩ࠵࠴࠷࠷࠮࠲࠳࠱࠶࠹ࡧฺࠧ"),kEhAHvti6Vnsfx(u"ࠪ࠶࠵࠸࠱࠯࠳࠵࠲࠸࠶ࠧ฻"),FvNyZqaLKw(u"ࠫ࠷࠶࠲࠳࠰࠳࠶࠳࠶࠲ࠨ฼"),wRxoKs10Syj7V4edYhtP(u"ࠬ࠸࠰࠳࠴࠱࠵࠵࠴࠲࠳ࠩ฽"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭࠲࠱࠴࠶࠲࠵࠹࠮࠱࠸ࠪ฾"),SO94xq1RAkMm2uF(u"ࠧ࠳࠲࠵࠷࠳࠶࠵࠯࠳࠹ࠫ฿"),Cu1704YofAbr3QTm(u"ࠨ࠴࠳࠶࠸࠴࠰࠷࠰࠳࠺ࠬเ"),fprnld4CZo(u"ࠩ࠵࠴࠷࠹࠮࠲࠲࠱࠶࠽࠭แ"),UTelCo0ihE1d5R(u"ࠪ࠶࠵࠸࠴࠯࠲࠴࠲࠶࠺ࠧโ")]
	gOa5qdXcP7ZvsnVSb3ky2 = yUT0oIaGNLg7ilpZjQ6vK3[-UTelCo0ihE1d5R(u"࠱ᕆ")]
	CPQa2847Aymq = nFIDUxebY52cj(gOa5qdXcP7ZvsnVSb3ky2)
	GYNuXDdHIQ9J = nFIDUxebY52cj(mmn0lB2tFI7XTgVfESo)
	if GYNuXDdHIQ9J>CPQa2847Aymq:
		Tps23SOx8Zty = iUeoLOsbHqP(u"ࠫࡘࡏࡍࡑࡎࡈࡣ࡚ࡖࡄࡂࡖࡈࠫใ")
	return Tps23SOx8Zty
def tjgGCd6n4120mwh8():
	if S4SOKF2QbBhjCd3RrVMuHIzE(u"࠲ᕇ"):
		PvTIqGjod45LYDaMcSVAbmnEx = LiRcTVUWuth70DmPy(u"࠲ᕈ")
		for PPpdbwumk4FXsHMZVh3o,Pquk4npoem9K0t5SFsNYR,OwhENJc75KjTmMH8qtzo1Sfv0X9kU6 in WpgZTyqoMAPhwGiXF.walk(YYyD6xzmsKbBTkrqEC,topdown=QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࡌࡡ࡭ࡵࡨទ")):
			PvTIqGjod45LYDaMcSVAbmnEx += len(OwhENJc75KjTmMH8qtzo1Sfv0X9kU6)
	if PvTIqGjod45LYDaMcSVAbmnEx>pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠸࠴࠵࠶ᕉ"): OOy4gzCqrV382ctPa(YYyD6xzmsKbBTkrqEC,S4SOKF2QbBhjCd3RrVMuHIzE(u"ࡕࡴࡸࡩន"),UTelCo0ihE1d5R(u"ࡆࡢ࡮ࡶࡩធ"))
	return
gl1TwIjQhCzLxnN2urAHKbSea = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࡈࡤࡰࡸ࡫ប")
def jKExzMkQmLFq(gGudVm2TlMnyh):
	global oSVpce1UQYrDqhuM6PT,gl1TwIjQhCzLxnN2urAHKbSea
	if not gGudVm2TlMnyh:
		xbrHkLcs09C6VXoqp15 = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,zqdvcbP5L8BHh(u"ࠬࡪࡩࡤࡶࠪไ"),XzrqbGDIy54juixkMA(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩๅ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧࡔࡋࡗࡉࡘ࡛ࡒࡍࡕࠪๆ"))
		if xbrHkLcs09C6VXoqp15:
			oSVpce1UQYrDqhuM6PT = xbrHkLcs09C6VXoqp15.copy()
			return
	if not gl1TwIjQhCzLxnN2urAHKbSea:
		mHejXxkvM1qCESPVRy54QB = oSVpce1UQYrDqhuM6PT[Me28A1sBLNIgUp5YCDyvT(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ็")][S4SOKF2QbBhjCd3RrVMuHIzE(u"࠽ᕊ")]
		exOIZnGECcR2p3WV4TPY06BNDo7 = PW2xo0Kq3Tcprj9Ck(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠸࠸ᕋ"),lc0dpSmwoPDjLnk(u"ࡗࡶࡺ࡫ផ"))
		ojS2y3cRDf = {oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠩࡸࡷࡪࡸ่ࠧ"):exOIZnGECcR2p3WV4TPY06BNDo7,l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࡺࡪࡸࡳࡪࡱࡱ้ࠫ"):mmn0lB2tFI7XTgVfESo}
		YutQm2AwozR9VKp4O1lWj8FaryI = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,bUdr5Hahw6sY8xJ(u"ࠫࡕࡕࡓࡕ๊ࠩ"),mHejXxkvM1qCESPVRy54QB,ojS2y3cRDf,UTelCo0ihE1d5R(u"๋ࠬ࠭"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭ࠧ์"),fprnld4CZo(u"ࠧࠨํ"),zqdvcbP5L8BHh(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡈ࡜࡙ࡘࡁࡠࡒ࡜ࡘࡍࡕࡎࡠࡅࡒࡈࡊ࠳࠱ࡴࡶࠪ๎"))
		if YutQm2AwozR9VKp4O1lWj8FaryI.succeeded:
			global NEW_SITESURLS
			exec(YutQm2AwozR9VKp4O1lWj8FaryI.content,globals(),locals())
			oSVpce1UQYrDqhuM6PT.update(NEW_SITESURLS)
			Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,wRxoKs10Syj7V4edYhtP(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ๏"),bUdr5Hahw6sY8xJ(u"ࠪࡗࡎ࡚ࡅࡔࡗࡕࡐࡘ࠭๐"),oSVpce1UQYrDqhuM6PT,GOhVkMATsg4cJmfa0Enp6zSqCr)
			gl1TwIjQhCzLxnN2urAHKbSea = sTcr7iDp5eFt4RoLMhuwq1A(u"ࡘࡷࡻࡥព")
	return
def Ixh90eJ2HkMZrTVofDp7n8aQwFy3Rj():
	XCf0q6um81HO4jAQFMPk9oBcnNEah = dXg3T8BS127LJNaWHh9ecpAuR()
	aHKzv76JCVnprbY8w(g4g6bfkPtVGU5lIM3(u"ࠫࠬ๑"),g4g6bfkPtVGU5lIM3(u"ࠬ࠭๒"),hBvsQ7oCkKUdwjx58ml3EN(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ๓"),FnBiAjthS8MkXs67W(u"ࠧห็ࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤๆ๐ࠠอ้สึ่ࡢ࡮ฦๆ์ࠤฬ๊ลึัสีࠥืโๆ࠼࡟ࡲࡡࡴࠧ๔")+mmn0lB2tFI7XTgVfESo)
	HHg0f8U75SdzxEcbt1JN(UkFh2OXjuTZEaexC,SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ๕"),UTelCo0ihE1d5R(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬ๖"))
	HHg0f8U75SdzxEcbt1JN(UkFh2OXjuTZEaexC,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭๗"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐࠬ๘"))
	HHg0f8U75SdzxEcbt1JN(UkFh2OXjuTZEaexC,iUeoLOsbHqP(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ๙"),g4g6bfkPtVGU5lIM3(u"࠭ࡓࡊࡖࡈࡗࡤࡔࡁࡎࡇࡖࠫ๚"))
	HHg0f8U75SdzxEcbt1JN(UkFh2OXjuTZEaexC,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ๛"),g4g6bfkPtVGU5lIM3(u"ࠨࡕࡌࡘࡊ࡙࡟ࡄࡊࡈࡇࡐ࠭๜"))
	HHg0f8U75SdzxEcbt1JN(UkFh2OXjuTZEaexC,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ๝"),p72fnFtcPix5UKwr9YNzW(u"ࠪࡗࡎ࡚ࡅࡔࡡ࡙ࡉࡗࡏࡆ࡚ࠩ๞"))
	jHevARrF7lS.setSetting(LiRcTVUWuth70DmPy(u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࡬࡯ࡴࡶࡤࠫ๟"),FnBiAjthS8MkXs67W(u"ࠬ࠭๠"))
	jHevARrF7lS.setSetting(SO94xq1RAkMm2uF(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࡧࡣࡥࡶࡦࡱࡡࠨ๡"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠧࠨ๢"))
	jHevARrF7lS.setSetting(UTelCo0ihE1d5R(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫ๣"),Me28A1sBLNIgUp5YCDyvT(u"ࠩࠪ๤"))
	jHevARrF7lS.setSetting(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲࡫ࡧࡳࡦ࡮࡫ࡨ࠶࠭๥"),kEhAHvti6Vnsfx(u"ࠫࠬ๦"))
	jHevARrF7lS.setSetting(zqdvcbP5L8BHh(u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹ࠱ࠨ๧"),xW2Arao7YVOemw(u"࠭ࠧ๨"))
	jHevARrF7lS.setSetting(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠧࡢࡸ࠱ࡴࡷ࡯ࡶࡴ࠴ࠪ๩"),Cu1704YofAbr3QTm(u"ࠨࠩ๪"))
	jHevARrF7lS.setSetting(p72fnFtcPix5UKwr9YNzW(u"ࠩࡤࡺ࠳ࡶࡥࡳ࡫ࡲࡨ࠳࡯࡮ࡧࡱࡶࠫ๫"),XzrqbGDIy54juixkMA(u"ࠪࠫ๬"))
	jHevARrF7lS.setSetting(UTelCo0ihE1d5R(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡰࡴࡴࡧࠨ๭"),g4g6bfkPtVGU5lIM3(u"ࠬ࠭๮"))
	jHevARrF7lS.setSetting(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡸࡥࡨࡷ࡯ࡥࡷ࠭๯"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧࠨ๰"))
	jHevARrF7lS.setSetting(FnBiAjthS8MkXs67W(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ๱"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠩࠪ๲"))
	jHevARrF7lS.setSetting(FnBiAjthS8MkXs67W(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ๳"),iUeoLOsbHqP(u"ࠫࠬ๴"))
	jHevARrF7lS.setSetting(Me28A1sBLNIgUp5YCDyvT(u"ࠬࡧࡶ࠯ࡨࡤ࡭ࡱ࡫ࡤ࠯ࡵࡦࡥࡷࡶࡥࡱࡴࡲࡼࡾ࠷ࠧ๵"),dshJSmRqeiP9nap2(u"࠭ࠧ๶"))
	jHevARrF7lS.setSetting(FnBiAjthS8MkXs67W(u"ࠧࡢࡸ࠱ࡪࡦ࡯࡬ࡦࡦ࠱ࡷࡨࡧࡲࡱࡧࡳࡶࡴࡾࡹ࠳ࠩ๷"),LiRcTVUWuth70DmPy(u"ࠨࠩ๸"))
	jHevARrF7lS.setSetting(E6MIKdpBomef(u"ࠩࡤࡺ࠳࡬ࡡࡪ࡮ࡨࡨ࠳ࡹࡣࡢࡴࡳࡩࡵࡸ࡯ࡹࡻ࠶ࠫ๹"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠪࠫ๺"))
	jHevARrF7lS.setSetting(FnBiAjthS8MkXs67W(u"ࠫࡦࡼ࠮ࡧࡣ࡬ࡰࡪࡪ࠮ࡴࡥࡤࡶࡵ࡫ࡰࡳࡱࡻࡽ࠹࠭๻"),iRoLg2m47tnDATBHGCSPNyx(u"ࠬ࠭๼"))
	import WWXqeaw1TE
	if XCf0q6um81HO4jAQFMPk9oBcnNEah==Me28A1sBLNIgUp5YCDyvT(u"࠭ࡓࡊࡏࡓࡐࡊࡥࡕࡑࡆࡄࡘࡊ࠭๽"):
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q(hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࡏࡑࡗࡍࡈࡋࠧ๾"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨ࠰ࠣࠤࡆࡸࡡࡣ࡫ࡦ࡚࡮ࡪࡥࡰࡵ࡙ࠣࡵࡪࡡࡵࡧࠣࡘࡾࡶࡥ࠻ࠢࠣࡗࡎࡓࡐࡍࡇ࡙ࠣࡕࡊࡁࡕࡇࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧ๿")+jI8KGT6dsgDQ+E6MIKdpBomef(u"ࠩࠣࡡࠬ຀"))
		HHg0f8U75SdzxEcbt1JN(UkFh2OXjuTZEaexC,bUdr5Hahw6sY8xJ(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤ࡙ࡉࡕࡇࡖࠫກ"))
		HHg0f8U75SdzxEcbt1JN(UkFh2OXjuTZEaexC,wRxoKs10Syj7V4edYhtP(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࠫຂ"))
		HHg0f8U75SdzxEcbt1JN(UkFh2OXjuTZEaexC,dshJSmRqeiP9nap2(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫ຃"))
		GcIxLR5v8p1YAleW2jkEu7nZqg(wRxoKs10Syj7V4edYhtP(u"࡙ࡸࡵࡦភ"),[UkFh2OXjuTZEaexC])
	else:
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ຄ"),bUdr5Hahw6sY8xJ(u"ࠧ࠯ࠢࠣࡅࡷࡧࡢࡪࡥ࡙࡭ࡩ࡫࡯ࡴࠢࡘࡴࡩࡧࡴࡦࠢࡗࡽࡵ࡫࠺ࠡࠢࡉ࡙ࡑࡒࠠࡖࡒࡇࡅ࡙ࡋࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫ຅")+jI8KGT6dsgDQ+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠨࠢࡠࠫຆ"))
		aHKzv76JCVnprbY8w(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩࠪງ"),UTelCo0ihE1d5R(u"ࠪࠫຈ"),bUdr5Hahw6sY8xJ(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧຉ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠬะๅࠡฬฮฬ๏ะࠠฤ๊ࠣฮาี๊ฬࠢส่ส฻ฯศำࠣห้าฯ๋ั่ࠣอืๆศ็ฯࠤฬ๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠢ࠱ࠤศ๎ࠠห็ุ้ࠣำࠠไษืࠤฬ๊ศา่ส้ัࠦ࡜࡯࡞ࡱࠤุ๐โ้็ࠣห้ศๆࠡษ็ฬึ์วๆฮࠣฬอ฿ึࠡษ็ๅา๎ีศฬ่ࠣ฻๋ว็ࠢ฼้้ࠦวๅสิ๊ฬ๋ฬࠡสุ์ึฯࠠึฯํัฮ่ࠦๆฬๆห๊๊ษࠨຊ"))
		GcIxLR5v8p1YAleW2jkEu7nZqg(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࡌࡡ࡭ࡵࡨម"),[])
		LKE5PBr2XSg0ZYlMCV(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࡆࡢ࡮ࡶࡩយ"))
		WWXqeaw1TE.AA6dYxswFGyI1zcN7kB82Rh9O()
		WWXqeaw1TE.KmIlXVwgsFZxEdh1b(lc0dpSmwoPDjLnk(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭຋"),iRoLg2m47tnDATBHGCSPNyx(u"ࡇࡣ࡯ࡷࡪរ"))
		WWXqeaw1TE.KmIlXVwgsFZxEdh1b(XzrqbGDIy54juixkMA(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡸࡴ࡮ࡲࠪຌ"),XzrqbGDIy54juixkMA(u"ࡈࡤࡰࡸ࡫ល"))
		WWXqeaw1TE.hD80GrKP5fMgRtdA9BYlHpCsk(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࡉࡥࡱࡹࡥវ"))
		WWXqeaw1TE.hEg3ps5mkl9i(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࡊࡦࡲࡳࡦឝ"))
		WWXqeaw1TE.pozVO4qafduDiX2WmYcN3w(lc0dpSmwoPDjLnk(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ຍ"),Me28A1sBLNIgUp5YCDyvT(u"ࠩࡨࡲࡦࡨ࡬ࡦࠩຎ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࡋࡧ࡬ࡴࡧឞ"))
		try:
			pjrlaSFd7x0DQYBO = WpgZTyqoMAPhwGiXF.path.join(mjaho7R5dY6eg,zqdvcbP5L8BHh(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬຏ"),Me28A1sBLNIgUp5YCDyvT(u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨຐ"),lc0dpSmwoPDjLnk(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠩຑ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬຒ"))
			bAKPiFGty6TVzcds7B = utF79ZlYs0VjSMJkOv4UHdf.Addon(id=fprnld4CZo(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫຓ"))
			bAKPiFGty6TVzcds7B.setSetting(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨࡣࡹ࠲ࡦࡻࡴࡰࡡࡳ࡭ࡨࡱࠧດ"),UTelCo0ihE1d5R(u"ࠩࡩࡥࡱࡹࡥࠨຕ"))
		except: pass
		try:
			pjrlaSFd7x0DQYBO = WpgZTyqoMAPhwGiXF.path.join(mjaho7R5dY6eg,g4g6bfkPtVGU5lIM3(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬຖ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨທ"),iRoLg2m47tnDATBHGCSPNyx(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿࡴ࠮ࡦ࡯ࡴࠬຘ"),UTelCo0ihE1d5R(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬນ"))
			bAKPiFGty6TVzcds7B = utF79ZlYs0VjSMJkOv4UHdf.Addon(id=bUdr5Hahw6sY8xJ(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡶ࠰ࡨࡱࡶࠧບ"))
			bAKPiFGty6TVzcds7B.setSetting(fprnld4CZo(u"ࠨࡣࡹ࠲ࡻ࡯ࡤࡦࡱࡢࡵࡺࡧ࡬ࡪࡶࡼࠫປ"),LiRcTVUWuth70DmPy(u"ࠩ࠶ࠫຜ"))
		except: pass
		try:
			pjrlaSFd7x0DQYBO = WpgZTyqoMAPhwGiXF.path.join(mjaho7R5dY6eg,Me28A1sBLNIgUp5YCDyvT(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬຝ"),SO94xq1RAkMm2uF(u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨພ"),iUeoLOsbHqP(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬຟ"),g4g6bfkPtVGU5lIM3(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬຠ"))
			bAKPiFGty6TVzcds7B = utF79ZlYs0VjSMJkOv4UHdf.Addon(id=Cu1704YofAbr3QTm(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧມ"))
			bAKPiFGty6TVzcds7B.setSetting(Me28A1sBLNIgUp5YCDyvT(u"ࠨࡣࡹ࠲ࡘ࡚ࡒࡆࡃࡐࡗࡊࡒࡅࡄࡖࡌࡓࡓ࠭ຢ"),UTelCo0ihE1d5R(u"ࠩ࠵ࠫຣ"))
		except: pass
	rKagANTOtGJnhVWfE2BHpePYC3IQ5l = iiZBqA90yC(J2M15kw7Rdv0rQZxITaNuXeyWc)
	rKagANTOtGJnhVWfE2BHpePYC3IQ5l = iiZBqA90yC(PGIWHNLQuRoK1M)
	jHevARrF7lS.setSetting(fprnld4CZo(u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧ຤"),mmn0lB2tFI7XTgVfESo)
	WWXqeaw1TE.cXkCR4jw3qv6(zqdvcbP5L8BHh(u"ࡌࡡ࡭ࡵࡨស"))
	zrIWmJZh2CpVf8(g4g6bfkPtVGU5lIM3(u"ࠫࡊࡾࡩࡵࠢࡷࡳࠥࡧࡰࡱ࡮ࡼࠤࡹ࡮ࡥࠡࡰࡨࡻࠥࡸࡥ࡭ࡧࡤࡷࡪ࠭ລ"))
	return
def oRFdNlxUi7a95Hr4SmgKV():
	hLFsrMZ4OBg9j2XPaevlDy = jHevARrF7lS.getSetting(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡸ࡮࡯ࡳࡶࠪ຦"))
	hLFsrMZ4OBg9j2XPaevlDy = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠶ᕌ") if not hLFsrMZ4OBg9j2XPaevlDy else int(hLFsrMZ4OBg9j2XPaevlDy)
	if not hLFsrMZ4OBg9j2XPaevlDy or not Cu1704YofAbr3QTm(u"࠰ᕍ")<=MMHpSTojGILfZXWeCOPyn4-hLFsrMZ4OBg9j2XPaevlDy<=xh9BXlAw0UoVsIZ4if3:
		jHevARrF7lS.setSetting(p72fnFtcPix5UKwr9YNzW(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡹࡨࡰࡴࡷࠫວ"),str(MMHpSTojGILfZXWeCOPyn4))
		o05ntqDmjf3OZBLgNlckQH(BXnrZSgERcxHvbVQ4)
		yqF23Yh7PQLRigpZ9fvAHBkn = jHevARrF7lS.getSetting(xW2Arao7YVOemw(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡲࡦࡩࡸࡰࡦࡸࠧຨ"))
		yqF23Yh7PQLRigpZ9fvAHBkn = SO94xq1RAkMm2uF(u"࠱ᕎ") if not yqF23Yh7PQLRigpZ9fvAHBkn else int(yqF23Yh7PQLRigpZ9fvAHBkn)
		if not yqF23Yh7PQLRigpZ9fvAHBkn or not YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠲ᕏ")<=MMHpSTojGILfZXWeCOPyn4-yqF23Yh7PQLRigpZ9fvAHBkn<=Oa8xvPtmLZkBA43K0EzrdhXS:
			jHevARrF7lS.setSetting(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡳࡧࡪࡹࡱࡧࡲࠨຩ"),str(MMHpSTojGILfZXWeCOPyn4))
			jKExzMkQmLFq(sTcr7iDp5eFt4RoLMhuwq1A(u"ࡔࡳࡷࡨហ"))
			t2EpW9jLKaIm4i = dM9DZS0pkxbqaf7W.Thread(target=tjgGCd6n4120mwh8)
			t2EpW9jLKaIm4i.start()
		CC1LIWDrQePnO2GNqkBaiZwmuYS = jHevARrF7lS.getSetting(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡮ࡲࡲ࡬࠭ສ"))
		CC1LIWDrQePnO2GNqkBaiZwmuYS = XzrqbGDIy54juixkMA(u"࠳ᕐ") if not CC1LIWDrQePnO2GNqkBaiZwmuYS else int(CC1LIWDrQePnO2GNqkBaiZwmuYS)
		if not CC1LIWDrQePnO2GNqkBaiZwmuYS or not hBvsQ7oCkKUdwjx58ml3EN(u"࠴ᕑ")<=MMHpSTojGILfZXWeCOPyn4-CC1LIWDrQePnO2GNqkBaiZwmuYS<=ZcdnQAJ3ltkoiPsyX5:
			jHevARrF7lS.setSetting(g4g6bfkPtVGU5lIM3(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰࡯ࡳࡳ࡭ࠧຫ"),str(MMHpSTojGILfZXWeCOPyn4))
			import WWXqeaw1TE
			WWXqeaw1TE.WrEwOCRSaplo7iy6ZDxIJ2teL0Tf(dshJSmRqeiP9nap2(u"ࡈࡤࡰࡸ࡫អ"),fprnld4CZo(u"ࡕࡴࡸࡩឡ"))
	Nli4T1k6dRBqg8DrEmVWcGfKH5Xwx = YrGtRdILOunPs8Zv(jHevARrF7lS.getSetting(FvNyZqaLKw(u"ࠫࡦࡼ࠮ࡱࡧࡵ࡭ࡴࡪ࠮ࡪࡰࡩࡳࡸ࠭ຬ")))
	Nli4T1k6dRBqg8DrEmVWcGfKH5Xwx = FvNyZqaLKw(u"࠵ᕒ") if not Nli4T1k6dRBqg8DrEmVWcGfKH5Xwx else int(Nli4T1k6dRBqg8DrEmVWcGfKH5Xwx)
	KgtveJz0F5EZL4XuBOQ2 = YrGtRdILOunPs8Zv(jHevARrF7lS.getSetting(FnBiAjthS8MkXs67W(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧອ")))
	KgtveJz0F5EZL4XuBOQ2 = FvNyZqaLKw(u"࠶ᕓ") if not KgtveJz0F5EZL4XuBOQ2 else int(KgtveJz0F5EZL4XuBOQ2)
	if not Nli4T1k6dRBqg8DrEmVWcGfKH5Xwx or not KgtveJz0F5EZL4XuBOQ2 or not S4SOKF2QbBhjCd3RrVMuHIzE(u"࠰ᕔ")<=MMHpSTojGILfZXWeCOPyn4-KgtveJz0F5EZL4XuBOQ2<=Nli4T1k6dRBqg8DrEmVWcGfKH5Xwx:
		dPK7QBzFODHNcMw = xW2Arao7YVOemw(u"࠲ᕕ")
		UPczVG8HDanC7JAK59RkEOW6u = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࡊࡦࡲࡳࡦឤ") if bkHiCyWXjdgvF9xE1DA6wQ48(dshJSmRqeiP9nap2(u"࠭ࡏࡕ࠳࠼ࡎ࡚࠶ࡸࡃࡖࡘࡰࡉ࡞ࠧຮ")) else LiRcTVUWuth70DmPy(u"ࡗࡶࡺ࡫ឣ")
		if UPczVG8HDanC7JAK59RkEOW6u:
			LysGAMozW185TVxl = AE8MedoFXQNrYhRvW(FvNyZqaLKw(u"࡙ࡸࡵࡦឥ"))
			if len(LysGAMozW185TVxl)>SO94xq1RAkMm2uF(u"࠳ᕖ"):
				LOHZ4o9m7p6ebfTYXGIdz5PWs3q(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧࡏࡑࡗࡍࡈࡋࠧຯ"),g4g6bfkPtVGU5lIM3(u"ࠨ࠰ࠣࠤࡘ࡮࡯ࡸ࡫ࡱ࡫ࠥࡗࡵࡦࡵࡷ࡭ࡴࡴࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫະ")+jI8KGT6dsgDQ+SO94xq1RAkMm2uF(u"ࠩࠣࡡࠬັ"))
				ESIi4D0MAgOCWT3Rwobfq5Yh,exOIZnGECcR2p3WV4TPY06BNDo7,Tg1CAnZtj9MNe5wS,RuSqTgGZ7tlerwK9pWYf16Ln,tcopCZGnbdvY8r,r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6 = LysGAMozW185TVxl[oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠳ᕗ")]
				uLrdWC8tUFHm52Sbo07I,vvuP2MEINoUGtKT5 = RuSqTgGZ7tlerwK9pWYf16Ln.split(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪࡠࡳࡁ࠻ࠨາ"))
				del LysGAMozW185TVxl[g4g6bfkPtVGU5lIM3(u"࠴ᕘ")]
				i725BsRvyf4xV9PuDK1l = Y7pXj2OtNq9GZdvmcTkS3hMJn.sample(LysGAMozW185TVxl,dshJSmRqeiP9nap2(u"࠶ᕙ"))
				ESIi4D0MAgOCWT3Rwobfq5Yh,exOIZnGECcR2p3WV4TPY06BNDo7,Tg1CAnZtj9MNe5wS,RuSqTgGZ7tlerwK9pWYf16Ln,tcopCZGnbdvY8r,r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6 = i725BsRvyf4xV9PuDK1l[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠶ᕚ")]
				Tg1CAnZtj9MNe5wS = bUdr5Hahw6sY8xJ(u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠥࡀࠠࠨຳ")+ESIi4D0MAgOCWT3Rwobfq5Yh+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧິ")+Tg1CAnZtj9MNe5wS
				tcopCZGnbdvY8r = Me28A1sBLNIgUp5YCDyvT(u"࠭ลาีส่ࠥืำศๆฬࠤ้๊ๅษำ่ะࠬີ")
				bKugLoHc61A7wqrmVs9G = xW2Arao7YVOemw(u"ࠧศๆอฬึ฿วหࠩຶ")
				button0,button1 = RuSqTgGZ7tlerwK9pWYf16Ln,tcopCZGnbdvY8r
				Npcl0CaSkg = [button0,button1,bKugLoHc61A7wqrmVs9G]
				V73imzAay4o2I0CLHNBXRcTPs8Jbv = QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠱ᕛ") if bkHiCyWXjdgvF9xE1DA6wQ48(lc0dpSmwoPDjLnk(u"ࠨ࡙ࡖ࡙ࡗࡌࡔ࠲࠻ࡔࡘࡊࡌ࡚࡙ࠩື")) else E6MIKdpBomef(u"࠲࠲ᕜ")
				r54fQALYmUbegM7yxsNc = -G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠻ᕝ")
				while r54fQALYmUbegM7yxsNc<UTelCo0ihE1d5R(u"࠳ᕞ"):
					NNm7RXEW4hKn98LtBlkDesp = Y7pXj2OtNq9GZdvmcTkS3hMJn.sample(Npcl0CaSkg,S4SOKF2QbBhjCd3RrVMuHIzE(u"࠷ᕟ"))
					r54fQALYmUbegM7yxsNc = CCQOct8zmrKMuP6ZEkxq7oaf1BeRv(fprnld4CZo(u"ຸࠩࠪ"),NNm7RXEW4hKn98LtBlkDesp[Me28A1sBLNIgUp5YCDyvT(u"࠶ᕡ")],NNm7RXEW4hKn98LtBlkDesp[FvNyZqaLKw(u"࠶ᕠ")],NNm7RXEW4hKn98LtBlkDesp[g4g6bfkPtVGU5lIM3(u"࠲ᕢ")],uLrdWC8tUFHm52Sbo07I,Tg1CAnZtj9MNe5wS,Cu1704YofAbr3QTm(u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡧ࡯ࡧࡧࡱࡱࡸູࠬ"),V73imzAay4o2I0CLHNBXRcTPs8Jbv,FvNyZqaLKw(u"࠷࠲ᕣ"))
					if r54fQALYmUbegM7yxsNc==G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠳࠳ᕤ"): break
					from WWXqeaw1TE import eimszEapSbIurqvN3c5hk4VylDCH,JuKwpjEMF0O8sC
					if r54fQALYmUbegM7yxsNc>=g4g6bfkPtVGU5lIM3(u"࠴ᕦ") and NNm7RXEW4hKn98LtBlkDesp[r54fQALYmUbegM7yxsNc]==Npcl0CaSkg[zqdvcbP5L8BHh(u"࠴ᕥ")]:
						eimszEapSbIurqvN3c5hk4VylDCH()
						if r54fQALYmUbegM7yxsNc>=pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠶ᕨ"): r54fQALYmUbegM7yxsNc = -Me28A1sBLNIgUp5YCDyvT(u"࠾ᕧ")
					elif r54fQALYmUbegM7yxsNc>=Me28A1sBLNIgUp5YCDyvT(u"࠰ᕩ") and NNm7RXEW4hKn98LtBlkDesp[r54fQALYmUbegM7yxsNc]==Npcl0CaSkg[FnBiAjthS8MkXs67W(u"࠳ᕪ")]:
						JuKwpjEMF0O8sC(yA5z6LIXBlo41PRVMY87wOisFp(u"ࡌࡡ࡭ࡵࡨឦ"))
					if r54fQALYmUbegM7yxsNc==-FvNyZqaLKw(u"࠳ᕫ"): aHKzv76JCVnprbY8w(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"຺ࠫࠬ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬ࠭ົ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩຼ"),fprnld4CZo(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ัีําࠠฯูฦ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴࠠๅๆัีําࠠศๆุั๏ำࠠฤะอีࠥ๎วฮั้๋ࠣࠦวๅลฯ์อฯࠠศๆ่ฮํ็ัสࠩຽ"))
				dPK7QBzFODHNcMw = sTcr7iDp5eFt4RoLMhuwq1A(u"࠴ᕬ")
			else: dPK7QBzFODHNcMw = fprnld4CZo(u"࠴ᕭ")
		jHevARrF7lS.setSetting(xW2Arao7YVOemw(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ຾"),njglTZ1qzxm9K70U2(MMHpSTojGILfZXWeCOPyn4))
		Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,iUeoLOsbHqP(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ຿"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠪࡗࡎ࡚ࡅࡔࡡࡑࡅࡒࡋࡓࠨເ"),dPK7QBzFODHNcMw,GOhVkMATsg4cJmfa0Enp6zSqCr)
	return
def TXC6fjMPKHmulA8p4NOYxbJ7ogcVa(uI7UAQCyPO85aLonkGqrdWwRt,PPVuQkU9OfiBXegYZK2c3Tl6,KmsBUDR0jWE4J5I1QLyHvr,xUmyzZKOd8hv3Jc5X2nPHCAarW4sF,vLfxaY43gW,Hax6koyQtZVp4TR,fH8bDPV6AceuCFNO0Ert7oq3p,stpvYViqku3,LGdFZQvKeU52s6H0DgjN,dMiPQHejCTElLJuDz6oN5tR8Y,ccIZBYDOGdJlTE81Li2wAmuKtk,Tr8iRxJmbcEhftU5DSHzA,ONgqycFoxi,PK3YifFT0nxcUa):
	JbesxSa6R0YfMkFrjLpl4PzA2H = int(dMiPQHejCTElLJuDz6oN5tR8Y%SO94xq1RAkMm2uF(u"࠶࠶ᕮ"))
	XjUwdKaTHutRF0MgYkiWpZI = int(dMiPQHejCTElLJuDz6oN5tR8Y/p72fnFtcPix5UKwr9YNzW(u"࠷࠰ᕯ"))
	gzlMwcJ8GTRbLjtQr3pXsACPYmqK42 = uI7UAQCyPO85aLonkGqrdWwRt,PPVuQkU9OfiBXegYZK2c3Tl6,KmsBUDR0jWE4J5I1QLyHvr,xUmyzZKOd8hv3Jc5X2nPHCAarW4sF,vLfxaY43gW,Hax6koyQtZVp4TR,fH8bDPV6AceuCFNO0Ert7oq3p,xW2Arao7YVOemw(u"ࠫࠬແ"),LGdFZQvKeU52s6H0DgjN
	JJTGFKEhWHfvNoA3trdlu7mZw = jHevARrF7lS.getSetting(FvNyZqaLKw(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡲࡺࡹࡣࡢࡥ࡫ࡩࠬໂ"))
	if not JJTGFKEhWHfvNoA3trdlu7mZw: jHevARrF7lS.setSetting(dshJSmRqeiP9nap2(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭ໃ"),bUdr5Hahw6sY8xJ(u"ࠧࡂࡗࡗࡓࠬໄ"))
	gGudVm2TlMnyh = jHevARrF7lS.getSetting(wRxoKs10Syj7V4edYhtP(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬ໅"))
	m5MfkiT7oUDbvHI43ByeY9FP = zQP2wplUqKgLE3DYy6OcoSHJfT8(ccIZBYDOGdJlTE81Li2wAmuKtk)
	A0EfUSpq5ePagikCcDRF = [kEhAHvti6Vnsfx(u"࠰ᕷ"),XzrqbGDIy54juixkMA(u"࠲࠷ᕱ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠳࠺ᕲ"),Cu1704YofAbr3QTm(u"࠴࠽ᕳ"),XzrqbGDIy54juixkMA(u"࠲࠷ᕰ"),kEhAHvti6Vnsfx(u"࠹࠴ᕶ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠹࠵ᕴ"),kEhAHvti6Vnsfx(u"࠺࠹ᕵ")]
	wkY72geNfMtWEG3Xm = XjUwdKaTHutRF0MgYkiWpZI not in A0EfUSpq5ePagikCcDRF
	LLvxmXqeZj4DQ = XjUwdKaTHutRF0MgYkiWpZI in [SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠶࠸ᕻ"),g4g6bfkPtVGU5lIM3(u"࠳࠺ᕸ"),g4g6bfkPtVGU5lIM3(u"࠺࠵ᕺ"),iUeoLOsbHqP(u"࠹࠵ᕹ")]
	qE5aLQv7Aj6rCIylT0ZSFupB2Y = dMiPQHejCTElLJuDz6oN5tR8Y in [iUeoLOsbHqP(u"࠸࠶࠶ᕽ"),yA5z6LIXBlo41PRVMY87wOisFp(u"࠷࠽࠰ᕼ")]
	nWZlLE9jkg8U40evFoOuriGxtH1 = (wkY72geNfMtWEG3Xm or LLvxmXqeZj4DQ) and not qE5aLQv7Aj6rCIylT0ZSFupB2Y
	fndPIAeTKyOtX0BYlcF1zgjh9asv = gGudVm2TlMnyh!=LiRcTVUWuth70DmPy(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡈࡈࠬໆ") and (gGudVm2TlMnyh or not stpvYViqku3)
	HEjfZ9iVnC8lSwhTDsYWQp = LiRcTVUWuth70DmPy(u"ࠪࡸࡾࡶࡥ࠾ࠩ໇") in gGudVm2TlMnyh
	tyc9EdgfWn = dMiPQHejCTElLJuDz6oN5tR8Y in [LiRcTVUWuth70DmPy(u"࠴࠺࠶ᖈ"),FnBiAjthS8MkXs67W(u"࠵࠻࠸ᖉ"),XzrqbGDIy54juixkMA(u"࠶࠼࠳ᖊ"),bUdr5Hahw6sY8xJ(u"࠷࠶࠵ᖄ"),Cu1704YofAbr3QTm(u"࠱࠷࠷ᖅ"),dshJSmRqeiP9nap2(u"࠲࠸࠹ᖆ"),iRoLg2m47tnDATBHGCSPNyx(u"࠳࠹࠻ᖇ"),dshJSmRqeiP9nap2(u"࠶࠼࠸ᖃ"),dshJSmRqeiP9nap2(u"࠹࠹࠵ᖀ"),XzrqbGDIy54juixkMA(u"࠷࠷࠴ᕾ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠸࠸࠶ᕿ"),XzrqbGDIy54juixkMA(u"࠺࠺࠹ᖁ"),yA5z6LIXBlo41PRVMY87wOisFp(u"࠻࠻࠻ᖂ")]
	szwTAdaBt4FiXO = JbesxSa6R0YfMkFrjLpl4PzA2H==SO94xq1RAkMm2uF(u"࠿ᖋ") or dMiPQHejCTElLJuDz6oN5tR8Y in [wRxoKs10Syj7V4edYhtP(u"࠲࠶࠸ᖍ"),LiRcTVUWuth70DmPy(u"࠸࠵࠻ᖏ"),bUdr5Hahw6sY8xJ(u"࠷࠵࠷ᖎ"),kEhAHvti6Vnsfx(u"࠴࠶ᖌ")]
	zsweY6aBOF8Nom2rkpTxCULnZVS = not tyc9EdgfWn
	L3NFZsQSrwE = not szwTAdaBt4FiXO
	gB9QPhncrt1sf5k7bdiE06o4ZaMeIN = m5MfkiT7oUDbvHI43ByeY9FP in [xW2Arao7YVOemw(u"່ࠫࠬ"),UTelCo0ihE1d5R(u"ࠬ࠴࠮ࠨ້")]
	RPnIwkGDg45zurCHhZUmtFXMaAB = gB9QPhncrt1sf5k7bdiE06o4ZaMeIN or zsweY6aBOF8Nom2rkpTxCULnZVS
	qLhjGK9s6Obadu1 = gB9QPhncrt1sf5k7bdiE06o4ZaMeIN or L3NFZsQSrwE or HEjfZ9iVnC8lSwhTDsYWQp
	bROqek21FEdauJwU4nQNGlT3 = dMiPQHejCTElLJuDz6oN5tR8Y not in [QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠳࠸࠳ᖔ"),lc0dpSmwoPDjLnk(u"࠶࠻࠷ᖐ"),FvNyZqaLKw(u"࠴࠹࠹ᖕ"),Me28A1sBLNIgUp5YCDyvT(u"࠸࠷࠱ᖒ"),sTcr7iDp5eFt4RoLMhuwq1A(u"࠸࠹࠰ᖑ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠵࠵࠲ᖓ")]
	if JJTGFKEhWHfvNoA3trdlu7mZw==FvNyZqaLKw(u"࠭ࡓࡕࡑࡓ໊ࠫ"): LLrYxtGOznuHIP8w9A5lEdK = szwTAdaBt4FiXO or tyc9EdgfWn
	else: LLrYxtGOznuHIP8w9A5lEdK = sTcr7iDp5eFt4RoLMhuwq1A(u"ࡔࡳࡷࡨឧ")
	Y3uMOTvosK = XjUwdKaTHutRF0MgYkiWpZI in [iUeoLOsbHqP(u"࠻࠹ᖗ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"࠺࠹ᖖ")]
	Gv7eMuU4poDP8alV1NsmxQ0wtCkW = dMiPQHejCTElLJuDz6oN5tR8Y in [E6MIKdpBomef(u"࠷࠾࠰ᖘ"),UTelCo0ihE1d5R(u"࠽࠲࠱ᖙ")]
	BPtk0fL1b5lEnQXgj4wve6D = not Y3uMOTvosK and not Gv7eMuU4poDP8alV1NsmxQ0wtCkW
	ICsPNOUeaB3q1F = RPnIwkGDg45zurCHhZUmtFXMaAB and qLhjGK9s6Obadu1 and bROqek21FEdauJwU4nQNGlT3 and LLrYxtGOznuHIP8w9A5lEdK and BPtk0fL1b5lEnQXgj4wve6D
	YoLfB705TmCp = bROqek21FEdauJwU4nQNGlT3 and LLrYxtGOznuHIP8w9A5lEdK and BPtk0fL1b5lEnQXgj4wve6D
	rBRcWufVlKL0xEY = YoLfB705TmCp
	KJbsEUM9tZiV3DkC4rpcHqw52Qh = jHevARrF7lS.getSetting(FnBiAjthS8MkXs67W(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡶࡲࡰࡸ࡬ࡨࡪࡸ໋ࠧ"))
	NZ4fvUkGE3AxJed9 = jHevARrF7lS.getSetting(g4g6bfkPtVGU5lIM3(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡣࡰࡦࡨࠫ໌"))
	if fndPIAeTKyOtX0BYlcF1zgjh9asv and ICsPNOUeaB3q1F:
		XXvYorzsNbUPBCtn289 = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩ࡯࡭ࡸࡺࠧໍ"),iUeoLOsbHqP(u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩ໎")+KJbsEUM9tZiV3DkC4rpcHqw52Qh+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࡤ࠭໏")+NZ4fvUkGE3AxJed9,gzlMwcJ8GTRbLjtQr3pXsACPYmqK42)
		if XXvYorzsNbUPBCtn289:
			LOHZ4o9m7p6ebfTYXGIdz5PWs3q(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠬ࠭໐"),iRoLg2m47tnDATBHGCSPNyx(u"࠭࠮ࠡࠢࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨ໑")+KJbsEUM9tZiV3DkC4rpcHqw52Qh+LiRcTVUWuth70DmPy(u"ࠧࡠࠩ໒")+NZ4fvUkGE3AxJed9+sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨࠢࠣࠤࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡳࡥ࡯ࡷࠣࡪࡷࡵ࡭ࠡࡥࡤࡧ࡭࡫ࠧ໓"))
			if HEjfZ9iVnC8lSwhTDsYWQp:
				l0RaMBnU56FLH7OG8bwhur = []
				from Fnbs0VJKLu import uy1vkLaIKUcm7dZM5poi
				from ILG9YzDbKk import WW7LRjMc4iCplzdXB,yi0Zf5IPxWcVrHjCBm71w
				RK90gXxbqwal7DpkTr = uy1vkLaIKUcm7dZM5poi
				aKdb1ORhYEDB = WW7LRjMc4iCplzdXB()
				WWOdm5Fv3G7lkBIVHf92ubZgQwh = gGudVm2TlMnyh
				yvil0t8OYz,QPWVZdwNG2bc5XIa78gOS,Zi5AuP7kLVfqF6pIXn,gbmKsHP02TRJySIfcw,DK7BTjNhbavIy18uQJZmSG,YOuC4JWSALz8cUoh1q92Pefm,Y89YcjpoTm1LfIzswACN27yxudh,qaO9WpUcvxAw,mXzICYuRNG2Pv0LAW3lH = z4sqGEoRxKVCSwc3nLZ(WWOdm5Fv3G7lkBIVHf92ubZgQwh)
				ikEC0j3XscUtzdSH6T9JZKRI7 = yvil0t8OYz,QPWVZdwNG2bc5XIa78gOS,Zi5AuP7kLVfqF6pIXn,gbmKsHP02TRJySIfcw,DK7BTjNhbavIy18uQJZmSG,YOuC4JWSALz8cUoh1q92Pefm,Y89YcjpoTm1LfIzswACN27yxudh,hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩࠪ໔"),mXzICYuRNG2Pv0LAW3lH
				for QCsivW64j0eEVL3uz87Sp1Jrfd in XXvYorzsNbUPBCtn289:
					HHPNF6gWUpy1j3Vhi5Qa7Dm = QCsivW64j0eEVL3uz87Sp1Jrfd[G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠪࡱࡪࡴࡵࡊࡶࡨࡱࠬ໕")]
					if HHPNF6gWUpy1j3Vhi5Qa7Dm==ikEC0j3XscUtzdSH6T9JZKRI7 or QCsivW64j0eEVL3uz87Sp1Jrfd[zqdvcbP5L8BHh(u"ࠫࡲࡵࡤࡦࠩ໖")] in [xW2Arao7YVOemw(u"࠳࠸࠸ᖛ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠲࠸࠲ᖚ")]:
						QCsivW64j0eEVL3uz87Sp1Jrfd = MNBcU3JpngmEZt9fCseuWdwkDh6(HHPNF6gWUpy1j3Vhi5Qa7Dm,RK90gXxbqwal7DpkTr,aKdb1ORhYEDB)
						if QCsivW64j0eEVL3uz87Sp1Jrfd[zqdvcbP5L8BHh(u"ࠬ࡬ࡡࡷࡱࡵ࡭ࡹ࡫ࡳࠨ໗")]:
							oNPncv5rDfYgHIOlhMtxdi2ys = yi0Zf5IPxWcVrHjCBm71w(aKdb1ORhYEDB,HHPNF6gWUpy1j3Vhi5Qa7Dm,QCsivW64j0eEVL3uz87Sp1Jrfd[XzrqbGDIy54juixkMA(u"࠭࡮ࡦࡹࡳࡥࡹ࡮ࠧ໘")])
							QCsivW64j0eEVL3uz87Sp1Jrfd[lc0dpSmwoPDjLnk(u"ࠧࡤࡱࡱࡸࡪࡾࡴࡠ࡯ࡨࡲࡺ࠭໙")] = oNPncv5rDfYgHIOlhMtxdi2ys+QCsivW64j0eEVL3uz87Sp1Jrfd[iUeoLOsbHqP(u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࡡࡰࡩࡳࡻࠧ໚")]
					l0RaMBnU56FLH7OG8bwhur.append(QCsivW64j0eEVL3uz87Sp1Jrfd)
				jHevARrF7lS.setSetting(UTelCo0ihE1d5R(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭໛"),fprnld4CZo(u"ࠪࠫໜ"))
				if uI7UAQCyPO85aLonkGqrdWwRt==oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫໝ"): Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,hBvsQ7oCkKUdwjx58ml3EN(u"ࠬࡓࡅࡏࡗࡖࡣࡈࡇࡃࡉࡇࡢࠫໞ")+KJbsEUM9tZiV3DkC4rpcHqw52Qh+LiRcTVUWuth70DmPy(u"࠭࡟ࠨໟ")+NZ4fvUkGE3AxJed9,gzlMwcJ8GTRbLjtQr3pXsACPYmqK42,l0RaMBnU56FLH7OG8bwhur,Oa8xvPtmLZkBA43K0EzrdhXS)
			else: l0RaMBnU56FLH7OG8bwhur = XXvYorzsNbUPBCtn289
			if uI7UAQCyPO85aLonkGqrdWwRt==UTelCo0ihE1d5R(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ໠") and m5MfkiT7oUDbvHI43ByeY9FP!=oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨ࠰࠱ࠫ໡") and nWZlLE9jkg8U40evFoOuriGxtH1: BejcHLrmkn9()
			aEQ5huZL1XtRAUrHsMp6Dfz3K = DsdoW9FXPpMkiLAlnrN2Tv3Gb17(gzlMwcJ8GTRbLjtQr3pXsACPYmqK42,l0RaMBnU56FLH7OG8bwhur,Tr8iRxJmbcEhftU5DSHzA,ONgqycFoxi,PK3YifFT0nxcUa)
			if aEQ5huZL1XtRAUrHsMp6Dfz3K: zrIWmJZh2CpVf8()
	elif uI7UAQCyPO85aLonkGqrdWwRt==lc0dpSmwoPDjLnk(u"ࠩࡩࡳࡱࡪࡥࡳࠩ໢") and gGudVm2TlMnyh==YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪࡖࡊࡌࡒࡆࡕࡋࡉࡉ࠭໣") and YoLfB705TmCp:
		HHg0f8U75SdzxEcbt1JN(UkFh2OXjuTZEaexC,UTelCo0ihE1d5R(u"ࠫࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡࠪ໤")+KJbsEUM9tZiV3DkC4rpcHqw52Qh+iRoLg2m47tnDATBHGCSPNyx(u"ࠬࡥࠧ໥")+NZ4fvUkGE3AxJed9,gzlMwcJ8GTRbLjtQr3pXsACPYmqK42)
	return gzlMwcJ8GTRbLjtQr3pXsACPYmqK42,m5MfkiT7oUDbvHI43ByeY9FP,nWZlLE9jkg8U40evFoOuriGxtH1,rBRcWufVlKL0xEY,KJbsEUM9tZiV3DkC4rpcHqw52Qh,NZ4fvUkGE3AxJed9
def GUNYIXtwzJvTa2x4k5u3p(uI7UAQCyPO85aLonkGqrdWwRt,PPVuQkU9OfiBXegYZK2c3Tl6,mHejXxkvM1qCESPVRy54QB,xUmyzZKOd8hv3Jc5X2nPHCAarW4sF,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,fH8bDPV6AceuCFNO0Ert7oq3p,stpvYViqku3,LGdFZQvKeU52s6H0DgjN,cpH6YnUzMk9A,dMiPQHejCTElLJuDz6oN5tR8Y,IyACiLrROSYh7HBjzgoUVmfF,MDjmb7oV5XyCkLe4T32Q):
	if IyACiLrROSYh7HBjzgoUVmfF in [LiRcTVUWuth70DmPy(u"࠭࠱ࠨ໦"),Cu1704YofAbr3QTm(u"ࠧ࠳ࠩ໧"),Cu1704YofAbr3QTm(u"ࠨ࠵ࠪ໨"),iRoLg2m47tnDATBHGCSPNyx(u"ࠩ࠷ࠫ໩"),Me28A1sBLNIgUp5YCDyvT(u"ࠪ࠹ࠬ໪")] and MDjmb7oV5XyCkLe4T32Q:
		from ILG9YzDbKk import CC2IGzXJ4u
		CC2IGzXJ4u(stpvYViqku3,IyACiLrROSYh7HBjzgoUVmfF,MDjmb7oV5XyCkLe4T32Q)
		jHevARrF7lS.setSetting(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨ໫"),jI8KGT6dsgDQ)
		cEZpW924rqNYm5.executebuiltin(xW2Arao7YVOemw(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ໬"))
	elif IyACiLrROSYh7HBjzgoUVmfF==kEhAHvti6Vnsfx(u"࠭࠶ࠨ໭"):
		from ccTpfuSVZY import From8aTqdhCbPs,keBlY04RjHEnpLPAbXaG
		if MDjmb7oV5XyCkLe4T32Q==pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩ໮"): From8aTqdhCbPs(LiRcTVUWuth70DmPy(u"ࠨ์ิะ๎ࠦวๅษ้ฮ฽อัࠨ໯"),xW2Arao7YVOemw(u"ࠩฯหึ๐ࠠโฯุࠤ๊๊แࠡษ็ฮา๋๊ๅࠩ໰"),MQbODJoPV2w8TEAg4zXZdjLxSW=iRoLg2m47tnDATBHGCSPNyx(u"࠳࠸࠴࠵ᖜ"))
		elif MDjmb7oV5XyCkLe4T32Q==bUdr5Hahw6sY8xJ(u"ࠪࡈࡊࡒࡅࡕࡇࠪ໱"): dMiPQHejCTElLJuDz6oN5tR8Y = SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠶࠷࠹ᖝ")
		zpXG3Ky6ou8ndWHkb4 = keBlY04RjHEnpLPAbXaG(uI7UAQCyPO85aLonkGqrdWwRt,cpH6YnUzMk9A,mHejXxkvM1qCESPVRy54QB,dMiPQHejCTElLJuDz6oN5tR8Y,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,fH8bDPV6AceuCFNO0Ert7oq3p,stpvYViqku3,LGdFZQvKeU52s6H0DgjN)
		if MDjmb7oV5XyCkLe4T32Q==UTelCo0ihE1d5R(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭໲"): zrIWmJZh2CpVf8(iUeoLOsbHqP(u"ࠬࡋࡸࡪࡶࠣࡸࡴࠦࡦࡪࡰࡤࡰ࡮ࢀࡥࠡࡸ࡬ࡨࡪࡵࡳࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ໳"))
		elif MDjmb7oV5XyCkLe4T32Q==E6MIKdpBomef(u"࠭ࡄࡆࡎࡈࡘࡊ࠭໴"): cEZpW924rqNYm5.executebuiltin(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ໵"))
	elif stpvYViqku3==fprnld4CZo(u"ࠨ࠹ࠪ໶"):
		from oIN2YpnkJd import A9osj6z4gXVhnymUCKB2F
		A9osj6z4gXVhnymUCKB2F()
		cEZpW924rqNYm5.executebuiltin(zqdvcbP5L8BHh(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭໷"))
	elif stpvYViqku3==pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠪ࠼ࠬ໸"):
		cEZpW924rqNYm5.executebuiltin(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ໹")+ssZLBRtgnMkc7dSouQeGCx3r8m+iRoLg2m47tnDATBHGCSPNyx(u"ࠬࡅ࡭ࡰࡦࡨࡁࠬ໺")+str(xUmyzZKOd8hv3Jc5X2nPHCAarW4sF)+oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠭ࠦࡵࡻࡳࡩࡂ࡬࡯࡭ࡦࡨࡶ࠮࠭໻"))
	elif stpvYViqku3==oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧ࠺ࠩ໼"):
		jHevARrF7lS.setSetting(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬ໽"),FnBiAjthS8MkXs67W(u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡈࡈࠬ໾"))
		cEZpW924rqNYm5.executebuiltin(g4g6bfkPtVGU5lIM3(u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ໿"))
		zrIWmJZh2CpVf8(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࡊࡾࡩࡵࠢࡷࡳࠥࡸࡥࡧࡴࡨࡷ࡭ࠦ࡭ࡦࡰࡸࠫༀ"))
	return
def Vi7FqdgSTmZptPJWj9wH(uI7UAQCyPO85aLonkGqrdWwRt,PPVuQkU9OfiBXegYZK2c3Tl6,mHejXxkvM1qCESPVRy54QB,xUmyzZKOd8hv3Jc5X2nPHCAarW4sF,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,fH8bDPV6AceuCFNO0Ert7oq3p,stpvYViqku3,LGdFZQvKeU52s6H0DgjN,cpH6YnUzMk9A,dMiPQHejCTElLJuDz6oN5tR8Y,IyACiLrROSYh7HBjzgoUVmfF,MDjmb7oV5XyCkLe4T32Q,ccIZBYDOGdJlTE81Li2wAmuKtk):
	if stpvYViqku3: GUNYIXtwzJvTa2x4k5u3p(uI7UAQCyPO85aLonkGqrdWwRt,PPVuQkU9OfiBXegYZK2c3Tl6,mHejXxkvM1qCESPVRy54QB,xUmyzZKOd8hv3Jc5X2nPHCAarW4sF,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,fH8bDPV6AceuCFNO0Ert7oq3p,stpvYViqku3,LGdFZQvKeU52s6H0DgjN,cpH6YnUzMk9A,dMiPQHejCTElLJuDz6oN5tR8Y,IyACiLrROSYh7HBjzgoUVmfF,MDjmb7oV5XyCkLe4T32Q)
	if fCQhRT4Nr3gvxstOoADJaY: Ixh90eJ2HkMZrTVofDp7n8aQwFy3Rj()
	jKExzMkQmLFq(zqdvcbP5L8BHh(u"ࡇࡣ࡯ࡷࡪឨ"))
	oRFdNlxUi7a95Hr4SmgKV()
	Tr8iRxJmbcEhftU5DSHzA,ONgqycFoxi,PK3YifFT0nxcUa = SO94xq1RAkMm2uF(u"ࡗࡶࡺ࡫ឪ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࡈࡤࡰࡸ࡫ឩ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࡈࡤࡰࡸ࡫ឩ")
	ANIMWHn51Sv9C = TXC6fjMPKHmulA8p4NOYxbJ7ogcVa(uI7UAQCyPO85aLonkGqrdWwRt,PPVuQkU9OfiBXegYZK2c3Tl6,mHejXxkvM1qCESPVRy54QB,xUmyzZKOd8hv3Jc5X2nPHCAarW4sF,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,fH8bDPV6AceuCFNO0Ert7oq3p,stpvYViqku3,LGdFZQvKeU52s6H0DgjN,dMiPQHejCTElLJuDz6oN5tR8Y,ccIZBYDOGdJlTE81Li2wAmuKtk,Tr8iRxJmbcEhftU5DSHzA,ONgqycFoxi,PK3YifFT0nxcUa)
	gzlMwcJ8GTRbLjtQr3pXsACPYmqK42,m5MfkiT7oUDbvHI43ByeY9FP,nWZlLE9jkg8U40evFoOuriGxtH1,rBRcWufVlKL0xEY,KJbsEUM9tZiV3DkC4rpcHqw52Qh,NZ4fvUkGE3AxJed9 = ANIMWHn51Sv9C
	Mrch2HElwVNnm9siDCkZIKFbYL6ao7(xW2Arao7YVOemw(u"ࠬࡹࡴࡢࡴࡷࠫ༁"))
	if jHevARrF7lS.getSetting(UTelCo0ihE1d5R(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬ༂")) not in [SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠧࡂࡗࡗࡓࠬ༃"),LiRcTVUWuth70DmPy(u"ࠨࡕࡗࡓࡕ࠭༄"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪ༅")]:
		jHevARrF7lS.setSetting(fprnld4CZo(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡨࡵࡶࡳࡧࡦࡩࡨࡦࠩ༆"),dshJSmRqeiP9nap2(u"ࠫࡆ࡛ࡔࡐࠩ༇"))
	if not jHevARrF7lS.getSetting(lc0dpSmwoPDjLnk(u"ࠬࡧࡶ࠯ࡦࡱࡷࠬ༈")): jHevARrF7lS.setSetting(SO94xq1RAkMm2uF(u"࠭ࡡࡷ࠰ࡧࡲࡸ࠭༉"),vNFPbXVJ7pmyWLen[S4SOKF2QbBhjCd3RrVMuHIzE(u"࠴ᖞ")])
	zpXG3Ky6ou8ndWHkb4 = keBlY04RjHEnpLPAbXaG(uI7UAQCyPO85aLonkGqrdWwRt,cpH6YnUzMk9A,mHejXxkvM1qCESPVRy54QB,xUmyzZKOd8hv3Jc5X2nPHCAarW4sF,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,fH8bDPV6AceuCFNO0Ert7oq3p,stpvYViqku3,LGdFZQvKeU52s6H0DgjN)
	if G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ༊") in fH8bDPV6AceuCFNO0Ert7oq3p: ONgqycFoxi = iRoLg2m47tnDATBHGCSPNyx(u"ࡘࡷࡻࡥឫ")
	if uI7UAQCyPO85aLonkGqrdWwRt==bUdr5Hahw6sY8xJ(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ་"):
		if m5MfkiT7oUDbvHI43ByeY9FP!=SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠩ࠱࠲ࠬ༌") and nWZlLE9jkg8U40evFoOuriGxtH1: BejcHLrmkn9()
		if cmBCkqS7vLYD3flwZ>-hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠶ᖟ"):
			csuzj4Wlfpowi93xv = [hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠶ᖧ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"࠱࠶ᖡ"),yA5z6LIXBlo41PRVMY87wOisFp(u"࠲࠹ᖢ"),E6MIKdpBomef(u"࠳࠼ᖣ"),lc0dpSmwoPDjLnk(u"࠸࠶ᖠ"),fprnld4CZo(u"࠸࠺ᖦ"),g4g6bfkPtVGU5lIM3(u"࠸࠴ᖤ"),p72fnFtcPix5UKwr9YNzW(u"࠹࠸ᖥ")]
			if (P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,E6MIKdpBomef(u"ࠪ࡭ࡳࡺࠧ།"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ༎"),dshJSmRqeiP9nap2(u"࡙ࠬࡉࡕࡇࡖࡣࡓࡇࡍࡆࡕࠪ༏")) or dMiPQHejCTElLJuDz6oN5tR8Y not in csuzj4Wlfpowi93xv) and not bkHiCyWXjdgvF9xE1DA6wQ48(FvNyZqaLKw(u"࠭ࡃࡕࡇ࠼ࡈࡘ࠷࠹ࡗࡗ࠳࡚ࡘ࡞ࠧ༐")):
				from Fnbs0VJKLu import uy1vkLaIKUcm7dZM5poi
				XXvYorzsNbUPBCtn289 = knXiBdhtmFIQGD(uy1vkLaIKUcm7dZM5poi)
				aEQ5huZL1XtRAUrHsMp6Dfz3K = DsdoW9FXPpMkiLAlnrN2Tv3Gb17(gzlMwcJ8GTRbLjtQr3pXsACPYmqK42,XXvYorzsNbUPBCtn289,Tr8iRxJmbcEhftU5DSHzA,ONgqycFoxi,PK3YifFT0nxcUa)
				if XXvYorzsNbUPBCtn289 and rBRcWufVlKL0xEY:
					Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,xW2Arao7YVOemw(u"ࠧࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭༑")+KJbsEUM9tZiV3DkC4rpcHqw52Qh+hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨࡡࠪ༒")+NZ4fvUkGE3AxJed9,gzlMwcJ8GTRbLjtQr3pXsACPYmqK42,XXvYorzsNbUPBCtn289,Oa8xvPtmLZkBA43K0EzrdhXS)
			else:
				XL4sA9FNebx30oE.addDirectoryItem(cmBCkqS7vLYD3flwZ,sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ༓")+ssZLBRtgnMkc7dSouQeGCx3r8m+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡰ࡮ࡴ࡫ࠧ࡯ࡲࡨࡪࡃ࠵࠱࠲ࠪ༔"),zz2LJUB9kjnZqAeH.ListItem(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"้ࠫี๊ไุ่่๊ࠢษࠡ็้ࠤัํวำๅࠪ༕")))
				XL4sA9FNebx30oE.addDirectoryItem(cmBCkqS7vLYD3flwZ,fprnld4CZo(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ༖")+ssZLBRtgnMkc7dSouQeGCx3r8m+p72fnFtcPix5UKwr9YNzW(u"࠭࠯ࡀࡶࡼࡴࡪࡃ࡬ࡪࡰ࡮ࠪࡲࡵࡤࡦ࠿࠸࠴࠵࠭༗"),zz2LJUB9kjnZqAeH.ListItem(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧฤใอั๊ࠥสใำฦࠤฬ๊สโษุ๎้༘࠭")))
			XL4sA9FNebx30oE.endOfDirectory(cmBCkqS7vLYD3flwZ,Tr8iRxJmbcEhftU5DSHzA,ONgqycFoxi,PK3YifFT0nxcUa)
	return
def o05ntqDmjf3OZBLgNlckQH(wQOJ6X70PxA3NUbG1BCgjHmp):
	nOXwycEfBDuAhUL5 = QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࡌࡡ࡭ࡵࡨឭ") if wQOJ6X70PxA3NUbG1BCgjHmp else fprnld4CZo(u"࡙ࡸࡵࡦឬ")
	if not nOXwycEfBDuAhUL5:
		aedLQNn2UwGkbsXJF = YrGtRdILOunPs8Zv(jHevARrF7lS.getSetting(FvNyZqaLKw(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴ༙ࠩ")))
		aedLQNn2UwGkbsXJF = iRoLg2m47tnDATBHGCSPNyx(u"࠰ᖨ") if not aedLQNn2UwGkbsXJF else int(aedLQNn2UwGkbsXJF)
		if not aedLQNn2UwGkbsXJF or not iUeoLOsbHqP(u"࠱ᖩ")<=MMHpSTojGILfZXWeCOPyn4-aedLQNn2UwGkbsXJF<=wQOJ6X70PxA3NUbG1BCgjHmp: nOXwycEfBDuAhUL5 = S4SOKF2QbBhjCd3RrVMuHIzE(u"ࡔࡳࡷࡨឮ")
	if not nOXwycEfBDuAhUL5:
		OOzQidLV3qycRBMSK = jHevARrF7lS.getSetting(SO94xq1RAkMm2uF(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ༚"))
		if OOzQidLV3qycRBMSK in [xW2Arao7YVOemw(u"ࠪࠫ༛"),E6MIKdpBomef(u"ࠫࡔࡒࡄࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪ༜"),xW2Arao7YVOemw(u"ࠬࡔࡅࡘࡡࡗࡓࡤࡋࡒࡓࡑࡕࠫ༝")]: nOXwycEfBDuAhUL5 = sTcr7iDp5eFt4RoLMhuwq1A(u"ࡕࡴࡸࡩឯ")
	if not nOXwycEfBDuAhUL5:
		from hashlib import md5 as iWY9OsI5lM6tuDA2RfhmqkPdBQv
		pdwfWq5X3DSrxO46tjRZPmN = jHevARrF7lS.getSetting(lc0dpSmwoPDjLnk(u"࠭ࡡࡷ࠰ࡳࡶ࡮ࡼࡳ࠲ࠩ༞"))
		IhN5eYtOzbjqS6EJF = jHevARrF7lS.getSetting(kEhAHvti6Vnsfx(u"ࠧࡢࡸ࠱ࡴࡷ࡯ࡶࡴ࠴ࠪ༟"))
		wnOokC21GQf3apHSgZAJP = iWY9OsI5lM6tuDA2RfhmqkPdBQv(kEhAHvti6Vnsfx(u"࠷ᖪ")*pdwfWq5X3DSrxO46tjRZPmN.encode(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࡷࡷࡪ࠽࠭༠"))).hexdigest()
		wnOokC21GQf3apHSgZAJP = iWY9OsI5lM6tuDA2RfhmqkPdBQv(FnBiAjthS8MkXs67W(u"࠴࠸ᖫ")*wnOokC21GQf3apHSgZAJP.encode(lc0dpSmwoPDjLnk(u"ࠩࡸࡸ࡫࠾ࠧ༡"))).hexdigest()
		wnOokC21GQf3apHSgZAJP = iWY9OsI5lM6tuDA2RfhmqkPdBQv(wRxoKs10Syj7V4edYhtP(u"࠵࠾ᖬ")*wnOokC21GQf3apHSgZAJP.encode(lc0dpSmwoPDjLnk(u"ࠪࡹࡹ࡬࠸ࠨ༢"))).hexdigest()
		if wnOokC21GQf3apHSgZAJP!=IhN5eYtOzbjqS6EJF: nOXwycEfBDuAhUL5 = dshJSmRqeiP9nap2(u"ࡖࡵࡹࡪឰ")
	if nOXwycEfBDuAhUL5: aZi5pERcgnxeh9BJDwXNky = WiBcHvkRCKfFns3YMhIyAZ16TD8x4O(p72fnFtcPix5UKwr9YNzW(u"ࡉࡥࡱࡹࡥឱ"))
	return
def keBlY04RjHEnpLPAbXaG(uI7UAQCyPO85aLonkGqrdWwRt,PPVuQkU9OfiBXegYZK2c3Tl6,mHejXxkvM1qCESPVRy54QB,xUmyzZKOd8hv3Jc5X2nPHCAarW4sF,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,fH8bDPV6AceuCFNO0Ert7oq3p,stpvYViqku3,LGdFZQvKeU52s6H0DgjN):
	dMiPQHejCTElLJuDz6oN5tR8Y = int(xUmyzZKOd8hv3Jc5X2nPHCAarW4sF)
	XjUwdKaTHutRF0MgYkiWpZI = int(dMiPQHejCTElLJuDz6oN5tR8Y//FnBiAjthS8MkXs67W(u"࠶࠶ᖭ"))
	if   XjUwdKaTHutRF0MgYkiWpZI==p72fnFtcPix5UKwr9YNzW(u"࠶ᖮ"):  from WWXqeaw1TE 		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==UTelCo0ihE1d5R(u"࠱ᖯ"):  from OKoIU8yQVZ 		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠳ᖰ"):  from nDT6wjrmfZ 			import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==xW2Arao7YVOemw(u"࠵ᖱ"):  from WZhjNqHtoG 			import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠷ᖲ"):  from WWIBDvHyP1 		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif XjUwdKaTHutRF0MgYkiWpZI==hBvsQ7oCkKUdwjx58ml3EN(u"࠹ᖳ"):  from xAPpLOj9eR 		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠻ᖴ"):  from mmIsO43ncr 		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==FvNyZqaLKw(u"࠽ᖵ"):  from iz81jLCMhR 			import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==bUdr5Hahw6sY8xJ(u"࠸ᖶ"):  from osBuzptTmE 		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==dshJSmRqeiP9nap2(u"࠺ᖷ"):  from Bdqka8SHjO		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==FnBiAjthS8MkXs67W(u"࠳࠳ᖸ"): from yO89JhAsH3 		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB)
	elif XjUwdKaTHutRF0MgYkiWpZI==G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠴࠵ᖹ"): from w9VNKsZ824 		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==UTelCo0ihE1d5R(u"࠵࠷ᖺ"): from VyYaji521x 		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==Cu1704YofAbr3QTm(u"࠶࠹ᖻ"): from QQn6S7xVUk		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==g4g6bfkPtVGU5lIM3(u"࠷࠴ᖼ"): from bbPAtUuTEM 		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p,uI7UAQCyPO85aLonkGqrdWwRt,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,PPVuQkU9OfiBXegYZK2c3Tl6,nWO8c3IgspK67QX)
	elif XjUwdKaTHutRF0MgYkiWpZI==YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠱࠶ᖽ"): from WWXqeaw1TE 		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠲࠸ᖾ"): from tyc9EdgfWn		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,LGdFZQvKeU52s6H0DgjN)
	elif XjUwdKaTHutRF0MgYkiWpZI==kEhAHvti6Vnsfx(u"࠳࠺ᖿ"): from WWXqeaw1TE 		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠴࠼ᗀ"): from hRls8FI2xT		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==hBvsQ7oCkKUdwjx58ml3EN(u"࠵࠾ᗁ"): from WWXqeaw1TE 		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==XzrqbGDIy54juixkMA(u"࠷࠶ᗂ"): from o2qO4LFMIN		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==bUdr5Hahw6sY8xJ(u"࠸࠱ᗃ"): from GG9wPnAJvh	import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==dshJSmRqeiP9nap2(u"࠲࠳ᗄ"): from IqESvwXPi0		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==xW2Arao7YVOemw(u"࠳࠵ᗅ"): from NYPKIqVcep			import hSlFxp6vyaE0tRqWBfKcn; zpXG3Ky6ou8ndWHkb4 = hSlFxp6vyaE0tRqWBfKcn(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p,uI7UAQCyPO85aLonkGqrdWwRt,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,LGdFZQvKeU52s6H0DgjN)
	elif XjUwdKaTHutRF0MgYkiWpZI==dshJSmRqeiP9nap2(u"࠴࠷ᗆ"): from AjTX6bWUoJ 			import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==Me28A1sBLNIgUp5YCDyvT(u"࠵࠹ᗇ"): from C7tunkvS8i 		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==LiRcTVUWuth70DmPy(u"࠶࠻ᗈ"): from Fnbs0VJKLu 			import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==zqdvcbP5L8BHh(u"࠷࠽ᗉ"): from ILG9YzDbKk		import hSlFxp6vyaE0tRqWBfKcn; zpXG3Ky6ou8ndWHkb4 = hSlFxp6vyaE0tRqWBfKcn(dMiPQHejCTElLJuDz6oN5tR8Y,stpvYViqku3)
	elif XjUwdKaTHutRF0MgYkiWpZI==fprnld4CZo(u"࠸࠸ᗊ"): from NYPKIqVcep			import hSlFxp6vyaE0tRqWBfKcn; zpXG3Ky6ou8ndWHkb4 = hSlFxp6vyaE0tRqWBfKcn(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p,uI7UAQCyPO85aLonkGqrdWwRt,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,LGdFZQvKeU52s6H0DgjN)
	elif XjUwdKaTHutRF0MgYkiWpZI==p72fnFtcPix5UKwr9YNzW(u"࠲࠺ᗋ"): from YLZXgHuiOk	import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==hBvsQ7oCkKUdwjx58ml3EN(u"࠴࠲ᗌ"): from QTLlPojE20		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==fprnld4CZo(u"࠵࠴ᗍ"): from hhB3tk7gso		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==hBvsQ7oCkKUdwjx58ml3EN(u"࠶࠶ᗎ"): from YYS1QvjNMR		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠷࠸ᗏ"): from TP0fzV8GMW		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB)
	elif XjUwdKaTHutRF0MgYkiWpZI==FvNyZqaLKw(u"࠸࠺ᗐ"): from WWXqeaw1TE 		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==FnBiAjthS8MkXs67W(u"࠹࠵ᗑ"): from nnTPxkzGRH		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==g4g6bfkPtVGU5lIM3(u"࠳࠷ᗒ"): from vIufSK5zHr			import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠴࠹ᗓ"): from PJsSdvbghy			import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠵࠻ᗔ"): from rrSL6nj91X 		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==LiRcTVUWuth70DmPy(u"࠶࠽ᗕ"): from SY3eVzk80i		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==SO94xq1RAkMm2uF(u"࠸࠵ᗖ"): from Xswr3uEckt	import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p,uI7UAQCyPO85aLonkGqrdWwRt,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif XjUwdKaTHutRF0MgYkiWpZI==oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠹࠷ᗗ"): from Xswr3uEckt	import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p,uI7UAQCyPO85aLonkGqrdWwRt,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif XjUwdKaTHutRF0MgYkiWpZI==XzrqbGDIy54juixkMA(u"࠺࠲ᗘ"): from Zb7u6XoB1m			import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==Cu1704YofAbr3QTm(u"࠴࠴ᗙ"): from X89TQqW1jf			import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠵࠶ᗚ"): from SfphHN5F3P		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==wRxoKs10Syj7V4edYhtP(u"࠶࠸ᗛ"): from zDNcRtVHBL		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==fprnld4CZo(u"࠷࠺ᗜ"): from PMfc9b4vXp			import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==Me28A1sBLNIgUp5YCDyvT(u"࠸࠼ᗝ"): from EZ9Ka24UCG		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==iUeoLOsbHqP(u"࠹࠾ᗞ"): from qqBmVUYNIA		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==Me28A1sBLNIgUp5YCDyvT(u"࠺࠹ᗟ"): from SlK7x3yAYL		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==g4g6bfkPtVGU5lIM3(u"࠵࠱ᗠ"): from WWXqeaw1TE 		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==Me28A1sBLNIgUp5YCDyvT(u"࠶࠳ᗡ"): from ha8zvuEnlJ 		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==zqdvcbP5L8BHh(u"࠷࠵ᗢ"): from ha8zvuEnlJ 		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==zqdvcbP5L8BHh(u"࠸࠷ᗣ"): from Fnbs0VJKLu 			import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==xW2Arao7YVOemw(u"࠹࠹ᗤ"): from oIN2YpnkJd	import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif XjUwdKaTHutRF0MgYkiWpZI==G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠺࠻ᗥ"): from SMNu2OETbA 		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==lc0dpSmwoPDjLnk(u"࠻࠶ᗦ"): from u2dxD1WamQ			import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==bUdr5Hahw6sY8xJ(u"࠵࠸ᗧ"): from hGZraoJ5gw		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==UTelCo0ihE1d5R(u"࠶࠺ᗨ"): from IlFb1Es0RA		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==XzrqbGDIy54juixkMA(u"࠷࠼ᗩ"): from gmyxR0jwhs		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠹࠴ᗪ"): from Lrye5NGadx			import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==S4SOKF2QbBhjCd3RrVMuHIzE(u"࠺࠶ᗫ"): from gW3mOQLz82			import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==hBvsQ7oCkKUdwjx58ml3EN(u"࠻࠸ᗬ"): from OOzxvVlGPU		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==yA5z6LIXBlo41PRVMY87wOisFp(u"࠼࠳ᗭ"): from a4G1IBfRoh	import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==Cu1704YofAbr3QTm(u"࠶࠵ᗮ"): from dJr4nDP9y3			import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==fprnld4CZo(u"࠷࠷ᗯ"): from VDGS2iTPuv			import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==xW2Arao7YVOemw(u"࠸࠹ᗰ"): from VtjyB7kOJX			import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==dshJSmRqeiP9nap2(u"࠹࠻ᗱ"): from pCYXWusGUJ		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==XzrqbGDIy54juixkMA(u"࠺࠽ᗲ"): from dAoCHcYhxv		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==S4SOKF2QbBhjCd3RrVMuHIzE(u"࠻࠿ᗳ"): from yJmzXcP5Fd		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠽࠰ᗴ"): from jTaZm2rxMp			import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠷࠲ᗵ"): from v8alOxSpJN			import hSlFxp6vyaE0tRqWBfKcn; zpXG3Ky6ou8ndWHkb4 = hSlFxp6vyaE0tRqWBfKcn(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p,uI7UAQCyPO85aLonkGqrdWwRt,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,LGdFZQvKeU52s6H0DgjN)
	elif XjUwdKaTHutRF0MgYkiWpZI==oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠸࠴ᗶ"): from v8alOxSpJN			import hSlFxp6vyaE0tRqWBfKcn; zpXG3Ky6ou8ndWHkb4 = hSlFxp6vyaE0tRqWBfKcn(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p,uI7UAQCyPO85aLonkGqrdWwRt,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,LGdFZQvKeU52s6H0DgjN)
	elif XjUwdKaTHutRF0MgYkiWpZI==kEhAHvti6Vnsfx(u"࠹࠶ᗷ"): from keQl9V61Cf	import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==fprnld4CZo(u"࠺࠸ᗸ"): from Y3uMOTvosK		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y)
	elif XjUwdKaTHutRF0MgYkiWpZI==p72fnFtcPix5UKwr9YNzW(u"࠻࠺ᗹ"): from Y3uMOTvosK		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y)
	elif XjUwdKaTHutRF0MgYkiWpZI==XzrqbGDIy54juixkMA(u"࠼࠼ᗺ"): from tyc9EdgfWn		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,LGdFZQvKeU52s6H0DgjN)
	elif XjUwdKaTHutRF0MgYkiWpZI==dshJSmRqeiP9nap2(u"࠽࠷ᗻ"): from MgAYQOR7aP 		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==S4SOKF2QbBhjCd3RrVMuHIzE(u"࠷࠹ᗼ"): from JuQmsf04rW 		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==fprnld4CZo(u"࠸࠻ᗽ"): from TNlZLgj9Gt 		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==XzrqbGDIy54juixkMA(u"࠺࠳ᗾ"): from glPzHI7LEe 		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==S4SOKF2QbBhjCd3RrVMuHIzE(u"࠻࠵ᗿ"): from fo7FzwInQ0 		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,fH8bDPV6AceuCFNO0Ert7oq3p)
	elif XjUwdKaTHutRF0MgYkiWpZI==p72fnFtcPix5UKwr9YNzW(u"࠼࠷ᘀ"): from flQ5A7tGE3		import p6G19bDsiCPfK4NwjZ3xrRHLqzV	; zpXG3Ky6ou8ndWHkb4 = p6G19bDsiCPfK4NwjZ3xrRHLqzV(dMiPQHejCTElLJuDz6oN5tR8Y,mHejXxkvM1qCESPVRy54QB,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,fH8bDPV6AceuCFNO0Ert7oq3p)
	else: zpXG3Ky6ou8ndWHkb4 = None
	return zpXG3Ky6ou8ndWHkb4
def I9zaUCksnTt0rXj7OQuoJyfwKgL(llhyFWpP90RSDQM,r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6,hayXA4TiLlPxcVSIoK2,showDialogs):
	iiFQATmrePSj = jHevARrF7lS.getSetting(hBvsQ7oCkKUdwjx58ml3EN(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬ༣"))
	jHevARrF7lS.setSetting(FnBiAjthS8MkXs67W(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭༤"),fprnld4CZo(u"࠭ࠧ༥"))
	if fprnld4CZo(u"ࠧ࠮ࠩ༦") in hayXA4TiLlPxcVSIoK2: jXPWwl4aH0OR9ILzMT5usS = hayXA4TiLlPxcVSIoK2.split(hBvsQ7oCkKUdwjx58ml3EN(u"ࠨ࠯ࠪ༧"),hBvsQ7oCkKUdwjx58ml3EN(u"࠶ᘁ"))[hBvsQ7oCkKUdwjx58ml3EN(u"࠶ᘂ")]
	else: jXPWwl4aH0OR9ILzMT5usS = hayXA4TiLlPxcVSIoK2
	HKA0Z47wi9WoptPQkme3hc6bXYu2 = llhyFWpP90RSDQM in [p72fnFtcPix5UKwr9YNzW(u"࠺ᘆ"),iRoLg2m47tnDATBHGCSPNyx(u"࠲࠳࠳࠴࠶ᘄ"),Cu1704YofAbr3QTm(u"࠱࠲࠲࠳࠶ᘃ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠳࠳࠴࠺࠺ᘅ")]
	QWxKd5pgGhesB = r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6.lower()
	HqBkA0rQ2Gya1h69U5Rjc4YiVDWFxO = llhyFWpP90RSDQM in [S4SOKF2QbBhjCd3RrVMuHIzE(u"࠴ᘇ"),FvNyZqaLKw(u"࠱࠱࠶ᘊ"),zqdvcbP5L8BHh(u"࠶࠶࠰࠷࠳ᘈ"),iRoLg2m47tnDATBHGCSPNyx(u"࠷࠱࠲ᘉ")]
	nFpcy5Je8qLx4QPYSGKHo = S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠪ༨") in QWxKd5pgGhesB
	xxNAHM3f1uG7LSyhOBVW8Y25eFvsEJ = XzrqbGDIy54juixkMA(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠ࠶ࠢࡶࡩࡨࡵ࡮ࡥࡵࠣࡦࡷࡵࡷࡴࡧࡵࠤࡨ࡮ࡥࡤ࡭ࠪ༩") in QWxKd5pgGhesB
	WEocxCQmRJiBsNK2S86MPgj1eOHZY4 = G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡴࡨࡧࡦࡶࡴࡤࡪࡤࠫ༪") in QWxKd5pgGhesB
	OhwuRCsxb9ZBqJPo1ENfQ57mcd2 = YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪࠦࡳࡦࡥࡸࡶ࡮ࡺࡹࠡࡥ࡫ࡩࡨࡱࠧ༫") in QWxKd5pgGhesB
	JdBcwGztPqOm6g = jHevARrF7lS.getSetting(XzrqbGDIy54juixkMA(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫ༬"))
	vEVCdcZuawPG6R4qDY = jHevARrF7lS.getSetting(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪ༭"))
	TTtsulFZ5mdPcBA39eEJ7M2NYz = QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠨใื่ࠥ็๊ࠡีะฬࠥอไึใะอ๋ࠥๆࠡษ็ษ๋ะั็ฬࠪ༮")
	IOdzG25nRxPFVtAs7j43forWpCy9m = FvNyZqaLKw(u"ࠩࡈࡶࡷࡵࡲࠡࠩ༯")+str(llhyFWpP90RSDQM)+S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠪ࠾ࠥ࠭༰")+r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6
	IOdzG25nRxPFVtAs7j43forWpCy9m = GhPlajzTxY8(IOdzG25nRxPFVtAs7j43forWpCy9m)
	if HqBkA0rQ2Gya1h69U5Rjc4YiVDWFxO or nFpcy5Je8qLx4QPYSGKHo or xxNAHM3f1uG7LSyhOBVW8Y25eFvsEJ or WEocxCQmRJiBsNK2S86MPgj1eOHZY4 or OhwuRCsxb9ZBqJPo1ENfQ57mcd2:
		TTtsulFZ5mdPcBA39eEJ7M2NYz += G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࠥ࠴ࠠศๆ่์็฿ࠠโ์๊ࠤาาศุࠡาࠤ่๎ฯู๋่ࠢิื็ࠡษ็ษ๋ะั็ฬࠣห้ิวึࠢห็ࠥษ่ࠡสส่๊๎โฺ࡞ࡱࠫ༱")
	if HKA0Z47wi9WoptPQkme3hc6bXYu2: TTtsulFZ5mdPcBA39eEJ7M2NYz += oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠬࠦ࠮ࠡๆา๎่ࠦฮุลࠣࡈࡓ้࡙ࠠ็฼๊ฬํࠠห฻ำีࠥะัอ็ฬࠤฬูๅࠡษ็้ํู่ࠡว็ํࠥืโๆ้࡟ࡲࠬ༲")
	IOdzG25nRxPFVtAs7j43forWpCy9m = fprnld4CZo(u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ༳")+IOdzG25nRxPFVtAs7j43forWpCy9m+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ༴")
	if JdBcwGztPqOm6g==SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࡃࡖࡏ༵ࠬ") or vEVCdcZuawPG6R4qDY==xW2Arao7YVOemw(u"ࠩࡄࡗࡐ࠭༶"):
		TTtsulFZ5mdPcBA39eEJ7M2NYz += FnBiAjthS8MkXs67W(u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝่ๆࠣฮึ๐ฯࠡล้ࠤ๏ำว้ๆࠣห้ฮั็ษ่ะࠥหีๅษะࠤฬ๊ๅีๅ็อࠥ࠴࠮ࠡล่ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠฤ๊ࠣา฼ษࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥลࠡࠢ࡝࠲ࡇࡔࡒࡏࡓ࡟༷ࠪ")
	rXe7KCkT4IqHE9 = Cu1704YofAbr3QTm(u"ࡊࡦࡲࡳࡦឲ")
	if showDialogs and hayXA4TiLlPxcVSIoK2 not in cqyx3WnkJKH2TIA:
		if JdBcwGztPqOm6g==G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࡆ࡙ࡋࠨ༸") or vEVCdcZuawPG6R4qDY==wRxoKs10Syj7V4edYhtP(u"ࠬࡇࡓࡌ༹ࠩ"):
			r54fQALYmUbegM7yxsNc = CCQOct8zmrKMuP6ZEkxq7oaf1BeRv(kEhAHvti6Vnsfx(u"࠭ࡣࡦࡰࡷࡩࡷ࠭༺"),Cu1704YofAbr3QTm(u"ࠧฯำ๋ะࠬ༻"),iUeoLOsbHqP(u"ࠨวิืฬ๊ࠠๅๆ่ฬึ๋ฬࠨ༼"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩศู้ออࠡษ็ู้้ไสࠩ༽"),jXPWwl4aH0OR9ILzMT5usS+UTelCo0ihE1d5R(u"ࠪࠤࠥࠦࠧ༾")+wPGkbaD7x6(jXPWwl4aH0OR9ILzMT5usS),TTtsulFZ5mdPcBA39eEJ7M2NYz+hBvsQ7oCkKUdwjx58ml3EN(u"ࠫࡡࡴࠧ༿")+IOdzG25nRxPFVtAs7j43forWpCy9m)
			if r54fQALYmUbegM7yxsNc==SO94xq1RAkMm2uF(u"࠲ᘋ"):
				from WWXqeaw1TE import eimszEapSbIurqvN3c5hk4VylDCH
				eimszEapSbIurqvN3c5hk4VylDCH()
			elif r54fQALYmUbegM7yxsNc==g4g6bfkPtVGU5lIM3(u"࠴ᘌ"): rXe7KCkT4IqHE9 = fprnld4CZo(u"࡙ࡸࡵࡦឳ")
		else: aHKzv76JCVnprbY8w(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬ࠭ཀ"),E6MIKdpBomef(u"࠭ࠧཁ"),jXPWwl4aH0OR9ILzMT5usS+fprnld4CZo(u"ࠧࠡࠢࠣࠫག")+wPGkbaD7x6(jXPWwl4aH0OR9ILzMT5usS),TTtsulFZ5mdPcBA39eEJ7M2NYz,IOdzG25nRxPFVtAs7j43forWpCy9m)
	jHevARrF7lS.setSetting(hBvsQ7oCkKUdwjx58ml3EN(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩགྷ"),iiFQATmrePSj)
	return rXe7KCkT4IqHE9
def GcIxLR5v8p1YAleW2jkEu7nZqg(XiZUd80tOc5FBKuQbIM7wfRqh=FnBiAjthS8MkXs67W(u"ࡌࡡ࡭ࡵࡨ឴"),ZWFCfg4GJiOSuvRlzK=[]):
	Ekj0Z1u4QRr53KIDHepWv = [J2M15kw7Rdv0rQZxITaNuXeyWc,PGIWHNLQuRoK1M]+ZWFCfg4GJiOSuvRlzK
	for TQ7XxCh6E4quszI1cornewB in WpgZTyqoMAPhwGiXF.listdir(JXUQZHLxEgTFbrRC7n9):
		if XiZUd80tOc5FBKuQbIM7wfRqh and (TQ7XxCh6E4quszI1cornewB.startswith(XzrqbGDIy54juixkMA(u"ࠩ࡬ࡴࡹࡼࠧང")) or TQ7XxCh6E4quszI1cornewB.startswith(hBvsQ7oCkKUdwjx58ml3EN(u"ࠪࡱ࠸ࡻࠧཅ"))): continue
		if TQ7XxCh6E4quszI1cornewB.startswith(Cu1704YofAbr3QTm(u"ࠫ࡫࡯࡬ࡦࡡࠪཆ")): continue
		p3pZ9cnBKlI56gMTUzy = WpgZTyqoMAPhwGiXF.path.join(JXUQZHLxEgTFbrRC7n9,TQ7XxCh6E4quszI1cornewB)
		if p3pZ9cnBKlI56gMTUzy in Ekj0Z1u4QRr53KIDHepWv: continue
		try: WpgZTyqoMAPhwGiXF.remove(p3pZ9cnBKlI56gMTUzy)
		except: pass
	if YYyD6xzmsKbBTkrqEC not in Ekj0Z1u4QRr53KIDHepWv: OOy4gzCqrV382ctPa(YYyD6xzmsKbBTkrqEC,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࡕࡴࡸࡩា"),LiRcTVUWuth70DmPy(u"ࡆࡢ࡮ࡶࡩ឵"))
	MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(E6MIKdpBomef(u"࠴ᘍ"))
	return
def dozj6ZLu1rKa(PsKN47RHYGF9yD,vYFXP48WV6M,mHejXxkvM1qCESPVRy54QB,rKagANTOtGJnhVWfE2BHpePYC3IQ5l,ep9JAOkj1wr5s,hXWtlI25BjAiN6ESe1ka79dc8PsGD,showDialogs,hayXA4TiLlPxcVSIoK2,GPBaUzVhdpyO6xkJD2=iUeoLOsbHqP(u"ࡖࡵࡹࡪិ"),t8x23UOsYmr9IDik06pG=iUeoLOsbHqP(u"ࡖࡵࡹࡪិ")):
	mHejXxkvM1qCESPVRy54QB = mHejXxkvM1qCESPVRy54QB+hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬཇ")+PsKN47RHYGF9yD
	YutQm2AwozR9VKp4O1lWj8FaryI = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,vYFXP48WV6M,mHejXxkvM1qCESPVRy54QB,rKagANTOtGJnhVWfE2BHpePYC3IQ5l,ep9JAOkj1wr5s,hXWtlI25BjAiN6ESe1ka79dc8PsGD,showDialogs,hayXA4TiLlPxcVSIoK2,GPBaUzVhdpyO6xkJD2,t8x23UOsYmr9IDik06pG)
	if mHejXxkvM1qCESPVRy54QB in YutQm2AwozR9VKp4O1lWj8FaryI.content: YutQm2AwozR9VKp4O1lWj8FaryI.succeeded = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࡉࡥࡱࡹࡥី")
	if not YutQm2AwozR9VKp4O1lWj8FaryI.succeeded:
		zrIWmJZh2CpVf8(UTelCo0ihE1d5R(u"࠭ࡈࡕࡖࡓࠤࡗ࡫ࡱࡶࡧࡶࡸࠥࡌࡡࡪ࡮ࡸࡶࡪ࠭཈"))
	return YutQm2AwozR9VKp4O1lWj8FaryI
def SSW92eU4a5OvDpPJHmFufRLo3wB(mHejXxkvM1qCESPVRy54QB):
	YutQm2AwozR9VKp4O1lWj8FaryI = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧࡈࡇࡗࠫཉ"),mHejXxkvM1qCESPVRy54QB,SO94xq1RAkMm2uF(u"ࠨࠩཊ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠩࠪཋ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"࡙ࡸࡵࡦឺ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠪࠫཌ"),FvNyZqaLKw(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡕࡡࡓࡖࡔ࡞ࡉࡆࡕࡢࡐࡎ࡙ࡔ࠮࠳ࡶࡸࠬཌྷ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"࡙ࡸࡵࡦឺ"),p72fnFtcPix5UKwr9YNzW(u"ࡊࡦࡲࡳࡦឹ"))
	Riz4EhLeKrIJltyBcV = []
	if YutQm2AwozR9VKp4O1lWj8FaryI.succeeded:
		U9rSWyc74gLOw = YutQm2AwozR9VKp4O1lWj8FaryI.content
		b46wo32JTUQClOgsrimhKADuG5v0x = GGvHJKP9LUxEk10Fw.findall(fprnld4CZo(u"ࠬࠦࠨ࠯ࠬࡂ࠭ࠥࡢࡤࡼ࠳࠯࠷ࢂࡳࡳࠨཎ"),U9rSWyc74gLOw)
		if b46wo32JTUQClOgsrimhKADuG5v0x: U9rSWyc74gLOw = FnBiAjthS8MkXs67W(u"࠭࡜࡯ࠩཏ").join(b46wo32JTUQClOgsrimhKADuG5v0x)
		m5rkWnXjq9bQiR4 = U9rSWyc74gLOw.replace(dshJSmRqeiP9nap2(u"ࠧ࡝ࡴࠪཐ"),SO94xq1RAkMm2uF(u"ࠨࠩད")).strip(iUeoLOsbHqP(u"ࠩ࡟ࡲࠬདྷ")).split(SO94xq1RAkMm2uF(u"ࠪࡠࡳ࠭ན"))
		Riz4EhLeKrIJltyBcV = []
		for PsKN47RHYGF9yD in m5rkWnXjq9bQiR4:
			if PsKN47RHYGF9yD.count(SO94xq1RAkMm2uF(u"ࠫ࠳࠭པ"))==p72fnFtcPix5UKwr9YNzW(u"࠷ᘎ"): Riz4EhLeKrIJltyBcV.append(PsKN47RHYGF9yD)
	return Riz4EhLeKrIJltyBcV
def dNR0xvuSyG4tWkieDslfYawc(*aargs):
	E9dXP6q5nzWG0cgiNFMoB = xW2Arao7YVOemw(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡱ࡫࠱ࡴࡷࡵࡸࡺࡵࡦࡶࡦࡶࡥ࠯ࡥࡲࡱ࠴ࡼ࠲࠰ࡁࡵࡩࡶࡻࡥࡴࡶࡀࡨ࡮ࡹࡰ࡭ࡣࡼࡴࡷࡵࡸࡪࡧࡶࠪࡵࡸ࡯ࡹࡻࡷࡽࡵ࡫࠽ࡩࡶࡷࡴࠫࡺࡩ࡮ࡧࡲࡹࡹࡃ࠱࠱࠲࠳࠴ࠫࡹࡳ࡭࠿ࡼࡩࡸࠬ࡬ࡪ࡯࡬ࡸࡂ࠷࠰ࠧࡥࡲࡹࡳࡺࡲࡺ࠿ࡑࡐ࠱ࡈࡅ࠭ࡆࡈ࠰ࡋࡘࠬࡈࡄ࠯ࡘࡗ࠭ཕ")
	p32gVNifSQPMJrj = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡳࡣࡺ࠲࡬࡯ࡴࡩࡷࡥࡹࡸ࡫ࡲࡤࡱࡱࡸࡪࡴࡴ࠯ࡥࡲࡱ࠴ࡸ࡯ࡰࡵࡷࡩࡷࡱࡩࡥ࠱ࡲࡴࡪࡴࡰࡳࡱࡻࡽࡱ࡯ࡳࡵ࠱ࡰࡥ࡮ࡴ࠯ࡉࡖࡗࡔࡘ࠴ࡴࡹࡶࠪབ")
	oK8cPAvpUVQa572eCN3lM1t4fHEuSJ = SSW92eU4a5OvDpPJHmFufRLo3wB(p32gVNifSQPMJrj)
	Riz4EhLeKrIJltyBcV = SSW92eU4a5OvDpPJHmFufRLo3wB(E9dXP6q5nzWG0cgiNFMoB)
	fLX58FC0lPxpySiAtmB = oK8cPAvpUVQa572eCN3lM1t4fHEuSJ+Riz4EhLeKrIJltyBcV
	LOHZ4o9m7p6ebfTYXGIdz5PWs3q(xW2Arao7YVOemw(u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭བྷ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+SO94xq1RAkMm2uF(u"ࠨࠢࠣࠤࡌࡵࡴࠡࡲࡵࡳࡽ࡯ࡥࡴࠢ࡯࡭ࡸࡺࠠࠡࠢ࠴ࡷࡹ࠱࠲࡯ࡦ࠽ࠤࡠࠦࠧམ")+str(len(oK8cPAvpUVQa572eCN3lM1t4fHEuSJ))+SO94xq1RAkMm2uF(u"ࠩ࠮ࠫཙ")+str(len(Riz4EhLeKrIJltyBcV))+hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪࠤࡢ࠭ཚ"))
	PsKN47RHYGF9yD = jHevARrF7lS.getSetting(fprnld4CZo(u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴࡬ࡢࡵࡷࠫཛ"))
	YutQm2AwozR9VKp4O1lWj8FaryI = dMPXkHuB87WsyEUNGQ6IeY()
	jHevARrF7lS.setSetting(FvNyZqaLKw(u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮࡭ࡣࡶࡸࠬཛྷ"),FnBiAjthS8MkXs67W(u"࠭ࠧཝ"))
	if PsKN47RHYGF9yD or fLX58FC0lPxpySiAtmB:
		ESIi4D0MAgOCWT3Rwobfq5Yh,I26dXLNboZt7ie = xW2Arao7YVOemw(u"࠵ᘏ"),FvNyZqaLKw(u"࠷࠰ᘐ")
		eeK45i16aqJXk7cxE2GC = len(fLX58FC0lPxpySiAtmB)
		VqMiAURNP6D4cousvlZKFa7 = I26dXLNboZt7ie
		if eeK45i16aqJXk7cxE2GC>VqMiAURNP6D4cousvlZKFa7: iDadeoH2YB10XPCMQNInxug9Fsr = VqMiAURNP6D4cousvlZKFa7
		else: iDadeoH2YB10XPCMQNInxug9Fsr = eeK45i16aqJXk7cxE2GC
		fk7GAmCNcoZ3ixYJb0q2DHM5e = Y7pXj2OtNq9GZdvmcTkS3hMJn.sample(fLX58FC0lPxpySiAtmB,iDadeoH2YB10XPCMQNInxug9Fsr)
		if PsKN47RHYGF9yD: fk7GAmCNcoZ3ixYJb0q2DHM5e = [PsKN47RHYGF9yD]+fk7GAmCNcoZ3ixYJb0q2DHM5e
		Bz3JlWSoCPtADGHQh = eWia5rknYzHm0J(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࡌࡡ࡭ࡵࡨុ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࡌࡡ࡭ࡵࡨុ"))
		LCaAcrp8R57YSD = MQbODJoPV2w8TEAg4zXZdjLxSW.time()
		while MQbODJoPV2w8TEAg4zXZdjLxSW.time()-LCaAcrp8R57YSD<=I26dXLNboZt7ie and not Bz3JlWSoCPtADGHQh.finishedLIST:
			if ESIi4D0MAgOCWT3Rwobfq5Yh<iDadeoH2YB10XPCMQNInxug9Fsr:
				PsKN47RHYGF9yD = fk7GAmCNcoZ3ixYJb0q2DHM5e[ESIi4D0MAgOCWT3Rwobfq5Yh]
				Bz3JlWSoCPtADGHQh.IISJUtB5zhnRuCp39(ESIi4D0MAgOCWT3Rwobfq5Yh,dozj6ZLu1rKa,PsKN47RHYGF9yD,*aargs)
			MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(SO94xq1RAkMm2uF(u"࠰࠯࠹࠸ᘑ"))
			ESIi4D0MAgOCWT3Rwobfq5Yh += hBvsQ7oCkKUdwjx58ml3EN(u"࠲ᘒ")
			LOHZ4o9m7p6ebfTYXGIdz5PWs3q(iRoLg2m47tnDATBHGCSPNyx(u"ࠧࡏࡑࡗࡍࡈࡋࠧཞ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+LiRcTVUWuth70DmPy(u"ࠨࠢࠣࠤ࡙ࡸࡹࡪࡰࡪ࠾ࠥࠦࠠࡑࡴࡲࡼࡾࡀࠠ࡜ࠢࠪཟ")+PsKN47RHYGF9yD+bUdr5Hahw6sY8xJ(u"ࠩࠣࡡࠬའ"))
		finishedLIST = Bz3JlWSoCPtADGHQh.finishedLIST
		if finishedLIST:
			resultsDICT = Bz3JlWSoCPtADGHQh.resultsDICT
			RQJdDXBxlsHWIY1oCEKgfmG2n = finishedLIST[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠲ᘓ")]
			YutQm2AwozR9VKp4O1lWj8FaryI = resultsDICT[RQJdDXBxlsHWIY1oCEKgfmG2n]
			PsKN47RHYGF9yD = fk7GAmCNcoZ3ixYJb0q2DHM5e[int(RQJdDXBxlsHWIY1oCEKgfmG2n)]
			jHevARrF7lS.setSetting(xW2Arao7YVOemw(u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡲࡡࡴࡶࠪཡ"),PsKN47RHYGF9yD)
			if RQJdDXBxlsHWIY1oCEKgfmG2n!=QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠳ᘔ"): LOHZ4o9m7p6ebfTYXGIdz5PWs3q(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪར"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+LiRcTVUWuth70DmPy(u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࠤࠥࡖࡲࡰࡺࡼ࠾ࠥࡡࠠࠨལ")+PsKN47RHYGF9yD+kEhAHvti6Vnsfx(u"࠭ࠠ࡞ࠩཤ"))
			else: LOHZ4o9m7p6ebfTYXGIdz5PWs3q(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭ཥ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+lc0dpSmwoPDjLnk(u"ࠨࠢࠣࠤࡘࡻࡣࡤࡧࡶࡷ࠿ࠦࠠࠡࡕࡤࡺࡪࡪࠠࡱࡴࡲࡼࡾࡀࠠ࡜ࠢࠪས")+PsKN47RHYGF9yD+Cu1704YofAbr3QTm(u"ࠩࠣࡡࠬཧ"))
	return YutQm2AwozR9VKp4O1lWj8FaryI
def ZCeV0YOWPsjg7RtH(fqRpnCHvNOz48e6,gc1t0hHWKiG5Uxb2s):
	V8Ev9npKcoL2mB1 = fqRpnCHvNOz48e6.create_connection
	def ikPNp08gFusEW4(mQokTZW3UFxws7H0MBY,*aargs,**kkwargs):
		WK59LPt30k6OEVm,QCndJmNEhwPe4qVba5 = mQokTZW3UFxws7H0MBY
		ip = CsaYzHKkqN4Dy10lV6XnSZbWhQ(WK59LPt30k6OEVm,gc1t0hHWKiG5Uxb2s)
		if ip: WK59LPt30k6OEVm = ip[zqdvcbP5L8BHh(u"࠴ᘕ")]
		else:
			if gc1t0hHWKiG5Uxb2s in vNFPbXVJ7pmyWLen: vNFPbXVJ7pmyWLen.remove(gc1t0hHWKiG5Uxb2s)
			if vNFPbXVJ7pmyWLen:
				OOF3BHNEU08gM5p7SuwQhrPj2CG4 = vNFPbXVJ7pmyWLen[Me28A1sBLNIgUp5YCDyvT(u"࠵ᘖ")]
				ip = CsaYzHKkqN4Dy10lV6XnSZbWhQ(WK59LPt30k6OEVm,OOF3BHNEU08gM5p7SuwQhrPj2CG4)
				if ip: WK59LPt30k6OEVm = ip[g4g6bfkPtVGU5lIM3(u"࠶ᘗ")]
		mQokTZW3UFxws7H0MBY = (WK59LPt30k6OEVm,QCndJmNEhwPe4qVba5)
		return V8Ev9npKcoL2mB1(mQokTZW3UFxws7H0MBY,*aargs,**kkwargs)
	fqRpnCHvNOz48e6.create_connection = ikPNp08gFusEW4
	return V8Ev9npKcoL2mB1
def zz4RnLCWwBTHrJ5vmXk(mHejXxkvM1qCESPVRy54QB):
	LLBI1HmfYhJw,BB3yloLsGP6t = mHejXxkvM1qCESPVRy54QB.split(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪ࠳ࠬཨ"))[hBvsQ7oCkKUdwjx58ml3EN(u"࠳ᘙ")],iRoLg2m47tnDATBHGCSPNyx(u"࠸࠱ᘘ")
	if iUeoLOsbHqP(u"ࠫ࠿࠭ཀྵ") in LLBI1HmfYhJw: LLBI1HmfYhJw,BB3yloLsGP6t = LLBI1HmfYhJw.split(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬࡀࠧཪ"))
	w2nU7ylvhuOqbWP = XzrqbGDIy54juixkMA(u"࠭࠯ࠨཫ")+kEhAHvti6Vnsfx(u"ࠧ࠰ࠩཬ").join(mHejXxkvM1qCESPVRy54QB.split(zqdvcbP5L8BHh(u"ࠨ࠱ࠪ཭"))[hBvsQ7oCkKUdwjx58ml3EN(u"࠵ᘚ"):])
	hD6se2E307NcI = G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩࡊࡉ࡙ࠦࠧ཮")+w2nU7ylvhuOqbWP+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࠤࡍ࡚ࡔࡑ࠱࠴࠲࠶ࡢࡲ࡝ࡰࠪ཯")
	hD6se2E307NcI += bUdr5Hahw6sY8xJ(u"ࠫࡍࡵࡳࡵ࠼ࠣࠫ཰")+LLBI1HmfYhJw+hBvsQ7oCkKUdwjx58ml3EN(u"ࠬࡢࡲ࡝ࡰཱࠪ")
	hD6se2E307NcI += G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠭࡜ࡳ࡞ࡱིࠫ")
	from socket import socket as PWX8Cboc6iE0KOgafZ9jMw1pG,AF_INET as F8gpvxURGVTJ0eH,SOCK_STREAM as K8Q9rSind42b
	try:
		k2kmhUOIVF4Xq3rCjyS0 = PWX8Cboc6iE0KOgafZ9jMw1pG(F8gpvxURGVTJ0eH,K8Q9rSind42b)
		k2kmhUOIVF4Xq3rCjyS0.connect((LLBI1HmfYhJw,BB3yloLsGP6t))
		k2kmhUOIVF4Xq3rCjyS0.send(hD6se2E307NcI.encode(E6MIKdpBomef(u"ࠧࡶࡶࡩ࠼ཱིࠬ")))
		bb5BhEKwTxCfH8FOrPM70Dv3 = k2kmhUOIVF4Xq3rCjyS0.recv(kEhAHvti6Vnsfx(u"࠸࠵࠿࠶ᘜ")*SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠴࠴࠷࠺ᘛ"))
		U9rSWyc74gLOw = repr(bb5BhEKwTxCfH8FOrPM70Dv3)
	except: U9rSWyc74gLOw = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨུࠩ")
	return U9rSWyc74gLOw
def RfKuIXwPAiWtmyF(vjXKalCNU4sS0G5eZr76VdPwgBm,uI7UAQCyPO85aLonkGqrdWwRt):
	if LiRcTVUWuth70DmPy(u"ࠩ࠱ཱུࠫ") not in vjXKalCNU4sS0G5eZr76VdPwgBm: return vjXKalCNU4sS0G5eZr76VdPwgBm
	vjXKalCNU4sS0G5eZr76VdPwgBm = vjXKalCNU4sS0G5eZr76VdPwgBm+UTelCo0ihE1d5R(u"ࠪ࠳ࠬྲྀ")
	n2WLxOpHN5YZQAslebPfm93KyC,XWjaStYqEHM5yDIQGw9UFb1N2f = vjXKalCNU4sS0G5eZr76VdPwgBm.split(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫ࠳࠭ཷ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠶ᘝ"))
	t91BGYi5m4gJlkFEONpSVXh0xLUTjM,y3s6tjkqT2d7Ez4MU = XWjaStYqEHM5yDIQGw9UFb1N2f.split(SO94xq1RAkMm2uF(u"ࠬ࠵ࠧླྀ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠷ᘞ"))
	VLDy4EIJqvpHauK0nMes9 = n2WLxOpHN5YZQAslebPfm93KyC+g4g6bfkPtVGU5lIM3(u"࠭࠮ࠨཹ")+t91BGYi5m4gJlkFEONpSVXh0xLUTjM
	if uI7UAQCyPO85aLonkGqrdWwRt in [fprnld4CZo(u"ࠧࡩࡱࡶࡸེࠬ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨࡰࡤࡱࡪཻ࠭")] and zqdvcbP5L8BHh(u"ࠩ࠲ོࠫ") in VLDy4EIJqvpHauK0nMes9: VLDy4EIJqvpHauK0nMes9 = VLDy4EIJqvpHauK0nMes9.rsplit(xW2Arao7YVOemw(u"ࠪ࠳ཽࠬ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠱ᘟ"))[hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠱ᘟ")]
	if uI7UAQCyPO85aLonkGqrdWwRt==LiRcTVUWuth70DmPy(u"ࠫࡳࡧ࡭ࡦࠩཾ") and dshJSmRqeiP9nap2(u"ࠬ࠴ࠧཿ") in VLDy4EIJqvpHauK0nMes9:
		Y70svecS23DnI8oBhFAR = VLDy4EIJqvpHauK0nMes9.split(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠭࠮ࠨྀ"))
		EFfqeBcwy8xLPgk1M0Izao = len(Y70svecS23DnI8oBhFAR)
		if EFfqeBcwy8xLPgk1M0Izao<=QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠴ᘡ") or UTelCo0ihE1d5R(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲཱྀࠬ") in VLDy4EIJqvpHauK0nMes9: Y70svecS23DnI8oBhFAR = Y70svecS23DnI8oBhFAR[bUdr5Hahw6sY8xJ(u"࠱ᘠ")]
		elif EFfqeBcwy8xLPgk1M0Izao>=hBvsQ7oCkKUdwjx58ml3EN(u"࠷ᘣ"): Y70svecS23DnI8oBhFAR = Y70svecS23DnI8oBhFAR[dshJSmRqeiP9nap2(u"࠴ᘢ")]
		if len(Y70svecS23DnI8oBhFAR)>fprnld4CZo(u"࠶ᘤ"): VLDy4EIJqvpHauK0nMes9 = Y70svecS23DnI8oBhFAR
	return VLDy4EIJqvpHauK0nMes9
def FEaio7MR2CjTJ9ZLVQnhNewgpv(ww2jqr0uZUVaX5M7D98):
	kNx9HE7YybShuWImMP2Z3cFt14BQ = repr(ww2jqr0uZUVaX5M7D98.encode(E6MIKdpBomef(u"ࠨࡷࡷࡪ࠽࠭ྂ"))).replace(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠤࠪࠦྃ"),SO94xq1RAkMm2uF(u"྄ࠪࠫ"))
	return kNx9HE7YybShuWImMP2Z3cFt14BQ
def e2N6JK0pzXdA4By(WpgxA1dwQPKoczytMNSRv9E):
	McpNFZ4ife276DjKlHgsqtyRv = dshJSmRqeiP9nap2(u"ࠫࠬ྅")
	if HHosl5fRdhtEDAYyP: WpgxA1dwQPKoczytMNSRv9E = WpgxA1dwQPKoczytMNSRv9E.decode(hBvsQ7oCkKUdwjx58ml3EN(u"ࠬࡻࡴࡧ࠺ࠪ྆"))
	from unicodedata import decomposition as UUwES5TPIlixcmnDKFJpyQ
	for OU28MfXSVaCBQY7d0 in WpgxA1dwQPKoczytMNSRv9E:
		if   OU28MfXSVaCBQY7d0==kEhAHvti6Vnsfx(u"ࡻࠧรࠩ྇"): LH52McR7pCQDleOZX4GST8a9KP3 = hBvsQ7oCkKUdwjx58ml3EN(u"ࠧ࡝࡞ࡸ࠴࠻࠸࠲ࠨྈ")
		elif OU28MfXSVaCBQY7d0==fprnld4CZo(u"ࡶࠩฦࠫྉ"): LH52McR7pCQDleOZX4GST8a9KP3 = g4g6bfkPtVGU5lIM3(u"ࠩ࡟ࡠࡺ࠶࠶࠳࠵ࠪྊ")
		elif OU28MfXSVaCBQY7d0==hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࡸࠫษ࠭ྋ"): LH52McR7pCQDleOZX4GST8a9KP3 = p72fnFtcPix5UKwr9YNzW(u"ࠫࡡࡢࡵ࠱࠸࠵࠸ࠬྌ")
		elif OU28MfXSVaCBQY7d0==oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࡺ࠭ลࠨྍ"): LH52McR7pCQDleOZX4GST8a9KP3 = sTcr7iDp5eFt4RoLMhuwq1A(u"࠭࡜࡝ࡷ࠳࠺࠷࠻ࠧྎ")
		elif OU28MfXSVaCBQY7d0==xW2Arao7YVOemw(u"ࡵࠨศࠪྏ"): LH52McR7pCQDleOZX4GST8a9KP3 = zqdvcbP5L8BHh(u"ࠨ࡞࡟ࡹ࠵࠼࠲࠷ࠩྐ")
		else:
			pxQwmz153rfqA7ybaFTPW = UUwES5TPIlixcmnDKFJpyQ(OU28MfXSVaCBQY7d0)
			if l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠩࠣࠫྑ") in pxQwmz153rfqA7ybaFTPW: LH52McR7pCQDleOZX4GST8a9KP3 = sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࡠࡡࡻࠧྒ")+pxQwmz153rfqA7ybaFTPW.split(iRoLg2m47tnDATBHGCSPNyx(u"ࠫࠥ࠭ྒྷ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠷ᘥ"))[l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠷ᘥ")]
			else:
				LH52McR7pCQDleOZX4GST8a9KP3 = yA5z6LIXBlo41PRVMY87wOisFp(u"ࠬ࠶࠰࠱࠲ࠪྔ")+hex(ord(OU28MfXSVaCBQY7d0)).replace(iUeoLOsbHqP(u"࠭࠰ࡹࠩྕ"),FnBiAjthS8MkXs67W(u"ࠧࠨྖ"))
				LH52McR7pCQDleOZX4GST8a9KP3 = lc0dpSmwoPDjLnk(u"ࠨ࡞࡟ࡹࠬྗ")+LH52McR7pCQDleOZX4GST8a9KP3[-yA5z6LIXBlo41PRVMY87wOisFp(u"࠴ᘦ"):]
		McpNFZ4ife276DjKlHgsqtyRv += LH52McR7pCQDleOZX4GST8a9KP3
	McpNFZ4ife276DjKlHgsqtyRv = McpNFZ4ife276DjKlHgsqtyRv.replace(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩ࡟ࡠࡺ࠶࠶ࡄࡅࠪ྘"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࡠࡡࡻ࠰࠷࠶࠼ࠫྙ"))
	if HHosl5fRdhtEDAYyP: McpNFZ4ife276DjKlHgsqtyRv = McpNFZ4ife276DjKlHgsqtyRv.decode(p72fnFtcPix5UKwr9YNzW(u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬྚ")).encode(E6MIKdpBomef(u"ࠬࡻࡴࡧ࠺ࠪྛ"))
	else: McpNFZ4ife276DjKlHgsqtyRv = McpNFZ4ife276DjKlHgsqtyRv.encode(wRxoKs10Syj7V4edYhtP(u"࠭ࡵࡵࡨ࠻ࠫྜ")).decode(Cu1704YofAbr3QTm(u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨྜྷ"))
	return McpNFZ4ife276DjKlHgsqtyRv
def yMRXZIpKxlSkaE6iCO(header=UTelCo0ihE1d5R(u"ࠨๆ๋ัฮࠦวๅ็ไหฯ๐อࠨྞ"),P5RNJYaomg7=Me28A1sBLNIgUp5YCDyvT(u"ࠩࠪྟ"),q4IaJTjdP6H=bUdr5Hahw6sY8xJ(u"ࡆࡢ࡮ࡶࡩូ"),source=dshJSmRqeiP9nap2(u"ࠪࠫྠ")):
	fH8bDPV6AceuCFNO0Ert7oq3p = NdJbnTW2X5ZfaDE6Hqwe(header,P5RNJYaomg7,type=zz2LJUB9kjnZqAeH.INPUT_ALPHANUM)
	fH8bDPV6AceuCFNO0Ert7oq3p = fH8bDPV6AceuCFNO0Ert7oq3p.replace(LiRcTVUWuth70DmPy(u"ࠫࠥࠦࠧྡ"),FvNyZqaLKw(u"ࠬࠦࠧྡྷ")).replace(zqdvcbP5L8BHh(u"࠭ࠠࠡࠩྣ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࠡࠩྤ")).replace(UTelCo0ihE1d5R(u"ࠨࠢࠣࠫྥ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩࠣࠫྦ"))
	if not fH8bDPV6AceuCFNO0Ert7oq3p and not q4IaJTjdP6H:
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q(p72fnFtcPix5UKwr9YNzW(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪྦྷ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫ࠳ࠦࠠࡌࡧࡼࡦࡴࡧࡲࡥࠢࡨࡲࡹࡸࡹࠡࡥࡤࡲࡨ࡫࡬ࡦࡦ࠽ࠤࠥࠦࠢࠨྨ")+fH8bDPV6AceuCFNO0Ert7oq3p+LiRcTVUWuth70DmPy(u"ࠬࠨࠧྩ"))
		aHKzv76JCVnprbY8w(UTelCo0ihE1d5R(u"࠭ࠧྪ"),fprnld4CZo(u"ࠧࠨྫ"),kEhAHvti6Vnsfx(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫྫྷ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊ละะส่ࠬྭ"))
		return Cu1704YofAbr3QTm(u"ࠪࠫྮ")
	if fH8bDPV6AceuCFNO0Ert7oq3p not in [S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࠬྯ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠬࠦࠧྰ")]:
		fH8bDPV6AceuCFNO0Ert7oq3p = fH8bDPV6AceuCFNO0Ert7oq3p.strip(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ࠠࠨྱ"))
		fH8bDPV6AceuCFNO0Ert7oq3p = e2N6JK0pzXdA4By(fH8bDPV6AceuCFNO0Ert7oq3p)
	if source!=xW2Arao7YVOemw(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔࠩྲ") and hNCJPTucIV7GOSR0HytZ6eQrqEUpw(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠨࡍࡈ࡝ࡇࡕࡁࡓࡆࠪླ"),UTelCo0ihE1d5R(u"ࠩࠪྴ"),[fH8bDPV6AceuCFNO0Ert7oq3p],oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࡇࡣ࡯ࡷࡪួ")):
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪྵ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫ࠳ࠦࠠࡌࡧࡼࡦࡴࡧࡲࡥࠢࡨࡲࡹࡸࡹࠡࡤ࡯ࡳࡨࡱࡥࡥ࠼ࠣࠤࠥࠨࠧྶ")+fH8bDPV6AceuCFNO0Ert7oq3p+iUeoLOsbHqP(u"ࠬࠨࠧྷ"))
		aHKzv76JCVnprbY8w(SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࠧྸ"),Me28A1sBLNIgUp5YCDyvT(u"ࠧࠨྐྵ"),fprnld4CZo(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫྺ"),xW2Arao7YVOemw(u"ࠩส๊ฯࠦใหสอࠤ่๊ๅสࠢฦ์ࠥืโๆࠢ็๋ࠥ฿ไศไฬࠤอษแๅษ่ࠤ้๊ใษษิࠤๆ่ืࠡ࠰࠱ࠤํํะศࠢส่อืๆศ็ฯࠤ้อ๋ࠠี่ัࠥฮวิฬัำฬ๋่ࠠๅำห้ࠥไๆษอࠫྻ"))
		return UTelCo0ihE1d5R(u"ࠪࠫྼ")
	LOHZ4o9m7p6ebfTYXGIdz5PWs3q(iRoLg2m47tnDATBHGCSPNyx(u"ࠫࡓࡕࡔࡊࡅࡈࠫ྽"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠬ࠴ࠠࠡࡍࡨࡽࡧࡵࡡࡳࡦࠣࡩࡳࡺࡲࡺࠢࡤࡰࡱࡵࡷࡦࡦ࠽ࠤࠥࠦࠢࠨ྾")+fH8bDPV6AceuCFNO0Ert7oq3p+Me28A1sBLNIgUp5YCDyvT(u"࠭ࠢࠨ྿"))
	return fH8bDPV6AceuCFNO0Ert7oq3p
def BXEJoygQHA8RZ(dR2vHyAtl8pJN1,BBYvCiQGe8RdpyAagfS72mZclxb5={}):
	mHejXxkvM1qCESPVRy54QB,TK8z2EXwL1pcxB,hTCIe9pGxs,ee9EWXY43swBPHhmqNOQi = dR2vHyAtl8pJN1,{},{},pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧࠨ࿀")
	if FvNyZqaLKw(u"ࠨࡾࠪ࿁") in dR2vHyAtl8pJN1: mHejXxkvM1qCESPVRy54QB,TK8z2EXwL1pcxB = xlk0nsAXjIrvOQFL4Vi1MJG5TChu(dR2vHyAtl8pJN1,lc0dpSmwoPDjLnk(u"ࠩࡿࠫ࿂"))
	LwIn0D67dbS3lB = list(set(list(BBYvCiQGe8RdpyAagfS72mZclxb5.keys())+list(TK8z2EXwL1pcxB.keys())))
	for EptZi8qnKhHSsuWMg5URx6FIkP in LwIn0D67dbS3lB:
		if EptZi8qnKhHSsuWMg5URx6FIkP in list(TK8z2EXwL1pcxB.keys()): hTCIe9pGxs[EptZi8qnKhHSsuWMg5URx6FIkP] = TK8z2EXwL1pcxB[EptZi8qnKhHSsuWMg5URx6FIkP]
		else: hTCIe9pGxs[EptZi8qnKhHSsuWMg5URx6FIkP] = BBYvCiQGe8RdpyAagfS72mZclxb5[EptZi8qnKhHSsuWMg5URx6FIkP]
	if p72fnFtcPix5UKwr9YNzW(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ࿃") not in LwIn0D67dbS3lB: hTCIe9pGxs[hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ࿄")] = Y8Y6b7aLSUKjdE1Ae()
	if lc0dpSmwoPDjLnk(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭࿅") not in LwIn0D67dbS3lB: hTCIe9pGxs[E6MIKdpBomef(u"࠭ࡒࡦࡨࡨࡶࡪࡸ࿆ࠧ")] = RfKuIXwPAiWtmyF(mHejXxkvM1qCESPVRy54QB,bUdr5Hahw6sY8xJ(u"ࠧࡶࡴ࡯ࠫ࿇"))
	if FnBiAjthS8MkXs67W(u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡎࡤࡲ࡬ࡻࡡࡨࡧࠪ࿈") not in LwIn0D67dbS3lB: hTCIe9pGxs[fprnld4CZo(u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡏࡥࡳ࡭ࡵࡢࡩࡨࠫ࿉")] = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࡩࡳ࠳ࡕࡔ࠮ࡨࡲࡀࡷ࠽࠱࠰࠼ࠫ࿊")
	for EptZi8qnKhHSsuWMg5URx6FIkP in list(hTCIe9pGxs.keys()): ee9EWXY43swBPHhmqNOQi += p72fnFtcPix5UKwr9YNzW(u"ࠫࠫ࠭࿋")+EptZi8qnKhHSsuWMg5URx6FIkP+p72fnFtcPix5UKwr9YNzW(u"ࠬࡃࠧ࿌")+hTCIe9pGxs[EptZi8qnKhHSsuWMg5URx6FIkP]
	if ee9EWXY43swBPHhmqNOQi: ee9EWXY43swBPHhmqNOQi = fprnld4CZo(u"࠭ࡼࠨ࿍")+ee9EWXY43swBPHhmqNOQi[S4SOKF2QbBhjCd3RrVMuHIzE(u"࠲ᘧ"):]
	YutQm2AwozR9VKp4O1lWj8FaryI = bxUSPZNcXgLKGuFlenmkh2OCd6oa(X9mvsOYNPGeWdaIw01Mf4Jz5p,oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧࡈࡇࡗࠫ࿎"),mHejXxkvM1qCESPVRy54QB,g4g6bfkPtVGU5lIM3(u"ࠨࠩ࿏"),hTCIe9pGxs,UTelCo0ihE1d5R(u"ࠩࠪ࿐"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠪࠫ࿑"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡕࡔࡄࡇ࡙ࡥࡍ࠴ࡗ࠻࠱࠶ࡹࡴࠨ࿒"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࡈࡤࡰࡸ࡫ើ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࡈࡤࡰࡸ࡫ើ"))
	U9rSWyc74gLOw = YutQm2AwozR9VKp4O1lWj8FaryI.content
	if zqdvcbP5L8BHh(u"࡙ࠬࡔࡓࡇࡄࡑ࠲ࡏࡎࡇࠩ࿓") not in U9rSWyc74gLOw: return [YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭࠭࠲ࠩ࿔")],[mHejXxkvM1qCESPVRy54QB+ee9EWXY43swBPHhmqNOQi]
	if g4g6bfkPtVGU5lIM3(u"ࠧࡕ࡛ࡓࡉࡂࡇࡕࡅࡋࡒࠫ࿕") in U9rSWyc74gLOw: return [zqdvcbP5L8BHh(u"ࠨ࠯࠴ࠫ࿖")],[mHejXxkvM1qCESPVRy54QB+ee9EWXY43swBPHhmqNOQi]
	if G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩࡗ࡝ࡕࡋ࠽ࡗࡋࡇࡉࡔ࠭࿗") in U9rSWyc74gLOw: return [xW2Arao7YVOemw(u"ࠪ࠱࠶࠭࿘")],[mHejXxkvM1qCESPVRy54QB+ee9EWXY43swBPHhmqNOQi]
	eyUmvNFiYsE,zzvBg3ShiamAZ,XfClp3FTeZLUIHQxSwmgvqV,yRK6nzFG7bamAjeEw913 = [],[],[],[]
	ExOjma9CSy2vQbPLhMUworYu = GGvHJKP9LUxEk10Fw.findall(bUdr5Hahw6sY8xJ(u"ࠫࠨࡋࡘࡕ࠯࡛࠱ࡘ࡚ࡒࡆࡃࡐ࠱ࡎࡔࡆ࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱ࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯ࠬ࿙"),U9rSWyc74gLOw+iRoLg2m47tnDATBHGCSPNyx(u"ࠬࡢ࡮ࠨ࿚"),GGvHJKP9LUxEk10Fw.DOTALL)
	if not ExOjma9CSy2vQbPLhMUworYu: return [zqdvcbP5L8BHh(u"࠭࠭࠲ࠩ࿛")],[mHejXxkvM1qCESPVRy54QB+ee9EWXY43swBPHhmqNOQi]
	for i94LpDNUzy,vjXKalCNU4sS0G5eZr76VdPwgBm in ExOjma9CSy2vQbPLhMUworYu:
		n5ndWC1IaE0,ttTAbmlyKH9Se,dDZQSEGRTo9g85x1C = {},-fprnld4CZo(u"࠳ᘨ"),-fprnld4CZo(u"࠳ᘨ")
		rA2I5DWRyNPqLi7klJUFZ43n = G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠧࠨ࿜")
		t17im2xFfVTW34jAauvlU9 = i94LpDNUzy.split(XzrqbGDIy54juixkMA(u"ࠨ࠮ࠪ࿝"))
		for fPpK27Cej9wqutr0 in t17im2xFfVTW34jAauvlU9:
			if xW2Arao7YVOemw(u"ࠩࡀࠫ࿞") in fPpK27Cej9wqutr0:
				EptZi8qnKhHSsuWMg5URx6FIkP,QXbBSpyH3qAEC = fPpK27Cej9wqutr0.split(g4g6bfkPtVGU5lIM3(u"ࠪࡁࠬ࿟"),dshJSmRqeiP9nap2(u"࠴ᘩ"))
				n5ndWC1IaE0[EptZi8qnKhHSsuWMg5URx6FIkP.lower()] = QXbBSpyH3qAEC
		if G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࡦࡼࡥࡳࡣࡪࡩ࠲ࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨࠨ࿠") in i94LpDNUzy.lower():
			ttTAbmlyKH9Se = int(n5ndWC1IaE0[lc0dpSmwoPDjLnk(u"ࠬࡧࡶࡦࡴࡤ࡫ࡪ࠳ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩ࿡")])//p72fnFtcPix5UKwr9YNzW(u"࠵࠵࠸࠴ᘪ")
			rA2I5DWRyNPqLi7klJUFZ43n += str(ttTAbmlyKH9Se)+hBvsQ7oCkKUdwjx58ml3EN(u"࠭࡫ࡣࡲࡶࠤࠥ࠭࿢")
		elif yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪ࿣") in i94LpDNUzy.lower():
			ttTAbmlyKH9Se = int(n5ndWC1IaE0[kEhAHvti6Vnsfx(u"ࠨࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫ࿤")])//p72fnFtcPix5UKwr9YNzW(u"࠶࠶࠲࠵ᘫ")
			rA2I5DWRyNPqLi7klJUFZ43n += str(ttTAbmlyKH9Se)+S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠩ࡮ࡦࡵࡹࠠࠡࠩ࿥")
		if fprnld4CZo(u"ࠪࡶࡪࡹ࡯࡭ࡷࡷ࡭ࡴࡴࠧ࿦") in i94LpDNUzy.lower():
			dDZQSEGRTo9g85x1C = int(n5ndWC1IaE0[yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫࡷ࡫ࡳࡰ࡮ࡸࡸ࡮ࡵ࡮ࠨ࿧")].split(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬࡾࠧ࿨"))[Cu1704YofAbr3QTm(u"࠷ᘬ")])
			rA2I5DWRyNPqLi7klJUFZ43n += str(dDZQSEGRTo9g85x1C)+yA5z6LIXBlo41PRVMY87wOisFp(u"࠭ࠠࠡࠩ࿩")
		rA2I5DWRyNPqLi7klJUFZ43n = rA2I5DWRyNPqLi7klJUFZ43n.strip(dshJSmRqeiP9nap2(u"ࠧࠡࠢࠪ࿪"))
		if not rA2I5DWRyNPqLi7klJUFZ43n: rA2I5DWRyNPqLi7klJUFZ43n = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩ࿫")
		if not vjXKalCNU4sS0G5eZr76VdPwgBm.startswith(FnBiAjthS8MkXs67W(u"ࠩ࡫ࡸࡹࡶࠧ࿬")):
			if vjXKalCNU4sS0G5eZr76VdPwgBm.startswith(g4g6bfkPtVGU5lIM3(u"ࠪ࠳࠴࠭࿭")): vjXKalCNU4sS0G5eZr76VdPwgBm = mHejXxkvM1qCESPVRy54QB.split(Me28A1sBLNIgUp5YCDyvT(u"ࠫ࠿࠭࿮"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠱ᘭ"))[hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠱ᘮ")]+FnBiAjthS8MkXs67W(u"ࠬࡀࠧ࿯")+vjXKalCNU4sS0G5eZr76VdPwgBm
			elif vjXKalCNU4sS0G5eZr76VdPwgBm.startswith(S4SOKF2QbBhjCd3RrVMuHIzE(u"࠭࠯ࠨ࿰")): vjXKalCNU4sS0G5eZr76VdPwgBm = RfKuIXwPAiWtmyF(mHejXxkvM1qCESPVRy54QB,sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࡶࡴ࡯ࠫ࿱"))+vjXKalCNU4sS0G5eZr76VdPwgBm
			else: vjXKalCNU4sS0G5eZr76VdPwgBm = mHejXxkvM1qCESPVRy54QB.rsplit(lc0dpSmwoPDjLnk(u"ࠨ࠱ࠪ࿲"),p72fnFtcPix5UKwr9YNzW(u"࠳ᘯ"))[p72fnFtcPix5UKwr9YNzW(u"࠳ᘰ")]+SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠩ࠲ࠫ࿳")+vjXKalCNU4sS0G5eZr76VdPwgBm
		if yA5z6LIXBlo41PRVMY87wOisFp(u"ࠪࡴࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥ࠮ࡷࡵ࡭ࠬ࿴") in list(n5ndWC1IaE0.keys()):
			E2EhMuOLdF08Pz75jDKS14cfYNxy = n5ndWC1IaE0[Me28A1sBLNIgUp5YCDyvT(u"ࠫࡵࡸ࡯ࡨࡴࡨࡷࡸ࡯ࡶࡦ࠯ࡸࡶ࡮࠭࿵")]
			E2EhMuOLdF08Pz75jDKS14cfYNxy = E2EhMuOLdF08Pz75jDKS14cfYNxy.replace(FvNyZqaLKw(u"ࠬࠨࠧ࿶"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࠧ࿷")).replace(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠢࠨࠤ࿸"),dshJSmRqeiP9nap2(u"ࠨࠩ࿹")).split(FvNyZqaLKw(u"ࠩࠦࠫ࿺"),XzrqbGDIy54juixkMA(u"࠵ᘱ"))[xW2Arao7YVOemw(u"࠵ᘲ")]
			QNHsaf7u3DSjiJ40ARCKYO = dd8rHcveo7O15hT3MSR(E2EhMuOLdF08Pz75jDKS14cfYNxy)
			if QNHsaf7u3DSjiJ40ARCKYO: qPmCp1Q4gRekdAH = rA2I5DWRyNPqLi7klJUFZ43n+dshJSmRqeiP9nap2(u"ࠪࠤࠥ࠭࿻")+QNHsaf7u3DSjiJ40ARCKYO
			else: qPmCp1Q4gRekdAH = rA2I5DWRyNPqLi7klJUFZ43n
			qPmCp1Q4gRekdAH = qPmCp1Q4gRekdAH+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫࠥࠦࡐࡳࡱࡪࡶࡪࡹࡳࡪࡸࡨࠫ࿼")
			qPmCp1Q4gRekdAH = qPmCp1Q4gRekdAH+dshJSmRqeiP9nap2(u"ࠬࠦࠠࠨ࿽")+RfKuIXwPAiWtmyF(E2EhMuOLdF08Pz75jDKS14cfYNxy,FvNyZqaLKw(u"࠭࡮ࡢ࡯ࡨࠫ࿾"))
			eyUmvNFiYsE.append(qPmCp1Q4gRekdAH)
			zzvBg3ShiamAZ.append(E2EhMuOLdF08Pz75jDKS14cfYNxy)
			XfClp3FTeZLUIHQxSwmgvqV.append(dDZQSEGRTo9g85x1C)
			yRK6nzFG7bamAjeEw913.append(ttTAbmlyKH9Se)
		vjXKalCNU4sS0G5eZr76VdPwgBm = vjXKalCNU4sS0G5eZr76VdPwgBm.split(p72fnFtcPix5UKwr9YNzW(u"ࠧࠤࠩ࿿"),p72fnFtcPix5UKwr9YNzW(u"࠷ᘳ"))[wRxoKs10Syj7V4edYhtP(u"࠰ᘴ")]
		QNHsaf7u3DSjiJ40ARCKYO = dd8rHcveo7O15hT3MSR(vjXKalCNU4sS0G5eZr76VdPwgBm)
		if QNHsaf7u3DSjiJ40ARCKYO: rA2I5DWRyNPqLi7klJUFZ43n = rA2I5DWRyNPqLi7klJUFZ43n+FvNyZqaLKw(u"ࠨࠢࠣࠫက")+QNHsaf7u3DSjiJ40ARCKYO
		rA2I5DWRyNPqLi7klJUFZ43n = rA2I5DWRyNPqLi7klJUFZ43n+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩࠣࠤࠬခ")+RfKuIXwPAiWtmyF(vjXKalCNU4sS0G5eZr76VdPwgBm,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠪࡲࡦࡳࡥࠨဂ"))
		eyUmvNFiYsE.append(rA2I5DWRyNPqLi7klJUFZ43n)
		zzvBg3ShiamAZ.append(vjXKalCNU4sS0G5eZr76VdPwgBm)
		XfClp3FTeZLUIHQxSwmgvqV.append(dDZQSEGRTo9g85x1C)
		yRK6nzFG7bamAjeEw913.append(ttTAbmlyKH9Se)
	iILrnWKwUhP6bf = list(zip(eyUmvNFiYsE,zzvBg3ShiamAZ,XfClp3FTeZLUIHQxSwmgvqV,yRK6nzFG7bamAjeEw913))
	iILrnWKwUhP6bf = sorted(iILrnWKwUhP6bf, reverse=wRxoKs10Syj7V4edYhtP(u"ࡗࡶࡺ࡫ឿ"), key=lambda key: key[iUeoLOsbHqP(u"࠴ᘵ")])
	eyUmvNFiYsE,zzvBg3ShiamAZ,XfClp3FTeZLUIHQxSwmgvqV,yRK6nzFG7bamAjeEw913 = list(zip(*iILrnWKwUhP6bf))
	eyUmvNFiYsE,zzvBg3ShiamAZ = list(eyUmvNFiYsE),list(zzvBg3ShiamAZ)
	gCitSRH90rUG5s72VIBcaMQv8qpf = []
	for vjXKalCNU4sS0G5eZr76VdPwgBm in zzvBg3ShiamAZ: gCitSRH90rUG5s72VIBcaMQv8qpf.append(vjXKalCNU4sS0G5eZr76VdPwgBm+ee9EWXY43swBPHhmqNOQi)
	return eyUmvNFiYsE,gCitSRH90rUG5s72VIBcaMQv8qpf
def CsaYzHKkqN4Dy10lV6XnSZbWhQ(WK59LPt30k6OEVm,gc1t0hHWKiG5Uxb2s=G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࠬဃ")):
	if not gc1t0hHWKiG5Uxb2s: gc1t0hHWKiG5Uxb2s = vNFPbXVJ7pmyWLen[g4g6bfkPtVGU5lIM3(u"࠲ᘶ")]
	if WK59LPt30k6OEVm.replace(zqdvcbP5L8BHh(u"ࠬ࠴ࠧင"),yA5z6LIXBlo41PRVMY87wOisFp(u"࠭ࠧစ")).isdigit(): return [WK59LPt30k6OEVm]
	from struct import pack as r8rChPpxDmYui1Kv,unpack_from as DDgX7OIlcSmaQLdFu
	from socket import socket as PWX8Cboc6iE0KOgafZ9jMw1pG,AF_INET as F8gpvxURGVTJ0eH,SOCK_DGRAM as SH0M3PhtRWuyoOagZG9Kv
	try:
		OOa2QSt4WlrcTDe = r8rChPpxDmYui1Kv(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠢ࠿ࡊࠥဆ"), g4g6bfkPtVGU5lIM3(u"࠴࠶࠵࠺࠹ᘷ"))
		OOa2QSt4WlrcTDe += r8rChPpxDmYui1Kv(dshJSmRqeiP9nap2(u"ࠣࡀࡋࠦဇ"), yA5z6LIXBlo41PRVMY87wOisFp(u"࠶࠺࠼ᘸ"))
		OOa2QSt4WlrcTDe += r8rChPpxDmYui1Kv(kEhAHvti6Vnsfx(u"ࠤࡁࡌࠧဈ"), hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠶ᘹ"))
		OOa2QSt4WlrcTDe += r8rChPpxDmYui1Kv(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠥࡂࡍࠨဉ"), SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠶ᘺ"))
		OOa2QSt4WlrcTDe += r8rChPpxDmYui1Kv(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠦࡃࡎࠢည"), YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠰ᘻ"))
		OOa2QSt4WlrcTDe += r8rChPpxDmYui1Kv(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧࡄࡈࠣဋ"), dshJSmRqeiP9nap2(u"࠱ᘼ"))
		if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: LnE6NkJITp2eAQ1KvzS8CGi = WK59LPt30k6OEVm.split(E6MIKdpBomef(u"࠭࠮ࠨဌ"))
		else: LnE6NkJITp2eAQ1KvzS8CGi = WK59LPt30k6OEVm.decode(Cu1704YofAbr3QTm(u"ࠧࡶࡶࡩ࠼ࠬဍ")).split(iRoLg2m47tnDATBHGCSPNyx(u"ࠨ࠰ࠪဎ"))
		for bbiz6OVqG5kajLe0M in LnE6NkJITp2eAQ1KvzS8CGi:
			WWkmY9jq7baZe5X0Hs = bbiz6OVqG5kajLe0M.encode(lc0dpSmwoPDjLnk(u"ࠩࡸࡸ࡫࠾ࠧဏ"))
			OOa2QSt4WlrcTDe += r8rChPpxDmYui1Kv(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠥࡆࠧတ"), len(bbiz6OVqG5kajLe0M))
			for df6AVUNQzmgs in bbiz6OVqG5kajLe0M:
				OOa2QSt4WlrcTDe += r8rChPpxDmYui1Kv(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠦࡨࠨထ"), df6AVUNQzmgs.encode(g4g6bfkPtVGU5lIM3(u"ࠬࡻࡴࡧ࠺ࠪဒ")))
		OOa2QSt4WlrcTDe += r8rChPpxDmYui1Kv(xW2Arao7YVOemw(u"ࠨࡂࠣဓ"), kEhAHvti6Vnsfx(u"࠲ᘽ"))
		OOa2QSt4WlrcTDe += r8rChPpxDmYui1Kv(dshJSmRqeiP9nap2(u"ࠢ࠿ࡊࠥန"), bUdr5Hahw6sY8xJ(u"࠴ᘾ"))
		OOa2QSt4WlrcTDe += r8rChPpxDmYui1Kv(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠣࡀࡋࠦပ"), UTelCo0ihE1d5R(u"࠵ᘿ"))
		M2I9wYxpkRe0 = PWX8Cboc6iE0KOgafZ9jMw1pG(F8gpvxURGVTJ0eH,SH0M3PhtRWuyoOagZG9Kv)
		M2I9wYxpkRe0.sendto(bytes(OOa2QSt4WlrcTDe), (gc1t0hHWKiG5Uxb2s, SO94xq1RAkMm2uF(u"࠺࠹ᙀ")))
		M2I9wYxpkRe0.settimeout(LiRcTVUWuth70DmPy(u"࠼ᙁ"))
		rKagANTOtGJnhVWfE2BHpePYC3IQ5l, c18pCRMLfevAZ4sjaNJoD = M2I9wYxpkRe0.recvfrom(zqdvcbP5L8BHh(u"࠱࠱࠴࠷ᙂ"))
		M2I9wYxpkRe0.close()
		vl5ukhiEcgS6nBDRGVaI3T = DDgX7OIlcSmaQLdFu(wRxoKs10Syj7V4edYhtP(u"ࠤࡁࡌࡍࡎࡈࡉࡊࠥဖ"), rKagANTOtGJnhVWfE2BHpePYC3IQ5l, LiRcTVUWuth70DmPy(u"࠱ᙃ"))
		l8lvMHIPtF = vl5ukhiEcgS6nBDRGVaI3T[yA5z6LIXBlo41PRVMY87wOisFp(u"࠵ᙄ")]
		qvEcXgSWrGkbB2f7t083uP6ijMw = len(WK59LPt30k6OEVm)+iUeoLOsbHqP(u"࠴࠼ᙅ")
		RuSqTgGZ7tlerwK9pWYf16Ln = []
		for _p6uWmHasLGMIVdjDlk7Z in range(l8lvMHIPtF):
			cnL9E74riAmVqyFbTPaK3SZXG = qvEcXgSWrGkbB2f7t083uP6ijMw
			OXPeEqnHfNAdr7Mh5RjcVTDBL0g6mo = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠵ᙆ")
			JByMbPh796 = YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࡊࡦࡲࡳࡦៀ")
			while Cu1704YofAbr3QTm(u"࡙ࡸࡵࡦេ"):
				df6AVUNQzmgs = DDgX7OIlcSmaQLdFu(zqdvcbP5L8BHh(u"ࠥࡂࡇࠨဗ"), rKagANTOtGJnhVWfE2BHpePYC3IQ5l, cnL9E74riAmVqyFbTPaK3SZXG)[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠵ᙇ")]
				if df6AVUNQzmgs == QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠶ᙈ"):
					cnL9E74riAmVqyFbTPaK3SZXG += SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠱ᙉ")
					break
				if df6AVUNQzmgs >= pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠲࠻࠵ᙊ"):
					euAPTXB7ZQOvHUNcLI4jCW = DDgX7OIlcSmaQLdFu(zqdvcbP5L8BHh(u"ࠦࡃࡈࠢဘ"), rKagANTOtGJnhVWfE2BHpePYC3IQ5l, cnL9E74riAmVqyFbTPaK3SZXG + E6MIKdpBomef(u"࠳ᙋ"))[Me28A1sBLNIgUp5YCDyvT(u"࠳ᙌ")]
					cnL9E74riAmVqyFbTPaK3SZXG = ((df6AVUNQzmgs << lc0dpSmwoPDjLnk(u"࠽ᙎ")) + euAPTXB7ZQOvHUNcLI4jCW - 0xc000) - FnBiAjthS8MkXs67W(u"࠵ᙍ")
					JByMbPh796 = SO94xq1RAkMm2uF(u"࡚ࡲࡶࡧែ")
				cnL9E74riAmVqyFbTPaK3SZXG += hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠷ᙏ")
				if JByMbPh796 == lc0dpSmwoPDjLnk(u"ࡆࡢ࡮ࡶࡩៃ"): OXPeEqnHfNAdr7Mh5RjcVTDBL0g6mo += sTcr7iDp5eFt4RoLMhuwq1A(u"࠱ᙐ")
			if JByMbPh796 == FnBiAjthS8MkXs67W(u"ࡕࡴࡸࡩោ"): OXPeEqnHfNAdr7Mh5RjcVTDBL0g6mo += oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠲ᙑ")
			qvEcXgSWrGkbB2f7t083uP6ijMw = qvEcXgSWrGkbB2f7t083uP6ijMw + OXPeEqnHfNAdr7Mh5RjcVTDBL0g6mo
			dwIW1pX9f2FaivgU = DDgX7OIlcSmaQLdFu(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠧࡄࡈࡉࡋࡋࠦမ"), rKagANTOtGJnhVWfE2BHpePYC3IQ5l, qvEcXgSWrGkbB2f7t083uP6ijMw)
			qvEcXgSWrGkbB2f7t083uP6ijMw = qvEcXgSWrGkbB2f7t083uP6ijMw + SO94xq1RAkMm2uF(u"࠳࠳ᙒ")
			W6WdK7xuyD9TUNMof1APF = dwIW1pX9f2FaivgU[Cu1704YofAbr3QTm(u"࠳ᙓ")]
			Cjm5snYRM2urQ8TPvcFoObeWqKaV = dwIW1pX9f2FaivgU[wRxoKs10Syj7V4edYhtP(u"࠷ᙔ")]
			if W6WdK7xuyD9TUNMof1APF == l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠶ᙕ"):
				PJA7lhq83ivVoHDejubG54CfI = DDgX7OIlcSmaQLdFu(p72fnFtcPix5UKwr9YNzW(u"ࠨ࠾ࠣယ")+yA5z6LIXBlo41PRVMY87wOisFp(u"ࠢࡃࠤရ")*Cjm5snYRM2urQ8TPvcFoObeWqKaV, rKagANTOtGJnhVWfE2BHpePYC3IQ5l, qvEcXgSWrGkbB2f7t083uP6ijMw)
				ip = bUdr5Hahw6sY8xJ(u"ࠨࠩလ")
				for df6AVUNQzmgs in PJA7lhq83ivVoHDejubG54CfI: ip += str(df6AVUNQzmgs) + E6MIKdpBomef(u"ࠩ࠱ࠫဝ")
				ip = ip[G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠰ᙗ"):-pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠷ᙖ")]
				RuSqTgGZ7tlerwK9pWYf16Ln.append(ip)
			if W6WdK7xuyD9TUNMof1APF in [fprnld4CZo(u"࠴ᙚ"),SO94xq1RAkMm2uF(u"࠶ᙛ"),UTelCo0ihE1d5R(u"࠺ᙜ"),kEhAHvti6Vnsfx(u"࠼ᙝ"),yA5z6LIXBlo41PRVMY87wOisFp(u"࠲࠷ᙘ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠴࠻ᙙ")]: qvEcXgSWrGkbB2f7t083uP6ijMw = qvEcXgSWrGkbB2f7t083uP6ijMw + Cjm5snYRM2urQ8TPvcFoObeWqKaV
	except: RuSqTgGZ7tlerwK9pWYf16Ln = []
	if not RuSqTgGZ7tlerwK9pWYf16Ln: LOHZ4o9m7p6ebfTYXGIdz5PWs3q(kEhAHvti6Vnsfx(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨသ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫࠥࠦࠠࡅࡐࡖࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡊࡲࡷࡹࡀࠠ࡜ࠢࠪဟ")+WK59LPt30k6OEVm+UTelCo0ihE1d5R(u"ࠬࠦ࡝ࠨဠ"))
	return RuSqTgGZ7tlerwK9pWYf16Ln
def hNCJPTucIV7GOSR0HytZ6eQrqEUpw(cTJphS1nFz5EUgNWm86C,mHejXxkvM1qCESPVRy54QB,NbE4qnzmPKGWtjYpoRL3HTS1A,showDialogs=FvNyZqaLKw(u"ࡖࡵࡹࡪៅ")):
	if NbE4qnzmPKGWtjYpoRL3HTS1A:
		g4LkdRSxCjt2WBT = [SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ใษษิࠫအ"),iRoLg2m47tnDATBHGCSPNyx(u"ࠧษษ็฾ࠬဢ"),p72fnFtcPix5UKwr9YNzW(u"ࠨࡣࡧࡹࡱࡺࠧဣ"),XzrqbGDIy54juixkMA(u"ࠩࡻࡼࠬဤ"),Cu1704YofAbr3QTm(u"ࠪࡷࡪࡾࠧဥ")]
		if cTJphS1nFz5EUgNWm86C!=xW2Arao7YVOemw(u"ࠫࡇࡕࡋࡓࡃࠪဦ"):
			g4LkdRSxCjt2WBT += [E6MIKdpBomef(u"ࠬࡸ࠺ࠨဧ"),zqdvcbP5L8BHh(u"࠭ࡲ࠮ࠩဨ"),E6MIKdpBomef(u"ࠧ࠮࡯ࡤࠫဩ")]
			g4LkdRSxCjt2WBT += [oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨ࠼ࡵࠫဪ"),wRxoKs10Syj7V4edYhtP(u"ࠩ࠰ࡶࠬါ"),kEhAHvti6Vnsfx(u"ࠪࡱࡦ࠳ࠧာ")]
		for toOX7FCsl8iWTf in NbE4qnzmPKGWtjYpoRL3HTS1A:
			if FnBiAjthS8MkXs67W(u"ࠫ࡬࡫ࡴ࠯ࡲ࡫ࡴࡄ࠭ိ") in toOX7FCsl8iWTf: continue
			if Cu1704YofAbr3QTm(u"ࠬำไใหࠪီ") in toOX7FCsl8iWTf: continue
			toOX7FCsl8iWTf = toOX7FCsl8iWTf.lower()
			if HHosl5fRdhtEDAYyP: toOX7FCsl8iWTf = toOX7FCsl8iWTf.decode(g4g6bfkPtVGU5lIM3(u"࠭ࡵࡵࡨ࠻ࠫု")).encode(FvNyZqaLKw(u"ࠧࡶࡶࡩ࠼ࠬူ"))
			toOX7FCsl8iWTf = toOX7FCsl8iWTf.replace(kEhAHvti6Vnsfx(u"ࠨ࠼ࠪေ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠩࠪဲ"))
			wRcJKqugz9mDsV5EQdZhxv = GGvHJKP9LUxEk10Fw.findall(wRxoKs10Syj7V4edYhtP(u"ࠪࠬ࠶ࡡ࠵࠮࠻ࡠ࠯ࢁ࠸࡛࠱࠯࠶ࡡ࠰࠯ࠧဳ"),toOX7FCsl8iWTf,GGvHJKP9LUxEk10Fw.DOTALL)
			d2qcy7O3X1JN95tTlCmAEzjGr = UTelCo0ihE1d5R(u"ࡉࡥࡱࡹࡥំ")
			for OHMCLP6gmcnf9vz in wRcJKqugz9mDsV5EQdZhxv:
				if len(OHMCLP6gmcnf9vz)==lc0dpSmwoPDjLnk(u"࠲ᙞ"):
					d2qcy7O3X1JN95tTlCmAEzjGr = Me28A1sBLNIgUp5YCDyvT(u"ࡘࡷࡻࡥះ")
					break
			if SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࡳࡵࡴࠡࡴࡤࡸࡪࡪࠧဴ") in toOX7FCsl8iWTf: continue
			elif E6MIKdpBomef(u"ࠬࡻ࡮ࡳࡣࡷࡩࡩ࠭ဵ") in toOX7FCsl8iWTf: continue
			elif iRoLg2m47tnDATBHGCSPNyx(u"ฺ๋࠭ำฺ้ࠣ์แࠨံ") in toOX7FCsl8iWTf: continue
			elif bkHiCyWXjdgvF9xE1DA6wQ48(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧࡃࡖࡈࡼࡕ࡜࠱࠺ࡕࡕ࡚ࡓ࡛ࡕ࡭ࡘࡇ࡚ࡊ࡜ࡅ့࡙ࠩ")): continue
			elif toOX7FCsl8iWTf in [kEhAHvti6Vnsfx(u"ࠨࡴࠪး")] or d2qcy7O3X1JN95tTlCmAEzjGr or any(hieW1zRUG5w9AykJjv0X in toOX7FCsl8iWTf for hieW1zRUG5w9AykJjv0X in g4LkdRSxCjt2WBT):
				LOHZ4o9m7p6ebfTYXGIdz5PWs3q(bUdr5Hahw6sY8xJ(u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ္࡙ࠧ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+kEhAHvti6Vnsfx(u"ࠪࠤࠥࠦࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡢࡦࡸࡰࡹࡹࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡗࡕࡐ࠿်࡛ࠦࠡࠩ")+mHejXxkvM1qCESPVRy54QB+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫࠥࡣࠧျ"))
				if showDialogs: From8aTqdhCbPs(Cu1704YofAbr3QTm(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨြ"),lc0dpSmwoPDjLnk(u"࠭วๅใํำ๏๎ࠠๅๆๆฬฬืࠠโไฺࠤํษๆศ่๊ࠢ฾ะ็ࠨွ"))
				return G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࡙ࡸࡵࡦៈ")
	return UTelCo0ihE1d5R(u"ࡌࡡ࡭ࡵࡨ៉")
def aHKzv76JCVnprbY8w(*aargs,**kkwargs):
	if aargs:
		direction = aargs[QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠱ᙟ")]
		sj1zh57tNePTAv9 = aargs[FnBiAjthS8MkXs67W(u"࠳ᙠ")]
		if not direction: direction = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧࡤࡧࡱࡸࡪࡸࠧှ")
		if not sj1zh57tNePTAv9: sj1zh57tNePTAv9 = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨษึฮ๊ืวาࠩဿ")
		qGMblkEhSwBnJUL3a6T = aargs[E6MIKdpBomef(u"࠵ᙡ")]
		fH8bDPV6AceuCFNO0Ert7oq3p = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩ࡟ࡲࠬ၀").join(aargs[xW2Arao7YVOemw(u"࠷ᙢ"):])
	else: direction,sj1zh57tNePTAv9,qGMblkEhSwBnJUL3a6T,fH8bDPV6AceuCFNO0Ert7oq3p = lc0dpSmwoPDjLnk(u"ࠪࠫ၁"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࡔࡑࠧ၂"),dshJSmRqeiP9nap2(u"ࠬ࠭၃"),FnBiAjthS8MkXs67W(u"࠭ࠧ၄")
	CCQOct8zmrKMuP6ZEkxq7oaf1BeRv(direction,S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠧࠨ၅"),sj1zh57tNePTAv9,G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠨࠩ၆"),qGMblkEhSwBnJUL3a6T,fH8bDPV6AceuCFNO0Ert7oq3p,**kkwargs)
	return
def ggi4vBsqHDArM1(*aargs,**kkwargs):
	direction = aargs[FnBiAjthS8MkXs67W(u"࠵ᙣ")]
	PE9nuk0B2Fg = aargs[SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠷ᙤ")]
	B6Qx9ts3HVjFCRrMGzgky0 = aargs[sTcr7iDp5eFt4RoLMhuwq1A(u"࠲ᙥ")]
	if B6Qx9ts3HVjFCRrMGzgky0 or PE9nuk0B2Fg: GhuabAM5xCEHofiL9P = FvNyZqaLKw(u"ࡔࡳࡷࡨ៊")
	else: GhuabAM5xCEHofiL9P = bUdr5Hahw6sY8xJ(u"ࡇࡣ࡯ࡷࡪ់")
	qGMblkEhSwBnJUL3a6T = aargs[zqdvcbP5L8BHh(u"࠴ᙦ")]
	fH8bDPV6AceuCFNO0Ert7oq3p = aargs[lc0dpSmwoPDjLnk(u"࠶ᙧ")]
	if not direction: direction = LiRcTVUWuth70DmPy(u"ࠩࡦࡩࡳࡺࡥࡳࠩ၇")
	if not PE9nuk0B2Fg: PE9nuk0B2Fg = Cu1704YofAbr3QTm(u"ࠪ็้อࠠࠡࡐࡲࠫ၈")
	if not B6Qx9ts3HVjFCRrMGzgky0: B6Qx9ts3HVjFCRrMGzgky0 = G5DeRbUpFj8E9OtJLvlo2fWmZC(u"๋ࠫ฿ๅࠡࠢ࡜ࡩࡸ࠭၉")
	if len(aargs)>=FnBiAjthS8MkXs67W(u"࠺ᙩ"): fH8bDPV6AceuCFNO0Ert7oq3p += FvNyZqaLKw(u"ࠬࡢ࡮ࠨ၊")+aargs[LiRcTVUWuth70DmPy(u"࠸ᙨ")]
	if len(aargs)>=p72fnFtcPix5UKwr9YNzW(u"࠼ᙪ"): fH8bDPV6AceuCFNO0Ert7oq3p += bUdr5Hahw6sY8xJ(u"࠭࡜࡯ࠩ။")+aargs[bUdr5Hahw6sY8xJ(u"࠼ᙫ")]
	r54fQALYmUbegM7yxsNc = CCQOct8zmrKMuP6ZEkxq7oaf1BeRv(direction,PE9nuk0B2Fg,lc0dpSmwoPDjLnk(u"ࠧࠨ၌"),B6Qx9ts3HVjFCRrMGzgky0,qGMblkEhSwBnJUL3a6T,fH8bDPV6AceuCFNO0Ert7oq3p,**kkwargs)
	if r54fQALYmUbegM7yxsNc==-yA5z6LIXBlo41PRVMY87wOisFp(u"࠱ᙬ") and GhuabAM5xCEHofiL9P: r54fQALYmUbegM7yxsNc = -yA5z6LIXBlo41PRVMY87wOisFp(u"࠱ᙬ")
	elif r54fQALYmUbegM7yxsNc==-QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠲᙭") and not GhuabAM5xCEHofiL9P: r54fQALYmUbegM7yxsNc = oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࡈࡤࡰࡸ࡫៌")
	elif r54fQALYmUbegM7yxsNc==g4g6bfkPtVGU5lIM3(u"࠲᙮"): r54fQALYmUbegM7yxsNc = FnBiAjthS8MkXs67W(u"ࡉࡥࡱࡹࡥ៍")
	elif r54fQALYmUbegM7yxsNc==FvNyZqaLKw(u"࠵ᙯ"): r54fQALYmUbegM7yxsNc = YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࡘࡷࡻࡥ៎")
	return r54fQALYmUbegM7yxsNc
def D1DJtzviFZSrA(*aargs,**kkwargs):
	return zz2LJUB9kjnZqAeH.Dialog().select(*aargs,**kkwargs)
def From8aTqdhCbPs(*aargs,**kkwargs):
	qGMblkEhSwBnJUL3a6T = aargs[G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠴ᙰ")]
	fH8bDPV6AceuCFNO0Ert7oq3p = aargs[g4g6bfkPtVGU5lIM3(u"࠶ᙱ")]
	if oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨࡶ࡬ࡱࡪ࠭၍") in list(kkwargs.keys()): P8qy3hDFSH = kkwargs[yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩࡷ࡭ࡲ࡫ࠧ၎")]
	else: P8qy3hDFSH = SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠷࠰࠱࠲ᙲ")
	if len(aargs)>oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠲ᙳ") and zqdvcbP5L8BHh(u"ࠪࡸ࡮ࡳࡥࠨ၏") not in aargs[oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠲ᙳ")]: profile = aargs[oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠲ᙳ")]
	else: profile = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࠪၐ")
	al9LoftcV58kC6Hm = PquO3SKtwbDmYLlvN5Jk9a2(bUdr5Hahw6sY8xJ(u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡓࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡌࡱࡦ࡭ࡥ࠯ࡺࡰࡰࠬၑ"),bdmxngE9YGIeQ,hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧၒ"),SO94xq1RAkMm2uF(u"ࠧ࠸࠴࠳ࡴࠬၓ"))
	image_filename = rJOGPocvjmQy1fSNHthMzRCuZ8D.replace(LiRcTVUWuth70DmPy(u"ࠨࡡ࠳࠴࠵࠶࡟ࠨၔ"),lc0dpSmwoPDjLnk(u"ࠩࡢࠫၕ")+str(MQbODJoPV2w8TEAg4zXZdjLxSW.time())+YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪࡣࠬၖ"))
	image_filename = image_filename.replace(UTelCo0ihE1d5R(u"ࠫࡡࡢࠧၗ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬࡢ࡜࡝࡞ࠪၘ")).replace(E6MIKdpBomef(u"࠭࠯࠰ࠩၙ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧ࠰࠱࠲࠳ࠬၚ"))
	image_height = EFo7dN1XkCJSI6sPzZO8cTRm9Aj3U5(wRxoKs10Syj7V4edYhtP(u"ࠨࠩၛ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩࠪၜ"),E6MIKdpBomef(u"ࠪࠫၝ"),qGMblkEhSwBnJUL3a6T,fH8bDPV6AceuCFNO0Ert7oq3p,profile,iRoLg2m47tnDATBHGCSPNyx(u"ࠫࡱ࡫ࡦࡵࠩၞ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࡋࡧ࡬ࡴࡧ៏"),image_filename)
	al9LoftcV58kC6Hm.show()
	if profile==fprnld4CZo(u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡣࡹࡽ࡯ࡩࡣ࡯ࡪࡸ࠭ၟ"):
		al9LoftcV58kC6Hm.getControl(hBvsQ7oCkKUdwjx58ml3EN(u"࠻࠳࠸࠵ᙵ")).setHeight(kEhAHvti6Vnsfx(u"࠳࠳࠸ᙴ"))
		al9LoftcV58kC6Hm.getControl(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠾࠶࠴࠱ᙸ")).setPosition(SO94xq1RAkMm2uF(u"࠸࠹ᙶ"),-iRoLg2m47tnDATBHGCSPNyx(u"࠼࠵ᙷ"))
		al9LoftcV58kC6Hm.getControl(kEhAHvti6Vnsfx(u"࠿࠰࠶࠲ᙹ")).setPosition(yA5z6LIXBlo41PRVMY87wOisFp(u"࠱࠳࠲ᙺ"),-yA5z6LIXBlo41PRVMY87wOisFp(u"࠷࠲ᙻ"))
		al9LoftcV58kC6Hm.getControl(SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠸࠵࠶ᙾ")).setPosition(xW2Arao7YVOemw(u"࠻࠳ᙼ"),-SO94xq1RAkMm2uF(u"࠶࠹ᙽ"))
	al9LoftcV58kC6Hm.getControl(sTcr7iDp5eFt4RoLMhuwq1A(u"࠹࠶࠱ᙿ")).setVisible(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࡌࡡ࡭ࡵࡨ័"))
	al9LoftcV58kC6Hm.getControl(SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠺࠰࠳ ")).setVisible(g4g6bfkPtVGU5lIM3(u"ࡆࡢ࡮ࡶࡩ៑"))
	al9LoftcV58kC6Hm.getControl(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠹࠱࠷࠳ᚁ")).setImage(image_filename)
	al9LoftcV58kC6Hm.getControl(Me28A1sBLNIgUp5YCDyvT(u"࠺࠲࠸࠴ᚂ")).setHeight(image_height)
	t2EpW9jLKaIm4i = dM9DZS0pkxbqaf7W.Thread(target=YROJzfHyAmnuvdLgQUCr0TKB1lG6,args=(al9LoftcV58kC6Hm,image_filename,P8qy3hDFSH))
	t2EpW9jLKaIm4i.start()
	return
def YROJzfHyAmnuvdLgQUCr0TKB1lG6(al9LoftcV58kC6Hm,image_filename,P8qy3hDFSH):
	MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(P8qy3hDFSH//LiRcTVUWuth70DmPy(u"࠳࠳࠴࠵࠴࠰ᚃ"))
	MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠳࠲࠶࠶࠰ᚄ"))
	if WpgZTyqoMAPhwGiXF.path.exists(image_filename):
		try: WpgZTyqoMAPhwGiXF.remove(image_filename)
		except: pass
	return
def W2mX5R4ShoirfzdFaOukjHZIDpC8(*aargs,**kkwargs):
	qGMblkEhSwBnJUL3a6T,fH8bDPV6AceuCFNO0Ert7oq3p,profile,direction = LiRcTVUWuth70DmPy(u"࠭ࠧၠ"),LiRcTVUWuth70DmPy(u"ࠧࠨၡ"),E6MIKdpBomef(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩၢ"),E6MIKdpBomef(u"ࠩ࡯ࡩ࡫ࡺࠧၣ")
	if len(aargs)>=SO94xq1RAkMm2uF(u"࠵ᚅ"): qGMblkEhSwBnJUL3a6T = aargs[lc0dpSmwoPDjLnk(u"࠵ᚆ")]
	if len(aargs)>=LiRcTVUWuth70DmPy(u"࠲ᚈ"): fH8bDPV6AceuCFNO0Ert7oq3p = aargs[dshJSmRqeiP9nap2(u"࠷ᚇ")]
	if len(aargs)>=sTcr7iDp5eFt4RoLMhuwq1A(u"࠴ᚉ"): profile = aargs[FvNyZqaLKw(u"࠴ᚊ")]
	if len(aargs)>=iUeoLOsbHqP(u"࠸ᚌ"): direction = aargs[hBvsQ7oCkKUdwjx58ml3EN(u"࠶ᚋ")]
	return d0tNlv4Lbu2pqDaO1JfSEC9QIP5Xc(direction,qGMblkEhSwBnJUL3a6T,fH8bDPV6AceuCFNO0Ert7oq3p,profile)
def VVlcpjUCK8HT70i(*aargs,**kkwargs):
	return zz2LJUB9kjnZqAeH.Dialog().contextmenu(*aargs,**kkwargs)
def xpNfHdntGQPjZOCli8A3JyvBSRL(*aargs,**kkwargs):
	return zz2LJUB9kjnZqAeH.Dialog().browseSingle(*aargs,**kkwargs)
def NdJbnTW2X5ZfaDE6Hqwe(*aargs,**kkwargs):
	return zz2LJUB9kjnZqAeH.Dialog().input(*aargs,**kkwargs)
def XOL34TuqseWy2gpYfd(*aargs,**kkwargs):
	return zz2LJUB9kjnZqAeH.DialogProgress(*aargs,**kkwargs)
LegXM4YdztOnEqC8i0GJu = fprnld4CZo(u"ࡇࡣ࡯ࡷࡪ្")
def Mrch2HElwVNnm9siDCkZIKFbYL6ao7(YudnJyHQXr0xI9o8MCg5PsSNjT):
	global LegXM4YdztOnEqC8i0GJu
	GwBsaCOTjM14 = YudnJyHQXr0xI9o8MCg5PsSNjT==l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࡷࡹࡧࡲࡵࠩၤ") and not LegXM4YdztOnEqC8i0GJu
	FRZzAcUCSDTWGfswQdEuy = YudnJyHQXr0xI9o8MCg5PsSNjT==pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࡸࡺ࡯ࡱࠩၥ") and LegXM4YdztOnEqC8i0GJu
	if GwBsaCOTjM14:
		al9LoftcV58kC6Hm = SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠬࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࡰࡲࡧࡦࡴࡣࡦ࡮ࠪၦ") if yMvF9GoTjhU5biA>dshJSmRqeiP9nap2(u"࠶࠽࠮࠺࠻ᚍ") else pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭ࡢࡶࡵࡼࡨ࡮ࡧ࡬ࡰࡩࠪၧ")
		cEZpW924rqNYm5.executebuiltin(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࠩၨ")+al9LoftcV58kC6Hm+FnBiAjthS8MkXs67W(u"ࠨࠫࠪၩ"))
		LegXM4YdztOnEqC8i0GJu = UTelCo0ihE1d5R(u"ࡖࡵࡹࡪ៓")
	elif FRZzAcUCSDTWGfswQdEuy:
		al9LoftcV58kC6Hm = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬ࡴ࡯ࡤࡣࡱࡧࡪࡲࠧၪ") if yMvF9GoTjhU5biA>pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠷࠷࠯࠻࠼ᚎ") else l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࡦࡺࡹࡹࡥ࡫ࡤࡰࡴ࡭ࠧၫ")
		cEZpW924rqNYm5.executebuiltin(XzrqbGDIy54juixkMA(u"ࠫࡉ࡯ࡡ࡭ࡱࡪ࠲ࡈࡲ࡯ࡴࡧࠫࠫၬ")+al9LoftcV58kC6Hm+LiRcTVUWuth70DmPy(u"ࠬ࠯ࠧၭ"))
		LegXM4YdztOnEqC8i0GJu = oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࡉࡥࡱࡹࡥ។")
	return
def CCQOct8zmrKMuP6ZEkxq7oaf1BeRv(direction,button0=l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࠧၮ"),button1=zqdvcbP5L8BHh(u"ࠧࠨၯ"),button2=bUdr5Hahw6sY8xJ(u"ࠨࠩၰ"),qGMblkEhSwBnJUL3a6T=pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩࠪၱ"),fH8bDPV6AceuCFNO0Ert7oq3p=UTelCo0ihE1d5R(u"ࠪࠫၲ"),profile=S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡨࡩࡨࡨࡲࡲࡹ࠭ၳ"),BxodSUvIMtD5ENPh9p=bUdr5Hahw6sY8xJ(u"࠰ᚏ"),F38FJ9zoGjYdruHE1NxDypRPmW=bUdr5Hahw6sY8xJ(u"࠰ᚏ")):
	if not direction: direction = dshJSmRqeiP9nap2(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬၴ")
	al9LoftcV58kC6Hm = hWUNalJAsv(yA5z6LIXBlo41PRVMY87wOisFp(u"࠭ࡄࡪࡣ࡯ࡳ࡬ࡉ࡯࡯ࡨ࡬ࡶࡲ࡚ࡨࡳࡧࡨࡆࡺࡺࡴࡰࡰࡶ࠲ࡽࡳ࡬ࠨၵ"),bdmxngE9YGIeQ,lc0dpSmwoPDjLnk(u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨၶ"),wRxoKs10Syj7V4edYhtP(u"ࠨ࠹࠵࠴ࡵ࠭ၷ"))
	al9LoftcV58kC6Hm.EOB7W1zJAsQFXMdLg(button0,button1,button2,qGMblkEhSwBnJUL3a6T,fH8bDPV6AceuCFNO0Ert7oq3p,profile,direction,BxodSUvIMtD5ENPh9p,F38FJ9zoGjYdruHE1NxDypRPmW)
	if BxodSUvIMtD5ENPh9p>p72fnFtcPix5UKwr9YNzW(u"࠱ᚐ"): al9LoftcV58kC6Hm.LuFKZhcI46PHD()
	if F38FJ9zoGjYdruHE1NxDypRPmW>iRoLg2m47tnDATBHGCSPNyx(u"࠲ᚑ"): al9LoftcV58kC6Hm.qDPbv5OjaR()
	if BxodSUvIMtD5ENPh9p==LiRcTVUWuth70DmPy(u"࠳ᚒ") and F38FJ9zoGjYdruHE1NxDypRPmW==LiRcTVUWuth70DmPy(u"࠳ᚒ"): al9LoftcV58kC6Hm.FQqZchx01mCfBUvgLIKJlS()
	al9LoftcV58kC6Hm.doModal()
	r54fQALYmUbegM7yxsNc = al9LoftcV58kC6Hm.choiceID
	return r54fQALYmUbegM7yxsNc
def d0tNlv4Lbu2pqDaO1JfSEC9QIP5Xc(direction,qGMblkEhSwBnJUL3a6T,fH8bDPV6AceuCFNO0Ert7oq3p,profile=yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪၸ")):
	if not direction: direction = kEhAHvti6Vnsfx(u"ࠪࡰࡪ࡬ࡴࠨၹ")
	al9LoftcV58kC6Hm = PquO3SKtwbDmYLlvN5Jk9a2(FvNyZqaLKw(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡘࡪࡾࡴࡗ࡫ࡨࡻࡪࡸࡆࡶ࡮࡯ࡗࡨࡸࡥࡦࡰ࠱ࡼࡲࡲࠧၺ"),bdmxngE9YGIeQ,g4g6bfkPtVGU5lIM3(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭ၻ"),iRoLg2m47tnDATBHGCSPNyx(u"࠭࠷࠳࠲ࡳࠫၼ"))
	image_filename = rJOGPocvjmQy1fSNHthMzRCuZ8D.replace(wRxoKs10Syj7V4edYhtP(u"ࠧࡠ࠲࠳࠴࠵ࡥࠧၽ"),wRxoKs10Syj7V4edYhtP(u"ࠨࡡࠪၾ")+str(MQbODJoPV2w8TEAg4zXZdjLxSW.time())+oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠩࡢࠫၿ"))
	image_filename = image_filename.replace(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࡠࡡ࠭ႀ"),Me28A1sBLNIgUp5YCDyvT(u"ࠫࡡࡢ࡜࡝ࠩႁ")).replace(kEhAHvti6Vnsfx(u"ࠬ࠵࠯ࠨႂ"),zqdvcbP5L8BHh(u"࠭࠯࠰࠱࠲ࠫႃ"))
	image_height = EFo7dN1XkCJSI6sPzZO8cTRm9Aj3U5(zqdvcbP5L8BHh(u"ࠧࠨႄ"),fprnld4CZo(u"ࠨࠩႅ"),xW2Arao7YVOemw(u"ࠩࠪႆ"),qGMblkEhSwBnJUL3a6T,fH8bDPV6AceuCFNO0Ert7oq3p,profile,direction,oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࡊࡦࡲࡳࡦ៕"),image_filename)
	al9LoftcV58kC6Hm.show()
	al9LoftcV58kC6Hm.getControl(yA5z6LIXBlo41PRVMY87wOisFp(u"࠽࠵࠻࠰ᚓ")).setHeight(image_height)
	al9LoftcV58kC6Hm.getControl(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠾࠶࠵࠱ᚔ")).setImage(image_filename)
	bph8oFsIHqyE5AWMTCvSkQgfzD3 = al9LoftcV58kC6Hm.doModal()
	try: WpgZTyqoMAPhwGiXF.remove(image_filename)
	except: pass
	return bph8oFsIHqyE5AWMTCvSkQgfzD3
def Y8Y6b7aLSUKjdE1Ae(cOYgBEo9iVr1mXjxPtk3sIvlGAf=sTcr7iDp5eFt4RoLMhuwq1A(u"࡙ࡸࡵࡦ៖")):
	if cOYgBEo9iVr1mXjxPtk3sIvlGAf:
		bTDaxXYSseoFCI6cQ4f58vqr3dPNp = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠪࡷࡹࡸࠧႇ"),iUeoLOsbHqP(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧႈ"),hBvsQ7oCkKUdwjx58ml3EN(u"࡛ࠬࡓࡆࡔࡄࡋࡊࡔࡔࠨႉ"))
		if bTDaxXYSseoFCI6cQ4f58vqr3dPNp: return bTDaxXYSseoFCI6cQ4f58vqr3dPNp
	fH8bDPV6AceuCFNO0Ert7oq3p = bUdr5Hahw6sY8xJ(u"࠭ࠧႊ")
	if iUeoLOsbHqP(u"࠶ᚕ") and YutQm2AwozR9VKp4O1lWj8FaryI.succeeded:
		U9rSWyc74gLOw = YutQm2AwozR9VKp4O1lWj8FaryI.content
		L8Nc9Q4IRd5Bqm21ZF = U9rSWyc74gLOw.count(dshJSmRqeiP9nap2(u"ࠧࡎࡱࡽ࡭ࡱࡲࡡࠨႋ"))
		if L8Nc9Q4IRd5Bqm21ZF>FnBiAjthS8MkXs67W(u"࠸࠱ᚖ"):
			fH8bDPV6AceuCFNO0Ert7oq3p = GGvHJKP9LUxEk10Fw.findall(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨࡩࡨࡸ࠲ࡺࡨࡦ࠯࡯࡭ࡸࡺ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪႌ"),U9rSWyc74gLOw,GGvHJKP9LUxEk10Fw.DOTALL)
			fH8bDPV6AceuCFNO0Ert7oq3p = fH8bDPV6AceuCFNO0Ert7oq3p[wRxoKs10Syj7V4edYhtP(u"࠱ᚗ")]
	if not fH8bDPV6AceuCFNO0Ert7oq3p:
		jfrDbIU6el5KaNvTHC2sZt1d = WpgZTyqoMAPhwGiXF.path.join(bdmxngE9YGIeQ,iRoLg2m47tnDATBHGCSPNyx(u"ࠩࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨႍ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪࡹࡸ࡫ࡲࡢࡩࡨࡲࡹࡹ࠮ࡵࡺࡷࠫႎ"))
		fH8bDPV6AceuCFNO0Ert7oq3p = open(jfrDbIU6el5KaNvTHC2sZt1d,fprnld4CZo(u"ࠫࡷࡨࠧႏ")).read()
		if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: fH8bDPV6AceuCFNO0Ert7oq3p = fH8bDPV6AceuCFNO0Ert7oq3p.decode(bUdr5Hahw6sY8xJ(u"ࠬࡻࡴࡧ࠺ࠪ႐"))
		fH8bDPV6AceuCFNO0Ert7oq3p = fH8bDPV6AceuCFNO0Ert7oq3p.replace(bUdr5Hahw6sY8xJ(u"࠭࡜ࡳࠩ႑"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠧࠨ႒"))
	nRvb4UpNHDL9twdoSZM5s0hqJm = GGvHJKP9LUxEk10Fw.findall(UTelCo0ihE1d5R(u"ࠨࠪࡐࡳࡿ࡯࡬࡭ࡣ࠱࠮ࡄ࠯࡜࡯ࠩ႓"),fH8bDPV6AceuCFNO0Ert7oq3p,GGvHJKP9LUxEk10Fw.DOTALL)
	Gg7E0oR21bhU6JQKXjvt48puMsqCwI = []
	for i94LpDNUzy in nRvb4UpNHDL9twdoSZM5s0hqJm:
		mA0uXGebhdOrW1vVUsfg25nE = i94LpDNUzy.lower()
		if iRoLg2m47tnDATBHGCSPNyx(u"ࠩࡤࡲࡩࡸ࡯ࡪࡦࠪ႔") in mA0uXGebhdOrW1vVUsfg25nE: continue
		if S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠪࡹࡧࡻ࡮ࡵࡷࠪ႕") in mA0uXGebhdOrW1vVUsfg25nE: continue
		if iUeoLOsbHqP(u"ࠫ࡮ࡶࡨࡰࡰࡨࠫ႖") in mA0uXGebhdOrW1vVUsfg25nE: continue
		if lc0dpSmwoPDjLnk(u"ࠬࡩࡲࡰࡵࠪ႗") in mA0uXGebhdOrW1vVUsfg25nE: continue
		Gg7E0oR21bhU6JQKXjvt48puMsqCwI.append(i94LpDNUzy)
	bTDaxXYSseoFCI6cQ4f58vqr3dPNp = Y7pXj2OtNq9GZdvmcTkS3hMJn.sample(Gg7E0oR21bhU6JQKXjvt48puMsqCwI,iUeoLOsbHqP(u"࠳ᚘ"))
	bTDaxXYSseoFCI6cQ4f58vqr3dPNp = bTDaxXYSseoFCI6cQ4f58vqr3dPNp[Me28A1sBLNIgUp5YCDyvT(u"࠳ᚙ")]
	Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,p72fnFtcPix5UKwr9YNzW(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ႘"),Me28A1sBLNIgUp5YCDyvT(u"ࠧࡖࡕࡈࡖࡆࡍࡅࡏࡖࠪ႙"),bTDaxXYSseoFCI6cQ4f58vqr3dPNp,Oa8xvPtmLZkBA43K0EzrdhXS)
	return bTDaxXYSseoFCI6cQ4f58vqr3dPNp
def XxluY9ohL0Ri3paB(CCeZSJvsigLcq=g4g6bfkPtVGU5lIM3(u"ࠨࠩႚ")):
	if not CCeZSJvsigLcq: CCeZSJvsigLcq = FTYWns4Q7dSEXmBOAGlJ.format_exc()
	if CCeZSJvsigLcq!=FnBiAjthS8MkXs67W(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬႛ") and YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪࡗࡾࡹࡴࡦ࡯ࡈࡼ࡮ࡺࠧႜ") not in CCeZSJvsigLcq: GGtWyVoJReUuEBCdAagiL1YXO8.stderr.write(CCeZSJvsigLcq)
	ExOjma9CSy2vQbPLhMUworYu = CCeZSJvsigLcq.splitlines()
	VVEta3LoIkqnG = ExOjma9CSy2vQbPLhMUworYu[-UTelCo0ihE1d5R(u"࠵ᚚ")]
	JtrGbLTVocjBEKme1XMQs9DRi4 = open(KpkbcfSIir6dCFMjwZy4gTYGuR0UA9,XzrqbGDIy54juixkMA(u"ࠫࡷࡨࠧႝ")).read()
	if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: JtrGbLTVocjBEKme1XMQs9DRi4 = JtrGbLTVocjBEKme1XMQs9DRi4.decode(fprnld4CZo(u"ࠬࡻࡴࡧ࠺ࠪ႞"))
	JtrGbLTVocjBEKme1XMQs9DRi4 = JtrGbLTVocjBEKme1XMQs9DRi4[-G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠽࠶࠰࠱᚛"):]
	ht2xa9F7Odi1CjMIEGqu3 = iUeoLOsbHqP(u"࠭࠽ࠨ႟")*Cu1704YofAbr3QTm(u"࠷࠰࠱᚜")
	if ht2xa9F7Odi1CjMIEGqu3 in JtrGbLTVocjBEKme1XMQs9DRi4: JtrGbLTVocjBEKme1XMQs9DRi4 = JtrGbLTVocjBEKme1XMQs9DRi4.rsplit(ht2xa9F7Odi1CjMIEGqu3,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠱᚝"))[QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠱᚝")]
	if VVEta3LoIkqnG in JtrGbLTVocjBEKme1XMQs9DRi4: JtrGbLTVocjBEKme1XMQs9DRi4 = JtrGbLTVocjBEKme1XMQs9DRi4.rsplit(VVEta3LoIkqnG,bUdr5Hahw6sY8xJ(u"࠲᚞"))[SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠲᚟")]
	bGt42uU18OeQ3FwxRCz5YS6v = GGvHJKP9LUxEk10Fw.findall(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࠩࡕࡲࡹࡷࡩࡥࡽࡏࡲࡨࡪ࠯࠺ࠡ࡞࡞ࠤ࠭࠴ࠪࡀࠫࠣࡠࡢ࠭Ⴀ"),JtrGbLTVocjBEKme1XMQs9DRi4,GGvHJKP9LUxEk10Fw.DOTALL)
	for h3lbGLTCz06Adp,hayXA4TiLlPxcVSIoK2 in reversed(bGt42uU18OeQ3FwxRCz5YS6v):
		if hayXA4TiLlPxcVSIoK2: break
	else: hayXA4TiLlPxcVSIoK2 = iUeoLOsbHqP(u"ࠨࡐࡒࡘ࡙ࠥࡐࡆࡅࡌࡊࡎࡋࡄࠨႡ")
	CESIzlW2YjMJck9ZuhXvfdTym0e,i94LpDNUzy,G9mhYrgWZ1ckjR7ezNJXOL = g4g6bfkPtVGU5lIM3(u"ࠩࠪႢ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪࠫႣ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠫࠬႤ")
	NbA0u8twXTkEjS1R26v3UB = YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไฯูฦ࠾࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨႥ")+VVEta3LoIkqnG
	Sdpv67IZVkJ8thgnX4jGEsq2NMD = g4g6bfkPtVGU5lIM3(u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅ็ุำึࡀࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪႦ")+hayXA4TiLlPxcVSIoK2
	for kzC0uyI9n7RPTsVE in reversed(ExOjma9CSy2vQbPLhMUworYu):
		if iRoLg2m47tnDATBHGCSPNyx(u"ࠧࡇ࡫࡯ࡩࠥࠨࠧႧ") in kzC0uyI9n7RPTsVE and iUeoLOsbHqP(u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧႨ") in kzC0uyI9n7RPTsVE: break
	kzC0uyI9n7RPTsVE = GGvHJKP9LUxEk10Fw.findall(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩࡉ࡭ࡱ࡫ࠠࠣࠪ࠱࠮ࡄ࠯ࠢ࡝࠮ࠣࡰ࡮ࡴࡥࠡࠪ࠱࠮ࡄ࠯࡜࠭ࠢ࡬ࡲࠥ࠮࠮ࠫࡁࠬࠨࠬႩ"),kzC0uyI9n7RPTsVE,GGvHJKP9LUxEk10Fw.DOTALL)
	if kzC0uyI9n7RPTsVE:
		CESIzlW2YjMJck9ZuhXvfdTym0e,i94LpDNUzy,G9mhYrgWZ1ckjR7ezNJXOL = kzC0uyI9n7RPTsVE[S4SOKF2QbBhjCd3RrVMuHIzE(u"࠳ᚠ")]
		if Me28A1sBLNIgUp5YCDyvT(u"ࠪ࠳ࠬႪ") in CESIzlW2YjMJck9ZuhXvfdTym0e: CESIzlW2YjMJck9ZuhXvfdTym0e = CESIzlW2YjMJck9ZuhXvfdTym0e.rsplit(lc0dpSmwoPDjLnk(u"ࠫ࠴࠭Ⴋ"),iRoLg2m47tnDATBHGCSPNyx(u"࠵ᚡ"))[iRoLg2m47tnDATBHGCSPNyx(u"࠵ᚡ")]
		else: CESIzlW2YjMJck9ZuhXvfdTym0e = CESIzlW2YjMJck9ZuhXvfdTym0e.rsplit(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬࡢ࡜ࠨႬ"),wRxoKs10Syj7V4edYhtP(u"࠶ᚢ"))[wRxoKs10Syj7V4edYhtP(u"࠶ᚢ")]
		qJ3gzrcmxD0Py = LiRcTVUWuth70DmPy(u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅ็็ๅ࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩႭ")+CESIzlW2YjMJck9ZuhXvfdTym0e
		GNBORki2UMplrcgTHFz6fJ = oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆึ฻ึࡀࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪႮ")+i94LpDNUzy
		HpefGVDy5sRt3mKzZNI8dBSQbr = iUeoLOsbHqP(u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็้่อๆ࠻ࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬႯ")+G9mhYrgWZ1ckjR7ezNJXOL
		c8MlH29jUJsYEy1IgxGBDVXuAOLTz = qJ3gzrcmxD0Py+UTelCo0ihE1d5R(u"ࠩ࡟ࡲࠬႰ")+GNBORki2UMplrcgTHFz6fJ+hBvsQ7oCkKUdwjx58ml3EN(u"ࠪࡠࡳ࠭Ⴑ")+HpefGVDy5sRt3mKzZNI8dBSQbr+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫࡡࡴࠧႲ")+Sdpv67IZVkJ8thgnX4jGEsq2NMD+iUeoLOsbHqP(u"ࠬࡢ࡮ࠨႳ")+NbA0u8twXTkEjS1R26v3UB
		Fn0w34LmWCA7cVS = GNBORki2UMplrcgTHFz6fJ+fprnld4CZo(u"࠭࡜࡯ࠩႴ")+Sdpv67IZVkJ8thgnX4jGEsq2NMD+S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠧ࡝ࡰࠪႵ")+NbA0u8twXTkEjS1R26v3UB+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨ࡞ࡱࠫႶ")+qJ3gzrcmxD0Py+Cu1704YofAbr3QTm(u"ࠩ࡟ࡲࠬႷ")+HpefGVDy5sRt3mKzZNI8dBSQbr
		xm3Ogy42wRhkJdfYHGBu = GNBORki2UMplrcgTHFz6fJ+xW2Arao7YVOemw(u"ࠪࡠࡳ࠭Ⴘ")+NbA0u8twXTkEjS1R26v3UB+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫࡡࡴࠧႹ")+qJ3gzrcmxD0Py+E6MIKdpBomef(u"ࠬࡢ࡮ࠨႺ")+HpefGVDy5sRt3mKzZNI8dBSQbr
	else:
		qJ3gzrcmxD0Py,GNBORki2UMplrcgTHFz6fJ,HpefGVDy5sRt3mKzZNI8dBSQbr = hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࠧႻ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧࠨႼ"),SO94xq1RAkMm2uF(u"ࠨࠩႽ")
		c8MlH29jUJsYEy1IgxGBDVXuAOLTz = Sdpv67IZVkJ8thgnX4jGEsq2NMD+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩ࡟ࡲࡡࡴࠧႾ")+NbA0u8twXTkEjS1R26v3UB
		Fn0w34LmWCA7cVS = Sdpv67IZVkJ8thgnX4jGEsq2NMD+E6MIKdpBomef(u"ࠪࡠࡳࡢ࡮ࠨႿ")+NbA0u8twXTkEjS1R26v3UB
		xm3Ogy42wRhkJdfYHGBu = NbA0u8twXTkEjS1R26v3UB
	XzA3anLPbTF5GiwcpRl9MDCvJ = wRxoKs10Syj7V4edYhtP(u"ࠫาีหࠡะฺวࠥเ๊า่ࠢๆฺ๎ฯࠨჀ")+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬࡢ࡮ࠨჁ")
	SSGYdpQ6vDK = OXFK49ofkhE6HJ3iyZ7LVdBMTtWx()
	WY7ZywL8umBcTRAH = []
	zpXG3Ky6ou8ndWHkb4 = SSGYdpQ6vDK[yA5z6LIXBlo41PRVMY87wOisFp(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫჂ")]
	GYNuXDdHIQ9J = nFIDUxebY52cj(mmn0lB2tFI7XTgVfESo)
	if hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬჃ") in list(SSGYdpQ6vDK.keys()):
		for BGRDN5Ssl8gTz,kRTdIsr2e3Q,vjWDgBalFoVEHT1Sy4iu3t in zpXG3Ky6ou8ndWHkb4: WY7ZywL8umBcTRAH = max(WY7ZywL8umBcTRAH,kRTdIsr2e3Q)
		if GYNuXDdHIQ9J<WY7ZywL8umBcTRAH:
			qGMblkEhSwBnJUL3a6T = g4g6bfkPtVGU5lIM3(u"ࠨไ่ࠤอะอะ์ฮࠤฬ๊ศา่ส้ัࠦโษๆࠣษึูวๅࠢส่ศิืศร่้๋ࠣศา็ฯࠫჄ")
			r54fQALYmUbegM7yxsNc = CCQOct8zmrKMuP6ZEkxq7oaf1BeRv(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩࡵ࡭࡬࡮ࡴࠨჅ"),zqdvcbP5L8BHh(u"ࠪษึูวๅࠢศ่๎ࠦวๅ็หี๊าࠧ჆"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫฯำฯ๋อࠪჇ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠬิั้ฮࠪ჈"),XzA3anLPbTF5GiwcpRl9MDCvJ+qGMblkEhSwBnJUL3a6T,c8MlH29jUJsYEy1IgxGBDVXuAOLTz)
			if r54fQALYmUbegM7yxsNc==LiRcTVUWuth70DmPy(u"࠶ᚣ"):
				o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࡣࡦࡰࡷࡩࡷ࠭჉"),xW2Arao7YVOemw(u"ࠧฯำ๋ะࠬ჊"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨฬะำ๏ัࠧ჋"),p72fnFtcPix5UKwr9YNzW(u"ࠩࠪ჌"),qGMblkEhSwBnJUL3a6T)
				if o07Z1tEB4n3ARCkVNu==xW2Arao7YVOemw(u"࠱ᚤ"): r54fQALYmUbegM7yxsNc = xW2Arao7YVOemw(u"࠱ᚤ")
			if r54fQALYmUbegM7yxsNc==zqdvcbP5L8BHh(u"࠲ᚥ"):
				import WWXqeaw1TE
				WWXqeaw1TE.WrEwOCRSaplo7iy6ZDxIJ2teL0Tf(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࡚ࡲࡶࡧៗ"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࡚ࡲࡶࡧៗ"))
			return
	vGrJ0pECFZtKSlI7DbXyT6daBc = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠪࡰ࡮ࡹࡴࠨჍ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ჎"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬࡇࡌࡍࡡࡖࡉࡓ࡚࡟ࡆࡔࡕࡓࡗ࡙ࠧ჏"))
	if not vGrJ0pECFZtKSlI7DbXyT6daBc: vGrJ0pECFZtKSlI7DbXyT6daBc = []
	Fn0w34LmWCA7cVS = Fn0w34LmWCA7cVS.replace(FnBiAjthS8MkXs67W(u"࠭࡜࡯ࠩა"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧ࡝࡞ࡱࠫბ")).replace(FvNyZqaLKw(u"ࠨ࡝ࡕࡘࡑࡣࠧგ"),lc0dpSmwoPDjLnk(u"ࠩࠪდ")).replace(FvNyZqaLKw(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ე"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࠬვ")).replace(wRxoKs10Syj7V4edYhtP(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧზ"),dshJSmRqeiP9nap2(u"࠭ࠧთ"))
	xm3Ogy42wRhkJdfYHGBu = xm3Ogy42wRhkJdfYHGBu.replace(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧ࡝ࡰࠪი"),LiRcTVUWuth70DmPy(u"ࠨ࡞࡟ࡲࠬკ")).replace(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨლ"),zqdvcbP5L8BHh(u"ࠪࠫმ")).replace(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧნ"),dshJSmRqeiP9nap2(u"ࠬ࠭ო")).replace(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨპ"),UTelCo0ihE1d5R(u"ࠧࠨჟ"))
	OmiEFfPARjG9MK2bLZNr = mmn0lB2tFI7XTgVfESo+FvNyZqaLKw(u"ࠨ࠼࠽ࠫრ")+xm3Ogy42wRhkJdfYHGBu
	if OmiEFfPARjG9MK2bLZNr in vGrJ0pECFZtKSlI7DbXyT6daBc:
		qGMblkEhSwBnJUL3a6T = XzrqbGDIy54juixkMA(u"ࠩ็ๆิࠦโๆฬࠣห๋ะࠠิษหๆฬࠦศฦำึห้ࠦ็ัษࠣห้ิืฤࠢศ่๎ࠦวๅ็หี๊าࠧს")
		aHKzv76JCVnprbY8w(FvNyZqaLKw(u"ࠪࡶ࡮࡭ࡨࡵࠩტ"),bUdr5Hahw6sY8xJ(u"ࠫࠬუ"),XzA3anLPbTF5GiwcpRl9MDCvJ+qGMblkEhSwBnJUL3a6T,c8MlH29jUJsYEy1IgxGBDVXuAOLTz)
		return
	i5GqR6h7rkMXmHsUWgwB1QTDVYvJ = str(yMvF9GoTjhU5biA).split(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠬ࠴ࠧფ"))[dshJSmRqeiP9nap2(u"࠲ᚦ")]
	mHejXxkvM1qCESPVRy54QB = oSVpce1UQYrDqhuM6PT[kEhAHvti6Vnsfx(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ქ")][LiRcTVUWuth70DmPy(u"࠹ᚧ")]
	YutQm2AwozR9VKp4O1lWj8FaryI = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࡑࡑࡖࡘࠬღ"),mHejXxkvM1qCESPVRy54QB,XzrqbGDIy54juixkMA(u"ࠨࠩყ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠩࠪშ"),g4g6bfkPtVGU5lIM3(u"ࠪࠫჩ"),p72fnFtcPix5UKwr9YNzW(u"ࠫࠬც"),wRxoKs10Syj7V4edYhtP(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡓࡉࡑ࡚ࡣࡊ࡞ࡉࡕࡡࡈࡖࡗࡕࡒࡔ࠯࠴ࡷࡹ࠭ძ"),iUeoLOsbHqP(u"ࡆࡢ࡮ࡶࡩ៘"),iUeoLOsbHqP(u"ࡆࡢ࡮ࡶࡩ៘"))
	U9rSWyc74gLOw = YutQm2AwozR9VKp4O1lWj8FaryI.content
	Nh8RwyWoiMZm2F76r = GGvHJKP9LUxEk10Fw.findall(fprnld4CZo(u"࠭ࡓࡕࡃࡕࡘ࠿ࡀࡓࡕࡃࡕࡘࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯ࡊࡔࡄ࠻࠼ࡈࡒࡉ࠭წ"),U9rSWyc74gLOw,GGvHJKP9LUxEk10Fw.DOTALL)
	for TF5yMr346tcRA0sjD89IeXN2,SSEfIdqszxVP1l2b,QQYrC1ILta2AOo,wW0gXLAmIB7OuVoCdJt84UQz3eR in Nh8RwyWoiMZm2F76r:
		TF5yMr346tcRA0sjD89IeXN2 = TF5yMr346tcRA0sjD89IeXN2.split(iUeoLOsbHqP(u"ࠧࠬࠩჭ"))
		QQYrC1ILta2AOo = QQYrC1ILta2AOo.split(FnBiAjthS8MkXs67W(u"ࠨ࠭ࠪხ"))
		wW0gXLAmIB7OuVoCdJt84UQz3eR = wW0gXLAmIB7OuVoCdJt84UQz3eR.split(dshJSmRqeiP9nap2(u"ࠩ࠮ࠫჯ"))
		if i94LpDNUzy in TF5yMr346tcRA0sjD89IeXN2 and VVEta3LoIkqnG==SSEfIdqszxVP1l2b and mmn0lB2tFI7XTgVfESo in QQYrC1ILta2AOo and i5GqR6h7rkMXmHsUWgwB1QTDVYvJ in wW0gXLAmIB7OuVoCdJt84UQz3eR:
			qGMblkEhSwBnJUL3a6T = iRoLg2m47tnDATBHGCSPNyx(u"๋ࠪีอࠠศๆั฻ศࠦๅฺำ๋ๅࠥ๎ำ๋฻ส่ัࠦศศๆศูิอัࠡษ็ๆฬีๅࠨჰ")
			o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(zqdvcbP5L8BHh(u"ࠫࡷ࡯ࡧࡩࡶࠪჱ"),bUdr5Hahw6sY8xJ(u"ࠬิั้ฮࠪჲ"),kEhAHvti6Vnsfx(u"࠭ลาีส่ࠥหไ๊ࠢส่๊ฮัๆฮࠪჳ"),XzA3anLPbTF5GiwcpRl9MDCvJ+qGMblkEhSwBnJUL3a6T,c8MlH29jUJsYEy1IgxGBDVXuAOLTz)
			if o07Z1tEB4n3ARCkVNu==yA5z6LIXBlo41PRVMY87wOisFp(u"࠵ᚨ"): aHKzv76JCVnprbY8w(kEhAHvti6Vnsfx(u"ࠧࡤࡧࡱࡸࡪࡸࠧჴ"),Cu1704YofAbr3QTm(u"ࠨࠩჵ"),kEhAHvti6Vnsfx(u"ࠩࠪჶ"),qGMblkEhSwBnJUL3a6T)
			return
	qGMblkEhSwBnJUL3a6T = iRoLg2m47tnDATBHGCSPNyx(u"ࠪห้ืฬศรࠣษึูวๅ๊ࠢิฬࠦวๅะฺวࠥหไ๊ࠢส่๊ฮัๆฮࠪჷ")
	msMl0uB5Y8AjRfqpZvWh1 = CCQOct8zmrKMuP6ZEkxq7oaf1BeRv(SO94xq1RAkMm2uF(u"ࠫࡷ࡯ࡧࡩࡶࠪჸ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩჹ"),lc0dpSmwoPDjLnk(u"࠭สฮัํฯࠥาาว์ࠪჺ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠧหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠨ჻"),XzA3anLPbTF5GiwcpRl9MDCvJ+qGMblkEhSwBnJUL3a6T,c8MlH29jUJsYEy1IgxGBDVXuAOLTz)
	if msMl0uB5Y8AjRfqpZvWh1==sTcr7iDp5eFt4RoLMhuwq1A(u"࠶ᚩ"):
		if not gl1TwIjQhCzLxnN2urAHKbSea:
			jKExzMkQmLFq(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࡕࡴࡸࡩ៙"))
			From8aTqdhCbPs(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠨ่ฯัฯูࠦๆๆํอࠥอไหฯา๎ะࠦวๅฮีส๏࠭ჼ"),E6MIKdpBomef(u"ࠩ๐ࡗࡺࡩࡣࡦࡵࡶࠫჽ"),MQbODJoPV2w8TEAg4zXZdjLxSW=G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠽࠵࠱ᚪ"))
			zrIWmJZh2CpVf8(FvNyZqaLKw(u"ࠪࡊࡴࡸࡣࡦࡦࠣࡩࡽ࡯ࡴࠡࡶࡲࠤࡦࡶࡰ࡭ࡻࠣࡸ࡭࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࡧࡧࠤ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࡹࠧჾ"))
		else: zrIWmJZh2CpVf8()
	elif msMl0uB5Y8AjRfqpZvWh1==Me28A1sBLNIgUp5YCDyvT(u"࠲ᚫ"):
		import WWXqeaw1TE
		WWXqeaw1TE.WrEwOCRSaplo7iy6ZDxIJ2teL0Tf(FnBiAjthS8MkXs67W(u"ࡖࡵࡹࡪ៚"),FnBiAjthS8MkXs67W(u"ࡖࡵࡹࡪ៚"))
		zrIWmJZh2CpVf8(UTelCo0ihE1d5R(u"ࠫࡋࡵࡲࡤࡧࡧࠤࡪࡾࡩࡵࠢࡷࡳࠥࡶࡲࡰࡥࡨࡷࡸࠦ࡮ࡦࡹࠣࡶࡪࡲࡥࡢࡵࡨࠫჿ"))
	o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(SO94xq1RAkMm2uF(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᄀ"),Cu1704YofAbr3QTm(u"࠭ࠧᄁ"),LiRcTVUWuth70DmPy(u"ࠧࠨᄂ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᄃ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠩึ์ๆ๊ࠦห็ࠣษึูวๅࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤส๊้ࠡษ็้อืๅอࠢ็็๏ฺ๊ࠦำไࠤฬ๊ๅษำ่ะࠥษ๊็๋้ࠢฯ๏้ࠠๅํๅࠥ๎ไๆษำหࠥำีๅฬ๋ࠣีํࠠศๆุ่่๊ษࠡๆฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ่ࠦๅษࠣ๎ุะื๋฻ࠣหฺ๊วฮุ่่๊ࠢษ๊๊ࠡ์๊ࠥวࠡ์฼ีๆࠦใ๋ใࠣ฼์ืส๊ࠡ็้ฬึวฺ๊ࠡีฯ่ࠦๆฬ์ࠤ฽ํัห๊ࠢิ์ࠦวๅ็ื็้ฯࠠ࠯๊่ࠢࠥะั๋ัࠣวึูวๅࠢสุ่าไࠡมࠪᄄ"))
	if o07Z1tEB4n3ARCkVNu==SO94xq1RAkMm2uF(u"࠲ᚬ"): gIQPxaThXNYtL = SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭ᄅ")
	else:
		aHKzv76JCVnprbY8w(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᄆ"),p72fnFtcPix5UKwr9YNzW(u"ࠬ࠭ᄇ"),LiRcTVUWuth70DmPy(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᄈ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟อ้ࠥหไ฻ษฤࠤสืำศๆࠣห้ิืฤ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲ้ษๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษ๋่ࠢฬ๊ࠦิฬฺ๎฾ࠦลึๆสัࠥอไฯูฦࠤอี่็ࠢึะ้ࠦวๅลั฻ฬวࠠศๆำ๎๋ࠥให๊หࠤๆ๐็ࠡฮ่๎฾ࠦสโษุ๎้ࠦ็ัษࠣห้ิืฤ๋ࠢ฾๏ื็ࠡ็้ࠤฬ๊รฯูสลࠬᄉ"))
		return
	oCrTtRIykV4E9fuKnBGW = Fn0w34LmWCA7cVS
	from WWXqeaw1TE import StXADUfOBwG413slo8VkK
	Tr8iRxJmbcEhftU5DSHzA = StXADUfOBwG413slo8VkK(E6MIKdpBomef(u"ࠨࡇࡵࡶࡴࡸࡳࠨᄊ"),oCrTtRIykV4E9fuKnBGW,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࡗࡶࡺ࡫៛"),Cu1704YofAbr3QTm(u"ࠩࠪᄋ"),wRxoKs10Syj7V4edYhtP(u"ࠪࡉࡒࡇࡉࡍ࠯ࡉࡖࡔࡓ࠭ࡔࡊࡒ࡛ࡤࡋࡘࡊࡖࡢࡉࡗࡘࡏࡓࡕࠪᄌ"),gIQPxaThXNYtL)
	if Tr8iRxJmbcEhftU5DSHzA and gIQPxaThXNYtL:
		vGrJ0pECFZtKSlI7DbXyT6daBc.append(OmiEFfPARjG9MK2bLZNr)
		Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,lc0dpSmwoPDjLnk(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧᄍ"),p72fnFtcPix5UKwr9YNzW(u"ࠬࡇࡌࡍࡡࡖࡉࡓ࡚࡟ࡆࡔࡕࡓࡗ࡙ࠧᄎ"),vGrJ0pECFZtKSlI7DbXyT6daBc,GOhVkMATsg4cJmfa0Enp6zSqCr)
	return
def d6dnfitqo7zQU9mNpJTwxEF3(rKagANTOtGJnhVWfE2BHpePYC3IQ5l):
	if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: rKagANTOtGJnhVWfE2BHpePYC3IQ5l = rKagANTOtGJnhVWfE2BHpePYC3IQ5l.encode(FnBiAjthS8MkXs67W(u"࠭ࡵࡵࡨ࠻ࠫᄏ"))
	TQ7XxCh6E4quszI1cornewB = wRxoKs10Syj7V4edYhtP(u"ࠧࡴ࠼࡟ࡠ࠵࠶࠰࠱ࡧࡰࡥࡩࡥࠧᄐ")+str(MQbODJoPV2w8TEAg4zXZdjLxSW.time())+bUdr5Hahw6sY8xJ(u"ࠨ࠰ࡧࡥࡹ࠭ᄑ")
	open(TQ7XxCh6E4quszI1cornewB,G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩࡺࡦࠬᄒ")).write(rKagANTOtGJnhVWfE2BHpePYC3IQ5l)
	return
def AE8MedoFXQNrYhRvW(nXl0o4fesWvCbZ):
	if nXl0o4fesWvCbZ:
		LysGAMozW185TVxl = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,hBvsQ7oCkKUdwjx58ml3EN(u"ࠪࡰ࡮ࡹࡴࠨᄓ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧᄔ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨᄕ"))
		if LysGAMozW185TVxl: return LysGAMozW185TVxl
	mHejXxkvM1qCESPVRy54QB = oSVpce1UQYrDqhuM6PT[XzrqbGDIy54juixkMA(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ᄖ")][XzrqbGDIy54juixkMA(u"࠷ᚭ")]
	exOIZnGECcR2p3WV4TPY06BNDo7 = PW2xo0Kq3Tcprj9Ck(LiRcTVUWuth70DmPy(u"࠶࠶ᚮ"),nXl0o4fesWvCbZ)
	Ld4oBuRD29JgTmZcMkH16 = T0U4fwNGiQ()
	CP2iXvM97DK6ZcNwFl8B = Ld4oBuRD29JgTmZcMkH16.split(iRoLg2m47tnDATBHGCSPNyx(u"ࠧ࠭ࠩᄗ"))[wRxoKs10Syj7V4edYhtP(u"࠶ᚯ")]
	otBJSYa3V2 = WpgZTyqoMAPhwGiXF.path.join(bdmxngE9YGIeQ,yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧᄘ"))
	eekAMBjifC5qOXI09tKhu = q35weK2bNsDmQ()
	ojS2y3cRDf = {lc0dpSmwoPDjLnk(u"ࠩࡸࡷࡪࡸࠧᄙ"):exOIZnGECcR2p3WV4TPY06BNDo7,Me28A1sBLNIgUp5YCDyvT(u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫᄚ"):mmn0lB2tFI7XTgVfESo,yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬᄛ"):CP2iXvM97DK6ZcNwFl8B,yA5z6LIXBlo41PRVMY87wOisFp(u"ࠬ࡯ࡤࡴࠩᄜ"):njglTZ1qzxm9K70U2(eekAMBjifC5qOXI09tKhu)}
	YutQm2AwozR9VKp4O1lWj8FaryI = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,UTelCo0ihE1d5R(u"࠭ࡐࡐࡕࡗࠫᄝ"),mHejXxkvM1qCESPVRy54QB,ojS2y3cRDf,hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠧࠨᄞ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠨࠩᄟ"),kEhAHvti6Vnsfx(u"ࠩࠪᄠ"),Cu1704YofAbr3QTm(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡓࡘࡉࡘ࡚ࡉࡐࡐࡖ࠱࠶ࡹࡴࠨᄡ"))
	LysGAMozW185TVxl = []
	if YutQm2AwozR9VKp4O1lWj8FaryI.succeeded:
		U9rSWyc74gLOw = YutQm2AwozR9VKp4O1lWj8FaryI.content
		LysGAMozW185TVxl = U9rSWyc74gLOw.replace(xW2Arao7YVOemw(u"ࠫࡡࡢࡲࠨᄢ"),dshJSmRqeiP9nap2(u"ࠬࡢ࡮ࠨᄣ")).replace(iRoLg2m47tnDATBHGCSPNyx(u"࠭࡜࡝ࡰࠪᄤ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧ࡝ࡰࠪᄥ")).replace(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠨ࡞ࡵࡠࡳ࠭ᄦ"),p72fnFtcPix5UKwr9YNzW(u"ࠩ࡟ࡲࠬᄧ")).replace(p72fnFtcPix5UKwr9YNzW(u"ࠪࡠࡷ࠭ᄨ"),xW2Arao7YVOemw(u"ࠫࡡࡴࠧᄩ"))
		LysGAMozW185TVxl = GGvHJKP9LUxEk10Fw.findall(XzrqbGDIy54juixkMA(u"࡙ࠬࡔࡂࡔࡗ࠾࠿࡙ࡔࡂࡔࡗ࠾࠿࠮࡜ࡥ࠭ࠬ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴࡅࡏࡆ࠽࠾ࡊࡔࡄࠨᄪ"),LysGAMozW185TVxl,GGvHJKP9LUxEk10Fw.DOTALL)
		if LysGAMozW185TVxl:
			LysGAMozW185TVxl = sorted(LysGAMozW185TVxl,reverse=bUdr5Hahw6sY8xJ(u"ࡊࡦࡲࡳࡦៜ"),key=lambda key: int(key[hBvsQ7oCkKUdwjx58ml3EN(u"࠵ᚰ")]))
			ESIi4D0MAgOCWT3Rwobfq5Yh,exOIZnGECcR2p3WV4TPY06BNDo7,Tg1CAnZtj9MNe5wS,RuSqTgGZ7tlerwK9pWYf16Ln,tcopCZGnbdvY8r,r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6 = LysGAMozW185TVxl[SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠶ᚱ")]
			xSqB9r4GnafdpcH3uKRze = r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6 if bkHiCyWXjdgvF9xE1DA6wQ48(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࡍࡕ࠲࠸ࡌ࡝࠶࡬ࡕࡖࡈࡊࡓ࡙ࡕࡏࡨࡘࡉ࡛࡙ࡓࡖ࠻ࡈ࡜ࠬᄫ")) else Tg1CAnZtj9MNe5wS
			jHevARrF7lS.setSetting(bUdr5Hahw6sY8xJ(u"ࠧࡢࡸ࠱ࡴࡪࡸࡩࡰࡦ࠱࡭ࡳ࡬࡯ࡴࠩᄬ"),xSqB9r4GnafdpcH3uKRze)
			Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,g4g6bfkPtVGU5lIM3(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫᄭ"),lc0dpSmwoPDjLnk(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬᄮ"),LysGAMozW185TVxl,Oa8xvPtmLZkBA43K0EzrdhXS)
			jHevARrF7lS.setSetting(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬᄯ"),njglTZ1qzxm9K70U2(MMHpSTojGILfZXWeCOPyn4))
	return LysGAMozW185TVxl
def sYD4E2xX9MWFrGC6jJbOq(t17im2xFfVTW34jAauvlU9,G5kP43aLFqfAEw6WbtQ=oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠰ᚲ"),vfnekBN2miEasLZtjq=oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠰ᚲ")):
	if G5kP43aLFqfAEw6WbtQ and not vfnekBN2miEasLZtjq: vfnekBN2miEasLZtjq = len(t17im2xFfVTW34jAauvlU9)//G5kP43aLFqfAEw6WbtQ
	Ubtm1fpcnPWlrNg2HJTki7xLM,CQMipytPbq,W6qVfHashAInl = [],-yA5z6LIXBlo41PRVMY87wOisFp(u"࠲ᚳ"),sTcr7iDp5eFt4RoLMhuwq1A(u"࠲ᚴ")
	for fPpK27Cej9wqutr0 in t17im2xFfVTW34jAauvlU9:
		if W6qVfHashAInl%vfnekBN2miEasLZtjq==oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠳ᚵ"):
			CQMipytPbq += iRoLg2m47tnDATBHGCSPNyx(u"࠵ᚶ")
			Ubtm1fpcnPWlrNg2HJTki7xLM.append([])
		Ubtm1fpcnPWlrNg2HJTki7xLM[CQMipytPbq].append(fPpK27Cej9wqutr0)
		W6qVfHashAInl += lc0dpSmwoPDjLnk(u"࠶ᚷ")
	return Ubtm1fpcnPWlrNg2HJTki7xLM
def wwhPIOYUBxKNiu3tvl(TQ7XxCh6E4quszI1cornewB,rKagANTOtGJnhVWfE2BHpePYC3IQ5l):
	GGb8Hsk2rSt9B = WpgZTyqoMAPhwGiXF.path.join(JXUQZHLxEgTFbrRC7n9,TQ7XxCh6E4quszI1cornewB)
	if wRxoKs10Syj7V4edYhtP(u"࠷ᚸ") or UTelCo0ihE1d5R(u"ࠫࡎࡖࡔࡗࡡࠪᄰ") not in TQ7XxCh6E4quszI1cornewB or l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬࡓ࠳ࡖࡡࠪᄱ") not in TQ7XxCh6E4quszI1cornewB: fH8bDPV6AceuCFNO0Ert7oq3p = str(rKagANTOtGJnhVWfE2BHpePYC3IQ5l)
	else:
		Ubtm1fpcnPWlrNg2HJTki7xLM = sYD4E2xX9MWFrGC6jJbOq(rKagANTOtGJnhVWfE2BHpePYC3IQ5l,hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠸ᚹ"))
		fH8bDPV6AceuCFNO0Ert7oq3p = FnBiAjthS8MkXs67W(u"࠭ࠧᄲ")
		for QImDTGKdFWkn1V in Ubtm1fpcnPWlrNg2HJTki7xLM:
			fH8bDPV6AceuCFNO0Ert7oq3p += str(QImDTGKdFWkn1V)+Me28A1sBLNIgUp5YCDyvT(u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭ᄳ")
		fH8bDPV6AceuCFNO0Ert7oq3p = fH8bDPV6AceuCFNO0Ert7oq3p.strip(E6MIKdpBomef(u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧᄴ"))
	B59B8UZ32g40KMuHOPJjAihNeIVdS = qYMC32PGUjsnfDtpzg5I.compress(fH8bDPV6AceuCFNO0Ert7oq3p)
	open(GGb8Hsk2rSt9B,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩࡺࡦࠬᄵ")).write(B59B8UZ32g40KMuHOPJjAihNeIVdS)
	return
def mkXDSzgwV9Ol7T0b26KuLhnq(AABznaCO5Hxd8Ig,TQ7XxCh6E4quszI1cornewB):
	if AABznaCO5Hxd8Ig==iUeoLOsbHqP(u"ࠪࡨ࡮ࡩࡴࠨᄶ"): rKagANTOtGJnhVWfE2BHpePYC3IQ5l = {}
	elif AABznaCO5Hxd8Ig==bUdr5Hahw6sY8xJ(u"ࠫࡱ࡯ࡳࡵࠩᄷ"): rKagANTOtGJnhVWfE2BHpePYC3IQ5l = []
	elif AABznaCO5Hxd8Ig==E6MIKdpBomef(u"ࠬࡹࡴࡳࠩᄸ"): rKagANTOtGJnhVWfE2BHpePYC3IQ5l = S4SOKF2QbBhjCd3RrVMuHIzE(u"࠭ࠧᄹ")
	elif AABznaCO5Hxd8Ig==lc0dpSmwoPDjLnk(u"ࠧࡪࡰࡷࠫᄺ"): rKagANTOtGJnhVWfE2BHpePYC3IQ5l = hBvsQ7oCkKUdwjx58ml3EN(u"࠱ᚺ")
	else: rKagANTOtGJnhVWfE2BHpePYC3IQ5l = None
	GGb8Hsk2rSt9B = WpgZTyqoMAPhwGiXF.path.join(JXUQZHLxEgTFbrRC7n9,TQ7XxCh6E4quszI1cornewB)
	B59B8UZ32g40KMuHOPJjAihNeIVdS = open(GGb8Hsk2rSt9B,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࡴࡥࠫᄻ")).read()
	fH8bDPV6AceuCFNO0Ert7oq3p = qYMC32PGUjsnfDtpzg5I.decompress(B59B8UZ32g40KMuHOPJjAihNeIVdS)
	if hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨᄼ") not in fH8bDPV6AceuCFNO0Ert7oq3p: rKagANTOtGJnhVWfE2BHpePYC3IQ5l = eval(fH8bDPV6AceuCFNO0Ert7oq3p)
	else:
		Ubtm1fpcnPWlrNg2HJTki7xLM = fH8bDPV6AceuCFNO0Ert7oq3p.split(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠪࡠࡳࡢ࡮࠾࠿ࡀࡁࡡࡴ࡜࡯ࠩᄽ"))
		del fH8bDPV6AceuCFNO0Ert7oq3p
		rKagANTOtGJnhVWfE2BHpePYC3IQ5l = []
		DDfE4V8aHNO0qIc = eWia5rknYzHm0J()
		ESIi4D0MAgOCWT3Rwobfq5Yh = p72fnFtcPix5UKwr9YNzW(u"࠲ᚻ")
		for QImDTGKdFWkn1V in Ubtm1fpcnPWlrNg2HJTki7xLM:
			DDfE4V8aHNO0qIc.ZgHxVpFyBDAibfOlo4(str(ESIi4D0MAgOCWT3Rwobfq5Yh),eval,QImDTGKdFWkn1V)
			ESIi4D0MAgOCWT3Rwobfq5Yh += p72fnFtcPix5UKwr9YNzW(u"࠴ᚼ")
		del Ubtm1fpcnPWlrNg2HJTki7xLM
		DDfE4V8aHNO0qIc.qzUOT2k8StRbuF()
		DDfE4V8aHNO0qIc.EyUZYbCF4vXNfO6HzTx()
		MWN0nKVeyq = list(DDfE4V8aHNO0qIc.resultsDICT.keys())
		wlvNZIUYHb6ReDA5xhjJTnk0Qm = sorted(MWN0nKVeyq,reverse=yA5z6LIXBlo41PRVMY87wOisFp(u"ࡋࡧ࡬ࡴࡧ៝"),key=lambda key: int(key))
		for ESIi4D0MAgOCWT3Rwobfq5Yh in wlvNZIUYHb6ReDA5xhjJTnk0Qm:
			rKagANTOtGJnhVWfE2BHpePYC3IQ5l += DDfE4V8aHNO0qIc.resultsDICT[ESIi4D0MAgOCWT3Rwobfq5Yh]
	return rKagANTOtGJnhVWfE2BHpePYC3IQ5l
def th15ipy0aSBFXDl39NgzVJjLmCwM(ssZLBRtgnMkc7dSouQeGCx3r8m):
	DAM97GRvZU38ezaE4SlFoIXOwJ = WpgZTyqoMAPhwGiXF.path.join(mjaho7R5dY6eg,E6MIKdpBomef(u"ࠫࡦࡪࡤࡰࡰࡶࠫᄾ"),ssZLBRtgnMkc7dSouQeGCx3r8m,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬࡧࡤࡥࡱࡱ࠲ࡽࡳ࡬ࠨᄿ"))
	try: giAJF2b3nLYEHBs59zuwSk = open(DAM97GRvZU38ezaE4SlFoIXOwJ,p72fnFtcPix5UKwr9YNzW(u"࠭ࡲࡣࠩᅀ")).read()
	except:
		hA59nJkuRjdXoQebMPpD = WpgZTyqoMAPhwGiXF.path.join(E30Sy9afZK8Rd1uV4PkM2zLW,l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧࡢࡦࡧࡳࡳࡹࠧᅁ"),ssZLBRtgnMkc7dSouQeGCx3r8m,zqdvcbP5L8BHh(u"ࠨࡣࡧࡨࡴࡴ࠮ࡹ࡯࡯ࠫᅂ"))
		try: giAJF2b3nLYEHBs59zuwSk = open(hA59nJkuRjdXoQebMPpD,S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠩࡵࡦࠬᅃ")).read()
		except: return E6MIKdpBomef(u"ࠪࠫᅄ"),[]
	if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: giAJF2b3nLYEHBs59zuwSk = giAJF2b3nLYEHBs59zuwSk.decode(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫࡺࡺࡦ࠹ࠩᅅ"))
	OaCRlXBefQSxtq = GGvHJKP9LUxEk10Fw.findall(iUeoLOsbHqP(u"ࠬ࡯ࡤ࠾࠰࠭ࡃࡻ࡫ࡲࡴ࡫ࡲࡲࡂࡡ࡜ࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࡠࠧࡢࠧ࡞ࠩᅆ"),giAJF2b3nLYEHBs59zuwSk,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.IGNORECASE)
	if not OaCRlXBefQSxtq: return Cu1704YofAbr3QTm(u"࠭ࠧᅇ"),[]
	DQsCdE3gli,HQgrRlDtNs = OaCRlXBefQSxtq[xW2Arao7YVOemw(u"࠴ᚽ")],nFIDUxebY52cj(OaCRlXBefQSxtq[xW2Arao7YVOemw(u"࠴ᚽ")])
	return DQsCdE3gli,HQgrRlDtNs
def OXFK49ofkhE6HJ3iyZ7LVdBMTtWx():
	nYc8QD0VLxqlm = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,E6MIKdpBomef(u"ࠧࡥ࡫ࡦࡸࠬᅈ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫᅉ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪᅊ"))
	if nYc8QD0VLxqlm: return nYc8QD0VLxqlm
	SSGYdpQ6vDK,nYc8QD0VLxqlm = {},{}
	bGt42uU18OeQ3FwxRCz5YS6v = [oSVpce1UQYrDqhuM6PT[E6MIKdpBomef(u"ࠪࡖࡊࡖࡏࡔࠩᅋ")][xW2Arao7YVOemw(u"࠵ᚾ")]]
	if yMvF9GoTjhU5biA>oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠱࠸࠰࠼࠽ᛀ"): bGt42uU18OeQ3FwxRCz5YS6v.append(oSVpce1UQYrDqhuM6PT[l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫࡗࡋࡐࡐࡕࠪᅌ")][QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠷ᚿ")])
	if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: bGt42uU18OeQ3FwxRCz5YS6v.append(oSVpce1UQYrDqhuM6PT[p72fnFtcPix5UKwr9YNzW(u"ࠬࡘࡅࡑࡑࡖࠫᅍ")][QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠳ᛁ")])
	for Wl8GH3iamAu in bGt42uU18OeQ3FwxRCz5YS6v:
		YutQm2AwozR9VKp4O1lWj8FaryI = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,wRxoKs10Syj7V4edYhtP(u"࠭ࡇࡆࡖࠪᅎ"),Wl8GH3iamAu,lc0dpSmwoPDjLnk(u"ࠧࠨᅏ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠨࠩᅐ"),wRxoKs10Syj7V4edYhtP(u"ࠩࠪᅑ"),xW2Arao7YVOemw(u"ࠪࠫᅒ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡂࡆࡢࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏ࠱࠶ࡹࡴࠨᅓ"))
		if YutQm2AwozR9VKp4O1lWj8FaryI.succeeded:
			U9rSWyc74gLOw = YutQm2AwozR9VKp4O1lWj8FaryI.content
			AmZ0YvUjIxhBRCb6z = Wl8GH3iamAu.rsplit(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠬ࠵ࠧᅔ"),SO94xq1RAkMm2uF(u"࠳ᛂ"))[SO94xq1RAkMm2uF(u"࠳ᛃ")]
			azV8ZM9vDOF3jwiU60P5shWkYebT = GGvHJKP9LUxEk10Fw.findall(SO94xq1RAkMm2uF(u"࠭ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡼࡥࡳࡵ࡬ࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᅕ"),U9rSWyc74gLOw,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.IGNORECASE)
			for ssZLBRtgnMkc7dSouQeGCx3r8m,yRKG6vQPfZTaVxdU5ElO2381s in azV8ZM9vDOF3jwiU60P5shWkYebT:
				JubX4LRcBUWYgvD2yM8ide1r = AmZ0YvUjIxhBRCb6z+wRxoKs10Syj7V4edYhtP(u"ࠧ࠰ࠩᅖ")+ssZLBRtgnMkc7dSouQeGCx3r8m+LiRcTVUWuth70DmPy(u"ࠨ࠱ࠪᅗ")+ssZLBRtgnMkc7dSouQeGCx3r8m+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩ࠰ࠫᅘ")+yRKG6vQPfZTaVxdU5ElO2381s+zqdvcbP5L8BHh(u"ࠪ࠲ࡿ࡯ࡰࠨᅙ")
				if ssZLBRtgnMkc7dSouQeGCx3r8m not in list(SSGYdpQ6vDK.keys()):
					SSGYdpQ6vDK[ssZLBRtgnMkc7dSouQeGCx3r8m] = []
					nYc8QD0VLxqlm[ssZLBRtgnMkc7dSouQeGCx3r8m] = []
				ACInbShyG6dHxsLalMPNBmXkVUzT = nFIDUxebY52cj(yRKG6vQPfZTaVxdU5ElO2381s)
				SSGYdpQ6vDK[ssZLBRtgnMkc7dSouQeGCx3r8m].append((yRKG6vQPfZTaVxdU5ElO2381s,ACInbShyG6dHxsLalMPNBmXkVUzT,JubX4LRcBUWYgvD2yM8ide1r))
	for ssZLBRtgnMkc7dSouQeGCx3r8m in list(SSGYdpQ6vDK.keys()):
		nYc8QD0VLxqlm[ssZLBRtgnMkc7dSouQeGCx3r8m] = sorted(SSGYdpQ6vDK[ssZLBRtgnMkc7dSouQeGCx3r8m],reverse=pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࡚ࡲࡶࡧ៞"),key=lambda key: key[XzrqbGDIy54juixkMA(u"࠵ᛄ")])
	Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,FvNyZqaLKw(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧᅚ"),g4g6bfkPtVGU5lIM3(u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭ᅛ"),nYc8QD0VLxqlm,Oa8xvPtmLZkBA43K0EzrdhXS)
	return nYc8QD0VLxqlm
def nFIDUxebY52cj(yRKG6vQPfZTaVxdU5ElO2381s):
	ACInbShyG6dHxsLalMPNBmXkVUzT = []
	Ui4p5bTRlZmx7nM8qy9FAPXdcYwof = yRKG6vQPfZTaVxdU5ElO2381s.split(p72fnFtcPix5UKwr9YNzW(u"࠭࠮ࠨᅜ"))
	for Sfug7s90teZTcO in Ui4p5bTRlZmx7nM8qy9FAPXdcYwof:
		WWkmY9jq7baZe5X0Hs = GGvHJKP9LUxEk10Fw.findall(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠧ࡝ࡦ࠮ࢀࡠࡢࠫ࡝࠯ࡤ࠱ࡿࡇ࡛࠭࡟࠮ࠫᅝ"),Sfug7s90teZTcO,GGvHJKP9LUxEk10Fw.DOTALL)
		mSrZBczouY9LA1D3Tlt = []
		for bbiz6OVqG5kajLe0M in WWkmY9jq7baZe5X0Hs:
			if bbiz6OVqG5kajLe0M.isdigit(): bbiz6OVqG5kajLe0M = int(bbiz6OVqG5kajLe0M)
			mSrZBczouY9LA1D3Tlt.append(bbiz6OVqG5kajLe0M)
		ACInbShyG6dHxsLalMPNBmXkVUzT.append(mSrZBczouY9LA1D3Tlt)
	return ACInbShyG6dHxsLalMPNBmXkVUzT
def Vk7bl30SKQfhr4XH(ACInbShyG6dHxsLalMPNBmXkVUzT):
	yRKG6vQPfZTaVxdU5ElO2381s = hBvsQ7oCkKUdwjx58ml3EN(u"ࠨࠩᅞ")
	for Sfug7s90teZTcO in ACInbShyG6dHxsLalMPNBmXkVUzT:
		for bbiz6OVqG5kajLe0M in Sfug7s90teZTcO: yRKG6vQPfZTaVxdU5ElO2381s += str(bbiz6OVqG5kajLe0M)
		yRKG6vQPfZTaVxdU5ElO2381s += iUeoLOsbHqP(u"ࠩ࠱ࠫᅟ")
	yRKG6vQPfZTaVxdU5ElO2381s = yRKG6vQPfZTaVxdU5ElO2381s.strip(fprnld4CZo(u"ࠪ࠲ࠬᅠ"))
	return yRKG6vQPfZTaVxdU5ElO2381s
def AwsCLr4K3zH1P6tg5cYxQJB7doFm(x8XIHdjPEoO4ezq51lwySr):
	YEROUgQ5Gkj1 = {}
	SSGYdpQ6vDK = OXFK49ofkhE6HJ3iyZ7LVdBMTtWx()
	mMOClDfZqYG42pVQtivPjN = wwCQF2Y0J5ZGg(x8XIHdjPEoO4ezq51lwySr)
	for ssZLBRtgnMkc7dSouQeGCx3r8m in x8XIHdjPEoO4ezq51lwySr:
		if ssZLBRtgnMkc7dSouQeGCx3r8m not in list(SSGYdpQ6vDK.keys()): continue
		nYc8QD0VLxqlm = SSGYdpQ6vDK[ssZLBRtgnMkc7dSouQeGCx3r8m]
		GujSHsyZOqkoWm8B7nLaXd9MpKPcUY,ViO2eHTQ0zIuwmKJ7gq4P,G30myqcjOuXhJHfK4 = nYc8QD0VLxqlm[hBvsQ7oCkKUdwjx58ml3EN(u"࠵ᛅ")]
		j0EsA2ZPvQrC,txZLfeKroOcXwy4gnF70B = th15ipy0aSBFXDl39NgzVJjLmCwM(ssZLBRtgnMkc7dSouQeGCx3r8m)
		cxb5RACHZY30rdfw9NE1,UU2A3ZKcRnv = mMOClDfZqYG42pVQtivPjN[ssZLBRtgnMkc7dSouQeGCx3r8m]
		MMjs1arRfBiFenDL4ulg5b = ViO2eHTQ0zIuwmKJ7gq4P>txZLfeKroOcXwy4gnF70B and cxb5RACHZY30rdfw9NE1
		CUjgrXvYcl71xbIV5TWkzfBonD = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࡔࡳࡷࡨ៟")
		if not cxb5RACHZY30rdfw9NE1: L5VnDolF9OviImp6dJrEB2huy = E6MIKdpBomef(u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬᅡ")
		elif not UU2A3ZKcRnv: L5VnDolF9OviImp6dJrEB2huy = yA5z6LIXBlo41PRVMY87wOisFp(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧᅢ")
		elif MMjs1arRfBiFenDL4ulg5b: L5VnDolF9OviImp6dJrEB2huy = lc0dpSmwoPDjLnk(u"࠭࡯࡭ࡦࠪᅣ")
		else:
			L5VnDolF9OviImp6dJrEB2huy = zqdvcbP5L8BHh(u"ࠧࡨࡱࡲࡨࠬᅤ")
			CUjgrXvYcl71xbIV5TWkzfBonD = Cu1704YofAbr3QTm(u"ࡇࡣ࡯ࡷࡪ០")
		YEROUgQ5Gkj1[ssZLBRtgnMkc7dSouQeGCx3r8m] = (CUjgrXvYcl71xbIV5TWkzfBonD,j0EsA2ZPvQrC,txZLfeKroOcXwy4gnF70B,GujSHsyZOqkoWm8B7nLaXd9MpKPcUY,ViO2eHTQ0zIuwmKJ7gq4P,L5VnDolF9OviImp6dJrEB2huy,G30myqcjOuXhJHfK4)
	return YEROUgQ5Gkj1
def FFBJqkrThNeWfiaZPE5Aws9uGdp(dzrSRqtj49so,jWqErvMB2AHZ1,r7MS2UfJghvtDB3a8HA=iUeoLOsbHqP(u"ࠨࠩᅥ"),GNBORki2UMplrcgTHFz6fJ=yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩࠪᅦ"),TF5yMr346tcRA0sjD89IeXN2=iUeoLOsbHqP(u"ࠪࠫᅧ")):
	if HHosl5fRdhtEDAYyP: dzrSRqtj49so.update(jWqErvMB2AHZ1,r7MS2UfJghvtDB3a8HA,GNBORki2UMplrcgTHFz6fJ,TF5yMr346tcRA0sjD89IeXN2)
	else: dzrSRqtj49so.update(jWqErvMB2AHZ1,r7MS2UfJghvtDB3a8HA+wRxoKs10Syj7V4edYhtP(u"ࠫࡡࡴࠧᅨ")+GNBORki2UMplrcgTHFz6fJ+bUdr5Hahw6sY8xJ(u"ࠬࡢ࡮ࠨᅩ")+TF5yMr346tcRA0sjD89IeXN2)
	return
def p0utbN8Uw2yC3qlm96KnxeTVPAIS(xbjuhmSNgZ15dta0vLKFiEG4):
	def LRPjSysTGkcMizuqmpIe80vW(jPaqJ9bTvGwNuyVD5C,fNhyo6e2MYzm8,bMQw8qT3SXZrDnpmGJkFHsEU2C=oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨ࠰࠲࠴࠶࠸࠺࠼࠷࠹࠻ࡤࡦࡨࡪࡥࡧࡩ࡫࡭࡯ࡱ࡬࡮ࡰࡲࡴࡶࡸࡳࡵࡷࡹࡻࡽࡿࡺࡂࡄࡆࡈࡊࡌࡇࡉࡋࡍࡏࡑࡓࡎࡐࡒࡔࡖࡘ࡚ࡕࡗ࡙࡛࡝࡟ࠨᅪ")):
		return ((jPaqJ9bTvGwNuyVD5C == l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠶ᛆ")) and bMQw8qT3SXZrDnpmGJkFHsEU2C[l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠶ᛆ")]) or (LRPjSysTGkcMizuqmpIe80vW(jPaqJ9bTvGwNuyVD5C // fNhyo6e2MYzm8, fNhyo6e2MYzm8, bMQw8qT3SXZrDnpmGJkFHsEU2C).lstrip(bMQw8qT3SXZrDnpmGJkFHsEU2C[l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠶ᛆ")]) + bMQw8qT3SXZrDnpmGJkFHsEU2C[jPaqJ9bTvGwNuyVD5C % fNhyo6e2MYzm8])
	def Z4H1qzL3DWM2uKktOY7Usv(zGvd1Le0P87OHB4DqU3posMZbtJX, rGQvqJk35uZ0atUwRb, MajNPJp5oc2ZYftDHg, gL8xQU3Ja5WVX, AYLTQgVcPebk1CXrMI5in620Gwo9=None, wLsNCkZDPednXF6r1RlB7gEqoQ=None, tevTH534F1NEfDA0WLRMJkIy=None):
		while (MajNPJp5oc2ZYftDHg):
			MajNPJp5oc2ZYftDHg-=xW2Arao7YVOemw(u"࠱ᛇ")
			if (gL8xQU3Ja5WVX[MajNPJp5oc2ZYftDHg]): zGvd1Le0P87OHB4DqU3posMZbtJX = GGvHJKP9LUxEk10Fw.sub(hBvsQ7oCkKUdwjx58ml3EN(u"ࠢ࡝࡞ࡥࠦᅫ") + LRPjSysTGkcMizuqmpIe80vW(MajNPJp5oc2ZYftDHg, rGQvqJk35uZ0atUwRb) + pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠣ࡞࡟ࡦࠧᅬ"),  gL8xQU3Ja5WVX[MajNPJp5oc2ZYftDHg], zGvd1Le0P87OHB4DqU3posMZbtJX)
		return zGvd1Le0P87OHB4DqU3posMZbtJX
	xbjuhmSNgZ15dta0vLKFiEG4 = xbjuhmSNgZ15dta0vLKFiEG4.split(XzrqbGDIy54juixkMA(u"ࠩࢀࠬࠬᅭ"))[g4g6bfkPtVGU5lIM3(u"࠲ᛈ")]
	xbjuhmSNgZ15dta0vLKFiEG4 = xbjuhmSNgZ15dta0vLKFiEG4.rsplit(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࡷࡵࡲࡩࡵࠩᅮ"))[sTcr7iDp5eFt4RoLMhuwq1A(u"࠲ᛉ")]+p72fnFtcPix5UKwr9YNzW(u"ࠦࡸࡶ࡬ࡪࡶࠫࠫࢁ࠭ࠩࠪࠤᅯ")
	PhzBCR0GOkLx4nfuQ = eval(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬࡻ࡮ࡱࡣࡦ࡯࠭࠭ᅰ")+xbjuhmSNgZ15dta0vLKFiEG4,{Me28A1sBLNIgUp5YCDyvT(u"࠭ࡢࡢࡵࡨࡒࠬᅱ"):LRPjSysTGkcMizuqmpIe80vW,dshJSmRqeiP9nap2(u"ࠧࡶࡰࡳࡥࡨࡱࠧᅲ"):Z4H1qzL3DWM2uKktOY7Usv})
	return PhzBCR0GOkLx4nfuQ
def BCTx14IM2b0uqV9GyaWK6zt3m(mHejXxkvM1qCESPVRy54QB,gTAqCv0hX9xemf=hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨࠩᅳ")):
	if gTAqCv0hX9xemf==LiRcTVUWuth70DmPy(u"ࠩ࡯ࡳࡼ࡫ࡲࠨᅴ"): mHejXxkvM1qCESPVRy54QB = GGvHJKP9LUxEk10Fw.sub(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࡵࠫࠪࡡ࠰࠮࠻ࡄ࠱࡟ࡣࡻ࠳ࡿࠪᅵ"),lambda mmfGatjsVYS1ydw0lPzMLQpq4CRA: mmfGatjsVYS1ydw0lPzMLQpq4CRA.group(zqdvcbP5L8BHh(u"࠳ᛊ")).lower(),mHejXxkvM1qCESPVRy54QB)
	elif gTAqCv0hX9xemf==pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࡺࡶࡰࡦࡴࠪᅶ"): mHejXxkvM1qCESPVRy54QB = GGvHJKP9LUxEk10Fw.sub(E6MIKdpBomef(u"ࡷ࠭ࠥ࡜࠲࠰࠽ࡦ࠳ࡺ࡞ࡽ࠵ࢁࠬᅷ"),lambda mmfGatjsVYS1ydw0lPzMLQpq4CRA: mmfGatjsVYS1ydw0lPzMLQpq4CRA.group(bUdr5Hahw6sY8xJ(u"࠴ᛋ")).upper(),mHejXxkvM1qCESPVRy54QB)
	return mHejXxkvM1qCESPVRy54QB
def wwCQF2Y0J5ZGg(x8XIHdjPEoO4ezq51lwySr):
	sWp6G5tqEcyQLmIVR8zxnJ,lya2TNSdzEF = iRoLg2m47tnDATBHGCSPNyx(u"ࡈࡤࡰࡸ࡫១"),iRoLg2m47tnDATBHGCSPNyx(u"ࡈࡤࡰࡸ࡫១")
	QAlb96UhsVG = j5cfNmnkuUA.connect(QLmA1IVR5dvG)
	QAlb96UhsVG.text_factory = str
	PYRN3CLTut = QAlb96UhsVG.cursor()
	if len(x8XIHdjPEoO4ezq51lwySr)==FnBiAjthS8MkXs67W(u"࠶ᛌ"): X5X3GL7kmCJwKlibIdyuqjcx = SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࠨࠣࠩᅸ")+x8XIHdjPEoO4ezq51lwySr[zqdvcbP5L8BHh(u"࠶ᛍ")]+yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧࠣࠫࠪᅹ")
	else: X5X3GL7kmCJwKlibIdyuqjcx = str(tuple(x8XIHdjPEoO4ezq51lwySr))
	PYRN3CLTut.execute(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࡕࡈࡐࡊࡉࡔࠡࡣࡧࡨࡴࡴࡉࡅ࠮ࡨࡲࡦࡨ࡬ࡦࡦࠣࡊࡗࡕࡍࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡎࡔࠠࠨᅺ")+X5X3GL7kmCJwKlibIdyuqjcx+XzrqbGDIy54juixkMA(u"ࠩࠣ࠿ࠬᅻ"))
	NOpl1LBIvGax8oHDbj9 = PYRN3CLTut.fetchall()
	mMOClDfZqYG42pVQtivPjN = {}
	for ssZLBRtgnMkc7dSouQeGCx3r8m in x8XIHdjPEoO4ezq51lwySr: mMOClDfZqYG42pVQtivPjN[ssZLBRtgnMkc7dSouQeGCx3r8m] = (fprnld4CZo(u"ࡉࡥࡱࡹࡥ២"),fprnld4CZo(u"ࡉࡥࡱࡹࡥ២"))
	for ssZLBRtgnMkc7dSouQeGCx3r8m,lya2TNSdzEF in NOpl1LBIvGax8oHDbj9:
		sWp6G5tqEcyQLmIVR8zxnJ = G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࡘࡷࡻࡥ៣")
		lya2TNSdzEF = lya2TNSdzEF==p72fnFtcPix5UKwr9YNzW(u"࠱ᛎ")
		mMOClDfZqYG42pVQtivPjN[ssZLBRtgnMkc7dSouQeGCx3r8m] = (sWp6G5tqEcyQLmIVR8zxnJ,lya2TNSdzEF)
	QAlb96UhsVG.close()
	return mMOClDfZqYG42pVQtivPjN
def iiZBqA90yC(CESIzlW2YjMJck9ZuhXvfdTym0e):
	zpXG3Ky6ou8ndWHkb4 = XzrqbGDIy54juixkMA(u"ࠪࠫᅼ")
	if WpgZTyqoMAPhwGiXF.path.exists(CESIzlW2YjMJck9ZuhXvfdTym0e):
		aeYlBOMguvy = open(CESIzlW2YjMJck9ZuhXvfdTym0e,XzrqbGDIy54juixkMA(u"ࠫࡷࡨࠧᅽ")).read()
		if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: aeYlBOMguvy = aeYlBOMguvy.decode(dshJSmRqeiP9nap2(u"ࠬࡻࡴࡧ࠺ࠪᅾ"))
		LTkDi4xOgXR = JKw5OWktPZB(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭ࡤࡪࡥࡷࠫᅿ"),aeYlBOMguvy)
		if LTkDi4xOgXR:
			zpXG3Ky6ou8ndWHkb4 = {}
			for EptZi8qnKhHSsuWMg5URx6FIkP in LTkDi4xOgXR.keys():
				zpXG3Ky6ou8ndWHkb4[EptZi8qnKhHSsuWMg5URx6FIkP] = []
				for tf71UgNmk3oWF8 in LTkDi4xOgXR[EptZi8qnKhHSsuWMg5URx6FIkP]:
					uI7UAQCyPO85aLonkGqrdWwRt,PPVuQkU9OfiBXegYZK2c3Tl6,mHejXxkvM1qCESPVRy54QB,xUmyzZKOd8hv3Jc5X2nPHCAarW4sF,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,fH8bDPV6AceuCFNO0Ert7oq3p,stpvYViqku3,LGdFZQvKeU52s6H0DgjN = oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧࠨᆀ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨࠩᆁ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠩࠪᆂ"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠪࠫᆃ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠫࠬᆄ"),iRoLg2m47tnDATBHGCSPNyx(u"ࠬ࠭ᆅ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭ࠧᆆ"),zqdvcbP5L8BHh(u"ࠧࠨᆇ"),Cu1704YofAbr3QTm(u"ࠨࠩᆈ")
					uI7UAQCyPO85aLonkGqrdWwRt = tf71UgNmk3oWF8[E6MIKdpBomef(u"࠱ᛏ")]
					PPVuQkU9OfiBXegYZK2c3Tl6 = tf71UgNmk3oWF8[g4g6bfkPtVGU5lIM3(u"࠳ᛐ")]
					PPVuQkU9OfiBXegYZK2c3Tl6 = zQP2wplUqKgLE3DYy6OcoSHJfT8(PPVuQkU9OfiBXegYZK2c3Tl6)
					mHejXxkvM1qCESPVRy54QB = tf71UgNmk3oWF8[hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠵ᛑ")]
					xUmyzZKOd8hv3Jc5X2nPHCAarW4sF = tf71UgNmk3oWF8[hBvsQ7oCkKUdwjx58ml3EN(u"࠷ᛒ")]
					nWO8c3IgspK67QX = tf71UgNmk3oWF8[kEhAHvti6Vnsfx(u"࠹ᛓ")]
					EfNzW3kLhcMTu07HrP28X9nFA6vpGd = tf71UgNmk3oWF8[l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠻ᛔ")]
					if len(tf71UgNmk3oWF8)>g4g6bfkPtVGU5lIM3(u"࠶ᛕ"): fH8bDPV6AceuCFNO0Ert7oq3p = tf71UgNmk3oWF8[g4g6bfkPtVGU5lIM3(u"࠶ᛕ")]
					if len(tf71UgNmk3oWF8)>G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠸ᛖ"): stpvYViqku3 = tf71UgNmk3oWF8[G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠸ᛖ")]
					if len(tf71UgNmk3oWF8)>lc0dpSmwoPDjLnk(u"࠺ᛗ"): LGdFZQvKeU52s6H0DgjN = tf71UgNmk3oWF8[lc0dpSmwoPDjLnk(u"࠺ᛗ")]
					if CESIzlW2YjMJck9ZuhXvfdTym0e==PGIWHNLQuRoK1M: KyHEuCTf27gcaO = uI7UAQCyPO85aLonkGqrdWwRt,PPVuQkU9OfiBXegYZK2c3Tl6,mHejXxkvM1qCESPVRy54QB,xUmyzZKOd8hv3Jc5X2nPHCAarW4sF,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,fH8bDPV6AceuCFNO0Ert7oq3p,yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩࠪᆉ"),LGdFZQvKeU52s6H0DgjN
					else: KyHEuCTf27gcaO = uI7UAQCyPO85aLonkGqrdWwRt,PPVuQkU9OfiBXegYZK2c3Tl6,mHejXxkvM1qCESPVRy54QB,xUmyzZKOd8hv3Jc5X2nPHCAarW4sF,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,fH8bDPV6AceuCFNO0Ert7oq3p,stpvYViqku3,LGdFZQvKeU52s6H0DgjN
					zpXG3Ky6ou8ndWHkb4[EptZi8qnKhHSsuWMg5URx6FIkP].append(KyHEuCTf27gcaO)
		jkum9pHGXvV1TB03Z6ULaAiMJyFKrf = str(zpXG3Ky6ou8ndWHkb4)
		if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: jkum9pHGXvV1TB03Z6ULaAiMJyFKrf = jkum9pHGXvV1TB03Z6ULaAiMJyFKrf.encode(dshJSmRqeiP9nap2(u"ࠪࡹࡹ࡬࠸ࠨᆊ"))
		open(CESIzlW2YjMJck9ZuhXvfdTym0e,oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫࡼࡨࠧᆋ")).write(jkum9pHGXvV1TB03Z6ULaAiMJyFKrf)
	return zpXG3Ky6ou8ndWHkb4
def pdLiwcEWN2o4PQ(jXPWwl4aH0OR9ILzMT5usS):
	Hps9b0ulz3kwtMLvEjPAQXC7hNR = jXPWwl4aH0OR9ILzMT5usS.split(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠬ࠳ࠧᆌ"),iRoLg2m47tnDATBHGCSPNyx(u"࠴ᛘ"))[iRoLg2m47tnDATBHGCSPNyx(u"࠴ᛙ")]
	YOb4ZFenMS08DN6yA3G5,ceL6qDxhFNo7,kUJng2Gx1u7br9Hs8MlFd = SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࠧᆍ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧࠨᆎ"),Me28A1sBLNIgUp5YCDyvT(u"ࠨࠩᆏ")
	if   Hps9b0ulz3kwtMLvEjPAQXC7hNR==G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩࡄࡌ࡜ࡇࡋࠨᆐ")		:	from gW3mOQLz82			import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==g4g6bfkPtVGU5lIM3(u"ࠪࡅࡐࡕࡁࡎࠩᆑ")		:	from iz81jLCMhR			import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==XzrqbGDIy54juixkMA(u"ࠫࡆࡑࡏࡂࡏࡆࡅࡒ࠭ᆒ")	:	from nnTPxkzGRH		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==E6MIKdpBomef(u"ࠬࡇࡋࡘࡃࡐࠫᆓ")		:	from AjTX6bWUoJ			import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==xW2Arao7YVOemw(u"࠭ࡁࡍࡃࡕࡅࡇ࠭ᆔ")	:	from OKoIU8yQVZ			import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧࡂࡎࡉࡅ࡙ࡏࡍࡊࠩᆕ")	:	from mmIsO43ncr		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==lc0dpSmwoPDjLnk(u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕࠫᆖ")	: 	from QQn6S7xVUk		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==XzrqbGDIy54juixkMA(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫᆗ")	:	from WWIBDvHyP1		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓࠨᆘ"):	from keQl9V61Cf	import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==g4g6bfkPtVGU5lIM3(u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭ᆙ")	:	from C7tunkvS8i		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠬࡈࡏࡌࡔࡄࠫᆚ")		:	from PJsSdvbghy			import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==XzrqbGDIy54juixkMA(u"࠭ࡂࡓࡕࡗࡉࡏ࠭ᆛ")	:	from VDGS2iTPuv			import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==fprnld4CZo(u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨᆜ")	:	from yJmzXcP5Fd		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==Cu1704YofAbr3QTm(u"ࠨࡅࡌࡑࡆ࠺ࡕࠨᆝ")	:	from Zb7u6XoB1m			import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==dshJSmRqeiP9nap2(u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫᆞ")	:	from SMNu2OETbA		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==UTelCo0ihE1d5R(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࡜ࡕࡒࡌࠩᆟ"):	from a4G1IBfRoh	import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==fprnld4CZo(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭ᆠ"):		from flQ5A7tGE3		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==LiRcTVUWuth70DmPy(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖࠧᆡ")	:	from SlK7x3yAYL		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==Cu1704YofAbr3QTm(u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨᆢ")	:	from Bdqka8SHjO		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪᆣ")	:	from EZ9Ka24UCG		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==zqdvcbP5L8BHh(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩᆤ")	:	from QTLlPojE20		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧᆥ"):	from Xswr3uEckt	import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==SO94xq1RAkMm2uF(u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫᆦ")	:	from dAoCHcYhxv		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==g4g6bfkPtVGU5lIM3(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘࠬᆧ")	:	from VyYaji521x		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧᆨ")	:	from MgAYQOR7aP		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠲ࠨᆩ")	:	from JuQmsf04rW		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==p72fnFtcPix5UKwr9YNzW(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴ࠩᆪ")	:	from TNlZLgj9Gt		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==iUeoLOsbHqP(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶ࠪᆫ")	:	from glPzHI7LEe		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪᆬ")	:	from SfphHN5F3P		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==lc0dpSmwoPDjLnk(u"ࠪࡉࡌ࡟ࡎࡐ࡙ࠪᆭ")	:	from X89TQqW1jf			import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==SO94xq1RAkMm2uF(u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬᆮ")	:	from OOzxvVlGPU		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==xW2Arao7YVOemw(u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨᆯ")	:	from SY3eVzk80i		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨᆰ")	:	from hGZraoJ5gw		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==fprnld4CZo(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳ࠩᆱ")	:	from gmyxR0jwhs		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨࡈࡒࡗ࡙ࡇࠧᆲ")		:	from Lrye5NGadx			import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫᆳ")	:	from osBuzptTmE		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==dshJSmRqeiP9nap2(u"ࠪࡍࡋࡏࡌࡎࠩᆴ")		:	from nDT6wjrmfZ			import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==bUdr5Hahw6sY8xJ(u"ࠫࡎࡖࡔࡗࠩᆵ")		:	from NYPKIqVcep	import MgXYEzpBGQfveJ3bHm1u as YOb4ZFenMS08DN6yA3G5,tnkSpQrOC9RugmzD2b as ceL6qDxhFNo7,XgvWSQ6o5hzlux8 as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==FvNyZqaLKw(u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨᆶ")	:	from YYS1QvjNMR		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==FvNyZqaLKw(u"࠭ࡋࡂࡖࡎࡓ࡙࡚ࡖࠨᆷ")	:	from fo7FzwInQ0		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==SO94xq1RAkMm2uF(u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆࠩᆸ")	:	from pCYXWusGUJ		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==Cu1704YofAbr3QTm(u"ࠨࡎࡄࡖࡔࡠࡁࠨᆹ")	:	from jTaZm2rxMp			import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪᆺ")	:	from zDNcRtVHBL		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==XzrqbGDIy54juixkMA(u"ࠪࡑ࠸࡛ࠧᆻ")		:	from v8alOxSpJN	import MgXYEzpBGQfveJ3bHm1u as YOb4ZFenMS08DN6yA3G5,tnkSpQrOC9RugmzD2b as ceL6qDxhFNo7,XgvWSQ6o5hzlux8 as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==hBvsQ7oCkKUdwjx58ml3EN(u"ࠫࡒࡕࡖࡔ࠶ࡘࠫᆼ")	:	from rrSL6nj91X			import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==g4g6bfkPtVGU5lIM3(u"ࠬࡓ࡙ࡄࡋࡐࡅࠬᆽ")	:	from vIufSK5zHr			import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==iUeoLOsbHqP(u"࠭ࡐࡂࡐࡈࡘࠬᆾ")		:	from WZhjNqHtoG			import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==iRoLg2m47tnDATBHGCSPNyx(u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩᆿ")	:	from w9VNKsZ824		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==Me28A1sBLNIgUp5YCDyvT(u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗࠬᇀ"):	from IlFb1Es0RA		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==E6MIKdpBomef(u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉࠬᇁ")	:	from hhB3tk7gso		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==iUeoLOsbHqP(u"ࠪࡗࡍࡕࡆࡉࡃࠪᇂ")	:	from dJr4nDP9y3			import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==FvNyZqaLKw(u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭ᇃ")	:	from xAPpLOj9eR		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕࠧᇄ")	:	from qqBmVUYNIA		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==g4g6bfkPtVGU5lIM3(u"࠭ࡔࡗࡈࡘࡒࠬᇅ")		:	from PMfc9b4vXp			import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==p72fnFtcPix5UKwr9YNzW(u"ࠧࡘࡇࡆࡍࡒࡇࠧᇆ")	:	from u2dxD1WamQ			import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨ࡛ࡄࡕࡔ࡚ࠧᇇ")		:	from VtjyB7kOJX			import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪᇈ")	:	from bbPAtUuTEM		import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5,szwTAdaBt4FiXO as ceL6qDxhFNo7,mmDwMlfoHtG5XT19VLIWqCR8i as kUJng2Gx1u7br9Hs8MlFd
	elif Hps9b0ulz3kwtMLvEjPAQXC7hNR==S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠪ࡝࡙ࡈ࡟ࡄࡊࡄࡒࡓࡋࡌࡔࠩᇉ"):	from YLZXgHuiOk	import T2AtWpmSuysJ3BzHVeFY as YOb4ZFenMS08DN6yA3G5
	return YOb4ZFenMS08DN6yA3G5,ceL6qDxhFNo7,kUJng2Gx1u7br9Hs8MlFd
def wwJEoNAiDnIZgYS(cwCzVAXW3DFdoiO6UK0mya,ep9JAOkj1wr5s,showDialogs):
	LOHZ4o9m7p6ebfTYXGIdz5PWs3q(bUdr5Hahw6sY8xJ(u"ࠫࡓࡕࡔࡊࡅࡈࠫᇊ"),fprnld4CZo(u"ࠬ࠴ࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬ࡀࠠ࡜ࠢࠪᇋ")+cwCzVAXW3DFdoiO6UK0mya+SO94xq1RAkMm2uF(u"࠭ࠠ࡞ࠢࠣࠤࡍ࡫ࡡࡥࡧࡵࡷ࠿࡛ࠦࠡࠩᇌ")+str(ep9JAOkj1wr5s)+LiRcTVUWuth70DmPy(u"ࠧࠡ࡟ࠪᇍ"))
	dzrSRqtj49so = XOL34TuqseWy2gpYfd()
	dzrSRqtj49so.create(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᇎ"),SO94xq1RAkMm2uF(u"ࠩํะึ๐ࠠศๆล๊ࠥ็อึࠢส่๊๊แࠡษ็้฼๊่ษࠢอั๊๐ไ่๋ࠢฬ฾ี็ศࠢึ์ๆࠦสษัฦࠤ฾๋ไ๋หࠣะ้ฮࠠศๆ่่ๆࠦๅ็ࠢส่ส์สา่อࠫᇏ"))
	cMR1f3D2UeyrLKXoYVPt8 = SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠶࠶࠲࠵ᛚ")*SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠶࠶࠲࠵ᛚ")
	OOAKlxzEFviaX03heD = LiRcTVUWuth70DmPy(u"࠷ᛛ")*cMR1f3D2UeyrLKXoYVPt8
	YutQm2AwozR9VKp4O1lWj8FaryI = DJ1rx9fvXIgUS7sZkVlOeGHb.get(cwCzVAXW3DFdoiO6UK0mya,stream=SyENPzdOon6uxcLXMhqb14aDlB9r(u"࡙ࡸࡵࡦ៤"),headers=ep9JAOkj1wr5s)
	qDtkRfYzop2j1USNEbOnx79da5ZIAe = YutQm2AwozR9VKp4O1lWj8FaryI.headers
	YutQm2AwozR9VKp4O1lWj8FaryI.close()
	bXdjnWpckF2h6iY3zUavgSBHA = bytes()
	if not qDtkRfYzop2j1USNEbOnx79da5ZIAe:
		if showDialogs: aHKzv76JCVnprbY8w(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࠫᇐ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࠬᇑ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᇒ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭วๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏ะๅไ่้๋ࠣࠦสฮ็ํ่ࠥอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥ๎วๅีหฬ่ࠥฯࠡ์ๆ์ู๋ࠦ็ัๆࠤฺ๊ใๅหࠣๅ๏ࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅࠣ࠲ࠥาัษࠢอั๊๐ไࠡษ็้้็ࠠๆำฬࠤศิั๊ࠩᇓ"))
		dzrSRqtj49so.close()
	else:
		if fprnld4CZo(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨᇔ") not in list(qDtkRfYzop2j1USNEbOnx79da5ZIAe.keys()): edsrQyH6L29Db = FvNyZqaLKw(u"࠰ᛜ")
		else: edsrQyH6L29Db = int(qDtkRfYzop2j1USNEbOnx79da5ZIAe[FnBiAjthS8MkXs67W(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩᇕ")])
		tV4NTJHwly = str(int(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠳࠳࠴࠵ᛞ")*edsrQyH6L29Db/cMR1f3D2UeyrLKXoYVPt8)/FvNyZqaLKw(u"࠲࠲࠳࠴࠳࠶ᛝ"))
		dac3D2xo6WPu = int(edsrQyH6L29Db/OOAKlxzEFviaX03heD)+iRoLg2m47tnDATBHGCSPNyx(u"࠴ᛟ")
		if iUeoLOsbHqP(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡖࡦࡴࡧࡦࠩᇖ") in list(qDtkRfYzop2j1USNEbOnx79da5ZIAe.keys()) and edsrQyH6L29Db>cMR1f3D2UeyrLKXoYVPt8:
			zhGPpZCjDMk1eBXTWtcsKQV = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࡚ࡲࡶࡧ៥")
			oouF3U2PGQ8qXcBLei = []
			knaNvHwfMKIpWZUyoGEd1xYsbB = QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠵࠵ᛠ")
			oouF3U2PGQ8qXcBLei.append(str(UTelCo0ihE1d5R(u"࠶ᛢ")*edsrQyH6L29Db//knaNvHwfMKIpWZUyoGEd1xYsbB)+S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠪ࠱ࠬᇗ")+str(E6MIKdpBomef(u"࠶ᛡ")*edsrQyH6L29Db//knaNvHwfMKIpWZUyoGEd1xYsbB-E6MIKdpBomef(u"࠶ᛡ")))
			oouF3U2PGQ8qXcBLei.append(str(iUeoLOsbHqP(u"࠱ᛣ")*edsrQyH6L29Db//knaNvHwfMKIpWZUyoGEd1xYsbB)+XzrqbGDIy54juixkMA(u"ࠫ࠲࠭ᇘ")+str(FnBiAjthS8MkXs67W(u"࠳ᛤ")*edsrQyH6L29Db//knaNvHwfMKIpWZUyoGEd1xYsbB-iUeoLOsbHqP(u"࠱ᛣ")))
			oouF3U2PGQ8qXcBLei.append(str(p72fnFtcPix5UKwr9YNzW(u"࠶ᛧ")*edsrQyH6L29Db//knaNvHwfMKIpWZUyoGEd1xYsbB)+E6MIKdpBomef(u"ࠬ࠳ࠧᇙ")+str(E6MIKdpBomef(u"࠶ᛦ")*edsrQyH6L29Db//knaNvHwfMKIpWZUyoGEd1xYsbB-LiRcTVUWuth70DmPy(u"࠳ᛥ")))
			oouF3U2PGQ8qXcBLei.append(str(hBvsQ7oCkKUdwjx58ml3EN(u"࠹ᛩ")*edsrQyH6L29Db//knaNvHwfMKIpWZUyoGEd1xYsbB)+LiRcTVUWuth70DmPy(u"࠭࠭ࠨᇚ")+str(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠴ᛪ")*edsrQyH6L29Db//knaNvHwfMKIpWZUyoGEd1xYsbB-zqdvcbP5L8BHh(u"࠶ᛨ")))
			oouF3U2PGQ8qXcBLei.append(str(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠷᛭")*edsrQyH6L29Db//knaNvHwfMKIpWZUyoGEd1xYsbB)+xW2Arao7YVOemw(u"ࠧ࠮ࠩᇛ")+str(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠷᛬")*edsrQyH6L29Db//knaNvHwfMKIpWZUyoGEd1xYsbB-lc0dpSmwoPDjLnk(u"࠲᛫")))
			oouF3U2PGQ8qXcBLei.append(str(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠺ᛯ")*edsrQyH6L29Db//knaNvHwfMKIpWZUyoGEd1xYsbB)+hBvsQ7oCkKUdwjx58ml3EN(u"ࠨ࠯ࠪᇜ")+str(FvNyZqaLKw(u"࠼ᛰ")*edsrQyH6L29Db//knaNvHwfMKIpWZUyoGEd1xYsbB-YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠵ᛮ")))
			oouF3U2PGQ8qXcBLei.append(str(hBvsQ7oCkKUdwjx58ml3EN(u"࠸ᛳ")*edsrQyH6L29Db//knaNvHwfMKIpWZUyoGEd1xYsbB)+SO94xq1RAkMm2uF(u"ࠩ࠰ࠫᇝ")+str(yA5z6LIXBlo41PRVMY87wOisFp(u"࠸ᛲ")*edsrQyH6L29Db//knaNvHwfMKIpWZUyoGEd1xYsbB-dshJSmRqeiP9nap2(u"࠱ᛱ")))
			oouF3U2PGQ8qXcBLei.append(str(hBvsQ7oCkKUdwjx58ml3EN(u"࠼ᛶ")*edsrQyH6L29Db//knaNvHwfMKIpWZUyoGEd1xYsbB)+yA5z6LIXBlo41PRVMY87wOisFp(u"ࠪ࠱ࠬᇞ")+str(zqdvcbP5L8BHh(u"࠼ᛵ")*edsrQyH6L29Db//knaNvHwfMKIpWZUyoGEd1xYsbB-fprnld4CZo(u"࠴ᛴ")))
			oouF3U2PGQ8qXcBLei.append(str(wRxoKs10Syj7V4edYhtP(u"࠸ᛸ")*edsrQyH6L29Db//knaNvHwfMKIpWZUyoGEd1xYsbB)+SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫ࠲࠭ᇟ")+str(FnBiAjthS8MkXs67W(u"࠿ᛷ")*edsrQyH6L29Db//knaNvHwfMKIpWZUyoGEd1xYsbB-pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠲᛹")))
			oouF3U2PGQ8qXcBLei.append(str(yA5z6LIXBlo41PRVMY87wOisFp(u"࠻᛺")*edsrQyH6L29Db//knaNvHwfMKIpWZUyoGEd1xYsbB)+UTelCo0ihE1d5R(u"ࠬ࠳ࠧᇠ"))
			oIrCXhgDUi = float(dac3D2xo6WPu)/knaNvHwfMKIpWZUyoGEd1xYsbB
			IMTlCOhmPWsguFX54fz = oIrCXhgDUi/int(iRoLg2m47tnDATBHGCSPNyx(u"࠴᛻")+oIrCXhgDUi)
		else:
			zhGPpZCjDMk1eBXTWtcsKQV = g4g6bfkPtVGU5lIM3(u"ࡆࡢ࡮ࡶࡩ៦")
			knaNvHwfMKIpWZUyoGEd1xYsbB = fprnld4CZo(u"࠵᛼")
			IMTlCOhmPWsguFX54fz = fprnld4CZo(u"࠶᛽")
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q(SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ᇡ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧ࠯ࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡻࡳࡪࡰࡪࠤࡷࡧ࡮ࡨࡧࡶ࠾ࠥࡡࠠࠨᇢ")+str(zhGPpZCjDMk1eBXTWtcsKQV)+LiRcTVUWuth70DmPy(u"ࠨࠢࡠࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪᇣ")+str(edsrQyH6L29Db)+Me28A1sBLNIgUp5YCDyvT(u"ࠩࠣࡡࠬᇤ"))
		CQMipytPbq,a2rTywv0G9Vkme37Y = g4g6bfkPtVGU5lIM3(u"࠶᛾"),g4g6bfkPtVGU5lIM3(u"࠶᛾")
		for W6qVfHashAInl in range(knaNvHwfMKIpWZUyoGEd1xYsbB):
			BBYvCiQGe8RdpyAagfS72mZclxb5 = ep9JAOkj1wr5s.copy()
			if zhGPpZCjDMk1eBXTWtcsKQV: BBYvCiQGe8RdpyAagfS72mZclxb5[XzrqbGDIy54juixkMA(u"ࠪࡖࡦࡴࡧࡦࠩᇥ")] = FvNyZqaLKw(u"ࠫࡧࡿࡴࡦࡵࡀࠫᇦ")+oouF3U2PGQ8qXcBLei[W6qVfHashAInl]
			YutQm2AwozR9VKp4O1lWj8FaryI = DJ1rx9fvXIgUS7sZkVlOeGHb.get(cwCzVAXW3DFdoiO6UK0mya,stream=iUeoLOsbHqP(u"ࡕࡴࡸࡩ៧"),headers=BBYvCiQGe8RdpyAagfS72mZclxb5,timeout=FvNyZqaLKw(u"࠳࠱࠲᛿"))
			for obD4nzcqwaOfPkQ3s159SV in YutQm2AwozR9VKp4O1lWj8FaryI.iter_content(chunk_size=OOAKlxzEFviaX03heD):
				if dzrSRqtj49so.iscanceled():
					LOHZ4o9m7p6ebfTYXGIdz5PWs3q(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠬࡔࡏࡕࡋࡆࡉࠬᇧ"),yA5z6LIXBlo41PRVMY87wOisFp(u"࠭࠮ࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡈࡧ࡮ࡤࡧ࡯ࡩࡩ࠭ᇨ"))
					break
				CQMipytPbq += IMTlCOhmPWsguFX54fz
				bXdjnWpckF2h6iY3zUavgSBHA += obD4nzcqwaOfPkQ3s159SV
				if not a2rTywv0G9Vkme37Y: a2rTywv0G9Vkme37Y = len(obD4nzcqwaOfPkQ3s159SV)
				if edsrQyH6L29Db: FFBJqkrThNeWfiaZPE5Aws9uGdp(dzrSRqtj49so,xW2Arao7YVOemw(u"࠲࠲࠳ᜀ")*CQMipytPbq//dac3D2xo6WPu,lc0dpSmwoPDjLnk(u"ࠧอๆหࠤฬ๊ๅๅใ࠽࠱ࠥอไอิฤࠤึ่ๅࠨᇩ"),str(FvNyZqaLKw(u"࠳࠳࠴࠳࠶ᜁ")*a2rTywv0G9Vkme37Y*CQMipytPbq//OOAKlxzEFviaX03heD//FvNyZqaLKw(u"࠳࠳࠴࠳࠶ᜁ"))+LiRcTVUWuth70DmPy(u"ࠨࠢ࠲ࠤࠬᇪ")+tV4NTJHwly+sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩࠣࡑࡇ࠭ᇫ"))
				else: FFBJqkrThNeWfiaZPE5Aws9uGdp(dzrSRqtj49so,a2rTywv0G9Vkme37Y*CQMipytPbq//OOAKlxzEFviaX03heD,p72fnFtcPix5UKwr9YNzW(u"ࠪะ้ฮࠠศๆ่่ๆࡀ࠭ࠨᇬ"),str(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠴࠴࠵࠴࠰ᜂ")*a2rTywv0G9Vkme37Y*CQMipytPbq//OOAKlxzEFviaX03heD//YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠴࠴࠵࠴࠰ᜂ"))+S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࠥࡓࡂࠨᇭ"))
			YutQm2AwozR9VKp4O1lWj8FaryI.close()
		dzrSRqtj49so.close()
		if len(bXdjnWpckF2h6iY3zUavgSBHA)<edsrQyH6L29Db and edsrQyH6L29Db>FnBiAjthS8MkXs67W(u"࠴ᜃ"):
			LOHZ4o9m7p6ebfTYXGIdz5PWs3q(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬࡔࡏࡕࡋࡆࡉࠬᇮ"),FnBiAjthS8MkXs67W(u"࠭࠮ࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤ࡫ࡧࡩ࡭ࡧࡧࠤࡴࡸࠠࡤࡣࡱࡧࡪࡲࡥࡥࠢࡤࡸ࠿࡛ࠦࠡࠩᇯ")+str(len(bXdjnWpckF2h6iY3zUavgSBHA)//cMR1f3D2UeyrLKXoYVPt8)+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡈࡵࡳࡲࠦࡴࡰࡶࡤࡰࠥࡵࡦ࠻ࠢ࡞ࠤࠬᇰ")+tV4NTJHwly+Me28A1sBLNIgUp5YCDyvT(u"ࠨࠢࡐࡆࠥࡣࠧᇱ"))
			r54fQALYmUbegM7yxsNc = CCQOct8zmrKMuP6ZEkxq7oaf1BeRv(Me28A1sBLNIgUp5YCDyvT(u"ࠩࠪᇲ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪษ้เวย๋ࠢาึ๎ฬࠨᇳ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫฬูสฯัส้ࠥอไๆๆไࠤฬ๊ๆศไุࠫᇴ"),Cu1704YofAbr3QTm(u"ࠬหูศัฬࠤั๊ศࠡษ็้้็ࠧᇵ"),iRoLg2m47tnDATBHGCSPNyx(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᇶ"),dshJSmRqeiP9nap2(u"ࠧโึ็ࠤๆ๐ࠠอๆหࠤฬ๊ๅๅใࠣࡠࡳࠦไๅลึๅࠥำฯฬࠢั฻ศࠦแ๋ࠢอั๊๐ไࠡษ็้้็ࠠ࡝ࡰࠣฮ๊ࠦฬๅสࠣࠫᇷ")+str(len(bXdjnWpckF2h6iY3zUavgSBHA)//cMR1f3D2UeyrLKXoYVPt8)+FnBiAjthS8MkXs67W(u"ࠨ่ࠢ๎฿อศศ์อࠤ๊์ࠠๆฮ่์฾ࠦࠧᇸ")+tV4NTJHwly+FvNyZqaLKw(u"้ࠩࠣ๏เวษษํฮࠥࡢ࡮ࠡฮิฬࠥาไษࠢส่๊๊แࠡ็ิอࠥษฮา๋ࠣࡠࡳࠦ็ๅࠢอี๏ีࠠศีอาิอๅࠡษ็้้็ࠠศๆ้ห็฻ࠠภࠣࠤࠫᇹ"))
			if r54fQALYmUbegM7yxsNc==SO94xq1RAkMm2uF(u"࠷ᜄ"): bXdjnWpckF2h6iY3zUavgSBHA = wwJEoNAiDnIZgYS(cwCzVAXW3DFdoiO6UK0mya,ep9JAOkj1wr5s,showDialogs)
			elif r54fQALYmUbegM7yxsNc==YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠷ᜅ"): LOHZ4o9m7p6ebfTYXGIdz5PWs3q(Cu1704YofAbr3QTm(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪᇺ"),g4g6bfkPtVGU5lIM3(u"ࠫ࠳ࠦࠠࡏࡱࡷࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࡪࠠࡥࡱࡺࡲࡱࡵࡡࡥࡧࡧࠤ࡫࡯࡬ࡦࠢ࡬ࡷࠥࡧࡣࡤࡧࡳࡸࡪࡪࠠࡢࡰࡧࠤࡼ࡯࡬࡭ࠢࡥࡩࠥࡻࡳࡦࡦࠪᇻ"))
			else: return Me28A1sBLNIgUp5YCDyvT(u"ࠬ࠭ᇼ")
			if not bXdjnWpckF2h6iY3zUavgSBHA: return G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠭ࠧᇽ")
		else: LOHZ4o9m7p6ebfTYXGIdz5PWs3q(XzrqbGDIy54juixkMA(u"ࠧࡏࡑࡗࡍࡈࡋࠧᇾ"),zqdvcbP5L8BHh(u"ࠨ࠰ࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡓࡶࡥࡦࡩࡪࡪࡥࡥ࠰ࠣࠤࠥࡌࡩ࡭ࡧࠣࡗ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬᇿ")+tV4NTJHwly+fprnld4CZo(u"ࠩࠣࡑࡇࠦ࡝ࠨሀ"))
	return bXdjnWpckF2h6iY3zUavgSBHA
def GUrw7YT8Qc(cTJphS1nFz5EUgNWm86C):
	return YutQm2AwozR9VKp4O1lWj8FaryI
def T0U4fwNGiQ(ip=FnBiAjthS8MkXs67W(u"ࠪࠫሁ")):
	CCyQeGku0xwcKTgDMRZXWq72B,CP2iXvM97DK6ZcNwFl8B,KgToBhcMflEypqdzjt,UQ3KHcETzGoMZCAg8VFiSsh,SBjvm2AlqQzrO8KVs9eTMY,xaQT3MO9fCGKIp0FEDR21BzHi = Me28A1sBLNIgUp5YCDyvT(u"ࠫࠬሂ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬ࠭ሃ"),hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࠧሄ"),p72fnFtcPix5UKwr9YNzW(u"ࠧࠨህ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨࠩሆ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࠪሇ")
	mHejXxkvM1qCESPVRy54QB = p72fnFtcPix5UKwr9YNzW(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡭ࡵࡽࡨࡰ࠰࡬ࡷ࠴࠭ለ")+ip+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࡄࡵࡵࡵࡲࡸࡸࡂࡰࡳࡰࡰࠩࡪ࡮࡫࡬ࡥࡵࡀ࡭ࡵ࠲ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵ࠮ࡦࡳࡺࡴࡴࡳࡻ࠯ࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦ࠮ࡵࡩ࡬࡯࡯࡯࠮ࡦ࡭ࡹࡿࠬࡵ࡫ࡰࡩࡿࡵ࡮ࡦࠩሉ")
	ep9JAOkj1wr5s = {UTelCo0ihE1d5R(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩሊ"):sTcr7iDp5eFt4RoLMhuwq1A(u"࠭ࠧላ")}
	YutQm2AwozR9VKp4O1lWj8FaryI = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࡈࡇࡗࠫሌ"),mHejXxkvM1qCESPVRy54QB,S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠨࠩል"),ep9JAOkj1wr5s,LiRcTVUWuth70DmPy(u"ࠩࠪሎ"),SO94xq1RAkMm2uF(u"ࠪࠫሏ"),p72fnFtcPix5UKwr9YNzW(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡐࡎࡒࡇࡆ࡚ࡉࡐࡐ࠰࠵ࡸࡺࠧሐ"))
	if not YutQm2AwozR9VKp4O1lWj8FaryI.succeeded: Ld4oBuRD29JgTmZcMkH16 = ip+SO94xq1RAkMm2uF(u"ࠬ࠲ࠧሑ")+CCyQeGku0xwcKTgDMRZXWq72B+bUdr5Hahw6sY8xJ(u"࠭ࠬࠨሒ")+CP2iXvM97DK6ZcNwFl8B+E6MIKdpBomef(u"ࠧ࠭ࠩሓ")+UQ3KHcETzGoMZCAg8VFiSsh+Cu1704YofAbr3QTm(u"ࠨ࠮ࠪሔ")+SBjvm2AlqQzrO8KVs9eTMY+FvNyZqaLKw(u"ࠩ࠯ࠫሕ")+xaQT3MO9fCGKIp0FEDR21BzHi
	else:
		U9rSWyc74gLOw = YutQm2AwozR9VKp4O1lWj8FaryI.content
		U9rSWyc74gLOw = GGvHJKP9LUxEk10Fw.findall(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪࡠࢀ࠴ࠪࡀ࡞ࢀࡠࢂ࠭ሖ"),U9rSWyc74gLOw,GGvHJKP9LUxEk10Fw.DOTALL)
		if U9rSWyc74gLOw:
			U9rSWyc74gLOw = U9rSWyc74gLOw[iUeoLOsbHqP(u"࠰ᜆ")]
			NNaGyCS4skiFWhV = JKw5OWktPZB(iRoLg2m47tnDATBHGCSPNyx(u"ࠫࡩ࡯ࡣࡵࠩሗ"),U9rSWyc74gLOw)
			xcp4sg02rIn57VdDwH = list(NNaGyCS4skiFWhV.keys())
			if g4g6bfkPtVGU5lIM3(u"ࠬ࡯ࡰࠨመ") in xcp4sg02rIn57VdDwH: ip = NNaGyCS4skiFWhV[LiRcTVUWuth70DmPy(u"࠭ࡩࡱࠩሙ")]
			if Me28A1sBLNIgUp5YCDyvT(u"ࠧࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶࠪሚ") in xcp4sg02rIn57VdDwH: CCyQeGku0xwcKTgDMRZXWq72B = NNaGyCS4skiFWhV[hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨࡥࡲࡲࡹ࡯࡮ࡦࡰࡷࠫማ")]
			if Me28A1sBLNIgUp5YCDyvT(u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪሜ") in xcp4sg02rIn57VdDwH: CP2iXvM97DK6ZcNwFl8B = NNaGyCS4skiFWhV[Cu1704YofAbr3QTm(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫም")]
			if xW2Arao7YVOemw(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࡤࡩ࡯ࡥࡧࠪሞ") in xcp4sg02rIn57VdDwH: KgToBhcMflEypqdzjt = NNaGyCS4skiFWhV[fprnld4CZo(u"ࠬࡩ࡯ࡶࡰࡷࡶࡾࡥࡣࡰࡦࡨࠫሟ")]
			if QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭ࡲࡦࡩ࡬ࡳࡳ࠭ሠ") in xcp4sg02rIn57VdDwH: UQ3KHcETzGoMZCAg8VFiSsh = NNaGyCS4skiFWhV[hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠧࡳࡧࡪ࡭ࡴࡴࠧሡ")]
			if G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠨࡥ࡬ࡸࡾ࠭ሢ") in xcp4sg02rIn57VdDwH: SBjvm2AlqQzrO8KVs9eTMY = NNaGyCS4skiFWhV[SO94xq1RAkMm2uF(u"ࠩࡦ࡭ࡹࡿࠧሣ")]
			if iUeoLOsbHqP(u"ࠪࡸ࡮ࡳࡥࡻࡱࡱࡩࠬሤ") in xcp4sg02rIn57VdDwH:
				xaQT3MO9fCGKIp0FEDR21BzHi = NNaGyCS4skiFWhV[p72fnFtcPix5UKwr9YNzW(u"ࠫࡹ࡯࡭ࡦࡼࡲࡲࡪ࠭ሥ")][hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬࡻࡴࡤࠩሦ")]
				if xaQT3MO9fCGKIp0FEDR21BzHi[fprnld4CZo(u"࠱ᜇ")] not in [LiRcTVUWuth70DmPy(u"࠭࠭ࠨሧ"),SO94xq1RAkMm2uF(u"ࠧࠬࠩረ")]: xaQT3MO9fCGKIp0FEDR21BzHi = LiRcTVUWuth70DmPy(u"ࠨ࠭ࠪሩ")+xaQT3MO9fCGKIp0FEDR21BzHi
			Ld4oBuRD29JgTmZcMkH16 = ip+YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩ࠯ࠫሪ")+CCyQeGku0xwcKTgDMRZXWq72B+SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪ࠰ࠬራ")+CP2iXvM97DK6ZcNwFl8B+LiRcTVUWuth70DmPy(u"ࠫ࠱࠭ሬ")+UQ3KHcETzGoMZCAg8VFiSsh+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬ࠲ࠧር")+SBjvm2AlqQzrO8KVs9eTMY+XzrqbGDIy54juixkMA(u"࠭ࠬࠨሮ")+xaQT3MO9fCGKIp0FEDR21BzHi
			if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: Ld4oBuRD29JgTmZcMkH16 = Ld4oBuRD29JgTmZcMkH16.encode(E6MIKdpBomef(u"ࠧࡶࡶࡩ࠼ࠬሯ")).decode(p72fnFtcPix5UKwr9YNzW(u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩሰ"))
	Ld4oBuRD29JgTmZcMkH16 = ptMqV54oKJhQ8CH(Ld4oBuRD29JgTmZcMkH16)
	return Ld4oBuRD29JgTmZcMkH16
def AHhPV9MzsOwnESxWedl3J4vYm(njH3QxTrRh):
	iETXWgjrxHUJab5C1lMDAk,showDialogs = FnBiAjthS8MkXs67W(u"ࠩࠪሱ"),FnBiAjthS8MkXs67W(u"ࡖࡵࡹࡪ៨")
	if njH3QxTrRh.count(bUdr5Hahw6sY8xJ(u"ࠪࡣࠬሲ"))>=p72fnFtcPix5UKwr9YNzW(u"࠴ᜈ"):
		njH3QxTrRh,iETXWgjrxHUJab5C1lMDAk = njH3QxTrRh.split(iUeoLOsbHqP(u"ࠫࡤ࠭ሳ"),XzrqbGDIy54juixkMA(u"࠴ᜉ"))
		iETXWgjrxHUJab5C1lMDAk = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬࡥࠧሴ")+iETXWgjrxHUJab5C1lMDAk
		if l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫስ") in iETXWgjrxHUJab5C1lMDAk: showDialogs = sTcr7iDp5eFt4RoLMhuwq1A(u"ࡉࡥࡱࡹࡥ៩")
		else: showDialogs = yA5z6LIXBlo41PRVMY87wOisFp(u"ࡘࡷࡻࡥ៪")
	return njH3QxTrRh,iETXWgjrxHUJab5C1lMDAk,showDialogs
def q35weK2bNsDmQ():
	otBJSYa3V2 = WpgZTyqoMAPhwGiXF.path.join(bdmxngE9YGIeQ,SO94xq1RAkMm2uF(u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ሶ"))
	eekAMBjifC5qOXI09tKhu = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠴ᜊ")
	if WpgZTyqoMAPhwGiXF.path.exists(otBJSYa3V2):
		for TQ7XxCh6E4quszI1cornewB in WpgZTyqoMAPhwGiXF.listdir(otBJSYa3V2):
			if FvNyZqaLKw(u"ࠨ࠰ࡳࡽࡴ࠭ሷ") in TQ7XxCh6E4quszI1cornewB: continue
			if Cu1704YofAbr3QTm(u"ࠩࡢࡣࡵࡿࡣࡢࡥ࡫ࡩࡤࡥࠧሸ") in TQ7XxCh6E4quszI1cornewB: continue
			abyzErNYtfoBs = WpgZTyqoMAPhwGiXF.path.join(otBJSYa3V2,TQ7XxCh6E4quszI1cornewB)
			HICQUYNXo1yMh,L8Nc9Q4IRd5Bqm21ZF = hYNG3tj5Xu2knZ7lowbS(abyzErNYtfoBs)
			eekAMBjifC5qOXI09tKhu += HICQUYNXo1yMh
	return eekAMBjifC5qOXI09tKhu
def WiBcHvkRCKfFns3YMhIyAZ16TD8x4O(showDialogs):
	lg87QsxhXNyDepwEcV5df = jHevARrF7lS.getSetting(SO94xq1RAkMm2uF(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨሹ"))
	b7bzJDCnt5ZrT86pUISPX9sdehF = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,p72fnFtcPix5UKwr9YNzW(u"ࠫࡸࡺࡲࠨሺ"),UTelCo0ihE1d5R(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨሻ"),iUeoLOsbHqP(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨሼ"))
	AACyoUFk9aXc87IPB2JTzOd,aNnlZBjEYeLp2krcziGS = lg87QsxhXNyDepwEcV5df,b7bzJDCnt5ZrT86pUISPX9sdehF
	vUjFIiO9LwuQk0VN518X,Y6bjMeWAF8XRva = XzrqbGDIy54juixkMA(u"ࠧࠨሽ"),Me28A1sBLNIgUp5YCDyvT(u"ࠨࠩሾ")
	if lc0dpSmwoPDjLnk(u"࠶ᜋ"):
		mHejXxkvM1qCESPVRy54QB = oSVpce1UQYrDqhuM6PT[E6MIKdpBomef(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩሿ")][pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠹ᜌ")]
		exOIZnGECcR2p3WV4TPY06BNDo7 = PW2xo0Kq3Tcprj9Ck(p72fnFtcPix5UKwr9YNzW(u"࠳࠳ᜍ"))
		Ld4oBuRD29JgTmZcMkH16 = T0U4fwNGiQ()
		CP2iXvM97DK6ZcNwFl8B = Ld4oBuRD29JgTmZcMkH16.split(LiRcTVUWuth70DmPy(u"ࠪ࠰ࠬቀ"))[SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠳ᜎ")]
		eekAMBjifC5qOXI09tKhu = q35weK2bNsDmQ()
		ojS2y3cRDf = {oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫࡺࡹࡥࡳࠩቁ"):exOIZnGECcR2p3WV4TPY06BNDo7,kEhAHvti6Vnsfx(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭ቂ"):mmn0lB2tFI7XTgVfESo,dshJSmRqeiP9nap2(u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧቃ"):CP2iXvM97DK6ZcNwFl8B,iRoLg2m47tnDATBHGCSPNyx(u"ࠧࡪࡦࡶࠫቄ"):njglTZ1qzxm9K70U2(eekAMBjifC5qOXI09tKhu)}
		YutQm2AwozR9VKp4O1lWj8FaryI = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠨࡒࡒࡗ࡙࠭ቅ"),mHejXxkvM1qCESPVRy54QB,ojS2y3cRDf,S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠩࠪቆ"),fprnld4CZo(u"ࠪࠫቇ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫࠬቈ"),Cu1704YofAbr3QTm(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡑࡊ࡙ࡓࡂࡉࡈࡗ࠲࠷ࡳࡵࠩ቉"))
		if not YutQm2AwozR9VKp4O1lWj8FaryI.succeeded:
			if lg87QsxhXNyDepwEcV5df in [E6MIKdpBomef(u"࠭ࠧቊ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࡏࡇ࡚ࠫቋ")]: AACyoUFk9aXc87IPB2JTzOd = sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨࡐࡈ࡛ࡤ࡚ࡏࡠࡇࡕࡖࡔࡘࠧቌ")
			elif lg87QsxhXNyDepwEcV5df==XzrqbGDIy54juixkMA(u"ࠩࡒࡐࡉ࠭ቍ"): AACyoUFk9aXc87IPB2JTzOd = Cu1704YofAbr3QTm(u"ࠪࡓࡑࡊ࡟ࡕࡑࡢࡉࡗࡘࡏࡓࠩ቎")
		else:
			GU8BmCW1xJ3dyiRQnpz9NI6 = YutQm2AwozR9VKp4O1lWj8FaryI.content
			GU8BmCW1xJ3dyiRQnpz9NI6 = JKw5OWktPZB(g4g6bfkPtVGU5lIM3(u"ࠫࡱ࡯ࡳࡵࠩ቏"),GU8BmCW1xJ3dyiRQnpz9NI6)
			GU8BmCW1xJ3dyiRQnpz9NI6 = sorted(GU8BmCW1xJ3dyiRQnpz9NI6,reverse=pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࡙ࡸࡵࡦ៫"),key=lambda key: int(key[yA5z6LIXBlo41PRVMY87wOisFp(u"࠲ᜏ")]))
			Y6bjMeWAF8XRva,aNnlZBjEYeLp2krcziGS = hBvsQ7oCkKUdwjx58ml3EN(u"ࠬ࠭ቐ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭ࠧቑ")
			for Y6DWhEbP9AXnG0BiCesaKHR3U,PVe4koxyt9Rh3Dz,oCrTtRIykV4E9fuKnBGW in GU8BmCW1xJ3dyiRQnpz9NI6:
				if Y6DWhEbP9AXnG0BiCesaKHR3U==xW2Arao7YVOemw(u"ࠧ࠱ࠩቒ"):
					Y6bjMeWAF8XRva += oCrTtRIykV4E9fuKnBGW+iUeoLOsbHqP(u"ࠨ࠼࠽ࠫቓ")
					continue
				if aNnlZBjEYeLp2krcziGS: aNnlZBjEYeLp2krcziGS += kEhAHvti6Vnsfx(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮࡝ࡰࠪቔ")
				Jx14G6qfspM8H32NlVFjazkUgA = oCrTtRIykV4E9fuKnBGW.split(wRxoKs10Syj7V4edYhtP(u"ࠪࡠࡳ࠭ቕ"))[oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠳ᜐ")]
				QDJRubCIOWBekmvyqgp9hfNxKHaZ42 = SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫึูวๅหࠣาฬ฻ษࠡๆๆࠤๆ่ืࠨቖ") if PVe4koxyt9Rh3Dz else zqdvcbP5L8BHh(u"ࠬ࠭቗")
				aNnlZBjEYeLp2krcziGS += oCrTtRIykV4E9fuKnBGW.replace(Jx14G6qfspM8H32NlVFjazkUgA,SyENPzdOon6uxcLXMhqb14aDlB9r(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩቘ")+Jx14G6qfspM8H32NlVFjazkUgA+QDJRubCIOWBekmvyqgp9hfNxKHaZ42+UTelCo0ihE1d5R(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ቙"))+wRxoKs10Syj7V4edYhtP(u"ࠨ࡞ࡱࠫቚ")
			aNnlZBjEYeLp2krcziGS = kEhAHvti6Vnsfx(u"ࠩ࡟ࡲࠬቛ")+aNnlZBjEYeLp2krcziGS+FnBiAjthS8MkXs67W(u"ࠪࡠࡳࡢ࡮ࠨቜ")
			Y6bjMeWAF8XRva = Y6bjMeWAF8XRva.strip(dshJSmRqeiP9nap2(u"ࠫ࠿ࡀࠧቝ"))
			vUjFIiO9LwuQk0VN518X = jHevARrF7lS.getSetting(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹ࠱ࠨ቞"))
			if aNnlZBjEYeLp2krcziGS==b7bzJDCnt5ZrT86pUISPX9sdehF and lg87QsxhXNyDepwEcV5df in [l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࡏࡍࡆࠪ቟"),iUeoLOsbHqP(u"ࠧࡐࡎࡇࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭በ")]: AACyoUFk9aXc87IPB2JTzOd = xW2Arao7YVOemw(u"ࠨࡑࡏࡈࠬቡ")
			else: AACyoUFk9aXc87IPB2JTzOd = fprnld4CZo(u"ࠩࡑࡉ࡜࠭ቢ")
			Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,kEhAHvti6Vnsfx(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ባ"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭ቤ"),aNnlZBjEYeLp2krcziGS,GOhVkMATsg4cJmfa0Enp6zSqCr)
			jHevARrF7lS.setSetting(UTelCo0ihE1d5R(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭ብ"),njglTZ1qzxm9K70U2(MMHpSTojGILfZXWeCOPyn4))
			jHevARrF7lS.setSetting(bUdr5Hahw6sY8xJ(u"࠭ࡡࡷ࠰ࡳࡶ࡮ࡼࡳ࠲ࠩቦ"),Y6bjMeWAF8XRva)
			from hashlib import md5 as iWY9OsI5lM6tuDA2RfhmqkPdBQv
			wnOokC21GQf3apHSgZAJP = iWY9OsI5lM6tuDA2RfhmqkPdBQv(LiRcTVUWuth70DmPy(u"࠹ᜑ")*Y6bjMeWAF8XRva.encode(zqdvcbP5L8BHh(u"ࠧࡶࡶࡩ࠼ࠬቧ"))).hexdigest()
			wnOokC21GQf3apHSgZAJP = iWY9OsI5lM6tuDA2RfhmqkPdBQv(E6MIKdpBomef(u"࠶࠺ᜒ")*wnOokC21GQf3apHSgZAJP.encode(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࡷࡷࡪ࠽࠭ቨ"))).hexdigest()
			wnOokC21GQf3apHSgZAJP = iWY9OsI5lM6tuDA2RfhmqkPdBQv(kEhAHvti6Vnsfx(u"࠷࠹ᜓ")*wnOokC21GQf3apHSgZAJP.encode(p72fnFtcPix5UKwr9YNzW(u"ࠩࡸࡸ࡫࠾ࠧቩ"))).hexdigest()
			jHevARrF7lS.setSetting(bUdr5Hahw6sY8xJ(u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷ࠷࠭ቪ"),wnOokC21GQf3apHSgZAJP)
	if showDialogs:
		if AACyoUFk9aXc87IPB2JTzOd in [p72fnFtcPix5UKwr9YNzW(u"ࠫࡔࡒࡄࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪቫ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠬࡔࡅࡘࡡࡗࡓࡤࡋࡒࡓࡑࡕࠫቬ")]:
			aHKzv76JCVnprbY8w(sTcr7iDp5eFt4RoLMhuwq1A(u"࠭ࠧቭ"),kEhAHvti6Vnsfx(u"ࠧࠨቮ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫቯ"),Cu1704YofAbr3QTm(u"๊๊ࠩฬ้ࠠๆึๆ่ฮࠦแ๋ࠢฯ๋ฬุใ๊๊ࠡ๎๊๊ࠥิฬ้๋ࠣࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤ์ึ็ࠡษ็ู้้ไสࠢๅำࠥ๐ใ้่ࠣือฮ็ศࠢส่ส์สา่อࠤฬ๊ฮศืࠣฬ่ࠦร้ࠢส่ึอ่หำࠣห้ิวึࠢห็ࠥษ่ࠡ็ื็้ฯࠠโ์ࠣห้ษำๅษๆࠤ฾์ฯไࠩተ"))
		else:
			d0tNlv4Lbu2pqDaO1JfSEC9QIP5Xc(fprnld4CZo(u"ࠪࡶ࡮࡭ࡨࡵࠩቱ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠫึูววๆ้๋ࠣࠦวๅ็หี๊าࠠฦๆ์ࠤู๊สฯั่๎ࠥอไษำ้ห๊าࠧቲ"),aNnlZBjEYeLp2krcziGS,xW2Arao7YVOemw(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭ታ"))
			AACyoUFk9aXc87IPB2JTzOd = fprnld4CZo(u"࠭ࡏࡍࡆࠪቴ")
	if AACyoUFk9aXc87IPB2JTzOd!=lg87QsxhXNyDepwEcV5df:
		jHevARrF7lS.setSetting(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡹࡳࡢࡩࡨࡷࠬት"),AACyoUFk9aXc87IPB2JTzOd)
		cEZpW924rqNYm5.executebuiltin(zqdvcbP5L8BHh(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬቶ"))
	aZi5pERcgnxeh9BJDwXNky = Cu1704YofAbr3QTm(u"ࡔࡳࡷࡨ៭") if Y6bjMeWAF8XRva!=vUjFIiO9LwuQk0VN518X else XzrqbGDIy54juixkMA(u"ࡌࡡ࡭ࡵࡨ៬")
	if aZi5pERcgnxeh9BJDwXNky:
		From8aTqdhCbPs(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"้ࠩะาะฺࠠ็็๎ฮࠦสฮัํฯࠥอไึๆสั๏อสࠨቷ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪࡗࡺࡩࡣࡦࡵࡶࠫቸ"),MQbODJoPV2w8TEAg4zXZdjLxSW=XzrqbGDIy54juixkMA(u"࠷࠶࠲᜔"))
		cEZpW924rqNYm5.executebuiltin(lc0dpSmwoPDjLnk(u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨቹ"))
	return aZi5pERcgnxeh9BJDwXNky
def P9UMWpgzcQqxO(WK59LPt30k6OEVm,QCndJmNEhwPe4qVba5):
	from socket import socket as PWX8Cboc6iE0KOgafZ9jMw1pG,AF_INET as F8gpvxURGVTJ0eH,SOCK_STREAM as K8Q9rSind42b
	M2I9wYxpkRe0 = PWX8Cboc6iE0KOgafZ9jMw1pG(F8gpvxURGVTJ0eH,K8Q9rSind42b)
	M2I9wYxpkRe0.settimeout(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠲᜕"))
	KKWoCUYw3thId2e1GPVuDcx98ia,i8JPEqWoaC7d3pnYBr = oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࡕࡴࡸࡩ៮"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠲᜖")
	LCaAcrp8R57YSD = MQbODJoPV2w8TEAg4zXZdjLxSW.time()
	try: M2I9wYxpkRe0.connect((WK59LPt30k6OEVm,QCndJmNEhwPe4qVba5))
	except: KKWoCUYw3thId2e1GPVuDcx98ia = S4SOKF2QbBhjCd3RrVMuHIzE(u"ࡈࡤࡰࡸ࡫៯")
	OyoFMlKmTs2aqvHjZ40Vu = MQbODJoPV2w8TEAg4zXZdjLxSW.time()
	if KKWoCUYw3thId2e1GPVuDcx98ia: i8JPEqWoaC7d3pnYBr = OyoFMlKmTs2aqvHjZ40Vu-LCaAcrp8R57YSD
	return i8JPEqWoaC7d3pnYBr
def LKE5PBr2XSg0ZYlMCV(showDialogs):
	if showDialogs:
		o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠬ࠭ቺ"),LiRcTVUWuth70DmPy(u"࠭ࠧቻ"),FnBiAjthS8MkXs67W(u"ࠧࠨቼ"),FnBiAjthS8MkXs67W(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫች"),iRoLg2m47tnDATBHGCSPNyx(u"ࠩึ์ๆ๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦวๅฤ้ࠤอหีๅษะࠤํะๆู์ไࠤัฺ๋๊ࠢๅ์ฬ฿ฯࠡษ็ฬ๏อๆศฬࠣ์ฬ๊ใศึࠣห้๋ำหะา้ฮࠦแ๋ࠢส่อืๆศ็ฯࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡฬื฾๏ฺ๊ࠠ็็๎ฮࠦวๅฬ้฼๏็ࠠศๆล๊ࠥลࠡࠨቾ"))
	else: o07Z1tEB4n3ARCkVNu = FvNyZqaLKw(u"ࡗࡶࡺ࡫៰")
	if o07Z1tEB4n3ARCkVNu==SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠴᜗"):
		for TQ7XxCh6E4quszI1cornewB in WpgZTyqoMAPhwGiXF.listdir(JXUQZHLxEgTFbrRC7n9):
			if TQ7XxCh6E4quszI1cornewB.endswith(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪ࠲ࡩࡨࠧቿ")) and g4g6bfkPtVGU5lIM3(u"ࠫࡩࡧࡴࡢࠩኀ") in TQ7XxCh6E4quszI1cornewB:
				U2gpeLZJrTRzYNvX0Fni3 = WpgZTyqoMAPhwGiXF.path.join(JXUQZHLxEgTFbrRC7n9,TQ7XxCh6E4quszI1cornewB)
				try: QAlb96UhsVG,PYRN3CLTut = PlKUSdaCEJ6T0rnL(U2gpeLZJrTRzYNvX0Fni3)
				except: return
				PYRN3CLTut.execute(fprnld4CZo(u"ࠬࡖࡒࡂࡉࡐࡅࠥ࡯࡮ࡵࡧࡪࡶ࡮ࡺࡹࡠࡥ࡫ࡩࡨࡱ࠻ࠨኁ"))
				PYRN3CLTut.execute(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࡐࡓࡃࡊࡑࡆࠦ࡯ࡱࡶ࡬ࡱ࡮ࢀࡥ࠼ࠩኂ"))
				PYRN3CLTut.execute(xW2Arao7YVOemw(u"ࠧࡗࡃࡆ࡙࡚ࡓ࠻ࠨኃ"))
				QAlb96UhsVG.commit()
				QAlb96UhsVG.close()
		if showDialogs:
			aHKzv76JCVnprbY8w(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࠩኄ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠩࠪኅ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ኆ"),dshJSmRqeiP9nap2(u"ࠫฯ๋สࠡส้ะฬำฺࠠ็็๎ฮࠦลึๆสัࠥ๎ส็ฺํๅࠥาๅ๋฻ࠣๆํอูะࠢส่อ๐ว็ษอࠤํอไไษืࠤฬ๊ๅิฬัำ๊ฯࠠโ์ࠣห้ฮั็ษ่ะࠬኇ"))
	return
def LFmr6Jxpwe1OklbdUCnTBMAuaiq(sce2GMh9gfRLu,gQnmaPXK0SDMCLN6r,showDialogs):
	if sce2GMh9gfRLu!=None:
		global w2AeoRGlxbh
		w2AeoRGlxbh = sce2GMh9gfRLu
	if gQnmaPXK0SDMCLN6r!=None:
		global JhbroxyaLzpcB6f28TIY1Nv
		JhbroxyaLzpcB6f28TIY1Nv = gQnmaPXK0SDMCLN6r
	if showDialogs!=None:
		global QDCIoXspYTFrVjz6KSgtN7H4JW
		QDCIoXspYTFrVjz6KSgtN7H4JW = showDialogs
	return
w2AeoRGlxbh,JhbroxyaLzpcB6f28TIY1Nv,QDCIoXspYTFrVjz6KSgtN7H4JW = hBvsQ7oCkKUdwjx58ml3EN(u"ࠬ࠭ኈ"),Cu1704YofAbr3QTm(u"࠭ࠧ኉"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧࠨኊ")
def V0DM83o2AXcT4mLwJzQkbhnR(vYFXP48WV6M,mHejXxkvM1qCESPVRy54QB,data,headers,allow_redirects,showDialogs,hayXA4TiLlPxcVSIoK2,GPBaUzVhdpyO6xkJD2,t8x23UOsYmr9IDik06pG):
	if showDialogs==l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨࠩኋ"): qDzNIhmbFvwp8arWP = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࡘࡷࡻࡥ៱") if QDCIoXspYTFrVjz6KSgtN7H4JW==fprnld4CZo(u"ࠩࠪኌ") else QDCIoXspYTFrVjz6KSgtN7H4JW
	else: qDzNIhmbFvwp8arWP = dshJSmRqeiP9nap2(u"࡚ࡲࡶࡧ៳") if showDialogs else iRoLg2m47tnDATBHGCSPNyx(u"ࡋࡧ࡬ࡴࡧ៲")
	if t8x23UOsYmr9IDik06pG==dshJSmRqeiP9nap2(u"ࠪࠫኍ"): ncipfgE3NSFUhlZC = LiRcTVUWuth70DmPy(u"ࡔࡳࡷࡨ៴") if JhbroxyaLzpcB6f28TIY1Nv==iRoLg2m47tnDATBHGCSPNyx(u"ࠫࠬ኎") else JhbroxyaLzpcB6f28TIY1Nv
	else: ncipfgE3NSFUhlZC = kEhAHvti6Vnsfx(u"ࡖࡵࡹࡪ៶") if t8x23UOsYmr9IDik06pG else YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࡇࡣ࡯ࡷࡪ៵")
	if GPBaUzVhdpyO6xkJD2==SO94xq1RAkMm2uF(u"ࠬ࠭኏"): PiHc07NenyoQB = YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࡗࡶࡺ࡫៷") if w2AeoRGlxbh==iUeoLOsbHqP(u"࠭ࠧነ") else w2AeoRGlxbh
	else: PiHc07NenyoQB = E6MIKdpBomef(u"࡙ࡸࡵࡦ៹") if GPBaUzVhdpyO6xkJD2 else YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࡊࡦࡲࡳࡦ៸")
	if allow_redirects==iUeoLOsbHqP(u"ࠧࠨኑ"): OCa4ZAo2pviYzdfuVQx1J5bF = E6MIKdpBomef(u"࡚ࡲࡶࡧ៺")
	else: OCa4ZAo2pviYzdfuVQx1J5bF = FvNyZqaLKw(u"ࡕࡴࡸࡩ៼") if allow_redirects else sTcr7iDp5eFt4RoLMhuwq1A(u"ࡆࡢ࡮ࡶࡩ៻")
	BBYvCiQGe8RdpyAagfS72mZclxb5 = {} if headers==lc0dpSmwoPDjLnk(u"ࠨࠩኒ") else headers
	Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = {} if data==SO94xq1RAkMm2uF(u"ࠩࠪና") else data
	JBLoPrMW9ZfsRGbaAU2O = list(BBYvCiQGe8RdpyAagfS72mZclxb5.keys())
	if kEhAHvti6Vnsfx(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫኔ") not in JBLoPrMW9ZfsRGbaAU2O: BBYvCiQGe8RdpyAagfS72mZclxb5[wRxoKs10Syj7V4edYhtP(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬን")] = oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠬ࡮ࡴࡵࡲࠪኖ")
	if YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪኗ") not in JBLoPrMW9ZfsRGbaAU2O: BBYvCiQGe8RdpyAagfS72mZclxb5[UTelCo0ihE1d5R(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫኘ")] = Y8Y6b7aLSUKjdE1Ae(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࡖࡵࡹࡪ៽"))
	return vYFXP48WV6M,mHejXxkvM1qCESPVRy54QB,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,OCa4ZAo2pviYzdfuVQx1J5bF,qDzNIhmbFvwp8arWP,hayXA4TiLlPxcVSIoK2,PiHc07NenyoQB,ncipfgE3NSFUhlZC
def mIZr8L4njqgR(vYFXP48WV6M,mHejXxkvM1qCESPVRy54QB,rKagANTOtGJnhVWfE2BHpePYC3IQ5l,ep9JAOkj1wr5s,hXWtlI25BjAiN6ESe1ka79dc8PsGD,showDialogs,hayXA4TiLlPxcVSIoK2,GPBaUzVhdpyO6xkJD2=YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠨࠩኙ"),t8x23UOsYmr9IDik06pG=Me28A1sBLNIgUp5YCDyvT(u"ࠩࠪኚ")):
	AApkbKmuNhY14teiI2UMP7wQEf = V0DM83o2AXcT4mLwJzQkbhnR(vYFXP48WV6M,mHejXxkvM1qCESPVRy54QB,rKagANTOtGJnhVWfE2BHpePYC3IQ5l,ep9JAOkj1wr5s,hXWtlI25BjAiN6ESe1ka79dc8PsGD,showDialogs,hayXA4TiLlPxcVSIoK2,GPBaUzVhdpyO6xkJD2,t8x23UOsYmr9IDik06pG)
	vYFXP48WV6M,mHejXxkvM1qCESPVRy54QB,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,OCa4ZAo2pviYzdfuVQx1J5bF,qDzNIhmbFvwp8arWP,hayXA4TiLlPxcVSIoK2,PiHc07NenyoQB,ncipfgE3NSFUhlZC = AApkbKmuNhY14teiI2UMP7wQEf
	dR2vHyAtl8pJN1,yaeqrwZ9BhV7N1,N3aW1fHjZrXkGdCVmzMolTvqpI,bbCy3Uxd48jVeNmT1c = GUnATzyQjq(mHejXxkvM1qCESPVRy54QB)
	gc1t0hHWKiG5Uxb2s = jHevARrF7lS.getSetting(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠪࡥࡻ࠴ࡤ࡯ࡵࠪኛ"))
	vEVCdcZuawPG6R4qDY = jHevARrF7lS.getSetting(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧኜ"))
	JdBcwGztPqOm6g = jHevARrF7lS.getSetting(Me28A1sBLNIgUp5YCDyvT(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪኝ"))
	Z8XzijnBexm = [Me28A1sBLNIgUp5YCDyvT(u"࠭ࡳࡤࡴࡤࡴࡪࡸࡡࡱ࡫ࠪኞ"),UTelCo0ihE1d5R(u"ࠧࡴࡥࡵࡥࡵ࡫࡯ࡱࡵࠪኟ"),E6MIKdpBomef(u"ࠨࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹ࠭አ"),FvNyZqaLKw(u"ࠩࡶࡧࡷࡧࡰࡦࡷࡳࠫኡ"),FvNyZqaLKw(u"ࠪࡷࡨࡸࡡࡱࡧ࠱ࡨࡴ࠭ኢ")]
	QAbmUsvWruyN98RfthLK = G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࡘࡷࡻࡥ៿") if any(hieW1zRUG5w9AykJjv0X in mHejXxkvM1qCESPVRy54QB for hieW1zRUG5w9AykJjv0X in Z8XzijnBexm) else bUdr5Hahw6sY8xJ(u"ࡉࡥࡱࡹࡥ៾")
	if iUeoLOsbHqP(u"ࠫࠫࡻࡲ࡭࠿ࠪኣ") in dR2vHyAtl8pJN1 and QAbmUsvWruyN98RfthLK: KXRYo6P5amVUIw4eyzBxHGdc8 = dR2vHyAtl8pJN1.rsplit(fprnld4CZo(u"ࠬࠬࡵࡳ࡮ࡀࠫኤ"),yA5z6LIXBlo41PRVMY87wOisFp(u"࠵᜘"))[yA5z6LIXBlo41PRVMY87wOisFp(u"࠵᜘")]
	else: KXRYo6P5amVUIw4eyzBxHGdc8 = sTcr7iDp5eFt4RoLMhuwq1A(u"࠭ࠧእ")
	EelqVTr2DuJw8i39xQ6sNHYRPtX4 = oSVpce1UQYrDqhuM6PT[kEhAHvti6Vnsfx(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧኦ")]
	T3oFJKaw2tipqmgUhelHQ4MSIG9 = dR2vHyAtl8pJN1 in EelqVTr2DuJw8i39xQ6sNHYRPtX4 or KXRYo6P5amVUIw4eyzBxHGdc8 in EelqVTr2DuJw8i39xQ6sNHYRPtX4
	Gf1v8juHCUAL70VN5mditg4nP = oSVpce1UQYrDqhuM6PT[FvNyZqaLKw(u"ࠨࡔࡈࡔࡔ࡙ࠧኧ")]
	l0lvcJiuoBOwWkTGDX9Yt18AE = dR2vHyAtl8pJN1 in Gf1v8juHCUAL70VN5mditg4nP or KXRYo6P5amVUIw4eyzBxHGdc8 in Gf1v8juHCUAL70VN5mditg4nP
	vt2fluJHn60KFwhq8cO = T3oFJKaw2tipqmgUhelHQ4MSIG9 or l0lvcJiuoBOwWkTGDX9Yt18AE
	HHzoanrd7QeVjqREugTsWYfl = yaeqrwZ9BhV7N1==None and N3aW1fHjZrXkGdCVmzMolTvqpI==None and not QAbmUsvWruyN98RfthLK
	if HHzoanrd7QeVjqREugTsWYfl and vt2fluJHn60KFwhq8cO:
		if T3oFJKaw2tipqmgUhelHQ4MSIG9:
			CGXRA48z139 = EelqVTr2DuJw8i39xQ6sNHYRPtX4.index(dR2vHyAtl8pJN1)
			h1Itiq73fDA82YzjC6 = oSVpce1UQYrDqhuM6PT[zqdvcbP5L8BHh(u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠭ከ")][CGXRA48z139]
			bR9ysk1LFHUVWo83vinAY75qIlCxfD = ZVrQewF1XiazvmI7oYnbMW[CGXRA48z139]
		elif l0lvcJiuoBOwWkTGDX9Yt18AE:
			CGXRA48z139 = Gf1v8juHCUAL70VN5mditg4nP.index(dR2vHyAtl8pJN1)
			h1Itiq73fDA82YzjC6 = oSVpce1UQYrDqhuM6PT[LiRcTVUWuth70DmPy(u"ࠪࡖࡊࡖࡏࡔࡡࡅࡏࡕ࠭ኩ")][CGXRA48z139]
			bR9ysk1LFHUVWo83vinAY75qIlCxfD = lZU9W7XhDxpeSA56vgQdi0[CGXRA48z139]
	if N3aW1fHjZrXkGdCVmzMolTvqpI==XzrqbGDIy54juixkMA(u"ࠫࠬኪ"): N3aW1fHjZrXkGdCVmzMolTvqpI = gc1t0hHWKiG5Uxb2s
	elif N3aW1fHjZrXkGdCVmzMolTvqpI==None and vEVCdcZuawPG6R4qDY in [QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬࡇࡕࡕࡑࠪካ"),Cu1704YofAbr3QTm(u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨኬ")] and PiHc07NenyoQB: N3aW1fHjZrXkGdCVmzMolTvqpI = gc1t0hHWKiG5Uxb2s
	CXZy2WU7xBwn6YjlI0 = dR2vHyAtl8pJN1==oSVpce1UQYrDqhuM6PT[UTelCo0ihE1d5R(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧክ")][FnBiAjthS8MkXs67W(u"࠼᜙")]
	if T3oFJKaw2tipqmgUhelHQ4MSIG9 or l0lvcJiuoBOwWkTGDX9Yt18AE: I26dXLNboZt7ie = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠷࠵᜚")
	elif hayXA4TiLlPxcVSIoK2 in cqyx3WnkJKH2TIA: I26dXLNboZt7ie = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠱࠱᜛")
	elif hayXA4TiLlPxcVSIoK2==oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡉ࡛ࡋࡒࡔࡑࡢࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠳࠱ࡴࡶࠪኮ"): I26dXLNboZt7ie = sTcr7iDp5eFt4RoLMhuwq1A(u"࠳࠲᜜")
	elif hayXA4TiLlPxcVSIoK2==wRxoKs10Syj7V4edYhtP(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠳࠱ࡴࡶࠪኯ"): I26dXLNboZt7ie = p72fnFtcPix5UKwr9YNzW(u"࠴࠳᜝")
	elif dshJSmRqeiP9nap2(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌ࡙ࡄࡑࠬኰ") in hayXA4TiLlPxcVSIoK2: I26dXLNboZt7ie = UTelCo0ihE1d5R(u"࠺࠴᜞")
	elif yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫࡘࡎࡏࡇࡊࡄࠫ኱") in hayXA4TiLlPxcVSIoK2: I26dXLNboZt7ie = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠻࠺ᜟ")
	elif oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠬࡉࡉࡎࡃ࠷࡙ࠬኲ") in hayXA4TiLlPxcVSIoK2: I26dXLNboZt7ie = sTcr7iDp5eFt4RoLMhuwq1A(u"࠷࠻ᜠ")
	elif SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࡁࡉ࡙ࡄࡏࠬኳ") in hayXA4TiLlPxcVSIoK2: I26dXLNboZt7ie = LiRcTVUWuth70DmPy(u"࠸࠰ᜡ")
	elif p72fnFtcPix5UKwr9YNzW(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪኴ") in hayXA4TiLlPxcVSIoK2: I26dXLNboZt7ie = kEhAHvti6Vnsfx(u"࠲࠱ᜢ")
	elif G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࡚ࡓࡗࡑࠧኵ") in hayXA4TiLlPxcVSIoK2: I26dXLNboZt7ie = wRxoKs10Syj7V4edYhtP(u"࠴࠲ᜣ")
	elif E6MIKdpBomef(u"ࠩࡄࡏࡔࡇࡍࠨ኶") in hayXA4TiLlPxcVSIoK2: I26dXLNboZt7ie = FnBiAjthS8MkXs67W(u"࠴࠸ᜤ")
	elif SO94xq1RAkMm2uF(u"ࠪࡅࡐ࡝ࡁࡎࠩ኷") in hayXA4TiLlPxcVSIoK2: I26dXLNboZt7ie = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠶࠴ᜥ")
	elif FvNyZqaLKw(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭ኸ") in hayXA4TiLlPxcVSIoK2: I26dXLNboZt7ie = iRoLg2m47tnDATBHGCSPNyx(u"࠶࠵ᜦ")
	elif iRoLg2m47tnDATBHGCSPNyx(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧኹ") in hayXA4TiLlPxcVSIoK2: I26dXLNboZt7ie = E6MIKdpBomef(u"࠻࠶ᜧ")
	elif E6MIKdpBomef(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨኺ") in hayXA4TiLlPxcVSIoK2: I26dXLNboZt7ie = xW2Arao7YVOemw(u"࠺࠰ᜨ")
	else: I26dXLNboZt7ie = yA5z6LIXBlo41PRVMY87wOisFp(u"࠱࠶ᜩ")
	MMZ5bshxKGJImFQBntCV9edr8U2fTv = (yaeqrwZ9BhV7N1!=None)
	sh54D1QEFM2ouxVq6 = (N3aW1fHjZrXkGdCVmzMolTvqpI!=None and vEVCdcZuawPG6R4qDY!=l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧࡔࡖࡒࡔࠬኻ"))
	if QAbmUsvWruyN98RfthLK: I26dXLNboZt7ie = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠷࠲ᜪ")
	if MMZ5bshxKGJImFQBntCV9edr8U2fTv and not QAbmUsvWruyN98RfthLK: From8aTqdhCbPs(XzrqbGDIy54juixkMA(u"ࠨฬไ฽๏๊ࠠษำ๋็ุ๐ࠠาไ่ࠫኼ"),yaeqrwZ9BhV7N1)
	elif sh54D1QEFM2ouxVq6: From8aTqdhCbPs(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩอๅ฾๐ไࠡࡆࡑࡗࠥืโๆࠩኽ"),N3aW1fHjZrXkGdCVmzMolTvqpI)
	if MMZ5bshxKGJImFQBntCV9edr8U2fTv:
		m5rkWnXjq9bQiR4 = {hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠥ࡬ࡹࡺࡰࠣኾ"):yaeqrwZ9BhV7N1,kEhAHvti6Vnsfx(u"ࠦ࡭ࡺࡴࡱࡵࠥ኿"):yaeqrwZ9BhV7N1}
		BBy4gfvEG6KcUVxr0QX = yaeqrwZ9BhV7N1
	else: m5rkWnXjq9bQiR4,BBy4gfvEG6KcUVxr0QX = {},LiRcTVUWuth70DmPy(u"ࠬ࠭ዀ")
	if sh54D1QEFM2ouxVq6:
		import urllib3.util.connection as fqRpnCHvNOz48e6
		V8Ev9npKcoL2mB1 = ZCeV0YOWPsjg7RtH(fqRpnCHvNOz48e6,gc1t0hHWKiG5Uxb2s)
	MM68HsAEi2N9L7y4lZ,Sdpv67IZVkJ8thgnX4jGEsq2NMD,n7V8RZPHWqpy,zUZ6MvWLTsJjCaFfl,vAHVGzEjId3TkZxc,verify = OCa4ZAo2pviYzdfuVQx1J5bF,hayXA4TiLlPxcVSIoK2,vYFXP48WV6M,SO94xq1RAkMm2uF(u"ࡋࡧ࡬ࡴࡧ᠀"),SO94xq1RAkMm2uF(u"ࡋࡧ࡬ࡴࡧ᠀"),bbCy3Uxd48jVeNmT1c
	if CXZy2WU7xBwn6YjlI0: vAHVGzEjId3TkZxc = kEhAHvti6Vnsfx(u"࡚ࡲࡶࡧ᠁")
	if vt2fluJHn60KFwhq8cO or OCa4ZAo2pviYzdfuVQx1J5bF: MM68HsAEi2N9L7y4lZ = iRoLg2m47tnDATBHGCSPNyx(u"ࡆࡢ࡮ࡶࡩ᠂")
	if T3oFJKaw2tipqmgUhelHQ4MSIG9: n7V8RZPHWqpy = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࡐࡐࡕࡗࠫ዁")
	llhyFWpP90RSDQM,r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6 = -SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠳ᜫ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡇࡵࡶࡴࡸࠧዂ")
	for CQMipytPbq in range(dshJSmRqeiP9nap2(u"࠼ᜬ")):
		APCdxQKoXLIaBOvyub3MqY4Eh6gV = FvNyZqaLKw(u"ࡕࡴࡸࡩ᠃")
		Tr8iRxJmbcEhftU5DSHzA = XzrqbGDIy54juixkMA(u"ࡈࡤࡰࡸ࡫᠄")
		try:
			if CQMipytPbq: Sdpv67IZVkJ8thgnX4jGEsq2NMD = lc0dpSmwoPDjLnk(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗ࠲࠷ࡳࡵࠩዃ")
			if QAbmUsvWruyN98RfthLK or not MMZ5bshxKGJImFQBntCV9edr8U2fTv: XXmSpTHNao6Gxbs0eK5(SO94xq1RAkMm2uF(u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡖࠤࠥࡕࡐࡆࡐࡢ࡙ࡗࡒࠧዄ"),dR2vHyAtl8pJN1,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,Sdpv67IZVkJ8thgnX4jGEsq2NMD,n7V8RZPHWqpy)
			try: YutQm2AwozR9VKp4O1lWj8FaryI.close()
			except: pass
			XwyU6PQgprMI0 = dR2vHyAtl8pJN1
			YutQm2AwozR9VKp4O1lWj8FaryI = DJ1rx9fvXIgUS7sZkVlOeGHb.request(n7V8RZPHWqpy,dR2vHyAtl8pJN1,data=Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,headers=BBYvCiQGe8RdpyAagfS72mZclxb5,verify=verify,allow_redirects=MM68HsAEi2N9L7y4lZ,timeout=I26dXLNboZt7ie,proxies=m5rkWnXjq9bQiR4)
			if g4g6bfkPtVGU5lIM3(u"࠷࠵࠶ᜭ")<=YutQm2AwozR9VKp4O1lWj8FaryI.status_code<=kEhAHvti6Vnsfx(u"࠸࠿࠹ᜮ"):
				if not zUZ6MvWLTsJjCaFfl:
					C8CQoX2hDPZ = list(YutQm2AwozR9VKp4O1lWj8FaryI.headers.keys())
					if FnBiAjthS8MkXs67W(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬዅ") in C8CQoX2hDPZ: dR2vHyAtl8pJN1 = YutQm2AwozR9VKp4O1lWj8FaryI.headers[QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭዆")]
					elif SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧ዇") in C8CQoX2hDPZ: dR2vHyAtl8pJN1 = YutQm2AwozR9VKp4O1lWj8FaryI.headers[SO94xq1RAkMm2uF(u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠨወ")]
					else: zUZ6MvWLTsJjCaFfl = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࡗࡶࡺ࡫᠅")
					if not zUZ6MvWLTsJjCaFfl: dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1.encode(SO94xq1RAkMm2uF(u"ࠧ࡭ࡣࡷ࡭ࡳ࠳࠱ࠨዉ"),wRxoKs10Syj7V4edYhtP(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨዊ")).decode(fprnld4CZo(u"ࠩࡸࡸ࡫࠾ࠧዋ"),xW2Arao7YVOemw(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪዌ"))
					if vt2fluJHn60KFwhq8cO and YutQm2AwozR9VKp4O1lWj8FaryI.status_code==G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠹࠰࠸ᜯ"):
						MM68HsAEi2N9L7y4lZ = OCa4ZAo2pviYzdfuVQx1J5bF
						n7V8RZPHWqpy = vYFXP48WV6M
						zUZ6MvWLTsJjCaFfl = lc0dpSmwoPDjLnk(u"ࡘࡷࡻࡥ᠆")
						iVx0jKXkfsThcq1
				if not zUZ6MvWLTsJjCaFfl or OCa4ZAo2pviYzdfuVQx1J5bF:
					if oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫ࡭ࡺࡴࡱࠩው") not in dR2vHyAtl8pJN1:
						VLDy4EIJqvpHauK0nMes9 = RfKuIXwPAiWtmyF(XwyU6PQgprMI0,xW2Arao7YVOemw(u"ࠬࡻࡲ࡭ࠩዎ"))
						dR2vHyAtl8pJN1 = VLDy4EIJqvpHauK0nMes9+YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭࠯ࠨዏ")+dR2vHyAtl8pJN1.lstrip(hBvsQ7oCkKUdwjx58ml3EN(u"ࠧ࠰ࠩዐ"))
				if not zUZ6MvWLTsJjCaFfl and OCa4ZAo2pviYzdfuVQx1J5bF and not dd8rHcveo7O15hT3MSR(dR2vHyAtl8pJN1): WKEF0ZkVOUPNtmpo8wjhC3bSBAM5
			elif hBvsQ7oCkKUdwjx58ml3EN(u"࠶࠷࠳ᜱ")<=YutQm2AwozR9VKp4O1lWj8FaryI.status_code<=XzrqbGDIy54juixkMA(u"࠵࠺࠻ᜰ"):
				YutQm2AwozR9VKp4O1lWj8FaryI.reason = YutQm2AwozR9VKp4O1lWj8FaryI.content
				vAHVGzEjId3TkZxc = yA5z6LIXBlo41PRVMY87wOisFp(u"࡙ࡸࡵࡦ᠇")
			XwyU6PQgprMI0 = YutQm2AwozR9VKp4O1lWj8FaryI.url
			llhyFWpP90RSDQM = YutQm2AwozR9VKp4O1lWj8FaryI.status_code
			r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6 = YutQm2AwozR9VKp4O1lWj8FaryI.reason
			YutQm2AwozR9VKp4O1lWj8FaryI.raise_for_status()
			Tr8iRxJmbcEhftU5DSHzA = QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࡚ࡲࡶࡧ᠈")
		except DJ1rx9fvXIgUS7sZkVlOeGHb.exceptions.HTTPError as D2VbK9hH17PSolWyBT8Uu:
			pass
		except DJ1rx9fvXIgUS7sZkVlOeGHb.exceptions.Timeout as D2VbK9hH17PSolWyBT8Uu:
			if HHosl5fRdhtEDAYyP: r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6 = str(D2VbK9hH17PSolWyBT8Uu.message).split(fprnld4CZo(u"ࠨ࠼ࠣࠫዑ"))[xW2Arao7YVOemw(u"࠳ᜲ")]
			else: r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6 = str(D2VbK9hH17PSolWyBT8Uu).split(SO94xq1RAkMm2uF(u"ࠩ࠽ࠤࠬዒ"))[lc0dpSmwoPDjLnk(u"࠴ᜳ")]
		except DJ1rx9fvXIgUS7sZkVlOeGHb.exceptions.ConnectionError as D2VbK9hH17PSolWyBT8Uu:
			try: VVEta3LoIkqnG = D2VbK9hH17PSolWyBT8Uu.message[UTelCo0ihE1d5R(u"࠴᜴")]
			except: VVEta3LoIkqnG = str(D2VbK9hH17PSolWyBT8Uu)
			aaY5ASKGWkXx0eIfqtCvpc9 = GGvHJKP9LUxEk10Fw.findall(XzrqbGDIy54juixkMA(u"ࠥࡠࡠࡋࡲࡳࡰࡲࠤ࠭ࡢࡤࠬࠫ࡟ࡡࠥ࠮࠮ࠫࡁࠬࠫࠧዓ"),VVEta3LoIkqnG)
			if not aaY5ASKGWkXx0eIfqtCvpc9: aaY5ASKGWkXx0eIfqtCvpc9 = GGvHJKP9LUxEk10Fw.findall(xW2Arao7YVOemw(u"ࠦ࠱ࠦࡥࡳࡴࡲࡶࡡ࠮ࠨ࡝ࡦ࠮࠭࠱ࠦࠧࠩ࠰࠭ࡃ࠮࠭ࠢዔ"),VVEta3LoIkqnG)
			if not aaY5ASKGWkXx0eIfqtCvpc9:
				eVlvSXa74WAgBEk68NGpsUTujxtbYo = GGvHJKP9LUxEk10Fw.findall(zqdvcbP5L8BHh(u"ࠧࡀࠠࠩ࠰࠭ࡃ࠮ࡀ࠮ࠫࡁࠫࡠࡩ࠱ࠩ࠻ࠤዕ"),VVEta3LoIkqnG)
				if eVlvSXa74WAgBEk68NGpsUTujxtbYo: aaY5ASKGWkXx0eIfqtCvpc9 = [eVlvSXa74WAgBEk68NGpsUTujxtbYo[FnBiAjthS8MkXs67W(u"࠶᜶")][iUeoLOsbHqP(u"࠶᜵")],eVlvSXa74WAgBEk68NGpsUTujxtbYo[FnBiAjthS8MkXs67W(u"࠶᜶")][FnBiAjthS8MkXs67W(u"࠶᜶")]]
			if not aaY5ASKGWkXx0eIfqtCvpc9: aaY5ASKGWkXx0eIfqtCvpc9 = GGvHJKP9LUxEk10Fw.findall(Me28A1sBLNIgUp5YCDyvT(u"ࠨ࠺ࠩ࡞ࡧ࠯࠮ࡀࠠࠩ࠰࠭ࡃ࠮࠭ࠢዖ"),VVEta3LoIkqnG)
			if not aaY5ASKGWkXx0eIfqtCvpc9: aaY5ASKGWkXx0eIfqtCvpc9 = GGvHJKP9LUxEk10Fw.findall(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠢࠡࠪ࡟ࡨ࠰࠯࡝ࠡࠪ࠱࠮ࡄ࠯ࠧࠣ዗"),VVEta3LoIkqnG)
			try: llhyFWpP90RSDQM,r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6 = aaY5ASKGWkXx0eIfqtCvpc9[FnBiAjthS8MkXs67W(u"࠰᜷")]
			except: llhyFWpP90RSDQM,r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6 = -kEhAHvti6Vnsfx(u"࠳᜸"),VVEta3LoIkqnG
		except DJ1rx9fvXIgUS7sZkVlOeGHb.exceptions.RequestException as D2VbK9hH17PSolWyBT8Uu:
			if HHosl5fRdhtEDAYyP: r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6 = D2VbK9hH17PSolWyBT8Uu.message
			else: r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6 = str(D2VbK9hH17PSolWyBT8Uu)
		except:
			APCdxQKoXLIaBOvyub3MqY4Eh6gV = FvNyZqaLKw(u"ࡆࡢ࡮ࡶࡩ᠉")
			try: llhyFWpP90RSDQM = YutQm2AwozR9VKp4O1lWj8FaryI.status_code
			except: pass
			try: r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6 = YutQm2AwozR9VKp4O1lWj8FaryI.reason
			except: pass
		r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6 = str(r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6)
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q(xW2Arao7YVOemw(u"ࠨࡐࡒࡘࡎࡉࡅࠨዘ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩ࠱ࠤࠥࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࠡࠢࡕࡉࡘࡖࡏࡏࡕࡈࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧዙ")+str(llhyFWpP90RSDQM)+fprnld4CZo(u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬዚ")+r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6+iUeoLOsbHqP(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ዛ")+hayXA4TiLlPxcVSIoK2+dshJSmRqeiP9nap2(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫዜ")+mHejXxkvM1qCESPVRy54QB+p72fnFtcPix5UKwr9YNzW(u"࠭ࠠ࡞ࠩዝ"))
		if HHzoanrd7QeVjqREugTsWYfl and vt2fluJHn60KFwhq8cO and APCdxQKoXLIaBOvyub3MqY4Eh6gV and not vAHVGzEjId3TkZxc and llhyFWpP90RSDQM!=sTcr7iDp5eFt4RoLMhuwq1A(u"࠴࠳࠴᜹"):
			dR2vHyAtl8pJN1 = h1Itiq73fDA82YzjC6
			vAHVGzEjId3TkZxc = G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࡕࡴࡸࡩ᠊")
			continue
		if APCdxQKoXLIaBOvyub3MqY4Eh6gV: break
	if N3aW1fHjZrXkGdCVmzMolTvqpI!=None and vEVCdcZuawPG6R4qDY!=iUeoLOsbHqP(u"ࠧࡔࡖࡒࡔࠬዞ"): fqRpnCHvNOz48e6.create_connection = V8Ev9npKcoL2mB1
	if vEVCdcZuawPG6R4qDY==oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨࡃࡏ࡛ࡆ࡟ࡓࠨዟ") and PiHc07NenyoQB: N3aW1fHjZrXkGdCVmzMolTvqpI = None
	if not Tr8iRxJmbcEhftU5DSHzA and yaeqrwZ9BhV7N1==None and hayXA4TiLlPxcVSIoK2 not in cqyx3WnkJKH2TIA:
		CCeZSJvsigLcq = FTYWns4Q7dSEXmBOAGlJ.format_exc()
		if CCeZSJvsigLcq!=YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬዠ"): GGtWyVoJReUuEBCdAagiL1YXO8.stderr.write(CCeZSJvsigLcq)
	QQTDOLdNUAzYbfl1vXrM8mB = dMPXkHuB87WsyEUNGQ6IeY()
	if QAbmUsvWruyN98RfthLK: XwyU6PQgprMI0 = KXRYo6P5amVUIw4eyzBxHGdc8
	QQTDOLdNUAzYbfl1vXrM8mB.url = XwyU6PQgprMI0
	QQTDOLdNUAzYbfl1vXrM8mB.scrape = QAbmUsvWruyN98RfthLK
	try: CmklERKLJO6vjyHAs8hXuYW = YutQm2AwozR9VKp4O1lWj8FaryI.content
	except: CmklERKLJO6vjyHAs8hXuYW = wRxoKs10Syj7V4edYhtP(u"ࠪࠫዡ")
	try: hTCIe9pGxs = YutQm2AwozR9VKp4O1lWj8FaryI.headers
	except: hTCIe9pGxs = {}
	try: oCAvXwQ0sRYfaOB = YutQm2AwozR9VKp4O1lWj8FaryI.cookies.get_dict()
	except: oCAvXwQ0sRYfaOB = {}
	try: YutQm2AwozR9VKp4O1lWj8FaryI.close()
	except: pass
	if u4ChFMGf6K93tbDjJ12zi0YQsAHyP:
		try: CmklERKLJO6vjyHAs8hXuYW = CmklERKLJO6vjyHAs8hXuYW.decode(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠫࡺࡺࡦ࠹ࠩዢ"))
		except: pass
	llhyFWpP90RSDQM = int(llhyFWpP90RSDQM)
	QQTDOLdNUAzYbfl1vXrM8mB.code = llhyFWpP90RSDQM
	QQTDOLdNUAzYbfl1vXrM8mB.reason = r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6
	QQTDOLdNUAzYbfl1vXrM8mB.content = CmklERKLJO6vjyHAs8hXuYW
	QQTDOLdNUAzYbfl1vXrM8mB.headers = hTCIe9pGxs
	QQTDOLdNUAzYbfl1vXrM8mB.cookies = oCAvXwQ0sRYfaOB
	QQTDOLdNUAzYbfl1vXrM8mB.succeeded = Tr8iRxJmbcEhftU5DSHzA
	QQTDOLdNUAzYbfl1vXrM8mB.scrapernumber = FvNyZqaLKw(u"ࠬ࠭ዣ")
	QQTDOLdNUAzYbfl1vXrM8mB.scraperserver = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ࠧዤ")
	QQTDOLdNUAzYbfl1vXrM8mB.scraperurl = fprnld4CZo(u"ࠧࠨዥ")
	if HHosl5fRdhtEDAYyP or isinstance(QQTDOLdNUAzYbfl1vXrM8mB.content,str): FENvJfYn2t4MULwhzpGecC = QQTDOLdNUAzYbfl1vXrM8mB.content.lower()
	else: FENvJfYn2t4MULwhzpGecC = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨࠩዦ")
	GwBsaCOTjM14 = (hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪ࠭ዧ") in FENvJfYn2t4MULwhzpGecC or SO94xq1RAkMm2uF(u"ࠪ࡫ࡴࡵࡧ࡭ࡧࠪየ") in FENvJfYn2t4MULwhzpGecC) and FENvJfYn2t4MULwhzpGecC.count(kEhAHvti6Vnsfx(u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧࠧዩ"))>Me28A1sBLNIgUp5YCDyvT(u"࠵᜺") and iUeoLOsbHqP(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧዪ") not in hayXA4TiLlPxcVSIoK2 and hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠯ࡷࡳࡰ࡫࡮ࠨያ") not in FENvJfYn2t4MULwhzpGecC and not QAbmUsvWruyN98RfthLK
	if llhyFWpP90RSDQM==g4g6bfkPtVGU5lIM3(u"࠶࠵࠶᜻") and GwBsaCOTjM14: QQTDOLdNUAzYbfl1vXrM8mB.succeeded = p72fnFtcPix5UKwr9YNzW(u"ࡈࡤࡰࡸ࡫᠋")
	if QQTDOLdNUAzYbfl1vXrM8mB.succeeded and HHzoanrd7QeVjqREugTsWYfl and vt2fluJHn60KFwhq8cO:
		if CXZy2WU7xBwn6YjlI0: bR9ysk1LFHUVWo83vinAY75qIlCxfD = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠧࡄࡃࡓࡘࡈࡎࡁࠨዬ")+Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd[zqdvcbP5L8BHh(u"ࠨ࡬ࡲࡦࠬይ")].upper().replace(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩࡊࡉ࡙࠭ዮ"),LiRcTVUWuth70DmPy(u"ࠪࠫዯ"))
		ye2NJVIc5j8 = EGTmIaUiSoHDC5bJlR19Zksqv(bR9ysk1LFHUVWo83vinAY75qIlCxfD)
	if not QQTDOLdNUAzYbfl1vXrM8mB.succeeded and HHzoanrd7QeVjqREugTsWYfl:
		FRZzAcUCSDTWGfswQdEuy = (UTelCo0ihE1d5R(u"ࠫࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨደ") in FENvJfYn2t4MULwhzpGecC and FvNyZqaLKw(u"ࠬࡸࡡࡺࠢ࡬ࡨ࠿ࠦࠧዱ") in FENvJfYn2t4MULwhzpGecC)
		CyIj0r4YWBA9Ln = (yA5z6LIXBlo41PRVMY87wOisFp(u"࠭࠵ࠡࡵࡨࡧࠬዲ") in FENvJfYn2t4MULwhzpGecC and zqdvcbP5L8BHh(u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࠨዳ") in FENvJfYn2t4MULwhzpGecC)
		YLHxTqrACwGzQOeiKSl4 = (llhyFWpP90RSDQM in [SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠹࠶࠳᜼")] and pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࡧࡵࡶࡴࡸࠠࡤࡱࡧࡩ࠿ࠦ࠱࠱࠴࠳ࠫዴ") in FENvJfYn2t4MULwhzpGecC)
		IzocNub0mRJXS8Z = (FvNyZqaLKw(u"ࠩࡢࡧ࡫ࡥࡣࡩ࡮ࡢࠫድ") in FENvJfYn2t4MULwhzpGecC and yA5z6LIXBlo41PRVMY87wOisFp(u"ࠪࡧ࡭ࡧ࡬࡭ࡧࡱ࡫ࡪ࠳ࠧዶ") in FENvJfYn2t4MULwhzpGecC)
		if   GwBsaCOTjM14: r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6 = E6MIKdpBomef(u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡴࡨࡧࡦࡶࡴࡤࡪࡤࠫዷ")
		elif FRZzAcUCSDTWGfswQdEuy: r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6 = lc0dpSmwoPDjLnk(u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪ࠭ዸ")
		elif CyIj0r4YWBA9Ln: r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6 = hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣ࠹ࠥࡹࡥࡤࡱࡱࡨࡸࠦࡢࡳࡱࡺࡷࡪࡸࠠࡤࡪࡨࡧࡰ࠭ዹ")
		elif YLHxTqrACwGzQOeiKSl4: r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6 = lc0dpSmwoPDjLnk(u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠡࡣࡦࡧࡪࡹࡳࠡࡦࡨࡲ࡮࡫ࡤࠨዺ")
		elif IzocNub0mRJXS8Z: r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6 = Cu1704YofAbr3QTm(u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠢࡶࡩࡨࡻࡲࡪࡶࡼࠤࡨ࡮ࡥࡤ࡭ࠪዻ")
		else: r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6 = str(r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6)
		if hayXA4TiLlPxcVSIoK2 in QQaW5UTufZ8X06EqILi: pass
		elif hayXA4TiLlPxcVSIoK2 in cqyx3WnkJKH2TIA:
			LOHZ4o9m7p6ebfTYXGIdz5PWs3q(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨዼ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠪࠤࠥࡊࡩࡳࡧࡦࡸࠥࡩ࡯࡯ࡰࡨࡧࡹ࡯࡯࡯ࠢࡩࡥ࡮ࡲࡥࡥࠢࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭ዽ")+str(llhyFWpP90RSDQM)+g4g6bfkPtVGU5lIM3(u"ࠫࠥࡣࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬዾ")+r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6+SO94xq1RAkMm2uF(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧዿ")+hayXA4TiLlPxcVSIoK2+S4SOKF2QbBhjCd3RrVMuHIzE(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬጀ")+dR2vHyAtl8pJN1+zqdvcbP5L8BHh(u"ࠧࠡ࡟ࠪጁ"))
		else: LOHZ4o9m7p6ebfTYXGIdz5PWs3q(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭ጂ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+FnBiAjthS8MkXs67W(u"ࠩࠣࠤࠥࡊࡩࡳࡧࡦࡸࠥࡩ࡯࡯ࡰࡨࡧࡹ࡯࡯࡯ࠢࡩࡥ࡮ࡲࡥࡥࠢࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭ጃ")+str(llhyFWpP90RSDQM)+SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪࠤࡢࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫጄ")+r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6+iUeoLOsbHqP(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ጅ")+hayXA4TiLlPxcVSIoK2+p72fnFtcPix5UKwr9YNzW(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫጆ")+dR2vHyAtl8pJN1+hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ࠠ࡞ࠩጇ"))
		RJ1UdHB3qC8v2 = KXRYo6P5amVUIw4eyzBxHGdc8 if QAbmUsvWruyN98RfthLK else GhPlajzTxY8(dR2vHyAtl8pJN1)
		if HHosl5fRdhtEDAYyP and isinstance(RJ1UdHB3qC8v2,unicode): RJ1UdHB3qC8v2 = RJ1UdHB3qC8v2.encode(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࡶࡶࡩ࠼ࠬገ"))
		if vt2fluJHn60KFwhq8cO: RJ1UdHB3qC8v2 = RJ1UdHB3qC8v2.split(wRxoKs10Syj7V4edYhtP(u"ࠨ࠱ࠪጉ"))[-FvNyZqaLKw(u"࠷᜽")]
		SBUF6NOuZGfoClxKA0spi = str(r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6)+iUeoLOsbHqP(u"ࠩ࡟ࡲ࠭ࠦࠧጊ")+RJ1UdHB3qC8v2+zqdvcbP5L8BHh(u"ࠪࠤ࠮࠭ጋ")
		if llhyFWpP90RSDQM in [-lc0dpSmwoPDjLnk(u"࠱᜾"),-pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠳᜿")] or GwBsaCOTjM14 or FRZzAcUCSDTWGfswQdEuy or CyIj0r4YWBA9Ln or YLHxTqrACwGzQOeiKSl4 or IzocNub0mRJXS8Z:
			QQTDOLdNUAzYbfl1vXrM8mB.code = -bUdr5Hahw6sY8xJ(u"࠵ᝀ")
			QQTDOLdNUAzYbfl1vXrM8mB.reason = r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6
			if ncipfgE3NSFUhlZC:
				CjElJZembnS3q = tWBJhyRicnY0SrZmQApbg56a(vYFXP48WV6M,dR2vHyAtl8pJN1,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,OCa4ZAo2pviYzdfuVQx1J5bF,qDzNIhmbFvwp8arWP,hayXA4TiLlPxcVSIoK2,llhyFWpP90RSDQM,r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6)
				if CjElJZembnS3q.succeeded: return CjElJZembnS3q
		o07Z1tEB4n3ARCkVNu = E6MIKdpBomef(u"ࡗࡶࡺ࡫᠌")
		if (vEVCdcZuawPG6R4qDY==l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫࡆ࡙ࡋࠨጌ") or JdBcwGztPqOm6g==Me28A1sBLNIgUp5YCDyvT(u"ࠬࡇࡓࡌࠩግ")) and (PiHc07NenyoQB or ncipfgE3NSFUhlZC):
			o07Z1tEB4n3ARCkVNu = I9zaUCksnTt0rXj7OQuoJyfwKgL(llhyFWpP90RSDQM,SBUF6NOuZGfoClxKA0spi,hayXA4TiLlPxcVSIoK2,qDzNIhmbFvwp8arWP)
			if o07Z1tEB4n3ARCkVNu and vEVCdcZuawPG6R4qDY==UTelCo0ihE1d5R(u"࠭ࡁࡔࡍࠪጎ"): vEVCdcZuawPG6R4qDY = YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࡂࡅࡆࡉࡕ࡚ࡅࡅࠩጏ")
			else: vEVCdcZuawPG6R4qDY = YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠨࡔࡈࡎࡊࡉࡔࡆࡆࠪጐ")
			if o07Z1tEB4n3ARCkVNu and JdBcwGztPqOm6g==dshJSmRqeiP9nap2(u"ࠩࡄࡗࡐ࠭጑"): JdBcwGztPqOm6g = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬጒ")
			else: JdBcwGztPqOm6g = SO94xq1RAkMm2uF(u"ࠫࡗࡋࡊࡆࡅࡗࡉࡉ࠭ጓ")
			jHevARrF7lS.setSetting(dshJSmRqeiP9nap2(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨጔ"),vEVCdcZuawPG6R4qDY)
			jHevARrF7lS.setSetting(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫጕ"),JdBcwGztPqOm6g)
		if o07Z1tEB4n3ARCkVNu:
			rVEdClJ9DU6MFQhgnaNw48qkHbK = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࡘࡷࡻࡥ᠍")
			if llhyFWpP90RSDQM==fprnld4CZo(u"࠻ᝁ") and QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧࡩࡶࡷࡴࡸ࠭጖") in dR2vHyAtl8pJN1 and rVEdClJ9DU6MFQhgnaNw48qkHbK:
				if qDzNIhmbFvwp8arWP: From8aTqdhCbPs(dshJSmRqeiP9nap2(u"ࠨฬไ฽๏๊ࠠโฯุࠤูํวะหࠣห้ะิโ์ิࠤࡘ࡙ࡌࠨ጗"),iRoLg2m47tnDATBHGCSPNyx(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫጘ"),MQbODJoPV2w8TEAg4zXZdjLxSW=bUdr5Hahw6sY8xJ(u"࠶࠵࠶࠰ᝂ"))
				XwyU6PQgprMI0 = dR2vHyAtl8pJN1+iUeoLOsbHqP(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪጙ")
				ye2NJVIc5j8 = mIZr8L4njqgR(vYFXP48WV6M,XwyU6PQgprMI0,rKagANTOtGJnhVWfE2BHpePYC3IQ5l,ep9JAOkj1wr5s,hXWtlI25BjAiN6ESe1ka79dc8PsGD,qDzNIhmbFvwp8arWP,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓ࠮࠴ࡱࡨࠬጚ"))
				if ye2NJVIc5j8.succeeded:
					QQTDOLdNUAzYbfl1vXrM8mB = ye2NJVIc5j8
					LOHZ4o9m7p6ebfTYXGIdz5PWs3q(FnBiAjthS8MkXs67W(u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫጛ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+lc0dpSmwoPDjLnk(u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡦࡦࡨࡨࠥࡻࡳࡪࡰࡪࠤࡘ࡙ࡌ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨጜ")+hayXA4TiLlPxcVSIoK2+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ጝ")+mHejXxkvM1qCESPVRy54QB+wRxoKs10Syj7V4edYhtP(u"ࠨࠢࡠࠫጞ"))
					if qDzNIhmbFvwp8arWP: From8aTqdhCbPs(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"้ࠩะฬำࠠษษึฮำีวๆࠢࡖࡗࡑ࠭ጟ"),iRoLg2m47tnDATBHGCSPNyx(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬጠ"),MQbODJoPV2w8TEAg4zXZdjLxSW=p72fnFtcPix5UKwr9YNzW(u"࠷࠶࠰࠱ᝃ"))
				else:
					LOHZ4o9m7p6ebfTYXGIdz5PWs3q(FnBiAjthS8MkXs67W(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩጡ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+E6MIKdpBomef(u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡷࡶ࡭ࡳ࡭ࠠࡔࡕࡏ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫጢ")+hayXA4TiLlPxcVSIoK2+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬጣ")+mHejXxkvM1qCESPVRy54QB+iUeoLOsbHqP(u"ࠧࠡ࡟ࠪጤ"))
					if qDzNIhmbFvwp8arWP: From8aTqdhCbPs(p72fnFtcPix5UKwr9YNzW(u"ࠨใื่ࠥฮวิฬัำฬ๋ࠠࡔࡕࡏࠫጥ"),SO94xq1RAkMm2uF(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫጦ"),MQbODJoPV2w8TEAg4zXZdjLxSW=pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠸࠰࠱࠲ᝄ"))
			if not QQTDOLdNUAzYbfl1vXrM8mB.succeeded and JdBcwGztPqOm6g in [hBvsQ7oCkKUdwjx58ml3EN(u"ࠪࡅ࡚࡚ࡏࠨጧ"),dshJSmRqeiP9nap2(u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭ጨ")] and ncipfgE3NSFUhlZC:
				if qDzNIhmbFvwp8arWP: From8aTqdhCbPs(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬะแฺ์็ࠤุ๐ัโำสฮࠥฮั้ๅึ๎ࠬጩ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨጪ"),MQbODJoPV2w8TEAg4zXZdjLxSW=UTelCo0ihE1d5R(u"࠲࠱࠲࠳ᝅ"))
				ye2NJVIc5j8 = dNR0xvuSyG4tWkieDslfYawc(vYFXP48WV6M,dR2vHyAtl8pJN1,rKagANTOtGJnhVWfE2BHpePYC3IQ5l,ep9JAOkj1wr5s,hXWtlI25BjAiN6ESe1ka79dc8PsGD,qDzNIhmbFvwp8arWP,hayXA4TiLlPxcVSIoK2)
				if ye2NJVIc5j8.succeeded:
					QQTDOLdNUAzYbfl1vXrM8mB = ye2NJVIc5j8
					LOHZ4o9m7p6ebfTYXGIdz5PWs3q(dshJSmRqeiP9nap2(u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭ጫ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+Cu1704YofAbr3QTm(u"ࠨࠢࠣࠤࡕࡸ࡯ࡹ࡫ࡨࡷࠥࡹࡵࡤࡥࡨࡩࡩ࡫ࡤ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨጬ")+hayXA4TiLlPxcVSIoK2+SO94xq1RAkMm2uF(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨጭ")+mHejXxkvM1qCESPVRy54QB+sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࠤࡢ࠭ጮ"))
					if qDzNIhmbFvwp8arWP: From8aTqdhCbPs(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"๋ࠫาวฮࠢึ๎ึ็ัศฬࠣฬึ๎ใิ์ࠪጯ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧጰ"),MQbODJoPV2w8TEAg4zXZdjLxSW=FnBiAjthS8MkXs67W(u"࠳࠲࠳࠴ᝆ"))
				else:
					LOHZ4o9m7p6ebfTYXGIdz5PWs3q(FvNyZqaLKw(u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫጱ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࠡࠢࠣࡔࡷࡵࡸࡪࡧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫጲ")+hayXA4TiLlPxcVSIoK2+bUdr5Hahw6sY8xJ(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧጳ")+mHejXxkvM1qCESPVRy54QB+E6MIKdpBomef(u"ࠩࠣࡡࠬጴ"))
					if qDzNIhmbFvwp8arWP: From8aTqdhCbPs(dshJSmRqeiP9nap2(u"ࠪๅู๊ࠠิ์ิๅึอสࠡสิ์ู่๊ࠨጵ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ጶ"),MQbODJoPV2w8TEAg4zXZdjLxSW=wRxoKs10Syj7V4edYhtP(u"࠴࠳࠴࠵ᝇ"))
			if not QQTDOLdNUAzYbfl1vXrM8mB.succeeded and vEVCdcZuawPG6R4qDY in [SO94xq1RAkMm2uF(u"ࠬࡇࡕࡕࡑࠪጷ"),FnBiAjthS8MkXs67W(u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨጸ")] and PiHc07NenyoQB:
				if qDzNIhmbFvwp8arWP: From8aTqdhCbPs(iUeoLOsbHqP(u"ࠧหใ฼๎้ࠦำ๋ำไีࠥࡊࡎࡔࠩጹ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪጺ"),MQbODJoPV2w8TEAg4zXZdjLxSW=lc0dpSmwoPDjLnk(u"࠵࠴࠵࠶ᝈ"))
				XwyU6PQgprMI0 = dR2vHyAtl8pJN1+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩࡿࢀࡒࡿࡄࡏࡕࡘࡶࡱࡃࠧጻ")
				ye2NJVIc5j8 = mIZr8L4njqgR(vYFXP48WV6M,XwyU6PQgprMI0,rKagANTOtGJnhVWfE2BHpePYC3IQ5l,ep9JAOkj1wr5s,hXWtlI25BjAiN6ESe1ka79dc8PsGD,qDzNIhmbFvwp8arWP,zqdvcbP5L8BHh(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࠭࠵ࡶ࡫ࠫጼ"))
				if ye2NJVIc5j8.succeeded:
					QQTDOLdNUAzYbfl1vXrM8mB = ye2NJVIc5j8
					LOHZ4o9m7p6ebfTYXGIdz5PWs3q(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪጽ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+E6MIKdpBomef(u"ࠬࠦࠠࠡࡆࡑࡗࠥࡹࡵࡤࡥࡨࡩࡩ࡫ࡤ࠻ࠢࠣࠤࡉࡔࡓ࠻ࠢ࡞ࠤࠬጾ")+gc1t0hHWKiG5Uxb2s+YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨጿ")+hayXA4TiLlPxcVSIoK2+xW2Arao7YVOemw(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ፀ")+mHejXxkvM1qCESPVRy54QB+zqdvcbP5L8BHh(u"ࠨࠢࡠࠫፁ"))
					if qDzNIhmbFvwp8arWP: From8aTqdhCbPs(dshJSmRqeiP9nap2(u"้ࠩะฬำࠠิ์ิๅึࠦࡄࡏࡕࠪፂ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬፃ"),MQbODJoPV2w8TEAg4zXZdjLxSW=oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠶࠵࠶࠰ᝉ"))
				else:
					LOHZ4o9m7p6ebfTYXGIdz5PWs3q(XzrqbGDIy54juixkMA(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩፄ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+hBvsQ7oCkKUdwjx58ml3EN(u"ࠬࠦࠠࠡࡆࡑࡗࠥ࡬ࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠡࡆࡑࡗ࠿࡛ࠦࠡࠩፅ")+gc1t0hHWKiG5Uxb2s+Me28A1sBLNIgUp5YCDyvT(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨፆ")+hayXA4TiLlPxcVSIoK2+E6MIKdpBomef(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ፇ")+mHejXxkvM1qCESPVRy54QB+fprnld4CZo(u"ࠨࠢࡠࠫፈ"))
					if qDzNIhmbFvwp8arWP: From8aTqdhCbPs(FnBiAjthS8MkXs67W(u"ࠩไุ้ࠦำ๋ำไีࠥࡊࡎࡔࠩፉ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬፊ"),MQbODJoPV2w8TEAg4zXZdjLxSW=FvNyZqaLKw(u"࠷࠶࠰࠱ᝊ"))
		if JdBcwGztPqOm6g==LiRcTVUWuth70DmPy(u"ࠫࡗࡋࡊࡆࡅࡗࡉࡉ࠭ፋ") or vEVCdcZuawPG6R4qDY==FnBiAjthS8MkXs67W(u"ࠬࡘࡅࡋࡇࡆࡘࡊࡊࠧፌ"): qDzNIhmbFvwp8arWP = g4g6bfkPtVGU5lIM3(u"ࡋࡧ࡬ࡴࡧ᠎")
		if not QQTDOLdNUAzYbfl1vXrM8mB.succeeded:
			if qDzNIhmbFvwp8arWP: rXe7KCkT4IqHE9 = I9zaUCksnTt0rXj7OQuoJyfwKgL(llhyFWpP90RSDQM,SBUF6NOuZGfoClxKA0spi,hayXA4TiLlPxcVSIoK2,qDzNIhmbFvwp8arWP)
			if llhyFWpP90RSDQM!=hBvsQ7oCkKUdwjx58ml3EN(u"࠸࠰࠱ᝋ") and hayXA4TiLlPxcVSIoK2 not in zzagHLkrSt2 and sTcr7iDp5eFt4RoLMhuwq1A(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࠪፍ") not in hayXA4TiLlPxcVSIoK2:
				zrIWmJZh2CpVf8(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧࡇࡱࡵࡧࡪࡪࠠࡦࡺ࡬ࡸࠥࡪࡵࡦࠢࡷࡳࠥࡴࡥࡵࡹࡲࡶࡰࠦࡩࡴࡵࡸࡩࡸࠦࡷࡪࡶ࡫࠾ࠥ࠭ፎ")+hayXA4TiLlPxcVSIoK2)
	if jHevARrF7lS.getSetting(hBvsQ7oCkKUdwjx58ml3EN(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫፏ")) not in [QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࡄ࡙࡙ࡕࠧፐ"),iUeoLOsbHqP(u"ࠪࡗ࡙ࡕࡐࠨፑ"),FnBiAjthS8MkXs67W(u"ࠫࡆ࡙ࡋࠨፒ")]: jHevARrF7lS.setSetting(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨፓ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ࡁࡔࡍࠪፔ"))
	if jHevARrF7lS.getSetting(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬፕ")) not in [dshJSmRqeiP9nap2(u"ࠨࡃࡘࡘࡔ࠭ፖ"),dshJSmRqeiP9nap2(u"ࠩࡖࡘࡔࡖࠧፗ"),kEhAHvti6Vnsfx(u"ࠪࡅࡘࡑࠧፘ")]: jHevARrF7lS.setSetting(wRxoKs10Syj7V4edYhtP(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩፙ"),UTelCo0ihE1d5R(u"ࠬࡇࡓࡌࠩፚ"))
	return QQTDOLdNUAzYbfl1vXrM8mB
def tWBJhyRicnY0SrZmQApbg56a(vYFXP48WV6M,dR2vHyAtl8pJN1,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,OCa4ZAo2pviYzdfuVQx1J5bF,qDzNIhmbFvwp8arWP,hayXA4TiLlPxcVSIoK2,llhyFWpP90RSDQM,r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6):
	From8aTqdhCbPs(hBvsQ7oCkKUdwjx58ml3EN(u"࠭ศะลอࠤ฾๋ไ๋หࠣฮัอ่ำࠢส่าาศࠨ፛"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧࠨ፜"),MQbODJoPV2w8TEAg4zXZdjLxSW=FnBiAjthS8MkXs67W(u"࠷࠶࠲ᝌ"))
	LOHZ4o9m7p6ebfTYXGIdz5PWs3q(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ፝"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+p72fnFtcPix5UKwr9YNzW(u"ࠩࠣࠤࠥࠦࡔࡳࡻ࡬ࡲ࡬ࠦࡢࡺࡲࡤࡷࡸ࡯࡮ࡨࠢࡥࡰࡴࡩ࡫ࡪࡰࡪࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨ፞")+str(llhyFWpP90RSDQM)+hBvsQ7oCkKUdwjx58ml3EN(u"ࠪࠤࡢࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫ፟")+r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6+S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭፠")+hayXA4TiLlPxcVSIoK2+S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ፡")+dR2vHyAtl8pJN1+bUdr5Hahw6sY8xJ(u"࠭ࠠ࡞ࠩ።"))
	n5CSaXYjqowGTR2LBK6szEt = jHevARrF7lS.getSetting(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࡢࡸ࠱ࡪࡦ࡯࡬ࡦࡦ࠱ࡷࡨࡧࡲࡱࡧࡳࡶࡴࡾࡹ࠲ࠩ፣"))
	YidU8bDWrmhXBLwu = jHevARrF7lS.getSetting(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨࡣࡹ࠲࡫ࡧࡩ࡭ࡧࡧ࠲ࡸࡩࡡࡳࡲࡨࡴࡷࡵࡸࡺ࠴ࠪ፤"))
	tmwSjEdsMkWOAH6aQFy1XiLR7rln = jHevARrF7lS.getSetting(hBvsQ7oCkKUdwjx58ml3EN(u"ࠩࡤࡺ࠳࡬ࡡࡪ࡮ࡨࡨ࠳ࡹࡣࡢࡴࡳࡩࡵࡸ࡯ࡹࡻ࠶ࠫ፥"))
	RXbY9Okr8AUu5JlIasDe1c = jHevARrF7lS.getSetting(Cu1704YofAbr3QTm(u"ࠪࡥࡻ࠴ࡦࡢ࡫࡯ࡩࡩ࠴ࡳࡤࡣࡵࡴࡪࡶࡲࡰࡺࡼ࠸ࠬ፦"))
	n5CSaXYjqowGTR2LBK6szEt = UTelCo0ihE1d5R(u"࠱ᝍ") if not n5CSaXYjqowGTR2LBK6szEt else int(n5CSaXYjqowGTR2LBK6szEt)
	YidU8bDWrmhXBLwu = XzrqbGDIy54juixkMA(u"࠲ᝎ") if not YidU8bDWrmhXBLwu else int(YidU8bDWrmhXBLwu)
	tmwSjEdsMkWOAH6aQFy1XiLR7rln = fprnld4CZo(u"࠳ᝏ") if not tmwSjEdsMkWOAH6aQFy1XiLR7rln else int(tmwSjEdsMkWOAH6aQFy1XiLR7rln)
	RXbY9Okr8AUu5JlIasDe1c = SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠴ᝐ") if not RXbY9Okr8AUu5JlIasDe1c else int(RXbY9Okr8AUu5JlIasDe1c)
	WQ17x4kDr8wIJqiFbTZNv = n5CSaXYjqowGTR2LBK6szEt>LiRcTVUWuth70DmPy(u"࠸ᝑ") and YidU8bDWrmhXBLwu>LiRcTVUWuth70DmPy(u"࠸ᝑ") and tmwSjEdsMkWOAH6aQFy1XiLR7rln>LiRcTVUWuth70DmPy(u"࠸ᝑ") and RXbY9Okr8AUu5JlIasDe1c>LiRcTVUWuth70DmPy(u"࠸ᝑ")
	if WQ17x4kDr8wIJqiFbTZNv:
		jHevARrF7lS.setSetting(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࡦࡼ࠮ࡧࡣ࡬ࡰࡪࡪ࠮ࡴࡥࡤࡶࡵ࡫ࡰࡳࡱࡻࡽ࠶࠭፧"),bUdr5Hahw6sY8xJ(u"ࠬ࠭፨"))
		jHevARrF7lS.setSetting(lc0dpSmwoPDjLnk(u"࠭ࡡࡷ࠰ࡩࡥ࡮ࡲࡥࡥ࠰ࡶࡧࡦࡸࡰࡦࡲࡵࡳࡽࡿ࠲ࠨ፩"),FvNyZqaLKw(u"ࠧࠨ፪"))
		jHevARrF7lS.setSetting(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠨࡣࡹ࠲࡫ࡧࡩ࡭ࡧࡧ࠲ࡸࡩࡡࡳࡲࡨࡴࡷࡵࡸࡺ࠵ࠪ፫"),iRoLg2m47tnDATBHGCSPNyx(u"ࠩࠪ፬"))
		jHevARrF7lS.setSetting(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠪࡥࡻ࠴ࡦࡢ࡫࡯ࡩࡩ࠴ࡳࡤࡣࡵࡴࡪࡶࡲࡰࡺࡼ࠸ࠬ፭"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࠬ፮"))
	zzmbGvSFqHQZaKwNDRx9gi7Pdh = []
	if WQ17x4kDr8wIJqiFbTZNv or n5CSaXYjqowGTR2LBK6szEt<=oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠳ᝓ"): zzmbGvSFqHQZaKwNDRx9gi7Pdh += [XzrqbGDIy54juixkMA(u"࠷ᝒ"),XzrqbGDIy54juixkMA(u"࠷ᝒ"),XzrqbGDIy54juixkMA(u"࠷ᝒ"),XzrqbGDIy54juixkMA(u"࠷ᝒ")]
	if WQ17x4kDr8wIJqiFbTZNv or YidU8bDWrmhXBLwu<=SO94xq1RAkMm2uF(u"࠴᝔"): zzmbGvSFqHQZaKwNDRx9gi7Pdh += [SO94xq1RAkMm2uF(u"࠴᝕"),SO94xq1RAkMm2uF(u"࠴᝕")]
	if WQ17x4kDr8wIJqiFbTZNv or tmwSjEdsMkWOAH6aQFy1XiLR7rln<=QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠶᝖"): zzmbGvSFqHQZaKwNDRx9gi7Pdh += [QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠶᝖")]
	if not BBYvCiQGe8RdpyAagfS72mZclxb5 and (WQ17x4kDr8wIJqiFbTZNv or RXbY9Okr8AUu5JlIasDe1c<=zqdvcbP5L8BHh(u"࠷᝗")): zzmbGvSFqHQZaKwNDRx9gi7Pdh += [dshJSmRqeiP9nap2(u"࠹᝘"),dshJSmRqeiP9nap2(u"࠹᝘"),dshJSmRqeiP9nap2(u"࠹᝘"),dshJSmRqeiP9nap2(u"࠹᝘"),dshJSmRqeiP9nap2(u"࠹᝘"),dshJSmRqeiP9nap2(u"࠹᝘"),dshJSmRqeiP9nap2(u"࠹᝘"),dshJSmRqeiP9nap2(u"࠹᝘")]
	if G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ፯") in hayXA4TiLlPxcVSIoK2: nRHa7g81TmVtC4NucE9y = kEhAHvti6Vnsfx(u"࠺᝙")
	elif pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨ፰") in hayXA4TiLlPxcVSIoK2: nRHa7g81TmVtC4NucE9y = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠲᝚")
	elif QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧࡘࡇࡆࡍࡒࡇࠧ፱") in hayXA4TiLlPxcVSIoK2: nRHa7g81TmVtC4NucE9y = fprnld4CZo(u"࠶᝛")
	elif zzmbGvSFqHQZaKwNDRx9gi7Pdh:
		nRHa7g81TmVtC4NucE9y = Y7pXj2OtNq9GZdvmcTkS3hMJn.sample(zzmbGvSFqHQZaKwNDRx9gi7Pdh,zqdvcbP5L8BHh(u"࠳᝜"))[iUeoLOsbHqP(u"࠳᝝")]
	else: nRHa7g81TmVtC4NucE9y = -iRoLg2m47tnDATBHGCSPNyx(u"࠵᝞")
	if nRHa7g81TmVtC4NucE9y==yA5z6LIXBlo41PRVMY87wOisFp(u"࠶᝟"):
		scraperserver = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹ࠭፲")
		YRDbQ3nUPza5vHM0hX = FnBiAjthS8MkXs67W(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡧࡷࡧࡰࡪࡰࡪࡥࡳࡺࠦࡱࡴࡲࡼࡾࡥࡣࡰࡷࡱࡸࡷࡿ࠽ࡂࡇࠩࡦࡷࡵࡷࡴࡧࡵࡁ࡫ࡧ࡬ࡴࡧࠩࡪࡴࡸࡷࡢࡴࡧࡣ࡭࡫ࡡࡥࡧࡵࡷࡂࡺࡲࡶࡧ࠽࠶ࡧ࠹࠴࠱ࡣ࠹࠼࠾࠶ࡡ࠶࠶࠳࠵ࡩࡨࡣ࠴࠹࠵ࡧ࠶࠷࠴࠶ࡦ࠼࠺࠷࡫࠸ࡁࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡯࡮ࡨࡣࡱࡸ࠳ࡩ࡯࡮࠼࠻࠴࠽࠶ࠧ፳")
		gmFNXM58sV6qH = dR2vHyAtl8pJN1+hBvsQ7oCkKUdwjx58ml3EN(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪ፴")+YRDbQ3nUPza5vHM0hX+oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫ፵")
		CjElJZembnS3q = mIZr8L4njqgR(vYFXP48WV6M,gmFNXM58sV6qH,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,OCa4ZAo2pviYzdfuVQx1J5bF,qDzNIhmbFvwp8arWP,hayXA4TiLlPxcVSIoK2,dshJSmRqeiP9nap2(u"ࡌࡡ࡭ࡵࡨ᠏"),dshJSmRqeiP9nap2(u"ࡌࡡ࡭ࡵࡨ᠏"))
		CIeaqB5lX3byA9d7NRQm1t = Me28A1sBLNIgUp5YCDyvT(u"ࠬ࠭፶") if CjElJZembnS3q.succeeded else str(n5CSaXYjqowGTR2LBK6szEt+Me28A1sBLNIgUp5YCDyvT(u"࠷ᝠ"))
		jHevARrF7lS.setSetting(E6MIKdpBomef(u"࠭ࡡࡷ࠰ࡩࡥ࡮ࡲࡥࡥ࠰ࡶࡧࡦࡸࡰࡦࡲࡵࡳࡽࡿ࠱ࠨ፷"),CIeaqB5lX3byA9d7NRQm1t)
	elif nRHa7g81TmVtC4NucE9y==UTelCo0ihE1d5R(u"࠲ᝡ"):
		scraperserver = zqdvcbP5L8BHh(u"ࠧࡴࡥࡵࡥࡵ࡫࡯ࡱࡵࠪ፸")
		YRDbQ3nUPza5vHM0hX = S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡦࡶࡦࡶࡥࡰࡲࡶ࠲ࡰ࡫ࡥࡱࡡ࡫ࡩࡦࡪࡥࡳࡵࡀࡸࡷࡻࡥ࠻ࡤ࠵ࡧ࠷࡬ࡣ࠶࠻࠰࠼࡫ࡪ࠰࠮࠶ࡦ࠶ࡩ࠳࠹࠲࠸ࡦ࠱ࡧࡩ࠷࠴࠹࠼࠼࠵ࡩࡥ࠳ࡣࡃࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡦࡱࡳࡷ࠳࡯࡯࠻࠷࠶࠹࠸࠭፹")
		gmFNXM58sV6qH = dR2vHyAtl8pJN1+xW2Arao7YVOemw(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩ፺")+YRDbQ3nUPza5vHM0hX+lc0dpSmwoPDjLnk(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪ፻")
		CjElJZembnS3q = mIZr8L4njqgR(vYFXP48WV6M,gmFNXM58sV6qH,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,OCa4ZAo2pviYzdfuVQx1J5bF,qDzNIhmbFvwp8arWP,hayXA4TiLlPxcVSIoK2,FvNyZqaLKw(u"ࡆࡢ࡮ࡶࡩ᠐"),FvNyZqaLKw(u"ࡆࡢ࡮ࡶࡩ᠐"))
		CIeaqB5lX3byA9d7NRQm1t = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫࠬ፼") if CjElJZembnS3q.succeeded else str(YidU8bDWrmhXBLwu+S4SOKF2QbBhjCd3RrVMuHIzE(u"࠲ᝢ"))
		jHevARrF7lS.setSetting(xW2Arao7YVOemw(u"ࠬࡧࡶ࠯ࡨࡤ࡭ࡱ࡫ࡤ࠯ࡵࡦࡥࡷࡶࡥࡱࡴࡲࡼࡾ࠸ࠧ፽"),CIeaqB5lX3byA9d7NRQm1t)
	elif nRHa7g81TmVtC4NucE9y==l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠵ᝣ"):
		scraperserver = p72fnFtcPix5UKwr9YNzW(u"࠭ࡳࡤࡴࡤࡴࡪࡸࡡࡱ࡫ࠪ፾")
		YRDbQ3nUPza5vHM0hX = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡥࡵࡥࡵ࡫ࡲࡢࡲ࡬࠲ࡰ࡫ࡥࡱࡡ࡫ࡩࡦࡪࡥࡳࡵࡀࡸࡷࡻࡥ࠻࠹࠹ࡦ࠹࡬ࡣ࠴࠶ࡩࡧࡩ࠷࠹ࡥ࠻ࡦ࠹࠺ࡧ࠱࠶ࡨ࠶࠺࠵࠺ࡣࡥ࠻࠴࠸ࡨࡆࡰࡳࡱࡻࡽ࠲ࡹࡥࡳࡸࡨࡶ࠳ࡹࡣࡳࡣࡳࡩࡷࡧࡰࡪ࠰ࡦࡳࡲࡀ࠸࠱࠲࠴ࠫ፿")
		gmFNXM58sV6qH = dR2vHyAtl8pJN1+E6MIKdpBomef(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨᎀ")+YRDbQ3nUPza5vHM0hX+SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩᎁ")
		CjElJZembnS3q = mIZr8L4njqgR(vYFXP48WV6M,gmFNXM58sV6qH,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,OCa4ZAo2pviYzdfuVQx1J5bF,qDzNIhmbFvwp8arWP,hayXA4TiLlPxcVSIoK2,fprnld4CZo(u"ࡇࡣ࡯ࡷࡪ᠑"),fprnld4CZo(u"ࡇࡣ࡯ࡷࡪ᠑"))
		CIeaqB5lX3byA9d7NRQm1t = SO94xq1RAkMm2uF(u"ࠪࠫᎂ") if CjElJZembnS3q.succeeded else str(tmwSjEdsMkWOAH6aQFy1XiLR7rln+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠴ᝤ"))
		jHevARrF7lS.setSetting(dshJSmRqeiP9nap2(u"ࠫࡦࡼ࠮ࡧࡣ࡬ࡰࡪࡪ࠮ࡴࡥࡤࡶࡵ࡫ࡰࡳࡱࡻࡽ࠸࠭ᎃ"),CIeaqB5lX3byA9d7NRQm1t)
	elif nRHa7g81TmVtC4NucE9y==XzrqbGDIy54juixkMA(u"࠸ᝥ"):
		scraperserver = xW2Arao7YVOemw(u"ࠬࡹࡣࡳࡣࡳࡩࡺࡶࠧᎄ")
		XwyU6PQgprMI0 = dR2vHyAtl8pJN1.replace(wRxoKs10Syj7V4edYhtP(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࠨᎅ"),bUdr5Hahw6sY8xJ(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨᎆ"))
		gmFNXM58sV6qH = UTelCo0ihE1d5R(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡣࡳ࡭࠳ࡹࡣࡳࡣࡳࡩࡺࡶ࠮ࡤࡱࡰ࠳ࡄࡧࡰࡪࡡ࡮ࡩࡾࡃ࠱ࡗࡐࡶࡑࡹࡒ࠱ࡰࡄࡕ࡜ࡰ࡙ࡎࡄࡤࡆࡑࡏ࠷ࡋ࡙࡛ࡍ࡮࡯࠶ࡤ࡫࡜ࡺࠪࡰ࡫ࡥࡱࡡ࡫ࡩࡦࡪࡥࡳࡵࡀࡪࡦࡲࡳࡦࠨࡸࡶࡱࡃࠧᎇ")+XwyU6PQgprMI0
		CjElJZembnS3q = mIZr8L4njqgR(FnBiAjthS8MkXs67W(u"ࠩࡊࡉ࡙࠭ᎈ"),gmFNXM58sV6qH,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,OCa4ZAo2pviYzdfuVQx1J5bF,qDzNIhmbFvwp8arWP,hayXA4TiLlPxcVSIoK2,wRxoKs10Syj7V4edYhtP(u"ࡈࡤࡰࡸ࡫᠒"),wRxoKs10Syj7V4edYhtP(u"ࡈࡤࡰࡸ࡫᠒"))
		CIeaqB5lX3byA9d7NRQm1t = S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠪࠫᎉ") if CjElJZembnS3q.succeeded else str(RXbY9Okr8AUu5JlIasDe1c+yA5z6LIXBlo41PRVMY87wOisFp(u"࠶ᝦ"))
		jHevARrF7lS.setSetting(zqdvcbP5L8BHh(u"ࠫࡦࡼ࠮ࡧࡣ࡬ࡰࡪࡪ࠮ࡴࡥࡤࡶࡵ࡫ࡰࡳࡱࡻࡽ࠹࠭ᎊ"),CIeaqB5lX3byA9d7NRQm1t)
	elif nRHa7g81TmVtC4NucE9y==p72fnFtcPix5UKwr9YNzW(u"࠻ᝧ"):
		scraperserver = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡲࡰࡤࡲࡸࠬᎋ")
		gmFNXM58sV6qH = dshJSmRqeiP9nap2(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡡࡱ࡫࠱ࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡷࡵࡢࡰࡶ࠱ࡧࡴࡳ࠯ࡀࡶࡲ࡯ࡪࡴ࠽ࡢ࠶ࡩ࠻࡫ࡨ࠱࠵࠯࠵ࡨࡪ࡬࠭࠵࠲࠺࠵࠲࠾࠶࠵ࡤ࠰࠶࠷࡫࠳࠳࠸࠷ࡨ࠹ࡪࡤࡤࠨࡳࡶࡴࡾࡹࡄࡱࡸࡲࡹࡸࡹ࠾ࡌࡒࠪࡺࡸ࡬࠾ࠩᎌ")+mGfdCk4Hyclg9RjD(dR2vHyAtl8pJN1)
		CjElJZembnS3q = mIZr8L4njqgR(hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࡈࡇࡗࠫᎍ"),gmFNXM58sV6qH,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,OCa4ZAo2pviYzdfuVQx1J5bF,qDzNIhmbFvwp8arWP,hayXA4TiLlPxcVSIoK2,XzrqbGDIy54juixkMA(u"ࡉࡥࡱࡹࡥ᠓"),XzrqbGDIy54juixkMA(u"ࡉࡥࡱࡹࡥ᠓"))
		try:
			import json as IsRfCubK4FeYlZgEcXn6U5PNa0
			CjElJZembnS3q.content = IsRfCubK4FeYlZgEcXn6U5PNa0.dumps(CjElJZembnS3q.content)[UTelCo0ihE1d5R(u"ࠨࡴࡨࡷࡺࡲࡴࠨᎎ")]
		except: pass
	elif nRHa7g81TmVtC4NucE9y==hBvsQ7oCkKUdwjx58ml3EN(u"࠴࠲ᝨ"):
		scraperserver = iRoLg2m47tnDATBHGCSPNyx(u"ࠩࡶࡧࡷࡧࡰࡦ࠰ࡧࡳ࠶࠭ᎏ")
		YRDbQ3nUPza5vHM0hX = zqdvcbP5L8BHh(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡧࡨ࠸࠶࠴ࡣࡥ࠵ࡪ࠻࠰࠵࠶ࡧ࠶ࡨࡧ࠵ࡥ࠷ࡧ࠷࡫࠿ࡥ࠴ࡥ࠶࠼࠻࡫ࡣࡢ࠳࠴࠴࠽࠹࠸࠺ࡣ࠺࠷࠿ࡩࡵࡴࡶࡲࡱࡍ࡫ࡡࡥࡧࡵࡷࡂࡺࡲࡶࡧࡃࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡦ࠰ࡧࡳ࠿࠾࠰࠹࠲ࠪ᎐")
		gmFNXM58sV6qH = dR2vHyAtl8pJN1+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫ᎑")+YRDbQ3nUPza5vHM0hX+g4g6bfkPtVGU5lIM3(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬ᎒")
		CjElJZembnS3q = mIZr8L4njqgR(vYFXP48WV6M,gmFNXM58sV6qH,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,OCa4ZAo2pviYzdfuVQx1J5bF,qDzNIhmbFvwp8arWP,hayXA4TiLlPxcVSIoK2,dshJSmRqeiP9nap2(u"ࡊࡦࡲࡳࡦ᠔"),dshJSmRqeiP9nap2(u"ࡊࡦࡲࡳࡦ᠔"))
		if LiRcTVUWuth70DmPy(u"࠭ࡓࡤࡴࡤࡴࡪ࠴ࡤࡰ࠯ࡕࡩࡲࡧࡩ࡯࡫ࡱ࡫࠲ࡉࡲࡦࡦ࡬ࡸࡸ࠭᎓") in list(CjElJZembnS3q.headers.keys()):
			Mgo12kP8avCL = CjElJZembnS3q.headers[Cu1704YofAbr3QTm(u"ࠧࡔࡥࡵࡥࡵ࡫࠮ࡥࡱ࠰ࡖࡪࡳࡡࡪࡰ࡬ࡲ࡬࠳ࡃࡳࡧࡧ࡭ࡹࡹࠧ᎔")]
			jHevARrF7lS.setSetting(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱࡧࡧࡳ࠹࠺ࠧ᎕"),Mgo12kP8avCL)
	elif nRHa7g81TmVtC4NucE9y==FvNyZqaLKw(u"࠵࠴ᝩ"):
		scraperserver = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩࡶࡧࡷࡧࡰࡦ࠰ࡧࡳ࠷࠭᎖")
		YRDbQ3nUPza5vHM0hX = S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵ࡨ࠹ࡤ࠴ࡣࡨ࠵࠽࠻ࡤࡧ࠶ࡥࡪ࠻ࡧࡦ࠶࠵࠶ࡧ࠼࠶࠴࠱ࡤ࠶࠸࠼ࡩ࠹ࡦ࠻࠼ࡦࡪ࠺࠶࠷ࡣࡨ࠽࠿ࡩࡵࡴࡶࡲࡱࡍ࡫ࡡࡥࡧࡵࡷࡂࡺࡲࡶࡧࡃࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡦ࠰ࡧࡳ࠿࠾࠰࠹࠲ࠪ᎗")
		gmFNXM58sV6qH = dR2vHyAtl8pJN1+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫ᎘")+YRDbQ3nUPza5vHM0hX+g4g6bfkPtVGU5lIM3(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬ᎙")
		CjElJZembnS3q = mIZr8L4njqgR(vYFXP48WV6M,gmFNXM58sV6qH,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,OCa4ZAo2pviYzdfuVQx1J5bF,qDzNIhmbFvwp8arWP,hayXA4TiLlPxcVSIoK2,lc0dpSmwoPDjLnk(u"ࡋࡧ࡬ࡴࡧ᠕"),lc0dpSmwoPDjLnk(u"ࡋࡧ࡬ࡴࡧ᠕"))
		if oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠭ࡓࡤࡴࡤࡴࡪ࠴ࡤࡰ࠯ࡕࡩࡲࡧࡩ࡯࡫ࡱ࡫࠲ࡉࡲࡦࡦ࡬ࡸࡸ࠭᎚") in list(CjElJZembnS3q.headers.keys()):
			Mgo12kP8avCL = CjElJZembnS3q.headers[xW2Arao7YVOemw(u"ࠧࡔࡥࡵࡥࡵ࡫࠮ࡥࡱ࠰ࡖࡪࡳࡡࡪࡰ࡬ࡲ࡬࠳ࡃࡳࡧࡧ࡭ࡹࡹࠧ᎛")]
			jHevARrF7lS.setSetting(XzrqbGDIy54juixkMA(u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱࡧࡧࡳ࠺࠻ࠧ᎜"),Mgo12kP8avCL)
	elif nRHa7g81TmVtC4NucE9y==QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠸࠴ᝪ"):
		scraperserver = QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࡶࡧࡷࡧࡰࡦࡱࡳࡷࠬ᎝")
		gmFNXM58sV6qH = bUdr5Hahw6sY8xJ(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱࡧࡲࡴࡸ࠴ࡩࡰ࠱ࡹ࠵࠴ࡅࡡࡱ࡫ࡢ࡯ࡪࡿ࠽ࡣ࠴ࡦ࠶࡫ࡩ࠵࠺࠯࠻ࡪࡩ࠶࠭࠵ࡥ࠵ࡨ࠲࠿࠱࠷ࡥ࠰ࡦࡨ࠽࠳࠸࠻࠻࠴ࡨ࡫࠲ࡢࠨࡸࡶࡱࡃࠧ᎞")+dR2vHyAtl8pJN1
		CjElJZembnS3q = mIZr8L4njqgR(UTelCo0ihE1d5R(u"ࠫࡌࡋࡔࠨ᎟"),gmFNXM58sV6qH,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,OCa4ZAo2pviYzdfuVQx1J5bF,qDzNIhmbFvwp8arWP,hayXA4TiLlPxcVSIoK2,SO94xq1RAkMm2uF(u"ࡌࡡ࡭ࡵࡨ᠖"),SO94xq1RAkMm2uF(u"ࡌࡡ࡭ࡵࡨ᠖"))
	else:
		scraperserver,gmFNXM58sV6qH = lc0dpSmwoPDjLnk(u"ࠬ࠭Ꭰ"),dshJSmRqeiP9nap2(u"࠭ࠧᎡ")
		CjElJZembnS3q = dMPXkHuB87WsyEUNGQ6IeY()
	CjElJZembnS3q.scrapernumber = str(nRHa7g81TmVtC4NucE9y)
	CjElJZembnS3q.scraperserver = scraperserver
	CjElJZembnS3q.scraperurl = gmFNXM58sV6qH
	j4FSA1inMdlWgDY2aEZR3b7THLc = fprnld4CZo(u"ࠧิ์ิๅึࠦัใ็ࠣࠫᎢ")+CjElJZembnS3q.scrapernumber
	if CjElJZembnS3q.succeeded:
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧᎣ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩࠣࠤࠥࠦࡓࡶࡥࡦࡩࡪࡪࡥࡥࠢࡥࡽࡵࡧࡳࡴ࡫ࡱ࡫ࠥࡨ࡬ࡰࡥ࡮࡭ࡳ࡭ࠠࠡࠢࡖࡩࡷࡼࡥࡳ࠼ࠣ࡟ࠥ࠭Ꭴ")+scraperserver+SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᎥ")+hayXA4TiLlPxcVSIoK2+LiRcTVUWuth70DmPy(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᎦ")+dR2vHyAtl8pJN1+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠬࠦ࡝ࠨᎧ"))
		From8aTqdhCbPs(S4SOKF2QbBhjCd3RrVMuHIzE(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣฮัอ่ำࠢส่าาศࠨᎨ"),j4FSA1inMdlWgDY2aEZR3b7THLc,MQbODJoPV2w8TEAg4zXZdjLxSW=SO94xq1RAkMm2uF(u"࠺࠹࠵ᝫ"))
	else:
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭Ꭹ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+LiRcTVUWuth70DmPy(u"ࠨࠢࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥࡨࡹࡱࡣࡶࡷ࡮ࡴࡧࠡࡤ࡯ࡳࡨࡱࡩ࡯ࡩࠣࠤ࡙ࠥࡥࡳࡸࡨࡶ࠿࡛ࠦࠡࠩᎪ")+scraperserver+Cu1704YofAbr3QTm(u"ࠩࠣࡡࠥࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩᎫ")+str(CjElJZembnS3q.code)+iRoLg2m47tnDATBHGCSPNyx(u"ࠪࠤࡢࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫᎬ")+CjElJZembnS3q.reason+hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭Ꭽ")+hayXA4TiLlPxcVSIoK2+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᎮ")+dR2vHyAtl8pJN1+SO94xq1RAkMm2uF(u"࠭ࠠ࡞ࠩᎯ"))
		From8aTqdhCbPs(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠧโึ็ฮࠥ฿ๅๅ์ฬࠤฯาว้ิࠣห้ำฬษࠩᎰ"),j4FSA1inMdlWgDY2aEZR3b7THLc,MQbODJoPV2w8TEAg4zXZdjLxSW=p72fnFtcPix5UKwr9YNzW(u"࠻࠺࠶ᝬ"))
	return CjElJZembnS3q
def bxUSPZNcXgLKGuFlenmkh2OCd6oa(cUsgVlb0iuBaW7OjSw4oCPL,vYFXP48WV6M,mHejXxkvM1qCESPVRy54QB,rKagANTOtGJnhVWfE2BHpePYC3IQ5l,ep9JAOkj1wr5s,hXWtlI25BjAiN6ESe1ka79dc8PsGD,showDialogs,hayXA4TiLlPxcVSIoK2,GPBaUzVhdpyO6xkJD2=E6MIKdpBomef(u"ࠨࠩᎱ"),t8x23UOsYmr9IDik06pG=XzrqbGDIy54juixkMA(u"ࠩࠪᎲ")):
	dR2vHyAtl8pJN1,yaeqrwZ9BhV7N1,N3aW1fHjZrXkGdCVmzMolTvqpI,bbCy3Uxd48jVeNmT1c = GUnATzyQjq(mHejXxkvM1qCESPVRy54QB)
	try: xxQlhIb84KzdymRgr9SGJ6VMnAsq = ep9JAOkj1wr5s.copy()
	except: xxQlhIb84KzdymRgr9SGJ6VMnAsq = ep9JAOkj1wr5s
	fPpK27Cej9wqutr0 = vYFXP48WV6M,dR2vHyAtl8pJN1,rKagANTOtGJnhVWfE2BHpePYC3IQ5l,xxQlhIb84KzdymRgr9SGJ6VMnAsq,hXWtlI25BjAiN6ESe1ka79dc8PsGD
	if cUsgVlb0iuBaW7OjSw4oCPL:
		YutQm2AwozR9VKp4O1lWj8FaryI = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,wRxoKs10Syj7V4edYhtP(u"ࠪࡶࡪࡹࡰࡰࡰࡶࡩࠬᎳ"),Me28A1sBLNIgUp5YCDyvT(u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙ࠧᎴ"),fPpK27Cej9wqutr0)
		if YutQm2AwozR9VKp4O1lWj8FaryI.succeeded:
			XXmSpTHNao6Gxbs0eK5(iUeoLOsbHqP(u"ࠬࡘࡅࡒࡗࡈࡗ࡙࡙ࠠࠡࡔࡈࡅࡉࡥࡃࡂࡅࡋࡉࠬᎵ"),dR2vHyAtl8pJN1,rKagANTOtGJnhVWfE2BHpePYC3IQ5l,ep9JAOkj1wr5s,hayXA4TiLlPxcVSIoK2,vYFXP48WV6M)
			return YutQm2AwozR9VKp4O1lWj8FaryI
	YutQm2AwozR9VKp4O1lWj8FaryI = mIZr8L4njqgR(vYFXP48WV6M,mHejXxkvM1qCESPVRy54QB,rKagANTOtGJnhVWfE2BHpePYC3IQ5l,ep9JAOkj1wr5s,hXWtlI25BjAiN6ESe1ka79dc8PsGD,showDialogs,hayXA4TiLlPxcVSIoK2,GPBaUzVhdpyO6xkJD2,t8x23UOsYmr9IDik06pG)
	if YutQm2AwozR9VKp4O1lWj8FaryI.succeeded:
		if xW2Arao7YVOemw(u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧᎶ") in hayXA4TiLlPxcVSIoK2: YutQm2AwozR9VKp4O1lWj8FaryI.content = Us3m2wZCVWHruY(YutQm2AwozR9VKp4O1lWj8FaryI.content)
		if YutQm2AwozR9VKp4O1lWj8FaryI.scrape: cUsgVlb0iuBaW7OjSw4oCPL = ZcdnQAJ3ltkoiPsyX5
		if cUsgVlb0iuBaW7OjSw4oCPL: Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠪᎷ"),fPpK27Cej9wqutr0,YutQm2AwozR9VKp4O1lWj8FaryI,cUsgVlb0iuBaW7OjSw4oCPL)
	return YutQm2AwozR9VKp4O1lWj8FaryI
def KkRZyvC312V5(cUsgVlb0iuBaW7OjSw4oCPL,mHejXxkvM1qCESPVRy54QB,rKagANTOtGJnhVWfE2BHpePYC3IQ5l,ep9JAOkj1wr5s,showDialogs,hayXA4TiLlPxcVSIoK2):
	if not rKagANTOtGJnhVWfE2BHpePYC3IQ5l or isinstance(rKagANTOtGJnhVWfE2BHpePYC3IQ5l,dict): vYFXP48WV6M = lc0dpSmwoPDjLnk(u"ࠨࡉࡈࡘࠬᎸ")
	else:
		vYFXP48WV6M = LiRcTVUWuth70DmPy(u"ࠩࡓࡓࡘ࡚ࠧᎹ")
		rKagANTOtGJnhVWfE2BHpePYC3IQ5l = GhPlajzTxY8(rKagANTOtGJnhVWfE2BHpePYC3IQ5l)
		QrSCGKHoUyfZVtwqsxc,rKagANTOtGJnhVWfE2BHpePYC3IQ5l = xlk0nsAXjIrvOQFL4Vi1MJG5TChu(rKagANTOtGJnhVWfE2BHpePYC3IQ5l)
	YutQm2AwozR9VKp4O1lWj8FaryI = bxUSPZNcXgLKGuFlenmkh2OCd6oa(cUsgVlb0iuBaW7OjSw4oCPL,vYFXP48WV6M,mHejXxkvM1qCESPVRy54QB,rKagANTOtGJnhVWfE2BHpePYC3IQ5l,ep9JAOkj1wr5s,kEhAHvti6Vnsfx(u"ࡔࡳࡷࡨ᠗"),showDialogs,hayXA4TiLlPxcVSIoK2)
	U9rSWyc74gLOw = YutQm2AwozR9VKp4O1lWj8FaryI.content
	U9rSWyc74gLOw = str(U9rSWyc74gLOw)
	return U9rSWyc74gLOw
def GUnATzyQjq(mHejXxkvM1qCESPVRy54QB):
	LcDbX2xlR9O3Nuv0BC = mHejXxkvM1qCESPVRy54QB.split(FnBiAjthS8MkXs67W(u"ࠪࢀࢁ࠭Ꮊ"))
	dR2vHyAtl8pJN1,yaeqrwZ9BhV7N1,N3aW1fHjZrXkGdCVmzMolTvqpI,bbCy3Uxd48jVeNmT1c = LcDbX2xlR9O3Nuv0BC[dshJSmRqeiP9nap2(u"࠵᝭")],None,None,bUdr5Hahw6sY8xJ(u"ࡕࡴࡸࡩ᠘")
	for fPpK27Cej9wqutr0 in LcDbX2xlR9O3Nuv0BC:
		if hBvsQ7oCkKUdwjx58ml3EN(u"ࠫࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩᎻ") in fPpK27Cej9wqutr0: yaeqrwZ9BhV7N1 = fPpK27Cej9wqutr0[UTelCo0ihE1d5R(u"࠷࠱ᝮ"):]
		elif XzrqbGDIy54juixkMA(u"ࠬࡓࡹࡅࡐࡖ࡙ࡷࡲ࠽ࠨᎼ") in fPpK27Cej9wqutr0: N3aW1fHjZrXkGdCVmzMolTvqpI = fPpK27Cej9wqutr0[G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠹ᝯ"):]
		elif E6MIKdpBomef(u"࠭ࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫᎽ") in fPpK27Cej9wqutr0: bbCy3Uxd48jVeNmT1c = zqdvcbP5L8BHh(u"ࡈࡤࡰࡸ࡫᠙")
	return dR2vHyAtl8pJN1,yaeqrwZ9BhV7N1,N3aW1fHjZrXkGdCVmzMolTvqpI,bbCy3Uxd48jVeNmT1c
def dL4qOfSeD1Jghxw2uVC(cUsgVlb0iuBaW7OjSw4oCPL,vYFXP48WV6M,mHejXxkvM1qCESPVRy54QB,KKm2Jp3jgzklHRharZQPVtX6yGnO5,sHtdv9y1YUVjNQBlEiqrPp280JL4m,pPRq07zdQly6D15fjmOCSvZnB,ep9JAOkj1wr5s=p72fnFtcPix5UKwr9YNzW(u"ࠧࠨᎾ")):
	UR1xh2lzC9ywIpSGfJrXQnVYiZs4v = RfKuIXwPAiWtmyF(mHejXxkvM1qCESPVRy54QB,p72fnFtcPix5UKwr9YNzW(u"ࠨࡷࡵࡰࠬᎿ"))
	hpRtseuJbF3cZfvQ5LD4Bkl = jHevARrF7lS.getSetting(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫᏀ")+KKm2Jp3jgzklHRharZQPVtX6yGnO5)
	if UR1xh2lzC9ywIpSGfJrXQnVYiZs4v==hpRtseuJbF3cZfvQ5LD4Bkl: jHevARrF7lS.setSetting(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࠬᏁ")+KKm2Jp3jgzklHRharZQPVtX6yGnO5,FnBiAjthS8MkXs67W(u"ࠫࠬᏂ"))
	if hpRtseuJbF3cZfvQ5LD4Bkl: XwyU6PQgprMI0 = mHejXxkvM1qCESPVRy54QB.replace(UR1xh2lzC9ywIpSGfJrXQnVYiZs4v,hpRtseuJbF3cZfvQ5LD4Bkl)
	else:
		XwyU6PQgprMI0 = mHejXxkvM1qCESPVRy54QB
		hpRtseuJbF3cZfvQ5LD4Bkl = UR1xh2lzC9ywIpSGfJrXQnVYiZs4v
	ye2NJVIc5j8 = bxUSPZNcXgLKGuFlenmkh2OCd6oa(cUsgVlb0iuBaW7OjSw4oCPL,vYFXP48WV6M,XwyU6PQgprMI0,XzrqbGDIy54juixkMA(u"ࠬ࠭Ꮓ"),ep9JAOkj1wr5s,iUeoLOsbHqP(u"࠭ࠧᏄ"),LiRcTVUWuth70DmPy(u"ࠧࠨᏅ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠳ࡶࡸࠬᏆ"))
	U9rSWyc74gLOw = ye2NJVIc5j8.content
	if u4ChFMGf6K93tbDjJ12zi0YQsAHyP:
		try: U9rSWyc74gLOw = U9rSWyc74gLOw.decode(Cu1704YofAbr3QTm(u"ࠩࡸࡸ࡫࠾ࠧᏇ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪᏈ"))
		except: pass
	if not ye2NJVIc5j8.succeeded or pPRq07zdQly6D15fjmOCSvZnB not in U9rSWyc74gLOw:
		sHtdv9y1YUVjNQBlEiqrPp280JL4m = sHtdv9y1YUVjNQBlEiqrPp280JL4m.replace(iUeoLOsbHqP(u"ࠫࠥ࠭Ꮙ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠬ࠱ࠧᏊ"))
		dR2vHyAtl8pJN1 = kEhAHvti6Vnsfx(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠲ࡨࡵ࡭࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡀࠫᏋ")+sHtdv9y1YUVjNQBlEiqrPp280JL4m
		BBYvCiQGe8RdpyAagfS72mZclxb5 = {zqdvcbP5L8BHh(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᏌ"):QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠨࠩᏍ")}
		QQTDOLdNUAzYbfl1vXrM8mB = bxUSPZNcXgLKGuFlenmkh2OCd6oa(cUsgVlb0iuBaW7OjSw4oCPL,vYFXP48WV6M,dR2vHyAtl8pJN1,oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠩࠪᏎ"),BBYvCiQGe8RdpyAagfS72mZclxb5,yA5z6LIXBlo41PRVMY87wOisFp(u"ࠪࠫᏏ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࠬᏐ"),wRxoKs10Syj7V4edYhtP(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠸࡮ࡥࠩᏑ"))
		if QQTDOLdNUAzYbfl1vXrM8mB.succeeded:
			U9rSWyc74gLOw = QQTDOLdNUAzYbfl1vXrM8mB.content
			if u4ChFMGf6K93tbDjJ12zi0YQsAHyP:
				try: U9rSWyc74gLOw = U9rSWyc74gLOw.decode(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭ࡵࡵࡨ࠻ࠫᏒ"),iRoLg2m47tnDATBHGCSPNyx(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧᏓ"))
				except: pass
			gI487voLsArVqW6Ffp = GGvHJKP9LUxEk10Fw.findall(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠳ࡡࡽࠪ࡝ࡁ࠱࠮ࡄ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣࠩᏔ"),U9rSWyc74gLOw,GGvHJKP9LUxEk10Fw.DOTALL)
			stcJ9ku3E0abKCLF21wqyl6iAp = [hpRtseuJbF3cZfvQ5LD4Bkl]
			GeRXEdgFYPimH0 = [FvNyZqaLKw(u"ࠩࡤࡴࡰ࠭Ꮥ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪ࡫ࡴࡵࡧ࡭ࡧࠪᏖ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫࡹࡽࡩࡵࡶࡨࡶࠬᏗ"),E6MIKdpBomef(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭Ꮨ"),lc0dpSmwoPDjLnk(u"࠭ࡦࡢࡥࡨࡦࡴࡵ࡫ࠨᏙ"),kEhAHvti6Vnsfx(u"ࠧࡱࡪࡳࠫᏚ"),p72fnFtcPix5UKwr9YNzW(u"ࠨࡣࡷࡰࡦࡷࠧᏛ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࡶ࡭ࡹ࡫ࡩ࡯ࡦ࡬ࡧࡪࡹࠧᏜ"),wRxoKs10Syj7V4edYhtP(u"ࠪࡷࡺࡸ࠮࡭ࡻࠪᏝ"),bUdr5Hahw6sY8xJ(u"ࠫࡧࡲ࡯ࡨࡵࡳࡳࡹ࠭Ꮮ"),Cu1704YofAbr3QTm(u"ࠬ࡯࡮ࡧࡱࡵࡱࡪࡸࠧᏟ"),iUeoLOsbHqP(u"࠭ࡳࡪࡶࡨࡰ࡮ࡱࡥࠨᏠ"),dshJSmRqeiP9nap2(u"ࠧࡪࡰࡶࡸࡦ࡭ࡲࡢ࡯ࠪᏡ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠨࡵࡱࡥࡵࡩࡨࡢࡶࠪᏢ"),Me28A1sBLNIgUp5YCDyvT(u"ࠩ࡫ࡸࡹࡶ࠭ࡦࡳࡸ࡭ࡻ࠭Ꮳ"),dshJSmRqeiP9nap2(u"ࠪࡪࡦࡹࡥ࡭ࡲ࡯ࡹࡸ࠭Ꮴ")]
			for vjXKalCNU4sS0G5eZr76VdPwgBm in gI487voLsArVqW6Ffp:
				if any(hieW1zRUG5w9AykJjv0X in vjXKalCNU4sS0G5eZr76VdPwgBm for hieW1zRUG5w9AykJjv0X in GeRXEdgFYPimH0): continue
				hpRtseuJbF3cZfvQ5LD4Bkl = RfKuIXwPAiWtmyF(vjXKalCNU4sS0G5eZr76VdPwgBm,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠫࡺࡸ࡬ࠨᏥ"))
				if hpRtseuJbF3cZfvQ5LD4Bkl in stcJ9ku3E0abKCLF21wqyl6iAp: continue
				if len(stcJ9ku3E0abKCLF21wqyl6iAp)==iRoLg2m47tnDATBHGCSPNyx(u"࠺ᝰ"):
					LOHZ4o9m7p6ebfTYXGIdz5PWs3q(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪᏦ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+dshJSmRqeiP9nap2(u"࠭ࠠࠡࠢࡊࡳࡴ࡭࡬ࡦࠢࡧ࡭ࡩࠦ࡮ࡰࡶࠣࡪ࡮ࡴࡤࠡࡣࠣࡲࡪࡽࠠࡩࡱࡶࡸࡳࡧ࡭ࡦࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭Ꮷ")+KKm2Jp3jgzklHRharZQPVtX6yGnO5+FvNyZqaLKw(u"ࠧࠡ࡟ࠣࠤࡔࡲࡤ࠻ࠢ࡞ࠤࠬᏨ")+UR1xh2lzC9ywIpSGfJrXQnVYiZs4v+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠨࠢࡠࠫᏩ"))
					jHevARrF7lS.setSetting(SO94xq1RAkMm2uF(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫᏪ")+KKm2Jp3jgzklHRharZQPVtX6yGnO5,bUdr5Hahw6sY8xJ(u"ࠪࠫᏫ"))
					break
				stcJ9ku3E0abKCLF21wqyl6iAp.append(hpRtseuJbF3cZfvQ5LD4Bkl)
				XwyU6PQgprMI0 = mHejXxkvM1qCESPVRy54QB.replace(UR1xh2lzC9ywIpSGfJrXQnVYiZs4v,hpRtseuJbF3cZfvQ5LD4Bkl)
				ye2NJVIc5j8 = bxUSPZNcXgLKGuFlenmkh2OCd6oa(cUsgVlb0iuBaW7OjSw4oCPL,vYFXP48WV6M,XwyU6PQgprMI0,kEhAHvti6Vnsfx(u"ࠫࠬᏬ"),ep9JAOkj1wr5s,hBvsQ7oCkKUdwjx58ml3EN(u"ࠬ࠭Ꮽ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"࠭ࠧᏮ"),kEhAHvti6Vnsfx(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠴ࡴࡧࠫᏯ"))
				U9rSWyc74gLOw = ye2NJVIc5j8.content
				if ye2NJVIc5j8.succeeded and pPRq07zdQly6D15fjmOCSvZnB in U9rSWyc74gLOw:
					LOHZ4o9m7p6ebfTYXGIdz5PWs3q(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧᏰ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩࠣࠤࠥࡍ࡯ࡰࡩ࡯ࡩࠥ࡬࡯ࡶࡰࡧࠤࡦࠦ࡮ࡦࡹࠣ࡬ࡴࡹࡴ࡯ࡣࡰࡩࠥࠦࠠࡔ࡫ࡷࡩ࠿࡛ࠦࠡࠩᏱ")+KKm2Jp3jgzklHRharZQPVtX6yGnO5+wRxoKs10Syj7V4edYhtP(u"ࠪࠤࡢࠦࠠࠡࡐࡨࡻ࠿࡛ࠦࠡࠩᏲ")+hpRtseuJbF3cZfvQ5LD4Bkl+Cu1704YofAbr3QTm(u"ࠫࠥࡣࠠࠡࡑ࡯ࡨ࠿࡛ࠦࠡࠩᏳ")+UR1xh2lzC9ywIpSGfJrXQnVYiZs4v+bUdr5Hahw6sY8xJ(u"ࠬࠦ࡝ࠨᏴ"))
					jHevARrF7lS.setSetting(wRxoKs10Syj7V4edYhtP(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨᏵ")+KKm2Jp3jgzklHRharZQPVtX6yGnO5,hpRtseuJbF3cZfvQ5LD4Bkl)
					break
	return hpRtseuJbF3cZfvQ5LD4Bkl,XwyU6PQgprMI0,ye2NJVIc5j8
def wPGkbaD7x6(fH8bDPV6AceuCFNO0Ert7oq3p):
	D4ubdsmVyQOKMie2JtqRP = {
	 kEhAHvti6Vnsfx(u"ࠧࡰ࡮ࡧࠫ᏶")			:G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠨไา๎๊࠭᏷")
	,yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫᏸ")		:E6MIKdpBomef(u"้ࠪฯ๎โโࠩᏹ")
	,zqdvcbP5L8BHh(u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬᏺ")		:lc0dpSmwoPDjLnk(u"๋ࠬแใ๊าࠫᏻ")
	,LiRcTVUWuth70DmPy(u"࠭ࡧࡰࡱࡧࠫᏼ")			:S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠧอ์าࠫᏽ")
	,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ᏾")		:YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩไุ้࠭᏿")
	,hBvsQ7oCkKUdwjx58ml3EN(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᐀")		:Cu1704YofAbr3QTm(u"๊ࠫาไะࠩᐁ")
	,iUeoLOsbHqP(u"ࠬࡼࡩࡥࡧࡲࠫᐂ")		:SO94xq1RAkMm2uF(u"࠭แ๋ัํ์ࠬᐃ")
	,p72fnFtcPix5UKwr9YNzW(u"ࠧ࡭࡫ࡹࡩࠬᐄ")			:oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨไ้หฮ࠭ᐅ")
	,xW2Arao7YVOemw(u"ࠩࡤ࡬ࡼࡧ࡫ࠨᐆ")		:Cu1704YofAbr3QTm(u"้ࠪํู่ࠡล๊์ฬ้ࠠห์ไ๎ࠬᐇ")
	,SO94xq1RAkMm2uF(u"ࠫࡦࡱ࡯ࡢ࡯ࠪᐈ")		:kEhAHvti6Vnsfx(u"๋่ࠬใ฻ࠣว่๎วๆࠢส่็ี๊ๆࠩᐉ")
	,yA5z6LIXBlo41PRVMY87wOisFp(u"࠭ࡡ࡬ࡱࡤࡱࡨࡧ࡭ࠨᐊ")		:G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠧๆ๊ๅ฽ࠥษใ้ษ่ࠤ่อๅࠨᐋ")
	,G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠨࡣ࡮ࡻࡦࡳࠧᐌ")		:G5DeRbUpFj8E9OtJLvlo2fWmZC(u"่ࠩ์็฿ࠠฤๅ๋ห๊ࠦวๅฮา๎ิ࠭ᐍ")
	,sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࡥࡱࡧࡲࡢࡤࠪᐎ")		:XzrqbGDIy54juixkMA(u"๊ࠫ๎โฺࠢๆ่ࠥอไฺำหࠫᐏ")
	,iRoLg2m47tnDATBHGCSPNyx(u"ࠬࡧ࡬ࡧࡣࡷ࡭ࡲ࡯ࠧᐐ")		:SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ๅ้ไ฼ࠤฬ๊ๅ็สิࠤฬ๊แศู่๎ࠬᐑ")
	,xW2Arao7YVOemw(u"ࠧࡢ࡮࡮ࡥࡼࡺࡨࡢࡴࠪᐒ")	:p72fnFtcPix5UKwr9YNzW(u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤฬ๊ใ้อิࠫᐓ")
	,E6MIKdpBomef(u"ࠩࡤࡰࡲࡧࡡࡳࡧࡩࠫᐔ")		:wRxoKs10Syj7V4edYhtP(u"้ࠪํู่ࠡไ้หฮࠦวๅ็฼หึ็ࠧᐕ")
	,FvNyZqaLKw(u"ࠫࡦࡸࡡࡣ࡫ࡦࡸࡴࡵ࡮ࡴࠩᐖ")	:Cu1704YofAbr3QTm(u"๋่ࠬใ฻ࠣฮํ์าࠡ฻ิฬ๏ฯࠧᐗ")
	,S4SOKF2QbBhjCd3RrVMuHIzE(u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨᐘ")		:iRoLg2m47tnDATBHGCSPNyx(u"ࠧๆ๊ๅ฽ࠥ฿ัษࠢึ๎๏ีࠧᐙ")
	,hBvsQ7oCkKUdwjx58ml3EN(u"ࠨࡣࡵࡦࡱ࡯࡯࡯ࡼࠪᐚ")		:sTcr7iDp5eFt4RoLMhuwq1A(u"่ࠩ์็฿ฺࠠำหࠤ้๐่็ิࠪᐛ")
	,iRoLg2m47tnDATBHGCSPNyx(u"ࠪࡦࡴࡱࡲࡢࠩᐜ")		:bUdr5Hahw6sY8xJ(u"๊ࠫ๎โฺࠢห็ึอࠧᐝ")
	,Me28A1sBLNIgUp5YCDyvT(u"ࠬࡨࡲࡴࡶࡨ࡮ࠬᐞ")		:iRoLg2m47tnDATBHGCSPNyx(u"࠭ๅ้ไ฼ࠤอืำห์ฯࠫᐟ")
	,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࡤ࡫ࡰࡥ࠹࠶࠰ࠨᐠ")		:bUdr5Hahw6sY8xJ(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ࠹࠶࠰ࠨᐡ")
	,Me28A1sBLNIgUp5YCDyvT(u"ࠩࡦ࡭ࡲࡧ࠴ࡶࠩᐢ")		:SO94xq1RAkMm2uF(u"้ࠪํู่ࠡีํ้ฬࠦแ้ำํ์ࠬᐣ")
	,hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠫࡨ࡯࡭ࡢࡣࡥࡨࡴ࠭ᐤ")		:FnBiAjthS8MkXs67W(u"๋่ࠬใ฻ࠣื๏๋วࠡ฻หำํ࠭ᐥ")
	,sTcr7iDp5eFt4RoLMhuwq1A(u"࠭ࡣࡪ࡯ࡤࡧࡱࡻࡢࠨᐦ")		:FnBiAjthS8MkXs67W(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ็้๎ศࠨᐧ")
	,p72fnFtcPix5UKwr9YNzW(u"ࠨࡥ࡬ࡱࡦࡩ࡬ࡶࡤࡺࡳࡷࡱࠧᐨ")	:S4SOKF2QbBhjCd3RrVMuHIzE(u"่ࠩ์็฿ࠠิ์่ห้ࠥไ้สࠣ฽๊๊ࠧᐩ")
	,p72fnFtcPix5UKwr9YNzW(u"ࠪࡧ࡮ࡳࡡࡤ࡮ࡸࡴࠬᐪ")		:lc0dpSmwoPDjLnk(u"๊ࠫ๎โฺࠢึ๎๊อࠠไๆ๋ฬࠬᐫ")
	,FvNyZqaLKw(u"ࠬࡩࡩ࡮ࡣࡩࡥࡳࡹࠧᐬ")		:wRxoKs10Syj7V4edYhtP(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢไหุ๋ࠧᐭ")
	,yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧࡤ࡫ࡰࡥࡱ࡯ࡧࡩࡶࠪᐮ")	:oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ้อ๊หࠩᐯ")
	,fprnld4CZo(u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪᐰ")		:dshJSmRqeiP9nap2(u"้ࠪํู่ࠡีํ้ฬࠦๆศ๊ࠪᐱ")
	,FvNyZqaLKw(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩᐲ")			:fprnld4CZo(u"๋่ࠬใ฻ࠣำ๏๊๊ࠡ็ุ๋๋࠭ᐳ")
	,hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ᐴ")	:SO94xq1RAkMm2uF(u"ࠧๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠡไ้์ฬะࠧᐵ")
	,S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩᐶ"):kEhAHvti6Vnsfx(u"่ࠩ์็฿ࠠะ์็๎๋่ࠥี่ࠣๆํอฦๆࠩᐷ")
	,dshJSmRqeiP9nap2(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮ࡶࡲࡴ࡮ࡩࡳࠨᐸ")	:sTcr7iDp5eFt4RoLMhuwq1A(u"๊ࠫ๎โฺࠢา๎้๐ࠠๆ๊ื๊๋่ࠥศุํ฽ࠬᐹ")
	,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡺ࡮ࡪࡥࡰࡵࠪᐺ")	:Me28A1sBLNIgUp5YCDyvT(u"࠭ๅ้ไ฼ࠤิ๐ไ๋่ࠢ์ู์ࠠโ์า๎ํํวหࠩᐻ")
	,fprnld4CZo(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡲࡩࡷࡧࡶࠫᐼ")	:p72fnFtcPix5UKwr9YNzW(u"ࠨ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็่ࠢฬฬฺัࠨᐽ")
	,xW2Arao7YVOemw(u"ࠩࡧࡶࡦࡳࡡࡴ࠹ࠪᐾ")		:hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"้ࠪํู่ࠡัิห๊อࠠึฯࠪᐿ")
	,iRoLg2m47tnDATBHGCSPNyx(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬᑀ")		:yA5z6LIXBlo41PRVMY87wOisFp(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯ࠭ᑁ")
	,S4SOKF2QbBhjCd3RrVMuHIzE(u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠱ࠨᑂ")		:LiRcTVUWuth70DmPy(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠳ࠪᑃ")
	,Me28A1sBLNIgUp5YCDyvT(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠴ࠪᑄ")		:S4SOKF2QbBhjCd3RrVMuHIzE(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠶ࠬᑅ")
	,l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠷ࠬᑆ")		:xW2Arao7YVOemw(u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠹ࠧᑇ")
	,lc0dpSmwoPDjLnk(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠺ࠧᑈ")		:FnBiAjthS8MkXs67W(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠵ࠩᑉ")
	,zqdvcbP5L8BHh(u"ࠧࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠫᑊ")	:FvNyZqaLKw(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢࡹ࡭ࡵ࠭ᑋ")
	,hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩࡨ࡫ࡾࡪࡥࡢࡦࠪᑌ")		:G5DeRbUpFj8E9OtJLvlo2fWmZC(u"้ࠪํู่ࠡวํะ๏ࠦฯ๋ัࠪᑍ")
	,p72fnFtcPix5UKwr9YNzW(u"ࠫࡪ࡭ࡹ࡯ࡱࡺࠫᑎ")		:fprnld4CZo(u"๋่ࠬใ฻ࠣษ๏า๊่ࠡส์ࠬᑏ")
	,lc0dpSmwoPDjLnk(u"࠭ࡥ࡭ࡥ࡬ࡲࡪࡳࡡࠨᑐ")		:Me28A1sBLNIgUp5YCDyvT(u"ࠧๆ๊ๅ฽ࠥอไิ์้้ฬ࠭ᑑ")
	,l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨࡨࡤࡦࡷࡧ࡫ࡢࠩᑒ")		:FnBiAjthS8MkXs67W(u"่ࠩ์็฿ࠠโสิ็ฮ࠭ᑓ")
	,fprnld4CZo(u"ࠪࡪࡦࡰࡥࡳࡵ࡫ࡳࡼ࠭ᑔ")	:UTelCo0ihE1d5R(u"๊ࠫ๎โฺࠢไะึࠦิ้ࠩᑕ")
	,zqdvcbP5L8BHh(u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠷ࠧᑖ")		:G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠭ๅ้ไ฼ࠤๆอีๅࠢส่ศ๎ไࠨᑗ")
	,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧࡧࡣࡶࡩࡱ࡮ࡤ࠳ࠩᑘ")		:G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠨ็๋ๆ฾ࠦแศื็ࠤฬ๊หศ่ํࠫᑙ")
	,Cu1704YofAbr3QTm(u"ࠩࡩࡳࡸࡺࡡࠨᑚ")		:fprnld4CZo(u"้ࠪํู่ࠡใ๋ืฯอࠧᑛ")
	,l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫ࡭ࡧ࡬ࡢࡥ࡬ࡱࡦ࠭ᑜ")		:yA5z6LIXBlo41PRVMY87wOisFp(u"๋่ࠬใ฻๋้ࠣอࠠิ์่หࠬᑝ")
	,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ࡨࡦ࡮ࡤࡰࠬᑞ")		:fprnld4CZo(u"ࠧๆ๊ๅ฽ࠥํไศๆࠣ๎ํะ๊้สࠪᑟ")
	,XzrqbGDIy54juixkMA(u"ࠨ࡫ࡩ࡭ࡱࡳࠧᑠ")				:G5DeRbUpFj8E9OtJLvlo2fWmZC(u"่ࠩ์็฿ࠠใ่สอࠥศ๊ࠡใํ่๊࠭ᑡ")
	,p72fnFtcPix5UKwr9YNzW(u"ࠪ࡭࡫࡯࡬࡮࠯ࡤࡶࡦࡨࡩࡤࠩᑢ")			:SO94xq1RAkMm2uF(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠡ฻ิฬ๏࠭ᑣ")
	,LiRcTVUWuth70DmPy(u"ࠬ࡯ࡦࡪ࡮ࡰ࠱ࡪࡴࡧ࡭࡫ࡶ࡬ࠬᑤ")		:YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ๅ้ไ฼ࠤ็์วสࠢล๎ࠥ็๊ๅ็ࠣห๋าไ๋ิํࠫᑥ")
	,iUeoLOsbHqP(u"ࠧࡪࡲࡷࡺࠬᑦ")					:hBvsQ7oCkKUdwjx58ml3EN(u"ࠨࡋࡓࡘ࡛࠭ᑧ")
	,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩ࡬ࡴࡹࡼ࠭࡭࡫ࡹࡩࠬᑨ")			:hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪࡍࡕ࡚ࡖࠡไ้์ฬะࠧᑩ")
	,fprnld4CZo(u"ࠫ࡮ࡶࡴࡷ࠯ࡰࡳࡻ࡯ࡥࡴࠩᑪ")			:oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠬࡏࡐࡕࡘࠣวๆ๊วๆࠩᑫ")
	,l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࡩࡱࡶࡹ࠱ࡸ࡫ࡲࡪࡧࡶࠫᑬ")			:lc0dpSmwoPDjLnk(u"ࠧࡊࡒࡗ๋࡚ࠥำๅี็หฯ࠭ᑭ")
	,yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨ࡭ࡤࡶࡧࡧ࡬ࡢࡶࡹࠫᑮ")	:wRxoKs10Syj7V4edYhtP(u"่ࠩ์็฿ࠠใ่สอ้ࠥัษๆสลࠬᑯ")
	,oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠪ࡯ࡦࡺ࡫ࡰࡶࡷࡺࠬᑰ")		:sTcr7iDp5eFt4RoLMhuwq1A(u"๊ࠫ๎โฺࠢๆฮ่๎สࠡฬํๅ๏࠭ᑱ")
	,FnBiAjthS8MkXs67W(u"ࠬࡱࡡࡵ࡭ࡲࡹࡹ࡫ࠧᑲ")		:SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ๅ้ไ฼ࠤ่ะใ้ฬࠪᑳ")
	,iUeoLOsbHqP(u"ࠧ࡭ࡣࡵࡳࡿࡧࠧᑴ")		:dshJSmRqeiP9nap2(u"ࠨ็๋ๆ฾ࠦไศำ๋ึฬ࠭ᑵ")
	,Cu1704YofAbr3QTm(u"ࠩ࡯࡭ࡧࡸࡡࡳࡻࠪᑶ")		:FvNyZqaLKw(u"้้ࠪ็ࠧᑷ")
	,G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࡱ࡯ࡶࡦࡶࡹࠫᑸ")		:bUdr5Hahw6sY8xJ(u"๋ࠬไโࠩᑹ")
	,Me28A1sBLNIgUp5YCDyvT(u"࠭࡬ࡰࡦࡼࡲࡪࡺࠧᑺ")		:dshJSmRqeiP9nap2(u"ࠧๆ๊ๅ฽๊่ࠥะ์๊ࠣฯ࠭ᑻ")
	,wRxoKs10Syj7V4edYhtP(u"ࠨ࡯࠶ࡹࠬᑼ")					:pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩࡐ࠷࡚࠭ᑽ")
	,UTelCo0ihE1d5R(u"ࠪࡱ࠸ࡻ࠭࡭࡫ࡹࡩࠬᑾ")				:xW2Arao7YVOemw(u"ࠫࡒ࠹ࡕࠡไ้์ฬะࠧᑿ")
	,SO94xq1RAkMm2uF(u"ࠬࡳ࠳ࡶ࠯ࡰࡳࡻ࡯ࡥࡴࠩᒀ")			:iRoLg2m47tnDATBHGCSPNyx(u"࠭ࡍ࠴ࡗࠣวๆ๊วๆࠩᒁ")
	,xW2Arao7YVOemw(u"ࠧ࡮࠵ࡸ࠱ࡸ࡫ࡲࡪࡧࡶࠫᒂ")			:bUdr5Hahw6sY8xJ(u"ࠨࡏ࠶๋࡙ࠥำๅี็หฯ࠭ᒃ")
	,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩࡰࡳࡻࡹ࠴ࡶࠩᒄ")		:E6MIKdpBomef(u"้ࠪํู่ࠡ็๋ๅืࠦแ้ำํ์ࠬᒅ")
	,G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࡲࡿࡣࡪ࡯ࡤࠫᒆ")		:l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"๋่ࠬใ฻้ࠣฬ๐ࠠิ์่หࠬᒇ")
	,yA5z6LIXBlo41PRVMY87wOisFp(u"࠭ࡰࡢࡰࡨࡸࠬᒈ")				:yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧๆ๊ๅ฽ࠥฮว็์อࠫᒉ")
	,xW2Arao7YVOemw(u"ࠨࡲࡤࡲࡪࡺ࠭࡮ࡱࡹ࡭ࡪࡹࠧᒊ")			:kEhAHvti6Vnsfx(u"่ࠩ์็฿ࠠษษ้๎ฯࠦวโๆส้ࠬᒋ")
	,bUdr5Hahw6sY8xJ(u"ࠪࡴࡦࡴࡥࡵ࠯ࡶࡩࡷ࡯ࡥࡴࠩᒌ")			:XzrqbGDIy54juixkMA(u"๊ࠫ๎โฺࠢหห๋๐สࠡ็ึุ่๊วหࠩᒍ")
	,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧᒎ")		:zqdvcbP5L8BHh(u"࠭ๅ้ไ฼ࠤูอ็ะࠢไ์ึ๐่ࠨᒏ")
	,E6MIKdpBomef(u"ࠧࡴࡪࡤ࡬࡮ࡪ࡮ࡦࡹࡶࠫᒐ")	:G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠨ็๋ๆ฾ࠦิศ้าࠤ๋๐่ำࠩᒑ")
	,SO94xq1RAkMm2uF(u"ࠩࡶ࡬࡮ࡧࡶࡰ࡫ࡦࡩࠬᒒ")			:iUeoLOsbHqP(u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠬᒓ")
	,g4g6bfkPtVGU5lIM3(u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫࠭ࡢ࡮ࡥࡹࡲࡹࠧᒔ")		:l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠠศๆห์๊࠭ᒕ")
	,zqdvcbP5L8BHh(u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦ࠯ࡤࡹࡩ࡯࡯ࡴࠩᒖ")		:wRxoKs10Syj7V4edYhtP(u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสุࠢ์ฯ๐วหࠩᒗ")
	,FvNyZqaLKw(u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨ࠱ࡵ࡫ࡲࡴࡱࡱࡷࠬᒘ")	:wRxoKs10Syj7V4edYhtP(u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤ็อัวࠩᒙ")
	,wRxoKs10Syj7V4edYhtP(u"ࠪࡷ࡭ࡵࡦࡩࡣࠪᒚ")		:dshJSmRqeiP9nap2(u"๊ࠫ๎โฺࠢื์ๆํวࠡฬํๅ๏࠭ᒛ")
	,wRxoKs10Syj7V4edYhtP(u"ࠬࡹࡨࡰࡱࡩࡱࡦࡾࠧᒜ")		:SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ๅ้ไ฼ࠤู๎แࠡ็ส็ุ࠭ᒝ")
	,XzrqbGDIy54juixkMA(u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩᒞ")		:kEhAHvti6Vnsfx(u"ࠨ็๋ๆ฾ࠦิ้ใࠣฬึ๎ࠧᒟ")
	,S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠩࡷࡺ࡫ࡻ࡮ࠨᒠ")		:G5DeRbUpFj8E9OtJLvlo2fWmZC(u"้ࠪํู่ࠡฬํๅ๏ࠦแศ่ࠪᒡ")
	,hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠫࡼ࡫ࡣࡪ࡯ࡤࠫᒢ")		:zqdvcbP5L8BHh(u"๋่ࠬใ฻ࠣ์๏ࠦำ๋็สࠫᒣ")
	,UTelCo0ihE1d5R(u"࠭ࡹࡢࡳࡲࡸࠬᒤ")		:dshJSmRqeiP9nap2(u"ࠧๆ๊ๅ฽ࠥ๐วใ๊อࠫᒥ")
	,SO94xq1RAkMm2uF(u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩᒦ")				:xW2Arao7YVOemw(u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠧᒧ")
	,bUdr5Hahw6sY8xJ(u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠱ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ᒨ")		:Cu1704YofAbr3QTm(u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢๅ๊ํอสࠨᒩ")
	,wRxoKs10Syj7V4edYhtP(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠳ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩᒪ")	:hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤ็๎วว็ࠪᒫ")
	,l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠨᒬ")		:oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦแ๋ัํ์์อสࠨᒭ")
	,S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠩࡼࡸࡧࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨᒮ")	:oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"้ࠪํอโฺࠢํ์ฯ๐่ษࠩᒯ")
	}
	try: bph8oFsIHqyE5AWMTCvSkQgfzD3 = D4ubdsmVyQOKMie2JtqRP[fH8bDPV6AceuCFNO0Ert7oq3p.lower()]
	except: bph8oFsIHqyE5AWMTCvSkQgfzD3 = SO94xq1RAkMm2uF(u"ࠫࠬᒰ")
	return bph8oFsIHqyE5AWMTCvSkQgfzD3
def zrIWmJZh2CpVf8(oCrTtRIykV4E9fuKnBGW=fprnld4CZo(u"ࠬ࠭ᒱ")):
	KoJbHj06uiglhdVTtws58xLNB()
	if oCrTtRIykV4E9fuKnBGW: LOHZ4o9m7p6ebfTYXGIdz5PWs3q(Cu1704YofAbr3QTm(u"࠭ࠧᒲ"),Me28A1sBLNIgUp5YCDyvT(u"ࠧ࡝ࡰࠪᒳ")+oCrTtRIykV4E9fuKnBGW+p72fnFtcPix5UKwr9YNzW(u"ࠨ࡞ࡱࠫᒴ"))
	raise SystemExit
def mGfdCk4Hyclg9RjD(mHejXxkvM1qCESPVRy54QB,VKxFDdXYo6R=S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠩ࠽࠳ࠬᒵ")):
	return _ycmolWPUNz(mHejXxkvM1qCESPVRy54QB,VKxFDdXYo6R)
def PecCS6YX0G(aLT5PozvdWkh):
	if aLT5PozvdWkh in [lc0dpSmwoPDjLnk(u"ࠪࠫᒶ"),iRoLg2m47tnDATBHGCSPNyx(u"ࠫ࠵࠭ᒷ"),UTelCo0ihE1d5R(u"࠲᝱")]: return xW2Arao7YVOemw(u"ࠬ࠭ᒸ")
	aLT5PozvdWkh = int(aLT5PozvdWkh)
	COLZQX2M046NduISsxKrhfb7aV = aLT5PozvdWkh^ZcdnQAJ3ltkoiPsyX5
	OEfw2TqRGy0irJYlHUdIsNK = aLT5PozvdWkh^Oa8xvPtmLZkBA43K0EzrdhXS
	SraZPwhdUOTtnu9Hx1gIzc672 = aLT5PozvdWkh^xh9BXlAw0UoVsIZ4if3
	bph8oFsIHqyE5AWMTCvSkQgfzD3 = str(COLZQX2M046NduISsxKrhfb7aV)+str(OEfw2TqRGy0irJYlHUdIsNK)+str(SraZPwhdUOTtnu9Hx1gIzc672)
	return bph8oFsIHqyE5AWMTCvSkQgfzD3
def e2Yyf9AZPETk0(aLT5PozvdWkh):
	if aLT5PozvdWkh in [hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ࠧᒹ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠧ࠱ࠩᒺ"),fprnld4CZo(u"࠳ᝲ")]: return YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠨࠩᒻ")
	aLT5PozvdWkh = str(aLT5PozvdWkh)
	bph8oFsIHqyE5AWMTCvSkQgfzD3 = FvNyZqaLKw(u"ࠩࠪᒼ")
	if len(aLT5PozvdWkh)==g4g6bfkPtVGU5lIM3(u"࠵࠺ᝳ"):
		COLZQX2M046NduISsxKrhfb7aV,OEfw2TqRGy0irJYlHUdIsNK,SraZPwhdUOTtnu9Hx1gIzc672 = aLT5PozvdWkh[Cu1704YofAbr3QTm(u"࠶᝵"):iUeoLOsbHqP(u"࠴᝶")],aLT5PozvdWkh[iUeoLOsbHqP(u"࠴᝶"):SO94xq1RAkMm2uF(u"࠾᝴")],aLT5PozvdWkh[SO94xq1RAkMm2uF(u"࠾᝴"):]
		COLZQX2M046NduISsxKrhfb7aV = int(COLZQX2M046NduISsxKrhfb7aV)^xh9BXlAw0UoVsIZ4if3
		OEfw2TqRGy0irJYlHUdIsNK = int(OEfw2TqRGy0irJYlHUdIsNK)^Oa8xvPtmLZkBA43K0EzrdhXS
		SraZPwhdUOTtnu9Hx1gIzc672 = int(SraZPwhdUOTtnu9Hx1gIzc672)^ZcdnQAJ3ltkoiPsyX5
		if COLZQX2M046NduISsxKrhfb7aV==OEfw2TqRGy0irJYlHUdIsNK==SraZPwhdUOTtnu9Hx1gIzc672: bph8oFsIHqyE5AWMTCvSkQgfzD3 = str(COLZQX2M046NduISsxKrhfb7aV*pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠷࠲᝷"))
	return bph8oFsIHqyE5AWMTCvSkQgfzD3
def njglTZ1qzxm9K70U2(aLT5PozvdWkh,bV1e7UOPLlahidrKNYoAt6X9Dnp=pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠪ࠺࠸࠾࠴࠲࠺࠵࠷ࠬᒽ")):
	if aLT5PozvdWkh==QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫࠬᒾ"): return lc0dpSmwoPDjLnk(u"ࠬ࠭ᒿ")
	aLT5PozvdWkh = int(aLT5PozvdWkh)+int(bV1e7UOPLlahidrKNYoAt6X9Dnp)
	COLZQX2M046NduISsxKrhfb7aV = aLT5PozvdWkh^ZcdnQAJ3ltkoiPsyX5
	OEfw2TqRGy0irJYlHUdIsNK = aLT5PozvdWkh^Oa8xvPtmLZkBA43K0EzrdhXS
	SraZPwhdUOTtnu9Hx1gIzc672 = aLT5PozvdWkh^xh9BXlAw0UoVsIZ4if3
	bph8oFsIHqyE5AWMTCvSkQgfzD3 = str(COLZQX2M046NduISsxKrhfb7aV)+str(OEfw2TqRGy0irJYlHUdIsNK)+str(SraZPwhdUOTtnu9Hx1gIzc672)
	return bph8oFsIHqyE5AWMTCvSkQgfzD3
def YrGtRdILOunPs8Zv(aLT5PozvdWkh,bV1e7UOPLlahidrKNYoAt6X9Dnp=lc0dpSmwoPDjLnk(u"࠭࠶࠴࠺࠷࠵࠽࠸࠳ࠨᓀ")):
	if aLT5PozvdWkh==iRoLg2m47tnDATBHGCSPNyx(u"ࠧࠨᓁ"): return QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠨࠩᓂ")
	aLT5PozvdWkh = str(aLT5PozvdWkh)
	EFfqeBcwy8xLPgk1M0Izao = int(len(aLT5PozvdWkh)/l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠵᝸"))
	COLZQX2M046NduISsxKrhfb7aV = int(aLT5PozvdWkh[FnBiAjthS8MkXs67W(u"࠳᝹"):EFfqeBcwy8xLPgk1M0Izao])^ZcdnQAJ3ltkoiPsyX5
	OEfw2TqRGy0irJYlHUdIsNK = int(aLT5PozvdWkh[EFfqeBcwy8xLPgk1M0Izao:p72fnFtcPix5UKwr9YNzW(u"࠶᝺")*EFfqeBcwy8xLPgk1M0Izao])^Oa8xvPtmLZkBA43K0EzrdhXS
	SraZPwhdUOTtnu9Hx1gIzc672 = int(aLT5PozvdWkh[lc0dpSmwoPDjLnk(u"࠸᝼")*EFfqeBcwy8xLPgk1M0Izao:iRoLg2m47tnDATBHGCSPNyx(u"࠸᝻")*EFfqeBcwy8xLPgk1M0Izao])^xh9BXlAw0UoVsIZ4if3
	bph8oFsIHqyE5AWMTCvSkQgfzD3 = g4g6bfkPtVGU5lIM3(u"ࠩࠪᓃ")
	if COLZQX2M046NduISsxKrhfb7aV==OEfw2TqRGy0irJYlHUdIsNK==SraZPwhdUOTtnu9Hx1gIzc672: bph8oFsIHqyE5AWMTCvSkQgfzD3 = str(int(COLZQX2M046NduISsxKrhfb7aV)-int(bV1e7UOPLlahidrKNYoAt6X9Dnp))
	return bph8oFsIHqyE5AWMTCvSkQgfzD3
def AacQrJ0RSlzI4(eExNKbV8wRjtzk5oh):
	REIeh2DnyslY7v89c = oSVpce1UQYrDqhuM6PT[yA5z6LIXBlo41PRVMY87wOisFp(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪᓄ")][lc0dpSmwoPDjLnk(u"࠸᝽")]
	L80LRyAMds6Uf = PW2xo0Kq3Tcprj9Ck(yA5z6LIXBlo41PRVMY87wOisFp(u"࠴࠴᝾"))
	v51Okh2xDXCKyJmAQaY8f = WpgZTyqoMAPhwGiXF.path.join(bdmxngE9YGIeQ,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࡷ࡫ࡳࡰࡷࡵࡧࡪࡹࠧᓅ"),xW2Arao7YVOemw(u"ࠬࡹ࡫ࡪࡰࡶࠫᓆ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧᓇ"),fprnld4CZo(u"ࠧ࠸࠴࠳ࡴࠬᓈ"),LiRcTVUWuth70DmPy(u"ࠨࡆ࡬ࡥࡱࡵࡧࡄࡱࡱࡪ࡮ࡸ࡭ࡕࡪࡵࡩࡪࡈࡵࡵࡶࡲࡲࡸ࠴ࡸ࡮࡮ࠪᓉ"))
	aaGvilVdysOf5bZ689w3qCW4rPg1,hqXgRmMCPtWpKxskGc2UbON = hYNG3tj5Xu2knZ7lowbS(v51Okh2xDXCKyJmAQaY8f)
	aaGvilVdysOf5bZ689w3qCW4rPg1 = njglTZ1qzxm9K70U2(aaGvilVdysOf5bZ689w3qCW4rPg1,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩ࠴࠶࠶࠾࠳࠲࠺࠸࠷ࠬᓊ"))
	FtMIw9AC2hgynYTvXd = {l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪ࡭ࡩࡹࠧᓋ"):kEhAHvti6Vnsfx(u"ࠫࡉࡏࡁࡍࡑࡊࠫᓌ"),p72fnFtcPix5UKwr9YNzW(u"ࠬࡻࡳࡳࠩᓍ"):L80LRyAMds6Uf,LiRcTVUWuth70DmPy(u"࠭ࡶࡦࡴࠪᓎ"):mmn0lB2tFI7XTgVfESo,FnBiAjthS8MkXs67W(u"ࠧࡴࡥࡵࠫᓏ"):eExNKbV8wRjtzk5oh,yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨࡵ࡬ࡾࠬᓐ"):aaGvilVdysOf5bZ689w3qCW4rPg1}
	m609mNiOklMS3AG71PtB = {S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨᓑ"):S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩᓒ")}
	QdRCFMAkGl = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,lc0dpSmwoPDjLnk(u"ࠫࡕࡕࡓࡕࠩᓓ"),REIeh2DnyslY7v89c,FtMIw9AC2hgynYTvXd,m609mNiOklMS3AG71PtB,p72fnFtcPix5UKwr9YNzW(u"ࠬ࠭ᓔ"),SO94xq1RAkMm2uF(u"࠭ࠧᓕ"),bUdr5Hahw6sY8xJ(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡕࡋࡓ࡜ࡥࡐࡍࡃ࡜ࡣࡉࡏࡁࡍࡑࡊ࠱࠶ࡹࡴࠨᓖ"))
	DDwmI7P9ebz2ysKjtxX5 = QdRCFMAkGl.content
	try:
		if not DDwmI7P9ebz2ysKjtxX5: CZbY8MJQ2F0NPUTyDShtmgvwusf4Wn
		WvQLqzAMnpRVKNegjI4TPHZrx7fY = JKw5OWktPZB(g4g6bfkPtVGU5lIM3(u"ࠨࡦ࡬ࡧࡹ࠭ᓗ"),DDwmI7P9ebz2ysKjtxX5)
		V4ZdLm1cvs8t = WvQLqzAMnpRVKNegjI4TPHZrx7fY[wRxoKs10Syj7V4edYhtP(u"ࠩࡰࡷ࡬࠭ᓘ")]
		EuSwM7asx5nl0QGyRBCrJhYTFbU = WvQLqzAMnpRVKNegjI4TPHZrx7fY[lc0dpSmwoPDjLnk(u"ࠪࡷࡪࡩࠧᓙ")]
		wu9peV2W0qy1zgNT8AUvlbj = WvQLqzAMnpRVKNegjI4TPHZrx7fY[l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫࡸࡺࡰࠨᓚ")]
		EuSwM7asx5nl0QGyRBCrJhYTFbU = int(YrGtRdILOunPs8Zv(EuSwM7asx5nl0QGyRBCrJhYTFbU,wRxoKs10Syj7V4edYhtP(u"ࠬ࠷࠲࠲࠺࠶࠵࠽࠻࠳ࠨᓛ")))
		wu9peV2W0qy1zgNT8AUvlbj = int(YrGtRdILOunPs8Zv(wu9peV2W0qy1zgNT8AUvlbj,wRxoKs10Syj7V4edYhtP(u"࠭࠱࠳࠳࠻࠷࠶࠾࠵࠴ࠩᓜ")))
		for ctV6U0PaNb8uk5z in range(EuSwM7asx5nl0QGyRBCrJhYTFbU,SO94xq1RAkMm2uF(u"࠲᝿"),-wu9peV2W0qy1zgNT8AUvlbj):
			if not eval(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡪࡵࡓࡰࡦࡿࡩ࡯ࡩ࡙࡭ࡩ࡫࡯ࠩࠫࠪᓝ"),{hBvsQ7oCkKUdwjx58ml3EN(u"ࠨࡺࡥࡱࡨ࠭ᓞ"):cEZpW924rqNYm5}): CZbY8MJQ2F0NPUTyDShtmgvwusf4Wn
			From8aTqdhCbPs(iRoLg2m47tnDATBHGCSPNyx(u"ࠩหห็๐ࠠๅๆอะึฮษ๊ࠡส่ๆำีࠨᓟ"),str(ctV6U0PaNb8uk5z)+xW2Arao7YVOemw(u"ࠪࠤࠥัว็์ฬࠫᓠ"),MQbODJoPV2w8TEAg4zXZdjLxSW=iUeoLOsbHqP(u"࠶࠴࠵ក")*wu9peV2W0qy1zgNT8AUvlbj)
			cEZpW924rqNYm5.sleep(Cu1704YofAbr3QTm(u"࠵࠵࠶࠰ខ")*wu9peV2W0qy1zgNT8AUvlbj)
		if eval(dshJSmRqeiP9nap2(u"ࠫࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲࡮ࡹࡐ࡭ࡣࡼ࡭ࡳ࡭ࡖࡪࡦࡨࡳ࠭࠯ࠧᓡ"),{p72fnFtcPix5UKwr9YNzW(u"ࠬࡾࡢ࡮ࡥࠪᓢ"):cEZpW924rqNYm5}):
			V4ZdLm1cvs8t = V4ZdLm1cvs8t.replace(LiRcTVUWuth70DmPy(u"࠭࡜࡯ࠩᓣ"),iUeoLOsbHqP(u"ࠧ࡝࡞ࡱࠫᓤ")).replace(dshJSmRqeiP9nap2(u"ࠨ࡞ࡵࠫᓥ"),FvNyZqaLKw(u"ࠩ࡟ࡠࡷ࠭ᓦ"))
			aHKzv76JCVnprbY8w(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪࠫᓧ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠫำื่อࠩᓨ"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᓩ"),V4ZdLm1cvs8t)
		CZbY8MJQ2F0NPUTyDShtmgvwusf4Wn
	except: exec(FnBiAjthS8MkXs67W(u"࠭ࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡳࡵࡱࡳࠬ࠮࠭ᓪ"),{YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࡹࡤࡰࡧࠬᓫ"):cEZpW924rqNYm5})
	return
def fMcamW7S36DCtuvGndVhTj4ZbO5P():
	exec(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠨࠩࠪࠑࠏࡺࡲࡺ࠼ࠐࠎࠎࡽࡩ࡯ࡦࡲࡻ࠶࠸࠳ࠡ࠿ࠣࡼࡧࡳࡣࡨࡷ࡬࠲࡜࡯࡮ࡥࡱࡺࠬ࠶࠶࠰࠳࠷ࠬࠑࠏࠏࡷࡩ࡫࡯ࡩ࡚ࠥࡲࡶࡧ࠽ࠑࠏࠏࠉࡹࡤࡰࡧ࠳ࡹ࡬ࡦࡧࡳࠬ࠶࠶࠰࠱ࠫࠐࠎࠎࠏࡴࡳࡻ࠽ࠤࡼ࡯࡮ࡥࡱࡺ࠵࠷࠹࠮ࡨࡧࡷࡊࡴࡩࡵࡴࠪ࠴࠴࠵࠸࠵ࠪࠏࠍࠍࠎ࡫ࡸࡤࡧࡳࡸ࠿ࠦࡢࡳࡧࡤ࡯ࠒࠐࠉࡻࡥࡵࡩࡦࡺࡥࡠࡧࡵࡳࡷࡸࠍࠋࡧࡻࡧࡪࡶࡴ࠻ࠢࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰ࡶࡸࡴࡶࠨࠪࠏࠍࠫࠬ࠭ᓬ"),{FvNyZqaLKw(u"ࠩࡻࡦࡲࡩࡧࡶ࡫ࠪᓭ"):zz2LJUB9kjnZqAeH,sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࡼࡧࡳࡣࠨᓮ"):cEZpW924rqNYm5})
	return
def hYNG3tj5Xu2knZ7lowbS(CESIzlW2YjMJck9ZuhXvfdTym0e):
	HICQUYNXo1yMh,L8Nc9Q4IRd5Bqm21ZF = g4g6bfkPtVGU5lIM3(u"࠵គ"),g4g6bfkPtVGU5lIM3(u"࠵គ")
	if WpgZTyqoMAPhwGiXF.path.exists(CESIzlW2YjMJck9ZuhXvfdTym0e):
		try: HICQUYNXo1yMh = WpgZTyqoMAPhwGiXF.path.getsize(CESIzlW2YjMJck9ZuhXvfdTym0e)
		except: pass
		if not HICQUYNXo1yMh:
			try: HICQUYNXo1yMh = WpgZTyqoMAPhwGiXF.stat(CESIzlW2YjMJck9ZuhXvfdTym0e).st_size
			except: pass
		if not HICQUYNXo1yMh:
			try:
				from pathlib import Path as a9aLZxb7MjrSTvVFsID8R
				HICQUYNXo1yMh = a9aLZxb7MjrSTvVFsID8R(CESIzlW2YjMJck9ZuhXvfdTym0e).stat().st_size
			except: pass
		if HICQUYNXo1yMh: L8Nc9Q4IRd5Bqm21ZF = lc0dpSmwoPDjLnk(u"࠷ឃ")
	return HICQUYNXo1yMh,L8Nc9Q4IRd5Bqm21ZF
def OOy4gzCqrV382ctPa(LJpiu0cUyIoN,PQcml15NWf8E,showDialogs):
	if showDialogs:
		o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(kEhAHvti6Vnsfx(u"ࠫࠬᓯ"),FnBiAjthS8MkXs67W(u"ࠬ࠭ᓰ"),Cu1704YofAbr3QTm(u"࠭ࠧᓱ"),Cu1704YofAbr3QTm(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᓲ"),LJpiu0cUyIoN+FnBiAjthS8MkXs67W(u"ࠨ࡞ࡱࡠࡳ࠭ᓳ")+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ์๊ࠠหำํำ๋ࠥำฮ๊ࠢิฬࠦวๅ็ฯ่ิࠦฟࠢ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᓴ"))
		if o07Z1tEB4n3ARCkVNu!=LiRcTVUWuth70DmPy(u"࠱ង"): return
	VVEta3LoIkqnG = S4SOKF2QbBhjCd3RrVMuHIzE(u"ࡉࡥࡱࡹࡥ᠚")
	if WpgZTyqoMAPhwGiXF.path.exists(LJpiu0cUyIoN):
		for PPpdbwumk4FXsHMZVh3o,Pquk4npoem9K0t5SFsNYR,OwhENJc75KjTmMH8qtzo1Sfv0X9kU6 in WpgZTyqoMAPhwGiXF.walk(LJpiu0cUyIoN,topdown=Me28A1sBLNIgUp5YCDyvT(u"ࡊࡦࡲࡳࡦ᠛")):
			for CESIzlW2YjMJck9ZuhXvfdTym0e in OwhENJc75KjTmMH8qtzo1Sfv0X9kU6:
				GGb8Hsk2rSt9B = WpgZTyqoMAPhwGiXF.path.join(PPpdbwumk4FXsHMZVh3o,CESIzlW2YjMJck9ZuhXvfdTym0e)
				try: WpgZTyqoMAPhwGiXF.remove(GGb8Hsk2rSt9B)
				except Exception as D2VbK9hH17PSolWyBT8Uu:
					if showDialogs and not VVEta3LoIkqnG: aHKzv76JCVnprbY8w(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࠫᓵ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫࠬᓶ"),SO94xq1RAkMm2uF(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᓷ"),str(D2VbK9hH17PSolWyBT8Uu))
					VVEta3LoIkqnG = SyENPzdOon6uxcLXMhqb14aDlB9r(u"࡙ࡸࡵࡦ᠜")
			if PQcml15NWf8E:
				for dir in Pquk4npoem9K0t5SFsNYR:
					ckbJ59nvm4BNXSsYMoi = WpgZTyqoMAPhwGiXF.path.join(PPpdbwumk4FXsHMZVh3o,dir)
					try: WpgZTyqoMAPhwGiXF.rmdir(ckbJ59nvm4BNXSsYMoi)
					except: pass
		if PQcml15NWf8E:
			try: WpgZTyqoMAPhwGiXF.rmdir(PPpdbwumk4FXsHMZVh3o)
			except: pass
	if showDialogs and not VVEta3LoIkqnG:
		aHKzv76JCVnprbY8w(iRoLg2m47tnDATBHGCSPNyx(u"࠭ࠧᓸ"),SO94xq1RAkMm2uF(u"ࠧࠨᓹ"),iUeoLOsbHqP(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᓺ"),iRoLg2m47tnDATBHGCSPNyx(u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪᓻ"))
		jHevARrF7lS.setSetting(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧᓼ"),g4g6bfkPtVGU5lIM3(u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧᓽ"))
		cEZpW924rqNYm5.executebuiltin(Me28A1sBLNIgUp5YCDyvT(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩᓾ"))
	return
def KoJbHj06uiglhdVTtws58xLNB(CCeZSJvsigLcq=G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠭ࠧᓿ")):
	Mrch2HElwVNnm9siDCkZIKFbYL6ao7(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠧࡴࡶࡲࡴࠬᔀ"))
	if CCeZSJvsigLcq:
		iiFQATmrePSj = jHevARrF7lS.getSetting(iUeoLOsbHqP(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩᔁ"))
		jHevARrF7lS.setSetting(E6MIKdpBomef(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪᔂ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࠫᔃ"))
		XxluY9ohL0Ri3paB(CCeZSJvsigLcq)
		jHevARrF7lS.setSetting(iRoLg2m47tnDATBHGCSPNyx(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬᔄ"),iiFQATmrePSj)
	gGudVm2TlMnyh = jHevARrF7lS.getSetting(LiRcTVUWuth70DmPy(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩᔅ"))
	if gGudVm2TlMnyh==oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠭ࡒࡆࡓࡘࡉࡘ࡚ࡅࡅࠩᔆ"): jHevARrF7lS.setSetting(iUeoLOsbHqP(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫᔇ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨࡔࡈࡊࡗࡋࡓࡉࡇࡇࠫᔈ"))
	elif gGudVm2TlMnyh==xW2Arao7YVOemw(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡈࡈࠬᔉ"): jHevARrF7lS.setSetting(lc0dpSmwoPDjLnk(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧᔊ"),E6MIKdpBomef(u"ࠫࠬᔋ"))
	if jHevARrF7lS.getSetting(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨᔌ")) not in [hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ࡁࡖࡖࡒࠫᔍ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧࡔࡖࡒࡔࠬᔎ"),SO94xq1RAkMm2uF(u"ࠨࡃࡖࡏࠬᔏ")]: jHevARrF7lS.setSetting(wRxoKs10Syj7V4edYhtP(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬᔐ"),bUdr5Hahw6sY8xJ(u"ࠪࡅࡘࡑࠧᔑ"))
	if jHevARrF7lS.getSetting(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩᔒ")) not in [kEhAHvti6Vnsfx(u"ࠬࡇࡕࡕࡑࠪᔓ"),E6MIKdpBomef(u"࠭ࡓࡕࡑࡓࠫᔔ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࡂࡕࡎࠫᔕ")]: jHevARrF7lS.setSetting(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ᔖ"),bUdr5Hahw6sY8xJ(u"ࠩࡄࡗࡐ࠭ᔗ"))
	a05jnRr3dgyslHwzK814XGQCiYIbp = jHevARrF7lS.getSetting(FvNyZqaLKw(u"ࠪࡥࡻ࠴࡭ࡺࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨᔘ"))
	Rbnv9164DBGdE = cEZpW924rqNYm5.executeJSONRPC(SO94xq1RAkMm2uF(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧᔙ"))
	if wRxoKs10Syj7V4edYhtP(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫᔚ") in str(Rbnv9164DBGdE) and a05jnRr3dgyslHwzK814XGQCiYIbp in [Cu1704YofAbr3QTm(u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩᔛ"),XzrqbGDIy54juixkMA(u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭ᔜ")]:
		MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(iRoLg2m47tnDATBHGCSPNyx(u"࠱࠰࠴࠴࠵ច"))
		cEZpW924rqNYm5.executebuiltin(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡘ࡫ࡴࡗ࡫ࡨࡻࡒࡵࡤࡦࠪ࠳࠭ࠬᔝ"))
	if sTcr7iDp5eFt4RoLMhuwq1A(u"࠳ជ") and cmBCkqS7vLYD3flwZ>-bUdr5Hahw6sY8xJ(u"࠳ឆ"):
		XL4sA9FNebx30oE.setResolvedUrl(cmBCkqS7vLYD3flwZ,xW2Arao7YVOemw(u"ࡌࡡ࡭ࡵࡨ᠝"),zz2LJUB9kjnZqAeH.ListItem())
		Tr8iRxJmbcEhftU5DSHzA,ONgqycFoxi,PK3YifFT0nxcUa = SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࡆࡢ࡮ࡶࡩ᠞"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࡆࡢ࡮ࡶࡩ᠞"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࡆࡢ࡮ࡶࡩ᠞")
		XL4sA9FNebx30oE.endOfDirectory(cmBCkqS7vLYD3flwZ,Tr8iRxJmbcEhftU5DSHzA,ONgqycFoxi,PK3YifFT0nxcUa)
	return
def DvMsd5eKPI02lXGHwgiWRCkU6Nra(cUsgVlb0iuBaW7OjSw4oCPL,vYFXP48WV6M,mHejXxkvM1qCESPVRy54QB,rKagANTOtGJnhVWfE2BHpePYC3IQ5l,ep9JAOkj1wr5s,hayXA4TiLlPxcVSIoK2):
	dR2vHyAtl8pJN1,yaeqrwZ9BhV7N1,N3aW1fHjZrXkGdCVmzMolTvqpI,bbCy3Uxd48jVeNmT1c = GUnATzyQjq(mHejXxkvM1qCESPVRy54QB)
	fPpK27Cej9wqutr0 = vYFXP48WV6M,dR2vHyAtl8pJN1,rKagANTOtGJnhVWfE2BHpePYC3IQ5l,ep9JAOkj1wr5s
	if cUsgVlb0iuBaW7OjSw4oCPL:
		U9rSWyc74gLOw = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,Cu1704YofAbr3QTm(u"ࠩࡶࡸࡷ࠭ᔞ"),Me28A1sBLNIgUp5YCDyvT(u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣ࡚ࡘࡌࡍࡋࡅࠫᔟ"),fPpK27Cej9wqutr0)
		if U9rSWyc74gLOw:
			XXmSpTHNao6Gxbs0eK5(XzrqbGDIy54juixkMA(u"࡚ࠫࡘࡌࡍࡋࡅࠤࠥࡘࡅࡂࡆࡢࡇࡆࡉࡈࡆࠩᔠ"),mHejXxkvM1qCESPVRy54QB,rKagANTOtGJnhVWfE2BHpePYC3IQ5l,ep9JAOkj1wr5s,hayXA4TiLlPxcVSIoK2,vYFXP48WV6M)
			return U9rSWyc74gLOw
	U9rSWyc74gLOw = t2RpE4wGrDfMvhjJZINln(vYFXP48WV6M,mHejXxkvM1qCESPVRy54QB,rKagANTOtGJnhVWfE2BHpePYC3IQ5l,ep9JAOkj1wr5s,hayXA4TiLlPxcVSIoK2)
	if U9rSWyc74gLOw and cUsgVlb0iuBaW7OjSw4oCPL: Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,fprnld4CZo(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡕࡓࡎࡏࡍࡇ࠭ᔡ"),fPpK27Cej9wqutr0,U9rSWyc74gLOw,cUsgVlb0iuBaW7OjSw4oCPL)
	return U9rSWyc74gLOw
from GwcCPira93 import *
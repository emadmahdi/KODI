# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'EGYBEST4'
mmDwMlfoHtG5XT19VLIWqCR8i = '_EB4_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
DDXTwbRBaj3e2rSsPQ = ['ايجي بست','اتصل بنا','ايجي بست الاصلي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست']
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,text):
	if   mode==800: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==801: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif mode==802: zpXG3Ky6ou8ndWHkb4 = i7pbAuodvX3(url)
	elif mode==803: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==804: zpXG3Ky6ou8ndWHkb4 = u5iGFOgPoB7n(url)
	elif mode==806: zpXG3Ky6ou8ndWHkb4 = pFmAuvrtnqEijTeQ4MRaw(url,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif mode==809: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',809,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فلتر',NBm2aWhPzoTpdYn+'/trending',804,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',NBm2aWhPzoTpdYn,'','','','','EGYBEST4-MENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('nav-categories(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			title = title.strip(' ')
			if any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in DDXTwbRBaj3e2rSsPQ): continue
			if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
			cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,801)
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('mainContent(.*?)<footer>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('mainTitle.*?href="(.*?)".*?title="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			title = title.strip(' ')
			if any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in DDXTwbRBaj3e2rSsPQ): continue
			if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
			cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,801,'','mainmenu')
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('main-menu(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			title = title.strip(' ')
			if any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in DDXTwbRBaj3e2rSsPQ): continue
			if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
			cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,801)
	return BBlXpmUyhFDwNtCVAHoE
def pFmAuvrtnqEijTeQ4MRaw(url,type=''):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','EGYBEST4-SEASONS_EPISODES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('mainTitle.*?>(.*?)<(.*?)pageContent',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		tt0PDNvYRduaiJSh8,kxoVRpfCEMyW15BFQu4n7G2,items = '','',[]
		for name,UCEFMfKbgpd in EeQqAGc0W5r6nlBbChwfZL:
			if 'حلقات' in name: kxoVRpfCEMyW15BFQu4n7G2 = UCEFMfKbgpd
			if 'مواسم' in name: tt0PDNvYRduaiJSh8 = UCEFMfKbgpd
		if tt0PDNvYRduaiJSh8 and not type:
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',tt0PDNvYRduaiJSh8,GGvHJKP9LUxEk10Fw.DOTALL)
			if len(items)>1:
				for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
					cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,806,VFqpJjRySZvgi,'season')
		if kxoVRpfCEMyW15BFQu4n7G2 and len(items)<2:
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',kxoVRpfCEMyW15BFQu4n7G2,GGvHJKP9LUxEk10Fw.DOTALL)
			if items:
				for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
					cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,803,VFqpJjRySZvgi)
			else:
				items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)<',kxoVRpfCEMyW15BFQu4n7G2,GGvHJKP9LUxEk10Fw.DOTALL)
				for ELbNB92cOh5dqtpVmi40kY,title in items:
					cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,803)
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(url,type=''):
	YliGQMEOWfHq8wcz,start,kMZsFyP9qdmj5KXlJLA8xNeCg3f,select,FwpuUBA6k9mI7CgiMH3fyNR = 0,0,'','',''
	if 'pagination' in type:
		EhqwLVFSdXaJc,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = url.split('?next=page&')
		BBYvCiQGe8RdpyAagfS72mZclxb5 = {'Content-Type':'application/x-www-form-urlencoded'}
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'POST',EhqwLVFSdXaJc,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,'','','EGYBEST4-TITLES-1st')
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		X3in5vNhqwWEG2TafmVCrFbSYDxjoK = 'secContent'+BBlXpmUyhFDwNtCVAHoE+'<footer>'
	else:
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','EGYBEST4-TITLES-2nd')
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		X3in5vNhqwWEG2TafmVCrFbSYDxjoK = BBlXpmUyhFDwNtCVAHoE
	items,ffOGheCcNowFKUZREBkMYp83H,FZj067Q2PlC8EsG9c5yiWpzNRq = [],False,False
	if not type and '/collections' not in url:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('mainContent(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?</i>(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				title = title.strip(' ')
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,801,'','submenu')
				ffOGheCcNowFKUZREBkMYp83H = True
	if not ffOGheCcNowFKUZREBkMYp83H:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('secContent(.*?)mainContent',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
				ELbNB92cOh5dqtpVmi40kY = GhPlajzTxY8(ELbNB92cOh5dqtpVmi40kY)
				VFqpJjRySZvgi = VFqpJjRySZvgi.strip('\n')
				title = DwNC3gEonizsB6a0v1F(title)
				if '/series/' in ELbNB92cOh5dqtpVmi40kY and type=='season': cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,806,VFqpJjRySZvgi,'season')
				elif '/series/' in ELbNB92cOh5dqtpVmi40kY: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,806,VFqpJjRySZvgi)
				elif '/seasons/' in ELbNB92cOh5dqtpVmi40kY: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,801,VFqpJjRySZvgi,'season')
				elif '/collections' in url: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,801,VFqpJjRySZvgi,'collections')
				else: cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,803,VFqpJjRySZvgi)
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('loadMoreParams = (.*?);',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
			AApkbKmuNhY14teiI2UMP7wQEf = JKw5OWktPZB('dict',UCEFMfKbgpd)
			FwpuUBA6k9mI7CgiMH3fyNR = AApkbKmuNhY14teiI2UMP7wQEf['ajaxurl']
			WgtDJdf7CrpxK41GQAMkyjSF8bu = int(AApkbKmuNhY14teiI2UMP7wQEf['current_page'])+1
			yO5kPAzwn6 = int(AApkbKmuNhY14teiI2UMP7wQEf['max_page'])
			cjyFBamb2CRr = AApkbKmuNhY14teiI2UMP7wQEf['posts'].replace('False','false').replace('True','true').replace('None','null')
			if WgtDJdf7CrpxK41GQAMkyjSF8bu<yO5kPAzwn6:
				Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = 'action=loadmore&query='+mGfdCk4Hyclg9RjD(cjyFBamb2CRr,'')+'&page='+str(WgtDJdf7CrpxK41GQAMkyjSF8bu)
				dR2vHyAtl8pJN1 = FwpuUBA6k9mI7CgiMH3fyNR+'?next=page&'+Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'جلب المزيد',dR2vHyAtl8pJN1,801,'','pagination_'+type)
		elif '?next=page&' in url:
			Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,IPbFd21uGo4Y7g5ntW8JNa0wlfC = Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd.rsplit('=',1)
			IPbFd21uGo4Y7g5ntW8JNa0wlfC = int(IPbFd21uGo4Y7g5ntW8JNa0wlfC)+1
			dR2vHyAtl8pJN1 = EhqwLVFSdXaJc+'?next=page&'+Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd+'='+str(IPbFd21uGo4Y7g5ntW8JNa0wlfC)
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'جلب المزيد',dR2vHyAtl8pJN1,801,'','pagination_'+type)
	return
def u5iGFOgPoB7n(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','EGYBEST4-FILTERS-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('sub_nav(.*?)secContent ',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		EHDeldN7L2k19JBUqhmsuSXiwV = GGvHJKP9LUxEk10Fw.findall('"current_opt">(.*?)<(.*?)</div>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for name,UCEFMfKbgpd in EHDeldN7L2k19JBUqhmsuSXiwV:
			if 'التصنيف' in name: continue
			name = name.strip(' ')
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,hieW1zRUG5w9AykJjv0X in items:
				title = name+':  '+hieW1zRUG5w9AykJjv0X
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,801,'','filter')
	return
def SUfe4unWoXBNFz90xqy(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,'GET',url,'','','','','EGYBEST4-PLAY-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	NbE4qnzmPKGWtjYpoRL3HTS1A = GGvHJKP9LUxEk10Fw.findall('<td>التصنيف</td>.*?">(.*?)<',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if NbE4qnzmPKGWtjYpoRL3HTS1A and hNCJPTucIV7GOSR0HytZ6eQrqEUpw(cTJphS1nFz5EUgNWm86C,url,NbE4qnzmPKGWtjYpoRL3HTS1A): return
	uuIjMn1YTf687WlRcOmhq4G23H,NBWQmkLbTzrcuEfKtp36 = [],[]
	ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall('postEmbed.*?src="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if ELbNB92cOh5dqtpVmi40kY:
		ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY[0].replace('\n','')
		NBWQmkLbTzrcuEfKtp36.append(ELbNB92cOh5dqtpVmi40kY)
		C83UXWf15zdwLA0 = RfKuIXwPAiWtmyF(ELbNB92cOh5dqtpVmi40kY,'name')
		uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY+'?named='+C83UXWf15zdwLA0+'__embed')
	COXUe5h6D8sE3bakPALMz2TG1yjpF0 = GGvHJKP9LUxEk10Fw.findall('vo_theme_dir.*?"(.*?)".*?"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if COXUe5h6D8sE3bakPALMz2TG1yjpF0:
		FwpuUBA6k9mI7CgiMH3fyNR,XXKY1GIJm9BeMw0jfdSWRtEi = COXUe5h6D8sE3bakPALMz2TG1yjpF0[0]
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('postPlayer(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
			UUNJq4HgwzSWE2Zm0vMdo7Rnc = GGvHJKP9LUxEk10Fw.findall('<li.*?id\,(.*?)\);">(.*?)</li>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for XBHqVoSCQg1uLNwe6cfUK05bdZIjW7,name in UUNJq4HgwzSWE2Zm0vMdo7Rnc:
				ELbNB92cOh5dqtpVmi40kY = FwpuUBA6k9mI7CgiMH3fyNR+'/temp/ajax/iframe.php?id='+XXKY1GIJm9BeMw0jfdSWRtEi+'&video='+XBHqVoSCQg1uLNwe6cfUK05bdZIjW7
				uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY+'?named='+name+'__watch')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('pageContentDown(.*?)</table>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('<tr>.*?<td>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</td>.*?href="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for dDZQSEGRTo9g85x1C,ELbNB92cOh5dqtpVmi40kY in items:
			if ELbNB92cOh5dqtpVmi40kY not in NBWQmkLbTzrcuEfKtp36:
				if '/?url=' in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.split('/?url=')[1]
				NBWQmkLbTzrcuEfKtp36.append(ELbNB92cOh5dqtpVmi40kY)
				C83UXWf15zdwLA0 = RfKuIXwPAiWtmyF(ELbNB92cOh5dqtpVmi40kY,'name')
				uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY+'?named='+C83UXWf15zdwLA0+'__download____'+dDZQSEGRTo9g85x1C)
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(uuIjMn1YTf687WlRcOmhq4G23H,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if not search: search = yMRXZIpKxlSkaE6iCO()
	if not search: return
	aKRILTAj1HC5c = search.replace(' ','+')
	url = NBm2aWhPzoTpdYn+'/?s='+aKRILTAj1HC5c
	xoiXMWjJC3pnQqurIGPkRSl8e(url,'search')
	return
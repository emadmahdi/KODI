# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'CIMALIGHT'
mmDwMlfoHtG5XT19VLIWqCR8i = '_CML_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
DDXTwbRBaj3e2rSsPQ = ['قنوات فضائية']
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==470: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==471: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,text)
	elif mode==472: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==473: zpXG3Ky6ou8ndWHkb4 = xKqSdbG6RNz8(url,text)
	elif mode==474: zpXG3Ky6ou8ndWHkb4 = i7pbAuodvX3(url)
	elif mode==479: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',NBm2aWhPzoTpdYn,'','','','','CIMALIGHT-MENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	aPNBvIyexc053gAsSw1QoRMUYfb = GGvHJKP9LUxEk10Fw.findall('"url": "(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	aPNBvIyexc053gAsSw1QoRMUYfb = aPNBvIyexc053gAsSw1QoRMUYfb[0].strip('/')
	aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(aPNBvIyexc053gAsSw1QoRMUYfb,'url')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',479,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"content"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?</i>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		title = title.replace('  ','').strip(' ')
		ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.replace('cat=online-movies1','cat=online-movies')
		cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,474)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('/category.php">(.*?)"navslide-divider"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall("'dropdown-menu'(.*?)</ul>",BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		if title in DDXTwbRBaj3e2rSsPQ: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,474)
	return
def i7pbAuodvX3(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','CIMALIGHT-TITLES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	if 'topvideos.php' in url: EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"caret"(.*?)id="pm-grid"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	else: EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"caret"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			if 'topvideos.php' in ELbNB92cOh5dqtpVmi40kY:
				if 'topvideos.php?c=english-movies' in ELbNB92cOh5dqtpVmi40kY: continue
				if 'topvideos.php?c=online-movies1' in ELbNB92cOh5dqtpVmi40kY: continue
				if 'topvideos.php?c=misc' in ELbNB92cOh5dqtpVmi40kY: continue
				if 'topvideos.php?c=tv-channel' in ELbNB92cOh5dqtpVmi40kY: continue
				if 'منذ البداية' in title and 'do=rating' not in ELbNB92cOh5dqtpVmi40kY: continue
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,471)
	else: xoiXMWjJC3pnQqurIGPkRSl8e(url)
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(url,hD6se2E307NcI=''):
	aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(url,'url')
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','CIMALIGHT-TITLES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	items = []
	if hD6se2E307NcI=='featured_movies':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"container-fluid"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		gI487voLsArVqW6Ffp,xut3LAibydXZnzkpBaKOsgew70,lYFvX6NUoDkHAfEcqtOi8QJ = zip(*items)
		items = zip(lYFvX6NUoDkHAfEcqtOi8QJ,gI487voLsArVqW6Ffp,xut3LAibydXZnzkpBaKOsgew70)
	elif hD6se2E307NcI=='featured_series':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('المسلسلات المميزة(.*?)<style>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		gI487voLsArVqW6Ffp,xut3LAibydXZnzkpBaKOsgew70,lYFvX6NUoDkHAfEcqtOi8QJ = zip(*items)
		items = zip(lYFvX6NUoDkHAfEcqtOi8QJ,gI487voLsArVqW6Ffp,xut3LAibydXZnzkpBaKOsgew70)
	else:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('(data-echo=".*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if not EeQqAGc0W5r6nlBbChwfZL: EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"BlocksList"(.*?)"titleSectionCon"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if not EeQqAGc0W5r6nlBbChwfZL: EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('id="pm-grid"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if not EeQqAGc0W5r6nlBbChwfZL: EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('id="pm-related"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if not EeQqAGc0W5r6nlBbChwfZL: EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('pm-ul-browse-videos(.*?)clearfix',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if not EeQqAGc0W5r6nlBbChwfZL: return
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	if not items: items = GGvHJKP9LUxEk10Fw.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	if not items: items = GGvHJKP9LUxEk10Fw.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	IcJOGsq3Ff7EmkiLx = []
	Dq0X5cvgdjwh6LbnUkETFBR8 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for VFqpJjRySZvgi,ELbNB92cOh5dqtpVmi40kY,title in items:
		ELbNB92cOh5dqtpVmi40kY = GhPlajzTxY8(ELbNB92cOh5dqtpVmi40kY).strip('/')
		title = title.replace('ماي سيما','').replace('مشاهدة','').strip(' ').replace('  ',' ')
		if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = aPNBvIyexc053gAsSw1QoRMUYfb+'/'+ELbNB92cOh5dqtpVmi40kY.strip('/')
		if 'http' not in VFqpJjRySZvgi: VFqpJjRySZvgi = aPNBvIyexc053gAsSw1QoRMUYfb+'/'+VFqpJjRySZvgi.strip('/')
		qUGxSK2VwsiBAdkDZnJ605vQeg = GGvHJKP9LUxEk10Fw.findall('(.*?) (الحلقة|حلقة) \d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
		if any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in Dq0X5cvgdjwh6LbnUkETFBR8):
			title = '_MOD_'+title
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,472,VFqpJjRySZvgi)
		elif qUGxSK2VwsiBAdkDZnJ605vQeg and 'حلقة' in title:
			title = '_MOD_'+qUGxSK2VwsiBAdkDZnJ605vQeg[0][0]
			if title not in IcJOGsq3Ff7EmkiLx:
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,473,VFqpJjRySZvgi)
				IcJOGsq3Ff7EmkiLx.append(title)
		elif '/movseries/' in ELbNB92cOh5dqtpVmi40kY:
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,471,VFqpJjRySZvgi)
		else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,473,VFqpJjRySZvgi)
	if hD6se2E307NcI not in ['featured_movies','featured_series']:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"pagination(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				if ELbNB92cOh5dqtpVmi40kY=='#': continue
				ELbNB92cOh5dqtpVmi40kY = aPNBvIyexc053gAsSw1QoRMUYfb+'/'+ELbNB92cOh5dqtpVmi40kY.strip('/')
				title = DwNC3gEonizsB6a0v1F(title)
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,471)
		ezAfMX0JKQPc2G = GGvHJKP9LUxEk10Fw.findall('showmore" href="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if ezAfMX0JKQPc2G:
			ELbNB92cOh5dqtpVmi40kY = ezAfMX0JKQPc2G[0]
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مشاهدة المزيد',ELbNB92cOh5dqtpVmi40kY,471)
	return
def xKqSdbG6RNz8(url,FzY68T7WDR1g4hEnNM5Sj9BkfXq):
	aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(url,'url')
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','CIMALIGHT-EPISODES-2nd')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	xxcVm7YBMXsfd = GGvHJKP9LUxEk10Fw.findall('"SeasonsBox"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	items = []
	if xxcVm7YBMXsfd and not FzY68T7WDR1g4hEnNM5Sj9BkfXq:
		VFqpJjRySZvgi = GGvHJKP9LUxEk10Fw.findall('"series-header".*?src="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		VFqpJjRySZvgi = VFqpJjRySZvgi[0] if VFqpJjRySZvgi else ''
		UCEFMfKbgpd = xxcVm7YBMXsfd[0]
		items = GGvHJKP9LUxEk10Fw.findall('openCity\(event\, \'(.*?)\'\)".*?>(.*?)</button>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if len(items)==1: FzY68T7WDR1g4hEnNM5Sj9BkfXq = items[0][0]
		elif len(items)>1:
			for FzY68T7WDR1g4hEnNM5Sj9BkfXq,title in items: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,473,VFqpJjRySZvgi,'',FzY68T7WDR1g4hEnNM5Sj9BkfXq)
	uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb = GGvHJKP9LUxEk10Fw.findall('id="'+FzY68T7WDR1g4hEnNM5Sj9BkfXq+'"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb and len(items)<2:
		VFqpJjRySZvgi = GGvHJKP9LUxEk10Fw.findall('"series-header".*?src="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		VFqpJjRySZvgi = VFqpJjRySZvgi[0] if VFqpJjRySZvgi else ''
		UCEFMfKbgpd = uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?title="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if items:
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				title = title.replace('ماي سيما','').replace('مسلسل','').strip(' ')
				if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = aPNBvIyexc053gAsSw1QoRMUYfb+'/'+ELbNB92cOh5dqtpVmi40kY.strip('/')
				cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,472,VFqpJjRySZvgi)
		else:
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,title,VFqpJjRySZvgi in items:
				if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = aPNBvIyexc053gAsSw1QoRMUYfb+'/'+ELbNB92cOh5dqtpVmi40kY.strip('/')
				cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,472,VFqpJjRySZvgi)
	if 'id="pm-related"' in BBlXpmUyhFDwNtCVAHoE:
		if items: cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مواضيع ذات صلة',url,471)
	return
def SUfe4unWoXBNFz90xqy(url):
	zzvBg3ShiamAZ = []
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','CIMALIGHT-PLAY-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('<div itemprop="description">(.*?)href=',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		NbE4qnzmPKGWtjYpoRL3HTS1A = GGvHJKP9LUxEk10Fw.findall('<p>(.*?)</p>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if NbE4qnzmPKGWtjYpoRL3HTS1A and hNCJPTucIV7GOSR0HytZ6eQrqEUpw(cTJphS1nFz5EUgNWm86C,url,NbE4qnzmPKGWtjYpoRL3HTS1A,True): return
	dR2vHyAtl8pJN1 = url.replace('/watch.php','/play.php')
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',dR2vHyAtl8pJN1,'','','','','CIMALIGHT-PLAY-2nd')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	KKpoiJXPIxzcrk = []
	ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall('"embedURL" href="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if ELbNB92cOh5dqtpVmi40kY:
		ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY[0]
		if ELbNB92cOh5dqtpVmi40kY and ELbNB92cOh5dqtpVmi40kY not in KKpoiJXPIxzcrk:
			KKpoiJXPIxzcrk.append(ELbNB92cOh5dqtpVmi40kY)
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named=__embed'
			if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = 'http:'+ELbNB92cOh5dqtpVmi40kY
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	items = GGvHJKP9LUxEk10Fw.findall("<iframe src='(.*?)'.*?<strong>(.*?)</strong>",BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		if ELbNB92cOh5dqtpVmi40kY not in KKpoiJXPIxzcrk:
			KKpoiJXPIxzcrk.append(ELbNB92cOh5dqtpVmi40kY)
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named='+title+'__watch'
			if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = 'http:'+ELbNB92cOh5dqtpVmi40kY
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	dR2vHyAtl8pJN1 = url.replace('/watch.php','/downloads.php')
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',dR2vHyAtl8pJN1,'','','','','CIMALIGHT-PLAY-3rd')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"downloadlist"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?<strong>(.*?)</strong>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			if ELbNB92cOh5dqtpVmi40kY not in KKpoiJXPIxzcrk:
				KKpoiJXPIxzcrk.append(ELbNB92cOh5dqtpVmi40kY)
				ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named='+title+'__download'
				if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = 'http:'+ELbNB92cOh5dqtpVmi40kY
				zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(zzvBg3ShiamAZ,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	search = search.replace(' ','+')
	C83UXWf15zdwLA0 = RfKuIXwPAiWtmyF(NBm2aWhPzoTpdYn,'url')
	url = C83UXWf15zdwLA0+'/search.php?keywords='+search
	xoiXMWjJC3pnQqurIGPkRSl8e(url,'search')
	return
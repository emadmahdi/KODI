# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'RANDOMS'
mmDwMlfoHtG5XT19VLIWqCR8i = '_LST_'
hTK5Zv39VBMOb = 4
XaNEiZ6GslU2R = 10
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(VRnfEFmJzUrSljM8,url,MMupPCxqkenwt6FlsbRILV37EAmB,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,LGdFZQvKeU52s6H0DgjN):
	try: xwaMIT0Kr5nmt6DsHlF2C9qV7p = str(LGdFZQvKeU52s6H0DgjN['folder'])
	except: xwaMIT0Kr5nmt6DsHlF2C9qV7p = ''
	if   VRnfEFmJzUrSljM8==160: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif VRnfEFmJzUrSljM8==161: zpXG3Ky6ou8ndWHkb4 = KKDmEAJlqvUHtewfdGBiTyukbFX(MMupPCxqkenwt6FlsbRILV37EAmB)
	elif VRnfEFmJzUrSljM8==162: zpXG3Ky6ou8ndWHkb4 = PbrlWTGNCd5Vj8EnAhzO96Km0H(MMupPCxqkenwt6FlsbRILV37EAmB,162)
	elif VRnfEFmJzUrSljM8==163: zpXG3Ky6ou8ndWHkb4 = PbrlWTGNCd5Vj8EnAhzO96Km0H(MMupPCxqkenwt6FlsbRILV37EAmB,163)
	elif VRnfEFmJzUrSljM8==164: zpXG3Ky6ou8ndWHkb4 = p1iEZd3aJnCmkvMyX5tDRKOUY7eA(MMupPCxqkenwt6FlsbRILV37EAmB)
	elif VRnfEFmJzUrSljM8==165: zpXG3Ky6ou8ndWHkb4 = NxWEduQh69Mzr5OKS3cC(url,MMupPCxqkenwt6FlsbRILV37EAmB)
	elif VRnfEFmJzUrSljM8==166: zpXG3Ky6ou8ndWHkb4 = mJTFgBfPUhDL0KdV8OuWZeEQ1RisYx(url,MMupPCxqkenwt6FlsbRILV37EAmB)
	elif VRnfEFmJzUrSljM8==167: zpXG3Ky6ou8ndWHkb4 = zQNSyVFOu4R7Wnq0(url,MMupPCxqkenwt6FlsbRILV37EAmB)
	elif VRnfEFmJzUrSljM8==168: zpXG3Ky6ou8ndWHkb4 = uwnrG7chj32HY8eTRyZFaKEzvqdQ6M(url,MMupPCxqkenwt6FlsbRILV37EAmB)
	elif VRnfEFmJzUrSljM8==761: zpXG3Ky6ou8ndWHkb4 = pDrAagycMni2zTs9EbV4hlvfO()
	elif VRnfEFmJzUrSljM8==762: zpXG3Ky6ou8ndWHkb4 = rNcgYWDodBuFKxefMG()
	elif VRnfEFmJzUrSljM8==763: zpXG3Ky6ou8ndWHkb4 = mLwj8KTUh4FDr3Bf(xwaMIT0Kr5nmt6DsHlF2C9qV7p,MMupPCxqkenwt6FlsbRILV37EAmB,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif VRnfEFmJzUrSljM8==764: zpXG3Ky6ou8ndWHkb4 = fY1HR62d3Nn4b0VksIO(xwaMIT0Kr5nmt6DsHlF2C9qV7p,MMupPCxqkenwt6FlsbRILV37EAmB)
	elif VRnfEFmJzUrSljM8==765: zpXG3Ky6ou8ndWHkb4 = b0cYlDhq7Us3Fk9CHKVxdtmA68u(xwaMIT0Kr5nmt6DsHlF2C9qV7p,MMupPCxqkenwt6FlsbRILV37EAmB)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	cd0aGwCPExbFU5pYNu8r('folder','قنوات تلفزيون عشوائية','',161,'','','_LIVETV__RANDOM__REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder','قسم عشوائي','',162,'','','_SITES__REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder','فيديوهات عشوائية','',163,'','','_SITES__RANDOM__REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder','فيديوهات بحث عشوائي','',164,'','','_SITES__RANDOM__REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder','فيديوهات عشوائية من قسم','',763,'','','_SITES__RANDOM_')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder','قنوات M3U عشوائية','',163,'','','_M3U__LIVE__RANDOM__REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder','فيديوهات M3U عشوائية','',163,'','','_M3U__VOD__RANDOM__REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder','قسم قنوات M3U عشوائي','',162,'','','_M3U__LIVE__REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder','قسم فيديو M3U عشوائي','',162,'','','_M3U__VOD__REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder','فيديوهات M3U بحث عشوائي','',164,'','','_M3U__RANDOM__REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder','فيديوهات M3U عشوائية من قسم','',765,'','','_M3U__RANDOM__REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder','قنوات IPTV عشوائية','',163,'','','_IPTV__LIVE__RANDOM__REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder','فيديوهات IPTV عشوائية','',163,'','','_IPTV__VOD__RANDOM__REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder','قسم قنوات IPTV عشوائي','',162,'','','_IPTV__LIVE__REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder','قسم فيديو IPTV عشوائي','',162,'','','_IPTV__VOD__REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder','فيديوهات IPTV بحث عشوائي','',164,'','','_IPTV__RANDOM__REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder','فيديوهات IPTV عشوائية من قسم','',764,'','','_IPTV__RANDOM__REMEMBERRESULTS_')
	return
def pDrAagycMni2zTs9EbV4hlvfO():
	cd0aGwCPExbFU5pYNu8r('folder','_IPT_'+'فيديوهات جميع IPTV','',764)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for xwaMIT0Kr5nmt6DsHlF2C9qV7p in range(1,pyq71xCY26s8hNQ+1):
		mmDwMlfoHtG5XT19VLIWqCR8i = '_IP'+str(xwaMIT0Kr5nmt6DsHlF2C9qV7p)+'_'
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+' فيديوهات مجلد '+Ri7qe1L6bhlGz3cyst4KSj[xwaMIT0Kr5nmt6DsHlF2C9qV7p],'',764,'','','','',{'folder':xwaMIT0Kr5nmt6DsHlF2C9qV7p})
	return
def rNcgYWDodBuFKxefMG():
	cd0aGwCPExbFU5pYNu8r('folder','_M3U_'+'فيديوهات جميع M3U','',765)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for xwaMIT0Kr5nmt6DsHlF2C9qV7p in range(1,pyq71xCY26s8hNQ+1):
		mmDwMlfoHtG5XT19VLIWqCR8i = '_MU'+str(xwaMIT0Kr5nmt6DsHlF2C9qV7p)+'_'
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+' فيديوهات مجلد '+Ri7qe1L6bhlGz3cyst4KSj[xwaMIT0Kr5nmt6DsHlF2C9qV7p],'',765,'','','','',{'folder':xwaMIT0Kr5nmt6DsHlF2C9qV7p})
	return
def MTViB7ENjFPfeWIK6(jXPWwl4aH0OR9ILzMT5usS):
	global TyJf9QN1Xk,tJ86rT42s0m5UC7LVEghvkOoAw
	YOb4ZFenMS08DN6yA3G5,ceL6qDxhFNo7,kUJng2Gx1u7br9Hs8MlFd = pdLiwcEWN2o4PQ(jXPWwl4aH0OR9ILzMT5usS)
	try:
		if 'IFILM' in jXPWwl4aH0OR9ILzMT5usS: YOb4ZFenMS08DN6yA3G5(jXPWwl4aH0OR9ILzMT5usS)
		else: YOb4ZFenMS08DN6yA3G5()
		JeF0toq1NYEIhw358b74iuCZcj = False
	except:
		XxluY9ohL0Ri3paB()
		JeF0toq1NYEIhw358b74iuCZcj = True
	jXPWwl4aH0OR9ILzMT5usS = wPGkbaD7x6(jXPWwl4aH0OR9ILzMT5usS)
	if JeF0toq1NYEIhw358b74iuCZcj:
		From8aTqdhCbPs(jXPWwl4aH0OR9ILzMT5usS,'فشل للأسف',MQbODJoPV2w8TEAg4zXZdjLxSW=2000)
		TyJf9QN1Xk += 1
		tJ86rT42s0m5UC7LVEghvkOoAw += ' '+jXPWwl4aH0OR9ILzMT5usS
	else: From8aTqdhCbPs(jXPWwl4aH0OR9ILzMT5usS,'',MQbODJoPV2w8TEAg4zXZdjLxSW=1000)
	return
def A2uZXtY3iR(Bi5GHjvnm39UA7wcTtDhSYryM=True):
	global TyJf9QN1Xk,tJ86rT42s0m5UC7LVEghvkOoAw
	if not Bi5GHjvnm39UA7wcTtDhSYryM:
		global InAzqY0hV5WkRsfgTmpoXQL4uCN
		zpXG3Ky6ou8ndWHkb4 = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,'dict','SECTIONS_SITES','SECTIONS_SITES_ALL')
		if zpXG3Ky6ou8ndWHkb4:
			InAzqY0hV5WkRsfgTmpoXQL4uCN = zpXG3Ky6ou8ndWHkb4
			return
	o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1('center','','','رسالة من المبرمج','لكي تملئ هذه القائمة . البرنامج يحتاج أن يفحص جميع مواقع الفيديو التي في البرنامج لكي يستخرج منها فقط الأقسام الرئيسية . ثم يقوم البرنامج بخزن هذه الأقسام حتى لا تحتاج أن تملئها مرة أخرى . عملية ملئ جميع الأقسام تحتاج عادة أقل من 3 دقائق . هل تريد أن تجمع قائمة الأقسام الآن ؟')
	if o07Z1tEB4n3ARCkVNu!=1: return
	LFmr6Jxpwe1OklbdUCnTBMAuaiq(False,False,False)
	aC6cHZ2kXYuymjLv0glfT = D6DrJsclfY
	TyJf9QN1Xk,tJ86rT42s0m5UC7LVEghvkOoAw,threads = 0,'',{}
	for jXPWwl4aH0OR9ILzMT5usS in X9JDEugQKfOZt5Ylc2m4b:
		MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(0.75)
		threads[jXPWwl4aH0OR9ILzMT5usS] = dM9DZS0pkxbqaf7W.Thread(target=MTViB7ENjFPfeWIK6,args=(jXPWwl4aH0OR9ILzMT5usS,))
		threads[jXPWwl4aH0OR9ILzMT5usS].start()
		if TyJf9QN1Xk>=XaNEiZ6GslU2R: break
	else:
		for jXPWwl4aH0OR9ILzMT5usS in list(threads.keys()):
			threads[jXPWwl4aH0OR9ILzMT5usS].join()
	D6DrJsclfY[:] = aC6cHZ2kXYuymjLv0glfT
	if TyJf9QN1Xk>=XaNEiZ6GslU2R: aHKzv76JCVnprbY8w('','','رسالة من المبرمج','لديك مشكلة في '+str(TyJf9QN1Xk)+' مواقع من مواقع البرنامج ... وسببها قد يكون عدم وجود إنترنيت في جهازك وهي:'+tJ86rT42s0m5UC7LVEghvkOoAw)
	else:
		Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,'SECTIONS_SITES','SECTIONS_SITES_ALL',InAzqY0hV5WkRsfgTmpoXQL4uCN,GOhVkMATsg4cJmfa0Enp6zSqCr)
		aHKzv76JCVnprbY8w('','','رسالة من المبرمج','تم جلب جميع الأقسام المتوفرة في البرنامج')
	LFmr6Jxpwe1OklbdUCnTBMAuaiq('','','')
	zrIWmJZh2CpVf8('Exit to apply new sections menus')
	return
def rpi9y7lI1OGVTHkE(xwaMIT0Kr5nmt6DsHlF2C9qV7p,cFghemYEoaiSN2Iw8kpyZ6ud5XO):
	nXl0o4fesWvCbZ = False
	lFzyGxNojBLa3IJsACTdUtrnu5c610 = D6DrJsclfY
	D6DrJsclfY[:] = []
	if nXl0o4fesWvCbZ and '_CREATENEW_' not in cFghemYEoaiSN2Iw8kpyZ6ud5XO:
		zpXG3Ky6ou8ndWHkb4 = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,'list','SECTIONS_IPTV','SECTIONS_IPTV_'+xwaMIT0Kr5nmt6DsHlF2C9qV7p)
	elif '_LIVE_' not in cFghemYEoaiSN2Iw8kpyZ6ud5XO or '_VOD_' not in cFghemYEoaiSN2Iw8kpyZ6ud5XO:
		import NYPKIqVcep
		LpdKxnIsY3Sy6qP = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in cFghemYEoaiSN2Iw8kpyZ6ud5XO:
			try: NYPKIqVcep.gLD9AntXhScRo1arYBsU42(xwaMIT0Kr5nmt6DsHlF2C9qV7p,'VOD_UNKNOWN_GROUPED_SORTED','','',cFghemYEoaiSN2Iw8kpyZ6ud5XO+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: aHKzv76JCVnprbY8w('','','موقع ـIPTV للفيديوهات',LpdKxnIsY3Sy6qP)
			try: NYPKIqVcep.gLD9AntXhScRo1arYBsU42(xwaMIT0Kr5nmt6DsHlF2C9qV7p,'VOD_MOVIES_GROUPED_SORTED','','',cFghemYEoaiSN2Iw8kpyZ6ud5XO+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: aHKzv76JCVnprbY8w('','','موقع ـIPTV للفيديوهات',LpdKxnIsY3Sy6qP)
			try: NYPKIqVcep.gLD9AntXhScRo1arYBsU42(xwaMIT0Kr5nmt6DsHlF2C9qV7p,'VOD_SERIES_GROUPED_SORTED','','',cFghemYEoaiSN2Iw8kpyZ6ud5XO+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: aHKzv76JCVnprbY8w('','','موقع ـIPTV للفيديوهات',LpdKxnIsY3Sy6qP)
		if '_VOD_' not in cFghemYEoaiSN2Iw8kpyZ6ud5XO:
			try: NYPKIqVcep.gLD9AntXhScRo1arYBsU42(xwaMIT0Kr5nmt6DsHlF2C9qV7p,'LIVE_UNKNOWN_GROUPED_SORTED','','',cFghemYEoaiSN2Iw8kpyZ6ud5XO+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: aHKzv76JCVnprbY8w('','','موقع ـIPTV للقنوات',LpdKxnIsY3Sy6qP)
			try: NYPKIqVcep.gLD9AntXhScRo1arYBsU42(xwaMIT0Kr5nmt6DsHlF2C9qV7p,'LIVE_GROUPED_SORTED','','',cFghemYEoaiSN2Iw8kpyZ6ud5XO+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: aHKzv76JCVnprbY8w('','','موقع ـIPTV للقنوات',LpdKxnIsY3Sy6qP)
		zpXG3Ky6ou8ndWHkb4 = D6DrJsclfY
		if nXl0o4fesWvCbZ: Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,'SECTIONS_IPTV','SECTIONS_IPTV_'+xwaMIT0Kr5nmt6DsHlF2C9qV7p,zpXG3Ky6ou8ndWHkb4,GOhVkMATsg4cJmfa0Enp6zSqCr)
	D6DrJsclfY[:] = lFzyGxNojBLa3IJsACTdUtrnu5c610
	return zpXG3Ky6ou8ndWHkb4
def siJbnrXwp6D5H92l81FdB0SvqW(xwaMIT0Kr5nmt6DsHlF2C9qV7p,cFghemYEoaiSN2Iw8kpyZ6ud5XO):
	nXl0o4fesWvCbZ = False
	lFzyGxNojBLa3IJsACTdUtrnu5c610 = D6DrJsclfY
	D6DrJsclfY[:] = []
	if nXl0o4fesWvCbZ and '_CREATENEW_' not in cFghemYEoaiSN2Iw8kpyZ6ud5XO:
		zpXG3Ky6ou8ndWHkb4 = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,'list','SECTIONS_M3U','SECTIONS_M3U_'+xwaMIT0Kr5nmt6DsHlF2C9qV7p)
	elif '_LIVE_' not in cFghemYEoaiSN2Iw8kpyZ6ud5XO or '_VOD_' not in cFghemYEoaiSN2Iw8kpyZ6ud5XO:
		import v8alOxSpJN
		LpdKxnIsY3Sy6qP = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in cFghemYEoaiSN2Iw8kpyZ6ud5XO:
			try: v8alOxSpJN.gLD9AntXhScRo1arYBsU42(xwaMIT0Kr5nmt6DsHlF2C9qV7p,'VOD_UNKNOWN_GROUPED_SORTED','','',cFghemYEoaiSN2Iw8kpyZ6ud5XO+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: aHKzv76JCVnprbY8w('','','موقع ـM3U للفيديوهات',LpdKxnIsY3Sy6qP)
			try: v8alOxSpJN.gLD9AntXhScRo1arYBsU42(xwaMIT0Kr5nmt6DsHlF2C9qV7p,'VOD_MOVIES_GROUPED_SORTED','','',cFghemYEoaiSN2Iw8kpyZ6ud5XO+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: aHKzv76JCVnprbY8w('','','موقع ـM3U للفيديوهات',LpdKxnIsY3Sy6qP)
			try: v8alOxSpJN.gLD9AntXhScRo1arYBsU42(xwaMIT0Kr5nmt6DsHlF2C9qV7p,'VOD_SERIES_GROUPED_SORTED','','',cFghemYEoaiSN2Iw8kpyZ6ud5XO+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: aHKzv76JCVnprbY8w('','','موقع ـM3U للفيديوهات',LpdKxnIsY3Sy6qP)
		if '_VOD_' not in cFghemYEoaiSN2Iw8kpyZ6ud5XO:
			try: v8alOxSpJN.gLD9AntXhScRo1arYBsU42(xwaMIT0Kr5nmt6DsHlF2C9qV7p,'LIVE_UNKNOWN_GROUPED_SORTED','','',cFghemYEoaiSN2Iw8kpyZ6ud5XO+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: aHKzv76JCVnprbY8w('','','موقع ـM3U للقنوات',LpdKxnIsY3Sy6qP)
			try: v8alOxSpJN.gLD9AntXhScRo1arYBsU42(xwaMIT0Kr5nmt6DsHlF2C9qV7p,'LIVE_GROUPED_SORTED','','',cFghemYEoaiSN2Iw8kpyZ6ud5XO+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: aHKzv76JCVnprbY8w('','','موقع ـM3U للقنوات',LpdKxnIsY3Sy6qP)
		zpXG3Ky6ou8ndWHkb4 = D6DrJsclfY
		if nXl0o4fesWvCbZ: Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,'SECTIONS_M3U','SECTIONS_M3U_'+xwaMIT0Kr5nmt6DsHlF2C9qV7p,zpXG3Ky6ou8ndWHkb4,GOhVkMATsg4cJmfa0Enp6zSqCr)
	D6DrJsclfY[:] = lFzyGxNojBLa3IJsACTdUtrnu5c610
	return zpXG3Ky6ou8ndWHkb4
def mLwj8KTUh4FDr3Bf(xwaMIT0Kr5nmt6DsHlF2C9qV7p,cFghemYEoaiSN2Iw8kpyZ6ud5XO,ENuhZwYGAixc1fnp):
	if '_CREATENEW_' in cFghemYEoaiSN2Iw8kpyZ6ud5XO and ENuhZwYGAixc1fnp=='': A2uZXtY3iR(True)
	elif ENuhZwYGAixc1fnp: A2uZXtY3iR(False)
	kyVJo4KDxjC2YdZgH3UzNcptLBE5s = cFghemYEoaiSN2Iw8kpyZ6ud5XO.replace('_CREATENEW_','').replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	if not ENuhZwYGAixc1fnp:
		cd0aGwCPExbFU5pYNu8r('link','تحديث هذه القائمة','',763,'','','_CREATENEW_'+kyVJo4KDxjC2YdZgH3UzNcptLBE5s,'',{'folder':xwaMIT0Kr5nmt6DsHlF2C9qV7p})
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VeIpTBA4KkFzJgRqGOE2Pb05Mx = ['أفلام','مسلسلات','مسرحيات','برامج','أطفال وكرتون','رمضان','أحدث-أخر','سلاسل','موسيقى','أشهر-أكثر','الآن','ضحك','رياضة','نيتفلكس','ممثلين','بث حي','دينية','سنوات','أخرى']
	A94n80WUxYRaouTqPpehkby = ['افلام','movie','فيلم','فلم']
	BBGXtqhb3wOAVj5YUosD0mL4 = ['مسلسل','series']
	TthzHKM6xdJ1ZW9uiSDUjVm = ['مسارح','مسرحيات']
	cUPYwbQTxrKWjJ4oX8aAtOmNR0 = ['برامج','show','تلفزيون','تليفزيون']
	TtDOrhJ5MfK0yCnjkLP = ['انمي','كرتون','كارتون','kids','طفل','اطفال']
	Khs4q5RTwn6eH = ['رمضان']
	CymTbuXdDhL = ['احدث','اخر','موخر','جديد','مضاف','حديث']
	BBMQcfkl5NVqSw4E = ['سلاسل','سلسله']
	ziBFh8dLA4jve0pWlgV1HE5 = ['اغاني','موسيقى','كليب','حفل','music']
	JaftLv58zYbRK2MAQZ = ['اكثر','اشهر','مميزه','اعلى','مختاره','مختارات','اقوى']
	WjEuNB7MDtC2ylk1ZUQwqXOAfY = ['الان','حالي','مثبت','رائج']
	gl0SzpYmiAKh = ['ضحك','كوميدي']
	MJFuVbphIOc9Ax4QaeSZT8mL = ['رياضه','كوره','مصارعه','شوت','رياضة']
	FafuNIX7Wrc3ZLHTnwC = ['نيتفلكس','netflix','نيتفليكس']
	ABrEx2hkSbP43vleszWDoXg90LumIY = ['ممثلين','اشخاص','نجوم']
	jvAw2XIh981zBbtonQELUFmfdyiJa = ['بث حي','live','قناه','قنوات']
	uCRb8jhHD0PLMNgtIr97 = ['دين','ادعيه','زيارات','لطميات','دعاء','قران','قصائد','رثاء','مرجعيه','اذان','اسلام','تواشيح','خطب','حوزوي','عتبات','مواليد','نواعي','عقائد','اناشيد']
	xhAcokQ3HUPaNTjYJB5gzWKu1qr = ['19','20','21','22','23','24','25','26']
	if not ENuhZwYGAixc1fnp:
		ENuhZwYGAixc1fnp = 0
		for bOrol2IGDMiCB64HUZ0vw75TmA in VeIpTBA4KkFzJgRqGOE2Pb05Mx:
			ENuhZwYGAixc1fnp += 1
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+bOrol2IGDMiCB64HUZ0vw75TmA,'',763,'',str(ENuhZwYGAixc1fnp),kyVJo4KDxjC2YdZgH3UzNcptLBE5s,'',{'folder':xwaMIT0Kr5nmt6DsHlF2C9qV7p})
	else:
		for WJr6B5imnN1Cypw in sorted(list(InAzqY0hV5WkRsfgTmpoXQL4uCN.keys())):
			RuWUKQylsNvOH7SpiL59nYP3rA = WJr6B5imnN1Cypw.lower()
			BBskpK6cGZJ = []
			if any(hieW1zRUG5w9AykJjv0X in RuWUKQylsNvOH7SpiL59nYP3rA for hieW1zRUG5w9AykJjv0X in A94n80WUxYRaouTqPpehkby): BBskpK6cGZJ.append(1)
			if any(hieW1zRUG5w9AykJjv0X in RuWUKQylsNvOH7SpiL59nYP3rA for hieW1zRUG5w9AykJjv0X in BBGXtqhb3wOAVj5YUosD0mL4): BBskpK6cGZJ.append(2)
			if any(hieW1zRUG5w9AykJjv0X in RuWUKQylsNvOH7SpiL59nYP3rA for hieW1zRUG5w9AykJjv0X in TthzHKM6xdJ1ZW9uiSDUjVm): BBskpK6cGZJ.append(3)
			if any(hieW1zRUG5w9AykJjv0X in RuWUKQylsNvOH7SpiL59nYP3rA for hieW1zRUG5w9AykJjv0X in cUPYwbQTxrKWjJ4oX8aAtOmNR0): BBskpK6cGZJ.append(4)
			if any(hieW1zRUG5w9AykJjv0X in RuWUKQylsNvOH7SpiL59nYP3rA for hieW1zRUG5w9AykJjv0X in TtDOrhJ5MfK0yCnjkLP): BBskpK6cGZJ.append(5)
			if any(hieW1zRUG5w9AykJjv0X in RuWUKQylsNvOH7SpiL59nYP3rA for hieW1zRUG5w9AykJjv0X in Khs4q5RTwn6eH): BBskpK6cGZJ.append(6)
			if any(hieW1zRUG5w9AykJjv0X in RuWUKQylsNvOH7SpiL59nYP3rA for hieW1zRUG5w9AykJjv0X in CymTbuXdDhL) and RuWUKQylsNvOH7SpiL59nYP3rA not in ['اخرى']: BBskpK6cGZJ.append(7)
			if any(hieW1zRUG5w9AykJjv0X in RuWUKQylsNvOH7SpiL59nYP3rA for hieW1zRUG5w9AykJjv0X in BBMQcfkl5NVqSw4E): BBskpK6cGZJ.append(8)
			if any(hieW1zRUG5w9AykJjv0X in RuWUKQylsNvOH7SpiL59nYP3rA for hieW1zRUG5w9AykJjv0X in ziBFh8dLA4jve0pWlgV1HE5): BBskpK6cGZJ.append(9)
			if any(hieW1zRUG5w9AykJjv0X in RuWUKQylsNvOH7SpiL59nYP3rA for hieW1zRUG5w9AykJjv0X in JaftLv58zYbRK2MAQZ): BBskpK6cGZJ.append(10)
			if any(hieW1zRUG5w9AykJjv0X in RuWUKQylsNvOH7SpiL59nYP3rA for hieW1zRUG5w9AykJjv0X in WjEuNB7MDtC2ylk1ZUQwqXOAfY): BBskpK6cGZJ.append(11)
			if any(hieW1zRUG5w9AykJjv0X in RuWUKQylsNvOH7SpiL59nYP3rA for hieW1zRUG5w9AykJjv0X in gl0SzpYmiAKh): BBskpK6cGZJ.append(12)
			if any(hieW1zRUG5w9AykJjv0X in RuWUKQylsNvOH7SpiL59nYP3rA for hieW1zRUG5w9AykJjv0X in MJFuVbphIOc9Ax4QaeSZT8mL): BBskpK6cGZJ.append(13)
			if any(hieW1zRUG5w9AykJjv0X in RuWUKQylsNvOH7SpiL59nYP3rA for hieW1zRUG5w9AykJjv0X in FafuNIX7Wrc3ZLHTnwC): BBskpK6cGZJ.append(14)
			if any(hieW1zRUG5w9AykJjv0X in RuWUKQylsNvOH7SpiL59nYP3rA for hieW1zRUG5w9AykJjv0X in ABrEx2hkSbP43vleszWDoXg90LumIY): BBskpK6cGZJ.append(15)
			if any(hieW1zRUG5w9AykJjv0X in RuWUKQylsNvOH7SpiL59nYP3rA for hieW1zRUG5w9AykJjv0X in jvAw2XIh981zBbtonQELUFmfdyiJa): BBskpK6cGZJ.append(16)
			if any(hieW1zRUG5w9AykJjv0X in RuWUKQylsNvOH7SpiL59nYP3rA for hieW1zRUG5w9AykJjv0X in uCRb8jhHD0PLMNgtIr97): BBskpK6cGZJ.append(17)
			if any(hieW1zRUG5w9AykJjv0X in RuWUKQylsNvOH7SpiL59nYP3rA for hieW1zRUG5w9AykJjv0X in xhAcokQ3HUPaNTjYJB5gzWKu1qr): BBskpK6cGZJ.append(18)
			if not BBskpK6cGZJ: BBskpK6cGZJ = [19]
			for LYJbXq4C9mgjWieMunoPd in BBskpK6cGZJ:
				if str(LYJbXq4C9mgjWieMunoPd)==ENuhZwYGAixc1fnp:
					cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+WJr6B5imnN1Cypw,WJr6B5imnN1Cypw,166,'','',kyVJo4KDxjC2YdZgH3UzNcptLBE5s+'_REMEMBERRESULTS_')
	return
def fY1HR62d3Nn4b0VksIO(xwaMIT0Kr5nmt6DsHlF2C9qV7p,cFghemYEoaiSN2Iw8kpyZ6ud5XO):
	nXl0o4fesWvCbZ = False
	if nXl0o4fesWvCbZ:
		cd0aGwCPExbFU5pYNu8r('link','تحديث هذه القائمة','',764,'','','_CREATENEW_','',{'folder':xwaMIT0Kr5nmt6DsHlF2C9qV7p})
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	lFzyGxNojBLa3IJsACTdUtrnu5c610 = D6DrJsclfY[:]
	import NYPKIqVcep
	if xwaMIT0Kr5nmt6DsHlF2C9qV7p:
		if not NYPKIqVcep.c5X1OvfJRaklF(xwaMIT0Kr5nmt6DsHlF2C9qV7p,True): return
		LkHv0uOhSYjMsPGiWtpg9A5 = rpi9y7lI1OGVTHkE(xwaMIT0Kr5nmt6DsHlF2C9qV7p,cFghemYEoaiSN2Iw8kpyZ6ud5XO)
		AzJSpsQ7kWrPeox2jOR5FK = sorted(LkHv0uOhSYjMsPGiWtpg9A5,reverse=False,key=lambda key: key[1].lower())
	else:
		if not NYPKIqVcep.c5X1OvfJRaklF('',True): return
		if nXl0o4fesWvCbZ and '_CREATENEW_' not in cFghemYEoaiSN2Iw8kpyZ6ud5XO:
			AzJSpsQ7kWrPeox2jOR5FK = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,'list','SECTIONS_IPTV','SECTIONS_IPTV_ALL')
		else:
			SEbvukaK9y0YlMOGPB,AzJSpsQ7kWrPeox2jOR5FK,LkHv0uOhSYjMsPGiWtpg9A5 = [],[],[]
			for UjLdhEkcuZ in range(1,pyq71xCY26s8hNQ+1):
				AzJSpsQ7kWrPeox2jOR5FK += rpi9y7lI1OGVTHkE(str(UjLdhEkcuZ),cFghemYEoaiSN2Iw8kpyZ6ud5XO)
			for type,WJr6B5imnN1Cypw,url,VRnfEFmJzUrSljM8,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,MMupPCxqkenwt6FlsbRILV37EAmB,stpvYViqku3,LGdFZQvKeU52s6H0DgjN in AzJSpsQ7kWrPeox2jOR5FK:
				if MMupPCxqkenwt6FlsbRILV37EAmB not in SEbvukaK9y0YlMOGPB:
					SEbvukaK9y0YlMOGPB.append(MMupPCxqkenwt6FlsbRILV37EAmB)
					P1gQ7xSTwkXItvABFfhn4YE56 = type,WJr6B5imnN1Cypw,MMupPCxqkenwt6FlsbRILV37EAmB,165,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,cFghemYEoaiSN2Iw8kpyZ6ud5XO,stpvYViqku3,LGdFZQvKeU52s6H0DgjN
					LkHv0uOhSYjMsPGiWtpg9A5.append(P1gQ7xSTwkXItvABFfhn4YE56)
			AzJSpsQ7kWrPeox2jOR5FK = sorted(LkHv0uOhSYjMsPGiWtpg9A5,reverse=False,key=lambda key: key[1].lower())
			if nXl0o4fesWvCbZ: Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,'SECTIONS_IPTV','SECTIONS_IPTV_ALL',AzJSpsQ7kWrPeox2jOR5FK,GOhVkMATsg4cJmfa0Enp6zSqCr)
	D6DrJsclfY[:] = lFzyGxNojBLa3IJsACTdUtrnu5c610+AzJSpsQ7kWrPeox2jOR5FK
	cEZpW924rqNYm5.executebuiltin('Container.Refresh')
	return
def b0cYlDhq7Us3Fk9CHKVxdtmA68u(xwaMIT0Kr5nmt6DsHlF2C9qV7p,cFghemYEoaiSN2Iw8kpyZ6ud5XO):
	nXl0o4fesWvCbZ = False
	if nXl0o4fesWvCbZ:
		cd0aGwCPExbFU5pYNu8r('link','تحديث هذه القائمة','',765,'','','_CREATENEW_','',{'folder':xwaMIT0Kr5nmt6DsHlF2C9qV7p})
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	lFzyGxNojBLa3IJsACTdUtrnu5c610 = D6DrJsclfY[:]
	import v8alOxSpJN
	if xwaMIT0Kr5nmt6DsHlF2C9qV7p:
		if not v8alOxSpJN.c5X1OvfJRaklF(xwaMIT0Kr5nmt6DsHlF2C9qV7p,True): return
		LkHv0uOhSYjMsPGiWtpg9A5 = siJbnrXwp6D5H92l81FdB0SvqW(xwaMIT0Kr5nmt6DsHlF2C9qV7p,cFghemYEoaiSN2Iw8kpyZ6ud5XO)
		AzJSpsQ7kWrPeox2jOR5FK = sorted(LkHv0uOhSYjMsPGiWtpg9A5,reverse=False,key=lambda key: key[1].lower())
	else:
		if not v8alOxSpJN.c5X1OvfJRaklF('',True): return
		if nXl0o4fesWvCbZ and '_CREATENEW_' not in cFghemYEoaiSN2Iw8kpyZ6ud5XO:
			AzJSpsQ7kWrPeox2jOR5FK = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,'list','SECTIONS_M3U','SECTIONS_M3U_ALL')
		else:
			SEbvukaK9y0YlMOGPB,AzJSpsQ7kWrPeox2jOR5FK,LkHv0uOhSYjMsPGiWtpg9A5 = [],[],[]
			for UjLdhEkcuZ in range(1,pyq71xCY26s8hNQ+1):
				AzJSpsQ7kWrPeox2jOR5FK += siJbnrXwp6D5H92l81FdB0SvqW(str(UjLdhEkcuZ),cFghemYEoaiSN2Iw8kpyZ6ud5XO)
			for type,WJr6B5imnN1Cypw,url,VRnfEFmJzUrSljM8,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,MMupPCxqkenwt6FlsbRILV37EAmB,stpvYViqku3,LGdFZQvKeU52s6H0DgjN in AzJSpsQ7kWrPeox2jOR5FK:
				if MMupPCxqkenwt6FlsbRILV37EAmB not in SEbvukaK9y0YlMOGPB:
					SEbvukaK9y0YlMOGPB.append(MMupPCxqkenwt6FlsbRILV37EAmB)
					P1gQ7xSTwkXItvABFfhn4YE56 = type,WJr6B5imnN1Cypw,MMupPCxqkenwt6FlsbRILV37EAmB,165,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,cFghemYEoaiSN2Iw8kpyZ6ud5XO,stpvYViqku3,LGdFZQvKeU52s6H0DgjN
					LkHv0uOhSYjMsPGiWtpg9A5.append(P1gQ7xSTwkXItvABFfhn4YE56)
			AzJSpsQ7kWrPeox2jOR5FK = sorted(LkHv0uOhSYjMsPGiWtpg9A5,reverse=False,key=lambda key: key[1].lower())
			if nXl0o4fesWvCbZ: Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,'SECTIONS_M3U','SECTIONS_M3U_ALL',AzJSpsQ7kWrPeox2jOR5FK,GOhVkMATsg4cJmfa0Enp6zSqCr)
	D6DrJsclfY[:] = lFzyGxNojBLa3IJsACTdUtrnu5c610+AzJSpsQ7kWrPeox2jOR5FK
	cEZpW924rqNYm5.executebuiltin('Container.Refresh')
	return
def NxWEduQh69Mzr5OKS3cC(group,cFghemYEoaiSN2Iw8kpyZ6ud5XO):
	nXl0o4fesWvCbZ = False
	zpXG3Ky6ou8ndWHkb4 = []
	zzPbOIU74Jua = '_IPTV_' if 'IPTV' in cFghemYEoaiSN2Iw8kpyZ6ud5XO else '_M3U_'
	if nXl0o4fesWvCbZ: zpXG3Ky6ou8ndWHkb4 = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,'list','SECTIONS'+zzPbOIU74Jua[:-1],group)
	if not zpXG3Ky6ou8ndWHkb4:
		for xwaMIT0Kr5nmt6DsHlF2C9qV7p in range(1,pyq71xCY26s8hNQ+1):
			if nXl0o4fesWvCbZ: zpXG3Ky6ou8ndWHkb4 += P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,'list','SECTIONS'+zzPbOIU74Jua[:-1],'SECTIONS'+zzPbOIU74Jua+str(xwaMIT0Kr5nmt6DsHlF2C9qV7p))
			elif zzPbOIU74Jua=='_IPTV_': zpXG3Ky6ou8ndWHkb4 += rpi9y7lI1OGVTHkE(str(xwaMIT0Kr5nmt6DsHlF2C9qV7p),'_CREATENEW_')
			elif zzPbOIU74Jua=='_M3U_': zpXG3Ky6ou8ndWHkb4 += siJbnrXwp6D5H92l81FdB0SvqW(str(xwaMIT0Kr5nmt6DsHlF2C9qV7p),'_CREATENEW_')
		for type,WJr6B5imnN1Cypw,url,VRnfEFmJzUrSljM8,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,MMupPCxqkenwt6FlsbRILV37EAmB,stpvYViqku3,LGdFZQvKeU52s6H0DgjN in zpXG3Ky6ou8ndWHkb4:
			if MMupPCxqkenwt6FlsbRILV37EAmB==group: keBlY04RjHEnpLPAbXaG(type,WJr6B5imnN1Cypw,url,VRnfEFmJzUrSljM8,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,MMupPCxqkenwt6FlsbRILV37EAmB,stpvYViqku3,LGdFZQvKeU52s6H0DgjN)
		items,GzpIUylJrXRteaKPiNDLHuScmbgj = [],[]
		for type,WJr6B5imnN1Cypw,url,VRnfEFmJzUrSljM8,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,MMupPCxqkenwt6FlsbRILV37EAmB,stpvYViqku3,LGdFZQvKeU52s6H0DgjN in D6DrJsclfY:
			R5TaSVneFZJbBCHKdhwYE0oy = type,WJr6B5imnN1Cypw[4:],url,VRnfEFmJzUrSljM8,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,MMupPCxqkenwt6FlsbRILV37EAmB,stpvYViqku3,''
			if R5TaSVneFZJbBCHKdhwYE0oy not in GzpIUylJrXRteaKPiNDLHuScmbgj:
				GzpIUylJrXRteaKPiNDLHuScmbgj.append(R5TaSVneFZJbBCHKdhwYE0oy)
				BrVNsC72UYWES4A = type,WJr6B5imnN1Cypw,url,VRnfEFmJzUrSljM8,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,MMupPCxqkenwt6FlsbRILV37EAmB,stpvYViqku3,LGdFZQvKeU52s6H0DgjN
				items.append(BrVNsC72UYWES4A)
		zpXG3Ky6ou8ndWHkb4 = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if nXl0o4fesWvCbZ: Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,'SECTIONS'+zzPbOIU74Jua[:-1],group,zpXG3Ky6ou8ndWHkb4,GOhVkMATsg4cJmfa0Enp6zSqCr)
	if '_RANDOM_' in cFghemYEoaiSN2Iw8kpyZ6ud5XO and len(zpXG3Ky6ou8ndWHkb4)>hTK5Zv39VBMOb:
		D6DrJsclfY[:] = []
		cd0aGwCPExbFU5pYNu8r('folder','[[COLOR FFC89008]'+group+'[/COLOR] :القسم]',group,165,'','',zzPbOIU74Jua+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		cd0aGwCPExbFU5pYNu8r('folder','إعادة الطلب العشوائي من نفس القسم',group,165,'','',zzPbOIU74Jua+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		zpXG3Ky6ou8ndWHkb4 = D6DrJsclfY+Y7pXj2OtNq9GZdvmcTkS3hMJn.sample(zpXG3Ky6ou8ndWHkb4,hTK5Zv39VBMOb)
	D6DrJsclfY[:] = zpXG3Ky6ou8ndWHkb4
	cEZpW924rqNYm5.executebuiltin('Container.Refresh')
	return
def KKDmEAJlqvUHtewfdGBiTyukbFX(cFghemYEoaiSN2Iw8kpyZ6ud5XO):
	cd0aGwCPExbFU5pYNu8r('folder','إعادة طلب قنوات عشوائية','',161,'','','_FORGETRESULTS__REMEMBERRESULTS__LIVETV__RANDOM_')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	zmicA8qsbX9kxwN = D6DrJsclfY[:]
	D6DrJsclfY[:] = []
	import yO89JhAsH3
	yO89JhAsH3.L4L0TUsN51taeljfc('0',False)
	yO89JhAsH3.L4L0TUsN51taeljfc('1',False)
	yO89JhAsH3.L4L0TUsN51taeljfc('2',False)
	if '_RANDOM_' in cFghemYEoaiSN2Iw8kpyZ6ud5XO:
		D6DrJsclfY[:] = gPU1rNet6y4wDunTJ8jsqQFbXBapMk(D6DrJsclfY)
		if len(D6DrJsclfY)>hTK5Zv39VBMOb: D6DrJsclfY[:] = Y7pXj2OtNq9GZdvmcTkS3hMJn.sample(D6DrJsclfY,hTK5Zv39VBMOb)
	D6DrJsclfY[:] = zmicA8qsbX9kxwN+D6DrJsclfY
	return
def p1iEZd3aJnCmkvMyX5tDRKOUY7eA(cFghemYEoaiSN2Iw8kpyZ6ud5XO):
	cFghemYEoaiSN2Iw8kpyZ6ud5XO = cFghemYEoaiSN2Iw8kpyZ6ud5XO.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	headers = { 'User-Agent' : '' }
	url = 'https://www.bestrandoms.com/random-arabic-words'
	data = {'quantity':'50'}
	data = Hym17NopzZUE3xhYMe(data)
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(X9mvsOYNPGeWdaIw01Mf4Jz5p,'GET',url,data,headers,'','','RANDOMS-RANDOM_VIDEOS_FROM_WORDS-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="content"(.*?)class="clearfix"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('<span>(.*?)</span>.*?<span>(.*?)</span>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	VC6lyLeDMKudEph,uMkSEKBJGRa69l = list(zip(*items))
	h2LfsZ3X5KEPdpTcF4ni1BRU = []
	VfzhbqO8XIvxUMplg7FkorJi = [' ','"','`',',','.',':',';',"'",'-']
	zntGr25ACw1h3YkO48qHP7 = uMkSEKBJGRa69l+VC6lyLeDMKudEph
	for XXPlKstzxr3a4 in zntGr25ACw1h3YkO48qHP7:
		if XXPlKstzxr3a4 in uMkSEKBJGRa69l: hhKsQyk39UlXfZp8zqRIwb0HW45m = 2
		if XXPlKstzxr3a4 in VC6lyLeDMKudEph: hhKsQyk39UlXfZp8zqRIwb0HW45m = 4
		BcF02MfqzsVGCojnS5vxrO = [umP72LtwzUTWHFAlJVyheEp5 in XXPlKstzxr3a4 for umP72LtwzUTWHFAlJVyheEp5 in VfzhbqO8XIvxUMplg7FkorJi]
		if any(BcF02MfqzsVGCojnS5vxrO):
			nlYKqpfrwVWLmig71o9BX = BcF02MfqzsVGCojnS5vxrO.index(True)
			b8gsPZMlUI7i32et46YSqCRB = VfzhbqO8XIvxUMplg7FkorJi[nlYKqpfrwVWLmig71o9BX]
			PPYv56GcmQjn1MyUli0K = ''
			if XXPlKstzxr3a4.count(b8gsPZMlUI7i32et46YSqCRB)>1: dy0xGHkJwzqYjOmNVIfpelS9,kHJVAvtX4Rh,PPYv56GcmQjn1MyUli0K = XXPlKstzxr3a4.split(b8gsPZMlUI7i32et46YSqCRB,2)
			else: dy0xGHkJwzqYjOmNVIfpelS9,kHJVAvtX4Rh = XXPlKstzxr3a4.split(b8gsPZMlUI7i32et46YSqCRB,1)
			if len(dy0xGHkJwzqYjOmNVIfpelS9)>hhKsQyk39UlXfZp8zqRIwb0HW45m: h2LfsZ3X5KEPdpTcF4ni1BRU.append(dy0xGHkJwzqYjOmNVIfpelS9.lower())
			if len(kHJVAvtX4Rh)>hhKsQyk39UlXfZp8zqRIwb0HW45m: h2LfsZ3X5KEPdpTcF4ni1BRU.append(kHJVAvtX4Rh.lower())
			if len(PPYv56GcmQjn1MyUli0K)>hhKsQyk39UlXfZp8zqRIwb0HW45m: h2LfsZ3X5KEPdpTcF4ni1BRU.append(PPYv56GcmQjn1MyUli0K.lower())
		elif len(XXPlKstzxr3a4)>hhKsQyk39UlXfZp8zqRIwb0HW45m: h2LfsZ3X5KEPdpTcF4ni1BRU.append(XXPlKstzxr3a4.lower())
	for umP72LtwzUTWHFAlJVyheEp5 in range(9): Y7pXj2OtNq9GZdvmcTkS3hMJn.shuffle(h2LfsZ3X5KEPdpTcF4ni1BRU)
	if '_SITES_' in cFghemYEoaiSN2Iw8kpyZ6ud5XO:
		k5vLu43WfbrTlOPi0HAYs17a = jjJZia6HOo2xFudTmtsyDVM5
	elif '_IPTV_' in cFghemYEoaiSN2Iw8kpyZ6ud5XO:
		k5vLu43WfbrTlOPi0HAYs17a = ['IPTV']
		import NYPKIqVcep
		if not NYPKIqVcep.c5X1OvfJRaklF('',True): return
	elif '_M3U_' in cFghemYEoaiSN2Iw8kpyZ6ud5XO:
		k5vLu43WfbrTlOPi0HAYs17a = ['M3U']
		import v8alOxSpJN
		if not v8alOxSpJN.c5X1OvfJRaklF('',True): return
	count,gId9w6hOJTkmB81Mzvi2r5VsZYR7 = 0,0
	cd0aGwCPExbFU5pYNu8r('folder','[  ] :البحث عن','',164,'','','_FORGETRESULTS__REMEMBERRESULTS_'+cFghemYEoaiSN2Iw8kpyZ6ud5XO)
	cd0aGwCPExbFU5pYNu8r('folder','إعادة البحث العشوائي','',164,'','','_FORGETRESULTS__REMEMBERRESULTS_'+cFghemYEoaiSN2Iw8kpyZ6ud5XO)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	gzRFBx3jZQmXSlcVOC472DuTpk1WI = D6DrJsclfY[:]
	D6DrJsclfY[:] = []
	mMQ8jhn3YGkxZseuipcrHWVBEI = []
	for XXPlKstzxr3a4 in h2LfsZ3X5KEPdpTcF4ni1BRU:
		kHJVAvtX4Rh = GGvHJKP9LUxEk10Fw.findall('[ \,\;\:\-\+\=\"\'\[\]\(\)\{\}\!\@'+'#'+'\$\%\^\&\*\_\<\>]',XXPlKstzxr3a4,GGvHJKP9LUxEk10Fw.DOTALL)
		if kHJVAvtX4Rh: XXPlKstzxr3a4 = XXPlKstzxr3a4.split(kHJVAvtX4Rh[0],1)[0]
		mjbpgiJ0NZo2BG9Lu = XXPlKstzxr3a4.replace('ّ','').replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
		mjbpgiJ0NZo2BG9Lu = mjbpgiJ0NZo2BG9Lu.replace('ِ','').replace('ٍ','').replace('ْ','').replace('،','').replace('ـ','')
		if mjbpgiJ0NZo2BG9Lu: mMQ8jhn3YGkxZseuipcrHWVBEI.append(mjbpgiJ0NZo2BG9Lu)
	D0wo1pYhtLI64H8sTyQreflnUO = []
	for CQMipytPbq in range(0,20):
		search = Y7pXj2OtNq9GZdvmcTkS3hMJn.sample(mMQ8jhn3YGkxZseuipcrHWVBEI,1)[0]
		if search in D0wo1pYhtLI64H8sTyQreflnUO: continue
		D0wo1pYhtLI64H8sTyQreflnUO.append(search)
		jXPWwl4aH0OR9ILzMT5usS = Y7pXj2OtNq9GZdvmcTkS3hMJn.sample(k5vLu43WfbrTlOPi0HAYs17a,1)[0]
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q('NOTICE',jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+'   Random Video Search   site:'+str(jXPWwl4aH0OR9ILzMT5usS)+'  search:'+search)
		YOb4ZFenMS08DN6yA3G5,ceL6qDxhFNo7,kUJng2Gx1u7br9Hs8MlFd = pdLiwcEWN2o4PQ(jXPWwl4aH0OR9ILzMT5usS)
		ceL6qDxhFNo7(search+'_NODIALOGS_')
		if len(D6DrJsclfY)>0: break
	search = search.replace('_MOD_','')
	gzRFBx3jZQmXSlcVOC472DuTpk1WI[0][1] = '[[COLOR FFC89008]'+search+'[/COLOR] :بحث عن]'
	D6DrJsclfY[:] = gPU1rNet6y4wDunTJ8jsqQFbXBapMk(D6DrJsclfY)
	if len(D6DrJsclfY)>hTK5Zv39VBMOb: D6DrJsclfY[:] = Y7pXj2OtNq9GZdvmcTkS3hMJn.sample(D6DrJsclfY,hTK5Zv39VBMOb)
	D6DrJsclfY[:] = gzRFBx3jZQmXSlcVOC472DuTpk1WI+D6DrJsclfY
	return
def mJTFgBfPUhDL0KdV8OuWZeEQ1RisYx(vfJ0BUOCt4xqDMp8X2LyQFh7IZ,cFghemYEoaiSN2Iw8kpyZ6ud5XO):
	vfJ0BUOCt4xqDMp8X2LyQFh7IZ = vfJ0BUOCt4xqDMp8X2LyQFh7IZ.replace('_MOD_','')
	cFghemYEoaiSN2Iw8kpyZ6ud5XO = cFghemYEoaiSN2Iw8kpyZ6ud5XO.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	A2uZXtY3iR(False)
	if InAzqY0hV5WkRsfgTmpoXQL4uCN=={}: return
	if '_RANDOM_' in cFghemYEoaiSN2Iw8kpyZ6ud5XO:
		cd0aGwCPExbFU5pYNu8r('folder','[[COLOR FFC89008]'+vfJ0BUOCt4xqDMp8X2LyQFh7IZ+'[/COLOR] :القسم]',vfJ0BUOCt4xqDMp8X2LyQFh7IZ,166,'','','_FORGETRESULTS__REMEMBERRESULTS_'+cFghemYEoaiSN2Iw8kpyZ6ud5XO)
		cd0aGwCPExbFU5pYNu8r('folder','إعادة الطلب العشوائي من نفس القسم',vfJ0BUOCt4xqDMp8X2LyQFh7IZ,166,'','','_FORGETRESULTS__REMEMBERRESULTS_'+cFghemYEoaiSN2Iw8kpyZ6ud5XO)
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for website in sorted(list(InAzqY0hV5WkRsfgTmpoXQL4uCN[vfJ0BUOCt4xqDMp8X2LyQFh7IZ].keys())):
		type,WJr6B5imnN1Cypw,url,XjUwdKaTHutRF0MgYkiWpZI,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,MMupPCxqkenwt6FlsbRILV37EAmB,stpvYViqku3,LGdFZQvKeU52s6H0DgjN = InAzqY0hV5WkRsfgTmpoXQL4uCN[vfJ0BUOCt4xqDMp8X2LyQFh7IZ][website]
		if '_RANDOM_' in cFghemYEoaiSN2Iw8kpyZ6ud5XO or len(InAzqY0hV5WkRsfgTmpoXQL4uCN[vfJ0BUOCt4xqDMp8X2LyQFh7IZ])==1:
			keBlY04RjHEnpLPAbXaG(type,'',url,XjUwdKaTHutRF0MgYkiWpZI,'',EfNzW3kLhcMTu07HrP28X9nFA6vpGd,MMupPCxqkenwt6FlsbRILV37EAmB,'','')
			D6DrJsclfY[:] = gPU1rNet6y4wDunTJ8jsqQFbXBapMk(D6DrJsclfY)
			lFzyGxNojBLa3IJsACTdUtrnu5c610,AzJSpsQ7kWrPeox2jOR5FK = D6DrJsclfY[:3],D6DrJsclfY[3:]
			for umP72LtwzUTWHFAlJVyheEp5 in range(9): Y7pXj2OtNq9GZdvmcTkS3hMJn.shuffle(AzJSpsQ7kWrPeox2jOR5FK)
			if '_RANDOM_' in cFghemYEoaiSN2Iw8kpyZ6ud5XO: D6DrJsclfY[:] = lFzyGxNojBLa3IJsACTdUtrnu5c610+AzJSpsQ7kWrPeox2jOR5FK[:hTK5Zv39VBMOb]
			else: D6DrJsclfY[:] = lFzyGxNojBLa3IJsACTdUtrnu5c610+AzJSpsQ7kWrPeox2jOR5FK
		elif '_SITES_' in cFghemYEoaiSN2Iw8kpyZ6ud5XO: cd0aGwCPExbFU5pYNu8r('folder',website,url,XjUwdKaTHutRF0MgYkiWpZI,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,MMupPCxqkenwt6FlsbRILV37EAmB,stpvYViqku3,LGdFZQvKeU52s6H0DgjN)
	return
def PbrlWTGNCd5Vj8EnAhzO96Km0H(cFghemYEoaiSN2Iw8kpyZ6ud5XO,VRnfEFmJzUrSljM8):
	cFghemYEoaiSN2Iw8kpyZ6ud5XO = cFghemYEoaiSN2Iw8kpyZ6ud5XO.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	WJr6B5imnN1Cypw,Q51kHpn0UY4 = '',[]
	cd0aGwCPExbFU5pYNu8r('folder','[[COLOR FFC89008]'+WJr6B5imnN1Cypw+'[/COLOR] :القسم]','',VRnfEFmJzUrSljM8,'','','_FORGETRESULTS__REMEMBERRESULTS_'+cFghemYEoaiSN2Iw8kpyZ6ud5XO)
	cd0aGwCPExbFU5pYNu8r('folder','إعادة طلب قسم عشوائي','',VRnfEFmJzUrSljM8,'','','_FORGETRESULTS__REMEMBERRESULTS_'+cFghemYEoaiSN2Iw8kpyZ6ud5XO)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	lFzyGxNojBLa3IJsACTdUtrnu5c610 = D6DrJsclfY[:]
	D6DrJsclfY[:] = []
	zpXG3Ky6ou8ndWHkb4 = []
	if '_SITES_' in cFghemYEoaiSN2Iw8kpyZ6ud5XO:
		A2uZXtY3iR(False)
		if InAzqY0hV5WkRsfgTmpoXQL4uCN=={}: return
		Nr4CuBpaHm6FJh = list(InAzqY0hV5WkRsfgTmpoXQL4uCN.keys())
		vfJ0BUOCt4xqDMp8X2LyQFh7IZ = Y7pXj2OtNq9GZdvmcTkS3hMJn.sample(Nr4CuBpaHm6FJh,1)[0]
		h2LfsZ3X5KEPdpTcF4ni1BRU = list(InAzqY0hV5WkRsfgTmpoXQL4uCN[vfJ0BUOCt4xqDMp8X2LyQFh7IZ].keys())
		website = Y7pXj2OtNq9GZdvmcTkS3hMJn.sample(h2LfsZ3X5KEPdpTcF4ni1BRU,1)[0]
		type,WJr6B5imnN1Cypw,url,XjUwdKaTHutRF0MgYkiWpZI,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,MMupPCxqkenwt6FlsbRILV37EAmB,stpvYViqku3,LGdFZQvKeU52s6H0DgjN = InAzqY0hV5WkRsfgTmpoXQL4uCN[vfJ0BUOCt4xqDMp8X2LyQFh7IZ][website]
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q('NOTICE',jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+'   Random Category   website: '+website+'   name: '+WJr6B5imnN1Cypw+'   url: '+url+'   mode: '+str(XjUwdKaTHutRF0MgYkiWpZI))
	elif '_IPTV_' in cFghemYEoaiSN2Iw8kpyZ6ud5XO:
		import NYPKIqVcep
		if not NYPKIqVcep.c5X1OvfJRaklF('',True): return
		for xwaMIT0Kr5nmt6DsHlF2C9qV7p in range(1,pyq71xCY26s8hNQ+1):
			zpXG3Ky6ou8ndWHkb4 += rpi9y7lI1OGVTHkE(str(xwaMIT0Kr5nmt6DsHlF2C9qV7p),cFghemYEoaiSN2Iw8kpyZ6ud5XO)
		if not zpXG3Ky6ou8ndWHkb4: return
		type,WJr6B5imnN1Cypw,url,XjUwdKaTHutRF0MgYkiWpZI,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,MMupPCxqkenwt6FlsbRILV37EAmB,stpvYViqku3,LGdFZQvKeU52s6H0DgjN = Y7pXj2OtNq9GZdvmcTkS3hMJn.sample(zpXG3Ky6ou8ndWHkb4,1)[0]
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q('NOTICE',jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+'   Random Category   name: '+WJr6B5imnN1Cypw+'   url: '+url+'   mode: '+str(XjUwdKaTHutRF0MgYkiWpZI))
	elif '_M3U_' in cFghemYEoaiSN2Iw8kpyZ6ud5XO:
		import v8alOxSpJN
		if not v8alOxSpJN.c5X1OvfJRaklF('',True): return
		for xwaMIT0Kr5nmt6DsHlF2C9qV7p in range(1,pyq71xCY26s8hNQ+1):
			zpXG3Ky6ou8ndWHkb4 += siJbnrXwp6D5H92l81FdB0SvqW(str(xwaMIT0Kr5nmt6DsHlF2C9qV7p),cFghemYEoaiSN2Iw8kpyZ6ud5XO)
		if not zpXG3Ky6ou8ndWHkb4: return
		type,WJr6B5imnN1Cypw,url,XjUwdKaTHutRF0MgYkiWpZI,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,MMupPCxqkenwt6FlsbRILV37EAmB,stpvYViqku3,LGdFZQvKeU52s6H0DgjN = Y7pXj2OtNq9GZdvmcTkS3hMJn.sample(zpXG3Ky6ou8ndWHkb4,1)[0]
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q('NOTICE',jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+'   Random Category   name: '+WJr6B5imnN1Cypw+'   url: '+url+'   mode: '+str(XjUwdKaTHutRF0MgYkiWpZI))
	CjMVd54QwAFtl6f83 = WJr6B5imnN1Cypw
	KK8yhLXzkIumAqbQwNZWYoS = []
	for umP72LtwzUTWHFAlJVyheEp5 in range(0,10):
		if umP72LtwzUTWHFAlJVyheEp5>0: LOHZ4o9m7p6ebfTYXGIdz5PWs3q('NOTICE',jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+'   Random Category   name: '+WJr6B5imnN1Cypw+'   url: '+url+'   mode: '+str(XjUwdKaTHutRF0MgYkiWpZI))
		D6DrJsclfY[:] = []
		if XjUwdKaTHutRF0MgYkiWpZI==234 and '__IPTVSeries__' in MMupPCxqkenwt6FlsbRILV37EAmB: XjUwdKaTHutRF0MgYkiWpZI = 233
		if XjUwdKaTHutRF0MgYkiWpZI==714 and '__M3USeries__' in MMupPCxqkenwt6FlsbRILV37EAmB: XjUwdKaTHutRF0MgYkiWpZI = 713
		if XjUwdKaTHutRF0MgYkiWpZI==144: XjUwdKaTHutRF0MgYkiWpZI = 291
		X4XyOPCEu65AMYebxwaVW = keBlY04RjHEnpLPAbXaG(type,WJr6B5imnN1Cypw,url,XjUwdKaTHutRF0MgYkiWpZI,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,MMupPCxqkenwt6FlsbRILV37EAmB,stpvYViqku3,LGdFZQvKeU52s6H0DgjN)
		if '_IPTV_' in cFghemYEoaiSN2Iw8kpyZ6ud5XO and XjUwdKaTHutRF0MgYkiWpZI==167: del D6DrJsclfY[:3]
		if '_M3U_' in cFghemYEoaiSN2Iw8kpyZ6ud5XO and XjUwdKaTHutRF0MgYkiWpZI==168: del D6DrJsclfY[:3]
		Q51kHpn0UY4[:] = gPU1rNet6y4wDunTJ8jsqQFbXBapMk(D6DrJsclfY)
		if KK8yhLXzkIumAqbQwNZWYoS and FEaio7MR2CjTJ9ZLVQnhNewgpv(u'حلقة') in str(Q51kHpn0UY4) or FEaio7MR2CjTJ9ZLVQnhNewgpv(u'حلقه') in str(Q51kHpn0UY4):
			WJr6B5imnN1Cypw = CjMVd54QwAFtl6f83
			Q51kHpn0UY4[:] = KK8yhLXzkIumAqbQwNZWYoS
			break
		CjMVd54QwAFtl6f83 = WJr6B5imnN1Cypw
		KK8yhLXzkIumAqbQwNZWYoS = Q51kHpn0UY4
		if str(Q51kHpn0UY4).count('video')>0: break
		if str(Q51kHpn0UY4).count('live')>0: break
		if XjUwdKaTHutRF0MgYkiWpZI==233: break
		if XjUwdKaTHutRF0MgYkiWpZI==713: break
		if XjUwdKaTHutRF0MgYkiWpZI==291: break
		if Q51kHpn0UY4: type,WJr6B5imnN1Cypw,url,XjUwdKaTHutRF0MgYkiWpZI,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,MMupPCxqkenwt6FlsbRILV37EAmB,stpvYViqku3,LGdFZQvKeU52s6H0DgjN = Y7pXj2OtNq9GZdvmcTkS3hMJn.sample(Q51kHpn0UY4,1)[0]
	if not WJr6B5imnN1Cypw: WJr6B5imnN1Cypw = '....'
	elif WJr6B5imnN1Cypw.count('_')>1: WJr6B5imnN1Cypw = WJr6B5imnN1Cypw.split('_',2)[2]
	WJr6B5imnN1Cypw = WJr6B5imnN1Cypw.replace('UNKNOWN: ','')
	WJr6B5imnN1Cypw = WJr6B5imnN1Cypw.replace('_MOD_','')
	lFzyGxNojBLa3IJsACTdUtrnu5c610[0][1] = '[[COLOR FFC89008]'+WJr6B5imnN1Cypw+'[/COLOR] :القسم]'
	for umP72LtwzUTWHFAlJVyheEp5 in range(9): Y7pXj2OtNq9GZdvmcTkS3hMJn.shuffle(Q51kHpn0UY4)
	if '_RANDOM_' in cFghemYEoaiSN2Iw8kpyZ6ud5XO: D6DrJsclfY[:] = lFzyGxNojBLa3IJsACTdUtrnu5c610+Q51kHpn0UY4[:hTK5Zv39VBMOb]
	else: D6DrJsclfY[:] = lFzyGxNojBLa3IJsACTdUtrnu5c610+Q51kHpn0UY4
	return
def zQNSyVFOu4R7Wnq0(ybdEILxj8qPwMoe9t4FnhO,tbEaGULKM0BpZVxy4eF):
	tbEaGULKM0BpZVxy4eF = tbEaGULKM0BpZVxy4eF.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	Df0xBaT7HIki = tbEaGULKM0BpZVxy4eF
	if '__IPTVSeries__' in tbEaGULKM0BpZVxy4eF:
		Df0xBaT7HIki = tbEaGULKM0BpZVxy4eF.split('__IPTVSeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in ybdEILxj8qPwMoe9t4FnhO: type = ',VIDEOS: '
	elif 'LIVE' in ybdEILxj8qPwMoe9t4FnhO: type = ',LIVE: '
	cd0aGwCPExbFU5pYNu8r('folder','[[COLOR FFC89008]'+type+Df0xBaT7HIki+'[/COLOR] :القسم]',ybdEILxj8qPwMoe9t4FnhO,167,'','','_FORGETRESULTS__REMEMBERRESULTS_'+tbEaGULKM0BpZVxy4eF)
	cd0aGwCPExbFU5pYNu8r('folder','إعادة الطلب العشوائي من نفس القسم',ybdEILxj8qPwMoe9t4FnhO,167,'','','_FORGETRESULTS__REMEMBERRESULTS_'+tbEaGULKM0BpZVxy4eF)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	import NYPKIqVcep
	for xwaMIT0Kr5nmt6DsHlF2C9qV7p in range(1,pyq71xCY26s8hNQ+1):
		if '__IPTVSeries__' in tbEaGULKM0BpZVxy4eF: NYPKIqVcep.gLD9AntXhScRo1arYBsU42(str(xwaMIT0Kr5nmt6DsHlF2C9qV7p),ybdEILxj8qPwMoe9t4FnhO,tbEaGULKM0BpZVxy4eF,'',False)
		else: NYPKIqVcep.L4L0TUsN51taeljfc(str(xwaMIT0Kr5nmt6DsHlF2C9qV7p),ybdEILxj8qPwMoe9t4FnhO,tbEaGULKM0BpZVxy4eF,'',False)
	D6DrJsclfY[:] = gPU1rNet6y4wDunTJ8jsqQFbXBapMk(D6DrJsclfY)
	if len(D6DrJsclfY)>(hTK5Zv39VBMOb+3): D6DrJsclfY[:] = D6DrJsclfY[:3]+Y7pXj2OtNq9GZdvmcTkS3hMJn.sample(D6DrJsclfY[3:],hTK5Zv39VBMOb)
	return
def uwnrG7chj32HY8eTRyZFaKEzvqdQ6M(ybdEILxj8qPwMoe9t4FnhO,tbEaGULKM0BpZVxy4eF):
	tbEaGULKM0BpZVxy4eF = tbEaGULKM0BpZVxy4eF.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	Df0xBaT7HIki = tbEaGULKM0BpZVxy4eF
	if '__M3USeries__' in tbEaGULKM0BpZVxy4eF:
		Df0xBaT7HIki = tbEaGULKM0BpZVxy4eF.split('__M3USeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in ybdEILxj8qPwMoe9t4FnhO: type = ',VIDEOS: '
	elif 'LIVE' in ybdEILxj8qPwMoe9t4FnhO: type = ',LIVE: '
	cd0aGwCPExbFU5pYNu8r('folder','[[COLOR FFC89008]'+type+Df0xBaT7HIki+'[/COLOR] :القسم]',ybdEILxj8qPwMoe9t4FnhO,168,'','','_FORGETRESULTS__REMEMBERRESULTS_'+tbEaGULKM0BpZVxy4eF)
	cd0aGwCPExbFU5pYNu8r('folder','إعادة الطلب العشوائي من نفس القسم',ybdEILxj8qPwMoe9t4FnhO,168,'','','_FORGETRESULTS__REMEMBERRESULTS_'+tbEaGULKM0BpZVxy4eF)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	import v8alOxSpJN
	for xwaMIT0Kr5nmt6DsHlF2C9qV7p in range(1,pyq71xCY26s8hNQ+1):
		if '__M3USeries__' in tbEaGULKM0BpZVxy4eF: v8alOxSpJN.gLD9AntXhScRo1arYBsU42(str(xwaMIT0Kr5nmt6DsHlF2C9qV7p),ybdEILxj8qPwMoe9t4FnhO,tbEaGULKM0BpZVxy4eF,'',False)
		else: v8alOxSpJN.L4L0TUsN51taeljfc(str(xwaMIT0Kr5nmt6DsHlF2C9qV7p),ybdEILxj8qPwMoe9t4FnhO,tbEaGULKM0BpZVxy4eF,'',False)
	D6DrJsclfY[:] = gPU1rNet6y4wDunTJ8jsqQFbXBapMk(D6DrJsclfY)
	if len(D6DrJsclfY)>(hTK5Zv39VBMOb+3): D6DrJsclfY[:] = D6DrJsclfY[:3]+Y7pXj2OtNq9GZdvmcTkS3hMJn.sample(D6DrJsclfY[3:],hTK5Zv39VBMOb)
	return
def gPU1rNet6y4wDunTJ8jsqQFbXBapMk(D6DrJsclfY):
	Q51kHpn0UY4 = []
	for type,WJr6B5imnN1Cypw,url,VRnfEFmJzUrSljM8,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,MMupPCxqkenwt6FlsbRILV37EAmB,stpvYViqku3,LGdFZQvKeU52s6H0DgjN in D6DrJsclfY:
		if 'صفحة' in WJr6B5imnN1Cypw or 'صفحه' in WJr6B5imnN1Cypw or 'page' in WJr6B5imnN1Cypw.lower(): continue
		Q51kHpn0UY4.append([type,WJr6B5imnN1Cypw,url,VRnfEFmJzUrSljM8,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,MMupPCxqkenwt6FlsbRILV37EAmB,stpvYViqku3,LGdFZQvKeU52s6H0DgjN])
	return Q51kHpn0UY4
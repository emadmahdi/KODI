# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'ALKAWTHAR'
mmDwMlfoHtG5XT19VLIWqCR8i = '_KWT_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,text):
	if   mode==130: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==131: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url)
	elif mode==132: zpXG3Ky6ou8ndWHkb4 = mgAQC3oRrjWLbHcE16dTMaJ7phsXV(url)
	elif mode==133: zpXG3Ky6ou8ndWHkb4 = hWPvGlXZ5arzV7(url,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif mode==134: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==135: zpXG3Ky6ou8ndWHkb4 = jvAw2XIh981zBbtonQELUFmfdyiJa()
	elif mode==139: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text,url)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',139,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,NBm2aWhPzoTpdYn,'','',True,'ALKAWTHAR-MENU-1st')
	EeQqAGc0W5r6nlBbChwfZL=GGvHJKP9LUxEk10Fw.findall('dropdown-menu(.*?)dropdown-toggle',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[1]
	items=GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		if '/conductor' in ELbNB92cOh5dqtpVmi40kY: continue
		title = title.strip(' ')
		url = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
		if '/category/' in url: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,132)
		else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,131)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'المسلسلات',NBm2aWhPzoTpdYn+'/category/543',132,'','1')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'الأفلام',NBm2aWhPzoTpdYn+'/category/628',132,'','1')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'برامج الصغار والشباب',NBm2aWhPzoTpdYn+'/category/517',132,'','1')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'ابرز البرامج',NBm2aWhPzoTpdYn+'/category/1763',132,'','1')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'المحاضرات',NBm2aWhPzoTpdYn+'/category/943',132,'','1')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'عاشوراء',NBm2aWhPzoTpdYn+'/category/1353',132,'','1')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'البرامج الاجتماعية',NBm2aWhPzoTpdYn+'/category/501',132,'','1')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'البرامج الدينية',NBm2aWhPzoTpdYn+'/category/509',132,'','1')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'البرامج الوثائقية',NBm2aWhPzoTpdYn+'/category/553',132,'','1')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'البرامج السياسية',NBm2aWhPzoTpdYn+'/category/545',132,'','1')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'كتب',NBm2aWhPzoTpdYn+'/category/291',132,'','1')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'تعلم الفارسية',NBm2aWhPzoTpdYn+'/category/88',132,'','1')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'أرشيف البرامج',NBm2aWhPzoTpdYn+'/category/1279',132,'','1')
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(url):
	IVhsmg2JH895wFGT = ['/religious','/social','/political','/films','/series']
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,url,'','',True,'ALKAWTHAR-TITLES-1st')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('titlebar(.*?)titlebar',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	if any(hieW1zRUG5w9AykJjv0X in url for hieW1zRUG5w9AykJjv0X in IVhsmg2JH895wFGT):
		items = GGvHJKP9LUxEk10Fw.findall("src='(.*?)'.*?href='(.*?)'.*?>(.*?)<",UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for VFqpJjRySZvgi,ELbNB92cOh5dqtpVmi40kY,title in items:
			title = title.strip(' ')
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn + ELbNB92cOh5dqtpVmi40kY
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,133,VFqpJjRySZvgi,'1')
	elif '/docs' in url:
		items = GGvHJKP9LUxEk10Fw.findall("src='(.*?)'.*?<h2>(.*?)</h2>.*?href='(.*?)'",UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for VFqpJjRySZvgi,title,ELbNB92cOh5dqtpVmi40kY in items:
			title = title.strip(' ')
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn + ELbNB92cOh5dqtpVmi40kY
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,133,VFqpJjRySZvgi,'1')
	return
def mgAQC3oRrjWLbHcE16dTMaJ7phsXV(url):
	BBskpK6cGZJ = url.split('/')[-1]
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,url,'','',True,'ALKAWTHAR-CATEGORIES-1st')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('parentcat(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not EeQqAGc0W5r6nlBbChwfZL:
		hWPvGlXZ5arzV7(url,'1')
		return
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall("href='(.*?)'.*?>(.*?)<",UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		title = title.strip(' ')
		ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn + ELbNB92cOh5dqtpVmi40kY
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,132,'','1')
	return
def hWPvGlXZ5arzV7(url,EfNzW3kLhcMTu07HrP28X9nFA6vpGd):
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,url,'','',True,'ALKAWTHAR-EPISODES-1st')
	items = GGvHJKP9LUxEk10Fw.findall('totalpagecount=[\'"](.*?)[\'"]',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not items:
		url = GGvHJKP9LUxEk10Fw.findall('class="news-detail-body".*?href="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		url = url[0]
		title = '_MOD_' + 'ملف التشغيل'
		if url: cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,134)
		else: aHKzv76JCVnprbY8w('','','رسالة من المبرمج','لا يوجد حاليا ملفات فيديو في هذا الفرع')
		return
	FVsf0bzMXqec2ojtyH984BargnDmK = int(items[0])
	name = GGvHJKP9LUxEk10Fw.findall('main-title.*?</a> >(.*?)<',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if name: name = name[0].strip(' ')
	else: name = cEZpW924rqNYm5.getInfoLabel('ListItem.Label')
	if '/category/' in url or 'search?q=' in url:
		BBskpK6cGZJ = url.split('/')[-1]
		if EfNzW3kLhcMTu07HrP28X9nFA6vpGd=='': dR2vHyAtl8pJN1 = url
		else: dR2vHyAtl8pJN1 = NBm2aWhPzoTpdYn + '/category/' + BBskpK6cGZJ + '/' + EfNzW3kLhcMTu07HrP28X9nFA6vpGd
		X3in5vNhqwWEG2TafmVCrFbSYDxjoK = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,dR2vHyAtl8pJN1,'','',True,'ALKAWTHAR-EPISODES-2nd')
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('currentpagenumber(.*?)pagination',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('src="(.*?)".*?full(.*?)>.*?href="(.*?)".*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for VFqpJjRySZvgi,type,ELbNB92cOh5dqtpVmi40kY,title in items:
			if 'video' not in type: continue
			if 'مسلسل' in title and 'حلقة' not in title: continue
			title = title.replace('\r\n','')
			title = title.strip(' ')
			if 'مسلسل' in name and 'حلقة' in title and 'مسلسل' not in title:
				title = '_MOD_' + name + ' - ' + title
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn + ELbNB92cOh5dqtpVmi40kY
			if BBskpK6cGZJ=='628': cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,133,VFqpJjRySZvgi,'1')
			else: cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,134,VFqpJjRySZvgi)
	elif '/episode/' in url:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('playlist(.*?)col-md-12',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
			items = GGvHJKP9LUxEk10Fw.findall("video-track-text.*?loadVideo\('(.*?)','(.*?)'.*?>(.*?)<",UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
				title = title.strip(' ')
				cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,134,VFqpJjRySZvgi)
		elif '/category/628' in BBlXpmUyhFDwNtCVAHoE:
				title = '_MOD_' + 'ملف التشغيل'
				cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,134)
		else:
			items = GGvHJKP9LUxEk10Fw.findall('id="Categories.*?href=\'(.*?)\'',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
			BBskpK6cGZJ = items[0].split('/')[-1]
			url = NBm2aWhPzoTpdYn + '/category/' + BBskpK6cGZJ
			mgAQC3oRrjWLbHcE16dTMaJ7phsXV(url)
			return
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('pagination(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		d1cF62jfZMwJ4PVXIBUz = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in d1cF62jfZMwJ4PVXIBUz:
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.replace('&amp;','&')
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,133)
	return
def SUfe4unWoXBNFz90xqy(url):
	if '/news/' in url or '/episode/' in url:
		BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,url,'','',True,'ALKAWTHAR-PLAY-1st')
		items = GGvHJKP9LUxEk10Fw.findall("mobilevideopath.*?value='(.*?)'",BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if items: url = items[0]
	ICifW6hdKqxkAJ02XZgHysOwoV9Dc5(url,cTJphS1nFz5EUgNWm86C,'video')
	return
def jvAw2XIh981zBbtonQELUFmfdyiJa():
	url = NBm2aWhPzoTpdYn+'/live'
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,url,'','',True,'ALKAWTHAR-LIVE-1st')
	dR2vHyAtl8pJN1 = GGvHJKP9LUxEk10Fw.findall('live-container.*?src="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1[0]
	BBYvCiQGe8RdpyAagfS72mZclxb5 = {'Referer':NBm2aWhPzoTpdYn}
	QQTDOLdNUAzYbfl1vXrM8mB = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,'GET',dR2vHyAtl8pJN1,'',BBYvCiQGe8RdpyAagfS72mZclxb5,'',True,'ALKAWTHAR-LIVE-2nd')
	X3in5vNhqwWEG2TafmVCrFbSYDxjoK = QQTDOLdNUAzYbfl1vXrM8mB.content
	DI9PgKJNvLiuBpXyctMs2RklobGA = GGvHJKP9LUxEk10Fw.findall('csrf-token" content="(.*?)"',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
	DI9PgKJNvLiuBpXyctMs2RklobGA = DI9PgKJNvLiuBpXyctMs2RklobGA[0]
	O1RUEwaLxbyINmo5iJ6MAheqVn = RfKuIXwPAiWtmyF(dR2vHyAtl8pJN1,'url')
	XwyU6PQgprMI0 = GGvHJKP9LUxEk10Fw.findall("playUrl = '(.*?)'",X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
	XwyU6PQgprMI0 = O1RUEwaLxbyINmo5iJ6MAheqVn+XwyU6PQgprMI0[0]
	hTCIe9pGxs = {'X-CSRF-TOKEN':DI9PgKJNvLiuBpXyctMs2RklobGA}
	ye2NJVIc5j8 = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,'POST',XwyU6PQgprMI0,'',hTCIe9pGxs,False,True,'ALKAWTHAR-LIVE-3rd')
	llYw5dj9ZaD46OpU = ye2NJVIc5j8.content
	gmFNXM58sV6qH = GGvHJKP9LUxEk10Fw.findall('"(.*?)"',llYw5dj9ZaD46OpU,GGvHJKP9LUxEk10Fw.DOTALL)
	gmFNXM58sV6qH = gmFNXM58sV6qH[0].replace('\/','/')
	ICifW6hdKqxkAJ02XZgHysOwoV9Dc5(gmFNXM58sV6qH,cTJphS1nFz5EUgNWm86C,'live')
	return
def szwTAdaBt4FiXO(search,url=''):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if url=='':
		if search=='': search = yMRXZIpKxlSkaE6iCO()
		if search=='': return
		search = mGfdCk4Hyclg9RjD(search)
		url = NBm2aWhPzoTpdYn+'/search?q='+search
		hWPvGlXZ5arzV7(url,'')
		return
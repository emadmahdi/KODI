# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'EGYBEST3'
mmDwMlfoHtG5XT19VLIWqCR8i = '_EB3_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
DDXTwbRBaj3e2rSsPQ = ['المصارعة الحرة','ايجي بست','التصميم الجديد','عروض المصارعة','مكتبتي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست','موقع نتفليكس']
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,text):
	if   mode==790: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==791: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif mode==792: zpXG3Ky6ou8ndWHkb4 = i7pbAuodvX3(url)
	elif mode==793: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==796: zpXG3Ky6ou8ndWHkb4 = pFmAuvrtnqEijTeQ4MRaw(url,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif mode==799: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',NBm2aWhPzoTpdYn,'','','','','EGYBEST3-MENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('list-pages(.*?)fa-folder',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?<span>(.*?)</span>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			title = title.strip(' ')
			if any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in DDXTwbRBaj3e2rSsPQ): continue
			if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
			cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,791)
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('main-article(.*?)social-box',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('main-title.*?">(.*?)<.*?href="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for title,ELbNB92cOh5dqtpVmi40kY in items:
			title = title.strip(' ')
			if any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in DDXTwbRBaj3e2rSsPQ): continue
			if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
			cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,791,'','mainmenu')
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('main-menu(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			title = title.strip(' ')
			if any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in DDXTwbRBaj3e2rSsPQ): continue
			if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
			cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,791)
	return BBlXpmUyhFDwNtCVAHoE
def pFmAuvrtnqEijTeQ4MRaw(url,type=''):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','EGYBEST3-SEASONS_EPISODES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('main-article".*?">(.*?)<(.*?)article',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		tt0PDNvYRduaiJSh8,kxoVRpfCEMyW15BFQu4n7G2,items = '','',[]
		for name,UCEFMfKbgpd in EeQqAGc0W5r6nlBbChwfZL:
			if 'حلقات' in name: kxoVRpfCEMyW15BFQu4n7G2 = UCEFMfKbgpd
			if 'مواسم' in name: tt0PDNvYRduaiJSh8 = UCEFMfKbgpd
		if tt0PDNvYRduaiJSh8 and not type:
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',tt0PDNvYRduaiJSh8,GGvHJKP9LUxEk10Fw.DOTALL)
			if len(items)>1:
				for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
					cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,796,VFqpJjRySZvgi,'season')
		if kxoVRpfCEMyW15BFQu4n7G2 and len(items)<2:
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?data-src="(.*?)".*?class="title">(.*?)<',kxoVRpfCEMyW15BFQu4n7G2,GGvHJKP9LUxEk10Fw.DOTALL)
			if items:
				for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
					cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,793,VFqpJjRySZvgi)
			else:
				items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)<',kxoVRpfCEMyW15BFQu4n7G2,GGvHJKP9LUxEk10Fw.DOTALL)
				for ELbNB92cOh5dqtpVmi40kY,title in items:
					cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,793)
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(url,type=''):
	YliGQMEOWfHq8wcz,start,kMZsFyP9qdmj5KXlJLA8xNeCg3f,select,FwpuUBA6k9mI7CgiMH3fyNR = 0,0,'','',''
	if 'pagination' in type:
		EhqwLVFSdXaJc,data = xlk0nsAXjIrvOQFL4Vi1MJG5TChu(url)
		YliGQMEOWfHq8wcz = int(data['limit'])
		start = int(data['start'])
		kMZsFyP9qdmj5KXlJLA8xNeCg3f = data['type']
		select = data['select']
		Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = 'limit='+str(YliGQMEOWfHq8wcz)+'&start='+str(start)+'&type='+kMZsFyP9qdmj5KXlJLA8xNeCg3f+'&select='+select
		BBYvCiQGe8RdpyAagfS72mZclxb5 = {'Content-Type':'application/x-www-form-urlencoded'}
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'POST',EhqwLVFSdXaJc,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,'','','EGYBEST3-TITLES-1st')
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		X3in5vNhqwWEG2TafmVCrFbSYDxjoK = 'blocks'+BBlXpmUyhFDwNtCVAHoE+'article'
	else:
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','EGYBEST3-TITLES-2nd')
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		X3in5vNhqwWEG2TafmVCrFbSYDxjoK = BBlXpmUyhFDwNtCVAHoE
		code = GGvHJKP9LUxEk10Fw.findall("<script>(var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?);</script>",BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if code:
			code = code[0].replace('var','').replace(' ','').replace("'",'').replace(';','&')
			X4XyOPCEu65AMYebxwaVW,data = xlk0nsAXjIrvOQFL4Vi1MJG5TChu('?'+code)
			YliGQMEOWfHq8wcz = int(data['limit'])
			start = int(data['start'])
			kMZsFyP9qdmj5KXlJLA8xNeCg3f = data['type']
			select = data['select']
			FwpuUBA6k9mI7CgiMH3fyNR = data['ajaxurl']
			Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = 'limit='+str(YliGQMEOWfHq8wcz)+'&start='+str(start)+'&type='+kMZsFyP9qdmj5KXlJLA8xNeCg3f+'&select='+select
			EhqwLVFSdXaJc = NBm2aWhPzoTpdYn+FwpuUBA6k9mI7CgiMH3fyNR
			BBYvCiQGe8RdpyAagfS72mZclxb5 = {'Content-Type':'application/x-www-form-urlencoded'}
			WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'POST',EhqwLVFSdXaJc,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,'','','EGYBEST3-TITLES-3rd')
			X3in5vNhqwWEG2TafmVCrFbSYDxjoK = WbTGMHnDysdYZ2lFA.content
			X3in5vNhqwWEG2TafmVCrFbSYDxjoK = 'blocks'+X3in5vNhqwWEG2TafmVCrFbSYDxjoK+'article'
	items,ffOGheCcNowFKUZREBkMYp83H,FZj067Q2PlC8EsG9c5yiWpzNRq = [],False,False
	if not type:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('main-content(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?</i>(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				title = title.strip(' ')
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,791,'','submenu')
				ffOGheCcNowFKUZREBkMYp83H = True
	if not type:
		FZj067Q2PlC8EsG9c5yiWpzNRq = u5iGFOgPoB7n(BBlXpmUyhFDwNtCVAHoE)
	if not ffOGheCcNowFKUZREBkMYp83H and not FZj067Q2PlC8EsG9c5yiWpzNRq:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('blocks(.*?)article',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
				VFqpJjRySZvgi = VFqpJjRySZvgi.strip('\n')
				ELbNB92cOh5dqtpVmi40kY = GhPlajzTxY8(ELbNB92cOh5dqtpVmi40kY)
				if '/selary/' in ELbNB92cOh5dqtpVmi40kY: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,791,VFqpJjRySZvgi)
				elif 'مسلسل' in ELbNB92cOh5dqtpVmi40kY and 'حلقة' not in ELbNB92cOh5dqtpVmi40kY: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,796,VFqpJjRySZvgi)
				elif 'موسم' in ELbNB92cOh5dqtpVmi40kY and 'حلقة' not in ELbNB92cOh5dqtpVmi40kY: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,796,VFqpJjRySZvgi)
				else: cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,793,VFqpJjRySZvgi)
		MUSrJfcoWxYhyjO = 12
		data = GGvHJKP9LUxEk10Fw.findall('class="(load-more.*?)<',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if len(items)==MUSrJfcoWxYhyjO and (data or 'pagination' in type):
			Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = 'limit='+str(MUSrJfcoWxYhyjO)+'&start='+str(start+MUSrJfcoWxYhyjO)+'&type='+kMZsFyP9qdmj5KXlJLA8xNeCg3f+'&select='+select
			dR2vHyAtl8pJN1 = EhqwLVFSdXaJc+'?next=page&'+Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'المزيد',dR2vHyAtl8pJN1,791,'','pagination_'+type)
	return
def u5iGFOgPoB7n(BBlXpmUyhFDwNtCVAHoE):
	FZj067Q2PlC8EsG9c5yiWpzNRq = False
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('main-article(.*?)article',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		EHDeldN7L2k19JBUqhmsuSXiwV = GGvHJKP9LUxEk10Fw.findall('data-tax="(.*?)".*?<span>(.*?)<(.*?)</ul>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if EHDeldN7L2k19JBUqhmsuSXiwV: cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		for BBskpK6cGZJ,name,UCEFMfKbgpd in EHDeldN7L2k19JBUqhmsuSXiwV:
			name = name.strip(' ')
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,hieW1zRUG5w9AykJjv0X in items:
				title = name+':  '+hieW1zRUG5w9AykJjv0X
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,791,'','filter')
				FZj067Q2PlC8EsG9c5yiWpzNRq = True
	return FZj067Q2PlC8EsG9c5yiWpzNRq
def SUfe4unWoXBNFz90xqy(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,'GET',url,'','','','','EGYBEST3-PLAY-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	uuIjMn1YTf687WlRcOmhq4G23H,NBWQmkLbTzrcuEfKtp36 = [],[]
	items = GGvHJKP9LUxEk10Fw.findall('server-item.*?data-code="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	for SSN8hMxmKAO0JaYrXfTzceg1 in items:
		ePYbKE38ayDNh = hNe0ECZHr9B6.b64decode(SSN8hMxmKAO0JaYrXfTzceg1)
		if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: ePYbKE38ayDNh = ePYbKE38ayDNh.decode('utf8')
		ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall('src="(.*?)"',ePYbKE38ayDNh,GGvHJKP9LUxEk10Fw.DOTALL)
		if ELbNB92cOh5dqtpVmi40kY:
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY[0]
			if ELbNB92cOh5dqtpVmi40kY not in NBWQmkLbTzrcuEfKtp36:
				NBWQmkLbTzrcuEfKtp36.append(ELbNB92cOh5dqtpVmi40kY)
				C83UXWf15zdwLA0 = RfKuIXwPAiWtmyF(ELbNB92cOh5dqtpVmi40kY,'name')
				uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY+'?named='+C83UXWf15zdwLA0+'__watch')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="downloads(.*?)</section>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('"tr flex-start".*?<div>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</div>.*?href="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for dDZQSEGRTo9g85x1C,ELbNB92cOh5dqtpVmi40kY in items:
			if ELbNB92cOh5dqtpVmi40kY not in NBWQmkLbTzrcuEfKtp36:
				if '/?url=' in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.split('/?url=')[1]
				NBWQmkLbTzrcuEfKtp36.append(ELbNB92cOh5dqtpVmi40kY)
				C83UXWf15zdwLA0 = RfKuIXwPAiWtmyF(ELbNB92cOh5dqtpVmi40kY,'name')
				uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY+'?named='+C83UXWf15zdwLA0+'__download____'+dDZQSEGRTo9g85x1C)
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(uuIjMn1YTf687WlRcOmhq4G23H,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(text):
	return
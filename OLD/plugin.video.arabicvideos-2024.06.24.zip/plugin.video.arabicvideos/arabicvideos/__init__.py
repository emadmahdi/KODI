# -*- coding: utf-8 -*-
import sys as GGtWyVoJReUuEBCdAagiL1YXO8
ggqTOXpCEcQD68f3oxrKilaSvkdtN = GGtWyVoJReUuEBCdAagiL1YXO8.version_info [0] == 2
pQ14eMnbYBK0xGywR7SuFChJdONj6 = 2048
y65ArzSx9RZh = 7
def MUzuWiALbXp6w5 (TMw2a0zHkY9lcdIvLFZXrS):
	global ynv9hpqlRAJuN0gXrEscaoP5dMWYDO
	Icnd5Dq4krBK3iYg2xNZHF = ord (TMw2a0zHkY9lcdIvLFZXrS [-1])
	u05ustK47xXQZbyFerWTROY = TMw2a0zHkY9lcdIvLFZXrS [:-1]
	BXAu3ZJQ9IPLg7kiy4K06ha = Icnd5Dq4krBK3iYg2xNZHF % len (u05ustK47xXQZbyFerWTROY)
	nRXUw1Fg0DSrkYGL = u05ustK47xXQZbyFerWTROY [:BXAu3ZJQ9IPLg7kiy4K06ha] + u05ustK47xXQZbyFerWTROY [BXAu3ZJQ9IPLg7kiy4K06ha:]
	if ggqTOXpCEcQD68f3oxrKilaSvkdtN:
		sW7Qyn32Zidt5TE4w96 = unicode () .join ([unichr (ord (Lk9Jh0wu7aNAE) - pQ14eMnbYBK0xGywR7SuFChJdONj6 - (Ebxc6eiUkyVNfMBs3CRIOArQ4h + Icnd5Dq4krBK3iYg2xNZHF) % y65ArzSx9RZh) for Ebxc6eiUkyVNfMBs3CRIOArQ4h, Lk9Jh0wu7aNAE in enumerate (nRXUw1Fg0DSrkYGL)])
	else:
		sW7Qyn32Zidt5TE4w96 = str () .join ([chr (ord (Lk9Jh0wu7aNAE) - pQ14eMnbYBK0xGywR7SuFChJdONj6 - (Ebxc6eiUkyVNfMBs3CRIOArQ4h + Icnd5Dq4krBK3iYg2xNZHF) % y65ArzSx9RZh) for Ebxc6eiUkyVNfMBs3CRIOArQ4h, Lk9Jh0wu7aNAE in enumerate (nRXUw1Fg0DSrkYGL)])
	return eval (sW7Qyn32Zidt5TE4w96)
Cu1704YofAbr3QTm,oh5Ptv7RjM3qLk1eEZJbcVzKis4d,LiRcTVUWuth70DmPy=MUzuWiALbXp6w5,MUzuWiALbXp6w5,MUzuWiALbXp6w5
pq3Z6xaELn0NW7PgAeI1bCRwdu,UTelCo0ihE1d5R,Me28A1sBLNIgUp5YCDyvT=LiRcTVUWuth70DmPy,oh5Ptv7RjM3qLk1eEZJbcVzKis4d,Cu1704YofAbr3QTm
kEhAHvti6Vnsfx,g4g6bfkPtVGU5lIM3,E6MIKdpBomef=Me28A1sBLNIgUp5YCDyvT,UTelCo0ihE1d5R,pq3Z6xaELn0NW7PgAeI1bCRwdu
wRxoKs10Syj7V4edYhtP,yA5z6LIXBlo41PRVMY87wOisFp,iUeoLOsbHqP=E6MIKdpBomef,g4g6bfkPtVGU5lIM3,kEhAHvti6Vnsfx
iRoLg2m47tnDATBHGCSPNyx,xW2Arao7YVOemw,l30iT7pjzmXk8dvwSNyUR1aZO4tWh=iUeoLOsbHqP,yA5z6LIXBlo41PRVMY87wOisFp,wRxoKs10Syj7V4edYhtP
dshJSmRqeiP9nap2,FnBiAjthS8MkXs67W,FvNyZqaLKw=l30iT7pjzmXk8dvwSNyUR1aZO4tWh,xW2Arao7YVOemw,iRoLg2m47tnDATBHGCSPNyx
SO94xq1RAkMm2uF,bUdr5Hahw6sY8xJ,XzrqbGDIy54juixkMA=FvNyZqaLKw,FnBiAjthS8MkXs67W,dshJSmRqeiP9nap2
p72fnFtcPix5UKwr9YNzW,sTcr7iDp5eFt4RoLMhuwq1A,SyENPzdOon6uxcLXMhqb14aDlB9r=XzrqbGDIy54juixkMA,bUdr5Hahw6sY8xJ,SO94xq1RAkMm2uF
zqdvcbP5L8BHh,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF,lc0dpSmwoPDjLnk=SyENPzdOon6uxcLXMhqb14aDlB9r,sTcr7iDp5eFt4RoLMhuwq1A,p72fnFtcPix5UKwr9YNzW
QVZl0O8yUIzdGDTfYcn5H37uWmb2,hRNlWkwDitzVpbSO3TIdAm5YGjaZ,fprnld4CZo=lc0dpSmwoPDjLnk,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF,zqdvcbP5L8BHh
hBvsQ7oCkKUdwjx58ml3EN,G5DeRbUpFj8E9OtJLvlo2fWmZC,S4SOKF2QbBhjCd3RrVMuHIzE=fprnld4CZo,hRNlWkwDitzVpbSO3TIdAm5YGjaZ,QVZl0O8yUIzdGDTfYcn5H37uWmb2
from euYNPkoBDm import *
cTJphS1nFz5EUgNWm86C = dshJSmRqeiP9nap2(u"ࠬࡏࡎࡊࡖࠪᛡ")
LOHZ4o9m7p6ebfTYXGIdz5PWs3q(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ᛢ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠧᛣ"))
uI7UAQCyPO85aLonkGqrdWwRt,PPVuQkU9OfiBXegYZK2c3Tl6,mHejXxkvM1qCESPVRy54QB,xUmyzZKOd8hv3Jc5X2nPHCAarW4sF,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,fH8bDPV6AceuCFNO0Ert7oq3p,stpvYViqku3,LGdFZQvKeU52s6H0DgjN = z4sqGEoRxKVCSwc3nLZ(jI8KGT6dsgDQ)
dMiPQHejCTElLJuDz6oN5tR8Y = int(xUmyzZKOd8hv3Jc5X2nPHCAarW4sF)
ccIZBYDOGdJlTE81Li2wAmuKtk = cEZpW924rqNYm5.getInfoLabel(Cu1704YofAbr3QTm(u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡐࡦࡨࡥ࡭ࠩᛤ"))
ccIZBYDOGdJlTE81Li2wAmuKtk = ccIZBYDOGdJlTE81Li2wAmuKtk.replace(UUv3pbV4MsPa,G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩࠪᛥ")).replace(NQzGnR49rhjOA0qi7gu,l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࠫᛦ"))
if dMiPQHejCTElLJuDz6oN5tR8Y==E6MIKdpBomef(u"࠸࠶࠱᜚"): oCrTtRIykV4E9fuKnBGW = Cu1704YofAbr3QTm(u"ࠫࠥࠦࠠࡗࡧࡵࡷ࡮ࡵ࡮࠻ࠢ࡞ࠤࠬᛧ")+mmn0lB2tFI7XTgVfESo+yA5z6LIXBlo41PRVMY87wOisFp(u"ࠬࠦ࡝ࠡࠢࠣࡏࡴࡪࡩ࠻ࠢ࡞ࠤࠬᛨ")+cc3xyKurSgDZ9pHhLiFk2fjXbTnsN+lc0dpSmwoPDjLnk(u"࠭ࠠ࡞ࠩᛩ")
else:
	m4TMa1Xgis3Yq = GhPlajzTxY8(jI8KGT6dsgDQ).replace(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪᛪ"),Me28A1sBLNIgUp5YCDyvT(u"ࠨࠩ᛫")).replace(bUdr5Hahw6sY8xJ(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ᛬"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪࠫ᛭"))
	m4TMa1Xgis3Yq = m4TMa1Xgis3Yq.replace(bUdr5Hahw6sY8xJ(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᛮ"),FnBiAjthS8MkXs67W(u"ࠬ࠭ᛯ")).strip(SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࠠࠨᛰ"))
	m4TMa1Xgis3Yq = m4TMa1Xgis3Yq.replace(Me28A1sBLNIgUp5YCDyvT(u"ࠧࠡࠢࠣࠤࠬᛱ"),Cu1704YofAbr3QTm(u"ࠨࠢࠪᛲ")).replace(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࠣࠤࠥ࠭ᛳ"),kEhAHvti6Vnsfx(u"ࠪࠤࠬᛴ")).replace(iRoLg2m47tnDATBHGCSPNyx(u"ࠫࠥࠦࠧᛵ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠬࠦࠧᛶ"))
	oCrTtRIykV4E9fuKnBGW = bUdr5Hahw6sY8xJ(u"࠭ࠠࠡࠢࡏࡥࡧ࡫࡬࠻ࠢ࡞ࠤࠬᛷ")+ccIZBYDOGdJlTE81Li2wAmuKtk+LiRcTVUWuth70DmPy(u"ࠧࠡ࡟ࠣࠤࠥࡓ࡯ࡥࡧ࠽ࠤࡠࠦࠧᛸ")+xUmyzZKOd8hv3Jc5X2nPHCAarW4sF+SO94xq1RAkMm2uF(u"ࠨࠢࡠࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨ᛹")+m4TMa1Xgis3Yq+iRoLg2m47tnDATBHGCSPNyx(u"ࠩࠣࡡࠬ᛺")
LOHZ4o9m7p6ebfTYXGIdz5PWs3q(lc0dpSmwoPDjLnk(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ᛻"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+oCrTtRIykV4E9fuKnBGW)
if xW2Arao7YVOemw(u"ࠫࡤ࠭᛼") in stpvYViqku3: IyACiLrROSYh7HBjzgoUVmfF,MDjmb7oV5XyCkLe4T32Q = stpvYViqku3.split(E6MIKdpBomef(u"ࠬࡥࠧ᛽"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠱᜛"))
else: IyACiLrROSYh7HBjzgoUVmfF,MDjmb7oV5XyCkLe4T32Q = stpvYViqku3,sTcr7iDp5eFt4RoLMhuwq1A(u"࠭ࠧ᛾")
if IyACiLrROSYh7HBjzgoUVmfF in [G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠧ࠲ࠩ᛿"),LiRcTVUWuth70DmPy(u"ࠨ࠴ࠪᜀ"),dshJSmRqeiP9nap2(u"ࠩ࠶ࠫᜁ"),SO94xq1RAkMm2uF(u"ࠪ࠸ࠬᜂ"),FnBiAjthS8MkXs67W(u"ࠫ࠺࠭ᜃ")] and (pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬࡇࡄࡅࠩᜄ") in MDjmb7oV5XyCkLe4T32Q or Me28A1sBLNIgUp5YCDyvT(u"࠭ࡒࡆࡏࡒ࡚ࡊ࠭ᜅ") in MDjmb7oV5XyCkLe4T32Q or lc0dpSmwoPDjLnk(u"ࠧࡖࡒࠪᜆ") in MDjmb7oV5XyCkLe4T32Q or sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨࡆࡒ࡛ࡓ࠭ᜇ") in MDjmb7oV5XyCkLe4T32Q):
	from ILG9YzDbKk import CC2IGzXJ4u
	CC2IGzXJ4u(stpvYViqku3,IyACiLrROSYh7HBjzgoUVmfF,MDjmb7oV5XyCkLe4T32Q)
	jHevARrF7lS.setSetting(kEhAHvti6Vnsfx(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭ᜈ"),jI8KGT6dsgDQ)
	cEZpW924rqNYm5.executebuiltin(FnBiAjthS8MkXs67W(u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧᜉ"))
elif not fCQhRT4Nr3gvxstOoADJaY and dMiPQHejCTElLJuDz6oN5tR8Y in [pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠳࠵࠸᜜"),wRxoKs10Syj7V4edYhtP(u"࠹࠴࠹᜝")]:
	xwaMIT0Kr5nmt6DsHlF2C9qV7p = str(LGdFZQvKeU52s6H0DgjN[Cu1704YofAbr3QTm(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᜊ")])
	cTJphS1nFz5EUgNWm86C = sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬࡏࡐࡕࡘࠪᜋ") if dMiPQHejCTElLJuDz6oN5tR8Y==pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠵࠷࠺᜞") else lc0dpSmwoPDjLnk(u"࠭ࡍ࠴ࡗࠪᜌ")
	UKc8W425PN = cTJphS1nFz5EUgNWm86C.lower()
	bTDaxXYSseoFCI6cQ4f58vqr3dPNp = jHevARrF7lS.getSetting(bUdr5Hahw6sY8xJ(u"ࠧࡢࡸ࠱ࠫᜍ")+UKc8W425PN+iUeoLOsbHqP(u"ࠨ࠰ࡸࡷࡪࡸࡡࡨࡧࡱࡸࡤ࠭ᜎ")+xwaMIT0Kr5nmt6DsHlF2C9qV7p)
	CCilGtf08YTx6qDX9Svg = jHevARrF7lS.getSetting(UTelCo0ihE1d5R(u"ࠩࡤࡺ࠳࠭ᜏ")+UKc8W425PN+LiRcTVUWuth70DmPy(u"ࠪ࠲ࡷ࡫ࡦࡦࡴࡨࡶࡤ࠭ᜐ")+xwaMIT0Kr5nmt6DsHlF2C9qV7p)
	if bTDaxXYSseoFCI6cQ4f58vqr3dPNp or CCilGtf08YTx6qDX9Svg:
		mHejXxkvM1qCESPVRy54QB += yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫࢁ࠭ᜑ")
		if bTDaxXYSseoFCI6cQ4f58vqr3dPNp: mHejXxkvM1qCESPVRy54QB += FnBiAjthS8MkXs67W(u"ࠬࠬࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫᜒ")+bTDaxXYSseoFCI6cQ4f58vqr3dPNp
		if CCilGtf08YTx6qDX9Svg: mHejXxkvM1qCESPVRy54QB += Me28A1sBLNIgUp5YCDyvT(u"࠭ࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩᜓ")+CCilGtf08YTx6qDX9Svg
		mHejXxkvM1qCESPVRy54QB = mHejXxkvM1qCESPVRy54QB.replace(hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࡽࠨ᜔ࠪ"),wRxoKs10Syj7V4edYhtP(u"ࠨࡾ᜕ࠪ"))
	ES8YZ7ymaUOX0j1RnLbedJW3GT = jHevARrF7lS.getSetting(lc0dpSmwoPDjLnk(u"ࠩࡤࡺ࠳࠭᜖")+UKc8W425PN+g4g6bfkPtVGU5lIM3(u"ࠪ࠲ࡸ࡫ࡲࡷࡧࡵࡣࠬ᜗")+xwaMIT0Kr5nmt6DsHlF2C9qV7p)
	if ES8YZ7ymaUOX0j1RnLbedJW3GT:
		aUuV7XeFnS = GGvHJKP9LUxEk10Fw.findall(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫ࠿࠵࠯ࠩ࠰࠭ࡃ࠮࠵ࠧ᜘"),mHejXxkvM1qCESPVRy54QB,GGvHJKP9LUxEk10Fw.DOTALL)
		mHejXxkvM1qCESPVRy54QB = mHejXxkvM1qCESPVRy54QB.replace(aUuV7XeFnS[XzrqbGDIy54juixkMA(u"࠴ᜟ")],ES8YZ7ymaUOX0j1RnLbedJW3GT)
	ICifW6hdKqxkAJ02XZgHysOwoV9Dc5(mHejXxkvM1qCESPVRy54QB,cTJphS1nFz5EUgNWm86C,uI7UAQCyPO85aLonkGqrdWwRt)
else:
	cpH6YnUzMk9A = zQP2wplUqKgLE3DYy6OcoSHJfT8(PPVuQkU9OfiBXegYZK2c3Tl6)
	import ccTpfuSVZY
	CCeZSJvsigLcq = FvNyZqaLKw(u"ࠬ࠭᜙")
	try: ccTpfuSVZY.Vi7FqdgSTmZptPJWj9wH(uI7UAQCyPO85aLonkGqrdWwRt,PPVuQkU9OfiBXegYZK2c3Tl6,mHejXxkvM1qCESPVRy54QB,xUmyzZKOd8hv3Jc5X2nPHCAarW4sF,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,fH8bDPV6AceuCFNO0Ert7oq3p,stpvYViqku3,LGdFZQvKeU52s6H0DgjN,cpH6YnUzMk9A,dMiPQHejCTElLJuDz6oN5tR8Y,IyACiLrROSYh7HBjzgoUVmfF,MDjmb7oV5XyCkLe4T32Q,ccIZBYDOGdJlTE81Li2wAmuKtk)
	except Exception as VVEta3LoIkqnG: CCeZSJvsigLcq = FTYWns4Q7dSEXmBOAGlJ.format_exc()
	ccTpfuSVZY.KoJbHj06uiglhdVTtws58xLNB(CCeZSJvsigLcq)
# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'MOVIZLAND'
headers = { 'User-Agent' : '' }
mmDwMlfoHtG5XT19VLIWqCR8i = '_MVZ_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
msL09WzMG3c86RAqkXpY7yn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][1]
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==180: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==181: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,text)
	elif mode==182: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==183: zpXG3Ky6ou8ndWHkb4 = hWPvGlXZ5arzV7(url)
	elif mode==188: zpXG3Ky6ou8ndWHkb4 = Q6bXWBHfTyd()
	elif mode==189: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def Q6bXWBHfTyd():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	aHKzv76JCVnprbY8w('','','رسالة من المبرمج',message)
	return
def T2AtWpmSuysJ3BzHVeFY():
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',189,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'بوكس اوفيس موفيز لاند',NBm2aWhPzoTpdYn,181,'','','box-office')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'أحدث الافلام',NBm2aWhPzoTpdYn,181,'','','latest-movies')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'تليفزيون موفيز لاند',NBm2aWhPzoTpdYn,181,'','','tv')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'الاكثر مشاهدة',NBm2aWhPzoTpdYn,181,'','','top-views')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'أقوى الافلام الحالية',NBm2aWhPzoTpdYn,181,'','','top-movies')
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,NBm2aWhPzoTpdYn,'',headers,'','MOVIZLAND-MENU-1st')
	items = GGvHJKP9LUxEk10Fw.findall('<h2><a href="(.*?)".*?">(.*?)<',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,181)
	return BBlXpmUyhFDwNtCVAHoE
def xoiXMWjJC3pnQqurIGPkRSl8e(url,type=''):
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,url,'',headers,'','MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': UCEFMfKbgpd = GGvHJKP9LUxEk10Fw.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)[0]
	elif type=='box-office': UCEFMfKbgpd = GGvHJKP9LUxEk10Fw.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)[0]
	elif type=='top-movies': UCEFMfKbgpd = GGvHJKP9LUxEk10Fw.findall('btn-2-overlay(.*?)<style>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)[0]
	elif type=='top-views': UCEFMfKbgpd = GGvHJKP9LUxEk10Fw.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)[0]
	elif type=='tv': UCEFMfKbgpd = GGvHJKP9LUxEk10Fw.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)[0]
	else: UCEFMfKbgpd = BBlXpmUyhFDwNtCVAHoE
	if type in ['top-views','top-movies']:
		items = GGvHJKP9LUxEk10Fw.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	else: items = GGvHJKP9LUxEk10Fw.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	IcJOGsq3Ff7EmkiLx = []
	O79xwZs3Cr42HinDSRfgMu = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for VFqpJjRySZvgi,n3ot08Ck2OIaKFq1iJsvWQScyfx,DCguJjW2E9bQomXAqG,KabhGpmIOrHTv0DEXWu7FVA in items:
		if type in ['top-views','top-movies']:
			VFqpJjRySZvgi,ELbNB92cOh5dqtpVmi40kY,E2EhMuOLdF08Pz75jDKS14cfYNxy,title = VFqpJjRySZvgi,n3ot08Ck2OIaKFq1iJsvWQScyfx,DCguJjW2E9bQomXAqG,KabhGpmIOrHTv0DEXWu7FVA
		else: VFqpJjRySZvgi,title,ELbNB92cOh5dqtpVmi40kY,E2EhMuOLdF08Pz75jDKS14cfYNxy = VFqpJjRySZvgi,n3ot08Ck2OIaKFq1iJsvWQScyfx,DCguJjW2E9bQomXAqG,KabhGpmIOrHTv0DEXWu7FVA
		ELbNB92cOh5dqtpVmi40kY = GhPlajzTxY8(ELbNB92cOh5dqtpVmi40kY)
		ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.replace('?view=true','')
		title = DwNC3gEonizsB6a0v1F(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ','').replace('بجوده ','')
		title = title.strip(' ')
		if 'الحلقة' in title or 'الحلقه' in title:
			qUGxSK2VwsiBAdkDZnJ605vQeg = GGvHJKP9LUxEk10Fw.findall('(.*?) (الحلقة|الحلقه) \d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
			if qUGxSK2VwsiBAdkDZnJ605vQeg:
				title = '_MOD_' + qUGxSK2VwsiBAdkDZnJ605vQeg[0][0]
				if title not in IcJOGsq3Ff7EmkiLx:
					cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,183,VFqpJjRySZvgi)
					IcJOGsq3Ff7EmkiLx.append(title)
		elif any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in O79xwZs3Cr42HinDSRfgMu):
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY + '?servers=' + E2EhMuOLdF08Pz75jDKS14cfYNxy
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,182,VFqpJjRySZvgi)
		else:
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY + '?servers=' + E2EhMuOLdF08Pz75jDKS14cfYNxy
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,183,VFqpJjRySZvgi)
	if type=='':
		items = GGvHJKP9LUxEk10Fw.findall('\n<li><a href="(.*?)".*?>(.*?)<',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			title = DwNC3gEonizsB6a0v1F(title)
			title = title.replace('الصفحة ','')
			if title!='':
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,181)
	return
def hWPvGlXZ5arzV7(url):
	dR2vHyAtl8pJN1 = url.split('?servers=')[0]
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,dR2vHyAtl8pJN1,'',headers,'','MOVIZLAND-EPISODES-1st')
	UCEFMfKbgpd = GGvHJKP9LUxEk10Fw.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	title,X4XyOPCEu65AMYebxwaVW,VFqpJjRySZvgi = UCEFMfKbgpd[0]
	name = GGvHJKP9LUxEk10Fw.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,GGvHJKP9LUxEk10Fw.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="episodesNumbers"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY in items:
			ELbNB92cOh5dqtpVmi40kY = GhPlajzTxY8(ELbNB92cOh5dqtpVmi40kY)
			title = GGvHJKP9LUxEk10Fw.findall('(الحلقة|الحلقه)-([0-9]+)',ELbNB92cOh5dqtpVmi40kY.split('/')[-2],GGvHJKP9LUxEk10Fw.DOTALL)
			if not title: title = GGvHJKP9LUxEk10Fw.findall('()-([0-9]+)',ELbNB92cOh5dqtpVmi40kY.split('/')[-2],GGvHJKP9LUxEk10Fw.DOTALL)
			if title: title = ' ' + title[0][1]
			else: title = ''
			title = name + ' - ' + 'الحلقة' + title
			title = DwNC3gEonizsB6a0v1F(title)
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,182,VFqpJjRySZvgi)
	if not items:
		title = DwNC3gEonizsB6a0v1F(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ','').replace('بجوده ','')
		cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,182,VFqpJjRySZvgi)
	return
def SUfe4unWoXBNFz90xqy(url):
	ppxeJaBXIurWHj = url.split('?servers=')
	dR2vHyAtl8pJN1 = ppxeJaBXIurWHj[0]
	del ppxeJaBXIurWHj[0]
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,dR2vHyAtl8pJN1,'',headers,'','MOVIZLAND-PLAY-1st')
	ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall('font-size: 25px;" href="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)[0]
	if ELbNB92cOh5dqtpVmi40kY not in ppxeJaBXIurWHj: ppxeJaBXIurWHj.append(ELbNB92cOh5dqtpVmi40kY)
	zzvBg3ShiamAZ = []
	for ELbNB92cOh5dqtpVmi40kY in ppxeJaBXIurWHj:
		if '://moshahda.' in ELbNB92cOh5dqtpVmi40kY:
			FJt8r4RCZVUdcWejmAzq3fLl = ELbNB92cOh5dqtpVmi40kY
			zzvBg3ShiamAZ.append(FJt8r4RCZVUdcWejmAzq3fLl+'?named=Main')
	for ELbNB92cOh5dqtpVmi40kY in ppxeJaBXIurWHj:
		if '://vb.movizland.' in ELbNB92cOh5dqtpVmi40kY:
			BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,ELbNB92cOh5dqtpVmi40kY,'',headers,'','MOVIZLAND-PLAY-2nd')
			BBlXpmUyhFDwNtCVAHoE = BBlXpmUyhFDwNtCVAHoE.decode('windows-1256').encode('utf8')
			BBlXpmUyhFDwNtCVAHoE = BBlXpmUyhFDwNtCVAHoE.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			BBlXpmUyhFDwNtCVAHoE = BBlXpmUyhFDwNtCVAHoE.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			BBlXpmUyhFDwNtCVAHoE = BBlXpmUyhFDwNtCVAHoE.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			BBlXpmUyhFDwNtCVAHoE = BBlXpmUyhFDwNtCVAHoE.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
			if EeQqAGc0W5r6nlBbChwfZL:
				gRVtlOdFCSG8p1UjmPD,gCitSRH90rUG5s72VIBcaMQv8qpf = [],[]
				if len(EeQqAGc0W5r6nlBbChwfZL)==1:
					title = ''
					UCEFMfKbgpd = BBlXpmUyhFDwNtCVAHoE
				else:
					for UCEFMfKbgpd in EeQqAGc0W5r6nlBbChwfZL:
						jCxVUBZwAdOtIHM81rTJYiX3 = GGvHJKP9LUxEk10Fw.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
						if jCxVUBZwAdOtIHM81rTJYiX3: UCEFMfKbgpd = 'src="/uploads/13721411411.png"  \n  ' + jCxVUBZwAdOtIHM81rTJYiX3[0][1]
						jCxVUBZwAdOtIHM81rTJYiX3 = GGvHJKP9LUxEk10Fw.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
						if jCxVUBZwAdOtIHM81rTJYiX3: UCEFMfKbgpd = 'src="/uploads/13721411411.png"  \n  ' + jCxVUBZwAdOtIHM81rTJYiX3[0]
						jCxVUBZwAdOtIHM81rTJYiX3 = GGvHJKP9LUxEk10Fw.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
						if jCxVUBZwAdOtIHM81rTJYiX3: UCEFMfKbgpd = jCxVUBZwAdOtIHM81rTJYiX3[0] + '  \n  src="/uploads/13721411411.png"'
						K0PFkb1GAZC = GGvHJKP9LUxEk10Fw.findall('<(.*?)http://up.movizland.(online|com)/uploads/',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
						title = GGvHJKP9LUxEk10Fw.findall('> *([^<>]+) *<',K0PFkb1GAZC[0][0],GGvHJKP9LUxEk10Fw.DOTALL)
						title = ' '.join(title)
						title = title.strip(' ')
						title = title.replace('  ',' ').replace('  ',' ').replace('  ',' ').replace('  ',' ').replace('  ',' ')
						gRVtlOdFCSG8p1UjmPD.append(title)
					z0jyetbQwKrIclL9vJW = D1DJtzviFZSrA('أختر الفيديو المطلوب:', gRVtlOdFCSG8p1UjmPD)
					if z0jyetbQwKrIclL9vJW == -1 : return
					title = gRVtlOdFCSG8p1UjmPD[z0jyetbQwKrIclL9vJW]
					UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[z0jyetbQwKrIclL9vJW]
				ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall('href="(http://moshahda\..*?/\w+.html)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
				EpVQSZHxa3C6zO5skIriKFcWUL = ELbNB92cOh5dqtpVmi40kY[0]
				zzvBg3ShiamAZ.append(EpVQSZHxa3C6zO5skIriKFcWUL+'?named=Forum')
				UCEFMfKbgpd = UCEFMfKbgpd.replace('ـ','')
				UCEFMfKbgpd = UCEFMfKbgpd.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				UCEFMfKbgpd = UCEFMfKbgpd.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				UCEFMfKbgpd = UCEFMfKbgpd.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				UCEFMfKbgpd = UCEFMfKbgpd.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				UCEFMfKbgpd = UCEFMfKbgpd.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				UCEFMfKbgpd = UCEFMfKbgpd.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				e54npQxEKvUsMV = GGvHJKP9LUxEk10Fw.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
				for EStRL9Jnhduqes835X6GHbxBVvci in e54npQxEKvUsMV:
					type = GGvHJKP9LUxEk10Fw.findall(' typetype="(.*?)" ',EStRL9Jnhduqes835X6GHbxBVvci)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = ''
					items = GGvHJKP9LUxEk10Fw.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',EStRL9Jnhduqes835X6GHbxBVvci,GGvHJKP9LUxEk10Fw.DOTALL)
					for eLVZ5QUFMKbtWRa3Su6fPkIxcB,ELbNB92cOh5dqtpVmi40kY in items:
						title = GGvHJKP9LUxEk10Fw.findall('(\w+[ \w]*)<',eLVZ5QUFMKbtWRa3Su6fPkIxcB)
						title = title[-1]
						ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY + '?named=' + title + type
						zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	XwyU6PQgprMI0 = dR2vHyAtl8pJN1.replace(NBm2aWhPzoTpdYn,msL09WzMG3c86RAqkXpY7yn)
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,XwyU6PQgprMI0,'',headers,'','MOVIZLAND-PLAY-3rd')
	items = GGvHJKP9LUxEk10Fw.findall('" href="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if items:
		UcPAj8Y7V1XJRtzx3qDaNoh0d2p = items[-1]
		zzvBg3ShiamAZ.append(UcPAj8Y7V1XJRtzx3qDaNoh0d2p+'?named=Mobile')
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(zzvBg3ShiamAZ,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	search = search.replace(' ','+')
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,NBm2aWhPzoTpdYn,'',headers,'','MOVIZLAND-SEARCH-1st')
	items = GGvHJKP9LUxEk10Fw.findall('<option value="(.*?)">(.*?)</option>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	HHgNAaRqpxJ8BZLFmusc5IrW = [ '' ]
	xPOWTuLJRQ6Mig = [ 'الكل وبدون فلتر' ]
	for BBskpK6cGZJ,title in items:
		HHgNAaRqpxJ8BZLFmusc5IrW.append(BBskpK6cGZJ)
		xPOWTuLJRQ6Mig.append(title)
	if BBskpK6cGZJ:
		z0jyetbQwKrIclL9vJW = D1DJtzviFZSrA('اختر الفلتر المناسب:', xPOWTuLJRQ6Mig)
		if z0jyetbQwKrIclL9vJW == -1 : return
		BBskpK6cGZJ = HHgNAaRqpxJ8BZLFmusc5IrW[z0jyetbQwKrIclL9vJW]
	else: BBskpK6cGZJ = ''
	url = NBm2aWhPzoTpdYn + '/?s='+search+'&mcat='+BBskpK6cGZJ
	xoiXMWjJC3pnQqurIGPkRSl8e(url)
	return
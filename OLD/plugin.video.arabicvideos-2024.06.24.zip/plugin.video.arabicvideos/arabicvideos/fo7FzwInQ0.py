# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'KATKOTTV'
mmDwMlfoHtG5XT19VLIWqCR8i = '_KTV_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
DDXTwbRBaj3e2rSsPQ = []
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==810: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==811: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,text)
	elif mode==812: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==813: zpXG3Ky6ou8ndWHkb4 = BBGXtqhb3wOAVj5YUosD0mL4(url)
	elif mode==819: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',NBm2aWhPzoTpdYn,'','','','','KATKOTTV-MENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',819,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"primary-links"(.*?)"most-viewed"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?<span>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		if title in DDXTwbRBaj3e2rSsPQ: continue
		cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,811)
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(url,type=''):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','KATKOTTV-TITLES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"home-content"(.*?)"footer"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('"thumb".*?data-src="(.*?)".*?href="(.*?)".*?title="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		IcJOGsq3Ff7EmkiLx = []
		for VFqpJjRySZvgi,ELbNB92cOh5dqtpVmi40kY,title in items:
			qUGxSK2VwsiBAdkDZnJ605vQeg = GGvHJKP9LUxEk10Fw.findall('(.*?) (الحلقة|حلقة).\d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
			if 'episodes' not in type and qUGxSK2VwsiBAdkDZnJ605vQeg:
				title = '_MOD_' + qUGxSK2VwsiBAdkDZnJ605vQeg[0][0]
				title = title.replace('اون لاين','')
				if title not in IcJOGsq3Ff7EmkiLx:
					cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,813,VFqpJjRySZvgi)
					IcJOGsq3Ff7EmkiLx.append(title)
			else: cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,812,VFqpJjRySZvgi)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall("'pagination'(.*?)footer",BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			title = DwNC3gEonizsB6a0v1F(title)
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,811,'','',type)
	return
def BBGXtqhb3wOAVj5YUosD0mL4(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','KATKOTTV-SERIES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall('"category".*?href="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if ELbNB92cOh5dqtpVmi40kY: xoiXMWjJC3pnQqurIGPkRSl8e(ELbNB92cOh5dqtpVmi40kY[0],'episodes')
	return
def SUfe4unWoXBNFz90xqy(url):
	uuIjMn1YTf687WlRcOmhq4G23H = []
	dR2vHyAtl8pJN1 = url+'?do=watch'
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',dR2vHyAtl8pJN1,'','','','','KATKOTTV-PLAY-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall('" src="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if ELbNB92cOh5dqtpVmi40kY:
		ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY[0]
		uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY)
	else:
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','KATKOTTV-PLAY-2nd')
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		OCYoctKgbdnePV2 = GGvHJKP9LUxEk10Fw.findall('post=(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if OCYoctKgbdnePV2:
			OCYoctKgbdnePV2 = hNe0ECZHr9B6.b64decode(OCYoctKgbdnePV2[0])
			if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: OCYoctKgbdnePV2 = OCYoctKgbdnePV2.decode('utf8')
			OCYoctKgbdnePV2 = JKw5OWktPZB('dict',OCYoctKgbdnePV2)
			gI487voLsArVqW6Ffp = OCYoctKgbdnePV2['servers']
			xut3LAibydXZnzkpBaKOsgew70 = list(gI487voLsArVqW6Ffp.keys())
			gI487voLsArVqW6Ffp = list(gI487voLsArVqW6Ffp.values())
			iILrnWKwUhP6bf = zip(xut3LAibydXZnzkpBaKOsgew70,gI487voLsArVqW6Ffp)
			for title,ELbNB92cOh5dqtpVmi40kY in iILrnWKwUhP6bf:
				ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named='+title+'__watch'
				uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY)
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(uuIjMn1YTf687WlRcOmhq4G23H,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	search = search.replace(' ','+')
	url = NBm2aWhPzoTpdYn+'/?s='+search
	xoiXMWjJC3pnQqurIGPkRSl8e(url,'search')
	return
# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'LAROZA'
mmDwMlfoHtG5XT19VLIWqCR8i = '_LRZ_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
DDXTwbRBaj3e2rSsPQ = ['الصفحة الرئيسية','Sign in','الاقسام','عرض المزيد']
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==700: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==701: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,text)
	elif mode==702: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==703: zpXG3Ky6ou8ndWHkb4 = xKqSdbG6RNz8(url,text)
	elif mode==704: zpXG3Ky6ou8ndWHkb4 = i7pbAuodvX3(url)
	elif mode==709: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	aPNBvIyexc053gAsSw1QoRMUYfb = NBm2aWhPzoTpdYn+'/zika.9'
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',aPNBvIyexc053gAsSw1QoRMUYfb,'','','','','LAROZA-MENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',709,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'مميز',aPNBvIyexc053gAsSw1QoRMUYfb,701,'','','featured')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="pm-top-nav"(.*?)class="hidden',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('href="(http.*?)".*?>(.*?)</',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		title = title.replace('<b>','').strip(' ')
		if title in DDXTwbRBaj3e2rSsPQ: continue
		if ELbNB92cOh5dqtpVmi40kY.endswith('category.php'): continue
		cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,704)
	return
def i7pbAuodvX3(url):
	nP18Siw4MjRatJdKYNL7CUyB9eg = False
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','LAROZA-SUBMENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	xxcVm7YBMXsfd = GGvHJKP9LUxEk10Fw.findall('role="menu"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if xxcVm7YBMXsfd:
		UCEFMfKbgpd = xxcVm7YBMXsfd[0]
		UCEFMfKbgpd = UCEFMfKbgpd.replace('"presentation"','</ul>')
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if not EeQqAGc0W5r6nlBbChwfZL: EeQqAGc0W5r6nlBbChwfZL = [('',UCEFMfKbgpd)]
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] فرز أو فلتر أو ترتيب [/COLOR]','',9999)
		for nn5FjvR2JoN9,UCEFMfKbgpd in EeQqAGc0W5r6nlBbChwfZL:
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			if nn5FjvR2JoN9: nn5FjvR2JoN9 = nn5FjvR2JoN9+': '
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				title = nn5FjvR2JoN9+title
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,701)
				nP18Siw4MjRatJdKYNL7CUyB9eg = True
	uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb = GGvHJKP9LUxEk10Fw.findall('"pm-category-subcats"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb:
		UCEFMfKbgpd = uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if len(items)<30:
			if nP18Siw4MjRatJdKYNL7CUyB9eg: cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,701)
				nP18Siw4MjRatJdKYNL7CUyB9eg = True
	egvf3lubILM5pSoCqrN1K0 = GGvHJKP9LUxEk10Fw.findall('class="catfootr"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if egvf3lubILM5pSoCqrN1K0:
		UCEFMfKbgpd = egvf3lubILM5pSoCqrN1K0[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if 1:
			if nP18Siw4MjRatJdKYNL7CUyB9eg: cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				title = title.strip(' ')
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,701)
				nP18Siw4MjRatJdKYNL7CUyB9eg = True
	if not nP18Siw4MjRatJdKYNL7CUyB9eg: xoiXMWjJC3pnQqurIGPkRSl8e(url)
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(url,hD6se2E307NcI=''):
	if hD6se2E307NcI=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'POST',url,data,headers,'','','LAROZA-TITLES-1st')
	else:
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','LAROZA-TITLES-2nd')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	UCEFMfKbgpd,items = '',[]
	aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(url,'url')
	if hD6se2E307NcI=='ajax-search':
		UCEFMfKbgpd = BBlXpmUyhFDwNtCVAHoE
		GzpIUylJrXRteaKPiNDLHuScmbgj = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in GzpIUylJrXRteaKPiNDLHuScmbgj: items.append(('',ELbNB92cOh5dqtpVmi40kY,title))
	elif hD6se2E307NcI=='featured':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('id="content"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL: UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	elif hD6se2E307NcI=='new_episodes':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"row pm-ul-browse-videos(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL: UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	elif hD6se2E307NcI=='new_movies':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"row pm-ul-browse-videos(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if len(EeQqAGc0W5r6nlBbChwfZL)>1: UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[1]
	elif hD6se2E307NcI=='featured_series':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"ba mgb table full"(.*?)"clearfix"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL: UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		GzpIUylJrXRteaKPiNDLHuScmbgj = GGvHJKP9LUxEk10Fw.findall('href="(.*?)" title="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in GzpIUylJrXRteaKPiNDLHuScmbgj: items.append(('',ELbNB92cOh5dqtpVmi40kY,title))
	else:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('(data-echo=".*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL: UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	if UCEFMfKbgpd and not items: items = GGvHJKP9LUxEk10Fw.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	if not items: return
	IcJOGsq3Ff7EmkiLx = []
	Dq0X5cvgdjwh6LbnUkETFBR8 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for VFqpJjRySZvgi,ELbNB92cOh5dqtpVmi40kY,title in items:
		if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = aPNBvIyexc053gAsSw1QoRMUYfb+'/'+ELbNB92cOh5dqtpVmi40kY.strip('/')
		qUGxSK2VwsiBAdkDZnJ605vQeg = GGvHJKP9LUxEk10Fw.findall('(.*?) (الحلقة|حلقة).\d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
		if any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in Dq0X5cvgdjwh6LbnUkETFBR8):
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,702,VFqpJjRySZvgi)
		elif hD6se2E307NcI=='new_episodes':
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,702,VFqpJjRySZvgi)
		elif qUGxSK2VwsiBAdkDZnJ605vQeg:
			title = '_MOD_' + qUGxSK2VwsiBAdkDZnJ605vQeg[0][0]
			if title not in IcJOGsq3Ff7EmkiLx:
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,703,VFqpJjRySZvgi)
				IcJOGsq3Ff7EmkiLx.append(title)
		else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,703,VFqpJjRySZvgi)
	if 1:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"pagination(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				if ELbNB92cOh5dqtpVmi40kY=='#': continue
				ELbNB92cOh5dqtpVmi40kY = aPNBvIyexc053gAsSw1QoRMUYfb+'/'+ELbNB92cOh5dqtpVmi40kY.strip('/')
				title = DwNC3gEonizsB6a0v1F(title)
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,701)
	return
def xKqSdbG6RNz8(url,FzY68T7WDR1g4hEnNM5Sj9BkfXq):
	aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(url,'url')
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','LAROZA-EPISODES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	xxcVm7YBMXsfd = GGvHJKP9LUxEk10Fw.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	nWO8c3IgspK67QX = GGvHJKP9LUxEk10Fw.findall('"series-header".*?src="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if nWO8c3IgspK67QX: VFqpJjRySZvgi = nWO8c3IgspK67QX[0]
	else: VFqpJjRySZvgi = ''
	items = []
	PXEg9SIJcUOi3v = False
	if xxcVm7YBMXsfd and not FzY68T7WDR1g4hEnNM5Sj9BkfXq:
		UCEFMfKbgpd = xxcVm7YBMXsfd[0]
		items = GGvHJKP9LUxEk10Fw.findall('''openCity\(event, '(.*?)'\).*?">(.*?)</button>''',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if not items: items = GGvHJKP9LUxEk10Fw.findall('data-serie="(.*?)".*?">(.*?)</',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for FzY68T7WDR1g4hEnNM5Sj9BkfXq,title in items:
			FzY68T7WDR1g4hEnNM5Sj9BkfXq = FzY68T7WDR1g4hEnNM5Sj9BkfXq.strip('#')
			if len(items)>1: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,703,VFqpJjRySZvgi,'',FzY68T7WDR1g4hEnNM5Sj9BkfXq)
			else: PXEg9SIJcUOi3v = True
	else: PXEg9SIJcUOi3v = True
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"SeasonsEpisodesMain(.*?)<script>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb = GGvHJKP9LUxEk10Fw.findall('id="'+FzY68T7WDR1g4hEnNM5Sj9BkfXq+'"(.*?)</ul>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if not uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb: uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb = GGvHJKP9LUxEk10Fw.findall('data-serie="'+FzY68T7WDR1g4hEnNM5Sj9BkfXq+'"(.*?)</div>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if not uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb: uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb = GGvHJKP9LUxEk10Fw.findall('id="Season'+FzY68T7WDR1g4hEnNM5Sj9BkfXq+'"(.*?)</ul>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb and PXEg9SIJcUOi3v:
			UCEFMfKbgpd = uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb[0]
			GzpIUylJrXRteaKPiNDLHuScmbgj = GGvHJKP9LUxEk10Fw.findall("href='(.*?)'><li><em>(.*?)</span>",UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			if not GzpIUylJrXRteaKPiNDLHuScmbgj: GzpIUylJrXRteaKPiNDLHuScmbgj = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?<em>(.*?)</span>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			items = []
			for ELbNB92cOh5dqtpVmi40kY,title in GzpIUylJrXRteaKPiNDLHuScmbgj: items.append((ELbNB92cOh5dqtpVmi40kY,title,VFqpJjRySZvgi))
			if not items: items = GGvHJKP9LUxEk10Fw.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,title,VFqpJjRySZvgi in items:
				ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.strip('./')
				ELbNB92cOh5dqtpVmi40kY = aPNBvIyexc053gAsSw1QoRMUYfb+'/'+ELbNB92cOh5dqtpVmi40kY.strip('/')
				title = title.replace('</em><span>',' ')
				cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,702,VFqpJjRySZvgi)
	return
def SUfe4unWoXBNFz90xqy(url):
	zzvBg3ShiamAZ,Y89Ig1NnB7SL4KJGPyXCQcdOoW,uuIjMn1YTf687WlRcOmhq4G23H = [],[],[]
	dR2vHyAtl8pJN1 = url.replace('/video.php','/play.php')
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',dR2vHyAtl8pJN1,'','','','','LAROZA-PLAY-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"WatchServers"(.*?)</div>.</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall('"Playerholder".*?src="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if ELbNB92cOh5dqtpVmi40kY:
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY[0]
			Y89Ig1NnB7SL4KJGPyXCQcdOoW.append('?named=__embed')
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
		gI487voLsArVqW6Ffp = GGvHJKP9LUxEk10Fw.findall('data-embed="(.*?)".*?</span>(.*?)</button>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in gI487voLsArVqW6Ffp:
			title = title.strip(' ')
			if ELbNB92cOh5dqtpVmi40kY not in zzvBg3ShiamAZ:
				Y89Ig1NnB7SL4KJGPyXCQcdOoW.append('?named='+title+'__watch')
				zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"DownloadServer"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		gI487voLsArVqW6Ffp = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?</i>(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in gI487voLsArVqW6Ffp:
			if ELbNB92cOh5dqtpVmi40kY not in zzvBg3ShiamAZ:
				title = title.strip('\n')
				Y89Ig1NnB7SL4KJGPyXCQcdOoW.append('?named='+title+'__download')
				zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	iILrnWKwUhP6bf = zip(zzvBg3ShiamAZ,Y89Ig1NnB7SL4KJGPyXCQcdOoW)
	for ELbNB92cOh5dqtpVmi40kY,name in iILrnWKwUhP6bf: uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY+name)
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(uuIjMn1YTf687WlRcOmhq4G23H,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	search = search.replace(' ','+')
	url = NBm2aWhPzoTpdYn+'/search.php?keywords='+search
	xoiXMWjJC3pnQqurIGPkRSl8e(url,'search')
	return
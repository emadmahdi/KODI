# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'ALFATIMI'
mmDwMlfoHtG5XT19VLIWqCR8i = '_FTM_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
RK4A7uQo8WEeXsxHrg9 = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
FT8psOlm6M3fDeYQ1ZEi4Hnt = ['3030','628']
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==60: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==61: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,text)
	elif mode==62: zpXG3Ky6ou8ndWHkb4 = hWPvGlXZ5arzV7(url)
	elif mode==63: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==64: zpXG3Ky6ou8ndWHkb4 = SrbdvMNlyawWjFT72unc6RpBfgUQ(text)
	elif mode==69: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',69,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'ما يتم مشاهدته الان',NBm2aWhPzoTpdYn,64,'','','recent_viewed_vids')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'الاكثر مشاهدة',NBm2aWhPzoTpdYn,64,'','','most_viewed_vids')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'اضيفت مؤخرا',NBm2aWhPzoTpdYn,64,'','','recently_added_vids')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'فيديو عشوائي',NBm2aWhPzoTpdYn,64,'','','random_vids')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'افلام ومسلسلات',NBm2aWhPzoTpdYn,61,'','','-1')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'البرامج الدينية',NBm2aWhPzoTpdYn,61,'','','-2')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'English Videos',NBm2aWhPzoTpdYn,61,'','','-3')
	return ''
def xoiXMWjJC3pnQqurIGPkRSl8e(url,BBskpK6cGZJ):
	LYJbXq4C9mgjWieMunoPd = ''
	if BBskpK6cGZJ not in ['-1','-2','-3']: LYJbXq4C9mgjWieMunoPd = '?cat='+BBskpK6cGZJ
	dR2vHyAtl8pJN1 = NBm2aWhPzoTpdYn+'/menu_level.php'+LYJbXq4C9mgjWieMunoPd
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,dR2vHyAtl8pJN1,'','','','ALFATIMI-TITLES-1st')
	items = GGvHJKP9LUxEk10Fw.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	AfFBoOGZPJsVItSWqn6pbL,nP18Siw4MjRatJdKYNL7CUyB9eg = False,False
	for ELbNB92cOh5dqtpVmi40kY,title,count in items:
		title = DwNC3gEonizsB6a0v1F(title)
		title = title.strip(' ')
		if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = 'http:'+ELbNB92cOh5dqtpVmi40kY
		LYJbXq4C9mgjWieMunoPd = GGvHJKP9LUxEk10Fw.findall('cat=(.*?)&',ELbNB92cOh5dqtpVmi40kY,GGvHJKP9LUxEk10Fw.DOTALL)[0]
		if BBskpK6cGZJ==LYJbXq4C9mgjWieMunoPd: AfFBoOGZPJsVItSWqn6pbL = True
		elif AfFBoOGZPJsVItSWqn6pbL 	or (BBskpK6cGZJ=='-1' and LYJbXq4C9mgjWieMunoPd in RK4A7uQo8WEeXsxHrg9)  						or (BBskpK6cGZJ=='-2' and LYJbXq4C9mgjWieMunoPd not in FT8psOlm6M3fDeYQ1ZEi4Hnt and LYJbXq4C9mgjWieMunoPd not in RK4A7uQo8WEeXsxHrg9)  						or (BBskpK6cGZJ=='-3' and LYJbXq4C9mgjWieMunoPd in FT8psOlm6M3fDeYQ1ZEi4Hnt):
							if count=='1': cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,63)
							else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,61,'','',LYJbXq4C9mgjWieMunoPd)
							nP18Siw4MjRatJdKYNL7CUyB9eg = True
	if not nP18Siw4MjRatJdKYNL7CUyB9eg: hWPvGlXZ5arzV7(url)
	return
def hWPvGlXZ5arzV7(url):
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,url,'','',True,'ALFATIMI-EPISODES-1st')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('pagination(.*?)id="footer',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	ELbNB92cOh5dqtpVmi40kY = ''
	for VFqpJjRySZvgi,title,ELbNB92cOh5dqtpVmi40kY in items:
		title = title.replace('Add','').replace('to Quicklist','').strip(' ')
		if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = 'http:'+ELbNB92cOh5dqtpVmi40kY
		cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,63,VFqpJjRySZvgi)
	EeQqAGc0W5r6nlBbChwfZL=GGvHJKP9LUxEk10Fw.findall('(.*?)div',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd=EeQqAGc0W5r6nlBbChwfZL[0]
	UCEFMfKbgpd=GGvHJKP9LUxEk10Fw.findall('pagination(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)[0]
	items=GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	dR2vHyAtl8pJN1 = url.split('?')[0]
	for ELbNB92cOh5dqtpVmi40kY,IPbFd21uGo4Y7g5ntW8JNa0wlfC in items:
		ELbNB92cOh5dqtpVmi40kY = dR2vHyAtl8pJN1 + ELbNB92cOh5dqtpVmi40kY
		title = DwNC3gEonizsB6a0v1F(IPbFd21uGo4Y7g5ntW8JNa0wlfC)
		title = 'صفحة ' + title
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,62)
	return ELbNB92cOh5dqtpVmi40kY
def SUfe4unWoXBNFz90xqy(url):
	if 'videos.php' in url: url = hWPvGlXZ5arzV7(url)
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,url,'','',True,'ALFATIMI-PLAY-1st')
	items = GGvHJKP9LUxEk10Fw.findall('playlistfile:"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	ICifW6hdKqxkAJ02XZgHysOwoV9Dc5(url,cTJphS1nFz5EUgNWm86C,'video')
	return
def SrbdvMNlyawWjFT72unc6RpBfgUQ(BBskpK6cGZJ):
	vpWXJDC4lTByaqcn56OFwUmieV = { 'mode' : BBskpK6cGZJ }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = Hym17NopzZUE3xhYMe(vpWXJDC4lTByaqcn56OFwUmieV)
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(xh9BXlAw0UoVsIZ4if3,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title,VFqpJjRySZvgi in items:
		title = title.strip(' ')
		if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = 'http:'+ELbNB92cOh5dqtpVmi40kY
		cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,63,VFqpJjRySZvgi)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	aKRILTAj1HC5c = search.replace(' ','+')
	url = NBm2aWhPzoTpdYn + '/search_result.php?query=' + aKRILTAj1HC5c
	hWPvGlXZ5arzV7(url)
	return
# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'GLOBALSEARCH'
mmDwMlfoHtG5XT19VLIWqCR8i = '_GLS_'
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(VRnfEFmJzUrSljM8,kk1GKyapocQZDAz,MMupPCxqkenwt6FlsbRILV37EAmB,EfNzW3kLhcMTu07HrP28X9nFA6vpGd):
	if   VRnfEFmJzUrSljM8==540: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif VRnfEFmJzUrSljM8==541: zpXG3Ky6ou8ndWHkb4 = irmLUsAPkD2ndfJb(MMupPCxqkenwt6FlsbRILV37EAmB)
	elif VRnfEFmJzUrSljM8==542: zpXG3Ky6ou8ndWHkb4 = QaY4tb5WpuewOXBM(MMupPCxqkenwt6FlsbRILV37EAmB,kk1GKyapocQZDAz,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif VRnfEFmJzUrSljM8==549: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(MMupPCxqkenwt6FlsbRILV37EAmB)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	cd0aGwCPExbFU5pYNu8r('folder','بحث جديد','',549)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008]==== كلمات مخزنة ====[/COLOR]','',9999)
	zIdGRJQMDT6i1Bu0gfyAemkE8a = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,'dict','GLOBALSEARCH_SITES')
	if zIdGRJQMDT6i1Bu0gfyAemkE8a:
		zIdGRJQMDT6i1Bu0gfyAemkE8a = zIdGRJQMDT6i1Bu0gfyAemkE8a['__SEQUENCED_COLUMNS__']
		for fPlzJqILutFmRv6NYy in reversed(zIdGRJQMDT6i1Bu0gfyAemkE8a):
			cd0aGwCPExbFU5pYNu8r('folder',fPlzJqILutFmRv6NYy,'',549,'','',fPlzJqILutFmRv6NYy)
	return
def szwTAdaBt4FiXO(fPlzJqILutFmRv6NYy):
	if not fPlzJqILutFmRv6NYy:
		fPlzJqILutFmRv6NYy = yMRXZIpKxlSkaE6iCO()
		if not fPlzJqILutFmRv6NYy: return
		fPlzJqILutFmRv6NYy = fPlzJqILutFmRv6NYy.lower()
	JVCtFqbiU0W83efEKm2wg = fPlzJqILutFmRv6NYy.replace(mmDwMlfoHtG5XT19VLIWqCR8i,'')
	lHZaRXM1pV2bJ8Ig0v(JVCtFqbiU0W83efEKm2wg)
	cd0aGwCPExbFU5pYNu8r('link','عمل بحث جماعي - '+JVCtFqbiU0W83efEKm2wg,'search_sites',542,'','',JVCtFqbiU0W83efEKm2wg)
	cd0aGwCPExbFU5pYNu8r('folder','عمل بحث منفرد - '+JVCtFqbiU0W83efEKm2wg,'',541,'','',JVCtFqbiU0W83efEKm2wg)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder','نتائج البحث مفصلة - '+JVCtFqbiU0W83efEKm2wg,'opened_sites',542,'','',JVCtFqbiU0W83efEKm2wg)
	cd0aGwCPExbFU5pYNu8r('folder','نتائج البحث مقسمة - '+JVCtFqbiU0W83efEKm2wg,'listed_sites',542,'','',JVCtFqbiU0W83efEKm2wg)
	return
def lHZaRXM1pV2bJ8Ig0v(rHnDgUNsEY):
	NjDFkXqb1fVMRt = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,'list','GLOBALSEARCH_SITES',rHnDgUNsEY)
	fNlTDukd5KgqxVEQMHSzaY6IW = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,'list','GLOBALSEARCH_SITES',mmDwMlfoHtG5XT19VLIWqCR8i+rHnDgUNsEY)
	HHg0f8U75SdzxEcbt1JN(UkFh2OXjuTZEaexC,'GLOBALSEARCH_SITES',rHnDgUNsEY)
	HHg0f8U75SdzxEcbt1JN(UkFh2OXjuTZEaexC,'GLOBALSEARCH_SITES',mmDwMlfoHtG5XT19VLIWqCR8i+rHnDgUNsEY)
	tlBNn79SopWZEkzm3DxJCh = NjDFkXqb1fVMRt+fNlTDukd5KgqxVEQMHSzaY6IW
	if tlBNn79SopWZEkzm3DxJCh: rHnDgUNsEY = mmDwMlfoHtG5XT19VLIWqCR8i+rHnDgUNsEY
	Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,'GLOBALSEARCH_SITES',rHnDgUNsEY,tlBNn79SopWZEkzm3DxJCh,OrZFej19nLcNdh2WKRuDJC)
	return
def A9osj6z4gXVhnymUCKB2F():
	o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1('','','','رسالة من المبرمج','هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if o07Z1tEB4n3ARCkVNu!=1: return
	HHg0f8U75SdzxEcbt1JN(UkFh2OXjuTZEaexC,'GLOBALSEARCH_SITES')
	HHg0f8U75SdzxEcbt1JN(UkFh2OXjuTZEaexC,'GLOBALSEARCH_OPENED')
	HHg0f8U75SdzxEcbt1JN(UkFh2OXjuTZEaexC,'GLOBALSEARCH_CLOSED')
	aHKzv76JCVnprbY8w('','','رسالة من المبرمج','تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def QaY4tb5WpuewOXBM(rb2kdCWl1zJhmcnfxAi,tOfa2BzsG7NCkYeUu,jXPWwl4aH0OR9ILzMT5usS=''):
	TBP3EmNKAyrCQ5lk0HhMJ,XXUhPV0CYtivDoq7TL,ZGoH9TFqRbAtODi36dag,GlYCEhojTuxIXWyKqtwvzAiUaS,OFezHAfk3mpXlBKhGUaiCo5,I6KzQPNf2CoTVRLqBcZOnXJWA4FpjS,yDegLiBrqJOCHQsA87dUw0 = [],[],[],{},{},{},{}
	if tOfa2BzsG7NCkYeUu!='search_sites':
		if tOfa2BzsG7NCkYeUu=='listed_sites': ZGoH9TFqRbAtODi36dag = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,'list','GLOBALSEARCH_SITES',mmDwMlfoHtG5XT19VLIWqCR8i+rb2kdCWl1zJhmcnfxAi)
		elif tOfa2BzsG7NCkYeUu=='opened_sites': ZGoH9TFqRbAtODi36dag = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,'list','GLOBALSEARCH_OPENED',rb2kdCWl1zJhmcnfxAi)
		elif tOfa2BzsG7NCkYeUu=='closed_sites': ZGoH9TFqRbAtODi36dag = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,'list','GLOBALSEARCH_CLOSED',(jXPWwl4aH0OR9ILzMT5usS,rb2kdCWl1zJhmcnfxAi))
	if not ZGoH9TFqRbAtODi36dag:
		Wu6THcbvsRZdXSz4nwlCVy = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		bdzvPE1KBTfkMj04QAG5hY7ouqZD = 'هل تريد الآن البحث في جميع المواقع عن \n "[COLOR FFFFFF00] '+rb2kdCWl1zJhmcnfxAi+' [/COLOR]" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if tOfa2BzsG7NCkYeUu=='search_sites': LpdKxnIsY3Sy6qP = bdzvPE1KBTfkMj04QAG5hY7ouqZD
		else: LpdKxnIsY3Sy6qP = Wu6THcbvsRZdXSz4nwlCVy+bdzvPE1KBTfkMj04QAG5hY7ouqZD
		o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1('','','','رسالة من المبرمج',LpdKxnIsY3Sy6qP)
		if o07Z1tEB4n3ARCkVNu!=1: return
		LFmr6Jxpwe1OklbdUCnTBMAuaiq(False,False,False)
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q('NOTICE',jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+'   Search For: [ '+rb2kdCWl1zJhmcnfxAi+' ]')
		sbRe9dqK0mX8Zfyxo = 1
		for jXPWwl4aH0OR9ILzMT5usS in tKZCufmDlvG0jRQxE2JYyF:
			GlYCEhojTuxIXWyKqtwvzAiUaS[jXPWwl4aH0OR9ILzMT5usS] = []
			cFghemYEoaiSN2Iw8kpyZ6ud5XO = '_NODIALOGS_'
			if '-' in jXPWwl4aH0OR9ILzMT5usS: cFghemYEoaiSN2Iw8kpyZ6ud5XO = cFghemYEoaiSN2Iw8kpyZ6ud5XO+'_REMEMBERRESULTS__'+jXPWwl4aH0OR9ILzMT5usS+'_'
			YOb4ZFenMS08DN6yA3G5,ceL6qDxhFNo7,kUJng2Gx1u7br9Hs8MlFd = pdLiwcEWN2o4PQ(jXPWwl4aH0OR9ILzMT5usS)
			if sbRe9dqK0mX8Zfyxo:
				MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(0.75)
				yDegLiBrqJOCHQsA87dUw0[jXPWwl4aH0OR9ILzMT5usS] = dM9DZS0pkxbqaf7W.Thread(target=ceL6qDxhFNo7,args=(rb2kdCWl1zJhmcnfxAi+cFghemYEoaiSN2Iw8kpyZ6ud5XO,))
				yDegLiBrqJOCHQsA87dUw0[jXPWwl4aH0OR9ILzMT5usS].start()
			else: ceL6qDxhFNo7(rb2kdCWl1zJhmcnfxAi+cFghemYEoaiSN2Iw8kpyZ6ud5XO)
			From8aTqdhCbPs(wPGkbaD7x6(jXPWwl4aH0OR9ILzMT5usS),'',MQbODJoPV2w8TEAg4zXZdjLxSW=1000)
		if sbRe9dqK0mX8Zfyxo:
			MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(2)
			for jXPWwl4aH0OR9ILzMT5usS in tKZCufmDlvG0jRQxE2JYyF:
				yDegLiBrqJOCHQsA87dUw0[jXPWwl4aH0OR9ILzMT5usS].join(10)
			MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(2)
		for jXPWwl4aH0OR9ILzMT5usS in tKZCufmDlvG0jRQxE2JYyF:
			YOb4ZFenMS08DN6yA3G5,ceL6qDxhFNo7,kUJng2Gx1u7br9Hs8MlFd = pdLiwcEWN2o4PQ(jXPWwl4aH0OR9ILzMT5usS)
			for O9AXtawrzj1Y2VUgc8oNFv6p in D6DrJsclfY:
				QTcZbyNIfxeU84vs5LBophFmqMAn6,WJr6B5imnN1Cypw,kk1GKyapocQZDAz,VRnfEFmJzUrSljM8,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,MMupPCxqkenwt6FlsbRILV37EAmB,stpvYViqku3,LGdFZQvKeU52s6H0DgjN = O9AXtawrzj1Y2VUgc8oNFv6p
				if kUJng2Gx1u7br9Hs8MlFd in WJr6B5imnN1Cypw:
					if 'IPTV-' in jXPWwl4aH0OR9ILzMT5usS and (239>=VRnfEFmJzUrSljM8>=230 or 289>=VRnfEFmJzUrSljM8>=280):
						if O9AXtawrzj1Y2VUgc8oNFv6p in GlYCEhojTuxIXWyKqtwvzAiUaS['IPTV-LIVE']: continue
						if O9AXtawrzj1Y2VUgc8oNFv6p in GlYCEhojTuxIXWyKqtwvzAiUaS['IPTV-MOVIES']: continue
						if O9AXtawrzj1Y2VUgc8oNFv6p in GlYCEhojTuxIXWyKqtwvzAiUaS['IPTV-SERIES']: continue
						if 'صفحة' not in WJr6B5imnN1Cypw:
							if   QTcZbyNIfxeU84vs5LBophFmqMAn6=='live': jXPWwl4aH0OR9ILzMT5usS = 'IPTV-LIVE'
							elif QTcZbyNIfxeU84vs5LBophFmqMAn6=='video': jXPWwl4aH0OR9ILzMT5usS = 'IPTV-MOVIES'
							elif QTcZbyNIfxeU84vs5LBophFmqMAn6=='folder': jXPWwl4aH0OR9ILzMT5usS = 'IPTV-SERIES'
						else:
							if   'LIVE' in kk1GKyapocQZDAz: jXPWwl4aH0OR9ILzMT5usS = 'IPTV-LIVE'
							elif 'MOVIES' in kk1GKyapocQZDAz: jXPWwl4aH0OR9ILzMT5usS = 'IPTV-MOVIES'
							elif 'SERIES' in kk1GKyapocQZDAz: jXPWwl4aH0OR9ILzMT5usS = 'IPTV-SERIES'
					elif 'M3U-' in jXPWwl4aH0OR9ILzMT5usS and 729>=VRnfEFmJzUrSljM8>=710:
						if O9AXtawrzj1Y2VUgc8oNFv6p in GlYCEhojTuxIXWyKqtwvzAiUaS['M3U-LIVE']: continue
						if O9AXtawrzj1Y2VUgc8oNFv6p in GlYCEhojTuxIXWyKqtwvzAiUaS['M3U-MOVIES']: continue
						if O9AXtawrzj1Y2VUgc8oNFv6p in GlYCEhojTuxIXWyKqtwvzAiUaS['M3U-SERIES']: continue
						if 'صفحة' not in WJr6B5imnN1Cypw:
							if   QTcZbyNIfxeU84vs5LBophFmqMAn6=='live': jXPWwl4aH0OR9ILzMT5usS = 'M3U-LIVE'
							elif QTcZbyNIfxeU84vs5LBophFmqMAn6=='video': jXPWwl4aH0OR9ILzMT5usS = 'M3U-MOVIES'
							elif QTcZbyNIfxeU84vs5LBophFmqMAn6=='folder': jXPWwl4aH0OR9ILzMT5usS = 'M3U-SERIES'
						else:
							if   'LIVE' in kk1GKyapocQZDAz: jXPWwl4aH0OR9ILzMT5usS = 'M3U-LIVE'
							elif 'MOVIES' in kk1GKyapocQZDAz: jXPWwl4aH0OR9ILzMT5usS = 'M3U-MOVIES'
							elif 'SERIES' in kk1GKyapocQZDAz: jXPWwl4aH0OR9ILzMT5usS = 'M3U-SERIES'
					elif 'YOUTUBE-' in jXPWwl4aH0OR9ILzMT5usS and 149>=VRnfEFmJzUrSljM8>=140:
						if O9AXtawrzj1Y2VUgc8oNFv6p in GlYCEhojTuxIXWyKqtwvzAiUaS['YOUTUBE-CHANNELS']: continue
						if O9AXtawrzj1Y2VUgc8oNFv6p in GlYCEhojTuxIXWyKqtwvzAiUaS['YOUTUBE-PLAYLISTS']: continue
						if O9AXtawrzj1Y2VUgc8oNFv6p in GlYCEhojTuxIXWyKqtwvzAiUaS['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in WJr6B5imnN1Cypw or ':: ' in WJr6B5imnN1Cypw:
							continue
						else:
							if   VRnfEFmJzUrSljM8==144 and 'USER' in WJr6B5imnN1Cypw: jXPWwl4aH0OR9ILzMT5usS = 'YOUTUBE-CHANNELS'
							elif VRnfEFmJzUrSljM8==144 and 'CHNL' in WJr6B5imnN1Cypw: jXPWwl4aH0OR9ILzMT5usS = 'YOUTUBE-CHANNELS'
							elif VRnfEFmJzUrSljM8==144 and 'LIST' in WJr6B5imnN1Cypw: jXPWwl4aH0OR9ILzMT5usS = 'YOUTUBE-PLAYLISTS'
							elif VRnfEFmJzUrSljM8==143: jXPWwl4aH0OR9ILzMT5usS = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in jXPWwl4aH0OR9ILzMT5usS and 419>=VRnfEFmJzUrSljM8>=400:
						if O9AXtawrzj1Y2VUgc8oNFv6p in GlYCEhojTuxIXWyKqtwvzAiUaS['DAILYMOTION-PLAYLISTS']: continue
						if O9AXtawrzj1Y2VUgc8oNFv6p in GlYCEhojTuxIXWyKqtwvzAiUaS['DAILYMOTION-CHANNELS']: continue
						if O9AXtawrzj1Y2VUgc8oNFv6p in GlYCEhojTuxIXWyKqtwvzAiUaS['DAILYMOTION-VIDEOS']: continue
						if O9AXtawrzj1Y2VUgc8oNFv6p in GlYCEhojTuxIXWyKqtwvzAiUaS['DAILYMOTION-TOPICS']: continue
						if   VRnfEFmJzUrSljM8 in [401,405]: jXPWwl4aH0OR9ILzMT5usS = 'DAILYMOTION-PLAYLISTS'
						elif VRnfEFmJzUrSljM8 in [402,406]: jXPWwl4aH0OR9ILzMT5usS = 'DAILYMOTION-CHANNELS'
						elif VRnfEFmJzUrSljM8 in [404]: jXPWwl4aH0OR9ILzMT5usS = 'DAILYMOTION-VIDEOS'
						elif VRnfEFmJzUrSljM8 in [415]: jXPWwl4aH0OR9ILzMT5usS = 'DAILYMOTION-LIVES'
						elif VRnfEFmJzUrSljM8 in [412,413]: jXPWwl4aH0OR9ILzMT5usS = 'DAILYMOTION-TOPICS'
					elif 'PANET-' in jXPWwl4aH0OR9ILzMT5usS and 39>=VRnfEFmJzUrSljM8>=30:
						if O9AXtawrzj1Y2VUgc8oNFv6p in GlYCEhojTuxIXWyKqtwvzAiUaS['PANET-SERIES']: continue
						if O9AXtawrzj1Y2VUgc8oNFv6p in GlYCEhojTuxIXWyKqtwvzAiUaS['PANET-MOVIES']: continue
						if   VRnfEFmJzUrSljM8 in [32,39]: jXPWwl4aH0OR9ILzMT5usS = 'PANET-SERIES'
						elif VRnfEFmJzUrSljM8 in [33,39]: jXPWwl4aH0OR9ILzMT5usS = 'PANET-MOVIES'
					elif 'IFILM-' in jXPWwl4aH0OR9ILzMT5usS and 29>=VRnfEFmJzUrSljM8>=20:
						if O9AXtawrzj1Y2VUgc8oNFv6p in GlYCEhojTuxIXWyKqtwvzAiUaS['IFILM-ARABIC']: continue
						if O9AXtawrzj1Y2VUgc8oNFv6p in GlYCEhojTuxIXWyKqtwvzAiUaS['IFILM-ENGLISH']: continue
						if   '/ar.' in kk1GKyapocQZDAz: jXPWwl4aH0OR9ILzMT5usS = 'IFILM-ARABIC'
						elif '/en.' in kk1GKyapocQZDAz: jXPWwl4aH0OR9ILzMT5usS = 'IFILM-ENGLISH'
					GlYCEhojTuxIXWyKqtwvzAiUaS[jXPWwl4aH0OR9ILzMT5usS].append(O9AXtawrzj1Y2VUgc8oNFv6p)
		D6DrJsclfY[:] = []
		for jXPWwl4aH0OR9ILzMT5usS in list(GlYCEhojTuxIXWyKqtwvzAiUaS.keys()):
			OFezHAfk3mpXlBKhGUaiCo5[jXPWwl4aH0OR9ILzMT5usS] = []
			I6KzQPNf2CoTVRLqBcZOnXJWA4FpjS[jXPWwl4aH0OR9ILzMT5usS] = []
			for QTcZbyNIfxeU84vs5LBophFmqMAn6,WJr6B5imnN1Cypw,kk1GKyapocQZDAz,VRnfEFmJzUrSljM8,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,MMupPCxqkenwt6FlsbRILV37EAmB,stpvYViqku3,LGdFZQvKeU52s6H0DgjN in GlYCEhojTuxIXWyKqtwvzAiUaS[jXPWwl4aH0OR9ILzMT5usS]:
				O9AXtawrzj1Y2VUgc8oNFv6p = (QTcZbyNIfxeU84vs5LBophFmqMAn6,WJr6B5imnN1Cypw,kk1GKyapocQZDAz,VRnfEFmJzUrSljM8,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,MMupPCxqkenwt6FlsbRILV37EAmB,stpvYViqku3,LGdFZQvKeU52s6H0DgjN)
				if 'صفحة' in WJr6B5imnN1Cypw and QTcZbyNIfxeU84vs5LBophFmqMAn6=='folder': I6KzQPNf2CoTVRLqBcZOnXJWA4FpjS[jXPWwl4aH0OR9ILzMT5usS].append(O9AXtawrzj1Y2VUgc8oNFv6p)
				else: OFezHAfk3mpXlBKhGUaiCo5[jXPWwl4aH0OR9ILzMT5usS].append(O9AXtawrzj1Y2VUgc8oNFv6p)
		Q4HbNgVejIP = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157,'','','','','')]
		for jXPWwl4aH0OR9ILzMT5usS in TpKmsy5SzeW:
			if jXPWwl4aH0OR9ILzMT5usS==wAPUj1vGyWBcFlKDa8ikm2[0]: Q4HbNgVejIP = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة وعامة - كثيرة المشاكل[/COLOR]','',157,'','','','','')]
			elif jXPWwl4aH0OR9ILzMT5usS==isHEfxUCa24bR9kGtF7[0]: Q4HbNgVejIP = [('link','[COLOR FFC89008]مواقع سيرفرات عامة - كثيرة المشاكل[/COLOR]','',157,'','','','','')]
			elif jXPWwl4aH0OR9ILzMT5usS==ylLUS9Wt8xE1uZ7Czcoba[0]: Q4HbNgVejIP = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157,'','','','','')]
			if jXPWwl4aH0OR9ILzMT5usS not in OFezHAfk3mpXlBKhGUaiCo5.keys(): continue
			if OFezHAfk3mpXlBKhGUaiCo5[jXPWwl4aH0OR9ILzMT5usS]:
				hgmb7JtQ0IiWDVl = wPGkbaD7x6(jXPWwl4aH0OR9ILzMT5usS)
				ssZdhHyTAY2 = [('link','[COLOR FFFFFF00]===== '+hgmb7JtQ0IiWDVl+' =====[/COLOR]','',9999,'','','','','')]
				if 0: N76NWkG4Ht = rb2kdCWl1zJhmcnfxAi+' - '+'بحث'+' '+hgmb7JtQ0IiWDVl
				else: N76NWkG4Ht = 'بحث'+' '+hgmb7JtQ0IiWDVl+' - '+rb2kdCWl1zJhmcnfxAi
				if len(OFezHAfk3mpXlBKhGUaiCo5[jXPWwl4aH0OR9ILzMT5usS])<8: x5naQvlZj7Y6mSVtbru = []
				else:
					dnM0QwUuoJm7ckRrg1ZtBizjAKS2N = '[COLOR FFC89008]'+N76NWkG4Ht+'[/COLOR]'
					x5naQvlZj7Y6mSVtbru = [('folder',mmDwMlfoHtG5XT19VLIWqCR8i+dnM0QwUuoJm7ckRrg1ZtBizjAKS2N,'closed_sites',542,'',jXPWwl4aH0OR9ILzMT5usS,rb2kdCWl1zJhmcnfxAi,'','')]
				iTFMN7qQXbaA = OFezHAfk3mpXlBKhGUaiCo5[jXPWwl4aH0OR9ILzMT5usS]+I6KzQPNf2CoTVRLqBcZOnXJWA4FpjS[jXPWwl4aH0OR9ILzMT5usS]
				XXUhPV0CYtivDoq7TL += Q4HbNgVejIP+ssZdhHyTAY2+iTFMN7qQXbaA[:7]+x5naQvlZj7Y6mSVtbru
				liqHnPNukMVA0vw9Us8Wj3 = [('folder',mmDwMlfoHtG5XT19VLIWqCR8i+N76NWkG4Ht,'closed_sites',542,'',jXPWwl4aH0OR9ILzMT5usS,rb2kdCWl1zJhmcnfxAi,'','')]
				TBP3EmNKAyrCQ5lk0HhMJ += Q4HbNgVejIP+liqHnPNukMVA0vw9Us8Wj3
				Q4HbNgVejIP = []
				Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,'GLOBALSEARCH_CLOSED',(jXPWwl4aH0OR9ILzMT5usS,rb2kdCWl1zJhmcnfxAi),iTFMN7qQXbaA,OrZFej19nLcNdh2WKRuDJC)
		Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,'GLOBALSEARCH_OPENED',rb2kdCWl1zJhmcnfxAi,XXUhPV0CYtivDoq7TL,OrZFej19nLcNdh2WKRuDJC)
		HHg0f8U75SdzxEcbt1JN(UkFh2OXjuTZEaexC,'GLOBALSEARCH_SITES',rb2kdCWl1zJhmcnfxAi)
		Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,'GLOBALSEARCH_SITES',mmDwMlfoHtG5XT19VLIWqCR8i+rb2kdCWl1zJhmcnfxAi,TBP3EmNKAyrCQ5lk0HhMJ,OrZFej19nLcNdh2WKRuDJC)
		aHKzv76JCVnprbY8w('','','رسالة من المبرمج','البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم لكي تستطيع العودة إليها بدون عمل بحث جديد')
		if tOfa2BzsG7NCkYeUu=='listed_sites' and TBP3EmNKAyrCQ5lk0HhMJ: ZGoH9TFqRbAtODi36dag = TBP3EmNKAyrCQ5lk0HhMJ
		else: ZGoH9TFqRbAtODi36dag = XXUhPV0CYtivDoq7TL
	if tOfa2BzsG7NCkYeUu!='search_sites':
		for QTcZbyNIfxeU84vs5LBophFmqMAn6,WJr6B5imnN1Cypw,kk1GKyapocQZDAz,VRnfEFmJzUrSljM8,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,MMupPCxqkenwt6FlsbRILV37EAmB,stpvYViqku3,LGdFZQvKeU52s6H0DgjN in ZGoH9TFqRbAtODi36dag:
			if tOfa2BzsG7NCkYeUu in ['listed_sites','opened_sites'] and 'صفحة' in WJr6B5imnN1Cypw and QTcZbyNIfxeU84vs5LBophFmqMAn6=='folder': continue
			cd0aGwCPExbFU5pYNu8r(QTcZbyNIfxeU84vs5LBophFmqMAn6,WJr6B5imnN1Cypw,kk1GKyapocQZDAz,VRnfEFmJzUrSljM8,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,MMupPCxqkenwt6FlsbRILV37EAmB,stpvYViqku3,LGdFZQvKeU52s6H0DgjN)
	LFmr6Jxpwe1OklbdUCnTBMAuaiq('','','')
	return
def irmLUsAPkD2ndfJb(rb2kdCWl1zJhmcnfxAi=''):
	fPlzJqILutFmRv6NYy,cFghemYEoaiSN2Iw8kpyZ6ud5XO,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(rb2kdCWl1zJhmcnfxAi)
	if not fPlzJqILutFmRv6NYy:
		fPlzJqILutFmRv6NYy = yMRXZIpKxlSkaE6iCO()
		if not fPlzJqILutFmRv6NYy: return
		fPlzJqILutFmRv6NYy = fPlzJqILutFmRv6NYy.lower()
	LOHZ4o9m7p6ebfTYXGIdz5PWs3q('NOTICE',jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+'   Search For: [ '+fPlzJqILutFmRv6NYy+' ]')
	aKRILTAj1HC5c = fPlzJqILutFmRv6NYy+cFghemYEoaiSN2Iw8kpyZ6ud5XO
	if 0: aa3MG9HiDjsL0RqBuefpVWth,JVCtFqbiU0W83efEKm2wg = fPlzJqILutFmRv6NYy+' - ',''
	else: aa3MG9HiDjsL0RqBuefpVWth,JVCtFqbiU0W83efEKm2wg = '',' - '+fPlzJqILutFmRv6NYy
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157)
	cd0aGwCPExbFU5pYNu8r('folder','_M3U_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث M3U'+JVCtFqbiU0W83efEKm2wg,'',719,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_IPT_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث IPTV'+JVCtFqbiU0W83efEKm2wg,'',239,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_BKR_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع بكرا'+JVCtFqbiU0W83efEKm2wg,'',379,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_ART_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع تونز عربية'+JVCtFqbiU0W83efEKm2wg,'',739,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_KRB_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع قناة كربلاء'+JVCtFqbiU0W83efEKm2wg,'',329,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_FH1_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع فاصل الأول'+JVCtFqbiU0W83efEKm2wg,'',579,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_KTV_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع كتكوت تيفي'+JVCtFqbiU0W83efEKm2wg,'',819,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_EB1_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع ايجي بيست 1'+JVCtFqbiU0W83efEKm2wg,'',779,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_EB2_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع ايجي بيست 2'+JVCtFqbiU0W83efEKm2wg,'',789,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_IFL_'+aa3MG9HiDjsL0RqBuefpVWth+'  بحث موقع قناة آي فيلم'+JVCtFqbiU0W83efEKm2wg+'  ','',29,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_AKO_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع أكوام القديم'+JVCtFqbiU0W83efEKm2wg,'',79,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_AKW_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع أكوام الجديد'+JVCtFqbiU0W83efEKm2wg,'',249,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_MRF_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع قناة المعارف'+JVCtFqbiU0W83efEKm2wg,'',49,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_SHM_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع شوف ماكس'+JVCtFqbiU0W83efEKm2wg,'',59,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008]مواقع سيرفرات خاصة وعامة - كثيرة المشاكل[/COLOR]','',157)
	cd0aGwCPExbFU5pYNu8r('folder','_FJS_'+aa3MG9HiDjsL0RqBuefpVWth+' بحث موقع فجر شو'+JVCtFqbiU0W83efEKm2wg+' ','',399,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_TVF_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع تيفي فان'+JVCtFqbiU0W83efEKm2wg,'',469,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_LDN_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع لودي نت'+JVCtFqbiU0W83efEKm2wg,'',459,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_CMN_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع سيما ناو'+JVCtFqbiU0W83efEKm2wg,'',309,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_WCM_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع وي سيما'+JVCtFqbiU0W83efEKm2wg,'',569,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_SHN_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع شاهد نيوز'+JVCtFqbiU0W83efEKm2wg,'',589,'','',aKRILTAj1HC5c+'_NODIALOGS_')
	cd0aGwCPExbFU5pYNu8r('folder','_ARS_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع عرب سييد'+JVCtFqbiU0W83efEKm2wg,'',259,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_CCB_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع سيما كلوب'+JVCtFqbiU0W83efEKm2wg,'',829,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_SH4_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع شاهد فوريو'+JVCtFqbiU0W83efEKm2wg,'',119,'','',aKRILTAj1HC5c+'_NODIALOGS_')
	cd0aGwCPExbFU5pYNu8r('folder','_SHT_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع شوفها تيفي'+JVCtFqbiU0W83efEKm2wg,'',649,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008]مواقع سيرفرات عامة - كثيرة المشاكل[/COLOR]','',157)
	cd0aGwCPExbFU5pYNu8r('folder','_FST_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع فوستا'+JVCtFqbiU0W83efEKm2wg,'',609,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_FBK_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع فبركة'+JVCtFqbiU0W83efEKm2wg,'',629,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_YQT_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع ياقوت'+JVCtFqbiU0W83efEKm2wg,'',669,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_BRS_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع برستيج'+JVCtFqbiU0W83efEKm2wg,'',659,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_HLC_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع هلا سيما'+JVCtFqbiU0W83efEKm2wg,'',89,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_DR7_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع دراما صح'+JVCtFqbiU0W83efEKm2wg,'',689,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_CMF_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع سيما فانز'+JVCtFqbiU0W83efEKm2wg,'',99,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_CML_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع سيما لايت'+JVCtFqbiU0W83efEKm2wg,'',479,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_ABD_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع سيما عبدو'+JVCtFqbiU0W83efEKm2wg,'',559,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_C4H_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع سيما 400'+JVCtFqbiU0W83efEKm2wg,'',699,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_AHK_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع أهواك تيفي'+JVCtFqbiU0W83efEKm2wg,'',619,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_EB4_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع ايجي بيست 4'+JVCtFqbiU0W83efEKm2wg,'',809,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157)
	cd0aGwCPExbFU5pYNu8r('folder','_YUT_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع يوتيوب'+JVCtFqbiU0W83efEKm2wg,'',149,'','',aKRILTAj1HC5c)
	cd0aGwCPExbFU5pYNu8r('folder','_DLM_'+aa3MG9HiDjsL0RqBuefpVWth+'بحث موقع ديلي موشن'+JVCtFqbiU0W83efEKm2wg,'',409,'','',aKRILTAj1HC5c)
	return
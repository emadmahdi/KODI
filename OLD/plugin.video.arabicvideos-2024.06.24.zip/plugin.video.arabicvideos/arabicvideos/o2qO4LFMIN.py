# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'ARBLIONZ'
headers = { 'User-Agent' : '' }
mmDwMlfoHtG5XT19VLIWqCR8i = '_ARL_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
DDXTwbRBaj3e2rSsPQ = ['عروض المصارعة','الكل','الرئيسية','العاب','برامج كمبيوتر','موبايل و جوال','القسم الاسلامي']
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==200: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==201: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url)
	elif mode==202: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==203: zpXG3Ky6ou8ndWHkb4 = hWPvGlXZ5arzV7(url)
	elif mode==204: zpXG3Ky6ou8ndWHkb4 = hWJg9P6lEYT5aGDizcb(url,'FILTERS___'+text)
	elif mode==205: zpXG3Ky6ou8ndWHkb4 = hWJg9P6lEYT5aGDizcb(url,'CATEGORIES___'+text)
	elif mode==209: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',209,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فلتر محدد',NBm2aWhPzoTpdYn,205)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فلتر كامل',NBm2aWhPzoTpdYn,204)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'مميزة',NBm2aWhPzoTpdYn+'??trending',201)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'أفلام مميزة',NBm2aWhPzoTpdYn+'??trending_movies',201)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'مسلسلات مميزة',NBm2aWhPzoTpdYn+'??trending_series',201)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'الصفحة الرئيسية',NBm2aWhPzoTpdYn+'??mainpage',201)
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',NBm2aWhPzoTpdYn,'',headers,True,'','ARBLIONZ-MENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('categories-tabs(.*?)MainRow',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('data-get="(.*?)".*?<h3>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for filter,title in items:
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/ajax/home/more?filter='+filter
			cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,201)
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('navigation-menu(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
		title = title.strip(' ')
		if not any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in DDXTwbRBaj3e2rSsPQ):
			cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,201)
	return BBlXpmUyhFDwNtCVAHoE
def xoiXMWjJC3pnQqurIGPkRSl8e(url):
	if '??' in url: url,type = url.split('??')
	else: type = ''
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'',headers,True,'','ARBLIONZ-TITLES-2nd')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content.encode('utf8')
	if 'getposts' in url: EeQqAGc0W5r6nlBbChwfZL = [BBlXpmUyhFDwNtCVAHoE]
	elif type=='trending':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('MasterSlider(.*?)</div>\n *</div>\n *</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	elif type=='trending_movies':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('Slider_1(.*?)</div>.</div>.</div>.</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	elif type=='trending_series':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('Slider_2(.*?)</div>.</div>.</div>.</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	elif type=='111mainpage':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="container page-content"(.*?)class="tabs"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	else:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('page-content(.*?)main-footer',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not EeQqAGc0W5r6nlBbChwfZL: return
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	O79xwZs3Cr42HinDSRfgMu = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	items = GGvHJKP9LUxEk10Fw.findall('content-box".*?src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	if not items:
		items = GGvHJKP9LUxEk10Fw.findall('SliderItem".*?href="(.*?)".*?image: url\((.*?)\).*?<h2>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		gI487voLsArVqW6Ffp,rgeSdYacsZyqQpA3NvTEu,xut3LAibydXZnzkpBaKOsgew70 = zip(*items)
		items = zip(rgeSdYacsZyqQpA3NvTEu,gI487voLsArVqW6Ffp,xut3LAibydXZnzkpBaKOsgew70)
	IcJOGsq3Ff7EmkiLx = []
	for VFqpJjRySZvgi,ELbNB92cOh5dqtpVmi40kY,title in items:
		if '/series/' in ELbNB92cOh5dqtpVmi40kY: continue
		ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.strip('/')
		title = DwNC3gEonizsB6a0v1F(title)
		title = title.strip(' ')
		if '/film/' in ELbNB92cOh5dqtpVmi40kY or any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in O79xwZs3Cr42HinDSRfgMu):
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,202,VFqpJjRySZvgi)
		elif '/episode/' in ELbNB92cOh5dqtpVmi40kY and 'الحلقة' in title:
			qUGxSK2VwsiBAdkDZnJ605vQeg = GGvHJKP9LUxEk10Fw.findall('(.*?) الحلقة \d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
			if qUGxSK2VwsiBAdkDZnJ605vQeg:
				title = '_MOD_' + qUGxSK2VwsiBAdkDZnJ605vQeg[0]
				if title not in IcJOGsq3Ff7EmkiLx:
					cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,203,VFqpJjRySZvgi)
					IcJOGsq3Ff7EmkiLx.append(title)
		elif '/pack/' in ELbNB92cOh5dqtpVmi40kY:
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY+'/films',201,VFqpJjRySZvgi)
		else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,203,VFqpJjRySZvgi)
	if type in ['','mainpage']:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="pagination(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
			items = GGvHJKP9LUxEk10Fw.findall('href=["\'](http.*?)["\'].*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				ELbNB92cOh5dqtpVmi40kY = DwNC3gEonizsB6a0v1F(ELbNB92cOh5dqtpVmi40kY)
				title = DwNC3gEonizsB6a0v1F(title)
				title = title.replace('الصفحة ','')
				if 'search?s=' in url:
					gkTSWpYd3XR47D8xPzJU9 = ELbNB92cOh5dqtpVmi40kY.split('page=')[1]
					cdT3BKM9CNHkQUuzalgvI = url.split('page=')[1]
					ELbNB92cOh5dqtpVmi40kY = url.replace('page='+cdT3BKM9CNHkQUuzalgvI,'page='+gkTSWpYd3XR47D8xPzJU9)
				if title!='': cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,201)
	return
def hWPvGlXZ5arzV7(url):
	jBgqdhKY5fb7ESyRnOiAGWZok9t2r,items,KQzlI18oVMbCAqvUN = -1,[],[]
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'',headers,True,'','ARBLIONZ-EPISODES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content.encode('utf8')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('ti-list-numbered(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		KQzlI18oVMbCAqvUN = []
		EHDeldN7L2k19JBUqhmsuSXiwV = ''.join(EeQqAGc0W5r6nlBbChwfZL)
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)"',EHDeldN7L2k19JBUqhmsuSXiwV,GGvHJKP9LUxEk10Fw.DOTALL)
	items.append(url)
	items = set(items)
	for ELbNB92cOh5dqtpVmi40kY in items:
		ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.strip('/')
		title = '_MOD_' + ELbNB92cOh5dqtpVmi40kY.split('/')[-1].replace('-',' ')
		vAxfDHyjwR6KM74IGEJl0dasY = GGvHJKP9LUxEk10Fw.findall('الحلقة-(\d+)',ELbNB92cOh5dqtpVmi40kY.split('/')[-1],GGvHJKP9LUxEk10Fw.DOTALL)
		if vAxfDHyjwR6KM74IGEJl0dasY: vAxfDHyjwR6KM74IGEJl0dasY = vAxfDHyjwR6KM74IGEJl0dasY[0]
		else: vAxfDHyjwR6KM74IGEJl0dasY = '0'
		KQzlI18oVMbCAqvUN.append([ELbNB92cOh5dqtpVmi40kY,title,vAxfDHyjwR6KM74IGEJl0dasY])
	items = sorted(KQzlI18oVMbCAqvUN, reverse=False, key=lambda key: int(key[2]))
	CYhD3frGVSq = str(items).count('/season/')
	jBgqdhKY5fb7ESyRnOiAGWZok9t2r = str(items).count('/episode/')
	if CYhD3frGVSq>1 and jBgqdhKY5fb7ESyRnOiAGWZok9t2r>0 and '/season/' not in url:
		for ELbNB92cOh5dqtpVmi40kY,title,vAxfDHyjwR6KM74IGEJl0dasY in items:
			if '/season/' in ELbNB92cOh5dqtpVmi40kY:
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,203)
	else:
		for ELbNB92cOh5dqtpVmi40kY,title,vAxfDHyjwR6KM74IGEJl0dasY in items:
			if '/season/' not in ELbNB92cOh5dqtpVmi40kY:
				title = GhPlajzTxY8(title)
				cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,202)
	return
def SUfe4unWoXBNFz90xqy(url):
	zzvBg3ShiamAZ = []
	Z0HoXM261lLgxBzjUK = url.split('/')
	gYaBcv86kLS = NBm2aWhPzoTpdYn
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',url,'',headers,True,True,'ARBLIONZ-PLAY-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content.encode('utf8')
	id = GGvHJKP9LUxEk10Fw.findall('postId:"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not id: id = GGvHJKP9LUxEk10Fw.findall('post_id=(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not id: id = GGvHJKP9LUxEk10Fw.findall('post-id="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if id: id = id[0]
	if '/watch/' in BBlXpmUyhFDwNtCVAHoE:
		dR2vHyAtl8pJN1 = url.replace(Z0HoXM261lLgxBzjUK[3],'watch')
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',dR2vHyAtl8pJN1,'',headers,True,True,'ARBLIONZ-PLAY-2nd')
		X3in5vNhqwWEG2TafmVCrFbSYDxjoK = WbTGMHnDysdYZ2lFA.content.encode('utf8')
		LLzAFbvEKf1H = GGvHJKP9LUxEk10Fw.findall('data-embedd="(.*?)".*?alt="(.*?)"',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
		GzpIUylJrXRteaKPiNDLHuScmbgj = GGvHJKP9LUxEk10Fw.findall('data-embedd=".*?(http.*?)("|&quot;)',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
		TTfIkSsybudK = GGvHJKP9LUxEk10Fw.findall('src=&quot;(.*?)&quot;.*?>(.*?)<',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.IGNORECASE)
		WfwYon0e2zSEgNVGqIm67 = GGvHJKP9LUxEk10Fw.findall('data-embedd="(.*?)">\n*.*?server_image">\n(.*?)\n',X3in5vNhqwWEG2TafmVCrFbSYDxjoK)
		tWvhnR7ISq1xoOG4Q3ir = GGvHJKP9LUxEk10Fw.findall('src=&quot;(.*?)&quot;.*?alt="(.*?)"',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.IGNORECASE)
		nOpPQmvxrIMqlogcDdb05HY = GGvHJKP9LUxEk10Fw.findall('server="(.*?)".*?<span>(.*?)<',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.IGNORECASE)
		items = LLzAFbvEKf1H+GzpIUylJrXRteaKPiNDLHuScmbgj+TTfIkSsybudK+WfwYon0e2zSEgNVGqIm67+tWvhnR7ISq1xoOG4Q3ir+nOpPQmvxrIMqlogcDdb05HY
		if not items:
			items = GGvHJKP9LUxEk10Fw.findall('<span>(.*?)</span>.*?src="(.*?)"',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.IGNORECASE)
			items = [(fNhyo6e2MYzm8,rGQvqJk35uZ0atUwRb) for rGQvqJk35uZ0atUwRb,fNhyo6e2MYzm8 in items]
		for C83UXWf15zdwLA0,title in items:
			if '.png' in C83UXWf15zdwLA0: continue
			if '.jpg' in C83UXWf15zdwLA0: continue
			if '&quot;' in C83UXWf15zdwLA0: continue
			dDZQSEGRTo9g85x1C = GGvHJKP9LUxEk10Fw.findall('\d\d\d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
			if dDZQSEGRTo9g85x1C:
				dDZQSEGRTo9g85x1C = dDZQSEGRTo9g85x1C[0]
				if dDZQSEGRTo9g85x1C in title: title = title.replace(dDZQSEGRTo9g85x1C+'p','').replace(dDZQSEGRTo9g85x1C,'').strip(' ')
				dDZQSEGRTo9g85x1C = '____'+dDZQSEGRTo9g85x1C
			else: dDZQSEGRTo9g85x1C = ''
			if C83UXWf15zdwLA0.isdigit():
				ELbNB92cOh5dqtpVmi40kY = gYaBcv86kLS+'/?postid='+id+'&serverid='+C83UXWf15zdwLA0+'?named='+title+'__watch'+dDZQSEGRTo9g85x1C
			else:
				if 'http' not in C83UXWf15zdwLA0: C83UXWf15zdwLA0 = 'http:'+C83UXWf15zdwLA0
				dDZQSEGRTo9g85x1C = GGvHJKP9LUxEk10Fw.findall('\d\d\d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
				if dDZQSEGRTo9g85x1C: dDZQSEGRTo9g85x1C = '____'+dDZQSEGRTo9g85x1C[0]
				else: dDZQSEGRTo9g85x1C = ''
				ELbNB92cOh5dqtpVmi40kY = C83UXWf15zdwLA0+'?named=__watch'+dDZQSEGRTo9g85x1C
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	if 'DownloadNow' in BBlXpmUyhFDwNtCVAHoE:
		BBYvCiQGe8RdpyAagfS72mZclxb5 = { 'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8' }
		dR2vHyAtl8pJN1 = url+'/download'
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',dR2vHyAtl8pJN1,'',BBYvCiQGe8RdpyAagfS72mZclxb5,True,'','ARBLIONZ-PLAY-3rd')
		X3in5vNhqwWEG2TafmVCrFbSYDxjoK = WbTGMHnDysdYZ2lFA.content.encode('utf8')
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('<ul class="download-items(.*?)</ul>',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
		for UCEFMfKbgpd in EeQqAGc0W5r6nlBbChwfZL:
			items = GGvHJKP9LUxEk10Fw.findall('href="(http.*?)".*?<span>(.*?)<.*?<p>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,name,dDZQSEGRTo9g85x1C in items:
				ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named='+name+'__download'+'____'+dDZQSEGRTo9g85x1C
				zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	elif '/download/' in BBlXpmUyhFDwNtCVAHoE:
		BBYvCiQGe8RdpyAagfS72mZclxb5 = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' }
		dR2vHyAtl8pJN1 = gYaBcv86kLS + '/ajaxCenter?_action=getdownloadlinks&postId='+id
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',dR2vHyAtl8pJN1,'',BBYvCiQGe8RdpyAagfS72mZclxb5,True,True,'ARBLIONZ-PLAY-4th')
		X3in5vNhqwWEG2TafmVCrFbSYDxjoK = WbTGMHnDysdYZ2lFA.content.encode('utf8')
		if 'download-btns' in X3in5vNhqwWEG2TafmVCrFbSYDxjoK:
			TTfIkSsybudK = GGvHJKP9LUxEk10Fw.findall('href="(.*?)"',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
			for XwyU6PQgprMI0 in TTfIkSsybudK:
				if '/page/' not in XwyU6PQgprMI0 and 'http' in XwyU6PQgprMI0:
					XwyU6PQgprMI0 = XwyU6PQgprMI0+'?named=__download'
					zzvBg3ShiamAZ.append(XwyU6PQgprMI0)
				elif '/page/' in XwyU6PQgprMI0:
					dDZQSEGRTo9g85x1C = ''
					WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',XwyU6PQgprMI0,'',headers,True,True,'ARBLIONZ-PLAY-5th')
					kA2Y8EVcsMo9SpyCmWbKaDeZ = WbTGMHnDysdYZ2lFA.content.encode('utf8')
					EHDeldN7L2k19JBUqhmsuSXiwV = GGvHJKP9LUxEk10Fw.findall('(<strong>.*?)-----',kA2Y8EVcsMo9SpyCmWbKaDeZ,GGvHJKP9LUxEk10Fw.DOTALL)
					for oSaQ12urny64V5AtHpxm0R7fzOeE in EHDeldN7L2k19JBUqhmsuSXiwV:
						RYcDahmQfJKqTeEL9Pxzr = ''
						WfwYon0e2zSEgNVGqIm67 = GGvHJKP9LUxEk10Fw.findall('<strong>(.*?)</strong>',oSaQ12urny64V5AtHpxm0R7fzOeE,GGvHJKP9LUxEk10Fw.DOTALL)
						for Ri3vwfZaL9EGMN7zQxFeloJDPWm4nq in WfwYon0e2zSEgNVGqIm67:
							BrVNsC72UYWES4A = GGvHJKP9LUxEk10Fw.findall('\d\d\d+',Ri3vwfZaL9EGMN7zQxFeloJDPWm4nq,GGvHJKP9LUxEk10Fw.DOTALL)
							if BrVNsC72UYWES4A:
								dDZQSEGRTo9g85x1C = '____'+BrVNsC72UYWES4A[0]
								break
						for Ri3vwfZaL9EGMN7zQxFeloJDPWm4nq in reversed(WfwYon0e2zSEgNVGqIm67):
							BrVNsC72UYWES4A = GGvHJKP9LUxEk10Fw.findall('\w\w+',Ri3vwfZaL9EGMN7zQxFeloJDPWm4nq,GGvHJKP9LUxEk10Fw.DOTALL)
							if BrVNsC72UYWES4A:
								RYcDahmQfJKqTeEL9Pxzr = BrVNsC72UYWES4A[0]
								break
						tWvhnR7ISq1xoOG4Q3ir = GGvHJKP9LUxEk10Fw.findall('href="(.*?)"',oSaQ12urny64V5AtHpxm0R7fzOeE,GGvHJKP9LUxEk10Fw.DOTALL)
						for rhTzKA51FXcGxsYWJQgUL in tWvhnR7ISq1xoOG4Q3ir:
							rhTzKA51FXcGxsYWJQgUL = rhTzKA51FXcGxsYWJQgUL+'?named='+RYcDahmQfJKqTeEL9Pxzr+'__download'+dDZQSEGRTo9g85x1C
							zzvBg3ShiamAZ.append(rhTzKA51FXcGxsYWJQgUL)
		elif 'slow-motion' in X3in5vNhqwWEG2TafmVCrFbSYDxjoK:
			X3in5vNhqwWEG2TafmVCrFbSYDxjoK = X3in5vNhqwWEG2TafmVCrFbSYDxjoK.replace('<h6 ','==END== ==START==')+'==END=='
			X3in5vNhqwWEG2TafmVCrFbSYDxjoK = X3in5vNhqwWEG2TafmVCrFbSYDxjoK.replace('<h3 ','==END== ==START==')+'==END=='
			xxFnUol65bu4OJzyArcDCSgEKXIj = GGvHJKP9LUxEk10Fw.findall('==START==(.*?)==END==',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
			if xxFnUol65bu4OJzyArcDCSgEKXIj:
				for oSaQ12urny64V5AtHpxm0R7fzOeE in xxFnUol65bu4OJzyArcDCSgEKXIj:
					if 'href=' not in oSaQ12urny64V5AtHpxm0R7fzOeE: continue
					tpXOZkgcfs2q57 = ''
					WfwYon0e2zSEgNVGqIm67 = GGvHJKP9LUxEk10Fw.findall('slow-motion">(.*?)<',oSaQ12urny64V5AtHpxm0R7fzOeE,GGvHJKP9LUxEk10Fw.DOTALL)
					for Ri3vwfZaL9EGMN7zQxFeloJDPWm4nq in WfwYon0e2zSEgNVGqIm67:
						BrVNsC72UYWES4A = GGvHJKP9LUxEk10Fw.findall('\d\d\d+',Ri3vwfZaL9EGMN7zQxFeloJDPWm4nq,GGvHJKP9LUxEk10Fw.DOTALL)
						if BrVNsC72UYWES4A:
							tpXOZkgcfs2q57 = '____'+BrVNsC72UYWES4A[0]
							break
					WfwYon0e2zSEgNVGqIm67 = GGvHJKP9LUxEk10Fw.findall('<td>(.*?)</td>.*?href="(http.*?)"',oSaQ12urny64V5AtHpxm0R7fzOeE,GGvHJKP9LUxEk10Fw.DOTALL)
					if WfwYon0e2zSEgNVGqIm67:
						for RYcDahmQfJKqTeEL9Pxzr,PsUQu1lnv7FrDJRoYA9B24hWLKc in WfwYon0e2zSEgNVGqIm67:
							PsUQu1lnv7FrDJRoYA9B24hWLKc = PsUQu1lnv7FrDJRoYA9B24hWLKc+'?named='+RYcDahmQfJKqTeEL9Pxzr+'__download'+tpXOZkgcfs2q57
							zzvBg3ShiamAZ.append(PsUQu1lnv7FrDJRoYA9B24hWLKc)
					else:
						WfwYon0e2zSEgNVGqIm67 = GGvHJKP9LUxEk10Fw.findall('href="(.*?http.*?)".*?name">(.*?)<',oSaQ12urny64V5AtHpxm0R7fzOeE,GGvHJKP9LUxEk10Fw.DOTALL)
						for PsUQu1lnv7FrDJRoYA9B24hWLKc,RYcDahmQfJKqTeEL9Pxzr in WfwYon0e2zSEgNVGqIm67:
							PsUQu1lnv7FrDJRoYA9B24hWLKc = PsUQu1lnv7FrDJRoYA9B24hWLKc.strip(' ')+'?named='+RYcDahmQfJKqTeEL9Pxzr+'__download'+tpXOZkgcfs2q57
							zzvBg3ShiamAZ.append(PsUQu1lnv7FrDJRoYA9B24hWLKc)
			else:
				WfwYon0e2zSEgNVGqIm67 = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(\w+)<',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
				for PsUQu1lnv7FrDJRoYA9B24hWLKc,RYcDahmQfJKqTeEL9Pxzr in WfwYon0e2zSEgNVGqIm67:
					PsUQu1lnv7FrDJRoYA9B24hWLKc = PsUQu1lnv7FrDJRoYA9B24hWLKc.strip(' ')+'?named='+RYcDahmQfJKqTeEL9Pxzr+'__download'
					zzvBg3ShiamAZ.append(PsUQu1lnv7FrDJRoYA9B24hWLKc)
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(zzvBg3ShiamAZ,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	search = search.replace(' ','+')
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',NBm2aWhPzoTpdYn+'/alz','',headers,True,'','ARBLIONZ-SEARCH-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content.encode('utf8')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('chevron-select(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if showDialogs and EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('value="(.*?)".*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		HHgNAaRqpxJ8BZLFmusc5IrW,xPOWTuLJRQ6Mig = [],[]
		for BBskpK6cGZJ,title in items:
			HHgNAaRqpxJ8BZLFmusc5IrW.append(BBskpK6cGZJ)
			xPOWTuLJRQ6Mig.append(title)
		z0jyetbQwKrIclL9vJW = D1DJtzviFZSrA('اختر الفلتر المناسب:', xPOWTuLJRQ6Mig)
		if z0jyetbQwKrIclL9vJW == -1 : return
		BBskpK6cGZJ = HHgNAaRqpxJ8BZLFmusc5IrW[z0jyetbQwKrIclL9vJW]
	else: BBskpK6cGZJ = ''
	url = NBm2aWhPzoTpdYn + '/search?s='+search+'&category='+BBskpK6cGZJ+'&page=1'
	xoiXMWjJC3pnQqurIGPkRSl8e(url)
	return
def hWJg9P6lEYT5aGDizcb(url,filter):
	A2kRm7N8gIn1MTrWZF0Yp5e = ['category','release-year','genre','Quality']
	if '?' in url: url = url.split('/getposts?')[0]
	type,filter = filter.split('___',1)
	if filter=='': zTi1IvPRBr,CcMQl4P9H8SkouF7srzBYdDKUNA = '',''
	else: zTi1IvPRBr,CcMQl4P9H8SkouF7srzBYdDKUNA = filter.split('___')
	if type=='CATEGORIES':
		if A2kRm7N8gIn1MTrWZF0Yp5e[0]+'=' not in zTi1IvPRBr: BBskpK6cGZJ = A2kRm7N8gIn1MTrWZF0Yp5e[0]
		for umP72LtwzUTWHFAlJVyheEp5 in range(len(A2kRm7N8gIn1MTrWZF0Yp5e[0:-1])):
			if A2kRm7N8gIn1MTrWZF0Yp5e[umP72LtwzUTWHFAlJVyheEp5]+'=' in zTi1IvPRBr: BBskpK6cGZJ = A2kRm7N8gIn1MTrWZF0Yp5e[umP72LtwzUTWHFAlJVyheEp5+1]
		i2i6oT5O34GLAgyPs8DdIfV = zTi1IvPRBr+'&'+BBskpK6cGZJ+'=0'
		WtVSCYeOJDGQf5sq8KZxkzyXwvBF = CcMQl4P9H8SkouF7srzBYdDKUNA+'&'+BBskpK6cGZJ+'=0'
		sDnjCtlaGyxmr9fqK = i2i6oT5O34GLAgyPs8DdIfV.strip('&')+'___'+WtVSCYeOJDGQf5sq8KZxkzyXwvBF.strip('&')
		BnNGcaxDl0pPVdmq3j1kQu6HJEs4 = fx0tQnZhGieDkA(CcMQl4P9H8SkouF7srzBYdDKUNA,'modified_filters')
		dR2vHyAtl8pJN1 = url+'/getposts?'+BnNGcaxDl0pPVdmq3j1kQu6HJEs4
	elif type=='FILTERS':
		QHWZwB3stnOp5SghLfl2zir6YCI = fx0tQnZhGieDkA(zTi1IvPRBr,'modified_values')
		QHWZwB3stnOp5SghLfl2zir6YCI = GhPlajzTxY8(QHWZwB3stnOp5SghLfl2zir6YCI)
		if CcMQl4P9H8SkouF7srzBYdDKUNA!='': CcMQl4P9H8SkouF7srzBYdDKUNA = fx0tQnZhGieDkA(CcMQl4P9H8SkouF7srzBYdDKUNA,'modified_filters')
		if CcMQl4P9H8SkouF7srzBYdDKUNA=='': dR2vHyAtl8pJN1 = url
		else: dR2vHyAtl8pJN1 = url+'/getposts?'+CcMQl4P9H8SkouF7srzBYdDKUNA
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'أظهار قائمة الفيديو التي تم اختيارها ',dR2vHyAtl8pJN1,201)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+' [[   '+QHWZwB3stnOp5SghLfl2zir6YCI+'   ]]',dR2vHyAtl8pJN1,201)
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,url+'/alz','',headers,'','ARBLIONZ-FILTERS_MENU-1st')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('AjaxFilteringData(.*?)FilterWord',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	nQKyI93hUT2ZGl6zimxDWe04ckj = GGvHJKP9LUxEk10Fw.findall('</i>(.*?)<.*?data-forTax="(.*?)"(.*?)<h2',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	dict = {}
	for name,mmRDx1Zhfjq4oFdsNey2EwCBlUOQv,UCEFMfKbgpd in nQKyI93hUT2ZGl6zimxDWe04ckj:
		name = name.replace('اختيار ','')
		name = name.replace('سنة الإنتاج','السنة')
		items = GGvHJKP9LUxEk10Fw.findall('value="(.*?)".*?</div>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if '=' not in dR2vHyAtl8pJN1: dR2vHyAtl8pJN1 = url
		if type=='CATEGORIES':
			if BBskpK6cGZJ!=mmRDx1Zhfjq4oFdsNey2EwCBlUOQv: continue
			elif len(items)<=1:
				if mmRDx1Zhfjq4oFdsNey2EwCBlUOQv==A2kRm7N8gIn1MTrWZF0Yp5e[-1]: xoiXMWjJC3pnQqurIGPkRSl8e(dR2vHyAtl8pJN1)
				else: hWJg9P6lEYT5aGDizcb(dR2vHyAtl8pJN1,'CATEGORIES___'+sDnjCtlaGyxmr9fqK)
				return
			else:
				if mmRDx1Zhfjq4oFdsNey2EwCBlUOQv==A2kRm7N8gIn1MTrWZF0Yp5e[-1]: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع ',dR2vHyAtl8pJN1,201)
				else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع ',dR2vHyAtl8pJN1,205,'','',sDnjCtlaGyxmr9fqK)
		elif type=='FILTERS':
			i2i6oT5O34GLAgyPs8DdIfV = zTi1IvPRBr+'&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'=0'
			WtVSCYeOJDGQf5sq8KZxkzyXwvBF = CcMQl4P9H8SkouF7srzBYdDKUNA+'&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'=0'
			sDnjCtlaGyxmr9fqK = i2i6oT5O34GLAgyPs8DdIfV+'___'+WtVSCYeOJDGQf5sq8KZxkzyXwvBF
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع :'+name,dR2vHyAtl8pJN1,204,'','',sDnjCtlaGyxmr9fqK)
		dict[mmRDx1Zhfjq4oFdsNey2EwCBlUOQv] = {}
		for hieW1zRUG5w9AykJjv0X,RHb9zAjcuTIoyZ0aDgS1pQYmUs8 in items:
			RHb9zAjcuTIoyZ0aDgS1pQYmUs8 = RHb9zAjcuTIoyZ0aDgS1pQYmUs8.replace('\n','')
			if RHb9zAjcuTIoyZ0aDgS1pQYmUs8 in DDXTwbRBaj3e2rSsPQ: continue
			dict[mmRDx1Zhfjq4oFdsNey2EwCBlUOQv][hieW1zRUG5w9AykJjv0X] = RHb9zAjcuTIoyZ0aDgS1pQYmUs8
			i2i6oT5O34GLAgyPs8DdIfV = zTi1IvPRBr+'&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'='+RHb9zAjcuTIoyZ0aDgS1pQYmUs8
			WtVSCYeOJDGQf5sq8KZxkzyXwvBF = CcMQl4P9H8SkouF7srzBYdDKUNA+'&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'='+hieW1zRUG5w9AykJjv0X
			KPcDQTE3e8duMHO6Lbgo1n = i2i6oT5O34GLAgyPs8DdIfV+'___'+WtVSCYeOJDGQf5sq8KZxkzyXwvBF
			title = RHb9zAjcuTIoyZ0aDgS1pQYmUs8+' :'#+dict[mmRDx1Zhfjq4oFdsNey2EwCBlUOQv]['0']
			title = RHb9zAjcuTIoyZ0aDgS1pQYmUs8+' :'+name
			if type=='FILTERS': cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,204,'','',KPcDQTE3e8duMHO6Lbgo1n)
			elif type=='CATEGORIES' and A2kRm7N8gIn1MTrWZF0Yp5e[-2]+'=' in zTi1IvPRBr:
				BnNGcaxDl0pPVdmq3j1kQu6HJEs4 = fx0tQnZhGieDkA(WtVSCYeOJDGQf5sq8KZxkzyXwvBF,'modified_filters')
				XwyU6PQgprMI0 = url+'/getposts?'+BnNGcaxDl0pPVdmq3j1kQu6HJEs4
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,XwyU6PQgprMI0,201)
			else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,205,'','',KPcDQTE3e8duMHO6Lbgo1n)
	return
def fx0tQnZhGieDkA(FZj067Q2PlC8EsG9c5yiWpzNRq,mode):
	FZj067Q2PlC8EsG9c5yiWpzNRq = FZj067Q2PlC8EsG9c5yiWpzNRq.replace('=&','=0&')
	FZj067Q2PlC8EsG9c5yiWpzNRq = FZj067Q2PlC8EsG9c5yiWpzNRq.strip('&')
	HG4gSjopqQwsPeivrcmn = {}
	if '=' in FZj067Q2PlC8EsG9c5yiWpzNRq:
		items = FZj067Q2PlC8EsG9c5yiWpzNRq.split('&')
		for BrVNsC72UYWES4A in items:
			RRSq2Qx0MfkFHLt,hieW1zRUG5w9AykJjv0X = BrVNsC72UYWES4A.split('=')
			HG4gSjopqQwsPeivrcmn[RRSq2Qx0MfkFHLt] = hieW1zRUG5w9AykJjv0X
	BbgO8pxWfVA41KGzed = ''
	ppwVAoqiOnjJZad = ['category','release-year','genre','Quality']
	for key in ppwVAoqiOnjJZad:
		if key in list(HG4gSjopqQwsPeivrcmn.keys()): hieW1zRUG5w9AykJjv0X = HG4gSjopqQwsPeivrcmn[key]
		else: hieW1zRUG5w9AykJjv0X = '0'
		if '%' not in hieW1zRUG5w9AykJjv0X: hieW1zRUG5w9AykJjv0X = mGfdCk4Hyclg9RjD(hieW1zRUG5w9AykJjv0X)
		if mode=='modified_values' and hieW1zRUG5w9AykJjv0X!='0': BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed+' + '+hieW1zRUG5w9AykJjv0X
		elif mode=='modified_filters' and hieW1zRUG5w9AykJjv0X!='0': BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed+'&'+key+'='+hieW1zRUG5w9AykJjv0X
		elif mode=='all': BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed+'&'+key+'='+hieW1zRUG5w9AykJjv0X
	BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed.strip(' + ')
	BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed.strip('&')
	BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed.replace('=0','=')
	BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed.replace('Quality','quality')
	return BbgO8pxWfVA41KGzed
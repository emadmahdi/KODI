# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
ucL0B1lWMCfAoEjG = 'FAVORITES'
def hSlFxp6vyaE0tRqWBfKcn(VRnfEFmJzUrSljM8,F91j3JLBCRkp0P):
	if   VRnfEFmJzUrSljM8==270: p8lwCLKmTWr = MgXYEzpBGQfveJ3bHm1u(F91j3JLBCRkp0P)
	else: p8lwCLKmTWr = False
	return p8lwCLKmTWr
def CC2IGzXJ4u(BZzGu5Dp6f3jbTW04Mxco8yE,F91j3JLBCRkp0P,C8q4NGk7MQcvUE):
	if not BZzGu5Dp6f3jbTW04Mxco8yE: return
	if   C8q4NGk7MQcvUE=='UP1'	: dd4i8PRohNMtgpOL0sJSK(F91j3JLBCRkp0P,True,1)
	elif C8q4NGk7MQcvUE=='DOWN1'	: dd4i8PRohNMtgpOL0sJSK(F91j3JLBCRkp0P,False,1)
	elif C8q4NGk7MQcvUE=='UP4'	: dd4i8PRohNMtgpOL0sJSK(F91j3JLBCRkp0P,True,4)
	elif C8q4NGk7MQcvUE=='DOWN4'	: dd4i8PRohNMtgpOL0sJSK(F91j3JLBCRkp0P,False,4)
	elif C8q4NGk7MQcvUE=='ADD1'	: TAPBr4LouO9VXGsq5Z1xn3lECc(F91j3JLBCRkp0P)
	elif C8q4NGk7MQcvUE=='REMOVE1': s9seHcijfGgzDdPlYBb8XSrxahk(F91j3JLBCRkp0P)
	elif C8q4NGk7MQcvUE=='DELETELIST': HcoNwWQUygOaD8vM2J61(F91j3JLBCRkp0P)
	return
def MgXYEzpBGQfveJ3bHm1u(F91j3JLBCRkp0P):
	aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA = WW7LRjMc4iCplzdXB()
	if F91j3JLBCRkp0P in list(aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA.keys()):
		try:
			o2Ol6N1A04JHqSDQi = aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA[F91j3JLBCRkp0P]
			for QTcZbyNIfxeU84vs5LBophFmqMAn6,WJr6B5imnN1Cypw,kk1GKyapocQZDAz,VRnfEFmJzUrSljM8,TF42IOaD6Gc,zdu6VAyNEi5IL1,MMupPCxqkenwt6FlsbRILV37EAmB,BZzGu5Dp6f3jbTW04Mxco8yE,Q16YwhAIPHb9Cgj4F in o2Ol6N1A04JHqSDQi:
				cd0aGwCPExbFU5pYNu8r(QTcZbyNIfxeU84vs5LBophFmqMAn6,WJr6B5imnN1Cypw,kk1GKyapocQZDAz,VRnfEFmJzUrSljM8,TF42IOaD6Gc,zdu6VAyNEi5IL1,MMupPCxqkenwt6FlsbRILV37EAmB,BZzGu5Dp6f3jbTW04Mxco8yE,Q16YwhAIPHb9Cgj4F)
		except:
			aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA = iiZBqA90yC(PGIWHNLQuRoK1M)
			o2Ol6N1A04JHqSDQi = aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA[F91j3JLBCRkp0P]
			for QTcZbyNIfxeU84vs5LBophFmqMAn6,WJr6B5imnN1Cypw,kk1GKyapocQZDAz,VRnfEFmJzUrSljM8,TF42IOaD6Gc,zdu6VAyNEi5IL1,MMupPCxqkenwt6FlsbRILV37EAmB,BZzGu5Dp6f3jbTW04Mxco8yE,Q16YwhAIPHb9Cgj4F in o2Ol6N1A04JHqSDQi:
				cd0aGwCPExbFU5pYNu8r(QTcZbyNIfxeU84vs5LBophFmqMAn6,WJr6B5imnN1Cypw,kk1GKyapocQZDAz,VRnfEFmJzUrSljM8,TF42IOaD6Gc,zdu6VAyNEi5IL1,MMupPCxqkenwt6FlsbRILV37EAmB,BZzGu5Dp6f3jbTW04Mxco8yE,Q16YwhAIPHb9Cgj4F)
	return
def TAPBr4LouO9VXGsq5Z1xn3lECc(F91j3JLBCRkp0P):
	QTcZbyNIfxeU84vs5LBophFmqMAn6,WJr6B5imnN1Cypw,kk1GKyapocQZDAz,VRnfEFmJzUrSljM8,TF42IOaD6Gc,zdu6VAyNEi5IL1,MMupPCxqkenwt6FlsbRILV37EAmB,BZzGu5Dp6f3jbTW04Mxco8yE,Q16YwhAIPHb9Cgj4F = z4sqGEoRxKVCSwc3nLZ(jI8KGT6dsgDQ)
	O6ajtFmEdzo3WBIYin4GxqK95fp = QTcZbyNIfxeU84vs5LBophFmqMAn6,WJr6B5imnN1Cypw,kk1GKyapocQZDAz,VRnfEFmJzUrSljM8,TF42IOaD6Gc,zdu6VAyNEi5IL1,MMupPCxqkenwt6FlsbRILV37EAmB,'',Q16YwhAIPHb9Cgj4F
	aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA = WW7LRjMc4iCplzdXB()
	W1x9AmJKoPfz6sbVwUN = {}
	for bZOevzjoWGIRd9THcSLD0AtMVEu in list(aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA.keys()):
		if bZOevzjoWGIRd9THcSLD0AtMVEu!=F91j3JLBCRkp0P: W1x9AmJKoPfz6sbVwUN[bZOevzjoWGIRd9THcSLD0AtMVEu] = aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA[bZOevzjoWGIRd9THcSLD0AtMVEu]
		else:
			if WJr6B5imnN1Cypw and WJr6B5imnN1Cypw!='..':
				QMVIf2jE5Z8iGd9X0C = aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA[bZOevzjoWGIRd9THcSLD0AtMVEu]
				if O6ajtFmEdzo3WBIYin4GxqK95fp in QMVIf2jE5Z8iGd9X0C:
					jo7K6zECvt5Q8LI = QMVIf2jE5Z8iGd9X0C.index(O6ajtFmEdzo3WBIYin4GxqK95fp)
					del QMVIf2jE5Z8iGd9X0C[jo7K6zECvt5Q8LI]
				FKMStRujBG = QMVIf2jE5Z8iGd9X0C+[O6ajtFmEdzo3WBIYin4GxqK95fp]
				W1x9AmJKoPfz6sbVwUN[bZOevzjoWGIRd9THcSLD0AtMVEu] = FKMStRujBG
			else: W1x9AmJKoPfz6sbVwUN[bZOevzjoWGIRd9THcSLD0AtMVEu] = aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA[bZOevzjoWGIRd9THcSLD0AtMVEu]
	if F91j3JLBCRkp0P not in list(W1x9AmJKoPfz6sbVwUN.keys()): W1x9AmJKoPfz6sbVwUN[F91j3JLBCRkp0P] = [O6ajtFmEdzo3WBIYin4GxqK95fp]
	W2ohuxTlHv6K0FIdeN5O = str(W1x9AmJKoPfz6sbVwUN)
	if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: W2ohuxTlHv6K0FIdeN5O = W2ohuxTlHv6K0FIdeN5O.encode('utf8')
	open(PGIWHNLQuRoK1M,'wb').write(W2ohuxTlHv6K0FIdeN5O)
	return
def s9seHcijfGgzDdPlYBb8XSrxahk(F91j3JLBCRkp0P):
	QTcZbyNIfxeU84vs5LBophFmqMAn6,WJr6B5imnN1Cypw,kk1GKyapocQZDAz,VRnfEFmJzUrSljM8,TF42IOaD6Gc,zdu6VAyNEi5IL1,MMupPCxqkenwt6FlsbRILV37EAmB,BZzGu5Dp6f3jbTW04Mxco8yE,Q16YwhAIPHb9Cgj4F = z4sqGEoRxKVCSwc3nLZ(jI8KGT6dsgDQ)
	O6ajtFmEdzo3WBIYin4GxqK95fp = QTcZbyNIfxeU84vs5LBophFmqMAn6,WJr6B5imnN1Cypw,kk1GKyapocQZDAz,VRnfEFmJzUrSljM8,TF42IOaD6Gc,zdu6VAyNEi5IL1,MMupPCxqkenwt6FlsbRILV37EAmB,'',Q16YwhAIPHb9Cgj4F
	aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA = WW7LRjMc4iCplzdXB()
	if F91j3JLBCRkp0P in list(aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA.keys()) and O6ajtFmEdzo3WBIYin4GxqK95fp in aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA[F91j3JLBCRkp0P]:
		aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA[F91j3JLBCRkp0P].remove(O6ajtFmEdzo3WBIYin4GxqK95fp)
		if len(aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA[F91j3JLBCRkp0P])==0: del aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA[F91j3JLBCRkp0P]
		W2ohuxTlHv6K0FIdeN5O = str(aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA)
		if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: W2ohuxTlHv6K0FIdeN5O = W2ohuxTlHv6K0FIdeN5O.encode('utf8')
		open(PGIWHNLQuRoK1M,'wb').write(W2ohuxTlHv6K0FIdeN5O)
	return
def dd4i8PRohNMtgpOL0sJSK(F91j3JLBCRkp0P,L7caOMF4h8WDz6ilNnEsIPwgjCVJ,giIcC3MJpGyVLvB):
	QTcZbyNIfxeU84vs5LBophFmqMAn6,WJr6B5imnN1Cypw,kk1GKyapocQZDAz,VRnfEFmJzUrSljM8,TF42IOaD6Gc,zdu6VAyNEi5IL1,MMupPCxqkenwt6FlsbRILV37EAmB,BZzGu5Dp6f3jbTW04Mxco8yE,Q16YwhAIPHb9Cgj4F = z4sqGEoRxKVCSwc3nLZ(jI8KGT6dsgDQ)
	O6ajtFmEdzo3WBIYin4GxqK95fp = QTcZbyNIfxeU84vs5LBophFmqMAn6,WJr6B5imnN1Cypw,kk1GKyapocQZDAz,VRnfEFmJzUrSljM8,TF42IOaD6Gc,zdu6VAyNEi5IL1,MMupPCxqkenwt6FlsbRILV37EAmB,'',Q16YwhAIPHb9Cgj4F
	aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA = WW7LRjMc4iCplzdXB()
	if F91j3JLBCRkp0P in list(aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA.keys()):
		QMVIf2jE5Z8iGd9X0C = aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA[F91j3JLBCRkp0P]
		if O6ajtFmEdzo3WBIYin4GxqK95fp not in QMVIf2jE5Z8iGd9X0C: return
		FKbzR4LiqVGEDcjQ2vUTM9Wk = len(QMVIf2jE5Z8iGd9X0C)
		for L4SCkrby5m8gjWwHOn0fJuhqQYvUN in range(0,giIcC3MJpGyVLvB):
			igTMZNnUPjrRfAIBl = QMVIf2jE5Z8iGd9X0C.index(O6ajtFmEdzo3WBIYin4GxqK95fp)
			if L7caOMF4h8WDz6ilNnEsIPwgjCVJ: WMtaDNbXGH34rF0uv6 = igTMZNnUPjrRfAIBl-1
			else: WMtaDNbXGH34rF0uv6 = igTMZNnUPjrRfAIBl+1
			if WMtaDNbXGH34rF0uv6>=FKbzR4LiqVGEDcjQ2vUTM9Wk: WMtaDNbXGH34rF0uv6 = WMtaDNbXGH34rF0uv6-FKbzR4LiqVGEDcjQ2vUTM9Wk
			if WMtaDNbXGH34rF0uv6<0: WMtaDNbXGH34rF0uv6 = WMtaDNbXGH34rF0uv6+FKbzR4LiqVGEDcjQ2vUTM9Wk
			QMVIf2jE5Z8iGd9X0C.insert(WMtaDNbXGH34rF0uv6, QMVIf2jE5Z8iGd9X0C.pop(igTMZNnUPjrRfAIBl))
		aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA[F91j3JLBCRkp0P] = QMVIf2jE5Z8iGd9X0C
		W2ohuxTlHv6K0FIdeN5O = str(aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA)
		if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: W2ohuxTlHv6K0FIdeN5O = W2ohuxTlHv6K0FIdeN5O.encode('utf8')
		open(PGIWHNLQuRoK1M,'wb').write(W2ohuxTlHv6K0FIdeN5O)
	return
def HcoNwWQUygOaD8vM2J61(F91j3JLBCRkp0P):
	yYuG6rWaR9gmSO05jlZ1woUX3 = ggi4vBsqHDArM1('center','','','رسالة من المبرمج','هل تريد فعلا مسح جميع محتويات قائمة المفضلة '+F91j3JLBCRkp0P+' ؟!')
	if yYuG6rWaR9gmSO05jlZ1woUX3!=1: return
	aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA = WW7LRjMc4iCplzdXB()
	if F91j3JLBCRkp0P in list(aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA.keys()):
		del aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA[F91j3JLBCRkp0P]
		W2ohuxTlHv6K0FIdeN5O = str(aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA)
		if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: W2ohuxTlHv6K0FIdeN5O = W2ohuxTlHv6K0FIdeN5O.encode('utf8')
		open(PGIWHNLQuRoK1M,'wb').write(W2ohuxTlHv6K0FIdeN5O)
		aHKzv76JCVnprbY8w('','','رسالة من المبرمج','تم مسح جميع محتويات قائمة المفضلة '+F91j3JLBCRkp0P)
	return
def WW7LRjMc4iCplzdXB():
	aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA = {}
	if WpgZTyqoMAPhwGiXF.path.exists(PGIWHNLQuRoK1M):
		Vfz0iFykxIQ3486CYnhTEpLeAaN7 = open(PGIWHNLQuRoK1M,'rb').read()
		if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: Vfz0iFykxIQ3486CYnhTEpLeAaN7 = Vfz0iFykxIQ3486CYnhTEpLeAaN7.decode('utf8')
		aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA = JKw5OWktPZB('dict',Vfz0iFykxIQ3486CYnhTEpLeAaN7)
	return aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA
def yi0Zf5IPxWcVrHjCBm71w(aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA,O6ajtFmEdzo3WBIYin4GxqK95fp,jSdfwZXxKOlF9rk3c6VGoLmJ5):
	QTcZbyNIfxeU84vs5LBophFmqMAn6,WJr6B5imnN1Cypw,kk1GKyapocQZDAz,VRnfEFmJzUrSljM8,TF42IOaD6Gc,zdu6VAyNEi5IL1,MMupPCxqkenwt6FlsbRILV37EAmB,BZzGu5Dp6f3jbTW04Mxco8yE,Q16YwhAIPHb9Cgj4F = O6ajtFmEdzo3WBIYin4GxqK95fp
	if not VRnfEFmJzUrSljM8: QTcZbyNIfxeU84vs5LBophFmqMAn6,VRnfEFmJzUrSljM8 = 'folder','260'
	jiGHkmYK8CeIEr5h,F91j3JLBCRkp0P = [],''
	if 'context=' in jI8KGT6dsgDQ:
		WKVr1RjQDSC = GGvHJKP9LUxEk10Fw.findall('context=(\d+)',jI8KGT6dsgDQ,GGvHJKP9LUxEk10Fw.DOTALL)
		if WKVr1RjQDSC: F91j3JLBCRkp0P = str(WKVr1RjQDSC[0])
	if VRnfEFmJzUrSljM8=='270':
		F91j3JLBCRkp0P = BZzGu5Dp6f3jbTW04Mxco8yE
		if F91j3JLBCRkp0P in list(aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA.keys()):
			jiGHkmYK8CeIEr5h.append(('مسح قائمة مفضلة '+F91j3JLBCRkp0P,'RunPlugin('+jSdfwZXxKOlF9rk3c6VGoLmJ5+'&context='+F91j3JLBCRkp0P+'_DELETELIST'+')'))
	else:
		if F91j3JLBCRkp0P in list(aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA.keys()):
			count = len(aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA[F91j3JLBCRkp0P])
			if count>1: jiGHkmYK8CeIEr5h.append(('تحريك 1 للأعلى','RunPlugin('+jSdfwZXxKOlF9rk3c6VGoLmJ5+'&context='+F91j3JLBCRkp0P+'_UP1)'))
			if count>4: jiGHkmYK8CeIEr5h.append(('تحريك 4 للأعلى','RunPlugin('+jSdfwZXxKOlF9rk3c6VGoLmJ5+'&context='+F91j3JLBCRkp0P+'_UP4)'))
			if count>1: jiGHkmYK8CeIEr5h.append(('تحريك 1 للأسفل','RunPlugin('+jSdfwZXxKOlF9rk3c6VGoLmJ5+'&context='+F91j3JLBCRkp0P+'_DOWN1)'))
			if count>4: jiGHkmYK8CeIEr5h.append(('تحريك 4 للأسفل','RunPlugin('+jSdfwZXxKOlF9rk3c6VGoLmJ5+'&context='+F91j3JLBCRkp0P+'_DOWN4)'))
		for F91j3JLBCRkp0P in ['1','2','3','4','5']:
			if F91j3JLBCRkp0P in list(aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA.keys()) and O6ajtFmEdzo3WBIYin4GxqK95fp in aYBvEh8z7yR9pJ6e4HoQldmDFNgSjA[F91j3JLBCRkp0P]:
				jiGHkmYK8CeIEr5h.append(('مسح من مفضلة '+F91j3JLBCRkp0P,'RunPlugin('+jSdfwZXxKOlF9rk3c6VGoLmJ5+'&context='+F91j3JLBCRkp0P+'_REMOVE1)'))
			else: jiGHkmYK8CeIEr5h.append(('إضافة لمفضلة '+F91j3JLBCRkp0P,'RunPlugin('+jSdfwZXxKOlF9rk3c6VGoLmJ5+'&context='+F91j3JLBCRkp0P+'_ADD1)'))
	qPJYsXTjW75u03 = []
	for AkKt3EJde9QjcXBmqlFogS5Op,NaBrRUiDzytQgWIAYOx8sjkm54E3 in jiGHkmYK8CeIEr5h:
		AkKt3EJde9QjcXBmqlFogS5Op = '[COLOR FFFFFF00]'+AkKt3EJde9QjcXBmqlFogS5Op+'[/COLOR]'
		qPJYsXTjW75u03.append((AkKt3EJde9QjcXBmqlFogS5Op,NaBrRUiDzytQgWIAYOx8sjkm54E3,))
	return qPJYsXTjW75u03
# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'EGYNOW'
mmDwMlfoHtG5XT19VLIWqCR8i = '_EGN_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
DDXTwbRBaj3e2rSsPQ = ['عروض مصارعة','الكل','n/A','المزيد','قصة عشق']
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==430: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==431: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,text)
	elif mode==432: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==433: zpXG3Ky6ou8ndWHkb4 = hWPvGlXZ5arzV7(url)
	elif mode==434: zpXG3Ky6ou8ndWHkb4 = hWJg9P6lEYT5aGDizcb(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==435: zpXG3Ky6ou8ndWHkb4 = hWJg9P6lEYT5aGDizcb(url,'SPECIFIED_FILTER___'+text)
	elif mode==436: zpXG3Ky6ou8ndWHkb4 = i7pbAuodvX3(url)
	elif mode==437: zpXG3Ky6ou8ndWHkb4 = cYfskxphSQ(url)
	elif mode==439: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',NBm2aWhPzoTpdYn+'/films','','','','','EGYNOW-MENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	aPNBvIyexc053gAsSw1QoRMUYfb = GGvHJKP9LUxEk10Fw.findall('"canonical" href="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	aPNBvIyexc053gAsSw1QoRMUYfb = aPNBvIyexc053gAsSw1QoRMUYfb[0].strip('/')
	aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(aPNBvIyexc053gAsSw1QoRMUYfb,'url')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',439,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فلتر محدد',aPNBvIyexc053gAsSw1QoRMUYfb,435)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فلتر كامل',aPNBvIyexc053gAsSw1QoRMUYfb,434)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'المضاف حديثا',aPNBvIyexc053gAsSw1QoRMUYfb,431)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'افلام اون لاين',aPNBvIyexc053gAsSw1QoRMUYfb+'/films1',436)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'مسلسلات اون لاين',aPNBvIyexc053gAsSw1QoRMUYfb+'/series-all1',436)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'قائمة تفصيلية',aPNBvIyexc053gAsSw1QoRMUYfb,437)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"SiteNavigation"(.*?)"Search"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		if title in DDXTwbRBaj3e2rSsPQ: continue
		if title=='الرئيسية': continue
		if 'اون لاين' in title: continue
		cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,431)
	return
def cYfskxphSQ(website=''):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',website+'/films','','','','','EGYNOW-MENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	aPNBvIyexc053gAsSw1QoRMUYfb = GGvHJKP9LUxEk10Fw.findall('"canonical" href="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	aPNBvIyexc053gAsSw1QoRMUYfb = aPNBvIyexc053gAsSw1QoRMUYfb[0].strip('/')
	aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(aPNBvIyexc053gAsSw1QoRMUYfb,'url')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"ListDroped"(.*?)"SearchingMaster"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('data-tax="(.*?)" data-term="(.*?)" data-name="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for BBskpK6cGZJ,hieW1zRUG5w9AykJjv0X,title in items:
		if title in DDXTwbRBaj3e2rSsPQ: continue
		ELbNB92cOh5dqtpVmi40kY = website+'/explore/?'+BBskpK6cGZJ+'='+hieW1zRUG5w9AykJjv0X
		cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,431)
	return
def i7pbAuodvX3(url):
	aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(url,'url')
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','EGYNOW-SUBMENU-1st')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع',url,431)
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"titleSectionCon"(.*?)</div></div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('data-key="(.*?)".*?<em>(.*?)</em>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for nKuYjzcZEXky6Va5UdoJfH1xqstL,title in items:
		if title in DDXTwbRBaj3e2rSsPQ: continue
		dR2vHyAtl8pJN1 = aPNBvIyexc053gAsSw1QoRMUYfb+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Movies/Keys.php?key='+nKuYjzcZEXky6Va5UdoJfH1xqstL
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,dR2vHyAtl8pJN1,431)
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(url,hD6se2E307NcI=''):
	aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(url,'url')
	items = []
	if '/Terms.php' in url or '/Get.php' in url or '/Keys.php' in url:
		dR2vHyAtl8pJN1,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = xlk0nsAXjIrvOQFL4Vi1MJG5TChu(url)
		BBYvCiQGe8RdpyAagfS72mZclxb5 = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'POST',dR2vHyAtl8pJN1,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,'','','EGYNOW-TITLES-1st')
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		UCEFMfKbgpd = BBlXpmUyhFDwNtCVAHoE
	elif hD6se2E307NcI=='featured':
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','EGYNOW-TITLES-2nd')
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"MainSlider"(.*?)"MatchesTable"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('<a href="(.*?)" title="(.*?)".*?image: url\((.*?)\)',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	else:
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','EGYNOW-TITLES-2nd')
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"BlocksList"(.*?)"Paginate"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if not EeQqAGc0W5r6nlBbChwfZL: EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"BlocksList"(.*?)"titleSectionCon"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	if not items: items = GGvHJKP9LUxEk10Fw.findall('<a href="(.*?)" title="(.*?)".*?data-image="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	IcJOGsq3Ff7EmkiLx = []
	Dq0X5cvgdjwh6LbnUkETFBR8 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for ELbNB92cOh5dqtpVmi40kY,title,VFqpJjRySZvgi in items:
		ELbNB92cOh5dqtpVmi40kY = GhPlajzTxY8(ELbNB92cOh5dqtpVmi40kY).strip('/')
		title = DwNC3gEonizsB6a0v1F(title)
		qUGxSK2VwsiBAdkDZnJ605vQeg = GGvHJKP9LUxEk10Fw.findall('(.*?) الحلقة \d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
		if any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in Dq0X5cvgdjwh6LbnUkETFBR8):
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,432,VFqpJjRySZvgi)
		elif qUGxSK2VwsiBAdkDZnJ605vQeg and 'الحلقة' in title:
			title = '_MOD_' + qUGxSK2VwsiBAdkDZnJ605vQeg[0]
			if title not in IcJOGsq3Ff7EmkiLx:
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,433,VFqpJjRySZvgi)
				IcJOGsq3Ff7EmkiLx.append(title)
		elif '/movseries/' in ELbNB92cOh5dqtpVmi40kY:
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,431,VFqpJjRySZvgi)
		else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,433,VFqpJjRySZvgi)
	if hD6se2E307NcI!='featured':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"Paginate"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = aPNBvIyexc053gAsSw1QoRMUYfb+ELbNB92cOh5dqtpVmi40kY
				ELbNB92cOh5dqtpVmi40kY = DwNC3gEonizsB6a0v1F(ELbNB92cOh5dqtpVmi40kY)
				title = DwNC3gEonizsB6a0v1F(title)
				if title!='': cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,431)
		ezAfMX0JKQPc2G = GGvHJKP9LUxEk10Fw.findall('showmore" href="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if ezAfMX0JKQPc2G:
			ELbNB92cOh5dqtpVmi40kY = ezAfMX0JKQPc2G[0]
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مشاهدة المزيد',ELbNB92cOh5dqtpVmi40kY,431)
	return
def hWPvGlXZ5arzV7(url):
	aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(url,'url')
	xxcVm7YBMXsfd,uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb = [],[]
	if 'Episodes.php' in url:
		dR2vHyAtl8pJN1,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = xlk0nsAXjIrvOQFL4Vi1MJG5TChu(url)
		BBYvCiQGe8RdpyAagfS72mZclxb5 = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'POST',dR2vHyAtl8pJN1,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,'','','EGYNOW-EPISODES-1st')
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb = [BBlXpmUyhFDwNtCVAHoE]
	else:
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','EGYNOW-EPISODES-2nd')
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		xxcVm7YBMXsfd = GGvHJKP9LUxEk10Fw.findall('"SeasonsList"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb = GGvHJKP9LUxEk10Fw.findall('"EpisodesList"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if xxcVm7YBMXsfd:
		VFqpJjRySZvgi = GGvHJKP9LUxEk10Fw.findall('"og:image" content="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		VFqpJjRySZvgi = VFqpJjRySZvgi[0]
		UCEFMfKbgpd = xxcVm7YBMXsfd[0]
		items = GGvHJKP9LUxEk10Fw.findall('data-id="(.*?)".*?data-season="(.*?)".*?">(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for OCYoctKgbdnePV2,bBfHlAPisD0Cj92m,title in items:
			ELbNB92cOh5dqtpVmi40kY = aPNBvIyexc053gAsSw1QoRMUYfb+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Episodes.php?'+'season='+bBfHlAPisD0Cj92m+'&post_id='+OCYoctKgbdnePV2
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,433,VFqpJjRySZvgi)
	elif uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb:
		VFqpJjRySZvgi = cEZpW924rqNYm5.getInfoLabel('ListItem.Thumb')
		UCEFMfKbgpd = uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?</i>(.*?)<em>(.*?)</em>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title,qUGxSK2VwsiBAdkDZnJ605vQeg in items:
			title = title+' '+qUGxSK2VwsiBAdkDZnJ605vQeg
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,432,VFqpJjRySZvgi)
	return
def SUfe4unWoXBNFz90xqy(url):
	dR2vHyAtl8pJN1 = url+'/watch/'
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',dR2vHyAtl8pJN1,'','','','','EGYNOW-PLAY-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	zzvBg3ShiamAZ = []
	aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(dR2vHyAtl8pJN1,'url')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"container-servers"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		Y5VwgWbBtTIAMsfRL8S4k = GGvHJKP9LUxEk10Fw.findall('data-id="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if Y5VwgWbBtTIAMsfRL8S4k:
			Y5VwgWbBtTIAMsfRL8S4k = Y5VwgWbBtTIAMsfRL8S4k[0]
			items = GGvHJKP9LUxEk10Fw.findall('data-server="(.*?)".*?<span>(.*?)</span>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for C83UXWf15zdwLA0,title in items:
				ELbNB92cOh5dqtpVmi40kY = aPNBvIyexc053gAsSw1QoRMUYfb+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Server.php?server='+C83UXWf15zdwLA0+'&post_id='+Y5VwgWbBtTIAMsfRL8S4k+'?named='+title+'__watch'
				zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	MOdvNeZH2YSugE = GGvHJKP9LUxEk10Fw.findall('"container-iframe"><iframe src="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if MOdvNeZH2YSugE:
		MOdvNeZH2YSugE = MOdvNeZH2YSugE[0].replace('\n','')
		title = RfKuIXwPAiWtmyF(MOdvNeZH2YSugE,'name')
		ELbNB92cOh5dqtpVmi40kY = MOdvNeZH2YSugE+'?named='+title+'__embed'
		zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"container-download"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?span>(.*?)<.*?em>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title,dDZQSEGRTo9g85x1C in items:
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.replace('\n','')
			if dDZQSEGRTo9g85x1C!='': dDZQSEGRTo9g85x1C = '____'+dDZQSEGRTo9g85x1C
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named='+title+'__download'+dDZQSEGRTo9g85x1C
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(zzvBg3ShiamAZ,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	search = search.replace(' ','%20')
	url = NBm2aWhPzoTpdYn+'/?s='+search
	xoiXMWjJC3pnQqurIGPkRSl8e(url)
	return
def ccBw4LkjaXAv8xDlV7UzFbrOfGqi5(url):
	url = url.split('/smartemadfilter?')[0]
	aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(url,'url')
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',aPNBvIyexc053gAsSw1QoRMUYfb,'','','','','EGYNOW-GET_FILTERS_BLOCKS-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('("dropdown-button".*?)"SearchingMaster"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	nQKyI93hUT2ZGl6zimxDWe04ckj = GGvHJKP9LUxEk10Fw.findall('"dropdown-button".*?<em>(.*?)</em>(.*?data-tax="(.*?)".*?</div>)',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	return nQKyI93hUT2ZGl6zimxDWe04ckj
def CEK49jfZAnysJ8wIiQDpkqaOPtrzbX(UCEFMfKbgpd):
	items = GGvHJKP9LUxEk10Fw.findall('data-term="(\d+)" data-name="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	return items
def CRdaLbyr9tTEuIX(url):
	Z5sNMdDa6h7j0 = url.split('/smartemadfilter?')[0]
	o6ZrjEvyT8th = RfKuIXwPAiWtmyF(url,'url')
	url = url.replace(Z5sNMdDa6h7j0,o6ZrjEvyT8th)
	url = url.replace('/smartemadfilter?','/explore/?')
	return url
def nnIG3zvStFsEygX1OjcTlUBLwfJ(WtVSCYeOJDGQf5sq8KZxkzyXwvBF,url):
	BnNGcaxDl0pPVdmq3j1kQu6HJEs4 = fx0tQnZhGieDkA(WtVSCYeOJDGQf5sq8KZxkzyXwvBF,'modified_filters')
	XwyU6PQgprMI0 = url+'/smartemadfilter?'+BnNGcaxDl0pPVdmq3j1kQu6HJEs4
	XwyU6PQgprMI0 = CRdaLbyr9tTEuIX(XwyU6PQgprMI0)
	return XwyU6PQgprMI0
A2kRm7N8gIn1MTrWZF0Yp5e = ['category','country','genre','release-year']
ppwVAoqiOnjJZad = ['quality','release-year','genre','category','language','country']
def hWJg9P6lEYT5aGDizcb(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': zTi1IvPRBr,CcMQl4P9H8SkouF7srzBYdDKUNA = '',''
	else: zTi1IvPRBr,CcMQl4P9H8SkouF7srzBYdDKUNA = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if A2kRm7N8gIn1MTrWZF0Yp5e[0]+'=' not in zTi1IvPRBr: BBskpK6cGZJ = A2kRm7N8gIn1MTrWZF0Yp5e[0]
		for umP72LtwzUTWHFAlJVyheEp5 in range(len(A2kRm7N8gIn1MTrWZF0Yp5e[0:-1])):
			if A2kRm7N8gIn1MTrWZF0Yp5e[umP72LtwzUTWHFAlJVyheEp5]+'=' in zTi1IvPRBr: BBskpK6cGZJ = A2kRm7N8gIn1MTrWZF0Yp5e[umP72LtwzUTWHFAlJVyheEp5+1]
		i2i6oT5O34GLAgyPs8DdIfV = zTi1IvPRBr+'&'+BBskpK6cGZJ+'=0'
		WtVSCYeOJDGQf5sq8KZxkzyXwvBF = CcMQl4P9H8SkouF7srzBYdDKUNA+'&'+BBskpK6cGZJ+'=0'
		sDnjCtlaGyxmr9fqK = i2i6oT5O34GLAgyPs8DdIfV.strip('&')+'___'+WtVSCYeOJDGQf5sq8KZxkzyXwvBF.strip('&')
		BnNGcaxDl0pPVdmq3j1kQu6HJEs4 = fx0tQnZhGieDkA(CcMQl4P9H8SkouF7srzBYdDKUNA,'modified_filters')
		dR2vHyAtl8pJN1 = url+'/smartemadfilter?'+BnNGcaxDl0pPVdmq3j1kQu6HJEs4
	elif type=='ALL_ITEMS_FILTER':
		QHWZwB3stnOp5SghLfl2zir6YCI = fx0tQnZhGieDkA(zTi1IvPRBr,'modified_values')
		QHWZwB3stnOp5SghLfl2zir6YCI = GhPlajzTxY8(QHWZwB3stnOp5SghLfl2zir6YCI)
		if CcMQl4P9H8SkouF7srzBYdDKUNA!='': CcMQl4P9H8SkouF7srzBYdDKUNA = fx0tQnZhGieDkA(CcMQl4P9H8SkouF7srzBYdDKUNA,'modified_filters')
		if CcMQl4P9H8SkouF7srzBYdDKUNA=='': dR2vHyAtl8pJN1 = url
		else: dR2vHyAtl8pJN1 = url+'/smartemadfilter?'+CcMQl4P9H8SkouF7srzBYdDKUNA
		dR2vHyAtl8pJN1 = CRdaLbyr9tTEuIX(dR2vHyAtl8pJN1)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'أظهار قائمة الفيديو التي تم اختيارها ',dR2vHyAtl8pJN1,431)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+' [[   '+QHWZwB3stnOp5SghLfl2zir6YCI+'   ]]',dR2vHyAtl8pJN1,431)
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nQKyI93hUT2ZGl6zimxDWe04ckj = ccBw4LkjaXAv8xDlV7UzFbrOfGqi5(url)
	dict = {}
	for name,UCEFMfKbgpd,mmRDx1Zhfjq4oFdsNey2EwCBlUOQv in nQKyI93hUT2ZGl6zimxDWe04ckj:
		name = name.replace('--','')
		items = CEK49jfZAnysJ8wIiQDpkqaOPtrzbX(UCEFMfKbgpd)
		if '=' not in dR2vHyAtl8pJN1: dR2vHyAtl8pJN1 = url
		if type=='SPECIFIED_FILTER':
			if BBskpK6cGZJ!=mmRDx1Zhfjq4oFdsNey2EwCBlUOQv: continue
			elif len(items)<2:
				if mmRDx1Zhfjq4oFdsNey2EwCBlUOQv==A2kRm7N8gIn1MTrWZF0Yp5e[-1]:
					url = CRdaLbyr9tTEuIX(url)
					xoiXMWjJC3pnQqurIGPkRSl8e(url)
				else: hWJg9P6lEYT5aGDizcb(dR2vHyAtl8pJN1,'SPECIFIED_FILTER___'+sDnjCtlaGyxmr9fqK)
				return
			else:
				dR2vHyAtl8pJN1 = CRdaLbyr9tTEuIX(dR2vHyAtl8pJN1)
				if mmRDx1Zhfjq4oFdsNey2EwCBlUOQv==A2kRm7N8gIn1MTrWZF0Yp5e[-1]: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع ',dR2vHyAtl8pJN1,431)
				else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع ',dR2vHyAtl8pJN1,435,'','',sDnjCtlaGyxmr9fqK)
		elif type=='ALL_ITEMS_FILTER':
			i2i6oT5O34GLAgyPs8DdIfV = zTi1IvPRBr+'&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'=0'
			WtVSCYeOJDGQf5sq8KZxkzyXwvBF = CcMQl4P9H8SkouF7srzBYdDKUNA+'&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'=0'
			sDnjCtlaGyxmr9fqK = i2i6oT5O34GLAgyPs8DdIfV+'___'+WtVSCYeOJDGQf5sq8KZxkzyXwvBF
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع :'+name,dR2vHyAtl8pJN1,434,'','',sDnjCtlaGyxmr9fqK)
		dict[mmRDx1Zhfjq4oFdsNey2EwCBlUOQv] = {}
		for hieW1zRUG5w9AykJjv0X,RHb9zAjcuTIoyZ0aDgS1pQYmUs8 in items:
			if hieW1zRUG5w9AykJjv0X=='196533': RHb9zAjcuTIoyZ0aDgS1pQYmUs8 = 'أفلام نيتفلكس'
			elif hieW1zRUG5w9AykJjv0X=='196531': RHb9zAjcuTIoyZ0aDgS1pQYmUs8 = 'مسلسلات نيتفلكس'
			if RHb9zAjcuTIoyZ0aDgS1pQYmUs8 in DDXTwbRBaj3e2rSsPQ: continue
			dict[mmRDx1Zhfjq4oFdsNey2EwCBlUOQv][hieW1zRUG5w9AykJjv0X] = RHb9zAjcuTIoyZ0aDgS1pQYmUs8
			i2i6oT5O34GLAgyPs8DdIfV = zTi1IvPRBr+'&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'='+RHb9zAjcuTIoyZ0aDgS1pQYmUs8
			WtVSCYeOJDGQf5sq8KZxkzyXwvBF = CcMQl4P9H8SkouF7srzBYdDKUNA+'&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'='+hieW1zRUG5w9AykJjv0X
			KPcDQTE3e8duMHO6Lbgo1n = i2i6oT5O34GLAgyPs8DdIfV+'___'+WtVSCYeOJDGQf5sq8KZxkzyXwvBF
			title = RHb9zAjcuTIoyZ0aDgS1pQYmUs8+' :'#+dict[mmRDx1Zhfjq4oFdsNey2EwCBlUOQv]['0']
			title = RHb9zAjcuTIoyZ0aDgS1pQYmUs8+' :'+name
			if type=='ALL_ITEMS_FILTER': cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,434,'','',KPcDQTE3e8duMHO6Lbgo1n)
			elif type=='SPECIFIED_FILTER' and A2kRm7N8gIn1MTrWZF0Yp5e[-2]+'=' in zTi1IvPRBr:
				XwyU6PQgprMI0 = nnIG3zvStFsEygX1OjcTlUBLwfJ(WtVSCYeOJDGQf5sq8KZxkzyXwvBF,url)
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,XwyU6PQgprMI0,431)
			else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,435,'','',KPcDQTE3e8duMHO6Lbgo1n)
	return
def fx0tQnZhGieDkA(FZj067Q2PlC8EsG9c5yiWpzNRq,mode):
	FZj067Q2PlC8EsG9c5yiWpzNRq = FZj067Q2PlC8EsG9c5yiWpzNRq.replace('=&','=0&')
	FZj067Q2PlC8EsG9c5yiWpzNRq = FZj067Q2PlC8EsG9c5yiWpzNRq.strip('&')
	HG4gSjopqQwsPeivrcmn = {}
	if '=' in FZj067Q2PlC8EsG9c5yiWpzNRq:
		items = FZj067Q2PlC8EsG9c5yiWpzNRq.split('&')
		for BrVNsC72UYWES4A in items:
			RRSq2Qx0MfkFHLt,hieW1zRUG5w9AykJjv0X = BrVNsC72UYWES4A.split('=')
			HG4gSjopqQwsPeivrcmn[RRSq2Qx0MfkFHLt] = hieW1zRUG5w9AykJjv0X
	BbgO8pxWfVA41KGzed = ''
	for key in ppwVAoqiOnjJZad:
		if key in list(HG4gSjopqQwsPeivrcmn.keys()): hieW1zRUG5w9AykJjv0X = HG4gSjopqQwsPeivrcmn[key]
		else: hieW1zRUG5w9AykJjv0X = '0'
		if '%' not in hieW1zRUG5w9AykJjv0X: hieW1zRUG5w9AykJjv0X = mGfdCk4Hyclg9RjD(hieW1zRUG5w9AykJjv0X)
		if mode=='modified_values' and hieW1zRUG5w9AykJjv0X!='0': BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed+' + '+hieW1zRUG5w9AykJjv0X
		elif mode=='modified_filters' and hieW1zRUG5w9AykJjv0X!='0': BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed+'&'+key+'='+hieW1zRUG5w9AykJjv0X
		elif mode=='all_filters': BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed+'&'+key+'='+hieW1zRUG5w9AykJjv0X
	BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed.strip(' + ')
	BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed.strip('&')
	BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed.replace('=0','=')
	return BbgO8pxWfVA41KGzed
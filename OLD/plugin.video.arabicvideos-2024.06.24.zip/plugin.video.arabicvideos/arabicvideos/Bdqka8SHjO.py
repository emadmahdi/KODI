# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'CIMAFANS'
headers = { 'User-Agent' : '' }
mmDwMlfoHtG5XT19VLIWqCR8i = '_CMF_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==90: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==91: zpXG3Ky6ou8ndWHkb4 = L4L0TUsN51taeljfc(url)
	elif mode==92: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==94: zpXG3Ky6ou8ndWHkb4 = CymTbuXdDhL()
	elif mode==95: zpXG3Ky6ou8ndWHkb4 = hWPvGlXZ5arzV7(url)
	elif mode==99: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',99,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'المضاف حديثا','',94)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'الأحدث',NBm2aWhPzoTpdYn+'/?type=latest',91)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'الأعلى تقيماً',NBm2aWhPzoTpdYn+'/?type=imdb',91)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'الأكثر مشاهدة',NBm2aWhPzoTpdYn+'/?type=view',91)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'المثبت',NBm2aWhPzoTpdYn+'/?type=pin',91)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'جديد الأفلام',NBm2aWhPzoTpdYn+'/?type=newMovies',91)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'جديد الحلقات',NBm2aWhPzoTpdYn+'/?type=newEpisodes',91)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,NBm2aWhPzoTpdYn,'',headers,'','CIMAFANS-MENU-1st')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="mainmenu(.*?)nav',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('<li><a href="(.*?)".*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	DDXTwbRBaj3e2rSsPQ = ['افلام للكبار فقط']
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		title = title.strip(' ')
		if not any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in DDXTwbRBaj3e2rSsPQ):
			cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,91)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="f-cats"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('<li><a href="(.*?)".*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		title = title.strip(' ')
		if not any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in DDXTwbRBaj3e2rSsPQ):
			cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,91)
	return BBlXpmUyhFDwNtCVAHoE
def L4L0TUsN51taeljfc(url):
	if '/search.php' in url:
		url,search = url.split('?t=')
		headers = { 'User-Agent' : '' , 'Content-Type' : 'application/x-www-form-urlencoded' }
		data = { 't' : search }
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'POST',url,data,headers,'','','CIMAFANS-ITEMS-1st')
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	else:
		headers = { 'User-Agent' : '' }
		BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,url,'',headers,'','CIMAFANS-ITEMS-2nd')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('id="movies-items(.*?)class="listfoot"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL: UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	else: UCEFMfKbgpd = ''
	items = GGvHJKP9LUxEk10Fw.findall('background-image:url\((.*?)\).*?href="(.*?)".*?movie-title">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	IcJOGsq3Ff7EmkiLx = []
	for VFqpJjRySZvgi,ELbNB92cOh5dqtpVmi40kY,title in items:
		if 'الحلقة' in title and '/c/' not in url and '/cat/' not in url:
			qUGxSK2VwsiBAdkDZnJ605vQeg = GGvHJKP9LUxEk10Fw.findall('(.*?) الحلقة [0-9]+',title,GGvHJKP9LUxEk10Fw.DOTALL)
			if qUGxSK2VwsiBAdkDZnJ605vQeg:
				title = '_MOD_'+qUGxSK2VwsiBAdkDZnJ605vQeg[0]
				if title not in IcJOGsq3Ff7EmkiLx:
					cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,95,VFqpJjRySZvgi)
					IcJOGsq3Ff7EmkiLx.append(title)
		elif '/video/' in ELbNB92cOh5dqtpVmi40kY: cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,92,VFqpJjRySZvgi)
		else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,91,VFqpJjRySZvgi)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="pagination(.*?)div',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('<a href="(.*?)".*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			title = DwNC3gEonizsB6a0v1F(title)
			title = title.replace('الصفحة ','')
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,91)
	return
def hWPvGlXZ5arzV7(url):
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,url,'',headers,'','CIMAFANS-EPISODES-1st')
	VFqpJjRySZvgi = GGvHJKP9LUxEk10Fw.findall('img src="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	VFqpJjRySZvgi = VFqpJjRySZvgi[0]
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('id="episodes-panel(.*?)div',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		name = GGvHJKP9LUxEk10Fw.findall('itemprop="title">(.*?)<',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if name: name = name[1]
		else:
			name = cEZpW924rqNYm5.getInfoLabel('ListItem.Label')
			if '[/COLOR]' in name: name = name.split('[/COLOR]',1)[1]
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?name">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+name+' - '+title,ELbNB92cOh5dqtpVmi40kY,92,VFqpJjRySZvgi)
	else:
		rYgcPZ9wVdDF = GGvHJKP9LUxEk10Fw.findall('class="movietitle"><a href="(.*?)">(.*?)<',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if rYgcPZ9wVdDF: ELbNB92cOh5dqtpVmi40kY,title = rYgcPZ9wVdDF[0]
		else: ELbNB92cOh5dqtpVmi40kY,title = url,name
		cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,92,VFqpJjRySZvgi)
	return
def SUfe4unWoXBNFz90xqy(url):
	zzvBg3ShiamAZ,hxtMO1r82E9lCj34NvqZISB = [],[]
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,url,'',headers,'','CIMAFANS-PLAY-1st')
	NbE4qnzmPKGWtjYpoRL3HTS1A = GGvHJKP9LUxEk10Fw.findall('text-shadow: none;">(.*?)<',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if NbE4qnzmPKGWtjYpoRL3HTS1A and hNCJPTucIV7GOSR0HytZ6eQrqEUpw(cTJphS1nFz5EUgNWm86C,url,NbE4qnzmPKGWtjYpoRL3HTS1A): return
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('id="links-panel(.*?)div',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY in items:
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?__download'
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('nav-tabs"(.*?)video-panel-more',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('id="(.*?)".*?embed src="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for id,ELbNB92cOh5dqtpVmi40kY in items:
			title = 'سيرفر '+id
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named='+title+'__watch'
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
		items = GGvHJKP9LUxEk10Fw.findall('data-server-src="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY in items:
			if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = 'http:'+ELbNB92cOh5dqtpVmi40kY
			ELbNB92cOh5dqtpVmi40kY = GhPlajzTxY8(ELbNB92cOh5dqtpVmi40kY)
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(zzvBg3ShiamAZ,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def CymTbuXdDhL():
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,NBm2aWhPzoTpdYn,'',headers,'','CIMAFANS-LATEST-1st')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('id="index-last-movie(.*?)id="index-slider-movie',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('src="(.*?)".*?href="(.*?)" title="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for VFqpJjRySZvgi,ELbNB92cOh5dqtpVmi40kY,title in items:
		if '/video/' in ELbNB92cOh5dqtpVmi40kY: cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,92,VFqpJjRySZvgi)
		else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,91,VFqpJjRySZvgi)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	search = search.replace(' ','+')
	url = NBm2aWhPzoTpdYn + '/search.php?t='+search
	L4L0TUsN51taeljfc(url)
	return
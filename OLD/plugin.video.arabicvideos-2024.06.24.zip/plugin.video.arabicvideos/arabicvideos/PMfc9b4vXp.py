# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'TVFUN'
mmDwMlfoHtG5XT19VLIWqCR8i = '_TVF_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
DDXTwbRBaj3e2rSsPQ = ['بث مباشر']
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==460: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==461: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,text)
	elif mode==462: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==463: zpXG3Ky6ou8ndWHkb4 = hWPvGlXZ5arzV7(url)
	elif mode==469: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',NBm2aWhPzoTpdYn,'','','','','TVFUN-MENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',469,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"menu-btn"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?<span>(.*?)</span>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
			if title=='الرئيسية': title = 'جديد حلقات تيفي فان'
			if title in DDXTwbRBaj3e2rSsPQ: continue
			cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,461)
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(url,nKuYjzcZEXky6Va5UdoJfH1xqstL=''):
	items = []
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','TVFUN-TITLES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="head-title"(.*?)id="footer"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('class="thumb.*?href="(.*?)".*?src="(.*?)".*?">(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		IcJOGsq3Ff7EmkiLx = []
		Dq0X5cvgdjwh6LbnUkETFBR8 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
		for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
			title = '_MOD_'+title.replace('<br>',' ').replace('  ',' ').strip(' ')
			if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
			ELbNB92cOh5dqtpVmi40kY = GhPlajzTxY8(ELbNB92cOh5dqtpVmi40kY)
			qUGxSK2VwsiBAdkDZnJ605vQeg = GGvHJKP9LUxEk10Fw.findall('(.*?) الحلقة \d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
			if any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in Dq0X5cvgdjwh6LbnUkETFBR8):
				cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,462,VFqpJjRySZvgi)
			elif qUGxSK2VwsiBAdkDZnJ605vQeg and 'الحلقة' in title:
				title = '_MOD_' + qUGxSK2VwsiBAdkDZnJ605vQeg[0]
				if title not in IcJOGsq3Ff7EmkiLx:
					cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,463,VFqpJjRySZvgi)
					IcJOGsq3Ff7EmkiLx.append(title)
			else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,463,VFqpJjRySZvgi)
	if nKuYjzcZEXky6Va5UdoJfH1xqstL!='latest':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"pagination"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
			items = GGvHJKP9LUxEk10Fw.findall('<a href="(.*?)".*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.strip(' ')
				if ELbNB92cOh5dqtpVmi40kY=="": continue
				if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
				if title!='': cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,461)
	return
def hWPvGlXZ5arzV7(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','TVFUN-EPISODES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="head-title"(.*?)id="footer"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('class="thumb.*?href="(.*?)".*?src="(.*?)".*?">(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if items:
			for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
				title = '_MOD_'+title.replace('<br>',' ').replace('  ',' ').strip(' ')
				if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
				cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,462,VFqpJjRySZvgi)
		else:
			items = GGvHJKP9LUxEk10Fw.findall('class="episode.*?href="(.*?)" title="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
				cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,462)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"pagination"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.strip(' ')
			if ELbNB92cOh5dqtpVmi40kY=="": continue
			if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
			if title!='': cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,463)
	return
def SUfe4unWoXBNFz90xqy(url):
	zzvBg3ShiamAZ = []
	dR2vHyAtl8pJN1 = url.replace('/video/','/watch/')
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',dR2vHyAtl8pJN1,'','','','','TVFUN-PLAY-2nd')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('VideoServers"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		gI487voLsArVqW6Ffp = GGvHJKP9LUxEk10Fw.findall('''setVideo\('(.*?)'\).*?">(.*?)<''',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for n5jroYmwhSxNCf4KMu6b18L9qze,name in gI487voLsArVqW6Ffp:
			n5jroYmwhSxNCf4KMu6b18L9qze = n5jroYmwhSxNCf4KMu6b18L9qze[2:]
			if HHosl5fRdhtEDAYyP: n5jroYmwhSxNCf4KMu6b18L9qze = n5jroYmwhSxNCf4KMu6b18L9qze.decode('utf8')
			n5jroYmwhSxNCf4KMu6b18L9qze = hNe0ECZHr9B6.b64decode(n5jroYmwhSxNCf4KMu6b18L9qze)
			if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: n5jroYmwhSxNCf4KMu6b18L9qze = n5jroYmwhSxNCf4KMu6b18L9qze.decode('utf8')
			ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall('src="(.*?)"',n5jroYmwhSxNCf4KMu6b18L9qze,GGvHJKP9LUxEk10Fw.DOTALL)
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY[0]
			if 'http' not in ELbNB92cOh5dqtpVmi40kY:
				if '//' in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = 'http:'+ELbNB92cOh5dqtpVmi40kY
				else: ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
			if ELbNB92cOh5dqtpVmi40kY not in zzvBg3ShiamAZ:
				ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named='+name+'__watch'
				zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(zzvBg3ShiamAZ,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if not search:
		search = yMRXZIpKxlSkaE6iCO()
		if not search: return
	if ' ' in search:
		if showDialogs: aHKzv76JCVnprbY8w('','','TVFUN موقع تيفي فان','للأسف البحث في هذا الموقع لا يعمل عند طلب أكثر من كلمة واحدة ... يرجى البحث عن كلمة واحدة فقط')
		return
	url = NBm2aWhPzoTpdYn+'/q/'+search+'/'
	xoiXMWjJC3pnQqurIGPkRSl8e(url)
	return
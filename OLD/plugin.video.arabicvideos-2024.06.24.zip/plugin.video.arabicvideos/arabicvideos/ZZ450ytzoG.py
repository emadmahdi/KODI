﻿# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(VRnfEFmJzUrSljM8,uf23v5ZPejSmL8EDI):
	if uf23v5ZPejSmL8EDI=='': return
	if VRnfEFmJzUrSljM8==1:
		Ii3JAtnvZlskgFYQ = zz2LJUB9kjnZqAeH.getCurrentWindowDialogId()
		zXVpvERrQx5jlWg6Zweit3fULMmYkq = zz2LJUB9kjnZqAeH.Window(Ii3JAtnvZlskgFYQ)
		uf23v5ZPejSmL8EDI = e2N6JK0pzXdA4By(uf23v5ZPejSmL8EDI)
		zXVpvERrQx5jlWg6Zweit3fULMmYkq.getControl(311).setLabel(uf23v5ZPejSmL8EDI)
	if VRnfEFmJzUrSljM8==0:
		uI7UAQCyPO85aLonkGqrdWwRt='X'
		if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: ZIjyGShVd9clXfxER = isinstance(uf23v5ZPejSmL8EDI,str)
		else: ZIjyGShVd9clXfxER = isinstance(uf23v5ZPejSmL8EDI,unicode)
		if ZIjyGShVd9clXfxER==True: uI7UAQCyPO85aLonkGqrdWwRt='U'
		Mi1xhZ5eYLzlv=str(type(uf23v5ZPejSmL8EDI))+' '+uf23v5ZPejSmL8EDI+' '+uI7UAQCyPO85aLonkGqrdWwRt+' '
		for umP72LtwzUTWHFAlJVyheEp5 in range(0,len(uf23v5ZPejSmL8EDI),1):
			Mi1xhZ5eYLzlv += hex(ord(uf23v5ZPejSmL8EDI[umP72LtwzUTWHFAlJVyheEp5])).replace('0x','')+' '
		uf23v5ZPejSmL8EDI = e2N6JK0pzXdA4By(uf23v5ZPejSmL8EDI)
		uI7UAQCyPO85aLonkGqrdWwRt='X'
		if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: ZIjyGShVd9clXfxER = isinstance(uf23v5ZPejSmL8EDI, str)
		else: ZIjyGShVd9clXfxER = isinstance(uf23v5ZPejSmL8EDI, unicode)
		if ZIjyGShVd9clXfxER==True: uI7UAQCyPO85aLonkGqrdWwRt='U'
		txKJRiscX0g4ojwvnaYbqlMIDE=str(type(uf23v5ZPejSmL8EDI))+' '+uf23v5ZPejSmL8EDI+' '+uI7UAQCyPO85aLonkGqrdWwRt+' '
		for umP72LtwzUTWHFAlJVyheEp5 in range(0,len(uf23v5ZPejSmL8EDI),1):
			txKJRiscX0g4ojwvnaYbqlMIDE += hex(ord(uf23v5ZPejSmL8EDI[umP72LtwzUTWHFAlJVyheEp5])).replace('0x','')+' '
	return
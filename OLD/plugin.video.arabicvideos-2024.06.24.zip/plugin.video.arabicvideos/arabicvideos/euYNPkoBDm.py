# -*- coding: utf-8 -*-
import sys as GGtWyVoJReUuEBCdAagiL1YXO8
ggqTOXpCEcQD68f3oxrKilaSvkdtN = GGtWyVoJReUuEBCdAagiL1YXO8.version_info [0] == 2
pQ14eMnbYBK0xGywR7SuFChJdONj6 = 2048
y65ArzSx9RZh = 7
def MUzuWiALbXp6w5 (TMw2a0zHkY9lcdIvLFZXrS):
	global ynv9hpqlRAJuN0gXrEscaoP5dMWYDO
	Icnd5Dq4krBK3iYg2xNZHF = ord (TMw2a0zHkY9lcdIvLFZXrS [-1])
	u05ustK47xXQZbyFerWTROY = TMw2a0zHkY9lcdIvLFZXrS [:-1]
	BXAu3ZJQ9IPLg7kiy4K06ha = Icnd5Dq4krBK3iYg2xNZHF % len (u05ustK47xXQZbyFerWTROY)
	nRXUw1Fg0DSrkYGL = u05ustK47xXQZbyFerWTROY [:BXAu3ZJQ9IPLg7kiy4K06ha] + u05ustK47xXQZbyFerWTROY [BXAu3ZJQ9IPLg7kiy4K06ha:]
	if ggqTOXpCEcQD68f3oxrKilaSvkdtN:
		sW7Qyn32Zidt5TE4w96 = unicode () .join ([unichr (ord (Lk9Jh0wu7aNAE) - pQ14eMnbYBK0xGywR7SuFChJdONj6 - (Ebxc6eiUkyVNfMBs3CRIOArQ4h + Icnd5Dq4krBK3iYg2xNZHF) % y65ArzSx9RZh) for Ebxc6eiUkyVNfMBs3CRIOArQ4h, Lk9Jh0wu7aNAE in enumerate (nRXUw1Fg0DSrkYGL)])
	else:
		sW7Qyn32Zidt5TE4w96 = str () .join ([chr (ord (Lk9Jh0wu7aNAE) - pQ14eMnbYBK0xGywR7SuFChJdONj6 - (Ebxc6eiUkyVNfMBs3CRIOArQ4h + Icnd5Dq4krBK3iYg2xNZHF) % y65ArzSx9RZh) for Ebxc6eiUkyVNfMBs3CRIOArQ4h, Lk9Jh0wu7aNAE in enumerate (nRXUw1Fg0DSrkYGL)])
	return eval (sW7Qyn32Zidt5TE4w96)
Cu1704YofAbr3QTm,oh5Ptv7RjM3qLk1eEZJbcVzKis4d,LiRcTVUWuth70DmPy=MUzuWiALbXp6w5,MUzuWiALbXp6w5,MUzuWiALbXp6w5
pq3Z6xaELn0NW7PgAeI1bCRwdu,UTelCo0ihE1d5R,Me28A1sBLNIgUp5YCDyvT=LiRcTVUWuth70DmPy,oh5Ptv7RjM3qLk1eEZJbcVzKis4d,Cu1704YofAbr3QTm
kEhAHvti6Vnsfx,g4g6bfkPtVGU5lIM3,E6MIKdpBomef=Me28A1sBLNIgUp5YCDyvT,UTelCo0ihE1d5R,pq3Z6xaELn0NW7PgAeI1bCRwdu
wRxoKs10Syj7V4edYhtP,yA5z6LIXBlo41PRVMY87wOisFp,iUeoLOsbHqP=E6MIKdpBomef,g4g6bfkPtVGU5lIM3,kEhAHvti6Vnsfx
iRoLg2m47tnDATBHGCSPNyx,xW2Arao7YVOemw,l30iT7pjzmXk8dvwSNyUR1aZO4tWh=iUeoLOsbHqP,yA5z6LIXBlo41PRVMY87wOisFp,wRxoKs10Syj7V4edYhtP
dshJSmRqeiP9nap2,FnBiAjthS8MkXs67W,FvNyZqaLKw=l30iT7pjzmXk8dvwSNyUR1aZO4tWh,xW2Arao7YVOemw,iRoLg2m47tnDATBHGCSPNyx
SO94xq1RAkMm2uF,bUdr5Hahw6sY8xJ,XzrqbGDIy54juixkMA=FvNyZqaLKw,FnBiAjthS8MkXs67W,dshJSmRqeiP9nap2
p72fnFtcPix5UKwr9YNzW,sTcr7iDp5eFt4RoLMhuwq1A,SyENPzdOon6uxcLXMhqb14aDlB9r=XzrqbGDIy54juixkMA,bUdr5Hahw6sY8xJ,SO94xq1RAkMm2uF
zqdvcbP5L8BHh,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF,lc0dpSmwoPDjLnk=SyENPzdOon6uxcLXMhqb14aDlB9r,sTcr7iDp5eFt4RoLMhuwq1A,p72fnFtcPix5UKwr9YNzW
QVZl0O8yUIzdGDTfYcn5H37uWmb2,hRNlWkwDitzVpbSO3TIdAm5YGjaZ,fprnld4CZo=lc0dpSmwoPDjLnk,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF,zqdvcbP5L8BHh
hBvsQ7oCkKUdwjx58ml3EN,G5DeRbUpFj8E9OtJLvlo2fWmZC,S4SOKF2QbBhjCd3RrVMuHIzE=fprnld4CZo,hRNlWkwDitzVpbSO3TIdAm5YGjaZ,QVZl0O8yUIzdGDTfYcn5H37uWmb2
import xbmc as cEZpW924rqNYm5,re as GGvHJKP9LUxEk10Fw,sys as GGtWyVoJReUuEBCdAagiL1YXO8,xbmcaddon as utF79ZlYs0VjSMJkOv4UHdf,random as Y7pXj2OtNq9GZdvmcTkS3hMJn,os as WpgZTyqoMAPhwGiXF,xbmcvfs as yynEsDtujBlKNcT0grm8FeLi92A,time as MQbODJoPV2w8TEAg4zXZdjLxSW,pickle as PDtZIYgv8SkOLiU0z3Mwdo29shN,zlib as qYMC32PGUjsnfDtpzg5I,xbmcgui as zz2LJUB9kjnZqAeH,xbmcplugin as XL4sA9FNebx30oE,sqlite3 as j5cfNmnkuUA,traceback as FTYWns4Q7dSEXmBOAGlJ,threading as dM9DZS0pkxbqaf7W
cTJphS1nFz5EUgNWm86C = lc0dpSmwoPDjLnk(u"ࠫࡑࡏࡂࡔࡑࡑࡉࠬਰ")
bdmxngE9YGIeQ = utF79ZlYs0VjSMJkOv4UHdf.Addon().getAddonInfo(FvNyZqaLKw(u"ࠬࡶࡡࡵࡪࠪ਱"))
GByYJDMArKtUZTHezClvPj8da30ip = WpgZTyqoMAPhwGiXF.path.join(bdmxngE9YGIeQ,E6MIKdpBomef(u"࠭ࡰࡢࡥ࡮ࡥ࡬࡫ࡳࠨਲ"))
GGtWyVoJReUuEBCdAagiL1YXO8.path.append(GByYJDMArKtUZTHezClvPj8da30ip)
cc3xyKurSgDZ9pHhLiFk2fjXbTnsN = cEZpW924rqNYm5.getInfoLabel(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠢࡔࡻࡶࡸࡪࡳ࠮ࡃࡷ࡬ࡰࡩ࡜ࡥࡳࡵ࡬ࡳࡳࠨਲ਼"))
yMvF9GoTjhU5biA = GGvHJKP9LUxEk10Fw.findall(lc0dpSmwoPDjLnk(u"ࠨࠪ࡟ࡨࡡࡪ࡜࠯࡞ࡧ࠭ࠬ਴"),cc3xyKurSgDZ9pHhLiFk2fjXbTnsN,GGvHJKP9LUxEk10Fw.DOTALL)
yMvF9GoTjhU5biA = float(yMvF9GoTjhU5biA[S4SOKF2QbBhjCd3RrVMuHIzE(u"࠰ఏ")])
tTc5ELgwNlW1h = cEZpW924rqNYm5.Player
PquO3SKtwbDmYLlvN5Jk9a2 = zz2LJUB9kjnZqAeH.WindowXMLDialog
HHosl5fRdhtEDAYyP = yMvF9GoTjhU5biA<g4g6bfkPtVGU5lIM3(u"࠲࠻ఐ")
u4ChFMGf6K93tbDjJ12zi0YQsAHyP = yMvF9GoTjhU5biA>Cu1704YofAbr3QTm(u"࠳࠻࠲࠾࠿఑")
if u4ChFMGf6K93tbDjJ12zi0YQsAHyP:
	Vst4fzHIp7QLueJnvoGZY0Dm = cEZpW924rqNYm5.LOGINFO
	UUv3pbV4MsPa,NQzGnR49rhjOA0qi7gu = UTelCo0ihE1d5R(u"ࡷࠪࡠࡺ࠸࠰࠳ࡣࠪਵ"),wRxoKs10Syj7V4edYhtP(u"ࡸࠫࡡࡻ࠲࠱࠴ࡥࠫਸ਼")
	jj9UVADwrvmJzeOo5 = yynEsDtujBlKNcT0grm8FeLi92A.translatePath(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡵࡧࡰࡴࠬ਷"))
	from urllib.parse import unquote as _SoHCX1qTsVGQE7L0MNf
else:
	Vst4fzHIp7QLueJnvoGZY0Dm = cEZpW924rqNYm5.LOGNOTICE
	UUv3pbV4MsPa,NQzGnR49rhjOA0qi7gu = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡦ࠭ਸ").encode(bUdr5Hahw6sY8xJ(u"࠭ࡵࡵࡨ࠻ࠫਹ")),UTelCo0ihE1d5R(u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡢࠨ਺").encode(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨࡷࡷࡪ࠽࠭਻"))
	jj9UVADwrvmJzeOo5 = cEZpW924rqNYm5.translatePath(g4g6bfkPtVGU5lIM3(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡺࡥ࡮ࡲ਼ࠪ"))
	from urllib import unquote as _SoHCX1qTsVGQE7L0MNf
MwYiAGqUjd = Me28A1sBLNIgUp5YCDyvT(u"࠹࠴ఒ")
EE1u6LYDqNpi = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠺࠵ఓ")*MwYiAGqUjd
OAc5nlCXF4Qk = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠷࠺ఔ")*EE1u6LYDqNpi
lQoDPv7tBKV5wiJ4f8T3GyE = xW2Arao7YVOemw(u"࠹࠰క")*OAc5nlCXF4Qk
BXnrZSgERcxHvbVQ4 = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠰ఖ")
X9mvsOYNPGeWdaIw01Mf4Jz5p = iRoLg2m47tnDATBHGCSPNyx(u"࠴࠲గ")*MwYiAGqUjd
xh9BXlAw0UoVsIZ4if3 = lc0dpSmwoPDjLnk(u"࠴ఘ")*EE1u6LYDqNpi
Oa8xvPtmLZkBA43K0EzrdhXS = FvNyZqaLKw(u"࠴࠺ఙ")*EE1u6LYDqNpi
ZcdnQAJ3ltkoiPsyX5 = Cu1704YofAbr3QTm(u"࠷చ")*OAc5nlCXF4Qk
OrZFej19nLcNdh2WKRuDJC = wRxoKs10Syj7V4edYhtP(u"࠸࠶ఛ")*OAc5nlCXF4Qk
GOhVkMATsg4cJmfa0Enp6zSqCr = kEhAHvti6Vnsfx(u"࠷࠲జ")*lQoDPv7tBKV5wiJ4f8T3GyE
BBDQiGNydYaPqxEv = g4g6bfkPtVGU5lIM3(u"࠱ఝ")*EE1u6LYDqNpi
ssZLBRtgnMkc7dSouQeGCx3r8m = GGtWyVoJReUuEBCdAagiL1YXO8.argv[SO94xq1RAkMm2uF(u"࠱ఞ")].split(E6MIKdpBomef(u"ࠪ࠳ࠬ਽"))[zqdvcbP5L8BHh(u"࠴ట")]
cmBCkqS7vLYD3flwZ = int(GGtWyVoJReUuEBCdAagiL1YXO8.argv[xW2Arao7YVOemw(u"࠴ఠ")])
jI8KGT6dsgDQ = GGtWyVoJReUuEBCdAagiL1YXO8.argv[dshJSmRqeiP9nap2(u"࠶డ")]
UjWtSARHiPKD8mQ09XgpGTsZ4an = ssZLBRtgnMkc7dSouQeGCx3r8m.split(p72fnFtcPix5UKwr9YNzW(u"ࠫ࠳࠭ਾ"))[iRoLg2m47tnDATBHGCSPNyx(u"࠷ఢ")]
mmn0lB2tFI7XTgVfESo = cEZpW924rqNYm5.getInfoLabel(fprnld4CZo(u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡇࡤࡥࡱࡱ࡚ࡪࡸࡳࡪࡱࡱࠬࠬਿ")+ssZLBRtgnMkc7dSouQeGCx3r8m+iUeoLOsbHqP(u"࠭ࠩࠨੀ"))
JXUQZHLxEgTFbrRC7n9 = WpgZTyqoMAPhwGiXF.path.join(jj9UVADwrvmJzeOo5,ssZLBRtgnMkc7dSouQeGCx3r8m)
UkFh2OXjuTZEaexC = WpgZTyqoMAPhwGiXF.path.join(JXUQZHLxEgTFbrRC7n9,iRoLg2m47tnDATBHGCSPNyx(u"ࠧ࡮ࡣ࡬ࡲࡩࡧࡴࡢ࠰ࡧࡦࠬੁ"))
J2M15kw7Rdv0rQZxITaNuXeyWc = WpgZTyqoMAPhwGiXF.path.join(JXUQZHLxEgTFbrRC7n9,FnBiAjthS8MkXs67W(u"ࠨ࡮ࡤࡷࡹࡼࡩࡥࡧࡲࡷ࠳ࡪࡡࡵࠩੂ"))
MMHpSTojGILfZXWeCOPyn4 = int(MQbODJoPV2w8TEAg4zXZdjLxSW.time())
jHevARrF7lS = utF79ZlYs0VjSMJkOv4UHdf.Addon(id=ssZLBRtgnMkc7dSouQeGCx3r8m)
BGRDN5Ssl8gTz = jHevARrF7lS.getSetting(iRoLg2m47tnDATBHGCSPNyx(u"ࠩࡤࡺ࠳ࡼࡥࡳࡵ࡬ࡳࡳ࠭੃"))
fCQhRT4Nr3gvxstOoADJaY = fprnld4CZo(u"ࡇࡣ࡯ࡷࡪ౹") if BGRDN5Ssl8gTz==mmn0lB2tFI7XTgVfESo else oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࡔࡳࡷࡨ౸")
def xlk0nsAXjIrvOQFL4Vi1MJG5TChu(mHejXxkvM1qCESPVRy54QB,ht2xa9F7Odi1CjMIEGqu3=S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠪࡃࠬ੄")):
	if XzrqbGDIy54juixkMA(u"ࠫࡂ࠭੅") in mHejXxkvM1qCESPVRy54QB:
		if ht2xa9F7Odi1CjMIEGqu3 in mHejXxkvM1qCESPVRy54QB: dR2vHyAtl8pJN1,iwzhluoY5kUB4cmXDSg0O1Zjy8 = mHejXxkvM1qCESPVRy54QB.split(ht2xa9F7Odi1CjMIEGqu3,fprnld4CZo(u"࠷ణ"))
		else: dR2vHyAtl8pJN1,iwzhluoY5kUB4cmXDSg0O1Zjy8 = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬ࠭੆"),mHejXxkvM1qCESPVRy54QB
		iwzhluoY5kUB4cmXDSg0O1Zjy8 = iwzhluoY5kUB4cmXDSg0O1Zjy8.split(Me28A1sBLNIgUp5YCDyvT(u"࠭ࠦࠨੇ"))
		Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = {}
		for iHtKVwo5EZA8g2cB6YqOpyDLMu9b7 in iwzhluoY5kUB4cmXDSg0O1Zjy8:
			EptZi8qnKhHSsuWMg5URx6FIkP,QXbBSpyH3qAEC = iHtKVwo5EZA8g2cB6YqOpyDLMu9b7.split(Me28A1sBLNIgUp5YCDyvT(u"ࠧ࠾ࠩੈ"),fprnld4CZo(u"࠱త"))
			Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd[EptZi8qnKhHSsuWMg5URx6FIkP] = QXbBSpyH3qAEC
	else: dR2vHyAtl8pJN1,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = mHejXxkvM1qCESPVRy54QB,{}
	return dR2vHyAtl8pJN1,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd
def zQP2wplUqKgLE3DYy6OcoSHJfT8(PPVuQkU9OfiBXegYZK2c3Tl6):
	mLe2DaYBZ361AFvwy5S84,jXPWwl4aH0OR9ILzMT5usS,KpIAahrbM31xcBsnjk7WC = lc0dpSmwoPDjLnk(u"ࠨࠩ੉"),kEhAHvti6Vnsfx(u"ࠩࠪ੊"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪࠫੋ")
	PPVuQkU9OfiBXegYZK2c3Tl6 = PPVuQkU9OfiBXegYZK2c3Tl6.replace(UUv3pbV4MsPa,hBvsQ7oCkKUdwjx58ml3EN(u"ࠫࠬੌ")).replace(NQzGnR49rhjOA0qi7gu,iRoLg2m47tnDATBHGCSPNyx(u"੍ࠬ࠭"))
	rYgcPZ9wVdDF = GGvHJKP9LUxEk10Fw.findall(p72fnFtcPix5UKwr9YNzW(u"࠭ࠨ࠯ࠫ࡟࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡡࡣࠨ࡝ࡹ࡟ࡻࡡࡽࠩࠡ࠭࡟࡟ࡡ࠵ࡃࡐࡎࡒࡖࡡࡣࠨ࠯ࠬࡂ࠭ࠩ࠭੎"),PPVuQkU9OfiBXegYZK2c3Tl6,GGvHJKP9LUxEk10Fw.DOTALL)
	if rYgcPZ9wVdDF: mLe2DaYBZ361AFvwy5S84,jXPWwl4aH0OR9ILzMT5usS,PPVuQkU9OfiBXegYZK2c3Tl6 = rYgcPZ9wVdDF[G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠱థ")]
	if mLe2DaYBZ361AFvwy5S84 not in [pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧࠡࠩ੏"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠨ࠮ࠪ੐"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࠪੑ")]: KpIAahrbM31xcBsnjk7WC = iRoLg2m47tnDATBHGCSPNyx(u"ࠪࡣࡒࡕࡄࡠࠩ੒")
	if jXPWwl4aH0OR9ILzMT5usS: jXPWwl4aH0OR9ILzMT5usS = oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫࡤ࠭੓")+jXPWwl4aH0OR9ILzMT5usS+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬࡥࠧ੔")
	PPVuQkU9OfiBXegYZK2c3Tl6 = jXPWwl4aH0OR9ILzMT5usS+KpIAahrbM31xcBsnjk7WC+PPVuQkU9OfiBXegYZK2c3Tl6
	return PPVuQkU9OfiBXegYZK2c3Tl6
def GhPlajzTxY8(mHejXxkvM1qCESPVRy54QB):
	return _SoHCX1qTsVGQE7L0MNf(mHejXxkvM1qCESPVRy54QB)
def z4sqGEoRxKVCSwc3nLZ(o3WvhfgYRx2MOPDJS9):
	Oy2VnGNJZdc4qpWmPCKM = {fprnld4CZo(u"࠭ࡴࡺࡲࡨࠫ੕"):iRoLg2m47tnDATBHGCSPNyx(u"ࠧࠨ੖"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨ࡯ࡲࡨࡪ࠭੗"):SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠩࠪ੘"),kEhAHvti6Vnsfx(u"ࠪࡹࡷࡲࠧਖ਼"):QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫࠬਗ਼"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠬࡺࡥࡹࡶࠪਜ਼"):hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ࠧੜ"),iRoLg2m47tnDATBHGCSPNyx(u"ࠧࡱࡣࡪࡩࠬ੝"):LiRcTVUWuth70DmPy(u"ࠨࠩਫ਼"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠩࡱࡥࡲ࡫ࠧ੟"):kEhAHvti6Vnsfx(u"ࠪࠫ੠"),SO94xq1RAkMm2uF(u"ࠫ࡮ࡳࡡࡨࡧࠪ੡"):xW2Arao7YVOemw(u"ࠬ࠭੢"),lc0dpSmwoPDjLnk(u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ੣"):fprnld4CZo(u"ࠧࠨ੤"),p72fnFtcPix5UKwr9YNzW(u"ࠨ࡫ࡱࡪࡴࡪࡩࡤࡶࠪ੥"):iUeoLOsbHqP(u"ࠩࠪ੦")}
	if p72fnFtcPix5UKwr9YNzW(u"ࠪࡃࠬ੧") in o3WvhfgYRx2MOPDJS9: o3WvhfgYRx2MOPDJS9 = o3WvhfgYRx2MOPDJS9.split(hBvsQ7oCkKUdwjx58ml3EN(u"ࠫࡄ࠭੨"),fprnld4CZo(u"࠳ద"))[fprnld4CZo(u"࠳ద")]
	dR2vHyAtl8pJN1,TRLSqBjs7oaXk = xlk0nsAXjIrvOQFL4Vi1MJG5TChu(o3WvhfgYRx2MOPDJS9)
	aargs = dict(list(Oy2VnGNJZdc4qpWmPCKM.items())+list(TRLSqBjs7oaXk.items()))
	GWaMVJQuw2KR6U9PDI3C0tcd = aargs[LiRcTVUWuth70DmPy(u"ࠬࡳ࡯ࡥࡧࠪ੩")]
	KmsBUDR0jWE4J5I1QLyHvr = GhPlajzTxY8(aargs[UTelCo0ihE1d5R(u"࠭ࡵࡳ࡮ࠪ੪")])
	a5s9g4riQZc0hkFdB = GhPlajzTxY8(aargs[p72fnFtcPix5UKwr9YNzW(u"ࠧࡵࡧࡻࡸࠬ੫")])
	Hax6koyQtZVp4TR = GhPlajzTxY8(aargs[yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨࡲࡤ࡫ࡪ࠭੬")])
	RCVOYBtGemn4La81JyploXFbwZ = GhPlajzTxY8(aargs[S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠩࡷࡽࡵ࡫ࠧ੭")])
	cpH6YnUzMk9A = GhPlajzTxY8(aargs[xW2Arao7YVOemw(u"ࠪࡲࡦࡳࡥࠨ੮")])
	vLfxaY43gW = GhPlajzTxY8(aargs[lc0dpSmwoPDjLnk(u"ࠫ࡮ࡳࡡࡨࡧࠪ੯")])
	B4ucT96ps3nXdvVL12JEOjGYoUDKm = aargs[G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭ੰ")]
	FOvT2mD3KZe90kouy = GhPlajzTxY8(aargs[FvNyZqaLKw(u"࠭ࡩ࡯ࡨࡲࡨ࡮ࡩࡴࠨੱ")])
	if FOvT2mD3KZe90kouy: FOvT2mD3KZe90kouy = eval(FOvT2mD3KZe90kouy)
	else: FOvT2mD3KZe90kouy = {}
	if not GWaMVJQuw2KR6U9PDI3C0tcd: RCVOYBtGemn4La81JyploXFbwZ = iUeoLOsbHqP(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧੲ") ; GWaMVJQuw2KR6U9PDI3C0tcd = iUeoLOsbHqP(u"ࠨ࠴࠹࠴ࠬੳ")
	return RCVOYBtGemn4La81JyploXFbwZ,cpH6YnUzMk9A,KmsBUDR0jWE4J5I1QLyHvr,GWaMVJQuw2KR6U9PDI3C0tcd,vLfxaY43gW,Hax6koyQtZVp4TR,a5s9g4riQZc0hkFdB,B4ucT96ps3nXdvVL12JEOjGYoUDKm,FOvT2mD3KZe90kouy
def jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C):
	QTPJAmZjLBE0obhiYn = GGtWyVoJReUuEBCdAagiL1YXO8._getframe(bUdr5Hahw6sY8xJ(u"࠴ధ")).f_code.co_name
	if not cTJphS1nFz5EUgNWm86C or not QTPJAmZjLBE0obhiYn or QTPJAmZjLBE0obhiYn==iRoLg2m47tnDATBHGCSPNyx(u"ࠩ࠿ࡱࡴࡪࡵ࡭ࡧࡁࠫੴ"):
		return E6MIKdpBomef(u"ࠪ࡟ࠥ࠭ੵ")+UjWtSARHiPKD8mQ09XgpGTsZ4an.upper()+lc0dpSmwoPDjLnk(u"ࠫ࠲࠭੶")+mmn0lB2tFI7XTgVfESo+Me28A1sBLNIgUp5YCDyvT(u"ࠬ࠳ࠧ੷")+str(yMvF9GoTjhU5biA)+fprnld4CZo(u"࠭ࠠ࡞ࠩ੸")
	return iRoLg2m47tnDATBHGCSPNyx(u"ࠧ࠯ࠢࠣࠫ੹")+QTPJAmZjLBE0obhiYn
def LOHZ4o9m7p6ebfTYXGIdz5PWs3q(v9YxuQr62pH17LoEOwZCz8fPkeGMiS,oCrTtRIykV4E9fuKnBGW):
	if HHosl5fRdhtEDAYyP: oCrTtRIykV4E9fuKnBGW = oCrTtRIykV4E9fuKnBGW.decode(fprnld4CZo(u"ࠨࡷࡷࡪ࠽࠭੺")).encode(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩࡸࡸ࡫࠾ࠧ੻"))
	VVK0yLi61jsoAw8TEcI94fup75kDXF = Vst4fzHIp7QLueJnvoGZY0Dm
	ExOjma9CSy2vQbPLhMUworYu = [l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࠫ੼"),FnBiAjthS8MkXs67W(u"ࠫࠬ੽")]
	if v9YxuQr62pH17LoEOwZCz8fPkeGMiS: oCrTtRIykV4E9fuKnBGW = oCrTtRIykV4E9fuKnBGW.replace(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ੾"),UTelCo0ihE1d5R(u"࠭ࠧ੿")).replace(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ઀"),SO94xq1RAkMm2uF(u"ࠨࠩઁ")).replace(kEhAHvti6Vnsfx(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫં"),Cu1704YofAbr3QTm(u"ࠪࠫઃ"))
	else: v9YxuQr62pH17LoEOwZCz8fPkeGMiS = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࡓࡕࡔࡊࡅࡈࠫ઄")
	BhQOrx3n4mEuwzpoSCgTURdL8bKJI9,ht2xa9F7Odi1CjMIEGqu3,Sm0dOH1vhMWjKtzcTsVNq = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬࠦࠠࠡࠢࠪઅ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࠠࠡࠢࠪઆ"),dshJSmRqeiP9nap2(u"ࠧࠨઇ")
	if E6MIKdpBomef(u"ࠨࡇࡕࡖࡔࡘࠧઈ") in v9YxuQr62pH17LoEOwZCz8fPkeGMiS: VVK0yLi61jsoAw8TEcI94fup75kDXF = cEZpW924rqNYm5.LOGERROR
	if v9YxuQr62pH17LoEOwZCz8fPkeGMiS==XzrqbGDIy54juixkMA(u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧઉ"):
		oCrTtRIykV4E9fuKnBGW = oCrTtRIykV4E9fuKnBGW+ht2xa9F7Odi1CjMIEGqu3
		ExOjma9CSy2vQbPLhMUworYu = oCrTtRIykV4E9fuKnBGW.split(ht2xa9F7Odi1CjMIEGqu3)
		Sm0dOH1vhMWjKtzcTsVNq = BhQOrx3n4mEuwzpoSCgTURdL8bKJI9
	elif v9YxuQr62pH17LoEOwZCz8fPkeGMiS==p72fnFtcPix5UKwr9YNzW(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩઊ"):
		oCrTtRIykV4E9fuKnBGW = oCrTtRIykV4E9fuKnBGW.replace(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠫ࠳࠭ઋ")+ht2xa9F7Odi1CjMIEGqu3,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬ࠴ࠠࠡࠩઌ"))
		ExOjma9CSy2vQbPLhMUworYu = oCrTtRIykV4E9fuKnBGW.split(ht2xa9F7Odi1CjMIEGqu3)
		ExOjma9CSy2vQbPLhMUworYu[sTcr7iDp5eFt4RoLMhuwq1A(u"࠵఩")] = dshJSmRqeiP9nap2(u"࠭࠮ࠨઍ")+ExOjma9CSy2vQbPLhMUworYu[sTcr7iDp5eFt4RoLMhuwq1A(u"࠵఩")][Cu1704YofAbr3QTm(u"࠵న"):]
		Sm0dOH1vhMWjKtzcTsVNq = BhQOrx3n4mEuwzpoSCgTURdL8bKJI9+ht2xa9F7Odi1CjMIEGqu3
	elif v9YxuQr62pH17LoEOwZCz8fPkeGMiS in [oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧࡏࡑࡗࡍࡈࡋࠧ઎"),kEhAHvti6Vnsfx(u"ࠨࡇࡕࡖࡔࡘࠧએ")]: ExOjma9CSy2vQbPLhMUworYu = oCrTtRIykV4E9fuKnBGW.split(BhQOrx3n4mEuwzpoSCgTURdL8bKJI9)
	Sm0dOH1vhMWjKtzcTsVNq += LiRcTVUWuth70DmPy(u"࠼ప")*BhQOrx3n4mEuwzpoSCgTURdL8bKJI9
	mPvNk7Qiw0uTJCMRgOD5c8l = XzrqbGDIy54juixkMA(u"࠳ఫ")*BhQOrx3n4mEuwzpoSCgTURdL8bKJI9
	if yMvF9GoTjhU5biA>wRxoKs10Syj7V4edYhtP(u"࠳࠺࠲࠾࠿భ"): Sm0dOH1vhMWjKtzcTsVNq += p72fnFtcPix5UKwr9YNzW(u"࠲࠳బ")*SO94xq1RAkMm2uF(u"ࠩࠣࠫઐ")
	UbvnTHIdtSg9BkEypfXPAzMxGw = ExOjma9CSy2vQbPLhMUworYu[sTcr7iDp5eFt4RoLMhuwq1A(u"࠳మ")]
	for i94LpDNUzy in ExOjma9CSy2vQbPLhMUworYu[hBvsQ7oCkKUdwjx58ml3EN(u"࠵య"):]:
		if dshJSmRqeiP9nap2(u"ࠪࡠࡳ࠭ઑ") in i94LpDNUzy: i94LpDNUzy = i94LpDNUzy.replace(FnBiAjthS8MkXs67W(u"ࠫࡡࡴࠧ઒"),iUeoLOsbHqP(u"ࠬࡢ࡮ࠨઓ")+BhQOrx3n4mEuwzpoSCgTURdL8bKJI9+BhQOrx3n4mEuwzpoSCgTURdL8bKJI9)
		mPvNk7Qiw0uTJCMRgOD5c8l += BhQOrx3n4mEuwzpoSCgTURdL8bKJI9
		UbvnTHIdtSg9BkEypfXPAzMxGw += FvNyZqaLKw(u"࠭࡜ࡳࠩઔ")+Sm0dOH1vhMWjKtzcTsVNq+mPvNk7Qiw0uTJCMRgOD5c8l+i94LpDNUzy
	UbvnTHIdtSg9BkEypfXPAzMxGw += SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠧࠡࡡࠪક")
	if E6MIKdpBomef(u"ࠨࠧࠪખ") in UbvnTHIdtSg9BkEypfXPAzMxGw: UbvnTHIdtSg9BkEypfXPAzMxGw = GhPlajzTxY8(UbvnTHIdtSg9BkEypfXPAzMxGw)
	cEZpW924rqNYm5.log(UbvnTHIdtSg9BkEypfXPAzMxGw,level=VVK0yLi61jsoAw8TEcI94fup75kDXF)
	return
def PlKUSdaCEJ6T0rnL(U2gpeLZJrTRzYNvX0Fni3):
	QAlb96UhsVG = j5cfNmnkuUA.connect(U2gpeLZJrTRzYNvX0Fni3)
	PYRN3CLTut = QAlb96UhsVG.cursor()
	PYRN3CLTut.execute(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠩࡓࡖࡆࡍࡍࡂࠢࡤࡹࡹࡵ࡭ࡢࡶ࡬ࡧࡤ࡯࡮ࡥࡧࡻࡁࡳࡵ࠻ࠨગ"))
	PYRN3CLTut.execute(hBvsQ7oCkKUdwjx58ml3EN(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡪࡴࡸࡥࡪࡩࡱࡣࡰ࡫ࡹࡴ࠿ࡱࡳࡀ࠭ઘ"))
	PYRN3CLTut.execute(fprnld4CZo(u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡮࡭࡮ࡰࡴࡨࡣࡨ࡮ࡥࡤ࡭ࡢࡧࡴࡴࡳࡵࡴࡤ࡭ࡳࡺࡳ࠾ࡻࡨࡷࡀ࠭ઙ"))
	PYRN3CLTut.execute(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬࡖࡒࡂࡉࡐࡅࠥࡰ࡯ࡶࡴࡱࡥࡱࡥ࡭ࡰࡦࡨࡁࡔࡌࡆ࠼ࠩચ"))
	PYRN3CLTut.execute(XzrqbGDIy54juixkMA(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡴࡦ࡯ࡳࡣࡸࡺ࡯ࡳࡧࡀࡑࡊࡓࡏࡓ࡛࠾ࠫછ"))
	PYRN3CLTut.execute(kEhAHvti6Vnsfx(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡴࡻࡱࡧ࡭ࡸ࡯࡯ࡱࡸࡷࡂࡕࡆࡇ࠽ࠪજ"))
	QAlb96UhsVG.text_factory = str
	return QAlb96UhsVG,PYRN3CLTut
def HHg0f8U75SdzxEcbt1JN(U2gpeLZJrTRzYNvX0Fni3,yqMtRI7sYaXkQE3HN2wjczhWF,vMjJHs2fD4WiRK3uVadX=None):
	try: QAlb96UhsVG,PYRN3CLTut = PlKUSdaCEJ6T0rnL(U2gpeLZJrTRzYNvX0Fni3)
	except: return
	if vMjJHs2fD4WiRK3uVadX==None: PYRN3CLTut.execute(XzrqbGDIy54juixkMA(u"ࠨࡆࡕࡓࡕࠦࡔࡂࡄࡏࡉࠥࡏࡆࠡࡇ࡛ࡍࡘ࡚ࡓࠡࠤࠪઝ")+yqMtRI7sYaXkQE3HN2wjczhWF+g4g6bfkPtVGU5lIM3(u"ࠩࠥࠤࡀ࠭ઞ"))
	else:
		acC9XhfeRS = (str(vMjJHs2fD4WiRK3uVadX),)
		try:
			if FvNyZqaLKw(u"ࠪࠩࠬટ") in vMjJHs2fD4WiRK3uVadX: PYRN3CLTut.execute(E6MIKdpBomef(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫઠ")+yqMtRI7sYaXkQE3HN2wjczhWF+yA5z6LIXBlo41PRVMY87wOisFp(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࡬ࡪ࡭ࡨࠤࡄࠦ࠻ࠨડ"),acC9XhfeRS)
			else: PYRN3CLTut.execute(lc0dpSmwoPDjLnk(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭ઢ")+yqMtRI7sYaXkQE3HN2wjczhWF+iUeoLOsbHqP(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧણ"),acC9XhfeRS)
		except: pass
	QAlb96UhsVG.commit()
	QAlb96UhsVG.close()
	return
class dXzPcsQrDyLnU(): pass
class dMPXkHuB87WsyEUNGQ6IeY(dXzPcsQrDyLnU):
	def __init__(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2):
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.url = hBvsQ7oCkKUdwjx58ml3EN(u"ࠨࠩત")
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.code = -FnBiAjthS8MkXs67W(u"࠾࠿ర")
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.reason = xW2Arao7YVOemw(u"ࠩࠪથ")
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.content = Cu1704YofAbr3QTm(u"ࠪࠫદ")
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.headers = {}
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.cookies = {}
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.succeeded = g4g6bfkPtVGU5lIM3(u"ࡈࡤࡰࡸ࡫౺")
def V7yfx6GXUP2DpOtQvCg0(uI7UAQCyPO85aLonkGqrdWwRt):
	if uI7UAQCyPO85aLonkGqrdWwRt==UTelCo0ihE1d5R(u"ࠫࡩ࡯ࡣࡵࠩધ"): rKagANTOtGJnhVWfE2BHpePYC3IQ5l = {}
	elif uI7UAQCyPO85aLonkGqrdWwRt==xW2Arao7YVOemw(u"ࠬࡲࡩࡴࡶࠪન"): rKagANTOtGJnhVWfE2BHpePYC3IQ5l = []
	elif uI7UAQCyPO85aLonkGqrdWwRt==sTcr7iDp5eFt4RoLMhuwq1A(u"࠭ࡳࡵࡴࠪ઩"): rKagANTOtGJnhVWfE2BHpePYC3IQ5l = iRoLg2m47tnDATBHGCSPNyx(u"ࠧࠨપ")
	elif uI7UAQCyPO85aLonkGqrdWwRt==sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨ࡫ࡱࡸࠬફ"): rKagANTOtGJnhVWfE2BHpePYC3IQ5l = iUeoLOsbHqP(u"࠶ఱ")
	elif uI7UAQCyPO85aLonkGqrdWwRt==FvNyZqaLKw(u"ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫબ"): rKagANTOtGJnhVWfE2BHpePYC3IQ5l = dMPXkHuB87WsyEUNGQ6IeY()
	elif not uI7UAQCyPO85aLonkGqrdWwRt: rKagANTOtGJnhVWfE2BHpePYC3IQ5l = None
	else: rKagANTOtGJnhVWfE2BHpePYC3IQ5l = None
	return rKagANTOtGJnhVWfE2BHpePYC3IQ5l
def bkHiCyWXjdgvF9xE1DA6wQ48(pgQ0W7Doks):
	from hashlib import md5 as iWY9OsI5lM6tuDA2RfhmqkPdBQv
	MyJz0spC6Ol2br1g9TEiZ5HVUeQRG = jHevARrF7lS.getSetting(lc0dpSmwoPDjLnk(u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷ࠶࠭ભ"))
	tQF2Zzc3ByWs9SfMmH5Oqnr = PW2xo0Kq3Tcprj9Ck(lc0dpSmwoPDjLnk(u"࠳࠳ల")).splitlines()
	KlH9sXF0WBjJA57dU = sTcr7iDp5eFt4RoLMhuwq1A(u"࠱ళ")
	for Lb4WtO6kIjfKDEgeazX1803oCq2Grc in [MMHpSTojGILfZXWeCOPyn4,MMHpSTojGILfZXWeCOPyn4-xh9BXlAw0UoVsIZ4if3]:
		aERoDgOeAwxNh7b5pkq = str(Lb4WtO6kIjfKDEgeazX1803oCq2Grc*p72fnFtcPix5UKwr9YNzW(u"࠵࠵࠶࠰࠱࠲࠱࠴శ")/g4g6bfkPtVGU5lIM3(u"࠷࠷࠷࠶࠰࠱వ"))[sTcr7iDp5eFt4RoLMhuwq1A(u"࠲ఴ"):pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠹ష")]
		if aERoDgOeAwxNh7b5pkq!=KlH9sXF0WBjJA57dU:
			for viKhygtBYs21 in tQF2Zzc3ByWs9SfMmH5Oqnr:
				gifF82hqluIzbQ4 = XzrqbGDIy54juixkMA(u"ࠫ࡝࠷࠹ࠨમ")+pgQ0W7Doks+SO94xq1RAkMm2uF(u"ࠬ࠷࠸࠾ࠩય")+viKhygtBYs21[-g4g6bfkPtVGU5lIM3(u"࠸࠴స"):]+mmn0lB2tFI7XTgVfESo+aERoDgOeAwxNh7b5pkq
				gifF82hqluIzbQ4 = iWY9OsI5lM6tuDA2RfhmqkPdBQv(gifF82hqluIzbQ4.encode(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭ࡵࡵࡨ࠻ࠫર"))).hexdigest()[:yA5z6LIXBlo41PRVMY87wOisFp(u"࠳࠳హ")]
				if gifF82hqluIzbQ4 in MyJz0spC6Ol2br1g9TEiZ5HVUeQRG: return Cu1704YofAbr3QTm(u"ࡗࡶࡺ࡫౻")
			KlH9sXF0WBjJA57dU = aERoDgOeAwxNh7b5pkq
	return YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࡊࡦࡲࡳࡦ౼")
def P702PlzKg5o3mELCt(U2gpeLZJrTRzYNvX0Fni3,AABznaCO5Hxd8Ig,yqMtRI7sYaXkQE3HN2wjczhWF,vMjJHs2fD4WiRK3uVadX=None):
	rKagANTOtGJnhVWfE2BHpePYC3IQ5l = V7yfx6GXUP2DpOtQvCg0(AABznaCO5Hxd8Ig)
	cUsgVlb0iuBaW7OjSw4oCPL = jHevARrF7lS.getSetting(hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱࡬ࡹࡺࡰࡤࡣࡦ࡬ࡪ࠭઱"))
	if yqMtRI7sYaXkQE3HN2wjczhWF!=kEhAHvti6Vnsfx(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫલ") and U2gpeLZJrTRzYNvX0Fni3==UkFh2OXjuTZEaexC:
		if cUsgVlb0iuBaW7OjSw4oCPL==Cu1704YofAbr3QTm(u"ࠩࡖࡘࡔࡖࠧળ"): return rKagANTOtGJnhVWfE2BHpePYC3IQ5l
		gGudVm2TlMnyh = jHevARrF7lS.getSetting(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧ઴"))
		if gGudVm2TlMnyh==S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࡗࡋࡆࡓࡇࡖࡌࡊࡊࠧવ"):
			HHg0f8U75SdzxEcbt1JN(U2gpeLZJrTRzYNvX0Fni3,yqMtRI7sYaXkQE3HN2wjczhWF,vMjJHs2fD4WiRK3uVadX)
			return rKagANTOtGJnhVWfE2BHpePYC3IQ5l
	TXQokhuymON = XzrqbGDIy54juixkMA(u"࠱఺")
	if cUsgVlb0iuBaW7OjSw4oCPL==Cu1704YofAbr3QTm(u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭શ"): TXQokhuymON = BBDQiGNydYaPqxEv
	try: QAlb96UhsVG,PYRN3CLTut = PlKUSdaCEJ6T0rnL(U2gpeLZJrTRzYNvX0Fni3)
	except: return rKagANTOtGJnhVWfE2BHpePYC3IQ5l
	WHBwQrvgV9mNPMiYuz = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࡙ࡸࡵࡦ౽")
	try: PYRN3CLTut.execute(dshJSmRqeiP9nap2(u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࠪࠡࡈࡕࡓࡒࠦࠢࠨષ")+yqMtRI7sYaXkQE3HN2wjczhWF+Me28A1sBLNIgUp5YCDyvT(u"ࠧࠣࠢࡏࡍࡒࡏࡔࠡ࠳ࠣ࠿ࠬસ"))
	except: WHBwQrvgV9mNPMiYuz = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࡌࡡ࡭ࡵࡨ౾")
	if WHBwQrvgV9mNPMiYuz:
		if TXQokhuymON: PYRN3CLTut.execute(zqdvcbP5L8BHh(u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠢࠨહ")+yqMtRI7sYaXkQE3HN2wjczhWF+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡩࡽࡶࡩࡳࡻࡁࠫ઺")+str(MMHpSTojGILfZXWeCOPyn4+TXQokhuymON)+hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪࠤࡀ࠭઻"))
		QAlb96UhsVG.commit()
		PYRN3CLTut.execute(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎ઼ࠢࠥࠫ")+yqMtRI7sYaXkQE3HN2wjczhWF+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡥࡹࡲ࡬ࡶࡾࡂࠧઽ")+str(MMHpSTojGILfZXWeCOPyn4)+UTelCo0ihE1d5R(u"࠭ࠠ࠼ࠩા"))
		QAlb96UhsVG.commit()
		if vMjJHs2fD4WiRK3uVadX:
			acC9XhfeRS = (str(vMjJHs2fD4WiRK3uVadX),)
			PYRN3CLTut.execute(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡥࡣࡷࡥࠥࡌࡒࡐࡏࠣࠦࠬિ")+yqMtRI7sYaXkQE3HN2wjczhWF+bUdr5Hahw6sY8xJ(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨી"),acC9XhfeRS)
			NOpl1LBIvGax8oHDbj9 = PYRN3CLTut.fetchall()
			if NOpl1LBIvGax8oHDbj9:
				try:
					fH8bDPV6AceuCFNO0Ert7oq3p = qYMC32PGUjsnfDtpzg5I.decompress(NOpl1LBIvGax8oHDbj9[Me28A1sBLNIgUp5YCDyvT(u"࠲఻")][Me28A1sBLNIgUp5YCDyvT(u"࠲఻")])
					rKagANTOtGJnhVWfE2BHpePYC3IQ5l = PDtZIYgv8SkOLiU0z3Mwdo29shN.loads(fH8bDPV6AceuCFNO0Ert7oq3p)
				except: pass
		else:
			PYRN3CLTut.execute(dshJSmRqeiP9nap2(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡦࡳࡱࡻ࡭࡯࠮ࡧࡥࡹࡧࠠࡇࡔࡒࡑࠥࠨࠧુ")+yqMtRI7sYaXkQE3HN2wjczhWF+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠪࠦࠥࡁࠧૂ"))
			NOpl1LBIvGax8oHDbj9 = PYRN3CLTut.fetchall()
			if NOpl1LBIvGax8oHDbj9:
				rKagANTOtGJnhVWfE2BHpePYC3IQ5l,hhy6pDGv94fPUQs1ESzxHK = {},[]
				for SmVq7jzdlK04FcIiZ5ObUapL,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd in NOpl1LBIvGax8oHDbj9:
					F2jvcEiRap8KbWh = qYMC32PGUjsnfDtpzg5I.decompress(Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd)
					Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = PDtZIYgv8SkOLiU0z3Mwdo29shN.loads(F2jvcEiRap8KbWh)
					rKagANTOtGJnhVWfE2BHpePYC3IQ5l[SmVq7jzdlK04FcIiZ5ObUapL] = Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd
					hhy6pDGv94fPUQs1ESzxHK.append(SmVq7jzdlK04FcIiZ5ObUapL)
				if hhy6pDGv94fPUQs1ESzxHK:
					rKagANTOtGJnhVWfE2BHpePYC3IQ5l[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠫࡤࡥࡓࡆࡓࡘࡉࡓࡉࡅࡅࡡࡆࡓࡑ࡛ࡍࡏࡕࡢࡣࠬૃ")] = hhy6pDGv94fPUQs1ESzxHK
					if AABznaCO5Hxd8Ig==G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠬࡲࡩࡴࡶࠪૄ"): rKagANTOtGJnhVWfE2BHpePYC3IQ5l = hhy6pDGv94fPUQs1ESzxHK
	QAlb96UhsVG.close()
	return rKagANTOtGJnhVWfE2BHpePYC3IQ5l
class CCBqEGLDlhno8zF4VKQsYpRMvk(tTc5ELgwNlW1h):
	def __init__(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2): pass
	def SxalJMDUBqsAwOTu8bQtL7d(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2,eExNKbV8wRjtzk5oh):
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.ooOesU7ElkjD8r6w3ubi = bkHiCyWXjdgvF9xE1DA6wQ48(LiRcTVUWuth70DmPy(u"࠭ࡃࡕࡇ࠼ࡈࡘ࠷࠹ࡗࡗ࠳࡚ࡘ࡞ࠧૅ"))
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.G3G7frxqk1mXIF86CBH9RMZ = bkHiCyWXjdgvF9xE1DA6wQ48(iRoLg2m47tnDATBHGCSPNyx(u"ࠧࡘࡕࡘࡖࡋ࡚࠱࠺ࡓࡗࡉࡋࡠࡘࠨ૆"))
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.GYIg5Pak9EShqFlHnWTQi3vd78 = bkHiCyWXjdgvF9xE1DA6wQ48(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨࡄࡗࡉࡽࡖࡖ࠲࠻ࡘࡖ࡛ࡔࡕࡔࡗ࠸ࡌ࡝࠭ે"))
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.h7hs0dloPeOfzGb39puZ4LxB = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠪૈ") if UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.ooOesU7ElkjD8r6w3ubi else iUeoLOsbHqP(u"ࠪࠫૉ")
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.eExNKbV8wRjtzk5oh = eExNKbV8wRjtzk5oh
		if not UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.G3G7frxqk1mXIF86CBH9RMZ:
			from ccTpfuSVZY import o05ntqDmjf3OZBLgNlckQH
			o05ntqDmjf3OZBLgNlckQH(X9mvsOYNPGeWdaIw01Mf4Jz5p)
	def onPlayBackStopped(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2): UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.h7hs0dloPeOfzGb39puZ4LxB = XzrqbGDIy54juixkMA(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ૊")
	def onPlayBackError(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2): UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.h7hs0dloPeOfzGb39puZ4LxB = zqdvcbP5L8BHh(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬો")
	def onPlayBackEnded(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2): UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.h7hs0dloPeOfzGb39puZ4LxB = g4g6bfkPtVGU5lIM3(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ૌ")
	def onPlayBackStarted(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2):
		UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.h7hs0dloPeOfzGb39puZ4LxB = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࠨ્")
		SyexTr9KDWnEMBzIcqtC0sZbXG7Qwl = dM9DZS0pkxbqaf7W.Thread(target=UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.VVCbyNTAXPd,args=())
		SyexTr9KDWnEMBzIcqtC0sZbXG7Qwl.start()
	def onAVStarted(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2):
		if UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.G3G7frxqk1mXIF86CBH9RMZ: UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.h7hs0dloPeOfzGb39puZ4LxB = hBvsQ7oCkKUdwjx58ml3EN(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ૎")
		else: UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.h7hs0dloPeOfzGb39puZ4LxB = fprnld4CZo(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪ૏")
	def VVCbyNTAXPd(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2):
		from ccTpfuSVZY import AacQrJ0RSlzI4,fMcamW7S36DCtuvGndVhTj4ZbO5P,Mrch2HElwVNnm9siDCkZIKFbYL6ao7
		Mrch2HElwVNnm9siDCkZIKFbYL6ao7(dshJSmRqeiP9nap2(u"ࠪࡷࡹࡵࡰࠨૐ"))
		WapqR0PcwGkduO7LQHx4gDftli5I = S4SOKF2QbBhjCd3RrVMuHIzE(u"࠳఼")
		while not eval(FnBiAjthS8MkXs67W(u"ࠫࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲࡮ࡹࡐ࡭ࡣࡼ࡭ࡳ࡭ࡖࡪࡦࡨࡳ࠭࠯ࠧ૑"),{E6MIKdpBomef(u"ࠬࡾࡢ࡮ࡥࠪ૒"):cEZpW924rqNYm5}) and UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.h7hs0dloPeOfzGb39puZ4LxB==iUeoLOsbHqP(u"࠭ࡳࡵࡣࡵࡸࡪࡪࠧ૓"):
			cEZpW924rqNYm5.sleep(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠵࠵࠶࠰ఽ"))
			WapqR0PcwGkduO7LQHx4gDftli5I += iRoLg2m47tnDATBHGCSPNyx(u"࠶ా")
			if WapqR0PcwGkduO7LQHx4gDftli5I>xW2Arao7YVOemw(u"࠼࠰ి"): return
		if UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.ooOesU7ElkjD8r6w3ubi: UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.h7hs0dloPeOfzGb39puZ4LxB = iUeoLOsbHqP(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠨ૔")
		elif UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.G3G7frxqk1mXIF86CBH9RMZ: UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.h7hs0dloPeOfzGb39puZ4LxB = kEhAHvti6Vnsfx(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ૕")
		elif UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.GYIg5Pak9EShqFlHnWTQi3vd78:
			UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.h7hs0dloPeOfzGb39puZ4LxB = kEhAHvti6Vnsfx(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪ૖")
			a3z4KjO1Do8PfdYEgn7pVS6JZHB = dM9DZS0pkxbqaf7W.Thread(target=AacQrJ0RSlzI4,args=(UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.eExNKbV8wRjtzk5oh,))
			a3z4KjO1Do8PfdYEgn7pVS6JZHB.start()
			hqGjzw1utX5Zsc0TCHo2RdWM7 = dM9DZS0pkxbqaf7W.Thread(target=fMcamW7S36DCtuvGndVhTj4ZbO5P,args=())
			hqGjzw1utX5Zsc0TCHo2RdWM7.start()
		else: UeMRfv6PpNVaBnHJ89KbtuI1cA7D2.h7hs0dloPeOfzGb39puZ4LxB = g4g6bfkPtVGU5lIM3(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ૗")
def IdTRDXA2bhlkof8MvUtYpq():
	KaHYWEgsFQbUhCSZl43zrc,ePJlpSEzQjhv9GOfANLURdV = dshJSmRqeiP9nap2(u"ࠫࠬ૘"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬ࠭૙")
	ttCd3lwrWVASs4q92aGiboHEX = cEZpW924rqNYm5.getInfoLabel(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡆࡳ࡫ࡨࡲࡩࡲࡹࡏࡣࡰࡩࠬ૚"))
	try:
		Ij5fxwJRz1QglSaOVs0vBy6MoKq = open(E6MIKdpBomef(u"ࠧ࠰ࡲࡵࡳࡨ࠵ࡣࡱࡷ࡬ࡲ࡫ࡵࠧ૛"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨࡴࡥࠫ૜")).read()
		if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: Ij5fxwJRz1QglSaOVs0vBy6MoKq = Ij5fxwJRz1QglSaOVs0vBy6MoKq.decode(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠩࡸࡸ࡫࠾ࠧ૝"))
		Hsn3w42plUr95vz7FRgadxGN = GGvHJKP9LUxEk10Fw.findall(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠪࡗࡪࡸࡩࡢ࡮࠱࠮ࡄࡀࠠࠩ࠰࠭ࡃ࠮ࠪࠧ૞"),Ij5fxwJRz1QglSaOVs0vBy6MoKq,GGvHJKP9LUxEk10Fw.IGNORECASE)
		if Hsn3w42plUr95vz7FRgadxGN: KaHYWEgsFQbUhCSZl43zrc = Hsn3w42plUr95vz7FRgadxGN[Cu1704YofAbr3QTm(u"࠰ీ")]
	except: pass
	try:
		import subprocess as VVTLiYAdxGkP7
		QeCqwB5WU3TZ402yuDt = VVTLiYAdxGkP7.Popen(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࡸࡺࡡࡵࠢ࠰ࡧࠥࠨ࡚ࠠࠦࠣࠦࠥ࠵ࡳࡵࡱࡵࡥ࡬࡫࠯ࡦ࡯ࡸࡰࡦࡺࡥࡥ࠱࠳ࠤࡀࠦࡳࡵࡣࡷࠤ࠲ࡩࠠࠣࠢࠨ࡛ࠥࠨࠠ࠰ࡸࡤࡶ࠴ࡲ࡯ࡨࠩ૟"),shell=FvNyZqaLKw(u"ࡔࡳࡷࡨ౿"),stdin=VVTLiYAdxGkP7.PIPE,stdout=VVTLiYAdxGkP7.PIPE,stderr=VVTLiYAdxGkP7.PIPE)
		RR5SM1KEzvOgdi6LrDZlwum9YfnGhA = QeCqwB5WU3TZ402yuDt.stdout.read()
		if RR5SM1KEzvOgdi6LrDZlwum9YfnGhA:
			if u4ChFMGf6K93tbDjJ12zi0YQsAHyP:
				RR5SM1KEzvOgdi6LrDZlwum9YfnGhA = RR5SM1KEzvOgdi6LrDZlwum9YfnGhA.decode(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠬࡻࡴࡧ࠺ࠪૠ"),lc0dpSmwoPDjLnk(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ૡ"))
			CJZhPpHEV7Atx6SGBw = GGvHJKP9LUxEk10Fw.findall(FnBiAjthS8MkXs67W(u"ࠧࠡࠪ࡟ࡨࢀ࠷࠰ࡾࠫࠣࠫૢ"),RR5SM1KEzvOgdi6LrDZlwum9YfnGhA,GGvHJKP9LUxEk10Fw.IGNORECASE)
			if CJZhPpHEV7Atx6SGBw: ePJlpSEzQjhv9GOfANLURdV = min(CJZhPpHEV7Atx6SGBw)
	except: pass
	return ttCd3lwrWVASs4q92aGiboHEX,KaHYWEgsFQbUhCSZl43zrc,ePJlpSEzQjhv9GOfANLURdV
def PW2xo0Kq3Tcprj9Ck(EFfqeBcwy8xLPgk1M0Izao,Gdw5MU3hrTnvSzuJA=bUdr5Hahw6sY8xJ(u"ࡕࡴࡸࡩಀ")):
	YJSCdiVeyGQ5FAKmtw = zqdvcbP5L8BHh(u"ࡖࡵࡹࡪಁ")
	if Gdw5MU3hrTnvSzuJA:
		A1BQMkSWPZufjqwdaVcCnt = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠨ࡮࡬ࡷࡹ࠭ૣ"),g4g6bfkPtVGU5lIM3(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ૤"),XzrqbGDIy54juixkMA(u"ࠪࡗࡎ࡚ࡅࡔࡡࡆࡌࡊࡉࡋࠨ૥"))
		if A1BQMkSWPZufjqwdaVcCnt:
			tQF2Zzc3ByWs9SfMmH5Oqnr,x7o2l1ufWh,QBFXnxSb2wvphO3C7JNqR5W,XJUsvSVIoHqaGRWfxbwC8zTh = A1BQMkSWPZufjqwdaVcCnt
			YJSCdiVeyGQ5FAKmtw = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,Cu1704YofAbr3QTm(u"ࠫࡱ࡯ࡳࡵࠩ૦"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ૧"),xW2Arao7YVOemw(u"࠭ࡓࡊࡖࡈࡗࡤ࡜ࡅࡓࡋࡉ࡝ࠬ૨"))
			if YJSCdiVeyGQ5FAKmtw: ttCd3lwrWVASs4q92aGiboHEX,KaHYWEgsFQbUhCSZl43zrc,ePJlpSEzQjhv9GOfANLURdV = YJSCdiVeyGQ5FAKmtw
			else: ttCd3lwrWVASs4q92aGiboHEX,KaHYWEgsFQbUhCSZl43zrc,ePJlpSEzQjhv9GOfANLURdV = IdTRDXA2bhlkof8MvUtYpq()
			if (x7o2l1ufWh,QBFXnxSb2wvphO3C7JNqR5W,XJUsvSVIoHqaGRWfxbwC8zTh)==(ttCd3lwrWVASs4q92aGiboHEX,KaHYWEgsFQbUhCSZl43zrc,ePJlpSEzQjhv9GOfANLURdV): return FnBiAjthS8MkXs67W(u"ࠧ࡝ࡰࠪ૩").join(tQF2Zzc3ByWs9SfMmH5Oqnr)
	if YJSCdiVeyGQ5FAKmtw: ttCd3lwrWVASs4q92aGiboHEX,KaHYWEgsFQbUhCSZl43zrc,ePJlpSEzQjhv9GOfANLURdV = IdTRDXA2bhlkof8MvUtYpq()
	global XUhp80RSm2PFOyrk519t,U4y2IJmHnGkYXivwRdu
	XUhp80RSm2PFOyrk519t,U4y2IJmHnGkYXivwRdu,yc9W6anNwJIFUq0DQgPBok8ZR = sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨࠩ૪"),bUdr5Hahw6sY8xJ(u"ࠩࠪ૫"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠪࠫ૬")
	EFfqeBcwy8xLPgk1M0Izao = EFfqeBcwy8xLPgk1M0Izao//FnBiAjthS8MkXs67W(u"࠳ు")
	dM9DZS0pkxbqaf7W.Thread(target=HHIOG9pytxT0o4Z5QYS).start()
	dM9DZS0pkxbqaf7W.Thread(target=fAF0zYVBZy4xwLHp7OWmoPhget).start()
	for CQMipytPbq in range(bUdr5Hahw6sY8xJ(u"࠳࠳ూ")):
		MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(yA5z6LIXBlo41PRVMY87wOisFp(u"࠳࠲࠺ృ"))
		if not yc9W6anNwJIFUq0DQgPBok8ZR:
			try:
				m2muEO8WZDoTnbBjyIsU7tN0Pez5 = cEZpW924rqNYm5.getInfoLabel(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࡓ࡫ࡴࡸࡱࡵ࡯࠳ࡓࡡࡤࡃࡧࡨࡷ࡫ࡳࡴࠩ૭"))
				if m2muEO8WZDoTnbBjyIsU7tN0Pez5.count(zqdvcbP5L8BHh(u"ࠬࡀࠧ૮"))==wRxoKs10Syj7V4edYhtP(u"࠺౅") and m2muEO8WZDoTnbBjyIsU7tN0Pez5.count(sTcr7iDp5eFt4RoLMhuwq1A(u"࠭࠰ࠨ૯"))<oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠽ౄ"):
					m2muEO8WZDoTnbBjyIsU7tN0Pez5 = m2muEO8WZDoTnbBjyIsU7tN0Pez5.lower().replace(FvNyZqaLKw(u"ࠧ࠻ࠩ૰"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠨࠩ૱"))
					yc9W6anNwJIFUq0DQgPBok8ZR = str(int(m2muEO8WZDoTnbBjyIsU7tN0Pez5,lc0dpSmwoPDjLnk(u"࠷࠶ె")))
			except: pass
		if XUhp80RSm2PFOyrk519t and U4y2IJmHnGkYXivwRdu and yc9W6anNwJIFUq0DQgPBok8ZR: break
	KDLs24oWy8XewrJBt5vMGh = [XUhp80RSm2PFOyrk519t,U4y2IJmHnGkYXivwRdu,yc9W6anNwJIFUq0DQgPBok8ZR,wRxoKs10Syj7V4edYhtP(u"ࠩࠪ૲"),Me28A1sBLNIgUp5YCDyvT(u"ࠪࠫ૳"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫ࠵࠶࠱࠲࠴࠵࠷࠸࠺࠴࠶࠷࠹࠺࠼࠽ࠧ૴")]
	if KaHYWEgsFQbUhCSZl43zrc or ePJlpSEzQjhv9GOfANLURdV:
		from hashlib import md5 as iWY9OsI5lM6tuDA2RfhmqkPdBQv
		Nwv8LxQh4XsEWyleZ = [(LiRcTVUWuth70DmPy(u"࠵ై"),KaHYWEgsFQbUhCSZl43zrc),(g4g6bfkPtVGU5lIM3(u"࠵ే"),ePJlpSEzQjhv9GOfANLURdV)]
		for EptZi8qnKhHSsuWMg5URx6FIkP,QXbBSpyH3qAEC in Nwv8LxQh4XsEWyleZ:
			QXbBSpyH3qAEC = QXbBSpyH3qAEC.strip(Cu1704YofAbr3QTm(u"ࠬ࠶ࠧ૵"))
			if QXbBSpyH3qAEC:
				if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: QXbBSpyH3qAEC = QXbBSpyH3qAEC.encode(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠭ࡵࡵࡨ࠻ࠫ૶"))
				QXbBSpyH3qAEC = str(int(iWY9OsI5lM6tuDA2RfhmqkPdBQv(QXbBSpyH3qAEC).hexdigest(),yA5z6LIXBlo41PRVMY87wOisFp(u"࠵࠹౉")))
				IhUJlwfyd0N8tP6 = [int(QXbBSpyH3qAEC[nHz8ErR0p5cyqXsuLJ41of:nHz8ErR0p5cyqXsuLJ41of+YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠵࠺ో")]) for nHz8ErR0p5cyqXsuLJ41of in range(len(QXbBSpyH3qAEC)) if nHz8ErR0p5cyqXsuLJ41of%YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠵࠺ో")==yA5z6LIXBlo41PRVMY87wOisFp(u"࠳ొ")]
				KDLs24oWy8XewrJBt5vMGh[EptZi8qnKhHSsuWMg5URx6FIkP-pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠶ౌ")] = str(sum(IhUJlwfyd0N8tP6))
	tQF2Zzc3ByWs9SfMmH5Oqnr,ul6XpSVNkienPWx = [],iUeoLOsbHqP(u"ࡉࡥࡱࡹࡥಂ")
	for NiCBA1fTdM7 in range(len(KDLs24oWy8XewrJBt5vMGh)):
		IhUJlwfyd0N8tP6 = KDLs24oWy8XewrJBt5vMGh[NiCBA1fTdM7]
		if not IhUJlwfyd0N8tP6: continue
		if ul6XpSVNkienPWx and IhUJlwfyd0N8tP6==KDLs24oWy8XewrJBt5vMGh[-pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠷్")]: continue
		ul6XpSVNkienPWx = xW2Arao7YVOemw(u"ࡘࡷࡻࡥಃ")
		IhUJlwfyd0N8tP6 = FvNyZqaLKw(u"ࠧ࠱ࠩ૷")*EFfqeBcwy8xLPgk1M0Izao+IhUJlwfyd0N8tP6
		IhUJlwfyd0N8tP6 = IhUJlwfyd0N8tP6[-EFfqeBcwy8xLPgk1M0Izao:]
		pAgZkqET57,HH9r4IgknCaMKu0b3Z1f = XzrqbGDIy54juixkMA(u"ࠨࠩ૸"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩࠪૹ")
		pn9kE4fWmP7D2dIRZUw = str(int(FnBiAjthS8MkXs67W(u"ࠪ࠽ࠬૺ")*(EFfqeBcwy8xLPgk1M0Izao+yA5z6LIXBlo41PRVMY87wOisFp(u"࠱౎")))-int(IhUJlwfyd0N8tP6))[-EFfqeBcwy8xLPgk1M0Izao:]
		for odfrR0C29T in list(range(fprnld4CZo(u"࠱౏"),EFfqeBcwy8xLPgk1M0Izao,XzrqbGDIy54juixkMA(u"࠶౐"))):
			pAgZkqET57 += pn9kE4fWmP7D2dIRZUw[odfrR0C29T:odfrR0C29T+FvNyZqaLKw(u"࠷౑")]+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫ࠲࠭ૻ")
			HH9r4IgknCaMKu0b3Z1f += str(sum(map(int,IhUJlwfyd0N8tP6[odfrR0C29T:odfrR0C29T+p72fnFtcPix5UKwr9YNzW(u"࠹౓")]))%wRxoKs10Syj7V4edYhtP(u"࠵࠵౒"))
		viKhygtBYs21 = str(NiCBA1fTdM7)+pAgZkqET57+HH9r4IgknCaMKu0b3Z1f
		tQF2Zzc3ByWs9SfMmH5Oqnr.append(viKhygtBYs21)
	Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,lc0dpSmwoPDjLnk(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨૼ"),SO94xq1RAkMm2uF(u"࠭ࡓࡊࡖࡈࡗࡤ࡜ࡅࡓࡋࡉ࡝ࠬ૽"),[ttCd3lwrWVASs4q92aGiboHEX,KaHYWEgsFQbUhCSZl43zrc,ePJlpSEzQjhv9GOfANLURdV],Oa8xvPtmLZkBA43K0EzrdhXS)
	Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ૾"),LiRcTVUWuth70DmPy(u"ࠨࡕࡌࡘࡊ࡙࡟ࡄࡊࡈࡇࡐ࠭૿"),[tQF2Zzc3ByWs9SfMmH5Oqnr,ttCd3lwrWVASs4q92aGiboHEX,KaHYWEgsFQbUhCSZl43zrc,ePJlpSEzQjhv9GOfANLURdV],ZcdnQAJ3ltkoiPsyX5)
	return g4g6bfkPtVGU5lIM3(u"ࠩ࡟ࡲࠬ଀").join(tQF2Zzc3ByWs9SfMmH5Oqnr)
def XXmSpTHNao6Gxbs0eK5(uI7UAQCyPO85aLonkGqrdWwRt,mHejXxkvM1qCESPVRy54QB,rKagANTOtGJnhVWfE2BHpePYC3IQ5l,ep9JAOkj1wr5s,hayXA4TiLlPxcVSIoK2,vYFXP48WV6M):
	BBYvCiQGe8RdpyAagfS72mZclxb5 = str(ep9JAOkj1wr5s)[iUeoLOsbHqP(u"࠶౔"):g4g6bfkPtVGU5lIM3(u"࠲࠶࠲ౕ")].replace(Me28A1sBLNIgUp5YCDyvT(u"ࠪࡠࡳ࠭ଁ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࡡࡢ࡮ࠨଂ")).replace(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬࡢࡲࠨଃ"),LiRcTVUWuth70DmPy(u"࠭࡜࡝ࡴࠪ଄")).replace(xW2Arao7YVOemw(u"ࠧࠡࠢࠣࠤࠬଅ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࠢࠪଆ")).replace(hBvsQ7oCkKUdwjx58ml3EN(u"ࠩࠣࠤࠥ࠭ଇ"),Cu1704YofAbr3QTm(u"ࠪࠤࠬଈ"))
	if len(str(ep9JAOkj1wr5s))>fprnld4CZo(u"࠳࠷࠳ౖ"): BBYvCiQGe8RdpyAagfS72mZclxb5 = BBYvCiQGe8RdpyAagfS72mZclxb5+hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠫࠥ࠴࠮࠯ࠩଉ")
	Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = str(rKagANTOtGJnhVWfE2BHpePYC3IQ5l)[SO94xq1RAkMm2uF(u"࠲౗"):sTcr7iDp5eFt4RoLMhuwq1A(u"࠵࠹࠵ౘ")].replace(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬࡢ࡮ࠨଊ"),E6MIKdpBomef(u"࠭࡜࡝ࡰࠪଋ")).replace(E6MIKdpBomef(u"ࠧ࡝ࡴࠪଌ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨ࡞࡟ࡶࠬ଍")).replace(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠩࠣࠤࠥࠦࠧ଎"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪࠤࠬଏ")).replace(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࠥࠦࠠࠨଐ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠬࠦࠧ଑"))
	if len(str(rKagANTOtGJnhVWfE2BHpePYC3IQ5l))>p72fnFtcPix5UKwr9YNzW(u"࠶࠺࠶ౙ"): Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd+FnBiAjthS8MkXs67W(u"࠭ࠠ࠯࠰࠱ࠫ଒")
	LOHZ4o9m7p6ebfTYXGIdz5PWs3q(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧࡏࡑࡗࡍࡈࡋࠧଓ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠨ࠰ࠣࠤࡔࡖࡅࡏࡗࡕࡐࡤ࠭ଔ")+uI7UAQCyPO85aLonkGqrdWwRt+xW2Arao7YVOemw(u"ࠩࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬକ")+mHejXxkvM1qCESPVRy54QB+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬଖ")+hayXA4TiLlPxcVSIoK2+wRxoKs10Syj7V4edYhtP(u"ࠫࠥࡣࠠࠡࠢࡐࡩࡹ࡮࡯ࡥ࠼ࠣ࡟ࠥ࠭ଗ")+vYFXP48WV6M+kEhAHvti6Vnsfx(u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨଘ")+str(BBYvCiQGe8RdpyAagfS72mZclxb5)+p72fnFtcPix5UKwr9YNzW(u"࠭ࠠ࡞ࠢࠣࠤࡉࡧࡴࡢ࠼ࠣ࡟ࠥ࠭ଙ")+Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd+wRxoKs10Syj7V4edYhtP(u"ࠧࠡ࡟ࠪଚ"))
	return
def HHIOG9pytxT0o4Z5QYS():
	global XUhp80RSm2PFOyrk519t
	import getmac82 as MljVKDiNeH0IdFoyWhTgGUkvb
	try:
		dnFTqZ4u2IktN0vVcla = MljVKDiNeH0IdFoyWhTgGUkvb.get_mac_address()
		if dnFTqZ4u2IktN0vVcla.count(Cu1704YofAbr3QTm(u"ࠨ࠼ࠪଛ"))==QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠻౛") and dnFTqZ4u2IktN0vVcla.count(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩ࠳ࠫଜ"))<SO94xq1RAkMm2uF(u"࠾ౚ"):
			dnFTqZ4u2IktN0vVcla = dnFTqZ4u2IktN0vVcla.lower().replace(iRoLg2m47tnDATBHGCSPNyx(u"ࠪ࠾ࠬଝ"),lc0dpSmwoPDjLnk(u"ࠫࠬଞ"))
			XUhp80RSm2PFOyrk519t = str(int(dnFTqZ4u2IktN0vVcla,S4SOKF2QbBhjCd3RrVMuHIzE(u"࠱࠷౜")))
	except: pass
	return
def fAF0zYVBZy4xwLHp7OWmoPhget():
	global U4y2IJmHnGkYXivwRdu
	import getmac94 as EhZvCO1D9A8x3
	try:
		ogt0ewmATdjbUYaPREy83 = EhZvCO1D9A8x3.get_mac_address()
		if ogt0ewmATdjbUYaPREy83.count(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬࡀࠧଟ"))==iRoLg2m47tnDATBHGCSPNyx(u"࠷౞") and ogt0ewmATdjbUYaPREy83.count(UTelCo0ihE1d5R(u"࠭࠰ࠨଠ"))<S4SOKF2QbBhjCd3RrVMuHIzE(u"࠺ౝ"):
			ogt0ewmATdjbUYaPREy83 = ogt0ewmATdjbUYaPREy83.lower().replace(zqdvcbP5L8BHh(u"ࠧ࠻ࠩଡ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨࠩଢ"))
			U4y2IJmHnGkYXivwRdu = str(int(ogt0ewmATdjbUYaPREy83,lc0dpSmwoPDjLnk(u"࠴࠺౟")))
	except: pass
	return
def t2RpE4wGrDfMvhjJZINln(vYFXP48WV6M,mHejXxkvM1qCESPVRy54QB,rKagANTOtGJnhVWfE2BHpePYC3IQ5l=bUdr5Hahw6sY8xJ(u"ࠩࠪଣ"),ep9JAOkj1wr5s=yA5z6LIXBlo41PRVMY87wOisFp(u"ࠪࠫତ"),hayXA4TiLlPxcVSIoK2=YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠫࠬଥ")):
	XXmSpTHNao6Gxbs0eK5(sTcr7iDp5eFt4RoLMhuwq1A(u"࡛ࠬࡒࡍࡎࡌࡆࠥࠦࡏࡑࡇࡑࡣ࡚ࡘࡌࠨଦ"),mHejXxkvM1qCESPVRy54QB,rKagANTOtGJnhVWfE2BHpePYC3IQ5l,ep9JAOkj1wr5s,hayXA4TiLlPxcVSIoK2,vYFXP48WV6M)
	if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: import urllib.request as NNLp9BwPeyCUjz
	else: import urllib2 as NNLp9BwPeyCUjz
	if not ep9JAOkj1wr5s: ep9JAOkj1wr5s = {p72fnFtcPix5UKwr9YNzW(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪଧ"):bUdr5Hahw6sY8xJ(u"ࠧࠨନ")}
	if not rKagANTOtGJnhVWfE2BHpePYC3IQ5l: rKagANTOtGJnhVWfE2BHpePYC3IQ5l = {}
	if vYFXP48WV6M==wRxoKs10Syj7V4edYhtP(u"ࠨࡉࡈࡘࠬ଩"):
		mHejXxkvM1qCESPVRy54QB = mHejXxkvM1qCESPVRy54QB+lc0dpSmwoPDjLnk(u"ࠩࡂࠫପ")+Hym17NopzZUE3xhYMe(rKagANTOtGJnhVWfE2BHpePYC3IQ5l)
		rKagANTOtGJnhVWfE2BHpePYC3IQ5l = None
	elif vYFXP48WV6M==LiRcTVUWuth70DmPy(u"ࠪࡔࡔ࡙ࡔࠨଫ") and FnBiAjthS8MkXs67W(u"ࠫ࡯ࡹ࡯࡯ࠩବ") in str(ep9JAOkj1wr5s):
		from json import dumps as cgEXLHaeZI1Ky90fWdNo
		rKagANTOtGJnhVWfE2BHpePYC3IQ5l = cgEXLHaeZI1Ky90fWdNo(rKagANTOtGJnhVWfE2BHpePYC3IQ5l)
		rKagANTOtGJnhVWfE2BHpePYC3IQ5l = str(rKagANTOtGJnhVWfE2BHpePYC3IQ5l).encode(E6MIKdpBomef(u"ࠬࡻࡴࡧ࠺ࠪଭ"))
	elif vYFXP48WV6M==p72fnFtcPix5UKwr9YNzW(u"࠭ࡐࡐࡕࡗࠫମ"):
		rKagANTOtGJnhVWfE2BHpePYC3IQ5l = Hym17NopzZUE3xhYMe(rKagANTOtGJnhVWfE2BHpePYC3IQ5l)
		rKagANTOtGJnhVWfE2BHpePYC3IQ5l = rKagANTOtGJnhVWfE2BHpePYC3IQ5l.encode(hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࡶࡶࡩ࠼ࠬଯ"))
	try:
		MMDHxkhWXmTPw0jKBcvq3 = NNLp9BwPeyCUjz.Request(mHejXxkvM1qCESPVRy54QB,headers=ep9JAOkj1wr5s,data=rKagANTOtGJnhVWfE2BHpePYC3IQ5l)
		YutQm2AwozR9VKp4O1lWj8FaryI = NNLp9BwPeyCUjz.urlopen(MMDHxkhWXmTPw0jKBcvq3)
		U9rSWyc74gLOw = YutQm2AwozR9VKp4O1lWj8FaryI.read()
		llhyFWpP90RSDQM,r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6 = fprnld4CZo(u"࠶࠵࠶ౠ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࡑࡎࠫର")
	except:
		U9rSWyc74gLOw = E6MIKdpBomef(u"ࠩࠪ଱")
		llhyFWpP90RSDQM,r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6 = -Me28A1sBLNIgUp5YCDyvT(u"࠶ౡ"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤࡊࡸࡲࡰࡴࠪଲ")
	LOHZ4o9m7p6ebfTYXGIdz5PWs3q(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࡓࡕࡔࡊࡅࡈࠫଳ"),Cu1704YofAbr3QTm(u"ࠬ࠴ࠠࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡘࡖࡑࡒࡉࡃࠢࠣࡖࡊ࡙ࡐࡐࡐࡖࡉࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨ଴")+str(llhyFWpP90RSDQM)+Cu1704YofAbr3QTm(u"࠭ࠠ࡞ࠢࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨଵ")+r2ADgiEcZ5deTWxkIX0ws8G9nmJOB6+p72fnFtcPix5UKwr9YNzW(u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩଶ")+hayXA4TiLlPxcVSIoK2+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧଷ")+mHejXxkvM1qCESPVRy54QB+XzrqbGDIy54juixkMA(u"ࠩࠣࡡࠬସ"))
	if U9rSWyc74gLOw and u4ChFMGf6K93tbDjJ12zi0YQsAHyP: U9rSWyc74gLOw = U9rSWyc74gLOw.decode(FnBiAjthS8MkXs67W(u"ࠪࡹࡹ࡬࠸ࠨହ"))
	return U9rSWyc74gLOw
def EGTmIaUiSoHDC5bJlR19Zksqv(SLfrxi1HIeThZdVF6jRwn9BcPQ4X,AJsDrgGwZzxHXSVNKCb7LT=FvNyZqaLKw(u"ࠫࠬ଺")):
	kkcUIZMRATHLXxCdFitoV9GNqpwW6f = str(Y7pXj2OtNq9GZdvmcTkS3hMJn.randrange(SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠷࠱࠲࠳࠴࠵࠶࠷࠱࠲࠳࠴ౢ"),FnBiAjthS8MkXs67W(u"࠹࠺࠻࠼࠽࠾࠿࠹࠺࠻࠼࠽ౣ")))
	ep9JAOkj1wr5s = {fprnld4CZo(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ଻"):iRoLg2m47tnDATBHGCSPNyx(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯଼ࠩ")}
	SAc8ClRJ9D7 = {	SO94xq1RAkMm2uF(u"ࠢࡶࡵࡨࡶࡤ࡯ࡤࠣଽ"):PW2xo0Kq3Tcprj9Ck(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠵࠵౥")).splitlines()[E6MIKdpBomef(u"࠳౦")][-Me28A1sBLNIgUp5YCDyvT(u"࠳࠶౤"):],
				G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠣࡱࡶࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠧା"):str(yMvF9GoTjhU5biA),
				iRoLg2m47tnDATBHGCSPNyx(u"ࠤࡤࡴࡵࡥࡶࡦࡴࡶ࡭ࡴࡴࠢି"):mmn0lB2tFI7XTgVfESo,
				pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠥࡨࡪࡼࡩࡤࡧࡢࡪࡦࡳࡩ࡭ࡻࠥୀ"):mmn0lB2tFI7XTgVfESo,
				fprnld4CZo(u"ࠦࡪࡼࡥ࡯ࡶࡢࡸࡾࡶࡥࠣୁ"):SLfrxi1HIeThZdVF6jRwn9BcPQ4X,
				xW2Arao7YVOemw(u"ࠧࡶ࡬ࡢࡶࡩࡳࡷࡳࠢୂ"): mmn0lB2tFI7XTgVfESo,
				wRxoKs10Syj7V4edYhtP(u"ࠨࡣࡢࡴࡵ࡭ࡪࡸࠢୃ"):S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠢࡂࡔࡄࡆࡎࡉ࡟ࡗࡋࡇࡉࡔ࡙ࠢୄ"),
				XzrqbGDIy54juixkMA(u"ࠣࡧࡹࡩࡳࡺ࡟ࡱࡴࡲࡴࡪࡸࡴࡪࡧࡶࠦ୅"):{G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠤࡈࡺࡪࡴࡴࡠࡐࡤࡱࡪࠨ୆"):SLfrxi1HIeThZdVF6jRwn9BcPQ4X},
				SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠥࡹࡸ࡫ࡲࡠࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷࠧେ"): {g4g6bfkPtVGU5lIM3(u"࡚ࠦࡹࡥࡳࡡࡈࡺࡪࡴࡴࡠࡐࡤࡱࡪࠨୈ"):SLfrxi1HIeThZdVF6jRwn9BcPQ4X},
				g4g6bfkPtVGU5lIM3(u"ࠧࠪࡳ࡬࡫ࡳࡣࡺࡹࡥࡳࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸࡥࡳࡺࡰࡦࠦ୉"):FvNyZqaLKw(u"ࡋࡧ࡬ࡴࡧ಄"),
				SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࡩࡱࠤ୊"): zqdvcbP5L8BHh(u"ࠢࠥࡴࡨࡱࡴࡺࡥࠣୋ")
			}
	if not AJsDrgGwZzxHXSVNKCb7LT: jy9J87zqHYTbWI4pDFcVt = [SAc8ClRJ9D7]
	else:
		IT0A6mk8fLsROEwu2gMG9Piedo3 = SAc8ClRJ9D7.copy()
		IT0A6mk8fLsROEwu2gMG9Piedo3[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠨࡧࡹࡩࡳࡺ࡟ࡵࡻࡳࡩࠬୌ")] = AJsDrgGwZzxHXSVNKCb7LT
		IT0A6mk8fLsROEwu2gMG9Piedo3[SO94xq1RAkMm2uF(u"ࠩࡨࡺࡪࡴࡴࡠࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷ୍ࠬ")] = {bUdr5Hahw6sY8xJ(u"ࠥࡉࡻ࡫࡮ࡵࡡࡑࡥࡲ࡫ࠢ୎"):AJsDrgGwZzxHXSVNKCb7LT}
		IT0A6mk8fLsROEwu2gMG9Piedo3[S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࡺࡹࡥࡳࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸ࠭୏")] = {lc0dpSmwoPDjLnk(u"࡛ࠧࡳࡦࡴࡢࡉࡻ࡫࡮ࡵࡡࡑࡥࡲ࡫ࠢ୐"):AJsDrgGwZzxHXSVNKCb7LT}
		jy9J87zqHYTbWI4pDFcVt = [SAc8ClRJ9D7,IT0A6mk8fLsROEwu2gMG9Piedo3]
	rKagANTOtGJnhVWfE2BHpePYC3IQ5l = {SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࡡࡱ࡫ࡢ࡯ࡪࡿࠢ୑"):Cu1704YofAbr3QTm(u"ࠧ࠳࠷࠷ࡨࡩ࠹ࡡ࠵࠲࠼ࡨ࠽ࡨ࠶࠹࠳ࡧ࠸ࡪ࠷࠱࠸ࡧࡨ࠻࠽ࡩࡥࡣࡨ࠵࠽ࠬ୒"),
			G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠣ࡫ࡱࡷࡪࡸࡴࡠ࡫ࡧࠦ୓"):kkcUIZMRATHLXxCdFitoV9GNqpwW6f,
			iRoLg2m47tnDATBHGCSPNyx(u"ࠤࡨࡺࡪࡴࡴࡴࠤ୔"): jy9J87zqHYTbWI4pDFcVt
		}
	mHejXxkvM1qCESPVRy54QB = LiRcTVUWuth70DmPy(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡶࡩ࠳࠰ࡤࡱࡵࡲࡩࡵࡷࡧࡩ࠳ࡩ࡯࡮࠱࠵࠳࡭ࡺࡴࡱࡣࡳ࡭ࠬ୕")
	U9rSWyc74gLOw = t2RpE4wGrDfMvhjJZINln(wRxoKs10Syj7V4edYhtP(u"ࠫࡕࡕࡓࡕࠩୖ"),mHejXxkvM1qCESPVRy54QB,rKagANTOtGJnhVWfE2BHpePYC3IQ5l,ep9JAOkj1wr5s,oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡓࡆࡐࡇࡣࡆࡔࡁࡍ࡛ࡗࡍࡈ࡙࡟ࡆࡘࡈࡒ࡙࠳࠱ࡴࡶࠪୗ"))
	return U9rSWyc74gLOw
def JKw5OWktPZB(AABznaCO5Hxd8Ig,fH8bDPV6AceuCFNO0Ert7oq3p):
	fH8bDPV6AceuCFNO0Ert7oq3p = fH8bDPV6AceuCFNO0Ert7oq3p.replace(Cu1704YofAbr3QTm(u"࠭࡮ࡶ࡮࡯ࠫ୘"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧࡏࡱࡱࡩࠬ୙"))
	fH8bDPV6AceuCFNO0Ert7oq3p = fH8bDPV6AceuCFNO0Ert7oq3p.replace(g4g6bfkPtVGU5lIM3(u"ࠨࡶࡵࡹࡪ࠭୚"),FvNyZqaLKw(u"ࠩࡗࡶࡺ࡫ࠧ୛"))
	fH8bDPV6AceuCFNO0Ert7oq3p = fH8bDPV6AceuCFNO0Ert7oq3p.replace(wRxoKs10Syj7V4edYhtP(u"ࠪࡪࡦࡲࡳࡦࠩଡ଼"),wRxoKs10Syj7V4edYhtP(u"ࠫࡋࡧ࡬ࡴࡧࠪଢ଼"))
	fH8bDPV6AceuCFNO0Ert7oq3p = fH8bDPV6AceuCFNO0Ert7oq3p.replace(iUeoLOsbHqP(u"ࠬࡢ࠯ࠨ୞"),bUdr5Hahw6sY8xJ(u"࠭࠯ࠨୟ"))
	try: F2jvcEiRap8KbWh = eval(fH8bDPV6AceuCFNO0Ert7oq3p)
	except: F2jvcEiRap8KbWh = V7yfx6GXUP2DpOtQvCg0(AABznaCO5Hxd8Ig)
	return F2jvcEiRap8KbWh
def BejcHLrmkn9():
	uI7UAQCyPO85aLonkGqrdWwRt,PPVuQkU9OfiBXegYZK2c3Tl6,mHejXxkvM1qCESPVRy54QB,xUmyzZKOd8hv3Jc5X2nPHCAarW4sF,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,fH8bDPV6AceuCFNO0Ert7oq3p,stpvYViqku3,LGdFZQvKeU52s6H0DgjN = z4sqGEoRxKVCSwc3nLZ(jI8KGT6dsgDQ)
	rYgcPZ9wVdDF = GGvHJKP9LUxEk10Fw.findall(FnBiAjthS8MkXs67W(u"ࠧ࡝ࡦ࡟ࡨ࠿ࡢࡤ࡝ࡦࠣࡠࡠ࠵ࡃࡐࡎࡒࡖࡡࡣࠧୠ"),PPVuQkU9OfiBXegYZK2c3Tl6,GGvHJKP9LUxEk10Fw.DOTALL)
	if rYgcPZ9wVdDF: PPVuQkU9OfiBXegYZK2c3Tl6 = PPVuQkU9OfiBXegYZK2c3Tl6.split(rYgcPZ9wVdDF[p72fnFtcPix5UKwr9YNzW(u"࠵౨")],sTcr7iDp5eFt4RoLMhuwq1A(u"࠵౧"))[sTcr7iDp5eFt4RoLMhuwq1A(u"࠵౧")]
	POTvxkwYNAryisqKFe49uUElLGanmB = MQbODJoPV2w8TEAg4zXZdjLxSW.strftime(SO94xq1RAkMm2uF(u"ࠨࡡࠨࡱ࠳ࠫࡤࡠࠧࡋ࠾ࠪࡓ࡟ࠨୡ"),MQbODJoPV2w8TEAg4zXZdjLxSW.localtime(MMHpSTojGILfZXWeCOPyn4))
	PPVuQkU9OfiBXegYZK2c3Tl6 = PPVuQkU9OfiBXegYZK2c3Tl6+POTvxkwYNAryisqKFe49uUElLGanmB
	O9AXtawrzj1Y2VUgc8oNFv6p = uI7UAQCyPO85aLonkGqrdWwRt,PPVuQkU9OfiBXegYZK2c3Tl6,mHejXxkvM1qCESPVRy54QB,xUmyzZKOd8hv3Jc5X2nPHCAarW4sF,nWO8c3IgspK67QX,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,fH8bDPV6AceuCFNO0Ert7oq3p,stpvYViqku3,LGdFZQvKeU52s6H0DgjN
	if WpgZTyqoMAPhwGiXF.path.exists(J2M15kw7Rdv0rQZxITaNuXeyWc):
		aeYlBOMguvy = open(J2M15kw7Rdv0rQZxITaNuXeyWc,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩࡵࡦࠬୢ")).read()
		if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: aeYlBOMguvy = aeYlBOMguvy.decode(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪࡹࡹ࡬࠸ࠨୣ"))
		aeYlBOMguvy = JKw5OWktPZB(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠫࡩ࡯ࡣࡵࠩ୤"),aeYlBOMguvy)
	else: aeYlBOMguvy = {}
	jkum9pHGXvV1TB03Z6ULaAiMJyFKrf = {}
	for zqTdulkBQP4wevmjb2Ahyi0ZHcoSVU in list(aeYlBOMguvy.keys()):
		if zqTdulkBQP4wevmjb2Ahyi0ZHcoSVU!=uI7UAQCyPO85aLonkGqrdWwRt: jkum9pHGXvV1TB03Z6ULaAiMJyFKrf[zqTdulkBQP4wevmjb2Ahyi0ZHcoSVU] = aeYlBOMguvy[zqTdulkBQP4wevmjb2Ahyi0ZHcoSVU]
		else:
			if PPVuQkU9OfiBXegYZK2c3Tl6 and PPVuQkU9OfiBXegYZK2c3Tl6!=l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬ࠴࠮ࠨ୥"):
				rPEfTRVqB3 = aeYlBOMguvy[zqTdulkBQP4wevmjb2Ahyi0ZHcoSVU]
				if O9AXtawrzj1Y2VUgc8oNFv6p in rPEfTRVqB3:
					nlYKqpfrwVWLmig71o9BX = rPEfTRVqB3.index(O9AXtawrzj1Y2VUgc8oNFv6p)
					del rPEfTRVqB3[nlYKqpfrwVWLmig71o9BX]
				AzJSpsQ7kWrPeox2jOR5FK = [O9AXtawrzj1Y2VUgc8oNFv6p]+rPEfTRVqB3
				AzJSpsQ7kWrPeox2jOR5FK = AzJSpsQ7kWrPeox2jOR5FK[:SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠻࠰౩")]
				jkum9pHGXvV1TB03Z6ULaAiMJyFKrf[zqTdulkBQP4wevmjb2Ahyi0ZHcoSVU] = AzJSpsQ7kWrPeox2jOR5FK
			else: jkum9pHGXvV1TB03Z6ULaAiMJyFKrf[zqTdulkBQP4wevmjb2Ahyi0ZHcoSVU] = aeYlBOMguvy[zqTdulkBQP4wevmjb2Ahyi0ZHcoSVU]
	if uI7UAQCyPO85aLonkGqrdWwRt not in list(jkum9pHGXvV1TB03Z6ULaAiMJyFKrf.keys()): jkum9pHGXvV1TB03Z6ULaAiMJyFKrf[uI7UAQCyPO85aLonkGqrdWwRt] = [O9AXtawrzj1Y2VUgc8oNFv6p]
	jkum9pHGXvV1TB03Z6ULaAiMJyFKrf = str(jkum9pHGXvV1TB03Z6ULaAiMJyFKrf)
	if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: jkum9pHGXvV1TB03Z6ULaAiMJyFKrf = jkum9pHGXvV1TB03Z6ULaAiMJyFKrf.encode(sTcr7iDp5eFt4RoLMhuwq1A(u"࠭ࡵࡵࡨ࠻ࠫ୦"))
	open(J2M15kw7Rdv0rQZxITaNuXeyWc,XzrqbGDIy54juixkMA(u"ࠧࡸࡤࠪ୧")).write(jkum9pHGXvV1TB03Z6ULaAiMJyFKrf)
	return
def Tx5qRmdAsc0FP6BUSf8eQKy3(U2gpeLZJrTRzYNvX0Fni3,yqMtRI7sYaXkQE3HN2wjczhWF,vMjJHs2fD4WiRK3uVadX,rKagANTOtGJnhVWfE2BHpePYC3IQ5l,pIkw3zMBQrHKXSOe7ig,SJA0eb3Xuh4Yp=xW2Arao7YVOemw(u"ࡌࡡ࡭ࡵࡨಅ")):
	cUsgVlb0iuBaW7OjSw4oCPL = jHevARrF7lS.getSetting(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧ୨"))
	if cUsgVlb0iuBaW7OjSw4oCPL==fprnld4CZo(u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪ୩") and pIkw3zMBQrHKXSOe7ig>BBDQiGNydYaPqxEv: pIkw3zMBQrHKXSOe7ig = BBDQiGNydYaPqxEv
	if SJA0eb3Xuh4Yp:
		LCaAcrp8R57YSD,Ymsj3C2JhQEonLDA0wP4VbN = [],[]
		for CQMipytPbq in range(len(vMjJHs2fD4WiRK3uVadX)):
			fH8bDPV6AceuCFNO0Ert7oq3p = PDtZIYgv8SkOLiU0z3Mwdo29shN.dumps(rKagANTOtGJnhVWfE2BHpePYC3IQ5l[CQMipytPbq])
			g5fuoNT2XaUz63Ytr = qYMC32PGUjsnfDtpzg5I.compress(fH8bDPV6AceuCFNO0Ert7oq3p)
			LCaAcrp8R57YSD.append((vMjJHs2fD4WiRK3uVadX[CQMipytPbq],))
			Ymsj3C2JhQEonLDA0wP4VbN.append((pIkw3zMBQrHKXSOe7ig+MMHpSTojGILfZXWeCOPyn4,str(vMjJHs2fD4WiRK3uVadX[CQMipytPbq]),g5fuoNT2XaUz63Ytr))
	else:
		fH8bDPV6AceuCFNO0Ert7oq3p = PDtZIYgv8SkOLiU0z3Mwdo29shN.dumps(rKagANTOtGJnhVWfE2BHpePYC3IQ5l)
		B59B8UZ32g40KMuHOPJjAihNeIVdS = qYMC32PGUjsnfDtpzg5I.compress(fH8bDPV6AceuCFNO0Ert7oq3p)
	try: QAlb96UhsVG,PYRN3CLTut = PlKUSdaCEJ6T0rnL(U2gpeLZJrTRzYNvX0Fni3)
	except: return
	while SO94xq1RAkMm2uF(u"ࡔࡳࡷࡨಆ"):
		try:
			PYRN3CLTut.execute(wRxoKs10Syj7V4edYhtP(u"ࠪࡆࡊࡍࡉࡏࠢࡌࡑࡒࡋࡄࡊࡃࡗࡉ࡚ࠥࡒࡂࡐࡖࡅࡈ࡚ࡉࡐࡐࠣ࠿ࠬ୪"))
			break
		except: MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(wRxoKs10Syj7V4edYhtP(u"࠰࠯࠷౪"))
	PYRN3CLTut.execute(lc0dpSmwoPDjLnk(u"ࠫࡈࡘࡅࡂࡖࡈࠤ࡙ࡇࡂࡍࡇࠣࡍࡋࠦࡎࡐࡖࠣࡉ࡝ࡏࡓࡕࡕࠣࠦࠬ୫")+yqMtRI7sYaXkQE3HN2wjczhWF+kEhAHvti6Vnsfx(u"ࠬࠨࠠࠩࡧࡻࡴ࡮ࡸࡹ࠭ࡥࡲࡰࡺࡳ࡮࠭ࡦࡤࡸࡦ࠯ࠠ࠼ࠩ୬"))
	if SJA0eb3Xuh4Yp:
		PYRN3CLTut.executemany(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭୭")+yqMtRI7sYaXkQE3HN2wjczhWF+bUdr5Hahw6sY8xJ(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧ୮"),LCaAcrp8R57YSD)
		PYRN3CLTut.executemany(LiRcTVUWuth70DmPy(u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠢࠨ୯")+yqMtRI7sYaXkQE3HN2wjczhWF+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠩࠥࠤ࡛ࡇࡌࡖࡇࡖࠤ࠭ࡅࠬࡀ࠮ࡂ࠭ࠥࡁࠧ୰"),Ymsj3C2JhQEonLDA0wP4VbN)
	else:
		if pIkw3zMBQrHKXSOe7ig:
			acC9XhfeRS = (str(vMjJHs2fD4WiRK3uVadX),)
			PYRN3CLTut.execute(UTelCo0ihE1d5R(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࠪୱ")+yqMtRI7sYaXkQE3HN2wjczhWF+SO94xq1RAkMm2uF(u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡩ࡯࡭ࡷࡰࡲࠥࡃࠠࡀࠢ࠾ࠫ୲"),acC9XhfeRS)
			acC9XhfeRS = (pIkw3zMBQrHKXSOe7ig+MMHpSTojGILfZXWeCOPyn4,str(vMjJHs2fD4WiRK3uVadX),B59B8UZ32g40KMuHOPJjAihNeIVdS)
			PYRN3CLTut.execute(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࠦࠬ୳")+yqMtRI7sYaXkQE3HN2wjczhWF+g4g6bfkPtVGU5lIM3(u"࠭ࠢࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࡂ࠰ࡄ࠲࠿ࠪࠢ࠾ࠫ୴"),acC9XhfeRS)
		else:
			acC9XhfeRS = (B59B8UZ32g40KMuHOPJjAihNeIVdS,str(vMjJHs2fD4WiRK3uVadX))
			PYRN3CLTut.execute(zqdvcbP5L8BHh(u"ࠧࡖࡒࡇࡅ࡙ࡋࠠࠣࠩ୵")+yqMtRI7sYaXkQE3HN2wjczhWF+bUdr5Hahw6sY8xJ(u"ࠨࠤࠣࡗࡊ࡚ࠠࡥࡣࡷࡥࠥࡃࠠࡀ࡚ࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧ୶"),acC9XhfeRS)
	QAlb96UhsVG.commit()
	QAlb96UhsVG.close()
	return
def Hym17NopzZUE3xhYMe(rKagANTOtGJnhVWfE2BHpePYC3IQ5l):
	if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: import urllib.parse as J9YkUlH06ABQ2Ia45sfepFXDLvbiGd
	else: import urllib as J9YkUlH06ABQ2Ia45sfepFXDLvbiGd
	Lktl3aqZO8cHwsFe = J9YkUlH06ABQ2Ia45sfepFXDLvbiGd.urlencode(rKagANTOtGJnhVWfE2BHpePYC3IQ5l)
	return Lktl3aqZO8cHwsFe
h7hs0dloPeOfzGb39puZ4LxB = UTelCo0ihE1d5R(u"ࠩࠪ୷")
def ICifW6hdKqxkAJ02XZgHysOwoV9Dc5(XwyU6PQgprMI0,AIdwORPiKbz01tHaxB5vhUDfF=l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࠫ୸"),RCVOYBtGemn4La81JyploXFbwZ=zqdvcbP5L8BHh(u"ࠫࠬ୹")):
	juG2Nk7XQlabF = AIdwORPiKbz01tHaxB5vhUDfF not in [iRoLg2m47tnDATBHGCSPNyx(u"ࠬࡓ࠳ࡖࠩ୺"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭ࡉࡑࡖ࡙ࠫ୻")]
	global h7hs0dloPeOfzGb39puZ4LxB
	if not RCVOYBtGemn4La81JyploXFbwZ: RCVOYBtGemn4La81JyploXFbwZ = sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࡷ࡫ࡧࡩࡴ࠭୼")
	h7hs0dloPeOfzGb39puZ4LxB,TBaK6MVlHSDGYrN915kR82pyP4,yPTzmuj0lapeMYC8NSvgQXiFIB = E6MIKdpBomef(u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦ࠳ࠫ୽"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩࠪ୾"),kEhAHvti6Vnsfx(u"ࠪࠫ୿")
	if len(XwyU6PQgprMI0)==FnBiAjthS8MkXs67W(u"࠴౫"):
		mHejXxkvM1qCESPVRy54QB,ffTNCLAjFlMtRBUxZWHoVP5kd,yPTzmuj0lapeMYC8NSvgQXiFIB = XwyU6PQgprMI0
		if ffTNCLAjFlMtRBUxZWHoVP5kd: TBaK6MVlHSDGYrN915kR82pyP4 = SO94xq1RAkMm2uF(u"ࠫࠥࠦࠠࡔࡷࡥࡸ࡮ࡺ࡬ࡦ࠼ࠣ࡟ࠥ࠭஀")+ffTNCLAjFlMtRBUxZWHoVP5kd+hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬࠦ࡝ࠨ஁")
	else: mHejXxkvM1qCESPVRy54QB,ffTNCLAjFlMtRBUxZWHoVP5kd,yPTzmuj0lapeMYC8NSvgQXiFIB = XwyU6PQgprMI0,SO94xq1RAkMm2uF(u"࠭ࠧஂ"),Cu1704YofAbr3QTm(u"ࠧࠨஃ")
	mHejXxkvM1qCESPVRy54QB = mHejXxkvM1qCESPVRy54QB.replace(kEhAHvti6Vnsfx(u"ࠨࠧ࠵࠴ࠬ஄"),LiRcTVUWuth70DmPy(u"ࠩࠣࠫஅ"))
	QNHsaf7u3DSjiJ40ARCKYO = dd8rHcveo7O15hT3MSR(mHejXxkvM1qCESPVRy54QB)
	if AIdwORPiKbz01tHaxB5vhUDfF not in [hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬஆ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࡎࡖࡔࡗࠩஇ")]:
		if AIdwORPiKbz01tHaxB5vhUDfF!=iUeoLOsbHqP(u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧஈ"): mHejXxkvM1qCESPVRy54QB = mHejXxkvM1qCESPVRy54QB.replace(Cu1704YofAbr3QTm(u"࠭ࠠࠨஉ"),E6MIKdpBomef(u"ࠧࠦ࠴࠳ࠫஊ"))
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q(FvNyZqaLKw(u"ࠨࡐࡒࡘࡎࡉࡅࠨ஋"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+LiRcTVUWuth70DmPy(u"ࠩࠣࠤࠥࡖࡲࡦࡲࡤࡶ࡮ࡴࡧࠡࡶࡲࠤࡵࡲࡡࡺ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡻ࡯ࡤࡦࡱࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨ஌")+mHejXxkvM1qCESPVRy54QB+iRoLg2m47tnDATBHGCSPNyx(u"ࠪࠤࡢ࠭஍")+TBaK6MVlHSDGYrN915kR82pyP4)
		if QNHsaf7u3DSjiJ40ARCKYO==FvNyZqaLKw(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪஎ") and AIdwORPiKbz01tHaxB5vhUDfF not in [oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠬࡏࡐࡕࡘࠪஏ"),wRxoKs10Syj7V4edYhtP(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧஐ")]:
			from ccTpfuSVZY import BXEJoygQHA8RZ,D1DJtzviFZSrA,From8aTqdhCbPs
			eyUmvNFiYsE,zzvBg3ShiamAZ = BXEJoygQHA8RZ(mHejXxkvM1qCESPVRy54QB)
			L8Nc9Q4IRd5Bqm21ZF = len(zzvBg3ShiamAZ)
			if L8Nc9Q4IRd5Bqm21ZF>SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠳౬"):
				z0jyetbQwKrIclL9vJW = D1DJtzviFZSrA(Me28A1sBLNIgUp5YCDyvT(u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿ࠦࠨࠨ஑")+str(L8Nc9Q4IRd5Bqm21ZF)+SO94xq1RAkMm2uF(u"ࠨ่่ࠢๆ࠯ࠧஒ"), eyUmvNFiYsE)
				if z0jyetbQwKrIclL9vJW==-FvNyZqaLKw(u"࠴౭"):
					From8aTqdhCbPs(fprnld4CZo(u"ࠩศ่฿อมࠡ฻่่๏ฯࠠหึ฽๎้ࠦวๅใํำ๏๎ࠧஓ"),E6MIKdpBomef(u"ࠪࡇࡦࡴࡣࡦ࡮ࠪஔ"))
					return h7hs0dloPeOfzGb39puZ4LxB
			else: z0jyetbQwKrIclL9vJW = lc0dpSmwoPDjLnk(u"࠴౮")
			mHejXxkvM1qCESPVRy54QB = zzvBg3ShiamAZ[z0jyetbQwKrIclL9vJW]
			if eyUmvNFiYsE[iRoLg2m47tnDATBHGCSPNyx(u"࠵౯")]!=UTelCo0ihE1d5R(u"ࠫ࠲࠷ࠧக"):
				LOHZ4o9m7p6ebfTYXGIdz5PWs3q(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠬࡔࡏࡕࡋࡆࡉࠬ஖"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡕࡨࡰࡪࡩࡴࡦࡦࠣࠤ࡙ࠥࡥ࡭ࡧࡦࡸ࡮ࡵ࡮࠻ࠢ࡞ࠤࠬ஗")+eyUmvNFiYsE[z0jyetbQwKrIclL9vJW]+wRxoKs10Syj7V4edYhtP(u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨ஘")+mHejXxkvM1qCESPVRy54QB+UTelCo0ihE1d5R(u"ࠨࠢࡠࠫங"))
		if zqdvcbP5L8BHh(u"ࠩ࠲࡭࡫࡯࡬࡮࠱ࠪச") in mHejXxkvM1qCESPVRy54QB: mHejXxkvM1qCESPVRy54QB = mHejXxkvM1qCESPVRy54QB+iUeoLOsbHqP(u"ࠪࢀ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠨࠪ஛")
		elif SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫ࡭ࡺࡴࡱࠩஜ") in mHejXxkvM1qCESPVRy54QB.lower() and kEhAHvti6Vnsfx(u"ࠬ࠵ࡤࡢࡵ࡫࠳ࠬ஝") not in mHejXxkvM1qCESPVRy54QB and bUdr5Hahw6sY8xJ(u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫஞ") not in mHejXxkvM1qCESPVRy54QB:
			if iRoLg2m47tnDATBHGCSPNyx(u"ࠧࡷࡧࡵ࡭࡫ࡿࡰࡦࡧࡵࡁࠬட") not in mHejXxkvM1qCESPVRy54QB and YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࠪ஠") in mHejXxkvM1qCESPVRy54QB.lower():
				if g4g6bfkPtVGU5lIM3(u"ࠩࡿࠫ஡") not in mHejXxkvM1qCESPVRy54QB: mHejXxkvM1qCESPVRy54QB = mHejXxkvM1qCESPVRy54QB+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠪࢀࡻ࡫ࡲࡪࡨࡼࡴࡪ࡫ࡲ࠾ࡨࡤࡰࡸ࡫ࠧ஢")
				else: mHejXxkvM1qCESPVRy54QB = mHejXxkvM1qCESPVRy54QB+LiRcTVUWuth70DmPy(u"ࠫࠫࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࡩࡥࡱࡹࡥࠨண")
			if hBvsQ7oCkKUdwjx58ml3EN(u"ࠬࡻࡳࡦࡴ࠰ࡥ࡬࡫࡮ࡵࠩத") not in mHejXxkvM1qCESPVRy54QB.lower() and AIdwORPiKbz01tHaxB5vhUDfF not in [zqdvcbP5L8BHh(u"࠭ࡉࡑࡖ࡙ࠫ஥"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࡎ࠵ࡘࠫ஦")]:
				if Me28A1sBLNIgUp5YCDyvT(u"ࠨࡾࠪ஧") not in mHejXxkvM1qCESPVRy54QB: mHejXxkvM1qCESPVRy54QB = mHejXxkvM1qCESPVRy54QB+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠧࠩந")
				else: mHejXxkvM1qCESPVRy54QB = mHejXxkvM1qCESPVRy54QB+oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࡚ࠪࠪࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠨࠪன")
	LOHZ4o9m7p6ebfTYXGIdz5PWs3q(XzrqbGDIy54juixkMA(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪப"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+bUdr5Hahw6sY8xJ(u"ࠬࠦࠠࠡࡉࡲࡸࠥ࡬ࡩ࡯ࡣ࡯ࠤࡺࡸ࡬࡚ࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭஫")+mHejXxkvM1qCESPVRy54QB+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭ࠠ࡞ࠩ஬"))
	iicok5Z1MUQnFTtVsB2vfw = zz2LJUB9kjnZqAeH.ListItem()
	RCVOYBtGemn4La81JyploXFbwZ,cpH6YnUzMk9A,KmsBUDR0jWE4J5I1QLyHvr,GWaMVJQuw2KR6U9PDI3C0tcd,vLfxaY43gW,Hax6koyQtZVp4TR,a5s9g4riQZc0hkFdB,B4ucT96ps3nXdvVL12JEOjGYoUDKm,FOvT2mD3KZe90kouy = z4sqGEoRxKVCSwc3nLZ(jI8KGT6dsgDQ)
	if AIdwORPiKbz01tHaxB5vhUDfF not in [yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩ஭"),g4g6bfkPtVGU5lIM3(u"ࠨࡋࡓࡘ࡛࠭ம")]:
		if HHosl5fRdhtEDAYyP: m3PG7IxMedbqFUCuw41DtOQsH0 = g4g6bfkPtVGU5lIM3(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳࡡࡥࡦࡲࡲࠬய")
		else: m3PG7IxMedbqFUCuw41DtOQsH0 = E6MIKdpBomef(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭ࠨர")
		iicok5Z1MUQnFTtVsB2vfw.setProperty(m3PG7IxMedbqFUCuw41DtOQsH0, p72fnFtcPix5UKwr9YNzW(u"ࠫࠬற"))
		iicok5Z1MUQnFTtVsB2vfw.setMimeType(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠬࡳࡩ࡮ࡧ࠲ࡼ࠲ࡺࡹࡱࡧࠪல"))
		if yMvF9GoTjhU5biA<iUeoLOsbHqP(u"࠸࠰౰"): iicok5Z1MUQnFTtVsB2vfw.setInfo(bUdr5Hahw6sY8xJ(u"࠭ࡶࡪࡦࡨࡳࠬள"),{SO94xq1RAkMm2uF(u"ࠧ࡮ࡧࡧ࡭ࡦࡺࡹࡱࡧࠪழ"):l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨ࡯ࡲࡺ࡮࡫ࠧவ")})
		else:
			RR8qQIDXsmOHwATWG = iicok5Z1MUQnFTtVsB2vfw.getVideoInfoTag()
			RR8qQIDXsmOHwATWG.setMediaType(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠩࡰࡳࡻ࡯ࡥࠨஶ"))
		iicok5Z1MUQnFTtVsB2vfw.setArt({Me28A1sBLNIgUp5YCDyvT(u"ࠪࡸ࡭ࡻ࡭ࡣࠩஷ"):vLfxaY43gW,SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࡵࡵࡳࡵࡧࡵࠫஸ"):vLfxaY43gW,SO94xq1RAkMm2uF(u"ࠬࡨࡡ࡯ࡰࡨࡶࠬஹ"):vLfxaY43gW,xW2Arao7YVOemw(u"࠭ࡦࡢࡰࡤࡶࡹ࠭஺"):vLfxaY43gW,hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࡤ࡮ࡨࡥࡷࡧࡲࡵࠩ஻"):vLfxaY43gW,iUeoLOsbHqP(u"ࠨࡥ࡯ࡩࡦࡸ࡬ࡰࡩࡲࠫ஼"):vLfxaY43gW,FvNyZqaLKw(u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩࠬ஽"):vLfxaY43gW,l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪ࡭ࡨࡵ࡮ࠨா"):vLfxaY43gW})
		if QNHsaf7u3DSjiJ40ARCKYO in [wRxoKs10Syj7V4edYhtP(u"ࠫ࠳ࡳࡰࡥࠩி"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬ࠴࡭࠴ࡷ࠻ࠫீ")]: iicok5Z1MUQnFTtVsB2vfw.setContentLookup(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࡕࡴࡸࡩಇ"))
		else: iicok5Z1MUQnFTtVsB2vfw.setContentLookup(dshJSmRqeiP9nap2(u"ࡈࡤࡰࡸ࡫ಈ"))
		from WWXqeaw1TE import KmIlXVwgsFZxEdh1b
		if Me28A1sBLNIgUp5YCDyvT(u"࠭ࡲࡵ࡯ࡳࠫு") in mHejXxkvM1qCESPVRy54QB:
			KmIlXVwgsFZxEdh1b(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡸࡴ࡮ࡲࠪூ"),FnBiAjthS8MkXs67W(u"ࡉࡥࡱࡹࡥಉ"))
		elif QNHsaf7u3DSjiJ40ARCKYO==hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨ࠰ࡰࡴࡩ࠭௃") or SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠩ࠲ࡨࡦࡹࡨ࠰ࠩ௄") in mHejXxkvM1qCESPVRy54QB:
			KmIlXVwgsFZxEdh1b(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ௅"),lc0dpSmwoPDjLnk(u"ࡊࡦࡲࡳࡦಊ"))
			iicok5Z1MUQnFTtVsB2vfw.setProperty(m3PG7IxMedbqFUCuw41DtOQsH0,wRxoKs10Syj7V4edYhtP(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫெ"))
			iicok5Z1MUQnFTtVsB2vfw.setProperty(Me28A1sBLNIgUp5YCDyvT(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩ࠳ࡳࡡ࡯࡫ࡩࡩࡸࡺ࡟ࡵࡻࡳࡩࠬே"),fprnld4CZo(u"࠭࡭ࡱࡦࠪை"))
		if ffTNCLAjFlMtRBUxZWHoVP5kd:
			iicok5Z1MUQnFTtVsB2vfw.setSubtitles([ffTNCLAjFlMtRBUxZWHoVP5kd])
	if RCVOYBtGemn4La81JyploXFbwZ==XzrqbGDIy54juixkMA(u"ࠧࡷ࡫ࡧࡩࡴ࠭௉") and AIdwORPiKbz01tHaxB5vhUDfF==kEhAHvti6Vnsfx(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪொ"):
		h7hs0dloPeOfzGb39puZ4LxB = QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࡳࡰࡦࡿ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩோ")
		AIdwORPiKbz01tHaxB5vhUDfF = YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪࡔࡑࡇ࡙ࡠࡆࡏࡣࡋࡏࡌࡆࡕࠪௌ")
	elif RCVOYBtGemn4La81JyploXFbwZ==Cu1704YofAbr3QTm(u"ࠫࡻ࡯ࡤࡦࡱ்ࠪ") and B4ucT96ps3nXdvVL12JEOjGYoUDKm.startswith(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠬ࠼ࠧ௎")):
		h7hs0dloPeOfzGb39puZ4LxB = S4SOKF2QbBhjCd3RrVMuHIzE(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ௏")
		AIdwORPiKbz01tHaxB5vhUDfF = AIdwORPiKbz01tHaxB5vhUDfF+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠧࡠࡆࡏࠫௐ")
	if h7hs0dloPeOfzGb39puZ4LxB!=Me28A1sBLNIgUp5YCDyvT(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ௑"): BejcHLrmkn9()
	rdq0M165Nyf = CCBqEGLDlhno8zF4VKQsYpRMvk()
	rdq0M165Nyf.SxalJMDUBqsAwOTu8bQtL7d(AIdwORPiKbz01tHaxB5vhUDfF)
	if rdq0M165Nyf.h7hs0dloPeOfzGb39puZ4LxB: return wRxoKs10Syj7V4edYhtP(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠪ௒")
	if RCVOYBtGemn4La81JyploXFbwZ==FnBiAjthS8MkXs67W(u"ࠪࡺ࡮ࡪࡥࡰࠩ௓") and not B4ucT96ps3nXdvVL12JEOjGYoUDKm.startswith(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫ࠻࠭௔")):
		iicok5Z1MUQnFTtVsB2vfw.setPath(mHejXxkvM1qCESPVRy54QB)
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q(kEhAHvti6Vnsfx(u"ࠬࡔࡏࡕࡋࡆࡉࠬ௕"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡲ࡯ࡥࡾࠦࡵࡴ࡫ࡱ࡫ࠥࡹࡥࡵࡔࡨࡷࡴࡲࡶࡦࡦࡘࡶࡱ࠮࡚ࠩࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭௖")+mHejXxkvM1qCESPVRy54QB+hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࠡ࡟ࠪௗ"))
		XL4sA9FNebx30oE.setResolvedUrl(cmBCkqS7vLYD3flwZ,hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࡙ࡸࡵࡦಋ"),iicok5Z1MUQnFTtVsB2vfw)
	elif RCVOYBtGemn4La81JyploXFbwZ==kEhAHvti6Vnsfx(u"ࠨ࡮࡬ࡺࡪ࠭௘"):
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ௙"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠪࠤࠥࠦࡌࡪࡸࡨࠤࡵࡲࡡࡺࠢࡸࡷ࡮ࡴࡧࠡࡲ࡯ࡥࡾ࠮࡚ࠩࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭௚")+mHejXxkvM1qCESPVRy54QB+XzrqbGDIy54juixkMA(u"ࠫࠥࡣࠧ௛"))
		rdq0M165Nyf.play(mHejXxkvM1qCESPVRy54QB,iicok5Z1MUQnFTtVsB2vfw)
	Tr8iRxJmbcEhftU5DSHzA = wRxoKs10Syj7V4edYhtP(u"ࡌࡡ࡭ࡵࡨಌ")
	if h7hs0dloPeOfzGb39puZ4LxB==p72fnFtcPix5UKwr9YNzW(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ௜"):
		from TP0fzV8GMW import wweM3YXLySo6
		Tr8iRxJmbcEhftU5DSHzA = wweM3YXLySo6(mHejXxkvM1qCESPVRy54QB,QNHsaf7u3DSjiJ40ARCKYO,AIdwORPiKbz01tHaxB5vhUDfF)
		if Tr8iRxJmbcEhftU5DSHzA: BejcHLrmkn9()
	else:
		I26dXLNboZt7ie,h7hs0dloPeOfzGb39puZ4LxB,vMmVcYBRd0abEH14UIo3gsi,VzQt8WXcSvbuRM1jUYfl,Jn0oNrWCm7DBh9Olp = QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠰౱"),E6MIKdpBomef(u"࠭ࡴࡳ࡫ࡨࡨࠬ௝"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࡆࡢ࡮ࡶࡩ಍"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠳࠳࠴࠵౳"),iUeoLOsbHqP(u"࠵࠷࠳࠴࠵౲")
		if juG2Nk7XQlabF: from ccTpfuSVZY import From8aTqdhCbPs
		while I26dXLNboZt7ie<Jn0oNrWCm7DBh9Olp:
			cEZpW924rqNYm5.sleep(VzQt8WXcSvbuRM1jUYfl)
			I26dXLNboZt7ie += VzQt8WXcSvbuRM1jUYfl
			if rdq0M165Nyf.h7hs0dloPeOfzGb39puZ4LxB==S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࠨ௞") and not vMmVcYBRd0abEH14UIo3gsi:
				if juG2Nk7XQlabF: From8aTqdhCbPs(SO94xq1RAkMm2uF(u"ࠨ่ฯัฯูࠦๆๆํอࠥห๊อษาࠤฬ๊แ๋ัํ์ࠬ௟"),Me28A1sBLNIgUp5YCDyvT(u"ࠩࡖࡹࡨࡩࡥࡴࡵࠪ௠"),MQbODJoPV2w8TEAg4zXZdjLxSW=xW2Arao7YVOemw(u"࠺࠹࠵౴"))
				LOHZ4o9m7p6ebfTYXGIdz5PWs3q(wRxoKs10Syj7V4edYhtP(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ௡"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪࡹࡳ࠻࡚ࠢࠣ࡮ࡪࡥࡰࠢࡶࡸࡦࡸࡴࡦࡦࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨ௢")+mHejXxkvM1qCESPVRy54QB+FvNyZqaLKw(u"ࠬࠦ࡝ࠨ௣")+TBaK6MVlHSDGYrN915kR82pyP4)
				vMmVcYBRd0abEH14UIo3gsi = FnBiAjthS8MkXs67W(u"ࡕࡴࡸࡩಎ")
			elif rdq0M165Nyf.h7hs0dloPeOfzGb39puZ4LxB in [bUdr5Hahw6sY8xJ(u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ௤"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨ௥")]:
				LOHZ4o9m7p6ebfTYXGIdz5PWs3q(wRxoKs10Syj7V4edYhtP(u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ௦"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࡘ࡬ࡨࡪࡵࠠࡱ࡮ࡤࡽ࡮ࡴࡧ࡚ࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭௧")+mHejXxkvM1qCESPVRy54QB+zqdvcbP5L8BHh(u"ࠪࠤࡢ࠭௨")+TBaK6MVlHSDGYrN915kR82pyP4)
				break
			elif rdq0M165Nyf.h7hs0dloPeOfzGb39puZ4LxB==oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ௩"):
				LOHZ4o9m7p6ebfTYXGIdz5PWs3q(xW2Arao7YVOemw(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ௪"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+LiRcTVUWuth70DmPy(u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡳࡰࡦࡿࡩ࡯ࡩࠣࡺ࡮ࡪࡥࡰࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧ௫")+mHejXxkvM1qCESPVRy54QB+lc0dpSmwoPDjLnk(u"ࠧࠡ࡟ࠪ௬")+TBaK6MVlHSDGYrN915kR82pyP4)
				if juG2Nk7XQlabF: From8aTqdhCbPs(p72fnFtcPix5UKwr9YNzW(u"ࠨใื่ฯูࠦๆๆํอࠥะิ฻์็ࠤฬ๊แ๋ัํ์ࠬ௭"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩࡉࡥ࡮ࡲࡵࡳࡧࠪ௮"),MQbODJoPV2w8TEAg4zXZdjLxSW=xW2Arao7YVOemw(u"࠻࠺࠶౵"))
				break
			elif rdq0M165Nyf.h7hs0dloPeOfzGb39puZ4LxB==XzrqbGDIy54juixkMA(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ௯"):
				LOHZ4o9m7p6ebfTYXGIdz5PWs3q(iUeoLOsbHqP(u"ࠫࡊࡘࡒࡐࡔࠪ௰"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬࠦࠠࠡࡆࡨࡺ࡮ࡩࡥࠡ࡫ࡶࠤࡧࡲ࡯ࡤ࡭ࡨࡨࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪ௱")+mHejXxkvM1qCESPVRy54QB+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭ࠠ࡞ࠩ௲"))
				break
		else:
			if juG2Nk7XQlabF: From8aTqdhCbPs(LiRcTVUWuth70DmPy(u"ࠧโึ็ฮࠥ฿ๅๅ์ฬࠤฯฺฺ๋ๆࠣห้็๊ะ์๋ࠫ௳"),fprnld4CZo(u"ࠨࡖ࡬ࡱࡪࡵࡵࡵࠩ௴"),MQbODJoPV2w8TEAg4zXZdjLxSW=XzrqbGDIy54juixkMA(u"࠼࠻࠰౶"))
			LOHZ4o9m7p6ebfTYXGIdz5PWs3q(iUeoLOsbHqP(u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ௵"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+Cu1704YofAbr3QTm(u"ࠪࠤࠥࠦࡔࡪ࡯ࡨࡳࡺࡺ࠺ࠡࠢࡘࡲࡰࡴ࡯ࡸࡰࠣࡴࡷࡵࡢ࡭ࡧࡰࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩ௶")+mHejXxkvM1qCESPVRy54QB+bUdr5Hahw6sY8xJ(u"ࠫࠥࡣࠧ௷")+TBaK6MVlHSDGYrN915kR82pyP4)
			h7hs0dloPeOfzGb39puZ4LxB = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭௸")
	if h7hs0dloPeOfzGb39puZ4LxB in [S4SOKF2QbBhjCd3RrVMuHIzE(u"࠭ࡰ࡭ࡣࡼࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭௹")] or rdq0M165Nyf.h7hs0dloPeOfzGb39puZ4LxB in [SO94xq1RAkMm2uF(u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ௺"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠨࡶࡨࡷࡹ࡯࡮ࡨࠩ௻")] or Tr8iRxJmbcEhftU5DSHzA:
		if rdq0M165Nyf.h7hs0dloPeOfzGb39puZ4LxB==zqdvcbP5L8BHh(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪ௼"): AIdwORPiKbz01tHaxB5vhUDfF = AIdwORPiKbz01tHaxB5vhUDfF+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࡣ࡙࡙ࠧ௽")
		YutQm2AwozR9VKp4O1lWj8FaryI = EGTmIaUiSoHDC5bJlR19Zksqv(AIdwORPiKbz01tHaxB5vhUDfF)
	else: exec(fprnld4CZo(u"ࠫ࡮ࡳࡰࡰࡴࡷࠤࡽࡨ࡭ࡤ࠽ࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰ࡶࡸࡴࡶࠨࠪࠩ௾"))
	return rdq0M165Nyf.h7hs0dloPeOfzGb39puZ4LxB
def dd8rHcveo7O15hT3MSR(mHejXxkvM1qCESPVRy54QB):
	if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: from urllib.parse import urlparse as G5ZTPl4m9M
	else: from urlparse import urlparse as G5ZTPl4m9M
	path = G5ZTPl4m9M(mHejXxkvM1qCESPVRy54QB).path
	W4HA1QvN6J3IjwryoFm0cV = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬ࠭௿") if l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭࠮ࠨఀ") not in path else path.rsplit(wRxoKs10Syj7V4edYhtP(u"ࠧ࠯ࠩఁ"),g4g6bfkPtVGU5lIM3(u"࠷౷"))[g4g6bfkPtVGU5lIM3(u"࠷౷")]
	if W4HA1QvN6J3IjwryoFm0cV in [YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠨࡣࡹ࡭ࠬం"),LiRcTVUWuth70DmPy(u"ࠩࡷࡷࠬః"),g4g6bfkPtVGU5lIM3(u"ࠪࡥࡦࡩࠧఄ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠫࡲࡶ࠴ࠨఅ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠬࡳ࠳ࡶࠩఆ"),g4g6bfkPtVGU5lIM3(u"࠭࡭࠴ࡷ࠻ࠫఇ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠧ࡮ࡲࡧࠫఈ"),Me28A1sBLNIgUp5YCDyvT(u"ࠨ࡯࡮ࡺࠬఉ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࡩࡰࡻ࠭ఊ"),Me28A1sBLNIgUp5YCDyvT(u"ࠪࡱࡵ࠹ࠧఋ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠫࡼ࡫ࡢ࡮ࠩఌ")]: return g4g6bfkPtVGU5lIM3(u"ࠬ࠴ࠧ఍")+W4HA1QvN6J3IjwryoFm0cV
	return Cu1704YofAbr3QTm(u"࠭ࠧఎ")
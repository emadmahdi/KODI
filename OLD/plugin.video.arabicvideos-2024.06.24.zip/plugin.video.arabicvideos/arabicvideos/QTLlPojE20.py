# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'CIMANOW'
mmDwMlfoHtG5XT19VLIWqCR8i = '_CMN_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
DDXTwbRBaj3e2rSsPQ = ['قائمتي']
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==300: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==301: zpXG3Ky6ou8ndWHkb4 = i7pbAuodvX3(url)
	elif mode==302: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url)
	elif mode==303: zpXG3Ky6ou8ndWHkb4 = MniZg2RhcpK01tCaTQN5rIOjdUWose(url)
	elif mode==304: zpXG3Ky6ou8ndWHkb4 = hWPvGlXZ5arzV7(url)
	elif mode==305: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==306: zpXG3Ky6ou8ndWHkb4 = nZo7TtikeCMhpLSJwVjYAl9()
	elif mode==309: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	cd0aGwCPExbFU5pYNu8r('link',mmDwMlfoHtG5XT19VLIWqCR8i+'لماذا الموقع بطيء','',306)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',309,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',NBm2aWhPzoTpdYn+'/home','','','','','CIMANOW-MENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('<header>(.*?)</header>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('<li><a href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		title = title.strip(' ')
		if not any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in DDXTwbRBaj3e2rSsPQ):
			cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,301)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	i7pbAuodvX3(NBm2aWhPzoTpdYn+'/home',BBlXpmUyhFDwNtCVAHoE)
	return BBlXpmUyhFDwNtCVAHoE
def nZo7TtikeCMhpLSJwVjYAl9():
	aHKzv76JCVnprbY8w('','','رسالة من المبرمج','موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def i7pbAuodvX3(url,BBlXpmUyhFDwNtCVAHoE=''):
	if not BBlXpmUyhFDwNtCVAHoE:
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',url,'','','','','CIMANOW-SUBMENU-1st')
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	onj6XfdmELkTOlWH3xBhG1PC8F72 = 0
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('(<section>.*?</section>)',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		for UCEFMfKbgpd in EeQqAGc0W5r6nlBbChwfZL:
			onj6XfdmELkTOlWH3xBhG1PC8F72 += 1
			items = GGvHJKP9LUxEk10Fw.findall('<section>.<span>(.*?)<(.*?)href="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for title,ZYjBCnrftJIDlvkR79d4O2SFhKHP3,ELbNB92cOh5dqtpVmi40kY in items:
				title = title.strip(' ')
				if title=='': title = 'بووووو'
				if 'em><a' not in ZYjBCnrftJIDlvkR79d4O2SFhKHP3:
					if UCEFMfKbgpd.count('/category/')>0:
						VeIpTBA4KkFzJgRqGOE2Pb05Mx = GGvHJKP9LUxEk10Fw.findall('href="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
						for ELbNB92cOh5dqtpVmi40kY in VeIpTBA4KkFzJgRqGOE2Pb05Mx:
							title = ELbNB92cOh5dqtpVmi40kY.split('/')[-2]
							cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,301)
						continue
					else: ELbNB92cOh5dqtpVmi40kY = url+'?sequence='+str(onj6XfdmELkTOlWH3xBhG1PC8F72)
				if not any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in DDXTwbRBaj3e2rSsPQ):
					cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,302)
	else: xoiXMWjJC3pnQqurIGPkRSl8e(url,BBlXpmUyhFDwNtCVAHoE)
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(url,BBlXpmUyhFDwNtCVAHoE=''):
	if BBlXpmUyhFDwNtCVAHoE=='':
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','CIMANOW-TITLES-1st')
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	if '?sequence=' in url:
		url,onj6XfdmELkTOlWH3xBhG1PC8F72 = url.split('?sequence=')
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('(<section>.*?</section>)',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[int(onj6XfdmELkTOlWH3xBhG1PC8F72)-1]
	else:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"posts"(.*?)</body>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	IcJOGsq3Ff7EmkiLx = []
	for ELbNB92cOh5dqtpVmi40kY,data,VFqpJjRySZvgi in items:
		title = GGvHJKP9LUxEk10Fw.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,GGvHJKP9LUxEk10Fw.DOTALL)
		if title: title = title[0][2].replace('\n','').strip(' ')
		if not title or title=='':
			title = GGvHJKP9LUxEk10Fw.findall('title">.*?</em>(.*?)<',data,GGvHJKP9LUxEk10Fw.DOTALL)
			if title: title = title[0].replace('\n','').strip(' ')
			if not title or title=='':
				title = GGvHJKP9LUxEk10Fw.findall('title">(.*?)<',data,GGvHJKP9LUxEk10Fw.DOTALL)
				title = title[0].replace('\n','').strip(' ')
		title = DwNC3gEonizsB6a0v1F(title)
		title = title.replace('  ',' ')
		if title not in IcJOGsq3Ff7EmkiLx:
			IcJOGsq3Ff7EmkiLx.append(title)
			jCxVUBZwAdOtIHM81rTJYiX3 = ELbNB92cOh5dqtpVmi40kY+data+VFqpJjRySZvgi
			if '/selary/' in jCxVUBZwAdOtIHM81rTJYiX3 or 'مسلسل' in jCxVUBZwAdOtIHM81rTJYiX3 or '"episode"' in jCxVUBZwAdOtIHM81rTJYiX3:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,303,VFqpJjRySZvgi)
			else: cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,305,VFqpJjRySZvgi)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"pagination"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('<li><a href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,302)
	return
def MniZg2RhcpK01tCaTQN5rIOjdUWose(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','CIMANOW-SEASONS-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	name = GGvHJKP9LUxEk10Fw.findall('<title>(.*?)</title>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	name = name[0].replace('| سيما ناو','').replace('Cima Now','').strip(' ').replace('  ',' ')
	name = name.split('الحلقة')[0].strip(' ')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('<section(.*?)</section>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if len(items)>1:
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				title = name+' - '+title.replace('\n','').strip(' ')
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,304)
		else: hWPvGlXZ5arzV7(url)
	return
def hWPvGlXZ5arzV7(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','CIMANOW-EPISODES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	if '/selary/' not in url:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"episodes"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			title = title.replace('\n','').strip(' ')
			title = 'الحلقة '+title
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,305)
	else:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"details"(.*?)"related"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
			title = title.replace('\n','').strip(' ')
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,305,VFqpJjRySZvgi)
	return
def SUfe4unWoXBNFz90xqy(url):
	dR2vHyAtl8pJN1 = url+'watching/'
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'GET',dR2vHyAtl8pJN1,'','','','','CIMANOW-PLAY-5th')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	zzvBg3ShiamAZ = []
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"download"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?</i>(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			title = title.replace('\n','').strip(' ')
			dDZQSEGRTo9g85x1C = GGvHJKP9LUxEk10Fw.findall('\d\d\d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
			if dDZQSEGRTo9g85x1C:
				dDZQSEGRTo9g85x1C = '____'+dDZQSEGRTo9g85x1C[0]
				title = RfKuIXwPAiWtmyF(ELbNB92cOh5dqtpVmi40kY,'name')
			else: dDZQSEGRTo9g85x1C = ''
			E2EhMuOLdF08Pz75jDKS14cfYNxy = ELbNB92cOh5dqtpVmi40kY+'?named='+title+'__download'+dDZQSEGRTo9g85x1C
			zzvBg3ShiamAZ.append(E2EhMuOLdF08Pz75jDKS14cfYNxy)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"watch"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		gI487voLsArVqW6Ffp = GGvHJKP9LUxEk10Fw.findall('"embed".*?src="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY in gI487voLsArVqW6Ffp:
			if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = 'http:'+ELbNB92cOh5dqtpVmi40kY
			title = RfKuIXwPAiWtmyF(ELbNB92cOh5dqtpVmi40kY,'name')
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named='+title+'__embed'
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
		gI487voLsArVqW6Ffp = [NBm2aWhPzoTpdYn+'/wp-content/themes/Cima%20Now%20New/core.php']
		if gI487voLsArVqW6Ffp:
			items = GGvHJKP9LUxEk10Fw.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for nlYKqpfrwVWLmig71o9BX,id,title in items:
				title = title.replace('\n','').strip(' ')
				ELbNB92cOh5dqtpVmi40kY = gI487voLsArVqW6Ffp[0]+'?action=switch&index='+nlYKqpfrwVWLmig71o9BX+'&id='+id+'?named='+title+'__watch'
				zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(zzvBg3ShiamAZ,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	search = search.replace(' ','+')
	url = NBm2aWhPzoTpdYn + '/?s='+search
	xoiXMWjJC3pnQqurIGPkRSl8e(url)
	return
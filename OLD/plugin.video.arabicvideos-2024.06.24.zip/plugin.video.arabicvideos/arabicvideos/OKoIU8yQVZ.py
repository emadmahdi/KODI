# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'ALARAB'
headers = {'User-Agent':''}
mmDwMlfoHtG5XT19VLIWqCR8i = '_KLA_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==10: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==11: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url)
	elif mode==12: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==13: zpXG3Ky6ou8ndWHkb4 = hWPvGlXZ5arzV7(url)
	elif mode==14: zpXG3Ky6ou8ndWHkb4 = CymTbuXdDhL()
	elif mode==15: zpXG3Ky6ou8ndWHkb4 = Zb7FI1ORWaezLrtoqAG6()
	elif mode==16: zpXG3Ky6ou8ndWHkb4 = Khs4q5RTwn6eH()
	elif mode==19: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',19,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'آخر الإضافات','',14)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'مسلسلات رمضان','',15)
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,NBm2aWhPzoTpdYn,'',headers,'','ALARAB-MENU-1st')
	EeQqAGc0W5r6nlBbChwfZL=GGvHJKP9LUxEk10Fw.findall('id="nav-slider"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	BVjy9iUtvpl6fJuc1IZRa8xEP4 = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)<',BVjy9iUtvpl6fJuc1IZRa8xEP4,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
		title = title.strip(' ')
		cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,11)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('id="navbar"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	jCxVUBZwAdOtIHM81rTJYiX3 = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)<',jCxVUBZwAdOtIHM81rTJYiX3,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
		cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,11)
	return BBlXpmUyhFDwNtCVAHoE
def Zb7FI1ORWaezLrtoqAG6():
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'جميع المسلسلات العربية',NBm2aWhPzoTpdYn+'/view-8/مسلسلات-عربية',11)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مسلسلات السنة الأخيرة','',16)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مسلسلات رمضان الأخيرة 1',NBm2aWhPzoTpdYn+'/view-8/مسلسلات-رمضان-2022',11)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مسلسلات رمضان الأخيرة 2',NBm2aWhPzoTpdYn+'/view-8/مسلسلات-رمضان-2023',11)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مسلسلات رمضان 2023',NBm2aWhPzoTpdYn+'/ramadan2023/مصرية',11)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مسلسلات رمضان 2022',NBm2aWhPzoTpdYn+'/ramadan2022/مصرية',11)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مسلسلات رمضان 2021',NBm2aWhPzoTpdYn+'/ramadan2021/مصرية',11)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مسلسلات رمضان 2020',NBm2aWhPzoTpdYn+'/ramadan2020/مصرية',11)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مسلسلات رمضان 2019',NBm2aWhPzoTpdYn+'/ramadan2019/مصرية',11)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مسلسلات رمضان 2018',NBm2aWhPzoTpdYn+'/ramadan2018/مصرية',11)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مسلسلات رمضان 2017',NBm2aWhPzoTpdYn+'/ramadan2017/مصرية',11)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مسلسلات رمضان 2016',NBm2aWhPzoTpdYn+'/ramadan2016/مصرية',11)
	return
def CymTbuXdDhL():
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,NBm2aWhPzoTpdYn,'',headers,True,'ALARAB-LATEST-1st')
	EeQqAGc0W5r6nlBbChwfZL=GGvHJKP9LUxEk10Fw.findall('heading-top(.*?)div class=',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]+EeQqAGc0W5r6nlBbChwfZL[1]
	items=GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
		url = NBm2aWhPzoTpdYn + ELbNB92cOh5dqtpVmi40kY
		if 'series' in url: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,11,VFqpJjRySZvgi)
		else: cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,12,VFqpJjRySZvgi)
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'',headers,True,True,'ALARAB-TITLES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('video-category(.*?)right_content',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not EeQqAGc0W5r6nlBbChwfZL: return
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	nP18Siw4MjRatJdKYNL7CUyB9eg = False
	items = GGvHJKP9LUxEk10Fw.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	IcJOGsq3Ff7EmkiLx,KQzlI18oVMbCAqvUN = [],[]
	for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
		if title=='': title = ELbNB92cOh5dqtpVmi40kY.split('/')[-1].replace('-',' ')
		vAxfDHyjwR6KM74IGEJl0dasY = GGvHJKP9LUxEk10Fw.findall('(\d+)',title,GGvHJKP9LUxEk10Fw.DOTALL)
		if vAxfDHyjwR6KM74IGEJl0dasY: vAxfDHyjwR6KM74IGEJl0dasY = int(vAxfDHyjwR6KM74IGEJl0dasY[0])
		else: vAxfDHyjwR6KM74IGEJl0dasY = 0
		KQzlI18oVMbCAqvUN.append([VFqpJjRySZvgi,ELbNB92cOh5dqtpVmi40kY,title,vAxfDHyjwR6KM74IGEJl0dasY])
	KQzlI18oVMbCAqvUN = sorted(KQzlI18oVMbCAqvUN, reverse=True, key=lambda key: key[3])
	for VFqpJjRySZvgi,ELbNB92cOh5dqtpVmi40kY,title,vAxfDHyjwR6KM74IGEJl0dasY in KQzlI18oVMbCAqvUN:
		ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn + ELbNB92cOh5dqtpVmi40kY
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي','')
		title = title.replace('عالية على العرب','')
		title = title.replace('مشاهدة مباشرة','')
		title = title.replace('اون لاين','')
		title = title.replace('اونلاين','')
		title = title.replace('بجودة عالية','')
		title = title.replace('جودة عالية','')
		title = title.replace('بدون تحميل','')
		title = title.replace('على العرب','')
		title = title.replace('مباشرة','')
		title = title.strip(' ').replace('  ',' ').replace('  ',' ')
		title = '_MOD_'+title
		qPmCp1Q4gRekdAH = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			qUGxSK2VwsiBAdkDZnJ605vQeg = GGvHJKP9LUxEk10Fw.findall('(.*?) الحلقة \d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
			if qUGxSK2VwsiBAdkDZnJ605vQeg: qPmCp1Q4gRekdAH = qUGxSK2VwsiBAdkDZnJ605vQeg[0]
		if qPmCp1Q4gRekdAH not in IcJOGsq3Ff7EmkiLx:
			IcJOGsq3Ff7EmkiLx.append(qPmCp1Q4gRekdAH)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+qPmCp1Q4gRekdAH,ELbNB92cOh5dqtpVmi40kY,13,VFqpJjRySZvgi)
				nP18Siw4MjRatJdKYNL7CUyB9eg = True
			elif 'series' in ELbNB92cOh5dqtpVmi40kY:
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,11,VFqpJjRySZvgi)
				nP18Siw4MjRatJdKYNL7CUyB9eg = True
			else:
				cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,12,VFqpJjRySZvgi)
				nP18Siw4MjRatJdKYNL7CUyB9eg = True
	if nP18Siw4MjRatJdKYNL7CUyB9eg:
		items = GGvHJKP9LUxEk10Fw.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,EfNzW3kLhcMTu07HrP28X9nFA6vpGd in items:
			url = NBm2aWhPzoTpdYn + ELbNB92cOh5dqtpVmi40kY
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+EfNzW3kLhcMTu07HrP28X9nFA6vpGd,url,11)
	return
def hWPvGlXZ5arzV7(url):
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,url,'',headers,True,'ALARAB-EPISODES-1st')
	kdMqIHf49N15m8OgBoaE = GGvHJKP9LUxEk10Fw.findall('href="(/series.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	dR2vHyAtl8pJN1 = NBm2aWhPzoTpdYn+kdMqIHf49N15m8OgBoaE[0]
	zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(dR2vHyAtl8pJN1)
	return
def SUfe4unWoXBNFz90xqy(url):
	zzvBg3ShiamAZ = []
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(xh9BXlAw0UoVsIZ4if3,url,'',headers,True,'ALARAB-PLAY-1st')
	dR2vHyAtl8pJN1 = GGvHJKP9LUxEk10Fw.findall('class="resp-iframe" src="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if dR2vHyAtl8pJN1:
		dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1[0]
		gI487voLsArVqW6Ffp = GGvHJKP9LUxEk10Fw.findall('^(http.*?)(http.*?)$',dR2vHyAtl8pJN1,GGvHJKP9LUxEk10Fw.DOTALL)
		if gI487voLsArVqW6Ffp:
			ltnfoZ29FRhWPwCbj = gI487voLsArVqW6Ffp[0][0]
			dfwIjoNHsxlS2ZAUpbnz0qFye,SraZPwhdUOTtnu9Hx1gIzc672 = gI487voLsArVqW6Ffp[0][1].rsplit('/',1)
			XwyU6PQgprMI0 = dfwIjoNHsxlS2ZAUpbnz0qFye+'?named=__watch'
			zzvBg3ShiamAZ.append(XwyU6PQgprMI0)
			gmFNXM58sV6qH = ltnfoZ29FRhWPwCbj+SraZPwhdUOTtnu9Hx1gIzc672
		else:
			X3in5vNhqwWEG2TafmVCrFbSYDxjoK = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,dR2vHyAtl8pJN1,'',headers,False,'ALARAB-PLAY-2nd')
			dR2vHyAtl8pJN1 = GGvHJKP9LUxEk10Fw.findall('"src": "(.*?)"',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
			if dR2vHyAtl8pJN1:
				dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1[0]+'?named=__watch__m3u8'
				zzvBg3ShiamAZ.append(dR2vHyAtl8pJN1)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('searchBox(.*?)<style>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		dR2vHyAtl8pJN1 = GGvHJKP9LUxEk10Fw.findall('href="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if dR2vHyAtl8pJN1:
			dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1[0]+'?named=__watch'
			zzvBg3ShiamAZ.append(dR2vHyAtl8pJN1)
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(zzvBg3ShiamAZ,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def Khs4q5RTwn6eH():
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,NBm2aWhPzoTpdYn,'',headers,True,'ALARAB-RAMADAN-1st')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('id="content_sec"(.*?)id="left_content"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	xrmz2pUA76aO5PqMwvQ4u8F3NYK = GGvHJKP9LUxEk10Fw.findall('/ramadan([0-9]+)/',str(items),GGvHJKP9LUxEk10Fw.DOTALL)
	xrmz2pUA76aO5PqMwvQ4u8F3NYK = xrmz2pUA76aO5PqMwvQ4u8F3NYK[0]
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		url = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
		title = title.strip(' ')+' '+xrmz2pUA76aO5PqMwvQ4u8F3NYK
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,11)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	aKRILTAj1HC5c = search.replace(' ','+')
	url = NBm2aWhPzoTpdYn + "/q/" + aKRILTAj1HC5c
	zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url)
	return
# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
ucL0B1lWMCfAoEjG = 'M3U'
XgvWSQ6o5hzlux8 = '_M3U_'
PIWGQhN5bMCcRy0dls = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
YY1DZ5qkNn = 4
def hSlFxp6vyaE0tRqWBfKcn(VRnfEFmJzUrSljM8,kk1GKyapocQZDAz,MMupPCxqkenwt6FlsbRILV37EAmB,QTcZbyNIfxeU84vs5LBophFmqMAn6,zdu6VAyNEi5IL1,Q16YwhAIPHb9Cgj4F):
	global XgvWSQ6o5hzlux8
	try:
		Kkecj5WTsm9rwlSJu1xqQLN = str(Q16YwhAIPHb9Cgj4F['folder'])
		XgvWSQ6o5hzlux8 = '_MU'+Kkecj5WTsm9rwlSJu1xqQLN+'_'
	except: Kkecj5WTsm9rwlSJu1xqQLN = ''
	try: IQG0cV3XZxjr5u = str(Q16YwhAIPHb9Cgj4F['sequence'])
	except: IQG0cV3XZxjr5u = ''
	if   VRnfEFmJzUrSljM8==710: p8lwCLKmTWr = s5z7jbHwX4kR()
	elif VRnfEFmJzUrSljM8==711: p8lwCLKmTWr = DTrYUCtdGu4Q90iq(Kkecj5WTsm9rwlSJu1xqQLN,IQG0cV3XZxjr5u)
	elif VRnfEFmJzUrSljM8==712: p8lwCLKmTWr = KT6H2d7qgZf9FcQpnes4hkO(Kkecj5WTsm9rwlSJu1xqQLN)
	elif VRnfEFmJzUrSljM8==713: p8lwCLKmTWr = gLD9AntXhScRo1arYBsU42(Kkecj5WTsm9rwlSJu1xqQLN,kk1GKyapocQZDAz,MMupPCxqkenwt6FlsbRILV37EAmB,zdu6VAyNEi5IL1)
	elif VRnfEFmJzUrSljM8==714: p8lwCLKmTWr = L4L0TUsN51taeljfc(Kkecj5WTsm9rwlSJu1xqQLN,kk1GKyapocQZDAz,MMupPCxqkenwt6FlsbRILV37EAmB,zdu6VAyNEi5IL1)
	elif VRnfEFmJzUrSljM8==715: p8lwCLKmTWr = SUfe4unWoXBNFz90xqy(Kkecj5WTsm9rwlSJu1xqQLN,kk1GKyapocQZDAz,QTcZbyNIfxeU84vs5LBophFmqMAn6)
	elif VRnfEFmJzUrSljM8==716: p8lwCLKmTWr = k2pKMT0PjuaroAf8zOHvshqXF(Kkecj5WTsm9rwlSJu1xqQLN,True)
	elif VRnfEFmJzUrSljM8==717: p8lwCLKmTWr = WNPb7YqE0hQOvwl2c(Kkecj5WTsm9rwlSJu1xqQLN,True)
	elif VRnfEFmJzUrSljM8==718: p8lwCLKmTWr = UCmW4FGwhbcx8(Kkecj5WTsm9rwlSJu1xqQLN,kk1GKyapocQZDAz,MMupPCxqkenwt6FlsbRILV37EAmB)
	elif VRnfEFmJzUrSljM8==719: p8lwCLKmTWr = tnkSpQrOC9RugmzD2b(MMupPCxqkenwt6FlsbRILV37EAmB,Kkecj5WTsm9rwlSJu1xqQLN,kk1GKyapocQZDAz,zdu6VAyNEi5IL1)
	elif VRnfEFmJzUrSljM8==720: p8lwCLKmTWr = MgXYEzpBGQfveJ3bHm1u(Kkecj5WTsm9rwlSJu1xqQLN,True)
	elif VRnfEFmJzUrSljM8==721: p8lwCLKmTWr = uorZ0e1B9Ty3AWhqnmCRbLH(Kkecj5WTsm9rwlSJu1xqQLN)
	elif VRnfEFmJzUrSljM8==722: p8lwCLKmTWr = ywoasx5le3RiNH(Kkecj5WTsm9rwlSJu1xqQLN)
	elif VRnfEFmJzUrSljM8==723: p8lwCLKmTWr = V564p0o1UxjGnuL27m9cXJ3(Kkecj5WTsm9rwlSJu1xqQLN)
	elif VRnfEFmJzUrSljM8==726: p8lwCLKmTWr = E0qU6274uWAjILvHa8(Kkecj5WTsm9rwlSJu1xqQLN)
	elif VRnfEFmJzUrSljM8==729: p8lwCLKmTWr = nWGdsTNS8h51(MMupPCxqkenwt6FlsbRILV37EAmB,Kkecj5WTsm9rwlSJu1xqQLN,kk1GKyapocQZDAz,zdu6VAyNEi5IL1)
	else: p8lwCLKmTWr = False
	return p8lwCLKmTWr
def s5z7jbHwX4kR():
	for Kkecj5WTsm9rwlSJu1xqQLN in range(1,pyq71xCY26s8hNQ+1):
		XgvWSQ6o5hzlux8 = '_MU'+str(Kkecj5WTsm9rwlSJu1xqQLN)+'_'
		cd0aGwCPExbFU5pYNu8r('folder',XgvWSQ6o5hzlux8+'قائمة مجلد '+Ri7qe1L6bhlGz3cyst4KSj[Kkecj5WTsm9rwlSJu1xqQLN],'',720,'','','','',{'folder':Kkecj5WTsm9rwlSJu1xqQLN})
	return
def MgXYEzpBGQfveJ3bHm1u(Kkecj5WTsm9rwlSJu1xqQLN='',PvaGjrNKS9C5TcxLBUIl4d10bHz=''):
	if Kkecj5WTsm9rwlSJu1xqQLN:
		l56eWRvjDP = {'folder':Kkecj5WTsm9rwlSJu1xqQLN}
		RVpbM5fI0UOy7du = ''
	else:
		l56eWRvjDP = ''
		RVpbM5fI0UOy7du = ''
	TlA0RJbdBSq6ovH2XN8pgLmP7 = c5X1OvfJRaklF(Kkecj5WTsm9rwlSJu1xqQLN,PvaGjrNKS9C5TcxLBUIl4d10bHz)
	if not TlA0RJbdBSq6ovH2XN8pgLmP7:
		cd0aGwCPExbFU5pYNu8r('link',XgvWSQ6o5hzlux8+'[COLOR FFFFFF00] إضافة وتغيير رابط'+RVpbM5fI0UOy7du+' '+Ri7qe1L6bhlGz3cyst4KSj[1]+' [/COLOR]','',711,'','','','',{'folder':Kkecj5WTsm9rwlSJu1xqQLN,'sequence':1})
		cd0aGwCPExbFU5pYNu8r('link',XgvWSQ6o5hzlux8+'[COLOR FFFFFF00] جلب ملفات'+RVpbM5fI0UOy7du+' [/COLOR]','',712,'','','','',l56eWRvjDP)
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	else:
		cd0aGwCPExbFU5pYNu8r('folder',XgvWSQ6o5hzlux8+'بحث في الملفات'+RVpbM5fI0UOy7du,'',729,'','','_REMEMBERRESULTS_','',l56eWRvjDP)
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		cd0aGwCPExbFU5pYNu8r('folder',XgvWSQ6o5hzlux8+'قنوات مصنفة مرتبة'+RVpbM5fI0UOy7du,'LIVE_GROUPED_SORTED',713,'','','','',l56eWRvjDP)
		cd0aGwCPExbFU5pYNu8r('folder',XgvWSQ6o5hzlux8+'قنوات مصنفة من القسم'+RVpbM5fI0UOy7du,'LIVE_FROM_GROUP_SORTED',713,'','','','',l56eWRvjDP)
		cd0aGwCPExbFU5pYNu8r('folder',XgvWSQ6o5hzlux8+'قنوات مصنفة من الاسم'+RVpbM5fI0UOy7du,'LIVE_FROM_NAME_SORTED',713,'','','','',l56eWRvjDP)
		cd0aGwCPExbFU5pYNu8r('folder',XgvWSQ6o5hzlux8+'قنوات مصنفة بلا ترتيب'+RVpbM5fI0UOy7du,'LIVE_GROUPED',713,'','','','',l56eWRvjDP)
		cd0aGwCPExbFU5pYNu8r('folder',XgvWSQ6o5hzlux8+'قنوات بلا ترتيب'+RVpbM5fI0UOy7du,'LIVE_ORIGINAL_GROUPED',713,'','','','',l56eWRvjDP)
		cd0aGwCPExbFU5pYNu8r('folder',XgvWSQ6o5hzlux8+'قنوات مجهولة مرتبة'+RVpbM5fI0UOy7du,'LIVE_UNKNOWN_GROUPED_SORTED',713,'','','','',l56eWRvjDP)
		cd0aGwCPExbFU5pYNu8r('folder',XgvWSQ6o5hzlux8+'قنوات مجهولة بلا ترتيب'+RVpbM5fI0UOy7du,'LIVE_UNKNOWN_GROUPED',713,'','','','',l56eWRvjDP)
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		cd0aGwCPExbFU5pYNu8r('folder',XgvWSQ6o5hzlux8+'فيديوهات بلا ترتيب'+RVpbM5fI0UOy7du,'VOD_ORIGINAL_GROUPED',713,'','','','',l56eWRvjDP)
		cd0aGwCPExbFU5pYNu8r('folder',XgvWSQ6o5hzlux8+'فيديوهات مصنفة القسم'+RVpbM5fI0UOy7du,'VOD_FROM_GROUP_SORTED',713,'','','','',l56eWRvjDP)
		cd0aGwCPExbFU5pYNu8r('folder',XgvWSQ6o5hzlux8+'فيديوهات مصنفة من الاسم'+RVpbM5fI0UOy7du,'VOD_FROM_NAME_SORTED',713,'','','','',l56eWRvjDP)
		cd0aGwCPExbFU5pYNu8r('folder',XgvWSQ6o5hzlux8+'فيديوهات مجهولة بلا ترتيب'+RVpbM5fI0UOy7du,'VOD_UNKNOWN_GROUPED',713,'','','','',l56eWRvjDP)
		cd0aGwCPExbFU5pYNu8r('folder',XgvWSQ6o5hzlux8+'فيديوهات مجهولة مرتبة'+RVpbM5fI0UOy7du,'VOD_UNKNOWN_GROUPED_SORTED',713,'','','','',l56eWRvjDP)
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for akVPDzJGgWi4vK3jNt0eCsuLUm9cZF in range(1,YY1DZ5qkNn+1):
		cd0aGwCPExbFU5pYNu8r('link',XgvWSQ6o5hzlux8+'إضافة وتغيير رابط'+RVpbM5fI0UOy7du+' '+Ri7qe1L6bhlGz3cyst4KSj[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF],'',711,'','','','',{'folder':Kkecj5WTsm9rwlSJu1xqQLN,'sequence':akVPDzJGgWi4vK3jNt0eCsuLUm9cZF})
	cd0aGwCPExbFU5pYNu8r('link',XgvWSQ6o5hzlux8+'جلب ملفات'+RVpbM5fI0UOy7du,'',712,'','','','',l56eWRvjDP)
	cd0aGwCPExbFU5pYNu8r('link',XgvWSQ6o5hzlux8+'مسح ملفات'+RVpbM5fI0UOy7du,'',717,'','','','',l56eWRvjDP)
	cd0aGwCPExbFU5pYNu8r('link',XgvWSQ6o5hzlux8+'عدد فيديوهات'+RVpbM5fI0UOy7du,'',721,'','','','',l56eWRvjDP)
	cd0aGwCPExbFU5pYNu8r('link',XgvWSQ6o5hzlux8+'Referer تغيير'+RVpbM5fI0UOy7du,'',726,'','','','',l56eWRvjDP)
	cd0aGwCPExbFU5pYNu8r('link',XgvWSQ6o5hzlux8+'User-Agent تغيير'+RVpbM5fI0UOy7du,'',723,'','','','',l56eWRvjDP)
	return
def k2pKMT0PjuaroAf8zOHvshqXF(Kkecj5WTsm9rwlSJu1xqQLN,PvaGjrNKS9C5TcxLBUIl4d10bHz=True):
	tx8i9jLaySnYIC5GeTzUr7vfBVcRw3,omJ8HlMED5iuCz = False,''
	JCm0LkY7hn3edW,gget9fLVImGrcoT6pvqw8Qd = '',''
	jYhxdBW8RpA1fFOZms,SMNlDK1d9EbJRoLOaIqZTp5zG72Vf,chruBaVmfeZ7Ps4,De3SRIg54y2nmT6Cw0LkAf7GEavx,LQvb4IOMczxBJ = JJRKaYfFBrw6A2(Kkecj5WTsm9rwlSJu1xqQLN)
	if De3SRIg54y2nmT6Cw0LkAf7GEavx=='': return False,'',''
	vqNwzh36FVc = Jgl0cPRtB7nb9E(Kkecj5WTsm9rwlSJu1xqQLN)
	if jYhxdBW8RpA1fFOZms:
		zGmyJhleoQZ = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,'GET',jYhxdBW8RpA1fFOZms,'',vqNwzh36FVc,False,'','M3U-CHECK_ACCOUNT-1st')
		xKglJoD3q9IepZMPjO2Lw4vBNG7HuS = zGmyJhleoQZ.content
		if zGmyJhleoQZ.succeeded:
			IeXvbsOrm7AaLw3Q,RCVk4e8jwOrMfcdGBuaLIt3s,H1vNzpbKVj9ifPrnTAGx,TUzg4vEVFwKNu,caFKPVLuHw7 = 0,0,'','',''
			try:
				OO4jzkxvdHqKpf1FMgByouaWX6 = JKw5OWktPZB('dict',xKglJoD3q9IepZMPjO2Lw4vBNG7HuS)
				omJ8HlMED5iuCz = OO4jzkxvdHqKpf1FMgByouaWX6['user_info']['status']
				tx8i9jLaySnYIC5GeTzUr7vfBVcRw3 = True
				H1vNzpbKVj9ifPrnTAGx = OO4jzkxvdHqKpf1FMgByouaWX6['server_info']['time_now']
			except: pass
			if H1vNzpbKVj9ifPrnTAGx:
				try:
					B068ARKIsafOPCXQHF = MQbODJoPV2w8TEAg4zXZdjLxSW.strptime(H1vNzpbKVj9ifPrnTAGx,'%Y.%m.%d %H:%M:%S')
					IeXvbsOrm7AaLw3Q = int(MQbODJoPV2w8TEAg4zXZdjLxSW.mktime(B068ARKIsafOPCXQHF))
					RCVk4e8jwOrMfcdGBuaLIt3s = int(MMHpSTojGILfZXWeCOPyn4-IeXvbsOrm7AaLw3Q)
					RCVk4e8jwOrMfcdGBuaLIt3s = int((RCVk4e8jwOrMfcdGBuaLIt3s+900)/1800)*1800
				except: pass
				try:
					B068ARKIsafOPCXQHF = MQbODJoPV2w8TEAg4zXZdjLxSW.localtime(int(OO4jzkxvdHqKpf1FMgByouaWX6['user_info']['created_at']))
					TUzg4vEVFwKNu = MQbODJoPV2w8TEAg4zXZdjLxSW.strftime('%Y.%m.%d %H:%M:%S',B068ARKIsafOPCXQHF)
				except: pass
				try:
					B068ARKIsafOPCXQHF = MQbODJoPV2w8TEAg4zXZdjLxSW.localtime(int(OO4jzkxvdHqKpf1FMgByouaWX6['user_info']['exp_date']))
					caFKPVLuHw7 = MQbODJoPV2w8TEAg4zXZdjLxSW.strftime('%Y.%m.%d %H:%M:%S',B068ARKIsafOPCXQHF)
				except: pass
			jHevARrF7lS.setSetting('av.m3u.timestamp_'+Kkecj5WTsm9rwlSJu1xqQLN,str(MMHpSTojGILfZXWeCOPyn4))
			jHevARrF7lS.setSetting('av.m3u.timediff_'+Kkecj5WTsm9rwlSJu1xqQLN,str(RCVk4e8jwOrMfcdGBuaLIt3s))
			try:
				uLj4xP6lrSeoGfTDwXbH3E8MiQg9hB = '"server_info":'+xKglJoD3q9IepZMPjO2Lw4vBNG7HuS.split('"server_info":')[1]
				uLj4xP6lrSeoGfTDwXbH3E8MiQg9hB = uLj4xP6lrSeoGfTDwXbH3E8MiQg9hB.replace(':',': ').replace(',',', ').replace('}}','}')
				oBuZrzLMjCR0Pt1QSOesWl5qkT2b9 = GGvHJKP9LUxEk10Fw.findall('"url": "(.*?)", "port": "(.*?)"',uLj4xP6lrSeoGfTDwXbH3E8MiQg9hB,GGvHJKP9LUxEk10Fw.DOTALL)
				JCm0LkY7hn3edW,gget9fLVImGrcoT6pvqw8Qd = oBuZrzLMjCR0Pt1QSOesWl5qkT2b9[0]
			except: tx8i9jLaySnYIC5GeTzUr7vfBVcRw3 = False
			if tx8i9jLaySnYIC5GeTzUr7vfBVcRw3 and PvaGjrNKS9C5TcxLBUIl4d10bHz:
				max = OO4jzkxvdHqKpf1FMgByouaWX6['user_info']['max_connections']
				DbgLeVAW1yjXNR5k3TBor0zYuMQEn = OO4jzkxvdHqKpf1FMgByouaWX6['user_info']['active_cons']
				VYsgnuZGbQF1v4fEJ = OO4jzkxvdHqKpf1FMgByouaWX6['user_info']['is_trial']
				A90tuaE8y1wkPjCxXrb7QB5N = jYhxdBW8RpA1fFOZms.split('?',1)
				LpdKxnIsY3Sy6qP = 'URL:  [COLOR FFC89008]'+jYhxdBW8RpA1fFOZms+'[/COLOR]'
				LpdKxnIsY3Sy6qP += '\n\nStatus:  '+'[COLOR FFC89008]'+omJ8HlMED5iuCz+'[/COLOR]'
				LpdKxnIsY3Sy6qP += '\nTrial:    '+'[COLOR FFC89008]'+str(VYsgnuZGbQF1v4fEJ=='1')+'[/COLOR]'
				LpdKxnIsY3Sy6qP += '\nCreated  At:  '+'[COLOR FFC89008]'+TUzg4vEVFwKNu+'[/COLOR]'
				LpdKxnIsY3Sy6qP += '\nExpiry Date:  '+'[COLOR FFC89008]'+caFKPVLuHw7+'[/COLOR]'
				LpdKxnIsY3Sy6qP += '\nConnections   ( Active / Maximum ) :  '+'[COLOR FFC89008]'+DbgLeVAW1yjXNR5k3TBor0zYuMQEn+' / '+max+'[/COLOR]'
				LpdKxnIsY3Sy6qP += '\nAllowed Outputs:   '+'[COLOR FFC89008]'+" , ".join(OO4jzkxvdHqKpf1FMgByouaWX6['user_info']['allowed_output_formats'])+'[/COLOR]'
				LpdKxnIsY3Sy6qP += '\n\n'+uLj4xP6lrSeoGfTDwXbH3E8MiQg9hB
				if omJ8HlMED5iuCz=='Active': W2mX5R4ShoirfzdFaOukjHZIDpC8('الاشتراك يعمل بدون مشاكل',LpdKxnIsY3Sy6qP)
				else: W2mX5R4ShoirfzdFaOukjHZIDpC8('يبدو أن هناك مشكلة في الاشتراك',LpdKxnIsY3Sy6qP)
	if jYhxdBW8RpA1fFOZms and tx8i9jLaySnYIC5GeTzUr7vfBVcRw3 and omJ8HlMED5iuCz=='Active':
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q('NOTICE','.  Checking M3U URL   [ M3U account is OK ]   [ '+jYhxdBW8RpA1fFOZms+' ]')
		Ax4racOvNio2fRj9wPhFyBnSeE = True
	else:
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q('ERROR_LINES','Checking M3U URL   [ Does not work ]   [ '+jYhxdBW8RpA1fFOZms+' ]')
		if PvaGjrNKS9C5TcxLBUIl4d10bHz: aHKzv76JCVnprbY8w('','','فحص اشتراك ـM3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		Ax4racOvNio2fRj9wPhFyBnSeE = False
	return Ax4racOvNio2fRj9wPhFyBnSeE,JCm0LkY7hn3edW,gget9fLVImGrcoT6pvqw8Qd
def L4L0TUsN51taeljfc(Kkecj5WTsm9rwlSJu1xqQLN,Shf69xuNDp8KUm2wtsAv,iefb6FS2na39RcJOhQy,srYAbBnl3KhyqQzkg1IZ2p5NmPL,PvaGjrNKS9C5TcxLBUIl4d10bHz=True):
	if not srYAbBnl3KhyqQzkg1IZ2p5NmPL: srYAbBnl3KhyqQzkg1IZ2p5NmPL = '1'
	if not c5X1OvfJRaklF(Kkecj5WTsm9rwlSJu1xqQLN,PvaGjrNKS9C5TcxLBUIl4d10bHz): return
	E3PchtfOMLAF2b8Yl7ze0 = o6vRfdb78XFQ2BnGMKLWpHC(Kkecj5WTsm9rwlSJu1xqQLN,Shf69xuNDp8KUm2wtsAv)
	jSAYDebE2hZPsKU398vitN = P702PlzKg5o3mELCt(E3PchtfOMLAF2b8Yl7ze0,'list',Shf69xuNDp8KUm2wtsAv,iefb6FS2na39RcJOhQy)
	sMFNOYx78ndEzcmH5K = int(srYAbBnl3KhyqQzkg1IZ2p5NmPL)*100
	cZ4lExhjBNvmp3OPyWQAT6s8 = sMFNOYx78ndEzcmH5K-100
	for BZzGu5Dp6f3jbTW04Mxco8yE,LmvaeNnVjSX5I,kk1GKyapocQZDAz,QQUuiDcMdVx in jSAYDebE2hZPsKU398vitN[cZ4lExhjBNvmp3OPyWQAT6s8:sMFNOYx78ndEzcmH5K]:
		HzNlJqsC0TEhRe = ('GROUPED' in Shf69xuNDp8KUm2wtsAv or Shf69xuNDp8KUm2wtsAv=='ALL')
		TTlv4F7o0aSewOWCUp = ('GROUPED' not in Shf69xuNDp8KUm2wtsAv and Shf69xuNDp8KUm2wtsAv!='ALL')
		if HzNlJqsC0TEhRe or TTlv4F7o0aSewOWCUp:
			if   'ARCHIVED'  in Shf69xuNDp8KUm2wtsAv: D6DrJsclfY.append(['folder',XgvWSQ6o5hzlux8+LmvaeNnVjSX5I,kk1GKyapocQZDAz,718,QQUuiDcMdVx,'','ARCHIVED','',{'folder':Kkecj5WTsm9rwlSJu1xqQLN}])
			elif 'EPG' 		 in Shf69xuNDp8KUm2wtsAv: D6DrJsclfY.append(['folder',XgvWSQ6o5hzlux8+LmvaeNnVjSX5I,kk1GKyapocQZDAz,718,QQUuiDcMdVx,'','FULL_EPG','',{'folder':Kkecj5WTsm9rwlSJu1xqQLN}])
			elif 'TIMESHIFT' in Shf69xuNDp8KUm2wtsAv: D6DrJsclfY.append(['folder',XgvWSQ6o5hzlux8+LmvaeNnVjSX5I,kk1GKyapocQZDAz,718,QQUuiDcMdVx,'','TIMESHIFT','',{'folder':Kkecj5WTsm9rwlSJu1xqQLN}])
			elif 'LIVE' 	 in Shf69xuNDp8KUm2wtsAv: D6DrJsclfY.append(['live',XgvWSQ6o5hzlux8+LmvaeNnVjSX5I,kk1GKyapocQZDAz,715,QQUuiDcMdVx,'','',BZzGu5Dp6f3jbTW04Mxco8yE,{'folder':Kkecj5WTsm9rwlSJu1xqQLN}])
			else: D6DrJsclfY.append(['video',XgvWSQ6o5hzlux8+LmvaeNnVjSX5I,kk1GKyapocQZDAz,715,QQUuiDcMdVx,'','','',{'folder':Kkecj5WTsm9rwlSJu1xqQLN}])
	JYVmGQ4726BXL3M8pzrtTnUOS = len(jSAYDebE2hZPsKU398vitN)
	Ozfhb9uBAL7lG3qU6ri(Kkecj5WTsm9rwlSJu1xqQLN,srYAbBnl3KhyqQzkg1IZ2p5NmPL,Shf69xuNDp8KUm2wtsAv,714,JYVmGQ4726BXL3M8pzrtTnUOS,iefb6FS2na39RcJOhQy)
	return
def xxSAVEBkcl3GLNCa5mfe6b89YUh(EyL6ROKnxXY4cGS95MFUmpziJfhv0):
	cd0aGwCPExbFU5pYNu8r('link',EyL6ROKnxXY4cGS95MFUmpziJfhv0+'هذه القائمة إما فارغة أو غير موجودة','',9999)
	cd0aGwCPExbFU5pYNu8r('link',EyL6ROKnxXY4cGS95MFUmpziJfhv0+'أو الخدمة غير موجودة في اشتراكك','',9999)
	cd0aGwCPExbFU5pYNu8r('link',EyL6ROKnxXY4cGS95MFUmpziJfhv0+'أو رابط M3U الذي أنت أضفته غير صحيح','',9999)
	return
def gLD9AntXhScRo1arYBsU42(Kkecj5WTsm9rwlSJu1xqQLN,Shf69xuNDp8KUm2wtsAv,iefb6FS2na39RcJOhQy,srYAbBnl3KhyqQzkg1IZ2p5NmPL,JRI0oPTMfQXnxUg='',PvaGjrNKS9C5TcxLBUIl4d10bHz=True):
	if not srYAbBnl3KhyqQzkg1IZ2p5NmPL: srYAbBnl3KhyqQzkg1IZ2p5NmPL = '1'
	EyL6ROKnxXY4cGS95MFUmpziJfhv0 = XgvWSQ6o5hzlux8
	if not c5X1OvfJRaklF(Kkecj5WTsm9rwlSJu1xqQLN,PvaGjrNKS9C5TcxLBUIl4d10bHz): return False
	if '__SERIES__' in iefb6FS2na39RcJOhQy: ABe6v3zUqGhXaINmSolcKjnpr,OquUniPJ7ba1 = iefb6FS2na39RcJOhQy.split('__SERIES__')
	else: ABe6v3zUqGhXaINmSolcKjnpr,OquUniPJ7ba1 = iefb6FS2na39RcJOhQy,''
	E3PchtfOMLAF2b8Yl7ze0 = o6vRfdb78XFQ2BnGMKLWpHC(Kkecj5WTsm9rwlSJu1xqQLN,Shf69xuNDp8KUm2wtsAv)
	c0ZEIktlnVH = P702PlzKg5o3mELCt(E3PchtfOMLAF2b8Yl7ze0,'list',Shf69xuNDp8KUm2wtsAv,'__GROUPS__')
	if not c0ZEIktlnVH: return False
	chU4AqniFubpZYCHMmat8lW5N = []
	for t1ta89OgTzdG5DfA4ZEvJspWhQLc,QQUuiDcMdVx in c0ZEIktlnVH:
		if '===== ===== =====' in t1ta89OgTzdG5DfA4ZEvJspWhQLc:
			cd0aGwCPExbFU5pYNu8r('link',EyL6ROKnxXY4cGS95MFUmpziJfhv0+t1ta89OgTzdG5DfA4ZEvJspWhQLc,'',9999)
			cd0aGwCPExbFU5pYNu8r('link',EyL6ROKnxXY4cGS95MFUmpziJfhv0+t1ta89OgTzdG5DfA4ZEvJspWhQLc,'',9999)
			continue
		if JRI0oPTMfQXnxUg:
			if '__SERIES__' in t1ta89OgTzdG5DfA4ZEvJspWhQLc: EyL6ROKnxXY4cGS95MFUmpziJfhv0 = 'SERIES'
			elif '!!__UNKNOWN__!!' in t1ta89OgTzdG5DfA4ZEvJspWhQLc: EyL6ROKnxXY4cGS95MFUmpziJfhv0 = 'UNKNOWN'
			elif 'LIVE' in Shf69xuNDp8KUm2wtsAv: EyL6ROKnxXY4cGS95MFUmpziJfhv0 = 'LIVE'
			else: EyL6ROKnxXY4cGS95MFUmpziJfhv0 = 'VIDEOS'
			EyL6ROKnxXY4cGS95MFUmpziJfhv0 = ',[COLOR FFC89008]'+EyL6ROKnxXY4cGS95MFUmpziJfhv0+': [/COLOR]'
		if '__SERIES__' in t1ta89OgTzdG5DfA4ZEvJspWhQLc: NdBtKhvMnXG,qmEzwpMoNZ = t1ta89OgTzdG5DfA4ZEvJspWhQLc.split('__SERIES__')
		else: NdBtKhvMnXG,qmEzwpMoNZ = t1ta89OgTzdG5DfA4ZEvJspWhQLc,''
		if not iefb6FS2na39RcJOhQy:
			if NdBtKhvMnXG in chU4AqniFubpZYCHMmat8lW5N: continue
			chU4AqniFubpZYCHMmat8lW5N.append(NdBtKhvMnXG)
			if 'RANDOM' in JRI0oPTMfQXnxUg: cd0aGwCPExbFU5pYNu8r('folder',EyL6ROKnxXY4cGS95MFUmpziJfhv0+NdBtKhvMnXG,Shf69xuNDp8KUm2wtsAv,168,'','1',t1ta89OgTzdG5DfA4ZEvJspWhQLc,'',{'folder':Kkecj5WTsm9rwlSJu1xqQLN})
			elif '__SERIES__' in t1ta89OgTzdG5DfA4ZEvJspWhQLc: cd0aGwCPExbFU5pYNu8r('folder',EyL6ROKnxXY4cGS95MFUmpziJfhv0+NdBtKhvMnXG,Shf69xuNDp8KUm2wtsAv,713,'','1',t1ta89OgTzdG5DfA4ZEvJspWhQLc,'',{'folder':Kkecj5WTsm9rwlSJu1xqQLN})
			else: cd0aGwCPExbFU5pYNu8r('folder',EyL6ROKnxXY4cGS95MFUmpziJfhv0+NdBtKhvMnXG,Shf69xuNDp8KUm2wtsAv,714,'','1',t1ta89OgTzdG5DfA4ZEvJspWhQLc,'',{'folder':Kkecj5WTsm9rwlSJu1xqQLN})
		elif '__SERIES__' in t1ta89OgTzdG5DfA4ZEvJspWhQLc and NdBtKhvMnXG==ABe6v3zUqGhXaINmSolcKjnpr:
			if qmEzwpMoNZ in chU4AqniFubpZYCHMmat8lW5N: continue
			chU4AqniFubpZYCHMmat8lW5N.append(qmEzwpMoNZ)
			if 'RANDOM' in JRI0oPTMfQXnxUg: cd0aGwCPExbFU5pYNu8r('folder',EyL6ROKnxXY4cGS95MFUmpziJfhv0+qmEzwpMoNZ,Shf69xuNDp8KUm2wtsAv,168,'','1',t1ta89OgTzdG5DfA4ZEvJspWhQLc,'',{'folder':Kkecj5WTsm9rwlSJu1xqQLN})
			else: cd0aGwCPExbFU5pYNu8r('folder',EyL6ROKnxXY4cGS95MFUmpziJfhv0+qmEzwpMoNZ,Shf69xuNDp8KUm2wtsAv,714,QQUuiDcMdVx,'1',t1ta89OgTzdG5DfA4ZEvJspWhQLc,'',{'folder':Kkecj5WTsm9rwlSJu1xqQLN})
	D6DrJsclfY[:] = sorted(D6DrJsclfY,reverse=False,key=lambda f3kLWlmQJcbvRG0tYqj4uigThV6s: f3kLWlmQJcbvRG0tYqj4uigThV6s[1].lower())
	if not JRI0oPTMfQXnxUg:
		sMFNOYx78ndEzcmH5K = int(srYAbBnl3KhyqQzkg1IZ2p5NmPL)*100
		cZ4lExhjBNvmp3OPyWQAT6s8 = sMFNOYx78ndEzcmH5K-100
		JYVmGQ4726BXL3M8pzrtTnUOS = len(D6DrJsclfY)
		D6DrJsclfY[:] = D6DrJsclfY[cZ4lExhjBNvmp3OPyWQAT6s8:sMFNOYx78ndEzcmH5K]
		Ozfhb9uBAL7lG3qU6ri(Kkecj5WTsm9rwlSJu1xqQLN,srYAbBnl3KhyqQzkg1IZ2p5NmPL,Shf69xuNDp8KUm2wtsAv,713,JYVmGQ4726BXL3M8pzrtTnUOS,iefb6FS2na39RcJOhQy)
	return True
def UCmW4FGwhbcx8(Kkecj5WTsm9rwlSJu1xqQLN,kk1GKyapocQZDAz,aZiFGflIoB9q1MERugneTbmW):
	if not c5X1OvfJRaklF(Kkecj5WTsm9rwlSJu1xqQLN,True): return
	vqNwzh36FVc = Jgl0cPRtB7nb9E(Kkecj5WTsm9rwlSJu1xqQLN)
	IeXvbsOrm7AaLw3Q = jHevARrF7lS.getSetting('av.m3u.timestamp_'+Kkecj5WTsm9rwlSJu1xqQLN)
	if not IeXvbsOrm7AaLw3Q or MMHpSTojGILfZXWeCOPyn4-int(IeXvbsOrm7AaLw3Q)>24*EE1u6LYDqNpi:
		Ax4racOvNio2fRj9wPhFyBnSeE,JCm0LkY7hn3edW,gget9fLVImGrcoT6pvqw8Qd = k2pKMT0PjuaroAf8zOHvshqXF(Kkecj5WTsm9rwlSJu1xqQLN,False)
		if not Ax4racOvNio2fRj9wPhFyBnSeE: return
	RCVk4e8jwOrMfcdGBuaLIt3s = int(jHevARrF7lS.getSetting('av.m3u.timediff_'+Kkecj5WTsm9rwlSJu1xqQLN))
	chruBaVmfeZ7Ps4 = jHevARrF7lS.getSetting('av.m3u.server_'+Kkecj5WTsm9rwlSJu1xqQLN)
	De3SRIg54y2nmT6Cw0LkAf7GEavx = jHevARrF7lS.getSetting('av.m3u.username_'+Kkecj5WTsm9rwlSJu1xqQLN)
	LQvb4IOMczxBJ = jHevARrF7lS.getSetting('av.m3u.password_'+Kkecj5WTsm9rwlSJu1xqQLN)
	m70kQaGrtYloe81Mgd3n4wAIN = kk1GKyapocQZDAz.split('/')
	eoH1BnQ59ji76GNOfpmhuLU8t = m70kQaGrtYloe81Mgd3n4wAIN[-1].replace('.ts','').replace('.m3u8','')
	if aZiFGflIoB9q1MERugneTbmW=='SHORT_EPG': aI36SNlWpuD = 'get_short_epg'
	else: aI36SNlWpuD = 'get_simple_data_table'
	jYhxdBW8RpA1fFOZms,SMNlDK1d9EbJRoLOaIqZTp5zG72Vf,chruBaVmfeZ7Ps4,De3SRIg54y2nmT6Cw0LkAf7GEavx,LQvb4IOMczxBJ = JJRKaYfFBrw6A2(Kkecj5WTsm9rwlSJu1xqQLN)
	if not De3SRIg54y2nmT6Cw0LkAf7GEavx: return
	bgfIVxLYhadqRMP = jYhxdBW8RpA1fFOZms+'&action='+aI36SNlWpuD+'&stream_id='+eoH1BnQ59ji76GNOfpmhuLU8t
	xKglJoD3q9IepZMPjO2Lw4vBNG7HuS = zz3Ag7BvnbIS1D4ofFy(BXnrZSgERcxHvbVQ4,bgfIVxLYhadqRMP,'',vqNwzh36FVc,'','M3U-EPG_ITEMS-2nd')
	mTQ1sR6gtn3PjJ0ckedyaGfwCv = JKw5OWktPZB('dict',xKglJoD3q9IepZMPjO2Lw4vBNG7HuS)
	vLR1rsnoMZmVuQOPHhYBJw82I = mTQ1sR6gtn3PjJ0ckedyaGfwCv['epg_listings']
	CC2bVdajnmLKGlo6sOWFPX3Bi = []
	if aZiFGflIoB9q1MERugneTbmW in ['ARCHIVED','TIMESHIFT']:
		for OO4jzkxvdHqKpf1FMgByouaWX6 in vLR1rsnoMZmVuQOPHhYBJw82I:
			if OO4jzkxvdHqKpf1FMgByouaWX6['has_archive']==1:
				CC2bVdajnmLKGlo6sOWFPX3Bi.append(OO4jzkxvdHqKpf1FMgByouaWX6)
				if aZiFGflIoB9q1MERugneTbmW in ['TIMESHIFT']: break
		if not CC2bVdajnmLKGlo6sOWFPX3Bi: return
		cd0aGwCPExbFU5pYNu8r('link',XgvWSQ6o5hzlux8+'[COLOR FFC89008]الملفات الأولي بهذه القائمة قد لا تعمل[/COLOR]','',9999)
		if aZiFGflIoB9q1MERugneTbmW in ['TIMESHIFT']:
			XmrQ6fbZH3I0kxN7ca = 2
			exvBFoM7Qs5KZJUXY2n8H6PlNfA0tk = XmrQ6fbZH3I0kxN7ca*EE1u6LYDqNpi
			CC2bVdajnmLKGlo6sOWFPX3Bi = []
			ppf9lGqLBsIKkyZbin7v12CY = int(int(OO4jzkxvdHqKpf1FMgByouaWX6['start_timestamp'])/exvBFoM7Qs5KZJUXY2n8H6PlNfA0tk)*exvBFoM7Qs5KZJUXY2n8H6PlNfA0tk
			dG2W67UelVBTDwM4IYomOp0FguRsS = MMHpSTojGILfZXWeCOPyn4+exvBFoM7Qs5KZJUXY2n8H6PlNfA0tk
			f6Ks830JQ1xrlARhCX4SUvFzMVdqZ = int((dG2W67UelVBTDwM4IYomOp0FguRsS-ppf9lGqLBsIKkyZbin7v12CY)/EE1u6LYDqNpi)
			for WLM259V3hkGyifQBAcnS in range(f6Ks830JQ1xrlARhCX4SUvFzMVdqZ):
				if WLM259V3hkGyifQBAcnS>=6:
					if WLM259V3hkGyifQBAcnS%XmrQ6fbZH3I0kxN7ca!=0: continue
					JP6KeQnB3AqWOh = exvBFoM7Qs5KZJUXY2n8H6PlNfA0tk
				else: JP6KeQnB3AqWOh = exvBFoM7Qs5KZJUXY2n8H6PlNfA0tk//2
				ix3y4tHEF0uz = ppf9lGqLBsIKkyZbin7v12CY+WLM259V3hkGyifQBAcnS*EE1u6LYDqNpi
				OO4jzkxvdHqKpf1FMgByouaWX6 = {}
				OO4jzkxvdHqKpf1FMgByouaWX6['title'] = ''
				B068ARKIsafOPCXQHF = MQbODJoPV2w8TEAg4zXZdjLxSW.localtime(ix3y4tHEF0uz-RCVk4e8jwOrMfcdGBuaLIt3s-EE1u6LYDqNpi)
				OO4jzkxvdHqKpf1FMgByouaWX6['start'] = MQbODJoPV2w8TEAg4zXZdjLxSW.strftime('%Y.%m.%d %H:%M:%S',B068ARKIsafOPCXQHF)
				OO4jzkxvdHqKpf1FMgByouaWX6['start_timestamp'] = str(ix3y4tHEF0uz)
				OO4jzkxvdHqKpf1FMgByouaWX6['stop_timestamp'] = str(ix3y4tHEF0uz+JP6KeQnB3AqWOh)
				CC2bVdajnmLKGlo6sOWFPX3Bi.append(OO4jzkxvdHqKpf1FMgByouaWX6)
	elif aZiFGflIoB9q1MERugneTbmW in ['SHORT_EPG','FULL_EPG']: CC2bVdajnmLKGlo6sOWFPX3Bi = vLR1rsnoMZmVuQOPHhYBJw82I
	if aZiFGflIoB9q1MERugneTbmW=='FULL_EPG' and len(CC2bVdajnmLKGlo6sOWFPX3Bi)>0:
		cd0aGwCPExbFU5pYNu8r('link',XgvWSQ6o5hzlux8+'[COLOR FFC89008]هذه قائمة برامج القنوات (جدول فقط)ـ[/COLOR]','',9999)
	u0uCylZVSU9pH5t = []
	QQUuiDcMdVx = cEZpW924rqNYm5.getInfoLabel('ListItem.Icon')
	for OO4jzkxvdHqKpf1FMgByouaWX6 in CC2bVdajnmLKGlo6sOWFPX3Bi:
		LmvaeNnVjSX5I = hNe0ECZHr9B6.b64decode(OO4jzkxvdHqKpf1FMgByouaWX6['title'])
		if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: LmvaeNnVjSX5I = LmvaeNnVjSX5I.decode('utf8')
		ix3y4tHEF0uz = int(OO4jzkxvdHqKpf1FMgByouaWX6['start_timestamp'])
		FaimjAxRKhwq5e9brXL8ZN = int(OO4jzkxvdHqKpf1FMgByouaWX6['stop_timestamp'])
		DKtUXu8dZgAbm9YNl2LnqQIO = str(int((FaimjAxRKhwq5e9brXL8ZN-ix3y4tHEF0uz+59)/60))
		sJedLOutQxzoaX2T9chlmjbpMD = OO4jzkxvdHqKpf1FMgByouaWX6['start'].replace(' ',':')
		B068ARKIsafOPCXQHF = MQbODJoPV2w8TEAg4zXZdjLxSW.localtime(ix3y4tHEF0uz-EE1u6LYDqNpi)
		VgZMKavyGUQj = MQbODJoPV2w8TEAg4zXZdjLxSW.strftime('%H:%M',B068ARKIsafOPCXQHF)
		Smyr5IFZu8wqdo = MQbODJoPV2w8TEAg4zXZdjLxSW.strftime('%a',B068ARKIsafOPCXQHF)
		if aZiFGflIoB9q1MERugneTbmW=='SHORT_EPG': LmvaeNnVjSX5I = '[COLOR FFFFFF00]'+VgZMKavyGUQj+' ـ '+LmvaeNnVjSX5I+'[/COLOR]'
		elif aZiFGflIoB9q1MERugneTbmW=='TIMESHIFT': LmvaeNnVjSX5I = Smyr5IFZu8wqdo+' '+VgZMKavyGUQj+' ('+DKtUXu8dZgAbm9YNl2LnqQIO+'min)'
		else: LmvaeNnVjSX5I = Smyr5IFZu8wqdo+' '+VgZMKavyGUQj+' ('+DKtUXu8dZgAbm9YNl2LnqQIO+'min)   '+LmvaeNnVjSX5I+' ـ'
		if aZiFGflIoB9q1MERugneTbmW in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			Jt2CNcE7QbImPjGUKD94l6g3 = chruBaVmfeZ7Ps4+'/timeshift/'+De3SRIg54y2nmT6Cw0LkAf7GEavx+'/'+LQvb4IOMczxBJ+'/'+DKtUXu8dZgAbm9YNl2LnqQIO+'/'+sJedLOutQxzoaX2T9chlmjbpMD+'/'+eoH1BnQ59ji76GNOfpmhuLU8t+'.m3u8'
			if aZiFGflIoB9q1MERugneTbmW=='FULL_EPG': cd0aGwCPExbFU5pYNu8r('link',XgvWSQ6o5hzlux8+LmvaeNnVjSX5I,Jt2CNcE7QbImPjGUKD94l6g3,9999,QQUuiDcMdVx,'','','',{'folder':Kkecj5WTsm9rwlSJu1xqQLN})
			else: cd0aGwCPExbFU5pYNu8r('video',XgvWSQ6o5hzlux8+LmvaeNnVjSX5I,Jt2CNcE7QbImPjGUKD94l6g3,715,QQUuiDcMdVx,'','','',{'folder':Kkecj5WTsm9rwlSJu1xqQLN})
		u0uCylZVSU9pH5t.append(LmvaeNnVjSX5I)
	if aZiFGflIoB9q1MERugneTbmW=='SHORT_EPG' and u0uCylZVSU9pH5t: rd4vL0M3YjfasgtxZ6EqBlF = VVlcpjUCK8HT70i(u0uCylZVSU9pH5t)
	return u0uCylZVSU9pH5t
def ywoasx5le3RiNH(Kkecj5WTsm9rwlSJu1xqQLN):
	if not c5X1OvfJRaklF(Kkecj5WTsm9rwlSJu1xqQLN,True): return
	chruBaVmfeZ7Ps4,MWRLS8pewOVh4Hqy5oxbgQNudY1,E75ETso4D0RcuJ8UdH1AP2tnqOlNy = '',0,0
	Ax4racOvNio2fRj9wPhFyBnSeE,JCm0LkY7hn3edW,gget9fLVImGrcoT6pvqw8Qd = k2pKMT0PjuaroAf8zOHvshqXF(Kkecj5WTsm9rwlSJu1xqQLN,False)
	if Ax4racOvNio2fRj9wPhFyBnSeE:
		NN8ruOiolh = CsaYzHKkqN4Dy10lV6XnSZbWhQ(JCm0LkY7hn3edW)
		MWRLS8pewOVh4Hqy5oxbgQNudY1 = P9UMWpgzcQqxO(NN8ruOiolh[0],int(gget9fLVImGrcoT6pvqw8Qd))
		E3PchtfOMLAF2b8Yl7ze0 = o6vRfdb78XFQ2BnGMKLWpHC(Kkecj5WTsm9rwlSJu1xqQLN,'LIVE_GROUPED')
		AFt4kHWRK9yherJ3ICVcBUsuql = P702PlzKg5o3mELCt(E3PchtfOMLAF2b8Yl7ze0,'list','LIVE_GROUPED')
		jSAYDebE2hZPsKU398vitN = P702PlzKg5o3mELCt(E3PchtfOMLAF2b8Yl7ze0,'list','LIVE_GROUPED',AFt4kHWRK9yherJ3ICVcBUsuql[1])
		kk1GKyapocQZDAz = jSAYDebE2hZPsKU398vitN[0][2]
		YYa0NqpIdACkX9v = GGvHJKP9LUxEk10Fw.findall('://(.*?)/',kk1GKyapocQZDAz,GGvHJKP9LUxEk10Fw.DOTALL)
		YYa0NqpIdACkX9v = YYa0NqpIdACkX9v[0]
		if ':' in YYa0NqpIdACkX9v: kwJGzrDQRUa28BYpuSZj6EKt,vD6kSz9XuPQ = YYa0NqpIdACkX9v.split(':')
		else: kwJGzrDQRUa28BYpuSZj6EKt,vD6kSz9XuPQ = YYa0NqpIdACkX9v,'80'
		og3IXsvfaO = CsaYzHKkqN4Dy10lV6XnSZbWhQ(kwJGzrDQRUa28BYpuSZj6EKt)
		E75ETso4D0RcuJ8UdH1AP2tnqOlNy = P9UMWpgzcQqxO(og3IXsvfaO[0],int(vD6kSz9XuPQ))
	if MWRLS8pewOVh4Hqy5oxbgQNudY1 and E75ETso4D0RcuJ8UdH1AP2tnqOlNy:
		LpdKxnIsY3Sy6qP = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		LpdKxnIsY3Sy6qP += '\n\n'+'وقت ضائع في السيرفر الأصلي'+'\n'+str(int(E75ETso4D0RcuJ8UdH1AP2tnqOlNy*1000))+' ملي ثانية'
		LpdKxnIsY3Sy6qP += '\n\n'+'وقت ضائع في السيرفر البديل'+'\n'+str(int(MWRLS8pewOVh4Hqy5oxbgQNudY1*1000))+' ملي ثانية'
		yYuG6rWaR9gmSO05jlZ1woUX3 = ggi4vBsqHDArM1('center','السيرفر الأصلي','السيرفر الأسرع','رسالة من المبرمج',LpdKxnIsY3Sy6qP)
		if yYuG6rWaR9gmSO05jlZ1woUX3==1 and MWRLS8pewOVh4Hqy5oxbgQNudY1<E75ETso4D0RcuJ8UdH1AP2tnqOlNy: chruBaVmfeZ7Ps4 = JCm0LkY7hn3edW+':'+gget9fLVImGrcoT6pvqw8Qd
	else: aHKzv76JCVnprbY8w('','','رسالة من المبرمج','البرنامج لم يجد السيرفر البديل')
	jHevARrF7lS.setSetting('av.m3u.server_'+Kkecj5WTsm9rwlSJu1xqQLN,chruBaVmfeZ7Ps4)
	return
def SUfe4unWoXBNFz90xqy(Kkecj5WTsm9rwlSJu1xqQLN,kk1GKyapocQZDAz,QTcZbyNIfxeU84vs5LBophFmqMAn6):
	Z1ZuwAjtfnMa5Fy29Ps4NhXeUTkxRH = jHevARrF7lS.getSetting('av.m3u.useragent_'+Kkecj5WTsm9rwlSJu1xqQLN)
	lt6VxyZ2wkK8UGnrQdYcg1ziR0NHWj = jHevARrF7lS.getSetting('av.m3u.referer_'+Kkecj5WTsm9rwlSJu1xqQLN)
	if Z1ZuwAjtfnMa5Fy29Ps4NhXeUTkxRH or lt6VxyZ2wkK8UGnrQdYcg1ziR0NHWj:
		kk1GKyapocQZDAz += '|'
		if Z1ZuwAjtfnMa5Fy29Ps4NhXeUTkxRH: kk1GKyapocQZDAz += '&User-Agent='+Z1ZuwAjtfnMa5Fy29Ps4NhXeUTkxRH
		if lt6VxyZ2wkK8UGnrQdYcg1ziR0NHWj: kk1GKyapocQZDAz += '&Referer='+lt6VxyZ2wkK8UGnrQdYcg1ziR0NHWj
		kk1GKyapocQZDAz = kk1GKyapocQZDAz.replace('|&','|')
	ICifW6hdKqxkAJ02XZgHysOwoV9Dc5(kk1GKyapocQZDAz,ucL0B1lWMCfAoEjG,QTcZbyNIfxeU84vs5LBophFmqMAn6)
	return
def V564p0o1UxjGnuL27m9cXJ3(Kkecj5WTsm9rwlSJu1xqQLN):
	aHKzv76JCVnprbY8w('','','رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـUser-Agent خاص')
	Z1ZuwAjtfnMa5Fy29Ps4NhXeUTkxRH = jHevARrF7lS.getSetting('av.m3u.useragent_'+Kkecj5WTsm9rwlSJu1xqQLN)
	VSn4wqyG5UmstoAjZaPXT = ggi4vBsqHDArM1('center','استخدام الأصلي','تعديل القديم',Z1ZuwAjtfnMa5Fy29Ps4NhXeUTkxRH,'هذا هو ـUser-Agent المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if VSn4wqyG5UmstoAjZaPXT==1: Z1ZuwAjtfnMa5Fy29Ps4NhXeUTkxRH = yMRXZIpKxlSkaE6iCO('أكتب ـM3U User-Agent جديد',Z1ZuwAjtfnMa5Fy29Ps4NhXeUTkxRH,True)
	else: Z1ZuwAjtfnMa5Fy29Ps4NhXeUTkxRH = 'Unknown'
	if Z1ZuwAjtfnMa5Fy29Ps4NhXeUTkxRH==' ':
		aHKzv76JCVnprbY8w('','','رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	VSn4wqyG5UmstoAjZaPXT = ggi4vBsqHDArM1('center','','',Z1ZuwAjtfnMa5Fy29Ps4NhXeUTkxRH,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if VSn4wqyG5UmstoAjZaPXT!=1:
		aHKzv76JCVnprbY8w('','','رسالة من المبرمج','تم الإلغاء')
		return
	jHevARrF7lS.setSetting('av.m3u.useragent_'+Kkecj5WTsm9rwlSJu1xqQLN,Z1ZuwAjtfnMa5Fy29Ps4NhXeUTkxRH)
	dMhIopnCqD(Kkecj5WTsm9rwlSJu1xqQLN)
	return
def E0qU6274uWAjILvHa8(Kkecj5WTsm9rwlSJu1xqQLN):
	aHKzv76JCVnprbY8w('','','رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـReferer خاص')
	lt6VxyZ2wkK8UGnrQdYcg1ziR0NHWj = jHevARrF7lS.getSetting('av.m3u.referer_'+Kkecj5WTsm9rwlSJu1xqQLN)
	VSn4wqyG5UmstoAjZaPXT = ggi4vBsqHDArM1('center','استخدام الأصلي','تعديل القديم',lt6VxyZ2wkK8UGnrQdYcg1ziR0NHWj,'هذا هو ـReferer المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if VSn4wqyG5UmstoAjZaPXT==1: lt6VxyZ2wkK8UGnrQdYcg1ziR0NHWj = yMRXZIpKxlSkaE6iCO('أكتب ـM3U Referer جديد',lt6VxyZ2wkK8UGnrQdYcg1ziR0NHWj,True)
	else: lt6VxyZ2wkK8UGnrQdYcg1ziR0NHWj = ''
	if lt6VxyZ2wkK8UGnrQdYcg1ziR0NHWj==' ':
		aHKzv76JCVnprbY8w('','','رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	VSn4wqyG5UmstoAjZaPXT = ggi4vBsqHDArM1('center','','',lt6VxyZ2wkK8UGnrQdYcg1ziR0NHWj,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if VSn4wqyG5UmstoAjZaPXT!=1:
		aHKzv76JCVnprbY8w('','','رسالة من المبرمج','تم الإلغاء')
		return
	jHevARrF7lS.setSetting('av.m3u.referer_'+Kkecj5WTsm9rwlSJu1xqQLN,lt6VxyZ2wkK8UGnrQdYcg1ziR0NHWj)
	dMhIopnCqD(Kkecj5WTsm9rwlSJu1xqQLN)
	return
def JJRKaYfFBrw6A2(Kkecj5WTsm9rwlSJu1xqQLN,GA9N3Q7IJ6jrig05XmYsDnRy=''):
	if not XXtkH1cZn3oaJhVTDBwlsubAP46Cm: XXtkH1cZn3oaJhVTDBwlsubAP46Cm = jHevARrF7lS.getSetting('av.m3u.url_'+Kkecj5WTsm9rwlSJu1xqQLN)
	chruBaVmfeZ7Ps4 = RfKuIXwPAiWtmyF(XXtkH1cZn3oaJhVTDBwlsubAP46Cm,'url')
	De3SRIg54y2nmT6Cw0LkAf7GEavx = GGvHJKP9LUxEk10Fw.findall('username=(.*?)&',XXtkH1cZn3oaJhVTDBwlsubAP46Cm+'&',GGvHJKP9LUxEk10Fw.DOTALL)
	LQvb4IOMczxBJ = GGvHJKP9LUxEk10Fw.findall('password=(.*?)&',XXtkH1cZn3oaJhVTDBwlsubAP46Cm+'&',GGvHJKP9LUxEk10Fw.DOTALL)
	if not De3SRIg54y2nmT6Cw0LkAf7GEavx or not LQvb4IOMczxBJ:
		aHKzv76JCVnprbY8w('','','فحص اشتراك M3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		return '','','','',''
	De3SRIg54y2nmT6Cw0LkAf7GEavx = De3SRIg54y2nmT6Cw0LkAf7GEavx[0]
	LQvb4IOMczxBJ = LQvb4IOMczxBJ[0]
	jYhxdBW8RpA1fFOZms = chruBaVmfeZ7Ps4+'/player_api.php?username='+De3SRIg54y2nmT6Cw0LkAf7GEavx+'&password='+LQvb4IOMczxBJ
	SMNlDK1d9EbJRoLOaIqZTp5zG72Vf = chruBaVmfeZ7Ps4+'/get.php?username='+De3SRIg54y2nmT6Cw0LkAf7GEavx+'&password='+LQvb4IOMczxBJ+'&type=m3u_plus'
	return jYhxdBW8RpA1fFOZms,SMNlDK1d9EbJRoLOaIqZTp5zG72Vf,chruBaVmfeZ7Ps4,De3SRIg54y2nmT6Cw0LkAf7GEavx,LQvb4IOMczxBJ
def If8LPzBmOS(Kkecj5WTsm9rwlSJu1xqQLN,jLtSeVhncqHJ8p7m3W1B=''):
	HpeJd0UFhnr86Z3TAi1tlWfGB = jLtSeVhncqHJ8p7m3W1B.replace('/','_').replace(':','_').replace('.','_')
	HpeJd0UFhnr86Z3TAi1tlWfGB = HpeJd0UFhnr86Z3TAi1tlWfGB.replace('?','_').replace('=','_').replace('&','_')
	HpeJd0UFhnr86Z3TAi1tlWfGB = WpgZTyqoMAPhwGiXF.path.join(JXUQZHLxEgTFbrRC7n9,HpeJd0UFhnr86Z3TAi1tlWfGB).strip('.m3u')+'.m3u'
	return HpeJd0UFhnr86Z3TAi1tlWfGB
def DTrYUCtdGu4Q90iq(Kkecj5WTsm9rwlSJu1xqQLN,IQG0cV3XZxjr5u):
	QQgjdPYKayqXSfGCU = jHevARrF7lS.getSetting('av.m3u.url_'+Kkecj5WTsm9rwlSJu1xqQLN+'_'+IQG0cV3XZxjr5u)
	ngo5JOYhrLSIXT68mK7R2qbBd = True
	if QQgjdPYKayqXSfGCU:
		VSn4wqyG5UmstoAjZaPXT = CCQOct8zmrKMuP6ZEkxq7oaf1BeRv('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:','[COLOR FFC89008]'+QQgjdPYKayqXSfGCU+'[/COLOR]'+'\n\n هذا هو رابط M3U المسجل في البرنامج .. هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if VSn4wqyG5UmstoAjZaPXT==-1: return
		elif VSn4wqyG5UmstoAjZaPXT==0: QQgjdPYKayqXSfGCU = ''
		elif VSn4wqyG5UmstoAjZaPXT==2:
			VSn4wqyG5UmstoAjZaPXT = ggi4vBsqHDArM1('center','','','رسالة من المبرمج','هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if VSn4wqyG5UmstoAjZaPXT in [-1,0]: return
			aHKzv76JCVnprbY8w('','','رسالة من المبرمج','تم مسح الرابط')
			ngo5JOYhrLSIXT68mK7R2qbBd = False
			b74aCq6NGjTm3QZY9AJp0PcyisLV8 = ''
	if ngo5JOYhrLSIXT68mK7R2qbBd:
		b74aCq6NGjTm3QZY9AJp0PcyisLV8 = yMRXZIpKxlSkaE6iCO('اكتب رابط M3U كاملا',QQgjdPYKayqXSfGCU)
		b74aCq6NGjTm3QZY9AJp0PcyisLV8 = b74aCq6NGjTm3QZY9AJp0PcyisLV8.strip(' ')
		if not b74aCq6NGjTm3QZY9AJp0PcyisLV8:
			VSn4wqyG5UmstoAjZaPXT = ggi4vBsqHDArM1('center','','','رسالة من المبرمج','لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if VSn4wqyG5UmstoAjZaPXT in [-1,0]: return
			aHKzv76JCVnprbY8w('','','رسالة من المبرمج','تم مسح الرابط')
		else:
			LpdKxnIsY3Sy6qP = 'هذه المعلومات تم أخذها من رابط ـM3U الذي انت كتبته . هل تريد استخدامها ؟!\n'
			VSn4wqyG5UmstoAjZaPXT = ggi4vBsqHDArM1('','','','الرابط الجديد هو:','[COLOR FFC89008]'+b74aCq6NGjTm3QZY9AJp0PcyisLV8+'[/COLOR]'+'\n\n'+LpdKxnIsY3Sy6qP)
			if VSn4wqyG5UmstoAjZaPXT!=1:
				aHKzv76JCVnprbY8w('','','رسالة من المبرمج','تم الإلغاء')
				return
	jHevARrF7lS.setSetting('av.m3u.url_'+Kkecj5WTsm9rwlSJu1xqQLN+'_'+IQG0cV3XZxjr5u,b74aCq6NGjTm3QZY9AJp0PcyisLV8)
	Z1ZuwAjtfnMa5Fy29Ps4NhXeUTkxRH = jHevARrF7lS.getSetting('av.m3u.useragent_'+Kkecj5WTsm9rwlSJu1xqQLN)
	if not Z1ZuwAjtfnMa5Fy29Ps4NhXeUTkxRH: jHevARrF7lS.setSetting('av.m3u.useragent_'+Kkecj5WTsm9rwlSJu1xqQLN,'Unknown')
	dMhIopnCqD(Kkecj5WTsm9rwlSJu1xqQLN)
	return
def hEdRXpT7ClueFc24KH0f(cXQ84du5sj97FvCiOoqTwJhWk16z,PPtlZ0Q9swcuIr41O5pGW3gJb,RsIBajtzmCP3,jBv4U2xYQ7IMewEA31aJqpoOrD5,IbqVpM2HXP98kWtfDw3A,GBFbN7Xqch6uSWt,SMNlDK1d9EbJRoLOaIqZTp5zG72Vf):
	jSAYDebE2hZPsKU398vitN,D6p5NLWIvu3jEGTU = [],[]
	HS7Oqb1Dsk0fgVuQW = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for ulk0vBZaNR in cXQ84du5sj97FvCiOoqTwJhWk16z:
		if GBFbN7Xqch6uSWt%473==0:
			FFBJqkrThNeWfiaZPE5Aws9uGdp(jBv4U2xYQ7IMewEA31aJqpoOrD5,40+int(10*GBFbN7Xqch6uSWt/IbqVpM2HXP98kWtfDw3A),'قراءة الفيديوهات','الفيديو رقم:-',str(GBFbN7Xqch6uSWt)+' / '+str(IbqVpM2HXP98kWtfDw3A))
			if jBv4U2xYQ7IMewEA31aJqpoOrD5.iscanceled():
				jBv4U2xYQ7IMewEA31aJqpoOrD5.close()
				return None,None,None
		kk1GKyapocQZDAz = GGvHJKP9LUxEk10Fw.findall('^(.*?)\n+((http|https|rtmp).*?)$',ulk0vBZaNR,GGvHJKP9LUxEk10Fw.DOTALL)
		if kk1GKyapocQZDAz:
			ulk0vBZaNR,kk1GKyapocQZDAz,KCD6TolwuY04WaLshzSpEqOFUV = kk1GKyapocQZDAz[0]
			kk1GKyapocQZDAz = kk1GKyapocQZDAz.replace('\n','')
			ulk0vBZaNR = ulk0vBZaNR.replace('\n','')
		else:
			D6p5NLWIvu3jEGTU.append({'line':ulk0vBZaNR})
			continue
		Kz5JHpnLGqP4vyWk0eT,BZzGu5Dp6f3jbTW04Mxco8yE,t1ta89OgTzdG5DfA4ZEvJspWhQLc,LmvaeNnVjSX5I,QTcZbyNIfxeU84vs5LBophFmqMAn6,MkgEc2uthN7j4HD = {},'','','','',False
		try:
			ulk0vBZaNR,LmvaeNnVjSX5I = ulk0vBZaNR.rsplit('",',1)
			ulk0vBZaNR = ulk0vBZaNR+'"'
		except:
			try: ulk0vBZaNR,LmvaeNnVjSX5I = ulk0vBZaNR.rsplit('1,',1)
			except: LmvaeNnVjSX5I = ''
		Kz5JHpnLGqP4vyWk0eT['url'] = kk1GKyapocQZDAz
		GGQlHJREFA3kTPrBO8ibSmsYt0a = GGvHJKP9LUxEk10Fw.findall(' (.*?)="(.*?)"',ulk0vBZaNR,GGvHJKP9LUxEk10Fw.DOTALL)
		for f3kLWlmQJcbvRG0tYqj4uigThV6s,dhwxGNvOkIFC4WYnSZz6DXRA1opue in GGQlHJREFA3kTPrBO8ibSmsYt0a:
			f3kLWlmQJcbvRG0tYqj4uigThV6s = f3kLWlmQJcbvRG0tYqj4uigThV6s.replace('"','').strip(' ')
			Kz5JHpnLGqP4vyWk0eT[f3kLWlmQJcbvRG0tYqj4uigThV6s] = dhwxGNvOkIFC4WYnSZz6DXRA1opue.strip(' ')
		kkP0pZ3VfazCGQtFe1c9NhDmX = list(Kz5JHpnLGqP4vyWk0eT.keys())
		if not LmvaeNnVjSX5I:
			if 'name' in kkP0pZ3VfazCGQtFe1c9NhDmX and Kz5JHpnLGqP4vyWk0eT['name']: LmvaeNnVjSX5I = Kz5JHpnLGqP4vyWk0eT['name']
		Kz5JHpnLGqP4vyWk0eT['title'] = LmvaeNnVjSX5I.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'logo' in kkP0pZ3VfazCGQtFe1c9NhDmX:
			Kz5JHpnLGqP4vyWk0eT['img'] = Kz5JHpnLGqP4vyWk0eT['logo']
			del Kz5JHpnLGqP4vyWk0eT['logo']
		else: Kz5JHpnLGqP4vyWk0eT['img'] = ''
		if 'group' in kkP0pZ3VfazCGQtFe1c9NhDmX and Kz5JHpnLGqP4vyWk0eT['group']: t1ta89OgTzdG5DfA4ZEvJspWhQLc = Kz5JHpnLGqP4vyWk0eT['group']
		if any(hieW1zRUG5w9AykJjv0X in kk1GKyapocQZDAz.lower() for hieW1zRUG5w9AykJjv0X in HS7Oqb1Dsk0fgVuQW):
			MkgEc2uthN7j4HD = True if 'm3u' not in kk1GKyapocQZDAz else False
		if MkgEc2uthN7j4HD or '__SERIES__' in t1ta89OgTzdG5DfA4ZEvJspWhQLc or '__MOVIES__' in t1ta89OgTzdG5DfA4ZEvJspWhQLc:
			QTcZbyNIfxeU84vs5LBophFmqMAn6 = 'VOD'
			if '__SERIES__' in t1ta89OgTzdG5DfA4ZEvJspWhQLc: QTcZbyNIfxeU84vs5LBophFmqMAn6 = QTcZbyNIfxeU84vs5LBophFmqMAn6+'_SERIES'
			elif '__MOVIES__' in t1ta89OgTzdG5DfA4ZEvJspWhQLc: QTcZbyNIfxeU84vs5LBophFmqMAn6 = QTcZbyNIfxeU84vs5LBophFmqMAn6+'_MOVIES'
			else: QTcZbyNIfxeU84vs5LBophFmqMAn6 = QTcZbyNIfxeU84vs5LBophFmqMAn6+'_UNKNOWN'
			t1ta89OgTzdG5DfA4ZEvJspWhQLc = t1ta89OgTzdG5DfA4ZEvJspWhQLc.replace('__SERIES__','').replace('__MOVIES__','')
		else:
			QTcZbyNIfxeU84vs5LBophFmqMAn6 = 'LIVE'
			if LmvaeNnVjSX5I in PPtlZ0Q9swcuIr41O5pGW3gJb: BZzGu5Dp6f3jbTW04Mxco8yE = BZzGu5Dp6f3jbTW04Mxco8yE+'_EPG'
			if LmvaeNnVjSX5I in RsIBajtzmCP3: BZzGu5Dp6f3jbTW04Mxco8yE = BZzGu5Dp6f3jbTW04Mxco8yE+'_ARCHIVED'
			if not t1ta89OgTzdG5DfA4ZEvJspWhQLc: QTcZbyNIfxeU84vs5LBophFmqMAn6 = QTcZbyNIfxeU84vs5LBophFmqMAn6+'_UNKNOWN'
			else: QTcZbyNIfxeU84vs5LBophFmqMAn6 = QTcZbyNIfxeU84vs5LBophFmqMAn6+BZzGu5Dp6f3jbTW04Mxco8yE
		t1ta89OgTzdG5DfA4ZEvJspWhQLc = t1ta89OgTzdG5DfA4ZEvJspWhQLc.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'LIVE_UNKNOWN' in QTcZbyNIfxeU84vs5LBophFmqMAn6: t1ta89OgTzdG5DfA4ZEvJspWhQLc = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in QTcZbyNIfxeU84vs5LBophFmqMAn6: t1ta89OgTzdG5DfA4ZEvJspWhQLc = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in QTcZbyNIfxeU84vs5LBophFmqMAn6:
			k1k0VKJUjMLGy3Rf = GGvHJKP9LUxEk10Fw.findall('(.*?) [Ss]\d+ +[Ee]\d+',Kz5JHpnLGqP4vyWk0eT['title'],GGvHJKP9LUxEk10Fw.DOTALL)
			if k1k0VKJUjMLGy3Rf: k1k0VKJUjMLGy3Rf = k1k0VKJUjMLGy3Rf[0]
			else: k1k0VKJUjMLGy3Rf = '!!__UNKNOWN_SERIES__!!'
			t1ta89OgTzdG5DfA4ZEvJspWhQLc = t1ta89OgTzdG5DfA4ZEvJspWhQLc+'__SERIES__'+k1k0VKJUjMLGy3Rf
		if 'id' in kkP0pZ3VfazCGQtFe1c9NhDmX: del Kz5JHpnLGqP4vyWk0eT['id']
		if 'ID' in kkP0pZ3VfazCGQtFe1c9NhDmX: del Kz5JHpnLGqP4vyWk0eT['ID']
		if 'name' in kkP0pZ3VfazCGQtFe1c9NhDmX: del Kz5JHpnLGqP4vyWk0eT['name']
		LmvaeNnVjSX5I = Kz5JHpnLGqP4vyWk0eT['title']
		LmvaeNnVjSX5I = ptMqV54oKJhQ8CH(LmvaeNnVjSX5I)
		LmvaeNnVjSX5I = VVuW3Y6KPl7(LmvaeNnVjSX5I)
		lXsQ3v6J0tWN5VPGHkpjCmOI,t1ta89OgTzdG5DfA4ZEvJspWhQLc = BKiDIq4Fm9VdujnRfG7pJyHOzs(t1ta89OgTzdG5DfA4ZEvJspWhQLc)
		kcLd7brzj6JXNFwGpVEy2eYnS3058v,LmvaeNnVjSX5I = BKiDIq4Fm9VdujnRfG7pJyHOzs(LmvaeNnVjSX5I)
		Kz5JHpnLGqP4vyWk0eT['type'] = QTcZbyNIfxeU84vs5LBophFmqMAn6
		Kz5JHpnLGqP4vyWk0eT['context'] = BZzGu5Dp6f3jbTW04Mxco8yE
		Kz5JHpnLGqP4vyWk0eT['group'] = t1ta89OgTzdG5DfA4ZEvJspWhQLc.upper()
		Kz5JHpnLGqP4vyWk0eT['title'] = LmvaeNnVjSX5I.upper()
		Kz5JHpnLGqP4vyWk0eT['country'] = kcLd7brzj6JXNFwGpVEy2eYnS3058v.upper()
		Kz5JHpnLGqP4vyWk0eT['language'] = lXsQ3v6J0tWN5VPGHkpjCmOI.upper()
		jSAYDebE2hZPsKU398vitN.append(Kz5JHpnLGqP4vyWk0eT)
		GBFbN7Xqch6uSWt += 1
	return jSAYDebE2hZPsKU398vitN,GBFbN7Xqch6uSWt,D6p5NLWIvu3jEGTU
def VVuW3Y6KPl7(LmvaeNnVjSX5I):
	LmvaeNnVjSX5I = LmvaeNnVjSX5I.replace('  ',' ').replace('  ',' ').replace('  ',' ')
	LmvaeNnVjSX5I = LmvaeNnVjSX5I.replace('||','|').replace('___',':').replace('--','-')
	LmvaeNnVjSX5I = LmvaeNnVjSX5I.replace('[[','[').replace(']]',']')
	LmvaeNnVjSX5I = LmvaeNnVjSX5I.replace('((','(').replace('))',')')
	LmvaeNnVjSX5I = LmvaeNnVjSX5I.replace('<<','<').replace('>>','>')
	LmvaeNnVjSX5I = LmvaeNnVjSX5I.strip(' ')
	return LmvaeNnVjSX5I
def Z8ScnyRQamfWC7MPuKTLEr6YdOqz(syXzE1dw6DJkv3BTbo2aerZ,jBv4U2xYQ7IMewEA31aJqpoOrD5,IQG0cV3XZxjr5u):
	dGIuAh50aHUk8PYjF9SX = {}
	for BitNvPz1mE in PIWGQhN5bMCcRy0dls: dGIuAh50aHUk8PYjF9SX[BitNvPz1mE+'_'+IQG0cV3XZxjr5u] = []
	IbqVpM2HXP98kWtfDw3A = len(syXzE1dw6DJkv3BTbo2aerZ)
	jCSi86xQAVlYrTHU4I7d = str(IbqVpM2HXP98kWtfDw3A)
	GBFbN7Xqch6uSWt = 0
	D6p5NLWIvu3jEGTU = []
	for Kz5JHpnLGqP4vyWk0eT in syXzE1dw6DJkv3BTbo2aerZ:
		if GBFbN7Xqch6uSWt%873==0:
			FFBJqkrThNeWfiaZPE5Aws9uGdp(jBv4U2xYQ7IMewEA31aJqpoOrD5,50+int(5*GBFbN7Xqch6uSWt/IbqVpM2HXP98kWtfDw3A),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(GBFbN7Xqch6uSWt)+' / '+jCSi86xQAVlYrTHU4I7d)
			if jBv4U2xYQ7IMewEA31aJqpoOrD5.iscanceled():
				jBv4U2xYQ7IMewEA31aJqpoOrD5.close()
				return None,None
		t1ta89OgTzdG5DfA4ZEvJspWhQLc,BZzGu5Dp6f3jbTW04Mxco8yE,LmvaeNnVjSX5I,kk1GKyapocQZDAz,QQUuiDcMdVx = Kz5JHpnLGqP4vyWk0eT['group'],Kz5JHpnLGqP4vyWk0eT['context'],Kz5JHpnLGqP4vyWk0eT['title'],Kz5JHpnLGqP4vyWk0eT['url'],Kz5JHpnLGqP4vyWk0eT['img']
		kcLd7brzj6JXNFwGpVEy2eYnS3058v,lXsQ3v6J0tWN5VPGHkpjCmOI,BitNvPz1mE = Kz5JHpnLGqP4vyWk0eT['country'],Kz5JHpnLGqP4vyWk0eT['language'],Kz5JHpnLGqP4vyWk0eT['type']
		qTtrmY7GydUWopAasE2 = (t1ta89OgTzdG5DfA4ZEvJspWhQLc,BZzGu5Dp6f3jbTW04Mxco8yE,LmvaeNnVjSX5I,kk1GKyapocQZDAz,QQUuiDcMdVx)
		XkY7MGlq1SQI = False
		if 'LIVE' in BitNvPz1mE:
			if 'UNKNOWN' in BitNvPz1mE: dGIuAh50aHUk8PYjF9SX['LIVE_UNKNOWN_GROUPED_'+IQG0cV3XZxjr5u].append(qTtrmY7GydUWopAasE2)
			elif 'LIVE' in BitNvPz1mE: dGIuAh50aHUk8PYjF9SX['LIVE_GROUPED_'+IQG0cV3XZxjr5u].append(qTtrmY7GydUWopAasE2)
			else: XkY7MGlq1SQI = True
			dGIuAh50aHUk8PYjF9SX['LIVE_ORIGINAL_GROUPED_'+IQG0cV3XZxjr5u].append(qTtrmY7GydUWopAasE2)
		elif 'VOD' in BitNvPz1mE:
			if 'UNKNOWN' in BitNvPz1mE: dGIuAh50aHUk8PYjF9SX['VOD_UNKNOWN_GROUPED_'+IQG0cV3XZxjr5u].append(qTtrmY7GydUWopAasE2)
			elif 'MOVIES' in BitNvPz1mE: dGIuAh50aHUk8PYjF9SX['VOD_MOVIES_GROUPED_'+IQG0cV3XZxjr5u].append(qTtrmY7GydUWopAasE2)
			elif 'SERIES' in BitNvPz1mE: dGIuAh50aHUk8PYjF9SX['VOD_SERIES_GROUPED_'+IQG0cV3XZxjr5u].append(qTtrmY7GydUWopAasE2)
			else: XkY7MGlq1SQI = True
			dGIuAh50aHUk8PYjF9SX['VOD_ORIGINAL_GROUPED_'+IQG0cV3XZxjr5u].append(qTtrmY7GydUWopAasE2)
		else: XkY7MGlq1SQI = True
		if XkY7MGlq1SQI: D6p5NLWIvu3jEGTU.append(Kz5JHpnLGqP4vyWk0eT)
		GBFbN7Xqch6uSWt += 1
	F5XnM7Nulsm = sorted(syXzE1dw6DJkv3BTbo2aerZ,reverse=False,key=lambda f3kLWlmQJcbvRG0tYqj4uigThV6s: f3kLWlmQJcbvRG0tYqj4uigThV6s['title'].lower())
	del syXzE1dw6DJkv3BTbo2aerZ
	jCSi86xQAVlYrTHU4I7d = str(IbqVpM2HXP98kWtfDw3A)
	GBFbN7Xqch6uSWt = 0
	for Kz5JHpnLGqP4vyWk0eT in F5XnM7Nulsm:
		GBFbN7Xqch6uSWt += 1
		if GBFbN7Xqch6uSWt%873==0:
			FFBJqkrThNeWfiaZPE5Aws9uGdp(jBv4U2xYQ7IMewEA31aJqpoOrD5,55+int(5*GBFbN7Xqch6uSWt/IbqVpM2HXP98kWtfDw3A),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(GBFbN7Xqch6uSWt)+' / '+jCSi86xQAVlYrTHU4I7d)
			if jBv4U2xYQ7IMewEA31aJqpoOrD5.iscanceled():
				jBv4U2xYQ7IMewEA31aJqpoOrD5.close()
				return None,None
		BitNvPz1mE = Kz5JHpnLGqP4vyWk0eT['type']
		t1ta89OgTzdG5DfA4ZEvJspWhQLc,BZzGu5Dp6f3jbTW04Mxco8yE,LmvaeNnVjSX5I,kk1GKyapocQZDAz,QQUuiDcMdVx = Kz5JHpnLGqP4vyWk0eT['group'],Kz5JHpnLGqP4vyWk0eT['context'],Kz5JHpnLGqP4vyWk0eT['title'],Kz5JHpnLGqP4vyWk0eT['url'],Kz5JHpnLGqP4vyWk0eT['img']
		kcLd7brzj6JXNFwGpVEy2eYnS3058v,lXsQ3v6J0tWN5VPGHkpjCmOI = Kz5JHpnLGqP4vyWk0eT['country'],Kz5JHpnLGqP4vyWk0eT['language']
		cAdRaVGwo2ZDfHj9gqeE = (t1ta89OgTzdG5DfA4ZEvJspWhQLc,BZzGu5Dp6f3jbTW04Mxco8yE+'_TIMESHIFT',LmvaeNnVjSX5I,kk1GKyapocQZDAz,QQUuiDcMdVx)
		qTtrmY7GydUWopAasE2 = (t1ta89OgTzdG5DfA4ZEvJspWhQLc,BZzGu5Dp6f3jbTW04Mxco8yE,LmvaeNnVjSX5I,kk1GKyapocQZDAz,QQUuiDcMdVx)
		odGJ4WXutyF = (kcLd7brzj6JXNFwGpVEy2eYnS3058v,BZzGu5Dp6f3jbTW04Mxco8yE,LmvaeNnVjSX5I,kk1GKyapocQZDAz,QQUuiDcMdVx)
		aRwmg890LxQZ7TMB1EDi5PnY = (lXsQ3v6J0tWN5VPGHkpjCmOI,BZzGu5Dp6f3jbTW04Mxco8yE,LmvaeNnVjSX5I,kk1GKyapocQZDAz,QQUuiDcMdVx)
		if 'LIVE' in BitNvPz1mE:
			if 'UNKNOWN' in BitNvPz1mE: dGIuAh50aHUk8PYjF9SX['LIVE_UNKNOWN_GROUPED_SORTED_'+IQG0cV3XZxjr5u].append(qTtrmY7GydUWopAasE2)
			else: dGIuAh50aHUk8PYjF9SX['LIVE_GROUPED_SORTED_'+IQG0cV3XZxjr5u].append(qTtrmY7GydUWopAasE2)
			if 'EPG'		in BitNvPz1mE: dGIuAh50aHUk8PYjF9SX['LIVE_EPG_GROUPED_SORTED_'+IQG0cV3XZxjr5u].append(qTtrmY7GydUWopAasE2)
			if 'ARCHIVED'	in BitNvPz1mE: dGIuAh50aHUk8PYjF9SX['LIVE_ARCHIVED_GROUPED_SORTED_'+IQG0cV3XZxjr5u].append(qTtrmY7GydUWopAasE2)
			if 'ARCHIVED'	in BitNvPz1mE: dGIuAh50aHUk8PYjF9SX['LIVE_TIMESHIFT_GROUPED_SORTED_'+IQG0cV3XZxjr5u].append(cAdRaVGwo2ZDfHj9gqeE)
			dGIuAh50aHUk8PYjF9SX['LIVE_FROM_NAME_SORTED_'+IQG0cV3XZxjr5u].append(odGJ4WXutyF)
			dGIuAh50aHUk8PYjF9SX['LIVE_FROM_GROUP_SORTED_'+IQG0cV3XZxjr5u].append(aRwmg890LxQZ7TMB1EDi5PnY)
		elif 'VOD' in BitNvPz1mE:
			if   'UNKNOWN'	in BitNvPz1mE: dGIuAh50aHUk8PYjF9SX['VOD_UNKNOWN_GROUPED_SORTED_'+IQG0cV3XZxjr5u].append(qTtrmY7GydUWopAasE2)
			elif 'MOVIES'	in BitNvPz1mE: dGIuAh50aHUk8PYjF9SX['VOD_MOVIES_GROUPED_SORTED_'+IQG0cV3XZxjr5u].append(qTtrmY7GydUWopAasE2)
			elif 'SERIES'	in BitNvPz1mE: dGIuAh50aHUk8PYjF9SX['VOD_SERIES_GROUPED_SORTED_'+IQG0cV3XZxjr5u].append(qTtrmY7GydUWopAasE2)
			dGIuAh50aHUk8PYjF9SX['VOD_FROM_NAME_SORTED_'+IQG0cV3XZxjr5u].append(odGJ4WXutyF)
			dGIuAh50aHUk8PYjF9SX['VOD_FROM_GROUP_SORTED_'+IQG0cV3XZxjr5u].append(aRwmg890LxQZ7TMB1EDi5PnY)
	return dGIuAh50aHUk8PYjF9SX,D6p5NLWIvu3jEGTU
def BKiDIq4Fm9VdujnRfG7pJyHOzs(LmvaeNnVjSX5I):
	if len(LmvaeNnVjSX5I)<3: return LmvaeNnVjSX5I,LmvaeNnVjSX5I
	HGN0Fgpl3oqaiBPjnSR4X9bLkZ,AALYi07EHlRdPXKC4VF = '',''
	KmekGJOZLgFw1prSP76BclWDsz = LmvaeNnVjSX5I
	yBGbAl1nXeoNfVpvj = LmvaeNnVjSX5I[:1]
	iIHr6qJ9kObAnpzlMRCP1uWwmU = LmvaeNnVjSX5I[1:]
	if   yBGbAl1nXeoNfVpvj=='(': AALYi07EHlRdPXKC4VF = ')'
	elif yBGbAl1nXeoNfVpvj=='[': AALYi07EHlRdPXKC4VF = ']'
	elif yBGbAl1nXeoNfVpvj=='<': AALYi07EHlRdPXKC4VF = '>'
	elif yBGbAl1nXeoNfVpvj=='|': AALYi07EHlRdPXKC4VF = '|'
	if AALYi07EHlRdPXKC4VF and (AALYi07EHlRdPXKC4VF in iIHr6qJ9kObAnpzlMRCP1uWwmU):
		wH3TqJdACmfMLIsYkutcWhigb05OS,OqM5AWlydChrUGiD = iIHr6qJ9kObAnpzlMRCP1uWwmU.split(AALYi07EHlRdPXKC4VF,1)
		HGN0Fgpl3oqaiBPjnSR4X9bLkZ = wH3TqJdACmfMLIsYkutcWhigb05OS
		KmekGJOZLgFw1prSP76BclWDsz = yBGbAl1nXeoNfVpvj+wH3TqJdACmfMLIsYkutcWhigb05OS+AALYi07EHlRdPXKC4VF+' '+OqM5AWlydChrUGiD
	elif LmvaeNnVjSX5I.count('|')>=2:
		wH3TqJdACmfMLIsYkutcWhigb05OS,OqM5AWlydChrUGiD = LmvaeNnVjSX5I.split('|',1)
		HGN0Fgpl3oqaiBPjnSR4X9bLkZ = wH3TqJdACmfMLIsYkutcWhigb05OS
		KmekGJOZLgFw1prSP76BclWDsz = wH3TqJdACmfMLIsYkutcWhigb05OS+' |'+OqM5AWlydChrUGiD
	else:
		AALYi07EHlRdPXKC4VF = GGvHJKP9LUxEk10Fw.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',LmvaeNnVjSX5I,GGvHJKP9LUxEk10Fw.DOTALL)
		if not AALYi07EHlRdPXKC4VF: AALYi07EHlRdPXKC4VF = GGvHJKP9LUxEk10Fw.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',LmvaeNnVjSX5I,GGvHJKP9LUxEk10Fw.DOTALL)
		if not AALYi07EHlRdPXKC4VF: AALYi07EHlRdPXKC4VF = GGvHJKP9LUxEk10Fw.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',LmvaeNnVjSX5I,GGvHJKP9LUxEk10Fw.DOTALL)
		if AALYi07EHlRdPXKC4VF:
			wH3TqJdACmfMLIsYkutcWhigb05OS,OqM5AWlydChrUGiD = LmvaeNnVjSX5I.split(AALYi07EHlRdPXKC4VF[0],1)
			HGN0Fgpl3oqaiBPjnSR4X9bLkZ = wH3TqJdACmfMLIsYkutcWhigb05OS
			KmekGJOZLgFw1prSP76BclWDsz = wH3TqJdACmfMLIsYkutcWhigb05OS+' '+AALYi07EHlRdPXKC4VF[0]+' '+OqM5AWlydChrUGiD
	KmekGJOZLgFw1prSP76BclWDsz = KmekGJOZLgFw1prSP76BclWDsz.replace('   ',' ').replace('  ',' ')
	HGN0Fgpl3oqaiBPjnSR4X9bLkZ = HGN0Fgpl3oqaiBPjnSR4X9bLkZ.replace('  ',' ')
	if not HGN0Fgpl3oqaiBPjnSR4X9bLkZ: HGN0Fgpl3oqaiBPjnSR4X9bLkZ = '!!__UNKNOWN__!!'
	HGN0Fgpl3oqaiBPjnSR4X9bLkZ = HGN0Fgpl3oqaiBPjnSR4X9bLkZ.strip(' ')
	KmekGJOZLgFw1prSP76BclWDsz = KmekGJOZLgFw1prSP76BclWDsz.strip(' ')
	return HGN0Fgpl3oqaiBPjnSR4X9bLkZ,KmekGJOZLgFw1prSP76BclWDsz
def Jgl0cPRtB7nb9E(Kkecj5WTsm9rwlSJu1xqQLN):
	vqNwzh36FVc = {}
	Z1ZuwAjtfnMa5Fy29Ps4NhXeUTkxRH = jHevARrF7lS.getSetting('av.m3u.useragent_'+Kkecj5WTsm9rwlSJu1xqQLN)
	if Z1ZuwAjtfnMa5Fy29Ps4NhXeUTkxRH: vqNwzh36FVc['User-Agent'] = Z1ZuwAjtfnMa5Fy29Ps4NhXeUTkxRH
	lt6VxyZ2wkK8UGnrQdYcg1ziR0NHWj = jHevARrF7lS.getSetting('av.m3u.referer_'+Kkecj5WTsm9rwlSJu1xqQLN)
	if lt6VxyZ2wkK8UGnrQdYcg1ziR0NHWj: vqNwzh36FVc['Referer'] = lt6VxyZ2wkK8UGnrQdYcg1ziR0NHWj
	return vqNwzh36FVc
def krbKaZqBTfHQ43lj9LhS1AoEM(Kkecj5WTsm9rwlSJu1xqQLN,IQG0cV3XZxjr5u):
	global jBv4U2xYQ7IMewEA31aJqpoOrD5,dGIuAh50aHUk8PYjF9SX,ZEBCb4oTwn7pa,wi3RV7dA4cJlQoBYHbpGS8vz0jC,quXzYmCniS6r8IQTc1PJGgNUheD,AFt4kHWRK9yherJ3ICVcBUsuql,eZSIDT5Nko7wO3Pf,oc5FHIJTCUMB0lwR,N2MIpFbTl6wYEr
	SMNlDK1d9EbJRoLOaIqZTp5zG72Vf = jHevARrF7lS.getSetting('av.m3u.url_'+Kkecj5WTsm9rwlSJu1xqQLN+'_'+IQG0cV3XZxjr5u)
	Z1ZuwAjtfnMa5Fy29Ps4NhXeUTkxRH = jHevARrF7lS.getSetting('av.m3u.useragent_'+Kkecj5WTsm9rwlSJu1xqQLN)
	vqNwzh36FVc = {'User-Agent':Z1ZuwAjtfnMa5Fy29Ps4NhXeUTkxRH}
	HpeJd0UFhnr86Z3TAi1tlWfGB = ERFOPQbuZhdSDy1.replace('___','_'+Kkecj5WTsm9rwlSJu1xqQLN+'_'+IQG0cV3XZxjr5u)
	if 1:
		Ax4racOvNio2fRj9wPhFyBnSeE,JCm0LkY7hn3edW,gget9fLVImGrcoT6pvqw8Qd = True,'',''
		if not Ax4racOvNio2fRj9wPhFyBnSeE:
			aHKzv76JCVnprbY8w('','','رسالة من المبرمج','فشل بسحب ملفات ـM3U . أحتمال رابط ـM3U غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـM3U الموجودة بهذا البرنامج')
			if not SMNlDK1d9EbJRoLOaIqZTp5zG72Vf: LOHZ4o9m7p6ebfTYXGIdz5PWs3q('ERROR_LINES',jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+'   No M3U URL found to download M3U files')
			else: LOHZ4o9m7p6ebfTYXGIdz5PWs3q('ERROR_LINES',jjqPWzLUBY1HpQJn0tlfVbGio(ucL0B1lWMCfAoEjG)+'   Failed to download M3U files')
			return
		aox4eiZTw3XtK = wwJEoNAiDnIZgYS(SMNlDK1d9EbJRoLOaIqZTp5zG72Vf,vqNwzh36FVc,True)
		if not aox4eiZTw3XtK: return
		open(HpeJd0UFhnr86Z3TAi1tlWfGB,'wb').write(aox4eiZTw3XtK)
	else: aox4eiZTw3XtK = open(HpeJd0UFhnr86Z3TAi1tlWfGB,'rb').read()
	if u4ChFMGf6K93tbDjJ12zi0YQsAHyP and aox4eiZTw3XtK: aox4eiZTw3XtK = aox4eiZTw3XtK.decode('utf8')
	jBv4U2xYQ7IMewEA31aJqpoOrD5 = XOL34TuqseWy2gpYfd()
	jBv4U2xYQ7IMewEA31aJqpoOrD5.create('جلب ملفات M3U جديدة','')
	FFBJqkrThNeWfiaZPE5Aws9uGdp(jBv4U2xYQ7IMewEA31aJqpoOrD5,15,'تنظيف الملف الرئيسي','')
	aox4eiZTw3XtK = aox4eiZTw3XtK.replace('"tvg-','" tvg-')
	aox4eiZTw3XtK = aox4eiZTw3XtK.replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
	aox4eiZTw3XtK = aox4eiZTw3XtK.replace('ّ','').replace('ِ','').replace('ٍ','').replace('ْ','')
	aox4eiZTw3XtK = aox4eiZTw3XtK.replace('group-title=','group=').replace('tvg-','')
	RsIBajtzmCP3,PPtlZ0Q9swcuIr41O5pGW3gJb = [],[]
	aox4eiZTw3XtK = aox4eiZTw3XtK.replace('\r','\n')
	cXQ84du5sj97FvCiOoqTwJhWk16z = GGvHJKP9LUxEk10Fw.findall('NF:(.+?)'+'#'+'EXTI',aox4eiZTw3XtK+'\n+'+'#'+'EXTINF:',GGvHJKP9LUxEk10Fw.DOTALL)
	if not cXQ84du5sj97FvCiOoqTwJhWk16z:
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q('ERROR_LINES',jjqPWzLUBY1HpQJn0tlfVbGio(ucL0B1lWMCfAoEjG)+'   Folder:'+Kkecj5WTsm9rwlSJu1xqQLN+'  Sequence:'+IQG0cV3XZxjr5u+'   No video links found in M3U file')
		aHKzv76JCVnprbY8w('','','رسالة من المبرمج','رابط ـM3U الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـM3U غير صحيح'+'\n'+'[COLOR FFFFFF00]'+'مجلد رقم '+Kkecj5WTsm9rwlSJu1xqQLN+'      رابط رقم '+IQG0cV3XZxjr5u+'[/COLOR]')
		jBv4U2xYQ7IMewEA31aJqpoOrD5.close()
		return
	gwNL4pQyxnGJH2d1thW6kuA7cOrPVK = []
	for ulk0vBZaNR in cXQ84du5sj97FvCiOoqTwJhWk16z:
		YCgyEZ3VBzTLqA = ulk0vBZaNR.lower()
		if 'adult' in YCgyEZ3VBzTLqA: continue
		if 'xxx' in YCgyEZ3VBzTLqA: continue
		gwNL4pQyxnGJH2d1thW6kuA7cOrPVK.append(ulk0vBZaNR)
	cXQ84du5sj97FvCiOoqTwJhWk16z = gwNL4pQyxnGJH2d1thW6kuA7cOrPVK
	del gwNL4pQyxnGJH2d1thW6kuA7cOrPVK
	if 'iptv-org' in SMNlDK1d9EbJRoLOaIqZTp5zG72Vf:
		gwNL4pQyxnGJH2d1thW6kuA7cOrPVK,tiIgfMlQnWPE = [],[]
		for ulk0vBZaNR in cXQ84du5sj97FvCiOoqTwJhWk16z:
			AFt4kHWRK9yherJ3ICVcBUsuql = GGvHJKP9LUxEk10Fw.findall('group="(.*?)"',ulk0vBZaNR,GGvHJKP9LUxEk10Fw.DOTALL)
			if AFt4kHWRK9yherJ3ICVcBUsuql:
				AFt4kHWRK9yherJ3ICVcBUsuql = AFt4kHWRK9yherJ3ICVcBUsuql[0]
				GPNqTAzQjo9n = AFt4kHWRK9yherJ3ICVcBUsuql.split(';')
				if 'region' in SMNlDK1d9EbJRoLOaIqZTp5zG72Vf: A0ANRvuXrVyjaO = '1_'
				elif 'category' in SMNlDK1d9EbJRoLOaIqZTp5zG72Vf: A0ANRvuXrVyjaO = '2_'
				elif 'language' in SMNlDK1d9EbJRoLOaIqZTp5zG72Vf: A0ANRvuXrVyjaO = '3_'
				elif 'country' in SMNlDK1d9EbJRoLOaIqZTp5zG72Vf: A0ANRvuXrVyjaO = '4_'
				else: A0ANRvuXrVyjaO = '5_'
				RNj7JThPnsSV2dM45gGmZwzr = ulk0vBZaNR.replace('group="'+AFt4kHWRK9yherJ3ICVcBUsuql+'"','group="'+A0ANRvuXrVyjaO+'~[COLOR FFC89008] ===== ===== ===== [/COLOR]'+'"')
				gwNL4pQyxnGJH2d1thW6kuA7cOrPVK.append(RNj7JThPnsSV2dM45gGmZwzr)
				for t1ta89OgTzdG5DfA4ZEvJspWhQLc in GPNqTAzQjo9n:
					RNj7JThPnsSV2dM45gGmZwzr = ulk0vBZaNR.replace('group="'+AFt4kHWRK9yherJ3ICVcBUsuql+'"','group="'+A0ANRvuXrVyjaO+t1ta89OgTzdG5DfA4ZEvJspWhQLc+'"')
					gwNL4pQyxnGJH2d1thW6kuA7cOrPVK.append(RNj7JThPnsSV2dM45gGmZwzr)
			else: gwNL4pQyxnGJH2d1thW6kuA7cOrPVK.append(ulk0vBZaNR)
		cXQ84du5sj97FvCiOoqTwJhWk16z = gwNL4pQyxnGJH2d1thW6kuA7cOrPVK
		del gwNL4pQyxnGJH2d1thW6kuA7cOrPVK,tiIgfMlQnWPE
	CCJnRg3qQLDPm = 1024*1024
	E8VGP0NnuWjUq = 1+len(aox4eiZTw3XtK)//CCJnRg3qQLDPm//10
	del aox4eiZTw3XtK
	gg1hLSonQGxNq5 = len(cXQ84du5sj97FvCiOoqTwJhWk16z)
	tiIgfMlQnWPE = sYD4E2xX9MWFrGC6jJbOq(cXQ84du5sj97FvCiOoqTwJhWk16z,E8VGP0NnuWjUq)
	del cXQ84du5sj97FvCiOoqTwJhWk16z
	for L4SCkrby5m8gjWwHOn0fJuhqQYvUN in range(E8VGP0NnuWjUq):
		FFBJqkrThNeWfiaZPE5Aws9uGdp(jBv4U2xYQ7IMewEA31aJqpoOrD5,35+int(5*L4SCkrby5m8gjWwHOn0fJuhqQYvUN/E8VGP0NnuWjUq),'تقطيع الملف الرئيسي','الجزء رقم:-',str(L4SCkrby5m8gjWwHOn0fJuhqQYvUN+1)+' / '+str(E8VGP0NnuWjUq))
		if jBv4U2xYQ7IMewEA31aJqpoOrD5.iscanceled():
			jBv4U2xYQ7IMewEA31aJqpoOrD5.close()
			return
		ooapJz9O8P = str(tiIgfMlQnWPE[L4SCkrby5m8gjWwHOn0fJuhqQYvUN])
		if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: ooapJz9O8P = ooapJz9O8P.encode('utf8')
		open(HpeJd0UFhnr86Z3TAi1tlWfGB+'.00'+str(L4SCkrby5m8gjWwHOn0fJuhqQYvUN),'wb').write(ooapJz9O8P)
	del tiIgfMlQnWPE,ooapJz9O8P
	KKdoAgOE08wQs3JXxFUGnVB,syXzE1dw6DJkv3BTbo2aerZ,GBFbN7Xqch6uSWt = [],[],0
	for L4SCkrby5m8gjWwHOn0fJuhqQYvUN in range(E8VGP0NnuWjUq):
		if jBv4U2xYQ7IMewEA31aJqpoOrD5.iscanceled():
			jBv4U2xYQ7IMewEA31aJqpoOrD5.close()
			return
		ooapJz9O8P = open(HpeJd0UFhnr86Z3TAi1tlWfGB+'.00'+str(L4SCkrby5m8gjWwHOn0fJuhqQYvUN),'rb').read()
		MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(1)
		try: WpgZTyqoMAPhwGiXF.remove(HpeJd0UFhnr86Z3TAi1tlWfGB+'.00'+str(L4SCkrby5m8gjWwHOn0fJuhqQYvUN))
		except: pass
		if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: ooapJz9O8P = ooapJz9O8P.decode('utf8')
		x2xFc5N4yhmPuBeI = JKw5OWktPZB('list',ooapJz9O8P)
		del ooapJz9O8P
		jSAYDebE2hZPsKU398vitN,GBFbN7Xqch6uSWt,D6p5NLWIvu3jEGTU = hEdRXpT7ClueFc24KH0f(x2xFc5N4yhmPuBeI,PPtlZ0Q9swcuIr41O5pGW3gJb,RsIBajtzmCP3,jBv4U2xYQ7IMewEA31aJqpoOrD5,gg1hLSonQGxNq5,GBFbN7Xqch6uSWt,SMNlDK1d9EbJRoLOaIqZTp5zG72Vf)
		if jBv4U2xYQ7IMewEA31aJqpoOrD5.iscanceled():
			jBv4U2xYQ7IMewEA31aJqpoOrD5.close()
			return
		if not jSAYDebE2hZPsKU398vitN:
			jBv4U2xYQ7IMewEA31aJqpoOrD5.close()
			return
		syXzE1dw6DJkv3BTbo2aerZ += jSAYDebE2hZPsKU398vitN
		KKdoAgOE08wQs3JXxFUGnVB += D6p5NLWIvu3jEGTU
	del x2xFc5N4yhmPuBeI,jSAYDebE2hZPsKU398vitN
	dGIuAh50aHUk8PYjF9SX,D6p5NLWIvu3jEGTU = Z8ScnyRQamfWC7MPuKTLEr6YdOqz(syXzE1dw6DJkv3BTbo2aerZ,jBv4U2xYQ7IMewEA31aJqpoOrD5,IQG0cV3XZxjr5u)
	if jBv4U2xYQ7IMewEA31aJqpoOrD5.iscanceled():
		jBv4U2xYQ7IMewEA31aJqpoOrD5.close()
		return
	KKdoAgOE08wQs3JXxFUGnVB += D6p5NLWIvu3jEGTU
	del syXzE1dw6DJkv3BTbo2aerZ,D6p5NLWIvu3jEGTU
	wi3RV7dA4cJlQoBYHbpGS8vz0jC,quXzYmCniS6r8IQTc1PJGgNUheD,AFt4kHWRK9yherJ3ICVcBUsuql,eZSIDT5Nko7wO3Pf,oc5FHIJTCUMB0lwR = {},{},{},0,0
	TBsKPhpSEI9z5XDumxU = list(dGIuAh50aHUk8PYjF9SX.keys())
	N2MIpFbTl6wYEr = len(TBsKPhpSEI9z5XDumxU)*3
	if 1:
		yDegLiBrqJOCHQsA87dUw0 = {}
		for Shf69xuNDp8KUm2wtsAv in TBsKPhpSEI9z5XDumxU:
			yDegLiBrqJOCHQsA87dUw0[Shf69xuNDp8KUm2wtsAv] = dM9DZS0pkxbqaf7W.Thread(target=w0qlrSeHJzIgoRdMtu2bO9shyCA7,args=(Shf69xuNDp8KUm2wtsAv,))
			yDegLiBrqJOCHQsA87dUw0[Shf69xuNDp8KUm2wtsAv].start()
		for Shf69xuNDp8KUm2wtsAv in TBsKPhpSEI9z5XDumxU:
			yDegLiBrqJOCHQsA87dUw0[Shf69xuNDp8KUm2wtsAv].join()
		if jBv4U2xYQ7IMewEA31aJqpoOrD5.iscanceled():
			jBv4U2xYQ7IMewEA31aJqpoOrD5.close()
			return
	else:
		for Shf69xuNDp8KUm2wtsAv in TBsKPhpSEI9z5XDumxU:
			w0qlrSeHJzIgoRdMtu2bO9shyCA7(Shf69xuNDp8KUm2wtsAv)
			if jBv4U2xYQ7IMewEA31aJqpoOrD5.iscanceled():
				jBv4U2xYQ7IMewEA31aJqpoOrD5.close()
				return
	cfUvix1bnVqF0C4GI6ElJjNQpd(Kkecj5WTsm9rwlSJu1xqQLN,IQG0cV3XZxjr5u,False)
	TBsKPhpSEI9z5XDumxU = list(wi3RV7dA4cJlQoBYHbpGS8vz0jC.keys())
	ZEBCb4oTwn7pa = 0
	if 1:
		yDegLiBrqJOCHQsA87dUw0 = {}
		for Shf69xuNDp8KUm2wtsAv in TBsKPhpSEI9z5XDumxU:
			yDegLiBrqJOCHQsA87dUw0[Shf69xuNDp8KUm2wtsAv] = dM9DZS0pkxbqaf7W.Thread(target=ssz2XHTtkhcEn,args=(Kkecj5WTsm9rwlSJu1xqQLN,Shf69xuNDp8KUm2wtsAv))
			yDegLiBrqJOCHQsA87dUw0[Shf69xuNDp8KUm2wtsAv].start()
		for Shf69xuNDp8KUm2wtsAv in TBsKPhpSEI9z5XDumxU:
			yDegLiBrqJOCHQsA87dUw0[Shf69xuNDp8KUm2wtsAv].join()
		if jBv4U2xYQ7IMewEA31aJqpoOrD5.iscanceled():
			jBv4U2xYQ7IMewEA31aJqpoOrD5.close()
			return
	else:
		for Shf69xuNDp8KUm2wtsAv in TBsKPhpSEI9z5XDumxU:
			ssz2XHTtkhcEn(Kkecj5WTsm9rwlSJu1xqQLN,Shf69xuNDp8KUm2wtsAv)
			if jBv4U2xYQ7IMewEA31aJqpoOrD5.iscanceled():
				jBv4U2xYQ7IMewEA31aJqpoOrD5.close()
				return
	L4SCkrby5m8gjWwHOn0fJuhqQYvUN = 0
	Ho3i0mhfTEjBWnIO91bsGAZ = len(KKdoAgOE08wQs3JXxFUGnVB)
	E3PchtfOMLAF2b8Yl7ze0 = o6vRfdb78XFQ2BnGMKLWpHC(Kkecj5WTsm9rwlSJu1xqQLN,'IGNORED')
	for fS8qLghj2I3J0amRov in KKdoAgOE08wQs3JXxFUGnVB:
		if L4SCkrby5m8gjWwHOn0fJuhqQYvUN%27==0:
			FFBJqkrThNeWfiaZPE5Aws9uGdp(jBv4U2xYQ7IMewEA31aJqpoOrD5,95+int(5*L4SCkrby5m8gjWwHOn0fJuhqQYvUN//Ho3i0mhfTEjBWnIO91bsGAZ),'تخزين المهملة','الفيديو رقم:-',str(L4SCkrby5m8gjWwHOn0fJuhqQYvUN)+' / '+str(Ho3i0mhfTEjBWnIO91bsGAZ))
			if jBv4U2xYQ7IMewEA31aJqpoOrD5.iscanceled():
				jBv4U2xYQ7IMewEA31aJqpoOrD5.close()
				return
		Tx5qRmdAsc0FP6BUSf8eQKy3(E3PchtfOMLAF2b8Yl7ze0,'IGNORED_'+IQG0cV3XZxjr5u,str(fS8qLghj2I3J0amRov),'',GOhVkMATsg4cJmfa0Enp6zSqCr)
		L4SCkrby5m8gjWwHOn0fJuhqQYvUN += 1
	Tx5qRmdAsc0FP6BUSf8eQKy3(E3PchtfOMLAF2b8Yl7ze0,'IGNORED_'+IQG0cV3XZxjr5u,'__COUNT__',str(Ho3i0mhfTEjBWnIO91bsGAZ),GOhVkMATsg4cJmfa0Enp6zSqCr)
	jBv4U2xYQ7IMewEA31aJqpoOrD5.close()
	MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(1)
	dMhIopnCqD(Kkecj5WTsm9rwlSJu1xqQLN)
	return
def w0qlrSeHJzIgoRdMtu2bO9shyCA7(Shf69xuNDp8KUm2wtsAv):
	global jBv4U2xYQ7IMewEA31aJqpoOrD5,dGIuAh50aHUk8PYjF9SX,ZEBCb4oTwn7pa,wi3RV7dA4cJlQoBYHbpGS8vz0jC,quXzYmCniS6r8IQTc1PJGgNUheD,AFt4kHWRK9yherJ3ICVcBUsuql,eZSIDT5Nko7wO3Pf,oc5FHIJTCUMB0lwR,N2MIpFbTl6wYEr
	wi3RV7dA4cJlQoBYHbpGS8vz0jC[Shf69xuNDp8KUm2wtsAv] = {}
	FuqVYjWikem7,E9eRjQrtyo = {},[]
	HxEw14lC9GR2BcuPm7vnZyfbK = len(dGIuAh50aHUk8PYjF9SX[Shf69xuNDp8KUm2wtsAv])
	wi3RV7dA4cJlQoBYHbpGS8vz0jC[Shf69xuNDp8KUm2wtsAv]['__COUNT__'] = HxEw14lC9GR2BcuPm7vnZyfbK
	if HxEw14lC9GR2BcuPm7vnZyfbK>0:
		RJSoMpOQukcwAfYErbeqa,GCAtolrM71uB5spI8ZmJ6jKQRcY,Ulu9w7q28oR,tLkRafOFJm9TbvU8A1sZMdEK72X,WAX1NvYBaK8 = zip(*dGIuAh50aHUk8PYjF9SX[Shf69xuNDp8KUm2wtsAv])
		del GCAtolrM71uB5spI8ZmJ6jKQRcY,Ulu9w7q28oR,tLkRafOFJm9TbvU8A1sZMdEK72X
		GPNqTAzQjo9n = list(set(RJSoMpOQukcwAfYErbeqa))
		for t1ta89OgTzdG5DfA4ZEvJspWhQLc in GPNqTAzQjo9n:
			FuqVYjWikem7[t1ta89OgTzdG5DfA4ZEvJspWhQLc] = ''
			wi3RV7dA4cJlQoBYHbpGS8vz0jC[Shf69xuNDp8KUm2wtsAv][t1ta89OgTzdG5DfA4ZEvJspWhQLc] = []
		FFBJqkrThNeWfiaZPE5Aws9uGdp(jBv4U2xYQ7IMewEA31aJqpoOrD5,60+int(15*oc5FHIJTCUMB0lwR//N2MIpFbTl6wYEr),'تصنيع القوائم','الجزء رقم:-',str(oc5FHIJTCUMB0lwR)+' / '+str(N2MIpFbTl6wYEr))
		if jBv4U2xYQ7IMewEA31aJqpoOrD5.iscanceled(): return
		oc5FHIJTCUMB0lwR += 1
		cNJP3i5oyAzvE2UGuq4OrZx = len(GPNqTAzQjo9n)
		del GPNqTAzQjo9n
		E9eRjQrtyo = list(set(zip(RJSoMpOQukcwAfYErbeqa,WAX1NvYBaK8)))
		del RJSoMpOQukcwAfYErbeqa,WAX1NvYBaK8
		for t1ta89OgTzdG5DfA4ZEvJspWhQLc,TF42IOaD6Gc in E9eRjQrtyo:
			if not FuqVYjWikem7[t1ta89OgTzdG5DfA4ZEvJspWhQLc] and TF42IOaD6Gc: FuqVYjWikem7[t1ta89OgTzdG5DfA4ZEvJspWhQLc] = TF42IOaD6Gc
		FFBJqkrThNeWfiaZPE5Aws9uGdp(jBv4U2xYQ7IMewEA31aJqpoOrD5,60+int(15*oc5FHIJTCUMB0lwR//N2MIpFbTl6wYEr),'تصنيع القوائم','الجزء رقم:-',str(oc5FHIJTCUMB0lwR)+' / '+str(N2MIpFbTl6wYEr))
		if jBv4U2xYQ7IMewEA31aJqpoOrD5.iscanceled(): return
		oc5FHIJTCUMB0lwR += 1
		JZgQY1UwnXDoa0r3MFz9Gp8iye5RH = list(FuqVYjWikem7.keys())
		FLm5z1wDhZyBPHdNe2GMbc8AVX7S = list(FuqVYjWikem7.values())
		del FuqVYjWikem7
		E9eRjQrtyo = list(zip(JZgQY1UwnXDoa0r3MFz9Gp8iye5RH,FLm5z1wDhZyBPHdNe2GMbc8AVX7S))
		del JZgQY1UwnXDoa0r3MFz9Gp8iye5RH,FLm5z1wDhZyBPHdNe2GMbc8AVX7S
		E9eRjQrtyo = sorted(E9eRjQrtyo)
	else: oc5FHIJTCUMB0lwR += 2
	wi3RV7dA4cJlQoBYHbpGS8vz0jC[Shf69xuNDp8KUm2wtsAv]['__GROUPS__'] = E9eRjQrtyo
	del E9eRjQrtyo
	for t1ta89OgTzdG5DfA4ZEvJspWhQLc,BZzGu5Dp6f3jbTW04Mxco8yE,LmvaeNnVjSX5I,kk1GKyapocQZDAz,QQUuiDcMdVx in dGIuAh50aHUk8PYjF9SX[Shf69xuNDp8KUm2wtsAv]:
		wi3RV7dA4cJlQoBYHbpGS8vz0jC[Shf69xuNDp8KUm2wtsAv][t1ta89OgTzdG5DfA4ZEvJspWhQLc].append((BZzGu5Dp6f3jbTW04Mxco8yE,LmvaeNnVjSX5I,kk1GKyapocQZDAz,QQUuiDcMdVx))
	FFBJqkrThNeWfiaZPE5Aws9uGdp(jBv4U2xYQ7IMewEA31aJqpoOrD5,60+int(15*oc5FHIJTCUMB0lwR//N2MIpFbTl6wYEr),'تصنيع القوائم','الجزء رقم:-',str(oc5FHIJTCUMB0lwR)+' / '+str(N2MIpFbTl6wYEr))
	if jBv4U2xYQ7IMewEA31aJqpoOrD5.iscanceled(): return
	oc5FHIJTCUMB0lwR += 1
	del dGIuAh50aHUk8PYjF9SX[Shf69xuNDp8KUm2wtsAv]
	AFt4kHWRK9yherJ3ICVcBUsuql[Shf69xuNDp8KUm2wtsAv] = list(wi3RV7dA4cJlQoBYHbpGS8vz0jC[Shf69xuNDp8KUm2wtsAv].keys())
	quXzYmCniS6r8IQTc1PJGgNUheD[Shf69xuNDp8KUm2wtsAv] = len(AFt4kHWRK9yherJ3ICVcBUsuql[Shf69xuNDp8KUm2wtsAv])
	eZSIDT5Nko7wO3Pf += quXzYmCniS6r8IQTc1PJGgNUheD[Shf69xuNDp8KUm2wtsAv]
	return
def ssz2XHTtkhcEn(Kkecj5WTsm9rwlSJu1xqQLN,Shf69xuNDp8KUm2wtsAv):
	global jBv4U2xYQ7IMewEA31aJqpoOrD5,dGIuAh50aHUk8PYjF9SX,ZEBCb4oTwn7pa,wi3RV7dA4cJlQoBYHbpGS8vz0jC,quXzYmCniS6r8IQTc1PJGgNUheD,AFt4kHWRK9yherJ3ICVcBUsuql,eZSIDT5Nko7wO3Pf,oc5FHIJTCUMB0lwR,N2MIpFbTl6wYEr
	E3PchtfOMLAF2b8Yl7ze0 = o6vRfdb78XFQ2BnGMKLWpHC(Kkecj5WTsm9rwlSJu1xqQLN,Shf69xuNDp8KUm2wtsAv)
	for GBFbN7Xqch6uSWt in range(1+quXzYmCniS6r8IQTc1PJGgNUheD[Shf69xuNDp8KUm2wtsAv]//273):
		kKHRnWAet1VxTcsYza5r2SJQGy = []
		r1rNBsZzCvApd3o08uPTI6RWVGYF = AFt4kHWRK9yherJ3ICVcBUsuql[Shf69xuNDp8KUm2wtsAv][0:273]
		for t1ta89OgTzdG5DfA4ZEvJspWhQLc in r1rNBsZzCvApd3o08uPTI6RWVGYF:
			kKHRnWAet1VxTcsYza5r2SJQGy.append(wi3RV7dA4cJlQoBYHbpGS8vz0jC[Shf69xuNDp8KUm2wtsAv][t1ta89OgTzdG5DfA4ZEvJspWhQLc])
		Tx5qRmdAsc0FP6BUSf8eQKy3(E3PchtfOMLAF2b8Yl7ze0,Shf69xuNDp8KUm2wtsAv,r1rNBsZzCvApd3o08uPTI6RWVGYF,kKHRnWAet1VxTcsYza5r2SJQGy,GOhVkMATsg4cJmfa0Enp6zSqCr,True)
		ZEBCb4oTwn7pa += len(r1rNBsZzCvApd3o08uPTI6RWVGYF)
		FFBJqkrThNeWfiaZPE5Aws9uGdp(jBv4U2xYQ7IMewEA31aJqpoOrD5,75+int(20*ZEBCb4oTwn7pa//eZSIDT5Nko7wO3Pf),'تخزين القوائم','القائمة رقم:-',str(ZEBCb4oTwn7pa)+' / '+str(eZSIDT5Nko7wO3Pf))
		if jBv4U2xYQ7IMewEA31aJqpoOrD5.iscanceled(): return
		del AFt4kHWRK9yherJ3ICVcBUsuql[Shf69xuNDp8KUm2wtsAv][0:273]
	del wi3RV7dA4cJlQoBYHbpGS8vz0jC[Shf69xuNDp8KUm2wtsAv],AFt4kHWRK9yherJ3ICVcBUsuql[Shf69xuNDp8KUm2wtsAv],quXzYmCniS6r8IQTc1PJGgNUheD[Shf69xuNDp8KUm2wtsAv]
	return
def uuMkFpUgJ3j7QqWcEoVdeL(Kkecj5WTsm9rwlSJu1xqQLN,IQG0cV3XZxjr5u,PvaGjrNKS9C5TcxLBUIl4d10bHz=True):
	bYXo3AOUF8mwIBR = 'عدد فيديوهات جميع الروابط'
	YDnUrWw1MhlmCBTIQAXFRZJvjxL2c = o6vRfdb78XFQ2BnGMKLWpHC(Kkecj5WTsm9rwlSJu1xqQLN,'LIVE_ORIGINAL_GROUPED')
	r7tqj9y5UFunYVf6vP = o6vRfdb78XFQ2BnGMKLWpHC(Kkecj5WTsm9rwlSJu1xqQLN,'VOD_ORIGINAL_GROUPED')
	if IQG0cV3XZxjr5u:
		bYXo3AOUF8mwIBR = 'عدد فيديوهات رابط '+Ri7qe1L6bhlGz3cyst4KSj[int(IQG0cV3XZxjr5u)]
		IQG0cV3XZxjr5u = '_'+IQG0cV3XZxjr5u
	Ho3i0mhfTEjBWnIO91bsGAZ = P702PlzKg5o3mELCt(YDnUrWw1MhlmCBTIQAXFRZJvjxL2c,'int','IGNORED'+IQG0cV3XZxjr5u,'__COUNT__')
	yj1ecHU4hxTVBpK2XEloIsnL07 = P702PlzKg5o3mELCt(YDnUrWw1MhlmCBTIQAXFRZJvjxL2c,'int','LIVE_ORIGINAL_GROUPED'+IQG0cV3XZxjr5u,'__COUNT__')
	hogIRmiDAYpKqPOtTXk5w = P702PlzKg5o3mELCt(r7tqj9y5UFunYVf6vP,'int','VOD_ORIGINAL_GROUPED'+IQG0cV3XZxjr5u,'__COUNT__')
	bbjctqwI8s = P702PlzKg5o3mELCt(YDnUrWw1MhlmCBTIQAXFRZJvjxL2c,'int','LIVE_GROUPED'+IQG0cV3XZxjr5u,'__COUNT__')
	tPuAjkMXEDIV = P702PlzKg5o3mELCt(YDnUrWw1MhlmCBTIQAXFRZJvjxL2c,'int','LIVE_UNKNOWN_GROUPED'+IQG0cV3XZxjr5u,'__COUNT__')
	ptH5SIkFMgT83vacWuzVdZoQ9q46sC = P702PlzKg5o3mELCt(YDnUrWw1MhlmCBTIQAXFRZJvjxL2c,'int','VOD_MOVIES_GROUPED'+IQG0cV3XZxjr5u,'__COUNT__')
	OdnTGq79gcAsu = P702PlzKg5o3mELCt(r7tqj9y5UFunYVf6vP,'int','VOD_SERIES_GROUPED'+IQG0cV3XZxjr5u,'__COUNT__')
	Guz5eQfwFyIWkbS = P702PlzKg5o3mELCt(YDnUrWw1MhlmCBTIQAXFRZJvjxL2c,'int','VOD_UNKNOWN_GROUPED'+IQG0cV3XZxjr5u,'__COUNT__')
	AFt4kHWRK9yherJ3ICVcBUsuql = P702PlzKg5o3mELCt(r7tqj9y5UFunYVf6vP,'list','VOD_SERIES_GROUPED'+IQG0cV3XZxjr5u,'__GROUPS__')
	XSNVtDRuPCHLZAgOIcGhv745wJ = []
	for t1ta89OgTzdG5DfA4ZEvJspWhQLc,QQUuiDcMdVx in AFt4kHWRK9yherJ3ICVcBUsuql:
		cTqE4JF1RhZejLXN2Vo7GQ8wlzYB0 = t1ta89OgTzdG5DfA4ZEvJspWhQLc.split('__SERIES__')[1]
		XSNVtDRuPCHLZAgOIcGhv745wJ.append(cTqE4JF1RhZejLXN2Vo7GQ8wlzYB0)
	HeyZoQ7KU9L026k4m5OnbC3XBvi = len(XSNVtDRuPCHLZAgOIcGhv745wJ)
	JYVmGQ4726BXL3M8pzrtTnUOS = int(ptH5SIkFMgT83vacWuzVdZoQ9q46sC)+int(OdnTGq79gcAsu)+int(Guz5eQfwFyIWkbS)+int(tPuAjkMXEDIV)+int(bbjctqwI8s)
	x6i8kNA5cmGFlLSQpaOjDht = ''
	x6i8kNA5cmGFlLSQpaOjDht += 'قنوات: '+str(bbjctqwI8s)
	x6i8kNA5cmGFlLSQpaOjDht += '   .   أفلام: '+str(ptH5SIkFMgT83vacWuzVdZoQ9q46sC)
	x6i8kNA5cmGFlLSQpaOjDht += '\nمسلسلات: '+str(HeyZoQ7KU9L026k4m5OnbC3XBvi)
	x6i8kNA5cmGFlLSQpaOjDht += '   .   حلقات: '+str(OdnTGq79gcAsu)
	x6i8kNA5cmGFlLSQpaOjDht += '\nقنوات مجهولة: '+str(tPuAjkMXEDIV)
	x6i8kNA5cmGFlLSQpaOjDht += '   .   فيدوهات مجهولة: '+str(Guz5eQfwFyIWkbS)
	x6i8kNA5cmGFlLSQpaOjDht += '\nمجموع القنوات: '+str(yj1ecHU4hxTVBpK2XEloIsnL07)
	x6i8kNA5cmGFlLSQpaOjDht += '   .   مجموع الفيديوهات: '+str(hogIRmiDAYpKqPOtTXk5w)
	x6i8kNA5cmGFlLSQpaOjDht += '\n\nمجموع المضافة: '+str(JYVmGQ4726BXL3M8pzrtTnUOS)
	x6i8kNA5cmGFlLSQpaOjDht += '   .   مجموع المهملة: '+str(Ho3i0mhfTEjBWnIO91bsGAZ)
	if PvaGjrNKS9C5TcxLBUIl4d10bHz: aHKzv76JCVnprbY8w('center','',bYXo3AOUF8mwIBR,x6i8kNA5cmGFlLSQpaOjDht)
	wXn0pKhqo8Iri3YfBJyFCu5x = x6i8kNA5cmGFlLSQpaOjDht.replace('\n\n','\n')
	if not IQG0cV3XZxjr5u: IQG0cV3XZxjr5u = 'All'
	else: IQG0cV3XZxjr5u = IQG0cV3XZxjr5u[1]
	LOHZ4o9m7p6ebfTYXGIdz5PWs3q('NOTICE','.  Counts of M3U videos   Folder: '+Kkecj5WTsm9rwlSJu1xqQLN+'   Sequence: '+IQG0cV3XZxjr5u+'\n'+wXn0pKhqo8Iri3YfBJyFCu5x)
	return x6i8kNA5cmGFlLSQpaOjDht
def cfUvix1bnVqF0C4GI6ElJjNQpd(Kkecj5WTsm9rwlSJu1xqQLN,IQG0cV3XZxjr5u,PvaGjrNKS9C5TcxLBUIl4d10bHz=True):
	if PvaGjrNKS9C5TcxLBUIl4d10bHz:
		yYuG6rWaR9gmSO05jlZ1woUX3 = ggi4vBsqHDArM1('center','','','مسح ملفات M3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if yYuG6rWaR9gmSO05jlZ1woUX3!=1: return
		beDxKEZgcHsQN10jXPIhGfwTvM63mt = ERFOPQbuZhdSDy1.replace('___','_'+Kkecj5WTsm9rwlSJu1xqQLN+'_'+IQG0cV3XZxjr5u)
		try: WpgZTyqoMAPhwGiXF.remove(beDxKEZgcHsQN10jXPIhGfwTvM63mt)
		except: pass
	E3PchtfOMLAF2b8Yl7ze0 = o6vRfdb78XFQ2BnGMKLWpHC(Kkecj5WTsm9rwlSJu1xqQLN,'')
	if IQG0cV3XZxjr5u:
		LhcA1ByR6ejbmi73v = []
		for gPXIrM2D50d in PIWGQhN5bMCcRy0dls:
			LhcA1ByR6ejbmi73v.append(gPXIrM2D50d+'_'+IQG0cV3XZxjr5u)
		HHg0f8U75SdzxEcbt1JN(E3PchtfOMLAF2b8Yl7ze0,'LINK_'+IQG0cV3XZxjr5u)
	else:
		LhcA1ByR6ejbmi73v = PIWGQhN5bMCcRy0dls
		HHg0f8U75SdzxEcbt1JN(E3PchtfOMLAF2b8Yl7ze0,'DUMMY')
		HHg0f8U75SdzxEcbt1JN(E3PchtfOMLAF2b8Yl7ze0,'GROUPS')
		HHg0f8U75SdzxEcbt1JN(E3PchtfOMLAF2b8Yl7ze0,'ITEMS')
		HHg0f8U75SdzxEcbt1JN(E3PchtfOMLAF2b8Yl7ze0,'SEARCH')
	HHg0f8U75SdzxEcbt1JN(UkFh2OXjuTZEaexC,'SECTIONS_M3U','SECTIONS_M3U_'+Kkecj5WTsm9rwlSJu1xqQLN)
	HHg0f8U75SdzxEcbt1JN(UkFh2OXjuTZEaexC,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	for Shf69xuNDp8KUm2wtsAv in LhcA1ByR6ejbmi73v:
		HHg0f8U75SdzxEcbt1JN(E3PchtfOMLAF2b8Yl7ze0,Shf69xuNDp8KUm2wtsAv)
	LKE5PBr2XSg0ZYlMCV(False)
	dMhIopnCqD(Kkecj5WTsm9rwlSJu1xqQLN)
	if PvaGjrNKS9C5TcxLBUIl4d10bHz: aHKzv76JCVnprbY8w('','','رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
	return
def c5X1OvfJRaklF(Kkecj5WTsm9rwlSJu1xqQLN='',PvaGjrNKS9C5TcxLBUIl4d10bHz=True):
	if Kkecj5WTsm9rwlSJu1xqQLN:
		E3PchtfOMLAF2b8Yl7ze0 = o6vRfdb78XFQ2BnGMKLWpHC(str(Kkecj5WTsm9rwlSJu1xqQLN),'DUMMY')
		KCD6TolwuY04WaLshzSpEqOFUV = P702PlzKg5o3mELCt(E3PchtfOMLAF2b8Yl7ze0,'str','DUMMY','__DUMMY__')
		if KCD6TolwuY04WaLshzSpEqOFUV: return True
	else:
		Kkecj5WTsm9rwlSJu1xqQLN = '1'
		for RVpbM5fI0UOy7du in range(1,pyq71xCY26s8hNQ+1):
			E3PchtfOMLAF2b8Yl7ze0 = o6vRfdb78XFQ2BnGMKLWpHC(str(RVpbM5fI0UOy7du),'DUMMY')
			KCD6TolwuY04WaLshzSpEqOFUV = P702PlzKg5o3mELCt(E3PchtfOMLAF2b8Yl7ze0,'str','DUMMY','__DUMMY__')
			if KCD6TolwuY04WaLshzSpEqOFUV: return True
	if PvaGjrNKS9C5TcxLBUIl4d10bHz:
		nydgr6ZlJp = 'https://iptv-org.github.io/iptv/index.region.m3u'
		K1KvB7NbefLDpFmadZRj8 = 'https://iptv-org.github.io/iptv/index.category.m3u'
		F5CG6HdxQMRD47ITO = 'https://iptv-org.github.io/iptv/index.language.m3u'
		TTO4PxZfXAbzrq9 = 'https://iptv-org.github.io/iptv/index.country.m3u'
		HtB0P1AhIJ5L = nydgr6ZlJp+'\n'+K1KvB7NbefLDpFmadZRj8+'\n'+F5CG6HdxQMRD47ITO+'\n'+TTO4PxZfXAbzrq9
		yYuG6rWaR9gmSO05jlZ1woUX3 = ggi4vBsqHDArM1('','','','رسالة من المبرمج','هذا الجزء من البرنامج يحتاج رابط فيديوهات نوعه M3U ومتوفر في الإنترنت مجانا وأيضا ممكن شراءه من الشركات المختصة . الموقع أدناه فيه روابط مجانية وهي ليست ملك المبرمج (صاحب هذا البرنامج) . ولا علاقة للمبرمج بمحتوياتها . والمبرمج لا يتحمل أي مسؤولية بسبب استخدام أي روابط مجانية أو غير مجانية\n [COLOR FFC89008]http://github.com/iptv-org/iptv[/COLOR]\nالروابط أدناه مجانية ومأخوذة من الموقع أعلاه هل تريد استخدامها\n [COLOR FFC89008]'+HtB0P1AhIJ5L+'[/COLOR]',profile='confirm_mediumfont')
		if yYuG6rWaR9gmSO05jlZ1woUX3==1:
			jHevARrF7lS.setSetting('av.m3u.url_'+str(Kkecj5WTsm9rwlSJu1xqQLN)+'_1',nydgr6ZlJp)
			jHevARrF7lS.setSetting('av.m3u.url_'+str(Kkecj5WTsm9rwlSJu1xqQLN)+'_2',K1KvB7NbefLDpFmadZRj8)
			jHevARrF7lS.setSetting('av.m3u.url_'+str(Kkecj5WTsm9rwlSJu1xqQLN)+'_3',F5CG6HdxQMRD47ITO)
			jHevARrF7lS.setSetting('av.m3u.url_'+str(Kkecj5WTsm9rwlSJu1xqQLN)+'_4',TTO4PxZfXAbzrq9)
			yYuG6rWaR9gmSO05jlZ1woUX3 = ggi4vBsqHDArM1('','','','رسالة من المبرمج','للاستفادة من روابط M3U التي أنت أضفتها للبرنامج .. أنت بحاجة إلى جلب ملفات هذه الروابط الجديدة .. هل تريد الآن جلب ملفات روابط M3U التي أنت أضفتها للبرنامج ؟!')
			if yYuG6rWaR9gmSO05jlZ1woUX3==1:
				YrMaPkgSntexB6yzTjRsZJOLD4fb = KT6H2d7qgZf9FcQpnes4hkO(Kkecj5WTsm9rwlSJu1xqQLN)
				return YrMaPkgSntexB6yzTjRsZJOLD4fb
		else:
			bYXo3AOUF8mwIBR = 'إضافة وتغيير رابط '+Ri7qe1L6bhlGz3cyst4KSj[1]+' (مجلد '+Ri7qe1L6bhlGz3cyst4KSj[int(Kkecj5WTsm9rwlSJu1xqQLN)]+')'
			yYuG6rWaR9gmSO05jlZ1woUX3 = ggi4vBsqHDArM1('','','',bYXo3AOUF8mwIBR,'لإضافة رابط M3U .. أولا أفتح قائمة M3U .. وثانيا أنقر على إضافة رابط أو اشتراك M3U .. وثالثا أنقر على جلب ملفات ـM3U \n\n هل تريد إضافة أو تغيير رابط M3U الآن ؟!')
			if yYuG6rWaR9gmSO05jlZ1woUX3==1: DTrYUCtdGu4Q90iq(Kkecj5WTsm9rwlSJu1xqQLN,'1')
	return False
def tnkSpQrOC9RugmzD2b(vyBEWaH7PSUs5dK93AMxDY,Kkecj5WTsm9rwlSJu1xqQLN='',Shf69xuNDp8KUm2wtsAv='',srYAbBnl3KhyqQzkg1IZ2p5NmPL=''):
	if not srYAbBnl3KhyqQzkg1IZ2p5NmPL: srYAbBnl3KhyqQzkg1IZ2p5NmPL = '1'
	fPlzJqILutFmRv6NYy,cFghemYEoaiSN2Iw8kpyZ6ud5XO,PvaGjrNKS9C5TcxLBUIl4d10bHz = AHhPV9MzsOwnESxWedl3J4vYm(vyBEWaH7PSUs5dK93AMxDY)
	if not c5X1OvfJRaklF(Kkecj5WTsm9rwlSJu1xqQLN,PvaGjrNKS9C5TcxLBUIl4d10bHz): return
	if not fPlzJqILutFmRv6NYy:
		fPlzJqILutFmRv6NYy = yMRXZIpKxlSkaE6iCO()
		if not fPlzJqILutFmRv6NYy: return
	pojTLO29yVgSuNmC = ['','LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not Shf69xuNDp8KUm2wtsAv:
		if not PvaGjrNKS9C5TcxLBUIl4d10bHz:
			if   '_M3U-LIVE_' in cFghemYEoaiSN2Iw8kpyZ6ud5XO: Shf69xuNDp8KUm2wtsAv = pojTLO29yVgSuNmC[1]
			elif '_M3U-MOVIES' in cFghemYEoaiSN2Iw8kpyZ6ud5XO: Shf69xuNDp8KUm2wtsAv = pojTLO29yVgSuNmC[2]
			elif '_M3U-SERIES' in cFghemYEoaiSN2Iw8kpyZ6ud5XO: Shf69xuNDp8KUm2wtsAv = pojTLO29yVgSuNmC[3]
			else: Shf69xuNDp8KUm2wtsAv = pojTLO29yVgSuNmC[0]
		else:
			eeEgZRY7sGJBKm3 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			w0g6SxLJBqDUl9cNIE52VMkR = D1DJtzviFZSrA('أختر البحث المناسب', eeEgZRY7sGJBKm3)
			if w0g6SxLJBqDUl9cNIE52VMkR==-1: return
			Shf69xuNDp8KUm2wtsAv = pojTLO29yVgSuNmC[w0g6SxLJBqDUl9cNIE52VMkR]
	fPlzJqILutFmRv6NYy = fPlzJqILutFmRv6NYy+'_NODIALOGS_'
	if Kkecj5WTsm9rwlSJu1xqQLN: nWGdsTNS8h51(fPlzJqILutFmRv6NYy,Kkecj5WTsm9rwlSJu1xqQLN,Shf69xuNDp8KUm2wtsAv,srYAbBnl3KhyqQzkg1IZ2p5NmPL)
	else:
		for Kkecj5WTsm9rwlSJu1xqQLN in range(1,pyq71xCY26s8hNQ+1):
			nWGdsTNS8h51(fPlzJqILutFmRv6NYy,str(Kkecj5WTsm9rwlSJu1xqQLN),Shf69xuNDp8KUm2wtsAv,srYAbBnl3KhyqQzkg1IZ2p5NmPL)
		D6DrJsclfY[:] = sorted(D6DrJsclfY,reverse=False,key=lambda f3kLWlmQJcbvRG0tYqj4uigThV6s: f3kLWlmQJcbvRG0tYqj4uigThV6s[1].lower())
	return
def nWGdsTNS8h51(vyBEWaH7PSUs5dK93AMxDY,Kkecj5WTsm9rwlSJu1xqQLN,Shf69xuNDp8KUm2wtsAv='',srYAbBnl3KhyqQzkg1IZ2p5NmPL=''):
	if not srYAbBnl3KhyqQzkg1IZ2p5NmPL: srYAbBnl3KhyqQzkg1IZ2p5NmPL = '1'
	fPlzJqILutFmRv6NYy,cFghemYEoaiSN2Iw8kpyZ6ud5XO,PvaGjrNKS9C5TcxLBUIl4d10bHz = AHhPV9MzsOwnESxWedl3J4vYm(vyBEWaH7PSUs5dK93AMxDY)
	if not Kkecj5WTsm9rwlSJu1xqQLN: return
	if not c5X1OvfJRaklF(Kkecj5WTsm9rwlSJu1xqQLN,PvaGjrNKS9C5TcxLBUIl4d10bHz): return
	if not fPlzJqILutFmRv6NYy:
		fPlzJqILutFmRv6NYy = yMRXZIpKxlSkaE6iCO()
		if not fPlzJqILutFmRv6NYy: return
	pojTLO29yVgSuNmC = ['','LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not Shf69xuNDp8KUm2wtsAv:
		if not PvaGjrNKS9C5TcxLBUIl4d10bHz:
			if   '_M3U-LIVE_' in cFghemYEoaiSN2Iw8kpyZ6ud5XO: Shf69xuNDp8KUm2wtsAv = pojTLO29yVgSuNmC[1]
			elif '_M3U-MOVIES' in cFghemYEoaiSN2Iw8kpyZ6ud5XO: Shf69xuNDp8KUm2wtsAv = pojTLO29yVgSuNmC[2]
			elif '_M3U-SERIES' in cFghemYEoaiSN2Iw8kpyZ6ud5XO: Shf69xuNDp8KUm2wtsAv = pojTLO29yVgSuNmC[3]
			else: Shf69xuNDp8KUm2wtsAv = pojTLO29yVgSuNmC[0]
		else:
			eeEgZRY7sGJBKm3 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			w0g6SxLJBqDUl9cNIE52VMkR = D1DJtzviFZSrA('أختر البحث المناسب', eeEgZRY7sGJBKm3)
			if w0g6SxLJBqDUl9cNIE52VMkR==-1: return
			Shf69xuNDp8KUm2wtsAv = pojTLO29yVgSuNmC[w0g6SxLJBqDUl9cNIE52VMkR]
	V3SWZ5lIdJHeUzvstKq9p = fPlzJqILutFmRv6NYy.lower()
	E3PchtfOMLAF2b8Yl7ze0 = o6vRfdb78XFQ2BnGMKLWpHC(Kkecj5WTsm9rwlSJu1xqQLN,'SEARCH')
	p8lwCLKmTWr = P702PlzKg5o3mELCt(E3PchtfOMLAF2b8Yl7ze0,'list','SEARCH',(Shf69xuNDp8KUm2wtsAv,V3SWZ5lIdJHeUzvstKq9p))
	if not p8lwCLKmTWr:
		UISVqRCl0nfv9XGF4AbkpPZauYMLxh,iJ72H4l9aXGhw = [],[]
		if not Shf69xuNDp8KUm2wtsAv: dzCSlY2ALbec = [1,2,3,4,5]
		else: dzCSlY2ALbec = [pojTLO29yVgSuNmC.index(Shf69xuNDp8KUm2wtsAv)]
		for L4SCkrby5m8gjWwHOn0fJuhqQYvUN in dzCSlY2ALbec:
			if L4SCkrby5m8gjWwHOn0fJuhqQYvUN!=3:
				jSAYDebE2hZPsKU398vitN = P702PlzKg5o3mELCt(E3PchtfOMLAF2b8Yl7ze0,'dict',pojTLO29yVgSuNmC[L4SCkrby5m8gjWwHOn0fJuhqQYvUN])
				del jSAYDebE2hZPsKU398vitN['__COUNT__']
				del jSAYDebE2hZPsKU398vitN['__GROUPS__']
				del jSAYDebE2hZPsKU398vitN['__SEQUENCED_COLUMNS__']
				AFt4kHWRK9yherJ3ICVcBUsuql = list(jSAYDebE2hZPsKU398vitN.keys())
				for t1ta89OgTzdG5DfA4ZEvJspWhQLc in AFt4kHWRK9yherJ3ICVcBUsuql:
					for BZzGu5Dp6f3jbTW04Mxco8yE,LmvaeNnVjSX5I,kk1GKyapocQZDAz,QQUuiDcMdVx in jSAYDebE2hZPsKU398vitN[t1ta89OgTzdG5DfA4ZEvJspWhQLc]:
						if V3SWZ5lIdJHeUzvstKq9p in LmvaeNnVjSX5I.lower(): iJ72H4l9aXGhw.append((LmvaeNnVjSX5I,kk1GKyapocQZDAz,QQUuiDcMdVx))
					del jSAYDebE2hZPsKU398vitN[t1ta89OgTzdG5DfA4ZEvJspWhQLc]
				del jSAYDebE2hZPsKU398vitN
			else: AFt4kHWRK9yherJ3ICVcBUsuql = P702PlzKg5o3mELCt(E3PchtfOMLAF2b8Yl7ze0,'list',pojTLO29yVgSuNmC[L4SCkrby5m8gjWwHOn0fJuhqQYvUN],'__GROUPS__')
			for t1ta89OgTzdG5DfA4ZEvJspWhQLc in AFt4kHWRK9yherJ3ICVcBUsuql:
				try: t1ta89OgTzdG5DfA4ZEvJspWhQLc,QQUuiDcMdVx = t1ta89OgTzdG5DfA4ZEvJspWhQLc
				except: QQUuiDcMdVx = ''
				if V3SWZ5lIdJHeUzvstKq9p in t1ta89OgTzdG5DfA4ZEvJspWhQLc.lower():
					if L4SCkrby5m8gjWwHOn0fJuhqQYvUN!=3: mLUzIhdwc0y5F7i = t1ta89OgTzdG5DfA4ZEvJspWhQLc
					else:
						NdBtKhvMnXG,qmEzwpMoNZ = t1ta89OgTzdG5DfA4ZEvJspWhQLc.split('__SERIES__')
						if V3SWZ5lIdJHeUzvstKq9p in NdBtKhvMnXG.lower(): mLUzIhdwc0y5F7i = NdBtKhvMnXG
						else: mLUzIhdwc0y5F7i = qmEzwpMoNZ
					UISVqRCl0nfv9XGF4AbkpPZauYMLxh.append((t1ta89OgTzdG5DfA4ZEvJspWhQLc,mLUzIhdwc0y5F7i,pojTLO29yVgSuNmC[L4SCkrby5m8gjWwHOn0fJuhqQYvUN],QQUuiDcMdVx))
			del AFt4kHWRK9yherJ3ICVcBUsuql
		UISVqRCl0nfv9XGF4AbkpPZauYMLxh = set(UISVqRCl0nfv9XGF4AbkpPZauYMLxh)
		iJ72H4l9aXGhw = set(iJ72H4l9aXGhw)
		UISVqRCl0nfv9XGF4AbkpPZauYMLxh = sorted(UISVqRCl0nfv9XGF4AbkpPZauYMLxh,reverse=False,key=lambda f3kLWlmQJcbvRG0tYqj4uigThV6s: f3kLWlmQJcbvRG0tYqj4uigThV6s[1])
		iJ72H4l9aXGhw = sorted(iJ72H4l9aXGhw,reverse=False,key=lambda f3kLWlmQJcbvRG0tYqj4uigThV6s: f3kLWlmQJcbvRG0tYqj4uigThV6s[0])
		Tx5qRmdAsc0FP6BUSf8eQKy3(E3PchtfOMLAF2b8Yl7ze0,'SEARCH',(Shf69xuNDp8KUm2wtsAv,V3SWZ5lIdJHeUzvstKq9p),(UISVqRCl0nfv9XGF4AbkpPZauYMLxh,iJ72H4l9aXGhw),GOhVkMATsg4cJmfa0Enp6zSqCr)
	else: UISVqRCl0nfv9XGF4AbkpPZauYMLxh,iJ72H4l9aXGhw = p8lwCLKmTWr
	AFt4kHWRK9yherJ3ICVcBUsuql = len(UISVqRCl0nfv9XGF4AbkpPZauYMLxh)
	wPtXBA1rsx3Lv0foF89UjbmE = len(iJ72H4l9aXGhw)
	zdu6VAyNEi5IL1 = int(srYAbBnl3KhyqQzkg1IZ2p5NmPL)
	YmTy7PVvhEU4d = max(0,(zdu6VAyNEi5IL1-1)*100)
	T8S5y2XxNm = max(0,zdu6VAyNEi5IL1*100)
	stnZYc9kdugFrPQp = max(0,YmTy7PVvhEU4d-AFt4kHWRK9yherJ3ICVcBUsuql)
	h8edH16AKtWui054Dj7nJ = max(0,T8S5y2XxNm-AFt4kHWRK9yherJ3ICVcBUsuql)
	for t1ta89OgTzdG5DfA4ZEvJspWhQLc,mLUzIhdwc0y5F7i,IaH83DjALsrcqleug90CSo4NyGd,QQUuiDcMdVx in UISVqRCl0nfv9XGF4AbkpPZauYMLxh[YmTy7PVvhEU4d:T8S5y2XxNm]:
		cd0aGwCPExbFU5pYNu8r('folder',XgvWSQ6o5hzlux8+mLUzIhdwc0y5F7i,IaH83DjALsrcqleug90CSo4NyGd,714,QQUuiDcMdVx,'1',t1ta89OgTzdG5DfA4ZEvJspWhQLc,'',{'folder':Kkecj5WTsm9rwlSJu1xqQLN})
	del UISVqRCl0nfv9XGF4AbkpPZauYMLxh
	for LmvaeNnVjSX5I,kk1GKyapocQZDAz,QQUuiDcMdVx in iJ72H4l9aXGhw[stnZYc9kdugFrPQp:h8edH16AKtWui054Dj7nJ]:
		pZbaYl8eABT7u9mXSQfxPhq = dd8rHcveo7O15hT3MSR(kk1GKyapocQZDAz)
		QTcZbyNIfxeU84vs5LBophFmqMAn6 = 'live'
		if '.mkv' in pZbaYl8eABT7u9mXSQfxPhq or 'VOD' in Shf69xuNDp8KUm2wtsAv: QTcZbyNIfxeU84vs5LBophFmqMAn6 = 'video'
		cd0aGwCPExbFU5pYNu8r(QTcZbyNIfxeU84vs5LBophFmqMAn6,XgvWSQ6o5hzlux8+LmvaeNnVjSX5I,kk1GKyapocQZDAz,715,QQUuiDcMdVx,'','','',{'folder':Kkecj5WTsm9rwlSJu1xqQLN})
	del iJ72H4l9aXGhw
	Ozfhb9uBAL7lG3qU6ri(Kkecj5WTsm9rwlSJu1xqQLN,srYAbBnl3KhyqQzkg1IZ2p5NmPL,Shf69xuNDp8KUm2wtsAv,719,AFt4kHWRK9yherJ3ICVcBUsuql+wPtXBA1rsx3Lv0foF89UjbmE,fPlzJqILutFmRv6NYy+'_NODIALOGS_')
	return
def Ozfhb9uBAL7lG3qU6ri(Kkecj5WTsm9rwlSJu1xqQLN,srYAbBnl3KhyqQzkg1IZ2p5NmPL,Shf69xuNDp8KUm2wtsAv,VRnfEFmJzUrSljM8,JYVmGQ4726BXL3M8pzrtTnUOS,MMupPCxqkenwt6FlsbRILV37EAmB):
	if not srYAbBnl3KhyqQzkg1IZ2p5NmPL: srYAbBnl3KhyqQzkg1IZ2p5NmPL = '1'
	if srYAbBnl3KhyqQzkg1IZ2p5NmPL!='1': cd0aGwCPExbFU5pYNu8r('folder',XgvWSQ6o5hzlux8+'صفحة '+str(1),Shf69xuNDp8KUm2wtsAv,VRnfEFmJzUrSljM8,'',str(1),MMupPCxqkenwt6FlsbRILV37EAmB,'',{'folder':Kkecj5WTsm9rwlSJu1xqQLN})
	if not JYVmGQ4726BXL3M8pzrtTnUOS: JYVmGQ4726BXL3M8pzrtTnUOS = 0
	yHUCJ05afNYSsn1pWDj = int(JYVmGQ4726BXL3M8pzrtTnUOS/100)+1
	for zdu6VAyNEi5IL1 in range(2,yHUCJ05afNYSsn1pWDj):
		HzNlJqsC0TEhRe = (zdu6VAyNEi5IL1%10==0 or int(srYAbBnl3KhyqQzkg1IZ2p5NmPL)-4<zdu6VAyNEi5IL1<int(srYAbBnl3KhyqQzkg1IZ2p5NmPL)+4)
		TTlv4F7o0aSewOWCUp = (HzNlJqsC0TEhRe and int(srYAbBnl3KhyqQzkg1IZ2p5NmPL)-40<zdu6VAyNEi5IL1<int(srYAbBnl3KhyqQzkg1IZ2p5NmPL)+40)
		if str(zdu6VAyNEi5IL1)!=srYAbBnl3KhyqQzkg1IZ2p5NmPL and (zdu6VAyNEi5IL1%100==0 or TTlv4F7o0aSewOWCUp):
			cd0aGwCPExbFU5pYNu8r('folder',XgvWSQ6o5hzlux8+'صفحة '+str(zdu6VAyNEi5IL1),Shf69xuNDp8KUm2wtsAv,VRnfEFmJzUrSljM8,'',str(zdu6VAyNEi5IL1),MMupPCxqkenwt6FlsbRILV37EAmB,'',{'folder':Kkecj5WTsm9rwlSJu1xqQLN})
	if str(yHUCJ05afNYSsn1pWDj)!=srYAbBnl3KhyqQzkg1IZ2p5NmPL: cd0aGwCPExbFU5pYNu8r('folder',XgvWSQ6o5hzlux8+'أخر صفحة '+str(yHUCJ05afNYSsn1pWDj),Shf69xuNDp8KUm2wtsAv,VRnfEFmJzUrSljM8,'',str(yHUCJ05afNYSsn1pWDj),MMupPCxqkenwt6FlsbRILV37EAmB,'',{'folder':Kkecj5WTsm9rwlSJu1xqQLN})
	return
def o6vRfdb78XFQ2BnGMKLWpHC(Kkecj5WTsm9rwlSJu1xqQLN,Shf69xuNDp8KUm2wtsAv):
	E3PchtfOMLAF2b8Yl7ze0 = Uc2C9tgfhvOQxu.replace('___','_'+Kkecj5WTsm9rwlSJu1xqQLN)
	return E3PchtfOMLAF2b8Yl7ze0
def KT6H2d7qgZf9FcQpnes4hkO(Kkecj5WTsm9rwlSJu1xqQLN):
	E3PchtfOMLAF2b8Yl7ze0 = o6vRfdb78XFQ2BnGMKLWpHC(Kkecj5WTsm9rwlSJu1xqQLN,'')
	yYuG6rWaR9gmSO05jlZ1woUX3 = ggi4vBsqHDArM1('center','','','رسالة من المبرمج','جلب ملفات M3U جديدة قد تحتاج عدة دقائق .. هل تريد أن تجلب الملفات الآن ؟!')
	if yYuG6rWaR9gmSO05jlZ1woUX3!=1: return False
	WNPb7YqE0hQOvwl2c(Kkecj5WTsm9rwlSJu1xqQLN,False)
	VizFoSElsOjqt2BRh3p = [0]
	for akVPDzJGgWi4vK3jNt0eCsuLUm9cZF in range(1,YY1DZ5qkNn+1):
		jLtSeVhncqHJ8p7m3W1B = jHevARrF7lS.getSetting('av.m3u.url_'+Kkecj5WTsm9rwlSJu1xqQLN+'_'+str(akVPDzJGgWi4vK3jNt0eCsuLUm9cZF))
		if jLtSeVhncqHJ8p7m3W1B: krbKaZqBTfHQ43lj9LhS1AoEM(Kkecj5WTsm9rwlSJu1xqQLN,str(akVPDzJGgWi4vK3jNt0eCsuLUm9cZF))
		VizFoSElsOjqt2BRh3p.append(0)
	for Shf69xuNDp8KUm2wtsAv in PIWGQhN5bMCcRy0dls:
		Cx5Y0m2N6H71oO,WWFM9TCZyhUQEgzo1YsOnAft6,extgL2Np6u8ziHGQ7rnoS,k1OK6LG4qn5BgMT2cmQhACW,FuqVYjWikem7 = 0,{},[],[],[]
		for akVPDzJGgWi4vK3jNt0eCsuLUm9cZF in range(1,YY1DZ5qkNn+1):
			IaH83DjALsrcqleug90CSo4NyGd = Shf69xuNDp8KUm2wtsAv+'_'+str(akVPDzJGgWi4vK3jNt0eCsuLUm9cZF)
			dGIuAh50aHUk8PYjF9SX = P702PlzKg5o3mELCt(E3PchtfOMLAF2b8Yl7ze0,'dict',IaH83DjALsrcqleug90CSo4NyGd)
			try:
				WglVtcZXk0 = dGIuAh50aHUk8PYjF9SX['__GROUPS__']
				WLM259V3hkGyifQBAcnS = dGIuAh50aHUk8PYjF9SX['__COUNT__']
			except: WglVtcZXk0,WLM259V3hkGyifQBAcnS = [],'0'
			for gFs2vrSE1ZIU4CnoNRP3huzKwYJd in WglVtcZXk0:
				t1ta89OgTzdG5DfA4ZEvJspWhQLc,TF42IOaD6Gc = gFs2vrSE1ZIU4CnoNRP3huzKwYJd
				jSAYDebE2hZPsKU398vitN = dGIuAh50aHUk8PYjF9SX[t1ta89OgTzdG5DfA4ZEvJspWhQLc]
				if t1ta89OgTzdG5DfA4ZEvJspWhQLc not in k1OK6LG4qn5BgMT2cmQhACW:
					k1OK6LG4qn5BgMT2cmQhACW.append(t1ta89OgTzdG5DfA4ZEvJspWhQLc)
					FuqVYjWikem7.append(gFs2vrSE1ZIU4CnoNRP3huzKwYJd)
					WWFM9TCZyhUQEgzo1YsOnAft6[t1ta89OgTzdG5DfA4ZEvJspWhQLc] = []
				WWFM9TCZyhUQEgzo1YsOnAft6[t1ta89OgTzdG5DfA4ZEvJspWhQLc] += jSAYDebE2hZPsKU398vitN
			HHg0f8U75SdzxEcbt1JN(E3PchtfOMLAF2b8Yl7ze0,IaH83DjALsrcqleug90CSo4NyGd)
			Tx5qRmdAsc0FP6BUSf8eQKy3(E3PchtfOMLAF2b8Yl7ze0,IaH83DjALsrcqleug90CSo4NyGd,'__COUNT__',WLM259V3hkGyifQBAcnS,GOhVkMATsg4cJmfa0Enp6zSqCr)
			VizFoSElsOjqt2BRh3p[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF] += int(WLM259V3hkGyifQBAcnS)
		for t1ta89OgTzdG5DfA4ZEvJspWhQLc in k1OK6LG4qn5BgMT2cmQhACW:
			jSAYDebE2hZPsKU398vitN = list(set(WWFM9TCZyhUQEgzo1YsOnAft6[t1ta89OgTzdG5DfA4ZEvJspWhQLc]))
			if 'SORTED' in Shf69xuNDp8KUm2wtsAv: jSAYDebE2hZPsKU398vitN = sorted(jSAYDebE2hZPsKU398vitN,reverse=False,key=lambda key: key[1].lower())
			Cx5Y0m2N6H71oO += len(jSAYDebE2hZPsKU398vitN)
			extgL2Np6u8ziHGQ7rnoS.append(jSAYDebE2hZPsKU398vitN)
		Tx5qRmdAsc0FP6BUSf8eQKy3(E3PchtfOMLAF2b8Yl7ze0,Shf69xuNDp8KUm2wtsAv,'__COUNT__',str(Cx5Y0m2N6H71oO),GOhVkMATsg4cJmfa0Enp6zSqCr)
		Tx5qRmdAsc0FP6BUSf8eQKy3(E3PchtfOMLAF2b8Yl7ze0,Shf69xuNDp8KUm2wtsAv,'__GROUPS__',FuqVYjWikem7,GOhVkMATsg4cJmfa0Enp6zSqCr)
		Tx5qRmdAsc0FP6BUSf8eQKy3(E3PchtfOMLAF2b8Yl7ze0,Shf69xuNDp8KUm2wtsAv,k1OK6LG4qn5BgMT2cmQhACW,extgL2Np6u8ziHGQ7rnoS,GOhVkMATsg4cJmfa0Enp6zSqCr,True)
	PoZfcqFVKg659AiEtmy = False
	for akVPDzJGgWi4vK3jNt0eCsuLUm9cZF in range(1,YY1DZ5qkNn+1):
		if int(VizFoSElsOjqt2BRh3p[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF])>0:
			jLtSeVhncqHJ8p7m3W1B = jHevARrF7lS.getSetting('av.m3u.url_'+Kkecj5WTsm9rwlSJu1xqQLN+'_'+str(akVPDzJGgWi4vK3jNt0eCsuLUm9cZF))
			Tx5qRmdAsc0FP6BUSf8eQKy3(E3PchtfOMLAF2b8Yl7ze0,'LINK_'+str(akVPDzJGgWi4vK3jNt0eCsuLUm9cZF),'__LINK__',jLtSeVhncqHJ8p7m3W1B,GOhVkMATsg4cJmfa0Enp6zSqCr)
			PoZfcqFVKg659AiEtmy = True
	Tx5qRmdAsc0FP6BUSf8eQKy3(E3PchtfOMLAF2b8Yl7ze0,'DUMMY','__DUMMY__','DUMMY',GOhVkMATsg4cJmfa0Enp6zSqCr)
	if not PoZfcqFVKg659AiEtmy:
		aHKzv76JCVnprbY8w('','','رسالة من المبرمج','فشل بسحب ملفات M3U .. أحتمال روابط M3U التي أنت أضفتها للبرنامج غير صحيحة .. علما أن هذه الخدمة تحتاج منك أن تضيف الرابط بنفسك للبرنامج باستخدام قائمة M3U الموجودة في هذا البرنامج')
		return False
	aHKzv76JCVnprbY8w('','','رسالة من المبرمج','تم جلب ملفات M3U جديدة')
	uorZ0e1B9Ty3AWhqnmCRbLH(Kkecj5WTsm9rwlSJu1xqQLN)
	cEZpW924rqNYm5.executebuiltin('Container.Refresh')
	return True
def uorZ0e1B9Ty3AWhqnmCRbLH(Kkecj5WTsm9rwlSJu1xqQLN):
	E3PchtfOMLAF2b8Yl7ze0 = o6vRfdb78XFQ2BnGMKLWpHC(Kkecj5WTsm9rwlSJu1xqQLN,'')
	if not c5X1OvfJRaklF(Kkecj5WTsm9rwlSJu1xqQLN,True): return
	for akVPDzJGgWi4vK3jNt0eCsuLUm9cZF in range(1,YY1DZ5qkNn+1):
		jLtSeVhncqHJ8p7m3W1B = P702PlzKg5o3mELCt(E3PchtfOMLAF2b8Yl7ze0,'str','LINK_'+str(akVPDzJGgWi4vK3jNt0eCsuLUm9cZF),'__LINK__')
		if jLtSeVhncqHJ8p7m3W1B: x6i8kNA5cmGFlLSQpaOjDht = uuMkFpUgJ3j7QqWcEoVdeL(Kkecj5WTsm9rwlSJu1xqQLN,str(akVPDzJGgWi4vK3jNt0eCsuLUm9cZF))
	uuMkFpUgJ3j7QqWcEoVdeL(Kkecj5WTsm9rwlSJu1xqQLN,'')
	return
def WNPb7YqE0hQOvwl2c(Kkecj5WTsm9rwlSJu1xqQLN,PvaGjrNKS9C5TcxLBUIl4d10bHz):
	if PvaGjrNKS9C5TcxLBUIl4d10bHz:
		yYuG6rWaR9gmSO05jlZ1woUX3 = ggi4vBsqHDArM1('center','','','مسح ملفات ـM3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if yYuG6rWaR9gmSO05jlZ1woUX3!=1: return
	E3PchtfOMLAF2b8Yl7ze0 = o6vRfdb78XFQ2BnGMKLWpHC(Kkecj5WTsm9rwlSJu1xqQLN,'')
	try: WpgZTyqoMAPhwGiXF.remove(E3PchtfOMLAF2b8Yl7ze0)
	except: pass
	for akVPDzJGgWi4vK3jNt0eCsuLUm9cZF in range(1,YY1DZ5qkNn+1):
		z4zpsIWKUVTxqe2NY9H1OJD7Xgb = ERFOPQbuZhdSDy1.replace('___','_'+Kkecj5WTsm9rwlSJu1xqQLN+'_'+str(akVPDzJGgWi4vK3jNt0eCsuLUm9cZF))
		dFrJXiBL6lUu15m = WpgZTyqoMAPhwGiXF.path.join(JXUQZHLxEgTFbrRC7n9,z4zpsIWKUVTxqe2NY9H1OJD7Xgb)
		try: WpgZTyqoMAPhwGiXF.remove(dFrJXiBL6lUu15m)
		except: pass
	HHg0f8U75SdzxEcbt1JN(UkFh2OXjuTZEaexC,'SECTIONS_M3U','SECTIONS_M3U_'+Kkecj5WTsm9rwlSJu1xqQLN)
	HHg0f8U75SdzxEcbt1JN(UkFh2OXjuTZEaexC,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	if PvaGjrNKS9C5TcxLBUIl4d10bHz:
		aHKzv76JCVnprbY8w('','','رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
		cEZpW924rqNYm5.executebuiltin('Container.Refresh')
	return
def dMhIopnCqD(Kkecj5WTsm9rwlSJu1xqQLN):
	nxshVUfjPCBbRmTGNZc = jHevARrF7lS.getSetting('av.language.provider')
	FXe97l2bPY6uKBySxG1 = jHevARrF7lS.getSetting('av.language.code')
	HHg0f8U75SdzxEcbt1JN(UkFh2OXjuTZEaexC,'MENUS_CACHE_'+nxshVUfjPCBbRmTGNZc+'_'+FXe97l2bPY6uKBySxG1,'%_MU'+Kkecj5WTsm9rwlSJu1xqQLN+'_%')
	return
m0tYFQ8iqn9pB = {
		 'AF':'Afghanistan'
		,'AL':'Albania'
		,'DZ':'Algeria'
		,'AS':'American Samoa'
		,'AD':'Andorra'
		,'AO':'Angola'
		,'AI':'Anguilla'
		,'AQ':'Antarctica'
		,'AG':'Antigua and Barbuda'
		,'AR':'Argentina'
		,'AM':'Armenia'
		,'AW':'Aruba'
		,'AU':'Australia'
		,'AT':'Austria'
		,'AZ':'Azerbaijan'
		,'BS':'Bahamas'
		,'BH':'Bahrain'
		,'BD':'Bangladesh'
		,'BB':'Barbados'
		,'BY':'Belarus'
		,'BE':'Belgium'
		,'BZ':'Belize'
		,'BJ':'Benin'
		,'BM':'Bermuda'
		,'BT':'Bhutan'
		,'BO':'Bolivia'
		,'BQ':'Bonaire'
		,'BA':'Bosnia and Herzegovina'
		,'BW':'Botswana'
		,'BV':'Bouvet Island'
		,'BR':'Brazil'
		,'IO':'British Indian Ocean Territory'
		,'VG':'British Virgin Islands'
		,'BN':'Brunei'
		,'BG':'Bulgaria'
		,'BF':'Burkina Faso'
		,'BI':'Burundi'
		,'KH':'Cambodia'
		,'CM':'Cameroon'
		,'CA':'Canada'
		,'CV':'Cape Verde'
		,'KY':'Cayman Islands'
		,'CF':'Central African Republic'
		,'TD':'Chad'
		,'CL':'Chile'
		,'CN':'China'
		,'CX':'Christmas Island'
		,'CC':'Cocos (Keeling) Islands'
		,'CO':'Colombia'
		,'KM':'Comoros'
		,'CK':'Cook Islands'
		,'CR':'Costa Rica'
		,'HR':'Croatia'
		,'CU':'Cuba'
		,'CW':'Curacao'
		,'CY':'Cyprus'
		,'CZ':'Czech Republic'
		,'CD':'Democratic Republic of the Congo'
		,'DK':'Denmark'
		,'DJ':'Djibouti'
		,'DM':'Dominica'
		,'DO':'Dominican Republic'
		,'TL':'East Timor'
		,'EC':'Ecuador'
		,'EG':'Egypt'
		,'SV':'El Salvador'
		,'GQ':'Equatorial Guinea'
		,'ER':'Eritrea'
		,'EE':'Estonia'
		,'ET':'Ethiopia'
		,'FK':'Falkland Islands'
		,'FO':'Faroe Islands'
		,'FJ':'Fiji'
		,'FI':'Finland'
		,'FR':'France'
		,'GF':'French Guiana'
		,'PF':'French Polynesia'
		,'TF':'French Southern Territories'
		,'GA':'Gabon'
		,'GM':'Gambia'
		,'GE':'Georgia'
		,'DE':'Germany'
		,'GH':'Ghana'
		,'GI':'Gibraltar'
		,'GR':'Greece'
		,'GL':'Greenland'
		,'GD':'Grenada'
		,'GP':'Guadeloupe'
		,'GU':'Guam'
		,'GT':'Guatemala'
		,'GG':'Guernsey'
		,'GN':'Guinea'
		,'GW':'Guinea-Bissau'
		,'GY':'Guyana'
		,'HT':'Haiti'
		,'HM':'Heard Island and McDonald Islands'
		,'HN':'Honduras'
		,'HK':'Hong Kong'
		,'HU':'Hungary'
		,'IS':'Iceland'
		,'IN':'India'
		,'ID':'Indonesia'
		,'IR':'Iran'
		,'IQ':'Iraq'
		,'IE':'Ireland'
		,'IM':'Isle of Man'
		,'IL':'Israel'
		,'IT':'Italy'
		,'CI':'Ivory Coast'
		,'JM':'Jamaica'
		,'JP':'Japan'
		,'JE':'Jersey'
		,'JO':'Jordan'
		,'KZ':'Kazakhstan'
		,'KE':'Kenya'
		,'KI':'Kiribati'
		,'XK':'Kosovo'
		,'KW':'Kuwait'
		,'KG':'Kyrgyzstan'
		,'LA':'Laos'
		,'LV':'Latvia'
		,'LB':'Lebanon'
		,'LS':'Lesotho'
		,'LR':'Liberia'
		,'LY':'Libya'
		,'LI':'Liechtenstein'
		,'LT':'Lithuania'
		,'LU':'Luxembourg'
		,'MO':'Macao'
		,'MG':'Madagascar'
		,'MW':'Malawi'
		,'MY':'Malaysia'
		,'MV':'Maldives'
		,'ML':'Mali'
		,'MT':'Malta'
		,'MH':'Marshall Islands'
		,'MQ':'Martinique'
		,'MR':'Mauritania'
		,'MU':'Mauritius'
		,'YT':'Mayotte'
		,'MX':'Mexico'
		,'FM':'Micronesia'
		,'MD':'Moldova'
		,'MC':'Monaco'
		,'MN':'Mongolia'
		,'ME':'Montenegro'
		,'MS':'Montserrat'
		,'MA':'Morocco'
		,'MZ':'Mozambique'
		,'MM':'Myanmar (Burma)'
		,'NA':'Namibia'
		,'NR':'Nauru'
		,'NP':'Nepal'
		,'NL':'Netherlands'
		,'NC':'New Caledonia'
		,'NZ':'New Zealand'
		,'NI':'Nicaragua'
		,'NE':'Niger'
		,'NG':'Nigeria'
		,'NU':'Niue'
		,'NF':'Norfolk Island'
		,'KP':'North Korea'
		,'MK':'North Macedonia'
		,'MP':'Northern Mariana Islands'
		,'NO':'Norway'
		,'OM':'Oman'
		,'PK':'Pakistan'
		,'PW':'Palau'
		,'PS':'Palestine'
		,'PA':'Panama'
		,'PG':'Papua New Guinea'
		,'PY':'Paraguay'
		,'PE':'Peru'
		,'PH':'Philippines'
		,'PN':'Pitcairn Islands'
		,'PL':'Poland'
		,'PT':'Portugal'
		,'PR':'Puerto Rico'
		,'QA':'Qatar'
		,'CG':'Republic of the Congo'
		,'RO':'Romania'
		,'RU':'Russia'
		,'RW':'Rwanda'
		,'RE':'Réunion'
		,'BL':'Saint Barthélemy'
		,'SH':'Saint Helena'
		,'KN':'Saint Kitts and Nevis'
		,'LC':'Saint Lucia'
		,'MF':'Saint Martin'
		,'PM':'Saint Pierre and Miquelon'
		,'VC':'Saint Vincent and the Grenadines'
		,'WS':'Samoa'
		,'SM':'San Marino'
		,'SA':'Saudi Arabia'
		,'SN':'Senegal'
		,'RS':'Serbia'
		,'SC':'Seychelles'
		,'SL':'Sierra Leone'
		,'SG':'Singapore'
		,'SX':'Sint Maarten'
		,'SK':'Slovakia'
		,'SI':'Slovenia'
		,'SB':'Solomon Islands'
		,'SO':'Somalia'
		,'ZA':'South Africa'
		,'GS':'South Georgia and the South Sandwich Islands'
		,'KR':'South Korea'
		,'SS':'South Sudan'
		,'ES':'Spain'
		,'LK':'Sri Lanka'
		,'SD':'Sudan'
		,'SR':'Suriname'
		,'SJ':'Svalbard and Jan Mayen'
		,'SZ':'Swaziland'
		,'SE':'Sweden'
		,'CH':'Switzerland'
		,'SY':'Syria'
		,'ST':'São Tomé and Príncipe'
		,'TW':'Taiwan'
		,'TJ':'Tajikistan'
		,'TZ':'Tanzania'
		,'TH':'Thailand'
		,'TG':'Togo'
		,'TK':'Tokelau'
		,'TO':'Tonga'
		,'TT':'Trinidad and Tobago'
		,'TN':'Tunisia'
		,'TR':'Turkey'
		,'TM':'Turkmenistan'
		,'TC':'Turks and Caicos Islands'
		,'TV':'Tuvalu'
		,'UM':'U.S. Minor Outlying Islands'
		,'VI':'U.S. Virgin Islands'
		,'UG':'Uganda'
		,'UA':'Ukraine'
		,'AE':'United Arab Emirates'
		,'UK':'United Kingdom'
		,'US':'United States'
		,'UY':'Uruguay'
		,'UZ':'Uzbekistan'
		,'VU':'Vanuatu'
		,'VA':'Vatican City'
		,'VE':'Venezuela'
		,'VN':'Vietnam'
		,'WF':'Wallis and Futuna'
		,'EH':'Western Sahara'
		,'YE':'Yemen'
		,'ZM':'Zambia'
		,'ZW':'Zimbabwe'
		,'AX':'Åland'
		}
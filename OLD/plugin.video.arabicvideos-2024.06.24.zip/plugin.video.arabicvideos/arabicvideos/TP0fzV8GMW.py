# -*- coding: utf-8 -*-
import sys as GGtWyVoJReUuEBCdAagiL1YXO8
ggqTOXpCEcQD68f3oxrKilaSvkdtN = GGtWyVoJReUuEBCdAagiL1YXO8.version_info [0] == 2
pQ14eMnbYBK0xGywR7SuFChJdONj6 = 2048
y65ArzSx9RZh = 7
def MUzuWiALbXp6w5 (TMw2a0zHkY9lcdIvLFZXrS):
	global ynv9hpqlRAJuN0gXrEscaoP5dMWYDO
	Icnd5Dq4krBK3iYg2xNZHF = ord (TMw2a0zHkY9lcdIvLFZXrS [-1])
	u05ustK47xXQZbyFerWTROY = TMw2a0zHkY9lcdIvLFZXrS [:-1]
	BXAu3ZJQ9IPLg7kiy4K06ha = Icnd5Dq4krBK3iYg2xNZHF % len (u05ustK47xXQZbyFerWTROY)
	nRXUw1Fg0DSrkYGL = u05ustK47xXQZbyFerWTROY [:BXAu3ZJQ9IPLg7kiy4K06ha] + u05ustK47xXQZbyFerWTROY [BXAu3ZJQ9IPLg7kiy4K06ha:]
	if ggqTOXpCEcQD68f3oxrKilaSvkdtN:
		sW7Qyn32Zidt5TE4w96 = unicode () .join ([unichr (ord (Lk9Jh0wu7aNAE) - pQ14eMnbYBK0xGywR7SuFChJdONj6 - (Ebxc6eiUkyVNfMBs3CRIOArQ4h + Icnd5Dq4krBK3iYg2xNZHF) % y65ArzSx9RZh) for Ebxc6eiUkyVNfMBs3CRIOArQ4h, Lk9Jh0wu7aNAE in enumerate (nRXUw1Fg0DSrkYGL)])
	else:
		sW7Qyn32Zidt5TE4w96 = str () .join ([chr (ord (Lk9Jh0wu7aNAE) - pQ14eMnbYBK0xGywR7SuFChJdONj6 - (Ebxc6eiUkyVNfMBs3CRIOArQ4h + Icnd5Dq4krBK3iYg2xNZHF) % y65ArzSx9RZh) for Ebxc6eiUkyVNfMBs3CRIOArQ4h, Lk9Jh0wu7aNAE in enumerate (nRXUw1Fg0DSrkYGL)])
	return eval (sW7Qyn32Zidt5TE4w96)
Cu1704YofAbr3QTm,oh5Ptv7RjM3qLk1eEZJbcVzKis4d,LiRcTVUWuth70DmPy=MUzuWiALbXp6w5,MUzuWiALbXp6w5,MUzuWiALbXp6w5
pq3Z6xaELn0NW7PgAeI1bCRwdu,UTelCo0ihE1d5R,Me28A1sBLNIgUp5YCDyvT=LiRcTVUWuth70DmPy,oh5Ptv7RjM3qLk1eEZJbcVzKis4d,Cu1704YofAbr3QTm
kEhAHvti6Vnsfx,g4g6bfkPtVGU5lIM3,E6MIKdpBomef=Me28A1sBLNIgUp5YCDyvT,UTelCo0ihE1d5R,pq3Z6xaELn0NW7PgAeI1bCRwdu
wRxoKs10Syj7V4edYhtP,yA5z6LIXBlo41PRVMY87wOisFp,iUeoLOsbHqP=E6MIKdpBomef,g4g6bfkPtVGU5lIM3,kEhAHvti6Vnsfx
iRoLg2m47tnDATBHGCSPNyx,xW2Arao7YVOemw,l30iT7pjzmXk8dvwSNyUR1aZO4tWh=iUeoLOsbHqP,yA5z6LIXBlo41PRVMY87wOisFp,wRxoKs10Syj7V4edYhtP
dshJSmRqeiP9nap2,FnBiAjthS8MkXs67W,FvNyZqaLKw=l30iT7pjzmXk8dvwSNyUR1aZO4tWh,xW2Arao7YVOemw,iRoLg2m47tnDATBHGCSPNyx
SO94xq1RAkMm2uF,bUdr5Hahw6sY8xJ,XzrqbGDIy54juixkMA=FvNyZqaLKw,FnBiAjthS8MkXs67W,dshJSmRqeiP9nap2
p72fnFtcPix5UKwr9YNzW,sTcr7iDp5eFt4RoLMhuwq1A,SyENPzdOon6uxcLXMhqb14aDlB9r=XzrqbGDIy54juixkMA,bUdr5Hahw6sY8xJ,SO94xq1RAkMm2uF
zqdvcbP5L8BHh,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF,lc0dpSmwoPDjLnk=SyENPzdOon6uxcLXMhqb14aDlB9r,sTcr7iDp5eFt4RoLMhuwq1A,p72fnFtcPix5UKwr9YNzW
QVZl0O8yUIzdGDTfYcn5H37uWmb2,hRNlWkwDitzVpbSO3TIdAm5YGjaZ,fprnld4CZo=lc0dpSmwoPDjLnk,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF,zqdvcbP5L8BHh
hBvsQ7oCkKUdwjx58ml3EN,G5DeRbUpFj8E9OtJLvlo2fWmZC,S4SOKF2QbBhjCd3RrVMuHIzE=fprnld4CZo,hRNlWkwDitzVpbSO3TIdAm5YGjaZ,QVZl0O8yUIzdGDTfYcn5H37uWmb2
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪज")
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(VRnfEFmJzUrSljM8,kk1GKyapocQZDAz):
	if   VRnfEFmJzUrSljM8==iUeoLOsbHqP(u"࠷࠸࠶৪"): zpXG3Ky6ou8ndWHkb4 = q0bnj1H5S36G4hIplrdWgPFT()
	elif VRnfEFmJzUrSljM8==QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠸࠹࠱৫"): zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(kk1GKyapocQZDAz)
	elif VRnfEFmJzUrSljM8==p72fnFtcPix5UKwr9YNzW(u"࠹࠳࠳৬"): zpXG3Ky6ou8ndWHkb4 = leEzSVa2sjFudxQO4BhiTYA1qyZPb7()
	elif VRnfEFmJzUrSljM8==iRoLg2m47tnDATBHGCSPNyx(u"࠳࠴࠵৭"): zpXG3Ky6ou8ndWHkb4 = F7Z8QI0dGwBNzACSUtO5RnLjrqKvfJ()
	elif VRnfEFmJzUrSljM8==YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠴࠵࠷৮"): zpXG3Ky6ou8ndWHkb4 = hFwmrXnMUVuzv1GxaH2SJ5YO(kk1GKyapocQZDAz)
	else: zpXG3Ky6ou8ndWHkb4 = Cu1704YofAbr3QTm(u"ࡋࡧ࡬ࡴࡧਜ")
	return zpXG3Ky6ou8ndWHkb4
def hFwmrXnMUVuzv1GxaH2SJ5YO(Idzv5S7TBF):
	try: WpgZTyqoMAPhwGiXF.remove(Idzv5S7TBF.decode(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠩࡸࡸ࡫࠾ࠧझ")))
	except: WpgZTyqoMAPhwGiXF.remove(Idzv5S7TBF)
	return
def SUfe4unWoXBNFz90xqy(kk1GKyapocQZDAz):
	ICifW6hdKqxkAJ02XZgHysOwoV9Dc5(kk1GKyapocQZDAz,cTJphS1nFz5EUgNWm86C,bUdr5Hahw6sY8xJ(u"ࠪࡺ࡮ࡪࡥࡰࠩञ"))
	return
def F7Z8QI0dGwBNzACSUtO5RnLjrqKvfJ():
	LpdKxnIsY3Sy6qP = LiRcTVUWuth70DmPy(u"ࠫศึ็ษࠢศ่๎ࠦัศสฺࠤฬ๊แ๋ัํ์ࠥษ่ࠡษ็ูํะࠠโ์ࠣห้๋่ใ฻ࠣห้๋ืๅ๊หࠤะ๋ࠠฤุ฽฻ࠥ฿ไ๊ࠢีีࠥอไใษษ้ฮࠦวๅ์่๎๋ࠦหๆࠢฦาฯอัࠡࠤอั๊๐ไࠡ็็ๅฬะࠠโ์า๎ํࠨࠠฬ็ࠣหำะวาࠢาๆฮࠦวๅื๋ีฮ่ࠦศะอหึࠦๆ้฻้้ࠣ็ࠠศๆุ์ึฯ้ࠠส฼ำ์อࠠิ๊ไࠤ๏ฮฯฤࠢส่ฯำๅ๋ๆࠪट")
	aHKzv76JCVnprbY8w(dshJSmRqeiP9nap2(u"ࠬ࠭ठ"),lc0dpSmwoPDjLnk(u"࠭ࠧड"),hBvsQ7oCkKUdwjx58ml3EN(u"ุࠧำํๆฮࠦสฮ็ํ่ࠥอไๆๆไหฯ࠭ढ"),LpdKxnIsY3Sy6qP)
	return
def q0bnj1H5S36G4hIplrdWgPFT():
	cd0aGwCPExbFU5pYNu8r(kEhAHvti6Vnsfx(u"ࠨ࡮࡬ࡲࡰ࠭ण"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ฼ื๊ใหࠣฮา๋๊ๅ่่ࠢๆอสࠡษ็ๅ๏ี๊้࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪत"),xW2Arao7YVOemw(u"ࠪࠫथ"),bUdr5Hahw6sY8xJ(u"࠵࠶࠷৯"))
	cd0aGwCPExbFU5pYNu8r(SO94xq1RAkMm2uF(u"ࠫࡱ࡯࡮࡬ࠩद"),FvNyZqaLKw(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ห฼ํ๎ึࠦๅไษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨध"),wRxoKs10Syj7V4edYhtP(u"࠭ࠧन"),dshJSmRqeiP9nap2(u"࠶࠷࠷ৰ"))
	cd0aGwCPExbFU5pYNu8r(iRoLg2m47tnDATBHGCSPNyx(u"ࠧ࡭࡫ࡱ࡯ࠬऩ"),dshJSmRqeiP9nap2(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪप"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩࠪफ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠽࠾࠿࠹ৱ"))
	mhP4wGjY27bUTkc1gDQANJuaEx3 = Db4gGI8fVPjJeKmdwqOtxQCWL0()
	xyOCU61jmbMN8d = WpgZTyqoMAPhwGiXF.stat(mhP4wGjY27bUTkc1gDQANJuaEx3).st_mtime
	OwhENJc75KjTmMH8qtzo1Sfv0X9kU6 = []
	if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: FKbOH5hxNSyPop0CG = WpgZTyqoMAPhwGiXF.listdir(mhP4wGjY27bUTkc1gDQANJuaEx3.encode(iUeoLOsbHqP(u"ࠪࡹࡹ࡬࠸ࠨब")))
	else: FKbOH5hxNSyPop0CG = WpgZTyqoMAPhwGiXF.listdir(mhP4wGjY27bUTkc1gDQANJuaEx3.decode(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫࡺࡺࡦ࠹ࠩभ")))
	for z4zpsIWKUVTxqe2NY9H1OJD7Xgb in FKbOH5hxNSyPop0CG:
		if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: z4zpsIWKUVTxqe2NY9H1OJD7Xgb = z4zpsIWKUVTxqe2NY9H1OJD7Xgb.decode(p72fnFtcPix5UKwr9YNzW(u"ࠬࡻࡴࡧ࠺ࠪम"))
		if not z4zpsIWKUVTxqe2NY9H1OJD7Xgb.startswith(p72fnFtcPix5UKwr9YNzW(u"࠭ࡦࡪ࡮ࡨࡣࠬय")): continue
		Vl3KQTu1v4Nzb9oUXnO = WpgZTyqoMAPhwGiXF.path.join(mhP4wGjY27bUTkc1gDQANJuaEx3,z4zpsIWKUVTxqe2NY9H1OJD7Xgb)
		xyOCU61jmbMN8d = WpgZTyqoMAPhwGiXF.path.getmtime(Vl3KQTu1v4Nzb9oUXnO)
		OwhENJc75KjTmMH8qtzo1Sfv0X9kU6.append([z4zpsIWKUVTxqe2NY9H1OJD7Xgb,xyOCU61jmbMN8d])
	OwhENJc75KjTmMH8qtzo1Sfv0X9kU6 = sorted(OwhENJc75KjTmMH8qtzo1Sfv0X9kU6,reverse=kEhAHvti6Vnsfx(u"࡚ࡲࡶࡧਝ"),key=lambda key: key[QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠶৲")])
	for z4zpsIWKUVTxqe2NY9H1OJD7Xgb,xyOCU61jmbMN8d in OwhENJc75KjTmMH8qtzo1Sfv0X9kU6:
		if HHosl5fRdhtEDAYyP:
			try: z4zpsIWKUVTxqe2NY9H1OJD7Xgb = z4zpsIWKUVTxqe2NY9H1OJD7Xgb.decode(FvNyZqaLKw(u"ࠧࡶࡶࡩ࠼ࠬर"))
			except: pass
			z4zpsIWKUVTxqe2NY9H1OJD7Xgb = z4zpsIWKUVTxqe2NY9H1OJD7Xgb.encode(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨࡷࡷࡪ࠽࠭ऱ"))
		Vl3KQTu1v4Nzb9oUXnO = WpgZTyqoMAPhwGiXF.path.join(mhP4wGjY27bUTkc1gDQANJuaEx3,z4zpsIWKUVTxqe2NY9H1OJD7Xgb)
		cd0aGwCPExbFU5pYNu8r(Cu1704YofAbr3QTm(u"ࠩࡹ࡭ࡩ࡫࡯ࠨल"),z4zpsIWKUVTxqe2NY9H1OJD7Xgb,Vl3KQTu1v4Nzb9oUXnO,SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠹࠳࠲৳"))
	return
def Db4gGI8fVPjJeKmdwqOtxQCWL0():
	mhP4wGjY27bUTkc1gDQANJuaEx3 = jHevARrF7lS.getSetting(UTelCo0ihE1d5R(u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭ळ"))
	if mhP4wGjY27bUTkc1gDQANJuaEx3: return mhP4wGjY27bUTkc1gDQANJuaEx3
	jHevARrF7lS.setSetting(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫࡦࡼ࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧऴ"),JXUQZHLxEgTFbrRC7n9)
	return JXUQZHLxEgTFbrRC7n9
def leEzSVa2sjFudxQO4BhiTYA1qyZPb7():
	mhP4wGjY27bUTkc1gDQANJuaEx3 = Db4gGI8fVPjJeKmdwqOtxQCWL0()
	u87kXEoHNvT6PLKnyxW = ggi4vBsqHDArM1(Cu1704YofAbr3QTm(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬव"),iUeoLOsbHqP(u"࠭ࠧश"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࠨष"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨ็ๆห๋ࠦสฯิํ๊๋ࠥไโษอࠤฬ๊สฮ็ํ่ࠬस"),Cu1704YofAbr3QTm(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬह")+mhP4wGjY27bUTkc1gDQANJuaEx3+LiRcTVUWuth70DmPy(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯้ำหࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮา๋ไ่ษࠣห๋ะࠠษษึฮำีวๆ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰๋้ࠣࠦสา์าࠤฯเ๊๋ำࠣห้๋ใศ่ࠣรࠬऺ"))
	if u87kXEoHNvT6PLKnyxW==Cu1704YofAbr3QTm(u"࠱৴"):
		djEYMQkrh1SJt78XzH = xpNfHdntGQPjZOCli8A3JyvBSRL(FnBiAjthS8MkXs67W(u"࠴৵"),iUeoLOsbHqP(u"๊้ࠫว็ࠢอั๊๐ไࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠨऻ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬࡲ࡯ࡤࡣ࡯़ࠫ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ࠧऽ"),iRoLg2m47tnDATBHGCSPNyx(u"ࡇࡣ࡯ࡷࡪਟ"),Me28A1sBLNIgUp5YCDyvT(u"ࡔࡳࡷࡨਞ"),mhP4wGjY27bUTkc1gDQANJuaEx3)
		o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(UTelCo0ihE1d5R(u"ࠧࡤࡧࡱࡸࡪࡸࠧा"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࠩि"),LiRcTVUWuth70DmPy(u"ࠩࠪी"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"้่ࠪอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅฬะ้๏๊ࠧु"),xW2Arao7YVOemw(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧू")+mhP4wGjY27bUTkc1gDQANJuaEx3+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱ๋ีอ่๊ࠠࠣห้๋ใศ่ࠣห้าฯ๋ั่ࠣฯิา๋่้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬะ้้ํวࠡษ้ฮࠥฮวิฬัำฬ๋่ࠠาสࠤฬ๊ศา่ส้ัࠦ࠮้ࠡ็ࠤฯื๊ะࠢสืฯิฯศ็๊ࠤอีไศ่๊ࠢࠥอไๆๅส๊ࠥอไใัํ้ࠥลࠧृ"))
		if o07Z1tEB4n3ARCkVNu==wRxoKs10Syj7V4edYhtP(u"࠳৶"):
			jHevARrF7lS.setSetting(fprnld4CZo(u"࠭ࡡࡷ࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵࡧࡴࡩࠩॄ"),djEYMQkrh1SJt78XzH)
			aHKzv76JCVnprbY8w(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠧࠨॅ"),g4g6bfkPtVGU5lIM3(u"ࠨࠩॆ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬे"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠪฮ๊ࠦส฻์ํี๋ࠥใศ่ࠣฮำุ๊็ࠢส่๊๊แศฬࠣห้๋อๆๆฬࠫै"))
	return
def wweM3YXLySo6(kk1GKyapocQZDAz,QNHsaf7u3DSjiJ40ARCKYO=hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠫࠬॉ"),website=oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠬ࠭ॊ")):
	LOHZ4o9m7p6ebfTYXGIdz5PWs3q(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ो"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+iUeoLOsbHqP(u"ࠧࠡࠢࠣࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧौ")+kk1GKyapocQZDAz+sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨࠢࡠ्ࠫ"))
	if not QNHsaf7u3DSjiJ40ARCKYO: QNHsaf7u3DSjiJ40ARCKYO = dd8rHcveo7O15hT3MSR(kk1GKyapocQZDAz)
	mhP4wGjY27bUTkc1gDQANJuaEx3 = Db4gGI8fVPjJeKmdwqOtxQCWL0()
	m5MfkiT7oUDbvHI43ByeY9FP = uHqQfiPTpJIj971nbGMs03LoyzwK()
	z4zpsIWKUVTxqe2NY9H1OJD7Xgb = m5MfkiT7oUDbvHI43ByeY9FP.replace(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠩࠣࠫॎ"),UTelCo0ihE1d5R(u"ࠪࡣࠬॏ"))
	z4zpsIWKUVTxqe2NY9H1OJD7Xgb = ICnDbfxZ5031iOzrYGH98sy2LtQ(z4zpsIWKUVTxqe2NY9H1OJD7Xgb)
	z4zpsIWKUVTxqe2NY9H1OJD7Xgb = LiRcTVUWuth70DmPy(u"ࠫ࡫࡯࡬ࡦࡡࠪॐ")+str(int(MMHpSTojGILfZXWeCOPyn4))[-QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠷৷"):]+fprnld4CZo(u"ࠬࡥࠧ॑")+z4zpsIWKUVTxqe2NY9H1OJD7Xgb+QNHsaf7u3DSjiJ40ARCKYO
	wsGBSE5nY94UXrdmxLRWKbie7 = WpgZTyqoMAPhwGiXF.path.join(mhP4wGjY27bUTkc1gDQANJuaEx3,z4zpsIWKUVTxqe2NY9H1OJD7Xgb)
	vqNwzh36FVc = {}
	vqNwzh36FVc[FnBiAjthS8MkXs67W(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ॒")] = S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠧࠨ॓")
	vqNwzh36FVc[dshJSmRqeiP9nap2(u"ࠨࡃࡦࡧࡪࡶࡴࠨ॔")] = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩ࠭࠳࠯࠭ॕ")
	kk1GKyapocQZDAz = kk1GKyapocQZDAz.replace(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠪࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡧࡣ࡯ࡷࡪ࠭ॖ"),FvNyZqaLKw(u"ࠫࠬॗ"))
	if FnBiAjthS8MkXs67W(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪक़") in kk1GKyapocQZDAz:
		dR2vHyAtl8pJN1,bTDaxXYSseoFCI6cQ4f58vqr3dPNp = kk1GKyapocQZDAz.rsplit(lc0dpSmwoPDjLnk(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫख़"),fprnld4CZo(u"࠵৸"))
		bTDaxXYSseoFCI6cQ4f58vqr3dPNp = bTDaxXYSseoFCI6cQ4f58vqr3dPNp.replace(kEhAHvti6Vnsfx(u"ࠧࡽࠩग़"),p72fnFtcPix5UKwr9YNzW(u"ࠨࠩज़")).replace(hBvsQ7oCkKUdwjx58ml3EN(u"ࠩࠩࠫड़"),SO94xq1RAkMm2uF(u"ࠪࠫढ़"))
	else: dR2vHyAtl8pJN1,bTDaxXYSseoFCI6cQ4f58vqr3dPNp = kk1GKyapocQZDAz,None
	if not bTDaxXYSseoFCI6cQ4f58vqr3dPNp: bTDaxXYSseoFCI6cQ4f58vqr3dPNp = Y8Y6b7aLSUKjdE1Ae()
	if bTDaxXYSseoFCI6cQ4f58vqr3dPNp: vqNwzh36FVc[G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨफ़")] = bTDaxXYSseoFCI6cQ4f58vqr3dPNp
	if pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬࡘࡥࡧࡧࡵࡩࡷࡃࠧय़") in dR2vHyAtl8pJN1: dR2vHyAtl8pJN1,CCilGtf08YTx6qDX9Svg = dR2vHyAtl8pJN1.rsplit(zqdvcbP5L8BHh(u"࠭ࡒࡦࡨࡨࡶࡪࡸ࠽ࠨॠ"),dshJSmRqeiP9nap2(u"࠶৹"))
	else: dR2vHyAtl8pJN1,CCilGtf08YTx6qDX9Svg = dR2vHyAtl8pJN1,Me28A1sBLNIgUp5YCDyvT(u"ࠧࠨॡ")
	dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1.strip(LiRcTVUWuth70DmPy(u"ࠨࡾࠪॢ")).strip(FnBiAjthS8MkXs67W(u"ࠩࠩࠫॣ")).strip(iUeoLOsbHqP(u"ࠪࢀࠬ।")).strip(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫࠫ࠭॥"))
	CCilGtf08YTx6qDX9Svg = CCilGtf08YTx6qDX9Svg.replace(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠬࢂࠧ०"),Me28A1sBLNIgUp5YCDyvT(u"࠭ࠧ१")).replace(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠧࠧࠩ२"),FnBiAjthS8MkXs67W(u"ࠨࠩ३"))
	if CCilGtf08YTx6qDX9Svg:	vqNwzh36FVc[p72fnFtcPix5UKwr9YNzW(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ४")] = CCilGtf08YTx6qDX9Svg
	LOHZ4o9m7p6ebfTYXGIdz5PWs3q(XzrqbGDIy54juixkMA(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ५"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+dshJSmRqeiP9nap2(u"ࠫࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫ࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ६")+dR2vHyAtl8pJN1+p72fnFtcPix5UKwr9YNzW(u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨ७")+str(vqNwzh36FVc)+SO94xq1RAkMm2uF(u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭८")+wsGBSE5nY94UXrdmxLRWKbie7+bUdr5Hahw6sY8xJ(u"ࠧࠡ࡟ࠪ९"))
	cMR1f3D2UeyrLKXoYVPt8 = Cu1704YofAbr3QTm(u"࠷࠰࠳࠶৺")*Cu1704YofAbr3QTm(u"࠷࠰࠳࠶৺")
	kzDFCG2nWXxBIK = UTelCo0ihE1d5R(u"࠰৻")
	try:
		ZergCtqJYcy9Vn24IGm58 =	cEZpW924rqNYm5.getInfoLabel(E6MIKdpBomef(u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡈࡵࡩࡪ࡙ࡰࡢࡥࡨࠫ॰"))
		ZergCtqJYcy9Vn24IGm58 = GGvHJKP9LUxEk10Fw.findall(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩ࡟ࡨ࠰࠭ॱ"),ZergCtqJYcy9Vn24IGm58)
		kzDFCG2nWXxBIK = int(ZergCtqJYcy9Vn24IGm58[FnBiAjthS8MkXs67W(u"࠱ৼ")])
	except: pass
	if not kzDFCG2nWXxBIK:
		try:
			yv9q2nXKNlBLx8kMDeQRc = WpgZTyqoMAPhwGiXF.statvfs(mhP4wGjY27bUTkc1gDQANJuaEx3)
			kzDFCG2nWXxBIK = yv9q2nXKNlBLx8kMDeQRc.f_frsize*yv9q2nXKNlBLx8kMDeQRc.f_bavail//cMR1f3D2UeyrLKXoYVPt8
		except: pass
	if not kzDFCG2nWXxBIK:
		try:
			yv9q2nXKNlBLx8kMDeQRc = WpgZTyqoMAPhwGiXF.fstatvfs(mhP4wGjY27bUTkc1gDQANJuaEx3)
			kzDFCG2nWXxBIK = yv9q2nXKNlBLx8kMDeQRc.f_frsize*yv9q2nXKNlBLx8kMDeQRc.f_bavail//cMR1f3D2UeyrLKXoYVPt8
		except: pass
	if not kzDFCG2nWXxBIK:
		try:
			import shutil as Hd46Y9eTlznk
			vU0mKurMALYj2xdohIPn,Sng15ECYf0ucMIjoZlGHVTs9AQDU4y,ZB6NduP32AMJ7znlvTYHLWp0q = Hd46Y9eTlznk.disk_usage(mhP4wGjY27bUTkc1gDQANJuaEx3)
			kzDFCG2nWXxBIK = ZB6NduP32AMJ7znlvTYHLWp0q//cMR1f3D2UeyrLKXoYVPt8
		except: pass
	if not kzDFCG2nWXxBIK:
		d0tNlv4Lbu2pqDaO1JfSEC9QIP5Xc(kEhAHvti6Vnsfx(u"ࠪࡶ࡮࡭ࡨࡵࠩॲ"),bUdr5Hahw6sY8xJ(u"ู๊ࠫวฮหࠣห้ะฮำ์้ࠤ๊า็้ๆฬࠫॳ"),FvNyZqaLKw(u"๊ࠬไฤีไࠤฬ๊ศา่ส้ัฺ๋ࠦำࠣๆฬีัࠡล้ࠤ๏ำฯะ่ࠢๆิอัࠡ็ึหาฯࠠศๆอาื๐ๆࠡษ็ๅฬืฺสࠢไ๎ࠥา็ศิๆࠤํ฿ไ๋้ࠣๅฬ์ࠠหฯ่๎้ࠦวๅใํำ๏๎็ศฬฺ่๋๊ࠣࠦ็็ࠤ฾์ฯไࠢศ่๎ࠦร็ࠢํๆํ๋ࠠๆสิ้ั๐ࠠษำ้ห๊าࠠไ๊า๎ࠥฮอๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠๅษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠠใัࠣ๎ุฮศࠡษ่ฮ้อมࠡฮ๊หื้ࠠษษ็้้็วห๋๋ࠢีอࠠโ์๊ࠤำ฽่าหࠣ฽้๏ฺࠠ็็ࠤัํวำๅࠣฬฺ๎ัสุࠢั๏ำษ๊ࠡ็๋ีอࠠศๆึฬอࠦโศ็ࠣห้๋ศา็ฯࠤ๊สโหษࠣฬ๊์ูࠡษ็ฬึ์วๆฮ้๋ࠣࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠩॴ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩॵ"))
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q(zqdvcbP5L8BHh(u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬॶ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨࠢࠣࠤ࡚ࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡥࡧࡷࡩࡷࡳࡩ࡯ࡧࠣࡸ࡭࡫ࠠࡥ࡫ࡶ࡯ࠥ࡬ࡲࡦࡧࠣࡷࡵࡧࡣࡦࠩॷ"))
		return fprnld4CZo(u"ࡈࡤࡰࡸ࡫ਠ")
	if QNHsaf7u3DSjiJ40ARCKYO==YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨॸ"):
		eyUmvNFiYsE,zzvBg3ShiamAZ = BXEJoygQHA8RZ(dR2vHyAtl8pJN1,vqNwzh36FVc)
		if len(eyUmvNFiYsE)==hBvsQ7oCkKUdwjx58ml3EN(u"࠲৽"):
			From8aTqdhCbPs(bUdr5Hahw6sY8xJ(u"ࠪๅู๊ࠠโ์ࠣษ๏าวะ่่ࠢๆࠦวๅฬะ้๏๊ࠧॹ"),FvNyZqaLKw(u"ࠫࠬॺ"))
			return E6MIKdpBomef(u"ࡉࡥࡱࡹࡥਡ")
		elif len(eyUmvNFiYsE)==wRxoKs10Syj7V4edYhtP(u"࠴৾"): z0jyetbQwKrIclL9vJW = E6MIKdpBomef(u"࠴৿")
		elif len(eyUmvNFiYsE)>g4g6bfkPtVGU5lIM3(u"࠶਀"):
			z0jyetbQwKrIclL9vJW = D1DJtzviFZSrA(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิสࠪॻ"), eyUmvNFiYsE)
			if z0jyetbQwKrIclL9vJW == -yA5z6LIXBlo41PRVMY87wOisFp(u"࠷ਁ") :
				From8aTqdhCbPs(zqdvcbP5L8BHh(u"࠭สๆࠢศ่฿อมࠡษ็ฮา๋๊ๅࠩॼ"),FvNyZqaLKw(u"ࠧࠨॽ"))
				return dshJSmRqeiP9nap2(u"ࡊࡦࡲࡳࡦਢ")
		dR2vHyAtl8pJN1 = zzvBg3ShiamAZ[z0jyetbQwKrIclL9vJW]
	zLT293nVDyIqidtgesBYSwZ8bR = oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠰ਂ")
	if QNHsaf7u3DSjiJ40ARCKYO==Cu1704YofAbr3QTm(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧॾ"):
		wsGBSE5nY94UXrdmxLRWKbie7 = wsGBSE5nY94UXrdmxLRWKbie7.rsplit(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨॿ"))[QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠱ਃ")]+kEhAHvti6Vnsfx(u"ࠪ࠲ࡲࡶ࠴ࠨঀ")
		zGmyJhleoQZ = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,E6MIKdpBomef(u"ࠫࡌࡋࡔࠨঁ"),dR2vHyAtl8pJN1,bUdr5Hahw6sY8xJ(u"ࠬ࠭ং"),vqNwzh36FVc,bUdr5Hahw6sY8xJ(u"࠭ࠧঃ"),LiRcTVUWuth70DmPy(u"ࠧࠨ঄"),FvNyZqaLKw(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆ࠰ࡈࡔ࡝ࡎࡍࡑࡄࡈࡤ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨঅ"))
		rybzkcfKhtYBEA74u = zGmyJhleoQZ.content
		gI487voLsArVqW6Ffp = GGvHJKP9LUxEk10Fw.findall(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩࠦࡉ࡝࡚ࡉࡏࡈ࠽࠲࠯ࡅ࡛࡝ࡰ࡟ࡶࡢ࠮࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪআ"),rybzkcfKhtYBEA74u+FnBiAjthS8MkXs67W(u"ࠪࡠࡳࡢࡲࠨই"),GGvHJKP9LUxEk10Fw.DOTALL)
		if not gI487voLsArVqW6Ffp:
			LOHZ4o9m7p6ebfTYXGIdz5PWs3q(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩঈ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬࠦࠠࠡࡖ࡫ࡩࠥࡳ࠳ࡶ࠺ࠣࡪ࡮ࡲࡥࠡࡦ࡬ࡨࠥࡴ࡯ࡵࠢ࡫ࡥࡻ࡫ࠠࡵࡪࡨࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࠦ࡬ࡪࡰ࡮ࡷࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨউ")+dR2vHyAtl8pJN1+wRxoKs10Syj7V4edYhtP(u"࠭ࠠ࡞ࠩঊ"))
			return Me28A1sBLNIgUp5YCDyvT(u"ࡋࡧ࡬ࡴࡧਣ")
		ELbNB92cOh5dqtpVmi40kY = gI487voLsArVqW6Ffp[FnBiAjthS8MkXs67W(u"࠲਄")]
		if not ELbNB92cOh5dqtpVmi40kY.startswith(FnBiAjthS8MkXs67W(u"ࠧࡩࡶࡷࡴࠬঋ")):
			if ELbNB92cOh5dqtpVmi40kY.startswith(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨ࠱࠲ࠫঌ")): ELbNB92cOh5dqtpVmi40kY = dR2vHyAtl8pJN1.split(wRxoKs10Syj7V4edYhtP(u"ࠩ࠽ࠫ঍"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠴ਅ"))[G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠴ਆ")]+LiRcTVUWuth70DmPy(u"ࠪ࠾ࠬ঎")+ELbNB92cOh5dqtpVmi40kY
			elif ELbNB92cOh5dqtpVmi40kY.startswith(FvNyZqaLKw(u"ࠫ࠴࠭এ")): ELbNB92cOh5dqtpVmi40kY = RfKuIXwPAiWtmyF(dR2vHyAtl8pJN1,SO94xq1RAkMm2uF(u"ࠬࡻࡲ࡭ࠩঐ"))+ELbNB92cOh5dqtpVmi40kY
			else: ELbNB92cOh5dqtpVmi40kY = dR2vHyAtl8pJN1.rsplit(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠭࠯ࠨ঑"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠶ਇ"))[sTcr7iDp5eFt4RoLMhuwq1A(u"࠶ਈ")]+wRxoKs10Syj7V4edYhtP(u"ࠧ࠰ࠩ঒")+ELbNB92cOh5dqtpVmi40kY
		zGmyJhleoQZ = DJ1rx9fvXIgUS7sZkVlOeGHb.request(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠨࡉࡈࡘࠬও"),ELbNB92cOh5dqtpVmi40kY,headers=vqNwzh36FVc,verify=LiRcTVUWuth70DmPy(u"ࡌࡡ࡭ࡵࡨਤ"))
		nL7q2gowIsPCWkRydufQZ = zGmyJhleoQZ.content
		xS7NEXG8nLsUiB9t6rbzM = len(nL7q2gowIsPCWkRydufQZ)
		dac3D2xo6WPu = len(gI487voLsArVqW6Ffp)
		zLT293nVDyIqidtgesBYSwZ8bR = xS7NEXG8nLsUiB9t6rbzM*dac3D2xo6WPu
	else:
		xS7NEXG8nLsUiB9t6rbzM = FvNyZqaLKw(u"࠱ਉ")*cMR1f3D2UeyrLKXoYVPt8
		zGmyJhleoQZ = DJ1rx9fvXIgUS7sZkVlOeGHb.request(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠩࡊࡉ࡙࠭ঔ"),dR2vHyAtl8pJN1,headers=vqNwzh36FVc,verify=pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࡇࡣ࡯ࡷࡪਦ"),stream=Me28A1sBLNIgUp5YCDyvT(u"ࡔࡳࡷࡨਥ"))
		if iRoLg2m47tnDATBHGCSPNyx(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫক") in zGmyJhleoQZ.headers: zLT293nVDyIqidtgesBYSwZ8bR = int(zGmyJhleoQZ.headers[E6MIKdpBomef(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬখ")])
		dac3D2xo6WPu = int(zLT293nVDyIqidtgesBYSwZ8bR//xS7NEXG8nLsUiB9t6rbzM)
	tV4NTJHwly = int(zLT293nVDyIqidtgesBYSwZ8bR//cMR1f3D2UeyrLKXoYVPt8)+LiRcTVUWuth70DmPy(u"࠲ਊ")
	if zLT293nVDyIqidtgesBYSwZ8bR<sTcr7iDp5eFt4RoLMhuwq1A(u"࠴࠴࠴࠵࠶਋"):
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪগ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+SyENPzdOon6uxcLXMhqb14aDlB9r(u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡩࡴࠢࡷࡳࡴࠦࡳ࡮ࡣ࡯ࡰࠥࡵࡲࠡ࡫ࡷࠤ࡮ࡹࠠ࡮࠵ࡸ࠼ࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨঘ")+dR2vHyAtl8pJN1+Cu1704YofAbr3QTm(u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫঙ")+str(tV4NTJHwly)+S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡄࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧচ")+str(kzDFCG2nWXxBIK)+kEhAHvti6Vnsfx(u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬছ")+wsGBSE5nY94UXrdmxLRWKbie7+hBvsQ7oCkKUdwjx58ml3EN(u"ࠪࠤࡢ࠭জ"))
		aHKzv76JCVnprbY8w(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫࠬঝ"),kEhAHvti6Vnsfx(u"ࠬ࠭ঞ"),p72fnFtcPix5UKwr9YNzW(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩট"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠧโึ็ࠤๆ๐ࠠๆ฻ิๅฮࠦออ็้้ࠣ็ࠠศๆไ๎ิ๐่ࠡล๋ࠤฬ๊ๅๅใูࠣ฿๐ัࠡฮาหࠥ๎ไ่าสࠤ้อ๋ࠠ็ๆ๊๊ࠥไษำ้ห๊าࠠหฯ่๎้ࠦ็ัษࠣห้๋ไโࠩঠ"))
		return oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࡈࡤࡰࡸ࡫ਧ")
	Gwdk3rnsufKI2eNL5zWMqUhcHx10A = wRxoKs10Syj7V4edYhtP(u"࠷࠴࠵਌")
	O0yYKUsJVI9 = kzDFCG2nWXxBIK-tV4NTJHwly
	if O0yYKUsJVI9<Gwdk3rnsufKI2eNL5zWMqUhcHx10A:
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q(lc0dpSmwoPDjLnk(u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭ড"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+FnBiAjthS8MkXs67W(u"ࠩࠣࠤࠥࡔ࡯ࡵࠢࡨࡲࡴࡻࡧࡩࠢࡧ࡭ࡸࡱࠠࡴࡲࡤࡧࡪࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡹ࡮ࡥࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨঢ")+dR2vHyAtl8pJN1+LiRcTVUWuth70DmPy(u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧণ")+str(tV4NTJHwly)+iUeoLOsbHqP(u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡇࡶࡢ࡫࡯ࡥࡧࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪত")+str(kzDFCG2nWXxBIK)+g4g6bfkPtVGU5lIM3(u"ࠬࠦࡍࡃࠢ࠰ࠤࠬথ")+str(Gwdk3rnsufKI2eNL5zWMqUhcHx10A)+hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩদ")+wsGBSE5nY94UXrdmxLRWKbie7+FvNyZqaLKw(u"ࠧࠡ࡟ࠪধ"))
		aHKzv76JCVnprbY8w(xW2Arao7YVOemw(u"ࠨࠩন"),iRoLg2m47tnDATBHGCSPNyx(u"ࠩࠪ঩"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"่ࠪฬ๊้ࠦฮาࠤู๊วฮหࠣ็ฬ็๊สࠢ็่ฯำๅ๋ๆࠪপ"),bUdr5Hahw6sY8xJ(u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤฯำๅ๋ๆ๊ࠤาาๅ่ࠢࠪফ")+str(tV4NTJHwly)+fprnld4CZo(u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣࠫব")+str(kzDFCG2nWXxBIK)+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠭ࠠๆ์฽หออ๊ห๋่้๋ࠢอศใ฻อࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮฯู้่้ࠣอใๅࠢํะอࠦลษไสลࠥ࠭ভ")+str(Gwdk3rnsufKI2eNL5zWMqUhcHx10A)+lc0dpSmwoPDjLnk(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣๅฬืฺสࠢาหห๋ว๊๊ࠡิฬࠦๅฺ่ส๋ࠥษๆࠡฮ๊หื้ࠠๅษࠣฮําฯࠡใํ๋๋ࠥำศฯฬࠤ่อแ๋ห่ࠣฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡษ็้฼๊่ษࠩম"))
		return hBvsQ7oCkKUdwjx58ml3EN(u"ࡉࡥࡱࡹࡥਨ")
	o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(FnBiAjthS8MkXs67W(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨয"),g4g6bfkPtVGU5lIM3(u"ࠩࠪর"),iRoLg2m47tnDATBHGCSPNyx(u"ࠪࠫ঱"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫ์๊ࠠหำํำࠥะอๆ์็ࠤฬ๊ๅๅใࠣรࠬল"),E6MIKdpBomef(u"ࠬอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥำฬๆ้ࠣฮ็ื๊ษษࠣࠫ঳")+str(tV4NTJHwly)+LiRcTVUWuth70DmPy(u"࠭ࠠๆ์฽หออ๊ห๋ࠢะ์อาไࠢไ๎์ࠦๅิษะอࠥ็วา฼ฬࠤฯ่ั๋สสࠤࠬ঴")+str(kzDFCG2nWXxBIK)+oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์์ึวࠡษ็้้็ࠠใัࠣ๎าะวอࠢห฽฻ࠦวๅ๊ๅฮ๊ࠥไหฯ่๎้ࠦๅ็ࠢส่ส์สา่อࠤส๊้ࠡฮ๊หื้ࠠ࠯๊่ࠢࠥอๆห่ࠢฮศ้ฯ๊ࠡอี๏ีࠠศๆสืฯ๋ัศำࠣฬฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡมࠪ঵"))
	if o07Z1tEB4n3ARCkVNu!=XzrqbGDIy54juixkMA(u"࠵਍"):
		aHKzv76JCVnprbY8w(hBvsQ7oCkKUdwjx58ml3EN(u"ࠨࠩশ"),lc0dpSmwoPDjLnk(u"ࠩࠪষ"),iUeoLOsbHqP(u"ࠪࠫস"),E6MIKdpBomef(u"ࠫฯ๋ࠠฦๆ฽หฦูࠦๆๆํอࠥะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩহ"))
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q(wRxoKs10Syj7V4edYhtP(u"ࠬࡔࡏࡕࡋࡆࡉࠬ঺"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+sTcr7iDp5eFt4RoLMhuwq1A(u"࠭ࠠࠡࠢࡘࡷࡪࡸࠠࡤࡣࡱࡧࡪࡲࡥࡥࠢࡷ࡬ࡪࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡࡱࡩࠤࡹ࡮ࡥࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ঻")+dR2vHyAtl8pJN1+FnBiAjthS8MkXs67W(u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠ়ࠦࠧ")+wsGBSE5nY94UXrdmxLRWKbie7+zqdvcbP5L8BHh(u"ࠨࠢࡠࠫঽ"))
		return zqdvcbP5L8BHh(u"ࡊࡦࡲࡳࡦ਩")
	LOHZ4o9m7p6ebfTYXGIdz5PWs3q(wRxoKs10Syj7V4edYhtP(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩা"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+lc0dpSmwoPDjLnk(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵࡷࡥࡷࡺࡥࡥࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹࠨি"))
	dzrSRqtj49so = XOL34TuqseWy2gpYfd()
	dzrSRqtj49so.create(wsGBSE5nY94UXrdmxLRWKbie7,yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬী"))
	qtBFONbSgr0RKM = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࡙ࡸࡵࡦਪ")
	LCaAcrp8R57YSD = MQbODJoPV2w8TEAg4zXZdjLxSW.time()
	if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: beDxKEZgcHsQN10jXPIhGfwTvM63mt = open(wsGBSE5nY94UXrdmxLRWKbie7,UTelCo0ihE1d5R(u"ࠬࡽࡢࠨু"))
	else: beDxKEZgcHsQN10jXPIhGfwTvM63mt = open(wsGBSE5nY94UXrdmxLRWKbie7.decode(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ࡵࡵࡨ࠻ࠫূ")),kEhAHvti6Vnsfx(u"ࠧࡸࡤࠪৃ"))
	if QNHsaf7u3DSjiJ40ARCKYO==FvNyZqaLKw(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧৄ"):
		for CQMipytPbq in range(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠶਎"),dac3D2xo6WPu+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠶਎")):
			ELbNB92cOh5dqtpVmi40kY = gI487voLsArVqW6Ffp[CQMipytPbq-hBvsQ7oCkKUdwjx58ml3EN(u"࠷ਏ")]
			if not ELbNB92cOh5dqtpVmi40kY.startswith(XzrqbGDIy54juixkMA(u"ࠩ࡫ࡸࡹࡶࠧ৅")):
				if ELbNB92cOh5dqtpVmi40kY.startswith(Me28A1sBLNIgUp5YCDyvT(u"ࠪ࠳࠴࠭৆")): ELbNB92cOh5dqtpVmi40kY = dR2vHyAtl8pJN1.split(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫ࠿࠭ে"),E6MIKdpBomef(u"࠱ਐ"))[UTelCo0ihE1d5R(u"࠱਑")]+iRoLg2m47tnDATBHGCSPNyx(u"ࠬࡀࠧৈ")+ELbNB92cOh5dqtpVmi40kY
				elif ELbNB92cOh5dqtpVmi40kY.startswith(yA5z6LIXBlo41PRVMY87wOisFp(u"࠭࠯ࠨ৉")): ELbNB92cOh5dqtpVmi40kY = RfKuIXwPAiWtmyF(dR2vHyAtl8pJN1,bUdr5Hahw6sY8xJ(u"ࠧࡶࡴ࡯ࠫ৊"))+ELbNB92cOh5dqtpVmi40kY
				else: ELbNB92cOh5dqtpVmi40kY = dR2vHyAtl8pJN1.rsplit(dshJSmRqeiP9nap2(u"ࠨ࠱ࠪো"),iUeoLOsbHqP(u"࠳਒"))[E6MIKdpBomef(u"࠳ਓ")]+FnBiAjthS8MkXs67W(u"ࠩ࠲ࠫৌ")+ELbNB92cOh5dqtpVmi40kY
			zGmyJhleoQZ = DJ1rx9fvXIgUS7sZkVlOeGHb.request(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠪࡋࡊ্࡚ࠧ"),ELbNB92cOh5dqtpVmi40kY,headers=vqNwzh36FVc,verify=dshJSmRqeiP9nap2(u"ࡌࡡ࡭ࡵࡨਫ"))
			nL7q2gowIsPCWkRydufQZ = zGmyJhleoQZ.content
			zGmyJhleoQZ.close()
			beDxKEZgcHsQN10jXPIhGfwTvM63mt.write(nL7q2gowIsPCWkRydufQZ)
			OyoFMlKmTs2aqvHjZ40Vu = MQbODJoPV2w8TEAg4zXZdjLxSW.time()
			VycYE6jvXI7DdJB04Us1NnzMhG9 = OyoFMlKmTs2aqvHjZ40Vu-LCaAcrp8R57YSD
			SKQabWcXOG1nDVh3eig5vop = VycYE6jvXI7DdJB04Us1NnzMhG9//CQMipytPbq
			DD8QaG3VRoAXzc7i = SKQabWcXOG1nDVh3eig5vop*(dac3D2xo6WPu+SO94xq1RAkMm2uF(u"࠵ਔ"))
			DwKL7mU8613NzCkMBsglEyQoqcO = DD8QaG3VRoAXzc7i-VycYE6jvXI7DdJB04Us1NnzMhG9
			FFBJqkrThNeWfiaZPE5Aws9uGdp(dzrSRqtj49so,int(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠷࠰࠱ਖ")*CQMipytPbq//(dac3D2xo6WPu+S4SOKF2QbBhjCd3RrVMuHIzE(u"࠶ਕ"))),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬৎ"),iRoLg2m47tnDATBHGCSPNyx(u"ࠬาไษ่่ࠢๆࠦวๅใํำ๏๎࠺࠮ࠢส่ัุมࠡำๅ้ࠬ৏"),str(CQMipytPbq*xS7NEXG8nLsUiB9t6rbzM//cMR1f3D2UeyrLKXoYVPt8)+lc0dpSmwoPDjLnk(u"࠭࠯ࠨ৐")+str(tV4NTJHwly)+E6MIKdpBomef(u"ࠧࠡࡏࡅࠤ้ࠥࠦࠠไอࠤ๊ะศใ์࠽ࠤࠬ৑")+MQbODJoPV2w8TEAg4zXZdjLxSW.strftime(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠣࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥ৒"),MQbODJoPV2w8TEAg4zXZdjLxSW.gmtime(DwKL7mU8613NzCkMBsglEyQoqcO))+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠩࠣไࠬ৓"))
			if dzrSRqtj49so.iscanceled():
				qtBFONbSgr0RKM = xW2Arao7YVOemw(u"ࡆࡢ࡮ࡶࡩਬ")
				break
	else:
		CQMipytPbq = SO94xq1RAkMm2uF(u"࠰ਗ")
		for nL7q2gowIsPCWkRydufQZ in zGmyJhleoQZ.iter_content(chunk_size=xS7NEXG8nLsUiB9t6rbzM):
			beDxKEZgcHsQN10jXPIhGfwTvM63mt.write(nL7q2gowIsPCWkRydufQZ)
			CQMipytPbq = CQMipytPbq+FnBiAjthS8MkXs67W(u"࠲ਘ")
			OyoFMlKmTs2aqvHjZ40Vu = MQbODJoPV2w8TEAg4zXZdjLxSW.time()
			VycYE6jvXI7DdJB04Us1NnzMhG9 = OyoFMlKmTs2aqvHjZ40Vu-LCaAcrp8R57YSD
			SKQabWcXOG1nDVh3eig5vop = VycYE6jvXI7DdJB04Us1NnzMhG9/CQMipytPbq
			DD8QaG3VRoAXzc7i = SKQabWcXOG1nDVh3eig5vop*(dac3D2xo6WPu+Cu1704YofAbr3QTm(u"࠳ਙ"))
			DwKL7mU8613NzCkMBsglEyQoqcO = DD8QaG3VRoAXzc7i-VycYE6jvXI7DdJB04Us1NnzMhG9
			FFBJqkrThNeWfiaZPE5Aws9uGdp(dzrSRqtj49so,int(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠵࠵࠶ਛ")*CQMipytPbq/(dac3D2xo6WPu+fprnld4CZo(u"࠴ਚ"))),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪหู้ืาࠢไ์็ࠦ็้่ࠢ็ฬ์ࠠหะี๎๋ࠦๅๅใࠣห้็๊ะ์๋ࠫ৔"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠫั๊ศࠡ็็ๅࠥอไโ์า๎ํࡀ࠭ࠡษ็ะืวࠠาไ่ࠫ৕"),str(CQMipytPbq*xS7NEXG8nLsUiB9t6rbzM//cMR1f3D2UeyrLKXoYVPt8)+zqdvcbP5L8BHh(u"ࠬ࠵ࠧ৖")+str(tV4NTJHwly)+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࠠࡎࡄࠣࠤ่ࠥࠦใฬ้ࠣฯฮโ๋࠼ࠣࠫৗ")+MQbODJoPV2w8TEAg4zXZdjLxSW.strftime(iRoLg2m47tnDATBHGCSPNyx(u"ࠢࠦࡊ࠽ࠩࡒࡀࠥࡔࠤ৘"),MQbODJoPV2w8TEAg4zXZdjLxSW.gmtime(DwKL7mU8613NzCkMBsglEyQoqcO))+SO94xq1RAkMm2uF(u"ࠨࠢใࠫ৙"))
			if dzrSRqtj49so.iscanceled():
				qtBFONbSgr0RKM = E6MIKdpBomef(u"ࡇࡣ࡯ࡷࡪਭ")
				break
		zGmyJhleoQZ.close()
	beDxKEZgcHsQN10jXPIhGfwTvM63mt.close()
	dzrSRqtj49so.close()
	if not qtBFONbSgr0RKM:
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q(kEhAHvti6Vnsfx(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ৚"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪࠤࠥࠦࡕࡴࡧࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠵ࡩ࡯ࡶࡨࡶࡷࡻࡰࡵࡧࡧࠤࡹ࡮ࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡴࡷࡵࡣࡦࡵࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ৛")+dR2vHyAtl8pJN1+SO94xq1RAkMm2uF(u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫড়")+wsGBSE5nY94UXrdmxLRWKbie7+SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠬࠦ࡝ࠨঢ়"))
		aHKzv76JCVnprbY8w(wRxoKs10Syj7V4edYhtP(u"࠭ࠧ৞"),E6MIKdpBomef(u"ࠧࠨয়"),iRoLg2m47tnDATBHGCSPNyx(u"ࠨࠩৠ"),g4g6bfkPtVGU5lIM3(u"ࠩอ้ࠥหไ฻ษฤࠤ฾๋ไ๋หࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧৡ"))
		return xW2Arao7YVOemw(u"ࡖࡵࡹࡪਮ")
	LOHZ4o9m7p6ebfTYXGIdz5PWs3q(bUdr5Hahw6sY8xJ(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪৢ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࡩࡵࡷ࡯࡮ࡲࡥࡩ࡫ࡤࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࡱࡿࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪৣ")+dR2vHyAtl8pJN1+FnBiAjthS8MkXs67W(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬ৤")+wsGBSE5nY94UXrdmxLRWKbie7+oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠭ࠠ࡞ࠩ৥"))
	aHKzv76JCVnprbY8w(bUdr5Hahw6sY8xJ(u"ࠧࠨ০"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨࠩ১"),LiRcTVUWuth70DmPy(u"ࠩࠪ২"),Cu1704YofAbr3QTm(u"ࠪฮ๊ࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠣฬ๋าวฮࠩ৩"))
	return FvNyZqaLKw(u"ࡗࡶࡺ࡫ਯ")
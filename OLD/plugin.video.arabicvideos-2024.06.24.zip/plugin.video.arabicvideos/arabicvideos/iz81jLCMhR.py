# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
headers = { 'User-Agent' : '' }
cTJphS1nFz5EUgNWm86C = 'AKOAM'
mmDwMlfoHtG5XT19VLIWqCR8i = '_AKO_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
iqEntjuM5hGB = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==70: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==71: zpXG3Ky6ou8ndWHkb4 = mgAQC3oRrjWLbHcE16dTMaJ7phsXV(url)
	elif mode==72: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,text)
	elif mode==73: zpXG3Ky6ou8ndWHkb4 = igsaMLoS9H2n(url)
	elif mode==74: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==79: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',79,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'سلسلة افلام','',79,'','','سلسلة افلام')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'سلاسل منوعة','',79,'','','سلسلة')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	DDXTwbRBaj3e2rSsPQ = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,NBm2aWhPzoTpdYn,'',headers,'','AKOAM-MENU-1st')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="partions"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			if title not in DDXTwbRBaj3e2rSsPQ:
				cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,71)
	return BBlXpmUyhFDwNtCVAHoE
def mgAQC3oRrjWLbHcE16dTMaJ7phsXV(url):
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,url,'',headers,'','AKOAM-CATEGORIES-1st')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('sect_parts(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			title = title.strip(' ')
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,72)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'جميع الفروع',url,72)
	else: xoiXMWjJC3pnQqurIGPkRSl8e(url,'')
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(url,type):
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,url,'',headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('section_title featured_title(.*?)subjects-crousel',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	elif type=='search':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('akoam_result(.*?)<script',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	elif type=='more':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('section_title more_title(.*?)footer_bottom_services',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	else:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('navigation(.*?)<script',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not items and EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace('\n','').strip(' ')
		title = DwNC3gEonizsB6a0v1F(title)
		if any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in iqEntjuM5hGB): cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,73,VFqpJjRySZvgi)
		else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,73,VFqpJjRySZvgi)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="pagination"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall("</li><li >.*?href='(.*?)'>(.*?)<",UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,72,'','',type)
	return
def GdTYKcACjnDtRfOXQu8z3yWb(url):
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,url,'',headers,True,'AKOAM-SECTIONS-2nd')
	dR2vHyAtl8pJN1 = GGvHJKP9LUxEk10Fw.findall('"href","(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1[1]
	return dR2vHyAtl8pJN1
def igsaMLoS9H2n(url):
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,url,'',headers,True,'AKOAM-SECTIONS-1st')
	qqSpXI6GDUtfu1hO = GGvHJKP9LUxEk10Fw.findall('"(https*://akwam.net/\w+.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	aa9NkRL4K12UwWVxQue5j = GGvHJKP9LUxEk10Fw.findall('"(https*://underurl.com/\w+.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if qqSpXI6GDUtfu1hO or aa9NkRL4K12UwWVxQue5j:
		if qqSpXI6GDUtfu1hO: XwyU6PQgprMI0 = qqSpXI6GDUtfu1hO[0]
		elif aa9NkRL4K12UwWVxQue5j: XwyU6PQgprMI0 = GdTYKcACjnDtRfOXQu8z3yWb(aa9NkRL4K12UwWVxQue5j[0])
		XwyU6PQgprMI0 = GhPlajzTxY8(XwyU6PQgprMI0)
		import AjTX6bWUoJ
		if '/series/' in XwyU6PQgprMI0 or '/shows/' in XwyU6PQgprMI0: AjTX6bWUoJ.hWPvGlXZ5arzV7(XwyU6PQgprMI0)
		else: AjTX6bWUoJ.SUfe4unWoXBNFz90xqy(XwyU6PQgprMI0)
		return
	NbE4qnzmPKGWtjYpoRL3HTS1A = GGvHJKP9LUxEk10Fw.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if NbE4qnzmPKGWtjYpoRL3HTS1A and hNCJPTucIV7GOSR0HytZ6eQrqEUpw(cTJphS1nFz5EUgNWm86C,url,NbE4qnzmPKGWtjYpoRL3HTS1A): return
	items = GGvHJKP9LUxEk10Fw.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		title = DwNC3gEonizsB6a0v1F(title)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,73)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not EeQqAGc0W5r6nlBbChwfZL:
		From8aTqdhCbPs('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,VFqpJjRySZvgi,UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	name = name.strip(' ')
	if 'sub_epsiode_title' in UCEFMfKbgpd:
		items = GGvHJKP9LUxEk10Fw.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	else:
		ssNgOHGDvcWKPh1k5i = GGvHJKP9LUxEk10Fw.findall('sub_file_title\'>(.*?) - <i>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		items = []
		for filename in ssNgOHGDvcWKPh1k5i:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل','') ]
	count = 0
	eyUmvNFiYsE,ESZUFl52KI7v9Vyb40f = [],[]
	size = len(items)
	for title,filename in items:
		eBjoKP40GyrEFp = ''
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: eBjoKP40GyrEFp = filename.split('.')[-1]
		title = title.replace('\n','').strip(' ')
		eyUmvNFiYsE.append(title)
		ESZUFl52KI7v9Vyb40f.append(count)
		count += 1
	if size>0:
		if any(hieW1zRUG5w9AykJjv0X in name for hieW1zRUG5w9AykJjv0X in iqEntjuM5hGB):
			if size==1:
				z0jyetbQwKrIclL9vJW = 0
			else:
				z0jyetbQwKrIclL9vJW = D1DJtzviFZSrA('اختر الفيديو المناسب:', eyUmvNFiYsE)
				if z0jyetbQwKrIclL9vJW == -1: return
			SUfe4unWoXBNFz90xqy(url+'?section='+str(1+ESZUFl52KI7v9Vyb40f[size-z0jyetbQwKrIclL9vJW-1]))
		else:
			for umP72LtwzUTWHFAlJVyheEp5 in reversed(range(size)):
				title = name + ' - ' + eyUmvNFiYsE[umP72LtwzUTWHFAlJVyheEp5]
				title = title.replace('\n','').strip(' ')
				ELbNB92cOh5dqtpVmi40kY = url + '?section='+str(size-umP72LtwzUTWHFAlJVyheEp5)
				cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,74,VFqpJjRySZvgi)
	else:
		cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+'الرابط ليس فيديو','',9999,VFqpJjRySZvgi)
	return
def SUfe4unWoXBNFz90xqy(url):
	dR2vHyAtl8pJN1,qUGxSK2VwsiBAdkDZnJ605vQeg = url.split('?section=')
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',dR2vHyAtl8pJN1,'',headers,True,'','AKOAM-PLAY_AKOAM-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	E0ygwCkqhNBA9df6aJ5vU7 = EeQqAGc0W5r6nlBbChwfZL[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	E0ygwCkqhNBA9df6aJ5vU7 = E0ygwCkqhNBA9df6aJ5vU7 + 'direct_link_box'
	EHDeldN7L2k19JBUqhmsuSXiwV = GGvHJKP9LUxEk10Fw.findall('epsoide_box(.*?)direct_link_box',E0ygwCkqhNBA9df6aJ5vU7,GGvHJKP9LUxEk10Fw.DOTALL)
	qUGxSK2VwsiBAdkDZnJ605vQeg = len(EHDeldN7L2k19JBUqhmsuSXiwV)-int(qUGxSK2VwsiBAdkDZnJ605vQeg)
	UCEFMfKbgpd = EHDeldN7L2k19JBUqhmsuSXiwV[qUGxSK2VwsiBAdkDZnJ605vQeg]
	uuIjMn1YTf687WlRcOmhq4G23H = []
	WWwaDomhGVpzP = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = GGvHJKP9LUxEk10Fw.findall("class='download_btn.*?href='(.*?)'",UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY in items:
		uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY+'?named=________akoam')
	items = GGvHJKP9LUxEk10Fw.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for s9xUeJTuairRcNWPDkz,ELbNB92cOh5dqtpVmi40kY in items:
		s9xUeJTuairRcNWPDkz = s9xUeJTuairRcNWPDkz.split('/')[-1]
		s9xUeJTuairRcNWPDkz = s9xUeJTuairRcNWPDkz.split('.')[0]
		if s9xUeJTuairRcNWPDkz in WWwaDomhGVpzP:
			uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY+'?named='+WWwaDomhGVpzP[s9xUeJTuairRcNWPDkz]+'________akoam')
		else: uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY+'?named='+s9xUeJTuairRcNWPDkz+'________akoam')
	if not uuIjMn1YTf687WlRcOmhq4G23H:
		message = GGvHJKP9LUxEk10Fw.findall('sub-no-file.*?\n(.*?)\n',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if message: aHKzv76JCVnprbY8w('','','رسالة من الموقع الاصلي',message[0])
	else:
		import XXPcDGxLdW
		XXPcDGxLdW.YguVs5RJFwDK6X8E(uuIjMn1YTf687WlRcOmhq4G23H,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	aKRILTAj1HC5c = search.replace(' ','%20')
	url = NBm2aWhPzoTpdYn + '/search/'+aKRILTAj1HC5c
	zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,'search')
	return
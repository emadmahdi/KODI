# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
headers = { 'User-Agent' : '' }
cTJphS1nFz5EUgNWm86C = 'AKOAMCAM'
mmDwMlfoHtG5XT19VLIWqCR8i = '_AKC_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
DDXTwbRBaj3e2rSsPQ = ['مصارعة']
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==350: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==351: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,text)
	elif mode==352: zpXG3Ky6ou8ndWHkb4 = hWPvGlXZ5arzV7(url)
	elif mode==353: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==354: zpXG3Ky6ou8ndWHkb4 = hWJg9P6lEYT5aGDizcb(url,'FILTERS___'+text)
	elif mode==355: zpXG3Ky6ou8ndWHkb4 = hWJg9P6lEYT5aGDizcb(url,'CATEGORIES___'+text)
	elif mode==356: zpXG3Ky6ou8ndWHkb4 = TTGrwKO8SlP7UNbMZDjaH(url)
	elif mode==357: zpXG3Ky6ou8ndWHkb4 = fwkpdiO2HBR(url)
	elif mode==359: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	cd0aGwCPExbFU5pYNu8r('link',mmDwMlfoHtG5XT19VLIWqCR8i+'[COLOR FFFFFF00]هذا الموقع مغلق[/COLOR]','',8)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',359,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فلتر محدد',NBm2aWhPzoTpdYn,356)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فلتر كامل',NBm2aWhPzoTpdYn,357)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,NBm2aWhPzoTpdYn,'',headers,'','AKOAMCAM-MENU-1st')
	dR2vHyAtl8pJN1 = GGvHJKP9LUxEk10Fw.findall('recently-container.*?href="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if dR2vHyAtl8pJN1: dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1[0]
	else: dR2vHyAtl8pJN1 = NBm2aWhPzoTpdYn
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'اضيف حديثا',dR2vHyAtl8pJN1,351)
	dR2vHyAtl8pJN1 = GGvHJKP9LUxEk10Fw.findall('@id":"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if dR2vHyAtl8pJN1: dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1[0]
	else: dR2vHyAtl8pJN1 = NBm2aWhPzoTpdYn
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'المميزة',dR2vHyAtl8pJN1,351,'','','featured')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('main-categories-list(.*?)main-categories-list',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?class="font.*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			if title not in DDXTwbRBaj3e2rSsPQ: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,351)
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="categories-box(.*?)<footer',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			ELbNB92cOh5dqtpVmi40kY = DwNC3gEonizsB6a0v1F(ELbNB92cOh5dqtpVmi40kY)
			if title not in DDXTwbRBaj3e2rSsPQ: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,351)
	return BBlXpmUyhFDwNtCVAHoE
def TTGrwKO8SlP7UNbMZDjaH(website=''):
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,NBm2aWhPzoTpdYn,'',headers,'','AKOAMCAM-MENU-1st')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="menu(.*?)<nav',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?text">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			if title not in DDXTwbRBaj3e2rSsPQ:
				title = title+' مصنفة'
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,355)
		if website=='': cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return BBlXpmUyhFDwNtCVAHoE
def fwkpdiO2HBR(website=''):
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,NBm2aWhPzoTpdYn,'',headers,'','AKOAMCAM-MENU-1st')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="menu(.*?)<nav',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?text">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			if title not in DDXTwbRBaj3e2rSsPQ:
				title = title+' مفلترة'
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,354)
		if website=='': cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return BBlXpmUyhFDwNtCVAHoE
def xoiXMWjJC3pnQqurIGPkRSl8e(url,type=''):
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(BXnrZSgERcxHvbVQ4,url,'',headers,True,'AKOAMCAM-TITLES-1st')
	if type=='featured': EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('swiper-container(.*?)swiper-button-prev',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	else: EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="container"(.*?)main-footer',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('xlink:href="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		IcJOGsq3Ff7EmkiLx = []
		for VFqpJjRySZvgi,ELbNB92cOh5dqtpVmi40kY,title in items:
			title = DwNC3gEonizsB6a0v1F(title)
			if 'الحلقة' in title or 'الحلقه' in title:
				qUGxSK2VwsiBAdkDZnJ605vQeg = GGvHJKP9LUxEk10Fw.findall('(.*?) (الحلقة|الحلقه) \d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
				if qUGxSK2VwsiBAdkDZnJ605vQeg:
					title = '_MOD_' + qUGxSK2VwsiBAdkDZnJ605vQeg[0][0]
					if title not in IcJOGsq3Ff7EmkiLx:
						cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,352,VFqpJjRySZvgi)
						IcJOGsq3Ff7EmkiLx.append(title)
			elif 'مسلسل' in title:
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,352,VFqpJjRySZvgi)
			else: cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,353,VFqpJjRySZvgi)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('pagination(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href=["\'](.*?)["\'].*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			ELbNB92cOh5dqtpVmi40kY = DwNC3gEonizsB6a0v1F(ELbNB92cOh5dqtpVmi40kY)
			title = DwNC3gEonizsB6a0v1F(title)
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,351)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	aKRILTAj1HC5c = search.replace(' ','+')
	url = NBm2aWhPzoTpdYn + '/?s='+aKRILTAj1HC5c
	zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url)
	return
def hWPvGlXZ5arzV7(url):
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,url,'',headers,True,'AKOAMCAM-EPISODES-1st')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('text-white">الحلقات(.*?)<header',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		kxoVRpfCEMyW15BFQu4n7G2 = GGvHJKP9LUxEk10Fw.findall('href="(http.*?)".*?src="(.*?)".*?alt="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in kxoVRpfCEMyW15BFQu4n7G2:
			if 'الحلقة' in title or 'الحلقه' in title: cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,353,VFqpJjRySZvgi)
	else:
		VFqpJjRySZvgi = cEZpW924rqNYm5.getInfoLabel('ListItem.Icon')
		if BBlXpmUyhFDwNtCVAHoE.count('<title>')>1: title = GGvHJKP9LUxEk10Fw.findall('<title>(.*?)<',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)[1]
		else: title = 'رابط التشغيل'
		cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,353,VFqpJjRySZvgi)
	return
def SUfe4unWoXBNFz90xqy(url):
	zzvBg3ShiamAZ,eyUmvNFiYsE = [],[]
	YYnqIymCMgXosB8deFcD52h3Z = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',url,'','','','','AKOAMCAM-PLAY-1st')
	BBlXpmUyhFDwNtCVAHoE = YYnqIymCMgXosB8deFcD52h3Z.content
	XXKY1GIJm9BeMw0jfdSWRtEi = GGvHJKP9LUxEk10Fw.findall('post_id=(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if XXKY1GIJm9BeMw0jfdSWRtEi:
		XXKY1GIJm9BeMw0jfdSWRtEi = XXKY1GIJm9BeMw0jfdSWRtEi[0]
		headers = {'User-Agent':'','Content-Type':'application/x-www-form-urlencoded'}
		data = {'post_id':XXKY1GIJm9BeMw0jfdSWRtEi}
		dR2vHyAtl8pJN1 = NBm2aWhPzoTpdYn+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Watch.php'
		GHEwlub3VtPyjZTMA4ceQgXFBIrKnN = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'POST',dR2vHyAtl8pJN1,data,headers,'','','AKOAMCAM-PLAY-1st')
		X3in5vNhqwWEG2TafmVCrFbSYDxjoK = GHEwlub3VtPyjZTMA4ceQgXFBIrKnN.content
		items = GGvHJKP9LUxEk10Fw.findall('data-server="(.*?)".*?class="text">(.*?)<',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
		for r9yaxqiB7EhQMfHjWoZTUn3LdvG,name in items:
			ELbNB92cOh5dqtpVmi40kY = 'https://w.akoam.cam/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Server.php'
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?postid='+XXKY1GIJm9BeMw0jfdSWRtEi+'&serverid='+r9yaxqiB7EhQMfHjWoZTUn3LdvG+'?named='+name+'__watch'
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
			eyUmvNFiYsE.append(name)
		dR2vHyAtl8pJN1 = NBm2aWhPzoTpdYn+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Download.php'
		GHEwlub3VtPyjZTMA4ceQgXFBIrKnN = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'POST',dR2vHyAtl8pJN1,data,headers,'','','AKOAMCAM-PLAY-1st')
		X3in5vNhqwWEG2TafmVCrFbSYDxjoK = GHEwlub3VtPyjZTMA4ceQgXFBIrKnN.content
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?class="text">(.*?)<',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.strip(' ')
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named='+title+'__download'
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
			eyUmvNFiYsE.append(title)
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(zzvBg3ShiamAZ,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def hWJg9P6lEYT5aGDizcb(url,filter):
	A2kRm7N8gIn1MTrWZF0Yp5e = ['cat','genre','release-year','quality','orderby']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter=='': zTi1IvPRBr,CcMQl4P9H8SkouF7srzBYdDKUNA = '',''
	else: zTi1IvPRBr,CcMQl4P9H8SkouF7srzBYdDKUNA = filter.split('___')
	if type=='CATEGORIES':
		if A2kRm7N8gIn1MTrWZF0Yp5e[0]+'=' not in zTi1IvPRBr: BBskpK6cGZJ = A2kRm7N8gIn1MTrWZF0Yp5e[0]
		for umP72LtwzUTWHFAlJVyheEp5 in range(len(A2kRm7N8gIn1MTrWZF0Yp5e[0:-1])):
			if A2kRm7N8gIn1MTrWZF0Yp5e[umP72LtwzUTWHFAlJVyheEp5]+'=' in zTi1IvPRBr: BBskpK6cGZJ = A2kRm7N8gIn1MTrWZF0Yp5e[umP72LtwzUTWHFAlJVyheEp5+1]
		i2i6oT5O34GLAgyPs8DdIfV = zTi1IvPRBr+'&'+BBskpK6cGZJ+'=0'
		WtVSCYeOJDGQf5sq8KZxkzyXwvBF = CcMQl4P9H8SkouF7srzBYdDKUNA+'&'+BBskpK6cGZJ+'=0'
		sDnjCtlaGyxmr9fqK = i2i6oT5O34GLAgyPs8DdIfV.strip('&')+'___'+WtVSCYeOJDGQf5sq8KZxkzyXwvBF.strip('&')
		BnNGcaxDl0pPVdmq3j1kQu6HJEs4 = fx0tQnZhGieDkA(CcMQl4P9H8SkouF7srzBYdDKUNA,'all')
		dR2vHyAtl8pJN1 = url+'?'+BnNGcaxDl0pPVdmq3j1kQu6HJEs4
	elif type=='FILTERS':
		QHWZwB3stnOp5SghLfl2zir6YCI = fx0tQnZhGieDkA(zTi1IvPRBr,'modified_values')
		QHWZwB3stnOp5SghLfl2zir6YCI = GhPlajzTxY8(QHWZwB3stnOp5SghLfl2zir6YCI)
		if CcMQl4P9H8SkouF7srzBYdDKUNA!='': CcMQl4P9H8SkouF7srzBYdDKUNA = fx0tQnZhGieDkA(CcMQl4P9H8SkouF7srzBYdDKUNA,'all')
		if CcMQl4P9H8SkouF7srzBYdDKUNA=='': dR2vHyAtl8pJN1 = url
		else: dR2vHyAtl8pJN1 = url+'?'+CcMQl4P9H8SkouF7srzBYdDKUNA
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'أظهار قائمة الفيديو التي تم اختيارها',dR2vHyAtl8pJN1,351,'','1')
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+' [[   '+QHWZwB3stnOp5SghLfl2zir6YCI+'   ]]',dR2vHyAtl8pJN1,351,'','1')
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,url,'',headers,True,'AKOAMCAM-FILTERS_MENU-1st')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('<form id(.*?)</form>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	nQKyI93hUT2ZGl6zimxDWe04ckj = GGvHJKP9LUxEk10Fw.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	dict = {}
	for mmRDx1Zhfjq4oFdsNey2EwCBlUOQv,name,UCEFMfKbgpd in nQKyI93hUT2ZGl6zimxDWe04ckj:
		items = GGvHJKP9LUxEk10Fw.findall('<option(.*?)>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if '=' not in dR2vHyAtl8pJN1: dR2vHyAtl8pJN1 = url
		if type=='CATEGORIES':
			if BBskpK6cGZJ!=mmRDx1Zhfjq4oFdsNey2EwCBlUOQv: continue
			elif len(items)<=1:
				if mmRDx1Zhfjq4oFdsNey2EwCBlUOQv==A2kRm7N8gIn1MTrWZF0Yp5e[-1]: xoiXMWjJC3pnQqurIGPkRSl8e(dR2vHyAtl8pJN1)
				else: hWJg9P6lEYT5aGDizcb(dR2vHyAtl8pJN1,'CATEGORIES___'+sDnjCtlaGyxmr9fqK)
				return
			else:
				if mmRDx1Zhfjq4oFdsNey2EwCBlUOQv==A2kRm7N8gIn1MTrWZF0Yp5e[-1]: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع',dR2vHyAtl8pJN1,351,'','1')
				else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع',dR2vHyAtl8pJN1,355,'','',sDnjCtlaGyxmr9fqK)
		elif type=='FILTERS':
			i2i6oT5O34GLAgyPs8DdIfV = zTi1IvPRBr+'&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'=0'
			WtVSCYeOJDGQf5sq8KZxkzyXwvBF = CcMQl4P9H8SkouF7srzBYdDKUNA+'&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'=0'
			sDnjCtlaGyxmr9fqK = i2i6oT5O34GLAgyPs8DdIfV+'___'+WtVSCYeOJDGQf5sq8KZxkzyXwvBF
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع : '+name,dR2vHyAtl8pJN1,354,'','',sDnjCtlaGyxmr9fqK)
		dict[mmRDx1Zhfjq4oFdsNey2EwCBlUOQv] = {}
		for hieW1zRUG5w9AykJjv0X,RHb9zAjcuTIoyZ0aDgS1pQYmUs8 in items:
			if RHb9zAjcuTIoyZ0aDgS1pQYmUs8 in DDXTwbRBaj3e2rSsPQ: continue
			if 'value' not in hieW1zRUG5w9AykJjv0X: hieW1zRUG5w9AykJjv0X = RHb9zAjcuTIoyZ0aDgS1pQYmUs8
			else: hieW1zRUG5w9AykJjv0X = GGvHJKP9LUxEk10Fw.findall('"(.*?)"',hieW1zRUG5w9AykJjv0X,GGvHJKP9LUxEk10Fw.DOTALL)[0]
			dict[mmRDx1Zhfjq4oFdsNey2EwCBlUOQv][hieW1zRUG5w9AykJjv0X] = RHb9zAjcuTIoyZ0aDgS1pQYmUs8
			i2i6oT5O34GLAgyPs8DdIfV = zTi1IvPRBr+'&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'='+RHb9zAjcuTIoyZ0aDgS1pQYmUs8
			WtVSCYeOJDGQf5sq8KZxkzyXwvBF = CcMQl4P9H8SkouF7srzBYdDKUNA+'&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'='+hieW1zRUG5w9AykJjv0X
			KPcDQTE3e8duMHO6Lbgo1n = i2i6oT5O34GLAgyPs8DdIfV+'___'+WtVSCYeOJDGQf5sq8KZxkzyXwvBF
			title = RHb9zAjcuTIoyZ0aDgS1pQYmUs8+' : '#+dict[mmRDx1Zhfjq4oFdsNey2EwCBlUOQv]['0']
			title = RHb9zAjcuTIoyZ0aDgS1pQYmUs8+' : '+name
			if type=='FILTERS': cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,354,'','',KPcDQTE3e8duMHO6Lbgo1n)
			elif type=='CATEGORIES' and A2kRm7N8gIn1MTrWZF0Yp5e[-2]+'=' in zTi1IvPRBr:
				BnNGcaxDl0pPVdmq3j1kQu6HJEs4 = fx0tQnZhGieDkA(WtVSCYeOJDGQf5sq8KZxkzyXwvBF,'all')
				XwyU6PQgprMI0 = url+'?'+BnNGcaxDl0pPVdmq3j1kQu6HJEs4
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,XwyU6PQgprMI0,351,'','1')
			else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,355,'','',KPcDQTE3e8duMHO6Lbgo1n)
	return
def fx0tQnZhGieDkA(FZj067Q2PlC8EsG9c5yiWpzNRq,mode):
	FZj067Q2PlC8EsG9c5yiWpzNRq = FZj067Q2PlC8EsG9c5yiWpzNRq.strip('&')
	HG4gSjopqQwsPeivrcmn = {}
	if '=' in FZj067Q2PlC8EsG9c5yiWpzNRq:
		items = FZj067Q2PlC8EsG9c5yiWpzNRq.split('&')
		for BrVNsC72UYWES4A in items:
			RRSq2Qx0MfkFHLt,hieW1zRUG5w9AykJjv0X = BrVNsC72UYWES4A.split('=')
			HG4gSjopqQwsPeivrcmn[RRSq2Qx0MfkFHLt] = hieW1zRUG5w9AykJjv0X
	BbgO8pxWfVA41KGzed = ''
	ppwVAoqiOnjJZad = ['cat','genre','release-year','quality','orderby']
	for key in ppwVAoqiOnjJZad:
		if key in list(HG4gSjopqQwsPeivrcmn.keys()): hieW1zRUG5w9AykJjv0X = HG4gSjopqQwsPeivrcmn[key]
		else: hieW1zRUG5w9AykJjv0X = '0'
		if mode=='modified_values' and hieW1zRUG5w9AykJjv0X!='0': BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed+' + '+hieW1zRUG5w9AykJjv0X
		elif mode=='modified_filters' and hieW1zRUG5w9AykJjv0X!='0': BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed+'&'+key+'='+hieW1zRUG5w9AykJjv0X
		elif mode=='all': BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed+'&'+key+'='+hieW1zRUG5w9AykJjv0X
	BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed.strip(' + ')
	BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed.strip('&')
	return BbgO8pxWfVA41KGzed
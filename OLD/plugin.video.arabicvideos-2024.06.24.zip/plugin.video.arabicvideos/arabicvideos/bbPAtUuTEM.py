# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'YOUTUBE'
mmDwMlfoHtG5XT19VLIWqCR8i = '_YUT_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
uLs2eNVw8mngEzdCavS = 0
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text,type,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,name,nWO8c3IgspK67QX):
	if	 mode==140: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==141: zpXG3Ky6ou8ndWHkb4 = dUgA4qerOv3xWhm90pVjy7(url,name,nWO8c3IgspK67QX)
	elif mode==143: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url,type)
	elif mode==144: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,text)
	elif mode==145: zpXG3Ky6ou8ndWHkb4 = NgvYbofjGDJQXMcZSt7B9u6el(url,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif mode==147: zpXG3Ky6ou8ndWHkb4 = WXuxgmeITy5bL()
	elif mode==148: zpXG3Ky6ou8ndWHkb4 = JLMYx4oXzPE7RBnwfgtQ85bm()
	elif mode==149: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	if 0:
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'قائمة',NBm2aWhPzoTpdYn+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'شخص',NBm2aWhPzoTpdYn+'/user/TCNofficial',144)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'موقع',NBm2aWhPzoTpdYn+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'حساب',NBm2aWhPzoTpdYn+'/@TheSocialCTV',144)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'العاب',NBm2aWhPzoTpdYn+'/gaming',144)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'افلام',NBm2aWhPzoTpdYn+'/feed/storefront',144)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مختارات',NBm2aWhPzoTpdYn+'/feed/guide_builder',144)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'قصيرة',NBm2aWhPzoTpdYn+'/shorts',144,'','','_REMEMBERRESULTS_')
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'تصفح',NBm2aWhPzoTpdYn+'/youtubei/v1/guide?key=',144)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'رئيسية',NBm2aWhPzoTpdYn+'',144)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'رائج',NBm2aWhPzoTpdYn+'/feed/trending?bp=',144)
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',149,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الرائجة',NBm2aWhPzoTpdYn+'/feed/trending',144)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'التصفح',NBm2aWhPzoTpdYn+'/youtubei/v1/guide?key=',144)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'القصيرة',NBm2aWhPzoTpdYn+'/shorts',144,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مختارات يوتيوب',NBm2aWhPzoTpdYn+'/feed/guide_builder',144)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مختارات البرنامج','',290)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث: قنوات عربية','',147)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث: قنوات أجنبية','',148)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث: افلام عربية',NBm2aWhPzoTpdYn+'/results?search_query=فيلم',144)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث: افلام اجنبية',NBm2aWhPzoTpdYn+'/results?search_query=movie',144)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث: مسرحيات عربية',NBm2aWhPzoTpdYn+'/results?search_query=مسرحية',144)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث: مسلسلات عربية',NBm2aWhPzoTpdYn+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث: مسلسلات اجنبية',NBm2aWhPzoTpdYn+'/results?search_query=series&sp=EgIQAw==',144)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث: مسلسلات كارتون',NBm2aWhPzoTpdYn+'/results?search_query=كارتون&sp=EgIQAw==',144)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث: خطبة المرجعية',NBm2aWhPzoTpdYn+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def dUgA4qerOv3xWhm90pVjy7(url,name,nWO8c3IgspK67QX):
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'CHNL:  '+name,url,144,nWO8c3IgspK67QX)
	return
def WXuxgmeITy5bL():
	xoiXMWjJC3pnQqurIGPkRSl8e(NBm2aWhPzoTpdYn+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def JLMYx4oXzPE7RBnwfgtQ85bm():
	xoiXMWjJC3pnQqurIGPkRSl8e(NBm2aWhPzoTpdYn+'/results?search_query=tv&sp=EgJAAQ==')
	return
def SUfe4unWoXBNFz90xqy(url,type):
	url = url.split('&',1)[0]
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E([url],cTJphS1nFz5EUgNWm86C,type,url)
	return
def mPFaU9XtvQZEqjNdrJS2Df0Gh5iW(VV8yn57cZdKkGoRQLxImf,url,nlYKqpfrwVWLmig71o9BX):
	level,zlQGH3OWpfK1bRojNDF,TX41HmrcRW,cYCUDAE9MWH0SuR6xPI7BlVv5OXwKJ = nlYKqpfrwVWLmig71o9BX.split('::')
	UaCSPBpXzR0JgKYocbwk4GETj2t,Lvgq63iyweO8XDEVt = [],[]
	if '/youtubei/v1/browse' in url: UaCSPBpXzR0JgKYocbwk4GETj2t.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: UaCSPBpXzR0JgKYocbwk4GETj2t.append("yccc['onResponseReceivedCommands']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	if level=='1': UaCSPBpXzR0JgKYocbwk4GETj2t.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yccc['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yccc['entries']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yccc['items'][3]['guideSectionRenderer']['items']")
	DMVjAb657OwW1I4SxdNYhgpR,DoeyJ2fA4GwZmqM8IbCsSjV,nkWYR3s9L4uzyUVCmjS = XXbN6Pe9D3(VV8yn57cZdKkGoRQLxImf,'',UaCSPBpXzR0JgKYocbwk4GETj2t)
	if level=='1' and DMVjAb657OwW1I4SxdNYhgpR:
		if len(DoeyJ2fA4GwZmqM8IbCsSjV)>1 and 'search_query' not in url:
			for k9qOc0wRPHIJeB5 in range(len(DoeyJ2fA4GwZmqM8IbCsSjV)):
				zlQGH3OWpfK1bRojNDF = str(k9qOc0wRPHIJeB5)
				UaCSPBpXzR0JgKYocbwk4GETj2t = []
				UaCSPBpXzR0JgKYocbwk4GETj2t.append("yddd["+zlQGH3OWpfK1bRojNDF+"]['reloadContinuationItemsCommand']['continuationItems']")
				UaCSPBpXzR0JgKYocbwk4GETj2t.append("yddd["+zlQGH3OWpfK1bRojNDF+"]['command']")
				UaCSPBpXzR0JgKYocbwk4GETj2t.append("yddd["+zlQGH3OWpfK1bRojNDF+"]")
				Tr8iRxJmbcEhftU5DSHzA,BrVNsC72UYWES4A,vAxfDHyjwR6KM74IGEJl0dasY = XXbN6Pe9D3(DoeyJ2fA4GwZmqM8IbCsSjV,'',UaCSPBpXzR0JgKYocbwk4GETj2t)
				if Tr8iRxJmbcEhftU5DSHzA: Lvgq63iyweO8XDEVt.append([BrVNsC72UYWES4A,url,'2::'+zlQGH3OWpfK1bRojNDF+'::0::0'])
			UaCSPBpXzR0JgKYocbwk4GETj2t.append("yccc['continuationEndpoint']")
			Tr8iRxJmbcEhftU5DSHzA,BrVNsC72UYWES4A,vAxfDHyjwR6KM74IGEJl0dasY = XXbN6Pe9D3(VV8yn57cZdKkGoRQLxImf,'',UaCSPBpXzR0JgKYocbwk4GETj2t)
			if Tr8iRxJmbcEhftU5DSHzA and Lvgq63iyweO8XDEVt and 'continuationCommand' in list(BrVNsC72UYWES4A.keys()):
				ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/my_main_page_shorts_link'
				Lvgq63iyweO8XDEVt.append([BrVNsC72UYWES4A,ELbNB92cOh5dqtpVmi40kY,'1::0::0::0'])
	return DoeyJ2fA4GwZmqM8IbCsSjV,DMVjAb657OwW1I4SxdNYhgpR,Lvgq63iyweO8XDEVt,nkWYR3s9L4uzyUVCmjS
def NLyC9kTuQfl4RaUDx(VV8yn57cZdKkGoRQLxImf,DoeyJ2fA4GwZmqM8IbCsSjV,url,nlYKqpfrwVWLmig71o9BX):
	level,zlQGH3OWpfK1bRojNDF,TX41HmrcRW,cYCUDAE9MWH0SuR6xPI7BlVv5OXwKJ = nlYKqpfrwVWLmig71o9BX.split('::')
	UaCSPBpXzR0JgKYocbwk4GETj2t,yEJYAZlvbRXTj4aegQS = [],[]
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yddd[0]['itemSectionRenderer']['contents']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yddd["+zlQGH3OWpfK1bRojNDF+"]['reloadContinuationItemsCommand']['continuationItems']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: UaCSPBpXzR0JgKYocbwk4GETj2t.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: UaCSPBpXzR0JgKYocbwk4GETj2t.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yddd["+zlQGH3OWpfK1bRojNDF+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		UaCSPBpXzR0JgKYocbwk4GETj2t.append("yddd["+zlQGH3OWpfK1bRojNDF+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yddd["+zlQGH3OWpfK1bRojNDF+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yddd["+zlQGH3OWpfK1bRojNDF+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yddd["+zlQGH3OWpfK1bRojNDF+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yddd["+zlQGH3OWpfK1bRojNDF+"]")
	aFAl6vZIf9BkbD74jdoOW3Q5H,i5CV2lpqSzadwJWHTvUMnY,xOY6bPp7tiCWs3uUfdr5gRhXwSqFa = XXbN6Pe9D3(DoeyJ2fA4GwZmqM8IbCsSjV,'',UaCSPBpXzR0JgKYocbwk4GETj2t)
	if level=='2' and aFAl6vZIf9BkbD74jdoOW3Q5H:
		if len(i5CV2lpqSzadwJWHTvUMnY)>1:
			for k9qOc0wRPHIJeB5 in range(len(i5CV2lpqSzadwJWHTvUMnY)):
				TX41HmrcRW = str(k9qOc0wRPHIJeB5)
				UaCSPBpXzR0JgKYocbwk4GETj2t = []
				UaCSPBpXzR0JgKYocbwk4GETj2t.append("yeee["+TX41HmrcRW+"]['richSectionRenderer']['content']")
				UaCSPBpXzR0JgKYocbwk4GETj2t.append("yeee["+TX41HmrcRW+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				UaCSPBpXzR0JgKYocbwk4GETj2t.append("yeee["+TX41HmrcRW+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				UaCSPBpXzR0JgKYocbwk4GETj2t.append("yeee["+TX41HmrcRW+"]['itemSectionRenderer']['contents'][0]")
				UaCSPBpXzR0JgKYocbwk4GETj2t.append("yeee["+TX41HmrcRW+"]['richItemRenderer']['content']")
				UaCSPBpXzR0JgKYocbwk4GETj2t.append("yeee["+TX41HmrcRW+"]")
				Tr8iRxJmbcEhftU5DSHzA,BrVNsC72UYWES4A,vAxfDHyjwR6KM74IGEJl0dasY = XXbN6Pe9D3(i5CV2lpqSzadwJWHTvUMnY,'',UaCSPBpXzR0JgKYocbwk4GETj2t)
				if Tr8iRxJmbcEhftU5DSHzA: yEJYAZlvbRXTj4aegQS.append([BrVNsC72UYWES4A,url,'3::'+zlQGH3OWpfK1bRojNDF+'::'+TX41HmrcRW+'::0'])
			UaCSPBpXzR0JgKYocbwk4GETj2t.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			UaCSPBpXzR0JgKYocbwk4GETj2t.append("yddd[1]")
			Tr8iRxJmbcEhftU5DSHzA,BrVNsC72UYWES4A,vAxfDHyjwR6KM74IGEJl0dasY = XXbN6Pe9D3(DoeyJ2fA4GwZmqM8IbCsSjV,'',UaCSPBpXzR0JgKYocbwk4GETj2t)
			if Tr8iRxJmbcEhftU5DSHzA and yEJYAZlvbRXTj4aegQS and 'continuationItemRenderer' in list(BrVNsC72UYWES4A.keys()):
				yEJYAZlvbRXTj4aegQS.append([BrVNsC72UYWES4A,url,'3::0::0::0'])
	return i5CV2lpqSzadwJWHTvUMnY,aFAl6vZIf9BkbD74jdoOW3Q5H,yEJYAZlvbRXTj4aegQS,xOY6bPp7tiCWs3uUfdr5gRhXwSqFa
def R4DSpMuQ1qkZnNT0WrO(VV8yn57cZdKkGoRQLxImf,i5CV2lpqSzadwJWHTvUMnY,url,nlYKqpfrwVWLmig71o9BX):
	level,zlQGH3OWpfK1bRojNDF,TX41HmrcRW,cYCUDAE9MWH0SuR6xPI7BlVv5OXwKJ = nlYKqpfrwVWLmig71o9BX.split('::')
	UaCSPBpXzR0JgKYocbwk4GETj2t,rMgELmQSRzns0pvu1BwOWKdVA = [],[]
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yeee["+TX41HmrcRW+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yeee["+TX41HmrcRW+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yeee["+TX41HmrcRW+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yeee["+TX41HmrcRW+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yeee["+TX41HmrcRW+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yeee["+TX41HmrcRW+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yeee["+TX41HmrcRW+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yeee["+TX41HmrcRW+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yeee["+TX41HmrcRW+"]['reelShelfRenderer']['items']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yeee["+TX41HmrcRW+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yeee")
	d60jSXbuqizUQAH1,gmBhCnfkljtwAV,lO0Sw14mh2k7eZEn3cjQ8Lty = XXbN6Pe9D3(i5CV2lpqSzadwJWHTvUMnY,'',UaCSPBpXzR0JgKYocbwk4GETj2t)
	if level=='3' and d60jSXbuqizUQAH1:
		if len(gmBhCnfkljtwAV)>0:
			for k9qOc0wRPHIJeB5 in range(len(gmBhCnfkljtwAV)):
				cYCUDAE9MWH0SuR6xPI7BlVv5OXwKJ = str(k9qOc0wRPHIJeB5)
				UaCSPBpXzR0JgKYocbwk4GETj2t = []
				UaCSPBpXzR0JgKYocbwk4GETj2t.append("yfff["+cYCUDAE9MWH0SuR6xPI7BlVv5OXwKJ+"]['richItemRenderer']['content']")
				UaCSPBpXzR0JgKYocbwk4GETj2t.append("yfff["+cYCUDAE9MWH0SuR6xPI7BlVv5OXwKJ+"]['gameCardRenderer']['game']")
				UaCSPBpXzR0JgKYocbwk4GETj2t.append("yfff["+cYCUDAE9MWH0SuR6xPI7BlVv5OXwKJ+"]['itemSectionRenderer']['contents'][0]")
				UaCSPBpXzR0JgKYocbwk4GETj2t.append("yfff["+cYCUDAE9MWH0SuR6xPI7BlVv5OXwKJ+"]")
				Tr8iRxJmbcEhftU5DSHzA,BrVNsC72UYWES4A,vAxfDHyjwR6KM74IGEJl0dasY = XXbN6Pe9D3(gmBhCnfkljtwAV,'',UaCSPBpXzR0JgKYocbwk4GETj2t)
				if Tr8iRxJmbcEhftU5DSHzA: rMgELmQSRzns0pvu1BwOWKdVA.append([BrVNsC72UYWES4A,url,'4::'+zlQGH3OWpfK1bRojNDF+'::'+TX41HmrcRW+'::'+cYCUDAE9MWH0SuR6xPI7BlVv5OXwKJ])
	return gmBhCnfkljtwAV,d60jSXbuqizUQAH1,rMgELmQSRzns0pvu1BwOWKdVA,lO0Sw14mh2k7eZEn3cjQ8Lty
def XXbN6Pe9D3(n3ot08Ck2OIaKFq1iJsvWQScyfx,DCguJjW2E9bQomXAqG,uNLwCObJaUeKsyvjTrzinc56ZW1Dp):
	VV8yn57cZdKkGoRQLxImf,DCguJjW2E9bQomXAqG = n3ot08Ck2OIaKFq1iJsvWQScyfx,DCguJjW2E9bQomXAqG
	DoeyJ2fA4GwZmqM8IbCsSjV,DCguJjW2E9bQomXAqG = n3ot08Ck2OIaKFq1iJsvWQScyfx,DCguJjW2E9bQomXAqG
	i5CV2lpqSzadwJWHTvUMnY,DCguJjW2E9bQomXAqG = n3ot08Ck2OIaKFq1iJsvWQScyfx,DCguJjW2E9bQomXAqG
	gmBhCnfkljtwAV,DCguJjW2E9bQomXAqG = n3ot08Ck2OIaKFq1iJsvWQScyfx,DCguJjW2E9bQomXAqG
	BrVNsC72UYWES4A,uu60lJKs4yAqHtPhbrYnj9oEQwLkWd = n3ot08Ck2OIaKFq1iJsvWQScyfx,DCguJjW2E9bQomXAqG
	count = len(uNLwCObJaUeKsyvjTrzinc56ZW1Dp)
	for CQMipytPbq in range(count):
		try:
			WjA38TbG4Sg60 = eval(uNLwCObJaUeKsyvjTrzinc56ZW1Dp[CQMipytPbq])
			return True,WjA38TbG4Sg60,CQMipytPbq+1
		except: pass
	return False,'',0
def xoiXMWjJC3pnQqurIGPkRSl8e(url,nlYKqpfrwVWLmig71o9BX='',data=''):
	Lvgq63iyweO8XDEVt,yEJYAZlvbRXTj4aegQS,rMgELmQSRzns0pvu1BwOWKdVA = [],[],[]
	if '::' not in nlYKqpfrwVWLmig71o9BX: nlYKqpfrwVWLmig71o9BX = '1::0::0::0'
	level,zlQGH3OWpfK1bRojNDF,TX41HmrcRW,cYCUDAE9MWH0SuR6xPI7BlVv5OXwKJ = nlYKqpfrwVWLmig71o9BX.split('::')
	if level=='4': level,zlQGH3OWpfK1bRojNDF,TX41HmrcRW,cYCUDAE9MWH0SuR6xPI7BlVv5OXwKJ = '1',zlQGH3OWpfK1bRojNDF,TX41HmrcRW,cYCUDAE9MWH0SuR6xPI7BlVv5OXwKJ
	data = data.replace('_REMEMBERRESULTS_','')
	BBlXpmUyhFDwNtCVAHoE,VV8yn57cZdKkGoRQLxImf,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = rKP5lefC2pJ4hNxgQ(url,data)
	nlYKqpfrwVWLmig71o9BX = level+'::'+zlQGH3OWpfK1bRojNDF+'::'+TX41HmrcRW+'::'+cYCUDAE9MWH0SuR6xPI7BlVv5OXwKJ
	if level in ['1','2','3']:
		DoeyJ2fA4GwZmqM8IbCsSjV,DMVjAb657OwW1I4SxdNYhgpR,Lvgq63iyweO8XDEVt,nkWYR3s9L4uzyUVCmjS = mPFaU9XtvQZEqjNdrJS2Df0Gh5iW(VV8yn57cZdKkGoRQLxImf,url,nlYKqpfrwVWLmig71o9BX)
		if not DMVjAb657OwW1I4SxdNYhgpR: return
		muEGPtzwjHfAh6d32rNXyBpFI = len(Lvgq63iyweO8XDEVt)
		if muEGPtzwjHfAh6d32rNXyBpFI<2:
			if level=='1': level = '2'
			Lvgq63iyweO8XDEVt = []
	nlYKqpfrwVWLmig71o9BX = level+'::'+zlQGH3OWpfK1bRojNDF+'::'+TX41HmrcRW+'::'+cYCUDAE9MWH0SuR6xPI7BlVv5OXwKJ
	if level in ['2','3']:
		i5CV2lpqSzadwJWHTvUMnY,aFAl6vZIf9BkbD74jdoOW3Q5H,yEJYAZlvbRXTj4aegQS,xOY6bPp7tiCWs3uUfdr5gRhXwSqFa = NLyC9kTuQfl4RaUDx(VV8yn57cZdKkGoRQLxImf,DoeyJ2fA4GwZmqM8IbCsSjV,url,nlYKqpfrwVWLmig71o9BX)
		if not aFAl6vZIf9BkbD74jdoOW3Q5H: return
		rrbJ4Tadynmf9kKhoHOC = len(yEJYAZlvbRXTj4aegQS)
		if rrbJ4Tadynmf9kKhoHOC<2:
			if level=='2': level = '3'
			yEJYAZlvbRXTj4aegQS = []
	nlYKqpfrwVWLmig71o9BX = level+'::'+zlQGH3OWpfK1bRojNDF+'::'+TX41HmrcRW+'::'+cYCUDAE9MWH0SuR6xPI7BlVv5OXwKJ
	if level in ['3']:
		gmBhCnfkljtwAV,d60jSXbuqizUQAH1,rMgELmQSRzns0pvu1BwOWKdVA,lO0Sw14mh2k7eZEn3cjQ8Lty = R4DSpMuQ1qkZnNT0WrO(VV8yn57cZdKkGoRQLxImf,i5CV2lpqSzadwJWHTvUMnY,url,nlYKqpfrwVWLmig71o9BX)
		if not d60jSXbuqizUQAH1: return
		RQtjlakdsW3 = len(rMgELmQSRzns0pvu1BwOWKdVA)
	for BrVNsC72UYWES4A,url,nlYKqpfrwVWLmig71o9BX in Lvgq63iyweO8XDEVt+yEJYAZlvbRXTj4aegQS+rMgELmQSRzns0pvu1BwOWKdVA:
		KKWoCUYw3thId2e1GPVuDcx98ia = xs5qyN8IWjmhu9t2wKH6TXOaS(BrVNsC72UYWES4A,url,nlYKqpfrwVWLmig71o9BX)
	return
def xs5qyN8IWjmhu9t2wKH6TXOaS(BrVNsC72UYWES4A,url='',nlYKqpfrwVWLmig71o9BX=''):
	if '::' in nlYKqpfrwVWLmig71o9BX: level,zlQGH3OWpfK1bRojNDF,TX41HmrcRW,cYCUDAE9MWH0SuR6xPI7BlVv5OXwKJ = nlYKqpfrwVWLmig71o9BX.split('::')
	else: level,zlQGH3OWpfK1bRojNDF,TX41HmrcRW,cYCUDAE9MWH0SuR6xPI7BlVv5OXwKJ = '1','0','0','0'
	Tr8iRxJmbcEhftU5DSHzA,title,ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,count,EDL3rwcivsR9W0pdTfygmOYUoVSb,vcZAMYo91uLtzbliawOx6GyKRT,BfZdAct4k0VDSeJ9uh,l7rLfvPJonaRBub = D5t3HLgP7uads2lVWmYvC(BrVNsC72UYWES4A)
	GwBsaCOTjM14 = '/videos?' in ELbNB92cOh5dqtpVmi40kY or '/streams?' in ELbNB92cOh5dqtpVmi40kY or '/playlists?' in ELbNB92cOh5dqtpVmi40kY
	FRZzAcUCSDTWGfswQdEuy = '/channels?' in ELbNB92cOh5dqtpVmi40kY or '/shorts?' in ELbNB92cOh5dqtpVmi40kY
	if GwBsaCOTjM14 or FRZzAcUCSDTWGfswQdEuy: ELbNB92cOh5dqtpVmi40kY = url
	GwBsaCOTjM14 = 'watch?v=' not in ELbNB92cOh5dqtpVmi40kY and '/playlist?list=' not in ELbNB92cOh5dqtpVmi40kY
	FRZzAcUCSDTWGfswQdEuy = '/gaming' not in ELbNB92cOh5dqtpVmi40kY  and '/feed/storefront' not in ELbNB92cOh5dqtpVmi40kY
	if nlYKqpfrwVWLmig71o9BX[0:5]=='3::0::' and GwBsaCOTjM14 and FRZzAcUCSDTWGfswQdEuy: ELbNB92cOh5dqtpVmi40kY = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in ELbNB92cOh5dqtpVmi40kY:
		level,zlQGH3OWpfK1bRojNDF,TX41HmrcRW,cYCUDAE9MWH0SuR6xPI7BlVv5OXwKJ = '1','0','0','0'
		nlYKqpfrwVWLmig71o9BX = ''
	Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = ''
	if '/youtubei/v1/browse' in ELbNB92cOh5dqtpVmi40kY or '/youtubei/v1/search' in ELbNB92cOh5dqtpVmi40kY or '/my_main_page_shorts_link' in url:
		data = jHevARrF7lS.getSetting('av.youtube.data')
		if data.count(':::')==4:
			R2XCvULdcta1fWkIzwo4Ge6u,key,XVSW1sQ4dAGx2hpUwHk8KT,SdAk9PfCaWtov0K4GnxIYUcQX8,DI9PgKJNvLiuBpXyctMs2RklobGA = data.split(':::')
			Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = R2XCvULdcta1fWkIzwo4Ge6u+':::'+key+':::'+XVSW1sQ4dAGx2hpUwHk8KT+':::'+SdAk9PfCaWtov0K4GnxIYUcQX8+':::'+l7rLfvPJonaRBub
			if '/my_main_page_shorts_link' in url and not ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = url
			else: ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?key='+key
	if not title:
		global uLs2eNVw8mngEzdCavS
		uLs2eNVw8mngEzdCavS += 1
		title = 'فيديوهات '+str(uLs2eNVw8mngEzdCavS)
		nlYKqpfrwVWLmig71o9BX = '3'+'::'+zlQGH3OWpfK1bRojNDF+'::'+TX41HmrcRW+'::'+cYCUDAE9MWH0SuR6xPI7BlVv5OXwKJ
	if not Tr8iRxJmbcEhftU5DSHzA: return False
	elif 'searchPyvRenderer' in str(BrVNsC72UYWES4A): return False
	elif '/about' in ELbNB92cOh5dqtpVmi40kY: return False
	elif '/community' in ELbNB92cOh5dqtpVmi40kY: return False
	elif 'continuationItemRenderer' in list(BrVNsC72UYWES4A.keys()) or 'continuationCommand' in list(BrVNsC72UYWES4A.keys()):
		if int(level)>1: level = str(int(level)-1)
		nlYKqpfrwVWLmig71o9BX = level+'::'+zlQGH3OWpfK1bRojNDF+'::'+TX41HmrcRW+'::'+cYCUDAE9MWH0SuR6xPI7BlVv5OXwKJ
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+':: '+'صفحة أخرى',ELbNB92cOh5dqtpVmi40kY,144,VFqpJjRySZvgi,nlYKqpfrwVWLmig71o9BX,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd)
	elif '/search' in ELbNB92cOh5dqtpVmi40kY:
		title = ':: '+title
		nlYKqpfrwVWLmig71o9BX = '3'+'::'+zlQGH3OWpfK1bRojNDF+'::'+TX41HmrcRW+'::'+cYCUDAE9MWH0SuR6xPI7BlVv5OXwKJ
		url = url.replace('/search','')
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,145,'',nlYKqpfrwVWLmig71o9BX,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not ELbNB92cOh5dqtpVmi40kY:
		nlYKqpfrwVWLmig71o9BX = '3'+'::'+zlQGH3OWpfK1bRojNDF+'::'+TX41HmrcRW+'::'+cYCUDAE9MWH0SuR6xPI7BlVv5OXwKJ
		title = ':: '+title
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,144,VFqpJjRySZvgi,nlYKqpfrwVWLmig71o9BX,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd)
	elif '/browse' in ELbNB92cOh5dqtpVmi40kY and url==NBm2aWhPzoTpdYn:
		title = ':: '+title
		nlYKqpfrwVWLmig71o9BX = '2::0::0::0'
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,144,VFqpJjRySZvgi,nlYKqpfrwVWLmig71o9BX,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd)
	elif not ELbNB92cOh5dqtpVmi40kY and 'horizontalMovieListRenderer' in str(BrVNsC72UYWES4A):
		title = ':: '+title
		nlYKqpfrwVWLmig71o9BX = '3::0::0::0'
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,144,VFqpJjRySZvgi,nlYKqpfrwVWLmig71o9BX)
	elif 'messageRenderer' in str(BrVNsC72UYWES4A):
		cd0aGwCPExbFU5pYNu8r('link',mmDwMlfoHtG5XT19VLIWqCR8i+title,'',9999)
	elif vcZAMYo91uLtzbliawOx6GyKRT:
		cd0aGwCPExbFU5pYNu8r('live',mmDwMlfoHtG5XT19VLIWqCR8i+vcZAMYo91uLtzbliawOx6GyKRT+title,ELbNB92cOh5dqtpVmi40kY,143,VFqpJjRySZvgi)
	elif '/playlist?list=' in ELbNB92cOh5dqtpVmi40kY:
		ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.replace('&playnext=1','')
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'LIST'+count+':  '+title,ELbNB92cOh5dqtpVmi40kY,144,VFqpJjRySZvgi,nlYKqpfrwVWLmig71o9BX)
	elif '/shorts/' in ELbNB92cOh5dqtpVmi40kY:
		ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.split('&list=',1)[0]
		cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,143,VFqpJjRySZvgi,EDL3rwcivsR9W0pdTfygmOYUoVSb)
	elif '/watch?v=' in ELbNB92cOh5dqtpVmi40kY:
		if '&list=' in ELbNB92cOh5dqtpVmi40kY and count:
			BBXLTRwUZoF1v7rHDiA5 = ELbNB92cOh5dqtpVmi40kY.split('&list=',1)[1]
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/playlist?list='+BBXLTRwUZoF1v7rHDiA5
			nlYKqpfrwVWLmig71o9BX = '3::0::0::0'
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'LIST'+count+':  '+title,ELbNB92cOh5dqtpVmi40kY,144,VFqpJjRySZvgi,nlYKqpfrwVWLmig71o9BX)
		else:
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.split('&list=',1)[0]
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,143,VFqpJjRySZvgi,EDL3rwcivsR9W0pdTfygmOYUoVSb)
	elif '/channel/' in ELbNB92cOh5dqtpVmi40kY or '/c/' in ELbNB92cOh5dqtpVmi40kY or ('/@' in ELbNB92cOh5dqtpVmi40kY and ELbNB92cOh5dqtpVmi40kY.count('/')==3):
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'CHNL'+count+':  '+title,ELbNB92cOh5dqtpVmi40kY,144,VFqpJjRySZvgi,nlYKqpfrwVWLmig71o9BX)
	elif '/user/' in ELbNB92cOh5dqtpVmi40kY:
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'USER'+count+':  '+title,ELbNB92cOh5dqtpVmi40kY,144,VFqpJjRySZvgi,nlYKqpfrwVWLmig71o9BX)
	else:
		if not ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = url
		title = ':: '+title
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,144,VFqpJjRySZvgi,nlYKqpfrwVWLmig71o9BX,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd)
	return True
def D5t3HLgP7uads2lVWmYvC(BrVNsC72UYWES4A):
	Tr8iRxJmbcEhftU5DSHzA,title,ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,count,EDL3rwcivsR9W0pdTfygmOYUoVSb,vcZAMYo91uLtzbliawOx6GyKRT,BfZdAct4k0VDSeJ9uh,DI9PgKJNvLiuBpXyctMs2RklobGA = False,'','','','','','','',''
	if not isinstance(BrVNsC72UYWES4A,dict): return Tr8iRxJmbcEhftU5DSHzA,title,ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,count,EDL3rwcivsR9W0pdTfygmOYUoVSb,vcZAMYo91uLtzbliawOx6GyKRT,BfZdAct4k0VDSeJ9uh,DI9PgKJNvLiuBpXyctMs2RklobGA
	for LLnY31KGyp in list(BrVNsC72UYWES4A.keys()):
		uu60lJKs4yAqHtPhbrYnj9oEQwLkWd = BrVNsC72UYWES4A[LLnY31KGyp]
		if isinstance(uu60lJKs4yAqHtPhbrYnj9oEQwLkWd,dict): break
	UaCSPBpXzR0JgKYocbwk4GETj2t = []
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['header']['playlistHeaderRenderer']['title']['simpleText']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['header']['richListHeaderRenderer']['title']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['headline']['simpleText']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['unplayableText']['simpleText']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['formattedTitle']['simpleText']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['title']['simpleText']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['title']['runs'][0]['text']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['text']['simpleText']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['text']['runs'][0]['text']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['title']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("item['title']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("item['reelWatchEndpoint']['videoId']")
	Tr8iRxJmbcEhftU5DSHzA,title,vAxfDHyjwR6KM74IGEJl0dasY = XXbN6Pe9D3(BrVNsC72UYWES4A,uu60lJKs4yAqHtPhbrYnj9oEQwLkWd,UaCSPBpXzR0JgKYocbwk4GETj2t)
	UaCSPBpXzR0JgKYocbwk4GETj2t = []
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("item['commandMetadata']['webCommandMetadata']['url']")
	Tr8iRxJmbcEhftU5DSHzA,ELbNB92cOh5dqtpVmi40kY,vAxfDHyjwR6KM74IGEJl0dasY = XXbN6Pe9D3(BrVNsC72UYWES4A,uu60lJKs4yAqHtPhbrYnj9oEQwLkWd,UaCSPBpXzR0JgKYocbwk4GETj2t)
	UaCSPBpXzR0JgKYocbwk4GETj2t = []
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['thumbnail']['thumbnails'][0]['url']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	Tr8iRxJmbcEhftU5DSHzA,VFqpJjRySZvgi,vAxfDHyjwR6KM74IGEJl0dasY = XXbN6Pe9D3(BrVNsC72UYWES4A,uu60lJKs4yAqHtPhbrYnj9oEQwLkWd,UaCSPBpXzR0JgKYocbwk4GETj2t)
	UaCSPBpXzR0JgKYocbwk4GETj2t = []
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['videoCount']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['videoCountText']['runs'][0]['text']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	Tr8iRxJmbcEhftU5DSHzA,count,vAxfDHyjwR6KM74IGEJl0dasY = XXbN6Pe9D3(BrVNsC72UYWES4A,uu60lJKs4yAqHtPhbrYnj9oEQwLkWd,UaCSPBpXzR0JgKYocbwk4GETj2t)
	UaCSPBpXzR0JgKYocbwk4GETj2t = []
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['lengthText']['simpleText']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	Tr8iRxJmbcEhftU5DSHzA,EDL3rwcivsR9W0pdTfygmOYUoVSb,vAxfDHyjwR6KM74IGEJl0dasY = XXbN6Pe9D3(BrVNsC72UYWES4A,uu60lJKs4yAqHtPhbrYnj9oEQwLkWd,UaCSPBpXzR0JgKYocbwk4GETj2t)
	UaCSPBpXzR0JgKYocbwk4GETj2t = []
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	Tr8iRxJmbcEhftU5DSHzA,DI9PgKJNvLiuBpXyctMs2RklobGA,vAxfDHyjwR6KM74IGEJl0dasY = XXbN6Pe9D3(BrVNsC72UYWES4A,uu60lJKs4yAqHtPhbrYnj9oEQwLkWd,UaCSPBpXzR0JgKYocbwk4GETj2t)
	if 'LIVE' in EDL3rwcivsR9W0pdTfygmOYUoVSb: EDL3rwcivsR9W0pdTfygmOYUoVSb,vcZAMYo91uLtzbliawOx6GyKRT = '','LIVE:  '
	if 'مباشر' in EDL3rwcivsR9W0pdTfygmOYUoVSb: EDL3rwcivsR9W0pdTfygmOYUoVSb,vcZAMYo91uLtzbliawOx6GyKRT = '','LIVE:  '
	if 'badges' in list(uu60lJKs4yAqHtPhbrYnj9oEQwLkWd.keys()):
		GCvmIBpyo7LH6cN1 = str(uu60lJKs4yAqHtPhbrYnj9oEQwLkWd['badges'])
		if 'Free with Ads' in GCvmIBpyo7LH6cN1: BfZdAct4k0VDSeJ9uh = '$:  '
		if 'LIVE' in GCvmIBpyo7LH6cN1: vcZAMYo91uLtzbliawOx6GyKRT = 'LIVE:  '
		if 'Buy' in GCvmIBpyo7LH6cN1 or 'Rent' in GCvmIBpyo7LH6cN1: BfZdAct4k0VDSeJ9uh = '$$:  '
		if FEaio7MR2CjTJ9ZLVQnhNewgpv(u'مباشر') in GCvmIBpyo7LH6cN1: vcZAMYo91uLtzbliawOx6GyKRT = 'LIVE:  '
		if FEaio7MR2CjTJ9ZLVQnhNewgpv(u'شراء') in GCvmIBpyo7LH6cN1: BfZdAct4k0VDSeJ9uh = '$$:  '
		if FEaio7MR2CjTJ9ZLVQnhNewgpv(u'استئجار') in GCvmIBpyo7LH6cN1: BfZdAct4k0VDSeJ9uh = '$$:  '
		if FEaio7MR2CjTJ9ZLVQnhNewgpv(u'إعلانات') in GCvmIBpyo7LH6cN1: BfZdAct4k0VDSeJ9uh = '$:  '
	ELbNB92cOh5dqtpVmi40kY = ptMqV54oKJhQ8CH(ELbNB92cOh5dqtpVmi40kY)
	if ELbNB92cOh5dqtpVmi40kY and 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
	VFqpJjRySZvgi = VFqpJjRySZvgi.split('?')[0]
	if  VFqpJjRySZvgi and 'http' not in VFqpJjRySZvgi: VFqpJjRySZvgi = 'https:'+VFqpJjRySZvgi
	title = ptMqV54oKJhQ8CH(title)
	if BfZdAct4k0VDSeJ9uh: title = BfZdAct4k0VDSeJ9uh+title
	EDL3rwcivsR9W0pdTfygmOYUoVSb = EDL3rwcivsR9W0pdTfygmOYUoVSb.replace(',','')
	count = count.replace(',','')
	count = GGvHJKP9LUxEk10Fw.findall('\d+',count)
	if count: count = count[0]
	else: count = ''
	return True,title,ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,count,EDL3rwcivsR9W0pdTfygmOYUoVSb,vcZAMYo91uLtzbliawOx6GyKRT,BfZdAct4k0VDSeJ9uh,DI9PgKJNvLiuBpXyctMs2RklobGA
def rKP5lefC2pJ4hNxgQ(url,data='',hD6se2E307NcI=''):
	if hD6se2E307NcI=='': hD6se2E307NcI = 'ytInitialData'
	bTDaxXYSseoFCI6cQ4f58vqr3dPNp = Y8Y6b7aLSUKjdE1Ae()
	BBYvCiQGe8RdpyAagfS72mZclxb5 = {'User-Agent':bTDaxXYSseoFCI6cQ4f58vqr3dPNp,'Cookie':'PREF=hl=ar'}
	global jHevARrF7lS
	if not data: data = jHevARrF7lS.getSetting('av.youtube.data')
	if data.count(':::')==4: R2XCvULdcta1fWkIzwo4Ge6u,key,XVSW1sQ4dAGx2hpUwHk8KT,SdAk9PfCaWtov0K4GnxIYUcQX8,DI9PgKJNvLiuBpXyctMs2RklobGA = data.split(':::')
	else: R2XCvULdcta1fWkIzwo4Ge6u,key,XVSW1sQ4dAGx2hpUwHk8KT,SdAk9PfCaWtov0K4GnxIYUcQX8,DI9PgKJNvLiuBpXyctMs2RklobGA = '','','','',''
	Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":XVSW1sQ4dAGx2hpUwHk8KT}}}
	if url==NBm2aWhPzoTpdYn+'/shorts' or '/my_main_page_shorts_link' in url:
		url = NBm2aWhPzoTpdYn+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd['sequenceParams'] = R2XCvULdcta1fWkIzwo4Ge6u
		Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = str(Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd)
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'POST',url,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = NBm2aWhPzoTpdYn+'/youtubei/v1/guide?key='+key
		Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = str(Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd)
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'POST',url,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and R2XCvULdcta1fWkIzwo4Ge6u:
		Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd['continuation'] = DI9PgKJNvLiuBpXyctMs2RklobGA
		Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd['context']['client']['visitorData'] = R2XCvULdcta1fWkIzwo4Ge6u
		Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = str(Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd)
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'POST',url,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and SdAk9PfCaWtov0K4GnxIYUcQX8:
		BBYvCiQGe8RdpyAagfS72mZclxb5.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':XVSW1sQ4dAGx2hpUwHk8KT})
		BBYvCiQGe8RdpyAagfS72mZclxb5.update({'Cookie':'VISITOR_INFO1_LIVE='+SdAk9PfCaWtov0K4GnxIYUcQX8})
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'GET',url,'',BBYvCiQGe8RdpyAagfS72mZclxb5,'','','YOUTUBE-GET_PAGE_DATA-5th')
	else:
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'GET',url,'',BBYvCiQGe8RdpyAagfS72mZclxb5,'','','YOUTUBE-GET_PAGE_DATA-6th')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	rYgcPZ9wVdDF = GGvHJKP9LUxEk10Fw.findall('"innertubeApiKey".*?"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.I)
	if rYgcPZ9wVdDF: key = rYgcPZ9wVdDF[0]
	rYgcPZ9wVdDF = GGvHJKP9LUxEk10Fw.findall('"cver".*?"value".*?"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.I)
	if rYgcPZ9wVdDF: XVSW1sQ4dAGx2hpUwHk8KT = rYgcPZ9wVdDF[0]
	rYgcPZ9wVdDF = GGvHJKP9LUxEk10Fw.findall('"visitorData".*?"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.I)
	if rYgcPZ9wVdDF: R2XCvULdcta1fWkIzwo4Ge6u = rYgcPZ9wVdDF[0]
	cookies = WbTGMHnDysdYZ2lFA.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): SdAk9PfCaWtov0K4GnxIYUcQX8 = cookies['VISITOR_INFO1_LIVE']
	IWPVYFU8cTixALJf = R2XCvULdcta1fWkIzwo4Ge6u+':::'+key+':::'+XVSW1sQ4dAGx2hpUwHk8KT+':::'+SdAk9PfCaWtov0K4GnxIYUcQX8+':::'+DI9PgKJNvLiuBpXyctMs2RklobGA
	if hD6se2E307NcI=='ytInitialData' and 'ytInitialData' in BBlXpmUyhFDwNtCVAHoE:
		Bp3FCNtj6r5gef8L = GGvHJKP9LUxEk10Fw.findall('window\["ytInitialData"\] = ({.*?});',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if not Bp3FCNtj6r5gef8L: Bp3FCNtj6r5gef8L = GGvHJKP9LUxEk10Fw.findall('var ytInitialData = ({.*?});',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		KKJmP0jzaiT2lyM3DYnQ6AW7o8Xd5 = JKw5OWktPZB('str',Bp3FCNtj6r5gef8L[0])
	elif hD6se2E307NcI=='ytInitialGuideData' and 'ytInitialGuideData' in BBlXpmUyhFDwNtCVAHoE:
		Bp3FCNtj6r5gef8L = GGvHJKP9LUxEk10Fw.findall('var ytInitialGuideData = ({.*?});',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		KKJmP0jzaiT2lyM3DYnQ6AW7o8Xd5 = JKw5OWktPZB('str',Bp3FCNtj6r5gef8L[0])
	elif '</script>' not in BBlXpmUyhFDwNtCVAHoE: KKJmP0jzaiT2lyM3DYnQ6AW7o8Xd5 = JKw5OWktPZB('str',BBlXpmUyhFDwNtCVAHoE)
	else: KKJmP0jzaiT2lyM3DYnQ6AW7o8Xd5 = ''
	if 0:
		VV8yn57cZdKkGoRQLxImf = str(KKJmP0jzaiT2lyM3DYnQ6AW7o8Xd5)
		if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: VV8yn57cZdKkGoRQLxImf = VV8yn57cZdKkGoRQLxImf.encode('utf8')
		open('S:\\0000emad.dat','wb').write(VV8yn57cZdKkGoRQLxImf)
	jHevARrF7lS.setSetting('av.youtube.data',IWPVYFU8cTixALJf)
	return BBlXpmUyhFDwNtCVAHoE,KKJmP0jzaiT2lyM3DYnQ6AW7o8Xd5,IWPVYFU8cTixALJf
def NgvYbofjGDJQXMcZSt7B9u6el(url,nlYKqpfrwVWLmig71o9BX):
	search = yMRXZIpKxlSkaE6iCO()
	if not search: return
	search = search.replace(' ','+')
	dR2vHyAtl8pJN1 = url+'/search?query='+search
	xoiXMWjJC3pnQqurIGPkRSl8e(dR2vHyAtl8pJN1,nlYKqpfrwVWLmig71o9BX)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if not search:
		search = yMRXZIpKxlSkaE6iCO()
		if not search: return
	search = search.replace(' ','+')
	dR2vHyAtl8pJN1 = NBm2aWhPzoTpdYn+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in tY3Dfrp6cMKFj: QFnjfwW5k984tKT6 = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in tY3Dfrp6cMKFj: QFnjfwW5k984tKT6 = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in tY3Dfrp6cMKFj: QFnjfwW5k984tKT6 = '&sp=EgIQAg%253D%253D'
		else: QFnjfwW5k984tKT6 = ''
		XwyU6PQgprMI0 = dR2vHyAtl8pJN1+QFnjfwW5k984tKT6
	else:
		ga1pf2D9JQTLmMGyk4jetPvXrW0,qGD53zc2bQKtX8Nnw7SYv6IMeVmiWP,qPmCp1Q4gRekdAH = [],[],''
		tt4dyBw6spGr = ['بدون ترتيب','ترتيب حسب مدى الصلة','ترتيب حسب تاريخ التحميل','ترتيب حسب عدد المشاهدات','ترتيب حسب التقييم']
		HHOnVAhFqZpgWCakiLmrRXYSJ3ITv = ['','&sp=CAA%253D','&sp=CAI%253D','&sp=CAM%253D','&sp=CAE%253D']
		Ct2LAYmsTvIcKzoEH0uV1QS = D1DJtzviFZSrA('موقع يوتيوب - اختر الترتيب',tt4dyBw6spGr)
		if Ct2LAYmsTvIcKzoEH0uV1QS == -1: return
		ElVJ3XuygPMnHz5TpkLAQv = HHOnVAhFqZpgWCakiLmrRXYSJ3ITv[Ct2LAYmsTvIcKzoEH0uV1QS]
		BBlXpmUyhFDwNtCVAHoE,MajNPJp5oc2ZYftDHg,data = rKP5lefC2pJ4hNxgQ(dR2vHyAtl8pJN1+ElVJ3XuygPMnHz5TpkLAQv)
		if MajNPJp5oc2ZYftDHg:
			try:
				wLsNCkZDPednXF6r1RlB7gEqoQ = MajNPJp5oc2ZYftDHg['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for rrQCv5GDdOjlTn6oZ7FJxLg in range(len(wLsNCkZDPednXF6r1RlB7gEqoQ)):
					group = wLsNCkZDPednXF6r1RlB7gEqoQ[rrQCv5GDdOjlTn6oZ7FJxLg]['searchFilterGroupRenderer']['filters']
					for TTLOpPkRY4UDZB0Msvt6K in range(len(group)):
						uu60lJKs4yAqHtPhbrYnj9oEQwLkWd = group[TTLOpPkRY4UDZB0Msvt6K]['searchFilterRenderer']
						if 'navigationEndpoint' in list(uu60lJKs4yAqHtPhbrYnj9oEQwLkWd.keys()):
							ELbNB92cOh5dqtpVmi40kY = uu60lJKs4yAqHtPhbrYnj9oEQwLkWd['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.replace('\u0026','&')
							title = uu60lJKs4yAqHtPhbrYnj9oEQwLkWd['tooltip']
							title = title.replace('البحث عن ','')
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								qPmCp1Q4gRekdAH = title
								E2EhMuOLdF08Pz75jDKS14cfYNxy = ELbNB92cOh5dqtpVmi40kY
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ','')
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								qPmCp1Q4gRekdAH = title
								E2EhMuOLdF08Pz75jDKS14cfYNxy = ELbNB92cOh5dqtpVmi40kY
							if 'Sort by' in title: continue
							ga1pf2D9JQTLmMGyk4jetPvXrW0.append(ptMqV54oKJhQ8CH(title))
							qGD53zc2bQKtX8Nnw7SYv6IMeVmiWP.append(ELbNB92cOh5dqtpVmi40kY)
			except: pass
		if not qPmCp1Q4gRekdAH: nuXhiECNxYUt6TBMSagv7l43m = ''
		else:
			ga1pf2D9JQTLmMGyk4jetPvXrW0 = ['بدون فلتر',qPmCp1Q4gRekdAH]+ga1pf2D9JQTLmMGyk4jetPvXrW0
			qGD53zc2bQKtX8Nnw7SYv6IMeVmiWP = ['',E2EhMuOLdF08Pz75jDKS14cfYNxy]+qGD53zc2bQKtX8Nnw7SYv6IMeVmiWP
			jHVDzSWJRnmuwAN3oM0GLs = D1DJtzviFZSrA('موقع يوتيوب - اختر الفلتر',ga1pf2D9JQTLmMGyk4jetPvXrW0)
			if jHVDzSWJRnmuwAN3oM0GLs == -1: return
			nuXhiECNxYUt6TBMSagv7l43m = qGD53zc2bQKtX8Nnw7SYv6IMeVmiWP[jHVDzSWJRnmuwAN3oM0GLs]
		if nuXhiECNxYUt6TBMSagv7l43m: XwyU6PQgprMI0 = NBm2aWhPzoTpdYn+nuXhiECNxYUt6TBMSagv7l43m
		elif ElVJ3XuygPMnHz5TpkLAQv: XwyU6PQgprMI0 = dR2vHyAtl8pJN1+ElVJ3XuygPMnHz5TpkLAQv
		else: XwyU6PQgprMI0 = dR2vHyAtl8pJN1
	xoiXMWjJC3pnQqurIGPkRSl8e(XwyU6PQgprMI0)
	return
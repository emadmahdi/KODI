# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'CIMACLUP'
mmDwMlfoHtG5XT19VLIWqCR8i = '_CMC_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
DDXTwbRBaj3e2rSsPQ = ['موقع نتفليكس']
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==490: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==491: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,text)
	elif mode==492: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==493: zpXG3Ky6ou8ndWHkb4 = hWPvGlXZ5arzV7(url)
	elif mode==494: zpXG3Ky6ou8ndWHkb4 = i7pbAuodvX3(url)
	elif mode==499: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text,url)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',NBm2aWhPzoTpdYn,'','','','','CIMACLUP-MENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	aPNBvIyexc053gAsSw1QoRMUYfb = GGvHJKP9LUxEk10Fw.findall('href="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	aPNBvIyexc053gAsSw1QoRMUYfb = aPNBvIyexc053gAsSw1QoRMUYfb[0].strip('/')
	aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(aPNBvIyexc053gAsSw1QoRMUYfb,'url')
	uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb = GGvHJKP9LUxEk10Fw.findall('"filter AjaxifyFilter"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb:
		UCEFMfKbgpd = uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb[0]
		items = GGvHJKP9LUxEk10Fw.findall('data-filter="(.*?)".*?>(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			if title in DDXTwbRBaj3e2rSsPQ: continue
			ELbNB92cOh5dqtpVmi40kY = aPNBvIyexc053gAsSw1QoRMUYfb+'/wp-content/themes/old/filter/'+ELbNB92cOh5dqtpVmi40kY+'.php'
			cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,491)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'أفلام',aPNBvIyexc053gAsSw1QoRMUYfb+'/category/افلام-movies-filme/foreign-hd-افلام-اجنبى-2',494,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'مسلسلات',aPNBvIyexc053gAsSw1QoRMUYfb+'/category/مسلسلات/مسلسلات-اجنبى',494,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="navigation-menu"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		if ELbNB92cOh5dqtpVmi40kY=='/': continue
		if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = aPNBvIyexc053gAsSw1QoRMUYfb+ELbNB92cOh5dqtpVmi40kY
		if title in DDXTwbRBaj3e2rSsPQ: continue
		cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,491)
	return BBlXpmUyhFDwNtCVAHoE
def i7pbAuodvX3(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','CIMACLUP-SUBMENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	xxcVm7YBMXsfd = GGvHJKP9LUxEk10Fw.findall('"filter"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if xxcVm7YBMXsfd:
		UCEFMfKbgpd = xxcVm7YBMXsfd[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			if title in DDXTwbRBaj3e2rSsPQ: continue
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,491)
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(url,nKuYjzcZEXky6Va5UdoJfH1xqstL=''):
	items = []
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','CIMACLUP-TITLES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	UCEFMfKbgpd = ''
	if '.php' in url: UCEFMfKbgpd = BBlXpmUyhFDwNtCVAHoE
	elif '?s=' in url:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"blocks(.*?)"manifest"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	else:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"Blocks(.*?)"manifest"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	if not UCEFMfKbgpd: return
	IcJOGsq3Ff7EmkiLx = []
	Dq0X5cvgdjwh6LbnUkETFBR8 = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
		title = DwNC3gEonizsB6a0v1F(title)
		qUGxSK2VwsiBAdkDZnJ605vQeg = GGvHJKP9LUxEk10Fw.findall('(.*?) حلقة \d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
		if not qUGxSK2VwsiBAdkDZnJ605vQeg: qUGxSK2VwsiBAdkDZnJ605vQeg = GGvHJKP9LUxEk10Fw.findall('(.*?) الحلقة \d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
		if not qUGxSK2VwsiBAdkDZnJ605vQeg or any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in Dq0X5cvgdjwh6LbnUkETFBR8):
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,492,VFqpJjRySZvgi)
		elif qUGxSK2VwsiBAdkDZnJ605vQeg and 'حلقة' in title:
			title = '_MOD_' + qUGxSK2VwsiBAdkDZnJ605vQeg[0]
			if title not in IcJOGsq3Ff7EmkiLx:
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,493,VFqpJjRySZvgi)
				IcJOGsq3Ff7EmkiLx.append(title)
		else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,493,VFqpJjRySZvgi)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"pagination"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('<li><a href="(.*?)".*?>(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			title = DwNC3gEonizsB6a0v1F(title)
			title = title.replace('الصفحة ','')
			if title!='': cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,491)
	return
def hWPvGlXZ5arzV7(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','CIMACLUP-EPISODES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	dR2vHyAtl8pJN1 = GGvHJKP9LUxEk10Fw.findall('"ButtonsBarCo".*?href="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if dR2vHyAtl8pJN1:
		dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1[0]
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',dR2vHyAtl8pJN1,'','','','','CIMACLUP-EPISODES-2nd')
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	VFqpJjRySZvgi = GGvHJKP9LUxEk10Fw.findall('"img-responsive" src="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if VFqpJjRySZvgi: VFqpJjRySZvgi = VFqpJjRySZvgi[0]
	else: VFqpJjRySZvgi = cEZpW924rqNYm5.getInfoLabel('ListItem.Thumb')
	xxcVm7YBMXsfd = GGvHJKP9LUxEk10Fw.findall('"filter"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb = GGvHJKP9LUxEk10Fw.findall('"Blocks(.*?)class="pagination"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if xxcVm7YBMXsfd and '/series/' not in url:
		UCEFMfKbgpd = xxcVm7YBMXsfd[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,493,VFqpJjRySZvgi)
	elif uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb:
		UCEFMfKbgpd = uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?image\:url\((.*?)\).*?"boxtitle">(.*?)</div>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if items:
			for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
				title = title.strip(' ')
				cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,492,VFqpJjRySZvgi)
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"pagination"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				title = DwNC3gEonizsB6a0v1F(title)
				title = title.replace('الصفحة ','')
				if title!='': cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,491)
	return
def SUfe4unWoXBNFz90xqy(url):
	dR2vHyAtl8pJN1 = url.strip('/')+'/?view=1'
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',dR2vHyAtl8pJN1,'','','','','CIMACLUP-PLAY-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	zzvBg3ShiamAZ = []
	aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(url,'url')
	Y5VwgWbBtTIAMsfRL8S4k = GGvHJKP9LUxEk10Fw.findall("data: 'q=(.*?)&",BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	Y5VwgWbBtTIAMsfRL8S4k = Y5VwgWbBtTIAMsfRL8S4k[0]
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"serversList"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('data-server="(.*?)">(.*?)</li>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for l3esWY6Jcjg9FTE,title in items:
			title = title.strip(' ')
			ELbNB92cOh5dqtpVmi40kY = aPNBvIyexc053gAsSw1QoRMUYfb+'/wp-content/themes/old/servers/server.php?q='+Y5VwgWbBtTIAMsfRL8S4k+'&i='+l3esWY6Jcjg9FTE+'?named='+title+'__watch'
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall('"embedServer".*?SRC="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if ELbNB92cOh5dqtpVmi40kY:
		title = 'مفضل'
		ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY[0]+'?named=__embed__'+title
		zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"downloadsList"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('<td>(.*?)</td>.*?href="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for title,ELbNB92cOh5dqtpVmi40kY in items:
			title = title.strip(' ')
			if 'anavidz' in ELbNB92cOh5dqtpVmi40kY: qPmCp1Q4gRekdAH = '__خاص'
			else: qPmCp1Q4gRekdAH = ''
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named='+title+'__download'+qPmCp1Q4gRekdAH
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(zzvBg3ShiamAZ,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search,aPNBvIyexc053gAsSw1QoRMUYfb=''):
	if not aPNBvIyexc053gAsSw1QoRMUYfb: aPNBvIyexc053gAsSw1QoRMUYfb = NBm2aWhPzoTpdYn
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if not search:
		search = yMRXZIpKxlSkaE6iCO()
		if not search: return
	search = search.replace(' ','+')
	url = aPNBvIyexc053gAsSw1QoRMUYfb+'/index.php?s='+search
	xoiXMWjJC3pnQqurIGPkRSl8e(url)
	return
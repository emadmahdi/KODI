# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
from PIL import ImageDraw as iWY9OsI5lM6tuDA2RfhmqkPdBQv,ImageFont as cgEXLHaeZI1Ky90fWdNo,Image as F8gpvxURGVTJ0eH
from arabic_reshaper import ArabicReshaper as K8Q9rSind42b
ucL0B1lWMCfAoEjG = 'EXCLUDES'
def SruhKcIXo9s3QnfV(WJr6B5imnN1Cypw,fjFdD8aKZeWcPVGwrY7Hg5uk4tE):
	fjFdD8aKZeWcPVGwrY7Hg5uk4tE = fjFdD8aKZeWcPVGwrY7Hg5uk4tE.replace('[COLOR FFC89008]','').replace(' [/COLOR]','')[1:]
	vmxrNGQUbXeDT2lYgJansPh = GGvHJKP9LUxEk10Fw.findall('[a-zA-Z]',WJr6B5imnN1Cypw,GGvHJKP9LUxEk10Fw.DOTALL)
	if 'بحث IPTV - ' in WJr6B5imnN1Cypw: WJr6B5imnN1Cypw = WJr6B5imnN1Cypw.replace('بحث IPTV - ',NQzGnR49rhjOA0qi7gu+'بحث IPTV - '+NQzGnR49rhjOA0qi7gu)
	elif ' IPTV' in WJr6B5imnN1Cypw and fjFdD8aKZeWcPVGwrY7Hg5uk4tE=='IPT': WJr6B5imnN1Cypw = NQzGnR49rhjOA0qi7gu+WJr6B5imnN1Cypw
	elif 'بحث M3U - ' in WJr6B5imnN1Cypw: WJr6B5imnN1Cypw = WJr6B5imnN1Cypw.replace('بحث M3U - ',NQzGnR49rhjOA0qi7gu+'بحث M3U - '+NQzGnR49rhjOA0qi7gu)
	elif ' M3U' in WJr6B5imnN1Cypw and fjFdD8aKZeWcPVGwrY7Hg5uk4tE=='M3U': WJr6B5imnN1Cypw = NQzGnR49rhjOA0qi7gu+WJr6B5imnN1Cypw
	elif 'بحث ' in WJr6B5imnN1Cypw and ' - ' in WJr6B5imnN1Cypw: WJr6B5imnN1Cypw = NQzGnR49rhjOA0qi7gu+WJr6B5imnN1Cypw
	elif not vmxrNGQUbXeDT2lYgJansPh:
		lNKYZHfVevQ9d8yUF42G0gi5x = GGvHJKP9LUxEk10Fw.findall('^( *?)(.*?)( *?)$',WJr6B5imnN1Cypw)
		QgcE9qpxCh1ANJF6kR,ALVgwH6l5zuxjPKfoQOGmb4BE,HVAG3lBcXyisQ7NmwO21tzYbqD = lNKYZHfVevQ9d8yUF42G0gi5x[0]
		WcLwS2HtKx0sQVqyrlCJPB = GGvHJKP9LUxEk10Fw.findall('^([!-~])',ALVgwH6l5zuxjPKfoQOGmb4BE)
		if WcLwS2HtKx0sQVqyrlCJPB: WJr6B5imnN1Cypw = QgcE9qpxCh1ANJF6kR+UUv3pbV4MsPa+ALVgwH6l5zuxjPKfoQOGmb4BE+HVAG3lBcXyisQ7NmwO21tzYbqD
		else: WJr6B5imnN1Cypw = HVAG3lBcXyisQ7NmwO21tzYbqD+NQzGnR49rhjOA0qi7gu+ALVgwH6l5zuxjPKfoQOGmb4BE+QgcE9qpxCh1ANJF6kR
	else:
		if 1:
			LCUFXZSuVKh = WJr6B5imnN1Cypw
			mRibAYrCXgp6nkfuBQNvwHFdP5zMG = Y5rNeFs8E7UJqRAQ9kP6.get_display(WJr6B5imnN1Cypw,base_dir='L')
			if HHosl5fRdhtEDAYyP: LCUFXZSuVKh = LCUFXZSuVKh.decode('utf8')
			if HHosl5fRdhtEDAYyP: mRibAYrCXgp6nkfuBQNvwHFdP5zMG = mRibAYrCXgp6nkfuBQNvwHFdP5zMG.decode('utf8')
			HPv9E5YkrRtLNcoWUqfl2emxJ = LCUFXZSuVKh.split(' ')
			YYam6cVM1bEdujzBvDU = mRibAYrCXgp6nkfuBQNvwHFdP5zMG.split(' ')
			UK0oTenvry6hYMuiDqIalc,Nu8hXaioV4vgt9rKOejycE2FJWpGU,ebAIWv0zjmcK5kgON1CJ,L9PVo1YAd3Evar0IB7i = [],[],'',''
			kkwLRoKSsqJtB = zip(HPv9E5YkrRtLNcoWUqfl2emxJ,YYam6cVM1bEdujzBvDU)
			for ddHwjoOaFyMUYL2BRkEbX6,sPbBRjOKEqM in kkwLRoKSsqJtB:
				if ddHwjoOaFyMUYL2BRkEbX6==sPbBRjOKEqM=='' and L9PVo1YAd3Evar0IB7i:
					ebAIWv0zjmcK5kgON1CJ += ' '
					continue
				if ddHwjoOaFyMUYL2BRkEbX6==sPbBRjOKEqM:
					HGN0Fgpl3oqaiBPjnSR4X9bLkZ = 'EN'
					if L9PVo1YAd3Evar0IB7i==HGN0Fgpl3oqaiBPjnSR4X9bLkZ: ebAIWv0zjmcK5kgON1CJ += ' '+ddHwjoOaFyMUYL2BRkEbX6
					elif ddHwjoOaFyMUYL2BRkEbX6:
						if ebAIWv0zjmcK5kgON1CJ:
							Nu8hXaioV4vgt9rKOejycE2FJWpGU.append(ebAIWv0zjmcK5kgON1CJ)
							UK0oTenvry6hYMuiDqIalc.append('')
						ebAIWv0zjmcK5kgON1CJ = ddHwjoOaFyMUYL2BRkEbX6
				else:
					HGN0Fgpl3oqaiBPjnSR4X9bLkZ = 'AR'
					if L9PVo1YAd3Evar0IB7i==HGN0Fgpl3oqaiBPjnSR4X9bLkZ: ebAIWv0zjmcK5kgON1CJ += ' '+ddHwjoOaFyMUYL2BRkEbX6
					elif ddHwjoOaFyMUYL2BRkEbX6:
						if ebAIWv0zjmcK5kgON1CJ:
							UK0oTenvry6hYMuiDqIalc.append(ebAIWv0zjmcK5kgON1CJ)
							Nu8hXaioV4vgt9rKOejycE2FJWpGU.append('')
						ebAIWv0zjmcK5kgON1CJ = ddHwjoOaFyMUYL2BRkEbX6
				L9PVo1YAd3Evar0IB7i = HGN0Fgpl3oqaiBPjnSR4X9bLkZ
			if HGN0Fgpl3oqaiBPjnSR4X9bLkZ=='EN':
				UK0oTenvry6hYMuiDqIalc.append(ebAIWv0zjmcK5kgON1CJ)
				Nu8hXaioV4vgt9rKOejycE2FJWpGU.append('')
			else:
				Nu8hXaioV4vgt9rKOejycE2FJWpGU.append(ebAIWv0zjmcK5kgON1CJ)
				UK0oTenvry6hYMuiDqIalc.append('')
			w1Yi3fQM06qv = ''
			kkwLRoKSsqJtB = zip(UK0oTenvry6hYMuiDqIalc,Nu8hXaioV4vgt9rKOejycE2FJWpGU)
			for haoMObFPfStWIx,vLmfYWOpjVNXls7qe2AMJg8G in kkwLRoKSsqJtB:
				if haoMObFPfStWIx: w1Yi3fQM06qv += ' '+haoMObFPfStWIx
				else:
					WcLwS2HtKx0sQVqyrlCJPB = GGvHJKP9LUxEk10Fw.findall('([!-~]) *$',vLmfYWOpjVNXls7qe2AMJg8G)
					if WcLwS2HtKx0sQVqyrlCJPB:
						WcLwS2HtKx0sQVqyrlCJPB = WcLwS2HtKx0sQVqyrlCJPB[0]
						try:
							Ml4i2beZUqX = dPAWpDKx0TBlMJjy5E2fh.MIRRORED[WcLwS2HtKx0sQVqyrlCJPB]
							lNKYZHfVevQ9d8yUF42G0gi5x = GGvHJKP9LUxEk10Fw.findall('^( *?)(.*?)( *?)$',vLmfYWOpjVNXls7qe2AMJg8G)
							if lNKYZHfVevQ9d8yUF42G0gi5x: QgcE9qpxCh1ANJF6kR,vLmfYWOpjVNXls7qe2AMJg8G,HVAG3lBcXyisQ7NmwO21tzYbqD = lNKYZHfVevQ9d8yUF42G0gi5x[0]
							vLmfYWOpjVNXls7qe2AMJg8G = QgcE9qpxCh1ANJF6kR+Ml4i2beZUqX+vLmfYWOpjVNXls7qe2AMJg8G[:-1]+HVAG3lBcXyisQ7NmwO21tzYbqD
						except: pass
					w1Yi3fQM06qv += ' '+vLmfYWOpjVNXls7qe2AMJg8G
			WJr6B5imnN1Cypw = w1Yi3fQM06qv[1:]
			if HHosl5fRdhtEDAYyP: WJr6B5imnN1Cypw = WJr6B5imnN1Cypw.encode('utf8')
		else:
			if HHosl5fRdhtEDAYyP: WJr6B5imnN1Cypw = WJr6B5imnN1Cypw.decode('utf8')
			WJr6B5imnN1Cypw = Y5rNeFs8E7UJqRAQ9kP6.get_display(WJr6B5imnN1Cypw)
			LCUFXZSuVKh,mRibAYrCXgp6nkfuBQNvwHFdP5zMG = WJr6B5imnN1Cypw,WJr6B5imnN1Cypw
			if 1:
				L9PVo1YAd3Evar0IB7i,VvWPqmCR0NlYaxFQrXUtMGgE = '',[]
				yGV6vgjOfUDHe0bRCJtrIpXu8oZzA = WJr6B5imnN1Cypw.split(' ')
				for IIdL96fpC4Wwo8P1 in yGV6vgjOfUDHe0bRCJtrIpXu8oZzA:
					if not IIdL96fpC4Wwo8P1:
						if VvWPqmCR0NlYaxFQrXUtMGgE: VvWPqmCR0NlYaxFQrXUtMGgE[-1] += ' '
						else: VvWPqmCR0NlYaxFQrXUtMGgE.append('')
						continue
					LBFZv3WmQSiJKNrInbkM7V = GGvHJKP9LUxEk10Fw.findall('[!-~]',IIdL96fpC4Wwo8P1[0])
					if LBFZv3WmQSiJKNrInbkM7V==L9PVo1YAd3Evar0IB7i and VvWPqmCR0NlYaxFQrXUtMGgE: VvWPqmCR0NlYaxFQrXUtMGgE[-1] += ' '+IIdL96fpC4Wwo8P1
					else:
						if VvWPqmCR0NlYaxFQrXUtMGgE:
							HqLZJGDr4XTmv3sdM9I58W = GGvHJKP9LUxEk10Fw.findall('[^!-~]',VvWPqmCR0NlYaxFQrXUtMGgE[-1])
							if HqLZJGDr4XTmv3sdM9I58W:
								VvWPqmCR0NlYaxFQrXUtMGgE[-1] = Y5rNeFs8E7UJqRAQ9kP6.get_display(VvWPqmCR0NlYaxFQrXUtMGgE[-1])
								qH9BrEdMumK1kfS5 = GGvHJKP9LUxEk10Fw.findall('^ +',VvWPqmCR0NlYaxFQrXUtMGgE[-1])
								if qH9BrEdMumK1kfS5: VvWPqmCR0NlYaxFQrXUtMGgE[-1] = VvWPqmCR0NlYaxFQrXUtMGgE[-1].lstrip(' ')+qH9BrEdMumK1kfS5[0]
						VvWPqmCR0NlYaxFQrXUtMGgE.append(IIdL96fpC4Wwo8P1)
					L9PVo1YAd3Evar0IB7i = LBFZv3WmQSiJKNrInbkM7V
				if VvWPqmCR0NlYaxFQrXUtMGgE: VvWPqmCR0NlYaxFQrXUtMGgE[-1] = Y5rNeFs8E7UJqRAQ9kP6.get_display(VvWPqmCR0NlYaxFQrXUtMGgE[-1])
				WJr6B5imnN1Cypw = ' '.join(VvWPqmCR0NlYaxFQrXUtMGgE)
			if HHosl5fRdhtEDAYyP: WJr6B5imnN1Cypw = WJr6B5imnN1Cypw.encode('utf8')
	return WJr6B5imnN1Cypw
def MNBcU3JpngmEZt9fCseuWdwkDh6(O6ajtFmEdzo3WBIYin4GxqK95fp,qeCUmHSJwr4RkZhYGbiMpO,udC8LvNthYf):
	QTcZbyNIfxeU84vs5LBophFmqMAn6,WJr6B5imnN1Cypw,kk1GKyapocQZDAz,VRnfEFmJzUrSljM8,TF42IOaD6Gc,Wl1w5TsVdNYJyOoF92Px8i,bqVkngzedy7ADpWx0,BZzGu5Dp6f3jbTW04Mxco8yE,Q16YwhAIPHb9Cgj4F = O6ajtFmEdzo3WBIYin4GxqK95fp
	VRnfEFmJzUrSljM8 = int(VRnfEFmJzUrSljM8)
	zNLOdmGXrEnsI1DtRYqUviAlejV = GGvHJKP9LUxEk10Fw.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',WJr6B5imnN1Cypw,GGvHJKP9LUxEk10Fw.DOTALL)
	if zNLOdmGXrEnsI1DtRYqUviAlejV:
		zNLOdmGXrEnsI1DtRYqUviAlejV,fOKRmLJgvA9cuE5Cq0klnGV,FFhNrg3O08ZoKJUXkj = zNLOdmGXrEnsI1DtRYqUviAlejV[0]
		WJr6B5imnN1Cypw = WJr6B5imnN1Cypw.replace(zNLOdmGXrEnsI1DtRYqUviAlejV,'')
	LLxmWf2Nh0XD5uSIe7CrtHynv3K4QR = WJr6B5imnN1Cypw
	fjFdD8aKZeWcPVGwrY7Hg5uk4tE = GGvHJKP9LUxEk10Fw.findall('^_(\w\w\w)_(.*?)$',WJr6B5imnN1Cypw,GGvHJKP9LUxEk10Fw.DOTALL)
	if fjFdD8aKZeWcPVGwrY7Hg5uk4tE:
		fjFdD8aKZeWcPVGwrY7Hg5uk4tE,WJr6B5imnN1Cypw = fjFdD8aKZeWcPVGwrY7Hg5uk4tE[0]
		QQVSwsNnPvpl6GkoqiC9g132YR = '_MOD_' in WJr6B5imnN1Cypw
		Kkecj5WTsm9rwlSJu1xqQLN = QTcZbyNIfxeU84vs5LBophFmqMAn6=='folder'
		if QQVSwsNnPvpl6GkoqiC9g132YR and Kkecj5WTsm9rwlSJu1xqQLN: cZ4lExhjBNvmp3OPyWQAT6s8 = ';'
		elif QQVSwsNnPvpl6GkoqiC9g132YR and not Kkecj5WTsm9rwlSJu1xqQLN: cZ4lExhjBNvmp3OPyWQAT6s8 = P4F7od5xLE0quekH3nSzXj92ThwINY
		elif not QQVSwsNnPvpl6GkoqiC9g132YR and Kkecj5WTsm9rwlSJu1xqQLN: cZ4lExhjBNvmp3OPyWQAT6s8 = ','
		elif not QQVSwsNnPvpl6GkoqiC9g132YR and not Kkecj5WTsm9rwlSJu1xqQLN: cZ4lExhjBNvmp3OPyWQAT6s8 = ' '
		WJr6B5imnN1Cypw = WJr6B5imnN1Cypw.replace('_MOD_','')
		fjFdD8aKZeWcPVGwrY7Hg5uk4tE = cZ4lExhjBNvmp3OPyWQAT6s8+'[COLOR FFC89008]'+fjFdD8aKZeWcPVGwrY7Hg5uk4tE+' [/COLOR]'
	else: fjFdD8aKZeWcPVGwrY7Hg5uk4tE = ''
	if zNLOdmGXrEnsI1DtRYqUviAlejV:
		if HHosl5fRdhtEDAYyP:
			zNLOdmGXrEnsI1DtRYqUviAlejV = '[COLOR FFFFFF00]'+fOKRmLJgvA9cuE5Cq0klnGV+' '+FFhNrg3O08ZoKJUXkj+'[/COLOR]'
			if fjFdD8aKZeWcPVGwrY7Hg5uk4tE: WJr6B5imnN1Cypw = zNLOdmGXrEnsI1DtRYqUviAlejV+' '+NQzGnR49rhjOA0qi7gu+fjFdD8aKZeWcPVGwrY7Hg5uk4tE+WJr6B5imnN1Cypw
			else: WJr6B5imnN1Cypw = zNLOdmGXrEnsI1DtRYqUviAlejV+NQzGnR49rhjOA0qi7gu+WJr6B5imnN1Cypw+' '
		elif u4ChFMGf6K93tbDjJ12zi0YQsAHyP:
			if fjFdD8aKZeWcPVGwrY7Hg5uk4tE:
				zNLOdmGXrEnsI1DtRYqUviAlejV = '[COLOR FFFFFF00]'+fOKRmLJgvA9cuE5Cq0klnGV+' '+FFhNrg3O08ZoKJUXkj+'[/COLOR]'
				WJr6B5imnN1Cypw = zNLOdmGXrEnsI1DtRYqUviAlejV+' '+fjFdD8aKZeWcPVGwrY7Hg5uk4tE+WJr6B5imnN1Cypw
			else:
				zNLOdmGXrEnsI1DtRYqUviAlejV = '[COLOR FFFFFF00]'+FFhNrg3O08ZoKJUXkj+' '+fOKRmLJgvA9cuE5Cq0klnGV+'[/COLOR]'
				WJr6B5imnN1Cypw = WJr6B5imnN1Cypw+' '+NQzGnR49rhjOA0qi7gu+zNLOdmGXrEnsI1DtRYqUviAlejV
	elif fjFdD8aKZeWcPVGwrY7Hg5uk4tE:
		WJr6B5imnN1Cypw = SruhKcIXo9s3QnfV(WJr6B5imnN1Cypw,fjFdD8aKZeWcPVGwrY7Hg5uk4tE)
		WJr6B5imnN1Cypw = fjFdD8aKZeWcPVGwrY7Hg5uk4tE+WJr6B5imnN1Cypw
	O6ajtFmEdzo3WBIYin4GxqK95fp = QTcZbyNIfxeU84vs5LBophFmqMAn6,LLxmWf2Nh0XD5uSIe7CrtHynv3K4QR,kk1GKyapocQZDAz,str(VRnfEFmJzUrSljM8),TF42IOaD6Gc,Wl1w5TsVdNYJyOoF92Px8i,bqVkngzedy7ADpWx0,BZzGu5Dp6f3jbTW04Mxco8yE,Q16YwhAIPHb9Cgj4F
	uqTLIvSOoMh = {'type':'','mode':'','url':'','text':'','page':'','name':'','image':'','context':'','infodict':''}
	uqTLIvSOoMh['name'] = mGfdCk4Hyclg9RjD(LLxmWf2Nh0XD5uSIe7CrtHynv3K4QR)
	uqTLIvSOoMh['type'] = QTcZbyNIfxeU84vs5LBophFmqMAn6.strip(' ')
	uqTLIvSOoMh['mode'] = str(VRnfEFmJzUrSljM8).strip(' ')
	if QTcZbyNIfxeU84vs5LBophFmqMAn6=='folder' and Wl1w5TsVdNYJyOoF92Px8i: uqTLIvSOoMh['page'] = mGfdCk4Hyclg9RjD(Wl1w5TsVdNYJyOoF92Px8i.strip(' '))
	if BZzGu5Dp6f3jbTW04Mxco8yE: uqTLIvSOoMh['context'] = BZzGu5Dp6f3jbTW04Mxco8yE.strip(' ')
	if bqVkngzedy7ADpWx0: uqTLIvSOoMh['text'] = mGfdCk4Hyclg9RjD(bqVkngzedy7ADpWx0.strip(' '))
	if TF42IOaD6Gc: uqTLIvSOoMh['image'] = mGfdCk4Hyclg9RjD(TF42IOaD6Gc.strip(' '))
	if Q16YwhAIPHb9Cgj4F:
		Q16YwhAIPHb9Cgj4F = str(Q16YwhAIPHb9Cgj4F)
		uqTLIvSOoMh['infodict'] = mGfdCk4Hyclg9RjD(Q16YwhAIPHb9Cgj4F.strip(' '))
		Q16YwhAIPHb9Cgj4F = eval(Q16YwhAIPHb9Cgj4F)
	else: Q16YwhAIPHb9Cgj4F = {}
	if kk1GKyapocQZDAz: uqTLIvSOoMh['url'] = mGfdCk4Hyclg9RjD(kk1GKyapocQZDAz.strip(' '))
	d8dUpVzoanjGw = {'name':'','context_menu':'','plot':'','stars':'','image':'','type':'','isFolder':'','newpath':'','duration':''}
	vBhsfxXCMyjZpPHTl8r6kI7EmV = []
	D0DQNiZMmVsL61 = 'plugin://'+ssZLBRtgnMkc7dSouQeGCx3r8m+'/?type='+uqTLIvSOoMh['type']+'&mode='+uqTLIvSOoMh['mode']
	if uqTLIvSOoMh['page']: D0DQNiZMmVsL61 += '&page='+uqTLIvSOoMh['page']
	if uqTLIvSOoMh['name']: D0DQNiZMmVsL61 += '&name='+uqTLIvSOoMh['name']
	if uqTLIvSOoMh['text']: D0DQNiZMmVsL61 += '&text='+uqTLIvSOoMh['text']
	if uqTLIvSOoMh['infodict']: D0DQNiZMmVsL61 += '&infodict='+uqTLIvSOoMh['infodict']
	if uqTLIvSOoMh['image']: D0DQNiZMmVsL61 += '&image='+uqTLIvSOoMh['image']
	if uqTLIvSOoMh['url']: D0DQNiZMmVsL61 += '&url='+uqTLIvSOoMh['url']
	if VRnfEFmJzUrSljM8!=265: d8dUpVzoanjGw['favorites'] = True
	else: d8dUpVzoanjGw['favorites'] = False
	if uqTLIvSOoMh['context']: D0DQNiZMmVsL61 += '&context='+uqTLIvSOoMh['context']
	if VRnfEFmJzUrSljM8 in [235,238] and QTcZbyNIfxeU84vs5LBophFmqMAn6=='live' and 'EPG' in BZzGu5Dp6f3jbTW04Mxco8yE:
		qWcMist1Ru5ZU = 'plugin://'+ssZLBRtgnMkc7dSouQeGCx3r8m+'?mode=238&text=SHORT_EPG&url='+kk1GKyapocQZDAz
		hhBATCjaNpGkV9iQu8RbyXt2r0EZH5 = '[COLOR FFFFFF00]البرامج القادمة[/COLOR]'
		l3lcVOG5hYuCPLo = (hhBATCjaNpGkV9iQu8RbyXt2r0EZH5,'RunPlugin('+qWcMist1Ru5ZU+')')
		vBhsfxXCMyjZpPHTl8r6kI7EmV.append(l3lcVOG5hYuCPLo)
	if VRnfEFmJzUrSljM8==265:
		IbqVpM2HXP98kWtfDw3A = qeCUmHSJwr4RkZhYGbiMpO(bqVkngzedy7ADpWx0,True)
		if IbqVpM2HXP98kWtfDw3A>0:
			qWcMist1Ru5ZU = 'plugin://'+ssZLBRtgnMkc7dSouQeGCx3r8m+'?mode=266&text='+bqVkngzedy7ADpWx0
			hhBATCjaNpGkV9iQu8RbyXt2r0EZH5 = '[COLOR FFFFFF00]مسح قائمة آخر 50 '+wPGkbaD7x6(bqVkngzedy7ADpWx0)+'[/COLOR]'
			l3lcVOG5hYuCPLo = (hhBATCjaNpGkV9iQu8RbyXt2r0EZH5,'RunPlugin('+qWcMist1Ru5ZU+')')
			vBhsfxXCMyjZpPHTl8r6kI7EmV.append(l3lcVOG5hYuCPLo)
	if QTcZbyNIfxeU84vs5LBophFmqMAn6=='video' and VRnfEFmJzUrSljM8!=331:
		qWcMist1Ru5ZU = D0DQNiZMmVsL61+'&context=6_DOWNLOAD'
		hhBATCjaNpGkV9iQu8RbyXt2r0EZH5 = '[COLOR FFFFFF00]تحميل ملف الفيديو[/COLOR]'
		l3lcVOG5hYuCPLo = (hhBATCjaNpGkV9iQu8RbyXt2r0EZH5,'RunPlugin('+qWcMist1Ru5ZU+')')
		vBhsfxXCMyjZpPHTl8r6kI7EmV.append(l3lcVOG5hYuCPLo)
	if VRnfEFmJzUrSljM8==331:
		qWcMist1Ru5ZU = D0DQNiZMmVsL61+'&context=6_DELETE'
		hhBATCjaNpGkV9iQu8RbyXt2r0EZH5 = '[COLOR FFFFFF00]حذف ملف الفيديو[/COLOR]'
		l3lcVOG5hYuCPLo = (hhBATCjaNpGkV9iQu8RbyXt2r0EZH5,'RunPlugin('+qWcMist1Ru5ZU+')')
		vBhsfxXCMyjZpPHTl8r6kI7EmV.append(l3lcVOG5hYuCPLo)
	if QTcZbyNIfxeU84vs5LBophFmqMAn6=='folder' and VRnfEFmJzUrSljM8==540:
		RRMg0XlUpFTjsxyIPi = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,'list','GLOBALSEARCH_SITES')
		if RRMg0XlUpFTjsxyIPi:
			qWcMist1Ru5ZU = 'plugin://'+ssZLBRtgnMkc7dSouQeGCx3r8m+'?context=7'
			hhBATCjaNpGkV9iQu8RbyXt2r0EZH5 = '[COLOR FFFFFF00]مسح جميع كلمات البحث[/COLOR]'
			l3lcVOG5hYuCPLo = (hhBATCjaNpGkV9iQu8RbyXt2r0EZH5,'RunPlugin('+qWcMist1Ru5ZU+')')
			vBhsfxXCMyjZpPHTl8r6kI7EmV.append(l3lcVOG5hYuCPLo)
	RmUjCou3c2G7 = [9990,2,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,540,710,719,761,762]
	if VRnfEFmJzUrSljM8 not in RmUjCou3c2G7:
		qWcMist1Ru5ZU = 'plugin://'+ssZLBRtgnMkc7dSouQeGCx3r8m+'?context=8&mode=260'
		hhBATCjaNpGkV9iQu8RbyXt2r0EZH5 = '[COLOR FFFFFF00]القائمة الرئيسية[/COLOR]'
		l3lcVOG5hYuCPLo = (hhBATCjaNpGkV9iQu8RbyXt2r0EZH5,'RunPlugin('+qWcMist1Ru5ZU+')')
		vBhsfxXCMyjZpPHTl8r6kI7EmV.append(l3lcVOG5hYuCPLo)
	QUbjVgr8D4B1mAKhEFHMc9t = [0,150,160,170,190,260,280,330,340,410,500,520,530,560,760]
	if VRnfEFmJzUrSljM8%10 and VRnfEFmJzUrSljM8!=9990:
		ITNRajBKCD = VRnfEFmJzUrSljM8-VRnfEFmJzUrSljM8%10
		if ITNRajBKCD==280: ITNRajBKCD = 230
		if ITNRajBKCD==410: ITNRajBKCD = 400
		if ITNRajBKCD==520: ITNRajBKCD = 510
		if ITNRajBKCD not in QUbjVgr8D4B1mAKhEFHMc9t:
			qWcMist1Ru5ZU = 'plugin://'+ssZLBRtgnMkc7dSouQeGCx3r8m+'?context=8&mode='+str(ITNRajBKCD)
			hhBATCjaNpGkV9iQu8RbyXt2r0EZH5 = '[COLOR FFFFFF00]قائمة الموقع[/COLOR]'
			l3lcVOG5hYuCPLo = (hhBATCjaNpGkV9iQu8RbyXt2r0EZH5,'RunPlugin('+qWcMist1Ru5ZU+')')
			vBhsfxXCMyjZpPHTl8r6kI7EmV.append(l3lcVOG5hYuCPLo)
	qWcMist1Ru5ZU = D0DQNiZMmVsL61+'&context=9'
	hhBATCjaNpGkV9iQu8RbyXt2r0EZH5 = '[COLOR FFFFFF00]تحديث القائمة[/COLOR]'
	l3lcVOG5hYuCPLo = (hhBATCjaNpGkV9iQu8RbyXt2r0EZH5,'RunPlugin('+qWcMist1Ru5ZU+')')
	vBhsfxXCMyjZpPHTl8r6kI7EmV.append(l3lcVOG5hYuCPLo)
	if QTcZbyNIfxeU84vs5LBophFmqMAn6 in ['link','video','live']: llmVMupR71qcHkU4D = False
	elif QTcZbyNIfxeU84vs5LBophFmqMAn6=='folder': llmVMupR71qcHkU4D = True
	d8dUpVzoanjGw['name'] = WJr6B5imnN1Cypw
	d8dUpVzoanjGw['context_menu'] = vBhsfxXCMyjZpPHTl8r6kI7EmV
	if 'plot' in list(Q16YwhAIPHb9Cgj4F.keys()): d8dUpVzoanjGw['plot'] = Q16YwhAIPHb9Cgj4F['plot']
	if 'stars' in list(Q16YwhAIPHb9Cgj4F.keys()): d8dUpVzoanjGw['stars'] = Q16YwhAIPHb9Cgj4F['stars']
	if TF42IOaD6Gc: d8dUpVzoanjGw['image'] = TF42IOaD6Gc
	if QTcZbyNIfxeU84vs5LBophFmqMAn6=='video' and Wl1w5TsVdNYJyOoF92Px8i:
		JP6KeQnB3AqWOh = GGvHJKP9LUxEk10Fw.findall('[\d:]+',Wl1w5TsVdNYJyOoF92Px8i,GGvHJKP9LUxEk10Fw.DOTALL)
		if JP6KeQnB3AqWOh:
			JP6KeQnB3AqWOh = '0:0:0:0:0:'+JP6KeQnB3AqWOh[0]
			KCD6TolwuY04WaLshzSpEqOFUV,BdvGfl38W2YSxR0IpTrXn1JDiFU4jO,hzuQWMKY7E0brZDiTUV6ocP,wHvybC2tZ4L0kG3pfoOghNXRciP,AAb6m9zupsB0GiM2wUH4fqJtOKQdZ = JP6KeQnB3AqWOh.rsplit(':',4)
			WezD1U53OICBPZSVKHatjELT = int(BdvGfl38W2YSxR0IpTrXn1JDiFU4jO)*24*EE1u6LYDqNpi+int(hzuQWMKY7E0brZDiTUV6ocP)*EE1u6LYDqNpi+int(wHvybC2tZ4L0kG3pfoOghNXRciP)*60+int(AAb6m9zupsB0GiM2wUH4fqJtOKQdZ)
			d8dUpVzoanjGw['duration'] = WezD1U53OICBPZSVKHatjELT
	d8dUpVzoanjGw['type'] = QTcZbyNIfxeU84vs5LBophFmqMAn6
	d8dUpVzoanjGw['isFolder'] = llmVMupR71qcHkU4D
	d8dUpVzoanjGw['newpath'] = D0DQNiZMmVsL61
	d8dUpVzoanjGw['menuItem'] = O6ajtFmEdzo3WBIYin4GxqK95fp
	d8dUpVzoanjGw['mode'] = VRnfEFmJzUrSljM8
	return d8dUpVzoanjGw
def knXiBdhtmFIQGD(qeCUmHSJwr4RkZhYGbiMpO):
	pBhZGD7fw4br = []
	from ILG9YzDbKk import WW7LRjMc4iCplzdXB,yi0Zf5IPxWcVrHjCBm71w
	udC8LvNthYf = WW7LRjMc4iCplzdXB()
	for O6ajtFmEdzo3WBIYin4GxqK95fp in D6DrJsclfY:
		d8dUpVzoanjGw = MNBcU3JpngmEZt9fCseuWdwkDh6(O6ajtFmEdzo3WBIYin4GxqK95fp,qeCUmHSJwr4RkZhYGbiMpO,udC8LvNthYf)
		if d8dUpVzoanjGw['favorites']:
			VjvYS1enA7hstN = yi0Zf5IPxWcVrHjCBm71w(udC8LvNthYf,d8dUpVzoanjGw['menuItem'],d8dUpVzoanjGw['newpath'])
			d8dUpVzoanjGw['context_menu'] = VjvYS1enA7hstN+d8dUpVzoanjGw['context_menu']
		pBhZGD7fw4br.append(d8dUpVzoanjGw)
	return pBhZGD7fw4br
def l1BqHEWVt7Dk(cXQ84du5sj97FvCiOoqTwJhWk16z):
	cZ4lExhjBNvmp3OPyWQAT6s8,NuaGd5gO60qb1Ts9, = [],''
	for ulk0vBZaNR in cXQ84du5sj97FvCiOoqTwJhWk16z:
		if not ulk0vBZaNR: cZ4lExhjBNvmp3OPyWQAT6s8.append('')
		else: break
	cXQ84du5sj97FvCiOoqTwJhWk16z = cXQ84du5sj97FvCiOoqTwJhWk16z[len(cZ4lExhjBNvmp3OPyWQAT6s8):]
	MMupPCxqkenwt6FlsbRILV37EAmB = '\n\n\n\n'.join(cXQ84du5sj97FvCiOoqTwJhWk16z)
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('===== ===== =====','000001')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('[COLOR FFC89008]','000002')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('[COLOR FFFFFF00]','000003')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('[/COLOR]','000004')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('[RIGHT]','000005')
	akVPDzJGgWi4vK3jNt0eCsuLUm9cZF = 100000
	jTXmnYSF4c3ODieqUP8 = {}
	MM6LqD4RcwKf9IVkQ = GGvHJKP9LUxEk10Fw.findall('http.*?[\r\n ]',MMupPCxqkenwt6FlsbRILV37EAmB,GGvHJKP9LUxEk10Fw.DOTALL)
	for wwPKjQEn7DxeFYyRo9 in MM6LqD4RcwKf9IVkQ:
		akVPDzJGgWi4vK3jNt0eCsuLUm9cZF += 1
		MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace(wwPKjQEn7DxeFYyRo9,str(akVPDzJGgWi4vK3jNt0eCsuLUm9cZF))
		jTXmnYSF4c3ODieqUP8[str(akVPDzJGgWi4vK3jNt0eCsuLUm9cZF)] = wwPKjQEn7DxeFYyRo9
	for L4SCkrby5m8gjWwHOn0fJuhqQYvUN in range(0,len(MMupPCxqkenwt6FlsbRILV37EAmB),4800):
		BRQpOtCEylv = MMupPCxqkenwt6FlsbRILV37EAmB[L4SCkrby5m8gjWwHOn0fJuhqQYvUN:L4SCkrby5m8gjWwHOn0fJuhqQYvUN+4800]
		FXe97l2bPY6uKBySxG1 = jHevARrF7lS.getSetting('av.language.code')
		kk1GKyapocQZDAz = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+FXe97l2bPY6uKBySxG1
		vqNwzh36FVc = {'Content-Type':'text/plain'}
		XMizba85pAG = BRQpOtCEylv.encode('utf8')
		zGmyJhleoQZ = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,'POST',kk1GKyapocQZDAz,XMizba85pAG,vqNwzh36FVc,'','','LIBRARY-GLOSBE_TRANSLATE-1st')
		if zGmyJhleoQZ.succeeded:
			xKglJoD3q9IepZMPjO2Lw4vBNG7HuS = zGmyJhleoQZ.content
			zs78bVKMxcl29OwYUTnPfBNo4kCXG = JKw5OWktPZB('str',xKglJoD3q9IepZMPjO2Lw4vBNG7HuS)
			if zs78bVKMxcl29OwYUTnPfBNo4kCXG:
				zs78bVKMxcl29OwYUTnPfBNo4kCXG = zs78bVKMxcl29OwYUTnPfBNo4kCXG['translation']
				zs78bVKMxcl29OwYUTnPfBNo4kCXG = ptMqV54oKJhQ8CH(zs78bVKMxcl29OwYUTnPfBNo4kCXG)
				for GBFbN7Xqch6uSWt in range(len(zs78bVKMxcl29OwYUTnPfBNo4kCXG)):
					NuaGd5gO60qb1Ts9 += zs78bVKMxcl29OwYUTnPfBNo4kCXG[GBFbN7Xqch6uSWt][0]
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.replace('000001','===== ===== =====')
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.replace('000002','[COLOR FFC89008]')
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.replace('000003','[COLOR FFFFFF00]')
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.replace('000004','[/COLOR]')
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.replace('000005','[RIGHT]')
	for akVPDzJGgWi4vK3jNt0eCsuLUm9cZF in list(jTXmnYSF4c3ODieqUP8.keys()):
		wwPKjQEn7DxeFYyRo9 = jTXmnYSF4c3ODieqUP8[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF]
		NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.replace(akVPDzJGgWi4vK3jNt0eCsuLUm9cZF,wwPKjQEn7DxeFYyRo9)
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.split('\n\n\n\n')
	return cZ4lExhjBNvmp3OPyWQAT6s8+NuaGd5gO60qb1Ts9
def cI9oQ0ZUEdp5LGPxNhT6(cXQ84du5sj97FvCiOoqTwJhWk16z):
	cZ4lExhjBNvmp3OPyWQAT6s8,NuaGd5gO60qb1Ts9, = [],''
	for ulk0vBZaNR in cXQ84du5sj97FvCiOoqTwJhWk16z:
		if not ulk0vBZaNR: cZ4lExhjBNvmp3OPyWQAT6s8.append('')
		else: break
	cXQ84du5sj97FvCiOoqTwJhWk16z = cXQ84du5sj97FvCiOoqTwJhWk16z[len(cZ4lExhjBNvmp3OPyWQAT6s8):]
	MMupPCxqkenwt6FlsbRILV37EAmB = '\\n\\n\\n\\n'.join(cXQ84du5sj97FvCiOoqTwJhWk16z)
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('كلا','no')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('استمرار','continue')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('===== ===== =====','000001')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('[COLOR FFC89008]','000002')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('[COLOR FFFFFF00]','000003')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('[/COLOR]','000004')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('[RIGHT]','000005')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('[CENTER]','000006')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('[RTL]','000007')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace("'","\\\\\\'")
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('"','\\\\\\"')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('\n','\\n')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('\r','\\\\r')
	for L4SCkrby5m8gjWwHOn0fJuhqQYvUN in range(0,len(MMupPCxqkenwt6FlsbRILV37EAmB),4800):
		BRQpOtCEylv = MMupPCxqkenwt6FlsbRILV37EAmB[L4SCkrby5m8gjWwHOn0fJuhqQYvUN:L4SCkrby5m8gjWwHOn0fJuhqQYvUN+4800]
		kk1GKyapocQZDAz = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		vqNwzh36FVc = {'Content-Type':'application/x-www-form-urlencoded'}
		FXe97l2bPY6uKBySxG1 = jHevARrF7lS.getSetting('av.language.code')
		XMizba85pAG = 'f.req='+mGfdCk4Hyclg9RjD('[[["MkEWBc","[[\\"'+BRQpOtCEylv+'\\",\\"ar\\",\\"'+FXe97l2bPY6uKBySxG1+'\\",1],[]]",null,"generic"]]]','')
		XMizba85pAG = XMizba85pAG.replace('%5Cn','%5C%5Cn')
		zGmyJhleoQZ = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,'POST',kk1GKyapocQZDAz,XMizba85pAG,vqNwzh36FVc,'','','LIBRARY-GOOGLE_TRANSLATE-1st')
		if zGmyJhleoQZ.succeeded:
			xKglJoD3q9IepZMPjO2Lw4vBNG7HuS = zGmyJhleoQZ.content
			xKglJoD3q9IepZMPjO2Lw4vBNG7HuS = xKglJoD3q9IepZMPjO2Lw4vBNG7HuS.split('\n')[-1]
			zs78bVKMxcl29OwYUTnPfBNo4kCXG = JKw5OWktPZB('str',xKglJoD3q9IepZMPjO2Lw4vBNG7HuS)[0][2]
			if zs78bVKMxcl29OwYUTnPfBNo4kCXG:
				zs78bVKMxcl29OwYUTnPfBNo4kCXG = JKw5OWktPZB('str',zs78bVKMxcl29OwYUTnPfBNo4kCXG)[1][0][0][5]
				zs78bVKMxcl29OwYUTnPfBNo4kCXG = ptMqV54oKJhQ8CH(zs78bVKMxcl29OwYUTnPfBNo4kCXG)
				for GBFbN7Xqch6uSWt in range(len(zs78bVKMxcl29OwYUTnPfBNo4kCXG)):
					NuaGd5gO60qb1Ts9 += zs78bVKMxcl29OwYUTnPfBNo4kCXG[GBFbN7Xqch6uSWt][0]
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.replace('00000','0000').replace('0000','000')
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.replace('0001','===== ===== =====')
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.replace('0002','[COLOR FFC89008]')
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.replace('0003','[COLOR FFFFFF00]')
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.replace('0004','[/COLOR]')
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.replace('0005','[RIGHT]')
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.replace('0006','[CENTER]')
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.replace('0007','[RTL]')
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.split('\n\n\n\n')
	return cZ4lExhjBNvmp3OPyWQAT6s8+NuaGd5gO60qb1Ts9
def XX3bPsWDzo(cXQ84du5sj97FvCiOoqTwJhWk16z):
	cZ4lExhjBNvmp3OPyWQAT6s8,ffzgx3EHApXLW20Uk = [],[]
	for ulk0vBZaNR in cXQ84du5sj97FvCiOoqTwJhWk16z:
		if not ulk0vBZaNR: cZ4lExhjBNvmp3OPyWQAT6s8.append('')
		else: break
	cXQ84du5sj97FvCiOoqTwJhWk16z = cXQ84du5sj97FvCiOoqTwJhWk16z[len(cZ4lExhjBNvmp3OPyWQAT6s8):]
	MMupPCxqkenwt6FlsbRILV37EAmB = '\n\n\n\n'.join(cXQ84du5sj97FvCiOoqTwJhWk16z)
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('كلا','no')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('استمرار','continue')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('أدناه','below')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('[COLOR FFC89008]','00001')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('[COLOR FFFFFF00]','00002')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('[/COLOR]','00003')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('=====','00004')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace(',','00005')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('[RTL]','00009')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('[CENTER]','0000A')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('\r','0000B')
	cXQ84du5sj97FvCiOoqTwJhWk16z = MMupPCxqkenwt6FlsbRILV37EAmB.split('\n')
	MMupPCxqkenwt6FlsbRILV37EAmB,NuaGd5gO60qb1Ts9 = '',''
	for ulk0vBZaNR in cXQ84du5sj97FvCiOoqTwJhWk16z:
		if len(MMupPCxqkenwt6FlsbRILV37EAmB+ulk0vBZaNR)<1800: MMupPCxqkenwt6FlsbRILV37EAmB += '\n'+ulk0vBZaNR
		else:
			ffzgx3EHApXLW20Uk.append(MMupPCxqkenwt6FlsbRILV37EAmB)
			MMupPCxqkenwt6FlsbRILV37EAmB = ulk0vBZaNR
	ffzgx3EHApXLW20Uk.append(MMupPCxqkenwt6FlsbRILV37EAmB)
	from json import dumps as UUwES5TPIlixcmnDKFJpyQ
	for ulk0vBZaNR in ffzgx3EHApXLW20Uk:
		vqNwzh36FVc = {'Content-Type':'application/json','User-Agent':''}
		kk1GKyapocQZDAz = 'https://api.reverso.net/translate/v1/translation'
		FXe97l2bPY6uKBySxG1 = jHevARrF7lS.getSetting('av.language.code')
		XMizba85pAG = {"format":"text","from":"ara","to":FXe97l2bPY6uKBySxG1,"input":ulk0vBZaNR,"options":{"sentenceSplitter":True,"origin":"translation.web","contextResults":False,"languageDetection":False}}
		XMizba85pAG = UUwES5TPIlixcmnDKFJpyQ(XMizba85pAG)
		zGmyJhleoQZ = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,'POST',kk1GKyapocQZDAz,XMizba85pAG,vqNwzh36FVc,'','','LIBRARY-REVERSO_TRANSLATE-1st')
		if zGmyJhleoQZ.succeeded:
			xKglJoD3q9IepZMPjO2Lw4vBNG7HuS = zGmyJhleoQZ.content
			xKglJoD3q9IepZMPjO2Lw4vBNG7HuS = JKw5OWktPZB('dict',xKglJoD3q9IepZMPjO2Lw4vBNG7HuS)
			NuaGd5gO60qb1Ts9 += '\n'+''.join(xKglJoD3q9IepZMPjO2Lw4vBNG7HuS['translation'])
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9[2:]
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.replace('000000','00000').replace('00000','0000').replace('0000','000')
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.replace('0001','[COLOR FFC89008]')
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.replace('0002','[COLOR FFFFFF00]')
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.replace('0003','[/COLOR]')
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.replace('0004','=====')
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.replace('0005',',')
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.replace('0009','[RTL]')
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.replace('000A','[CENTER]')
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.replace('000B','\r')
	NuaGd5gO60qb1Ts9 = NuaGd5gO60qb1Ts9.split('\n\n\n\n')
	return cZ4lExhjBNvmp3OPyWQAT6s8+NuaGd5gO60qb1Ts9
def xhtEqmg2WX1JocU83G(cXQ84du5sj97FvCiOoqTwJhWk16z):
	nSo10BULGrY = jHevARrF7lS.getSetting('av.language.translate')
	if not nSo10BULGrY or not cXQ84du5sj97FvCiOoqTwJhWk16z: return cXQ84du5sj97FvCiOoqTwJhWk16z
	nxshVUfjPCBbRmTGNZc = jHevARrF7lS.getSetting('av.language.provider')
	FXe97l2bPY6uKBySxG1 = jHevARrF7lS.getSetting('av.language.code')
	oEuJxAXGIRSTdmg8r3W = FXe97l2bPY6uKBySxG1+'__'+str(cXQ84du5sj97FvCiOoqTwJhWk16z)
	jHevARrF7lS.setSetting('av.language.translate','')
	NuaGd5gO60qb1Ts9 = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,'list','TRANSLATE_'+nxshVUfjPCBbRmTGNZc,oEuJxAXGIRSTdmg8r3W)
	if not NuaGd5gO60qb1Ts9:
		if nxshVUfjPCBbRmTGNZc=='GOOGLE': NuaGd5gO60qb1Ts9 = cI9oQ0ZUEdp5LGPxNhT6(cXQ84du5sj97FvCiOoqTwJhWk16z)
		elif nxshVUfjPCBbRmTGNZc=='REVERSO': NuaGd5gO60qb1Ts9 = XX3bPsWDzo(cXQ84du5sj97FvCiOoqTwJhWk16z)
		elif nxshVUfjPCBbRmTGNZc=='GLOSBE': NuaGd5gO60qb1Ts9 = l1BqHEWVt7Dk(cXQ84du5sj97FvCiOoqTwJhWk16z)
		if len(cXQ84du5sj97FvCiOoqTwJhWk16z)==len(NuaGd5gO60qb1Ts9):
			Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,'TRANSLATE_'+nxshVUfjPCBbRmTGNZc,oEuJxAXGIRSTdmg8r3W,NuaGd5gO60qb1Ts9,OrZFej19nLcNdh2WKRuDJC)
		else:
			NuaGd5gO60qb1Ts9 = cXQ84du5sj97FvCiOoqTwJhWk16z
			From8aTqdhCbPs('الترجمة فشلت','Translation Failed')
	jHevARrF7lS.setSetting('av.language.translate','1')
	return NuaGd5gO60qb1Ts9
def DsdoW9FXPpMkiLAlnrN2Tv3Gb17(O6ajtFmEdzo3WBIYin4GxqK95fp,pBhZGD7fw4br,Ax4racOvNio2fRj9wPhFyBnSeE,r03pSPJT9BF7YGAgRufvQhICckqM,GPJt6psrDEyZN4LxnTzFQcg2wvRCq):
	QTcZbyNIfxeU84vs5LBophFmqMAn6,WJr6B5imnN1Cypw,kk1GKyapocQZDAz,VRnfEFmJzUrSljM8,TF42IOaD6Gc,zdu6VAyNEi5IL1,MMupPCxqkenwt6FlsbRILV37EAmB,BZzGu5Dp6f3jbTW04Mxco8yE,Q16YwhAIPHb9Cgj4F = O6ajtFmEdzo3WBIYin4GxqK95fp
	CucTRL7BP1Doyg = []
	nSo10BULGrY = jHevARrF7lS.getSetting('av.language.translate')
	if nSo10BULGrY:
		cZ15aqrubLNiCwoR,HRvB8UOso6GjTMcNqb1r4,Fuw6MdjLPB0 = [],[],[]
		if not CucTRL7BP1Doyg:
			for d8dUpVzoanjGw in pBhZGD7fw4br:
				WJr6B5imnN1Cypw = d8dUpVzoanjGw['name'].replace(NQzGnR49rhjOA0qi7gu,'').replace(UUv3pbV4MsPa,'')
				zNLOdmGXrEnsI1DtRYqUviAlejV = GGvHJKP9LUxEk10Fw.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',WJr6B5imnN1Cypw,GGvHJKP9LUxEk10Fw.DOTALL)
				if zNLOdmGXrEnsI1DtRYqUviAlejV:
					cZ4lExhjBNvmp3OPyWQAT6s8,fOKRmLJgvA9cuE5Cq0klnGV,FFhNrg3O08ZoKJUXkj,sMFNOYx78ndEzcmH5K,WJr6B5imnN1Cypw = zNLOdmGXrEnsI1DtRYqUviAlejV[0]
					zNLOdmGXrEnsI1DtRYqUviAlejV = cZ4lExhjBNvmp3OPyWQAT6s8+fOKRmLJgvA9cuE5Cq0klnGV+' '+FFhNrg3O08ZoKJUXkj+sMFNOYx78ndEzcmH5K+' '
				else:
					zNLOdmGXrEnsI1DtRYqUviAlejV = GGvHJKP9LUxEk10Fw.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',WJr6B5imnN1Cypw,GGvHJKP9LUxEk10Fw.DOTALL)
					if zNLOdmGXrEnsI1DtRYqUviAlejV:
						WJr6B5imnN1Cypw,cZ4lExhjBNvmp3OPyWQAT6s8,FFhNrg3O08ZoKJUXkj,fOKRmLJgvA9cuE5Cq0klnGV,sMFNOYx78ndEzcmH5K = zNLOdmGXrEnsI1DtRYqUviAlejV[0]
						zNLOdmGXrEnsI1DtRYqUviAlejV = cZ4lExhjBNvmp3OPyWQAT6s8+fOKRmLJgvA9cuE5Cq0klnGV+' '+FFhNrg3O08ZoKJUXkj+sMFNOYx78ndEzcmH5K+' '
					else: zNLOdmGXrEnsI1DtRYqUviAlejV = ''
				fjFdD8aKZeWcPVGwrY7Hg5uk4tE = GGvHJKP9LUxEk10Fw.findall('^(.\[COLOR FFC89008\]\w\w\w \[/COLOR\])(.*?)$',WJr6B5imnN1Cypw,GGvHJKP9LUxEk10Fw.DOTALL)
				if fjFdD8aKZeWcPVGwrY7Hg5uk4tE: fjFdD8aKZeWcPVGwrY7Hg5uk4tE,WJr6B5imnN1Cypw = fjFdD8aKZeWcPVGwrY7Hg5uk4tE[0]
				else: fjFdD8aKZeWcPVGwrY7Hg5uk4tE = ''
				cZ15aqrubLNiCwoR.append(zNLOdmGXrEnsI1DtRYqUviAlejV+fjFdD8aKZeWcPVGwrY7Hg5uk4tE)
				HRvB8UOso6GjTMcNqb1r4.append(WJr6B5imnN1Cypw)
			Fuw6MdjLPB0 = xhtEqmg2WX1JocU83G(HRvB8UOso6GjTMcNqb1r4)
			if Fuw6MdjLPB0:
				for L4SCkrby5m8gjWwHOn0fJuhqQYvUN in range(len(pBhZGD7fw4br)):
					d8dUpVzoanjGw = pBhZGD7fw4br[L4SCkrby5m8gjWwHOn0fJuhqQYvUN]
					d8dUpVzoanjGw['name'] = cZ15aqrubLNiCwoR[L4SCkrby5m8gjWwHOn0fJuhqQYvUN]+Fuw6MdjLPB0[L4SCkrby5m8gjWwHOn0fJuhqQYvUN]
					CucTRL7BP1Doyg.append(d8dUpVzoanjGw)
	if CucTRL7BP1Doyg: pBhZGD7fw4br = CucTRL7BP1Doyg
	UsBCtZzbjf,IIu9fOGJvakoghqMm,UTwRza8EbD642XJpth = [],0,0
	iyxWw4jY8ZuocaXFsL1hd = WpgZTyqoMAPhwGiXF.path.join(YYyD6xzmsKbBTkrqEC,VRnfEFmJzUrSljM8)
	try: iqNHkO4UsyIhfCmZLz = WpgZTyqoMAPhwGiXF.listdir(iyxWw4jY8ZuocaXFsL1hd)
	except:
		try: WpgZTyqoMAPhwGiXF.makedirs(iyxWw4jY8ZuocaXFsL1hd)
		except: pass
		iqNHkO4UsyIhfCmZLz = []
	Rm9ancXdl10vQ2bEFCVW68pN = HhUZnj7TDPbiI('menu_item')
	for d8dUpVzoanjGw in pBhZGD7fw4br:
		WJr6B5imnN1Cypw = d8dUpVzoanjGw['name']
		vBhsfxXCMyjZpPHTl8r6kI7EmV = d8dUpVzoanjGw['context_menu']
		wwK9z8kr10VDeRgjtUW = d8dUpVzoanjGw['plot']
		qIuyiXKvSYkU8n0w = d8dUpVzoanjGw['stars']
		TF42IOaD6Gc = d8dUpVzoanjGw['image']
		QTcZbyNIfxeU84vs5LBophFmqMAn6 = d8dUpVzoanjGw['type']
		JP6KeQnB3AqWOh = d8dUpVzoanjGw['duration']
		llmVMupR71qcHkU4D = d8dUpVzoanjGw['isFolder']
		D0DQNiZMmVsL61 = d8dUpVzoanjGw['newpath']
		Y2Seto984wNaJiWuVd7Pk = zz2LJUB9kjnZqAeH.ListItem(WJr6B5imnN1Cypw)
		Y2Seto984wNaJiWuVd7Pk.addContextMenuItems(vBhsfxXCMyjZpPHTl8r6kI7EmV)
		if TF42IOaD6Gc: Y2Seto984wNaJiWuVd7Pk.setArt({'icon':TF42IOaD6Gc,'thumb':TF42IOaD6Gc,'fanart':TF42IOaD6Gc,'banner':TF42IOaD6Gc,'clearart':TF42IOaD6Gc,'poster':TF42IOaD6Gc,'clearlogo':TF42IOaD6Gc,'landscape':TF42IOaD6Gc})
		else:
			WJr6B5imnN1Cypw = uHqQfiPTpJIj971nbGMs03LoyzwK(WJr6B5imnN1Cypw)
			WJr6B5imnN1Cypw = ICnDbfxZ5031iOzrYGH98sy2LtQ(WJr6B5imnN1Cypw)
			Fxn2vPuhqYkOXyWQA67oBCR = WJr6B5imnN1Cypw+'.png'
			P5RNJYaomg7 = True
			if Fxn2vPuhqYkOXyWQA67oBCR in iqNHkO4UsyIhfCmZLz:
				v3jufZLwG8 = WpgZTyqoMAPhwGiXF.path.join(iyxWw4jY8ZuocaXFsL1hd,Fxn2vPuhqYkOXyWQA67oBCR)
				Y2Seto984wNaJiWuVd7Pk.setArt({'icon':v3jufZLwG8,'thumb':v3jufZLwG8,'fanart':v3jufZLwG8,'banner':v3jufZLwG8,'clearart':v3jufZLwG8,'poster':v3jufZLwG8,'clearlogo':v3jufZLwG8,'landscape':v3jufZLwG8})
				P5RNJYaomg7 = False
			elif IIu9fOGJvakoghqMm<60 and UTwRza8EbD642XJpth<5:
				v3jufZLwG8 = WpgZTyqoMAPhwGiXF.path.join(iyxWw4jY8ZuocaXFsL1hd,Fxn2vPuhqYkOXyWQA67oBCR)
				try:
					WYNtyVAoqX5BziDp = v5vbLykQB0ZngR8p(Rm9ancXdl10vQ2bEFCVW68pN,'','','','',WJr6B5imnN1Cypw,'menu_item','center',False,v3jufZLwG8)
					Y2Seto984wNaJiWuVd7Pk.setArt({'icon':v3jufZLwG8,'thumb':v3jufZLwG8,'fanart':v3jufZLwG8,'banner':v3jufZLwG8,'clearart':v3jufZLwG8,'poster':v3jufZLwG8,'clearlogo':v3jufZLwG8,'landscape':v3jufZLwG8})
					IIu9fOGJvakoghqMm += 1
					P5RNJYaomg7 = False
				except: UTwRza8EbD642XJpth += 1
			if P5RNJYaomg7: Y2Seto984wNaJiWuVd7Pk.setArt({'icon':IINvt3OAGhTLUm,'thumb':HX9MlF3SYzNv1OuGK,'fanart':a3m91diCBeJ2QYtho,'banner':A7WmPjRNeJHzEvutcGirYgFw1xD,'clearart':r6r3MYfl17dang2ZXwQ8zGCE,'poster':iiAVemYJBSNUG4C8Mhvs,'clearlogo':NMo5hwcf9esO3lVK1Z0u,'landscape':VVwpTD6yaASd4lNQf5MxLU0K8})
		if yMvF9GoTjhU5biA<20:
			if wwK9z8kr10VDeRgjtUW: Y2Seto984wNaJiWuVd7Pk.setInfo('video',{'Plot':wwK9z8kr10VDeRgjtUW,'PlotOutline':wwK9z8kr10VDeRgjtUW})
			if qIuyiXKvSYkU8n0w: Y2Seto984wNaJiWuVd7Pk.setInfo('video',{'Rating':qIuyiXKvSYkU8n0w})
			if not TF42IOaD6Gc:
				Y2Seto984wNaJiWuVd7Pk.setInfo('video',{'Title':WJr6B5imnN1Cypw})
			if QTcZbyNIfxeU84vs5LBophFmqMAn6=='video':
				Y2Seto984wNaJiWuVd7Pk.setInfo('video',{'mediatype':'movie'})
				if JP6KeQnB3AqWOh: Y2Seto984wNaJiWuVd7Pk.setInfo('video',{'duration':JP6KeQnB3AqWOh})
				Y2Seto984wNaJiWuVd7Pk.setProperty('IsPlayable','true')
		else:
			XwS6ad2hDWfTEo = Y2Seto984wNaJiWuVd7Pk.getVideoInfoTag()
			if qIuyiXKvSYkU8n0w: XwS6ad2hDWfTEo.setRating(float(qIuyiXKvSYkU8n0w))
			if not TF42IOaD6Gc:
				XwS6ad2hDWfTEo.setTitle(WJr6B5imnN1Cypw)
			if QTcZbyNIfxeU84vs5LBophFmqMAn6=='video':
				XwS6ad2hDWfTEo.setMediaType('tvshow')
				if JP6KeQnB3AqWOh: XwS6ad2hDWfTEo.setDuration(JP6KeQnB3AqWOh)
				Y2Seto984wNaJiWuVd7Pk.setProperty('IsPlayable','true')
		UsBCtZzbjf.append((D0DQNiZMmVsL61,Y2Seto984wNaJiWuVd7Pk,llmVMupR71qcHkU4D))
	XL4sA9FNebx30oE.setContent(cmBCkqS7vLYD3flwZ,'tvshows')
	rrCk7OJ9dFbnzx = XL4sA9FNebx30oE.addDirectoryItems(cmBCkqS7vLYD3flwZ,UsBCtZzbjf)
	XL4sA9FNebx30oE.endOfDirectory(cmBCkqS7vLYD3flwZ,Ax4racOvNio2fRj9wPhFyBnSeE,r03pSPJT9BF7YGAgRufvQhICckqM,GPJt6psrDEyZN4LxnTzFQcg2wvRCq)
	return rrCk7OJ9dFbnzx
def cd0aGwCPExbFU5pYNu8r(QTcZbyNIfxeU84vs5LBophFmqMAn6,WJr6B5imnN1Cypw,kk1GKyapocQZDAz,VRnfEFmJzUrSljM8,TF42IOaD6Gc='',zdu6VAyNEi5IL1='',MMupPCxqkenwt6FlsbRILV37EAmB='',BZzGu5Dp6f3jbTW04Mxco8yE='',Q16YwhAIPHb9Cgj4F={}):
	WJr6B5imnN1Cypw = WJr6B5imnN1Cypw.replace('\r','').replace('\n','').replace('\t','')
	kk1GKyapocQZDAz = kk1GKyapocQZDAz.replace('\r','').replace('\n','').replace('\t','')
	if '_SCRIPT_' in WJr6B5imnN1Cypw: ucL0B1lWMCfAoEjG,WJr6B5imnN1Cypw = WJr6B5imnN1Cypw.split('_SCRIPT_',1)
	else: ucL0B1lWMCfAoEjG,WJr6B5imnN1Cypw = '',WJr6B5imnN1Cypw
	if ucL0B1lWMCfAoEjG:
		moek6R5EuGOxD142UBdM7PXWb9V = WJr6B5imnN1Cypw
		if not moek6R5EuGOxD142UBdM7PXWb9V: moek6R5EuGOxD142UBdM7PXWb9V = '....'
		elif moek6R5EuGOxD142UBdM7PXWb9V.count('_')>1: moek6R5EuGOxD142UBdM7PXWb9V = moek6R5EuGOxD142UBdM7PXWb9V.split('_',2)[2]
		moek6R5EuGOxD142UBdM7PXWb9V = moek6R5EuGOxD142UBdM7PXWb9V.replace(' ','')
		moek6R5EuGOxD142UBdM7PXWb9V = moek6R5EuGOxD142UBdM7PXWb9V.replace('ـ','').replace('ة','ه').replace('ؤ','و')
		moek6R5EuGOxD142UBdM7PXWb9V = moek6R5EuGOxD142UBdM7PXWb9V.replace('أ','ا').replace('إ','ا').replace('آ','ا')
		moek6R5EuGOxD142UBdM7PXWb9V = moek6R5EuGOxD142UBdM7PXWb9V.replace('لأ','لا').replace('لإ','لا').replace('لآ','لا')
		moek6R5EuGOxD142UBdM7PXWb9V = moek6R5EuGOxD142UBdM7PXWb9V.replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
		moek6R5EuGOxD142UBdM7PXWb9V = moek6R5EuGOxD142UBdM7PXWb9V.replace('ِ','').replace('ٍ','').replace('ْ','').replace('ّ','')
		moek6R5EuGOxD142UBdM7PXWb9V = moek6R5EuGOxD142UBdM7PXWb9V.replace('|','').replace('~','')
		moek6R5EuGOxD142UBdM7PXWb9V = moek6R5EuGOxD142UBdM7PXWb9V.replace('اون لاين','').replace('سيما لايت','')
		fu5MqCF6JGIeDPlwiKc3 = ['العاب','خيال','البوم','الان','اطفال','حاليه','الغاز','صالح','الدين','مواليد','العالم','اعمال']
		if not any(dhwxGNvOkIFC4WYnSZz6DXRA1opue in moek6R5EuGOxD142UBdM7PXWb9V for dhwxGNvOkIFC4WYnSZz6DXRA1opue in fu5MqCF6JGIeDPlwiKc3): moek6R5EuGOxD142UBdM7PXWb9V = moek6R5EuGOxD142UBdM7PXWb9V.replace('ال','')
		moek6R5EuGOxD142UBdM7PXWb9V = moek6R5EuGOxD142UBdM7PXWb9V.replace('اخري','اخرى').replace('اجنبى','اجنبي').replace('عائليه','عائلي')
		moek6R5EuGOxD142UBdM7PXWb9V = moek6R5EuGOxD142UBdM7PXWb9V.replace('اجنبيه','اجنبي').replace('عربيه','عربي').replace('رومانسيه','رومانسي')
		moek6R5EuGOxD142UBdM7PXWb9V = moek6R5EuGOxD142UBdM7PXWb9V.replace('غربيه','غربي').replace('و مسلسلات','مسلسلات').replace('اغانى','اغاني')
		moek6R5EuGOxD142UBdM7PXWb9V = moek6R5EuGOxD142UBdM7PXWb9V.replace('تاريخي','تاريخ').replace('خيال علمي','خيال').replace('موسيقيه','موسيقى')
		moek6R5EuGOxD142UBdM7PXWb9V = moek6R5EuGOxD142UBdM7PXWb9V.replace('هندى','هندي').replace('هنديه','هندي').replace('وثائقيه','وثائقي')
		moek6R5EuGOxD142UBdM7PXWb9V = moek6R5EuGOxD142UBdM7PXWb9V.replace('تليفزيونيه','تلفزيون').replace('تلفزيونيه','تلفزيون').replace('و كرتون','وكرتون')
		moek6R5EuGOxD142UBdM7PXWb9V = moek6R5EuGOxD142UBdM7PXWb9V.replace('الحاليه','حاليه').replace('موسیقي','موسيقى').replace('الانمي','انمي')
		moek6R5EuGOxD142UBdM7PXWb9V = moek6R5EuGOxD142UBdM7PXWb9V.replace('المسلسلات','مسلسلات').replace('البرامج','برامج').replace('كارتون','كرتون')
		moek6R5EuGOxD142UBdM7PXWb9V = moek6R5EuGOxD142UBdM7PXWb9V.replace('حروب','حرب').replace('الاناشيد','اناشيد').replace('اسيويه','اسيوي')
		moek6R5EuGOxD142UBdM7PXWb9V = moek6R5EuGOxD142UBdM7PXWb9V.replace('عربى','عربي').replace('تركى','تركي').replace('تركيه','تركي')
		moek6R5EuGOxD142UBdM7PXWb9V = moek6R5EuGOxD142UBdM7PXWb9V.replace('رياضي','رياضة').replace('رياضه','رياضة').replace('اسيويه','اسيوي')
		moek6R5EuGOxD142UBdM7PXWb9V = moek6R5EuGOxD142UBdM7PXWb9V.replace('كوميدى','كوميدي').replace('كوميديه','كوميدي').replace('انيمي','انمي')
		moek6R5EuGOxD142UBdM7PXWb9V = moek6R5EuGOxD142UBdM7PXWb9V.replace('انيميشن','انميشن').replace('انمى','انميشن').replace('انمي','انميشن')
		moek6R5EuGOxD142UBdM7PXWb9V = moek6R5EuGOxD142UBdM7PXWb9V.replace('انميشنشن','انميشن').replace('الانميشن','انميشن').replace('افلام مسلسلات','افلام ومسلسلات')
		moek6R5EuGOxD142UBdM7PXWb9V = moek6R5EuGOxD142UBdM7PXWb9V.replace('  ',' ').strip(' ')
		ucL0B1lWMCfAoEjG = '_LST_'+wPGkbaD7x6(ucL0B1lWMCfAoEjG)
		if moek6R5EuGOxD142UBdM7PXWb9V not in list(InAzqY0hV5WkRsfgTmpoXQL4uCN.keys()): InAzqY0hV5WkRsfgTmpoXQL4uCN[moek6R5EuGOxD142UBdM7PXWb9V] = {}
		InAzqY0hV5WkRsfgTmpoXQL4uCN[moek6R5EuGOxD142UBdM7PXWb9V][ucL0B1lWMCfAoEjG] = [QTcZbyNIfxeU84vs5LBophFmqMAn6,WJr6B5imnN1Cypw,kk1GKyapocQZDAz,VRnfEFmJzUrSljM8,TF42IOaD6Gc,zdu6VAyNEi5IL1,MMupPCxqkenwt6FlsbRILV37EAmB,BZzGu5Dp6f3jbTW04Mxco8yE,Q16YwhAIPHb9Cgj4F]
	D6DrJsclfY.append([QTcZbyNIfxeU84vs5LBophFmqMAn6,WJr6B5imnN1Cypw,kk1GKyapocQZDAz,VRnfEFmJzUrSljM8,TF42IOaD6Gc,zdu6VAyNEi5IL1,MMupPCxqkenwt6FlsbRILV37EAmB,BZzGu5Dp6f3jbTW04Mxco8yE,Q16YwhAIPHb9Cgj4F])
	return
def DwNC3gEonizsB6a0v1F(De9sc7jx0YmbpHEX):
	if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: from html import unescape as _HvCwAYRXjx7
	else:
		from HTMLParser import HTMLParser as QHvaC0OMbrdWmY4jiofeFKlZ9JG
		_HvCwAYRXjx7 = QHvaC0OMbrdWmY4jiofeFKlZ9JG().unescape
	if '&' in De9sc7jx0YmbpHEX and ';' in De9sc7jx0YmbpHEX:
		if HHosl5fRdhtEDAYyP: De9sc7jx0YmbpHEX = De9sc7jx0YmbpHEX.decode('utf8')
		De9sc7jx0YmbpHEX = _HvCwAYRXjx7(De9sc7jx0YmbpHEX)
		if HHosl5fRdhtEDAYyP: De9sc7jx0YmbpHEX = De9sc7jx0YmbpHEX.encode('utf8')
	return De9sc7jx0YmbpHEX
def ptMqV54oKJhQ8CH(De9sc7jx0YmbpHEX):
	if '\\u' in De9sc7jx0YmbpHEX:
		if HHosl5fRdhtEDAYyP: De9sc7jx0YmbpHEX = De9sc7jx0YmbpHEX.decode('unicode_escape','ignore').encode('utf8')
		elif u4ChFMGf6K93tbDjJ12zi0YQsAHyP: De9sc7jx0YmbpHEX = De9sc7jx0YmbpHEX.encode('utf8').decode('unicode_escape','ignore')
	return De9sc7jx0YmbpHEX
def EFo7dN1XkCJSI6sPzZO8cTRm9Aj3U5(aBprCULEvDtX2fl0nJSokmqHO,ysk7F3m6AajJ58RSPNI,e2HWO47IavQxZC50,zfeoG4vPkOqpT,MMupPCxqkenwt6FlsbRILV37EAmB,vmrJNuUwOhLHjsY,NUIguYy1GA9OQeplDHx6JE,TOQXLqKoYmsu,y8BHVFaLm9x4pvb):
	V5AjqDbpYzrExf = HhUZnj7TDPbiI(vmrJNuUwOhLHjsY)
	WYNtyVAoqX5BziDp = v5vbLykQB0ZngR8p(V5AjqDbpYzrExf,aBprCULEvDtX2fl0nJSokmqHO,ysk7F3m6AajJ58RSPNI,e2HWO47IavQxZC50,zfeoG4vPkOqpT,MMupPCxqkenwt6FlsbRILV37EAmB,vmrJNuUwOhLHjsY,NUIguYy1GA9OQeplDHx6JE,TOQXLqKoYmsu,y8BHVFaLm9x4pvb)
	return WYNtyVAoqX5BziDp
def HhUZnj7TDPbiI(vmrJNuUwOhLHjsY):
	sDwEaCi2OGqTt = 5
	Rcv1xG5rtjiQYI3pNubzs0 = 20
	BbjVzNInhpW134egQUfvMLCqZd2i = 20
	ijKuWcm6gGVsZBPUdbJSTN = 0
	SN0GTvlO3f = 'center'
	o1gvis6DT7V = 0
	LlUAfsnDoHRGwCOdhFV9MJEuSymKBv = 19
	PPF1LBbu5JzDaHyiw = 30
	pB4Qwkg7h2Yfz8O = 8
	dM2Ezy6ORA5CXKIi947qhSxYwGjJD0 = True
	s9NE85jrlAcRnyimVaDG = 375
	h32TsN1p6rcBQ0SJFyD = 410
	Dv592Y6jFNZPiyW30R71dbqeThLz = 50
	Oq6t1KiWkxBVn34y8c7gU9TsFDSJQ0 = 280
	Qcwp0HINrqJkLsEG13eB = 28
	XI4gSJuiBcMHAonLat2Yrs = 5
	ktZaMfnAOPR7JmE = 0
	ZtYQir10gvWkjAXTU = 31
	MQOpPbmi4r2qHoWehTAN3v = [36,32,28]
	if vmrJNuUwOhLHjsY in ['notification','notification_twohalfs']:
		if vmrJNuUwOhLHjsY=='notification_twohalfs':
			cIk2iQrz491fVUh7dJO85plB0FnPwT,STReruH4xZU80 = 'UPPER',720
			SN0GTvlO3f = 'right'
			dM2Ezy6ORA5CXKIi947qhSxYwGjJD0 = True
			ijKuWcm6gGVsZBPUdbJSTN = 10
		else:
			cIk2iQrz491fVUh7dJO85plB0FnPwT,STReruH4xZU80 = 97+20,720
			SN0GTvlO3f = 'left'
			dM2Ezy6ORA5CXKIi947qhSxYwGjJD0 = False
		MQOpPbmi4r2qHoWehTAN3v = [33,33,33]
		BbjVzNInhpW134egQUfvMLCqZd2i = 20
		Rcv1xG5rtjiQYI3pNubzs0 = 0
		PPF1LBbu5JzDaHyiw = 20
		LlUAfsnDoHRGwCOdhFV9MJEuSymKBv = 25+10
	elif vmrJNuUwOhLHjsY=='menu_item':
		MQOpPbmi4r2qHoWehTAN3v,cIk2iQrz491fVUh7dJO85plB0FnPwT,STReruH4xZU80 = [48,44,40],200,400
		PPF1LBbu5JzDaHyiw,LlUAfsnDoHRGwCOdhFV9MJEuSymKBv,Rcv1xG5rtjiQYI3pNubzs0 = 0,0,-16
		w2QWpY4mXVKA1ty6rHRGfiCsZc = F8gpvxURGVTJ0eH.open(L2M7I0quXgicoQF1k)
		XE16ulObzNjpRIrtUYC = F8gpvxURGVTJ0eH.new('RGBA',(200,200),(255,0,0,255))
	elif vmrJNuUwOhLHjsY=='confirm_smallfont': MQOpPbmi4r2qHoWehTAN3v,cIk2iQrz491fVUh7dJO85plB0FnPwT,STReruH4xZU80 = [28,24,20],500,900
	elif vmrJNuUwOhLHjsY=='confirm_mediumfont': MQOpPbmi4r2qHoWehTAN3v,cIk2iQrz491fVUh7dJO85plB0FnPwT,STReruH4xZU80 = [32,28,24],500,900
	elif vmrJNuUwOhLHjsY=='confirm_bigfont': MQOpPbmi4r2qHoWehTAN3v,cIk2iQrz491fVUh7dJO85plB0FnPwT,STReruH4xZU80 = [36,32,28],500,900
	elif vmrJNuUwOhLHjsY=='textview_bigfont': cIk2iQrz491fVUh7dJO85plB0FnPwT,STReruH4xZU80 = 740,1270
	elif vmrJNuUwOhLHjsY=='textview_bigfont_long': cIk2iQrz491fVUh7dJO85plB0FnPwT,STReruH4xZU80 = 'UPPER',1270
	elif vmrJNuUwOhLHjsY=='textview_smallfont': MQOpPbmi4r2qHoWehTAN3v,cIk2iQrz491fVUh7dJO85plB0FnPwT,STReruH4xZU80 = [28,23,18],740,1270
	elif vmrJNuUwOhLHjsY=='textview_smallfont_long': MQOpPbmi4r2qHoWehTAN3v,cIk2iQrz491fVUh7dJO85plB0FnPwT,STReruH4xZU80 = [28,23,18],'UPPER',1270
	ewl7AoZ3gT = MQOpPbmi4r2qHoWehTAN3v[0]
	l2lbfrZeIGWw4T = MQOpPbmi4r2qHoWehTAN3v[1]
	I6IThzf5g8vr9wYsUHLclEAKDy = MQOpPbmi4r2qHoWehTAN3v[2]
	s7xIbLRKq8owfZtP = cgEXLHaeZI1Ky90fWdNo.truetype(LxI6HlyziFS,size=ewl7AoZ3gT)
	zqlact80s2Sw = cgEXLHaeZI1Ky90fWdNo.truetype(LxI6HlyziFS,size=l2lbfrZeIGWw4T)
	z6J843A0UOhQ19tuqmiD = cgEXLHaeZI1Ky90fWdNo.truetype(LxI6HlyziFS,size=I6IThzf5g8vr9wYsUHLclEAKDy)
	CgjmwMcHeFyZXTRIN5lb = F8gpvxURGVTJ0eH.new('RGBA',(100,100),(255,255,255,0))
	OMhBi91ZNJ6s7dIQxjw = iWY9OsI5lM6tuDA2RfhmqkPdBQv.Draw(CgjmwMcHeFyZXTRIN5lb)
	dQL4cJTYZA3U0oFm,LLOIi62vekaj7scBDQdz = OMhBi91ZNJ6s7dIQxjw.textsize('HHH BBB 888 000',font=zqlact80s2Sw)
	G5ijE8KFkA2mqB,ON8WMUjfQYrHlunAypEcCviVePaI61 = OMhBi91ZNJ6s7dIQxjw.textsize('HHH BBB 888 000',font=s7xIbLRKq8owfZtP)
	zeEkdUVWQ0jtSfw43FpP8XHGZy = {'delete_harakat':False,'support_ligatures':True,'ARABIC LIGATURE ALLAH':False}
	mYLdgBUwjN1R9oOPIbGSin = K8Q9rSind42b(configuration=zeEkdUVWQ0jtSfw43FpP8XHGZy)
	V5AjqDbpYzrExf = {}
	m2PzU3Crs5AtJGDgpu = locals()
	for f3kLWlmQJcbvRG0tYqj4uigThV6s in m2PzU3Crs5AtJGDgpu: V5AjqDbpYzrExf[f3kLWlmQJcbvRG0tYqj4uigThV6s] = m2PzU3Crs5AtJGDgpu[f3kLWlmQJcbvRG0tYqj4uigThV6s]
	return V5AjqDbpYzrExf
def v5vbLykQB0ZngR8p(V5AjqDbpYzrExf,aBprCULEvDtX2fl0nJSokmqHO,ysk7F3m6AajJ58RSPNI,e2HWO47IavQxZC50,zfeoG4vPkOqpT,MMupPCxqkenwt6FlsbRILV37EAmB,vmrJNuUwOhLHjsY,NUIguYy1GA9OQeplDHx6JE,TOQXLqKoYmsu,y8BHVFaLm9x4pvb):
	for f3kLWlmQJcbvRG0tYqj4uigThV6s in V5AjqDbpYzrExf: globals()[f3kLWlmQJcbvRG0tYqj4uigThV6s] = V5AjqDbpYzrExf[f3kLWlmQJcbvRG0tYqj4uigThV6s]
	global Qcwp0HINrqJkLsEG13eB,XI4gSJuiBcMHAonLat2Yrs
	nSo10BULGrY = jHevARrF7lS.getSetting('av.language.translate')
	if nSo10BULGrY:
		if aBprCULEvDtX2fl0nJSokmqHO=='نعم  Yes': aBprCULEvDtX2fl0nJSokmqHO = 'Yes'
		elif aBprCULEvDtX2fl0nJSokmqHO=='كلا  No': aBprCULEvDtX2fl0nJSokmqHO = 'No'
		if ysk7F3m6AajJ58RSPNI=='نعم  Yes': ysk7F3m6AajJ58RSPNI = 'Yes'
		elif ysk7F3m6AajJ58RSPNI=='كلا  No': ysk7F3m6AajJ58RSPNI = 'No'
		if e2HWO47IavQxZC50=='نعم  Yes': e2HWO47IavQxZC50 = 'Yes'
		elif e2HWO47IavQxZC50=='كلا  No': e2HWO47IavQxZC50 = 'No'
		p8lwCLKmTWr = xhtEqmg2WX1JocU83G([aBprCULEvDtX2fl0nJSokmqHO,ysk7F3m6AajJ58RSPNI,e2HWO47IavQxZC50,zfeoG4vPkOqpT,MMupPCxqkenwt6FlsbRILV37EAmB])
		if p8lwCLKmTWr: aBprCULEvDtX2fl0nJSokmqHO,ysk7F3m6AajJ58RSPNI,e2HWO47IavQxZC50,zfeoG4vPkOqpT,MMupPCxqkenwt6FlsbRILV37EAmB = p8lwCLKmTWr
	if HHosl5fRdhtEDAYyP:
		MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.decode('utf8')
		zfeoG4vPkOqpT = zfeoG4vPkOqpT.decode('utf8')
		aBprCULEvDtX2fl0nJSokmqHO = aBprCULEvDtX2fl0nJSokmqHO.decode('utf8')
		ysk7F3m6AajJ58RSPNI = ysk7F3m6AajJ58RSPNI.decode('utf8')
		e2HWO47IavQxZC50 = e2HWO47IavQxZC50.decode('utf8')
	u7qOM2YPUpCh = zfeoG4vPkOqpT.count('\n')+1
	Kg7cwpSti8rL93eFQxkh1Umu = Rcv1xG5rtjiQYI3pNubzs0+u7qOM2YPUpCh*(ON8WMUjfQYrHlunAypEcCviVePaI61+ijKuWcm6gGVsZBPUdbJSTN)-ijKuWcm6gGVsZBPUdbJSTN
	if MMupPCxqkenwt6FlsbRILV37EAmB:
		xp3ZShNqB5EvMkzt9GmFd = STReruH4xZU80-PPF1LBbu5JzDaHyiw*2
		k2k7HifvExVnQB = LLOIi62vekaj7scBDQdz+pB4Qwkg7h2Yfz8O
		Exj1p853Y2cFkfAPJCW9riMbOlvh = mYLdgBUwjN1R9oOPIbGSin.reshape(MMupPCxqkenwt6FlsbRILV37EAmB)
		if dM2Ezy6ORA5CXKIi947qhSxYwGjJD0:
			nniDjaGrUd = bbkX6EVcqN(Exj1p853Y2cFkfAPJCW9riMbOlvh,l2lbfrZeIGWw4T,xp3ZShNqB5EvMkzt9GmFd,k2k7HifvExVnQB)
			cT8E3DFO1N = QUJZGiYFWnhp6DR(nniDjaGrUd)
			cHp29ArWn085fTOX = cT8E3DFO1N.count('\n')+1
			if cHp29ArWn085fTOX<6:
				pnGsMu6krt8vCeJoqjh0 = xp3ZShNqB5EvMkzt9GmFd
				nniDjaGrUd = bbkX6EVcqN(Exj1p853Y2cFkfAPJCW9riMbOlvh,l2lbfrZeIGWw4T,pnGsMu6krt8vCeJoqjh0,k2k7HifvExVnQB)
				cT8E3DFO1N = QUJZGiYFWnhp6DR(nniDjaGrUd)
				cHp29ArWn085fTOX = cT8E3DFO1N.count('\n')+1
			u8dbzLAc7nBrWNMq6KagVIkDs = LlUAfsnDoHRGwCOdhFV9MJEuSymKBv+cHp29ArWn085fTOX*k2k7HifvExVnQB-pB4Qwkg7h2Yfz8O
		else:
			u8dbzLAc7nBrWNMq6KagVIkDs = LlUAfsnDoHRGwCOdhFV9MJEuSymKBv+LLOIi62vekaj7scBDQdz
			cT8E3DFO1N = Exj1p853Y2cFkfAPJCW9riMbOlvh.split('\n')[0]
			nniDjaGrUd = Exj1p853Y2cFkfAPJCW9riMbOlvh.split('\n')[0]
	else: u8dbzLAc7nBrWNMq6KagVIkDs = LlUAfsnDoHRGwCOdhFV9MJEuSymKBv
	PTFL7JsuwD8qlxMgCN9 = ktZaMfnAOPR7JmE+ZtYQir10gvWkjAXTU
	if TOQXLqKoYmsu:
		mzXQyhIavGk = h32TsN1p6rcBQ0SJFyD-s9NE85jrlAcRnyimVaDG
		PTFL7JsuwD8qlxMgCN9 += mzXQyhIavGk
	else: mzXQyhIavGk = 0
	if aBprCULEvDtX2fl0nJSokmqHO or ysk7F3m6AajJ58RSPNI or e2HWO47IavQxZC50: PTFL7JsuwD8qlxMgCN9 += Dv592Y6jFNZPiyW30R71dbqeThLz
	if cIk2iQrz491fVUh7dJO85plB0FnPwT!='UPPER': WYNtyVAoqX5BziDp = cIk2iQrz491fVUh7dJO85plB0FnPwT
	else: WYNtyVAoqX5BziDp = Kg7cwpSti8rL93eFQxkh1Umu+u8dbzLAc7nBrWNMq6KagVIkDs+PTFL7JsuwD8qlxMgCN9
	R0hGlQcSD1rHTe4f6FAqMwXjvtzOk = WYNtyVAoqX5BziDp-Kg7cwpSti8rL93eFQxkh1Umu-PTFL7JsuwD8qlxMgCN9-LlUAfsnDoHRGwCOdhFV9MJEuSymKBv
	CgjmwMcHeFyZXTRIN5lb = F8gpvxURGVTJ0eH.new('RGBA',(STReruH4xZU80,WYNtyVAoqX5BziDp),(255,255,255,0))
	OMhBi91ZNJ6s7dIQxjw = iWY9OsI5lM6tuDA2RfhmqkPdBQv.Draw(CgjmwMcHeFyZXTRIN5lb)
	if not ysk7F3m6AajJ58RSPNI and aBprCULEvDtX2fl0nJSokmqHO and e2HWO47IavQxZC50:
		Qcwp0HINrqJkLsEG13eB += 105
		XI4gSJuiBcMHAonLat2Yrs -= 110
	if zfeoG4vPkOqpT:
		TLVUcWnv27JtRZ9MXENCjhGdom08 = Rcv1xG5rtjiQYI3pNubzs0
		zfeoG4vPkOqpT = Y5rNeFs8E7UJqRAQ9kP6.get_display(mYLdgBUwjN1R9oOPIbGSin.reshape(zfeoG4vPkOqpT))
		cXQ84du5sj97FvCiOoqTwJhWk16z = zfeoG4vPkOqpT.splitlines()
		for ulk0vBZaNR in cXQ84du5sj97FvCiOoqTwJhWk16z:
			if ulk0vBZaNR:
				ii9svd5H7UhO0CBec8X4LWNwb,nb43EgtvSA5oM2CR = OMhBi91ZNJ6s7dIQxjw.textsize(ulk0vBZaNR,font=s7xIbLRKq8owfZtP)
				if SN0GTvlO3f=='center': cQ1R3Vp4LhYKkWxweG = sDwEaCi2OGqTt+(STReruH4xZU80-ii9svd5H7UhO0CBec8X4LWNwb)/2
				elif SN0GTvlO3f=='right': cQ1R3Vp4LhYKkWxweG = sDwEaCi2OGqTt+STReruH4xZU80-ii9svd5H7UhO0CBec8X4LWNwb-BbjVzNInhpW134egQUfvMLCqZd2i
				elif SN0GTvlO3f=='left': cQ1R3Vp4LhYKkWxweG = sDwEaCi2OGqTt+BbjVzNInhpW134egQUfvMLCqZd2i
				OMhBi91ZNJ6s7dIQxjw.text((cQ1R3Vp4LhYKkWxweG,TLVUcWnv27JtRZ9MXENCjhGdom08),ulk0vBZaNR,font=s7xIbLRKq8owfZtP,fill='yellow')
			TLVUcWnv27JtRZ9MXENCjhGdom08 += ewl7AoZ3gT+ijKuWcm6gGVsZBPUdbJSTN
	if aBprCULEvDtX2fl0nJSokmqHO or ysk7F3m6AajJ58RSPNI or e2HWO47IavQxZC50:
		QjLs0FrqbKC4Env = Kg7cwpSti8rL93eFQxkh1Umu+R0hGlQcSD1rHTe4f6FAqMwXjvtzOk+LlUAfsnDoHRGwCOdhFV9MJEuSymKBv+mzXQyhIavGk+ktZaMfnAOPR7JmE
		if aBprCULEvDtX2fl0nJSokmqHO:
			aBprCULEvDtX2fl0nJSokmqHO = Y5rNeFs8E7UJqRAQ9kP6.get_display(mYLdgBUwjN1R9oOPIbGSin.reshape(aBprCULEvDtX2fl0nJSokmqHO))
			HmuSb2AcgFvsk896Ylxt,hCok4L0KJGn62Dilc = OMhBi91ZNJ6s7dIQxjw.textsize(aBprCULEvDtX2fl0nJSokmqHO,font=z6J843A0UOhQ19tuqmiD)
			DYyBsUp8HCJPOAuhEzQ2g67tR = Qcwp0HINrqJkLsEG13eB+0*(XI4gSJuiBcMHAonLat2Yrs+Oq6t1KiWkxBVn34y8c7gU9TsFDSJQ0)+(Oq6t1KiWkxBVn34y8c7gU9TsFDSJQ0-HmuSb2AcgFvsk896Ylxt)/2
			OMhBi91ZNJ6s7dIQxjw.text((DYyBsUp8HCJPOAuhEzQ2g67tR,QjLs0FrqbKC4Env),aBprCULEvDtX2fl0nJSokmqHO,font=z6J843A0UOhQ19tuqmiD,fill='yellow')
		if ysk7F3m6AajJ58RSPNI:
			ysk7F3m6AajJ58RSPNI = Y5rNeFs8E7UJqRAQ9kP6.get_display(mYLdgBUwjN1R9oOPIbGSin.reshape(ysk7F3m6AajJ58RSPNI))
			EayoHl56RhB3N2uzML,Nbm3ARZHUgLBpfxWY4IlvMFeu1 = OMhBi91ZNJ6s7dIQxjw.textsize(ysk7F3m6AajJ58RSPNI,font=z6J843A0UOhQ19tuqmiD)
			VuwxkWGSDFyrmo = Qcwp0HINrqJkLsEG13eB+1*(XI4gSJuiBcMHAonLat2Yrs+Oq6t1KiWkxBVn34y8c7gU9TsFDSJQ0)+(Oq6t1KiWkxBVn34y8c7gU9TsFDSJQ0-EayoHl56RhB3N2uzML)/2
			OMhBi91ZNJ6s7dIQxjw.text((VuwxkWGSDFyrmo,QjLs0FrqbKC4Env),ysk7F3m6AajJ58RSPNI,font=z6J843A0UOhQ19tuqmiD,fill='yellow')
		if e2HWO47IavQxZC50:
			e2HWO47IavQxZC50 = Y5rNeFs8E7UJqRAQ9kP6.get_display(mYLdgBUwjN1R9oOPIbGSin.reshape(e2HWO47IavQxZC50))
			uXk8J7AYHUc4lSFdPibvMw,AYaRHMBOWNVe9khUZtD4owE = OMhBi91ZNJ6s7dIQxjw.textsize(e2HWO47IavQxZC50,font=z6J843A0UOhQ19tuqmiD)
			iPrJu3pOR0BwfHtE4yLG = Qcwp0HINrqJkLsEG13eB+2*(XI4gSJuiBcMHAonLat2Yrs+Oq6t1KiWkxBVn34y8c7gU9TsFDSJQ0)+(Oq6t1KiWkxBVn34y8c7gU9TsFDSJQ0-uXk8J7AYHUc4lSFdPibvMw)/2
			OMhBi91ZNJ6s7dIQxjw.text((iPrJu3pOR0BwfHtE4yLG,QjLs0FrqbKC4Env),e2HWO47IavQxZC50,font=z6J843A0UOhQ19tuqmiD,fill='yellow')
	if MMupPCxqkenwt6FlsbRILV37EAmB:
		yg9IYm2LTBURar,scTfn8wjy0FDEhNrapIWgJKX7CUiRL = [],[]
		nniDjaGrUd = uvBWAOzt67(nniDjaGrUd)
		TpZMNnomuf2RFdVDU5ESH = nniDjaGrUd.split('_sss__newline_')
		for jA9gFwtqWdk0e45UMcRD8 in TpZMNnomuf2RFdVDU5ESH:
			DatJiISuhUdE875 = NUIguYy1GA9OQeplDHx6JE
			if   '_sss__lineleft_' in jA9gFwtqWdk0e45UMcRD8: DatJiISuhUdE875 = 'left'
			elif '_sss__lineright_' in jA9gFwtqWdk0e45UMcRD8: DatJiISuhUdE875 = 'right'
			elif '_sss__linecenter_' in jA9gFwtqWdk0e45UMcRD8: DatJiISuhUdE875 = 'center'
			ickpxmHE3uTvN4PY967QZXJrU = jA9gFwtqWdk0e45UMcRD8
			Bqwv4PKQL7Tiy8lc = GGvHJKP9LUxEk10Fw.findall('_sss__.*?_',jA9gFwtqWdk0e45UMcRD8,GGvHJKP9LUxEk10Fw.DOTALL)
			for TeMLgVimqnEraDP2tfSK6cz9YIb57 in Bqwv4PKQL7Tiy8lc: ickpxmHE3uTvN4PY967QZXJrU = ickpxmHE3uTvN4PY967QZXJrU.replace(TeMLgVimqnEraDP2tfSK6cz9YIb57,'')
			if ickpxmHE3uTvN4PY967QZXJrU=='': ii9svd5H7UhO0CBec8X4LWNwb,nb43EgtvSA5oM2CR = 0,k2k7HifvExVnQB
			else: ii9svd5H7UhO0CBec8X4LWNwb,nb43EgtvSA5oM2CR = OMhBi91ZNJ6s7dIQxjw.textsize(ickpxmHE3uTvN4PY967QZXJrU,font=zqlact80s2Sw)
			if   DatJiISuhUdE875=='left': q3q6GME9cmF2ACRk1JoKtUnj5vrgNl = o1gvis6DT7V+PPF1LBbu5JzDaHyiw
			elif DatJiISuhUdE875=='right': q3q6GME9cmF2ACRk1JoKtUnj5vrgNl = o1gvis6DT7V+PPF1LBbu5JzDaHyiw+xp3ZShNqB5EvMkzt9GmFd-ii9svd5H7UhO0CBec8X4LWNwb
			elif DatJiISuhUdE875=='center': q3q6GME9cmF2ACRk1JoKtUnj5vrgNl = o1gvis6DT7V+PPF1LBbu5JzDaHyiw+(xp3ZShNqB5EvMkzt9GmFd-ii9svd5H7UhO0CBec8X4LWNwb)/2
			if q3q6GME9cmF2ACRk1JoKtUnj5vrgNl<PPF1LBbu5JzDaHyiw: q3q6GME9cmF2ACRk1JoKtUnj5vrgNl = o1gvis6DT7V+PPF1LBbu5JzDaHyiw
			yg9IYm2LTBURar.append(q3q6GME9cmF2ACRk1JoKtUnj5vrgNl)
			scTfn8wjy0FDEhNrapIWgJKX7CUiRL.append(ii9svd5H7UhO0CBec8X4LWNwb)
		q3q6GME9cmF2ACRk1JoKtUnj5vrgNl = yg9IYm2LTBURar[0]
		xYIvJhpn6ubTCPzAyfBq4 = nniDjaGrUd.split('_sss_')
		UobTidOgMywmjkBvxzED6C7qu0a1 = (255,255,255,255)
		PwAOD2fkvYzhCdyEVG5Q0ZpL = UobTidOgMywmjkBvxzED6C7qu0a1
		YPTEDevhW0G9kNqFmJlba2,jjIuYvFpzL = 0,0
		tt2q6PTdcszRaHSDEkuAoFjWUhl10 = False
		dpWJENICOb0 = 0
		IIqLV4W0Ao37hvNZ = Kg7cwpSti8rL93eFQxkh1Umu+LlUAfsnDoHRGwCOdhFV9MJEuSymKBv/2
		if u8dbzLAc7nBrWNMq6KagVIkDs<(R0hGlQcSD1rHTe4f6FAqMwXjvtzOk+LlUAfsnDoHRGwCOdhFV9MJEuSymKBv):
			spR8SHBAat0elQjXo7615v = (R0hGlQcSD1rHTe4f6FAqMwXjvtzOk+LlUAfsnDoHRGwCOdhFV9MJEuSymKBv-u8dbzLAc7nBrWNMq6KagVIkDs)/2
			IIqLV4W0Ao37hvNZ = Kg7cwpSti8rL93eFQxkh1Umu+LlUAfsnDoHRGwCOdhFV9MJEuSymKBv+spR8SHBAat0elQjXo7615v-LLOIi62vekaj7scBDQdz/2
		for ulk0vBZaNR in xYIvJhpn6ubTCPzAyfBq4:
			if not ulk0vBZaNR or (ulk0vBZaNR and ord(ulk0vBZaNR[0])==65279): continue
			tWvy4Vh15bJSYkKmDr8Gd7LCqlzpR = ulk0vBZaNR.split('_newline_',1)
			ffRGNE5qpmhKcrWzU = ulk0vBZaNR.split('_newcolor',1)
			mmIzeMJjPHwLYyOB4q1dTA = ulk0vBZaNR.split('_endcolor_',1)
			MrGiahIUlsm23 = ulk0vBZaNR.split('_linertl_',1)
			OOqRcTlhBvDL = ulk0vBZaNR.split('_lineleft_',1)
			QCmXxSDdLHYR8wtTobzlJq6rMp4EF = ulk0vBZaNR.split('_lineright_',1)
			uBGZRK3aqFJbwATHQpWjgv1 = ulk0vBZaNR.split('_linecenter_',1)
			if len(tWvy4Vh15bJSYkKmDr8Gd7LCqlzpR)>1:
				dpWJENICOb0 += 1
				ulk0vBZaNR = tWvy4Vh15bJSYkKmDr8Gd7LCqlzpR[1]
				YPTEDevhW0G9kNqFmJlba2 = 0
				q3q6GME9cmF2ACRk1JoKtUnj5vrgNl = yg9IYm2LTBURar[dpWJENICOb0]
				jjIuYvFpzL += k2k7HifvExVnQB
				tt2q6PTdcszRaHSDEkuAoFjWUhl10 = False
			elif len(ffRGNE5qpmhKcrWzU)>1:
				ulk0vBZaNR = ffRGNE5qpmhKcrWzU[1]
				PwAOD2fkvYzhCdyEVG5Q0ZpL = ulk0vBZaNR[0:8]
				PwAOD2fkvYzhCdyEVG5Q0ZpL = '#'+PwAOD2fkvYzhCdyEVG5Q0ZpL[2:]
				ulk0vBZaNR = ulk0vBZaNR[9:]
			elif len(mmIzeMJjPHwLYyOB4q1dTA)>1:
				ulk0vBZaNR = mmIzeMJjPHwLYyOB4q1dTA[1]
				PwAOD2fkvYzhCdyEVG5Q0ZpL = UobTidOgMywmjkBvxzED6C7qu0a1
			elif len(MrGiahIUlsm23)>1:
				ulk0vBZaNR = MrGiahIUlsm23[1]
				tt2q6PTdcszRaHSDEkuAoFjWUhl10 = True
				YPTEDevhW0G9kNqFmJlba2 = scTfn8wjy0FDEhNrapIWgJKX7CUiRL[dpWJENICOb0]
			elif len(OOqRcTlhBvDL)>1: ulk0vBZaNR = OOqRcTlhBvDL[1]
			elif len(QCmXxSDdLHYR8wtTobzlJq6rMp4EF)>1: ulk0vBZaNR = QCmXxSDdLHYR8wtTobzlJq6rMp4EF[1]
			elif len(uBGZRK3aqFJbwATHQpWjgv1)>1: ulk0vBZaNR = uBGZRK3aqFJbwATHQpWjgv1[1]
			if ulk0vBZaNR:
				RJqj89WNgpPx4fH = IIqLV4W0Ao37hvNZ+jjIuYvFpzL
				ulk0vBZaNR = Y5rNeFs8E7UJqRAQ9kP6.get_display(ulk0vBZaNR)
				ii9svd5H7UhO0CBec8X4LWNwb,nb43EgtvSA5oM2CR = OMhBi91ZNJ6s7dIQxjw.textsize(ulk0vBZaNR,font=zqlact80s2Sw)
				if tt2q6PTdcszRaHSDEkuAoFjWUhl10: YPTEDevhW0G9kNqFmJlba2 -= ii9svd5H7UhO0CBec8X4LWNwb
				kqC3TZfh2IQGSyv8b = q3q6GME9cmF2ACRk1JoKtUnj5vrgNl+YPTEDevhW0G9kNqFmJlba2
				OMhBi91ZNJ6s7dIQxjw.text((kqC3TZfh2IQGSyv8b,RJqj89WNgpPx4fH),ulk0vBZaNR,font=zqlact80s2Sw,fill=PwAOD2fkvYzhCdyEVG5Q0ZpL)
				if vmrJNuUwOhLHjsY=='menu_item':
					OMhBi91ZNJ6s7dIQxjw.text((kqC3TZfh2IQGSyv8b+1,RJqj89WNgpPx4fH+1),ulk0vBZaNR,font=zqlact80s2Sw,fill=PwAOD2fkvYzhCdyEVG5Q0ZpL)
				if not tt2q6PTdcszRaHSDEkuAoFjWUhl10: YPTEDevhW0G9kNqFmJlba2 += ii9svd5H7UhO0CBec8X4LWNwb
				if RJqj89WNgpPx4fH>R0hGlQcSD1rHTe4f6FAqMwXjvtzOk+k2k7HifvExVnQB: break
	if vmrJNuUwOhLHjsY=='menu_item':
		CgjmwMcHeFyZXTRIN5lb = CgjmwMcHeFyZXTRIN5lb.resize((200,200))
		gipFLS8T31j4t5HKMVuQswdrN = w2QWpY4mXVKA1ty6rHRGfiCsZc.copy()
		gipFLS8T31j4t5HKMVuQswdrN.paste(XE16ulObzNjpRIrtUYC,(0,0),mask=CgjmwMcHeFyZXTRIN5lb)
	else: gipFLS8T31j4t5HKMVuQswdrN = CgjmwMcHeFyZXTRIN5lb
	if HHosl5fRdhtEDAYyP: y8BHVFaLm9x4pvb = y8BHVFaLm9x4pvb.decode('utf8')
	try: gipFLS8T31j4t5HKMVuQswdrN.save(y8BHVFaLm9x4pvb)
	except:
		AGc25udS3CtLlh = WpgZTyqoMAPhwGiXF.path.dirname(y8BHVFaLm9x4pvb)
		try: WpgZTyqoMAPhwGiXF.makedirs(AGc25udS3CtLlh)
		except: pass
		gipFLS8T31j4t5HKMVuQswdrN.save(y8BHVFaLm9x4pvb)
	return WYNtyVAoqX5BziDp
def bbkX6EVcqN(hhy1MbBqK3x,rBdgovlO8utE2nq5Jpb,d4hUcPVD2EJH0qyM,NCodLPpMklzgm3):
	ii1aElnYkyceRpXfb2FAv,upwMdTGcnrD7Xe9lJRhBb3zyNEPK,Y3ySGvmjDq028nATbKose9H7ItJ = '',0,15000
	hhy1MbBqK3x = hhy1MbBqK3x.replace('[COLOR ','[COLOR:::')
	WaQkLiUSArdmwZG42N = cgEXLHaeZI1Ky90fWdNo.truetype(LxI6HlyziFS,size=rBdgovlO8utE2nq5Jpb)
	d4hUcPVD2EJH0qyM -= rBdgovlO8utE2nq5Jpb*2
	CgjmwMcHeFyZXTRIN5lb = F8gpvxURGVTJ0eH.new('RGBA',(d4hUcPVD2EJH0qyM,99),(255,255,255,0))
	OMhBi91ZNJ6s7dIQxjw = iWY9OsI5lM6tuDA2RfhmqkPdBQv.Draw(CgjmwMcHeFyZXTRIN5lb)
	for bJLZyM4f3DdGVolOm in hhy1MbBqK3x.splitlines():
		upwMdTGcnrD7Xe9lJRhBb3zyNEPK += NCodLPpMklzgm3
		i9izlOmHDqrYjXv0pcwJRsNGub1I,zdxw68FsQAVBimfrk = 0,''
		for IIdL96fpC4Wwo8P1 in bJLZyM4f3DdGVolOm.split(' '):
			Sxo3DnAsGZ = QUJZGiYFWnhp6DR(' '+IIdL96fpC4Wwo8P1)
			rrbmNdzQaJUh0ZFRyDWYGVKkX,PdZ2OfA9GQxbocsm5nywVgMWj = OMhBi91ZNJ6s7dIQxjw.textsize(Sxo3DnAsGZ,font=WaQkLiUSArdmwZG42N)
			if i9izlOmHDqrYjXv0pcwJRsNGub1I+rrbmNdzQaJUh0ZFRyDWYGVKkX<d4hUcPVD2EJH0qyM:
				if not zdxw68FsQAVBimfrk: zdxw68FsQAVBimfrk += IIdL96fpC4Wwo8P1
				else: zdxw68FsQAVBimfrk += ' '+IIdL96fpC4Wwo8P1
				i9izlOmHDqrYjXv0pcwJRsNGub1I += rrbmNdzQaJUh0ZFRyDWYGVKkX
			else:
				if rrbmNdzQaJUh0ZFRyDWYGVKkX<d4hUcPVD2EJH0qyM:
					zdxw68FsQAVBimfrk += '\n '+IIdL96fpC4Wwo8P1
					upwMdTGcnrD7Xe9lJRhBb3zyNEPK += NCodLPpMklzgm3
					i9izlOmHDqrYjXv0pcwJRsNGub1I = rrbmNdzQaJUh0ZFRyDWYGVKkX
				else:
					while rrbmNdzQaJUh0ZFRyDWYGVKkX>d4hUcPVD2EJH0qyM:
						for L4SCkrby5m8gjWwHOn0fJuhqQYvUN in range(1,len(' '+IIdL96fpC4Wwo8P1),1):
							AZMpl7nB9vuTebE = ' '+IIdL96fpC4Wwo8P1[:L4SCkrby5m8gjWwHOn0fJuhqQYvUN]
							cJLl8HnDhuN7AMIZV3wFtjk0U = IIdL96fpC4Wwo8P1[L4SCkrby5m8gjWwHOn0fJuhqQYvUN:]
							nKXWolqHtwzdm0RMNF = QUJZGiYFWnhp6DR(AZMpl7nB9vuTebE)
							MMoaTspRgz7Hbxm2ije,zkch5O4YIq9pKmsnT8FD = OMhBi91ZNJ6s7dIQxjw.textsize(nKXWolqHtwzdm0RMNF,font=WaQkLiUSArdmwZG42N)
							if i9izlOmHDqrYjXv0pcwJRsNGub1I+MMoaTspRgz7Hbxm2ije>d4hUcPVD2EJH0qyM:
								NYFSQpbW18vMCDlZgBraJo60Oe9Iu = rrbmNdzQaJUh0ZFRyDWYGVKkX-MMoaTspRgz7Hbxm2ije
								zdxw68FsQAVBimfrk += AZMpl7nB9vuTebE+'\n'
								upwMdTGcnrD7Xe9lJRhBb3zyNEPK += NCodLPpMklzgm3
								rrbmNdzQaJUh0ZFRyDWYGVKkX = NYFSQpbW18vMCDlZgBraJo60Oe9Iu
								if NYFSQpbW18vMCDlZgBraJo60Oe9Iu>d4hUcPVD2EJH0qyM:
									i9izlOmHDqrYjXv0pcwJRsNGub1I = 0
									IIdL96fpC4Wwo8P1 = cJLl8HnDhuN7AMIZV3wFtjk0U
								else:
									i9izlOmHDqrYjXv0pcwJRsNGub1I = NYFSQpbW18vMCDlZgBraJo60Oe9Iu
									zdxw68FsQAVBimfrk += cJLl8HnDhuN7AMIZV3wFtjk0U
								break
				if upwMdTGcnrD7Xe9lJRhBb3zyNEPK>Y3ySGvmjDq028nATbKose9H7ItJ: break
		ii1aElnYkyceRpXfb2FAv += '\n'+zdxw68FsQAVBimfrk
		if upwMdTGcnrD7Xe9lJRhBb3zyNEPK>Y3ySGvmjDq028nATbKose9H7ItJ: break
	ii1aElnYkyceRpXfb2FAv = ii1aElnYkyceRpXfb2FAv[1:]
	ii1aElnYkyceRpXfb2FAv = ii1aElnYkyceRpXfb2FAv.replace('[COLOR:::','[COLOR ')
	return ii1aElnYkyceRpXfb2FAv
def QUJZGiYFWnhp6DR(IIdL96fpC4Wwo8P1):
	if '[' in IIdL96fpC4Wwo8P1 and ']' in IIdL96fpC4Wwo8P1:
		Bqwv4PKQL7Tiy8lc = ['[/COLOR]','[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		bBj7maw5K4QxO = GGvHJKP9LUxEk10Fw.findall('\[COLOR .*?\]',IIdL96fpC4Wwo8P1,GGvHJKP9LUxEk10Fw.DOTALL)
		ruNIm3D1gYkWTzXj4VbqAHy8ES = GGvHJKP9LUxEk10Fw.findall('\[COLOR:::.*?\]',IIdL96fpC4Wwo8P1,GGvHJKP9LUxEk10Fw.DOTALL)
		hLbUxXYQ3HusR = Bqwv4PKQL7Tiy8lc+bBj7maw5K4QxO+ruNIm3D1gYkWTzXj4VbqAHy8ES
		for TeMLgVimqnEraDP2tfSK6cz9YIb57 in hLbUxXYQ3HusR: IIdL96fpC4Wwo8P1 = IIdL96fpC4Wwo8P1.replace(TeMLgVimqnEraDP2tfSK6cz9YIb57,'')
	return IIdL96fpC4Wwo8P1
def uvBWAOzt67(MMupPCxqkenwt6FlsbRILV37EAmB):
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('\n','_sss__newline_')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('[RTL]','_sss__linertl_')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('[LEFT]','_sss__lineleft_')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('[RIGHT]','_sss__lineright_')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('[CENTER]','_sss__linecenter_')
	MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('[/COLOR]','_sss__endcolor_')
	OGMS5rvAUDs3FW1NQcIhX4nB2qjbg = GGvHJKP9LUxEk10Fw.findall('\[COLOR (.*?)\]',MMupPCxqkenwt6FlsbRILV37EAmB,GGvHJKP9LUxEk10Fw.DOTALL)
	for TBIjeGmbQxgZ9S4lHhU1kLywOfsvaC in OGMS5rvAUDs3FW1NQcIhX4nB2qjbg: MMupPCxqkenwt6FlsbRILV37EAmB = MMupPCxqkenwt6FlsbRILV37EAmB.replace('[COLOR '+TBIjeGmbQxgZ9S4lHhU1kLywOfsvaC+']','_sss__newcolor'+TBIjeGmbQxgZ9S4lHhU1kLywOfsvaC+'_')
	return MMupPCxqkenwt6FlsbRILV37EAmB
def uHqQfiPTpJIj971nbGMs03LoyzwK(WJr6B5imnN1Cypw=''):
	if not WJr6B5imnN1Cypw: WJr6B5imnN1Cypw = cEZpW924rqNYm5.getInfoLabel('ListItem.Label')
	WJr6B5imnN1Cypw = WJr6B5imnN1Cypw.replace('[/COLOR]','')
	WJr6B5imnN1Cypw = WJr6B5imnN1Cypw.replace('    ',' ').replace('   ',' ').replace('  ',' ').strip(' ')
	WJr6B5imnN1Cypw = WJr6B5imnN1Cypw.replace('[COLOR FFFFFF00]','').replace('[COLOR FFC89008]','')
	WKVr1RjQDSC = GGvHJKP9LUxEk10Fw.findall('\d\d:\d\d ',WJr6B5imnN1Cypw,GGvHJKP9LUxEk10Fw.DOTALL)
	if WKVr1RjQDSC: WJr6B5imnN1Cypw = WJr6B5imnN1Cypw.split(WKVr1RjQDSC[0],1)[1]
	if not WJr6B5imnN1Cypw: WJr6B5imnN1Cypw = 'Main Menu'
	return WJr6B5imnN1Cypw
def ICnDbfxZ5031iOzrYGH98sy2LtQ(z4zpsIWKUVTxqe2NY9H1OJD7Xgb):
	ZXeG6kKu03LSq = ''.join(L4SCkrby5m8gjWwHOn0fJuhqQYvUN for L4SCkrby5m8gjWwHOn0fJuhqQYvUN in z4zpsIWKUVTxqe2NY9H1OJD7Xgb if L4SCkrby5m8gjWwHOn0fJuhqQYvUN not in '\/":*?<>|'+P4F7od5xLE0quekH3nSzXj92ThwINY)
	return ZXeG6kKu03LSq
def Us3m2wZCVWHruY(zdu6VAyNEi5IL1):
	XMizba85pAG = GGvHJKP9LUxEk10Fw.findall("adilbo_HTML_encoder(.*?)/g.....(.*?)\)",zdu6VAyNEi5IL1,GGvHJKP9LUxEk10Fw.S)
	if XMizba85pAG:
		OElk4CQSYhvtKbqAxWdNFaGpZ,CMTvxERwVmDUg4iWG8hloaHyZdb3f6 = XMizba85pAG[0]
		OElk4CQSYhvtKbqAxWdNFaGpZ = GGvHJKP9LUxEk10Fw.findall("=[\r\n\s\t]+'(.*?)';", OElk4CQSYhvtKbqAxWdNFaGpZ, GGvHJKP9LUxEk10Fw.S)[0]
		if OElk4CQSYhvtKbqAxWdNFaGpZ and CMTvxERwVmDUg4iWG8hloaHyZdb3f6:
			xSjb7l5acEUVhCT = OElk4CQSYhvtKbqAxWdNFaGpZ.replace("'",'').replace("+",'').replace("\n",'').replace("\r",'')
			hPflYDOqb7KxEaMI9eNBm0nLU6 = xSjb7l5acEUVhCT.split('.')
			zdu6VAyNEi5IL1 = ''
			for yuKl1YUTftWOC9jnJ85 in hPflYDOqb7KxEaMI9eNBm0nLU6:
				B0BuW3GdQbgCKNqOwyLizSA = hNe0ECZHr9B6.b64decode(yuKl1YUTftWOC9jnJ85+'==').decode('utf8')
				rOIqJVx6Xvf8L1o9dn = GGvHJKP9LUxEk10Fw.findall('\d+', B0BuW3GdQbgCKNqOwyLizSA, GGvHJKP9LUxEk10Fw.S)
				if rOIqJVx6Xvf8L1o9dn:
					Igw2ai9cBuRGT8Ef0rokvj = int(rOIqJVx6Xvf8L1o9dn[0])
					Igw2ai9cBuRGT8Ef0rokvj += int(CMTvxERwVmDUg4iWG8hloaHyZdb3f6)
					zdu6VAyNEi5IL1 = zdu6VAyNEi5IL1 + chr(Igw2ai9cBuRGT8Ef0rokvj)
			if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: zdu6VAyNEi5IL1 = zdu6VAyNEi5IL1.encode('iso-8859-1').decode('utf8')
	return zdu6VAyNEi5IL1
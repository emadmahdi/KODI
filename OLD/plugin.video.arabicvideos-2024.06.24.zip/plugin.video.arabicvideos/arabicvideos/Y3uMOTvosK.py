# -*- coding: utf-8 -*-
import sys as GGtWyVoJReUuEBCdAagiL1YXO8
ggqTOXpCEcQD68f3oxrKilaSvkdtN = GGtWyVoJReUuEBCdAagiL1YXO8.version_info [0] == 2
pQ14eMnbYBK0xGywR7SuFChJdONj6 = 2048
y65ArzSx9RZh = 7
def MUzuWiALbXp6w5 (TMw2a0zHkY9lcdIvLFZXrS):
	global ynv9hpqlRAJuN0gXrEscaoP5dMWYDO
	Icnd5Dq4krBK3iYg2xNZHF = ord (TMw2a0zHkY9lcdIvLFZXrS [-1])
	u05ustK47xXQZbyFerWTROY = TMw2a0zHkY9lcdIvLFZXrS [:-1]
	BXAu3ZJQ9IPLg7kiy4K06ha = Icnd5Dq4krBK3iYg2xNZHF % len (u05ustK47xXQZbyFerWTROY)
	nRXUw1Fg0DSrkYGL = u05ustK47xXQZbyFerWTROY [:BXAu3ZJQ9IPLg7kiy4K06ha] + u05ustK47xXQZbyFerWTROY [BXAu3ZJQ9IPLg7kiy4K06ha:]
	if ggqTOXpCEcQD68f3oxrKilaSvkdtN:
		sW7Qyn32Zidt5TE4w96 = unicode () .join ([unichr (ord (Lk9Jh0wu7aNAE) - pQ14eMnbYBK0xGywR7SuFChJdONj6 - (Ebxc6eiUkyVNfMBs3CRIOArQ4h + Icnd5Dq4krBK3iYg2xNZHF) % y65ArzSx9RZh) for Ebxc6eiUkyVNfMBs3CRIOArQ4h, Lk9Jh0wu7aNAE in enumerate (nRXUw1Fg0DSrkYGL)])
	else:
		sW7Qyn32Zidt5TE4w96 = str () .join ([chr (ord (Lk9Jh0wu7aNAE) - pQ14eMnbYBK0xGywR7SuFChJdONj6 - (Ebxc6eiUkyVNfMBs3CRIOArQ4h + Icnd5Dq4krBK3iYg2xNZHF) % y65ArzSx9RZh) for Ebxc6eiUkyVNfMBs3CRIOArQ4h, Lk9Jh0wu7aNAE in enumerate (nRXUw1Fg0DSrkYGL)])
	return eval (sW7Qyn32Zidt5TE4w96)
Cu1704YofAbr3QTm,oh5Ptv7RjM3qLk1eEZJbcVzKis4d,LiRcTVUWuth70DmPy=MUzuWiALbXp6w5,MUzuWiALbXp6w5,MUzuWiALbXp6w5
pq3Z6xaELn0NW7PgAeI1bCRwdu,UTelCo0ihE1d5R,Me28A1sBLNIgUp5YCDyvT=LiRcTVUWuth70DmPy,oh5Ptv7RjM3qLk1eEZJbcVzKis4d,Cu1704YofAbr3QTm
kEhAHvti6Vnsfx,g4g6bfkPtVGU5lIM3,E6MIKdpBomef=Me28A1sBLNIgUp5YCDyvT,UTelCo0ihE1d5R,pq3Z6xaELn0NW7PgAeI1bCRwdu
wRxoKs10Syj7V4edYhtP,yA5z6LIXBlo41PRVMY87wOisFp,iUeoLOsbHqP=E6MIKdpBomef,g4g6bfkPtVGU5lIM3,kEhAHvti6Vnsfx
iRoLg2m47tnDATBHGCSPNyx,xW2Arao7YVOemw,l30iT7pjzmXk8dvwSNyUR1aZO4tWh=iUeoLOsbHqP,yA5z6LIXBlo41PRVMY87wOisFp,wRxoKs10Syj7V4edYhtP
dshJSmRqeiP9nap2,FnBiAjthS8MkXs67W,FvNyZqaLKw=l30iT7pjzmXk8dvwSNyUR1aZO4tWh,xW2Arao7YVOemw,iRoLg2m47tnDATBHGCSPNyx
SO94xq1RAkMm2uF,bUdr5Hahw6sY8xJ,XzrqbGDIy54juixkMA=FvNyZqaLKw,FnBiAjthS8MkXs67W,dshJSmRqeiP9nap2
p72fnFtcPix5UKwr9YNzW,sTcr7iDp5eFt4RoLMhuwq1A,SyENPzdOon6uxcLXMhqb14aDlB9r=XzrqbGDIy54juixkMA,bUdr5Hahw6sY8xJ,SO94xq1RAkMm2uF
zqdvcbP5L8BHh,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF,lc0dpSmwoPDjLnk=SyENPzdOon6uxcLXMhqb14aDlB9r,sTcr7iDp5eFt4RoLMhuwq1A,p72fnFtcPix5UKwr9YNzW
QVZl0O8yUIzdGDTfYcn5H37uWmb2,hRNlWkwDitzVpbSO3TIdAm5YGjaZ,fprnld4CZo=lc0dpSmwoPDjLnk,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF,zqdvcbP5L8BHh
hBvsQ7oCkKUdwjx58ml3EN,G5DeRbUpFj8E9OtJLvlo2fWmZC,S4SOKF2QbBhjCd3RrVMuHIzE=fprnld4CZo,hRNlWkwDitzVpbSO3TIdAm5YGjaZ,QVZl0O8yUIzdGDTfYcn5H37uWmb2
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
mmDwMlfoHtG5XT19VLIWqCR8i = YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
kkoVHLuYW1yBUtq4dxnTwO5XFfeMP = WpgZTyqoMAPhwGiXF.path.join(verdwoPF9GcOh1psxjHB34lgRMI,iRoLg2m47tnDATBHGCSPNyx(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
e7cHgraq6wUiOjDhk3sSxMK2nVLPA = WpgZTyqoMAPhwGiXF.path.join(verdwoPF9GcOh1psxjHB34lgRMI,fprnld4CZo(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
KKRnGTPirdY = WpgZTyqoMAPhwGiXF.path.join(mjaho7R5dY6eg,g4g6bfkPtVGU5lIM3(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
fJo0re3DEITGzuAXyd9F4 = OOP32CuaLYlWIscZg4tr19kMx
Owg8PXCdkTSEAxQNhis7 = wRxoKs10Syj7V4edYhtP(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
DF6OeAQnZo3 = UTelCo0ihE1d5R(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
lz3dkoVg2vcr = xW2Arao7YVOemw(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
ifLMaW59VBnlg1rFKED6sA = iUeoLOsbHqP(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
KJd6zmGAxBF1NVr = wRxoKs10Syj7V4edYhtP(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
LkG6CstJw37dl = g4g6bfkPtVGU5lIM3(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(VRnfEFmJzUrSljM8):
	if   VRnfEFmJzUrSljM8==lc0dpSmwoPDjLnk(u"࠹࠷࠴ࣉ"): zpXG3Ky6ou8ndWHkb4 = qlPwBTRK5kZgi0uneIo()
	elif VRnfEFmJzUrSljM8==hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠺࠸࠶࣊"): zpXG3Ky6ou8ndWHkb4 = OOy4gzCqrV382ctPa(kkoVHLuYW1yBUtq4dxnTwO5XFfeMP,p72fnFtcPix5UKwr9YNzW(u"ࡖࡵࡹࡪࣳ"),p72fnFtcPix5UKwr9YNzW(u"ࡖࡵࡹࡪࣳ"))
	elif VRnfEFmJzUrSljM8==yA5z6LIXBlo41PRVMY87wOisFp(u"࠻࠹࠸࣋"): zpXG3Ky6ou8ndWHkb4 = OOy4gzCqrV382ctPa(e7cHgraq6wUiOjDhk3sSxMK2nVLPA,SO94xq1RAkMm2uF(u"ࡗࡶࡺ࡫ࣴ"),SO94xq1RAkMm2uF(u"ࡗࡶࡺ࡫ࣴ"))
	elif VRnfEFmJzUrSljM8==hBvsQ7oCkKUdwjx58ml3EN(u"࠼࠺࠳࣌"): zpXG3Ky6ou8ndWHkb4 = OOy4gzCqrV382ctPa(KKRnGTPirdY,g4g6bfkPtVGU5lIM3(u"ࡋࡧ࡬ࡴࡧࣶ"),FnBiAjthS8MkXs67W(u"ࡘࡷࡻࡥࣵ"))
	elif VRnfEFmJzUrSljM8==Me28A1sBLNIgUp5YCDyvT(u"࠽࠴࠵࣍"): zpXG3Ky6ou8ndWHkb4 = gJWRyKDkx3YHfMrj8(fJo0re3DEITGzuAXyd9F4,S4SOKF2QbBhjCd3RrVMuHIzE(u"࡚ࡲࡶࡧࣷ"))
	elif VRnfEFmJzUrSljM8==iUeoLOsbHqP(u"࠷࠵࠷࣎"): zpXG3Ky6ou8ndWHkb4 = pMWLn3hstBrGDHQd6Rgfl(iRoLg2m47tnDATBHGCSPNyx(u"ࡔࡳࡷࡨࣸ"))
	elif VRnfEFmJzUrSljM8==FvNyZqaLKw(u"࠸࠷࠳࣏"): zpXG3Ky6ou8ndWHkb4 = Z8nSetKYNjEuMGLoXlCfqcwV71T()
	elif VRnfEFmJzUrSljM8==SO94xq1RAkMm2uF(u"࠹࠸࠵࣐"): zpXG3Ky6ou8ndWHkb4 = OOy4gzCqrV382ctPa(Owg8PXCdkTSEAxQNhis7,xW2Arao7YVOemw(u"ࡈࡤࡰࡸ࡫ࣺ"),dshJSmRqeiP9nap2(u"ࡕࡴࡸࡩࣹ"))
	elif VRnfEFmJzUrSljM8==QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠺࠹࠷࣑"): zpXG3Ky6ou8ndWHkb4 = OOy4gzCqrV382ctPa(DF6OeAQnZo3,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࡊࡦࡲࡳࡦࣼ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࡗࡶࡺ࡫ࣻ"))
	elif VRnfEFmJzUrSljM8==l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠻࠺࠹࣒"): zpXG3Ky6ou8ndWHkb4 = OOy4gzCqrV382ctPa(lz3dkoVg2vcr,XzrqbGDIy54juixkMA(u"ࡌࡡ࡭ࡵࡨࣾ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"࡙ࡸࡵࡦࣽ"))
	elif VRnfEFmJzUrSljM8==Me28A1sBLNIgUp5YCDyvT(u"࠼࠻࠴࣓"): zpXG3Ky6ou8ndWHkb4 = OOy4gzCqrV382ctPa(ifLMaW59VBnlg1rFKED6sA,fprnld4CZo(u"ࡇࡣ࡯ࡷࡪऀ"),g4g6bfkPtVGU5lIM3(u"ࡔࡳࡷࡨࣿ"))
	elif VRnfEFmJzUrSljM8==Me28A1sBLNIgUp5YCDyvT(u"࠽࠵࠶ࣔ"): zpXG3Ky6ou8ndWHkb4 = OOy4gzCqrV382ctPa(KJd6zmGAxBF1NVr,zqdvcbP5L8BHh(u"ࡉࡥࡱࡹࡥं"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࡖࡵࡹࡪँ"))
	elif VRnfEFmJzUrSljM8==iRoLg2m47tnDATBHGCSPNyx(u"࠷࠶࠸ࣕ"): zpXG3Ky6ou8ndWHkb4 = OOy4gzCqrV382ctPa(LkG6CstJw37dl,FvNyZqaLKw(u"ࡋࡧ࡬ࡴࡧऄ"),bUdr5Hahw6sY8xJ(u"ࡘࡷࡻࡥः"))
	elif VRnfEFmJzUrSljM8==FnBiAjthS8MkXs67W(u"࠸࠷࠺ࣖ"): zpXG3Ky6ou8ndWHkb4 = ocYUR14dTItpVeDO(iUeoLOsbHqP(u"࡚ࡲࡶࡧअ"))
	elif VRnfEFmJzUrSljM8==Cu1704YofAbr3QTm(u"࠹࠸࠼ࣗ"): zpXG3Ky6ou8ndWHkb4 = DkeNKqGdnt5ja41w2OFP()
	else: zpXG3Ky6ou8ndWHkb4 = FnBiAjthS8MkXs67W(u"ࡆࡢ࡮ࡶࡩआ")
	return zpXG3Ky6ou8ndWHkb4
def qlPwBTRK5kZgi0uneIo():
	HHGjg6oYIy,muEGPtzwjHfAh6d32rNXyBpFI = EmIh7grLsY4ZxTw3O2vKa(kkoVHLuYW1yBUtq4dxnTwO5XFfeMP)
	jKaUOgPyBzCvr3Sp,rrbJ4Tadynmf9kKhoHOC = EmIh7grLsY4ZxTw3O2vKa(e7cHgraq6wUiOjDhk3sSxMK2nVLPA)
	kklGOxMf5vLnm9H7KqUbYpJW,RQtjlakdsW3 = EmIh7grLsY4ZxTw3O2vKa(KKRnGTPirdY)
	bOtr6HyJjAs4,gmNqslW7bV0C2cU9oEJr = hYNG3tj5Xu2knZ7lowbS(fJo0re3DEITGzuAXyd9F4)
	bOtr6HyJjAs4 -= zqdvcbP5L8BHh(u"࠶࠺࠽࠼࠴ࣘ")
	gmNqslW7bV0C2cU9oEJr -= FnBiAjthS8MkXs67W(u"࠵ࣙ")
	WudaQ1Cgy08NvYx5SZkzwVP4BDt = bUdr5Hahw6sY8xJ(u"ࠩࠣࠬࠬࠌ")+IKgwb8n0T3a(HHGjg6oYIy)+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࠤ࠲ࠦࠧࠍ")+str(muEGPtzwjHfAh6d32rNXyBpFI)+fprnld4CZo(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠎ")
	F2jvcEiRap8KbWh = sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬࠦࠨࠨࠏ")+IKgwb8n0T3a(jKaUOgPyBzCvr3Sp)+E6MIKdpBomef(u"࠭ࠠ࠮ࠢࠪࠐ")+str(rrbJ4Tadynmf9kKhoHOC)+g4g6bfkPtVGU5lIM3(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠑ")
	uuaHVcLxsdkXbqtY1fzRhi = p72fnFtcPix5UKwr9YNzW(u"ࠨࠢࠫࠫࠒ")+IKgwb8n0T3a(kklGOxMf5vLnm9H7KqUbYpJW)+iUeoLOsbHqP(u"ࠩࠣ࠱ࠥ࠭ࠓ")+str(RQtjlakdsW3)+fprnld4CZo(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠔ")
	a0xUXYviFC8sb9Apt26mr = xW2Arao7YVOemw(u"ࠫࠥ࠮ࠧࠕ")+IKgwb8n0T3a(bOtr6HyJjAs4)+Cu1704YofAbr3QTm(u"ࠬ࠯ࠧࠖ")
	FKbzR4LiqVGEDcjQ2vUTM9Wk = HHGjg6oYIy+jKaUOgPyBzCvr3Sp+kklGOxMf5vLnm9H7KqUbYpJW+bOtr6HyJjAs4
	WLM259V3hkGyifQBAcnS = muEGPtzwjHfAh6d32rNXyBpFI+rrbJ4Tadynmf9kKhoHOC+RQtjlakdsW3+gmNqslW7bV0C2cU9oEJr
	MMupPCxqkenwt6FlsbRILV37EAmB = zqdvcbP5L8BHh(u"࠭ࠠࠩࠩࠗ")+IKgwb8n0T3a(FKbzR4LiqVGEDcjQ2vUTM9Wk)+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧࠡ࠯ࠣࠫ࠘")+str(WLM259V3hkGyifQBAcnS)+FnBiAjthS8MkXs67W(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠙")
	cd0aGwCPExbFU5pYNu8r(fprnld4CZo(u"ࠩ࡯࡭ࡳࡱࠧࠚ"),mmDwMlfoHtG5XT19VLIWqCR8i+xW2Arao7YVOemw(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࠛ")+MMupPCxqkenwt6FlsbRILV37EAmB,sTcr7iDp5eFt4RoLMhuwq1A(u"ࠫࠬࠜ"),kEhAHvti6Vnsfx(u"࠼࠺࠵ࣚ"))
	cd0aGwCPExbFU5pYNu8r(g4g6bfkPtVGU5lIM3(u"ࠬࡲࡩ࡯࡭ࠪࠝ"),FnBiAjthS8MkXs67W(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨࠞ"),FvNyZqaLKw(u"ࠧࠨࠟ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠿࠹࠺࠻ࣛ"))
	cd0aGwCPExbFU5pYNu8r(p72fnFtcPix5UKwr9YNzW(u"ࠨ࡮࡬ࡲࡰ࠭ࠠ"),mmDwMlfoHtG5XT19VLIWqCR8i+zqdvcbP5L8BHh(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠨࠡ")+WudaQ1Cgy08NvYx5SZkzwVP4BDt,G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠪࠫࠢ"),LiRcTVUWuth70DmPy(u"࠷࠵࠳ࣜ"))
	cd0aGwCPExbFU5pYNu8r(xW2Arao7YVOemw(u"ࠫࡱ࡯࡮࡬ࠩࠣ"),mmDwMlfoHtG5XT19VLIWqCR8i+bUdr5Hahw6sY8xJ(u"๋ࠬำฮࠢส่๊๊แศฬࠣห้๋ึ฻ฺ๊อࠬࠤ")+F2jvcEiRap8KbWh,p72fnFtcPix5UKwr9YNzW(u"࠭ࠧࠥ"),lc0dpSmwoPDjLnk(u"࠸࠶࠵ࣝ"))
	cd0aGwCPExbFU5pYNu8r(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧ࡭࡫ࡱ࡯ࠬࠦ"),mmDwMlfoHtG5XT19VLIWqCR8i+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨ็ึัࠥอไึ๊ิࠤฬ๊โะ์่อࠬࠧ")+uuaHVcLxsdkXbqtY1fzRhi,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࠪࠨ"),UTelCo0ihE1d5R(u"࠹࠷࠷ࣞ"))
	cd0aGwCPExbFU5pYNu8r(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪࡰ࡮ࡴ࡫ࠨࠩ"),mmDwMlfoHtG5XT19VLIWqCR8i+sTcr7iDp5eFt4RoLMhuwq1A(u"ࠫฯ็ั๋฼้้ࠣ็ࠠึ๊ิࠤฬ๊ลืษไหฯ࠭ࠪ")+a0xUXYviFC8sb9Apt26mr,lc0dpSmwoPDjLnk(u"ࠬ࠭ࠫ"),dshJSmRqeiP9nap2(u"࠺࠸࠹ࣟ"))
	jHevARrF7lS.setSetting(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࠬ"),zqdvcbP5L8BHh(u"ࠧࠨ࠭"))
	return
def Z8nSetKYNjEuMGLoXlCfqcwV71T():
	LLOfPVX2lsxZFmSTdEMWhp = bUdr5Hahw6sY8xJ(u"ࡖࡵࡹࡪई") if g4g6bfkPtVGU5lIM3(u"ࠨ࠱ࠪ࠮") in mjaho7R5dY6eg else SO94xq1RAkMm2uF(u"ࡇࡣ࡯ࡷࡪइ")
	if not LLOfPVX2lsxZFmSTdEMWhp:
		aHKzv76JCVnprbY8w(UTelCo0ihE1d5R(u"ࠩࠪ࠯"),UTelCo0ihE1d5R(u"ࠪࠫ࠰"),lc0dpSmwoPDjLnk(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ࠱"),XzrqbGDIy54juixkMA(u"ࠬ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣห้า็ศิ้ࠣฯ๎แาหࠣๅ็฽ࠠๅลฯ๋ืฯ๋๊้ࠠ็ุࠦ࠮࠯๋ࠢะ์อาไࠢ็๎ุࠦๅ็้ࠢ์฾๊้่ࠦๆืࠬ࠲"))
		return
	gGudVm2TlMnyh = jHevARrF7lS.getSetting(g4g6bfkPtVGU5lIM3(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪ࠳"))
	if not gGudVm2TlMnyh: DkeNKqGdnt5ja41w2OFP()
	HHGjg6oYIy,muEGPtzwjHfAh6d32rNXyBpFI = EmIh7grLsY4ZxTw3O2vKa(Owg8PXCdkTSEAxQNhis7)
	jKaUOgPyBzCvr3Sp,rrbJ4Tadynmf9kKhoHOC = EmIh7grLsY4ZxTw3O2vKa(DF6OeAQnZo3)
	kklGOxMf5vLnm9H7KqUbYpJW,RQtjlakdsW3 = EmIh7grLsY4ZxTw3O2vKa(lz3dkoVg2vcr)
	bOtr6HyJjAs4,gmNqslW7bV0C2cU9oEJr = EmIh7grLsY4ZxTw3O2vKa(ifLMaW59VBnlg1rFKED6sA)
	kNvRGE2XyA0YKcdfpV7ea31HBQgC,VlPvrZNwpF180fnbhtG = EmIh7grLsY4ZxTw3O2vKa(KJd6zmGAxBF1NVr)
	dnULqbfjksMGcp6Al75W3iJFtXrI8,yA2vgh1UHWBl = EmIh7grLsY4ZxTw3O2vKa(LkG6CstJw37dl)
	WudaQ1Cgy08NvYx5SZkzwVP4BDt = kEhAHvti6Vnsfx(u"ࠧࠡࠪࠪ࠴")+IKgwb8n0T3a(HHGjg6oYIy)+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠨࠢ࠰ࠤࠬ࠵")+str(muEGPtzwjHfAh6d32rNXyBpFI)+kEhAHvti6Vnsfx(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪ࠶")
	F2jvcEiRap8KbWh = g4g6bfkPtVGU5lIM3(u"ࠪࠤ࠭࠭࠷")+IKgwb8n0T3a(jKaUOgPyBzCvr3Sp)+Me28A1sBLNIgUp5YCDyvT(u"ࠫࠥ࠳ࠠࠨ࠸")+str(rrbJ4Tadynmf9kKhoHOC)+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭࠹")
	uuaHVcLxsdkXbqtY1fzRhi = xW2Arao7YVOemw(u"࠭ࠠࠩࠩ࠺")+IKgwb8n0T3a(kklGOxMf5vLnm9H7KqUbYpJW)+Cu1704YofAbr3QTm(u"ࠧࠡ࠯ࠣࠫ࠻")+str(RQtjlakdsW3)+iUeoLOsbHqP(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠼")
	a0xUXYviFC8sb9Apt26mr = SO94xq1RAkMm2uF(u"ࠩࠣࠬࠬ࠽")+IKgwb8n0T3a(bOtr6HyJjAs4)+E6MIKdpBomef(u"ࠪࠤ࠲ࠦࠧ࠾")+str(gmNqslW7bV0C2cU9oEJr)+sTcr7iDp5eFt4RoLMhuwq1A(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬ࠿")
	kk6bLhQMDI = bUdr5Hahw6sY8xJ(u"ࠬࠦࠨࠨࡀ")+IKgwb8n0T3a(kNvRGE2XyA0YKcdfpV7ea31HBQgC)+kEhAHvti6Vnsfx(u"࠭ࠠ࠮ࠢࠪࡁ")+str(VlPvrZNwpF180fnbhtG)+XzrqbGDIy54juixkMA(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࡂ")
	PqpeoCUu4WBdk1fIJR = bUdr5Hahw6sY8xJ(u"ࠨࠢࠫࠫࡃ")+IKgwb8n0T3a(dnULqbfjksMGcp6Al75W3iJFtXrI8)+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࠣ࠱ࠥ࠭ࡄ")+str(yA2vgh1UHWBl)+S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡅ")
	FKbzR4LiqVGEDcjQ2vUTM9Wk = HHGjg6oYIy+jKaUOgPyBzCvr3Sp+kklGOxMf5vLnm9H7KqUbYpJW+bOtr6HyJjAs4+kNvRGE2XyA0YKcdfpV7ea31HBQgC+dnULqbfjksMGcp6Al75W3iJFtXrI8
	WLM259V3hkGyifQBAcnS = muEGPtzwjHfAh6d32rNXyBpFI+rrbJ4Tadynmf9kKhoHOC+RQtjlakdsW3+gmNqslW7bV0C2cU9oEJr+VlPvrZNwpF180fnbhtG+yA2vgh1UHWBl
	MMupPCxqkenwt6FlsbRILV37EAmB = SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࠥ࠮ࠧࡆ")+IKgwb8n0T3a(FKbzR4LiqVGEDcjQ2vUTM9Wk)+dshJSmRqeiP9nap2(u"ࠬࠦ࠭ࠡࠩࡇ")+str(WLM259V3hkGyifQBAcnS)+Me28A1sBLNIgUp5YCDyvT(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࡈ")
	cd0aGwCPExbFU5pYNu8r(p72fnFtcPix5UKwr9YNzW(u"ࠧ࡭࡫ࡱ࡯ࠬࡉ"),mmDwMlfoHtG5XT19VLIWqCR8i+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨว฼฻ฬวࠠาะุอ่ࠥัศรฬࠤํ้สศสฬࠫࡊ"),wRxoKs10Syj7V4edYhtP(u"ࠩࠪࡋ"),LiRcTVUWuth70DmPy(u"࠻࠺࠾࣠"))
	cd0aGwCPExbFU5pYNu8r(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠪࡰ࡮ࡴ࡫ࠨࡌ"),mmDwMlfoHtG5XT19VLIWqCR8i+Cu1704YofAbr3QTm(u"ู๊ࠫอࠡษ็ะ๊๐ูࠨࡍ")+MMupPCxqkenwt6FlsbRILV37EAmB,zqdvcbP5L8BHh(u"ࠬ࠭ࡎ"),FnBiAjthS8MkXs67W(u"࠼࠻࠷࣡"))
	cd0aGwCPExbFU5pYNu8r(p72fnFtcPix5UKwr9YNzW(u"࠭࡬ࡪࡰ࡮ࠫࡏ"),g4g6bfkPtVGU5lIM3(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࡐ"),lc0dpSmwoPDjLnk(u"ࠨࠩࡑ"),hBvsQ7oCkKUdwjx58ml3EN(u"࠿࠹࠺࠻࣢"))
	cd0aGwCPExbFU5pYNu8r(LiRcTVUWuth70DmPy(u"ࠩ࡯࡭ࡳࡱࠧࡒ"),mmDwMlfoHtG5XT19VLIWqCR8i+YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ุ้ࠪำࠠๆๆไหฯࠦࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠪࡓ")+WudaQ1Cgy08NvYx5SZkzwVP4BDt,UTelCo0ihE1d5R(u"ࠫࠬࡔ"),fprnld4CZo(u"࠷࠶࠳ࣣ"))
	cd0aGwCPExbFU5pYNu8r(iRoLg2m47tnDATBHGCSPNyx(u"ࠬࡲࡩ࡯࡭ࠪࡕ"),mmDwMlfoHtG5XT19VLIWqCR8i+sTcr7iDp5eFt4RoLMhuwq1A(u"࠭ๅิฯ้้ࠣ็วหࠢࡧࡶࡴࡶࡢࡰࡺࠪࡖ")+F2jvcEiRap8KbWh,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧࠨࡗ"),dshJSmRqeiP9nap2(u"࠸࠷࠵ࣤ"))
	cd0aGwCPExbFU5pYNu8r(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨ࡮࡬ࡲࡰ࠭ࡘ"),mmDwMlfoHtG5XT19VLIWqCR8i+Me28A1sBLNIgUp5YCDyvT(u"่ࠩืาࠦๅๅใสฮࠥࡺ࡯࡮ࡤࡶࡸࡴࡴࡥࡴ࡙ࠩ")+uuaHVcLxsdkXbqtY1fzRhi,lc0dpSmwoPDjLnk(u"࡚ࠪࠫ"),SO94xq1RAkMm2uF(u"࠹࠸࠷ࣥ"))
	cd0aGwCPExbFU5pYNu8r(zqdvcbP5L8BHh(u"ࠫࡱ࡯࡮࡬࡛ࠩ"),mmDwMlfoHtG5XT19VLIWqCR8i+wRxoKs10Syj7V4edYhtP(u"๋ࠬำฮ่่ࠢๆอสࠡ࡮ࡲ࡫࡬࡫ࡲࠨ࡜")+a0xUXYviFC8sb9Apt26mr,Cu1704YofAbr3QTm(u"࠭ࠧ࡝"),kEhAHvti6Vnsfx(u"࠺࠹࠹ࣦ"))
	cd0aGwCPExbFU5pYNu8r(dshJSmRqeiP9nap2(u"ࠧ࡭࡫ࡱ࡯ࠬ࡞"),mmDwMlfoHtG5XT19VLIWqCR8i+wRxoKs10Syj7V4edYhtP(u"ࠨ็ึั๋ࠥไโษอࠤࡱࡵࡧࠨ࡟")+kk6bLhQMDI,UTelCo0ihE1d5R(u"ࠩࠪࡠ"),hBvsQ7oCkKUdwjx58ml3EN(u"࠻࠺࠻ࣧ"))
	cd0aGwCPExbFU5pYNu8r(kEhAHvti6Vnsfx(u"ࠪࡰ࡮ࡴ࡫ࠨࡡ"),mmDwMlfoHtG5XT19VLIWqCR8i+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ู๊ࠫอࠡ็็ๅฬะࠠࡢࡰࡵࠫࡢ")+PqpeoCUu4WBdk1fIJR,UTelCo0ihE1d5R(u"ࠬ࠭ࡣ"),SO94xq1RAkMm2uF(u"࠼࠻࠶ࣨ"))
	jHevARrF7lS.setSetting(FvNyZqaLKw(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࡤ"),Cu1704YofAbr3QTm(u"ࠧࠨࡥ"))
	return
def DkeNKqGdnt5ja41w2OFP():
	o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(dshJSmRqeiP9nap2(u"ࠨࠩࡦ"),kEhAHvti6Vnsfx(u"ࠩࠪࡧ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪࠫࡨ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࡩ"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"๊ࠬใ๋ࠢํ฽๊๊ࠠศๆอ๊฽๐แࠡ฻้ำ่ࠦ࠮࠯ࠢหี๋อๅอࠢ฼้ฬีࠠษฯสะฮࠦลๅ๋ࠣษ฾฽วยࠢิาฺฯࠠศๆๅีฬวษ๊ࠡส่่ะวษห่้๋ࠣไโษอࠤํอไๆฮ็ำฬะࠠศๆอ๎ู่ࠥโࠢํุ้ำ็ศࠢส่อืๆศ็ฯࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡว฼฻ฬว่ࠠา๊ࠤฬ๊ัฯืฬࠤฬ๊ย็ࠢยࠥࠬࡪ"))
	if o07Z1tEB4n3ARCkVNu==-p72fnFtcPix5UKwr9YNzW(u"࠷ࣩ"): return
	if o07Z1tEB4n3ARCkVNu:
		import subprocess as VVTLiYAdxGkP7
		try:
			VVTLiYAdxGkP7.Popen(g4g6bfkPtVGU5lIM3(u"࠭ࡳࡶࠩ࡫"))
			mLz1lyiJ2aCQHcF = sTcr7iDp5eFt4RoLMhuwq1A(u"ࡗࡶࡺ࡫उ")
		except: mLz1lyiJ2aCQHcF = g4g6bfkPtVGU5lIM3(u"ࡊࡦࡲࡳࡦऊ")
		if mLz1lyiJ2aCQHcF:
			oigBltVGHyus9YqrNDWx4vkf = Owg8PXCdkTSEAxQNhis7+E6MIKdpBomef(u"ࠧࠡࠩ࡬")+DF6OeAQnZo3+FvNyZqaLKw(u"ࠨࠢࠪ࡭")+lz3dkoVg2vcr+Me28A1sBLNIgUp5YCDyvT(u"ࠩࠣࠫ࡮")+ifLMaW59VBnlg1rFKED6sA+lc0dpSmwoPDjLnk(u"ࠪࠤࠬ࡯")+KJd6zmGAxBF1NVr+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࠥ࠭ࡰ")+LkG6CstJw37dl
			NP0ypRceX2E3 = VVTLiYAdxGkP7.Popen(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬࡹࡵࠡ࠯ࡦࠤࠧࡩࡨ࡮ࡱࡧࠤ࠲ࡘࠠ࠱࠹࠺࠻ࠥ࠭ࡱ")+oigBltVGHyus9YqrNDWx4vkf+wRxoKs10Syj7V4edYhtP(u"࠭ࠢࠨࡲ"),shell=XzrqbGDIy54juixkMA(u"࡙ࡸࡵࡦऋ"),stdin=VVTLiYAdxGkP7.PIPE,stdout=VVTLiYAdxGkP7.PIPE,stderr=VVTLiYAdxGkP7.PIPE)
			aHKzv76JCVnprbY8w(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠧࠨࡳ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠨࠩࡴ"),xW2Arao7YVOemw(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡵ"),dshJSmRqeiP9nap2(u"๊ࠪัำสࠡ฻่่๏ฯࠠฦ฻ฺหฦࠦวๅำัูฮ࠭ࡶ"))
			jHevARrF7lS.setSetting(g4g6bfkPtVGU5lIM3(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨࡷ"),E6MIKdpBomef(u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨࡸ"))
			cEZpW924rqNYm5.executebuiltin(wRxoKs10Syj7V4edYhtP(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪࡹ"))
		else: aHKzv76JCVnprbY8w(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠧࠨࡺ"),XzrqbGDIy54juixkMA(u"ࠨࠩࡻ"),g4g6bfkPtVGU5lIM3(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡼ"),p72fnFtcPix5UKwr9YNzW(u"ࠪ฽๊๊๊สࠢศ฽฼อมࠡำัูฮࠦวๅไิหฦฯ้ࠠษ็็ฯอศสࠢอัฯอฬࠡสิ๊ฬ๋ฬࠡࠢࡵࡳࡴࡺࠠࠡล๋ࠤࠥࡹࡵࡱࡧࡵࡹࡸ࡫ࡲࠡࠢฦ์ࠥࠦࡳࡶࠢࠣ์ัํวำๅ่ࠣฬ๊้ࠦฮาࠤๆ๐็้ࠡำหࠥอไษำ้ห๊าࠠ࠯࠰ࠣวํࠦใ้ัํࠤ฿๐ัࠡไสำึูࠦๅ๋ࠣหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠪࡽ"))
	return
def IKgwb8n0T3a(FKbzR4LiqVGEDcjQ2vUTM9Wk):
	for kH2pUF40DrLlqiPhM9wtKc in [FvNyZqaLKw(u"ࠫࡇ࠭ࡾ"),XzrqbGDIy54juixkMA(u"ࠬࡑࡂࠨࡿ"),iUeoLOsbHqP(u"࠭ࡍࡃࠩࢀ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࡈࡄࠪࢁ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨࡖࡅࠫࢂ")]:
		if FKbzR4LiqVGEDcjQ2vUTM9Wk<QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠱࠱࠴࠷࣪"): break
		else: FKbzR4LiqVGEDcjQ2vUTM9Wk /= QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠲࠲࠵࠸࠳࠶࣫")
	MMupPCxqkenwt6FlsbRILV37EAmB = E6MIKdpBomef(u"ࠤࠨ࠷࠳࠷ࡦࠡࠧࡶࠦࢃ")%(FKbzR4LiqVGEDcjQ2vUTM9Wk,kH2pUF40DrLlqiPhM9wtKc)
	return MMupPCxqkenwt6FlsbRILV37EAmB
def EmIh7grLsY4ZxTw3O2vKa(AGKR2WYpPtZdfyJSM=l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪ࠲ࠬࢄ")):
	global ZnLJhUy4sQdOa3CrNAPgxISH9Yepw2,PvTIqGjod45LYDaMcSVAbmnEx
	ZnLJhUy4sQdOa3CrNAPgxISH9Yepw2,PvTIqGjod45LYDaMcSVAbmnEx = S4SOKF2QbBhjCd3RrVMuHIzE(u"࠲࣬"),S4SOKF2QbBhjCd3RrVMuHIzE(u"࠲࣬")
	def tzS8hAyBYKpM0jXw(AGKR2WYpPtZdfyJSM):
		global ZnLJhUy4sQdOa3CrNAPgxISH9Yepw2,PvTIqGjod45LYDaMcSVAbmnEx
		if WpgZTyqoMAPhwGiXF.path.exists(AGKR2WYpPtZdfyJSM):
			if pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠳࣭") and iUeoLOsbHqP(u"ࠫࡸࡩࡡ࡯ࡦ࡬ࡶࠬࢅ") in dir(WpgZTyqoMAPhwGiXF):
				for S9B3J7ZWbVpM8fPtQ4 in WpgZTyqoMAPhwGiXF.scandir(AGKR2WYpPtZdfyJSM):
					if S9B3J7ZWbVpM8fPtQ4.is_dir(follow_symlinks=hBvsQ7oCkKUdwjx58ml3EN(u"ࡌࡡ࡭ࡵࡨऌ")):
						tzS8hAyBYKpM0jXw(S9B3J7ZWbVpM8fPtQ4.path)
					elif S9B3J7ZWbVpM8fPtQ4.is_file(follow_symlinks=FvNyZqaLKw(u"ࡆࡢ࡮ࡶࡩऍ")):
						ZnLJhUy4sQdOa3CrNAPgxISH9Yepw2 += S9B3J7ZWbVpM8fPtQ4.stat().st_size
						PvTIqGjod45LYDaMcSVAbmnEx += wRxoKs10Syj7V4edYhtP(u"࠵࣮")
			else:
				for S9B3J7ZWbVpM8fPtQ4 in WpgZTyqoMAPhwGiXF.listdir(AGKR2WYpPtZdfyJSM):
					abyzErNYtfoBs = WpgZTyqoMAPhwGiXF.path.abspath(WpgZTyqoMAPhwGiXF.path.join(AGKR2WYpPtZdfyJSM,S9B3J7ZWbVpM8fPtQ4))
					if WpgZTyqoMAPhwGiXF.path.isdir(abyzErNYtfoBs):
						tzS8hAyBYKpM0jXw(abyzErNYtfoBs)
					elif WpgZTyqoMAPhwGiXF.path.isfile(abyzErNYtfoBs):
						FKbzR4LiqVGEDcjQ2vUTM9Wk,WLM259V3hkGyifQBAcnS = hYNG3tj5Xu2knZ7lowbS(abyzErNYtfoBs)
						ZnLJhUy4sQdOa3CrNAPgxISH9Yepw2 += FKbzR4LiqVGEDcjQ2vUTM9Wk
						PvTIqGjod45LYDaMcSVAbmnEx += WLM259V3hkGyifQBAcnS
		return
	try: tzS8hAyBYKpM0jXw(AGKR2WYpPtZdfyJSM)
	except: pass
	return ZnLJhUy4sQdOa3CrNAPgxISH9Yepw2,PvTIqGjod45LYDaMcSVAbmnEx
def hFwmrXnMUVuzv1GxaH2SJ5YO(TCrSYwznIcVi5Zf,showDialogs):
	if showDialogs:
		o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(xW2Arao7YVOemw(u"ࠬ࠭ࢆ"),xW2Arao7YVOemw(u"࠭ࠧࢇ"),bUdr5Hahw6sY8xJ(u"ࠧࠨ࢈"),g4g6bfkPtVGU5lIM3(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࢉ"),TCrSYwznIcVi5Zf+wRxoKs10Syj7V4edYhtP(u"ࠩ࡟ࡲࡡࡴࠧࢊ")+kEhAHvti6Vnsfx(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่่ๆࠦฟࠢ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢋ"))
		if o07Z1tEB4n3ARCkVNu!=iUeoLOsbHqP(u"࠶࣯"): return
	sJ0eB9GwzmTUrvAO5 = zqdvcbP5L8BHh(u"ࡇࡣ࡯ࡷࡪऎ")
	if WpgZTyqoMAPhwGiXF.path.exists(TCrSYwznIcVi5Zf):
		try: WpgZTyqoMAPhwGiXF.remove(TCrSYwznIcVi5Zf)
		except Exception as WxmkzUZ3fys2XELCjn4idOvrP:
			if showDialogs: aHKzv76JCVnprbY8w(FvNyZqaLKw(u"ࠫࠬࢌ"),wRxoKs10Syj7V4edYhtP(u"ࠬ࠭ࢍ"),iRoLg2m47tnDATBHGCSPNyx(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢎ"),str(WxmkzUZ3fys2XELCjn4idOvrP))
			sJ0eB9GwzmTUrvAO5 = Cu1704YofAbr3QTm(u"ࡖࡵࡹࡪए")
	if showDialogs and not sJ0eB9GwzmTUrvAO5:
		aHKzv76JCVnprbY8w(Cu1704YofAbr3QTm(u"ࠧࠨ࢏"),iRoLg2m47tnDATBHGCSPNyx(u"ࠨࠩ࢐"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࢑"),g4g6bfkPtVGU5lIM3(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫ࢒"))
		jHevARrF7lS.setSetting(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨ࢓"),xW2Arao7YVOemw(u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨ࢔"))
		cEZpW924rqNYm5.executebuiltin(E6MIKdpBomef(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ࢕"))
	return
def pMWLn3hstBrGDHQd6Rgfl(showDialogs):
	if showDialogs:
		o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(g4g6bfkPtVGU5lIM3(u"ࠧࠨ࢖"),Cu1704YofAbr3QTm(u"ࠨࠩࢗ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࠪ࢘"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࢙࠭"),XzrqbGDIy54juixkMA(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ็ๅࠢอี๏ีࠠๆีะ࢚ࠫ")+p72fnFtcPix5UKwr9YNzW(u"ࠬࡢ࡮ࠨ࢛")+YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ๅอๆาࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮࠦ࠮࠯๋้ࠢั๊ฯࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠤ࠳࠴้ࠠ็ฯ่ิࠦวๅื๋ีࠥอไใัํ้ฮࠦ࠮࠯๋ࠢฮๆื๊฻่่ࠢๆࠦี้ำࠣห้หึศใสฮࠬ࢜")+Me28A1sBLNIgUp5YCDyvT(u"ࠧ࡝ࡰࠪ࢝")+g4g6bfkPtVGU5lIM3(u"ࠨมࠤࠥࠬ࢞")+iUeoLOsbHqP(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࢟"))
		if o07Z1tEB4n3ARCkVNu!=UTelCo0ihE1d5R(u"࠷ࣰ"): return
	OOy4gzCqrV382ctPa(kkoVHLuYW1yBUtq4dxnTwO5XFfeMP,iUeoLOsbHqP(u"ࡘࡷࡻࡥऑ"),iRoLg2m47tnDATBHGCSPNyx(u"ࡉࡥࡱࡹࡥऐ"))
	OOy4gzCqrV382ctPa(e7cHgraq6wUiOjDhk3sSxMK2nVLPA,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࡚ࡲࡶࡧओ"),SO94xq1RAkMm2uF(u"ࡋࡧ࡬ࡴࡧऒ"))
	OOy4gzCqrV382ctPa(KKRnGTPirdY,SO94xq1RAkMm2uF(u"ࡆࡢ࡮ࡶࡩऔ"),SO94xq1RAkMm2uF(u"ࡆࡢ࡮ࡶࡩऔ"))
	gJWRyKDkx3YHfMrj8(fJo0re3DEITGzuAXyd9F4,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࡇࡣ࡯ࡷࡪक"))
	if showDialogs:
		aHKzv76JCVnprbY8w(E6MIKdpBomef(u"ࠪࠫࢠ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠫࠬࢡ"),UTelCo0ihE1d5R(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࢢ"),lc0dpSmwoPDjLnk(u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧࢣ"))
		jHevARrF7lS.setSetting(FvNyZqaLKw(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫࢤ"),FvNyZqaLKw(u"ࠨࡕࡒࡑࡊ࡚ࡈࡊࡐࡊࠫࢥ"))
		cEZpW924rqNYm5.executebuiltin(p72fnFtcPix5UKwr9YNzW(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭ࢦ"))
	return
def ocYUR14dTItpVeDO(showDialogs):
	if showDialogs:
		o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࠫࢧ"),g4g6bfkPtVGU5lIM3(u"ࠫࠬࢨ"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠬ࠭ࢩ"),hBvsQ7oCkKUdwjx58ml3EN(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢪ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๊่ࠥะั๋ัุ้ࠣำࠠๆๆไหฯ࠭ࢫ")+wRxoKs10Syj7V4edYhtP(u"ࠨ࡞ࡱࠫࢬ")+SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠩࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸࠦ࠮࠯ࠢࡧࡶࡴࡶࡢࡰࡺࠣ࠲࠳ࠦࡴࡰ࡯ࡥࡷࡹࡵ࡮ࡦࡵࠣ࠲࠳ࠦ࡬ࡰࡩࡪࡩࡷࠦ࠮࠯ࠢ࡯ࡳ࡬ࠦ࠮࠯ࠢࡤࡲࡷ࠭ࢭ")+kEhAHvti6Vnsfx(u"ࠪࡠࡳ࠭ࢮ")+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࡄࠧࠡࠨࢯ")+E6MIKdpBomef(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࢰ"))
		if o07Z1tEB4n3ARCkVNu!=iUeoLOsbHqP(u"࠱ࣱ"): return
	OOy4gzCqrV382ctPa(Owg8PXCdkTSEAxQNhis7,iUeoLOsbHqP(u"ࡈࡤࡰࡸ࡫ख"),iUeoLOsbHqP(u"ࡈࡤࡰࡸ࡫ख"))
	OOy4gzCqrV382ctPa(DF6OeAQnZo3,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࡉࡥࡱࡹࡥग"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࡉࡥࡱࡹࡥग"))
	OOy4gzCqrV382ctPa(lz3dkoVg2vcr,hBvsQ7oCkKUdwjx58ml3EN(u"ࡊࡦࡲࡳࡦघ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࡊࡦࡲࡳࡦघ"))
	OOy4gzCqrV382ctPa(ifLMaW59VBnlg1rFKED6sA,SO94xq1RAkMm2uF(u"ࡋࡧ࡬ࡴࡧङ"),SO94xq1RAkMm2uF(u"ࡋࡧ࡬ࡴࡧङ"))
	OOy4gzCqrV382ctPa(KJd6zmGAxBF1NVr,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࡌࡡ࡭ࡵࡨच"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࡌࡡ࡭ࡵࡨच"))
	OOy4gzCqrV382ctPa(LkG6CstJw37dl,zqdvcbP5L8BHh(u"ࡆࡢ࡮ࡶࡩछ"),zqdvcbP5L8BHh(u"ࡆࡢ࡮ࡶࡩछ"))
	if showDialogs:
		aHKzv76JCVnprbY8w(SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࠧࢱ"),kEhAHvti6Vnsfx(u"ࠧࠨࢲ"),FvNyZqaLKw(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࢳ"),bUdr5Hahw6sY8xJ(u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪࢴ"))
		jHevARrF7lS.setSetting(dshJSmRqeiP9nap2(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧࢵ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧࢶ"))
		cEZpW924rqNYm5.executebuiltin(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩࢷ"))
	return
def gJWRyKDkx3YHfMrj8(U2gpeLZJrTRzYNvX0Fni3,showDialogs):
	if showDialogs:
		o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࠧࢸ"),Me28A1sBLNIgUp5YCDyvT(u"ࠧࠨࢹ"),p72fnFtcPix5UKwr9YNzW(u"ࠨࠩࢺ"),E6MIKdpBomef(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࢻ"),LiRcTVUWuth70DmPy(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ้ࠣาะ่๋ษอࠤ๊๊แࠡื๋ีࠥอไอๆาࠤฤࠧࠡࠨࢼ")+zqdvcbP5L8BHh(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࢽ"))
		if o07Z1tEB4n3ARCkVNu!=hBvsQ7oCkKUdwjx58ml3EN(u"࠲ࣲ"): return
	QAlb96UhsVG = j5cfNmnkuUA.connect(U2gpeLZJrTRzYNvX0Fni3)
	QAlb96UhsVG.text_factory = str
	PYRN3CLTut = QAlb96UhsVG.cursor()
	PYRN3CLTut.execute(FvNyZqaLKw(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡴࡦࡺࡨ࠼ࠩࢾ"))
	PYRN3CLTut.execute(XzrqbGDIy54juixkMA(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡸ࡯ࡺࡦࡵ࠾ࠫࢿ"))
	PYRN3CLTut.execute(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡺࡥࡹࡶࡸࡶࡪࡁࠧࣀ"))
	QAlb96UhsVG.commit()
	PYRN3CLTut.execute(FnBiAjthS8MkXs67W(u"ࠨࡘࡄࡇ࡚࡛ࡍ࠼ࠩࣁ"))
	QAlb96UhsVG.close()
	if showDialogs:
		aHKzv76JCVnprbY8w(g4g6bfkPtVGU5lIM3(u"ࠩࠪࣂ"),zqdvcbP5L8BHh(u"ࠪࠫࣃ"),lc0dpSmwoPDjLnk(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࣄ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ࣅ"))
		jHevARrF7lS.setSetting(dshJSmRqeiP9nap2(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࣆ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࡔࡑࡐࡉ࡙ࡎࡉࡏࡉࠪࣇ"))
		cEZpW924rqNYm5.executebuiltin(xW2Arao7YVOemw(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬࣈ"))
	return
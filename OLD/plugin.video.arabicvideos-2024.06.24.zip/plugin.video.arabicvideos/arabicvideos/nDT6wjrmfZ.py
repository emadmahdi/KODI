# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'IFILM'
mmDwMlfoHtG5XT19VLIWqCR8i = '_IFL_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
msL09WzMG3c86RAqkXpY7yn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][1]
HdWn38vFCz47 = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][2]
KYC0cOfQbPHhLnNkSaJ7WgrA = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][3]
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,text):
	if   mode==20: zpXG3Ky6ou8ndWHkb4 = xA6VcJtLipfKoe9TsP()
	elif mode==21: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY(url)
	elif mode==22: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif mode==23: zpXG3Ky6ou8ndWHkb4 = hWPvGlXZ5arzV7(url,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif mode==24: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url,text)
	elif mode==25: zpXG3Ky6ou8ndWHkb4 = yEhNJTuwdZmMHKBl9aiIF(url)
	elif mode==27: zpXG3Ky6ou8ndWHkb4 = jvAw2XIh981zBbtonQELUFmfdyiJa(url)
	elif mode==28: zpXG3Ky6ou8ndWHkb4 = X42OhcwkSfV3xtmj0liYRIgps()
	elif mode==29: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def xA6VcJtLipfKoe9TsP():
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'عربي',NBm2aWhPzoTpdYn,21,'','101')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'English',msL09WzMG3c86RAqkXpY7yn,21,'','101')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فارسى',HdWn38vFCz47,21,'','101')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فارسى 2',KYC0cOfQbPHhLnNkSaJ7WgrA,21,'','101')
	return
def X42OhcwkSfV3xtmj0liYRIgps():
	cd0aGwCPExbFU5pYNu8r('live',mmDwMlfoHtG5XT19VLIWqCR8i+'عربي',NBm2aWhPzoTpdYn,27)
	cd0aGwCPExbFU5pYNu8r('live',mmDwMlfoHtG5XT19VLIWqCR8i+'English',msL09WzMG3c86RAqkXpY7yn,27)
	cd0aGwCPExbFU5pYNu8r('live',mmDwMlfoHtG5XT19VLIWqCR8i+'فارسى',HdWn38vFCz47,27)
	cd0aGwCPExbFU5pYNu8r('live',mmDwMlfoHtG5XT19VLIWqCR8i+'فارسى 2',KYC0cOfQbPHhLnNkSaJ7WgrA,27)
	return
def T2AtWpmSuysJ3BzHVeFY(llnw2D4RFysMrHIPeCSg1K):
	cTJphS1nFz5EUgNWm86C = llnw2D4RFysMrHIPeCSg1K
	if llnw2D4RFysMrHIPeCSg1K=='IFILM-ARABIC': llnw2D4RFysMrHIPeCSg1K = NBm2aWhPzoTpdYn
	elif llnw2D4RFysMrHIPeCSg1K=='IFILM-ENGLISH': llnw2D4RFysMrHIPeCSg1K = msL09WzMG3c86RAqkXpY7yn
	else: cTJphS1nFz5EUgNWm86C = ''
	CCWfMt5XsOGPa = LJjtONKul68X4QT7(llnw2D4RFysMrHIPeCSg1K)
	if CCWfMt5XsOGPa=='ar' or cTJphS1nFz5EUgNWm86C=='IFILM-ARABIC':
		m24m5PSXjCOhfn39uaM0ZBqzgDLIo = 'بحث في الموقع'
		yCcvQk8BMijebJlaHfhgKux = 'مسلسلات - حالية'
		RuWUKQylsNvOH7SpiL59nYP3rA = 'مسلسلات - أحدث'
		Fpj0V3LCdlha = 'مسلسلات - أبجدي'
		ViPQT3Zv7UbXKjsh8yl2Erak = 'بث حي آي فيلم'
		hbM57i2vI69SztdlfEoR4GLJ0xWyUP = 'أفلام'
		EhDeMQ1Ic3fKpVlNz = 'موسيقى'
		m1M79bl8vZwg = 'برامج'
	elif CCWfMt5XsOGPa=='en' or cTJphS1nFz5EUgNWm86C=='IFILM-ENGLISH':
		m24m5PSXjCOhfn39uaM0ZBqzgDLIo = 'Search in site'
		yCcvQk8BMijebJlaHfhgKux = 'Series - Current'
		RuWUKQylsNvOH7SpiL59nYP3rA = 'Series - Latest'
		Fpj0V3LCdlha = 'Series - Alphabet'
		ViPQT3Zv7UbXKjsh8yl2Erak = 'Live iFilm channel'
		hbM57i2vI69SztdlfEoR4GLJ0xWyUP = 'Movies'
		EhDeMQ1Ic3fKpVlNz = 'Music'
		m1M79bl8vZwg = 'Shows'
	elif CCWfMt5XsOGPa in ['fa','fa2']:
		m24m5PSXjCOhfn39uaM0ZBqzgDLIo = 'جستجو در سایت'
		yCcvQk8BMijebJlaHfhgKux = 'سريال - جاری'
		RuWUKQylsNvOH7SpiL59nYP3rA = 'سريال - آخرین'
		Fpj0V3LCdlha = 'سريال - الفبا'
		ViPQT3Zv7UbXKjsh8yl2Erak = 'پخش زنده اي فيلم'
		hbM57i2vI69SztdlfEoR4GLJ0xWyUP = 'فيلم'
		EhDeMQ1Ic3fKpVlNz = 'موسيقى'
		m1M79bl8vZwg = 'برنامه ها'
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+m24m5PSXjCOhfn39uaM0ZBqzgDLIo,llnw2D4RFysMrHIPeCSg1K,29,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('live',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+ViPQT3Zv7UbXKjsh8yl2Erak,llnw2D4RFysMrHIPeCSg1K,27)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	qERDVNWvZzbf9O8sXCxi = ['Series','Program','Music']
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,llnw2D4RFysMrHIPeCSg1K+'/home','','','','IFILM-MENU-1st')
	EeQqAGc0W5r6nlBbChwfZL=GGvHJKP9LUxEk10Fw.findall('button-menu(.*?)/Contact',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			if any(hieW1zRUG5w9AykJjv0X in ELbNB92cOh5dqtpVmi40kY for hieW1zRUG5w9AykJjv0X in qERDVNWvZzbf9O8sXCxi):
				url = llnw2D4RFysMrHIPeCSg1K+ELbNB92cOh5dqtpVmi40kY
				if 'Series' in ELbNB92cOh5dqtpVmi40kY:
					cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+yCcvQk8BMijebJlaHfhgKux,url,22,'','100')
					cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+RuWUKQylsNvOH7SpiL59nYP3rA,url,22,'','101')
					cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+Fpj0V3LCdlha,url,22,'','201')
				elif 'Film' in ELbNB92cOh5dqtpVmi40kY: cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+hbM57i2vI69SztdlfEoR4GLJ0xWyUP,url,22,'','100')
				elif 'Music' in ELbNB92cOh5dqtpVmi40kY: cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+EhDeMQ1Ic3fKpVlNz,url,25,'','101')
				elif 'Program' in ELbNB92cOh5dqtpVmi40kY: cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+m1M79bl8vZwg,url,22,'','101')
	return BBlXpmUyhFDwNtCVAHoE
def yEhNJTuwdZmMHKBl9aiIF(url):
	llnw2D4RFysMrHIPeCSg1K = X9QCHNBT3Ae7jJptYV0(url)
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,url,'','','','IFILM-MUSIC_MENU-1st')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('Music-tools-header(.*?)Music-body',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	title = GGvHJKP9LUxEk10Fw.findall('<p>(.*?)</p>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)[0]
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,22,'','101')
	items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		ELbNB92cOh5dqtpVmi40kY = llnw2D4RFysMrHIPeCSg1K + ELbNB92cOh5dqtpVmi40kY
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,23,'','101')
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(url,EfNzW3kLhcMTu07HrP28X9nFA6vpGd):
	llnw2D4RFysMrHIPeCSg1K = X9QCHNBT3Ae7jJptYV0(url)
	CCWfMt5XsOGPa = LJjtONKul68X4QT7(url)
	type = url.split('/')[-1]
	sxrFuSfgqO4NwaBDvEh = str(int(EfNzW3kLhcMTu07HrP28X9nFA6vpGd)//100)
	EfNzW3kLhcMTu07HrP28X9nFA6vpGd = str(int(EfNzW3kLhcMTu07HrP28X9nFA6vpGd)%100)
	if type=='Series' and EfNzW3kLhcMTu07HrP28X9nFA6vpGd=='0':
		BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,url,'','','','IFILM-TITLES-1st')
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('serial-body(.*?)class="row',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
			title = ptMqV54oKJhQ8CH(title)
			title = DwNC3gEonizsB6a0v1F(title)
			ELbNB92cOh5dqtpVmi40kY = llnw2D4RFysMrHIPeCSg1K + ELbNB92cOh5dqtpVmi40kY
			VFqpJjRySZvgi = llnw2D4RFysMrHIPeCSg1K + mGfdCk4Hyclg9RjD(VFqpJjRySZvgi)
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,23,VFqpJjRySZvgi,sxrFuSfgqO4NwaBDvEh+'01')
	f4fdwQ9BLjDt1PZvRps6=0
	if type=='Series': BBskpK6cGZJ='3'
	if type=='Film': BBskpK6cGZJ='5'
	if type=='Program': BBskpK6cGZJ='7'
	if type in ['Series','Program','Film'] and EfNzW3kLhcMTu07HrP28X9nFA6vpGd!='0':
		dR2vHyAtl8pJN1 = llnw2D4RFysMrHIPeCSg1K+'/Home/PageingItem?category='+BBskpK6cGZJ+'&page='+EfNzW3kLhcMTu07HrP28X9nFA6vpGd+'&size=30&orderby='+sxrFuSfgqO4NwaBDvEh
		BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,dR2vHyAtl8pJN1,'','','','IFILM-TITLES-2nd')
		items = GGvHJKP9LUxEk10Fw.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		for id,title,VFqpJjRySZvgi in items:
			title = ptMqV54oKJhQ8CH(title)
			title = title.replace('\\','')
			title = title.replace('"','')
			f4fdwQ9BLjDt1PZvRps6 += 1
			ELbNB92cOh5dqtpVmi40kY = llnw2D4RFysMrHIPeCSg1K + '/' + type + '/Content/' + id
			VFqpJjRySZvgi = llnw2D4RFysMrHIPeCSg1K + mGfdCk4Hyclg9RjD(VFqpJjRySZvgi)
			if type=='Film': cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,24,VFqpJjRySZvgi,sxrFuSfgqO4NwaBDvEh+'01')
			else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,23,VFqpJjRySZvgi,sxrFuSfgqO4NwaBDvEh+'01')
	if type=='Music':
		BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,llnw2D4RFysMrHIPeCSg1K+'/Music/Index?page='+EfNzW3kLhcMTu07HrP28X9nFA6vpGd,'','','','IFILM-TITLES-3rd')
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('pagination-demo(.*?)pagination-demo',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
			f4fdwQ9BLjDt1PZvRps6 += 1
			VFqpJjRySZvgi = llnw2D4RFysMrHIPeCSg1K + VFqpJjRySZvgi
			ELbNB92cOh5dqtpVmi40kY = llnw2D4RFysMrHIPeCSg1K + ELbNB92cOh5dqtpVmi40kY
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,23,VFqpJjRySZvgi,'101')
	if f4fdwQ9BLjDt1PZvRps6>20:
		title='صفحة '
		if CCWfMt5XsOGPa=='en': title = 'Page '
		if CCWfMt5XsOGPa=='fa': title = 'صفحه '
		if CCWfMt5XsOGPa=='fa2': title = 'صفحه '
		for FI8HhGAfbMi6EN7OJWnoPu3m9zRV in range(1,11) :
			if not EfNzW3kLhcMTu07HrP28X9nFA6vpGd==str(FI8HhGAfbMi6EN7OJWnoPu3m9zRV):
				qq8bQag3W7yoxcHptvBZu1I0hiN = '0'+str(FI8HhGAfbMi6EN7OJWnoPu3m9zRV)
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title+str(FI8HhGAfbMi6EN7OJWnoPu3m9zRV),url,22,'',sxrFuSfgqO4NwaBDvEh+qq8bQag3W7yoxcHptvBZu1I0hiN[-2:])
	return
def hWPvGlXZ5arzV7(url,EfNzW3kLhcMTu07HrP28X9nFA6vpGd):
	if not EfNzW3kLhcMTu07HrP28X9nFA6vpGd: EfNzW3kLhcMTu07HrP28X9nFA6vpGd = 0
	llnw2D4RFysMrHIPeCSg1K = X9QCHNBT3Ae7jJptYV0(url)
	AIdwORPiKbz01tHaxB5vhUDfF = X9QCHNBT3Ae7jJptYV0(url)
	CCWfMt5XsOGPa = LJjtONKul68X4QT7(url)
	Z0HoXM261lLgxBzjUK = url.split('/')
	id,type = Z0HoXM261lLgxBzjUK[-1],Z0HoXM261lLgxBzjUK[3]
	sxrFuSfgqO4NwaBDvEh = str(int(EfNzW3kLhcMTu07HrP28X9nFA6vpGd)//100)
	EfNzW3kLhcMTu07HrP28X9nFA6vpGd = str(int(EfNzW3kLhcMTu07HrP28X9nFA6vpGd)%100)
	f4fdwQ9BLjDt1PZvRps6 = 0
	if type=='Series':
		BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,url,'','','','IFILM-EPISODES-1st')
		items = GGvHJKP9LUxEk10Fw.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		title = ' - الحلقة '
		if CCWfMt5XsOGPa=='en': title = ' - Episode '
		if CCWfMt5XsOGPa=='fa': title = ' - قسمت '
		if CCWfMt5XsOGPa=='fa2': title = ' - قسمت '
		if CCWfMt5XsOGPa=='fa': RDXB1i2flOgs = ''
		else: RDXB1i2flOgs = CCWfMt5XsOGPa
		RQ2jr3OloGfvABN4MJIdkEgZuq86ae = GGvHJKP9LUxEk10Fw.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		for name,count,VFqpJjRySZvgi,ELbNB92cOh5dqtpVmi40kY in items:
			for qUGxSK2VwsiBAdkDZnJ605vQeg in range(int(count),0,-1):
				BlgMbHN1WC754 = VFqpJjRySZvgi + RDXB1i2flOgs + id + '/' + str(qUGxSK2VwsiBAdkDZnJ605vQeg) + '.png'
				yCcvQk8BMijebJlaHfhgKux = name + title + str(qUGxSK2VwsiBAdkDZnJ605vQeg)
				yCcvQk8BMijebJlaHfhgKux = DwNC3gEonizsB6a0v1F(yCcvQk8BMijebJlaHfhgKux)
				cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+yCcvQk8BMijebJlaHfhgKux,url,24,BlgMbHN1WC754,'',str(qUGxSK2VwsiBAdkDZnJ605vQeg))
	elif type=='Program':
		dR2vHyAtl8pJN1 = llnw2D4RFysMrHIPeCSg1K+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+EfNzW3kLhcMTu07HrP28X9nFA6vpGd+'&size=30&orderby=1'
		BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,dR2vHyAtl8pJN1,'','','','IFILM-EPISODES-2nd')
		items = GGvHJKP9LUxEk10Fw.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		title = ' - الحلقة '
		if CCWfMt5XsOGPa=='en': title = ' - Episode '
		if CCWfMt5XsOGPa=='fa': title = ' - قسمت '
		if CCWfMt5XsOGPa=='fa2': title = ' - قسمت '
		for qUGxSK2VwsiBAdkDZnJ605vQeg,VFqpJjRySZvgi,ELbNB92cOh5dqtpVmi40kY,KKgnkvZw9YMAbN,name in items:
			f4fdwQ9BLjDt1PZvRps6 += 1
			BlgMbHN1WC754 = AIdwORPiKbz01tHaxB5vhUDfF + mGfdCk4Hyclg9RjD(VFqpJjRySZvgi)
			name = ptMqV54oKJhQ8CH(name)
			yCcvQk8BMijebJlaHfhgKux = name + title + str(qUGxSK2VwsiBAdkDZnJ605vQeg)
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+yCcvQk8BMijebJlaHfhgKux,dR2vHyAtl8pJN1,24,BlgMbHN1WC754,'',str(f4fdwQ9BLjDt1PZvRps6))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			dR2vHyAtl8pJN1 = llnw2D4RFysMrHIPeCSg1K+'/Music/GetTracksBy?id='+str(id)+'&page='+EfNzW3kLhcMTu07HrP28X9nFA6vpGd+'&size=30&type=0'
			BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,dR2vHyAtl8pJN1,'','','','IFILM-EPISODES-3rd')
			items = GGvHJKP9LUxEk10Fw.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
			for VFqpJjRySZvgi,ELbNB92cOh5dqtpVmi40kY,name,title in items:
				f4fdwQ9BLjDt1PZvRps6 += 1
				BlgMbHN1WC754 = AIdwORPiKbz01tHaxB5vhUDfF + mGfdCk4Hyclg9RjD(VFqpJjRySZvgi)
				yCcvQk8BMijebJlaHfhgKux = name + ' - ' + title
				yCcvQk8BMijebJlaHfhgKux = yCcvQk8BMijebJlaHfhgKux.strip(' ')
				yCcvQk8BMijebJlaHfhgKux = ptMqV54oKJhQ8CH(yCcvQk8BMijebJlaHfhgKux)
				cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+yCcvQk8BMijebJlaHfhgKux,dR2vHyAtl8pJN1,24,BlgMbHN1WC754,'',str(f4fdwQ9BLjDt1PZvRps6))
		elif 'Clips' in url:
			dR2vHyAtl8pJN1 = llnw2D4RFysMrHIPeCSg1K+'/Music/GetTracksBy?id=0&page='+EfNzW3kLhcMTu07HrP28X9nFA6vpGd+'&size=30&type=15'
			BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,dR2vHyAtl8pJN1,'','','','IFILM-EPISODES-4th')
			items = GGvHJKP9LUxEk10Fw.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
			for VFqpJjRySZvgi,title,ELbNB92cOh5dqtpVmi40kY in items:
				f4fdwQ9BLjDt1PZvRps6 += 1
				BlgMbHN1WC754 = AIdwORPiKbz01tHaxB5vhUDfF + mGfdCk4Hyclg9RjD(VFqpJjRySZvgi)
				yCcvQk8BMijebJlaHfhgKux = title.strip(' ')
				yCcvQk8BMijebJlaHfhgKux = ptMqV54oKJhQ8CH(yCcvQk8BMijebJlaHfhgKux)
				cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+yCcvQk8BMijebJlaHfhgKux,dR2vHyAtl8pJN1,24,BlgMbHN1WC754,'',str(f4fdwQ9BLjDt1PZvRps6))
		elif 'category' in url:
			if 'category=6' in url:
				dR2vHyAtl8pJN1 = llnw2D4RFysMrHIPeCSg1K+'/Music/GetTracksBy?id=0&page='+EfNzW3kLhcMTu07HrP28X9nFA6vpGd+'&size=30&type=6'
				BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,dR2vHyAtl8pJN1,'','','','IFILM-EPISODES-5th')
			elif 'category=4' in url:
				dR2vHyAtl8pJN1 = llnw2D4RFysMrHIPeCSg1K+'/Music/GetTracksBy?id=0&page='+EfNzW3kLhcMTu07HrP28X9nFA6vpGd+'&size=30&type=4'
				BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,dR2vHyAtl8pJN1,'','','','IFILM-EPISODES-6th')
			items = GGvHJKP9LUxEk10Fw.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
			for VFqpJjRySZvgi,ELbNB92cOh5dqtpVmi40kY,name,title in items:
				f4fdwQ9BLjDt1PZvRps6 += 1
				BlgMbHN1WC754 = AIdwORPiKbz01tHaxB5vhUDfF + mGfdCk4Hyclg9RjD(VFqpJjRySZvgi)
				yCcvQk8BMijebJlaHfhgKux = name + ' - ' + title
				yCcvQk8BMijebJlaHfhgKux = yCcvQk8BMijebJlaHfhgKux.strip(' ')
				yCcvQk8BMijebJlaHfhgKux = ptMqV54oKJhQ8CH(yCcvQk8BMijebJlaHfhgKux)
				cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+yCcvQk8BMijebJlaHfhgKux,dR2vHyAtl8pJN1,24,BlgMbHN1WC754,'',str(f4fdwQ9BLjDt1PZvRps6))
	if type=='Music' or type=='Program':
		if f4fdwQ9BLjDt1PZvRps6>25:
			title='صفحة '
			if CCWfMt5XsOGPa=='en': title = ' Page '
			if CCWfMt5XsOGPa=='fa': title = ' صفحه '
			if CCWfMt5XsOGPa=='fa2': title = ' صفحه '
			for FI8HhGAfbMi6EN7OJWnoPu3m9zRV in range(1,11):
				if not EfNzW3kLhcMTu07HrP28X9nFA6vpGd==str(FI8HhGAfbMi6EN7OJWnoPu3m9zRV):
					qq8bQag3W7yoxcHptvBZu1I0hiN = '0'+str(FI8HhGAfbMi6EN7OJWnoPu3m9zRV)
					cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title+str(FI8HhGAfbMi6EN7OJWnoPu3m9zRV),url,23,'',sxrFuSfgqO4NwaBDvEh+qq8bQag3W7yoxcHptvBZu1I0hiN[-2:])
	return
def SUfe4unWoXBNFz90xqy(url,qUGxSK2VwsiBAdkDZnJ605vQeg):
	AIdwORPiKbz01tHaxB5vhUDfF = X9QCHNBT3Ae7jJptYV0(url)
	eyUmvNFiYsE,zzvBg3ShiamAZ = [],[]
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,url,'','','','IFILM-PLAY-1st')
	items = GGvHJKP9LUxEk10Fw.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if items:
		CCWfMt5XsOGPa = LJjtONKul68X4QT7(url)
		Z0HoXM261lLgxBzjUK = url.split('/')
		id,type = Z0HoXM261lLgxBzjUK[-1],Z0HoXM261lLgxBzjUK[3]
		ELbNB92cOh5dqtpVmi40kY = items[0][0]+CCWfMt5XsOGPa+id+'/,'+qUGxSK2VwsiBAdkDZnJ605vQeg+','+qUGxSK2VwsiBAdkDZnJ605vQeg+'_'+items[0][2]
		eyUmvNFiYsE.append('m3u8')
		zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	items = GGvHJKP9LUxEk10Fw.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if items:
		CCWfMt5XsOGPa = LJjtONKul68X4QT7(url)
		Z0HoXM261lLgxBzjUK = url.split('/')
		id,type = Z0HoXM261lLgxBzjUK[-1],Z0HoXM261lLgxBzjUK[3]
		ELbNB92cOh5dqtpVmi40kY = items[0][0]+CCWfMt5XsOGPa+id+'/'+qUGxSK2VwsiBAdkDZnJ605vQeg+items[0][2]
		eyUmvNFiYsE.append('mp4 url')
		zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	items = GGvHJKP9LUxEk10Fw.findall('source src="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY in items:
		ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.replace('//','/')
		eyUmvNFiYsE.append('mp4 src')
		zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	items = GGvHJKP9LUxEk10Fw.findall('VideoAddress":"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if items:
		ELbNB92cOh5dqtpVmi40kY = items[int(qUGxSK2VwsiBAdkDZnJ605vQeg)-1]
		ELbNB92cOh5dqtpVmi40kY = AIdwORPiKbz01tHaxB5vhUDfF+mGfdCk4Hyclg9RjD(ELbNB92cOh5dqtpVmi40kY)
		eyUmvNFiYsE.append('mp4 address')
		zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	items = GGvHJKP9LUxEk10Fw.findall('VoiceAddress":"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if items:
		ELbNB92cOh5dqtpVmi40kY = items[int(qUGxSK2VwsiBAdkDZnJ605vQeg)-1]
		ELbNB92cOh5dqtpVmi40kY = AIdwORPiKbz01tHaxB5vhUDfF+mGfdCk4Hyclg9RjD(ELbNB92cOh5dqtpVmi40kY)
		eyUmvNFiYsE.append('mp3 address')
		zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	if len(zzvBg3ShiamAZ)==1: ELbNB92cOh5dqtpVmi40kY = zzvBg3ShiamAZ[0]
	else:
		z0jyetbQwKrIclL9vJW = D1DJtzviFZSrA('اختر الفيديو المناسب:', eyUmvNFiYsE)
		if z0jyetbQwKrIclL9vJW == -1 : return
		ELbNB92cOh5dqtpVmi40kY = zzvBg3ShiamAZ[z0jyetbQwKrIclL9vJW]
	ICifW6hdKqxkAJ02XZgHysOwoV9Dc5(ELbNB92cOh5dqtpVmi40kY,cTJphS1nFz5EUgNWm86C,'video')
	return
def X9QCHNBT3Ae7jJptYV0(url):
	if NBm2aWhPzoTpdYn in url: jXPWwl4aH0OR9ILzMT5usS = NBm2aWhPzoTpdYn
	elif msL09WzMG3c86RAqkXpY7yn in url: jXPWwl4aH0OR9ILzMT5usS = msL09WzMG3c86RAqkXpY7yn
	elif HdWn38vFCz47 in url: jXPWwl4aH0OR9ILzMT5usS = HdWn38vFCz47
	elif KYC0cOfQbPHhLnNkSaJ7WgrA in url: jXPWwl4aH0OR9ILzMT5usS = KYC0cOfQbPHhLnNkSaJ7WgrA
	else: jXPWwl4aH0OR9ILzMT5usS = ''
	return jXPWwl4aH0OR9ILzMT5usS
def LJjtONKul68X4QT7(url):
	if   NBm2aWhPzoTpdYn in url: CCWfMt5XsOGPa = 'ar'
	elif msL09WzMG3c86RAqkXpY7yn in url: CCWfMt5XsOGPa = 'en'
	elif HdWn38vFCz47 in url: CCWfMt5XsOGPa = 'fa'
	elif KYC0cOfQbPHhLnNkSaJ7WgrA in url: CCWfMt5XsOGPa = 'fa2'
	else: CCWfMt5XsOGPa = ''
	return CCWfMt5XsOGPa
def jvAw2XIh981zBbtonQELUFmfdyiJa(url):
	CCWfMt5XsOGPa = LJjtONKul68X4QT7(url)
	dR2vHyAtl8pJN1 = url + '/Home/Live'
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',dR2vHyAtl8pJN1,'','','','','IFILM-LIVE-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	items = GGvHJKP9LUxEk10Fw.findall('source src="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	XwyU6PQgprMI0 = items[0]
	ICifW6hdKqxkAJ02XZgHysOwoV9Dc5(XwyU6PQgprMI0,cTJphS1nFz5EUgNWm86C,'live')
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if not search:
		search = yMRXZIpKxlSkaE6iCO()
		if not search: return
	aKRILTAj1HC5c = search.replace(' ','+')
	if showDialogs:
		hxtMO1r82E9lCj34NvqZISB = [ NBm2aWhPzoTpdYn , msL09WzMG3c86RAqkXpY7yn , HdWn38vFCz47 , KYC0cOfQbPHhLnNkSaJ7WgrA ]
		Y89Ig1NnB7SL4KJGPyXCQcdOoW = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		z0jyetbQwKrIclL9vJW = D1DJtzviFZSrA('اختر اللغة المناسبة:', Y89Ig1NnB7SL4KJGPyXCQcdOoW)
		if z0jyetbQwKrIclL9vJW == -1 : return
		website = hxtMO1r82E9lCj34NvqZISB[z0jyetbQwKrIclL9vJW]
	else:
		if '_IFILM-ARABIC_' in tY3Dfrp6cMKFj: website = NBm2aWhPzoTpdYn
		elif '_IFILM-ENGLISH_' in tY3Dfrp6cMKFj: website = msL09WzMG3c86RAqkXpY7yn
		else: website = ''
	if not website: return
	CCWfMt5XsOGPa = LJjtONKul68X4QT7(website)
	dR2vHyAtl8pJN1 = website + "/Home/Search?searchstring=" + aKRILTAj1HC5c
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,dR2vHyAtl8pJN1,'','','','IFILM-SEARCH-1st')
	items = GGvHJKP9LUxEk10Fw.findall('"ImageAddress_S":"(.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if items:
		for VFqpJjRySZvgi,BBskpK6cGZJ,id,title in items:
			if BBskpK6cGZJ in ['3','7']:
				title = title.replace('\\','')
				title = title.replace('"','')
				if BBskpK6cGZJ=='3':
					type = 'Series'
					if CCWfMt5XsOGPa=='ar': name = 'مسلسل : '
					elif CCWfMt5XsOGPa=='en': name = 'Series : '
					elif CCWfMt5XsOGPa=='fa': name = 'سريال ها : '
					elif CCWfMt5XsOGPa=='fa2': name = 'سريال ها : '
				elif BBskpK6cGZJ=='5':
					type = 'Film'
					if CCWfMt5XsOGPa=='ar': name = 'فيلم : '
					elif CCWfMt5XsOGPa=='en': name = 'Movie : '
					elif CCWfMt5XsOGPa=='fa': name = 'فيلم : '
					elif CCWfMt5XsOGPa=='fa2': name = 'فلم ها : '
				elif BBskpK6cGZJ=='7':
					type = 'Program'
					if CCWfMt5XsOGPa=='ar': name = 'برنامج : '
					elif CCWfMt5XsOGPa=='en': name = 'Program : '
					elif CCWfMt5XsOGPa=='fa': name = 'برنامه ها : '
					elif CCWfMt5XsOGPa=='fa2': name = 'برنامه ها : '
				title = name + title
				ELbNB92cOh5dqtpVmi40kY = website + '/' + type + '/Content/' + id
				VFqpJjRySZvgi = mGfdCk4Hyclg9RjD(VFqpJjRySZvgi)
				VFqpJjRySZvgi = website+VFqpJjRySZvgi
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,23,VFqpJjRySZvgi,'101')
	return
# -*- coding: utf-8 -*-
import sys as GGtWyVoJReUuEBCdAagiL1YXO8
ggqTOXpCEcQD68f3oxrKilaSvkdtN = GGtWyVoJReUuEBCdAagiL1YXO8.version_info [0] == 2
pQ14eMnbYBK0xGywR7SuFChJdONj6 = 2048
y65ArzSx9RZh = 7
def MUzuWiALbXp6w5 (TMw2a0zHkY9lcdIvLFZXrS):
	global ynv9hpqlRAJuN0gXrEscaoP5dMWYDO
	Icnd5Dq4krBK3iYg2xNZHF = ord (TMw2a0zHkY9lcdIvLFZXrS [-1])
	u05ustK47xXQZbyFerWTROY = TMw2a0zHkY9lcdIvLFZXrS [:-1]
	BXAu3ZJQ9IPLg7kiy4K06ha = Icnd5Dq4krBK3iYg2xNZHF % len (u05ustK47xXQZbyFerWTROY)
	nRXUw1Fg0DSrkYGL = u05ustK47xXQZbyFerWTROY [:BXAu3ZJQ9IPLg7kiy4K06ha] + u05ustK47xXQZbyFerWTROY [BXAu3ZJQ9IPLg7kiy4K06ha:]
	if ggqTOXpCEcQD68f3oxrKilaSvkdtN:
		sW7Qyn32Zidt5TE4w96 = unicode () .join ([unichr (ord (Lk9Jh0wu7aNAE) - pQ14eMnbYBK0xGywR7SuFChJdONj6 - (Ebxc6eiUkyVNfMBs3CRIOArQ4h + Icnd5Dq4krBK3iYg2xNZHF) % y65ArzSx9RZh) for Ebxc6eiUkyVNfMBs3CRIOArQ4h, Lk9Jh0wu7aNAE in enumerate (nRXUw1Fg0DSrkYGL)])
	else:
		sW7Qyn32Zidt5TE4w96 = str () .join ([chr (ord (Lk9Jh0wu7aNAE) - pQ14eMnbYBK0xGywR7SuFChJdONj6 - (Ebxc6eiUkyVNfMBs3CRIOArQ4h + Icnd5Dq4krBK3iYg2xNZHF) % y65ArzSx9RZh) for Ebxc6eiUkyVNfMBs3CRIOArQ4h, Lk9Jh0wu7aNAE in enumerate (nRXUw1Fg0DSrkYGL)])
	return eval (sW7Qyn32Zidt5TE4w96)
Cu1704YofAbr3QTm,oh5Ptv7RjM3qLk1eEZJbcVzKis4d,LiRcTVUWuth70DmPy=MUzuWiALbXp6w5,MUzuWiALbXp6w5,MUzuWiALbXp6w5
pq3Z6xaELn0NW7PgAeI1bCRwdu,UTelCo0ihE1d5R,Me28A1sBLNIgUp5YCDyvT=LiRcTVUWuth70DmPy,oh5Ptv7RjM3qLk1eEZJbcVzKis4d,Cu1704YofAbr3QTm
kEhAHvti6Vnsfx,g4g6bfkPtVGU5lIM3,E6MIKdpBomef=Me28A1sBLNIgUp5YCDyvT,UTelCo0ihE1d5R,pq3Z6xaELn0NW7PgAeI1bCRwdu
wRxoKs10Syj7V4edYhtP,yA5z6LIXBlo41PRVMY87wOisFp,iUeoLOsbHqP=E6MIKdpBomef,g4g6bfkPtVGU5lIM3,kEhAHvti6Vnsfx
iRoLg2m47tnDATBHGCSPNyx,xW2Arao7YVOemw,l30iT7pjzmXk8dvwSNyUR1aZO4tWh=iUeoLOsbHqP,yA5z6LIXBlo41PRVMY87wOisFp,wRxoKs10Syj7V4edYhtP
dshJSmRqeiP9nap2,FnBiAjthS8MkXs67W,FvNyZqaLKw=l30iT7pjzmXk8dvwSNyUR1aZO4tWh,xW2Arao7YVOemw,iRoLg2m47tnDATBHGCSPNyx
SO94xq1RAkMm2uF,bUdr5Hahw6sY8xJ,XzrqbGDIy54juixkMA=FvNyZqaLKw,FnBiAjthS8MkXs67W,dshJSmRqeiP9nap2
p72fnFtcPix5UKwr9YNzW,sTcr7iDp5eFt4RoLMhuwq1A,SyENPzdOon6uxcLXMhqb14aDlB9r=XzrqbGDIy54juixkMA,bUdr5Hahw6sY8xJ,SO94xq1RAkMm2uF
zqdvcbP5L8BHh,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF,lc0dpSmwoPDjLnk=SyENPzdOon6uxcLXMhqb14aDlB9r,sTcr7iDp5eFt4RoLMhuwq1A,p72fnFtcPix5UKwr9YNzW
QVZl0O8yUIzdGDTfYcn5H37uWmb2,hRNlWkwDitzVpbSO3TIdAm5YGjaZ,fprnld4CZo=lc0dpSmwoPDjLnk,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF,zqdvcbP5L8BHh
hBvsQ7oCkKUdwjx58ml3EN,G5DeRbUpFj8E9OtJLvlo2fWmZC,S4SOKF2QbBhjCd3RrVMuHIzE=fprnld4CZo,hRNlWkwDitzVpbSO3TIdAm5YGjaZ,QVZl0O8yUIzdGDTfYcn5H37uWmb2
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = zqdvcbP5L8BHh(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫṍ")
PsebiIt1mulCAcEBXpJUj7 = []
headers = {LiRcTVUWuth70DmPy(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭Ṏ"):SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪࠫṏ")}
uu3WeZljhRAMQEqfSPCdrLJig = [kEhAHvti6Vnsfx(u"ࠫࡆࡑࡗࡂࡏࠪṐ"),XzrqbGDIy54juixkMA(u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧṑ"),LiRcTVUWuth70DmPy(u"࠭ࡉࡇࡋࡏࡑࠬṒ"),dshJSmRqeiP9nap2(u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪṓ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪṔ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉࠬṕ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࡍࡕ࡚ࡖࠨṖ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫࡒ࠹ࡕࠨṗ")]
def YguVs5RJFwDK6X8E(uuIjMn1YTf687WlRcOmhq4G23H,source,type,url):
	if not uuIjMn1YTf687WlRcOmhq4G23H:
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪṘ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+FnBiAjthS8MkXs67W(u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡩ࡭ࡳࡪࡩ࡯ࡩࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࡳࠡࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭ṙ")+source+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧࠡ࡟ࠣࠤࠥࠦࡔࡺࡲࡨ࠾ࠥࡡࠠࠨṚ")+type+zqdvcbP5L8BHh(u"ࠨࠢࡠࠫṛ"))
		iDW9CpKe4fkPIYrF6AZ5zqQXox = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,UTelCo0ihE1d5R(u"ࠩࡧ࡭ࡨࡺࠧṜ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ṝ"),Me28A1sBLNIgUp5YCDyvT(u"ࠫࡘࡏࡔࡆࡕࡢࡉࡗࡘࡏࡓࡕࠪṞ"))
		POTvxkwYNAryisqKFe49uUElLGanmB = MQbODJoPV2w8TEAg4zXZdjLxSW.strftime(bUdr5Hahw6sY8xJ(u"࡙ࠬࠫ࠯ࠧࡰ࠲ࠪࡪࠠࠦࡊ࠽ࠩࡒ࠭ṟ"),MQbODJoPV2w8TEAg4zXZdjLxSW.gmtime(MMHpSTojGILfZXWeCOPyn4))
		WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej = POTvxkwYNAryisqKFe49uUElLGanmB,url
		key = source+SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࠠࠡࠢࠣࠫṠ")+mmn0lB2tFI7XTgVfESo+p72fnFtcPix5UKwr9YNzW(u"ࠧࠡࠢࠣࠤࠬṡ")+str(yMvF9GoTjhU5biA)
		LpdKxnIsY3Sy6qP = iUeoLOsbHqP(u"ࠨࠩṢ")
		if key not in list(iDW9CpKe4fkPIYrF6AZ5zqQXox.keys()): iDW9CpKe4fkPIYrF6AZ5zqQXox[key] = [WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej]
		else:
			if url not in str(iDW9CpKe4fkPIYrF6AZ5zqQXox[key]): iDW9CpKe4fkPIYrF6AZ5zqQXox[key].append(WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej)
			else: LpdKxnIsY3Sy6qP = fprnld4CZo(u"ࠩ࡟ࡲࠥํะศࠢส่ๆ๐ฯ๋๊้ࠣํา่ะࠢไ๎่ࠥวว็ฬࠤฬ๊แ๋ัํ์์อสࠡษ็ฮ๏ࠦไๆࠢอ฽๊๊ࠧṣ")
		vU0mKurMALYj2xdohIPn = G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠶ྪ")
		for key in list(iDW9CpKe4fkPIYrF6AZ5zqQXox.keys()):
			iDW9CpKe4fkPIYrF6AZ5zqQXox[key] = list(set(iDW9CpKe4fkPIYrF6AZ5zqQXox[key]))
			vU0mKurMALYj2xdohIPn += len(iDW9CpKe4fkPIYrF6AZ5zqQXox[key])
		aHKzv76JCVnprbY8w(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪࠫṤ"),g4g6bfkPtVGU5lIM3(u"ࠫࠬṥ"),wRxoKs10Syj7V4edYhtP(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨṦ"),g4g6bfkPtVGU5lIM3(u"࠭ไๅลึๅࠥอไษำ้ห๊าࠠๅ็ࠣ๎ัีࠠๆๆไหฯࠦวๅใํำ๏๎ࠧṧ")+LpdKxnIsY3Sy6qP+lc0dpSmwoPDjLnk(u"ࠧ࡝ࡰ࡟ࡲ๊ࠥไฺๆ่ࠤฬ๊ศา่ส้ั๊ࠦใ๊่ࠤอาๅฺࠢๅหห๋ษࠡสส่ๆ๐ฯ๋๊๊หฯࠦวๅฬํࠤ้๋๋ࠠฮาࠤ้ํวࠡ็็ๅฬะࠠโ์า๎ํ่ࠦิ๊ไࠤ๏฿ัืࠢ฼่๏้ࠠศๆหี๋อๅอࠢฦ๊ࠥะัิๆ๋ࠣีํࠠศๆๅหห๋ษࠡว็ํࠥอไๆสิ้ัูࠦ็ั่หࠥ๐ีษฯࠣ฽ิี็ศࠢ࠸ࠤๆ๐ฯ๋๊๊หฯ࠭Ṩ")+LiRcTVUWuth70DmPy(u"ࠨ࡞ࡱࡠࡳ࠭ṩ")+xW2Arao7YVOemw(u"ࠩ฼ำิࠦวๅใํำ๏๎็ศฬࠣๅ๏ࠦวๅไสส๊ฯࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠬṪ")+str(vU0mKurMALYj2xdohIPn))
		if vU0mKurMALYj2xdohIPn>=yA5z6LIXBlo41PRVMY87wOisFp(u"࠵ྫ"):
			o07Z1tEB4n3ARCkVNu = ggi4vBsqHDArM1(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠪࠫṫ"),xW2Arao7YVOemw(u"ࠫࠬṬ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬ࠭ṭ"),Cu1704YofAbr3QTm(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩṮ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠧศๆหี๋อๅอࠢฯ้฾ࠦโศศ่อࠥ็๊่ษࠣ࠹ࠥ็๊ะ์๋๋ฬะࠠๅ็ࠣ๎ัีࠠศๆหี๋อๅอࠢ็๋ฬࠦๅๅใสฮࠥ็๊ะ์๋ࠤ࠳࠴ࠠิ๊ไࠤ๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢหุ้ำ่ࠠา๊ࠤฬ๊โศศ่อࠥࡢ࡮࡝ࡰ๋้ࠣࠦสา์าࠤสืำศๆ๋ࠣีํࠠศๆๅหห๋ษࠡไห่๋ࠥำฮ้สࠤส๊้ࠡษ็้อืๅอࠢ็็๏๊ࠦใ๊่ࠤฬ๊ๅษำ่ะࠥฮแฮื๋ࠣีํࠠศๆไ๎ิ๐่่ษอࠤฤࠧࠡࠨṯ"))
			if o07Z1tEB4n3ARCkVNu==yA5z6LIXBlo41PRVMY87wOisFp(u"࠲ྫྷ"):
				XAP2xv0SYMCHuL3Ow = SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࠩṰ")
				for key in list(iDW9CpKe4fkPIYrF6AZ5zqQXox.keys()):
					XAP2xv0SYMCHuL3Ow += Me28A1sBLNIgUp5YCDyvT(u"ࠩ࡟ࡲࠬṱ")+key
					QCoJqbswHjiI = sorted(iDW9CpKe4fkPIYrF6AZ5zqQXox[key],reverse=Cu1704YofAbr3QTm(u"ࡆࡢ࡮ࡶࡩᅁ"),key=lambda uysiIXhqMnljaEtG3fRH: uysiIXhqMnljaEtG3fRH[QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠲ྭ")])
					for POTvxkwYNAryisqKFe49uUElLGanmB,url in QCoJqbswHjiI:
						XAP2xv0SYMCHuL3Ow += pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠪࡠࡳ࠭Ṳ")+POTvxkwYNAryisqKFe49uUElLGanmB+xW2Arao7YVOemw(u"ࠫࠥࠦࠠࠡࠩṳ")+GhPlajzTxY8(url)
					XAP2xv0SYMCHuL3Ow += FvNyZqaLKw(u"ࠬࡢ࡮࡝ࡰࠪṴ")
				import WWXqeaw1TE
				Tr8iRxJmbcEhftU5DSHzA = WWXqeaw1TE.StXADUfOBwG413slo8VkK(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠭ࡖࡪࡦࡨࡳࡸ࠭ṵ"),fprnld4CZo(u"ࠧࠨṶ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࡇࡣ࡯ࡷࡪᅂ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠨࠩṷ"),p72fnFtcPix5UKwr9YNzW(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡖࡌࡂ࡛ࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭Ṹ"),LiRcTVUWuth70DmPy(u"ࠪࠫṹ"),XAP2xv0SYMCHuL3Ow)
				if Tr8iRxJmbcEhftU5DSHzA: aHKzv76JCVnprbY8w(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࠬṺ"),LiRcTVUWuth70DmPy(u"ࠬ࠭ṻ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩṼ"),LiRcTVUWuth70DmPy(u"ࠧห็ࠣห้หัิษ็ࠤอ์ฬศฯࠪṽ"))
				else: aHKzv76JCVnprbY8w(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠨࠩṾ"),FvNyZqaLKw(u"ࠩࠪṿ"),bUdr5Hahw6sY8xJ(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭Ẁ"),UTelCo0ihE1d5R(u"ࠫๆฺไหࠢ฼้้๐ษࠡษ็ษึูวๅࠩẁ"))
			if o07Z1tEB4n3ARCkVNu!=-sTcr7iDp5eFt4RoLMhuwq1A(u"࠴ྮ"):
				iDW9CpKe4fkPIYrF6AZ5zqQXox = {}
				HHg0f8U75SdzxEcbt1JN(UkFh2OXjuTZEaexC,FvNyZqaLKw(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨẂ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭ࡓࡊࡖࡈࡗࡤࡋࡒࡓࡑࡕࡗࠬẃ"))
		if iDW9CpKe4fkPIYrF6AZ5zqQXox: Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪẄ"),iRoLg2m47tnDATBHGCSPNyx(u"ࠨࡕࡌࡘࡊ࡙࡟ࡆࡔࡕࡓࡗ࡙ࠧẅ"),iDW9CpKe4fkPIYrF6AZ5zqQXox,GOhVkMATsg4cJmfa0Enp6zSqCr)
		return
	uuIjMn1YTf687WlRcOmhq4G23H = list(set(uuIjMn1YTf687WlRcOmhq4G23H))
	eyUmvNFiYsE,zzvBg3ShiamAZ = hntfj5cOUKGbrp(uuIjMn1YTf687WlRcOmhq4G23H,source)
	MuoKBqT7xz4a90N6X83 = str(zzvBg3ShiamAZ).count(FnBiAjthS8MkXs67W(u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪẆ"))
	q4qUGeTFzuKp8A5mSdZEvitP6Vc0 = str(zzvBg3ShiamAZ).count(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧẇ"))
	gzRbOLMG1ncuBPNeX3p = len(zzvBg3ShiamAZ)-MuoKBqT7xz4a90N6X83-q4qUGeTFzuKp8A5mSdZEvitP6Vc0
	Vqcf7bOFsYHG = lc0dpSmwoPDjLnk(u"ฺ๊ࠫว่ัฬ࠾ࠬẈ")+str(MuoKBqT7xz4a90N6X83)+S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠬࠦࠠࠡࠢอั๊๐ไ࠻ࠩẉ")+str(q4qUGeTFzuKp8A5mSdZEvitP6Vc0)+iRoLg2m47tnDATBHGCSPNyx(u"࠭ࠠࠡࠢࠣวำื้࠻ࠩẊ")+str(gzRbOLMG1ncuBPNeX3p)
	if not zzvBg3ShiamAZ: IJuVYdzmgy1AUtiKGfqWcv,svejmhZS0t24bAiYuzk = YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫẋ"),UTelCo0ihE1d5R(u"ࠨࠩẌ")
	else:
		add = LiRcTVUWuth70DmPy(u"࠴ྯ")
		if not any(hieW1zRUG5w9AykJjv0X in source for hieW1zRUG5w9AykJjv0X in uu3WeZljhRAMQEqfSPCdrLJig):
			add = zqdvcbP5L8BHh(u"࠶ྰ")
			zzvBg3ShiamAZ = [UTelCo0ihE1d5R(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡢࡅࡑࡒ࡟ࡍࡋࡑࡏࡘ࠭ẍ")]+list(zzvBg3ShiamAZ)
			eyUmvNFiYsE = [fprnld4CZo(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ็อึࠢฯ้๏฿ࠠศๆึ๎ึ็ัศฬ࡞࠳ࡈࡕࡌࡐࡔࡠࠫẎ")]+list(eyUmvNFiYsE)
		while XzrqbGDIy54juixkMA(u"ࡖࡵࡹࡪᅃ"):
			svejmhZS0t24bAiYuzk,IJuVYdzmgy1AUtiKGfqWcv = YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠫࠬẏ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠬ࠭Ẑ")
			if add and len(zzvBg3ShiamAZ)==oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠲ྲ"): z0jyetbQwKrIclL9vJW = xW2Arao7YVOemw(u"࠷ྱ")
			else: z0jyetbQwKrIclL9vJW = D1DJtzviFZSrA(Vqcf7bOFsYHG,eyUmvNFiYsE)
			if z0jyetbQwKrIclL9vJW==-Cu1704YofAbr3QTm(u"࠲ླ"): IJuVYdzmgy1AUtiKGfqWcv = LiRcTVUWuth70DmPy(u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠳ࡶࡸࡤࡳࡥ࡯ࡷࠪẑ")
			elif add and z0jyetbQwKrIclL9vJW==G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠲ྴ"):
				IJuVYdzmgy1AUtiKGfqWcv = iUeoLOsbHqP(u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࡡ࠵ࡲࡩࡥ࡭ࡦࡰࡸࠫẒ")
				zpXG3Ky6ou8ndWHkb4 = qojxlrHzfeaZwEYnFyi0t(eyUmvNFiYsE[add:],zzvBg3ShiamAZ[add:],source)
				if zpXG3Ky6ou8ndWHkb4:
					rK02twfigsv = []
					for Cyh9cRvbUW,vZx9XQFNgIby,wTy18cJ4YkhDaFpUlSsPMQnvW,tcpxFN9D0SMhr2OJXBfI5C1,x3xgNfCckZlGe8vWJ4m in zpXG3Ky6ou8ndWHkb4:
						if x3xgNfCckZlGe8vWJ4m: rK02twfigsv.append((Cyh9cRvbUW,vZx9XQFNgIby,wTy18cJ4YkhDaFpUlSsPMQnvW,tcpxFN9D0SMhr2OJXBfI5C1,x3xgNfCckZlGe8vWJ4m))
					if rK02twfigsv: eyUmvNFiYsE,zzvBg3ShiamAZ,errors,xut3LAibydXZnzkpBaKOsgew70,gI487voLsArVqW6Ffp = zip(*rK02twfigsv)
					else:
						aHKzv76JCVnprbY8w(p72fnFtcPix5UKwr9YNzW(u"ࠨࠩẓ"),XzrqbGDIy54juixkMA(u"ࠩࠪẔ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ẕ"),xW2Arao7YVOemw(u"้๊ࠫริใ่๊๊ࠣࠦห็ࠣษ๏าวะࠢึ๎ึ็ัศฬࠣะ๏ีษࠡใํࠤ์ึวࠡษ็ๅ๏ี๊้ࠢ࠱࠲ࠥำว้ๆࠣว๋ࠦสษฯฮࠤ฾์่ࠠาสࠤฬ๊แ๋ัํ์ࠥ็๊ࠡ็๋ห็฿ࠠฤะิํࠬẖ"))
						IJuVYdzmgy1AUtiKGfqWcv = E6MIKdpBomef(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬẗ")
						break
					Vqcf7bOFsYHG = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭วๅีํีๆืวหࠢส่ั๐ฯสࠢࠫࠤࠬẘ")+str(len(zzvBg3ShiamAZ))+FnBiAjthS8MkXs67W(u"ࠧࠡࠫࠪẙ")
					add = iUeoLOsbHqP(u"࠳ྵ")
					continue
			else:
				zpXG3Ky6ou8ndWHkb4 = qojxlrHzfeaZwEYnFyi0t([eyUmvNFiYsE[z0jyetbQwKrIclL9vJW]],[zzvBg3ShiamAZ[z0jyetbQwKrIclL9vJW]],source)
				if zpXG3Ky6ou8ndWHkb4:
					title,ELbNB92cOh5dqtpVmi40kY,errors,xut3LAibydXZnzkpBaKOsgew70,gI487voLsArVqW6Ffp = zpXG3Ky6ou8ndWHkb4[E6MIKdpBomef(u"࠴ྶ")]
					if not gI487voLsArVqW6Ffp and not any(hieW1zRUG5w9AykJjv0X in source for hieW1zRUG5w9AykJjv0X in uu3WeZljhRAMQEqfSPCdrLJig):
						errors,xut3LAibydXZnzkpBaKOsgew70,gI487voLsArVqW6Ffp = ixWp9hHqkbJ(title,ELbNB92cOh5dqtpVmi40kY,source,S4SOKF2QbBhjCd3RrVMuHIzE(u"࠵ྷ"))
						if errors==hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ẚ"): return errors
					if p72fnFtcPix5UKwr9YNzW(u"ࠩึ๎ึ็ัࠨẛ") in title and wRxoKs10Syj7V4edYhtP(u"ࠪ࠶๊า็้ๆ࠵ࠫẜ") in title:
						LOHZ4o9m7p6ebfTYXGIdz5PWs3q(E6MIKdpBomef(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩẝ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+SO94xq1RAkMm2uF(u"ࠬࠦࠠࠡࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡶࡩࡱ࡫ࡣࡵࡧࡧࠤࡸ࡫ࡲࡷࡧࡵࠤࠥࠦࡓࡦࡴࡹࡩࡷࡀࠠ࡜ࠢࠪẞ")+title+bUdr5Hahw6sY8xJ(u"࠭ࠠ࡞ࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪẟ")+ELbNB92cOh5dqtpVmi40kY+p72fnFtcPix5UKwr9YNzW(u"ࠧࠡ࡟ࠪẠ"))
						import WWXqeaw1TE
						WWXqeaw1TE.xpGg082CRzFKyBklQebhI()
						IJuVYdzmgy1AUtiKGfqWcv = Me28A1sBLNIgUp5YCDyvT(u"ࠨࡷࡱࡶࡪࡹ࡯࡭ࡸࡨࡨࠬạ")
					else:
						IJuVYdzmgy1AUtiKGfqWcv,svejmhZS0t24bAiYuzk,gCitSRH90rUG5s72VIBcaMQv8qpf = wV9txGTDFZN(title,ELbNB92cOh5dqtpVmi40kY,errors,xut3LAibydXZnzkpBaKOsgew70,gI487voLsArVqW6Ffp,source,type)
			if IJuVYdzmgy1AUtiKGfqWcv in [yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧẢ"),g4g6bfkPtVGU5lIM3(u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬả"),xW2Arao7YVOemw(u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬẤ"),fprnld4CZo(u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭ấ"),iRoLg2m47tnDATBHGCSPNyx(u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠳ࡶࡸࡤࡳࡥ࡯ࡷࠪẦ")] or len(zzvBg3ShiamAZ)==hBvsQ7oCkKUdwjx58ml3EN(u"࠷ྸ")+add: break
			elif IJuVYdzmgy1AUtiKGfqWcv in [Me28A1sBLNIgUp5YCDyvT(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧầ"),bUdr5Hahw6sY8xJ(u"ࠨࡶ࡬ࡱࡪࡵࡵࡵࠩẨ"),kEhAHvti6Vnsfx(u"ࠩࡷࡶ࡮࡫ࡤࠨẩ")]: break
			elif IJuVYdzmgy1AUtiKGfqWcv not in [SO94xq1RAkMm2uF(u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࡤ࠸࡮ࡥࡡࡰࡩࡳࡻࠧẪ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠫ࡭ࡺࡴࡱࡵࠪẫ")]:
				if hBvsQ7oCkKUdwjx58ml3EN(u"ࠬࡢ࡮ࠨẬ") in svejmhZS0t24bAiYuzk: svejmhZS0t24bAiYuzk = lc0dpSmwoPDjLnk(u"࡛࠭ࡍࡇࡉࡘࡢࠦࠠࠨậ")+svejmhZS0t24bAiYuzk.replace(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠧ࡝ࡰࠪẮ"),SO94xq1RAkMm2uF(u"ࠨ࡞ࡱ࡟ࡑࡋࡆࡕ࡟ࠣࠤࠬắ"))
				aHKzv76JCVnprbY8w(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩࠪẰ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࠫằ"),lc0dpSmwoPDjLnk(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧẲ"),iUeoLOsbHqP(u"ࠬอไิ์ิๅึࠦไๆࠢํ฽๊๊ࠠอำหࠤุ๐ัโำࠣ฾๏ื็ࠨẳ")+yA5z6LIXBlo41PRVMY87wOisFp(u"࠭࡜࡯ࠩẴ")+svejmhZS0t24bAiYuzk,profile=FnBiAjthS8MkXs67W(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠ࡯ࡨࡨ࡮ࡻ࡭ࡧࡱࡱࡸࠬẵ"))
	if IJuVYdzmgy1AUtiKGfqWcv==FnBiAjthS8MkXs67W(u"ࠨࡷࡱࡶࡪࡹ࡯࡭ࡸࡨࡨࠬẶ") and len(eyUmvNFiYsE)>hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠰ྐྵ"): aHKzv76JCVnprbY8w(fprnld4CZo(u"ࠩࠪặ"),lc0dpSmwoPDjLnk(u"ࠪࠫẸ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧẹ"),UTelCo0ihE1d5R(u"ู๊ࠬาใิࠤ์ึวࠡษ็ๅ๏ี๊้ࠢ็้ࠥ๐ูๆๆࠣะึฮࠠโ์า๎ํฺ๋ࠦำ๊ࠫẺ")+FnBiAjthS8MkXs67W(u"࠭࡜࡯ࠩẻ")+svejmhZS0t24bAiYuzk,profile=wRxoKs10Syj7V4edYhtP(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠ࡯ࡨࡨ࡮ࡻ࡭ࡧࡱࡱࡸࠬẼ"))
	elif IJuVYdzmgy1AUtiKGfqWcv in [SO94xq1RAkMm2uF(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨẽ"),xW2Arao7YVOemw(u"ࠩࡷ࡭ࡲ࡫࡯ࡶࡶࠪẾ")] and svejmhZS0t24bAiYuzk!=wRxoKs10Syj7V4edYhtP(u"ࠪࠫế"): aHKzv76JCVnprbY8w(g4g6bfkPtVGU5lIM3(u"ࠫࠬỀ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬ࠭ề"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩỂ"),svejmhZS0t24bAiYuzk,profile=sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠ࡯ࡨࡨ࡮ࡻ࡭ࡧࡱࡱࡸࠬể"))
	return IJuVYdzmgy1AUtiKGfqWcv
QCas1lI3KeDnmHRGtT,Skdi3pIFefVsojEbMOLGXlPR7zN,snvp5HM7f4,BVQ3UYZop90bzfAagqwFNn5r,Ls6ezt1TuoSb = [],[],[],[],[]
def qojxlrHzfeaZwEYnFyi0t(HHSO6Q4KI0hlPxYpNuXRkWCmjEgA,uuIjMn1YTf687WlRcOmhq4G23H,source):
	global QCas1lI3KeDnmHRGtT,Skdi3pIFefVsojEbMOLGXlPR7zN,snvp5HM7f4,BVQ3UYZop90bzfAagqwFNn5r,Ls6ezt1TuoSb
	zpXG3Ky6ou8ndWHkb4,g5VCIhlZ4BTUFcPKYoiv6EO,new = [],[],[]
	LFmr6Jxpwe1OklbdUCnTBMAuaiq(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࡉࡥࡱࡹࡥᅄ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࡉࡥࡱࡹࡥᅄ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࡉࡥࡱࡹࡥᅄ"))
	count = len(uuIjMn1YTf687WlRcOmhq4G23H)
	for odfrR0C29T in range(count):
		QCas1lI3KeDnmHRGtT.append(None)
		Skdi3pIFefVsojEbMOLGXlPR7zN.append(None)
		snvp5HM7f4.append(None)
		BVQ3UYZop90bzfAagqwFNn5r.append(None)
		Ls6ezt1TuoSb.append(None)
		title = HHSO6Q4KI0hlPxYpNuXRkWCmjEgA[odfrR0C29T]
		ELbNB92cOh5dqtpVmi40kY = uuIjMn1YTf687WlRcOmhq4G23H[odfrR0C29T].strip(LiRcTVUWuth70DmPy(u"ࠨࠢࠪỄ")).strip(FnBiAjthS8MkXs67W(u"ࠩࠩࠫễ")).strip(iUeoLOsbHqP(u"ࠪࡃࠬỆ")).strip(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫ࠴࠭ệ"))
		if count>FvNyZqaLKw(u"࠲ྺ"): From8aTqdhCbPs(iRoLg2m47tnDATBHGCSPNyx(u"ࠬ็อึࠢึ๎ึ็ัࠡำๅ้ࠥࠦࠧỈ")+str(odfrR0C29T+FvNyZqaLKw(u"࠲ྺ")),title)
		arnh6BjMUifQ95twmyIcV3ERlKo0 = ELbNB92cOh5dqtpVmi40kY.split(Cu1704YofAbr3QTm(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧỉ"),zqdvcbP5L8BHh(u"࠳ྻ"))[lc0dpSmwoPDjLnk(u"࠳ྼ")]
		D3DV6jKQZnqGd = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,iUeoLOsbHqP(u"ࠧ࡭࡫ࡶࡸࠬỊ"),Cu1704YofAbr3QTm(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࠪị"),arnh6BjMUifQ95twmyIcV3ERlKo0)
		if D3DV6jKQZnqGd and hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩࡄࡏ࡜ࡇࡍࠨỌ") not in source:
			QCas1lI3KeDnmHRGtT[odfrR0C29T] = D3DV6jKQZnqGd
		else:
			EhMGckq0IeiTSozlNYZfCVnp = dM9DZS0pkxbqaf7W.Thread(target=ixWp9hHqkbJ,args=(title,ELbNB92cOh5dqtpVmi40kY,source,odfrR0C29T))
			EhMGckq0IeiTSozlNYZfCVnp.start()
			g5VCIhlZ4BTUFcPKYoiv6EO.append(EhMGckq0IeiTSozlNYZfCVnp)
			new.append(odfrR0C29T)
			MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(sTcr7iDp5eFt4RoLMhuwq1A(u"࠴࠳࠽࠵྽"))
	timeout = oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠻࠶྾") if source==yA5z6LIXBlo41PRVMY87wOisFp(u"ࠪࡅࡐ࡝ࡁࡎࠩọ") else hBvsQ7oCkKUdwjx58ml3EN(u"࠹࠰྿")
	for EhMGckq0IeiTSozlNYZfCVnp in g5VCIhlZ4BTUFcPKYoiv6EO: EhMGckq0IeiTSozlNYZfCVnp.join(timeout)
	for odfrR0C29T in range(count):
		title = HHSO6Q4KI0hlPxYpNuXRkWCmjEgA[odfrR0C29T]
		ELbNB92cOh5dqtpVmi40kY = uuIjMn1YTf687WlRcOmhq4G23H[odfrR0C29T].strip(iRoLg2m47tnDATBHGCSPNyx(u"ࠫࠥ࠭Ỏ")).strip(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠬࠬࠧỏ")).strip(yA5z6LIXBlo41PRVMY87wOisFp(u"࠭࠿ࠨỐ")).strip(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠧ࠰ࠩố"))
		if QCas1lI3KeDnmHRGtT[odfrR0C29T]: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = QCas1lI3KeDnmHRGtT[odfrR0C29T]
		else: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = zqdvcbP5L8BHh(u"ࠨ࡞ࡱࡊࡦ࡯࡬ࡦࡦ࠽ࠤ࡚ࠥࡩ࡮ࡧࡲࡹࡹࠦࠨࠨỒ")+str(timeout)+sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩࠣࡷࡪࡩ࡯࡯ࡦࡶ࠭ࠬồ"),[],[]
		zpXG3Ky6ou8ndWHkb4.append([title,ELbNB92cOh5dqtpVmi40kY,svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ])
		if odfrR0C29T in new:
			arnh6BjMUifQ95twmyIcV3ERlKo0 = ELbNB92cOh5dqtpVmi40kY.split(iRoLg2m47tnDATBHGCSPNyx(u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫỔ"),wRxoKs10Syj7V4edYhtP(u"࠱࿀"))[bUdr5Hahw6sY8xJ(u"࠱࿁")]
			try: kQYx4H9gO7uXcBmDGvrVCJyhLel5p,IouTA2U5QcPE8bw4SkBa,CrxbYkqAehjotBP8Sd1gzTUMyu50 = zzvBg3ShiamAZ[l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠲࿂")]
			except: Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,LiRcTVUWuth70DmPy(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡉ࠭ổ"),arnh6BjMUifQ95twmyIcV3ERlKo0,[svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ],Oa8xvPtmLZkBA43K0EzrdhXS)
	LFmr6Jxpwe1OklbdUCnTBMAuaiq(bUdr5Hahw6sY8xJ(u"ࠬ࠭Ỗ"),p72fnFtcPix5UKwr9YNzW(u"࠭ࠧỗ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠧࠨỘ"))
	return zpXG3Ky6ou8ndWHkb4
def ixWp9hHqkbJ(C83UXWf15zdwLA0,url,source,akVPDzJGgWi4vK3jNt0eCsuLUm9cZF):
	global QCas1lI3KeDnmHRGtT
	LOHZ4o9m7p6ebfTYXGIdz5PWs3q(E6MIKdpBomef(u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧộ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+XzrqbGDIy54juixkMA(u"ࠩࠣࠤࠥࡘࡥࡴࡱ࡯ࡺ࡮ࡴࡧࠡࡵࡷࡥࡷࡺࡥࡥࠢࠣࠤࡘ࡫࡬ࡦࡥࡷࡩࡩࡀࠠ࡜ࠢࠪỚ")+C83UXWf15zdwLA0+SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪࠤࡢࠦࠠࠡࡑࡵ࡭࡬࡯࡮ࡢ࡮࠽ࠤࡠࠦࠧớ")+url+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫࠥࡣࠧỜ"))
	ELbNB92cOh5dqtpVmi40kY,pmyfc2tquKUHb3iBN0C4zxsRDZQSw = url,Cu1704YofAbr3QTm(u"ࠬ࠭ờ")
	jgowdIiYXk6RSZ8 = zqdvcbP5L8BHh(u"࠭ࡉࡏࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࠪỞ")
	svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = kiJBeRQvK723qUyrs(url,source)
	if svejmhZS0t24bAiYuzk==YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬở"):
		QCas1lI3KeDnmHRGtT[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF] = yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭Ỡ"),[],[]
		return QCas1lI3KeDnmHRGtT[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF]
	elif UTelCo0ihE1d5R(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬỡ") in svejmhZS0t24bAiYuzk:
		pmyfc2tquKUHb3iBN0C4zxsRDZQSw = YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠲࠼ࠣࠤࡓ࡫ࡥࡥࠢࡈࡼࡹ࡫ࡲ࡯ࡣ࡯ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷ࠭Ợ")
		ELbNB92cOh5dqtpVmi40kY = qqLtBwnyWV1(zzvBg3ShiamAZ)[E6MIKdpBomef(u"࠳࿃")]
		jgowdIiYXk6RSZ8,pmyfc2tquKUHb3iBN0C4zxsRDZQSw,eyUmvNFiYsE,zzvBg3ShiamAZ = ttdQSIAeTaKpLHlDguxsN50O2Zb(pmyfc2tquKUHb3iBN0C4zxsRDZQSw,ELbNB92cOh5dqtpVmi40kY,source,akVPDzJGgWi4vK3jNt0eCsuLUm9cZF)
		if pmyfc2tquKUHb3iBN0C4zxsRDZQSw==SO94xq1RAkMm2uF(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩợ"): return pmyfc2tquKUHb3iBN0C4zxsRDZQSw,eyUmvNFiYsE,zzvBg3ShiamAZ
	elif svejmhZS0t24bAiYuzk: pmyfc2tquKUHb3iBN0C4zxsRDZQSw = xW2Arao7YVOemw(u"ࠬࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠲࠼ࠣࠤࠬỤ")+svejmhZS0t24bAiYuzk.replace(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠭࡜࡯ࠩụ"),g4g6bfkPtVGU5lIM3(u"ࠧࠨỦ")).replace(iRoLg2m47tnDATBHGCSPNyx(u"ࠨ࡞ࡵࠫủ"),bUdr5Hahw6sY8xJ(u"ࠩࠪỨ"))[:S4SOKF2QbBhjCd3RrVMuHIzE(u"࠼࠵࿄")]
	if zzvBg3ShiamAZ:
		zzvBg3ShiamAZ = qqLtBwnyWV1(zzvBg3ShiamAZ)
		LOHZ4o9m7p6ebfTYXGIdz5PWs3q(lc0dpSmwoPDjLnk(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩứ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+kEhAHvti6Vnsfx(u"ࠫࠥࠦࠠࡓࡧࡶࡳࡱࡼࡩ࡯ࡩࠣࡷࡺࡩࡣࡦࡧࡧࡩࡩࠦࠠࠡࡕࡨࡰࡪࡩࡴࡦࡦ࠽ࠤࡠࠦࠧỪ")+C83UXWf15zdwLA0+SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡹ࡯࡭ࡸࡨࡶ࠿࡛ࠦࠡࠩừ")+jgowdIiYXk6RSZ8+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࠠ࡞ࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪỬ")+url+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧử")+ELbNB92cOh5dqtpVmi40kY+hBvsQ7oCkKUdwjx58ml3EN(u"ࠨࠢࡠࠤࠥࠦࡖࡪࡦࡨࡳࡸࡀࠠ࡜ࠢࠪỮ")+str(zzvBg3ShiamAZ)+XzrqbGDIy54juixkMA(u"ࠩࠣࡡࠬữ"))
	else: LOHZ4o9m7p6ebfTYXGIdz5PWs3q(SO94xq1RAkMm2uF(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩỰ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+hBvsQ7oCkKUdwjx58ml3EN(u"ࠫࠥࠦࠠࡓࡧࡶࡳࡱࡼࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦࠣࠤ࡙ࠥࡥ࡭ࡧࡦࡸࡪࡪ࠺ࠡ࡝ࠣࠫự")+C83UXWf15zdwLA0+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠬࠦ࡝ࠡࠢࠣࡓࡷ࡯ࡧࡪࡰࡤࡰ࠿࡛ࠦࠡࠩỲ")+url+Me28A1sBLNIgUp5YCDyvT(u"࠭ࠠ࡞ࠢࠣࠤࡑ࡯࡮࡬࠼ࠣ࡟ࠥ࠭ỳ")+ELbNB92cOh5dqtpVmi40kY+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧࠡ࡟ࠣࠤࠥࡋࡲࡳࡱࡵࡷ࠿࡛ࠦࠡࠩỴ")+pmyfc2tquKUHb3iBN0C4zxsRDZQSw+xW2Arao7YVOemw(u"ࠨࠢࡠࠫỵ"))
	pmyfc2tquKUHb3iBN0C4zxsRDZQSw = GhPlajzTxY8(pmyfc2tquKUHb3iBN0C4zxsRDZQSw)
	QCas1lI3KeDnmHRGtT[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF] = pmyfc2tquKUHb3iBN0C4zxsRDZQSw,eyUmvNFiYsE,zzvBg3ShiamAZ
	return pmyfc2tquKUHb3iBN0C4zxsRDZQSw,eyUmvNFiYsE,zzvBg3ShiamAZ
def wV9txGTDFZN(title,ELbNB92cOh5dqtpVmi40kY,svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ,source,type=sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩࠪỶ")):
	if svejmhZS0t24bAiYuzk==XzrqbGDIy54juixkMA(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨỷ"): return svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ
	elif zzvBg3ShiamAZ:
		while xW2Arao7YVOemw(u"ࡘࡷࡻࡥᅅ"):
			if len(zzvBg3ShiamAZ)==pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠶࿅"): z0jyetbQwKrIclL9vJW = YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠶࿆")
			else: z0jyetbQwKrIclL9vJW = D1DJtzviFZSrA(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪỸ"), eyUmvNFiYsE)
			if z0jyetbQwKrIclL9vJW==-l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠱࿇"): IJuVYdzmgy1AUtiKGfqWcv = XzrqbGDIy54juixkMA(u"ࠬࡺࡲࡪࡧࡧࠫỹ")
			else:
				bbkJxiMOdPG = zzvBg3ShiamAZ[z0jyetbQwKrIclL9vJW]
				LOHZ4o9m7p6ebfTYXGIdz5PWs3q(fprnld4CZo(u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬỺ"),jjqPWzLUBY1HpQJn0tlfVbGio(cTJphS1nFz5EUgNWm86C)+fprnld4CZo(u"ࠧࠡࠢࠣࡔࡱࡧࡹࡪࡰࡪࠤࡸࡺࡡࡳࡶࡨࡨࠥࠦࠠࡔࡧ࡯ࡩࡨࡺࡥࡥ࠼ࠣ࡟ࠥ࠭ỻ")+title+zqdvcbP5L8BHh(u"ࠨࠢࡠࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬỼ")+ELbNB92cOh5dqtpVmi40kY+p72fnFtcPix5UKwr9YNzW(u"ࠩࠣࡡࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪỽ")+str(bbkJxiMOdPG)+oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠪࠤࡢ࠭Ỿ"))
				if fprnld4CZo(u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴ࠧỿ") in bbkJxiMOdPG and wRxoKs10Syj7V4edYhtP(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠬἀ") in bbkJxiMOdPG:
					EngrYRNsHhx,gRVtlOdFCSG8p1UjmPD,gCitSRH90rUG5s72VIBcaMQv8qpf = UYbpHGsed0fihgtDQ6n(bbkJxiMOdPG)
					if gCitSRH90rUG5s72VIBcaMQv8qpf: bbkJxiMOdPG = gCitSRH90rUG5s72VIBcaMQv8qpf[Me28A1sBLNIgUp5YCDyvT(u"࠱࿈")]
					else: bbkJxiMOdPG = LiRcTVUWuth70DmPy(u"࠭ࠧἁ")
				if not bbkJxiMOdPG: IJuVYdzmgy1AUtiKGfqWcv = kEhAHvti6Vnsfx(u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫἂ")
				else: IJuVYdzmgy1AUtiKGfqWcv = ICifW6hdKqxkAJ02XZgHysOwoV9Dc5(bbkJxiMOdPG,source,type)
			if IJuVYdzmgy1AUtiKGfqWcv in [XzrqbGDIy54juixkMA(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩἃ"),kEhAHvti6Vnsfx(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪἄ"),wRxoKs10Syj7V4edYhtP(u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࡤ࠸࡮ࡥࡡࡰࡩࡳࡻࠧἅ")] or len(zzvBg3ShiamAZ)==oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠳࿉"): break
			elif IJuVYdzmgy1AUtiKGfqWcv in [sTcr7iDp5eFt4RoLMhuwq1A(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫἆ"),xW2Arao7YVOemw(u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭ἇ"),yA5z6LIXBlo41PRVMY87wOisFp(u"࠭ࡴࡳ࡫ࡨࡨࠬἈ")]: break
			else: aHKzv76JCVnprbY8w(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࠨἉ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨࠩἊ"),wRxoKs10Syj7V4edYhtP(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬἋ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠪห้๋ไโࠢ็้ࠥ๐ูๆๆࠣะึฮࠠๆๆไࠤ฿๐ั่ࠩἌ"))
	else:
		IJuVYdzmgy1AUtiKGfqWcv = QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫࡺࡴࡲࡦࡵࡲࡰࡻ࡫ࡤࠨἍ")
		if dd8rHcveo7O15hT3MSR(ELbNB92cOh5dqtpVmi40kY): IJuVYdzmgy1AUtiKGfqWcv = ICifW6hdKqxkAJ02XZgHysOwoV9Dc5(ELbNB92cOh5dqtpVmi40kY,source,type)
	return IJuVYdzmgy1AUtiKGfqWcv,svejmhZS0t24bAiYuzk,zzvBg3ShiamAZ
def BgA5JzqTxGOwEnaFv4Xjdf(url,source):
	dR2vHyAtl8pJN1,Xi4JdxQVvZY12c,C83UXWf15zdwLA0,Gi75CwvrkAtjl0bo13pycexqgDnTKF,WJr6B5imnN1Cypw,type,eBjoKP40GyrEFp,dDZQSEGRTo9g85x1C,CCilGtf08YTx6qDX9Svg = url,XzrqbGDIy54juixkMA(u"ࠬ࠭Ἆ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭ࠧἏ"),FvNyZqaLKw(u"ࠧࠨἐ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨࠩἑ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩࠪἒ"),kEhAHvti6Vnsfx(u"ࠪࠫἓ"),lc0dpSmwoPDjLnk(u"ࠫࠬἔ"),SO94xq1RAkMm2uF(u"ࠬ࠭ἕ")
	if p72fnFtcPix5UKwr9YNzW(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ἖") in url:
		dR2vHyAtl8pJN1,Xi4JdxQVvZY12c = url.split(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ἗"),LiRcTVUWuth70DmPy(u"࠴࿊"))
		Xi4JdxQVvZY12c = Xi4JdxQVvZY12c+dshJSmRqeiP9nap2(u"ࠨࡡࡢࠫἘ")+xW2Arao7YVOemw(u"ࠩࡢࡣࠬἙ")+yA5z6LIXBlo41PRVMY87wOisFp(u"ࠪࡣࡤ࠭Ἒ")+LiRcTVUWuth70DmPy(u"ࠫࡤࡥࠧἛ")+hBvsQ7oCkKUdwjx58ml3EN(u"ࠬࡥ࡟ࠨἜ")
		WJr6B5imnN1Cypw,type,eBjoKP40GyrEFp,dDZQSEGRTo9g85x1C,CCilGtf08YTx6qDX9Svg,Sdpv67IZVkJ8thgnX4jGEsq2NMD, = Xi4JdxQVvZY12c.split(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭࡟ࡠࠩἝ"))[:LiRcTVUWuth70DmPy(u"࠺࿋")]
	if not dDZQSEGRTo9g85x1C: dDZQSEGRTo9g85x1C = dshJSmRqeiP9nap2(u"ࠧ࠱ࠩ἞")
	else: dDZQSEGRTo9g85x1C = dDZQSEGRTo9g85x1C.replace(wRxoKs10Syj7V4edYhtP(u"ࠨࡲࠪ἟"),LiRcTVUWuth70DmPy(u"ࠩࠪἠ")).replace(fprnld4CZo(u"ࠪࠤࠬἡ"),Me28A1sBLNIgUp5YCDyvT(u"ࠫࠬἢ"))
	dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1.strip(zqdvcbP5L8BHh(u"ࠬࡅࠧἣ")).strip(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠭࠯ࠨἤ")).strip(iUeoLOsbHqP(u"ࠧࠧࠩἥ"))
	C83UXWf15zdwLA0 = RfKuIXwPAiWtmyF(dR2vHyAtl8pJN1,l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨࡪࡲࡷࡹ࠭ἦ"))
	if WJr6B5imnN1Cypw: Gi75CwvrkAtjl0bo13pycexqgDnTKF = WJr6B5imnN1Cypw
	else: Gi75CwvrkAtjl0bo13pycexqgDnTKF = C83UXWf15zdwLA0
	Gi75CwvrkAtjl0bo13pycexqgDnTKF = RfKuIXwPAiWtmyF(Gi75CwvrkAtjl0bo13pycexqgDnTKF,l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠩࡱࡥࡲ࡫ࠧἧ"))
	WJr6B5imnN1Cypw = WJr6B5imnN1Cypw.replace(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"้ࠪออิาࠩἨ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫࠬἩ")).replace(lc0dpSmwoPDjLnk(u"ู๊ࠬาใิࠫἪ"),p72fnFtcPix5UKwr9YNzW(u"࠭ࠧἫ")).replace(wRxoKs10Syj7V4edYhtP(u"ࠧศๆࠣࠫἬ"),iRoLg2m47tnDATBHGCSPNyx(u"ࠨࠢࠪἭ")).replace(g4g6bfkPtVGU5lIM3(u"ࠩࠣࠤࠬἮ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪࠤࠬἯ"))
	Xi4JdxQVvZY12c = Xi4JdxQVvZY12c.replace(dshJSmRqeiP9nap2(u"๊ࠫฮวีำࠪἰ"),SO94xq1RAkMm2uF(u"ࠬ࠭ἱ")).replace(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭ำ๋ำไีࠬἲ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠧࠨἳ")).replace(kEhAHvti6Vnsfx(u"ࠨษ็ࠤࠬἴ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠩࠣࠫἵ")).replace(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࠤࠥ࠭ἶ"),fprnld4CZo(u"ࠫࠥ࠭ἷ"))
	Gi75CwvrkAtjl0bo13pycexqgDnTKF = Gi75CwvrkAtjl0bo13pycexqgDnTKF.replace(dshJSmRqeiP9nap2(u"๋ࠬศศึิࠫἸ"),Cu1704YofAbr3QTm(u"࠭ࠧἹ")).replace(Cu1704YofAbr3QTm(u"ࠧิ์ิๅึ࠭Ἲ"),SO94xq1RAkMm2uF(u"ࠨࠩἻ")).replace(fprnld4CZo(u"ࠩส่ࠥ࠭Ἴ"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠪࠤࠬἽ")).replace(zqdvcbP5L8BHh(u"ࠫࠥࠦࠧἾ"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠬࠦࠧἿ"))
	return dR2vHyAtl8pJN1,Xi4JdxQVvZY12c,C83UXWf15zdwLA0,Gi75CwvrkAtjl0bo13pycexqgDnTKF,WJr6B5imnN1Cypw,type,eBjoKP40GyrEFp,dDZQSEGRTo9g85x1C,CCilGtf08YTx6qDX9Svg
def xx53V2msKlzA(url,source):
	ooLVBfH73OqagTXS8DGKMCybiWvs,WJr6B5imnN1Cypw,QDJRubCIOWBekmvyqgp9hfNxKHaZ42,EEGNxq8bvDYd6tucfVLgmPyK1WB,GgSYQArIck8Xu4eonFwpRx1Dsbm3yE,faHizDS7Tkt1JlP,jgowdIiYXk6RSZ8 = yA5z6LIXBlo41PRVMY87wOisFp(u"࠭ࠧὀ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࠨὁ"),None,None,None,None,None
	dR2vHyAtl8pJN1,Xi4JdxQVvZY12c,C83UXWf15zdwLA0,Gi75CwvrkAtjl0bo13pycexqgDnTKF,WJr6B5imnN1Cypw,type,eBjoKP40GyrEFp,dDZQSEGRTo9g85x1C,CCilGtf08YTx6qDX9Svg = BgA5JzqTxGOwEnaFv4Xjdf(url,source)
	if pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩὂ") in url:
		if   type==UTelCo0ihE1d5R(u"ࠩࡨࡱࡧ࡫ࡤࠨὃ"): type = oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠪࠤࠬὄ")+wRxoKs10Syj7V4edYhtP(u"๊ࠫ็ึๅࠩὅ")
		elif type==hBvsQ7oCkKUdwjx58ml3EN(u"ࠬࡽࡡࡵࡥ࡫ࠫ὆"): type = FvNyZqaLKw(u"࠭ࠠࠨ὇")+wRxoKs10Syj7V4edYhtP(u"ࠧࠦ็ืห์ีษࠨὈ")
		elif type==iRoLg2m47tnDATBHGCSPNyx(u"ࠨࡤࡲࡸ࡭࠭Ὁ"): type = xW2Arao7YVOemw(u"ࠩࠣࠫὊ")+fprnld4CZo(u"๋ࠪࠩࠪิศ้าอࠥ๎สฮ็ํ่ࠬὋ")
		elif type==Me28A1sBLNIgUp5YCDyvT(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭Ὄ"): type = UTelCo0ihE1d5R(u"ࠬࠦࠧὍ")+lc0dpSmwoPDjLnk(u"࠭ࠥࠦࠧอั๊๐ไࠨ὎")
		elif type==l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧࠨ὏"): type = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࠢࠪὐ")+fprnld4CZo(u"ࠩࠨࠩࠪࠫࠧὑ")
		if eBjoKP40GyrEFp!=dshJSmRqeiP9nap2(u"ࠪࠫὒ"):
			if lc0dpSmwoPDjLnk(u"ࠫࡲࡶ࠴ࠨὓ") not in eBjoKP40GyrEFp: eBjoKP40GyrEFp = kEhAHvti6Vnsfx(u"ࠬࠫࠧὔ")+eBjoKP40GyrEFp
			eBjoKP40GyrEFp = p72fnFtcPix5UKwr9YNzW(u"࠭ࠠࠨὕ")+eBjoKP40GyrEFp
		if dDZQSEGRTo9g85x1C!=kEhAHvti6Vnsfx(u"ࠧࠨὖ"):
			dDZQSEGRTo9g85x1C = FnBiAjthS8MkXs67W(u"ࠨࠧࠨࠩࠪࠫࠥࠦࠧࠨࠫὗ")+dDZQSEGRTo9g85x1C
			dDZQSEGRTo9g85x1C = Me28A1sBLNIgUp5YCDyvT(u"ࠩࠣࠫ὘")+dDZQSEGRTo9g85x1C[-iRoLg2m47tnDATBHGCSPNyx(u"࠾࿌"):]
	if   kEhAHvti6Vnsfx(u"ࠪࡅࡐࡕࡁࡎࠩὙ")		in source: faHizDS7Tkt1JlP	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࡆࡑࡗࡂࡏࠪ὚")		in source: QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬࡧ࡫ࡸࡣࡰࠫὛ")
	elif FnBiAjthS8MkXs67W(u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥࠨ὜")		in C83UXWf15zdwLA0: QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif LiRcTVUWuth70DmPy(u"ࠧࡱࡪࡲࡸࡴࡹ࠮ࡢࡲࡳ࠲࡬࠭Ὕ")	in C83UXWf15zdwLA0: QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif fprnld4CZo(u"ࠨࡣࡵࡥࡧࡹࡥࡦࡦࠪ὞")		in source: QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif LiRcTVUWuth70DmPy(u"ࠩࡤࡰࡦࡸࡡࡣࠩὟ")		in C83UXWf15zdwLA0: QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif yA5z6LIXBlo41PRVMY87wOisFp(u"ࠪࡪࡦࡹࡥ࡭ࠩὠ")		in C83UXWf15zdwLA0: QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif Cu1704YofAbr3QTm(u"ࠫࡹ࠽࡭ࡦࡧ࡯ࠫὡ")		in C83UXWf15zdwLA0: QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif FvNyZqaLKw(u"ࠬࡳ࡯ࡷࡵ࠷ࡹࠬὢ")		in WJr6B5imnN1Cypw:   QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif xW2Arao7YVOemw(u"࠭࡭ࡺࡧࡪࡽࡻ࡯ࡰࠨὣ")		in WJr6B5imnN1Cypw:   QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧࡧࡣ࡭ࡩࡷ࠭ὤ")		in WJr6B5imnN1Cypw:   QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif bUdr5Hahw6sY8xJ(u"ࠨใฯีࠬὥ")			in WJr6B5imnN1Cypw:   QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= dshJSmRqeiP9nap2(u"ࠩࡩࡥ࡯࡫ࡲࠨὦ")
	elif g4g6bfkPtVGU5lIM3(u"ࠪๅู้ื๋่ࠪὧ")		in WJr6B5imnN1Cypw:   QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࡵࡧ࡬ࡦࡵࡷ࡭ࡳ࡫ࠧὨ")
	elif p72fnFtcPix5UKwr9YNzW(u"ࠬ࡭ࡤࡳ࡫ࡹࡩࠬὩ")		in dR2vHyAtl8pJN1:   QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= wRxoKs10Syj7V4edYhtP(u"࠭ࡧࡰࡱࡪࡰࡪ࠭Ὢ")
	elif UTelCo0ihE1d5R(u"ࠧ࡮ࡻࡦ࡭ࡲࡧࠧὫ")		in WJr6B5imnN1Cypw:   QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨࡹࡨࡧ࡮ࡳࡡࠨὬ")		in WJr6B5imnN1Cypw:   QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪὭ")		in WJr6B5imnN1Cypw:   QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࡲࡪࡽࡣࡪ࡯ࡤࠫὮ")		in WJr6B5imnN1Cypw:   QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif fprnld4CZo(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩὯ")	in C83UXWf15zdwLA0: QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬࡨ࡯࡬ࡴࡤࠫὰ")		in C83UXWf15zdwLA0: QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif Cu1704YofAbr3QTm(u"࠭ࡴࡷࡨࡸࡲࠬά")		in C83UXWf15zdwLA0: QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠧࡵࡸ࡮ࡷࡦ࠭ὲ")		in C83UXWf15zdwLA0: QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠨࡣࡱࡥࡻ࡯ࡤࡻࠩέ")		in C83UXWf15zdwLA0: QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif fprnld4CZo(u"ࠩࡶ࡬ࡴࡵࡦࡱࡴࡲࠫὴ")		in C83UXWf15zdwLA0: QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif iRoLg2m47tnDATBHGCSPNyx(u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬή")		in C83UXWf15zdwLA0: faHizDS7Tkt1JlP	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif E6MIKdpBomef(u"ࠫࡸ࡮ࡡࡩࡧࡧ࠸ࡺ࠭ὶ")		in C83UXWf15zdwLA0: faHizDS7Tkt1JlP	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif wRxoKs10Syj7V4edYhtP(u"ࠬࡩࡩ࡮ࡣ࠷ࡹࠬί")		in C83UXWf15zdwLA0: faHizDS7Tkt1JlP	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࡥࡨࡻࡱࡳࡼ࠭ὸ")		in C83UXWf15zdwLA0: faHizDS7Tkt1JlP	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif iRoLg2m47tnDATBHGCSPNyx(u"ࠧࡩࡣ࡯ࡥࡨ࡯࡭ࡢࠩό")		in C83UXWf15zdwLA0: faHizDS7Tkt1JlP	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif UTelCo0ihE1d5R(u"ࠨࡥ࡬ࡱࡦࡧࡢࡥࡱࠪὺ")		in C83UXWf15zdwLA0: faHizDS7Tkt1JlP	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif zqdvcbP5L8BHh(u"ࠩࡼࡳࡺࡺࡵࠨύ")	 	in C83UXWf15zdwLA0: QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= SO94xq1RAkMm2uF(u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫὼ")
	elif pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࡾ࠸ࡵ࠯ࡤࡨࠫώ")	 	in C83UXWf15zdwLA0: QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭὾")
	elif lc0dpSmwoPDjLnk(u"࠭ࡥࡨࡻ࠰ࡦࡪࡹࡴ࠯ࡰࡨࡸࠬ὿")	in C83UXWf15zdwLA0: QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧࡥ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡨࠬᾀ")	in C83UXWf15zdwLA0: QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= p72fnFtcPix5UKwr9YNzW(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࡸ࡬ࡴࠬᾁ")
	elif YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩࡨ࡫ࡾ࠴ࡢࡦࡵࡷࠫᾂ")		in C83UXWf15zdwLA0: QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠵ࠬᾃ")
	elif fprnld4CZo(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬᾄ")		in C83UXWf15zdwLA0: QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= FvNyZqaLKw(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠹ࠧᾅ")
	elif kEhAHvti6Vnsfx(u"࠭࡭ࡰࡵ࡫ࡥ࡭ࡪࡡࠨᾆ")		in C83UXWf15zdwLA0: QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢࠩᾇ")
	elif fprnld4CZo(u"ࠨࡨࡤࡧࡺࡲࡴࡺࡤࡲࡳࡰࡹࠧᾈ")	in C83UXWf15zdwLA0: QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= Cu1704YofAbr3QTm(u"ࠩࡩࡥࡨࡻ࡬ࡵࡻࡥࡳࡴࡱࡳࠨᾉ")
	elif S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠪ࡭ࡳ࡬࡬ࡢ࡯࠱ࡧࡨ࠭ᾊ")	in C83UXWf15zdwLA0: QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= wRxoKs10Syj7V4edYhtP(u"ࠫ࡮ࡴࡦ࡭ࡣࡰࠫᾋ")
	elif S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠬࡨࡵࡻࡼࡹࡶࡱ࠭ᾌ")		in C83UXWf15zdwLA0: QDJRubCIOWBekmvyqgp9hfNxKHaZ42	= SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࡢࡶࡼࡽࡺࡷࡲࠧᾍ")
	elif hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠧࡢࡴࡤࡦࡱࡵࡡࡥࡵࠪᾎ")	in C83UXWf15zdwLA0: EEGNxq8bvDYd6tucfVLgmPyK1WB	= lc0dpSmwoPDjLnk(u"ࠨࡣࡵࡥࡧࡲ࡯ࡢࡦࡶࠫᾏ")
	elif XzrqbGDIy54juixkMA(u"ࠩࡤࡶࡨ࡮ࡩࡷࡧࠪᾐ")		in C83UXWf15zdwLA0: EEGNxq8bvDYd6tucfVLgmPyK1WB	= UTelCo0ihE1d5R(u"ࠪࡥࡷࡩࡨࡪࡸࡨࠫᾑ")
	elif hBvsQ7oCkKUdwjx58ml3EN(u"ࠫࡨࡧࡴࡤࡪ࠱࡭ࡸ࠭ᾒ")	 	in C83UXWf15zdwLA0: EEGNxq8bvDYd6tucfVLgmPyK1WB	= l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬࡩࡡࡵࡥ࡫ࠫᾓ")
	elif LiRcTVUWuth70DmPy(u"࠭ࡦࡪ࡮ࡨࡶ࡮ࡵࠧᾔ")		in C83UXWf15zdwLA0: EEGNxq8bvDYd6tucfVLgmPyK1WB	= g4g6bfkPtVGU5lIM3(u"ࠧࡧ࡫࡯ࡩࡷ࡯࡯ࠨᾕ")
	elif iUeoLOsbHqP(u"ࠨࡸ࡬ࡨࡧࡳࠧᾖ")		in C83UXWf15zdwLA0: EEGNxq8bvDYd6tucfVLgmPyK1WB	= FnBiAjthS8MkXs67W(u"ࠩࡹ࡭ࡩࡨ࡭ࠨᾗ")
	elif E6MIKdpBomef(u"ࠪࡺ࡮ࡪࡨࡥࠩᾘ")		in C83UXWf15zdwLA0: faHizDS7Tkt1JlP	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif iUeoLOsbHqP(u"ࠫࡲࡿࡶࡪࡦࠪᾙ")		in C83UXWf15zdwLA0: faHizDS7Tkt1JlP	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif wRxoKs10Syj7V4edYhtP(u"ࠬࡳࡹࡷ࡫࡬ࡨࠬᾚ")		in C83UXWf15zdwLA0: faHizDS7Tkt1JlP	= Gi75CwvrkAtjl0bo13pycexqgDnTKF
	elif pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭ࡶࡪࡦࡨࡳࡧ࡯࡮ࠨᾛ")		in C83UXWf15zdwLA0: EEGNxq8bvDYd6tucfVLgmPyK1WB	= bUdr5Hahw6sY8xJ(u"ࠧࡷ࡫ࡧࡩࡴࡨࡩ࡯ࠩᾜ")
	elif hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨࡩࡲࡺ࡮ࡪࠧᾝ")		in C83UXWf15zdwLA0: EEGNxq8bvDYd6tucfVLgmPyK1WB	= zqdvcbP5L8BHh(u"ࠩࡪࡳࡻ࡯ࡤࠨᾞ")
	elif iUeoLOsbHqP(u"ࠪࡰ࡮࡯ࡶࡪࡦࡨࡳࠬᾟ") 	in C83UXWf15zdwLA0: EEGNxq8bvDYd6tucfVLgmPyK1WB	= p72fnFtcPix5UKwr9YNzW(u"ࠫࡱ࡯ࡩࡷ࡫ࡧࡩࡴ࠭ᾠ")
	elif l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬࡳࡰ࠵ࡷࡳࡰࡴࡧࡤࠨᾡ")	in C83UXWf15zdwLA0: EEGNxq8bvDYd6tucfVLgmPyK1WB	= Cu1704YofAbr3QTm(u"࠭࡭ࡱ࠶ࡸࡴࡱࡵࡡࡥࠩᾢ")
	elif SO94xq1RAkMm2uF(u"ࠧࡱࡷࡥࡰ࡮ࡩࡶࡪࡦࡨࡳࠬᾣ")	in C83UXWf15zdwLA0: EEGNxq8bvDYd6tucfVLgmPyK1WB	= iRoLg2m47tnDATBHGCSPNyx(u"ࠨࡲࡸࡦࡱ࡯ࡣࡷ࡫ࡧࡩࡴ࠭ᾤ")
	elif iUeoLOsbHqP(u"ࠩࡵࡥࡵ࡯ࡤࡷ࡫ࡧࡩࡴ࠭ᾥ") 	in C83UXWf15zdwLA0: EEGNxq8bvDYd6tucfVLgmPyK1WB	= S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠪࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵࠧᾦ")
	elif l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫࡹࡵࡰ࠵ࡶࡲࡴࠬᾧ")		in C83UXWf15zdwLA0: EEGNxq8bvDYd6tucfVLgmPyK1WB	= hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬࡺ࡯ࡱ࠶ࡷࡳࡵ࠭ᾨ")
	elif iRoLg2m47tnDATBHGCSPNyx(u"࠭ࡵࡱࡲࠪᾩ") 			in C83UXWf15zdwLA0: EEGNxq8bvDYd6tucfVLgmPyK1WB	= E6MIKdpBomef(u"ࠧࡶࡲࡥࡳࡲ࠭ᾪ")
	elif FvNyZqaLKw(u"ࠨࡷࡳࡦࠬᾫ") 			in C83UXWf15zdwLA0: EEGNxq8bvDYd6tucfVLgmPyK1WB	= iUeoLOsbHqP(u"ࠩࡸࡴࡧࡵ࡭ࠨᾬ")
	elif sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࡹࡶࡲ࡯ࡢࡦࠪᾭ") 		in C83UXWf15zdwLA0: EEGNxq8bvDYd6tucfVLgmPyK1WB	= g4g6bfkPtVGU5lIM3(u"ࠫࡺࡷ࡬ࡰࡣࡧࠫᾮ")
	elif pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬࡼࡣࡴࡶࡵࡩࡦࡳࠧᾯ") 	in C83UXWf15zdwLA0: EEGNxq8bvDYd6tucfVLgmPyK1WB	= YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ࡶࡤࡵࡷࡶࡪࡧ࡭ࠨᾰ")
	elif XzrqbGDIy54juixkMA(u"ࠧࡷ࡫ࡧࡦࡴࡨࠧᾱ")		in C83UXWf15zdwLA0: EEGNxq8bvDYd6tucfVLgmPyK1WB	= Me28A1sBLNIgUp5YCDyvT(u"ࠨࡸ࡬ࡨࡧࡵࡢࠨᾲ")
	elif Cu1704YofAbr3QTm(u"ࠩࡹ࡭ࡩࡵࡺࡢࠩᾳ") 		in C83UXWf15zdwLA0: EEGNxq8bvDYd6tucfVLgmPyK1WB	= FvNyZqaLKw(u"ࠪࡺ࡮ࡪ࡯ࡻࡣࠪᾴ")
	elif hBvsQ7oCkKUdwjx58ml3EN(u"ࠫࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯ࠨ᾵") 	in C83UXWf15zdwLA0: EEGNxq8bvDYd6tucfVLgmPyK1WB	= SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰࠩᾶ")
	elif oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧࠪᾷ")	in C83UXWf15zdwLA0: EEGNxq8bvDYd6tucfVLgmPyK1WB	= UTelCo0ihE1d5R(u"ࠧࡸ࡫ࡱࡸࡻ࠴࡬ࡪࡸࡨࠫᾸ")
	elif Cu1704YofAbr3QTm(u"ࠨࡼ࡬ࡴࡵࡿࡳࡩࡣࡵࡩࠬᾹ")	in C83UXWf15zdwLA0: EEGNxq8bvDYd6tucfVLgmPyK1WB	= SO94xq1RAkMm2uF(u"ࠩࡽ࡭ࡵࡶࡹࡴࡪࡤࡶࡪ࠭Ὰ")
	elif zqdvcbP5L8BHh(u"ࠪ࡬ࡩ࠳ࡣࡥࡰࠪΆ")		in C83UXWf15zdwLA0: EEGNxq8bvDYd6tucfVLgmPyK1WB	= iUeoLOsbHqP(u"ࠫ࡭ࡪ࠭ࡤࡦࡱࠫᾼ")
	if   QDJRubCIOWBekmvyqgp9hfNxKHaZ42:	ooLVBfH73OqagTXS8DGKMCybiWvs,WJr6B5imnN1Cypw = yA5z6LIXBlo41PRVMY87wOisFp(u"ࠬิวึࠩ᾽"),QDJRubCIOWBekmvyqgp9hfNxKHaZ42
	elif faHizDS7Tkt1JlP:		ooLVBfH73OqagTXS8DGKMCybiWvs,WJr6B5imnN1Cypw = FvNyZqaLKw(u"࠭ࠥๆฯาำࠬι"),faHizDS7Tkt1JlP
	elif EEGNxq8bvDYd6tucfVLgmPyK1WB:		ooLVBfH73OqagTXS8DGKMCybiWvs,WJr6B5imnN1Cypw = wRxoKs10Syj7V4edYhtP(u"ࠧࠦࠧ฼ห๊ࠦๅฺำ๋ๅࠬ᾿"),EEGNxq8bvDYd6tucfVLgmPyK1WB
	elif GgSYQArIck8Xu4eonFwpRx1Dsbm3yE:	ooLVBfH73OqagTXS8DGKMCybiWvs,WJr6B5imnN1Cypw = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨࠧࠨࠩ฾อๅࠡะสีั๐ࠧ῀"),GgSYQArIck8Xu4eonFwpRx1Dsbm3yE
	elif jgowdIiYXk6RSZ8:	ooLVBfH73OqagTXS8DGKMCybiWvs,WJr6B5imnN1Cypw = FvNyZqaLKw(u"ࠩࠨูࠩࠪࠫศ็ࠣาฬืฬ๋ࠩ῁"),Gi75CwvrkAtjl0bo13pycexqgDnTKF
	else:			ooLVBfH73OqagTXS8DGKMCybiWvs,WJr6B5imnN1Cypw = xW2Arao7YVOemw(u"ࠪࠩࠪࠫࠥࠦ฻ส้๋ࠥฬ่๊็ࠫῂ"),Gi75CwvrkAtjl0bo13pycexqgDnTKF
	return ooLVBfH73OqagTXS8DGKMCybiWvs,WJr6B5imnN1Cypw,type,eBjoKP40GyrEFp,dDZQSEGRTo9g85x1C
def kiJBeRQvK723qUyrs(url,source):
	dR2vHyAtl8pJN1,faHizDS7Tkt1JlP,C83UXWf15zdwLA0,Gi75CwvrkAtjl0bo13pycexqgDnTKF,WJr6B5imnN1Cypw,type,eBjoKP40GyrEFp,dDZQSEGRTo9g85x1C,CCilGtf08YTx6qDX9Svg = BgA5JzqTxGOwEnaFv4Xjdf(url,source)
	if   sTcr7iDp5eFt4RoLMhuwq1A(u"ࠫࡆࡑࡏࡂࡏࠪῃ")		in source: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = iz81jLCMhR(dR2vHyAtl8pJN1,WJr6B5imnN1Cypw)
	elif p72fnFtcPix5UKwr9YNzW(u"ࠬࡇࡋࡘࡃࡐࠫῄ")		in source: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = AjTX6bWUoJ(dR2vHyAtl8pJN1,type,dDZQSEGRTo9g85x1C)
	elif l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨ῅")		in source: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = hGZraoJ5gw(dR2vHyAtl8pJN1)
	elif E6MIKdpBomef(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨῆ")		in source: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = bbPAtUuTEM(dR2vHyAtl8pJN1)
	elif SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࡻࡲࡹࡹࡻࠧῇ")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = bbPAtUuTEM(dR2vHyAtl8pJN1)
	elif wRxoKs10Syj7V4edYhtP(u"ࠩࡼ࠶ࡺ࠴ࡢࡦࠩῈ")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = bbPAtUuTEM(dR2vHyAtl8pJN1)
	elif bUdr5Hahw6sY8xJ(u"ࠪࡇࡎࡓࡁ࠵ࡗࠪΈ")		in source: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = Zb7u6XoB1m(dR2vHyAtl8pJN1)
	elif dshJSmRqeiP9nap2(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭Ὴ")		in source: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = flQ5A7tGE3(dR2vHyAtl8pJN1)
	elif iUeoLOsbHqP(u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧΉ")		in source: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = C7tunkvS8i(dR2vHyAtl8pJN1)
	elif YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨῌ")		in source: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = SMNu2OETbA(dR2vHyAtl8pJN1)
	elif Me28A1sBLNIgUp5YCDyvT(u"ࠧࡔࡊࡒࡊࡍࡇࠧ῍")		in source: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = dJr4nDP9y3(dR2vHyAtl8pJN1)
	elif hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪ῎")		in source: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = MgAYQOR7aP(dR2vHyAtl8pJN1,CCilGtf08YTx6qDX9Svg)
	elif UTelCo0ihE1d5R(u"ࠩ࡮ࡥࡹࡱ࡯ࡶࡶࡨࠫ῏")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = pCYXWusGUJ(dR2vHyAtl8pJN1)
	elif bUdr5Hahw6sY8xJ(u"ࠪࡥࡰࡵࡡ࡮࠰ࡦࡥࡲ࠭ῐ")	in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = nnTPxkzGRH(dR2vHyAtl8pJN1)
	elif lc0dpSmwoPDjLnk(u"ࠫࡦࡲࡡࡳࡣࡥࠫῑ")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = SSFpvX9OBg2L6Yoi7mJsCWdbIPG(dR2vHyAtl8pJN1)
	elif l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧῒ")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = w9VNKsZ824(dR2vHyAtl8pJN1)
	elif XzrqbGDIy54juixkMA(u"࠭ࡳࡩࡣ࡫ࡩࡩ࠺ࡵࠨΐ")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = w9VNKsZ824(dR2vHyAtl8pJN1)
	elif iUeoLOsbHqP(u"ࠧࡦࡩࡼࡲࡴࡽࠧ῔")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = X89TQqW1jf(dR2vHyAtl8pJN1)
	elif Me28A1sBLNIgUp5YCDyvT(u"ࠨࡶࡹࡪࡺࡴࠧ῕")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = PMfc9b4vXp(dR2vHyAtl8pJN1)
	elif iUeoLOsbHqP(u"ࠩࡷࡺࡰࡹࡡࠨῖ")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = PMfc9b4vXp(dR2vHyAtl8pJN1)
	elif dshJSmRqeiP9nap2(u"ࠪࡸࡻ࠳ࡦ࠯ࡥࡲࡱࠬῗ")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = PMfc9b4vXp(dR2vHyAtl8pJN1)
	elif lc0dpSmwoPDjLnk(u"ࠫ࡭ࡧ࡬ࡢࡥ࡬ࡱࡦ࠭Ῐ")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = osBuzptTmE(dR2vHyAtl8pJN1)
	elif oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠬࡹࡨࡰࡱࡩࡴࡷࡵࠧῙ")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = qqBmVUYNIA(dR2vHyAtl8pJN1)
	elif zqdvcbP5L8BHh(u"࠭࡭ࡺࡧࡪࡽࡻ࡯ࡰࠨῚ")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = o3oR5Z61GyxavgupWP(dR2vHyAtl8pJN1)
	elif Cu1704YofAbr3QTm(u"ࠧࡷࡵ࠷ࡹࠬΊ")			in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = rrSL6nj91X(dR2vHyAtl8pJN1)
	elif pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࡨࡤ࡮ࡪࡸࠧ῜")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = SY3eVzk80i(dR2vHyAtl8pJN1)
	elif Cu1704YofAbr3QTm(u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪ῝")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = QTLlPojE20(dR2vHyAtl8pJN1)
	elif fprnld4CZo(u"ࠪࡲࡪࡽࡣࡪ࡯ࡤࠫ῞")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = QTLlPojE20(dR2vHyAtl8pJN1)
	elif wRxoKs10Syj7V4edYhtP(u"ࠫࡨ࡯࡭ࡢ࠯࡯࡭࡬࡮ࡴࠨ῟")	in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = EZ9Ka24UCG(dR2vHyAtl8pJN1)
	elif QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬࡩࡩ࡮ࡣ࡯࡭࡬࡮ࡴࠨῠ")	in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = EZ9Ka24UCG(dR2vHyAtl8pJN1)
	elif g4g6bfkPtVGU5lIM3(u"࠭࡭ࡺࡥ࡬ࡱࡦ࠭ῡ")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = vIufSK5zHr(dR2vHyAtl8pJN1)
	elif p72fnFtcPix5UKwr9YNzW(u"ࠧࡸࡧࡦ࡭ࡲࡧࠧῢ")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = u2dxD1WamQ(dR2vHyAtl8pJN1)
	elif QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠨࡤࡲ࡯ࡷࡧࠧΰ")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = PJsSdvbghy(dR2vHyAtl8pJN1)
	elif fprnld4CZo(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧῤ")	in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = Xswr3uEckt(dR2vHyAtl8pJN1)
	elif QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠪࡥࡷࡨ࡬ࡪࡱࡱࡾࠬῥ")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = o2qO4LFMIN(dR2vHyAtl8pJN1)
	elif hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠫࡪ࡭ࡹ࠮ࡤࡨࡷࡹ࠴࡮ࡦࡶࠪῦ")	in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = glPzHI7LEe(dR2vHyAtl8pJN1)
	elif dshJSmRqeiP9nap2(u"ࠬࡪ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡦࠪῧ")	in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = UTelCo0ihE1d5R(u"࠭ࠧῨ"),[xW2Arao7YVOemw(u"ࠧࠨῩ")],[dR2vHyAtl8pJN1]
	elif LiRcTVUWuth70DmPy(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩῪ")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = TNlZLgj9Gt(dR2vHyAtl8pJN1)
	elif UTelCo0ihE1d5R(u"ࠩࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨࠨΎ")	in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = GG9wPnAJvh(dR2vHyAtl8pJN1)
	elif bUdr5Hahw6sY8xJ(u"ࠪࡹࡵࡨࡡ࡮ࠩῬ") 		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࠬ῭"),[S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠬ࠭΅")],[dR2vHyAtl8pJN1]
	else: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = dshJSmRqeiP9nap2(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ`"),[bUdr5Hahw6sY8xJ(u"ࠧࠨ῰")],[dR2vHyAtl8pJN1]
	if svejmhZS0t24bAiYuzk!=iUeoLOsbHqP(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭῱"): svejmhZS0t24bAiYuzk = SO94xq1RAkMm2uF(u"ࠩࡉࡥ࡮ࡲࡥࡥ࠼ࠣࠤࠬῲ")+svejmhZS0t24bAiYuzk
	return svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ
def ttyPFT6xjAnSUfpOdiYM7(svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ):
	xut3LAibydXZnzkpBaKOsgew70,gI487voLsArVqW6Ffp = [],[]
	for title,ELbNB92cOh5dqtpVmi40kY in zip(eyUmvNFiYsE,zzvBg3ShiamAZ):
		if dd8rHcveo7O15hT3MSR(ELbNB92cOh5dqtpVmi40kY):
			xut3LAibydXZnzkpBaKOsgew70.append(title)
			gI487voLsArVqW6Ffp.append(ELbNB92cOh5dqtpVmi40kY)
	if not gI487voLsArVqW6Ffp and not svejmhZS0t24bAiYuzk: svejmhZS0t24bAiYuzk = fprnld4CZo(u"ࠪࡊࡦ࡯࡬ࡦࡦࠪῳ")
	return svejmhZS0t24bAiYuzk,xut3LAibydXZnzkpBaKOsgew70,gI487voLsArVqW6Ffp
def ttdQSIAeTaKpLHlDguxsN50O2Zb(pmyfc2tquKUHb3iBN0C4zxsRDZQSw,url,source,akVPDzJGgWi4vK3jNt0eCsuLUm9cZF):
	global QCas1lI3KeDnmHRGtT,Skdi3pIFefVsojEbMOLGXlPR7zN,snvp5HM7f4,BVQ3UYZop90bzfAagqwFNn5r,Ls6ezt1TuoSb
	kohuG31e4mVDOyPtYxZHbz2Q = []
	QfcnerXFOaWg = (g4g6bfkPtVGU5lIM3(u"࡙ࠫ࡯࡭ࡦࡱࡸࡸࠬῴ"),[],[])
	Skdi3pIFefVsojEbMOLGXlPR7zN[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF],snvp5HM7f4[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF],BVQ3UYZop90bzfAagqwFNn5r[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF],Ls6ezt1TuoSb[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF] = QfcnerXFOaWg,QfcnerXFOaWg,QfcnerXFOaWg,QfcnerXFOaWg
	E1O2aUeoZrvCdLBuXJznIGM = [vrEgRWcX78TDonLaf9N0uzVHSYP5Z,oJh2GeyVSdIjKTfgrkN,JfKEwO6WNYrkGQt,kLo7t93uF85zxGpSCWKcI6Tl4XHbOY]
	for A2AHdqWBkYytPpbl1N in E1O2aUeoZrvCdLBuXJznIGM:
		iHzge9SO74 = dM9DZS0pkxbqaf7W.Thread(target=A2AHdqWBkYytPpbl1N,args=(url,source,akVPDzJGgWi4vK3jNt0eCsuLUm9cZF))
		iHzge9SO74.start()
		if Skdi3pIFefVsojEbMOLGXlPR7zN[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF][QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠶࿍")]==Cu1704YofAbr3QTm(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ῵") or (not Skdi3pIFefVsojEbMOLGXlPR7zN[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF][QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠶࿍")] and Skdi3pIFefVsojEbMOLGXlPR7zN[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF][l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠲࿎")]): break
		if snvp5HM7f4[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF][bUdr5Hahw6sY8xJ(u"࠱࿏")]==hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫῶ") or (not snvp5HM7f4[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF][bUdr5Hahw6sY8xJ(u"࠱࿏")] and snvp5HM7f4[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF][hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠴࿐")]): break
		if BVQ3UYZop90bzfAagqwFNn5r[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF][SO94xq1RAkMm2uF(u"࠳࿑")]==LiRcTVUWuth70DmPy(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬῷ") or (not BVQ3UYZop90bzfAagqwFNn5r[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF][SO94xq1RAkMm2uF(u"࠳࿑")] and BVQ3UYZop90bzfAagqwFNn5r[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF][FnBiAjthS8MkXs67W(u"࠶࿒")]): break
		if Ls6ezt1TuoSb[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF][G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠵࿓")]==YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭Ὸ") or (not Ls6ezt1TuoSb[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF][G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠵࿓")] and Ls6ezt1TuoSb[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF][lc0dpSmwoPDjLnk(u"࠸࿔")]): break
		MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠰࠯࠹࠸࿕"))
		kohuG31e4mVDOyPtYxZHbz2Q.append(iHzge9SO74)
	timeout,step = xW2Arao7YVOemw(u"࠵࠳࿗"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠳࿖")
	for QfcnerXFOaWg in range(timeout//step):
		if Skdi3pIFefVsojEbMOLGXlPR7zN[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF][UTelCo0ihE1d5R(u"࠳࿘")]==sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧΌ") or (not Skdi3pIFefVsojEbMOLGXlPR7zN[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF][UTelCo0ihE1d5R(u"࠳࿘")] and Skdi3pIFefVsojEbMOLGXlPR7zN[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF][l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠶࿙")]): break
		if snvp5HM7f4[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF][LiRcTVUWuth70DmPy(u"࠵࿚")]==kEhAHvti6Vnsfx(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨῺ") or (not snvp5HM7f4[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF][LiRcTVUWuth70DmPy(u"࠵࿚")] and snvp5HM7f4[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF][kEhAHvti6Vnsfx(u"࠸࿛")]): break
		if BVQ3UYZop90bzfAagqwFNn5r[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF][FnBiAjthS8MkXs67W(u"࠰࿜")]==UTelCo0ihE1d5R(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩΏ") or (not BVQ3UYZop90bzfAagqwFNn5r[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF][FnBiAjthS8MkXs67W(u"࠰࿜")] and BVQ3UYZop90bzfAagqwFNn5r[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF][SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠳࿝")]): break
		if Ls6ezt1TuoSb[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF][yA5z6LIXBlo41PRVMY87wOisFp(u"࠲࿞")]==xW2Arao7YVOemw(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪῼ") or (not Ls6ezt1TuoSb[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF][yA5z6LIXBlo41PRVMY87wOisFp(u"࠲࿞")] and Ls6ezt1TuoSb[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF][E6MIKdpBomef(u"࠵࿟")]): break
		MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(step)
	for iHzge9SO74 in kohuG31e4mVDOyPtYxZHbz2Q: iHzge9SO74.join(dshJSmRqeiP9nap2(u"࠵࿠"))
	ot3EhumqJncM8DpYi5ZPrsvS7ULRb = sTcr7iDp5eFt4RoLMhuwq1A(u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠶ࠬ´")
	svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = Skdi3pIFefVsojEbMOLGXlPR7zN[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF]
	zzvBg3ShiamAZ = qqLtBwnyWV1(zzvBg3ShiamAZ)
	QCas1lI3KeDnmHRGtT[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF] = pmyfc2tquKUHb3iBN0C4zxsRDZQSw,eyUmvNFiYsE,zzvBg3ShiamAZ
	if svejmhZS0t24bAiYuzk==S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ῾") or zzvBg3ShiamAZ: return ot3EhumqJncM8DpYi5ZPrsvS7ULRb,svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ
	pmyfc2tquKUHb3iBN0C4zxsRDZQSw += hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨ࡞ࡱࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠸࠺ࠡࠢࠪ῿")+svejmhZS0t24bAiYuzk.replace(g4g6bfkPtVGU5lIM3(u"ࠫࡡࡴࠧࠀ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬ࠭ࠁ")).replace(p72fnFtcPix5UKwr9YNzW(u"࠭࡜ࡳࠩࠂ"),p72fnFtcPix5UKwr9YNzW(u"ࠧࠨࠃ"))[:QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠽࠶࿡")]
	ot3EhumqJncM8DpYi5ZPrsvS7ULRb = Me28A1sBLNIgUp5YCDyvT(u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠹ࠧࠄ")
	svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = snvp5HM7f4[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF]
	zzvBg3ShiamAZ = qqLtBwnyWV1(zzvBg3ShiamAZ)
	QCas1lI3KeDnmHRGtT[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF] = pmyfc2tquKUHb3iBN0C4zxsRDZQSw,eyUmvNFiYsE,zzvBg3ShiamAZ
	if svejmhZS0t24bAiYuzk==zqdvcbP5L8BHh(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧࠅ") or zzvBg3ShiamAZ: return ot3EhumqJncM8DpYi5ZPrsvS7ULRb,svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ
	pmyfc2tquKUHb3iBN0C4zxsRDZQSw += p72fnFtcPix5UKwr9YNzW(u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠴࠼ࠣࠤࠬࠆ")+svejmhZS0t24bAiYuzk.replace(p72fnFtcPix5UKwr9YNzW(u"ࠫࡡࡴࠧࠇ"),dshJSmRqeiP9nap2(u"ࠬ࠭ࠈ")).replace(g4g6bfkPtVGU5lIM3(u"࠭࡜ࡳࠩࠉ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧࠨࠊ"))[:xW2Arao7YVOemw(u"࠾࠰࿢")]
	ot3EhumqJncM8DpYi5ZPrsvS7ULRb = UTelCo0ihE1d5R(u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠺ࠧࠋ")
	svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = BVQ3UYZop90bzfAagqwFNn5r[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF]
	zzvBg3ShiamAZ = qqLtBwnyWV1(zzvBg3ShiamAZ)
	QCas1lI3KeDnmHRGtT[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF] = pmyfc2tquKUHb3iBN0C4zxsRDZQSw,eyUmvNFiYsE,zzvBg3ShiamAZ
	if svejmhZS0t24bAiYuzk==UTelCo0ihE1d5R(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧࠌ") or zzvBg3ShiamAZ: return ot3EhumqJncM8DpYi5ZPrsvS7ULRb,svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ
	pmyfc2tquKUHb3iBN0C4zxsRDZQSw += hBvsQ7oCkKUdwjx58ml3EN(u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠵࠼ࠣࠤࠬࠍ")+svejmhZS0t24bAiYuzk.replace(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࡡࡴࠧࠎ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠬ࠭ࠏ")).replace(E6MIKdpBomef(u"࠭࡜ࡳࠩࠐ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࠨࠑ"))[:l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠸࠱࿣")]
	ot3EhumqJncM8DpYi5ZPrsvS7ULRb = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠻ࠧࠒ")
	svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = Ls6ezt1TuoSb[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF]
	zzvBg3ShiamAZ = qqLtBwnyWV1(zzvBg3ShiamAZ)
	QCas1lI3KeDnmHRGtT[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF] = pmyfc2tquKUHb3iBN0C4zxsRDZQSw,eyUmvNFiYsE,zzvBg3ShiamAZ
	if svejmhZS0t24bAiYuzk==g4g6bfkPtVGU5lIM3(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧࠓ") or zzvBg3ShiamAZ: return ot3EhumqJncM8DpYi5ZPrsvS7ULRb,svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ
	pmyfc2tquKUHb3iBN0C4zxsRDZQSw += sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠶࠼ࠣࠤࠬࠔ")+svejmhZS0t24bAiYuzk.replace(dshJSmRqeiP9nap2(u"ࠫࡡࡴࠧࠕ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠬ࠭ࠖ")).replace(XzrqbGDIy54juixkMA(u"࠭࡜ࡳࠩࠗ"),bUdr5Hahw6sY8xJ(u"ࠧࠨ࠘"))[:iUeoLOsbHqP(u"࠹࠲࿤")]
	QCas1lI3KeDnmHRGtT[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF] = pmyfc2tquKUHb3iBN0C4zxsRDZQSw,eyUmvNFiYsE,zzvBg3ShiamAZ
	return ot3EhumqJncM8DpYi5ZPrsvS7ULRb,pmyfc2tquKUHb3iBN0C4zxsRDZQSw,eyUmvNFiYsE,zzvBg3ShiamAZ
def vrEgRWcX78TDonLaf9N0uzVHSYP5Z(url,source,akVPDzJGgWi4vK3jNt0eCsuLUm9cZF):
	C83UXWf15zdwLA0 = RfKuIXwPAiWtmyF(url,Me28A1sBLNIgUp5YCDyvT(u"ࠨࡰࡤࡱࡪ࠭࠙"))
	zzvBg3ShiamAZ = []
	if QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧࠚ")	in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = Xswr3uEckt(url)
	elif UTelCo0ihE1d5R(u"ࠪ࡫ࡴࡵࡧ࡭ࡧࡸࡷࡪࡸࡣࡰࠩࠛ") in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = ZZY5h4oRSuKW0vgsnqiw1l6XDNM(url)
	elif E6MIKdpBomef(u"ࠫࡾࡵࡵࡵࡷࠪࠜ")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = bbPAtUuTEM(url)
	elif xW2Arao7YVOemw(u"ࠬࡿ࠲ࡶ࠰ࡥࡩࠬࠝ")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = bbPAtUuTEM(url)
	elif SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࡰࡩࡱࡷࡳࡸ࠴ࡡࡱࡲ࠱࡫ࠬࠞ")	in url   : svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = Ijg51tcCLBzpvyxGAVXul(url)
	elif kEhAHvti6Vnsfx(u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢࠩࠟ")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = UYbpHGsed0fihgtDQ6n(url)
	elif yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨࡨࡤࡷࡪࡲࡨࡥࠩࠠ")		in url   : svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = hGZraoJ5gw(url)
	elif iUeoLOsbHqP(u"ࠩࡤࡶࡦࡨ࡬ࡰࡣࡧࡷࠬࠡ")	in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = ssDjKt5fiu0Hb6ZoaqXRPAJml(url)
	elif hBvsQ7oCkKUdwjx58ml3EN(u"ࠪࡥࡷࡩࡨࡪࡸࡨࠫࠢ")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = nMRd3JxIrNzCw5ByYm1GkvUDciS497(url)
	elif G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࡧࡻࡺࡻࡸࡵࡰࠬࠣ")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = dSH9hOkvRn5FZPI0maAg(url)
	elif LiRcTVUWuth70DmPy(u"ࠬ࡫࠵ࡵࡵࡤࡶࠬࠤ")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = E8CGDpBhxoOWeVnad(url)
	elif Cu1704YofAbr3QTm(u"࠭ࡦࡢࡥࡸࡰࡹࡿࡢࡰࡱ࡮ࡷࠬࠥ")	in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = vKPaNJ3FMRAq(url)
	elif fprnld4CZo(u"ࠧࡪࡰࡩࡰࡦࡳ࠮ࡤࡥࠪࠦ")	in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = vKPaNJ3FMRAq(url)
	elif S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠨࡷࡳࡦࡦࡳࠧࠧ") 		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩࠪࠨ"),[FvNyZqaLKw(u"ࠪࠫࠩ")],[url]
	elif S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࡱ࡯ࡩࡷ࡫ࡧࡩࡴ࠭ࠪ") 	in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = HSdLNlvDbwtMo6XiQ(url)
	elif g4g6bfkPtVGU5lIM3(u"ࠬࡳࡰ࠵ࡷࡳࡰࡴࡧࡤࠨࠫ")	in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = GH9ngjZFiseWyY4mA1Q0Pv5cl(url)
	elif hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࡲࡢࡲ࡬ࡨࡻ࡯ࡤࡦࡱࠪࠬ") 	in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = fdEIVcHevjQipl1CPyR(url)
	elif iRoLg2m47tnDATBHGCSPNyx(u"ࠧࡵࡱࡳ࠸ࡹࡵࡰࠨ࠭")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = p13vUrlswfaj0cKh(url)
	elif lc0dpSmwoPDjLnk(u"ࠨࡷࡳࡦࠬ࠮") 			in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = LMV09wIFXvGWm3(url)
	elif SO94xq1RAkMm2uF(u"ࠩࡸࡴࡵ࠭࠯") 			in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = LMV09wIFXvGWm3(url)
	elif FvNyZqaLKw(u"ࠪࡹࡶࡲ࡯ࡢࡦࠪ࠰") 		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = dGXWThCABUxw6Ep1KDk34Z0NIcL(url)
	elif S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࡻࡩࡳࡵࡴࡨࡥࡲ࠭࠱") 	in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = prUJEtlVN8uZ0Gkg9HFP3LY7qe(url)
	elif wRxoKs10Syj7V4edYhtP(u"ࠬࡼࡩࡥࡤࡲࡦࠬ࠲")		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = vufdxnJTXh5RlpW9maY(url)
	elif zqdvcbP5L8BHh(u"࠭ࡶࡪࡦࡲࡾࡦ࠭࠳") 		in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = ZZLo0QTgRy(url)
	elif S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠧࡸࡣࡷࡧ࡭ࡼࡩࡥࡧࡲࠫ࠴") 	in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = DVbf9m8hvQiKzgj172ZqkedE5sC(url)
	elif kEhAHvti6Vnsfx(u"ࠨࡹ࡬ࡲࡹࡼ࠮࡭࡫ࡹࡩࠬ࠵")	in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = iCWrkM5wAaTbpS7KhRVodUYDuv(url)
	elif YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩࡽ࡭ࡵࡶࡹࡴࡪࡤࡶࡪ࠭࠶")	in C83UXWf15zdwLA0: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = Zoj6CfFnS50biE(url)
	else: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = Cu1704YofAbr3QTm(u"ࠪࠫ࠷"),[],[]
	global Skdi3pIFefVsojEbMOLGXlPR7zN
	if svejmhZS0t24bAiYuzk and svejmhZS0t24bAiYuzk!=lc0dpSmwoPDjLnk(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ࠸"): svejmhZS0t24bAiYuzk = Me28A1sBLNIgUp5YCDyvT(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠨ࠹")
	Skdi3pIFefVsojEbMOLGXlPR7zN[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF] = svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ
	return
def oJh2GeyVSdIjKTfgrkN(url,source,akVPDzJGgWi4vK3jNt0eCsuLUm9cZF):
	global snvp5HM7f4
	if SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧ࠺") in url:
		snvp5HM7f4[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF] = sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠢࡖ࡯࡮ࡶࡰࡦࡦࠪ࠻"),[],[]
		return
	svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = xW2Arao7YVOemw(u"ࠨࠩ࠼"),[],[]
	if dd8rHcveo7O15hT3MSR(url): svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = fprnld4CZo(u"ࠩࠪ࠽"),[SO94xq1RAkMm2uF(u"ࠪࠫ࠾")],[url]
	if not zzvBg3ShiamAZ: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = hdeN64namS7o9IqAYOj1bXPp3(url)
	if not zzvBg3ShiamAZ: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = XMmpP948RLndfWUeBwIJcTFCGv(url)
	if not zzvBg3ShiamAZ:
		if svejmhZS0t24bAiYuzk==LiRcTVUWuth70DmPy(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ࠿"): svejmhZS0t24bAiYuzk = FnBiAjthS8MkXs67W(u"ࠬ࠭ࡀ")
		snvp5HM7f4[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF] = FvNyZqaLKw(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࠩࡁ")+svejmhZS0t24bAiYuzk,[],[]
		return
	snvp5HM7f4[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF] = svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ
	return
def JfKEwO6WNYrkGQt(url,source,akVPDzJGgWi4vK3jNt0eCsuLUm9cZF):
	CCeZSJvsigLcq = wRxoKs10Syj7V4edYhtP(u"ࠧࠨࡂ")
	zpXG3Ky6ou8ndWHkb4 = UTelCo0ihE1d5R(u"ࡋࡧ࡬ࡴࡧᅆ")
	try:
		import resolveurl as PPWv6UrNVsl0A
		zpXG3Ky6ou8ndWHkb4 = PPWv6UrNVsl0A.resolve(url)
	except Exception as QUsq5XR712ZifxVBFgYCkyEcP30: CCeZSJvsigLcq = str(QUsq5XR712ZifxVBFgYCkyEcP30)
	global BVQ3UYZop90bzfAagqwFNn5r
	if not zpXG3Ky6ou8ndWHkb4:
		if CCeZSJvsigLcq==p72fnFtcPix5UKwr9YNzW(u"ࠨࠩࡃ"):
			CCeZSJvsigLcq = FTYWns4Q7dSEXmBOAGlJ.format_exc()
			if CCeZSJvsigLcq!=FnBiAjthS8MkXs67W(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬࡄ"): GGtWyVoJReUuEBCdAagiL1YXO8.stderr.write(CCeZSJvsigLcq)
		svejmhZS0t24bAiYuzk = CCeZSJvsigLcq.splitlines()[-hBvsQ7oCkKUdwjx58ml3EN(u"࠳࿥")]
		BVQ3UYZop90bzfAagqwFNn5r[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF] = FnBiAjthS8MkXs67W(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥ࠭ࡅ")+svejmhZS0t24bAiYuzk,[],[]
		return
	BVQ3UYZop90bzfAagqwFNn5r[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF] = yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫࠬࡆ"),[l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬ࠭ࡇ")],[zpXG3Ky6ou8ndWHkb4]
	return
def kLo7t93uF85zxGpSCWKcI6Tl4XHbOY(url,source,akVPDzJGgWi4vK3jNt0eCsuLUm9cZF):
	CCeZSJvsigLcq = fprnld4CZo(u"࠭ࠧࡈ")
	zpXG3Ky6ou8ndWHkb4 = iUeoLOsbHqP(u"ࡌࡡ࡭ࡵࡨᅇ")
	try:
		import yt_dlp as eASrkOLJogs82lIDZCjzq
		LrSAWpIKTO3ghNqzZmBevC = eASrkOLJogs82lIDZCjzq.YoutubeDL({l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧ࡯ࡱࡢࡧࡴࡲ࡯ࡳࠩࡉ"): Me28A1sBLNIgUp5YCDyvT(u"ࡔࡳࡷࡨᅈ")})
		zpXG3Ky6ou8ndWHkb4 = LrSAWpIKTO3ghNqzZmBevC.extract_info(url,download=E6MIKdpBomef(u"ࡇࡣ࡯ࡷࡪᅉ"))
	except Exception as QUsq5XR712ZifxVBFgYCkyEcP30: CCeZSJvsigLcq = str(QUsq5XR712ZifxVBFgYCkyEcP30)
	global Ls6ezt1TuoSb
	if not zpXG3Ky6ou8ndWHkb4 or YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩࡊ") not in list(zpXG3Ky6ou8ndWHkb4.keys()):
		if CCeZSJvsigLcq==XzrqbGDIy54juixkMA(u"ࠩࠪࡋ"):
			CCeZSJvsigLcq = FTYWns4Q7dSEXmBOAGlJ.format_exc()
			if CCeZSJvsigLcq!=QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠪࡒࡴࡴࡥࡕࡻࡳࡩ࠿ࠦࡎࡰࡰࡨࡠࡳ࠭ࡌ"): GGtWyVoJReUuEBCdAagiL1YXO8.stderr.write(CCeZSJvsigLcq)
		svejmhZS0t24bAiYuzk = CCeZSJvsigLcq.splitlines()[-UTelCo0ihE1d5R(u"࠴࿦")]
		Ls6ezt1TuoSb[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF] = Me28A1sBLNIgUp5YCDyvT(u"ࠫࡋࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠧࡍ")+svejmhZS0t24bAiYuzk,[],[]
	else:
		eyUmvNFiYsE,zzvBg3ShiamAZ = [],[]
		for ELbNB92cOh5dqtpVmi40kY in zpXG3Ky6ou8ndWHkb4[SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠬ࡬࡯ࡳ࡯ࡤࡸࡸ࠭ࡎ")]:
			eyUmvNFiYsE.append(ELbNB92cOh5dqtpVmi40kY[Me28A1sBLNIgUp5YCDyvT(u"࠭ࡦࡰࡴࡰࡥࡹ࠭ࡏ")])
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY[SO94xq1RAkMm2uF(u"ࠧࡶࡴ࡯ࠫࡐ")])
		Ls6ezt1TuoSb[akVPDzJGgWi4vK3jNt0eCsuLUm9cZF] = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨࠩࡑ"),eyUmvNFiYsE,zzvBg3ShiamAZ
	return
def hdeN64namS7o9IqAYOj1bXPp3(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,dshJSmRqeiP9nap2(u"ࠩࡊࡉ࡙࠭ࡒ"),url,G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠪࠫࡓ"),fprnld4CZo(u"ࠫࠬࡔ"),wRxoKs10Syj7V4edYhtP(u"ࠬ࠭ࡕ"),Me28A1sBLNIgUp5YCDyvT(u"ࡈࡤࡰࡸ࡫ᅊ"),hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡕࡉࡉࡏࡒࡆࡅࡗࡣ࡚ࡘࡌ࠮࠳ࡶࡸࠬࡖ"))
	headers = WbTGMHnDysdYZ2lFA.headers
	if FvNyZqaLKw(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩࡗ") in list(headers.keys()):
		ELbNB92cOh5dqtpVmi40kY = WbTGMHnDysdYZ2lFA.headers[l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪࡘ")]
		if dd8rHcveo7O15hT3MSR(ELbNB92cOh5dqtpVmi40kY): return iUeoLOsbHqP(u"࡙ࠩࠪ"),[sTcr7iDp5eFt4RoLMhuwq1A(u"࡚ࠪࠫ")],[ELbNB92cOh5dqtpVmi40kY]
	return hBvsQ7oCkKUdwjx58ml3EN(u"ࠫࡋࡧࡩ࡭ࡧࡧ࠾࡛ࠥࠦࠧ"),[],[]
def qqLtBwnyWV1(ppxeJaBXIurWHj):
	if E6MIKdpBomef(u"ࠬࡲࡩࡴࡶࠪ࡜") in str(type(ppxeJaBXIurWHj)):
		gI487voLsArVqW6Ffp = []
		for ELbNB92cOh5dqtpVmi40kY in ppxeJaBXIurWHj:
			if yA5z6LIXBlo41PRVMY87wOisFp(u"࠭ࡳࡵࡴࠪ࡝") in str(type(ELbNB92cOh5dqtpVmi40kY)): ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.replace(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧ࡝ࡴࠪ࡞"),Me28A1sBLNIgUp5YCDyvT(u"ࠨࠩ࡟")).replace(UTelCo0ihE1d5R(u"ࠩ࡟ࡲࠬࡠ"),UTelCo0ihE1d5R(u"ࠪࠫࡡ")).strip(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࠥ࠭ࡢ"))
			gI487voLsArVqW6Ffp.append(ELbNB92cOh5dqtpVmi40kY)
	else: gI487voLsArVqW6Ffp = ppxeJaBXIurWHj.replace(Cu1704YofAbr3QTm(u"ࠬࡢࡲࠨࡣ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࠧࡤ")).replace(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠧ࡝ࡰࠪࡥ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨࠩࡦ")).strip(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩࠣࠫࡧ"))
	return gI487voLsArVqW6Ffp
def hntfj5cOUKGbrp(gCitSRH90rUG5s72VIBcaMQv8qpf,source):
	pIkw3zMBQrHKXSOe7ig = ZcdnQAJ3ltkoiPsyX5
	data = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,zqdvcbP5L8BHh(u"ࠪࡰ࡮ࡹࡴࠨࡨ"),E6MIKdpBomef(u"ࠫࡘࡋࡒࡗࡇࡕࡗࠬࡩ"),gCitSRH90rUG5s72VIBcaMQv8qpf)
	if data:
		eyUmvNFiYsE,zzvBg3ShiamAZ = list(zip(*data))
		return eyUmvNFiYsE,zzvBg3ShiamAZ
	eyUmvNFiYsE,zzvBg3ShiamAZ,X5YHGtU28eWoSuBFOpr = [],[],[]
	for ELbNB92cOh5dqtpVmi40kY in gCitSRH90rUG5s72VIBcaMQv8qpf:
		if E6MIKdpBomef(u"ࠬ࠵࠯ࠨࡪ") not in ELbNB92cOh5dqtpVmi40kY: continue
		ooLVBfH73OqagTXS8DGKMCybiWvs,WJr6B5imnN1Cypw,type,eBjoKP40GyrEFp,dDZQSEGRTo9g85x1C = xx53V2msKlzA(ELbNB92cOh5dqtpVmi40kY,source)
		dDZQSEGRTo9g85x1C = GGvHJKP9LUxEk10Fw.findall(yA5z6LIXBlo41PRVMY87wOisFp(u"࠭࡜ࡥ࠭ࠪ࡫"),dDZQSEGRTo9g85x1C,GGvHJKP9LUxEk10Fw.DOTALL)
		if dDZQSEGRTo9g85x1C: dDZQSEGRTo9g85x1C = int(dDZQSEGRTo9g85x1C[SO94xq1RAkMm2uF(u"࠴࿧")])
		else: dDZQSEGRTo9g85x1C = E6MIKdpBomef(u"࠵࿨")
		C83UXWf15zdwLA0 = RfKuIXwPAiWtmyF(ELbNB92cOh5dqtpVmi40kY,G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠧ࡯ࡣࡰࡩࠬ࡬"))
		X5YHGtU28eWoSuBFOpr.append([ooLVBfH73OqagTXS8DGKMCybiWvs,WJr6B5imnN1Cypw,type,eBjoKP40GyrEFp,dDZQSEGRTo9g85x1C,ELbNB92cOh5dqtpVmi40kY,C83UXWf15zdwLA0])
	if X5YHGtU28eWoSuBFOpr:
		FFuzTtoAp9V4vHLIqcb03Q5MKS = sorted(X5YHGtU28eWoSuBFOpr,reverse=XzrqbGDIy54juixkMA(u"ࡗࡶࡺ࡫ᅋ"),key=lambda key: (key[QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠸࿮")],key[bUdr5Hahw6sY8xJ(u"࠰࿪")],key[xW2Arao7YVOemw(u"࠴࿫")],key[l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠴࿬")],key[FvNyZqaLKw(u"࠷࿩")],key[FnBiAjthS8MkXs67W(u"࠸࿭")],key[xW2Arao7YVOemw(u"࠻࿯")]))
		DDLUxZhd9RYfn0aHqNc6EV = []
		for WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej in FFuzTtoAp9V4vHLIqcb03Q5MKS:
			if WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej not in DDLUxZhd9RYfn0aHqNc6EV:
				DDLUxZhd9RYfn0aHqNc6EV.append(WQ6M7vlo2psd3IkhTC4Eczuyn8Ymej)
		for ooLVBfH73OqagTXS8DGKMCybiWvs,WJr6B5imnN1Cypw,type,eBjoKP40GyrEFp,dDZQSEGRTo9g85x1C,ELbNB92cOh5dqtpVmi40kY,C83UXWf15zdwLA0 in DDLUxZhd9RYfn0aHqNc6EV:
			if dDZQSEGRTo9g85x1C: dDZQSEGRTo9g85x1C = str(dDZQSEGRTo9g85x1C)
			else: dDZQSEGRTo9g85x1C = Me28A1sBLNIgUp5YCDyvT(u"ࠨࠩ࡭")
			title = dshJSmRqeiP9nap2(u"ࠩึ๎ึ็ัࠨ࡮")+Cu1704YofAbr3QTm(u"ࠪࠤࠬ࡯")+type+SO94xq1RAkMm2uF(u"ࠫࠥ࠭ࡰ")+ooLVBfH73OqagTXS8DGKMCybiWvs+fprnld4CZo(u"ࠬࠦࠧࡱ")+dDZQSEGRTo9g85x1C+bUdr5Hahw6sY8xJ(u"࠭ࠠࠨࡲ")+eBjoKP40GyrEFp+Cu1704YofAbr3QTm(u"ࠧࠡࠩࡳ")+WJr6B5imnN1Cypw
			if C83UXWf15zdwLA0 not in title: title = title+iUeoLOsbHqP(u"ࠨࠢࠪࡴ")+C83UXWf15zdwLA0
			title = title.replace(bUdr5Hahw6sY8xJ(u"ࠩࠨࠫࡵ"),UTelCo0ihE1d5R(u"ࠪࠫࡶ")).strip(dshJSmRqeiP9nap2(u"ࠫࠥ࠭ࡷ")).replace(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬࠦࠠࠨࡸ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࠠࠨࡹ")).replace(iRoLg2m47tnDATBHGCSPNyx(u"ࠧࠡࠢࠪࡺ"),SO94xq1RAkMm2uF(u"ࠨࠢࠪࡻ")).replace(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩࠣࠤࠬࡼ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠪࠤࠬࡽ"))
			if ELbNB92cOh5dqtpVmi40kY not in zzvBg3ShiamAZ:
				eyUmvNFiYsE.append(title)
				zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
		if zzvBg3ShiamAZ:
			data = list(zip(eyUmvNFiYsE,zzvBg3ShiamAZ))
			if data: Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,fprnld4CZo(u"ࠫࡘࡋࡒࡗࡇࡕࡗࠬࡾ"),gCitSRH90rUG5s72VIBcaMQv8qpf,data,pIkw3zMBQrHKXSOe7ig)
	return eyUmvNFiYsE,zzvBg3ShiamAZ
def SSFpvX9OBg2L6Yoi7mJsCWdbIPG(url):
	if sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬ࠴࡭࠴ࡷ࠻ࠫࡿ") in url:
		eyUmvNFiYsE,zzvBg3ShiamAZ = BXEJoygQHA8RZ(url)
		if zzvBg3ShiamAZ: return l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࠧࢀ"),eyUmvNFiYsE,zzvBg3ShiamAZ
		return iUeoLOsbHqP(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐ࠷࡚࠾ࠧࢁ"),[],[]
	return SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࢂ"),[UTelCo0ihE1d5R(u"ࠩࠪࢃ")],[url]
def pCYXWusGUJ(url):
	uuIjMn1YTf687WlRcOmhq4G23H,HHSO6Q4KI0hlPxYpNuXRkWCmjEgA = [],[]
	if lc0dpSmwoPDjLnk(u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶ࠲ࡲࡶ࠴ࡀࡸ࡬ࡨࡂ࠭ࢄ") in url:
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫࡌࡋࡔࠨࢅ"),url,zqdvcbP5L8BHh(u"ࠬ࠭ࢆ"),XzrqbGDIy54juixkMA(u"࠭ࠧࢇ"),UTelCo0ihE1d5R(u"ࡊࡦࡲࡳࡦᅌ"),kEhAHvti6Vnsfx(u"ࠧࠨ࢈"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡐࡇࡔࡌࡑࡘࡘࡊ࠳࠱ࡴࡶࠪࢉ"))
		if Cu1704YofAbr3QTm(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫࢊ") in WbTGMHnDysdYZ2lFA.headers:
			ELbNB92cOh5dqtpVmi40kY = WbTGMHnDysdYZ2lFA.headers[bUdr5Hahw6sY8xJ(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬࢋ")]
			uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY)
			C83UXWf15zdwLA0 = RfKuIXwPAiWtmyF(ELbNB92cOh5dqtpVmi40kY,g4g6bfkPtVGU5lIM3(u"ࠫࡳࡧ࡭ࡦࠩࢌ"))
			HHSO6Q4KI0hlPxYpNuXRkWCmjEgA.append(C83UXWf15zdwLA0)
	elif hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬࡱࡡࡵ࡭ࡲࡹࡹ࡫࠮ࡤࡱࡰࠫࢍ") in url:
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,lc0dpSmwoPDjLnk(u"࠭ࡇࡆࡖࠪࢎ"),url,SO94xq1RAkMm2uF(u"ࠧࠨ࢏"),E6MIKdpBomef(u"ࠨࠩ࢐"),zqdvcbP5L8BHh(u"ࠩࠪ࢑"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪࠫ࢒"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯࠵ࡲࡩ࠭࢓"))
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		xbjuhmSNgZ15dta0vLKFiEG4 = GGvHJKP9LUxEk10Fw.findall(zqdvcbP5L8BHh(u"ࠬ࠮ࡥࡷࡣ࡯ࡠ࠭࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡜ࠩࡲ࠯ࡥ࠱ࡩࠬ࡬࠮ࡨ࠰ࡩࡢࠩ࠯ࠬࡂࡠ࠮ࡢࠩࠪ࠰࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬ࢔"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if xbjuhmSNgZ15dta0vLKFiEG4:
			xbjuhmSNgZ15dta0vLKFiEG4 = xbjuhmSNgZ15dta0vLKFiEG4[Cu1704YofAbr3QTm(u"࠶࿰")]
			PhzBCR0GOkLx4nfuQ = p0utbN8Uw2yC3qlm96KnxeTVPAIS(xbjuhmSNgZ15dta0vLKFiEG4)
			bGt42uU18OeQ3FwxRCz5YS6v = GGvHJKP9LUxEk10Fw.findall(lc0dpSmwoPDjLnk(u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺ࠩ࡞࡞࠲࠯ࡅ࡜࡞ࠫ࠯ࠫ࢕"),PhzBCR0GOkLx4nfuQ,GGvHJKP9LUxEk10Fw.DOTALL)
			if bGt42uU18OeQ3FwxRCz5YS6v:
				bGt42uU18OeQ3FwxRCz5YS6v = bGt42uU18OeQ3FwxRCz5YS6v[Cu1704YofAbr3QTm(u"࠰࿱")]
				bGt42uU18OeQ3FwxRCz5YS6v = JKw5OWktPZB(E6MIKdpBomef(u"ࠧ࡭࡫ࡶࡸࠬ࢖"),bGt42uU18OeQ3FwxRCz5YS6v)
				for dict in bGt42uU18OeQ3FwxRCz5YS6v:
					ELbNB92cOh5dqtpVmi40kY = dict[bUdr5Hahw6sY8xJ(u"ࠨࡨ࡬ࡰࡪ࠭ࢗ")]
					dDZQSEGRTo9g85x1C = dict[p72fnFtcPix5UKwr9YNzW(u"ࠩ࡯ࡥࡧ࡫࡬ࠨ࢘")]
					uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY)
					C83UXWf15zdwLA0 = RfKuIXwPAiWtmyF(ELbNB92cOh5dqtpVmi40kY,UTelCo0ihE1d5R(u"ࠪࡲࡦࡳࡥࠨ࢙"))
					HHSO6Q4KI0hlPxYpNuXRkWCmjEgA.append(dDZQSEGRTo9g85x1C+YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࢚ࠫࠥ࠭")+C83UXWf15zdwLA0)
		elif dshJSmRqeiP9nap2(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴ࢛ࠧ") in WbTGMHnDysdYZ2lFA.headers:
			ELbNB92cOh5dqtpVmi40kY = WbTGMHnDysdYZ2lFA.headers[hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ࢜")]
			uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY)
			C83UXWf15zdwLA0 = RfKuIXwPAiWtmyF(ELbNB92cOh5dqtpVmi40kY,Cu1704YofAbr3QTm(u"ࠧ࡯ࡣࡰࡩࠬ࢝"))
			HHSO6Q4KI0hlPxYpNuXRkWCmjEgA.append(C83UXWf15zdwLA0)
		if FnBiAjthS8MkXs67W(u"ࠨࡁࡸࡶࡱࡃࡨࡵࡶࡳࡷ࠿࠵࠯ࡱࡪࡲࡸࡴࡹ࠮ࡢࡲࡳ࠲࡬ࡵ࡯ࠨ࢞") in url:
			ELbNB92cOh5dqtpVmi40kY = url.split(FnBiAjthS8MkXs67W(u"ࠩࡂࡹࡷࡲ࠽ࠨ࢟"))[g4g6bfkPtVGU5lIM3(u"࠲࿲")]
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.split(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠪࠪࠬࢠ"))[XzrqbGDIy54juixkMA(u"࠲࿳")]
			if ELbNB92cOh5dqtpVmi40kY:
				uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY)
				HHSO6Q4KI0hlPxYpNuXRkWCmjEgA.append(lc0dpSmwoPDjLnk(u"ࠫࡵ࡮࡯ࡵࡱࡶࠤ࡬ࡵ࡯ࡨ࡮ࡨࠫࢡ"))
	else:
		uuIjMn1YTf687WlRcOmhq4G23H.append(url)
		C83UXWf15zdwLA0 = RfKuIXwPAiWtmyF(url,zqdvcbP5L8BHh(u"ࠬࡴࡡ࡮ࡧࠪࢢ"))
		HHSO6Q4KI0hlPxYpNuXRkWCmjEgA.append(C83UXWf15zdwLA0)
	if not uuIjMn1YTf687WlRcOmhq4G23H: return hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡍࡄࡘࡐࡕࡕࡕࡇࠪࢣ"),[],[]
	elif len(uuIjMn1YTf687WlRcOmhq4G23H)==p72fnFtcPix5UKwr9YNzW(u"࠴࿴"): ELbNB92cOh5dqtpVmi40kY = uuIjMn1YTf687WlRcOmhq4G23H[p72fnFtcPix5UKwr9YNzW(u"࠴࿵")]
	else:
		z0jyetbQwKrIclL9vJW = D1DJtzviFZSrA(p72fnFtcPix5UKwr9YNzW(u"ࠧฤะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬࢤ"),HHSO6Q4KI0hlPxYpNuXRkWCmjEgA)
		if z0jyetbQwKrIclL9vJW==-sTcr7iDp5eFt4RoLMhuwq1A(u"࠶࿶"): return Cu1704YofAbr3QTm(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ࢥ"),[],[]
		ELbNB92cOh5dqtpVmi40kY = uuIjMn1YTf687WlRcOmhq4G23H[z0jyetbQwKrIclL9vJW]
	return XzrqbGDIy54juixkMA(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࢦ"),[kEhAHvti6Vnsfx(u"ࠪࠫࢧ")],[ELbNB92cOh5dqtpVmi40kY]
def ZZY5h4oRSuKW0vgsnqiw1l6XDNM(url):
	headers = {E6MIKdpBomef(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨࢨ"):FvNyZqaLKw(u"ࠬࡑ࡯ࡥ࡫࠲ࠫࢩ")+str(yMvF9GoTjhU5biA)}
	for CQMipytPbq in range(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠻࠰࿷")):
		MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠰࠯࠳࠳࠴࿸"))
		WbTGMHnDysdYZ2lFA = mIZr8L4njqgR(wRxoKs10Syj7V4edYhtP(u"࠭ࡇࡆࡖࠪࢪ"),url,oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧࠨࢫ"),headers,yA5z6LIXBlo41PRVMY87wOisFp(u"ࡋࡧ࡬ࡴࡧᅍ"),zqdvcbP5L8BHh(u"ࠨࠩࢬ"),FnBiAjthS8MkXs67W(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕ࠯࠴ࡷࡹ࠭ࢭ"))
		if SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬࢮ") in list(WbTGMHnDysdYZ2lFA.headers.keys()):
			ELbNB92cOh5dqtpVmi40kY = WbTGMHnDysdYZ2lFA.headers[zqdvcbP5L8BHh(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ࢯ")]
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+g4g6bfkPtVGU5lIM3(u"ࠬࢂࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫࢰ")+headers[fprnld4CZo(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪࢱ")]
			return hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠧࠨࢲ"),[LiRcTVUWuth70DmPy(u"ࠨࠩࢳ")],[ELbNB92cOh5dqtpVmi40kY]
		if WbTGMHnDysdYZ2lFA.code!=S4SOKF2QbBhjCd3RrVMuHIzE(u"࠵࠴࠼࿹"): break
	return YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡌࡕࡏࡈࡎࡈ࡙ࡘࡋࡒࡄࡑࡑࡘࡊࡔࡔࠨࢴ"),[],[]
def Ijg51tcCLBzpvyxGAVXul(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,iRoLg2m47tnDATBHGCSPNyx(u"ࠪࡋࡊ࡚ࠧࢵ"),url,SO94xq1RAkMm2uF(u"ࠫࠬࢶ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠬ࠭ࢷ"),Cu1704YofAbr3QTm(u"࠭ࠧࢸ"),Cu1704YofAbr3QTm(u"ࠧࠨࢹ"),dshJSmRqeiP9nap2(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡕࡎࡏࡕࡑࡖࡋࡔࡕࡇࡍࡇ࠰࠵ࡸࡺࠧࢺ"))
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(LiRcTVUWuth70DmPy(u"ࠩࠥࠬ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡼࡩࡥࡧࡲ࠱ࡩࡵࡷ࡯࡮ࡲࡥࡩࡹ࠮ࠫࡁࠬࠦ࠱࠴ࠪࡀ࠮࠱࠮ࡄ࠲ࠨ࠯ࠬࡂ࠭࠱࠭ࢻ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if ELbNB92cOh5dqtpVmi40kY:
		ELbNB92cOh5dqtpVmi40kY,dDZQSEGRTo9g85x1C = ELbNB92cOh5dqtpVmi40kY[Me28A1sBLNIgUp5YCDyvT(u"࠲࿺")]
		return kEhAHvti6Vnsfx(u"ࠪࠫࢼ"),[dDZQSEGRTo9g85x1C],[ELbNB92cOh5dqtpVmi40kY]
	return UTelCo0ihE1d5R(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡐࡉࡑࡗࡓࡘࡍࡏࡐࡉࡏࡉࠬࢽ"),[],[]
def hGZraoJ5gw(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,dshJSmRqeiP9nap2(u"ࠬࡍࡅࡕࠩࢾ"),url,l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࠧࢿ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧࠨࣀ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࠩࣁ"),FnBiAjthS8MkXs67W(u"ࠩࠪࣂ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡕࡈࡐࡍࡊ࠱࠮࠳ࡶࡸࠬࣃ"))
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	BBlXpmUyhFDwNtCVAHoE = Us3m2wZCVWHruY(BBlXpmUyhFDwNtCVAHoE)
	ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫࠧ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬࣄ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if ELbNB92cOh5dqtpVmi40kY: return xW2Arao7YVOemw(u"ࠬ࠭ࣅ"),[dshJSmRqeiP9nap2(u"࠭ࠧࣆ")],[ELbNB92cOh5dqtpVmi40kY[iUeoLOsbHqP(u"࠳࿻")]]
	return sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡉࡅࡘࡋࡌࡉࡆ࠴ࠫࣇ"),[],[]
def dJr4nDP9y3(url):
	if g4g6bfkPtVGU5lIM3(u"ࠨ࠱ࡧࡳࡼࡴ࠮ࡱࡪࡳࠫࣈ") in url:
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,LiRcTVUWuth70DmPy(u"ࠩࡊࡉ࡙࠭ࣉ"),url,Me28A1sBLNIgUp5YCDyvT(u"ࠪࠫ࣊"),LiRcTVUWuth70DmPy(u"ࠫࠬ࣋"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠬ࠭࣌"),sTcr7iDp5eFt4RoLMhuwq1A(u"࠭ࠧ࣍"),dshJSmRqeiP9nap2(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡗࡍࡕࡆࡉࡃ࠰࠵ࡸࡺࠧ࣎"))
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(FnBiAjthS8MkXs67W(u"ࠨࡸ࡬ࡨࡪࡵ࠭ࡸࡴࡤࡴࡵ࡫ࡲ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅ࣏ࠩࠣࠩ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		url = ELbNB92cOh5dqtpVmi40kY[g4g6bfkPtVGU5lIM3(u"࠴࿼")]
	return FnBiAjthS8MkXs67W(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗ࣐ࠬ"),[iRoLg2m47tnDATBHGCSPNyx(u"࣑ࠪࠫ")],[url]
def Zb7u6XoB1m(url):
	if S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࡸ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࠨ࣒") in url:
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,xW2Arao7YVOemw(u"ࠬࡍࡅࡕ࣓ࠩ"),url,iRoLg2m47tnDATBHGCSPNyx(u"࠭ࠧࣔ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧࠨࣕ"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠨࠩࣖ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠩࠪࣗ"),iUeoLOsbHqP(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄ࠸࡚࠳࠱ࡴࡶࠪࣘ"))
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(iRoLg2m47tnDATBHGCSPNyx(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩࣙ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY[hBvsQ7oCkKUdwjx58ml3EN(u"࠵࿽")]
		if pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬ࡮ࡴࡵࡲࠪࣚ") in ELbNB92cOh5dqtpVmi40kY: return xW2Arao7YVOemw(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࣛ"),[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࠨࣜ")],[ELbNB92cOh5dqtpVmi40kY]
		return zqdvcbP5L8BHh(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡇࡎࡓࡁ࠵ࡗࠪࣝ"),[],[]
	return G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࣞ"),[FnBiAjthS8MkXs67W(u"ࠪࠫࣟ")],[url]
def X89TQqW1jf(url):
	dR2vHyAtl8pJN1,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = xlk0nsAXjIrvOQFL4Vi1MJG5TChu(url)
	BBYvCiQGe8RdpyAagfS72mZclxb5 = {lc0dpSmwoPDjLnk(u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ࣠"):Cu1704YofAbr3QTm(u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭࣡"),kEhAHvti6Vnsfx(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ࣢"):dshJSmRqeiP9nap2(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࣣࠧ")}
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,FnBiAjthS8MkXs67W(u"ࠨࡒࡒࡗ࡙࠭ࣤ"),dR2vHyAtl8pJN1,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩࠪࣥ"),bUdr5Hahw6sY8xJ(u"ࣦࠪࠫ"),SO94xq1RAkMm2uF(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡒࡔ࡝࠭࠲ࡵࡷࠫࣧ"))
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪࣨ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not ELbNB92cOh5dqtpVmi40kY: return oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡊ࡝ࡓࡕࡗࠨࣩ"),[],[]
	ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY[G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠶࿾")]
	return wRxoKs10Syj7V4edYhtP(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ࣪"),[bUdr5Hahw6sY8xJ(u"ࠨࠩ࣫")],[ELbNB92cOh5dqtpVmi40kY]
def qqBmVUYNIA(url):
	headers = {UTelCo0ihE1d5R(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ࣬"):bUdr5Hahw6sY8xJ(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷ࣭ࠫ")}
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,hBvsQ7oCkKUdwjx58ml3EN(u"ࠫࡌࡋࡔࠨ࣮"),url,fprnld4CZo(u"࣯ࠬ࠭"),headers,wRxoKs10Syj7V4edYhtP(u"ࣰ࠭ࠧ"),Cu1704YofAbr3QTm(u"ࠧࠨࣱ"),wRxoKs10Syj7V4edYhtP(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡎࡏࡐࡈࡓࡖࡔ࠳࠱ࡴࡶࣲࠪ"))
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(g4g6bfkPtVGU5lIM3(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧࣳ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.IGNORECASE)
	if not ELbNB92cOh5dqtpVmi40kY: return pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡙ࠥࡈࡐࡑࡉࡔࡗࡕࠧࣴ"),[],[]
	ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY[SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠰࿿")]
	return pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧࣵ"),[lc0dpSmwoPDjLnk(u"ࣶࠬ࠭")],[ELbNB92cOh5dqtpVmi40kY]
def osBuzptTmE(url):
	dR2vHyAtl8pJN1,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = xlk0nsAXjIrvOQFL4Vi1MJG5TChu(url)
	BBYvCiQGe8RdpyAagfS72mZclxb5 = {XzrqbGDIy54juixkMA(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬࣷ"):UTelCo0ihE1d5R(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧࣸ")}
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨࡒࡒࡗ࡙ࣹ࠭"),dR2vHyAtl8pJN1,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,SO94xq1RAkMm2uF(u"ࣺࠩࠪ"),p72fnFtcPix5UKwr9YNzW(u"ࠪࠫࣻ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡉࡃࡏࡅࡈࡏࡍࡂ࠯࠴ࡷࡹ࠭ࣼ"))
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(SO94xq1RAkMm2uF(u"ࠬ࠭ࠧ࠽࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࡡࠢࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤࠪࡡࠬ࠭ࠧࣽ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.IGNORECASE)
	if not ELbNB92cOh5dqtpVmi40kY: return iUeoLOsbHqP(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡊࡄࡐࡆࡉࡉࡎࡃࠪࣾ"),[],[]
	ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY[oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠱က")]
	if LiRcTVUWuth70DmPy(u"ࠧࡩࡶࡷࡴࠬࣿ") not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨࡪࡷࡸࡵࡀࠧऀ")+ELbNB92cOh5dqtpVmi40kY
	return g4g6bfkPtVGU5lIM3(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬँ"),[iRoLg2m47tnDATBHGCSPNyx(u"ࠪࠫं")],[ELbNB92cOh5dqtpVmi40kY]
def SMNu2OETbA(url):
	E2EhMuOLdF08Pz75jDKS14cfYNxy,HHSO6Q4KI0hlPxYpNuXRkWCmjEgA,uuIjMn1YTf687WlRcOmhq4G23H = url,[],[]
	if SO94xq1RAkMm2uF(u"ࠫ࠴ࡧࡪࡢࡺ࠲ࠫः") in url:
		dR2vHyAtl8pJN1,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = xlk0nsAXjIrvOQFL4Vi1MJG5TChu(url)
		BBYvCiQGe8RdpyAagfS72mZclxb5 = {LiRcTVUWuth70DmPy(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫऄ"):YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭अ")}
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,fprnld4CZo(u"ࠧࡑࡑࡖࡘࠬआ"),dR2vHyAtl8pJN1,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠨࠩइ"),fprnld4CZo(u"ࠩࠪई"),XzrqbGDIy54juixkMA(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡅࡇࡊࡏ࠮࠳ࡶࡸࠬउ"))
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		fbt2z8IFXaDclZhGQ4io = GGvHJKP9LUxEk10Fw.findall(FvNyZqaLKw(u"ࠫࠬ࠭࠼ࡪࡨࡵࡥࡲ࡫࠮ࠫࡁࡶࡶࡨࡃ࡛ࠣࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࠫࡢ࠭ࠧࠨऊ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.IGNORECASE)
		if fbt2z8IFXaDclZhGQ4io: E2EhMuOLdF08Pz75jDKS14cfYNxy = fbt2z8IFXaDclZhGQ4io[dshJSmRqeiP9nap2(u"࠲ခ")]
	return UTelCo0ihE1d5R(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨऋ"),[G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠭ࠧऌ")],[E2EhMuOLdF08Pz75jDKS14cfYNxy]
def PMfc9b4vXp(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,FvNyZqaLKw(u"ࠧࡈࡇࡗࠫऍ"),url,wRxoKs10Syj7V4edYhtP(u"ࠨࠩऎ"),bUdr5Hahw6sY8xJ(u"ࠩࠪए"),zqdvcbP5L8BHh(u"ࠪࠫऐ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫࠬऑ"),iRoLg2m47tnDATBHGCSPNyx(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡖ࡙ࡊ࡚ࡔ࠭࠲ࡵࡷࠫऒ"))
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	n5jroYmwhSxNCf4KMu6b18L9qze = GGvHJKP9LUxEk10Fw.findall(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࡶࡢࡴࠣࡪࡸ࡫ࡲࡷࠢࡀ࠲࠯ࡅࠧࠩ࠰࠭ࡃ࠮࠭ࠢओ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.IGNORECASE)
	if n5jroYmwhSxNCf4KMu6b18L9qze:
		n5jroYmwhSxNCf4KMu6b18L9qze = n5jroYmwhSxNCf4KMu6b18L9qze[UTelCo0ihE1d5R(u"࠳ဂ")][iRoLg2m47tnDATBHGCSPNyx(u"࠶ဃ"):]
		n5jroYmwhSxNCf4KMu6b18L9qze = hNe0ECZHr9B6.b64decode(n5jroYmwhSxNCf4KMu6b18L9qze)
		if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: n5jroYmwhSxNCf4KMu6b18L9qze = n5jroYmwhSxNCf4KMu6b18L9qze.decode(XzrqbGDIy54juixkMA(u"ࠧࡶࡶࡩ࠼ࠬऔ"))
		ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(g4g6bfkPtVGU5lIM3(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭क"),n5jroYmwhSxNCf4KMu6b18L9qze,GGvHJKP9LUxEk10Fw.DOTALL)
	else: ELbNB92cOh5dqtpVmi40kY = g4g6bfkPtVGU5lIM3(u"ࠩࠪख")
	if not ELbNB92cOh5dqtpVmi40kY: return sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡚ࠥࡖࡇࡗࡑࠫग"),[],[]
	ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY[zqdvcbP5L8BHh(u"࠵င")]
	if E6MIKdpBomef(u"ࠫ࡭ࡺࡴࡱࠩघ") not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬ࡮ࡴࡵࡲ࠽ࠫङ")+ELbNB92cOh5dqtpVmi40kY
	return Me28A1sBLNIgUp5YCDyvT(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩच"),[fprnld4CZo(u"ࠧࠨछ")],[ELbNB92cOh5dqtpVmi40kY]
def o3oR5Z61GyxavgupWP(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,lc0dpSmwoPDjLnk(u"ࠨࡉࡈࡘࠬज"),url,sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩࠪझ"),FvNyZqaLKw(u"ࠪࠫञ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠫࠬट"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠬ࠭ठ"),SO94xq1RAkMm2uF(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐ࡝ࡊࡍ࡙ࡗࡋࡓ࠱࠶ࡹࡴࠨड"))
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱ࡯࠱ࡸࡳ࠭࠲࠴ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬढ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not ELbNB92cOh5dqtpVmi40kY: return dshJSmRqeiP9nap2(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑ࡞ࡋࡇ࡚ࡘࡌࡔࠬण"),[],[]
	ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY[QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠶စ")]
	return xW2Arao7YVOemw(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬत"),[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪࠫथ")],[ELbNB92cOh5dqtpVmi40kY]
def Xswr3uEckt(url):
	id = url.split(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫ࠴࠭द"))[-p72fnFtcPix5UKwr9YNzW(u"࠱ဆ")]
	if SO94xq1RAkMm2uF(u"ࠬ࠵ࡥ࡮ࡤࡨࡨࠬध") in url: url = url.replace(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠭न"),FvNyZqaLKw(u"ࠧࠨऩ"))
	url = url.replace(fprnld4CZo(u"ࠨ࠰ࡦࡳࡲ࠵ࠧप"),g4g6bfkPtVGU5lIM3(u"ࠩ࠱ࡧࡴࡳ࠯ࡱ࡮ࡤࡽࡪࡸ࠯࡮ࡧࡷࡥࡩࡧࡴࡢ࠱ࠪफ"))
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,xW2Arao7YVOemw(u"ࠪࡋࡊ࡚ࠧब"),url,xW2Arao7YVOemw(u"ࠫࠬभ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬ࠭म"),XzrqbGDIy54juixkMA(u"࠭ࠧय"),g4g6bfkPtVGU5lIM3(u"ࠧࠨर"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࠴ࡷࡹ࠭ऱ"))
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	svejmhZS0t24bAiYuzk = hBvsQ7oCkKUdwjx58ml3EN(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩल")
	QUsq5XR712ZifxVBFgYCkyEcP30 = GGvHJKP9LUxEk10Fw.findall(LiRcTVUWuth70DmPy(u"ࠪࠦࡪࡸࡲࡰࡴࠥ࠲࠯ࡅࠢ࡮ࡧࡶࡷࡦ࡭ࡥࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫळ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if QUsq5XR712ZifxVBFgYCkyEcP30: svejmhZS0t24bAiYuzk = QUsq5XR712ZifxVBFgYCkyEcP30[S4SOKF2QbBhjCd3RrVMuHIzE(u"࠱ဇ")]
	url = GGvHJKP9LUxEk10Fw.findall(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫࡽ࠳࡭ࡱࡧࡪ࡙ࡗࡒࠢ࠭ࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨऴ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not url and svejmhZS0t24bAiYuzk:
		return svejmhZS0t24bAiYuzk,[],[]
	ELbNB92cOh5dqtpVmi40kY = url[XzrqbGDIy54juixkMA(u"࠲ဈ")].replace(hBvsQ7oCkKUdwjx58ml3EN(u"ࠬࡢ࡜ࠨव"),S4SOKF2QbBhjCd3RrVMuHIzE(u"࠭ࠧश"))
	gRVtlOdFCSG8p1UjmPD,gCitSRH90rUG5s72VIBcaMQv8qpf = BXEJoygQHA8RZ(ELbNB92cOh5dqtpVmi40kY)
	X5byeYgp1hrD0jGKf7wNUT2ZmquI = GGvHJKP9LUxEk10Fw.findall(XzrqbGDIy54juixkMA(u"ࠧࠣࡱࡺࡲࡪࡸࠢ࠻ࡽࠥ࡭ࡩࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࡶࡧࡷ࡫ࡥ࡯ࡰࡤࡱࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨष"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if X5byeYgp1hrD0jGKf7wNUT2ZmquI: fRQbXpEl1eoNJ5nDPVAkZx72T0,Azfxil4CX1wL,UoEJHpds26YyfnST5FirD3WZKgMbwL = X5byeYgp1hrD0jGKf7wNUT2ZmquI[UTelCo0ihE1d5R(u"࠳ဉ")]
	else: fRQbXpEl1eoNJ5nDPVAkZx72T0,Azfxil4CX1wL,UoEJHpds26YyfnST5FirD3WZKgMbwL = Me28A1sBLNIgUp5YCDyvT(u"ࠨࠩस"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࠪह"),LiRcTVUWuth70DmPy(u"ࠪࠫऺ")
	UoEJHpds26YyfnST5FirD3WZKgMbwL = UoEJHpds26YyfnST5FirD3WZKgMbwL.replace(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫࡡ࠵ࠧऻ"),iRoLg2m47tnDATBHGCSPNyx(u"ࠬ࠵़ࠧ"))
	Azfxil4CX1wL = ptMqV54oKJhQ8CH(Azfxil4CX1wL)
	eyUmvNFiYsE = [xW2Arao7YVOemw(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡑ࡚ࡒࡊࡘ࠺ࠡࠢࠪऽ")+Azfxil4CX1wL+YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩा")]+gRVtlOdFCSG8p1UjmPD
	zzvBg3ShiamAZ = [UoEJHpds26YyfnST5FirD3WZKgMbwL]+gCitSRH90rUG5s72VIBcaMQv8qpf
	z0jyetbQwKrIclL9vJW = D1DJtzviFZSrA(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠠࠩࠩि")+str(len(zzvBg3ShiamAZ)-fprnld4CZo(u"࠵ည"))+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"้้ࠩࠣ็ࠩࠨी"),eyUmvNFiYsE)
	if z0jyetbQwKrIclL9vJW==-QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠶ဋ"): return S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨु"),[],[]
	elif z0jyetbQwKrIclL9vJW==Cu1704YofAbr3QTm(u"࠶ဌ"):
		mzGeIvQtoSATpH392 = GGtWyVoJReUuEBCdAagiL1YXO8.argv[FvNyZqaLKw(u"࠰ဍ")]+E6MIKdpBomef(u"ࠫࡄࡺࡹࡱࡧࡀࡪࡴࡲࡤࡦࡴࠩࡱࡴࡪࡥ࠾࠶࠳࠶ࠫࡻࡲ࡭࠿ࠪू")+UoEJHpds26YyfnST5FirD3WZKgMbwL+fprnld4CZo(u"ࠬࠬࡴࡦࡺࡷࡸࡂ࠭ृ")+Azfxil4CX1wL
		cEZpW924rqNYm5.executebuiltin(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠪࠥॄ")+mzGeIvQtoSATpH392+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠢࠪࠤॅ"))
		return G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ॆ"),[],[]
	ELbNB92cOh5dqtpVmi40kY =  zzvBg3ShiamAZ[z0jyetbQwKrIclL9vJW]
	return Me28A1sBLNIgUp5YCDyvT(u"ࠩࠪे"),[UTelCo0ihE1d5R(u"ࠪࠫै")],[ELbNB92cOh5dqtpVmi40kY]
def PJsSdvbghy(ELbNB92cOh5dqtpVmi40kY):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,E6MIKdpBomef(u"ࠫࡌࡋࡔࠨॉ"),ELbNB92cOh5dqtpVmi40kY,xW2Arao7YVOemw(u"ࠬ࠭ॊ"),iUeoLOsbHqP(u"࠭ࠧो"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࠨौ"),g4g6bfkPtVGU5lIM3(u"ࠨ्ࠩ"),p72fnFtcPix5UKwr9YNzW(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈࡏࡌࡔࡄ࠱࠶ࡹࡴࠨॎ"))
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	if dshJSmRqeiP9nap2(u"ࠪ࠲࡯ࡹ࡯࡯ࠩॏ") in ELbNB92cOh5dqtpVmi40kY: url = GGvHJKP9LUxEk10Fw.findall(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࠧࡹࡲࡤࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫॐ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	else: url = GGvHJKP9LUxEk10Fw.findall(Me28A1sBLNIgUp5YCDyvT(u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ॑"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not url: return FnBiAjthS8MkXs67W(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡄࡒࡏࡗࡇ॒ࠧ"),[],[]
	url = url[Me28A1sBLNIgUp5YCDyvT(u"࠱ဎ")]
	if G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠧࡩࡶࡷࡴࠬ॓") not in url: url = xW2Arao7YVOemw(u"ࠨࡪࡷࡸࡵࡀࠧ॔")+url
	return YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩࠪॕ"),[FnBiAjthS8MkXs67W(u"ࠪࠫॖ")],[url]
def UYbpHGsed0fihgtDQ6n(url):
	headers = { sTcr7iDp5eFt4RoLMhuwq1A(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨॗ") : iUeoLOsbHqP(u"ࠬ࠭क़") }
	if S4SOKF2QbBhjCd3RrVMuHIzE(u"࠭࡯ࡱ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡴࡸࡩࡨࠩख़") in url:
		BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(xh9BXlAw0UoVsIZ4if3,url,xW2Arao7YVOemw(u"ࠧࠨग़"),headers,SO94xq1RAkMm2uF(u"ࠨࠩज़"),kEhAHvti6Vnsfx(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠲ࡵࡷࠫड़"))
		items = GGvHJKP9LUxEk10Fw.findall(Me28A1sBLNIgUp5YCDyvT(u"ࠪࡨ࡮ࡸࡥࡤࡶࠣࡰ࡮ࡴ࡫࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩढ़"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if items: return lc0dpSmwoPDjLnk(u"ࠫࠬफ़"),[LiRcTVUWuth70DmPy(u"ࠬ࠭य़")],[items[Cu1704YofAbr3QTm(u"࠲ဏ")]]
		else:
			LpdKxnIsY3Sy6qP = GGvHJKP9LUxEk10Fw.findall(bUdr5Hahw6sY8xJ(u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡥࡳࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫॠ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
			if LpdKxnIsY3Sy6qP:
				aHKzv76JCVnprbY8w(LiRcTVUWuth70DmPy(u"ࠧࠨॡ"),Me28A1sBLNIgUp5YCDyvT(u"ࠨࠩॢ"),Cu1704YofAbr3QTm(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊วึๆํࠫॣ"),LpdKxnIsY3Sy6qP[E6MIKdpBomef(u"࠳တ")])
				return pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࠫ।")+LpdKxnIsY3Sy6qP[fprnld4CZo(u"࠴ထ")],[],[]
	else:
		RuWUKQylsNvOH7SpiL59nYP3rA = hBvsQ7oCkKUdwjx58ml3EN(u"ࠫࡲࡵࡶࡪࡼ࡯ࡥࡳࡪࠧ॥")
		BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(xh9BXlAw0UoVsIZ4if3,url,SO94xq1RAkMm2uF(u"ࠬ࠭०"),headers,oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠭ࠧ१"),LiRcTVUWuth70DmPy(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡙ࡈࡂࡊࡇࡅ࠲࠸࡮ࡥࠩ२"))
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall(LiRcTVUWuth70DmPy(u"ࠨࡈࡲࡶࡲࠦ࡭ࡦࡶ࡫ࡳࡩࡃࠢࡑࡑࡖࡘࠧࠦࡡࡤࡶ࡬ࡳࡳࡃ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪ३"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if not EeQqAGc0W5r6nlBbChwfZL: return E6MIKdpBomef(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡓࡉࡃࡋࡈࡆ࠭४"),[],[]
		E2EhMuOLdF08Pz75jDKS14cfYNxy = EeQqAGc0W5r6nlBbChwfZL[oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠵ဒ")][oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠵ဒ")]
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[zqdvcbP5L8BHh(u"࠰န")][UTelCo0ihE1d5R(u"࠷ဓ")]
		if kEhAHvti6Vnsfx(u"ࠪ࠲ࡷࡧࡲࠨ५") in UCEFMfKbgpd or yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫ࠳ࢀࡩࡱࠩ६") in UCEFMfKbgpd: return pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡓࡏࡔࡊࡄࡌࡉࡇࠠࡏࡱࡷࠤࡦࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠪ७"),[],[]
		items = GGvHJKP9LUxEk10Fw.findall(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭࡮ࡢ࡯ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ८"),UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		vpWXJDC4lTByaqcn56OFwUmieV = {}
		for WJr6B5imnN1Cypw,hieW1zRUG5w9AykJjv0X in items:
			vpWXJDC4lTByaqcn56OFwUmieV[WJr6B5imnN1Cypw] = hieW1zRUG5w9AykJjv0X
		data = Hym17NopzZUE3xhYMe(vpWXJDC4lTByaqcn56OFwUmieV)
		BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(xh9BXlAw0UoVsIZ4if3,E2EhMuOLdF08Pz75jDKS14cfYNxy,data,headers,xW2Arao7YVOemw(u"ࠧࠨ९"),FvNyZqaLKw(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠳ࡳࡦࠪ॰"))
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall(hBvsQ7oCkKUdwjx58ml3EN(u"ࠩࡇࡳࡼࡴ࡬ࡰࡣࡧࠤ࡛࡯ࡤࡦࡱ࠱࠮ࡄ࡭ࡥࡵ࡞ࠫࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠴ࠪࡀࡵࡲࡹࡷࡩࡥࡴ࠼ࠫ࠲࠯ࡅࠩࡪ࡯ࡤ࡫ࡪࡀࠧॱ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if not EeQqAGc0W5r6nlBbChwfZL: return XzrqbGDIy54juixkMA(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡏࡔࡊࡄࡌࡉࡇࠧॲ"),[],[]
		download = EeQqAGc0W5r6nlBbChwfZL[dshJSmRqeiP9nap2(u"࠱ပ")][dshJSmRqeiP9nap2(u"࠱ပ")]
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[lc0dpSmwoPDjLnk(u"࠳ဗ")][S4SOKF2QbBhjCd3RrVMuHIzE(u"࠳ဖ")]
		items = GGvHJKP9LUxEk10Fw.findall(E6MIKdpBomef(u"ࠫ࡫࡯࡬ࡦ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠰ࡱࡧࡢࡦ࡮࠽ࠦ࠳࠰࠿ࠣࡾࠬࠫॳ"),UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		pnOTgyAIevsrkqVch,eyUmvNFiYsE,BBvfW05P4wUs9Nlkjqyd6gnaAC,zzvBg3ShiamAZ,sOB2jqeMrKTUnNy3iAZbH9Ld5xmo = [],[],[],[],[]
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			if FnBiAjthS8MkXs67W(u"ࠬ࠴࡭࠴ࡷ࠻ࠫॴ") in ELbNB92cOh5dqtpVmi40kY:
				pnOTgyAIevsrkqVch,BBvfW05P4wUs9Nlkjqyd6gnaAC = BXEJoygQHA8RZ(ELbNB92cOh5dqtpVmi40kY)
				zzvBg3ShiamAZ = zzvBg3ShiamAZ + BBvfW05P4wUs9Nlkjqyd6gnaAC
				if pnOTgyAIevsrkqVch[g4g6bfkPtVGU5lIM3(u"࠴ဘ")]==FvNyZqaLKw(u"࠭࠭࠲ࠩॵ"): eyUmvNFiYsE.append(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࠡีํีๆืࠠฯษุࠤࠬॶ")+wRxoKs10Syj7V4edYhtP(u"ࠨ࡯࠶ࡹ࠽ࠦࠧॷ")+RuWUKQylsNvOH7SpiL59nYP3rA)
				else:
					for title in pnOTgyAIevsrkqVch:
						eyUmvNFiYsE.append(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩࠣื๏ืแาࠢัหฺࠦࠧॸ")+kEhAHvti6Vnsfx(u"ࠪࡱ࠸ࡻ࠸ࠡࠩॹ")+RuWUKQylsNvOH7SpiL59nYP3rA+SO94xq1RAkMm2uF(u"ࠫࠥ࠭ॺ")+title)
			else:
				title = title.replace(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬ࠲࡬ࡢࡤࡨࡰ࠿ࠨࠧॻ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭ࠧॼ"))
				title = title.strip(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧࠣࠩॽ"))
				title = LiRcTVUWuth70DmPy(u"ࠨࠢึ๎ึ็ัࠡࠢัหฺࠦࠧॾ")+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࠣࡱࡵ࠺ࠠࠨॿ")+RuWUKQylsNvOH7SpiL59nYP3rA+bUdr5Hahw6sY8xJ(u"ࠪࠤࠬঀ")+title
				eyUmvNFiYsE.append(title)
				zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
		ELbNB92cOh5dqtpVmi40kY = G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴࡯࡯࡮࡬ࡲࡪ࠭ঁ") + download
		BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(xh9BXlAw0UoVsIZ4if3,ELbNB92cOh5dqtpVmi40kY,Cu1704YofAbr3QTm(u"ࠬ࠭ং"),headers,hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࠧঃ"),p72fnFtcPix5UKwr9YNzW(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡙ࡈࡂࡊࡇࡅ࠲࠻ࡴࡩࠩ঄"))
		items = GGvHJKP9LUxEk10Fw.findall(zqdvcbP5L8BHh(u"ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡺ࡮ࡪࡥࡰ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬ࠰ࠧঅ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		for id,VRnfEFmJzUrSljM8,hash,uLB6kAt7dfNarSJWUCy in items:
			title = sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩࠣื๏ืแาࠢอั๊๐ไࠡะสูࠥ࠭আ")+fprnld4CZo(u"ࠪࠤࡲࡶ࠴ࠡࠩই")+RuWUKQylsNvOH7SpiL59nYP3rA+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࠥ࠭ঈ")+uLB6kAt7dfNarSJWUCy.split(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠬࡾࠧউ"))[bUdr5Hahw6sY8xJ(u"࠶မ")]
			ELbNB92cOh5dqtpVmi40kY = SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࠯ࡱࡱࡰ࡮ࡴࡥ࠰ࡦ࡯ࡃࡴࡶ࠽ࡥࡱࡺࡲࡱࡵࡡࡥࡡࡲࡶ࡮࡭ࠦࡪࡦࡀࠫঊ")+id+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧࠧ࡯ࡲࡨࡪࡃࠧঋ")+VRnfEFmJzUrSljM8+Me28A1sBLNIgUp5YCDyvT(u"ࠨࠨ࡫ࡥࡸ࡮࠽ࠨঌ")+hash
			sOB2jqeMrKTUnNy3iAZbH9Ld5xmo.append(uLB6kAt7dfNarSJWUCy)
			eyUmvNFiYsE.append(title)
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
		sOB2jqeMrKTUnNy3iAZbH9Ld5xmo = set(sOB2jqeMrKTUnNy3iAZbH9Ld5xmo)
		cedTZnBYxH2QNOysaWIw8zUXL,Xj5EbaB0lRp1oTIQ = [],[]
		for title in eyUmvNFiYsE:
			hIkZC1KLl25AW = GGvHJKP9LUxEk10Fw.findall(iRoLg2m47tnDATBHGCSPNyx(u"ࠤࠣࠬࡡࡪࠪࡹࡾ࡟ࡨ࠯࠯ࠦࠧࠤ঍"),title+g4g6bfkPtVGU5lIM3(u"ࠪࠪࠫ࠭঎"),GGvHJKP9LUxEk10Fw.DOTALL)
			for uLB6kAt7dfNarSJWUCy in sOB2jqeMrKTUnNy3iAZbH9Ld5xmo:
				if hIkZC1KLl25AW[iUeoLOsbHqP(u"࠶ယ")] in uLB6kAt7dfNarSJWUCy:
					title = title.replace(hIkZC1KLl25AW[SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠱လ")],uLB6kAt7dfNarSJWUCy.split(hBvsQ7oCkKUdwjx58ml3EN(u"ࠫࡽ࠭এ"))[SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠱ရ")])
			cedTZnBYxH2QNOysaWIw8zUXL.append(title)
		for umP72LtwzUTWHFAlJVyheEp5 in range(len(zzvBg3ShiamAZ)):
			items = GGvHJKP9LUxEk10Fw.findall(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࠬࠦࠩ࠰࠭ࡃ࠮࠮࡜ࡥࠬࠬࠪࠫࠨঐ"),bUdr5Hahw6sY8xJ(u"࠭ࠦࠧࠩ঑")+cedTZnBYxH2QNOysaWIw8zUXL[umP72LtwzUTWHFAlJVyheEp5]+LiRcTVUWuth70DmPy(u"ࠧࠧࠨࠪ঒"),GGvHJKP9LUxEk10Fw.DOTALL)
			Xj5EbaB0lRp1oTIQ.append( [cedTZnBYxH2QNOysaWIw8zUXL[umP72LtwzUTWHFAlJVyheEp5],zzvBg3ShiamAZ[umP72LtwzUTWHFAlJVyheEp5],items[FnBiAjthS8MkXs67W(u"࠳သ")][FnBiAjthS8MkXs67W(u"࠳သ")],items[FnBiAjthS8MkXs67W(u"࠳သ")][SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠳ဝ")]] )
		Xj5EbaB0lRp1oTIQ = sorted(Xj5EbaB0lRp1oTIQ, key=lambda kH2pUF40DrLlqiPhM9wtKc: kH2pUF40DrLlqiPhM9wtKc[S4SOKF2QbBhjCd3RrVMuHIzE(u"࠷ဟ")], reverse=iRoLg2m47tnDATBHGCSPNyx(u"࡚ࡲࡶࡧᅎ"))
		Xj5EbaB0lRp1oTIQ = sorted(Xj5EbaB0lRp1oTIQ, key=lambda kH2pUF40DrLlqiPhM9wtKc: kH2pUF40DrLlqiPhM9wtKc[pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠷ဠ")], reverse=sTcr7iDp5eFt4RoLMhuwq1A(u"ࡆࡢ࡮ࡶࡩᅏ"))
		eyUmvNFiYsE,zzvBg3ShiamAZ = [],[]
		for umP72LtwzUTWHFAlJVyheEp5 in range(len(Xj5EbaB0lRp1oTIQ)):
			eyUmvNFiYsE.append(Xj5EbaB0lRp1oTIQ[umP72LtwzUTWHFAlJVyheEp5][oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠶အ")])
			zzvBg3ShiamAZ.append(Xj5EbaB0lRp1oTIQ[umP72LtwzUTWHFAlJVyheEp5][iRoLg2m47tnDATBHGCSPNyx(u"࠱ဢ")])
	if len(zzvBg3ShiamAZ)==dshJSmRqeiP9nap2(u"࠱ဣ"): return LiRcTVUWuth70DmPy(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡔ࡙ࡈࡂࡊࡇࡅࠬও"),[],[]
	return hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩࠪঔ"),eyUmvNFiYsE,zzvBg3ShiamAZ
def E8CGDpBhxoOWeVnad(url):
	Z0HoXM261lLgxBzjUK = url.split(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪࡃࠬক"))
	dR2vHyAtl8pJN1 = Z0HoXM261lLgxBzjUK[zqdvcbP5L8BHh(u"࠲ဤ")]
	headers = { g4g6bfkPtVGU5lIM3(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨখ") : FnBiAjthS8MkXs67W(u"ࠬ࠭গ") }
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(xh9BXlAw0UoVsIZ4if3,dR2vHyAtl8pJN1,xW2Arao7YVOemw(u"࠭ࠧঘ"),headers,bUdr5Hahw6sY8xJ(u"ࠧࠨঙ"),FvNyZqaLKw(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊ࠻ࡔࡔࡃࡕ࠱࠶ࡹࡴࠨচ"))
	items = GGvHJKP9LUxEk10Fw.findall(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠩࡓࡰࡪࡧࡳࡦࠢࡺࡥ࡮ࡺ࠮ࠫࡁ࡫ࡶࡪ࡬࠽࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩࠪছ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	url = items[l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠳ဥ")]
	return sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭জ"),[zqdvcbP5L8BHh(u"ࠫࠬঝ")],[url]
def dSH9hOkvRn5FZPI0maAg(url):
	eyUmvNFiYsE,zzvBg3ShiamAZ = [],[]
	headers = { FvNyZqaLKw(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩঞ") : E6MIKdpBomef(u"࠭ࠧট") }
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,url,l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧࠨঠ"),headers,l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨࠩড"),p72fnFtcPix5UKwr9YNzW(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡄࡗࡏࡘ࡞ࡈࡏࡐࡍࡖ࠱࠶ࡹࡴࠨঢ"))
	dR2vHyAtl8pJN1 = GGvHJKP9LUxEk10Fw.findall(E6MIKdpBomef(u"ࠪࡶࡪࡪࡩࡳࡧࡦࡸࡤࡻࡲ࡭࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪণ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if dR2vHyAtl8pJN1: return l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫࠬত"),[dshJSmRqeiP9nap2(u"ࠬ࠭থ")],[dR2vHyAtl8pJN1[xW2Arao7YVOemw(u"࠴ဦ")]]
	else: return FvNyZqaLKw(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡄࡘ࡞࡟࡜ࡒࡍࠩদ"),[],[]
def vKPaNJ3FMRAq(url):
	eyUmvNFiYsE,zzvBg3ShiamAZ = [],[]
	headers = { Me28A1sBLNIgUp5YCDyvT(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫধ") : pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࠩন") }
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,url,kEhAHvti6Vnsfx(u"ࠩࠪ঩"),headers,S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠪࠫপ"),SO94xq1RAkMm2uF(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡆ࡙ࡑ࡚࡙ࡃࡑࡒࡏࡘ࠳࠱ࡴࡶࠪফ"))
	dR2vHyAtl8pJN1 = GGvHJKP9LUxEk10Fw.findall(LiRcTVUWuth70DmPy(u"ࠬ࡮ࡲࡦࡨࠥ࠰ࠧ࠮ࡨࡵࡶ࠱࠮ࡄ࠯ࠢࠨব"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if dR2vHyAtl8pJN1: return xW2Arao7YVOemw(u"࠭ࠧভ"),[E6MIKdpBomef(u"ࠧࠨম")],[dR2vHyAtl8pJN1[Cu1704YofAbr3QTm(u"࠵ဧ")]]
	else: return SO94xq1RAkMm2uF(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡊࡆࡉࡕࡍࡖ࡜ࡆࡔࡕࡋࡔࠩয"),[],[]
def SY3eVzk80i(url):
	eyUmvNFiYsE,zzvBg3ShiamAZ,errno = [],[],iUeoLOsbHqP(u"ࠩࠪর")
	if bUdr5Hahw6sY8xJ(u"ࠪ࠳ࡼࡶ࠭ࡢࡦࡰ࡭ࡳ࠵ࠧ঱") in url:
		dR2vHyAtl8pJN1,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = xlk0nsAXjIrvOQFL4Vi1MJG5TChu(url)
		BBYvCiQGe8RdpyAagfS72mZclxb5 = {oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪল"):hBvsQ7oCkKUdwjx58ml3EN(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ঳")}
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,FnBiAjthS8MkXs67W(u"࠭ࡐࡐࡕࡗࠫ঴"),dR2vHyAtl8pJN1,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,fprnld4CZo(u"ࠧࠨ঵"),Me28A1sBLNIgUp5YCDyvT(u"ࠨࠩশ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮࠴ࡱࡨࠬষ"))
		X3in5vNhqwWEG2TafmVCrFbSYDxjoK = WbTGMHnDysdYZ2lFA.content
		if X3in5vNhqwWEG2TafmVCrFbSYDxjoK.startswith(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪ࡬ࡹࡺࡰࠨস")): dR2vHyAtl8pJN1 = X3in5vNhqwWEG2TafmVCrFbSYDxjoK
		else:
			XwyU6PQgprMI0 = GGvHJKP9LUxEk10Fw.findall(lc0dpSmwoPDjLnk(u"ࠫࠬ࠭ࡳࡳࡥࡀ࡟ࠬࠨ࡝ࠩ࠰࠭ࡃ࠮ࡡࠧࠣ࡟ࠪࠫࠬহ"),X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
			if XwyU6PQgprMI0:
				dR2vHyAtl8pJN1 = XwyU6PQgprMI0[hBvsQ7oCkKUdwjx58ml3EN(u"࠶ဨ")]
				XwyU6PQgprMI0 = GGvHJKP9LUxEk10Fw.findall(iUeoLOsbHqP(u"ࠬࡹ࡯ࡶࡴࡦࡩࡂ࠮࠮ࠫࡁࠬ࡟ࠫࠪ࡝ࠨ঺"),dR2vHyAtl8pJN1,GGvHJKP9LUxEk10Fw.DOTALL)
				if XwyU6PQgprMI0:
					dR2vHyAtl8pJN1 = GhPlajzTxY8(XwyU6PQgprMI0[FvNyZqaLKw(u"࠰ဩ")])
					return hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ࠧ঻"),[dshJSmRqeiP9nap2(u"ࠧࠨ়")],[dR2vHyAtl8pJN1]
	elif FnBiAjthS8MkXs67W(u"ࠨ࠱࡯࡭ࡳࡱࡳ࠰ࠩঽ") in url:
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,Me28A1sBLNIgUp5YCDyvT(u"ࠩࡊࡉ࡙࠭া"),url,Cu1704YofAbr3QTm(u"ࠪࠫি"),bUdr5Hahw6sY8xJ(u"ࠫࠬী"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࡕࡴࡸࡩᅐ"),FvNyZqaLKw(u"ࠬ࠭ু"),bUdr5Hahw6sY8xJ(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡏࡋࡒࡔࡊࡒ࡛࠲࠷ࡳࡵࠩূ"))
		X3in5vNhqwWEG2TafmVCrFbSYDxjoK = WbTGMHnDysdYZ2lFA.content
		if SO94xq1RAkMm2uF(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩৃ") in list(WbTGMHnDysdYZ2lFA.headers.keys()): dR2vHyAtl8pJN1 = WbTGMHnDysdYZ2lFA.headers[pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪৄ")]
		else: dR2vHyAtl8pJN1 = GGvHJKP9LUxEk10Fw.findall(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩ࡬ࡨࡂࠨ࡬ࡪࡰ࡮ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭৅"),X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)[Cu1704YofAbr3QTm(u"࠱ဪ")]
	if hBvsQ7oCkKUdwjx58ml3EN(u"ࠪ࠳ࡻ࠵ࠧ৆") in dR2vHyAtl8pJN1 or oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫ࠴࡬࠯ࠨে") in dR2vHyAtl8pJN1:
		dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1.replace(SO94xq1RAkMm2uF(u"ࠬ࠵ࡦ࠰ࠩৈ"),fprnld4CZo(u"࠭࠯ࡢࡲ࡬࠳ࡸࡵࡵࡳࡥࡨ࠳ࠬ৉"))
		dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1.replace(wRxoKs10Syj7V4edYhtP(u"ࠧ࠰ࡸ࠲ࠫ৊"),p72fnFtcPix5UKwr9YNzW(u"ࠨ࠱ࡤࡴ࡮࠵ࡳࡰࡷࡵࡧࡪ࠵ࠧো"))
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,FnBiAjthS8MkXs67W(u"ࠩࡓࡓࡘ࡚ࠧৌ"),dR2vHyAtl8pJN1,S4SOKF2QbBhjCd3RrVMuHIzE(u"্ࠪࠫ"),Cu1704YofAbr3QTm(u"ࠫࠬৎ"),iUeoLOsbHqP(u"ࠬ࠭৏"),lc0dpSmwoPDjLnk(u"࠭ࠧ৐"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳࠳ࡳࡦࠪ৑"))
		X3in5vNhqwWEG2TafmVCrFbSYDxjoK = WbTGMHnDysdYZ2lFA.content
		items = GGvHJKP9LUxEk10Fw.findall(zqdvcbP5L8BHh(u"ࠨࠤࡩ࡭ࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠥࡰࡦࡨࡥ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ৒"),X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
		if items:
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.replace(Me28A1sBLNIgUp5YCDyvT(u"ࠩ࡟ࡠࠬ৓"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪࠫ৔"))
				eyUmvNFiYsE.append(title)
				zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
		else:
			items = GGvHJKP9LUxEk10Fw.findall(FvNyZqaLKw(u"ࠫࠧ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ৕"),X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
			if items:
				ELbNB92cOh5dqtpVmi40kY = items[FnBiAjthS8MkXs67W(u"࠲ါ")]
				ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.replace(hBvsQ7oCkKUdwjx58ml3EN(u"ࠬࡢ࡜ࠨ৖"),hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࠧৗ"))
				eyUmvNFiYsE.append(g4g6bfkPtVGU5lIM3(u"ࠧࠨ৘"))
				zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	else: return g4g6bfkPtVGU5lIM3(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ৙"),[iRoLg2m47tnDATBHGCSPNyx(u"ࠩࠪ৚")],[dR2vHyAtl8pJN1]
	if len(zzvBg3ShiamAZ)==g4g6bfkPtVGU5lIM3(u"࠳ာ"): return dshJSmRqeiP9nap2(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨ৛"),[],[]
	return LiRcTVUWuth70DmPy(u"ࠫࠬড়"),eyUmvNFiYsE,zzvBg3ShiamAZ
def rrSL6nj91X(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,Me28A1sBLNIgUp5YCDyvT(u"ࠬࡍࡅࡕࠩঢ়"),url,FvNyZqaLKw(u"࠭ࠧ৞"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧࠨয়"),dshJSmRqeiP9nap2(u"ࠨࠩৠ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩࠪৡ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡘࡖ࠸࡚࠳࠱ࡴࡶࠪৢ"))
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	eyUmvNFiYsE,zzvBg3ShiamAZ,errno = [],[],FnBiAjthS8MkXs67W(u"ࠫࠬৣ")
	if oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠬࡶ࡬ࡢࡻࡨࡶࡤ࡫࡭ࡣࡧࡧ࠲ࡵ࡮ࡰࠨ৤") in url or g4g6bfkPtVGU5lIM3(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠵ࠧ৥") in url:
		if Cu1704YofAbr3QTm(u"ࠧࡱ࡮ࡤࡽࡪࡸ࡟ࡦ࡯ࡥࡩࡩ࠴ࡰࡩࡲࠪ০") in url:
			dR2vHyAtl8pJN1 = GGvHJKP9LUxEk10Fw.findall(wRxoKs10Syj7V4edYhtP(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭১"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
			dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1[oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠴ိ")]
		else: dR2vHyAtl8pJN1 = url
		if wRxoKs10Syj7V4edYhtP(u"ࠩࡰࡳࡻࡹ࠴ࡶࠩ২") not in dR2vHyAtl8pJN1: return p72fnFtcPix5UKwr9YNzW(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭৩"),[SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࠬ৪")],[dR2vHyAtl8pJN1]
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,FvNyZqaLKw(u"ࠬࡍࡅࡕࠩ৫"),dR2vHyAtl8pJN1,iRoLg2m47tnDATBHGCSPNyx(u"࠭ࠧ৬"),iUeoLOsbHqP(u"ࠧࠨ৭"),E6MIKdpBomef(u"ࠨࠩ৮"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠩࠪ৯"),Cu1704YofAbr3QTm(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡘࡖ࠸࡚࠳࠲࡯ࡦࠪৰ"))
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall(dshJSmRqeiP9nap2(u"ࠫ࡮ࡪ࠽ࠣࡲ࡯ࡥࡾ࡫ࡲࠣࠪ࠱࠮ࡄ࠯ࡶࡪࡦࡨࡳ࡯ࡹࠧৱ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[zqdvcbP5L8BHh(u"࠵ီ")]
		items = GGvHJKP9LUxEk10Fw.findall(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡬ࡢࡤࡨࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭৲"),UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if items:
			for ELbNB92cOh5dqtpVmi40kY,ccIZBYDOGdJlTE81Li2wAmuKtk in items:
				eyUmvNFiYsE.append(ccIZBYDOGdJlTE81Li2wAmuKtk)
				zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	elif iRoLg2m47tnDATBHGCSPNyx(u"࠭࡭ࡢ࡫ࡱࡣࡵࡲࡡࡺࡧࡵ࠲ࡵ࡮ࡰࠨ৳") in url:
		dR2vHyAtl8pJN1 = GGvHJKP9LUxEk10Fw.findall(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧࡶࡴ࡯ࡁ࠭࠴ࠪࡀࠫࠥࠫ৴"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1[UTelCo0ihE1d5R(u"࠶ု")]
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,UTelCo0ihE1d5R(u"ࠨࡉࡈࡘࠬ৵"),dR2vHyAtl8pJN1,kEhAHvti6Vnsfx(u"ࠩࠪ৶"),dshJSmRqeiP9nap2(u"ࠪࠫ৷"),g4g6bfkPtVGU5lIM3(u"ࠫࠬ৸"),bUdr5Hahw6sY8xJ(u"ࠬ࠭৹"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓ࡛࡙࠴ࡖ࠯࠶ࡶࡩ࠭৺"))
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		XwyU6PQgprMI0 = GGvHJKP9LUxEk10Fw.findall(FvNyZqaLKw(u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ৻"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		XwyU6PQgprMI0 = XwyU6PQgprMI0[dshJSmRqeiP9nap2(u"࠰ူ")]
		eyUmvNFiYsE.append(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࠩৼ"))
		zzvBg3ShiamAZ.append(XwyU6PQgprMI0)
	elif bUdr5Hahw6sY8xJ(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡱ࡯࡮࡬ࠩ৽") in url:
		dR2vHyAtl8pJN1 = GGvHJKP9LUxEk10Fw.findall(g4g6bfkPtVGU5lIM3(u"ࠪࡀࡨ࡫࡮ࡵࡧࡵࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭৾"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if dR2vHyAtl8pJN1:
			dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1[Cu1704YofAbr3QTm(u"࠱ေ")]
			return g4g6bfkPtVGU5lIM3(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ৿"),[hBvsQ7oCkKUdwjx58ml3EN(u"ࠬ࠭਀")],[dR2vHyAtl8pJN1]
	if len(zzvBg3ShiamAZ)==fprnld4CZo(u"࠲ဲ"): return S4SOKF2QbBhjCd3RrVMuHIzE(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡒ࡚ࡘ࠺ࡕࠨਁ"),[],[]
	return Cu1704YofAbr3QTm(u"ࠧࠨਂ"),eyUmvNFiYsE,zzvBg3ShiamAZ
def flQ5A7tGE3(url):
	if SO94xq1RAkMm2uF(u"ࠨࡁࡪࡩࡹࡃࠧਃ") in url:
		ELbNB92cOh5dqtpVmi40kY = url.split(xW2Arao7YVOemw(u"ࠩࡂ࡫ࡪࡺ࠽ࠨ਄"),iRoLg2m47tnDATBHGCSPNyx(u"࠴ဳ"))[iRoLg2m47tnDATBHGCSPNyx(u"࠴ဳ")]
		ELbNB92cOh5dqtpVmi40kY = hNe0ECZHr9B6.b64decode(ELbNB92cOh5dqtpVmi40kY)
		if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.decode(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪࡹࡹ࡬࠸ࠨਅ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫਆ"))
		return fprnld4CZo(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨਇ"),[S4SOKF2QbBhjCd3RrVMuHIzE(u"࠭ࠧਈ")],[ELbNB92cOh5dqtpVmi40kY]
	website = oSVpce1UQYrDqhuM6PT[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩਉ")][E6MIKdpBomef(u"࠴ဴ")]
	headers = {yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩਊ"):website}
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࡊࡉ࡙࠭਋"),url,Cu1704YofAbr3QTm(u"ࠪࠫ਌"),headers,Cu1704YofAbr3QTm(u"ࠫࠬ਍"),Cu1704YofAbr3QTm(u"ࠬ࠭਎"),UTelCo0ihE1d5R(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡃࡍࡗࡅ࠱࠷ࡴࡤࠨਏ"))
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	C83UXWf15zdwLA0 = RfKuIXwPAiWtmyF(url,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧࡶࡴ࡯ࠫਐ"))
	ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(Cu1704YofAbr3QTm(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࡀ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ਑"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(g4g6bfkPtVGU5lIM3(u"ࠤࡶࡳࡺࡸࡣࡦࡵ࠽ࠤࡡࡡࠧࠩ࠰࠭ࡃ࠮࠭ࠢ਒"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(iRoLg2m47tnDATBHGCSPNyx(u"ࠥࡪ࡮ࡲࡥ࠻ࠩࠫ࠲࠯ࡅࠩࠨࠤਓ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if ELbNB92cOh5dqtpVmi40kY:
		ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY[xW2Arao7YVOemw(u"࠵ဵ")]+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧਔ")+website
		return xW2Arao7YVOemw(u"ࠬ࠭ਕ"),[Me28A1sBLNIgUp5YCDyvT(u"࠭ࠧਖ")],[ELbNB92cOh5dqtpVmi40kY]
	if xW2Arao7YVOemw(u"ࠧ࡯ࡣࡰࡩࡂࠨࡘࡵࡱ࡮ࡩࡳࠨࠧਗ") in BBlXpmUyhFDwNtCVAHoE:
		aZQpzgfW9N30m65UwlBsnuDHrhb = GGvHJKP9LUxEk10Fw.findall(fprnld4CZo(u"ࠨࡰࡤࡱࡪࡃ࡙ࠢࡶࡲ࡯ࡪࡴࠢࠡࡥࡲࡲࡹ࡫࡮ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪਘ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if aZQpzgfW9N30m65UwlBsnuDHrhb:
			ELbNB92cOh5dqtpVmi40kY = aZQpzgfW9N30m65UwlBsnuDHrhb[LiRcTVUWuth70DmPy(u"࠶ံ")]
			ELbNB92cOh5dqtpVmi40kY = hNe0ECZHr9B6.b64decode(ELbNB92cOh5dqtpVmi40kY)
			if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.decode(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩࡸࡸ࡫࠾ࠧਙ"),FnBiAjthS8MkXs67W(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪਚ"))
			ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(g4g6bfkPtVGU5lIM3(u"ࠫ࡭ࡺࡴࡱ࠰࠭ࡃ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠬࠨਛ"),ELbNB92cOh5dqtpVmi40kY,GGvHJKP9LUxEk10Fw.DOTALL)
			if ELbNB92cOh5dqtpVmi40kY:
				ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY[iRoLg2m47tnDATBHGCSPNyx(u"࠰့")]+E6MIKdpBomef(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨਜ")+website
				return oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠭ࠧਝ"),[hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠧࠨਞ")],[ELbNB92cOh5dqtpVmi40kY]
	return pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫਟ"),[FnBiAjthS8MkXs67W(u"ࠩࠪਠ")],[url]
def MgAYQOR7aP(url,CCilGtf08YTx6qDX9Svg):
	HHSO6Q4KI0hlPxYpNuXRkWCmjEgA,uuIjMn1YTf687WlRcOmhq4G23H = [],[]
	if sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪ࠳࠶࠵ࠧਡ") in url:
		ELbNB92cOh5dqtpVmi40kY = url.replace(Me28A1sBLNIgUp5YCDyvT(u"ࠫ࠴࠷࠯ࠨਢ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬ࠵࠴࠰ࠩਣ"))
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,yA5z6LIXBlo41PRVMY87wOisFp(u"࠭ࡇࡆࡖࠪਤ"),ELbNB92cOh5dqtpVmi40kY,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧࠨਥ"),SO94xq1RAkMm2uF(u"ࠨࠩਦ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࡈࡤࡰࡸ࡫ᅑ"),iRoLg2m47tnDATBHGCSPNyx(u"ࠩࠪਧ"),kEhAHvti6Vnsfx(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠳ࡶࡸࠬਨ"))
		X3in5vNhqwWEG2TafmVCrFbSYDxjoK = WbTGMHnDysdYZ2lFA.content
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠫࡁࡼࡩࡥࡧࡲࠬ࠳࠰࠿ࠪ࠾࠲ࡺ࡮ࡪࡥࡰࡀࠪ਩"),X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠱း")]
			items = GGvHJKP9LUxEk10Fw.findall(kEhAHvti6Vnsfx(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩࡻࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫਪ"),UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,dDZQSEGRTo9g85x1C in items:
				if ELbNB92cOh5dqtpVmi40kY not in uuIjMn1YTf687WlRcOmhq4G23H:
					uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY)
					C83UXWf15zdwLA0 = RfKuIXwPAiWtmyF(ELbNB92cOh5dqtpVmi40kY,hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭࡮ࡢ࡯ࡨࠫਫ"))
					HHSO6Q4KI0hlPxYpNuXRkWCmjEgA.append(C83UXWf15zdwLA0+iUeoLOsbHqP(u"ࠧࠡࠢࠪਬ")+dDZQSEGRTo9g85x1C)
			return yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨࠩਭ"),HHSO6Q4KI0hlPxYpNuXRkWCmjEgA,uuIjMn1YTf687WlRcOmhq4G23H
	elif oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠩ࠲ࡨ࠴࠭ਮ") in url:
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪࡋࡊ࡚ࠧਯ"),url,dshJSmRqeiP9nap2(u"ࠫࠬਰ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠬ࠭਱"),xW2Arao7YVOemw(u"࠭ࠧਲ"),kEhAHvti6Vnsfx(u"ࠧࠨਲ਼"),LiRcTVUWuth70DmPy(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳࠲࡯ࡦࠪ਴"))
		X3in5vNhqwWEG2TafmVCrFbSYDxjoK = WbTGMHnDysdYZ2lFA.content
		ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪਵ"),X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
		if ELbNB92cOh5dqtpVmi40kY:
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠲္")].replace(dshJSmRqeiP9nap2(u"ࠪ࠳࠶࠵ࠧਸ਼"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠫ࠴࠺࠯ࠨ਷"))
			WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠬࡍࡅࡕࠩਸ"),ELbNB92cOh5dqtpVmi40kY,iUeoLOsbHqP(u"࠭ࠧਹ"),wRxoKs10Syj7V4edYhtP(u"ࠧࠨ਺"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࡉࡥࡱࡹࡥᅒ"),E6MIKdpBomef(u"ࠨࠩ਻"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠴ࡴࡧ਼ࠫ"))
			X3in5vNhqwWEG2TafmVCrFbSYDxjoK = WbTGMHnDysdYZ2lFA.content
			ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠪࡧࡱࡧࡳࡴ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ਽"),X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
			if ELbNB92cOh5dqtpVmi40kY: return Me28A1sBLNIgUp5YCDyvT(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧਾ"),[iUeoLOsbHqP(u"ࠬ࠭ਿ")],[ELbNB92cOh5dqtpVmi40kY[fprnld4CZo(u"࠳်")]]
	elif zqdvcbP5L8BHh(u"࠭࠯ࡳࡱ࡯ࡩ࠴࠭ੀ") in url:
		headers = {E6MIKdpBomef(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨੁ"):CCilGtf08YTx6qDX9Svg}
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,kEhAHvti6Vnsfx(u"ࠨࡉࡈࡘࠬੂ"),url,hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩࠪ੃"),headers,Me28A1sBLNIgUp5YCDyvT(u"ࡊࡦࡲࡳࡦᅓ"),FvNyZqaLKw(u"ࠪࠫ੄"),bUdr5Hahw6sY8xJ(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠷ࡸ࡭࠭੅"))
		ELbNB92cOh5dqtpVmi40kY = WbTGMHnDysdYZ2lFA.headers[xW2Arao7YVOemw(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ੆")]
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠭ࡇࡆࡖࠪੇ"),ELbNB92cOh5dqtpVmi40kY,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧࠨੈ"),bUdr5Hahw6sY8xJ(u"ࠨࠩ੉"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩࠪ੊"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠪࠫੋ"),xW2Arao7YVOemw(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠸ࡸ࡭࠭ੌ"))
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		svejmhZS0t24bAiYuzk,HHSO6Q4KI0hlPxYpNuXRkWCmjEgA,uuIjMn1YTf687WlRcOmhq4G23H = ZHj03wK2Tq(ELbNB92cOh5dqtpVmi40kY,BBlXpmUyhFDwNtCVAHoE)
		return svejmhZS0t24bAiYuzk,HHSO6Q4KI0hlPxYpNuXRkWCmjEgA,uuIjMn1YTf687WlRcOmhq4G23H
	elif SO94xq1RAkMm2uF(u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠰੍ࠩ") in url:
		dR2vHyAtl8pJN1 = url.replace(bUdr5Hahw6sY8xJ(u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࠪ੎"),wRxoKs10Syj7V4edYhtP(u"ࠧ࠰ࡵࡦࡶ࡮ࡶࡴ࠰ࠩ੏"))
		BBYvCiQGe8RdpyAagfS72mZclxb5 = {hBvsQ7oCkKUdwjx58ml3EN(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ੐"):CCilGtf08YTx6qDX9Svg}
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,Me28A1sBLNIgUp5YCDyvT(u"ࠩࡊࡉ࡙࠭ੑ"),dR2vHyAtl8pJN1,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠪࠫ੒"),BBYvCiQGe8RdpyAagfS72mZclxb5,fprnld4CZo(u"ࡋࡧ࡬ࡴࡧᅔ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠫࠬ੓"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰࠺ࡹ࡮ࠧ੔"))
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(sTcr7iDp5eFt4RoLMhuwq1A(u"࠭࠼ࡪࡨࡵࡥࡲ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ੕"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if ELbNB92cOh5dqtpVmi40kY:
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY[iUeoLOsbHqP(u"࠴ျ")]
			WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧࡈࡇࡗࠫ੖"),ELbNB92cOh5dqtpVmi40kY,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠨࠩ੗"),BBYvCiQGe8RdpyAagfS72mZclxb5,SO94xq1RAkMm2uF(u"ࡌࡡ࡭ࡵࡨᅕ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩࠪ੘"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠹ࡷ࡬ࠬਖ਼"))
			BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
			if l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ਗ਼") in list(WbTGMHnDysdYZ2lFA.headers.keys()):
				ELbNB92cOh5dqtpVmi40kY = WbTGMHnDysdYZ2lFA.headers[Me28A1sBLNIgUp5YCDyvT(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧਜ਼")]
				WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,iUeoLOsbHqP(u"࠭ࡇࡆࡖࠪੜ"),ELbNB92cOh5dqtpVmi40kY,kEhAHvti6Vnsfx(u"ࠧࠨ੝"),BBYvCiQGe8RdpyAagfS72mZclxb5,g4g6bfkPtVGU5lIM3(u"ࡆࡢ࡮ࡶࡩᅖ"),UTelCo0ihE1d5R(u"ࠨࠩਫ਼"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠹ࡶ࡫ࠫ੟"))
				BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
				svejmhZS0t24bAiYuzk,HHSO6Q4KI0hlPxYpNuXRkWCmjEgA,uuIjMn1YTf687WlRcOmhq4G23H = ZHj03wK2Tq(ELbNB92cOh5dqtpVmi40kY,BBlXpmUyhFDwNtCVAHoE)
				if uuIjMn1YTf687WlRcOmhq4G23H: return svejmhZS0t24bAiYuzk,HHSO6Q4KI0hlPxYpNuXRkWCmjEgA,uuIjMn1YTf687WlRcOmhq4G23H
			elif SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠱ࡴ࡭ࡶ࠿ࡪࡦࡀࠫ੠") in ELbNB92cOh5dqtpVmi40kY:
				ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.replace(lc0dpSmwoPDjLnk(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠲ࡵ࡮ࡰࡀ࡫ࡧࡁࠬ੡"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬ࠵ࡪࡸࡲ࡯ࡥࡾ࡫ࡲ࠯ࡲ࡫ࡴࡄ࡯ࡤ࠾ࠩ੢"))
				return fprnld4CZo(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ੣"),[LiRcTVUWuth70DmPy(u"ࠧࠨ੤")],[ELbNB92cOh5dqtpVmi40kY]
	else: return zqdvcbP5L8BHh(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ੥"),[g4g6bfkPtVGU5lIM3(u"ࠩࠪ੦")],[url]
	return g4g6bfkPtVGU5lIM3(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧ੧"),[],[]
def TNlZLgj9Gt(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,kEhAHvti6Vnsfx(u"ࠫࡌࡋࡔࠨ੨"),url,Me28A1sBLNIgUp5YCDyvT(u"ࠬ࠭੩"),zqdvcbP5L8BHh(u"࠭ࠧ੪"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧࠨ੫"),xW2Arao7YVOemw(u"ࠨࠩ੬"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠹࠭࠲ࡵࡷࠫ੭"))
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	data = GGvHJKP9LUxEk10Fw.findall(UTelCo0ihE1d5R(u"ࠪࠦࡦࡩࡴࡪࡱࡱࠦ࠳࠰࠿ࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ੮"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if data:
		lF6WOPL0A29urgmB7ySfZ8tvGwV,id,YcfzlVni9S4BN = data[yA5z6LIXBlo41PRVMY87wOisFp(u"࠵ြ")]
		data = iRoLg2m47tnDATBHGCSPNyx(u"ࠫࡴࡶ࠽ࠨ੯")+lF6WOPL0A29urgmB7ySfZ8tvGwV+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬࠬࡩࡥ࠿ࠪੰ")+id+bUdr5Hahw6sY8xJ(u"࠭ࠦࡧࡰࡤࡱࡪࡃࠧੱ")+YcfzlVni9S4BN
		headers = {YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ੲ"):hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧੳ")}
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࡓࡓࡘ࡚ࠧੴ"),url,data,headers,zqdvcbP5L8BHh(u"ࠪࠫੵ"),iRoLg2m47tnDATBHGCSPNyx(u"ࠫࠬ੶"),E6MIKdpBomef(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠵࠰࠶ࡳࡪࠧ੷"))
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(LiRcTVUWuth70DmPy(u"࠭ࠢࡳࡧࡩࡩࡷ࡫ࡲࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ੸"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if ELbNB92cOh5dqtpVmi40kY: return QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ੹"),[p72fnFtcPix5UKwr9YNzW(u"ࠨࠩ੺")],[ELbNB92cOh5dqtpVmi40kY[Me28A1sBLNIgUp5YCDyvT(u"࠶ွ")]]
	return Cu1704YofAbr3QTm(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭੻"),[],[]
def glPzHI7LEe(url):
	headers = {oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭੼"):g4g6bfkPtVGU5lIM3(u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ੽")}
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬࡍࡅࡕࠩ੾"),url,oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠭ࠧ੿"),headers,Cu1704YofAbr3QTm(u"ࠧࠨ઀"),FvNyZqaLKw(u"ࠨࠩઁ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠺࠭࠲ࡵࡷࠫં"))
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(fprnld4CZo(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨઃ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if ELbNB92cOh5dqtpVmi40kY:
		ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY[SO94xq1RAkMm2uF(u"࠰ှ")].replace(lc0dpSmwoPDjLnk(u"ࠫࡡࡴࠧ઄"),bUdr5Hahw6sY8xJ(u"ࠬ࠭અ"))
		return hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩઆ"),[hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࠨઇ")],[ELbNB92cOh5dqtpVmi40kY]
	return E6MIKdpBomef(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬઈ"),[],[]
def VyYaji521x(url):
	dR2vHyAtl8pJN1 = url.split(fprnld4CZo(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪઉ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠲ဿ"))[zqdvcbP5L8BHh(u"࠲၀")].strip(g4g6bfkPtVGU5lIM3(u"ࠪࡃࠬઊ")).strip(iRoLg2m47tnDATBHGCSPNyx(u"ࠫ࠴࠭ઋ")).strip(iRoLg2m47tnDATBHGCSPNyx(u"ࠬࠬࠧઌ"))
	eyUmvNFiYsE,zzvBg3ShiamAZ,items,XwyU6PQgprMI0 = [],[],[],FnBiAjthS8MkXs67W(u"࠭ࠧઍ")
	headers = { g4g6bfkPtVGU5lIM3(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ઎"):iRoLg2m47tnDATBHGCSPNyx(u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣ࡮ࡴ࠶࠵࠽ࠣࡼ࠻࠺ࠩࠨએ") }
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,Cu1704YofAbr3QTm(u"ࠩࡊࡉ࡙࠭ઐ"),dR2vHyAtl8pJN1,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠪࠫઑ"),headers,hBvsQ7oCkKUdwjx58ml3EN(u"ࡕࡴࡸࡩᅗ"),iRoLg2m47tnDATBHGCSPNyx(u"ࠫࠬ઒"),iRoLg2m47tnDATBHGCSPNyx(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠯࠴ࡷࡹ࠭ઓ"))
	if oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨઔ") in list(WbTGMHnDysdYZ2lFA.headers.keys()): XwyU6PQgprMI0 = WbTGMHnDysdYZ2lFA.headers[FnBiAjthS8MkXs67W(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩક")]
	if SO94xq1RAkMm2uF(u"ࠨࡪࡷࡸࡵ࠭ખ") in XwyU6PQgprMI0:
		if Me28A1sBLNIgUp5YCDyvT(u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪગ") in url: XwyU6PQgprMI0 = XwyU6PQgprMI0.replace(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪ࠳࡫࠵ࠧઘ"),iRoLg2m47tnDATBHGCSPNyx(u"ࠫ࠴ࡼ࠯ࠨઙ"))
		yyl2d6CNWt4 = dR2vHyAtl8pJN1.split(p72fnFtcPix5UKwr9YNzW(u"ࠬࡅࡐࡉࡒࡖࡍࡉࡃࠧચ"))[fprnld4CZo(u"࠴၁")]
		headers = { Cu1704YofAbr3QTm(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪછ"):headers[Me28A1sBLNIgUp5YCDyvT(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫજ")] , p72fnFtcPix5UKwr9YNzW(u"ࠨࡅࡲࡳࡰ࡯ࡥࠨઝ"):SO94xq1RAkMm2uF(u"ࠩࡓࡌࡕ࡙ࡉࡅ࠿ࠪઞ")+yyl2d6CNWt4 }
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,Me28A1sBLNIgUp5YCDyvT(u"ࠪࡋࡊ࡚ࠧટ"),XwyU6PQgprMI0,hBvsQ7oCkKUdwjx58ml3EN(u"ࠫࠬઠ"),headers,yA5z6LIXBlo41PRVMY87wOisFp(u"ࡈࡤࡰࡸ࡫ᅘ"),p72fnFtcPix5UKwr9YNzW(u"ࠬ࠭ડ"),lc0dpSmwoPDjLnk(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩઢ"))
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		if xW2Arao7YVOemw(u"ࠧ࠰ࡨ࠲ࠫણ") in XwyU6PQgprMI0: items = GGvHJKP9LUxEk10Fw.findall(hBvsQ7oCkKUdwjx58ml3EN(u"ࠨ࠾࡫࠶ࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧત"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		elif hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩ࠲ࡺ࠴࠭થ") in XwyU6PQgprMI0: items = GGvHJKP9LUxEk10Fw.findall(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪ࡭ࡩࡃࠢࡷ࡫ࡧࡩࡴࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧદ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if items: return [],[hBvsQ7oCkKUdwjx58ml3EN(u"ࠫࠬધ")],[ items[hBvsQ7oCkKUdwjx58ml3EN(u"࠴၂")] ]
		elif YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠬࡂࡨ࠲ࡀ࠷࠴࠹ࡂ࠯ࡩ࠳ࡁࠫન") in BBlXpmUyhFDwNtCVAHoE:
			return hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦำ๋ำไีࠥอไโ์า๎ํࠦแ๋้ࠣััฮࠠืัࠣ็ํีู๊๊่ࠡิื็ࠡ็้ࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูฮࠦศไࠩ઩"),[],[]
	else: return wRxoKs10Syj7V4edYhtP(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡈࡅࡔࡖࠪપ"),[],[]
def GG9wPnAJvh(ELbNB92cOh5dqtpVmi40kY):
	Z0HoXM261lLgxBzjUK = GGvHJKP9LUxEk10Fw.findall(dshJSmRqeiP9nap2(u"ࠨࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠨࠪફ"),ELbNB92cOh5dqtpVmi40kY+bUdr5Hahw6sY8xJ(u"ࠩࠩࠪࠬબ"),GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.IGNORECASE)
	XXKY1GIJm9BeMw0jfdSWRtEi,r9yaxqiB7EhQMfHjWoZTUn3LdvG = Z0HoXM261lLgxBzjUK[xW2Arao7YVOemw(u"࠵၃")]
	url = UTelCo0ihE1d5R(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡫ࡲࡪࡧࡶ࠸ࡼࡧࡴࡤࡪ࠱ࡲࡪࡺ࠯ࡢ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵࡃࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡵࡨࡶࡻ࡫ࡲࠧࡡࡳࡳࡸࡺ࡟ࡪࡦࡀࠫભ")+XXKY1GIJm9BeMw0jfdSWRtEi+Cu1704YofAbr3QTm(u"ࠫࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠨમ")+r9yaxqiB7EhQMfHjWoZTUn3LdvG
	headers = { SO94xq1RAkMm2uF(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩય"):zqdvcbP5L8BHh(u"࠭ࠧર") , fprnld4CZo(u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ઱"):SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩલ") }
	dR2vHyAtl8pJN1 = KkRZyvC312V5(xh9BXlAw0UoVsIZ4if3,url,wRxoKs10Syj7V4edYhtP(u"ࠩࠪળ"),headers,S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠪࠫ઴"),FnBiAjthS8MkXs67W(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳࠱ࡴࡶࠪવ"))
	return S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨશ"),[hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࠧષ")],[dR2vHyAtl8pJN1]
def vIufSK5zHr(url):
	C83UXWf15zdwLA0 = RfKuIXwPAiWtmyF(url,E6MIKdpBomef(u"ࠧࡶࡴ࡯ࠫસ"))
	BBYvCiQGe8RdpyAagfS72mZclxb5 = {p72fnFtcPix5UKwr9YNzW(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩહ"):C83UXWf15zdwLA0,fprnld4CZo(u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡈࡲࡨࡵࡤࡪࡰࡪࠫ઺"):FvNyZqaLKw(u"ࠪ࡫ࡿ࡯ࡰ࠭ࠢࡧࡩ࡫ࡲࡡࡵࡧࠪ઻")}
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(X9mvsOYNPGeWdaIw01Mf4Jz5p,dshJSmRqeiP9nap2(u"ࠫࡌࡋࡔࠨ઼"),url,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠬ࠭ઽ"),BBYvCiQGe8RdpyAagfS72mZclxb5,l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࠧા"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧࠨિ"),wRxoKs10Syj7V4edYhtP(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡟ࡃࡊࡏࡄ࠱࠶ࡹࡴࠨી"))
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall(xW2Arao7YVOemw(u"ࠩࡳࡰࡦࡿࡥࡳ࠰ࡴࡹࡦࡲࡩࡵࡻࡶࡩࡱ࡫ࡣࡵࡱࡵࠬ࠳࠰࠿ࠪࡨࡲࡶࡲࡧࡴࡴ࠼ࠪુ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	dR2vHyAtl8pJN1 = FnBiAjthS8MkXs67W(u"ࠪࠫૂ")
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[iUeoLOsbHqP(u"࠶၄")]
		items = GGvHJKP9LUxEk10Fw.findall(FvNyZqaLKw(u"ࠫ࡫ࡵࡲ࡮ࡣࡷ࠾ࠥࡢࠧࠩ࡞ࡧ࠲࠯ࡅࠩ࡝ࠩ࠯ࠤࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪૃ"),UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		eyUmvNFiYsE,zzvBg3ShiamAZ = [],[]
		for title,ELbNB92cOh5dqtpVmi40kY in items:
			eyUmvNFiYsE.append(title)
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
		if len(zzvBg3ShiamAZ)==E6MIKdpBomef(u"࠱၅"): dR2vHyAtl8pJN1 = zzvBg3ShiamAZ[sTcr7iDp5eFt4RoLMhuwq1A(u"࠱၆")]
		elif len(zzvBg3ShiamAZ)>E6MIKdpBomef(u"࠳၇"):
			z0jyetbQwKrIclL9vJW = D1DJtzviFZSrA(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬษฮหำࠣห้๋ไโࠢส่๊์วิสࠪૄ"), eyUmvNFiYsE)
			if z0jyetbQwKrIclL9vJW==-Cu1704YofAbr3QTm(u"࠴၈"): return QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭ࠧૅ"),[],[]
			dR2vHyAtl8pJN1 = zzvBg3ShiamAZ[z0jyetbQwKrIclL9vJW]
	else:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall(xW2Arao7YVOemw(u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ૆"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL: dR2vHyAtl8pJN1 = EeQqAGc0W5r6nlBbChwfZL[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠴၉")]
	if not dR2vHyAtl8pJN1: return bUdr5Hahw6sY8xJ(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑ࡞ࡉࡉࡎࡃࠪે"),[],[]
	return bUdr5Hahw6sY8xJ(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬૈ"),[E6MIKdpBomef(u"ࠪࠫૉ")],[dR2vHyAtl8pJN1]
def u2dxD1WamQ(url):
	C83UXWf15zdwLA0 = RfKuIXwPAiWtmyF(url,UTelCo0ihE1d5R(u"ࠫࡺࡸ࡬ࠨ૊"))
	BBYvCiQGe8RdpyAagfS72mZclxb5 = {FvNyZqaLKw(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ો"):C83UXWf15zdwLA0,iRoLg2m47tnDATBHGCSPNyx(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨૌ"):S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠧࡨࡼ࡬ࡴ࠱ࠦࡤࡦࡨ࡯ࡥࡹ࡫્ࠧ")}
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(X9mvsOYNPGeWdaIw01Mf4Jz5p,UTelCo0ihE1d5R(u"ࠨࡉࡈࡘࠬ૎"),url,FnBiAjthS8MkXs67W(u"ࠩࠪ૏"),BBYvCiQGe8RdpyAagfS72mZclxb5,hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪࠫૐ"),UTelCo0ihE1d5R(u"ࠫࠬ૑"),zqdvcbP5L8BHh(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡈࡇࡎࡓࡁ࠮࠳ࡶࡸࠬ૒"))
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall(LiRcTVUWuth70DmPy(u"࠭ࡰ࡭ࡣࡼࡩࡷ࠴ࡱࡶࡣ࡯࡭ࡹࡿࡳࡦ࡮ࡨࡧࡹࡵࡲࠩ࠰࠭ࡃ࠮࡬࡯ࡳ࡯ࡤࡸࡸࡀࠧ૓"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	dR2vHyAtl8pJN1 = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧࠨ૔")
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[hBvsQ7oCkKUdwjx58ml3EN(u"࠵၊")]
		items = GGvHJKP9LUxEk10Fw.findall(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠨࡨࡲࡶࡲࡧࡴ࠻ࠢ࡟ࠫ࠭ࡢࡤ࠯ࠬࡂ࠭ࡡ࠭ࠬࠡࡵࡵࡧ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ૕"),UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		eyUmvNFiYsE,zzvBg3ShiamAZ = [],[]
		for title,ELbNB92cOh5dqtpVmi40kY in items:
			eyUmvNFiYsE.append(title)
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
		if len(zzvBg3ShiamAZ)==dshJSmRqeiP9nap2(u"࠷။"): dR2vHyAtl8pJN1 = zzvBg3ShiamAZ[FnBiAjthS8MkXs67W(u"࠰၌")]
		elif len(zzvBg3ShiamAZ)>XzrqbGDIy54juixkMA(u"࠲၍"):
			z0jyetbQwKrIclL9vJW = D1DJtzviFZSrA(xW2Arao7YVOemw(u"ࠩฦาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧ૖"), eyUmvNFiYsE)
			if z0jyetbQwKrIclL9vJW==-iUeoLOsbHqP(u"࠳၎"): return bUdr5Hahw6sY8xJ(u"ࠪࠫ૗"),[],[]
			dR2vHyAtl8pJN1 = zzvBg3ShiamAZ[z0jyetbQwKrIclL9vJW]
	if not dR2vHyAtl8pJN1:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall(LiRcTVUWuth70DmPy(u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ૘"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL: dR2vHyAtl8pJN1 = EeQqAGc0W5r6nlBbChwfZL[bUdr5Hahw6sY8xJ(u"࠳၏")]
	if not dR2vHyAtl8pJN1: return wRxoKs10Syj7V4edYhtP(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡇࡆࡍࡒࡇࠧ૙"),[],[]
	return hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ૚"),[hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࠨ૛")],[dR2vHyAtl8pJN1]
def nnTPxkzGRH(ELbNB92cOh5dqtpVmi40kY):
	Z0HoXM261lLgxBzjUK = GGvHJKP9LUxEk10Fw.findall(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࡠࡄࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࠬࠧ૜"),ELbNB92cOh5dqtpVmi40kY+oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠩࠩࠪࠬ૝"),GGvHJKP9LUxEk10Fw.DOTALL)
	url,XXKY1GIJm9BeMw0jfdSWRtEi,r9yaxqiB7EhQMfHjWoZTUn3LdvG = Z0HoXM261lLgxBzjUK[hBvsQ7oCkKUdwjx58ml3EN(u"࠴ၐ")]
	data = {QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠪࡴࡴࡹࡴࡠ࡫ࡧࠫ૞"):XXKY1GIJm9BeMw0jfdSWRtEi,wRxoKs10Syj7V4edYhtP(u"ࠫࡸ࡫ࡲࡷࡧࡵࠫ૟"):r9yaxqiB7EhQMfHjWoZTUn3LdvG}
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬࡖࡏࡔࡖࠪૠ"),url,data,G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠭ࠧૡ"),iUeoLOsbHqP(u"ࠧࠨૢ"),zqdvcbP5L8BHh(u"ࠨࠩૣ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡐࡃࡐࡇࡆࡓ࠭࠲ࡵࡷࠫ૤"))
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	dR2vHyAtl8pJN1 = GGvHJKP9LUxEk10Fw.findall(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ૥"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)[g4g6bfkPtVGU5lIM3(u"࠵ၑ")]
	return G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ૦"),[zqdvcbP5L8BHh(u"ࠬ࠭૧")],[dR2vHyAtl8pJN1]
def EZ9Ka24UCG(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,iUeoLOsbHqP(u"࠭ࡇࡆࡖࠪ૨"),url,sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࠨ૩"),LiRcTVUWuth70DmPy(u"ࠨࠩ૪"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩࠪ૫"),wRxoKs10Syj7V4edYhtP(u"ࠪࠫ૬"),FnBiAjthS8MkXs67W(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡑࡏࡇࡉࡖ࠰࠵ࡸࡺࠧ૭"))
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(lc0dpSmwoPDjLnk(u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭૮"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if ELbNB92cOh5dqtpVmi40kY:
		ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY[zqdvcbP5L8BHh(u"࠶ၒ")]
		if ELbNB92cOh5dqtpVmi40kY: return l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ૯"),[bUdr5Hahw6sY8xJ(u"ࠧࠨ૰")],[ELbNB92cOh5dqtpVmi40kY]
	return SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭૱"),[],[]
def SlK7x3yAYL(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩࡊࡉ࡙࠭૲"),url,fprnld4CZo(u"ࠪࠫ૳"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫࠬ૴"),iRoLg2m47tnDATBHGCSPNyx(u"ࠬ࠭૵"),SO94xq1RAkMm2uF(u"࠭ࠧ૶"),Me28A1sBLNIgUp5YCDyvT(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡄࡎࡘࡔ࠲࠷ࡳࡵࠩ૷"))
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(SO94xq1RAkMm2uF(u"ࠨ࠾ࡌࡊࡗࡇࡍࡆࠢࡖࡖࡈࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ૸"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)[pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠰ၓ")]
	return lc0dpSmwoPDjLnk(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬૹ"),[kEhAHvti6Vnsfx(u"ࠪࠫૺ")],[ELbNB92cOh5dqtpVmi40kY]
def QTLlPojE20(url):
	Z5sNMdDa6h7j0 = RfKuIXwPAiWtmyF(url,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࡺࡸ࡬ࠨૻ"))
	if S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠬ࡯࡮ࡥࡧࡻࡁࠬૼ") in url:
		headers = {iRoLg2m47tnDATBHGCSPNyx(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ૽"):Z5sNMdDa6h7j0}
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,SO94xq1RAkMm2uF(u"ࠧࡈࡇࡗࠫ૾"),url,p72fnFtcPix5UKwr9YNzW(u"ࠨࠩ૿"),headers,bUdr5Hahw6sY8xJ(u"ࠩࠪ଀"),FnBiAjthS8MkXs67W(u"ࠪࠫଁ"),iUeoLOsbHqP(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡓࡕࡗ࠮࠳ࡶࡸࠬଂ"))
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		dR2vHyAtl8pJN1 = GGvHJKP9LUxEk10Fw.findall(p72fnFtcPix5UKwr9YNzW(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪଃ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if dR2vHyAtl8pJN1:
			dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1[E6MIKdpBomef(u"࠱ၔ")]
			if Cu1704YofAbr3QTm(u"࠭ࡨࡵࡶࡳࠫ଄") not in dR2vHyAtl8pJN1: dR2vHyAtl8pJN1 = QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧࡩࡶࡷࡴ࠿࠭ଅ")+dR2vHyAtl8pJN1
			if SO94xq1RAkMm2uF(u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩଆ") in dR2vHyAtl8pJN1:
				dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1.replace(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫଇ"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫଈ"))
				WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠫࡌࡋࡔࠨଉ"),dR2vHyAtl8pJN1,lc0dpSmwoPDjLnk(u"ࠬ࠭ଊ"),headers,S4SOKF2QbBhjCd3RrVMuHIzE(u"࠭ࠧଋ"),Cu1704YofAbr3QTm(u"ࠧࠨଌ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠸࡮ࡥࠩ଍"))
				X3in5vNhqwWEG2TafmVCrFbSYDxjoK = WbTGMHnDysdYZ2lFA.content
				items = GGvHJKP9LUxEk10Fw.findall(FvNyZqaLKw(u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶ࡭ࡿ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ଎"),X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
				eyUmvNFiYsE,zzvBg3ShiamAZ = [],[]
				o6ZrjEvyT8th = RfKuIXwPAiWtmyF(dR2vHyAtl8pJN1,xW2Arao7YVOemw(u"ࠪࡹࡷࡲࠧଏ"))
				for ELbNB92cOh5dqtpVmi40kY,dDZQSEGRTo9g85x1C in reversed(items):
					ELbNB92cOh5dqtpVmi40kY = o6ZrjEvyT8th+ELbNB92cOh5dqtpVmi40kY+Cu1704YofAbr3QTm(u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧଐ")+o6ZrjEvyT8th
					eyUmvNFiYsE.append(dDZQSEGRTo9g85x1C)
					zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
				return G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠬ࠭଑"),eyUmvNFiYsE,zzvBg3ShiamAZ
			else: return lc0dpSmwoPDjLnk(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ଒"),[E6MIKdpBomef(u"ࠧࠨଓ")],[dR2vHyAtl8pJN1]
	dR2vHyAtl8pJN1 = url+yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫଔ")+Z5sNMdDa6h7j0
	if FnBiAjthS8MkXs67W(u"ࠩ࡫ࡸࡹࡶࠧକ") not in dR2vHyAtl8pJN1: dR2vHyAtl8pJN1 = SO94xq1RAkMm2uF(u"ࠪ࡬ࡹࡺࡰ࠻ࠩଖ")+dR2vHyAtl8pJN1
	return oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫࠬଗ"),[lc0dpSmwoPDjLnk(u"ࠬ࠭ଘ")],[dR2vHyAtl8pJN1]
def GCEpxXe6Pn(ELbNB92cOh5dqtpVmi40kY):
	Z5sNMdDa6h7j0 = RfKuIXwPAiWtmyF(ELbNB92cOh5dqtpVmi40kY,p72fnFtcPix5UKwr9YNzW(u"࠭ࡵࡳ࡮ࠪଙ"))
	if LiRcTVUWuth70DmPy(u"ࠧࡱࡱࡶࡸ࡮ࡪࠧଚ") in ELbNB92cOh5dqtpVmi40kY:
		Z0HoXM261lLgxBzjUK = GGvHJKP9LUxEk10Fw.findall(SO94xq1RAkMm2uF(u"ࠨࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࡠࡄࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࠬࠧଛ"),ELbNB92cOh5dqtpVmi40kY+fprnld4CZo(u"ࠩࠩࠪࠬଜ"),GGvHJKP9LUxEk10Fw.DOTALL)
		url,XXKY1GIJm9BeMw0jfdSWRtEi,r9yaxqiB7EhQMfHjWoZTUn3LdvG = Z0HoXM261lLgxBzjUK[iRoLg2m47tnDATBHGCSPNyx(u"࠲ၕ")]
		data = {bUdr5Hahw6sY8xJ(u"ࠪ࡭ࡩ࠭ଝ"):XXKY1GIJm9BeMw0jfdSWRtEi,bUdr5Hahw6sY8xJ(u"ࠫࡸ࡫ࡲࡷࡧࡵࠫଞ"):r9yaxqiB7EhQMfHjWoZTUn3LdvG}
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠬࡖࡏࡔࡖࠪଟ"),url,data,kEhAHvti6Vnsfx(u"࠭ࠧଠ"),kEhAHvti6Vnsfx(u"ࠧࠨଡ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠨࠩଢ"),LiRcTVUWuth70DmPy(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠱ࡴࡶࠪଣ"))
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		dR2vHyAtl8pJN1 = GGvHJKP9LUxEk10Fw.findall(LiRcTVUWuth70DmPy(u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨତ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)[g4g6bfkPtVGU5lIM3(u"࠳ၖ")]
		if oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬଥ") in dR2vHyAtl8pJN1:
			headers = {hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ଦ"):Z5sNMdDa6h7j0,fprnld4CZo(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪଧ"):FvNyZqaLKw(u"ࠧࠨନ")}
			WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,wRxoKs10Syj7V4edYhtP(u"ࠨࡉࡈࡘࠬ଩"),dR2vHyAtl8pJN1,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩࠪପ"),headers,XzrqbGDIy54juixkMA(u"ࠪࠫଫ"),bUdr5Hahw6sY8xJ(u"ࠫࠬବ"),p72fnFtcPix5UKwr9YNzW(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡔࡏࡘ࠯࠵ࡲࡩ࠭ଭ"))
			X3in5vNhqwWEG2TafmVCrFbSYDxjoK = WbTGMHnDysdYZ2lFA.content
			items = GGvHJKP9LUxEk10Fw.findall(dshJSmRqeiP9nap2(u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪࡼࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬମ"),X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
			eyUmvNFiYsE,zzvBg3ShiamAZ = [],[]
			o6ZrjEvyT8th = RfKuIXwPAiWtmyF(dR2vHyAtl8pJN1,SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠧࡶࡴ࡯ࠫଯ"))
			for ELbNB92cOh5dqtpVmi40kY,dDZQSEGRTo9g85x1C in reversed(items):
				ELbNB92cOh5dqtpVmi40kY = o6ZrjEvyT8th+ELbNB92cOh5dqtpVmi40kY+E6MIKdpBomef(u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫର")+o6ZrjEvyT8th
				eyUmvNFiYsE.append(dDZQSEGRTo9g85x1C)
				zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
			return p72fnFtcPix5UKwr9YNzW(u"ࠩࠪ଱"),eyUmvNFiYsE,zzvBg3ShiamAZ
		else: return iUeoLOsbHqP(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ଲ"),[fprnld4CZo(u"ࠫࠬଳ")],[dR2vHyAtl8pJN1]
	else:
		ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+iRoLg2m47tnDATBHGCSPNyx(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ଴")+Z5sNMdDa6h7j0
		return S4SOKF2QbBhjCd3RrVMuHIzE(u"࠭ࠧଵ"),[hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࠨଶ")],[ELbNB92cOh5dqtpVmi40kY]
def o2qO4LFMIN(ELbNB92cOh5dqtpVmi40kY):
	if pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࡲࡲࡷࡹ࡯ࡤࠨଷ") in ELbNB92cOh5dqtpVmi40kY:
		Z0HoXM261lLgxBzjUK = GGvHJKP9LUxEk10Fw.findall(Cu1704YofAbr3QTm(u"ࠩࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫସ"),ELbNB92cOh5dqtpVmi40kY+fprnld4CZo(u"ࠪࠪࠫ࠭ହ"),GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.IGNORECASE)
		XXKY1GIJm9BeMw0jfdSWRtEi,r9yaxqiB7EhQMfHjWoZTUn3LdvG = Z0HoXM261lLgxBzjUK[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠴ၗ")]
		HAjq82l1zhsCxt70YNf = RfKuIXwPAiWtmyF(ELbNB92cOh5dqtpVmi40kY,yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫࡺࡸ࡬ࠨ଺"))
		url = HAjq82l1zhsCxt70YNf+kEhAHvti6Vnsfx(u"ࠬ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡴࡧࡵࡺࡪࡸࠦࡠࡲࡲࡷࡹࡥࡩࡥ࠿ࠪ଻")+XXKY1GIJm9BeMw0jfdSWRtEi+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿଼ࠪ")+r9yaxqiB7EhQMfHjWoZTUn3LdvG
		headers = { iUeoLOsbHqP(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫଽ"):SO94xq1RAkMm2uF(u"ࠨࠩା") , p72fnFtcPix5UKwr9YNzW(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬି"):lc0dpSmwoPDjLnk(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫୀ") }
		dR2vHyAtl8pJN1 = KkRZyvC312V5(xh9BXlAw0UoVsIZ4if3,url,zqdvcbP5L8BHh(u"ࠫࠬୁ"),headers,fprnld4CZo(u"ࠬ࠭ୂ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡇࡒࡉࡐࡐ࡝࠱࠶ࡹࡴࠨୃ"))
		dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1.replace(hBvsQ7oCkKUdwjx58ml3EN(u"ࠧ࡝ࡰࠪୄ"),FvNyZqaLKw(u"ࠨࠩ୅")).replace(iUeoLOsbHqP(u"ࠩ࡟ࡶࠬ୆"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࠫେ"))
		return lc0dpSmwoPDjLnk(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧୈ"),[FnBiAjthS8MkXs67W(u"ࠬ࠭୉")],[dR2vHyAtl8pJN1]
	elif zqdvcbP5L8BHh(u"࠭࠯ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠱ࠪ୊") in ELbNB92cOh5dqtpVmi40kY:
		NOcFpG4d02xz = p72fnFtcPix5UKwr9YNzW(u"࠵ၘ")
		while S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠧ࠰ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠲ࠫୋ") in ELbNB92cOh5dqtpVmi40kY and NOcFpG4d02xz<SO94xq1RAkMm2uF(u"࠻ၙ"):
			WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,wRxoKs10Syj7V4edYhtP(u"ࠨࡉࡈࡘࠬୌ"),ELbNB92cOh5dqtpVmi40kY,xW2Arao7YVOemw(u"୍ࠩࠪ"),Cu1704YofAbr3QTm(u"ࠪࠫ୎"),hBvsQ7oCkKUdwjx58ml3EN(u"ࠫࠬ୏"),XzrqbGDIy54juixkMA(u"ࠬ࠭୐"),Me28A1sBLNIgUp5YCDyvT(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡇࡒࡉࡐࡐ࡝࠱࠷ࡴࡤࠨ୑"))
			if UTelCo0ihE1d5R(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ୒") in list(WbTGMHnDysdYZ2lFA.headers.keys()): ELbNB92cOh5dqtpVmi40kY = WbTGMHnDysdYZ2lFA.headers[UTelCo0ihE1d5R(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ୓")]
			NOcFpG4d02xz += SO94xq1RAkMm2uF(u"࠱ၚ")
		return Cu1704YofAbr3QTm(u"ࠩࠪ୔"),[fprnld4CZo(u"ࠪࠫ୕")],[ELbNB92cOh5dqtpVmi40kY]
	else: return p72fnFtcPix5UKwr9YNzW(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡓࡄࡏࡍࡔࡔ࡚ࠨୖ"),[],[]
def C7tunkvS8i(url):
	C83UXWf15zdwLA0 = RfKuIXwPAiWtmyF(url,SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠬࡻࡲ࡭ࠩୗ"))
	headers = {YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ୘"):C83UXWf15zdwLA0,fprnld4CZo(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ୙"):Y8Y6b7aLSUKjdE1Ae()}
	if p72fnFtcPix5UKwr9YNzW(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ୚") in url:
		BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(xh9BXlAw0UoVsIZ4if3,url,Me28A1sBLNIgUp5YCDyvT(u"ࠩࠪ୛"),headers,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠪࠫଡ଼"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡄࡆࡘࡋࡅࡅ࠯࠵ࡲࡩ࠭ଢ଼"))
		ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ୞"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if ELbNB92cOh5dqtpVmi40kY:
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY[S4SOKF2QbBhjCd3RrVMuHIzE(u"࠱ၛ")].replace(SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࡨࡵࡶࡳࡷࠬୟ"),wRxoKs10Syj7V4edYhtP(u"ࠧࡩࡶࡷࡴࠬୠ"))
			return SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࠩୡ"),[oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠩࠪୢ")],[ELbNB92cOh5dqtpVmi40kY]
	else:
		TTpNxoFCYd4Vw8Z = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࡋࡊ࡚ࠧୣ"),url,dshJSmRqeiP9nap2(u"ࠫࠬ୤"),headers,SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠬ࠭୥"),dshJSmRqeiP9nap2(u"࠭ࠧ୦"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠹ࡲࡥࠩ୧"))
		BBlXpmUyhFDwNtCVAHoE = TTpNxoFCYd4Vw8Z.content
		BBYvCiQGe8RdpyAagfS72mZclxb5 = headers.copy()
		if sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨࡡ࡯ࡲࡰࡥࠧ୨") in str(TTpNxoFCYd4Vw8Z.cookies):
			cookies = TTpNxoFCYd4Vw8Z.cookies
			BBYvCiQGe8RdpyAagfS72mZclxb5[hBvsQ7oCkKUdwjx58ml3EN(u"ࠩࡆࡳࡴࡱࡩࡦࠩ୩")] = GhPlajzTxY8(Hym17NopzZUE3xhYMe(cookies))
		ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(iUeoLOsbHqP(u"ࠪࡰ࡮ࡴ࡫࠯ࡪࡵࡩ࡫ࠦ࠽ࠡࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠭୪"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if not ELbNB92cOh5dqtpVmi40kY: return FnBiAjthS8MkXs67W(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ୫"),[kEhAHvti6Vnsfx(u"ࠬ࠭୬")],[url]
		else:
			ELbNB92cOh5dqtpVmi40kY = GhPlajzTxY8(ELbNB92cOh5dqtpVmi40kY[bUdr5Hahw6sY8xJ(u"࠲ၜ")])+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࠦࡥ࠿࠴ࠫ୭")
			QQTDOLdNUAzYbfl1vXrM8mB = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠧࡈࡇࡗࠫ୮"),ELbNB92cOh5dqtpVmi40kY,E6MIKdpBomef(u"ࠨࠩ୯"),BBYvCiQGe8RdpyAagfS72mZclxb5,hBvsQ7oCkKUdwjx58ml3EN(u"ࠩࠪ୰"),g4g6bfkPtVGU5lIM3(u"ࠪࠫୱ"),SO94xq1RAkMm2uF(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡄࡆࡘࡋࡅࡅ࠯࠷ࡸ࡭࠭୲"))
			BBlXpmUyhFDwNtCVAHoE = QQTDOLdNUAzYbfl1vXrM8mB.content
			ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(lc0dpSmwoPDjLnk(u"ࠬ࡯ࡤ࠾ࠤࡥࡸࡳࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ୳"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
			if ELbNB92cOh5dqtpVmi40kY:
				ELbNB92cOh5dqtpVmi40kY = GhPlajzTxY8(ELbNB92cOh5dqtpVmi40kY[FnBiAjthS8MkXs67W(u"࠳ၝ")])
				if XzrqbGDIy54juixkMA(u"࠭࡭ࡱ࠶ࠪ୴") in ELbNB92cOh5dqtpVmi40kY and XzrqbGDIy54juixkMA(u"ࠧ࠰ࡦ࠲ࠫ୵") in ELbNB92cOh5dqtpVmi40kY: return XzrqbGDIy54juixkMA(u"ࠨࠩ୶"),[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩࠪ୷")],[ELbNB92cOh5dqtpVmi40kY]
				else: return SO94xq1RAkMm2uF(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭୸"),[LiRcTVUWuth70DmPy(u"ࠫࠬ୹")],[ELbNB92cOh5dqtpVmi40kY]
	return G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡄࡆࡘࡋࡅࡅࠩ୺"),[],[]
def w9VNKsZ824(ELbNB92cOh5dqtpVmi40kY):
	if fprnld4CZo(u"࠭࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡷࡪࡸࡶࡦࡴࠪ୻") in ELbNB92cOh5dqtpVmi40kY:
		headers = {yA5z6LIXBlo41PRVMY87wOisFp(u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ୼"):oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ୽")}
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,kEhAHvti6Vnsfx(u"ࠩࡊࡉ࡙࠭୾"),ELbNB92cOh5dqtpVmi40kY,oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠪࠫ୿"),headers,bUdr5Hahw6sY8xJ(u"ࠫࠬ஀"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬ࠭஁"),yA5z6LIXBlo41PRVMY87wOisFp(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱࠶ࡹࡴࠨஂ"))
		url = WbTGMHnDysdYZ2lFA.content
		if url: return xW2Arao7YVOemw(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪஃ"),[dshJSmRqeiP9nap2(u"ࠨࠩ஄")],[url]
	else:
		Z0HoXM261lLgxBzjUK = GGvHJKP9LUxEk10Fw.findall(iUeoLOsbHqP(u"ࠩࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠦࠪஅ"),ELbNB92cOh5dqtpVmi40kY,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.IGNORECASE)
		if not Z0HoXM261lLgxBzjUK: Z0HoXM261lLgxBzjUK = GGvHJKP9LUxEk10Fw.findall(wRxoKs10Syj7V4edYhtP(u"ࠪࡣࡵࡵࡳࡵࡡ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠩ࠭ஆ"),ELbNB92cOh5dqtpVmi40kY,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.IGNORECASE)
		XXKY1GIJm9BeMw0jfdSWRtEi,r9yaxqiB7EhQMfHjWoZTUn3LdvG = Z0HoXM261lLgxBzjUK[bUdr5Hahw6sY8xJ(u"࠴ၞ")]
		C83UXWf15zdwLA0 = RfKuIXwPAiWtmyF(ELbNB92cOh5dqtpVmi40kY,xW2Arao7YVOemw(u"ࠫࡺࡸ࡬ࠨஇ"))
		url = C83UXWf15zdwLA0+sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡸ࡭࡫࡭ࡦ࠱ࡄ࡮ࡦࡾࡡࡵ࠱ࡖ࡭ࡳ࡭࡬ࡦ࠱ࡖࡩࡷࡼࡥࡳ࠰ࡳ࡬ࡵ࠭ஈ")
		data = {hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ࡩࡥࠩஉ"):XXKY1GIJm9BeMw0jfdSWRtEi,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧࡪࠩஊ"):r9yaxqiB7EhQMfHjWoZTUn3LdvG}
		headers = {SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ஋"):QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ஌"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ஍"):ELbNB92cOh5dqtpVmi40kY}
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,fprnld4CZo(u"ࠫࡕࡕࡓࡕࠩஎ"),url,data,headers,Me28A1sBLNIgUp5YCDyvT(u"ࠬ࠭ஏ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࠧஐ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡗࡍࡇࡈࡊࡆ࠷࡙࠲࠸࡮ࡥࠩ஑"))
		X3in5vNhqwWEG2TafmVCrFbSYDxjoK = WbTGMHnDysdYZ2lFA.content
		dR2vHyAtl8pJN1 = GGvHJKP9LUxEk10Fw.findall(Cu1704YofAbr3QTm(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ஒ"),X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.IGNORECASE)
		if dR2vHyAtl8pJN1:
			dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1[Me28A1sBLNIgUp5YCDyvT(u"࠵ၟ")]
			return iUeoLOsbHqP(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬஓ"),[kEhAHvti6Vnsfx(u"ࠪࠫஔ")],[dR2vHyAtl8pJN1]
	return FnBiAjthS8MkXs67W(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡓࡉࡃࡋࡍࡉ࠺ࡕࠨக"),[],[]
def BV6y83JXwAmTncRHfsFa(qrXWyPmSJeCE87RhFfx9):
	a0xm5s2TFcfeyWZPibQjHnEVg = jHevARrF7lS.getSetting(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠬࡧࡶ࠯ࡣ࡮ࡻࡦࡳ࠮ࡷࡧࡵ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳ࠭஖"))
	headers = {l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭஗"):a0xm5s2TFcfeyWZPibQjHnEVg} if a0xm5s2TFcfeyWZPibQjHnEVg else bUdr5Hahw6sY8xJ(u"ࠧࠨ஘")
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,fprnld4CZo(u"ࠨࡉࡈࡘࠬங"),qrXWyPmSJeCE87RhFfx9,FnBiAjthS8MkXs67W(u"ࠩࠪச"),headers,lc0dpSmwoPDjLnk(u"ࠪࠫ஛"),p72fnFtcPix5UKwr9YNzW(u"ࠫࠬஜ"),XzrqbGDIy54juixkMA(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠳ࡶࡸࠬ஝"))
	e1VlxdKmgOCDHhEzvS3LAyqTMN5Z8P = WbTGMHnDysdYZ2lFA.content
	QVJ6Eaiqwp3xLvlI8M7uYzO = str(WbTGMHnDysdYZ2lFA.headers)
	pdqW3KahVj4xHb8rPmZugz = QVJ6Eaiqwp3xLvlI8M7uYzO+e1VlxdKmgOCDHhEzvS3LAyqTMN5Z8P
	if Me28A1sBLNIgUp5YCDyvT(u"࠭࠮࡮ࡲ࠷ࠫஞ") in pdqW3KahVj4xHb8rPmZugz: nP18Siw4MjRatJdKYNL7CUyB9eg = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࡗࡶࡺ࡫ᅙ")
	else:
		ssNoLSgalqVO3MPZefBEb25JwTFX,DI9PgKJNvLiuBpXyctMs2RklobGA,UbYKodWeN2wcF1ypOHnEijLz5,CxWkbv4QOd1Il96qTaYrUBRfzej5Vw,nP18Siw4MjRatJdKYNL7CUyB9eg = yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧࠨட"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࠩ஠"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩࠪ஡"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࠫ஢"),kEhAHvti6Vnsfx(u"ࡊࡦࡲࡳࡦᅚ")
		captcha = GGvHJKP9LUxEk10Fw.findall(lc0dpSmwoPDjLnk(u"ࠫࡵࡧࡧࡦ࠯ࡵࡩࡩ࡯ࡲࡦࡥࡷ࠲࠯ࡅࡡࡤࡶ࡬ࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡴ࡫ࡷࡩࡰ࡫ࡹ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩண"),e1VlxdKmgOCDHhEzvS3LAyqTMN5Z8P,GGvHJKP9LUxEk10Fw.DOTALL)
		if captcha: UbYKodWeN2wcF1ypOHnEijLz5,CxWkbv4QOd1Il96qTaYrUBRfzej5Vw = captcha[FnBiAjthS8MkXs67W(u"࠶ၠ")]
		zAxv7UuDIQ = oSVpce1UQYrDqhuM6PT[SO94xq1RAkMm2uF(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬத")][yA5z6LIXBlo41PRVMY87wOisFp(u"࠷ၡ")]
		exOIZnGECcR2p3WV4TPY06BNDo7 = PW2xo0Kq3Tcprj9Ck(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠴࠴ၢ"))
		if QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠲ၣ"):
			data = {iRoLg2m47tnDATBHGCSPNyx(u"࠭ࡵࡴࡧࡵࠫ஥"):exOIZnGECcR2p3WV4TPY06BNDo7,SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ஦"):mmn0lB2tFI7XTgVfESo,G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠨࡷࡵࡰࠬ஧"):qrXWyPmSJeCE87RhFfx9,hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩ࡮ࡩࡾ࠭ந"):CxWkbv4QOd1Il96qTaYrUBRfzej5Vw,kEhAHvti6Vnsfx(u"ࠪ࡭ࡩ࠭ன"):kEhAHvti6Vnsfx(u"ࠫࠬப"),wRxoKs10Syj7V4edYhtP(u"ࠬࡰ࡯ࡣࠩ஫"):hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ࡧࡦࡶࡸࡶࡱࡹࠧ஬")}
			WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࡑࡑࡖࡘࠬ஭"),zAxv7UuDIQ,data,sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨࠩம"),E6MIKdpBomef(u"ࠩࠪய"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࠫர"),lc0dpSmwoPDjLnk(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠳ࡰࡧࠫற"))
			BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		BBlXpmUyhFDwNtCVAHoE = wRxoKs10Syj7V4edYhtP(u"ࠬ࠭ல")
		if BBlXpmUyhFDwNtCVAHoE.startswith(SO94xq1RAkMm2uF(u"࠭ࡕࡓࡎࡖࡁࠬள")):
			ppxeJaBXIurWHj = JKw5OWktPZB(fprnld4CZo(u"ࠧ࡭࡫ࡶࡸࠬழ"),BBlXpmUyhFDwNtCVAHoE.split(wRxoKs10Syj7V4edYhtP(u"ࠨࡗࡕࡐࡘࡃࠧவ"),E6MIKdpBomef(u"࠴ၤ"))[E6MIKdpBomef(u"࠴ၤ")])
			for hD6se2E307NcI in ppxeJaBXIurWHj:
				url = hD6se2E307NcI[wRxoKs10Syj7V4edYhtP(u"ࠩࡸࡶࡱ࠭ஶ")]
				gSEirDUWV3 = hD6se2E307NcI[LiRcTVUWuth70DmPy(u"ࠪࡱࡪࡺࡨࡰࡦࠪஷ")]
				data = hD6se2E307NcI[fprnld4CZo(u"ࠫࡩࡧࡴࡢࠩஸ")]
				headers = hD6se2E307NcI[Cu1704YofAbr3QTm(u"ࠬ࡮ࡥࡢࡦࡨࡶࡸ࠭ஹ")]
				WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,gSEirDUWV3,url,data,headers,E6MIKdpBomef(u"࠭ࠧ஺"),LiRcTVUWuth70DmPy(u"ࠧࠨ஻"),Cu1704YofAbr3QTm(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠸ࡸࡤࠨ஼"))
				e1VlxdKmgOCDHhEzvS3LAyqTMN5Z8P = WbTGMHnDysdYZ2lFA.content
				if LiRcTVUWuth70DmPy(u"ࠩ࠱ࡱࡵ࠺ࠧ஽") in e1VlxdKmgOCDHhEzvS3LAyqTMN5Z8P:
					nP18Siw4MjRatJdKYNL7CUyB9eg = kEhAHvti6Vnsfx(u"࡙ࡸࡵࡦᅛ")
					break
				QVJ6Eaiqwp3xLvlI8M7uYzO = str(WbTGMHnDysdYZ2lFA.headers)
				pdqW3KahVj4xHb8rPmZugz = QVJ6Eaiqwp3xLvlI8M7uYzO+e1VlxdKmgOCDHhEzvS3LAyqTMN5Z8P
				ssNoLSgalqVO3MPZefBEb25JwTFX = GGvHJKP9LUxEk10Fw.findall(hBvsQ7oCkKUdwjx58ml3EN(u"ࠪࠬࡦࡱࡷࡢ࡯࡙ࡩࡷ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮࡝ࡹ࠮࠭࠳࠰࠿ࠣࠪࡨࡽࡏ࠴ࠪࡀࠫࠥࠫா"),pdqW3KahVj4xHb8rPmZugz,GGvHJKP9LUxEk10Fw.DOTALL)
				DI9PgKJNvLiuBpXyctMs2RklobGA = GGvHJKP9LUxEk10Fw.findall(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠭ࡵࡱ࡮ࡩࡳ࠴ࠪࡀࠤࠫ࠴࠸ࡇ࠮ࠫࡁࠬࠦࠬி"),pdqW3KahVj4xHb8rPmZugz,GGvHJKP9LUxEk10Fw.DOTALL)
				if DI9PgKJNvLiuBpXyctMs2RklobGA: DI9PgKJNvLiuBpXyctMs2RklobGA = DI9PgKJNvLiuBpXyctMs2RklobGA[G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠴ၥ")]
				if ssNoLSgalqVO3MPZefBEb25JwTFX or DI9PgKJNvLiuBpXyctMs2RklobGA: break
		if not nP18Siw4MjRatJdKYNL7CUyB9eg:
			if not ssNoLSgalqVO3MPZefBEb25JwTFX:
				if captcha and not DI9PgKJNvLiuBpXyctMs2RklobGA:
					if p72fnFtcPix5UKwr9YNzW(u"࠶ၦ"): DI9PgKJNvLiuBpXyctMs2RklobGA = Br34w0lTgsbQF6DvUyRikLEMYfZ(CxWkbv4QOd1Il96qTaYrUBRfzej5Vw,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬࡧࡲࠨீ"),qrXWyPmSJeCE87RhFfx9)
					else:
						if not BBlXpmUyhFDwNtCVAHoE.startswith(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠭ࡉࡅ࠿ࠪு")):
							data = {SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠧࡶࡵࡨࡶࠬூ"):exOIZnGECcR2p3WV4TPY06BNDo7,zqdvcbP5L8BHh(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩ௃"):mmn0lB2tFI7XTgVfESo,dshJSmRqeiP9nap2(u"ࠩࡸࡶࡱ࠭௄"):qrXWyPmSJeCE87RhFfx9,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠪ࡯ࡪࡿࠧ௅"):CxWkbv4QOd1Il96qTaYrUBRfzej5Vw,hBvsQ7oCkKUdwjx58ml3EN(u"ࠫ࡮ࡪࠧெ"):oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠬ࠭ே"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࡪࡰࡤࠪை"):LiRcTVUWuth70DmPy(u"ࠧࡨࡧࡷ࡭ࡩ࠭௉")}
							WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨࡒࡒࡗ࡙࠭ொ"),zAxv7UuDIQ,data,g4g6bfkPtVGU5lIM3(u"ࠩࠪோ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࠫௌ"),sTcr7iDp5eFt4RoLMhuwq1A(u"்ࠫࠬ"),UTelCo0ihE1d5R(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠶ࡷ࡬ࠬ௎"))
							BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
						else: BBlXpmUyhFDwNtCVAHoE = E6MIKdpBomef(u"࠭ࡉࡅ࠿࠴࠶࠸࠺࠺࠻࠼࠽ࡘࡎࡓࡅࡐࡗࡗࡁ࠹࠻ࠧ௏")
						if BBlXpmUyhFDwNtCVAHoE.startswith(zqdvcbP5L8BHh(u"ࠧࡊࡆࡀࠫௐ")):
							MnHCaozwYg0AypZv5fVP = GGvHJKP9LUxEk10Fw.findall(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠨࡋࡇࡁ࠭࠴ࠪࡀࠫ࠽࠾࠿ࡀࡔࡊࡏࡈࡓ࡚࡚࠽ࠩ࠰࠭ࡃ࠮ࠪࠧ௑"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
							DDFQGu9s2ipbxA,I26dXLNboZt7ie = MnHCaozwYg0AypZv5fVP[XzrqbGDIy54juixkMA(u"࠶ၧ")]
							LpdKxnIsY3Sy6qP = Cu1704YofAbr3QTm(u"๊ࠩิ์ࠦวๅ฻่่๏ฯࠠหฯอหั่ࠦใฬ้๋ࠣࠦ࠱࠱ࠢศ่๎ࠦࠧ௒")+I26dXLNboZt7ie+fprnld4CZo(u"ࠪࠤะอๆ๋หࠪ௓")
							dzrSRqtj49so = XOL34TuqseWy2gpYfd()
							dzrSRqtj49so.create(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"๊ࠫำว้ๆฬࠤฯาว้ิࠣๅา฻ࠠฤ่สࠤศ์ำศ่ࠣ์ู้สࠡสิ๊ฬ๋ฬࠡๅ๋้อ๐่หำࠪ௔"),LpdKxnIsY3Sy6qP)
							QmFUvolcPrMdgfLyn4H = MQbODJoPV2w8TEAg4zXZdjLxSW.time()
							nSTcPrUxHjl7Nq2msIR91ZdoB,cHX8bEikra = lc0dpSmwoPDjLnk(u"࠰ၨ"),lc0dpSmwoPDjLnk(u"࠰ၨ")
							while nSTcPrUxHjl7Nq2msIR91ZdoB<int(I26dXLNboZt7ie):
								FFBJqkrThNeWfiaZPE5Aws9uGdp(dzrSRqtj49so,int(nSTcPrUxHjl7Nq2msIR91ZdoB/int(I26dXLNboZt7ie)*Me28A1sBLNIgUp5YCDyvT(u"࠲࠲࠳ၩ")),LpdKxnIsY3Sy6qP,fprnld4CZo(u"ࠬ࠭௕"),I26dXLNboZt7ie+LiRcTVUWuth70DmPy(u"࠭ࠠ࠰ࠢࠪ௖")+str(int(nSTcPrUxHjl7Nq2msIR91ZdoB))+zqdvcbP5L8BHh(u"ࠧࠡࠢฮห๋๐ษࠨௗ"))
								if nSTcPrUxHjl7Nq2msIR91ZdoB>cHX8bEikra+oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠳࠳ၪ"):
									data = {hBvsQ7oCkKUdwjx58ml3EN(u"ࠨࡷࡶࡩࡷ࠭௘"):exOIZnGECcR2p3WV4TPY06BNDo7,sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪ௙"):mmn0lB2tFI7XTgVfESo,YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪࡹࡷࡲࠧ௚"):qrXWyPmSJeCE87RhFfx9,iUeoLOsbHqP(u"ࠫࡰ࡫ࡹࠨ௛"):CxWkbv4QOd1Il96qTaYrUBRfzej5Vw,Me28A1sBLNIgUp5YCDyvT(u"ࠬ࡯ࡤࠨ௜"):DDFQGu9s2ipbxA,Me28A1sBLNIgUp5YCDyvT(u"࠭ࡪࡰࡤࠪ௝"):pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧࡨࡧࡷࡸࡴࡱࡥ࡯ࠩ௞")}
									WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨࡒࡒࡗ࡙࠭௟"),zAxv7UuDIQ,data,p72fnFtcPix5UKwr9YNzW(u"ࠩࠪ௠"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠪࠫ௡"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫࠬ௢"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠷ࡷ࡬ࠬ௣"))
									BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
									if BBlXpmUyhFDwNtCVAHoE.startswith(iUeoLOsbHqP(u"࠭ࡔࡐࡍࡈࡒࡂ࠭௤")):
										DI9PgKJNvLiuBpXyctMs2RklobGA = BBlXpmUyhFDwNtCVAHoE.split(FnBiAjthS8MkXs67W(u"ࠧࡕࡑࡎࡉࡓࡃࠧ௥"),g4g6bfkPtVGU5lIM3(u"࠴ၫ"))[g4g6bfkPtVGU5lIM3(u"࠴ၫ")]
										break
									cHX8bEikra = nSTcPrUxHjl7Nq2msIR91ZdoB
								else: MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(SO94xq1RAkMm2uF(u"࠵ၬ"))
								nSTcPrUxHjl7Nq2msIR91ZdoB = MQbODJoPV2w8TEAg4zXZdjLxSW.time()-QmFUvolcPrMdgfLyn4H
							dzrSRqtj49so.close()
				if DI9PgKJNvLiuBpXyctMs2RklobGA:
					rVQy1ULRjJMShzw2DTnPs = WbTGMHnDysdYZ2lFA.cookies
					BPCp38Kav4wNhmG2gktuTi0yFS7lrM = GGvHJKP9LUxEk10Fw.findall(dshJSmRqeiP9nap2(u"ࠨࡣ࡮ࡻࡦࡳ࡟ࡴࡧࡶࡷ࡮ࡵ࡮࠾ࠪ࠱࠮ࡄ࠯࠻ࠨ௦"),pdqW3KahVj4xHb8rPmZugz,GGvHJKP9LUxEk10Fw.DOTALL)
					if pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩࡤ࡯ࡼࡧ࡭ࡠࡵࡨࡷࡸ࡯࡯࡯ࠩ௧") in list(rVQy1ULRjJMShzw2DTnPs.keys()): BPCp38Kav4wNhmG2gktuTi0yFS7lrM = rVQy1ULRjJMShzw2DTnPs[hBvsQ7oCkKUdwjx58ml3EN(u"ࠪࡥࡰࡽࡡ࡮ࡡࡶࡩࡸࡹࡩࡰࡰࠪ௨")]
					elif BPCp38Kav4wNhmG2gktuTi0yFS7lrM: BPCp38Kav4wNhmG2gktuTi0yFS7lrM = BPCp38Kav4wNhmG2gktuTi0yFS7lrM[S4SOKF2QbBhjCd3RrVMuHIzE(u"࠵ၭ")]
					captcha = GGvHJKP9LUxEk10Fw.findall(lc0dpSmwoPDjLnk(u"ࠫࡵࡧࡧࡦ࠯ࡵࡩࡩ࡯ࡲࡦࡥࡷ࠲࠯ࡅࡡࡤࡶ࡬ࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡴ࡫ࡷࡩࡰ࡫ࡹ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ௩"),e1VlxdKmgOCDHhEzvS3LAyqTMN5Z8P,GGvHJKP9LUxEk10Fw.DOTALL)
					if captcha: UbYKodWeN2wcF1ypOHnEijLz5,CxWkbv4QOd1Il96qTaYrUBRfzej5Vw = captcha[sTcr7iDp5eFt4RoLMhuwq1A(u"࠶ၮ")]
					if BPCp38Kav4wNhmG2gktuTi0yFS7lrM and captcha:
						headers = {Me28A1sBLNIgUp5YCDyvT(u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ௪"):S4SOKF2QbBhjCd3RrVMuHIzE(u"࠭ࡡ࡬ࡹࡤࡱࡤࡹࡥࡴࡵ࡬ࡳࡳࡃࠧ௫")+BPCp38Kav4wNhmG2gktuTi0yFS7lrM,g4g6bfkPtVGU5lIM3(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ௬"):qrXWyPmSJeCE87RhFfx9,kEhAHvti6Vnsfx(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ௭"):wRxoKs10Syj7V4edYhtP(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ௮")}
						data = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪ࡫࠲ࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠮ࡴࡨࡷࡵࡵ࡮ࡴࡧࡀࠫ௯")+DI9PgKJNvLiuBpXyctMs2RklobGA
						WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,iUeoLOsbHqP(u"ࠫࡕࡕࡓࡕࠩ௰"),UbYKodWeN2wcF1ypOHnEijLz5,data,headers,hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࡌࡡ࡭ࡵࡨᅜ"),LiRcTVUWuth70DmPy(u"ࠬ࠭௱"),XzrqbGDIy54juixkMA(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠹ࡸ࡭࠭௲"))
						e1VlxdKmgOCDHhEzvS3LAyqTMN5Z8P = WbTGMHnDysdYZ2lFA.content
						try: cookies = WbTGMHnDysdYZ2lFA.cookies
						except: cookies = {}
						ssNoLSgalqVO3MPZefBEb25JwTFX = GGvHJKP9LUxEk10Fw.findall(hBvsQ7oCkKUdwjx58ml3EN(u"ࠢࠨࠪࡤ࡯ࡼࡧ࡭ࡗࡧࡵ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳ࠴ࠪࡀࠫࠪ࠾ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨ௳"),str(cookies),GGvHJKP9LUxEk10Fw.DOTALL)
			if ssNoLSgalqVO3MPZefBEb25JwTFX:
				WJr6B5imnN1Cypw,ssNoLSgalqVO3MPZefBEb25JwTFX = ssNoLSgalqVO3MPZefBEb25JwTFX[E6MIKdpBomef(u"࠰ၯ")]
				a0xm5s2TFcfeyWZPibQjHnEVg = WJr6B5imnN1Cypw+iRoLg2m47tnDATBHGCSPNyx(u"ࠨ࠿ࠪ௴")+ssNoLSgalqVO3MPZefBEb25JwTFX
				jHevARrF7lS.setSetting(iUeoLOsbHqP(u"ࠩࡤࡺ࠳ࡧ࡫ࡸࡣࡰ࠲ࡻ࡫ࡲࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࠪ௵"),a0xm5s2TFcfeyWZPibQjHnEVg)
				aHKzv76JCVnprbY8w(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪࠫ௶"),bUdr5Hahw6sY8xJ(u"ࠫࠬ௷"),lc0dpSmwoPDjLnk(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ௸"),fprnld4CZo(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣๅา฻ࠠฤ่สࠤส์ำศ่ࠣ࠲࠳่ࠦใษ่ࠤฬ๊ศา่ส้ัࠦศฯิ้ࠤ๋ะววฮ๋ࠣีอࠠศๆไัฺࠦไไ์ࠣ๎ุะฮะ็๊ห๊ࠥวฮไสࠤ࠳࠴้ࠠๆสࠤฯ๎ฬะࠢะหัฯࠠๅว฼หิฯ่ࠠาสࠤฬ๊แฮื่ࠣ฾ีษࠡลื๋ึࠦ࡜࡯࡞ࡱࠤ฾๊ๅศࠢฦ๊ࠥํะศࠢส่ๆำีࠡี๋ๅࠥ๐สไำิࠤๆ๐ࠠฮษ็อࠥะฺ๋ำࠣีอ฽ࠠศๆฯ๋ฬุࠠษษ็ษ๋ะั็ฬࠣ࠲࠳ࠦร้ࠢศ฻ๆอมࠡำส์ฯืࠠศๆศ๊ฯืๆหࠢ࠱࠲ࠥษ่ࠡใุู่ࠥไไࠢส่ึอ่หำࠣ࠲࠳ࠦร้ࠢสืฯิฯศ็࡚ࠣࡕࡔࠠฤ๊ࠣฬึ๎ใิ์ࠪ௹"))
				if sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧ࠯࡯ࡳ࠸ࠬ௺") not in e1VlxdKmgOCDHhEzvS3LAyqTMN5Z8P:
					headers = {pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ௻"):a0xm5s2TFcfeyWZPibQjHnEVg}
					WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,g4g6bfkPtVGU5lIM3(u"ࠩࡊࡉ࡙࠭௼"),qrXWyPmSJeCE87RhFfx9,S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠪࠫ௽"),headers,kEhAHvti6Vnsfx(u"ࠫࠬ௾"),iUeoLOsbHqP(u"ࠬ࠭௿"),g4g6bfkPtVGU5lIM3(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠺ࡸ࡭࠭ఀ"))
					e1VlxdKmgOCDHhEzvS3LAyqTMN5Z8P = WbTGMHnDysdYZ2lFA.content
	if not nP18Siw4MjRatJdKYNL7CUyB9eg and not a0xm5s2TFcfeyWZPibQjHnEVg: aHKzv76JCVnprbY8w(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࠨఁ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨࠩం"),iUeoLOsbHqP(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬః"),LiRcTVUWuth70DmPy(u"ࠪๅู๊สࠡ฻่่๏ฯࠠโฯุࠤศ์วࠡล้ืฬ์ࠠ࠯࠰ࠣัฬ๎ไࠡว฼หิฯࠠศๆ฼้้๐ษࠡ็ิอࠥษฮา๋ࠣฬฬูสฯัส้ࠥ์แิࠢส่ๆ๐ฯ๋๊ࠣวํࠦแ๋ัํ์ࠥเ๊า้้๋ࠣࠦๆโีࠣห้๋่ใ฻ࠪఄ"))
	return e1VlxdKmgOCDHhEzvS3LAyqTMN5Z8P
def AjTX6bWUoJ(url,type,dDZQSEGRTo9g85x1C):
	uuIjMn1YTf687WlRcOmhq4G23H,HHSO6Q4KI0hlPxYpNuXRkWCmjEgA = [],[]
	qrXWyPmSJeCE87RhFfx9 = url
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,bUdr5Hahw6sY8xJ(u"ࠫࡌࡋࡔࠨఅ"),url,Me28A1sBLNIgUp5YCDyvT(u"ࠬ࠭ఆ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"࠭ࠧఇ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧࠨఈ"),kEhAHvti6Vnsfx(u"ࠨࠩఉ"),dshJSmRqeiP9nap2(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡘࡃࡐ࠱࠶ࡹࡴࠨఊ"))
	X3in5vNhqwWEG2TafmVCrFbSYDxjoK = WbTGMHnDysdYZ2lFA.content
	k1kO0p2aAHS3DPb9QL = []
	if SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫఋ") in X3in5vNhqwWEG2TafmVCrFbSYDxjoK or dshJSmRqeiP9nap2(u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨఌ") in X3in5vNhqwWEG2TafmVCrFbSYDxjoK:
		EHDeldN7L2k19JBUqhmsuSXiwV = GGvHJKP9LUxEk10Fw.findall(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࡩࡶࡷࡴ࠳࠰࠿࠽࠱ࡤࡂࠬ఍"),X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
		if EHDeldN7L2k19JBUqhmsuSXiwV:
			for UCEFMfKbgpd in EHDeldN7L2k19JBUqhmsuSXiwV:
				gI487voLsArVqW6Ffp = GGvHJKP9LUxEk10Fw.findall(zqdvcbP5L8BHh(u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪఎ"),UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
				for ELbNB92cOh5dqtpVmi40kY,title in gI487voLsArVqW6Ffp:
					if ELbNB92cOh5dqtpVmi40kY in uuIjMn1YTf687WlRcOmhq4G23H: continue
					if fprnld4CZo(u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࠨఏ") not in ELbNB92cOh5dqtpVmi40kY and kEhAHvti6Vnsfx(u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬఐ") not in ELbNB92cOh5dqtpVmi40kY: continue
					if g4g6bfkPtVGU5lIM3(u"ࠩสࠫ఑") not in title:
						k1kO0p2aAHS3DPb9QL.append((title,ELbNB92cOh5dqtpVmi40kY))
						continue
					title = title.replace(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪࡀ࠴ࡹࡰࡢࡰࡁࠫఒ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࠬఓ")).replace(p72fnFtcPix5UKwr9YNzW(u"ࠬࠦ࠭ࠡࠩఔ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ࠧక")).strip(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧࠡࠩఖ")).replace(hBvsQ7oCkKUdwjx58ml3EN(u"ࠨࠢࠣࠫగ"),p72fnFtcPix5UKwr9YNzW(u"ࠩࠣࠫఘ"))
					if wRxoKs10Syj7V4edYhtP(u"ࠪࡷࡵࡧ࡮ࠨఙ") in title: continue
					uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY)
					HHSO6Q4KI0hlPxYpNuXRkWCmjEgA.append(title)
			for title,ELbNB92cOh5dqtpVmi40kY in k1kO0p2aAHS3DPb9QL:
				if ELbNB92cOh5dqtpVmi40kY not in uuIjMn1YTf687WlRcOmhq4G23H:
					uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY)
					HHSO6Q4KI0hlPxYpNuXRkWCmjEgA.append(title)
			z0jyetbQwKrIclL9vJW = iRoLg2m47tnDATBHGCSPNyx(u"࠱ၰ")
			if len(uuIjMn1YTf687WlRcOmhq4G23H)>oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠳ၱ"):
				z0jyetbQwKrIclL9vJW = D1DJtzviFZSrA(hBvsQ7oCkKUdwjx58ml3EN(u"ࠫอ฿ึ่ษࠣ๎าะวอࠢ࠹࠴ࠥัว็์ฬࠫచ"),HHSO6Q4KI0hlPxYpNuXRkWCmjEgA)
				if z0jyetbQwKrIclL9vJW==-lc0dpSmwoPDjLnk(u"࠴ၲ"): return UTelCo0ihE1d5R(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡄࡣࡱࡧࡪࡲࡥࡥࠢࡄࡏ࡜ࡇࡍࠨఛ"),[],[]
			if uuIjMn1YTf687WlRcOmhq4G23H and z0jyetbQwKrIclL9vJW>=iUeoLOsbHqP(u"࠴ၳ"): qrXWyPmSJeCE87RhFfx9 = uuIjMn1YTf687WlRcOmhq4G23H[z0jyetbQwKrIclL9vJW]
	e1VlxdKmgOCDHhEzvS3LAyqTMN5Z8P = BV6y83JXwAmTncRHfsFa(qrXWyPmSJeCE87RhFfx9)
	zzvBg3ShiamAZ,eyUmvNFiYsE = [],[]
	if type==iUeoLOsbHqP(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨజ"):
		ccth2dxLzePUg8SfVY = GGvHJKP9LUxEk10Fw.findall(lc0dpSmwoPDjLnk(u"ࠧࡣࡶࡱ࠱ࡱࡵࡡࡥࡧࡵ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬఝ"),e1VlxdKmgOCDHhEzvS3LAyqTMN5Z8P,GGvHJKP9LUxEk10Fw.DOTALL)
		if ccth2dxLzePUg8SfVY:
			ELbNB92cOh5dqtpVmi40kY = GhPlajzTxY8(ccth2dxLzePUg8SfVY[zqdvcbP5L8BHh(u"࠵ၴ")])
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
			eyUmvNFiYsE.append(dDZQSEGRTo9g85x1C)
	elif type==dshJSmRqeiP9nap2(u"ࠨࡹࡤࡸࡨ࡮ࠧఞ"):
		gI487voLsArVqW6Ffp = GGvHJKP9LUxEk10Fw.findall(iRoLg2m47tnDATBHGCSPNyx(u"ࠩ࠿ࡷࡴࡻࡲࡤࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩࡻࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫట"),e1VlxdKmgOCDHhEzvS3LAyqTMN5Z8P,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,size in gI487voLsArVqW6Ffp:
			if not ELbNB92cOh5dqtpVmi40kY: continue
			if dDZQSEGRTo9g85x1C in size:
				eyUmvNFiYsE.append(size)
				zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
				break
		if not zzvBg3ShiamAZ:
			for ELbNB92cOh5dqtpVmi40kY,size in gI487voLsArVqW6Ffp:
				if not ELbNB92cOh5dqtpVmi40kY: continue
				eyUmvNFiYsE.append(size)
				zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	if not zzvBg3ShiamAZ: return lc0dpSmwoPDjLnk(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡋࡘࡃࡐࠫఠ"),[],[]
	return Cu1704YofAbr3QTm(u"ࠫࠬడ"),eyUmvNFiYsE,zzvBg3ShiamAZ
def iz81jLCMhR(url,WJr6B5imnN1Cypw):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,lc0dpSmwoPDjLnk(u"ࠬࡍࡅࡕࠩఢ"),url,g4g6bfkPtVGU5lIM3(u"࠭ࠧణ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࠨత"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࡔࡳࡷࡨᅝ"),YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠨࠩథ"),UTelCo0ihE1d5R(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡐࡃࡐ࠱࠶ࡹࡴࠨద"))
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	cookies = WbTGMHnDysdYZ2lFA.cookies
	if G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠪ࡫ࡴࡲࡩ࡯࡭ࠪధ") in list(cookies.keys()):
		a0xm5s2TFcfeyWZPibQjHnEVg = cookies[fprnld4CZo(u"ࠫ࡬ࡵ࡬ࡪࡰ࡮ࠫన")]
		a0xm5s2TFcfeyWZPibQjHnEVg = GhPlajzTxY8(ptMqV54oKJhQ8CH(a0xm5s2TFcfeyWZPibQjHnEVg))
		items = GGvHJKP9LUxEk10Fw.findall(kEhAHvti6Vnsfx(u"ࠬࡸ࡯ࡶࡶࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭఩"),a0xm5s2TFcfeyWZPibQjHnEVg,GGvHJKP9LUxEk10Fw.DOTALL)
		dR2vHyAtl8pJN1 = items[SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠶ၵ")].replace(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠭࡜࠰ࠩప"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧ࠰ࠩఫ"))
		dR2vHyAtl8pJN1 = ptMqV54oKJhQ8CH(dR2vHyAtl8pJN1)
	else: dR2vHyAtl8pJN1 = url
	if YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠨࡥࡤࡸࡨ࡮࠮ࡪࡵࠪబ") in dR2vHyAtl8pJN1:
		id = dR2vHyAtl8pJN1.split(E6MIKdpBomef(u"ࠩࠨ࠶ࡋ࠭భ"))[-xW2Arao7YVOemw(u"࠱ၶ")]
		dR2vHyAtl8pJN1 = hBvsQ7oCkKUdwjx58ml3EN(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡧࡦࡺࡣࡩ࠰࡬ࡷ࠴࠭మ")+id
		return yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧయ"),[XzrqbGDIy54juixkMA(u"ࠬ࠭ర")],[dR2vHyAtl8pJN1]
	else:
		website = oSVpce1UQYrDqhuM6PT[kEhAHvti6Vnsfx(u"࠭ࡁࡌࡑࡄࡑࠬఱ")][iRoLg2m47tnDATBHGCSPNyx(u"࠱ၷ")]
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࡈࡇࡗࠫల"),website,yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨࠩళ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩࠪఴ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࡕࡴࡸࡩᅞ"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠪࠫవ"),E6MIKdpBomef(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍࡒࡅࡒ࠳࠲࡯ࡦࠪశ"))
		zswE5N1WPkOx9hlCQr2KgGR7a6muI = WbTGMHnDysdYZ2lFA.url
		n2DARgtpxKLGM6T8YiUJkjVWslrw = dR2vHyAtl8pJN1.split(UTelCo0ihE1d5R(u"ࠬ࠵ࠧష"))[hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠴ၸ")]
		T8DvOxJcR7ugUZ0q = zswE5N1WPkOx9hlCQr2KgGR7a6muI.split(XzrqbGDIy54juixkMA(u"࠭࠯ࠨస"))[zqdvcbP5L8BHh(u"࠵ၹ")]
		XwyU6PQgprMI0 = dR2vHyAtl8pJN1.replace(n2DARgtpxKLGM6T8YiUJkjVWslrw,T8DvOxJcR7ugUZ0q)
		headers = { hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫహ"):Me28A1sBLNIgUp5YCDyvT(u"ࠨࠩ఺") , iRoLg2m47tnDATBHGCSPNyx(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ఻"):sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷ఼ࠫ") , iRoLg2m47tnDATBHGCSPNyx(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬఽ"):XwyU6PQgprMI0 }
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠬࡖࡏࡔࡖࠪా"), XwyU6PQgprMI0, FvNyZqaLKw(u"࠭ࠧి"), headers, FnBiAjthS8MkXs67W(u"ࡈࡤࡰࡸ࡫ᅟ"),UTelCo0ihE1d5R(u"ࠧࠨీ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡏࡂࡏ࠰࠷ࡷࡪࠧు"))
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		items = GGvHJKP9LUxEk10Fw.findall(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠩࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩూ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.IGNORECASE)
		if not items:
			items = GGvHJKP9LUxEk10Fw.findall(SO94xq1RAkMm2uF(u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫృ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.IGNORECASE)
			if not items:
				items = GGvHJKP9LUxEk10Fw.findall(l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫࡁ࡫࡭ࡣࡧࡧ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫౄ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.IGNORECASE)
		if items:
			ELbNB92cOh5dqtpVmi40kY = items[pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠴ၺ")].replace(Me28A1sBLNIgUp5YCDyvT(u"ࠬࡢ࠯ࠨ౅"),XzrqbGDIy54juixkMA(u"࠭࠯ࠨె"))
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.rstrip(iUeoLOsbHqP(u"ࠧ࠰ࠩే"))
			if SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࡪࡷࡸࡵ࠭ై") not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = UTelCo0ihE1d5R(u"ࠩ࡫ࡸࡹࡶ࠺ࠨ౉") + ELbNB92cOh5dqtpVmi40kY
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.replace(hBvsQ7oCkKUdwjx58ml3EN(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫొ"),g4g6bfkPtVGU5lIM3(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠭ో"))
			if WJr6B5imnN1Cypw==zqdvcbP5L8BHh(u"ࠬ࠭ౌ"): svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = hBvsQ7oCkKUdwjx58ml3EN(u"్࠭ࠧ"),[sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࠨ౎")],[ELbNB92cOh5dqtpVmi40kY]
			else: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = UTelCo0ihE1d5R(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ౏"),[fprnld4CZo(u"ࠩࠪ౐")],[ELbNB92cOh5dqtpVmi40kY]
		else: svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = yA5z6LIXBlo41PRVMY87wOisFp(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡋࡐࡃࡐࠫ౑"),[],[]
		return svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ
def fdEIVcHevjQipl1CPyR(url):
	headers = { G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ౒") : wRxoKs10Syj7V4edYhtP(u"ࠬ࠭౓") }
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(xh9BXlAw0UoVsIZ4if3,url,S4SOKF2QbBhjCd3RrVMuHIzE(u"࠭ࠧ౔"),headers,SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠧࠨౕ"),XzrqbGDIy54juixkMA(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡗࡇࡐࡊࡆ࡙ࡍࡉࡋࡏ࠮࠳ࡶࡸౖࠬ"))
	items = GGvHJKP9LUxEk10Fw.findall(dshJSmRqeiP9nap2(u"ࠩ࠿ࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡰࡦࡨࡥ࡭࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ౗"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	eyUmvNFiYsE,zzvBg3ShiamAZ,errno = [],[],LiRcTVUWuth70DmPy(u"ࠪࠫౘ")
	if items:
		for ELbNB92cOh5dqtpVmi40kY,ccIZBYDOGdJlTE81Li2wAmuKtk in items:
			eyUmvNFiYsE.append(ccIZBYDOGdJlTE81Li2wAmuKtk)
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	if len(zzvBg3ShiamAZ)==l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠵ၻ"): return UTelCo0ihE1d5R(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡒࡂࡒࡌࡈ࡛ࡏࡄࡆࡑࠪౙ"),[],[]
	return hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬ࠭ౚ"),eyUmvNFiYsE,zzvBg3ShiamAZ
def dGXWThCABUxw6Ep1KDk34Z0NIcL(url):
	headers = {Me28A1sBLNIgUp5YCDyvT(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ౛"):pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧࠨ౜")}
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(xh9BXlAw0UoVsIZ4if3,url,sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨࠩౝ"),headers,SO94xq1RAkMm2uF(u"ࠩࠪ౞"),dshJSmRqeiP9nap2(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡒࡎࡒࡅࡉ࠳࠱ࡴࡶࠪ౟"))
	items = GGvHJKP9LUxEk10Fw.findall(iUeoLOsbHqP(u"ࠫࡸࡵࡵࡳࡥࡨࡷ࠿ࠦ࡜࡜ࠤࠫ࠲࠯ࡅࠩࠣࠩౠ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if items:
		url = items[dshJSmRqeiP9nap2(u"࠶ၼ")]+SO94xq1RAkMm2uF(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨౡ")+url
		return fprnld4CZo(u"࠭ࠧౢ"),[iRoLg2m47tnDATBHGCSPNyx(u"ࠧࠨౣ")],[url]
	else: return SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡙ࠣࡖࡒࡏࡂࡆࠪ౤"),[],[]
def prUJEtlVN8uZ0Gkg9HFP3LY7qe(url):
	url = url.strip(lc0dpSmwoPDjLnk(u"ࠩ࠲ࠫ౥"))
	if YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠲ࠫ౦") in url: id = url.split(UTelCo0ihE1d5R(u"ࠫ࠴࠭౧"))[oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠴ၽ")]
	else: id = url.split(wRxoKs10Syj7V4edYhtP(u"ࠬ࠵ࠧ౨"))[-Cu1704YofAbr3QTm(u"࠲ၾ")]
	url = QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷࡥࡶࡸࡷ࡫ࡡ࡮࠰ࡷࡳ࠴ࡶ࡬ࡢࡻࡨࡶࡄ࡬ࡩࡥ࠿ࠪ౩") + id
	headers = { xW2Arao7YVOemw(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ౪") : pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࠩ౫") }
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(xh9BXlAw0UoVsIZ4if3,url,dshJSmRqeiP9nap2(u"ࠩࠪ౬"),headers,FvNyZqaLKw(u"ࠪࠫ౭"),p72fnFtcPix5UKwr9YNzW(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡗࡅࡖࡘࡗࡋࡁࡎ࠯࠴ࡷࡹ࠭౮"))
	BBlXpmUyhFDwNtCVAHoE = BBlXpmUyhFDwNtCVAHoE.replace(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬࡢ࡜ࠨ౯"),XzrqbGDIy54juixkMA(u"࠭ࠧ౰"))
	items = GGvHJKP9LUxEk10Fw.findall(xW2Arao7YVOemw(u"ࠧࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ౱"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if items: return zqdvcbP5L8BHh(u"ࠨࠩ౲"),[lc0dpSmwoPDjLnk(u"ࠩࠪ౳")],[ items[bUdr5Hahw6sY8xJ(u"࠲ၿ")] ]
	else: return G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡜ࡃࡔࡖࡕࡉࡆࡓࠧ౴"),[],[]
def ZZLo0QTgRy(url):
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(xh9BXlAw0UoVsIZ4if3,url,zqdvcbP5L8BHh(u"ࠫࠬ౵"),FnBiAjthS8MkXs67W(u"ࠬ࠭౶"),yA5z6LIXBlo41PRVMY87wOisFp(u"࠭ࠧ౷"),wRxoKs10Syj7V4edYhtP(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡎࡊࡏ࡛ࡃ࠰࠵ࡸࡺࠧ౸"))
	items = GGvHJKP9LUxEk10Fw.findall(lc0dpSmwoPDjLnk(u"ࠨࡵࡵࡧ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡯ࡥࡧ࡫࡬࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠣࡶࡪࡹ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ౹"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	eyUmvNFiYsE,zzvBg3ShiamAZ = [],[]
	for ELbNB92cOh5dqtpVmi40kY,ccIZBYDOGdJlTE81Li2wAmuKtk,hIkZC1KLl25AW in items:
		eyUmvNFiYsE.append(ccIZBYDOGdJlTE81Li2wAmuKtk+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩࠣࠫ౺")+hIkZC1KLl25AW)
		zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	if len(zzvBg3ShiamAZ)==iUeoLOsbHqP(u"࠳ႀ"): return bUdr5Hahw6sY8xJ(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡜ࡉࡅࡑ࡝ࡅࠬ౻"),[],[]
	return oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫࠬ౼"),eyUmvNFiYsE,zzvBg3ShiamAZ
def DVbf9m8hvQiKzgj172ZqkedE5sC(url):
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(xh9BXlAw0UoVsIZ4if3,url,FnBiAjthS8MkXs67W(u"ࠬ࠭౽"),lc0dpSmwoPDjLnk(u"࠭ࠧ౾"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧࠨ౿"),FvNyZqaLKw(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡇࡔࡄࡊ࡙ࡍࡉࡋࡏ࠮࠳ࡶࡸࠬಀ"))
	items = GGvHJKP9LUxEk10Fw.findall(xW2Arao7YVOemw(u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡻ࡯ࡤࡦࡱ࡟ࠬࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬ࠲ࠧࠩ࠰࠭ࡃ࠮࠭࡜ࠪ࡞ࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄ࠮ࠫࡁ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭࠱࠴ࠪࡀ࠾࠲ࡸࡩࡄࠢಁ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	items = set(items)
	eyUmvNFiYsE,zzvBg3ShiamAZ = [],[]
	for id,VRnfEFmJzUrSljM8,hash,ccIZBYDOGdJlTE81Li2wAmuKtk,hIkZC1KLl25AW in items:
		url = XzrqbGDIy54juixkMA(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯࠯ࡷࡶ࠳ࡩࡲ࠿ࡰࡲࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡵࡲࡪࡩࠩ࡭ࡩࡃࠧಂ")+id+iUeoLOsbHqP(u"ࠫࠫࡳ࡯ࡥࡧࡀࠫಃ")+VRnfEFmJzUrSljM8+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬࠬࡨࡢࡵ࡫ࡁࠬ಄")+hash
		BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(xh9BXlAw0UoVsIZ4if3,url,fprnld4CZo(u"࠭ࠧಅ"),SO94xq1RAkMm2uF(u"ࠧࠨಆ"),E6MIKdpBomef(u"ࠨࠩಇ"),FvNyZqaLKw(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡝ࡁࡕࡅࡋ࡚ࡎࡊࡅࡐ࠯࠵ࡲࡩ࠭ಈ"))
		items = GGvHJKP9LUxEk10Fw.findall(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࡨ࡮ࡸࡥࡤࡶࠣࡰ࡮ࡴ࡫࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩಉ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY in items:
			eyUmvNFiYsE.append(ccIZBYDOGdJlTE81Li2wAmuKtk+LiRcTVUWuth70DmPy(u"ࠫࠥ࠭ಊ")+hIkZC1KLl25AW)
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	if len(zzvBg3ShiamAZ)==Cu1704YofAbr3QTm(u"࠴ႁ"): return lc0dpSmwoPDjLnk(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒࠫಋ"),[],[]
	return wRxoKs10Syj7V4edYhtP(u"࠭ࠧಌ"),eyUmvNFiYsE,zzvBg3ShiamAZ
def LMV09wIFXvGWm3(url):
	ELbNB92cOh5dqtpVmi40kY = iUeoLOsbHqP(u"ࠧࠨ಍")
	if XzrqbGDIy54juixkMA(u"࠶ႂ") or lc0dpSmwoPDjLnk(u"ࠨࡍࡨࡽࡂ࠭ಎ") not in url:
		dR2vHyAtl8pJN1 = url.replace(p72fnFtcPix5UKwr9YNzW(u"ࠩࡸࡴࡧࡵ࡭࠯࡮࡬ࡺࡪ࠭ಏ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠪࡹࡵࡶ࡯࡮࠰࡯࡭ࡻ࡫ࠧಐ"))
		dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1.split(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫ࠴࠭಑"))
		id = dR2vHyAtl8pJN1[dshJSmRqeiP9nap2(u"࠹ႃ")]
		dR2vHyAtl8pJN1 = Cu1704YofAbr3QTm(u"ࠬ࠵ࠧಒ").join(dR2vHyAtl8pJN1[l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠰ႄ"):iRoLg2m47tnDATBHGCSPNyx(u"࠵ႅ")])
		vpWXJDC4lTByaqcn56OFwUmieV = {pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭ࡩࡥࠩಓ"):id,SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠧࡰࡲࠪಔ"):sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࠵ࠫಕ"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩࡰࡩࡹ࡮࡯ࡥࡡࡩࡶࡪ࡫ࠧಖ"):LiRcTVUWuth70DmPy(u"ࠪࡊࡷ࡫ࡥࠬࡆࡲࡻࡳࡲ࡯ࡢࡦ࠮ࠩ࠸ࡋࠥ࠴ࡇࠪಗ")}
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,FvNyZqaLKw(u"ࠫࡕࡕࡓࡕࠩಘ"),dR2vHyAtl8pJN1,vpWXJDC4lTByaqcn56OFwUmieV,xW2Arao7YVOemw(u"ࠬ࠭ಙ"),kEhAHvti6Vnsfx(u"࠭ࠧಚ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠧࠨಛ"),XzrqbGDIy54juixkMA(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡚ࡖࡂࡐࡏ࠰࠵ࡸࡺࠧಜ"))
		if Me28A1sBLNIgUp5YCDyvT(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫಝ") in list(WbTGMHnDysdYZ2lFA.headers.keys()): ELbNB92cOh5dqtpVmi40kY = WbTGMHnDysdYZ2lFA.headers[dshJSmRqeiP9nap2(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬಞ")]
		if not ELbNB92cOh5dqtpVmi40kY and WbTGMHnDysdYZ2lFA.succeeded:
			BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
			ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫ࡮ࡪ࠽ࠣࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨಟ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
			if ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY[wRxoKs10Syj7V4edYhtP(u"࠲ႆ")]
	else:
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,g4g6bfkPtVGU5lIM3(u"ࠬࡍࡅࡕࠩಠ"),url,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭ࠧಡ"),FnBiAjthS8MkXs67W(u"ࠧࠨಢ"),FnBiAjthS8MkXs67W(u"ࠨࠩಣ"),LiRcTVUWuth70DmPy(u"ࠩࠪತ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡑࡄࡒࡑ࠲࠸࡮ࡥࠩಥ"))
		if lc0dpSmwoPDjLnk(u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭ದ") in list(WbTGMHnDysdYZ2lFA.headers.keys()): ELbNB92cOh5dqtpVmi40kY = WbTGMHnDysdYZ2lFA.headers[xW2Arao7YVOemw(u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧಧ")]
	if ELbNB92cOh5dqtpVmi40kY: return E6MIKdpBomef(u"࠭ࠧನ"),[Cu1704YofAbr3QTm(u"ࠧࠨ಩")],[ELbNB92cOh5dqtpVmi40kY]
	return bUdr5Hahw6sY8xJ(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡙ࠣࡕࡈࡏࡎࠩಪ"),[],[]
def HSdLNlvDbwtMo6XiQ(url):
	headers = { p72fnFtcPix5UKwr9YNzW(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ಫ") : FvNyZqaLKw(u"ࠪࠫಬ") }
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(xh9BXlAw0UoVsIZ4if3,url,E6MIKdpBomef(u"ࠫࠬಭ"),headers,g4g6bfkPtVGU5lIM3(u"ࠬ࠭ಮ"),fprnld4CZo(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡏࡍࡎ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨಯ"))
	items = GGvHJKP9LUxEk10Fw.findall(xW2Arao7YVOemw(u"ࠧࡴࡱࡸࡶࡨ࡫ࡳ࠻࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ರ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	eyUmvNFiYsE,zzvBg3ShiamAZ = [],[]
	if items:
		eyUmvNFiYsE.append(FnBiAjthS8MkXs67W(u"ࠨ࡯ࡳ࠸ࠬಱ"))
		zzvBg3ShiamAZ.append(items[oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠴ႈ")][Cu1704YofAbr3QTm(u"࠴ႇ")])
		eyUmvNFiYsE.append(g4g6bfkPtVGU5lIM3(u"ࠩࡰ࠷ࡺ࠾ࠧಲ"))
		zzvBg3ShiamAZ.append(items[SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠵ႉ")][SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠵ႉ")])
		return sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࠫಳ"),eyUmvNFiYsE,zzvBg3ShiamAZ
	else: return XzrqbGDIy54juixkMA(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡌࡊࡋ࡙ࡍࡉࡋࡏࠨ಴"),[],[]
jc93gDTzOkyfZvo6FeKPBdJmGMtW = FvNyZqaLKw(u"ࡉࡥࡱࡹࡥᅠ")
def bbPAtUuTEM(url):
	global jc93gDTzOkyfZvo6FeKPBdJmGMtW
	if jc93gDTzOkyfZvo6FeKPBdJmGMtW: return iUeoLOsbHqP(u"ࠬࡋࡲࡳࡱࡵࠤࠥࠦࠠ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࠥࡌࡡࡪ࡮ࡨࡨࠬವ"),[],[]
	jc93gDTzOkyfZvo6FeKPBdJmGMtW = oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࡘࡷࡻࡥᅡ")
	id = url.split(dshJSmRqeiP9nap2(u"࠭࠯ࠨಶ"))[-G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠷ႊ")]
	id = id.split(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧࠧࠩಷ"))[Cu1704YofAbr3QTm(u"࠰ႋ")]
	id = id.replace(FnBiAjthS8MkXs67W(u"ࠨࡹࡤࡸࡨ࡮࠿ࡷ࠿ࠪಸ"),iUeoLOsbHqP(u"ࠩࠪಹ"))
	dR2vHyAtl8pJN1 = oSVpce1UQYrDqhuM6PT[bUdr5Hahw6sY8xJ(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ಺")][xW2Arao7YVOemw(u"࠱ႌ")]+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࠧ಻")+id
	GEtPTVHm4U = Me28A1sBLNIgUp5YCDyvT(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡿ࡯ࡶࡶࡸ࠲ࡧ࡫࠯ࠨ಼")+id
	EER1WVLBPmTZd,Ue61rJH2dAZ30qM5n,B2FwNxsjTPVz37rk6nXJieLRbtEo,hhek6RlcmH8IG = YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ࠧಽ"),fprnld4CZo(u"ࠧࠨಾ"),SO94xq1RAkMm2uF(u"ࠨࠩಿ"),LiRcTVUWuth70DmPy(u"ࠩࠪೀ")
	headers = {S4SOKF2QbBhjCd3RrVMuHIzE(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧು"):p72fnFtcPix5UKwr9YNzW(u"ࠫࠬೂ")}
	if kEhAHvti6Vnsfx(u"࠲ႍ"):
		for CQMipytPbq in range(FnBiAjthS8MkXs67W(u"࠸ႎ")):
			WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,iUeoLOsbHqP(u"ࠬࡍࡅࡕࠩೃ"),dR2vHyAtl8pJN1,FnBiAjthS8MkXs67W(u"࠭ࠧೄ"),headers,l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧࠨ೅"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࠩೆ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠱ࡴࡶࠪೇ"))
			BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
			if g4g6bfkPtVGU5lIM3(u"ࠪ࡭ࡹࡧࡧࠨೈ") in BBlXpmUyhFDwNtCVAHoE: break
			MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(lc0dpSmwoPDjLnk(u"࠶ႏ"))
		JWPYA5r2liu0zQTHwhXfDay4 = GGvHJKP9LUxEk10Fw.findall(FvNyZqaLKw(u"ࠫࡻࡧࡲࠡࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡔࡱࡧࡹࡦࡴࡕࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࠨ࠯ࠬࡂ࠭ࡀࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ೉"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if JWPYA5r2liu0zQTHwhXfDay4: JWPYA5r2liu0zQTHwhXfDay4 = JWPYA5r2liu0zQTHwhXfDay4[SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠵႐")]
		else: JWPYA5r2liu0zQTHwhXfDay4 = BBlXpmUyhFDwNtCVAHoE
	else:
		headers[hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫೊ")] = zqdvcbP5L8BHh(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯ࠩೋ")
		XwyU6PQgprMI0 = oSVpce1UQYrDqhuM6PT[SO94xq1RAkMm2uF(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨೌ")][iRoLg2m47tnDATBHGCSPNyx(u"࠶႑")]+bUdr5Hahw6sY8xJ(u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡱ࡮ࡤࡽࡪࡸ್ࠧ")
		IWPVYFU8cTixALJf = fprnld4CZo(u"ࠩࡾࠦࡻ࡯ࡤࡦࡱࡌࡨࠧࡀࠠࠣࠩ೎")+id+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠪࠦ࠱ࠦࠢࡤࡱࡱࡸࡪࡾࡴࠣ࠼ࠣࡿࠧࡩ࡬ࡪࡧࡱࡸࠧࡀࠠࡼࠤࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠤ࠽ࠤࠧ࠷࠮࠺ࠤ࠯ࠤࠧࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠤ࠽ࠤࠧࡇࡎࡅࡔࡒࡍࡉࡥࡔࡆࡕࡗࡗ࡚ࡏࡔࡆࠤࢀࢁࢂ࠭೏")
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,FvNyZqaLKw(u"ࠫࡕࡕࡓࡕࠩ೐"),XwyU6PQgprMI0,IWPVYFU8cTixALJf,headers,SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠬ࠭೑"),bUdr5Hahw6sY8xJ(u"࠭ࠧ೒"),p72fnFtcPix5UKwr9YNzW(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠶ࡹࡴࠨ೓"))
		JWPYA5r2liu0zQTHwhXfDay4 = WbTGMHnDysdYZ2lFA.content
	JWPYA5r2liu0zQTHwhXfDay4 = JWPYA5r2liu0zQTHwhXfDay4.replace(g4g6bfkPtVGU5lIM3(u"ࠨ࡞࡟ࡹ࠵࠶࠲࠷ࠩ೔"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠩࠩࠫೕ"))
	zCqhvsn4QIRHAV5GKpB = JKw5OWktPZB(FvNyZqaLKw(u"ࠪࡨ࡮ࡩࡴࠨೖ"),JWPYA5r2liu0zQTHwhXfDay4)
	eyUmvNFiYsE,zzvBg3ShiamAZ = [G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫอี่็ࠢอีั๋ษࠡ์๋ฮ๏๎ศࠨ೗")],[SO94xq1RAkMm2uF(u"ࠬ࠭೘")]
	try:
		RGqszVlOk9LXQ = zCqhvsn4QIRHAV5GKpB[kEhAHvti6Vnsfx(u"࠭ࡣࡢࡲࡷ࡭ࡴࡴࡳࠨ೙")][Me28A1sBLNIgUp5YCDyvT(u"ࠧࡱ࡮ࡤࡽࡪࡸࡃࡢࡲࡷ࡭ࡴࡴࡳࡕࡴࡤࡧࡰࡲࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ೚")][l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠨࡥࡤࡴࡹ࡯࡯࡯ࡖࡵࡥࡨࡱࡳࠨ೛")]
		for wVSAGvzDhsmgnXkyPLKjiFElOrd in RGqszVlOk9LXQ:
			ELbNB92cOh5dqtpVmi40kY = wVSAGvzDhsmgnXkyPLKjiFElOrd[hBvsQ7oCkKUdwjx58ml3EN(u"ࠩࡥࡥࡸ࡫ࡕࡳ࡮ࠪ೜")]
			try: title = wVSAGvzDhsmgnXkyPLKjiFElOrd[xW2Arao7YVOemw(u"ࠪࡲࡦࡳࡥࠨೝ")][bUdr5Hahw6sY8xJ(u"ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨೞ")]
			except: title = wVSAGvzDhsmgnXkyPLKjiFElOrd[xW2Arao7YVOemw(u"ࠬࡴࡡ࡮ࡧࠪ೟")][yA5z6LIXBlo41PRVMY87wOisFp(u"࠭ࡲࡶࡰࡶࠫೠ")][YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠰႒")][UTelCo0ihE1d5R(u"ࠧࡵࡧࡻࡸࡹ࠭ೡ")]
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
			eyUmvNFiYsE.append(title)
	except: pass
	if len(eyUmvNFiYsE)>E6MIKdpBomef(u"࠲႓"):
		z0jyetbQwKrIclL9vJW = D1DJtzviFZSrA(wRxoKs10Syj7V4edYhtP(u"ࠨษัฮึࠦวๅฬิะ๊ฯࠠࠩࠩೢ")+str(len(eyUmvNFiYsE))+oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"้้ࠩࠣ็ࠩࠨೣ"), eyUmvNFiYsE)
		if z0jyetbQwKrIclL9vJW==-FvNyZqaLKw(u"࠳႔"): return S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ೤"),[],[]
		elif z0jyetbQwKrIclL9vJW!=FvNyZqaLKw(u"࠳႕"):
			ELbNB92cOh5dqtpVmi40kY = zzvBg3ShiamAZ[z0jyetbQwKrIclL9vJW]+fprnld4CZo(u"ࠫࠫ࠭೥")
			UH4B3Q1xWsphSXgz8R = GGvHJKP9LUxEk10Fw.findall(p72fnFtcPix5UKwr9YNzW(u"ࠬࠬࠨࡧ࡯ࡷࡁ࠳࠰࠿ࠪࠨࠪ೦"),ELbNB92cOh5dqtpVmi40kY)
			if UH4B3Q1xWsphSXgz8R: ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.replace(UH4B3Q1xWsphSXgz8R[hBvsQ7oCkKUdwjx58ml3EN(u"࠴႖")],kEhAHvti6Vnsfx(u"࠭ࡦ࡮ࡶࡀࡺࡹࡺࠧ೧"))
			else: ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+g4g6bfkPtVGU5lIM3(u"ࠧࡧ࡯ࡷࡁࡻࡺࡴࠨ೨")
			EER1WVLBPmTZd = ELbNB92cOh5dqtpVmi40kY.strip(E6MIKdpBomef(u"ࠨࠨࠪ೩"))
	lBkgOT3y9u4ehPR,x0NUTsohaGeH7c3ZqCQ1O9S,bXLBrdavhFoQzJIERM8,Znf0Q1cR9Y,g6Gyn7X8cbB1Ax3o = [],[],[],[],[]
	try: Ue61rJH2dAZ30qM5n = zCqhvsn4QIRHAV5GKpB[Cu1704YofAbr3QTm(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ೪")][E6MIKdpBomef(u"ࠪࡨࡦࡹࡨࡎࡣࡱ࡭࡫࡫ࡳࡵࡗࡵࡰࠬ೫")]
	except: pass
	try: B2FwNxsjTPVz37rk6nXJieLRbtEo = zCqhvsn4QIRHAV5GKpB[l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫ೬")][g4g6bfkPtVGU5lIM3(u"ࠬ࡮࡬ࡴࡏࡤࡲ࡮࡬ࡥࡴࡶࡘࡶࡱ࠭೭")]
	except: pass
	try: lBkgOT3y9u4ehPR = zCqhvsn4QIRHAV5GKpB[pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭೮")][hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࡧࡱࡵࡱࡦࡺࡳࠨ೯")]
	except: pass
	try: x0NUTsohaGeH7c3ZqCQ1O9S = zCqhvsn4QIRHAV5GKpB[dshJSmRqeiP9nap2(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨ೰")][g4g6bfkPtVGU5lIM3(u"ࠩࡤࡨࡦࡶࡴࡪࡸࡨࡊࡴࡸ࡭ࡢࡶࡶࠫೱ")]
	except: pass
	JlCAPMnXf7kveOb = lBkgOT3y9u4ehPR+x0NUTsohaGeH7c3ZqCQ1O9S
	for dict in JlCAPMnXf7kveOb:
		if sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪ࡭ࡹࡧࡧࠨೲ") in list(dict.keys()): dict[S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫ࡮ࡺࡡࡨࠩೳ")] = str(dict[hBvsQ7oCkKUdwjx58ml3EN(u"ࠬ࡯ࡴࡢࡩࠪ೴")])
		if wRxoKs10Syj7V4edYhtP(u"࠭ࡦࡱࡵࠪ೵") in list(dict.keys()): dict[G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠧࡧࡲࡶࠫ೶")] = str(dict[XzrqbGDIy54juixkMA(u"ࠨࡨࡳࡷࠬ೷")])
		if fprnld4CZo(u"ࠩࡰ࡭ࡲ࡫ࡔࡺࡲࡨࠫ೸") in list(dict.keys()): dict[lc0dpSmwoPDjLnk(u"ࠪࡸࡾࡶࡥࠨ೹")] = dict[LiRcTVUWuth70DmPy(u"ࠫࡲ࡯࡭ࡦࡖࡼࡴࡪ࠭೺")]
		if kEhAHvti6Vnsfx(u"ࠬࡧࡵࡥ࡫ࡲࡗࡦࡳࡰ࡭ࡧࡕࡥࡹ࡫ࠧ೻") in list(dict.keys()): dict[dshJSmRqeiP9nap2(u"࠭ࡡࡶࡦ࡬ࡳࡤࡹࡡ࡮ࡲ࡯ࡩࡤࡸࡡࡵࡧࠪ೼")] = str(dict[l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧࡢࡷࡧ࡭ࡴ࡙ࡡ࡮ࡲ࡯ࡩࡗࡧࡴࡦࠩ೽")])
		if sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨࡣࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡳࠨ೾") in list(dict.keys()): dict[bUdr5Hahw6sY8xJ(u"ࠩࡤࡹࡩ࡯࡯ࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ೿")] = str(dict[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪࡥࡺࡪࡩࡰࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠪഀ")])
		if G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࡼ࡯ࡤࡵࡪࠪഁ") in list(dict.keys()): dict[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠬࡹࡩࡻࡧࠪം")] = str(dict[g4g6bfkPtVGU5lIM3(u"࠭ࡷࡪࡦࡷ࡬ࠬഃ")])+kEhAHvti6Vnsfx(u"ࠧࡹࠩഄ")+str(dict[LiRcTVUWuth70DmPy(u"ࠨࡪࡨ࡭࡬࡮ࡴࠨഅ")])
		if xW2Arao7YVOemw(u"ࠩ࡬ࡲ࡮ࡺࡒࡢࡰࡪࡩࠬആ") in list(dict.keys()): dict[yA5z6LIXBlo41PRVMY87wOisFp(u"ࠪ࡭ࡳ࡯ࡴࠨഇ")] = dict[FnBiAjthS8MkXs67W(u"ࠫ࡮ࡴࡩࡵࡔࡤࡲ࡬࡫ࠧഈ")][l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬࡹࡴࡢࡴࡷࠫഉ")]+FvNyZqaLKw(u"࠭࠭ࠨഊ")+dict[wRxoKs10Syj7V4edYhtP(u"ࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪഋ")][hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨࡧࡱࡨࠬഌ")]
		if FvNyZqaLKw(u"ࠩ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪ࠭഍") in list(dict.keys()): dict[bUdr5Hahw6sY8xJ(u"ࠪ࡭ࡳࡪࡥࡹࠩഎ")] = dict[FvNyZqaLKw(u"ࠫ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥࠨഏ")][UTelCo0ihE1d5R(u"ࠬࡹࡴࡢࡴࡷࠫഐ")]+iUeoLOsbHqP(u"࠭࠭ࠨ഑")+dict[XzrqbGDIy54juixkMA(u"ࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫഒ")][G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠨࡧࡱࡨࠬഓ")]
		if bUdr5Hahw6sY8xJ(u"ࠩࡤࡺࡪࡸࡡࡨࡧࡅ࡭ࡹࡸࡡࡵࡧࠪഔ") in list(dict.keys()): dict[oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫക")] = dict[lc0dpSmwoPDjLnk(u"ࠫࡦࡼࡥࡳࡣࡪࡩࡇ࡯ࡴࡳࡣࡷࡩࠬഖ")]
		if p72fnFtcPix5UKwr9YNzW(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ഗ") in list(dict.keys()) and int(dict[pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧഘ")])>wRxoKs10Syj7V4edYhtP(u"࠶࠷࠱࠳࠴࠵࠷࠸࠹႗"): del dict[oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨങ")]
		if UTelCo0ihE1d5R(u"ࠨࡵ࡬࡫ࡳࡧࡴࡶࡴࡨࡇ࡮ࡶࡨࡦࡴࠪച") in list(dict.keys()):
			BSJu8jhc7VW5lTF3aGMPKH4kn = dict[zqdvcbP5L8BHh(u"ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡈ࡯ࡰࡩࡧࡵࠫഛ")].split(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠪࠪࠬജ"))
			for BrVNsC72UYWES4A in BSJu8jhc7VW5lTF3aGMPKH4kn:
				key,hieW1zRUG5w9AykJjv0X = BrVNsC72UYWES4A.split(lc0dpSmwoPDjLnk(u"ࠫࡂ࠭ഝ"),dshJSmRqeiP9nap2(u"࠷႘"))
				dict[key] = GhPlajzTxY8(hieW1zRUG5w9AykJjv0X)
		if iRoLg2m47tnDATBHGCSPNyx(u"ࠬࡻࡲ࡭ࠩഞ") in list(dict.keys()): dict[lc0dpSmwoPDjLnk(u"࠭ࡵࡳ࡮ࠪട")] = GhPlajzTxY8(dict[iUeoLOsbHqP(u"ࠧࡶࡴ࡯ࠫഠ")])
		bXLBrdavhFoQzJIERM8.append(dict)
	yHOpAGJ0UvkX5umZrg = G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠨࠩഡ")
	if bUdr5Hahw6sY8xJ(u"ࠩࡶࡴࡂࡹࡩࡨࠩഢ") in JWPYA5r2liu0zQTHwhXfDay4:
		I45ZKcaj0VRX6 = GGvHJKP9LUxEk10Fw.findall(Cu1704YofAbr3QTm(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠲ࡷ࠴ࡶ࡬ࡢࡻࡨࡶ࠴ࡢࡷࠫࡁ࠲ࡴࡱࡧࡹࡦࡴࡢ࡭ࡦࡹ࠮ࡷࡨ࡯ࡷࡪࡺ࠯ࡦࡰࡢ࠲࠳࠵ࡢࡢࡵࡨ࠲࡯ࡹࠩࠣࠩണ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if I45ZKcaj0VRX6:
			I45ZKcaj0VRX6 = oSVpce1UQYrDqhuM6PT[FnBiAjthS8MkXs67W(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬത")][YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠰႙")]+I45ZKcaj0VRX6[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠰႙")]
			WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,iUeoLOsbHqP(u"ࠬࡍࡅࡕࠩഥ"),I45ZKcaj0VRX6,zqdvcbP5L8BHh(u"࠭ࠧദ"),yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧࠨധ"),iUeoLOsbHqP(u"ࠨࠩന"),FvNyZqaLKw(u"ࠩࠪഩ"),LiRcTVUWuth70DmPy(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠳ࡰࡧࠫപ"))
			yHOpAGJ0UvkX5umZrg = WbTGMHnDysdYZ2lFA.content
			import youtube_signature.cipher as ZZFJnODzGk2aPuhTpjvf,youtube_signature.json_script_engine as wR6VqfurZt94JiH1D
			BSJu8jhc7VW5lTF3aGMPKH4kn = BMGgLnAhipbz1a.BSJu8jhc7VW5lTF3aGMPKH4kn.Cipher()
			BSJu8jhc7VW5lTF3aGMPKH4kn._object_cache = {}
			gBoeRrayT1XDCwqFWsJ7GV6H = BSJu8jhc7VW5lTF3aGMPKH4kn._load_javascript(yHOpAGJ0UvkX5umZrg)
			ZuORtgroDyTp0Bnal7AJjKX = JKw5OWktPZB(bUdr5Hahw6sY8xJ(u"ࠫࡸࡺࡲࠨഫ"),str(gBoeRrayT1XDCwqFWsJ7GV6H))
			PPlb0sBYeUQ = BMGgLnAhipbz1a.DKtuzJBws65xopkHfhN.JsonScriptEngine(ZuORtgroDyTp0Bnal7AJjKX)
	for dict in bXLBrdavhFoQzJIERM8:
		url = dict[FnBiAjthS8MkXs67W(u"ࠬࡻࡲ࡭ࠩബ")]
		if YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦ࠿ࠪഭ") in url or url.count(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࡴ࡫ࡪࡁࠬമ"))>hBvsQ7oCkKUdwjx58ml3EN(u"࠲ႚ"):
			Znf0Q1cR9Y.append(dict)
		elif yHOpAGJ0UvkX5umZrg and E6MIKdpBomef(u"ࠨࡵࠪയ") in list(dict.keys()) and p72fnFtcPix5UKwr9YNzW(u"ࠩࡶࡴࠬര") in list(dict.keys()):
			h9J1D7cV5CuWeO = PPlb0sBYeUQ.execute(dict[hBvsQ7oCkKUdwjx58ml3EN(u"ࠪࡷࠬറ")])
			if h9J1D7cV5CuWeO!=dict[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠫࡸ࠭ല")]:
				dict[G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠬࡻࡲ࡭ࠩള")] = url+E6MIKdpBomef(u"࠭ࠦࠨഴ")+dict[wRxoKs10Syj7V4edYhtP(u"ࠧࡴࡲࠪവ")]+XzrqbGDIy54juixkMA(u"ࠨ࠿ࠪശ")+h9J1D7cV5CuWeO
				Znf0Q1cR9Y.append(dict)
	for dict in Znf0Q1cR9Y:
		eBjoKP40GyrEFp,ggpi84Cyzw2T,h2MKtWOV4noje0acSIvHTEDw,kMZsFyP9qdmj5KXlJLA8xNeCg3f,rx70vawoNtqERBAY3Pp,ttTAbmlyKH9Se = LiRcTVUWuth70DmPy(u"ࠩࡸࡲࡰࡴ࡯ࡸࡰࠪഷ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࡹࡳࡱ࡮ࡰࡹࡱࠫസ"),iRoLg2m47tnDATBHGCSPNyx(u"ࠫࡺࡴ࡫࡯ࡱࡺࡲࠬഹ"),yA5z6LIXBlo41PRVMY87wOisFp(u"࡛ࠬ࡮࡬ࡰࡲࡻࡳ࠭ഺ"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"഻࠭ࠧ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠧ࠱഼ࠩ")
		try:
			Id7JYAqzRWK9OsxLw = dict[UTelCo0ihE1d5R(u"ࠨࡶࡼࡴࡪ࠭ഽ")]
			Id7JYAqzRWK9OsxLw = Id7JYAqzRWK9OsxLw.replace(kEhAHvti6Vnsfx(u"ࠩ࠮ࠫാ"),SO94xq1RAkMm2uF(u"ࠪࠫി"))
			items = GGvHJKP9LUxEk10Fw.findall(iRoLg2m47tnDATBHGCSPNyx(u"ࠫ࠭࠴ࠪࡀࠫ࠲ࠬ࠳࠰࠿ࠪ࠽࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ീ"),Id7JYAqzRWK9OsxLw,GGvHJKP9LUxEk10Fw.DOTALL)
			kMZsFyP9qdmj5KXlJLA8xNeCg3f,eBjoKP40GyrEFp,rx70vawoNtqERBAY3Pp = items[hBvsQ7oCkKUdwjx58ml3EN(u"࠲ႛ")]
			CqlXv86ApbIWxLjPkFTKJ = rx70vawoNtqERBAY3Pp.split(SO94xq1RAkMm2uF(u"ࠬ࠲ࠧു"))
			ggpi84Cyzw2T = fprnld4CZo(u"࠭ࠧൂ")
			for BrVNsC72UYWES4A in CqlXv86ApbIWxLjPkFTKJ: ggpi84Cyzw2T += BrVNsC72UYWES4A.split(FnBiAjthS8MkXs67W(u"ࠧ࠯ࠩൃ"))[oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠳ႜ")]+sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨ࠮ࠪൄ")
			ggpi84Cyzw2T = ggpi84Cyzw2T.strip(FvNyZqaLKw(u"ࠩ࠯ࠫ൅"))
			if pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫെ") in list(dict.keys()): ttTAbmlyKH9Se = str(float(dict[wRxoKs10Syj7V4edYhtP(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬേ")]*xW2Arao7YVOemw(u"࠵࠵ႝ"))//QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠶࠶࠲࠵႞")/xW2Arao7YVOemw(u"࠵࠵ႝ"))+Me28A1sBLNIgUp5YCDyvT(u"ࠬࡱࡢࡱࡵࠣࠤࠬൈ")
			else: ttTAbmlyKH9Se = bUdr5Hahw6sY8xJ(u"࠭ࠧ൉")
			if kMZsFyP9qdmj5KXlJLA8xNeCg3f==FvNyZqaLKw(u"ࠧࡵࡧࡻࡸࡹ࠭ൊ"): continue
			elif Me28A1sBLNIgUp5YCDyvT(u"ࠨ࠮ࠪോ") in Id7JYAqzRWK9OsxLw:
				kMZsFyP9qdmj5KXlJLA8xNeCg3f = kEhAHvti6Vnsfx(u"ࠩࡄ࠯࡛࠭ൌ")
				h2MKtWOV4noje0acSIvHTEDw = eBjoKP40GyrEFp+xW2Arao7YVOemw(u"ࠪࠤ്ࠥ࠭")+ttTAbmlyKH9Se+dict[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠫࡸ࡯ࡺࡦࠩൎ")].split(Me28A1sBLNIgUp5YCDyvT(u"ࠬࡾࠧ൏"))[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠷႟")]
			elif kMZsFyP9qdmj5KXlJLA8xNeCg3f==Cu1704YofAbr3QTm(u"࠭ࡶࡪࡦࡨࡳࠬ൐"):
				kMZsFyP9qdmj5KXlJLA8xNeCg3f = SO94xq1RAkMm2uF(u"ࠧࡗ࡫ࡧࡩࡴ࠭൑")
				h2MKtWOV4noje0acSIvHTEDw = ttTAbmlyKH9Se+dict[FvNyZqaLKw(u"ࠨࡵ࡬ࡾࡪ࠭൒")].split(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩࡻࠫ൓"))[xW2Arao7YVOemw(u"࠱Ⴀ")]+sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࠤࠥ࠭ൔ")+dict[xW2Arao7YVOemw(u"ࠫ࡫ࡶࡳࠨൕ")]+S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠬ࡬ࡰࡴࠩൖ")+wRxoKs10Syj7V4edYhtP(u"࠭ࠠࠡࠩൗ")+eBjoKP40GyrEFp
			elif kMZsFyP9qdmj5KXlJLA8xNeCg3f==iRoLg2m47tnDATBHGCSPNyx(u"ࠧࡢࡷࡧ࡭ࡴ࠭൘"):
				kMZsFyP9qdmj5KXlJLA8xNeCg3f = E6MIKdpBomef(u"ࠨࡃࡸࡨ࡮ࡵࠧ൙")
				h2MKtWOV4noje0acSIvHTEDw = ttTAbmlyKH9Se+str(int(dict[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩࡤࡹࡩ࡯࡯ࡠࡵࡤࡱࡵࡲࡥࡠࡴࡤࡸࡪ࠭൚")])/YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠲࠲࠳࠴Ⴁ"))+g4g6bfkPtVGU5lIM3(u"ࠪ࡯࡭ࢀࠠࠡࠩ൛")+dict[FnBiAjthS8MkXs67W(u"ࠫࡦࡻࡤࡪࡱࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ൜")]+g4g6bfkPtVGU5lIM3(u"ࠬࡩࡨࠨ൝")+sTcr7iDp5eFt4RoLMhuwq1A(u"࠭ࠠࠡࠩ൞")+eBjoKP40GyrEFp
		except:
			CCeZSJvsigLcq = FTYWns4Q7dSEXmBOAGlJ.format_exc()
			if CCeZSJvsigLcq!=iRoLg2m47tnDATBHGCSPNyx(u"ࠧࡏࡱࡱࡩ࡙ࡿࡰࡦ࠼ࠣࡒࡴࡴࡥ࡝ࡰࠪൟ"): GGtWyVoJReUuEBCdAagiL1YXO8.stderr.write(CCeZSJvsigLcq)
		if S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠨࡦࡸࡶࡂ࠭ൠ") in dict[g4g6bfkPtVGU5lIM3(u"ࠩࡸࡶࡱ࠭ൡ")]: EDL3rwcivsR9W0pdTfygmOYUoVSb = round(XzrqbGDIy54juixkMA(u"࠴࠳࠻Ⴄ")+float(dict[oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠪࡹࡷࡲࠧൢ")].split(dshJSmRqeiP9nap2(u"ࠫࡩࡻࡲ࠾ࠩൣ"),g4g6bfkPtVGU5lIM3(u"࠳Ⴂ"))[g4g6bfkPtVGU5lIM3(u"࠳Ⴂ")].split(Me28A1sBLNIgUp5YCDyvT(u"ࠬࠬࠧ൤"),g4g6bfkPtVGU5lIM3(u"࠳Ⴂ"))[hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠳Ⴃ")]))
		elif iUeoLOsbHqP(u"࠭ࡡࡱࡲࡵࡳࡽࡊࡵࡳࡣࡷ࡭ࡴࡴࡍࡴࠩ൥") in list(dict.keys()): EDL3rwcivsR9W0pdTfygmOYUoVSb = round(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠵࠴࠵Ⴅ")+float(dict[fprnld4CZo(u"ࠧࡢࡲࡳࡶࡴࡾࡄࡶࡴࡤࡸ࡮ࡵ࡮ࡎࡵࠪ൦")])/FvNyZqaLKw(u"࠷࠰࠱࠲Ⴆ"))
		else: EDL3rwcivsR9W0pdTfygmOYUoVSb = zqdvcbP5L8BHh(u"ࠨ࠲ࠪ൧")
		if hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ൨") not in list(dict.keys()): ttTAbmlyKH9Se = dict[hBvsQ7oCkKUdwjx58ml3EN(u"ࠪࡷ࡮ࢀࡥࠨ൩")].split(UTelCo0ihE1d5R(u"ࠫࡽ࠭൪"))[pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠱Ⴇ")]
		else: ttTAbmlyKH9Se = dict[FnBiAjthS8MkXs67W(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭൫")]
		if QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭ࡩ࡯࡫ࡷࠫ൬") not in list(dict.keys()): dict[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࡪࡰ࡬ࡸࠬ൭")] = UTelCo0ihE1d5R(u"ࠨ࠲࠰࠴ࠬ൮")
		dict[hBvsQ7oCkKUdwjx58ml3EN(u"ࠩࡷ࡭ࡹࡲࡥࠨ൯")] = kMZsFyP9qdmj5KXlJLA8xNeCg3f+iUeoLOsbHqP(u"ࠪ࠾ࠥࠦࠧ൰")+h2MKtWOV4noje0acSIvHTEDw+iUeoLOsbHqP(u"ࠫࠥࠦࠨࠨ൱")+ggpi84Cyzw2T+yA5z6LIXBlo41PRVMY87wOisFp(u"ࠬ࠲ࠧ൲")+dict[hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࡩࡵࡣࡪࠫ൳")]+kEhAHvti6Vnsfx(u"ࠧࠪࠩ൴")
		dict[p72fnFtcPix5UKwr9YNzW(u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ൵")] = h2MKtWOV4noje0acSIvHTEDw.split(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩࠣࠤࠬ൶"))[QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠱Ⴈ")].split(fprnld4CZo(u"ࠪ࡯ࡧࡶࡳࠨ൷"))[QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠱Ⴈ")]
		dict[Me28A1sBLNIgUp5YCDyvT(u"ࠫࡹࡿࡰࡦ࠴ࠪ൸")] = kMZsFyP9qdmj5KXlJLA8xNeCg3f
		dict[p72fnFtcPix5UKwr9YNzW(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ൹")] = eBjoKP40GyrEFp
		dict[QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭ࡣࡰࡦࡨࡧࡸ࠭ൺ")] = rx70vawoNtqERBAY3Pp
		dict[dshJSmRqeiP9nap2(u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩൻ")] = EDL3rwcivsR9W0pdTfygmOYUoVSb
		dict[E6MIKdpBomef(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩർ")] = ttTAbmlyKH9Se
		g6Gyn7X8cbB1Ax3o.append(dict)
	b0bZiIYEHT8vUORAczGlaLNujg,tQqVsjXK9OrpBUWknl,rXj23qLvaGnH0czfQODokPbJ,mmxsMLbW3u9ZV,jBn92t1CPZAgWdIxG = [],[],[],[],[]
	nmXjIrZcHTdh9uQLlVxJe7b1zs,KKeIYzMOBCStTZQLuq0U68Nlry4F,pGwmaVAQ1fto98FzZ,pvSLGkxJXt1jRYUzl5sN7,qsfPLhmUYSa = [],[],[],[],[]
	if Ue61rJH2dAZ30qM5n:
		dict = {}
		dict[S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠩࡷࡽࡵ࡫࠲ࠨൽ")] = S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠪࡅ࠰࡜ࠧൾ")
		dict[FnBiAjthS8MkXs67W(u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭ൿ")] = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬࡳࡰࡥࠩ඀")
		dict[E6MIKdpBomef(u"࠭ࡴࡪࡶ࡯ࡩࠬඁ")] = dict[xW2Arao7YVOemw(u"ࠧࡵࡻࡳࡩ࠷࠭ං")]+SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨ࠼ࠣࠤࠬඃ")+dict[dshJSmRqeiP9nap2(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ඄")]+bUdr5Hahw6sY8xJ(u"ࠪࠤࠥ࠭අ")+YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠫั๎ฯสࠢำ็๏ฯࠧආ")
		dict[FvNyZqaLKw(u"ࠬࡻࡲ࡭ࠩඇ")] = Ue61rJH2dAZ30qM5n
		dict[SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧඈ")] = lc0dpSmwoPDjLnk(u"ࠧ࠱ࠩඉ")
		dict[iRoLg2m47tnDATBHGCSPNyx(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩඊ")] = LiRcTVUWuth70DmPy(u"ࠩ࠼࠼࠼࠼࠵࠵࠵࠵࠵࠵࠭උ")
		g6Gyn7X8cbB1Ax3o.append(dict)
	if B2FwNxsjTPVz37rk6nXJieLRbtEo:
		pnOTgyAIevsrkqVch,BBvfW05P4wUs9Nlkjqyd6gnaAC = BXEJoygQHA8RZ(B2FwNxsjTPVz37rk6nXJieLRbtEo)
		OpLPyGjKYvea = list(zip(pnOTgyAIevsrkqVch,BBvfW05P4wUs9Nlkjqyd6gnaAC))
		for title,ELbNB92cOh5dqtpVmi40kY in OpLPyGjKYvea:
			dict = {}
			dict[kEhAHvti6Vnsfx(u"ࠪࡸࡾࡶࡥ࠳ࠩඌ")] = Cu1704YofAbr3QTm(u"ࠫࡆ࠱ࡖࠨඍ")
			dict[p72fnFtcPix5UKwr9YNzW(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧඎ")] = yA5z6LIXBlo41PRVMY87wOisFp(u"࠭࡭࠴ࡷ࠻ࠫඏ")
			dict[fprnld4CZo(u"ࠧࡶࡴ࡯ࠫඐ")] = ELbNB92cOh5dqtpVmi40kY
			if XzrqbGDIy54juixkMA(u"ࠨ࡭ࡥࡴࡸ࠭එ") in title: dict[hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪඒ")] = title.split(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠪ࡯ࡧࡶࡳࠨඓ"))[wRxoKs10Syj7V4edYhtP(u"࠳Ⴊ")].rsplit(LiRcTVUWuth70DmPy(u"ࠫࠥࠦࠧඔ"))[-kEhAHvti6Vnsfx(u"࠳Ⴉ")]
			else: dict[xW2Arao7YVOemw(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ඕ")] = fprnld4CZo(u"࠭࠱࠱ࠩඖ")
			if title.count(g4g6bfkPtVGU5lIM3(u"ࠧࠡࠢࠪ඗"))>LiRcTVUWuth70DmPy(u"࠵Ⴋ"):
				dDZQSEGRTo9g85x1C = title.rsplit(bUdr5Hahw6sY8xJ(u"ࠨࠢࠣࠫ඘"))[-dshJSmRqeiP9nap2(u"࠸Ⴌ")]
				if dDZQSEGRTo9g85x1C.isdigit(): dict[g4g6bfkPtVGU5lIM3(u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ඙")] = dDZQSEGRTo9g85x1C
				else: dict[kEhAHvti6Vnsfx(u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫක")] = yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫ࠵࠶࠰࠱ࠩඛ")
			if title==p72fnFtcPix5UKwr9YNzW(u"ࠬ࠳࠱ࠨග"): dict[p72fnFtcPix5UKwr9YNzW(u"࠭ࡴࡪࡶ࡯ࡩࠬඝ")] = dict[iRoLg2m47tnDATBHGCSPNyx(u"ࠧࡵࡻࡳࡩ࠷࠭ඞ")]+E6MIKdpBomef(u"ࠨ࠼ࠣࠤࠬඟ")+dict[kEhAHvti6Vnsfx(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫච")]+sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࠤࠥ࠭ඡ")+XzrqbGDIy54juixkMA(u"ࠫั๎ฯสࠢำ็๏ฯࠧජ")
			else: dict[XzrqbGDIy54juixkMA(u"ࠬࡺࡩࡵ࡮ࡨࠫඣ")] = dict[xW2Arao7YVOemw(u"࠭ࡴࡺࡲࡨ࠶ࠬඤ")]+Me28A1sBLNIgUp5YCDyvT(u"ࠧ࠻ࠢࠣࠫඥ")+dict[xW2Arao7YVOemw(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪඦ")]+LiRcTVUWuth70DmPy(u"ࠩࠣࠤࠬට")+dict[iRoLg2m47tnDATBHGCSPNyx(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫඨ")]+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫࡰࡨࡰࡴࠢࠣࠫඩ")+dict[FvNyZqaLKw(u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭ඪ")]
			g6Gyn7X8cbB1Ax3o.append(dict)
	g6Gyn7X8cbB1Ax3o = sorted(g6Gyn7X8cbB1Ax3o,reverse=FvNyZqaLKw(u"࡙ࡸࡵࡦᅢ"),key=lambda key: float(key[iRoLg2m47tnDATBHGCSPNyx(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧණ")]))
	if not g6Gyn7X8cbB1Ax3o:
		Wu6THcbvsRZdXSz4nwlCVy = GGvHJKP9LUxEk10Fw.findall(FvNyZqaLKw(u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡧࡶࡷࡦ࡭ࡥࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪඬ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		bdzvPE1KBTfkMj04QAG5hY7ouqZD = GGvHJKP9LUxEk10Fw.findall(g4g6bfkPtVGU5lIM3(u"ࠨࠤࡳࡰࡦࡿࡥࡳࡇࡵࡶࡴࡸࡍࡦࡵࡶࡥ࡬࡫ࡒࡦࡰࡧࡩࡷ࡫ࡲࠣ࠼࡟ࡿࠧࡹࡵࡣࡴࡨࡥࡸࡵ࡮ࠣ࠼࡟ࡿࠧࡸࡵ࡯ࡵࠥ࠾ࡡࡡ࡜ࡼࠤࡷࡩࡽࡺࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪත"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		eFQXmOopl5Gfd = GGvHJKP9LUxEk10Fw.findall(E6MIKdpBomef(u"ࠩࠥࡴࡱࡧࡹࡦࡴࡈࡶࡷࡵࡲࡎࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡲࡦࡣࡶࡳࡳࠨ࠺ࡼࠤࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨථ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		ZIGlKA0aOBfFuonWj = GGvHJKP9LUxEk10Fw.findall(iUeoLOsbHqP(u"ࠪࠦࡵࡲࡡࡺࡧࡵࡉࡷࡸ࡯ࡳࡏࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠥ࠾ࡡࢁࠢࡴࡷࡥࡶࡪࡧࡳࡰࡰࠥ࠾ࢀࠨࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬද"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		try: FCkpbo9fVRaiHum3U = zCqhvsn4QIRHAV5GKpB[Cu1704YofAbr3QTm(u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨධ")][hBvsQ7oCkKUdwjx58ml3EN(u"ࠬ࡫ࡲࡳࡱࡵࡗࡨࡸࡥࡦࡰࠪන")][QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳࡄࡪࡣ࡯ࡳ࡬ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ඲")][E6MIKdpBomef(u"ࠧࡵ࡫ࡷࡰࡪ࠭ඳ")][zqdvcbP5L8BHh(u"ࠨࡴࡸࡲࡸ࠭ප")][SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠶Ⴍ")][oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠩࡷࡩࡽࡺࡴࠨඵ")]
		except: FCkpbo9fVRaiHum3U = S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠪࠫබ")
		try: GMhYVPfz79To = zCqhvsn4QIRHAV5GKpB[UTelCo0ihE1d5R(u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨභ")][xW2Arao7YVOemw(u"ࠬ࡫ࡲࡳࡱࡵࡗࡨࡸࡥࡦࡰࠪම")][YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳࡄࡪࡣ࡯ࡳ࡬ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧඹ")][fprnld4CZo(u"ࠧࡥ࡫ࡤࡰࡴ࡭ࡍࡦࡵࡶࡥ࡬࡫ࡳࠨය")][iUeoLOsbHqP(u"࠰Ⴎ")][iUeoLOsbHqP(u"ࠨࡴࡸࡲࡸ࠭ර")][iUeoLOsbHqP(u"࠰Ⴎ")][E6MIKdpBomef(u"ࠩࡷࡩࡽࡺࡴࠨ඼")]
		except: GMhYVPfz79To = wRxoKs10Syj7V4edYhtP(u"ࠪࠫල")
		try: aapKI0sNr8vOLRnhoiYjczElqXe6w = zCqhvsn4QIRHAV5GKpB[oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨ඾")][hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬࡸࡥࡢࡵࡲࡲࠬ඿")]
		except: aapKI0sNr8vOLRnhoiYjczElqXe6w = LiRcTVUWuth70DmPy(u"࠭ࠧව")
		if Wu6THcbvsRZdXSz4nwlCVy or bdzvPE1KBTfkMj04QAG5hY7ouqZD or eFQXmOopl5Gfd or ZIGlKA0aOBfFuonWj or FCkpbo9fVRaiHum3U or GMhYVPfz79To or aapKI0sNr8vOLRnhoiYjczElqXe6w:
			if   Wu6THcbvsRZdXSz4nwlCVy: LpdKxnIsY3Sy6qP = Wu6THcbvsRZdXSz4nwlCVy[G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠱Ⴏ")]
			elif bdzvPE1KBTfkMj04QAG5hY7ouqZD: LpdKxnIsY3Sy6qP = bdzvPE1KBTfkMj04QAG5hY7ouqZD[hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠲Ⴐ")]
			elif eFQXmOopl5Gfd: LpdKxnIsY3Sy6qP = eFQXmOopl5Gfd[lc0dpSmwoPDjLnk(u"࠳Ⴑ")]
			elif ZIGlKA0aOBfFuonWj: LpdKxnIsY3Sy6qP = ZIGlKA0aOBfFuonWj[wRxoKs10Syj7V4edYhtP(u"࠴Ⴒ")]
			elif FCkpbo9fVRaiHum3U: LpdKxnIsY3Sy6qP = FCkpbo9fVRaiHum3U
			elif GMhYVPfz79To: LpdKxnIsY3Sy6qP = GMhYVPfz79To
			elif aapKI0sNr8vOLRnhoiYjczElqXe6w: LpdKxnIsY3Sy6qP = aapKI0sNr8vOLRnhoiYjczElqXe6w
			Ol9gIrXjoHqmC2ESZ7 = LpdKxnIsY3Sy6qP.replace(xW2Arao7YVOemw(u"ࠧ࡝ࡰࠪශ"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠨࠩෂ")).strip(g4g6bfkPtVGU5lIM3(u"ࠩࠣࠫස"))
			UfCG41Ix36q2TktAreN70v9 = XzrqbGDIy54juixkMA(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํะศࠢส่ๆ๐ฯ๋๊ࠣๅ๏ํࠠๆึๆ่ฮ่ࠦใัࠣ๎่๎ๆࠡ฼ํี๋ࠥไศศ่ࠤ้ฮูืࠢสู่๊สฯั่๎๋ࠦร้ࠢ฽๎ึࠦๅห๊ไีࠥอไร่࡞࠳ࡈࡕࡌࡐࡔࡠࠫහ")
			aHKzv76JCVnprbY8w(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫࠬළ"),LiRcTVUWuth70DmPy(u"ࠬ࠭ෆ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭ัิษ็อ๋ࠥๆࠡษ็้ํู่๊ࠡส่๊ฮัๆฮࠪ෇"),UfCG41Ix36q2TktAreN70v9+dshJSmRqeiP9nap2(u"ࠧ࡝ࡰ࡟ࡲࠬ෈")+Ol9gIrXjoHqmC2ESZ7)
			return pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࡇࡵࡶࡴࡸࠠࠡࠢࠣ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸ࡚ࠠࡑࡘࡘ࡚ࡈࡅࠡࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠪ෉")+Ol9gIrXjoHqmC2ESZ7,[],[]
		else: return bUdr5Hahw6sY8xJ(u"ࠩࡈࡶࡷࡵࡲࠡࠢࠣࠤ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲ࡛ࠡࡒ࡙࡙࡛ࡂࡆࠢࡉࡥ࡮ࡲࡥࡥ්ࠩ"),[],[]
	zzMgTAkuSDn83Ya10Im64heNjXsro,OQkb6CwGtxnU,DjFtN40oUmKhEObZn = [],[],[]
	for dict in g6Gyn7X8cbB1Ax3o:
		if dict[fprnld4CZo(u"ࠪࡸࡾࡶࡥ࠳ࠩ෋")]==xW2Arao7YVOemw(u"࡛ࠫ࡯ࡤࡦࡱࠪ෌"):
			b0bZiIYEHT8vUORAczGlaLNujg.append(dict[l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬࡺࡩࡵ࡮ࡨࠫ෍")])
			nmXjIrZcHTdh9uQLlVxJe7b1zs.append(dict)
		elif dict[G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠭ࡴࡺࡲࡨ࠶ࠬ෎")]==Cu1704YofAbr3QTm(u"ࠧࡂࡷࡧ࡭ࡴ࠭ා"):
			tQqVsjXK9OrpBUWknl.append(dict[SO94xq1RAkMm2uF(u"ࠨࡶ࡬ࡸࡱ࡫ࠧැ")])
			KKeIYzMOBCStTZQLuq0U68Nlry4F.append(dict)
		elif dict[sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫෑ")]==LiRcTVUWuth70DmPy(u"ࠪࡱࡵࡪࠧි"):
			title = dict[dshJSmRqeiP9nap2(u"ࠫࡹ࡯ࡴ࡭ࡧࠪී")].replace(bUdr5Hahw6sY8xJ(u"ࠬࡇࠫࡗ࠼ࠣࠤࠬු"),bUdr5Hahw6sY8xJ(u"࠭ࠧ෕"))
			if sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨූ") not in list(dict.keys()): ttTAbmlyKH9Se = SO94xq1RAkMm2uF(u"ࠨ࠲ࠪ෗")
			else: ttTAbmlyKH9Se = dict[zqdvcbP5L8BHh(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪෘ")]
			zzMgTAkuSDn83Ya10Im64heNjXsro.append([dict,{},title,ttTAbmlyKH9Se])
		else:
			title = dict[QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠪࡸ࡮ࡺ࡬ࡦࠩෙ")].replace(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࡆ࠱ࡖ࠻ࠢࠣࠫේ"),zqdvcbP5L8BHh(u"ࠬ࠭ෛ"))
			if hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧො") not in list(dict.keys()): ttTAbmlyKH9Se = SO94xq1RAkMm2uF(u"ࠧ࠱ࠩෝ")
			else: ttTAbmlyKH9Se = dict[g4g6bfkPtVGU5lIM3(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩෞ")]
			zzMgTAkuSDn83Ya10Im64heNjXsro.append([dict,{},title,ttTAbmlyKH9Se])
			rXj23qLvaGnH0czfQODokPbJ.append(title)
			pGwmaVAQ1fto98FzZ.append(dict)
		psZJ4QH5hfM71tm6r0K = bUdr5Hahw6sY8xJ(u"࡚ࡲࡶࡧᅣ")
		if fprnld4CZo(u"ࠩࡦࡳࡩ࡫ࡣࡴࠩෟ") in list(dict.keys()):
			if dshJSmRqeiP9nap2(u"ࠪࡥࡻ࠶ࠧ෠") in dict[LiRcTVUWuth70DmPy(u"ࠫࡨࡵࡤࡦࡥࡶࠫ෡")]: psZJ4QH5hfM71tm6r0K = UTelCo0ihE1d5R(u"ࡆࡢ࡮ࡶࡩᅤ")
			elif yMvF9GoTjhU5biA<G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠶࠾Ⴓ"):
				if SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠬࡧࡶࡤࠩ෢") not in dict[zqdvcbP5L8BHh(u"࠭ࡣࡰࡦࡨࡧࡸ࠭෣")] and yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧ࡮ࡲ࠷ࡥࠬ෤") not in dict[SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࡥࡲࡨࡪࡩࡳࠨ෥")]: psZJ4QH5hfM71tm6r0K = E6MIKdpBomef(u"ࡇࡣ࡯ࡷࡪᅥ")
		if dict[QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࡷࡽࡵ࡫࠲ࠨ෦")]==FnBiAjthS8MkXs67W(u"࡚ࠪ࡮ࡪࡥࡰࠩ෧") and dict[FnBiAjthS8MkXs67W(u"ࠫ࡮ࡴࡩࡵࠩ෨")]!=FvNyZqaLKw(u"ࠬ࠶࠭࠱ࠩ෩") and psZJ4QH5hfM71tm6r0K==g4g6bfkPtVGU5lIM3(u"ࡖࡵࡹࡪᅦ"):
			jBn92t1CPZAgWdIxG.append(dict[XzrqbGDIy54juixkMA(u"࠭ࡴࡪࡶ࡯ࡩࠬ෪")])
			qsfPLhmUYSa.append(dict)
		elif dict[lc0dpSmwoPDjLnk(u"ࠧࡵࡻࡳࡩ࠷࠭෫")]==hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨࡃࡸࡨ࡮ࡵࠧ෬") and dict[FvNyZqaLKw(u"ࠩ࡬ࡲ࡮ࡺࠧ෭")]!=iUeoLOsbHqP(u"ࠪ࠴࠲࠶ࠧ෮") and psZJ4QH5hfM71tm6r0K==p72fnFtcPix5UKwr9YNzW(u"ࡗࡶࡺ࡫ᅧ"):
			mmxsMLbW3u9ZV.append(dict[SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࡹ࡯ࡴ࡭ࡧࠪ෯")])
			pvSLGkxJXt1jRYUzl5sN7.append(dict)
	for JLsVoGUKx6QArEXaN2edZmf in pvSLGkxJXt1jRYUzl5sN7:
		yMjwieUTpmDEbQk = JLsVoGUKx6QArEXaN2edZmf[hBvsQ7oCkKUdwjx58ml3EN(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭෰")]
		for vM9mcaHtCGqiro64 in qsfPLhmUYSa:
			EMVQNZq6ASWdvgGBrXhmbHCw7kp5 = vM9mcaHtCGqiro64[SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ෱")]
			ttTAbmlyKH9Se = EMVQNZq6ASWdvgGBrXhmbHCw7kp5+yMjwieUTpmDEbQk
			title = vM9mcaHtCGqiro64[SO94xq1RAkMm2uF(u"ࠧࡵ࡫ࡷࡰࡪ࠭ෲ")].replace(fprnld4CZo(u"ࠨࡘ࡬ࡨࡪࡵ࠺ࠡࠢࠪෳ"),hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩࡰࡴࡩࠦࠠࠨ෴"))
			title = title.replace(vM9mcaHtCGqiro64[p72fnFtcPix5UKwr9YNzW(u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ෵")]+FvNyZqaLKw(u"ࠫࠥࠦࠧ෶"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬ࠭෷"))
			title = title.replace(str((float(EMVQNZq6ASWdvgGBrXhmbHCw7kp5*YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠷࠰Ⴔ"))//hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠱࠱࠴࠷Ⴕ")/YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠷࠰Ⴔ")))+p72fnFtcPix5UKwr9YNzW(u"࠭࡫ࡣࡲࡶࠫ෸"),str((float(ttTAbmlyKH9Se*YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠷࠰Ⴔ"))//hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠱࠱࠴࠷Ⴕ")/YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠷࠰Ⴔ")))+kEhAHvti6Vnsfx(u"ࠧ࡬ࡤࡳࡷࠬ෹"))
			title = title+XzrqbGDIy54juixkMA(u"ࠨࠪࠪ෺")+JLsVoGUKx6QArEXaN2edZmf[E6MIKdpBomef(u"ࠩࡷ࡭ࡹࡲࡥࠨ෻")].split(UTelCo0ihE1d5R(u"ࠪࠬࠬ෼"),xW2Arao7YVOemw(u"࠲Ⴖ"))[xW2Arao7YVOemw(u"࠲Ⴖ")]
			zzMgTAkuSDn83Ya10Im64heNjXsro.append([vM9mcaHtCGqiro64,JLsVoGUKx6QArEXaN2edZmf,title,ttTAbmlyKH9Se])
	zzMgTAkuSDn83Ya10Im64heNjXsro = sorted(zzMgTAkuSDn83Ya10Im64heNjXsro, reverse=pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࡘࡷࡻࡥᅨ"), key=lambda key: float(key[G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠵Ⴗ")]))
	for vM9mcaHtCGqiro64,JLsVoGUKx6QArEXaN2edZmf,title,ttTAbmlyKH9Se in zzMgTAkuSDn83Ya10Im64heNjXsro:
		PYgCGFxpoBZ = vM9mcaHtCGqiro64[bUdr5Hahw6sY8xJ(u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭෽")]
		if l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ෾") in list(JLsVoGUKx6QArEXaN2edZmf.keys()):
			PYgCGFxpoBZ = hBvsQ7oCkKUdwjx58ml3EN(u"࠭࡭ࡱࡦࠪ෿")
		if PYgCGFxpoBZ not in DjFtN40oUmKhEObZn:
			DjFtN40oUmKhEObZn.append(PYgCGFxpoBZ)
			OQkb6CwGtxnU.append([vM9mcaHtCGqiro64,JLsVoGUKx6QArEXaN2edZmf,title,ttTAbmlyKH9Se])
	YNcoL2hj1rOpiU8,UPq4TOsCtHe7rGYD5bF13RA8vKM,Sm0dOH1vhMWjKtzcTsVNq = [],[],sTcr7iDp5eFt4RoLMhuwq1A(u"࠳Ⴘ")
	Azfxil4CX1wL,js8eRFOEJzAwLPBY0K6GmqgQkdh = yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧࠨ฀"),E6MIKdpBomef(u"ࠨࠩก")
	try: Azfxil4CX1wL = zCqhvsn4QIRHAV5GKpB[QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠩࡹ࡭ࡩ࡫࡯ࡅࡧࡷࡥ࡮ࡲࡳࠨข")][sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࡥࡺࡺࡨࡰࡴࠪฃ")]
	except: Azfxil4CX1wL = S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࠬค")
	try: GGEKzVOPBNsfpHMUJyT = zCqhvsn4QIRHAV5GKpB[dshJSmRqeiP9nap2(u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫฅ")][SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࡣࡩࡣࡱࡲࡪࡲࡉࡥࠩฆ")]
	except: GGEKzVOPBNsfpHMUJyT = sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࠨง")
	if Azfxil4CX1wL and GGEKzVOPBNsfpHMUJyT:
		Sm0dOH1vhMWjKtzcTsVNq += G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠵Ⴙ")
		title = LiRcTVUWuth70DmPy(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡓ࡜ࡔࡅࡓ࠼ࠣࠤࠬจ")+Azfxil4CX1wL+wRxoKs10Syj7V4edYhtP(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫฉ")
		ELbNB92cOh5dqtpVmi40kY = oSVpce1UQYrDqhuM6PT[E6MIKdpBomef(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫช")][pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠵Ⴚ")]+g4g6bfkPtVGU5lIM3(u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱ࠵ࠧซ")+GGEKzVOPBNsfpHMUJyT
		YNcoL2hj1rOpiU8.append(title)
		UPq4TOsCtHe7rGYD5bF13RA8vKM.append(ELbNB92cOh5dqtpVmi40kY)
		try: js8eRFOEJzAwLPBY0K6GmqgQkdh = zCqhvsn4QIRHAV5GKpB[p72fnFtcPix5UKwr9YNzW(u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫฌ")][g4g6bfkPtVGU5lIM3(u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠩญ")][FnBiAjthS8MkXs67W(u"ࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫฎ")][-XzrqbGDIy54juixkMA(u"࠷Ⴛ")][YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠨࡷࡵࡰࠬฏ")]
		except: pass
	for vM9mcaHtCGqiro64,JLsVoGUKx6QArEXaN2edZmf,title,ttTAbmlyKH9Se in OQkb6CwGtxnU:
		YNcoL2hj1rOpiU8.append(title) ; UPq4TOsCtHe7rGYD5bF13RA8vKM.append(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠩ࡫࡭࡬࡮ࡥࡴࡶࠪฐ"))
	if rXj23qLvaGnH0czfQODokPbJ: YNcoL2hj1rOpiU8.append(iRoLg2m47tnDATBHGCSPNyx(u"ูࠪํืษุ๊ࠡ์ฯࠦๅฮัาอࠬฑ")) ; UPq4TOsCtHe7rGYD5bF13RA8vKM.append(Cu1704YofAbr3QTm(u"ࠫࡲࡻࡸࡦࡦࠪฒ"))
	if zzMgTAkuSDn83Ya10Im64heNjXsro: YNcoL2hj1rOpiU8.append(G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠬ฻่าหࠣ์ฺ๎สࠡษ็้ฯ๎แาࠩณ")) ; UPq4TOsCtHe7rGYD5bF13RA8vKM.append(UTelCo0ihE1d5R(u"࠭ࡡ࡭࡮ࠪด"))
	if jBn92t1CPZAgWdIxG: YNcoL2hj1rOpiU8.append(LiRcTVUWuth70DmPy(u"ࠧ࡮ࡲࡧࠤฬิสาࠢสฺ่๎ัส๋ࠢห้฻่หࠩต")) ; UPq4TOsCtHe7rGYD5bF13RA8vKM.append(iRoLg2m47tnDATBHGCSPNyx(u"ࠨ࡯ࡳࡨࠬถ"))
	if b0bZiIYEHT8vUORAczGlaLNujg: YNcoL2hj1rOpiU8.append(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ุࠩ์ึฯࠠษั๋๊ࠥ฻่หࠩท")) ; UPq4TOsCtHe7rGYD5bF13RA8vKM.append(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠪࡺ࡮ࡪࡥࡰࠩธ"))
	if tQqVsjXK9OrpBUWknl: YNcoL2hj1rOpiU8.append(E6MIKdpBomef(u"ฺࠫ๎สࠡสา์๋ࠦี้ำฬࠫน")) ; UPq4TOsCtHe7rGYD5bF13RA8vKM.append(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠬࡧࡵࡥ࡫ࡲࠫบ"))
	rrB3IT8bALGJzX0vE6M = Cu1704YofAbr3QTm(u"ࡋࡧ࡬ࡴࡧᅩ")
	while kEhAHvti6Vnsfx(u"࡚ࡲࡶࡧᅪ"):
		z0jyetbQwKrIclL9vJW = D1DJtzviFZSrA(GEtPTVHm4U, YNcoL2hj1rOpiU8)
		if z0jyetbQwKrIclL9vJW==-yA5z6LIXBlo41PRVMY87wOisFp(u"࠱Ⴜ"): return yA5z6LIXBlo41PRVMY87wOisFp(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫป"),[],[]
		elif z0jyetbQwKrIclL9vJW==fprnld4CZo(u"࠱Ⴝ") and Azfxil4CX1wL:
			ELbNB92cOh5dqtpVmi40kY = UPq4TOsCtHe7rGYD5bF13RA8vKM[z0jyetbQwKrIclL9vJW]
			mzGeIvQtoSATpH392 = GGtWyVoJReUuEBCdAagiL1YXO8.argv[pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠲Ⴞ")]+g4g6bfkPtVGU5lIM3(u"ࠧࡀࡶࡼࡴࡪࡃࡦࡰ࡮ࡧࡩࡷࠬ࡭ࡰࡦࡨࡁ࠶࠺࠱ࠧࡰࡤࡱࡪࡃࠧผ")+mGfdCk4Hyclg9RjD(Azfxil4CX1wL)+UTelCo0ihE1d5R(u"ࠨࠨࡸࡶࡱࡃࠧฝ")+ELbNB92cOh5dqtpVmi40kY
			if js8eRFOEJzAwLPBY0K6GmqgQkdh: mzGeIvQtoSATpH392 = mzGeIvQtoSATpH392+XzrqbGDIy54juixkMA(u"ࠩࠩ࡭ࡲࡧࡧࡦ࠿ࠪพ")+mGfdCk4Hyclg9RjD(js8eRFOEJzAwLPBY0K6GmqgQkdh)
			cEZpW924rqNYm5.executebuiltin(xW2Arao7YVOemw(u"ࠥࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࠢฟ")+mzGeIvQtoSATpH392+sTcr7iDp5eFt4RoLMhuwq1A(u"ࠦ࠮ࠨภ"))
			return XzrqbGDIy54juixkMA(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪม"),[],[]
		w0g6SxLJBqDUl9cNIE52VMkR = UPq4TOsCtHe7rGYD5bF13RA8vKM[z0jyetbQwKrIclL9vJW]
		jt7H6GdrJKIkzw = YNcoL2hj1rOpiU8[z0jyetbQwKrIclL9vJW]
		if w0g6SxLJBqDUl9cNIE52VMkR==Cu1704YofAbr3QTm(u"࠭ࡤࡢࡵ࡫ࠫย"):
			hhek6RlcmH8IG = Ue61rJH2dAZ30qM5n
			break
		elif w0g6SxLJBqDUl9cNIE52VMkR in [SO94xq1RAkMm2uF(u"ࠧࡢࡷࡧ࡭ࡴ࠭ร"),S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠨࡸ࡬ࡨࡪࡵࠧฤ"),fprnld4CZo(u"ࠩࡰࡹࡽ࡫ࡤࠨล")]:
			if w0g6SxLJBqDUl9cNIE52VMkR==lc0dpSmwoPDjLnk(u"ࠪࡱࡺࡾࡥࡥࠩฦ"): eyUmvNFiYsE,oPdwZYAODb = rXj23qLvaGnH0czfQODokPbJ,pGwmaVAQ1fto98FzZ
			elif w0g6SxLJBqDUl9cNIE52VMkR==S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࡻ࡯ࡤࡦࡱࠪว"): eyUmvNFiYsE,oPdwZYAODb = b0bZiIYEHT8vUORAczGlaLNujg,nmXjIrZcHTdh9uQLlVxJe7b1zs
			elif w0g6SxLJBqDUl9cNIE52VMkR==G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠬࡧࡵࡥ࡫ࡲࠫศ"): eyUmvNFiYsE,oPdwZYAODb = tQqVsjXK9OrpBUWknl,KKeIYzMOBCStTZQLuq0U68Nlry4F
			z0jyetbQwKrIclL9vJW = D1DJtzviFZSrA(XzrqbGDIy54juixkMA(u"࠭วฯฬิࠤฬ๊ๅๅใࠣࠬࠬษ")+str(len(eyUmvNFiYsE))+iUeoLOsbHqP(u"ࠧࠡ็็ๅ࠮࠭ส"), eyUmvNFiYsE)
			if z0jyetbQwKrIclL9vJW!=-Cu1704YofAbr3QTm(u"࠴Ⴟ"):
				hhek6RlcmH8IG = oPdwZYAODb[z0jyetbQwKrIclL9vJW][FnBiAjthS8MkXs67W(u"ࠨࡷࡵࡰࠬห")]
				jt7H6GdrJKIkzw = eyUmvNFiYsE[z0jyetbQwKrIclL9vJW]
				break
		elif w0g6SxLJBqDUl9cNIE52VMkR==hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩࡰࡴࡩ࠭ฬ"):
			z0jyetbQwKrIclL9vJW = D1DJtzviFZSrA(dshJSmRqeiP9nap2(u"ࠪหำะัࠡฮ๋ำฮࠦวๅื๋ีฮࠦࠨࠨอ")+str(len(jBn92t1CPZAgWdIxG))+wRxoKs10Syj7V4edYhtP(u"๋ࠫࠥไโࠫࠪฮ"), jBn92t1CPZAgWdIxG)
			if z0jyetbQwKrIclL9vJW!=-YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠵Ⴠ"):
				jt7H6GdrJKIkzw = jBn92t1CPZAgWdIxG[z0jyetbQwKrIclL9vJW]
				iihEyY7WeogT1 = qsfPLhmUYSa[z0jyetbQwKrIclL9vJW]
				z0jyetbQwKrIclL9vJW = D1DJtzviFZSrA(iUeoLOsbHqP(u"ࠬอฮหำࠣะํีษࠡษ็ูํะࠠࠩࠩฯ")+str(len(mmxsMLbW3u9ZV))+hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࠠๆๆไ࠭ࠬะ"), mmxsMLbW3u9ZV)
				if z0jyetbQwKrIclL9vJW!=-SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠶Ⴡ"):
					jt7H6GdrJKIkzw += LiRcTVUWuth70DmPy(u"ࠧࠡ࠭ࠣࠫั")+mmxsMLbW3u9ZV[z0jyetbQwKrIclL9vJW]
					WL9MoeHQNS = pvSLGkxJXt1jRYUzl5sN7[z0jyetbQwKrIclL9vJW]
					rrB3IT8bALGJzX0vE6M = iUeoLOsbHqP(u"ࡔࡳࡷࡨᅫ")
					break
		elif w0g6SxLJBqDUl9cNIE52VMkR==lc0dpSmwoPDjLnk(u"ࠨࡣ࡯ࡰࠬา"):
			fmcl85jZJut02pxCiTQvyhRYVeOWEg,CCvBOozskVjWufLYpx93wr0c1hXH,DnhsbKkPqfS9dYjGXoMW7tua,rWFywhKg0uZGlQVsnLB = list(zip(*zzMgTAkuSDn83Ya10Im64heNjXsro))
			z0jyetbQwKrIclL9vJW = D1DJtzviFZSrA(iRoLg2m47tnDATBHGCSPNyx(u"ࠩสาฯืࠠศๆ่่ๆࠦࠨࠨำ")+str(len(DnhsbKkPqfS9dYjGXoMW7tua))+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠪࠤ๊๊แࠪࠩิ"), DnhsbKkPqfS9dYjGXoMW7tua)
			if z0jyetbQwKrIclL9vJW!=-Me28A1sBLNIgUp5YCDyvT(u"࠷Ⴢ"):
				jt7H6GdrJKIkzw = DnhsbKkPqfS9dYjGXoMW7tua[z0jyetbQwKrIclL9vJW]
				iihEyY7WeogT1 = fmcl85jZJut02pxCiTQvyhRYVeOWEg[z0jyetbQwKrIclL9vJW]
				if zqdvcbP5L8BHh(u"ࠫࡲࡶࡤࠨี") in DnhsbKkPqfS9dYjGXoMW7tua[z0jyetbQwKrIclL9vJW] and iihEyY7WeogT1[fprnld4CZo(u"ࠬࡻࡲ࡭ࠩึ")]!=Ue61rJH2dAZ30qM5n:
					WL9MoeHQNS = CCvBOozskVjWufLYpx93wr0c1hXH[z0jyetbQwKrIclL9vJW]
					rrB3IT8bALGJzX0vE6M = XzrqbGDIy54juixkMA(u"ࡕࡴࡸࡩᅬ")
				else: hhek6RlcmH8IG = iihEyY7WeogT1[S4SOKF2QbBhjCd3RrVMuHIzE(u"࠭ࡵࡳ࡮ࠪื")]
				break
		elif w0g6SxLJBqDUl9cNIE52VMkR==SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠧࡩ࡫ࡪ࡬ࡪࡹࡴࠨุ"):
			fmcl85jZJut02pxCiTQvyhRYVeOWEg,CCvBOozskVjWufLYpx93wr0c1hXH,DnhsbKkPqfS9dYjGXoMW7tua,rWFywhKg0uZGlQVsnLB = list(zip(*OQkb6CwGtxnU))
			iihEyY7WeogT1 = fmcl85jZJut02pxCiTQvyhRYVeOWEg[z0jyetbQwKrIclL9vJW-Sm0dOH1vhMWjKtzcTsVNq]
			if kEhAHvti6Vnsfx(u"ࠨ࡯ࡳࡨูࠬ") in DnhsbKkPqfS9dYjGXoMW7tua[z0jyetbQwKrIclL9vJW-Sm0dOH1vhMWjKtzcTsVNq] and iihEyY7WeogT1[wRxoKs10Syj7V4edYhtP(u"ࠩࡸࡶࡱฺ࠭")]!=Ue61rJH2dAZ30qM5n:
				WL9MoeHQNS = CCvBOozskVjWufLYpx93wr0c1hXH[z0jyetbQwKrIclL9vJW-Sm0dOH1vhMWjKtzcTsVNq]
				rrB3IT8bALGJzX0vE6M = xW2Arao7YVOemw(u"ࡖࡵࡹࡪᅭ")
			else: hhek6RlcmH8IG = iihEyY7WeogT1[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪࡹࡷࡲࠧ฻")]
			jt7H6GdrJKIkzw = DnhsbKkPqfS9dYjGXoMW7tua[z0jyetbQwKrIclL9vJW-Sm0dOH1vhMWjKtzcTsVNq]
			break
	if not rrB3IT8bALGJzX0vE6M: T53BKcaQ2xFrl9XkWsjL = hhek6RlcmH8IG
	else: T53BKcaQ2xFrl9XkWsjL = iUeoLOsbHqP(u"࡛ࠫ࡯ࡤࡦࡱ࠽ࠤࠬ฼")+iihEyY7WeogT1[SO94xq1RAkMm2uF(u"ࠬࡻࡲ࡭ࠩ฽")]+YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠭ࠠࠬࠢࡄࡹࡩ࡯࡯࠻ࠢࠪ฾")+WL9MoeHQNS[fprnld4CZo(u"ࠧࡶࡴ࡯ࠫ฿")]
	if rrB3IT8bALGJzX0vE6M:
		okhpG4VdIlaz9ZBxicD = int(iihEyY7WeogT1[fprnld4CZo(u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪเ")])
		FScJ8W5Dt1dg = int(WL9MoeHQNS[l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫแ")])
		EDL3rwcivsR9W0pdTfygmOYUoVSb = str(max(okhpG4VdIlaz9ZBxicD,FScJ8W5Dt1dg))
		bhmgO3ze1W42NGqy = iihEyY7WeogT1[kEhAHvti6Vnsfx(u"ࠪࡹࡷࡲࠧโ")].replace(E6MIKdpBomef(u"ࠫࠫ࠭ใ"),dshJSmRqeiP9nap2(u"ࠬࠬࡡ࡮ࡲ࠾ࠫไ"))
		wivW7ZhfzXS = WL9MoeHQNS[pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭ࡵࡳ࡮ࠪๅ")].replace(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧࠧࠩๆ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠨࠨࡤࡱࡵࡁࠧ็"))
		mpd = p72fnFtcPix5UKwr9YNzW(u"ࠩ࠿ࡃࡽࡳ࡬ࠡࡸࡨࡶࡸ࡯࡯࡯࠿ࠥ࠵࠳࠶ࠢࠡࡧࡱࡧࡴࡪࡩ࡯ࡩࡀ࡚࡚ࠦࡆ࠮࠺ࠥࡃࡃࡢ࡮ࠨ่")
		mpd += UTelCo0ihE1d5R(u"ࠪࡀࡒࡖࡄࠡࡺࡰࡰࡳࡹ࠺ࡹࡵ࡬ࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡺ࠷࠳ࡵࡲࡨ࠱࠵࠴࠵࠷࠯࡙ࡏࡏࡗࡨ࡮ࡥ࡮ࡣ࠰࡭ࡳࡹࡴࡢࡰࡦࡩࠧࠦࡸ࡮࡮ࡱࡷࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡦࡤࡷ࡭ࡀࡳࡤࡪࡨࡱࡦࡀ࡭ࡱࡦ࠽࠶࠵࠷࠱ࠣࠢࡻࡱࡱࡴࡳ࠻ࡺ࡯࡭ࡳࡱ࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡽ࠳࠯ࡱࡵ࡫࠴࠷࠹࠺࠻࠲ࡼࡱ࡯࡮࡬ࠤࠣࡼࡸ࡯࠺ࡴࡥ࡫ࡩࡲࡧࡌࡰࡥࡤࡸ࡮ࡵ࡮࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡩࡧࡳࡩ࠼ࡶࡧ࡭࡫࡭ࡢ࠼ࡰࡴࡩࡀ࠲࠱࠳࠴ࠤ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡺࡡ࡯ࡦࡤࡶࡩࡹ࠮ࡪࡵࡲ࠲ࡴࡸࡧ࠰࡫ࡷࡸ࡫࠵ࡐࡶࡤ࡯࡭ࡨࡲࡹࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࡖࡸࡦࡴࡤࡢࡴࡧࡷ࠴ࡓࡐࡆࡉ࠰ࡈࡆ࡙ࡈࡠࡵࡦ࡬ࡪࡳࡡࡠࡨ࡬ࡰࡪࡹ࠯ࡅࡃࡖࡌ࠲ࡓࡐࡅ࠰ࡻࡷࡩࠨࠠ࡮࡫ࡱࡆࡺ࡬ࡦࡦࡴࡗ࡭ࡲ࡫࠽ࠣࡒࡗ࠵࠳࠻ࡓࠣࠢࡰࡩࡩ࡯ࡡࡑࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࡊࡵࡳࡣࡷ࡭ࡴࡴ࠽ࠣࡒࡗ้ࠫ")+EDL3rwcivsR9W0pdTfygmOYUoVSb+oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫࡘࠨࠠࡵࡻࡳࡩࡂࠨࡳࡵࡣࡷ࡭ࡨࠨࠠࡱࡴࡲࡪ࡮ࡲࡥࡴ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡪࡡࡴࡪ࠽ࡴࡷࡵࡦࡪ࡮ࡨ࠾࡮ࡹ࡯ࡧࡨ࠰ࡱࡦ࡯࡮࠻࠴࠳࠵࠶ࠨ࠾࡝ࡰ๊ࠪ")
		mpd += bUdr5Hahw6sY8xJ(u"ࠬࡂࡐࡦࡴ࡬ࡳࡩࡄ࡜࡯๋ࠩ")
		mpd += Cu1704YofAbr3QTm(u"࠭࠼ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺࠠࡪࡦࡀࠦ࠵ࠨࠠ࡮࡫ࡰࡩ࡙ࡿࡰࡦ࠿ࠥࡺ࡮ࡪࡥࡰ࠱ࠪ์")+iihEyY7WeogT1[G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩํ")]+yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨࠤࠣࡷࡺࡨࡳࡦࡩࡰࡩࡳࡺࡁ࡭࡫ࡪࡲࡲ࡫࡮ࡵ࠿ࠥࡸࡷࡻࡥࠣࡀ࡟ࡲࠬ๎")
		mpd += sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩ࠿ࡖࡴࡲࡥࠡࡵࡦ࡬ࡪࡳࡥࡊࡦࡘࡶ࡮ࡃࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡇࡅࡘࡎ࠺ࡳࡱ࡯ࡩ࠿࠸࠰࠲࠳ࠥࠤࡻࡧ࡬ࡶࡧࡀࠦࡲࡧࡩ࡯ࠤ࠲ࡂࡡࡴࠧ๏")
		mpd += LiRcTVUWuth70DmPy(u"ࠪࡀࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠥ࡯ࡤ࠾ࠤࠪ๐")+iihEyY7WeogT1[wRxoKs10Syj7V4edYhtP(u"ࠫ࡮ࡺࡡࡨࠩ๑")]+hBvsQ7oCkKUdwjx58ml3EN(u"ࠬࠨࠠࡤࡱࡧࡩࡨࡹ࠽ࠣࠩ๒")+iihEyY7WeogT1[l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࡣࡰࡦࡨࡧࡸ࠭๓")]+hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠧࠣࠢࡶࡸࡦࡸࡴࡘ࡫ࡷ࡬ࡘࡇࡐ࠾ࠤ࠴ࠦࠥࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨ࠾ࠤࠪ๔")+str(iihEyY7WeogT1[UTelCo0ihE1d5R(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ๕")])+Me28A1sBLNIgUp5YCDyvT(u"ࠩࠥࠤࡼ࡯ࡤࡵࡪࡀࠦࠬ๖")+str(iihEyY7WeogT1[UTelCo0ihE1d5R(u"ࠪࡻ࡮ࡪࡴࡩࠩ๗")])+E6MIKdpBomef(u"ࠫࠧࠦࡨࡦ࡫ࡪ࡬ࡹࡃࠢࠨ๘")+str(iihEyY7WeogT1[g4g6bfkPtVGU5lIM3(u"ࠬ࡮ࡥࡪࡩ࡫ࡸࠬ๙")])+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭ࠢࠡࡨࡵࡥࡲ࡫ࡒࡢࡶࡨࡁࠧ࠭๚")+iihEyY7WeogT1[xW2Arao7YVOemw(u"ࠧࡧࡲࡶࠫ๛")]+LiRcTVUWuth70DmPy(u"ࠨࠤࡁࡠࡳ࠭๜")
		mpd += zqdvcbP5L8BHh(u"ࠩ࠿ࡆࡦࡹࡥࡖࡔࡏࡂࠬ๝")+bhmgO3ze1W42NGqy+LiRcTVUWuth70DmPy(u"ࠪࡀ࠴ࡈࡡࡴࡧࡘࡖࡑࡄ࡜࡯ࠩ๞")
		mpd += FnBiAjthS8MkXs67W(u"ࠫࡁ࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࠣ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫࠽ࠣࠩ๟")+iihEyY7WeogT1[hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠬ࡯࡮ࡥࡧࡻࠫ๠")]+S4SOKF2QbBhjCd3RrVMuHIzE(u"࠭ࠢ࠿࡞ࡱࠫ๡")
		mpd += LiRcTVUWuth70DmPy(u"ࠧ࠽ࡋࡱ࡭ࡹ࡯ࡡ࡭࡫ࡽࡥࡹ࡯࡯࡯ࠢࡵࡥࡳ࡭ࡥ࠾ࠤࠪ๢")+iihEyY7WeogT1[LiRcTVUWuth70DmPy(u"ࠨ࡫ࡱ࡭ࡹ࠭๣")]+zqdvcbP5L8BHh(u"ࠩࠥࠤ࠴ࡄ࡜࡯ࠩ๤")
		mpd += SO94xq1RAkMm2uF(u"ࠪࡀ࠴࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࡁࡠࡳ࠭๥")
		mpd += hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠫࡁ࠵ࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴ࠾࡝ࡰࠪ๦")
		mpd += iUeoLOsbHqP(u"ࠬࡂ࠯ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺ࠾࡝ࡰࠪ๧")
		mpd += wRxoKs10Syj7V4edYhtP(u"࠭࠼ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺࠠࡪࡦࡀࠦ࠶ࠨࠠ࡮࡫ࡰࡩ࡙ࡿࡰࡦ࠿ࠥࡥࡺࡪࡩࡰ࠱ࠪ๨")+WL9MoeHQNS[UTelCo0ihE1d5R(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ๩")]+SO94xq1RAkMm2uF(u"ࠨࠤࠣࡷࡺࡨࡳࡦࡩࡰࡩࡳࡺࡁ࡭࡫ࡪࡲࡲ࡫࡮ࡵ࠿ࠥࡸࡷࡻࡥࠣࡀ࡟ࡲࠬ๪")
		mpd += G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠩ࠿ࡖࡴࡲࡥࠡࡵࡦ࡬ࡪࡳࡥࡊࡦࡘࡶ࡮ࡃࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡇࡅࡘࡎ࠺ࡳࡱ࡯ࡩ࠿࠸࠰࠲࠳ࠥࠤࡻࡧ࡬ࡶࡧࡀࠦࡲࡧࡩ࡯ࠤ࠲ࡂࡡࡴࠧ๫")
		mpd += fprnld4CZo(u"ࠪࡀࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠥ࡯ࡤ࠾ࠤࠪ๬")+WL9MoeHQNS[fprnld4CZo(u"ࠫ࡮ࡺࡡࡨࠩ๭")]+p72fnFtcPix5UKwr9YNzW(u"ࠬࠨࠠࡤࡱࡧࡩࡨࡹ࠽ࠣࠩ๮")+WL9MoeHQNS[E6MIKdpBomef(u"࠭ࡣࡰࡦࡨࡧࡸ࠭๯")]+g4g6bfkPtVGU5lIM3(u"ࠧࠣࠢࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࡂࠨ࠱࠴࠲࠷࠻࠺ࠨ࠾࡝ࡰࠪ๰")
		mpd += hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨ࠾ࡄࡹࡩ࡯࡯ࡄࡪࡤࡲࡳ࡫࡬ࡄࡱࡱࡪ࡮࡭ࡵࡳࡣࡷ࡭ࡴࡴࠠࡴࡥ࡫ࡩࡲ࡫ࡉࡥࡗࡵ࡭ࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡦࡤࡷ࡭ࡀ࠲࠴࠲࠳࠷࠿࠹࠺ࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲ࡟ࡤࡱࡱࡪ࡮࡭ࡵࡳࡣࡷ࡭ࡴࡴ࠺࠳࠲࠴࠵ࠧࠦࡶࡢ࡮ࡸࡩࡂࠨࠧ๱")+WL9MoeHQNS[kEhAHvti6Vnsfx(u"ࠩࡤࡹࡩ࡯࡯ࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ๲")]+FvNyZqaLKw(u"ࠪࠦ࠴ࡄ࡜࡯ࠩ๳")
		mpd += S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠫࡁࡈࡡࡴࡧࡘࡖࡑࡄࠧ๴")+wivW7ZhfzXS+SO94xq1RAkMm2uF(u"ࠬࡂ࠯ࡃࡣࡶࡩ࡚ࡘࡌ࠿࡞ࡱࠫ๵")
		mpd += Me28A1sBLNIgUp5YCDyvT(u"࠭࠼ࡔࡧࡪࡱࡪࡴࡴࡃࡣࡶࡩࠥ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦ࠿ࠥࠫ๶")+WL9MoeHQNS[pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧࡪࡰࡧࡩࡽ࠭๷")]+lc0dpSmwoPDjLnk(u"ࠨࠤࡁࡠࡳ࠭๸")
		mpd += dshJSmRqeiP9nap2(u"ࠩ࠿ࡍࡳ࡯ࡴࡪࡣ࡯࡭ࡿࡧࡴࡪࡱࡱࠤࡷࡧ࡮ࡨࡧࡀࠦࠬ๹")+WL9MoeHQNS[FvNyZqaLKw(u"ࠪ࡭ࡳ࡯ࡴࠨ๺")]+lc0dpSmwoPDjLnk(u"ࠫࠧࠦ࠯࠿࡞ࡱࠫ๻")
		mpd += iRoLg2m47tnDATBHGCSPNyx(u"ࠬࡂ࠯ࡔࡧࡪࡱࡪࡴࡴࡃࡣࡶࡩࡃࡢ࡮ࠨ๼")
		mpd += iUeoLOsbHqP(u"࠭࠼࠰ࡔࡨࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࡀ࡟ࡲࠬ๽")
		mpd += p72fnFtcPix5UKwr9YNzW(u"ࠧ࠽࠱ࡄࡨࡦࡶࡴࡢࡶ࡬ࡳࡳ࡙ࡥࡵࡀ࡟ࡲࠬ๾")
		mpd += lc0dpSmwoPDjLnk(u"ࠨ࠾࠲ࡔࡪࡸࡩࡰࡦࡁࡠࡳ࠭๿")
		mpd += UTelCo0ihE1d5R(u"ࠩ࠿࠳ࡒࡖࡄ࠿࡞ࡱࠫ຀")
		if u4ChFMGf6K93tbDjJ12zi0YQsAHyP:
			import http.server as cLUbYuIBzlMxsN0KhqiF2m
			import http.client as I80waz73NF5MYuo
		else:
			import BaseHTTPServer as cLUbYuIBzlMxsN0KhqiF2m
			import httplib as I80waz73NF5MYuo
		class exlvpUtEuZ(cLUbYuIBzlMxsN0KhqiF2m.HTTPServer):
			def __init__(J4JbrLDI1aWiBHX8hYuZcFCq6VsG,ip=kEhAHvti6Vnsfx(u"ࠪࡰࡴࡩࡡ࡭ࡪࡲࡷࡹ࠭ກ"),port=hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠵࠶࠲࠸࠹Ⴣ"),mpd=p72fnFtcPix5UKwr9YNzW(u"ࠫࡁࡄࠧຂ")):
				J4JbrLDI1aWiBHX8hYuZcFCq6VsG.ip = ip
				J4JbrLDI1aWiBHX8hYuZcFCq6VsG.port = port
				J4JbrLDI1aWiBHX8hYuZcFCq6VsG.mpd = mpd
				cLUbYuIBzlMxsN0KhqiF2m.HTTPServer.__init__(J4JbrLDI1aWiBHX8hYuZcFCq6VsG,(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.ip,J4JbrLDI1aWiBHX8hYuZcFCq6VsG.port),oEskVh6Tg2ZKFBrU0SAu4X3Y9m)
				J4JbrLDI1aWiBHX8hYuZcFCq6VsG.mpdurl = SO94xq1RAkMm2uF(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠭຃")+ip+iRoLg2m47tnDATBHGCSPNyx(u"࠭࠺ࠨຄ")+str(port)+zqdvcbP5L8BHh(u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࠰ࡰࡴࡩ࠭຅")
			def start(J4JbrLDI1aWiBHX8hYuZcFCq6VsG):
				J4JbrLDI1aWiBHX8hYuZcFCq6VsG.threads = eWia5rknYzHm0J(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࡉࡥࡱࡹࡥᅮ"))
				J4JbrLDI1aWiBHX8hYuZcFCq6VsG.threads.IISJUtB5zhnRuCp39(hBvsQ7oCkKUdwjx58ml3EN(u"࠲Ⴤ"),J4JbrLDI1aWiBHX8hYuZcFCq6VsG.jxkecv8XCuWLGsimbIoltJD)
			def jxkecv8XCuWLGsimbIoltJD(J4JbrLDI1aWiBHX8hYuZcFCq6VsG):
				J4JbrLDI1aWiBHX8hYuZcFCq6VsG.keeprunning = l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࡘࡷࡻࡥᅯ")
				while J4JbrLDI1aWiBHX8hYuZcFCq6VsG.keeprunning:
					J4JbrLDI1aWiBHX8hYuZcFCq6VsG.handle_request()
			def stop(J4JbrLDI1aWiBHX8hYuZcFCq6VsG):
				J4JbrLDI1aWiBHX8hYuZcFCq6VsG.keeprunning = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࡋࡧ࡬ࡴࡧᅰ")
				J4JbrLDI1aWiBHX8hYuZcFCq6VsG.timy60SxBT1cl3rnfaJMCqbjIX8p()
			def KKDGzqanYiTQxkcfjtFs(J4JbrLDI1aWiBHX8hYuZcFCq6VsG):
				J4JbrLDI1aWiBHX8hYuZcFCq6VsG.stop()
				J4JbrLDI1aWiBHX8hYuZcFCq6VsG.PWX8Cboc6iE0KOgafZ9jMw1pG.close()
				J4JbrLDI1aWiBHX8hYuZcFCq6VsG.server_close()
			def RNhzToSB3ZtCs9L6F1DWAlQEkU(J4JbrLDI1aWiBHX8hYuZcFCq6VsG,mpd):
				J4JbrLDI1aWiBHX8hYuZcFCq6VsG.mpd = mpd
			def timy60SxBT1cl3rnfaJMCqbjIX8p(J4JbrLDI1aWiBHX8hYuZcFCq6VsG):
				QAlb96UhsVG = I80waz73NF5MYuo.HTTPConnection(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.ip+FvNyZqaLKw(u"ࠨ࠼ࠪຆ")+str(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.port))
				QAlb96UhsVG.request(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠤࡋࡉࡆࡊࠢງ"), FvNyZqaLKw(u"ࠥ࠳ࠧຈ"))
		class oEskVh6Tg2ZKFBrU0SAu4X3Y9m(cLUbYuIBzlMxsN0KhqiF2m.BaseHTTPRequestHandler):
			def Jun6izH0hZ7AD(J4JbrLDI1aWiBHX8hYuZcFCq6VsG):
				J4JbrLDI1aWiBHX8hYuZcFCq6VsG.send_response(iRoLg2m47tnDATBHGCSPNyx(u"࠴࠳࠴Ⴥ"))
				J4JbrLDI1aWiBHX8hYuZcFCq6VsG.send_header(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡺࡹࡱࡧࠪຉ"),p72fnFtcPix5UKwr9YNzW(u"ࠬࡺࡥࡹࡶࡷ࠳ࡵࡲࡡࡪࡰࠪຊ"))
				J4JbrLDI1aWiBHX8hYuZcFCq6VsG.end_headers()
				J4JbrLDI1aWiBHX8hYuZcFCq6VsG.wfile.write(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.C83UXWf15zdwLA0.mpd.encode(XzrqbGDIy54juixkMA(u"࠭ࡵࡵࡨ࠻ࠫ຋")))
				MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠴჆"))
				if J4JbrLDI1aWiBHX8hYuZcFCq6VsG.path==SO94xq1RAkMm2uF(u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࠰ࡰࡴࡩ࠭ຌ"): J4JbrLDI1aWiBHX8hYuZcFCq6VsG.C83UXWf15zdwLA0.KKDGzqanYiTQxkcfjtFs()
				if J4JbrLDI1aWiBHX8hYuZcFCq6VsG.path==dshJSmRqeiP9nap2(u"ࠨ࠱ࡶ࡬ࡺࡺࡤࡰࡹࡱࠫຍ"): J4JbrLDI1aWiBHX8hYuZcFCq6VsG.C83UXWf15zdwLA0.KKDGzqanYiTQxkcfjtFs()
			def vx24MtleWLChdEmsTgfqFubyAoI6(J4JbrLDI1aWiBHX8hYuZcFCq6VsG):
				J4JbrLDI1aWiBHX8hYuZcFCq6VsG.send_response(FnBiAjthS8MkXs67W(u"࠶࠵࠶Ⴧ"))
				J4JbrLDI1aWiBHX8hYuZcFCq6VsG.end_headers()
		yPTzmuj0lapeMYC8NSvgQXiFIB = exlvpUtEuZ(g4g6bfkPtVGU5lIM3(u"ࠩ࠴࠶࠼࠴࠰࠯࠲࠱࠵ࠬຎ"),S4SOKF2QbBhjCd3RrVMuHIzE(u"࠺࠻࠰࠶࠷჈"),mpd)
		hhek6RlcmH8IG = yPTzmuj0lapeMYC8NSvgQXiFIB.mpdurl
		yPTzmuj0lapeMYC8NSvgQXiFIB.start()
	else: yPTzmuj0lapeMYC8NSvgQXiFIB = LiRcTVUWuth70DmPy(u"ࠪࠫຏ")
	if not hhek6RlcmH8IG: return SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࡊࡸࡲࡰࡴࠣࠤࠥࠦ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣ࡝ࡔ࡛ࡔࡖࡄࡈࠤࡋࡧࡩ࡭ࡧࡧࠫຐ"),[],[]
	return SO94xq1RAkMm2uF(u"ࠬ࠭ຑ"),[SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠭ࠧຒ")],[[hhek6RlcmH8IG,EER1WVLBPmTZd,yPTzmuj0lapeMYC8NSvgQXiFIB]]
def vufdxnJTXh5RlpW9maY(url):
	headers = { lc0dpSmwoPDjLnk(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫຓ") : g4g6bfkPtVGU5lIM3(u"ࠨࠩດ") }
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(xh9BXlAw0UoVsIZ4if3,url,FvNyZqaLKw(u"ࠩࠪຕ"),headers,hBvsQ7oCkKUdwjx58ml3EN(u"ࠪࠫຖ"),XzrqbGDIy54juixkMA(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡗࡋࡇࡆࡔࡈ࠭࠲ࡵࡷࠫທ"))
	items = GGvHJKP9LUxEk10Fw.findall(LiRcTVUWuth70DmPy(u"ࠬ࡬ࡩ࡭ࡧ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠬ࠱ࡲࡡࡣࡧ࡯࠾ࠧ࠮࠮ࠫࡁࠬࠦࢁ࠯࡜ࡾࠩຘ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	items = set(items)
	items = sorted(items, reverse=iRoLg2m47tnDATBHGCSPNyx(u"࡚ࡲࡶࡧᅱ"), key=lambda key: key[iRoLg2m47tnDATBHGCSPNyx(u"࠸჉")])
	pnOTgyAIevsrkqVch,eyUmvNFiYsE,BBvfW05P4wUs9Nlkjqyd6gnaAC,zzvBg3ShiamAZ = [],[],[],[]
	if not items: return UTelCo0ihE1d5R(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡘࡌࡈࡇࡕࡂࠨນ"),[],[]
	for ELbNB92cOh5dqtpVmi40kY,X4XyOPCEu65AMYebxwaVW,ccIZBYDOGdJlTE81Li2wAmuKtk in items:
		ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.replace(S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠧࡩࡶࡷࡴࡸࡀࠧບ"),bUdr5Hahw6sY8xJ(u"ࠨࡪࡷࡸࡵࡀࠧປ"))
		if dshJSmRqeiP9nap2(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨຜ") in ELbNB92cOh5dqtpVmi40kY:
			pnOTgyAIevsrkqVch,BBvfW05P4wUs9Nlkjqyd6gnaAC = BXEJoygQHA8RZ(ELbNB92cOh5dqtpVmi40kY)
			zzvBg3ShiamAZ = zzvBg3ShiamAZ + BBvfW05P4wUs9Nlkjqyd6gnaAC
			if pnOTgyAIevsrkqVch[XzrqbGDIy54juixkMA(u"࠰჊")]==l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪ࠱࠶࠭ຝ"): eyUmvNFiYsE.append(lc0dpSmwoPDjLnk(u"ุࠫ๐ัโำࠣาฬ฻ࠧພ")+xW2Arao7YVOemw(u"ࠬࠦࠠࠡ࡯࠶ࡹ࠽࠭ຟ"))
			else:
				for title in pnOTgyAIevsrkqVch:
					eyUmvNFiYsE.append(iRoLg2m47tnDATBHGCSPNyx(u"࠭ำ๋ำไีࠥิวึࠩຠ")+bUdr5Hahw6sY8xJ(u"ࠧࠡࠢࠣࠫມ")+title)
		else:
			title = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠨีํีๆืࠠฯษุࠫຢ")+oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠩࠣࠤࠥࡳࡰ࠵ࠢࠣࠤࠬຣ")+ccIZBYDOGdJlTE81Li2wAmuKtk
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
			eyUmvNFiYsE.append(title)
	return Cu1704YofAbr3QTm(u"ࠪࠫ຤"),eyUmvNFiYsE,zzvBg3ShiamAZ
def ZHj03wK2Tq(url,BBlXpmUyhFDwNtCVAHoE):
	HHSO6Q4KI0hlPxYpNuXRkWCmjEgA,uuIjMn1YTf687WlRcOmhq4G23H,Ymlyk3rMKj512tacPEASXW09f8biU,XmkyiLasFhMzCGYQu8rA,gI487voLsArVqW6Ffp = [],[],[],[],[]
	ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(iRoLg2m47tnDATBHGCSPNyx(u"ࠫࡁࡼࡩࡥࡧࡲࠤࡵࡸࡥ࡭ࡱࡤࡨ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬລ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if ELbNB92cOh5dqtpVmi40kY and not dd8rHcveo7O15hT3MSR(ELbNB92cOh5dqtpVmi40kY[hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠱჋")]): ELbNB92cOh5dqtpVmi40kY = []
	if not ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(FvNyZqaLKw(u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ຦"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if ELbNB92cOh5dqtpVmi40kY and not dd8rHcveo7O15hT3MSR(ELbNB92cOh5dqtpVmi40kY[Cu1704YofAbr3QTm(u"࠲჌")]): ELbNB92cOh5dqtpVmi40kY = []
	if not ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall(Me28A1sBLNIgUp5YCDyvT(u"࠭ࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬວ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if ELbNB92cOh5dqtpVmi40kY and not dd8rHcveo7O15hT3MSR(ELbNB92cOh5dqtpVmi40kY[SO94xq1RAkMm2uF(u"࠳Ⴭ")]): ELbNB92cOh5dqtpVmi40kY = []
	if ELbNB92cOh5dqtpVmi40kY:
		ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY[Cu1704YofAbr3QTm(u"࠴჎")]
		title = ELbNB92cOh5dqtpVmi40kY.rsplit(yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧ࠯ࠩຨ"),lc0dpSmwoPDjLnk(u"࠶჏"))[lc0dpSmwoPDjLnk(u"࠶჏")]
		HHSO6Q4KI0hlPxYpNuXRkWCmjEgA.append(title)
		uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY)
	else:
		EHDeldN7L2k19JBUqhmsuSXiwV = GGvHJKP9LUxEk10Fw.findall(XzrqbGDIy54juixkMA(u"ࠨࡵࡲࡹࡷࡩࡥࡴ࠼ࠣ࠮࠭ࡢ࡛࠯ࠬࡂࡠࡢ࠯ࠧຩ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if not EHDeldN7L2k19JBUqhmsuSXiwV: EHDeldN7L2k19JBUqhmsuSXiwV = GGvHJKP9LUxEk10Fw.findall(Cu1704YofAbr3QTm(u"ࠩࡹࡥࡷࠦࡳࡰࡷࡵࡧࡪࡹࠠ࠾ࠢࠫࡠࢀ࠴ࠪࡀ࡞ࢀ࠭ࠬສ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if not EHDeldN7L2k19JBUqhmsuSXiwV: EHDeldN7L2k19JBUqhmsuSXiwV = GGvHJKP9LUxEk10Fw.findall(hBvsQ7oCkKUdwjx58ml3EN(u"ࠪࡺࡦࡸࠠ࡫ࡹࠣࡁࠥ࠮࡜ࡼ࠰࠭ࡃࡡࢃࠩࠨຫ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if not EHDeldN7L2k19JBUqhmsuSXiwV: EHDeldN7L2k19JBUqhmsuSXiwV = GGvHJKP9LUxEk10Fw.findall(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࡻࡧࡲࠡࡲ࡯ࡥࡾ࡫ࡲࠡ࠿ࠣ࠲࠯ࡅ࡜ࠩࠪ࡟ࡿ࠳࠰࠿࡝ࡿࠬࡠ࠮࠭ຬ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EHDeldN7L2k19JBUqhmsuSXiwV:
			EHDeldN7L2k19JBUqhmsuSXiwV = EHDeldN7L2k19JBUqhmsuSXiwV[kEhAHvti6Vnsfx(u"࠶ა")]
			EHDeldN7L2k19JBUqhmsuSXiwV = GGvHJKP9LUxEk10Fw.sub(FnBiAjthS8MkXs67W(u"ࡷ࠭ࠨ࡜࡞ࡾࡠ࠱ࡣ࡛࡝ࡶ࡟ࡷࡡࡴ࡜ࡳ࡟࠭࠭࠭ࡢࡷࠬ࡝࡟ࡸࡡࡹ࡝ࠫࠫ࠽ࠫອ"),zqdvcbP5L8BHh(u"ࡸࠧ࡝࠳ࠥࡠ࠷ࠨ࠺ࠨຮ"),EHDeldN7L2k19JBUqhmsuSXiwV)
			EHDeldN7L2k19JBUqhmsuSXiwV = JKw5OWktPZB(xW2Arao7YVOemw(u"ࠧࡥ࡫ࡦࡸࠬຯ"),EHDeldN7L2k19JBUqhmsuSXiwV)
			if isinstance(EHDeldN7L2k19JBUqhmsuSXiwV,dict): EHDeldN7L2k19JBUqhmsuSXiwV = [EHDeldN7L2k19JBUqhmsuSXiwV]
			for UCEFMfKbgpd in EHDeldN7L2k19JBUqhmsuSXiwV:
				HmD8fPh3Jb,ELbNB92cOh5dqtpVmi40kY = E6MIKdpBomef(u"ࠨࠩະ"),iUeoLOsbHqP(u"ࠩࠪັ")
				if isinstance(UCEFMfKbgpd,dict):
					keys = list(UCEFMfKbgpd.keys())
					if   yA5z6LIXBlo41PRVMY87wOisFp(u"ࠪࡸࡾࡶࡥࠨາ") in keys: HmD8fPh3Jb = str(UCEFMfKbgpd[hBvsQ7oCkKUdwjx58ml3EN(u"ࠫࡹࡿࡰࡦࠩຳ")])
					if   S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠬ࡬ࡩ࡭ࡧࠪິ") in keys: ELbNB92cOh5dqtpVmi40kY = UCEFMfKbgpd[Cu1704YofAbr3QTm(u"࠭ࡦࡪ࡮ࡨࠫີ")]
					elif QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧࡩ࡮ࡶࠫຶ") in keys: ELbNB92cOh5dqtpVmi40kY = UCEFMfKbgpd[yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨࡪ࡯ࡷࠬື")]
					elif hBvsQ7oCkKUdwjx58ml3EN(u"ࠩࡶࡶࡨຸ࠭") in keys: ELbNB92cOh5dqtpVmi40kY = UCEFMfKbgpd[p72fnFtcPix5UKwr9YNzW(u"ࠪࡷࡷࡩູࠧ")]
					if   kEhAHvti6Vnsfx(u"ࠫࡱࡧࡢࡦ࡮຺ࠪ") in keys: title = str(UCEFMfKbgpd[XzrqbGDIy54juixkMA(u"ࠬࡲࡡࡣࡧ࡯ࠫົ")])
					elif hBvsQ7oCkKUdwjx58ml3EN(u"࠭ࡶࡪࡦࡨࡳࡤ࡮ࡥࡪࡩ࡫ࡸࠬຼ") in keys: title = str(UCEFMfKbgpd[l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧࡷ࡫ࡧࡩࡴࡥࡨࡦ࡫ࡪ࡬ࡹ࠭ຽ")])
					elif p72fnFtcPix5UKwr9YNzW(u"ࠨ࠰ࠪ຾") in ELbNB92cOh5dqtpVmi40kY: title = ELbNB92cOh5dqtpVmi40kY.rsplit(Me28A1sBLNIgUp5YCDyvT(u"ࠩ࠱ࠫ຿"),lc0dpSmwoPDjLnk(u"࠱ბ"))[lc0dpSmwoPDjLnk(u"࠱ბ")]
					else: title = ELbNB92cOh5dqtpVmi40kY
				elif isinstance(UCEFMfKbgpd,str):
					ELbNB92cOh5dqtpVmi40kY = UCEFMfKbgpd
					title = ELbNB92cOh5dqtpVmi40kY.rsplit(FnBiAjthS8MkXs67W(u"ࠪ࠲ࠬເ"),yA5z6LIXBlo41PRVMY87wOisFp(u"࠲გ"))[yA5z6LIXBlo41PRVMY87wOisFp(u"࠲გ")]
				if iRoLg2m47tnDATBHGCSPNyx(u"࠳დ"):
					HHSO6Q4KI0hlPxYpNuXRkWCmjEgA.append(title+lc0dpSmwoPDjLnk(u"ࠫࠥࠦࠧແ")+HmD8fPh3Jb)
					uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY)
	for ELbNB92cOh5dqtpVmi40kY,title in zip(uuIjMn1YTf687WlRcOmhq4G23H,HHSO6Q4KI0hlPxYpNuXRkWCmjEgA):
		ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.replace(FvNyZqaLKw(u"ࠬࡢ࡜࠰ࠩໂ"),hBvsQ7oCkKUdwjx58ml3EN(u"࠭࠯ࠨໃ"))
		C83UXWf15zdwLA0 = RfKuIXwPAiWtmyF(url,FnBiAjthS8MkXs67W(u"ࠧࡶࡴ࡯ࠫໄ"))
		bTDaxXYSseoFCI6cQ4f58vqr3dPNp = Y8Y6b7aLSUKjdE1Ae()
		if oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨࡪࡷࡸࡵ࠭໅") not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = C83UXWf15zdwLA0+ELbNB92cOh5dqtpVmi40kY
		if l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨໆ") in ELbNB92cOh5dqtpVmi40kY:
			headers = {yA5z6LIXBlo41PRVMY87wOisFp(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ໇"):bTDaxXYSseoFCI6cQ4f58vqr3dPNp,SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶ່ࠬ"):C83UXWf15zdwLA0}
			zs8Od4FR9Iqx,UZd6pDilGMOjfAX07EWNrk2nw3 = BXEJoygQHA8RZ(ELbNB92cOh5dqtpVmi40kY,headers)
			XmkyiLasFhMzCGYQu8rA += UZd6pDilGMOjfAX07EWNrk2nw3
			Ymlyk3rMKj512tacPEASXW09f8biU += zs8Od4FR9Iqx
		else:
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬࢂࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀ້ࠫ")+bTDaxXYSseoFCI6cQ4f58vqr3dPNp+yA5z6LIXBlo41PRVMY87wOisFp(u"࠭ࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾໊ࠩ")+C83UXWf15zdwLA0
			XmkyiLasFhMzCGYQu8rA.append(ELbNB92cOh5dqtpVmi40kY)
			Ymlyk3rMKj512tacPEASXW09f8biU.append(title)
	svejmhZS0t24bAiYuzk,HHSO6Q4KI0hlPxYpNuXRkWCmjEgA,uuIjMn1YTf687WlRcOmhq4G23H = oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧࠨ໋"),[],[]
	if XmkyiLasFhMzCGYQu8rA: svejmhZS0t24bAiYuzk,HHSO6Q4KI0hlPxYpNuXRkWCmjEgA,uuIjMn1YTf687WlRcOmhq4G23H = g4g6bfkPtVGU5lIM3(u"ࠨࠩ໌"),Ymlyk3rMKj512tacPEASXW09f8biU,XmkyiLasFhMzCGYQu8rA
	else:
		if oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠩ࠿ࠫໍ") not in BBlXpmUyhFDwNtCVAHoE and len(BBlXpmUyhFDwNtCVAHoE)<FnBiAjthS8MkXs67W(u"࠴࠴࠵ე") and BBlXpmUyhFDwNtCVAHoE: svejmhZS0t24bAiYuzk = BBlXpmUyhFDwNtCVAHoE
		else:
			msg = GGvHJKP9LUxEk10Fw.findall(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠪࡀࡩ࡯ࡶࠡࡵࡷࡽࡱ࡫࠽ࠣ࠰࠭ࡃࠧࡄࠨࡇ࡫࡯ࡩ࠳࠰࠿ࠪ࠾ࠪ໎"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
			if not msg: msg = GGvHJKP9LUxEk10Fw.findall(kEhAHvti6Vnsfx(u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡹࡴࡤࡼࡩࡥࡧࡲࡣࡸࡺࡵࡣࡡࡷࡼࡹࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ໏"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
			if not msg: msg = GGvHJKP9LUxEk10Fw.findall(wRxoKs10Syj7V4edYhtP(u"ࠬࡂࡨ࠳ࡀࠫࡗࡴࡸࡲࡺ࠰࠭ࡃ࠮ࡂࠧ໐"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
			if msg: svejmhZS0t24bAiYuzk = msg[bUdr5Hahw6sY8xJ(u"࠴ვ")]
	return svejmhZS0t24bAiYuzk,HHSO6Q4KI0hlPxYpNuXRkWCmjEgA,uuIjMn1YTf687WlRcOmhq4G23H
def BB8QxXwpUcNlHFq1y(DDzlgSc5ftYM,url):
	global Ba6r5xTjeV8F91pgSK0fNvslkbXUz
	url = url.strip(wRxoKs10Syj7V4edYhtP(u"࠭࠯ࠨ໑"))
	PhzBCR0GOkLx4nfuQ,vpWXJDC4lTByaqcn56OFwUmieV = SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠧࠨ໒"),{}
	headers = {pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ໓"):Y8Y6b7aLSUKjdE1Ae()}
	headers[E6MIKdpBomef(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ໔")] = RfKuIXwPAiWtmyF(url,p72fnFtcPix5UKwr9YNzW(u"ࠪࡹࡷࡲࠧ໕"))
	headers[wRxoKs10Syj7V4edYhtP(u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡑࡧ࡮ࡨࡷࡤ࡫ࡪ࠭໖")] = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠬ࡫࡮࠮ࡗࡖ࠰ࡪࡴ࠻ࡲ࠿࠳࠲࠾࠭໗")
	headers[lc0dpSmwoPDjLnk(u"࠭ࡓࡦࡥ࠰ࡊࡪࡺࡣࡩ࠯ࡇࡩࡸࡺࠧ໘")] = Cu1704YofAbr3QTm(u"ࠧࡪࡨࡵࡥࡲ࡫ࠧ໙")
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠨࡉࡈࡘࠬ໚"),url,l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠩࠪ໛"),headers,Me28A1sBLNIgUp5YCDyvT(u"ࠪࠫໜ"),bUdr5Hahw6sY8xJ(u"ࡆࡢ࡮ࡶࡩᅲ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭ໝ"))
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	oqLRzBWu7h6vrekUDlQdYs = WbTGMHnDysdYZ2lFA.code
	if not isinstance(BBlXpmUyhFDwNtCVAHoE,str): BBlXpmUyhFDwNtCVAHoE = BBlXpmUyhFDwNtCVAHoE.decode(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬࡻࡴࡧ࠺ࠪໞ"),E6MIKdpBomef(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ໟ"))
	if oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠪࡳ࠰ࡦ࠲ࡣ࠭࡭࠯ࡩ࠱࠭໠") in BBlXpmUyhFDwNtCVAHoE:
		xbjuhmSNgZ15dta0vLKFiEG4 = GGvHJKP9LUxEk10Fw.findall(UTelCo0ihE1d5R(u"ࠨࠪࡨࡺࡦࡲ࡜ࠩࡨࡸࡲࡨࡺࡩࡰࡰ࡟ࠬࡵ࠲ࡡ࠭ࡥ࠯࡯࠱࡫ࠬ࡜ࡦࡵࡡ࠳࠰࠿ࠪ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ໡"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if xbjuhmSNgZ15dta0vLKFiEG4:
			try: PhzBCR0GOkLx4nfuQ = p0utbN8Uw2yC3qlm96KnxeTVPAIS(xbjuhmSNgZ15dta0vLKFiEG4[SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠵ზ")])
			except: PhzBCR0GOkLx4nfuQ = UTelCo0ihE1d5R(u"ࠩࠪ໢")
	X3in5vNhqwWEG2TafmVCrFbSYDxjoK = BBlXpmUyhFDwNtCVAHoE+PhzBCR0GOkLx4nfuQ
	if kEhAHvti6Vnsfx(u"ࠪࠦ࡮ࡪ࠲ࠣࠩ໣") in X3in5vNhqwWEG2TafmVCrFbSYDxjoK or p72fnFtcPix5UKwr9YNzW(u"ࠫࠧ࡯ࡤࠣࠩ໤") in X3in5vNhqwWEG2TafmVCrFbSYDxjoK:
		vhoZ9LdCzJKOMBce4xrWtwXqA = url.split(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬ࠵ࠧ໥"))[oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"࠹თ")].replace(hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭ࡥ࡮ࡤࡨࡨ࠲࠭໦"),dshJSmRqeiP9nap2(u"ࠧࠨ໧")).replace(sTcr7iDp5eFt4RoLMhuwq1A(u"ࠨ࠰࡫ࡸࡲࡲࠧ໨"),xW2Arao7YVOemw(u"ࠩࠪ໩"))
		if iRoLg2m47tnDATBHGCSPNyx(u"ࠪࠦ࡮ࡪ࠲ࠣࠩ໪") in X3in5vNhqwWEG2TafmVCrFbSYDxjoK: vpWXJDC4lTByaqcn56OFwUmieV = {g4g6bfkPtVGU5lIM3(u"ࠫ࡮ࡪ࠲ࠨ໫"):vhoZ9LdCzJKOMBce4xrWtwXqA,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬࡵࡰࠨ໬"):XzrqbGDIy54juixkMA(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠩ໭")}
		elif oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧࠣ࡫ࡧࠦࠬ໮") in X3in5vNhqwWEG2TafmVCrFbSYDxjoK: vpWXJDC4lTByaqcn56OFwUmieV = {p72fnFtcPix5UKwr9YNzW(u"ࠨ࡫ࡧࠫ໯"):vhoZ9LdCzJKOMBce4xrWtwXqA,fprnld4CZo(u"ࠩࡲࡴࠬ໰"):E6MIKdpBomef(u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ࠷࠭໱")}
		BBYvCiQGe8RdpyAagfS72mZclxb5 = headers.copy()
		BBYvCiQGe8RdpyAagfS72mZclxb5[SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ໲")] = SO94xq1RAkMm2uF(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ໳")
		QQTDOLdNUAzYbfl1vXrM8mB = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,bUdr5Hahw6sY8xJ(u"࠭ࡐࡐࡕࡗࠫ໴"),url,vpWXJDC4lTByaqcn56OFwUmieV,BBYvCiQGe8RdpyAagfS72mZclxb5,l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧࠨ໵"),G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࡇࡣ࡯ࡷࡪᅳ"),SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝࡙ࡈࡂࡔࡌࡒࡌ࠳࠲࡯ࡦࠪ໶"))
		X3in5vNhqwWEG2TafmVCrFbSYDxjoK = QQTDOLdNUAzYbfl1vXrM8mB.content
	UJvSGKNhkXmQxs7LzF1D,Oa5egNxhLk9myYfA4XUFl6,sDNR1Vr7E8X4h9BYOcgwWoLb = ZHj03wK2Tq(url,X3in5vNhqwWEG2TafmVCrFbSYDxjoK)
	Ba6r5xTjeV8F91pgSK0fNvslkbXUz[DDzlgSc5ftYM] = UJvSGKNhkXmQxs7LzF1D,Oa5egNxhLk9myYfA4XUFl6,sDNR1Vr7E8X4h9BYOcgwWoLb,oqLRzBWu7h6vrekUDlQdYs
	return
Ba6r5xTjeV8F91pgSK0fNvslkbXUz,IHnXZR4FOCWvVerc69fTYEhMaJwl2 = {},UTelCo0ihE1d5R(u"࠰ი")
def XMmpP948RLndfWUeBwIJcTFCGv(url):
	global Ba6r5xTjeV8F91pgSK0fNvslkbXUz,IHnXZR4FOCWvVerc69fTYEhMaJwl2
	gI487voLsArVqW6Ffp,threads = [],[]
	IHnXZR4FOCWvVerc69fTYEhMaJwl2 += yA5z6LIXBlo41PRVMY87wOisFp(u"࠲࠲࠳კ")
	POesUF9hB46SpIVioz = IHnXZR4FOCWvVerc69fTYEhMaJwl2
	gI487voLsArVqW6Ffp.append([sTcr7iDp5eFt4RoLMhuwq1A(u"࠳ლ"),url])
	Ba6r5xTjeV8F91pgSK0fNvslkbXUz[POesUF9hB46SpIVioz+xW2Arao7YVOemw(u"࠴მ")] = [None,None,None,None]
	zgN6CGruX2s789hVZBtS1c = dM9DZS0pkxbqaf7W.Thread(target=BB8QxXwpUcNlHFq1y,args=(POesUF9hB46SpIVioz+zqdvcbP5L8BHh(u"࠵ნ"),url))
	zgN6CGruX2s789hVZBtS1c.start()
	zgN6CGruX2s789hVZBtS1c.join(Cu1704YofAbr3QTm(u"࠶࠶ო"))
	if not Ba6r5xTjeV8F91pgSK0fNvslkbXUz[POesUF9hB46SpIVioz+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠷პ")][p72fnFtcPix5UKwr9YNzW(u"࠲ჟ")]:
		dR2vHyAtl8pJN1 = url.replace(YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ໷"),UTelCo0ihE1d5R(u"ࠪ࠳ࠬ໸"))
		Z0HoXM261lLgxBzjUK = GGvHJKP9LUxEk10Fw.findall(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠫࡣ࠮࠮ࠫࡁ࠽࠳࠴࠴ࠪࡀࠫ࠲ࠬ࠳࠰࠿ࠪ࠱ࠫ࠲࠯ࡅࠩࠥࠩ໹"),dR2vHyAtl8pJN1+SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠬ࠵ࠧ໺"),GGvHJKP9LUxEk10Fw.DOTALL)
		start,ggIOqZDkNrVS,end = Z0HoXM261lLgxBzjUK[LiRcTVUWuth70DmPy(u"࠱რ")]
		end = end.strip(iUeoLOsbHqP(u"࠭࠯ࠨ໻"))
		DDsOqVRZbyfMlxL1mEPU9knh = len(ggIOqZDkNrVS)<SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠶ს") or ggIOqZDkNrVS in [G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠧࡧ࡫࡯ࡩࠬ໼"),g4g6bfkPtVGU5lIM3(u"ࠨࡸ࡬ࡨࡪࡵࠧ໽"),pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠩࡹ࡭ࡩ࡫࡯ࡦ࡯ࡥࡩࡩ࠭໾"),Me28A1sBLNIgUp5YCDyvT(u"ࠪࡥ࡯ࡧࡸࠨ໿"),fprnld4CZo(u"ࠫ࡮࡬ࡲࡢ࡯ࡨࠫༀ"),lc0dpSmwoPDjLnk(u"ࠬࡳࡩࡳࡴࡲࡶࠬ༁")]
		if not DDsOqVRZbyfMlxL1mEPU9knh: gI487voLsArVqW6Ffp.append([SO94xq1RAkMm2uF(u"࠵ტ"),start+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ༂")+ggIOqZDkNrVS+oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧ࠰ࠩ༃")+end])
		if end: gI487voLsArVqW6Ffp.append([zqdvcbP5L8BHh(u"࠷უ"),start+bUdr5Hahw6sY8xJ(u"ࠨ࠱ࠪ༄")+ggIOqZDkNrVS+iUeoLOsbHqP(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ༅")+end])
		if l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪ࠲࡭ࡺ࡭࡭ࠩ༆") in ggIOqZDkNrVS:
			E1WrtLP9XHMo5Tyj3K8S0uQmUd = ggIOqZDkNrVS.replace(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫ࠳࡮ࡴ࡮࡮ࠪ༇"),kEhAHvti6Vnsfx(u"ࠬ࠭༈"))
			gI487voLsArVqW6Ffp.append([hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠹ფ"),start+hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠭࠯ࠨ༉")+E1WrtLP9XHMo5Tyj3K8S0uQmUd+sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧ࠰ࠩ༊")+end])
			gI487voLsArVqW6Ffp.append([UTelCo0ihE1d5R(u"࠻ქ"),start+oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ་")+E1WrtLP9XHMo5Tyj3K8S0uQmUd+iUeoLOsbHqP(u"ࠩ࠲ࠫ༌")+end])
			if end: gI487voLsArVqW6Ffp.append([Cu1704YofAbr3QTm(u"࠶ღ"),start+XzrqbGDIy54juixkMA(u"ࠪ࠳ࠬ།")+E1WrtLP9XHMo5Tyj3K8S0uQmUd+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬ༎")+end])
		elif hBvsQ7oCkKUdwjx58ml3EN(u"ࠬ࠴ࡨࡵ࡯࡯ࠫ༏") in end:
			K4KpuaJcysZ5 = end.replace(iRoLg2m47tnDATBHGCSPNyx(u"࠭࠮ࡩࡶࡰࡰࠬ༐"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࠨ༑"))
			gI487voLsArVqW6Ffp.append([LiRcTVUWuth70DmPy(u"࠸ყ"),start+g4g6bfkPtVGU5lIM3(u"ࠨ࠱ࠪ༒")+ggIOqZDkNrVS+hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠩ࠲ࠫ༓")+K4KpuaJcysZ5])
			if not DDsOqVRZbyfMlxL1mEPU9knh: gI487voLsArVqW6Ffp.append([E6MIKdpBomef(u"࠺შ"),start+G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫ༔")+ggIOqZDkNrVS+zqdvcbP5L8BHh(u"ࠫ࠴࠭༕")+K4KpuaJcysZ5])
			gI487voLsArVqW6Ffp.append([xW2Arao7YVOemw(u"࠼ჩ"),start+l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠬ࠵ࠧ༖")+ggIOqZDkNrVS+dshJSmRqeiP9nap2(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ༗")+K4KpuaJcysZ5])
		else:
			if not DDsOqVRZbyfMlxL1mEPU9knh: gI487voLsArVqW6Ffp.append([fprnld4CZo(u"࠵࠵ც"),start+iUeoLOsbHqP(u"ࠧ࠰༘ࠩ")+ggIOqZDkNrVS+yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨ࠰࡫ࡸࡲࡲ༙ࠧ")])
			if not DDsOqVRZbyfMlxL1mEPU9knh: gI487voLsArVqW6Ffp.append([g4g6bfkPtVGU5lIM3(u"࠶࠷ძ"),start+lc0dpSmwoPDjLnk(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ༚")+ggIOqZDkNrVS+dshJSmRqeiP9nap2(u"ࠪ࠲࡭ࡺ࡭࡭ࠩ༛")])
			if end: gI487voLsArVqW6Ffp.append([yA5z6LIXBlo41PRVMY87wOisFp(u"࠷࠲წ"),start+iRoLg2m47tnDATBHGCSPNyx(u"ࠫ࠴࠭༜")+ggIOqZDkNrVS+FvNyZqaLKw(u"ࠬ࠵ࠧ༝")+end+kEhAHvti6Vnsfx(u"࠭࠮ࡩࡶࡰࡰࠬ༞")])
			if end: gI487voLsArVqW6Ffp.append([p72fnFtcPix5UKwr9YNzW(u"࠱࠴ჭ"),start+LiRcTVUWuth70DmPy(u"ࠧ࠰ࠩ༟")+ggIOqZDkNrVS+kEhAHvti6Vnsfx(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ༠")+end+sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩ࠱࡬ࡹࡳ࡬ࠨ༡")])
		if DDsOqVRZbyfMlxL1mEPU9knh and end:
			end = end.replace(wRxoKs10Syj7V4edYhtP(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫ༢"),p72fnFtcPix5UKwr9YNzW(u"ࠫ࠴࠭༣"))
			gI487voLsArVqW6Ffp.append([bUdr5Hahw6sY8xJ(u"࠲࠶ხ"),start+iUeoLOsbHqP(u"ࠬ࠵ࠧ༤")+end])
			gI487voLsArVqW6Ffp.append([YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠳࠸ჯ"),start+LiRcTVUWuth70DmPy(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ༥")+end])
			if xW2Arao7YVOemw(u"ࠧ࠯ࡪࡷࡱࡱ࠭༦") in end:
				K4KpuaJcysZ5 = end.replace(lc0dpSmwoPDjLnk(u"ࠨ࠰࡫ࡸࡲࡲࠧ༧"),wRxoKs10Syj7V4edYhtP(u"ࠩࠪ༨"))
				gI487voLsArVqW6Ffp.append([iRoLg2m47tnDATBHGCSPNyx(u"࠴࠺ჰ"),start+hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࠪ࠳ࠬ༩")+K4KpuaJcysZ5])
				gI487voLsArVqW6Ffp.append([iRoLg2m47tnDATBHGCSPNyx(u"࠵࠼ჱ"),start+wRxoKs10Syj7V4edYhtP(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬ༪")+K4KpuaJcysZ5])
			else:
				gI487voLsArVqW6Ffp.append([YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠶࠾ჲ"),start+FvNyZqaLKw(u"ࠬ࠵ࠧ༫")+end+dshJSmRqeiP9nap2(u"࠭࠮ࡩࡶࡰࡰࠬ༬")])
				gI487voLsArVqW6Ffp.append([hBvsQ7oCkKUdwjx58ml3EN(u"࠷࠹ჳ"),start+wRxoKs10Syj7V4edYhtP(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ༭")+end+YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠨ࠰࡫ࡸࡲࡲࠧ༮")])
		VTexFJvIErXytCh2HS3df = []
		for jayps2bqRW6CEVl9IY8LdB5e,ELbNB92cOh5dqtpVmi40kY in gI487voLsArVqW6Ffp[FnBiAjthS8MkXs67W(u"࠱ჴ"):]:
			Ba6r5xTjeV8F91pgSK0fNvslkbXUz[POesUF9hB46SpIVioz+jayps2bqRW6CEVl9IY8LdB5e] = [None,None,None,None]
			PSbke6pamBs7 = dM9DZS0pkxbqaf7W.Thread(target=BB8QxXwpUcNlHFq1y,args=(POesUF9hB46SpIVioz+jayps2bqRW6CEVl9IY8LdB5e,ELbNB92cOh5dqtpVmi40kY))
			PSbke6pamBs7.start()
			VTexFJvIErXytCh2HS3df.append(PSbke6pamBs7)
			MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(hBvsQ7oCkKUdwjx58ml3EN(u"࠱࠰࠺࠹ჵ"))
		for PSbke6pamBs7 in VTexFJvIErXytCh2HS3df: PSbke6pamBs7.join(pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠳࠳ჶ"))
	svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ = yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩࠪ༯"),[],[]
	lmtqPFcsRx2f1ZdQK4ynABL = []
	for jayps2bqRW6CEVl9IY8LdB5e,ELbNB92cOh5dqtpVmi40kY in gI487voLsArVqW6Ffp:
		ITKmgGWBtXOcSf0DPZ,BtI5cGOUZk,PsUQu1lnv7FrDJRoYA9B24hWLKc,vJ9E6xR1a7nYrjZFcUDoieB = Ba6r5xTjeV8F91pgSK0fNvslkbXUz[POesUF9hB46SpIVioz+jayps2bqRW6CEVl9IY8LdB5e]
		if not zzvBg3ShiamAZ and PsUQu1lnv7FrDJRoYA9B24hWLKc: eyUmvNFiYsE,zzvBg3ShiamAZ = BtI5cGOUZk,PsUQu1lnv7FrDJRoYA9B24hWLKc
		if not svejmhZS0t24bAiYuzk and ITKmgGWBtXOcSf0DPZ: svejmhZS0t24bAiYuzk = ITKmgGWBtXOcSf0DPZ
		if vJ9E6xR1a7nYrjZFcUDoieB: lmtqPFcsRx2f1ZdQK4ynABL.append(vJ9E6xR1a7nYrjZFcUDoieB)
	lmtqPFcsRx2f1ZdQK4ynABL = list(set(lmtqPFcsRx2f1ZdQK4ynABL))
	if not svejmhZS0t24bAiYuzk and len(lmtqPFcsRx2f1ZdQK4ynABL)==fprnld4CZo(u"࠴ჷ"):
		oqLRzBWu7h6vrekUDlQdYs = lmtqPFcsRx2f1ZdQK4ynABL[SO94xq1RAkMm2uF(u"࠴ჸ")]
		if oqLRzBWu7h6vrekUDlQdYs!=YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠷࠶࠰ჹ"):
			if oqLRzBWu7h6vrekUDlQdYs<zqdvcbP5L8BHh(u"࠶ჺ"): svejmhZS0t24bAiYuzk = Me28A1sBLNIgUp5YCDyvT(u"࡚ࠪ࡮ࡪࡥࡰࠢࡳࡥ࡬࡫࠯ࡴࡧࡵࡺࡪࡸࠠࡪࡵࠣࡲࡴࡺࠠࡢࡥࡦࡩࡸࡹࡩࡣ࡮ࡨࠫ༰")
			else:
				svejmhZS0t24bAiYuzk = sTcr7iDp5eFt4RoLMhuwq1A(u"ࠫࡍ࡚ࡔࡑࠢࡈࡶࡷࡵࡲ࠻ࠢࠪ༱")+str(oqLRzBWu7h6vrekUDlQdYs)
				if u4ChFMGf6K93tbDjJ12zi0YQsAHyP: import http.client as I80waz73NF5MYuo
				else: import httplib as I80waz73NF5MYuo
				try: svejmhZS0t24bAiYuzk += sTcr7iDp5eFt4RoLMhuwq1A(u"ࠬࠦࠨࠡࠩ༲")+I80waz73NF5MYuo.responses[oqLRzBWu7h6vrekUDlQdYs]+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭ࠠࠪࠩ༳")
				except: pass
	MQbODJoPV2w8TEAg4zXZdjLxSW.sleep(g4g6bfkPtVGU5lIM3(u"࠱჻"))
	return svejmhZS0t24bAiYuzk,eyUmvNFiYsE,zzvBg3ShiamAZ
class vv5XnctQWb(zz2LJUB9kjnZqAeH.WindowDialog):
	def __init__(J4JbrLDI1aWiBHX8hYuZcFCq6VsG, *args, **i5tUsoW8aVxqFNlRn97Q1):
		WY8C0hakPDi1F27q = WpgZTyqoMAPhwGiXF.path.join(bdmxngE9YGIeQ, G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠧࡳࡧࡶࡳࡺࡸࡣࡦࡵࠪ༴"), yA5z6LIXBlo41PRVMY87wOisFp(u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠶༵ࠬ"), sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡤࡪ࠲ࡵࡴࡧࠨ༶"))
		M6Og0qZCpo = WpgZTyqoMAPhwGiXF.path.join(bdmxngE9YGIeQ, SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠪࡶࡪࡹ࡯ࡶࡴࡦࡩࡸ༷࠭"), kEhAHvti6Vnsfx(u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠲ࠨ༸"), lc0dpSmwoPDjLnk(u"ࠬࡹࡥ࡭ࡧࡦࡸࡪࡪ࠮ࡱࡰࡪ༹ࠫ"))
		ff8uYjDv5LVs7BFWQliTe94 = WpgZTyqoMAPhwGiXF.path.join(bdmxngE9YGIeQ, SO94xq1RAkMm2uF(u"࠭ࡲࡦࡵࡲࡹࡷࡩࡥࡴࠩ༺"), l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠵ࠫ༻"), xW2Arao7YVOemw(u"ࠨࡤࡸࡸࡹࡵ࡮ࡧࡱ࠱ࡴࡳ࡭ࠧ༼"))
		nAuopDEz3BW8HxQTwrZU1MmKsf = WpgZTyqoMAPhwGiXF.path.join(bdmxngE9YGIeQ, yA5z6LIXBlo41PRVMY87wOisFp(u"ࠩࡵࡩࡸࡵࡵࡳࡥࡨࡷࠬ༽"), l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠸ࠧ༾"), fprnld4CZo(u"ࠫࡧࡻࡴࡵࡱࡱࡲ࡫࠴ࡰ࡯ࡩࠪ༿"))
		UWibZkIEaKPQgX0 = WpgZTyqoMAPhwGiXF.path.join(bdmxngE9YGIeQ, yA5z6LIXBlo41PRVMY87wOisFp(u"ࠬࡸࡥࡴࡱࡸࡶࡨ࡫ࡳࠨཀ"), XzrqbGDIy54juixkMA(u"࠭ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠴ࠪཁ"), kEhAHvti6Vnsfx(u"ࠧࡣࡷࡷࡸࡴࡴࡢࡨ࠰ࡳࡲ࡬࠭ག"))
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.cancelled = p72fnFtcPix5UKwr9YNzW(u"ࡈࡤࡰࡸ࡫ᅴ")
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chk = [S4SOKF2QbBhjCd3RrVMuHIzE(u"࠲ჽ")] * E6MIKdpBomef(u"࠺ჼ")
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chkbutton = [XzrqbGDIy54juixkMA(u"࠴ჿ")] * dshJSmRqeiP9nap2(u"࠼ჾ")
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chkstate = [hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"ࡉࡥࡱࡹࡥᅵ")] * hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠾ᄀ")
		JkqeBgNMAG0uIs31tKRTnPy6, i2BmVbgPZpvA7M9Qn, p8Dswb4vY9zuSG, PpmsLyCOSQx9ZUl6nt712bWco = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠲࠶࠲ᄂ"), XzrqbGDIy54juixkMA(u"࠶ᄁ"), iRoLg2m47tnDATBHGCSPNyx(u"࠸࠲࠳ᄃ"), hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࠹࠹࠴ᄄ")
		AlOTJSGP0QrNXh2uWDFEcZfszp = JkqeBgNMAG0uIs31tKRTnPy6+p8Dswb4vY9zuSG//Cu1704YofAbr3QTm(u"࠵ᄅ")
		yWchHjb4Ntd8pU5Y9z, X5QybkEPYMaiBnor0qLNft, OPB5pwVcXtxi8FK9NeRfdljYgJnWy, MDHdKq7mY6J0Qev = kEhAHvti6Vnsfx(u"࠸࠻࠵ᄇ"), SO94xq1RAkMm2uF(u"࠵࠷࠶ᄆ"), dshJSmRqeiP9nap2(u"࠻࠰࠱ᄈ"), dshJSmRqeiP9nap2(u"࠻࠰࠱ᄈ")
		bR0Hca9SdeuT8FkIfvnMiNP1E6rKt = yWchHjb4Ntd8pU5Y9z+OPB5pwVcXtxi8FK9NeRfdljYgJnWy//xW2Arao7YVOemw(u"࠲ᄉ")
		r2y1XaivMLqF6R3pxdg, B3zqtH6Nv0nQk8U, D09WF6UCsPNrybjawLB4xGnX, qi2We0tnLaA = G5DeRbUpFj8E9OtJLvlo2fWmZC(u"࠳࠳࠴ᄋ"), wRxoKs10Syj7V4edYhtP(u"࠹࠹࠺ᄌ"), QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠲࠷࠳ᄊ"), YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠹࠵ᄍ")
		c4hpEF9CyoQKva0JWzwm7 = AlOTJSGP0QrNXh2uWDFEcZfszp-D09WF6UCsPNrybjawLB4xGnX-r2y1XaivMLqF6R3pxdg//E6MIKdpBomef(u"࠷ᄎ")
		E1EiVHTNwbWgelq9p = AlOTJSGP0QrNXh2uWDFEcZfszp+r2y1XaivMLqF6R3pxdg//zqdvcbP5L8BHh(u"࠸ᄏ")
		NKfRM9v6dYc, E067ElkLBNSQeJoqVrhTcdGRFwA9, m87ZLDAueqiHvnXFkQEj4dt2y, AtQZLfNmP35 = S4SOKF2QbBhjCd3RrVMuHIzE(u"࠳࠶࠷ᄐ"), lc0dpSmwoPDjLnk(u"࠴࠲ᄑ"), p72fnFtcPix5UKwr9YNzW(u"࠸࠴࠵ᄓ"), dshJSmRqeiP9nap2(u"࠷࠳ᄒ")
		O5Spd2veN83r9nuoRsqyl, tsMXOV2IPiov1FLxb7, ygn0lrwMsdW7YpCJ4U, LL4BnR61lisFDbay = S4SOKF2QbBhjCd3RrVMuHIzE(u"࠷࠺࠻ᄔ"), zqdvcbP5L8BHh(u"࠷࠱ᄗ"), lc0dpSmwoPDjLnk(u"࠻࠰࠱ᄖ"), fprnld4CZo(u"࠺࠶ᄕ")
		HZongSdE6OubvwFR2Uehx9XT = g4g6bfkPtVGU5lIM3(u"࠱࠰࠼ᄘ")
		JkqeBgNMAG0uIs31tKRTnPy6, i2BmVbgPZpvA7M9Qn, p8Dswb4vY9zuSG, PpmsLyCOSQx9ZUl6nt712bWco = int(JkqeBgNMAG0uIs31tKRTnPy6*HZongSdE6OubvwFR2Uehx9XT), int(i2BmVbgPZpvA7M9Qn*HZongSdE6OubvwFR2Uehx9XT), int(p8Dswb4vY9zuSG*HZongSdE6OubvwFR2Uehx9XT), int(PpmsLyCOSQx9ZUl6nt712bWco*HZongSdE6OubvwFR2Uehx9XT)
		yWchHjb4Ntd8pU5Y9z, X5QybkEPYMaiBnor0qLNft, OPB5pwVcXtxi8FK9NeRfdljYgJnWy, MDHdKq7mY6J0Qev = int(yWchHjb4Ntd8pU5Y9z*HZongSdE6OubvwFR2Uehx9XT), int(X5QybkEPYMaiBnor0qLNft*HZongSdE6OubvwFR2Uehx9XT), int(OPB5pwVcXtxi8FK9NeRfdljYgJnWy*HZongSdE6OubvwFR2Uehx9XT), int(MDHdKq7mY6J0Qev*HZongSdE6OubvwFR2Uehx9XT)
		c4hpEF9CyoQKva0JWzwm7, LLxgZhP0O9FAMwvpWn2iuGCSt, b3iLK1p5l4V7o8fDtuHxYzZgsIC0, eBuZTOF4A90hmaHPDpsVURC = int(c4hpEF9CyoQKva0JWzwm7*HZongSdE6OubvwFR2Uehx9XT), int(B3zqtH6Nv0nQk8U*HZongSdE6OubvwFR2Uehx9XT), int(D09WF6UCsPNrybjawLB4xGnX*HZongSdE6OubvwFR2Uehx9XT), int(qi2We0tnLaA*HZongSdE6OubvwFR2Uehx9XT)
		E1EiVHTNwbWgelq9p, EkySYo6CIP8u70wtLpUn45el, x7UeOMpKjGg1BNEAhkiZHCcX0s, U0U2k7MJpbAXRueZWgOn9zV = int(E1EiVHTNwbWgelq9p*HZongSdE6OubvwFR2Uehx9XT), int(B3zqtH6Nv0nQk8U*HZongSdE6OubvwFR2Uehx9XT), int(D09WF6UCsPNrybjawLB4xGnX*HZongSdE6OubvwFR2Uehx9XT), int(qi2We0tnLaA*HZongSdE6OubvwFR2Uehx9XT)
		NKfRM9v6dYc, E067ElkLBNSQeJoqVrhTcdGRFwA9, m87ZLDAueqiHvnXFkQEj4dt2y, AtQZLfNmP35 = int(NKfRM9v6dYc*HZongSdE6OubvwFR2Uehx9XT), int(E067ElkLBNSQeJoqVrhTcdGRFwA9*HZongSdE6OubvwFR2Uehx9XT), int(m87ZLDAueqiHvnXFkQEj4dt2y*HZongSdE6OubvwFR2Uehx9XT), int(AtQZLfNmP35*HZongSdE6OubvwFR2Uehx9XT)
		O5Spd2veN83r9nuoRsqyl, tsMXOV2IPiov1FLxb7, ygn0lrwMsdW7YpCJ4U, LL4BnR61lisFDbay = int(O5Spd2veN83r9nuoRsqyl*HZongSdE6OubvwFR2Uehx9XT), int(tsMXOV2IPiov1FLxb7*HZongSdE6OubvwFR2Uehx9XT), int(ygn0lrwMsdW7YpCJ4U*HZongSdE6OubvwFR2Uehx9XT), int(LL4BnR61lisFDbay*HZongSdE6OubvwFR2Uehx9XT)
		KvuYqm4dO1HltPE7R0UA6a9pnVwD = zz2LJUB9kjnZqAeH.ControlImage(JkqeBgNMAG0uIs31tKRTnPy6, i2BmVbgPZpvA7M9Qn, p8Dswb4vY9zuSG, PpmsLyCOSQx9ZUl6nt712bWco, WY8C0hakPDi1F27q)
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.addControl(KvuYqm4dO1HltPE7R0UA6a9pnVwD)
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.iteration = i5tUsoW8aVxqFNlRn97Q1.get(FvNyZqaLKw(u"ࠨ࡫ࡷࡩࡷࡧࡴࡪࡱࡱࠫགྷ"))
		hC0a8fvquHNeIc = SO94xq1RAkMm2uF(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬང")+FvNyZqaLKw(u"ࠪๅา฻ࠠฤ่สࠤส์ำศ่ࠣ์ู้สࠡำ๋ฬํะࠠࠡࠢࠣࠤࠥࠦࠠࠡࠩཅ")+Me28A1sBLNIgUp5YCDyvT(u"ࠫฬ๊ๅฮษ๋่ฮࠦัใ็ࠣࠤࠬཆ")+str(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.iteration)+Me28A1sBLNIgUp5YCDyvT(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧཇ")
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.strActionInfo = zz2LJUB9kjnZqAeH.ControlLabel(NKfRM9v6dYc, E067ElkLBNSQeJoqVrhTcdGRFwA9, m87ZLDAueqiHvnXFkQEj4dt2y, AtQZLfNmP35, hC0a8fvquHNeIc, FvNyZqaLKw(u"࠭ࡦࡰࡰࡷ࠵࠸࠭཈"))
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.addControl(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.strActionInfo)
		VFqpJjRySZvgi = zz2LJUB9kjnZqAeH.ControlImage(yWchHjb4Ntd8pU5Y9z, X5QybkEPYMaiBnor0qLNft, OPB5pwVcXtxi8FK9NeRfdljYgJnWy, MDHdKq7mY6J0Qev, i5tUsoW8aVxqFNlRn97Q1.get(hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࡤࡣࡳࡸࡨ࡮ࡡࠨཉ")))
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.addControl(VFqpJjRySZvgi)
		YUG1V8mBsoAvZSid6nx0gpPNIHh = oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫཊ")+i5tUsoW8aVxqFNlRn97Q1.get(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠩࡰࡷ࡬࠭ཋ"))+pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬཌ")
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.strActionInfo = zz2LJUB9kjnZqAeH.ControlLabel(O5Spd2veN83r9nuoRsqyl, tsMXOV2IPiov1FLxb7, ygn0lrwMsdW7YpCJ4U, LL4BnR61lisFDbay, YUG1V8mBsoAvZSid6nx0gpPNIHh, Cu1704YofAbr3QTm(u"ࠫ࡫ࡵ࡮ࡵ࠳࠶ࠫཌྷ"))
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.addControl(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.strActionInfo)
		text = xW2Arao7YVOemw(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨཎ")+xW2Arao7YVOemw(u"࠭ฮา๊ฯࠫཏ")+FvNyZqaLKw(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩཐ")
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.cancelbutton = zz2LJUB9kjnZqAeH.ControlButton(c4hpEF9CyoQKva0JWzwm7, LLxgZhP0O9FAMwvpWn2iuGCSt, b3iLK1p5l4V7o8fDtuHxYzZgsIC0, eBuZTOF4A90hmaHPDpsVURC, text, focusTexture=UWibZkIEaKPQgX0, noFocusTexture=ff8uYjDv5LVs7BFWQliTe94, alignment=dshJSmRqeiP9nap2(u"࠴ᄙ"))
		text = Cu1704YofAbr3QTm(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫད")+hBvsQ7oCkKUdwjx58ml3EN(u"ࠩสืฯ๋ัศำࠪདྷ")+QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬན")
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.okbutton = zz2LJUB9kjnZqAeH.ControlButton(E1EiVHTNwbWgelq9p, EkySYo6CIP8u70wtLpUn45el, x7UeOMpKjGg1BNEAhkiZHCcX0s, U0U2k7MJpbAXRueZWgOn9zV, text, focusTexture=UWibZkIEaKPQgX0, noFocusTexture=ff8uYjDv5LVs7BFWQliTe94, alignment=iRoLg2m47tnDATBHGCSPNyx(u"࠵ᄚ"))
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.addControl(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.okbutton)
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.addControl(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.cancelbutton)
		wwLyTRF0kUWmgeZ6iz, HZQDUvJwK4x15pC0TgXo = MDHdKq7mY6J0Qev//p72fnFtcPix5UKwr9YNzW(u"࠷ᄛ"), OPB5pwVcXtxi8FK9NeRfdljYgJnWy//p72fnFtcPix5UKwr9YNzW(u"࠷ᄛ")
		for umP72LtwzUTWHFAlJVyheEp5 in range(XzrqbGDIy54juixkMA(u"࠾ᄜ")):
			w9XJVimUN5 = umP72LtwzUTWHFAlJVyheEp5 // FvNyZqaLKw(u"࠹ᄝ")
			wuXqmzPANJ1LpU0dQYyMOlSi = umP72LtwzUTWHFAlJVyheEp5 % bUdr5Hahw6sY8xJ(u"࠳ᄞ")
			nmC1O2RkzLYTvGpSeXDc3E7dIUa = yWchHjb4Ntd8pU5Y9z + (HZQDUvJwK4x15pC0TgXo * wuXqmzPANJ1LpU0dQYyMOlSi)
			r1r0i5KRfFEUSdtICbmjXYvQgwqhJk = X5QybkEPYMaiBnor0qLNft + (wwLyTRF0kUWmgeZ6iz * w9XJVimUN5)
			J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chk[umP72LtwzUTWHFAlJVyheEp5] = zz2LJUB9kjnZqAeH.ControlImage(nmC1O2RkzLYTvGpSeXDc3E7dIUa, r1r0i5KRfFEUSdtICbmjXYvQgwqhJk, HZQDUvJwK4x15pC0TgXo, wwLyTRF0kUWmgeZ6iz, M6Og0qZCpo)
			J4JbrLDI1aWiBHX8hYuZcFCq6VsG.addControl(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chk[umP72LtwzUTWHFAlJVyheEp5])
			J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chk[umP72LtwzUTWHFAlJVyheEp5].setVisible(UTelCo0ihE1d5R(u"ࡊࡦࡲࡳࡦᅶ"))
			J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chkbutton[umP72LtwzUTWHFAlJVyheEp5] = zz2LJUB9kjnZqAeH.ControlButton(nmC1O2RkzLYTvGpSeXDc3E7dIUa, r1r0i5KRfFEUSdtICbmjXYvQgwqhJk, HZQDUvJwK4x15pC0TgXo, wwLyTRF0kUWmgeZ6iz, str(umP72LtwzUTWHFAlJVyheEp5 + lc0dpSmwoPDjLnk(u"࠲ᄟ")), font=iUeoLOsbHqP(u"ࠫ࡫ࡵ࡮ࡵ࠳࠶ࠫཔ"), focusTexture=ff8uYjDv5LVs7BFWQliTe94, noFocusTexture=nAuopDEz3BW8HxQTwrZU1MmKsf)
			J4JbrLDI1aWiBHX8hYuZcFCq6VsG.addControl(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chkbutton[umP72LtwzUTWHFAlJVyheEp5])
		for umP72LtwzUTWHFAlJVyheEp5 in range(UTelCo0ihE1d5R(u"࠻ᄠ")):
			ktq2W0ou8ZsSPzY4LH3m = (umP72LtwzUTWHFAlJVyheEp5 // XzrqbGDIy54juixkMA(u"࠶ᄡ")) * XzrqbGDIy54juixkMA(u"࠶ᄡ")
			vk10w8olcPZS6XMBGINbd29qLpez74 = ktq2W0ou8ZsSPzY4LH3m + (umP72LtwzUTWHFAlJVyheEp5 + l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠵ᄢ")) % Cu1704YofAbr3QTm(u"࠸ᄣ")
			s3YNc4ZgH9ApXbtGvVR = ktq2W0ou8ZsSPzY4LH3m + (umP72LtwzUTWHFAlJVyheEp5 - S4SOKF2QbBhjCd3RrVMuHIzE(u"࠷ᄤ")) % kEhAHvti6Vnsfx(u"࠳ᄥ")
			bbTOicY53XAnrSk = (umP72LtwzUTWHFAlJVyheEp5 - wRxoKs10Syj7V4edYhtP(u"࠵ᄧ")) % FnBiAjthS8MkXs67W(u"࠺ᄦ")
			WWNaPtpFEQ26fmDuecqLons9CYM = (umP72LtwzUTWHFAlJVyheEp5 + p72fnFtcPix5UKwr9YNzW(u"࠷ᄩ")) % pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠼ᄨ")
			J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chkbutton[umP72LtwzUTWHFAlJVyheEp5].controlRight(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chkbutton[vk10w8olcPZS6XMBGINbd29qLpez74])
			J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chkbutton[umP72LtwzUTWHFAlJVyheEp5].controlLeft(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chkbutton[s3YNc4ZgH9ApXbtGvVR])
			if umP72LtwzUTWHFAlJVyheEp5 <= SO94xq1RAkMm2uF(u"࠷ᄪ"):
				J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chkbutton[umP72LtwzUTWHFAlJVyheEp5].controlUp(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.okbutton)
			else:
				J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chkbutton[umP72LtwzUTWHFAlJVyheEp5].controlUp(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chkbutton[bbTOicY53XAnrSk])
			if umP72LtwzUTWHFAlJVyheEp5 >= pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠼ᄫ"):
				J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chkbutton[umP72LtwzUTWHFAlJVyheEp5].controlDown(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.okbutton)
			else:
				J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chkbutton[umP72LtwzUTWHFAlJVyheEp5].controlDown(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chkbutton[WWNaPtpFEQ26fmDuecqLons9CYM])
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.okbutton.controlLeft(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.cancelbutton)
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.okbutton.controlRight(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.cancelbutton)
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.cancelbutton.controlLeft(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.okbutton)
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.cancelbutton.controlRight(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.okbutton)
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.okbutton.controlDown(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chkbutton[zqdvcbP5L8BHh(u"࠲ᄬ")])
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.okbutton.controlUp(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chkbutton[SO94xq1RAkMm2uF(u"࠹ᄭ")])
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.cancelbutton.controlDown(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chkbutton[l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠲ᄮ")])
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.cancelbutton.controlUp(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chkbutton[SO94xq1RAkMm2uF(u"࠹ᄯ")])
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.setFocus(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.okbutton)
	def get(J4JbrLDI1aWiBHX8hYuZcFCq6VsG):
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.doModal()
		J4JbrLDI1aWiBHX8hYuZcFCq6VsG.close()
		if not J4JbrLDI1aWiBHX8hYuZcFCq6VsG.cancelled:
			return [umP72LtwzUTWHFAlJVyheEp5 for umP72LtwzUTWHFAlJVyheEp5 in range(XzrqbGDIy54juixkMA(u"࠽ᄰ")) if J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chkstate[umP72LtwzUTWHFAlJVyheEp5]]
	def onControl(J4JbrLDI1aWiBHX8hYuZcFCq6VsG, eebJnLziB0rZaswk7RVxy81):
		if eebJnLziB0rZaswk7RVxy81.getId() == J4JbrLDI1aWiBHX8hYuZcFCq6VsG.okbutton.getId() and any(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chkstate):
			J4JbrLDI1aWiBHX8hYuZcFCq6VsG.close()
		elif eebJnLziB0rZaswk7RVxy81.getId() == J4JbrLDI1aWiBHX8hYuZcFCq6VsG.cancelbutton.getId():
			J4JbrLDI1aWiBHX8hYuZcFCq6VsG.cancelled = iRoLg2m47tnDATBHGCSPNyx(u"࡙ࡸࡵࡦᅷ")
			J4JbrLDI1aWiBHX8hYuZcFCq6VsG.close()
		else:
			ccIZBYDOGdJlTE81Li2wAmuKtk = eebJnLziB0rZaswk7RVxy81.getLabel()
			if ccIZBYDOGdJlTE81Li2wAmuKtk.isnumeric():
				index = int(ccIZBYDOGdJlTE81Li2wAmuKtk) - Cu1704YofAbr3QTm(u"࠶ᄱ")
				J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chkstate[index] = not J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chkstate[index]
				J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chk[index].setVisible(J4JbrLDI1aWiBHX8hYuZcFCq6VsG.chkstate[index])
	def onAction(J4JbrLDI1aWiBHX8hYuZcFCq6VsG, ZSzcObrtyHA5aY9):
		if ZSzcObrtyHA5aY9 == QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠷࠰ᄲ"):
			J4JbrLDI1aWiBHX8hYuZcFCq6VsG.cancelled = hRNlWkwDitzVpbSO3TIdAm5YGjaZ(u"࡚ࡲࡶࡧᅸ")
			J4JbrLDI1aWiBHX8hYuZcFCq6VsG.close()
def Br34w0lTgsbQF6DvUyRikLEMYfZ(key,CCWfMt5XsOGPa,url):
	headers = {XzrqbGDIy54juixkMA(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ཕ"):url,pq3Z6xaELn0NW7PgAeI1bCRwdu(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡌࡢࡰࡪࡹࡦ࡭ࡥࠨབ"):CCWfMt5XsOGPa}
	F9gdlLKO8iy = pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠲ࡨࡵ࡭࠰ࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠳ࡦࡶࡩ࠰ࡨࡤࡰࡱࡨࡡࡤ࡭ࡂ࡯ࡂ࠭བྷ")+key
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨࡉࡈࡘࠬམ"),F9gdlLKO8iy,FvNyZqaLKw(u"ࠩࠪཙ"),headers,iRoLg2m47tnDATBHGCSPNyx(u"ࠪࠫཚ"),dshJSmRqeiP9nap2(u"ࠫࠬཛ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡈࡘࡤࡘࡅࡄࡃࡓࡘࡈࡎࡁ࠳ࡡࡗࡓࡐࡋࡎ࠮࠳ࡶࡸࠬཛྷ"))
	DI9PgKJNvLiuBpXyctMs2RklobGA,iteration = p72fnFtcPix5UKwr9YNzW(u"࠭ࠧཝ"),Me28A1sBLNIgUp5YCDyvT(u"࠰ᄳ")
	while YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࡔࡳࡷࡨᅹ"):
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		vpWXJDC4lTByaqcn56OFwUmieV = GGvHJKP9LUxEk10Fw.findall(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧࠣࠪ࠲ࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠵ࡡࡱ࡫࠵࠳ࡵࡧࡹ࡭ࡱࡤࡨࡠࡤࠢ࡞࠭ࠬࠫཞ"), BBlXpmUyhFDwNtCVAHoE)
		iteration += yA5z6LIXBlo41PRVMY87wOisFp(u"࠲ᄴ")
		message = GGvHJKP9LUxEk10Fw.findall(p72fnFtcPix5UKwr9YNzW(u"ࠨ࠾࡯ࡥࡧ࡫࡬࡜ࡠࡁࡡ࠰ࡩ࡬ࡢࡵࡶࡁࠧ࡬ࡢࡤ࠯࡬ࡱࡦ࡭ࡥࡴࡧ࡯ࡩࡨࡺ࠭࡮ࡧࡶࡷࡦ࡭ࡥ࠮ࡶࡨࡼࡹࠨ࡛࡟ࡀࡠ࠮ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡡࡣࡧ࡯ࡂࠬཟ"), BBlXpmUyhFDwNtCVAHoE)
		if not message: message = GGvHJKP9LUxEk10Fw.findall(oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠩ࠿ࡨ࡮ࡼ࡛࡟ࡀࡠ࠯ࡨࡲࡡࡴࡵࡀࠦ࡫ࡨࡣ࠮࡫ࡰࡥ࡬࡫ࡳࡦ࡮ࡨࡧࡹ࠳࡭ࡦࡵࡶࡥ࡬࡫࠭ࡦࡴࡵࡳࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬའ"), BBlXpmUyhFDwNtCVAHoE)
		if not message:
			DI9PgKJNvLiuBpXyctMs2RklobGA = GGvHJKP9LUxEk10Fw.findall(kEhAHvti6Vnsfx(u"ࠪࡶࡪࡧࡤࡰࡰ࡯ࡽࡃ࠮࠮ࠫࡁࠬࡀࠬཡ"), BBlXpmUyhFDwNtCVAHoE)[iUeoLOsbHqP(u"࠲ᄵ")]
			break
		else:
			message = message[SO94xq1RAkMm2uF(u"࠳ᄶ")]
			vpWXJDC4lTByaqcn56OFwUmieV = vpWXJDC4lTByaqcn56OFwUmieV[iUeoLOsbHqP(u"࠴ᄷ")]
		dmjR76ty2sePqCr5 = GGvHJKP9LUxEk10Fw.findall(lc0dpSmwoPDjLnk(u"ࡶࠬࡴࡡ࡮ࡧࡀࠦࡨࠨ࡜ࡴ࠭ࡹࡥࡱࡻࡥ࠾ࠤࠫ࡟ࡣࠨ࡝ࠬࠫࠪར"), BBlXpmUyhFDwNtCVAHoE)[SyENPzdOon6uxcLXMhqb14aDlB9r(u"࠵ᄸ")]
		ddWMwqbos3u = bUdr5Hahw6sY8xJ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱࡫ࡴࡵࡧ࡭ࡧ࠱ࡧࡴࡳࠥࡴࠩལ") % (vpWXJDC4lTByaqcn56OFwUmieV.replace(lc0dpSmwoPDjLnk(u"࠭ࠦࡢ࡯ࡳ࠿ࠬཤ"), SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠧࠧࠩཥ")))
		message = GGvHJKP9LUxEk10Fw.sub(SyENPzdOon6uxcLXMhqb14aDlB9r(u"ࠨ࠾࠲ࡃ࠭ࡪࡩࡷࡾࡶࡸࡷࡵ࡮ࡨࠫ࡞ࡢࡃࡣࠪ࠿ࠩས"), lc0dpSmwoPDjLnk(u"ࠩࠪཧ"), message)
		UMeD4bCO2k6i9KoWPBqaTy = vv5XnctQWb(captcha=ddWMwqbos3u, msg=message, iteration=iteration)
		dVlPWUkcpstBXrNbzn = UMeD4bCO2k6i9KoWPBqaTy.get()
		if not dVlPWUkcpstBXrNbzn: break
		data = {FnBiAjthS8MkXs67W(u"ࠪࡧࠬཨ"): dmjR76ty2sePqCr5, FvNyZqaLKw(u"ࠫࡷ࡫ࡳࡱࡱࡱࡷࡪ࠭ཀྵ"): dVlPWUkcpstBXrNbzn}
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,E6MIKdpBomef(u"ࠬࡖࡏࡔࡖࠪཪ"),F9gdlLKO8iy,data,headers,kEhAHvti6Vnsfx(u"࠭ࠧཫ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠧࠨཬ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡌࡋࡔࡠࡔࡈࡇࡆࡖࡔࡄࡊࡄ࠶ࡤ࡚ࡏࡌࡇࡑ࠱࠷ࡴࡤࠨ཭"))
	return DI9PgKJNvLiuBpXyctMs2RklobGA
def ssDjKt5fiu0Hb6ZoaqXRPAJml(url):
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(xh9BXlAw0UoVsIZ4if3,url,bUdr5Hahw6sY8xJ(u"ࠩࠪ཮"),E6MIKdpBomef(u"ࠪࠫ཯"),Cu1704YofAbr3QTm(u"ࠫࠬ཰"),iUeoLOsbHqP(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇࡒࡏࡂࡆࡖ࠱࠶ࡹࡴࠨཱ"))
	items = GGvHJKP9LUxEk10Fw.findall(p72fnFtcPix5UKwr9YNzW(u"࠭ࡣࡰ࡮ࡲࡶࡂࠨࡲࡦࡦࠥࡂ࠭࠴ࠪࡀࠫ࠿ིࠫ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if items: return FnBiAjthS8MkXs67W(u"ࠧࠨཱི"),[dshJSmRqeiP9nap2(u"ࠨུࠩ")],[ items[E6MIKdpBomef(u"࠶ᄹ")] ]
	else: return g4g6bfkPtVGU5lIM3(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡘࡁࡃࡎࡒࡅࡉཱུ࡙ࠧ"),[],[]
def p13vUrlswfaj0cKh(url):
	return YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠪࠫྲྀ"),[iUeoLOsbHqP(u"ࠫࠬཷ")],[ url ]
def Zoj6CfFnS50biE(url):
	C83UXWf15zdwLA0 = url.split(p72fnFtcPix5UKwr9YNzW(u"ࠬ࠵ࠧླྀ"))
	jSzJyQIO6Pa1D748H3CLl0XE = iRoLg2m47tnDATBHGCSPNyx(u"࠭࠯ࠨཹ").join(C83UXWf15zdwLA0[lc0dpSmwoPDjLnk(u"࠰ᄺ"):zqdvcbP5L8BHh(u"࠴ᄻ")])
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(xh9BXlAw0UoVsIZ4if3,url,yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧࠨེ"),g4g6bfkPtVGU5lIM3(u"ࠨཻࠩ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ོࠩࠪ"),SO94xq1RAkMm2uF(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡚ࡊࡒࡓ࡝ࡘࡎࡁࡓࡇ࠰࠵ࡸࡺཽࠧ"))
	items = GGvHJKP9LUxEk10Fw.findall(xW2Arao7YVOemw(u"ࠫࡩࡲࡢࡶࡶࡷࡳࡳࡢࠧ࡝ࠫ࠱࡬ࡷ࡫ࡦࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠤࡡ࠱ࠠ࡝ࠪࠫ࠲࠯ࡅࠩࠡ࡞ࠨࠤ࠭࠴ࠪࡀࠫࠣࡠ࠰ࠦࠨ࠯ࠬࡂ࠭ࠥࡢࠥࠡࠪ࠱࠮ࡄ࠯࡜ࠪࠢ࡟࠯ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ཾ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if items:
		n3ot08Ck2OIaKFq1iJsvWQScyfx,DCguJjW2E9bQomXAqG,KabhGpmIOrHTv0DEXWu7FVA,EjQwRXIlWF2K4tTxrgmU7JPpAB0Zk,w8eZ62x4LgaJXNhUWudcqoAtpl,nqmS8DWOcpwEi2uT0I5ybM9 = items[QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠲ᄼ")]
		RRSq2Qx0MfkFHLt = int(DCguJjW2E9bQomXAqG) % int(KabhGpmIOrHTv0DEXWu7FVA) + int(EjQwRXIlWF2K4tTxrgmU7JPpAB0Zk) % int(w8eZ62x4LgaJXNhUWudcqoAtpl)
		url = jSzJyQIO6Pa1D748H3CLl0XE + n3ot08Ck2OIaKFq1iJsvWQScyfx + str(RRSq2Qx0MfkFHLt) + nqmS8DWOcpwEi2uT0I5ybM9
		return hBvsQ7oCkKUdwjx58ml3EN(u"ࠬ࠭ཿ"),[Cu1704YofAbr3QTm(u"ྀ࠭ࠧ")],[url]
	else: return YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢ࡝ࡍࡕࡖ࡙ࡔࡊࡄࡖࡊཱྀ࠭"),[],[]
def GH9ngjZFiseWyY4mA1Q0Pv5cl(url):
	id = url.split(bUdr5Hahw6sY8xJ(u"ࠨ࠱ࠪྂ"))[-iUeoLOsbHqP(u"࠴ᄽ")]
	headers = { kEhAHvti6Vnsfx(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨྃ") : hBvsQ7oCkKUdwjx58ml3EN(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ྄ࠩ") }
	vpWXJDC4lTByaqcn56OFwUmieV = { bUdr5Hahw6sY8xJ(u"ࠦ࡮ࡪࠢ྅"):id , l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"ࠧࡵࡰࠣ྆"):dshJSmRqeiP9nap2(u"ࠨࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠤ྇") }
	hD6se2E307NcI = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,hBvsQ7oCkKUdwjx58ml3EN(u"ࠧࡑࡑࡖࡘࠬྈ"), url, vpWXJDC4lTByaqcn56OFwUmieV, headers, YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"ࠨࠩྉ"),LiRcTVUWuth70DmPy(u"ࠩࠪྊ"),oh5Ptv7RjM3qLk1eEZJbcVzKis4d(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡑ࠶ࡘࡔࡑࡕࡁࡅ࠯࠴ࡷࡹ࠭ྋ"))
	if pq3Z6xaELn0NW7PgAeI1bCRwdu(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ྌ") in list(hD6se2E307NcI.headers.keys()): ELbNB92cOh5dqtpVmi40kY = hD6se2E307NcI.headers[S4SOKF2QbBhjCd3RrVMuHIzE(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧྍ")]
	else: ELbNB92cOh5dqtpVmi40kY = url
	if ELbNB92cOh5dqtpVmi40kY: return XzrqbGDIy54juixkMA(u"࠭ࠧྎ"),[yA5z6LIXBlo41PRVMY87wOisFp(u"ࠧࠨྏ")],[ELbNB92cOh5dqtpVmi40kY]
	else: return SO94xq1RAkMm2uF(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡕ࠺ࡕࡑࡎࡒࡅࡉ࠭ྐ"),[],[]
def iCWrkM5wAaTbpS7KhRVodUYDuv(url):
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(xh9BXlAw0UoVsIZ4if3,url,wRxoKs10Syj7V4edYhtP(u"ࠩࠪྑ"),FvNyZqaLKw(u"ࠪࠫྒ"),g4g6bfkPtVGU5lIM3(u"ࠫࠬྒྷ"),fprnld4CZo(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡌࡒ࡙࡜ࡌࡊࡘࡈ࠱࠶ࡹࡴࠨྔ"))
	items = GGvHJKP9LUxEk10Fw.findall(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"࠭࡭ࡱ࠶࠽ࠤࡡࡡ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨࠩྕ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if items: return LiRcTVUWuth70DmPy(u"ࠧࠨྖ"),[bUdr5Hahw6sY8xJ(u"ࠨࠩྗ")],[ items[YcEj8nlBAbSHCI5P9Xg4TVNQ3UF(u"࠴ᄾ")] ]
	else: return sTcr7iDp5eFt4RoLMhuwq1A(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡜ࡏࡎࡕࡘࡏࡍ࡛ࡋࠧ྘"),[],[]
def nMRd3JxIrNzCw5ByYm1GkvUDciS497(url):
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(xh9BXlAw0UoVsIZ4if3,url,G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠪࠫྙ"),lc0dpSmwoPDjLnk(u"ࠫࠬྚ"),QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬ࠭ྛ"),l30iT7pjzmXk8dvwSNyUR1aZO4tWh(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡈࡎࡉࡗࡇ࠰࠵ࡸࡺࠧྜ"))
	items = GGvHJKP9LUxEk10Fw.findall(QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬྜྷ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if items:
		url = url = g4g6bfkPtVGU5lIM3(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡨ࡮ࡩࡷࡧ࠱ࡳࡷ࡭ࠧྞ") + items[FvNyZqaLKw(u"࠵ᄿ")]
		return bUdr5Hahw6sY8xJ(u"ࠩࠪྟ"),[iRoLg2m47tnDATBHGCSPNyx(u"ࠪࠫྠ")],[ url ]
	else: return Cu1704YofAbr3QTm(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡓࡅࡋࡍ࡛ࡋࠧྡ"),[],[]
def EQ3xfWXapKG4y1uTw2Oz08(url):
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(xh9BXlAw0UoVsIZ4if3,url,QVZl0O8yUIzdGDTfYcn5H37uWmb2(u"ࠬ࠭ྡྷ"),XzrqbGDIy54juixkMA(u"࠭ࠧྣ"),sTcr7iDp5eFt4RoLMhuwq1A(u"ࠧࠨྤ"),xW2Arao7YVOemw(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊ࡙ࡔࡓࡇࡄࡑ࠲࠷ࡳࡵࠩྥ"))
	items = GGvHJKP9LUxEk10Fw.findall(bUdr5Hahw6sY8xJ(u"ࠩࡹ࡭ࡩ࡫࡯ࠡࡲࡵࡩࡱࡵࡡࡥ࠰࠭ࡃࡸࡸࡣ࠾࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩྦ"),BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if items: return fprnld4CZo(u"ࠪࠫྦྷ"),[G5DeRbUpFj8E9OtJLvlo2fWmZC(u"ࠫࠬྨ")],[ items[E6MIKdpBomef(u"࠶ᅀ")] ]
	else: return xW2Arao7YVOemw(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡕࡗࡖࡊࡇࡍࠨྩ"),[],[]
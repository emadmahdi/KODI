# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'EGYDEAD'
mmDwMlfoHtG5XT19VLIWqCR8i = '_EGD_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
DDXTwbRBaj3e2rSsPQ = ['مصارعة','احدث البرامج','احدث الالعاب','الرئيسية','احدث الاغانى']
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==440: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==441: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,text)
	elif mode==442: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==443: zpXG3Ky6ou8ndWHkb4 = hWPvGlXZ5arzV7(url)
	elif mode==449: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',NBm2aWhPzoTpdYn,'','','','','EGYDEAD-MENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(NBm2aWhPzoTpdYn,'url')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',449,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'الرئيسية',NBm2aWhPzoTpdYn,441)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="title_menu_right"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		if title in DDXTwbRBaj3e2rSsPQ: continue
		if ELbNB92cOh5dqtpVmi40kY=='#': continue
		cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,441)
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(url,vAxfDHyjwR6KM74IGEJl0dasY=''):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','EGYDEAD-TITLES-2nd')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="list-related"(.*?)class="pagination"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('<li>.*?href="(.*?)".*?<h1>(.*?)</h1>.*?src="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title,VFqpJjRySZvgi in items:
		if '/url/' in ELbNB92cOh5dqtpVmi40kY: continue
		elif '/season/' in ELbNB92cOh5dqtpVmi40kY: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,443,VFqpJjRySZvgi)
		elif '/episode/' in ELbNB92cOh5dqtpVmi40kY: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,443,VFqpJjRySZvgi)
		else: cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,442,VFqpJjRySZvgi)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="pagination"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			title = DwNC3gEonizsB6a0v1F(title)
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,441)
	return
def hWPvGlXZ5arzV7(url):
	data = {'View':1}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'POST',url,data,headers,'','','EGYDEAD-EPISODES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	xxcVm7YBMXsfd = GGvHJKP9LUxEk10Fw.findall('"seasons-list"(.*?)</div>.</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb = GGvHJKP9LUxEk10Fw.findall('"episodes-list"(.*?)</div>.</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if xxcVm7YBMXsfd:
		UCEFMfKbgpd = xxcVm7YBMXsfd[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title,VFqpJjRySZvgi in items:
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,443,VFqpJjRySZvgi)
	elif uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb:
		VFqpJjRySZvgi = GGvHJKP9LUxEk10Fw.findall('"og:image" content="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		VFqpJjRySZvgi = VFqpJjRySZvgi[0]
		UCEFMfKbgpd = uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			title = title.replace('\n','').strip(' ')
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,442,VFqpJjRySZvgi)
	return
def SUfe4unWoXBNFz90xqy(url):
	data = {'View':1}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'POST',url,data,headers,'','','EGYDEAD-PLAY-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	zzvBg3ShiamAZ = []
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"watchAreaMaster"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('data-link="(.*?)".*?<p>(.*?)</p>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			title = title.replace('\n','').strip(' ')
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named='+title+'__watch'
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"donwload-servers-list"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('"ser-name">(.*?)</span>.*?<em>(.*?)</em>.*?href="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for title,dDZQSEGRTo9g85x1C,ELbNB92cOh5dqtpVmi40kY in items:
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.replace('\n','')
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named='+title+'__download'+'____'+dDZQSEGRTo9g85x1C
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(zzvBg3ShiamAZ,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	search = search.replace(' ','+')
	url = NBm2aWhPzoTpdYn+'/?s='+search
	xoiXMWjJC3pnQqurIGPkRSl8e(url)
	return
# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
import bs4 as uY305abnMJ8WPDBrpC9
cTJphS1nFz5EUgNWm86C = 'ELCINEMA'
mmDwMlfoHtG5XT19VLIWqCR8i = '_ELC_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
headers = {'Referer':NBm2aWhPzoTpdYn}
DDXTwbRBaj3e2rSsPQ = []
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==510: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==511: zpXG3Ky6ou8ndWHkb4 = eCbNXynLxjdzDvRKkEJc8sQYF(url)
	elif mode==512: zpXG3Ky6ou8ndWHkb4 = hW91LE0xpvtXdIBs(url)
	elif mode==513: zpXG3Ky6ou8ndWHkb4 = TUdAIoGJ6vO1whqQXn5(url)
	elif mode==514: zpXG3Ky6ou8ndWHkb4 = Eg9wreTHlMp8iD3zLShWc4kNaJG(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: zpXG3Ky6ou8ndWHkb4 = Eg9wreTHlMp8iD3zLShWc4kNaJG(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: zpXG3Ky6ou8ndWHkb4 = vIFnX7qU8TCKJVZaQPhg3zo(text)
	elif mode==517: zpXG3Ky6ou8ndWHkb4 = UleuHWgb6zKJ7cFjoZ(url)
	elif mode==518: zpXG3Ky6ou8ndWHkb4 = dZziDAFNaE6OPycgWm1Vqpwrbh9x5(url)
	elif mode==519: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	elif mode==520: zpXG3Ky6ou8ndWHkb4 = G9ws8WoOTK63yDAVj7LZqJmMhBP(url)
	elif mode==521: zpXG3Ky6ou8ndWHkb4 = CCFrN8ZvA0leJEx(url)
	elif mode==522: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==523: zpXG3Ky6ou8ndWHkb4 = UeHiL2uY06jmAGWc4BNsDpdR3olqyx(text)
	elif mode==524: zpXG3Ky6ou8ndWHkb4 = mMojbP4RwaQgp()
	elif mode==525: zpXG3Ky6ou8ndWHkb4 = uzY2CJiSc9gQ4TG()
	elif mode==526: zpXG3Ky6ou8ndWHkb4 = TtI0hHB9p17FDfOjNnabvRmlU()
	elif mode==527: zpXG3Ky6ou8ndWHkb4 = nI3yXcRKf8s5QleubPgAUxYSED7jz()
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث بموسوعة السينما','',519)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'موسوعة الأعمال','',525)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'موسوعة الأشخاص','',526)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'موسوعة المصنفات','',527)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'موسوعة المنوعات','',524)
	return
def mMojbP4RwaQgp():
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+' فيديوهات - خاصة',NBm2aWhPzoTpdYn+'/video',520)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فيديوهات - أحدث',NBm2aWhPzoTpdYn+'/video/latest',521)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فيديوهات - أقدم',NBm2aWhPzoTpdYn+'/video/oldest',521)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فيديوهات - أكثر مشاهدة',NBm2aWhPzoTpdYn+'/video/views',521)
	return
def uzY2CJiSc9gQ4TG():
	HMEsoD4uOm0Kd8W = NBm2aWhPzoTpdYn+'/lineup?utf8=%E2%9C%93'
	HHwVRk8LTWtIEgloBO3F = HMEsoD4uOm0Kd8W+'&type=2&category=1&foreign=false&tag='
	CCZpueYl7HG96dkhM3nXrQcw = HMEsoD4uOm0Kd8W+'&type=2&category=3&foreign=false&tag='
	jabLRrWlQ1Eo2T8YptkzBdXxqO4Gh = HMEsoD4uOm0Kd8W+'&type=2&category=1&foreign=true&tag='
	dwzoFBnt9VkmK2DTe = HMEsoD4uOm0Kd8W+'&type=2&category=3&foreign=true&tag='
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مصنفات أفلام عربي',HHwVRk8LTWtIEgloBO3F,511)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مصنفات مسلسلات عربي',CCZpueYl7HG96dkhM3nXrQcw,511)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مصنفات أفلام اجنبي',jabLRrWlQ1Eo2T8YptkzBdXxqO4Gh,511)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مصنفات مسلسلات اجنبي',dwzoFBnt9VkmK2DTe,511)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فهرس أعمال أبجدي',NBm2aWhPzoTpdYn+'/index/work/alphabet',517)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فهرس  بلد الإنتاج',NBm2aWhPzoTpdYn+'/index/work/country',517)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فهرس اللغة',NBm2aWhPzoTpdYn+'/index/work/language',517)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فهرس مصنفات العمل',NBm2aWhPzoTpdYn+'/index/work/genre',517)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فهرس سنة الإصدار',NBm2aWhPzoTpdYn+'/index/work/release_year',517)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مواسم - فلتر محدد',NBm2aWhPzoTpdYn+'/seasonals',515)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مواسم - فلتر كامل',NBm2aWhPzoTpdYn+'/seasonals',514)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مصنفات - فلتر محدد',NBm2aWhPzoTpdYn+'/lineup',515)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مصنفات - فلتر كامل',NBm2aWhPzoTpdYn+'/lineup',514)
	return
def nI3yXcRKf8s5QleubPgAUxYSED7jz():
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',NBm2aWhPzoTpdYn+'/lineup','',headers,'','','ELCINEMA-MENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	kwRzflA7aeFUsCEpLXJrO = uY305abnMJ8WPDBrpC9.BeautifulSoup(BBlXpmUyhFDwNtCVAHoE,'html.parser',multi_valued_attributes=None)
	UCEFMfKbgpd = kwRzflA7aeFUsCEpLXJrO.find('select',attrs={'name':'tag'})
	tY3Dfrp6cMKFj = UCEFMfKbgpd.find_all('option')
	for RHb9zAjcuTIoyZ0aDgS1pQYmUs8 in tY3Dfrp6cMKFj:
		hieW1zRUG5w9AykJjv0X = RHb9zAjcuTIoyZ0aDgS1pQYmUs8.get('value')
		if not hieW1zRUG5w9AykJjv0X: continue
		title = RHb9zAjcuTIoyZ0aDgS1pQYmUs8.text
		if HHosl5fRdhtEDAYyP:
			title = title.encode('utf8')
			hieW1zRUG5w9AykJjv0X = hieW1zRUG5w9AykJjv0X.encode('utf8')
		ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+hieW1zRUG5w9AykJjv0X
		title = title.replace('قائمة ','')
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,511)
	return
def TtI0hHB9p17FDfOjNnabvRmlU():
	HMEsoD4uOm0Kd8W = NBm2aWhPzoTpdYn+'/lineup?utf8=%E2%9C%93'
	y7bJTYDq3ZmLoBOl = HMEsoD4uOm0Kd8W+'&type=1&category=&foreign=&tag='
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مصنفات أشخاص',y7bJTYDq3ZmLoBOl,511)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فهرس أشخاص أبجدي',NBm2aWhPzoTpdYn+'/index/person/alphabet',517)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فهرس موطن',NBm2aWhPzoTpdYn+'/index/person/nationality',517)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فهرس  تاريخ الميلاد',NBm2aWhPzoTpdYn+'/index/person/birth_year',517)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فهرس  تاريخ الوفاة',NBm2aWhPzoTpdYn+'/index/person/death_year',517)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مصنفات - فلتر محدد',NBm2aWhPzoTpdYn+'/lineup',515)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مصنفات - فلتر كامل',NBm2aWhPzoTpdYn+'/lineup',514)
	return
def eCbNXynLxjdzDvRKkEJc8sQYF(url):
	if '/seasonals' in url: nlYKqpfrwVWLmig71o9BX = 0
	elif '/lineup' in url: nlYKqpfrwVWLmig71o9BX = 1
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',url,'',headers,'','','ELCINEMA-LISTS-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	kwRzflA7aeFUsCEpLXJrO = uY305abnMJ8WPDBrpC9.BeautifulSoup(BBlXpmUyhFDwNtCVAHoE,'html.parser',multi_valued_attributes=None)
	EHDeldN7L2k19JBUqhmsuSXiwV = kwRzflA7aeFUsCEpLXJrO.find_all(class_='jumbo-theater clearfix')
	for UCEFMfKbgpd in EHDeldN7L2k19JBUqhmsuSXiwV:
		title = UCEFMfKbgpd.find_all('a')[nlYKqpfrwVWLmig71o9BX].text
		ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+UCEFMfKbgpd.find_all('a')[nlYKqpfrwVWLmig71o9BX].get('href')
		if HHosl5fRdhtEDAYyP:
			title = title.encode('utf8')
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.encode('utf8')
		if not EHDeldN7L2k19JBUqhmsuSXiwV:
			hW91LE0xpvtXdIBs(ELbNB92cOh5dqtpVmi40kY)
			return
		else:
			title = title.replace('قائمة ','')
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,512)
	Ozfhb9uBAL7lG3qU6ri(kwRzflA7aeFUsCEpLXJrO,511)
	return
def Ozfhb9uBAL7lG3qU6ri(kwRzflA7aeFUsCEpLXJrO,mode):
	UCEFMfKbgpd = kwRzflA7aeFUsCEpLXJrO.find(class_='pagination')
	if UCEFMfKbgpd:
		d1cF62jfZMwJ4PVXIBUz = UCEFMfKbgpd.find_all('a')
		vA7Y9nzx5TZqFDBhPX4btUImlNkWG8 = UCEFMfKbgpd.find_all('li')
		o8HP37RJktF = list(zip(d1cF62jfZMwJ4PVXIBUz,vA7Y9nzx5TZqFDBhPX4btUImlNkWG8))
		CQMipytPbq = -1
		MUSrJfcoWxYhyjO = len(o8HP37RJktF)
		for IPbFd21uGo4Y7g5ntW8JNa0wlfC,naVkUhcPG7J9oQ in o8HP37RJktF:
			CQMipytPbq += 1
			naVkUhcPG7J9oQ = naVkUhcPG7J9oQ['class']
			if 'unavailable' in naVkUhcPG7J9oQ or 'current' in naVkUhcPG7J9oQ: continue
			RuWUKQylsNvOH7SpiL59nYP3rA = IPbFd21uGo4Y7g5ntW8JNa0wlfC.text
			E2EhMuOLdF08Pz75jDKS14cfYNxy = NBm2aWhPzoTpdYn+IPbFd21uGo4Y7g5ntW8JNa0wlfC.get('href')
			if HHosl5fRdhtEDAYyP:
				RuWUKQylsNvOH7SpiL59nYP3rA = RuWUKQylsNvOH7SpiL59nYP3rA.encode('utf8')
				E2EhMuOLdF08Pz75jDKS14cfYNxy = E2EhMuOLdF08Pz75jDKS14cfYNxy.encode('utf8')
			if   CQMipytPbq==0: RuWUKQylsNvOH7SpiL59nYP3rA = 'أولى'
			elif CQMipytPbq==1: RuWUKQylsNvOH7SpiL59nYP3rA = 'سابقة'
			elif CQMipytPbq==MUSrJfcoWxYhyjO-2: RuWUKQylsNvOH7SpiL59nYP3rA = 'لاحقة'
			elif CQMipytPbq==MUSrJfcoWxYhyjO-1: RuWUKQylsNvOH7SpiL59nYP3rA = 'أخيرة'
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+RuWUKQylsNvOH7SpiL59nYP3rA,E2EhMuOLdF08Pz75jDKS14cfYNxy,mode)
	return
def hW91LE0xpvtXdIBs(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',url,'',headers,'','','ELCINEMA-TITLES1-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	kwRzflA7aeFUsCEpLXJrO = uY305abnMJ8WPDBrpC9.BeautifulSoup(BBlXpmUyhFDwNtCVAHoE,'html.parser',multi_valued_attributes=None)
	EHDeldN7L2k19JBUqhmsuSXiwV = kwRzflA7aeFUsCEpLXJrO.find_all(class_='row')
	items,ltnfoZ29FRhWPwCbj = [],True
	for UCEFMfKbgpd in EHDeldN7L2k19JBUqhmsuSXiwV:
		if not UCEFMfKbgpd.find(class_='thumbnail-wrapper'): continue
		if ltnfoZ29FRhWPwCbj: ltnfoZ29FRhWPwCbj = False ; continue
		ZUFtIdvSsiQDy6epx = []
		pLru0bFmV8iHBfKAYU6Cow3kZqcG = UCEFMfKbgpd.find_all(class_=['censorship red','censorship purple'])
		for OOmidthcMPWBybJE in pLru0bFmV8iHBfKAYU6Cow3kZqcG:
			toOX7FCsl8iWTf = OOmidthcMPWBybJE.find_all('li')[1].text
			if HHosl5fRdhtEDAYyP:
				toOX7FCsl8iWTf = toOX7FCsl8iWTf.encode('utf8')
			ZUFtIdvSsiQDy6epx.append(toOX7FCsl8iWTf)
		if not hNCJPTucIV7GOSR0HytZ6eQrqEUpw(cTJphS1nFz5EUgNWm86C,'',ZUFtIdvSsiQDy6epx,False):
			nWO8c3IgspK67QX = UCEFMfKbgpd.find('img').get('data-src')
			title = UCEFMfKbgpd.find('h3')
			name = title.find('a').text
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+title.find('a').get('href')
			dvosg4EYw9D1 = UCEFMfKbgpd.find(class_='no-margin')
			JrNE09KoUVWd = UCEFMfKbgpd.find(class_='legend')
			if dvosg4EYw9D1: dvosg4EYw9D1 = dvosg4EYw9D1.text
			if JrNE09KoUVWd: JrNE09KoUVWd = JrNE09KoUVWd.text
			if HHosl5fRdhtEDAYyP:
				nWO8c3IgspK67QX = nWO8c3IgspK67QX.encode('utf8')
				name = name.encode('utf8')
				ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.encode('utf8')
				if dvosg4EYw9D1: dvosg4EYw9D1 = dvosg4EYw9D1.encode('utf8')
			LGdFZQvKeU52s6H0DgjN = {}
			if JrNE09KoUVWd: LGdFZQvKeU52s6H0DgjN['stars'] = JrNE09KoUVWd
			if dvosg4EYw9D1:
				dvosg4EYw9D1 = dvosg4EYw9D1.replace('\n',' .. ')
				LGdFZQvKeU52s6H0DgjN['plot'] = dvosg4EYw9D1.replace('...اقرأ المزيد','')
			if '/work/' in ELbNB92cOh5dqtpVmi40kY:
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+name,ELbNB92cOh5dqtpVmi40kY,516,nWO8c3IgspK67QX,'',name,'',LGdFZQvKeU52s6H0DgjN)
			elif '/person/' in ELbNB92cOh5dqtpVmi40kY: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+name,ELbNB92cOh5dqtpVmi40kY,513,nWO8c3IgspK67QX,'',name,'',LGdFZQvKeU52s6H0DgjN)
	Ozfhb9uBAL7lG3qU6ri(kwRzflA7aeFUsCEpLXJrO,512)
	return
def TUdAIoGJ6vO1whqQXn5(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',url,'',headers,'','','ELCINEMA-TITLES2-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	kwRzflA7aeFUsCEpLXJrO = uY305abnMJ8WPDBrpC9.BeautifulSoup(BBlXpmUyhFDwNtCVAHoE,'html.parser',multi_valued_attributes=None)
	EHDeldN7L2k19JBUqhmsuSXiwV = kwRzflA7aeFUsCEpLXJrO.find_all('li')
	YUgMTmWlyuxAkbqCwrvS89h6Ddnta,items = [],[]
	for UCEFMfKbgpd in EHDeldN7L2k19JBUqhmsuSXiwV:
		if not UCEFMfKbgpd.find(class_='thumbnail-wrapper'): continue
		if not UCEFMfKbgpd.find(class_=['unstyled','unstyled text-center']): continue
		if UCEFMfKbgpd.find(class_='hide'): continue
		title = UCEFMfKbgpd.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in YUgMTmWlyuxAkbqCwrvS89h6Ddnta: continue
		YUgMTmWlyuxAkbqCwrvS89h6Ddnta.append(name)
		ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+title.find('a').get('href')
		if '/search/work/' in url: nWO8c3IgspK67QX = UCEFMfKbgpd.find('img').get('src')
		elif '/search/person/' in url: nWO8c3IgspK67QX = UCEFMfKbgpd.find('img').get('data-src')
		elif '/search/video/' in url: nWO8c3IgspK67QX = UCEFMfKbgpd.find('img').get('data-src')
		else: nWO8c3IgspK67QX = UCEFMfKbgpd.find('img').get('src')
		if HHosl5fRdhtEDAYyP:
			name = name.encode('utf8')
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.encode('utf8')
			nWO8c3IgspK67QX = nWO8c3IgspK67QX.encode('utf8')
		name = name.strip(' ')
		items.append((name,ELbNB92cOh5dqtpVmi40kY,nWO8c3IgspK67QX))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,ELbNB92cOh5dqtpVmi40kY,nWO8c3IgspK67QX in items:
		if '/search/video/' in url: cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+name,ELbNB92cOh5dqtpVmi40kY,522,nWO8c3IgspK67QX)
		elif '/search/person/' in url: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+name,ELbNB92cOh5dqtpVmi40kY,513,nWO8c3IgspK67QX,'',name)
		else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+name,ELbNB92cOh5dqtpVmi40kY,516,nWO8c3IgspK67QX,'',name)
	return
def vIFnX7qU8TCKJVZaQPhg3zo(text):
	text = text.replace('الإعلان','').replace('لفيلم','').replace('الرسمي','')
	text = text.replace('إعلان','').replace('فيلم','').replace('البرومو','')
	text = text.replace('التشويقي','').replace('لمسلسل','').replace('مسلسل','')
	text = text.replace(':','').replace(')','').replace('(','').replace(',','')
	text = text.replace('_','').replace(';','').replace('-','').replace('.','')
	text = text.replace('\'','').replace('\"','')
	text = text.replace('    ',' ').replace('   ',' ').replace('  ',' ')
	text = text.strip(' ')
	CJ8HEV96Lkl0OjhADKYmRzG = text.count(' ')+1
	if CJ8HEV96Lkl0OjhADKYmRzG==1:
		UeHiL2uY06jmAGWc4BNsDpdR3olqyx(text)
		return
	cd0aGwCPExbFU5pYNu8r('link',mmDwMlfoHtG5XT19VLIWqCR8i+'[COLOR FFC89008]==== كلمات للبحث ====[/COLOR]','',9999)
	D4NFkh0vuy = text.split(' ')
	qb3TfmuVLy9cP = pow(2,CJ8HEV96Lkl0OjhADKYmRzG)
	tKy7SD2Ip3rJunj8aMGqwZ5Edgx = []
	def te9shkSxKVbmr(rGQvqJk35uZ0atUwRb,fNhyo6e2MYzm8):
		if rGQvqJk35uZ0atUwRb=='1': return fNhyo6e2MYzm8
		return ''
	for CQMipytPbq in range(qb3TfmuVLy9cP,0,-1):
		mmkZ9WpTIuyGRncdtEoH7gJXrD = list(CJ8HEV96Lkl0OjhADKYmRzG*'0'+bin(CQMipytPbq)[2:])[-CJ8HEV96Lkl0OjhADKYmRzG:]
		mmkZ9WpTIuyGRncdtEoH7gJXrD = reversed(mmkZ9WpTIuyGRncdtEoH7gJXrD)
		IJuVYdzmgy1AUtiKGfqWcv = map(te9shkSxKVbmr,mmkZ9WpTIuyGRncdtEoH7gJXrD,D4NFkh0vuy)
		title = ' '.join(filter(None,IJuVYdzmgy1AUtiKGfqWcv))
		if HHosl5fRdhtEDAYyP: qPmCp1Q4gRekdAH = title.decode('utf8')
		else: qPmCp1Q4gRekdAH = title
		if len(qPmCp1Q4gRekdAH)>2 and title not in tKy7SD2Ip3rJunj8aMGqwZ5Edgx:
			tKy7SD2Ip3rJunj8aMGqwZ5Edgx.append(title)
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,'',523,'','',title)
	return
def UeHiL2uY06jmAGWc4BNsDpdR3olqyx(JVCtFqbiU0W83efEKm2wg):
	if HHosl5fRdhtEDAYyP:
		JVCtFqbiU0W83efEKm2wg = JVCtFqbiU0W83efEKm2wg.decode('utf8')
		import arabic_reshaper as KEOyqt40kUroCMJpzA9Sal8mgwX
		JVCtFqbiU0W83efEKm2wg = KEOyqt40kUroCMJpzA9Sal8mgwX.ArabicReshaper().reshape(JVCtFqbiU0W83efEKm2wg)
		JVCtFqbiU0W83efEKm2wg = Y5rNeFs8E7UJqRAQ9kP6.get_display(JVCtFqbiU0W83efEKm2wg)
	import oIN2YpnkJd
	JVCtFqbiU0W83efEKm2wg = yMRXZIpKxlSkaE6iCO(P5RNJYaomg7=JVCtFqbiU0W83efEKm2wg)
	oIN2YpnkJd.szwTAdaBt4FiXO(JVCtFqbiU0W83efEKm2wg)
	return
def UleuHWgb6zKJ7cFjoZ(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',url,'',headers,'','','ELCINEMA-INDEXES_LISTS-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	kwRzflA7aeFUsCEpLXJrO = uY305abnMJ8WPDBrpC9.BeautifulSoup(BBlXpmUyhFDwNtCVAHoE,'html.parser',multi_valued_attributes=None)
	UCEFMfKbgpd = kwRzflA7aeFUsCEpLXJrO.find(class_='list-separator list-title')
	xut3LAibydXZnzkpBaKOsgew70 = UCEFMfKbgpd.find_all('a')
	items = []
	for title in xut3LAibydXZnzkpBaKOsgew70:
		name = title.text
		ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+title.get('href')
		if HHosl5fRdhtEDAYyP:
			name = name.encode('utf8')
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.encode('utf8')
		if '#' not in ELbNB92cOh5dqtpVmi40kY: items.append((name,ELbNB92cOh5dqtpVmi40kY))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for BrVNsC72UYWES4A in items:
		name,ELbNB92cOh5dqtpVmi40kY = BrVNsC72UYWES4A
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+name,ELbNB92cOh5dqtpVmi40kY,518)
	return
def dZziDAFNaE6OPycgWm1Vqpwrbh9x5(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',url,'',headers,'','','ELCINEMA-INDEXES_TITLES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	kwRzflA7aeFUsCEpLXJrO = uY305abnMJ8WPDBrpC9.BeautifulSoup(BBlXpmUyhFDwNtCVAHoE,'html.parser',multi_valued_attributes=None)
	EHDeldN7L2k19JBUqhmsuSXiwV = kwRzflA7aeFUsCEpLXJrO.find(class_='expand').find_all('tr')
	for UCEFMfKbgpd in EHDeldN7L2k19JBUqhmsuSXiwV:
		Ok4TBK0h27 = UCEFMfKbgpd.find_all('a')
		if not Ok4TBK0h27: continue
		nWO8c3IgspK67QX = UCEFMfKbgpd.find('img').get('data-src')
		name = Ok4TBK0h27[1].text
		ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+Ok4TBK0h27[1].get('href')
		JrNE09KoUVWd = UCEFMfKbgpd.find(class_='legend')
		if JrNE09KoUVWd: JrNE09KoUVWd = JrNE09KoUVWd.text
		if HHosl5fRdhtEDAYyP:
			name = name.encode('utf8')
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.encode('utf8')
			nWO8c3IgspK67QX = nWO8c3IgspK67QX.encode('utf8')
		LGdFZQvKeU52s6H0DgjN = {}
		if JrNE09KoUVWd: LGdFZQvKeU52s6H0DgjN['stars'] = JrNE09KoUVWd
		if '/work/' in ELbNB92cOh5dqtpVmi40kY:
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+name,ELbNB92cOh5dqtpVmi40kY,516,nWO8c3IgspK67QX,'',name,'',LGdFZQvKeU52s6H0DgjN)
		elif '/person/' in ELbNB92cOh5dqtpVmi40kY: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+name,ELbNB92cOh5dqtpVmi40kY,513,nWO8c3IgspK67QX,'',name,'',LGdFZQvKeU52s6H0DgjN)
	Ozfhb9uBAL7lG3qU6ri(kwRzflA7aeFUsCEpLXJrO,518)
	return
def G9ws8WoOTK63yDAVj7LZqJmMhBP(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',url,'',headers,'','','ELCINEMA-VIDEOS_LISTS-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	kwRzflA7aeFUsCEpLXJrO = uY305abnMJ8WPDBrpC9.BeautifulSoup(BBlXpmUyhFDwNtCVAHoE,'html.parser',multi_valued_attributes=None)
	xut3LAibydXZnzkpBaKOsgew70 = kwRzflA7aeFUsCEpLXJrO.find_all(class_='section-title inline')
	gI487voLsArVqW6Ffp = kwRzflA7aeFUsCEpLXJrO.find_all(class_='button green small right')
	items = zip(xut3LAibydXZnzkpBaKOsgew70,gI487voLsArVqW6Ffp)
	for title,ELbNB92cOh5dqtpVmi40kY in items:
		title = title.text
		ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY.get('href')
		if HHosl5fRdhtEDAYyP:
			title = title.encode('utf8')
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.encode('utf8')
		title = title.replace('    ',' ').replace('   ',' ').replace('  ',' ')
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,521)
	return
def CCFrN8ZvA0leJEx(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',url,'',headers,'','','ELCINEMA-VIDEOS_TITLES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	kwRzflA7aeFUsCEpLXJrO = uY305abnMJ8WPDBrpC9.BeautifulSoup(BBlXpmUyhFDwNtCVAHoE,'html.parser',multi_valued_attributes=None)
	b8xP0T19BJp3nDEoR7jHWuk = kwRzflA7aeFUsCEpLXJrO.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	EHDeldN7L2k19JBUqhmsuSXiwV = b8xP0T19BJp3nDEoR7jHWuk.find_all('li')
	for UCEFMfKbgpd in EHDeldN7L2k19JBUqhmsuSXiwV:
		title = UCEFMfKbgpd.find(class_='title').text
		ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+UCEFMfKbgpd.find('a').get('href')
		nWO8c3IgspK67QX = UCEFMfKbgpd.find('img').get('data-src')
		EDL3rwcivsR9W0pdTfygmOYUoVSb = UCEFMfKbgpd.find(class_='duration').text
		if HHosl5fRdhtEDAYyP:
			title = title.encode('utf8')
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.encode('utf8')
			nWO8c3IgspK67QX = nWO8c3IgspK67QX.encode('utf8')
			EDL3rwcivsR9W0pdTfygmOYUoVSb = EDL3rwcivsR9W0pdTfygmOYUoVSb.encode('utf8')
		EDL3rwcivsR9W0pdTfygmOYUoVSb = EDL3rwcivsR9W0pdTfygmOYUoVSb.replace('\n','').strip(' ')
		cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,522,nWO8c3IgspK67QX,EDL3rwcivsR9W0pdTfygmOYUoVSb)
	Ozfhb9uBAL7lG3qU6ri(kwRzflA7aeFUsCEpLXJrO,521)
	return
def SUfe4unWoXBNFz90xqy(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',url,'',headers,'','','ELCINEMA-PLAY-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	kwRzflA7aeFUsCEpLXJrO = uY305abnMJ8WPDBrpC9.BeautifulSoup(BBlXpmUyhFDwNtCVAHoE,'html.parser',multi_valued_attributes=None)
	ELbNB92cOh5dqtpVmi40kY = kwRzflA7aeFUsCEpLXJrO.find(class_='flex-video').find('iframe').get('src')
	if HHosl5fRdhtEDAYyP: ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.encode('utf8')
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E([ELbNB92cOh5dqtpVmi40kY],cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	search = search.replace(' ','%20')
	url = NBm2aWhPzoTpdYn+'/search/?q='+search
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',url,'',headers,'','','ELCINEMA-SEARCH-1st')
	if not WbTGMHnDysdYZ2lFA.succeeded:
		y7bJTYDq3ZmLoBOl = NBm2aWhPzoTpdYn+'/search_entity/?q='+search+'&entity=work'
		E2EhMuOLdF08Pz75jDKS14cfYNxy = NBm2aWhPzoTpdYn+'/search_entity/?q='+search+'&entity=person'
		vZx9XQFNgIby = NBm2aWhPzoTpdYn+'/search_entity/?q='+search+'&entity=video'
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث عن أعمال',y7bJTYDq3ZmLoBOl,513,'',search)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث عن أشخاص',E2EhMuOLdF08Pz75jDKS14cfYNxy,513,'',search)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث عن فيديوهات',vZx9XQFNgIby,513,'',search)
		return
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	kwRzflA7aeFUsCEpLXJrO = uY305abnMJ8WPDBrpC9.BeautifulSoup(BBlXpmUyhFDwNtCVAHoE,'html.parser',multi_valued_attributes=None)
	EHDeldN7L2k19JBUqhmsuSXiwV = kwRzflA7aeFUsCEpLXJrO.find_all(class_='section-title left')
	for UCEFMfKbgpd in EHDeldN7L2k19JBUqhmsuSXiwV:
		title = UCEFMfKbgpd.text
		if HHosl5fRdhtEDAYyP:
			title = title.encode('utf8')
		title = title.split('(',1)[0].strip(' ')
		if   'أعمال' in title: ELbNB92cOh5dqtpVmi40kY = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: ELbNB92cOh5dqtpVmi40kY = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: ELbNB92cOh5dqtpVmi40kY = url.replace('/search/','/search/video/')
		else: continue
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,513)
	return
def Eg9wreTHlMp8iD3zLShWc4kNaJG(url,text):
	global A2kRm7N8gIn1MTrWZF0Yp5e,ppwVAoqiOnjJZad
	if '/seasonals' in url:
		A2kRm7N8gIn1MTrWZF0Yp5e = ['seasonal','year','category']
		ppwVAoqiOnjJZad = ['seasonal','year','category']
	elif '/lineup' in url:
		A2kRm7N8gIn1MTrWZF0Yp5e = ['category','foreign','type']
		ppwVAoqiOnjJZad = ['category','foreign','type']
	hWJg9P6lEYT5aGDizcb(url,text)
	return
def ccBw4LkjaXAv8xDlV7UzFbrOfGqi5(url):
	url = url.split('/smartemadfilter?')[0]
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',url,'',headers,'','','ELCINEMA-GET_FILTERS_BLOCKS-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('form action="/(.*?)</form>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	nQKyI93hUT2ZGl6zimxDWe04ckj = GGvHJKP9LUxEk10Fw.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	return nQKyI93hUT2ZGl6zimxDWe04ckj
def CEK49jfZAnysJ8wIiQDpkqaOPtrzbX(UCEFMfKbgpd):
	items = GGvHJKP9LUxEk10Fw.findall('<option value="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	return items
def CRdaLbyr9tTEuIX(url):
	Z5sNMdDa6h7j0 = url.split('/smartemadfilter?')[0]
	o6ZrjEvyT8th = RfKuIXwPAiWtmyF(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def uSkUqV8Y9z2Pa5(WtVSCYeOJDGQf5sq8KZxkzyXwvBF,url):
	BnNGcaxDl0pPVdmq3j1kQu6HJEs4 = fx0tQnZhGieDkA(WtVSCYeOJDGQf5sq8KZxkzyXwvBF,'all_filters')
	XwyU6PQgprMI0 = url+'/smartemadfilter?'+BnNGcaxDl0pPVdmq3j1kQu6HJEs4
	XwyU6PQgprMI0 = CRdaLbyr9tTEuIX(XwyU6PQgprMI0)
	return XwyU6PQgprMI0
def hWJg9P6lEYT5aGDizcb(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': zTi1IvPRBr,CcMQl4P9H8SkouF7srzBYdDKUNA = '',''
	else: zTi1IvPRBr,CcMQl4P9H8SkouF7srzBYdDKUNA = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if A2kRm7N8gIn1MTrWZF0Yp5e[0]+'=' not in zTi1IvPRBr: BBskpK6cGZJ = A2kRm7N8gIn1MTrWZF0Yp5e[0]
		for umP72LtwzUTWHFAlJVyheEp5 in range(len(A2kRm7N8gIn1MTrWZF0Yp5e[0:-1])):
			if A2kRm7N8gIn1MTrWZF0Yp5e[umP72LtwzUTWHFAlJVyheEp5]+'=' in zTi1IvPRBr: BBskpK6cGZJ = A2kRm7N8gIn1MTrWZF0Yp5e[umP72LtwzUTWHFAlJVyheEp5+1]
		i2i6oT5O34GLAgyPs8DdIfV = zTi1IvPRBr+'&'+BBskpK6cGZJ+'=0'
		WtVSCYeOJDGQf5sq8KZxkzyXwvBF = CcMQl4P9H8SkouF7srzBYdDKUNA+'&'+BBskpK6cGZJ+'=0'
		sDnjCtlaGyxmr9fqK = i2i6oT5O34GLAgyPs8DdIfV.strip('&')+'___'+WtVSCYeOJDGQf5sq8KZxkzyXwvBF.strip('&')
		BnNGcaxDl0pPVdmq3j1kQu6HJEs4 = fx0tQnZhGieDkA(CcMQl4P9H8SkouF7srzBYdDKUNA,'modified_filters')
		dR2vHyAtl8pJN1 = url+'/smartemadfilter?'+BnNGcaxDl0pPVdmq3j1kQu6HJEs4
	elif type=='ALL_ITEMS_FILTER':
		QHWZwB3stnOp5SghLfl2zir6YCI = fx0tQnZhGieDkA(zTi1IvPRBr,'modified_values')
		QHWZwB3stnOp5SghLfl2zir6YCI = GhPlajzTxY8(QHWZwB3stnOp5SghLfl2zir6YCI)
		if CcMQl4P9H8SkouF7srzBYdDKUNA!='': CcMQl4P9H8SkouF7srzBYdDKUNA = fx0tQnZhGieDkA(CcMQl4P9H8SkouF7srzBYdDKUNA,'modified_filters')
		if CcMQl4P9H8SkouF7srzBYdDKUNA=='': dR2vHyAtl8pJN1 = url
		else: dR2vHyAtl8pJN1 = url+'/smartemadfilter?'+CcMQl4P9H8SkouF7srzBYdDKUNA
		dR2vHyAtl8pJN1 = CRdaLbyr9tTEuIX(dR2vHyAtl8pJN1)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'أظهار قائمة الفيديو التي تم اختيارها ',dR2vHyAtl8pJN1,511)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+' [[   '+QHWZwB3stnOp5SghLfl2zir6YCI+'   ]]',dR2vHyAtl8pJN1,511)
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nQKyI93hUT2ZGl6zimxDWe04ckj = ccBw4LkjaXAv8xDlV7UzFbrOfGqi5(url)
	dict = {}
	for name,mmRDx1Zhfjq4oFdsNey2EwCBlUOQv,UCEFMfKbgpd in nQKyI93hUT2ZGl6zimxDWe04ckj:
		name = name.replace('--','')
		items = CEK49jfZAnysJ8wIiQDpkqaOPtrzbX(UCEFMfKbgpd)
		if '=' not in dR2vHyAtl8pJN1: dR2vHyAtl8pJN1 = url
		if type=='SPECIFIED_FILTER':
			if mmRDx1Zhfjq4oFdsNey2EwCBlUOQv not in A2kRm7N8gIn1MTrWZF0Yp5e: continue
			if BBskpK6cGZJ!=mmRDx1Zhfjq4oFdsNey2EwCBlUOQv: continue
			elif len(items)<2:
				if mmRDx1Zhfjq4oFdsNey2EwCBlUOQv==A2kRm7N8gIn1MTrWZF0Yp5e[-1]:
					url = CRdaLbyr9tTEuIX(url)
					hW91LE0xpvtXdIBs(url)
				else: hWJg9P6lEYT5aGDizcb(dR2vHyAtl8pJN1,'SPECIFIED_FILTER___'+sDnjCtlaGyxmr9fqK)
				return
			else:
				dR2vHyAtl8pJN1 = CRdaLbyr9tTEuIX(dR2vHyAtl8pJN1)
				if mmRDx1Zhfjq4oFdsNey2EwCBlUOQv==A2kRm7N8gIn1MTrWZF0Yp5e[-1]: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع',dR2vHyAtl8pJN1,511)
				else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع',dR2vHyAtl8pJN1,515,'','',sDnjCtlaGyxmr9fqK)
		elif type=='ALL_ITEMS_FILTER':
			if mmRDx1Zhfjq4oFdsNey2EwCBlUOQv not in ppwVAoqiOnjJZad: continue
			i2i6oT5O34GLAgyPs8DdIfV = zTi1IvPRBr+'&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'=0'
			WtVSCYeOJDGQf5sq8KZxkzyXwvBF = CcMQl4P9H8SkouF7srzBYdDKUNA+'&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'=0'
			sDnjCtlaGyxmr9fqK = i2i6oT5O34GLAgyPs8DdIfV+'___'+WtVSCYeOJDGQf5sq8KZxkzyXwvBF
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع: '+name,dR2vHyAtl8pJN1,514,'','',sDnjCtlaGyxmr9fqK)
		dict[mmRDx1Zhfjq4oFdsNey2EwCBlUOQv] = {}
		for hieW1zRUG5w9AykJjv0X,RHb9zAjcuTIoyZ0aDgS1pQYmUs8 in items:
			if RHb9zAjcuTIoyZ0aDgS1pQYmUs8 in DDXTwbRBaj3e2rSsPQ: continue
			if 'مصنفات أخرى' in RHb9zAjcuTIoyZ0aDgS1pQYmUs8: continue
			if 'الكل' in RHb9zAjcuTIoyZ0aDgS1pQYmUs8: continue
			if 'اللغة' in RHb9zAjcuTIoyZ0aDgS1pQYmUs8: continue
			RHb9zAjcuTIoyZ0aDgS1pQYmUs8 = RHb9zAjcuTIoyZ0aDgS1pQYmUs8.replace('قائمة ','')
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[mmRDx1Zhfjq4oFdsNey2EwCBlUOQv][hieW1zRUG5w9AykJjv0X] = RHb9zAjcuTIoyZ0aDgS1pQYmUs8
			i2i6oT5O34GLAgyPs8DdIfV = zTi1IvPRBr+'&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'='+RHb9zAjcuTIoyZ0aDgS1pQYmUs8
			WtVSCYeOJDGQf5sq8KZxkzyXwvBF = CcMQl4P9H8SkouF7srzBYdDKUNA+'&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'='+hieW1zRUG5w9AykJjv0X
			KPcDQTE3e8duMHO6Lbgo1n = i2i6oT5O34GLAgyPs8DdIfV+'___'+WtVSCYeOJDGQf5sq8KZxkzyXwvBF
			if name: title = RHb9zAjcuTIoyZ0aDgS1pQYmUs8+' :'+name
			else: title = RHb9zAjcuTIoyZ0aDgS1pQYmUs8
			if type=='ALL_ITEMS_FILTER': cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,514,'','',KPcDQTE3e8duMHO6Lbgo1n)
			elif type=='SPECIFIED_FILTER' and A2kRm7N8gIn1MTrWZF0Yp5e[-2]+'=' in zTi1IvPRBr:
				XwyU6PQgprMI0 = uSkUqV8Y9z2Pa5(WtVSCYeOJDGQf5sq8KZxkzyXwvBF,url)
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,XwyU6PQgprMI0,511)
			else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,515,'','',KPcDQTE3e8duMHO6Lbgo1n)
	return
def fx0tQnZhGieDkA(FZj067Q2PlC8EsG9c5yiWpzNRq,mode):
	FZj067Q2PlC8EsG9c5yiWpzNRq = FZj067Q2PlC8EsG9c5yiWpzNRq.replace('=&','=0&')
	FZj067Q2PlC8EsG9c5yiWpzNRq = FZj067Q2PlC8EsG9c5yiWpzNRq.strip('&')
	HG4gSjopqQwsPeivrcmn = {}
	if '=' in FZj067Q2PlC8EsG9c5yiWpzNRq:
		items = FZj067Q2PlC8EsG9c5yiWpzNRq.split('&')
		for BrVNsC72UYWES4A in items:
			RRSq2Qx0MfkFHLt,hieW1zRUG5w9AykJjv0X = BrVNsC72UYWES4A.split('=')
			HG4gSjopqQwsPeivrcmn[RRSq2Qx0MfkFHLt] = hieW1zRUG5w9AykJjv0X
	BbgO8pxWfVA41KGzed = ''
	for key in ppwVAoqiOnjJZad:
		if key in list(HG4gSjopqQwsPeivrcmn.keys()): hieW1zRUG5w9AykJjv0X = HG4gSjopqQwsPeivrcmn[key]
		else: hieW1zRUG5w9AykJjv0X = '0'
		if '%' not in hieW1zRUG5w9AykJjv0X: hieW1zRUG5w9AykJjv0X = mGfdCk4Hyclg9RjD(hieW1zRUG5w9AykJjv0X)
		if mode=='modified_values' and hieW1zRUG5w9AykJjv0X!='0': BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed+' + '+hieW1zRUG5w9AykJjv0X
		elif mode=='modified_filters' and hieW1zRUG5w9AykJjv0X!='0': BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed+'&'+key+'='+hieW1zRUG5w9AykJjv0X
		elif mode=='all_filters': BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed+'&'+key+'='+hieW1zRUG5w9AykJjv0X
	BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed.strip(' + ')
	BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed.strip('&')
	BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed.replace('=0','=')
	return BbgO8pxWfVA41KGzed
A2kRm7N8gIn1MTrWZF0Yp5e = []
ppwVAoqiOnjJZad = []
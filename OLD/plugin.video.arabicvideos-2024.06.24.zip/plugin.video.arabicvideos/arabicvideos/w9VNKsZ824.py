# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'SHAHID4U'
mmDwMlfoHtG5XT19VLIWqCR8i = '_SH4_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
DDXTwbRBaj3e2rSsPQ = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==110: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==111: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,text)
	elif mode==112: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==113: zpXG3Ky6ou8ndWHkb4 = hWPvGlXZ5arzV7(url,True)
	elif mode==114: zpXG3Ky6ou8ndWHkb4 = hWJg9P6lEYT5aGDizcb(url,'FULL_FILTER___'+text)
	elif mode==115: zpXG3Ky6ou8ndWHkb4 = hWJg9P6lEYT5aGDizcb(url,'DEFINED_FILTER___'+text)
	elif mode==116: zpXG3Ky6ou8ndWHkb4 = hWPvGlXZ5arzV7(url,False)
	elif mode==119: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	headers = {'User-Agent':Y8Y6b7aLSUKjdE1Ae(True)}
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',NBm2aWhPzoTpdYn,'',headers,'','','SHAHID4U-MENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(WbTGMHnDysdYZ2lFA.url,'url')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',119,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فلتر محدد',aPNBvIyexc053gAsSw1QoRMUYfb,115)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فلتر كامل',aPNBvIyexc053gAsSw1QoRMUYfb,114)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'المميزة',aPNBvIyexc053gAsSw1QoRMUYfb,111,'','','featured')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('simple-filter(.*?)adv-filter',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not EeQqAGc0W5r6nlBbChwfZL:
		aHKzv76JCVnprbY8w('','','موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for filter,VFqpJjRySZvgi,title in items:
			url = aPNBvIyexc053gAsSw1QoRMUYfb+filter
			cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,url,111,VFqpJjRySZvgi,'',filter)
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="dropdown"(.*?)<script>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			title = title.replace('\n','').replace('\r','').strip(' ')
			if title in DDXTwbRBaj3e2rSsPQ: continue
			if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = aPNBvIyexc053gAsSw1QoRMUYfb+ELbNB92cOh5dqtpVmi40kY
			if 'netflix' in ELbNB92cOh5dqtpVmi40kY: title = 'نيتفلكس'
			cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,111)
	return BBlXpmUyhFDwNtCVAHoE
def xoiXMWjJC3pnQqurIGPkRSl8e(url,nKuYjzcZEXky6Va5UdoJfH1xqstL='',WbTGMHnDysdYZ2lFA=''):
	headers = {'User-Agent':Y8Y6b7aLSUKjdE1Ae(True)}
	if not WbTGMHnDysdYZ2lFA: WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'',headers,'','','SHAHID4U-TITLES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL,items,IcJOGsq3Ff7EmkiLx = [],[],[]
	if nKuYjzcZEXky6Va5UdoJfH1xqstL=='featured': EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('glide__slides(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	else: EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('shows-container(.*?)pagination',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not EeQqAGc0W5r6nlBbChwfZL: return
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	if not items: items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)</h4>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	Dq0X5cvgdjwh6LbnUkETFBR8 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
		if 'WWE' in title: continue
		if 'javascript' in ELbNB92cOh5dqtpVmi40kY: continue
		ELbNB92cOh5dqtpVmi40kY = GhPlajzTxY8(ELbNB92cOh5dqtpVmi40kY).strip('/')
		title = DwNC3gEonizsB6a0v1F(title)
		title = title.strip(' ')
		qUGxSK2VwsiBAdkDZnJ605vQeg = GGvHJKP9LUxEk10Fw.findall('(.*?) الحلقة \d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
		if '/film/' in ELbNB92cOh5dqtpVmi40kY or 'فيلم' in ELbNB92cOh5dqtpVmi40kY or any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in Dq0X5cvgdjwh6LbnUkETFBR8):
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,112,VFqpJjRySZvgi)
		elif qUGxSK2VwsiBAdkDZnJ605vQeg and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + qUGxSK2VwsiBAdkDZnJ605vQeg[0]
			if title not in IcJOGsq3Ff7EmkiLx:
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,113,VFqpJjRySZvgi)
				IcJOGsq3Ff7EmkiLx.append(title)
		elif '/actor/' in ELbNB92cOh5dqtpVmi40kY:
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,111,VFqpJjRySZvgi)
		elif '/series/' in ELbNB92cOh5dqtpVmi40kY and '/list' not in url:
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'/list'
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,111,VFqpJjRySZvgi)
		elif '/list' in url and 'حلقة' in title:
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,112,VFqpJjRySZvgi)
		else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,113,VFqpJjRySZvgi)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"pagination"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		if nKuYjzcZEXky6Va5UdoJfH1xqstL!='search': items = GGvHJKP9LUxEk10Fw.findall('(updateQuery).*?>(.+?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		else: items = GGvHJKP9LUxEk10Fw.findall('<li>.*?href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if 'page=' in url: url = url.split('page=',1)[0][:-1]
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			title = title.replace('\n','').replace('\r','')
			title = title.strip(' ')
			if nKuYjzcZEXky6Va5UdoJfH1xqstL!='search':
				if '?' in url: ELbNB92cOh5dqtpVmi40kY = url+'&page='+title
				else: ELbNB92cOh5dqtpVmi40kY = url+'?page='+title
			title = DwNC3gEonizsB6a0v1F(title)
			if title: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,111,'','',nKuYjzcZEXky6Va5UdoJfH1xqstL)
	return
def hWPvGlXZ5arzV7(url,x0CK8zQSXL):
	headers = {'User-Agent':Y8Y6b7aLSUKjdE1Ae(True)}
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'',headers,'','','SHAHID4U-EPISODES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('items d-flex(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if len(EeQqAGc0W5r6nlBbChwfZL)>1:
		if '/season/' in EeQqAGc0W5r6nlBbChwfZL[0]: tt0PDNvYRduaiJSh8,kxoVRpfCEMyW15BFQu4n7G2 = EeQqAGc0W5r6nlBbChwfZL[0],EeQqAGc0W5r6nlBbChwfZL[1]
		else: tt0PDNvYRduaiJSh8,kxoVRpfCEMyW15BFQu4n7G2 = EeQqAGc0W5r6nlBbChwfZL[1],EeQqAGc0W5r6nlBbChwfZL[0]
	else: tt0PDNvYRduaiJSh8,kxoVRpfCEMyW15BFQu4n7G2 = EeQqAGc0W5r6nlBbChwfZL[0],EeQqAGc0W5r6nlBbChwfZL[0]
	for CQMipytPbq in range(2):
		if x0CK8zQSXL: mode,type,UCEFMfKbgpd = 116,'folder',tt0PDNvYRduaiJSh8
		else: mode,type,UCEFMfKbgpd = 112,'video',kxoVRpfCEMyW15BFQu4n7G2
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if x0CK8zQSXL and len(items)<2:
			x0CK8zQSXL = False
			continue
		for ELbNB92cOh5dqtpVmi40kY,now0UFQXvPyWA8TNluJ53M,qPmCp1Q4gRekdAH in items:
			title = now0UFQXvPyWA8TNluJ53M+' '+qPmCp1Q4gRekdAH
			cd0aGwCPExbFU5pYNu8r(type,mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,mode)
		break
	if not items and '/episodes' in BBlXpmUyhFDwNtCVAHoE:
		egvf3lubILM5pSoCqrN1K0 = GGvHJKP9LUxEk10Fw.findall('class="breadcrumb"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if egvf3lubILM5pSoCqrN1K0:
			UCEFMfKbgpd = egvf3lubILM5pSoCqrN1K0[0]
			gI487voLsArVqW6Ffp = GGvHJKP9LUxEk10Fw.findall('href="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			if len(gI487voLsArVqW6Ffp)>2:
				ELbNB92cOh5dqtpVmi40kY = gI487voLsArVqW6Ffp[2]+'list'
				xoiXMWjJC3pnQqurIGPkRSl8e(ELbNB92cOh5dqtpVmi40kY)
	return
def SUfe4unWoXBNFz90xqy(url):
	headers = {'User-Agent':Y8Y6b7aLSUKjdE1Ae(True)}
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',url,'',headers,'','','SHAHID4U-PLAY-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="actions(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not EeQqAGc0W5r6nlBbChwfZL: return
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	gI487voLsArVqW6Ffp = GGvHJKP9LUxEk10Fw.findall('href="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	Whtb7AU8zJH3G9YSQnK0Bag = '/watch/' in UCEFMfKbgpd
	download = '/download/' in UCEFMfKbgpd
	if   Whtb7AU8zJH3G9YSQnK0Bag and not download: TGWDgzmcZqdnEHa5vX8S2,ZZU4LuPeAXij8F = gI487voLsArVqW6Ffp[0],''
	elif not Whtb7AU8zJH3G9YSQnK0Bag and download: TGWDgzmcZqdnEHa5vX8S2,ZZU4LuPeAXij8F = '',gI487voLsArVqW6Ffp[0]
	elif Whtb7AU8zJH3G9YSQnK0Bag and download: TGWDgzmcZqdnEHa5vX8S2,ZZU4LuPeAXij8F = gI487voLsArVqW6Ffp[0],gI487voLsArVqW6Ffp[1]
	else: TGWDgzmcZqdnEHa5vX8S2,ZZU4LuPeAXij8F = '',''
	zzvBg3ShiamAZ = []
	if Whtb7AU8zJH3G9YSQnK0Bag:
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',TGWDgzmcZqdnEHa5vX8S2,'',headers,'','','SHAHID4U-PLAY-2nd')
		X3in5vNhqwWEG2TafmVCrFbSYDxjoK = WbTGMHnDysdYZ2lFA.content
		uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb = GGvHJKP9LUxEk10Fw.findall('let servers(.*?)player',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.IGNORECASE)
		if uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb:
			jCxVUBZwAdOtIHM81rTJYiX3 = uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb[0]
			GzpIUylJrXRteaKPiNDLHuScmbgj = GGvHJKP9LUxEk10Fw.findall('"name":"(.*?)".*?"url":"(.*?)"',jCxVUBZwAdOtIHM81rTJYiX3,GGvHJKP9LUxEk10Fw.DOTALL)
			for title,ELbNB92cOh5dqtpVmi40kY in GzpIUylJrXRteaKPiNDLHuScmbgj:
				ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.replace('\\/','/')
				ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named='+title+'__watch'
				zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	if download:
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',ZZU4LuPeAXij8F,'',headers,'','','SHAHID4U-PLAY-3rd')
		X3in5vNhqwWEG2TafmVCrFbSYDxjoK = WbTGMHnDysdYZ2lFA.content
		uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb = GGvHJKP9LUxEk10Fw.findall('"servers"(.*?)info-container',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
		if uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb:
			jCxVUBZwAdOtIHM81rTJYiX3 = uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb[0]
			GzpIUylJrXRteaKPiNDLHuScmbgj = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',jCxVUBZwAdOtIHM81rTJYiX3,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,title,dDZQSEGRTo9g85x1C in GzpIUylJrXRteaKPiNDLHuScmbgj:
				ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named='+title+'__download'+'____'+dDZQSEGRTo9g85x1C
				zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(zzvBg3ShiamAZ,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if not search:
		search = yMRXZIpKxlSkaE6iCO()
		if not search: return
	search = search.replace(' ','+')
	url = NBm2aWhPzoTpdYn+'/search?s='+search
	xoiXMWjJC3pnQqurIGPkRSl8e(url,'search')
	return
def ccBw4LkjaXAv8xDlV7UzFbrOfGqi5(url):
	url = url.split('/smartemadfilter?')[0]
	headers = {'User-Agent':Y8Y6b7aLSUKjdE1Ae(True)}
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',url,'',headers,'','','SHAHID4U-GET_FILTERS_BLOCKS-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	nQKyI93hUT2ZGl6zimxDWe04ckj = []
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('adv-filter(.*?)shows-container',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		nQKyI93hUT2ZGl6zimxDWe04ckj = GGvHJKP9LUxEk10Fw.findall('''updateQuery\('(.*?)'.*?value="">(.*?)<(.*?)</select''',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		P5tbhRVEZBuY1QKgcpCv,YUgMTmWlyuxAkbqCwrvS89h6Ddnta,EHDeldN7L2k19JBUqhmsuSXiwV = zip(*nQKyI93hUT2ZGl6zimxDWe04ckj)
		nQKyI93hUT2ZGl6zimxDWe04ckj = zip(YUgMTmWlyuxAkbqCwrvS89h6Ddnta,P5tbhRVEZBuY1QKgcpCv,EHDeldN7L2k19JBUqhmsuSXiwV)
	return nQKyI93hUT2ZGl6zimxDWe04ckj
def CEK49jfZAnysJ8wIiQDpkqaOPtrzbX(UCEFMfKbgpd):
	items = GGvHJKP9LUxEk10Fw.findall('value="(.*?)".*?>\s*(.*?)\s*<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	return items
def SfxkV5IQZzseREyJW(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	Z5sNMdDa6h7j0 = url.split('/smartemadfilter?')[0]
	o6ZrjEvyT8th = RfKuIXwPAiWtmyF(url,'url')
	url = url.replace(Z5sNMdDa6h7j0,o6ZrjEvyT8th)
	url = url.replace('/smartemadfilter?','/?')
	return url
FA0yRhHtTKpqkfYL9u73 = ['quality','year','genre','category']
xqt5DurYchma = ['category','genre','year']
def hWJg9P6lEYT5aGDizcb(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': zTi1IvPRBr,CcMQl4P9H8SkouF7srzBYdDKUNA = '',''
	else: zTi1IvPRBr,CcMQl4P9H8SkouF7srzBYdDKUNA = filter.split('___')
	if type=='DEFINED_FILTER':
		if xqt5DurYchma[0]+'=' not in zTi1IvPRBr: BBskpK6cGZJ = xqt5DurYchma[0]
		for umP72LtwzUTWHFAlJVyheEp5 in range(len(xqt5DurYchma[0:-1])):
			if xqt5DurYchma[umP72LtwzUTWHFAlJVyheEp5]+'=' in zTi1IvPRBr: BBskpK6cGZJ = xqt5DurYchma[umP72LtwzUTWHFAlJVyheEp5+1]
		i2i6oT5O34GLAgyPs8DdIfV = zTi1IvPRBr+'&'+BBskpK6cGZJ+'=0'
		WtVSCYeOJDGQf5sq8KZxkzyXwvBF = CcMQl4P9H8SkouF7srzBYdDKUNA+'&'+BBskpK6cGZJ+'=0'
		sDnjCtlaGyxmr9fqK = i2i6oT5O34GLAgyPs8DdIfV.strip('&')+'___'+WtVSCYeOJDGQf5sq8KZxkzyXwvBF.strip('&')
		BnNGcaxDl0pPVdmq3j1kQu6HJEs4 = fx0tQnZhGieDkA(CcMQl4P9H8SkouF7srzBYdDKUNA,'modified_filters')
		dR2vHyAtl8pJN1 = url+'/smartemadfilter?'+BnNGcaxDl0pPVdmq3j1kQu6HJEs4
	elif type=='FULL_FILTER':
		QHWZwB3stnOp5SghLfl2zir6YCI = fx0tQnZhGieDkA(zTi1IvPRBr,'modified_values')
		QHWZwB3stnOp5SghLfl2zir6YCI = GhPlajzTxY8(QHWZwB3stnOp5SghLfl2zir6YCI)
		if CcMQl4P9H8SkouF7srzBYdDKUNA!='': CcMQl4P9H8SkouF7srzBYdDKUNA = fx0tQnZhGieDkA(CcMQl4P9H8SkouF7srzBYdDKUNA,'modified_filters')
		if CcMQl4P9H8SkouF7srzBYdDKUNA=='': dR2vHyAtl8pJN1 = url
		else: dR2vHyAtl8pJN1 = url+'/smartemadfilter?'+CcMQl4P9H8SkouF7srzBYdDKUNA
		XwyU6PQgprMI0 = SfxkV5IQZzseREyJW(dR2vHyAtl8pJN1)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'أظهار قائمة الفيديو التي تم اختيارها ',XwyU6PQgprMI0,111)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+' [[   '+QHWZwB3stnOp5SghLfl2zir6YCI+'   ]]',XwyU6PQgprMI0,111)
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nQKyI93hUT2ZGl6zimxDWe04ckj = ccBw4LkjaXAv8xDlV7UzFbrOfGqi5(url)
	dict = {}
	for name,mmRDx1Zhfjq4oFdsNey2EwCBlUOQv,UCEFMfKbgpd in nQKyI93hUT2ZGl6zimxDWe04ckj:
		name = name.replace('كل ','')
		items = CEK49jfZAnysJ8wIiQDpkqaOPtrzbX(UCEFMfKbgpd)
		if '=' not in dR2vHyAtl8pJN1: dR2vHyAtl8pJN1 = url
		if type=='DEFINED_FILTER':
			if BBskpK6cGZJ!=mmRDx1Zhfjq4oFdsNey2EwCBlUOQv: continue
			elif len(items)<2:
				if mmRDx1Zhfjq4oFdsNey2EwCBlUOQv==xqt5DurYchma[-1]:
					XwyU6PQgprMI0 = SfxkV5IQZzseREyJW(dR2vHyAtl8pJN1)
					xoiXMWjJC3pnQqurIGPkRSl8e(XwyU6PQgprMI0)
				else: hWJg9P6lEYT5aGDizcb(dR2vHyAtl8pJN1,'DEFINED_FILTER___'+sDnjCtlaGyxmr9fqK)
				return
			else:
				if mmRDx1Zhfjq4oFdsNey2EwCBlUOQv==xqt5DurYchma[-1]:
					XwyU6PQgprMI0 = SfxkV5IQZzseREyJW(dR2vHyAtl8pJN1)
					cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع',XwyU6PQgprMI0,111)
				else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع',dR2vHyAtl8pJN1,115,'','',sDnjCtlaGyxmr9fqK)
		elif type=='FULL_FILTER':
			i2i6oT5O34GLAgyPs8DdIfV = zTi1IvPRBr+'&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'=0'
			WtVSCYeOJDGQf5sq8KZxkzyXwvBF = CcMQl4P9H8SkouF7srzBYdDKUNA+'&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'=0'
			sDnjCtlaGyxmr9fqK = i2i6oT5O34GLAgyPs8DdIfV+'___'+WtVSCYeOJDGQf5sq8KZxkzyXwvBF
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع :'+name,dR2vHyAtl8pJN1,114,'','',sDnjCtlaGyxmr9fqK)
		dict[mmRDx1Zhfjq4oFdsNey2EwCBlUOQv] = {}
		for hieW1zRUG5w9AykJjv0X,RHb9zAjcuTIoyZ0aDgS1pQYmUs8 in items:
			if hieW1zRUG5w9AykJjv0X=='196533': RHb9zAjcuTIoyZ0aDgS1pQYmUs8 = 'أفلام نيتفلكس'
			elif hieW1zRUG5w9AykJjv0X=='196531': RHb9zAjcuTIoyZ0aDgS1pQYmUs8 = 'مسلسلات نيتفلكس'
			if RHb9zAjcuTIoyZ0aDgS1pQYmUs8 in DDXTwbRBaj3e2rSsPQ: continue
			dict[mmRDx1Zhfjq4oFdsNey2EwCBlUOQv][hieW1zRUG5w9AykJjv0X] = RHb9zAjcuTIoyZ0aDgS1pQYmUs8
			i2i6oT5O34GLAgyPs8DdIfV = zTi1IvPRBr+'&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'='+RHb9zAjcuTIoyZ0aDgS1pQYmUs8
			WtVSCYeOJDGQf5sq8KZxkzyXwvBF = CcMQl4P9H8SkouF7srzBYdDKUNA+'&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'='+hieW1zRUG5w9AykJjv0X
			KPcDQTE3e8duMHO6Lbgo1n = i2i6oT5O34GLAgyPs8DdIfV+'___'+WtVSCYeOJDGQf5sq8KZxkzyXwvBF
			title = RHb9zAjcuTIoyZ0aDgS1pQYmUs8+' :'#+dict[mmRDx1Zhfjq4oFdsNey2EwCBlUOQv]['0']
			title = RHb9zAjcuTIoyZ0aDgS1pQYmUs8+' :'+name
			if type=='FULL_FILTER': cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,114,'','',KPcDQTE3e8duMHO6Lbgo1n)
			elif type=='DEFINED_FILTER' and xqt5DurYchma[-2]+'=' in zTi1IvPRBr:
				BnNGcaxDl0pPVdmq3j1kQu6HJEs4 = fx0tQnZhGieDkA(WtVSCYeOJDGQf5sq8KZxkzyXwvBF,'modified_filters')
				dR2vHyAtl8pJN1 = url+'/smartemadfilter?'+BnNGcaxDl0pPVdmq3j1kQu6HJEs4
				XwyU6PQgprMI0 = SfxkV5IQZzseREyJW(dR2vHyAtl8pJN1)
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,XwyU6PQgprMI0,111)
			else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,115,'','',KPcDQTE3e8duMHO6Lbgo1n)
	return
def fx0tQnZhGieDkA(FZj067Q2PlC8EsG9c5yiWpzNRq,mode):
	FZj067Q2PlC8EsG9c5yiWpzNRq = FZj067Q2PlC8EsG9c5yiWpzNRq.replace('=&','=0&')
	FZj067Q2PlC8EsG9c5yiWpzNRq = FZj067Q2PlC8EsG9c5yiWpzNRq.strip('&')
	HG4gSjopqQwsPeivrcmn = {}
	if '=' in FZj067Q2PlC8EsG9c5yiWpzNRq:
		items = FZj067Q2PlC8EsG9c5yiWpzNRq.split('&')
		for BrVNsC72UYWES4A in items:
			RRSq2Qx0MfkFHLt,hieW1zRUG5w9AykJjv0X = BrVNsC72UYWES4A.split('=')
			HG4gSjopqQwsPeivrcmn[RRSq2Qx0MfkFHLt] = hieW1zRUG5w9AykJjv0X
	BbgO8pxWfVA41KGzed = ''
	for key in FA0yRhHtTKpqkfYL9u73:
		if key in list(HG4gSjopqQwsPeivrcmn.keys()): hieW1zRUG5w9AykJjv0X = HG4gSjopqQwsPeivrcmn[key]
		else: hieW1zRUG5w9AykJjv0X = '0'
		if '%' not in hieW1zRUG5w9AykJjv0X: hieW1zRUG5w9AykJjv0X = mGfdCk4Hyclg9RjD(hieW1zRUG5w9AykJjv0X)
		if mode=='modified_values' and hieW1zRUG5w9AykJjv0X!='0': BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed+' + '+hieW1zRUG5w9AykJjv0X
		elif mode=='modified_filters' and hieW1zRUG5w9AykJjv0X!='0': BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed+'&'+key+'='+hieW1zRUG5w9AykJjv0X
		elif mode=='all': BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed+'&'+key+'='+hieW1zRUG5w9AykJjv0X
	BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed.strip(' + ')
	BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed.strip('&')
	BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed.replace('=0','=')
	return BbgO8pxWfVA41KGzed
# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'LIVETV'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT['PYTHON'][0]
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url):
	if   mode==100: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==101: zpXG3Ky6ou8ndWHkb4 = L4L0TUsN51taeljfc('0',True)
	elif mode==102: zpXG3Ky6ou8ndWHkb4 = L4L0TUsN51taeljfc('1',True)
	elif mode==103: zpXG3Ky6ou8ndWHkb4 = L4L0TUsN51taeljfc('2',True)
	elif mode==104: zpXG3Ky6ou8ndWHkb4 = L4L0TUsN51taeljfc('3',True)
	elif mode==105: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==106: zpXG3Ky6ou8ndWHkb4 = L4L0TUsN51taeljfc('4',True)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	cd0aGwCPExbFU5pYNu8r('folder','_M3U_'+'قوائم فيديوهات M3U','',762)
	cd0aGwCPExbFU5pYNu8r('folder','_IPT_'+'قوائم فيديوهات IPTV','',761)
	cd0aGwCPExbFU5pYNu8r('folder','_TV0_'+'قنوات من مواقعها الأصلية','',101)
	cd0aGwCPExbFU5pYNu8r('folder','_TV4_'+'قنوات مختارة من يوتيوب','',106)
	cd0aGwCPExbFU5pYNu8r('folder','_YUT_'+'قنوات عربية من يوتيوب','',147)
	cd0aGwCPExbFU5pYNu8r('folder','_YUT_'+'قنوات أجنبية من يوتيوب','',148)
	cd0aGwCPExbFU5pYNu8r('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ','',28)
	cd0aGwCPExbFU5pYNu8r('live','_MRF_'+'قناة المعارف من موقعهم','',41)
	cd0aGwCPExbFU5pYNu8r('live','_PNT_'+'قناة هلا من موقع بانيت','',38)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder','_TV1_'+'قنوات تلفزيونية عامة','',102)
	cd0aGwCPExbFU5pYNu8r('folder','_TV2_'+'قنوات تلفزيونية خاصة','',103)
	cd0aGwCPExbFU5pYNu8r('folder','_TV3_'+'قنوات تلفزيونية للفحص','',104)
	return
def L4L0TUsN51taeljfc(qERDVNWvZzbf9O8sXCxi,showDialogs=True):
	mmDwMlfoHtG5XT19VLIWqCR8i = '_TV'+qERDVNWvZzbf9O8sXCxi+'_'
	exOIZnGECcR2p3WV4TPY06BNDo7 = PW2xo0Kq3Tcprj9Ck(32)
	vpWXJDC4lTByaqcn56OFwUmieV = {'id':'','user':exOIZnGECcR2p3WV4TPY06BNDo7,'function':'list','menu':qERDVNWvZzbf9O8sXCxi}
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'POST',NBm2aWhPzoTpdYn,vpWXJDC4lTByaqcn56OFwUmieV,'','','','LIVETV-ITEMS-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	items = GGvHJKP9LUxEk10Fw.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if items:
		for umP72LtwzUTWHFAlJVyheEp5 in range(len(items)):
			name = items[umP72LtwzUTWHFAlJVyheEp5][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[umP72LtwzUTWHFAlJVyheEp5] = items[umP72LtwzUTWHFAlJVyheEp5][0],items[umP72LtwzUTWHFAlJVyheEp5][1],items[umP72LtwzUTWHFAlJVyheEp5][2],name,items[umP72LtwzUTWHFAlJVyheEp5][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for hayXA4TiLlPxcVSIoK2,C83UXWf15zdwLA0,jayps2bqRW6CEVl9IY8LdB5e,name,VFqpJjRySZvgi in items:
			if '#' in hayXA4TiLlPxcVSIoK2: continue
			if hayXA4TiLlPxcVSIoK2!='URL': name = name+'[COLOR FFC89008]   '+hayXA4TiLlPxcVSIoK2+'[/COLOR]'
			url = hayXA4TiLlPxcVSIoK2+';;'+C83UXWf15zdwLA0+';;'+jayps2bqRW6CEVl9IY8LdB5e+';;'+qERDVNWvZzbf9O8sXCxi
			cd0aGwCPExbFU5pYNu8r('live',mmDwMlfoHtG5XT19VLIWqCR8i+''+name,url,105,VFqpJjRySZvgi)
	else:
		if showDialogs: cd0aGwCPExbFU5pYNu8r('link',mmDwMlfoHtG5XT19VLIWqCR8i+'هذه الخدمة مخصصة للمبرمج فقط','',9999)
	return
def SUfe4unWoXBNFz90xqy(id):
	hayXA4TiLlPxcVSIoK2,C83UXWf15zdwLA0,jayps2bqRW6CEVl9IY8LdB5e,qERDVNWvZzbf9O8sXCxi = id.split(';;')
	url = ''
	exOIZnGECcR2p3WV4TPY06BNDo7 = PW2xo0Kq3Tcprj9Ck(32)
	if hayXA4TiLlPxcVSIoK2=='URL': url = jayps2bqRW6CEVl9IY8LdB5e
	elif hayXA4TiLlPxcVSIoK2=='YOUTUBE':
		url = oSVpce1UQYrDqhuM6PT['YOUTUBE'][0]+'/watch?v='+jayps2bqRW6CEVl9IY8LdB5e
		import XXPcDGxLdW
		XXPcDGxLdW.YguVs5RJFwDK6X8E([url],cTJphS1nFz5EUgNWm86C,'live',url)
		return
	elif hayXA4TiLlPxcVSIoK2=='GA':
		vpWXJDC4lTByaqcn56OFwUmieV = { 'id' : '', 'user' : exOIZnGECcR2p3WV4TPY06BNDo7 , 'function' : 'playGA1' , 'menu' : '' }
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'GET',NBm2aWhPzoTpdYn,vpWXJDC4lTByaqcn56OFwUmieV,'',False,'','LIVETV-PLAY-1st')
		if not WbTGMHnDysdYZ2lFA.succeeded:
			aHKzv76JCVnprbY8w('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		cookies = WbTGMHnDysdYZ2lFA.cookies
		BPCp38Kav4wNhmG2gktuTi0yFS7lrM = cookies['ASP.NET_SessionId']
		url = WbTGMHnDysdYZ2lFA.headers['Location']
		vpWXJDC4lTByaqcn56OFwUmieV = { 'id' : jayps2bqRW6CEVl9IY8LdB5e , 'user' : exOIZnGECcR2p3WV4TPY06BNDo7 , 'function' : 'playGA2' , 'menu' : '' }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+BPCp38Kav4wNhmG2gktuTi0yFS7lrM }
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'GET',NBm2aWhPzoTpdYn,vpWXJDC4lTByaqcn56OFwUmieV,headers,'','','LIVETV-PLAY-2nd')
		if not WbTGMHnDysdYZ2lFA.succeeded:
			aHKzv76JCVnprbY8w('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		url = GGvHJKP9LUxEk10Fw.findall('resp":"(http.*?m3u8)(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		ELbNB92cOh5dqtpVmi40kY = url[0][0]
		AApkbKmuNhY14teiI2UMP7wQEf = url[0][1]
		CWNyHpOasoZTJBt4Rexjg9bGA = 'http://38.'+C83UXWf15zdwLA0+'777/'+jayps2bqRW6CEVl9IY8LdB5e+'_HD.m3u8'+AApkbKmuNhY14teiI2UMP7wQEf
		oLKPVjQeXHFaZiu0ycg5YsnpJG = CWNyHpOasoZTJBt4Rexjg9bGA.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		QYhIAPMdiNt8juCJX06EF = CWNyHpOasoZTJBt4Rexjg9bGA.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		eyUmvNFiYsE = ['HD','SD1','SD2']
		zzvBg3ShiamAZ = [CWNyHpOasoZTJBt4Rexjg9bGA,oLKPVjQeXHFaZiu0ycg5YsnpJG,QYhIAPMdiNt8juCJX06EF]
		z0jyetbQwKrIclL9vJW = 0
		if z0jyetbQwKrIclL9vJW == -1: return
		else: url = zzvBg3ShiamAZ[z0jyetbQwKrIclL9vJW]
	elif hayXA4TiLlPxcVSIoK2=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		vpWXJDC4lTByaqcn56OFwUmieV = { 'id' : jayps2bqRW6CEVl9IY8LdB5e , 'user' : exOIZnGECcR2p3WV4TPY06BNDo7 , 'function' : 'playNT' , 'menu' : qERDVNWvZzbf9O8sXCxi }
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'POST', NBm2aWhPzoTpdYn, vpWXJDC4lTByaqcn56OFwUmieV, headers, False,'','LIVETV-PLAY-3rd')
		if not WbTGMHnDysdYZ2lFA.succeeded:
			aHKzv76JCVnprbY8w('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		url = WbTGMHnDysdYZ2lFA.headers['Location']
		url = url.replace('%20',' ')
		url = url.replace('%3D','=')
		if 'Learn' in jayps2bqRW6CEVl9IY8LdB5e:
			url = url.replace('NTNNile','')
			url = url.replace('learning1','Learning')
	elif hayXA4TiLlPxcVSIoK2=='PL':
		vpWXJDC4lTByaqcn56OFwUmieV = { 'id' : jayps2bqRW6CEVl9IY8LdB5e , 'user' : exOIZnGECcR2p3WV4TPY06BNDo7 , 'function' : 'playPL' , 'menu' : qERDVNWvZzbf9O8sXCxi }
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'POST', NBm2aWhPzoTpdYn, vpWXJDC4lTByaqcn56OFwUmieV, '',False,'','LIVETV-PLAY-4th')
		if not WbTGMHnDysdYZ2lFA.succeeded:
			aHKzv76JCVnprbY8w('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		url = WbTGMHnDysdYZ2lFA.headers['Location']
		headers = {'Referer':WbTGMHnDysdYZ2lFA.headers['Referer']}
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,'POST',url, '',headers , '','','LIVETV-PLAY-5th')
		if not WbTGMHnDysdYZ2lFA.succeeded:
			aHKzv76JCVnprbY8w('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		items = GGvHJKP9LUxEk10Fw.findall('source src="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		url = items[0]
	elif hayXA4TiLlPxcVSIoK2 in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if hayXA4TiLlPxcVSIoK2=='TA': jayps2bqRW6CEVl9IY8LdB5e = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		vpWXJDC4lTByaqcn56OFwUmieV = { 'id' : jayps2bqRW6CEVl9IY8LdB5e , 'user' : exOIZnGECcR2p3WV4TPY06BNDo7 , 'function' : 'play'+hayXA4TiLlPxcVSIoK2 , 'menu' : qERDVNWvZzbf9O8sXCxi }
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'POST',NBm2aWhPzoTpdYn,vpWXJDC4lTByaqcn56OFwUmieV,headers,'','','LIVETV-PLAY-6th')
		if not WbTGMHnDysdYZ2lFA.succeeded:
			aHKzv76JCVnprbY8w('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
		url = WbTGMHnDysdYZ2lFA.headers['Location']
		if hayXA4TiLlPxcVSIoK2=='FM':
			WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,'GET', url, '', '', False,'','LIVETV-PLAY-7th')
			url = WbTGMHnDysdYZ2lFA.headers['Location']
			url = url.replace('https','http')
	ICifW6hdKqxkAJ02XZgHysOwoV9Dc5(url,cTJphS1nFz5EUgNWm86C,'live')
	return
# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'SHOOFMAX'
mmDwMlfoHtG5XT19VLIWqCR8i = '_SHM_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
msL09WzMG3c86RAqkXpY7yn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][1]
HdWn38vFCz47 = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][2]
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==50: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==51: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url)
	elif mode==52: zpXG3Ky6ou8ndWHkb4 = hWPvGlXZ5arzV7(url)
	elif mode==53: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==55: zpXG3Ky6ou8ndWHkb4 = oWRdar7hNUELZG()
	elif mode==56: zpXG3Ky6ou8ndWHkb4 = BjSgXktfJFo()
	elif mode==57: zpXG3Ky6ou8ndWHkb4 = u5iGFOgPoB7n(url,1)
	elif mode==58: zpXG3Ky6ou8ndWHkb4 = u5iGFOgPoB7n(url,2)
	elif mode==59: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',59,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'المسلسلات','',56)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'الافلام','',55)
	return ''
def oWRdar7hNUELZG():
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'أفلام مرتبة بسنة الإنتاج',NBm2aWhPzoTpdYn+'/movie/1/yop',57)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'أفلام مرتبة بالأفضل تقييم',NBm2aWhPzoTpdYn+'/movie/1/review',57)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'أفلام مرتبة بالأكثر مشاهدة',NBm2aWhPzoTpdYn+'/movie/1/views',57)
	return
def BjSgXktfJFo():
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مسلسلات مرتبة بسنة الإنتاج',NBm2aWhPzoTpdYn+'/series/1/yop',57)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مسلسلات مرتبة بالأفضل تقييم',NBm2aWhPzoTpdYn+'/series/1/review',57)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مسلسلات مرتبة بالأكثر مشاهدة',NBm2aWhPzoTpdYn+'/series/1/views',57)
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(url):
	if '?' in url:
		Z0HoXM261lLgxBzjUK = url.split('?')
		url = Z0HoXM261lLgxBzjUK[0]
		filter = '?' + mGfdCk4Hyclg9RjD(Z0HoXM261lLgxBzjUK[1],'=&:/%')
	else: filter = ''
	type,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,sort = url.split('/')[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': co2tTWeh79bO='فيلم'
		elif type=='series': co2tTWeh79bO='مسلسل'
		url = NBm2aWhPzoTpdYn + '/genre/filter/' + mGfdCk4Hyclg9RjD(co2tTWeh79bO) + '/' + EfNzW3kLhcMTu07HrP28X9nFA6vpGd + '/' + sort + filter
		BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,url,'','','','SHOOFMAX-TITLES-1st')
		items = GGvHJKP9LUxEk10Fw.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		f4fdwQ9BLjDt1PZvRps6=0
		for id,title,G39wjnRoPv5JKAH,VFqpJjRySZvgi in items:
			f4fdwQ9BLjDt1PZvRps6 += 1
			VFqpJjRySZvgi = HdWn38vFCz47 + '/v2/img/program/main/' + VFqpJjRySZvgi + '-2.jpg'
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn + '/program/' + id
			if type=='movie': cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,53,VFqpJjRySZvgi)
			if type=='series': cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مسلسل '+title,ELbNB92cOh5dqtpVmi40kY+'?ep='+G39wjnRoPv5JKAH+'='+title+'='+VFqpJjRySZvgi,52,VFqpJjRySZvgi)
	else:
		if type=='movie': co2tTWeh79bO='movies'
		elif type=='series': co2tTWeh79bO='series'
		url = msL09WzMG3c86RAqkXpY7yn + '/json/selected/' + sort + '-' + co2tTWeh79bO + '-WW.json'
		BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,url,'','','','SHOOFMAX-TITLES-2nd')
		items = GGvHJKP9LUxEk10Fw.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		f4fdwQ9BLjDt1PZvRps6=0
		for id,G39wjnRoPv5JKAH,VFqpJjRySZvgi,title in items:
			f4fdwQ9BLjDt1PZvRps6 += 1
			VFqpJjRySZvgi = msL09WzMG3c86RAqkXpY7yn + '/img/program/' + VFqpJjRySZvgi + '-2.jpg'
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn + '/program/' + id
			if type=='movie': cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,53,VFqpJjRySZvgi)
			elif type=='series': cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'مسلسل '+title,ELbNB92cOh5dqtpVmi40kY+'?ep='+G39wjnRoPv5JKAH+'='+title+'='+VFqpJjRySZvgi,52,VFqpJjRySZvgi)
	title='صفحة '
	if f4fdwQ9BLjDt1PZvRps6==16:
		for FI8HhGAfbMi6EN7OJWnoPu3m9zRV in range(1,13) :
			if not EfNzW3kLhcMTu07HrP28X9nFA6vpGd==str(FI8HhGAfbMi6EN7OJWnoPu3m9zRV):
				url = NBm2aWhPzoTpdYn+'/genre/filter/'+type+'/'+str(FI8HhGAfbMi6EN7OJWnoPu3m9zRV)+'/'+sort+filter
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title+str(FI8HhGAfbMi6EN7OJWnoPu3m9zRV),url,51)
	return
def hWPvGlXZ5arzV7(url):
	Z0HoXM261lLgxBzjUK = url.split('=')
	G39wjnRoPv5JKAH = int(Z0HoXM261lLgxBzjUK[1])
	name = GhPlajzTxY8(Z0HoXM261lLgxBzjUK[2])
	name = name.replace('_MOD_مسلسل ','')
	VFqpJjRySZvgi = Z0HoXM261lLgxBzjUK[3]
	url = url.split('?')[0]
	if G39wjnRoPv5JKAH==0:
		BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,url,'','','','SHOOFMAX-EPISODES-1st')
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('<select(.*?)</select>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('option value="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		G39wjnRoPv5JKAH = int(items[-1])
	for qUGxSK2VwsiBAdkDZnJ605vQeg in range(G39wjnRoPv5JKAH,0,-1):
		ELbNB92cOh5dqtpVmi40kY = url + '?ep=' + str(qUGxSK2VwsiBAdkDZnJ605vQeg)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(qUGxSK2VwsiBAdkDZnJ605vQeg)
		cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,53,VFqpJjRySZvgi)
	return
def SUfe4unWoXBNFz90xqy(url):
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,url,'','','','SHOOFMAX-PLAY-1st')
	lRNzQFuSKEovWq30Cfxhi = GGvHJKP9LUxEk10Fw.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if lRNzQFuSKEovWq30Cfxhi:
		MQbODJoPV2w8TEAg4zXZdjLxSW = lRNzQFuSKEovWq30Cfxhi[1].replace('T','    ')
		aHKzv76JCVnprbY8w('','','رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+'\n'+MQbODJoPV2w8TEAg4zXZdjLxSW)
		return
	i6pnc9bEA2,cmJtyL52OEi0psBQIFg89vjV = [],[]
	UUXoNzHQTRZiaMpBDK = GGvHJKP9LUxEk10Fw.findall('var origin_link = "(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)[0]
	aJwVfYZG5ACUj0p7uPsOEH8XI = GGvHJKP9LUxEk10Fw.findall('var backup_origin_link = "(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)[0]
	gI487voLsArVqW6Ffp = GGvHJKP9LUxEk10Fw.findall('hls: (.*?)_link\+"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	for C83UXWf15zdwLA0,ELbNB92cOh5dqtpVmi40kY in gI487voLsArVqW6Ffp:
		if 'backup' in C83UXWf15zdwLA0:
			C83UXWf15zdwLA0 = 'backup server'
			url = aJwVfYZG5ACUj0p7uPsOEH8XI + ELbNB92cOh5dqtpVmi40kY
		else:
			C83UXWf15zdwLA0 = 'main server'
			url = UUXoNzHQTRZiaMpBDK + ELbNB92cOh5dqtpVmi40kY
		if '.m3u8' in url:
			i6pnc9bEA2.append(url)
			cmJtyL52OEi0psBQIFg89vjV.append('m3u8  '+C83UXWf15zdwLA0)
	gI487voLsArVqW6Ffp = GGvHJKP9LUxEk10Fw.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	gI487voLsArVqW6Ffp += GGvHJKP9LUxEk10Fw.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	for C83UXWf15zdwLA0,ELbNB92cOh5dqtpVmi40kY in gI487voLsArVqW6Ffp:
		filename = ELbNB92cOh5dqtpVmi40kY.split('/')[-1]
		filename = filename.replace('fallback','')
		filename = filename.replace('.mp4','')
		filename = filename.replace('-','')
		if 'backup' in C83UXWf15zdwLA0:
			C83UXWf15zdwLA0 = 'backup server'
			url = aJwVfYZG5ACUj0p7uPsOEH8XI + ELbNB92cOh5dqtpVmi40kY
		else:
			C83UXWf15zdwLA0 = 'main server'
			url = UUXoNzHQTRZiaMpBDK + ELbNB92cOh5dqtpVmi40kY
		i6pnc9bEA2.append(url)
		cmJtyL52OEi0psBQIFg89vjV.append('mp4  '+C83UXWf15zdwLA0+'  '+filename)
	z0jyetbQwKrIclL9vJW = D1DJtzviFZSrA('Select Video Quality:', cmJtyL52OEi0psBQIFg89vjV)
	if z0jyetbQwKrIclL9vJW == -1 : return
	url = i6pnc9bEA2[z0jyetbQwKrIclL9vJW]
	ICifW6hdKqxkAJ02XZgHysOwoV9Dc5(url,cTJphS1nFz5EUgNWm86C,'video')
	return
def u5iGFOgPoB7n(url,type):
	if 'series' in url: dR2vHyAtl8pJN1 = NBm2aWhPzoTpdYn + '/genre/مسلسل'
	else: dR2vHyAtl8pJN1 = NBm2aWhPzoTpdYn + '/genre/فيلم'
	dR2vHyAtl8pJN1 = mGfdCk4Hyclg9RjD(dR2vHyAtl8pJN1)
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,dR2vHyAtl8pJN1,'','','','SHOOFMAX-FILTERS-1st')
	if type==1: EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('subgenre(.*?)div',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	elif type==2: EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('country(.*?)div',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('option value="(.*?)">(.*?)</option',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	if type==1:
		for FGzWVA3yK9NfrgYIsEHPBj5CZm8pS,title in items:
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url+'?subgenre='+FGzWVA3yK9NfrgYIsEHPBj5CZm8pS,58)
	elif type==2:
		url,FGzWVA3yK9NfrgYIsEHPBj5CZm8pS = url.split('?')
		for CP2iXvM97DK6ZcNwFl8B,title in items:
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url+'?country='+CP2iXvM97DK6ZcNwFl8B+'&'+FGzWVA3yK9NfrgYIsEHPBj5CZm8pS,51)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if not search: search = yMRXZIpKxlSkaE6iCO()
	if not search: return
	aKRILTAj1HC5c = search.replace(' ','%20')
	url = NBm2aWhPzoTpdYn+'/search?q='+aKRILTAj1HC5c
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','',True,'','SHOOFMAX-SEARCH-2nd')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('general-body(.*?)search-bottom-padding',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	if items:
		for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
			url = NBm2aWhPzoTpdYn + ELbNB92cOh5dqtpVmi40kY
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+mGfdCk4Hyclg9RjD(title)+'='+VFqpJjRySZvgi
					cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,52,VFqpJjRySZvgi)
				else:
					title = '_MOD_فيلم '+title
					cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,53,VFqpJjRySZvgi)
	return
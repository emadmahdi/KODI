# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'EGYBESTVIP'
mmDwMlfoHtG5XT19VLIWqCR8i = '_EGV_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,EfNzW3kLhcMTu07HrP28X9nFA6vpGd,text):
	if   mode==220: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==221: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif mode==222: zpXG3Ky6ou8ndWHkb4 = i7pbAuodvX3(url)
	elif mode==223: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==224: zpXG3Ky6ou8ndWHkb4 = hWJg9P6lEYT5aGDizcb(url)
	elif mode==229: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',229,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',NBm2aWhPzoTpdYn,'','','','','EGYBEST-MENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="i i-home"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)"(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,222)
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="ba(.*?)<script',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		for title,ELbNB92cOh5dqtpVmi40kY in items:
			cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,221)
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			if 'html' not in ELbNB92cOh5dqtpVmi40kY: continue
			if not ELbNB92cOh5dqtpVmi40kY.endswith('/'): cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,221)
	return BBlXpmUyhFDwNtCVAHoE
def i7pbAuodvX3(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',url,'','','','','EGYBESTVIP-SUBMENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="rs_scroll"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?</i>(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,224)
	return
def hWJg9P6lEYT5aGDizcb(url):
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع',url,221)
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,url,'','','','EGYBESTVIP-FILTERS_MENU-1st')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="sub_nav(.*?)id="movies',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".+?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			if ELbNB92cOh5dqtpVmi40kY=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,221)
	else: xoiXMWjJC3pnQqurIGPkRSl8e(url)
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(url,EfNzW3kLhcMTu07HrP28X9nFA6vpGd='1'):
	if EfNzW3kLhcMTu07HrP28X9nFA6vpGd=='': EfNzW3kLhcMTu07HrP28X9nFA6vpGd = '1'
	if '/search' in url or '?' in url: dR2vHyAtl8pJN1 = url + '&'
	else: dR2vHyAtl8pJN1 = url + '?'
	dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1 + 'page=' + EfNzW3kLhcMTu07HrP28X9nFA6vpGd
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,dR2vHyAtl8pJN1,'','','','EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		EeQqAGc0W5r6nlBbChwfZL=GGvHJKP9LUxEk10Fw.findall('class="pda"(.*?)div',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[-1]
	elif '/series/' in url:
		EeQqAGc0W5r6nlBbChwfZL=GGvHJKP9LUxEk10Fw.findall('class="owl-carousel owl-carousel(.*?)div',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	else:
		EeQqAGc0W5r6nlBbChwfZL=GGvHJKP9LUxEk10Fw.findall('id="movies(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[-1]
	items = GGvHJKP9LUxEk10Fw.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
		title = DwNC3gEonizsB6a0v1F(title)
		if '/movie/' in ELbNB92cOh5dqtpVmi40kY or '/episode' in ELbNB92cOh5dqtpVmi40kY:
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY.rstrip('/'),223,VFqpJjRySZvgi)
		else:
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,221,VFqpJjRySZvgi)
	if len(items)>=16:
		coHt7a2TCD = ['/movies','/tv','/search','/trending']
		EfNzW3kLhcMTu07HrP28X9nFA6vpGd = int(EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
		if any(hieW1zRUG5w9AykJjv0X in url for hieW1zRUG5w9AykJjv0X in coHt7a2TCD):
			for SrlqLHPiugYnDpT24hOEyC5Kb in range(0,1000,100):
				if int(EfNzW3kLhcMTu07HrP28X9nFA6vpGd/100)*100==SrlqLHPiugYnDpT24hOEyC5Kb:
					for umP72LtwzUTWHFAlJVyheEp5 in range(SrlqLHPiugYnDpT24hOEyC5Kb,SrlqLHPiugYnDpT24hOEyC5Kb+100,10):
						if int(EfNzW3kLhcMTu07HrP28X9nFA6vpGd/10)*10==umP72LtwzUTWHFAlJVyheEp5:
							for jHrnWJzMY7a3PmcBVid in range(umP72LtwzUTWHFAlJVyheEp5,umP72LtwzUTWHFAlJVyheEp5+10,1):
								if not EfNzW3kLhcMTu07HrP28X9nFA6vpGd==jHrnWJzMY7a3PmcBVid and jHrnWJzMY7a3PmcBVid!=0:
									cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+str(jHrnWJzMY7a3PmcBVid),url,221,'',str(jHrnWJzMY7a3PmcBVid))
						elif umP72LtwzUTWHFAlJVyheEp5!=0: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+str(umP72LtwzUTWHFAlJVyheEp5),url,221,'',str(umP72LtwzUTWHFAlJVyheEp5))
						else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+str(1),url,221,'',str(1))
				elif SrlqLHPiugYnDpT24hOEyC5Kb!=0: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+str(SrlqLHPiugYnDpT24hOEyC5Kb),url,221,'',str(SrlqLHPiugYnDpT24hOEyC5Kb))
				else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+str(1),url,221)
	return
def SUfe4unWoXBNFz90xqy(url):
	eyUmvNFiYsE,zzvBg3ShiamAZ = [],[]
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,url,'','','','EGYBESTVIP-PLAY-1st')
	NbE4qnzmPKGWtjYpoRL3HTS1A = GGvHJKP9LUxEk10Fw.findall('<td>التصنيف</td>.*?">(.*?)<',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if NbE4qnzmPKGWtjYpoRL3HTS1A and hNCJPTucIV7GOSR0HytZ6eQrqEUpw(cTJphS1nFz5EUgNWm86C,url,NbE4qnzmPKGWtjYpoRL3HTS1A): return
	nHECwv9lrspKxmdBMJgqZDFO,WdGuwqgVbJsHF80oSRDBy1 = '',''
	N1lHvpYMtECP,vt3ZMoKyD1qTE0zG = BBlXpmUyhFDwNtCVAHoE,BBlXpmUyhFDwNtCVAHoE
	LL5UVKRtEwipqYn = GGvHJKP9LUxEk10Fw.findall('show_dl api" href="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if LL5UVKRtEwipqYn:
		for ELbNB92cOh5dqtpVmi40kY in LL5UVKRtEwipqYn:
			if '/watch/' in ELbNB92cOh5dqtpVmi40kY: nHECwv9lrspKxmdBMJgqZDFO = ELbNB92cOh5dqtpVmi40kY
			elif '/download/' in ELbNB92cOh5dqtpVmi40kY: WdGuwqgVbJsHF80oSRDBy1 = ELbNB92cOh5dqtpVmi40kY
		if nHECwv9lrspKxmdBMJgqZDFO!='': N1lHvpYMtECP = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,nHECwv9lrspKxmdBMJgqZDFO,'','','','EGYBESTVIP-PLAY-2nd')
		if WdGuwqgVbJsHF80oSRDBy1!='': vt3ZMoKyD1qTE0zG = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,WdGuwqgVbJsHF80oSRDBy1,'','','','EGYBESTVIP-PLAY-3rd')
	VFASq5XtJyfbN9PvpdH4W = GGvHJKP9LUxEk10Fw.findall('id="video".*?data-src="(.*?)"',N1lHvpYMtECP,GGvHJKP9LUxEk10Fw.DOTALL)
	if VFASq5XtJyfbN9PvpdH4W:
		dR2vHyAtl8pJN1 = VFASq5XtJyfbN9PvpdH4W[0]
		if dR2vHyAtl8pJN1!='' and 'uploaded.egybest.download' in dR2vHyAtl8pJN1 and '/?id=_' not in dR2vHyAtl8pJN1:
			X3in5vNhqwWEG2TafmVCrFbSYDxjoK = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,dR2vHyAtl8pJN1,'','','','EGYBESTVIP-PLAY-4th')
			rHpVBq09lg6PFso21N = GGvHJKP9LUxEk10Fw.findall('source src="(.*?)" title="(.*?)"',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
			if rHpVBq09lg6PFso21N:
				for ELbNB92cOh5dqtpVmi40kY,dDZQSEGRTo9g85x1C in rHpVBq09lg6PFso21N:
					zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY+'?named=ed.egybest.do__watch__mp4__'+dDZQSEGRTo9g85x1C)
			else:
				C83UXWf15zdwLA0 = dR2vHyAtl8pJN1.split('/')[2]
				zzvBg3ShiamAZ.append(dR2vHyAtl8pJN1+'?named='+C83UXWf15zdwLA0+'__watch')
		elif dR2vHyAtl8pJN1!='':
			C83UXWf15zdwLA0 = dR2vHyAtl8pJN1.split('/')[2]
			zzvBg3ShiamAZ.append(dR2vHyAtl8pJN1+'?named='+C83UXWf15zdwLA0+'__watch')
	D8wRLqfVFjIox = GGvHJKP9LUxEk10Fw.findall('<table class="dls_table(.*?)</table>',vt3ZMoKyD1qTE0zG,GGvHJKP9LUxEk10Fw.DOTALL)
	if D8wRLqfVFjIox:
		D8wRLqfVFjIox = D8wRLqfVFjIox[0]
		OOVIKX5nep0kAjW8lsRwv = GGvHJKP9LUxEk10Fw.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',D8wRLqfVFjIox,GGvHJKP9LUxEk10Fw.DOTALL)
		if OOVIKX5nep0kAjW8lsRwv:
			for dDZQSEGRTo9g85x1C,ELbNB92cOh5dqtpVmi40kY in OOVIKX5nep0kAjW8lsRwv:
				if 'myegyvip' not in ELbNB92cOh5dqtpVmi40kY: continue
				if ELbNB92cOh5dqtpVmi40kY.count('/')>=2:
					C83UXWf15zdwLA0 = ELbNB92cOh5dqtpVmi40kY.split('/')[2]
					zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY+'?named='+C83UXWf15zdwLA0+'__download__mp4__'+dDZQSEGRTo9g85x1C)
	AzJSpsQ7kWrPeox2jOR5FK = []
	for ELbNB92cOh5dqtpVmi40kY in zzvBg3ShiamAZ:
		AzJSpsQ7kWrPeox2jOR5FK.append(ELbNB92cOh5dqtpVmi40kY)
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(AzJSpsQ7kWrPeox2jOR5FK,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	aKRILTAj1HC5c = search.replace(' ','+')
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(xh9BXlAw0UoVsIZ4if3,NBm2aWhPzoTpdYn,'','','','EGYBESTVIP-SEARCH-1st')
	DI9PgKJNvLiuBpXyctMs2RklobGA = GGvHJKP9LUxEk10Fw.findall('name="_token" value="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if DI9PgKJNvLiuBpXyctMs2RklobGA:
		url = NBm2aWhPzoTpdYn+'/search?_token='+DI9PgKJNvLiuBpXyctMs2RklobGA[0]+'&q='+aKRILTAj1HC5c
		xoiXMWjJC3pnQqurIGPkRSl8e(url)
	return
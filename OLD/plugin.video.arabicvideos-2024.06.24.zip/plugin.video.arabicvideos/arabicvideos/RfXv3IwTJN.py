# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'YOUTUBE'
mmDwMlfoHtG5XT19VLIWqCR8i = '_YUT_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text,type,EfNzW3kLhcMTu07HrP28X9nFA6vpGd):
	if	 mode==140: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==143: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url,type)
	elif mode==144: zpXG3Ky6ou8ndWHkb4 = L4L0TUsN51taeljfc(url,text,EfNzW3kLhcMTu07HrP28X9nFA6vpGd)
	elif mode==145: zpXG3Ky6ou8ndWHkb4 = NgvYbofjGDJQXMcZSt7B9u6el(url)
	elif mode==146: zpXG3Ky6ou8ndWHkb4 = d42lwMJC6a1oczLkK07FPGs(url)
	elif mode==147: zpXG3Ky6ou8ndWHkb4 = WXuxgmeITy5bL()
	elif mode==148: zpXG3Ky6ou8ndWHkb4 = JLMYx4oXzPE7RBnwfgtQ85bm()
	elif mode==149: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',149,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+'_YTC_'+'مواقع اختارها المبرمج','',290)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'مواقع اختارها يوتيوب',NBm2aWhPzoTpdYn+'/feed/guide_builder',144)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'الصفحة الرئيسية',NBm2aWhPzoTpdYn,144,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'المحتوى الرائج',NBm2aWhPzoTpdYn+'/feed/trending',146)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'بحث: قنوات عربية','',147)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'بحث: قنوات أجنبية','',148)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'بحث: افلام عربية',NBm2aWhPzoTpdYn+'/results?search_query=فيلم',144)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'بحث: افلام اجنبية',NBm2aWhPzoTpdYn+'/results?search_query=movie',144)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'بحث: مسرحيات عربية',NBm2aWhPzoTpdYn+'/results?search_query=مسرحية',144)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'بحث: مسلسلات عربية',NBm2aWhPzoTpdYn+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'بحث: مسلسلات اجنبية',NBm2aWhPzoTpdYn+'/results?search_query=series&sp=EgIQAw==',144)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'بحث: مسلسلات كارتون',NBm2aWhPzoTpdYn+'/results?search_query=كارتون&sp=EgIQAw==',144)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'بحث: خطبة المرجعية',NBm2aWhPzoTpdYn+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def WXuxgmeITy5bL():
	L4L0TUsN51taeljfc(NBm2aWhPzoTpdYn+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def JLMYx4oXzPE7RBnwfgtQ85bm():
	L4L0TUsN51taeljfc(NBm2aWhPzoTpdYn+'/results?search_query=tv&sp=EgJAAQ==')
	return
def SUfe4unWoXBNFz90xqy(url,type):
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E([url],cTJphS1nFz5EUgNWm86C,type,url)
	return
def d42lwMJC6a1oczLkK07FPGs(url):
	BBlXpmUyhFDwNtCVAHoE,PYRN3CLTut,data = rKP5lefC2pJ4hNxgQ(url)
	qOwEC2fpNgcrzGl = PYRN3CLTut['contents']['twoColumnBrowseResultsRenderer']['tabs']
	for CQMipytPbq in range(len(qOwEC2fpNgcrzGl)):
		BrVNsC72UYWES4A = qOwEC2fpNgcrzGl[CQMipytPbq]
		xs5qyN8IWjmhu9t2wKH6TXOaS(BrVNsC72UYWES4A,url,str(CQMipytPbq))
	Ag3mJoNkHrfURZI9yt = qOwEC2fpNgcrzGl[0]['tabRenderer']['content']['sectionListRenderer']['contents']
	osVA40TFrdnQED3BCWgUOmSRbaYqL2 = 0
	for CQMipytPbq in range(len(Ag3mJoNkHrfURZI9yt)):
		BrVNsC72UYWES4A = Ag3mJoNkHrfURZI9yt[CQMipytPbq]['itemSectionRenderer']['contents'][0]
		if list(BrVNsC72UYWES4A['shelfRenderer']['content'].keys())[0]=='horizontalListRenderer': continue
		Ax4racOvNio2fRj9wPhFyBnSeE,title,ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,count,EDL3rwcivsR9W0pdTfygmOYUoVSb,vcZAMYo91uLtzbliawOx6GyKRT,BfZdAct4k0VDSeJ9uh = D5t3HLgP7uads2lVWmYvC(BrVNsC72UYWES4A)
		if not title:
			osVA40TFrdnQED3BCWgUOmSRbaYqL2 += 1
			title = 'فيديوهات رائجة '+str(osVA40TFrdnQED3BCWgUOmSRbaYqL2)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,144,'',str(CQMipytPbq))
	key = GGvHJKP9LUxEk10Fw.findall('"innertubeApiKey":"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	dR2vHyAtl8pJN1 = 'https://www.youtube.com/youtubei/v1/guide?key='+key[0]
	BBlXpmUyhFDwNtCVAHoE,PYRN3CLTut,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = rKP5lefC2pJ4hNxgQ(dR2vHyAtl8pJN1)
	for W6qVfHashAInl in range(3,4):
		qOwEC2fpNgcrzGl = PYRN3CLTut['items'][W6qVfHashAInl]['guideSectionRenderer']['items']
		for CQMipytPbq in range(len(qOwEC2fpNgcrzGl)):
			BrVNsC72UYWES4A = qOwEC2fpNgcrzGl[CQMipytPbq]
			if 'YouTube Premium' in str(BrVNsC72UYWES4A): continue
			xs5qyN8IWjmhu9t2wKH6TXOaS(BrVNsC72UYWES4A)
	return
def L4L0TUsN51taeljfc(url,data='',index=0):
	global jHevARrF7lS
	if not data: data = jHevARrF7lS.getSetting('av.youtube.data')
	if index: index = int(index)
	else: index = 0
	data = data.replace('_REMEMBERRESULTS_','')
	BBlXpmUyhFDwNtCVAHoE,PYRN3CLTut,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = rKP5lefC2pJ4hNxgQ(url,data)
	ms2eq39LGR5ZluDtoVQ,Rdz7xp3wsWDu9XiqShHBZnGrj1 = '',''
	X5byeYgp1hrD0jGKf7wNUT2ZmquI = GGvHJKP9LUxEk10Fw.findall('"ownerName".*?":"(.*?)".*?"url":"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not X5byeYgp1hrD0jGKf7wNUT2ZmquI: X5byeYgp1hrD0jGKf7wNUT2ZmquI = GGvHJKP9LUxEk10Fw.findall('"videoOwner".*?"text":"(.*?)".*?"url":"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not X5byeYgp1hrD0jGKf7wNUT2ZmquI: X5byeYgp1hrD0jGKf7wNUT2ZmquI = GGvHJKP9LUxEk10Fw.findall('"channelMetadataRenderer":\{"title":"(.*?)".*?"ownerUrls":\["(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if X5byeYgp1hrD0jGKf7wNUT2ZmquI:
		ms2eq39LGR5ZluDtoVQ = '[COLOR FFC89008]'+X5byeYgp1hrD0jGKf7wNUT2ZmquI[0][0]+'[/COLOR]'
		ELbNB92cOh5dqtpVmi40kY = X5byeYgp1hrD0jGKf7wNUT2ZmquI[0][1]
		if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
		if 'list=' in url: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+ms2eq39LGR5ZluDtoVQ,ELbNB92cOh5dqtpVmi40kY,144)
	YASM639jhszyPkpiR = ['/search','/videos','/channels','/playlists','/featured','ss=','ctoken=','key=','bp=','shelf_id=']
	y6dDSuZOvsXoxl7gTp38fkW = not any(hieW1zRUG5w9AykJjv0X in url for hieW1zRUG5w9AykJjv0X in YASM639jhszyPkpiR)
	if y6dDSuZOvsXoxl7gTp38fkW and ms2eq39LGR5ZluDtoVQ:
		now0UFQXvPyWA8TNluJ53M = 'البحث'
		qPmCp1Q4gRekdAH = 'قوائم التشغيل'
		Cyh9cRvbUW = 'الفيديوهات'
		BtI5cGOUZk = 'القنوات'
		cd0aGwCPExbFU5pYNu8r('link',mmDwMlfoHtG5XT19VLIWqCR8i+ms2eq39LGR5ZluDtoVQ,url,9999)
		if '"title":"بحث"' in BBlXpmUyhFDwNtCVAHoE: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+now0UFQXvPyWA8TNluJ53M,url,145,'','','_REMEMBERRESULTS_')
		if '"title":"قوائم التشغيل"' in BBlXpmUyhFDwNtCVAHoE: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+qPmCp1Q4gRekdAH,url+'/playlists',144)
		if '"title":"الفيديوهات"' in BBlXpmUyhFDwNtCVAHoE: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+Cyh9cRvbUW,url+'/videos',144)
		if '"title":"القنوات"' in BBlXpmUyhFDwNtCVAHoE: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+BtI5cGOUZk,url+'/channels',144)
		if '"title":"Search"' in BBlXpmUyhFDwNtCVAHoE: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+now0UFQXvPyWA8TNluJ53M,url,145,'','','_REMEMBERRESULTS_')
		if '"title":"Playlists"' in BBlXpmUyhFDwNtCVAHoE: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+qPmCp1Q4gRekdAH,url+'/playlists',144)
		if '"title":"Videos"' in BBlXpmUyhFDwNtCVAHoE: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+Cyh9cRvbUW,url+'/videos',144)
		if '"title":"Channels"' in BBlXpmUyhFDwNtCVAHoE: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+BtI5cGOUZk,url+'/channels',144)
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	if 'search_query' in url:
		qOwEC2fpNgcrzGl = PYRN3CLTut['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']
		ss6rIM5oL7RTeO = 0
		for umP72LtwzUTWHFAlJVyheEp5 in range(len(qOwEC2fpNgcrzGl)):
			if 'itemSectionRenderer' in list(qOwEC2fpNgcrzGl[umP72LtwzUTWHFAlJVyheEp5].keys()):
				gqu4bMnHOme87TSY2Uj0a = qOwEC2fpNgcrzGl[umP72LtwzUTWHFAlJVyheEp5]['itemSectionRenderer']
				MUSrJfcoWxYhyjO = len(str(gqu4bMnHOme87TSY2Uj0a))
				if MUSrJfcoWxYhyjO>ss6rIM5oL7RTeO:
					ss6rIM5oL7RTeO = MUSrJfcoWxYhyjO
					Rdz7xp3wsWDu9XiqShHBZnGrj1 = gqu4bMnHOme87TSY2Uj0a
		if ss6rIM5oL7RTeO==0: return
	elif '&list=' in url or '/search?key=' in url or '/browse?key=' in url or 'ctoken=' in url or '/search' in url or url==NBm2aWhPzoTpdYn:
		UaCSPBpXzR0JgKYocbwk4GETj2t = []
		UaCSPBpXzR0JgKYocbwk4GETj2t.append("cc['onResponseReceivedCommands'][0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']")
		UaCSPBpXzR0JgKYocbwk4GETj2t.append("cc['onResponseReceivedActions'][0]['appendContinuationItemsAction']['continuationItems']")
		UaCSPBpXzR0JgKYocbwk4GETj2t.append("cc[1]['response']['continuationContents']['sectionListContinuation']")
		UaCSPBpXzR0JgKYocbwk4GETj2t.append("cc[1]['response']['continuationContents']['gridContinuation']['items']")
		UaCSPBpXzR0JgKYocbwk4GETj2t.append("cc[1]['response']['continuationContents']['playlistVideoListContinuation']")
		UaCSPBpXzR0JgKYocbwk4GETj2t.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][-1]['expandableTabRenderer']['content']['sectionListRenderer']")
		UaCSPBpXzR0JgKYocbwk4GETj2t.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']")
		UaCSPBpXzR0JgKYocbwk4GETj2t.append("cc['contents']['twoColumnWatchNextResults']['playlist']['playlist']")
		OtTkHdy0XAQjnvBZbGmhwK,Rdz7xp3wsWDu9XiqShHBZnGrj1 = YUIOn5yPWjh8mFMtEXdHZu(PYRN3CLTut,'',UaCSPBpXzR0JgKYocbwk4GETj2t)
	if not Rdz7xp3wsWDu9XiqShHBZnGrj1:
		try:
			qOwEC2fpNgcrzGl = PYRN3CLTut['contents']['twoColumnBrowseResultsRenderer']['tabs']
			GwBsaCOTjM14 = '/videos' in url or '/playlists' in url or '/channels' in url
			fc38IijmEsgSNdCu7qFeWhM = '"title":"الفيديوهات"' in BBlXpmUyhFDwNtCVAHoE or '"title":"قوائم التشغيل"' in BBlXpmUyhFDwNtCVAHoE or '"title":"القنوات"' in BBlXpmUyhFDwNtCVAHoE
			jC6en8o1LGBi = '"title":"Videos"' in BBlXpmUyhFDwNtCVAHoE or '"title":"Playlists"' in BBlXpmUyhFDwNtCVAHoE or '"title":"Channels"' in BBlXpmUyhFDwNtCVAHoE
			if GwBsaCOTjM14 and (fc38IijmEsgSNdCu7qFeWhM or jC6en8o1LGBi):
				for CQMipytPbq in range(len(qOwEC2fpNgcrzGl)):
					if 'tabRenderer' not in list(qOwEC2fpNgcrzGl[CQMipytPbq].keys()): continue
					Ag3mJoNkHrfURZI9yt = qOwEC2fpNgcrzGl[CQMipytPbq]['tabRenderer']
					try: lFpGwZTsmtuczHxEMN = Ag3mJoNkHrfURZI9yt['content']['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems'][CQMipytPbq]
					except: lFpGwZTsmtuczHxEMN = Ag3mJoNkHrfURZI9yt
					try: ELbNB92cOh5dqtpVmi40kY = lFpGwZTsmtuczHxEMN['endpoint']['commandMetadata']['webCommandMetadata']['url']
					except: continue
					if   '/videos'		in ELbNB92cOh5dqtpVmi40kY	and '/videos'		in url: Ag3mJoNkHrfURZI9yt = qOwEC2fpNgcrzGl[CQMipytPbq] ; break
					elif '/playlists'	in ELbNB92cOh5dqtpVmi40kY	and '/playlists'	in url: Ag3mJoNkHrfURZI9yt = qOwEC2fpNgcrzGl[CQMipytPbq] ; break
					elif '/channels'	in ELbNB92cOh5dqtpVmi40kY	and '/channels'		in url: Ag3mJoNkHrfURZI9yt = qOwEC2fpNgcrzGl[CQMipytPbq] ; break
					else: Ag3mJoNkHrfURZI9yt = qOwEC2fpNgcrzGl[0]
			elif 'bp=' in url: Ag3mJoNkHrfURZI9yt = qOwEC2fpNgcrzGl[index]
			else: Ag3mJoNkHrfURZI9yt = qOwEC2fpNgcrzGl[0]
			Rdz7xp3wsWDu9XiqShHBZnGrj1 = Ag3mJoNkHrfURZI9yt['tabRenderer']['content']
		except: pass
	if not Rdz7xp3wsWDu9XiqShHBZnGrj1: return
	UaCSPBpXzR0JgKYocbwk4GETj2t = []
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['cards']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("ff['sectionListRenderer']['contents'][int(index)]['richSectionRenderer']['content']")
	if 'view=' not in url: UaCSPBpXzR0JgKYocbwk4GETj2t.append("ff['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("ff['sectionListRenderer']['contents']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("ff['sectionListRenderer']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("ff['richGridRenderer']['contents']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("ff['contents']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("ff")
	ww2jqr0uZUVaX5M7D98 = FEaio7MR2CjTJ9ZLVQnhNewgpv(u'كل قوائم التشغيل')
	kNx9HE7YybShuWImMP2Z3cFt14BQ = FEaio7MR2CjTJ9ZLVQnhNewgpv(u'كل الفيديوهات')
	V2LP8TinUY4bmfyXw = FEaio7MR2CjTJ9ZLVQnhNewgpv(u'كل القنوات')
	Nr4CuBpaHm6FJh = [ww2jqr0uZUVaX5M7D98,kNx9HE7YybShuWImMP2Z3cFt14BQ,V2LP8TinUY4bmfyXw,'All playlists','All videos','All channels']
	TTdcNqi4h805SaB,lFpGwZTsmtuczHxEMN = YUIOn5yPWjh8mFMtEXdHZu(Rdz7xp3wsWDu9XiqShHBZnGrj1,index,UaCSPBpXzR0JgKYocbwk4GETj2t)
	if 'list' in str(type(lFpGwZTsmtuczHxEMN)) and any(hieW1zRUG5w9AykJjv0X in str(lFpGwZTsmtuczHxEMN[0]) for hieW1zRUG5w9AykJjv0X in Nr4CuBpaHm6FJh): del lFpGwZTsmtuczHxEMN[0]
	for TX41HmrcRW in range(len(lFpGwZTsmtuczHxEMN)):
		UaCSPBpXzR0JgKYocbwk4GETj2t = []
		UaCSPBpXzR0JgKYocbwk4GETj2t.append("gg[index2]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
		UaCSPBpXzR0JgKYocbwk4GETj2t.append("gg[index2]['itemSectionRenderer']['header']")
		UaCSPBpXzR0JgKYocbwk4GETj2t.append("gg[index2]['horizontalCardListRenderer']['header']")
		UaCSPBpXzR0JgKYocbwk4GETj2t.append("gg[index2]['itemSectionRenderer']['contents'][0]")
		UaCSPBpXzR0JgKYocbwk4GETj2t.append("gg[index2]['richSectionRenderer']['content']")
		UaCSPBpXzR0JgKYocbwk4GETj2t.append("gg[index2]['richItemRenderer']['content']")
		UaCSPBpXzR0JgKYocbwk4GETj2t.append("gg[index2]['gameCardRenderer']['game']")
		UaCSPBpXzR0JgKYocbwk4GETj2t.append("gg[index2]")
		OtTkHdy0XAQjnvBZbGmhwK,BrVNsC72UYWES4A = YUIOn5yPWjh8mFMtEXdHZu(lFpGwZTsmtuczHxEMN,TX41HmrcRW,UaCSPBpXzR0JgKYocbwk4GETj2t)
		xs5qyN8IWjmhu9t2wKH6TXOaS(BrVNsC72UYWES4A,url,str(TX41HmrcRW))
		if OtTkHdy0XAQjnvBZbGmhwK=='4':
			try:
				TjUMkRLF1upcs = BrVNsC72UYWES4A['shelfRenderer']['content']['horizontalMovieListRenderer']['items']
				for cYCUDAE9MWH0SuR6xPI7BlVv5OXwKJ in range(len(TjUMkRLF1upcs)):
					R5TaSVneFZJbBCHKdhwYE0oy = TjUMkRLF1upcs[cYCUDAE9MWH0SuR6xPI7BlVv5OXwKJ]
					xs5qyN8IWjmhu9t2wKH6TXOaS(R5TaSVneFZJbBCHKdhwYE0oy)
			except: pass
	ffOGheCcNowFKUZREBkMYp83H = False
	if 'view=' not in url and TTdcNqi4h805SaB=='8': ffOGheCcNowFKUZREBkMYp83H = True
	if ':::' in Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd: R2XCvULdcta1fWkIzwo4Ge6u,key,ggBUqDPoF3Z24we,XVSW1sQ4dAGx2hpUwHk8KT,DI9PgKJNvLiuBpXyctMs2RklobGA,SdAk9PfCaWtov0K4GnxIYUcQX8 = Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd.split(':::')
	else: R2XCvULdcta1fWkIzwo4Ge6u,key,ggBUqDPoF3Z24we,XVSW1sQ4dAGx2hpUwHk8KT,DI9PgKJNvLiuBpXyctMs2RklobGA,SdAk9PfCaWtov0K4GnxIYUcQX8 = '','','','','',''
	dR2vHyAtl8pJN1,WgtDJdf7CrpxK41GQAMkyjSF8bu = '',''
	if D6DrJsclfY:
		rLzspynQH0b7Fj95fBe = str(D6DrJsclfY[-1][1])
		if   mmDwMlfoHtG5XT19VLIWqCR8i+'CHNL' in rLzspynQH0b7Fj95fBe: WgtDJdf7CrpxK41GQAMkyjSF8bu = 'CHANNELS'
		elif mmDwMlfoHtG5XT19VLIWqCR8i+'USER' in rLzspynQH0b7Fj95fBe: WgtDJdf7CrpxK41GQAMkyjSF8bu = 'CHANNELS'
		elif mmDwMlfoHtG5XT19VLIWqCR8i+'LIST' in rLzspynQH0b7Fj95fBe: WgtDJdf7CrpxK41GQAMkyjSF8bu = 'PLAYLISTS'
	if '"continuations"' in BBlXpmUyhFDwNtCVAHoE and '&list=' not in url and not ffOGheCcNowFKUZREBkMYp83H and 'shelf_id' not in url:
		dR2vHyAtl8pJN1 = NBm2aWhPzoTpdYn+'/browse_ajax?ctoken='+ggBUqDPoF3Z24we
	elif '"token"' in BBlXpmUyhFDwNtCVAHoE and 'bp=' not in url and 'search_query' in url or 'search?key=' in url:
		dR2vHyAtl8pJN1 = NBm2aWhPzoTpdYn+'/youtubei/v1/search?key='+key
	elif '"token"' in BBlXpmUyhFDwNtCVAHoE and 'bp=' not in url:
		dR2vHyAtl8pJN1 = NBm2aWhPzoTpdYn+'/youtubei/v1/browse?key='+key
	if dR2vHyAtl8pJN1: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة أخرى',dR2vHyAtl8pJN1,144,WgtDJdf7CrpxK41GQAMkyjSF8bu,'',Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd)
	return
def YUIOn5yPWjh8mFMtEXdHZu(n3ot08Ck2OIaKFq1iJsvWQScyfx,DCguJjW2E9bQomXAqG,uNLwCObJaUeKsyvjTrzinc56ZW1Dp):
	PYRN3CLTut = n3ot08Ck2OIaKFq1iJsvWQScyfx
	Rdz7xp3wsWDu9XiqShHBZnGrj1,index = n3ot08Ck2OIaKFq1iJsvWQScyfx,DCguJjW2E9bQomXAqG
	lFpGwZTsmtuczHxEMN,TX41HmrcRW = n3ot08Ck2OIaKFq1iJsvWQScyfx,DCguJjW2E9bQomXAqG
	BrVNsC72UYWES4A,ZZtBE1UbYMh = n3ot08Ck2OIaKFq1iJsvWQScyfx,DCguJjW2E9bQomXAqG
	count = len(uNLwCObJaUeKsyvjTrzinc56ZW1Dp)
	for CQMipytPbq in range(count):
		try:
			WjA38TbG4Sg60 = eval(uNLwCObJaUeKsyvjTrzinc56ZW1Dp[CQMipytPbq])
			return str(CQMipytPbq+1),WjA38TbG4Sg60
		except: pass
	return '',''
def D5t3HLgP7uads2lVWmYvC(BrVNsC72UYWES4A):
	try: LLnY31KGyp = list(BrVNsC72UYWES4A.keys())[0]
	except: return False,'','','','','','',''
	Ax4racOvNio2fRj9wPhFyBnSeE,title,ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,count,EDL3rwcivsR9W0pdTfygmOYUoVSb,vcZAMYo91uLtzbliawOx6GyKRT,BfZdAct4k0VDSeJ9uh = False,'','','','','','',''
	ZZtBE1UbYMh = BrVNsC72UYWES4A[LLnY31KGyp]
	UaCSPBpXzR0JgKYocbwk4GETj2t = []
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("render['unplayableText']['simpleText']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("render['formattedTitle']['simpleText']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("render['title']['simpleText']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("render['title']['runs'][0]['text']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("render['text']['simpleText']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("render['text']['runs'][0]['text']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("render['title']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("item['title']")
	OtTkHdy0XAQjnvBZbGmhwK,title = YUIOn5yPWjh8mFMtEXdHZu(BrVNsC72UYWES4A,ZZtBE1UbYMh,UaCSPBpXzR0JgKYocbwk4GETj2t)
	UaCSPBpXzR0JgKYocbwk4GETj2t = []
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("render['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("render['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("render['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	OtTkHdy0XAQjnvBZbGmhwK,ELbNB92cOh5dqtpVmi40kY = YUIOn5yPWjh8mFMtEXdHZu(BrVNsC72UYWES4A,ZZtBE1UbYMh,UaCSPBpXzR0JgKYocbwk4GETj2t)
	UaCSPBpXzR0JgKYocbwk4GETj2t = []
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("render['thumbnail']['thumbnails'][0]['url']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("render['thumbnails'][0]['thumbnails'][0]['url']")
	OtTkHdy0XAQjnvBZbGmhwK,VFqpJjRySZvgi = YUIOn5yPWjh8mFMtEXdHZu(BrVNsC72UYWES4A,ZZtBE1UbYMh,UaCSPBpXzR0JgKYocbwk4GETj2t)
	UaCSPBpXzR0JgKYocbwk4GETj2t = []
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("render['videoCount']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("render['videoCountText']['runs'][0]['text']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("render['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	OtTkHdy0XAQjnvBZbGmhwK,count = YUIOn5yPWjh8mFMtEXdHZu(BrVNsC72UYWES4A,ZZtBE1UbYMh,UaCSPBpXzR0JgKYocbwk4GETj2t)
	UaCSPBpXzR0JgKYocbwk4GETj2t = []
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("render['lengthText']['simpleText']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	UaCSPBpXzR0JgKYocbwk4GETj2t.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	OtTkHdy0XAQjnvBZbGmhwK,EDL3rwcivsR9W0pdTfygmOYUoVSb = YUIOn5yPWjh8mFMtEXdHZu(BrVNsC72UYWES4A,ZZtBE1UbYMh,UaCSPBpXzR0JgKYocbwk4GETj2t)
	if 'LIVE' in EDL3rwcivsR9W0pdTfygmOYUoVSb: EDL3rwcivsR9W0pdTfygmOYUoVSb,vcZAMYo91uLtzbliawOx6GyKRT = '','LIVE:  '
	if 'مباشر' in EDL3rwcivsR9W0pdTfygmOYUoVSb: EDL3rwcivsR9W0pdTfygmOYUoVSb,vcZAMYo91uLtzbliawOx6GyKRT = '','LIVE:  '
	if 'badges' in list(ZZtBE1UbYMh.keys()):
		GCvmIBpyo7LH6cN1 = str(ZZtBE1UbYMh['badges'])
		if 'Free with Ads' in GCvmIBpyo7LH6cN1: BfZdAct4k0VDSeJ9uh = '$:'
		if 'LIVE NOW' in GCvmIBpyo7LH6cN1: vcZAMYo91uLtzbliawOx6GyKRT = 'LIVE:  '
		if 'Buy' in GCvmIBpyo7LH6cN1 or 'Rent' in GCvmIBpyo7LH6cN1: BfZdAct4k0VDSeJ9uh = '$$:'
		if FEaio7MR2CjTJ9ZLVQnhNewgpv(u'مباشر') in GCvmIBpyo7LH6cN1: vcZAMYo91uLtzbliawOx6GyKRT = 'LIVE:  '
		if FEaio7MR2CjTJ9ZLVQnhNewgpv(u'شراء') in GCvmIBpyo7LH6cN1: BfZdAct4k0VDSeJ9uh = '$$:'
		if FEaio7MR2CjTJ9ZLVQnhNewgpv(u'استئجار') in GCvmIBpyo7LH6cN1: BfZdAct4k0VDSeJ9uh = '$$:'
		if FEaio7MR2CjTJ9ZLVQnhNewgpv(u'إعلانات') in GCvmIBpyo7LH6cN1: BfZdAct4k0VDSeJ9uh = '$:'
	ELbNB92cOh5dqtpVmi40kY = ptMqV54oKJhQ8CH(ELbNB92cOh5dqtpVmi40kY)
	if ELbNB92cOh5dqtpVmi40kY and 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
	VFqpJjRySZvgi = VFqpJjRySZvgi.split('?')[0]
	if  VFqpJjRySZvgi and 'http' not in VFqpJjRySZvgi: VFqpJjRySZvgi = 'https:'+VFqpJjRySZvgi
	title = ptMqV54oKJhQ8CH(title)
	if BfZdAct4k0VDSeJ9uh: title = BfZdAct4k0VDSeJ9uh+'  '+title
	EDL3rwcivsR9W0pdTfygmOYUoVSb = EDL3rwcivsR9W0pdTfygmOYUoVSb.replace(',','')
	count = count.replace(',','')
	count = GGvHJKP9LUxEk10Fw.findall('\d+',count)
	if count: count = count[0]
	else: count = ''
	return True,title,ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,count,EDL3rwcivsR9W0pdTfygmOYUoVSb,vcZAMYo91uLtzbliawOx6GyKRT,BfZdAct4k0VDSeJ9uh
def xs5qyN8IWjmhu9t2wKH6TXOaS(BrVNsC72UYWES4A,url='',index=''):
	Ax4racOvNio2fRj9wPhFyBnSeE,title,ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,count,EDL3rwcivsR9W0pdTfygmOYUoVSb,vcZAMYo91uLtzbliawOx6GyKRT,BfZdAct4k0VDSeJ9uh = D5t3HLgP7uads2lVWmYvC(BrVNsC72UYWES4A)
	if not Ax4racOvNio2fRj9wPhFyBnSeE: return
	elif 'continuationItemRenderer' in str(BrVNsC72UYWES4A): return
	elif 'searchPyvRenderer' in str(BrVNsC72UYWES4A): return
	elif not ELbNB92cOh5dqtpVmi40kY and 'search_query' in url: return
	elif title and not ELbNB92cOh5dqtpVmi40kY and ('search_query' in url or 'horizontalMovieListRenderer' in str(BrVNsC72UYWES4A) or url==NBm2aWhPzoTpdYn):
		title = '=== '+title+' ==='
		cd0aGwCPExbFU5pYNu8r('link',mmDwMlfoHtG5XT19VLIWqCR8i+title,'',9999)
	elif title and 'messageRenderer' in str(BrVNsC72UYWES4A):
		cd0aGwCPExbFU5pYNu8r('link',mmDwMlfoHtG5XT19VLIWqCR8i+title,'',9999)
	elif '/feed/trending' in ELbNB92cOh5dqtpVmi40kY: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,144,VFqpJjRySZvgi,index)
	elif not title: return
	elif vcZAMYo91uLtzbliawOx6GyKRT: cd0aGwCPExbFU5pYNu8r('live',mmDwMlfoHtG5XT19VLIWqCR8i+vcZAMYo91uLtzbliawOx6GyKRT+title,ELbNB92cOh5dqtpVmi40kY,143,VFqpJjRySZvgi)
	elif 'watch?v=' in ELbNB92cOh5dqtpVmi40kY or '/shorts/' in ELbNB92cOh5dqtpVmi40kY:
		if '&list=' in ELbNB92cOh5dqtpVmi40kY and 'index=' not in ELbNB92cOh5dqtpVmi40kY:
			BBXLTRwUZoF1v7rHDiA5 = ELbNB92cOh5dqtpVmi40kY.split('&list=',1)[1]
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/playlist?list='+BBXLTRwUZoF1v7rHDiA5
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'LIST'+count+':  '+title,ELbNB92cOh5dqtpVmi40kY,144,VFqpJjRySZvgi)
		else:
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.split('&list=',1)[0]
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,143,VFqpJjRySZvgi,EDL3rwcivsR9W0pdTfygmOYUoVSb)
	else:
		type = ''
		if not ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = url
		elif not any(hieW1zRUG5w9AykJjv0X in ELbNB92cOh5dqtpVmi40kY for hieW1zRUG5w9AykJjv0X in ['/videos','/playlists','/channels','/featured','ss=','bp=']):
			if '/channel/'	in ELbNB92cOh5dqtpVmi40kY or '/c/' in ELbNB92cOh5dqtpVmi40kY: type = 'CHNL'+count+':  '
			if '/user/' in ELbNB92cOh5dqtpVmi40kY: type = 'USER'+count+':  '
			index,P9y6NJdaTK = '',''
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+type+title,ELbNB92cOh5dqtpVmi40kY,144,VFqpJjRySZvgi,index)
	return
def rKP5lefC2pJ4hNxgQ(url,data='',hD6se2E307NcI=''):
	global jHevARrF7lS
	if not data: data = jHevARrF7lS.getSetting('av.youtube.data')
	if hD6se2E307NcI=='': hD6se2E307NcI = 'ytInitialData'
	bTDaxXYSseoFCI6cQ4f58vqr3dPNp = Y8Y6b7aLSUKjdE1Ae()
	BBYvCiQGe8RdpyAagfS72mZclxb5 = {'User-Agent':bTDaxXYSseoFCI6cQ4f58vqr3dPNp,'Cookie':'PREF=hl=ar'}
	if ':::' in data: R2XCvULdcta1fWkIzwo4Ge6u,key,ggBUqDPoF3Z24we,XVSW1sQ4dAGx2hpUwHk8KT,DI9PgKJNvLiuBpXyctMs2RklobGA,SdAk9PfCaWtov0K4GnxIYUcQX8 = data.split(':::')
	else: R2XCvULdcta1fWkIzwo4Ge6u,key,ggBUqDPoF3Z24we,XVSW1sQ4dAGx2hpUwHk8KT,DI9PgKJNvLiuBpXyctMs2RklobGA,SdAk9PfCaWtov0K4GnxIYUcQX8 = '','','','','',''
	if 'guide?key=' in url:
		Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = {}
		Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd['context'] = {"client":{"hl":"ar","clientName":"WEB","clientVersion":XVSW1sQ4dAGx2hpUwHk8KT}}
		Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = str(Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd)
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'POST',url,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif 'key=' in url and R2XCvULdcta1fWkIzwo4Ge6u:
		Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = {'continuation':DI9PgKJNvLiuBpXyctMs2RklobGA}
		Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd['context'] = {"client":{"visitorData":R2XCvULdcta1fWkIzwo4Ge6u,"clientName":"WEB","clientVersion":XVSW1sQ4dAGx2hpUwHk8KT}}
		Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd = str(Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd)
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'POST',url,Zq0HJYpLMTu9NAi5SER7gUzhyjFvwd,BBYvCiQGe8RdpyAagfS72mZclxb5,True,True,'YOUTUBE-GET_PAGE_DATA-2nd')
	elif 'ctoken=' in url and SdAk9PfCaWtov0K4GnxIYUcQX8:
		BBYvCiQGe8RdpyAagfS72mZclxb5.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':XVSW1sQ4dAGx2hpUwHk8KT})
		BBYvCiQGe8RdpyAagfS72mZclxb5.update({'Cookie':'VISITOR_INFO1_LIVE='+SdAk9PfCaWtov0K4GnxIYUcQX8})
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'GET',url,'',BBYvCiQGe8RdpyAagfS72mZclxb5,'','','YOUTUBE-GET_PAGE_DATA-3rd')
	else:
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'GET',url,'',BBYvCiQGe8RdpyAagfS72mZclxb5,'','','YOUTUBE-GET_PAGE_DATA-4th')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	fbt2z8IFXaDclZhGQ4io = GGvHJKP9LUxEk10Fw.findall('"innertubeApiKey".*?"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.I)
	if fbt2z8IFXaDclZhGQ4io: key = fbt2z8IFXaDclZhGQ4io[0]
	fbt2z8IFXaDclZhGQ4io = GGvHJKP9LUxEk10Fw.findall('"cver".*?"value".*?"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.I)
	if fbt2z8IFXaDclZhGQ4io: XVSW1sQ4dAGx2hpUwHk8KT = fbt2z8IFXaDclZhGQ4io[0]
	fbt2z8IFXaDclZhGQ4io = GGvHJKP9LUxEk10Fw.findall('"token".*?"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.I)
	if fbt2z8IFXaDclZhGQ4io: DI9PgKJNvLiuBpXyctMs2RklobGA = fbt2z8IFXaDclZhGQ4io[0]
	fbt2z8IFXaDclZhGQ4io = GGvHJKP9LUxEk10Fw.findall('"visitorData".*?"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.I)
	if fbt2z8IFXaDclZhGQ4io: R2XCvULdcta1fWkIzwo4Ge6u = fbt2z8IFXaDclZhGQ4io[0]
	fbt2z8IFXaDclZhGQ4io = GGvHJKP9LUxEk10Fw.findall('"continuation".*?"(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.I)
	if fbt2z8IFXaDclZhGQ4io: ggBUqDPoF3Z24we = fbt2z8IFXaDclZhGQ4io[0]
	cookies = WbTGMHnDysdYZ2lFA.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): SdAk9PfCaWtov0K4GnxIYUcQX8 = cookies['VISITOR_INFO1_LIVE']
	data = R2XCvULdcta1fWkIzwo4Ge6u+':::'+key+':::'+ggBUqDPoF3Z24we+':::'+XVSW1sQ4dAGx2hpUwHk8KT+':::'+DI9PgKJNvLiuBpXyctMs2RklobGA+':::'+SdAk9PfCaWtov0K4GnxIYUcQX8
	if hD6se2E307NcI=='ytInitialData' and 'ytInitialData' in BBlXpmUyhFDwNtCVAHoE:
		Bp3FCNtj6r5gef8L = GGvHJKP9LUxEk10Fw.findall('window\["ytInitialData"\] = ({.*?});',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if not Bp3FCNtj6r5gef8L: Bp3FCNtj6r5gef8L = GGvHJKP9LUxEk10Fw.findall('var ytInitialData = ({.*?});',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		KKJmP0jzaiT2lyM3DYnQ6AW7o8Xd5 = JKw5OWktPZB('str',Bp3FCNtj6r5gef8L[0])
	elif hD6se2E307NcI=='ytInitialGuideData' and 'ytInitialGuideData' in BBlXpmUyhFDwNtCVAHoE:
		Bp3FCNtj6r5gef8L = GGvHJKP9LUxEk10Fw.findall('var ytInitialGuideData = ({.*?});',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		KKJmP0jzaiT2lyM3DYnQ6AW7o8Xd5 = JKw5OWktPZB('str',Bp3FCNtj6r5gef8L[0])
	elif '</script>' not in BBlXpmUyhFDwNtCVAHoE: KKJmP0jzaiT2lyM3DYnQ6AW7o8Xd5 = JKw5OWktPZB('str',BBlXpmUyhFDwNtCVAHoE)
	else: KKJmP0jzaiT2lyM3DYnQ6AW7o8Xd5 = ''
	jHevARrF7lS.setSetting('av.youtube.data',data)
	return BBlXpmUyhFDwNtCVAHoE,KKJmP0jzaiT2lyM3DYnQ6AW7o8Xd5,data
def NgvYbofjGDJQXMcZSt7B9u6el(url):
	search = yMRXZIpKxlSkaE6iCO()
	if not search: return
	search = search.replace(' ','+')
	dR2vHyAtl8pJN1 = url+'/search?query='+search
	L4L0TUsN51taeljfc(dR2vHyAtl8pJN1)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if not search:
		search = yMRXZIpKxlSkaE6iCO()
		if not search: return
	search = search.replace(' ','+')
	dR2vHyAtl8pJN1 = NBm2aWhPzoTpdYn+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in tY3Dfrp6cMKFj: QFnjfwW5k984tKT6 = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in tY3Dfrp6cMKFj: QFnjfwW5k984tKT6 = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in tY3Dfrp6cMKFj: QFnjfwW5k984tKT6 = '&sp=EgIQAg%253D%253D'
		XwyU6PQgprMI0 = dR2vHyAtl8pJN1+QFnjfwW5k984tKT6
	else:
		ga1pf2D9JQTLmMGyk4jetPvXrW0,qGD53zc2bQKtX8Nnw7SYv6IMeVmiWP,qPmCp1Q4gRekdAH = [],[],''
		tt4dyBw6spGr = ['بدون ترتيب','ترتيب حسب مدى الصلة','ترتيب حسب تاريخ التحميل','ترتيب حسب عدد المشاهدات','ترتيب حسب التقييم']
		HHOnVAhFqZpgWCakiLmrRXYSJ3ITv = ['','&sp=CAA%253D','&sp=CAI%253D','&sp=CAM%253D','&sp=CAE%253D']
		Ct2LAYmsTvIcKzoEH0uV1QS = D1DJtzviFZSrA('موقع يوتيوب - اختر الترتيب',tt4dyBw6spGr)
		if Ct2LAYmsTvIcKzoEH0uV1QS == -1: return
		ElVJ3XuygPMnHz5TpkLAQv = HHOnVAhFqZpgWCakiLmrRXYSJ3ITv[Ct2LAYmsTvIcKzoEH0uV1QS]
		BBlXpmUyhFDwNtCVAHoE,MajNPJp5oc2ZYftDHg,data = rKP5lefC2pJ4hNxgQ(dR2vHyAtl8pJN1+ElVJ3XuygPMnHz5TpkLAQv)
		if MajNPJp5oc2ZYftDHg:
			wLsNCkZDPednXF6r1RlB7gEqoQ = MajNPJp5oc2ZYftDHg['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
			for rrQCv5GDdOjlTn6oZ7FJxLg in range(len(wLsNCkZDPednXF6r1RlB7gEqoQ)):
				group = wLsNCkZDPednXF6r1RlB7gEqoQ[rrQCv5GDdOjlTn6oZ7FJxLg]['searchFilterGroupRenderer']['filters']
				for TTLOpPkRY4UDZB0Msvt6K in range(len(group)):
					ZZtBE1UbYMh = group[TTLOpPkRY4UDZB0Msvt6K]['searchFilterRenderer']
					if 'navigationEndpoint' in list(ZZtBE1UbYMh.keys()):
						ELbNB92cOh5dqtpVmi40kY = ZZtBE1UbYMh['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
						ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.replace('\u0026','&')
						title = ZZtBE1UbYMh['tooltip']
						title = title.replace('البحث عن ','')
						if 'إزالة الفلتر' in title: continue
						if 'قائمة تشغيل' in title:
							title = 'جيد للمسلسلات '+title
							qPmCp1Q4gRekdAH = title
							E2EhMuOLdF08Pz75jDKS14cfYNxy = ELbNB92cOh5dqtpVmi40kY
						if 'ترتيب حسب' in title: continue
						title = title.replace('Search for ','')
						if 'Remove' in title: continue
						if 'Playlist' in title:
							title = 'جيد للمسلسلات '+title
							qPmCp1Q4gRekdAH = title
							E2EhMuOLdF08Pz75jDKS14cfYNxy = ELbNB92cOh5dqtpVmi40kY
						if 'Sort by' in title: continue
						ga1pf2D9JQTLmMGyk4jetPvXrW0.append(ptMqV54oKJhQ8CH(title))
						qGD53zc2bQKtX8Nnw7SYv6IMeVmiWP.append(ELbNB92cOh5dqtpVmi40kY)
		if not qPmCp1Q4gRekdAH: nuXhiECNxYUt6TBMSagv7l43m = ''
		else:
			ga1pf2D9JQTLmMGyk4jetPvXrW0 = ['بدون فلتر',qPmCp1Q4gRekdAH]+ga1pf2D9JQTLmMGyk4jetPvXrW0
			qGD53zc2bQKtX8Nnw7SYv6IMeVmiWP = ['',E2EhMuOLdF08Pz75jDKS14cfYNxy]+qGD53zc2bQKtX8Nnw7SYv6IMeVmiWP
			jHVDzSWJRnmuwAN3oM0GLs = D1DJtzviFZSrA('موقع يوتيوب - اختر الفلتر',ga1pf2D9JQTLmMGyk4jetPvXrW0)
			if jHVDzSWJRnmuwAN3oM0GLs == -1: return
			nuXhiECNxYUt6TBMSagv7l43m = qGD53zc2bQKtX8Nnw7SYv6IMeVmiWP[jHVDzSWJRnmuwAN3oM0GLs]
		if nuXhiECNxYUt6TBMSagv7l43m: XwyU6PQgprMI0 = NBm2aWhPzoTpdYn+nuXhiECNxYUt6TBMSagv7l43m
		elif ElVJ3XuygPMnHz5TpkLAQv: XwyU6PQgprMI0 = dR2vHyAtl8pJN1+ElVJ3XuygPMnHz5TpkLAQv
		else: XwyU6PQgprMI0 = dR2vHyAtl8pJN1
	L4L0TUsN51taeljfc(XwyU6PQgprMI0)
	return
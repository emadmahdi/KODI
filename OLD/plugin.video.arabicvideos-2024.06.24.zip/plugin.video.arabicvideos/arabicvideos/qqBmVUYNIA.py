# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'SHOOFPRO'
mmDwMlfoHtG5XT19VLIWqCR8i = '_SHP_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
DDXTwbRBaj3e2rSsPQ = ['مصارعة','بث مباشر']
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==480: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==481: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,text)
	elif mode==482: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==483: zpXG3Ky6ou8ndWHkb4 = hWPvGlXZ5arzV7(url,text)
	elif mode==489: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text,url)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',NBm2aWhPzoTpdYn,'','','','','SHOOFPRO-MENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	aPNBvIyexc053gAsSw1QoRMUYfb = GGvHJKP9LUxEk10Fw.findall('href="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	aPNBvIyexc053gAsSw1QoRMUYfb = aPNBvIyexc053gAsSw1QoRMUYfb[0].strip('/')
	aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(aPNBvIyexc053gAsSw1QoRMUYfb,'url')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع',aPNBvIyexc053gAsSw1QoRMUYfb,489,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'أحدث المواضيع',aPNBvIyexc053gAsSw1QoRMUYfb,481)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"navigation"(.*?)"myAccount"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?</span>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		if ELbNB92cOh5dqtpVmi40kY=='#': continue
		if title in DDXTwbRBaj3e2rSsPQ: continue
		title = DwNC3gEonizsB6a0v1F(title)
		cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,481)
	return BBlXpmUyhFDwNtCVAHoE
def xoiXMWjJC3pnQqurIGPkRSl8e(url,wozOhs3guHpGCPU54):
	items = []
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','SHOOFPRO-TITLES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"post(.*?)"footer"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not EeQqAGc0W5r6nlBbChwfZL: return
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)" title="(.*?)".*?image:url\((.*?)\)',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	IcJOGsq3Ff7EmkiLx = []
	Dq0X5cvgdjwh6LbnUkETFBR8 = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	uqIp9B87eg2wV = '/'.join(wozOhs3guHpGCPU54.strip('/').split('/')[4:]).split('-')
	for ELbNB92cOh5dqtpVmi40kY,title,VFqpJjRySZvgi in items:
		title = DwNC3gEonizsB6a0v1F(title)
		qUGxSK2VwsiBAdkDZnJ605vQeg = GGvHJKP9LUxEk10Fw.findall('(.*?) حلقة \d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
		if wozOhs3guHpGCPU54:
			E2EhMuOLdF08Pz75jDKS14cfYNxy = '/'.join(ELbNB92cOh5dqtpVmi40kY.strip('/').split('/')[4:]).split('-')
			G5nqTch7o6gyavUZPKjwX08 = len([kH2pUF40DrLlqiPhM9wtKc for kH2pUF40DrLlqiPhM9wtKc in uqIp9B87eg2wV if kH2pUF40DrLlqiPhM9wtKc in E2EhMuOLdF08Pz75jDKS14cfYNxy])
			if G5nqTch7o6gyavUZPKjwX08>2 and '/episodes/' in ELbNB92cOh5dqtpVmi40kY:
				cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,482,VFqpJjRySZvgi)
		else:
			if not qUGxSK2VwsiBAdkDZnJ605vQeg: qUGxSK2VwsiBAdkDZnJ605vQeg = GGvHJKP9LUxEk10Fw.findall('(.*?) الحلقة \d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
			if set(title.split()) & set(Dq0X5cvgdjwh6LbnUkETFBR8) and 'مسلسل' not in title:
				cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,482,VFqpJjRySZvgi)
			elif qUGxSK2VwsiBAdkDZnJ605vQeg and 'حلقة' in title:
				title = '_MOD_' + qUGxSK2VwsiBAdkDZnJ605vQeg[0]
				if title not in IcJOGsq3Ff7EmkiLx:
					cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,483,VFqpJjRySZvgi,'',url)
					IcJOGsq3Ff7EmkiLx.append(title)
			else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,483,VFqpJjRySZvgi,'',url)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall("'pagination'(.*?)</div>",BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall("href='(.*?)'.*?>(.*?)</a>",UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			title = DwNC3gEonizsB6a0v1F(title)
			title = title.replace('الصفحة ','')
			if title!='': cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,481,'','',wozOhs3guHpGCPU54)
	return
def hWPvGlXZ5arzV7(url,dR2vHyAtl8pJN1):
	headers = {'X-Requested-With':'XMLHttpRequest'}
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'',headers,'','','SHOOFPRO-EPISODES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(url,'url')
	VFqpJjRySZvgi = GGvHJKP9LUxEk10Fw.findall('"img-responsive" src="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if VFqpJjRySZvgi: VFqpJjRySZvgi = VFqpJjRySZvgi[0]
	else: VFqpJjRySZvgi = cEZpW924rqNYm5.getInfoLabel('ListItem.Thumb')
	zhSmt0plEjfL6uGOWx9PFUdNRI = True
	xxcVm7YBMXsfd = GGvHJKP9LUxEk10Fw.findall('"listSeasons(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if xxcVm7YBMXsfd and '/ajax/seasons' not in url:
		UCEFMfKbgpd = xxcVm7YBMXsfd[0]
		count = UCEFMfKbgpd.count('data-slug=')
		if count==0: count = UCEFMfKbgpd.count('data-season=')
		if count>1:
			zhSmt0plEjfL6uGOWx9PFUdNRI = False
			if 'data-slug="' in UCEFMfKbgpd:
				items = GGvHJKP9LUxEk10Fw.findall('data-slug="(.*?)">(.*?)</li>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
				for id,title in items:
					ELbNB92cOh5dqtpVmi40kY = aPNBvIyexc053gAsSw1QoRMUYfb+'/wp-content/themes/vo2021/temp/ajax/seasons2.php?slug='+id
					cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,483,VFqpJjRySZvgi)
			else:
				items = GGvHJKP9LUxEk10Fw.findall('data-season="(.*?)">(.*?)</li>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
				for id,title in items:
					ELbNB92cOh5dqtpVmi40kY = aPNBvIyexc053gAsSw1QoRMUYfb+'/wp-content/themes/vo2021/temp/ajax/seasons.php?seriesID='+id
					cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,483,VFqpJjRySZvgi)
	if zhSmt0plEjfL6uGOWx9PFUdNRI:
		UCEFMfKbgpd = ''
		if '/ajax/seasons' in url: UCEFMfKbgpd = BBlXpmUyhFDwNtCVAHoE
		else:
			uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb = GGvHJKP9LUxEk10Fw.findall('"eplist"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
			if uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb: UCEFMfKbgpd = uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)" title="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if items:
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				title = title.strip(' ')
				cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,482,VFqpJjRySZvgi)
	if not D6DrJsclfY: xoiXMWjJC3pnQqurIGPkRSl8e(dR2vHyAtl8pJN1,url)
	return
def SUfe4unWoXBNFz90xqy(url):
	dR2vHyAtl8pJN1 = url.strip('/')+'/?do=watch'
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',dR2vHyAtl8pJN1,'','','','','SHOOFPRO-PLAY-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	zzvBg3ShiamAZ = []
	aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(url,'url')
	Y5VwgWbBtTIAMsfRL8S4k = GGvHJKP9LUxEk10Fw.findall('vo_postID = "(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not Y5VwgWbBtTIAMsfRL8S4k: Y5VwgWbBtTIAMsfRL8S4k = GGvHJKP9LUxEk10Fw.findall('\(this\.id\,0\,(.*?)\)',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	Y5VwgWbBtTIAMsfRL8S4k = Y5VwgWbBtTIAMsfRL8S4k[0]
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"serversList"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('id="(.*?)".*?">(.*?)</li>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for l3esWY6Jcjg9FTE,title in items:
			title = title.strip(' ')
			ELbNB92cOh5dqtpVmi40kY = aPNBvIyexc053gAsSw1QoRMUYfb+'/wp-content/themes/vo2021/temp/ajax/iframe2.php?id='+Y5VwgWbBtTIAMsfRL8S4k+'&video='+l3esWY6Jcjg9FTE[2:]+'?named='+title+'__watch'
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall('"getEmbed".*?src="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if ELbNB92cOh5dqtpVmi40kY:
		title = RfKuIXwPAiWtmyF(ELbNB92cOh5dqtpVmi40kY[0],'url')
		ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY[0]+'?named='+title+'__embed'
		zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	dR2vHyAtl8pJN1 = url.strip('/')+'/?do=download'
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',dR2vHyAtl8pJN1,'','','','','SHOOFPRO-PLAY-2nd')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"table-responsive"(.*?)</table>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('<td>(.*?)</td>.*?href="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for title,ELbNB92cOh5dqtpVmi40kY in items:
			title = title.strip(' ')
			if 'anavidz' in ELbNB92cOh5dqtpVmi40kY: qPmCp1Q4gRekdAH = '__خاص'
			else: qPmCp1Q4gRekdAH = ''
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named='+title+'__download'+qPmCp1Q4gRekdAH
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(zzvBg3ShiamAZ,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search,aPNBvIyexc053gAsSw1QoRMUYfb=''):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	search = search.replace(' ','+')
	if aPNBvIyexc053gAsSw1QoRMUYfb=='': aPNBvIyexc053gAsSw1QoRMUYfb = NBm2aWhPzoTpdYn
	url = aPNBvIyexc053gAsSw1QoRMUYfb+'/search/'+search+'/'
	xoiXMWjJC3pnQqurIGPkRSl8e(url,'')
	return
# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'FASELHD1'
headers = {'User-Agent':''}
mmDwMlfoHtG5XT19VLIWqCR8i = '_FH1_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
DDXTwbRBaj3e2rSsPQ = ['جوائز الأوسكار','المراجعات','wwe']
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==570: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==571: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,text)
	elif mode==572: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==573: zpXG3Ky6ou8ndWHkb4 = pFmAuvrtnqEijTeQ4MRaw(url,text)
	elif mode==576: zpXG3Ky6ou8ndWHkb4 = nZo7TtikeCMhpLSJwVjYAl9()
	elif mode==579: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	cd0aGwCPExbFU5pYNu8r('link',mmDwMlfoHtG5XT19VLIWqCR8i+'لماذا الموقع بطيء','',576)
	aPNBvIyexc053gAsSw1QoRMUYfb,url,WbTGMHnDysdYZ2lFA = dL4qOfSeD1Jghxw2uVC(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',NBm2aWhPzoTpdYn,'faselhd1','فاصل إعلاني','dubbed-movies')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع',aPNBvIyexc053gAsSw1QoRMUYfb,579,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'المميزة',aPNBvIyexc053gAsSw1QoRMUYfb,571,'','','featured1')
	items = GGvHJKP9LUxEk10Fw.findall('class="h3">(.*?)<.*?href="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not items:
		aHKzv76JCVnprbY8w('','','موقع فاصل الأول','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	for title,ELbNB92cOh5dqtpVmi40kY in items:
		cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,571,'','','details1')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"menu-primary"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		PDj2GmxN3EVbne = GGvHJKP9LUxEk10Fw.findall('<li (.*?)</li>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		Ui4p5bTRlZmx7nM8qy9FAPXdcYwof = ['','أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		CQMipytPbq = 0
		for qERDVNWvZzbf9O8sXCxi in PDj2GmxN3EVbne:
			if CQMipytPbq>0: cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)<',qERDVNWvZzbf9O8sXCxi,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				if ELbNB92cOh5dqtpVmi40kY=='#': continue
				if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = aPNBvIyexc053gAsSw1QoRMUYfb+ELbNB92cOh5dqtpVmi40kY
				if title=='': continue
				if any(hieW1zRUG5w9AykJjv0X in title.lower() for hieW1zRUG5w9AykJjv0X in DDXTwbRBaj3e2rSsPQ): continue
				title = Ui4p5bTRlZmx7nM8qy9FAPXdcYwof[CQMipytPbq]+title
				cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,571,'','','details2')
			CQMipytPbq += 1
	return
def nZo7TtikeCMhpLSJwVjYAl9():
	aHKzv76JCVnprbY8w('','','رسالة من المبرمج','موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(url,type=''):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','FASELHD1-TITLES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb = GGvHJKP9LUxEk10Fw.findall('class="h4">(.*?)</div>(.*?)"container"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb: return
	if type=='filters':
		EeQqAGc0W5r6nlBbChwfZL = [BBlXpmUyhFDwNtCVAHoE.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"homeSlide"(.*?)"container"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		rgeSdYacsZyqQpA3NvTEu,gI487voLsArVqW6Ffp,xut3LAibydXZnzkpBaKOsgew70 = zip(*items)
		items = zip(gI487voLsArVqW6Ffp,rgeSdYacsZyqQpA3NvTEu,xut3LAibydXZnzkpBaKOsgew70)
	elif type=='featured2':
		title,UCEFMfKbgpd = uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	elif type=='details2' and len(uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb)>1:
		title = uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb[0][0]
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,571,'','','featured2')
		title = uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb[1][0]
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,571,'','','details3')
		return
	else:
		title,UCEFMfKbgpd = uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb[-1]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	IcJOGsq3Ff7EmkiLx = []
	for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
		if any(hieW1zRUG5w9AykJjv0X in title.lower() for hieW1zRUG5w9AykJjv0X in DDXTwbRBaj3e2rSsPQ): continue
		VFqpJjRySZvgi = ptMqV54oKJhQ8CH(VFqpJjRySZvgi)
		VFqpJjRySZvgi = VFqpJjRySZvgi.split('?resize=')[0]
		title = DwNC3gEonizsB6a0v1F(title)
		qUGxSK2VwsiBAdkDZnJ605vQeg = GGvHJKP9LUxEk10Fw.findall('(.*?) (الحلقة|حلقة).\d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
		if '/collections/' in ELbNB92cOh5dqtpVmi40kY:
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,571,VFqpJjRySZvgi)
		elif qUGxSK2VwsiBAdkDZnJ605vQeg and type=='':
			title = '_MOD_'+qUGxSK2VwsiBAdkDZnJ605vQeg[0][0]
			title = title.strip(' –')
			if title not in IcJOGsq3Ff7EmkiLx:
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,573,VFqpJjRySZvgi)
				IcJOGsq3Ff7EmkiLx.append(title)
		elif 'episodes/' in ELbNB92cOh5dqtpVmi40kY or 'movies/' in ELbNB92cOh5dqtpVmi40kY or 'hindi/' in ELbNB92cOh5dqtpVmi40kY:
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,572,VFqpJjRySZvgi)
		else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,573,VFqpJjRySZvgi)
	if type=='filters':
		WgtDJdf7CrpxK41GQAMkyjSF8bu = GGvHJKP9LUxEk10Fw.findall('"more_button_page":(.*?),',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if WgtDJdf7CrpxK41GQAMkyjSF8bu:
			count = WgtDJdf7CrpxK41GQAMkyjSF8bu[0]
			ELbNB92cOh5dqtpVmi40kY = url+'/offset/'+count
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة أخرى',ELbNB92cOh5dqtpVmi40kY,571,'','','filters')
	elif 'details' in type:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall("class='pagination(.*?)</div>",BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
			items = GGvHJKP9LUxEk10Fw.findall("href='(.*?)'.*?>(.*?)<",UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				title = 'صفحة '+DwNC3gEonizsB6a0v1F(title)
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,571,'','','details4')
	return
def pFmAuvrtnqEijTeQ4MRaw(url,type=''):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','FASELHD1-SEASONS_EPISODES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	tt0PDNvYRduaiJSh8 = False
	if not type:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"seasonList"(.*?)"container"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
			items = GGvHJKP9LUxEk10Fw.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			if len(items)>1:
				aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(url,'url')
				tt0PDNvYRduaiJSh8 = True
				for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,name,title in items:
					name = DwNC3gEonizsB6a0v1F(name)
					if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = aPNBvIyexc053gAsSw1QoRMUYfb+ELbNB92cOh5dqtpVmi40kY
					title = name+' - '+title
					cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,573,VFqpJjRySZvgi,'','episodes')
	if type=='episodes' or not tt0PDNvYRduaiJSh8:
		nWO8c3IgspK67QX = GGvHJKP9LUxEk10Fw.findall('"posterImg".*?src="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if nWO8c3IgspK67QX: VFqpJjRySZvgi = nWO8c3IgspK67QX[0]
		else: VFqpJjRySZvgi = ''
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"epAll"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				title = title.strip(' ')
				title = DwNC3gEonizsB6a0v1F(title)
				cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,572,VFqpJjRySZvgi)
	return
def SUfe4unWoXBNFz90xqy(url):
	uuIjMn1YTf687WlRcOmhq4G23H,fvwYpJEzgA,XmkyiLasFhMzCGYQu8rA = [],[],[]
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'GET',url,'','','','','FASELHD1-PLAY-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	uq1XDjRm9z5nUvH23hL = GGvHJKP9LUxEk10Fw.findall('مستوى المشاهدة.*?">(.*?)</span>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if uq1XDjRm9z5nUvH23hL:
		NbE4qnzmPKGWtjYpoRL3HTS1A = GGvHJKP9LUxEk10Fw.findall('"tag">(.*?)</a>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if NbE4qnzmPKGWtjYpoRL3HTS1A and hNCJPTucIV7GOSR0HytZ6eQrqEUpw(cTJphS1nFz5EUgNWm86C,url,NbE4qnzmPKGWtjYpoRL3HTS1A): return
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"videoRow"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('src="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY in items:
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.split('&img=')[0]
			uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY+'?named=__embed')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="streamHeader(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall("href = '(.*?)'.*?</i>(.*?)</a>",UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,name in items:
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.split('&img=')[0]
			name = name.strip(' ')
			uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY+'?named='+name+'__watch')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="downloadLinks(.*?)blackwindow',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?</span>(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,name in items:
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.split('&img=')[0]
			uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY+'?named='+name+'__download')
	for P5c9KCQbrhE1FjRVl8HgfMvaOwAYGy in uuIjMn1YTf687WlRcOmhq4G23H:
		ELbNB92cOh5dqtpVmi40kY,name = P5c9KCQbrhE1FjRVl8HgfMvaOwAYGy.split('?named')
		if ELbNB92cOh5dqtpVmi40kY not in fvwYpJEzgA:
			fvwYpJEzgA.append(ELbNB92cOh5dqtpVmi40kY)
			XmkyiLasFhMzCGYQu8rA.append(P5c9KCQbrhE1FjRVl8HgfMvaOwAYGy)
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(XmkyiLasFhMzCGYQu8rA,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	search = search.replace(' ','+')
	url = NBm2aWhPzoTpdYn+'/?s='+search
	aPNBvIyexc053gAsSw1QoRMUYfb,dR2vHyAtl8pJN1,QQTDOLdNUAzYbfl1vXrM8mB = dL4qOfSeD1Jghxw2uVC(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'faselhd1','فاصل إعلاني','dubbed-movies')
	xoiXMWjJC3pnQqurIGPkRSl8e(dR2vHyAtl8pJN1,'details5')
	return
# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'MOVS4U'
mmDwMlfoHtG5XT19VLIWqCR8i = '_M4U_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
DDXTwbRBaj3e2rSsPQ = ['انواع افلام','جودات افلام']
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==380: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==381: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,text)
	elif mode==382: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==383: zpXG3Ky6ou8ndWHkb4 = hWPvGlXZ5arzV7(url)
	elif mode==389: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',389,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'المميزة',NBm2aWhPzoTpdYn,381,'','','featured')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'الجانبية',NBm2aWhPzoTpdYn,381,'','','sider')
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',NBm2aWhPzoTpdYn,'','','','','MOVS4U-MENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	items = GGvHJKP9LUxEk10Fw.findall('<header>.*?<h2>(.*?)<',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	for onj6XfdmELkTOlWH3xBhG1PC8F72 in range(len(items)):
		title = items[onj6XfdmELkTOlWH3xBhG1PC8F72]
		cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,NBm2aWhPzoTpdYn,381,'','','latest'+str(onj6XfdmELkTOlWH3xBhG1PC8F72))
	UCEFMfKbgpd = ''
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="menu"(.*?)id="contenedor"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL: UCEFMfKbgpd += EeQqAGc0W5r6nlBbChwfZL[0]
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="sidebar(.*?)aside',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL: UCEFMfKbgpd += EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	ltnfoZ29FRhWPwCbj = True
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		title = DwNC3gEonizsB6a0v1F(title)
		if title=='الأعلى مشاهدة':
			if ltnfoZ29FRhWPwCbj:
				title = 'الافلام '+title
				ltnfoZ29FRhWPwCbj = False
			else: title = 'المسلسلات '+title
		if title not in DDXTwbRBaj3e2rSsPQ:
			cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,381)
	return BBlXpmUyhFDwNtCVAHoE
def xoiXMWjJC3pnQqurIGPkRSl8e(url,type):
	UCEFMfKbgpd,items = [],[]
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','MOVS4U-TITLES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	if type=='search':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="search-page"(.*?)class="sidebar',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
			items = GGvHJKP9LUxEk10Fw.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	elif type=='sider':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="widget(.*?)class="widget',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		iFcwUG46bdgJ = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		zzvBg3ShiamAZ,o6SMpIvt0WjVymOxTeqE7A93Zindfr,eyUmvNFiYsE = zip(*iFcwUG46bdgJ)
		items = zip(o6SMpIvt0WjVymOxTeqE7A93Zindfr,zzvBg3ShiamAZ,eyUmvNFiYsE)
	elif type=='featured':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('id="slider-movies-tvshows"(.*?)<header>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	elif 'latest' in type:
		onj6XfdmELkTOlWH3xBhG1PC8F72 = int(type[-1:])
		BBlXpmUyhFDwNtCVAHoE = BBlXpmUyhFDwNtCVAHoE.replace('<header>','<end><start>')
		BBlXpmUyhFDwNtCVAHoE = BBlXpmUyhFDwNtCVAHoE.replace('<div class="sidebar','<end><div class="sidebar')
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('<start>(.*?)<end>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[onj6XfdmELkTOlWH3xBhG1PC8F72]
		if onj6XfdmELkTOlWH3xBhG1PC8F72==2: items = GGvHJKP9LUxEk10Fw.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	else:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="content"(.*?)class="(pagination|sidebar)',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0][0]
			if '/collection/' in url:
				items = GGvHJKP9LUxEk10Fw.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			elif '/quality/' in url:
				items = GGvHJKP9LUxEk10Fw.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	if not items and UCEFMfKbgpd:
		items = GGvHJKP9LUxEk10Fw.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	IcJOGsq3Ff7EmkiLx = []
	for VFqpJjRySZvgi,ELbNB92cOh5dqtpVmi40kY,title in items:
		if 'serie' in title:
			title = GGvHJKP9LUxEk10Fw.findall('^(.*?)<.*?serie">(.*?)<',title,GGvHJKP9LUxEk10Fw.DOTALL)
			title = title[0][1]
			if title in IcJOGsq3Ff7EmkiLx: continue
			IcJOGsq3Ff7EmkiLx.append(title)
			title = '_MOD_'+title
		qPmCp1Q4gRekdAH = GGvHJKP9LUxEk10Fw.findall('^(.*?)<',title,GGvHJKP9LUxEk10Fw.DOTALL)
		if qPmCp1Q4gRekdAH: title = qPmCp1Q4gRekdAH[0]
		title = DwNC3gEonizsB6a0v1F(title)
		if '/tvshows/' in ELbNB92cOh5dqtpVmi40kY: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,383,VFqpJjRySZvgi)
		elif '/episodes/' in ELbNB92cOh5dqtpVmi40kY: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,383,VFqpJjRySZvgi)
		elif '/seasons/' in ELbNB92cOh5dqtpVmi40kY: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,383,VFqpJjRySZvgi)
		elif '/collection/' in ELbNB92cOh5dqtpVmi40kY: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,381,VFqpJjRySZvgi)
		else: cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,382,VFqpJjRySZvgi)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		AUgLXfQOR4Vm75Wq02JkbhEu = EeQqAGc0W5r6nlBbChwfZL[0][0]
		UZvaKyjnQYPxoHLfiq63h8m2BI = EeQqAGc0W5r6nlBbChwfZL[0][1]
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0][2]
		items = GGvHJKP9LUxEk10Fw.findall("href='(.*?)'.*?>(.*?)<",UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			if title=='' or title==UZvaKyjnQYPxoHLfiq63h8m2BI: continue
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,381,'','',type)
		ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.replace('/page/'+title+'/','/page/'+UZvaKyjnQYPxoHLfiq63h8m2BI+'/')
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'اخر صفحة '+UZvaKyjnQYPxoHLfiq63h8m2BI,ELbNB92cOh5dqtpVmi40kY,381,'','',type)
	return
def hWPvGlXZ5arzV7(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','MOVS4U-EPISODES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	NbE4qnzmPKGWtjYpoRL3HTS1A = GGvHJKP9LUxEk10Fw.findall('class="C rated".*?>(.*?)<',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if NbE4qnzmPKGWtjYpoRL3HTS1A and hNCJPTucIV7GOSR0HytZ6eQrqEUpw(cTJphS1nFz5EUgNWm86C,url,NbE4qnzmPKGWtjYpoRL3HTS1A,False):
		cd0aGwCPExbFU5pYNu8r('link',mmDwMlfoHtG5XT19VLIWqCR8i+'المسلسل للكبار والمبرمج منعه','',9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		dR2vHyAtl8pJN1 = GGvHJKP9LUxEk10Fw.findall('''class='item'><a href="(.*?)"''',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if dR2vHyAtl8pJN1:
			dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1[1]
			hWPvGlXZ5arzV7(dR2vHyAtl8pJN1)
			return
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('''class='episodios'(.*?)id="cast"''',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for VFqpJjRySZvgi,qUGxSK2VwsiBAdkDZnJ605vQeg,ELbNB92cOh5dqtpVmi40kY,name in items:
			title = qUGxSK2VwsiBAdkDZnJ605vQeg+' : '+name+' الحلقة'
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,382)
	return
def SUfe4unWoXBNFz90xqy(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','MOVS4U-PLAY-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	NbE4qnzmPKGWtjYpoRL3HTS1A = GGvHJKP9LUxEk10Fw.findall('class="C rated".*?>(.*?)<',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if NbE4qnzmPKGWtjYpoRL3HTS1A and hNCJPTucIV7GOSR0HytZ6eQrqEUpw(cTJphS1nFz5EUgNWm86C,url,NbE4qnzmPKGWtjYpoRL3HTS1A): return
	zzvBg3ShiamAZ = []
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0][0]
		items = GGvHJKP9LUxEk10Fw.findall("data-url='(.*?)'.*?class='server'>(.*?)<",UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named='+title+'__watch'
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="remodal"(.*?)class="remodal-close"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named='+title+'__download'
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(zzvBg3ShiamAZ,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	search = search.replace(' ','+')
	url = NBm2aWhPzoTpdYn+'/?s='+search
	xoiXMWjJC3pnQqurIGPkRSl8e(url,'search')
	return
# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'SHIAVOICE'
mmDwMlfoHtG5XT19VLIWqCR8i = '_SHV_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
headers = {'User-Agent':None}
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==310: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==311: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url)
	elif mode==312: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==313: zpXG3Ky6ou8ndWHkb4 = WToQk0lYgVHKbOc74jtpAPf9v3hu5(url)
	elif mode==314: zpXG3Ky6ou8ndWHkb4 = CymTbuXdDhL(text)
	elif mode==319: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',319,'','','_REMEMBERRESULTS_')
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(ZcdnQAJ3ltkoiPsyX5,'GET',NBm2aWhPzoTpdYn,'','','','','SHIAVOICE-MENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('id="menulinks"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = GGvHJKP9LUxEk10Fw.findall('<h5>(.*?)</h5>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL|GGvHJKP9LUxEk10Fw.IGNORECASE)
	for onj6XfdmELkTOlWH3xBhG1PC8F72 in range(len(items)):
		title = items[onj6XfdmELkTOlWH3xBhG1PC8F72].strip(' ')
		cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,NBm2aWhPzoTpdYn,314,'','',str(onj6XfdmELkTOlWH3xBhG1PC8F72+1))
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'مقاطع شهر',NBm2aWhPzoTpdYn,314,'','','0')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?<B>(.*?)</B>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/'+ELbNB92cOh5dqtpVmi40kY
		cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,311)
	return BBlXpmUyhFDwNtCVAHoE
def CymTbuXdDhL(onj6XfdmELkTOlWH3xBhG1PC8F72):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'GET',NBm2aWhPzoTpdYn,'','','','','SHIAVOICE-LATEST-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	if onj6XfdmELkTOlWH3xBhG1PC8F72=='0':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="tab-content"(.*?)</table>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,name,title in items:
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/'+ELbNB92cOh5dqtpVmi40kY
			title = title.strip(' ')
			name = name.strip(' ')
			title = title+' ('+name+')'
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,312)
	elif onj6XfdmELkTOlWH3xBhG1PC8F72 in ['1','2','3']:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('(<h5>.*?)<div class="col-lg',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		aWpP3BO9Lze8gwlsTIQtx7ZfS402 = int(onj6XfdmELkTOlWH3xBhG1PC8F72)-1
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[aWpP3BO9Lze8gwlsTIQtx7ZfS402]
		if onj6XfdmELkTOlWH3xBhG1PC8F72=='1': items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		else: items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title,name in items:
			VFqpJjRySZvgi = NBm2aWhPzoTpdYn+'/'+VFqpJjRySZvgi
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/'+ELbNB92cOh5dqtpVmi40kY
			title = title.strip(' ')
			name = name.strip(' ')
			title = title+' ('+name+')'
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,311,VFqpJjRySZvgi)
	elif onj6XfdmELkTOlWH3xBhG1PC8F72 in ['4','5','6']:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('(<h5>.*?)</table>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		onj6XfdmELkTOlWH3xBhG1PC8F72 = int(onj6XfdmELkTOlWH3xBhG1PC8F72)-4
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[onj6XfdmELkTOlWH3xBhG1PC8F72]
		items = GGvHJKP9LUxEk10Fw.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for VFqpJjRySZvgi,ELbNB92cOh5dqtpVmi40kY,yCcvQk8BMijebJlaHfhgKux,title,RuWUKQylsNvOH7SpiL59nYP3rA in items:
			VFqpJjRySZvgi = NBm2aWhPzoTpdYn+'/'+VFqpJjRySZvgi
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/'+ELbNB92cOh5dqtpVmi40kY
			title = title.strip(' ')
			yCcvQk8BMijebJlaHfhgKux = yCcvQk8BMijebJlaHfhgKux.strip(' ')
			RuWUKQylsNvOH7SpiL59nYP3rA = RuWUKQylsNvOH7SpiL59nYP3rA.strip(' ')
			if yCcvQk8BMijebJlaHfhgKux: name = yCcvQk8BMijebJlaHfhgKux
			else: name = RuWUKQylsNvOH7SpiL59nYP3rA
			title = title+' ('+name+')'
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,312,VFqpJjRySZvgi)
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','SHIAVOICE-TITLES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('ibox-heading"(.*?)class="float-right',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	if 'catsum-mobile' in UCEFMfKbgpd:
		items = GGvHJKP9LUxEk10Fw.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if items:
			for VFqpJjRySZvgi,ELbNB92cOh5dqtpVmi40kY,title,count in items:
				VFqpJjRySZvgi = NBm2aWhPzoTpdYn+'/'+VFqpJjRySZvgi
				ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/'+ELbNB92cOh5dqtpVmi40kY
				count = count.replace(' الصوتية: ',':')
				title = title.strip(' ')
				title = title+' ('+count+')'
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,311,VFqpJjRySZvgi)
	else:
		items = GGvHJKP9LUxEk10Fw.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title,qQG3ZSeWd1UBmpK,EDL3rwcivsR9W0pdTfygmOYUoVSb in items:
			if title=='' or qQG3ZSeWd1UBmpK=='': continue
			ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/'+ELbNB92cOh5dqtpVmi40kY
			title = title+' ('+EDL3rwcivsR9W0pdTfygmOYUoVSb+')'
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,312)
	if not items: hWPvGlXZ5arzV7(BBlXpmUyhFDwNtCVAHoE)
	return
def hWPvGlXZ5arzV7(BBlXpmUyhFDwNtCVAHoE):
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="ibox-content"(.*?)class="pagination',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title,name,count,EDL3rwcivsR9W0pdTfygmOYUoVSb in items:
		ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/'+ELbNB92cOh5dqtpVmi40kY
		title = title.strip(' ')
		name = name.strip(' ')
		title = title+' ('+name+')'
		cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,312,'',EDL3rwcivsR9W0pdTfygmOYUoVSb)
	return
def WToQk0lYgVHKbOc74jtpAPf9v3hu5(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','SHIAVOICE-SEARCH_ITEMS-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="ibox-content p-1"(.*?)class="ibox-content"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not EeQqAGc0W5r6nlBbChwfZL:
		xoiXMWjJC3pnQqurIGPkRSl8e(url)
		return
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?<strong>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/'+ELbNB92cOh5dqtpVmi40kY
		title = title.strip(' ')
		if '/play-' in ELbNB92cOh5dqtpVmi40kY: cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,312)
		else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,311)
	return
def SUfe4unWoXBNFz90xqy(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(xh9BXlAw0UoVsIZ4if3,'GET',url,'','','','','SHIAVOICE-PLAY-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall('<audio.*?src="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = GGvHJKP9LUxEk10Fw.findall('<video.*?src="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+ELbNB92cOh5dqtpVmi40kY[0]
	ICifW6hdKqxkAJ02XZgHysOwoV9Dc5(ELbNB92cOh5dqtpVmi40kY,cTJphS1nFz5EUgNWm86C,'video')
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	search = search.replace(' ','+')
	miPrE2kOa10Q6BU7cebF = ['&t=a','&t=c','&t=s']
	if showDialogs:
		SSChumt91H28fJMp5V7BY = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		z0jyetbQwKrIclL9vJW = D1DJtzviFZSrA('موقع صوت الشيعة - أختر البحث', SSChumt91H28fJMp5V7BY)
		if z0jyetbQwKrIclL9vJW == -1: return
	elif '_SHIAVOICE-PERSONS_' in tY3Dfrp6cMKFj: z0jyetbQwKrIclL9vJW = 0
	elif '_SHIAVOICE-ALBUMS_' in tY3Dfrp6cMKFj: z0jyetbQwKrIclL9vJW = 1
	elif '_SHIAVOICE-AUDIOS_' in tY3Dfrp6cMKFj: z0jyetbQwKrIclL9vJW = 2
	else: return
	type = miPrE2kOa10Q6BU7cebF[z0jyetbQwKrIclL9vJW]
	url = NBm2aWhPzoTpdYn+'/search.php?q='+search+type
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','SHIAVOICE-SEARCH-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="ibox-content"(.*?)class="ibox-content"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		if z0jyetbQwKrIclL9vJW in [0,1]:
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title,name in items:
				title = title.strip(' ')
				name = name.strip(' ')
				title = title+' ('+name+')'
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,313,VFqpJjRySZvgi)
		elif z0jyetbQwKrIclL9vJW==2:
			items = GGvHJKP9LUxEk10Fw.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,title,name in items:
				title = title.strip(' ')
				name = name.strip(' ')
				title = title+' ('+name+')'
				cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,312)
	return
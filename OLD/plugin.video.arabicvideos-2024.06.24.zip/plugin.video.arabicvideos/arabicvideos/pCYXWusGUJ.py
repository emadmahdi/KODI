# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'KATKOUTE'
mmDwMlfoHtG5XT19VLIWqCR8i = '_KTK_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
DDXTwbRBaj3e2rSsPQ = ['الصفحة الرئيسية','Sign in','الأقسام']
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==670: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==671: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,text)
	elif mode==672: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==673: zpXG3Ky6ou8ndWHkb4 = xKqSdbG6RNz8(url,text)
	elif mode==674: zpXG3Ky6ou8ndWHkb4 = i7pbAuodvX3(url)
	elif mode==679: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',NBm2aWhPzoTpdYn,'','','','','KATKOUTE-MENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',679,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"navslide-divider"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			if title in DDXTwbRBaj3e2rSsPQ: continue
			if title=='الأقسام': mode = 675
			else: mode = 674
			cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,mode)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = mgAQC3oRrjWLbHcE16dTMaJ7phsXV(NBm2aWhPzoTpdYn+'/watch/browse.html')
	for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
		cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,674,VFqpJjRySZvgi)
	return
def mgAQC3oRrjWLbHcE16dTMaJ7phsXV(url):
	VeIpTBA4KkFzJgRqGOE2Pb05Mx = P702PlzKg5o3mELCt(UkFh2OXjuTZEaexC,'list','KATKOUTE','CATEGORIES')
	if VeIpTBA4KkFzJgRqGOE2Pb05Mx: return VeIpTBA4KkFzJgRqGOE2Pb05Mx
	VeIpTBA4KkFzJgRqGOE2Pb05Mx = []
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(BXnrZSgERcxHvbVQ4,'GET',url,'','','','','KATKOUTE-CATEGORIES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"category-header"(.*?)<footer>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		VeIpTBA4KkFzJgRqGOE2Pb05Mx = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?src="(.*?)" alt="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if VeIpTBA4KkFzJgRqGOE2Pb05Mx: Tx5qRmdAsc0FP6BUSf8eQKy3(UkFh2OXjuTZEaexC,'KATKOUTE','CATEGORIES',VeIpTBA4KkFzJgRqGOE2Pb05Mx,ZcdnQAJ3ltkoiPsyX5)
	return VeIpTBA4KkFzJgRqGOE2Pb05Mx
def i7pbAuodvX3(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','KATKOUTE-SUBMENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	xxcVm7YBMXsfd = GGvHJKP9LUxEk10Fw.findall('"caret"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if xxcVm7YBMXsfd:
		UCEFMfKbgpd = xxcVm7YBMXsfd[0]
		UCEFMfKbgpd = UCEFMfKbgpd.replace('"presentation"','</ul>')
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if not EeQqAGc0W5r6nlBbChwfZL: EeQqAGc0W5r6nlBbChwfZL = [('',UCEFMfKbgpd)]
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] فرز أو فلتر أو ترتيب [/COLOR]','',9999)
		for nn5FjvR2JoN9,UCEFMfKbgpd in EeQqAGc0W5r6nlBbChwfZL:
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			if nn5FjvR2JoN9: nn5FjvR2JoN9 = nn5FjvR2JoN9+': '
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				title = nn5FjvR2JoN9+title
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,671)
	uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb = GGvHJKP9LUxEk10Fw.findall('"pm-category-subcats"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb:
		UCEFMfKbgpd = uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		if len(items)<30:
			cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,671)
	if not xxcVm7YBMXsfd and not uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb: xoiXMWjJC3pnQqurIGPkRSl8e(url)
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(url,hD6se2E307NcI=''):
	if hD6se2E307NcI=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'POST',url,data,headers,'','','KATKOUTE-TITLES-1st')
	else:
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','KATKOUTE-TITLES-2nd')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	UCEFMfKbgpd,items = '',[]
	aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(url,'url')
	if hD6se2E307NcI=='ajax-search':
		UCEFMfKbgpd = BBlXpmUyhFDwNtCVAHoE
		GzpIUylJrXRteaKPiNDLHuScmbgj = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in GzpIUylJrXRteaKPiNDLHuScmbgj: items.append(('',ELbNB92cOh5dqtpVmi40kY,title))
	elif hD6se2E307NcI=='featured':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"pm-video-watch-featured"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL: UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	elif hD6se2E307NcI=='new_episodes':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"row pm-ul-browse-videos(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL: UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	elif hD6se2E307NcI=='new_movies':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"row pm-ul-browse-videos(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if len(EeQqAGc0W5r6nlBbChwfZL)>1: UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[1]
	elif hD6se2E307NcI=='featured_series':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL: UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		GzpIUylJrXRteaKPiNDLHuScmbgj = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in GzpIUylJrXRteaKPiNDLHuScmbgj: items.append(('',ELbNB92cOh5dqtpVmi40kY,title))
	else:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('(data-echo=".*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL: UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	if UCEFMfKbgpd and not items: items = GGvHJKP9LUxEk10Fw.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	if not items: return
	IcJOGsq3Ff7EmkiLx = []
	Dq0X5cvgdjwh6LbnUkETFBR8 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','فلم']
	for VFqpJjRySZvgi,ELbNB92cOh5dqtpVmi40kY,title in items:
		qUGxSK2VwsiBAdkDZnJ605vQeg = GGvHJKP9LUxEk10Fw.findall('(.*?) (الحلقة|حلقة).\d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
		if any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in Dq0X5cvgdjwh6LbnUkETFBR8):
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,672,VFqpJjRySZvgi)
		elif hD6se2E307NcI=='new_episodes':
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,672,VFqpJjRySZvgi)
		elif qUGxSK2VwsiBAdkDZnJ605vQeg:
			title = '_MOD_' + qUGxSK2VwsiBAdkDZnJ605vQeg[0][0]
			if title not in IcJOGsq3Ff7EmkiLx:
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,673,VFqpJjRySZvgi)
				IcJOGsq3Ff7EmkiLx.append(title)
		elif '/movseries/' in ELbNB92cOh5dqtpVmi40kY:
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,671,VFqpJjRySZvgi)
		else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,673,VFqpJjRySZvgi)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"pagination(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			if ELbNB92cOh5dqtpVmi40kY=='#': continue
			if 'http' not in ELbNB92cOh5dqtpVmi40kY:
				dR2vHyAtl8pJN1 = url.rsplit('/',1)[0]
				ELbNB92cOh5dqtpVmi40kY = dR2vHyAtl8pJN1+'/'+ELbNB92cOh5dqtpVmi40kY.strip('/')
			title = DwNC3gEonizsB6a0v1F(title)
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,671,'','',hD6se2E307NcI)
	return
def xKqSdbG6RNz8(url,FzY68T7WDR1g4hEnNM5Sj9BkfXq):
	cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+'تشغيل الفيديو',url,672)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VeIpTBA4KkFzJgRqGOE2Pb05Mx = mgAQC3oRrjWLbHcE16dTMaJ7phsXV(NBm2aWhPzoTpdYn+'/watch/browse.html')
	XLTgRzkIKrWVY3,hh6uWjrPCTNMJ0nVkyzxf4Kabd7,Xy7cSYUTHlj8zt = zip(*VeIpTBA4KkFzJgRqGOE2Pb05Mx)
	O1VPRmTXAw6sCUuZeKbNk = []
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','KATKOUTE-EPISODES-2nd')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"row pm-video-heading"(.*?)id="player"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		gI487voLsArVqW6Ffp = GGvHJKP9LUxEk10Fw.findall('class="myButton".*?href="(.*?)".*?<b>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in gI487voLsArVqW6Ffp:
			if ELbNB92cOh5dqtpVmi40kY not in XLTgRzkIKrWVY3:
				BrVNsC72UYWES4A = (ELbNB92cOh5dqtpVmi40kY,title)
				O1VPRmTXAw6sCUuZeKbNk.append(BrVNsC72UYWES4A)
		if len(O1VPRmTXAw6sCUuZeKbNk)==1:
			ELbNB92cOh5dqtpVmi40kY,title = O1VPRmTXAw6sCUuZeKbNk[0]
			xoiXMWjJC3pnQqurIGPkRSl8e(ELbNB92cOh5dqtpVmi40kY,'new_episodes')
			return
		else:
			for ELbNB92cOh5dqtpVmi40kY,title in O1VPRmTXAw6sCUuZeKbNk:
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,671,'','','new_episodes')
	if not O1VPRmTXAw6sCUuZeKbNk: xoiXMWjJC3pnQqurIGPkRSl8e(url,'new_episodes')
	return
def SUfe4unWoXBNFz90xqy(url):
	uuIjMn1YTf687WlRcOmhq4G23H = []
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','KATKOUTE-PLAY-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('sources:(.*?)flashplayer',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		gI487voLsArVqW6Ffp = GGvHJKP9LUxEk10Fw.findall('file: "(.*?)".*?label: "(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,dDZQSEGRTo9g85x1C in gI487voLsArVqW6Ffp:
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named=__watch__'+dDZQSEGRTo9g85x1C
			uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY)
	gI487voLsArVqW6Ffp = GGvHJKP9LUxEk10Fw.findall('"embedded-video".*?src="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if not gI487voLsArVqW6Ffp: gI487voLsArVqW6Ffp = GGvHJKP9LUxEk10Fw.findall("file: '(.*?)'",BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if gI487voLsArVqW6Ffp:
		ELbNB92cOh5dqtpVmi40kY = gI487voLsArVqW6Ffp[0]
		if 'http' not in ELbNB92cOh5dqtpVmi40kY: ELbNB92cOh5dqtpVmi40kY = 'http:'+ELbNB92cOh5dqtpVmi40kY
		uuIjMn1YTf687WlRcOmhq4G23H.append(ELbNB92cOh5dqtpVmi40kY+'?named=__embed')
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(uuIjMn1YTf687WlRcOmhq4G23H,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	search = search.replace(' ','+')
	url = NBm2aWhPzoTpdYn+'/watch/search.php?keywords='+search
	xoiXMWjJC3pnQqurIGPkRSl8e(url,'search')
	return
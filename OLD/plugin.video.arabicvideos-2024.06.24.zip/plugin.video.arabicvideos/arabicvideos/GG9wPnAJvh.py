# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'SERIES4WATCH'
headers = { 'User-Agent' : '' }
mmDwMlfoHtG5XT19VLIWqCR8i = '_SFW_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==210: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==211: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url)
	elif mode==212: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==213: zpXG3Ky6ou8ndWHkb4 = hWPvGlXZ5arzV7(url)
	elif mode==214: zpXG3Ky6ou8ndWHkb4 = HksFrImc6gRud(url)
	elif mode==215: zpXG3Ky6ou8ndWHkb4 = YxAm7ShiIsW0L2fkT(url)
	elif mode==218: zpXG3Ky6ou8ndWHkb4 = Q6bXWBHfTyd()
	elif mode==219: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def Q6bXWBHfTyd():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	aHKzv76JCVnprbY8w('','','رسالة من المبرمج','الموقع تغير بالكامل',message)
	return
def T2AtWpmSuysJ3BzHVeFY():
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',219,'','','_REMEMBERRESULTS_')
	url = NBm2aWhPzoTpdYn+'/getpostsPin?type=one&data=pin&limit=25'
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'المميزة',url,211)
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,NBm2aWhPzoTpdYn,'',headers,'','SERIES4WATCH-MENU-1st')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('FiltersButtons(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('data-get="(.*?)".*?</i>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		url = NBm2aWhPzoTpdYn+'/getposts?type=one&data='+ELbNB92cOh5dqtpVmi40kY
		cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,url,211)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('navigation-menu(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('href="(http.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	DDXTwbRBaj3e2rSsPQ = ['مسلسلات انمي','الرئيسية']
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		title = title.strip(' ')
		if not any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in DDXTwbRBaj3e2rSsPQ):
			cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,211)
	return BBlXpmUyhFDwNtCVAHoE
def xoiXMWjJC3pnQqurIGPkRSl8e(url):
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,url,'',headers,'','SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: UCEFMfKbgpd = BBlXpmUyhFDwNtCVAHoE
	else:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('MediaGrid"(.*?)class="pagination"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL: UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		else: return
	items = GGvHJKP9LUxEk10Fw.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	IcJOGsq3Ff7EmkiLx = []
	O79xwZs3Cr42HinDSRfgMu = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for VFqpJjRySZvgi,ELbNB92cOh5dqtpVmi40kY,title in items:
		if '/series/' in ELbNB92cOh5dqtpVmi40kY: continue
		ELbNB92cOh5dqtpVmi40kY = GhPlajzTxY8(ELbNB92cOh5dqtpVmi40kY).strip('/')
		title = DwNC3gEonizsB6a0v1F(title)
		title = title.strip(' ')
		if '/film/' in ELbNB92cOh5dqtpVmi40kY or any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in O79xwZs3Cr42HinDSRfgMu):
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,212,VFqpJjRySZvgi)
		elif '/episode/' in ELbNB92cOh5dqtpVmi40kY and 'الحلقة' in title:
			qUGxSK2VwsiBAdkDZnJ605vQeg = GGvHJKP9LUxEk10Fw.findall('(.*?) الحلقة \d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
			if qUGxSK2VwsiBAdkDZnJ605vQeg:
				title = '_MOD_' + qUGxSK2VwsiBAdkDZnJ605vQeg[0]
				if title not in IcJOGsq3Ff7EmkiLx:
					cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,213,VFqpJjRySZvgi)
					IcJOGsq3Ff7EmkiLx.append(title)
		else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,213,VFqpJjRySZvgi)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="pagination(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			ELbNB92cOh5dqtpVmi40kY = DwNC3gEonizsB6a0v1F(ELbNB92cOh5dqtpVmi40kY)
			title = DwNC3gEonizsB6a0v1F(title)
			title = title.replace('الصفحة ','')
			if title!='': cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,211)
	return
def hWPvGlXZ5arzV7(url):
	jBgqdhKY5fb7ESyRnOiAGWZok9t2r,items,KQzlI18oVMbCAqvUN = -1,[],[]
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(Oa8xvPtmLZkBA43K0EzrdhXS,url,'',headers,'','SERIES4WATCH-EPISODES-1st')
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('ti-list-numbered(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		EHDeldN7L2k19JBUqhmsuSXiwV = ''.join(EeQqAGc0W5r6nlBbChwfZL)
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)"',EHDeldN7L2k19JBUqhmsuSXiwV,GGvHJKP9LUxEk10Fw.DOTALL)
	items.append(url)
	items = set(items)
	for ELbNB92cOh5dqtpVmi40kY in items:
		ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.strip('/')
		title = '_MOD_' + ELbNB92cOh5dqtpVmi40kY.split('/')[-1].replace('-',' ')
		vAxfDHyjwR6KM74IGEJl0dasY = GGvHJKP9LUxEk10Fw.findall('الحلقة-(\d+)',ELbNB92cOh5dqtpVmi40kY.split('/')[-1],GGvHJKP9LUxEk10Fw.DOTALL)
		if vAxfDHyjwR6KM74IGEJl0dasY: vAxfDHyjwR6KM74IGEJl0dasY = vAxfDHyjwR6KM74IGEJl0dasY[0]
		else: vAxfDHyjwR6KM74IGEJl0dasY = '0'
		KQzlI18oVMbCAqvUN.append([ELbNB92cOh5dqtpVmi40kY,title,vAxfDHyjwR6KM74IGEJl0dasY])
	items = sorted(KQzlI18oVMbCAqvUN, reverse=False, key=lambda key: int(key[2]))
	CYhD3frGVSq = str(items).count('/season/')
	jBgqdhKY5fb7ESyRnOiAGWZok9t2r = str(items).count('/episode/')
	if CYhD3frGVSq>1 and jBgqdhKY5fb7ESyRnOiAGWZok9t2r>0 and '/season/' not in url:
		for ELbNB92cOh5dqtpVmi40kY,title,vAxfDHyjwR6KM74IGEJl0dasY in items:
			if '/season/' in ELbNB92cOh5dqtpVmi40kY: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,213)
	else:
		for ELbNB92cOh5dqtpVmi40kY,title,vAxfDHyjwR6KM74IGEJl0dasY in items:
			if '/season/' not in ELbNB92cOh5dqtpVmi40kY: cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,212)
	return
def SUfe4unWoXBNFz90xqy(url):
	zzvBg3ShiamAZ = []
	Z0HoXM261lLgxBzjUK = url.split('/')
	BBlXpmUyhFDwNtCVAHoE = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,url,'',headers,'','SERIES4WATCH-PLAY-1st')
	if '/watch/' in BBlXpmUyhFDwNtCVAHoE:
		dR2vHyAtl8pJN1 = url.replace(Z0HoXM261lLgxBzjUK[3],'watch')
		X3in5vNhqwWEG2TafmVCrFbSYDxjoK = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,dR2vHyAtl8pJN1,'',headers,'','SERIES4WATCH-PLAY-2nd')
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="servers-list(.*?)</div>',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
			items = GGvHJKP9LUxEk10Fw.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			if items:
				id = GGvHJKP9LUxEk10Fw.findall('post_id=(.*?)"',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
				if id:
					jayps2bqRW6CEVl9IY8LdB5e = id[0]
					for ELbNB92cOh5dqtpVmi40kY,title in items:
						ELbNB92cOh5dqtpVmi40kY = NBm2aWhPzoTpdYn+'/?postid='+jayps2bqRW6CEVl9IY8LdB5e+'&serverid='+ELbNB92cOh5dqtpVmi40kY+'?named='+title+'__watch'
						zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
			else:
				items = GGvHJKP9LUxEk10Fw.findall('data-embedd=".*?(http.*?)("|&quot;)',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
				for ELbNB92cOh5dqtpVmi40kY,X4XyOPCEu65AMYebxwaVW in items:
					zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	if '/download/' in BBlXpmUyhFDwNtCVAHoE:
		dR2vHyAtl8pJN1 = url.replace(Z0HoXM261lLgxBzjUK[3],'download')
		X3in5vNhqwWEG2TafmVCrFbSYDxjoK = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,dR2vHyAtl8pJN1,'',headers,'','SERIES4WATCH-PLAY-3rd')
		id = GGvHJKP9LUxEk10Fw.findall('postId:"(.*?)"',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
		if id:
			jayps2bqRW6CEVl9IY8LdB5e = id[0]
			BBYvCiQGe8RdpyAagfS72mZclxb5 = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' }
			dR2vHyAtl8pJN1 = NBm2aWhPzoTpdYn + '/ajaxCenter?_action=getdownloadlinks&postId='+jayps2bqRW6CEVl9IY8LdB5e
			X3in5vNhqwWEG2TafmVCrFbSYDxjoK = KkRZyvC312V5(ZcdnQAJ3ltkoiPsyX5,dR2vHyAtl8pJN1,'',BBYvCiQGe8RdpyAagfS72mZclxb5,'','SERIES4WATCH-PLAY-4th')
			EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('<h3.*?(\d+)(.*?)</div>',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
			if EeQqAGc0W5r6nlBbChwfZL:
				for uLB6kAt7dfNarSJWUCy,UCEFMfKbgpd in EeQqAGc0W5r6nlBbChwfZL:
					items = GGvHJKP9LUxEk10Fw.findall('<td>(.*?)<.*?href="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
					for name,ELbNB92cOh5dqtpVmi40kY in items:
						zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY+'?named='+name+'__download'+'____'+uLB6kAt7dfNarSJWUCy)
			else:
				EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('<h6(.*?)</table>',X3in5vNhqwWEG2TafmVCrFbSYDxjoK,GGvHJKP9LUxEk10Fw.DOTALL)
				if not EeQqAGc0W5r6nlBbChwfZL: EeQqAGc0W5r6nlBbChwfZL = [X3in5vNhqwWEG2TafmVCrFbSYDxjoK]
				for UCEFMfKbgpd in EeQqAGc0W5r6nlBbChwfZL:
					name = ''
					items = GGvHJKP9LUxEk10Fw.findall('href="(http.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
					for ELbNB92cOh5dqtpVmi40kY in items:
						C83UXWf15zdwLA0 = '&&' + ELbNB92cOh5dqtpVmi40kY.split('/')[2].lower() + '&&'
						C83UXWf15zdwLA0 = C83UXWf15zdwLA0.replace('.com&&','').replace('.co&&','')
						C83UXWf15zdwLA0 = C83UXWf15zdwLA0.replace('.net&&','').replace('.org&&','')
						C83UXWf15zdwLA0 = C83UXWf15zdwLA0.replace('.live&&','').replace('.online&&','')
						C83UXWf15zdwLA0 = C83UXWf15zdwLA0.replace('&&hd.','').replace('&&www.','')
						C83UXWf15zdwLA0 = C83UXWf15zdwLA0.replace('&&','')
						ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY + '?named=' + name + C83UXWf15zdwLA0 + '__download'
						zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(zzvBg3ShiamAZ,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	search = search.replace(' ','+')
	url = NBm2aWhPzoTpdYn + '/search?s='+search
	xoiXMWjJC3pnQqurIGPkRSl8e(url)
	return
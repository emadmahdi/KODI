# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'CIMA4U'
headers = {'User-Agent':''}
mmDwMlfoHtG5XT19VLIWqCR8i = '_C4U_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
DDXTwbRBaj3e2rSsPQ = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==420: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==421: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,text)
	elif mode==422: zpXG3Ky6ou8ndWHkb4 = MniZg2RhcpK01tCaTQN5rIOjdUWose(url)
	elif mode==423: zpXG3Ky6ou8ndWHkb4 = hWPvGlXZ5arzV7(url)
	elif mode==424: zpXG3Ky6ou8ndWHkb4 = hWJg9P6lEYT5aGDizcb(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: zpXG3Ky6ou8ndWHkb4 = hWJg9P6lEYT5aGDizcb(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==427: zpXG3Ky6ou8ndWHkb4 = cYfskxphSQ(url)
	elif mode==429: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',NBm2aWhPzoTpdYn,'','','','','CIMA4U-MENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	aPNBvIyexc053gAsSw1QoRMUYfb = GGvHJKP9LUxEk10Fw.findall('href="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	aPNBvIyexc053gAsSw1QoRMUYfb = aPNBvIyexc053gAsSw1QoRMUYfb[0].strip('/')
	aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(aPNBvIyexc053gAsSw1QoRMUYfb,'url')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',429,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فلتر محدد',aPNBvIyexc053gAsSw1QoRMUYfb,425)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'فلتر كامل',aPNBvIyexc053gAsSw1QoRMUYfb,424)
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'الرئيسية',aPNBvIyexc053gAsSw1QoRMUYfb,421)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('NavigationMenu(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('href="*(.*?)"*>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for ELbNB92cOh5dqtpVmi40kY,title in items:
		if title in DDXTwbRBaj3e2rSsPQ: continue
		if '/actors' in ELbNB92cOh5dqtpVmi40kY: title = 'أفلام النجوم'
		elif '/netflix' in ELbNB92cOh5dqtpVmi40kY: title = 'أفلام ومسلسلات نيتفلكس'
		cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,421)
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'قائمة تفصيلية',aPNBvIyexc053gAsSw1QoRMUYfb,427)
	return
def cYfskxphSQ(website=''):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',NBm2aWhPzoTpdYn,'','','','','CIMA4U-MENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('FilteringTitle(.*?)PageTitle',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	items = GGvHJKP9LUxEk10Fw.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	for BBskpK6cGZJ,id,ELbNB92cOh5dqtpVmi40kY,title in items:
		if title in DDXTwbRBaj3e2rSsPQ: continue
		if 'netflix-movies' in ELbNB92cOh5dqtpVmi40kY: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in ELbNB92cOh5dqtpVmi40kY: title = 'مسلسلات نيتفلكس'
		cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,421,'','',BBskpK6cGZJ+'|'+id)
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(url,nKuYjzcZEXky6Va5UdoJfH1xqstL=''):
	if '/HomepageLoader/' in url: url = url.strip('/')+'/mpaa/family/'
	items = []
	aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(url,'url')
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'',headers,'','','CIMA4U-TITLES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	if not nKuYjzcZEXky6Va5UdoJfH1xqstL or '|' in nKuYjzcZEXky6Va5UdoJfH1xqstL:
		if '|' not in nKuYjzcZEXky6Va5UdoJfH1xqstL: cM0CUWGRleK3yA5QuJP9Eti = ''
		else: cM0CUWGRleK3yA5QuJP9Eti = '/archive/'+nKuYjzcZEXky6Va5UdoJfH1xqstL
		ht2xa9F7Odi1CjMIEGqu3 = False
		if 'PinSlider' in BBlXpmUyhFDwNtCVAHoE:
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'المميزة',url,421,'','','featured')
			ht2xa9F7Odi1CjMIEGqu3 = True
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('PageTitle(.*?)PageContent',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			jCxVUBZwAdOtIHM81rTJYiX3 = EeQqAGc0W5r6nlBbChwfZL[0]
			GzpIUylJrXRteaKPiNDLHuScmbgj = GGvHJKP9LUxEk10Fw.findall('data-tab="(.*?)".*?<span>(.*?)<',jCxVUBZwAdOtIHM81rTJYiX3,GGvHJKP9LUxEk10Fw.DOTALL)
			for afRW5XdvgFPLBpMNjVeIknSu9JOsq,qPmCp1Q4gRekdAH in GzpIUylJrXRteaKPiNDLHuScmbgj:
				E2EhMuOLdF08Pz75jDKS14cfYNxy = aPNBvIyexc053gAsSw1QoRMUYfb+'/ajaxcenter/action/HomepageLoader/tab/'+afRW5XdvgFPLBpMNjVeIknSu9JOsq+cM0CUWGRleK3yA5QuJP9Eti+'/'
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+qPmCp1Q4gRekdAH,E2EhMuOLdF08Pz75jDKS14cfYNxy,421)
				ht2xa9F7Odi1CjMIEGqu3 = True
		if ht2xa9F7Odi1CjMIEGqu3: cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	if nKuYjzcZEXky6Va5UdoJfH1xqstL=='featured':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('PinSlider(.*?)MultiFilter',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if not EeQqAGc0W5r6nlBbChwfZL: EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('PinSlider(.*?)PageTitle',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL: UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		else: UCEFMfKbgpd = ''
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		UCEFMfKbgpd = BBlXpmUyhFDwNtCVAHoE
	elif '/filter/' in url:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('PageContent(.*?)class="*pagination"*',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	elif '/actors' in url:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('PageContent(.*?)class="*pagination"*',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	else:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('Cima4uBlocks(.*?)</li></ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL: UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		else: UCEFMfKbgpd = ''
	if not items: items = GGvHJKP9LUxEk10Fw.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	if not items: items = GGvHJKP9LUxEk10Fw.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	IcJOGsq3Ff7EmkiLx = []
	for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
		if not title: continue
		if '?news=' in ELbNB92cOh5dqtpVmi40kY: continue
		title = title.replace('مشاهدة ','')
		title = DwNC3gEonizsB6a0v1F(title)
		qUGxSK2VwsiBAdkDZnJ605vQeg = GGvHJKP9LUxEk10Fw.findall('(.*?) حلقة \d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
		if qUGxSK2VwsiBAdkDZnJ605vQeg and 'حلقة' in title:
			title = '_MOD_' + qUGxSK2VwsiBAdkDZnJ605vQeg[0]
			if title not in IcJOGsq3Ff7EmkiLx:
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,422,VFqpJjRySZvgi)
				IcJOGsq3Ff7EmkiLx.append(title)
		elif '/actor/' in ELbNB92cOh5dqtpVmi40kY: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,421,VFqpJjRySZvgi)
		else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,422,VFqpJjRySZvgi)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('pagination(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL and nKuYjzcZEXky6Va5UdoJfH1xqstL!='featured':
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			title = DwNC3gEonizsB6a0v1F(title)
			title = title.replace('الصفحة ','')
			if title!='': cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,421)
	ezAfMX0JKQPc2G = GGvHJKP9LUxEk10Fw.findall('</li><a href="(.*?)".*?>(.*?)<',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if ezAfMX0JKQPc2G:
		ELbNB92cOh5dqtpVmi40kY,title = ezAfMX0JKQPc2G[0]
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,421)
	return
def MniZg2RhcpK01tCaTQN5rIOjdUWose(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','CIMA4U-SEASONS-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('class="WatchNow".*?href="(.*?)"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		url = EeQqAGc0W5r6nlBbChwfZL[0]
		WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','CIMA4U-SEASONS-2nd')
		BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('SeasonsSections(.*?)</div></div></div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if '/tag/' in url or '/actor' in url:
		xoiXMWjJC3pnQqurIGPkRSl8e(url)
	elif EeQqAGc0W5r6nlBbChwfZL:
		VFqpJjRySZvgi = cEZpW924rqNYm5.getInfoLabel('ListItem.Thumb')
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall("href='(.*?)'>(.*?)<",UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		AgG9Sncrs1jJ3Ly = ['مسلسل','موسم','برنامج','حلقة']
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			if any(hieW1zRUG5w9AykJjv0X in title for hieW1zRUG5w9AykJjv0X in AgG9Sncrs1jJ3Ly):
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,423,VFqpJjRySZvgi)
			else: cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,426,VFqpJjRySZvgi)
	else: hWPvGlXZ5arzV7(url)
	return
def hWPvGlXZ5arzV7(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','CIMA4U-EPISODES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	VFqpJjRySZvgi = GGvHJKP9LUxEk10Fw.findall('"background-image:url\((.*?)\)',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if VFqpJjRySZvgi: VFqpJjRySZvgi = VFqpJjRySZvgi[0]
	else: VFqpJjRySZvgi = ''
	egvf3lubILM5pSoCqrN1K0 = GGvHJKP9LUxEk10Fw.findall('EpisodesSection(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if egvf3lubILM5pSoCqrN1K0:
		UCEFMfKbgpd = egvf3lubILM5pSoCqrN1K0[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title,qUGxSK2VwsiBAdkDZnJ605vQeg in items:
			title = title+' '+qUGxSK2VwsiBAdkDZnJ605vQeg
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,426,VFqpJjRySZvgi)
	else: cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+'رابط التشغيل',url,426,VFqpJjRySZvgi)
	return
def SUfe4unWoXBNFz90xqy(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'',headers,'','','CIMA4U-PLAY-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	okjSqe5yt18CYZnQXaAlhMOrb0T = WbTGMHnDysdYZ2lFA.url
	if HHosl5fRdhtEDAYyP: okjSqe5yt18CYZnQXaAlhMOrb0T = okjSqe5yt18CYZnQXaAlhMOrb0T.encode('utf8')
	aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(okjSqe5yt18CYZnQXaAlhMOrb0T,'url')
	zzvBg3ShiamAZ = []
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('WatchSection(.*?)</div></div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('data-link="(.*?)".*? />(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for r9yaxqiB7EhQMfHjWoZTUn3LdvG,title in items:
			title = title.strip(' ')
			if 'myvid' in title.lower(): title = 'خاص '+title
			ELbNB92cOh5dqtpVmi40kY = aPNBvIyexc053gAsSw1QoRMUYfb+'/structure/server.php?id='+r9yaxqiB7EhQMfHjWoZTUn3LdvG+'?named='+title+'__watch'
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.replace('\r','')
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('DownloadServers(.*?)</div></div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*? />(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			title = title.strip(' ')
			if 'myvid' in title.lower(): qPmCp1Q4gRekdAH = '__خاص'
			else: qPmCp1Q4gRekdAH = ''
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named='+title+'__download'+qPmCp1Q4gRekdAH
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY.replace('\r','')
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(zzvBg3ShiamAZ,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	search = search.replace(' ','+')
	url = NBm2aWhPzoTpdYn+'/Search?q='+search
	xoiXMWjJC3pnQqurIGPkRSl8e(url,'search')
	return
def ccBw4LkjaXAv8xDlV7UzFbrOfGqi5(url):
	if 'smartemadfilter' not in url: url = RfKuIXwPAiWtmyF(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','CIMA4U-GET_FILTERS_BLOCKS-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('MultiFilter(.*?)PageTitle',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	nQKyI93hUT2ZGl6zimxDWe04ckj = GGvHJKP9LUxEk10Fw.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	return nQKyI93hUT2ZGl6zimxDWe04ckj
def CEK49jfZAnysJ8wIiQDpkqaOPtrzbX(UCEFMfKbgpd):
	items = GGvHJKP9LUxEk10Fw.findall('data-id="(.*?)".*?</div>(.*?)</a>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	return items
def CRdaLbyr9tTEuIX(url):
	Z5sNMdDa6h7j0 = url.split('/smartemadfilter?')[0]
	o6ZrjEvyT8th = RfKuIXwPAiWtmyF(url,'url')
	url = url.replace(Z5sNMdDa6h7j0,o6ZrjEvyT8th)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=','/').replace('&','/')
	url = url+'/'
	return url
A2kRm7N8gIn1MTrWZF0Yp5e = ['category','types','release-year']
ppwVAoqiOnjJZad = ['Quality','release-year','types','category']
def hWJg9P6lEYT5aGDizcb(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': zTi1IvPRBr,CcMQl4P9H8SkouF7srzBYdDKUNA = '',''
	else: zTi1IvPRBr,CcMQl4P9H8SkouF7srzBYdDKUNA = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global A2kRm7N8gIn1MTrWZF0Yp5e
			A2kRm7N8gIn1MTrWZF0Yp5e = A2kRm7N8gIn1MTrWZF0Yp5e[1:]
		if A2kRm7N8gIn1MTrWZF0Yp5e[0]+'=' not in zTi1IvPRBr: BBskpK6cGZJ = A2kRm7N8gIn1MTrWZF0Yp5e[0]
		for umP72LtwzUTWHFAlJVyheEp5 in range(len(A2kRm7N8gIn1MTrWZF0Yp5e[0:-1])):
			if A2kRm7N8gIn1MTrWZF0Yp5e[umP72LtwzUTWHFAlJVyheEp5]+'=' in zTi1IvPRBr: BBskpK6cGZJ = A2kRm7N8gIn1MTrWZF0Yp5e[umP72LtwzUTWHFAlJVyheEp5+1]
		i2i6oT5O34GLAgyPs8DdIfV = zTi1IvPRBr+'&'+BBskpK6cGZJ+'=0'
		WtVSCYeOJDGQf5sq8KZxkzyXwvBF = CcMQl4P9H8SkouF7srzBYdDKUNA+'&'+BBskpK6cGZJ+'=0'
		sDnjCtlaGyxmr9fqK = i2i6oT5O34GLAgyPs8DdIfV.strip('&')+'___'+WtVSCYeOJDGQf5sq8KZxkzyXwvBF.strip('&')
		BnNGcaxDl0pPVdmq3j1kQu6HJEs4 = fx0tQnZhGieDkA(CcMQl4P9H8SkouF7srzBYdDKUNA,'modified_filters')
		dR2vHyAtl8pJN1 = url+'/smartemadfilter?'+BnNGcaxDl0pPVdmq3j1kQu6HJEs4
	elif type=='ALL_ITEMS_FILTER':
		QHWZwB3stnOp5SghLfl2zir6YCI = fx0tQnZhGieDkA(zTi1IvPRBr,'modified_values')
		QHWZwB3stnOp5SghLfl2zir6YCI = GhPlajzTxY8(QHWZwB3stnOp5SghLfl2zir6YCI)
		if CcMQl4P9H8SkouF7srzBYdDKUNA!='': CcMQl4P9H8SkouF7srzBYdDKUNA = fx0tQnZhGieDkA(CcMQl4P9H8SkouF7srzBYdDKUNA,'modified_filters')
		if CcMQl4P9H8SkouF7srzBYdDKUNA=='': dR2vHyAtl8pJN1 = url
		else: dR2vHyAtl8pJN1 = url+'/smartemadfilter?'+CcMQl4P9H8SkouF7srzBYdDKUNA
		dR2vHyAtl8pJN1 = CRdaLbyr9tTEuIX(dR2vHyAtl8pJN1)
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'أظهار قائمة الفيديو التي تم اختيارها ',dR2vHyAtl8pJN1,421,'','','filter')
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+' [[   '+QHWZwB3stnOp5SghLfl2zir6YCI+'   ]]',dR2vHyAtl8pJN1,421,'','','filter')
		cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nQKyI93hUT2ZGl6zimxDWe04ckj = ccBw4LkjaXAv8xDlV7UzFbrOfGqi5(url)
	dict = {}
	for name,UCEFMfKbgpd,mmRDx1Zhfjq4oFdsNey2EwCBlUOQv in nQKyI93hUT2ZGl6zimxDWe04ckj:
		if '/category/' in url and mmRDx1Zhfjq4oFdsNey2EwCBlUOQv=='category': continue
		name = name.replace('--','')
		items = CEK49jfZAnysJ8wIiQDpkqaOPtrzbX(UCEFMfKbgpd)
		if '=' not in dR2vHyAtl8pJN1: dR2vHyAtl8pJN1 = url
		if type=='SPECIFIED_FILTER':
			if BBskpK6cGZJ!=mmRDx1Zhfjq4oFdsNey2EwCBlUOQv: continue
			elif len(items)<2:
				if mmRDx1Zhfjq4oFdsNey2EwCBlUOQv==A2kRm7N8gIn1MTrWZF0Yp5e[-1]:
					url = CRdaLbyr9tTEuIX(url)
					xoiXMWjJC3pnQqurIGPkRSl8e(url)
				else: hWJg9P6lEYT5aGDizcb(dR2vHyAtl8pJN1,'SPECIFIED_FILTER___'+sDnjCtlaGyxmr9fqK)
				return
			else:
				dR2vHyAtl8pJN1 = CRdaLbyr9tTEuIX(dR2vHyAtl8pJN1)
				if mmRDx1Zhfjq4oFdsNey2EwCBlUOQv==A2kRm7N8gIn1MTrWZF0Yp5e[-1]: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع',dR2vHyAtl8pJN1,421,'','','filter')
				else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع',dR2vHyAtl8pJN1,425,'','',sDnjCtlaGyxmr9fqK)
		elif type=='ALL_ITEMS_FILTER':
			i2i6oT5O34GLAgyPs8DdIfV = zTi1IvPRBr+'&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'=0'
			WtVSCYeOJDGQf5sq8KZxkzyXwvBF = CcMQl4P9H8SkouF7srzBYdDKUNA+'&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'=0'
			sDnjCtlaGyxmr9fqK = i2i6oT5O34GLAgyPs8DdIfV+'___'+WtVSCYeOJDGQf5sq8KZxkzyXwvBF
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'الجميع :'+name,dR2vHyAtl8pJN1,424,'','',sDnjCtlaGyxmr9fqK)
		dict[mmRDx1Zhfjq4oFdsNey2EwCBlUOQv] = {}
		for hieW1zRUG5w9AykJjv0X,RHb9zAjcuTIoyZ0aDgS1pQYmUs8 in items:
			if hieW1zRUG5w9AykJjv0X=='196533': RHb9zAjcuTIoyZ0aDgS1pQYmUs8 = 'أفلام نيتفلكس'
			elif hieW1zRUG5w9AykJjv0X=='196531': RHb9zAjcuTIoyZ0aDgS1pQYmUs8 = 'مسلسلات نيتفلكس'
			if RHb9zAjcuTIoyZ0aDgS1pQYmUs8 in DDXTwbRBaj3e2rSsPQ: continue
			dict[mmRDx1Zhfjq4oFdsNey2EwCBlUOQv][hieW1zRUG5w9AykJjv0X] = RHb9zAjcuTIoyZ0aDgS1pQYmUs8
			i2i6oT5O34GLAgyPs8DdIfV = zTi1IvPRBr+'&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'='+RHb9zAjcuTIoyZ0aDgS1pQYmUs8
			WtVSCYeOJDGQf5sq8KZxkzyXwvBF = CcMQl4P9H8SkouF7srzBYdDKUNA+'&'+mmRDx1Zhfjq4oFdsNey2EwCBlUOQv+'='+hieW1zRUG5w9AykJjv0X
			KPcDQTE3e8duMHO6Lbgo1n = i2i6oT5O34GLAgyPs8DdIfV+'___'+WtVSCYeOJDGQf5sq8KZxkzyXwvBF
			title = RHb9zAjcuTIoyZ0aDgS1pQYmUs8+' :'#+dict[mmRDx1Zhfjq4oFdsNey2EwCBlUOQv]['0']
			title = RHb9zAjcuTIoyZ0aDgS1pQYmUs8+' :'+name
			if type=='ALL_ITEMS_FILTER': cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,424,'','',KPcDQTE3e8duMHO6Lbgo1n)
			elif type=='SPECIFIED_FILTER' and A2kRm7N8gIn1MTrWZF0Yp5e[-2]+'=' in zTi1IvPRBr:
				BnNGcaxDl0pPVdmq3j1kQu6HJEs4 = fx0tQnZhGieDkA(WtVSCYeOJDGQf5sq8KZxkzyXwvBF,'modified_filters')
				XwyU6PQgprMI0 = url+'/smartemadfilter?'+BnNGcaxDl0pPVdmq3j1kQu6HJEs4
				XwyU6PQgprMI0 = CRdaLbyr9tTEuIX(XwyU6PQgprMI0)
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,XwyU6PQgprMI0,421,'','','filter')
			else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,425,'','',KPcDQTE3e8duMHO6Lbgo1n)
	return
def fx0tQnZhGieDkA(FZj067Q2PlC8EsG9c5yiWpzNRq,mode):
	FZj067Q2PlC8EsG9c5yiWpzNRq = FZj067Q2PlC8EsG9c5yiWpzNRq.replace('=&','=0&')
	FZj067Q2PlC8EsG9c5yiWpzNRq = FZj067Q2PlC8EsG9c5yiWpzNRq.strip('&')
	HG4gSjopqQwsPeivrcmn = {}
	if '=' in FZj067Q2PlC8EsG9c5yiWpzNRq:
		items = FZj067Q2PlC8EsG9c5yiWpzNRq.split('&')
		for BrVNsC72UYWES4A in items:
			RRSq2Qx0MfkFHLt,hieW1zRUG5w9AykJjv0X = BrVNsC72UYWES4A.split('=')
			HG4gSjopqQwsPeivrcmn[RRSq2Qx0MfkFHLt] = hieW1zRUG5w9AykJjv0X
	BbgO8pxWfVA41KGzed = ''
	for key in ppwVAoqiOnjJZad:
		if key in list(HG4gSjopqQwsPeivrcmn.keys()): hieW1zRUG5w9AykJjv0X = HG4gSjopqQwsPeivrcmn[key]
		else: hieW1zRUG5w9AykJjv0X = '0'
		if '%' not in hieW1zRUG5w9AykJjv0X: hieW1zRUG5w9AykJjv0X = mGfdCk4Hyclg9RjD(hieW1zRUG5w9AykJjv0X)
		if mode=='modified_values' and hieW1zRUG5w9AykJjv0X!='0': BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed+' + '+hieW1zRUG5w9AykJjv0X
		elif mode=='modified_filters' and hieW1zRUG5w9AykJjv0X!='0': BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed+'&'+key+'='+hieW1zRUG5w9AykJjv0X
		elif mode=='all': BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed+'&'+key+'='+hieW1zRUG5w9AykJjv0X
	BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed.strip(' + ')
	BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed.strip('&')
	BbgO8pxWfVA41KGzed = BbgO8pxWfVA41KGzed.replace('=0','=')
	return BbgO8pxWfVA41KGzed
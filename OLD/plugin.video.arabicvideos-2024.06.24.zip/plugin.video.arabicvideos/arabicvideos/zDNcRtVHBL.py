# -*- coding: utf-8 -*-
from ccTpfuSVZY import *
cTJphS1nFz5EUgNWm86C = 'LODYNET'
mmDwMlfoHtG5XT19VLIWqCR8i = '_LDN_'
NBm2aWhPzoTpdYn = oSVpce1UQYrDqhuM6PT[cTJphS1nFz5EUgNWm86C][0]
DDXTwbRBaj3e2rSsPQ = ['الرئيسية','استفسارتكم و الطلبات']
def p6G19bDsiCPfK4NwjZ3xrRHLqzV(mode,url,text):
	if   mode==450: zpXG3Ky6ou8ndWHkb4 = T2AtWpmSuysJ3BzHVeFY()
	elif mode==451: zpXG3Ky6ou8ndWHkb4 = xoiXMWjJC3pnQqurIGPkRSl8e(url,text)
	elif mode==452: zpXG3Ky6ou8ndWHkb4 = SUfe4unWoXBNFz90xqy(url)
	elif mode==453: zpXG3Ky6ou8ndWHkb4 = MniZg2RhcpK01tCaTQN5rIOjdUWose(url)
	elif mode==454: zpXG3Ky6ou8ndWHkb4 = hWPvGlXZ5arzV7(url)
	elif mode==459: zpXG3Ky6ou8ndWHkb4 = szwTAdaBt4FiXO(text)
	else: zpXG3Ky6ou8ndWHkb4 = False
	return zpXG3Ky6ou8ndWHkb4
def T2AtWpmSuysJ3BzHVeFY():
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',NBm2aWhPzoTpdYn,'','','','','LODYNET-MENU-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(NBm2aWhPzoTpdYn,'url')
	cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'بحث في الموقع','',459,'','','_REMEMBERRESULTS_')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'مثبتات لودي نت',aPNBvIyexc053gAsSw1QoRMUYfb,451,'','','featured')
	cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+'المضاف حديثا',aPNBvIyexc053gAsSw1QoRMUYfb,451,'','','latest')
	cd0aGwCPExbFU5pYNu8r('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"MainMenu"(.*?)"SiteSlider"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			if ELbNB92cOh5dqtpVmi40kY=='#': continue
			if title in DDXTwbRBaj3e2rSsPQ: continue
			cd0aGwCPExbFU5pYNu8r('folder',cTJphS1nFz5EUgNWm86C+'_SCRIPT_'+mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,451)
	return
def xoiXMWjJC3pnQqurIGPkRSl8e(url,nKuYjzcZEXky6Va5UdoJfH1xqstL=''):
	items = []
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','LODYNET-TITLES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	if nKuYjzcZEXky6Va5UdoJfH1xqstL=='featured':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"SiteSlider"(.*?)"waves"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	elif nKuYjzcZEXky6Va5UdoJfH1xqstL=='latest':
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"RecentPosts"(.*?)"pagination"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	elif '"ActorsList"' in BBlXpmUyhFDwNtCVAHoE:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"ActorsList"(.*?)"text/javascript"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)"(.*?)"ActorName">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	elif nKuYjzcZEXky6Va5UdoJfH1xqstL in ['0','1','2']:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"Section"(.*?)</li></ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[int(nKuYjzcZEXky6Va5UdoJfH1xqstL)]
	else:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"BlocksArea"(.*?)"text/javascript"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
	if not items: items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?src="(.*?)".*?<h2>(.*?)</h2>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
	IcJOGsq3Ff7EmkiLx = []
	Dq0X5cvgdjwh6LbnUkETFBR8 = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
		if '"ActorsList"' in BBlXpmUyhFDwNtCVAHoE and 'src=' in VFqpJjRySZvgi:
			VFqpJjRySZvgi = GGvHJKP9LUxEk10Fw.findall('src="(.*?)"',VFqpJjRySZvgi,GGvHJKP9LUxEk10Fw.DOTALL)
			VFqpJjRySZvgi = VFqpJjRySZvgi[0]
		ELbNB92cOh5dqtpVmi40kY = GhPlajzTxY8(ELbNB92cOh5dqtpVmi40kY).strip('/')
		qUGxSK2VwsiBAdkDZnJ605vQeg = GGvHJKP9LUxEk10Fw.findall('(.*?) حلقة \d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
		if not qUGxSK2VwsiBAdkDZnJ605vQeg: qUGxSK2VwsiBAdkDZnJ605vQeg = GGvHJKP9LUxEk10Fw.findall('(.*?) الحلقة \d+',title,GGvHJKP9LUxEk10Fw.DOTALL)
		if set(title.split()) & set(Dq0X5cvgdjwh6LbnUkETFBR8) and 'مسلسل' not in title:
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,452,VFqpJjRySZvgi)
		elif qUGxSK2VwsiBAdkDZnJ605vQeg and 'حلقة' in title:
			title = '_MOD_' + qUGxSK2VwsiBAdkDZnJ605vQeg[0]
			if title not in IcJOGsq3Ff7EmkiLx:
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,453,VFqpJjRySZvgi)
				IcJOGsq3Ff7EmkiLx.append(title)
		else: cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,453,VFqpJjRySZvgi)
	if nKuYjzcZEXky6Va5UdoJfH1xqstL in ['','latest']:
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"pagination"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				title = DwNC3gEonizsB6a0v1F(title)
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,451)
	return
def MniZg2RhcpK01tCaTQN5rIOjdUWose(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','LODYNET-SEASONS-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	xxcVm7YBMXsfd = GGvHJKP9LUxEk10Fw.findall('"CategorySubLinks"(.*?)</div>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if xxcVm7YBMXsfd and 'href=' in str(xxcVm7YBMXsfd):
		title = GGvHJKP9LUxEk10Fw.findall('<title>(.*?)-',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		title = title[0].strip(' ')
		cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,url,454)
		UCEFMfKbgpd = xxcVm7YBMXsfd[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)">(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,454)
	else: hWPvGlXZ5arzV7(url)
	return
def hWPvGlXZ5arzV7(url):
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',url,'','','','','LODYNET-EPISODES-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb = GGvHJKP9LUxEk10Fw.findall('"BlocksArea"(.*?)"text/javascript"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb:
		UCEFMfKbgpd = uo0MCJzWDUPfZqFNkHl8Kh1Gm3tcb[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?src="(.*?)".*?<h2>(.*?)</h2>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,VFqpJjRySZvgi,title in items:
			cd0aGwCPExbFU5pYNu8r('video',mmDwMlfoHtG5XT19VLIWqCR8i+title,ELbNB92cOh5dqtpVmi40kY,452,VFqpJjRySZvgi)
		EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"pagination"(.*?)</ul>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
		if EeQqAGc0W5r6nlBbChwfZL:
			UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
			items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?>(.*?)<',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
			for ELbNB92cOh5dqtpVmi40kY,title in items:
				title = DwNC3gEonizsB6a0v1F(title)
				cd0aGwCPExbFU5pYNu8r('folder',mmDwMlfoHtG5XT19VLIWqCR8i+'صفحة '+title,ELbNB92cOh5dqtpVmi40kY,454)
	return
def SUfe4unWoXBNFz90xqy(url):
	dR2vHyAtl8pJN1 = url.replace('/movies/','/watch_movies/')
	dR2vHyAtl8pJN1 = dR2vHyAtl8pJN1.replace('/episodes/','/watch_episodes/')
	WbTGMHnDysdYZ2lFA = bxUSPZNcXgLKGuFlenmkh2OCd6oa(Oa8xvPtmLZkBA43K0EzrdhXS,'GET',dR2vHyAtl8pJN1,'','','','','LODYNET-PLAY-1st')
	BBlXpmUyhFDwNtCVAHoE = WbTGMHnDysdYZ2lFA.content
	aPNBvIyexc053gAsSw1QoRMUYfb = RfKuIXwPAiWtmyF(dR2vHyAtl8pJN1,'url')
	zzvBg3ShiamAZ = []
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"WatchTitle"(.*?)</aside>',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('data-embed="(.*?)">(.*?)</li>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,title in items:
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named='+title+'__watch'
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	EeQqAGc0W5r6nlBbChwfZL = GGvHJKP9LUxEk10Fw.findall('"DownloadLinks"(.*?)"selary"',BBlXpmUyhFDwNtCVAHoE,GGvHJKP9LUxEk10Fw.DOTALL)
	if EeQqAGc0W5r6nlBbChwfZL:
		UCEFMfKbgpd = EeQqAGc0W5r6nlBbChwfZL[0]
		items = GGvHJKP9LUxEk10Fw.findall('href="(.*?)".*?<span>(.*?)</span>',UCEFMfKbgpd,GGvHJKP9LUxEk10Fw.DOTALL)
		for ELbNB92cOh5dqtpVmi40kY,name in items:
			name = DwNC3gEonizsB6a0v1F(name)
			dDZQSEGRTo9g85x1C = GGvHJKP9LUxEk10Fw.findall('\d\d\d+',name,GGvHJKP9LUxEk10Fw.DOTALL)
			if dDZQSEGRTo9g85x1C:
				dDZQSEGRTo9g85x1C = '____'+dDZQSEGRTo9g85x1C[0]
				name = ''
			else: dDZQSEGRTo9g85x1C = ''
			ELbNB92cOh5dqtpVmi40kY = ELbNB92cOh5dqtpVmi40kY+'?named='+name+'__download'+dDZQSEGRTo9g85x1C
			zzvBg3ShiamAZ.append(ELbNB92cOh5dqtpVmi40kY)
	import XXPcDGxLdW
	XXPcDGxLdW.YguVs5RJFwDK6X8E(zzvBg3ShiamAZ,cTJphS1nFz5EUgNWm86C,'video',url)
	return
def szwTAdaBt4FiXO(search):
	search,tY3Dfrp6cMKFj,showDialogs = AHhPV9MzsOwnESxWedl3J4vYm(search)
	if search=='': search = yMRXZIpKxlSkaE6iCO()
	if search=='': return
	search = search.replace(' ','+')
	url = NBm2aWhPzoTpdYn+'/search/'+search
	xoiXMWjJC3pnQqurIGPkRSl8e(url)
	return
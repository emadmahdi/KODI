# -*- coding: utf-8 -*-
import sys as ddABnr3K9Xv8e71CzcN0Pxt
NLQaPokgt7Zi = ddABnr3K9Xv8e71CzcN0Pxt.version_info [0] == 2
QzcRNkipwA1WPJu6ZoTnxrjBlqe2 = 2048
Y07K8pBzWtXncO9rUdsw1MTgAyFS = 7
def pFM6HfGd7Urbxto45vSNLniWA (gKVwro2lTJQEp):
	global AUQrTjaXt8K
	UUhFMplXo8RaCwxnEz5Hm7r = ord (gKVwro2lTJQEp [-1])
	slDu7whZzrU2b3oCYREig1L65F9HK = gKVwro2lTJQEp [:-1]
	Ha7jrvByPJYSIiRoXm5ThCOWc = UUhFMplXo8RaCwxnEz5Hm7r % len (slDu7whZzrU2b3oCYREig1L65F9HK)
	E5JVTBFqvjCN2Sc = slDu7whZzrU2b3oCYREig1L65F9HK [:Ha7jrvByPJYSIiRoXm5ThCOWc] + slDu7whZzrU2b3oCYREig1L65F9HK [Ha7jrvByPJYSIiRoXm5ThCOWc:]
	if NLQaPokgt7Zi:
		lK9D8U71rY = unicode () .join ([unichr (ord (ysjIJ8PTAQv5copxFkLUXrRwf) - QzcRNkipwA1WPJu6ZoTnxrjBlqe2 - (WutIpGj5YChbO + UUhFMplXo8RaCwxnEz5Hm7r) % Y07K8pBzWtXncO9rUdsw1MTgAyFS) for WutIpGj5YChbO, ysjIJ8PTAQv5copxFkLUXrRwf in enumerate (E5JVTBFqvjCN2Sc)])
	else:
		lK9D8U71rY = str () .join ([chr (ord (ysjIJ8PTAQv5copxFkLUXrRwf) - QzcRNkipwA1WPJu6ZoTnxrjBlqe2 - (WutIpGj5YChbO + UUhFMplXo8RaCwxnEz5Hm7r) % Y07K8pBzWtXncO9rUdsw1MTgAyFS) for WutIpGj5YChbO, ysjIJ8PTAQv5copxFkLUXrRwf in enumerate (E5JVTBFqvjCN2Sc)])
	return eval (lK9D8U71rY)
OVmSuf8tpd,LmcNhzY6fQPd2JyCGslkSr,J3OCAmZVcn=pFM6HfGd7Urbxto45vSNLniWA,pFM6HfGd7Urbxto45vSNLniWA,pFM6HfGd7Urbxto45vSNLniWA
eeIL1TfgFQJaKqVD8hGNPEZ,aFQoGfmYKyqLU6X8libw9k3ncW5,m6b7CoBk4EQ=J3OCAmZVcn,LmcNhzY6fQPd2JyCGslkSr,OVmSuf8tpd
ZSJVq5XDrRot,yTMWeCgUROcvtsblfK85L62xPk,AAgpHN0nMZ=m6b7CoBk4EQ,aFQoGfmYKyqLU6X8libw9k3ncW5,eeIL1TfgFQJaKqVD8hGNPEZ
XogUJZEijT7KWbxeO6,FhcnOB9t3frzvXb,aVLSn1xw5cK=AAgpHN0nMZ,yTMWeCgUROcvtsblfK85L62xPk,ZSJVq5XDrRot
ffCSGrTJYPsxgVQWKLtHU3iMwB,EDPaWgMt1SwNn8o,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg=aVLSn1xw5cK,FhcnOB9t3frzvXb,XogUJZEijT7KWbxeO6
Ej67fFyoqW8kbV2HdSK,kmdSKeBIwViM9t3,fR68jBGWCzUsFXdlTKPOScugm=PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg,EDPaWgMt1SwNn8o,ffCSGrTJYPsxgVQWKLtHU3iMwB
bdhQDyjm3nPwToFHkprvCzBLUGR,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r,wwyUWMFAsO=fR68jBGWCzUsFXdlTKPOScugm,kmdSKeBIwViM9t3,Ej67fFyoqW8kbV2HdSK
kRYWcNuAazr4jtmBoxFVS19Z6,pEo8g7riWVL014KaRtzQ,sArCMRngQNmXkBoKv=wwyUWMFAsO,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r,bdhQDyjm3nPwToFHkprvCzBLUGR
JMLhEyaBWmskovGHTrVCxQ08,MM2BQ7xrAfNivgenXPytGYOs0DEHRC,hjNP5w9srJz2QpVISxBfndbD4CkXvl=sArCMRngQNmXkBoKv,pEo8g7riWVL014KaRtzQ,kRYWcNuAazr4jtmBoxFVS19Z6
xuYvdJpOEyQKTLNwb,jYaM5vilgZdFx6QHbApwVXO8et,DLSVmlyBbCK=hjNP5w9srJz2QpVISxBfndbD4CkXvl,MM2BQ7xrAfNivgenXPytGYOs0DEHRC,JMLhEyaBWmskovGHTrVCxQ08
gnfv8UtZ3daGqpjzk,gSmqZU0plur2xKPJwQA,c4QSTnPiWUCjhrLlwGB=DLSVmlyBbCK,jYaM5vilgZdFx6QHbApwVXO8et,xuYvdJpOEyQKTLNwb
from xcH7j3ButC import *
import bidi.algorithm as hBvy1ernIGgsxCc4bSJMEjQXuLU,bidi.mirror as EEJlBFf5r4XdMUQiyhNR3uGs7,base64 as EGTVgQoSu6ZsD,requests as EfD78uCdxyZSO
ll6f2wvU4FdqL3MJyDxORESCK197i = m6b7CoBk4EQ(u"ࠩࡏࡍࡇ࡙ࡔࡘࡑࠪಏ")
YLg3diKrRb61pkP08hJBZNEsXlvA = {}
OWasmQ27g3Dbljpo = []
if VYMZsxRpcQHPgkaiDKjyoh:
	mqOvo7bGt2K6eh0wPYV1 = OkWUaJXTZf.translatePath(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡸࡣ࡯ࡦࠫಐ"))
	D2DYfsvFSG5CnV = OkWUaJXTZf.translatePath(kmdSKeBIwViM9t3(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩࠬ಑"))
	P2JEed3UY7vOC1ioqfFrKxpl4Qt = OkWUaJXTZf.translatePath(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩಒ"))
	CGoMep90r3LDHfxU16ntBZi8hdaIJg = hhHq8m5vauKG9dl.path.join(D2DYfsvFSG5CnV,c4QSTnPiWUCjhrLlwGB(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨಓ"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩಔ"),DLSVmlyBbCK(u"ࠨࡃࡧࡨࡴࡴࡳ࠴࠵࠱ࡨࡧ࠭ಕ"))
	DlE2VZrCQyYz9 = hhHq8m5vauKG9dl.path.join(D2DYfsvFSG5CnV,yTMWeCgUROcvtsblfK85L62xPk(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫಖ"),gnfv8UtZ3daGqpjzk(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬಗ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࡛ࠫ࡯ࡥࡸࡏࡲࡨࡪࡹ࠶࠯ࡦࡥࠫಘ"))
	doZD3UL95pTEIiOkMXquRa = hhHq8m5vauKG9dl.path.join(D2DYfsvFSG5CnV,ZSJVq5XDrRot(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧಙ"),OVmSuf8tpd(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨಚ"),xuYvdJpOEyQKTLNwb(u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧಛ"))
	LLf6s3gMbn = eeIL1TfgFQJaKqVD8hGNPEZ(u"ࡶࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩಜ")
	from urllib.parse import quote as _tiKbagXkV
else:
	mqOvo7bGt2K6eh0wPYV1 = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.translatePath(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡾࡢ࡮ࡥࠪಝ"))
	D2DYfsvFSG5CnV = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.translatePath(Ej67fFyoqW8kbV2HdSK(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫಞ"))
	P2JEed3UY7vOC1ioqfFrKxpl4Qt = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.translatePath(FhcnOB9t3frzvXb(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯࡭ࡱࡪࡴࡦࡺࡨࠨಟ"))
	CGoMep90r3LDHfxU16ntBZi8hdaIJg = hhHq8m5vauKG9dl.path.join(D2DYfsvFSG5CnV,gSmqZU0plur2xKPJwQA(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧಠ"),yTMWeCgUROcvtsblfK85L62xPk(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨಡ"),pEo8g7riWVL014KaRtzQ(u"ࠧࡂࡦࡧࡳࡳࡹ࠲࠸࠰ࡧࡦࠬಢ"))
	DlE2VZrCQyYz9 = hhHq8m5vauKG9dl.path.join(D2DYfsvFSG5CnV,m6b7CoBk4EQ(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪಣ"),wwyUWMFAsO(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫತ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࡚ࠪ࡮࡫ࡷࡎࡱࡧࡩࡸ࠼࠮ࡥࡤࠪಥ"))
	doZD3UL95pTEIiOkMXquRa = hhHq8m5vauKG9dl.path.join(D2DYfsvFSG5CnV,EDPaWgMt1SwNn8o(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭ದ"),EDPaWgMt1SwNn8o(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧಧ"),LmcNhzY6fQPd2JyCGslkSr(u"࠭ࡔࡦࡺࡷࡹࡷ࡫ࡳ࠲࠵࠱ࡨࡧ࠭ನ"))
	LLf6s3gMbn = bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࡵࠨ࡞ࡸ࠴࠷ࡪ࠱ࠨ಩").encode(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨࡷࡷࡪ࠽࠭ಪ"))
	from urllib import quote as _tiKbagXkV
wkKn0yuX13 = hhHq8m5vauKG9dl.path.join(P2JEed3UY7vOC1ioqfFrKxpl4Qt,JMLhEyaBWmskovGHTrVCxQ08(u"ࠩ࡮ࡳࡩ࡯࠮࡭ࡱࡪࠫಫ"))
sFgrS6kNYvPtD3u0x1L = hhHq8m5vauKG9dl.path.join(P2JEed3UY7vOC1ioqfFrKxpl4Qt,Ej67fFyoqW8kbV2HdSK(u"ࠪ࡯ࡴࡪࡩ࠯ࡱ࡯ࡨ࠳ࡲ࡯ࡨࠩಬ"))
zIB8rhRY234a = hhHq8m5vauKG9dl.path.join(mATvU6VbxOXNFhz8lK5WGrfQ,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫ࡮ࡶࡴࡷ࠳ࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭ಭ"))
k1dRDmf9BNME6UcoVQeO7P3Y = hhHq8m5vauKG9dl.path.join(mATvU6VbxOXNFhz8lK5WGrfQ,ZSJVq5XDrRot(u"ࠬ࡯ࡰࡵࡸ࠵ࡨࡦࡺࡡࡠࡡࡢ࠲ࡩࡨࠧಮ"))
n4ngaxMs3OK = hhHq8m5vauKG9dl.path.join(mATvU6VbxOXNFhz8lK5WGrfQ,eeIL1TfgFQJaKqVD8hGNPEZ(u"࠭࡭࠴ࡷࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭ಯ"))
P71CANTSyWYptGs8JnZkUHu3Kwi6Ql = hhHq8m5vauKG9dl.path.join(mATvU6VbxOXNFhz8lK5WGrfQ,aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧࡧࡣࡹࡳࡺࡸࡩࡵࡧࡶ࠲ࡩࡧࡴࠨರ"))
qqXYCDM3kcB7mNj6W2h8dwb = hhHq8m5vauKG9dl.path.join(mATvU6VbxOXNFhz8lK5WGrfQ,m6b7CoBk4EQ(u"ࠨ࡫ࡳࡸࡻ࡬ࡩ࡭ࡧࡢࡣࡤ࠴ࡤࡢࡶࠪಱ"))
kyZdMcbuHrEwf = hhHq8m5vauKG9dl.path.join(mATvU6VbxOXNFhz8lK5WGrfQ,m6b7CoBk4EQ(u"ࠩࡰ࠷ࡺ࡬ࡩ࡭ࡧࡢࡣࡤ࠴ࡤࡢࡶࠪಲ"))
Po8NVKEkyc30eCS = hhHq8m5vauKG9dl.path.join(mATvU6VbxOXNFhz8lK5WGrfQ,aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠪ࡭ࡲࡧࡧࡦࡵࠪಳ"))
KQVBHLJCh4IsRfY01nu9 = hhHq8m5vauKG9dl.path.join(Po8NVKEkyc30eCS,LmcNhzY6fQPd2JyCGslkSr(u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡷࠬ಴"))
HVZp3DNTCmeMA5lOBnWyI1dfvFqJzU = hhHq8m5vauKG9dl.path.join(KQVBHLJCh4IsRfY01nu9,kmdSKeBIwViM9t3(u"ࠬࡪࡩࡢ࡮ࡲ࡫ࡤ࠶࠰࠱࠲ࡢ࠲ࡵࡴࡧࠨವ"))
J5keFiyQtf9bGZ0vulzNIsTYMx1oR = A2AXwrPWdJ3V4958K.Addon().getAddonInfo(XogUJZEijT7KWbxeO6(u"࠭ࡰࡢࡶ࡫ࠫಶ"))
pw80MbNXAgc1s2 = hhHq8m5vauKG9dl.path.join(J5keFiyQtf9bGZ0vulzNIsTYMx1oR,c4QSTnPiWUCjhrLlwGB(u"ࠧࡪࡥࡲࡲ࠳ࡶ࡮ࡨࠩಷ"))
H8KRdpbwzNPJ6tL = hhHq8m5vauKG9dl.path.join(J5keFiyQtf9bGZ0vulzNIsTYMx1oR,pEo8g7riWVL014KaRtzQ(u"ࠨࡶ࡫ࡹࡲࡨ࠮ࡱࡰࡪࠫಸ"))
lcSEbP6kx5NhfoITZLyq91 = hhHq8m5vauKG9dl.path.join(J5keFiyQtf9bGZ0vulzNIsTYMx1oR,gSmqZU0plur2xKPJwQA(u"ࠩࡩࡥࡳࡧࡲࡵ࠰ࡳࡲ࡬࠭ಹ"))
zzqcLFIrpZTvySm9Qkj2YeX8Da3nx = hhHq8m5vauKG9dl.path.join(J5keFiyQtf9bGZ0vulzNIsTYMx1oR,XogUJZEijT7KWbxeO6(u"ࠪࡦࡦࡴ࡮ࡦࡴ࠱ࡴࡳ࡭ࠧ಺"))
iALf3heBoQVRwpg7 = hhHq8m5vauKG9dl.path.join(J5keFiyQtf9bGZ0vulzNIsTYMx1oR,EDPaWgMt1SwNn8o(u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫࠮ࡱࡰࡪࠫ಻"))
rJm3aq4Fpj2ZnU0sNMS9wHQf1 = hhHq8m5vauKG9dl.path.join(J5keFiyQtf9bGZ0vulzNIsTYMx1oR,FhcnOB9t3frzvXb(u"ࠬࡶ࡯ࡴࡶࡨࡶ࠳ࡶ࡮ࡨ಼ࠩ"))
eXGEtqBJ06TCuw = hhHq8m5vauKG9dl.path.join(J5keFiyQtf9bGZ0vulzNIsTYMx1oR,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭ࡣ࡭ࡧࡤࡶࡱࡵࡧࡰ࠰ࡳࡲ࡬࠭ಽ"))
SaFiHAzn1JMkLDbvrK = hhHq8m5vauKG9dl.path.join(J5keFiyQtf9bGZ0vulzNIsTYMx1oR,sArCMRngQNmXkBoKv(u"ࠧࡤ࡮ࡨࡥࡷࡧࡲࡵ࠰ࡳࡲ࡬࠭ಾ"))
vhILp70VsMPBjG3Wb1OiZqCT = hhHq8m5vauKG9dl.path.join(J5keFiyQtf9bGZ0vulzNIsTYMx1oR,aVLSn1xw5cK(u"ࠨ࡯ࡨࡲࡺ࠴ࡰ࡯ࡩࠪಿ"))
oHI0G2nwtkFxjlORMQfc6sJ = hhHq8m5vauKG9dl.path.join(J5keFiyQtf9bGZ0vulzNIsTYMx1oR,xuYvdJpOEyQKTLNwb(u"ࠩࡦ࡬ࡦࡴࡧࡦ࡮ࡲ࡫࠳ࡺࡸࡵࠩೀ"))
hWu2yd5fRP = hhHq8m5vauKG9dl.path.join(D2DYfsvFSG5CnV,ZSJVq5XDrRot(u"ࠪࡥࡩࡪ࡯࡯ࡵࠪು"))
vHLfqUjC0xy = hhHq8m5vauKG9dl.path.join(D2DYfsvFSG5CnV,kmdSKeBIwViM9t3(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭ೂ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩೃ"),ZK5gkAtjrCeEXYGD2bRQHOF3Moyc,xuYvdJpOEyQKTLNwb(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬೄ"))
I0kWLGvRgTPyNq75uaKxB6eDC9 = hhHq8m5vauKG9dl.path.join(mqOvo7bGt2K6eh0wPYV1,gSmqZU0plur2xKPJwQA(u"ࠧ࡮ࡧࡧ࡭ࡦ࠭೅"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨࡈࡲࡲࡹࡹࠧೆ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠩࡤࡶ࡮ࡧ࡬࠯ࡶࡷࡪࠬೇ"))
SS2ZAHCRpu8QxIao7BMq = ZSJVq5XDrRot(u"࠻ᔢ")
KnGrOQsDgfB8Raj9C2AZJuYcTxP = [Ej67fFyoqW8kbV2HdSK(u"ูࠪๆืࠧೈ"),fR68jBGWCzUsFXdlTKPOScugm(u"ࠫศ๎ไࠨ೉"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠬัว็์ࠪೊ"),ZSJVq5XDrRot(u"࠭หศๆฮࠫೋ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧาษห฽ࠬೌ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨะส್ุ้࠭"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠩึหิูࠧ೎"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠪืฬฮูࠨ೏"),ZSJVq5XDrRot(u"ࠫะอๅ็ࠩ೐"),FhcnOB9t3frzvXb(u"ࠬะวิ฻ࠪ೑"),jYaM5vilgZdFx6QHbApwVXO8et(u"ู࠭ศึิࠫ೒")]
VVaGyg2580cfE = XogUJZEijT7KWbxeO6(u"ࠧ⸼ࠢ⼠ࠤⸯࠦ⸻ࠨ೓")
RYFreQufSzqAbP9gsLGTt0m5HNw = [m6b7CoBk4EQ(u"ࠨ࡛ࡗࡆࡤࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ೔")]
FOIDEWbjVTtS = [kmdSKeBIwViM9t3(u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝ࠫೕ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠭ೖ"),gnfv8UtZ3daGqpjzk(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐࠨ೗"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠬࡋࡇ࡚ࡆࡈࡅࡉ࠭೘"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅࠩ೙"),sArCMRngQNmXkBoKv(u"ࠧࡎࡑ࡙ࡗ࠹࡛ࠧ೚"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨࡏ࡜ࡇࡎࡓࡁࠨ೛"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࡏࡅࡗࡕ࡚ࡂࠩ೜"),aVLSn1xw5cK(u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍࠬೝ"),FhcnOB9t3frzvXb(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠭ೞ")]
FOIDEWbjVTtS += [XogUJZEijT7KWbxeO6(u"ࠬࡎࡅࡍࡃࡏࠫ೟"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌࠬೠ"),sArCMRngQNmXkBoKv(u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎࠩೡ"),ZSJVq5XDrRot(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࠩೢ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓࠫೣ"),sArCMRngQNmXkBoKv(u"ࠪࡉࡌ࡟ࡎࡐ࡙ࠪ೤"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠭೥"),wwyUWMFAsO(u"ࠬࡖࡁࡏࡇࡗࠫ೦"),Ej67fFyoqW8kbV2HdSK(u"࠭ࡃࡊࡏࡄ࠸࡚࠭೧"),OVmSuf8tpd(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭೨")]
Ry7UJZAh9zS = [Ej67fFyoqW8kbV2HdSK(u"ࠨࡋࡓࡘ࡛࠭೩"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬ೪"),sArCMRngQNmXkBoKv(u"ࠪࡍࡕ࡚ࡖ࠮ࡏࡒ࡚ࡎࡋࡓࠨ೫"),wwyUWMFAsO(u"ࠫࡎࡖࡔࡗ࠯ࡖࡉࡗࡏࡅࡔࠩ೬")]
Ry7UJZAh9zS += [ZSJVq5XDrRot(u"ࠬࡓ࠳ࡖࠩ೭"),jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࠨ೮"),sArCMRngQNmXkBoKv(u"ࠧࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫ೯"),fR68jBGWCzUsFXdlTKPOScugm(u"ࠨࡏ࠶࡙࠲࡙ࡅࡓࡋࡈࡗࠬ೰")]
Ry7UJZAh9zS += [J3OCAmZVcn(u"ࠩࡌࡊࡎࡒࡍࠨೱ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩೲ"),J3OCAmZVcn(u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫೳ")]
Ry7UJZAh9zS += [J3OCAmZVcn(u"ࠬࡇࡋࡘࡃࡐࠫ೴"),JMLhEyaBWmskovGHTrVCxQ08(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ೵"),kmdSKeBIwViM9t3(u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩ೶"),kmdSKeBIwViM9t3(u"ࠨࡃࡎࡓࡆࡓࠧ೷"),AAgpHN0nMZ(u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫ೸")]
Ry7UJZAh9zS += [Ej67fFyoqW8kbV2HdSK(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭೹"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠫࡇࡕࡋࡓࡃࠪ೺"),J3OCAmZVcn(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ೻"),xuYvdJpOEyQKTLNwb(u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫ೼"),LmcNhzY6fQPd2JyCGslkSr(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩ೽"),XogUJZEijT7KWbxeO6(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴ࠪ೾")]
r16Wf3imkv4BGhq5bReoxEpgzUsdw9 = [Ej67fFyoqW8kbV2HdSK(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ೿"),kmdSKeBIwViM9t3(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱࡛ࡏࡄࡆࡑࡖࠫഀ"),XogUJZEijT7KWbxeO6(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨഁ"),sArCMRngQNmXkBoKv(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨം")]
r16Wf3imkv4BGhq5bReoxEpgzUsdw9 += [kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫഃ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡜ࡉࡅࡇࡒࡗࠬഄ"),EDPaWgMt1SwNn8o(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩഅ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩആ"),aVLSn1xw5cK(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡖࡒࡔࡎࡉࡓࠨഇ"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡏࡍ࡛ࡋࡓࠨഈ")]
wLGYuyAbjiocERx8sHZpaOFUKdfN = [aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨഉ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧഊ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨഋ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪഌ"),xuYvdJpOEyQKTLNwb(u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭഍")]
wLGYuyAbjiocERx8sHZpaOFUKdfN += [XogUJZEijT7KWbxeO6(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬഎ"),XogUJZEijT7KWbxeO6(u"࡙ࠫ࡜ࡆࡖࡐࠪഏ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠬ࡝ࡅࡄࡋࡐࡅࠬഐ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ഑")]
FKY2egH1L8xQyvNClp = [DLSVmlyBbCK(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩഒ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕࠪഓ"),kmdSKeBIwViM9t3(u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬഔ"),J3OCAmZVcn(u"ࠪࡊࡔ࡙ࡔࡂࠩക"),sArCMRngQNmXkBoKv(u"ࠫࡆࡎࡗࡂࡍࠪഖ"),sArCMRngQNmXkBoKv(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭ഗ")]
FKY2egH1L8xQyvNClp += [EDPaWgMt1SwNn8o(u"࠭ࡓࡉࡑࡉࡌࡆ࠭ഘ"),kmdSKeBIwViM9t3(u"ࠧࡃࡔࡖࡘࡊࡐࠧങ"),J3OCAmZVcn(u"ࠨ࡛ࡄࡕࡔ࡚ࠧച"),pEo8g7riWVL014KaRtzQ(u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪഛ"),m6b7CoBk4EQ(u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫജ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭ഝ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧഞ")]
xQ7m5hpIHEt9UZFiwres3B2o1T  = [Ej67fFyoqW8kbV2HdSK(u"࠭ࡁࡌ࡙ࡄࡑࠬട"),c4QSTnPiWUCjhrLlwGB(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩഠ"),DLSVmlyBbCK(u"ࠨࡄࡒࡏࡗࡇࠧഡ"),J3OCAmZVcn(u"ࠩࡄࡏࡔࡇࡍࠨഢ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬണ"),pEo8g7riWVL014KaRtzQ(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭ത"),gnfv8UtZ3daGqpjzk(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭ഥ")]
xQ7m5hpIHEt9UZFiwres3B2o1T += [MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨദ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪധ"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩന"),OVmSuf8tpd(u"࡚ࠩࡉࡈࡏࡍࡂࠩഩ"),kmdSKeBIwViM9t3(u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧപ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫࡋࡕࡓࡕࡃࠪഫ"),fR68jBGWCzUsFXdlTKPOScugm(u"ࠬࡇࡈࡘࡃࡎࠫബ")]
xQ7m5hpIHEt9UZFiwres3B2o1T += [sArCMRngQNmXkBoKv(u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩഭ"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪമ"),sArCMRngQNmXkBoKv(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪയ"),XogUJZEijT7KWbxeO6(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠵ࠫര"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬറ"),AAgpHN0nMZ(u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭ല")]
xQ7m5hpIHEt9UZFiwres3B2o1T += [aVLSn1xw5cK(u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭ള"),FhcnOB9t3frzvXb(u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨഴ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩവ"),LmcNhzY6fQPd2JyCGslkSr(u"ࠨࡖ࡙ࡊ࡚ࡔࠧശ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫഷ"),gnfv8UtZ3daGqpjzk(u"ࠪࡗࡍࡕࡆࡉࡃࠪസ")]
xQ7m5hpIHEt9UZFiwres3B2o1T += [DLSVmlyBbCK(u"ࠫࡇࡘࡓࡕࡇࡍࠫഹ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬ࡟ࡁࡒࡑࡗࠫഺ"),pEo8g7riWVL014KaRtzQ(u"࠭ࡄࡓࡃࡐࡅࡘ࠽഻ࠧ"),J3OCAmZVcn(u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨ഼"),aVLSn1xw5cK(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭ഽ"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫാ"),fR68jBGWCzUsFXdlTKPOScugm(u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚ࠬി")]
EFLC5Z9I0cl  = [c4QSTnPiWUCjhrLlwGB(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࡙ࡍࡉࡋࡏࡔࠩീ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭ു"),pEo8g7riWVL014KaRtzQ(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭ൂ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡚ࡏࡑࡋࡆࡗࠬൃ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡌࡊࡘࡈࡗࠬൄ")]
EFLC5Z9I0cl += [gnfv8UtZ3daGqpjzk(u"ࠩࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࠨ൅"),FhcnOB9t3frzvXb(u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࠪെ")]
EFLC5Z9I0cl += [pEo8g7riWVL014KaRtzQ(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲࡜ࡉࡅࡇࡒࡗࠬേ"),XogUJZEijT7KWbxeO6(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩൈ"),EDPaWgMt1SwNn8o(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ൉")]
EFLC5Z9I0cl += [fR68jBGWCzUsFXdlTKPOScugm(u"ࠧࡊࡒࡗ࡚࠲ࡒࡉࡗࡇࠪൊ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࡋࡓࡘ࡛࠳ࡍࡐࡘࡌࡉࡘ࠭ോ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧൌ")]
EFLC5Z9I0cl += [PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࡑ࠸࡛࠭ࡍࡋ࡙ࡉ്ࠬ"),XogUJZEijT7KWbxeO6(u"ࠫࡒ࠹ࡕ࠮ࡏࡒ࡚ࡎࡋࡓࠨൎ"),gnfv8UtZ3daGqpjzk(u"ࠬࡓ࠳ࡖ࠯ࡖࡉࡗࡏࡅࡔࠩ൏")]
YaJxOZ1qWck = [sArCMRngQNmXkBoKv(u"࠭ࡍ࠴ࡗࠪ൐"),EDPaWgMt1SwNn8o(u"ࠧࡊࡒࡗ࡚ࠬ൑"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭൒"),wwyUWMFAsO(u"ࠩࡌࡊࡎࡒࡍࠨ൓"),aVLSn1xw5cK(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫൔ")]
g84gfDrBtVRb1KM7o5 = xQ7m5hpIHEt9UZFiwres3B2o1T+EFLC5Z9I0cl
ujqHb6gv3ZcKmJazCy2 = xQ7m5hpIHEt9UZFiwres3B2o1T+YaJxOZ1qWck
bEY9tdnqgQAaB1L4VeNlDZ = xQ7m5hpIHEt9UZFiwres3B2o1T+EFLC5Z9I0cl
aaPxVDR1EFfA9ghw2 = Ry7UJZAh9zS+wLGYuyAbjiocERx8sHZpaOFUKdfN+FKY2egH1L8xQyvNClp+r16Wf3imkv4BGhq5bReoxEpgzUsdw9
CCndLYKhjyiwb = [
						m6b7CoBk4EQ(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭ൕ")
						,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠶ࡳࡪࠧൖ")
						,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐ࡙ࡑ࡚ࡉࡠ࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧൗ")
						]
ppEw9HgZkCPtvnjV4Y = [
						pEo8g7riWVL014KaRtzQ(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡕࡈࡒࡉࡥࡁࡏࡃࡏ࡝࡙ࡏࡃࡔࡡࡈ࡚ࡊࡔࡔ࠮࠳ࡶࡸࠬ൘")
						,aVLSn1xw5cK(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡈ࡜࡙ࡘࡁࡄࡖࡢࡑ࠸࡛࠸࠮࠳ࡶࡸࠬ൙")
						,gnfv8UtZ3daGqpjzk(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡆࡔࡄࡐࡏࡢ࡙ࡘࡋࡒࡂࡉࡈࡒ࡙࠳࠱ࡴࡶࠪ൚")
						,DLSVmlyBbCK(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡒࡕࡓ࡝ࡏࡅࡔࡡࡏࡍࡘ࡚࠭࠲ࡵࡷࠫ൛")
						,JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࡎࡖࡔࡗ࠯ࡆࡌࡊࡉࡋࡠࡃࡆࡇࡔ࡛ࡎࡕ࠯࠴ࡷࡹ࠭൜")
						,xuYvdJpOEyQKTLNwb(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡑࡏࡓࡈࡇࡔࡊࡑࡑ࠱࠶ࡹࡴࠨ൝")
						,fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠱ࡴࡶࠪ൞")
						,kmdSKeBIwViM9t3(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠴ࡴࡧࠫൟ")
						,fR68jBGWCzUsFXdlTKPOScugm(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡉࡆࡊ࡟ࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌ࠮࠳ࡶࡸࠬൠ")
						,wwyUWMFAsO(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕ࠯࠴ࡷࡹ࠭ൡ")
						,DLSVmlyBbCK(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠳ࡳࡦࠪൢ")
						,XogUJZEijT7KWbxeO6(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠶ࡶ࡫ࠫൣ")
						,Ej67fFyoqW8kbV2HdSK(u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ൤")
						,gnfv8UtZ3daGqpjzk(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠶ࡹࡴࠨ൥")
						,AAgpHN0nMZ(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠸࡮ࡥࠩ൦")
						]
vw4ahqzAlgOVTnNe29SXWUJZ8pf = ppEw9HgZkCPtvnjV4Y+[
				 fR68jBGWCzUsFXdlTKPOScugm(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡓࡖࡔ࡞࡙ࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪ൧")
				,xuYvdJpOEyQKTLNwb(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡍ࡚ࡔࡑࡕࡓࡖࡔ࡞ࡉࡆࡕ࠰࠵ࡸࡺࠧ൨")
				,JMLhEyaBWmskovGHTrVCxQ08(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤ࡝ࡅࡃࡒࡕࡓ࡝ࡏࡅࡔ࠯࠴ࡷࡹ࠭൩")
				,kmdSKeBIwViM9t3(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞ࡉࡆࡕ࠰࠶ࡳࡪࠧ൪")
				,FhcnOB9t3frzvXb(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘ࡚ࡖࡒ࠱࠶ࡹࡴࠨ൫")
				,bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙࡛ࡗࡓ࠲࠸࡮ࡥࠩ൬")
				,Ej67fFyoqW8kbV2HdSK(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡎࡔࡗࡕࡘ࡚ࡅࡒࡑ࠲࠷ࡳࡵࠩ൭")
				,FhcnOB9t3frzvXb(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡏࡕࡘࡏ࡙࡛ࡆࡓࡒ࠳࠲࡯ࡦࠪ൮")
				,OVmSuf8tpd(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡐࡖࡒࡐ࡚࡜ࡇࡔࡓ࠭࠴ࡴࡧࠫ൯")
				,wwyUWMFAsO(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡈࡎࡅࡄࡍࡢࡌ࡙࡚ࡐࡔࡡࡓࡖࡔ࡞ࡉࡆࡕ࠰࠵ࡸࡺࠧ൰")
				,c4QSTnPiWUCjhrLlwGB(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡈࡕࡖࡓࡗࡤ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧ൱")
				,eeIL1TfgFQJaKqVD8hGNPEZ(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡕࡇࡖࡘࡤࡇࡌࡍࡡ࡚ࡉࡇ࡙ࡉࡕࡇࡖ࠱࠶ࡹࡴࠨ൲")
				,wwyUWMFAsO(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡖࡈࡗ࡙ࡥࡁࡍࡎࡢ࡛ࡊࡈࡓࡊࡖࡈࡗ࠲࠸࡮ࡥࠩ൳")
				,kmdSKeBIwViM9t3(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡘࡗࡆࡍࡅࡠࡔࡈࡔࡔࡘࡔ࠮࠳ࡶࡸࠬ൴")
				,MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩ൵")
				,jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊ࡜ࡅࡓࡕࡒࡣ࡙ࡘࡁࡏࡕࡏࡅ࡙ࡋ࠭࠲ࡵࡷࠫ൶")
				]
XK2WaStRNq = [Ej67fFyoqW8kbV2HdSK(u"ࠪ࠼࠳࠾࠮࠹࠰࠻ࠫ൷"),wwyUWMFAsO(u"ࠫ࠶࠴࠱࠯࠳࠱࠵ࠬ൸"),LmcNhzY6fQPd2JyCGslkSr(u"ࠬ࠷࠮࠱࠰࠳࠲࠶࠭൹"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭࠸࠯࠺࠱࠸࠳࠺ࠧൺ"),DLSVmlyBbCK(u"ࠧ࠳࠲࠻࠲࠻࠽࠮࠳࠴࠵࠲࠷࠸࠲ࠨൻ"),gSmqZU0plur2xKPJwQA(u"ࠨ࠴࠳࠼࠳࠼࠷࠯࠴࠵࠴࠳࠸࠲࠱ࠩർ")]
uReHcEzxkTm6pN4Q = {
			 JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠩࡄࡏࡔࡇࡍࠨൽ")		:[aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡱ࠮ࡴࡸ࠲ࡳࡱࡪࠧൾ")]
			,eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫࡆࡎࡗࡂࡍࠪൿ")		:[JMLhEyaBWmskovGHTrVCxQ08(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡴ࠰ࡤ࡬ࡼࡧ࡫ࡵࡸ࠱ࡲࡪࡺࠧ඀")]
			,jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࡁࡌ࡙ࡄࡑࠬඁ")		:[MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣ࡮࠲ࡸࡼࠧං")]
			,kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨࡃࡏࡅࡗࡇࡂࠨඃ")		:[LmcNhzY6fQPd2JyCGslkSr(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺࡴࡪ࠮ࡢ࡮ࡤࡶࡦࡨ࠮ࡤࡱࡰࠫ඄")]
			,c4QSTnPiWUCjhrLlwGB(u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍࠬඅ")		:[bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡲࡦࡢࡶ࡬ࡱ࡮࠴ࡴࡷࠩආ")]
			,J3OCAmZVcn(u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧඇ")		:[JMLhEyaBWmskovGHTrVCxQ08(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡮ࡰࡥࡦࡸࡥࡧ࠰ࡦ࡬ࠬඈ")]
			,aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗࠬඉ")	:[ZSJVq5XDrRot(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡧࡲࡢࡤ࡬ࡧ࠲ࡺ࡯ࡰࡰࡶ࠲ࡨࡵ࡭ࠨඊ")]
			,Ej67fFyoqW8kbV2HdSK(u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫඋ")		:[FhcnOB9t3frzvXb(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸࡡࡣࡵࡨࡩࡩ࠴࡮ࡦࡶࠪඌ")]
			,gSmqZU0plur2xKPJwQA(u"ࠫࡇࡕࡋࡓࡃࠪඍ")		:[DLSVmlyBbCK(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡨࡰࡱࡩࡺࡴࡪ࠮ࡤࡱࡰࠫඎ")]
			,hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭ࡂࡓࡕࡗࡉࡏ࠭ඏ")		:[LmcNhzY6fQPd2JyCGslkSr(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡤࡵࡷࡹ࡫ࡪ࠯ࡥࡲࡱࠬඐ")]
			,DLSVmlyBbCK(u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩඑ")		:[aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࠵࠲࠳࠲ࡨࡵ࡭ࠨඒ")]
			,wwyUWMFAsO(u"ࠪࡇࡎࡓࡁ࠵ࡗࠪඓ")		:[FhcnOB9t3frzvXb(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠷ࡣࡪ࡯ࡤ࠸ࡺ࠴ࡣࡰ࡯ࠪඔ")]
			,ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧඕ")		:[JMLhEyaBWmskovGHTrVCxQ08(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥ࠸ࡨࡤࡰ࠰ࡦࡳࡲ࠭ඖ")]
			,xuYvdJpOEyQKTLNwb(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩ඗")		:[OVmSuf8tpd(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧࡣ࡭ࡷࡥ࠲ࡼࡧࡴࡤࡪࠪ඘")]
			,EDPaWgMt1SwNn8o(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࡛ࡔࡘࡋࠨ඙")	:[kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹࡼࡶ࠯ࡥ࡬ࡱࡦࡩ࡬ࡶࡤ࠱ࡷ࡭ࡵࡰࠨක")]
			,hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭ඛ")		:[J3OCAmZVcn(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡧ࡮ࡳࡡࡧࡣࡱࡷ࠳ࡩ࡯࡮ࠩග")]
			,kmdSKeBIwViM9t3(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩඝ")	:[AAgpHN0nMZ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹ࠵࠻࠳ࡳࡹ࠮ࡥ࡬ࡱࡦ࠴࡮ࡦࡶ࠲ࡱࡾࡩ࠱ࠨඞ")]
			,AAgpHN0nMZ(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩඟ")		:[yTMWeCgUROcvtsblfK85L62xPk(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࡯ࡱࡺ࠲ࡨࡩࠧච")]
			,c4QSTnPiWUCjhrLlwGB(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨඡ")	:[gSmqZU0plur2xKPJwQA(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠮ࡤࡱࡰࠫජ"),sArCMRngQNmXkBoKv(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧࡳࡣࡳ࡬ࡶࡲ࠮ࡢࡲ࡬࠲ࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠰ࡦࡳࡲ࠭ඣ")]
			,ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧඤ")		:[pEo8g7riWVL014KaRtzQ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡦ࠲ࡩࡸࡡ࡮ࡣࡶ࠻࠳ࡩ࡯࡮ࠩඥ")]
			,Ej67fFyoqW8kbV2HdSK(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪඦ")		:[c4QSTnPiWUCjhrLlwGB(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡢࡦࡵࡷ࠲࡫ࡻ࡮ࠨට")]
			,hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬඨ")		:[LmcNhzY6fQPd2JyCGslkSr(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡤࡨࡷࡹ࠴ࡷࡦࡤࡦࡥࡲ࠭ඩ")]
			,hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧඪ")		:[OVmSuf8tpd(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡪࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡥ࡭ࡩ࠭ණ")]
			,J3OCAmZVcn(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵ࠩඬ")		:[FhcnOB9t3frzvXb(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾ࠳ࡢࡦࡵࡷ࠲ࡳ࡫ࡴࠨත")]
			,aVLSn1xw5cK(u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪථ")		:[pEo8g7riWVL014KaRtzQ(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡥࡧࡤࡨ࠳ࡲࡩࡷࡧࠪද")]
			,wwyUWMFAsO(u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠭ධ")		:[kmdSKeBIwViM9t3(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡭ࡥ࡬ࡲࡪࡳࡡ࠯ࡥࡲࡱࠬන")]
			,OVmSuf8tpd(u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧ඲")		:[fR68jBGWCzUsFXdlTKPOScugm(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤࡦࡷࡱࡡ࠯ࡥࡲࡱࠬඳ")]
			,XogUJZEijT7KWbxeO6(u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫප")	:[EDPaWgMt1SwNn8o(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦࡰࡥࡳ࠰ࡶ࡬ࡴࡽࠧඵ")]
			,AAgpHN0nMZ(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬබ")		:[ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡩࡥࡸ࡫࡬ࡩࡦࡶ࠲ࡼࡵࡲ࡭ࡦࠪභ")]
			,fR68jBGWCzUsFXdlTKPOScugm(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸ࠧම")		:[jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡵ࡯ࡥ࠳࡬ࡡࡴࡧ࡯࡬ࡩ࠴ࡣ࡭ࡱࡸࡨࠬඹ")]
			,pEo8g7riWVL014KaRtzQ(u"ࠧࡇࡑࡖࡘࡆ࠭ය")		:[hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻ࡯࠴ࡦࡰࡵࡷࡥ࠲ࡺࡶ࠯ࡰࡨࡸࠬර")]
			,fR68jBGWCzUsFXdlTKPOScugm(u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫ඼")		:[c4QSTnPiWUCjhrLlwGB(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡭ࡧ࡬ࡢࡥ࡬ࡱࡦ࠴࡭ࡦࡦ࡬ࡥࠬල")]
			,hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫࡎࡌࡉࡍࡏࠪ඾")		:[XogUJZEijT7KWbxeO6(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳ࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭඿"),eeIL1TfgFQJaKqVD8hGNPEZ(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡰ࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧව"),DLSVmlyBbCK(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨශ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥ࠷࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪෂ"),J3OCAmZVcn(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠼࠷࠳࠷࠹࠱࠰࠵࠸࠳࠷࠲࠳ࠩස")]
			,LmcNhzY6fQPd2JyCGslkSr(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭හ")	:[JMLhEyaBWmskovGHTrVCxQ08(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱࡡࡳࡤࡤࡰࡦ࠳ࡴࡷ࠰࡬ࡵࠬළ")]
			,AAgpHN0nMZ(u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧෆ")		:[EDPaWgMt1SwNn8o(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨࡱࡲ࠲ࡰ࡯ࡴ࡬ࡱࡷ࠲ࡹࡼࠧ෇")]
			,MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧࡌࡑࡇࡍࡊࡓࡁࡅࡡࡄࡔࡕ࠭෈")	:[XogUJZEijT7KWbxeO6(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷ࡭ࡳࡿ࠮ࡤࡥ࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨࠬ෉"),xuYvdJpOEyQKTLNwb(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠳࠲࠴࠼࠳࡬ࡷࡴ࠰ࡶࡸࡴࡸࡥࠨ්")]
			,fR68jBGWCzUsFXdlTKPOScugm(u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫ෋")		:[AAgpHN0nMZ(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡲ࡯ࡥࡻࡱࡩࡹ࠴࡬ࡪࡰ࡮ࠫ෌")]
			,OVmSuf8tpd(u"ࠬࡖࡁࡏࡇࡗࠫ෍")		:[bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡴࡦࡴࡥࡵ࠰ࡦࡳ࠳࡯࡬ࠨ෎")]
			,kmdSKeBIwViM9t3(u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩා")		:[wwyUWMFAsO(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬࡮ࡪ࠴ࡶ࠰ࡦࡥࡲ࠭ැ")]
			,yTMWeCgUROcvtsblfK85L62xPk(u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭ෑ")	:[aVLSn1xw5cK(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࠴ࡳࡩ࠶ࡸ࠲ࡳ࡫ࡷࡴࠩි")]
			,DLSVmlyBbCK(u"ࠫࡘࡎࡏࡇࡊࡄࠫී")		:[eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡪࡦ࠱ࡷ࡭ࡵࡦࡩࡣ࠱ࡸࡻ࠭ු")]
			,m6b7CoBk4EQ(u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨ෕")		:[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫ࡳࡴ࡬࡭ࡢࡺ࠱ࡧࡴࡳࠧූ"),c4QSTnPiWUCjhrLlwGB(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡸࡦࡺࡩࡤ࠰ࡶ࡬ࡴࡵࡦ࡮ࡣࡻ࠲ࡨࡵ࡭ࠨ෗"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼ࠳ࡧࡺࡶࡴࡨࡩࡩ࡭ࡥ࠯ࡰࡨࡸࠬෘ")]
			,yTMWeCgUROcvtsblfK85L62xPk(u"ࠪࡘ࡛ࡌࡕࡏࠩෙ")		:[kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹ࠮ࡵࡸࡩࡹࡳ࠴࡭ࡦࠩේ")]
			,ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬ࡝ࡅࡄࡋࡐࡅࠬෛ")		:[gSmqZU0plur2xKPJwQA(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡹࡰ࠰࠱࠲࠳࠭࠮ࡰࡽࡩࡧࡩࡡ࠶ࡩࡧ࠻ࡴࡪࡥ࠱ࡤ࡬࡫ࡱ࡮࠮࡮ࡻࡦ࡭࡮ࡳࡡ࠮ࡹࡨࡧ࡮࡯࡭ࡢ࠰ࡶ࡬ࡴࡶࠧො")]
			,ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࡚ࠧࡃࡔࡓ࡙࠭ෝ")		:[aVLSn1xw5cK(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡼ࠲ࡾࡧࡱࡰࡶ࠱ࡸࡻ࠭ෞ")]
			,kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪෟ")		:[xuYvdJpOEyQKTLNwb(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠭෠")]
			,FhcnOB9t3frzvXb(u"ࠫࡗࡋࡐࡐࡕࠪ෡")		:[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬ෢"),c4QSTnPiWUCjhrLlwGB(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶ࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠳࠻࠳ࡦࡪࡤࡰࡰࡶ࠵࠽࠴ࡸ࡮࡮ࠪ෣"),ZSJVq5XDrRot(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑ࠲ࡅࡉࡊࡏࡏࡕ࠴࠽࠴ࡧࡤࡥࡱࡱࡷ࠶࠿࠮ࡹ࡯࡯ࠫ෤")]
			,MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨࡔࡈࡔࡔ࡙࡟ࡃࡍࡓࠫ෥")	:[OVmSuf8tpd(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ෦"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠵࠽࠵ࡡࡥࡦࡲࡲࡸ࠷࠸࠯ࡺࡰࡰࠬ෧"),fR68jBGWCzUsFXdlTKPOScugm(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠶࠿࠯ࡢࡦࡧࡳࡳࡹ࠱࠺࠰ࡻࡱࡱ࠭෨")]
			,EDPaWgMt1SwNn8o(u"࡙ࠬࡏࡖࡔࡆࡉࡘ࠭෩")		:[bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰࡭ࡲࡨ࡮࠭෪"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡷࡺࡸࡧࡦ࠰ࡶ࡬ࠬ෫"),Ej67fFyoqW8kbV2HdSK(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱ࠱ࡎࡓࡉࡏࡒࡆࡒࡒࠫ෬")]
			}
if PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠱ᔣ"):
	uReHcEzxkTm6pN4Q[wwyUWMFAsO(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ෭")] = [AAgpHN0nMZ(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ෮"),gSmqZU0plur2xKPJwQA(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ෯"),FhcnOB9t3frzvXb(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ෰"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ෱"),Ej67fFyoqW8kbV2HdSK(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫෲ"),AAgpHN0nMZ(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧෳ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ෴"),m6b7CoBk4EQ(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡧࡦࡶࡴࡤࡪࡤࠫ෵"),J3OCAmZVcn(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ෶"),kmdSKeBIwViM9t3(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵࡵ࡬ࡸࡪࡹࡵࡳ࡮ࡶࠫ෷")]
	uReHcEzxkTm6pN4Q[OVmSuf8tpd(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒࠪ෸")] = [pEo8g7riWVL014KaRtzQ(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ෹"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ෺"),XogUJZEijT7KWbxeO6(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭෻"),kmdSKeBIwViM9t3(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ෼"),xuYvdJpOEyQKTLNwb(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩ෽"),aVLSn1xw5cK(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ෾"),m6b7CoBk4EQ(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ෿"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡥࡤࡴࡹࡩࡨࡢࠩ฀"),ZSJVq5XDrRot(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪก"),c4QSTnPiWUCjhrLlwGB(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺࡳࡪࡶࡨࡷࡺࡸ࡬ࡴࠩข")]
else:
	uReHcEzxkTm6pN4Q[c4QSTnPiWUCjhrLlwGB(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪฃ")] = [JMLhEyaBWmskovGHTrVCxQ08(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧค"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫฅ"),pEo8g7riWVL014KaRtzQ(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪฆ"),gnfv8UtZ3daGqpjzk(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭ง"),Ej67fFyoqW8kbV2HdSK(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭จ"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩฉ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬช"),sArCMRngQNmXkBoKv(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭ซ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧฌ"),EDPaWgMt1SwNn8o(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡷ࡮ࡺࡥࡴࡷࡵࡰࡸ࠭ญ")]
	uReHcEzxkTm6pN4Q[fR68jBGWCzUsFXdlTKPOScugm(u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓࠫฎ")] = [pEo8g7riWVL014KaRtzQ(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫฏ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨฐ"),OVmSuf8tpd(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧฑ"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪฒ"),DLSVmlyBbCK(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪณ"),kmdSKeBIwViM9t3(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ด"),wwyUWMFAsO(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩต"),OVmSuf8tpd(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡦࡥࡵࡺࡣࡩࡣࠪถ"),XogUJZEijT7KWbxeO6(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡸࡪࡹࡴࡪࡰࡪࠫท"),kmdSKeBIwViM9t3(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡴ࡫ࡷࡩࡸࡻࡲ࡭ࡵࠪธ")]
Hhl2G8LRwq7 = [wwyUWMFAsO(u"ࠫࡑࡏࡓࡕࡒࡏࡅ࡞࠭น"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬࡘࡅࡑࡑࡕࡘࡘ࠭บ"),EDPaWgMt1SwNn8o(u"࠭ࡅࡎࡃࡌࡐࡘ࠭ป"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩผ"),pEo8g7riWVL014KaRtzQ(u"ࠨࡋࡖࡐࡆࡓࡉࡄࡕࠪฝ"),XogUJZEijT7KWbxeO6(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬพ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࡏࡓࡕࡗࡏࡇࡕࡖࡔࡘࡓࠨฟ"),wwyUWMFAsO(u"ࠫࡈࡇࡐࡕࡅࡋࡅࠬภ"),JMLhEyaBWmskovGHTrVCxQ08(u"࡚ࠬࡅࡔࡖࡌࡒࡌ࠭ม"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࡓࡊࡖࡈࡗ࡚ࡘࡌࡔࠩย")]
dRv1o5GDY4QV = [XogUJZEijT7KWbxeO6(u"ࠧࡂࡆࡇࡓࡓ࡙ࠧร"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠨࡃࡇࡈࡔࡔࡓ࠲࠺ࠪฤ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࡄࡈࡉࡕࡎࡔ࠳࠼ࠫล")]
class OL9QdnXpIeVN7S6K1yTgs4mqHRYbEt(ulKB5wvME2o):
	def __init__(Oxpg4wUz3fYLkVRu,*aargs,**kkwargs):
		Oxpg4wUz3fYLkVRu.choiceID = -J3OCAmZVcn(u"࠲ᔤ")
	def onClick(Oxpg4wUz3fYLkVRu,ZoIJWnq47bvDXMpF85Kcj3GyVfNR):
		if ZoIJWnq47bvDXMpF85Kcj3GyVfNR>=LmcNhzY6fQPd2JyCGslkSr(u"࠻࠳࠵࠵ᔥ"): Oxpg4wUz3fYLkVRu.choiceID = ZoIJWnq47bvDXMpF85Kcj3GyVfNR-LmcNhzY6fQPd2JyCGslkSr(u"࠻࠳࠵࠵ᔥ")
		Oxpg4wUz3fYLkVRu.xku4EXmFnU()
	def MzD6HuIloB95GqPXn(Oxpg4wUz3fYLkVRu,*aargs):
		Oxpg4wUz3fYLkVRu.button0,Oxpg4wUz3fYLkVRu.button1,Oxpg4wUz3fYLkVRu.button2 = aargs[xuYvdJpOEyQKTLNwb(u"࠴ᔧ")],aargs[XogUJZEijT7KWbxeO6(u"࠴ᔦ")],aargs[aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠷ᔨ")]
		Oxpg4wUz3fYLkVRu.header,Oxpg4wUz3fYLkVRu.text = aargs[LmcNhzY6fQPd2JyCGslkSr(u"࠹ᔩ")],aargs[wwyUWMFAsO(u"࠴ᔪ")]
		Oxpg4wUz3fYLkVRu.profile,Oxpg4wUz3fYLkVRu.direction = aargs[J3OCAmZVcn(u"࠶ᔫ")],aargs[LmcNhzY6fQPd2JyCGslkSr(u"࠸ᔬ")]
		Oxpg4wUz3fYLkVRu.buttonstimeout,Oxpg4wUz3fYLkVRu.closetimeout = aargs[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠻ᔮ")],aargs[XogUJZEijT7KWbxeO6(u"࠻ᔭ")]
		if Oxpg4wUz3fYLkVRu.buttonstimeout>bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠵ᔯ") or Oxpg4wUz3fYLkVRu.closetimeout>bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠵ᔯ"): Oxpg4wUz3fYLkVRu.enable_progressbar = ZSJVq5XDrRot(u"ࡗࡶࡺ࡫ជ")
		else: Oxpg4wUz3fYLkVRu.enable_progressbar = Ej67fFyoqW8kbV2HdSK(u"ࡊࡦࡲࡳࡦឈ")
		Oxpg4wUz3fYLkVRu.image_filename = HVZp3DNTCmeMA5lOBnWyI1dfvFqJzU.replace(JMLhEyaBWmskovGHTrVCxQ08(u"ࠪࡣ࠵࠶࠰࠱ࡡࠪฦ"),pEo8g7riWVL014KaRtzQ(u"ࠫࡤ࠭ว")+str(luMHeSgCBaPrb9KvUjNFqcR.time())+yTMWeCgUROcvtsblfK85L62xPk(u"ࠬࡥࠧศ"))
		Oxpg4wUz3fYLkVRu.image_filename = Oxpg4wUz3fYLkVRu.image_filename.replace(pEo8g7riWVL014KaRtzQ(u"࠭࡜࡝ࠩษ"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠧ࡝࡞࡟ࡠࠬส")).replace(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠨ࠱࠲ࠫห"),m6b7CoBk4EQ(u"ࠩ࠲࠳࠴࠵ࠧฬ"))
		Oxpg4wUz3fYLkVRu.image_height = MFGPCcLwzSV(Oxpg4wUz3fYLkVRu.button0,Oxpg4wUz3fYLkVRu.button1,Oxpg4wUz3fYLkVRu.button2,Oxpg4wUz3fYLkVRu.header,Oxpg4wUz3fYLkVRu.text,Oxpg4wUz3fYLkVRu.profile,Oxpg4wUz3fYLkVRu.direction,Oxpg4wUz3fYLkVRu.enable_progressbar,Oxpg4wUz3fYLkVRu.image_filename)
		Oxpg4wUz3fYLkVRu.show()
		Oxpg4wUz3fYLkVRu.getControl(eeIL1TfgFQJaKqVD8hGNPEZ(u"࠿࠰࠶࠲ᔰ")).setImage(Oxpg4wUz3fYLkVRu.image_filename)
		Oxpg4wUz3fYLkVRu.getControl(J3OCAmZVcn(u"࠹࠱࠷࠳ᔱ")).setHeight(Oxpg4wUz3fYLkVRu.image_height)
		if not Oxpg4wUz3fYLkVRu.button1 and Oxpg4wUz3fYLkVRu.button0 and Oxpg4wUz3fYLkVRu.button2: Oxpg4wUz3fYLkVRu.getControl(EDPaWgMt1SwNn8o(u"࠻࠳࠵࠷ᔳ")).setPosition(-m6b7CoBk4EQ(u"࠵࠶࠵ᔴ"),wwyUWMFAsO(u"࠱ᔲ"))
		return Oxpg4wUz3fYLkVRu.image_filename,Oxpg4wUz3fYLkVRu.image_height
	def tyAGuKJgzaOXrBfxFpn43e2b(Oxpg4wUz3fYLkVRu):
		if Oxpg4wUz3fYLkVRu.buttonstimeout:
			Oxpg4wUz3fYLkVRu.th1 = c3cgVjNv1rde.Thread(target=Oxpg4wUz3fYLkVRu.IHnxaQmgjWE78lvoJht3LeZV,args=())
			Oxpg4wUz3fYLkVRu.th1.start()
		else: Oxpg4wUz3fYLkVRu.RDCFgQJ9k5UBxdK0y()
	def IHnxaQmgjWE78lvoJht3LeZV(Oxpg4wUz3fYLkVRu):
		Oxpg4wUz3fYLkVRu.getControl(pEo8g7riWVL014KaRtzQ(u"࠽࠵࠸࠰ᔵ")).setEnabled(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࡙ࡸࡵࡦញ"))
		for OeT2Jo0sp6h1mGdqfFw in range(J3OCAmZVcn(u"࠶ᔶ"),Oxpg4wUz3fYLkVRu.buttonstimeout+J3OCAmZVcn(u"࠶ᔶ")):
			luMHeSgCBaPrb9KvUjNFqcR.sleep(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠷ᔷ"))
			GGCNdcbKF0R6 = int(fR68jBGWCzUsFXdlTKPOScugm(u"࠱࠱࠲ᔸ")*OeT2Jo0sp6h1mGdqfFw/Oxpg4wUz3fYLkVRu.buttonstimeout)
			Oxpg4wUz3fYLkVRu.HtV3D6gQC48BcAoPKFNRpEdwvx(GGCNdcbKF0R6)
			if Oxpg4wUz3fYLkVRu.choiceID>fR68jBGWCzUsFXdlTKPOScugm(u"࠱ᔹ"): break
		Oxpg4wUz3fYLkVRu.RDCFgQJ9k5UBxdK0y()
	def BoeEi3C7LtW1hK2zT8xXvdyNZ0kbm(Oxpg4wUz3fYLkVRu):
		if Oxpg4wUz3fYLkVRu.closetimeout:
			Oxpg4wUz3fYLkVRu.th2 = c3cgVjNv1rde.Thread(target=Oxpg4wUz3fYLkVRu.NdcHLIZmfpWQPVE0gJbYD,args=())
			Oxpg4wUz3fYLkVRu.th2.start()
		else: Oxpg4wUz3fYLkVRu.RDCFgQJ9k5UBxdK0y()
	def NdcHLIZmfpWQPVE0gJbYD(Oxpg4wUz3fYLkVRu):
		Oxpg4wUz3fYLkVRu.getControl(kmdSKeBIwViM9t3(u"࠻࠳࠶࠵ᔺ")).setEnabled(kmdSKeBIwViM9t3(u"࡚ࡲࡶࡧដ"))
		luMHeSgCBaPrb9KvUjNFqcR.sleep(Oxpg4wUz3fYLkVRu.buttonstimeout)
		for OeT2Jo0sp6h1mGdqfFw in range(Oxpg4wUz3fYLkVRu.closetimeout-xuYvdJpOEyQKTLNwb(u"࠴ᔻ"),-xuYvdJpOEyQKTLNwb(u"࠴ᔻ"),-xuYvdJpOEyQKTLNwb(u"࠴ᔻ")):
			luMHeSgCBaPrb9KvUjNFqcR.sleep(EDPaWgMt1SwNn8o(u"࠵ᔼ"))
			GGCNdcbKF0R6 = int(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠶࠶࠰ᔽ")*OeT2Jo0sp6h1mGdqfFw/Oxpg4wUz3fYLkVRu.closetimeout)
			Oxpg4wUz3fYLkVRu.HtV3D6gQC48BcAoPKFNRpEdwvx(GGCNdcbKF0R6)
			if Oxpg4wUz3fYLkVRu.choiceID>XogUJZEijT7KWbxeO6(u"࠶ᔾ"): break
		if Oxpg4wUz3fYLkVRu.closetimeout>yTMWeCgUROcvtsblfK85L62xPk(u"࠰ᔿ"): Oxpg4wUz3fYLkVRu.choiceID = kmdSKeBIwViM9t3(u"࠲࠲ᕀ")
		Oxpg4wUz3fYLkVRu.xku4EXmFnU()
	def HtV3D6gQC48BcAoPKFNRpEdwvx(Oxpg4wUz3fYLkVRu,GGCNdcbKF0R6):
		Oxpg4wUz3fYLkVRu.precent = GGCNdcbKF0R6
		Oxpg4wUz3fYLkVRu.getControl(kRYWcNuAazr4jtmBoxFVS19Z6(u"࠻࠳࠶࠵ᕁ")).setPercent(Oxpg4wUz3fYLkVRu.precent)
	def RDCFgQJ9k5UBxdK0y(Oxpg4wUz3fYLkVRu):
		if Oxpg4wUz3fYLkVRu.button0: Oxpg4wUz3fYLkVRu.getControl(m6b7CoBk4EQ(u"࠼࠴࠶࠶ᕂ")).setEnabled(EDPaWgMt1SwNn8o(u"ࡔࡳࡷࡨឋ"))
		if Oxpg4wUz3fYLkVRu.button1: Oxpg4wUz3fYLkVRu.getControl(kmdSKeBIwViM9t3(u"࠽࠵࠷࠱ᕃ")).setEnabled(wwyUWMFAsO(u"ࡕࡴࡸࡩឌ"))
		if Oxpg4wUz3fYLkVRu.button2: Oxpg4wUz3fYLkVRu.getControl(ZSJVq5XDrRot(u"࠾࠶࠱࠳ᕄ")).setEnabled(LmcNhzY6fQPd2JyCGslkSr(u"ࡖࡵࡹࡪឍ"))
	def xku4EXmFnU(Oxpg4wUz3fYLkVRu):
		Oxpg4wUz3fYLkVRu.close()
		try: hhHq8m5vauKG9dl.remove(Oxpg4wUz3fYLkVRu.image_filename)
		except: pass
class K7Mybc2p4irvPHQ1GaIhjXZ():
	def __init__(Oxpg4wUz3fYLkVRu,showDialogs=fR68jBGWCzUsFXdlTKPOScugm(u"ࡊࡦࡲࡳࡦត"),logErrors=eeIL1TfgFQJaKqVD8hGNPEZ(u"ࡗࡶࡺ࡫ណ")):
		Oxpg4wUz3fYLkVRu.showDialogs = showDialogs
		Oxpg4wUz3fYLkVRu.logErrors = logErrors
		Oxpg4wUz3fYLkVRu.finishedLIST,Oxpg4wUz3fYLkVRu.failedLIST = [],[]
		Oxpg4wUz3fYLkVRu.statusDICT,Oxpg4wUz3fYLkVRu.resultsDICT = {},{}
		Oxpg4wUz3fYLkVRu.processesLIST = []
		Oxpg4wUz3fYLkVRu.starttimeDICT,Oxpg4wUz3fYLkVRu.finishtimeDICT,Oxpg4wUz3fYLkVRu.elpasedtimeDICT = {},{},{}
	def JkOZNjX83SgnQaCqY(Oxpg4wUz3fYLkVRu,nTSFmel5UBt6bWh,c3O7xZvagUizTAG9jlQHJVPqNWE,*aargs):
		nTSFmel5UBt6bWh = str(nTSFmel5UBt6bWh)
		Oxpg4wUz3fYLkVRu.statusDICT[nTSFmel5UBt6bWh] = bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪࡶࡺࡴ࡮ࡪࡰࡪࠫอ")
		if Oxpg4wUz3fYLkVRu.showDialogs: NLVM3HAtxQOSvJf6kd78K1o(sArCMRngQNmXkBoKv(u"ࠫࠬฮ"),nTSFmel5UBt6bWh)
		tvzC6pjwDiN1gUSEJmfVyOq = c3cgVjNv1rde.Thread(target=Oxpg4wUz3fYLkVRu.VSUxCQ1bME8Zjv,args=(nTSFmel5UBt6bWh,c3O7xZvagUizTAG9jlQHJVPqNWE,aargs))
		Oxpg4wUz3fYLkVRu.processesLIST.append(tvzC6pjwDiN1gUSEJmfVyOq)
		return tvzC6pjwDiN1gUSEJmfVyOq
	def qDZujpko1NmiSc60L9RIQUgF(Oxpg4wUz3fYLkVRu,nTSFmel5UBt6bWh,c3O7xZvagUizTAG9jlQHJVPqNWE,*aargs):
		tvzC6pjwDiN1gUSEJmfVyOq = Oxpg4wUz3fYLkVRu.JkOZNjX83SgnQaCqY(nTSFmel5UBt6bWh,c3O7xZvagUizTAG9jlQHJVPqNWE,*aargs)
		tvzC6pjwDiN1gUSEJmfVyOq.start()
	def VSUxCQ1bME8Zjv(Oxpg4wUz3fYLkVRu,nTSFmel5UBt6bWh,c3O7xZvagUizTAG9jlQHJVPqNWE,aargs):
		nTSFmel5UBt6bWh = str(nTSFmel5UBt6bWh)
		Oxpg4wUz3fYLkVRu.starttimeDICT[nTSFmel5UBt6bWh] = luMHeSgCBaPrb9KvUjNFqcR.time()
		try:
			Oxpg4wUz3fYLkVRu.resultsDICT[nTSFmel5UBt6bWh] = c3O7xZvagUizTAG9jlQHJVPqNWE(*aargs)
			if pEo8g7riWVL014KaRtzQ(u"ࠬࡕࡐࡆࡐࡘࡖࡑ࠭ฯ") in str(c3O7xZvagUizTAG9jlQHJVPqNWE) and not Oxpg4wUz3fYLkVRu.resultsDICT[nTSFmel5UBt6bWh].succeeded:
				iiysxZ8dOaA(Ej67fFyoqW8kbV2HdSK(u"࠭ࡆࡰࡴࡦࡩࡩࠦࡥࡹ࡫ࡷࠤࡩࡻࡥࠡࡶࡲࠤࡹ࡮ࡲࡦࡣࡧࡩࡩࠦࡏࡑࡇࡑ࡙ࡗࡒࠠࡧࡣ࡬ࡰࠬะ"))
			Oxpg4wUz3fYLkVRu.finishedLIST.append(nTSFmel5UBt6bWh)
			Oxpg4wUz3fYLkVRu.statusDICT[nTSFmel5UBt6bWh] = sArCMRngQNmXkBoKv(u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࠩั")
		except Exception as jD36UfMuAv9TqxZeVFlm75WynYk:
			if Oxpg4wUz3fYLkVRu.logErrors:
				m0AGWhywZVXFtYQ = QQV1pDhCLqHP5a3sGvoUrJfmjXFw.format_exc()
				if m0AGWhywZVXFtYQ!=kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨࡐࡲࡲࡪ࡚ࡹࡱࡧ࠽ࠤࡓࡵ࡮ࡦ࡞ࡱࠫา"): ddABnr3K9Xv8e71CzcN0Pxt.stderr.write(m0AGWhywZVXFtYQ)
			Oxpg4wUz3fYLkVRu.failedLIST.append(nTSFmel5UBt6bWh)
			Oxpg4wUz3fYLkVRu.statusDICT[nTSFmel5UBt6bWh] = xuYvdJpOEyQKTLNwb(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩำ")
		Oxpg4wUz3fYLkVRu.finishtimeDICT[nTSFmel5UBt6bWh] = luMHeSgCBaPrb9KvUjNFqcR.time()
		Oxpg4wUz3fYLkVRu.elpasedtimeDICT[nTSFmel5UBt6bWh] = Oxpg4wUz3fYLkVRu.finishtimeDICT[nTSFmel5UBt6bWh] - Oxpg4wUz3fYLkVRu.starttimeDICT[nTSFmel5UBt6bWh]
	def wsYEa9Je6L4gPSjpWHK(Oxpg4wUz3fYLkVRu):
		for yEMOPV50Znt1JU4X7lLqkvAuh8Y2T in Oxpg4wUz3fYLkVRu.processesLIST:
			yEMOPV50Znt1JU4X7lLqkvAuh8Y2T.start()
	def kQ5exrifztCSnIoUKs8G3WAOa6EM(Oxpg4wUz3fYLkVRu):
		while EDPaWgMt1SwNn8o(u"ࠪࡶࡺࡴ࡮ࡪࡰࡪࠫิ") in list(Oxpg4wUz3fYLkVRu.statusDICT.values()): luMHeSgCBaPrb9KvUjNFqcR.sleep(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠷ᕅ"))
def gaZEYqIoUjF643VmRu():
	if not nc1u5UZAtX2WNO4aJMmbg: return hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫࡓࡕ࡟ࡖࡒࡇࡅ࡙ࡋࠧี")
	try: hhHq8m5vauKG9dl.makedirs(mATvU6VbxOXNFhz8lK5WGrfQ)
	except: pass
	WlgC4QPY8ZoLfOATkya = wwyUWMFAsO(u"ࠬࡌࡕࡍࡎࡢ࡙ࡕࡊࡁࡕࡇࠪึ")
	SKLd1zfIuJBxyORZiqbl4sg8UHwND = [PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭࠸࠯࠷࠱࠴ࠬื"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧ࠳࠲࠵࠵࠳࠷࠰࠯࠳࠼ุࠫ"),gSmqZU0plur2xKPJwQA(u"ࠨ࠴࠳࠶࠶࠴࠱࠲࠰࠵࠸ࡦู࠭"),pEo8g7riWVL014KaRtzQ(u"ࠩ࠵࠴࠷࠷࠮࠲࠴࠱࠷࠵ฺ࠭"),DLSVmlyBbCK(u"ࠪ࠶࠵࠸࠲࠯࠲࠵࠲࠵࠸ࠧ฻"),ZSJVq5XDrRot(u"ࠫ࠷࠶࠲࠳࠰࠴࠴࠳࠸࠲ࠨ฼"),kmdSKeBIwViM9t3(u"ࠬ࠸࠰࠳࠵࠱࠴࠸࠴࠰࠷ࠩ฽"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠭࠲࠱࠴࠶࠲࠵࠻࠮࠲࠸ࠪ฾"),AAgpHN0nMZ(u"ࠧ࠳࠲࠵࠷࠳࠶࠶࠯࠲࠹ࠫ฿"),Ej67fFyoqW8kbV2HdSK(u"ࠨ࠴࠳࠶࠸࠴࠱࠱࠰࠵࠼ࠬเ"),LmcNhzY6fQPd2JyCGslkSr(u"ࠩ࠵࠴࠷࠺࠮࠱࠳࠱࠵࠹࠭แ")]
	aarbJLPEWw8XG9V5kMSvl = SKLd1zfIuJBxyORZiqbl4sg8UHwND[-LmcNhzY6fQPd2JyCGslkSr(u"࠱ᕆ")]
	ZZYt6aTuxIL0Bf = XaDMQjxwWpr9ykI2(aarbJLPEWw8XG9V5kMSvl)
	QQiBNbPTu2A7CR3eftXxIzclOGmrso = XaDMQjxwWpr9ykI2(i69DxzEZSwmuY5Il)
	if QQiBNbPTu2A7CR3eftXxIzclOGmrso>ZZYt6aTuxIL0Bf:
		WlgC4QPY8ZoLfOATkya = J3OCAmZVcn(u"ࠪࡗࡎࡓࡐࡍࡇࡢ࡙ࡕࡊࡁࡕࡇࠪโ")
	return WlgC4QPY8ZoLfOATkya
def R6UJn7qs9E1aDeWhld8Iz():
	if sArCMRngQNmXkBoKv(u"࠲ᕇ"):
		f42fXbxnw1Ei8tY6IOcsDZ0uykov = J3OCAmZVcn(u"࠲ᕈ")
		for Wc2Cz7h3LlwfYMDPteNasGdZ4IXok5,P8CTpdirwzO5ZFRGfoJV93k1Xqy,NN0VnHzeD4flhcFUot in hhHq8m5vauKG9dl.walk(Po8NVKEkyc30eCS,topdown=eeIL1TfgFQJaKqVD8hGNPEZ(u"ࡋࡧ࡬ࡴࡧថ")):
			f42fXbxnw1Ei8tY6IOcsDZ0uykov += len(NN0VnHzeD4flhcFUot)
	if f42fXbxnw1Ei8tY6IOcsDZ0uykov>xuYvdJpOEyQKTLNwb(u"࠸࠴࠵࠶ᕉ"): Eux3w7MylkQfiBa6pvJO0FWTNbr(Po8NVKEkyc30eCS,gSmqZU0plur2xKPJwQA(u"ࡔࡳࡷࡨធ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࡌࡡ࡭ࡵࡨទ"))
	return
AA58pW4UfMiI9B2avFZ3YrsoeQ = hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࡇࡣ࡯ࡷࡪន")
def VZotrchyP5ez4psFq8QGjbUIYO9dE(nnF1VOMIkrqi2ojXux6UPHGyEf7Kg):
	global uReHcEzxkTm6pN4Q,AA58pW4UfMiI9B2avFZ3YrsoeQ
	if not nnF1VOMIkrqi2ojXux6UPHGyEf7Kg:
		yqZ1Xlrxw76agAzML = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠫࡩ࡯ࡣࡵࠩใ"),c4QSTnPiWUCjhrLlwGB(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨไ"),m6b7CoBk4EQ(u"࠭ࡓࡊࡖࡈࡗ࡚ࡘࡌࡔࠩๅ"))
		if yqZ1Xlrxw76agAzML:
			uReHcEzxkTm6pN4Q = yqZ1Xlrxw76agAzML.copy()
			return
	if not AA58pW4UfMiI9B2avFZ3YrsoeQ:
		XpOsU3v5dqH8MQAK6FcafmP1z0kL2 = uReHcEzxkTm6pN4Q[c4QSTnPiWUCjhrLlwGB(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧๆ")][EDPaWgMt1SwNn8o(u"࠽ᕊ")]
		hhC9JITqv3yWEGFm = HHWAnGJrb9powOqTkYgcPQ6Ef(DLSVmlyBbCK(u"࠸࠸ᕋ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࡖࡵࡹࡪប"))
		QnIsrBC7Wc3tOSXbGJp8l = {MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨࡷࡶࡩࡷ࠭็"):hhC9JITqv3yWEGFm,J3OCAmZVcn(u"ࠩࡹࡩࡷࡹࡩࡰࡰ่ࠪ"):i69DxzEZSwmuY5Il}
		wvdJxFK9nk = A6F71g3cqN4(KxirmCLT6Gw,aVLSn1xw5cK(u"ࠪࡔࡔ࡙ࡔࠨ้"),XpOsU3v5dqH8MQAK6FcafmP1z0kL2,QnIsrBC7Wc3tOSXbGJp8l,yTMWeCgUROcvtsblfK85L62xPk(u"๊ࠫࠬ"),xuYvdJpOEyQKTLNwb(u"๋ࠬ࠭"),ZSJVq5XDrRot(u"࠭ࠧ์"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡗࡓࡈࡆ࡚ࡅࡠࡕࡌࡘࡊ࡙ࡕࡓࡎࡖ࠱࠶ࡹࡴࠨํ"))
		if wvdJxFK9nk.succeeded:
			global NEW_SITESURLS
			exec(wvdJxFK9nk.content,globals(),locals())
			uReHcEzxkTm6pN4Q.update(NEW_SITESURLS)
			Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ๎"),XogUJZEijT7KWbxeO6(u"ࠩࡖࡍ࡙ࡋࡓࡖࡔࡏࡗࠬ๏"),uReHcEzxkTm6pN4Q,iKYM8NdkGHmBcr)
			AA58pW4UfMiI9B2avFZ3YrsoeQ = ZSJVq5XDrRot(u"ࡗࡶࡺ࡫ផ")
	return
def CVWiQUeASg():
	wfzYAN8iHTQmer1DKLEWZ6qU3 = gaZEYqIoUjF643VmRu()
	HHTzVhiY079bvdluNkFQ4wCMpe(wwyUWMFAsO(u"ࠪࠫ๐"),wwyUWMFAsO(u"ࠫࠬ๑"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ๒"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠭สๆࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣๅ๏ࠦฬ่ษี็ࡡࡴลๅ๋ࠣห้หีะษิࠤึ่ๅ࠻࡞ࡱࡠࡳ࠭๓")+i69DxzEZSwmuY5Il)
	ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,wwyUWMFAsO(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ๔"),gnfv8UtZ3daGqpjzk(u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫ๕"))
	ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,c4QSTnPiWUCjhrLlwGB(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ๖"),FhcnOB9t3frzvXb(u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫ๗"))
	ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,FhcnOB9t3frzvXb(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ๘"),xuYvdJpOEyQKTLNwb(u"࡙ࠬࡉࡕࡇࡖࡣࡓࡇࡍࡆࡕࠪ๙"))
	ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ๚"),LmcNhzY6fQPd2JyCGslkSr(u"ࠧࡔࡋࡗࡉࡘࡥࡃࡉࡇࡆࡏࠬ๛"))
	ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,gnfv8UtZ3daGqpjzk(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ๜"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࡖࡍ࡙ࡋࡓࡠࡘࡈࡖࡎࡌ࡙ࠨ๝"))
	j2agIU0xsLS6c7T.setSetting(kmdSKeBIwViM9t3(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲࡫ࡵࡳࡵࡣࠪ๞"),OVmSuf8tpd(u"ࠫࠬ๟"))
	j2agIU0xsLS6c7T.setSetting(EDPaWgMt1SwNn8o(u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࡦࡢࡤࡵࡥࡰࡧࠧ๠"),AAgpHN0nMZ(u"࠭ࠧ๡"))
	j2agIU0xsLS6c7T.setSetting(EDPaWgMt1SwNn8o(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪ๢"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨࠩ๣"))
	j2agIU0xsLS6c7T.setSetting(xuYvdJpOEyQKTLNwb(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡪࡦࡹࡥ࡭ࡪࡧ࠵ࠬ๤"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࠫ๥"))
	j2agIU0xsLS6c7T.setSetting(ZSJVq5XDrRot(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠷ࠧ๦"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬ࠭๧"))
	j2agIU0xsLS6c7T.setSetting(XogUJZEijT7KWbxeO6(u"࠭ࡡࡷ࠰ࡳࡶ࡮ࡼࡳ࠳ࠩ๨"),OVmSuf8tpd(u"ࠧࠨ๩"))
	j2agIU0xsLS6c7T.setSetting(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠨࡣࡹ࠲ࡵ࡫ࡲࡪࡱࡧ࠲࡮ࡴࡦࡰࡵࠪ๪"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩࠪ๫"))
	j2agIU0xsLS6c7T.setSetting(gSmqZU0plur2xKPJwQA(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰࡯ࡳࡳ࡭ࠧ๬"),aVLSn1xw5cK(u"ࠫࠬ๭"))
	j2agIU0xsLS6c7T.setSetting(J3OCAmZVcn(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡷ࡫ࡧࡶ࡮ࡤࡶࠬ๮"),Ej67fFyoqW8kbV2HdSK(u"࠭ࠧ๯"))
	j2agIU0xsLS6c7T.setSetting(yTMWeCgUROcvtsblfK85L62xPk(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ๰"),OVmSuf8tpd(u"ࠨࠩ๱"))
	j2agIU0xsLS6c7T.setSetting(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ๲"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠪࠫ๳"))
	j2agIU0xsLS6c7T.setSetting(kmdSKeBIwViM9t3(u"ࠫࡦࡼ࠮ࡧࡣ࡬ࡰࡪࡪ࠮ࡴࡥࡤࡶࡵ࡫ࡰࡳࡱࡻࡽ࠶࠭๴"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬ࠭๵"))
	j2agIU0xsLS6c7T.setSetting(bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࡡࡷ࠰ࡩࡥ࡮ࡲࡥࡥ࠰ࡶࡧࡦࡸࡰࡦࡲࡵࡳࡽࡿ࠲ࠨ๶"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧࠨ๷"))
	j2agIU0xsLS6c7T.setSetting(pEo8g7riWVL014KaRtzQ(u"ࠨࡣࡹ࠲࡫ࡧࡩ࡭ࡧࡧ࠲ࡸࡩࡡࡳࡲࡨࡴࡷࡵࡸࡺ࠵ࠪ๸"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࠪ๹"))
	j2agIU0xsLS6c7T.setSetting(Ej67fFyoqW8kbV2HdSK(u"ࠪࡥࡻ࠴ࡦࡢ࡫࡯ࡩࡩ࠴ࡳࡤࡣࡵࡴࡪࡶࡲࡰࡺࡼ࠸ࠬ๺"),XogUJZEijT7KWbxeO6(u"ࠫࠬ๻"))
	import bYGAkzJECs
	if wfzYAN8iHTQmer1DKLEWZ6qU3==jYaM5vilgZdFx6QHbApwVXO8et(u"࡙ࠬࡉࡎࡒࡏࡉࡤ࡛ࡐࡅࡃࡗࡉࠬ๼"):
		tr24ZoudmqvxfYCw(wwyUWMFAsO(u"࠭ࡎࡐࡖࡌࡇࡊ࠭๽"),Ej67fFyoqW8kbV2HdSK(u"ࠧ࠯ࠢࠣࡅࡷࡧࡢࡪࡥ࡙࡭ࡩ࡫࡯ࡴࠢࡘࡴࡩࡧࡴࡦࠢࡗࡽࡵ࡫࠺ࠡࠢࡖࡍࡒࡖࡌࡆࠢࡘࡔࡉࡇࡔࡆࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭๾")+VPIEsaiROZwmp20Jdn8WrA7c3Y+hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠨࠢࡠࠫ๿"))
		ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,DLSVmlyBbCK(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡘࡏࡔࡆࡕࠪ຀"))
		ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,XogUJZEijT7KWbxeO6(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࠪກ"))
		ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,fR68jBGWCzUsFXdlTKPOScugm(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࠪຂ"))
		yyGtPJnrR67K(pEo8g7riWVL014KaRtzQ(u"ࡘࡷࡻࡥព"),[hosgCj2byWvuVT])
	else:
		tr24ZoudmqvxfYCw(JMLhEyaBWmskovGHTrVCxQ08(u"ࠬࡔࡏࡕࡋࡆࡉࠬ຃"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭࠮ࠡࠢࡄࡶࡦࡨࡩࡤࡘ࡬ࡨࡪࡵࡳࠡࡗࡳࡨࡦࡺࡥࠡࡖࡼࡴࡪࡀࠠࠡࡈࡘࡐࡑࠦࡕࡑࡆࡄࡘࡊࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪຄ")+VPIEsaiROZwmp20Jdn8WrA7c3Y+Ej67fFyoqW8kbV2HdSK(u"ࠧࠡ࡟ࠪ຅"))
		HHTzVhiY079bvdluNkFQ4wCMpe(LmcNhzY6fQPd2JyCGslkSr(u"ࠨࠩຆ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩࠪງ"),sArCMRngQNmXkBoKv(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ຈ"),aVLSn1xw5cK(u"ࠫฯ๋ࠠหอห๎ฯࠦร้ࠢอัิ๐หࠡษ็ษฺีวาࠢส่ัี๊ะࠢ็ฬึ์วๆฮࠣห้็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠡ࠰ࠣวํࠦสๆ่ࠢืาࠦใศึࠣห้ฮั็ษ่ะࠥࡢ࡮࡝ࡰࠣื๏่่ๆࠢส่ว์ࠠศๆหี๋อๅอࠢหฬ฾฼ࠠศๆไัํ฻วหࠢ็ฺ๊อๆࠡ฻่่ࠥอไษำ้ห๊าࠠษื๋ีฮࠦีฮ์ะอࠥ๎ๅหๅส้้ฯࠧຉ"))
		yyGtPJnrR67K(DLSVmlyBbCK(u"ࡋࡧ࡬ࡴࡧភ"),[])
		MCAInGyaz6mZwUx4gjqBb(fR68jBGWCzUsFXdlTKPOScugm(u"ࡌࡡ࡭ࡵࡨម"))
		bYGAkzJECs.hEuK6GmSYZURWgdLwy25b()
		bYGAkzJECs.tTsLa8vMRzfgoVxdwkeW0DXCpKbPn(fR68jBGWCzUsFXdlTKPOScugm(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬຊ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࡆࡢ࡮ࡶࡩយ"))
		bYGAkzJECs.tTsLa8vMRzfgoVxdwkeW0DXCpKbPn(gSmqZU0plur2xKPJwQA(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡷࡺ࡭ࡱࠩ຋"),Ej67fFyoqW8kbV2HdSK(u"ࡇࡣ࡯ࡷࡪរ"))
		bYGAkzJECs.kOriw8l9X0sLv6M7AQqGH1WYo(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࡈࡤࡰࡸ࡫ល"))
		bYGAkzJECs.ZOIbNiQGafpXCxh3E1w4ulsD9my(XogUJZEijT7KWbxeO6(u"ࡉࡥࡱࡹࡥវ"))
		bYGAkzJECs.Wjht89D0l2OpN4Rm6HoP7Z(fR68jBGWCzUsFXdlTKPOScugm(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬຌ"),c4QSTnPiWUCjhrLlwGB(u"ࠨࡧࡱࡥࡧࡲࡥࠨຍ"),m6b7CoBk4EQ(u"ࡊࡦࡲࡳࡦឝ"))
		try:
			kkEVyRYFpfO0qjcdrguA = hhHq8m5vauKG9dl.path.join(D2DYfsvFSG5CnV,OVmSuf8tpd(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫຎ"),EDPaWgMt1SwNn8o(u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧຏ"),kmdSKeBIwViM9t3(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡷ࡫ࡳࡰ࡮ࡹࡩࡺࡸ࡬ࠨຐ"),OVmSuf8tpd(u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫຑ"))
			fV1YjoKR67vLW2b4c0adgNyTZDz3p = A2AXwrPWdJ3V4958K.Addon(id=PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪຒ"))
			fV1YjoKR67vLW2b4c0adgNyTZDz3p.setSetting(DLSVmlyBbCK(u"ࠧࡢࡸ࠱ࡥࡺࡺ࡯ࡠࡲ࡬ࡧࡰ࠭ຓ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨࡨࡤࡰࡸ࡫ࠧດ"))
		except: pass
		try:
			kkEVyRYFpfO0qjcdrguA = hhHq8m5vauKG9dl.path.join(D2DYfsvFSG5CnV,yTMWeCgUROcvtsblfK85L62xPk(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫຕ"),pEo8g7riWVL014KaRtzQ(u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧຖ"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡾࡺ࠭ࡥ࡮ࡳࠫທ"),fR68jBGWCzUsFXdlTKPOScugm(u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫຘ"))
			fV1YjoKR67vLW2b4c0adgNyTZDz3p = A2AXwrPWdJ3V4958K.Addon(id=kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡵ࠯ࡧࡰࡵ࠭ນ"))
			fV1YjoKR67vLW2b4c0adgNyTZDz3p.setSetting(kmdSKeBIwViM9t3(u"ࠧࡢࡸ࠱ࡺ࡮ࡪࡥࡰࡡࡴࡹࡦࡲࡩࡵࡻࠪບ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨ࠵ࠪປ"))
		except: pass
		try:
			kkEVyRYFpfO0qjcdrguA = hhHq8m5vauKG9dl.path.join(D2DYfsvFSG5CnV,kmdSKeBIwViM9t3(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫຜ"),J3OCAmZVcn(u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧຝ"),ZSJVq5XDrRot(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫພ"),FhcnOB9t3frzvXb(u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫຟ"))
			fV1YjoKR67vLW2b4c0adgNyTZDz3p = A2AXwrPWdJ3V4958K.Addon(id=AAgpHN0nMZ(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭ຠ"))
			fV1YjoKR67vLW2b4c0adgNyTZDz3p.setSetting(yTMWeCgUROcvtsblfK85L62xPk(u"ࠧࡢࡸ࠱ࡗ࡙ࡘࡅࡂࡏࡖࡉࡑࡋࡃࡕࡋࡒࡒࠬມ"),LmcNhzY6fQPd2JyCGslkSr(u"ࠨ࠴ࠪຢ"))
		except: pass
	SOlDApJEx73FokmVdYCfKuRNXy8 = KJM5ELV47wTIWg(ryc0LEzgSbaI7NqvwJ)
	SOlDApJEx73FokmVdYCfKuRNXy8 = KJM5ELV47wTIWg(P71CANTSyWYptGs8JnZkUHu3Kwi6Ql)
	j2agIU0xsLS6c7T.setSetting(XogUJZEijT7KWbxeO6(u"ࠩࡤࡺ࠳ࡼࡥࡳࡵ࡬ࡳࡳ࠭ຣ"),i69DxzEZSwmuY5Il)
	bYGAkzJECs.CJAc6jFdGkqfUKxPTQ2ItSBX(gnfv8UtZ3daGqpjzk(u"ࡋࡧ࡬ࡴࡧឞ"))
	iiysxZ8dOaA(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠪࡉࡽ࡯ࡴࠡࡶࡲࠤࡦࡶࡰ࡭ࡻࠣࡸ࡭࡫ࠠ࡯ࡧࡺࠤࡷ࡫࡬ࡦࡣࡶࡩࠬ຤"))
	return
def Q8RtwXp7ioDUqbW9HjKgYlP():
	FIXmBE83KVSwYOZo = j2agIU0xsLS6c7T.getSetting(aVLSn1xw5cK(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡷ࡭ࡵࡲࡵࠩລ"))
	FIXmBE83KVSwYOZo = Ej67fFyoqW8kbV2HdSK(u"࠶ᕌ") if not FIXmBE83KVSwYOZo else int(FIXmBE83KVSwYOZo)
	if not FIXmBE83KVSwYOZo or not fR68jBGWCzUsFXdlTKPOScugm(u"࠰ᕍ")<=F5I1VZzxkXenKuEAYO-FIXmBE83KVSwYOZo<=dALVaOWB4jKN3Tbt0Cm1ns9k5u:
		j2agIU0xsLS6c7T.setSetting(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡸ࡮࡯ࡳࡶࠪ຦"),str(F5I1VZzxkXenKuEAYO))
		UAyxKVL2kthjd(KxirmCLT6Gw)
		zG5qDbfyv3udW4B0LEt2 = j2agIU0xsLS6c7T.getSetting(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡸࡥࡨࡷ࡯ࡥࡷ࠭ວ"))
		zG5qDbfyv3udW4B0LEt2 = kRYWcNuAazr4jtmBoxFVS19Z6(u"࠱ᕎ") if not zG5qDbfyv3udW4B0LEt2 else int(zG5qDbfyv3udW4B0LEt2)
		if not zG5qDbfyv3udW4B0LEt2 or not wwyUWMFAsO(u"࠲ᕏ")<=F5I1VZzxkXenKuEAYO-zG5qDbfyv3udW4B0LEt2<=Z7uFdWIRv9ybj0:
			j2agIU0xsLS6c7T.setSetting(fR68jBGWCzUsFXdlTKPOScugm(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡲࡦࡩࡸࡰࡦࡸࠧຨ"),str(F5I1VZzxkXenKuEAYO))
			VZotrchyP5ez4psFq8QGjbUIYO9dE(wwyUWMFAsO(u"࡚ࡲࡶࡧស"))
			tvzC6pjwDiN1gUSEJmfVyOq = c3cgVjNv1rde.Thread(target=R6UJn7qs9E1aDeWhld8Iz)
			tvzC6pjwDiN1gUSEJmfVyOq.start()
		zzkFhraG02B7ysSoN = j2agIU0xsLS6c7T.getSetting(FhcnOB9t3frzvXb(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡭ࡱࡱ࡫ࠬຩ"))
		zzkFhraG02B7ysSoN = DLSVmlyBbCK(u"࠳ᕐ") if not zzkFhraG02B7ysSoN else int(zzkFhraG02B7ysSoN)
		if not zzkFhraG02B7ysSoN or not JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠴ᕑ")<=F5I1VZzxkXenKuEAYO-zzkFhraG02B7ysSoN<=JNsoWV1CXc4xy:
			j2agIU0xsLS6c7T.setSetting(pEo8g7riWVL014KaRtzQ(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡮ࡲࡲ࡬࠭ສ"),str(F5I1VZzxkXenKuEAYO))
			import bYGAkzJECs
			bYGAkzJECs.LLMXenCcYZHSN4OKzy9R(AAgpHN0nMZ(u"ࡇࡣ࡯ࡷࡪឡ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࡔࡳࡷࡨហ"))
	iZs0cGd2n8rtpMgJ34vwSNm = SeN2UjVuMw6K03nrgWZLOYB5la7mpA(j2agIU0xsLS6c7T.getSetting(yTMWeCgUROcvtsblfK85L62xPk(u"ࠪࡥࡻ࠴ࡰࡦࡴ࡬ࡳࡩ࠴ࡩ࡯ࡨࡲࡷࠬຫ")))
	iZs0cGd2n8rtpMgJ34vwSNm = ZSJVq5XDrRot(u"࠵ᕒ") if not iZs0cGd2n8rtpMgJ34vwSNm else int(iZs0cGd2n8rtpMgJ34vwSNm)
	yxWIgR6LFok8eQiu = SeN2UjVuMw6K03nrgWZLOYB5la7mpA(j2agIU0xsLS6c7T.getSetting(AAgpHN0nMZ(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ຬ")))
	yxWIgR6LFok8eQiu = EDPaWgMt1SwNn8o(u"࠶ᕓ") if not yxWIgR6LFok8eQiu else int(yxWIgR6LFok8eQiu)
	if not iZs0cGd2n8rtpMgJ34vwSNm or not yxWIgR6LFok8eQiu or not gSmqZU0plur2xKPJwQA(u"࠰ᕔ")<=F5I1VZzxkXenKuEAYO-yxWIgR6LFok8eQiu<=iZs0cGd2n8rtpMgJ34vwSNm:
		uuVpFB8aTS = LmcNhzY6fQPd2JyCGslkSr(u"࠲ᕕ")
		KKhYzNW98JxMdD = Ej67fFyoqW8kbV2HdSK(u"ࡉࡥࡱࡹࡥឣ") if ynO4oHRV3Mj6Z9gNh(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠬࡕࡔ࠲࠻ࡍ࡙࠵ࡾࡂࡕࡗ࡯ࡈ࡝࠭ອ")) else aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࡖࡵࡹࡪអ")
		if KKhYzNW98JxMdD:
			EC5XwtROefg9UNdSvQ = KLSU61gP7bs5QBrp(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࡘࡷࡻࡥឤ"))
			if len(EC5XwtROefg9UNdSvQ)>JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠳ᕖ"):
				tr24ZoudmqvxfYCw(pEo8g7riWVL014KaRtzQ(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ຮ"),kmdSKeBIwViM9t3(u"ࠧ࠯ࠢࠣࡗ࡭ࡵࡷࡪࡰࡪࠤࡖࡻࡥࡴࡶ࡬ࡳࡳࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪຯ")+VPIEsaiROZwmp20Jdn8WrA7c3Y+EDPaWgMt1SwNn8o(u"ࠨࠢࡠࠫະ"))
				nTSFmel5UBt6bWh,hhC9JITqv3yWEGFm,X3OBj9hFudG,xOV4lRWI2Ak37E,kwRd5A8WqiVBQ4cxf0rNPbC7XaSUF2,X75jhUrfuFIJW82GYmbp = EC5XwtROefg9UNdSvQ[ZSJVq5XDrRot(u"࠳ᕗ")]
				YPINwkvUA9arTds6y,zzuOx8f13Np = xOV4lRWI2Ak37E.split(gnfv8UtZ3daGqpjzk(u"ࠩ࡟ࡲࡀࡁࠧັ"))
				del EC5XwtROefg9UNdSvQ[wwyUWMFAsO(u"࠴ᕘ")]
				LNxMafI0bV = bnPo1W52UVMRs7Lw6kfG9QdO.sample(EC5XwtROefg9UNdSvQ,gnfv8UtZ3daGqpjzk(u"࠶ᕙ"))
				nTSFmel5UBt6bWh,hhC9JITqv3yWEGFm,X3OBj9hFudG,xOV4lRWI2Ak37E,kwRd5A8WqiVBQ4cxf0rNPbC7XaSUF2,X75jhUrfuFIJW82GYmbp = LNxMafI0bV[aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠶ᕚ")]
				X3OBj9hFudG = Ej67fFyoqW8kbV2HdSK(u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠤ࠿ࠦࠧາ")+nTSFmel5UBt6bWh+gnfv8UtZ3daGqpjzk(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ຳ")+X3OBj9hFudG
				kwRd5A8WqiVBQ4cxf0rNPbC7XaSUF2 = c4QSTnPiWUCjhrLlwGB(u"ࠬหัิษ็ࠤึูวๅห่้๋ࠣศา็ฯࠫິ")
				VVaGyg2580cfE = ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭วๅฬหี฾อสࠨີ")
				button0,button1 = xOV4lRWI2Ak37E,kwRd5A8WqiVBQ4cxf0rNPbC7XaSUF2
				YdIJ2BMWuebmqg5DNsZE = [button0,button1,VVaGyg2580cfE]
				DQYkjzFm49EewgbKoqZs2C = ZSJVq5XDrRot(u"࠱ᕛ") if ynO4oHRV3Mj6Z9gNh(ZSJVq5XDrRot(u"ࠧࡘࡕࡘࡖࡋ࡚࠱࠺ࡓࡗࡉࡋࡠࡘࠨຶ")) else AAgpHN0nMZ(u"࠲࠲ᕜ")
				HBJbZpwN23hveudOrcI68W0M = -gSmqZU0plur2xKPJwQA(u"࠻ᕝ")
				while HBJbZpwN23hveudOrcI68W0M<m6b7CoBk4EQ(u"࠳ᕞ"):
					hlaI9ze7D3bGwxRO = bnPo1W52UVMRs7Lw6kfG9QdO.sample(YdIJ2BMWuebmqg5DNsZE,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠷ᕟ"))
					HBJbZpwN23hveudOrcI68W0M = A0iaw7hK4Qmc2EeHXZB(Ej67fFyoqW8kbV2HdSK(u"ࠨࠩື"),hlaI9ze7D3bGwxRO[hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠶ᕡ")],hlaI9ze7D3bGwxRO[Ej67fFyoqW8kbV2HdSK(u"࠶ᕠ")],hlaI9ze7D3bGwxRO[aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠲ᕢ")],YPINwkvUA9arTds6y,X3OBj9hFudG,wwyUWMFAsO(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷຸࠫ"),DQYkjzFm49EewgbKoqZs2C,DLSVmlyBbCK(u"࠷࠲ᕣ"))
					if HBJbZpwN23hveudOrcI68W0M==XogUJZEijT7KWbxeO6(u"࠳࠳ᕤ"): break
					from bYGAkzJECs import HvcsiXhFR9Dw1,TlD1doFipMsk0y
					if HBJbZpwN23hveudOrcI68W0M>=EDPaWgMt1SwNn8o(u"࠴ᕦ") and hlaI9ze7D3bGwxRO[HBJbZpwN23hveudOrcI68W0M]==YdIJ2BMWuebmqg5DNsZE[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠴ᕥ")]:
						HvcsiXhFR9Dw1()
						if HBJbZpwN23hveudOrcI68W0M>=OVmSuf8tpd(u"࠶ᕨ"): HBJbZpwN23hveudOrcI68W0M = -EDPaWgMt1SwNn8o(u"࠾ᕧ")
					elif HBJbZpwN23hveudOrcI68W0M>=kmdSKeBIwViM9t3(u"࠰ᕩ") and hlaI9ze7D3bGwxRO[HBJbZpwN23hveudOrcI68W0M]==YdIJ2BMWuebmqg5DNsZE[eeIL1TfgFQJaKqVD8hGNPEZ(u"࠳ᕪ")]:
						TlD1doFipMsk0y(ZSJVq5XDrRot(u"ࡋࡧ࡬ࡴࡧឥ"))
					if HBJbZpwN23hveudOrcI68W0M==-c4QSTnPiWUCjhrLlwGB(u"࠳ᕫ"): HHTzVhiY079bvdluNkFQ4wCMpe(wwyUWMFAsO(u"ູࠪࠫ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"຺ࠫࠬ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨົ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ะิ์ัࠦฮุล࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳࠦไๅะิ์ัࠦวๅืะ๎าࠦรฯฬิࠤํออะ่๊ࠢࠥอไฤฮ๋ฬฮࠦวๅ็อ์ๆืษࠨຼ"))
				uuVpFB8aTS = PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠴ᕬ")
			else: uuVpFB8aTS = JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠴ᕭ")
		j2agIU0xsLS6c7T.setSetting(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩຽ"),uD0IBl6nS9jqNekYZXaxzd2(F5I1VZzxkXenKuEAYO))
		Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,EDPaWgMt1SwNn8o(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ຾"),c4QSTnPiWUCjhrLlwGB(u"ࠩࡖࡍ࡙ࡋࡓࡠࡐࡄࡑࡊ࡙ࠧ຿"),uuVpFB8aTS,iKYM8NdkGHmBcr)
	return
def p2yfKDCa9NszEVY6mSnk0u1FqwH(m6egkRrjcavHEdwYDSOs,vABVTz0qOd1anSJ3D,exjaDckuA9M,knu9Y0BX6ErPRJWT13A5o,C3CUrDxjTcfdEQ8B,EExKW3DenGU8b,unjzvHfWpPTbqACy9RtOY6m,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw,ewfcdr7BUIRb1FE9htzSONsKo4gVjD,W5V6oRmIDCvcMGBQU,ybf3Qo7isaYVr,fCT9Mc1xyXogjGYN08mbnLQDIqh,c0c6mgI7VBUhHZ):
	CXGxFuL8dSY = int(ewfcdr7BUIRb1FE9htzSONsKo4gVjD%PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠶࠶ᕮ"))
	fFDoUS4V8iHqBvQdJCk3 = int(ewfcdr7BUIRb1FE9htzSONsKo4gVjD/aVLSn1xw5cK(u"࠷࠰ᕯ"))
	WPu2K19xsQTFOHaIcpM = m6egkRrjcavHEdwYDSOs,vABVTz0qOd1anSJ3D,exjaDckuA9M,knu9Y0BX6ErPRJWT13A5o,C3CUrDxjTcfdEQ8B,EExKW3DenGU8b,unjzvHfWpPTbqACy9RtOY6m,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࠫເ"),B0BjfWuVKkht7gPaNqFsTJOdcHbw
	RsB1atZJ30IkXiGnQE9jW72wOSd = j2agIU0xsLS6c7T.getSetting(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡱࡹࡸࡩࡡࡤࡪࡨࠫແ"))
	if not RsB1atZJ30IkXiGnQE9jW72wOSd: j2agIU0xsLS6c7T.setSetting(OVmSuf8tpd(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡲࡺࡹࡣࡢࡥ࡫ࡩࠬໂ"),OVmSuf8tpd(u"࠭ࡁࡖࡖࡒࠫໃ"))
	nnF1VOMIkrqi2ojXux6UPHGyEf7Kg = j2agIU0xsLS6c7T.getSetting(c4QSTnPiWUCjhrLlwGB(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫໄ"))
	nnUZQ3KaPgjcv6CuF = NiOkerpvwHXxLGR1Yy9um(W5V6oRmIDCvcMGBQU)
	TBUpCFJrs4O8 = [m6b7CoBk4EQ(u"࠰ᕷ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠲࠷ᕱ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠳࠺ᕲ"),JMLhEyaBWmskovGHTrVCxQ08(u"࠴࠽ᕳ"),c4QSTnPiWUCjhrLlwGB(u"࠲࠷ᕰ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠹࠴ᕶ"),LmcNhzY6fQPd2JyCGslkSr(u"࠹࠵ᕴ"),gnfv8UtZ3daGqpjzk(u"࠺࠹ᕵ")]
	DPmIorcZRTCXStH = fFDoUS4V8iHqBvQdJCk3 not in TBUpCFJrs4O8
	j6j5kKycazt7wCdNBTsgYvRJh2MP = fFDoUS4V8iHqBvQdJCk3 in [aVLSn1xw5cK(u"࠶࠸ᕻ"),XogUJZEijT7KWbxeO6(u"࠳࠺ᕸ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠺࠵ᕺ"),wwyUWMFAsO(u"࠹࠵ᕹ")]
	Rmyl5GPpvnNhI48AxXQCsZJLYHk1V = ewfcdr7BUIRb1FE9htzSONsKo4gVjD in [ZSJVq5XDrRot(u"࠸࠶࠶ᕽ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"࠷࠽࠰ᕼ")]
	SR980qf1uTVxojIPZBkXQ = (DPmIorcZRTCXStH or j6j5kKycazt7wCdNBTsgYvRJh2MP) and not Rmyl5GPpvnNhI48AxXQCsZJLYHk1V
	TA9h1o8wei67ZDXCcl2P4j0JgSYqE = nnF1VOMIkrqi2ojXux6UPHGyEf7Kg!=OVmSuf8tpd(u"ࠨࡔࡈࡊࡗࡋࡓࡉࡇࡇࠫ໅") and (nnF1VOMIkrqi2ojXux6UPHGyEf7Kg or not UISsAqZ5MGpEvJntk2N0LgbFuzHTK6)
	O1WwGBIXVUmFo39plP0E5Y8M = xuYvdJpOEyQKTLNwb(u"ࠩࡷࡽࡵ࡫࠽ࠨໆ") in nnF1VOMIkrqi2ojXux6UPHGyEf7Kg
	ut0bC8FTHQ = ewfcdr7BUIRb1FE9htzSONsKo4gVjD in [pEo8g7riWVL014KaRtzQ(u"࠴࠺࠶ᖈ"),AAgpHN0nMZ(u"࠵࠻࠸ᖉ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"࠶࠼࠳ᖊ"),FhcnOB9t3frzvXb(u"࠷࠶࠵ᖄ"),aVLSn1xw5cK(u"࠱࠷࠷ᖅ"),J3OCAmZVcn(u"࠲࠸࠹ᖆ"),sArCMRngQNmXkBoKv(u"࠳࠹࠻ᖇ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠶࠼࠸ᖃ"),ZSJVq5XDrRot(u"࠹࠹࠵ᖀ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠷࠷࠴ᕾ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"࠸࠸࠶ᕿ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"࠺࠺࠹ᖁ"),c4QSTnPiWUCjhrLlwGB(u"࠻࠻࠻ᖂ")]
	F6OgHwYPRiX10tJEv8r = CXGxFuL8dSY==OVmSuf8tpd(u"࠿ᖋ") or ewfcdr7BUIRb1FE9htzSONsKo4gVjD in [pEo8g7riWVL014KaRtzQ(u"࠲࠶࠸ᖍ"),OVmSuf8tpd(u"࠸࠵࠻ᖏ"),JMLhEyaBWmskovGHTrVCxQ08(u"࠷࠵࠷ᖎ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠴࠶ᖌ")]
	xhp2DwLiI9UjTqy6AdRGNErP4gfsYa = not ut0bC8FTHQ
	VIp32MEOsl0WD = not F6OgHwYPRiX10tJEv8r
	P3fRYDuAdVv1l = nnUZQ3KaPgjcv6CuF in [hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠪࠫ໇"),fR68jBGWCzUsFXdlTKPOScugm(u"ࠫ࠳࠴່ࠧ")]
	ihS9XxQ7Os = P3fRYDuAdVv1l or xhp2DwLiI9UjTqy6AdRGNErP4gfsYa
	jwZXbCAfNc5kniYpmzTMa9WodguJ0K = P3fRYDuAdVv1l or VIp32MEOsl0WD or O1WwGBIXVUmFo39plP0E5Y8M
	BBR9bi3SgDoykJPGNjTU0C = ewfcdr7BUIRb1FE9htzSONsKo4gVjD not in [Ej67fFyoqW8kbV2HdSK(u"࠳࠸࠳ᖔ"),ZSJVq5XDrRot(u"࠶࠻࠷ᖐ"),AAgpHN0nMZ(u"࠴࠹࠹ᖕ"),gSmqZU0plur2xKPJwQA(u"࠸࠷࠱ᖒ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠸࠹࠰ᖑ"),J3OCAmZVcn(u"࠵࠵࠲ᖓ")]
	if RsB1atZJ30IkXiGnQE9jW72wOSd==JMLhEyaBWmskovGHTrVCxQ08(u"࡙ࠬࡔࡐࡒ້ࠪ"): rrZ9nhjAx7T5ys3Eqpdu0 = F6OgHwYPRiX10tJEv8r or ut0bC8FTHQ
	else: rrZ9nhjAx7T5ys3Eqpdu0 = eeIL1TfgFQJaKqVD8hGNPEZ(u"࡚ࡲࡶࡧឦ")
	X4X8nOrLZ2 = fFDoUS4V8iHqBvQdJCk3 in [yTMWeCgUROcvtsblfK85L62xPk(u"࠻࠹ᖗ"),EDPaWgMt1SwNn8o(u"࠺࠹ᖖ")]
	AAiLH2XwYjQyVfJ8PNqleGRUaD13 = ewfcdr7BUIRb1FE9htzSONsKo4gVjD in [fR68jBGWCzUsFXdlTKPOScugm(u"࠷࠾࠰ᖘ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠽࠲࠱ᖙ")]
	IY7OL6W9lJ = not X4X8nOrLZ2 and not AAiLH2XwYjQyVfJ8PNqleGRUaD13
	IAs6viKNdSZQxU7Bq8oDkJ = ihS9XxQ7Os and jwZXbCAfNc5kniYpmzTMa9WodguJ0K and BBR9bi3SgDoykJPGNjTU0C and rrZ9nhjAx7T5ys3Eqpdu0 and IY7OL6W9lJ
	OBzAmRdCYk9h = BBR9bi3SgDoykJPGNjTU0C and rrZ9nhjAx7T5ys3Eqpdu0 and IY7OL6W9lJ
	yB2UlKV6Yz1P08J3OhrIoCNw9tfpkg = OBzAmRdCYk9h
	htBLnxDKORPs3kMCWTb8p9XmUNZ1E6 = j2agIU0xsLS6c7T.getSetting(m6b7CoBk4EQ(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡵࡸ࡯ࡷ࡫ࡧࡩࡷ໊࠭"))
	Q1Qh8yrEX7sgcVNzxuBAHi0KlG9 = j2agIU0xsLS6c7T.getSetting(gSmqZU0plur2xKPJwQA(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡩ࡯ࡥࡧ໋ࠪ"))
	if TA9h1o8wei67ZDXCcl2P4j0JgSYqE and IAs6viKNdSZQxU7Bq8oDkJ:
		qqFJhTEz8G4 = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,sArCMRngQNmXkBoKv(u"ࠨ࡮࡬ࡷࡹ࠭໌"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨໍ")+htBLnxDKORPs3kMCWTb8p9XmUNZ1E6+EDPaWgMt1SwNn8o(u"ࠪࡣࠬ໎")+Q1Qh8yrEX7sgcVNzxuBAHi0KlG9,WPu2K19xsQTFOHaIcpM)
		if qqFJhTEz8G4:
			tr24ZoudmqvxfYCw(wwyUWMFAsO(u"ࠫࠬ໏"),m6b7CoBk4EQ(u"ࠬ࠴ࠠࠡࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧ໐")+htBLnxDKORPs3kMCWTb8p9XmUNZ1E6+Ej67fFyoqW8kbV2HdSK(u"࠭࡟ࠨ໑")+Q1Qh8yrEX7sgcVNzxuBAHi0KlG9+ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧࠡࠢࠣࡐࡴࡧࡤࡪࡰࡪࠤࡲ࡫࡮ࡶࠢࡩࡶࡴࡳࠠࡤࡣࡦ࡬ࡪ࠭໒"))
			if O1WwGBIXVUmFo39plP0E5Y8M:
				FAajz7IZx61wNHCBQEY8 = []
				from ddrR0tvQHW import OybEV9qmloeJDaiF
				from bepC1A2Yfo import M83nAibIqYrhcdPvJl1aQExy,uwtI7SKjfJZYHzi5slFOebhc21qx
				Q3Z6HNEkebjrMslRTxU27nLdV = OybEV9qmloeJDaiF
				ewqSLf1rMYZlW = M83nAibIqYrhcdPvJl1aQExy()
				acVigKJGZAWR06xX7n9UoYlBhy2 = nnF1VOMIkrqi2ojXux6UPHGyEf7Kg
				vCJiW8u6BXSn70sxUGKfpI,gvjsHAy589YJhQGOqWRXSBZrfMP,roRCK9UjVn5LJfuesZlxywh,RiKwculGZDrsA2WH38vMBPbS,ddrRx8OJVTKlam41MeHcpsL,Ws3M1cGdHR,FVyek2GdjiAv5nUl,IvhEYNxBaH5mVU2r4XSg1,r8EDFMQea9jup6gTm3ClcJ = q0tgURwzEOJIYc27DbG4aT(acVigKJGZAWR06xX7n9UoYlBhy2)
				BU0pAdsZYmMK9ocFg = vCJiW8u6BXSn70sxUGKfpI,gvjsHAy589YJhQGOqWRXSBZrfMP,roRCK9UjVn5LJfuesZlxywh,RiKwculGZDrsA2WH38vMBPbS,ddrRx8OJVTKlam41MeHcpsL,Ws3M1cGdHR,FVyek2GdjiAv5nUl,XogUJZEijT7KWbxeO6(u"ࠨࠩ໓"),r8EDFMQea9jup6gTm3ClcJ
				for GdRN5bKfBFXMti7 in qqFJhTEz8G4:
					IAV1YMPTR3SU = GdRN5bKfBFXMti7[xuYvdJpOEyQKTLNwb(u"ࠩࡰࡩࡳࡻࡉࡵࡧࡰࠫ໔")]
					if IAV1YMPTR3SU==BU0pAdsZYmMK9ocFg or GdRN5bKfBFXMti7[aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠪࡱࡴࡪࡥࠨ໕")] in [kmdSKeBIwViM9t3(u"࠳࠸࠸ᖛ"),Ej67fFyoqW8kbV2HdSK(u"࠲࠸࠲ᖚ")]:
						GdRN5bKfBFXMti7 = wwmUu7Mragt1QJeNhIiA4RZfB(IAV1YMPTR3SU,Q3Z6HNEkebjrMslRTxU27nLdV,ewqSLf1rMYZlW)
						if GdRN5bKfBFXMti7[eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫ࡫ࡧࡶࡰࡴ࡬ࡸࡪࡹࠧ໖")]:
							ooT4mRBx82uM9ElZn5 = uwtI7SKjfJZYHzi5slFOebhc21qx(ewqSLf1rMYZlW,IAV1YMPTR3SU,GdRN5bKfBFXMti7[JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬࡴࡥࡸࡲࡤࡸ࡭࠭໗")])
							GdRN5bKfBFXMti7[jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࡣࡰࡰࡷࡩࡽࡺ࡟࡮ࡧࡱࡹࠬ໘")] = ooT4mRBx82uM9ElZn5+GdRN5bKfBFXMti7[eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧࡤࡱࡱࡸࡪࡾࡴࡠ࡯ࡨࡲࡺ࠭໙")]
					FAajz7IZx61wNHCBQEY8.append(GdRN5bKfBFXMti7)
				j2agIU0xsLS6c7T.setSetting(gnfv8UtZ3daGqpjzk(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬ໚"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩࠪ໛"))
				if m6egkRrjcavHEdwYDSOs==AAgpHN0nMZ(u"ࠪࡪࡴࡲࡤࡦࡴࠪໜ"): Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠫࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡࠪໝ")+htBLnxDKORPs3kMCWTb8p9XmUNZ1E6+AAgpHN0nMZ(u"ࠬࡥࠧໞ")+Q1Qh8yrEX7sgcVNzxuBAHi0KlG9,WPu2K19xsQTFOHaIcpM,FAajz7IZx61wNHCBQEY8,Z7uFdWIRv9ybj0)
			else: FAajz7IZx61wNHCBQEY8 = qqFJhTEz8G4
			if m6egkRrjcavHEdwYDSOs==DLSVmlyBbCK(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ໟ") and nnUZQ3KaPgjcv6CuF!=MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧ࠯࠰ࠪ໠") and SR980qf1uTVxojIPZBkXQ: UyKd8a0phrm()
			P0hoMkHjXq6ubZVr = TT81k0Wa2MmLfiN5ZjCEIqlGB6(WPu2K19xsQTFOHaIcpM,FAajz7IZx61wNHCBQEY8,ybf3Qo7isaYVr,fCT9Mc1xyXogjGYN08mbnLQDIqh,c0c6mgI7VBUhHZ)
			if P0hoMkHjXq6ubZVr: iiysxZ8dOaA()
	elif m6egkRrjcavHEdwYDSOs==pEo8g7riWVL014KaRtzQ(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ໡") and nnF1VOMIkrqi2ojXux6UPHGyEf7Kg==Ej67fFyoqW8kbV2HdSK(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡈࡈࠬ໢") and OBzAmRdCYk9h:
		ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,J3OCAmZVcn(u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩ໣")+htBLnxDKORPs3kMCWTb8p9XmUNZ1E6+EDPaWgMt1SwNn8o(u"ࠫࡤ࠭໤")+Q1Qh8yrEX7sgcVNzxuBAHi0KlG9,WPu2K19xsQTFOHaIcpM)
	return WPu2K19xsQTFOHaIcpM,nnUZQ3KaPgjcv6CuF,SR980qf1uTVxojIPZBkXQ,yB2UlKV6Yz1P08J3OhrIoCNw9tfpkg,htBLnxDKORPs3kMCWTb8p9XmUNZ1E6,Q1Qh8yrEX7sgcVNzxuBAHi0KlG9
def LEWui47GYrtb2zg8ysSQOA(m6egkRrjcavHEdwYDSOs,vABVTz0qOd1anSJ3D,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,knu9Y0BX6ErPRJWT13A5o,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,unjzvHfWpPTbqACy9RtOY6m,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw,qDBsizKL2w,ewfcdr7BUIRb1FE9htzSONsKo4gVjD,TnXLWxs5MD6FY1Ktwfl2kQuVASdhZ9,RGivP87NcYKdw):
	if TnXLWxs5MD6FY1Ktwfl2kQuVASdhZ9 in [XogUJZEijT7KWbxeO6(u"ࠬ࠷ࠧ໥"),kmdSKeBIwViM9t3(u"࠭࠲ࠨ໦"),AAgpHN0nMZ(u"ࠧ࠴ࠩ໧"),DLSVmlyBbCK(u"ࠨ࠶ࠪ໨"),m6b7CoBk4EQ(u"ࠩ࠸ࠫ໩")] and RGivP87NcYKdw:
		from bepC1A2Yfo import hhUnvQ52jmRlVGxcyeK38NagAFI
		hhUnvQ52jmRlVGxcyeK38NagAFI(UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,TnXLWxs5MD6FY1Ktwfl2kQuVASdhZ9,RGivP87NcYKdw)
		j2agIU0xsLS6c7T.setSetting(AAgpHN0nMZ(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧ໪"),VPIEsaiROZwmp20Jdn8WrA7c3Y)
		cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(kmdSKeBIwViM9t3(u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ໫"))
	elif TnXLWxs5MD6FY1Ktwfl2kQuVASdhZ9==kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠬ࠼ࠧ໬"):
		from j3x780FpaM import NLVM3HAtxQOSvJf6kd78K1o,II41hWgEXR7wfsmJCZocYqKA8BdzHQ
		if RGivP87NcYKdw==c4QSTnPiWUCjhrLlwGB(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ໭"): NLVM3HAtxQOSvJf6kd78K1o(Ej67fFyoqW8kbV2HdSK(u"๋ࠧำฯํࠥอไศ่อ฼ฬืࠧ໮"),gnfv8UtZ3daGqpjzk(u"ࠨฮสี๏ࠦแฮื้้ࠣ็ࠠศๆอั๊๐ไࠨ໯"),luMHeSgCBaPrb9KvUjNFqcR=LmcNhzY6fQPd2JyCGslkSr(u"࠳࠸࠴࠵ᖜ"))
		elif RGivP87NcYKdw==jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩࡇࡉࡑࡋࡔࡆࠩ໰"): ewfcdr7BUIRb1FE9htzSONsKo4gVjD = AAgpHN0nMZ(u"࠶࠷࠹ᖝ")
		HkKfQCS7RIa4xi3houjvl = II41hWgEXR7wfsmJCZocYqKA8BdzHQ(m6egkRrjcavHEdwYDSOs,qDBsizKL2w,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,ewfcdr7BUIRb1FE9htzSONsKo4gVjD,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,unjzvHfWpPTbqACy9RtOY6m,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw)
		if RGivP87NcYKdw==kmdSKeBIwViM9t3(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬ໱"): iiysxZ8dOaA(sArCMRngQNmXkBoKv(u"ࠫࡊࡾࡩࡵࠢࡷࡳࠥ࡬ࡩ࡯ࡣ࡯࡭ࡿ࡫ࠠࡷ࡫ࡧࡩࡴࡹࠠࡥࡱࡺࡲࡱࡵࡡࡥࠩ໲"))
		elif RGivP87NcYKdw==bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠬࡊࡅࡍࡇࡗࡉࠬ໳"): cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ໴"))
	elif UISsAqZ5MGpEvJntk2N0LgbFuzHTK6==bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧ࠸ࠩ໵"):
		from HzOyl02xJf import O2uRfkS5dcYy
		O2uRfkS5dcYy()
		cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ໶"))
	elif UISsAqZ5MGpEvJntk2N0LgbFuzHTK6==Ej67fFyoqW8kbV2HdSK(u"ࠩ࠻ࠫ໷"):
		cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(XogUJZEijT7KWbxeO6(u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ໸")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+LmcNhzY6fQPd2JyCGslkSr(u"ࠫࡄࡳ࡯ࡥࡧࡀࠫ໹")+str(knu9Y0BX6ErPRJWT13A5o)+JMLhEyaBWmskovGHTrVCxQ08(u"ࠬࠬࡴࡺࡲࡨࡁ࡫ࡵ࡬ࡥࡧࡵ࠭ࠬ໺"))
	elif UISsAqZ5MGpEvJntk2N0LgbFuzHTK6==m6b7CoBk4EQ(u"࠭࠹ࠨ໻"):
		j2agIU0xsLS6c7T.setSetting(aVLSn1xw5cK(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫ໼"),c4QSTnPiWUCjhrLlwGB(u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡇࡇࠫ໽"))
		cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(EDPaWgMt1SwNn8o(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭໾"))
		iiysxZ8dOaA(OVmSuf8tpd(u"ࠪࡉࡽ࡯ࡴࠡࡶࡲࠤࡷ࡫ࡦࡳࡧࡶ࡬ࠥࡳࡥ࡯ࡷࠪ໿"))
	return
def f3fo8AlmKQH9e6IJ451dr(m6egkRrjcavHEdwYDSOs,vABVTz0qOd1anSJ3D,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,knu9Y0BX6ErPRJWT13A5o,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,unjzvHfWpPTbqACy9RtOY6m,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw,qDBsizKL2w,ewfcdr7BUIRb1FE9htzSONsKo4gVjD,TnXLWxs5MD6FY1Ktwfl2kQuVASdhZ9,RGivP87NcYKdw,W5V6oRmIDCvcMGBQU):
	if UISsAqZ5MGpEvJntk2N0LgbFuzHTK6: LEWui47GYrtb2zg8ysSQOA(m6egkRrjcavHEdwYDSOs,vABVTz0qOd1anSJ3D,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,knu9Y0BX6ErPRJWT13A5o,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,unjzvHfWpPTbqACy9RtOY6m,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw,qDBsizKL2w,ewfcdr7BUIRb1FE9htzSONsKo4gVjD,TnXLWxs5MD6FY1Ktwfl2kQuVASdhZ9,RGivP87NcYKdw)
	if nc1u5UZAtX2WNO4aJMmbg: CVWiQUeASg()
	VZotrchyP5ez4psFq8QGjbUIYO9dE(FhcnOB9t3frzvXb(u"ࡆࡢ࡮ࡶࡩឧ"))
	Q8RtwXp7ioDUqbW9HjKgYlP()
	ybf3Qo7isaYVr,fCT9Mc1xyXogjGYN08mbnLQDIqh,c0c6mgI7VBUhHZ = PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࡖࡵࡹࡪឩ"),wwyUWMFAsO(u"ࡇࡣ࡯ࡷࡪឨ"),wwyUWMFAsO(u"ࡇࡣ࡯ࡷࡪឨ")
	WBcZQFep3Ms9Oqw26Y = p2yfKDCa9NszEVY6mSnk0u1FqwH(m6egkRrjcavHEdwYDSOs,vABVTz0qOd1anSJ3D,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,knu9Y0BX6ErPRJWT13A5o,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,unjzvHfWpPTbqACy9RtOY6m,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw,ewfcdr7BUIRb1FE9htzSONsKo4gVjD,W5V6oRmIDCvcMGBQU,ybf3Qo7isaYVr,fCT9Mc1xyXogjGYN08mbnLQDIqh,c0c6mgI7VBUhHZ)
	WPu2K19xsQTFOHaIcpM,nnUZQ3KaPgjcv6CuF,SR980qf1uTVxojIPZBkXQ,yB2UlKV6Yz1P08J3OhrIoCNw9tfpkg,htBLnxDKORPs3kMCWTb8p9XmUNZ1E6,Q1Qh8yrEX7sgcVNzxuBAHi0KlG9 = WBcZQFep3Ms9Oqw26Y
	jJSBRtqke9EU6waxvz7PDrg8ATnWm1(ZSJVq5XDrRot(u"ࠫࡸࡺࡡࡳࡶࠪༀ"))
	if j2agIU0xsLS6c7T.getSetting(J3OCAmZVcn(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡪࡷࡸࡵࡩࡡࡤࡪࡨࠫ༁")) not in [EDPaWgMt1SwNn8o(u"࠭ࡁࡖࡖࡒࠫ༂"),c4QSTnPiWUCjhrLlwGB(u"ࠧࡔࡖࡒࡔࠬ༃"),wwyUWMFAsO(u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩ༄")]:
		j2agIU0xsLS6c7T.setSetting(OVmSuf8tpd(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨ༅"),xuYvdJpOEyQKTLNwb(u"ࠪࡅ࡚࡚ࡏࠨ༆"))
	if not j2agIU0xsLS6c7T.getSetting(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠫࡦࡼ࠮ࡥࡰࡶࠫ༇")): j2agIU0xsLS6c7T.setSetting(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠬࡧࡶ࠯ࡦࡱࡷࠬ༈"),XK2WaStRNq[bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠴ᖞ")])
	HkKfQCS7RIa4xi3houjvl = II41hWgEXR7wfsmJCZocYqKA8BdzHQ(m6egkRrjcavHEdwYDSOs,qDBsizKL2w,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,knu9Y0BX6ErPRJWT13A5o,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,unjzvHfWpPTbqACy9RtOY6m,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw)
	if m6b7CoBk4EQ(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ༉") in unjzvHfWpPTbqACy9RtOY6m: fCT9Mc1xyXogjGYN08mbnLQDIqh = EDPaWgMt1SwNn8o(u"ࡗࡶࡺ࡫ឪ")
	if m6egkRrjcavHEdwYDSOs==fR68jBGWCzUsFXdlTKPOScugm(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ༊"):
		if nnUZQ3KaPgjcv6CuF!=kmdSKeBIwViM9t3(u"ࠨ࠰࠱ࠫ་") and SR980qf1uTVxojIPZBkXQ: UyKd8a0phrm()
		if jVGRimgPZeu9l0dsUoHJ1a>-LmcNhzY6fQPd2JyCGslkSr(u"࠶ᖟ"):
			yjKOvBMbqwYsa1ztdLufTEmnFeQVi = [PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠶ᖧ"),DLSVmlyBbCK(u"࠱࠶ᖡ"),wwyUWMFAsO(u"࠲࠹ᖢ"),yTMWeCgUROcvtsblfK85L62xPk(u"࠳࠼ᖣ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠸࠶ᖠ"),JMLhEyaBWmskovGHTrVCxQ08(u"࠸࠺ᖦ"),wwyUWMFAsO(u"࠸࠴ᖤ"),gSmqZU0plur2xKPJwQA(u"࠹࠸ᖥ")]
			if (NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,XogUJZEijT7KWbxeO6(u"ࠩ࡬ࡲࡹ࠭༌"),DLSVmlyBbCK(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭།"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠫࡘࡏࡔࡆࡕࡢࡒࡆࡓࡅࡔࠩ༎")) or ewfcdr7BUIRb1FE9htzSONsKo4gVjD not in yjKOvBMbqwYsa1ztdLufTEmnFeQVi) and not ynO4oHRV3Mj6Z9gNh(OVmSuf8tpd(u"ࠬࡉࡔࡆ࠻ࡇࡗ࠶࠿ࡖࡖ࠲࡙ࡗ࡝࠭༏")):
				from ddrR0tvQHW import OybEV9qmloeJDaiF
				qqFJhTEz8G4 = QVm4NG9aLtX6Hn8fod0iRWwhsUyu(OybEV9qmloeJDaiF)
				P0hoMkHjXq6ubZVr = TT81k0Wa2MmLfiN5ZjCEIqlGB6(WPu2K19xsQTFOHaIcpM,qqFJhTEz8G4,ybf3Qo7isaYVr,fCT9Mc1xyXogjGYN08mbnLQDIqh,c0c6mgI7VBUhHZ)
				if qqFJhTEz8G4 and yB2UlKV6Yz1P08J3OhrIoCNw9tfpkg:
					Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,c4QSTnPiWUCjhrLlwGB(u"࠭ࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࡣࠬ༐")+htBLnxDKORPs3kMCWTb8p9XmUNZ1E6+xuYvdJpOEyQKTLNwb(u"ࠧࡠࠩ༑")+Q1Qh8yrEX7sgcVNzxuBAHi0KlG9,WPu2K19xsQTFOHaIcpM,qqFJhTEz8G4,Z7uFdWIRv9ybj0)
			else:
				pZrEWcFVmiNCjozM.addDirectoryItem(jVGRimgPZeu9l0dsUoHJ1a,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫ༒")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+Ej67fFyoqW8kbV2HdSK(u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿࡯࡭ࡳࡱࠦ࡮ࡱࡧࡩࡂ࠻࠰࠱ࠩ༓"),kGEPsyxKnHDJ.ListItem(c4QSTnPiWUCjhrLlwGB(u"่ࠪิ๐ใࠡ็ื็้ฯࠠๆ่ࠣะ์อาไࠩ༔")))
				pZrEWcFVmiNCjozM.addDirectoryItem(jVGRimgPZeu9l0dsUoHJ1a,AAgpHN0nMZ(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧ༕")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+kmdSKeBIwViM9t3(u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡲࡩ࡯࡭ࠩࡱࡴࡪࡥ࠾࠷࠳࠴ࠬ༖"),kGEPsyxKnHDJ.ListItem(LmcNhzY6fQPd2JyCGslkSr(u"࠭รโฬะࠤ้ะโาลࠣห้ะแศืํ่ࠬ༗")))
			pZrEWcFVmiNCjozM.endOfDirectory(jVGRimgPZeu9l0dsUoHJ1a,ybf3Qo7isaYVr,fCT9Mc1xyXogjGYN08mbnLQDIqh,c0c6mgI7VBUhHZ)
	return
def UAyxKVL2kthjd(JCNj7yt4xW2PIO0g5DqhpFXzs8Y):
	q3fE6oQSzKFM8BANRjw21GkUVv9r = m6b7CoBk4EQ(u"ࡋࡧ࡬ࡴࡧឬ") if JCNj7yt4xW2PIO0g5DqhpFXzs8Y else gSmqZU0plur2xKPJwQA(u"ࡘࡷࡻࡥឫ")
	if not q3fE6oQSzKFM8BANRjw21GkUVv9r:
		eW0wIFV2Gkf = SeN2UjVuMw6K03nrgWZLOYB5la7mpA(j2agIU0xsLS6c7T.getSetting(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ༘")))
		eW0wIFV2Gkf = c4QSTnPiWUCjhrLlwGB(u"࠰ᖨ") if not eW0wIFV2Gkf else int(eW0wIFV2Gkf)
		if not eW0wIFV2Gkf or not ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠱ᖩ")<=F5I1VZzxkXenKuEAYO-eW0wIFV2Gkf<=JCNj7yt4xW2PIO0g5DqhpFXzs8Y: q3fE6oQSzKFM8BANRjw21GkUVv9r = hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࡚ࡲࡶࡧឭ")
	if not q3fE6oQSzKFM8BANRjw21GkUVv9r:
		vMWkKJfju4r10CdmSUyg9F3hRb = j2agIU0xsLS6c7T.getSetting(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ༙࠭"))
		if vMWkKJfju4r10CdmSUyg9F3hRb in [kmdSKeBIwViM9t3(u"ࠩࠪ༚"),xuYvdJpOEyQKTLNwb(u"ࠪࡓࡑࡊ࡟ࡕࡑࡢࡉࡗࡘࡏࡓࠩ༛"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࡓࡋࡗࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪ༜")]: q3fE6oQSzKFM8BANRjw21GkUVv9r = JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࡔࡳࡷࡨឮ")
	if not q3fE6oQSzKFM8BANRjw21GkUVv9r:
		from hashlib import md5 as ppq7nbP8zdkSt20aCVK3rY9
		FFd8ZA7WH3Mlcq6YtNnJDyX = j2agIU0xsLS6c7T.getSetting(EDPaWgMt1SwNn8o(u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹ࠱ࠨ༝"))
		YfDtc91gRzkIirNwAvZqp7 = j2agIU0xsLS6c7T.getSetting(fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࡡࡷ࠰ࡳࡶ࡮ࡼࡳ࠳ࠩ༞"))
		HY1K74yAmEacxL8VITDd5MhGgQBsit = ppq7nbP8zdkSt20aCVK3rY9(kmdSKeBIwViM9t3(u"࠷ᖪ")*FFd8ZA7WH3Mlcq6YtNnJDyX.encode(gnfv8UtZ3daGqpjzk(u"ࠧࡶࡶࡩ࠼ࠬ༟"))).hexdigest()
		HY1K74yAmEacxL8VITDd5MhGgQBsit = ppq7nbP8zdkSt20aCVK3rY9(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠴࠸ᖫ")*HY1K74yAmEacxL8VITDd5MhGgQBsit.encode(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨࡷࡷࡪ࠽࠭༠"))).hexdigest()
		HY1K74yAmEacxL8VITDd5MhGgQBsit = ppq7nbP8zdkSt20aCVK3rY9(aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠵࠾ᖬ")*HY1K74yAmEacxL8VITDd5MhGgQBsit.encode(c4QSTnPiWUCjhrLlwGB(u"ࠩࡸࡸ࡫࠾ࠧ༡"))).hexdigest()
		if HY1K74yAmEacxL8VITDd5MhGgQBsit!=YfDtc91gRzkIirNwAvZqp7: q3fE6oQSzKFM8BANRjw21GkUVv9r = yTMWeCgUROcvtsblfK85L62xPk(u"ࡕࡴࡸࡩឯ")
	if q3fE6oQSzKFM8BANRjw21GkUVv9r: du39cjxwQqvhBVAfNClDi = XGx6Bsa9nEuiPD(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࡈࡤࡰࡸ࡫ឰ"))
	return
def II41hWgEXR7wfsmJCZocYqKA8BdzHQ(m6egkRrjcavHEdwYDSOs,vABVTz0qOd1anSJ3D,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,knu9Y0BX6ErPRJWT13A5o,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,unjzvHfWpPTbqACy9RtOY6m,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw):
	ewfcdr7BUIRb1FE9htzSONsKo4gVjD = int(knu9Y0BX6ErPRJWT13A5o)
	fFDoUS4V8iHqBvQdJCk3 = int(ewfcdr7BUIRb1FE9htzSONsKo4gVjD//OVmSuf8tpd(u"࠶࠶ᖭ"))
	if   fFDoUS4V8iHqBvQdJCk3==EDPaWgMt1SwNn8o(u"࠶ᖮ"):  from bYGAkzJECs 		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==ZSJVq5XDrRot(u"࠱ᖯ"):  from Ml3d4o2esx 		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==aVLSn1xw5cK(u"࠳ᖰ"):  from DKjZTYuh2d 			import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,wwNtFTLK2IqAszYBDV9J,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==aVLSn1xw5cK(u"࠵ᖱ"):  from pPqIT7ySwO 			import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,wwNtFTLK2IqAszYBDV9J,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==XogUJZEijT7KWbxeO6(u"࠷ᖲ"):  from aagcLB1H9T 		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m,wwNtFTLK2IqAszYBDV9J)
	elif fFDoUS4V8iHqBvQdJCk3==eeIL1TfgFQJaKqVD8hGNPEZ(u"࠹ᖳ"):  from LoAjV7akcH 		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠻ᖴ"):  from tZHX76ugUT 		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠽ᖵ"):  from mCTR9VFong 			import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==EDPaWgMt1SwNn8o(u"࠸ᖶ"):  from zzRXnV0x6N 		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==eeIL1TfgFQJaKqVD8hGNPEZ(u"࠺ᖷ"):  from W49pfiPnCH		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==OVmSuf8tpd(u"࠳࠳ᖸ"): from DDPe9NIFqf 		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2)
	elif fFDoUS4V8iHqBvQdJCk3==aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠴࠵ᖹ"): from epWEGAh8dK 		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==JMLhEyaBWmskovGHTrVCxQ08(u"࠵࠷ᖺ"): from foyTwPNklz 		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,wwNtFTLK2IqAszYBDV9J,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠶࠹ᖻ"): from V8VuXMhUew		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,wwNtFTLK2IqAszYBDV9J,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==aVLSn1xw5cK(u"࠷࠴ᖼ"): from gmlsMyZIhB 		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m,m6egkRrjcavHEdwYDSOs,wwNtFTLK2IqAszYBDV9J,vABVTz0qOd1anSJ3D,ttiasLcTXGvgqb41nC7DRF)
	elif fFDoUS4V8iHqBvQdJCk3==yTMWeCgUROcvtsblfK85L62xPk(u"࠱࠶ᖽ"): from bYGAkzJECs 		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==gSmqZU0plur2xKPJwQA(u"࠲࠸ᖾ"): from ut0bC8FTHQ		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m,wwNtFTLK2IqAszYBDV9J,B0BjfWuVKkht7gPaNqFsTJOdcHbw)
	elif fFDoUS4V8iHqBvQdJCk3==fR68jBGWCzUsFXdlTKPOScugm(u"࠳࠺ᖿ"): from bYGAkzJECs 		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==LmcNhzY6fQPd2JyCGslkSr(u"࠴࠼ᗀ"): from va5Cwpohg4		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==AAgpHN0nMZ(u"࠵࠾ᗁ"): from bYGAkzJECs 		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠷࠶ᗂ"): from eL6whX7imV		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠸࠱ᗃ"): from NpYuwRIMtG	import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==J3OCAmZVcn(u"࠲࠳ᗄ"): from qeNbZQXt1o		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,wwNtFTLK2IqAszYBDV9J,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==Ej67fFyoqW8kbV2HdSK(u"࠳࠵ᗅ"): from uu80ZYa2sG			import EXgQe7mIMsxD8kcOZ; HkKfQCS7RIa4xi3houjvl = EXgQe7mIMsxD8kcOZ(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m,m6egkRrjcavHEdwYDSOs,wwNtFTLK2IqAszYBDV9J,B0BjfWuVKkht7gPaNqFsTJOdcHbw)
	elif fFDoUS4V8iHqBvQdJCk3==JMLhEyaBWmskovGHTrVCxQ08(u"࠴࠷ᗆ"): from FN6uzHvdbp 			import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==fR68jBGWCzUsFXdlTKPOScugm(u"࠵࠹ᗇ"): from iRzsfUmpP7 		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==AAgpHN0nMZ(u"࠶࠻ᗈ"): from ddrR0tvQHW 			import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==pEo8g7riWVL014KaRtzQ(u"࠷࠽ᗉ"): from bepC1A2Yfo		import EXgQe7mIMsxD8kcOZ; HkKfQCS7RIa4xi3houjvl = EXgQe7mIMsxD8kcOZ(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6)
	elif fFDoUS4V8iHqBvQdJCk3==OVmSuf8tpd(u"࠸࠸ᗊ"): from uu80ZYa2sG			import EXgQe7mIMsxD8kcOZ; HkKfQCS7RIa4xi3houjvl = EXgQe7mIMsxD8kcOZ(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m,m6egkRrjcavHEdwYDSOs,wwNtFTLK2IqAszYBDV9J,B0BjfWuVKkht7gPaNqFsTJOdcHbw)
	elif fFDoUS4V8iHqBvQdJCk3==yTMWeCgUROcvtsblfK85L62xPk(u"࠲࠺ᗋ"): from xxS1KjEBZg	import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,wwNtFTLK2IqAszYBDV9J,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==AAgpHN0nMZ(u"࠴࠲ᗌ"): from iNwU014Zu7		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==jYaM5vilgZdFx6QHbApwVXO8et(u"࠵࠴ᗍ"): from tNqL8MgEnu		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==kmdSKeBIwViM9t3(u"࠶࠶ᗎ"): from lEv3OAV9W2		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==kRYWcNuAazr4jtmBoxFVS19Z6(u"࠷࠸ᗏ"): from L1Zo20tErl		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2)
	elif fFDoUS4V8iHqBvQdJCk3==JMLhEyaBWmskovGHTrVCxQ08(u"࠸࠺ᗐ"): from bYGAkzJECs 		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==c4QSTnPiWUCjhrLlwGB(u"࠹࠵ᗑ"): from oV8DHKQf25		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==AAgpHN0nMZ(u"࠳࠷ᗒ"): from z8zlcAXu7D			import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==aVLSn1xw5cK(u"࠴࠹ᗓ"): from dpINwXmrSA			import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠵࠻ᗔ"): from D2DLOUb5Qx 		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==yTMWeCgUROcvtsblfK85L62xPk(u"࠶࠽ᗕ"): from RaP18ex9yp		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==eeIL1TfgFQJaKqVD8hGNPEZ(u"࠸࠵ᗖ"): from hyzijIU4w3	import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m,m6egkRrjcavHEdwYDSOs,wwNtFTLK2IqAszYBDV9J)
	elif fFDoUS4V8iHqBvQdJCk3==OVmSuf8tpd(u"࠹࠷ᗗ"): from hyzijIU4w3	import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m,m6egkRrjcavHEdwYDSOs,wwNtFTLK2IqAszYBDV9J)
	elif fFDoUS4V8iHqBvQdJCk3==jYaM5vilgZdFx6QHbApwVXO8et(u"࠺࠲ᗘ"): from jrfTYWXZnv			import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==aVLSn1xw5cK(u"࠴࠴ᗙ"): from rr8BvkwspK			import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==DLSVmlyBbCK(u"࠵࠶ᗚ"): from cae3Us4hwj		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==LmcNhzY6fQPd2JyCGslkSr(u"࠶࠸ᗛ"): from rZNXI2Ki3b		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==jYaM5vilgZdFx6QHbApwVXO8et(u"࠷࠺ᗜ"): from tjAQk8gwul			import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==LmcNhzY6fQPd2JyCGslkSr(u"࠸࠼ᗝ"): from zeHi9kbLcZ		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==eeIL1TfgFQJaKqVD8hGNPEZ(u"࠹࠾ᗞ"): from yLKZ3U5T8o		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==aVLSn1xw5cK(u"࠺࠹ᗟ"): from Ea7O1mGSgv		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠵࠱ᗠ"): from bYGAkzJECs 		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==xuYvdJpOEyQKTLNwb(u"࠶࠳ᗡ"): from pcPAMuFyhV 		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠷࠵ᗢ"): from pcPAMuFyhV 		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠸࠷ᗣ"): from ddrR0tvQHW 			import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠹࠹ᗤ"): from HzOyl02xJf	import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m,wwNtFTLK2IqAszYBDV9J)
	elif fFDoUS4V8iHqBvQdJCk3==jYaM5vilgZdFx6QHbApwVXO8et(u"࠺࠻ᗥ"): from BMiW1qeG8b 		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==fR68jBGWCzUsFXdlTKPOScugm(u"࠻࠶ᗦ"): from GAOBVmq23j			import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==eeIL1TfgFQJaKqVD8hGNPEZ(u"࠵࠸ᗧ"): from L5Wip7lPhd		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==kRYWcNuAazr4jtmBoxFVS19Z6(u"࠶࠺ᗨ"): from D0Da3tgVUJ		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==JMLhEyaBWmskovGHTrVCxQ08(u"࠷࠼ᗩ"): from byPuAs5w3T		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==m6b7CoBk4EQ(u"࠹࠴ᗪ"): from sDIuzwKn2V			import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==c4QSTnPiWUCjhrLlwGB(u"࠺࠶ᗫ"): from aFn7TlwuWq			import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==fR68jBGWCzUsFXdlTKPOScugm(u"࠻࠸ᗬ"): from ydvYhtoqkf		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==c4QSTnPiWUCjhrLlwGB(u"࠼࠳ᗭ"): from E4E51cx7Zq	import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠶࠵ᗮ"): from E2RU1x6hfF			import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==kRYWcNuAazr4jtmBoxFVS19Z6(u"࠷࠷ᗯ"): from VgZh1PxFql			import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==m6b7CoBk4EQ(u"࠸࠹ᗰ"): from VVnZDU48aC			import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==LmcNhzY6fQPd2JyCGslkSr(u"࠹࠻ᗱ"): from U0UaVBJHgY		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠺࠽ᗲ"): from HB9slYrGKq		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==pEo8g7riWVL014KaRtzQ(u"࠻࠿ᗳ"): from J8DPkmleWz		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==LmcNhzY6fQPd2JyCGslkSr(u"࠽࠰ᗴ"): from HPo3xEClYW			import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==yTMWeCgUROcvtsblfK85L62xPk(u"࠷࠲ᗵ"): from Yj2oWQg6sb			import EXgQe7mIMsxD8kcOZ; HkKfQCS7RIa4xi3houjvl = EXgQe7mIMsxD8kcOZ(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m,m6egkRrjcavHEdwYDSOs,wwNtFTLK2IqAszYBDV9J,B0BjfWuVKkht7gPaNqFsTJOdcHbw)
	elif fFDoUS4V8iHqBvQdJCk3==aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠸࠴ᗶ"): from Yj2oWQg6sb			import EXgQe7mIMsxD8kcOZ; HkKfQCS7RIa4xi3houjvl = EXgQe7mIMsxD8kcOZ(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m,m6egkRrjcavHEdwYDSOs,wwNtFTLK2IqAszYBDV9J,B0BjfWuVKkht7gPaNqFsTJOdcHbw)
	elif fFDoUS4V8iHqBvQdJCk3==hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠹࠶ᗷ"): from TTEnLQIMeW	import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠺࠸ᗸ"): from X4X8nOrLZ2		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD)
	elif fFDoUS4V8iHqBvQdJCk3==c4QSTnPiWUCjhrLlwGB(u"࠻࠺ᗹ"): from X4X8nOrLZ2		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD)
	elif fFDoUS4V8iHqBvQdJCk3==fR68jBGWCzUsFXdlTKPOScugm(u"࠼࠼ᗺ"): from ut0bC8FTHQ		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m,wwNtFTLK2IqAszYBDV9J,B0BjfWuVKkht7gPaNqFsTJOdcHbw)
	elif fFDoUS4V8iHqBvQdJCk3==Ej67fFyoqW8kbV2HdSK(u"࠽࠷ᗻ"): from jRx1tlqX0z 		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,wwNtFTLK2IqAszYBDV9J,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==gnfv8UtZ3daGqpjzk(u"࠷࠹ᗼ"): from tbohC2lJn3 		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,wwNtFTLK2IqAszYBDV9J,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==JMLhEyaBWmskovGHTrVCxQ08(u"࠸࠻ᗽ"): from KK7JZeE4GP 		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,wwNtFTLK2IqAszYBDV9J,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==jYaM5vilgZdFx6QHbApwVXO8et(u"࠺࠳ᗾ"): from ShN9wm1BE8 		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,wwNtFTLK2IqAszYBDV9J,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==gnfv8UtZ3daGqpjzk(u"࠻࠵ᗿ"): from t5A1SMbXW2 		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,unjzvHfWpPTbqACy9RtOY6m)
	elif fFDoUS4V8iHqBvQdJCk3==kmdSKeBIwViM9t3(u"࠼࠷ᘀ"): from u2APxIQdlD		import OVQIAezo6U1NSTl4L	; HkKfQCS7RIa4xi3houjvl = OVQIAezo6U1NSTl4L(ewfcdr7BUIRb1FE9htzSONsKo4gVjD,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,wwNtFTLK2IqAszYBDV9J,unjzvHfWpPTbqACy9RtOY6m)
	else: HkKfQCS7RIa4xi3houjvl = None
	return HkKfQCS7RIa4xi3houjvl
def oxPZWmC4asVXJyLB(vhQayCIs07WL6iB1XSwubO,X75jhUrfuFIJW82GYmbp,j5jMXZ7myEuoLG,showDialogs):
	tgQs4VY5JdLGi9wr = j2agIU0xsLS6c7T.getSetting(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫ༢"))
	j2agIU0xsLS6c7T.setSetting(Ej67fFyoqW8kbV2HdSK(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬ༣"),FhcnOB9t3frzvXb(u"ࠬ࠭༤"))
	if Ej67fFyoqW8kbV2HdSK(u"࠭࠭ࠨ༥") in j5jMXZ7myEuoLG: ji1dGuYnsFNKe = j5jMXZ7myEuoLG.split(OVmSuf8tpd(u"ࠧ࠮ࠩ༦"),FhcnOB9t3frzvXb(u"࠶ᘁ"))[MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠶ᘂ")]
	else: ji1dGuYnsFNKe = j5jMXZ7myEuoLG
	c8MA5nvYGZ03PEufWr = vhQayCIs07WL6iB1XSwubO in [kRYWcNuAazr4jtmBoxFVS19Z6(u"࠺ᘆ"),wwyUWMFAsO(u"࠲࠳࠳࠴࠶ᘄ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠱࠲࠲࠳࠶ᘃ"),fR68jBGWCzUsFXdlTKPOScugm(u"࠳࠳࠴࠺࠺ᘅ")]
	fYujIve8adGANT4g5O3iVP = X75jhUrfuFIJW82GYmbp.lower()
	L8LqzesBD9AHMugJY7 = vhQayCIs07WL6iB1XSwubO in [LmcNhzY6fQPd2JyCGslkSr(u"࠴ᘇ"),XogUJZEijT7KWbxeO6(u"࠱࠱࠶ᘊ"),sArCMRngQNmXkBoKv(u"࠶࠶࠰࠷࠳ᘈ"),JMLhEyaBWmskovGHTrVCxQ08(u"࠷࠱࠲ᘉ")]
	v8hlgLTzeP4RoSyC29 = ZSJVq5XDrRot(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩ༧") in fYujIve8adGANT4g5O3iVP
	ZbE6RhA5d7lm4rGvJx13 = fR68jBGWCzUsFXdlTKPOScugm(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦ࠵ࠡࡵࡨࡧࡴࡴࡤࡴࠢࡥࡶࡴࡽࡳࡦࡴࠣࡧ࡭࡫ࡣ࡬ࠩ༨") in fYujIve8adGANT4g5O3iVP
	mfCu1XlqGMHZwRL5F = m6b7CoBk4EQ(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡳࡧࡦࡥࡵࡺࡣࡩࡣࠪ༩") in fYujIve8adGANT4g5O3iVP
	ZjNf2VgMp4qKiGXrDBLbe0oUlCvx9y = wwyUWMFAsO(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠥࡹࡥࡤࡷࡵ࡭ࡹࡿࠠࡤࡪࡨࡧࡰ࠭༪") in fYujIve8adGANT4g5O3iVP
	AwQmhUJRXj0qtbCz3BpSYl6Zkuone = j2agIU0xsLS6c7T.getSetting(JMLhEyaBWmskovGHTrVCxQ08(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪ༫"))
	urEw42gLtCNeoXclaksQbAViZd39 = j2agIU0xsLS6c7T.getSetting(ZSJVq5XDrRot(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩ༬"))
	uC9Jwn7rmKIR4EVFoSXay0OqAZQhkl = bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧโึ็ࠤๆ๐ࠠิฯหࠤฬ๊ีโฯฬࠤ๊์ࠠศๆศ๊ฯืๆหࠩ༭")
	K1GbY6Nz5PDwBAJIyHot3ers = fR68jBGWCzUsFXdlTKPOScugm(u"ࠨࡇࡵࡶࡴࡸࠠࠨ༮")+str(vhQayCIs07WL6iB1XSwubO)+ZSJVq5XDrRot(u"ࠩ࠽ࠤࠬ༯")+X75jhUrfuFIJW82GYmbp
	K1GbY6Nz5PDwBAJIyHot3ers = ejBOu2WXwvb4YpITdsLF16(K1GbY6Nz5PDwBAJIyHot3ers)
	if L8LqzesBD9AHMugJY7 or v8hlgLTzeP4RoSyC29 or ZbE6RhA5d7lm4rGvJx13 or mfCu1XlqGMHZwRL5F or ZjNf2VgMp4qKiGXrDBLbe0oUlCvx9y:
		uC9Jwn7rmKIR4EVFoSXay0OqAZQhkl += pEo8g7riWVL014KaRtzQ(u"ࠪࠤ࠳ࠦวๅ็๋ๆ฾ࠦแ๋้ࠣััฮࠠืัࠣ็ํี๊ࠡ็ุำึํࠠศๆศ๊ฯืๆหࠢส่ำอีࠡสๆࠤศ๎ࠠษษ็้ํู่࡝ࡰࠪ༰")
	if c8MA5nvYGZ03PEufWr: uC9Jwn7rmKIR4EVFoSXay0OqAZQhkl += LmcNhzY6fQPd2JyCGslkSr(u"ࠫࠥ࠴ࠠๅัํ็ࠥิืฤࠢࡇࡒࡘ่ࠦๆ฻้ห์ࠦสฺาิࠤฯืฬๆหࠣหุ๋ࠠศๆ่์็฿ࠠฦๆ์ࠤึ่ๅ่࡞ࡱࠫ༱")
	K1GbY6Nz5PDwBAJIyHot3ers = jYaM5vilgZdFx6QHbApwVXO8et(u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ༲")+K1GbY6Nz5PDwBAJIyHot3ers+fR68jBGWCzUsFXdlTKPOScugm(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ༳")
	if AwQmhUJRXj0qtbCz3BpSYl6Zkuone==fR68jBGWCzUsFXdlTKPOScugm(u"ࠧࡂࡕࡎࠫ༴") or urEw42gLtCNeoXclaksQbAViZd39==OVmSuf8tpd(u"ࠨࡃࡖࡏ༵ࠬ"):
		uC9Jwn7rmKIR4EVFoSXay0OqAZQhkl += kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣ็ๅࠢอี๏ีࠠฤ่ࠣ๎าอ่ๅࠢส่อืๆศ็ฯࠤส฻ไศฯࠣห้๋ิไๆฬࠤ࠳࠴ࠠฤ็ࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦร้ࠢั฻ศࠦลๅ๋ࠣห้๋ศา็ฯࠤฤࠧࠡ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ༶")
	yh04Y1UbKaoD3Lqe6rZTm = yTMWeCgUROcvtsblfK85L62xPk(u"ࡉࡥࡱࡹࡥឱ")
	if showDialogs and j5jMXZ7myEuoLG not in ppEw9HgZkCPtvnjV4Y:
		if AwQmhUJRXj0qtbCz3BpSYl6Zkuone==yTMWeCgUROcvtsblfK85L62xPk(u"ࠪࡅࡘࡑ༷ࠧ") or urEw42gLtCNeoXclaksQbAViZd39==m6b7CoBk4EQ(u"ࠫࡆ࡙ࡋࠨ༸"):
			HBJbZpwN23hveudOrcI68W0M = A0iaw7hK4Qmc2EeHXZB(AAgpHN0nMZ(u"ࠬࡩࡥ࡯ࡶࡨࡶ༹ࠬ"),kmdSKeBIwViM9t3(u"࠭ฮา๊ฯࠫ༺"),xuYvdJpOEyQKTLNwb(u"ࠧฦำึห้ࠦไๅ็หี๊าࠧ༻"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨวุ่ฬำࠠศๆุ่่๊ษࠨ༼"),ji1dGuYnsFNKe+FhcnOB9t3frzvXb(u"ࠩࠣࠤࠥ࠭༽")+Po4CyOusDaWq6pbIjYV(ji1dGuYnsFNKe),uC9Jwn7rmKIR4EVFoSXay0OqAZQhkl+aVLSn1xw5cK(u"ࠪࡠࡳ࠭༾")+K1GbY6Nz5PDwBAJIyHot3ers)
			if HBJbZpwN23hveudOrcI68W0M==eeIL1TfgFQJaKqVD8hGNPEZ(u"࠲ᘋ"):
				from bYGAkzJECs import HvcsiXhFR9Dw1
				HvcsiXhFR9Dw1()
			elif HBJbZpwN23hveudOrcI68W0M==fR68jBGWCzUsFXdlTKPOScugm(u"࠴ᘌ"): yh04Y1UbKaoD3Lqe6rZTm = wwyUWMFAsO(u"ࡘࡷࡻࡥឲ")
		else: HHTzVhiY079bvdluNkFQ4wCMpe(yTMWeCgUROcvtsblfK85L62xPk(u"ࠫࠬ༿"),kmdSKeBIwViM9t3(u"ࠬ࠭ཀ"),ji1dGuYnsFNKe+fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࠠࠡࠢࠪཁ")+Po4CyOusDaWq6pbIjYV(ji1dGuYnsFNKe),uC9Jwn7rmKIR4EVFoSXay0OqAZQhkl,K1GbY6Nz5PDwBAJIyHot3ers)
	j2agIU0xsLS6c7T.setSetting(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨག"),tgQs4VY5JdLGi9wr)
	return yh04Y1UbKaoD3Lqe6rZTm
def yyGtPJnrR67K(HCjiPmb0nEQkWwl45upRyYTKML6=gSmqZU0plur2xKPJwQA(u"ࡋࡧ࡬ࡴࡧឳ"),vtBfFixzgZ=[]):
	FC2A1KVgqXHYviNGOnkdZBbh6 = [ryc0LEzgSbaI7NqvwJ,P71CANTSyWYptGs8JnZkUHu3Kwi6Ql]+vtBfFixzgZ
	for dhJn8VcYtlwIBb0Su7WFmi in hhHq8m5vauKG9dl.listdir(mATvU6VbxOXNFhz8lK5WGrfQ):
		if HCjiPmb0nEQkWwl45upRyYTKML6 and (dhJn8VcYtlwIBb0Su7WFmi.startswith(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨ࡫ࡳࡸࡻ࠭གྷ")) or dhJn8VcYtlwIBb0Su7WFmi.startswith(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩࡰ࠷ࡺ࠭ང"))): continue
		if dhJn8VcYtlwIBb0Su7WFmi.startswith(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠪࡪ࡮ࡲࡥࡠࠩཅ")): continue
		G8GPiKxEqCb13YD = hhHq8m5vauKG9dl.path.join(mATvU6VbxOXNFhz8lK5WGrfQ,dhJn8VcYtlwIBb0Su7WFmi)
		if G8GPiKxEqCb13YD in FC2A1KVgqXHYviNGOnkdZBbh6: continue
		try: hhHq8m5vauKG9dl.remove(G8GPiKxEqCb13YD)
		except: pass
	if Po8NVKEkyc30eCS not in FC2A1KVgqXHYviNGOnkdZBbh6: Eux3w7MylkQfiBa6pvJO0FWTNbr(Po8NVKEkyc30eCS,aVLSn1xw5cK(u"ࡔࡳࡷࡨ឵"),gSmqZU0plur2xKPJwQA(u"ࡌࡡ࡭ࡵࡨ឴"))
	luMHeSgCBaPrb9KvUjNFqcR.sleep(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠴ᘍ"))
	return
def cCYSjEm8Nph9e2kalIQbFV1oz(rLkEhgxpFKtdDsvWBym7RAo0384,nJDfuczrBG4ZeOs,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,SOlDApJEx73FokmVdYCfKuRNXy8,yJQ0WizojdcChZPM4,rCH9LTAcqthZnFOpU76bxPmWdG,showDialogs,j5jMXZ7myEuoLG,PPwsGxBAMTvE56tL9ohCl=pEo8g7riWVL014KaRtzQ(u"ࡕࡴࡸࡩា"),P8P01rposdK5Vk=pEo8g7riWVL014KaRtzQ(u"ࡕࡴࡸࡩា")):
	XpOsU3v5dqH8MQAK6FcafmP1z0kL2 = XpOsU3v5dqH8MQAK6FcafmP1z0kL2+AAgpHN0nMZ(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫཆ")+rLkEhgxpFKtdDsvWBym7RAo0384
	wvdJxFK9nk = A6F71g3cqN4(JNsoWV1CXc4xy,nJDfuczrBG4ZeOs,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,SOlDApJEx73FokmVdYCfKuRNXy8,yJQ0WizojdcChZPM4,rCH9LTAcqthZnFOpU76bxPmWdG,showDialogs,j5jMXZ7myEuoLG,PPwsGxBAMTvE56tL9ohCl,P8P01rposdK5Vk)
	if XpOsU3v5dqH8MQAK6FcafmP1z0kL2 in wvdJxFK9nk.content: wvdJxFK9nk.succeeded = kRYWcNuAazr4jtmBoxFVS19Z6(u"ࡈࡤࡰࡸ࡫ិ")
	if not wvdJxFK9nk.succeeded:
		iiysxZ8dOaA(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬࡎࡔࡕࡒࠣࡖࡪࡷࡵࡦࡵࡷࠤࡋࡧࡩ࡭ࡷࡵࡩࠬཇ"))
	return wvdJxFK9nk
def UMs29ktLpbBRSh(XpOsU3v5dqH8MQAK6FcafmP1z0kL2):
	wvdJxFK9nk = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,gSmqZU0plur2xKPJwQA(u"࠭ࡇࡆࡖࠪ཈"),XpOsU3v5dqH8MQAK6FcafmP1z0kL2,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠧࠨཉ"),LmcNhzY6fQPd2JyCGslkSr(u"ࠨࠩཊ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࡘࡷࡻࡥឹ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࠪཋ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡒࡕࡓ࡝ࡏࡅࡔࡡࡏࡍࡘ࡚࠭࠲ࡵࡷࠫཌ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࡘࡷࡻࡥឹ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࡉࡥࡱࡹࡥី"))
	ggCHLyDi4dUKlIx9mJrwWu3Fjv56b = []
	if wvdJxFK9nk.succeeded:
		vdCNK2GykrWZIVeg7z5S4HFh = wvdJxFK9nk.content
		W13tTK9XSZCd8IQAxunwrkhEY = ZXFs0mEPR8qI2zj.findall(xuYvdJpOEyQKTLNwb(u"ࠫࠥ࠮࠮ࠫࡁࠬࠤࡡࡪࡻ࠲࠮࠶ࢁࡲࡹࠧཌྷ"),vdCNK2GykrWZIVeg7z5S4HFh)
		if W13tTK9XSZCd8IQAxunwrkhEY: vdCNK2GykrWZIVeg7z5S4HFh = Ej67fFyoqW8kbV2HdSK(u"ࠬࡢ࡮ࠨཎ").join(W13tTK9XSZCd8IQAxunwrkhEY)
		ihuOpLQngBmJo0VavM16WARIN = vdCNK2GykrWZIVeg7z5S4HFh.replace(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭࡜ࡳࠩཏ"),AAgpHN0nMZ(u"ࠧࠨཐ")).strip(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨ࡞ࡱࠫད")).split(FhcnOB9t3frzvXb(u"ࠩ࡟ࡲࠬདྷ"))
		ggCHLyDi4dUKlIx9mJrwWu3Fjv56b = []
		for rLkEhgxpFKtdDsvWBym7RAo0384 in ihuOpLQngBmJo0VavM16WARIN:
			if rLkEhgxpFKtdDsvWBym7RAo0384.count(FhcnOB9t3frzvXb(u"ࠪ࠲ࠬན"))==EDPaWgMt1SwNn8o(u"࠷ᘎ"): ggCHLyDi4dUKlIx9mJrwWu3Fjv56b.append(rLkEhgxpFKtdDsvWBym7RAo0384)
	return ggCHLyDi4dUKlIx9mJrwWu3Fjv56b
def f4drGSDOjlVCqawNQ(*aargs):
	TToznRXkctNLs5h3KIUZ = bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡰࡪ࠰ࡳࡶࡴࡾࡹࡴࡥࡵࡥࡵ࡫࠮ࡤࡱࡰ࠳ࡻ࠸࠯ࡀࡴࡨࡵࡺ࡫ࡳࡵ࠿ࡧ࡭ࡸࡶ࡬ࡢࡻࡳࡶࡴࡾࡩࡦࡵࠩࡴࡷࡵࡸࡺࡶࡼࡴࡪࡃࡨࡵࡶࡳࠪࡹ࡯࡭ࡦࡱࡸࡸࡂ࠷࠰࠱࠲࠳ࠪࡸࡹ࡬࠾ࡻࡨࡷࠫࡲࡩ࡮࡫ࡷࡁ࠶࠶ࠦࡤࡱࡸࡲࡹࡸࡹ࠾ࡐࡏ࠰ࡇࡋࠬࡅࡇ࠯ࡊࡗ࠲ࡇࡃ࠮ࡗࡖࠬཔ")
	bMju4ZHJNhY9Uk = fR68jBGWCzUsFXdlTKPOScugm(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡲࡢࡹ࠱࡫࡮ࡺࡨࡶࡤࡸࡷࡪࡸࡣࡰࡰࡷࡩࡳࡺ࠮ࡤࡱࡰ࠳ࡷࡵ࡯ࡴࡶࡨࡶࡰ࡯ࡤ࠰ࡱࡳࡩࡳࡶࡲࡰࡺࡼࡰ࡮ࡹࡴ࠰࡯ࡤ࡭ࡳ࠵ࡈࡕࡖࡓࡗ࠳ࡺࡸࡵࠩཕ")
	db3PSi7sAnBF4aDm1wCQ0qk9eMJH = UMs29ktLpbBRSh(bMju4ZHJNhY9Uk)
	ggCHLyDi4dUKlIx9mJrwWu3Fjv56b = UMs29ktLpbBRSh(TToznRXkctNLs5h3KIUZ)
	zZrFfMN2PI7EmCc = db3PSi7sAnBF4aDm1wCQ0qk9eMJH+ggCHLyDi4dUKlIx9mJrwWu3Fjv56b
	tr24ZoudmqvxfYCw(kmdSKeBIwViM9t3(u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬབ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧࠡࠢࠣࡋࡴࡺࠠࡱࡴࡲࡼ࡮࡫ࡳࠡ࡮࡬ࡷࡹࠦࠠࠡ࠳ࡶࡸ࠰࠸࡮ࡥ࠼ࠣ࡟ࠥ࠭བྷ")+str(len(db3PSi7sAnBF4aDm1wCQ0qk9eMJH))+OVmSuf8tpd(u"ࠨ࠭ࠪམ")+str(len(ggCHLyDi4dUKlIx9mJrwWu3Fjv56b))+FhcnOB9t3frzvXb(u"ࠩࠣࡡࠬཙ"))
	rLkEhgxpFKtdDsvWBym7RAo0384 = j2agIU0xsLS6c7T.getSetting(fR68jBGWCzUsFXdlTKPOScugm(u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡲࡡࡴࡶࠪཚ"))
	wvdJxFK9nk = o0o6fpDwEd5BMY()
	j2agIU0xsLS6c7T.setSetting(LmcNhzY6fQPd2JyCGslkSr(u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴࡬ࡢࡵࡷࠫཛ"),FhcnOB9t3frzvXb(u"ࠬ࠭ཛྷ"))
	if rLkEhgxpFKtdDsvWBym7RAo0384 or zZrFfMN2PI7EmCc:
		nTSFmel5UBt6bWh,DyGfNV3WpHzPF2CL = pEo8g7riWVL014KaRtzQ(u"࠵ᘏ"),OVmSuf8tpd(u"࠷࠰ᘐ")
		sHDnI4h32NfTVoWiFKrwCJez9YOv = len(zZrFfMN2PI7EmCc)
		Mqg3XC0pbLj1NWJrIAVwa = DyGfNV3WpHzPF2CL
		if sHDnI4h32NfTVoWiFKrwCJez9YOv>Mqg3XC0pbLj1NWJrIAVwa: v2jk8ThPQHMnSdJxX14yI3EaUBKC = Mqg3XC0pbLj1NWJrIAVwa
		else: v2jk8ThPQHMnSdJxX14yI3EaUBKC = sHDnI4h32NfTVoWiFKrwCJez9YOv
		kEcHqsBXxojFamM1u0irDC5 = bnPo1W52UVMRs7Lw6kfG9QdO.sample(zZrFfMN2PI7EmCc,v2jk8ThPQHMnSdJxX14yI3EaUBKC)
		if rLkEhgxpFKtdDsvWBym7RAo0384: kEcHqsBXxojFamM1u0irDC5 = [rLkEhgxpFKtdDsvWBym7RAo0384]+kEcHqsBXxojFamM1u0irDC5
		heWLzsm1OXRnryZJCDVfYx9g = K7Mybc2p4irvPHQ1GaIhjXZ(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࡋࡧ࡬ࡴࡧឺ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࡋࡧ࡬ࡴࡧឺ"))
		BkeMNv4iXH3 = luMHeSgCBaPrb9KvUjNFqcR.time()
		while luMHeSgCBaPrb9KvUjNFqcR.time()-BkeMNv4iXH3<=DyGfNV3WpHzPF2CL and not heWLzsm1OXRnryZJCDVfYx9g.finishedLIST:
			if nTSFmel5UBt6bWh<v2jk8ThPQHMnSdJxX14yI3EaUBKC:
				rLkEhgxpFKtdDsvWBym7RAo0384 = kEcHqsBXxojFamM1u0irDC5[nTSFmel5UBt6bWh]
				heWLzsm1OXRnryZJCDVfYx9g.qDZujpko1NmiSc60L9RIQUgF(nTSFmel5UBt6bWh,cCYSjEm8Nph9e2kalIQbFV1oz,rLkEhgxpFKtdDsvWBym7RAo0384,*aargs)
			luMHeSgCBaPrb9KvUjNFqcR.sleep(gnfv8UtZ3daGqpjzk(u"࠰࠯࠹࠸ᘑ"))
			nTSFmel5UBt6bWh += DLSVmlyBbCK(u"࠲ᘒ")
			tr24ZoudmqvxfYCw(XogUJZEijT7KWbxeO6(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ཝ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+Ej67fFyoqW8kbV2HdSK(u"ࠧࠡࠢࠣࡘࡷࡿࡩ࡯ࡩ࠽ࠤࠥࠦࡐࡳࡱࡻࡽ࠿࡛ࠦࠡࠩཞ")+rLkEhgxpFKtdDsvWBym7RAo0384+JMLhEyaBWmskovGHTrVCxQ08(u"ࠨࠢࡠࠫཟ"))
		finishedLIST = heWLzsm1OXRnryZJCDVfYx9g.finishedLIST
		if finishedLIST:
			resultsDICT = heWLzsm1OXRnryZJCDVfYx9g.resultsDICT
			GnLRWedCQsD8qiEmTt7Jw5SjB4h6 = finishedLIST[yTMWeCgUROcvtsblfK85L62xPk(u"࠲ᘓ")]
			wvdJxFK9nk = resultsDICT[GnLRWedCQsD8qiEmTt7Jw5SjB4h6]
			rLkEhgxpFKtdDsvWBym7RAo0384 = kEcHqsBXxojFamM1u0irDC5[int(GnLRWedCQsD8qiEmTt7Jw5SjB4h6)]
			j2agIU0xsLS6c7T.setSetting(ZSJVq5XDrRot(u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡱࡧࡳࡵࠩའ"),rLkEhgxpFKtdDsvWBym7RAo0384)
			if GnLRWedCQsD8qiEmTt7Jw5SjB4h6!=sArCMRngQNmXkBoKv(u"࠳ᘔ"): tr24ZoudmqvxfYCw(c4QSTnPiWUCjhrLlwGB(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩཡ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+LmcNhzY6fQPd2JyCGslkSr(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪࡹࡳ࠻ࠢࠣࠤࡕࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧར")+rLkEhgxpFKtdDsvWBym7RAo0384+aVLSn1xw5cK(u"ࠬࠦ࡝ࠨལ"))
			else: tr24ZoudmqvxfYCw(Ej67fFyoqW8kbV2HdSK(u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬཤ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+OVmSuf8tpd(u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡵࡶ࠾ࠥࠦࠠࡔࡣࡹࡩࡩࠦࡰࡳࡱࡻࡽ࠿࡛ࠦࠡࠩཥ")+rLkEhgxpFKtdDsvWBym7RAo0384+Ej67fFyoqW8kbV2HdSK(u"ࠨࠢࡠࠫས"))
	return wvdJxFK9nk
def Y53Y7NJ0Hq8bVU1lPv6h(lgptVW8FiCo5EryJXPIHRT,UCnYqvDtGZgPHdaiN2Of48pjL):
	L7Q0esSKyWCzINkXVg9Of2 = lgptVW8FiCo5EryJXPIHRT.create_connection
	def krexW927Rslo4(tyHqXS4juRp85OEel,*aargs,**kkwargs):
		CC462TptPM3lv,pRu510YASI2ikPwnrKZ = tyHqXS4juRp85OEel
		ip = W2wvbMy1zCOsHLnoX4BSJfq9(CC462TptPM3lv,UCnYqvDtGZgPHdaiN2Of48pjL)
		if ip: CC462TptPM3lv = ip[wwyUWMFAsO(u"࠴ᘕ")]
		else:
			if UCnYqvDtGZgPHdaiN2Of48pjL in XK2WaStRNq: XK2WaStRNq.remove(UCnYqvDtGZgPHdaiN2Of48pjL)
			if XK2WaStRNq:
				lhJ2eSHdPEj4ZvLDqN8nXKYWwR0aA = XK2WaStRNq[bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠵ᘖ")]
				ip = W2wvbMy1zCOsHLnoX4BSJfq9(CC462TptPM3lv,lhJ2eSHdPEj4ZvLDqN8nXKYWwR0aA)
				if ip: CC462TptPM3lv = ip[yTMWeCgUROcvtsblfK85L62xPk(u"࠶ᘗ")]
		tyHqXS4juRp85OEel = (CC462TptPM3lv,pRu510YASI2ikPwnrKZ)
		return L7Q0esSKyWCzINkXVg9Of2(tyHqXS4juRp85OEel,*aargs,**kkwargs)
	lgptVW8FiCo5EryJXPIHRT.create_connection = krexW927Rslo4
	return L7Q0esSKyWCzINkXVg9Of2
def joNpfEmWvsCLDA6uBc3x97yeY(XpOsU3v5dqH8MQAK6FcafmP1z0kL2):
	e1OoYdQ2tml4KWDSHfIjA,RJxNLB2doS4Z8m9qgjQziAcf7Fb = XpOsU3v5dqH8MQAK6FcafmP1z0kL2.split(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠩ࠲ࠫཧ"))[kRYWcNuAazr4jtmBoxFVS19Z6(u"࠳ᘙ")],pEo8g7riWVL014KaRtzQ(u"࠸࠱ᘘ")
	if LmcNhzY6fQPd2JyCGslkSr(u"ࠪ࠾ࠬཨ") in e1OoYdQ2tml4KWDSHfIjA: e1OoYdQ2tml4KWDSHfIjA,RJxNLB2doS4Z8m9qgjQziAcf7Fb = e1OoYdQ2tml4KWDSHfIjA.split(J3OCAmZVcn(u"ࠫ࠿࠭ཀྵ"))
	RPCjJZ57Hu = gnfv8UtZ3daGqpjzk(u"ࠬ࠵ࠧཪ")+gnfv8UtZ3daGqpjzk(u"࠭࠯ࠨཫ").join(XpOsU3v5dqH8MQAK6FcafmP1z0kL2.split(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠧ࠰ࠩཬ"))[jYaM5vilgZdFx6QHbApwVXO8et(u"࠵ᘚ"):])
	l3UpyxrXZ2 = gnfv8UtZ3daGqpjzk(u"ࠨࡉࡈࡘࠥ࠭཭")+RPCjJZ57Hu+LmcNhzY6fQPd2JyCGslkSr(u"ࠩࠣࡌ࡙࡚ࡐ࠰࠳࠱࠵ࡡࡸ࡜࡯ࠩ཮")
	l3UpyxrXZ2 += EDPaWgMt1SwNn8o(u"ࠪࡌࡴࡹࡴ࠻ࠢࠪ཯")+e1OoYdQ2tml4KWDSHfIjA+ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠫࡡࡸ࡜࡯ࠩ཰")
	l3UpyxrXZ2 += pEo8g7riWVL014KaRtzQ(u"ࠬࡢࡲ࡝ࡰཱࠪ")
	from socket import socket as z1FdwRrY6OLgZ,AF_INET as MfgOeR2YHEWhp,SOCK_STREAM as r2GOwLkB5Wmasb6EhogVCt1
	try:
		qd0KVG7xXI3gvCnY = z1FdwRrY6OLgZ(MfgOeR2YHEWhp,r2GOwLkB5Wmasb6EhogVCt1)
		qd0KVG7xXI3gvCnY.connect((e1OoYdQ2tml4KWDSHfIjA,RJxNLB2doS4Z8m9qgjQziAcf7Fb))
		qd0KVG7xXI3gvCnY.send(l3UpyxrXZ2.encode(fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࡵࡵࡨ࠻ིࠫ")))
		iMAEFRUXy9gkYJ7DcIod0Ljq4Z = qd0KVG7xXI3gvCnY.recv(fR68jBGWCzUsFXdlTKPOScugm(u"࠸࠵࠿࠶ᘜ")*JMLhEyaBWmskovGHTrVCxQ08(u"࠴࠴࠷࠺ᘛ"))
		vdCNK2GykrWZIVeg7z5S4HFh = repr(iMAEFRUXy9gkYJ7DcIod0Ljq4Z)
	except: vdCNK2GykrWZIVeg7z5S4HFh = bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࠨཱི")
	return vdCNK2GykrWZIVeg7z5S4HFh
def d78KRnJmBWscGua0XMk(Y5Q8P0S7i6bnyGzHgE2jBDkp9,m6egkRrjcavHEdwYDSOs):
	if MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨ࠰ུࠪ") not in Y5Q8P0S7i6bnyGzHgE2jBDkp9: return Y5Q8P0S7i6bnyGzHgE2jBDkp9
	Y5Q8P0S7i6bnyGzHgE2jBDkp9 = Y5Q8P0S7i6bnyGzHgE2jBDkp9+bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩ࠲ཱུࠫ")
	bs7MA0wnVhaODFdSEIpY4Kmkl1grq,b6Em57nN3lqprIfwAPYot42D0 = Y5Q8P0S7i6bnyGzHgE2jBDkp9.split(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪ࠲ࠬྲྀ"),gSmqZU0plur2xKPJwQA(u"࠶ᘝ"))
	VRNrfY0GC8zu2Q7PAUsxKJMOI,PkB8L2ErvzdYRUT = b6Em57nN3lqprIfwAPYot42D0.split(EDPaWgMt1SwNn8o(u"ࠫ࠴࠭ཷ"),JMLhEyaBWmskovGHTrVCxQ08(u"࠷ᘞ"))
	PP2gTKYxLzmf = bs7MA0wnVhaODFdSEIpY4Kmkl1grq+LmcNhzY6fQPd2JyCGslkSr(u"ࠬ࠴ࠧླྀ")+VRNrfY0GC8zu2Q7PAUsxKJMOI
	if m6egkRrjcavHEdwYDSOs in [LmcNhzY6fQPd2JyCGslkSr(u"࠭ࡨࡰࡵࡷࠫཹ"),J3OCAmZVcn(u"ࠧ࡯ࡣࡰࡩེࠬ")] and jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨ࠱ཻࠪ") in PP2gTKYxLzmf: PP2gTKYxLzmf = PP2gTKYxLzmf.rsplit(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠩ࠲ོࠫ"),jYaM5vilgZdFx6QHbApwVXO8et(u"࠱ᘟ"))[jYaM5vilgZdFx6QHbApwVXO8et(u"࠱ᘟ")]
	if m6egkRrjcavHEdwYDSOs==m6b7CoBk4EQ(u"ࠪࡲࡦࡳࡥࠨཽ") and pEo8g7riWVL014KaRtzQ(u"ࠫ࠳࠭ཾ") in PP2gTKYxLzmf:
		LkUXY5yxMecFWmS7IPpghVON4sT2of = PP2gTKYxLzmf.split(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬ࠴ࠧཿ"))
		U2QADirkbfRT7 = len(LkUXY5yxMecFWmS7IPpghVON4sT2of)
		if U2QADirkbfRT7<=PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠴ᘡ") or aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱྀࠫ") in PP2gTKYxLzmf: LkUXY5yxMecFWmS7IPpghVON4sT2of = LkUXY5yxMecFWmS7IPpghVON4sT2of[sArCMRngQNmXkBoKv(u"࠱ᘠ")]
		elif U2QADirkbfRT7>=pEo8g7riWVL014KaRtzQ(u"࠷ᘣ"): LkUXY5yxMecFWmS7IPpghVON4sT2of = LkUXY5yxMecFWmS7IPpghVON4sT2of[fR68jBGWCzUsFXdlTKPOScugm(u"࠴ᘢ")]
		if len(LkUXY5yxMecFWmS7IPpghVON4sT2of)>J3OCAmZVcn(u"࠶ᘤ"): PP2gTKYxLzmf = LkUXY5yxMecFWmS7IPpghVON4sT2of
	return PP2gTKYxLzmf
def PPMg73d1CAKIZS2hvHc5pLmXt4Fsez(gn28RboQ5cpSMq):
	CyZMRenVhLr4AzqlBGYQUWtdNk = repr(gn28RboQ5cpSMq.encode(ZSJVq5XDrRot(u"ࠧࡶࡶࡩ࠼ཱྀࠬ"))).replace(EDPaWgMt1SwNn8o(u"ࠣࠩࠥྂ"),sArCMRngQNmXkBoKv(u"ࠩࠪྃ"))
	return CyZMRenVhLr4AzqlBGYQUWtdNk
def BXdJu6DpcG9k8ieCLWtZ(fUAYaMdi3WZS2ockOzylPerT1):
	KelBjxCJyXGP0wt = JMLhEyaBWmskovGHTrVCxQ08(u"྄ࠪࠫ")
	if Yd6t3PjlLKk: fUAYaMdi3WZS2ockOzylPerT1 = fUAYaMdi3WZS2ockOzylPerT1.decode(m6b7CoBk4EQ(u"ࠫࡺࡺࡦ࠹ࠩ྅"))
	from unicodedata import decomposition as d3Dny8apiLb27shEwS
	for Kajqrzo5LF49k2Q in fUAYaMdi3WZS2ockOzylPerT1:
		if   Kajqrzo5LF49k2Q==m6b7CoBk4EQ(u"ࡺ࠭ยࠨ྆"): H0YL2iklRxFPbO5TBvw6gZ4V = FhcnOB9t3frzvXb(u"࠭࡜࡝ࡷ࠳࠺࠷࠸ࠧ྇")
		elif Kajqrzo5LF49k2Q==xuYvdJpOEyQKTLNwb(u"ࡵࠨลࠪྈ"): H0YL2iklRxFPbO5TBvw6gZ4V = Ej67fFyoqW8kbV2HdSK(u"ࠨ࡞࡟ࡹ࠵࠼࠲࠴ࠩྉ")
		elif Kajqrzo5LF49k2Q==kRYWcNuAazr4jtmBoxFVS19Z6(u"ࡷࠪศࠬྊ"): H0YL2iklRxFPbO5TBvw6gZ4V = bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪࡠࡡࡻ࠰࠷࠴࠷ࠫྋ")
		elif Kajqrzo5LF49k2Q==eeIL1TfgFQJaKqVD8hGNPEZ(u"ࡹࠬหࠧྌ"): H0YL2iklRxFPbO5TBvw6gZ4V = kmdSKeBIwViM9t3(u"ࠬࡢ࡜ࡶ࠲࠹࠶࠺࠭ྍ")
		elif Kajqrzo5LF49k2Q==gnfv8UtZ3daGqpjzk(u"ࡻࠧวࠩྎ"): H0YL2iklRxFPbO5TBvw6gZ4V = JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠧ࡝࡞ࡸ࠴࠻࠸࠶ࠨྏ")
		else:
			EcpJ09fL1s5xNkW2ZA = d3Dny8apiLb27shEwS(Kajqrzo5LF49k2Q)
			if eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨࠢࠪྐ") in EcpJ09fL1s5xNkW2ZA: H0YL2iklRxFPbO5TBvw6gZ4V = aVLSn1xw5cK(u"ࠩ࡟ࡠࡺ࠭ྑ")+EcpJ09fL1s5xNkW2ZA.split(gnfv8UtZ3daGqpjzk(u"ࠪࠤࠬྒ"),LmcNhzY6fQPd2JyCGslkSr(u"࠷ᘥ"))[LmcNhzY6fQPd2JyCGslkSr(u"࠷ᘥ")]
			else:
				H0YL2iklRxFPbO5TBvw6gZ4V = AAgpHN0nMZ(u"ࠫ࠵࠶࠰࠱ࠩྒྷ")+hex(ord(Kajqrzo5LF49k2Q)).replace(xuYvdJpOEyQKTLNwb(u"ࠬ࠶ࡸࠨྔ"),pEo8g7riWVL014KaRtzQ(u"࠭ࠧྕ"))
				H0YL2iklRxFPbO5TBvw6gZ4V = yTMWeCgUROcvtsblfK85L62xPk(u"ࠧ࡝࡞ࡸࠫྖ")+H0YL2iklRxFPbO5TBvw6gZ4V[-c4QSTnPiWUCjhrLlwGB(u"࠴ᘦ"):]
		KelBjxCJyXGP0wt += H0YL2iklRxFPbO5TBvw6gZ4V
	KelBjxCJyXGP0wt = KelBjxCJyXGP0wt.replace(J3OCAmZVcn(u"ࠨ࡞࡟ࡹ࠵࠼ࡃࡄࠩྗ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩ࡟ࡠࡺ࠶࠶࠵࠻ࠪ྘"))
	if Yd6t3PjlLKk: KelBjxCJyXGP0wt = KelBjxCJyXGP0wt.decode(J3OCAmZVcn(u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫྙ")).encode(xuYvdJpOEyQKTLNwb(u"ࠫࡺࡺࡦ࠹ࠩྚ"))
	else: KelBjxCJyXGP0wt = KelBjxCJyXGP0wt.encode(OVmSuf8tpd(u"ࠬࡻࡴࡧ࠺ࠪྛ")).decode(kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧྜ"))
	return KelBjxCJyXGP0wt
def CjyEnpfQ23o0PYwDtLId(header=FhcnOB9t3frzvXb(u"ࠧๅ๊ะอࠥอไๆใสฮ๏ำࠧྜྷ"),yj4nE0cZHBgXfbT2xM5ovmF3AJN=JMLhEyaBWmskovGHTrVCxQ08(u"ࠨࠩྞ"),CPbq1NQUeTzahYdiXFO2=eeIL1TfgFQJaKqVD8hGNPEZ(u"ࡌࡡ࡭ࡵࡨុ"),source=Ej67fFyoqW8kbV2HdSK(u"ࠩࠪྟ")):
	unjzvHfWpPTbqACy9RtOY6m = swETIMKAyfzL(header,yj4nE0cZHBgXfbT2xM5ovmF3AJN,type=kGEPsyxKnHDJ.INPUT_ALPHANUM)
	unjzvHfWpPTbqACy9RtOY6m = unjzvHfWpPTbqACy9RtOY6m.replace(DLSVmlyBbCK(u"ࠪࠤࠥ࠭ྠ"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࠥ࠭ྡ")).replace(pEo8g7riWVL014KaRtzQ(u"ࠬࠦࠠࠨྡྷ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭ࠠࠨྣ")).replace(aVLSn1xw5cK(u"ࠧࠡࠢࠪྤ"),EDPaWgMt1SwNn8o(u"ࠨࠢࠪྥ"))
	if not unjzvHfWpPTbqACy9RtOY6m and not CPbq1NQUeTzahYdiXFO2:
		tr24ZoudmqvxfYCw(XogUJZEijT7KWbxeO6(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩྦ"),m6b7CoBk4EQ(u"ࠪ࠲ࠥࠦࡋࡦࡻࡥࡳࡦࡸࡤࠡࡧࡱࡸࡷࡿࠠࡤࡣࡱࡧࡪࡲࡥࡥ࠼ࠣࠤࠥࠨࠧྦྷ")+unjzvHfWpPTbqACy9RtOY6m+wwyUWMFAsO(u"ࠫࠧ࠭ྨ"))
		HHTzVhiY079bvdluNkFQ4wCMpe(m6b7CoBk4EQ(u"ࠬ࠭ྩ"),wwyUWMFAsO(u"࠭ࠧྪ"),AAgpHN0nMZ(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪྫ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨฬ่ࠤสฺ๊ศรࠣห้หฯฯษ็ࠫྫྷ"))
		return kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩࠪྭ")
	if unjzvHfWpPTbqACy9RtOY6m not in [AAgpHN0nMZ(u"ࠪࠫྮ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠫࠥ࠭ྯ")]:
		unjzvHfWpPTbqACy9RtOY6m = unjzvHfWpPTbqACy9RtOY6m.strip(LmcNhzY6fQPd2JyCGslkSr(u"ࠬࠦࠧྰ"))
		unjzvHfWpPTbqACy9RtOY6m = BXdJu6DpcG9k8ieCLWtZ(unjzvHfWpPTbqACy9RtOY6m)
	if source!=LmcNhzY6fQPd2JyCGslkSr(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓࠨྱ") and GBC7yanr9WNYIKXSHRxgP(ZSJVq5XDrRot(u"ࠧࡌࡇ࡜ࡆࡔࡇࡒࡅࠩྲ"),FhcnOB9t3frzvXb(u"ࠨࠩླ"),[unjzvHfWpPTbqACy9RtOY6m],eeIL1TfgFQJaKqVD8hGNPEZ(u"ࡆࡢ࡮ࡶࡩូ")):
		tr24ZoudmqvxfYCw(XogUJZEijT7KWbxeO6(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩྴ"),xuYvdJpOEyQKTLNwb(u"ࠪ࠲ࠥࠦࡋࡦࡻࡥࡳࡦࡸࡤࠡࡧࡱࡸࡷࡿࠠࡣ࡮ࡲࡧࡰ࡫ࡤ࠻ࠢࠣࠤࠧ࠭ྵ")+unjzvHfWpPTbqACy9RtOY6m+EDPaWgMt1SwNn8o(u"ࠫࠧ࠭ྶ"))
		HHTzVhiY079bvdluNkFQ4wCMpe(yTMWeCgUROcvtsblfK85L62xPk(u"ࠬ࠭ྷ"),xuYvdJpOEyQKTLNwb(u"࠭ࠧྸ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪྐྵ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨษ้ฮ้ࠥสษฬࠣ็้๋ษࠡล๋ࠤึ่ๅࠡๆ๊ࠤ฾๊วใหࠣฬศ็ไศ็่้้ࠣศศำࠣๅ็฽ࠠ࠯࠰ࠣ์์ึวࠡษ็ฬึ์วๆฮ่ࠣฬ๊ࠦิ็ะࠤออำหะาห๊ࠦ็ไาสࠤ่๊ๅศฬࠪྺ"))
		return fR68jBGWCzUsFXdlTKPOScugm(u"ࠩࠪྻ")
	tr24ZoudmqvxfYCw(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪྼ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠫ࠳ࠦࠠࡌࡧࡼࡦࡴࡧࡲࡥࠢࡨࡲࡹࡸࡹࠡࡣ࡯ࡰࡴࡽࡥࡥ࠼ࠣࠤࠥࠨࠧ྽")+unjzvHfWpPTbqACy9RtOY6m+JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬࠨࠧ྾"))
	return unjzvHfWpPTbqACy9RtOY6m
def c8T0X52CGk9UZ71q(lQHXdV9Nzf6BLqS8D,obS4TpHeV3digGC={}):
	XpOsU3v5dqH8MQAK6FcafmP1z0kL2,fWQY1RuVslvpd96CAKOHiI4F,mmlnqfTsuZdaMx7I3rDEYgo,vvqEwLb8kAfuJtxBCX7K1V6jI0l = lQHXdV9Nzf6BLqS8D,{},{},aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠭ࠧ྿")
	if XogUJZEijT7KWbxeO6(u"ࠧࡽࠩ࿀") in lQHXdV9Nzf6BLqS8D: XpOsU3v5dqH8MQAK6FcafmP1z0kL2,fWQY1RuVslvpd96CAKOHiI4F = hGMVvHBuPC014(lQHXdV9Nzf6BLqS8D,Ej67fFyoqW8kbV2HdSK(u"ࠨࡾࠪ࿁"))
	NO8fFSIKHigoc0 = list(set(list(obS4TpHeV3digGC.keys())+list(fWQY1RuVslvpd96CAKOHiI4F.keys())))
	for qWMXl6rZ1seT2NBhn in NO8fFSIKHigoc0:
		if qWMXl6rZ1seT2NBhn in list(fWQY1RuVslvpd96CAKOHiI4F.keys()): mmlnqfTsuZdaMx7I3rDEYgo[qWMXl6rZ1seT2NBhn] = fWQY1RuVslvpd96CAKOHiI4F[qWMXl6rZ1seT2NBhn]
		else: mmlnqfTsuZdaMx7I3rDEYgo[qWMXl6rZ1seT2NBhn] = obS4TpHeV3digGC[qWMXl6rZ1seT2NBhn]
	if kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭࿂") not in NO8fFSIKHigoc0: mmlnqfTsuZdaMx7I3rDEYgo[jYaM5vilgZdFx6QHbApwVXO8et(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ࿃")] = SjMG7CYyUqbPVso0DErhXROvkl()
	if kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ࿄") not in NO8fFSIKHigoc0: mmlnqfTsuZdaMx7I3rDEYgo[MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭࿅")] = d78KRnJmBWscGua0XMk(XpOsU3v5dqH8MQAK6FcafmP1z0kL2,OVmSuf8tpd(u"࠭ࡵࡳ࡮࿆ࠪ"))
	if ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡍࡣࡱ࡫ࡺࡧࡧࡦࠩ࿇") not in NO8fFSIKHigoc0: mmlnqfTsuZdaMx7I3rDEYgo[MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡎࡤࡲ࡬ࡻࡡࡨࡧࠪ࿈")] = fR68jBGWCzUsFXdlTKPOScugm(u"ࠩࡨࡲ࠲࡛ࡓ࠭ࡧࡱ࠿ࡶࡃ࠰࠯࠻ࠪ࿉")
	for qWMXl6rZ1seT2NBhn in list(mmlnqfTsuZdaMx7I3rDEYgo.keys()): vvqEwLb8kAfuJtxBCX7K1V6jI0l += MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࠪࠬ࿊")+qWMXl6rZ1seT2NBhn+bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠫࡂ࠭࿋")+mmlnqfTsuZdaMx7I3rDEYgo[qWMXl6rZ1seT2NBhn]
	if vvqEwLb8kAfuJtxBCX7K1V6jI0l: vvqEwLb8kAfuJtxBCX7K1V6jI0l = m6b7CoBk4EQ(u"ࠬࢂࠧ࿌")+vvqEwLb8kAfuJtxBCX7K1V6jI0l[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠲ᘧ"):]
	wvdJxFK9nk = A6F71g3cqN4(RwhaLmQ4cpyvfxsPUJVA0DtM,OVmSuf8tpd(u"࠭ࡇࡆࡖࠪ࿍"),XpOsU3v5dqH8MQAK6FcafmP1z0kL2,aVLSn1xw5cK(u"ࠧࠨ࿎"),mmlnqfTsuZdaMx7I3rDEYgo,LmcNhzY6fQPd2JyCGslkSr(u"ࠨࠩ࿏"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩࠪ࿐"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡊ࡞ࡔࡓࡃࡆࡘࡤࡓ࠳ࡖ࠺࠰࠵ࡸࡺࠧ࿑"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࡇࡣ࡯ࡷࡪួ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࡇࡣ࡯ࡷࡪួ"))
	vdCNK2GykrWZIVeg7z5S4HFh = wvdJxFK9nk.content
	if LmcNhzY6fQPd2JyCGslkSr(u"ࠫࡘ࡚ࡒࡆࡃࡐ࠱ࡎࡔࡆࠨ࿒") not in vdCNK2GykrWZIVeg7z5S4HFh: return [kmdSKeBIwViM9t3(u"ࠬ࠳࠱ࠨ࿓")],[XpOsU3v5dqH8MQAK6FcafmP1z0kL2+vvqEwLb8kAfuJtxBCX7K1V6jI0l]
	if XogUJZEijT7KWbxeO6(u"࠭ࡔ࡚ࡒࡈࡁࡆ࡛ࡄࡊࡑࠪ࿔") in vdCNK2GykrWZIVeg7z5S4HFh: return [LmcNhzY6fQPd2JyCGslkSr(u"ࠧ࠮࠳ࠪ࿕")],[XpOsU3v5dqH8MQAK6FcafmP1z0kL2+vvqEwLb8kAfuJtxBCX7K1V6jI0l]
	if aVLSn1xw5cK(u"ࠨࡖ࡜ࡔࡊࡃࡖࡊࡆࡈࡓࠬ࿖") in vdCNK2GykrWZIVeg7z5S4HFh: return [aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩ࠰࠵ࠬ࿗")],[XpOsU3v5dqH8MQAK6FcafmP1z0kL2+vvqEwLb8kAfuJtxBCX7K1V6jI0l]
	xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd,iifVwOrYkW,FrwJ3STYZfKj1HIWQy = [],[],[],[]
	YYyAscnV8LouaiJz = ZXFs0mEPR8qI2zj.findall(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠪࠧࡊ࡞ࡔ࠮࡚࠰ࡗ࡙ࡘࡅࡂࡏ࠰ࡍࡓࡌ࠺ࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮ࠫ࿘"),vdCNK2GykrWZIVeg7z5S4HFh+FhcnOB9t3frzvXb(u"ࠫࡡࡴࠧ࿙"),ZXFs0mEPR8qI2zj.DOTALL)
	if not YYyAscnV8LouaiJz: return [ZSJVq5XDrRot(u"ࠬ࠳࠱ࠨ࿚")],[XpOsU3v5dqH8MQAK6FcafmP1z0kL2+vvqEwLb8kAfuJtxBCX7K1V6jI0l]
	for fl6EYgtdJCZOcNaLpnUrDHQ,Y5Q8P0S7i6bnyGzHgE2jBDkp9 in YYyAscnV8LouaiJz:
		RRclq657NkdjGVnzxOKIZTuJFaW,TzMbHrQSJ5AVKxmOY,PHUqTNVJ0ErRSwibn5gD = {},-AAgpHN0nMZ(u"࠳ᘨ"),-AAgpHN0nMZ(u"࠳ᘨ")
		CjghrR26plQ = FhcnOB9t3frzvXb(u"࠭ࠧ࿛")
		OHnId4ojGSuQ2KZPfaEeCm7py1q = fl6EYgtdJCZOcNaLpnUrDHQ.split(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠧ࠭ࠩ࿜"))
		for fdmbuvJpzy in OHnId4ojGSuQ2KZPfaEeCm7py1q:
			if c4QSTnPiWUCjhrLlwGB(u"ࠨ࠿ࠪ࿝") in fdmbuvJpzy:
				qWMXl6rZ1seT2NBhn,A6zIXayOqBNEgorvnD7dwUspk = fdmbuvJpzy.split(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠩࡀࠫ࿞"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠴ᘩ"))
				RRclq657NkdjGVnzxOKIZTuJFaW[qWMXl6rZ1seT2NBhn.lower()] = A6zIXayOqBNEgorvnD7dwUspk
		if DLSVmlyBbCK(u"ࠪࡥࡻ࡫ࡲࡢࡩࡨ࠱ࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮ࠧ࿟") in fl6EYgtdJCZOcNaLpnUrDHQ.lower():
			TzMbHrQSJ5AVKxmOY = int(RRclq657NkdjGVnzxOKIZTuJFaW[kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫࡦࡼࡥࡳࡣࡪࡩ࠲ࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨࠨ࿠")])//hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠵࠵࠸࠴ᘪ")
			CjghrR26plQ += str(TzMbHrQSJ5AVKxmOY)+hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠬࡱࡢࡱࡵࠣࠤࠬ࿡")
		elif pEo8g7riWVL014KaRtzQ(u"࠭ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩ࿢") in fl6EYgtdJCZOcNaLpnUrDHQ.lower():
			TzMbHrQSJ5AVKxmOY = int(RRclq657NkdjGVnzxOKIZTuJFaW[xuYvdJpOEyQKTLNwb(u"ࠧࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪ࿣")])//c4QSTnPiWUCjhrLlwGB(u"࠶࠶࠲࠵ᘫ")
			CjghrR26plQ += str(TzMbHrQSJ5AVKxmOY)+Ej67fFyoqW8kbV2HdSK(u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ࿤")
		if gnfv8UtZ3daGqpjzk(u"ࠩࡵࡩࡸࡵ࡬ࡶࡶ࡬ࡳࡳ࠭࿥") in fl6EYgtdJCZOcNaLpnUrDHQ.lower():
			PHUqTNVJ0ErRSwibn5gD = int(RRclq657NkdjGVnzxOKIZTuJFaW[sArCMRngQNmXkBoKv(u"ࠪࡶࡪࡹ࡯࡭ࡷࡷ࡭ࡴࡴࠧ࿦")].split(EDPaWgMt1SwNn8o(u"ࠫࡽ࠭࿧"))[ZSJVq5XDrRot(u"࠷ᘬ")])
			CjghrR26plQ += str(PHUqTNVJ0ErRSwibn5gD)+pEo8g7riWVL014KaRtzQ(u"ࠬࠦࠠࠨ࿨")
		CjghrR26plQ = CjghrR26plQ.strip(wwyUWMFAsO(u"࠭ࠠࠡࠩ࿩"))
		if not CjghrR26plQ: CjghrR26plQ = gnfv8UtZ3daGqpjzk(u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠨ࿪")
		if not Y5Q8P0S7i6bnyGzHgE2jBDkp9.startswith(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨࡪࡷࡸࡵ࠭࿫")):
			if Y5Q8P0S7i6bnyGzHgE2jBDkp9.startswith(EDPaWgMt1SwNn8o(u"ࠩ࠲࠳ࠬ࿬")): Y5Q8P0S7i6bnyGzHgE2jBDkp9 = XpOsU3v5dqH8MQAK6FcafmP1z0kL2.split(J3OCAmZVcn(u"ࠪ࠾ࠬ࿭"),JMLhEyaBWmskovGHTrVCxQ08(u"࠱ᘭ"))[aVLSn1xw5cK(u"࠱ᘮ")]+AAgpHN0nMZ(u"ࠫ࠿࠭࿮")+Y5Q8P0S7i6bnyGzHgE2jBDkp9
			elif Y5Q8P0S7i6bnyGzHgE2jBDkp9.startswith(sArCMRngQNmXkBoKv(u"ࠬ࠵ࠧ࿯")): Y5Q8P0S7i6bnyGzHgE2jBDkp9 = d78KRnJmBWscGua0XMk(XpOsU3v5dqH8MQAK6FcafmP1z0kL2,wwyUWMFAsO(u"࠭ࡵࡳ࡮ࠪ࿰"))+Y5Q8P0S7i6bnyGzHgE2jBDkp9
			else: Y5Q8P0S7i6bnyGzHgE2jBDkp9 = XpOsU3v5dqH8MQAK6FcafmP1z0kL2.rsplit(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧ࠰ࠩ࿱"),c4QSTnPiWUCjhrLlwGB(u"࠳ᘯ"))[DLSVmlyBbCK(u"࠳ᘰ")]+MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨ࠱ࠪ࿲")+Y5Q8P0S7i6bnyGzHgE2jBDkp9
		if PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࡳࡶࡴ࡭ࡲࡦࡵࡶ࡭ࡻ࡫࠭ࡶࡴ࡬ࠫ࿳") in list(RRclq657NkdjGVnzxOKIZTuJFaW.keys()):
			oKqQr8Ij0btxZ9SDm6h3Nd = RRclq657NkdjGVnzxOKIZTuJFaW[LmcNhzY6fQPd2JyCGslkSr(u"ࠪࡴࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥ࠮ࡷࡵ࡭ࠬ࿴")]
			oKqQr8Ij0btxZ9SDm6h3Nd = oKqQr8Ij0btxZ9SDm6h3Nd.replace(gSmqZU0plur2xKPJwQA(u"ࠫࠧ࠭࿵"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠬ࠭࿶")).replace(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠨࠧࠣ࿷"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧࠨ࿸")).split(J3OCAmZVcn(u"ࠨࠥࠪ࿹"),EDPaWgMt1SwNn8o(u"࠵ᘱ"))[aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠵ᘲ")]
			n2wpUdA6KX4kLjJGxZWVieycPg = fDEdQSsq1uPoU(oKqQr8Ij0btxZ9SDm6h3Nd)
			if n2wpUdA6KX4kLjJGxZWVieycPg: Wu4CadwRTJfkbXMUVxO3jQ2 = CjghrR26plQ+wwyUWMFAsO(u"ࠩࠣࠤࠬ࿺")+n2wpUdA6KX4kLjJGxZWVieycPg
			else: Wu4CadwRTJfkbXMUVxO3jQ2 = CjghrR26plQ
			Wu4CadwRTJfkbXMUVxO3jQ2 = Wu4CadwRTJfkbXMUVxO3jQ2+PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࠤࠥࡖࡲࡰࡩࡵࡩࡸࡹࡩࡷࡧࠪ࿻")
			Wu4CadwRTJfkbXMUVxO3jQ2 = Wu4CadwRTJfkbXMUVxO3jQ2+EDPaWgMt1SwNn8o(u"ࠫࠥࠦࠧ࿼")+d78KRnJmBWscGua0XMk(oKqQr8Ij0btxZ9SDm6h3Nd,EDPaWgMt1SwNn8o(u"ࠬࡴࡡ࡮ࡧࠪ࿽"))
			xCLQK8kh39sjyi5DXSZAVeI.append(Wu4CadwRTJfkbXMUVxO3jQ2)
			YYmyQXglbEewzL3IA2Sd.append(oKqQr8Ij0btxZ9SDm6h3Nd)
			iifVwOrYkW.append(PHUqTNVJ0ErRSwibn5gD)
			FrwJ3STYZfKj1HIWQy.append(TzMbHrQSJ5AVKxmOY)
		Y5Q8P0S7i6bnyGzHgE2jBDkp9 = Y5Q8P0S7i6bnyGzHgE2jBDkp9.split(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭ࠣࠨ࿾"),xuYvdJpOEyQKTLNwb(u"࠷ᘳ"))[c4QSTnPiWUCjhrLlwGB(u"࠰ᘴ")]
		n2wpUdA6KX4kLjJGxZWVieycPg = fDEdQSsq1uPoU(Y5Q8P0S7i6bnyGzHgE2jBDkp9)
		if n2wpUdA6KX4kLjJGxZWVieycPg: CjghrR26plQ = CjghrR26plQ+DLSVmlyBbCK(u"ࠧࠡࠢࠪ࿿")+n2wpUdA6KX4kLjJGxZWVieycPg
		CjghrR26plQ = CjghrR26plQ+gnfv8UtZ3daGqpjzk(u"ࠨࠢࠣࠫက")+d78KRnJmBWscGua0XMk(Y5Q8P0S7i6bnyGzHgE2jBDkp9,DLSVmlyBbCK(u"ࠩࡱࡥࡲ࡫ࠧခ"))
		xCLQK8kh39sjyi5DXSZAVeI.append(CjghrR26plQ)
		YYmyQXglbEewzL3IA2Sd.append(Y5Q8P0S7i6bnyGzHgE2jBDkp9)
		iifVwOrYkW.append(PHUqTNVJ0ErRSwibn5gD)
		FrwJ3STYZfKj1HIWQy.append(TzMbHrQSJ5AVKxmOY)
	xPDZRXulfK5CvcTz0gbV = list(zip(xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd,iifVwOrYkW,FrwJ3STYZfKj1HIWQy))
	xPDZRXulfK5CvcTz0gbV = sorted(xPDZRXulfK5CvcTz0gbV, reverse=m6b7CoBk4EQ(u"ࡖࡵࡹࡪើ"), key=lambda key: key[m6b7CoBk4EQ(u"࠴ᘵ")])
	xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd,iifVwOrYkW,FrwJ3STYZfKj1HIWQy = list(zip(*xPDZRXulfK5CvcTz0gbV))
	xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = list(xCLQK8kh39sjyi5DXSZAVeI),list(YYmyQXglbEewzL3IA2Sd)
	bFEOBVfxy7nPvCdgta1U = []
	for Y5Q8P0S7i6bnyGzHgE2jBDkp9 in YYmyQXglbEewzL3IA2Sd: bFEOBVfxy7nPvCdgta1U.append(Y5Q8P0S7i6bnyGzHgE2jBDkp9+vvqEwLb8kAfuJtxBCX7K1V6jI0l)
	return xCLQK8kh39sjyi5DXSZAVeI,bFEOBVfxy7nPvCdgta1U
def W2wvbMy1zCOsHLnoX4BSJfq9(CC462TptPM3lv,UCnYqvDtGZgPHdaiN2Of48pjL=yTMWeCgUROcvtsblfK85L62xPk(u"ࠪࠫဂ")):
	if not UCnYqvDtGZgPHdaiN2Of48pjL: UCnYqvDtGZgPHdaiN2Of48pjL = XK2WaStRNq[aVLSn1xw5cK(u"࠲ᘶ")]
	if CC462TptPM3lv.replace(yTMWeCgUROcvtsblfK85L62xPk(u"ࠫ࠳࠭ဃ"),aVLSn1xw5cK(u"ࠬ࠭င")).isdigit(): return [CC462TptPM3lv]
	from struct import pack as af4mJngXdESRoGv35FthQ9LD,unpack_from as Oyl0LCKQDYkbFPigBtXu
	from socket import socket as z1FdwRrY6OLgZ,AF_INET as MfgOeR2YHEWhp,SOCK_DGRAM as tyq1D0a9wsmBOo
	try:
		ffN3HnYgxumlC = af4mJngXdESRoGv35FthQ9LD(OVmSuf8tpd(u"ࠨ࠾ࡉࠤစ"), Ej67fFyoqW8kbV2HdSK(u"࠴࠶࠵࠺࠹ᘷ"))
		ffN3HnYgxumlC += af4mJngXdESRoGv35FthQ9LD(XogUJZEijT7KWbxeO6(u"ࠢ࠿ࡊࠥဆ"), kRYWcNuAazr4jtmBoxFVS19Z6(u"࠶࠺࠼ᘸ"))
		ffN3HnYgxumlC += af4mJngXdESRoGv35FthQ9LD(xuYvdJpOEyQKTLNwb(u"ࠣࡀࡋࠦဇ"), ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠶ᘹ"))
		ffN3HnYgxumlC += af4mJngXdESRoGv35FthQ9LD(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠤࡁࡌࠧဈ"), EDPaWgMt1SwNn8o(u"࠶ᘺ"))
		ffN3HnYgxumlC += af4mJngXdESRoGv35FthQ9LD(kmdSKeBIwViM9t3(u"ࠥࡂࡍࠨဉ"), ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠰ᘻ"))
		ffN3HnYgxumlC += af4mJngXdESRoGv35FthQ9LD(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠦࡃࡎࠢည"), kRYWcNuAazr4jtmBoxFVS19Z6(u"࠱ᘼ"))
		if VYMZsxRpcQHPgkaiDKjyoh: tgVplb1Msy0K9cqE8WReahT = CC462TptPM3lv.split(XogUJZEijT7KWbxeO6(u"ࠬ࠴ࠧဋ"))
		else: tgVplb1Msy0K9cqE8WReahT = CC462TptPM3lv.decode(DLSVmlyBbCK(u"࠭ࡵࡵࡨ࠻ࠫဌ")).split(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧ࠯ࠩဍ"))
		for gqX7BtKEdWs4ZYpuSxHn in tgVplb1Msy0K9cqE8WReahT:
			jF2KuMdwrgW = gqX7BtKEdWs4ZYpuSxHn.encode(J3OCAmZVcn(u"ࠨࡷࡷࡪ࠽࠭ဎ"))
			ffN3HnYgxumlC += af4mJngXdESRoGv35FthQ9LD(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠤࡅࠦဏ"), len(gqX7BtKEdWs4ZYpuSxHn))
			for qq1tpxa5d0L in gqX7BtKEdWs4ZYpuSxHn:
				ffN3HnYgxumlC += af4mJngXdESRoGv35FthQ9LD(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠥࡧࠧတ"), qq1tpxa5d0L.encode(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠫࡺࡺࡦ࠹ࠩထ")))
		ffN3HnYgxumlC += af4mJngXdESRoGv35FthQ9LD(kmdSKeBIwViM9t3(u"ࠧࡈࠢဒ"), m6b7CoBk4EQ(u"࠲ᘽ"))
		ffN3HnYgxumlC += af4mJngXdESRoGv35FthQ9LD(wwyUWMFAsO(u"ࠨ࠾ࡉࠤဓ"), aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠴ᘾ"))
		ffN3HnYgxumlC += af4mJngXdESRoGv35FthQ9LD(gnfv8UtZ3daGqpjzk(u"ࠢ࠿ࡊࠥန"), kmdSKeBIwViM9t3(u"࠵ᘿ"))
		EtVLHXqGIwQjlpDFcRabZ123 = z1FdwRrY6OLgZ(MfgOeR2YHEWhp,tyq1D0a9wsmBOo)
		EtVLHXqGIwQjlpDFcRabZ123.sendto(bytes(ffN3HnYgxumlC), (UCnYqvDtGZgPHdaiN2Of48pjL, yTMWeCgUROcvtsblfK85L62xPk(u"࠺࠹ᙀ")))
		EtVLHXqGIwQjlpDFcRabZ123.settimeout(bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠼ᙁ"))
		SOlDApJEx73FokmVdYCfKuRNXy8, wM8VDauE2mpxINAqnkeK3 = EtVLHXqGIwQjlpDFcRabZ123.recvfrom(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠱࠱࠴࠷ᙂ"))
		EtVLHXqGIwQjlpDFcRabZ123.close()
		FNDdj4AkalbBLrS8fMPxG5uismOJQ = Oyl0LCKQDYkbFPigBtXu(c4QSTnPiWUCjhrLlwGB(u"ࠣࡀࡋࡌࡍࡎࡈࡉࠤပ"), SOlDApJEx73FokmVdYCfKuRNXy8, FhcnOB9t3frzvXb(u"࠱ᙃ"))
		PPexYUiGgBwKFvA8N1aCq0 = FNDdj4AkalbBLrS8fMPxG5uismOJQ[xuYvdJpOEyQKTLNwb(u"࠵ᙄ")]
		xbZtO3B7DA9G1CPUTeFSgERXar4 = len(CC462TptPM3lv)+kRYWcNuAazr4jtmBoxFVS19Z6(u"࠴࠼ᙅ")
		xOV4lRWI2Ak37E = []
		for _0hYPQ2BKepX in range(PPexYUiGgBwKFvA8N1aCq0):
			D1BEgfsTZw7QiV = xbZtO3B7DA9G1CPUTeFSgERXar4
			EEKxvXfHb7JlZ6eRDoiGLcn0IBF = yTMWeCgUROcvtsblfK85L62xPk(u"࠵ᙆ")
			BpYHn0ye1Jw7 = MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࡉࡥࡱࡹࡥឿ")
			while wwyUWMFAsO(u"ࡘࡷࡻࡥៀ"):
				qq1tpxa5d0L = Oyl0LCKQDYkbFPigBtXu(EDPaWgMt1SwNn8o(u"ࠤࡁࡆࠧဖ"), SOlDApJEx73FokmVdYCfKuRNXy8, D1BEgfsTZw7QiV)[jYaM5vilgZdFx6QHbApwVXO8et(u"࠵ᙇ")]
				if qq1tpxa5d0L == XogUJZEijT7KWbxeO6(u"࠶ᙈ"):
					D1BEgfsTZw7QiV += kmdSKeBIwViM9t3(u"࠱ᙉ")
					break
				if qq1tpxa5d0L >= FhcnOB9t3frzvXb(u"࠲࠻࠵ᙊ"):
					LHd726txcKonRpJhEg0GYrsN5b8QI = Oyl0LCKQDYkbFPigBtXu(gnfv8UtZ3daGqpjzk(u"ࠥࡂࡇࠨဗ"), SOlDApJEx73FokmVdYCfKuRNXy8, D1BEgfsTZw7QiV + PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠳ᙋ"))[FhcnOB9t3frzvXb(u"࠳ᙌ")]
					D1BEgfsTZw7QiV = ((qq1tpxa5d0L << aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠽ᙎ")) + LHd726txcKonRpJhEg0GYrsN5b8QI - 0xc000) - DLSVmlyBbCK(u"࠵ᙍ")
					BpYHn0ye1Jw7 = eeIL1TfgFQJaKqVD8hGNPEZ(u"࡙ࡸࡵࡦេ")
				D1BEgfsTZw7QiV += yTMWeCgUROcvtsblfK85L62xPk(u"࠷ᙏ")
				if BpYHn0ye1Jw7 == m6b7CoBk4EQ(u"ࡌࡡ࡭ࡵࡨែ"): EEKxvXfHb7JlZ6eRDoiGLcn0IBF += kmdSKeBIwViM9t3(u"࠱ᙐ")
			if BpYHn0ye1Jw7 == MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࡔࡳࡷࡨៃ"): EEKxvXfHb7JlZ6eRDoiGLcn0IBF += sArCMRngQNmXkBoKv(u"࠲ᙑ")
			xbZtO3B7DA9G1CPUTeFSgERXar4 = xbZtO3B7DA9G1CPUTeFSgERXar4 + EEKxvXfHb7JlZ6eRDoiGLcn0IBF
			VqOEwjTfex = Oyl0LCKQDYkbFPigBtXu(AAgpHN0nMZ(u"ࠦࡃࡎࡈࡊࡊࠥဘ"), SOlDApJEx73FokmVdYCfKuRNXy8, xbZtO3B7DA9G1CPUTeFSgERXar4)
			xbZtO3B7DA9G1CPUTeFSgERXar4 = xbZtO3B7DA9G1CPUTeFSgERXar4 + aVLSn1xw5cK(u"࠳࠳ᙒ")
			ii78yUzafOvcDH4uC5BsITm = VqOEwjTfex[ZSJVq5XDrRot(u"࠳ᙓ")]
			ueE7goaAZTK6 = VqOEwjTfex[JMLhEyaBWmskovGHTrVCxQ08(u"࠷ᙔ")]
			if ii78yUzafOvcDH4uC5BsITm == hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠶ᙕ"):
				DKAZ96yg7hjIkqmGfvpMwozxCHEN5b = Oyl0LCKQDYkbFPigBtXu(DLSVmlyBbCK(u"ࠧࡄࠢမ")+JMLhEyaBWmskovGHTrVCxQ08(u"ࠨࡂࠣယ")*ueE7goaAZTK6, SOlDApJEx73FokmVdYCfKuRNXy8, xbZtO3B7DA9G1CPUTeFSgERXar4)
				ip = AAgpHN0nMZ(u"ࠧࠨရ")
				for qq1tpxa5d0L in DKAZ96yg7hjIkqmGfvpMwozxCHEN5b: ip += str(qq1tpxa5d0L) + OVmSuf8tpd(u"ࠨ࠰ࠪလ")
				ip = ip[pEo8g7riWVL014KaRtzQ(u"࠰ᙗ"):-MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠷ᙖ")]
				xOV4lRWI2Ak37E.append(ip)
			if ii78yUzafOvcDH4uC5BsITm in [LmcNhzY6fQPd2JyCGslkSr(u"࠴ᙚ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠶ᙛ"),FhcnOB9t3frzvXb(u"࠺ᙜ"),sArCMRngQNmXkBoKv(u"࠼ᙝ"),LmcNhzY6fQPd2JyCGslkSr(u"࠲࠷ᙘ"),Ej67fFyoqW8kbV2HdSK(u"࠴࠻ᙙ")]: xbZtO3B7DA9G1CPUTeFSgERXar4 = xbZtO3B7DA9G1CPUTeFSgERXar4 + ueE7goaAZTK6
	except: xOV4lRWI2Ak37E = []
	if not xOV4lRWI2Ak37E: tr24ZoudmqvxfYCw(fR68jBGWCzUsFXdlTKPOScugm(u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧဝ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࠤࠥࠦࡄࡏࡕࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡉࡱࡶࡸ࠿࡛ࠦࠡࠩသ")+CC462TptPM3lv+Ej67fFyoqW8kbV2HdSK(u"ࠫࠥࡣࠧဟ"))
	return xOV4lRWI2Ak37E
def GBC7yanr9WNYIKXSHRxgP(ll6f2wvU4FdqL3MJyDxORESCK197i,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,z4O2HXsQyg,showDialogs=eeIL1TfgFQJaKqVD8hGNPEZ(u"ࡕࡴࡸࡩោ")):
	if z4O2HXsQyg:
		GI5pvVcTEAkH2S = [ffCSGrTJYPsxgVQWKLtHU3iMwB(u"้ࠬศศำࠪဠ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭ศศๆ฽ࠫအ"),pEo8g7riWVL014KaRtzQ(u"ࠧࡢࡦࡸࡰࡹ࠭ဢ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨࡺࡻࠫဣ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩࡶࡩࡽ࠭ဤ")]
		if ll6f2wvU4FdqL3MJyDxORESCK197i!=EDPaWgMt1SwNn8o(u"ࠪࡆࡔࡑࡒࡂࠩဥ"):
			GI5pvVcTEAkH2S += [hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫࡷࡀࠧဦ"),m6b7CoBk4EQ(u"ࠬࡸ࠭ࠨဧ"),ZSJVq5XDrRot(u"࠭࠭࡮ࡣࠪဨ")]
			GI5pvVcTEAkH2S += [J3OCAmZVcn(u"ࠧ࠻ࡴࠪဩ"),ZSJVq5XDrRot(u"ࠨ࠯ࡵࠫဪ"),pEo8g7riWVL014KaRtzQ(u"ࠩࡰࡥ࠲࠭ါ")]
		for zzIWR9wx8MXvqNC3 in z4O2HXsQyg:
			if FhcnOB9t3frzvXb(u"ࠪ࡫ࡪࡺ࠮ࡱࡪࡳࡃࠬာ") in zzIWR9wx8MXvqNC3: continue
			if J3OCAmZVcn(u"ࠫา๊โสࠩိ") in zzIWR9wx8MXvqNC3: continue
			zzIWR9wx8MXvqNC3 = zzIWR9wx8MXvqNC3.lower()
			if Yd6t3PjlLKk: zzIWR9wx8MXvqNC3 = zzIWR9wx8MXvqNC3.decode(JMLhEyaBWmskovGHTrVCxQ08(u"ࠬࡻࡴࡧ࠺ࠪီ")).encode(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭ࡵࡵࡨ࠻ࠫု"))
			zzIWR9wx8MXvqNC3 = zzIWR9wx8MXvqNC3.replace(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧ࠻ࠩူ"),aVLSn1xw5cK(u"ࠨࠩေ"))
			yP5hBR4xijuEZ3g1JOYpW0KbHXsdFM = ZXFs0mEPR8qI2zj.findall(m6b7CoBk4EQ(u"ࠩࠫ࠵ࡠ࠻࠭࠺࡟࠮ࢀ࠷ࡡ࠰࠮࠵ࡠ࠯࠮࠭ဲ"),zzIWR9wx8MXvqNC3,ZXFs0mEPR8qI2zj.DOTALL)
			wTCA6SBmW9hUzPcDgJQNl8 = aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࡈࡤࡰࡸ࡫ៅ")
			for HkAXWjNs36F8bqZB in yP5hBR4xijuEZ3g1JOYpW0KbHXsdFM:
				if len(HkAXWjNs36F8bqZB)==J3OCAmZVcn(u"࠲ᙞ"):
					wTCA6SBmW9hUzPcDgJQNl8 = FhcnOB9t3frzvXb(u"ࡗࡶࡺ࡫ំ")
					break
			if MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࡲࡴࡺࠠࡳࡣࡷࡩࡩ࠭ဳ") in zzIWR9wx8MXvqNC3: continue
			elif DLSVmlyBbCK(u"ࠫࡺࡴࡲࡢࡶࡨࡨࠬဴ") in zzIWR9wx8MXvqNC3: continue
			elif pEo8g7riWVL014KaRtzQ(u"ࠬเ๊าู่๋ࠢ็ࠧဵ") in zzIWR9wx8MXvqNC3: continue
			elif ynO4oHRV3Mj6Z9gNh(bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࡂࡕࡇࡻࡔ࡛࠷࠹ࡔࡔ࡙ࡒ࡚࡛࡬ࡗࡆ࡙ࡉ࡛ࡋࡘࠨံ")): continue
			elif zzIWR9wx8MXvqNC3 in [jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧࡳ့ࠩ")] or wTCA6SBmW9hUzPcDgJQNl8 or any(AARNPWHjQU9dEmDI in zzIWR9wx8MXvqNC3 for AARNPWHjQU9dEmDI in GI5pvVcTEAkH2S):
				tr24ZoudmqvxfYCw(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭း"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+xuYvdJpOEyQKTLNwb(u"ࠩࠣࠤࠥࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡡࡥࡷ࡯ࡸࡸࠦࡶࡪࡦࡨࡳࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ္")+XpOsU3v5dqH8MQAK6FcafmP1z0kL2+Ej67fFyoqW8kbV2HdSK(u"ࠪࠤࡢ်࠭"))
				if showDialogs: NLVM3HAtxQOSvJf6kd78K1o(OVmSuf8tpd(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧျ"),FhcnOB9t3frzvXb(u"ࠬอไโ์า๎ํࠦไๅๅหหึࠦแใูࠣ์ศ์วࠡ็้฽ฯํࠧြ"))
				return kRYWcNuAazr4jtmBoxFVS19Z6(u"ࡘࡷࡻࡥះ")
	return JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࡋࡧ࡬ࡴࡧៈ")
def HHTzVhiY079bvdluNkFQ4wCMpe(*aargs,**kkwargs):
	if aargs:
		direction = aargs[wwyUWMFAsO(u"࠱ᙟ")]
		cOMy1A2uveIp978LxZ = aargs[ZSJVq5XDrRot(u"࠳ᙠ")]
		if not direction: direction = PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ွ")
		if not cOMy1A2uveIp978LxZ: cOMy1A2uveIp978LxZ = xuYvdJpOEyQKTLNwb(u"ࠧศีอ้ึอัࠨှ")
		vACpfsPLwe73kWmyoIuzN0 = aargs[AAgpHN0nMZ(u"࠵ᙡ")]
		unjzvHfWpPTbqACy9RtOY6m = wwyUWMFAsO(u"ࠨ࡞ࡱࠫဿ").join(aargs[gSmqZU0plur2xKPJwQA(u"࠷ᙢ"):])
	else: direction,cOMy1A2uveIp978LxZ,vACpfsPLwe73kWmyoIuzN0,unjzvHfWpPTbqACy9RtOY6m = aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩࠪ၀"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࡓࡐ࠭၁"),FhcnOB9t3frzvXb(u"ࠫࠬ၂"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬ࠭၃")
	A0iaw7hK4Qmc2EeHXZB(direction,xuYvdJpOEyQKTLNwb(u"࠭ࠧ၄"),cOMy1A2uveIp978LxZ,hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧࠨ၅"),vACpfsPLwe73kWmyoIuzN0,unjzvHfWpPTbqACy9RtOY6m,**kkwargs)
	return
def OxCB4medn1(*aargs,**kkwargs):
	direction = aargs[ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠵ᙣ")]
	u4BCa9H8t6GQdgPEbIksxjyiYq0lv = aargs[c4QSTnPiWUCjhrLlwGB(u"࠷ᙤ")]
	sn65bYXg4h7vFWt = aargs[EDPaWgMt1SwNn8o(u"࠲ᙥ")]
	if sn65bYXg4h7vFWt or u4BCa9H8t6GQdgPEbIksxjyiYq0lv: uuNbxvLGpy7HXaVBmrc = OVmSuf8tpd(u"࡚ࡲࡶࡧ៉")
	else: uuNbxvLGpy7HXaVBmrc = m6b7CoBk4EQ(u"ࡆࡢ࡮ࡶࡩ៊")
	vACpfsPLwe73kWmyoIuzN0 = aargs[J3OCAmZVcn(u"࠴ᙦ")]
	unjzvHfWpPTbqACy9RtOY6m = aargs[xuYvdJpOEyQKTLNwb(u"࠶ᙧ")]
	if not direction: direction = ZSJVq5XDrRot(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ၆")
	if not u4BCa9H8t6GQdgPEbIksxjyiYq0lv: u4BCa9H8t6GQdgPEbIksxjyiYq0lv = kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩๆ่ฬࠦࠠࡏࡱࠪ၇")
	if not sn65bYXg4h7vFWt: sn65bYXg4h7vFWt = MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"๊ࠪ฾๋࡛ࠠࠡࡨࡷࠬ၈")
	if len(aargs)>=EDPaWgMt1SwNn8o(u"࠺ᙩ"): unjzvHfWpPTbqACy9RtOY6m += m6b7CoBk4EQ(u"ࠫࡡࡴࠧ၉")+aargs[OVmSuf8tpd(u"࠸ᙨ")]
	if len(aargs)>=OVmSuf8tpd(u"࠼ᙪ"): unjzvHfWpPTbqACy9RtOY6m += ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬࡢ࡮ࠨ၊")+aargs[fR68jBGWCzUsFXdlTKPOScugm(u"࠼ᙫ")]
	HBJbZpwN23hveudOrcI68W0M = A0iaw7hK4Qmc2EeHXZB(direction,u4BCa9H8t6GQdgPEbIksxjyiYq0lv,J3OCAmZVcn(u"࠭ࠧ။"),sn65bYXg4h7vFWt,vACpfsPLwe73kWmyoIuzN0,unjzvHfWpPTbqACy9RtOY6m,**kkwargs)
	if HBJbZpwN23hveudOrcI68W0M==-Ej67fFyoqW8kbV2HdSK(u"࠱ᙬ") and uuNbxvLGpy7HXaVBmrc: HBJbZpwN23hveudOrcI68W0M = -Ej67fFyoqW8kbV2HdSK(u"࠱ᙬ")
	elif HBJbZpwN23hveudOrcI68W0M==-kRYWcNuAazr4jtmBoxFVS19Z6(u"࠲᙭") and not uuNbxvLGpy7HXaVBmrc: HBJbZpwN23hveudOrcI68W0M = PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࡇࡣ࡯ࡷࡪ់")
	elif HBJbZpwN23hveudOrcI68W0M==LmcNhzY6fQPd2JyCGslkSr(u"࠲᙮"): HBJbZpwN23hveudOrcI68W0M = ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࡈࡤࡰࡸ࡫៌")
	elif HBJbZpwN23hveudOrcI68W0M==pEo8g7riWVL014KaRtzQ(u"࠵ᙯ"): HBJbZpwN23hveudOrcI68W0M = LmcNhzY6fQPd2JyCGslkSr(u"ࡗࡶࡺ࡫៍")
	return HBJbZpwN23hveudOrcI68W0M
def F2yZPukcUh09sqCI8nYw7e(*aargs,**kkwargs):
	return kGEPsyxKnHDJ.Dialog().select(*aargs,**kkwargs)
def NLVM3HAtxQOSvJf6kd78K1o(*aargs,**kkwargs):
	vACpfsPLwe73kWmyoIuzN0 = aargs[AAgpHN0nMZ(u"࠴ᙰ")]
	unjzvHfWpPTbqACy9RtOY6m = aargs[pEo8g7riWVL014KaRtzQ(u"࠶ᙱ")]
	if ZSJVq5XDrRot(u"ࠧࡵ࡫ࡰࡩࠬ၌") in list(kkwargs.keys()): UPNQBeGnh3JjSXiu9d = kkwargs[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠨࡶ࡬ࡱࡪ࠭၍")]
	else: UPNQBeGnh3JjSXiu9d = gnfv8UtZ3daGqpjzk(u"࠷࠰࠱࠲ᙲ")
	if len(aargs)>PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠲ᙳ") and XogUJZEijT7KWbxeO6(u"ࠩࡷ࡭ࡲ࡫ࠧ၎") not in aargs[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠲ᙳ")]: profile = aargs[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠲ᙳ")]
	else: profile = wwyUWMFAsO(u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࠩ၏")
	hUXvzyo8qHOnY3W6MZRGANr = ulKB5wvME2o(FhcnOB9t3frzvXb(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡒࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡋࡰࡥ࡬࡫࠮ࡹ࡯࡯ࠫၐ"),J5keFiyQtf9bGZ0vulzNIsTYMx1oR,xuYvdJpOEyQKTLNwb(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭ၑ"),OVmSuf8tpd(u"࠭࠷࠳࠲ࡳࠫၒ"))
	image_filename = HVZp3DNTCmeMA5lOBnWyI1dfvFqJzU.replace(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࡠ࠲࠳࠴࠵ࡥࠧၓ"),XogUJZEijT7KWbxeO6(u"ࠨࡡࠪၔ")+str(luMHeSgCBaPrb9KvUjNFqcR.time())+aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩࡢࠫၕ"))
	image_filename = image_filename.replace(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪࡠࡡ࠭ၖ"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠫࡡࡢ࡜࡝ࠩၗ")).replace(gnfv8UtZ3daGqpjzk(u"ࠬ࠵࠯ࠨၘ"),wwyUWMFAsO(u"࠭࠯࠰࠱࠲ࠫၙ"))
	image_height = MFGPCcLwzSV(xuYvdJpOEyQKTLNwb(u"ࠧࠨၚ"),pEo8g7riWVL014KaRtzQ(u"ࠨࠩၛ"),kmdSKeBIwViM9t3(u"ࠩࠪၜ"),vACpfsPLwe73kWmyoIuzN0,unjzvHfWpPTbqACy9RtOY6m,profile,wwyUWMFAsO(u"ࠪࡰࡪ࡬ࡴࠨၝ"),J3OCAmZVcn(u"ࡊࡦࡲࡳࡦ៎"),image_filename)
	hUXvzyo8qHOnY3W6MZRGANr.show()
	if profile==kmdSKeBIwViM9t3(u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡢࡸࡼࡵࡨࡢ࡮ࡩࡷࠬၞ"):
		hUXvzyo8qHOnY3W6MZRGANr.getControl(kmdSKeBIwViM9t3(u"࠻࠳࠸࠵ᙵ")).setHeight(fR68jBGWCzUsFXdlTKPOScugm(u"࠳࠳࠸ᙴ"))
		hUXvzyo8qHOnY3W6MZRGANr.getControl(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠾࠶࠴࠱ᙸ")).setPosition(yTMWeCgUROcvtsblfK85L62xPk(u"࠸࠹ᙶ"),-JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠼࠵ᙷ"))
		hUXvzyo8qHOnY3W6MZRGANr.getControl(aVLSn1xw5cK(u"࠿࠰࠶࠲ᙹ")).setPosition(OVmSuf8tpd(u"࠱࠳࠲ᙺ"),-bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠷࠲ᙻ"))
		hUXvzyo8qHOnY3W6MZRGANr.getControl(c4QSTnPiWUCjhrLlwGB(u"࠸࠵࠶ᙾ")).setPosition(DLSVmlyBbCK(u"࠻࠳ᙼ"),-DLSVmlyBbCK(u"࠶࠹ᙽ"))
	hUXvzyo8qHOnY3W6MZRGANr.getControl(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠹࠶࠱ᙿ")).setVisible(LmcNhzY6fQPd2JyCGslkSr(u"ࡋࡧ࡬ࡴࡧ៏"))
	hUXvzyo8qHOnY3W6MZRGANr.getControl(c4QSTnPiWUCjhrLlwGB(u"࠺࠰࠳ ")).setVisible(OVmSuf8tpd(u"ࡌࡡ࡭ࡵࡨ័"))
	hUXvzyo8qHOnY3W6MZRGANr.getControl(m6b7CoBk4EQ(u"࠹࠱࠷࠳ᚁ")).setImage(image_filename)
	hUXvzyo8qHOnY3W6MZRGANr.getControl(LmcNhzY6fQPd2JyCGslkSr(u"࠺࠲࠸࠴ᚂ")).setHeight(image_height)
	tvzC6pjwDiN1gUSEJmfVyOq = c3cgVjNv1rde.Thread(target=ZGRFgiALJayKfqT,args=(hUXvzyo8qHOnY3W6MZRGANr,image_filename,UPNQBeGnh3JjSXiu9d))
	tvzC6pjwDiN1gUSEJmfVyOq.start()
	return
def ZGRFgiALJayKfqT(hUXvzyo8qHOnY3W6MZRGANr,image_filename,UPNQBeGnh3JjSXiu9d):
	luMHeSgCBaPrb9KvUjNFqcR.sleep(UPNQBeGnh3JjSXiu9d//J3OCAmZVcn(u"࠳࠳࠴࠵࠴࠰ᚃ"))
	luMHeSgCBaPrb9KvUjNFqcR.sleep(DLSVmlyBbCK(u"࠳࠲࠶࠶࠰ᚄ"))
	if hhHq8m5vauKG9dl.path.exists(image_filename):
		try: hhHq8m5vauKG9dl.remove(image_filename)
		except: pass
	return
def JATO6o8EHKZLIsaQV(*aargs,**kkwargs):
	vACpfsPLwe73kWmyoIuzN0,unjzvHfWpPTbqACy9RtOY6m,profile,direction = OVmSuf8tpd(u"ࠬ࠭ၟ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭ࠧၠ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨၡ"),Ej67fFyoqW8kbV2HdSK(u"ࠨ࡮ࡨࡪࡹ࠭ၢ")
	if len(aargs)>=jYaM5vilgZdFx6QHbApwVXO8et(u"࠵ᚅ"): vACpfsPLwe73kWmyoIuzN0 = aargs[FhcnOB9t3frzvXb(u"࠵ᚆ")]
	if len(aargs)>=wwyUWMFAsO(u"࠲ᚈ"): unjzvHfWpPTbqACy9RtOY6m = aargs[fR68jBGWCzUsFXdlTKPOScugm(u"࠷ᚇ")]
	if len(aargs)>=XogUJZEijT7KWbxeO6(u"࠴ᚉ"): profile = aargs[bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠴ᚊ")]
	if len(aargs)>=ZSJVq5XDrRot(u"࠸ᚌ"): direction = aargs[JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠶ᚋ")]
	return FD5mbRq2ypcA6QOUE8hG(direction,vACpfsPLwe73kWmyoIuzN0,unjzvHfWpPTbqACy9RtOY6m,profile)
def JZ83rVRIumz4KGT(*aargs,**kkwargs):
	return kGEPsyxKnHDJ.Dialog().contextmenu(*aargs,**kkwargs)
def AeZ3q6sbXHJ5w1(*aargs,**kkwargs):
	return kGEPsyxKnHDJ.Dialog().browseSingle(*aargs,**kkwargs)
def swETIMKAyfzL(*aargs,**kkwargs):
	return kGEPsyxKnHDJ.Dialog().input(*aargs,**kkwargs)
def a6Nd4etSry0P1W(*aargs,**kkwargs):
	return kGEPsyxKnHDJ.DialogProgress(*aargs,**kkwargs)
QQ7ZJ13iWSs4qdnfc0KEVx = kmdSKeBIwViM9t3(u"ࡆࡢ࡮ࡶࡩ៑")
def jJSBRtqke9EU6waxvz7PDrg8ATnWm1(i7GMEfBy4lvX3Ld1oTbCQI6hxNp0O):
	global QQ7ZJ13iWSs4qdnfc0KEVx
	ssBUod0JflaI3OMm = i7GMEfBy4lvX3Ld1oTbCQI6hxNp0O==yTMWeCgUROcvtsblfK85L62xPk(u"ࠩࡶࡸࡦࡸࡴࠨၣ") and not QQ7ZJ13iWSs4qdnfc0KEVx
	pYduixISz1FNHCwfKWanQUbTZO = i7GMEfBy4lvX3Ld1oTbCQI6hxNp0O==ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠪࡷࡹࡵࡰࠨၤ") and QQ7ZJ13iWSs4qdnfc0KEVx
	if ssBUod0JflaI3OMm:
		hUXvzyo8qHOnY3W6MZRGANr = eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫࡧࡻࡳࡺࡦ࡬ࡥࡱࡵࡧ࡯ࡱࡦࡥࡳࡩࡥ࡭ࠩၥ") if V8US2yZAg0QXJebWIHKD5xFa>AAgpHN0nMZ(u"࠶࠽࠮࠺࠻ᚍ") else JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࠩၦ")
		cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࡁࡤࡶ࡬ࡺࡦࡺࡥࡘ࡫ࡱࡨࡴࡽࠨࠨၧ")+hUXvzyo8qHOnY3W6MZRGANr+kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠧࠪࠩၨ"))
		QQ7ZJ13iWSs4qdnfc0KEVx = pEo8g7riWVL014KaRtzQ(u"ࡕࡴࡸࡩ្")
	elif pYduixISz1FNHCwfKWanQUbTZO:
		hUXvzyo8qHOnY3W6MZRGANr = eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨࡤࡸࡷࡾࡪࡩࡢ࡮ࡲ࡫ࡳࡵࡣࡢࡰࡦࡩࡱ࠭ၩ") if V8US2yZAg0QXJebWIHKD5xFa>ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠷࠷࠯࠻࠼ᚎ") else DLSVmlyBbCK(u"ࠩࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬࠭ၪ")
		cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(sArCMRngQNmXkBoKv(u"ࠪࡈ࡮ࡧ࡬ࡰࡩ࠱ࡇࡱࡵࡳࡦࠪࠪၫ")+hUXvzyo8qHOnY3W6MZRGANr+kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫ࠮࠭ၬ"))
		QQ7ZJ13iWSs4qdnfc0KEVx = xuYvdJpOEyQKTLNwb(u"ࡈࡤࡰࡸ࡫៓")
	return
def A0iaw7hK4Qmc2EeHXZB(direction,button0=LmcNhzY6fQPd2JyCGslkSr(u"ࠬ࠭ၭ"),button1=kmdSKeBIwViM9t3(u"࠭ࠧၮ"),button2=aVLSn1xw5cK(u"ࠧࠨၯ"),vACpfsPLwe73kWmyoIuzN0=EDPaWgMt1SwNn8o(u"ࠨࠩၰ"),unjzvHfWpPTbqACy9RtOY6m=AAgpHN0nMZ(u"ࠩࠪၱ"),profile=yTMWeCgUROcvtsblfK85L62xPk(u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡧ࡯ࡧࡧࡱࡱࡸࠬၲ"),jat9PgfIVSN2eUhFivKu83oY0MROmd=gnfv8UtZ3daGqpjzk(u"࠰ᚏ"),W5WMqVpCAXaLi8yvwsx=gnfv8UtZ3daGqpjzk(u"࠰ᚏ")):
	if not direction: direction = bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫၳ")
	hUXvzyo8qHOnY3W6MZRGANr = OL9QdnXpIeVN7S6K1yTgs4mqHRYbEt(EDPaWgMt1SwNn8o(u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡈࡵ࡮ࡧ࡫ࡵࡱ࡙࡮ࡲࡦࡧࡅࡹࡹࡺ࡯࡯ࡵ࠱ࡼࡲࡲࠧၴ"),J5keFiyQtf9bGZ0vulzNIsTYMx1oR,pEo8g7riWVL014KaRtzQ(u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧၵ"),J3OCAmZVcn(u"ࠧ࠸࠴࠳ࡴࠬၶ"))
	hUXvzyo8qHOnY3W6MZRGANr.MzD6HuIloB95GqPXn(button0,button1,button2,vACpfsPLwe73kWmyoIuzN0,unjzvHfWpPTbqACy9RtOY6m,profile,direction,jat9PgfIVSN2eUhFivKu83oY0MROmd,W5WMqVpCAXaLi8yvwsx)
	if jat9PgfIVSN2eUhFivKu83oY0MROmd>MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠱ᚐ"): hUXvzyo8qHOnY3W6MZRGANr.tyAGuKJgzaOXrBfxFpn43e2b()
	if W5WMqVpCAXaLi8yvwsx>FhcnOB9t3frzvXb(u"࠲ᚑ"): hUXvzyo8qHOnY3W6MZRGANr.BoeEi3C7LtW1hK2zT8xXvdyNZ0kbm()
	if jat9PgfIVSN2eUhFivKu83oY0MROmd==m6b7CoBk4EQ(u"࠳ᚒ") and W5WMqVpCAXaLi8yvwsx==m6b7CoBk4EQ(u"࠳ᚒ"): hUXvzyo8qHOnY3W6MZRGANr.RDCFgQJ9k5UBxdK0y()
	hUXvzyo8qHOnY3W6MZRGANr.doModal()
	HBJbZpwN23hveudOrcI68W0M = hUXvzyo8qHOnY3W6MZRGANr.choiceID
	return HBJbZpwN23hveudOrcI68W0M
def FD5mbRq2ypcA6QOUE8hG(direction,vACpfsPLwe73kWmyoIuzN0,unjzvHfWpPTbqACy9RtOY6m,profile=eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩၷ")):
	if not direction: direction = pEo8g7riWVL014KaRtzQ(u"ࠩ࡯ࡩ࡫ࡺࠧၸ")
	hUXvzyo8qHOnY3W6MZRGANr = ulKB5wvME2o(gSmqZU0plur2xKPJwQA(u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡗࡩࡽࡺࡖࡪࡧࡺࡩࡷࡌࡵ࡭࡮ࡖࡧࡷ࡫ࡥ࡯࠰ࡻࡱࡱ࠭ၹ"),J5keFiyQtf9bGZ0vulzNIsTYMx1oR,FhcnOB9t3frzvXb(u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬၺ"),EDPaWgMt1SwNn8o(u"ࠬ࠽࠲࠱ࡲࠪၻ"))
	image_filename = HVZp3DNTCmeMA5lOBnWyI1dfvFqJzU.replace(EDPaWgMt1SwNn8o(u"࠭࡟࠱࠲࠳࠴ࡤ࠭ၼ"),J3OCAmZVcn(u"ࠧࡠࠩၽ")+str(luMHeSgCBaPrb9KvUjNFqcR.time())+eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨࡡࠪၾ"))
	image_filename = image_filename.replace(c4QSTnPiWUCjhrLlwGB(u"ࠩ࡟ࡠࠬၿ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪࡠࡡࡢ࡜ࠨႀ")).replace(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠫ࠴࠵ࠧႁ"),AAgpHN0nMZ(u"ࠬ࠵࠯࠰࠱ࠪႂ"))
	image_height = MFGPCcLwzSV(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭ࠧႃ"),XogUJZEijT7KWbxeO6(u"ࠧࠨႄ"),sArCMRngQNmXkBoKv(u"ࠨࠩႅ"),vACpfsPLwe73kWmyoIuzN0,unjzvHfWpPTbqACy9RtOY6m,profile,direction,fR68jBGWCzUsFXdlTKPOScugm(u"ࡉࡥࡱࡹࡥ។"),image_filename)
	hUXvzyo8qHOnY3W6MZRGANr.show()
	hUXvzyo8qHOnY3W6MZRGANr.getControl(wwyUWMFAsO(u"࠽࠵࠻࠰ᚓ")).setHeight(image_height)
	hUXvzyo8qHOnY3W6MZRGANr.getControl(DLSVmlyBbCK(u"࠾࠶࠵࠱ᚔ")).setImage(image_filename)
	OjgFlPRGcVy95qSxZeJKM4fkBoLWtN = hUXvzyo8qHOnY3W6MZRGANr.doModal()
	try: hhHq8m5vauKG9dl.remove(image_filename)
	except: pass
	return OjgFlPRGcVy95qSxZeJKM4fkBoLWtN
def SjMG7CYyUqbPVso0DErhXROvkl(e9jtGdZVTx0ngEo5YcIaUm6=LmcNhzY6fQPd2JyCGslkSr(u"ࡘࡷࡻࡥ៕")):
	if e9jtGdZVTx0ngEo5YcIaUm6:
		k0kUAjI76Erhgf = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩࡶࡸࡷ࠭ႆ"),OVmSuf8tpd(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ႇ"),OVmSuf8tpd(u"࡚࡙ࠫࡅࡓࡃࡊࡉࡓ࡚ࠧႈ"))
		if k0kUAjI76Erhgf: return k0kUAjI76Erhgf
	unjzvHfWpPTbqACy9RtOY6m = XogUJZEijT7KWbxeO6(u"ࠬ࠭ႉ")
	if AAgpHN0nMZ(u"࠶ᚕ") and wvdJxFK9nk.succeeded:
		vdCNK2GykrWZIVeg7z5S4HFh = wvdJxFK9nk.content
		Bn1eRl2KbGqszdFYJ8Z3S4I = vdCNK2GykrWZIVeg7z5S4HFh.count(pEo8g7riWVL014KaRtzQ(u"࠭ࡍࡰࡼ࡬ࡰࡱࡧࠧႊ"))
		if Bn1eRl2KbGqszdFYJ8Z3S4I>ZSJVq5XDrRot(u"࠸࠱ᚖ"):
			unjzvHfWpPTbqACy9RtOY6m = ZXFs0mEPR8qI2zj.findall(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧࡨࡧࡷ࠱ࡹ࡮ࡥ࠮࡮࡬ࡷࡹ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩႋ"),vdCNK2GykrWZIVeg7z5S4HFh,ZXFs0mEPR8qI2zj.DOTALL)
			unjzvHfWpPTbqACy9RtOY6m = unjzvHfWpPTbqACy9RtOY6m[Ej67fFyoqW8kbV2HdSK(u"࠱ᚗ")]
	if not unjzvHfWpPTbqACy9RtOY6m:
		IIFMQmxHiyBfTcdWOJqa9Vlwth = hhHq8m5vauKG9dl.path.join(J5keFiyQtf9bGZ0vulzNIsTYMx1oR,bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧႌ"),XogUJZEijT7KWbxeO6(u"ࠩࡸࡷࡪࡸࡡࡨࡧࡱࡸࡸ࠴ࡴࡹࡶႍࠪ"))
		unjzvHfWpPTbqACy9RtOY6m = open(IIFMQmxHiyBfTcdWOJqa9Vlwth,kmdSKeBIwViM9t3(u"ࠪࡶࡧ࠭ႎ")).read()
		if VYMZsxRpcQHPgkaiDKjyoh: unjzvHfWpPTbqACy9RtOY6m = unjzvHfWpPTbqACy9RtOY6m.decode(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫࡺࡺࡦ࠹ࠩႏ"))
		unjzvHfWpPTbqACy9RtOY6m = unjzvHfWpPTbqACy9RtOY6m.replace(ZSJVq5XDrRot(u"ࠬࡢࡲࠨ႐"),XogUJZEijT7KWbxeO6(u"࠭ࠧ႑"))
	tLVzbqJOi4M9X1xWhCo = ZXFs0mEPR8qI2zj.findall(OVmSuf8tpd(u"ࠧࠩࡏࡲࡾ࡮ࡲ࡬ࡢ࠰࠭ࡃ࠮ࡢ࡮ࠨ႒"),unjzvHfWpPTbqACy9RtOY6m,ZXFs0mEPR8qI2zj.DOTALL)
	YnzPODEH1KfkWi0wl9h4AtoVLNFg7M = []
	for fl6EYgtdJCZOcNaLpnUrDHQ in tLVzbqJOi4M9X1xWhCo:
		FFOhBKSDkdQVc48v0Mpqt2La6gR = fl6EYgtdJCZOcNaLpnUrDHQ.lower()
		if JMLhEyaBWmskovGHTrVCxQ08(u"ࠨࡣࡱࡨࡷࡵࡩࡥࠩ႓") in FFOhBKSDkdQVc48v0Mpqt2La6gR: continue
		if eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠩࡸࡦࡺࡴࡴࡶࠩ႔") in FFOhBKSDkdQVc48v0Mpqt2La6gR: continue
		if FhcnOB9t3frzvXb(u"ࠪ࡭ࡵ࡮࡯࡯ࡧࠪ႕") in FFOhBKSDkdQVc48v0Mpqt2La6gR: continue
		if AAgpHN0nMZ(u"ࠫࡨࡸ࡯ࡴࠩ႖") in FFOhBKSDkdQVc48v0Mpqt2La6gR: continue
		YnzPODEH1KfkWi0wl9h4AtoVLNFg7M.append(fl6EYgtdJCZOcNaLpnUrDHQ)
	k0kUAjI76Erhgf = bnPo1W52UVMRs7Lw6kfG9QdO.sample(YnzPODEH1KfkWi0wl9h4AtoVLNFg7M,hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠳ᚘ"))
	k0kUAjI76Erhgf = k0kUAjI76Erhgf[fR68jBGWCzUsFXdlTKPOScugm(u"࠳ᚙ")]
	Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ႗"),gnfv8UtZ3daGqpjzk(u"࠭ࡕࡔࡇࡕࡅࡌࡋࡎࡕࠩ႘"),k0kUAjI76Erhgf,Z7uFdWIRv9ybj0)
	return k0kUAjI76Erhgf
def jTB4IzGRvbPxCgq2Y(m0AGWhywZVXFtYQ=wwyUWMFAsO(u"ࠧࠨ႙")):
	if not m0AGWhywZVXFtYQ: m0AGWhywZVXFtYQ = QQV1pDhCLqHP5a3sGvoUrJfmjXFw.format_exc()
	if m0AGWhywZVXFtYQ!=DLSVmlyBbCK(u"ࠨࡐࡲࡲࡪ࡚ࡹࡱࡧ࠽ࠤࡓࡵ࡮ࡦ࡞ࡱࠫႚ") and XogUJZEijT7KWbxeO6(u"ࠩࡖࡽࡸࡺࡥ࡮ࡇࡻ࡭ࡹ࠭ႛ") not in m0AGWhywZVXFtYQ: ddABnr3K9Xv8e71CzcN0Pxt.stderr.write(m0AGWhywZVXFtYQ)
	YYyAscnV8LouaiJz = m0AGWhywZVXFtYQ.splitlines()
	KB1kx0UPF7 = YYyAscnV8LouaiJz[-hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠵ᚚ")]
	yf7aTED1KvxsnVo2 = open(wkKn0yuX13,m6b7CoBk4EQ(u"ࠪࡶࡧ࠭ႜ")).read()
	if VYMZsxRpcQHPgkaiDKjyoh: yf7aTED1KvxsnVo2 = yf7aTED1KvxsnVo2.decode(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫࡺࡺࡦ࠹ࠩႝ"))
	yf7aTED1KvxsnVo2 = yf7aTED1KvxsnVo2[-ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠽࠶࠰࠱᚛"):]
	cxvUhw6qRTP4oMJ3AzZ = kmdSKeBIwViM9t3(u"ࠬࡃࠧ႞")*gnfv8UtZ3daGqpjzk(u"࠷࠰࠱᚜")
	if cxvUhw6qRTP4oMJ3AzZ in yf7aTED1KvxsnVo2: yf7aTED1KvxsnVo2 = yf7aTED1KvxsnVo2.rsplit(cxvUhw6qRTP4oMJ3AzZ,MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠱᚝"))[MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠱᚝")]
	if KB1kx0UPF7 in yf7aTED1KvxsnVo2: yf7aTED1KvxsnVo2 = yf7aTED1KvxsnVo2.rsplit(KB1kx0UPF7,wwyUWMFAsO(u"࠲᚞"))[kmdSKeBIwViM9t3(u"࠲᚟")]
	LzRhxr0bujKNDl8Q4F2AiZvyVB = ZXFs0mEPR8qI2zj.findall(kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭ࠨࡔࡱࡸࡶࡨ࡫ࡼࡎࡱࡧࡩ࠮ࡀࠠ࡝࡝ࠣࠬ࠳࠰࠿ࠪࠢ࡟ࡡࠬ႟"),yf7aTED1KvxsnVo2,ZXFs0mEPR8qI2zj.DOTALL)
	for w2kEAC8mgb,j5jMXZ7myEuoLG in reversed(LzRhxr0bujKNDl8Q4F2AiZvyVB):
		if j5jMXZ7myEuoLG: break
	else: j5jMXZ7myEuoLG = kmdSKeBIwViM9t3(u"ࠧࡏࡑࡗࠤࡘࡖࡅࡄࡋࡉࡍࡊࡊࠧႠ")
	zN3iGUHVMpnEfLrvFDxcPX,fl6EYgtdJCZOcNaLpnUrDHQ,c3O7xZvagUizTAG9jlQHJVPqNWE = FhcnOB9t3frzvXb(u"ࠨࠩႡ"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠩࠪႢ"),aVLSn1xw5cK(u"ࠪࠫႣ")
	KD0xqt8Y12pAfNRPgdzCeoF = JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ฮุล࠽ࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧႤ")+KB1kx0UPF7
	MqBGmv53etuED = aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไๆืาี࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩႥ")+j5jMXZ7myEuoLG
	for BZoxXRfEVj in reversed(YYyAscnV8LouaiJz):
		if ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭ࡆࡪ࡮ࡨࠤࠧ࠭Ⴆ") in BZoxXRfEVj and FhcnOB9t3frzvXb(u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭Ⴇ") in BZoxXRfEVj: break
	BZoxXRfEVj = ZXFs0mEPR8qI2zj.findall(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨࡈ࡬ࡰࡪࠦࠢࠩ࠰࠭ࡃ࠮ࠨ࡜࠭ࠢ࡯࡭ࡳ࡫ࠠࠩ࠰࠭ࡃ࠮ࡢࠬࠡ࡫ࡱࠤ࠭࠴ࠪࡀࠫࠧࠫႨ"),BZoxXRfEVj,ZXFs0mEPR8qI2zj.DOTALL)
	if BZoxXRfEVj:
		zN3iGUHVMpnEfLrvFDxcPX,fl6EYgtdJCZOcNaLpnUrDHQ,c3O7xZvagUizTAG9jlQHJVPqNWE = BZoxXRfEVj[wwyUWMFAsO(u"࠳ᚠ")]
		if JMLhEyaBWmskovGHTrVCxQ08(u"ࠩ࠲ࠫႩ") in zN3iGUHVMpnEfLrvFDxcPX: zN3iGUHVMpnEfLrvFDxcPX = zN3iGUHVMpnEfLrvFDxcPX.rsplit(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪ࠳ࠬႪ"),xuYvdJpOEyQKTLNwb(u"࠵ᚡ"))[xuYvdJpOEyQKTLNwb(u"࠵ᚡ")]
		else: zN3iGUHVMpnEfLrvFDxcPX = zN3iGUHVMpnEfLrvFDxcPX.rsplit(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠫࡡࡢࠧႫ"),EDPaWgMt1SwNn8o(u"࠶ᚢ"))[EDPaWgMt1SwNn8o(u"࠶ᚢ")]
		uDvXaI4dwgetlME9UhABWQs8f1yOJ = DLSVmlyBbCK(u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไๆๆไ࠾࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨႬ")+zN3iGUHVMpnEfLrvFDxcPX
		AHQ8kCxK102dX9YEWa = gSmqZU0plur2xKPJwQA(u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅีฺี࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩႭ")+fl6EYgtdJCZOcNaLpnUrDHQ
		uOc1yIZUwlnSjs = OVmSuf8tpd(u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆ่็ฬ์࠺ࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫႮ")+c3O7xZvagUizTAG9jlQHJVPqNWE
		yFUgDZxX1iWwqOGA2v7obeVp8 = uDvXaI4dwgetlME9UhABWQs8f1yOJ+ZSJVq5XDrRot(u"ࠨ࡞ࡱࠫႯ")+AHQ8kCxK102dX9YEWa+xuYvdJpOEyQKTLNwb(u"ࠩ࡟ࡲࠬႰ")+uOc1yIZUwlnSjs+AAgpHN0nMZ(u"ࠪࡠࡳ࠭Ⴑ")+MqBGmv53etuED+c4QSTnPiWUCjhrLlwGB(u"ࠫࡡࡴࠧႲ")+KD0xqt8Y12pAfNRPgdzCeoF
		soSE59lJfRYkh8HtFGyX2 = AHQ8kCxK102dX9YEWa+gSmqZU0plur2xKPJwQA(u"ࠬࡢ࡮ࠨႳ")+MqBGmv53etuED+aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠭࡜࡯ࠩႴ")+KD0xqt8Y12pAfNRPgdzCeoF+LmcNhzY6fQPd2JyCGslkSr(u"ࠧ࡝ࡰࠪႵ")+uDvXaI4dwgetlME9UhABWQs8f1yOJ+m6b7CoBk4EQ(u"ࠨ࡞ࡱࠫႶ")+uOc1yIZUwlnSjs
		AAUwJW3RBPgEZY07xFlM8HiK24dDk = AHQ8kCxK102dX9YEWa+FhcnOB9t3frzvXb(u"ࠩ࡟ࡲࠬႷ")+KD0xqt8Y12pAfNRPgdzCeoF+PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࡠࡳ࠭Ⴘ")+uDvXaI4dwgetlME9UhABWQs8f1yOJ+JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࡡࡴࠧႹ")+uOc1yIZUwlnSjs
	else:
		uDvXaI4dwgetlME9UhABWQs8f1yOJ,AHQ8kCxK102dX9YEWa,uOc1yIZUwlnSjs = EDPaWgMt1SwNn8o(u"ࠬ࠭Ⴚ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"࠭ࠧႻ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠧࠨႼ")
		yFUgDZxX1iWwqOGA2v7obeVp8 = MqBGmv53etuED+JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠨ࡞ࡱࡠࡳ࠭Ⴝ")+KD0xqt8Y12pAfNRPgdzCeoF
		soSE59lJfRYkh8HtFGyX2 = MqBGmv53etuED+aVLSn1xw5cK(u"ࠩ࡟ࡲࡡࡴࠧႾ")+KD0xqt8Y12pAfNRPgdzCeoF
		AAUwJW3RBPgEZY07xFlM8HiK24dDk = KD0xqt8Y12pAfNRPgdzCeoF
	MXIk0Tr3QdhC4EO8Aotj6LDeV2mUFZ = wwyUWMFAsO(u"ࠪัิัࠠฯูฦࠤ฿๐ัࠡ็ๅูํีࠧႿ")+kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫࡡࡴࠧჀ")
	HWlj9JfFKDXtR4 = LpX1u0IcHw82TMhAWS()
	ft4ZvnyswB1RLHN = []
	HkKfQCS7RIa4xi3houjvl = HWlj9JfFKDXtR4[pEo8g7riWVL014KaRtzQ(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪჁ")]
	QQiBNbPTu2A7CR3eftXxIzclOGmrso = XaDMQjxwWpr9ykI2(i69DxzEZSwmuY5Il)
	if FhcnOB9t3frzvXb(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫჂ") in list(HWlj9JfFKDXtR4.keys()):
		for aMFIi4RQklcU6,niDFPsVYfw3b1tK,PReOtWhb0Hw27Mifug5IjASoYkv in HkKfQCS7RIa4xi3houjvl: ft4ZvnyswB1RLHN = max(ft4ZvnyswB1RLHN,niDFPsVYfw3b1tK)
		if QQiBNbPTu2A7CR3eftXxIzclOGmrso<ft4ZvnyswB1RLHN:
			vACpfsPLwe73kWmyoIuzN0 = jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧใ็ࠣฬฯำฯ๋อࠣห้ฮั็ษ่ะ่ࠥศๅࠢศีุอไࠡษ็วำ฽วยࠢ็่๊ฮัๆฮࠪჃ")
			HBJbZpwN23hveudOrcI68W0M = A0iaw7hK4Qmc2EeHXZB(ZSJVq5XDrRot(u"ࠨࡴ࡬࡫࡭ࡺࠧჄ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩศีุอไࠡว็ํࠥอไๆสิ้ั࠭Ⴥ"),wwyUWMFAsO(u"ࠪฮาี๊ฬࠩ჆"),kmdSKeBIwViM9t3(u"ࠫำื่อࠩჇ"),MXIk0Tr3QdhC4EO8Aotj6LDeV2mUFZ+vACpfsPLwe73kWmyoIuzN0,yFUgDZxX1iWwqOGA2v7obeVp8)
			if HBJbZpwN23hveudOrcI68W0M==bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠶ᚣ"):
				YYkEu4IL0sTa = OxCB4medn1(AAgpHN0nMZ(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ჈"),xuYvdJpOEyQKTLNwb(u"࠭ฮา๊ฯࠫ჉"),m6b7CoBk4EQ(u"ࠧหฯา๎ะ࠭჊"),pEo8g7riWVL014KaRtzQ(u"ࠨࠩ჋"),vACpfsPLwe73kWmyoIuzN0)
				if YYkEu4IL0sTa==aVLSn1xw5cK(u"࠱ᚤ"): HBJbZpwN23hveudOrcI68W0M = aVLSn1xw5cK(u"࠱ᚤ")
			if HBJbZpwN23hveudOrcI68W0M==LmcNhzY6fQPd2JyCGslkSr(u"࠲ᚥ"):
				import bYGAkzJECs
				bYGAkzJECs.LLMXenCcYZHSN4OKzy9R(OVmSuf8tpd(u"࡙ࡸࡵࡦ៖"),OVmSuf8tpd(u"࡙ࡸࡵࡦ៖"))
			return
	NPQ2cLMvVmhG7ta4ux5ws = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,aVLSn1xw5cK(u"ࠩ࡯࡭ࡸࡺࠧ჌"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭Ⴭ"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠫࡆࡒࡌࡠࡕࡈࡒ࡙ࡥࡅࡓࡔࡒࡖࡘ࠭჎"))
	if not NPQ2cLMvVmhG7ta4ux5ws: NPQ2cLMvVmhG7ta4ux5ws = []
	soSE59lJfRYkh8HtFGyX2 = soSE59lJfRYkh8HtFGyX2.replace(pEo8g7riWVL014KaRtzQ(u"ࠬࡢ࡮ࠨ჏"),FhcnOB9t3frzvXb(u"࠭࡜࡝ࡰࠪა")).replace(gnfv8UtZ3daGqpjzk(u"ࠧ࡜ࡔࡗࡐࡢ࠭ბ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨࠩგ")).replace(FhcnOB9t3frzvXb(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬდ"),aVLSn1xw5cK(u"ࠪࠫე")).replace(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ვ"),c4QSTnPiWUCjhrLlwGB(u"ࠬ࠭ზ"))
	AAUwJW3RBPgEZY07xFlM8HiK24dDk = AAUwJW3RBPgEZY07xFlM8HiK24dDk.replace(aVLSn1xw5cK(u"࠭࡜࡯ࠩთ"),XogUJZEijT7KWbxeO6(u"ࠧ࡝࡞ࡱࠫი")).replace(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠨ࡝ࡕࡘࡑࡣࠧკ"),kmdSKeBIwViM9t3(u"ࠩࠪლ")).replace(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭მ"),gnfv8UtZ3daGqpjzk(u"ࠫࠬნ")).replace(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧო"),pEo8g7riWVL014KaRtzQ(u"࠭ࠧპ"))
	LFjphsAX89DybUnTN1rRzqwxH = i69DxzEZSwmuY5Il+yTMWeCgUROcvtsblfK85L62xPk(u"ࠧ࠻࠼ࠪჟ")+AAUwJW3RBPgEZY07xFlM8HiK24dDk
	if LFjphsAX89DybUnTN1rRzqwxH in NPQ2cLMvVmhG7ta4ux5ws:
		vACpfsPLwe73kWmyoIuzN0 = MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨๆๅำ่ࠥๅหࠢส๊ฯࠦำศสๅหࠥฮลาีส่ࠥํะศࠢส่ำ฽รࠡว็ํࠥอไๆสิ้ั࠭რ")
		HHTzVhiY079bvdluNkFQ4wCMpe(sArCMRngQNmXkBoKv(u"ࠩࡵ࡭࡬࡮ࡴࠨს"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪࠫტ"),MXIk0Tr3QdhC4EO8Aotj6LDeV2mUFZ+vACpfsPLwe73kWmyoIuzN0,yFUgDZxX1iWwqOGA2v7obeVp8)
		return
	LBkP0GAdZnmlXwCh2Egqu5xs8fS3M = str(V8US2yZAg0QXJebWIHKD5xFa).split(c4QSTnPiWUCjhrLlwGB(u"ࠫ࠳࠭უ"))[OVmSuf8tpd(u"࠲ᚦ")]
	XpOsU3v5dqH8MQAK6FcafmP1z0kL2 = uReHcEzxkTm6pN4Q[aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬფ")][ZSJVq5XDrRot(u"࠹ᚧ")]
	wvdJxFK9nk = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࡐࡐࡕࡗࠫქ"),XpOsU3v5dqH8MQAK6FcafmP1z0kL2,kmdSKeBIwViM9t3(u"ࠧࠨღ"),wwyUWMFAsO(u"ࠨࠩყ"),OVmSuf8tpd(u"ࠩࠪშ"),J3OCAmZVcn(u"ࠪࠫჩ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡈࡐ࡙ࡢࡉ࡝ࡏࡔࡠࡇࡕࡖࡔࡘࡓ࠮࠳ࡶࡸࠬც"),pEo8g7riWVL014KaRtzQ(u"ࡌࡡ࡭ࡵࡨៗ"),pEo8g7riWVL014KaRtzQ(u"ࡌࡡ࡭ࡵࡨៗ"))
	vdCNK2GykrWZIVeg7z5S4HFh = wvdJxFK9nk.content
	imnoraEFItQ5AfjW1lsZvJeYhP = ZXFs0mEPR8qI2zj.findall(DLSVmlyBbCK(u"࡙ࠬࡔࡂࡔࡗ࠾࠿࡙ࡔࡂࡔࡗ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮ࡉࡓࡊ࠺࠻ࡇࡑࡈࠬძ"),vdCNK2GykrWZIVeg7z5S4HFh,ZXFs0mEPR8qI2zj.DOTALL)
	for gwJvlCkXUiG,OnQHdMvaPKgb,I9CFlRy6VXrOAHYWjeBGuzoT,smkZ0oXc3Tit9xCpunbQ in imnoraEFItQ5AfjW1lsZvJeYhP:
		gwJvlCkXUiG = gwJvlCkXUiG.split(AAgpHN0nMZ(u"࠭ࠫࠨწ"))
		I9CFlRy6VXrOAHYWjeBGuzoT = I9CFlRy6VXrOAHYWjeBGuzoT.split(AAgpHN0nMZ(u"ࠧࠬࠩჭ"))
		smkZ0oXc3Tit9xCpunbQ = smkZ0oXc3Tit9xCpunbQ.split(Ej67fFyoqW8kbV2HdSK(u"ࠨ࠭ࠪხ"))
		if fl6EYgtdJCZOcNaLpnUrDHQ in gwJvlCkXUiG and KB1kx0UPF7==OnQHdMvaPKgb and i69DxzEZSwmuY5Il in I9CFlRy6VXrOAHYWjeBGuzoT and LBkP0GAdZnmlXwCh2Egqu5xs8fS3M in smkZ0oXc3Tit9xCpunbQ:
			vACpfsPLwe73kWmyoIuzN0 = JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"๊ࠩิฬࠦวๅะฺวู๋ࠥา๊ไࠤํฺู๊ษ็ะࠥฮวๅวุำฬืࠠศๆๅหิ๋ࠧჯ")
			YYkEu4IL0sTa = OxCB4medn1(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࡶ࡮࡭ࡨࡵࠩჰ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫำื่อࠩჱ"),J3OCAmZVcn(u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩჲ"),MXIk0Tr3QdhC4EO8Aotj6LDeV2mUFZ+vACpfsPLwe73kWmyoIuzN0,yFUgDZxX1iWwqOGA2v7obeVp8)
			if YYkEu4IL0sTa==aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠵ᚨ"): HHTzVhiY079bvdluNkFQ4wCMpe(eeIL1TfgFQJaKqVD8hGNPEZ(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ჳ"),gnfv8UtZ3daGqpjzk(u"ࠧࠨჴ"),sArCMRngQNmXkBoKv(u"ࠨࠩჵ"),vACpfsPLwe73kWmyoIuzN0)
			return
	vACpfsPLwe73kWmyoIuzN0 = hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠩส่ึาวยࠢศีุอไ้ࠡำหࠥอไฯูฦࠤส๊้ࠡษ็้อืๅอࠩჶ")
	c6IqdvmufwszMorD = A0iaw7hK4Qmc2EeHXZB(gSmqZU0plur2xKPJwQA(u"ࠪࡶ࡮࡭ࡨࡵࠩჷ"),m6b7CoBk4EQ(u"ࠫสืำศๆࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨჸ"),J3OCAmZVcn(u"ࠬะอะ์ฮࠤึ๎วษูࠣห้๋่ศไ฼ࠫჹ"),sArCMRngQNmXkBoKv(u"࠭สฮัํฯࠥอไษำ้ห๊าࠧჺ"),MXIk0Tr3QdhC4EO8Aotj6LDeV2mUFZ+vACpfsPLwe73kWmyoIuzN0,yFUgDZxX1iWwqOGA2v7obeVp8)
	if c6IqdvmufwszMorD==PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠶ᚩ"):
		if not AA58pW4UfMiI9B2avFZ3YrsoeQ:
			VZotrchyP5ez4psFq8QGjbUIYO9dE(fR68jBGWCzUsFXdlTKPOScugm(u"ࡔࡳࡷࡨ៘"))
			NLVM3HAtxQOSvJf6kd78K1o(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧ็ฮะฮࠥ฿ๅๅ์ฬࠤฯำฯ๋อࠣีํอศุࠢส่๊๎วใ฻ࠪ჻"),LmcNhzY6fQPd2JyCGslkSr(u"ࠨ๏ࡖࡹࡨࡩࡥࡴࡵࠪჼ"),luMHeSgCBaPrb9KvUjNFqcR=kRYWcNuAazr4jtmBoxFVS19Z6(u"࠽࠵࠱ᚪ"))
			iiysxZ8dOaA(fR68jBGWCzUsFXdlTKPOScugm(u"ࠩࡉࡳࡷࡩࡥࡥࠢࡨࡼ࡮ࡺࠠࡵࡱࠣࡥࡵࡶ࡬ࡺࠢࡱࡩࡼࠦࡷࡦࡤࡶ࡭ࡹ࡫ࡳࠡࡪࡲࡷࡹࡹࠠ࡯ࡣࡰࡩࡸ࠭ჽ"))
	elif c6IqdvmufwszMorD==gSmqZU0plur2xKPJwQA(u"࠲ᚫ"):
		import bYGAkzJECs
		bYGAkzJECs.LLMXenCcYZHSN4OKzy9R(DLSVmlyBbCK(u"ࡕࡴࡸࡩ៙"),DLSVmlyBbCK(u"ࡕࡴࡸࡩ៙"))
		iiysxZ8dOaA(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠪࡊࡴࡸࡣࡦࡦࠣࡩࡽ࡯ࡴࠡࡶࡲࠤࡵࡸ࡯ࡤࡧࡶࡷࠥࡴࡥࡸࠢࡵࡩࡱ࡫ࡡࡴࡧࠪჾ"))
	YYkEu4IL0sTa = OxCB4medn1(yTMWeCgUROcvtsblfK85L62xPk(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫჿ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬ࠭ᄀ"),kmdSKeBIwViM9t3(u"࠭ࠧᄁ"),aVLSn1xw5cK(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᄂ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨี๋ๅࠥ๐สๆࠢศีุอไࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡๆๆ๎ࠥ๐ูาใࠣห้๋ศา็ฯࠤศ๐ๆ๊่ࠡฮ๎่ࠦไ์ไࠤํ๊ๅศาสࠤา฻ไห๊ࠢิ์ࠦวๅ็ื็้ฯࠠๅล้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠥ๎ไศࠢํืฯ฽ฺ๊ࠢสู้ออࠡ็ื็้ฯ้้๋ࠠࠤ้อ๋ࠠ฻ิๅ้๊ࠥโࠢ฻๋ึะ้ࠠๆ่หีอู้ࠠิฮࠥ๎ๅห๋ࠣ฼์ืส้ࠡำ๋ࠥอไๆึๆ่ฮࠦ࠮้ࠡ็ࠤฯื๊ะࠢฦีุอไࠡษ็ืั๊ࠠภࠩᄃ"))
	if YYkEu4IL0sTa==fR68jBGWCzUsFXdlTKPOScugm(u"࠲ᚬ"): GwLHvcBPTiMSJVAQedjk549yg6CUNm = sArCMRngQNmXkBoKv(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬᄄ")
	else:
		HHTzVhiY079bvdluNkFQ4wCMpe(pEo8g7riWVL014KaRtzQ(u"ࠪࡧࡪࡴࡴࡦࡴࠪᄅ"),ZSJVq5XDrRot(u"ࠫࠬᄆ"),xuYvdJpOEyQKTLNwb(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᄇ"),DLSVmlyBbCK(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ฬ่ࠤสฺ๊ศรࠣษึูวๅࠢส่ำ฽ร࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱ่ศ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศ๊ࠡ็หࠥ๐ำหูํ฽ࠥหีๅษะࠤฬ๊ฮุลࠣฬิ๎ๆࠡีฯ่ࠥอไฤะฺหฦࠦวๅาํࠤ๊้ส้สࠣๅ๏ํࠠอ็ํ฽ࠥะแศืํ่ࠥํะศࠢส่ำ฽ร๊ࠡ฽๎ึํࠠๆ่ࠣห้ษฮุษฤࠫᄈ"))
		return
	d0Z7abLoEfmpHTOkgVG = soSE59lJfRYkh8HtFGyX2
	from bYGAkzJECs import lkRNq72CIhOaXQWb
	ybf3Qo7isaYVr = lkRNq72CIhOaXQWb(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧࡆࡴࡵࡳࡷࡹࠧᄉ"),d0Z7abLoEfmpHTOkgVG,OVmSuf8tpd(u"ࡖࡵࡹࡪ៚"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨࠩᄊ"),sArCMRngQNmXkBoKv(u"ࠩࡈࡑࡆࡏࡌ࠮ࡈࡕࡓࡒ࠳ࡓࡉࡑ࡚ࡣࡊ࡞ࡉࡕࡡࡈࡖࡗࡕࡒࡔࠩᄋ"),GwLHvcBPTiMSJVAQedjk549yg6CUNm)
	if ybf3Qo7isaYVr and GwLHvcBPTiMSJVAQedjk549yg6CUNm:
		NPQ2cLMvVmhG7ta4ux5ws.append(LFjphsAX89DybUnTN1rRzqwxH)
		Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,kmdSKeBIwViM9t3(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ᄌ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠫࡆࡒࡌࡠࡕࡈࡒ࡙ࡥࡅࡓࡔࡒࡖࡘ࠭ᄍ"),NPQ2cLMvVmhG7ta4ux5ws,iKYM8NdkGHmBcr)
	return
def R5fx8QPidEzFDL9e7IYpNql3bt1(SOlDApJEx73FokmVdYCfKuRNXy8):
	if VYMZsxRpcQHPgkaiDKjyoh: SOlDApJEx73FokmVdYCfKuRNXy8 = SOlDApJEx73FokmVdYCfKuRNXy8.encode(yTMWeCgUROcvtsblfK85L62xPk(u"ࠬࡻࡴࡧ࠺ࠪᄎ"))
	dhJn8VcYtlwIBb0Su7WFmi = MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠭ࡳ࠻࡞࡟࠴࠵࠶࠰ࡦ࡯ࡤࡨࡤ࠭ᄏ")+str(luMHeSgCBaPrb9KvUjNFqcR.time())+gSmqZU0plur2xKPJwQA(u"ࠧ࠯ࡦࡤࡸࠬᄐ")
	open(dhJn8VcYtlwIBb0Su7WFmi,aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨࡹࡥࠫᄑ")).write(SOlDApJEx73FokmVdYCfKuRNXy8)
	return
def KLSU61gP7bs5QBrp(pxc6J0d9LuvQ1tPWfTD4bn):
	if pxc6J0d9LuvQ1tPWfTD4bn:
		EC5XwtROefg9UNdSvQ = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩ࡯࡭ࡸࡺࠧᄒ"),wwyUWMFAsO(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ᄓ"),AAgpHN0nMZ(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧᄔ"))
		if EC5XwtROefg9UNdSvQ: return EC5XwtROefg9UNdSvQ
	XpOsU3v5dqH8MQAK6FcafmP1z0kL2 = uReHcEzxkTm6pN4Q[LmcNhzY6fQPd2JyCGslkSr(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬᄕ")][gSmqZU0plur2xKPJwQA(u"࠷ᚭ")]
	hhC9JITqv3yWEGFm = HHWAnGJrb9powOqTkYgcPQ6Ef(jYaM5vilgZdFx6QHbApwVXO8et(u"࠶࠶ᚮ"),pxc6J0d9LuvQ1tPWfTD4bn)
	K6yLQmfzv7OAXCqln9oig0U4a3St = lTqcJaeunfS2YrEVIFNmMHG()
	SvVD2AkXlf17EFnY = K6yLQmfzv7OAXCqln9oig0U4a3St.split(m6b7CoBk4EQ(u"࠭ࠬࠨᄖ"))[xuYvdJpOEyQKTLNwb(u"࠶ᚯ")]
	ywvHBKsXJgjPW3uc = hhHq8m5vauKG9dl.path.join(J5keFiyQtf9bGZ0vulzNIsTYMx1oR,xuYvdJpOEyQKTLNwb(u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ᄗ"))
	SfyPWiO4LQBV3gbGxoRwpY9Ce1dK = ZFj2BomiVuntxCv5dYEUyKgX()
	QnIsrBC7Wc3tOSXbGJp8l = {wwyUWMFAsO(u"ࠨࡷࡶࡩࡷ࠭ᄘ"):hhC9JITqv3yWEGFm,m6b7CoBk4EQ(u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪᄙ"):i69DxzEZSwmuY5Il,FhcnOB9t3frzvXb(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫᄚ"):SvVD2AkXlf17EFnY,fR68jBGWCzUsFXdlTKPOScugm(u"ࠫ࡮ࡪࡳࠨᄛ"):uD0IBl6nS9jqNekYZXaxzd2(SfyPWiO4LQBV3gbGxoRwpY9Ce1dK)}
	wvdJxFK9nk = A6F71g3cqN4(KxirmCLT6Gw,c4QSTnPiWUCjhrLlwGB(u"ࠬࡖࡏࡔࡖࠪᄜ"),XpOsU3v5dqH8MQAK6FcafmP1z0kL2,QnIsrBC7Wc3tOSXbGJp8l,fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࠧᄝ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࠨᄞ"),FhcnOB9t3frzvXb(u"ࠨࠩᄟ"),Ej67fFyoqW8kbV2HdSK(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡒࡗࡈࡗ࡙ࡏࡏࡏࡕ࠰࠵ࡸࡺࠧᄠ"))
	EC5XwtROefg9UNdSvQ = []
	if wvdJxFK9nk.succeeded:
		vdCNK2GykrWZIVeg7z5S4HFh = wvdJxFK9nk.content
		EC5XwtROefg9UNdSvQ = vdCNK2GykrWZIVeg7z5S4HFh.replace(LmcNhzY6fQPd2JyCGslkSr(u"ࠪࡠࡡࡸࠧᄡ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫࡡࡴࠧᄢ")).replace(EDPaWgMt1SwNn8o(u"ࠬࡢ࡜࡯ࠩᄣ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭࡜࡯ࠩᄤ")).replace(fR68jBGWCzUsFXdlTKPOScugm(u"ࠧ࡝ࡴ࡟ࡲࠬᄥ"),sArCMRngQNmXkBoKv(u"ࠨ࡞ࡱࠫᄦ")).replace(pEo8g7riWVL014KaRtzQ(u"ࠩ࡟ࡶࠬᄧ"),OVmSuf8tpd(u"ࠪࡠࡳ࠭ᄨ"))
		EC5XwtROefg9UNdSvQ = ZXFs0mEPR8qI2zj.findall(kmdSKeBIwViM9t3(u"ࠫࡘ࡚ࡁࡓࡖ࠽࠾ࡘ࡚ࡁࡓࡖ࠽࠾࠭ࡢࡤࠬࠫ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡋࡎࡅ࠼࠽ࡉࡓࡊࠧᄩ"),EC5XwtROefg9UNdSvQ,ZXFs0mEPR8qI2zj.DOTALL)
		if EC5XwtROefg9UNdSvQ:
			EC5XwtROefg9UNdSvQ = sorted(EC5XwtROefg9UNdSvQ,reverse=aVLSn1xw5cK(u"ࡉࡥࡱࡹࡥ៛"),key=lambda key: int(key[c4QSTnPiWUCjhrLlwGB(u"࠵ᚰ")]))
			nTSFmel5UBt6bWh,hhC9JITqv3yWEGFm,X3OBj9hFudG,xOV4lRWI2Ak37E,kwRd5A8WqiVBQ4cxf0rNPbC7XaSUF2,X75jhUrfuFIJW82GYmbp = EC5XwtROefg9UNdSvQ[bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠶ᚱ")]
			qFBZ7u5yW3kjvr = X75jhUrfuFIJW82GYmbp if ynO4oHRV3Mj6Z9gNh(EDPaWgMt1SwNn8o(u"ࠬࡓࡔ࠱࠷ࡋ࡜࠵ࡲࡔࡕࡇࡉࡒࡘ࡛ࡎࡧࡗࡈ࡚ࡘ࡙ࡕ࠺ࡇ࡛ࠫᄪ")) else X3OBj9hFudG
			j2agIU0xsLS6c7T.setSetting(ZSJVq5XDrRot(u"࠭ࡡࡷ࠰ࡳࡩࡷ࡯࡯ࡥ࠰࡬ࡲ࡫ࡵࡳࠨᄫ"),qFBZ7u5yW3kjvr)
			Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,LmcNhzY6fQPd2JyCGslkSr(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪᄬ"),pEo8g7riWVL014KaRtzQ(u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫᄭ"),EC5XwtROefg9UNdSvQ,Z7uFdWIRv9ybj0)
			j2agIU0xsLS6c7T.setSetting(m6b7CoBk4EQ(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫᄮ"),uD0IBl6nS9jqNekYZXaxzd2(F5I1VZzxkXenKuEAYO))
	return EC5XwtROefg9UNdSvQ
def UUG3k64wyPDtOszK728Vx1Ql(OHnId4ojGSuQ2KZPfaEeCm7py1q,AAxWfFhNulDK=sArCMRngQNmXkBoKv(u"࠰ᚲ"),b3bf8Du1pRlSVgdzY=sArCMRngQNmXkBoKv(u"࠰ᚲ")):
	if AAxWfFhNulDK and not b3bf8Du1pRlSVgdzY: b3bf8Du1pRlSVgdzY = len(OHnId4ojGSuQ2KZPfaEeCm7py1q)//AAxWfFhNulDK
	aaR3Toz92rOsX,OeT2Jo0sp6h1mGdqfFw,TzRI3GLUr9laoJNeDd1O8kW = [],-kmdSKeBIwViM9t3(u"࠲ᚳ"),AAgpHN0nMZ(u"࠲ᚴ")
	for fdmbuvJpzy in OHnId4ojGSuQ2KZPfaEeCm7py1q:
		if TzRI3GLUr9laoJNeDd1O8kW%b3bf8Du1pRlSVgdzY==PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠳ᚵ"):
			OeT2Jo0sp6h1mGdqfFw += PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠵ᚶ")
			aaR3Toz92rOsX.append([])
		aaR3Toz92rOsX[OeT2Jo0sp6h1mGdqfFw].append(fdmbuvJpzy)
		TzRI3GLUr9laoJNeDd1O8kW += PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠶ᚷ")
	return aaR3Toz92rOsX
def zARNykmldphW5wvE6T1(dhJn8VcYtlwIBb0Su7WFmi,SOlDApJEx73FokmVdYCfKuRNXy8):
	Ss8MaEbzQmOBGhR4C7ontf3jdiu = hhHq8m5vauKG9dl.path.join(mATvU6VbxOXNFhz8lK5WGrfQ,dhJn8VcYtlwIBb0Su7WFmi)
	if XogUJZEijT7KWbxeO6(u"࠷ᚸ") or gSmqZU0plur2xKPJwQA(u"ࠪࡍࡕ࡚ࡖࡠࠩᄯ") not in dhJn8VcYtlwIBb0Su7WFmi or xuYvdJpOEyQKTLNwb(u"ࠫࡒ࠹ࡕࡠࠩᄰ") not in dhJn8VcYtlwIBb0Su7WFmi: unjzvHfWpPTbqACy9RtOY6m = str(SOlDApJEx73FokmVdYCfKuRNXy8)
	else:
		aaR3Toz92rOsX = UUG3k64wyPDtOszK728Vx1Ql(SOlDApJEx73FokmVdYCfKuRNXy8,kRYWcNuAazr4jtmBoxFVS19Z6(u"࠸ᚹ"))
		unjzvHfWpPTbqACy9RtOY6m = DLSVmlyBbCK(u"ࠬ࠭ᄱ")
		for hqlpMvnfC8i in aaR3Toz92rOsX:
			unjzvHfWpPTbqACy9RtOY6m += str(hqlpMvnfC8i)+fR68jBGWCzUsFXdlTKPOScugm(u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬᄲ")
		unjzvHfWpPTbqACy9RtOY6m = unjzvHfWpPTbqACy9RtOY6m.strip(J3OCAmZVcn(u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭ᄳ"))
	VVHBq0GL1o = KKTylHUNgwka5pr1tuWSBPDEA.compress(unjzvHfWpPTbqACy9RtOY6m)
	open(Ss8MaEbzQmOBGhR4C7ontf3jdiu,ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨࡹࡥࠫᄴ")).write(VVHBq0GL1o)
	return
def yysjTEX8hRPJgwW74BNzY3(sLhOM54GVH06aR1kSy2iBPfbItYo,dhJn8VcYtlwIBb0Su7WFmi):
	if sLhOM54GVH06aR1kSy2iBPfbItYo==ZSJVq5XDrRot(u"ࠩࡧ࡭ࡨࡺࠧᄵ"): SOlDApJEx73FokmVdYCfKuRNXy8 = {}
	elif sLhOM54GVH06aR1kSy2iBPfbItYo==kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪࡰ࡮ࡹࡴࠨᄶ"): SOlDApJEx73FokmVdYCfKuRNXy8 = []
	elif sLhOM54GVH06aR1kSy2iBPfbItYo==MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠫࡸࡺࡲࠨᄷ"): SOlDApJEx73FokmVdYCfKuRNXy8 = xuYvdJpOEyQKTLNwb(u"ࠬ࠭ᄸ")
	elif sLhOM54GVH06aR1kSy2iBPfbItYo==bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࡩ࡯ࡶࠪᄹ"): SOlDApJEx73FokmVdYCfKuRNXy8 = m6b7CoBk4EQ(u"࠱ᚺ")
	else: SOlDApJEx73FokmVdYCfKuRNXy8 = None
	Ss8MaEbzQmOBGhR4C7ontf3jdiu = hhHq8m5vauKG9dl.path.join(mATvU6VbxOXNFhz8lK5WGrfQ,dhJn8VcYtlwIBb0Su7WFmi)
	VVHBq0GL1o = open(Ss8MaEbzQmOBGhR4C7ontf3jdiu,DLSVmlyBbCK(u"ࠧࡳࡤࠪᄺ")).read()
	unjzvHfWpPTbqACy9RtOY6m = KKTylHUNgwka5pr1tuWSBPDEA.decompress(VVHBq0GL1o)
	if gSmqZU0plur2xKPJwQA(u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧᄻ") not in unjzvHfWpPTbqACy9RtOY6m: SOlDApJEx73FokmVdYCfKuRNXy8 = eval(unjzvHfWpPTbqACy9RtOY6m)
	else:
		aaR3Toz92rOsX = unjzvHfWpPTbqACy9RtOY6m.split(OVmSuf8tpd(u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨᄼ"))
		del unjzvHfWpPTbqACy9RtOY6m
		SOlDApJEx73FokmVdYCfKuRNXy8 = []
		Q0b7hrPautTdskLixNF6mo = K7Mybc2p4irvPHQ1GaIhjXZ()
		nTSFmel5UBt6bWh = sArCMRngQNmXkBoKv(u"࠲ᚻ")
		for hqlpMvnfC8i in aaR3Toz92rOsX:
			Q0b7hrPautTdskLixNF6mo.JkOZNjX83SgnQaCqY(str(nTSFmel5UBt6bWh),eval,hqlpMvnfC8i)
			nTSFmel5UBt6bWh += gSmqZU0plur2xKPJwQA(u"࠴ᚼ")
		del aaR3Toz92rOsX
		Q0b7hrPautTdskLixNF6mo.wsYEa9Je6L4gPSjpWHK()
		Q0b7hrPautTdskLixNF6mo.kQ5exrifztCSnIoUKs8G3WAOa6EM()
		RPNYok1KzGMSy0xW68u7ieaCAQObj = list(Q0b7hrPautTdskLixNF6mo.resultsDICT.keys())
		L7gCKJHFEqR4ye = sorted(RPNYok1KzGMSy0xW68u7ieaCAQObj,reverse=EDPaWgMt1SwNn8o(u"ࡊࡦࡲࡳࡦៜ"),key=lambda key: int(key))
		for nTSFmel5UBt6bWh in L7gCKJHFEqR4ye:
			SOlDApJEx73FokmVdYCfKuRNXy8 += Q0b7hrPautTdskLixNF6mo.resultsDICT[nTSFmel5UBt6bWh]
	return SOlDApJEx73FokmVdYCfKuRNXy8
def BBydgcOMpxFImqi5wtV0Pv1EhfzJ(ZK5gkAtjrCeEXYGD2bRQHOF3Moyc):
	SXnlY0kCeA7 = hhHq8m5vauKG9dl.path.join(D2DYfsvFSG5CnV,wwyUWMFAsO(u"ࠪࡥࡩࡪ࡯࡯ࡵࠪᄽ"),ZK5gkAtjrCeEXYGD2bRQHOF3Moyc,eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫࡦࡪࡤࡰࡰ࠱ࡼࡲࡲࠧᄾ"))
	try: myA9MKT5O7ulV3pWsgFk6ZQwiDjY0 = open(SXnlY0kCeA7,J3OCAmZVcn(u"ࠬࡸࡢࠨᄿ")).read()
	except:
		ZSDVBWJwnxH547hqr9ycldNXz0Pj = hhHq8m5vauKG9dl.path.join(mqOvo7bGt2K6eh0wPYV1,ZSJVq5XDrRot(u"࠭ࡡࡥࡦࡲࡲࡸ࠭ᅀ"),ZK5gkAtjrCeEXYGD2bRQHOF3Moyc,OVmSuf8tpd(u"ࠧࡢࡦࡧࡳࡳ࠴ࡸ࡮࡮ࠪᅁ"))
		try: myA9MKT5O7ulV3pWsgFk6ZQwiDjY0 = open(ZSDVBWJwnxH547hqr9ycldNXz0Pj,aVLSn1xw5cK(u"ࠨࡴࡥࠫᅂ")).read()
		except: return bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩࠪᅃ"),[]
	if VYMZsxRpcQHPgkaiDKjyoh: myA9MKT5O7ulV3pWsgFk6ZQwiDjY0 = myA9MKT5O7ulV3pWsgFk6ZQwiDjY0.decode(OVmSuf8tpd(u"ࠪࡹࡹ࡬࠸ࠨᅄ"))
	uuiyNr2Gf37n0CeZ = ZXFs0mEPR8qI2zj.findall(AAgpHN0nMZ(u"ࠫ࡮ࡪ࠽࠯ࠬࡂࡺࡪࡸࡳࡪࡱࡱࡁࡠࡢࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝࡟ࠦࡡ࠭࡝ࠨᅅ"),myA9MKT5O7ulV3pWsgFk6ZQwiDjY0,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.IGNORECASE)
	if not uuiyNr2Gf37n0CeZ: return bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠬ࠭ᅆ"),[]
	yFmciIqAPpYZE5dQMuJsHnVGtoCDT,RMU59zov3y8Br0OK = uuiyNr2Gf37n0CeZ[J3OCAmZVcn(u"࠴ᚽ")],XaDMQjxwWpr9ykI2(uuiyNr2Gf37n0CeZ[J3OCAmZVcn(u"࠴ᚽ")])
	return yFmciIqAPpYZE5dQMuJsHnVGtoCDT,RMU59zov3y8Br0OK
def LpX1u0IcHw82TMhAWS():
	cxhbLsri96o0AWfXez = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭ࡤࡪࡥࡷࠫᅇ"),c4QSTnPiWUCjhrLlwGB(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪᅈ"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠨࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍࠩᅉ"))
	if cxhbLsri96o0AWfXez: return cxhbLsri96o0AWfXez
	HWlj9JfFKDXtR4,cxhbLsri96o0AWfXez = {},{}
	LzRhxr0bujKNDl8Q4F2AiZvyVB = [uReHcEzxkTm6pN4Q[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࡕࡉࡕࡕࡓࠨᅊ")][MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠵ᚾ")]]
	if V8US2yZAg0QXJebWIHKD5xFa>fR68jBGWCzUsFXdlTKPOScugm(u"࠱࠸࠰࠼࠽ᛀ"): LzRhxr0bujKNDl8Q4F2AiZvyVB.append(uReHcEzxkTm6pN4Q[XogUJZEijT7KWbxeO6(u"ࠪࡖࡊࡖࡏࡔࠩᅋ")][PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠷ᚿ")])
	if VYMZsxRpcQHPgkaiDKjyoh: LzRhxr0bujKNDl8Q4F2AiZvyVB.append(uReHcEzxkTm6pN4Q[DLSVmlyBbCK(u"ࠫࡗࡋࡐࡐࡕࠪᅌ")][ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠳ᛁ")])
	for EH4A8YWftNRV160qdQpZxgI in LzRhxr0bujKNDl8Q4F2AiZvyVB:
		wvdJxFK9nk = A6F71g3cqN4(KxirmCLT6Gw,AAgpHN0nMZ(u"ࠬࡍࡅࡕࠩᅍ"),EH4A8YWftNRV160qdQpZxgI,aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠭ࠧᅎ"),XogUJZEijT7KWbxeO6(u"ࠧࠨᅏ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠨࠩᅐ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠩࠪᅑ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡁࡅࡡࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎ࠰࠵ࡸࡺࠧᅒ"))
		if wvdJxFK9nk.succeeded:
			vdCNK2GykrWZIVeg7z5S4HFh = wvdJxFK9nk.content
			dHrYEIpLofM1qeAK = EH4A8YWftNRV160qdQpZxgI.rsplit(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠫ࠴࠭ᅓ"),FhcnOB9t3frzvXb(u"࠳ᛂ"))[kRYWcNuAazr4jtmBoxFVS19Z6(u"࠳ᛃ")]
			uS4OWt32c9T1HjYXy = ZXFs0mEPR8qI2zj.findall(xuYvdJpOEyQKTLNwb(u"ࠬ࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻ࡫ࡲࡴ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᅔ"),vdCNK2GykrWZIVeg7z5S4HFh,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.IGNORECASE)
			for ZK5gkAtjrCeEXYGD2bRQHOF3Moyc,pGzmNqA83DYFiVMr46PnWL5 in uS4OWt32c9T1HjYXy:
				EblWhIBO81RTfxgnVJ4QHvL = dHrYEIpLofM1qeAK+pEo8g7riWVL014KaRtzQ(u"࠭࠯ࠨᅕ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+LmcNhzY6fQPd2JyCGslkSr(u"ࠧ࠰ࠩᅖ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+XogUJZEijT7KWbxeO6(u"ࠨ࠯ࠪᅗ")+pGzmNqA83DYFiVMr46PnWL5+wwyUWMFAsO(u"ࠩ࠱ࡾ࡮ࡶࠧᅘ")
				if ZK5gkAtjrCeEXYGD2bRQHOF3Moyc not in list(HWlj9JfFKDXtR4.keys()):
					HWlj9JfFKDXtR4[ZK5gkAtjrCeEXYGD2bRQHOF3Moyc] = []
					cxhbLsri96o0AWfXez[ZK5gkAtjrCeEXYGD2bRQHOF3Moyc] = []
				Y8RakyT5eL = XaDMQjxwWpr9ykI2(pGzmNqA83DYFiVMr46PnWL5)
				HWlj9JfFKDXtR4[ZK5gkAtjrCeEXYGD2bRQHOF3Moyc].append((pGzmNqA83DYFiVMr46PnWL5,Y8RakyT5eL,EblWhIBO81RTfxgnVJ4QHvL))
	for ZK5gkAtjrCeEXYGD2bRQHOF3Moyc in list(HWlj9JfFKDXtR4.keys()):
		cxhbLsri96o0AWfXez[ZK5gkAtjrCeEXYGD2bRQHOF3Moyc] = sorted(HWlj9JfFKDXtR4[ZK5gkAtjrCeEXYGD2bRQHOF3Moyc],reverse=xuYvdJpOEyQKTLNwb(u"࡙ࡸࡵࡦ៝"),key=lambda key: key[yTMWeCgUROcvtsblfK85L62xPk(u"࠵ᛄ")])
	Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,AAgpHN0nMZ(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ᅙ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐࠬᅚ"),cxhbLsri96o0AWfXez,Z7uFdWIRv9ybj0)
	return cxhbLsri96o0AWfXez
def XaDMQjxwWpr9ykI2(pGzmNqA83DYFiVMr46PnWL5):
	Y8RakyT5eL = []
	tTa96FKWcqPvrgXhwdN01iyekRB3l7 = pGzmNqA83DYFiVMr46PnWL5.split(Ej67fFyoqW8kbV2HdSK(u"ࠬ࠴ࠧᅛ"))
	for nHoueUS6hLXcjy0dV9JFMwvECfZ5tN in tTa96FKWcqPvrgXhwdN01iyekRB3l7:
		jF2KuMdwrgW = ZXFs0mEPR8qI2zj.findall(Ej67fFyoqW8kbV2HdSK(u"࠭࡜ࡥ࠭ࡿ࡟ࡡ࠱࡜࠮ࡣ࠰ࡾࡆ࠳࡚࡞࠭ࠪᅜ"),nHoueUS6hLXcjy0dV9JFMwvECfZ5tN,ZXFs0mEPR8qI2zj.DOTALL)
		qwVo8DJpExgtaP = []
		for gqX7BtKEdWs4ZYpuSxHn in jF2KuMdwrgW:
			if gqX7BtKEdWs4ZYpuSxHn.isdigit(): gqX7BtKEdWs4ZYpuSxHn = int(gqX7BtKEdWs4ZYpuSxHn)
			qwVo8DJpExgtaP.append(gqX7BtKEdWs4ZYpuSxHn)
		Y8RakyT5eL.append(qwVo8DJpExgtaP)
	return Y8RakyT5eL
def ktSNDyVZwgFT(Y8RakyT5eL):
	pGzmNqA83DYFiVMr46PnWL5 = AAgpHN0nMZ(u"ࠧࠨᅝ")
	for nHoueUS6hLXcjy0dV9JFMwvECfZ5tN in Y8RakyT5eL:
		for gqX7BtKEdWs4ZYpuSxHn in nHoueUS6hLXcjy0dV9JFMwvECfZ5tN: pGzmNqA83DYFiVMr46PnWL5 += str(gqX7BtKEdWs4ZYpuSxHn)
		pGzmNqA83DYFiVMr46PnWL5 += eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨ࠰ࠪᅞ")
	pGzmNqA83DYFiVMr46PnWL5 = pGzmNqA83DYFiVMr46PnWL5.strip(gSmqZU0plur2xKPJwQA(u"ࠩ࠱ࠫᅟ"))
	return pGzmNqA83DYFiVMr46PnWL5
def XxDICeh4Y7yOvFtq(xx7WK5UMjqQ):
	ZUCy6NxE0T7rkjYLpScutH81 = {}
	HWlj9JfFKDXtR4 = LpX1u0IcHw82TMhAWS()
	u3uEcyjGSdUBFCTwt = iixDYHUoBgLIcC7XPT(xx7WK5UMjqQ)
	for ZK5gkAtjrCeEXYGD2bRQHOF3Moyc in xx7WK5UMjqQ:
		if ZK5gkAtjrCeEXYGD2bRQHOF3Moyc not in list(HWlj9JfFKDXtR4.keys()): continue
		cxhbLsri96o0AWfXez = HWlj9JfFKDXtR4[ZK5gkAtjrCeEXYGD2bRQHOF3Moyc]
		ZndOUgIT2XKtp4A3rJV9mYv7l0s,qdDYlWhnL26jymixs5M3GZH8gX,UUu5b0VtLT2h8SGvXaIjicJAEB1zeC = cxhbLsri96o0AWfXez[jYaM5vilgZdFx6QHbApwVXO8et(u"࠵ᛅ")]
		VXjAU9TxqzSBP1DeRvnLcpwo0YfK8,wVtAH7Oq9gNWkBuKl = BBydgcOMpxFImqi5wtV0Pv1EhfzJ(ZK5gkAtjrCeEXYGD2bRQHOF3Moyc)
		Hsp7DiTEZQq2oeBAGbwNWOKl90FVz,hqzZrtv5wjPVFHlxkY = u3uEcyjGSdUBFCTwt[ZK5gkAtjrCeEXYGD2bRQHOF3Moyc]
		pRvLYtkfONxUADzXKV3TE8o92giHn = qdDYlWhnL26jymixs5M3GZH8gX>wVtAH7Oq9gNWkBuKl and Hsp7DiTEZQq2oeBAGbwNWOKl90FVz
		HVhWsdYRMyzq = kRYWcNuAazr4jtmBoxFVS19Z6(u"࡚ࡲࡶࡧ៞")
		if not Hsp7DiTEZQq2oeBAGbwNWOKl90FVz: htyZkGQTeSmCIA9r2Nx1vicMsbH03 = DLSVmlyBbCK(u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫᅠ")
		elif not hqzZrtv5wjPVFHlxkY: htyZkGQTeSmCIA9r2Nx1vicMsbH03 = gnfv8UtZ3daGqpjzk(u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠭ᅡ")
		elif pRvLYtkfONxUADzXKV3TE8o92giHn: htyZkGQTeSmCIA9r2Nx1vicMsbH03 = gSmqZU0plur2xKPJwQA(u"ࠬࡵ࡬ࡥࠩᅢ")
		else:
			htyZkGQTeSmCIA9r2Nx1vicMsbH03 = J3OCAmZVcn(u"࠭ࡧࡰࡱࡧࠫᅣ")
			HVhWsdYRMyzq = EDPaWgMt1SwNn8o(u"ࡆࡢ࡮ࡶࡩ៟")
		ZUCy6NxE0T7rkjYLpScutH81[ZK5gkAtjrCeEXYGD2bRQHOF3Moyc] = (HVhWsdYRMyzq,VXjAU9TxqzSBP1DeRvnLcpwo0YfK8,wVtAH7Oq9gNWkBuKl,ZndOUgIT2XKtp4A3rJV9mYv7l0s,qdDYlWhnL26jymixs5M3GZH8gX,htyZkGQTeSmCIA9r2Nx1vicMsbH03,UUu5b0VtLT2h8SGvXaIjicJAEB1zeC)
	return ZUCy6NxE0T7rkjYLpScutH81
def b8bEl0XjyR4hACKcYkJVP2oBavnGm1(EEA7qzwV381eifP,jyoPfFBiqmw4c96KpCVe,uRieLYyacVpSW4Ul7N21q98G=kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠧࠨᅤ"),AHQ8kCxK102dX9YEWa=wwyUWMFAsO(u"ࠨࠩᅥ"),gwJvlCkXUiG=JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠩࠪᅦ")):
	if Yd6t3PjlLKk: EEA7qzwV381eifP.update(jyoPfFBiqmw4c96KpCVe,uRieLYyacVpSW4Ul7N21q98G,AHQ8kCxK102dX9YEWa,gwJvlCkXUiG)
	else: EEA7qzwV381eifP.update(jyoPfFBiqmw4c96KpCVe,uRieLYyacVpSW4Ul7N21q98G+m6b7CoBk4EQ(u"ࠪࡠࡳ࠭ᅧ")+AHQ8kCxK102dX9YEWa+jYaM5vilgZdFx6QHbApwVXO8et(u"ࠫࡡࡴࠧᅨ")+gwJvlCkXUiG)
	return
def yBUaLu7GJmpc(WYRLUPvTZcIHGAnsljMbKhDBEVNOg):
	def AAGU6PRikEweSOFH(cLxw12BngFMS7To0P,NNegALBo7uywU2CbGQczXpa1,I1dQSCxsKoBHkg=gSmqZU0plur2xKPJwQA(u"ࠧ࠶࠱࠳࠵࠷࠹࠻࠽࠸࠺ࡣࡥࡧࡩ࡫ࡦࡨࡪ࡬࡮ࡰࡲ࡭࡯ࡱࡳࡵࡷࡹࡴࡶࡸࡺࡼࡾࢀࡁࡃࡅࡇࡉࡋࡍࡈࡊࡌࡎࡐࡒࡔࡏࡑࡓࡕࡗ࡙࡛ࡖࡘ࡚࡜࡞ࠧᅩ")):
		return ((cLxw12BngFMS7To0P == bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠶ᛆ")) and I1dQSCxsKoBHkg[bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠶ᛆ")]) or (AAGU6PRikEweSOFH(cLxw12BngFMS7To0P // NNegALBo7uywU2CbGQczXpa1, NNegALBo7uywU2CbGQczXpa1, I1dQSCxsKoBHkg).lstrip(I1dQSCxsKoBHkg[bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠶ᛆ")]) + I1dQSCxsKoBHkg[cLxw12BngFMS7To0P % NNegALBo7uywU2CbGQczXpa1])
	def JxSkrguLyVPmTcn1(fRwXcYOkIQDNg0V, t1XqvOW7h3IDQRuErCjyg, i3huRfgNCQ0DszZV4bp8PlELqyv, KCBfdy3jvZJA, rfucFqxUX2gEBvdSsojhnkblaP1=None, Xt7HVfQSuR2aCM8YsLNoZp4db6K=None, eaVqPMQh8A1xX3crJuTyfzs=None):
		while (i3huRfgNCQ0DszZV4bp8PlELqyv):
			i3huRfgNCQ0DszZV4bp8PlELqyv-=bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠱ᛇ")
			if (KCBfdy3jvZJA[i3huRfgNCQ0DszZV4bp8PlELqyv]): fRwXcYOkIQDNg0V = ZXFs0mEPR8qI2zj.sub(sArCMRngQNmXkBoKv(u"ࠨ࡜࡝ࡤࠥᅪ") + AAGU6PRikEweSOFH(i3huRfgNCQ0DszZV4bp8PlELqyv, t1XqvOW7h3IDQRuErCjyg) + AAgpHN0nMZ(u"ࠢ࡝࡞ࡥࠦᅫ"),  KCBfdy3jvZJA[i3huRfgNCQ0DszZV4bp8PlELqyv], fRwXcYOkIQDNg0V)
		return fRwXcYOkIQDNg0V
	WYRLUPvTZcIHGAnsljMbKhDBEVNOg = WYRLUPvTZcIHGAnsljMbKhDBEVNOg.split(gnfv8UtZ3daGqpjzk(u"ࠨࡿࠫࠫᅬ"))[DLSVmlyBbCK(u"࠲ᛈ")]
	WYRLUPvTZcIHGAnsljMbKhDBEVNOg = WYRLUPvTZcIHGAnsljMbKhDBEVNOg.rsplit(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩࡶࡴࡱ࡯ࡴࠨᅭ"))[XogUJZEijT7KWbxeO6(u"࠲ᛉ")]+JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠥࡷࡵࡲࡩࡵࠪࠪࢀࠬ࠯ࠩࠣᅮ")
	GHNJWEoudbyOrUz = eval(LmcNhzY6fQPd2JyCGslkSr(u"ࠫࡺࡴࡰࡢࡥ࡮ࠬࠬᅯ")+WYRLUPvTZcIHGAnsljMbKhDBEVNOg,{jYaM5vilgZdFx6QHbApwVXO8et(u"ࠬࡨࡡࡴࡧࡑࠫᅰ"):AAGU6PRikEweSOFH,DLSVmlyBbCK(u"࠭ࡵ࡯ࡲࡤࡧࡰ࠭ᅱ"):JxSkrguLyVPmTcn1})
	return GHNJWEoudbyOrUz
def ER1oeQxwHcW5NvqS9m8d(XpOsU3v5dqH8MQAK6FcafmP1z0kL2,UOJ5S1AI9yiKa=ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧࠨᅲ")):
	if UOJ5S1AI9yiKa==XogUJZEijT7KWbxeO6(u"ࠨ࡮ࡲࡻࡪࡸࠧᅳ"): XpOsU3v5dqH8MQAK6FcafmP1z0kL2 = ZXFs0mEPR8qI2zj.sub(xuYvdJpOEyQKTLNwb(u"ࡴࠪࠩࡠ࠶࠭࠺ࡃ࠰࡞ࡢࢁ࠲ࡾࠩᅴ"),lambda F6FPu9pfK7vRjMwEc3hUJoYikl4Iz1: F6FPu9pfK7vRjMwEc3hUJoYikl4Iz1.group(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠳ᛊ")).lower(),XpOsU3v5dqH8MQAK6FcafmP1z0kL2)
	elif UOJ5S1AI9yiKa==xuYvdJpOEyQKTLNwb(u"ࠪࡹࡵࡶࡥࡳࠩᅵ"): XpOsU3v5dqH8MQAK6FcafmP1z0kL2 = ZXFs0mEPR8qI2zj.sub(fR68jBGWCzUsFXdlTKPOScugm(u"ࡶ࡛ࠬࠫ࠱࠯࠼ࡥ࠲ࢀ࡝ࡼ࠴ࢀࠫᅶ"),lambda F6FPu9pfK7vRjMwEc3hUJoYikl4Iz1: F6FPu9pfK7vRjMwEc3hUJoYikl4Iz1.group(gSmqZU0plur2xKPJwQA(u"࠴ᛋ")).upper(),XpOsU3v5dqH8MQAK6FcafmP1z0kL2)
	return XpOsU3v5dqH8MQAK6FcafmP1z0kL2
def iixDYHUoBgLIcC7XPT(xx7WK5UMjqQ):
	BUKhoVxpX4yMRuZ5PIaG,OY34fAiC2s5 = pEo8g7riWVL014KaRtzQ(u"ࡇࡣ࡯ࡷࡪ០"),pEo8g7riWVL014KaRtzQ(u"ࡇࡣ࡯ࡷࡪ០")
	m5h4wdsHCKLvPu9V6rEFi2q = esvtXhdikb2GDJm5Arc.connect(CGoMep90r3LDHfxU16ntBZi8hdaIJg)
	m5h4wdsHCKLvPu9V6rEFi2q.text_factory = str
	nRseEAQwXo4jC21gmqPzIihfUc = m5h4wdsHCKLvPu9V6rEFi2q.cursor()
	if len(xx7WK5UMjqQ)==m6b7CoBk4EQ(u"࠶ᛌ"): AArBg6VQqXe4bMSpjU = aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬ࠮ࠢࠨᅷ")+xx7WK5UMjqQ[AAgpHN0nMZ(u"࠶ᛍ")]+Ej67fFyoqW8kbV2HdSK(u"࠭ࠢࠪࠩᅸ")
	else: AArBg6VQqXe4bMSpjU = str(tuple(xx7WK5UMjqQ))
	nRseEAQwXo4jC21gmqPzIihfUc.execute(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡢࡦࡧࡳࡳࡏࡄ࠭ࡧࡱࡥࡧࡲࡥࡥࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡍࡓࠦࠧᅹ")+AArBg6VQqXe4bMSpjU+LmcNhzY6fQPd2JyCGslkSr(u"ࠨࠢ࠾ࠫᅺ"))
	h72BryKAmUNjZwIqgvYtD = nRseEAQwXo4jC21gmqPzIihfUc.fetchall()
	u3uEcyjGSdUBFCTwt = {}
	for ZK5gkAtjrCeEXYGD2bRQHOF3Moyc in xx7WK5UMjqQ: u3uEcyjGSdUBFCTwt[ZK5gkAtjrCeEXYGD2bRQHOF3Moyc] = (kRYWcNuAazr4jtmBoxFVS19Z6(u"ࡈࡤࡰࡸ࡫១"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࡈࡤࡰࡸ࡫១"))
	for ZK5gkAtjrCeEXYGD2bRQHOF3Moyc,OY34fAiC2s5 in h72BryKAmUNjZwIqgvYtD:
		BUKhoVxpX4yMRuZ5PIaG = LmcNhzY6fQPd2JyCGslkSr(u"ࡗࡶࡺ࡫២")
		OY34fAiC2s5 = OY34fAiC2s5==eeIL1TfgFQJaKqVD8hGNPEZ(u"࠱ᛎ")
		u3uEcyjGSdUBFCTwt[ZK5gkAtjrCeEXYGD2bRQHOF3Moyc] = (BUKhoVxpX4yMRuZ5PIaG,OY34fAiC2s5)
	m5h4wdsHCKLvPu9V6rEFi2q.close()
	return u3uEcyjGSdUBFCTwt
def KJM5ELV47wTIWg(zN3iGUHVMpnEfLrvFDxcPX):
	HkKfQCS7RIa4xi3houjvl = hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠩࠪᅻ")
	if hhHq8m5vauKG9dl.path.exists(zN3iGUHVMpnEfLrvFDxcPX):
		SqKW7xf9uRlLa0 = open(zN3iGUHVMpnEfLrvFDxcPX,ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠪࡶࡧ࠭ᅼ")).read()
		if VYMZsxRpcQHPgkaiDKjyoh: SqKW7xf9uRlLa0 = SqKW7xf9uRlLa0.decode(XogUJZEijT7KWbxeO6(u"ࠫࡺࡺࡦ࠹ࠩᅽ"))
		BPSea4pv6RN7TxrZcq0InDyuK5L = NL0JIkbrEWqTYj61vVKGCnBw37MsOF(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬࡪࡩࡤࡶࠪᅾ"),SqKW7xf9uRlLa0)
		if BPSea4pv6RN7TxrZcq0InDyuK5L:
			HkKfQCS7RIa4xi3houjvl = {}
			for qWMXl6rZ1seT2NBhn in BPSea4pv6RN7TxrZcq0InDyuK5L.keys():
				HkKfQCS7RIa4xi3houjvl[qWMXl6rZ1seT2NBhn] = []
				for TU5LfRXn0OJsi in BPSea4pv6RN7TxrZcq0InDyuK5L[qWMXl6rZ1seT2NBhn]:
					m6egkRrjcavHEdwYDSOs,vABVTz0qOd1anSJ3D,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,knu9Y0BX6ErPRJWT13A5o,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,unjzvHfWpPTbqACy9RtOY6m,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw = EDPaWgMt1SwNn8o(u"࠭ࠧᅿ"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠧࠨᆀ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨࠩᆁ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩࠪᆂ"),aVLSn1xw5cK(u"ࠪࠫᆃ"),xuYvdJpOEyQKTLNwb(u"ࠫࠬᆄ"),sArCMRngQNmXkBoKv(u"ࠬ࠭ᆅ"),c4QSTnPiWUCjhrLlwGB(u"࠭ࠧᆆ"),pEo8g7riWVL014KaRtzQ(u"ࠧࠨᆇ")
					m6egkRrjcavHEdwYDSOs = TU5LfRXn0OJsi[J3OCAmZVcn(u"࠱ᛏ")]
					vABVTz0qOd1anSJ3D = TU5LfRXn0OJsi[XogUJZEijT7KWbxeO6(u"࠳ᛐ")]
					vABVTz0qOd1anSJ3D = NiOkerpvwHXxLGR1Yy9um(vABVTz0qOd1anSJ3D)
					XpOsU3v5dqH8MQAK6FcafmP1z0kL2 = TU5LfRXn0OJsi[pEo8g7riWVL014KaRtzQ(u"࠵ᛑ")]
					knu9Y0BX6ErPRJWT13A5o = TU5LfRXn0OJsi[wwyUWMFAsO(u"࠷ᛒ")]
					ttiasLcTXGvgqb41nC7DRF = TU5LfRXn0OJsi[m6b7CoBk4EQ(u"࠹ᛓ")]
					wwNtFTLK2IqAszYBDV9J = TU5LfRXn0OJsi[eeIL1TfgFQJaKqVD8hGNPEZ(u"࠻ᛔ")]
					if len(TU5LfRXn0OJsi)>eeIL1TfgFQJaKqVD8hGNPEZ(u"࠶ᛕ"): unjzvHfWpPTbqACy9RtOY6m = TU5LfRXn0OJsi[eeIL1TfgFQJaKqVD8hGNPEZ(u"࠶ᛕ")]
					if len(TU5LfRXn0OJsi)>aVLSn1xw5cK(u"࠸ᛖ"): UISsAqZ5MGpEvJntk2N0LgbFuzHTK6 = TU5LfRXn0OJsi[aVLSn1xw5cK(u"࠸ᛖ")]
					if len(TU5LfRXn0OJsi)>AAgpHN0nMZ(u"࠺ᛗ"): B0BjfWuVKkht7gPaNqFsTJOdcHbw = TU5LfRXn0OJsi[AAgpHN0nMZ(u"࠺ᛗ")]
					if zN3iGUHVMpnEfLrvFDxcPX==P71CANTSyWYptGs8JnZkUHu3Kwi6Ql: xOhU8RblmVP = m6egkRrjcavHEdwYDSOs,vABVTz0qOd1anSJ3D,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,knu9Y0BX6ErPRJWT13A5o,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,unjzvHfWpPTbqACy9RtOY6m,gnfv8UtZ3daGqpjzk(u"ࠨࠩᆈ"),B0BjfWuVKkht7gPaNqFsTJOdcHbw
					else: xOhU8RblmVP = m6egkRrjcavHEdwYDSOs,vABVTz0qOd1anSJ3D,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,knu9Y0BX6ErPRJWT13A5o,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,unjzvHfWpPTbqACy9RtOY6m,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw
					HkKfQCS7RIa4xi3houjvl[qWMXl6rZ1seT2NBhn].append(xOhU8RblmVP)
		DLK8qQNC0619awSOAkohrJXU7 = str(HkKfQCS7RIa4xi3houjvl)
		if VYMZsxRpcQHPgkaiDKjyoh: DLK8qQNC0619awSOAkohrJXU7 = DLK8qQNC0619awSOAkohrJXU7.encode(AAgpHN0nMZ(u"ࠩࡸࡸ࡫࠾ࠧᆉ"))
		open(zN3iGUHVMpnEfLrvFDxcPX,eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠪࡻࡧ࠭ᆊ")).write(DLK8qQNC0619awSOAkohrJXU7)
	return HkKfQCS7RIa4xi3houjvl
def Cqb7Pp23AvmRTwQhjroY68uKE4ye(ji1dGuYnsFNKe):
	K6hOlLQc1kynI5t8XEfCP3pjmNA = ji1dGuYnsFNKe.split(xuYvdJpOEyQKTLNwb(u"ࠫ࠲࠭ᆋ"),LmcNhzY6fQPd2JyCGslkSr(u"࠴ᛘ"))[bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠴ᛙ")]
	terDuEzAxwJBMfij2Z3VTyOn5bU,hRXOg9EUnHF,dGbUpZ6N7WX52BLmR4vfz = kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠬ࠭ᆌ"),XogUJZEijT7KWbxeO6(u"࠭ࠧᆍ"),pEo8g7riWVL014KaRtzQ(u"ࠧࠨᆎ")
	if   K6hOlLQc1kynI5t8XEfCP3pjmNA==J3OCAmZVcn(u"ࠨࡃࡋ࡛ࡆࡑࠧᆏ")		:	from aFn7TlwuWq			import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==gnfv8UtZ3daGqpjzk(u"ࠩࡄࡏࡔࡇࡍࠨᆐ")		:	from mCTR9VFong			import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==sArCMRngQNmXkBoKv(u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑࠬᆑ")	:	from oV8DHKQf25		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==aVLSn1xw5cK(u"ࠫࡆࡑࡗࡂࡏࠪᆒ")		:	from FN6uzHvdbp			import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==ZSJVq5XDrRot(u"ࠬࡇࡌࡂࡔࡄࡆࠬᆓ")	:	from Ml3d4o2esx			import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==J3OCAmZVcn(u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉࠨᆔ")	:	from tZHX76ugUT		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==kmdSKeBIwViM9t3(u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔࠪᆕ")	: 	from V8VuXMhUew		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪᆖ")	:	from aagcLB1H9T		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==OVmSuf8tpd(u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧᆗ"):	from TTEnLQIMeW	import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==aVLSn1xw5cK(u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬᆘ")	:	from iRzsfUmpP7		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==jYaM5vilgZdFx6QHbApwVXO8et(u"ࠫࡇࡕࡋࡓࡃࠪᆙ")		:	from dpINwXmrSA			import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==kmdSKeBIwViM9t3(u"ࠬࡈࡒࡔࡖࡈࡎࠬᆚ")	:	from VgZh1PxFql			import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==Ej67fFyoqW8kbV2HdSK(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧᆛ")	:	from J8DPkmleWz		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==aVLSn1xw5cK(u"ࠧࡄࡋࡐࡅ࠹࡛ࠧᆜ")	:	from jrfTYWXZnv			import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑࠪᆝ")	:	from BMiW1qeG8b		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==OVmSuf8tpd(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࡛ࡔࡘࡋࠨᆞ"):	from E4E51cx7Zq	import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==LmcNhzY6fQPd2JyCGslkSr(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬᆟ"):		from u2APxIQdlD		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==kmdSKeBIwViM9t3(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠭ᆠ")	:	from Ea7O1mGSgv		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==AAgpHN0nMZ(u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧᆡ")	:	from W49pfiPnCH		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==JMLhEyaBWmskovGHTrVCxQ08(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩᆢ")	:	from zeHi9kbLcZ		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==pEo8g7riWVL014KaRtzQ(u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨᆣ")	:	from iNwU014Zu7		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭ᆤ"):	from hyzijIU4w3	import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==xuYvdJpOEyQKTLNwb(u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪᆥ")	:	from HB9slYrGKq		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==xuYvdJpOEyQKTLNwb(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫᆦ")	:	from foyTwPNklz		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭ᆧ")	:	from jRx1tlqX0z		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸ࠧᆨ")	:	from tbohC2lJn3		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==J3OCAmZVcn(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠳ࠨᆩ")	:	from KK7JZeE4GP		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵ࠩᆪ")	:	from ShN9wm1BE8		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==xuYvdJpOEyQKTLNwb(u"ࠨࡇࡊ࡝ࡉࡋࡁࡅࠩᆫ")	:	from cae3Us4hwj		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==xuYvdJpOEyQKTLNwb(u"ࠩࡈࡋ࡞ࡔࡏࡘࠩᆬ")	:	from rr8BvkwspK			import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫᆭ")	:	from ydvYhtoqkf		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==c4QSTnPiWUCjhrLlwGB(u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧᆮ")	:	from RaP18ex9yp		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==xuYvdJpOEyQKTLNwb(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧᆯ")	:	from L5Wip7lPhd		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==yTMWeCgUROcvtsblfK85L62xPk(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨᆰ")	:	from byPuAs5w3T		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==gSmqZU0plur2xKPJwQA(u"ࠧࡇࡑࡖࡘࡆ࠭ᆱ")		:	from sDIuzwKn2V			import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==DLSVmlyBbCK(u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪᆲ")	:	from zzRXnV0x6N		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠩࡌࡊࡎࡒࡍࠨᆳ")		:	from DKjZTYuh2d			import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠪࡍࡕ࡚ࡖࠨᆴ")		:	from uu80ZYa2sG	import rUedtQkCXJq as terDuEzAxwJBMfij2Z3VTyOn5bU,ZQTkpw4se6EOaIrgNLn as hRXOg9EUnHF,oYkzVLIgyjNpsiTbZSBQ as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==gSmqZU0plur2xKPJwQA(u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧᆵ")	:	from lEv3OAV9W2		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==wwyUWMFAsO(u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧᆶ")	:	from t5A1SMbXW2		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅࠨᆷ")	:	from U0UaVBJHgY		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࡍࡃࡕࡓ࡟ࡇࠧᆸ")	:	from HPo3xEClYW			import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩᆹ")	:	from rZNXI2Ki3b		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==EDPaWgMt1SwNn8o(u"ࠩࡐ࠷࡚࠭ᆺ")		:	from Yj2oWQg6sb	import rUedtQkCXJq as terDuEzAxwJBMfij2Z3VTyOn5bU,ZQTkpw4se6EOaIrgNLn as hRXOg9EUnHF,oYkzVLIgyjNpsiTbZSBQ as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࡑࡔ࡜ࡓ࠵ࡗࠪᆻ")	:	from D2DLOUb5Qx			import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==FhcnOB9t3frzvXb(u"ࠫࡒ࡟ࡃࡊࡏࡄࠫᆼ")	:	from z8zlcAXu7D			import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==EDPaWgMt1SwNn8o(u"ࠬࡖࡁࡏࡇࡗࠫᆽ")		:	from pPqIT7ySwO			import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨᆾ")	:	from epWEGAh8dK		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==c4QSTnPiWUCjhrLlwGB(u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫᆿ"):	from D0Da3tgVUJ		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==XogUJZEijT7KWbxeO6(u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫᇀ")	:	from tNqL8MgEnu		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩࡖࡌࡔࡌࡈࡂࠩᇁ")	:	from E2RU1x6hfF			import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==pEo8g7riWVL014KaRtzQ(u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬᇂ")	:	from LoAjV7akcH		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==sArCMRngQNmXkBoKv(u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠭ᇃ")	:	from yLKZ3U5T8o		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==DLSVmlyBbCK(u"࡚ࠬࡖࡇࡗࡑࠫᇄ")		:	from tjAQk8gwul			import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==aVLSn1xw5cK(u"࠭ࡗࡆࡅࡌࡑࡆ࠭ᇅ")	:	from GAOBVmq23j			import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==c4QSTnPiWUCjhrLlwGB(u"࡚ࠧࡃࡔࡓ࡙࠭ᇆ")		:	from VVnZDU48aC			import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==fR68jBGWCzUsFXdlTKPOScugm(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩᇇ")	:	from gmlsMyZIhB		import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU,F6OgHwYPRiX10tJEv8r as hRXOg9EUnHF,W74fAyGxODoLPs5vMX2l8C93R as dGbUpZ6N7WX52BLmR4vfz
	elif K6hOlLQc1kynI5t8XEfCP3pjmNA==sArCMRngQNmXkBoKv(u"ࠩ࡜ࡘࡇࡥࡃࡉࡃࡑࡒࡊࡒࡓࠨᇈ"):	from xxS1KjEBZg	import oMUN5hPpTkxVZG12Qiva8BKnyw6 as terDuEzAxwJBMfij2Z3VTyOn5bU
	return terDuEzAxwJBMfij2Z3VTyOn5bU,hRXOg9EUnHF,dGbUpZ6N7WX52BLmR4vfz
def L41Ku9Nxqcsw(tUG6HPuhLyeAvfS9n8JzXmK,yJQ0WizojdcChZPM4,showDialogs):
	tr24ZoudmqvxfYCw(ZSJVq5XDrRot(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪᇉ"),kmdSKeBIwViM9t3(u"ࠫ࠳ࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫࠿࡛ࠦࠡࠩᇊ")+tUG6HPuhLyeAvfS9n8JzXmK+PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨᇋ")+str(yJQ0WizojdcChZPM4)+J3OCAmZVcn(u"࠭ࠠ࡞ࠩᇌ"))
	EEA7qzwV381eifP = a6Nd4etSry0P1W()
	EEA7qzwV381eifP.create(FhcnOB9t3frzvXb(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᇍ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨ์ฯี๏ࠦวๅฤ้ࠤๆำีࠡษ็้้็ࠠศๆ่฻้๎ศࠡฬะ้๏๊็๊ࠡห฽ิํวࠡี๋ๅࠥะศะลࠣ฽๊๊๊สࠢฯ่อࠦวๅ็็ๅ๋ࠥๆࠡษ็ษ๋ะั็ฬࠪᇎ"))
	y2yDWXiNdze7 = hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠶࠶࠲࠵ᛚ")*hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠶࠶࠲࠵ᛚ")
	tcPp40mOV7WjulIr2 = jYaM5vilgZdFx6QHbApwVXO8et(u"࠷ᛛ")*y2yDWXiNdze7
	wvdJxFK9nk = EfD78uCdxyZSO.get(tUG6HPuhLyeAvfS9n8JzXmK,stream=pEo8g7riWVL014KaRtzQ(u"ࡘࡷࡻࡥ៣"),headers=yJQ0WizojdcChZPM4)
	XybmStLkxVUR7ahG4qgY3dDIriB = wvdJxFK9nk.headers
	wvdJxFK9nk.close()
	dpaFOTGeDNlUvAJYcWSuqH = bytes()
	if not XybmStLkxVUR7ahG4qgY3dDIriB:
		if showDialogs: HHTzVhiY079bvdluNkFQ4wCMpe(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࠪᇏ"),LmcNhzY6fQPd2JyCGslkSr(u"ࠪࠫᇐ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᇑ"),DLSVmlyBbCK(u"ࠬอไษำ้ห๊าࠠๅ็ࠣ๎ฯ๋ใ็่๊ࠢࠥะอๆ์็ࠤฬ๊ๅๅใࠣห้๋ืๅ๊หࠤํอไิสหࠤ็ี๋ࠠๅ๋๊ࠥ฿ๆะๅู้้ࠣไสࠢไ๎ࠥอไฦ่อี๋ะࠠศๆัหฺࠦศไࠢ࠱ࠤัืศࠡฬะ้๏๊ࠠศๆ่่ๆࠦๅาหࠣวำื้ࠨᇒ"))
		EEA7qzwV381eifP.close()
	else:
		if yTMWeCgUROcvtsblfK85L62xPk(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡍࡧࡱ࡫ࡹ࡮ࠧᇓ") not in list(XybmStLkxVUR7ahG4qgY3dDIriB.keys()): NN9mEkKacGlUJqyRCOwsrj61 = kmdSKeBIwViM9t3(u"࠰ᛜ")
		else: NN9mEkKacGlUJqyRCOwsrj61 = int(XybmStLkxVUR7ahG4qgY3dDIriB[JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨᇔ")])
		ssqAVJzkogUCnH2P1Tc9BpI0GOx = str(int(jYaM5vilgZdFx6QHbApwVXO8et(u"࠳࠳࠴࠵ᛞ")*NN9mEkKacGlUJqyRCOwsrj61/y2yDWXiNdze7)/kmdSKeBIwViM9t3(u"࠲࠲࠳࠴࠳࠶ᛝ"))
		vdiIm5tSoyQBwMCNFr6fJGAz3xp = int(NN9mEkKacGlUJqyRCOwsrj61/tcPp40mOV7WjulIr2)+yTMWeCgUROcvtsblfK85L62xPk(u"࠴ᛟ")
		if bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡕࡥࡳ࡭ࡥࠨᇕ") in list(XybmStLkxVUR7ahG4qgY3dDIriB.keys()) and NN9mEkKacGlUJqyRCOwsrj61>y2yDWXiNdze7:
			EM09gtWTr4 = fR68jBGWCzUsFXdlTKPOScugm(u"࡙ࡸࡵࡦ៤")
			HaVnqjtxZQ7dO6Eh = []
			zO4avLxr6f0WiSXQTw = yTMWeCgUROcvtsblfK85L62xPk(u"࠵࠵ᛠ")
			HaVnqjtxZQ7dO6Eh.append(str(m6b7CoBk4EQ(u"࠶ᛢ")*NN9mEkKacGlUJqyRCOwsrj61//zO4avLxr6f0WiSXQTw)+J3OCAmZVcn(u"ࠩ࠰ࠫᇖ")+str(ZSJVq5XDrRot(u"࠶ᛡ")*NN9mEkKacGlUJqyRCOwsrj61//zO4avLxr6f0WiSXQTw-ZSJVq5XDrRot(u"࠶ᛡ")))
			HaVnqjtxZQ7dO6Eh.append(str(AAgpHN0nMZ(u"࠱ᛣ")*NN9mEkKacGlUJqyRCOwsrj61//zO4avLxr6f0WiSXQTw)+aVLSn1xw5cK(u"ࠪ࠱ࠬᇗ")+str(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠳ᛤ")*NN9mEkKacGlUJqyRCOwsrj61//zO4avLxr6f0WiSXQTw-AAgpHN0nMZ(u"࠱ᛣ")))
			HaVnqjtxZQ7dO6Eh.append(str(OVmSuf8tpd(u"࠶ᛧ")*NN9mEkKacGlUJqyRCOwsrj61//zO4avLxr6f0WiSXQTw)+AAgpHN0nMZ(u"ࠫ࠲࠭ᇘ")+str(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠶ᛦ")*NN9mEkKacGlUJqyRCOwsrj61//zO4avLxr6f0WiSXQTw-DLSVmlyBbCK(u"࠳ᛥ")))
			HaVnqjtxZQ7dO6Eh.append(str(yTMWeCgUROcvtsblfK85L62xPk(u"࠹ᛩ")*NN9mEkKacGlUJqyRCOwsrj61//zO4avLxr6f0WiSXQTw)+XogUJZEijT7KWbxeO6(u"ࠬ࠳ࠧᇙ")+str(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠴ᛪ")*NN9mEkKacGlUJqyRCOwsrj61//zO4avLxr6f0WiSXQTw-XogUJZEijT7KWbxeO6(u"࠶ᛨ")))
			HaVnqjtxZQ7dO6Eh.append(str(bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠷᛭")*NN9mEkKacGlUJqyRCOwsrj61//zO4avLxr6f0WiSXQTw)+sArCMRngQNmXkBoKv(u"࠭࠭ࠨᇚ")+str(gSmqZU0plur2xKPJwQA(u"࠷᛬")*NN9mEkKacGlUJqyRCOwsrj61//zO4avLxr6f0WiSXQTw-kmdSKeBIwViM9t3(u"࠲᛫")))
			HaVnqjtxZQ7dO6Eh.append(str(AAgpHN0nMZ(u"࠺ᛯ")*NN9mEkKacGlUJqyRCOwsrj61//zO4avLxr6f0WiSXQTw)+jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧ࠮ࠩᇛ")+str(jYaM5vilgZdFx6QHbApwVXO8et(u"࠼ᛰ")*NN9mEkKacGlUJqyRCOwsrj61//zO4avLxr6f0WiSXQTw-JMLhEyaBWmskovGHTrVCxQ08(u"࠵ᛮ")))
			HaVnqjtxZQ7dO6Eh.append(str(pEo8g7riWVL014KaRtzQ(u"࠸ᛳ")*NN9mEkKacGlUJqyRCOwsrj61//zO4avLxr6f0WiSXQTw)+EDPaWgMt1SwNn8o(u"ࠨ࠯ࠪᇜ")+str(FhcnOB9t3frzvXb(u"࠸ᛲ")*NN9mEkKacGlUJqyRCOwsrj61//zO4avLxr6f0WiSXQTw-hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠱ᛱ")))
			HaVnqjtxZQ7dO6Eh.append(str(c4QSTnPiWUCjhrLlwGB(u"࠼ᛶ")*NN9mEkKacGlUJqyRCOwsrj61//zO4avLxr6f0WiSXQTw)+hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠩ࠰ࠫᇝ")+str(AAgpHN0nMZ(u"࠼ᛵ")*NN9mEkKacGlUJqyRCOwsrj61//zO4avLxr6f0WiSXQTw-bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠴ᛴ")))
			HaVnqjtxZQ7dO6Eh.append(str(wwyUWMFAsO(u"࠸ᛸ")*NN9mEkKacGlUJqyRCOwsrj61//zO4avLxr6f0WiSXQTw)+XogUJZEijT7KWbxeO6(u"ࠪ࠱ࠬᇞ")+str(m6b7CoBk4EQ(u"࠿ᛷ")*NN9mEkKacGlUJqyRCOwsrj61//zO4avLxr6f0WiSXQTw-jYaM5vilgZdFx6QHbApwVXO8et(u"࠲᛹")))
			HaVnqjtxZQ7dO6Eh.append(str(jYaM5vilgZdFx6QHbApwVXO8et(u"࠻᛺")*NN9mEkKacGlUJqyRCOwsrj61//zO4avLxr6f0WiSXQTw)+sArCMRngQNmXkBoKv(u"ࠫ࠲࠭ᇟ"))
			NCt6XbHjAOrBkPgDM = float(vdiIm5tSoyQBwMCNFr6fJGAz3xp)/zO4avLxr6f0WiSXQTw
			jDJE2M3dSWaNf4tGVAlh6IORP = NCt6XbHjAOrBkPgDM/int(XogUJZEijT7KWbxeO6(u"࠴᛻")+NCt6XbHjAOrBkPgDM)
		else:
			EM09gtWTr4 = bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࡌࡡ࡭ࡵࡨ៥")
			zO4avLxr6f0WiSXQTw = kmdSKeBIwViM9t3(u"࠵᛼")
			jDJE2M3dSWaNf4tGVAlh6IORP = aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠶᛽")
		tr24ZoudmqvxfYCw(DLSVmlyBbCK(u"ࠬࡔࡏࡕࡋࡆࡉࠬᇠ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭࠮ࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡺࡹࡩ࡯ࡩࠣࡶࡦࡴࡧࡦࡵ࠽ࠤࡠࠦࠧᇡ")+str(EM09gtWTr4)+J3OCAmZVcn(u"ࠧࠡ࡟ࠣࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩᇢ")+str(NN9mEkKacGlUJqyRCOwsrj61)+OVmSuf8tpd(u"ࠨࠢࡠࠫᇣ"))
		OeT2Jo0sp6h1mGdqfFw,KPyAw5LC40U9SlhR = J3OCAmZVcn(u"࠶᛾"),J3OCAmZVcn(u"࠶᛾")
		for TzRI3GLUr9laoJNeDd1O8kW in range(zO4avLxr6f0WiSXQTw):
			obS4TpHeV3digGC = yJQ0WizojdcChZPM4.copy()
			if EM09gtWTr4: obS4TpHeV3digGC[m6b7CoBk4EQ(u"ࠩࡕࡥࡳ࡭ࡥࠨᇤ")] = xuYvdJpOEyQKTLNwb(u"ࠪࡦࡾࡺࡥࡴ࠿ࠪᇥ")+HaVnqjtxZQ7dO6Eh[TzRI3GLUr9laoJNeDd1O8kW]
			wvdJxFK9nk = EfD78uCdxyZSO.get(tUG6HPuhLyeAvfS9n8JzXmK,stream=Ej67fFyoqW8kbV2HdSK(u"ࡔࡳࡷࡨ៦"),headers=obS4TpHeV3digGC,timeout=DLSVmlyBbCK(u"࠳࠱࠲᛿"))
			for isEy90bxRMLtGPZABwI in wvdJxFK9nk.iter_content(chunk_size=tcPp40mOV7WjulIr2):
				if EEA7qzwV381eifP.iscanceled():
					tr24ZoudmqvxfYCw(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠫࡓࡕࡔࡊࡅࡈࠫᇦ"),pEo8g7riWVL014KaRtzQ(u"ࠬ࠴ࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡇࡦࡴࡣࡦ࡮ࡨࡨࠬᇧ"))
					break
				OeT2Jo0sp6h1mGdqfFw += jDJE2M3dSWaNf4tGVAlh6IORP
				dpaFOTGeDNlUvAJYcWSuqH += isEy90bxRMLtGPZABwI
				if not KPyAw5LC40U9SlhR: KPyAw5LC40U9SlhR = len(isEy90bxRMLtGPZABwI)
				if NN9mEkKacGlUJqyRCOwsrj61: b8bEl0XjyR4hACKcYkJVP2oBavnGm1(EEA7qzwV381eifP,ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠲࠲࠳ᜀ")*OeT2Jo0sp6h1mGdqfFw//vdiIm5tSoyQBwMCNFr6fJGAz3xp,m6b7CoBk4EQ(u"࠭ฬๅสࠣห้๋ไโ࠼࠰ࠤฬ๊ฬำรࠣี็๋ࠧᇨ"),str(aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠳࠳࠴࠳࠶ᜁ")*KPyAw5LC40U9SlhR*OeT2Jo0sp6h1mGdqfFw//tcPp40mOV7WjulIr2//aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠳࠳࠴࠳࠶ᜁ"))+c4QSTnPiWUCjhrLlwGB(u"ࠧࠡ࠱ࠣࠫᇩ")+ssqAVJzkogUCnH2P1Tc9BpI0GOx+PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠨࠢࡐࡆࠬᇪ"))
				else: b8bEl0XjyR4hACKcYkJVP2oBavnGm1(EEA7qzwV381eifP,KPyAw5LC40U9SlhR*OeT2Jo0sp6h1mGdqfFw//tcPp40mOV7WjulIr2,jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩฯ่อࠦวๅ็็ๅ࠿࠳ࠧᇫ"),str(kRYWcNuAazr4jtmBoxFVS19Z6(u"࠴࠴࠵࠴࠰ᜂ")*KPyAw5LC40U9SlhR*OeT2Jo0sp6h1mGdqfFw//tcPp40mOV7WjulIr2//kRYWcNuAazr4jtmBoxFVS19Z6(u"࠴࠴࠵࠴࠰ᜂ"))+JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠪࠤࡒࡈࠧᇬ"))
			wvdJxFK9nk.close()
		EEA7qzwV381eifP.close()
		if len(dpaFOTGeDNlUvAJYcWSuqH)<NN9mEkKacGlUJqyRCOwsrj61 and NN9mEkKacGlUJqyRCOwsrj61>sArCMRngQNmXkBoKv(u"࠴ᜃ"):
			tr24ZoudmqvxfYCw(kmdSKeBIwViM9t3(u"ࠫࡓࡕࡔࡊࡅࡈࠫᇭ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠬ࠴ࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡪࡦ࡯࡬ࡦࡦࠣࡳࡷࠦࡣࡢࡰࡦࡩࡱ࡫ࡤࠡࡣࡷ࠾ࠥࡡࠠࠨᇮ")+str(len(dpaFOTGeDNlUvAJYcWSuqH)//y2yDWXiNdze7)+pEo8g7riWVL014KaRtzQ(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡇࡴࡲࡱࠥࡺ࡯ࡵࡣ࡯ࠤࡴ࡬࠺ࠡ࡝ࠣࠫᇯ")+ssqAVJzkogUCnH2P1Tc9BpI0GOx+m6b7CoBk4EQ(u"ࠧࠡࡏࡅࠤࡢ࠭ᇰ"))
			HBJbZpwN23hveudOrcI68W0M = A0iaw7hK4Qmc2EeHXZB(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨࠩᇱ"),kmdSKeBIwViM9t3(u"ࠩศ่฿อม๊ࠡัีําࠧᇲ"),aVLSn1xw5cK(u"ࠪหุะฮะษ่ࠤฬ๊ๅๅใࠣห้์วใืࠪᇳ"),gnfv8UtZ3daGqpjzk(u"ࠫส฿วะหࠣะ้ฮࠠศๆ่่ๆ࠭ᇴ"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᇵ"),sArCMRngQNmXkBoKv(u"࠭แีๆࠣๅ๏ࠦฬๅสࠣห้๋ไโࠢ࡟ࡲ๊ࠥไฤีไࠤาีหࠡะฺวࠥ็๊ࠡฬะ้๏๊ࠠศๆ่่ๆࠦ࡜࡯ࠢอ้ࠥาไษࠢࠪᇶ")+str(len(dpaFOTGeDNlUvAJYcWSuqH)//y2yDWXiNdze7)+bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࠡ็ํ฾ฬฮว๋ฬ้๋ࠣࠦๅอ็๋฽ࠥ࠭ᇷ")+ssqAVJzkogUCnH2P1Tc9BpI0GOx+jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨ่ࠢ๎฿อศศ์อࠤࡡࡴࠠอำหࠤั๊ศࠡษ็้้็ࠠๆำฬࠤศิั๊ࠢ࡟ࡲࠥํไࠡฬิ๎ิࠦวิฬัำฬ๋ࠠศๆ่่ๆࠦวๅ่สๆฺࠦฟࠢࠣࠪᇸ"))
			if HBJbZpwN23hveudOrcI68W0M==J3OCAmZVcn(u"࠷ᜄ"): dpaFOTGeDNlUvAJYcWSuqH = L41Ku9Nxqcsw(tUG6HPuhLyeAvfS9n8JzXmK,yJQ0WizojdcChZPM4,showDialogs)
			elif HBJbZpwN23hveudOrcI68W0M==JMLhEyaBWmskovGHTrVCxQ08(u"࠷ᜅ"): tr24ZoudmqvxfYCw(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩᇹ"),J3OCAmZVcn(u"ࠪ࠲ࠥࠦࡎࡰࡶࠣࡧࡴࡳࡰ࡭ࡧࡷࡩࡩࠦࡤࡰࡹࡱࡰࡴࡧࡤࡦࡦࠣࡪ࡮ࡲࡥࠡ࡫ࡶࠤࡦࡩࡣࡦࡲࡷࡩࡩࠦࡡ࡯ࡦࠣࡻ࡮ࡲ࡬ࠡࡤࡨࠤࡺࡹࡥࡥࠩᇺ"))
			else: return OVmSuf8tpd(u"ࠫࠬᇻ")
			if not dpaFOTGeDNlUvAJYcWSuqH: return eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬ࠭ᇼ")
		else: tr24ZoudmqvxfYCw(OVmSuf8tpd(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ᇽ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧ࠯ࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨ࡙ࠥࡵࡤࡥࡨࡩࡩ࡫ࡤ࠯ࠢࠣࠤࡋ࡯࡬ࡦࠢࡖ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫᇾ")+ssqAVJzkogUCnH2P1Tc9BpI0GOx+wwyUWMFAsO(u"ࠨࠢࡐࡆࠥࡣࠧᇿ"))
	return dpaFOTGeDNlUvAJYcWSuqH
def H8HW0TzGuiU(ll6f2wvU4FdqL3MJyDxORESCK197i):
	return wvdJxFK9nk
def lTqcJaeunfS2YrEVIFNmMHG(ip=FhcnOB9t3frzvXb(u"ࠩࠪሀ")):
	aJL1jVFzNWiDeXGhSOrxvp,SvVD2AkXlf17EFnY,OvAF0JZNzcY8yTl6WjkDEs,MfGqQNE47bPzDcJg,LLT7s0cFVEofDlW8yXQzarmvdiZ,zzRidb8K2LZB4uHeEml = LmcNhzY6fQPd2JyCGslkSr(u"ࠪࠫሁ"),xuYvdJpOEyQKTLNwb(u"ࠫࠬሂ"),aVLSn1xw5cK(u"ࠬ࠭ሃ"),JMLhEyaBWmskovGHTrVCxQ08(u"࠭ࠧሄ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧࠨህ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨࠩሆ")
	XpOsU3v5dqH8MQAK6FcafmP1z0kL2 = LmcNhzY6fQPd2JyCGslkSr(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡬ࡴࡼ࡮࡯࠯࡫ࡶ࠳ࠬሇ")+ip+jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪࡃࡴࡻࡴࡱࡷࡷࡁ࡯ࡹ࡯࡯ࠨࡩ࡭ࡪࡲࡤࡴ࠿࡬ࡴ࠱ࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴ࠭ࡥࡲࡹࡳࡺࡲࡺ࠮ࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥ࠭ࡴࡨ࡫࡮ࡵ࡮࠭ࡥ࡬ࡸࡾ࠲ࡴࡪ࡯ࡨࡾࡴࡴࡥࠨለ")
	yJQ0WizojdcChZPM4 = {eeIL1TfgFQJaKqVD8hGNPEZ(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨሉ"):sArCMRngQNmXkBoKv(u"ࠬ࠭ሊ")}
	wvdJxFK9nk = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,eeIL1TfgFQJaKqVD8hGNPEZ(u"࠭ࡇࡆࡖࠪላ"),XpOsU3v5dqH8MQAK6FcafmP1z0kL2,hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧࠨሌ"),yJQ0WizojdcChZPM4,bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࠩል"),J3OCAmZVcn(u"ࠩࠪሎ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡏࡍࡑࡆࡅ࡙ࡏࡏࡏ࠯࠴ࡷࡹ࠭ሏ"))
	if not wvdJxFK9nk.succeeded: K6yLQmfzv7OAXCqln9oig0U4a3St = ip+MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠫ࠱࠭ሐ")+aJL1jVFzNWiDeXGhSOrxvp+kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠬ࠲ࠧሑ")+SvVD2AkXlf17EFnY+DLSVmlyBbCK(u"࠭ࠬࠨሒ")+MfGqQNE47bPzDcJg+AAgpHN0nMZ(u"ࠧ࠭ࠩሓ")+LLT7s0cFVEofDlW8yXQzarmvdiZ+gSmqZU0plur2xKPJwQA(u"ࠨ࠮ࠪሔ")+zzRidb8K2LZB4uHeEml
	else:
		vdCNK2GykrWZIVeg7z5S4HFh = wvdJxFK9nk.content
		vdCNK2GykrWZIVeg7z5S4HFh = ZXFs0mEPR8qI2zj.findall(sArCMRngQNmXkBoKv(u"ࠩ࡟ࡿ࠳࠰࠿࡝ࡿ࡟ࢁࠬሕ"),vdCNK2GykrWZIVeg7z5S4HFh,ZXFs0mEPR8qI2zj.DOTALL)
		if vdCNK2GykrWZIVeg7z5S4HFh:
			vdCNK2GykrWZIVeg7z5S4HFh = vdCNK2GykrWZIVeg7z5S4HFh[MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠰ᜆ")]
			oEcYXzm1ln8FKGLhkdr0VJgPw9 = NL0JIkbrEWqTYj61vVKGCnBw37MsOF(J3OCAmZVcn(u"ࠪࡨ࡮ࡩࡴࠨሖ"),vdCNK2GykrWZIVeg7z5S4HFh)
			FHWYwjrlZvK3 = list(oEcYXzm1ln8FKGLhkdr0VJgPw9.keys())
			if eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫ࡮ࡶࠧሗ") in FHWYwjrlZvK3: ip = oEcYXzm1ln8FKGLhkdr0VJgPw9[JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬ࡯ࡰࠨመ")]
			if DLSVmlyBbCK(u"࠭ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵࠩሙ") in FHWYwjrlZvK3: aJL1jVFzNWiDeXGhSOrxvp = oEcYXzm1ln8FKGLhkdr0VJgPw9[gnfv8UtZ3daGqpjzk(u"ࠧࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶࠪሚ")]
			if xuYvdJpOEyQKTLNwb(u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩማ") in FHWYwjrlZvK3: SvVD2AkXlf17EFnY = oEcYXzm1ln8FKGLhkdr0VJgPw9[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪሜ")]
			if yTMWeCgUROcvtsblfK85L62xPk(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦࠩም") in FHWYwjrlZvK3: OvAF0JZNzcY8yTl6WjkDEs = oEcYXzm1ln8FKGLhkdr0VJgPw9[sArCMRngQNmXkBoKv(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࡤࡩ࡯ࡥࡧࠪሞ")]
			if sArCMRngQNmXkBoKv(u"ࠬࡸࡥࡨ࡫ࡲࡲࠬሟ") in FHWYwjrlZvK3: MfGqQNE47bPzDcJg = oEcYXzm1ln8FKGLhkdr0VJgPw9[DLSVmlyBbCK(u"࠭ࡲࡦࡩ࡬ࡳࡳ࠭ሠ")]
			if ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧࡤ࡫ࡷࡽࠬሡ") in FHWYwjrlZvK3: LLT7s0cFVEofDlW8yXQzarmvdiZ = oEcYXzm1ln8FKGLhkdr0VJgPw9[JMLhEyaBWmskovGHTrVCxQ08(u"ࠨࡥ࡬ࡸࡾ࠭ሢ")]
			if gSmqZU0plur2xKPJwQA(u"ࠩࡷ࡭ࡲ࡫ࡺࡰࡰࡨࠫሣ") in FHWYwjrlZvK3:
				zzRidb8K2LZB4uHeEml = oEcYXzm1ln8FKGLhkdr0VJgPw9[kmdSKeBIwViM9t3(u"ࠪࡸ࡮ࡳࡥࡻࡱࡱࡩࠬሤ")][m6b7CoBk4EQ(u"ࠫࡺࡺࡣࠨሥ")]
				if zzRidb8K2LZB4uHeEml[pEo8g7riWVL014KaRtzQ(u"࠱ᜇ")] not in [eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬ࠳ࠧሦ"),EDPaWgMt1SwNn8o(u"࠭ࠫࠨሧ")]: zzRidb8K2LZB4uHeEml = OVmSuf8tpd(u"ࠧࠬࠩረ")+zzRidb8K2LZB4uHeEml
			K6yLQmfzv7OAXCqln9oig0U4a3St = ip+hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠨ࠮ࠪሩ")+aJL1jVFzNWiDeXGhSOrxvp+eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠩ࠯ࠫሪ")+SvVD2AkXlf17EFnY+FhcnOB9t3frzvXb(u"ࠪ࠰ࠬራ")+MfGqQNE47bPzDcJg+c4QSTnPiWUCjhrLlwGB(u"ࠫ࠱࠭ሬ")+LLT7s0cFVEofDlW8yXQzarmvdiZ+Ej67fFyoqW8kbV2HdSK(u"ࠬ࠲ࠧር")+zzRidb8K2LZB4uHeEml
			if VYMZsxRpcQHPgkaiDKjyoh: K6yLQmfzv7OAXCqln9oig0U4a3St = K6yLQmfzv7OAXCqln9oig0U4a3St.encode(EDPaWgMt1SwNn8o(u"࠭ࡵࡵࡨ࠻ࠫሮ")).decode(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨሯ"))
	K6yLQmfzv7OAXCqln9oig0U4a3St = WhJe7bGx5XackTwOIZVLC8ut(K6yLQmfzv7OAXCqln9oig0U4a3St)
	return K6yLQmfzv7OAXCqln9oig0U4a3St
def XDzpr8RxgZhT(grdRuyKQi5DToakpOwIjxV16):
	UBtIANfmcP,showDialogs = kmdSKeBIwViM9t3(u"ࠨࠩሰ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࡕࡴࡸࡩ៧")
	if grdRuyKQi5DToakpOwIjxV16.count(gnfv8UtZ3daGqpjzk(u"ࠩࡢࠫሱ"))>=LmcNhzY6fQPd2JyCGslkSr(u"࠴ᜈ"):
		grdRuyKQi5DToakpOwIjxV16,UBtIANfmcP = grdRuyKQi5DToakpOwIjxV16.split(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࡣࠬሲ"),ZSJVq5XDrRot(u"࠴ᜉ"))
		UBtIANfmcP = c4QSTnPiWUCjhrLlwGB(u"ࠫࡤ࠭ሳ")+UBtIANfmcP
		if PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࠪሴ") in UBtIANfmcP: showDialogs = gSmqZU0plur2xKPJwQA(u"ࡈࡤࡰࡸ࡫៨")
		else: showDialogs = gnfv8UtZ3daGqpjzk(u"ࡗࡶࡺ࡫៩")
	return grdRuyKQi5DToakpOwIjxV16,UBtIANfmcP,showDialogs
def ZFj2BomiVuntxCv5dYEUyKgX():
	ywvHBKsXJgjPW3uc = hhHq8m5vauKG9dl.path.join(J5keFiyQtf9bGZ0vulzNIsTYMx1oR,ZSJVq5XDrRot(u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬስ"))
	SfyPWiO4LQBV3gbGxoRwpY9Ce1dK = gSmqZU0plur2xKPJwQA(u"࠴ᜊ")
	if hhHq8m5vauKG9dl.path.exists(ywvHBKsXJgjPW3uc):
		for dhJn8VcYtlwIBb0Su7WFmi in hhHq8m5vauKG9dl.listdir(ywvHBKsXJgjPW3uc):
			if JMLhEyaBWmskovGHTrVCxQ08(u"ࠧ࠯ࡲࡼࡳࠬሶ") in dhJn8VcYtlwIBb0Su7WFmi: continue
			if gnfv8UtZ3daGqpjzk(u"ࠨࡡࡢࡴࡾࡩࡡࡤࡪࡨࡣࡤ࠭ሷ") in dhJn8VcYtlwIBb0Su7WFmi: continue
			x2B7p6d5qXaW8wnluf1jKeVZcENI = hhHq8m5vauKG9dl.path.join(ywvHBKsXJgjPW3uc,dhJn8VcYtlwIBb0Su7WFmi)
			aZAiV53PSI0XFWj,Bn1eRl2KbGqszdFYJ8Z3S4I = ssIxDJ3iKeVqBUvFYW4r(x2B7p6d5qXaW8wnluf1jKeVZcENI)
			SfyPWiO4LQBV3gbGxoRwpY9Ce1dK += aZAiV53PSI0XFWj
	return SfyPWiO4LQBV3gbGxoRwpY9Ce1dK
def XGx6Bsa9nEuiPD(showDialogs):
	iVYo04R83hyzAJTjWQk5x = j2agIU0xsLS6c7T.getSetting(c4QSTnPiWUCjhrLlwGB(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧሸ"))
	Ll3fjOGHh2i7U4wMKtesZ = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,kmdSKeBIwViM9t3(u"ࠪࡷࡹࡸࠧሹ"),LmcNhzY6fQPd2JyCGslkSr(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧሺ"),sArCMRngQNmXkBoKv(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧሻ"))
	YbsV4xSuGCkAp8PLMfT7eInrjJWgz,lU2ObRvwyHx = iVYo04R83hyzAJTjWQk5x,Ll3fjOGHh2i7U4wMKtesZ
	KLJizZkRDnu2cC,fh8b26cngAurjlWRmK1Lx = JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭ࠧሼ"),LmcNhzY6fQPd2JyCGslkSr(u"ࠧࠨሽ")
	if hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠶ᜋ"):
		XpOsU3v5dqH8MQAK6FcafmP1z0kL2 = uReHcEzxkTm6pN4Q[aVLSn1xw5cK(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨሾ")][m6b7CoBk4EQ(u"࠹ᜌ")]
		hhC9JITqv3yWEGFm = HHWAnGJrb9powOqTkYgcPQ6Ef(DLSVmlyBbCK(u"࠳࠳ᜍ"))
		K6yLQmfzv7OAXCqln9oig0U4a3St = lTqcJaeunfS2YrEVIFNmMHG()
		SvVD2AkXlf17EFnY = K6yLQmfzv7OAXCqln9oig0U4a3St.split(gnfv8UtZ3daGqpjzk(u"ࠩ࠯ࠫሿ"))[DLSVmlyBbCK(u"࠳ᜎ")]
		SfyPWiO4LQBV3gbGxoRwpY9Ce1dK = ZFj2BomiVuntxCv5dYEUyKgX()
		QnIsrBC7Wc3tOSXbGJp8l = {eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠪࡹࡸ࡫ࡲࠨቀ"):hhC9JITqv3yWEGFm,jYaM5vilgZdFx6QHbApwVXO8et(u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬቁ"):i69DxzEZSwmuY5Il,Ej67fFyoqW8kbV2HdSK(u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭ቂ"):SvVD2AkXlf17EFnY,yTMWeCgUROcvtsblfK85L62xPk(u"࠭ࡩࡥࡵࠪቃ"):uD0IBl6nS9jqNekYZXaxzd2(SfyPWiO4LQBV3gbGxoRwpY9Ce1dK)}
		wvdJxFK9nk = A6F71g3cqN4(KxirmCLT6Gw,ZSJVq5XDrRot(u"ࠧࡑࡑࡖࡘࠬቄ"),XpOsU3v5dqH8MQAK6FcafmP1z0kL2,QnIsrBC7Wc3tOSXbGJp8l,aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨࠩቅ"),Ej67fFyoqW8kbV2HdSK(u"ࠩࠪቆ"),xuYvdJpOEyQKTLNwb(u"ࠪࠫቇ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡕࡡࡐࡉࡘ࡙ࡁࡈࡇࡖ࠱࠶ࡹࡴࠨቈ"))
		if not wvdJxFK9nk.succeeded:
			if iVYo04R83hyzAJTjWQk5x in [AAgpHN0nMZ(u"ࠬ࠭቉"),EDPaWgMt1SwNn8o(u"࠭ࡎࡆ࡙ࠪቊ")]: YbsV4xSuGCkAp8PLMfT7eInrjJWgz = aVLSn1xw5cK(u"ࠧࡏࡇ࡚ࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭ቋ")
			elif iVYo04R83hyzAJTjWQk5x==sArCMRngQNmXkBoKv(u"ࠨࡑࡏࡈࠬቌ"): YbsV4xSuGCkAp8PLMfT7eInrjJWgz = EDPaWgMt1SwNn8o(u"ࠩࡒࡐࡉࡥࡔࡐࡡࡈࡖࡗࡕࡒࠨቍ")
		else:
			rUbdDe3GaEj = wvdJxFK9nk.content
			rUbdDe3GaEj = NL0JIkbrEWqTYj61vVKGCnBw37MsOF(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࡰ࡮ࡹࡴࠨ቎"),rUbdDe3GaEj)
			rUbdDe3GaEj = sorted(rUbdDe3GaEj,reverse=eeIL1TfgFQJaKqVD8hGNPEZ(u"ࡘࡷࡻࡥ៪"),key=lambda key: int(key[J3OCAmZVcn(u"࠲ᜏ")]))
			fh8b26cngAurjlWRmK1Lx,lU2ObRvwyHx = FhcnOB9t3frzvXb(u"ࠫࠬ቏"),AAgpHN0nMZ(u"ࠬ࠭ቐ")
			for Bx1MRVGFirb6chvgI2nYaDpO,szohLkcCMgarR7K69wyYEFUjxbt8l,d0Z7abLoEfmpHTOkgVG in rUbdDe3GaEj:
				if Bx1MRVGFirb6chvgI2nYaDpO==PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭࠰ࠨቑ"):
					fh8b26cngAurjlWRmK1Lx += d0Z7abLoEfmpHTOkgVG+kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠧ࠻࠼ࠪቒ")
					continue
				if lU2ObRvwyHx: lU2ObRvwyHx += wwyUWMFAsO(u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯ࠩቓ")
				G4uzaiVPLnpvdTcEZtrbKYS = d0Z7abLoEfmpHTOkgVG.split(XogUJZEijT7KWbxeO6(u"ࠩ࡟ࡲࠬቔ"))[wwyUWMFAsO(u"࠳ᜐ")]
				vbYfzUgrlIPBTJA312n7dciSQx0Dq = Ej67fFyoqW8kbV2HdSK(u"ࠪีุอไสࠢัหฺฯࠠๅๅࠣๅ็฽ࠧቕ") if szohLkcCMgarR7K69wyYEFUjxbt8l else DLSVmlyBbCK(u"ࠫࠬቖ")
				lU2ObRvwyHx += d0Z7abLoEfmpHTOkgVG.replace(G4uzaiVPLnpvdTcEZtrbKYS,aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ቗")+G4uzaiVPLnpvdTcEZtrbKYS+vbYfzUgrlIPBTJA312n7dciSQx0Dq+OVmSuf8tpd(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨቘ"))+LmcNhzY6fQPd2JyCGslkSr(u"ࠧ࡝ࡰࠪ቙")
			lU2ObRvwyHx = gSmqZU0plur2xKPJwQA(u"ࠨ࡞ࡱࠫቚ")+lU2ObRvwyHx+sArCMRngQNmXkBoKv(u"ࠩ࡟ࡲࡡࡴࠧቛ")
			fh8b26cngAurjlWRmK1Lx = fh8b26cngAurjlWRmK1Lx.strip(EDPaWgMt1SwNn8o(u"ࠪ࠾࠿࠭ቜ"))
			KLJizZkRDnu2cC = j2agIU0xsLS6c7T.getSetting(LmcNhzY6fQPd2JyCGslkSr(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠷ࠧቝ"))
			if lU2ObRvwyHx==Ll3fjOGHh2i7U4wMKtesZ and iVYo04R83hyzAJTjWQk5x in [yTMWeCgUROcvtsblfK85L62xPk(u"ࠬࡕࡌࡅࠩ቞"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭ࡏࡍࡆࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬ቟")]: YbsV4xSuGCkAp8PLMfT7eInrjJWgz = hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧࡐࡎࡇࠫበ")
			else: YbsV4xSuGCkAp8PLMfT7eInrjJWgz = sArCMRngQNmXkBoKv(u"ࠨࡐࡈ࡛ࠬቡ")
			Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,m6b7CoBk4EQ(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬቢ"),pEo8g7riWVL014KaRtzQ(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬባ"),lU2ObRvwyHx,iKYM8NdkGHmBcr)
			j2agIU0xsLS6c7T.setSetting(c4QSTnPiWUCjhrLlwGB(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡱࡪࡹࡳࡢࡩࡨࡷࠬቤ"),uD0IBl6nS9jqNekYZXaxzd2(F5I1VZzxkXenKuEAYO))
			j2agIU0xsLS6c7T.setSetting(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹ࠱ࠨብ"),fh8b26cngAurjlWRmK1Lx)
			from hashlib import md5 as ppq7nbP8zdkSt20aCVK3rY9
			HY1K74yAmEacxL8VITDd5MhGgQBsit = ppq7nbP8zdkSt20aCVK3rY9(AAgpHN0nMZ(u"࠹ᜑ")*fh8b26cngAurjlWRmK1Lx.encode(FhcnOB9t3frzvXb(u"࠭ࡵࡵࡨ࠻ࠫቦ"))).hexdigest()
			HY1K74yAmEacxL8VITDd5MhGgQBsit = ppq7nbP8zdkSt20aCVK3rY9(AAgpHN0nMZ(u"࠶࠺ᜒ")*HY1K74yAmEacxL8VITDd5MhGgQBsit.encode(m6b7CoBk4EQ(u"ࠧࡶࡶࡩ࠼ࠬቧ"))).hexdigest()
			HY1K74yAmEacxL8VITDd5MhGgQBsit = ppq7nbP8zdkSt20aCVK3rY9(eeIL1TfgFQJaKqVD8hGNPEZ(u"࠷࠹ᜓ")*HY1K74yAmEacxL8VITDd5MhGgQBsit.encode(yTMWeCgUROcvtsblfK85L62xPk(u"ࠨࡷࡷࡪ࠽࠭ቨ"))).hexdigest()
			j2agIU0xsLS6c7T.setSetting(OVmSuf8tpd(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ࠶ࠬቩ"),HY1K74yAmEacxL8VITDd5MhGgQBsit)
	if showDialogs:
		if YbsV4xSuGCkAp8PLMfT7eInrjJWgz in [hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠪࡓࡑࡊ࡟ࡕࡑࡢࡉࡗࡘࡏࡓࠩቪ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫࡓࡋࡗࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪቫ")]:
			HHTzVhiY079bvdluNkFQ4wCMpe(Ej67fFyoqW8kbV2HdSK(u"ࠬ࠭ቬ"),pEo8g7riWVL014KaRtzQ(u"࠭ࠧቭ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪቮ"),J3OCAmZVcn(u"ࠨ้้ห่ࠦๅีๅ็อࠥ็๊ࠡฮ๊หื้้้ࠠํࠤ้๐ำห่๊ࠢࠥอไษำ้ห๊าࠠ࠯࠰๋ࠣีํࠠศๆุ่่๊ษࠡไาࠤ๏้่็ࠢึฬอํวࠡษ็ษ๋ะั็ฬࠣห้ิวึࠢห็ࠥษ่ࠡษ็ีฬ๎สาࠢส่ำอีࠡสๆࠤศ๎ࠠๆึๆ่ฮࠦแ๋ࠢส่ศูไศๅࠣ฽๋ีใࠨቯ"))
		else:
			FD5mbRq2ypcA6QOUE8hG(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩࡵ࡭࡬࡮ࡴࠨተ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠪีุอฦๅ่๊ࠢࠥอไๆสิ้ัࠦลๅุ๋้ࠣะฮะ็ํࠤฬ๊ศา่ส้ั࠭ቱ"),lU2ObRvwyHx,yTMWeCgUROcvtsblfK85L62xPk(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬቲ"))
			YbsV4xSuGCkAp8PLMfT7eInrjJWgz = yTMWeCgUROcvtsblfK85L62xPk(u"ࠬࡕࡌࡅࠩታ")
	if YbsV4xSuGCkAp8PLMfT7eInrjJWgz!=iVYo04R83hyzAJTjWQk5x:
		j2agIU0xsLS6c7T.setSetting(JMLhEyaBWmskovGHTrVCxQ08(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫቴ"),YbsV4xSuGCkAp8PLMfT7eInrjJWgz)
		cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(AAgpHN0nMZ(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫት"))
	du39cjxwQqvhBVAfNClDi = pEo8g7riWVL014KaRtzQ(u"࡚ࡲࡶࡧ៬") if fh8b26cngAurjlWRmK1Lx!=KLJizZkRDnu2cC else gnfv8UtZ3daGqpjzk(u"ࡋࡧ࡬ࡴࡧ៫")
	if du39cjxwQqvhBVAfNClDi:
		NLVM3HAtxQOSvJf6kd78K1o(FhcnOB9t3frzvXb(u"ࠨ่ฯัฯูࠦๆๆํอࠥะอะ์ฮࠤฬ๊ีๅษะ๎ฬะࠧቶ"),Ej67fFyoqW8kbV2HdSK(u"ࠩࡖࡹࡨࡩࡥࡴࡵࠪቷ"),luMHeSgCBaPrb9KvUjNFqcR=yTMWeCgUROcvtsblfK85L62xPk(u"࠷࠶࠲᜔"))
		iiysxZ8dOaA(AAgpHN0nMZ(u"ࠪࡊࡴࡸࡣࡦࡦࠣࡩࡽ࡯ࡴࠡࡶࡲࠤࡦࡶࡰ࡭ࡻࠣࡲࡪࡽࠠࡱࡴ࡬ࡺ࡮ࡲࡥࡨࡧࡶࠫቸ"))
	return du39cjxwQqvhBVAfNClDi
def eLsVYNQShdAc0mapgIFbu34l(CC462TptPM3lv,pRu510YASI2ikPwnrKZ):
	from socket import socket as z1FdwRrY6OLgZ,AF_INET as MfgOeR2YHEWhp,SOCK_STREAM as r2GOwLkB5Wmasb6EhogVCt1
	EtVLHXqGIwQjlpDFcRabZ123 = z1FdwRrY6OLgZ(MfgOeR2YHEWhp,r2GOwLkB5Wmasb6EhogVCt1)
	EtVLHXqGIwQjlpDFcRabZ123.settimeout(J3OCAmZVcn(u"࠲᜕"))
	RMAgiUJIDre4,xxYCIt685WfoXZgruUPGiD9cJlTKnb = ZSJVq5XDrRot(u"ࡔࡳࡷࡨ៭"),LmcNhzY6fQPd2JyCGslkSr(u"࠲᜖")
	BkeMNv4iXH3 = luMHeSgCBaPrb9KvUjNFqcR.time()
	try: EtVLHXqGIwQjlpDFcRabZ123.connect((CC462TptPM3lv,pRu510YASI2ikPwnrKZ))
	except: RMAgiUJIDre4 = xuYvdJpOEyQKTLNwb(u"ࡇࡣ࡯ࡷࡪ៮")
	lwf2tjLc6WER5pY91HVTKya8MU = luMHeSgCBaPrb9KvUjNFqcR.time()
	if RMAgiUJIDre4: xxYCIt685WfoXZgruUPGiD9cJlTKnb = lwf2tjLc6WER5pY91HVTKya8MU-BkeMNv4iXH3
	return xxYCIt685WfoXZgruUPGiD9cJlTKnb
def MCAInGyaz6mZwUx4gjqBb(showDialogs):
	if showDialogs:
		YYkEu4IL0sTa = OxCB4medn1(kmdSKeBIwViM9t3(u"ࠫࠬቹ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠬ࠭ቺ"),jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࠧቻ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪቼ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠨี๋ๅࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥอไร่ࠣฬส฻ไศฯࠣ์ฯ์ุ๋ใࠣะ๊๐ูࠡไ๋ห฾ีࠠศๆห๎ฬ์วห๋ࠢห้้วีࠢสู่๊สฯั่อࠥ็๊ࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠหึ฽๎ู้ࠦๆๆํอࠥอไห่฻๎ๆࠦวๅฤ้ࠤฤࠧࠧች"))
	else: YYkEu4IL0sTa = m6b7CoBk4EQ(u"ࡖࡵࡹࡪ៯")
	if YYkEu4IL0sTa==EDPaWgMt1SwNn8o(u"࠴᜗"):
		for dhJn8VcYtlwIBb0Su7WFmi in hhHq8m5vauKG9dl.listdir(mATvU6VbxOXNFhz8lK5WGrfQ):
			if dhJn8VcYtlwIBb0Su7WFmi.endswith(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠩ࠱ࡨࡧ࠭ቾ")) and eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠪࡨࡦࡺࡡࠨቿ") in dhJn8VcYtlwIBb0Su7WFmi:
				tP325FYWofVAzLGEuSQN6ZHk1dIq = hhHq8m5vauKG9dl.path.join(mATvU6VbxOXNFhz8lK5WGrfQ,dhJn8VcYtlwIBb0Su7WFmi)
				try: m5h4wdsHCKLvPu9V6rEFi2q,nRseEAQwXo4jC21gmqPzIihfUc = xocasQYVZLF5(tP325FYWofVAzLGEuSQN6ZHk1dIq)
				except: return
				nRseEAQwXo4jC21gmqPzIihfUc.execute(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡮ࡴࡴࡦࡩࡵ࡭ࡹࡿ࡟ࡤࡪࡨࡧࡰࡁࠧኀ"))
				nRseEAQwXo4jC21gmqPzIihfUc.execute(gSmqZU0plur2xKPJwQA(u"ࠬࡖࡒࡂࡉࡐࡅࠥࡵࡰࡵ࡫ࡰ࡭ࡿ࡫࠻ࠨኁ"))
				nRseEAQwXo4jC21gmqPzIihfUc.execute(yTMWeCgUROcvtsblfK85L62xPk(u"࠭ࡖࡂࡅࡘ࡙ࡒࡁࠧኂ"))
				m5h4wdsHCKLvPu9V6rEFi2q.commit()
				m5h4wdsHCKLvPu9V6rEFi2q.close()
		if showDialogs:
			HHTzVhiY079bvdluNkFQ4wCMpe(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࠨኃ"),FhcnOB9t3frzvXb(u"ࠨࠩኄ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬኅ"),c4QSTnPiWUCjhrLlwGB(u"ࠪฮ๊ะࠠษ่ฯหาูࠦๆๆํอࠥหีๅษะࠤํะๆู์ไࠤัฺ๋๊ࠢๅ์ฬ฿ฯࠡษ็ฬ๏อๆศฬࠣ์ฬ๊ใศึࠣห้๋ำหะา้ฮࠦแ๋ࠢส่อืๆศ็ฯࠫኆ"))
	return
def K18gduYeq29CsrQN(ppKk3AhNdXng16ZwsFj,C5UAr17g2ORcjX,showDialogs):
	if ppKk3AhNdXng16ZwsFj!=None:
		global RnVrCam6JhskEpe7T2BD0yjtcq1
		RnVrCam6JhskEpe7T2BD0yjtcq1 = ppKk3AhNdXng16ZwsFj
	if C5UAr17g2ORcjX!=None:
		global Gwc7u3bFf8U
		Gwc7u3bFf8U = C5UAr17g2ORcjX
	if showDialogs!=None:
		global cOW5nr0N8FDHX1TZf4q7zM6m
		cOW5nr0N8FDHX1TZf4q7zM6m = showDialogs
	return
RnVrCam6JhskEpe7T2BD0yjtcq1,Gwc7u3bFf8U,cOW5nr0N8FDHX1TZf4q7zM6m = xuYvdJpOEyQKTLNwb(u"ࠫࠬኇ"),EDPaWgMt1SwNn8o(u"ࠬ࠭ኈ"),LmcNhzY6fQPd2JyCGslkSr(u"࠭ࠧ኉")
def ilfKOa2xLFvXCywYQ(nJDfuczrBG4ZeOs,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,data,headers,allow_redirects,showDialogs,j5jMXZ7myEuoLG,PPwsGxBAMTvE56tL9ohCl,P8P01rposdK5Vk):
	if showDialogs==J3OCAmZVcn(u"ࠧࠨኊ"): WaVLXft1im89uH5blkvRPEjyOex = JMLhEyaBWmskovGHTrVCxQ08(u"ࡗࡶࡺ࡫៰") if cOW5nr0N8FDHX1TZf4q7zM6m==MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨࠩኋ") else cOW5nr0N8FDHX1TZf4q7zM6m
	else: WaVLXft1im89uH5blkvRPEjyOex = XogUJZEijT7KWbxeO6(u"࡙ࡸࡵࡦ៲") if showDialogs else gnfv8UtZ3daGqpjzk(u"ࡊࡦࡲࡳࡦ៱")
	if P8P01rposdK5Vk==sArCMRngQNmXkBoKv(u"ࠩࠪኌ"): qbG87zkKNdI0txW = hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࡚ࡲࡶࡧ៳") if Gwc7u3bFf8U==JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠪࠫኍ") else Gwc7u3bFf8U
	else: qbG87zkKNdI0txW = FhcnOB9t3frzvXb(u"ࡕࡴࡸࡩ៵") if P8P01rposdK5Vk else PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࡆࡢ࡮ࡶࡩ៴")
	if PPwsGxBAMTvE56tL9ohCl==EDPaWgMt1SwNn8o(u"ࠫࠬ኎"): VeAMjb76TC1imXNGYthn42QWB = AAgpHN0nMZ(u"ࡖࡵࡹࡪ៶") if RnVrCam6JhskEpe7T2BD0yjtcq1==c4QSTnPiWUCjhrLlwGB(u"ࠬ࠭኏") else RnVrCam6JhskEpe7T2BD0yjtcq1
	else: VeAMjb76TC1imXNGYthn42QWB = wwyUWMFAsO(u"ࡘࡷࡻࡥ៸") if PPwsGxBAMTvE56tL9ohCl else ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࡉࡥࡱࡹࡥ៷")
	if allow_redirects==FhcnOB9t3frzvXb(u"࠭ࠧነ"): bw2MplmGB1NOITx = wwyUWMFAsO(u"࡙ࡸࡵࡦ៹")
	else: bw2MplmGB1NOITx = aVLSn1xw5cK(u"ࡔࡳࡷࡨ៻") if allow_redirects else pEo8g7riWVL014KaRtzQ(u"ࡌࡡ࡭ࡵࡨ៺")
	obS4TpHeV3digGC = {} if headers==aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧࠨኑ") else headers
	BTMputsaqV = {} if data==jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨࠩኒ") else data
	A6VoE2Z1PpkOiuGSreH5n9h = list(obS4TpHeV3digGC.keys())
	if yTMWeCgUROcvtsblfK85L62xPk(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪና") not in A6VoE2Z1PpkOiuGSreH5n9h: obS4TpHeV3digGC[fR68jBGWCzUsFXdlTKPOScugm(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫኔ")] = yTMWeCgUROcvtsblfK85L62xPk(u"ࠫ࡭ࡺࡴࡱࠩን")
	if gnfv8UtZ3daGqpjzk(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩኖ") not in A6VoE2Z1PpkOiuGSreH5n9h: obS4TpHeV3digGC[Ej67fFyoqW8kbV2HdSK(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪኗ")] = SjMG7CYyUqbPVso0DErhXROvkl(EDPaWgMt1SwNn8o(u"ࡕࡴࡸࡩ៼"))
	return nJDfuczrBG4ZeOs,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,BTMputsaqV,obS4TpHeV3digGC,bw2MplmGB1NOITx,WaVLXft1im89uH5blkvRPEjyOex,j5jMXZ7myEuoLG,VeAMjb76TC1imXNGYthn42QWB,qbG87zkKNdI0txW
def ggAhyPE3zSu(nJDfuczrBG4ZeOs,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,SOlDApJEx73FokmVdYCfKuRNXy8,yJQ0WizojdcChZPM4,rCH9LTAcqthZnFOpU76bxPmWdG,showDialogs,j5jMXZ7myEuoLG,PPwsGxBAMTvE56tL9ohCl=pEo8g7riWVL014KaRtzQ(u"ࠧࠨኘ"),P8P01rposdK5Vk=bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࠩኙ")):
	s8nZN31lf7OUr2J = ilfKOa2xLFvXCywYQ(nJDfuczrBG4ZeOs,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,SOlDApJEx73FokmVdYCfKuRNXy8,yJQ0WizojdcChZPM4,rCH9LTAcqthZnFOpU76bxPmWdG,showDialogs,j5jMXZ7myEuoLG,PPwsGxBAMTvE56tL9ohCl,P8P01rposdK5Vk)
	nJDfuczrBG4ZeOs,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,BTMputsaqV,obS4TpHeV3digGC,bw2MplmGB1NOITx,WaVLXft1im89uH5blkvRPEjyOex,j5jMXZ7myEuoLG,VeAMjb76TC1imXNGYthn42QWB,qbG87zkKNdI0txW = s8nZN31lf7OUr2J
	lQHXdV9Nzf6BLqS8D,b6jTGhv0gK,a7043au5scA2dQextyrVvCzGoq,Ehvu5RXJdc826O = glE1Zx2einabXPjKV3DvMu(XpOsU3v5dqH8MQAK6FcafmP1z0kL2)
	UCnYqvDtGZgPHdaiN2Of48pjL = j2agIU0xsLS6c7T.getSetting(AAgpHN0nMZ(u"ࠩࡤࡺ࠳ࡪ࡮ࡴࠩኚ"))
	urEw42gLtCNeoXclaksQbAViZd39 = j2agIU0xsLS6c7T.getSetting(LmcNhzY6fQPd2JyCGslkSr(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ኛ"))
	AwQmhUJRXj0qtbCz3BpSYl6Zkuone = j2agIU0xsLS6c7T.getSetting(Ej67fFyoqW8kbV2HdSK(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩኜ"))
	veqJ4nouVLf3cS6dEg = [kmdSKeBIwViM9t3(u"ࠬࡹࡣࡳࡣࡳࡩࡷࡧࡰࡪࠩኝ"),gSmqZU0plur2xKPJwQA(u"࠭ࡳࡤࡴࡤࡴࡪࡵࡰࡴࠩኞ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧࡴࡥࡵࡥࡵ࡯࡮ࡨࡣࡱࡸࠬኟ"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠨࡵࡦࡶࡦࡶࡥࡶࡲࠪአ"),gnfv8UtZ3daGqpjzk(u"ࠩࡶࡧࡷࡧࡰࡦ࠰ࡧࡳࠬኡ")]
	aUgZ4whHA75BFWMPXosOdmCk = hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࡗࡶࡺ࡫៾") if any(AARNPWHjQU9dEmDI in XpOsU3v5dqH8MQAK6FcafmP1z0kL2 for AARNPWHjQU9dEmDI in veqJ4nouVLf3cS6dEg) else eeIL1TfgFQJaKqVD8hGNPEZ(u"ࡈࡤࡰࡸ࡫៽")
	if EDPaWgMt1SwNn8o(u"ࠪࠪࡺࡸ࡬࠾ࠩኢ") in lQHXdV9Nzf6BLqS8D and aUgZ4whHA75BFWMPXosOdmCk: kkQaWCZOFq4vzGp2wd = lQHXdV9Nzf6BLqS8D.rsplit(ZSJVq5XDrRot(u"ࠫࠫࡻࡲ࡭࠿ࠪኣ"),JMLhEyaBWmskovGHTrVCxQ08(u"࠵᜘"))[JMLhEyaBWmskovGHTrVCxQ08(u"࠵᜘")]
	else: kkQaWCZOFq4vzGp2wd = aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬ࠭ኤ")
	uRJNCDU2dWTI63pf7hbzoyO4HGk = uReHcEzxkTm6pN4Q[EDPaWgMt1SwNn8o(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭እ")]
	iiosLBOqPmgTl = lQHXdV9Nzf6BLqS8D in uRJNCDU2dWTI63pf7hbzoyO4HGk or kkQaWCZOFq4vzGp2wd in uRJNCDU2dWTI63pf7hbzoyO4HGk
	kYIinmzTbdLOKWP7JsvEX = uReHcEzxkTm6pN4Q[c4QSTnPiWUCjhrLlwGB(u"ࠧࡓࡇࡓࡓࡘ࠭ኦ")]
	M56lRsXp8oQeYTzg = lQHXdV9Nzf6BLqS8D in kYIinmzTbdLOKWP7JsvEX or kkQaWCZOFq4vzGp2wd in kYIinmzTbdLOKWP7JsvEX
	go9dDr1tMbNpG0SxjyH2 = iiosLBOqPmgTl or M56lRsXp8oQeYTzg
	ZLHyVwueBXMNFiPnmDU = b6jTGhv0gK==None and a7043au5scA2dQextyrVvCzGoq==None and not aUgZ4whHA75BFWMPXosOdmCk
	if ZLHyVwueBXMNFiPnmDU and go9dDr1tMbNpG0SxjyH2:
		if iiosLBOqPmgTl:
			UCcgFE4JTPvYAaxsGhpWLdZ = uRJNCDU2dWTI63pf7hbzoyO4HGk.index(lQHXdV9Nzf6BLqS8D)
			ebiLv0FgGr = uReHcEzxkTm6pN4Q[kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔࠬኧ")][UCcgFE4JTPvYAaxsGhpWLdZ]
			PM6godIBhtY9SpwUKs1 = Hhl2G8LRwq7[UCcgFE4JTPvYAaxsGhpWLdZ]
		elif M56lRsXp8oQeYTzg:
			UCcgFE4JTPvYAaxsGhpWLdZ = kYIinmzTbdLOKWP7JsvEX.index(lQHXdV9Nzf6BLqS8D)
			ebiLv0FgGr = uReHcEzxkTm6pN4Q[FhcnOB9t3frzvXb(u"ࠩࡕࡉࡕࡕࡓࡠࡄࡎࡔࠬከ")][UCcgFE4JTPvYAaxsGhpWLdZ]
			PM6godIBhtY9SpwUKs1 = dRv1o5GDY4QV[UCcgFE4JTPvYAaxsGhpWLdZ]
	if a7043au5scA2dQextyrVvCzGoq==c4QSTnPiWUCjhrLlwGB(u"ࠪࠫኩ"): a7043au5scA2dQextyrVvCzGoq = UCnYqvDtGZgPHdaiN2Of48pjL
	elif a7043au5scA2dQextyrVvCzGoq==None and urEw42gLtCNeoXclaksQbAViZd39 in [xuYvdJpOEyQKTLNwb(u"ࠫࡆ࡛ࡔࡐࠩኪ"),gnfv8UtZ3daGqpjzk(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧካ")] and VeAMjb76TC1imXNGYthn42QWB: a7043au5scA2dQextyrVvCzGoq = UCnYqvDtGZgPHdaiN2Of48pjL
	mBQfPRTikLWc7I = lQHXdV9Nzf6BLqS8D==uReHcEzxkTm6pN4Q[JMLhEyaBWmskovGHTrVCxQ08(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ኬ")][aVLSn1xw5cK(u"࠼᜙")]
	if iiosLBOqPmgTl or M56lRsXp8oQeYTzg: DyGfNV3WpHzPF2CL = pEo8g7riWVL014KaRtzQ(u"࠷࠵᜚")
	elif j5jMXZ7myEuoLG in ppEw9HgZkCPtvnjV4Y: DyGfNV3WpHzPF2CL = xuYvdJpOEyQKTLNwb(u"࠱࠱᜛")
	elif j5jMXZ7myEuoLG==MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈ࡚ࡊࡘࡓࡐࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩክ"): DyGfNV3WpHzPF2CL = Ej67fFyoqW8kbV2HdSK(u"࠳࠲᜜")
	elif j5jMXZ7myEuoLG==Ej67fFyoqW8kbV2HdSK(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩኮ"): DyGfNV3WpHzPF2CL = fR68jBGWCzUsFXdlTKPOScugm(u"࠴࠳᜝")
	elif J3OCAmZVcn(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡘࡃࡐࠫኯ") in j5jMXZ7myEuoLG: DyGfNV3WpHzPF2CL = FhcnOB9t3frzvXb(u"࠺࠴᜞")
	elif hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠪࡗࡍࡕࡆࡉࡃࠪኰ") in j5jMXZ7myEuoLG: DyGfNV3WpHzPF2CL = JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠻࠺ᜟ")
	elif AAgpHN0nMZ(u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ኱") in j5jMXZ7myEuoLG: DyGfNV3WpHzPF2CL = fR68jBGWCzUsFXdlTKPOScugm(u"࠷࠻ᜠ")
	elif bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠬࡇࡈࡘࡃࡎࠫኲ") in j5jMXZ7myEuoLG: DyGfNV3WpHzPF2CL = PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠸࠰ᜡ")
	elif jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩኳ") in j5jMXZ7myEuoLG: DyGfNV3WpHzPF2CL = xuYvdJpOEyQKTLNwb(u"࠲࠱ᜢ")
	elif jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭ኴ") in j5jMXZ7myEuoLG: DyGfNV3WpHzPF2CL = MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠴࠲ᜣ")
	elif kmdSKeBIwViM9t3(u"ࠨࡃࡎࡓࡆࡓࠧኵ") in j5jMXZ7myEuoLG: DyGfNV3WpHzPF2CL = JMLhEyaBWmskovGHTrVCxQ08(u"࠴࠸ᜤ")
	elif FhcnOB9t3frzvXb(u"ࠩࡄࡏ࡜ࡇࡍࠨ኶") in j5jMXZ7myEuoLG: DyGfNV3WpHzPF2CL = hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠶࠴ᜥ")
	elif AAgpHN0nMZ(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ኷") in j5jMXZ7myEuoLG: DyGfNV3WpHzPF2CL = EDPaWgMt1SwNn8o(u"࠶࠵ᜦ")
	elif Ej67fFyoqW8kbV2HdSK(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠭ኸ") in j5jMXZ7myEuoLG: DyGfNV3WpHzPF2CL = bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠻࠶ᜧ")
	elif eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧኹ") in j5jMXZ7myEuoLG: DyGfNV3WpHzPF2CL = m6b7CoBk4EQ(u"࠺࠰ᜨ")
	else: DyGfNV3WpHzPF2CL = eeIL1TfgFQJaKqVD8hGNPEZ(u"࠱࠶ᜩ")
	PK95MZ6Anzd3iFBlI = (b6jTGhv0gK!=None)
	gVCUjJE2lsaKo8I6hHbm0Aty7BkNR = (a7043au5scA2dQextyrVvCzGoq!=None and urEw42gLtCNeoXclaksQbAViZd39!=xuYvdJpOEyQKTLNwb(u"࠭ࡓࡕࡑࡓࠫኺ"))
	if aUgZ4whHA75BFWMPXosOdmCk: DyGfNV3WpHzPF2CL = MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠷࠲ᜪ")
	if PK95MZ6Anzd3iFBlI and not aUgZ4whHA75BFWMPXosOdmCk: NLVM3HAtxQOSvJf6kd78K1o(JMLhEyaBWmskovGHTrVCxQ08(u"ࠧหใ฼๎้ࠦศา๊ๆื๏ࠦัใ็ࠪኻ"),b6jTGhv0gK)
	elif gVCUjJE2lsaKo8I6hHbm0Aty7BkNR: NLVM3HAtxQOSvJf6kd78K1o(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨฬไ฽๏๊ࠠࡅࡐࡖࠤึ่ๅࠨኼ"),a7043au5scA2dQextyrVvCzGoq)
	if PK95MZ6Anzd3iFBlI:
		ihuOpLQngBmJo0VavM16WARIN = {MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠤ࡫ࡸࡹࡶࠢኽ"):b6jTGhv0gK,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠥ࡬ࡹࡺࡰࡴࠤኾ"):b6jTGhv0gK}
		aa2Dn8HLAYRkbdx74FhXt = b6jTGhv0gK
	else: ihuOpLQngBmJo0VavM16WARIN,aa2Dn8HLAYRkbdx74FhXt = {},c4QSTnPiWUCjhrLlwGB(u"ࠫࠬ኿")
	if gVCUjJE2lsaKo8I6hHbm0Aty7BkNR:
		import urllib3.util.connection as lgptVW8FiCo5EryJXPIHRT
		L7Q0esSKyWCzINkXVg9Of2 = Y53Y7NJ0Hq8bVU1lPv6h(lgptVW8FiCo5EryJXPIHRT,UCnYqvDtGZgPHdaiN2Of48pjL)
	HRjEblhndIkuX,MqBGmv53etuED,REQYDPrVCOimAsG,k5qNpTPgiKFMOGZ,D6MkwtlPLhEdrbVIan,verify = bw2MplmGB1NOITx,j5jMXZ7myEuoLG,nJDfuczrBG4ZeOs,hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࡊࡦࡲࡳࡦ៿"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࡊࡦࡲࡳࡦ៿"),Ehvu5RXJdc826O
	if mBQfPRTikLWc7I: D6MkwtlPLhEdrbVIan = DLSVmlyBbCK(u"࡙ࡸࡵࡦ᠀")
	if go9dDr1tMbNpG0SxjyH2 or bw2MplmGB1NOITx: HRjEblhndIkuX = kmdSKeBIwViM9t3(u"ࡌࡡ࡭ࡵࡨ᠁")
	if iiosLBOqPmgTl: REQYDPrVCOimAsG = EDPaWgMt1SwNn8o(u"ࠬࡖࡏࡔࡖࠪዀ")
	vhQayCIs07WL6iB1XSwubO,X75jhUrfuFIJW82GYmbp = -sArCMRngQNmXkBoKv(u"࠳ᜫ"),OVmSuf8tpd(u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠠࡆࡴࡵࡳࡷ࠭዁")
	for OeT2Jo0sp6h1mGdqfFw in range(LmcNhzY6fQPd2JyCGslkSr(u"࠼ᜬ")):
		yuoRfS19aGCqb8E2FjQ = MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࡔࡳࡷࡨ᠂")
		ybf3Qo7isaYVr = kRYWcNuAazr4jtmBoxFVS19Z6(u"ࡇࡣ࡯ࡷࡪ᠃")
		try:
			if OeT2Jo0sp6h1mGdqfFw: MqBGmv53etuED = eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖ࠱࠶ࡹࡴࠨዂ")
			if aUgZ4whHA75BFWMPXosOdmCk or not PK95MZ6Anzd3iFBlI: QbG0Lx7lnS6jUA9X3rzfsBYI8(wwyUWMFAsO(u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡕࠣࠤࡔࡖࡅࡏࡡࡘࡖࡑ࠭ዃ"),lQHXdV9Nzf6BLqS8D,BTMputsaqV,obS4TpHeV3digGC,MqBGmv53etuED,REQYDPrVCOimAsG)
			try: wvdJxFK9nk.close()
			except: pass
			aaIn3XlQKJ6zSfkmjuCyM = lQHXdV9Nzf6BLqS8D
			wvdJxFK9nk = EfD78uCdxyZSO.request(REQYDPrVCOimAsG,lQHXdV9Nzf6BLqS8D,data=BTMputsaqV,headers=obS4TpHeV3digGC,verify=verify,allow_redirects=HRjEblhndIkuX,timeout=DyGfNV3WpHzPF2CL,proxies=ihuOpLQngBmJo0VavM16WARIN)
			if OVmSuf8tpd(u"࠷࠵࠶ᜭ")<=wvdJxFK9nk.status_code<=pEo8g7riWVL014KaRtzQ(u"࠸࠿࠹ᜮ"):
				if not k5qNpTPgiKFMOGZ:
					qtToi3jLX7vJrgRzYCebS1Mk0c = list(wvdJxFK9nk.headers.keys())
					if ZSJVq5XDrRot(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫዄ") in qtToi3jLX7vJrgRzYCebS1Mk0c: lQHXdV9Nzf6BLqS8D = wvdJxFK9nk.headers[kmdSKeBIwViM9t3(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬዅ")]
					elif J3OCAmZVcn(u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭዆") in qtToi3jLX7vJrgRzYCebS1Mk0c: lQHXdV9Nzf6BLqS8D = wvdJxFK9nk.headers[wwyUWMFAsO(u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧ዇")]
					else: k5qNpTPgiKFMOGZ = c4QSTnPiWUCjhrLlwGB(u"ࡖࡵࡹࡪ᠄")
					if not k5qNpTPgiKFMOGZ: lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D.encode(pEo8g7riWVL014KaRtzQ(u"࠭࡬ࡢࡶ࡬ࡲ࠲࠷ࠧወ"),XogUJZEijT7KWbxeO6(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧዉ")).decode(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠨࡷࡷࡪ࠽࠭ዊ"),DLSVmlyBbCK(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩዋ"))
					if go9dDr1tMbNpG0SxjyH2 and wvdJxFK9nk.status_code==PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠹࠰࠸ᜯ"):
						HRjEblhndIkuX = bw2MplmGB1NOITx
						REQYDPrVCOimAsG = nJDfuczrBG4ZeOs
						k5qNpTPgiKFMOGZ = FhcnOB9t3frzvXb(u"ࡗࡶࡺ࡫᠅")
						ALKnRWPEYX5swo4FStx8MGI
				if not k5qNpTPgiKFMOGZ or bw2MplmGB1NOITx:
					if eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠪ࡬ࡹࡺࡰࠨዌ") not in lQHXdV9Nzf6BLqS8D:
						PP2gTKYxLzmf = d78KRnJmBWscGua0XMk(aaIn3XlQKJ6zSfkmjuCyM,EDPaWgMt1SwNn8o(u"ࠫࡺࡸ࡬ࠨው"))
						lQHXdV9Nzf6BLqS8D = PP2gTKYxLzmf+eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬ࠵ࠧዎ")+lQHXdV9Nzf6BLqS8D.lstrip(FhcnOB9t3frzvXb(u"࠭࠯ࠨዏ"))
				if not k5qNpTPgiKFMOGZ and bw2MplmGB1NOITx and not fDEdQSsq1uPoU(lQHXdV9Nzf6BLqS8D): AtEqfu7OdZkplL6igrjFoTWv
			elif pEo8g7riWVL014KaRtzQ(u"࠶࠷࠳ᜱ")<=wvdJxFK9nk.status_code<=PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠵࠺࠻ᜰ"):
				wvdJxFK9nk.reason = wvdJxFK9nk.content
				D6MkwtlPLhEdrbVIan = kRYWcNuAazr4jtmBoxFVS19Z6(u"ࡘࡷࡻࡥ᠆")
			aaIn3XlQKJ6zSfkmjuCyM = wvdJxFK9nk.url
			vhQayCIs07WL6iB1XSwubO = wvdJxFK9nk.status_code
			X75jhUrfuFIJW82GYmbp = wvdJxFK9nk.reason
			wvdJxFK9nk.raise_for_status()
			ybf3Qo7isaYVr = aVLSn1xw5cK(u"࡙ࡸࡵࡦ᠇")
		except EfD78uCdxyZSO.exceptions.HTTPError as jD36UfMuAv9TqxZeVFlm75WynYk:
			pass
		except EfD78uCdxyZSO.exceptions.Timeout as jD36UfMuAv9TqxZeVFlm75WynYk:
			if Yd6t3PjlLKk: X75jhUrfuFIJW82GYmbp = str(jD36UfMuAv9TqxZeVFlm75WynYk.message).split(gSmqZU0plur2xKPJwQA(u"ࠧ࠻ࠢࠪዐ"))[sArCMRngQNmXkBoKv(u"࠳ᜲ")]
			else: X75jhUrfuFIJW82GYmbp = str(jD36UfMuAv9TqxZeVFlm75WynYk).split(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨ࠼ࠣࠫዑ"))[pEo8g7riWVL014KaRtzQ(u"࠴ᜳ")]
		except EfD78uCdxyZSO.exceptions.ConnectionError as jD36UfMuAv9TqxZeVFlm75WynYk:
			try: KB1kx0UPF7 = jD36UfMuAv9TqxZeVFlm75WynYk.message[eeIL1TfgFQJaKqVD8hGNPEZ(u"࠴᜴")]
			except: KB1kx0UPF7 = str(jD36UfMuAv9TqxZeVFlm75WynYk)
			omkEv7OeUudAGDSVZKs = ZXFs0mEPR8qI2zj.findall(AAgpHN0nMZ(u"ࠤ࡟࡟ࡊࡸࡲ࡯ࡱࠣࠬࡡࡪࠫࠪ࡞ࡠࠤ࠭࠴ࠪࡀࠫࠪࠦዒ"),KB1kx0UPF7)
			if not omkEv7OeUudAGDSVZKs: omkEv7OeUudAGDSVZKs = ZXFs0mEPR8qI2zj.findall(DLSVmlyBbCK(u"ࠥ࠰ࠥ࡫ࡲࡳࡱࡵࡠ࠭࠮࡜ࡥ࠭ࠬ࠰ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨዓ"),KB1kx0UPF7)
			if not omkEv7OeUudAGDSVZKs:
				KDNoTxu43V = ZXFs0mEPR8qI2zj.findall(LmcNhzY6fQPd2JyCGslkSr(u"ࠦ࠿ࠦࠨ࠯ࠬࡂ࠭࠿࠴ࠪࡀࠪ࡟ࡨ࠰࠯࠺ࠣዔ"),KB1kx0UPF7)
				if KDNoTxu43V: omkEv7OeUudAGDSVZKs = [KDNoTxu43V[gnfv8UtZ3daGqpjzk(u"࠶᜶")][gSmqZU0plur2xKPJwQA(u"࠶᜵")],KDNoTxu43V[gnfv8UtZ3daGqpjzk(u"࠶᜶")][gnfv8UtZ3daGqpjzk(u"࠶᜶")]]
			if not omkEv7OeUudAGDSVZKs: omkEv7OeUudAGDSVZKs = ZXFs0mEPR8qI2zj.findall(yTMWeCgUROcvtsblfK85L62xPk(u"ࠧࡀࠨ࡝ࡦ࠮࠭࠿ࠦࠨ࠯ࠬࡂ࠭ࠬࠨዕ"),KB1kx0UPF7)
			if not omkEv7OeUudAGDSVZKs: omkEv7OeUudAGDSVZKs = ZXFs0mEPR8qI2zj.findall(m6b7CoBk4EQ(u"ࠨࠠࠩ࡞ࡧ࠯࠮ࡣࠠࠩ࠰࠭ࡃ࠮࠭ࠢዖ"),KB1kx0UPF7)
			try: vhQayCIs07WL6iB1XSwubO,X75jhUrfuFIJW82GYmbp = omkEv7OeUudAGDSVZKs[J3OCAmZVcn(u"࠰᜷")]
			except: vhQayCIs07WL6iB1XSwubO,X75jhUrfuFIJW82GYmbp = -aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠳᜸"),KB1kx0UPF7
			if not AA58pW4UfMiI9B2avFZ3YrsoeQ and (JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠧ࠮ࡏࡈࡒ࡚࠳ࠧ዗") in j5jMXZ7myEuoLG or JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠨ࠯ࡖࡉࡆࡘࡃࡉ࠯ࠪዘ") in j5jMXZ7myEuoLG):
				VZotrchyP5ez4psFq8QGjbUIYO9dE(gSmqZU0plur2xKPJwQA(u"࡚ࡲࡶࡧ᠈"))
				NLVM3HAtxQOSvJf6kd78K1o(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"้ࠩะาะฺࠠ็็๎ฮࠦสฮัํฯࠥื่ศสฺࠤฬ๊ๅ้ษๅ฽ࠬዙ"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠪ๑ࡘࡻࡣࡤࡧࡶࡷࠬዚ"),luMHeSgCBaPrb9KvUjNFqcR=JMLhEyaBWmskovGHTrVCxQ08(u"࠹࠸࠴᜹"))
				iiysxZ8dOaA(Ej67fFyoqW8kbV2HdSK(u"ࠫࡋࡵࡲࡤࡧࡧࠤࡪࡾࡩࡵࠢࡷࡳࠥࡧࡰࡱ࡮ࡼࠤࡳ࡫ࡷࠡࡹࡨࡦࡸ࡯ࡴࡦࡵࠣ࡬ࡴࡹࡴࡴࠢࡱࡥࡲ࡫ࡳࠨዛ"))
		except EfD78uCdxyZSO.exceptions.RequestException as jD36UfMuAv9TqxZeVFlm75WynYk:
			if Yd6t3PjlLKk: X75jhUrfuFIJW82GYmbp = jD36UfMuAv9TqxZeVFlm75WynYk.message
			else: X75jhUrfuFIJW82GYmbp = str(jD36UfMuAv9TqxZeVFlm75WynYk)
		except:
			yuoRfS19aGCqb8E2FjQ = fR68jBGWCzUsFXdlTKPOScugm(u"ࡆࡢ࡮ࡶࡩ᠉")
			try: vhQayCIs07WL6iB1XSwubO = wvdJxFK9nk.status_code
			except: pass
			try: X75jhUrfuFIJW82GYmbp = wvdJxFK9nk.reason
			except: pass
		X75jhUrfuFIJW82GYmbp = str(X75jhUrfuFIJW82GYmbp)
		tr24ZoudmqvxfYCw(sArCMRngQNmXkBoKv(u"ࠬࡔࡏࡕࡋࡆࡉࠬዜ"),XogUJZEijT7KWbxeO6(u"࠭࠮ࠡࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠥࠦࡒࡆࡕࡓࡓࡓ࡙ࡅࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫዝ")+str(vhQayCIs07WL6iB1XSwubO)+JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩዞ")+X75jhUrfuFIJW82GYmbp+hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪዟ")+j5jMXZ7myEuoLG+XogUJZEijT7KWbxeO6(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨዠ")+XpOsU3v5dqH8MQAK6FcafmP1z0kL2+kmdSKeBIwViM9t3(u"ࠪࠤࡢ࠭ዡ"))
		if ZLHyVwueBXMNFiPnmDU and go9dDr1tMbNpG0SxjyH2 and yuoRfS19aGCqb8E2FjQ and not D6MkwtlPLhEdrbVIan and vhQayCIs07WL6iB1XSwubO!=aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠵࠴࠵᜺"):
			lQHXdV9Nzf6BLqS8D = ebiLv0FgGr
			D6MkwtlPLhEdrbVIan = kRYWcNuAazr4jtmBoxFVS19Z6(u"ࡕࡴࡸࡩ᠊")
			continue
		if yuoRfS19aGCqb8E2FjQ: break
	if a7043au5scA2dQextyrVvCzGoq!=None and urEw42gLtCNeoXclaksQbAViZd39!=sArCMRngQNmXkBoKv(u"ࠫࡘ࡚ࡏࡑࠩዢ"): lgptVW8FiCo5EryJXPIHRT.create_connection = L7Q0esSKyWCzINkXVg9Of2
	if urEw42gLtCNeoXclaksQbAViZd39==JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬࡇࡌࡘࡃ࡜ࡗࠬዣ") and VeAMjb76TC1imXNGYthn42QWB: a7043au5scA2dQextyrVvCzGoq = None
	if not ybf3Qo7isaYVr and b6jTGhv0gK==None and j5jMXZ7myEuoLG not in ppEw9HgZkCPtvnjV4Y:
		m0AGWhywZVXFtYQ = QQV1pDhCLqHP5a3sGvoUrJfmjXFw.format_exc()
		if m0AGWhywZVXFtYQ!=OVmSuf8tpd(u"࠭ࡎࡰࡰࡨࡘࡾࡶࡥ࠻ࠢࡑࡳࡳ࡫࡜࡯ࠩዤ"): ddABnr3K9Xv8e71CzcN0Pxt.stderr.write(m0AGWhywZVXFtYQ)
	qShkDLtUac9u = o0o6fpDwEd5BMY()
	if aUgZ4whHA75BFWMPXosOdmCk: aaIn3XlQKJ6zSfkmjuCyM = kkQaWCZOFq4vzGp2wd
	qShkDLtUac9u.url = aaIn3XlQKJ6zSfkmjuCyM
	qShkDLtUac9u.scrape = aUgZ4whHA75BFWMPXosOdmCk
	try: kkXTGc8UJRfohdu = wvdJxFK9nk.content
	except: kkXTGc8UJRfohdu = pEo8g7riWVL014KaRtzQ(u"ࠧࠨዥ")
	try: mmlnqfTsuZdaMx7I3rDEYgo = wvdJxFK9nk.headers
	except: mmlnqfTsuZdaMx7I3rDEYgo = {}
	try: K5ozBn1r9pXftvPFAgDYm04kT = wvdJxFK9nk.cookies.get_dict()
	except: K5ozBn1r9pXftvPFAgDYm04kT = {}
	try: wvdJxFK9nk.close()
	except: pass
	if VYMZsxRpcQHPgkaiDKjyoh:
		try: kkXTGc8UJRfohdu = kkXTGc8UJRfohdu.decode(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨࡷࡷࡪ࠽࠭ዦ"))
		except: pass
	vhQayCIs07WL6iB1XSwubO = int(vhQayCIs07WL6iB1XSwubO)
	qShkDLtUac9u.code = vhQayCIs07WL6iB1XSwubO
	qShkDLtUac9u.reason = X75jhUrfuFIJW82GYmbp
	qShkDLtUac9u.content = kkXTGc8UJRfohdu
	qShkDLtUac9u.headers = mmlnqfTsuZdaMx7I3rDEYgo
	qShkDLtUac9u.cookies = K5ozBn1r9pXftvPFAgDYm04kT
	qShkDLtUac9u.succeeded = ybf3Qo7isaYVr
	qShkDLtUac9u.scrapernumber = MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩࠪዧ")
	qShkDLtUac9u.scraperserver = J3OCAmZVcn(u"ࠪࠫየ")
	qShkDLtUac9u.scraperurl = aVLSn1xw5cK(u"ࠫࠬዩ")
	if Yd6t3PjlLKk or isinstance(qShkDLtUac9u.content,str): fWGAJtyhP1LpDi9VQ7k = qShkDLtUac9u.content.lower()
	else: fWGAJtyhP1LpDi9VQ7k = jYaM5vilgZdFx6QHbApwVXO8et(u"ࠬ࠭ዪ")
	ssBUod0JflaI3OMm = (LmcNhzY6fQPd2JyCGslkSr(u"࠭ࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠪያ") in fWGAJtyhP1LpDi9VQ7k or J3OCAmZVcn(u"ࠧࡨࡱࡲ࡫ࡱ࡫ࠧዬ") in fWGAJtyhP1LpDi9VQ7k) and fWGAJtyhP1LpDi9VQ7k.count(m6b7CoBk4EQ(u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤࠫይ"))>yTMWeCgUROcvtsblfK85L62xPk(u"࠶᜻") and JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴ࠫዮ") not in j5jMXZ7myEuoLG and MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠳ࡴࡰ࡭ࡨࡲࠬዯ") not in fWGAJtyhP1LpDi9VQ7k and not aUgZ4whHA75BFWMPXosOdmCk
	if vhQayCIs07WL6iB1XSwubO==kRYWcNuAazr4jtmBoxFVS19Z6(u"࠷࠶࠰᜼") and ssBUod0JflaI3OMm: qShkDLtUac9u.succeeded = m6b7CoBk4EQ(u"ࡈࡤࡰࡸ࡫᠋")
	if qShkDLtUac9u.succeeded and ZLHyVwueBXMNFiPnmDU and go9dDr1tMbNpG0SxjyH2:
		if mBQfPRTikLWc7I: PM6godIBhtY9SpwUKs1 = J3OCAmZVcn(u"ࠫࡈࡇࡐࡕࡅࡋࡅࠬደ")+BTMputsaqV[sArCMRngQNmXkBoKv(u"ࠬࡰ࡯ࡣࠩዱ")].upper().replace(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠭ࡇࡆࡖࠪዲ"),sArCMRngQNmXkBoKv(u"ࠧࠨዳ"))
		fN17TMovu5aHWVgqjKI = PEdiNj9D3ZtIcy1anJwVQYfkzM8W0b(PM6godIBhtY9SpwUKs1)
	if not qShkDLtUac9u.succeeded and ZLHyVwueBXMNFiPnmDU:
		pYduixISz1FNHCwfKWanQUbTZO = (gnfv8UtZ3daGqpjzk(u"ࠨࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠬዴ") in fWGAJtyhP1LpDi9VQ7k and xuYvdJpOEyQKTLNwb(u"ࠩࡵࡥࡾࠦࡩࡥ࠼ࠣࠫድ") in fWGAJtyhP1LpDi9VQ7k)
		ww81hd7jvG3 = (gnfv8UtZ3daGqpjzk(u"ࠪ࠹ࠥࡹࡥࡤࠩዶ") in fWGAJtyhP1LpDi9VQ7k and LmcNhzY6fQPd2JyCGslkSr(u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࠬዷ") in fWGAJtyhP1LpDi9VQ7k)
		g8gASZkfBIFRLWhDedxy75 = (vhQayCIs07WL6iB1XSwubO in [JMLhEyaBWmskovGHTrVCxQ08(u"࠺࠰࠴᜽")] and jYaM5vilgZdFx6QHbApwVXO8et(u"ࠬ࡫ࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣ࠵࠵࠸࠰ࠨዸ") in fWGAJtyhP1LpDi9VQ7k)
		JqQKjbI9TcYfP7lBzCdk = (ZSJVq5XDrRot(u"࠭࡟ࡤࡨࡢࡧ࡭ࡲ࡟ࠨዹ") in fWGAJtyhP1LpDi9VQ7k and kmdSKeBIwViM9t3(u"ࠧࡤࡪࡤࡰࡱ࡫࡮ࡨࡧ࠰ࠫዺ") in fWGAJtyhP1LpDi9VQ7k)
		if   ssBUod0JflaI3OMm: X75jhUrfuFIJW82GYmbp = gSmqZU0plur2xKPJwQA(u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡸࡥࡤࡣࡳࡸࡨ࡮ࡡࠨዻ")
		elif pYduixISz1FNHCwfKWanQUbTZO: X75jhUrfuFIJW82GYmbp = kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠪዼ")
		elif ww81hd7jvG3: X75jhUrfuFIJW82GYmbp = jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠ࠶ࠢࡶࡩࡨࡵ࡮ࡥࡵࠣࡦࡷࡵࡷࡴࡧࡵࠤࡨ࡮ࡥࡤ࡭ࠪዽ")
		elif g8gASZkfBIFRLWhDedxy75: X75jhUrfuFIJW82GYmbp = fR68jBGWCzUsFXdlTKPOScugm(u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠥࡧࡣࡤࡧࡶࡷࠥࡪࡥ࡯࡫ࡨࡨࠬዾ")
		elif JqQKjbI9TcYfP7lBzCdk: X75jhUrfuFIJW82GYmbp = bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪࠦࡳࡦࡥࡸࡶ࡮ࡺࡹࠡࡥ࡫ࡩࡨࡱࠧዿ")
		else: X75jhUrfuFIJW82GYmbp = str(X75jhUrfuFIJW82GYmbp)
		if j5jMXZ7myEuoLG in CCndLYKhjyiwb: pass
		elif j5jMXZ7myEuoLG in ppEw9HgZkCPtvnjV4Y:
			tr24ZoudmqvxfYCw(Ej67fFyoqW8kbV2HdSK(u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬጀ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+sArCMRngQNmXkBoKv(u"ࠧࠡࠢࡇ࡭ࡷ࡫ࡣࡵࠢࡦࡳࡳࡴࡥࡤࡶ࡬ࡳࡳࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪጁ")+str(vhQayCIs07WL6iB1XSwubO)+bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࠢࡠࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩጂ")+X75jhUrfuFIJW82GYmbp+pEo8g7riWVL014KaRtzQ(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫጃ")+j5jMXZ7myEuoLG+OVmSuf8tpd(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩጄ")+lQHXdV9Nzf6BLqS8D+AAgpHN0nMZ(u"ࠫࠥࡣࠧጅ"))
		else: tr24ZoudmqvxfYCw(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪጆ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࠠࠡࠢࡇ࡭ࡷ࡫ࡣࡵࠢࡦࡳࡳࡴࡥࡤࡶ࡬ࡳࡳࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪጇ")+str(vhQayCIs07WL6iB1XSwubO)+ZSJVq5XDrRot(u"ࠧࠡ࡟ࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨገ")+X75jhUrfuFIJW82GYmbp+ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪጉ")+j5jMXZ7myEuoLG+DLSVmlyBbCK(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨጊ")+lQHXdV9Nzf6BLqS8D+sArCMRngQNmXkBoKv(u"ࠪࠤࡢ࠭ጋ"))
		JYgnFdE9SwrZNA7qM3zm20ByVUGtHa = kkQaWCZOFq4vzGp2wd if aUgZ4whHA75BFWMPXosOdmCk else ejBOu2WXwvb4YpITdsLF16(lQHXdV9Nzf6BLqS8D)
		if Yd6t3PjlLKk and isinstance(JYgnFdE9SwrZNA7qM3zm20ByVUGtHa,unicode): JYgnFdE9SwrZNA7qM3zm20ByVUGtHa = JYgnFdE9SwrZNA7qM3zm20ByVUGtHa.encode(m6b7CoBk4EQ(u"ࠫࡺࡺࡦ࠹ࠩጌ"))
		if go9dDr1tMbNpG0SxjyH2: JYgnFdE9SwrZNA7qM3zm20ByVUGtHa = JYgnFdE9SwrZNA7qM3zm20ByVUGtHa.split(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠬ࠵ࠧግ"))[-bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠱᜾")]
		WSTXIlVUOG2r = str(X75jhUrfuFIJW82GYmbp)+wwyUWMFAsO(u"࠭࡜࡯ࠪࠣࠫጎ")+JYgnFdE9SwrZNA7qM3zm20ByVUGtHa+fR68jBGWCzUsFXdlTKPOScugm(u"ࠧࠡࠫࠪጏ")
		if vhQayCIs07WL6iB1XSwubO in [-hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠲᜿"),-kmdSKeBIwViM9t3(u"࠴ᝀ")] or ssBUod0JflaI3OMm or pYduixISz1FNHCwfKWanQUbTZO or ww81hd7jvG3 or g8gASZkfBIFRLWhDedxy75 or JqQKjbI9TcYfP7lBzCdk:
			qShkDLtUac9u.code = -m6b7CoBk4EQ(u"࠶ᝁ")
			qShkDLtUac9u.reason = X75jhUrfuFIJW82GYmbp
			if qbG87zkKNdI0txW:
				VSFdug34LfycxCT5 = TA2hFRnNq4m8YzPvMalCwLg(nJDfuczrBG4ZeOs,lQHXdV9Nzf6BLqS8D,BTMputsaqV,obS4TpHeV3digGC,bw2MplmGB1NOITx,WaVLXft1im89uH5blkvRPEjyOex,j5jMXZ7myEuoLG,vhQayCIs07WL6iB1XSwubO,X75jhUrfuFIJW82GYmbp)
				if VSFdug34LfycxCT5.succeeded: return VSFdug34LfycxCT5
		YYkEu4IL0sTa = LmcNhzY6fQPd2JyCGslkSr(u"ࡗࡶࡺ࡫᠌")
		if (urEw42gLtCNeoXclaksQbAViZd39==bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࡃࡖࡏࠬጐ") or AwQmhUJRXj0qtbCz3BpSYl6Zkuone==eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠩࡄࡗࡐ࠭጑")) and (VeAMjb76TC1imXNGYthn42QWB or qbG87zkKNdI0txW):
			YYkEu4IL0sTa = oxPZWmC4asVXJyLB(vhQayCIs07WL6iB1XSwubO,WSTXIlVUOG2r,j5jMXZ7myEuoLG,WaVLXft1im89uH5blkvRPEjyOex)
			if YYkEu4IL0sTa and urEw42gLtCNeoXclaksQbAViZd39==gnfv8UtZ3daGqpjzk(u"ࠪࡅࡘࡑࠧጒ"): urEw42gLtCNeoXclaksQbAViZd39 = yTMWeCgUROcvtsblfK85L62xPk(u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭ጓ")
			else: urEw42gLtCNeoXclaksQbAViZd39 = JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬࡘࡅࡋࡇࡆࡘࡊࡊࠧጔ")
			if YYkEu4IL0sTa and AwQmhUJRXj0qtbCz3BpSYl6Zkuone==JMLhEyaBWmskovGHTrVCxQ08(u"࠭ࡁࡔࡍࠪጕ"): AwQmhUJRXj0qtbCz3BpSYl6Zkuone = yTMWeCgUROcvtsblfK85L62xPk(u"ࠧࡂࡅࡆࡉࡕ࡚ࡅࡅࠩ጖")
			else: AwQmhUJRXj0qtbCz3BpSYl6Zkuone = eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨࡔࡈࡎࡊࡉࡔࡆࡆࠪ጗")
			j2agIU0xsLS6c7T.setSetting(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬጘ"),urEw42gLtCNeoXclaksQbAViZd39)
			j2agIU0xsLS6c7T.setSetting(OVmSuf8tpd(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨጙ"),AwQmhUJRXj0qtbCz3BpSYl6Zkuone)
		if YYkEu4IL0sTa:
			vVPxM7FkZlJNaCTAqfQXig6D5Wb0c = JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࡘࡷࡻࡥ᠍")
			if vhQayCIs07WL6iB1XSwubO==wwyUWMFAsO(u"࠼ᝂ") and hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫ࡭ࡺࡴࡱࡵࠪጚ") in lQHXdV9Nzf6BLqS8D and vVPxM7FkZlJNaCTAqfQXig6D5Wb0c:
				if WaVLXft1im89uH5blkvRPEjyOex: NLVM3HAtxQOSvJf6kd78K1o(wwyUWMFAsO(u"ࠬะแฺ์็ࠤๆำีࠡึ๊หิฯࠠศๆอุๆ๐ัࠡࡕࡖࡐࠬጛ"),kmdSKeBIwViM9t3(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨጜ"),luMHeSgCBaPrb9KvUjNFqcR=jYaM5vilgZdFx6QHbApwVXO8et(u"࠷࠶࠰࠱ᝃ"))
				aaIn3XlQKJ6zSfkmjuCyM = lQHXdV9Nzf6BLqS8D+gSmqZU0plur2xKPJwQA(u"ࠧࡽࡾࡑࡳ࡛࡫ࡲࡪࡨࡼࡗࡘࡒࠧጝ")
				fN17TMovu5aHWVgqjKI = ggAhyPE3zSu(nJDfuczrBG4ZeOs,aaIn3XlQKJ6zSfkmjuCyM,SOlDApJEx73FokmVdYCfKuRNXy8,yJQ0WizojdcChZPM4,rCH9LTAcqthZnFOpU76bxPmWdG,WaVLXft1im89uH5blkvRPEjyOex,kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗ࠲࠸࡮ࡥࠩጞ"))
				if fN17TMovu5aHWVgqjKI.succeeded:
					qShkDLtUac9u = fN17TMovu5aHWVgqjKI
					tr24ZoudmqvxfYCw(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨጟ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+aVLSn1xw5cK(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡪࡪࡥࡥࠢࡸࡷ࡮ࡴࡧࠡࡕࡖࡐ࠿ࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬጠ")+j5jMXZ7myEuoLG+sArCMRngQNmXkBoKv(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪጡ")+XpOsU3v5dqH8MQAK6FcafmP1z0kL2+J3OCAmZVcn(u"ࠬࠦ࡝ࠨጢ"))
					if WaVLXft1im89uH5blkvRPEjyOex: NLVM3HAtxQOSvJf6kd78K1o(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭ๆอษะࠤออำหะาห๊ࠦࡓࡔࡎࠪጣ"),LmcNhzY6fQPd2JyCGslkSr(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩጤ"),luMHeSgCBaPrb9KvUjNFqcR=sArCMRngQNmXkBoKv(u"࠸࠰࠱࠲ᝄ"))
				else:
					tr24ZoudmqvxfYCw(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭ጥ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥࡻࡳࡪࡰࡪࠤࡘ࡙ࡌ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨጦ")+j5jMXZ7myEuoLG+jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩጧ")+XpOsU3v5dqH8MQAK6FcafmP1z0kL2+wwyUWMFAsO(u"ࠫࠥࡣࠧጨ"))
					if WaVLXft1im89uH5blkvRPEjyOex: NLVM3HAtxQOSvJf6kd78K1o(pEo8g7riWVL014KaRtzQ(u"ࠬ็ิๅࠢหหุะฮะษ่ࠤࡘ࡙ࡌࠨጩ"),OVmSuf8tpd(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨጪ"),luMHeSgCBaPrb9KvUjNFqcR=fR68jBGWCzUsFXdlTKPOScugm(u"࠲࠱࠲࠳ᝅ"))
			if not qShkDLtUac9u.succeeded and AwQmhUJRXj0qtbCz3BpSYl6Zkuone in [EDPaWgMt1SwNn8o(u"ࠧࡂࡗࡗࡓࠬጫ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪጬ")] and qbG87zkKNdI0txW:
				if WaVLXft1im89uH5blkvRPEjyOex: NLVM3HAtxQOSvJf6kd78K1o(JMLhEyaBWmskovGHTrVCxQ08(u"ࠩอๅ฾๐ไࠡีํีๆืวหࠢหีํ้ำ๋ࠩጭ"),J3OCAmZVcn(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬጮ"),luMHeSgCBaPrb9KvUjNFqcR=c4QSTnPiWUCjhrLlwGB(u"࠳࠲࠳࠴ᝆ"))
				fN17TMovu5aHWVgqjKI = f4drGSDOjlVCqawNQ(nJDfuczrBG4ZeOs,lQHXdV9Nzf6BLqS8D,SOlDApJEx73FokmVdYCfKuRNXy8,yJQ0WizojdcChZPM4,rCH9LTAcqthZnFOpU76bxPmWdG,WaVLXft1im89uH5blkvRPEjyOex,j5jMXZ7myEuoLG)
				if fN17TMovu5aHWVgqjKI.succeeded:
					qShkDLtUac9u = fN17TMovu5aHWVgqjKI
					tr24ZoudmqvxfYCw(aVLSn1xw5cK(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪጯ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+DLSVmlyBbCK(u"ࠬࠦࠠࠡࡒࡵࡳࡽ࡯ࡥࡴࠢࡶࡹࡨࡩࡥࡦࡦࡨࡨ࠿ࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬጰ")+j5jMXZ7myEuoLG+fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬጱ")+XpOsU3v5dqH8MQAK6FcafmP1z0kL2+J3OCAmZVcn(u"ࠧࠡ࡟ࠪጲ"))
					if WaVLXft1im89uH5blkvRPEjyOex: NLVM3HAtxQOSvJf6kd78K1o(c4QSTnPiWUCjhrLlwGB(u"ࠨ่ฯหาࠦำ๋ำไีฬะࠠษำ๋็ุ๐ࠧጳ"),Ej67fFyoqW8kbV2HdSK(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫጴ"),luMHeSgCBaPrb9KvUjNFqcR=c4QSTnPiWUCjhrLlwGB(u"࠴࠳࠴࠵ᝇ"))
				else:
					tr24ZoudmqvxfYCw(EDPaWgMt1SwNn8o(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨጵ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+gnfv8UtZ3daGqpjzk(u"ࠫࠥࠦࠠࡑࡴࡲࡼ࡮࡫ࡳࠡࡨࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨጶ")+j5jMXZ7myEuoLG+FhcnOB9t3frzvXb(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫጷ")+XpOsU3v5dqH8MQAK6FcafmP1z0kL2+pEo8g7riWVL014KaRtzQ(u"࠭ࠠ࡞ࠩጸ"))
					if WaVLXft1im89uH5blkvRPEjyOex: NLVM3HAtxQOSvJf6kd78K1o(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧโึ็ࠤุ๐ัโำสฮࠥฮั้ๅึ๎ࠬጹ"),DLSVmlyBbCK(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪጺ"),luMHeSgCBaPrb9KvUjNFqcR=Ej67fFyoqW8kbV2HdSK(u"࠵࠴࠵࠶ᝈ"))
			if not qShkDLtUac9u.succeeded and urEw42gLtCNeoXclaksQbAViZd39 in [ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠩࡄ࡙࡙ࡕࠧጻ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬጼ")] and VeAMjb76TC1imXNGYthn42QWB:
				if WaVLXft1im89uH5blkvRPEjyOex: NLVM3HAtxQOSvJf6kd78K1o(gnfv8UtZ3daGqpjzk(u"ࠫฯ็ู๋ๆࠣื๏ืแาࠢࡇࡒࡘ࠭ጽ"),m6b7CoBk4EQ(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧጾ"),luMHeSgCBaPrb9KvUjNFqcR=Ej67fFyoqW8kbV2HdSK(u"࠶࠵࠶࠰ᝉ"))
				aaIn3XlQKJ6zSfkmjuCyM = lQHXdV9Nzf6BLqS8D+gSmqZU0plur2xKPJwQA(u"࠭ࡼࡽࡏࡼࡈࡓ࡙ࡕࡳ࡮ࡀࠫጿ")
				fN17TMovu5aHWVgqjKI = ggAhyPE3zSu(nJDfuczrBG4ZeOs,aaIn3XlQKJ6zSfkmjuCyM,SOlDApJEx73FokmVdYCfKuRNXy8,yJQ0WizojdcChZPM4,rCH9LTAcqthZnFOpU76bxPmWdG,WaVLXft1im89uH5blkvRPEjyOex,DLSVmlyBbCK(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖ࠱࠹ࡺࡨࠨፀ"))
				if fN17TMovu5aHWVgqjKI.succeeded:
					qShkDLtUac9u = fN17TMovu5aHWVgqjKI
					tr24ZoudmqvxfYCw(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧፁ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+m6b7CoBk4EQ(u"ࠩࠣࠤࠥࡊࡎࡔࠢࡶࡹࡨࡩࡥࡦࡦࡨࡨ࠿ࠦࠠࠡࡆࡑࡗ࠿࡛ࠦࠡࠩፂ")+UCnYqvDtGZgPHdaiN2Of48pjL+c4QSTnPiWUCjhrLlwGB(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬፃ")+j5jMXZ7myEuoLG+XogUJZEijT7KWbxeO6(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪፄ")+XpOsU3v5dqH8MQAK6FcafmP1z0kL2+J3OCAmZVcn(u"ࠬࠦ࡝ࠨፅ"))
					if WaVLXft1im89uH5blkvRPEjyOex: NLVM3HAtxQOSvJf6kd78K1o(m6b7CoBk4EQ(u"࠭ๆอษะࠤุ๐ัโำࠣࡈࡓ࡙ࠧፆ"),wwyUWMFAsO(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩፇ"),luMHeSgCBaPrb9KvUjNFqcR=DLSVmlyBbCK(u"࠷࠶࠰࠱ᝊ"))
				else:
					tr24ZoudmqvxfYCw(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭ፈ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+EDPaWgMt1SwNn8o(u"ࠩࠣࠤࠥࡊࡎࡔࠢࡩࡥ࡮ࡲࡥࡥ࠼ࠣࠤࠥࡊࡎࡔ࠼ࠣ࡟ࠥ࠭ፉ")+UCnYqvDtGZgPHdaiN2Of48pjL+JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬፊ")+j5jMXZ7myEuoLG+OVmSuf8tpd(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪፋ")+XpOsU3v5dqH8MQAK6FcafmP1z0kL2+kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠬࠦ࡝ࠨፌ"))
					if WaVLXft1im89uH5blkvRPEjyOex: NLVM3HAtxQOSvJf6kd78K1o(Ej67fFyoqW8kbV2HdSK(u"࠭แีๆࠣื๏ืแาࠢࡇࡒࡘ࠭ፍ"),FhcnOB9t3frzvXb(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩፎ"),luMHeSgCBaPrb9KvUjNFqcR=JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠸࠰࠱࠲ᝋ"))
		if AwQmhUJRXj0qtbCz3BpSYl6Zkuone==hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠨࡔࡈࡎࡊࡉࡔࡆࡆࠪፏ") or urEw42gLtCNeoXclaksQbAViZd39==JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫፐ"): WaVLXft1im89uH5blkvRPEjyOex = AAgpHN0nMZ(u"ࡋࡧ࡬ࡴࡧ᠎")
		if not qShkDLtUac9u.succeeded:
			if WaVLXft1im89uH5blkvRPEjyOex: yh04Y1UbKaoD3Lqe6rZTm = oxPZWmC4asVXJyLB(vhQayCIs07WL6iB1XSwubO,WSTXIlVUOG2r,j5jMXZ7myEuoLG,WaVLXft1im89uH5blkvRPEjyOex)
			if vhQayCIs07WL6iB1XSwubO!=pEo8g7riWVL014KaRtzQ(u"࠲࠱࠲ᝌ") and j5jMXZ7myEuoLG not in vw4ahqzAlgOVTnNe29SXWUJZ8pf and FhcnOB9t3frzvXb(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࠧፑ") not in j5jMXZ7myEuoLG:
				iiysxZ8dOaA(ZSJVq5XDrRot(u"ࠫࡋࡵࡲࡤࡧࡧࠤࡪࡾࡩࡵࠢࡧࡹࡪࠦࡴࡰࠢࡱࡩࡹࡽ࡯ࡳ࡭ࠣ࡭ࡸࡹࡵࡦࡵࠣࡻ࡮ࡺࡨ࠻ࠢࠪፒ")+j5jMXZ7myEuoLG)
	if j2agIU0xsLS6c7T.getSetting(c4QSTnPiWUCjhrLlwGB(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨፓ")) not in [yTMWeCgUROcvtsblfK85L62xPk(u"࠭ࡁࡖࡖࡒࠫፔ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠧࡔࡖࡒࡔࠬፕ"),DLSVmlyBbCK(u"ࠨࡃࡖࡏࠬፖ")]: j2agIU0xsLS6c7T.setSetting(pEo8g7riWVL014KaRtzQ(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬፗ"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠪࡅࡘࡑࠧፘ"))
	if j2agIU0xsLS6c7T.getSetting(OVmSuf8tpd(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩፙ")) not in [ZSJVq5XDrRot(u"ࠬࡇࡕࡕࡑࠪፚ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭ࡓࡕࡑࡓࠫ፛"),ZSJVq5XDrRot(u"ࠧࡂࡕࡎࠫ፜")]: j2agIU0xsLS6c7T.setSetting(DLSVmlyBbCK(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭፝"),pEo8g7riWVL014KaRtzQ(u"ࠩࡄࡗࡐ࠭፞"))
	return qShkDLtUac9u
def TA2hFRnNq4m8YzPvMalCwLg(nJDfuczrBG4ZeOs,lQHXdV9Nzf6BLqS8D,BTMputsaqV,obS4TpHeV3digGC,bw2MplmGB1NOITx,WaVLXft1im89uH5blkvRPEjyOex,j5jMXZ7myEuoLG,vhQayCIs07WL6iB1XSwubO,X75jhUrfuFIJW82GYmbp):
	NLVM3HAtxQOSvJf6kd78K1o(ZSJVq5XDrRot(u"ࠪฬิษสࠡ฻่่๏ฯࠠหฮส์ืࠦวๅฯฯฬࠬ፟"),XogUJZEijT7KWbxeO6(u"ࠫࠬ፠"),luMHeSgCBaPrb9KvUjNFqcR=gnfv8UtZ3daGqpjzk(u"࠸࠷࠳ᝍ"))
	tr24ZoudmqvxfYCw(gSmqZU0plur2xKPJwQA(u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ፡"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+ZSJVq5XDrRot(u"࠭ࠠࠡࠢࠣࡘࡷࡿࡩ࡯ࡩࠣࡦࡾࡶࡡࡴࡵ࡬ࡲ࡬ࠦࡢ࡭ࡱࡦ࡯࡮ࡴࡧࠡࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬ።")+str(vhQayCIs07WL6iB1XSwubO)+bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࠡ࡟ࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨ፣")+X75jhUrfuFIJW82GYmbp+EDPaWgMt1SwNn8o(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ፤")+j5jMXZ7myEuoLG+ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ፥")+lQHXdV9Nzf6BLqS8D+OVmSuf8tpd(u"ࠪࠤࡢ࠭፦"))
	vGu8jXylokfOsHV = j2agIU0xsLS6c7T.getSetting(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠫࡦࡼ࠮ࡧࡣ࡬ࡰࡪࡪ࠮ࡴࡥࡤࡶࡵ࡫ࡰࡳࡱࡻࡽ࠶࠭፧"))
	TryYKJAGi9Q = j2agIU0xsLS6c7T.getSetting(c4QSTnPiWUCjhrLlwGB(u"ࠬࡧࡶ࠯ࡨࡤ࡭ࡱ࡫ࡤ࠯ࡵࡦࡥࡷࡶࡥࡱࡴࡲࡼࡾ࠸ࠧ፨"))
	pX5WixRnNTbJZrFLsUhu47g = j2agIU0xsLS6c7T.getSetting(gnfv8UtZ3daGqpjzk(u"࠭ࡡࡷ࠰ࡩࡥ࡮ࡲࡥࡥ࠰ࡶࡧࡦࡸࡰࡦࡲࡵࡳࡽࡿ࠳ࠨ፩"))
	KmkyX6SxVDnHjI5cwd1 = j2agIU0xsLS6c7T.getSetting(Ej67fFyoqW8kbV2HdSK(u"ࠧࡢࡸ࠱ࡪࡦ࡯࡬ࡦࡦ࠱ࡷࡨࡧࡲࡱࡧࡳࡶࡴࡾࡹ࠵ࠩ፪"))
	vGu8jXylokfOsHV = yTMWeCgUROcvtsblfK85L62xPk(u"࠲ᝎ") if not vGu8jXylokfOsHV else int(vGu8jXylokfOsHV)
	TryYKJAGi9Q = gSmqZU0plur2xKPJwQA(u"࠳ᝏ") if not TryYKJAGi9Q else int(TryYKJAGi9Q)
	pX5WixRnNTbJZrFLsUhu47g = AAgpHN0nMZ(u"࠴ᝐ") if not pX5WixRnNTbJZrFLsUhu47g else int(pX5WixRnNTbJZrFLsUhu47g)
	KmkyX6SxVDnHjI5cwd1 = EDPaWgMt1SwNn8o(u"࠵ᝑ") if not KmkyX6SxVDnHjI5cwd1 else int(KmkyX6SxVDnHjI5cwd1)
	af5IwdsMoE = vGu8jXylokfOsHV>eeIL1TfgFQJaKqVD8hGNPEZ(u"࠹ᝒ") and TryYKJAGi9Q>eeIL1TfgFQJaKqVD8hGNPEZ(u"࠹ᝒ") and pX5WixRnNTbJZrFLsUhu47g>eeIL1TfgFQJaKqVD8hGNPEZ(u"࠹ᝒ") and KmkyX6SxVDnHjI5cwd1>eeIL1TfgFQJaKqVD8hGNPEZ(u"࠹ᝒ")
	if af5IwdsMoE:
		j2agIU0xsLS6c7T.setSetting(XogUJZEijT7KWbxeO6(u"ࠨࡣࡹ࠲࡫ࡧࡩ࡭ࡧࡧ࠲ࡸࡩࡡࡳࡲࡨࡴࡷࡵࡸࡺ࠳ࠪ፫"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩࠪ፬"))
		j2agIU0xsLS6c7T.setSetting(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠪࡥࡻ࠴ࡦࡢ࡫࡯ࡩࡩ࠴ࡳࡤࡣࡵࡴࡪࡶࡲࡰࡺࡼ࠶ࠬ፭"),EDPaWgMt1SwNn8o(u"ࠫࠬ፮"))
		j2agIU0xsLS6c7T.setSetting(JMLhEyaBWmskovGHTrVCxQ08(u"ࠬࡧࡶ࠯ࡨࡤ࡭ࡱ࡫ࡤ࠯ࡵࡦࡥࡷࡶࡥࡱࡴࡲࡼࡾ࠹ࠧ፯"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࠧ፰"))
		j2agIU0xsLS6c7T.setSetting(Ej67fFyoqW8kbV2HdSK(u"ࠧࡢࡸ࠱ࡪࡦ࡯࡬ࡦࡦ࠱ࡷࡨࡧࡲࡱࡧࡳࡶࡴࡾࡹ࠵ࠩ፱"),EDPaWgMt1SwNn8o(u"ࠨࠩ፲"))
	JfEBHirNSyswl1FKA6mP7 = []
	if af5IwdsMoE or vGu8jXylokfOsHV<=kRYWcNuAazr4jtmBoxFVS19Z6(u"࠴᝔"): JfEBHirNSyswl1FKA6mP7 += [MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠱ᝓ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠱ᝓ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠱ᝓ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠱ᝓ")]
	if af5IwdsMoE or TryYKJAGi9Q<=jYaM5vilgZdFx6QHbApwVXO8et(u"࠵᝕"): JfEBHirNSyswl1FKA6mP7 += [AAgpHN0nMZ(u"࠵᝖"),AAgpHN0nMZ(u"࠵᝖")]
	if af5IwdsMoE or pX5WixRnNTbJZrFLsUhu47g<=hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠷᝗"): JfEBHirNSyswl1FKA6mP7 += [hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠷᝗")]
	if not obS4TpHeV3digGC and (af5IwdsMoE or KmkyX6SxVDnHjI5cwd1<=fR68jBGWCzUsFXdlTKPOScugm(u"࠸᝘")): JfEBHirNSyswl1FKA6mP7 += [AAgpHN0nMZ(u"࠺᝙"),AAgpHN0nMZ(u"࠺᝙"),AAgpHN0nMZ(u"࠺᝙"),AAgpHN0nMZ(u"࠺᝙"),AAgpHN0nMZ(u"࠺᝙"),AAgpHN0nMZ(u"࠺᝙"),AAgpHN0nMZ(u"࠺᝙"),AAgpHN0nMZ(u"࠺᝙")]
	if   OVmSuf8tpd(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ፳") in j5jMXZ7myEuoLG: Rhu1gX0tJC4zUiyxo5O6da7 = kRYWcNuAazr4jtmBoxFVS19Z6(u"࠴᝚")
	elif DLSVmlyBbCK(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ፴") in j5jMXZ7myEuoLG: Rhu1gX0tJC4zUiyxo5O6da7 = bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠳᝛")
	else:
		Rhu1gX0tJC4zUiyxo5O6da7 = bnPo1W52UVMRs7Lw6kfG9QdO.sample(JfEBHirNSyswl1FKA6mP7,fR68jBGWCzUsFXdlTKPOScugm(u"࠳᝜"))[LmcNhzY6fQPd2JyCGslkSr(u"࠳᝝")]
	if Rhu1gX0tJC4zUiyxo5O6da7==ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠵᝞"):
		scraperserver = ZSJVq5XDrRot(u"ࠫࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡧ࡮ࡵࠩ፵")
		GxNq1ktHbA0clOjsTrCgd2vnZSPJy = MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡡ࡯ࡶࠩࡴࡷࡵࡸࡺࡡࡦࡳࡺࡴࡴࡳࡻࡀࡅࡊࠬࡢࡳࡱࡺࡷࡪࡸ࠽ࡧࡣ࡯ࡷࡪࠬࡦࡰࡴࡺࡥࡷࡪ࡟ࡩࡧࡤࡨࡪࡸࡳ࠾ࡶࡵࡹࡪࡀ࠲ࡣ࠵࠷࠴ࡦ࠼࠸࠺࠲ࡤ࠹࠹࠶࠱ࡥࡤࡦ࠷࠼࠸ࡣ࠲࠳࠷࠹ࡩ࠿࠶࠳ࡧ࠻ࡄࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡦࡴࡴ࠯ࡥࡲࡱ࠿࠾࠰࠹࠲ࠪ፶")
		pqrfNVvo8H = lQHXdV9Nzf6BLqS8D+gnfv8UtZ3daGqpjzk(u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭፷")+GxNq1ktHbA0clOjsTrCgd2vnZSPJy+XogUJZEijT7KWbxeO6(u"ࠧࡽࡾࡑࡳ࡛࡫ࡲࡪࡨࡼࡗࡘࡒࠧ፸")
		VSFdug34LfycxCT5 = ggAhyPE3zSu(nJDfuczrBG4ZeOs,pqrfNVvo8H,BTMputsaqV,obS4TpHeV3digGC,bw2MplmGB1NOITx,WaVLXft1im89uH5blkvRPEjyOex,j5jMXZ7myEuoLG,JMLhEyaBWmskovGHTrVCxQ08(u"ࡌࡡ࡭ࡵࡨ᠏"),JMLhEyaBWmskovGHTrVCxQ08(u"ࡌࡡ࡭ࡵࡨ᠏"))
		hhZ7xrNTnzm509ilPC = sArCMRngQNmXkBoKv(u"ࠨࠩ፹") if VSFdug34LfycxCT5.succeeded else str(vGu8jXylokfOsHV+sArCMRngQNmXkBoKv(u"࠶᝟"))
		j2agIU0xsLS6c7T.setSetting(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࡤࡺ࠳࡬ࡡࡪ࡮ࡨࡨ࠳ࡹࡣࡢࡴࡳࡩࡵࡸ࡯ࡹࡻ࠴ࠫ፺"),hhZ7xrNTnzm509ilPC)
	elif Rhu1gX0tJC4zUiyxo5O6da7==yTMWeCgUROcvtsblfK85L62xPk(u"࠸ᝠ"):
		scraperserver = gnfv8UtZ3daGqpjzk(u"ࠪࡷࡨࡸࡡࡱࡧࡲࡴࡸ࠭፻")
		GxNq1ktHbA0clOjsTrCgd2vnZSPJy = xuYvdJpOEyQKTLNwb(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠮࡬ࡧࡨࡴࡤ࡮ࡥࡢࡦࡨࡶࡸࡃࡴࡳࡷࡨ࠾ࡧ࠸ࡣ࠳ࡨࡦ࠹࠾࠳࠸ࡧࡦ࠳࠱࠹ࡩ࠲ࡥ࠯࠼࠵࠻ࡩ࠭ࡣࡥ࠺࠷࠼࠿࠸࠱ࡥࡨ࠶ࡦࡆࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠯࡫ࡲ࠾࠺࠹࠵࠴ࠩ፼")
		pqrfNVvo8H = lQHXdV9Nzf6BLqS8D+c4QSTnPiWUCjhrLlwGB(u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬ፽")+GxNq1ktHbA0clOjsTrCgd2vnZSPJy+Ej67fFyoqW8kbV2HdSK(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭፾")
		VSFdug34LfycxCT5 = ggAhyPE3zSu(nJDfuczrBG4ZeOs,pqrfNVvo8H,BTMputsaqV,obS4TpHeV3digGC,bw2MplmGB1NOITx,WaVLXft1im89uH5blkvRPEjyOex,j5jMXZ7myEuoLG,J3OCAmZVcn(u"ࡆࡢ࡮ࡶࡩ᠐"),J3OCAmZVcn(u"ࡆࡢ࡮ࡶࡩ᠐"))
		hhZ7xrNTnzm509ilPC = ZSJVq5XDrRot(u"ࠧࠨ፿") if VSFdug34LfycxCT5.succeeded else str(TryYKJAGi9Q+jYaM5vilgZdFx6QHbApwVXO8et(u"࠱ᝡ"))
		j2agIU0xsLS6c7T.setSetting(fR68jBGWCzUsFXdlTKPOScugm(u"ࠨࡣࡹ࠲࡫ࡧࡩ࡭ࡧࡧ࠲ࡸࡩࡡࡳࡲࡨࡴࡷࡵࡸࡺ࠴ࠪᎀ"),hhZ7xrNTnzm509ilPC)
	elif Rhu1gX0tJC4zUiyxo5O6da7==OVmSuf8tpd(u"࠴ᝢ"):
		scraperserver = J3OCAmZVcn(u"ࠩࡶࡧࡷࡧࡰࡦࡴࡤࡴ࡮࠭ᎁ")
		GxNq1ktHbA0clOjsTrCgd2vnZSPJy = kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡨࡸࡡࡱࡧࡵࡥࡵ࡯࠮࡬ࡧࡨࡴࡤ࡮ࡥࡢࡦࡨࡶࡸࡃࡴࡳࡷࡨ࠾࠼࠼ࡢ࠵ࡨࡦ࠷࠹࡬ࡣࡥ࠳࠼ࡨ࠾ࡩ࠵࠶ࡣ࠴࠹࡫࠹࠶࠱࠶ࡦࡨ࠾࠷࠴ࡤࡂࡳࡶࡴࡾࡹ࠮ࡵࡨࡶࡻ࡫ࡲ࠯ࡵࡦࡶࡦࡶࡥࡳࡣࡳ࡭࠳ࡩ࡯࡮࠼࠻࠴࠵࠷ࠧᎂ")
		pqrfNVvo8H = lQHXdV9Nzf6BLqS8D+ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫᎃ")+GxNq1ktHbA0clOjsTrCgd2vnZSPJy+eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬᎄ")
		VSFdug34LfycxCT5 = ggAhyPE3zSu(nJDfuczrBG4ZeOs,pqrfNVvo8H,BTMputsaqV,obS4TpHeV3digGC,bw2MplmGB1NOITx,WaVLXft1im89uH5blkvRPEjyOex,j5jMXZ7myEuoLG,bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࡇࡣ࡯ࡷࡪ᠑"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࡇࡣ࡯ࡷࡪ᠑"))
		hhZ7xrNTnzm509ilPC = LmcNhzY6fQPd2JyCGslkSr(u"࠭ࠧᎅ") if VSFdug34LfycxCT5.succeeded else str(pX5WixRnNTbJZrFLsUhu47g+ZSJVq5XDrRot(u"࠳ᝣ"))
		j2agIU0xsLS6c7T.setSetting(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧࡢࡸ࠱ࡪࡦ࡯࡬ࡦࡦ࠱ࡷࡨࡧࡲࡱࡧࡳࡶࡴࡾࡹ࠴ࠩᎆ"),hhZ7xrNTnzm509ilPC)
	elif Rhu1gX0tJC4zUiyxo5O6da7==c4QSTnPiWUCjhrLlwGB(u"࠷ᝤ"):
		scraperserver = XogUJZEijT7KWbxeO6(u"ࠨࡵࡦࡶࡦࡶࡥࡶࡲࠪᎇ")
		aaIn3XlQKJ6zSfkmjuCyM = lQHXdV9Nzf6BLqS8D.replace(OVmSuf8tpd(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫᎈ"),pEo8g7riWVL014KaRtzQ(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫᎉ"))
		pqrfNVvo8H = ZSJVq5XDrRot(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡶࡩ࠯ࡵࡦࡶࡦࡶࡥࡶࡲ࠱ࡧࡴࡳ࠯ࡀࡣࡳ࡭ࡤࡱࡥࡺ࠿࠴࡚ࡓࡹࡍࡵࡎ࠴ࡳࡇࡘࡘ࡬ࡕࡑࡇࡧࡉࡍࡋ࠳ࡎ࡜࡞ࡐࡪ࡫࠲ࡧ࡮࡟ࡽࠦ࡬ࡧࡨࡴࡤ࡮ࡥࡢࡦࡨࡶࡸࡃࡦࡢ࡮ࡶࡩࠫࡻࡲ࡭࠿ࠪᎊ")+aaIn3XlQKJ6zSfkmjuCyM
		VSFdug34LfycxCT5 = ggAhyPE3zSu(J3OCAmZVcn(u"ࠬࡍࡅࡕࠩᎋ"),pqrfNVvo8H,BTMputsaqV,obS4TpHeV3digGC,bw2MplmGB1NOITx,WaVLXft1im89uH5blkvRPEjyOex,j5jMXZ7myEuoLG,hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࡈࡤࡰࡸ࡫᠒"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࡈࡤࡰࡸ࡫᠒"))
		hhZ7xrNTnzm509ilPC = c4QSTnPiWUCjhrLlwGB(u"࠭ࠧᎌ") if VSFdug34LfycxCT5.succeeded else str(KmkyX6SxVDnHjI5cwd1+gnfv8UtZ3daGqpjzk(u"࠵ᝥ"))
		j2agIU0xsLS6c7T.setSetting(Ej67fFyoqW8kbV2HdSK(u"ࠧࡢࡸ࠱ࡪࡦ࡯࡬ࡦࡦ࠱ࡷࡨࡧࡲࡱࡧࡳࡶࡴࡾࡹ࠵ࠩᎍ"),hhZ7xrNTnzm509ilPC)
	elif Rhu1gX0tJC4zUiyxo5O6da7==gnfv8UtZ3daGqpjzk(u"࠹࠺ᝦ"):
		scraperserver = jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨࡵࡦࡶࡦࡶࡥ࠯ࡦࡲ࠵ࠬᎎ")
		GxNq1ktHbA0clOjsTrCgd2vnZSPJy = JMLhEyaBWmskovGHTrVCxQ08(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡦࡧ࠷࠼࠳ࡢࡤ࠴ࡩ࠺࠶࠴࠵ࡦ࠵ࡧࡦ࠻ࡤ࠶ࡦ࠶ࡪ࠾࡫࠳ࡤ࠵࠻࠺ࡪࡩࡡ࠲࠳࠳࠼࠸࠾࠹ࡢ࠹࠶࠾ࡨࡻࡳࡵࡱࡰࡌࡪࡧࡤࡦࡴࡶࡁࡹࡸࡵࡦࡂࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥ࠯ࡦࡲ࠾࠽࠶࠸࠱ࠩᎏ")
		pqrfNVvo8H = lQHXdV9Nzf6BLqS8D+OVmSuf8tpd(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪ᎐")+GxNq1ktHbA0clOjsTrCgd2vnZSPJy+gSmqZU0plur2xKPJwQA(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫ᎑")
		VSFdug34LfycxCT5 = ggAhyPE3zSu(nJDfuczrBG4ZeOs,pqrfNVvo8H,BTMputsaqV,obS4TpHeV3digGC,bw2MplmGB1NOITx,WaVLXft1im89uH5blkvRPEjyOex,j5jMXZ7myEuoLG,wwyUWMFAsO(u"ࡉࡥࡱࡹࡥ᠓"),wwyUWMFAsO(u"ࡉࡥࡱࡹࡥ᠓"))
		if aFQoGfmYKyqLU6X8libw9k3ncW5(u"࡙ࠬࡣࡳࡣࡳࡩ࠳ࡪ࡯࠮ࡔࡨࡱࡦ࡯࡮ࡪࡰࡪ࠱ࡈࡸࡥࡥ࡫ࡷࡷࠬ᎒") in list(VSFdug34LfycxCT5.headers.keys()):
			ZZOdHGYfRgIFwCtcu6JTlPMz0 = VSFdug34LfycxCT5.headers[eeIL1TfgFQJaKqVD8hGNPEZ(u"࠭ࡓࡤࡴࡤࡴࡪ࠴ࡤࡰ࠯ࡕࡩࡲࡧࡩ࡯࡫ࡱ࡫࠲ࡉࡲࡦࡦ࡬ࡸࡸ࠭᎓")]
			j2agIU0xsLS6c7T.setSetting(gnfv8UtZ3daGqpjzk(u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡦࡦࡲ࠸࠹࠭᎔"),ZZOdHGYfRgIFwCtcu6JTlPMz0)
	elif Rhu1gX0tJC4zUiyxo5O6da7==ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠻࠵ᝧ"):
		scraperserver = J3OCAmZVcn(u"ࠨࡵࡦࡶࡦࡶࡥ࠯ࡦࡲ࠶ࠬ᎕")
		GxNq1ktHbA0clOjsTrCgd2vnZSPJy = XogUJZEijT7KWbxeO6(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴ࡧ࠸ࡪ࠳ࡢࡧ࠴࠼࠺ࡪࡦ࠵ࡤࡩ࠺ࡦ࡬࠵࠴࠵ࡦ࠻࠵࠺࠰ࡣ࠵࠷࠻ࡨ࠿ࡥ࠺࠻ࡥࡩ࠹࠼࠶ࡢࡧ࠼࠾ࡨࡻࡳࡵࡱࡰࡌࡪࡧࡤࡦࡴࡶࡁࡹࡸࡵࡦࡂࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥ࠯ࡦࡲ࠾࠽࠶࠸࠱ࠩ᎖")
		pqrfNVvo8H = lQHXdV9Nzf6BLqS8D+PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪ᎗")+GxNq1ktHbA0clOjsTrCgd2vnZSPJy+wwyUWMFAsO(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫ᎘")
		VSFdug34LfycxCT5 = ggAhyPE3zSu(nJDfuczrBG4ZeOs,pqrfNVvo8H,BTMputsaqV,obS4TpHeV3digGC,bw2MplmGB1NOITx,WaVLXft1im89uH5blkvRPEjyOex,j5jMXZ7myEuoLG,gnfv8UtZ3daGqpjzk(u"ࡊࡦࡲࡳࡦ᠔"),gnfv8UtZ3daGqpjzk(u"ࡊࡦࡲࡳࡦ᠔"))
		if m6b7CoBk4EQ(u"࡙ࠬࡣࡳࡣࡳࡩ࠳ࡪ࡯࠮ࡔࡨࡱࡦ࡯࡮ࡪࡰࡪ࠱ࡈࡸࡥࡥ࡫ࡷࡷࠬ᎙") in list(VSFdug34LfycxCT5.headers.keys()):
			ZZOdHGYfRgIFwCtcu6JTlPMz0 = VSFdug34LfycxCT5.headers[gSmqZU0plur2xKPJwQA(u"࠭ࡓࡤࡴࡤࡴࡪ࠴ࡤࡰ࠯ࡕࡩࡲࡧࡩ࡯࡫ࡱ࡫࠲ࡉࡲࡦࡦ࡬ࡸࡸ࠭᎚")]
			j2agIU0xsLS6c7T.setSetting(AAgpHN0nMZ(u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡦࡦࡲ࠹࠺࠭᎛"),ZZOdHGYfRgIFwCtcu6JTlPMz0)
	elif Rhu1gX0tJC4zUiyxo5O6da7==LmcNhzY6fQPd2JyCGslkSr(u"࠹࠺࠻࠶ᝨ"):
		scraperserver = ZSJVq5XDrRot(u"ࠨࡵࡦࡶࡦࡶࡩ࡯ࡩࡵࡳࡧࡵࡴࠨ᎜")
		pqrfNVvo8H = c4QSTnPiWUCjhrLlwGB(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡴ࡮࠴ࡳࡤࡴࡤࡴ࡮ࡴࡧࡳࡱࡥࡳࡹ࠴ࡣࡰ࡯࠲ࡃࡹࡵ࡫ࡦࡰࡀࡥ࠹࡬࠷ࡧࡤ࠴࠸࠲࠸ࡤࡦࡨ࠰࠸࠵࠽࠱࠮࠺࠹࠸ࡧ࠳࠲࠳ࡧ࠶࠶࠻࠺ࡤ࠵ࡦࡧࡧࠫࡶࡲࡰࡺࡼࡇࡴࡻ࡮ࡵࡴࡼࡁࡏࡕࠦࡶࡴ࡯ࡁࠬ᎝")+cD1AgYCl0qZI8(lQHXdV9Nzf6BLqS8D)
		VSFdug34LfycxCT5 = ggAhyPE3zSu(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠪࡋࡊ࡚ࠧ᎞"),pqrfNVvo8H,BTMputsaqV,obS4TpHeV3digGC,bw2MplmGB1NOITx,WaVLXft1im89uH5blkvRPEjyOex,j5jMXZ7myEuoLG,XogUJZEijT7KWbxeO6(u"ࡋࡧ࡬ࡴࡧ᠕"),XogUJZEijT7KWbxeO6(u"ࡋࡧ࡬ࡴࡧ᠕"))
		try:
			import json as VmSKvRtTw5WBYDI
			VSFdug34LfycxCT5.content = VmSKvRtTw5WBYDI.dumps(VSFdug34LfycxCT5.content)[xuYvdJpOEyQKTLNwb(u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫ᎟")]
		except: pass
	elif Rhu1gX0tJC4zUiyxo5O6da7==xuYvdJpOEyQKTLNwb(u"࠺࠻࠼࠵ᝩ"):
		scraperserver = FhcnOB9t3frzvXb(u"ࠬࡹࡣࡳࡣࡳࡩࡴࡶࡳࠨᎠ")
		pqrfNVvo8H = hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴࡪࡵࡰࡴ࠰࡬ࡳ࠴ࡼ࠱࠰ࡁࡤࡴ࡮ࡥ࡫ࡦࡻࡀࡦ࠷ࡩ࠲ࡧࡥ࠸࠽࠲࠾ࡦࡥ࠲࠰࠸ࡨ࠸ࡤ࠮࠻࠴࠺ࡨ࠳ࡢࡤ࠹࠶࠻࠾࠾࠰ࡤࡧ࠵ࡥࠫࡻࡲ࡭࠿ࠪᎡ")+lQHXdV9Nzf6BLqS8D
		VSFdug34LfycxCT5 = ggAhyPE3zSu(OVmSuf8tpd(u"ࠧࡈࡇࡗࠫᎢ"),pqrfNVvo8H,BTMputsaqV,obS4TpHeV3digGC,bw2MplmGB1NOITx,WaVLXft1im89uH5blkvRPEjyOex,j5jMXZ7myEuoLG,Ej67fFyoqW8kbV2HdSK(u"ࡌࡡ࡭ࡵࡨ᠖"),Ej67fFyoqW8kbV2HdSK(u"ࡌࡡ࡭ࡵࡨ᠖"))
	else:
		scraperserver,pqrfNVvo8H = Ej67fFyoqW8kbV2HdSK(u"ࠨࠩᎣ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠩࠪᎤ")
		VSFdug34LfycxCT5 = o0o6fpDwEd5BMY()
	VSFdug34LfycxCT5.scrapernumber = str(Rhu1gX0tJC4zUiyxo5O6da7)
	VSFdug34LfycxCT5.scraperserver = scraperserver
	VSFdug34LfycxCT5.scraperurl = pqrfNVvo8H
	cmlGbgQOHrx57zYNIw1j = kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪื๏ืแาࠢิๆ๊ࠦࠧᎥ")+VSFdug34LfycxCT5.scrapernumber
	if VSFdug34LfycxCT5.succeeded:
		tr24ZoudmqvxfYCw(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪᎦ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+aVLSn1xw5cK(u"ࠬࠦࠠࠡࠢࡖࡹࡨࡩࡥࡦࡦࡨࡨࠥࡨࡹࡱࡣࡶࡷ࡮ࡴࡧࠡࡤ࡯ࡳࡨࡱࡩ࡯ࡩࠣࠤ࡙ࠥࡥࡳࡸࡨࡶ࠿࡛ࠦࠡࠩᎧ")+scraperserver+c4QSTnPiWUCjhrLlwGB(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨᎨ")+j5jMXZ7myEuoLG+pEo8g7riWVL014KaRtzQ(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭Ꭹ")+lQHXdV9Nzf6BLqS8D+LmcNhzY6fQPd2JyCGslkSr(u"ࠨࠢࡠࠫᎪ"))
		NLVM3HAtxQOSvJf6kd78K1o(LmcNhzY6fQPd2JyCGslkSr(u"้ࠩะาะฺࠠ็็๎ฮࠦสอษ๋ึࠥอไฮฮหࠫᎫ"),cmlGbgQOHrx57zYNIw1j,luMHeSgCBaPrb9KvUjNFqcR=m6b7CoBk4EQ(u"࠹࠸࠴ᝪ"))
	else:
		tr24ZoudmqvxfYCw(pEo8g7riWVL014KaRtzQ(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩᎬ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+xuYvdJpOEyQKTLNwb(u"ࠫࠥࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡤࡼࡴࡦࡹࡳࡪࡰࡪࠤࡧࡲ࡯ࡤ࡭࡬ࡲ࡬ࠦࠠࠡࡕࡨࡶࡻ࡫ࡲ࠻ࠢ࡞ࠤࠬᎭ")+scraperserver+OVmSuf8tpd(u"ࠬࠦ࡝ࠡࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬᎮ")+str(VSFdug34LfycxCT5.code)+jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࠠ࡞ࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧᎯ")+VSFdug34LfycxCT5.reason+aVLSn1xw5cK(u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩᎰ")+j5jMXZ7myEuoLG+Ej67fFyoqW8kbV2HdSK(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᎱ")+lQHXdV9Nzf6BLqS8D+yTMWeCgUROcvtsblfK85L62xPk(u"ࠩࠣࡡࠬᎲ"))
		NLVM3HAtxQOSvJf6kd78K1o(gnfv8UtZ3daGqpjzk(u"ࠪๅู๊สࠡ฻่่๏ฯࠠหฮส์ืࠦวๅฯฯฬࠬᎳ"),cmlGbgQOHrx57zYNIw1j,luMHeSgCBaPrb9KvUjNFqcR=JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠺࠹࠵ᝫ"))
	return VSFdug34LfycxCT5
def A6F71g3cqN4(VkZ3taqEOKhCI6N,nJDfuczrBG4ZeOs,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,SOlDApJEx73FokmVdYCfKuRNXy8,yJQ0WizojdcChZPM4,rCH9LTAcqthZnFOpU76bxPmWdG,showDialogs,j5jMXZ7myEuoLG,PPwsGxBAMTvE56tL9ohCl=XogUJZEijT7KWbxeO6(u"ࠫࠬᎴ"),P8P01rposdK5Vk=wwyUWMFAsO(u"ࠬ࠭Ꮅ")):
	lQHXdV9Nzf6BLqS8D,b6jTGhv0gK,a7043au5scA2dQextyrVvCzGoq,Ehvu5RXJdc826O = glE1Zx2einabXPjKV3DvMu(XpOsU3v5dqH8MQAK6FcafmP1z0kL2)
	try: RPrpQulXTSmAHKa = yJQ0WizojdcChZPM4.copy()
	except: RPrpQulXTSmAHKa = yJQ0WizojdcChZPM4
	fdmbuvJpzy = nJDfuczrBG4ZeOs,lQHXdV9Nzf6BLqS8D,SOlDApJEx73FokmVdYCfKuRNXy8,RPrpQulXTSmAHKa,rCH9LTAcqthZnFOpU76bxPmWdG
	if VkZ3taqEOKhCI6N:
		wvdJxFK9nk = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,JMLhEyaBWmskovGHTrVCxQ08(u"࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨᎶ"),OVmSuf8tpd(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠪᎷ"),fdmbuvJpzy)
		if wvdJxFK9nk.succeeded:
			QbG0Lx7lnS6jUA9X3rzfsBYI8(AAgpHN0nMZ(u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡕࠣࠤࡗࡋࡁࡅࡡࡆࡅࡈࡎࡅࠨᎸ"),lQHXdV9Nzf6BLqS8D,SOlDApJEx73FokmVdYCfKuRNXy8,yJQ0WizojdcChZPM4,j5jMXZ7myEuoLG,nJDfuczrBG4ZeOs)
			return wvdJxFK9nk
	wvdJxFK9nk = ggAhyPE3zSu(nJDfuczrBG4ZeOs,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,SOlDApJEx73FokmVdYCfKuRNXy8,yJQ0WizojdcChZPM4,rCH9LTAcqthZnFOpU76bxPmWdG,showDialogs,j5jMXZ7myEuoLG,PPwsGxBAMTvE56tL9ohCl,P8P01rposdK5Vk)
	if wvdJxFK9nk.succeeded:
		if bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪᎹ") in j5jMXZ7myEuoLG: wvdJxFK9nk.content = Aq4xzQOb5ISuiC9JWnPtavj0gXlh(wvdJxFK9nk.content)
		if wvdJxFK9nk.scrape: VkZ3taqEOKhCI6N = JNsoWV1CXc4xy
		if VkZ3taqEOKhCI6N: Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠭Ꮊ"),fdmbuvJpzy,wvdJxFK9nk,VkZ3taqEOKhCI6N)
	return wvdJxFK9nk
def QuWA3hsmIvockZDiy2rLg(VkZ3taqEOKhCI6N,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,SOlDApJEx73FokmVdYCfKuRNXy8,yJQ0WizojdcChZPM4,showDialogs,j5jMXZ7myEuoLG):
	if not SOlDApJEx73FokmVdYCfKuRNXy8 or isinstance(SOlDApJEx73FokmVdYCfKuRNXy8,dict): nJDfuczrBG4ZeOs = eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫࡌࡋࡔࠨᎻ")
	else:
		nJDfuczrBG4ZeOs = xuYvdJpOEyQKTLNwb(u"ࠬࡖࡏࡔࡖࠪᎼ")
		SOlDApJEx73FokmVdYCfKuRNXy8 = ejBOu2WXwvb4YpITdsLF16(SOlDApJEx73FokmVdYCfKuRNXy8)
		lyJGUQz5KvtL,SOlDApJEx73FokmVdYCfKuRNXy8 = hGMVvHBuPC014(SOlDApJEx73FokmVdYCfKuRNXy8)
	wvdJxFK9nk = A6F71g3cqN4(VkZ3taqEOKhCI6N,nJDfuczrBG4ZeOs,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,SOlDApJEx73FokmVdYCfKuRNXy8,yJQ0WizojdcChZPM4,J3OCAmZVcn(u"ࡔࡳࡷࡨ᠗"),showDialogs,j5jMXZ7myEuoLG)
	vdCNK2GykrWZIVeg7z5S4HFh = wvdJxFK9nk.content
	vdCNK2GykrWZIVeg7z5S4HFh = str(vdCNK2GykrWZIVeg7z5S4HFh)
	return vdCNK2GykrWZIVeg7z5S4HFh
def glE1Zx2einabXPjKV3DvMu(XpOsU3v5dqH8MQAK6FcafmP1z0kL2):
	XgFKIj482w63RA9UdWoinHzpVD0q = XpOsU3v5dqH8MQAK6FcafmP1z0kL2.split(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭ࡼࡽࠩᎽ"))
	lQHXdV9Nzf6BLqS8D,b6jTGhv0gK,a7043au5scA2dQextyrVvCzGoq,Ehvu5RXJdc826O = XgFKIj482w63RA9UdWoinHzpVD0q[wwyUWMFAsO(u"࠴ᝬ")],None,None,aVLSn1xw5cK(u"ࡕࡴࡸࡩ᠘")
	for fdmbuvJpzy in XgFKIj482w63RA9UdWoinHzpVD0q:
		if yTMWeCgUROcvtsblfK85L62xPk(u"ࠧࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬᎾ") in fdmbuvJpzy: b6jTGhv0gK = fdmbuvJpzy[AAgpHN0nMZ(u"࠶࠷᝭"):]
		elif ZSJVq5XDrRot(u"ࠨࡏࡼࡈࡓ࡙ࡕࡳ࡮ࡀࠫᎿ") in fdmbuvJpzy: a7043au5scA2dQextyrVvCzGoq = fdmbuvJpzy[FhcnOB9t3frzvXb(u"࠿ᝮ"):]
		elif MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩࡑࡳ࡛࡫ࡲࡪࡨࡼࡗࡘࡒࠧᏀ") in fdmbuvJpzy: Ehvu5RXJdc826O = xuYvdJpOEyQKTLNwb(u"ࡈࡤࡰࡸ࡫᠙")
	return lQHXdV9Nzf6BLqS8D,b6jTGhv0gK,a7043au5scA2dQextyrVvCzGoq,Ehvu5RXJdc826O
def UUNdIkbzF3lKquAsr4Q9TJnHM8tYOf(VkZ3taqEOKhCI6N,nJDfuczrBG4ZeOs,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,VVE6d2QnRN,OiVFLNYMe2DoksnK0,Lx68FXfOi4ozMN0vruE,yJQ0WizojdcChZPM4=hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠪࠫᏁ")):
	dkPM9xRLrDa = d78KRnJmBWscGua0XMk(XpOsU3v5dqH8MQAK6FcafmP1z0kL2,fR68jBGWCzUsFXdlTKPOScugm(u"ࠫࡺࡸ࡬ࠨᏂ"))
	JTAZ6uOVaXPrRFzLifMgw3tlGxE = j2agIU0xsLS6c7T.getSetting(FhcnOB9t3frzvXb(u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࠧᏃ")+VVE6d2QnRN)
	if dkPM9xRLrDa==JTAZ6uOVaXPrRFzLifMgw3tlGxE: j2agIU0xsLS6c7T.setSetting(DLSVmlyBbCK(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨᏄ")+VVE6d2QnRN,fR68jBGWCzUsFXdlTKPOScugm(u"ࠧࠨᏅ"))
	if JTAZ6uOVaXPrRFzLifMgw3tlGxE: aaIn3XlQKJ6zSfkmjuCyM = XpOsU3v5dqH8MQAK6FcafmP1z0kL2.replace(dkPM9xRLrDa,JTAZ6uOVaXPrRFzLifMgw3tlGxE)
	else:
		aaIn3XlQKJ6zSfkmjuCyM = XpOsU3v5dqH8MQAK6FcafmP1z0kL2
		JTAZ6uOVaXPrRFzLifMgw3tlGxE = dkPM9xRLrDa
	fN17TMovu5aHWVgqjKI = A6F71g3cqN4(VkZ3taqEOKhCI6N,nJDfuczrBG4ZeOs,aaIn3XlQKJ6zSfkmjuCyM,gnfv8UtZ3daGqpjzk(u"ࠨࠩᏆ"),yJQ0WizojdcChZPM4,gnfv8UtZ3daGqpjzk(u"ࠩࠪᏇ"),XogUJZEijT7KWbxeO6(u"ࠪࠫᏈ"),J3OCAmZVcn(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤࡔࡅࡘࡡࡋࡓࡘ࡚ࡎࡂࡏࡈ࠱࠶ࡹࡴࠨᏉ"))
	vdCNK2GykrWZIVeg7z5S4HFh = fN17TMovu5aHWVgqjKI.content
	if VYMZsxRpcQHPgkaiDKjyoh:
		try: vdCNK2GykrWZIVeg7z5S4HFh = vdCNK2GykrWZIVeg7z5S4HFh.decode(ZSJVq5XDrRot(u"ࠬࡻࡴࡧ࠺ࠪᏊ"),m6b7CoBk4EQ(u"࠭ࡩࡨࡰࡲࡶࡪ࠭Ꮛ"))
		except: pass
	if not fN17TMovu5aHWVgqjKI.succeeded or Lx68FXfOi4ozMN0vruE not in vdCNK2GykrWZIVeg7z5S4HFh:
		OiVFLNYMe2DoksnK0 = OiVFLNYMe2DoksnK0.replace(yTMWeCgUROcvtsblfK85L62xPk(u"ࠧࠡࠩᏌ"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠨ࠭ࠪᏍ"))
		lQHXdV9Nzf6BLqS8D = AAgpHN0nMZ(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡨࡱࡲ࡫ࡱ࡫࠮ࡤࡱࡰ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡶࡃࠧᏎ")+OiVFLNYMe2DoksnK0
		obS4TpHeV3digGC = {Ej67fFyoqW8kbV2HdSK(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᏏ"):sArCMRngQNmXkBoKv(u"ࠫࠬᏐ")}
		qShkDLtUac9u = A6F71g3cqN4(VkZ3taqEOKhCI6N,nJDfuczrBG4ZeOs,lQHXdV9Nzf6BLqS8D,XogUJZEijT7KWbxeO6(u"ࠬ࠭Ꮡ"),obS4TpHeV3digGC,aVLSn1xw5cK(u"࠭ࠧᏒ"),gSmqZU0plur2xKPJwQA(u"ࠧࠨᏓ"),J3OCAmZVcn(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠴ࡱࡨࠬᏔ"))
		if qShkDLtUac9u.succeeded:
			vdCNK2GykrWZIVeg7z5S4HFh = qShkDLtUac9u.content
			if VYMZsxRpcQHPgkaiDKjyoh:
				try: vdCNK2GykrWZIVeg7z5S4HFh = vdCNK2GykrWZIVeg7z5S4HFh.decode(gSmqZU0plur2xKPJwQA(u"ࠩࡸࡸ࡫࠾ࠧᏕ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪᏖ"))
				except: pass
			R28S4pFmAojEW7CGnx = ZXFs0mEPR8qI2zj.findall(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨ࠯࡝ࡹ࠭ࡠࡄ࠴ࠪࡀࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࠬᏗ"),vdCNK2GykrWZIVeg7z5S4HFh,ZXFs0mEPR8qI2zj.DOTALL)
			Xbe1cuDIH7w0mU3g = [JTAZ6uOVaXPrRFzLifMgw3tlGxE]
			Upr2RevHsw0hmfjDa6 = [LmcNhzY6fQPd2JyCGslkSr(u"ࠬࡧࡰ࡬ࠩᏘ"),xuYvdJpOEyQKTLNwb(u"࠭ࡧࡰࡱࡪࡰࡪ࠭Ꮩ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧࡵࡹ࡬ࡸࡹ࡫ࡲࠨᏚ"),Ej67fFyoqW8kbV2HdSK(u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩᏛ"),aVLSn1xw5cK(u"ࠩࡩࡥࡨ࡫ࡢࡰࡱ࡮ࠫᏜ"),Ej67fFyoqW8kbV2HdSK(u"ࠪࡴ࡭ࡶࠧᏝ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠫࡦࡺ࡬ࡢࡳࠪᏞ"),OVmSuf8tpd(u"ࠬࡹࡩࡵࡧ࡬ࡲࡩ࡯ࡣࡦࡵࠪᏟ"),EDPaWgMt1SwNn8o(u"࠭ࡳࡶࡴ࠱ࡰࡾ࠭Ꮰ"),aVLSn1xw5cK(u"ࠧࡣ࡮ࡲ࡫ࡸࡶ࡯ࡵࠩᏡ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠨ࡫ࡱࡪࡴࡸ࡭ࡦࡴࠪᏢ"),xuYvdJpOEyQKTLNwb(u"ࠩࡶ࡭ࡹ࡫࡬ࡪ࡭ࡨࠫᏣ"),wwyUWMFAsO(u"ࠪ࡭ࡳࡹࡴࡢࡩࡵࡥࡲ࠭Ꮴ"),OVmSuf8tpd(u"ࠫࡸࡴࡡࡱࡥ࡫ࡥࡹ࠭Ꮵ"),wwyUWMFAsO(u"ࠬ࡮ࡴࡵࡲ࠰ࡩࡶࡻࡩࡷࠩᏦ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠭ࡦࡢࡵࡨࡰࡵࡲࡵࡴࠩᏧ")]
			for Y5Q8P0S7i6bnyGzHgE2jBDkp9 in R28S4pFmAojEW7CGnx:
				if any(AARNPWHjQU9dEmDI in Y5Q8P0S7i6bnyGzHgE2jBDkp9 for AARNPWHjQU9dEmDI in Upr2RevHsw0hmfjDa6): continue
				JTAZ6uOVaXPrRFzLifMgw3tlGxE = d78KRnJmBWscGua0XMk(Y5Q8P0S7i6bnyGzHgE2jBDkp9,aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧࡶࡴ࡯ࠫᏨ"))
				if JTAZ6uOVaXPrRFzLifMgw3tlGxE in Xbe1cuDIH7w0mU3g: continue
				if len(Xbe1cuDIH7w0mU3g)==hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠹ᝯ"):
					tr24ZoudmqvxfYCw(ZSJVq5XDrRot(u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭Ꮹ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+c4QSTnPiWUCjhrLlwGB(u"ࠩࠣࠤࠥࡍ࡯ࡰࡩ࡯ࡩࠥࡪࡩࡥࠢࡱࡳࡹࠦࡦࡪࡰࡧࠤࡦࠦ࡮ࡦࡹࠣ࡬ࡴࡹࡴ࡯ࡣࡰࡩࠥࠦࠠࡔ࡫ࡷࡩ࠿࡛ࠦࠡࠩᏪ")+VVE6d2QnRN+fR68jBGWCzUsFXdlTKPOScugm(u"ࠪࠤࡢࠦࠠࡐ࡮ࡧ࠾ࠥࡡࠠࠨᏫ")+dkPM9xRLrDa+J3OCAmZVcn(u"ࠫࠥࡣࠧᏬ"))
					j2agIU0xsLS6c7T.setSetting(JMLhEyaBWmskovGHTrVCxQ08(u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࠧᏭ")+VVE6d2QnRN,MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠭ࠧᏮ"))
					break
				Xbe1cuDIH7w0mU3g.append(JTAZ6uOVaXPrRFzLifMgw3tlGxE)
				aaIn3XlQKJ6zSfkmjuCyM = XpOsU3v5dqH8MQAK6FcafmP1z0kL2.replace(dkPM9xRLrDa,JTAZ6uOVaXPrRFzLifMgw3tlGxE)
				fN17TMovu5aHWVgqjKI = A6F71g3cqN4(VkZ3taqEOKhCI6N,nJDfuczrBG4ZeOs,aaIn3XlQKJ6zSfkmjuCyM,aVLSn1xw5cK(u"ࠧࠨᏯ"),yJQ0WizojdcChZPM4,yTMWeCgUROcvtsblfK85L62xPk(u"ࠨࠩᏰ"),ZSJVq5XDrRot(u"ࠩࠪᏱ"),gSmqZU0plur2xKPJwQA(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠷ࡷࡪࠧᏲ"))
				vdCNK2GykrWZIVeg7z5S4HFh = fN17TMovu5aHWVgqjKI.content
				if fN17TMovu5aHWVgqjKI.succeeded and Lx68FXfOi4ozMN0vruE in vdCNK2GykrWZIVeg7z5S4HFh:
					tr24ZoudmqvxfYCw(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪᏳ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠬࠦࠠࠡࡉࡲࡳ࡬ࡲࡥࠡࡨࡲࡹࡳࡪࠠࡢࠢࡱࡩࡼࠦࡨࡰࡵࡷࡲࡦࡳࡥࠡࠢࠣࡗ࡮ࡺࡥ࠻ࠢ࡞ࠤࠬᏴ")+VVE6d2QnRN+ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭ࠠ࡞ࠢࠣࠤࡓ࡫ࡷ࠻ࠢ࡞ࠤࠬᏵ")+JTAZ6uOVaXPrRFzLifMgw3tlGxE+bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࠡ࡟ࠣࠤࡔࡲࡤ࠻ࠢ࡞ࠤࠬ᏶")+dkPM9xRLrDa+LmcNhzY6fQPd2JyCGslkSr(u"ࠨࠢࡠࠫ᏷"))
					j2agIU0xsLS6c7T.setSetting(gSmqZU0plur2xKPJwQA(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫᏸ")+VVE6d2QnRN,JTAZ6uOVaXPrRFzLifMgw3tlGxE)
					break
	return JTAZ6uOVaXPrRFzLifMgw3tlGxE,aaIn3XlQKJ6zSfkmjuCyM,fN17TMovu5aHWVgqjKI
def Po4CyOusDaWq6pbIjYV(unjzvHfWpPTbqACy9RtOY6m):
	ARYupe4MbZJVPWhIFy7jDBo = {
	 fR68jBGWCzUsFXdlTKPOScugm(u"ࠪࡳࡱࡪࠧᏹ")			:AAgpHN0nMZ(u"ࠫ็ี๊ๆࠩᏺ")
	,JMLhEyaBWmskovGHTrVCxQ08(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧᏻ")		:LmcNhzY6fQPd2JyCGslkSr(u"࠭ๅห๊ๅๅࠬᏼ")
	,JMLhEyaBWmskovGHTrVCxQ08(u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨᏽ")		:EDPaWgMt1SwNn8o(u"ࠨ็ไๆํีࠧ᏾")
	,FhcnOB9t3frzvXb(u"ࠩࡪࡳࡴࡪࠧ᏿")			:pEo8g7riWVL014KaRtzQ(u"ࠪะ๏ีࠧ᐀")
	,xuYvdJpOEyQKTLNwb(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫᐁ")		:yTMWeCgUROcvtsblfK85L62xPk(u"ࠬ็ิๅࠩᐂ")
	,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᐃ")		:J3OCAmZVcn(u"ࠧๆฮ็ำࠬᐄ")
	,c4QSTnPiWUCjhrLlwGB(u"ࠨࡸ࡬ࡨࡪࡵࠧᐅ")		:AAgpHN0nMZ(u"ࠩไ๎ิ๐่ࠨᐆ")
	,kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪࡰ࡮ࡼࡥࠨᐇ")			:MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠫ็์วสࠩᐈ")
	,jYaM5vilgZdFx6QHbApwVXO8et(u"ࠬࡧ࡫ࡰࡣࡰࠫᐉ")		:JMLhEyaBWmskovGHTrVCxQ08(u"࠭ๅ้ไ฼ࠤศ้่ศ็ࠣห้่ฯ๋็ࠪᐊ")
	,J3OCAmZVcn(u"ࠧࡢ࡭ࡺࡥࡲ࠭ᐋ")		:aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨ็๋ๆ฾ࠦรไ๊ส้ࠥอไอัํำࠬᐌ")
	,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࡤ࡯ࡴࡧ࡭ࡤࡣࡰࠫᐍ")		:AAgpHN0nMZ(u"้ࠪํู่ࠡลๆ์ฬ๋ࠠไษ่ࠫᐎ")
	,yTMWeCgUROcvtsblfK85L62xPk(u"ࠫࡦࡲࡡࡳࡣࡥࠫᐏ")		:aFQoGfmYKyqLU6X8libw9k3ncW5(u"๋่ࠬใ฻ࠣ็้ࠦวๅ฻ิฬࠬᐐ")
	,fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࡡ࡭ࡨࡤࡸ࡮ࡳࡩࠨᐑ")		:J3OCAmZVcn(u"ࠧๆ๊ๅ฽ࠥอไๆ่หีࠥอไโษฺ้๏࠭ᐒ")
	,ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨࡣ࡯࡯ࡦࡽࡴࡩࡣࡵࠫᐓ")	:JMLhEyaBWmskovGHTrVCxQ08(u"่ࠩ์็฿ࠠใ่สอࠥอไไ๊ฮีࠬᐔ")
	,m6b7CoBk4EQ(u"ࠪࡥࡱࡳࡡࡢࡴࡨࡪࠬᐕ")		:wwyUWMFAsO(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠศๆ่฽ฬืแࠨᐖ")
	,XogUJZEijT7KWbxeO6(u"ࠬࡧࡲࡣ࡮࡬ࡳࡳࢀࠧᐗ")		:AAgpHN0nMZ(u"࠭ๅ้ไ฼ࠤ฾ืศࠡๆํ์ุ๋ࠧᐘ")
	,J3OCAmZVcn(u"ࠧࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠫᐙ")	:PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢࡹ࡭ࡵ࠭ᐚ")
	,kmdSKeBIwViM9t3(u"ࠩࡨࡰࡨ࡯࡮ࡦ࡯ࡤࠫᐛ")		:eeIL1TfgFQJaKqVD8hGNPEZ(u"้ࠪํู่ࠡษ็ื๏์ๅศࠩᐜ")
	,aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠫ࡭࡫࡬ࡢ࡮ࠪᐝ")		:PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"๋่ࠬใ฻๋้ࠣอไࠡ์๋ฮ๏๎ศࠨᐞ")
	,ZSJVq5XDrRot(u"࠭ࡣࡪ࡯ࡤࡪࡦࡴࡳࠨᐟ")		:ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣๅฬ์าࠨᐠ")
	,gSmqZU0plur2xKPJwQA(u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪᐡ")		:ZSJVq5XDrRot(u"่ࠩ์็฿ࠠีษ๊ำࠥ็่า์๋ࠫᐢ")
	,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼࠬᐣ")		:yTMWeCgUROcvtsblfK85L62xPk(u"๊ࠫ๎โฺࠢื์ๆࠦๅศๅึࠫᐤ")
	,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬࡧࡲࡢࡤࡶࡩࡪࡪࠧᐥ")		:Ej67fFyoqW8kbV2HdSK(u"࠭ๅ้ไ฼ࠤ฾ืศࠡีํ๎ิ࠭ᐦ")
	,gSmqZU0plur2xKPJwQA(u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨᐧ")		:sArCMRngQNmXkBoKv(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ๋อ่ࠨᐨ")
	,AAgpHN0nMZ(u"ࠩ࡮ࡥࡷࡨࡡ࡭ࡣࡷࡺࠬᐩ")	:aVLSn1xw5cK(u"้ࠪํู่ࠡไ้หฮࠦใาส็หฦ࠭ᐪ")
	,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫࡾࡺࡢࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪᐫ")	:EDPaWgMt1SwNn8o(u"๋่ࠬศไ฼ࠤ๏๎ส๋๊หࠫᐬ")
	,Ej67fFyoqW8kbV2HdSK(u"࠭࡭ࡺࡥ࡬ࡱࡦ࠭ᐭ")		:gnfv8UtZ3daGqpjzk(u"ࠧๆ๊ๅ฽๋ࠥว๋ࠢึ๎๊อࠧᐮ")
	,JMLhEyaBWmskovGHTrVCxQ08(u"ࠨࡹࡨࡧ࡮ࡳࡡࠨᐯ")		:ffCSGrTJYPsxgVQWKLtHU3iMwB(u"่ࠩ์็฿้ࠠ์ࠣื๏๋วࠨᐰ")
	,pEo8g7riWVL014KaRtzQ(u"ࠪࡪࡦࡹࡥ࡭ࡪࡧ࠵ࠬᐱ")		:bdhQDyjm3nPwToFHkprvCzBLUGR(u"๊ࠫ๎โฺࠢไหฺ๊ࠠศๆฦ์้࠭ᐲ")
	,ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠸ࠧᐳ")		:wwyUWMFAsO(u"࠭ๅ้ไ฼ࠤๆอีๅࠢส่ะอๆ๋ࠩᐴ")
	,AAgpHN0nMZ(u"ࠧࡣࡱ࡮ࡶࡦ࠭ᐵ")		:XogUJZEijT7KWbxeO6(u"ࠨ็๋ๆ฾ࠦศไำสࠫᐶ")
	,aVLSn1xw5cK(u"ࠩࡦ࡭ࡲࡧࡡࡣࡦࡲࠫᐷ")		:xuYvdJpOEyQKTLNwb(u"้ࠪํู่ࠡีํ้ฬูࠦษั๋ࠫᐸ")
	,wwyUWMFAsO(u"ࠫࡱ࡯ࡶࡦࡶࡹࠫᐹ")		:aFQoGfmYKyqLU6X8libw9k3ncW5(u"๋ࠬไโࠩᐺ")
	,gnfv8UtZ3daGqpjzk(u"࠭࡬ࡪࡤࡵࡥࡷࡿࠧᐻ")		:aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧๆๆไࠫᐼ")
	,aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨ࡯ࡲࡺࡸ࠺ࡵࠨᐽ")		:aVLSn1xw5cK(u"่ࠩ์็฿ࠠๆ๊ไึࠥ็่า์๋ࠫᐾ")
	,fR68jBGWCzUsFXdlTKPOScugm(u"ࠪࡪࡦࡰࡥࡳࡵ࡫ࡳࡼ࠭ᐿ")	:aFQoGfmYKyqLU6X8libw9k3ncW5(u"๊ࠫ๎โฺࠢไะึࠦิ้ࠩᑀ")
	,m6b7CoBk4EQ(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠭ᑁ")		:FhcnOB9t3frzvXb(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠧᑂ")
	,Ej67fFyoqW8kbV2HdSK(u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠲ࠩᑃ")		:XogUJZEijT7KWbxeO6(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠴ࠫᑄ")
	,aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠵ࠫᑅ")		:hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠷࠭ᑆ")
	,XogUJZEijT7KWbxeO6(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠸࠭ᑇ")		:pEo8g7riWVL014KaRtzQ(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠳ࠨᑈ")
	,jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠴ࠨᑉ")		:m6b7CoBk4EQ(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠶ࠪᑊ")
	,gnfv8UtZ3daGqpjzk(u"ࠨࡥ࡬ࡱࡦ࠺ࡵࠨᑋ")		:hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"่ࠩ์็฿ࠠิ์่หࠥ็่า์๋ࠫᑌ")
	,c4QSTnPiWUCjhrLlwGB(u"ࠪࡩ࡬ࡿ࡮ࡰࡹࠪᑍ")		:kmdSKeBIwViM9t3(u"๊ࠫ๎โฺࠢศ๎ั๐ࠠ็ษ๋ࠫᑎ")
	,xuYvdJpOEyQKTLNwb(u"ࠬ࡫ࡧࡺࡦࡨࡥࡩ࠭ᑏ")		:wwyUWMFAsO(u"࠭ๅ้ไ฼ࠤส๐ฬ๋ࠢา๎ิ࠭ᑐ")
	,Ej67fFyoqW8kbV2HdSK(u"ࠧࡩࡣ࡯ࡥࡨ࡯࡭ࡢࠩᑑ")		:eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨ็๋ๆ฾ࠦ็ๅษࠣื๏๋วࠨᑒ")
	,eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠩ࡯ࡳࡩࡿ࡮ࡦࡶࠪᑓ")		:JMLhEyaBWmskovGHTrVCxQ08(u"้ࠪํู่ࠡๆ๋ำ๏ࠦๆหࠩᑔ")
	,AAgpHN0nMZ(u"ࠫࡹࡼࡦࡶࡰࠪᑕ")		:sArCMRngQNmXkBoKv(u"๋่ࠬใ฻ࠣฮ๏็๊ࠡใส๊ࠬᑖ")
	,XogUJZEijT7KWbxeO6(u"࠭ࡣࡪ࡯ࡤࡰ࡮࡭ࡨࡵࠩᑗ")	:jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧๆ๊ๅ฽ู๊ࠥๆษ่ࠣฬ๐สࠨᑘ")
	,LmcNhzY6fQPd2JyCGslkSr(u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࡯ࡧࡺࡷࠬᑙ")	:pEo8g7riWVL014KaRtzQ(u"่ࠩ์็฿ࠠีษ๊ำࠥ์๊้ิࠪᑚ")
	,OVmSuf8tpd(u"ࠪࡪࡴࡹࡴࡢࠩᑛ")		:c4QSTnPiWUCjhrLlwGB(u"๊ࠫ๎โฺࠢไ์ุะวࠨᑜ")
	,AAgpHN0nMZ(u"ࠬࡧࡨࡸࡣ࡮ࠫᑝ")		:eeIL1TfgFQJaKqVD8hGNPEZ(u"࠭ๅ้ไ฼ࠤศํ่ศๅࠣฮ๏็๊ࠨᑞ")
	,pEo8g7riWVL014KaRtzQ(u"ࠧࡧࡣࡥࡶࡦࡱࡡࠨᑟ")		:Ej67fFyoqW8kbV2HdSK(u"ࠨ็๋ๆ฾ࠦแษำๆอࠬᑠ")
	,Ej67fFyoqW8kbV2HdSK(u"ࠩࡦ࡭ࡲࡧࡣ࡭ࡷࡥࡻࡴࡸ࡫ࠨᑡ")	:EDPaWgMt1SwNn8o(u"้ࠪํู่ࠡีํ้ฬࠦใๅ๊หࠤ฾๋ไࠨᑢ")
	,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫࡨ࡯࡭ࡢࡥ࡯ࡹࡧ࠭ᑣ")		:sArCMRngQNmXkBoKv(u"๋่ࠬใ฻ࠣื๏๋วࠡๅ็์อ࠭ᑤ")
	,aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠭ࡳࡩࡱࡩ࡬ࡦ࠭ᑥ")		:aVLSn1xw5cK(u"ࠧๆ๊ๅ฽ฺ่ࠥโ้สࠤฯ๐แ๋ࠩᑦ")
	,c4QSTnPiWUCjhrLlwGB(u"ࠨࡤࡵࡷࡹ࡫ࡪࠨᑧ")		:m6b7CoBk4EQ(u"่ࠩ์็฿ࠠษำึฮ๏าࠧᑨ")
	,bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪࡧ࡮ࡳࡡ࠵࠲࠳ࠫᑩ")		:LmcNhzY6fQPd2JyCGslkSr(u"๊ࠫ๎โฺࠢึ๎๊อࠠ࠵࠲࠳ࠫᑪ")
	,gSmqZU0plur2xKPJwQA(u"ࠬࡲࡡࡳࡱࡽࡥࠬᑫ")		:JMLhEyaBWmskovGHTrVCxQ08(u"࠭ๅ้ไ฼ࠤ้อั้ิสࠫᑬ")
	,aVLSn1xw5cK(u"ࠧࡺࡣࡴࡳࡹ࠭ᑭ")		:JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠨ็๋ๆ฾๊ࠦศไ๋ฮࠬᑮ")
	,gnfv8UtZ3daGqpjzk(u"ࠩ࡮ࡥࡹࡱ࡯ࡶࡶࡨࠫᑯ")		:wwyUWMFAsO(u"้ࠪํู่ࠡๅอ็ํะࠧᑰ")
	,yTMWeCgUROcvtsblfK85L62xPk(u"ࠫࡰࡧࡴ࡬ࡱࡷࡸࡻ࠭ᑱ")		:EDPaWgMt1SwNn8o(u"๋่ࠬใ฻ࠣ็ฯ้่หࠢอ๎ๆ๐ࠧᑲ")
	,J3OCAmZVcn(u"࠭ࡡࡳࡣࡥ࡭ࡨࡺ࡯ࡰࡰࡶࠫᑳ")	:PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠧๆ๊ๅ฽ࠥะ่็ิࠣ฽ึฮ๊สࠩᑴ")
	,FhcnOB9t3frzvXb(u"ࠨࡦࡵࡥࡲࡧࡳ࠸ࠩᑵ")		:JMLhEyaBWmskovGHTrVCxQ08(u"่ࠩ์็฿ࠠะำส้ฬࠦีฮࠩᑶ")
	,gnfv8UtZ3daGqpjzk(u"ࠪࡷ࡭ࡵ࡯ࡧࡲࡵࡳࠬᑷ")		:jYaM5vilgZdFx6QHbApwVXO8et(u"๊ࠫ๎โฺࠢื์ๆࠦศา๊ࠪᑸ")
	,ZSJVq5XDrRot(u"ࠬ࡯ࡦࡪ࡮ࡰࠫᑹ")				:m6b7CoBk4EQ(u"࠭ๅ้ไ฼ࠤ็์วสࠢล๎ࠥ็๊ๅ็ࠪᑺ")
	,bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࡪࡨ࡬ࡰࡲ࠳ࡡࡳࡣࡥ࡭ࡨ࠭ᑻ")			:hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠥ฿ัษ์ࠪᑼ")
	,OVmSuf8tpd(u"ࠩ࡬ࡪ࡮ࡲ࡭࠮ࡧࡱ࡫ࡱ࡯ࡳࡩࠩᑽ")		:bdhQDyjm3nPwToFHkprvCzBLUGR(u"้ࠪํู่ࠡไ้หฮࠦย๋ࠢไ๎้๋ࠠศ่ฯ่๏ุ๊ࠨᑾ")
	,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫࡵࡧ࡮ࡦࡶࠪᑿ")				:eeIL1TfgFQJaKqVD8hGNPEZ(u"๋่ࠬใ฻ࠣฬฬ์๊หࠩᒀ")
	,wwyUWMFAsO(u"࠭ࡰࡢࡰࡨࡸ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬᒁ")			:pEo8g7riWVL014KaRtzQ(u"ࠧๆ๊ๅ฽ࠥฮว็์อࠤฬ็ไศ็ࠪᒂ")
	,fR68jBGWCzUsFXdlTKPOScugm(u"ࠨࡲࡤࡲࡪࡺ࠭ࡴࡧࡵ࡭ࡪࡹࠧᒃ")			:m6b7CoBk4EQ(u"่ࠩ์็฿ࠠษษ้๎ฯࠦๅิๆึ่ฬะࠧᒄ")
	,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫᒅ")				:FhcnOB9t3frzvXb(u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠩᒆ")
	,ZSJVq5XDrRot(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠳ࡶࡪࡦࡨࡳࡸ࠭ᒇ")		:aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤๆ๐ฯ๋๊๊หฯ࠭ᒈ")
	,EDPaWgMt1SwNn8o(u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠮ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫᒉ")	:gSmqZU0plur2xKPJwQA(u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦโ้ษษ้ࠬᒊ")
	,JMLhEyaBWmskovGHTrVCxQ08(u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠰ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬᒋ")		:OVmSuf8tpd(u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡไ้์ฬะࠧᒌ")
	,OVmSuf8tpd(u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫ࠧᒍ")			:PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠧᒎ")
	,AAgpHN0nMZ(u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦ࠯ࡳࡩࡷࡹ࡯࡯ࡵࠪᒏ")	:FhcnOB9t3frzvXb(u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสࠢๅหึฬࠧᒐ")
	,DLSVmlyBbCK(u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨ࠱ࡦࡲࡢࡶ࡯ࡶࠫᒑ")		:pEo8g7riWVL014KaRtzQ(u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤฬ๊ศ้็ࠪᒒ")
	,J3OCAmZVcn(u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠳ࡡࡶࡦ࡬ࡳࡸ࠭ᒓ")		:JMLhEyaBWmskovGHTrVCxQ08(u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦี้ฬํหฯ࠭ᒔ")
	,ZSJVq5XDrRot(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪᒕ")			:gnfv8UtZ3daGqpjzk(u"࠭ๅ้ไ฼ࠤิ๐ไ๋่ࠢ์ู์ࠧᒖ")
	,gSmqZU0plur2xKPJwQA(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡼࡩࡥࡧࡲࡷࠬᒗ")	:JMLhEyaBWmskovGHTrVCxQ08(u"ࠨ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠢไ๎ิ๐่่ษอࠫᒘ")
	,LmcNhzY6fQPd2JyCGslkSr(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪᒙ"):FhcnOB9t3frzvXb(u"้ࠪํู่ࠡัํ่๏ࠦๅ้ึ้ࠤ็๎วว็ࠪᒚ")
	,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫᒛ")	:wwyUWMFAsO(u"๋่ࠬใ฻ࠣำ๏๊๊ࠡ็ุ๋๋ࠦโ็๊สฮࠬᒜ")
	,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡹࡵࡰࡪࡥࡶࠫᒝ")	:pEo8g7riWVL014KaRtzQ(u"ࠧๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠡ็๋ห฻๐ูࠨᒞ")
	,gSmqZU0plur2xKPJwQA(u"ࠨ࡫ࡳࡸࡻ࠭ᒟ")					:J3OCAmZVcn(u"ࠩࡌࡔ࡙࡜ࠧᒠ")
	,XogUJZEijT7KWbxeO6(u"ࠪ࡭ࡵࡺࡶ࠮࡮࡬ࡺࡪ࠭ᒡ")			:eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫࡎࡖࡔࡗࠢๅ๊ํอสࠨᒢ")
	,J3OCAmZVcn(u"ࠬ࡯ࡰࡵࡸ࠰ࡱࡴࡼࡩࡦࡵࠪᒣ")			:gnfv8UtZ3daGqpjzk(u"࠭ࡉࡑࡖ࡙ࠤศ็ไศ็ࠪᒤ")
	,LmcNhzY6fQPd2JyCGslkSr(u"ࠧࡪࡲࡷࡺ࠲ࡹࡥࡳ࡫ࡨࡷࠬᒥ")			:gSmqZU0plur2xKPJwQA(u"ࠨࡋࡓࡘ࡛ࠦๅิๆึ่ฬะࠧᒦ")
	,ZSJVq5XDrRot(u"ࠩࡰ࠷ࡺ࠭ᒧ")					:aVLSn1xw5cK(u"ࠪࡑ࠸࡛ࠧᒨ")
	,JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࡲ࠹ࡵ࠮࡮࡬ࡺࡪ࠭ᒩ")				:Ej67fFyoqW8kbV2HdSK(u"ࠬࡓ࠳ࡖࠢๅ๊ํอสࠨᒪ")
	,kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭࡭࠴ࡷ࠰ࡱࡴࡼࡩࡦࡵࠪᒫ")			:wwyUWMFAsO(u"ࠧࡎ࠵ࡘࠤศ็ไศ็ࠪᒬ")
	,hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠨ࡯࠶ࡹ࠲ࡹࡥࡳ࡫ࡨࡷࠬᒭ")			:JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠩࡐ࠷࡚ࠦๅิๆึ่ฬะࠧᒮ")
	}
	try: OjgFlPRGcVy95qSxZeJKM4fkBoLWtN = ARYupe4MbZJVPWhIFy7jDBo[unjzvHfWpPTbqACy9RtOY6m.lower()]
	except: OjgFlPRGcVy95qSxZeJKM4fkBoLWtN = FhcnOB9t3frzvXb(u"ࠪࠫᒯ")
	return OjgFlPRGcVy95qSxZeJKM4fkBoLWtN
def iiysxZ8dOaA(d0Z7abLoEfmpHTOkgVG=DLSVmlyBbCK(u"ࠫࠬᒰ")):
	Uzk5El62NdFj()
	if not d0Z7abLoEfmpHTOkgVG: d0Z7abLoEfmpHTOkgVG = jYaM5vilgZdFx6QHbApwVXO8et(u"ࠬࡌ࡯ࡳࡥࡨࡨࠥࡋࡸࡪࡶࠪᒱ")
	tr24ZoudmqvxfYCw(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭ࠧᒲ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧ࡝ࡰࠪᒳ")+d0Z7abLoEfmpHTOkgVG+EDPaWgMt1SwNn8o(u"ࠨ࡞ࡱࠫᒴ"))
	raise SystemExit
def cD1AgYCl0qZI8(XpOsU3v5dqH8MQAK6FcafmP1z0kL2,fuEbncpNV5DXPzHI4Os7TMjZvdeiJy=m6b7CoBk4EQ(u"ࠩ࠽࠳ࠬᒵ")):
	return _tiKbagXkV(XpOsU3v5dqH8MQAK6FcafmP1z0kL2,fuEbncpNV5DXPzHI4Os7TMjZvdeiJy)
def cDJ2hdI4jPu9CweB0Nsg37L(YYKqgSAxOPurGvWT0QDwZeRHpiN3c):
	if YYKqgSAxOPurGvWT0QDwZeRHpiN3c in [xuYvdJpOEyQKTLNwb(u"ࠪࠫᒶ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠫ࠵࠭ᒷ"),ZSJVq5XDrRot(u"࠱ᝰ")]: return ZSJVq5XDrRot(u"ࠬ࠭ᒸ")
	YYKqgSAxOPurGvWT0QDwZeRHpiN3c = int(YYKqgSAxOPurGvWT0QDwZeRHpiN3c)
	nW6H9LE31jY0GqFtlA = YYKqgSAxOPurGvWT0QDwZeRHpiN3c^JNsoWV1CXc4xy
	gNVmLpP014zuOCRjJ3I8wh6nfc = YYKqgSAxOPurGvWT0QDwZeRHpiN3c^Z7uFdWIRv9ybj0
	gMXki9QYWHFR0hwsnIPJTz = YYKqgSAxOPurGvWT0QDwZeRHpiN3c^dALVaOWB4jKN3Tbt0Cm1ns9k5u
	OjgFlPRGcVy95qSxZeJKM4fkBoLWtN = str(nW6H9LE31jY0GqFtlA)+str(gNVmLpP014zuOCRjJ3I8wh6nfc)+str(gMXki9QYWHFR0hwsnIPJTz)
	return OjgFlPRGcVy95qSxZeJKM4fkBoLWtN
def TFKHknYudeslSbxOQDoGaXpc6(YYKqgSAxOPurGvWT0QDwZeRHpiN3c):
	if YYKqgSAxOPurGvWT0QDwZeRHpiN3c in [J3OCAmZVcn(u"࠭ࠧᒹ"),xuYvdJpOEyQKTLNwb(u"ࠧ࠱ࠩᒺ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠲᝱")]: return xuYvdJpOEyQKTLNwb(u"ࠨࠩᒻ")
	YYKqgSAxOPurGvWT0QDwZeRHpiN3c = str(YYKqgSAxOPurGvWT0QDwZeRHpiN3c)
	OjgFlPRGcVy95qSxZeJKM4fkBoLWtN = AAgpHN0nMZ(u"ࠩࠪᒼ")
	if len(YYKqgSAxOPurGvWT0QDwZeRHpiN3c)==kRYWcNuAazr4jtmBoxFVS19Z6(u"࠴࠹ᝲ"):
		nW6H9LE31jY0GqFtlA,gNVmLpP014zuOCRjJ3I8wh6nfc,gMXki9QYWHFR0hwsnIPJTz = YYKqgSAxOPurGvWT0QDwZeRHpiN3c[kmdSKeBIwViM9t3(u"࠵᝴"):fR68jBGWCzUsFXdlTKPOScugm(u"࠺᝵")],YYKqgSAxOPurGvWT0QDwZeRHpiN3c[fR68jBGWCzUsFXdlTKPOScugm(u"࠺᝵"):c4QSTnPiWUCjhrLlwGB(u"࠽ᝳ")],YYKqgSAxOPurGvWT0QDwZeRHpiN3c[c4QSTnPiWUCjhrLlwGB(u"࠽ᝳ"):]
		nW6H9LE31jY0GqFtlA = int(nW6H9LE31jY0GqFtlA)^dALVaOWB4jKN3Tbt0Cm1ns9k5u
		gNVmLpP014zuOCRjJ3I8wh6nfc = int(gNVmLpP014zuOCRjJ3I8wh6nfc)^Z7uFdWIRv9ybj0
		gMXki9QYWHFR0hwsnIPJTz = int(gMXki9QYWHFR0hwsnIPJTz)^JNsoWV1CXc4xy
		if nW6H9LE31jY0GqFtlA==gNVmLpP014zuOCRjJ3I8wh6nfc==gMXki9QYWHFR0hwsnIPJTz: OjgFlPRGcVy95qSxZeJKM4fkBoLWtN = str(nW6H9LE31jY0GqFtlA*ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠶࠱᝶"))
	return OjgFlPRGcVy95qSxZeJKM4fkBoLWtN
def uD0IBl6nS9jqNekYZXaxzd2(YYKqgSAxOPurGvWT0QDwZeRHpiN3c,icpsBKqbgeS3DNxnuFflPYCMjvm=jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪ࠺࠸࠾࠴࠲࠺࠵࠷ࠬᒽ")):
	if YYKqgSAxOPurGvWT0QDwZeRHpiN3c==gnfv8UtZ3daGqpjzk(u"ࠫࠬᒾ"): return wwyUWMFAsO(u"ࠬ࠭ᒿ")
	YYKqgSAxOPurGvWT0QDwZeRHpiN3c = int(YYKqgSAxOPurGvWT0QDwZeRHpiN3c)+int(icpsBKqbgeS3DNxnuFflPYCMjvm)
	nW6H9LE31jY0GqFtlA = YYKqgSAxOPurGvWT0QDwZeRHpiN3c^JNsoWV1CXc4xy
	gNVmLpP014zuOCRjJ3I8wh6nfc = YYKqgSAxOPurGvWT0QDwZeRHpiN3c^Z7uFdWIRv9ybj0
	gMXki9QYWHFR0hwsnIPJTz = YYKqgSAxOPurGvWT0QDwZeRHpiN3c^dALVaOWB4jKN3Tbt0Cm1ns9k5u
	OjgFlPRGcVy95qSxZeJKM4fkBoLWtN = str(nW6H9LE31jY0GqFtlA)+str(gNVmLpP014zuOCRjJ3I8wh6nfc)+str(gMXki9QYWHFR0hwsnIPJTz)
	return OjgFlPRGcVy95qSxZeJKM4fkBoLWtN
def SeN2UjVuMw6K03nrgWZLOYB5la7mpA(YYKqgSAxOPurGvWT0QDwZeRHpiN3c,icpsBKqbgeS3DNxnuFflPYCMjvm=wwyUWMFAsO(u"࠭࠶࠴࠺࠷࠵࠽࠸࠳ࠨᓀ")):
	if YYKqgSAxOPurGvWT0QDwZeRHpiN3c==bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࠨᓁ"): return wwyUWMFAsO(u"ࠨࠩᓂ")
	YYKqgSAxOPurGvWT0QDwZeRHpiN3c = str(YYKqgSAxOPurGvWT0QDwZeRHpiN3c)
	U2QADirkbfRT7 = int(len(YYKqgSAxOPurGvWT0QDwZeRHpiN3c)/DLSVmlyBbCK(u"࠴᝷"))
	nW6H9LE31jY0GqFtlA = int(YYKqgSAxOPurGvWT0QDwZeRHpiN3c[MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠲᝸"):U2QADirkbfRT7])^JNsoWV1CXc4xy
	gNVmLpP014zuOCRjJ3I8wh6nfc = int(YYKqgSAxOPurGvWT0QDwZeRHpiN3c[U2QADirkbfRT7:eeIL1TfgFQJaKqVD8hGNPEZ(u"࠵᝹")*U2QADirkbfRT7])^Z7uFdWIRv9ybj0
	gMXki9QYWHFR0hwsnIPJTz = int(YYKqgSAxOPurGvWT0QDwZeRHpiN3c[c4QSTnPiWUCjhrLlwGB(u"࠷᝻")*U2QADirkbfRT7:wwyUWMFAsO(u"࠷᝺")*U2QADirkbfRT7])^dALVaOWB4jKN3Tbt0Cm1ns9k5u
	OjgFlPRGcVy95qSxZeJKM4fkBoLWtN = jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩࠪᓃ")
	if nW6H9LE31jY0GqFtlA==gNVmLpP014zuOCRjJ3I8wh6nfc==gMXki9QYWHFR0hwsnIPJTz: OjgFlPRGcVy95qSxZeJKM4fkBoLWtN = str(int(nW6H9LE31jY0GqFtlA)-int(icpsBKqbgeS3DNxnuFflPYCMjvm))
	return OjgFlPRGcVy95qSxZeJKM4fkBoLWtN
def LTOXNG9KQohp8lmbS0uw16VEJrjUk(w0TmsUtgR5F8LIjNAbfKua7d6QWZ):
	TUchol3DA8j = uReHcEzxkTm6pN4Q[ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪᓄ")][sArCMRngQNmXkBoKv(u"࠾᝼")]
	Ebpk835OflJcWrhLiR7Sot4XaF1KCs = HHWAnGJrb9powOqTkYgcPQ6Ef(XogUJZEijT7KWbxeO6(u"࠳࠳᝽"))
	py2d0Cjtv1TW6VZqED4nuSoULGwR = hhHq8m5vauKG9dl.path.join(J5keFiyQtf9bGZ0vulzNIsTYMx1oR,jYaM5vilgZdFx6QHbApwVXO8et(u"ࠫࡷ࡫ࡳࡰࡷࡵࡧࡪࡹࠧᓅ"),m6b7CoBk4EQ(u"ࠬࡹ࡫ࡪࡰࡶࠫᓆ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧᓇ"),xuYvdJpOEyQKTLNwb(u"ࠧ࠸࠴࠳ࡴࠬᓈ"),gnfv8UtZ3daGqpjzk(u"ࠨࡆ࡬ࡥࡱࡵࡧࡄࡱࡱࡪ࡮ࡸ࡭ࡕࡪࡵࡩࡪࡈࡵࡵࡶࡲࡲࡸ࠴ࡸ࡮࡮ࠪᓉ"))
	DDKFkOxhsB0mpR,KDLg8Xr1AMzsoO6CEYG2mk9e = ssIxDJ3iKeVqBUvFYW4r(py2d0Cjtv1TW6VZqED4nuSoULGwR)
	DDKFkOxhsB0mpR = uD0IBl6nS9jqNekYZXaxzd2(DDKFkOxhsB0mpR,Ej67fFyoqW8kbV2HdSK(u"ࠩ࠴࠶࠶࠾࠳࠲࠺࠸࠷ࠬᓊ"))
	bmMr9EqwzuN1j5lahA = {FhcnOB9t3frzvXb(u"ࠪ࡭ࡩࡹࠧᓋ"):JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠫࡉࡏࡁࡍࡑࡊࠫᓌ"),DLSVmlyBbCK(u"ࠬࡻࡳࡳࠩᓍ"):Ebpk835OflJcWrhLiR7Sot4XaF1KCs,gnfv8UtZ3daGqpjzk(u"࠭ࡶࡦࡴࠪᓎ"):i69DxzEZSwmuY5Il,gSmqZU0plur2xKPJwQA(u"ࠧࡴࡥࡵࠫᓏ"):w0TmsUtgR5F8LIjNAbfKua7d6QWZ,sArCMRngQNmXkBoKv(u"ࠨࡵ࡬ࡾࠬᓐ"):DDKFkOxhsB0mpR}
	izyE4fRgAVrHI = {kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨᓑ"):AAgpHN0nMZ(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩᓒ")}
	MMT6cew8ybVJLNA = A6F71g3cqN4(Z7uFdWIRv9ybj0,bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠫࡕࡕࡓࡕࠩᓓ"),TUchol3DA8j,bmMr9EqwzuN1j5lahA,izyE4fRgAVrHI,ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬ࠭ᓔ"),LmcNhzY6fQPd2JyCGslkSr(u"࠭ࠧᓕ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡕࡋࡓ࡜ࡥࡐࡍࡃ࡜ࡣࡉࡏࡁࡍࡑࡊ࠱࠶ࡹࡴࠨᓖ"))
	UvmqIg10hpY4KP8aBre7 = MMT6cew8ybVJLNA.content
	try:
		if not UvmqIg10hpY4KP8aBre7: GY2LqZuejNs50XPgmUbzKdiy
		v5xpGoeSMm16 = NL0JIkbrEWqTYj61vVKGCnBw37MsOF(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨࡦ࡬ࡧࡹ࠭ᓗ"),UvmqIg10hpY4KP8aBre7)
		xeXfR4wdUsWpZ8kyQ2L5 = v5xpGoeSMm16[FhcnOB9t3frzvXb(u"ࠩࡰࡷ࡬࠭ᓘ")]
		uZDK4gJdBWr32 = v5xpGoeSMm16[aVLSn1xw5cK(u"ࠪࡷࡪࡩࠧᓙ")]
		Gh7OfWHuePtV8ralC0bM2JvEqgN = v5xpGoeSMm16[gSmqZU0plur2xKPJwQA(u"ࠫࡸࡺࡰࠨᓚ")]
		uZDK4gJdBWr32 = int(SeN2UjVuMw6K03nrgWZLOYB5la7mpA(uZDK4gJdBWr32,Ej67fFyoqW8kbV2HdSK(u"ࠬ࠷࠲࠲࠺࠶࠵࠽࠻࠳ࠨᓛ")))
		Gh7OfWHuePtV8ralC0bM2JvEqgN = int(SeN2UjVuMw6K03nrgWZLOYB5la7mpA(Gh7OfWHuePtV8ralC0bM2JvEqgN,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭࠱࠳࠳࠻࠷࠶࠾࠵࠴ࠩᓜ")))
		for qJhdcfYEO6gSUHMFkpw in range(uZDK4gJdBWr32,wwyUWMFAsO(u"࠱᝾"),-Gh7OfWHuePtV8ralC0bM2JvEqgN):
			if not eval(gSmqZU0plur2xKPJwQA(u"ࠧࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡪࡵࡓࡰࡦࡿࡩ࡯ࡩ࡙࡭ࡩ࡫࡯ࠩࠫࠪᓝ"),{pEo8g7riWVL014KaRtzQ(u"ࠨࡺࡥࡱࡨ࠭ᓞ"):cPwDBuG4HVTCdQ9JmMeoWjNY2hX}): GY2LqZuejNs50XPgmUbzKdiy
			NLVM3HAtxQOSvJf6kd78K1o(DLSVmlyBbCK(u"ࠩหห็๐ࠠๅๆอะึฮษ๊ࠡส่ๆำีࠨᓟ"),str(qJhdcfYEO6gSUHMFkpw)+LmcNhzY6fQPd2JyCGslkSr(u"ࠪࠤࠥัว็์ฬࠫᓠ"),luMHeSgCBaPrb9KvUjNFqcR=LmcNhzY6fQPd2JyCGslkSr(u"࠵࠳࠴᝿")*Gh7OfWHuePtV8ralC0bM2JvEqgN)
			cPwDBuG4HVTCdQ9JmMeoWjNY2hX.sleep(OVmSuf8tpd(u"࠴࠴࠵࠶ក")*Gh7OfWHuePtV8ralC0bM2JvEqgN)
		if eval(J3OCAmZVcn(u"ࠫࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲࡮ࡹࡐ࡭ࡣࡼ࡭ࡳ࡭ࡖࡪࡦࡨࡳ࠭࠯ࠧᓡ"),{LmcNhzY6fQPd2JyCGslkSr(u"ࠬࡾࡢ࡮ࡥࠪᓢ"):cPwDBuG4HVTCdQ9JmMeoWjNY2hX}):
			xeXfR4wdUsWpZ8kyQ2L5 = xeXfR4wdUsWpZ8kyQ2L5.replace(pEo8g7riWVL014KaRtzQ(u"࠭࡜࡯ࠩᓣ"),Ej67fFyoqW8kbV2HdSK(u"ࠧ࡝࡞ࡱࠫᓤ")).replace(kmdSKeBIwViM9t3(u"ࠨ࡞ࡵࠫᓥ"),OVmSuf8tpd(u"ࠩ࡟ࡠࡷ࠭ᓦ"))
			HHTzVhiY079bvdluNkFQ4wCMpe(aVLSn1xw5cK(u"ࠪࠫᓧ"),wwyUWMFAsO(u"ࠫำื่อࠩᓨ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᓩ"),xeXfR4wdUsWpZ8kyQ2L5)
		GY2LqZuejNs50XPgmUbzKdiy
	except: exec(gnfv8UtZ3daGqpjzk(u"࠭ࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡳࡵࡱࡳࠬ࠮࠭ᓪ"),{ZSJVq5XDrRot(u"ࠧࡹࡤࡰࡧࠬᓫ"):cPwDBuG4HVTCdQ9JmMeoWjNY2hX})
	return
def KBeixSYCP1AhJvlN9p73LDaQzbw():
	exec(Ej67fFyoqW8kbV2HdSK(u"ࠨࠩࠪࠑࠏࡺࡲࡺ࠼ࠐࠎࠎࡽࡩ࡯ࡦࡲࡻ࠶࠸࠳ࠡ࠿ࠣࡼࡧࡳࡣࡨࡷ࡬࠲࡜࡯࡮ࡥࡱࡺࠬ࠶࠶࠰࠳࠷ࠬࠑࠏࠏࡷࡩ࡫࡯ࡩ࡚ࠥࡲࡶࡧ࠽ࠑࠏࠏࠉࡹࡤࡰࡧ࠳ࡹ࡬ࡦࡧࡳࠬ࠶࠶࠰࠱ࠫࠐࠎࠎࠏࡴࡳࡻ࠽ࠤࡼ࡯࡮ࡥࡱࡺ࠵࠷࠹࠮ࡨࡧࡷࡊࡴࡩࡵࡴࠪ࠴࠴࠵࠸࠵ࠪࠏࠍࠍࠎ࡫ࡸࡤࡧࡳࡸ࠿ࠦࡢࡳࡧࡤ࡯ࠒࠐࠉࡻࡥࡵࡩࡦࡺࡥࡠࡧࡵࡳࡷࡸࠍࠋࡧࡻࡧࡪࡶࡴ࠻ࠢࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰ࡶࡸࡴࡶࠨࠪࠏࠍࠫࠬ࠭ᓬ"),{MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩࡻࡦࡲࡩࡧࡶ࡫ࠪᓭ"):kGEPsyxKnHDJ,gnfv8UtZ3daGqpjzk(u"ࠪࡼࡧࡳࡣࠨᓮ"):cPwDBuG4HVTCdQ9JmMeoWjNY2hX})
	return
def ssIxDJ3iKeVqBUvFYW4r(zN3iGUHVMpnEfLrvFDxcPX):
	aZAiV53PSI0XFWj,Bn1eRl2KbGqszdFYJ8Z3S4I = xuYvdJpOEyQKTLNwb(u"࠴ខ"),xuYvdJpOEyQKTLNwb(u"࠴ខ")
	if hhHq8m5vauKG9dl.path.exists(zN3iGUHVMpnEfLrvFDxcPX):
		try: aZAiV53PSI0XFWj = hhHq8m5vauKG9dl.path.getsize(zN3iGUHVMpnEfLrvFDxcPX)
		except: pass
		if not aZAiV53PSI0XFWj:
			try: aZAiV53PSI0XFWj = hhHq8m5vauKG9dl.stat(zN3iGUHVMpnEfLrvFDxcPX).st_size
			except: pass
		if not aZAiV53PSI0XFWj:
			try:
				from pathlib import Path as bgupZyjE7X
				aZAiV53PSI0XFWj = bgupZyjE7X(zN3iGUHVMpnEfLrvFDxcPX).stat().st_size
			except: pass
		if aZAiV53PSI0XFWj: Bn1eRl2KbGqszdFYJ8Z3S4I = JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠶គ")
	return aZAiV53PSI0XFWj,Bn1eRl2KbGqszdFYJ8Z3S4I
def Eux3w7MylkQfiBa6pvJO0FWTNbr(YtxioeKAJWSUNVOla,vLH2ijytoXROrakeF1x6UI4NfE,showDialogs):
	if showDialogs:
		YYkEu4IL0sTa = OxCB4medn1(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫࠬᓯ"),FhcnOB9t3frzvXb(u"ࠬ࠭ᓰ"),kmdSKeBIwViM9t3(u"࠭ࠧᓱ"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᓲ"),YtxioeKAJWSUNVOla+J3OCAmZVcn(u"ࠨ࡞ࡱࡠࡳ࠭ᓳ")+ZSJVq5XDrRot(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ์๊ࠠหำํำ๋ࠥำฮ๊ࠢิฬࠦวๅ็ฯ่ิࠦฟࠢ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᓴ"))
		if YYkEu4IL0sTa!=ZSJVq5XDrRot(u"࠷ឃ"): return
	KB1kx0UPF7 = bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࡉࡥࡱࡹࡥ᠚")
	if hhHq8m5vauKG9dl.path.exists(YtxioeKAJWSUNVOla):
		for Wc2Cz7h3LlwfYMDPteNasGdZ4IXok5,P8CTpdirwzO5ZFRGfoJV93k1Xqy,NN0VnHzeD4flhcFUot in hhHq8m5vauKG9dl.walk(YtxioeKAJWSUNVOla,topdown=FhcnOB9t3frzvXb(u"ࡊࡦࡲࡳࡦ᠛")):
			for zN3iGUHVMpnEfLrvFDxcPX in NN0VnHzeD4flhcFUot:
				Ss8MaEbzQmOBGhR4C7ontf3jdiu = hhHq8m5vauKG9dl.path.join(Wc2Cz7h3LlwfYMDPteNasGdZ4IXok5,zN3iGUHVMpnEfLrvFDxcPX)
				try: hhHq8m5vauKG9dl.remove(Ss8MaEbzQmOBGhR4C7ontf3jdiu)
				except Exception as jD36UfMuAv9TqxZeVFlm75WynYk:
					if showDialogs and not KB1kx0UPF7: HHTzVhiY079bvdluNkFQ4wCMpe(yTMWeCgUROcvtsblfK85L62xPk(u"ࠪࠫᓵ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫࠬᓶ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᓷ"),str(jD36UfMuAv9TqxZeVFlm75WynYk))
					KB1kx0UPF7 = yTMWeCgUROcvtsblfK85L62xPk(u"࡙ࡸࡵࡦ᠜")
			if vLH2ijytoXROrakeF1x6UI4NfE:
				for dir in P8CTpdirwzO5ZFRGfoJV93k1Xqy:
					EAicvVI8jXPC = hhHq8m5vauKG9dl.path.join(Wc2Cz7h3LlwfYMDPteNasGdZ4IXok5,dir)
					try: hhHq8m5vauKG9dl.rmdir(EAicvVI8jXPC)
					except: pass
		if vLH2ijytoXROrakeF1x6UI4NfE:
			try: hhHq8m5vauKG9dl.rmdir(Wc2Cz7h3LlwfYMDPteNasGdZ4IXok5)
			except: pass
	if showDialogs and not KB1kx0UPF7:
		HHTzVhiY079bvdluNkFQ4wCMpe(Ej67fFyoqW8kbV2HdSK(u"࠭ࠧᓸ"),xuYvdJpOEyQKTLNwb(u"ࠧࠨᓹ"),wwyUWMFAsO(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᓺ"),DLSVmlyBbCK(u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪᓻ"))
		j2agIU0xsLS6c7T.setSetting(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧᓼ"),kmdSKeBIwViM9t3(u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧᓽ"))
		cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(EDPaWgMt1SwNn8o(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩᓾ"))
	return
def Uzk5El62NdFj(m0AGWhywZVXFtYQ=kmdSKeBIwViM9t3(u"࠭ࠧᓿ")):
	jJSBRtqke9EU6waxvz7PDrg8ATnWm1(ZSJVq5XDrRot(u"ࠧࡴࡶࡲࡴࠬᔀ"))
	if m0AGWhywZVXFtYQ:
		tgQs4VY5JdLGi9wr = j2agIU0xsLS6c7T.getSetting(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩᔁ"))
		j2agIU0xsLS6c7T.setSetting(aVLSn1xw5cK(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪᔂ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪࠫᔃ"))
		jTB4IzGRvbPxCgq2Y(m0AGWhywZVXFtYQ)
		j2agIU0xsLS6c7T.setSetting(aVLSn1xw5cK(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬᔄ"),tgQs4VY5JdLGi9wr)
	nnF1VOMIkrqi2ojXux6UPHGyEf7Kg = j2agIU0xsLS6c7T.getSetting(kmdSKeBIwViM9t3(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩᔅ"))
	if nnF1VOMIkrqi2ojXux6UPHGyEf7Kg==c4QSTnPiWUCjhrLlwGB(u"࠭ࡒࡆࡓࡘࡉࡘ࡚ࡅࡅࠩᔆ"): j2agIU0xsLS6c7T.setSetting(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫᔇ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨࡔࡈࡊࡗࡋࡓࡉࡇࡇࠫᔈ"))
	elif nnF1VOMIkrqi2ojXux6UPHGyEf7Kg==J3OCAmZVcn(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡈࡈࠬᔉ"): j2agIU0xsLS6c7T.setSetting(EDPaWgMt1SwNn8o(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧᔊ"),gnfv8UtZ3daGqpjzk(u"ࠫࠬᔋ"))
	if j2agIU0xsLS6c7T.getSetting(gnfv8UtZ3daGqpjzk(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨᔌ")) not in [yTMWeCgUROcvtsblfK85L62xPk(u"࠭ࡁࡖࡖࡒࠫᔍ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧࡔࡖࡒࡔࠬᔎ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠨࡃࡖࡏࠬᔏ")]: j2agIU0xsLS6c7T.setSetting(FhcnOB9t3frzvXb(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬᔐ"),FhcnOB9t3frzvXb(u"ࠪࡅࡘࡑࠧᔑ"))
	if j2agIU0xsLS6c7T.getSetting(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩᔒ")) not in [wwyUWMFAsO(u"ࠬࡇࡕࡕࡑࠪᔓ"),JMLhEyaBWmskovGHTrVCxQ08(u"࠭ࡓࡕࡑࡓࠫᔔ"),AAgpHN0nMZ(u"ࠧࡂࡕࡎࠫᔕ")]: j2agIU0xsLS6c7T.setSetting(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ᔖ"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠩࡄࡗࡐ࠭ᔗ"))
	XlHqW2y5e1 = j2agIU0xsLS6c7T.getSetting(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪࡥࡻ࠴࡭ࡺࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨᔘ"))
	lC8scLAd0IFYuTbR3UWk9ZxJNSQ = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executeJSONRPC(FhcnOB9t3frzvXb(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧᔙ"))
	if OVmSuf8tpd(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫᔚ") in str(lC8scLAd0IFYuTbR3UWk9ZxJNSQ) and XlHqW2y5e1 in [sArCMRngQNmXkBoKv(u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩᔛ"),m6b7CoBk4EQ(u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭ᔜ")]:
		luMHeSgCBaPrb9KvUjNFqcR.sleep(bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠰࠯࠳࠳࠴ង"))
		cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(XogUJZEijT7KWbxeO6(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡘ࡫ࡴࡗ࡫ࡨࡻࡒࡵࡤࡦࠪ࠳࠭ࠬᔝ"))
	if eeIL1TfgFQJaKqVD8hGNPEZ(u"࠲ឆ") and jVGRimgPZeu9l0dsUoHJ1a>-ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠲ច"):
		pZrEWcFVmiNCjozM.setResolvedUrl(jVGRimgPZeu9l0dsUoHJ1a,FhcnOB9t3frzvXb(u"ࡌࡡ࡭ࡵࡨ᠝"),kGEPsyxKnHDJ.ListItem())
		ybf3Qo7isaYVr,fCT9Mc1xyXogjGYN08mbnLQDIqh,c0c6mgI7VBUhHZ = ZSJVq5XDrRot(u"ࡆࡢ࡮ࡶࡩ᠞"),ZSJVq5XDrRot(u"ࡆࡢ࡮ࡶࡩ᠞"),ZSJVq5XDrRot(u"ࡆࡢ࡮ࡶࡩ᠞")
		pZrEWcFVmiNCjozM.endOfDirectory(jVGRimgPZeu9l0dsUoHJ1a,ybf3Qo7isaYVr,fCT9Mc1xyXogjGYN08mbnLQDIqh,c0c6mgI7VBUhHZ)
	return
def qdMurfa5o7CbOKU6xE(VkZ3taqEOKhCI6N,nJDfuczrBG4ZeOs,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,SOlDApJEx73FokmVdYCfKuRNXy8,yJQ0WizojdcChZPM4,j5jMXZ7myEuoLG):
	lQHXdV9Nzf6BLqS8D,b6jTGhv0gK,a7043au5scA2dQextyrVvCzGoq,Ehvu5RXJdc826O = glE1Zx2einabXPjKV3DvMu(XpOsU3v5dqH8MQAK6FcafmP1z0kL2)
	fdmbuvJpzy = nJDfuczrBG4ZeOs,lQHXdV9Nzf6BLqS8D,SOlDApJEx73FokmVdYCfKuRNXy8,yJQ0WizojdcChZPM4
	if VkZ3taqEOKhCI6N:
		vdCNK2GykrWZIVeg7z5S4HFh = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,m6b7CoBk4EQ(u"ࠩࡶࡸࡷ࠭ᔞ"),kmdSKeBIwViM9t3(u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣ࡚ࡘࡌࡍࡋࡅࠫᔟ"),fdmbuvJpzy)
		if vdCNK2GykrWZIVeg7z5S4HFh:
			QbG0Lx7lnS6jUA9X3rzfsBYI8(FhcnOB9t3frzvXb(u"࡚ࠫࡘࡌࡍࡋࡅࠤࠥࡘࡅࡂࡆࡢࡇࡆࡉࡈࡆࠩᔠ"),XpOsU3v5dqH8MQAK6FcafmP1z0kL2,SOlDApJEx73FokmVdYCfKuRNXy8,yJQ0WizojdcChZPM4,j5jMXZ7myEuoLG,nJDfuczrBG4ZeOs)
			return vdCNK2GykrWZIVeg7z5S4HFh
	vdCNK2GykrWZIVeg7z5S4HFh = dptm8vZW9MiuK3fVNC(nJDfuczrBG4ZeOs,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,SOlDApJEx73FokmVdYCfKuRNXy8,yJQ0WizojdcChZPM4,j5jMXZ7myEuoLG)
	if vdCNK2GykrWZIVeg7z5S4HFh and VkZ3taqEOKhCI6N: Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,wwyUWMFAsO(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡕࡓࡎࡏࡍࡇ࠭ᔡ"),fdmbuvJpzy,vdCNK2GykrWZIVeg7z5S4HFh,VkZ3taqEOKhCI6N)
	return vdCNK2GykrWZIVeg7z5S4HFh
from iMTksS5tWQ import *
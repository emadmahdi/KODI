# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'SHIAVOICE'
W74fAyGxODoLPs5vMX2l8C93R = '_SHV_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
headers = {'User-Agent':None}
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==310: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==311: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url)
	elif mode==312: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==313: HkKfQCS7RIa4xi3houjvl = rreIwvojBJkMUd(url)
	elif mode==314: HkKfQCS7RIa4xi3houjvl = vyM5CbgVYS(text)
	elif mode==319: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',319,'','','_REMEMBERRESULTS_')
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',JJTrn6SEtYZV31eyR97,'','','','','SHIAVOICE-MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('id="menulinks"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = ZXFs0mEPR8qI2zj.findall('<h5>(.*?)</h5>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.IGNORECASE)
	for bznBHAX7xt6 in range(len(items)):
		title = items[bznBHAX7xt6].strip(' ')
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,JJTrn6SEtYZV31eyR97,314,'','',str(bznBHAX7xt6+1))
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'مقاطع شهر',JJTrn6SEtYZV31eyR97,314,'','','0')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?<B>(.*?)</B>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title in items:
		RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/'+RRucmYBaXegTtNOdGHMQ
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,311)
	return QstumvzTIEUMXCcx06aD4y8nSqH
def vyM5CbgVYS(bznBHAX7xt6):
	wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'GET',JJTrn6SEtYZV31eyR97,'','','','','SHIAVOICE-LATEST-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	if bznBHAX7xt6=='0':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="tab-content"(.*?)</table>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,name,title in items:
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/'+RRucmYBaXegTtNOdGHMQ
			title = title.strip(' ')
			name = name.strip(' ')
			title = title+' ('+name+')'
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,312)
	elif bznBHAX7xt6 in ['1','2','3']:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('(<h5>.*?)<div class="col-lg',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		nnrehsI6Y3OtGN = int(bznBHAX7xt6)-1
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[nnrehsI6Y3OtGN]
		if bznBHAX7xt6=='1': items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		else: items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title,name in items:
			CrGO63LT7j2UxniW = JJTrn6SEtYZV31eyR97+'/'+CrGO63LT7j2UxniW
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/'+RRucmYBaXegTtNOdGHMQ
			title = title.strip(' ')
			name = name.strip(' ')
			title = title+' ('+name+')'
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,311,CrGO63LT7j2UxniW)
	elif bznBHAX7xt6 in ['4','5','6']:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('(<h5>.*?)</table>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bznBHAX7xt6 = int(bznBHAX7xt6)-4
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[bznBHAX7xt6]
		items = ZXFs0mEPR8qI2zj.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for CrGO63LT7j2UxniW,RRucmYBaXegTtNOdGHMQ,Isp16k7xRZa0lYD5vdmA,title,Ym8DlVPuqS1tJb in items:
			CrGO63LT7j2UxniW = JJTrn6SEtYZV31eyR97+'/'+CrGO63LT7j2UxniW
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/'+RRucmYBaXegTtNOdGHMQ
			title = title.strip(' ')
			Isp16k7xRZa0lYD5vdmA = Isp16k7xRZa0lYD5vdmA.strip(' ')
			Ym8DlVPuqS1tJb = Ym8DlVPuqS1tJb.strip(' ')
			if Isp16k7xRZa0lYD5vdmA: name = Isp16k7xRZa0lYD5vdmA
			else: name = Ym8DlVPuqS1tJb
			title = title+' ('+name+')'
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,312,CrGO63LT7j2UxniW)
	return
def RxAy5lEFQ1chv0BrdU4p6Pt2(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','SHIAVOICE-TITLES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('ibox-heading"(.*?)class="float-right',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	if 'catsum-mobile' in bdq4e6Wr2gslnSiA38:
		items = ZXFs0mEPR8qI2zj.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if items:
			for CrGO63LT7j2UxniW,RRucmYBaXegTtNOdGHMQ,title,count in items:
				CrGO63LT7j2UxniW = JJTrn6SEtYZV31eyR97+'/'+CrGO63LT7j2UxniW
				RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/'+RRucmYBaXegTtNOdGHMQ
				count = count.replace(' الصوتية: ',':')
				title = title.strip(' ')
				title = title+' ('+count+')'
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,311,CrGO63LT7j2UxniW)
	else:
		items = ZXFs0mEPR8qI2zj.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title,zNyqR9EraWTXQH6tbDGi43klA,UombAD0Kk4XqOrYLB in items:
			if title=='' or zNyqR9EraWTXQH6tbDGi43klA=='': continue
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/'+RRucmYBaXegTtNOdGHMQ
			title = title+' ('+UombAD0Kk4XqOrYLB+')'
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,312)
	if not items: pqx0gStI9ojGFP2rWhwRfkVCNX(QstumvzTIEUMXCcx06aD4y8nSqH)
	return
def pqx0gStI9ojGFP2rWhwRfkVCNX(QstumvzTIEUMXCcx06aD4y8nSqH):
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="ibox-content"(.*?)class="pagination',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title,name,count,UombAD0Kk4XqOrYLB in items:
		RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/'+RRucmYBaXegTtNOdGHMQ
		title = title.strip(' ')
		name = name.strip(' ')
		title = title+' ('+name+')'
		Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,312,'',UombAD0Kk4XqOrYLB)
	return
def rreIwvojBJkMUd(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','SHIAVOICE-SEARCH_ITEMS-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="ibox-content p-1"(.*?)class="ibox-content"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not IZGcQbePXxwAoyYR1n:
		RxAy5lEFQ1chv0BrdU4p6Pt2(url)
		return
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?<strong>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title in items:
		RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/'+RRucmYBaXegTtNOdGHMQ
		title = title.strip(' ')
		if '/play-' in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,312)
		else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,311)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'GET',url,'','','','','SHIAVOICE-PLAY-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall('<audio.*?src="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall('<video.*?src="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ[0]
	w3hq0Xp8D9rZJ(RRucmYBaXegTtNOdGHMQ,ll6f2wvU4FdqL3MJyDxORESCK197i,'video')
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	search = search.replace(' ','+')
	smq0FpBJu4cbIT8PeU5HvDrz1Al = ['&t=a','&t=c','&t=s']
	if showDialogs:
		YhUMZe6GNliD2IknraFfB51u = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e('موقع صوت الشيعة - أختر البحث', YhUMZe6GNliD2IknraFfB51u)
		if jQ6w8xOrgYhSHIRpUqzL == -1: return
	elif '_SHIAVOICE-PERSONS_' in Y9RKmgsxBefkFcuIj2GULDHy3: jQ6w8xOrgYhSHIRpUqzL = 0
	elif '_SHIAVOICE-ALBUMS_' in Y9RKmgsxBefkFcuIj2GULDHy3: jQ6w8xOrgYhSHIRpUqzL = 1
	elif '_SHIAVOICE-AUDIOS_' in Y9RKmgsxBefkFcuIj2GULDHy3: jQ6w8xOrgYhSHIRpUqzL = 2
	else: return
	type = smq0FpBJu4cbIT8PeU5HvDrz1Al[jQ6w8xOrgYhSHIRpUqzL]
	url = JJTrn6SEtYZV31eyR97+'/search.php?q='+search+type
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','SHIAVOICE-SEARCH-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="ibox-content"(.*?)class="ibox-content"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		if jQ6w8xOrgYhSHIRpUqzL in [0,1]:
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title,name in items:
				title = title.strip(' ')
				name = name.strip(' ')
				title = title+' ('+name+')'
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,313,CrGO63LT7j2UxniW)
		elif jQ6w8xOrgYhSHIRpUqzL==2:
			items = ZXFs0mEPR8qI2zj.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title,name in items:
				title = title.strip(' ')
				name = name.strip(' ')
				title = title+' ('+name+')'
				Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,312)
	return
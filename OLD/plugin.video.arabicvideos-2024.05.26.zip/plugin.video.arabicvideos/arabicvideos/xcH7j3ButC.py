# -*- coding: utf-8 -*-
import sys as ddABnr3K9Xv8e71CzcN0Pxt
NLQaPokgt7Zi = ddABnr3K9Xv8e71CzcN0Pxt.version_info [0] == 2
QzcRNkipwA1WPJu6ZoTnxrjBlqe2 = 2048
Y07K8pBzWtXncO9rUdsw1MTgAyFS = 7
def pFM6HfGd7Urbxto45vSNLniWA (gKVwro2lTJQEp):
	global AUQrTjaXt8K
	UUhFMplXo8RaCwxnEz5Hm7r = ord (gKVwro2lTJQEp [-1])
	slDu7whZzrU2b3oCYREig1L65F9HK = gKVwro2lTJQEp [:-1]
	Ha7jrvByPJYSIiRoXm5ThCOWc = UUhFMplXo8RaCwxnEz5Hm7r % len (slDu7whZzrU2b3oCYREig1L65F9HK)
	E5JVTBFqvjCN2Sc = slDu7whZzrU2b3oCYREig1L65F9HK [:Ha7jrvByPJYSIiRoXm5ThCOWc] + slDu7whZzrU2b3oCYREig1L65F9HK [Ha7jrvByPJYSIiRoXm5ThCOWc:]
	if NLQaPokgt7Zi:
		lK9D8U71rY = unicode () .join ([unichr (ord (ysjIJ8PTAQv5copxFkLUXrRwf) - QzcRNkipwA1WPJu6ZoTnxrjBlqe2 - (WutIpGj5YChbO + UUhFMplXo8RaCwxnEz5Hm7r) % Y07K8pBzWtXncO9rUdsw1MTgAyFS) for WutIpGj5YChbO, ysjIJ8PTAQv5copxFkLUXrRwf in enumerate (E5JVTBFqvjCN2Sc)])
	else:
		lK9D8U71rY = str () .join ([chr (ord (ysjIJ8PTAQv5copxFkLUXrRwf) - QzcRNkipwA1WPJu6ZoTnxrjBlqe2 - (WutIpGj5YChbO + UUhFMplXo8RaCwxnEz5Hm7r) % Y07K8pBzWtXncO9rUdsw1MTgAyFS) for WutIpGj5YChbO, ysjIJ8PTAQv5copxFkLUXrRwf in enumerate (E5JVTBFqvjCN2Sc)])
	return eval (lK9D8U71rY)
OVmSuf8tpd,LmcNhzY6fQPd2JyCGslkSr,J3OCAmZVcn=pFM6HfGd7Urbxto45vSNLniWA,pFM6HfGd7Urbxto45vSNLniWA,pFM6HfGd7Urbxto45vSNLniWA
eeIL1TfgFQJaKqVD8hGNPEZ,aFQoGfmYKyqLU6X8libw9k3ncW5,m6b7CoBk4EQ=J3OCAmZVcn,LmcNhzY6fQPd2JyCGslkSr,OVmSuf8tpd
ZSJVq5XDrRot,yTMWeCgUROcvtsblfK85L62xPk,AAgpHN0nMZ=m6b7CoBk4EQ,aFQoGfmYKyqLU6X8libw9k3ncW5,eeIL1TfgFQJaKqVD8hGNPEZ
XogUJZEijT7KWbxeO6,FhcnOB9t3frzvXb,aVLSn1xw5cK=AAgpHN0nMZ,yTMWeCgUROcvtsblfK85L62xPk,ZSJVq5XDrRot
ffCSGrTJYPsxgVQWKLtHU3iMwB,EDPaWgMt1SwNn8o,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg=aVLSn1xw5cK,FhcnOB9t3frzvXb,XogUJZEijT7KWbxeO6
Ej67fFyoqW8kbV2HdSK,kmdSKeBIwViM9t3,fR68jBGWCzUsFXdlTKPOScugm=PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg,EDPaWgMt1SwNn8o,ffCSGrTJYPsxgVQWKLtHU3iMwB
bdhQDyjm3nPwToFHkprvCzBLUGR,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r,wwyUWMFAsO=fR68jBGWCzUsFXdlTKPOScugm,kmdSKeBIwViM9t3,Ej67fFyoqW8kbV2HdSK
kRYWcNuAazr4jtmBoxFVS19Z6,pEo8g7riWVL014KaRtzQ,sArCMRngQNmXkBoKv=wwyUWMFAsO,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r,bdhQDyjm3nPwToFHkprvCzBLUGR
JMLhEyaBWmskovGHTrVCxQ08,MM2BQ7xrAfNivgenXPytGYOs0DEHRC,hjNP5w9srJz2QpVISxBfndbD4CkXvl=sArCMRngQNmXkBoKv,pEo8g7riWVL014KaRtzQ,kRYWcNuAazr4jtmBoxFVS19Z6
xuYvdJpOEyQKTLNwb,jYaM5vilgZdFx6QHbApwVXO8et,DLSVmlyBbCK=hjNP5w9srJz2QpVISxBfndbD4CkXvl,MM2BQ7xrAfNivgenXPytGYOs0DEHRC,JMLhEyaBWmskovGHTrVCxQ08
gnfv8UtZ3daGqpjzk,gSmqZU0plur2xKPJwQA,c4QSTnPiWUCjhrLlwGB=DLSVmlyBbCK,jYaM5vilgZdFx6QHbApwVXO8et,xuYvdJpOEyQKTLNwb
import xbmc as cPwDBuG4HVTCdQ9JmMeoWjNY2hX,re as ZXFs0mEPR8qI2zj,sys as ddABnr3K9Xv8e71CzcN0Pxt,xbmcaddon as A2AXwrPWdJ3V4958K,random as bnPo1W52UVMRs7Lw6kfG9QdO,os as hhHq8m5vauKG9dl,xbmcvfs as OkWUaJXTZf,time as luMHeSgCBaPrb9KvUjNFqcR,pickle as BDzGhMLecC,zlib as KKTylHUNgwka5pr1tuWSBPDEA,xbmcgui as kGEPsyxKnHDJ,xbmcplugin as pZrEWcFVmiNCjozM,sqlite3 as esvtXhdikb2GDJm5Arc,traceback as QQV1pDhCLqHP5a3sGvoUrJfmjXFw,threading as c3cgVjNv1rde
ll6f2wvU4FdqL3MJyDxORESCK197i = FhcnOB9t3frzvXb(u"ࠫࡑࡏࡂࡔࡑࡑࡉࠬਰ")
J5keFiyQtf9bGZ0vulzNIsTYMx1oR = A2AXwrPWdJ3V4958K.Addon().getAddonInfo(xuYvdJpOEyQKTLNwb(u"ࠬࡶࡡࡵࡪࠪ਱"))
YIMCkRZyLWhi5 = hhHq8m5vauKG9dl.path.join(J5keFiyQtf9bGZ0vulzNIsTYMx1oR,aVLSn1xw5cK(u"࠭ࡰࡢࡥ࡮ࡥ࡬࡫ࡳࠨਲ"))
ddABnr3K9Xv8e71CzcN0Pxt.path.append(YIMCkRZyLWhi5)
RDroKU08JGFn53dsguECSkYTW1 = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.getInfoLabel(pEo8g7riWVL014KaRtzQ(u"ࠢࡔࡻࡶࡸࡪࡳ࠮ࡃࡷ࡬ࡰࡩ࡜ࡥࡳࡵ࡬ࡳࡳࠨਲ਼"))
V8US2yZAg0QXJebWIHKD5xFa = ZXFs0mEPR8qI2zj.findall(FhcnOB9t3frzvXb(u"ࠨࠪ࡟ࡨࡡࡪ࡜࠯࡞ࡧ࠭ࠬ਴"),RDroKU08JGFn53dsguECSkYTW1,ZXFs0mEPR8qI2zj.DOTALL)
V8US2yZAg0QXJebWIHKD5xFa = float(V8US2yZAg0QXJebWIHKD5xFa[LmcNhzY6fQPd2JyCGslkSr(u"࠰ఏ")])
thQbNvliCsycGE6Rw8jLVom1 = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.Player
ulKB5wvME2o = kGEPsyxKnHDJ.WindowXMLDialog
Yd6t3PjlLKk = V8US2yZAg0QXJebWIHKD5xFa<ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠲࠻ఐ")
VYMZsxRpcQHPgkaiDKjyoh = V8US2yZAg0QXJebWIHKD5xFa>gSmqZU0plur2xKPJwQA(u"࠳࠻࠲࠾࠿఑")
if VYMZsxRpcQHPgkaiDKjyoh:
	NNTx9MFlkze0nBsL4XRD7J3K = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.LOGINFO
	llDwesm6h4YkuLBCKQE8W0JIORoFS,PGLUYu7ySB5gD8b4ZJQq = XogUJZEijT7KWbxeO6(u"ࡷࠪࡠࡺ࠸࠰࠳ࡣࠪਵ"),aVLSn1xw5cK(u"ࡸࠫࡡࡻ࠲࠱࠴ࡥࠫਸ਼")
	L8nGBZgOsiIDb = OkWUaJXTZf.translatePath(J3OCAmZVcn(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡵࡧࡰࡴࠬ਷"))
	from urllib.parse import unquote as _Lv3ukB4eP5ndHfN0RwrhtQYG
else:
	NNTx9MFlkze0nBsL4XRD7J3K = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.LOGNOTICE
	llDwesm6h4YkuLBCKQE8W0JIORoFS,PGLUYu7ySB5gD8b4ZJQq = JMLhEyaBWmskovGHTrVCxQ08(u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡦ࠭ਸ").encode(fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࡵࡵࡨ࠻ࠫਹ")),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡢࠨ਺").encode(EDPaWgMt1SwNn8o(u"ࠨࡷࡷࡪ࠽࠭਻"))
	L8nGBZgOsiIDb = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.translatePath(JMLhEyaBWmskovGHTrVCxQ08(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡺࡥ࡮ࡲ਼ࠪ"))
	from urllib import unquote as _Lv3ukB4eP5ndHfN0RwrhtQYG
zepFKvZ0wuOrsAMGXt7LmkYV3U = ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠹࠴ఒ")
sGOne0xWA5 = JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠺࠵ఓ")*zepFKvZ0wuOrsAMGXt7LmkYV3U
VdKjgpMNTkxOytEBo286 = m6b7CoBk4EQ(u"࠷࠺ఔ")*sGOne0xWA5
RRazVJcSOCeUKQFsNgwoY0LE6xvkh5 = DLSVmlyBbCK(u"࠹࠰క")*VdKjgpMNTkxOytEBo286
KxirmCLT6Gw = jYaM5vilgZdFx6QHbApwVXO8et(u"࠰ఖ")
RwhaLmQ4cpyvfxsPUJVA0DtM = eeIL1TfgFQJaKqVD8hGNPEZ(u"࠴࠲గ")*zepFKvZ0wuOrsAMGXt7LmkYV3U
dALVaOWB4jKN3Tbt0Cm1ns9k5u = m6b7CoBk4EQ(u"࠴ఘ")*sGOne0xWA5
Z7uFdWIRv9ybj0 = LmcNhzY6fQPd2JyCGslkSr(u"࠴࠺ఙ")*sGOne0xWA5
JNsoWV1CXc4xy = bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠷చ")*VdKjgpMNTkxOytEBo286
tteHTjUArw = yTMWeCgUROcvtsblfK85L62xPk(u"࠸࠶ఛ")*VdKjgpMNTkxOytEBo286
iKYM8NdkGHmBcr = ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠷࠲జ")*RRazVJcSOCeUKQFsNgwoY0LE6xvkh5
ii5ULJKfcyuVn = bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠱ఝ")*sGOne0xWA5
ZK5gkAtjrCeEXYGD2bRQHOF3Moyc = ddABnr3K9Xv8e71CzcN0Pxt.argv[kmdSKeBIwViM9t3(u"࠱ఞ")].split(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠪ࠳ࠬ਽"))[c4QSTnPiWUCjhrLlwGB(u"࠴ట")]
jVGRimgPZeu9l0dsUoHJ1a = int(ddABnr3K9Xv8e71CzcN0Pxt.argv[Ej67fFyoqW8kbV2HdSK(u"࠴ఠ")])
VPIEsaiROZwmp20Jdn8WrA7c3Y = ddABnr3K9Xv8e71CzcN0Pxt.argv[xuYvdJpOEyQKTLNwb(u"࠶డ")]
bBTJDwrXQNk = ZK5gkAtjrCeEXYGD2bRQHOF3Moyc.split(aVLSn1xw5cK(u"ࠫ࠳࠭ਾ"))[gSmqZU0plur2xKPJwQA(u"࠷ఢ")]
i69DxzEZSwmuY5Il = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.getInfoLabel(kmdSKeBIwViM9t3(u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡇࡤࡥࡱࡱ࡚ࡪࡸࡳࡪࡱࡱࠬࠬਿ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭ࠩࠨੀ"))
mATvU6VbxOXNFhz8lK5WGrfQ = hhHq8m5vauKG9dl.path.join(L8nGBZgOsiIDb,ZK5gkAtjrCeEXYGD2bRQHOF3Moyc)
hosgCj2byWvuVT = hhHq8m5vauKG9dl.path.join(mATvU6VbxOXNFhz8lK5WGrfQ,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠧ࡮ࡣ࡬ࡲࡩࡧࡴࡢ࠰ࡧࡦࠬੁ"))
ryc0LEzgSbaI7NqvwJ = hhHq8m5vauKG9dl.path.join(mATvU6VbxOXNFhz8lK5WGrfQ,JMLhEyaBWmskovGHTrVCxQ08(u"ࠨ࡮ࡤࡷࡹࡼࡩࡥࡧࡲࡷ࠳ࡪࡡࡵࠩੂ"))
F5I1VZzxkXenKuEAYO = int(luMHeSgCBaPrb9KvUjNFqcR.time())
j2agIU0xsLS6c7T = A2AXwrPWdJ3V4958K.Addon(id=ZK5gkAtjrCeEXYGD2bRQHOF3Moyc)
aMFIi4RQklcU6 = j2agIU0xsLS6c7T.getSetting(yTMWeCgUROcvtsblfK85L62xPk(u"ࠩࡤࡺ࠳ࡼࡥࡳࡵ࡬ࡳࡳ࠭੃"))
nc1u5UZAtX2WNO4aJMmbg = JMLhEyaBWmskovGHTrVCxQ08(u"ࡇࡣ࡯ࡷࡪ౹") if aMFIi4RQklcU6==i69DxzEZSwmuY5Il else jYaM5vilgZdFx6QHbApwVXO8et(u"ࡔࡳࡷࡨ౸")
def hGMVvHBuPC014(XpOsU3v5dqH8MQAK6FcafmP1z0kL2,cxvUhw6qRTP4oMJ3AzZ=AAgpHN0nMZ(u"ࠪࡃࠬ੄")):
	if J3OCAmZVcn(u"ࠫࡂ࠭੅") in XpOsU3v5dqH8MQAK6FcafmP1z0kL2:
		if cxvUhw6qRTP4oMJ3AzZ in XpOsU3v5dqH8MQAK6FcafmP1z0kL2: lQHXdV9Nzf6BLqS8D,mmrsj0WHleRYOI = XpOsU3v5dqH8MQAK6FcafmP1z0kL2.split(cxvUhw6qRTP4oMJ3AzZ,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠷ణ"))
		else: lQHXdV9Nzf6BLqS8D,mmrsj0WHleRYOI = fR68jBGWCzUsFXdlTKPOScugm(u"ࠬ࠭੆"),XpOsU3v5dqH8MQAK6FcafmP1z0kL2
		mmrsj0WHleRYOI = mmrsj0WHleRYOI.split(gnfv8UtZ3daGqpjzk(u"࠭ࠦࠨੇ"))
		BTMputsaqV = {}
		for TCd2DbQ4zsF8rtqHgak9KR03cohxUl in mmrsj0WHleRYOI:
			qWMXl6rZ1seT2NBhn,A6zIXayOqBNEgorvnD7dwUspk = TCd2DbQ4zsF8rtqHgak9KR03cohxUl.split(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠧ࠾ࠩੈ"),kmdSKeBIwViM9t3(u"࠱త"))
			BTMputsaqV[qWMXl6rZ1seT2NBhn] = A6zIXayOqBNEgorvnD7dwUspk
	else: lQHXdV9Nzf6BLqS8D,BTMputsaqV = XpOsU3v5dqH8MQAK6FcafmP1z0kL2,{}
	return lQHXdV9Nzf6BLqS8D,BTMputsaqV
def NiOkerpvwHXxLGR1Yy9um(vABVTz0qOd1anSJ3D):
	jiNFXA1x8MWw,ji1dGuYnsFNKe,nSpH6ktoa78sJb3gjBQl1imFD = AAgpHN0nMZ(u"ࠨࠩ੉"),Ej67fFyoqW8kbV2HdSK(u"ࠩࠪ੊"),EDPaWgMt1SwNn8o(u"ࠪࠫੋ")
	vABVTz0qOd1anSJ3D = vABVTz0qOd1anSJ3D.replace(llDwesm6h4YkuLBCKQE8W0JIORoFS,jYaM5vilgZdFx6QHbApwVXO8et(u"ࠫࠬੌ")).replace(PGLUYu7ySB5gD8b4ZJQq,c4QSTnPiWUCjhrLlwGB(u"੍ࠬ࠭"))
	p3pw6HeVfqXcFnT = ZXFs0mEPR8qI2zj.findall(c4QSTnPiWUCjhrLlwGB(u"࠭ࠨ࠯ࠫ࡟࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡡࡣࠨ࡝ࡹ࡟ࡻࡡࡽࠩࠡ࠭࡟࡟ࡡ࠵ࡃࡐࡎࡒࡖࡡࡣࠨ࠯ࠬࡂ࠭ࠩ࠭੎"),vABVTz0qOd1anSJ3D,ZXFs0mEPR8qI2zj.DOTALL)
	if p3pw6HeVfqXcFnT: jiNFXA1x8MWw,ji1dGuYnsFNKe,vABVTz0qOd1anSJ3D = p3pw6HeVfqXcFnT[ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠱థ")]
	if jiNFXA1x8MWw not in [ZSJVq5XDrRot(u"ࠧࠡࠩ੏"),aVLSn1xw5cK(u"ࠨ࠮ࠪ੐"),OVmSuf8tpd(u"ࠩࠪੑ")]: nSpH6ktoa78sJb3gjBQl1imFD = kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪࡣࡒࡕࡄࡠࠩ੒")
	if ji1dGuYnsFNKe: ji1dGuYnsFNKe = JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࡤ࠭੓")+ji1dGuYnsFNKe+EDPaWgMt1SwNn8o(u"ࠬࡥࠧ੔")
	vABVTz0qOd1anSJ3D = ji1dGuYnsFNKe+nSpH6ktoa78sJb3gjBQl1imFD+vABVTz0qOd1anSJ3D
	return vABVTz0qOd1anSJ3D
def ejBOu2WXwvb4YpITdsLF16(XpOsU3v5dqH8MQAK6FcafmP1z0kL2):
	return _Lv3ukB4eP5ndHfN0RwrhtQYG(XpOsU3v5dqH8MQAK6FcafmP1z0kL2)
def q0tgURwzEOJIYc27DbG4aT(V2bKEUko7XTtGeOzBYPWM):
	Y54IkPljObHyqcdxMhWnZ2Fg1B = {AAgpHN0nMZ(u"࠭ࡴࡺࡲࡨࠫ੕"):kmdSKeBIwViM9t3(u"ࠧࠨ੖"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨ࡯ࡲࡨࡪ࠭੗"):fR68jBGWCzUsFXdlTKPOScugm(u"ࠩࠪ੘"),OVmSuf8tpd(u"ࠪࡹࡷࡲࠧਖ਼"):m6b7CoBk4EQ(u"ࠫࠬਗ਼"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬࡺࡥࡹࡶࠪਜ਼"):J3OCAmZVcn(u"࠭ࠧੜ"),c4QSTnPiWUCjhrLlwGB(u"ࠧࡱࡣࡪࡩࠬ੝"):gSmqZU0plur2xKPJwQA(u"ࠨࠩਫ਼"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࡱࡥࡲ࡫ࠧ੟"):EDPaWgMt1SwNn8o(u"ࠪࠫ੠"),gSmqZU0plur2xKPJwQA(u"ࠫ࡮ࡳࡡࡨࡧࠪ੡"):MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠬ࠭੢"),FhcnOB9t3frzvXb(u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ੣"):xuYvdJpOEyQKTLNwb(u"ࠧࠨ੤"),Ej67fFyoqW8kbV2HdSK(u"ࠨ࡫ࡱࡪࡴࡪࡩࡤࡶࠪ੥"):OVmSuf8tpd(u"ࠩࠪ੦")}
	if ZSJVq5XDrRot(u"ࠪࡃࠬ੧") in V2bKEUko7XTtGeOzBYPWM: V2bKEUko7XTtGeOzBYPWM = V2bKEUko7XTtGeOzBYPWM.split(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫࡄ࠭੨"),xuYvdJpOEyQKTLNwb(u"࠳ద"))[xuYvdJpOEyQKTLNwb(u"࠳ద")]
	lQHXdV9Nzf6BLqS8D,EGFjU0K9N3bPVicp = hGMVvHBuPC014(V2bKEUko7XTtGeOzBYPWM)
	aargs = dict(list(Y54IkPljObHyqcdxMhWnZ2Fg1B.items())+list(EGFjU0K9N3bPVicp.items()))
	uMlyLGznmKW0ej3bdUX7piF2h9IP8g = aargs[aVLSn1xw5cK(u"ࠬࡳ࡯ࡥࡧࠪ੩")]
	exjaDckuA9M = ejBOu2WXwvb4YpITdsLF16(aargs[kmdSKeBIwViM9t3(u"࠭ࡵࡳ࡮ࠪ੪")])
	U2NbDeiFrw1T7cz9qmEO = ejBOu2WXwvb4YpITdsLF16(aargs[fR68jBGWCzUsFXdlTKPOScugm(u"ࠧࡵࡧࡻࡸࠬ੫")])
	EExKW3DenGU8b = ejBOu2WXwvb4YpITdsLF16(aargs[JMLhEyaBWmskovGHTrVCxQ08(u"ࠨࡲࡤ࡫ࡪ࠭੬")])
	IgNryh38O4iuY9ZQd = ejBOu2WXwvb4YpITdsLF16(aargs[ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠩࡷࡽࡵ࡫ࠧ੭")])
	qDBsizKL2w = ejBOu2WXwvb4YpITdsLF16(aargs[J3OCAmZVcn(u"ࠪࡲࡦࡳࡥࠨ੮")])
	C3CUrDxjTcfdEQ8B = ejBOu2WXwvb4YpITdsLF16(aargs[m6b7CoBk4EQ(u"ࠫ࡮ࡳࡡࡨࡧࠪ੯")])
	ga0MNsKDV9mAiJvwCx8HB = aargs[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭ੰ")]
	hCf5knZr2i9MmNGyb1Su3zAvlEYq = ejBOu2WXwvb4YpITdsLF16(aargs[hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭ࡩ࡯ࡨࡲࡨ࡮ࡩࡴࠨੱ")])
	if hCf5knZr2i9MmNGyb1Su3zAvlEYq: hCf5knZr2i9MmNGyb1Su3zAvlEYq = eval(hCf5knZr2i9MmNGyb1Su3zAvlEYq)
	else: hCf5knZr2i9MmNGyb1Su3zAvlEYq = {}
	if not uMlyLGznmKW0ej3bdUX7piF2h9IP8g: IgNryh38O4iuY9ZQd = aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧੲ") ; uMlyLGznmKW0ej3bdUX7piF2h9IP8g = pEo8g7riWVL014KaRtzQ(u"ࠨ࠴࠹࠴ࠬੳ")
	return IgNryh38O4iuY9ZQd,qDBsizKL2w,exjaDckuA9M,uMlyLGznmKW0ej3bdUX7piF2h9IP8g,C3CUrDxjTcfdEQ8B,EExKW3DenGU8b,U2NbDeiFrw1T7cz9qmEO,ga0MNsKDV9mAiJvwCx8HB,hCf5knZr2i9MmNGyb1Su3zAvlEYq
def RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i):
	XxpUhvwZ0CFPrJAuHq5jDdNT = ddABnr3K9Xv8e71CzcN0Pxt._getframe(DLSVmlyBbCK(u"࠴ధ")).f_code.co_name
	if not ll6f2wvU4FdqL3MJyDxORESCK197i or not XxpUhvwZ0CFPrJAuHq5jDdNT or XxpUhvwZ0CFPrJAuHq5jDdNT==MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩ࠿ࡱࡴࡪࡵ࡭ࡧࡁࠫੴ"):
		return kmdSKeBIwViM9t3(u"ࠪ࡟ࠥ࠭ੵ")+bBTJDwrXQNk.upper()+hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫ࠲࠭੶")+i69DxzEZSwmuY5Il+ZSJVq5XDrRot(u"ࠬ࠳ࠧ੷")+str(V8US2yZAg0QXJebWIHKD5xFa)+c4QSTnPiWUCjhrLlwGB(u"࠭ࠠ࡞ࠩ੸")
	return AAgpHN0nMZ(u"ࠧ࠯ࠢࠣࠫ੹")+XxpUhvwZ0CFPrJAuHq5jDdNT
def tr24ZoudmqvxfYCw(tyC2JZLuRnmvK,d0Z7abLoEfmpHTOkgVG):
	if Yd6t3PjlLKk: d0Z7abLoEfmpHTOkgVG = d0Z7abLoEfmpHTOkgVG.decode(EDPaWgMt1SwNn8o(u"ࠨࡷࡷࡪ࠽࠭੺")).encode(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࡸࡸ࡫࠾ࠧ੻"))
	LcygesvKjS4175uUDaPbNIV9wdn = NNTx9MFlkze0nBsL4XRD7J3K
	YYyAscnV8LouaiJz = [wwyUWMFAsO(u"ࠪࠫ੼"),XogUJZEijT7KWbxeO6(u"ࠫࠬ੽")]
	if tyC2JZLuRnmvK: d0Z7abLoEfmpHTOkgVG = d0Z7abLoEfmpHTOkgVG.replace(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ੾"),yTMWeCgUROcvtsblfK85L62xPk(u"࠭ࠧ੿")).replace(LmcNhzY6fQPd2JyCGslkSr(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ઀"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨࠩઁ")).replace(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫં"),aVLSn1xw5cK(u"ࠪࠫઃ"))
	else: tyC2JZLuRnmvK = JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࡓࡕࡔࡊࡅࡈࠫ઄")
	PMWuXfH0bUGcz7,cxvUhw6qRTP4oMJ3AzZ,KP0YBtJjwMe3ndSO8qCR2 = Ej67fFyoqW8kbV2HdSK(u"ࠬࠦࠠࠡࠢࠪઅ"),gSmqZU0plur2xKPJwQA(u"࠭ࠠࠡࠢࠪઆ"),XogUJZEijT7KWbxeO6(u"ࠧࠨઇ")
	if eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨࡇࡕࡖࡔࡘࠧઈ") in tyC2JZLuRnmvK: LcygesvKjS4175uUDaPbNIV9wdn = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.LOGERROR
	if tyC2JZLuRnmvK==JMLhEyaBWmskovGHTrVCxQ08(u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧઉ"):
		d0Z7abLoEfmpHTOkgVG = d0Z7abLoEfmpHTOkgVG+cxvUhw6qRTP4oMJ3AzZ
		YYyAscnV8LouaiJz = d0Z7abLoEfmpHTOkgVG.split(cxvUhw6qRTP4oMJ3AzZ)
		KP0YBtJjwMe3ndSO8qCR2 = PMWuXfH0bUGcz7
	elif tyC2JZLuRnmvK==yTMWeCgUROcvtsblfK85L62xPk(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩઊ"):
		d0Z7abLoEfmpHTOkgVG = d0Z7abLoEfmpHTOkgVG.replace(fR68jBGWCzUsFXdlTKPOScugm(u"ࠫ࠳࠭ઋ")+cxvUhw6qRTP4oMJ3AzZ,DLSVmlyBbCK(u"ࠬ࠴ࠠࠡࠩઌ"))
		YYyAscnV8LouaiJz = d0Z7abLoEfmpHTOkgVG.split(cxvUhw6qRTP4oMJ3AzZ)
		YYyAscnV8LouaiJz[bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠵఩")] = JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭࠮ࠨઍ")+YYyAscnV8LouaiJz[bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠵఩")][Ej67fFyoqW8kbV2HdSK(u"࠵న"):]
		KP0YBtJjwMe3ndSO8qCR2 = PMWuXfH0bUGcz7+cxvUhw6qRTP4oMJ3AzZ
	elif tyC2JZLuRnmvK in [eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧࡏࡑࡗࡍࡈࡋࠧ઎"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨࡇࡕࡖࡔࡘࠧએ")]: YYyAscnV8LouaiJz = d0Z7abLoEfmpHTOkgVG.split(PMWuXfH0bUGcz7)
	KP0YBtJjwMe3ndSO8qCR2 += xuYvdJpOEyQKTLNwb(u"࠼ప")*PMWuXfH0bUGcz7
	GmH2OPQlo9LdtXYsJ70avW = ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠳ఫ")*PMWuXfH0bUGcz7
	if V8US2yZAg0QXJebWIHKD5xFa>eeIL1TfgFQJaKqVD8hGNPEZ(u"࠳࠺࠲࠾࠿భ"): KP0YBtJjwMe3ndSO8qCR2 += PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠲࠳బ")*gSmqZU0plur2xKPJwQA(u"ࠩࠣࠫઐ")
	nw9lLJrDZTQoN6VAXWyPGa = YYyAscnV8LouaiJz[sArCMRngQNmXkBoKv(u"࠳మ")]
	for fl6EYgtdJCZOcNaLpnUrDHQ in YYyAscnV8LouaiJz[gnfv8UtZ3daGqpjzk(u"࠵య"):]:
		if FhcnOB9t3frzvXb(u"ࠪࡠࡳ࠭ઑ") in fl6EYgtdJCZOcNaLpnUrDHQ: fl6EYgtdJCZOcNaLpnUrDHQ = fl6EYgtdJCZOcNaLpnUrDHQ.replace(AAgpHN0nMZ(u"ࠫࡡࡴࠧ઒"),ZSJVq5XDrRot(u"ࠬࡢ࡮ࠨઓ")+PMWuXfH0bUGcz7+PMWuXfH0bUGcz7)
		GmH2OPQlo9LdtXYsJ70avW += PMWuXfH0bUGcz7
		nw9lLJrDZTQoN6VAXWyPGa += DLSVmlyBbCK(u"࠭࡜ࡳࠩઔ")+KP0YBtJjwMe3ndSO8qCR2+GmH2OPQlo9LdtXYsJ70avW+fl6EYgtdJCZOcNaLpnUrDHQ
	nw9lLJrDZTQoN6VAXWyPGa += aVLSn1xw5cK(u"ࠧࠡࡡࠪક")
	if OVmSuf8tpd(u"ࠨࠧࠪખ") in nw9lLJrDZTQoN6VAXWyPGa: nw9lLJrDZTQoN6VAXWyPGa = ejBOu2WXwvb4YpITdsLF16(nw9lLJrDZTQoN6VAXWyPGa)
	cPwDBuG4HVTCdQ9JmMeoWjNY2hX.log(nw9lLJrDZTQoN6VAXWyPGa,level=LcygesvKjS4175uUDaPbNIV9wdn)
	return
def xocasQYVZLF5(tP325FYWofVAzLGEuSQN6ZHk1dIq):
	m5h4wdsHCKLvPu9V6rEFi2q = esvtXhdikb2GDJm5Arc.connect(tP325FYWofVAzLGEuSQN6ZHk1dIq)
	nRseEAQwXo4jC21gmqPzIihfUc = m5h4wdsHCKLvPu9V6rEFi2q.cursor()
	nRseEAQwXo4jC21gmqPzIihfUc.execute(yTMWeCgUROcvtsblfK85L62xPk(u"ࠩࡓࡖࡆࡍࡍࡂࠢࡤࡹࡹࡵ࡭ࡢࡶ࡬ࡧࡤ࡯࡮ࡥࡧࡻࡁࡳࡵ࠻ࠨગ"))
	nRseEAQwXo4jC21gmqPzIihfUc.execute(FhcnOB9t3frzvXb(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡪࡴࡸࡥࡪࡩࡱࡣࡰ࡫ࡹࡴ࠿ࡱࡳࡀ࠭ઘ"))
	nRseEAQwXo4jC21gmqPzIihfUc.execute(m6b7CoBk4EQ(u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡮࡭࡮ࡰࡴࡨࡣࡨ࡮ࡥࡤ࡭ࡢࡧࡴࡴࡳࡵࡴࡤ࡭ࡳࡺࡳ࠾ࡻࡨࡷࡀ࠭ઙ"))
	nRseEAQwXo4jC21gmqPzIihfUc.execute(pEo8g7riWVL014KaRtzQ(u"ࠬࡖࡒࡂࡉࡐࡅࠥࡰ࡯ࡶࡴࡱࡥࡱࡥ࡭ࡰࡦࡨࡁࡔࡌࡆ࠼ࠩચ"))
	nRseEAQwXo4jC21gmqPzIihfUc.execute(XogUJZEijT7KWbxeO6(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡴࡦ࡯ࡳࡣࡸࡺ࡯ࡳࡧࡀࡑࡊࡓࡏࡓ࡛࠾ࠫછ"))
	nRseEAQwXo4jC21gmqPzIihfUc.execute(pEo8g7riWVL014KaRtzQ(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡴࡻࡱࡧ࡭ࡸ࡯࡯ࡱࡸࡷࡂࡕࡆࡇ࠽ࠪજ"))
	m5h4wdsHCKLvPu9V6rEFi2q.text_factory = str
	return m5h4wdsHCKLvPu9V6rEFi2q,nRseEAQwXo4jC21gmqPzIihfUc
def ibdKZ0sMlyrDcaJgPFV(tP325FYWofVAzLGEuSQN6ZHk1dIq,It0pgDyrsGJeX6O84KWVN7Za,kFhHbDMUyN9vBz=None):
	try: m5h4wdsHCKLvPu9V6rEFi2q,nRseEAQwXo4jC21gmqPzIihfUc = xocasQYVZLF5(tP325FYWofVAzLGEuSQN6ZHk1dIq)
	except: return
	if kFhHbDMUyN9vBz==None: nRseEAQwXo4jC21gmqPzIihfUc.execute(wwyUWMFAsO(u"ࠨࡆࡕࡓࡕࠦࡔࡂࡄࡏࡉࠥࡏࡆࠡࡇ࡛ࡍࡘ࡚ࡓࠡࠤࠪઝ")+It0pgDyrsGJeX6O84KWVN7Za+Ej67fFyoqW8kbV2HdSK(u"ࠩࠥࠤࡀ࠭ઞ"))
	else:
		eEgyDQbFcBRTu6riAtxnl1 = (str(kFhHbDMUyN9vBz),)
		try:
			if wwyUWMFAsO(u"ࠪࠩࠬટ") in kFhHbDMUyN9vBz: nRseEAQwXo4jC21gmqPzIihfUc.execute(EDPaWgMt1SwNn8o(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫઠ")+It0pgDyrsGJeX6O84KWVN7Za+c4QSTnPiWUCjhrLlwGB(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࡬ࡪ࡭ࡨࠤࡄࠦ࠻ࠨડ"),eEgyDQbFcBRTu6riAtxnl1)
			else: nRseEAQwXo4jC21gmqPzIihfUc.execute(FhcnOB9t3frzvXb(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭ઢ")+It0pgDyrsGJeX6O84KWVN7Za+yTMWeCgUROcvtsblfK85L62xPk(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧણ"),eEgyDQbFcBRTu6riAtxnl1)
		except: pass
	m5h4wdsHCKLvPu9V6rEFi2q.commit()
	m5h4wdsHCKLvPu9V6rEFi2q.close()
	return
class LZzsUMNKwoxkn1a(): pass
class o0o6fpDwEd5BMY(LZzsUMNKwoxkn1a):
	def __init__(Oxpg4wUz3fYLkVRu):
		Oxpg4wUz3fYLkVRu.url = wwyUWMFAsO(u"ࠨࠩત")
		Oxpg4wUz3fYLkVRu.code = -OVmSuf8tpd(u"࠾࠿ర")
		Oxpg4wUz3fYLkVRu.reason = ZSJVq5XDrRot(u"ࠩࠪથ")
		Oxpg4wUz3fYLkVRu.content = ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠪࠫદ")
		Oxpg4wUz3fYLkVRu.headers = {}
		Oxpg4wUz3fYLkVRu.cookies = {}
		Oxpg4wUz3fYLkVRu.succeeded = jYaM5vilgZdFx6QHbApwVXO8et(u"ࡈࡤࡰࡸ࡫౺")
def xvPYSiDMwZ3EHs9b75XhqBGeK8(m6egkRrjcavHEdwYDSOs):
	if m6egkRrjcavHEdwYDSOs==yTMWeCgUROcvtsblfK85L62xPk(u"ࠫࡩ࡯ࡣࡵࠩધ"): SOlDApJEx73FokmVdYCfKuRNXy8 = {}
	elif m6egkRrjcavHEdwYDSOs==MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠬࡲࡩࡴࡶࠪન"): SOlDApJEx73FokmVdYCfKuRNXy8 = []
	elif m6egkRrjcavHEdwYDSOs==ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭ࡳࡵࡴࠪ઩"): SOlDApJEx73FokmVdYCfKuRNXy8 = OVmSuf8tpd(u"ࠧࠨપ")
	elif m6egkRrjcavHEdwYDSOs==aVLSn1xw5cK(u"ࠨ࡫ࡱࡸࠬફ"): SOlDApJEx73FokmVdYCfKuRNXy8 = OVmSuf8tpd(u"࠶ఱ")
	elif m6egkRrjcavHEdwYDSOs==PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫબ"): SOlDApJEx73FokmVdYCfKuRNXy8 = o0o6fpDwEd5BMY()
	elif not m6egkRrjcavHEdwYDSOs: SOlDApJEx73FokmVdYCfKuRNXy8 = None
	else: SOlDApJEx73FokmVdYCfKuRNXy8 = None
	return SOlDApJEx73FokmVdYCfKuRNXy8
def ynO4oHRV3Mj6Z9gNh(o7NYzci8HDMmCT1f):
	from hashlib import md5 as ppq7nbP8zdkSt20aCVK3rY9
	u2LKkgECmceZs = j2agIU0xsLS6c7T.getSetting(AAgpHN0nMZ(u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷ࠶࠭ભ"))
	B4tpFcjqKw = HHWAnGJrb9powOqTkYgcPQ6Ef(JMLhEyaBWmskovGHTrVCxQ08(u"࠳࠳ల")).splitlines()
	GhEjJRSBZ4mXcCgUKsn = gnfv8UtZ3daGqpjzk(u"࠱ళ")
	for RhdQMXPxL0UuZl7sY in [F5I1VZzxkXenKuEAYO,F5I1VZzxkXenKuEAYO-dALVaOWB4jKN3Tbt0Cm1ns9k5u]:
		HZuDLTab3v21hK = str(RhdQMXPxL0UuZl7sY*m6b7CoBk4EQ(u"࠵࠵࠶࠰࠱࠲࠱࠴శ")/pEo8g7riWVL014KaRtzQ(u"࠷࠷࠷࠶࠰࠱వ"))[aVLSn1xw5cK(u"࠲ఴ"):fR68jBGWCzUsFXdlTKPOScugm(u"࠹ష")]
		if HZuDLTab3v21hK!=GhEjJRSBZ4mXcCgUKsn:
			for w8HZ5Joskl7z0 in B4tpFcjqKw:
				TEhbLZGIVKc8r = AAgpHN0nMZ(u"ࠫ࡝࠷࠹ࠨમ")+o7NYzci8HDMmCT1f+yTMWeCgUROcvtsblfK85L62xPk(u"ࠬ࠷࠸࠾ࠩય")+w8HZ5Joskl7z0[-gnfv8UtZ3daGqpjzk(u"࠸࠴స"):]+i69DxzEZSwmuY5Il+HZuDLTab3v21hK
				TEhbLZGIVKc8r = ppq7nbP8zdkSt20aCVK3rY9(TEhbLZGIVKc8r.encode(jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࡵࡵࡨ࠻ࠫર"))).hexdigest()[:MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠳࠳హ")]
				if TEhbLZGIVKc8r in u2LKkgECmceZs: return aVLSn1xw5cK(u"ࡗࡶࡺ࡫౻")
			GhEjJRSBZ4mXcCgUKsn = HZuDLTab3v21hK
	return wwyUWMFAsO(u"ࡊࡦࡲࡳࡦ౼")
def NUauTXxKLAoqQtJkglSFRWE(tP325FYWofVAzLGEuSQN6ZHk1dIq,sLhOM54GVH06aR1kSy2iBPfbItYo,It0pgDyrsGJeX6O84KWVN7Za,kFhHbDMUyN9vBz=None):
	SOlDApJEx73FokmVdYCfKuRNXy8 = xvPYSiDMwZ3EHs9b75XhqBGeK8(sLhOM54GVH06aR1kSy2iBPfbItYo)
	VkZ3taqEOKhCI6N = j2agIU0xsLS6c7T.getSetting(fR68jBGWCzUsFXdlTKPOScugm(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱࡬ࡹࡺࡰࡤࡣࡦ࡬ࡪ࠭઱"))
	if It0pgDyrsGJeX6O84KWVN7Za!=bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫલ") and tP325FYWofVAzLGEuSQN6ZHk1dIq==hosgCj2byWvuVT:
		if VkZ3taqEOKhCI6N==OVmSuf8tpd(u"ࠩࡖࡘࡔࡖࠧળ"): return SOlDApJEx73FokmVdYCfKuRNXy8
		nnF1VOMIkrqi2ojXux6UPHGyEf7Kg = j2agIU0xsLS6c7T.getSetting(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧ઴"))
		if nnF1VOMIkrqi2ojXux6UPHGyEf7Kg==kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫࡗࡋࡆࡓࡇࡖࡌࡊࡊࠧવ"):
			ibdKZ0sMlyrDcaJgPFV(tP325FYWofVAzLGEuSQN6ZHk1dIq,It0pgDyrsGJeX6O84KWVN7Za,kFhHbDMUyN9vBz)
			return SOlDApJEx73FokmVdYCfKuRNXy8
	sfcAYSHWErFhpPCTq5e = FhcnOB9t3frzvXb(u"࠱఺")
	if VkZ3taqEOKhCI6N==hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭શ"): sfcAYSHWErFhpPCTq5e = ii5ULJKfcyuVn
	try: m5h4wdsHCKLvPu9V6rEFi2q,nRseEAQwXo4jC21gmqPzIihfUc = xocasQYVZLF5(tP325FYWofVAzLGEuSQN6ZHk1dIq)
	except: return SOlDApJEx73FokmVdYCfKuRNXy8
	EZyqzChAJFX = FhcnOB9t3frzvXb(u"࡙ࡸࡵࡦ౽")
	try: nRseEAQwXo4jC21gmqPzIihfUc.execute(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࠪࠡࡈࡕࡓࡒࠦࠢࠨષ")+It0pgDyrsGJeX6O84KWVN7Za+J3OCAmZVcn(u"ࠧࠣࠢࡏࡍࡒࡏࡔࠡ࠳ࠣ࠿ࠬસ"))
	except: EZyqzChAJFX = fR68jBGWCzUsFXdlTKPOScugm(u"ࡌࡡ࡭ࡵࡨ౾")
	if EZyqzChAJFX:
		if sfcAYSHWErFhpPCTq5e: nRseEAQwXo4jC21gmqPzIihfUc.execute(pEo8g7riWVL014KaRtzQ(u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠢࠨહ")+It0pgDyrsGJeX6O84KWVN7Za+DLSVmlyBbCK(u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡩࡽࡶࡩࡳࡻࡁࠫ઺")+str(F5I1VZzxkXenKuEAYO+sfcAYSHWErFhpPCTq5e)+OVmSuf8tpd(u"ࠪࠤࡀ࠭઻"))
		m5h4wdsHCKLvPu9V6rEFi2q.commit()
		nRseEAQwXo4jC21gmqPzIihfUc.execute(LmcNhzY6fQPd2JyCGslkSr(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎ઼ࠢࠥࠫ")+It0pgDyrsGJeX6O84KWVN7Za+JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡥࡹࡲ࡬ࡶࡾࡂࠧઽ")+str(F5I1VZzxkXenKuEAYO)+ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭ࠠ࠼ࠩા"))
		m5h4wdsHCKLvPu9V6rEFi2q.commit()
		if kFhHbDMUyN9vBz:
			eEgyDQbFcBRTu6riAtxnl1 = (str(kFhHbDMUyN9vBz),)
			nRseEAQwXo4jC21gmqPzIihfUc.execute(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡥࡣࡷࡥࠥࡌࡒࡐࡏࠣࠦࠬિ")+It0pgDyrsGJeX6O84KWVN7Za+fR68jBGWCzUsFXdlTKPOScugm(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨી"),eEgyDQbFcBRTu6riAtxnl1)
			h72BryKAmUNjZwIqgvYtD = nRseEAQwXo4jC21gmqPzIihfUc.fetchall()
			if h72BryKAmUNjZwIqgvYtD:
				try:
					unjzvHfWpPTbqACy9RtOY6m = KKTylHUNgwka5pr1tuWSBPDEA.decompress(h72BryKAmUNjZwIqgvYtD[J3OCAmZVcn(u"࠲఻")][J3OCAmZVcn(u"࠲఻")])
					SOlDApJEx73FokmVdYCfKuRNXy8 = BDzGhMLecC.loads(unjzvHfWpPTbqACy9RtOY6m)
				except: pass
		else:
			nRseEAQwXo4jC21gmqPzIihfUc.execute(sArCMRngQNmXkBoKv(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡦࡳࡱࡻ࡭࡯࠮ࡧࡥࡹࡧࠠࡇࡔࡒࡑࠥࠨࠧુ")+It0pgDyrsGJeX6O84KWVN7Za+J3OCAmZVcn(u"ࠪࠦࠥࡁࠧૂ"))
			h72BryKAmUNjZwIqgvYtD = nRseEAQwXo4jC21gmqPzIihfUc.fetchall()
			if h72BryKAmUNjZwIqgvYtD:
				SOlDApJEx73FokmVdYCfKuRNXy8,WZhczGqsC2SUo4AOYTB0K = {},[]
				for nBc5xEODh7,BTMputsaqV in h72BryKAmUNjZwIqgvYtD:
					Qg3B18PfKv7kTZe = KKTylHUNgwka5pr1tuWSBPDEA.decompress(BTMputsaqV)
					BTMputsaqV = BDzGhMLecC.loads(Qg3B18PfKv7kTZe)
					SOlDApJEx73FokmVdYCfKuRNXy8[nBc5xEODh7] = BTMputsaqV
					WZhczGqsC2SUo4AOYTB0K.append(nBc5xEODh7)
				if WZhczGqsC2SUo4AOYTB0K:
					SOlDApJEx73FokmVdYCfKuRNXy8[XogUJZEijT7KWbxeO6(u"ࠫࡤࡥࡓࡆࡓࡘࡉࡓࡉࡅࡅࡡࡆࡓࡑ࡛ࡍࡏࡕࡢࡣࠬૃ")] = WZhczGqsC2SUo4AOYTB0K
					if sLhOM54GVH06aR1kSy2iBPfbItYo==DLSVmlyBbCK(u"ࠬࡲࡩࡴࡶࠪૄ"): SOlDApJEx73FokmVdYCfKuRNXy8 = WZhczGqsC2SUo4AOYTB0K
	m5h4wdsHCKLvPu9V6rEFi2q.close()
	return SOlDApJEx73FokmVdYCfKuRNXy8
class i4L2GE7hQ5M9(thQbNvliCsycGE6Rw8jLVom1):
	def __init__(Oxpg4wUz3fYLkVRu): pass
	def nNVDjqC23E8i9oeOkrZbBQ1S(Oxpg4wUz3fYLkVRu,w0TmsUtgR5F8LIjNAbfKua7d6QWZ):
		Oxpg4wUz3fYLkVRu.Va48fiIPqx7 = ynO4oHRV3Mj6Z9gNh(AAgpHN0nMZ(u"࠭ࡃࡕࡇ࠼ࡈࡘ࠷࠹ࡗࡗ࠳࡚ࡘ࡞ࠧૅ"))
		Oxpg4wUz3fYLkVRu.ATcfJiGm4ehdpPzYyoj28Kxr17H = ynO4oHRV3Mj6Z9gNh(m6b7CoBk4EQ(u"ࠧࡘࡕࡘࡖࡋ࡚࠱࠺ࡓࡗࡉࡋࡠࡘࠨ૆"))
		Oxpg4wUz3fYLkVRu.AFINKpwTE3hZLzMlOvD = ynO4oHRV3Mj6Z9gNh(OVmSuf8tpd(u"ࠨࡄࡗࡉࡽࡖࡖ࠲࠻ࡘࡖ࡛ࡔࡕࡔࡗ࠸ࡌ࡝࠭ે"))
		Oxpg4wUz3fYLkVRu.OBSvfy3cbl = J3OCAmZVcn(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠪૈ") if Oxpg4wUz3fYLkVRu.Va48fiIPqx7 else kmdSKeBIwViM9t3(u"ࠪࠫૉ")
		Oxpg4wUz3fYLkVRu.w0TmsUtgR5F8LIjNAbfKua7d6QWZ = w0TmsUtgR5F8LIjNAbfKua7d6QWZ
		if not Oxpg4wUz3fYLkVRu.ATcfJiGm4ehdpPzYyoj28Kxr17H:
			from j3x780FpaM import UAyxKVL2kthjd
			UAyxKVL2kthjd(RwhaLmQ4cpyvfxsPUJVA0DtM)
	def onPlayBackStopped(Oxpg4wUz3fYLkVRu): Oxpg4wUz3fYLkVRu.OBSvfy3cbl = gSmqZU0plur2xKPJwQA(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ૊")
	def onPlayBackError(Oxpg4wUz3fYLkVRu): Oxpg4wUz3fYLkVRu.OBSvfy3cbl = eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬો")
	def onPlayBackEnded(Oxpg4wUz3fYLkVRu): Oxpg4wUz3fYLkVRu.OBSvfy3cbl = aVLSn1xw5cK(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ૌ")
	def onPlayBackStarted(Oxpg4wUz3fYLkVRu):
		Oxpg4wUz3fYLkVRu.OBSvfy3cbl = gnfv8UtZ3daGqpjzk(u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࠨ્")
		nGmMgv9rxND18Z0qae3jPAd5Xl = c3cgVjNv1rde.Thread(target=Oxpg4wUz3fYLkVRu.L3A1qsTolYdtVEe7FfNHSIW,args=())
		nGmMgv9rxND18Z0qae3jPAd5Xl.start()
	def onAVStarted(Oxpg4wUz3fYLkVRu):
		if Oxpg4wUz3fYLkVRu.ATcfJiGm4ehdpPzYyoj28Kxr17H: Oxpg4wUz3fYLkVRu.OBSvfy3cbl = LmcNhzY6fQPd2JyCGslkSr(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ૎")
		else: Oxpg4wUz3fYLkVRu.OBSvfy3cbl = PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪ૏")
	def L3A1qsTolYdtVEe7FfNHSIW(Oxpg4wUz3fYLkVRu):
		from j3x780FpaM import LTOXNG9KQohp8lmbS0uw16VEJrjUk,KBeixSYCP1AhJvlN9p73LDaQzbw,jJSBRtqke9EU6waxvz7PDrg8ATnWm1
		jJSBRtqke9EU6waxvz7PDrg8ATnWm1(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࡷࡹࡵࡰࠨૐ"))
		QxElDcSyvp5qmIzf1au = PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠳఼")
		while not eval(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠫࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲࡮ࡹࡐ࡭ࡣࡼ࡭ࡳ࡭ࡖࡪࡦࡨࡳ࠭࠯ࠧ૑"),{LmcNhzY6fQPd2JyCGslkSr(u"ࠬࡾࡢ࡮ࡥࠪ૒"):cPwDBuG4HVTCdQ9JmMeoWjNY2hX}) and Oxpg4wUz3fYLkVRu.OBSvfy3cbl==FhcnOB9t3frzvXb(u"࠭ࡳࡵࡣࡵࡸࡪࡪࠧ૓"):
			cPwDBuG4HVTCdQ9JmMeoWjNY2hX.sleep(kRYWcNuAazr4jtmBoxFVS19Z6(u"࠵࠵࠶࠰ఽ"))
			QxElDcSyvp5qmIzf1au += J3OCAmZVcn(u"࠶ా")
			if QxElDcSyvp5qmIzf1au>m6b7CoBk4EQ(u"࠼࠰ి"): return
		if Oxpg4wUz3fYLkVRu.Va48fiIPqx7: Oxpg4wUz3fYLkVRu.OBSvfy3cbl = kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠨ૔")
		elif Oxpg4wUz3fYLkVRu.ATcfJiGm4ehdpPzYyoj28Kxr17H: Oxpg4wUz3fYLkVRu.OBSvfy3cbl = bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ૕")
		elif Oxpg4wUz3fYLkVRu.AFINKpwTE3hZLzMlOvD:
			Oxpg4wUz3fYLkVRu.OBSvfy3cbl = bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪ૖")
			kk2aqHMpo0mQTxBGFluRbj = c3cgVjNv1rde.Thread(target=LTOXNG9KQohp8lmbS0uw16VEJrjUk,args=(Oxpg4wUz3fYLkVRu.w0TmsUtgR5F8LIjNAbfKua7d6QWZ,))
			kk2aqHMpo0mQTxBGFluRbj.start()
			l2Q3KphWJHbSrVGmDnZ = c3cgVjNv1rde.Thread(target=KBeixSYCP1AhJvlN9p73LDaQzbw,args=())
			l2Q3KphWJHbSrVGmDnZ.start()
		else: Oxpg4wUz3fYLkVRu.OBSvfy3cbl = fR68jBGWCzUsFXdlTKPOScugm(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ૗")
def zKTnVMO1upX9gAoJfrEwGIe8YHFtLP():
	qyUmHF8jvOQVrWxuBlPJnAp3h4,sWYQ7ZNhFgwrlMeXo = hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫࠬ૘"),wwyUWMFAsO(u"ࠬ࠭૙")
	GetlihO4NTw6a = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.getInfoLabel(DLSVmlyBbCK(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡆࡳ࡫ࡨࡲࡩࡲࡹࡏࡣࡰࡩࠬ૚"))
	try:
		UcsQSmtGiPvHu9CnR8xqAjOTKFI54 = open(DLSVmlyBbCK(u"ࠧ࠰ࡲࡵࡳࡨ࠵ࡣࡱࡷ࡬ࡲ࡫ࡵࠧ૛"),m6b7CoBk4EQ(u"ࠨࡴࡥࠫ૜")).read()
		if VYMZsxRpcQHPgkaiDKjyoh: UcsQSmtGiPvHu9CnR8xqAjOTKFI54 = UcsQSmtGiPvHu9CnR8xqAjOTKFI54.decode(gnfv8UtZ3daGqpjzk(u"ࠩࡸࡸ࡫࠾ࠧ૝"))
		hCQNltBHRf2EkpoFOzsbPn4icTI6X9 = ZXFs0mEPR8qI2zj.findall(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠪࡗࡪࡸࡩࡢ࡮࠱࠮ࡄࡀࠠࠩ࠰࠭ࡃ࠮ࠪࠧ૞"),UcsQSmtGiPvHu9CnR8xqAjOTKFI54,ZXFs0mEPR8qI2zj.IGNORECASE)
		if hCQNltBHRf2EkpoFOzsbPn4icTI6X9: qyUmHF8jvOQVrWxuBlPJnAp3h4 = hCQNltBHRf2EkpoFOzsbPn4icTI6X9[eeIL1TfgFQJaKqVD8hGNPEZ(u"࠰ీ")]
	except: pass
	try:
		import subprocess as a8ARByYenzNJF3COjZmdlMiS9h
		yEMOPV50Znt1JU4X7lLqkvAuh8Y2T = a8ARByYenzNJF3COjZmdlMiS9h.Popen(XogUJZEijT7KWbxeO6(u"ࠫࡸࡺࡡࡵࠢ࠰ࡧࠥࠨ࡚ࠠࠦࠣࠦࠥ࠵ࡳࡵࡱࡵࡥ࡬࡫࠯ࡦ࡯ࡸࡰࡦࡺࡥࡥ࠱࠳ࠤࡀࠦࡳࡵࡣࡷࠤ࠲ࡩࠠࠣࠢࠨ࡛ࠥࠨࠠ࠰ࡸࡤࡶ࠴ࡲ࡯ࡨࠩ૟"),shell=wwyUWMFAsO(u"ࡔࡳࡷࡨ౿"),stdin=a8ARByYenzNJF3COjZmdlMiS9h.PIPE,stdout=a8ARByYenzNJF3COjZmdlMiS9h.PIPE,stderr=a8ARByYenzNJF3COjZmdlMiS9h.PIPE)
		m6x9DpA0NbEWZtz3oV7IMqS = yEMOPV50Znt1JU4X7lLqkvAuh8Y2T.stdout.read()
		if m6x9DpA0NbEWZtz3oV7IMqS:
			if VYMZsxRpcQHPgkaiDKjyoh:
				m6x9DpA0NbEWZtz3oV7IMqS = m6x9DpA0NbEWZtz3oV7IMqS.decode(FhcnOB9t3frzvXb(u"ࠬࡻࡴࡧ࠺ࠪૠ"),EDPaWgMt1SwNn8o(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ૡ"))
			VeAEpDqrjMsZHyu7O5fY1dSnti9L = ZXFs0mEPR8qI2zj.findall(XogUJZEijT7KWbxeO6(u"ࠧࠡࠪ࡟ࡨࢀ࠷࠰ࡾࠫࠣࠫૢ"),m6x9DpA0NbEWZtz3oV7IMqS,ZXFs0mEPR8qI2zj.IGNORECASE)
			if VeAEpDqrjMsZHyu7O5fY1dSnti9L: sWYQ7ZNhFgwrlMeXo = min(VeAEpDqrjMsZHyu7O5fY1dSnti9L)
	except: pass
	return GetlihO4NTw6a,qyUmHF8jvOQVrWxuBlPJnAp3h4,sWYQ7ZNhFgwrlMeXo
def HHWAnGJrb9powOqTkYgcPQ6Ef(U2QADirkbfRT7,N9ySiLF8gbHrP1me0nuCh=yTMWeCgUROcvtsblfK85L62xPk(u"ࡕࡴࡸࡩಀ")):
	Q6ZzMusGWn9CDAygVB05h = DLSVmlyBbCK(u"ࡖࡵࡹࡪಁ")
	if N9ySiLF8gbHrP1me0nuCh:
		GZ15LsotElHF = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,EDPaWgMt1SwNn8o(u"ࠨ࡮࡬ࡷࡹ࠭ૣ"),ZSJVq5XDrRot(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ૤"),fR68jBGWCzUsFXdlTKPOScugm(u"ࠪࡗࡎ࡚ࡅࡔࡡࡆࡌࡊࡉࡋࠨ૥"))
		if GZ15LsotElHF:
			B4tpFcjqKw,hhrNn2Gq8jReviOK3H0oS,C9ChlqeJRxFHy0As,SO3Es1rgFYUAKoRcPx = GZ15LsotElHF
			Q6ZzMusGWn9CDAygVB05h = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,pEo8g7riWVL014KaRtzQ(u"ࠫࡱ࡯ࡳࡵࠩ૦"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ૧"),fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࡓࡊࡖࡈࡗࡤ࡜ࡅࡓࡋࡉ࡝ࠬ૨"))
			if Q6ZzMusGWn9CDAygVB05h: GetlihO4NTw6a,qyUmHF8jvOQVrWxuBlPJnAp3h4,sWYQ7ZNhFgwrlMeXo = Q6ZzMusGWn9CDAygVB05h
			else: GetlihO4NTw6a,qyUmHF8jvOQVrWxuBlPJnAp3h4,sWYQ7ZNhFgwrlMeXo = zKTnVMO1upX9gAoJfrEwGIe8YHFtLP()
			if (hhrNn2Gq8jReviOK3H0oS,C9ChlqeJRxFHy0As,SO3Es1rgFYUAKoRcPx)==(GetlihO4NTw6a,qyUmHF8jvOQVrWxuBlPJnAp3h4,sWYQ7ZNhFgwrlMeXo): return OVmSuf8tpd(u"ࠧ࡝ࡰࠪ૩").join(B4tpFcjqKw)
	if Q6ZzMusGWn9CDAygVB05h: GetlihO4NTw6a,qyUmHF8jvOQVrWxuBlPJnAp3h4,sWYQ7ZNhFgwrlMeXo = zKTnVMO1upX9gAoJfrEwGIe8YHFtLP()
	global ojuVgRsHfBzkAQETUP,avjxeAJ8rz
	ojuVgRsHfBzkAQETUP,avjxeAJ8rz,WW8LPHwUoJmO4ETkrBjyX3CbK6 = aVLSn1xw5cK(u"ࠨࠩ૪"),m6b7CoBk4EQ(u"ࠩࠪ૫"),xuYvdJpOEyQKTLNwb(u"ࠪࠫ૬")
	U2QADirkbfRT7 = U2QADirkbfRT7//kmdSKeBIwViM9t3(u"࠳ు")
	c3cgVjNv1rde.Thread(target=DzQZshd2pgKwf).start()
	c3cgVjNv1rde.Thread(target=EHLBIwUWgQ21ibzOK).start()
	for OeT2Jo0sp6h1mGdqfFw in range(EDPaWgMt1SwNn8o(u"࠳࠳ూ")):
		luMHeSgCBaPrb9KvUjNFqcR.sleep(OVmSuf8tpd(u"࠳࠲࠺ృ"))
		if not WW8LPHwUoJmO4ETkrBjyX3CbK6:
			try:
				R9kOQ27dBWmyTwo3 = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.getInfoLabel(kmdSKeBIwViM9t3(u"ࠫࡓ࡫ࡴࡸࡱࡵ࡯࠳ࡓࡡࡤࡃࡧࡨࡷ࡫ࡳࡴࠩ૭"))
				if R9kOQ27dBWmyTwo3.count(FhcnOB9t3frzvXb(u"ࠬࡀࠧ૮"))==fR68jBGWCzUsFXdlTKPOScugm(u"࠺౅") and R9kOQ27dBWmyTwo3.count(jYaM5vilgZdFx6QHbApwVXO8et(u"࠭࠰ࠨ૯"))<PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠽ౄ"):
					R9kOQ27dBWmyTwo3 = R9kOQ27dBWmyTwo3.lower().replace(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧ࠻ࠩ૰"),DLSVmlyBbCK(u"ࠨࠩ૱"))
					WW8LPHwUoJmO4ETkrBjyX3CbK6 = str(int(R9kOQ27dBWmyTwo3,gSmqZU0plur2xKPJwQA(u"࠷࠶ె")))
			except: pass
		if ojuVgRsHfBzkAQETUP and avjxeAJ8rz and WW8LPHwUoJmO4ETkrBjyX3CbK6: break
	k5GHLNehBd1lcSzfZCnIYwA467tR = [ojuVgRsHfBzkAQETUP,avjxeAJ8rz,WW8LPHwUoJmO4ETkrBjyX3CbK6,gSmqZU0plur2xKPJwQA(u"ࠩࠪ૲"),OVmSuf8tpd(u"ࠪࠫ૳"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠫ࠵࠶࠱࠲࠴࠵࠷࠸࠺࠴࠶࠷࠹࠺࠼࠽ࠧ૴")]
	if qyUmHF8jvOQVrWxuBlPJnAp3h4 or sWYQ7ZNhFgwrlMeXo:
		from hashlib import md5 as ppq7nbP8zdkSt20aCVK3rY9
		DVCYsO5aE7SzRi = [(LmcNhzY6fQPd2JyCGslkSr(u"࠵ై"),qyUmHF8jvOQVrWxuBlPJnAp3h4),(eeIL1TfgFQJaKqVD8hGNPEZ(u"࠵ే"),sWYQ7ZNhFgwrlMeXo)]
		for qWMXl6rZ1seT2NBhn,A6zIXayOqBNEgorvnD7dwUspk in DVCYsO5aE7SzRi:
			A6zIXayOqBNEgorvnD7dwUspk = A6zIXayOqBNEgorvnD7dwUspk.strip(xuYvdJpOEyQKTLNwb(u"ࠬ࠶ࠧ૵"))
			if A6zIXayOqBNEgorvnD7dwUspk:
				if VYMZsxRpcQHPgkaiDKjyoh: A6zIXayOqBNEgorvnD7dwUspk = A6zIXayOqBNEgorvnD7dwUspk.encode(J3OCAmZVcn(u"࠭ࡵࡵࡨ࠻ࠫ૶"))
				A6zIXayOqBNEgorvnD7dwUspk = str(int(ppq7nbP8zdkSt20aCVK3rY9(A6zIXayOqBNEgorvnD7dwUspk).hexdigest(),jYaM5vilgZdFx6QHbApwVXO8et(u"࠵࠹౉")))
				FFBfgVjWc9AytKXq4IpwURG8d = [int(A6zIXayOqBNEgorvnD7dwUspk[cw8YWfq9FGP0bvx6E:cw8YWfq9FGP0bvx6E+JMLhEyaBWmskovGHTrVCxQ08(u"࠵࠺ో")]) for cw8YWfq9FGP0bvx6E in range(len(A6zIXayOqBNEgorvnD7dwUspk)) if cw8YWfq9FGP0bvx6E%JMLhEyaBWmskovGHTrVCxQ08(u"࠵࠺ో")==eeIL1TfgFQJaKqVD8hGNPEZ(u"࠳ొ")]
				k5GHLNehBd1lcSzfZCnIYwA467tR[qWMXl6rZ1seT2NBhn-XogUJZEijT7KWbxeO6(u"࠶ౌ")] = str(sum(FFBfgVjWc9AytKXq4IpwURG8d))
	B4tpFcjqKw,zz0FIYZRUXytAClw = [],ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࡉࡥࡱࡹࡥಂ")
	for Sqb57X9u6FGQiW3Z1 in range(len(k5GHLNehBd1lcSzfZCnIYwA467tR)):
		FFBfgVjWc9AytKXq4IpwURG8d = k5GHLNehBd1lcSzfZCnIYwA467tR[Sqb57X9u6FGQiW3Z1]
		if not FFBfgVjWc9AytKXq4IpwURG8d: continue
		if zz0FIYZRUXytAClw and FFBfgVjWc9AytKXq4IpwURG8d==k5GHLNehBd1lcSzfZCnIYwA467tR[-aVLSn1xw5cK(u"࠷్")]: continue
		zz0FIYZRUXytAClw = jYaM5vilgZdFx6QHbApwVXO8et(u"ࡘࡷࡻࡥಃ")
		FFBfgVjWc9AytKXq4IpwURG8d = ZSJVq5XDrRot(u"ࠧ࠱ࠩ૷")*U2QADirkbfRT7+FFBfgVjWc9AytKXq4IpwURG8d
		FFBfgVjWc9AytKXq4IpwURG8d = FFBfgVjWc9AytKXq4IpwURG8d[-U2QADirkbfRT7:]
		M5wbdPJ1BZR,axpJNgoq5wk2BIz0 = yTMWeCgUROcvtsblfK85L62xPk(u"ࠨࠩ૸"),XogUJZEijT7KWbxeO6(u"ࠩࠪૹ")
		O5tIJNqPKl = str(int(JMLhEyaBWmskovGHTrVCxQ08(u"ࠪ࠽ࠬૺ")*(U2QADirkbfRT7+pEo8g7riWVL014KaRtzQ(u"࠱౎")))-int(FFBfgVjWc9AytKXq4IpwURG8d))[-U2QADirkbfRT7:]
		for RB2MA1va7eYuCK in list(range(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠱౏"),U2QADirkbfRT7,FhcnOB9t3frzvXb(u"࠶౐"))):
			M5wbdPJ1BZR += O5tIJNqPKl[RB2MA1va7eYuCK:RB2MA1va7eYuCK+AAgpHN0nMZ(u"࠷౑")]+OVmSuf8tpd(u"ࠫ࠲࠭ૻ")
			axpJNgoq5wk2BIz0 += str(sum(map(int,FFBfgVjWc9AytKXq4IpwURG8d[RB2MA1va7eYuCK:RB2MA1va7eYuCK+JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠹౓")]))%yTMWeCgUROcvtsblfK85L62xPk(u"࠵࠵౒"))
		w8HZ5Joskl7z0 = str(Sqb57X9u6FGQiW3Z1)+M5wbdPJ1BZR+axpJNgoq5wk2BIz0
		B4tpFcjqKw.append(w8HZ5Joskl7z0)
	Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,ZSJVq5XDrRot(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨૼ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࡓࡊࡖࡈࡗࡤ࡜ࡅࡓࡋࡉ࡝ࠬ૽"),[GetlihO4NTw6a,qyUmHF8jvOQVrWxuBlPJnAp3h4,sWYQ7ZNhFgwrlMeXo],Z7uFdWIRv9ybj0)
	Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,kmdSKeBIwViM9t3(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ૾"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨࡕࡌࡘࡊ࡙࡟ࡄࡊࡈࡇࡐ࠭૿"),[B4tpFcjqKw,GetlihO4NTw6a,qyUmHF8jvOQVrWxuBlPJnAp3h4,sWYQ7ZNhFgwrlMeXo],JNsoWV1CXc4xy)
	return ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠩ࡟ࡲࠬ଀").join(B4tpFcjqKw)
def QbG0Lx7lnS6jUA9X3rzfsBYI8(m6egkRrjcavHEdwYDSOs,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,SOlDApJEx73FokmVdYCfKuRNXy8,yJQ0WizojdcChZPM4,j5jMXZ7myEuoLG,nJDfuczrBG4ZeOs):
	obS4TpHeV3digGC = str(yJQ0WizojdcChZPM4)[ZSJVq5XDrRot(u"࠶౔"):EDPaWgMt1SwNn8o(u"࠲࠶࠲ౕ")].replace(DLSVmlyBbCK(u"ࠪࡠࡳ࠭ଁ"),aVLSn1xw5cK(u"ࠫࡡࡢ࡮ࠨଂ")).replace(J3OCAmZVcn(u"ࠬࡢࡲࠨଃ"),fR68jBGWCzUsFXdlTKPOScugm(u"࠭࡜࡝ࡴࠪ଄")).replace(m6b7CoBk4EQ(u"ࠧࠡࠢࠣࠤࠬଅ"),gnfv8UtZ3daGqpjzk(u"ࠨࠢࠪଆ")).replace(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࠣࠤࠥ࠭ଇ"),m6b7CoBk4EQ(u"ࠪࠤࠬଈ"))
	if len(str(yJQ0WizojdcChZPM4))>kmdSKeBIwViM9t3(u"࠳࠷࠳ౖ"): obS4TpHeV3digGC = obS4TpHeV3digGC+fR68jBGWCzUsFXdlTKPOScugm(u"ࠫࠥ࠴࠮࠯ࠩଉ")
	BTMputsaqV = str(SOlDApJEx73FokmVdYCfKuRNXy8)[kRYWcNuAazr4jtmBoxFVS19Z6(u"࠲౗"):JMLhEyaBWmskovGHTrVCxQ08(u"࠵࠹࠵ౘ")].replace(EDPaWgMt1SwNn8o(u"ࠬࡢ࡮ࠨଊ"),wwyUWMFAsO(u"࠭࡜࡝ࡰࠪଋ")).replace(xuYvdJpOEyQKTLNwb(u"ࠧ࡝ࡴࠪଌ"),fR68jBGWCzUsFXdlTKPOScugm(u"ࠨ࡞࡟ࡶࠬ଍")).replace(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠩࠣࠤࠥࠦࠧ଎"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪࠤࠬଏ")).replace(DLSVmlyBbCK(u"ࠫࠥࠦࠠࠨଐ"),sArCMRngQNmXkBoKv(u"ࠬࠦࠧ଑"))
	if len(str(SOlDApJEx73FokmVdYCfKuRNXy8))>bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠶࠺࠶ౙ"): BTMputsaqV = BTMputsaqV+sArCMRngQNmXkBoKv(u"࠭ࠠ࠯࠰࠱ࠫ଒")
	tr24ZoudmqvxfYCw(pEo8g7riWVL014KaRtzQ(u"ࠧࡏࡑࡗࡍࡈࡋࠧଓ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠨ࠰ࠣࠤࡔࡖࡅࡏࡗࡕࡐࡤ࠭ଔ")+m6egkRrjcavHEdwYDSOs+sArCMRngQNmXkBoKv(u"ࠩࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬକ")+XpOsU3v5dqH8MQAK6FcafmP1z0kL2+kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬଖ")+j5jMXZ7myEuoLG+AAgpHN0nMZ(u"ࠫࠥࡣࠠࠡࠢࡐࡩࡹ࡮࡯ࡥ࠼ࠣ࡟ࠥ࠭ଗ")+nJDfuczrBG4ZeOs+MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨଘ")+str(obS4TpHeV3digGC)+AAgpHN0nMZ(u"࠭ࠠ࡞ࠢࠣࠤࡉࡧࡴࡢ࠼ࠣ࡟ࠥ࠭ଙ")+BTMputsaqV+DLSVmlyBbCK(u"ࠧࠡ࡟ࠪଚ"))
	return
def DzQZshd2pgKwf():
	global ojuVgRsHfBzkAQETUP
	import getmac82 as LLPohCiEgOQWcyIzM6AVKn
	try:
		zU5CbB0cgfmdJvZ91KuNGPE4QS = LLPohCiEgOQWcyIzM6AVKn.get_mac_address()
		if zU5CbB0cgfmdJvZ91KuNGPE4QS.count(aVLSn1xw5cK(u"ࠨ࠼ࠪଛ"))==J3OCAmZVcn(u"࠻౛") and zU5CbB0cgfmdJvZ91KuNGPE4QS.count(JMLhEyaBWmskovGHTrVCxQ08(u"ࠩ࠳ࠫଜ"))<bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠾ౚ"):
			zU5CbB0cgfmdJvZ91KuNGPE4QS = zU5CbB0cgfmdJvZ91KuNGPE4QS.lower().replace(kmdSKeBIwViM9t3(u"ࠪ࠾ࠬଝ"),m6b7CoBk4EQ(u"ࠫࠬଞ"))
			ojuVgRsHfBzkAQETUP = str(int(zU5CbB0cgfmdJvZ91KuNGPE4QS,sArCMRngQNmXkBoKv(u"࠱࠷౜")))
	except: pass
	return
def EHLBIwUWgQ21ibzOK():
	global avjxeAJ8rz
	import getmac94 as BcViU09hkGEfIAFrDdQM
	try:
		CzrfSbdMqYsLFNmy8cIQ1A = BcViU09hkGEfIAFrDdQM.get_mac_address()
		if CzrfSbdMqYsLFNmy8cIQ1A.count(aVLSn1xw5cK(u"ࠬࡀࠧଟ"))==sArCMRngQNmXkBoKv(u"࠷౞") and CzrfSbdMqYsLFNmy8cIQ1A.count(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭࠰ࠨଠ"))<fR68jBGWCzUsFXdlTKPOScugm(u"࠺ౝ"):
			CzrfSbdMqYsLFNmy8cIQ1A = CzrfSbdMqYsLFNmy8cIQ1A.lower().replace(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧ࠻ࠩଡ"),ZSJVq5XDrRot(u"ࠨࠩଢ"))
			avjxeAJ8rz = str(int(CzrfSbdMqYsLFNmy8cIQ1A,LmcNhzY6fQPd2JyCGslkSr(u"࠴࠺౟")))
	except: pass
	return
def dptm8vZW9MiuK3fVNC(nJDfuczrBG4ZeOs,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,SOlDApJEx73FokmVdYCfKuRNXy8=jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩࠪଣ"),yJQ0WizojdcChZPM4=c4QSTnPiWUCjhrLlwGB(u"ࠪࠫତ"),j5jMXZ7myEuoLG=EDPaWgMt1SwNn8o(u"ࠫࠬଥ")):
	QbG0Lx7lnS6jUA9X3rzfsBYI8(yTMWeCgUROcvtsblfK85L62xPk(u"࡛ࠬࡒࡍࡎࡌࡆࠥࠦࡏࡑࡇࡑࡣ࡚ࡘࡌࠨଦ"),XpOsU3v5dqH8MQAK6FcafmP1z0kL2,SOlDApJEx73FokmVdYCfKuRNXy8,yJQ0WizojdcChZPM4,j5jMXZ7myEuoLG,nJDfuczrBG4ZeOs)
	if VYMZsxRpcQHPgkaiDKjyoh: import urllib.request as jom0yNvdbBFSZ5
	else: import urllib2 as jom0yNvdbBFSZ5
	if not yJQ0WizojdcChZPM4: yJQ0WizojdcChZPM4 = {JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪଧ"):wwyUWMFAsO(u"ࠧࠨନ")}
	if not SOlDApJEx73FokmVdYCfKuRNXy8: SOlDApJEx73FokmVdYCfKuRNXy8 = {}
	if nJDfuczrBG4ZeOs==eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨࡉࡈࡘࠬ଩"):
		XpOsU3v5dqH8MQAK6FcafmP1z0kL2 = XpOsU3v5dqH8MQAK6FcafmP1z0kL2+DLSVmlyBbCK(u"ࠩࡂࠫପ")+XapnozmJWluEb8fdYye0SR6QxqZL(SOlDApJEx73FokmVdYCfKuRNXy8)
		SOlDApJEx73FokmVdYCfKuRNXy8 = None
	elif nJDfuczrBG4ZeOs==c4QSTnPiWUCjhrLlwGB(u"ࠪࡔࡔ࡙ࡔࠨଫ") and gSmqZU0plur2xKPJwQA(u"ࠫ࡯ࡹ࡯࡯ࠩବ") in str(yJQ0WizojdcChZPM4):
		from json import dumps as zIdYyOpmXEar2RLH
		SOlDApJEx73FokmVdYCfKuRNXy8 = zIdYyOpmXEar2RLH(SOlDApJEx73FokmVdYCfKuRNXy8)
		SOlDApJEx73FokmVdYCfKuRNXy8 = str(SOlDApJEx73FokmVdYCfKuRNXy8).encode(JMLhEyaBWmskovGHTrVCxQ08(u"ࠬࡻࡴࡧ࠺ࠪଭ"))
	elif nJDfuczrBG4ZeOs==fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࡐࡐࡕࡗࠫମ"):
		SOlDApJEx73FokmVdYCfKuRNXy8 = XapnozmJWluEb8fdYye0SR6QxqZL(SOlDApJEx73FokmVdYCfKuRNXy8)
		SOlDApJEx73FokmVdYCfKuRNXy8 = SOlDApJEx73FokmVdYCfKuRNXy8.encode(sArCMRngQNmXkBoKv(u"ࠧࡶࡶࡩ࠼ࠬଯ"))
	try:
		rTzcIokalWgbSiC289MjXZmONs = jom0yNvdbBFSZ5.Request(XpOsU3v5dqH8MQAK6FcafmP1z0kL2,headers=yJQ0WizojdcChZPM4,data=SOlDApJEx73FokmVdYCfKuRNXy8)
		wvdJxFK9nk = jom0yNvdbBFSZ5.urlopen(rTzcIokalWgbSiC289MjXZmONs)
		vdCNK2GykrWZIVeg7z5S4HFh = wvdJxFK9nk.read()
		vhQayCIs07WL6iB1XSwubO,X75jhUrfuFIJW82GYmbp = yTMWeCgUROcvtsblfK85L62xPk(u"࠶࠵࠶ౠ"),c4QSTnPiWUCjhrLlwGB(u"ࠨࡑࡎࠫର")
	except:
		vdCNK2GykrWZIVeg7z5S4HFh = OVmSuf8tpd(u"ࠩࠪ଱")
		vhQayCIs07WL6iB1XSwubO,X75jhUrfuFIJW82GYmbp = -OVmSuf8tpd(u"࠶ౡ"),yTMWeCgUROcvtsblfK85L62xPk(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤࡊࡸࡲࡰࡴࠪଲ")
	tr24ZoudmqvxfYCw(EDPaWgMt1SwNn8o(u"ࠫࡓࡕࡔࡊࡅࡈࠫଳ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬ࠴ࠠࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡘࡖࡑࡒࡉࡃࠢࠣࡖࡊ࡙ࡐࡐࡐࡖࡉࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨ଴")+str(vhQayCIs07WL6iB1XSwubO)+kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭ࠠ࡞ࠢࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨଵ")+X75jhUrfuFIJW82GYmbp+MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩଶ")+j5jMXZ7myEuoLG+xuYvdJpOEyQKTLNwb(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧଷ")+XpOsU3v5dqH8MQAK6FcafmP1z0kL2+OVmSuf8tpd(u"ࠩࠣࡡࠬସ"))
	if vdCNK2GykrWZIVeg7z5S4HFh and VYMZsxRpcQHPgkaiDKjyoh: vdCNK2GykrWZIVeg7z5S4HFh = vdCNK2GykrWZIVeg7z5S4HFh.decode(OVmSuf8tpd(u"ࠪࡹࡹ࡬࠸ࠨହ"))
	return vdCNK2GykrWZIVeg7z5S4HFh
def PEdiNj9D3ZtIcy1anJwVQYfkzM8W0b(XEhPrVHD5LGmYRMI3wfC7,uueC2a4k37PMw=c4QSTnPiWUCjhrLlwGB(u"ࠫࠬ଺")):
	D6QLAPfTCFue4KxzOXqUZoRHk7r = str(bnPo1W52UVMRs7Lw6kfG9QdO.randrange(XogUJZEijT7KWbxeO6(u"࠷࠱࠲࠳࠴࠵࠶࠷࠱࠲࠳࠴ౢ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"࠹࠺࠻࠼࠽࠾࠿࠹࠺࠻࠼࠽ౣ")))
	yJQ0WizojdcChZPM4 = {JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ଻"):kmdSKeBIwViM9t3(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯଼ࠩ")}
	TaHKyEBmlpIOSdnr2XDA = {	J3OCAmZVcn(u"ࠢࡶࡵࡨࡶࡤ࡯ࡤࠣଽ"):HHWAnGJrb9powOqTkYgcPQ6Ef(kRYWcNuAazr4jtmBoxFVS19Z6(u"࠵࠵౥")).splitlines()[pEo8g7riWVL014KaRtzQ(u"࠳౦")][-aVLSn1xw5cK(u"࠳࠶౤"):],
				ZSJVq5XDrRot(u"ࠣࡱࡶࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠧା"):str(V8US2yZAg0QXJebWIHKD5xFa),
				XogUJZEijT7KWbxeO6(u"ࠤࡤࡴࡵࡥࡶࡦࡴࡶ࡭ࡴࡴࠢି"):i69DxzEZSwmuY5Il,
				OVmSuf8tpd(u"ࠥࡨࡪࡼࡩࡤࡧࡢࡪࡦࡳࡩ࡭ࡻࠥୀ"):i69DxzEZSwmuY5Il,
				PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠦࡪࡼࡥ࡯ࡶࡢࡸࡾࡶࡥࠣୁ"):XEhPrVHD5LGmYRMI3wfC7,
				MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧࡶ࡬ࡢࡶࡩࡳࡷࡳࠢୂ"): i69DxzEZSwmuY5Il,
				bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࡣࡢࡴࡵ࡭ࡪࡸࠢୃ"):ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠢࡂࡔࡄࡆࡎࡉ࡟ࡗࡋࡇࡉࡔ࡙ࠢୄ"),
				ZSJVq5XDrRot(u"ࠣࡧࡹࡩࡳࡺ࡟ࡱࡴࡲࡴࡪࡸࡴࡪࡧࡶࠦ୅"):{OVmSuf8tpd(u"ࠤࡈࡺࡪࡴࡴࡠࡐࡤࡱࡪࠨ୆"):XEhPrVHD5LGmYRMI3wfC7},
				JMLhEyaBWmskovGHTrVCxQ08(u"ࠥࡹࡸ࡫ࡲࡠࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷࠧେ"): {bdhQDyjm3nPwToFHkprvCzBLUGR(u"࡚ࠦࡹࡥࡳࡡࡈࡺࡪࡴࡴࡠࡐࡤࡱࡪࠨୈ"):XEhPrVHD5LGmYRMI3wfC7},
				PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠧࠪࡳ࡬࡫ࡳࡣࡺࡹࡥࡳࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸࡥࡳࡺࡰࡦࠦ୉"):FhcnOB9t3frzvXb(u"ࡋࡧ࡬ࡴࡧ಄"),
				Ej67fFyoqW8kbV2HdSK(u"ࠨࡩࡱࠤ୊"): jYaM5vilgZdFx6QHbApwVXO8et(u"ࠢࠥࡴࡨࡱࡴࡺࡥࠣୋ")
			}
	if not uueC2a4k37PMw: oAfkXjPBgR = [TaHKyEBmlpIOSdnr2XDA]
	else:
		Iin4ePDgTdC = TaHKyEBmlpIOSdnr2XDA.copy()
		Iin4ePDgTdC[bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࡧࡹࡩࡳࡺ࡟ࡵࡻࡳࡩࠬୌ")] = uueC2a4k37PMw
		Iin4ePDgTdC[MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩࡨࡺࡪࡴࡴࡠࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷ୍ࠬ")] = {ZSJVq5XDrRot(u"ࠥࡉࡻ࡫࡮ࡵࡡࡑࡥࡲ࡫ࠢ୎"):uueC2a4k37PMw}
		Iin4ePDgTdC[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫࡺࡹࡥࡳࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸ࠭୏")] = {JMLhEyaBWmskovGHTrVCxQ08(u"࡛ࠧࡳࡦࡴࡢࡉࡻ࡫࡮ࡵࡡࡑࡥࡲ࡫ࠢ୐"):uueC2a4k37PMw}
		oAfkXjPBgR = [TaHKyEBmlpIOSdnr2XDA,Iin4ePDgTdC]
	SOlDApJEx73FokmVdYCfKuRNXy8 = {ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨࡡࡱ࡫ࡢ࡯ࡪࡿࠢ୑"):sArCMRngQNmXkBoKv(u"ࠧ࠳࠷࠷ࡨࡩ࠹ࡡ࠵࠲࠼ࡨ࠽ࡨ࠶࠹࠳ࡧ࠸ࡪ࠷࠱࠸ࡧࡨ࠻࠽ࡩࡥࡣࡨ࠵࠽ࠬ୒"),
			JMLhEyaBWmskovGHTrVCxQ08(u"ࠣ࡫ࡱࡷࡪࡸࡴࡠ࡫ࡧࠦ୓"):D6QLAPfTCFue4KxzOXqUZoRHk7r,
			eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠤࡨࡺࡪࡴࡴࡴࠤ୔"): oAfkXjPBgR
		}
	XpOsU3v5dqH8MQAK6FcafmP1z0kL2 = LmcNhzY6fQPd2JyCGslkSr(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡶࡩ࠳࠰ࡤࡱࡵࡲࡩࡵࡷࡧࡩ࠳ࡩ࡯࡮࠱࠵࠳࡭ࡺࡴࡱࡣࡳ࡭ࠬ୕")
	vdCNK2GykrWZIVeg7z5S4HFh = dptm8vZW9MiuK3fVNC(m6b7CoBk4EQ(u"ࠫࡕࡕࡓࡕࠩୖ"),XpOsU3v5dqH8MQAK6FcafmP1z0kL2,SOlDApJEx73FokmVdYCfKuRNXy8,yJQ0WizojdcChZPM4,JMLhEyaBWmskovGHTrVCxQ08(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡓࡆࡐࡇࡣࡆࡔࡁࡍ࡛ࡗࡍࡈ࡙࡟ࡆࡘࡈࡒ࡙࠳࠱ࡴࡶࠪୗ"))
	return vdCNK2GykrWZIVeg7z5S4HFh
def NL0JIkbrEWqTYj61vVKGCnBw37MsOF(sLhOM54GVH06aR1kSy2iBPfbItYo,unjzvHfWpPTbqACy9RtOY6m):
	unjzvHfWpPTbqACy9RtOY6m = unjzvHfWpPTbqACy9RtOY6m.replace(kmdSKeBIwViM9t3(u"࠭࡮ࡶ࡮࡯ࠫ୘"),c4QSTnPiWUCjhrLlwGB(u"ࠧࡏࡱࡱࡩࠬ୙"))
	unjzvHfWpPTbqACy9RtOY6m = unjzvHfWpPTbqACy9RtOY6m.replace(Ej67fFyoqW8kbV2HdSK(u"ࠨࡶࡵࡹࡪ࠭୚"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩࡗࡶࡺ࡫ࠧ୛"))
	unjzvHfWpPTbqACy9RtOY6m = unjzvHfWpPTbqACy9RtOY6m.replace(xuYvdJpOEyQKTLNwb(u"ࠪࡪࡦࡲࡳࡦࠩଡ଼"),c4QSTnPiWUCjhrLlwGB(u"ࠫࡋࡧ࡬ࡴࡧࠪଢ଼"))
	unjzvHfWpPTbqACy9RtOY6m = unjzvHfWpPTbqACy9RtOY6m.replace(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬࡢ࠯ࠨ୞"),J3OCAmZVcn(u"࠭࠯ࠨୟ"))
	try: Qg3B18PfKv7kTZe = eval(unjzvHfWpPTbqACy9RtOY6m)
	except: Qg3B18PfKv7kTZe = xvPYSiDMwZ3EHs9b75XhqBGeK8(sLhOM54GVH06aR1kSy2iBPfbItYo)
	return Qg3B18PfKv7kTZe
def UyKd8a0phrm():
	m6egkRrjcavHEdwYDSOs,vABVTz0qOd1anSJ3D,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,knu9Y0BX6ErPRJWT13A5o,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,unjzvHfWpPTbqACy9RtOY6m,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw = q0tgURwzEOJIYc27DbG4aT(VPIEsaiROZwmp20Jdn8WrA7c3Y)
	p3pw6HeVfqXcFnT = ZXFs0mEPR8qI2zj.findall(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧ࡝ࡦ࡟ࡨ࠿ࡢࡤ࡝ࡦࠣࡠࡠ࠵ࡃࡐࡎࡒࡖࡡࡣࠧୠ"),vABVTz0qOd1anSJ3D,ZXFs0mEPR8qI2zj.DOTALL)
	if p3pw6HeVfqXcFnT: vABVTz0qOd1anSJ3D = vABVTz0qOd1anSJ3D.split(p3pw6HeVfqXcFnT[aVLSn1xw5cK(u"࠵౨")],fR68jBGWCzUsFXdlTKPOScugm(u"࠵౧"))[fR68jBGWCzUsFXdlTKPOScugm(u"࠵౧")]
	Vzo6GaySHCx = luMHeSgCBaPrb9KvUjNFqcR.strftime(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨࡡࠨࡱ࠳ࠫࡤࡠࠧࡋ࠾ࠪࡓ࡟ࠨୡ"),luMHeSgCBaPrb9KvUjNFqcR.localtime(F5I1VZzxkXenKuEAYO))
	vABVTz0qOd1anSJ3D = vABVTz0qOd1anSJ3D+Vzo6GaySHCx
	lTyPebYg7CFcwJuWBvkH2LQr5MGp = m6egkRrjcavHEdwYDSOs,vABVTz0qOd1anSJ3D,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,knu9Y0BX6ErPRJWT13A5o,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,unjzvHfWpPTbqACy9RtOY6m,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw
	if hhHq8m5vauKG9dl.path.exists(ryc0LEzgSbaI7NqvwJ):
		SqKW7xf9uRlLa0 = open(ryc0LEzgSbaI7NqvwJ,MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩࡵࡦࠬୢ")).read()
		if VYMZsxRpcQHPgkaiDKjyoh: SqKW7xf9uRlLa0 = SqKW7xf9uRlLa0.decode(Ej67fFyoqW8kbV2HdSK(u"ࠪࡹࡹ࡬࠸ࠨୣ"))
		SqKW7xf9uRlLa0 = NL0JIkbrEWqTYj61vVKGCnBw37MsOF(DLSVmlyBbCK(u"ࠫࡩ࡯ࡣࡵࠩ୤"),SqKW7xf9uRlLa0)
	else: SqKW7xf9uRlLa0 = {}
	DLK8qQNC0619awSOAkohrJXU7 = {}
	for QI3rzUVCS4pFeg in list(SqKW7xf9uRlLa0.keys()):
		if QI3rzUVCS4pFeg!=m6egkRrjcavHEdwYDSOs: DLK8qQNC0619awSOAkohrJXU7[QI3rzUVCS4pFeg] = SqKW7xf9uRlLa0[QI3rzUVCS4pFeg]
		else:
			if vABVTz0qOd1anSJ3D and vABVTz0qOd1anSJ3D!=LmcNhzY6fQPd2JyCGslkSr(u"ࠬ࠴࠮ࠨ୥"):
				g3fTr5v9HECqRVuzL6d7el2W = SqKW7xf9uRlLa0[QI3rzUVCS4pFeg]
				if lTyPebYg7CFcwJuWBvkH2LQr5MGp in g3fTr5v9HECqRVuzL6d7el2W:
					LcnYtXvRpST3U = g3fTr5v9HECqRVuzL6d7el2W.index(lTyPebYg7CFcwJuWBvkH2LQr5MGp)
					del g3fTr5v9HECqRVuzL6d7el2W[LcnYtXvRpST3U]
				usLWRwnPVIOzf8JeGj = [lTyPebYg7CFcwJuWBvkH2LQr5MGp]+g3fTr5v9HECqRVuzL6d7el2W
				usLWRwnPVIOzf8JeGj = usLWRwnPVIOzf8JeGj[:AAgpHN0nMZ(u"࠻࠰౩")]
				DLK8qQNC0619awSOAkohrJXU7[QI3rzUVCS4pFeg] = usLWRwnPVIOzf8JeGj
			else: DLK8qQNC0619awSOAkohrJXU7[QI3rzUVCS4pFeg] = SqKW7xf9uRlLa0[QI3rzUVCS4pFeg]
	if m6egkRrjcavHEdwYDSOs not in list(DLK8qQNC0619awSOAkohrJXU7.keys()): DLK8qQNC0619awSOAkohrJXU7[m6egkRrjcavHEdwYDSOs] = [lTyPebYg7CFcwJuWBvkH2LQr5MGp]
	DLK8qQNC0619awSOAkohrJXU7 = str(DLK8qQNC0619awSOAkohrJXU7)
	if VYMZsxRpcQHPgkaiDKjyoh: DLK8qQNC0619awSOAkohrJXU7 = DLK8qQNC0619awSOAkohrJXU7.encode(J3OCAmZVcn(u"࠭ࡵࡵࡨ࠻ࠫ୦"))
	open(ryc0LEzgSbaI7NqvwJ,fR68jBGWCzUsFXdlTKPOScugm(u"ࠧࡸࡤࠪ୧")).write(DLK8qQNC0619awSOAkohrJXU7)
	return
def Qc96YoCZJOsKUB8yImw034(tP325FYWofVAzLGEuSQN6ZHk1dIq,It0pgDyrsGJeX6O84KWVN7Za,kFhHbDMUyN9vBz,SOlDApJEx73FokmVdYCfKuRNXy8,xx1wskaWc0SMDNdLVnoF325,aaiEzrZY1xK6oWsNnL2fXDptUv=JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࡌࡡ࡭ࡵࡨಅ")):
	VkZ3taqEOKhCI6N = j2agIU0xsLS6c7T.getSetting(fR68jBGWCzUsFXdlTKPOScugm(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧ୨"))
	if VkZ3taqEOKhCI6N==JMLhEyaBWmskovGHTrVCxQ08(u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪ୩") and xx1wskaWc0SMDNdLVnoF325>ii5ULJKfcyuVn: xx1wskaWc0SMDNdLVnoF325 = ii5ULJKfcyuVn
	if aaiEzrZY1xK6oWsNnL2fXDptUv:
		BkeMNv4iXH3,UXdpKgHOF1i7hmvjcDE2qLr = [],[]
		for OeT2Jo0sp6h1mGdqfFw in range(len(kFhHbDMUyN9vBz)):
			unjzvHfWpPTbqACy9RtOY6m = BDzGhMLecC.dumps(SOlDApJEx73FokmVdYCfKuRNXy8[OeT2Jo0sp6h1mGdqfFw])
			VwrnHFIWktiMa21R5xDAdCcBP0 = KKTylHUNgwka5pr1tuWSBPDEA.compress(unjzvHfWpPTbqACy9RtOY6m)
			BkeMNv4iXH3.append((kFhHbDMUyN9vBz[OeT2Jo0sp6h1mGdqfFw],))
			UXdpKgHOF1i7hmvjcDE2qLr.append((xx1wskaWc0SMDNdLVnoF325+F5I1VZzxkXenKuEAYO,str(kFhHbDMUyN9vBz[OeT2Jo0sp6h1mGdqfFw]),VwrnHFIWktiMa21R5xDAdCcBP0))
	else:
		unjzvHfWpPTbqACy9RtOY6m = BDzGhMLecC.dumps(SOlDApJEx73FokmVdYCfKuRNXy8)
		VVHBq0GL1o = KKTylHUNgwka5pr1tuWSBPDEA.compress(unjzvHfWpPTbqACy9RtOY6m)
	try: m5h4wdsHCKLvPu9V6rEFi2q,nRseEAQwXo4jC21gmqPzIihfUc = xocasQYVZLF5(tP325FYWofVAzLGEuSQN6ZHk1dIq)
	except: return
	while sArCMRngQNmXkBoKv(u"ࡔࡳࡷࡨಆ"):
		try:
			nRseEAQwXo4jC21gmqPzIihfUc.execute(aVLSn1xw5cK(u"ࠪࡆࡊࡍࡉࡏࠢࡌࡑࡒࡋࡄࡊࡃࡗࡉ࡚ࠥࡒࡂࡐࡖࡅࡈ࡚ࡉࡐࡐࠣ࠿ࠬ୪"))
			break
		except: luMHeSgCBaPrb9KvUjNFqcR.sleep(LmcNhzY6fQPd2JyCGslkSr(u"࠰࠯࠷౪"))
	nRseEAQwXo4jC21gmqPzIihfUc.execute(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫࡈࡘࡅࡂࡖࡈࠤ࡙ࡇࡂࡍࡇࠣࡍࡋࠦࡎࡐࡖࠣࡉ࡝ࡏࡓࡕࡕࠣࠦࠬ୫")+It0pgDyrsGJeX6O84KWVN7Za+eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬࠨࠠࠩࡧࡻࡴ࡮ࡸࡹ࠭ࡥࡲࡰࡺࡳ࡮࠭ࡦࡤࡸࡦ࠯ࠠ࠼ࠩ୬"))
	if aaiEzrZY1xK6oWsNnL2fXDptUv:
		nRseEAQwXo4jC21gmqPzIihfUc.executemany(EDPaWgMt1SwNn8o(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭୭")+It0pgDyrsGJeX6O84KWVN7Za+FhcnOB9t3frzvXb(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧ୮"),BkeMNv4iXH3)
		nRseEAQwXo4jC21gmqPzIihfUc.executemany(xuYvdJpOEyQKTLNwb(u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠢࠨ୯")+It0pgDyrsGJeX6O84KWVN7Za+fR68jBGWCzUsFXdlTKPOScugm(u"ࠩࠥࠤ࡛ࡇࡌࡖࡇࡖࠤ࠭ࡅࠬࡀ࠮ࡂ࠭ࠥࡁࠧ୰"),UXdpKgHOF1i7hmvjcDE2qLr)
	else:
		if xx1wskaWc0SMDNdLVnoF325:
			eEgyDQbFcBRTu6riAtxnl1 = (str(kFhHbDMUyN9vBz),)
			nRseEAQwXo4jC21gmqPzIihfUc.execute(yTMWeCgUROcvtsblfK85L62xPk(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࠪୱ")+It0pgDyrsGJeX6O84KWVN7Za+gSmqZU0plur2xKPJwQA(u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡩ࡯࡭ࡷࡰࡲࠥࡃࠠࡀࠢ࠾ࠫ୲"),eEgyDQbFcBRTu6riAtxnl1)
			eEgyDQbFcBRTu6riAtxnl1 = (xx1wskaWc0SMDNdLVnoF325+F5I1VZzxkXenKuEAYO,str(kFhHbDMUyN9vBz),VVHBq0GL1o)
			nRseEAQwXo4jC21gmqPzIihfUc.execute(EDPaWgMt1SwNn8o(u"ࠬࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࠦࠬ୳")+It0pgDyrsGJeX6O84KWVN7Za+yTMWeCgUROcvtsblfK85L62xPk(u"࠭ࠢࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࡂ࠰ࡄ࠲࠿ࠪࠢ࠾ࠫ୴"),eEgyDQbFcBRTu6riAtxnl1)
		else:
			eEgyDQbFcBRTu6riAtxnl1 = (VVHBq0GL1o,str(kFhHbDMUyN9vBz))
			nRseEAQwXo4jC21gmqPzIihfUc.execute(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠧࡖࡒࡇࡅ࡙ࡋࠠࠣࠩ୵")+It0pgDyrsGJeX6O84KWVN7Za+ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨࠤࠣࡗࡊ࡚ࠠࡥࡣࡷࡥࠥࡃࠠࡀ࡚ࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧ୶"),eEgyDQbFcBRTu6riAtxnl1)
	m5h4wdsHCKLvPu9V6rEFi2q.commit()
	m5h4wdsHCKLvPu9V6rEFi2q.close()
	return
def XapnozmJWluEb8fdYye0SR6QxqZL(SOlDApJEx73FokmVdYCfKuRNXy8):
	if VYMZsxRpcQHPgkaiDKjyoh: import urllib.parse as cdDMgAq8YvUrG
	else: import urllib as cdDMgAq8YvUrG
	IUkczZlMsSQwAnPoGmpCYeEf = cdDMgAq8YvUrG.urlencode(SOlDApJEx73FokmVdYCfKuRNXy8)
	return IUkczZlMsSQwAnPoGmpCYeEf
OBSvfy3cbl = JMLhEyaBWmskovGHTrVCxQ08(u"ࠩࠪ୷")
def w3hq0Xp8D9rZJ(aaIn3XlQKJ6zSfkmjuCyM,ssnI4ASGlVvce79=eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠪࠫ୸"),IgNryh38O4iuY9ZQd=ZSJVq5XDrRot(u"ࠫࠬ୹")):
	djQBSOYN1kF7s = ssnI4ASGlVvce79 not in [Ej67fFyoqW8kbV2HdSK(u"ࠬࡓ࠳ࡖࠩ୺"),J3OCAmZVcn(u"࠭ࡉࡑࡖ࡙ࠫ୻")]
	global OBSvfy3cbl
	if not IgNryh38O4iuY9ZQd: IgNryh38O4iuY9ZQd = m6b7CoBk4EQ(u"ࠧࡷ࡫ࡧࡩࡴ࠭୼")
	OBSvfy3cbl,QDNfiRwV3lqT9sK4SWnery0z,PHnRyap4rJevEQOoICZNwF10izhf8c = m6b7CoBk4EQ(u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦ࠳ࠫ୽"),kmdSKeBIwViM9t3(u"ࠩࠪ୾"),m6b7CoBk4EQ(u"ࠪࠫ୿")
	if len(aaIn3XlQKJ6zSfkmjuCyM)==MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠴౫"):
		XpOsU3v5dqH8MQAK6FcafmP1z0kL2,FFhkuSjpZ5csd7bBGt9Rrqw3lm,PHnRyap4rJevEQOoICZNwF10izhf8c = aaIn3XlQKJ6zSfkmjuCyM
		if FFhkuSjpZ5csd7bBGt9Rrqw3lm: QDNfiRwV3lqT9sK4SWnery0z = fR68jBGWCzUsFXdlTKPOScugm(u"ࠫࠥࠦࠠࡔࡷࡥࡸ࡮ࡺ࡬ࡦ࠼ࠣ࡟ࠥ࠭஀")+FFhkuSjpZ5csd7bBGt9Rrqw3lm+DLSVmlyBbCK(u"ࠬࠦ࡝ࠨ஁")
	else: XpOsU3v5dqH8MQAK6FcafmP1z0kL2,FFhkuSjpZ5csd7bBGt9Rrqw3lm,PHnRyap4rJevEQOoICZNwF10izhf8c = aaIn3XlQKJ6zSfkmjuCyM,EDPaWgMt1SwNn8o(u"࠭ࠧஂ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧࠨஃ")
	XpOsU3v5dqH8MQAK6FcafmP1z0kL2 = XpOsU3v5dqH8MQAK6FcafmP1z0kL2.replace(sArCMRngQNmXkBoKv(u"ࠨࠧ࠵࠴ࠬ஄"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠩࠣࠫஅ"))
	n2wpUdA6KX4kLjJGxZWVieycPg = fDEdQSsq1uPoU(XpOsU3v5dqH8MQAK6FcafmP1z0kL2)
	if ssnI4ASGlVvce79 not in [m6b7CoBk4EQ(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬஆ"),gnfv8UtZ3daGqpjzk(u"ࠫࡎࡖࡔࡗࠩஇ")]:
		if ssnI4ASGlVvce79!=m6b7CoBk4EQ(u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧஈ"): XpOsU3v5dqH8MQAK6FcafmP1z0kL2 = XpOsU3v5dqH8MQAK6FcafmP1z0kL2.replace(ZSJVq5XDrRot(u"࠭ࠠࠨஉ"),FhcnOB9t3frzvXb(u"ࠧࠦ࠴࠳ࠫஊ"))
		tr24ZoudmqvxfYCw(xuYvdJpOEyQKTLNwb(u"ࠨࡐࡒࡘࡎࡉࡅࠨ஋"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+AAgpHN0nMZ(u"ࠩࠣࠤࠥࡖࡲࡦࡲࡤࡶ࡮ࡴࡧࠡࡶࡲࠤࡵࡲࡡࡺ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡻ࡯ࡤࡦࡱࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨ஌")+XpOsU3v5dqH8MQAK6FcafmP1z0kL2+Ej67fFyoqW8kbV2HdSK(u"ࠪࠤࡢ࠭஍")+QDNfiRwV3lqT9sK4SWnery0z)
		if n2wpUdA6KX4kLjJGxZWVieycPg==PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪஎ") and ssnI4ASGlVvce79 not in [Ej67fFyoqW8kbV2HdSK(u"ࠬࡏࡐࡕࡘࠪஏ"),kmdSKeBIwViM9t3(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧஐ")]:
			from j3x780FpaM import c8T0X52CGk9UZ71q,F2yZPukcUh09sqCI8nYw7e,NLVM3HAtxQOSvJf6kd78K1o
			xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = c8T0X52CGk9UZ71q(XpOsU3v5dqH8MQAK6FcafmP1z0kL2)
			Bn1eRl2KbGqszdFYJ8Z3S4I = len(YYmyQXglbEewzL3IA2Sd)
			if Bn1eRl2KbGqszdFYJ8Z3S4I>bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠳౬"):
				jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿ࠦࠨࠨ஑")+str(Bn1eRl2KbGqszdFYJ8Z3S4I)+eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨ่่ࠢๆ࠯ࠧஒ"), xCLQK8kh39sjyi5DXSZAVeI)
				if jQ6w8xOrgYhSHIRpUqzL==-DLSVmlyBbCK(u"࠴౭"):
					NLVM3HAtxQOSvJf6kd78K1o(xuYvdJpOEyQKTLNwb(u"ࠩศ่฿อมࠡ฻่่๏ฯࠠหึ฽๎้ࠦวๅใํำ๏๎ࠧஓ"),Ej67fFyoqW8kbV2HdSK(u"ࠪࡇࡦࡴࡣࡦ࡮ࠪஔ"))
					return OBSvfy3cbl
			else: jQ6w8xOrgYhSHIRpUqzL = J3OCAmZVcn(u"࠴౮")
			XpOsU3v5dqH8MQAK6FcafmP1z0kL2 = YYmyQXglbEewzL3IA2Sd[jQ6w8xOrgYhSHIRpUqzL]
			if xCLQK8kh39sjyi5DXSZAVeI[eeIL1TfgFQJaKqVD8hGNPEZ(u"࠵౯")]!=pEo8g7riWVL014KaRtzQ(u"ࠫ࠲࠷ࠧக"):
				tr24ZoudmqvxfYCw(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬࡔࡏࡕࡋࡆࡉࠬ஖"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡕࡨࡰࡪࡩࡴࡦࡦࠣࠤ࡙ࠥࡥ࡭ࡧࡦࡸ࡮ࡵ࡮࠻ࠢ࡞ࠤࠬ஗")+xCLQK8kh39sjyi5DXSZAVeI[jQ6w8xOrgYhSHIRpUqzL]+hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨ஘")+XpOsU3v5dqH8MQAK6FcafmP1z0kL2+MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨࠢࡠࠫங"))
		if FhcnOB9t3frzvXb(u"ࠩ࠲࡭࡫࡯࡬࡮࠱ࠪச") in XpOsU3v5dqH8MQAK6FcafmP1z0kL2: XpOsU3v5dqH8MQAK6FcafmP1z0kL2 = XpOsU3v5dqH8MQAK6FcafmP1z0kL2+c4QSTnPiWUCjhrLlwGB(u"ࠪࢀ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠨࠪ஛")
		elif wwyUWMFAsO(u"ࠫ࡭ࡺࡴࡱࠩஜ") in XpOsU3v5dqH8MQAK6FcafmP1z0kL2.lower() and Ej67fFyoqW8kbV2HdSK(u"ࠬ࠵ࡤࡢࡵ࡫࠳ࠬ஝") not in XpOsU3v5dqH8MQAK6FcafmP1z0kL2 and kmdSKeBIwViM9t3(u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫஞ") not in XpOsU3v5dqH8MQAK6FcafmP1z0kL2:
			if OVmSuf8tpd(u"ࠧࡷࡧࡵ࡭࡫ࡿࡰࡦࡧࡵࡁࠬட") not in XpOsU3v5dqH8MQAK6FcafmP1z0kL2 and sArCMRngQNmXkBoKv(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࠪ஠") in XpOsU3v5dqH8MQAK6FcafmP1z0kL2.lower():
				if AAgpHN0nMZ(u"ࠩࡿࠫ஡") not in XpOsU3v5dqH8MQAK6FcafmP1z0kL2: XpOsU3v5dqH8MQAK6FcafmP1z0kL2 = XpOsU3v5dqH8MQAK6FcafmP1z0kL2+aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠪࢀࡻ࡫ࡲࡪࡨࡼࡴࡪ࡫ࡲ࠾ࡨࡤࡰࡸ࡫ࠧ஢")
				else: XpOsU3v5dqH8MQAK6FcafmP1z0kL2 = XpOsU3v5dqH8MQAK6FcafmP1z0kL2+FhcnOB9t3frzvXb(u"ࠫࠫࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࡩࡥࡱࡹࡥࠨண")
			if sArCMRngQNmXkBoKv(u"ࠬࡻࡳࡦࡴ࠰ࡥ࡬࡫࡮ࡵࠩத") not in XpOsU3v5dqH8MQAK6FcafmP1z0kL2.lower() and ssnI4ASGlVvce79 not in [XogUJZEijT7KWbxeO6(u"࠭ࡉࡑࡖ࡙ࠫ஥"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧࡎ࠵ࡘࠫ஦")]:
				if hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠨࡾࠪ஧") not in XpOsU3v5dqH8MQAK6FcafmP1z0kL2: XpOsU3v5dqH8MQAK6FcafmP1z0kL2 = XpOsU3v5dqH8MQAK6FcafmP1z0kL2+XogUJZEijT7KWbxeO6(u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠧࠩந")
				else: XpOsU3v5dqH8MQAK6FcafmP1z0kL2 = XpOsU3v5dqH8MQAK6FcafmP1z0kL2+jYaM5vilgZdFx6QHbApwVXO8et(u"࡚ࠪࠪࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠨࠪன")
	tr24ZoudmqvxfYCw(XogUJZEijT7KWbxeO6(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪப"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+pEo8g7riWVL014KaRtzQ(u"ࠬࠦࠠࠡࡉࡲࡸࠥ࡬ࡩ࡯ࡣ࡯ࠤࡺࡸ࡬࡚ࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭஫")+XpOsU3v5dqH8MQAK6FcafmP1z0kL2+AAgpHN0nMZ(u"࠭ࠠ࡞ࠩ஬"))
	NLWPSbyQGephakUFs5mOu7lKEX = kGEPsyxKnHDJ.ListItem()
	IgNryh38O4iuY9ZQd,qDBsizKL2w,exjaDckuA9M,uMlyLGznmKW0ej3bdUX7piF2h9IP8g,C3CUrDxjTcfdEQ8B,EExKW3DenGU8b,U2NbDeiFrw1T7cz9qmEO,ga0MNsKDV9mAiJvwCx8HB,hCf5knZr2i9MmNGyb1Su3zAvlEYq = q0tgURwzEOJIYc27DbG4aT(VPIEsaiROZwmp20Jdn8WrA7c3Y)
	if ssnI4ASGlVvce79 not in [jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩ஭"),xuYvdJpOEyQKTLNwb(u"ࠨࡋࡓࡘ࡛࠭ம")]:
		if Yd6t3PjlLKk: cM4tBu8Z60z7 = eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳࡡࡥࡦࡲࡲࠬய")
		else: cM4tBu8Z60z7 = FhcnOB9t3frzvXb(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭ࠨர")
		NLWPSbyQGephakUFs5mOu7lKEX.setProperty(cM4tBu8Z60z7, aVLSn1xw5cK(u"ࠫࠬற"))
		NLWPSbyQGephakUFs5mOu7lKEX.setMimeType(yTMWeCgUROcvtsblfK85L62xPk(u"ࠬࡳࡩ࡮ࡧ࠲ࡼ࠲ࡺࡹࡱࡧࠪல"))
		if V8US2yZAg0QXJebWIHKD5xFa<m6b7CoBk4EQ(u"࠸࠰౰"): NLWPSbyQGephakUFs5mOu7lKEX.setInfo(gnfv8UtZ3daGqpjzk(u"࠭ࡶࡪࡦࡨࡳࠬள"),{PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠧ࡮ࡧࡧ࡭ࡦࡺࡹࡱࡧࠪழ"):aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨ࡯ࡲࡺ࡮࡫ࠧவ")})
		else:
			SCpKYv3MrylGHtbA1dNTUafZ = NLWPSbyQGephakUFs5mOu7lKEX.getVideoInfoTag()
			SCpKYv3MrylGHtbA1dNTUafZ.setMediaType(fR68jBGWCzUsFXdlTKPOScugm(u"ࠩࡰࡳࡻ࡯ࡥࠨஶ"))
		NLWPSbyQGephakUFs5mOu7lKEX.setArt({bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪࡸ࡭ࡻ࡭ࡣࠩஷ"):C3CUrDxjTcfdEQ8B,JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࡵࡵࡳࡵࡧࡵࠫஸ"):C3CUrDxjTcfdEQ8B,gSmqZU0plur2xKPJwQA(u"ࠬࡨࡡ࡯ࡰࡨࡶࠬஹ"):C3CUrDxjTcfdEQ8B,wwyUWMFAsO(u"࠭ࡦࡢࡰࡤࡶࡹ࠭஺"):C3CUrDxjTcfdEQ8B,JMLhEyaBWmskovGHTrVCxQ08(u"ࠧࡤ࡮ࡨࡥࡷࡧࡲࡵࠩ஻"):C3CUrDxjTcfdEQ8B,FhcnOB9t3frzvXb(u"ࠨࡥ࡯ࡩࡦࡸ࡬ࡰࡩࡲࠫ஼"):C3CUrDxjTcfdEQ8B,Ej67fFyoqW8kbV2HdSK(u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩࠬ஽"):C3CUrDxjTcfdEQ8B,hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠪ࡭ࡨࡵ࡮ࠨா"):C3CUrDxjTcfdEQ8B})
		if n2wpUdA6KX4kLjJGxZWVieycPg in [LmcNhzY6fQPd2JyCGslkSr(u"ࠫ࠳ࡳࡰࡥࠩி"),xuYvdJpOEyQKTLNwb(u"ࠬ࠴࡭࠴ࡷ࠻ࠫீ")]: NLWPSbyQGephakUFs5mOu7lKEX.setContentLookup(kmdSKeBIwViM9t3(u"ࡕࡴࡸࡩಇ"))
		else: NLWPSbyQGephakUFs5mOu7lKEX.setContentLookup(fR68jBGWCzUsFXdlTKPOScugm(u"ࡈࡤࡰࡸ࡫ಈ"))
		from bYGAkzJECs import tTsLa8vMRzfgoVxdwkeW0DXCpKbPn
		if Ej67fFyoqW8kbV2HdSK(u"࠭ࡲࡵ࡯ࡳࠫு") in XpOsU3v5dqH8MQAK6FcafmP1z0kL2:
			tTsLa8vMRzfgoVxdwkeW0DXCpKbPn(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡸࡴ࡮ࡲࠪூ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࡉࡥࡱࡹࡥಉ"))
		elif n2wpUdA6KX4kLjJGxZWVieycPg==kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨ࠰ࡰࡴࡩ࠭௃") or AAgpHN0nMZ(u"ࠩ࠲ࡨࡦࡹࡨ࠰ࠩ௄") in XpOsU3v5dqH8MQAK6FcafmP1z0kL2:
			tTsLa8vMRzfgoVxdwkeW0DXCpKbPn(Ej67fFyoqW8kbV2HdSK(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ௅"),m6b7CoBk4EQ(u"ࡊࡦࡲࡳࡦಊ"))
			NLWPSbyQGephakUFs5mOu7lKEX.setProperty(cM4tBu8Z60z7,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫெ"))
			NLWPSbyQGephakUFs5mOu7lKEX.setProperty(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩ࠳ࡳࡡ࡯࡫ࡩࡩࡸࡺ࡟ࡵࡻࡳࡩࠬே"),gSmqZU0plur2xKPJwQA(u"࠭࡭ࡱࡦࠪை"))
		if FFhkuSjpZ5csd7bBGt9Rrqw3lm:
			NLWPSbyQGephakUFs5mOu7lKEX.setSubtitles([FFhkuSjpZ5csd7bBGt9Rrqw3lm])
	if IgNryh38O4iuY9ZQd==m6b7CoBk4EQ(u"ࠧࡷ࡫ࡧࡩࡴ࠭௉") and ssnI4ASGlVvce79==jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪொ"):
		OBSvfy3cbl = c4QSTnPiWUCjhrLlwGB(u"ࠩࡳࡰࡦࡿ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩோ")
		ssnI4ASGlVvce79 = fR68jBGWCzUsFXdlTKPOScugm(u"ࠪࡔࡑࡇ࡙ࡠࡆࡏࡣࡋࡏࡌࡆࡕࠪௌ")
	elif IgNryh38O4iuY9ZQd==kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫࡻ࡯ࡤࡦࡱ்ࠪ") and ga0MNsKDV9mAiJvwCx8HB.startswith(aVLSn1xw5cK(u"ࠬ࠼ࠧ௎")):
		OBSvfy3cbl = gnfv8UtZ3daGqpjzk(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ௏")
		ssnI4ASGlVvce79 = ssnI4ASGlVvce79+wwyUWMFAsO(u"ࠧࡠࡆࡏࠫௐ")
	if OBSvfy3cbl!=LmcNhzY6fQPd2JyCGslkSr(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ௑"): UyKd8a0phrm()
	a5d7nLKXDJ = i4L2GE7hQ5M9()
	a5d7nLKXDJ.nNVDjqC23E8i9oeOkrZbBQ1S(ssnI4ASGlVvce79)
	if a5d7nLKXDJ.OBSvfy3cbl: return jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠪ௒")
	if IgNryh38O4iuY9ZQd==fR68jBGWCzUsFXdlTKPOScugm(u"ࠪࡺ࡮ࡪࡥࡰࠩ௓") and not ga0MNsKDV9mAiJvwCx8HB.startswith(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠫ࠻࠭௔")):
		NLWPSbyQGephakUFs5mOu7lKEX.setPath(XpOsU3v5dqH8MQAK6FcafmP1z0kL2)
		tr24ZoudmqvxfYCw(Ej67fFyoqW8kbV2HdSK(u"ࠬࡔࡏࡕࡋࡆࡉࠬ௕"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+pEo8g7riWVL014KaRtzQ(u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡲ࡯ࡥࡾࠦࡵࡴ࡫ࡱ࡫ࠥࡹࡥࡵࡔࡨࡷࡴࡲࡶࡦࡦࡘࡶࡱ࠮࡚ࠩࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭௖")+XpOsU3v5dqH8MQAK6FcafmP1z0kL2+OVmSuf8tpd(u"ࠧࠡ࡟ࠪௗ"))
		pZrEWcFVmiNCjozM.setResolvedUrl(jVGRimgPZeu9l0dsUoHJ1a,OVmSuf8tpd(u"࡙ࡸࡵࡦಋ"),NLWPSbyQGephakUFs5mOu7lKEX)
	elif IgNryh38O4iuY9ZQd==aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨ࡮࡬ࡺࡪ࠭௘"):
		tr24ZoudmqvxfYCw(aVLSn1xw5cK(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ௙"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+yTMWeCgUROcvtsblfK85L62xPk(u"ࠪࠤࠥࠦࡌࡪࡸࡨࠤࡵࡲࡡࡺࠢࡸࡷ࡮ࡴࡧࠡࡲ࡯ࡥࡾ࠮࡚ࠩࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭௚")+XpOsU3v5dqH8MQAK6FcafmP1z0kL2+FhcnOB9t3frzvXb(u"ࠫࠥࡣࠧ௛"))
		a5d7nLKXDJ.play(XpOsU3v5dqH8MQAK6FcafmP1z0kL2,NLWPSbyQGephakUFs5mOu7lKEX)
	ybf3Qo7isaYVr = aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࡌࡡ࡭ࡵࡨಌ")
	if OBSvfy3cbl==JMLhEyaBWmskovGHTrVCxQ08(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ௜"):
		from L1Zo20tErl import YYGwvozNbHknlU4
		ybf3Qo7isaYVr = YYGwvozNbHknlU4(XpOsU3v5dqH8MQAK6FcafmP1z0kL2,n2wpUdA6KX4kLjJGxZWVieycPg,ssnI4ASGlVvce79)
		if ybf3Qo7isaYVr: UyKd8a0phrm()
	else:
		DyGfNV3WpHzPF2CL,OBSvfy3cbl,EgBQkIlP1K,Ng4bwmrOKMal16Y7tQ,y4nkpFeV57IOJTAlH = yTMWeCgUROcvtsblfK85L62xPk(u"࠰౱"),yTMWeCgUROcvtsblfK85L62xPk(u"࠭ࡴࡳ࡫ࡨࡨࠬ௝"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࡆࡢ࡮ࡶࡩ಍"),sArCMRngQNmXkBoKv(u"࠳࠳࠴࠵౳"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠵࠷࠳࠴࠵౲")
		if djQBSOYN1kF7s: from j3x780FpaM import NLVM3HAtxQOSvJf6kd78K1o
		while DyGfNV3WpHzPF2CL<y4nkpFeV57IOJTAlH:
			cPwDBuG4HVTCdQ9JmMeoWjNY2hX.sleep(Ng4bwmrOKMal16Y7tQ)
			DyGfNV3WpHzPF2CL += Ng4bwmrOKMal16Y7tQ
			if a5d7nLKXDJ.OBSvfy3cbl==aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࠨ௞") and not EgBQkIlP1K:
				if djQBSOYN1kF7s: NLVM3HAtxQOSvJf6kd78K1o(ZSJVq5XDrRot(u"ࠨ่ฯัฯูࠦๆๆํอࠥะิ฻์็ࠤฬ๊แ๋ัํ์ࠬ௟"),J3OCAmZVcn(u"ࠩࡖࡹࡨࡩࡥࡴࡵࠪ௠"),luMHeSgCBaPrb9KvUjNFqcR=JMLhEyaBWmskovGHTrVCxQ08(u"࠺࠹࠵౴"))
				tr24ZoudmqvxfYCw(ZSJVq5XDrRot(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ௡"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+FhcnOB9t3frzvXb(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪࡹࡳ࠻࡚ࠢࠣ࡮ࡪࡥࡰࠢࡶࡸࡦࡸࡴࡦࡦࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨ௢")+XpOsU3v5dqH8MQAK6FcafmP1z0kL2+PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬࠦ࡝ࠨ௣")+QDNfiRwV3lqT9sK4SWnery0z)
				EgBQkIlP1K = FhcnOB9t3frzvXb(u"ࡕࡴࡸࡩಎ")
			elif a5d7nLKXDJ.OBSvfy3cbl in [JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ௤"),wwyUWMFAsO(u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨ௥")]:
				tr24ZoudmqvxfYCw(m6b7CoBk4EQ(u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ௦"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+kmdSKeBIwViM9t3(u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࡘ࡬ࡨࡪࡵࠠࡱ࡮ࡤࡽ࡮ࡴࡧ࡚ࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭௧")+XpOsU3v5dqH8MQAK6FcafmP1z0kL2+pEo8g7riWVL014KaRtzQ(u"ࠪࠤࡢ࠭௨")+QDNfiRwV3lqT9sK4SWnery0z)
				break
			elif a5d7nLKXDJ.OBSvfy3cbl==fR68jBGWCzUsFXdlTKPOScugm(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ௩"):
				tr24ZoudmqvxfYCw(Ej67fFyoqW8kbV2HdSK(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ௪"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡳࡰࡦࡿࡩ࡯ࡩࠣࡺ࡮ࡪࡥࡰࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧ௫")+XpOsU3v5dqH8MQAK6FcafmP1z0kL2+bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࠡ࡟ࠪ௬")+QDNfiRwV3lqT9sK4SWnery0z)
				if djQBSOYN1kF7s: NLVM3HAtxQOSvJf6kd78K1o(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠨใื่ฯูࠦๆๆํอࠥะิ฻์็ࠤฬ๊แ๋ัํ์ࠬ௭"),gSmqZU0plur2xKPJwQA(u"ࠩࡉࡥ࡮ࡲࡵࡳࡧࠪ௮"),luMHeSgCBaPrb9KvUjNFqcR=m6b7CoBk4EQ(u"࠻࠺࠶౵"))
				break
			elif a5d7nLKXDJ.OBSvfy3cbl==wwyUWMFAsO(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ௯"):
				tr24ZoudmqvxfYCw(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠫࡊࡘࡒࡐࡔࠪ௰"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+ZSJVq5XDrRot(u"ࠬࠦࠠࠡࡆࡨࡺ࡮ࡩࡥࠡ࡫ࡶࠤࡧࡲ࡯ࡤ࡭ࡨࡨࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪ௱")+XpOsU3v5dqH8MQAK6FcafmP1z0kL2+EDPaWgMt1SwNn8o(u"࠭ࠠ࡞ࠩ௲"))
				break
		else:
			if djQBSOYN1kF7s: NLVM3HAtxQOSvJf6kd78K1o(wwyUWMFAsO(u"ࠧโึ็ฮࠥ฿ๅๅ์ฬࠤฯฺฺ๋ๆࠣห้็๊ะ์๋ࠫ௳"),gnfv8UtZ3daGqpjzk(u"ࠨࡖ࡬ࡱࡪࡵࡵࡵࠩ௴"),luMHeSgCBaPrb9KvUjNFqcR=PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠼࠻࠰౶"))
			tr24ZoudmqvxfYCw(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ௵"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+J3OCAmZVcn(u"ࠪࠤࠥࠦࡔࡪ࡯ࡨࡳࡺࡺ࠺ࠡࠢࡘࡲࡰࡴ࡯ࡸࡰࠣࡴࡷࡵࡢ࡭ࡧࡰࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩ௶")+XpOsU3v5dqH8MQAK6FcafmP1z0kL2+c4QSTnPiWUCjhrLlwGB(u"ࠫࠥࡣࠧ௷")+QDNfiRwV3lqT9sK4SWnery0z)
			OBSvfy3cbl = JMLhEyaBWmskovGHTrVCxQ08(u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭௸")
	if OBSvfy3cbl in [ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭ࡰ࡭ࡣࡼࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭௹")] or a5d7nLKXDJ.OBSvfy3cbl in [OVmSuf8tpd(u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ௺"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨࡶࡨࡷࡹ࡯࡮ࡨࠩ௻")] or ybf3Qo7isaYVr:
		if a5d7nLKXDJ.OBSvfy3cbl==XogUJZEijT7KWbxeO6(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪ௼"): ssnI4ASGlVvce79 = ssnI4ASGlVvce79+xuYvdJpOEyQKTLNwb(u"ࠪࡣ࡙࡙ࠧ௽")
		wvdJxFK9nk = PEdiNj9D3ZtIcy1anJwVQYfkzM8W0b(ssnI4ASGlVvce79)
	else: exec(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠫ࡮ࡳࡰࡰࡴࡷࠤࡽࡨ࡭ࡤ࠽ࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰ࡶࡸࡴࡶࠨࠪࠩ௾"))
	return a5d7nLKXDJ.OBSvfy3cbl
def fDEdQSsq1uPoU(XpOsU3v5dqH8MQAK6FcafmP1z0kL2):
	if VYMZsxRpcQHPgkaiDKjyoh: from urllib.parse import urlparse
	else: from urlparse import urlparse
	path = urlparse(XpOsU3v5dqH8MQAK6FcafmP1z0kL2).path
	OOzUf6uIsgARa5VJ = ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬ࠭௿") if kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭࠮ࠨఀ") not in path else path.rsplit(OVmSuf8tpd(u"ࠧ࠯ࠩఁ"),FhcnOB9t3frzvXb(u"࠷౷"))[FhcnOB9t3frzvXb(u"࠷౷")]
	if OOzUf6uIsgARa5VJ in [fR68jBGWCzUsFXdlTKPOScugm(u"ࠨࡣࡹ࡭ࠬం"),sArCMRngQNmXkBoKv(u"ࠩࡷࡷࠬః"),FhcnOB9t3frzvXb(u"ࠪࡥࡦࡩࠧఄ"),xuYvdJpOEyQKTLNwb(u"ࠫࡲࡶ࠴ࠨఅ"),J3OCAmZVcn(u"ࠬࡳ࠳ࡶࠩఆ"),JMLhEyaBWmskovGHTrVCxQ08(u"࠭࡭࠴ࡷ࠻ࠫఇ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧ࡮ࡲࡧࠫఈ"),kmdSKeBIwViM9t3(u"ࠨ࡯࡮ࡺࠬఉ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩࡩࡰࡻ࠭ఊ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪࡱࡵ࠹ࠧఋ"),ZSJVq5XDrRot(u"ࠫࡼ࡫ࡢ࡮ࠩఌ")]: return m6b7CoBk4EQ(u"ࠬ࠴ࠧ఍")+OOzUf6uIsgARa5VJ
	return DLSVmlyBbCK(u"࠭ࠧఎ")
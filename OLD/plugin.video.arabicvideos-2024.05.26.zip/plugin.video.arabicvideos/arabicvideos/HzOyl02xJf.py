# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'GLOBALSEARCH'
W74fAyGxODoLPs5vMX2l8C93R = '_GLS_'
def OVQIAezo6U1NSTl4L(nnPsf4XLIJ7RWF,gC2hO80boRyM7TBGqD,uHGMxiZfcoErOyXghvnWUK,wwNtFTLK2IqAszYBDV9J):
	if   nnPsf4XLIJ7RWF==540: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif nnPsf4XLIJ7RWF==541: HkKfQCS7RIa4xi3houjvl = JJI5YlwvUM6Ond1ejoXi(uHGMxiZfcoErOyXghvnWUK)
	elif nnPsf4XLIJ7RWF==542: HkKfQCS7RIa4xi3houjvl = iljuYoahcSVCn1M2Wf8sm3Ixvr7(uHGMxiZfcoErOyXghvnWUK,gC2hO80boRyM7TBGqD,wwNtFTLK2IqAszYBDV9J)
	elif nnPsf4XLIJ7RWF==549: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(uHGMxiZfcoErOyXghvnWUK)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','بحث جديد','',549)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008]==== كلمات مخزنة ====[/COLOR]','',9999)
	Hvt70WOi5CGePh = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,'dict','GLOBALSEARCH_SITES')
	if Hvt70WOi5CGePh:
		Hvt70WOi5CGePh = Hvt70WOi5CGePh['__SEQUENCED_COLUMNS__']
		for GlveBZnj3sLDrPIpJ64oi2aYW in reversed(Hvt70WOi5CGePh):
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',GlveBZnj3sLDrPIpJ64oi2aYW,'',549,'','',GlveBZnj3sLDrPIpJ64oi2aYW)
	return
def F6OgHwYPRiX10tJEv8r(GlveBZnj3sLDrPIpJ64oi2aYW):
	if not GlveBZnj3sLDrPIpJ64oi2aYW:
		GlveBZnj3sLDrPIpJ64oi2aYW = CjyEnpfQ23o0PYwDtLId()
		if not GlveBZnj3sLDrPIpJ64oi2aYW: return
		GlveBZnj3sLDrPIpJ64oi2aYW = GlveBZnj3sLDrPIpJ64oi2aYW.lower()
	C7i9Byuo4DsraGHAjKJE0nzk5q = GlveBZnj3sLDrPIpJ64oi2aYW.replace(W74fAyGxODoLPs5vMX2l8C93R,'')
	hxj2HRSZzPb0Wt6(C7i9Byuo4DsraGHAjKJE0nzk5q)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','عمل بحث جماعي - '+C7i9Byuo4DsraGHAjKJE0nzk5q,'search_sites',542,'','',C7i9Byuo4DsraGHAjKJE0nzk5q)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','عمل بحث منفرد - '+C7i9Byuo4DsraGHAjKJE0nzk5q,'',541,'','',C7i9Byuo4DsraGHAjKJE0nzk5q)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','نتائج البحث مفصلة - '+C7i9Byuo4DsraGHAjKJE0nzk5q,'opened_sites',542,'','',C7i9Byuo4DsraGHAjKJE0nzk5q)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','نتائج البحث مقسمة - '+C7i9Byuo4DsraGHAjKJE0nzk5q,'listed_sites',542,'','',C7i9Byuo4DsraGHAjKJE0nzk5q)
	return
def hxj2HRSZzPb0Wt6(f6ry85hsTURtYngxeF02P4m):
	vSI9whDCme7A0gp = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,'list','GLOBALSEARCH_SITES',f6ry85hsTURtYngxeF02P4m)
	aatTwpLRXo = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,'list','GLOBALSEARCH_SITES',W74fAyGxODoLPs5vMX2l8C93R+f6ry85hsTURtYngxeF02P4m)
	ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,'GLOBALSEARCH_SITES',f6ry85hsTURtYngxeF02P4m)
	ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,'GLOBALSEARCH_SITES',W74fAyGxODoLPs5vMX2l8C93R+f6ry85hsTURtYngxeF02P4m)
	tnrTD8q9UWbha6ZlMScACv74 = vSI9whDCme7A0gp+aatTwpLRXo
	if tnrTD8q9UWbha6ZlMScACv74: f6ry85hsTURtYngxeF02P4m = W74fAyGxODoLPs5vMX2l8C93R+f6ry85hsTURtYngxeF02P4m
	Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,'GLOBALSEARCH_SITES',f6ry85hsTURtYngxeF02P4m,tnrTD8q9UWbha6ZlMScACv74,tteHTjUArw)
	return
def O2uRfkS5dcYy():
	YYkEu4IL0sTa = OxCB4medn1('','','','رسالة من المبرمج','هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if YYkEu4IL0sTa!=1: return
	ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,'GLOBALSEARCH_SITES')
	ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,'GLOBALSEARCH_OPENED')
	ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,'GLOBALSEARCH_CLOSED')
	HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def iljuYoahcSVCn1M2Wf8sm3Ixvr7(rFDuyVaqjoWT,V3SYnJLe0k4WmfbICZHhoPiQz27qyl,ji1dGuYnsFNKe=''):
	YfUqJmLF4nC9hEzHc1rKVsdSxp,rUJWCZLnMfk701q8icY,k1Ty7whgNI8mEf405ZxFJjKSGbVvOp,ahuUtRLXjv,WEsj5BD7oKwFOlbZGy,HJSsWNBcl56vjpxgUnbhIyuP1RqV2z,pYszTMCOeWg = [],[],[],{},{},{},{}
	if V3SYnJLe0k4WmfbICZHhoPiQz27qyl!='search_sites':
		if V3SYnJLe0k4WmfbICZHhoPiQz27qyl=='listed_sites': k1Ty7whgNI8mEf405ZxFJjKSGbVvOp = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,'list','GLOBALSEARCH_SITES',W74fAyGxODoLPs5vMX2l8C93R+rFDuyVaqjoWT)
		elif V3SYnJLe0k4WmfbICZHhoPiQz27qyl=='opened_sites': k1Ty7whgNI8mEf405ZxFJjKSGbVvOp = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,'list','GLOBALSEARCH_OPENED',rFDuyVaqjoWT)
		elif V3SYnJLe0k4WmfbICZHhoPiQz27qyl=='closed_sites': k1Ty7whgNI8mEf405ZxFJjKSGbVvOp = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,'list','GLOBALSEARCH_CLOSED',(ji1dGuYnsFNKe,rFDuyVaqjoWT))
	if not k1Ty7whgNI8mEf405ZxFJjKSGbVvOp:
		uu5SDqLcCs7IUA = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		zzPuKeTq6I4gHrRA3aUDmEpVyl = 'هل تريد الآن البحث في جميع المواقع عن \n "[COLOR FFFFFF00] '+rFDuyVaqjoWT+' [/COLOR]" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if V3SYnJLe0k4WmfbICZHhoPiQz27qyl=='search_sites': LaX1QCyeIJ = zzPuKeTq6I4gHrRA3aUDmEpVyl
		else: LaX1QCyeIJ = uu5SDqLcCs7IUA+zzPuKeTq6I4gHrRA3aUDmEpVyl
		YYkEu4IL0sTa = OxCB4medn1('','','','رسالة من المبرمج',LaX1QCyeIJ)
		if YYkEu4IL0sTa!=1: return
		K18gduYeq29CsrQN(False,False,False)
		tr24ZoudmqvxfYCw('NOTICE',RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+'   Search For: [ '+rFDuyVaqjoWT+' ]')
		m0mMg8vwH6jylZYaLE = 1
		for ji1dGuYnsFNKe in g84gfDrBtVRb1KM7o5:
			ahuUtRLXjv[ji1dGuYnsFNKe] = []
			xdWIA3KvVbtMaszgNPyZEn9fQ = '_NODIALOGS_'
			if '-' in ji1dGuYnsFNKe: xdWIA3KvVbtMaszgNPyZEn9fQ = xdWIA3KvVbtMaszgNPyZEn9fQ+'_REMEMBERRESULTS__'+ji1dGuYnsFNKe+'_'
			terDuEzAxwJBMfij2Z3VTyOn5bU,hRXOg9EUnHF,dGbUpZ6N7WX52BLmR4vfz = Cqb7Pp23AvmRTwQhjroY68uKE4ye(ji1dGuYnsFNKe)
			if m0mMg8vwH6jylZYaLE:
				luMHeSgCBaPrb9KvUjNFqcR.sleep(0.75)
				pYszTMCOeWg[ji1dGuYnsFNKe] = c3cgVjNv1rde.Thread(target=hRXOg9EUnHF,args=(rFDuyVaqjoWT+xdWIA3KvVbtMaszgNPyZEn9fQ,))
				pYszTMCOeWg[ji1dGuYnsFNKe].start()
			else: hRXOg9EUnHF(rFDuyVaqjoWT+xdWIA3KvVbtMaszgNPyZEn9fQ)
			NLVM3HAtxQOSvJf6kd78K1o(Po4CyOusDaWq6pbIjYV(ji1dGuYnsFNKe),'',luMHeSgCBaPrb9KvUjNFqcR=1000)
		if m0mMg8vwH6jylZYaLE:
			luMHeSgCBaPrb9KvUjNFqcR.sleep(2)
			for ji1dGuYnsFNKe in g84gfDrBtVRb1KM7o5:
				pYszTMCOeWg[ji1dGuYnsFNKe].join(10)
			luMHeSgCBaPrb9KvUjNFqcR.sleep(2)
		for ji1dGuYnsFNKe in g84gfDrBtVRb1KM7o5:
			terDuEzAxwJBMfij2Z3VTyOn5bU,hRXOg9EUnHF,dGbUpZ6N7WX52BLmR4vfz = Cqb7Pp23AvmRTwQhjroY68uKE4ye(ji1dGuYnsFNKe)
			for lTyPebYg7CFcwJuWBvkH2LQr5MGp in OWasmQ27g3Dbljpo:
				RGDQbxHAi1UpIuNveqTFXSw9gZjc4,aaYDh2EzJ5ky,gC2hO80boRyM7TBGqD,nnPsf4XLIJ7RWF,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,uHGMxiZfcoErOyXghvnWUK,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw = lTyPebYg7CFcwJuWBvkH2LQr5MGp
				if dGbUpZ6N7WX52BLmR4vfz in aaYDh2EzJ5ky:
					if 'IPTV-' in ji1dGuYnsFNKe and (239>=nnPsf4XLIJ7RWF>=230 or 289>=nnPsf4XLIJ7RWF>=280):
						if lTyPebYg7CFcwJuWBvkH2LQr5MGp in ahuUtRLXjv['IPTV-LIVE']: continue
						if lTyPebYg7CFcwJuWBvkH2LQr5MGp in ahuUtRLXjv['IPTV-MOVIES']: continue
						if lTyPebYg7CFcwJuWBvkH2LQr5MGp in ahuUtRLXjv['IPTV-SERIES']: continue
						if 'صفحة' not in aaYDh2EzJ5ky:
							if   RGDQbxHAi1UpIuNveqTFXSw9gZjc4=='live': ji1dGuYnsFNKe = 'IPTV-LIVE'
							elif RGDQbxHAi1UpIuNveqTFXSw9gZjc4=='video': ji1dGuYnsFNKe = 'IPTV-MOVIES'
							elif RGDQbxHAi1UpIuNveqTFXSw9gZjc4=='folder': ji1dGuYnsFNKe = 'IPTV-SERIES'
						else:
							if   'LIVE' in gC2hO80boRyM7TBGqD: ji1dGuYnsFNKe = 'IPTV-LIVE'
							elif 'MOVIES' in gC2hO80boRyM7TBGqD: ji1dGuYnsFNKe = 'IPTV-MOVIES'
							elif 'SERIES' in gC2hO80boRyM7TBGqD: ji1dGuYnsFNKe = 'IPTV-SERIES'
					elif 'M3U-' in ji1dGuYnsFNKe and 729>=nnPsf4XLIJ7RWF>=710:
						if lTyPebYg7CFcwJuWBvkH2LQr5MGp in ahuUtRLXjv['M3U-LIVE']: continue
						if lTyPebYg7CFcwJuWBvkH2LQr5MGp in ahuUtRLXjv['M3U-MOVIES']: continue
						if lTyPebYg7CFcwJuWBvkH2LQr5MGp in ahuUtRLXjv['M3U-SERIES']: continue
						if 'صفحة' not in aaYDh2EzJ5ky:
							if   RGDQbxHAi1UpIuNveqTFXSw9gZjc4=='live': ji1dGuYnsFNKe = 'M3U-LIVE'
							elif RGDQbxHAi1UpIuNveqTFXSw9gZjc4=='video': ji1dGuYnsFNKe = 'M3U-MOVIES'
							elif RGDQbxHAi1UpIuNveqTFXSw9gZjc4=='folder': ji1dGuYnsFNKe = 'M3U-SERIES'
						else:
							if   'LIVE' in gC2hO80boRyM7TBGqD: ji1dGuYnsFNKe = 'M3U-LIVE'
							elif 'MOVIES' in gC2hO80boRyM7TBGqD: ji1dGuYnsFNKe = 'M3U-MOVIES'
							elif 'SERIES' in gC2hO80boRyM7TBGqD: ji1dGuYnsFNKe = 'M3U-SERIES'
					elif 'YOUTUBE-' in ji1dGuYnsFNKe and 149>=nnPsf4XLIJ7RWF>=140:
						if lTyPebYg7CFcwJuWBvkH2LQr5MGp in ahuUtRLXjv['YOUTUBE-CHANNELS']: continue
						if lTyPebYg7CFcwJuWBvkH2LQr5MGp in ahuUtRLXjv['YOUTUBE-PLAYLISTS']: continue
						if lTyPebYg7CFcwJuWBvkH2LQr5MGp in ahuUtRLXjv['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in aaYDh2EzJ5ky or ':: ' in aaYDh2EzJ5ky:
							continue
						else:
							if   nnPsf4XLIJ7RWF==144 and 'USER' in aaYDh2EzJ5ky: ji1dGuYnsFNKe = 'YOUTUBE-CHANNELS'
							elif nnPsf4XLIJ7RWF==144 and 'CHNL' in aaYDh2EzJ5ky: ji1dGuYnsFNKe = 'YOUTUBE-CHANNELS'
							elif nnPsf4XLIJ7RWF==144 and 'LIST' in aaYDh2EzJ5ky: ji1dGuYnsFNKe = 'YOUTUBE-PLAYLISTS'
							elif nnPsf4XLIJ7RWF==143: ji1dGuYnsFNKe = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in ji1dGuYnsFNKe and 419>=nnPsf4XLIJ7RWF>=400:
						if lTyPebYg7CFcwJuWBvkH2LQr5MGp in ahuUtRLXjv['DAILYMOTION-PLAYLISTS']: continue
						if lTyPebYg7CFcwJuWBvkH2LQr5MGp in ahuUtRLXjv['DAILYMOTION-CHANNELS']: continue
						if lTyPebYg7CFcwJuWBvkH2LQr5MGp in ahuUtRLXjv['DAILYMOTION-VIDEOS']: continue
						if lTyPebYg7CFcwJuWBvkH2LQr5MGp in ahuUtRLXjv['DAILYMOTION-TOPICS']: continue
						if   nnPsf4XLIJ7RWF in [401,405]: ji1dGuYnsFNKe = 'DAILYMOTION-PLAYLISTS'
						elif nnPsf4XLIJ7RWF in [402,406]: ji1dGuYnsFNKe = 'DAILYMOTION-CHANNELS'
						elif nnPsf4XLIJ7RWF in [404]: ji1dGuYnsFNKe = 'DAILYMOTION-VIDEOS'
						elif nnPsf4XLIJ7RWF in [415]: ji1dGuYnsFNKe = 'DAILYMOTION-LIVES'
						elif nnPsf4XLIJ7RWF in [412,413]: ji1dGuYnsFNKe = 'DAILYMOTION-TOPICS'
					elif 'PANET-' in ji1dGuYnsFNKe and 39>=nnPsf4XLIJ7RWF>=30:
						if lTyPebYg7CFcwJuWBvkH2LQr5MGp in ahuUtRLXjv['PANET-SERIES']: continue
						if lTyPebYg7CFcwJuWBvkH2LQr5MGp in ahuUtRLXjv['PANET-MOVIES']: continue
						if   nnPsf4XLIJ7RWF in [32,39]: ji1dGuYnsFNKe = 'PANET-SERIES'
						elif nnPsf4XLIJ7RWF in [33,39]: ji1dGuYnsFNKe = 'PANET-MOVIES'
					elif 'IFILM-' in ji1dGuYnsFNKe and 29>=nnPsf4XLIJ7RWF>=20:
						if lTyPebYg7CFcwJuWBvkH2LQr5MGp in ahuUtRLXjv['IFILM-ARABIC']: continue
						if lTyPebYg7CFcwJuWBvkH2LQr5MGp in ahuUtRLXjv['IFILM-ENGLISH']: continue
						if   '/ar.' in gC2hO80boRyM7TBGqD: ji1dGuYnsFNKe = 'IFILM-ARABIC'
						elif '/en.' in gC2hO80boRyM7TBGqD: ji1dGuYnsFNKe = 'IFILM-ENGLISH'
					ahuUtRLXjv[ji1dGuYnsFNKe].append(lTyPebYg7CFcwJuWBvkH2LQr5MGp)
		OWasmQ27g3Dbljpo[:] = []
		for ji1dGuYnsFNKe in list(ahuUtRLXjv.keys()):
			WEsj5BD7oKwFOlbZGy[ji1dGuYnsFNKe] = []
			HJSsWNBcl56vjpxgUnbhIyuP1RqV2z[ji1dGuYnsFNKe] = []
			for RGDQbxHAi1UpIuNveqTFXSw9gZjc4,aaYDh2EzJ5ky,gC2hO80boRyM7TBGqD,nnPsf4XLIJ7RWF,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,uHGMxiZfcoErOyXghvnWUK,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw in ahuUtRLXjv[ji1dGuYnsFNKe]:
				lTyPebYg7CFcwJuWBvkH2LQr5MGp = (RGDQbxHAi1UpIuNveqTFXSw9gZjc4,aaYDh2EzJ5ky,gC2hO80boRyM7TBGqD,nnPsf4XLIJ7RWF,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,uHGMxiZfcoErOyXghvnWUK,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw)
				if 'صفحة' in aaYDh2EzJ5ky and RGDQbxHAi1UpIuNveqTFXSw9gZjc4=='folder': HJSsWNBcl56vjpxgUnbhIyuP1RqV2z[ji1dGuYnsFNKe].append(lTyPebYg7CFcwJuWBvkH2LQr5MGp)
				else: WEsj5BD7oKwFOlbZGy[ji1dGuYnsFNKe].append(lTyPebYg7CFcwJuWBvkH2LQr5MGp)
		f7NMZlxd04URyTcQP12ieD8ILho = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157,'','','','','')]
		for ji1dGuYnsFNKe in aaPxVDR1EFfA9ghw2:
			if ji1dGuYnsFNKe==wLGYuyAbjiocERx8sHZpaOFUKdfN[0]: f7NMZlxd04URyTcQP12ieD8ILho = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة وعامة - كثيرة المشاكل[/COLOR]','',157,'','','','','')]
			elif ji1dGuYnsFNKe==FKY2egH1L8xQyvNClp[0]: f7NMZlxd04URyTcQP12ieD8ILho = [('link','[COLOR FFC89008]مواقع سيرفرات عامة - كثيرة المشاكل[/COLOR]','',157,'','','','','')]
			elif ji1dGuYnsFNKe==r16Wf3imkv4BGhq5bReoxEpgzUsdw9[0]: f7NMZlxd04URyTcQP12ieD8ILho = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157,'','','','','')]
			if ji1dGuYnsFNKe not in WEsj5BD7oKwFOlbZGy.keys(): continue
			if WEsj5BD7oKwFOlbZGy[ji1dGuYnsFNKe]:
				UGLYEn0ZFq3pB = Po4CyOusDaWq6pbIjYV(ji1dGuYnsFNKe)
				BBSwjl6XP3tiFMOImAH = [('link','[COLOR FFFFFF00]===== '+UGLYEn0ZFq3pB+' =====[/COLOR]','',9999,'','','','','')]
				if 0: Ig47qX0snrWYQORGBE = rFDuyVaqjoWT+' - '+'بحث'+' '+UGLYEn0ZFq3pB
				else: Ig47qX0snrWYQORGBE = 'بحث'+' '+UGLYEn0ZFq3pB+' - '+rFDuyVaqjoWT
				if len(WEsj5BD7oKwFOlbZGy[ji1dGuYnsFNKe])<8: lGemKHMAn46ygh50xLP3QSDqrb = []
				else:
					TwkqGgQ4YnXlz2JKyBd6Za = '[COLOR FFC89008]'+Ig47qX0snrWYQORGBE+'[/COLOR]'
					lGemKHMAn46ygh50xLP3QSDqrb = [('folder',W74fAyGxODoLPs5vMX2l8C93R+TwkqGgQ4YnXlz2JKyBd6Za,'closed_sites',542,'',ji1dGuYnsFNKe,rFDuyVaqjoWT,'','')]
				TJP8lujRUQ6dYoL2Fxey9ws = WEsj5BD7oKwFOlbZGy[ji1dGuYnsFNKe]+HJSsWNBcl56vjpxgUnbhIyuP1RqV2z[ji1dGuYnsFNKe]
				rUJWCZLnMfk701q8icY += f7NMZlxd04URyTcQP12ieD8ILho+BBSwjl6XP3tiFMOImAH+TJP8lujRUQ6dYoL2Fxey9ws[:7]+lGemKHMAn46ygh50xLP3QSDqrb
				py9AYFekvzo0qVJ7h3 = [('folder',W74fAyGxODoLPs5vMX2l8C93R+Ig47qX0snrWYQORGBE,'closed_sites',542,'',ji1dGuYnsFNKe,rFDuyVaqjoWT,'','')]
				YfUqJmLF4nC9hEzHc1rKVsdSxp += f7NMZlxd04URyTcQP12ieD8ILho+py9AYFekvzo0qVJ7h3
				f7NMZlxd04URyTcQP12ieD8ILho = []
				Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,'GLOBALSEARCH_CLOSED',(ji1dGuYnsFNKe,rFDuyVaqjoWT),TJP8lujRUQ6dYoL2Fxey9ws,tteHTjUArw)
		Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,'GLOBALSEARCH_OPENED',rFDuyVaqjoWT,rUJWCZLnMfk701q8icY,tteHTjUArw)
		ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,'GLOBALSEARCH_SITES',rFDuyVaqjoWT)
		Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,'GLOBALSEARCH_SITES',W74fAyGxODoLPs5vMX2l8C93R+rFDuyVaqjoWT,YfUqJmLF4nC9hEzHc1rKVsdSxp,tteHTjUArw)
		HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم لكي تستطيع العودة إليها بدون عمل بحث جديد')
		if V3SYnJLe0k4WmfbICZHhoPiQz27qyl=='listed_sites' and YfUqJmLF4nC9hEzHc1rKVsdSxp: k1Ty7whgNI8mEf405ZxFJjKSGbVvOp = YfUqJmLF4nC9hEzHc1rKVsdSxp
		else: k1Ty7whgNI8mEf405ZxFJjKSGbVvOp = rUJWCZLnMfk701q8icY
	if V3SYnJLe0k4WmfbICZHhoPiQz27qyl!='search_sites':
		for RGDQbxHAi1UpIuNveqTFXSw9gZjc4,aaYDh2EzJ5ky,gC2hO80boRyM7TBGqD,nnPsf4XLIJ7RWF,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,uHGMxiZfcoErOyXghvnWUK,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw in k1Ty7whgNI8mEf405ZxFJjKSGbVvOp:
			if V3SYnJLe0k4WmfbICZHhoPiQz27qyl in ['listed_sites','opened_sites'] and 'صفحة' in aaYDh2EzJ5ky and RGDQbxHAi1UpIuNveqTFXSw9gZjc4=='folder': continue
			Tca7NsYPkIRWtBpFgxLZbSmCi(RGDQbxHAi1UpIuNveqTFXSw9gZjc4,aaYDh2EzJ5ky,gC2hO80boRyM7TBGqD,nnPsf4XLIJ7RWF,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,uHGMxiZfcoErOyXghvnWUK,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw)
	K18gduYeq29CsrQN('','','')
	return
def JJI5YlwvUM6Ond1ejoXi(rFDuyVaqjoWT=''):
	GlveBZnj3sLDrPIpJ64oi2aYW,xdWIA3KvVbtMaszgNPyZEn9fQ,showDialogs = XDzpr8RxgZhT(rFDuyVaqjoWT)
	if not GlveBZnj3sLDrPIpJ64oi2aYW:
		GlveBZnj3sLDrPIpJ64oi2aYW = CjyEnpfQ23o0PYwDtLId()
		if not GlveBZnj3sLDrPIpJ64oi2aYW: return
		GlveBZnj3sLDrPIpJ64oi2aYW = GlveBZnj3sLDrPIpJ64oi2aYW.lower()
	tr24ZoudmqvxfYCw('NOTICE',RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+'   Search For: [ '+GlveBZnj3sLDrPIpJ64oi2aYW+' ]')
	H9IMP4eTVW8dji3EXnS7w = GlveBZnj3sLDrPIpJ64oi2aYW+xdWIA3KvVbtMaszgNPyZEn9fQ
	if 0: bbxIwkuXpSML2v,C7i9Byuo4DsraGHAjKJE0nzk5q = GlveBZnj3sLDrPIpJ64oi2aYW+' - ',''
	else: bbxIwkuXpSML2v,C7i9Byuo4DsraGHAjKJE0nzk5q = '',' - '+GlveBZnj3sLDrPIpJ64oi2aYW
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_M3U_'+bbxIwkuXpSML2v+'بحث M3U'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',719,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_IPT_'+bbxIwkuXpSML2v+'بحث IPTV'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',239,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_BKR_'+bbxIwkuXpSML2v+'بحث موقع بكرا'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',379,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_ART_'+bbxIwkuXpSML2v+'بحث موقع تونز عربية'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',739,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_KRB_'+bbxIwkuXpSML2v+'بحث موقع قناة كربلاء'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',329,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_FH1_'+bbxIwkuXpSML2v+'بحث موقع فاصل الأول'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',579,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_KTV_'+bbxIwkuXpSML2v+'بحث موقع كتكوت تيفي'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',819,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_EB1_'+bbxIwkuXpSML2v+'بحث موقع ايجي بيست 1'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',779,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_EB2_'+bbxIwkuXpSML2v+'بحث موقع ايجي بيست 2'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',789,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_IFL_'+bbxIwkuXpSML2v+'  بحث موقع قناة آي فيلم'+C7i9Byuo4DsraGHAjKJE0nzk5q+'  ','',29,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_AKO_'+bbxIwkuXpSML2v+'بحث موقع أكوام القديم'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',79,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_AKW_'+bbxIwkuXpSML2v+'بحث موقع أكوام الجديد'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',249,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_MRF_'+bbxIwkuXpSML2v+'بحث موقع قناة المعارف'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',49,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_SHM_'+bbxIwkuXpSML2v+'بحث موقع شوف ماكس'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',59,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008]مواقع سيرفرات خاصة وعامة - كثيرة المشاكل[/COLOR]','',157)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_FJS_'+bbxIwkuXpSML2v+' بحث موقع فجر شو'+C7i9Byuo4DsraGHAjKJE0nzk5q+' ','',399,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_TVF_'+bbxIwkuXpSML2v+'بحث موقع تيفي فان'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',469,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_LDN_'+bbxIwkuXpSML2v+'بحث موقع لودي نت'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',459,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_CMN_'+bbxIwkuXpSML2v+'بحث موقع سيما ناو'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',309,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_WCM_'+bbxIwkuXpSML2v+'بحث موقع وي سيما'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',569,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_SHN_'+bbxIwkuXpSML2v+'بحث موقع شاهد نيوز'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',589,'','',H9IMP4eTVW8dji3EXnS7w+'_NODIALOGS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_ARS_'+bbxIwkuXpSML2v+'بحث موقع عرب سييد'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',259,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_CCB_'+bbxIwkuXpSML2v+'بحث موقع سيما كلوب'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',829,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_SH4_'+bbxIwkuXpSML2v+'بحث موقع شاهد فوريو'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',119,'','',H9IMP4eTVW8dji3EXnS7w+'_NODIALOGS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_SHT_'+bbxIwkuXpSML2v+'بحث موقع شوفها تيفي'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',649,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008]مواقع سيرفرات عامة - كثيرة المشاكل[/COLOR]','',157)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_FST_'+bbxIwkuXpSML2v+'بحث موقع فوستا'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',609,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_FBK_'+bbxIwkuXpSML2v+'بحث موقع فبركة'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',629,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_YQT_'+bbxIwkuXpSML2v+'بحث موقع ياقوت'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',669,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_BRS_'+bbxIwkuXpSML2v+'بحث موقع برستيج'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',659,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_HLC_'+bbxIwkuXpSML2v+'بحث موقع هلا سيما'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',89,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_DR7_'+bbxIwkuXpSML2v+'بحث موقع دراما صح'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',689,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_CMF_'+bbxIwkuXpSML2v+'بحث موقع سيما فانز'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',99,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_CML_'+bbxIwkuXpSML2v+'بحث موقع سيما لايت'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',479,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_ABD_'+bbxIwkuXpSML2v+'بحث موقع سيما عبدو'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',559,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_C4H_'+bbxIwkuXpSML2v+'بحث موقع سيما 400'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',699,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_AHK_'+bbxIwkuXpSML2v+'بحث موقع أهواك تيفي'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',619,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_EB4_'+bbxIwkuXpSML2v+'بحث موقع ايجي بيست 4'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',809,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_YUT_'+bbxIwkuXpSML2v+'بحث موقع يوتيوب'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',149,'','',H9IMP4eTVW8dji3EXnS7w)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_DLM_'+bbxIwkuXpSML2v+'بحث موقع ديلي موشن'+C7i9Byuo4DsraGHAjKJE0nzk5q,'',409,'','',H9IMP4eTVW8dji3EXnS7w)
	return
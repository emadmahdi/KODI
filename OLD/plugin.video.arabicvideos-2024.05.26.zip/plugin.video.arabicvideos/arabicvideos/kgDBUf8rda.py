# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'YOUTUBE'
W74fAyGxODoLPs5vMX2l8C93R = '_YUT_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
def OVQIAezo6U1NSTl4L(mode,url,text,type,wwNtFTLK2IqAszYBDV9J):
	if	 mode==140: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==143: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url,type)
	elif mode==144: HkKfQCS7RIa4xi3houjvl = J2K0qdYZMhG(url,text,wwNtFTLK2IqAszYBDV9J)
	elif mode==145: HkKfQCS7RIa4xi3houjvl = P7Z0G9vzMOlnidteTSwVsQCa6Ah3xp(url)
	elif mode==146: HkKfQCS7RIa4xi3houjvl = gZyV9WPudrJMSUGCKsm(url)
	elif mode==147: HkKfQCS7RIa4xi3houjvl = ZAiFwv4qXaQVumyYc3G0KUPzkl()
	elif mode==148: HkKfQCS7RIa4xi3houjvl = bLXle32UrFNAH1CVKgDEa0YftP5x()
	elif mode==149: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',149,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+'_YTC_'+'مواقع اختارها المبرمج','',290)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'مواقع اختارها يوتيوب',JJTrn6SEtYZV31eyR97+'/feed/guide_builder',144)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'الصفحة الرئيسية',JJTrn6SEtYZV31eyR97,144,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'المحتوى الرائج',JJTrn6SEtYZV31eyR97+'/feed/trending',146)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'بحث: قنوات عربية','',147)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'بحث: قنوات أجنبية','',148)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'بحث: افلام عربية',JJTrn6SEtYZV31eyR97+'/results?search_query=فيلم',144)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'بحث: افلام اجنبية',JJTrn6SEtYZV31eyR97+'/results?search_query=movie',144)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'بحث: مسرحيات عربية',JJTrn6SEtYZV31eyR97+'/results?search_query=مسرحية',144)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'بحث: مسلسلات عربية',JJTrn6SEtYZV31eyR97+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'بحث: مسلسلات اجنبية',JJTrn6SEtYZV31eyR97+'/results?search_query=series&sp=EgIQAw==',144)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'بحث: مسلسلات كارتون',JJTrn6SEtYZV31eyR97+'/results?search_query=كارتون&sp=EgIQAw==',144)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'بحث: خطبة المرجعية',JJTrn6SEtYZV31eyR97+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def ZAiFwv4qXaQVumyYc3G0KUPzkl():
	J2K0qdYZMhG(JJTrn6SEtYZV31eyR97+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def bLXle32UrFNAH1CVKgDEa0YftP5x():
	J2K0qdYZMhG(JJTrn6SEtYZV31eyR97+'/results?search_query=tv&sp=EgJAAQ==')
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url,type):
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs([url],ll6f2wvU4FdqL3MJyDxORESCK197i,type,url)
	return
def gZyV9WPudrJMSUGCKsm(url):
	QstumvzTIEUMXCcx06aD4y8nSqH,nRseEAQwXo4jC21gmqPzIihfUc,data = TBHlpjUZ35mnoC6(url)
	Lc6NP8nrxwSYEv4ktQhIZVjT = nRseEAQwXo4jC21gmqPzIihfUc['contents']['twoColumnBrowseResultsRenderer']['tabs']
	for OeT2Jo0sp6h1mGdqfFw in range(len(Lc6NP8nrxwSYEv4ktQhIZVjT)):
		q8BXZlN9sU1fP2JAxH7W = Lc6NP8nrxwSYEv4ktQhIZVjT[OeT2Jo0sp6h1mGdqfFw]
		KxAIS18pWBYyF6bJCMw5PtL(q8BXZlN9sU1fP2JAxH7W,url,str(OeT2Jo0sp6h1mGdqfFw))
	wq5hOslEjUpCSuGmHQ = Lc6NP8nrxwSYEv4ktQhIZVjT[0]['tabRenderer']['content']['sectionListRenderer']['contents']
	cyWlgtOdGq6avPCwHADxYmTUNJ = 0
	for OeT2Jo0sp6h1mGdqfFw in range(len(wq5hOslEjUpCSuGmHQ)):
		q8BXZlN9sU1fP2JAxH7W = wq5hOslEjUpCSuGmHQ[OeT2Jo0sp6h1mGdqfFw]['itemSectionRenderer']['contents'][0]
		if list(q8BXZlN9sU1fP2JAxH7W['shelfRenderer']['content'].keys())[0]=='horizontalListRenderer': continue
		Q4o2IDnNJzcYe,title,RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,count,UombAD0Kk4XqOrYLB,u4u1TsmL6PDz2jW,oUX2bhl8gK5TRZc = u3DhGNOAY0ZS71pitafPy4d(q8BXZlN9sU1fP2JAxH7W)
		if not title:
			cyWlgtOdGq6avPCwHADxYmTUNJ += 1
			title = 'فيديوهات رائجة '+str(cyWlgtOdGq6avPCwHADxYmTUNJ)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,144,'',str(OeT2Jo0sp6h1mGdqfFw))
	key = ZXFs0mEPR8qI2zj.findall('"innertubeApiKey":"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	lQHXdV9Nzf6BLqS8D = 'https://www.youtube.com/youtubei/v1/guide?key='+key[0]
	QstumvzTIEUMXCcx06aD4y8nSqH,nRseEAQwXo4jC21gmqPzIihfUc,BTMputsaqV = TBHlpjUZ35mnoC6(lQHXdV9Nzf6BLqS8D)
	for TzRI3GLUr9laoJNeDd1O8kW in range(3,4):
		Lc6NP8nrxwSYEv4ktQhIZVjT = nRseEAQwXo4jC21gmqPzIihfUc['items'][TzRI3GLUr9laoJNeDd1O8kW]['guideSectionRenderer']['items']
		for OeT2Jo0sp6h1mGdqfFw in range(len(Lc6NP8nrxwSYEv4ktQhIZVjT)):
			q8BXZlN9sU1fP2JAxH7W = Lc6NP8nrxwSYEv4ktQhIZVjT[OeT2Jo0sp6h1mGdqfFw]
			if 'YouTube Premium' in str(q8BXZlN9sU1fP2JAxH7W): continue
			KxAIS18pWBYyF6bJCMw5PtL(q8BXZlN9sU1fP2JAxH7W)
	return
def J2K0qdYZMhG(url,data='',index=0):
	global j2agIU0xsLS6c7T
	if not data: data = j2agIU0xsLS6c7T.getSetting('av.youtube.data')
	if index: index = int(index)
	else: index = 0
	data = data.replace('_REMEMBERRESULTS_','')
	QstumvzTIEUMXCcx06aD4y8nSqH,nRseEAQwXo4jC21gmqPzIihfUc,BTMputsaqV = TBHlpjUZ35mnoC6(url,data)
	e4LiD3xgMzabsKPqj,k6zf2PxpoCMbtSZcueRTs = '',''
	uk4V7BxXanKgeGcjAqDQLJ26SRr59d = ZXFs0mEPR8qI2zj.findall('"ownerName".*?":"(.*?)".*?"url":"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not uk4V7BxXanKgeGcjAqDQLJ26SRr59d: uk4V7BxXanKgeGcjAqDQLJ26SRr59d = ZXFs0mEPR8qI2zj.findall('"videoOwner".*?"text":"(.*?)".*?"url":"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not uk4V7BxXanKgeGcjAqDQLJ26SRr59d: uk4V7BxXanKgeGcjAqDQLJ26SRr59d = ZXFs0mEPR8qI2zj.findall('"channelMetadataRenderer":\{"title":"(.*?)".*?"ownerUrls":\["(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if uk4V7BxXanKgeGcjAqDQLJ26SRr59d:
		e4LiD3xgMzabsKPqj = '[COLOR FFC89008]'+uk4V7BxXanKgeGcjAqDQLJ26SRr59d[0][0]+'[/COLOR]'
		RRucmYBaXegTtNOdGHMQ = uk4V7BxXanKgeGcjAqDQLJ26SRr59d[0][1]
		if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
		if 'list=' in url: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+e4LiD3xgMzabsKPqj,RRucmYBaXegTtNOdGHMQ,144)
	uuVBnZiUbL5rXhTfzK3EaQ7Y9wIpc = ['/search','/videos','/channels','/playlists','/featured','ss=','ctoken=','key=','bp=','shelf_id=']
	evd0P9TIifonDEaL = not any(AARNPWHjQU9dEmDI in url for AARNPWHjQU9dEmDI in uuVBnZiUbL5rXhTfzK3EaQ7Y9wIpc)
	if evd0P9TIifonDEaL and e4LiD3xgMzabsKPqj:
		QCDVzPGHj6IxMA = 'البحث'
		Wu4CadwRTJfkbXMUVxO3jQ2 = 'قوائم التشغيل'
		IIa6whCNrJmkRXeMqTb23lgB = 'الفيديوهات'
		iFPsmk8AQ7VcTynof6XWze = 'القنوات'
		Tca7NsYPkIRWtBpFgxLZbSmCi('link',W74fAyGxODoLPs5vMX2l8C93R+e4LiD3xgMzabsKPqj,url,9999)
		if '"title":"بحث"' in QstumvzTIEUMXCcx06aD4y8nSqH: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+QCDVzPGHj6IxMA,url,145,'','','_REMEMBERRESULTS_')
		if '"title":"قوائم التشغيل"' in QstumvzTIEUMXCcx06aD4y8nSqH: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+Wu4CadwRTJfkbXMUVxO3jQ2,url+'/playlists',144)
		if '"title":"الفيديوهات"' in QstumvzTIEUMXCcx06aD4y8nSqH: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+IIa6whCNrJmkRXeMqTb23lgB,url+'/videos',144)
		if '"title":"القنوات"' in QstumvzTIEUMXCcx06aD4y8nSqH: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+iFPsmk8AQ7VcTynof6XWze,url+'/channels',144)
		if '"title":"Search"' in QstumvzTIEUMXCcx06aD4y8nSqH: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+QCDVzPGHj6IxMA,url,145,'','','_REMEMBERRESULTS_')
		if '"title":"Playlists"' in QstumvzTIEUMXCcx06aD4y8nSqH: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+Wu4CadwRTJfkbXMUVxO3jQ2,url+'/playlists',144)
		if '"title":"Videos"' in QstumvzTIEUMXCcx06aD4y8nSqH: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+IIa6whCNrJmkRXeMqTb23lgB,url+'/videos',144)
		if '"title":"Channels"' in QstumvzTIEUMXCcx06aD4y8nSqH: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+iFPsmk8AQ7VcTynof6XWze,url+'/channels',144)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	if 'search_query' in url:
		Lc6NP8nrxwSYEv4ktQhIZVjT = nRseEAQwXo4jC21gmqPzIihfUc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']
		VUKIbynRmDpri = 0
		for xxFhvt275i8MdUVuPkSXzmbT in range(len(Lc6NP8nrxwSYEv4ktQhIZVjT)):
			if 'itemSectionRenderer' in list(Lc6NP8nrxwSYEv4ktQhIZVjT[xxFhvt275i8MdUVuPkSXzmbT].keys()):
				IIa01Jh3cAQVNHW = Lc6NP8nrxwSYEv4ktQhIZVjT[xxFhvt275i8MdUVuPkSXzmbT]['itemSectionRenderer']
				aCjFiMNJDG = len(str(IIa01Jh3cAQVNHW))
				if aCjFiMNJDG>VUKIbynRmDpri:
					VUKIbynRmDpri = aCjFiMNJDG
					k6zf2PxpoCMbtSZcueRTs = IIa01Jh3cAQVNHW
		if VUKIbynRmDpri==0: return
	elif '&list=' in url or '/search?key=' in url or '/browse?key=' in url or 'ctoken=' in url or '/search' in url or url==JJTrn6SEtYZV31eyR97:
		FF9E6MD1B8WA0NKG = []
		FF9E6MD1B8WA0NKG.append("cc['onResponseReceivedCommands'][0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']")
		FF9E6MD1B8WA0NKG.append("cc['onResponseReceivedActions'][0]['appendContinuationItemsAction']['continuationItems']")
		FF9E6MD1B8WA0NKG.append("cc[1]['response']['continuationContents']['sectionListContinuation']")
		FF9E6MD1B8WA0NKG.append("cc[1]['response']['continuationContents']['gridContinuation']['items']")
		FF9E6MD1B8WA0NKG.append("cc[1]['response']['continuationContents']['playlistVideoListContinuation']")
		FF9E6MD1B8WA0NKG.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][-1]['expandableTabRenderer']['content']['sectionListRenderer']")
		FF9E6MD1B8WA0NKG.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']")
		FF9E6MD1B8WA0NKG.append("cc['contents']['twoColumnWatchNextResults']['playlist']['playlist']")
		UUGrK2dnvY9H1oq4bP,k6zf2PxpoCMbtSZcueRTs = hwpMgCYmHbtzjNXk9UiGuVOexWaQ(nRseEAQwXo4jC21gmqPzIihfUc,'',FF9E6MD1B8WA0NKG)
	if not k6zf2PxpoCMbtSZcueRTs:
		try:
			Lc6NP8nrxwSYEv4ktQhIZVjT = nRseEAQwXo4jC21gmqPzIihfUc['contents']['twoColumnBrowseResultsRenderer']['tabs']
			ssBUod0JflaI3OMm = '/videos' in url or '/playlists' in url or '/channels' in url
			r0JBLYPDMs1uNZvmIH5flkqcajVR = '"title":"الفيديوهات"' in QstumvzTIEUMXCcx06aD4y8nSqH or '"title":"قوائم التشغيل"' in QstumvzTIEUMXCcx06aD4y8nSqH or '"title":"القنوات"' in QstumvzTIEUMXCcx06aD4y8nSqH
			w26e1uNxWlXMzVBqUAsdfO4kgS8G = '"title":"Videos"' in QstumvzTIEUMXCcx06aD4y8nSqH or '"title":"Playlists"' in QstumvzTIEUMXCcx06aD4y8nSqH or '"title":"Channels"' in QstumvzTIEUMXCcx06aD4y8nSqH
			if ssBUod0JflaI3OMm and (r0JBLYPDMs1uNZvmIH5flkqcajVR or w26e1uNxWlXMzVBqUAsdfO4kgS8G):
				for OeT2Jo0sp6h1mGdqfFw in range(len(Lc6NP8nrxwSYEv4ktQhIZVjT)):
					if 'tabRenderer' not in list(Lc6NP8nrxwSYEv4ktQhIZVjT[OeT2Jo0sp6h1mGdqfFw].keys()): continue
					wq5hOslEjUpCSuGmHQ = Lc6NP8nrxwSYEv4ktQhIZVjT[OeT2Jo0sp6h1mGdqfFw]['tabRenderer']
					try: epMjgH7uZbRiBdFQ16y0r4sPWw = wq5hOslEjUpCSuGmHQ['content']['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems'][OeT2Jo0sp6h1mGdqfFw]
					except: epMjgH7uZbRiBdFQ16y0r4sPWw = wq5hOslEjUpCSuGmHQ
					try: RRucmYBaXegTtNOdGHMQ = epMjgH7uZbRiBdFQ16y0r4sPWw['endpoint']['commandMetadata']['webCommandMetadata']['url']
					except: continue
					if   '/videos'		in RRucmYBaXegTtNOdGHMQ	and '/videos'		in url: wq5hOslEjUpCSuGmHQ = Lc6NP8nrxwSYEv4ktQhIZVjT[OeT2Jo0sp6h1mGdqfFw] ; break
					elif '/playlists'	in RRucmYBaXegTtNOdGHMQ	and '/playlists'	in url: wq5hOslEjUpCSuGmHQ = Lc6NP8nrxwSYEv4ktQhIZVjT[OeT2Jo0sp6h1mGdqfFw] ; break
					elif '/channels'	in RRucmYBaXegTtNOdGHMQ	and '/channels'		in url: wq5hOslEjUpCSuGmHQ = Lc6NP8nrxwSYEv4ktQhIZVjT[OeT2Jo0sp6h1mGdqfFw] ; break
					else: wq5hOslEjUpCSuGmHQ = Lc6NP8nrxwSYEv4ktQhIZVjT[0]
			elif 'bp=' in url: wq5hOslEjUpCSuGmHQ = Lc6NP8nrxwSYEv4ktQhIZVjT[index]
			else: wq5hOslEjUpCSuGmHQ = Lc6NP8nrxwSYEv4ktQhIZVjT[0]
			k6zf2PxpoCMbtSZcueRTs = wq5hOslEjUpCSuGmHQ['tabRenderer']['content']
		except: pass
	if not k6zf2PxpoCMbtSZcueRTs: return
	FF9E6MD1B8WA0NKG = []
	FF9E6MD1B8WA0NKG.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	FF9E6MD1B8WA0NKG.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	FF9E6MD1B8WA0NKG.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	FF9E6MD1B8WA0NKG.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	FF9E6MD1B8WA0NKG.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['cards']")
	FF9E6MD1B8WA0NKG.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	FF9E6MD1B8WA0NKG.append("ff['sectionListRenderer']['contents'][int(index)]['richSectionRenderer']['content']")
	if 'view=' not in url: FF9E6MD1B8WA0NKG.append("ff['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems']")
	FF9E6MD1B8WA0NKG.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	FF9E6MD1B8WA0NKG.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	FF9E6MD1B8WA0NKG.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	FF9E6MD1B8WA0NKG.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	FF9E6MD1B8WA0NKG.append("ff['sectionListRenderer']['contents']")
	FF9E6MD1B8WA0NKG.append("ff['sectionListRenderer']")
	FF9E6MD1B8WA0NKG.append("ff['richGridRenderer']['contents']")
	FF9E6MD1B8WA0NKG.append("ff['contents']")
	FF9E6MD1B8WA0NKG.append("ff")
	gn28RboQ5cpSMq = PPMg73d1CAKIZS2hvHc5pLmXt4Fsez(u'كل قوائم التشغيل')
	CyZMRenVhLr4AzqlBGYQUWtdNk = PPMg73d1CAKIZS2hvHc5pLmXt4Fsez(u'كل الفيديوهات')
	uSV0XDyzd9YAQjU5ExR = PPMg73d1CAKIZS2hvHc5pLmXt4Fsez(u'كل القنوات')
	VJmCTk2lNPF0 = [gn28RboQ5cpSMq,CyZMRenVhLr4AzqlBGYQUWtdNk,uSV0XDyzd9YAQjU5ExR,'All playlists','All videos','All channels']
	FfWQLyAEIj3B6axUtSP4,epMjgH7uZbRiBdFQ16y0r4sPWw = hwpMgCYmHbtzjNXk9UiGuVOexWaQ(k6zf2PxpoCMbtSZcueRTs,index,FF9E6MD1B8WA0NKG)
	if 'list' in str(type(epMjgH7uZbRiBdFQ16y0r4sPWw)) and any(AARNPWHjQU9dEmDI in str(epMjgH7uZbRiBdFQ16y0r4sPWw[0]) for AARNPWHjQU9dEmDI in VJmCTk2lNPF0): del epMjgH7uZbRiBdFQ16y0r4sPWw[0]
	for KTPWbDAHS2kxNcB0j7nIhJdMCZ in range(len(epMjgH7uZbRiBdFQ16y0r4sPWw)):
		FF9E6MD1B8WA0NKG = []
		FF9E6MD1B8WA0NKG.append("gg[index2]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
		FF9E6MD1B8WA0NKG.append("gg[index2]['itemSectionRenderer']['header']")
		FF9E6MD1B8WA0NKG.append("gg[index2]['horizontalCardListRenderer']['header']")
		FF9E6MD1B8WA0NKG.append("gg[index2]['itemSectionRenderer']['contents'][0]")
		FF9E6MD1B8WA0NKG.append("gg[index2]['richSectionRenderer']['content']")
		FF9E6MD1B8WA0NKG.append("gg[index2]['richItemRenderer']['content']")
		FF9E6MD1B8WA0NKG.append("gg[index2]['gameCardRenderer']['game']")
		FF9E6MD1B8WA0NKG.append("gg[index2]")
		UUGrK2dnvY9H1oq4bP,q8BXZlN9sU1fP2JAxH7W = hwpMgCYmHbtzjNXk9UiGuVOexWaQ(epMjgH7uZbRiBdFQ16y0r4sPWw,KTPWbDAHS2kxNcB0j7nIhJdMCZ,FF9E6MD1B8WA0NKG)
		KxAIS18pWBYyF6bJCMw5PtL(q8BXZlN9sU1fP2JAxH7W,url,str(KTPWbDAHS2kxNcB0j7nIhJdMCZ))
		if UUGrK2dnvY9H1oq4bP=='4':
			try:
				J9bXIrhucvL4FzpBintDqoWTU7 = q8BXZlN9sU1fP2JAxH7W['shelfRenderer']['content']['horizontalMovieListRenderer']['items']
				for JYElAaxM0gZeH42WQi1cumj in range(len(J9bXIrhucvL4FzpBintDqoWTU7)):
					rrc9HRI5OA8oKfiDbw = J9bXIrhucvL4FzpBintDqoWTU7[JYElAaxM0gZeH42WQi1cumj]
					KxAIS18pWBYyF6bJCMw5PtL(rrc9HRI5OA8oKfiDbw)
			except: pass
	rzc5pxXnS1eFdMg = False
	if 'view=' not in url and FfWQLyAEIj3B6axUtSP4=='8': rzc5pxXnS1eFdMg = True
	if ':::' in BTMputsaqV: qv2xgQPCXsm3aWVSuYKTOwhy,key,FG1mX30dCxHyb5,WrKdzhw7QSCXGEA846t3fnvupj2Pe,Yhqjz4bLa1HB,N30U6gJYef1v = BTMputsaqV.split(':::')
	else: qv2xgQPCXsm3aWVSuYKTOwhy,key,FG1mX30dCxHyb5,WrKdzhw7QSCXGEA846t3fnvupj2Pe,Yhqjz4bLa1HB,N30U6gJYef1v = '','','','','',''
	lQHXdV9Nzf6BLqS8D,jMD8RBfTGUlQwJCk = '',''
	if OWasmQ27g3Dbljpo:
		PGxBwAEDTbS6n78Xo3HidIJOsLNca = str(OWasmQ27g3Dbljpo[-1][1])
		if   W74fAyGxODoLPs5vMX2l8C93R+'CHNL' in PGxBwAEDTbS6n78Xo3HidIJOsLNca: jMD8RBfTGUlQwJCk = 'CHANNELS'
		elif W74fAyGxODoLPs5vMX2l8C93R+'USER' in PGxBwAEDTbS6n78Xo3HidIJOsLNca: jMD8RBfTGUlQwJCk = 'CHANNELS'
		elif W74fAyGxODoLPs5vMX2l8C93R+'LIST' in PGxBwAEDTbS6n78Xo3HidIJOsLNca: jMD8RBfTGUlQwJCk = 'PLAYLISTS'
	if '"continuations"' in QstumvzTIEUMXCcx06aD4y8nSqH and '&list=' not in url and not rzc5pxXnS1eFdMg and 'shelf_id' not in url:
		lQHXdV9Nzf6BLqS8D = JJTrn6SEtYZV31eyR97+'/browse_ajax?ctoken='+FG1mX30dCxHyb5
	elif '"token"' in QstumvzTIEUMXCcx06aD4y8nSqH and 'bp=' not in url and 'search_query' in url or 'search?key=' in url:
		lQHXdV9Nzf6BLqS8D = JJTrn6SEtYZV31eyR97+'/youtubei/v1/search?key='+key
	elif '"token"' in QstumvzTIEUMXCcx06aD4y8nSqH and 'bp=' not in url:
		lQHXdV9Nzf6BLqS8D = JJTrn6SEtYZV31eyR97+'/youtubei/v1/browse?key='+key
	if lQHXdV9Nzf6BLqS8D: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة أخرى',lQHXdV9Nzf6BLqS8D,144,jMD8RBfTGUlQwJCk,'',BTMputsaqV)
	return
def hwpMgCYmHbtzjNXk9UiGuVOexWaQ(ssMt96muVHx,umJRt83OTfvgsBzNi2V5L,rQFZhiOgTx0IPAEmoYC8ntv):
	nRseEAQwXo4jC21gmqPzIihfUc = ssMt96muVHx
	k6zf2PxpoCMbtSZcueRTs,index = ssMt96muVHx,umJRt83OTfvgsBzNi2V5L
	epMjgH7uZbRiBdFQ16y0r4sPWw,KTPWbDAHS2kxNcB0j7nIhJdMCZ = ssMt96muVHx,umJRt83OTfvgsBzNi2V5L
	q8BXZlN9sU1fP2JAxH7W,P45bBFUk8TZKX7n62AL3r1lxQVs = ssMt96muVHx,umJRt83OTfvgsBzNi2V5L
	count = len(rQFZhiOgTx0IPAEmoYC8ntv)
	for OeT2Jo0sp6h1mGdqfFw in range(count):
		try:
			RkLU63KnoA7fSxQ5EgBYpHis0wIj = eval(rQFZhiOgTx0IPAEmoYC8ntv[OeT2Jo0sp6h1mGdqfFw])
			return str(OeT2Jo0sp6h1mGdqfFw+1),RkLU63KnoA7fSxQ5EgBYpHis0wIj
		except: pass
	return '',''
def u3DhGNOAY0ZS71pitafPy4d(q8BXZlN9sU1fP2JAxH7W):
	try: LNeYbBgv50 = list(q8BXZlN9sU1fP2JAxH7W.keys())[0]
	except: return False,'','','','','','',''
	Q4o2IDnNJzcYe,title,RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,count,UombAD0Kk4XqOrYLB,u4u1TsmL6PDz2jW,oUX2bhl8gK5TRZc = False,'','','','','','',''
	P45bBFUk8TZKX7n62AL3r1lxQVs = q8BXZlN9sU1fP2JAxH7W[LNeYbBgv50]
	FF9E6MD1B8WA0NKG = []
	FF9E6MD1B8WA0NKG.append("render['unplayableText']['simpleText']")
	FF9E6MD1B8WA0NKG.append("render['formattedTitle']['simpleText']")
	FF9E6MD1B8WA0NKG.append("render['title']['simpleText']")
	FF9E6MD1B8WA0NKG.append("render['title']['runs'][0]['text']")
	FF9E6MD1B8WA0NKG.append("render['text']['simpleText']")
	FF9E6MD1B8WA0NKG.append("render['text']['runs'][0]['text']")
	FF9E6MD1B8WA0NKG.append("render['title']")
	FF9E6MD1B8WA0NKG.append("item['title']")
	UUGrK2dnvY9H1oq4bP,title = hwpMgCYmHbtzjNXk9UiGuVOexWaQ(q8BXZlN9sU1fP2JAxH7W,P45bBFUk8TZKX7n62AL3r1lxQVs,FF9E6MD1B8WA0NKG)
	FF9E6MD1B8WA0NKG = []
	FF9E6MD1B8WA0NKG.append("render['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	FF9E6MD1B8WA0NKG.append("render['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	FF9E6MD1B8WA0NKG.append("render['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	FF9E6MD1B8WA0NKG.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	UUGrK2dnvY9H1oq4bP,RRucmYBaXegTtNOdGHMQ = hwpMgCYmHbtzjNXk9UiGuVOexWaQ(q8BXZlN9sU1fP2JAxH7W,P45bBFUk8TZKX7n62AL3r1lxQVs,FF9E6MD1B8WA0NKG)
	FF9E6MD1B8WA0NKG = []
	FF9E6MD1B8WA0NKG.append("render['thumbnail']['thumbnails'][0]['url']")
	FF9E6MD1B8WA0NKG.append("render['thumbnails'][0]['thumbnails'][0]['url']")
	UUGrK2dnvY9H1oq4bP,CrGO63LT7j2UxniW = hwpMgCYmHbtzjNXk9UiGuVOexWaQ(q8BXZlN9sU1fP2JAxH7W,P45bBFUk8TZKX7n62AL3r1lxQVs,FF9E6MD1B8WA0NKG)
	FF9E6MD1B8WA0NKG = []
	FF9E6MD1B8WA0NKG.append("render['videoCount']")
	FF9E6MD1B8WA0NKG.append("render['videoCountText']['runs'][0]['text']")
	FF9E6MD1B8WA0NKG.append("render['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	UUGrK2dnvY9H1oq4bP,count = hwpMgCYmHbtzjNXk9UiGuVOexWaQ(q8BXZlN9sU1fP2JAxH7W,P45bBFUk8TZKX7n62AL3r1lxQVs,FF9E6MD1B8WA0NKG)
	FF9E6MD1B8WA0NKG = []
	FF9E6MD1B8WA0NKG.append("render['lengthText']['simpleText']")
	FF9E6MD1B8WA0NKG.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	FF9E6MD1B8WA0NKG.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	UUGrK2dnvY9H1oq4bP,UombAD0Kk4XqOrYLB = hwpMgCYmHbtzjNXk9UiGuVOexWaQ(q8BXZlN9sU1fP2JAxH7W,P45bBFUk8TZKX7n62AL3r1lxQVs,FF9E6MD1B8WA0NKG)
	if 'LIVE' in UombAD0Kk4XqOrYLB: UombAD0Kk4XqOrYLB,u4u1TsmL6PDz2jW = '','LIVE:  '
	if 'مباشر' in UombAD0Kk4XqOrYLB: UombAD0Kk4XqOrYLB,u4u1TsmL6PDz2jW = '','LIVE:  '
	if 'badges' in list(P45bBFUk8TZKX7n62AL3r1lxQVs.keys()):
		Gjw1Oko2AT6PItCHsWxYQuK9mV0an = str(P45bBFUk8TZKX7n62AL3r1lxQVs['badges'])
		if 'Free with Ads' in Gjw1Oko2AT6PItCHsWxYQuK9mV0an: oUX2bhl8gK5TRZc = '$:'
		if 'LIVE NOW' in Gjw1Oko2AT6PItCHsWxYQuK9mV0an: u4u1TsmL6PDz2jW = 'LIVE:  '
		if 'Buy' in Gjw1Oko2AT6PItCHsWxYQuK9mV0an or 'Rent' in Gjw1Oko2AT6PItCHsWxYQuK9mV0an: oUX2bhl8gK5TRZc = '$$:'
		if PPMg73d1CAKIZS2hvHc5pLmXt4Fsez(u'مباشر') in Gjw1Oko2AT6PItCHsWxYQuK9mV0an: u4u1TsmL6PDz2jW = 'LIVE:  '
		if PPMg73d1CAKIZS2hvHc5pLmXt4Fsez(u'شراء') in Gjw1Oko2AT6PItCHsWxYQuK9mV0an: oUX2bhl8gK5TRZc = '$$:'
		if PPMg73d1CAKIZS2hvHc5pLmXt4Fsez(u'استئجار') in Gjw1Oko2AT6PItCHsWxYQuK9mV0an: oUX2bhl8gK5TRZc = '$$:'
		if PPMg73d1CAKIZS2hvHc5pLmXt4Fsez(u'إعلانات') in Gjw1Oko2AT6PItCHsWxYQuK9mV0an: oUX2bhl8gK5TRZc = '$:'
	RRucmYBaXegTtNOdGHMQ = WhJe7bGx5XackTwOIZVLC8ut(RRucmYBaXegTtNOdGHMQ)
	if RRucmYBaXegTtNOdGHMQ and 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
	CrGO63LT7j2UxniW = CrGO63LT7j2UxniW.split('?')[0]
	if  CrGO63LT7j2UxniW and 'http' not in CrGO63LT7j2UxniW: CrGO63LT7j2UxniW = 'https:'+CrGO63LT7j2UxniW
	title = WhJe7bGx5XackTwOIZVLC8ut(title)
	if oUX2bhl8gK5TRZc: title = oUX2bhl8gK5TRZc+'  '+title
	UombAD0Kk4XqOrYLB = UombAD0Kk4XqOrYLB.replace(',','')
	count = count.replace(',','')
	count = ZXFs0mEPR8qI2zj.findall('\d+',count)
	if count: count = count[0]
	else: count = ''
	return True,title,RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,count,UombAD0Kk4XqOrYLB,u4u1TsmL6PDz2jW,oUX2bhl8gK5TRZc
def KxAIS18pWBYyF6bJCMw5PtL(q8BXZlN9sU1fP2JAxH7W,url='',index=''):
	Q4o2IDnNJzcYe,title,RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,count,UombAD0Kk4XqOrYLB,u4u1TsmL6PDz2jW,oUX2bhl8gK5TRZc = u3DhGNOAY0ZS71pitafPy4d(q8BXZlN9sU1fP2JAxH7W)
	if not Q4o2IDnNJzcYe: return
	elif 'continuationItemRenderer' in str(q8BXZlN9sU1fP2JAxH7W): return
	elif 'searchPyvRenderer' in str(q8BXZlN9sU1fP2JAxH7W): return
	elif not RRucmYBaXegTtNOdGHMQ and 'search_query' in url: return
	elif title and not RRucmYBaXegTtNOdGHMQ and ('search_query' in url or 'horizontalMovieListRenderer' in str(q8BXZlN9sU1fP2JAxH7W) or url==JJTrn6SEtYZV31eyR97):
		title = '=== '+title+' ==='
		Tca7NsYPkIRWtBpFgxLZbSmCi('link',W74fAyGxODoLPs5vMX2l8C93R+title,'',9999)
	elif title and 'messageRenderer' in str(q8BXZlN9sU1fP2JAxH7W):
		Tca7NsYPkIRWtBpFgxLZbSmCi('link',W74fAyGxODoLPs5vMX2l8C93R+title,'',9999)
	elif '/feed/trending' in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,144,CrGO63LT7j2UxniW,index)
	elif not title: return
	elif u4u1TsmL6PDz2jW: Tca7NsYPkIRWtBpFgxLZbSmCi('live',W74fAyGxODoLPs5vMX2l8C93R+u4u1TsmL6PDz2jW+title,RRucmYBaXegTtNOdGHMQ,143,CrGO63LT7j2UxniW)
	elif 'watch?v=' in RRucmYBaXegTtNOdGHMQ or '/shorts/' in RRucmYBaXegTtNOdGHMQ:
		if '&list=' in RRucmYBaXegTtNOdGHMQ and 'index=' not in RRucmYBaXegTtNOdGHMQ:
			zVi08rx2RYC6oXsTQHEdgPJeS = RRucmYBaXegTtNOdGHMQ.split('&list=',1)[1]
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/playlist?list='+zVi08rx2RYC6oXsTQHEdgPJeS
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'LIST'+count+':  '+title,RRucmYBaXegTtNOdGHMQ,144,CrGO63LT7j2UxniW)
		else:
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.split('&list=',1)[0]
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,143,CrGO63LT7j2UxniW,UombAD0Kk4XqOrYLB)
	else:
		type = ''
		if not RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = url
		elif not any(AARNPWHjQU9dEmDI in RRucmYBaXegTtNOdGHMQ for AARNPWHjQU9dEmDI in ['/videos','/playlists','/channels','/featured','ss=','bp=']):
			if '/channel/'	in RRucmYBaXegTtNOdGHMQ or '/c/' in RRucmYBaXegTtNOdGHMQ: type = 'CHNL'+count+':  '
			if '/user/' in RRucmYBaXegTtNOdGHMQ: type = 'USER'+count+':  '
			index,VV6yIHPAg2Ys3SuvlwWTCFX8ZN = '',''
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+type+title,RRucmYBaXegTtNOdGHMQ,144,CrGO63LT7j2UxniW,index)
	return
def TBHlpjUZ35mnoC6(url,data='',l3UpyxrXZ2=''):
	global j2agIU0xsLS6c7T
	if not data: data = j2agIU0xsLS6c7T.getSetting('av.youtube.data')
	if l3UpyxrXZ2=='': l3UpyxrXZ2 = 'ytInitialData'
	k0kUAjI76Erhgf = SjMG7CYyUqbPVso0DErhXROvkl()
	obS4TpHeV3digGC = {'User-Agent':k0kUAjI76Erhgf,'Cookie':'PREF=hl=ar'}
	if ':::' in data: qv2xgQPCXsm3aWVSuYKTOwhy,key,FG1mX30dCxHyb5,WrKdzhw7QSCXGEA846t3fnvupj2Pe,Yhqjz4bLa1HB,N30U6gJYef1v = data.split(':::')
	else: qv2xgQPCXsm3aWVSuYKTOwhy,key,FG1mX30dCxHyb5,WrKdzhw7QSCXGEA846t3fnvupj2Pe,Yhqjz4bLa1HB,N30U6gJYef1v = '','','','','',''
	if 'guide?key=' in url:
		BTMputsaqV = {}
		BTMputsaqV['context'] = {"client":{"hl":"ar","clientName":"WEB","clientVersion":WrKdzhw7QSCXGEA846t3fnvupj2Pe}}
		BTMputsaqV = str(BTMputsaqV)
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'POST',url,BTMputsaqV,obS4TpHeV3digGC,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif 'key=' in url and qv2xgQPCXsm3aWVSuYKTOwhy:
		BTMputsaqV = {'continuation':Yhqjz4bLa1HB}
		BTMputsaqV['context'] = {"client":{"visitorData":qv2xgQPCXsm3aWVSuYKTOwhy,"clientName":"WEB","clientVersion":WrKdzhw7QSCXGEA846t3fnvupj2Pe}}
		BTMputsaqV = str(BTMputsaqV)
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'POST',url,BTMputsaqV,obS4TpHeV3digGC,True,True,'YOUTUBE-GET_PAGE_DATA-2nd')
	elif 'ctoken=' in url and N30U6gJYef1v:
		obS4TpHeV3digGC.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':WrKdzhw7QSCXGEA846t3fnvupj2Pe})
		obS4TpHeV3digGC.update({'Cookie':'VISITOR_INFO1_LIVE='+N30U6gJYef1v})
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'GET',url,'',obS4TpHeV3digGC,'','','YOUTUBE-GET_PAGE_DATA-3rd')
	else:
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'GET',url,'',obS4TpHeV3digGC,'','','YOUTUBE-GET_PAGE_DATA-4th')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	RRr48IPQSLEdunNcgGUhJozkY = ZXFs0mEPR8qI2zj.findall('"innertubeApiKey".*?"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.I)
	if RRr48IPQSLEdunNcgGUhJozkY: key = RRr48IPQSLEdunNcgGUhJozkY[0]
	RRr48IPQSLEdunNcgGUhJozkY = ZXFs0mEPR8qI2zj.findall('"cver".*?"value".*?"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.I)
	if RRr48IPQSLEdunNcgGUhJozkY: WrKdzhw7QSCXGEA846t3fnvupj2Pe = RRr48IPQSLEdunNcgGUhJozkY[0]
	RRr48IPQSLEdunNcgGUhJozkY = ZXFs0mEPR8qI2zj.findall('"token".*?"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.I)
	if RRr48IPQSLEdunNcgGUhJozkY: Yhqjz4bLa1HB = RRr48IPQSLEdunNcgGUhJozkY[0]
	RRr48IPQSLEdunNcgGUhJozkY = ZXFs0mEPR8qI2zj.findall('"visitorData".*?"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.I)
	if RRr48IPQSLEdunNcgGUhJozkY: qv2xgQPCXsm3aWVSuYKTOwhy = RRr48IPQSLEdunNcgGUhJozkY[0]
	RRr48IPQSLEdunNcgGUhJozkY = ZXFs0mEPR8qI2zj.findall('"continuation".*?"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.I)
	if RRr48IPQSLEdunNcgGUhJozkY: FG1mX30dCxHyb5 = RRr48IPQSLEdunNcgGUhJozkY[0]
	cookies = wpFmEA3z8JR.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): N30U6gJYef1v = cookies['VISITOR_INFO1_LIVE']
	data = qv2xgQPCXsm3aWVSuYKTOwhy+':::'+key+':::'+FG1mX30dCxHyb5+':::'+WrKdzhw7QSCXGEA846t3fnvupj2Pe+':::'+Yhqjz4bLa1HB+':::'+N30U6gJYef1v
	if l3UpyxrXZ2=='ytInitialData' and 'ytInitialData' in QstumvzTIEUMXCcx06aD4y8nSqH:
		O0XS7Kx1Hic3nr6eCNl = ZXFs0mEPR8qI2zj.findall('window\["ytInitialData"\] = ({.*?});',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if not O0XS7Kx1Hic3nr6eCNl: O0XS7Kx1Hic3nr6eCNl = ZXFs0mEPR8qI2zj.findall('var ytInitialData = ({.*?});',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		NUKL7j2lO3kAWIZhormG19Qgc0b = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('str',O0XS7Kx1Hic3nr6eCNl[0])
	elif l3UpyxrXZ2=='ytInitialGuideData' and 'ytInitialGuideData' in QstumvzTIEUMXCcx06aD4y8nSqH:
		O0XS7Kx1Hic3nr6eCNl = ZXFs0mEPR8qI2zj.findall('var ytInitialGuideData = ({.*?});',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		NUKL7j2lO3kAWIZhormG19Qgc0b = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('str',O0XS7Kx1Hic3nr6eCNl[0])
	elif '</script>' not in QstumvzTIEUMXCcx06aD4y8nSqH: NUKL7j2lO3kAWIZhormG19Qgc0b = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('str',QstumvzTIEUMXCcx06aD4y8nSqH)
	else: NUKL7j2lO3kAWIZhormG19Qgc0b = ''
	j2agIU0xsLS6c7T.setSetting('av.youtube.data',data)
	return QstumvzTIEUMXCcx06aD4y8nSqH,NUKL7j2lO3kAWIZhormG19Qgc0b,data
def P7Z0G9vzMOlnidteTSwVsQCa6Ah3xp(url):
	search = CjyEnpfQ23o0PYwDtLId()
	if not search: return
	search = search.replace(' ','+')
	lQHXdV9Nzf6BLqS8D = url+'/search?query='+search
	J2K0qdYZMhG(lQHXdV9Nzf6BLqS8D)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if not search:
		search = CjyEnpfQ23o0PYwDtLId()
		if not search: return
	search = search.replace(' ','+')
	lQHXdV9Nzf6BLqS8D = JJTrn6SEtYZV31eyR97+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in Y9RKmgsxBefkFcuIj2GULDHy3: jvaS5uPA9R3nM17Nhics2fZOo = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in Y9RKmgsxBefkFcuIj2GULDHy3: jvaS5uPA9R3nM17Nhics2fZOo = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in Y9RKmgsxBefkFcuIj2GULDHy3: jvaS5uPA9R3nM17Nhics2fZOo = '&sp=EgIQAg%253D%253D'
		aaIn3XlQKJ6zSfkmjuCyM = lQHXdV9Nzf6BLqS8D+jvaS5uPA9R3nM17Nhics2fZOo
	else:
		RDG7CIKNsFj5XAcJl,lf3ekTjGuH7CVKA0X5nsi4,Wu4CadwRTJfkbXMUVxO3jQ2 = [],[],''
		X8IawbrEisGK = ['بدون ترتيب','ترتيب حسب مدى الصلة','ترتيب حسب تاريخ التحميل','ترتيب حسب عدد المشاهدات','ترتيب حسب التقييم']
		sVlFA6dw9qu3PRD2K0r = ['','&sp=CAA%253D','&sp=CAI%253D','&sp=CAM%253D','&sp=CAE%253D']
		L7lUEM8KHDxzu = F2yZPukcUh09sqCI8nYw7e('موقع يوتيوب - اختر الترتيب',X8IawbrEisGK)
		if L7lUEM8KHDxzu == -1: return
		ZIA3hMQqbiDnCHgNUtOFLmVs1T = sVlFA6dw9qu3PRD2K0r[L7lUEM8KHDxzu]
		QstumvzTIEUMXCcx06aD4y8nSqH,i3huRfgNCQ0DszZV4bp8PlELqyv,data = TBHlpjUZ35mnoC6(lQHXdV9Nzf6BLqS8D+ZIA3hMQqbiDnCHgNUtOFLmVs1T)
		if i3huRfgNCQ0DszZV4bp8PlELqyv:
			Xt7HVfQSuR2aCM8YsLNoZp4db6K = i3huRfgNCQ0DszZV4bp8PlELqyv['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
			for EEpvM1LZJzd039gONoKrWweRkQD4 in range(len(Xt7HVfQSuR2aCM8YsLNoZp4db6K)):
				group = Xt7HVfQSuR2aCM8YsLNoZp4db6K[EEpvM1LZJzd039gONoKrWweRkQD4]['searchFilterGroupRenderer']['filters']
				for JRSGAxBO58a1cHdsIXPmY in range(len(group)):
					P45bBFUk8TZKX7n62AL3r1lxQVs = group[JRSGAxBO58a1cHdsIXPmY]['searchFilterRenderer']
					if 'navigationEndpoint' in list(P45bBFUk8TZKX7n62AL3r1lxQVs.keys()):
						RRucmYBaXegTtNOdGHMQ = P45bBFUk8TZKX7n62AL3r1lxQVs['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
						RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.replace('\u0026','&')
						title = P45bBFUk8TZKX7n62AL3r1lxQVs['tooltip']
						title = title.replace('البحث عن ','')
						if 'إزالة الفلتر' in title: continue
						if 'قائمة تشغيل' in title:
							title = 'جيد للمسلسلات '+title
							Wu4CadwRTJfkbXMUVxO3jQ2 = title
							oKqQr8Ij0btxZ9SDm6h3Nd = RRucmYBaXegTtNOdGHMQ
						if 'ترتيب حسب' in title: continue
						title = title.replace('Search for ','')
						if 'Remove' in title: continue
						if 'Playlist' in title:
							title = 'جيد للمسلسلات '+title
							Wu4CadwRTJfkbXMUVxO3jQ2 = title
							oKqQr8Ij0btxZ9SDm6h3Nd = RRucmYBaXegTtNOdGHMQ
						if 'Sort by' in title: continue
						RDG7CIKNsFj5XAcJl.append(WhJe7bGx5XackTwOIZVLC8ut(title))
						lf3ekTjGuH7CVKA0X5nsi4.append(RRucmYBaXegTtNOdGHMQ)
		if not Wu4CadwRTJfkbXMUVxO3jQ2: ha9BNgzAdunWcq0 = ''
		else:
			RDG7CIKNsFj5XAcJl = ['بدون فلتر',Wu4CadwRTJfkbXMUVxO3jQ2]+RDG7CIKNsFj5XAcJl
			lf3ekTjGuH7CVKA0X5nsi4 = ['',oKqQr8Ij0btxZ9SDm6h3Nd]+lf3ekTjGuH7CVKA0X5nsi4
			oKMLiWJOzgrl9xw5vD73d8UV = F2yZPukcUh09sqCI8nYw7e('موقع يوتيوب - اختر الفلتر',RDG7CIKNsFj5XAcJl)
			if oKMLiWJOzgrl9xw5vD73d8UV == -1: return
			ha9BNgzAdunWcq0 = lf3ekTjGuH7CVKA0X5nsi4[oKMLiWJOzgrl9xw5vD73d8UV]
		if ha9BNgzAdunWcq0: aaIn3XlQKJ6zSfkmjuCyM = JJTrn6SEtYZV31eyR97+ha9BNgzAdunWcq0
		elif ZIA3hMQqbiDnCHgNUtOFLmVs1T: aaIn3XlQKJ6zSfkmjuCyM = lQHXdV9Nzf6BLqS8D+ZIA3hMQqbiDnCHgNUtOFLmVs1T
		else: aaIn3XlQKJ6zSfkmjuCyM = lQHXdV9Nzf6BLqS8D
	J2K0qdYZMhG(aaIn3XlQKJ6zSfkmjuCyM)
	return
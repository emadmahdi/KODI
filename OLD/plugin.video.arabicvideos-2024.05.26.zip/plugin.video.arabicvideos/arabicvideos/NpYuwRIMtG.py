# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'SERIES4WATCH'
headers = { 'User-Agent' : '' }
W74fAyGxODoLPs5vMX2l8C93R = '_SFW_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==210: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==211: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url)
	elif mode==212: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==213: HkKfQCS7RIa4xi3houjvl = pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	elif mode==214: HkKfQCS7RIa4xi3houjvl = vWOVYCNFqEhzX(url)
	elif mode==215: HkKfQCS7RIa4xi3houjvl = wZpBUDm2NxvcIgEaWHd1C35Ft(url)
	elif mode==218: HkKfQCS7RIa4xi3houjvl = uhyI3UPNRv1ACT()
	elif mode==219: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def uhyI3UPNRv1ACT():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','الموقع تغير بالكامل',message)
	return
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',219,'','','_REMEMBERRESULTS_')
	url = JJTrn6SEtYZV31eyR97+'/getpostsPin?type=one&data=pin&limit=25'
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'المميزة',url,211)
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,JJTrn6SEtYZV31eyR97,'',headers,'','SERIES4WATCH-MENU-1st')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('FiltersButtons(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('data-get="(.*?)".*?</i>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title in items:
		url = JJTrn6SEtYZV31eyR97+'/getposts?type=one&data='+RRucmYBaXegTtNOdGHMQ
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,url,211)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('navigation-menu(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('href="(http.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	SmgoEYJ7uyL = ['مسلسلات انمي','الرئيسية']
	for RRucmYBaXegTtNOdGHMQ,title in items:
		title = title.strip(' ')
		if not any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in SmgoEYJ7uyL):
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,211)
	return QstumvzTIEUMXCcx06aD4y8nSqH
def RxAy5lEFQ1chv0BrdU4p6Pt2(url):
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,url,'',headers,'','SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: bdq4e6Wr2gslnSiA38 = QstumvzTIEUMXCcx06aD4y8nSqH
	else:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('MediaGrid"(.*?)class="pagination"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n: bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		else: return
	items = ZXFs0mEPR8qI2zj.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	FF1TYf6O5KENr8R72LUVievClmudxD = []
	OVKupw4tFexi6JMykj3lNhW1 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for CrGO63LT7j2UxniW,RRucmYBaXegTtNOdGHMQ,title in items:
		if '/series/' in RRucmYBaXegTtNOdGHMQ: continue
		RRucmYBaXegTtNOdGHMQ = ejBOu2WXwvb4YpITdsLF16(RRucmYBaXegTtNOdGHMQ).strip('/')
		title = qpob7TvxHSs4fEzO6(title)
		title = title.strip(' ')
		if '/film/' in RRucmYBaXegTtNOdGHMQ or any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in OVKupw4tFexi6JMykj3lNhW1):
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,212,CrGO63LT7j2UxniW)
		elif '/episode/' in RRucmYBaXegTtNOdGHMQ and 'الحلقة' in title:
			LqYKJ36CBG = ZXFs0mEPR8qI2zj.findall('(.*?) الحلقة \d+',title,ZXFs0mEPR8qI2zj.DOTALL)
			if LqYKJ36CBG:
				title = '_MOD_' + LqYKJ36CBG[0]
				if title not in FF1TYf6O5KENr8R72LUVievClmudxD:
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,213,CrGO63LT7j2UxniW)
					FF1TYf6O5KENr8R72LUVievClmudxD.append(title)
		else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,213,CrGO63LT7j2UxniW)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="pagination(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			RRucmYBaXegTtNOdGHMQ = qpob7TvxHSs4fEzO6(RRucmYBaXegTtNOdGHMQ)
			title = qpob7TvxHSs4fEzO6(title)
			title = title.replace('الصفحة ','')
			if title!='': Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,RRucmYBaXegTtNOdGHMQ,211)
	return
def pqx0gStI9ojGFP2rWhwRfkVCNX(url):
	FLZWy5QnN2m9GbXSoIhP1dUr7Yilwu,items,IN6fHPDgUuOEvsXR3814Y = -1,[],[]
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,url,'',headers,'','SERIES4WATCH-EPISODES-1st')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('ti-list-numbered(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		n5nyDgxTuHbY0LNV4cWvoBtp = ''.join(IZGcQbePXxwAoyYR1n)
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)"',n5nyDgxTuHbY0LNV4cWvoBtp,ZXFs0mEPR8qI2zj.DOTALL)
	items.append(url)
	items = set(items)
	for RRucmYBaXegTtNOdGHMQ in items:
		RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.strip('/')
		title = '_MOD_' + RRucmYBaXegTtNOdGHMQ.split('/')[-1].replace('-',' ')
		QmVwp4UG5eXbO6vRtcWghHY8a7nFqN = ZXFs0mEPR8qI2zj.findall('الحلقة-(\d+)',RRucmYBaXegTtNOdGHMQ.split('/')[-1],ZXFs0mEPR8qI2zj.DOTALL)
		if QmVwp4UG5eXbO6vRtcWghHY8a7nFqN: QmVwp4UG5eXbO6vRtcWghHY8a7nFqN = QmVwp4UG5eXbO6vRtcWghHY8a7nFqN[0]
		else: QmVwp4UG5eXbO6vRtcWghHY8a7nFqN = '0'
		IN6fHPDgUuOEvsXR3814Y.append([RRucmYBaXegTtNOdGHMQ,title,QmVwp4UG5eXbO6vRtcWghHY8a7nFqN])
	items = sorted(IN6fHPDgUuOEvsXR3814Y, reverse=False, key=lambda key: int(key[2]))
	EMOwU2mH4Ku8cP0ypzt1vIbqB = str(items).count('/season/')
	FLZWy5QnN2m9GbXSoIhP1dUr7Yilwu = str(items).count('/episode/')
	if EMOwU2mH4Ku8cP0ypzt1vIbqB>1 and FLZWy5QnN2m9GbXSoIhP1dUr7Yilwu>0 and '/season/' not in url:
		for RRucmYBaXegTtNOdGHMQ,title,QmVwp4UG5eXbO6vRtcWghHY8a7nFqN in items:
			if '/season/' in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,213)
	else:
		for RRucmYBaXegTtNOdGHMQ,title,QmVwp4UG5eXbO6vRtcWghHY8a7nFqN in items:
			if '/season/' not in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,212)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	YYmyQXglbEewzL3IA2Sd = []
	mcEHCT3jSM = url.split('/')
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,url,'',headers,'','SERIES4WATCH-PLAY-1st')
	if '/watch/' in QstumvzTIEUMXCcx06aD4y8nSqH:
		lQHXdV9Nzf6BLqS8D = url.replace(mcEHCT3jSM[3],'watch')
		XgMyLUkfvP4uKVpQsY8RiWZz6N50O = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,lQHXdV9Nzf6BLqS8D,'',headers,'','SERIES4WATCH-PLAY-2nd')
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="servers-list(.*?)</div>',XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			if items:
				id = ZXFs0mEPR8qI2zj.findall('post_id=(.*?)"',XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
				if id:
					yfZpUog0Rbs8CFEv9 = id[0]
					for RRucmYBaXegTtNOdGHMQ,title in items:
						RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/?postid='+yfZpUog0Rbs8CFEv9+'&serverid='+RRucmYBaXegTtNOdGHMQ+'?named='+title+'__watch'
						YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
			else:
				items = ZXFs0mEPR8qI2zj.findall('data-embedd=".*?(http.*?)("|&quot;)',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
				for RRucmYBaXegTtNOdGHMQ,vfLGDU1N0e8c in items:
					YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	if '/download/' in QstumvzTIEUMXCcx06aD4y8nSqH:
		lQHXdV9Nzf6BLqS8D = url.replace(mcEHCT3jSM[3],'download')
		XgMyLUkfvP4uKVpQsY8RiWZz6N50O = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,lQHXdV9Nzf6BLqS8D,'',headers,'','SERIES4WATCH-PLAY-3rd')
		id = ZXFs0mEPR8qI2zj.findall('postId:"(.*?)"',XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
		if id:
			yfZpUog0Rbs8CFEv9 = id[0]
			obS4TpHeV3digGC = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' }
			lQHXdV9Nzf6BLqS8D = JJTrn6SEtYZV31eyR97 + '/ajaxCenter?_action=getdownloadlinks&postId='+yfZpUog0Rbs8CFEv9
			XgMyLUkfvP4uKVpQsY8RiWZz6N50O = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,lQHXdV9Nzf6BLqS8D,'',obS4TpHeV3digGC,'','SERIES4WATCH-PLAY-4th')
			IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('<h3.*?(\d+)(.*?)</div>',XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
			if IZGcQbePXxwAoyYR1n:
				for F50hr1lB8iCUeSAVjntKzHsR4,bdq4e6Wr2gslnSiA38 in IZGcQbePXxwAoyYR1n:
					items = ZXFs0mEPR8qI2zj.findall('<td>(.*?)<.*?href="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
					for name,RRucmYBaXegTtNOdGHMQ in items:
						YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ+'?named='+name+'__download'+'____'+F50hr1lB8iCUeSAVjntKzHsR4)
			else:
				IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('<h6(.*?)</table>',XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
				if not IZGcQbePXxwAoyYR1n: IZGcQbePXxwAoyYR1n = [XgMyLUkfvP4uKVpQsY8RiWZz6N50O]
				for bdq4e6Wr2gslnSiA38 in IZGcQbePXxwAoyYR1n:
					name = ''
					items = ZXFs0mEPR8qI2zj.findall('href="(http.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
					for RRucmYBaXegTtNOdGHMQ in items:
						NGmuWwXdLQ6nMltx39FYECohJ = '&&' + RRucmYBaXegTtNOdGHMQ.split('/')[2].lower() + '&&'
						NGmuWwXdLQ6nMltx39FYECohJ = NGmuWwXdLQ6nMltx39FYECohJ.replace('.com&&','').replace('.co&&','')
						NGmuWwXdLQ6nMltx39FYECohJ = NGmuWwXdLQ6nMltx39FYECohJ.replace('.net&&','').replace('.org&&','')
						NGmuWwXdLQ6nMltx39FYECohJ = NGmuWwXdLQ6nMltx39FYECohJ.replace('.live&&','').replace('.online&&','')
						NGmuWwXdLQ6nMltx39FYECohJ = NGmuWwXdLQ6nMltx39FYECohJ.replace('&&hd.','').replace('&&www.','')
						NGmuWwXdLQ6nMltx39FYECohJ = NGmuWwXdLQ6nMltx39FYECohJ.replace('&&','')
						RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ + '?named=' + name + NGmuWwXdLQ6nMltx39FYECohJ + '__download'
						YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(YYmyQXglbEewzL3IA2Sd,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	search = search.replace(' ','+')
	url = JJTrn6SEtYZV31eyR97 + '/search?s='+search
	RxAy5lEFQ1chv0BrdU4p6Pt2(url)
	return
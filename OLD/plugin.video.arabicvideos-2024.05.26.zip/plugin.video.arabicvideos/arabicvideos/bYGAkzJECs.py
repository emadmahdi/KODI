# -*- coding: utf-8 -*-
import sys as ddABnr3K9Xv8e71CzcN0Pxt
NLQaPokgt7Zi = ddABnr3K9Xv8e71CzcN0Pxt.version_info [0] == 2
QzcRNkipwA1WPJu6ZoTnxrjBlqe2 = 2048
Y07K8pBzWtXncO9rUdsw1MTgAyFS = 7
def pFM6HfGd7Urbxto45vSNLniWA (gKVwro2lTJQEp):
	global AUQrTjaXt8K
	UUhFMplXo8RaCwxnEz5Hm7r = ord (gKVwro2lTJQEp [-1])
	slDu7whZzrU2b3oCYREig1L65F9HK = gKVwro2lTJQEp [:-1]
	Ha7jrvByPJYSIiRoXm5ThCOWc = UUhFMplXo8RaCwxnEz5Hm7r % len (slDu7whZzrU2b3oCYREig1L65F9HK)
	E5JVTBFqvjCN2Sc = slDu7whZzrU2b3oCYREig1L65F9HK [:Ha7jrvByPJYSIiRoXm5ThCOWc] + slDu7whZzrU2b3oCYREig1L65F9HK [Ha7jrvByPJYSIiRoXm5ThCOWc:]
	if NLQaPokgt7Zi:
		lK9D8U71rY = unicode () .join ([unichr (ord (ysjIJ8PTAQv5copxFkLUXrRwf) - QzcRNkipwA1WPJu6ZoTnxrjBlqe2 - (WutIpGj5YChbO + UUhFMplXo8RaCwxnEz5Hm7r) % Y07K8pBzWtXncO9rUdsw1MTgAyFS) for WutIpGj5YChbO, ysjIJ8PTAQv5copxFkLUXrRwf in enumerate (E5JVTBFqvjCN2Sc)])
	else:
		lK9D8U71rY = str () .join ([chr (ord (ysjIJ8PTAQv5copxFkLUXrRwf) - QzcRNkipwA1WPJu6ZoTnxrjBlqe2 - (WutIpGj5YChbO + UUhFMplXo8RaCwxnEz5Hm7r) % Y07K8pBzWtXncO9rUdsw1MTgAyFS) for WutIpGj5YChbO, ysjIJ8PTAQv5copxFkLUXrRwf in enumerate (E5JVTBFqvjCN2Sc)])
	return eval (lK9D8U71rY)
OVmSuf8tpd,LmcNhzY6fQPd2JyCGslkSr,J3OCAmZVcn=pFM6HfGd7Urbxto45vSNLniWA,pFM6HfGd7Urbxto45vSNLniWA,pFM6HfGd7Urbxto45vSNLniWA
eeIL1TfgFQJaKqVD8hGNPEZ,aFQoGfmYKyqLU6X8libw9k3ncW5,m6b7CoBk4EQ=J3OCAmZVcn,LmcNhzY6fQPd2JyCGslkSr,OVmSuf8tpd
ZSJVq5XDrRot,yTMWeCgUROcvtsblfK85L62xPk,AAgpHN0nMZ=m6b7CoBk4EQ,aFQoGfmYKyqLU6X8libw9k3ncW5,eeIL1TfgFQJaKqVD8hGNPEZ
XogUJZEijT7KWbxeO6,FhcnOB9t3frzvXb,aVLSn1xw5cK=AAgpHN0nMZ,yTMWeCgUROcvtsblfK85L62xPk,ZSJVq5XDrRot
ffCSGrTJYPsxgVQWKLtHU3iMwB,EDPaWgMt1SwNn8o,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg=aVLSn1xw5cK,FhcnOB9t3frzvXb,XogUJZEijT7KWbxeO6
Ej67fFyoqW8kbV2HdSK,kmdSKeBIwViM9t3,fR68jBGWCzUsFXdlTKPOScugm=PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg,EDPaWgMt1SwNn8o,ffCSGrTJYPsxgVQWKLtHU3iMwB
bdhQDyjm3nPwToFHkprvCzBLUGR,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r,wwyUWMFAsO=fR68jBGWCzUsFXdlTKPOScugm,kmdSKeBIwViM9t3,Ej67fFyoqW8kbV2HdSK
kRYWcNuAazr4jtmBoxFVS19Z6,pEo8g7riWVL014KaRtzQ,sArCMRngQNmXkBoKv=wwyUWMFAsO,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r,bdhQDyjm3nPwToFHkprvCzBLUGR
JMLhEyaBWmskovGHTrVCxQ08,MM2BQ7xrAfNivgenXPytGYOs0DEHRC,hjNP5w9srJz2QpVISxBfndbD4CkXvl=sArCMRngQNmXkBoKv,pEo8g7riWVL014KaRtzQ,kRYWcNuAazr4jtmBoxFVS19Z6
xuYvdJpOEyQKTLNwb,jYaM5vilgZdFx6QHbApwVXO8et,DLSVmlyBbCK=hjNP5w9srJz2QpVISxBfndbD4CkXvl,MM2BQ7xrAfNivgenXPytGYOs0DEHRC,JMLhEyaBWmskovGHTrVCxQ08
gnfv8UtZ3daGqpjzk,gSmqZU0plur2xKPJwQA,c4QSTnPiWUCjhrLlwGB=DLSVmlyBbCK,jYaM5vilgZdFx6QHbApwVXO8et,xuYvdJpOEyQKTLNwb
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = kmdSKeBIwViM9t3(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠭ᅓ")
def OVQIAezo6U1NSTl4L(nnPsf4XLIJ7RWF,uHGMxiZfcoErOyXghvnWUK=aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬ࠭ᅔ")):
	if   nnPsf4XLIJ7RWF==  FhcnOB9t3frzvXb(u"࠴ᖞ"): ZyRBeVh7iH3obnftmDdjsPUrw(uHGMxiZfcoErOyXghvnWUK)
	elif nnPsf4XLIJ7RWF==  c4QSTnPiWUCjhrLlwGB(u"࠷ᖟ"): HvcsiXhFR9Dw1(uHGMxiZfcoErOyXghvnWUK)
	elif nnPsf4XLIJ7RWF==  aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠹ᖠ"): u8dzrBUjQ2IKAhLmgTtqbky()
	elif nnPsf4XLIJ7RWF==  kRYWcNuAazr4jtmBoxFVS19Z6(u"࠴ᖡ"): kOriw8l9X0sLv6M7AQqGH1WYo(uHGMxiZfcoErOyXghvnWUK)
	elif nnPsf4XLIJ7RWF==  MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠶ᖢ"): YdDSuEmMlZLwB39pOX()
	elif nnPsf4XLIJ7RWF==  m6b7CoBk4EQ(u"࠸ᖣ"): KQJyISNdlh()
	elif nnPsf4XLIJ7RWF==  PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠺ᖤ"): LLMXenCcYZHSN4OKzy9R(m6b7CoBk4EQ(u"ࡔࡳࡷࡨᙐ"),m6b7CoBk4EQ(u"ࡔࡳࡷࡨᙐ"))
	elif nnPsf4XLIJ7RWF==  bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠼ᖥ"): IFz8cq9Qj2UC5dWKMuXlb6NJw()
	elif nnPsf4XLIJ7RWF==  PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠾ᖦ"): dUGDJnp1Rf80yCuqsW93tFlxvkh7()
	elif nnPsf4XLIJ7RWF==gnfv8UtZ3daGqpjzk(u"࠷࠵࠱ᖧ"): yej2XGh1UZq4uA3E65L87JNrC()
	elif nnPsf4XLIJ7RWF==jYaM5vilgZdFx6QHbApwVXO8et(u"࠱࠶࠳ᖨ"): hNXYWSBkqGI2xACJ4ROcfQTHi10o5()
	elif nnPsf4XLIJ7RWF==pEo8g7riWVL014KaRtzQ(u"࠲࠷࠵ᖩ"): WWwh46NzuTtC9ISYmbsVrqRL()
	elif nnPsf4XLIJ7RWF==wwyUWMFAsO(u"࠳࠸࠷ᖪ"): aa8Z32x7Vkl()
	elif nnPsf4XLIJ7RWF==JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠴࠹࠹ᖫ"): N7gwvZyHQ6uqOoGTIM3LJKnXRzbV()
	elif nnPsf4XLIJ7RWF==OVmSuf8tpd(u"࠵࠺࠻ᖬ"): gT7a5b6IxWHK()
	elif nnPsf4XLIJ7RWF==FhcnOB9t3frzvXb(u"࠶࠻࠶ᖭ"): kYU2LCfAKQ8qxmupz09cbrEojya()
	elif nnPsf4XLIJ7RWF==xuYvdJpOEyQKTLNwb(u"࠷࠵࠸ᖮ"): OlLWqaxiN8eHTFm7SR5uBsygA()
	elif nnPsf4XLIJ7RWF==gSmqZU0plur2xKPJwQA(u"࠱࠶࠺ᖯ"): hFiRvbJrWYd78VEco()
	elif nnPsf4XLIJ7RWF==sArCMRngQNmXkBoKv(u"࠲࠷࠼ᖰ"): tKcmZ2YEF06ysejqd59Nv(kmdSKeBIwViM9t3(u"ࡕࡴࡸࡩᙑ"))
	elif nnPsf4XLIJ7RWF==Ej67fFyoqW8kbV2HdSK(u"࠳࠺࠴ᖱ"): ndQs8Nkp9eMTiLBhFwPGJqHx7()
	elif nnPsf4XLIJ7RWF==pEo8g7riWVL014KaRtzQ(u"࠴࠻࠶ᖲ"): AuYs2NIJVc91Lzn0jSEgG4QD()
	elif nnPsf4XLIJ7RWF==MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠵࠼࠸ᖳ"): Tj9ZsGIv1hxtzFe7HuWobP05V(uHGMxiZfcoErOyXghvnWUK,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࡖࡵࡹࡪᙒ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࡖࡵࡹࡪᙒ"))
	elif nnPsf4XLIJ7RWF==gnfv8UtZ3daGqpjzk(u"࠶࠽࠳ᖴ"): tTsLa8vMRzfgoVxdwkeW0DXCpKbPn(Ej67fFyoqW8kbV2HdSK(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭ᅕ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࡗࡶࡺ࡫ᙓ"))
	elif nnPsf4XLIJ7RWF==Ej67fFyoqW8kbV2HdSK(u"࠷࠷࠵ᖵ"): tTsLa8vMRzfgoVxdwkeW0DXCpKbPn(fR68jBGWCzUsFXdlTKPOScugm(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡸࡴ࡮ࡲࠪᅖ"),kmdSKeBIwViM9t3(u"ࡘࡷࡻࡥᙔ"))
	elif nnPsf4XLIJ7RWF==fR68jBGWCzUsFXdlTKPOScugm(u"࠱࠸࠷ᖶ"): ooXTfA94SZaQYUL1WdFl()
	elif nnPsf4XLIJ7RWF==gSmqZU0plur2xKPJwQA(u"࠲࠹࠹ᖷ"): RRftkXcUVLEsGYw7T8Me9jHDnxi0()
	elif nnPsf4XLIJ7RWF==JMLhEyaBWmskovGHTrVCxQ08(u"࠳࠺࠻ᖸ"): VgJQ6yCE4DYq1AOfGjoc(gnfv8UtZ3daGqpjzk(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬᅗ"))
	elif nnPsf4XLIJ7RWF==FhcnOB9t3frzvXb(u"࠴࠻࠽ᖹ"): VgJQ6yCE4DYq1AOfGjoc(FhcnOB9t3frzvXb(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡼࡸ࠲ࡪ࡬ࡱࠩᅘ"))
	elif nnPsf4XLIJ7RWF==EDPaWgMt1SwNn8o(u"࠵࠼࠿ᖺ"): VgJQ6yCE4DYq1AOfGjoc(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡼࡳࡺࡺࡵࡣࡧࠪᅙ"))
	elif nnPsf4XLIJ7RWF==yTMWeCgUROcvtsblfK85L62xPk(u"࠶࠿࠰ᖻ"): M6V2LFP1hmqaYJEz0RD4I35nX()
	elif nnPsf4XLIJ7RWF==JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠷࠹࠲ᖼ"): Bmx8EfZGpO2y1olb9()
	elif nnPsf4XLIJ7RWF==gnfv8UtZ3daGqpjzk(u"࠱࠺࠴ᖽ"): RkzZitmuW8KqLGaBC9()
	elif nnPsf4XLIJ7RWF==J3OCAmZVcn(u"࠲࠻࠶ᖾ"): kBimwuzGKNgqj43sOYxZycrd2QJMt()
	elif nnPsf4XLIJ7RWF==c4QSTnPiWUCjhrLlwGB(u"࠳࠼࠸ᖿ"): iOdej7CpTsqYb839RoW4ZPm6fcHMU()
	elif nnPsf4XLIJ7RWF==PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠴࠽࠺ᗀ"): YIwt0rTkJ8s3bPKMUGBCq5ROHZ()
	elif nnPsf4XLIJ7RWF==jYaM5vilgZdFx6QHbApwVXO8et(u"࠵࠾࠼ᗁ"): zn7E16cm42eY3qk()
	elif nnPsf4XLIJ7RWF==OVmSuf8tpd(u"࠶࠿࠷ᗂ"): gdqkVFbKYvBmt0AQ46nlPi()
	elif nnPsf4XLIJ7RWF==FhcnOB9t3frzvXb(u"࠷࠹࠹ᗃ"): g3tClM2DqI()
	elif nnPsf4XLIJ7RWF==bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠱࠺࠻ᗄ"): aqWbDur87TEoAvs()
	elif nnPsf4XLIJ7RWF==xuYvdJpOEyQKTLNwb(u"࠴࠶࠳ᗅ"): tKLGpmBwMZjJ(uHGMxiZfcoErOyXghvnWUK)
	elif nnPsf4XLIJ7RWF==kmdSKeBIwViM9t3(u"࠵࠷࠵ᗆ"): hEuK6GmSYZURWgdLwy25b()
	elif nnPsf4XLIJ7RWF==m6b7CoBk4EQ(u"࠶࠸࠷ᗇ"): EEs46Yvh3iD5txgQUPIzWZe9()
	elif nnPsf4XLIJ7RWF==c4QSTnPiWUCjhrLlwGB(u"࠷࠹࠹ᗈ"): I6fHznR0sdAT()
	elif nnPsf4XLIJ7RWF==EDPaWgMt1SwNn8o(u"࠸࠺࠴ᗉ"): ggCEbNwx1l7e(yTMWeCgUROcvtsblfK85L62xPk(u"࡙ࡸࡵࡦᙕ"))
	elif nnPsf4XLIJ7RWF==kmdSKeBIwViM9t3(u"࠹࠴࠶ᗊ"): OycaYRWLHfr5mUdsXZTintFQz7quVb()
	elif nnPsf4XLIJ7RWF==bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠳࠵࠸ᗋ"): TlD1doFipMsk0y(aVLSn1xw5cK(u"ࡌࡡ࡭ࡵࡨᙖ"))
	elif nnPsf4XLIJ7RWF==gSmqZU0plur2xKPJwQA(u"࠴࠶࠺ᗌ"): ZOIbNiQGafpXCxh3E1w4ulsD9my(FhcnOB9t3frzvXb(u"ࡔࡳࡷࡨᙗ"))
	elif nnPsf4XLIJ7RWF==AAgpHN0nMZ(u"࠵࠷࠼ᗍ"): p3AqitSPuRf7cnLxvrab1()
	elif nnPsf4XLIJ7RWF==FhcnOB9t3frzvXb(u"࠶࠸࠾ᗎ"): pass
	elif nnPsf4XLIJ7RWF==hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠹࠵࠶ᗏ"): GGdBXtWJ2UO8QfImxT()
	elif nnPsf4XLIJ7RWF==xuYvdJpOEyQKTLNwb(u"࠺࠶࠱ᗐ"): Eaku1fiqX3RBrN7906Q85eKlLo()
	elif nnPsf4XLIJ7RWF==OVmSuf8tpd(u"࠻࠰࠳ᗑ"): cZjl7kE40hJznyQt5(yTMWeCgUROcvtsblfK85L62xPk(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪᅚ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࡕࡴࡸࡩᙘ"))
	elif nnPsf4XLIJ7RWF==kmdSKeBIwViM9t3(u"࠵࠱࠵ᗒ"): KPCYsuEtQb73e90oZi65fGS(ryc0LEzgSbaI7NqvwJ)
	elif nnPsf4XLIJ7RWF==LmcNhzY6fQPd2JyCGslkSr(u"࠶࠲࠷ᗓ"): KPCYsuEtQb73e90oZi65fGS(P71CANTSyWYptGs8JnZkUHu3Kwi6Ql)
	elif nnPsf4XLIJ7RWF==ZSJVq5XDrRot(u"࠷࠳࠹ᗔ"): NWpjEyc6oAkFs8VCImxgO()
	elif nnPsf4XLIJ7RWF==ZSJVq5XDrRot(u"࠸࠴࠻ᗕ"): MCAInGyaz6mZwUx4gjqBb(Ej67fFyoqW8kbV2HdSK(u"ࡖࡵࡹࡪᙙ"))
	elif nnPsf4XLIJ7RWF==JMLhEyaBWmskovGHTrVCxQ08(u"࠹࠵࠽ᗖ"): Wjht89D0l2OpN4Rm6HoP7Z(uHGMxiZfcoErOyXghvnWUK,hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠬ࠭ᅛ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࡗࡶࡺ࡫ᙚ"))
	elif nnPsf4XLIJ7RWF==J3OCAmZVcn(u"࠺࠶࠸ᗗ"): EtpePavw6CyRoxI0OBWcLHn3dr2()
	elif nnPsf4XLIJ7RWF==c4QSTnPiWUCjhrLlwGB(u"࠻࠰࠺ᗘ"): liq81xozW7ZVXP()
	return
def liq81xozW7ZVXP():
	YYkEu4IL0sTa = OxCB4medn1(XogUJZEijT7KWbxeO6(u"࠭ࠧᅜ"),wwyUWMFAsO(u"ࠧࠨᅝ"),kmdSKeBIwViM9t3(u"ࠨࠩᅞ"),aVLSn1xw5cK(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᅟ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"๋้ࠪࠦสา์าࠤๆ฿ไศ่ࠢืาࠦฬๆ์฼ࠤส฿ฯศัสฮࠥอไษำ้ห๊าࠠ࠯࠰ࠣ์ู๊อࠡฮ่๎฾ࠦๅๅใสฮࠥอไษำ้ห๊าࠠศๆๅำ๏๋ษࠡ࠰࠱ࠤ้้๊ࠡ์฼์ิࠦวๅสิ๊ฬ๋ฬࠡว็ํࠥำวๅหࠣห้฻แาࠢ࠱࠲ࠥ๐ู็์ࠣฮัี๊ะࠢส่อืๆศ็ฯࠤํะีโ์ิ๋ࠥ๎่ื฻๊ࠤอำวๅหࠣห้๋ี็฻ࠣห้ะู๊๊ࠡ฽์อࠠศๆ่ฬึ๋ฬࠡมࠤࠥࠬᅠ"))
	if YYkEu4IL0sTa:
		ggCEbNwx1l7e(yTMWeCgUROcvtsblfK85L62xPk(u"ࡊࡦࡲࡳࡦᙛ"))
		Eux3w7MylkQfiBa6pvJO0FWTNbr(mATvU6VbxOXNFhz8lK5WGrfQ,gnfv8UtZ3daGqpjzk(u"࡚ࡲࡶࡧᙝ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࡋࡧ࡬ࡴࡧᙜ"))
		HHTzVhiY079bvdluNkFQ4wCMpe(JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࠬᅡ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠬ࠭ᅢ"),gSmqZU0plur2xKPJwQA(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᅣ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧห็ุ้ࠣำࠠอ็ํ฽ࠥอไๆๆไหฯࠦวๅไา๎๊ฯࠠๅๆหี๋อๅอࠢ࠱࠲ࠥ๎ูศัࠣห้ฮั็ษ่ะࠥหไฺ๊๋ࠢ฾๐ษࠡษ็ูๆืࠠ࠯࠰ࠣ์฻฿๊สࠢส่๊฻ๆฺࠩᅤ"))
	return
def Wjht89D0l2OpN4Rm6HoP7Z(ZK5gkAtjrCeEXYGD2bRQHOF3Moyc,TnDqWtjmsg3Pd8Qza19vbZHRhy,showDialogs):
	m5h4wdsHCKLvPu9V6rEFi2q = esvtXhdikb2GDJm5Arc.connect(CGoMep90r3LDHfxU16ntBZi8hdaIJg)
	m5h4wdsHCKLvPu9V6rEFi2q.text_factory = str
	nRseEAQwXo4jC21gmqPzIihfUc = m5h4wdsHCKLvPu9V6rEFi2q.cursor()
	if Yd6t3PjlLKk: bvj5YTMoNWmU = JMLhEyaBWmskovGHTrVCxQ08(u"ࠨࡤ࡯ࡥࡨࡱ࡬ࡪࡵࡷࠫᅥ")
	else: bvj5YTMoNWmU = gnfv8UtZ3daGqpjzk(u"ࠩࡸࡴࡩࡧࡴࡦࡡࡵࡹࡱ࡫ࡳࠨᅦ")
	nRseEAQwXo4jC21gmqPzIihfUc.execute(J3OCAmZVcn(u"ࠪࡗࡊࡒࡅࡄࡖࠣ࠮ࠥࡌࡒࡐࡏࠣࠫᅧ")+bvj5YTMoNWmU+c4QSTnPiWUCjhrLlwGB(u"ࠫࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩᅨ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+J3OCAmZVcn(u"ࠬࠨࠠ࠼ࠩᅩ"))
	h72BryKAmUNjZwIqgvYtD = nRseEAQwXo4jC21gmqPzIihfUc.fetchall()
	if h72BryKAmUNjZwIqgvYtD and TnDqWtjmsg3Pd8Qza19vbZHRhy in [JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭ࠧᅪ"),AAgpHN0nMZ(u"ࠧࡦࡰࡤࡦࡱ࡫ࠧᅫ")]:
		YYkEu4IL0sTa = OxCB4medn1(OVmSuf8tpd(u"ࠨࠩᅬ"),FhcnOB9t3frzvXb(u"ࠩࠪᅭ"),gSmqZU0plur2xKPJwQA(u"ࠪࠫᅮ"),Ej67fFyoqW8kbV2HdSK(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᅯ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬอไหฯา๎ะࠦวๅล๋ฮํ๋วห์ๆ๎๊ࠥลืษไอࠥࡢ࡮ࠡࠩᅰ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠭ࠠ࡝ࡰ࡟ࡲࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ็อ์็็้ࠠๆสࠤ๏฿ๅๅࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦสโ฻ํ่์ࠦวๅฤ้ࠤฤࠧࠡࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࡠࡳࡢ࡮ࠡฬึฮ฼๐ูࠡวํๆฬ็็ࠡสึ๋ํ๊ษࠡ฻้ำࠥอไฺ๊าอࠥหไ๊๊ࠢิ์ࠦวๅึสุฮࠦวๅ็๋ะํีษࠡใํࠤ็อฦๆหࠣาิ๋วหࠢหี๋อๅอࠢ฼้ฬีࠧᅱ"))
		if YYkEu4IL0sTa!=bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠱ᗙ"): return
		nRseEAQwXo4jC21gmqPzIihfUc.execute(Ej67fFyoqW8kbV2HdSK(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥ࠭ᅲ")+bvj5YTMoNWmU+wwyUWMFAsO(u"ࠨ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭ᅳ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠩࠥࠤࡀ࠭ᅴ"))
	elif TnDqWtjmsg3Pd8Qza19vbZHRhy in [jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪࠫᅵ"),aVLSn1xw5cK(u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࠬᅶ")]:
		YYkEu4IL0sTa = OxCB4medn1(pEo8g7riWVL014KaRtzQ(u"ࠬ࠭ᅷ"),aVLSn1xw5cK(u"࠭ࠧᅸ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧࠨᅹ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᅺ"),XogUJZEijT7KWbxeO6(u"ࠩส่ฯำฯ๋อࠣห้ษ่ห๊่หฯ๐ใ๋ࠢ็ษ฻อแสࠢ࡟ࡲࠥ࠭ᅻ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠪࠤࡡࡴ࡜࡯ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๋ࠥแฺๆࠣ์๏฿ๅๅࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦล๋ไสๅ์ࠦวๅฤ้ࠤฤࠧࠡࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࡠࡳࡢ࡮ࠡฬึฮ฼๐ูࠡฬไ฽๏๊็ࠡสึ๋ํ๊ษࠡ฻้ำࠥอไฺ๊าอࠥหไ๊๊ࠢิ์ࠦวๅึสุฮࠦวๅ็๋ะํีษࠡใํࠤ็อฦๆหࠣาิ๋วหࠢหี๋อๅอࠢ฼้ฬีࠧᅼ"))
		if YYkEu4IL0sTa!=fR68jBGWCzUsFXdlTKPOScugm(u"࠲ᗚ"): return
		if Yd6t3PjlLKk: nRseEAQwXo4jC21gmqPzIihfUc.execute(gnfv8UtZ3daGqpjzk(u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࡥࡰࡦࡩ࡫࡭࡫ࡶࡸࠥ࠮ࡡࡥࡦࡲࡲࡎࡊࠩࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࠥࠫᅽ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+LmcNhzY6fQPd2JyCGslkSr(u"ࠬࠨࠩࠡ࠽ࠪᅾ"))
		else: nRseEAQwXo4jC21gmqPzIihfUc.execute(fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࡺࡶࡤࡢࡶࡨࡣࡷࡻ࡬ࡦࡵࠣࠬࡦࡪࡤࡰࡰࡌࡈ࠱ࡻࡰࡥࡣࡷࡩࡗࡻ࡬ࡦ࡚ࠫࠣࡆࡒࡕࡆࡕࠣࠬࠧ࠭ᅿ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+XogUJZEijT7KWbxeO6(u"ࠧࠣ࠮࠴࠭ࠥࡁࠧᆀ"))
	m5h4wdsHCKLvPu9V6rEFi2q.commit()
	m5h4wdsHCKLvPu9V6rEFi2q.close()
	luMHeSgCBaPrb9KvUjNFqcR.sleep(fR68jBGWCzUsFXdlTKPOScugm(u"࠳ᗛ"))
	cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(DLSVmlyBbCK(u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬᆁ"))
	luMHeSgCBaPrb9KvUjNFqcR.sleep(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠴ᗜ"))
	if showDialogs: HHTzVhiY079bvdluNkFQ4wCMpe(wwyUWMFAsO(u"ࠩࠪᆂ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠪࠫᆃ"),J3OCAmZVcn(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᆄ"),sArCMRngQNmXkBoKv(u"ࠬะๅหࠢส่฾๋ไ๋หࠣฬ๋าวฮࠩᆅ"))
	if TnDqWtjmsg3Pd8Qza19vbZHRhy in [JMLhEyaBWmskovGHTrVCxQ08(u"࠭ࠧᆆ"),DLSVmlyBbCK(u"ࠧࡦࡰࡤࡦࡱ࡫ࠧᆇ")]: tKcmZ2YEF06ysejqd59Nv(showDialogs)
	return
def NWpjEyc6oAkFs8VCImxgO():
	ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,Ej67fFyoqW8kbV2HdSK(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫᆈ"),ZSJVq5XDrRot(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬᆉ"))
	EC5XwtROefg9UNdSvQ = KLSU61gP7bs5QBrp(OVmSuf8tpd(u"ࡆࡢ࡮ࡶࡩᙞ"))
	EpOcF7b29oRkHNvXfKmau = kmdSKeBIwViM9t3(u"ࠪࡠࡳ࠭ᆊ")
	rNXEK9fe3wo7ZxSD5PMCpYyqthH1AQ = xuYvdJpOEyQKTLNwb(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠠ࠮࠯࠰࠱࠲ࠦ࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯ࠣ࠱࠲࠳࠭࠮ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᆋ")
	gF1vS5wTOJUrM = JMLhEyaBWmskovGHTrVCxQ08(u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱࠫᆌ")
	for id,hhC9JITqv3yWEGFm,X3OBj9hFudG,xOV4lRWI2Ak37E,kwRd5A8WqiVBQ4cxf0rNPbC7XaSUF2,reason in reversed(EC5XwtROefg9UNdSvQ):
		if id==kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭࠰ࠨᆍ"):
			YPINwkvUA9arTds6y,zzuOx8f13Np = xOV4lRWI2Ak37E.split(OVmSuf8tpd(u"ࠧ࡝ࡰ࠾࠿ࠬᆎ"))
			continue
		if EpOcF7b29oRkHNvXfKmau!=aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨ࡞ࡱࠫᆏ"): EpOcF7b29oRkHNvXfKmau += gF1vS5wTOJUrM
		uu5SDqLcCs7IUA = kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪᆐ")+id+pEo8g7riWVL014KaRtzQ(u"ࠪࠤ࠿ࠦࠧᆑ")+wwyUWMFAsO(u"ࠫฬ๊ำลษ็ࠤ࠿ࠦࠧᆒ")+pEo8g7riWVL014KaRtzQ(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᆓ")+X3OBj9hFudG
		zzPuKeTq6I4gHrRA3aUDmEpVyl = kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭࡜࡯࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็ะํอศࠡ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᆔ")+xOV4lRWI2Ak37E
		zb9ro4X6jnBHhxpg = m6b7CoBk4EQ(u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆั฻ศࠦ࠺ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᆕ")+kwRd5A8WqiVBQ4cxf0rNPbC7XaSUF2
		kAotrbLajs5J2m8 = m6b7CoBk4EQ(u"ࠨ࡞ࡱ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠหู้ศษࠢ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᆖ")+reason
		EpOcF7b29oRkHNvXfKmau += uu5SDqLcCs7IUA+zzPuKeTq6I4gHrRA3aUDmEpVyl+MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩ࡟ࡲࠬᆗ")+rNXEK9fe3wo7ZxSD5PMCpYyqthH1AQ+bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪࡠࡳ࠭ᆘ")+zb9ro4X6jnBHhxpg+kAotrbLajs5J2m8+yTMWeCgUROcvtsblfK85L62xPk(u"ࠫࡡࡴࠧᆙ")
	FD5mbRq2ypcA6QOUE8hG(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬࡸࡩࡨࡪࡷࠫᆚ"),zzuOx8f13Np,EpOcF7b29oRkHNvXfKmau,gnfv8UtZ3daGqpjzk(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧᆛ"))
	return
def KPCYsuEtQb73e90oZi65fGS(file):
	if file==P71CANTSyWYptGs8JnZkUHu3Kwi6Ql: rU4nL6JuYlbVH2AGtNw7RO = DLSVmlyBbCK(u"ࠧใ๊สส๊ࠦวๅ็ไฺ้ฯࠧᆜ")
	elif file==ryc0LEzgSbaI7NqvwJ: rU4nL6JuYlbVH2AGtNw7RO = jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨไ๋หห๋ࠠระิࠤฬ๊แ๋ัํ์์อสࠨᆝ")
	PTQimzWJpkrt6H = A0iaw7hK4Qmc2EeHXZB(aVLSn1xw5cK(u"ࠩࡦࡩࡳࡺࡥࡳࠩᆞ"),aVLSn1xw5cK(u"ุ้ࠪำࠧᆟ"),Ej67fFyoqW8kbV2HdSK(u"ࠫส฻ไศฯࠪᆠ"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠬิั้ฮࠪᆡ"),gnfv8UtZ3daGqpjzk(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᆢ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"่ࠧๆࠣฮึ๐ฯࠡวุ่ฬำࠠๆๆไࠤࠬᆣ")+rU4nL6JuYlbVH2AGtNw7RO+aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨࠢฦ้ࠥะั๋ัุ้ࠣำࠠศๆ่่ๆࠦฟࠨᆤ"))
	if PTQimzWJpkrt6H==J3OCAmZVcn(u"࠴ᗝ"):
		if hhHq8m5vauKG9dl.path.exists(file):
			try: hhHq8m5vauKG9dl.remove(file)
			except: pass
		HHTzVhiY079bvdluNkFQ4wCMpe(ZSJVq5XDrRot(u"ࠩࠪᆥ"),XogUJZEijT7KWbxeO6(u"ࠪࠫᆦ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᆧ"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠬะๅࠡ็ึั๋ࠥไโࠢࠪᆨ")+rU4nL6JuYlbVH2AGtNw7RO)
	elif PTQimzWJpkrt6H==eeIL1TfgFQJaKqVD8hGNPEZ(u"࠶ᗞ"):
		data = KJM5ELV47wTIWg(file)
		HHTzVhiY079bvdluNkFQ4wCMpe(fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࠧᆩ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧࠨᆪ"),c4QSTnPiWUCjhrLlwGB(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᆫ"),wwyUWMFAsO(u"ࠩอ้ࠥหีๅษะࠤ๊๊แࠡࠩᆬ")+rU4nL6JuYlbVH2AGtNw7RO)
	return
def Eaku1fiqX3RBrN7906Q85eKlLo():
	if V8US2yZAg0QXJebWIHKD5xFa<EDPaWgMt1SwNn8o(u"࠷࠸ᗟ"):
		LaX1QCyeIJ = EDPaWgMt1SwNn8o(u"่้ࠪษำโࠢฦ๊ฯࠦสิฬัำ๊ࠦลึัสี้่ࠥะ์ࠣๆิ๐ๅࠡำๅ้ࠥ࠭ᆭ")+str(V8US2yZAg0QXJebWIHKD5xFa)+JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࠥ๎ไ่าสࠤฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦไศࠢอ฽ฺ๊๊่ࠠา็ࠥ࠴่ࠠา๊ࠤฬ๊ๅ๋ิฬࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣห้็๊ะ์๋๋ฬะࠠโ์ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠥ࠴ࠠๅวุ่ฬำࠠศๆุ่่๊ษࠡไ่ࠤอะอะ์ฮࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢศ่๎ࠦล๋ࠢศูิอัࠡำๅ้์ࠦรฺๆ์ࠤ๊์ࠠ࠲࠺࠱࠴ࠬᆮ")
		HHTzVhiY079bvdluNkFQ4wCMpe(OVmSuf8tpd(u"ࠬ࠭ᆯ"),m6b7CoBk4EQ(u"࠭ࠧᆰ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᆱ"),LaX1QCyeIJ)
		return
	lC8scLAd0IFYuTbR3UWk9ZxJNSQ = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executeJSONRPC(Ej67fFyoqW8kbV2HdSK(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣࡿࢀࠫᆲ"))
	ZUCy6NxE0T7rkjYLpScutH81 = XxDICeh4Y7yOvFtq([PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨᆳ")])
	HVhWsdYRMyzq,ggHqGwlzYZ,RSjEAZU0gca,aheZ6MPkfd2O3uL8tKyxGo,H3wQ8jn2MVNfOYoX4,hy6cWmn15srpG7gl3auNtC,aawySXrIb0 = ZUCy6NxE0T7rkjYLpScutH81[sArCMRngQNmXkBoKv(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩᆴ")]
	if HVhWsdYRMyzq or jYaM5vilgZdFx6QHbApwVXO8et(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪᆵ") not in str(lC8scLAd0IFYuTbR3UWk9ZxJNSQ):
		HHTzVhiY079bvdluNkFQ4wCMpe(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬ࠭ᆶ"),Ej67fFyoqW8kbV2HdSK(u"࠭ࠧᆷ"),m6b7CoBk4EQ(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᆸ"),aVLSn1xw5cK(u"ࠨษ็ๆํอฦๆࠢส่๊฻่าหࠣฮ฾๋ไࠡใๅ฻ู๋ࠥࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴่ࠠา๊ࠤฬ๊โ้ษษ้ࠥะๅไ่ๆࠤ๊์ࠠาฦํอ่่ࠥศศ่ࠤอืๆศ็ฯࠤ฾๋วะࠢหุ่๊ࠠึ๊ิࠤอีไศ่๊ࠢࠥอไไฬสฬฮ࠭ᆹ"))
		ybf3Qo7isaYVr = cZjl7kE40hJznyQt5(sArCMRngQNmXkBoKv(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨᆺ"),xuYvdJpOEyQKTLNwb(u"ࡕࡴࡸࡩᙟ"))
		if not ybf3Qo7isaYVr: return
	CJAc6jFdGkqfUKxPTQ2ItSBX(aVLSn1xw5cK(u"ࡖࡵࡹࡪᙠ"))
	return
def CJAc6jFdGkqfUKxPTQ2ItSBX(showDialogs=xuYvdJpOEyQKTLNwb(u"ࡗࡶࡺ࡫ᙡ")):
	lC8scLAd0IFYuTbR3UWk9ZxJNSQ = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executeJSONRPC(pEo8g7riWVL014KaRtzQ(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭ᆻ"))
	if xuYvdJpOEyQKTLNwb(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪᆼ") not in str(lC8scLAd0IFYuTbR3UWk9ZxJNSQ):
		if showDialogs:
			HHTzVhiY079bvdluNkFQ4wCMpe(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬ࠭ᆽ"),LmcNhzY6fQPd2JyCGslkSr(u"࠭ࠧᆾ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᆿ"),DLSVmlyBbCK(u"ࠨๆ็วุ็ࠠอ้สึ่ࠦไศࠢํืฯิฯๆࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮ࠡษ็ๆํอฦๆࠢส่๊฻่าหࠣฮ฾๋ไࠡใๅ฻ู๋ࠥࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴่ࠠา๊ࠤฬ๊โ้ษษ้ࠥะๅไ่ๆࠤ๊์ࠠาฦํอ่่ࠥศศ่ࠤอืๆศ็ฯࠤ฾๋วะࠢหุ่๊ࠠึ๊ิࠤอีไศ่๊ࠢࠥอไไฬสฬฮ࠭ᇀ"))
		return
	V2DgoBNA9vSi5tw6ZG3RE = hhHq8m5vauKG9dl.path.join(D2DYfsvFSG5CnV,FhcnOB9t3frzvXb(u"ࠩࡤࡨࡩࡵ࡮ࡴࠩᇁ"),c4QSTnPiWUCjhrLlwGB(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩᇂ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠫ࠼࠸࠰ࡱࠩᇃ"),ZSJVq5XDrRot(u"ࠬࡓࡹࡗ࡫ࡧࡩࡴࡔࡡࡷ࠰ࡻࡱࡱ࠭ᇄ"))
	if not hhHq8m5vauKG9dl.path.exists(V2DgoBNA9vSi5tw6ZG3RE): return
	SqKW7xf9uRlLa0 = open(V2DgoBNA9vSi5tw6ZG3RE,sArCMRngQNmXkBoKv(u"࠭ࡲࡣࠩᇅ")).read()
	if VYMZsxRpcQHPgkaiDKjyoh: SqKW7xf9uRlLa0 = SqKW7xf9uRlLa0.decode(Ej67fFyoqW8kbV2HdSK(u"ࠧࡶࡶࡩ࠼ࠬᇆ"))
	fprgQKlnu8TiUo5aO43hwE2bmP = ZXFs0mEPR8qI2zj.findall(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨ࠾ࡹ࡭ࡪࡽࡳ࠿ࠪ࡟ࡨ࠰࠲࡜ࡥ࠭࠯ࡠࡩ࠱ࠩ࠭ࠪ࠱࠮ࡄ࠯࠼࠰ࡸ࡬ࡩࡼࡹ࠾ࠨᇇ"),SqKW7xf9uRlLa0,ZXFs0mEPR8qI2zj.DOTALL)
	HHwzErnUiO1Bpdte4vjRZCSuasL,yaiug04tE1H8MpZlmCX = fprgQKlnu8TiUo5aO43hwE2bmP[eeIL1TfgFQJaKqVD8hGNPEZ(u"࠰ᗠ")]
	Q2SjuMqOkLKyr5JHZTXBtlciUpVE3 = wwyUWMFAsO(u"ࠩ࠿ࡺ࡮࡫ࡷࡴࡀࠪᇈ")+HHwzErnUiO1Bpdte4vjRZCSuasL+LmcNhzY6fQPd2JyCGslkSr(u"ࠪ࠰ࠬᇉ")+yaiug04tE1H8MpZlmCX+aVLSn1xw5cK(u"ࠫࡁ࠵ࡶࡪࡧࡺࡷࡃ࠭ᇊ")
	if showDialogs:
		ZHgeIz8qSJFOsCQkDERoMu2 = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.getInfoLabel(LmcNhzY6fQPd2JyCGslkSr(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡘ࡬ࡩࡼࡳ࡯ࡥࡧࠪᇋ"))
		if ZHgeIz8qSJFOsCQkDERoMu2==J3OCAmZVcn(u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩᇌ"): XlHqW2y5e1 = eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧใ๊สส๊ࠦวๅๅอหอฯࠧᇍ")
		elif ZHgeIz8qSJFOsCQkDERoMu2==sArCMRngQNmXkBoKv(u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧᇎ"): XlHqW2y5e1 = gSmqZU0plur2xKPJwQA(u"ࠩๅ์ฬฬๅࠡษ็ูํืࠧᇏ")
		else: XlHqW2y5e1 = sArCMRngQNmXkBoKv(u"ࠪๆํอฦๆࠢฦาึ๏ࠧᇐ")
		PTQimzWJpkrt6H = A0iaw7hK4Qmc2EeHXZB(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᇑ"),sArCMRngQNmXkBoKv(u"่่ࠬศศ่ࠤศิั๊ࠩᇒ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭โ้ษษ้ࠥอไไฬสฬฮ࠭ᇓ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧใ๊สส๊ࠦวๅื๋ีࠬᇔ"),J3OCAmZVcn(u"ࠨษ้ฮࠥำวๅ์สࠤฯูสฯั่ࠤࠬᇕ")+XlHqW2y5e1,J3OCAmZVcn(u"ࠩส๊ฯࠦวๅฤ้ࠤฯูสฯั่ࠤฬ๊ลึัสีࠥอไฤะํี๊ࠥฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠲ࠥ๎็ัษ้ࠣ฾์ว่ࠢส๊่ࠦสิฬฺ๎฾ࠦวิฬัำฬ๋ࠠศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢหำ้อࠠๆ่ࠣๆํอฦๆࠢส่่ะวษหࠣ࠲ࠥ๎รุ๋สࠤฯูสุ์฼ࠤส๐โศใ๊หࠥ็๊ࠡลํࠤํ่สࠡฬืหฦࠦ࡜࡯࡞ࡱࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠠฤะอีࠥอไร่๊ࠣํ฿ࠠศๆๅ์ฬฬๅࠡษ็ฮ๏ࠦสา์าࠤศูสฯัส้์อࠠภࠣ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᇖ"))
		if PTQimzWJpkrt6H==gnfv8UtZ3daGqpjzk(u"࠲ᗡ"): kp1dfOzPDwnjW2 = yTMWeCgUROcvtsblfK85L62xPk(u"ࠪࡉࡒࡇࡄࠡࡎ࡬ࡷࡹ࠭ᇗ")
		elif PTQimzWJpkrt6H==MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠴ᗢ"): kp1dfOzPDwnjW2 = PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪᇘ")
		else: kp1dfOzPDwnjW2 = kmdSKeBIwViM9t3(u"ࠬ࠭ᇙ")
	else:
		ZHgeIz8qSJFOsCQkDERoMu2 = j2agIU0xsLS6c7T.getSetting(wwyUWMFAsO(u"࠭ࡡࡷ࠰ࡰࡽࡸࡱࡩ࡯࠰ࡹ࡭ࡪࡽ࡭ࡰࡦࡨࠫᇚ"))
		if   ZHgeIz8qSJFOsCQkDERoMu2==aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧࠨᇛ"): PTQimzWJpkrt6H = yTMWeCgUROcvtsblfK85L62xPk(u"࠳ᗣ")
		elif ZHgeIz8qSJFOsCQkDERoMu2==xuYvdJpOEyQKTLNwb(u"ࠨࡇࡐࡅࡉࠦࡌࡪࡵࡷࠫᇜ"): PTQimzWJpkrt6H = aVLSn1xw5cK(u"࠵ᗤ")
		elif ZHgeIz8qSJFOsCQkDERoMu2==m6b7CoBk4EQ(u"ࠩࡈࡑࡆࡊࠠࡈࡣ࡯ࡰࡪࡸࡹࠨᇝ"): PTQimzWJpkrt6H = MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠷ᗥ")
		kp1dfOzPDwnjW2 = ZHgeIz8qSJFOsCQkDERoMu2
	if   PTQimzWJpkrt6H==aVLSn1xw5cK(u"࠶ᗦ"): kLy7p6H8FBD0dAUR = PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪ࠹࠺࠲࠵࠵࠶࠯࠹࠺࠻ࠧᇞ")
	elif PTQimzWJpkrt6H==sArCMRngQNmXkBoKv(u"࠱ᗧ"): kLy7p6H8FBD0dAUR = MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠫ࠺࠺࠴࠭࠷࠸࠹࠱࠻࠵ࠨᇟ")
	elif PTQimzWJpkrt6H==wwyUWMFAsO(u"࠳ᗨ"): kLy7p6H8FBD0dAUR = fR68jBGWCzUsFXdlTKPOScugm(u"ࠬ࠻࠵࠶࠮࠸࠹࠱࠻࠴࠵ࠩᇠ")
	else: return
	j2agIU0xsLS6c7T.setSetting(c4QSTnPiWUCjhrLlwGB(u"࠭ࡡࡷ࠰ࡰࡽࡸࡱࡩ࡯࠰ࡹ࡭ࡪࡽ࡭ࡰࡦࡨࠫᇡ"),kp1dfOzPDwnjW2)
	wdtXsa0jez = FhcnOB9t3frzvXb(u"ࠧ࠽ࡸ࡬ࡩࡼࡹ࠾ࠨᇢ")+kLy7p6H8FBD0dAUR+XogUJZEijT7KWbxeO6(u"ࠨ࠮ࠪᇣ")+yaiug04tE1H8MpZlmCX+EDPaWgMt1SwNn8o(u"ࠩ࠿࠳ࡻ࡯ࡥࡸࡵࡁࠫᇤ")
	DLK8qQNC0619awSOAkohrJXU7 = SqKW7xf9uRlLa0.replace(Q2SjuMqOkLKyr5JHZTXBtlciUpVE3,wdtXsa0jez)
	if VYMZsxRpcQHPgkaiDKjyoh: DLK8qQNC0619awSOAkohrJXU7 = DLK8qQNC0619awSOAkohrJXU7.encode(EDPaWgMt1SwNn8o(u"ࠪࡹࡹ࡬࠸ࠨᇥ"))
	open(V2DgoBNA9vSi5tw6ZG3RE,Ej67fFyoqW8kbV2HdSK(u"ࠫࡼࡨࠧᇦ")).write(DLK8qQNC0619awSOAkohrJXU7)
	tr24ZoudmqvxfYCw(ZSJVq5XDrRot(u"ࠬࡔࡏࡕࡋࡆࡉࠬᇧ"),aVLSn1xw5cK(u"࠭࠮ࠡࠢࡖ࡯࡮ࡴࠠࡅࡧࡩࡥࡺࡲࡴࠡࡘ࡬ࡩࡼࡹ࠺ࠡ࡝ࠣࠫᇨ")+kLy7p6H8FBD0dAUR+LmcNhzY6fQPd2JyCGslkSr(u"ࠧࠡ࡟ࠪᇩ"))
	if showDialogs: cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(JMLhEyaBWmskovGHTrVCxQ08(u"ࠨࡔࡨࡰࡴࡧࡤࡔ࡭࡬ࡲ࠭࠯ࠧᇪ"))
	return
def GGdBXtWJ2UO8QfImxT():
	YYkEu4IL0sTa = OxCB4medn1(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩࠪᇫ"),fR68jBGWCzUsFXdlTKPOScugm(u"ࠪࠫᇬ"),wwyUWMFAsO(u"ࠫࠬᇭ"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᇮ"),J3OCAmZVcn(u"࠭ศา่ส้ัูࠦๆษาࠤๆ๐็ࠡ็ื็้ฯฺ่ࠠา็ࠥ࠴࠮࠯ࠢศ้ฬࠦรๅวุำฬืࠠใัํ้ࠥ࠴࠮࠯ࠢฦ์ࠥอๆห่้๋ࠢ๎ูࠡ็้ࠤฬูสฯัส้ࠥอไษำ้ห๊าࠠ࠯࠰࠱ࠤศ๎ࠠๅัํ็๋ࠥิไๆฬࠤศิั๊ࠢอาฺࠦฬ่ษี็ࠥษๆห๋่ࠢฬࠦสฯืࠣฬ็๐ษࠡะ็ๆࠥอไๅ้ࠣࡠࡳࡢ࡮ࠡฯส์้ࠦสฮัํฯࠥอไษำ้ห๊าࠠฤ๊ࠣหฯ฻ไࠡสส่๊ฮัๆฮ่๊ࠣ฿ัโหࠣือฮࠠศๆุ่่๊ษࠡ฻้ำ่ࠦ࠮࠯࠰๋้ࠣࠦสา์าࠤๆำีࠡษ็ฮาี๊ฬษอࠤฬ๊ย็ࠢยࠫᇯ"))
	if YYkEu4IL0sTa==sArCMRngQNmXkBoKv(u"࠳ᗩ"): LLMXenCcYZHSN4OKzy9R(sArCMRngQNmXkBoKv(u"ࡘࡷࡻࡥᙢ"),sArCMRngQNmXkBoKv(u"ࡘࡷࡻࡥᙢ"))
	return
def IFz8cq9Qj2UC5dWKMuXlb6NJw():
	HHTzVhiY079bvdluNkFQ4wCMpe(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧࠨᇰ"),DLSVmlyBbCK(u"ࠨࠩᇱ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᇲ"),LmcNhzY6fQPd2JyCGslkSr(u"๋ࠪีอࠠศๆ่์็฿ࠠๆ฼็ๆ๋ࠥๆࠡษ็ฺ้ีั๊ࠡ฽๎ึࠦๅฺำ๋ๅ๋ࠥส๋ࠢํีั฿ࠠๅๆ฼้้࠭ᇳ"))
	return
def p3AqitSPuRf7cnLxvrab1():
	uu5SDqLcCs7IUA = xuYvdJpOEyQKTLNwb(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣสฺัสำฺฺ๊ࠥหࠣฦ้ࠦๅฮ็าࠤู้ๆสࠢ࠵࠴࠷࠷ࠠ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᇴ")
	uu5SDqLcCs7IUA += kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠬอไๆ๊ๅ฽ࠥษฯ็ษ๊ࠤๆ๐็ࠡวะูฬฬ๊สࠢ็฽ิีࠠศๆื๎฾ฯࠠโ์ࠣห้฿วๅ็ࠣฮ๊ࠦฬๆ฻๊ห๋ࠥๆࠡฮ่๎฾ࠦวๅ็ุหิืࠠศๆ่ฮํ็ัสࠢไ๎ࠥอไฦ่อี๋ะࠠศๆๅำ๏๋ษ๊ࠡส่ัี๊ะหࠣห้ำใ้็ํอࠥ๎วๅ฼ํีࠥำใ้็ํอࠥ๎ๅ็ࠢฯ้๏฿ࠠะ๊็ࠤฬู๊ศๆ่ࠤะ๋ࠠห็ࠣฮํำ๊ะ้สࠤํำำศสࠣหู้๋ะๆࠣัุฮࠠิๅส๊ࠥี่ๅࠢส่฾อไๆࠢ็ื๋ฯࠠ࠳࠲࠵࠵ࠥ๎็๋ࠢส่สำีศศํอࠥอไฤฯาฯࠥ๎วๅลื้้ࠦวๅฬํࠤฯฺ๋ࠠ็็๋ฬࠦแ๋ࠢสุ่์่ศฬࠣห้฿ิาหࠣห้๋วื์ฬࠫᇵ")
	uu5SDqLcCs7IUA += gnfv8UtZ3daGqpjzk(u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹ࡯࡮ࡺ࠰ࡦࡧ࠴ࡹࡨࡪࡣࡦࡳࡺࡴࡴ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᇶ")
	zzPuKeTq6I4gHrRA3aUDmEpVyl = MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟หี๋อๅอࠢืี๏฽ࠠศๆ่ื้๋ࠠ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᇷ")
	zzPuKeTq6I4gHrRA3aUDmEpVyl += LmcNhzY6fQPd2JyCGslkSr(u"ࠨ้๋ࠤ฾ฮวาหࠣ฽๋ࠦศา่ส้ั๊้ࠦใิࠤ๊฿ไ้็สฮࠥำำศสํอ้ࠥห๋ำฬࠤฯํๅࠡฮ่๎฾ࠦวๅ็ึ่๊๐ๆࠡ็ฮ่ࠥษ่ใษอࠤฬ๊ีๅษฬࠤํษ่ใษอࠤฬ๊ใิ๊ไࠤํอไฯี๋ๅࠥ๎ิไๆࠣห้่ๅา๋ࠢวํ่วหࠢส่็๋ั๊ࠡฦ๎฻อ๋๊ࠠไีࠥืฤ๋หࠣห้ํไศๆࠣๅ๏ࠦฬๆ์฼ࠤิ๎ไࠡษ็฽ฬ๊ๅ๊ࠡฦ๎฻อࠠโ์๊ࠤฯ่่๋็้ࠣ๏๊วะ์ࠣ์์าั๋๋ࠢๅ๏ํࠠฤ์ูหࠥฮอฬ๋ࠢๆึอมสࠢส่็ืย็๋ࠢว๏฼วࠡใํ๋ࠥอำหะสีฮ่ࠦหใสศ้่ࠦโ์๊ࠤศ่่ศๆู้๋่ࠣษห่้ࠣษๅศ็ࠣ฽้๐้ࠠล่์ึࠦรฯำ์ࠤฯํๅࠡๅ็ࠤู๊ไๆࠢ࠱ࠤฬ๊ศา่ส้ัࠦๅไฬ๋ฬࠥฮไ฻หࠣะฬ็วࠡีๆีอะ้ࠠ์ึฮำีๅ่ࠡ฻ห๊่๋่ࠦา์ืࠦสฮฬࠣฬ๏ฬษ๊ࠡํ๊ิ๎าࠡๅสะ๏ะ้ࠠ็ัฺูࠦแใู่ࠣศา็ำหࠣห้๎๊็ั๋ึࠥ࠴ࠠศๆ่์็฿ࠠศๆิื๊๐ࠠๅๆหี๋อๅอ๊ࠢ์ࠬᇸ")
	zzPuKeTq6I4gHrRA3aUDmEpVyl += eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࡨࡵࡶࡳࡷ࠿࠵࠯ࡵ࡫ࡱࡽ࠳ࡩࡣ࠰࡯ࡸࡷࡱ࡯࡭ࡳࡷ࡯ࡩࡷࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᇹ")
	LaX1QCyeIJ = EDPaWgMt1SwNn8o(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩᇺ")+uu5SDqLcCs7IUA+ZSJVq5XDrRot(u"ࠫࡡࡴ࡜࡯࡞ࡱ࡟ࡗ࡚ࡌ࡞ࠩᇻ")+zzPuKeTq6I4gHrRA3aUDmEpVyl
	FD5mbRq2ypcA6QOUE8hG(aVLSn1xw5cK(u"ࠬࡸࡩࡨࡪࡷࠫᇼ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"࠭ࠧᇽ"),LaX1QCyeIJ)
	return
def TlD1doFipMsk0y(pxc6J0d9LuvQ1tPWfTD4bn):
	UAyxKVL2kthjd(KxirmCLT6Gw)
	EC5XwtROefg9UNdSvQ = KLSU61gP7bs5QBrp(pxc6J0d9LuvQ1tPWfTD4bn)
	id,hhC9JITqv3yWEGFm,X3OBj9hFudG,xOV4lRWI2Ak37E,kwRd5A8WqiVBQ4cxf0rNPbC7XaSUF2,reason = EC5XwtROefg9UNdSvQ[ZSJVq5XDrRot(u"࠳ᗪ")]
	YPINwkvUA9arTds6y,zzuOx8f13Np = xOV4lRWI2Ak37E.split(gnfv8UtZ3daGqpjzk(u"ࠧ࡝ࡰ࠾࠿ࠬᇾ"))
	zzPuKeTq6I4gHrRA3aUDmEpVyl,zb9ro4X6jnBHhxpg,kAotrbLajs5J2m8 = kwRd5A8WqiVBQ4cxf0rNPbC7XaSUF2.split(aVLSn1xw5cK(u"ࠨ࡞ࡱ࠿ࡀ࠭ᇿ"))
	Je2Nmw1cv7xa39jBASIg0zWq = sArCMRngQNmXkBoKv(u"࡙ࡸࡵࡦᙣ")
	while Je2Nmw1cv7xa39jBASIg0zWq:
		AOYzmEMG1f0KgDCb2usBehxwXH6ZaI = A0iaw7hK4Qmc2EeHXZB(xuYvdJpOEyQKTLNwb(u"ࠩࠪሀ"),AAgpHN0nMZ(u"ࠪาึ๎ฬࠨሁ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠫสืำศๆࠣีุอไสࠢ็่๊ฮัๆฮࠪሂ"),jYaM5vilgZdFx6QHbApwVXO8et(u"่ࠬวว็ฬࠤฬ๊สษำ฼หฯ࠭ሃ"),fR68jBGWCzUsFXdlTKPOScugm(u"࠭ไฦ์ๅหๆࠦวๅว฼่ฬ์วหࠢ࠽ࠤࠥะศา฻ࠣวํࠦวๆีะࠤฬ๊ศา่ส้ั࠭ሄ"),zzPuKeTq6I4gHrRA3aUDmEpVyl)
		if AOYzmEMG1f0KgDCb2usBehxwXH6ZaI==JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠶ᗫ"): A9AQn3cmpVarM = A0iaw7hK4Qmc2EeHXZB(Ej67fFyoqW8kbV2HdSK(u"ࠧࠨህ"),c4QSTnPiWUCjhrLlwGB(u"ࠨࠩሆ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠩ฼์ิฯࠧሇ"),gnfv8UtZ3daGqpjzk(u"ࠪࠫለ"),gSmqZU0plur2xKPJwQA(u"๊ࠫฮฯฤࠢส่ฯฮัฺࠢ฽๎ึࠦโศส็ࠤ้๊ๆใษืࠫሉ"),zb9ro4X6jnBHhxpg,AAgpHN0nMZ(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥࡳ࡮ࡣ࡯ࡰ࡫ࡵ࡮ࡵࠩሊ"))
		elif AOYzmEMG1f0KgDCb2usBehxwXH6ZaI==aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠶ᗬ"): HvcsiXhFR9Dw1()
		else: Je2Nmw1cv7xa39jBASIg0zWq = bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࡌࡡ࡭ࡵࡨᙤ")
	cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(FhcnOB9t3frzvXb(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪላ"))
	return
def ggCEbNwx1l7e(showDialogs):
	YYkEu4IL0sTa = m6b7CoBk4EQ(u"ࡔࡳࡷࡨᙥ")
	if showDialogs: YYkEu4IL0sTa = OxCB4medn1(pEo8g7riWVL014KaRtzQ(u"ࠧࡤࡧࡱࡸࡪࡸࠧሌ"),OVmSuf8tpd(u"ࠨࠩል"),aVLSn1xw5cK(u"ࠩࠪሎ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠪืษอไࠨሏ"),J3OCAmZVcn(u"ࠫ์๊ࠠฤ่อࠤ๊ะรไัࠣ์ฯื๊ะ่ࠢืา่ࠦหืไ๎ึࠦฬๆ์฼ࠤส฿ฯศัสฮࠥฮั็ษ่ะࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠡ࠰ࠣั๏ัࠠห฻๋ำࠥาๅ๋฻ࠣห้หูะษาหฯࠦลๅ๋ࠣ์฻฿๊สࠢอฯอ๐สࠡษ็ฬึ์วๆฮࠣรࠬሐ"))
	if YYkEu4IL0sTa:
		ybf3Qo7isaYVr = PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࡕࡴࡸࡩᙦ")
		if hhHq8m5vauKG9dl.path.exists(vHLfqUjC0xy):
			try: hhHq8m5vauKG9dl.remove(vHLfqUjC0xy)
			except: ybf3Qo7isaYVr = EDPaWgMt1SwNn8o(u"ࡈࡤࡰࡸ࡫ᙧ")
		if showDialogs:
			if ybf3Qo7isaYVr: HHTzVhiY079bvdluNkFQ4wCMpe(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠬ࠭ሑ"),EDPaWgMt1SwNn8o(u"࠭ࠧሒ"),FhcnOB9t3frzvXb(u"ࠧࠨሓ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨฬ่ࠤอ์ฬศฯุ้ࠣำ้ࠠฬุๅ๏ืࠠๆๆไࠤส฿ฯศัสฮࠥฮั็ษ่ะࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠨሔ"))
			else: HHTzVhiY079bvdluNkFQ4wCMpe(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩࠪሕ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪࠫሖ"),xuYvdJpOEyQKTLNwb(u"ࠫࠬሗ"),JMLhEyaBWmskovGHTrVCxQ08(u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡ็ึั๋ࠥไโࠢส่ส฿ฯศัสฮࠬመ"))
	return
def OycaYRWLHfr5mUdsXZTintFQz7quVb():
	M6V2LFP1hmqaYJEz0RD4I35nX()
	Y4YRqAJFEU1Oc = j2agIU0xsLS6c7T.getSetting(aVLSn1xw5cK(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬሙ"))
	LaX1QCyeIJ = {}
	LaX1QCyeIJ[pEo8g7riWVL014KaRtzQ(u"ࠧࡂࡗࡗࡓࠬሚ")] = bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨษ็็ฬฺࠠศๆอ่็อฦ๋ࠢํ฽๊๊ࠧማ")
	LaX1QCyeIJ[J3OCAmZVcn(u"ࠩࡖࡘࡔࡖࠧሜ")] = gnfv8UtZ3daGqpjzk(u"ࠪห้้วี่ࠢฮํ่แࠡฬ่ห๊อ้ࠠสส่่อๅๅࠩም")
	LaX1QCyeIJ[JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࡑࡏࡍࡊࡖࡈࡈࠬሞ")] = xuYvdJpOEyQKTLNwb(u"้ࠬวีࠢฯำฬࠦโึ์ิࠤฬ๊ๅะ๋ࠣ࠲ࠥ࠭ሟ")+str(ii5ULJKfcyuVn/kRYWcNuAazr4jtmBoxFVS19Z6(u"࠼࠰ᗭ"))+hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭ࠠะไํๆฮࠦแใูࠪሠ")
	sswNyo1F2LjmPp6f7D = LaX1QCyeIJ[Y4YRqAJFEU1Oc]
	PTQimzWJpkrt6H = A0iaw7hK4Qmc2EeHXZB(gnfv8UtZ3daGqpjzk(u"ࠧࠨሡ"),wwyUWMFAsO(u"ࠨๅสุࠥ࠭ሢ")+str(ii5ULJKfcyuVn/FhcnOB9t3frzvXb(u"࠶࠱ᗮ"))+JMLhEyaBWmskovGHTrVCxQ08(u"ࠩࠣำ็๐โสࠩሣ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩሤ"),OVmSuf8tpd(u"ࠫส๐โศใࠣ็ฬ๋ไࠨሥ"),sswNyo1F2LjmPp6f7D,EDPaWgMt1SwNn8o(u"ࠬํไࠡฬิ๎ิࠦวิฬัำฬ๋ࠠศๆๆหูࠦวๅาๆ๎ࠥอไหๆๅหห๐ࠠฤ็ࠣฮึ๐ฯࠡวํๆฬ็ࠠศๆๆหูࠦศศๆๆห๊๊ࠠฤ็ࠣฮึ๐ฯࠡๅสุࠥ฿ๅา้ࠣๆฺ๐ัࠡฮาหࠥลࠡࠨሦ"))
	if PTQimzWJpkrt6H==gnfv8UtZ3daGqpjzk(u"࠱ᗯ"): tTC65dploRsK = pEo8g7riWVL014KaRtzQ(u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧሧ")
	elif PTQimzWJpkrt6H==EDPaWgMt1SwNn8o(u"࠳ᗰ"): tTC65dploRsK = xuYvdJpOEyQKTLNwb(u"ࠧࡂࡗࡗࡓࠬረ")
	elif PTQimzWJpkrt6H==AAgpHN0nMZ(u"࠵ᗱ"): tTC65dploRsK = Ej67fFyoqW8kbV2HdSK(u"ࠨࡕࡗࡓࡕ࠭ሩ")
	else: tTC65dploRsK = JMLhEyaBWmskovGHTrVCxQ08(u"ࠩࠪሪ")
	if tTC65dploRsK:
		j2agIU0xsLS6c7T.setSetting(xuYvdJpOEyQKTLNwb(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡨࡵࡶࡳࡧࡦࡩࡨࡦࠩራ"),tTC65dploRsK)
		oYja2qZGVTeuX0v = LaX1QCyeIJ[tTC65dploRsK]
		HHTzVhiY079bvdluNkFQ4wCMpe(yTMWeCgUROcvtsblfK85L62xPk(u"ࠫࠬሬ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬ࠭ር"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭ࠧሮ"),oYja2qZGVTeuX0v)
	return
def I6fHznR0sdAT():
	LaX1QCyeIJ = {}
	LaX1QCyeIJ[c4QSTnPiWUCjhrLlwGB(u"ࠧࡂࡗࡗࡓࠬሯ")] = gSmqZU0plur2xKPJwQA(u"ࠨีํีๆืࠠࡅࡐࡖࠤฬ๊สๅไสส๏ฺ๊ࠦ็็࠾ࠥ࠭ሰ")
	LaX1QCyeIJ[JMLhEyaBWmskovGHTrVCxQ08(u"ࠩࡄࡗࡐ࠭ሱ")] = AAgpHN0nMZ(u"ࠪื๏ืแาࠢࡇࡒࡘࠦำ๋฻่่ࠥฮูะࠢสุ่๋วฮࠢ็๋࠿ࠦࠧሲ")
	LaX1QCyeIJ[EDPaWgMt1SwNn8o(u"ࠫࡘ࡚ࡏࡑࠩሳ")] = Ej67fFyoqW8kbV2HdSK(u"ู๊ࠬาใิࠤࡉࡔࡓࠡ็อ์็็ࠠห็ส้ฬ่ࠦษษ็็ฬ๋ไࠨሴ")
	zy7GlnZE2qVPTtYQreCgWX = j2agIU0xsLS6c7T.getSetting(gSmqZU0plur2xKPJwQA(u"࠭ࡡࡷ࠰ࡧࡲࡸ࠭ስ"))
	Y4YRqAJFEU1Oc = j2agIU0xsLS6c7T.getSetting(pEo8g7riWVL014KaRtzQ(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪሶ"))
	sswNyo1F2LjmPp6f7D = LaX1QCyeIJ[Y4YRqAJFEU1Oc]+zy7GlnZE2qVPTtYQreCgWX
	PTQimzWJpkrt6H = A0iaw7hK4Qmc2EeHXZB(c4QSTnPiWUCjhrLlwGB(u"ࠨࠩሷ"),kmdSKeBIwViM9t3(u"ࠩอุ฿๐ไࠡ฻้ำࠥอไๆ๊สๅ็ฯࠧሸ"),sArCMRngQNmXkBoKv(u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩሹ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠫส๐โศใࠣ็ฬ๋ไࠨሺ"),sswNyo1F2LjmPp6f7D,XogUJZEijT7KWbxeO6(u"ู๊ࠬาใิࠤࡉࡔࡓ้๋ࠡࠤัํวำࠢไ๎ࠥอไฦ่อี๋๐สࠡ์ๅ์๊ࠦศหฯ๋๎้ࠦริ็สลࠥอไๆ๊สๆ฾่ࠦศๆึ๎ึ็ัศฬࠣษ้๏ࠠฤำๅหฺ๊่่ࠦาࠤอ฿ึࠡษ็๊ฬู๋ࠠไ๋้ࠥฮออสࠣ์๊์ู๊ࠡะฺึࠦศฺุࠣห้๋่ศไ฼ࠤ࠳ࠦไหึ฽๎้ࠦำ๋ำไีࠥࡊࡎࡔࠢๅ้ࠥฮวฯฬํหึࠦวๅีํีๆืࠠศๆ่๊ฬูศࠡล๋ࠤ็๋ࠠษวํๆฬ็็ࠡสส่่อๅๅࠩሻ"))
	if PTQimzWJpkrt6H==FhcnOB9t3frzvXb(u"࠴ᗲ"): tTC65dploRsK = EDPaWgMt1SwNn8o(u"࠭ࡁࡔࡍࠪሼ")
	elif PTQimzWJpkrt6H==c4QSTnPiWUCjhrLlwGB(u"࠶ᗳ"): tTC65dploRsK = J3OCAmZVcn(u"ࠧࡂࡗࡗࡓࠬሽ")
	elif PTQimzWJpkrt6H==MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠸ᗴ"): tTC65dploRsK = bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࡕࡗࡓࡕ࠭ሾ")
	if PTQimzWJpkrt6H in [jYaM5vilgZdFx6QHbApwVXO8et(u"࠱ᗶ"),fR68jBGWCzUsFXdlTKPOScugm(u"࠱ᗵ")]:
		YYkEu4IL0sTa = OxCB4medn1(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠩࡦࡩࡳࡺࡥࡳࠩሿ"),sArCMRngQNmXkBoKv(u"ࠪื๏ืแา࠼ࠣࠫቀ")+XK2WaStRNq[ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠳ᗷ")],sArCMRngQNmXkBoKv(u"ุࠫ๐ัโำ࠽ࠤࠬቁ")+XK2WaStRNq[pEo8g7riWVL014KaRtzQ(u"࠳ᗸ")],sArCMRngQNmXkBoKv(u"ࠬ࠭ቂ"),AAgpHN0nMZ(u"࠭รฯฬสีู๊ࠥาใิࠤࡉࡔࡓࠡษ็้๋อำษࠢ็็ࠬቃ"))
		if YYkEu4IL0sTa==JMLhEyaBWmskovGHTrVCxQ08(u"࠵ᗹ"): JTAZ6uOVaXPrRFzLifMgw3tlGxE = XK2WaStRNq[ZSJVq5XDrRot(u"࠵ᗺ")]
		else: JTAZ6uOVaXPrRFzLifMgw3tlGxE = XK2WaStRNq[kmdSKeBIwViM9t3(u"࠷ᗻ")]
	elif PTQimzWJpkrt6H==jYaM5vilgZdFx6QHbApwVXO8et(u"࠲ᗼ"): JTAZ6uOVaXPrRFzLifMgw3tlGxE = XogUJZEijT7KWbxeO6(u"ࠧࠨቄ")
	else: tTC65dploRsK = JMLhEyaBWmskovGHTrVCxQ08(u"ࠨࠩቅ")
	if tTC65dploRsK:
		j2agIU0xsLS6c7T.setSetting(yTMWeCgUROcvtsblfK85L62xPk(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬቆ"),tTC65dploRsK)
		j2agIU0xsLS6c7T.setSetting(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠪࡥࡻ࠴ࡤ࡯ࡵࠪቇ"),JTAZ6uOVaXPrRFzLifMgw3tlGxE)
		oYja2qZGVTeuX0v = LaX1QCyeIJ[tTC65dploRsK]+JTAZ6uOVaXPrRFzLifMgw3tlGxE
		HHTzVhiY079bvdluNkFQ4wCMpe(sArCMRngQNmXkBoKv(u"ࠫࠬቈ"),ZSJVq5XDrRot(u"ࠬ࠭቉"),OVmSuf8tpd(u"࠭ࠧቊ"),oYja2qZGVTeuX0v)
	return
def EEs46Yvh3iD5txgQUPIzWZe9():
	Y4YRqAJFEU1Oc = j2agIU0xsLS6c7T.getSetting(DLSVmlyBbCK(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬቋ"))
	LaX1QCyeIJ = {}
	LaX1QCyeIJ[JMLhEyaBWmskovGHTrVCxQ08(u"ࠨࡃࡘࡘࡔ࠭ቌ")] = fR68jBGWCzUsFXdlTKPOScugm(u"ࠩส่อื่ไีํࠤฬ๊สๅไสส๏ࠦฬศ้ีࠤู้๊ๆๆࠪቍ")
	LaX1QCyeIJ[EDPaWgMt1SwNn8o(u"ࠪࡅࡘࡑࠧ቎")] = XogUJZEijT7KWbxeO6(u"ࠫฬ๊ศา๊ๆื๏ࠦำ๋฻่่ࠥฮูะࠢสุ่๋วฮࠢ็๋ࠬ቏")
	LaX1QCyeIJ[OVmSuf8tpd(u"࡙ࠬࡔࡐࡒࠪቐ")] = EDPaWgMt1SwNn8o(u"࠭วๅสิ์ู่๊ࠡ็อ์็็ࠠห็ส้ฬ่ࠦษษ็็ฬ๋ไࠨቑ")
	sswNyo1F2LjmPp6f7D = LaX1QCyeIJ[Y4YRqAJFEU1Oc]
	PTQimzWJpkrt6H = A0iaw7hK4Qmc2EeHXZB(aVLSn1xw5cK(u"ࠧࠨቒ"),wwyUWMFAsO(u"ࠨฬื฾๏ฺ๊่ࠠาࠤฬ๊ๅ้ษไๆฮ࠭ቓ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠩอุ฿๐ไࠡฬ็ๆฬฬ๊ࠨቔ"),m6b7CoBk4EQ(u"ࠪษ๏่วโࠢๆห๊๊ࠧቕ"),sswNyo1F2LjmPp6f7D,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫฬ๊ศา๊ๆื๏ࠦ็้ࠢฯ๋ฬุࠠโ์ࠣห้หๆหำ้๎ฯฺ๊ࠦ็็ࠤํูุ๊ࠢห๎๋ࠦฬ่ษี็ࠥ๎วๅว้ฮึ์๊หࠢ࠱ࠤ์๎๋ࠠีอ่๊ࠦืๅสสฮ่่๋ࠦไ๋้ࠥฮำฮส๊หࠥฮฯๅษ้๋้ࠣࠠฬ็ࠣ๎อ฿ห่ษ่่ࠣࠦ࠮้ࠡ็ࠤฯื๊ะࠢอุ฿๐ไࠡล่ࠤส๐โศใࠣห้ฮั้ๅึ๎ࠥลࠧቖ"))
	if PTQimzWJpkrt6H==wwyUWMFAsO(u"࠱ᗽ"): tTC65dploRsK = fR68jBGWCzUsFXdlTKPOScugm(u"ࠬࡇࡓࡌࠩ቗")
	elif PTQimzWJpkrt6H==xuYvdJpOEyQKTLNwb(u"࠳ᗾ"): tTC65dploRsK = Ej67fFyoqW8kbV2HdSK(u"࠭ࡁࡖࡖࡒࠫቘ")
	elif PTQimzWJpkrt6H==JMLhEyaBWmskovGHTrVCxQ08(u"࠵ᗿ"): tTC65dploRsK = aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧࡔࡖࡒࡔࠬ቙")
	else: tTC65dploRsK = yTMWeCgUROcvtsblfK85L62xPk(u"ࠨࠩቚ")
	if tTC65dploRsK:
		j2agIU0xsLS6c7T.setSetting(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧቛ"),tTC65dploRsK)
		oYja2qZGVTeuX0v = LaX1QCyeIJ[tTC65dploRsK]
		HHTzVhiY079bvdluNkFQ4wCMpe(pEo8g7riWVL014KaRtzQ(u"ࠪࠫቜ"),AAgpHN0nMZ(u"ࠫࠬቝ"),pEo8g7riWVL014KaRtzQ(u"ࠬ࠭቞"),oYja2qZGVTeuX0v)
	return
def EtpePavw6CyRoxI0OBWcLHn3dr2():
	RsB1atZJ30IkXiGnQE9jW72wOSd = j2agIU0xsLS6c7T.getSetting(aVLSn1xw5cK(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭቟"))
	if RsB1atZJ30IkXiGnQE9jW72wOSd==gSmqZU0plur2xKPJwQA(u"ࠧࡔࡖࡒࡔࠬበ"): header = JMLhEyaBWmskovGHTrVCxQ08(u"ࠨฬัึ๏์ࠠศๆๅ์ฬฬๅࠡ็อ์็็ࠧቡ")
	else: header = XogUJZEijT7KWbxeO6(u"ࠩอาื๐ๆࠡษ็ๆํอฦๆ่ࠢๅ฾๊ࠧቢ")
	YYkEu4IL0sTa = OxCB4medn1(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠪࠫባ"),XogUJZEijT7KWbxeO6(u"ࠫส๐โศใࠪቤ"),AAgpHN0nMZ(u"ࠬะแฺ์็ࠫብ"),header,JMLhEyaBWmskovGHTrVCxQ08(u"࠭โ้ษษ้ࠥอไษำ้ห๊า๋ࠠฬ่ࠤฯำฯ๋อ๊หࠥษ่ห๊่หฯ๐ใ๋ษࠣฬ฾ีࠠ࠲࠸ࠣืฬ฿ษࠡ็้ࠤศ๎ไࠡลึฮำีวๆࠢ࠱࠲ࠥ๎ล๋ไสๅࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠥ๐ฤะ์ࠣษ้๏ࠠหฯา๎ะํวࠡใํࠤ่๊ࠠๆำฬࠤ๏ะๅࠡษึฮำีวๆࠢส่็๎วว็ࠣ࠲࠳่่ࠦาสࠤ๏ูศษࠢห฻หࠦแ๋ࠢไฮาࠦโ้ษษ้ࠥอไษำ้ห๊า࡜࡯࡞ࡱࠤ์๊ࠠหำํำࠥะแฺ์็ࠤศ๋ࠠฦ์ๅหๆࠦสฯิํ๊ࠥอไใ๊สส๊ࠦฟࠢࠣࠪቦ"))
	if YYkEu4IL0sTa==-MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠵ᘀ"): return
	elif YYkEu4IL0sTa:
		j2agIU0xsLS6c7T.setSetting(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫ࠧቧ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨࡃࡘࡘࡔ࠭ቨ"))
		HHTzVhiY079bvdluNkFQ4wCMpe(gnfv8UtZ3daGqpjzk(u"ࠩࠪቩ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࠫቪ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧቫ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬะๅࠡฬไ฽๏๊ࠠหะี๎๋ࠦวๅไ๋หห๋ࠧቬ"))
	else:
		j2agIU0xsLS6c7T.setSetting(DLSVmlyBbCK(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭ቭ"),gnfv8UtZ3daGqpjzk(u"ࠧࡔࡖࡒࡔࠬቮ"))
		HHTzVhiY079bvdluNkFQ4wCMpe(J3OCAmZVcn(u"ࠨࠩቯ"),FhcnOB9t3frzvXb(u"ࠩࠪተ"),aVLSn1xw5cK(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ቱ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫฯ๋ࠠฦ์ๅหๆࠦสฯิํ๊ࠥอไใ๊สส๊࠭ቲ"))
	return
def ZyRBeVh7iH3obnftmDdjsPUrw(uHGMxiZfcoErOyXghvnWUK):
	if uHGMxiZfcoErOyXghvnWUK!=MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠬ࠭ታ"):
		uHGMxiZfcoErOyXghvnWUK = BXdJu6DpcG9k8ieCLWtZ(uHGMxiZfcoErOyXghvnWUK)
		uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.decode(yTMWeCgUROcvtsblfK85L62xPk(u"࠭ࡵࡵࡨ࠻ࠫቴ")).encode(OVmSuf8tpd(u"ࠧࡶࡶࡩ࠼ࠬት"))
		MSXZoqyGgxAmhP09wW = Ej67fFyoqW8kbV2HdSK(u"࠶࠶࠱࠱࠵ᘁ")
		m8mkFvZWVyK02XwGxpeR9nIEifA4 = kGEPsyxKnHDJ.Window(MSXZoqyGgxAmhP09wW)
		m8mkFvZWVyK02XwGxpeR9nIEifA4.getControl(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠹࠱࠲ᘂ")).setLabel(uHGMxiZfcoErOyXghvnWUK)
	return
MgZYrPXeFA4Kb9 = [
			 c4QSTnPiWUCjhrLlwGB(u"ࠣࡧࡻࡸࡪࡴࡳࡪࡱࡱࠤࠬ࠭ࠠࡪࡵࠣࡲࡴࡺࠠࡤࡷࡵࡶࡪࡴࡴ࡭ࡻࠣࡷࡺࡶࡰࡰࡴࡷࡩࡩࠨቶ")
			,kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩࡆ࡬ࡪࡩ࡫ࡪࡰࡪࠤ࡫ࡵࡲࠡࡏࡤࡰ࡮ࡩࡩࡰࡷࡶࠤࡸࡩࡲࡪࡲࡷࡷࠬቷ")
			,pEo8g7riWVL014KaRtzQ(u"ࠪࡔ࡛ࡘࠠࡊࡒࡗ࡚࡙ࠥࡩ࡮ࡲ࡯ࡩࠥࡉ࡬ࡪࡧࡱࡸࠬቸ")
			,JMLhEyaBWmskovGHTrVCxQ08(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥ࡜ࡩࡥࡧࡲࠤࡎࡴࡦࡰࠢࡎࡩࡾ࠭ቹ")
			,ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬࡺࡨࡪࡵࠣ࡬ࡦࡹࡨࠡࡨࡸࡲࡨࡺࡩࡰࡰࠣ࡭ࡸࠦࡢࡳࡱ࡮ࡩࡳ࠭ቺ")
			,EDPaWgMt1SwNn8o(u"࠭ࡵࡴࡧࡶࠤࡵࡲࡡࡪࡰࠣࡌ࡙࡚ࡐࠡࡨࡲࡶࠥࡧࡤࡥ࠯ࡲࡲࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡳࠨቻ")
			,gnfv8UtZ3daGqpjzk(u"ࠧࡢࡦࡹࡥࡳࡩࡥࡥ࠯ࡸࡷࡦ࡭ࡥ࠯ࡪࡷࡱࡱ࠭ቼ")+AAgpHN0nMZ(u"ࠨࠥࠪች")+kmdSKeBIwViM9t3(u"ࠩࡶࡷࡱ࠳ࡷࡢࡴࡱ࡭ࡳ࡭ࡳࠨቾ")
			,fR68jBGWCzUsFXdlTKPOScugm(u"ࠪࡍࡳࡹࡥࡤࡷࡵࡩࡗ࡫ࡱࡶࡧࡶࡸ࡜ࡧࡲ࡯࡫ࡱ࡫࠱࠭ቿ")
			,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫࡊࡸࡲࡰࡴࠣ࡫ࡪࡺࡴࡪࡰࡪࠤࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈ࠴ࡅ࡭ࡰࡦࡨࡩࡂ࠶ࠦࡵࡧࡻࡸࡹࡃࠧኀ")
			,wwyUWMFAsO(u"ࠬࡽࡡࡳࡰ࡬ࡲ࡬ࡹ࠮ࡸࡣࡵࡲ࠭࠭ኁ")
			,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭࡞࡟ࡠࡡࡢࠬኂ")
			,pEo8g7riWVL014KaRtzQ(u"ࠧࡍࡱࡤࡨ࡮ࡴࡧࠡࡵ࡮࡭ࡳࠦࡦࡪ࡮ࡨ࠾ࠬኃ")
			]
def IGHRM75XNLl2phBqvxf(yJzVl8aho4tDk65mAsT3N):
	if pEo8g7riWVL014KaRtzQ(u"ࠨࡎࡲࡥࡩ࡯࡮ࡨࠢࡶ࡯࡮ࡴࠠࡧ࡫࡯ࡩ࠿࠭ኄ") in yJzVl8aho4tDk65mAsT3N and hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧኅ") in yJzVl8aho4tDk65mAsT3N: return PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࡗࡶࡺ࡫ᙨ")
	for uHGMxiZfcoErOyXghvnWUK in MgZYrPXeFA4Kb9:
		if uHGMxiZfcoErOyXghvnWUK in yJzVl8aho4tDk65mAsT3N: return sArCMRngQNmXkBoKv(u"ࡘࡷࡻࡥᙩ")
	return Ej67fFyoqW8kbV2HdSK(u"ࡋࡧ࡬ࡴࡧᙪ")
def wFrAySctgUnK0LuVYqp41B9zX(data):
	data = data.replace(kmdSKeBIwViM9t3(u"ࠪࡠࡷࡢ࡮ࠨኆ")+EDPaWgMt1SwNn8o(u"࠵࠲ᘃ")*kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫࠥ࠭ኇ")+m6b7CoBk4EQ(u"ࠬࡢࡲ࡝ࡰࠪኈ"),DLSVmlyBbCK(u"࠭࡜ࡳ࡞ࡱࠫ኉"))
	data = data.replace(gnfv8UtZ3daGqpjzk(u"ࠧ࡝ࡰࠪኊ")+fR68jBGWCzUsFXdlTKPOScugm(u"࠶࠳ᘄ")*ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨࠢࠪኋ")+ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠩ࡟ࡶࡡࡴࠧኌ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࡠࡷࡢ࡮ࠨኍ"))
	data = data.replace(gSmqZU0plur2xKPJwQA(u"ࠫࡡࡴࠧ኎")+JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠷࠴ᘅ")*PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬࠦࠧ኏")+aVLSn1xw5cK(u"࠭࡜࡯ࠩነ"),wwyUWMFAsO(u"ࠧ࡝ࡰࠪኑ"))
	data = data.replace(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨ࡞ࡱࠫኒ")+aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠹࠶ᘇ")*FhcnOB9t3frzvXb(u"ࠩࠣࠫና"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠪࡠࡳ࠭ኔ")+aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠶࠵ᘆ")*MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠫࠥ࠭ን"))
	data = data.replace(gSmqZU0plur2xKPJwQA(u"ࠬࠦ࠼ࡨࡧࡱࡩࡷࡧ࡬࠿࠼ࠣࠫኖ"),ZSJVq5XDrRot(u"࠭࠺ࠡࠩኗ"))
	BTMputsaqV = gSmqZU0plur2xKPJwQA(u"ࠧࠨኘ")
	for yJzVl8aho4tDk65mAsT3N in data.splitlines():
		xku4EXmFnU = ZXFs0mEPR8qI2zj.findall(sArCMRngQNmXkBoKv(u"ࠨࠢࠣࠤࠥࠦࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠮ࠪࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧኙ"),yJzVl8aho4tDk65mAsT3N,ZXFs0mEPR8qI2zj.DOTALL)
		if xku4EXmFnU: yJzVl8aho4tDk65mAsT3N = yJzVl8aho4tDk65mAsT3N.replace(xku4EXmFnU[bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠵ᘈ")],hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠩࠪኚ"))
		BTMputsaqV += J3OCAmZVcn(u"ࠪࡠࡳ࠭ኛ")+yJzVl8aho4tDk65mAsT3N
	return BTMputsaqV
def tKLGpmBwMZjJ(JpdsKlDRYrLVO1AjzxZmc):
	if aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠫࡔࡒࡄࠨኜ") in JpdsKlDRYrLVO1AjzxZmc:
		XdEpgcCjxln76B = sFgrS6kNYvPtD3u0x1L
		header = AAgpHN0nMZ(u"่ࠬัศรฬࠤฬ๊ำอๆࠣห้่ฯ๋็ࠣรࠬኝ")
	else:
		XdEpgcCjxln76B = wkKn0yuX13
		header = m6b7CoBk4EQ(u"࠭โาษฤอࠥอไิฮ็ࠤฬ๊อศๆํࠤฤ࠭ኞ")
	YYkEu4IL0sTa = OxCB4medn1(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧࠨኟ"),pEo8g7riWVL014KaRtzQ(u"ࠨࠩአ"),wwyUWMFAsO(u"ࠩࠪኡ"),header,Ej67fFyoqW8kbV2HdSK(u"ࠪืั๊ࠠศๆฦา฼อมࠡ์ะฮํ๐ࠠฤ์ูหࠥ฿ไ๊ࠢึะ้ࠦวๅษึฮำีวๆࠢ࠱ࠤํอไศอ้๎๋ࠦึา๊ิ๎ฮࠦไๆ฻ิๅฮࠦใ๋ใࠣัิัสࠡษ็ู้้ไส๋้ࠢฬࠦ็้ࠢส่๊้ว็ࠢส่ี๐ࠠิสหࠤาี่ฬࠢสฺ่๊ใๅหࠣ࠲้่ࠥะ์ࠣ๎าะแูࠢหืั๊๊็ࠢ࠱ࠤฬ๊ร้ๆ๋ࠣํࠦวๅีฯ่ࠥอไฮษ็๎ࠥ๎แ๋้้ࠣ฾๊่ๆษอࠤฯฮฯฤ่๊ࠢีࠦศะษํอࠥอไหึ฽๎้ࠦวๅฯส่๏ࠦไษำ้ห๊าࠠไ๊า๎ࠥ๎วๅ๋ࠣห้ศๆࠡ࠰ࠣว๊อࠠศๆึะ้ࠦวๅไา๎๊ࠦแ่๊ࠣหู้ฬๅࠢสุ่อศใࠢส่ี๐ࠠห็ࠣะ๊฿็ࠡ็้ࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢๅฬ้ࠦยฯำࠣษ฼็วยࠢ็๋ࠥ࠴่ࠠๆࠣฮึ๐ฯࠡษ็หุะๅาษิࠤฤ࠭ኢ"))
	if YYkEu4IL0sTa!=xuYvdJpOEyQKTLNwb(u"࠷ᘉ"): return
	H2wDGnUdkNV5Fm8asReX,qq3nmoTeXK2t8j4PFZ = [],aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠰ᘊ")
	size,count = ssIxDJ3iKeVqBUvFYW4r(XdEpgcCjxln76B)
	file = open(XdEpgcCjxln76B,c4QSTnPiWUCjhrLlwGB(u"ࠫࡷࡨࠧኣ"))
	if size>ZSJVq5XDrRot(u"࠳࠳࠴࠷࠶࠰ᘌ"): file.seek(-ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠲࠲࠳࠵࠵࠶ᘋ"),hhHq8m5vauKG9dl.SEEK_END)
	data = file.read()
	file.close()
	if VYMZsxRpcQHPgkaiDKjyoh: data = data.decode(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠬࡻࡴࡧ࠺ࠪኤ"))
	data = wFrAySctgUnK0LuVYqp41B9zX(data)
	YYyAscnV8LouaiJz = data.split(ZSJVq5XDrRot(u"࠭࡜࡯ࠩእ"))
	for yJzVl8aho4tDk65mAsT3N in reversed(YYyAscnV8LouaiJz):
		pGgf8qAHEIFdyV0MbCnrOlcS6ui9U = IGHRM75XNLl2phBqvxf(yJzVl8aho4tDk65mAsT3N)
		if pGgf8qAHEIFdyV0MbCnrOlcS6ui9U: continue
		yJzVl8aho4tDk65mAsT3N = yJzVl8aho4tDk65mAsT3N.replace(m6b7CoBk4EQ(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࡠࠩኦ"),Ej67fFyoqW8kbV2HdSK(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧኧ"))
		yJzVl8aho4tDk65mAsT3N = yJzVl8aho4tDk65mAsT3N.replace(EDPaWgMt1SwNn8o(u"ࠩࡈࡖࡗࡕࡒ࠻ࠩከ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆ࠱࠲࠳࠴ࡢࡋࡒࡓࡑࡕ࠾ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ኩ"))
		isMYOWFKoBhUIRLSgrwpxPqz = c4QSTnPiWUCjhrLlwGB(u"ࠫࠬኪ")
		ttz1W2LaJXxo = ZXFs0mEPR8qI2zj.findall(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬࡤࠨ࡝ࡦ࠮࠱࠭ࡢࡤࠬ࠯࡟ࡨ࠰ࠦ࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤ࡚ࠬࠫࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬካ"),yJzVl8aho4tDk65mAsT3N,ZXFs0mEPR8qI2zj.DOTALL)
		if ttz1W2LaJXxo:
			yJzVl8aho4tDk65mAsT3N = yJzVl8aho4tDk65mAsT3N.replace(ttz1W2LaJXxo[ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠴ᘎ")][ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠴ᘎ")],ttz1W2LaJXxo[ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠴ᘎ")][ZSJVq5XDrRot(u"࠴ᘍ")]).replace(ttz1W2LaJXxo[ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠴ᘎ")][JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠷ᘏ")],J3OCAmZVcn(u"࠭ࠧኬ"))
			isMYOWFKoBhUIRLSgrwpxPqz = ttz1W2LaJXxo[Ej67fFyoqW8kbV2HdSK(u"࠰ᘑ")][eeIL1TfgFQJaKqVD8hGNPEZ(u"࠷ᘐ")]
		else:
			ttz1W2LaJXxo = ZXFs0mEPR8qI2zj.findall(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧ࡟ࠪ࡟ࡨ࠰ࡀ࡜ࡥ࠭࠽ࡠࡩ࠱࡜࠯࡞ࡧ࠯࠮࠮ࠠࡕ࠼࡟ࡨ࠰࠯ࠧክ"),yJzVl8aho4tDk65mAsT3N,ZXFs0mEPR8qI2zj.DOTALL)
			if ttz1W2LaJXxo:
				yJzVl8aho4tDk65mAsT3N = yJzVl8aho4tDk65mAsT3N.replace(ttz1W2LaJXxo[wwyUWMFAsO(u"࠲ᘓ")][EDPaWgMt1SwNn8o(u"࠲ᘒ")],fR68jBGWCzUsFXdlTKPOScugm(u"ࠨࠩኮ"))
				isMYOWFKoBhUIRLSgrwpxPqz = ttz1W2LaJXxo[bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠳ᘔ")][bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠳ᘔ")]
		if isMYOWFKoBhUIRLSgrwpxPqz: yJzVl8aho4tDk65mAsT3N = yJzVl8aho4tDk65mAsT3N.replace(isMYOWFKoBhUIRLSgrwpxPqz,sArCMRngQNmXkBoKv(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬኯ")+isMYOWFKoBhUIRLSgrwpxPqz+J3OCAmZVcn(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬኰ"))
		H2wDGnUdkNV5Fm8asReX.append(yJzVl8aho4tDk65mAsT3N)
		if len(str(H2wDGnUdkNV5Fm8asReX))>jYaM5vilgZdFx6QHbApwVXO8et(u"࠹࠵࠷࠰࠱ᘕ"): break
	H2wDGnUdkNV5Fm8asReX = reversed(H2wDGnUdkNV5Fm8asReX)
	v9vNbm6WPZfJI5YnL3rDieTXR = JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠫࡡࡴࠧ኱").join(H2wDGnUdkNV5Fm8asReX)
	FD5mbRq2ypcA6QOUE8hG(xuYvdJpOEyQKTLNwb(u"ࠬࡲࡥࡧࡶࠪኲ"),AAgpHN0nMZ(u"࠭ยฯำࠣวุ฽ัࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠪኳ"),v9vNbm6WPZfJI5YnL3rDieTXR,eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪኴ"))
	return
def aqWbDur87TEoAvs():
	oH7Sc50ItmplaYvRsnK = open(oHI0G2nwtkFxjlORMQfc6sJ,aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨࡴࡥࠫኵ")).read()
	if VYMZsxRpcQHPgkaiDKjyoh: oH7Sc50ItmplaYvRsnK = oH7Sc50ItmplaYvRsnK.decode(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩࡸࡸ࡫࠾ࠧ኶"))
	oH7Sc50ItmplaYvRsnK = oH7Sc50ItmplaYvRsnK.replace(wwyUWMFAsO(u"ࠪࡠࡹ࠭኷"),wwyUWMFAsO(u"ࠫࠥࠦࠠࠡࠢࠣࠤࠥ࠭ኸ"))
	ZUCy6NxE0T7rkjYLpScutH81 = ZXFs0mEPR8qI2zj.findall(JMLhEyaBWmskovGHTrVCxQ08(u"ࠬ࠮ࡶ࡝ࡦ࠱࠮ࡄ࠯࡛࡝ࡰ࡟ࡶࡢ࠭ኹ"),oH7Sc50ItmplaYvRsnK,ZXFs0mEPR8qI2zj.DOTALL)
	for yJzVl8aho4tDk65mAsT3N in ZUCy6NxE0T7rkjYLpScutH81:
		oH7Sc50ItmplaYvRsnK = oH7Sc50ItmplaYvRsnK.replace(yJzVl8aho4tDk65mAsT3N,LmcNhzY6fQPd2JyCGslkSr(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩኺ")+yJzVl8aho4tDk65mAsT3N+aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩኻ"))
	JATO6o8EHKZLIsaQV(sArCMRngQNmXkBoKv(u"ࠨษ็ฮ฿๐๊าษอࠤฬ๊รฯ์ิอࠥ็๊ࠡษ็ฬึอๅอࠩኼ"),oH7Sc50ItmplaYvRsnK)
	return
def g3tClM2DqI():
	uu5SDqLcCs7IUA = Ej67fFyoqW8kbV2HdSK(u"ࠩห฽฻ࠦวๅลีีฬืฺࠠๆ์ࠤฬ๊ั๋็๋ฮ้่ࠥ็ฬิ์้ࠦส้ใิࠤส๋ใศ่ํอࠥะโะ์่ࠤํะรฯ์ิࠤฬ๊แ๋ัํ์ࠥ๎็ั้ࠣห้ษาาษิࠤ์๐ࠠศๆฦื์๋้ࠠษ็วึ่วๆ่ࠢ฽ࠥฮูื๋ࠢ็ฬ๊สศๆํࠫኽ")
	zzPuKeTq6I4gHrRA3aUDmEpVyl = AAgpHN0nMZ(u"่ࠪฯ่ฯ๋็ࠣห้็๊ะ์๋ࠤฬูสฯั่ࠤฬ๊ำ่็ࠣห้๐ๅ๋่ࠣ์้ะรฯ์ิ๋ࠥอำหะา้ࠥอไิ้่ࠤฬ๊๊ิษิࠤ࠳ࠦรๆษࠣ฽ิฯࠠศี๊้๋ࠥสหษ็๎ฮࠦแ่า๊ࠤฯ่่ๆࠢหฮาื๊ไࠢส่ๆ๐ฯ๋๊ࠣฬํ่สࠡษๆฬึࠦๅ็๋ࠢๆฯࠦวๅี๊้ࠥอไ้ษะำࠥ࠴ࠠฤ็สࠤฬ๊ำ่็ࠣห้ษูๅ๋ࠣ์ฬ๊ริใ็ࠤๆํ่ࠡ์ะี่ࠦวๅใํำ๏๎ࠠฦๆ์ࠤฬ๊รๆษ่ࠤศ๎ࠠฦๆ์ࠤฬ๊่าษฤࠤํ๊ใ็ࠢหๆๆุษࠡๅห๎ึฯࠧኾ")
	zb9ro4X6jnBHhxpg = JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠫศ๋วࠡษ็วึ่วๆࠢไ๋๏ࠦสิฬัำ๊ࠦไๅฬๅำ๏๋้ࠠษ็ฮศิ๊า๋่่ࠢ์ࠠษ็ๅำฬืฺࠠัาࠤฬ๊ห้ษ้๎ࠥ๎วๅัๅหห่ࠠ࠯่ࠢฯ้อࠠาไ่ࠤ࠺࠺࠴ࠡฬ฼๊๏ࠦ࠵ࠡัๅหห่้ࠠࠢ࠷࠸ࠥัว็์ฬࠤส๊้ࠡษ็ว๊อๅࠡล๋ࠤส๊้ࠡษ็์ึอมࠡสะือࠦวิฬัำฬ๋ใࠡๆ็ื์๋ࠠศๆํ้๏์ࠠฤ๊ࠣื์๋ࠠศๆํืฬืࠧ኿")
	LaX1QCyeIJ = uu5SDqLcCs7IUA+Ej67fFyoqW8kbV2HdSK(u"ࠬࡀࠠࠨዀ")+zzPuKeTq6I4gHrRA3aUDmEpVyl+fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࠠ࠯ࠢࠪ዁")+zb9ro4X6jnBHhxpg
	FD5mbRq2ypcA6QOUE8hG(JMLhEyaBWmskovGHTrVCxQ08(u"ࠧࡤࡧࡱࡸࡪࡸࠧዂ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫዃ"),LaX1QCyeIJ,LmcNhzY6fQPd2JyCGslkSr(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬዄ"))
	return
def lkRNq72CIhOaXQWb(type,LaX1QCyeIJ,showDialogs=bdhQDyjm3nPwToFHkprvCzBLUGR(u"࡚ࡲࡶࡧᙫ"),url=JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠪࠫዅ"),j5jMXZ7myEuoLG=MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠫࠬ዆"),uHGMxiZfcoErOyXghvnWUK=ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬ࠭዇"),a4BAuzi56OETxFSj3YtoZGU8k7=aVLSn1xw5cK(u"࠭ࠧወ")):
	QQnaRSv5CTVWUqLouc = DLSVmlyBbCK(u"ࡔࡳࡷࡨᙬ")
	if not ynO4oHRV3Mj6Z9gNh(ZSJVq5XDrRot(u"ࠧࡄࡖࡈ࠽ࡉ࡙࠱࠺ࡘࡘ࠴࡛࡙ࡘࠨዉ")):
		if showDialogs:
			VexOD927np = (ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨษ็ื฼ื࠺ࠨዊ") in LaX1QCyeIJ and ZSJVq5XDrRot(u"ࠩส่๊้ว็࠼ࠪዋ") in LaX1QCyeIJ and jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪห้๋ไโ࠼ࠪዌ") in LaX1QCyeIJ and FhcnOB9t3frzvXb(u"ࠫฬ๊ฮุลࠪው") in LaX1QCyeIJ and gSmqZU0plur2xKPJwQA(u"ࠬอไๆืาี࠿࠭ዎ") in LaX1QCyeIJ)
			if not VexOD927np: QQnaRSv5CTVWUqLouc = OxCB4medn1(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ዏ"),wwyUWMFAsO(u"ࠧࠨዐ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠨࠩዑ"),Ej67fFyoqW8kbV2HdSK(u"๊่ࠩࠥะัิๆ๋ࠣีํࠠศๆิืฬ๊ษࠡว็ํࠥอไๆสิ้ั࠭ዒ"),LaX1QCyeIJ.replace(Ej67fFyoqW8kbV2HdSK(u"ࠪࡠࡡࡴࠧዓ"),ZSJVq5XDrRot(u"ࠫࡡࡴࠧዔ")))
	elif showDialogs:
		LaX1QCyeIJ = wwyUWMFAsO(u"ࠬࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไส࡞࡟ࡲฯ๋ࠠๆีะࠤึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไส࡞࡟ࡲฯ๋ࠠๆีะࠤฬ๊ัิษ็อࠬዕ")
		yWr16IoAU9GBkMlf = OxCB4medn1(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ዖ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠧࠨ዗"),J3OCAmZVcn(u"ࠨࠩዘ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩዙ")+LmcNhzY6fQPd2JyCGslkSr(u"ࠪࠤࠥ࠷࠯࠶ࠩዚ"),gSmqZU0plur2xKPJwQA(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩዛ"))
		e5jqD7Z9hOwSQlCtGsyT6ViuF = OxCB4medn1(c4QSTnPiWUCjhrLlwGB(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬዜ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࠧዝ"),OVmSuf8tpd(u"ࠧࠨዞ"),gSmqZU0plur2xKPJwQA(u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨዟ")+DLSVmlyBbCK(u"ࠩࠣࠤ࠷࠵࠵ࠨዠ"),AAgpHN0nMZ(u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨዡ"))
		md01cRb7VSPX6ipA = OxCB4medn1(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫዢ"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬ࠭ዣ"),xuYvdJpOEyQKTLNwb(u"࠭ࠧዤ"),aVLSn1xw5cK(u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧዥ")+aVLSn1xw5cK(u"ࠨࠢࠣ࠷࠴࠻ࠧዦ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧዧ"))
		TXnfWGF5BEZYLlaqDhtjr67beK92g = OxCB4medn1(LmcNhzY6fQPd2JyCGslkSr(u"ࠪࡧࡪࡴࡴࡦࡴࠪየ"),xuYvdJpOEyQKTLNwb(u"ࠫࠬዩ"),wwyUWMFAsO(u"ࠬ࠭ዪ"),OVmSuf8tpd(u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭ያ")+aVLSn1xw5cK(u"ࠧࠡࠢ࠷࠳࠺࠭ዬ"),wwyUWMFAsO(u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭ይ"))
		QQnaRSv5CTVWUqLouc = OxCB4medn1(EDPaWgMt1SwNn8o(u"ࠩࡦࡩࡳࡺࡥࡳࠩዮ"),m6b7CoBk4EQ(u"ࠪࠫዯ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠫࠬደ"),aVLSn1xw5cK(u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬዱ")+pEo8g7riWVL014KaRtzQ(u"࠭ࠠࠡ࠷࠲࠹ࠬዲ"),sArCMRngQNmXkBoKv(u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬዳ"))
	hhC9JITqv3yWEGFm = HHWAnGJrb9powOqTkYgcPQ6Ef(FhcnOB9t3frzvXb(u"࠸࠸ᘖ"),gSmqZU0plur2xKPJwQA(u"ࡇࡣ࡯ࡷࡪ᙭"))
	sOe9EKtvlQiLYd3WI7MmB6T = eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨࡃ࡙࠾ࠥ࠭ዴ")+hhC9JITqv3yWEGFm+fR68jBGWCzUsFXdlTKPOScugm(u"ࠩ࠰ࠫድ")+type
	GwLHvcBPTiMSJVAQedjk549yg6CUNm = PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࡗࡶࡺ࡫ᙯ") if wwyUWMFAsO(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭ዶ") in uHGMxiZfcoErOyXghvnWUK else kRYWcNuAazr4jtmBoxFVS19Z6(u"ࡈࡤࡰࡸ࡫᙮")
	if not QQnaRSv5CTVWUqLouc:
		if showDialogs: HHTzVhiY079bvdluNkFQ4wCMpe(pEo8g7riWVL014KaRtzQ(u"ࠫࠬዷ"),ZSJVq5XDrRot(u"ࠬ࠭ዸ"),JMLhEyaBWmskovGHTrVCxQ08(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩዹ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧห็ࠣษ้เวยࠢส่สืำศๆࠣฬ๋อมࠡ฻็ํࠥ฽ไษๅࠪዺ"))
		return jYaM5vilgZdFx6QHbApwVXO8et(u"ࡊࡦࡲࡳࡦᙰ")
	D7zd5YJReVEomjCXKifUOxSpLH = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.getInfoLabel(J3OCAmZVcn(u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡈࡵ࡭ࡪࡴࡤ࡭ࡻࡑࡥࡲ࡫ࠧዻ"))
	LaX1QCyeIJ += c4QSTnPiWUCjhrLlwGB(u"ࠩࠣࡠࡡࡴ࡜࡝ࡰࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࠣࡠࡡࡴࡁࡥࡦࡲࡲࠥ࡜ࡥࡳࡵ࡬ࡳࡳࡀࠠࠨዼ")+i69DxzEZSwmuY5Il+sArCMRngQNmXkBoKv(u"ࠪࠤ࠿ࡢ࡜࡯ࠩዽ")
	LaX1QCyeIJ += PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫࡊࡳࡡࡪ࡮ࠣࡗࡪࡴࡤࡦࡴ࠽ࠤࠬዾ")+hhC9JITqv3yWEGFm+JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬࠦ࠺࡝࡞ࡱࡏࡴࡪࡩࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠫዿ")+RDroKU08JGFn53dsguECSkYTW1+JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭ࠠ࠻࡞࡟ࡲࠬጀ")
	LaX1QCyeIJ += eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧࡌࡱࡧ࡭ࠥࡔࡡ࡮ࡧ࠽ࠤࠬጁ")+D7zd5YJReVEomjCXKifUOxSpLH
	K6yLQmfzv7OAXCqln9oig0U4a3St = lTqcJaeunfS2YrEVIFNmMHG()
	K6yLQmfzv7OAXCqln9oig0U4a3St = cD1AgYCl0qZI8(K6yLQmfzv7OAXCqln9oig0U4a3St)
	if K6yLQmfzv7OAXCqln9oig0U4a3St: LaX1QCyeIJ += gSmqZU0plur2xKPJwQA(u"ࠨࠢ࠽ࡠࡡࡴࡌࡰࡥࡤࡸ࡮ࡵ࡮࠻ࠢࠪጂ")+K6yLQmfzv7OAXCqln9oig0U4a3St
	if url: LaX1QCyeIJ += AAgpHN0nMZ(u"ࠩࠣ࠾ࡡࡢ࡮ࡖࡔࡏ࠾ࠥ࠭ጃ")+url
	if j5jMXZ7myEuoLG: LaX1QCyeIJ += OVmSuf8tpd(u"ࠪࠤ࠿ࡢ࡜࡯ࡕࡲࡹࡷࡩࡥ࠻ࠢࠪጄ")+j5jMXZ7myEuoLG
	LaX1QCyeIJ += JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࠥࡀ࡜࡝ࡰࠪጅ")
	if showDialogs: NLVM3HAtxQOSvJf6kd78K1o(ZSJVq5XDrRot(u"ࠬาวา์ࠣห้หัิษ็ࠫጆ"),jYaM5vilgZdFx6QHbApwVXO8et(u"࠭วๅำฯหฦࠦวๅษ้ฮ฽อัࠨጇ"))
	if a4BAuzi56OETxFSj3YtoZGU8k7:
		v9vNbm6WPZfJI5YnL3rDieTXR = a4BAuzi56OETxFSj3YtoZGU8k7
		if VYMZsxRpcQHPgkaiDKjyoh: v9vNbm6WPZfJI5YnL3rDieTXR = v9vNbm6WPZfJI5YnL3rDieTXR.encode(AAgpHN0nMZ(u"ࠧࡶࡶࡩ࠼ࠬገ"))
		v9vNbm6WPZfJI5YnL3rDieTXR = EGTVgQoSu6ZsD.b64encode(v9vNbm6WPZfJI5YnL3rDieTXR)
	elif GwLHvcBPTiMSJVAQedjk549yg6CUNm:
		if m6b7CoBk4EQ(u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࡓࡑࡊ࡟ࠨጉ") in uHGMxiZfcoErOyXghvnWUK: D2gGoLdEAih60s4 = sFgrS6kNYvPtD3u0x1L
		else: D2gGoLdEAih60s4 = wkKn0yuX13
		if not hhHq8m5vauKG9dl.path.exists(D2gGoLdEAih60s4):
			HHTzVhiY079bvdluNkFQ4wCMpe(sArCMRngQNmXkBoKv(u"ࠩࠪጊ"),aVLSn1xw5cK(u"ࠪࠫጋ"),J3OCAmZVcn(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧጌ"),gSmqZU0plur2xKPJwQA(u"ูࠬฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠ฻์ิࠤ๊๎ฬ้ัࠪግ"))
			return MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࡋࡧ࡬ࡴࡧᙱ")
		tr24ZoudmqvxfYCw(OVmSuf8tpd(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ጎ"),gnfv8UtZ3daGqpjzk(u"ࠧ࠯ࠢࠣࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡶࡩࡳࡪࠠࡵࡪࡨࠤࡱࡵࡧࡧ࡫࡯ࡩࠬጏ"))
		H2wDGnUdkNV5Fm8asReX,qq3nmoTeXK2t8j4PFZ = [],OVmSuf8tpd(u"࠶ᘗ")
		file = open(D2gGoLdEAih60s4,Ej67fFyoqW8kbV2HdSK(u"ࠨࡴࡥࠫጐ"))
		size,count = ssIxDJ3iKeVqBUvFYW4r(D2gGoLdEAih60s4)
		if size>PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠳࠱࠳࠳࠴࠵ᘘ"): file.seek(-PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠳࠱࠳࠳࠴࠵ᘘ"),hhHq8m5vauKG9dl.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(c4QSTnPiWUCjhrLlwGB(u"ࠩࡸࡸ࡫࠾ࠧ጑"))
		data = wFrAySctgUnK0LuVYqp41B9zX(data)
		YYyAscnV8LouaiJz = data.splitlines()
		for yJzVl8aho4tDk65mAsT3N in reversed(YYyAscnV8LouaiJz):
			pGgf8qAHEIFdyV0MbCnrOlcS6ui9U = IGHRM75XNLl2phBqvxf(yJzVl8aho4tDk65mAsT3N)
			if pGgf8qAHEIFdyV0MbCnrOlcS6ui9U: continue
			ttz1W2LaJXxo = ZXFs0mEPR8qI2zj.findall(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠪࡢ࠭ࡢࡤࠬ࠯ࠫࡠࡩ࠱࠭࡝ࡦ࠮ࠤࡡࡪࠫ࠻࡞ࡧ࠯࠿ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪጒ"),yJzVl8aho4tDk65mAsT3N,ZXFs0mEPR8qI2zj.DOTALL)
			if ttz1W2LaJXxo:
				yJzVl8aho4tDk65mAsT3N = yJzVl8aho4tDk65mAsT3N.replace(ttz1W2LaJXxo[XogUJZEijT7KWbxeO6(u"࠲ᘚ")][XogUJZEijT7KWbxeO6(u"࠲ᘚ")],ttz1W2LaJXxo[XogUJZEijT7KWbxeO6(u"࠲ᘚ")][m6b7CoBk4EQ(u"࠲ᘙ")]).replace(ttz1W2LaJXxo[XogUJZEijT7KWbxeO6(u"࠲ᘚ")][bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠵ᘛ")],m6b7CoBk4EQ(u"ࠫࠬጓ"))
			else:
				ttz1W2LaJXxo = ZXFs0mEPR8qI2zj.findall(J3OCAmZVcn(u"ࠬࡤࠨ࡝ࡦ࠮࠾ࡡࡪࠫ࠻࡞ࡧ࠯ࡡ࠴࡜ࡥ࡚࠭ࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬጔ"),yJzVl8aho4tDk65mAsT3N,ZXFs0mEPR8qI2zj.DOTALL)
				if ttz1W2LaJXxo: yJzVl8aho4tDk65mAsT3N = yJzVl8aho4tDk65mAsT3N.replace(ttz1W2LaJXxo[Ej67fFyoqW8kbV2HdSK(u"࠵ᘝ")][bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠵ᘜ")],kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭ࠧጕ"))
			H2wDGnUdkNV5Fm8asReX.append(yJzVl8aho4tDk65mAsT3N)
			if len(str(H2wDGnUdkNV5Fm8asReX))>gnfv8UtZ3daGqpjzk(u"࠸࠵࠲࠲࠳࠴ᘞ"): break
		H2wDGnUdkNV5Fm8asReX = reversed(H2wDGnUdkNV5Fm8asReX)
		v9vNbm6WPZfJI5YnL3rDieTXR = fR68jBGWCzUsFXdlTKPOScugm(u"ࠧ࡝ࡴ࡟ࡲࠬ጖").join(H2wDGnUdkNV5Fm8asReX)
		v9vNbm6WPZfJI5YnL3rDieTXR = v9vNbm6WPZfJI5YnL3rDieTXR.encode(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨࡷࡷࡪ࠽࠭጗"))
		v9vNbm6WPZfJI5YnL3rDieTXR = EGTVgQoSu6ZsD.b64encode(v9vNbm6WPZfJI5YnL3rDieTXR)
	else: v9vNbm6WPZfJI5YnL3rDieTXR = fR68jBGWCzUsFXdlTKPOScugm(u"ࠩࠪጘ")
	url = uReHcEzxkTm6pN4Q[DLSVmlyBbCK(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪጙ")][jYaM5vilgZdFx6QHbApwVXO8et(u"࠲ᘟ")]
	VbZ1Pig043uIGYQ = {OVmSuf8tpd(u"ࠫࡸࡻࡢ࡫ࡧࡦࡸࠬጚ"):sOe9EKtvlQiLYd3WI7MmB6T,MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ጛ"):LaX1QCyeIJ,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭࡬ࡰࡩࡩ࡭ࡱ࡫ࠧጜ"):v9vNbm6WPZfJI5YnL3rDieTXR}
	wpFmEA3z8JR = A6F71g3cqN4(KxirmCLT6Gw,sArCMRngQNmXkBoKv(u"ࠧࡑࡑࡖࡘࠬጝ"),url,VbZ1Pig043uIGYQ,EDPaWgMt1SwNn8o(u"ࠨࠩጞ"),sArCMRngQNmXkBoKv(u"ࠩࠪጟ"),c4QSTnPiWUCjhrLlwGB(u"ࠪࠫጠ"),xuYvdJpOEyQKTLNwb(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡓࡆࡐࡇࡣࡊࡓࡁࡊࡎ࠰࠵ࡸࡺࠧጡ"))
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	if fR68jBGWCzUsFXdlTKPOScugm(u"ࠬࠨࡳࡶࡥࡦࡩࡪࡪࡥࡥࠤ࠽ࠤ࠶࠲ࠧጢ") in QstumvzTIEUMXCcx06aD4y8nSqH: ybf3Qo7isaYVr = m6b7CoBk4EQ(u"࡚ࡲࡶࡧᙲ")
	else: ybf3Qo7isaYVr = aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࡆࡢ࡮ࡶࡩᙳ")
	if showDialogs:
		if ybf3Qo7isaYVr:
			NLVM3HAtxQOSvJf6kd78K1o(LmcNhzY6fQPd2JyCGslkSr(u"࠭สๆࠢส่สืำศๆࠣฬ๋าวฮࠩጣ"),m6b7CoBk4EQ(u"ࠧࡔࡷࡦࡧࡪࡹࡳࠨጤ"))
			HHTzVhiY079bvdluNkFQ4wCMpe(aVLSn1xw5cK(u"ࠨࠩጥ"),c4QSTnPiWUCjhrLlwGB(u"ࠩࠪጦ"),LmcNhzY6fQPd2JyCGslkSr(u"ࠪࡑࡪࡹࡳࡢࡩࡨࠤࡸ࡫࡮ࡵࠩጧ"),fR68jBGWCzUsFXdlTKPOScugm(u"ࠫฯ๋ࠠฦำึห้ࠦวๅำึห้ฯࠠษ่ฯหา࠭ጨ"))
		else:
			NLVM3HAtxQOSvJf6kd78K1o(yTMWeCgUROcvtsblfK85L62xPk(u"๊ࠬไฤีไࠤๆฺไࠡษ็ษึูวๅࠩጩ"),aVLSn1xw5cK(u"࠭ࡆࡢ࡫࡯ࡹࡷ࡫ࠧጪ"))
			HHTzVhiY079bvdluNkFQ4wCMpe(wwyUWMFAsO(u"ࠧࠨጫ"),gnfv8UtZ3daGqpjzk(u"ࠨࠩጬ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬጭ"),xuYvdJpOEyQKTLNwb(u"ࠪา฼ษ้ࠠใื่ࠥ็๊ࠡวิืฬ๊ࠠศๆิืฬ๊ษࠨጮ"))
	return ybf3Qo7isaYVr
def hNXYWSBkqGI2xACJ4ROcfQTHi10o5():
	uu5SDqLcCs7IUA = Ej67fFyoqW8kbV2HdSK(u"ࠫ࠶࠴ࠠࠡࠢࡌࡪࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡱࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡁࡳࡣࡥ࡭ࡨࠦࡴࡦࡺࡷࡸࠥࡺࡨࡦࡰࠣ࡫ࡴࠦࡴࡰࠢࠥࡏࡴࡪࡩࠡࡋࡱࡸࡪࡸࡦࡢࡥࡨࠤࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸࠨࠠࡢࡰࡧࠤࡨ࡮ࡡ࡯ࡩࡨࠤࡹ࡮ࡥࠡࡨࡲࡲࡹࠦࡴࡰࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠪጯ")
	zzPuKeTq6I4gHrRA3aUDmEpVyl = bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠬ࠷࠮ࠡࠢࠣษีอࠠๅัํ็๋ࠥิไๆฬࠤๆ๐ࠠศๆฦัึ็ࠠศๆ฼ีอ๐ษࠡใสิ์ฮࠠฦๆ์ࠤส฿ฯศัสฮࠥ๎วอ้ฬࠤ่๎ฯ๋ࠢฮ้ࠥเ๊าࠢส่ำ฽ࠠศๆ่ืฯิฯๆࠢศ่๎ࠦࠢࡂࡴ࡬ࡥࡱࠨࠧጰ")
	HHTzVhiY079bvdluNkFQ4wCMpe(sArCMRngQNmXkBoKv(u"࠭ࠧጱ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠧࠨጲ"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠨࡃࡵࡥࡧ࡯ࡣࠡࡒࡵࡳࡧࡲࡥ࡮ࠩጳ"),uu5SDqLcCs7IUA+OVmSuf8tpd(u"ࠩ࡟ࡲࡡࡴࠧጴ")+zzPuKeTq6I4gHrRA3aUDmEpVyl)
	uu5SDqLcCs7IUA = bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪ࠶࠳ࠦࠠࠡࡋࡩࠤࡾࡵࡵࠡࡥࡤࡲࡡ࠭ࡴࠡࡨ࡬ࡲࡩࠦࠢࡂࡴ࡬ࡥࡱࠨࠠࡧࡱࡱࡸࠥࡺࡨࡦࡰࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡴ࡭࡬ࡲࠥࡧ࡮ࡥࠢࡷ࡬ࡪࡴࠠࡤࡪࡤࡲ࡬࡫ࠠࡵࡪࡨࠤ࡫ࡵ࡮ࡵࠩጵ")
	zzPuKeTq6I4gHrRA3aUDmEpVyl = kmdSKeBIwViM9t3(u"ࠫ࠷࠴ࠠࠡࠢศิฬࠦไๆࠢอะิࠦวๅะฺࠤࠧࡇࡲࡪࡣ࡯ࠦࠥ็โๆࠢหฮ฿๐๊าࠢส่ั๊ฯࠡอ่ࠤ็๋ࠠษฬ฽๎ึࠦวๅะฺࠤฬ๊ๅิฬัำ๊ࠦลๅ๋ࠣࠦࡆࡸࡩࡢ࡮ࠥࠫጶ")
	HHTzVhiY079bvdluNkFQ4wCMpe(J3OCAmZVcn(u"ࠬ࠭ጷ"),JMLhEyaBWmskovGHTrVCxQ08(u"࠭ࠧጸ"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠧࡇࡱࡱࡸࠥࡖࡲࡰࡤ࡯ࡩࡲ࠭ጹ"),uu5SDqLcCs7IUA+bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨ࡞ࡱࡠࡳ࠭ጺ")+zzPuKeTq6I4gHrRA3aUDmEpVyl)
	uu5SDqLcCs7IUA = AAgpHN0nMZ(u"ࠩ࠶࠲ࠥࠦࠠࡊࡨࠣࡽࡴࡻࠠࡥࡱࡱࡠࠬࡺࠠࡩࡣࡹࡩࠥࡇࡲࡢࡤ࡬ࡧࠥࡑࡥࡺࡤࡲࡥࡷࡪࠠࡵࡪࡨࡲࠥ࡭࡯ࠡࡶࡲࠤࠧࡑ࡯ࡥ࡫ࠣࡍࡳࡺࡥࡳࡨࡤࡧࡪࠦࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠣࠢࡤࡲࡩࠦࡣࡩࡣࡱ࡫ࡪࠦࡴࡩࡧࠣࡶࡪ࡭ࡩࡰࡰࡤࡰࠥࡹࡥࡵࡶ࡬ࡲ࡬ࡹࠧጻ")
	zzPuKeTq6I4gHrRA3aUDmEpVyl = DLSVmlyBbCK(u"ࠪ࠷࠳ࠦࠠࠡวำห๊ࠥๅࠡ์ๆ๊๊ࠥฯ๋ๅ่ࠣํำษࠡ็ไหฯ๐อࠡ฻ิฬ๏ฯࠠโษำ๋อࠦลๅ๋ࠣษ฾ีวะษอࠤํอฬ่หࠣ็ํี๊ࠡอ่ࠤ฿๐ัࠡว฼ำฬีวหࠢส่๊์ืใหࠣห้าฺาษไ๎ฮ࠭ጼ")
	HHTzVhiY079bvdluNkFQ4wCMpe(sArCMRngQNmXkBoKv(u"ࠫࠬጽ"),c4QSTnPiWUCjhrLlwGB(u"ࠬ࠭ጾ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭ࡆࡰࡰࡷࠤࡕࡸ࡯ࡣ࡮ࡨࡱࠬጿ"),uu5SDqLcCs7IUA+xuYvdJpOEyQKTLNwb(u"ࠧ࡝ࡰ࡟ࡲࠬፀ")+zzPuKeTq6I4gHrRA3aUDmEpVyl)
	YYkEu4IL0sTa = OxCB4medn1(wwyUWMFAsO(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨፁ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩࠪፂ"),kmdSKeBIwViM9t3(u"ࠪࠫፃ"),Ej67fFyoqW8kbV2HdSK(u"ࠫࡋࡵ࡮ࡵࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠫፄ"),gnfv8UtZ3daGqpjzk(u"ࠬࡊ࡯ࠡࡻࡲࡹࠥࡽࡡ࡯ࡶࠣࡸࡴࠦࡧࡰࠢࡷࡳࠥࠨࡋࡰࡦ࡬ࠤࡎࡴࡴࡦࡴࡩࡥࡨ࡫ࠠࡔࡧࡷࡸ࡮ࡴࡧࡴࠤࠣࡲࡴࡽࠠࡀࠩፅ")+JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭࡜࡯࡞ࡱࠫፆ")+LmcNhzY6fQPd2JyCGslkSr(u"่ࠧๆࠣฮึ๐ฯࠡษ็ิ์อศࠡว็ํ๊่ࠥฮหࠣษ฾ีวะษอࠤํอฬ่หࠣ็ํี๊ࠡล็ฦ๋ลࠧፇ"))
	if YYkEu4IL0sTa==c4QSTnPiWUCjhrLlwGB(u"࠲ᘠ"): KQJyISNdlh()
	return
def aa8Z32x7Vkl():
	HHTzVhiY079bvdluNkFQ4wCMpe(c4QSTnPiWUCjhrLlwGB(u"ࠨࠩፈ"),FhcnOB9t3frzvXb(u"ࠩࠪፉ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ፊ"),J3OCAmZVcn(u"ࠫ฿อไษษࠣหู้ศษ๊ࠢ์๋ࠥๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡษ็้฿ึ๊ࠡๆ็ฬึ์วๆฮࠣ์้๊สฤๅาࠤ็๋ࠠษฬื฾๏๊ࠠศๆิหอ฽ࠠศๆำ๎๊ࠥวࠡ์฼้้ࠦหๆࠢๅ้ࠥฮลาีส่๋ࠥิไๆฬࠤส๊้ࠡษ็้อืๅอ่๊ࠢࠥอไใษษ้ฮࠦวๅำษ๎ุ๐ษࠡๆ็ฬึ์วๆฮࠪፋ"))
	return
def N7gwvZyHQ6uqOoGTIM3LJKnXRzbV():
	LaX1QCyeIJ = JMLhEyaBWmskovGHTrVCxQ08(u"ࠬํะศࠢส่อืๆศ็ฯࠤ๊ิีึࠢไๆ฼ࠦไๅ฼ฬࠤฬู๊าสํอࠥ๎ไไ่๋ࠣีอࠠๅษࠣ๎๊์ู๊ࠡฯ์ิࠦๅ้ษๅ฽ࠥ็๊่ษࠣวๆ๊วๆุ๋้๊ࠢำๅษอࠤ๊ะัอ็ฬࠤศ๎ࠠๆัห่ัฯࠠฦๆ์ࠤฬ๊ไ฻หࠣห้฿ัษ์ฬࠤํอไ๊ࠢ็฾ฬะࠠศะิํࠥ๎ไศࠢํ์ัีࠠิสหࠤ้๊สไำสีࠬፌ")
	HHTzVhiY079bvdluNkFQ4wCMpe(wwyUWMFAsO(u"࠭ࠧፍ"),sArCMRngQNmXkBoKv(u"ࠧࠨፎ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫፏ"),LaX1QCyeIJ)
	return
def gT7a5b6IxWHK():
	LaX1QCyeIJ = sArCMRngQNmXkBoKv(u"ࠩส่ึ๎วษูࠣห้ฮื๋ศฬࠤ้อฺࠠๆสๆฮࠦไ่ษࠣฬฬ๊ศา่ส้ั่ࠦ฻ษ็ฬฬࠦวๅีหฬࠥํ่ࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤฬ๊ๅ฻าํࠤ้๊ศา่ส้ั࠭ፐ")
	HHTzVhiY079bvdluNkFQ4wCMpe(kmdSKeBIwViM9t3(u"ࠪࠫፑ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫࠬፒ"),aVLSn1xw5cK(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨፓ"),LaX1QCyeIJ)
	return
def kYU2LCfAKQ8qxmupz09cbrEojya():
	LaX1QCyeIJ = bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭็๋ࠢึ๎ึ็ัศฬ่ࠣฬ๊ࠦิฬฺ๎฾ࠦวๅสิ๊ฬ๋ฬࠡษึฮำีวๆ้สࠤอูศษࠢๆ์๋ํวࠡ็ะ้๏ฯࠠๆ่ࠣห้๋ีะำࠣวํࠦศฮษฯอࠥหไ๊ࠢสุฯืวไࠢิื๊๐ࠠฤ๊ࠣะิ๐ฯสࠢฦ์๊ࠥวࠡ์฼ีๆํวࠡษ็ฬึ์วๆฮࠪፔ")
	HHTzVhiY079bvdluNkFQ4wCMpe(Ej67fFyoqW8kbV2HdSK(u"ࠧࠨፕ"),FhcnOB9t3frzvXb(u"ࠨࠩፖ"),kmdSKeBIwViM9t3(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬፗ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠪื๏ืแาษอࠤุ๐ฦสࠢฦ์๋ࠥฬ่๊็อࠬፘ"),LaX1QCyeIJ)
	return
def OlLWqaxiN8eHTFm7SR5uBsygA():
	LaX1QCyeIJ = JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠫฬ๊ำ๋ำไีฬะࠠศๆ฼ห๊ฯ่ࠠ์ࠣื๏ืแาษอࠤำอัอ์ฬࠤํเ๊าࠢอหอ฿ษࠡๆ็้ํู่ࠡษ็วฺ๊๊๊ࠡฯ้๏฿ࠠศๆ่์ฬู่ࠡฬึฮำีๅ่ษࠣ์฾อฯสࠢอ็ํ์ࠠๆฮส๊๏ฯ้ࠠ็ืห่๊็ศࠢๆฯ๏ืษࠡๆส๊ࠥอไโ์า๎ํํวหࠢไ๎์อࠠฦ็สࠤอ฽๊วหࠣวํࠦๅๆ่๋฽ฮࠦร้่ࠢัี๎แสࠢฦ์ࠥ็๊่ษู้้ࠣไสࠢะๆํ่ࠠศๆ่่่๐ษ࡝ࡰ࡟ࡲࡡࡴวๅีํีๆืวหࠢส่ำอีส๊ࠢ๎ู๊ࠥาใิหฯࠦสศส฼อ๊ࠥไๆ๊ๅ฽ࠥอไฤื็๎ࠥ๎ๅิฬัำ๊ฯࠠโ์้ࠣํอโฺࠢๅ่๏๊ษࠡฮาหࠥ๎ูศัฬࠤฯ้่็่ࠢำๆ๎ูสࠢส่ศาัࠡล๋ࠤ๏๋ไไ้สࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤํ๊็ัษࠣๅ์๐ࠠอ์าอࠥ์ำษ์สࠤํูั๋฻ฬࠤํ๋ิศๅ็๋ฬࠦโๅ์็อࠥาฯศࠩፙ")
	FD5mbRq2ypcA6QOUE8hG(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬፚ"),JMLhEyaBWmskovGHTrVCxQ08(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ፛"),LaX1QCyeIJ,ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ፜"))
	return
def hFiRvbJrWYd78VEco():
	uu5SDqLcCs7IUA = aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨษหฮ฾ีฺ่้้ࠠࠣ็วหࠢส่ิ่ษࠡษ็฽ฬ๊๊สࠩ፝")
	zzPuKeTq6I4gHrRA3aUDmEpVyl = AAgpHN0nMZ(u"ࠩสฬฯ฿ฯࠡ฻้ࠤ๊๊แศฬࠣว้ࠦ࡭࠴ࡷ࠻ࠫ፞")
	zb9ro4X6jnBHhxpg = bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪหอะูะࠢ฼๊๋ࠥไโษอࠤฬ๊สฮ็ํ่ࠥ๎วๅัส์๋๊่ะࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ፟")
	HHTzVhiY079bvdluNkFQ4wCMpe(OVmSuf8tpd(u"ࠫࠬ፠"),gnfv8UtZ3daGqpjzk(u"ࠬ࠭፡"),eeIL1TfgFQJaKqVD8hGNPEZ(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ።"),uu5SDqLcCs7IUA,zzPuKeTq6I4gHrRA3aUDmEpVyl,zb9ro4X6jnBHhxpg)
	return
def M6V2LFP1hmqaYJEz0RD4I35nX():
	zzPuKeTq6I4gHrRA3aUDmEpVyl = m6b7CoBk4EQ(u"ࠧศๆๆหูࠦ็้่ࠢาื์ࠠๆฦๅฮ๊ࠥไๆ฻็์๊อสࠡ์ึฮำีๅ่ࠢส่อืๆศ็ฯࠤ้ิา็ุࠢๅาอสࠡษ็ษ๋ะั็์อࠤํื่ศสฺࠤฬ๊แ๋ัํ์์อสࠡๆ็์ฺ๎ไࠡว็๎์อࠠษีิ฽ฮ่ࠦษั๋๊ࠥหๆหำ้๎ฯ่ࠦศๆหี๋อๅอࠢํุ้ำ็ศࠢอ่็อฦ๋ษࠣฬ฾ีࠠศ่อ๋ฬวฺࠠ็ิ๋ฬ่ࠦฤ์ูหࠥ฿ๆะࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣ࠲ࠥ๎็ัษࠣห้ฮั็ษ่ะࠥ๐ำหะาู้ࠥศฺหࠣว๋๎วฺࠢ็฽๊ืࠠศๆๆหูࠦ࠺ࠨ፣")
	zzPuKeTq6I4gHrRA3aUDmEpVyl += eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨ࡞ࡱࡠࡳ࠭፤") + EDPaWgMt1SwNn8o(u"ࠩ࠴࠲ࠥัวษฬ่้ࠣ฻แฮษอࠤฬ๊ส๋่ࠢ฽ึ๎แࠡล้๋ฬࠦไศࠢอฮ฿๐ั่๊ࠡหห๐ว๊่ࠡำฯํࠠࠨ፥") + str(iKYM8NdkGHmBcr/JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠸࠳ᘡ")/JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠸࠳ᘡ")/kRYWcNuAazr4jtmBoxFVS19Z6(u"࠵࠸ᘢ")/jYaM5vilgZdFx6QHbApwVXO8et(u"࠷࠵ᘣ")) + hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠪࠤูํัࠨ፦")
	zzPuKeTq6I4gHrRA3aUDmEpVyl += LmcNhzY6fQPd2JyCGslkSr(u"ࠫࡡࡴࠧ፧") + JMLhEyaBWmskovGHTrVCxQ08(u"ࠬ࠸࠮ࠡฮาหࠥ฽่๋ๆࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้๋แาู๊ࠤศ์็ศࠢ็หࠥะส฻์ิࠤํ๋ฯห้ࠣࠫ፨") + str(tteHTjUArw/xuYvdJpOEyQKTLNwb(u"࠻࠶ᘤ")/xuYvdJpOEyQKTLNwb(u"࠻࠶ᘤ")/MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠸࠴ᘥ")) + aVLSn1xw5cK(u"๋๊่࠭ࠠࠫ፩")
	zzPuKeTq6I4gHrRA3aUDmEpVyl += yTMWeCgUROcvtsblfK85L62xPk(u"ࠧ࡝ࡰࠪ፪") + eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨ࠵࠱ࠤ฼๎๊ๅࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠ็ษาีฬࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬ፫") + str(JNsoWV1CXc4xy/bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠶࠱ᘦ")/bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠶࠱ᘦ")/EDPaWgMt1SwNn8o(u"࠳࠶ᘧ")) + sArCMRngQNmXkBoKv(u"ࠩࠣ๎ํ๋ࠧ፬")
	zzPuKeTq6I4gHrRA3aUDmEpVyl += jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪࡠࡳ࠭፭") + DLSVmlyBbCK(u"ࠫ࠹࠴ࠠๆฬ๋ื฼ࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅฬํࠤ็ีࠠหฬ฽๎ึ่ࠦๆัอ๋ࠥ࠭፮") + str(Z7uFdWIRv9ybj0/PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠸࠳ᘨ")/PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠸࠳ᘨ")) + aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬࠦำศ฻ฬࠫ፯")
	zzPuKeTq6I4gHrRA3aUDmEpVyl += sArCMRngQNmXkBoKv(u"࠭࡜࡯ࠩ፰") + aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧ࠶࠰ࠣๆฺ๐ัࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํีࠥีวว็สࠤํ๋ฯห้ࠣࠫ፱") + str(dALVaOWB4jKN3Tbt0Cm1ns9k5u/Ej67fFyoqW8kbV2HdSK(u"࠹࠴ᘩ")/Ej67fFyoqW8kbV2HdSK(u"࠹࠴ᘩ")) + yTMWeCgUROcvtsblfK85L62xPk(u"ࠨࠢึห฾ฯࠧ፲")
	zzPuKeTq6I4gHrRA3aUDmEpVyl += aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩ࡟ࡲࠬ፳") + J3OCAmZVcn(u"ࠪ࠺࠳ࠦฬะษࠣๆฺ๐ัࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํี้ࠥห๋ำสࠤํ๋ฯห้ࠣࠫ፴") + str(RwhaLmQ4cpyvfxsPUJVA0DtM/kmdSKeBIwViM9t3(u"࠺࠵ᘪ")) + Ej67fFyoqW8kbV2HdSK(u"ࠫࠥีโ๋ไฬࠫ፵")
	zzPuKeTq6I4gHrRA3aUDmEpVyl += c4QSTnPiWUCjhrLlwGB(u"ࠬࡢ࡮ࠨ፶") + AAgpHN0nMZ(u"࠭࠷࠯ࠢหำํ์ࠠไษืࠤ้๊ีโฯสฮࠥอไห์ࠣฮฯเ๊าࠢหืึ฿ษ๊่ࠡำฯํࠠࠨ፷") + str(KxirmCLT6Gw) + m6b7CoBk4EQ(u"ࠧࠡัๅ๎็ฯࠧ፸")
	zzPuKeTq6I4gHrRA3aUDmEpVyl += AAgpHN0nMZ(u"ࠨ࡞ࡱࡠࡳ࠭፹") + xuYvdJpOEyQKTLNwb(u"่ࠩฯ้อ࠺ࠡืไัฬะࠠใ๊สส๊ࠦวๅลไ่ฬ๋้ࠠษ็ุ้๊ำๅษอࠤํอไฮๆๅหฯูࠦๆำ๊หࠥ࠭፺") + str(Z7uFdWIRv9ybj0/gSmqZU0plur2xKPJwQA(u"࠻࠶ᘫ")/gSmqZU0plur2xKPJwQA(u"࠻࠶ᘫ")) + kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪࠤุอูสࠢ࠱ࠤศ๋วࠡไ๋หห๋ࠠฤ่๋ห฾ࠦวๅใํำ๏๎็ศฬࠣๅ฾๋ั่ษࠣࠫ፻") + str(JNsoWV1CXc4xy/gSmqZU0plur2xKPJwQA(u"࠻࠶ᘫ")/gSmqZU0plur2xKPJwQA(u"࠻࠶ᘫ")/kRYWcNuAazr4jtmBoxFVS19Z6(u"࠸࠴ᘬ")) + aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠫࠥษ๊ศ็ࠣ࠲ࠥษๅศ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠢไ฽๊ื็ศࠢࠪ፼") + str(dALVaOWB4jKN3Tbt0Cm1ns9k5u/gSmqZU0plur2xKPJwQA(u"࠻࠶ᘫ")/gSmqZU0plur2xKPJwQA(u"࠻࠶ᘫ")) + PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬࠦำศ฻ฬࠤๆ่ืࠡ࠰ࠣว๊อࠠโฯุࠤึ่ๅࠡษ็ษฺีวาࠢไ฽๊ื็ࠡࠩ፽") + str(RwhaLmQ4cpyvfxsPUJVA0DtM/gSmqZU0plur2xKPJwQA(u"࠻࠶ᘫ")) + AAgpHN0nMZ(u"࠭ࠠะไํๆฮࠦ࠮ࠡล่หࠥ็อึࠢสุฯืวไࠢใࡍࡕ࡚ࡖࠡใ฼้ึํࠠࠨ፾") + str(KxirmCLT6Gw) + J3OCAmZVcn(u"ࠧࠡัๅ๎็ฯࠧ፿")
	FD5mbRq2ypcA6QOUE8hG(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࡴ࡬࡫࡭ࡺࠧᎀ"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"่ࠩหࠥํ่ࠡษ็็ฬฺࠠศๆ่ืฯิฯๆࠢไ๎ࠥอไษำ้ห๊าࠧᎁ"),zzPuKeTq6I4gHrRA3aUDmEpVyl,ZSJVq5XDrRot(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ᎂ"))
	return
def Bmx8EfZGpO2y1olb9():
	LaX1QCyeIJ = XogUJZEijT7KWbxeO6(u"ࠫฬ๊แศื็อࠥะู็์้ࠣั๊ฯࠡส้ๅุࠦวิ็๊ࠤฬ๊รึๆํࠤํอไ็ไฺอࠥะู็์ࠣว๋ࠦวๅษึ้ࠥอไฤื็๎ࠥะๅࠡฬ฼ำ๏๊็๊ࠡไหฺ๊ษ๊้ࠡๆ฼ฯࠠห฻้ํ๋ࠥฬๅัࠣ์ฯ๋ࠠห฻า๎้ࠦวิ็๊ࠤํฮฯ้่ࠣ฽้อๅสࠢอ฽๋๐ࠠๆๆไࠤอ์แิࠢสื๊ํࠠศๆฦู้๐ࠧᎃ")
	HHTzVhiY079bvdluNkFQ4wCMpe(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠬ࠭ᎄ"),pEo8g7riWVL014KaRtzQ(u"࠭ࠧᎅ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᎆ"),LaX1QCyeIJ)
	return
def RkzZitmuW8KqLGaBC9():
	LaX1QCyeIJ = eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨวำหࠥ๎วอ้อ็๋ࠥิไๆฬࠤๆ๐ࠠศๆืฬ่ฯ้ࠠฬ่ࠤา๊็ศࠢ࠱࠲࠳ࠦร้ࠢส๊่ࠦสู่ࠣว๋ࠦวๅ็๋ๆ฾ࠦวๅลุ่๏ࠦใศ่ࠣๅ๏ํࠠๆึๆ่ฮࠦๅลไอ๋ࠥ๎สๆࠢะ่์อࠠ࠯࠰࠱ࠤๆหะ็ࠢฯีอࠦๅิฯࠣ็ฬฺࠠศๆหี๋อๅอࠢ็็๏๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦศุๆหࠤฬ๊ีโฯฬࠤฬ๊ีฮ์ะอࠥ๎สฯิํ๊์อࠠษั็ห๋ࠥๆࠡษ็ูๆำษࠡษ็ๆิ๐ๅสࠩᎇ")
	HHTzVhiY079bvdluNkFQ4wCMpe(AAgpHN0nMZ(u"ࠩࠪᎈ"),J3OCAmZVcn(u"ࠪࠫᎉ"),DLSVmlyBbCK(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᎊ"),LaX1QCyeIJ)
	return
def kBimwuzGKNgqj43sOYxZycrd2QJMt():
	LaX1QCyeIJ = DLSVmlyBbCK(u"ࠬอไ฻ำูࠤ๊์ࠠี้สำฮࠦวๅฬืๅ๏ืฺ่๊๊ࠠࠣอๆࠡืะอࠥ๎ำา์ฬࠤฬ๊ๅฺๆ๋้ฬะࠠศๆ่ฮออฯๅหࠣฬ๏์ࠠศๆหี๋อๅอ๋ࠢห้๋่ใ฻ࠣห้๋ิโำࠣ์์ึวࠡษ็ฺ๊อๆࠡ฼ํี๋ࠥืๅ๊หࠤํ๊วࠡฯสะฮࠦไ่ࠢ฼๊ิࠦวๅษอูฬ๊ࠠศ๊ࠣห้ืศุ่ࠢ฽๋่ࠥศไ฼ࠤฬ๊แ๋ัํ์์อสࠡษ็ู้็ัสࠩᎋ")
	HHTzVhiY079bvdluNkFQ4wCMpe(EDPaWgMt1SwNn8o(u"࠭ࠧᎌ"),kmdSKeBIwViM9t3(u"ࠧࠨᎍ"),gnfv8UtZ3daGqpjzk(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᎎ"),LaX1QCyeIJ)
	return
def iOdej7CpTsqYb839RoW4ZPm6fcHMU():
	HHTzVhiY079bvdluNkFQ4wCMpe(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩࠪᎏ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࠫ᎐"),J3OCAmZVcn(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ᎑"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"๊ࠬใ๋ࠢํ฽๊๊่ࠠาสࠤฬ๊ๆ้฻้๋ࠣࠦวๅใํำ๏๎็ศฬࠣࡠࡳ๊ࠦอสࠣฮๆ฿๊ๅࠢศฺฬ็ษࠡษึ้์อࠠ࡝ࡰࠣ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ᎒"))
	tTsLa8vMRzfgoVxdwkeW0DXCpKbPn(XogUJZEijT7KWbxeO6(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭᎓"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࡕࡴࡸࡩᙴ"))
	return
def YIwt0rTkJ8s3bPKMUGBCq5ROHZ():
	LaX1QCyeIJ  = ZSJVq5XDrRot(u"ࠧๆฦัีฬࠦโศ็อࠤอ฿ึࠡึิ็ฬะࠠศๆศ๊ฯืๆหࠢส่ิ๎ไ๋ࠢห์฻฿ฺࠠษษๆࠥ฼ฯࠡษ็ฬึอๅอ่ࠢฯ้ࠦใ้ัํࠤ้ะำๆฯࠣๅ็฽ࠠๅส฼ฺ๋ࠥำหะา้๏ࠦวๅ็อูๆำࠠษษ็ำำ๎ไࠡๆ่์ฬู่ࠡษ็ๅ๏ี๊้ࠩ᎔")
	LaX1QCyeIJ += pEo8g7riWVL014KaRtzQ(u"ࠨ๋๊ࠢฯ๐ฬสࠢ็๋ีอࠠศๆ฼หห่ࠠโษ้๋ࠥะโา์หหࠥาๅ๋฻ุ้ࠣะฮะ็ํࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢ็หࠥ๐ำหูํ฽ํ์ࠠศๆาาํ๊ࠠๅฮ่๎฾ࠦๅ้ษๅ฽ࠥอไษำ้ห๊าࠠฮฬ์ࠤ๊฿ࠠศีอาิอๅࠨ᎕")
	LaX1QCyeIJ += aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣเ࡙ࠡࠢࡔࡓࠦࠠฤ๊ࠣࠤࡕࡸ࡯ࡹࡻࠣࠤศ๎ࠠࠡࡆࡑࡗࠥࠦร้ࠢฦ๎ࠥำไࠡสึ๎฼ࠦยฯำ࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳ࠭᎖")
	LaX1QCyeIJ += XogUJZEijT7KWbxeO6(u"ࠪࡠࡳ๊ว็๊ࠢิฬࠦไ็ࠢํั้ࠦวๅ็ื็้ฯ้ࠠว้้ฬࠦแใูࠣื๏่่ๆࠢหษฺ๊วฮࠢห฽฻ࠦวๅ็๋ห็฿้ࠠว฼ห็ฯࠠๆ๊สๆ฾ࠦวฯำ์ࠤ่อๆหࠢอ฽๊๊ࠠิษหๆฬࠦศะ๊้ࠤฺ๊วไๆࠪ᎗")
	FD5mbRq2ypcA6QOUE8hG(AAgpHN0nMZ(u"ࠫࡷ࡯ࡧࡩࡶࠪ᎘"),DLSVmlyBbCK(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ᎙"),LaX1QCyeIJ,gnfv8UtZ3daGqpjzk(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ᎚"))
	LaX1QCyeIJ = ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧศๆ่์ฬู่ࠡษ็ฮ๏ࠦสฤอิฮࠥฮวๅ฻สส็ูࠦ็ัࠣฬ฾฼ࠠศๆ้หุࠦ็๋࠼ࠪ᎛")
	LaX1QCyeIJ += m6b7CoBk4EQ(u"ࠨ࡞ࡱࠫ᎜")+JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡦࡱ࡯ࡢ࡯ࠣࠤࡪ࡭ࡹࡣࡧࡶࡸࠥࠦࡥࡨࡻࡥࡩࡸࡺࡶࡪࡲࠣࠤࡲࡵࡶࡪࡼ࡯ࡥࡳࡪࠠࠡࡵࡨࡶ࡮࡫ࡳ࠵ࡹࡤࡸࡨ࡮ࠠࠡࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ᎝")
	LaX1QCyeIJ += J3OCAmZVcn(u"ࠪࡠࡳࡢ࡮ࠨ᎞")+m6b7CoBk4EQ(u"ࠫฬ๊ฯ้ๆࠣห้ะ๊ࠡฬฦฯึะࠠษษ็฽ฬฬโࠡ฻้ำࠥฮูืࠢส่๋อำ้ࠡํ࠾ࠬ᎟")
	LaX1QCyeIJ += pEo8g7riWVL014KaRtzQ(u"ࠬࡢ࡮ࠨᎠ")+LmcNhzY6fQPd2JyCGslkSr(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞็ุีࠥࠦวๅๅ๋๎ฯࠦࠠฤ็ํี่อࠠࠡๅ้ำฬࠦࠠโำ้ืฬࠦࠠศๆํ์๋อๆࠡࠢหี๏฽ว็์สࠤฬ๊ลๆษิหฯࠦรๅ็ส๊๏อࠠา๊ึ๎ฬࠦวๅ์สฬฬ์ࠠศๆึ฽ํี๊สࠢิ์๊อๆ๋ษ๋ࠣํ๊ๆะษ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᎡ")
	LaX1QCyeIJ += hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧ࡝ࡰ࡟ࡲࠬᎢ")+fR68jBGWCzUsFXdlTKPOScugm(u"ࠨษ็้อืๅอ๋ࠢะิࠦืา์ๅอ๊ࠥสอษ๋ึࠥอไฺษษๆࠥ๎ไไ่๊หࠥะอหษฯࠤัํฯࠡๅห๎ึ่ࠦศๆ่ฬึ๋ฬࠡ์฻๊ࠥอไๆึๆ่ฮࠦี฻์ิอࠥ๎ไศࠢอืฯำโࠡษ็ฮ฾ฮࠠโวำห๊ࠥฯ๋ๅู้้ࠣไสࠢหห้ีฮ้ๆ่ࠣอ฿ึࠡษ็้ํอโฺ๋ࠢว๏฼วࠡๆๆ๎ࠥ๐สืฯࠣัั๋ࠠศๆุ่่๊ษࠡࠩᎣ")
	LaX1QCyeIJ += DLSVmlyBbCK(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡฬืำๅࠢิืฬ๊ษࠡ็วำอฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ๎วไฬหࠤๆ๐็ศࠢสื๊ࠦศๅัๆࠤํษำๆษฤࠤฬ๊ๅ้ษๅ฽ࠥอไห์่ࠣฬࠦสิฬฺ๎฾ࠦฯฯ๊็๋ฬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᎤ")
	FD5mbRq2ypcA6QOUE8hG(sArCMRngQNmXkBoKv(u"ࠪࡶ࡮࡭ࡨࡵࠩᎥ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᎦ"),LaX1QCyeIJ,bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨᎧ"))
	return
def zn7E16cm42eY3qk():
	HHTzVhiY079bvdluNkFQ4wCMpe(jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࠧᎨ"),OVmSuf8tpd(u"ࠧࠨᎩ"),aVLSn1xw5cK(u"ࠨอ็หะࠦืาไ่้ࠣะ่ศื็ࠤ๊฿ࠠศๆ่ฬึ๋ฬࠨᎪ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩฦีุ๊ࠠาีส่ฮࠦรุ้่่๊ࠢษࠡ็้ࠤ็อฦๆหࠣาิ๋วห๊ࠢิฬࠦวๅสิ๊ฬ๋ฬ࡝ࡰ࡟ࡲศ๎ࠠษษึฮำีวๆࠢส่ๆ๐ำษ๊ๆࠤศีๆศ้࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡨࡵࡶࡳ࠾࠴࠵ࡦࡢࡥࡨࡦࡴࡵ࡫࠯ࡥࡲࡱ࠴ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠶࠵࠷࠸࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࡠࡳษ่ࠡสสีุอไࠡษํ้๏๊ࠠศๆ์ࠤศีๆศ้ࠣࠤࡡࡴࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠳࠲࠴࠼ࡅ࡭࡭ࡢ࡫࡯࠲ࡨࡵ࡭࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᎫ"))
	return
def dUGDJnp1Rf80yCuqsW93tFlxvkh7():
	M6V2LFP1hmqaYJEz0RD4I35nX()
	YYkEu4IL0sTa = OxCB4medn1(gSmqZU0plur2xKPJwQA(u"ࠪࡧࡪࡴࡴࡦࡴࠪᎬ"),DLSVmlyBbCK(u"ࠫࠬᎭ"),gnfv8UtZ3daGqpjzk(u"ࠬ࠭Ꭾ"),kmdSKeBIwViM9t3(u"࠭็ๅࠢอี๏ีࠠๆีะࠤัฺ๋๊ࠢส่่อิࠡมࠪᎯ"),LmcNhzY6fQPd2JyCGslkSr(u"ࠧศๆๆหู๊ࠦิำ฼ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣ์ู๊อ่ࠢํ฽๏ีࠠิฯหࠤฬ๊ีโฯสฮ๋ࠥๆࠡษ็ษ๋ะั็ฬࠣ฽๋ีࠠศๆะหัฯࠠฦๆํ๋ฬ่ࠦศๆ่ืา๊ࠦห็ࠣฮ้่วว์สࠤ฾์ฯࠡษ้ฮ์อมࠡ฻่ีࠥอไึใะหฯ่ࠦศๆ่ืาࠦไศࠢํฺึ่ࠦๆ็ๆ๊ࠥ๐อๅࠢห฽฻ࠦวๅ็ืห่๊ࠧᎰ"))
	if YYkEu4IL0sTa==m6b7CoBk4EQ(u"࠱ᘭ"):
		yyGtPJnrR67K(xuYvdJpOEyQKTLNwb(u"ࡖࡵࡹࡪᙵ"))
		HHTzVhiY079bvdluNkFQ4wCMpe(pEo8g7riWVL014KaRtzQ(u"ࠨࠩᎱ"),m6b7CoBk4EQ(u"ࠩࠪᎲ"),c4QSTnPiWUCjhrLlwGB(u"ࠪฮ๊ࠦๅิฯࠣ็ฬฺࠠศๆหี๋อๅอࠢหห้้วๆๆࠪᎳ"),EDPaWgMt1SwNn8o(u"ࠫสึวࠡๅส๊ฯูࠦ็ัๆࠤฺ๊ใๅหࠣๅ๏ࠦวฮัࠣห้๋่ศไ฼ࠤๆาัษࠢส่๊๎โฺࠢส่ว์ࠠ࠯࠰࠱ࠤํษะศࠢสฺ่๊ใๅหุ้ࠣะๅาหࠣๅสึๆࠡษิื้ࠦวๅ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬᎴ"))
	return YYkEu4IL0sTa
def kOriw8l9X0sLv6M7AQqGH1WYo(showDialogs=jYaM5vilgZdFx6QHbApwVXO8et(u"ࡗࡶࡺ࡫ᙶ")):
	if not showDialogs: showDialogs = wwyUWMFAsO(u"ࡘࡷࡻࡥᙷ")
	wpFmEA3z8JR = A6F71g3cqN4(KxirmCLT6Gw,gSmqZU0plur2xKPJwQA(u"ࠬࡍࡅࡕࠩᎵ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡺࡤࡱࡵࡲࡥ࠯ࡥࡲࡱࠬᎶ"),sArCMRngQNmXkBoKv(u"ࠧࠨᎷ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠨࠩᎸ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࡋࡧ࡬ࡴࡧᙸ"),DLSVmlyBbCK(u"ࠩࠪᎹ"),kmdSKeBIwViM9t3(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲ࡎࡔࡕࡒࡖࡣ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭Ꮊ"))
	if not wpFmEA3z8JR.succeeded:
		swKeI16GoiBr7X = OVmSuf8tpd(u"ࡌࡡ࡭ࡵࡨᙹ")
		nnUZQ3KaPgjcv6CuF = YqFHx5cX8apMkfeB()
		tr24ZoudmqvxfYCw(pEo8g7riWVL014KaRtzQ(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩᎻ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+FhcnOB9t3frzvXb(u"ࠬࠦࠠࠡࡊࡗࡘࡕ࡙ࠠࡇࡣ࡬ࡰࡪࡪࠠࠡࠢࡏࡥࡧ࡫࡬࠻࡝ࠪᎼ")+nnUZQ3KaPgjcv6CuF+m6b7CoBk4EQ(u"࠭࡝ࠨᎽ"))
		if showDialogs: HHTzVhiY079bvdluNkFQ4wCMpe(XogUJZEijT7KWbxeO6(u"ࠧࠨᎾ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠨࠩᎿ"),AAgpHN0nMZ(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᏀ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪๅา฻ࠠศๆสฮฺอไࠡษ็ู้็ัࠡ࠰࠱࠲๋ࠥิไๆฬࠤ࠳࠴࠮ࠡษ็หฯ฻วๅࠢสฺ่๊แาࠢࠫห้ืศุࠢสฺ่๊แา่ࠫࠣฬฺ๊ࠦ็็ࠤ฾์ฯไࠢ฼่๎ࠦใ้ัํࠤ࠳࠴࠮๊ࠡ฼๊ิ้ࠠไ๊า๎ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬูสฯัส้ࠥอไๆ๊สๆ฾ࠦวๅ็ืๅึฯࠧᏁ"))
	else:
		swKeI16GoiBr7X = FhcnOB9t3frzvXb(u"ࡔࡳࡷࡨᙺ")
		if showDialogs: HHTzVhiY079bvdluNkFQ4wCMpe(xuYvdJpOEyQKTLNwb(u"ࠫࠬᏂ"),J3OCAmZVcn(u"ࠬ࠭Ꮓ"),ZSJVq5XDrRot(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᏄ"),xuYvdJpOEyQKTLNwb(u"ࠧอ์าࠤัีวࠡ࠰࠱࠲ࠥอไศฬุห้ࠦวๅ็ืๅึࠦࠨศๆิฬ฼ࠦวๅ็ืๅึ࠯๋ࠠ฻่่ࠥ฿ๆะๅࠣ์ฬ๊ศา่ส้ัࠦโศัิࠤ฾๊้ࠡษึฮำีวๆࠢส่๊๎วใ฻ࠣห้๋ิโำฬࠫᏅ"))
	if not swKeI16GoiBr7X and showDialogs: WWwh46NzuTtC9ISYmbsVrqRL()
	return swKeI16GoiBr7X
def WWwh46NzuTtC9ISYmbsVrqRL():
	HHTzVhiY079bvdluNkFQ4wCMpe(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨࠩᏆ"),wwyUWMFAsO(u"ࠩࠪᏇ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭Ꮘ"),sArCMRngQNmXkBoKv(u"ࠫอ฿ึࠡษ็้ํอโฺࠢอัฯอฬࠡำห฻๋ࠥิโำࠣ์็ี๋ࠠๅ๋๊ࠥา็ศิๆࠤ฿๐ัࠡไสำึูࠦๅ๋ࠣห้ืศุࠢสฺ่๊แาࠢฦ์ࠥํๆศๅู้้ࠣไสࠢไ๎ฺࠥ็ศัฬࠤฬ๊สีใํีࠥอไฯษุอࠥฮใ้ัํࠤ฾์ฯไࠢ฼่๊อࠠศ่๊ࠤฯ๋ࠠโฯุࠤฬ๊ศา่ส้ัูࠦๅ๋ࠣ็ํี๊ࠡษ็ษฺีวาษอࠤࡡࡴࠠ࠲࠹࠱࠺ࠥࠦࠦࠡࠢ࠴࠼࠳ࡡ࠰࠮࠻ࡠࠤࠥࠬࠠࠡ࠳࠼࠲ࡠ࠶࠭࠴࡟ࠪᏉ"))
	Cci3Yy4nZJwjWqUOpbD0r8X2()
	return
def HvcsiXhFR9Dw1(uHGMxiZfcoErOyXghvnWUK=fR68jBGWCzUsFXdlTKPOScugm(u"ࠬ࠭Ꮚ")):
	GwLHvcBPTiMSJVAQedjk549yg6CUNm = c4QSTnPiWUCjhrLlwGB(u"ࡕࡴࡸࡩᙻ")
	if pEo8g7riWVL014KaRtzQ(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩᏋ") not in uHGMxiZfcoErOyXghvnWUK:
		GwLHvcBPTiMSJVAQedjk549yg6CUNm = sArCMRngQNmXkBoKv(u"ࡈࡤࡰࡸ࡫ᙼ")
		PTQimzWJpkrt6H = A0iaw7hK4Qmc2EeHXZB(kmdSKeBIwViM9t3(u"ࠧࡤࡧࡱࡸࡪࡸࠧᏌ"),pEo8g7riWVL014KaRtzQ(u"ࠨะิ์ั࠭Ꮝ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠩศีุอไࠡ็ื็้ฯࠧᏎ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠪษึูวๅࠢิืฬ๊ษࠨᏏ"),J3OCAmZVcn(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᏐ"),XogUJZEijT7KWbxeO6(u"ࠬํไࠡฬิ๎ิࠦร็ࠢอีุ๊ࠠาีส่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ࠳࠴ࠠฤ็ࠣฮึ๐ฯࠡล้ࠤฯืำๅุ่่๊ࠢษࠡ็๋ะํีษࠡใํࠤฬ๊ศา่ส้ัࠦฟࠨᏑ"))
		if PTQimzWJpkrt6H in [-jYaM5vilgZdFx6QHbApwVXO8et(u"࠲ᘮ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"࠲ᘯ")]: return
		elif PTQimzWJpkrt6H==LmcNhzY6fQPd2JyCGslkSr(u"࠴ᘰ"):
			GwLHvcBPTiMSJVAQedjk549yg6CUNm = XogUJZEijT7KWbxeO6(u"ࡗࡶࡺ࡫ᙽ")
			uHGMxiZfcoErOyXghvnWUK = JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩᏒ")
	if GwLHvcBPTiMSJVAQedjk549yg6CUNm:
		if AAgpHN0nMZ(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࡒࡐࡉࡥࠧᏓ") not in uHGMxiZfcoErOyXghvnWUK:
			YYkEu4IL0sTa = OxCB4medn1(LmcNhzY6fQPd2JyCGslkSr(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᏔ"),LmcNhzY6fQPd2JyCGslkSr(u"ࠩࠪᏕ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪࠫᏖ"),AAgpHN0nMZ(u"ࠫํ฼ูࠡษ็ู้้ไสࠢไ๎ࠥอไิฮ็ࠫᏗ"),yTMWeCgUROcvtsblfK85L62xPk(u"่ࠬศๅࠢศีุอไࠡษ็ืัฺ๊ࠠๆํ็ࠥษๆࠡฬๆีึࠦࠠ็ใึࠤฬ๊แฺๆࠣห้ึ๊ࠡล฼฻ฬ้ࠠศๆุ่่๊ษࠡ࠰่่ࠣ๐๋ࠠฬ่ࠤฯูฬ๋ๆ๋ࠣีํࠠศๆุ่่๊ษࠡใํࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊ࠦ࠮๊ࠡหำํ์่ࠠาสࠤฬ๊สิฮํู่่ࠥโࠢอีุ๊ࠠๆๆไࠤ้อࠠโษษำฮࠦๅ็้่ࠣส์็ࠡๆสࠤ๏ำส้์ࠣ฽้๏ࠠศๆุ่่๊ษࠡษ็ฮ๏ࠦสา์าࠤฬ์สࠡษ็ษอ๊ว฻ࠢ฼๊์อࠠ࠯๊่่ࠢࠥๅหࠢหฮ่ืวาࠢสฺ่๊ใๅหࠣรࠬᏘ"))
			if YYkEu4IL0sTa!=sArCMRngQNmXkBoKv(u"࠵ᘱ"):
				HHTzVhiY079bvdluNkFQ4wCMpe(c4QSTnPiWUCjhrLlwGB(u"࠭ࠧᏙ"),FhcnOB9t3frzvXb(u"ࠧࠨᏚ"),EDPaWgMt1SwNn8o(u"ࠨฬ่ࠤสฺ๊ศรࠣห้หัิษ็ࠫᏛ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩ็่ศูแࠡสา์๋ࠦสิฮํ่ࠥอไๆึๆ่ฮࠦแ๋ࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤๆอๆࠡษ็้อืๅอࠢ็หࠥ๐ำหูํ฽ู๋ࠥาใฬࠤฬ๊ๅีๅ็อࠥ๎ไศࠢะ่์อࠠๅษ้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠬᏜ"))
				return
	HHTzVhiY079bvdluNkFQ4wCMpe(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࠫᏝ"),XogUJZEijT7KWbxeO6(u"ࠫࠬᏞ"),ZSJVq5XDrRot(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᏟ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠭แ๋ࠢสู่อิสࠢส่็อฯๆหࠣัฬ๎ไࠡล้ࠤฯ้สษࠢิืฬ๊ษࠡว็ํࠥอไๆสิ้ั่ࠦศึิัࠥ็๊่ษࠣห้๋ิไๆฬࠤศ๎ࠠศๆ่์฻๎ู๊ࠡศิฬࠦราัอࠤั๎วษ่๊ࠢࠥอไๆสิ้ัࠦแฦา้ࠤศ้สษࠢ฼๊ํอๆࠡสิ๎ิ้ࠠฤๆศ่่ะั้่ํࠤฬ๊ล๋็ํ่ࠥ๎สัๅิࠤํ๊วࠡฬ้ื๎ࠦร็ࠢส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠪᏠ"))
	search = CjyEnpfQ23o0PYwDtLId(header=ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧࡘࡴ࡬ࡸࡪࠦࡡࠡ࡯ࡨࡷࡸࡧࡧࡦࡧࠣࠤࠥอใหสࠣีุอไสࠩᏡ"),source=ll6f2wvU4FdqL3MJyDxORESCK197i)
	if not search: return
	LaX1QCyeIJ = search
	if GwLHvcBPTiMSJVAQedjk549yg6CUNm: type = PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠨࡒࡵࡳࡧࡲࡥ࡮ࠩᏢ")
	else: type = XogUJZEijT7KWbxeO6(u"ࠩࡐࡩࡸࡹࡡࡨࡧࠪᏣ")
	ybf3Qo7isaYVr = lkRNq72CIhOaXQWb(type,LaX1QCyeIJ,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࡘࡷࡻࡥᙾ"),gnfv8UtZ3daGqpjzk(u"ࠪࠫᏤ"),sArCMRngQNmXkBoKv(u"ࠫࡊࡓࡁࡊࡎ࠰ࡊࡗࡕࡍ࠮ࡗࡖࡉࡗ࡙ࠧᏥ"),uHGMxiZfcoErOyXghvnWUK)
	return
def u8dzrBUjQ2IKAhLmgTtqbky():
	uHGMxiZfcoErOyXghvnWUK = LmcNhzY6fQPd2JyCGslkSr(u"ࠬํะศࠢส่อืๆศ็ฯࠤ้อ๋๊ࠠฯำ๊ࠥ็ࠡลํࠤุ๐ัโำࠣ๎ุะึ๋ใࠣว๏ࠦๅฮฬ๋๎ฬะ࠮ࠡษ็ฬึ์วๆฮࠣ๎ุะฮะ็ࠣีํอศุ๋ࠢฮ฻๋๊็ࠢ็้าะ่๋ษอࠤ๊ืแ้฻ฬࠤ฾๊้ࠡีํีๆืวหࠢัหึา๊ส࠰ࠣห้ฮั็ษ่ะࠥเ๊า่ࠢืษ๎ไࠡ฻้ࠤศ๐ࠠๆฯอ์๏อสࠡฬ่ࠤฯำๅ๋ๆ๊หࠥ฿ไ๊ࠢึ๎ึ็ัศฬࠣ์๊๎วใ฻ࠣาฬืฬ๋ห๊ࠣࠦ๎วใ฻ࠣ฻ึ็ࠠฬษ็ฯࠧ࠴ࠠอ็ํ฽ࠥอไฤี่หฦ่ࠦศๆ่หึ้วห๋ࠢห้฻่า๋ࠢห้๋ๆี๊ิหฯࠦ็๋ࠢัหฺฯࠠษษุัฬฮ็ศ࠰ࠣห้ฮั็ษ่ะ๊ࠥวࠡ์้ฮ์้ࠠฮไ๋ๆࠥอไุส฼ࠤํอไ็ึิࠤํ่ว็๊้ࠤฬ๊รๅใํอ๊ࠥไๆๆๆ๎ฮࠦวๅำๅ้๏ฯࠠࡅࡏࡆࡅࠥหะศࠢๆห๋ࠦไะ์ๆࠤู้่๊ࠢัหฺฯࠠษษ็ีํอศุ๋ࠢห้ะึศ็ํ๊ࠥอไฯษิะ๏ฯࠠโษ็ีัอมࠡษ็ฮํอีๅ่ࠢ฽ࠥหฯศำฬࠤ์ึ็ࠡษ็ื๏ืแาษอࠤํอไๆ๊สๆ฾ࠦวๅะสีั๐ษ࠯๊ࠢิฬࠦวๅสิ๊ฬ๋ฬ้๋ࠡࠤอฮำศูฬࠤ๊ะีโฯ่๊ࠣ๎วใ฻ࠣห้๎๊ษࠩᏦ")
	FD5mbRq2ypcA6QOUE8hG(Ej67fFyoqW8kbV2HdSK(u"࠭ࡲࡪࡩ࡫ࡸࠬᏧ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧฮไ๋ๆࠥอไุส฼ࠤํอไ็ึิࠤํ่ว็๊้ࠤฬ๊รๅใํอ๊ࠥไๆๆๆ๎ฮࠦวๅำๅ้๏ฯࠧᏨ"),uHGMxiZfcoErOyXghvnWUK,J3OCAmZVcn(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫᏩ"))
	uHGMxiZfcoErOyXghvnWUK = c4QSTnPiWUCjhrLlwGB(u"ࠩࡗ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡࡦࡲࡩࡸࠦ࡮ࡰࡶࠣ࡬ࡴࡹࡴࠡࡣࡱࡽࠥࡩ࡯࡯ࡶࡨࡲࡹࠦ࡯࡯ࠢࡤࡲࡾࠦࡳࡦࡴࡹࡩࡷ࠴ࠠࡊࡶࠣࡳࡳࡲࡹࠡࡷࡶࡩࡸࠦ࡬ࡪࡰ࡮ࡷࠥࡺ࡯ࠡࡧࡰࡦࡪࡪࡤࡦࡦࠣࡧࡴࡴࡴࡦࡰࡷࠤࡹ࡮ࡡࡵࠢࡺࡥࡸࠦࡵࡱ࡮ࡲࡥࡩ࡫ࡤࠡࡶࡲࠤࡵࡵࡰࡶ࡮ࡤࡶࠥࡵ࡮࡭࡫ࡱࡩࠥࡼࡩࡥࡧࡲࠤ࡭ࡵࡳࡵ࡫ࡱ࡫ࠥࡹࡩࡵࡧࡶ࠲ࠥࡇ࡬࡭ࠢࡷࡶࡦࡪࡥ࡮ࡣࡵ࡯ࡸ࠲ࠠࡷ࡫ࡧࡩࡴࡹࠬࠡࡶࡵࡥࡩ࡫ࠠ࡯ࡣࡰࡩࡸ࠲ࠠࡴࡧࡵࡺ࡮ࡩࡥࠡ࡯ࡤࡶࡰࡹࠬࠡࡥࡲࡴࡾࡸࡩࡨࡪࡷࡩࡩࠦࡷࡰࡴ࡮࠰ࠥࡲ࡯ࡨࡱࡶࠤࡷ࡫ࡦࡦࡴࡨࡲࡨ࡫ࡤࠡࡪࡨࡶࡪ࡯࡮ࠡࡤࡨࡰࡴࡴࡧࠡࡶࡲࠤࡹ࡮ࡥࡪࡴࠣࡶࡪࡹࡰࡦࡥࡷ࡭ࡻ࡫ࠠࡰࡹࡱࡩࡷࡹࠠ࠰ࠢࡦࡳࡲࡶࡡ࡯࡫ࡨࡷ࠳ࠦࡔࡩࡧࠣࡴࡷࡵࡧࡳࡣࡰࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡷ࡫ࡳࡱࡱࡱࡷ࡮ࡨ࡬ࡦࠢࡩࡳࡷࠦࡷࡩࡣࡷࠤࡴࡺࡨࡦࡴࠣࡴࡪࡵࡰ࡭ࡧࠣࡹࡵࡲ࡯ࡢࡦࠣࡸࡴࠦ࠳ࡳࡦࠣࡴࡦࡸࡴࡺࠢࡶ࡭ࡹ࡫ࡳ࠯࡚ࠢࡩࠥࡻࡲࡨࡧࠣࡥࡱࡲࠠࡤࡱࡳࡽࡷ࡯ࡧࡩࡶࠣࡳࡼࡴࡥࡳࡵ࠯ࠤࡹࡵࠠࡳࡧࡦࡳ࡬ࡴࡩࡻࡧࠣࡸ࡭ࡧࡴࠡࡶ࡫ࡩࠥࡲࡩ࡯࡭ࡶࠤࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡪࠠࡸ࡫ࡷ࡬࡮ࡴࠠࡵࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲࠦࡡࡳࡧࠣࡰࡴࡩࡡࡵࡧࡧࠤࡸࡵ࡭ࡦࡹ࡫ࡩࡷ࡫ࠠࡦ࡮ࡶࡩࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡽࡥࡣࠢࡲࡶࠥࡼࡩࡥࡧࡲࠤࡪࡳࡢࡦࡦࡧࡩࡩࠦࡡࡳࡧࠣࡪࡷࡵ࡭ࠡࡱࡷ࡬ࡪࡸࠠࡷࡣࡵ࡭ࡴࡻࡳࠡࡵ࡬ࡸࡪࡹ࠮ࠡࡋࡩࠤࡾࡵࡵࠡࡪࡤࡺࡪࠦࡡ࡯ࡻࠣࡰࡪ࡭ࡡ࡭ࠢ࡬ࡷࡸࡻࡥࡴࠢࡳࡰࡪࡧࡳࡦࠢࡦࡳࡳࡺࡡࡤࡶࠣࡥࡵࡶࡲࡰࡲࡵ࡭ࡦࡺࡥࠡ࡯ࡨࡨ࡮ࡧࠠࡧ࡫࡯ࡩࠥࡵࡷ࡯ࡧࡵࡷࠥ࠵ࠠࡩࡱࡶࡸࡪࡸࡳ࠯ࠢࡗ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡ࡫ࡶࠤࡸ࡯࡭ࡱ࡮ࡼࠤࡦࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵ࠲ࠬᏪ")
	FD5mbRq2ypcA6QOUE8hG(gnfv8UtZ3daGqpjzk(u"ࠪࡰࡪ࡬ࡴࠨᏫ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫࡉ࡯ࡧࡪࡶࡤࡰࠥࡓࡩ࡭࡮ࡨࡲࡳ࡯ࡵ࡮ࠢࡆࡳࡵࡿࡲࡪࡩ࡫ࡸࠥࡇࡣࡵࠢࠫࡈࡒࡉࡁࠪࠩᏬ"),uHGMxiZfcoErOyXghvnWUK,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨᏭ"))
	return
def LL4Wwzr8SG170oqUiH(ZK5gkAtjrCeEXYGD2bRQHOF3Moyc):
	FaLTw4gN9ZCSkJeqObQPu870o = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executeJSONRPC(DLSVmlyBbCK(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡇࡤࡥࡱࡱࡷ࠳࡙ࡥࡵࡃࡧࡨࡴࡴࡅ࡯ࡣࡥࡰࡪࡪࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡧࡤࡥࡱࡱ࡭ࡩࠨ࠺ࠣࠩᏮ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+xuYvdJpOEyQKTLNwb(u"ࠧࠣ࠮ࠥࡩࡳࡧࡢ࡭ࡧࡧࠦ࠿࡬ࡡ࡭ࡵࡨࢁࢂ࠭Ꮿ"))
	nnF1VOMIkrqi2ojXux6UPHGyEf7Kg = bdhQDyjm3nPwToFHkprvCzBLUGR(u"࡙ࡸࡵࡦᙿ")
	if nnF1VOMIkrqi2ojXux6UPHGyEf7Kg:
		luMHeSgCBaPrb9KvUjNFqcR.sleep(fR68jBGWCzUsFXdlTKPOScugm(u"࠶ᘲ"))
		cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(gnfv8UtZ3daGqpjzk(u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬᏰ"))
		luMHeSgCBaPrb9KvUjNFqcR.sleep(bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠷ᘳ"))
	return
def AuYs2NIJVc91Lzn0jSEgG4QD():
	HHTzVhiY079bvdluNkFQ4wCMpe(J3OCAmZVcn(u"ࠩࠪᏱ"),m6b7CoBk4EQ(u"ࠪࠫᏲ"),AAgpHN0nMZ(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᏳ"),ZSJVq5XDrRot(u"ࠬอไษำ้ห๊าࠠๅษࠣ๎ๆำีࠡึ๊หิฯࠠศๆอุๆ๐ัࠡ฻้ำࠥอไศฬุห้ࠦศศๆ่์ฬู่ࠡษ็ู้็ัส๋่ࠢ์ึวࠡใํࠤาอไ๊ࠡฯ์ิࠦิ่ษาอࠥเ๊าุࠢั๏ำษࠡล๋ࠤ๊์ส่์ฬࠤฬ๊ีๅษะ๎ฮࠦร้่ࠢึ๏็ษࠡใส๊ࠥํะศࠢ็๊ࠥ๐่ใใࠣห้ืศุࠢสฺ่๊แา๋่๋๊้ࠢࠦไไࠤ฾๋ไࠡษ็ฬึ์วๆฮࠪᏴ"))
	kBimwuzGKNgqj43sOYxZycrd2QJMt()
	return
def Cci3Yy4nZJwjWqUOpbD0r8X2():
	url = DLSVmlyBbCK(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡪࡴࡵࡳࡷࡹ࠮࡬ࡱࡧ࡭࠳ࡺࡶ࠰ࡴࡨࡰࡪࡧࡳࡦࡵ࠲ࡻ࡮ࡴࡤࡰࡹࡶ࠳ࡼ࡯࡮࠷࠶࠲ࠫᏵ")
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,fR68jBGWCzUsFXdlTKPOScugm(u"ࠧࡈࡇࡗࠫ᏶"),url,FhcnOB9t3frzvXb(u"ࠨࠩ᏷"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩࠪᏸ"),aVLSn1xw5cK(u"ࠪࠫᏹ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠫࠬᏺ"),JMLhEyaBWmskovGHTrVCxQ08(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡔࡊࡒ࡛ࡤࡒࡁࡕࡇࡖࡘࡤࡑࡏࡅࡋࡢ࡚ࡊࡘࡓࡊࡑࡑ࠱࠶ࡹࡴࠨᏻ"))
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	OaREYJW4xw0mu68k = ZXFs0mEPR8qI2zj.findall(yTMWeCgUROcvtsblfK85L62xPk(u"࠭ࡴࡪࡶ࡯ࡩࡂࠨ࡫ࡰࡦ࡬࠱࠭ࡢࡤࠬ࡞࠱ࡠࡩ࠱࠭࡜ࡣ࠰ࡾࡆ࠳࡚࡞࠭ࠬ࠱ࠬᏼ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	OaREYJW4xw0mu68k = OaREYJW4xw0mu68k[JMLhEyaBWmskovGHTrVCxQ08(u"࠰ᘴ")].split(xuYvdJpOEyQKTLNwb(u"ࠧ࠮ࠩᏽ"))[JMLhEyaBWmskovGHTrVCxQ08(u"࠰ᘴ")]
	Nrh5umo0xW3lL1jstJMV9 = str(V8US2yZAg0QXJebWIHKD5xFa)
	kAotrbLajs5J2m8 = Ej67fFyoqW8kbV2HdSK(u"ࠨ࡝ࡕࡘࡑࡣลึัสี้่ࠥะ์ࠣห้ษฮ๋ำࠣห้๋ส้ใิࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠢࠪ᏾")+wwyUWMFAsO(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ᏿")+OaREYJW4xw0mu68k+PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᐀")
	kAotrbLajs5J2m8 += J3OCAmZVcn(u"ࠫࡡࡴ࡜࡯ࠩᐁ")+PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬࡡࡒࡕࡎࡠษฺีวาࠢๆ์ิ๐ࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆ้๋ࠣํࠦ࠺ࠡࠢࠣࠫᐂ")+fR68jBGWCzUsFXdlTKPOScugm(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩᐃ")+Nrh5umo0xW3lL1jstJMV9+EDPaWgMt1SwNn8o(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᐄ")
	HHTzVhiY079bvdluNkFQ4wCMpe(yTMWeCgUROcvtsblfK85L62xPk(u"ࠨࠩᐅ"),wwyUWMFAsO(u"ࠩࠪᐆ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᐇ"),kAotrbLajs5J2m8)
	return
def RRftkXcUVLEsGYw7T8Me9jHDnxi0():
	uu5SDqLcCs7IUA,zzPuKeTq6I4gHrRA3aUDmEpVyl,zb9ro4X6jnBHhxpg,kAotrbLajs5J2m8,MZxUmIt5qszvg2DOBHbnTE109,ww5nga0cxLZ6HYdGu,RRITe3bLJkvUhsX4QFWVaf7p = JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࠬᐈ"),fR68jBGWCzUsFXdlTKPOScugm(u"ࠬ࠭ᐉ"),XogUJZEijT7KWbxeO6(u"࠭ࠧᐊ"),kmdSKeBIwViM9t3(u"ࠧࠨᐋ"),EDPaWgMt1SwNn8o(u"ࠨࠩᐌ"),DLSVmlyBbCK(u"ࠩࠪᐍ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠪࠫᐎ")
	VbZ1Pig043uIGYQ,UVQuIpZP89,RHXPL6JqBeCrA7gvEuYion8d9,qWbe8rENv0fjSi75pPyVYCgRGax = {gSmqZU0plur2xKPJwQA(u"ࠫࡦ࠭ᐏ"):LmcNhzY6fQPd2JyCGslkSr(u"ࠬࡧࠧᐐ")},{},[],{}
	url = uReHcEzxkTm6pN4Q[LmcNhzY6fQPd2JyCGslkSr(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ᐑ")][kRYWcNuAazr4jtmBoxFVS19Z6(u"࠲ᘵ")]
	wpFmEA3z8JR = A6F71g3cqN4(RwhaLmQ4cpyvfxsPUJVA0DtM,gSmqZU0plur2xKPJwQA(u"ࠧࡑࡑࡖࡘࠬᐒ"),url,VbZ1Pig043uIGYQ,eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨࠩᐓ"),gSmqZU0plur2xKPJwQA(u"ࠩࠪᐔ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠪࠫᐕ"),aVLSn1xw5cK(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡕࡔࡃࡊࡉࡤࡘࡅࡑࡑࡕࡘ࠲࠷ࡳࡵࠩᐖ"))
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	QstumvzTIEUMXCcx06aD4y8nSqH = QstumvzTIEUMXCcx06aD4y8nSqH.replace(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࡛ࠬ࡮ࡪࡶࡨࡨ࡙ࠥࡴࡢࡶࡨࡷࠬᐗ"),gSmqZU0plur2xKPJwQA(u"࠭ࡕࡔࡃࠪᐘ"))
	QstumvzTIEUMXCcx06aD4y8nSqH = QstumvzTIEUMXCcx06aD4y8nSqH.replace(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠧࡖࡰ࡬ࡸࡪࡪࠠࡌ࡫ࡱ࡫ࡩࡵ࡭ࠨᐙ"),kmdSKeBIwViM9t3(u"ࠨࡗࡎࠫᐚ"))
	QstumvzTIEUMXCcx06aD4y8nSqH = QstumvzTIEUMXCcx06aD4y8nSqH.replace(ZSJVq5XDrRot(u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡄࡶࡦࡨࠠࡆ࡯࡬ࡶࡦࡺࡥࡴࠩᐛ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࡙ࠪࡆࡋࠧᐜ"))
	QstumvzTIEUMXCcx06aD4y8nSqH = QstumvzTIEUMXCcx06aD4y8nSqH.replace(sArCMRngQNmXkBoKv(u"ࠫࡘࡧࡵࡥ࡫ࠣࡅࡷࡧࡢࡪࡣࠪᐝ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠬࡑࡓࡂࠩᐞ"))
	QstumvzTIEUMXCcx06aD4y8nSqH = QstumvzTIEUMXCcx06aD4y8nSqH.replace(gSmqZU0plur2xKPJwQA(u"࠭ࡎࡰࡴࡷ࡬ࠥࡓࡡࡤࡧࡧࡳࡳ࡯ࡡࠨᐟ"),pEo8g7riWVL014KaRtzQ(u"ࠧࡏ࠰ࡐࡥࡨ࡫ࡤࡰࡰ࡬ࡥࠬᐠ"))
	QstumvzTIEUMXCcx06aD4y8nSqH = QstumvzTIEUMXCcx06aD4y8nSqH.replace(ZSJVq5XDrRot(u"ࠨ࡙ࡨࡷࡹ࡫ࡲ࡯ࠢࡖࡥ࡭ࡧࡲࡢࠩᐡ"),jYaM5vilgZdFx6QHbApwVXO8et(u"࡚ࠩ࠲ࡘࡧࡨࡢࡴࡤࠫᐢ"))
	QstumvzTIEUMXCcx06aD4y8nSqH = QstumvzTIEUMXCcx06aD4y8nSqH.replace(xuYvdJpOEyQKTLNwb(u"ࠪࡣࡤࡥࠧᐣ"),fR68jBGWCzUsFXdlTKPOScugm(u"ࠫࠥࠦࠧᐤ"))
	try: WWtEu9K5cBjIzaPghCq3kefJl7ObR = NL0JIkbrEWqTYj61vVKGCnBw37MsOF(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬࡲࡩࡴࡶࠪᐥ"),QstumvzTIEUMXCcx06aD4y8nSqH)
	except:
		HHTzVhiY079bvdluNkFQ4wCMpe(EDPaWgMt1SwNn8o(u"࠭ࠧᐦ"),kmdSKeBIwViM9t3(u"ࠧࠨᐧ"),aVLSn1xw5cK(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᐨ"),xuYvdJpOEyQKTLNwb(u"ࠩไุ้ࠦแ๋ࠢฯ่อࠦๅฮฬ๋๎ฬะࠠหไิ๎ึࠦวๅษึฮำีวๆࠩᐩ"))
		return
	IUoKbxFC5W,ZFWc9G7kpMAEiQrRSs5j,Ma8UAqYR5jlsBv0iCnX = WWtEu9K5cBjIzaPghCq3kefJl7ObR
	qWbe8rENv0fjSi75pPyVYCgRGax = {}
	LVlIF7WuxgryK4waqbCRMZzv38JEiT = [kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪࡇࡆࡖࡔࡄࡊࡄࡍࡉ࠭ᐪ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠫࡈࡇࡐࡕࡅࡋࡅ࡙ࡕࡋࡆࡐࠪᐫ")]
	RQuGdHxklbj2vn4p8MczSBU0 = [OVmSuf8tpd(u"ࠬࡇࡌࡍࠩᐬ"),fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ᐭ"),pEo8g7riWVL014KaRtzQ(u"ࠧࡊࡐࡖࡘࡆࡒࡌࠨᐮ"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠨࡏࡈࡘࡗࡕࡐࡐࡎࡌࡗࠬᐯ"),DLSVmlyBbCK(u"ࠩࡕࡉࡕࡕࡓࠨᐰ")]+LVlIF7WuxgryK4waqbCRMZzv38JEiT+Hhl2G8LRwq7+dRv1o5GDY4QV
	for ji1dGuYnsFNKe,J50BAvCeDaMj43PRqFKVcLQ,fryG7VCW8pdRUQYAmj in ZFWc9G7kpMAEiQrRSs5j:
		fryG7VCW8pdRUQYAmj = WhJe7bGx5XackTwOIZVLC8ut(fryG7VCW8pdRUQYAmj)
		fryG7VCW8pdRUQYAmj = fryG7VCW8pdRUQYAmj.strip(AAgpHN0nMZ(u"ࠪࠤࠬᐱ")).strip(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫࠥ࠴ࠧᐲ"))
		kAotrbLajs5J2m8 += ZSJVq5XDrRot(u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪᐳ")+ji1dGuYnsFNKe+ZSJVq5XDrRot(u"࠭࠺ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᐴ")+fryG7VCW8pdRUQYAmj+kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠧ࡝ࡰࠪᐵ")
		if J50BAvCeDaMj43PRqFKVcLQ.isdigit():
			qWbe8rENv0fjSi75pPyVYCgRGax[ji1dGuYnsFNKe] = int(J50BAvCeDaMj43PRqFKVcLQ)
			if int(J50BAvCeDaMj43PRqFKVcLQ)>PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠳࠳࠴ᘶ"): J50BAvCeDaMj43PRqFKVcLQ = ZSJVq5XDrRot(u"ࠨࡪ࡬࡫࡭ࡻࡳࡢࡩࡨࠫᐶ")
			else: J50BAvCeDaMj43PRqFKVcLQ = c4QSTnPiWUCjhrLlwGB(u"ࠩ࡯ࡳࡼࡻࡳࡢࡩࡨࠫᐷ")
		if ji1dGuYnsFNKe not in RQuGdHxklbj2vn4p8MczSBU0:
			if   J50BAvCeDaMj43PRqFKVcLQ==JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠪ࡬࡮࡭ࡨࡶࡵࡤ࡫ࡪ࠭ᐸ"): uu5SDqLcCs7IUA += FhcnOB9t3frzvXb(u"ࠫࠥࠦࠧᐹ")+ji1dGuYnsFNKe
			elif J50BAvCeDaMj43PRqFKVcLQ==OVmSuf8tpd(u"ࠬࡲ࡯ࡸࡷࡶࡥ࡬࡫ࠧᐺ"): zzPuKeTq6I4gHrRA3aUDmEpVyl += gSmqZU0plur2xKPJwQA(u"࠭ࠠࠡࠩᐻ")+ji1dGuYnsFNKe
	BB6cZ2J4SqA,e9hKVzkY8NEpyAXrgWx46v,sQJmUkhnXDYrPZ6C = list(zip(*ZFWc9G7kpMAEiQrRSs5j))
	for ji1dGuYnsFNKe in sorted(ujqHb6gv3ZcKmJazCy2):
		if ji1dGuYnsFNKe not in BB6cZ2J4SqA:
			kAotrbLajs5J2m8 += xuYvdJpOEyQKTLNwb(u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬᐼ")+ji1dGuYnsFNKe+LmcNhzY6fQPd2JyCGslkSr(u"ࠨ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᐽ")+PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩ็หࠥ๐่อัࠪᐾ")+kmdSKeBIwViM9t3(u"ࠪࡠࡳࡢ࡮ࠨᐿ")
			if ji1dGuYnsFNKe not in RQuGdHxklbj2vn4p8MczSBU0: zb9ro4X6jnBHhxpg += gnfv8UtZ3daGqpjzk(u"ࠫࠥࠦࠧᑀ")+ji1dGuYnsFNKe
	for fryG7VCW8pdRUQYAmj,qq3nmoTeXK2t8j4PFZ in IUoKbxFC5W:
		fryG7VCW8pdRUQYAmj = WhJe7bGx5XackTwOIZVLC8ut(fryG7VCW8pdRUQYAmj)
		MZxUmIt5qszvg2DOBHbnTE109 += fryG7VCW8pdRUQYAmj+kmdSKeBIwViM9t3(u"ࠬࡀࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪᑁ")+str(qq3nmoTeXK2t8j4PFZ)+aVLSn1xw5cK(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡࠢࠣࠫᑂ")
	uu5SDqLcCs7IUA = uu5SDqLcCs7IUA.strip(wwyUWMFAsO(u"ࠧࠡࠩᑃ"))
	zzPuKeTq6I4gHrRA3aUDmEpVyl = zzPuKeTq6I4gHrRA3aUDmEpVyl.strip(ZSJVq5XDrRot(u"ࠨࠢࠪᑄ"))
	zb9ro4X6jnBHhxpg = zb9ro4X6jnBHhxpg.strip(XogUJZEijT7KWbxeO6(u"ࠩࠣࠫᑅ"))
	jjYB4Por9lqnzivIZeACEuDfxgd = uu5SDqLcCs7IUA+pEo8g7riWVL014KaRtzQ(u"ࠪࠤࠥ࠭ᑆ")+zzPuKeTq6I4gHrRA3aUDmEpVyl
	CMqHoE0FLzApUQIY5tPZewb  = AAgpHN0nMZ(u"๊ࠫ๎วใ฻๊ࠣัำࠠศๆหี๋อๅอࠢหฮูเ๊ๅࠢไ๎ิ๐่่ษอࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠨᑇ")+OVmSuf8tpd(u"ࠬࡢ࡮ࠨᑈ")+xuYvdJpOEyQKTLNwb(u"่่࠭าสࠤ๊฿ๆศ้ࠣษีอࠠๅัํ็๋ࠥิไๆฬࠤๆํ๊ࠡๆํืฯࠦๅ็ࠢส่อืๆศ็ฯࠫᑉ")+kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠧ࡝ࡰࠪᑊ")
	CMqHoE0FLzApUQIY5tPZewb += gSmqZU0plur2xKPJwQA(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫᑋ")+jjYB4Por9lqnzivIZeACEuDfxgd+PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳࡢ࡮ࠨᑌ")
	CMqHoE0FLzApUQIY5tPZewb += sArCMRngQNmXkBoKv(u"้ࠪํอโฺࠢ็้ࠥ๐ิ฻ๆࠣห้ฮั็ษ่ะ๋ࠥๆ่ษࠣๅ๏ี๊้้สฮࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠩᑍ")+xuYvdJpOEyQKTLNwb(u"ࠫࡡࡴࠧᑎ")+sArCMRngQNmXkBoKv(u"ࠬ๎็ัษ้ࠣ฾์ว่ࠢสัฯ๋วๅࠢๆฬ๏ื้ࠠฮ๋ำ๋ࠥิไๆฬࠤๆ๐ࠠศๆหี๋อๅอࠩᑏ")+bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭࡜࡯ࠩᑐ")
	CMqHoE0FLzApUQIY5tPZewb += FhcnOB9t3frzvXb(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪᑑ")+zb9ro4X6jnBHhxpg+gnfv8UtZ3daGqpjzk(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᑒ")
	LLac9KMPFp,XyL76s9HcVWza0Ql3SKp5TAIgOFRPM,xSN3l25qWT80trAaGoCwQmhK,lAZk7MojVPsB4tY = ZSJVq5XDrRot(u"࠳ᘷ"),ZSJVq5XDrRot(u"࠳ᘷ"),ZSJVq5XDrRot(u"࠳ᘷ"),ZSJVq5XDrRot(u"࠳ᘷ")
	all = qWbe8rENv0fjSi75pPyVYCgRGax[wwyUWMFAsO(u"ࠩࡄࡐࡑ࠭ᑓ")]
	if JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪᑔ") in list(qWbe8rENv0fjSi75pPyVYCgRGax.keys()): LLac9KMPFp = qWbe8rENv0fjSi75pPyVYCgRGax[pEo8g7riWVL014KaRtzQ(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫᑕ")]
	if AAgpHN0nMZ(u"ࠬࡏࡎࡔࡖࡄࡐࡑ࠭ᑖ") in list(qWbe8rENv0fjSi75pPyVYCgRGax.keys()): XyL76s9HcVWza0Ql3SKp5TAIgOFRPM = qWbe8rENv0fjSi75pPyVYCgRGax[JMLhEyaBWmskovGHTrVCxQ08(u"࠭ࡉࡏࡕࡗࡅࡑࡒࠧᑗ")]
	if MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧࡎࡇࡗࡖࡔࡖࡏࡍࡋࡖࠫᑘ") in list(qWbe8rENv0fjSi75pPyVYCgRGax.keys()): xSN3l25qWT80trAaGoCwQmhK = qWbe8rENv0fjSi75pPyVYCgRGax[kmdSKeBIwViM9t3(u"ࠨࡏࡈࡘࡗࡕࡐࡐࡎࡌࡗࠬᑙ")]
	if JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠩࡕࡉࡕࡕࡓࠨᑚ") in list(qWbe8rENv0fjSi75pPyVYCgRGax.keys()): lAZk7MojVPsB4tY = qWbe8rENv0fjSi75pPyVYCgRGax[OVmSuf8tpd(u"ࠪࡖࡊࡖࡏࡔࠩᑛ")]
	Z5BAClmzjiF928XH0EM = all-LLac9KMPFp-XyL76s9HcVWza0Ql3SKp5TAIgOFRPM-xSN3l25qWT80trAaGoCwQmhK-lAZk7MojVPsB4tY
	vfLGDU1N0e8c,TASCJrf2OtNmVdgnlD1c = Ma8UAqYR5jlsBv0iCnX[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠴ᘸ")]
	vfLGDU1N0e8c,BRwMOecrQUdti = Ma8UAqYR5jlsBv0iCnX[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠶ᘹ")]
	q9ZUtnWOSc = TASCJrf2OtNmVdgnlD1c-BRwMOecrQUdti
	RRITe3bLJkvUhsX4QFWVaf7p += aVLSn1xw5cK(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧᑜ")+str(BRwMOecrQUdti)+pEo8g7riWVL014KaRtzQ(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᑝ")+J3OCAmZVcn(u"࠭วๅ฻าำࠥอไฮไํๆ๏ࠦไๅลฯ๋ืฯࠠ࠻ࠢࠪᑞ")
	RRITe3bLJkvUhsX4QFWVaf7p += kmdSKeBIwViM9t3(u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬᑟ")+str(q9ZUtnWOSc)+J3OCAmZVcn(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᑠ")+xuYvdJpOEyQKTLNwb(u"ࠩหหุะฮะษ่ࠤࡵࡸ࡯ࡹࡻࠣวํࠦࡶࡱࡰࠣ࠾ࠥ࠭ᑡ")
	RRITe3bLJkvUhsX4QFWVaf7p += aVLSn1xw5cK(u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨᑢ")+str(TASCJrf2OtNmVdgnlD1c)+gnfv8UtZ3daGqpjzk(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᑣ")+JMLhEyaBWmskovGHTrVCxQ08(u"ࠬอไฺัาࠤฬ๊ใๅ์่ࠣัฺ๋๊ࠢส่ศา็ำหࠣ࠾ࠥ࠭ᑤ")
	RRITe3bLJkvUhsX4QFWVaf7p += xuYvdJpOEyQKTLNwb(u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫᑥ")+str(len(Ma8UAqYR5jlsBv0iCnX[AAgpHN0nMZ(u"࠸ᘺ"):]))+ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᑦ")+aVLSn1xw5cK(u"ࠨ฻าำࠥอไะ๊็ࠤฬ๊ส๋ࠢไ๎์อࠠฤฮ๊ึฮࠦ࠺ࠡ࡞ࡱࡠࡳ࠭ᑧ")
	for SvVD2AkXlf17EFnY,hhC9JITqv3yWEGFm in Ma8UAqYR5jlsBv0iCnX[AAgpHN0nMZ(u"࠲ᘻ"):]:
		SvVD2AkXlf17EFnY = WhJe7bGx5XackTwOIZVLC8ut(SvVD2AkXlf17EFnY)
		SvVD2AkXlf17EFnY = SvVD2AkXlf17EFnY.strip(kmdSKeBIwViM9t3(u"ࠩࠣࠫᑨ")).strip(AAgpHN0nMZ(u"ࠪࠤ࠳࠭ᑩ"))
		RRITe3bLJkvUhsX4QFWVaf7p += SvVD2AkXlf17EFnY+ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠫ࠿࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩᑪ")+str(hhC9JITqv3yWEGFm)+OVmSuf8tpd(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠࠡࠢࠪᑫ")
	ww5nga0cxLZ6HYdGu += FhcnOB9t3frzvXb(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩᑬ")+str(Z5BAClmzjiF928XH0EM)+kmdSKeBIwViM9t3(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᑭ")+OVmSuf8tpd(u"ࠨใํำ๏๎็ศฬࠣหูะฺๅฬࠣ࠾ࠥ࠭ᑮ")
	ww5nga0cxLZ6HYdGu += sArCMRngQNmXkBoKv(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧᑯ")+str(LLac9KMPFp)+gnfv8UtZ3daGqpjzk(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᑰ")+kmdSKeBIwViM9t3(u"ࠫ฼๊ศศฬࠣื๏ืแาࠢหห๏ั่็ࠢ࠽ࠤࠬᑱ")
	ww5nga0cxLZ6HYdGu += wwyUWMFAsO(u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪᑲ")+str(lAZk7MojVPsB4tY)+eeIL1TfgFQJaKqVD8hGNPEZ(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨᑳ")+kRYWcNuAazr4jtmBoxFVS19Z6(u"ุࠧๆหหฯࠦำ๋ำไีࠥอไๆีอ์ิ฿ࠠ࠻ࠢࠪᑴ")
	ww5nga0cxLZ6HYdGu += J3OCAmZVcn(u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ᑵ")+str(XyL76s9HcVWza0Ql3SKp5TAIgOFRPM)+Ej67fFyoqW8kbV2HdSK(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᑶ")+gnfv8UtZ3daGqpjzk(u"ࠪฮะฮ๊หࠢอ฻อ๐โࠡๅ๋ำ๏ูࠦๆษาࠤ࠿ࠦࠧᑷ")
	ww5nga0cxLZ6HYdGu += JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩᑸ")+str(xSN3l25qWT80trAaGoCwQmhK)+kmdSKeBIwViM9t3(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᑹ")+hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭สฬสํฮࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠽ࠤࠬᑺ")
	ww5nga0cxLZ6HYdGu += J3OCAmZVcn(u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬᑻ")+str(len(IUoKbxFC5W))+gnfv8UtZ3daGqpjzk(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᑼ")+kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩา์้ࠦิ฻ๆอࠤๆ๐ฯ๋๊๊หฯࠦ࠺ࠡࠩᑽ")
	ww5nga0cxLZ6HYdGu += yTMWeCgUROcvtsblfK85L62xPk(u"ࠪࡠࡳࡢ࡮ࠨᑾ")+MZxUmIt5qszvg2DOBHbnTE109
	FD5mbRq2ypcA6QOUE8hG(pEo8g7riWVL014KaRtzQ(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᑿ"),FhcnOB9t3frzvXb(u"ࠬ฿ฯะࠢส่ศา็ำหࠣห้ะ๊ࠡษึฮำีๅห๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠥ็๊ࠡษ็฽ฬ๊ๅࠡๅ็๋ࠬᒀ"),RRITe3bLJkvUhsX4QFWVaf7p,fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩᒁ"))
	FD5mbRq2ypcA6QOUE8hG(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧࡤࡧࡱࡸࡪࡸࠧᒂ"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠨ฻าำࠥอไโ์า๎ํํวหࠢส่ฯ๐ࠠี฼็๋ฬࠦ็ัษࠣห้ฮั็ษ่ะࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠢไ๎ࠥอไฺษ็้้ࠥไ่ࠩᒃ"),ww5nga0cxLZ6HYdGu,aVLSn1xw5cK(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬᒄ"))
	FD5mbRq2ypcA6QOUE8hG(XogUJZEijT7KWbxeO6(u"ࠪࡧࡪࡴࡴࡦࡴࠪᒅ"),jYaM5vilgZdFx6QHbApwVXO8et(u"๊ࠫ๎วใ฻ࠣหูะฺๅฬࠣๅ๏ࠦ࠳ࠡลํห๊ࠦวๅ็สฺ๏ฯࠠโ์ࠣห้฿วๅ็ࠣ็้ํࠧᒆ"),CMqHoE0FLzApUQIY5tPZewb,aVLSn1xw5cK(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨᒇ"))
	FD5mbRq2ypcA6QOUE8hG(wwyUWMFAsO(u"࠭࡬ࡦࡨࡷࠫᒈ"),AAgpHN0nMZ(u"ࠧฤ฻็ํࠥอไะ๊็ࠤฬ๊ส๋ࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮࠦวิฬัำ๊ะࠠศๆหี๋อๅอࠩᒉ"),kAotrbLajs5J2m8,xuYvdJpOEyQKTLNwb(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩᒊ"))
	return
def gdqkVFbKYvBmt0AQ46nlPi():
	LaX1QCyeIJ = yTMWeCgUROcvtsblfK85L62xPk(u"๊ࠩิฬࠦวๅสิ๊ฬ๋ฬࠡ์฼้้ࠦวโุ็ࠤออำหะาห๊ࠦฬๅัࠣ็ํี๊ࠡࠪࡎࡳࡩ࡯ࠠࡔ࡭࡬ࡲ࠮ࠦวๅาํࠤฬูๅ่࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯࡞ࡱࠤํ๋ๅไ่ࠣฮะฮ๊ห้ࠣฬฬูสฯัส้๋ࠥำห๊า฽ࠥ฿ๅศัࠣࡉࡒࡇࡄࠡࡔࡨࡴࡴࡹࡩࡵࡱࡵࡽࠥษ่ࠡฬะ้๏๊็ࠡ็้ࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡸ࡯࠳ࡺ࡯࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࡠࡳࡢ࡮้ࠡำ๋ࠥอไาีส่ฮ่ࠦ฻์ิ๋ฬࠦใฬ์ิࠤ๊๎ฬ้ัฬࠤๆ๐ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊า้ࠠษ็้ื๐ฯࠡลํฺฬࠦๅ้ฮ๋ำࠥ็๊ࠡไสส๊ฯࠠฤฮ๋ฬฮࠦวๅสิ๊ฬ๋ฬࠨᒋ")
	FD5mbRq2ypcA6QOUE8hG(gSmqZU0plur2xKPJwQA(u"ࠪࡧࡪࡴࡴࡦࡴࠪᒌ"),LmcNhzY6fQPd2JyCGslkSr(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᒍ"),LaX1QCyeIJ,gSmqZU0plur2xKPJwQA(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨᒎ"))
	return
def hEuK6GmSYZURWgdLwy25b():
	LaX1QCyeIJ = jYaM5vilgZdFx6QHbApwVXO8et(u"࠭วๅำสฬ฼๐ๆࠡลา๊ฬํࠠโ์๊้ฬࠦสุสํๆ้่ࠥะ์ࠣ฽๊อฯ๊๊ࠡ์ࠥ฿ศศำฬࠤ฾์ࠠหอห๎ฯࠦใศ็็ࠤฬ๎ส้็สฮ๏้๊ࠡๆหี๋อๅอࠢๆ์ิ๐้ࠠ็฼๋ࠥอึศใฬࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯ้ࠠ็฼๋ࠥอึศใฬࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯ๊่ࠡ฽์ࠦวืษไอ๋ࠥำห๊า฽ࠥ฿ๅศัࠣ์ๆ๐็ࠡลํฺฬࠦฬๆ์฼ࠤฬ฿ฯศัอࠤ่๎ฯ๋ࠢส่๊฽ไ้สฬࠤ้฿ๅๅࠢหี๋อๅอࠢ฼้ฬี้ࠠๅ็๋ฬࠦสห็ࠣหํะ่ๆษอ๎่๐ว๊ࠡ็หࠥะอหษฯࠤศ๐ࠠ็๊฼ࠤ๊์ࠠศๆัฬึฯࠠโ์ࠣ็ํี๊ࠡล๋ࠤฬ๊ฮษำฬࠤๆ๐ࠠหอห๎ฯࠦรืษไหฯࠦใ้ัํࠫᒏ")+FhcnOB9t3frzvXb(u"ࠧ࡝ࡰࠪᒐ")+kmdSKeBIwViM9t3(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫᒑ")+uReHcEzxkTm6pN4Q[eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠩࡎࡓࡉࡏࡅࡎࡃࡇࡣࡆࡖࡐࠨᒒ")][kRYWcNuAazr4jtmBoxFVS19Z6(u"࠲ᘽ")]+yTMWeCgUROcvtsblfK85L62xPk(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࠦࠠࠡࠢࠣวํࠦࠠࠡࠢࠣࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧᒓ")+uReHcEzxkTm6pN4Q[ZSJVq5XDrRot(u"ࠫࡐࡕࡄࡊࡇࡐࡅࡉࡥࡁࡑࡒࠪᒔ")][pEo8g7riWVL014KaRtzQ(u"࠲ᘼ")]+yTMWeCgUROcvtsblfK85L62xPk(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᒕ")
	LaX1QCyeIJ += LmcNhzY6fQPd2JyCGslkSr(u"࠭࡜࡯࡞ࡱࡠࡳอไาษห฻ࠥษฯ็ษ๊ࠤ์๎ࠠศๆึ์ึูࠠศๆำ๎ࠥ๐อหษฯ๋๋ࠥฯ๋ำ้้ࠣ็วหࠢๆ์ิ๐ࠠๅฬฮฬ๏ะࠠษำ้ห๊าฺࠠ็สำࠥฮวๅูิ๎็ฯࠠศๆอๆ้๐ฯ๋หࠣห้่ฯ๋็ฬࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨᒖ")+uReHcEzxkTm6pN4Q[gnfv8UtZ3daGqpjzk(u"ࠧࡔࡑࡘࡖࡈࡋࡓࠨᒗ")][c4QSTnPiWUCjhrLlwGB(u"࠴ᘾ")]+kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᒘ")
	LaX1QCyeIJ += EDPaWgMt1SwNn8o(u"ࠩ࡟ࡲࡡࡴ࡜࡯ฮ่๎฾ࠦๅๅใสฮࠥ฿ๅศั้ࠣํา่ะหࠣๅ๏ࠦวๅ็๋ๆ฾ࠦระ่ส๋ࠬᒙ")+kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪࡠࡳ࠭ᒚ")+jYaM5vilgZdFx6QHbApwVXO8et(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧᒛ")+uReHcEzxkTm6pN4Q[aVLSn1xw5cK(u"࡙ࠬࡏࡖࡔࡆࡉࡘ࠭ᒜ")][eeIL1TfgFQJaKqVD8hGNPEZ(u"࠶ᘿ")]+m6b7CoBk4EQ(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨᒝ")
	FD5mbRq2ypcA6QOUE8hG(c4QSTnPiWUCjhrLlwGB(u"ࠧࡤࡧࡱࡸࡪࡸࠧᒞ"),FhcnOB9t3frzvXb(u"ࠨษ็้ํอโฺࠢส่ึูๅ๋ห่ࠣอืๆศ็ฯࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯࠧᒟ"),LaX1QCyeIJ,kmdSKeBIwViM9t3(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬᒠ"))
	return
def VgJQ6yCE4DYq1AOfGjoc(qWISL7n6vtKdFERDug3Hol8):
	cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(XogUJZEijT7KWbxeO6(u"ࠪࡅࡩࡪ࡯࡯࠰ࡒࡴࡪࡴࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠩࠩᒡ")+qWISL7n6vtKdFERDug3Hol8+eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫ࠮࠭ᒢ"), kmdSKeBIwViM9t3(u"࡚ࡲࡶࡧ "))
	return
def KQJyISNdlh():
	jJSBRtqke9EU6waxvz7PDrg8ATnWm1(Ej67fFyoqW8kbV2HdSK(u"ࠬࡹࡴࡰࡲࠪᒣ"))
	cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(JMLhEyaBWmskovGHTrVCxQ08(u"ࠨࡁࡤࡶ࡬ࡺࡦࡺࡥࡘ࡫ࡱࡨࡴࡽࠨࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࡖࡩࡹࡺࡩ࡯ࡩࡶ࠭ࠧᒤ"))
	return
def YdDSuEmMlZLwB39pOX():
	cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࡂࡦࡧࡳࡳ࠴ࡏࡱࡧࡱࡗࡪࡺࡴࡪࡰࡪࡷ࠭࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩ࠮࠭ᒥ"), ZSJVq5XDrRot(u"ࡔࡳࡷࡨᚁ"))
	return
def tKcmZ2YEF06ysejqd59Nv(showDialogs):
	if not showDialogs: YYkEu4IL0sTa = c4QSTnPiWUCjhrLlwGB(u"ࡕࡴࡸࡩᚂ")
	else: YYkEu4IL0sTa = OxCB4medn1(gSmqZU0plur2xKPJwQA(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᒦ"),fR68jBGWCzUsFXdlTKPOScugm(u"ࠩࠪᒧ"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠪࠫᒨ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᒩ"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠬฮั็ษ่ะ้่ࠥะ์ࠣ๎็๎ๅࠡส฼้้๐ษࠡฬะำ๏ัࠠอ็ํ฽ࠥอไฦุสๅฬะࠠหๆๅหห๐วࠡๅ็ࠤ࠷࠺ࠠิษ฼อࠥ๎ไไ่้๊้ࠣๆࠡวฯีฬว็ศࠢส่ว์ࠠ࠯๊่ࠢࠥะั๋ัࠣฮาี๊ฬࠢฯ้๏฿ࠠฦุสๅฬะࠠไ๊า๎ࠥอไร่ࠣรࠬᒪ"))
	if YYkEu4IL0sTa==wwyUWMFAsO(u"࠶ᙀ"):
		cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(yTMWeCgUROcvtsblfK85L62xPk(u"࠭ࡕࡱࡦࡤࡸࡪࡇࡤࡥࡱࡱࡖࡪࡶ࡯ࡴࠩᒫ"))
		if showDialogs: HHTzVhiY079bvdluNkFQ4wCMpe(kmdSKeBIwViM9t3(u"ࠧࠨᒬ"),OVmSuf8tpd(u"ࠨࠩᒭ"),pEo8g7riWVL014KaRtzQ(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᒮ"),m6b7CoBk4EQ(u"ࠪฮ๊ࠦลาีส่ࠥ฽ไษࠢศ่๎ࠦศา่ส้ัࠦใ้ัํࠤฬ๊ะ๋ࠢไ๎ࠥา็ศิๆࠤ้้๊ࠡ์ๅ์๊ࠦศหฯา๎ะࠦฬๆ์฼ࠤส฼วโษอࠤ่๎ฯ๋ࠢ࠱ࠤอ๋วࠡใํ๋ฬࠦสฮัํฯࠥํะศࠢส่อืๆศ็ฯࠤํะอะ์ฮࠤู๊ส้ั฼ࠤ฾๋วะࠢ࠱ࠤ๏ืฬ๊ࠢศ฽฼อมࠡๅ๋ำ๏ࠦ࠵ࠡัๅหห่ࠠฤ๊ࠣว่ััࠡๆๆ๎ࠥ๐ๆ่์ࠣ฽๊๊๊สࠢส่ฯำฯ๋อࠪᒯ"))
		cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(EDPaWgMt1SwNn8o(u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨᒰ"))
	return
def ndQs8Nkp9eMTiLBhFwPGJqHx7():
	HHTzVhiY079bvdluNkFQ4wCMpe(m6b7CoBk4EQ(u"ࠬ࠭ᒱ"),EDPaWgMt1SwNn8o(u"࠭ࠧᒲ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᒳ"),XogUJZEijT7KWbxeO6(u"ࠨๆ่ืาࠦๅฮฬ๋๎ฬะࠠใษษ้ฮࠦ࠮ࠡษำ๋อࠦลๅ๋ࠣห้่วว็ฬࠤฬ๊ส๋ࠢอี๏ีࠠๆีะ๋ฬ่ࠦๅษࠣฮิิไࠡว็๎์อ้ࠠๆๆ๊ࠥฮวิฬัำฬ๋ࠠࠣษ็้ฬ๎ำࠣࠢฦ์ࠥࠨวๅำํ้ํะࠢࠡษู฾฼ูࠦๅ๋ࠣหุ้ัࠡฮ๊อࠥอไ๋็ํ๊ࠥษ่ࠡษึฮำีๅࠡࠤส่่๐ศ้ำาࠦࠥ๎วื฼ฺࠤ฾๊้ࠡฯิๅࠥࠨࡃࠣࠢฦ์ࠥ฿ไ๊ࠢสฺ฿฽ฺࠠๆ์ࠤืืࠠࠣษ็ๆฬฬๅสࠤࠣห้ึ๊ࠡใํࠤัํษࠡษ็๎๊๐ๆࠨᒴ"))
	return
def yej2XGh1UZq4uA3E65L87JNrC():
	HHTzVhiY079bvdluNkFQ4wCMpe(m6b7CoBk4EQ(u"ࠩࠪᒵ"),pEo8g7riWVL014KaRtzQ(u"ࠪࠫᒶ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᒷ"),kmdSKeBIwViM9t3(u"๊ࠬไห฻ส้้ࠦๅฺࠢส่๊็ึๅหࠣ࠲ࠥอะ่สࠣษ้๏ࠠศๆิหอ฽ࠠศๆำ๎ࠥะั๋ัࠣษ฻อแห้ࠣวํࠦๅิฯ๊ࠤ๊์ࠠࠡไสส๊ฯࠠศๆ่ๅ฻๊ษ๊ࠡ็็๋ࠦไศࠢอ๊็ืฺࠠๆํ๋ࠥ๎ไศࠢอุ฿๊็ࠡ࠰ࠣ์ออำหะาห๊ࠦࠢศๆ่หํูࠢࠡล๋ࠤࠧอไา์่์ฯࠨࠠศุ฽฻ࠥ฿ไ๊ࠢส่ืืࠠอ้ฬࠤฬ๊๊ๆ์้ࠤ࠳่ࠦฤ็สࠤออำหะาห๊ࠦࠢศๆๆ๎อ๎ัะࠤࠣๅฬ฼ฺุࠢ฼่๎ࠦอาใࠣࠦࡈࠨࠠฤ๊ࠣ฽้๏ࠠำำࠣࠦฬ๊โศศ่อࠧࠦวๅาํࠤๆ๐ࠠอ้ฬࠤฬ๊๊ๆ์้ࠤ࠳่ࠦ็ใึࠤฬ๊ใๅษ่ࠤํอไุำํๆฮูࠦ็ัࠣห้ะูศ็็ࠤ๊฿ࠠๆฯอ์๏อสࠡไ๋หห๋ࠠศๆ่ๅ฻๊ษࠨᒸ"))
	return
def ZOIbNiQGafpXCxh3E1w4ulsD9my(showDialogs=XogUJZEijT7KWbxeO6(u"ࡖࡵࡹࡪᚃ")):
	dO907nchLeoKSFbRj6uaHBxqVGWT = [PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡱࡷ࡬ࡪࡸࡳࠨᒹ"),kmdSKeBIwViM9t3(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡪ࡭ࡹ࡫ࡥࠨᒺ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨࠫᒻ"),gSmqZU0plur2xKPJwQA(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲࡬࡯ࡴࡩࡷࡥࠫᒼ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡧࡤࠫᒽ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡣࡰࡦࡨࡦࡪࡸࡧࠨᒾ")]
	y9nKcwjLV1Zih3XfxdWHoM0 = dO907nchLeoKSFbRj6uaHBxqVGWT+[MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧᒿ"),EDPaWgMt1SwNn8o(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫᓀ"),FhcnOB9t3frzvXb(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ᓁ"),J3OCAmZVcn(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧᓂ"),DLSVmlyBbCK(u"ࠩࡶ࡯࡮ࡴ࠮ࡱࡪࡨࡲࡴࡳࡥ࡯ࡣ࡯ࡉࡒࡇࡄࠨᓃ"),Ej67fFyoqW8kbV2HdSK(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧᓄ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡾࡺ࠭ࡥ࡮ࡳࠫᓅ")]
	ZUCy6NxE0T7rkjYLpScutH81 = XxDICeh4Y7yOvFtq([JMLhEyaBWmskovGHTrVCxQ08(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧᓆ")])
	MlaJbexB1OcHW6ZDXS2RVNTdIuEo7 = []
	for ZK5gkAtjrCeEXYGD2bRQHOF3Moyc in [kmdSKeBIwViM9t3(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨᓇ")]:
		if ZK5gkAtjrCeEXYGD2bRQHOF3Moyc not in list(ZUCy6NxE0T7rkjYLpScutH81.keys()): continue
		HVhWsdYRMyzq,VXjAU9TxqzSBP1DeRvnLcpwo0YfK8,RSjEAZU0gca,aheZ6MPkfd2O3uL8tKyxGo,H3wQ8jn2MVNfOYoX4,hy6cWmn15srpG7gl3auNtC,aawySXrIb0 = ZUCy6NxE0T7rkjYLpScutH81[ZK5gkAtjrCeEXYGD2bRQHOF3Moyc]
		if not VXjAU9TxqzSBP1DeRvnLcpwo0YfK8 or (VXjAU9TxqzSBP1DeRvnLcpwo0YfK8 and HVhWsdYRMyzq): MlaJbexB1OcHW6ZDXS2RVNTdIuEo7.append(ZK5gkAtjrCeEXYGD2bRQHOF3Moyc)
	HHsoZxXuymCAIGbUP8Dki = len(MlaJbexB1OcHW6ZDXS2RVNTdIuEo7)>J3OCAmZVcn(u"࠶ᙁ")
	m5h4wdsHCKLvPu9V6rEFi2q = esvtXhdikb2GDJm5Arc.connect(CGoMep90r3LDHfxU16ntBZi8hdaIJg)
	m5h4wdsHCKLvPu9V6rEFi2q.text_factory = str
	nRseEAQwXo4jC21gmqPzIihfUc = m5h4wdsHCKLvPu9V6rEFi2q.cursor()
	JNgZDWuPyfcC9oHwMeEk = []
	for ZK5gkAtjrCeEXYGD2bRQHOF3Moyc in dO907nchLeoKSFbRj6uaHBxqVGWT:
		nRseEAQwXo4jC21gmqPzIihfUc.execute(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡨࡲࡦࡨ࡬ࡦࡦࠣࡁࠥࠨ࠱ࠣࠢࡤࡲࡩࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫᓈ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+m6b7CoBk4EQ(u"ࠨࠤࠣ࠿ࠬᓉ"))
		h72BryKAmUNjZwIqgvYtD = nRseEAQwXo4jC21gmqPzIihfUc.fetchall()
		if h72BryKAmUNjZwIqgvYtD: JNgZDWuPyfcC9oHwMeEk.append(ZK5gkAtjrCeEXYGD2bRQHOF3Moyc)
	pgBHCQS6R2U4rJxymhPYtFTnw = len(JNgZDWuPyfcC9oHwMeEk)>EDPaWgMt1SwNn8o(u"࠰ᙂ")
	for ZK5gkAtjrCeEXYGD2bRQHOF3Moyc in y9nKcwjLV1Zih3XfxdWHoM0:
		nRseEAQwXo4jC21gmqPzIihfUc.execute(yTMWeCgUROcvtsblfK85L62xPk(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡲࡶ࡮࡭ࡩ࡯ࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧᓊ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+c4QSTnPiWUCjhrLlwGB(u"ࠪࠦࠥࡁࠧᓋ"))
		gQulv4VNswEkSHZI6j0FByhLUY = nRseEAQwXo4jC21gmqPzIihfUc.fetchall()
		if gQulv4VNswEkSHZI6j0FByhLUY and ZSJVq5XDrRot(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭ᓌ") not in str(gQulv4VNswEkSHZI6j0FByhLUY): MlaJbexB1OcHW6ZDXS2RVNTdIuEo7.append(ZK5gkAtjrCeEXYGD2bRQHOF3Moyc)
	GWz8ZNyY3Q9S0qCeH4Kt = len(MlaJbexB1OcHW6ZDXS2RVNTdIuEo7)>hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠱ᙃ")
	MlaJbexB1OcHW6ZDXS2RVNTdIuEo7 = list(set(MlaJbexB1OcHW6ZDXS2RVNTdIuEo7))
	m5h4wdsHCKLvPu9V6rEFi2q.close()
	HVhWsdYRMyzq = MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࡉࡥࡱࡹࡥᚄ")
	if pgBHCQS6R2U4rJxymhPYtFTnw or GWz8ZNyY3Q9S0qCeH4Kt:
		YYkEu4IL0sTa = OxCB4medn1(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᓍ"),ZSJVq5XDrRot(u"࠭ࠧᓎ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧࠨᓏ"),J3OCAmZVcn(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᓐ"),m6b7CoBk4EQ(u"ࠩส่อืๆศ็ฯࠤําฯࠡ็ื็้ฯࠠโ์ุ้ࠣะ่ะ฻ࠣ฽๊อฯࠡล๋ࠤฺ๊ใๅหࠣๅ๏ࠦวๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢ็ษ฻อแศฬࠣฬึ์วๆฮࠣ฽๊อฯࠡ࡞ࡱࡠࡳ࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞๊่ࠢࠥะั๋ัࠣษฺ๊วฮ๊ࠢิ์ࠦวๅ็ื็้ฯࠠศๆล๊ࠥล࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨᓑ"))
		if YYkEu4IL0sTa==ZSJVq5XDrRot(u"࠳ᙄ"):
			ZQ6y0v2SiDKcpaP = yTMWeCgUROcvtsblfK85L62xPk(u"ࡘࡷࡻࡥᚅ")
			if HHsoZxXuymCAIGbUP8Dki:
				ZQ6y0v2SiDKcpaP = Tj9ZsGIv1hxtzFe7HuWobP05V(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬᓒ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࡋࡧ࡬ࡴࡧᚆ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࡋࡧ࡬ࡴࡧᚆ"))
			GVvtXx94Okmz = jYaM5vilgZdFx6QHbApwVXO8et(u"࡚ࡲࡶࡧᚇ")
			if pgBHCQS6R2U4rJxymhPYtFTnw:
				for ZK5gkAtjrCeEXYGD2bRQHOF3Moyc in JNgZDWuPyfcC9oHwMeEk: LL4Wwzr8SG170oqUiH(ZK5gkAtjrCeEXYGD2bRQHOF3Moyc)
				GVvtXx94Okmz = DLSVmlyBbCK(u"ࡔࡳࡷࡨᚈ")
			XyIsgbCH3S2kt6uReLJ75BQ1 = aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࡕࡴࡸࡩᚉ")
			if GWz8ZNyY3Q9S0qCeH4Kt:
				m5h4wdsHCKLvPu9V6rEFi2q = esvtXhdikb2GDJm5Arc.connect(CGoMep90r3LDHfxU16ntBZi8hdaIJg)
				m5h4wdsHCKLvPu9V6rEFi2q.text_factory = str
				nRseEAQwXo4jC21gmqPzIihfUc = m5h4wdsHCKLvPu9V6rEFi2q.cursor()
				for ZK5gkAtjrCeEXYGD2bRQHOF3Moyc in MlaJbexB1OcHW6ZDXS2RVNTdIuEo7:
					if m6b7CoBk4EQ(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࠧᓓ") in ZK5gkAtjrCeEXYGD2bRQHOF3Moyc: gQulv4VNswEkSHZI6j0FByhLUY = ZK5gkAtjrCeEXYGD2bRQHOF3Moyc
					else: gQulv4VNswEkSHZI6j0FByhLUY = sArCMRngQNmXkBoKv(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧᓔ")
					try: nRseEAQwXo4jC21gmqPzIihfUc.execute(AAgpHN0nMZ(u"࠭ࡕࡑࡆࡄࡘࡊࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠢࡖࡉ࡙ࠦ࡯ࡳ࡫ࡪ࡭ࡳࠦ࠽ࠡࠤࠪᓕ")+gQulv4VNswEkSHZI6j0FByhLUY+kRYWcNuAazr4jtmBoxFVS19Z6(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭ᓖ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+EDPaWgMt1SwNn8o(u"ࠨࠤࠣ࠿ࠬᓗ"))
					except: XyIsgbCH3S2kt6uReLJ75BQ1 = gSmqZU0plur2xKPJwQA(u"ࡈࡤࡰࡸ࡫ᚊ")
				m5h4wdsHCKLvPu9V6rEFi2q.commit()
				m5h4wdsHCKLvPu9V6rEFi2q.close()
			luMHeSgCBaPrb9KvUjNFqcR.sleep(ZSJVq5XDrRot(u"࠴ᙅ"))
			cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ࠭ᓘ"))
			luMHeSgCBaPrb9KvUjNFqcR.sleep(sArCMRngQNmXkBoKv(u"࠵ᙆ"))
			if ZQ6y0v2SiDKcpaP or GVvtXx94Okmz or XyIsgbCH3S2kt6uReLJ75BQ1:
				HVhWsdYRMyzq = eeIL1TfgFQJaKqVD8hGNPEZ(u"ࡉࡥࡱࡹࡥᚋ")
				HHTzVhiY079bvdluNkFQ4wCMpe(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࠫᓙ"),DLSVmlyBbCK(u"ࠫࠬᓚ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᓛ"),fR68jBGWCzUsFXdlTKPOScugm(u"࠭ฬ๋ัࠣ࠲࠳ࠦสๆࠢห๊ัออࠡฬไ฽๏๊้ࠠวุ่ฬำࠠศๆ่ืฯ๎ฯฺ๋ࠢห้ะอะ์ฮࠤฬ๊สๅไสส๏ࠦไอ็ํ฽ࠥหึศใสฮࠥฮั็ษ่ะࠥ฿ๅศัࠪᓜ"))
			else:
				HVhWsdYRMyzq = sArCMRngQNmXkBoKv(u"ࡘࡷࡻࡥᚌ")
				HHTzVhiY079bvdluNkFQ4wCMpe(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧࠨᓝ"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠨࠩᓞ"),c4QSTnPiWUCjhrLlwGB(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᓟ"),FhcnOB9t3frzvXb(u"่้ࠪษำโࠢ࠱࠲ࠥ็ิๅฬࠣ฽๊๊๊สࠢศู้ออࠡ็ึฮํีูࠡ฻่หิ่ࠦฦื็หาࠦวๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢ็ษ฻อแศฬࠣฬึ์วๆฮࠣ฽๊อฯࠨᓠ"))
	elif showDialogs: HHTzVhiY079bvdluNkFQ4wCMpe(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠫࠬᓡ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬ࠭ᓢ"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᓣ"),DLSVmlyBbCK(u"ࠧอ์าࠤัีวࠡ࠰࠱ࠤฬ๊ศา่ส้ัࠦไๆࠢํะิࠦๅีๅ็อࠥ็๊ࠡ็ึฮํีูࠡ฻่หิࠦร้ࠢไ๎ࠥอไหฯา๎ะࠦวๅฬ็ๆฬฬ๊ࠡๆศฺฬ็วหࠢหี๋อๅอࠢ฼้ฬีࠧᓤ"))
	return HVhWsdYRMyzq
def KFhCv3nyVNgERte2b7mruLc():
	pAcUmhCV9uyi0,N2GF4HyKxtYjC,ixJnyRQI0ph6UbP = hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࡋࡧ࡬ࡴࡧᚍ"),gSmqZU0plur2xKPJwQA(u"ࠨࠩᓥ"),gnfv8UtZ3daGqpjzk(u"ࠩࠪᓦ")
	CvxpS8hw06bPdHDagXcfQqyeYV,GDVmsCnEwhkXiZO10,TWetruIqvLKys = EDPaWgMt1SwNn8o(u"ࡌࡡ࡭ࡵࡨᚎ"),pEo8g7riWVL014KaRtzQ(u"ࠪࠫᓧ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠫࠬᓨ")
	xx7WK5UMjqQ = [ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪᓩ"),c4QSTnPiWUCjhrLlwGB(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬᓪ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩᓫ"),DLSVmlyBbCK(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧᓬ")]
	ZUCy6NxE0T7rkjYLpScutH81 = XxDICeh4Y7yOvFtq(xx7WK5UMjqQ)
	for ZK5gkAtjrCeEXYGD2bRQHOF3Moyc in xx7WK5UMjqQ:
		if ZK5gkAtjrCeEXYGD2bRQHOF3Moyc not in list(ZUCy6NxE0T7rkjYLpScutH81.keys()): continue
		HVhWsdYRMyzq,VXjAU9TxqzSBP1DeRvnLcpwo0YfK8,wVtAH7Oq9gNWkBuKl,ZndOUgIT2XKtp4A3rJV9mYv7l0s,qdDYlWhnL26jymixs5M3GZH8gX,htyZkGQTeSmCIA9r2Nx1vicMsbH03,UUu5b0VtLT2h8SGvXaIjicJAEB1zeC = ZUCy6NxE0T7rkjYLpScutH81[ZK5gkAtjrCeEXYGD2bRQHOF3Moyc]
		if ZK5gkAtjrCeEXYGD2bRQHOF3Moyc==JMLhEyaBWmskovGHTrVCxQ08(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧᓭ"):
			CvxpS8hw06bPdHDagXcfQqyeYV = HVhWsdYRMyzq
			GDVmsCnEwhkXiZO10 = m6b7CoBk4EQ(u"ࠪࠬࠬᓮ")+VXjAU9TxqzSBP1DeRvnLcpwo0YfK8+sArCMRngQNmXkBoKv(u"ࠫࠥ࠭ᓯ")+Po4CyOusDaWq6pbIjYV(htyZkGQTeSmCIA9r2Nx1vicMsbH03)+J3OCAmZVcn(u"ࠬ࠯ࠧᓰ")
			TWetruIqvLKys = ZndOUgIT2XKtp4A3rJV9mYv7l0s
		elif ZK5gkAtjrCeEXYGD2bRQHOF3Moyc==MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨᓱ"):
			pAcUmhCV9uyi0 = pAcUmhCV9uyi0 or HVhWsdYRMyzq
			N2GF4HyKxtYjC += JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠧࠡࠢ࠯ࠤࠥ࠮ࠧᓲ")+VXjAU9TxqzSBP1DeRvnLcpwo0YfK8+JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠨࠢࠪᓳ")+Po4CyOusDaWq6pbIjYV(htyZkGQTeSmCIA9r2Nx1vicMsbH03)+yTMWeCgUROcvtsblfK85L62xPk(u"ࠩࠬࠫᓴ")
			ixJnyRQI0ph6UbP += fR68jBGWCzUsFXdlTKPOScugm(u"ࠪࠤࠥ࠲ࠠࠡࠩᓵ")+ZndOUgIT2XKtp4A3rJV9mYv7l0s
		elif ZK5gkAtjrCeEXYGD2bRQHOF3Moyc==eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪᓶ"):
			Q7FU0LazOVYjx = HVhWsdYRMyzq
			ppe5cATMHhug1PSknrDVKoyREU = pEo8g7riWVL014KaRtzQ(u"ࠬ࠮ࠧᓷ")+VXjAU9TxqzSBP1DeRvnLcpwo0YfK8+ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭ࠠࠨᓸ")+Po4CyOusDaWq6pbIjYV(htyZkGQTeSmCIA9r2Nx1vicMsbH03)+yTMWeCgUROcvtsblfK85L62xPk(u"ࠧࠪࠩᓹ")
			khQnDqzmHbfdV4ju = ZndOUgIT2XKtp4A3rJV9mYv7l0s
	N2GF4HyKxtYjC = N2GF4HyKxtYjC.strip(FhcnOB9t3frzvXb(u"ࠨࠢࠣ࠰ࠥࠦࠧᓺ"))
	ixJnyRQI0ph6UbP = ixJnyRQI0ph6UbP.strip(yTMWeCgUROcvtsblfK85L62xPk(u"ࠩࠣࠤ࠱ࠦࠠࠨᓻ"))
	oDhA56fLa0XZSWc3rzV  = OVmSuf8tpd(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ศิ๊าࠢ็ฬึ์วๆฮࠣ฽๊อฯࠡษ็้ฯ๎แาࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪᓼ")+TWetruIqvLKys+jYaM5vilgZdFx6QHbApwVXO8et(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᓽ")
	oDhA56fLa0XZSWc3rzV += xuYvdJpOEyQKTLNwb(u"ࠬࡢ࡮ࠨᓾ")+m6b7CoBk4EQ(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไั์ࠣห๋ะࠠหีอาิ๋็ࠡๆหี๋อๅอࠢ฼้ฬี่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪᓿ")+GDVmsCnEwhkXiZO10+ZSJVq5XDrRot(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᔀ")
	oDhA56fLa0XZSWc3rzV += OVmSuf8tpd(u"ࠨ࡞ࡱࡠࡳ࠭ᔁ")+wwyUWMFAsO(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็วำ๐ัࠡๆ่ืฯ๎ฯฺࠢ฼้ฬีࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤ࡛ࠥࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩᔂ")+ixJnyRQI0ph6UbP+Ej67fFyoqW8kbV2HdSK(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᔃ")
	oDhA56fLa0XZSWc3rzV += m6b7CoBk4EQ(u"ࠫࡡࡴࠧᔄ")+JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํࠠๅ็ึฮํีูࠡ฻่หิࠦ็้ࠢ࠽ࠤ࡛ࠥࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩᔅ")+N2GF4HyKxtYjC+bdhQDyjm3nPwToFHkprvCzBLUGR(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨᔆ")
	oDhA56fLa0XZSWc3rzV += gSmqZU0plur2xKPJwQA(u"ࠧ࡝ࡰ࡟ࡲࠬᔇ")+c4QSTnPiWUCjhrLlwGB(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆฦา๏ืࠠๅฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥอไๆฬ๋ๅึࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧᔈ")+khQnDqzmHbfdV4ju+aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᔉ")
	oDhA56fLa0XZSWc3rzV += Ej67fFyoqW8kbV2HdSK(u"ࠪࡠࡳ࠭ᔊ")+J3OCAmZVcn(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦไอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ์๎ࠠ࠻ࠢࠣࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧᔋ")+ppe5cATMHhug1PSknrDVKoyREU+kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᔌ")
	HVhWsdYRMyzq = (CvxpS8hw06bPdHDagXcfQqyeYV or pAcUmhCV9uyi0)
	if HVhWsdYRMyzq:
		header = sArCMRngQNmXkBoKv(u"࠭วๅำฯหฦࠦสฮัํฯࠥหึศใสฮ้่ࠥะ์่ࠣา๊ࠠศๆุ่ฬ้ไࠨᔍ")
		Qg3B18PfKv7kTZe = J3OCAmZVcn(u"ࠧศ่อࠤอำวอห่ࠣฯำฯ๋อࠣฬึ์วๆฮࠣ฽๊อฯࠡล๋ࠤฯำฯ๋อุ้ࠣะ่ะ฻ࠣ฽๊อฯࠨᔎ")
	else:
		header = m6b7CoBk4EQ(u"ࠨฯส่๏อࠠๅษࠣ๎ําฯࠡฬะำ๏ัวหࠢ็ฬึ์วๆฮࠣ฽๊อฯࠡล๋ࠤู๊ส้ั฼ࠤ฾๋วะࠩᔏ")
		Qg3B18PfKv7kTZe = c4QSTnPiWUCjhrLlwGB(u"ࠩส่ึาวยࠢศฬ้อฺࠡษ็้อืๅอࠢ฼๊ࠥอไๆึๆ่ฮࠦวๅฬํࠤฯ๎วอ้ๆࠫᔐ")
	qvmFG30k1AwZBY2uRSpWjI7xXsfdQD = kRYWcNuAazr4jtmBoxFVS19Z6(u"่่ࠪ๐๋ࠠ฻่่ࠥ฿ๆะๅࠣห้ะอะ์ฮࠤฬ๊สๅไสส๏๊ࠦอสࠣว๋๊ࠦไ๊้ࠤ้ี๊ไࠢไ๎้่ࠥะ์࡟ࡲู๊ส้ั฼ࠤ฾๋วะࠢࡈࡑࡆࡊࠠࡓࡧࡳࡳࡸ࡯ࡴࡰࡴࡼࠫᔑ")
	ZRKXMjwCptG = oDhA56fLa0XZSWc3rzV+aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠫࡡࡴ࡜࡯ࠩᔒ")+Qg3B18PfKv7kTZe+OVmSuf8tpd(u"ࠬࡢ࡮࡝ࡰࠪᔓ")+qvmFG30k1AwZBY2uRSpWjI7xXsfdQD
	FD5mbRq2ypcA6QOUE8hG(gSmqZU0plur2xKPJwQA(u"࠭ࡲࡪࡩ࡫ࡸࠬᔔ"),header,ZRKXMjwCptG,ZSJVq5XDrRot(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪᔕ"))
	return
def LLMXenCcYZHSN4OKzy9R(showDialogs,hhej2OHCSYlDdxv5wNAbmJ6EqGuW):
	ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,gSmqZU0plur2xKPJwQA(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫᔖ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪᔗ"))
	if showDialogs:
		KFhCv3nyVNgERte2b7mruLc()
		Cci3Yy4nZJwjWqUOpbD0r8X2()
	if hhej2OHCSYlDdxv5wNAbmJ6EqGuW:
		ZOIbNiQGafpXCxh3E1w4ulsD9my(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࡆࡢ࡮ࡶࡩᚏ"))
		BTs8teMr09j2Na = [ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨᔘ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪᔙ"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧᔚ"),yTMWeCgUROcvtsblfK85L62xPk(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪᔛ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡶ࠰ࡨࡱࡶࠧᔜ")]
		for eNtdzAFGlMHm1W6 in BTs8teMr09j2Na:
			ybf3Qo7isaYVr,JJVEmtC8jpGPN9XY6cq0zrFdv,VXjAU9TxqzSBP1DeRvnLcpwo0YfK8 = Tj9ZsGIv1hxtzFe7HuWobP05V(eNtdzAFGlMHm1W6,sArCMRngQNmXkBoKv(u"ࡖࡵࡹࡪᚑ"),aVLSn1xw5cK(u"ࡇࡣ࡯ࡷࡪᚐ"))
		tKcmZ2YEF06ysejqd59Nv(showDialogs)
		cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(EDPaWgMt1SwNn8o(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬᔝ"))
	return
def cZjl7kE40hJznyQt5(eeUlISkyoOaPTCpqWD5Yr2VXc3d6=xuYvdJpOEyQKTLNwb(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨᔞ"),showDialogs=sArCMRngQNmXkBoKv(u"ࡗࡶࡺ࡫ᚒ")):
	lC8scLAd0IFYuTbR3UWk9ZxJNSQ = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executeJSONRPC(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭ᔟ"))
	import json as VmSKvRtTw5WBYDI
	data = VmSKvRtTw5WBYDI.loads(lC8scLAd0IFYuTbR3UWk9ZxJNSQ)
	ppOxeQwA8ldXjP1Gb4FT0EHmqRVi7 = data[jYaM5vilgZdFx6QHbApwVXO8et(u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫᔠ")][gSmqZU0plur2xKPJwQA(u"ࠬࡼࡡ࡭ࡷࡨࠫᔡ")]
	if Yd6t3PjlLKk: ppOxeQwA8ldXjP1Gb4FT0EHmqRVi7 = ppOxeQwA8ldXjP1Gb4FT0EHmqRVi7.encode(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭ࡵࡵࡨ࠻ࠫᔢ"))
	if showDialogs:
		YYkEu4IL0sTa = OxCB4medn1(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠧࠨᔣ"),sArCMRngQNmXkBoKv(u"ࠨࠩᔤ"),c4QSTnPiWUCjhrLlwGB(u"ࠩࠪᔥ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᔦ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫ์๊ࠠหำํำࠥะฺ๋์ิࠤั๊ฯࠡࠩᔧ")+ppOxeQwA8ldXjP1Gb4FT0EHmqRVi7+c4QSTnPiWUCjhrLlwGB(u"ࠬࠦวๅาํࠤู๊สฯั่ࠤฬ๊ย็ࠢไ๎้่ࠥะ์ࠣษ้๏ࠠศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦࠧᔨ")+eeUlISkyoOaPTCpqWD5Yr2VXc3d6+fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࠠภࠣࠪᔩ"))
		if YYkEu4IL0sTa!=FhcnOB9t3frzvXb(u"࠶ᙇ"): return kRYWcNuAazr4jtmBoxFVS19Z6(u"ࡊࡦࡲࡳࡦᚓ")
	ybf3Qo7isaYVr,JJVEmtC8jpGPN9XY6cq0zrFdv,O0jiXVEUJoMuh48bBqKd9FRPNDaIY = Tj9ZsGIv1hxtzFe7HuWobP05V(eeUlISkyoOaPTCpqWD5Yr2VXc3d6,kmdSKeBIwViM9t3(u"ࡋࡧ࡬ࡴࡧᚔ"),kmdSKeBIwViM9t3(u"ࡋࡧ࡬ࡴࡧᚔ"))
	if ybf3Qo7isaYVr:
		if showDialogs: HHTzVhiY079bvdluNkFQ4wCMpe(gnfv8UtZ3daGqpjzk(u"ࠧࠨᔪ"),J3OCAmZVcn(u"ࠨࠩᔫ"),OVmSuf8tpd(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᔬ"),wwyUWMFAsO(u"ࠪฮ๊ะฺࠠ็็๎ฮࠦสฬสํฮࠥอไอๆาࠤฬ๊ฬะ์าࠤํํ่ࠡฮส๋ืࠦไๅษึฮำีวๆࠢ࠱ࠤุ๎แࠡ์อ้ࠥอไร่ࠣฮ฿๐๊าࠢศ฽ิอฯศฬࠣ็ํี๊ࠡๆๆ๎ࠥ๐ำห฻่่ࠥอไอๆาࠤฬ๊ฬะ์าࠤอีไศ่๊ࠢࠥอไใัํ้ࠬᔭ"))
		FaLTw4gN9ZCSkJeqObQPu870o = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executeJSONRPC(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳࡙ࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦ࠱ࠨࡶࡢ࡮ࡸࡩࠧࡀࠢࠨᔮ")+eeUlISkyoOaPTCpqWD5Yr2VXc3d6+Ej67fFyoqW8kbV2HdSK(u"ࠬࠨࡽࡾࠩᔯ"))
		if bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࡏࡌࠩᔰ") in FaLTw4gN9ZCSkJeqObQPu870o: ybf3Qo7isaYVr = m6b7CoBk4EQ(u"࡚ࡲࡶࡧᚕ")
		luMHeSgCBaPrb9KvUjNFqcR.sleep(kmdSKeBIwViM9t3(u"࠷ᙈ"))
		cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧࡔࡧࡱࡨࡈࡲࡩࡤ࡭ࠫ࠵࠶࠯ࠧᔱ"))
	elif showDialogs: HHTzVhiY079bvdluNkFQ4wCMpe(FhcnOB9t3frzvXb(u"ࠨࠩᔲ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩࠪᔳ"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᔴ"),FhcnOB9t3frzvXb(u"้๊ࠫริใࠣๅู๊สࠡ฻่่๏ฯࠠหอห๎ฯ่ࠦหใ฼๎้ࠦวๅฮ็ำࠥอไๆู็์อ࠭ᔵ"))
	return ybf3Qo7isaYVr
def tTsLa8vMRzfgoVxdwkeW0DXCpKbPn(ZK5gkAtjrCeEXYGD2bRQHOF3Moyc,showDialogs=DLSVmlyBbCK(u"ࡔࡳࡷࡨᚖ")):
	if showDialogs==fR68jBGWCzUsFXdlTKPOScugm(u"ࠬ࠭ᔶ"): showDialogs = sArCMRngQNmXkBoKv(u"ࡕࡴࡸࡩᚗ")
	u3uEcyjGSdUBFCTwt = iixDYHUoBgLIcC7XPT([ZK5gkAtjrCeEXYGD2bRQHOF3Moyc])
	Hsp7DiTEZQq2oeBAGbwNWOKl90FVz,hqzZrtv5wjPVFHlxkY = u3uEcyjGSdUBFCTwt[ZK5gkAtjrCeEXYGD2bRQHOF3Moyc]
	if hqzZrtv5wjPVFHlxkY:
		ybf3Qo7isaYVr = ZSJVq5XDrRot(u"ࡖࡵࡹࡪᚘ")
		if showDialogs: HHTzVhiY079bvdluNkFQ4wCMpe(xuYvdJpOEyQKTLNwb(u"࠭ࠧᔷ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧࠨᔸ"),DLSVmlyBbCK(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᔹ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩไัฺࠦวๅวูหๆฯࠠ࡝ࡰࠣࠫᔺ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+LmcNhzY6fQPd2JyCGslkSr(u"ࠪࠤࡡࡴ่ࠠา๊ࠤศ๊ลืษไอࠥ฿ๆะๅ้ࠣํา่ะหࠣ์๊็ูๅหࠣ์ัอ็ำห่้ࠣอำหะาห๊࠭ᔻ"))
	else:
		ybf3Qo7isaYVr = ZSJVq5XDrRot(u"ࡉࡥࡱࡹࡥᚙ")
		YYkEu4IL0sTa = OxCB4medn1(AAgpHN0nMZ(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᔼ"),m6b7CoBk4EQ(u"ࠬ࠭ᔽ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠭ࠧᔾ"),FhcnOB9t3frzvXb(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᔿ"),gSmqZU0plur2xKPJwQA(u"ࠨࠩᕀ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+OVmSuf8tpd(u"ࠩࠣࡠࡳࠦ็ั้ࠣว้หึศใฬࠤ฾์ฯไࠢ฽๎ึࠦๅโ฻็อࠥษ่ࠡ฼ํี๋่ࠥอ๊าอࠥ࠴๋ࠠฮหࠤฯัศ๋ฬ๊หࠥ๎สโ฻ํ่์อࠠๅๅํࠤ๏฿ๅๅࠢส่อืๆศ็ฯࠤ฾์ฯไࠢหูํืษࠡืะ๎าฯࠠ࠯๊่ࠢࠥะั๋ัࠣฮะฮ๊ห๋ࠢฮๆ฿๊ๅ๊ࠢิ์ࠦวๅวูหๆฯࠠศๆล๊ࠥลࠧᕁ"))
		if YYkEu4IL0sTa==JMLhEyaBWmskovGHTrVCxQ08(u"࠱ᙉ"):
			cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࡍࡳࡹࡴࡢ࡮࡯ࡅࡩࡪ࡯࡯ࠪࠪᕂ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+yTMWeCgUROcvtsblfK85L62xPk(u"ࠫ࠮࠭ᕃ"))
			luMHeSgCBaPrb9KvUjNFqcR.sleep(J3OCAmZVcn(u"࠲ᙊ"))
			cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(m6b7CoBk4EQ(u"࡙ࠬࡥ࡯ࡦࡆࡰ࡮ࡩ࡫ࠩ࠳࠴࠭ࠬᕄ"))
			luMHeSgCBaPrb9KvUjNFqcR.sleep(gSmqZU0plur2xKPJwQA(u"࠳ᙋ"))
			while cPwDBuG4HVTCdQ9JmMeoWjNY2hX.getCondVisibility(jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࡗࡪࡰࡧࡳࡼ࠴ࡉࡴࡃࡦࡸ࡮ࡼࡥࠩࡲࡵࡳ࡬ࡸࡥࡴࡵࡧ࡭ࡦࡲ࡯ࡨࠫࠪᕅ")): luMHeSgCBaPrb9KvUjNFqcR.sleep(Ej67fFyoqW8kbV2HdSK(u"࠴ᙌ"))
			FaLTw4gN9ZCSkJeqObQPu870o = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executeJSONRPC(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡁࡥࡦࡲࡲࡸ࠴ࡓࡦࡶࡄࡨࡩࡵ࡮ࡆࡰࡤࡦࡱ࡫ࡤࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡡࡥࡦࡲࡲ࡮ࡪࠢ࠻ࠤࠪᕆ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+sArCMRngQNmXkBoKv(u"ࠨࠤ࠯ࠦࡪࡴࡡࡣ࡮ࡨࡨࠧࡀࡴࡳࡷࡨࢁࢂ࠭ᕇ"))
			if JMLhEyaBWmskovGHTrVCxQ08(u"ࠩࡒࡏࠬᕈ") in FaLTw4gN9ZCSkJeqObQPu870o:
				ybf3Qo7isaYVr = sArCMRngQNmXkBoKv(u"ࡘࡷࡻࡥᚚ")
				if showDialogs: HHTzVhiY079bvdluNkFQ4wCMpe(xuYvdJpOEyQKTLNwb(u"ࠪࠫᕉ"),LmcNhzY6fQPd2JyCGslkSr(u"ࠫࠬᕊ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᕋ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭สๆࠢไัฺࠦร้ࠢอฯอ๐สࠡล๋ࠤฯ็ู๋ๆࠣวํࠦสฮัํฯࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษ๊๊ࠡ๎ࠥอไร่ࠣะฬําสࠢ็่ฬูสฯัส้ࠬᕌ"))
			elif showDialogs: HHTzVhiY079bvdluNkFQ4wCMpe(wwyUWMFAsO(u"ࠧࠨᕍ"),gnfv8UtZ3daGqpjzk(u"ࠨࠩᕎ"),XogUJZEijT7KWbxeO6(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᕏ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠪๅู๊ࠠโ์ࠣฮะฮ๊หࠢฦ์ࠥะแฺ์็ࠤศ๎ࠠหฯา๎ะࠦวๅวูหๆฯࠠศๆ่฻้๎ศสࠢ࠱ࠤํอไฮๆ๋ࠣํࠦสฬสํฮ์อ้ࠠฬไ฽๏๊็ศ่๊ࠢࠥิวาฮࠣห้ฮั็ษ่ะࠬᕐ"))
	return ybf3Qo7isaYVr
def aatn01gK8mSI6RZWPcDxfs3JQywGBl(ZK5gkAtjrCeEXYGD2bRQHOF3Moyc,UUu5b0VtLT2h8SGvXaIjicJAEB1zeC,showDialogs):
	ybf3Qo7isaYVr = JMLhEyaBWmskovGHTrVCxQ08(u"ࡋࡧ࡬ࡴࡧ᚛")
	if showDialogs:
		YYkEu4IL0sTa = OxCB4medn1(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫࠬᕑ"),LmcNhzY6fQPd2JyCGslkSr(u"ࠬ࠭ᕒ"),XogUJZEijT7KWbxeO6(u"࠭ࠧᕓ"),kmdSKeBIwViM9t3(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᕔ"),sArCMRngQNmXkBoKv(u"ࠨี๋ๅࠥ๐สๆࠢส่ว์ࠠอๆหࠤฬ๊ๅๅใࠣห้๋ึ฻ฺ๊ࠤ้๊ลืษไอࠥอไๆู็์อฯࠠๅๅํࠤ๏ะๅࠡฬฮฬ๏ะ็ࠡ฻็ํ้่ࠥะ์ࠣ࠲ࠥอไๆๆไࠤ็ี๋ࠠๅ๋๊้ࠥศ๋ำࠣ์็ี๋ࠠฯอหัࠦศฺุࠣห้๎โหࠢ࠱ࠤ์๊ࠠหำํำࠥะอๆ์็ࠤฬ๊ๅๅใࠣห้ศๆࠡมࠤࠫᕕ"))
		if YYkEu4IL0sTa!=kmdSKeBIwViM9t3(u"࠵ᙍ"): return ZSJVq5XDrRot(u"ࡌࡡ࡭ࡵࡨ᚜")
	TbBxneaIil6usNcZ2trvVLO85q0XGR = L41Ku9Nxqcsw(UUu5b0VtLT2h8SGvXaIjicJAEB1zeC,{},showDialogs)
	if TbBxneaIil6usNcZ2trvVLO85q0XGR:
		EAicvVI8jXPC = hhHq8m5vauKG9dl.path.join(hWu2yd5fRP,ZK5gkAtjrCeEXYGD2bRQHOF3Moyc)
		Eux3w7MylkQfiBa6pvJO0FWTNbr(EAicvVI8jXPC,sArCMRngQNmXkBoKv(u"ࡕࡴࡸࡩ᚞"),XogUJZEijT7KWbxeO6(u"ࡆࡢ࡮ࡶࡩ᚝"))
		import zipfile as IIteL3Wvcw7N4R0BlUGAFQ9iOrC,io as dWZaeXTpCb5kFGO
		OLmSaVCj2wNhYbnPGl4xuQ0ERsUe9 = dWZaeXTpCb5kFGO.BytesIO(TbBxneaIil6usNcZ2trvVLO85q0XGR)
		try:
			dNV3rIfBUyzSJsFncgY5 = IIteL3Wvcw7N4R0BlUGAFQ9iOrC.ZipFile(OLmSaVCj2wNhYbnPGl4xuQ0ERsUe9)
			dNV3rIfBUyzSJsFncgY5.extractall(hWu2yd5fRP)
			luMHeSgCBaPrb9KvUjNFqcR.sleep(XogUJZEijT7KWbxeO6(u"࠶ᙎ"))
			cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ࠭ᕖ"))
			luMHeSgCBaPrb9KvUjNFqcR.sleep(pEo8g7riWVL014KaRtzQ(u"࠸ᙏ"))
			FaLTw4gN9ZCSkJeqObQPu870o = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executeJSONRPC(pEo8g7riWVL014KaRtzQ(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡄࡨࡩࡵ࡮ࡴ࠰ࡖࡩࡹࡇࡤࡥࡱࡱࡉࡳࡧࡢ࡭ࡧࡧࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡤࡨࡩࡵ࡮ࡪࡦࠥ࠾ࠧ࠭ᕗ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+sArCMRngQNmXkBoKv(u"ࠫࠧ࠲ࠢࡦࡰࡤࡦࡱ࡫ࡤࠣ࠼ࡷࡶࡺ࡫ࡽࡾࠩᕘ"))
			if aVLSn1xw5cK(u"ࠬࡕࡋࠨᕙ") in FaLTw4gN9ZCSkJeqObQPu870o: ybf3Qo7isaYVr = yTMWeCgUROcvtsblfK85L62xPk(u"ࡖࡵࡹࡪ᚟")
			ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,EDPaWgMt1SwNn8o(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩᕚ"),LmcNhzY6fQPd2JyCGslkSr(u"ࠧࡂࡆࡇࡓࡓ࡙࡟ࡅࡇࡗࡅࡎࡒࡓࠨᕛ"))
		except: ybf3Qo7isaYVr = ZSJVq5XDrRot(u"ࡉࡥࡱࡹࡥᚠ")
	if showDialogs:
		if ybf3Qo7isaYVr: HHTzVhiY079bvdluNkFQ4wCMpe(LmcNhzY6fQPd2JyCGslkSr(u"ࠨࠩᕜ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩࠪᕝ"),xuYvdJpOEyQKTLNwb(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᕞ"),XogUJZEijT7KWbxeO6(u"ࠫฯ๋ࠠษ่ฯหาࠦสฬสํฮࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษࠨᕟ"))
		else: HHTzVhiY079bvdluNkFQ4wCMpe(aVLSn1xw5cK(u"ࠬ࠭ᕠ"),OVmSuf8tpd(u"࠭ࠧᕡ"),gSmqZU0plur2xKPJwQA(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᕢ"),wwyUWMFAsO(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯัศ๋ฬࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮ࠭ᕣ"))
	return ybf3Qo7isaYVr
def Tj9ZsGIv1hxtzFe7HuWobP05V(ZK5gkAtjrCeEXYGD2bRQHOF3Moyc,showDialogs,QcKsqHu2ED4wlb6AJ0I7k):
	YYkEu4IL0sTa,ybf3Qo7isaYVr,JJVEmtC8jpGPN9XY6cq0zrFdv,VXjAU9TxqzSBP1DeRvnLcpwo0YfK8 = J3OCAmZVcn(u"࡙ࡸࡵࡦᚢ"),xuYvdJpOEyQKTLNwb(u"ࡊࡦࡲࡳࡦᚡ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩᕤ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪࠫᕥ")
	ZUCy6NxE0T7rkjYLpScutH81 = XxDICeh4Y7yOvFtq([ZK5gkAtjrCeEXYGD2bRQHOF3Moyc])
	if ZK5gkAtjrCeEXYGD2bRQHOF3Moyc in list(ZUCy6NxE0T7rkjYLpScutH81.keys()):
		HVhWsdYRMyzq,VXjAU9TxqzSBP1DeRvnLcpwo0YfK8,wVtAH7Oq9gNWkBuKl,ZndOUgIT2XKtp4A3rJV9mYv7l0s,qdDYlWhnL26jymixs5M3GZH8gX,htyZkGQTeSmCIA9r2Nx1vicMsbH03,UUu5b0VtLT2h8SGvXaIjicJAEB1zeC = ZUCy6NxE0T7rkjYLpScutH81[ZK5gkAtjrCeEXYGD2bRQHOF3Moyc]
		if htyZkGQTeSmCIA9r2Nx1vicMsbH03==aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠫ࡬ࡵ࡯ࡥࠩᕦ"):
			ybf3Qo7isaYVr,JJVEmtC8jpGPN9XY6cq0zrFdv = ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࡚ࡲࡶࡧᚣ"),gnfv8UtZ3daGqpjzk(u"ࠬࡴ࡯ࡵࡪ࡬ࡲ࡬࠭ᕧ")
			if QcKsqHu2ED4wlb6AJ0I7k: HHTzVhiY079bvdluNkFQ4wCMpe(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭ࠧᕨ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧࠨᕩ"),xuYvdJpOEyQKTLNwb(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᕪ"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳ࠦใ้ัํࠤ๏ูสฯั่ࠤศิัࠡวุำฬืࠠๆฬ๋ๅึࠦแ๋่ࠢ์ฬู่ࠡ็ึฮํีูࠡ฻่หิࠦไ่า๊ࠤฬ๊ลืษไอࡡࡴ࡜࡯ࠩᕫ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc)
		else:
			if showDialogs:
				if htyZkGQTeSmCIA9r2Nx1vicMsbH03==AAgpHN0nMZ(u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬᕬ"): LaX1QCyeIJ = FhcnOB9t3frzvXb(u"๊ࠫะ่ใใฬࠫᕭ")
				elif htyZkGQTeSmCIA9r2Nx1vicMsbH03==fR68jBGWCzUsFXdlTKPOScugm(u"ࠬࡵ࡬ࡥࠩᕮ"): LaX1QCyeIJ = aVLSn1xw5cK(u"࠭โะ์่อࠬᕯ")
				elif htyZkGQTeSmCIA9r2Nx1vicMsbH03==JMLhEyaBWmskovGHTrVCxQ08(u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨᕰ"): LaX1QCyeIJ = ZSJVq5XDrRot(u"ࠨ฼ํี๋ࠥหษฬฬࠫᕱ")
				YYkEu4IL0sTa = OxCB4medn1(FhcnOB9t3frzvXb(u"ࠩࠪᕲ"),pEo8g7riWVL014KaRtzQ(u"ࠪࠫᕳ"),c4QSTnPiWUCjhrLlwGB(u"ࠫࠬᕴ"),OVmSuf8tpd(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᕵ"),AAgpHN0nMZ(u"࠭็ั้ࠣห้หึศใฬࠤࠬᕶ")+LaX1QCyeIJ+kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠧࠡ࠰࠱ࠤ์๊ࠠหำํำࠥหีๅษะࠤ์ึ็ࠡษ็ู้้ไสࠢยࠥࡡࡴ࡜࡯ࠩᕷ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc)
			if not YYkEu4IL0sTa: JJVEmtC8jpGPN9XY6cq0zrFdv = DLSVmlyBbCK(u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࠪᕸ")
			else:
				if htyZkGQTeSmCIA9r2Nx1vicMsbH03==wwyUWMFAsO(u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫᕹ"):
					HkKfQCS7RIa4xi3houjvl = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executeJSONRPC(c4QSTnPiWUCjhrLlwGB(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡄࡨࡩࡵ࡮ࡴ࠰ࡖࡩࡹࡇࡤࡥࡱࡱࡉࡳࡧࡢ࡭ࡧࡧࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡤࡨࡩࡵ࡮ࡪࡦࠥ࠾ࠧ࠭ᕺ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+pEo8g7riWVL014KaRtzQ(u"ࠫࠧ࠲ࠢࡦࡰࡤࡦࡱ࡫ࡤࠣ࠼ࡷࡶࡺ࡫ࡽࡾࠩᕻ"))
					if hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠬࡕࡋࠨᕼ") in HkKfQCS7RIa4xi3houjvl:
						ybf3Qo7isaYVr,JJVEmtC8jpGPN9XY6cq0zrFdv = hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࡔࡳࡷࡨᚤ"),m6b7CoBk4EQ(u"࠭ࡥ࡯ࡣࡥࡰࡪࡪࠧᕽ")
						if showDialogs: HHTzVhiY079bvdluNkFQ4wCMpe(J3OCAmZVcn(u"ࠧࠨᕾ"),Ej67fFyoqW8kbV2HdSK(u"ࠨࠩᕿ"),AAgpHN0nMZ(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᖀ"),gSmqZU0plur2xKPJwQA(u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠศๆศฺฬ็ษࠡๅส๊ฯࠦๅห๊ๅๅฮࠦ࠮࠯๋ࠢๆฬ๋ࠠศๆหี๋อๅอࠢหฮูเ๊ๅ้สࡠࡳࡢ࡮ࠨᖁ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc)
					elif showDialogs: HHTzVhiY079bvdluNkFQ4wCMpe(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫࠬᖂ"),wwyUWMFAsO(u"ࠬ࠭ᖃ"),kmdSKeBIwViM9t3(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᖄ"),J3OCAmZVcn(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢส่ส฼วโห้ࠣฯ๎โโหࠣ࠲࠳่ࠦๅ็ࠣ๎ุะื๋฻ࠣห้ฮั็ษ่ะࠥะิ฻์็๋ฬࡢ࡮࡝ࡰࠪᖅ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc)
				elif htyZkGQTeSmCIA9r2Nx1vicMsbH03 in [OVmSuf8tpd(u"ࠨࡱ࡯ࡨࠬᖆ"),wwyUWMFAsO(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪᖇ")]:
					ybf3Qo7isaYVr = aatn01gK8mSI6RZWPcDxfs3JQywGBl(ZK5gkAtjrCeEXYGD2bRQHOF3Moyc,UUu5b0VtLT2h8SGvXaIjicJAEB1zeC,pEo8g7riWVL014KaRtzQ(u"ࡇࡣ࡯ࡷࡪᚥ"))
					if ybf3Qo7isaYVr:
						if htyZkGQTeSmCIA9r2Nx1vicMsbH03==aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠪࡳࡱࡪࠧᖈ"): JJVEmtC8jpGPN9XY6cq0zrFdv = EDPaWgMt1SwNn8o(u"ࠫࡺࡶࡤࡢࡶࡨࡨࠬᖉ")
						elif htyZkGQTeSmCIA9r2Nx1vicMsbH03==OVmSuf8tpd(u"ࠬࡳࡩࡴࡵ࡬ࡲ࡬࠭ᖊ"): JJVEmtC8jpGPN9XY6cq0zrFdv = AAgpHN0nMZ(u"࠭ࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠩᖋ")
						VXjAU9TxqzSBP1DeRvnLcpwo0YfK8 = ZndOUgIT2XKtp4A3rJV9mYv7l0s
						if showDialogs:
							if JJVEmtC8jpGPN9XY6cq0zrFdv==ZSJVq5XDrRot(u"ࠧࡶࡲࡧࡥࡹ࡫ࡤࠨᖌ"): HHTzVhiY079bvdluNkFQ4wCMpe(JMLhEyaBWmskovGHTrVCxQ08(u"ࠨࠩᖍ"),FhcnOB9t3frzvXb(u"ࠩࠪᖎ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᖏ"),xuYvdJpOEyQKTLNwb(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢๆห๋ะࠠใัํ้ฮࠦ࠮࠯๋ࠢห้ฮั็ษ่ะ่ࠥวๆࠢหฮาี๊ฬ้สࡠࡳࡢ࡮ࠨᖐ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc)
							elif JJVEmtC8jpGPN9XY6cq0zrFdv==gnfv8UtZ3daGqpjzk(u"ࠬ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠨᖑ"): HHTzVhiY079bvdluNkFQ4wCMpe(fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࠧᖒ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࠨᖓ"),gnfv8UtZ3daGqpjzk(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᖔ"),DLSVmlyBbCK(u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳ࠦวๅวูหๆฯࠠๅ็ࠣฮ่์ࠠๆ๊ฯ์ิฯࠠโ์ࠣ็ํี๊ࠡ࠰࠱ࠤํอไษำ้ห๊าࠠใษ่ࠤอะหษ์อ๋ฬࡢ࡮࡝ࡰࠪᖕ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc)
					elif showDialogs: HHTzVhiY079bvdluNkFQ4wCMpe(pEo8g7riWVL014KaRtzQ(u"ࠪࠫᖖ"),OVmSuf8tpd(u"ࠫࠬᖗ"),OVmSuf8tpd(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᖘ"),pEo8g7riWVL014KaRtzQ(u"࠭ไๅลึๅࠥ࠴࠮ࠡษ็ฬึ์วๆฮ่๊๊ࠣࠦิฬฺ๎฾ࠦสฮัํฯࠥษ่ࠡฬฮฬ๏ะ่ࠠา๊ࠤฬ๊ลืษไอࡡࡴ࡜࡯ࠩᖙ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc)
	elif showDialogs: HHTzVhiY079bvdluNkFQ4wCMpe(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧࠨᖚ"),ZSJVq5XDrRot(u"ࠨࠩᖛ"),EDPaWgMt1SwNn8o(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᖜ"),pEo8g7riWVL014KaRtzQ(u"่้ࠪษำโࠢ࠱࠲ࠥํะ่ࠢส่ส฼วโหࠣ฾๏ืࠠๆ๊ฯ์ิฯࠠโ์้ࠣํอโฺ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠ࠯࠰ࠣ์้ํะศࠢ็หࠥ๐ำหูํ฽ࠥอไษำ้ห๊าࠠฤ่ࠣ๎็๎ๅࠡสอฯอ๐ส้ࠡำ๋ࠥอไฦุสๅฮࠦร้ࠢอัิ๐ห่ษ࡟ࡲࡡࡴࠧᖝ")+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc)
	return ybf3Qo7isaYVr,JJVEmtC8jpGPN9XY6cq0zrFdv,VXjAU9TxqzSBP1DeRvnLcpwo0YfK8
# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'HALACIMA'
W74fAyGxODoLPs5vMX2l8C93R = '_HLC_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
SmgoEYJ7uyL = ['مصارعة','احدث البرامج','احدث الالعاب','احدث الاغانى']
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==80: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==81: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,text)
	elif mode==82: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==83: HkKfQCS7RIa4xi3houjvl = pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	elif mode==89: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',JJTrn6SEtYZV31eyR97,'','','','','HALACIMA-MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	pp5vX2CWHBtwOPzdq0Junij7 = d78KRnJmBWscGua0XMk(JJTrn6SEtYZV31eyR97,'url')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',89,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('main-content(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('data-name="(.*?)".*?</i>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for qzTpS3aBcFGiM,title in items:
		RRucmYBaXegTtNOdGHMQ = pp5vX2CWHBtwOPzdq0Junij7+'/ajax/getItem?item='+qzTpS3aBcFGiM+'&Ajax=1'
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,81)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"nav-main"(.*?)</nav>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title in items:
		if RRucmYBaXegTtNOdGHMQ=='#': continue
		if title in SmgoEYJ7uyL: continue
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,81)
	return
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,qzTpS3aBcFGiM=''):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		lQHXdV9Nzf6BLqS8D,BTMputsaqV = hGMVvHBuPC014(url)
		obS4TpHeV3digGC = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'POST',lQHXdV9Nzf6BLqS8D,BTMputsaqV,obS4TpHeV3digGC,'','','HALACIMA-TITLES-1st')
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		IZGcQbePXxwAoyYR1n = [QstumvzTIEUMXCcx06aD4y8nSqH]
	else:
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','HALACIMA-TITLES-2nd')
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		if qzTpS3aBcFGiM=='featured':
			IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"container"(.*?)"container"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		elif '"section-post mb-10"' in QstumvzTIEUMXCcx06aD4y8nSqH:
			IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"section-post mb-10"(.*?)"container"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		else:
			IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('<article(.*?)"pagination"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not IZGcQbePXxwAoyYR1n: return
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	if not items:
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if not items: items = ZXFs0mEPR8qI2zj.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	FF1TYf6O5KENr8R72LUVievClmudxD = []
	QK2N8Bn0lLVdsURIgufJ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for RRucmYBaXegTtNOdGHMQ,title,CrGO63LT7j2UxniW in items:
		RRucmYBaXegTtNOdGHMQ = ejBOu2WXwvb4YpITdsLF16(RRucmYBaXegTtNOdGHMQ).strip('/')
		LqYKJ36CBG = ZXFs0mEPR8qI2zj.findall('(.*?) الحلقة \d+',title,ZXFs0mEPR8qI2zj.DOTALL)
		if '/series/' in RRucmYBaXegTtNOdGHMQ:
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,83,CrGO63LT7j2UxniW)
		elif 'سلاسل' not in url and any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in QK2N8Bn0lLVdsURIgufJ):
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,82,CrGO63LT7j2UxniW)
		elif LqYKJ36CBG and 'الحلقة' in title:
			title = '_MOD_' + LqYKJ36CBG[0]
			if title not in FF1TYf6O5KENr8R72LUVievClmudxD:
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,83,CrGO63LT7j2UxniW)
				FF1TYf6O5KENr8R72LUVievClmudxD.append(title)
		elif '/movies/' in RRucmYBaXegTtNOdGHMQ:
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,81,CrGO63LT7j2UxniW)
		else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,83,CrGO63LT7j2UxniW)
	if qzTpS3aBcFGiM=='':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"pagination"(.*?)<footer',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title in items:
				if RRucmYBaXegTtNOdGHMQ=="": continue
				if title!='': Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,RRucmYBaXegTtNOdGHMQ,81)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'هناك المزيد',url,81)
	return
def pqx0gStI9ojGFP2rWhwRfkVCNX(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','HALACIMA-EPISODES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	Wgapb9wyGrVHo0 = ZXFs0mEPR8qI2zj.findall('"getSeasonsBySeries(.*?)"container"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	CCqaV18lM0OL = ZXFs0mEPR8qI2zj.findall('"list-episodes"(.*?)"container"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if Wgapb9wyGrVHo0 and '/series/' not in url:
		bdq4e6Wr2gslnSiA38 = Wgapb9wyGrVHo0[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title,CrGO63LT7j2UxniW in items:
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,83,CrGO63LT7j2UxniW)
	elif CCqaV18lM0OL:
		CrGO63LT7j2UxniW = ZXFs0mEPR8qI2zj.findall('"image" src="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		CrGO63LT7j2UxniW = CrGO63LT7j2UxniW[0]
		bdq4e6Wr2gslnSiA38 = CCqaV18lM0OL[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)" title="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,82,CrGO63LT7j2UxniW)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	lQHXdV9Nzf6BLqS8D = url.replace('/movies/','/watch_movies/')
	lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D.replace('/episodes/','/watch_episodes/')
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',lQHXdV9Nzf6BLqS8D,'','','','','HALACIMA-PLAY-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	pp5vX2CWHBtwOPzdq0Junij7 = d78KRnJmBWscGua0XMk(lQHXdV9Nzf6BLqS8D,'url')
	YYmyQXglbEewzL3IA2Sd = []
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"servers"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		mnt96JHiPpI = ZXFs0mEPR8qI2zj.findall('postID = "(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		mnt96JHiPpI = mnt96JHiPpI[0]
		items = ZXFs0mEPR8qI2zj.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for NGmuWwXdLQ6nMltx39FYECohJ,title in items:
			title = title.replace('\n','').strip(' ')
			RRucmYBaXegTtNOdGHMQ = pp5vX2CWHBtwOPzdq0Junij7+'/ajax/getPlayer?server='+NGmuWwXdLQ6nMltx39FYECohJ+'&postID='+mnt96JHiPpI+'&Ajax=1'
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+title+'__watch'
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"downs"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)" title="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,name in items:
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+name+'__download'
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(YYmyQXglbEewzL3IA2Sd,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	search = search.replace(' ','-')
	url = JJTrn6SEtYZV31eyR97+'/search/'+search+'.html'
	RxAy5lEFQ1chv0BrdU4p6Pt2(url)
	return
# -*- coding: utf-8 -*-
from j3x780FpaM import *
LBtjHDg8yZz69QOp = 'M3U'
oYkzVLIgyjNpsiTbZSBQ = '_M3U_'
FJLMxd8alBC7QbDKU9Onu2fw = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
t7HERlKxBJpPfILviq9Y2Ge3d = 4
def EXgQe7mIMsxD8kcOZ(nnPsf4XLIJ7RWF,gC2hO80boRyM7TBGqD,uHGMxiZfcoErOyXghvnWUK,RGDQbxHAi1UpIuNveqTFXSw9gZjc4,NznapDvCteQPx,WtmwkIxcKOZ3rB6PuSHCFL5vGqVo):
	global oYkzVLIgyjNpsiTbZSBQ
	try:
		fTLHoIGS2JMYV3jKh7DuW0ke = str(WtmwkIxcKOZ3rB6PuSHCFL5vGqVo['folder'])
		oYkzVLIgyjNpsiTbZSBQ = '_MU'+fTLHoIGS2JMYV3jKh7DuW0ke+'_'
	except: fTLHoIGS2JMYV3jKh7DuW0ke = ''
	try: VqryRlBf2mx8n5oYOIH6SDp4zXb3 = str(WtmwkIxcKOZ3rB6PuSHCFL5vGqVo['sequence'])
	except: VqryRlBf2mx8n5oYOIH6SDp4zXb3 = ''
	if   nnPsf4XLIJ7RWF==710: RqIMxSdNAFb7P = u0M6dB3x9cNVDpYiztshXySWfv()
	elif nnPsf4XLIJ7RWF==711: RqIMxSdNAFb7P = gmfoXnU7hlQ5qL9euC(fTLHoIGS2JMYV3jKh7DuW0ke,VqryRlBf2mx8n5oYOIH6SDp4zXb3)
	elif nnPsf4XLIJ7RWF==712: RqIMxSdNAFb7P = kV5DSBWMJ2ItamTpFd9PRNKsCGxc(fTLHoIGS2JMYV3jKh7DuW0ke)
	elif nnPsf4XLIJ7RWF==713: RqIMxSdNAFb7P = Ovdoig1sAc(fTLHoIGS2JMYV3jKh7DuW0ke,gC2hO80boRyM7TBGqD,uHGMxiZfcoErOyXghvnWUK,NznapDvCteQPx)
	elif nnPsf4XLIJ7RWF==714: RqIMxSdNAFb7P = J2K0qdYZMhG(fTLHoIGS2JMYV3jKh7DuW0ke,gC2hO80boRyM7TBGqD,uHGMxiZfcoErOyXghvnWUK,NznapDvCteQPx)
	elif nnPsf4XLIJ7RWF==715: RqIMxSdNAFb7P = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(fTLHoIGS2JMYV3jKh7DuW0ke,gC2hO80boRyM7TBGqD,RGDQbxHAi1UpIuNveqTFXSw9gZjc4)
	elif nnPsf4XLIJ7RWF==716: RqIMxSdNAFb7P = FhYAZG1ur2sQRtTX9DlOcx3WILv(fTLHoIGS2JMYV3jKh7DuW0ke,True)
	elif nnPsf4XLIJ7RWF==717: RqIMxSdNAFb7P = MQ8XEa9BOq0cp6jwsZuxYoA(fTLHoIGS2JMYV3jKh7DuW0ke,True)
	elif nnPsf4XLIJ7RWF==718: RqIMxSdNAFb7P = saV3z5bE1LJF0moyeYikrnjgIH(fTLHoIGS2JMYV3jKh7DuW0ke,gC2hO80boRyM7TBGqD,uHGMxiZfcoErOyXghvnWUK)
	elif nnPsf4XLIJ7RWF==719: RqIMxSdNAFb7P = ZQTkpw4se6EOaIrgNLn(uHGMxiZfcoErOyXghvnWUK,fTLHoIGS2JMYV3jKh7DuW0ke,gC2hO80boRyM7TBGqD,NznapDvCteQPx)
	elif nnPsf4XLIJ7RWF==720: RqIMxSdNAFb7P = rUedtQkCXJq(fTLHoIGS2JMYV3jKh7DuW0ke,True)
	elif nnPsf4XLIJ7RWF==721: RqIMxSdNAFb7P = opD4a2icuhtnm9l6fMQqFbTv(fTLHoIGS2JMYV3jKh7DuW0ke)
	elif nnPsf4XLIJ7RWF==722: RqIMxSdNAFb7P = UMPvFx2RpQTh3LfNYlqSyZz(fTLHoIGS2JMYV3jKh7DuW0ke)
	elif nnPsf4XLIJ7RWF==723: RqIMxSdNAFb7P = MQ0WAOIYobmyxS6akuziJG(fTLHoIGS2JMYV3jKh7DuW0ke)
	elif nnPsf4XLIJ7RWF==726: RqIMxSdNAFb7P = sYyPU0CzeIgLmG7pjBq4uDJO(fTLHoIGS2JMYV3jKh7DuW0ke)
	elif nnPsf4XLIJ7RWF==729: RqIMxSdNAFb7P = NBoCjHK6ITwgY5OxeuALPlZ(uHGMxiZfcoErOyXghvnWUK,fTLHoIGS2JMYV3jKh7DuW0ke,gC2hO80boRyM7TBGqD,NznapDvCteQPx)
	else: RqIMxSdNAFb7P = False
	return RqIMxSdNAFb7P
def u0M6dB3x9cNVDpYiztshXySWfv():
	for fTLHoIGS2JMYV3jKh7DuW0ke in range(1,SS2ZAHCRpu8QxIao7BMq+1):
		oYkzVLIgyjNpsiTbZSBQ = '_MU'+str(fTLHoIGS2JMYV3jKh7DuW0ke)+'_'
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'قائمة مجلد '+KnGrOQsDgfB8Raj9C2AZJuYcTxP[fTLHoIGS2JMYV3jKh7DuW0ke],'',720,'','','','',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
	return
def rUedtQkCXJq(fTLHoIGS2JMYV3jKh7DuW0ke='',CaiGWx9HlMhRznyFDm1=''):
	if fTLHoIGS2JMYV3jKh7DuW0ke:
		TTaZ1xuBDtY6ldoyr3kE85QWUjb = {'folder':fTLHoIGS2JMYV3jKh7DuW0ke}
		r0djYXtTGD6HhniSkCp = ''
	else:
		TTaZ1xuBDtY6ldoyr3kE85QWUjb = ''
		r0djYXtTGD6HhniSkCp = ''
	JYEjR3wTduF = KHWOFrzptwybYx(fTLHoIGS2JMYV3jKh7DuW0ke,CaiGWx9HlMhRznyFDm1)
	if not JYEjR3wTduF:
		Tca7NsYPkIRWtBpFgxLZbSmCi('link',oYkzVLIgyjNpsiTbZSBQ+'[COLOR FFFFFF00] إضافة وتغيير رابط'+r0djYXtTGD6HhniSkCp+' '+KnGrOQsDgfB8Raj9C2AZJuYcTxP[1]+' [/COLOR]','',711,'','','','',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke,'sequence':1})
		Tca7NsYPkIRWtBpFgxLZbSmCi('link',oYkzVLIgyjNpsiTbZSBQ+'[COLOR FFFFFF00] جلب ملفات'+r0djYXtTGD6HhniSkCp+' [/COLOR]','',712,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	else:
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'بحث في الملفات'+r0djYXtTGD6HhniSkCp,'',729,'','','_REMEMBERRESULTS_','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'قنوات مصنفة مرتبة'+r0djYXtTGD6HhniSkCp,'LIVE_GROUPED_SORTED',713,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'قنوات مصنفة من القسم'+r0djYXtTGD6HhniSkCp,'LIVE_FROM_GROUP_SORTED',713,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'قنوات مصنفة من الاسم'+r0djYXtTGD6HhniSkCp,'LIVE_FROM_NAME_SORTED',713,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'قنوات مصنفة بلا ترتيب'+r0djYXtTGD6HhniSkCp,'LIVE_GROUPED',713,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'قنوات بلا ترتيب'+r0djYXtTGD6HhniSkCp,'LIVE_ORIGINAL_GROUPED',713,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'قنوات مجهولة مرتبة'+r0djYXtTGD6HhniSkCp,'LIVE_UNKNOWN_GROUPED_SORTED',713,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'قنوات مجهولة بلا ترتيب'+r0djYXtTGD6HhniSkCp,'LIVE_UNKNOWN_GROUPED',713,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'فيديوهات بلا ترتيب'+r0djYXtTGD6HhniSkCp,'VOD_ORIGINAL_GROUPED',713,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'فيديوهات مصنفة القسم'+r0djYXtTGD6HhniSkCp,'VOD_FROM_GROUP_SORTED',713,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'فيديوهات مصنفة من الاسم'+r0djYXtTGD6HhniSkCp,'VOD_FROM_NAME_SORTED',713,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'فيديوهات مجهولة بلا ترتيب'+r0djYXtTGD6HhniSkCp,'VOD_UNKNOWN_GROUPED',713,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'فيديوهات مجهولة مرتبة'+r0djYXtTGD6HhniSkCp,'VOD_UNKNOWN_GROUPED_SORTED',713,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for hcVjpT7mOqX in range(1,t7HERlKxBJpPfILviq9Y2Ge3d+1):
		Tca7NsYPkIRWtBpFgxLZbSmCi('link',oYkzVLIgyjNpsiTbZSBQ+'إضافة وتغيير رابط'+r0djYXtTGD6HhniSkCp+' '+KnGrOQsDgfB8Raj9C2AZJuYcTxP[hcVjpT7mOqX],'',711,'','','','',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke,'sequence':hcVjpT7mOqX})
	Tca7NsYPkIRWtBpFgxLZbSmCi('link',oYkzVLIgyjNpsiTbZSBQ+'جلب ملفات'+r0djYXtTGD6HhniSkCp,'',712,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link',oYkzVLIgyjNpsiTbZSBQ+'مسح ملفات'+r0djYXtTGD6HhniSkCp,'',717,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link',oYkzVLIgyjNpsiTbZSBQ+'عدد فيديوهات'+r0djYXtTGD6HhniSkCp,'',721,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link',oYkzVLIgyjNpsiTbZSBQ+'Referer تغيير'+r0djYXtTGD6HhniSkCp,'',726,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link',oYkzVLIgyjNpsiTbZSBQ+'User-Agent تغيير'+r0djYXtTGD6HhniSkCp,'',723,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
	return
def FhYAZG1ur2sQRtTX9DlOcx3WILv(fTLHoIGS2JMYV3jKh7DuW0ke,CaiGWx9HlMhRznyFDm1=True):
	D7OijMIzyKWUTpQF1ECnZJcqBRxed,FdjY1QbmG6y = False,''
	VzPym8fW6lKD1bpeZGnRCBs,MnAvyj3DZthLSIo = '',''
	LLmOgfvERFwWp9DQMoBHS36rd,fUSnuQTRBwOtFhZz36k9y,lBeGVXTt0qD,v1IzDVTBhweb3tRr6YCyoNK,LX35qsjfcIWaDT8S462 = gmcELYbTJS(fTLHoIGS2JMYV3jKh7DuW0ke)
	if v1IzDVTBhweb3tRr6YCyoNK=='': return False,'',''
	Mm7XCRohg3iUSfJKdWsIqx = poTRFiyNCYwsO8dhMBHZ2lAIvL1(fTLHoIGS2JMYV3jKh7DuW0ke)
	if LLmOgfvERFwWp9DQMoBHS36rd:
		Ba3qhge51Hynsz8mcoW = A6F71g3cqN4(KxirmCLT6Gw,'GET',LLmOgfvERFwWp9DQMoBHS36rd,'',Mm7XCRohg3iUSfJKdWsIqx,False,'','M3U-CHECK_ACCOUNT-1st')
		BRufE2IykDCOaNAv9iU = Ba3qhge51Hynsz8mcoW.content
		if Ba3qhge51Hynsz8mcoW.succeeded:
			T1TmhxAtY5qeJ28ywXBL,kb3SMugt0LQCmD2dwFHRapPNI4,c6coXJrbRVSiEQG4tDxkM1d5uz,DeSVN9RM7W,bVRiuYAeDM9NnSfxdHI = 0,0,'','',''
			try:
				JxuZ9wqO1Fbm6sQNU5raoA8PjW = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('dict',BRufE2IykDCOaNAv9iU)
				FdjY1QbmG6y = JxuZ9wqO1Fbm6sQNU5raoA8PjW['user_info']['status']
				D7OijMIzyKWUTpQF1ECnZJcqBRxed = True
				c6coXJrbRVSiEQG4tDxkM1d5uz = JxuZ9wqO1Fbm6sQNU5raoA8PjW['server_info']['time_now']
			except: pass
			if c6coXJrbRVSiEQG4tDxkM1d5uz:
				try:
					nHbv7QFEXlKGotj4BAeLdYJ = luMHeSgCBaPrb9KvUjNFqcR.strptime(c6coXJrbRVSiEQG4tDxkM1d5uz,'%Y.%m.%d %H:%M:%S')
					T1TmhxAtY5qeJ28ywXBL = int(luMHeSgCBaPrb9KvUjNFqcR.mktime(nHbv7QFEXlKGotj4BAeLdYJ))
					kb3SMugt0LQCmD2dwFHRapPNI4 = int(F5I1VZzxkXenKuEAYO-T1TmhxAtY5qeJ28ywXBL)
					kb3SMugt0LQCmD2dwFHRapPNI4 = int((kb3SMugt0LQCmD2dwFHRapPNI4+900)/1800)*1800
				except: pass
				try:
					nHbv7QFEXlKGotj4BAeLdYJ = luMHeSgCBaPrb9KvUjNFqcR.localtime(int(JxuZ9wqO1Fbm6sQNU5raoA8PjW['user_info']['created_at']))
					DeSVN9RM7W = luMHeSgCBaPrb9KvUjNFqcR.strftime('%Y.%m.%d %H:%M:%S',nHbv7QFEXlKGotj4BAeLdYJ)
				except: pass
				try:
					nHbv7QFEXlKGotj4BAeLdYJ = luMHeSgCBaPrb9KvUjNFqcR.localtime(int(JxuZ9wqO1Fbm6sQNU5raoA8PjW['user_info']['exp_date']))
					bVRiuYAeDM9NnSfxdHI = luMHeSgCBaPrb9KvUjNFqcR.strftime('%Y.%m.%d %H:%M:%S',nHbv7QFEXlKGotj4BAeLdYJ)
				except: pass
			j2agIU0xsLS6c7T.setSetting('av.m3u.timestamp_'+fTLHoIGS2JMYV3jKh7DuW0ke,str(F5I1VZzxkXenKuEAYO))
			j2agIU0xsLS6c7T.setSetting('av.m3u.timediff_'+fTLHoIGS2JMYV3jKh7DuW0ke,str(kb3SMugt0LQCmD2dwFHRapPNI4))
			try:
				JgsehvZt1BlxyQF = '"server_info":'+BRufE2IykDCOaNAv9iU.split('"server_info":')[1]
				JgsehvZt1BlxyQF = JgsehvZt1BlxyQF.replace(':',': ').replace(',',', ').replace('}}','}')
				WWeS01piHaDk2EhtyIqYVncXPBCRf = ZXFs0mEPR8qI2zj.findall('"url": "(.*?)", "port": "(.*?)"',JgsehvZt1BlxyQF,ZXFs0mEPR8qI2zj.DOTALL)
				VzPym8fW6lKD1bpeZGnRCBs,MnAvyj3DZthLSIo = WWeS01piHaDk2EhtyIqYVncXPBCRf[0]
			except: D7OijMIzyKWUTpQF1ECnZJcqBRxed = False
			if D7OijMIzyKWUTpQF1ECnZJcqBRxed and CaiGWx9HlMhRznyFDm1:
				max = JxuZ9wqO1Fbm6sQNU5raoA8PjW['user_info']['max_connections']
				KF4o6hpsOVix0Ljd9 = JxuZ9wqO1Fbm6sQNU5raoA8PjW['user_info']['active_cons']
				g1MNEeO6riAypnm8qQ4tYxW = JxuZ9wqO1Fbm6sQNU5raoA8PjW['user_info']['is_trial']
				RkXi8unALUVC5 = LLmOgfvERFwWp9DQMoBHS36rd.split('?',1)
				LaX1QCyeIJ = 'URL:  [COLOR FFC89008]'+LLmOgfvERFwWp9DQMoBHS36rd+'[/COLOR]'
				LaX1QCyeIJ += '\n\nStatus:  '+'[COLOR FFC89008]'+FdjY1QbmG6y+'[/COLOR]'
				LaX1QCyeIJ += '\nTrial:    '+'[COLOR FFC89008]'+str(g1MNEeO6riAypnm8qQ4tYxW=='1')+'[/COLOR]'
				LaX1QCyeIJ += '\nCreated  At:  '+'[COLOR FFC89008]'+DeSVN9RM7W+'[/COLOR]'
				LaX1QCyeIJ += '\nExpiry Date:  '+'[COLOR FFC89008]'+bVRiuYAeDM9NnSfxdHI+'[/COLOR]'
				LaX1QCyeIJ += '\nConnections   ( Active / Maximum ) :  '+'[COLOR FFC89008]'+KF4o6hpsOVix0Ljd9+' / '+max+'[/COLOR]'
				LaX1QCyeIJ += '\nAllowed Outputs:   '+'[COLOR FFC89008]'+" , ".join(JxuZ9wqO1Fbm6sQNU5raoA8PjW['user_info']['allowed_output_formats'])+'[/COLOR]'
				LaX1QCyeIJ += '\n\n'+JgsehvZt1BlxyQF
				if FdjY1QbmG6y=='Active': JATO6o8EHKZLIsaQV('الاشتراك يعمل بدون مشاكل',LaX1QCyeIJ)
				else: JATO6o8EHKZLIsaQV('يبدو أن هناك مشكلة في الاشتراك',LaX1QCyeIJ)
	if LLmOgfvERFwWp9DQMoBHS36rd and D7OijMIzyKWUTpQF1ECnZJcqBRxed and FdjY1QbmG6y=='Active':
		tr24ZoudmqvxfYCw('NOTICE','.  Checking M3U URL   [ M3U account is OK ]   [ '+LLmOgfvERFwWp9DQMoBHS36rd+' ]')
		Q4o2IDnNJzcYe = True
	else:
		tr24ZoudmqvxfYCw('ERROR_LINES','Checking M3U URL   [ Does not work ]   [ '+LLmOgfvERFwWp9DQMoBHS36rd+' ]')
		if CaiGWx9HlMhRznyFDm1: HHTzVhiY079bvdluNkFQ4wCMpe('','','فحص اشتراك ـM3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		Q4o2IDnNJzcYe = False
	return Q4o2IDnNJzcYe,VzPym8fW6lKD1bpeZGnRCBs,MnAvyj3DZthLSIo
def J2K0qdYZMhG(fTLHoIGS2JMYV3jKh7DuW0ke,dMu4F8L5Azo6IJ2aleywBmb,kUxyZMQ2Svz9A4JNBYtHn5sbDRr,uVGD6ZCHboELna3i7hKM4YPNS,CaiGWx9HlMhRznyFDm1=True):
	if not uVGD6ZCHboELna3i7hKM4YPNS: uVGD6ZCHboELna3i7hKM4YPNS = '1'
	if not KHWOFrzptwybYx(fTLHoIGS2JMYV3jKh7DuW0ke,CaiGWx9HlMhRznyFDm1): return
	sEyDZTBxj9l = cHa5JRAQ3ZKku7(fTLHoIGS2JMYV3jKh7DuW0ke,dMu4F8L5Azo6IJ2aleywBmb)
	bb2Wi1TrnXpSA4wgfszMvcxd0O3mL = NUauTXxKLAoqQtJkglSFRWE(sEyDZTBxj9l,'list',dMu4F8L5Azo6IJ2aleywBmb,kUxyZMQ2Svz9A4JNBYtHn5sbDRr)
	PZg0OBKQyfwR3uFp = int(uVGD6ZCHboELna3i7hKM4YPNS)*100
	qzWuPiXcUV3I7D1jGB2R = PZg0OBKQyfwR3uFp-100
	for dGlmU8JqW5yFAtcsg,yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0 in bb2Wi1TrnXpSA4wgfszMvcxd0O3mL[qzWuPiXcUV3I7D1jGB2R:PZg0OBKQyfwR3uFp]:
		wjNixHdgWLyZS59I = ('GROUPED' in dMu4F8L5Azo6IJ2aleywBmb or dMu4F8L5Azo6IJ2aleywBmb=='ALL')
		p2pHPMV4sadmf8qJBOZb0 = ('GROUPED' not in dMu4F8L5Azo6IJ2aleywBmb and dMu4F8L5Azo6IJ2aleywBmb!='ALL')
		if wjNixHdgWLyZS59I or p2pHPMV4sadmf8qJBOZb0:
			if   'ARCHIVED'  in dMu4F8L5Azo6IJ2aleywBmb: OWasmQ27g3Dbljpo.append(['folder',oYkzVLIgyjNpsiTbZSBQ+yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,718,EoMKR2biY0,'','ARCHIVED','',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke}])
			elif 'EPG' 		 in dMu4F8L5Azo6IJ2aleywBmb: OWasmQ27g3Dbljpo.append(['folder',oYkzVLIgyjNpsiTbZSBQ+yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,718,EoMKR2biY0,'','FULL_EPG','',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke}])
			elif 'TIMESHIFT' in dMu4F8L5Azo6IJ2aleywBmb: OWasmQ27g3Dbljpo.append(['folder',oYkzVLIgyjNpsiTbZSBQ+yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,718,EoMKR2biY0,'','TIMESHIFT','',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke}])
			elif 'LIVE' 	 in dMu4F8L5Azo6IJ2aleywBmb: OWasmQ27g3Dbljpo.append(['live',oYkzVLIgyjNpsiTbZSBQ+yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,715,EoMKR2biY0,'','',dGlmU8JqW5yFAtcsg,{'folder':fTLHoIGS2JMYV3jKh7DuW0ke}])
			else: OWasmQ27g3Dbljpo.append(['video',oYkzVLIgyjNpsiTbZSBQ+yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,715,EoMKR2biY0,'','','',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke}])
	Nkx1U6BAd2ClyzDqW0noOPj3h = len(bb2Wi1TrnXpSA4wgfszMvcxd0O3mL)
	dlU0EksuLjrBaq(fTLHoIGS2JMYV3jKh7DuW0ke,uVGD6ZCHboELna3i7hKM4YPNS,dMu4F8L5Azo6IJ2aleywBmb,714,Nkx1U6BAd2ClyzDqW0noOPj3h,kUxyZMQ2Svz9A4JNBYtHn5sbDRr)
	return
def nFVKo4raOPWfjIJ1LDRh2d3g(na6F4zgxAjdZ):
	Tca7NsYPkIRWtBpFgxLZbSmCi('link',na6F4zgxAjdZ+'هذه القائمة إما فارغة أو غير موجودة','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link',na6F4zgxAjdZ+'أو الخدمة غير موجودة في اشتراكك','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link',na6F4zgxAjdZ+'أو رابط M3U الذي أنت أضفته غير صحيح','',9999)
	return
def Ovdoig1sAc(fTLHoIGS2JMYV3jKh7DuW0ke,dMu4F8L5Azo6IJ2aleywBmb,kUxyZMQ2Svz9A4JNBYtHn5sbDRr,uVGD6ZCHboELna3i7hKM4YPNS,qh15WZ4Gdcbv='',CaiGWx9HlMhRznyFDm1=True):
	if not uVGD6ZCHboELna3i7hKM4YPNS: uVGD6ZCHboELna3i7hKM4YPNS = '1'
	na6F4zgxAjdZ = oYkzVLIgyjNpsiTbZSBQ
	if not KHWOFrzptwybYx(fTLHoIGS2JMYV3jKh7DuW0ke,CaiGWx9HlMhRznyFDm1): return False
	if '__SERIES__' in kUxyZMQ2Svz9A4JNBYtHn5sbDRr: Tf1EBxvRyIzcNk,coXV1en2GfJPYKsLT8MECx0 = kUxyZMQ2Svz9A4JNBYtHn5sbDRr.split('__SERIES__')
	else: Tf1EBxvRyIzcNk,coXV1en2GfJPYKsLT8MECx0 = kUxyZMQ2Svz9A4JNBYtHn5sbDRr,''
	sEyDZTBxj9l = cHa5JRAQ3ZKku7(fTLHoIGS2JMYV3jKh7DuW0ke,dMu4F8L5Azo6IJ2aleywBmb)
	O5YIZ7asToB1lfpeVrRE4bW = NUauTXxKLAoqQtJkglSFRWE(sEyDZTBxj9l,'list',dMu4F8L5Azo6IJ2aleywBmb,'__GROUPS__')
	if not O5YIZ7asToB1lfpeVrRE4bW: return False
	uQkZILtf5X6Kp = []
	for aBXgWuYGwdyS8k0jF4efM5QOcDL,EoMKR2biY0 in O5YIZ7asToB1lfpeVrRE4bW:
		if '===== ===== =====' in aBXgWuYGwdyS8k0jF4efM5QOcDL:
			Tca7NsYPkIRWtBpFgxLZbSmCi('link',na6F4zgxAjdZ+aBXgWuYGwdyS8k0jF4efM5QOcDL,'',9999)
			Tca7NsYPkIRWtBpFgxLZbSmCi('link',na6F4zgxAjdZ+aBXgWuYGwdyS8k0jF4efM5QOcDL,'',9999)
			continue
		if qh15WZ4Gdcbv:
			if '__SERIES__' in aBXgWuYGwdyS8k0jF4efM5QOcDL: na6F4zgxAjdZ = 'SERIES'
			elif '!!__UNKNOWN__!!' in aBXgWuYGwdyS8k0jF4efM5QOcDL: na6F4zgxAjdZ = 'UNKNOWN'
			elif 'LIVE' in dMu4F8L5Azo6IJ2aleywBmb: na6F4zgxAjdZ = 'LIVE'
			else: na6F4zgxAjdZ = 'VIDEOS'
			na6F4zgxAjdZ = ',[COLOR FFC89008]'+na6F4zgxAjdZ+': [/COLOR]'
		if '__SERIES__' in aBXgWuYGwdyS8k0jF4efM5QOcDL: Tu82Ar7n6YRQmGw1xze95jdKXy,O8o4wEI93GfiX7qCyKbe0BUF2 = aBXgWuYGwdyS8k0jF4efM5QOcDL.split('__SERIES__')
		else: Tu82Ar7n6YRQmGw1xze95jdKXy,O8o4wEI93GfiX7qCyKbe0BUF2 = aBXgWuYGwdyS8k0jF4efM5QOcDL,''
		if not kUxyZMQ2Svz9A4JNBYtHn5sbDRr:
			if Tu82Ar7n6YRQmGw1xze95jdKXy in uQkZILtf5X6Kp: continue
			uQkZILtf5X6Kp.append(Tu82Ar7n6YRQmGw1xze95jdKXy)
			if 'RANDOM' in qh15WZ4Gdcbv: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',na6F4zgxAjdZ+Tu82Ar7n6YRQmGw1xze95jdKXy,dMu4F8L5Azo6IJ2aleywBmb,168,'','1',aBXgWuYGwdyS8k0jF4efM5QOcDL,'',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
			elif '__SERIES__' in aBXgWuYGwdyS8k0jF4efM5QOcDL: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',na6F4zgxAjdZ+Tu82Ar7n6YRQmGw1xze95jdKXy,dMu4F8L5Azo6IJ2aleywBmb,713,'','1',aBXgWuYGwdyS8k0jF4efM5QOcDL,'',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',na6F4zgxAjdZ+Tu82Ar7n6YRQmGw1xze95jdKXy,dMu4F8L5Azo6IJ2aleywBmb,714,'','1',aBXgWuYGwdyS8k0jF4efM5QOcDL,'',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
		elif '__SERIES__' in aBXgWuYGwdyS8k0jF4efM5QOcDL and Tu82Ar7n6YRQmGw1xze95jdKXy==Tf1EBxvRyIzcNk:
			if O8o4wEI93GfiX7qCyKbe0BUF2 in uQkZILtf5X6Kp: continue
			uQkZILtf5X6Kp.append(O8o4wEI93GfiX7qCyKbe0BUF2)
			if 'RANDOM' in qh15WZ4Gdcbv: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',na6F4zgxAjdZ+O8o4wEI93GfiX7qCyKbe0BUF2,dMu4F8L5Azo6IJ2aleywBmb,168,'','1',aBXgWuYGwdyS8k0jF4efM5QOcDL,'',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',na6F4zgxAjdZ+O8o4wEI93GfiX7qCyKbe0BUF2,dMu4F8L5Azo6IJ2aleywBmb,714,EoMKR2biY0,'1',aBXgWuYGwdyS8k0jF4efM5QOcDL,'',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
	OWasmQ27g3Dbljpo[:] = sorted(OWasmQ27g3Dbljpo,reverse=False,key=lambda JDv1uYxBEPcFGwrmlfzSOC: JDv1uYxBEPcFGwrmlfzSOC[1].lower())
	if not qh15WZ4Gdcbv:
		PZg0OBKQyfwR3uFp = int(uVGD6ZCHboELna3i7hKM4YPNS)*100
		qzWuPiXcUV3I7D1jGB2R = PZg0OBKQyfwR3uFp-100
		Nkx1U6BAd2ClyzDqW0noOPj3h = len(OWasmQ27g3Dbljpo)
		OWasmQ27g3Dbljpo[:] = OWasmQ27g3Dbljpo[qzWuPiXcUV3I7D1jGB2R:PZg0OBKQyfwR3uFp]
		dlU0EksuLjrBaq(fTLHoIGS2JMYV3jKh7DuW0ke,uVGD6ZCHboELna3i7hKM4YPNS,dMu4F8L5Azo6IJ2aleywBmb,713,Nkx1U6BAd2ClyzDqW0noOPj3h,kUxyZMQ2Svz9A4JNBYtHn5sbDRr)
	return True
def saV3z5bE1LJF0moyeYikrnjgIH(fTLHoIGS2JMYV3jKh7DuW0ke,gC2hO80boRyM7TBGqD,ItpjaAnZOhUEluJQiMm9zGo2v8Dw):
	if not KHWOFrzptwybYx(fTLHoIGS2JMYV3jKh7DuW0ke,True): return
	Mm7XCRohg3iUSfJKdWsIqx = poTRFiyNCYwsO8dhMBHZ2lAIvL1(fTLHoIGS2JMYV3jKh7DuW0ke)
	T1TmhxAtY5qeJ28ywXBL = j2agIU0xsLS6c7T.getSetting('av.m3u.timestamp_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	if not T1TmhxAtY5qeJ28ywXBL or F5I1VZzxkXenKuEAYO-int(T1TmhxAtY5qeJ28ywXBL)>24*sGOne0xWA5:
		Q4o2IDnNJzcYe,VzPym8fW6lKD1bpeZGnRCBs,MnAvyj3DZthLSIo = FhYAZG1ur2sQRtTX9DlOcx3WILv(fTLHoIGS2JMYV3jKh7DuW0ke,False)
		if not Q4o2IDnNJzcYe: return
	kb3SMugt0LQCmD2dwFHRapPNI4 = int(j2agIU0xsLS6c7T.getSetting('av.m3u.timediff_'+fTLHoIGS2JMYV3jKh7DuW0ke))
	lBeGVXTt0qD = j2agIU0xsLS6c7T.getSetting('av.m3u.server_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	v1IzDVTBhweb3tRr6YCyoNK = j2agIU0xsLS6c7T.getSetting('av.m3u.username_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	LX35qsjfcIWaDT8S462 = j2agIU0xsLS6c7T.getSetting('av.m3u.password_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	UGWsYP1KNJHfr5I9O36AEC7oTljLt = gC2hO80boRyM7TBGqD.split('/')
	jsINZ1EbOvtS7o0 = UGWsYP1KNJHfr5I9O36AEC7oTljLt[-1].replace('.ts','').replace('.m3u8','')
	if ItpjaAnZOhUEluJQiMm9zGo2v8Dw=='SHORT_EPG': cYPzbseokvViBH4a8lO2p = 'get_short_epg'
	else: cYPzbseokvViBH4a8lO2p = 'get_simple_data_table'
	LLmOgfvERFwWp9DQMoBHS36rd,fUSnuQTRBwOtFhZz36k9y,lBeGVXTt0qD,v1IzDVTBhweb3tRr6YCyoNK,LX35qsjfcIWaDT8S462 = gmcELYbTJS(fTLHoIGS2JMYV3jKh7DuW0ke)
	if not v1IzDVTBhweb3tRr6YCyoNK: return
	AR5qiolctwvpLKXsSh6nVx = LLmOgfvERFwWp9DQMoBHS36rd+'&action='+cYPzbseokvViBH4a8lO2p+'&stream_id='+jsINZ1EbOvtS7o0
	BRufE2IykDCOaNAv9iU = WHFUa0fegZpJshClji9KzRVDoA8Xrt(KxirmCLT6Gw,AR5qiolctwvpLKXsSh6nVx,'',Mm7XCRohg3iUSfJKdWsIqx,'','M3U-EPG_ITEMS-2nd')
	i54QjcV2tWB0d = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('dict',BRufE2IykDCOaNAv9iU)
	ZfTwrusDx3UeXqbtCla = i54QjcV2tWB0d['epg_listings']
	niJKWcmRgwo7D8012bx36IO = []
	if ItpjaAnZOhUEluJQiMm9zGo2v8Dw in ['ARCHIVED','TIMESHIFT']:
		for JxuZ9wqO1Fbm6sQNU5raoA8PjW in ZfTwrusDx3UeXqbtCla:
			if JxuZ9wqO1Fbm6sQNU5raoA8PjW['has_archive']==1:
				niJKWcmRgwo7D8012bx36IO.append(JxuZ9wqO1Fbm6sQNU5raoA8PjW)
				if ItpjaAnZOhUEluJQiMm9zGo2v8Dw in ['TIMESHIFT']: break
		if not niJKWcmRgwo7D8012bx36IO: return
		Tca7NsYPkIRWtBpFgxLZbSmCi('link',oYkzVLIgyjNpsiTbZSBQ+'[COLOR FFC89008]الملفات الأولي بهذه القائمة قد لا تعمل[/COLOR]','',9999)
		if ItpjaAnZOhUEluJQiMm9zGo2v8Dw in ['TIMESHIFT']:
			Mmp2hxGFv1Lo5Jb = 2
			w8lmdARKWLovTMPjrC = Mmp2hxGFv1Lo5Jb*sGOne0xWA5
			niJKWcmRgwo7D8012bx36IO = []
			rhTsY3DS9bojgKOz = int(int(JxuZ9wqO1Fbm6sQNU5raoA8PjW['start_timestamp'])/w8lmdARKWLovTMPjrC)*w8lmdARKWLovTMPjrC
			St9hoc5FMNfDOvEI6A7QamsJVWwBz = F5I1VZzxkXenKuEAYO+w8lmdARKWLovTMPjrC
			V8kFyJt0g1hoY6zRuMQ = int((St9hoc5FMNfDOvEI6A7QamsJVWwBz-rhTsY3DS9bojgKOz)/sGOne0xWA5)
			for AiP7CnItTsZS02c4vogWrVw in range(V8kFyJt0g1hoY6zRuMQ):
				if AiP7CnItTsZS02c4vogWrVw>=6:
					if AiP7CnItTsZS02c4vogWrVw%Mmp2hxGFv1Lo5Jb!=0: continue
					nntqkTFQdC4JgeKWbvj0sORHVz = w8lmdARKWLovTMPjrC
				else: nntqkTFQdC4JgeKWbvj0sORHVz = w8lmdARKWLovTMPjrC//2
				iZfU32pPy0lA5dDrWxCEnuIk6j8HM = rhTsY3DS9bojgKOz+AiP7CnItTsZS02c4vogWrVw*sGOne0xWA5
				JxuZ9wqO1Fbm6sQNU5raoA8PjW = {}
				JxuZ9wqO1Fbm6sQNU5raoA8PjW['title'] = ''
				nHbv7QFEXlKGotj4BAeLdYJ = luMHeSgCBaPrb9KvUjNFqcR.localtime(iZfU32pPy0lA5dDrWxCEnuIk6j8HM-kb3SMugt0LQCmD2dwFHRapPNI4-sGOne0xWA5)
				JxuZ9wqO1Fbm6sQNU5raoA8PjW['start'] = luMHeSgCBaPrb9KvUjNFqcR.strftime('%Y.%m.%d %H:%M:%S',nHbv7QFEXlKGotj4BAeLdYJ)
				JxuZ9wqO1Fbm6sQNU5raoA8PjW['start_timestamp'] = str(iZfU32pPy0lA5dDrWxCEnuIk6j8HM)
				JxuZ9wqO1Fbm6sQNU5raoA8PjW['stop_timestamp'] = str(iZfU32pPy0lA5dDrWxCEnuIk6j8HM+nntqkTFQdC4JgeKWbvj0sORHVz)
				niJKWcmRgwo7D8012bx36IO.append(JxuZ9wqO1Fbm6sQNU5raoA8PjW)
	elif ItpjaAnZOhUEluJQiMm9zGo2v8Dw in ['SHORT_EPG','FULL_EPG']: niJKWcmRgwo7D8012bx36IO = ZfTwrusDx3UeXqbtCla
	if ItpjaAnZOhUEluJQiMm9zGo2v8Dw=='FULL_EPG' and len(niJKWcmRgwo7D8012bx36IO)>0:
		Tca7NsYPkIRWtBpFgxLZbSmCi('link',oYkzVLIgyjNpsiTbZSBQ+'[COLOR FFC89008]هذه قائمة برامج القنوات (جدول فقط)ـ[/COLOR]','',9999)
	ttCaYMOIjP = []
	EoMKR2biY0 = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.getInfoLabel('ListItem.Icon')
	for JxuZ9wqO1Fbm6sQNU5raoA8PjW in niJKWcmRgwo7D8012bx36IO:
		yHAD9oVfdieMNhC = EGTVgQoSu6ZsD.b64decode(JxuZ9wqO1Fbm6sQNU5raoA8PjW['title'])
		if VYMZsxRpcQHPgkaiDKjyoh: yHAD9oVfdieMNhC = yHAD9oVfdieMNhC.decode('utf8')
		iZfU32pPy0lA5dDrWxCEnuIk6j8HM = int(JxuZ9wqO1Fbm6sQNU5raoA8PjW['start_timestamp'])
		aalDH3jwJQ9cT0goYz4 = int(JxuZ9wqO1Fbm6sQNU5raoA8PjW['stop_timestamp'])
		KgpWFY29JRedEjiOfHaUGn = str(int((aalDH3jwJQ9cT0goYz4-iZfU32pPy0lA5dDrWxCEnuIk6j8HM+59)/60))
		ud6Pjcnt2MxWEQ7Z5ySpimI = JxuZ9wqO1Fbm6sQNU5raoA8PjW['start'].replace(' ',':')
		nHbv7QFEXlKGotj4BAeLdYJ = luMHeSgCBaPrb9KvUjNFqcR.localtime(iZfU32pPy0lA5dDrWxCEnuIk6j8HM-sGOne0xWA5)
		PYEiUvRX1D7O2hzCKIcHjqxgS3edpN = luMHeSgCBaPrb9KvUjNFqcR.strftime('%H:%M',nHbv7QFEXlKGotj4BAeLdYJ)
		gxV1zLTsPYfd7eOXi596k = luMHeSgCBaPrb9KvUjNFqcR.strftime('%a',nHbv7QFEXlKGotj4BAeLdYJ)
		if ItpjaAnZOhUEluJQiMm9zGo2v8Dw=='SHORT_EPG': yHAD9oVfdieMNhC = '[COLOR FFFFFF00]'+PYEiUvRX1D7O2hzCKIcHjqxgS3edpN+' ـ '+yHAD9oVfdieMNhC+'[/COLOR]'
		elif ItpjaAnZOhUEluJQiMm9zGo2v8Dw=='TIMESHIFT': yHAD9oVfdieMNhC = gxV1zLTsPYfd7eOXi596k+' '+PYEiUvRX1D7O2hzCKIcHjqxgS3edpN+' ('+KgpWFY29JRedEjiOfHaUGn+'min)'
		else: yHAD9oVfdieMNhC = gxV1zLTsPYfd7eOXi596k+' '+PYEiUvRX1D7O2hzCKIcHjqxgS3edpN+' ('+KgpWFY29JRedEjiOfHaUGn+'min)   '+yHAD9oVfdieMNhC+' ـ'
		if ItpjaAnZOhUEluJQiMm9zGo2v8Dw in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			gvWBYqV3zbRahrCO5IcUs = lBeGVXTt0qD+'/timeshift/'+v1IzDVTBhweb3tRr6YCyoNK+'/'+LX35qsjfcIWaDT8S462+'/'+KgpWFY29JRedEjiOfHaUGn+'/'+ud6Pjcnt2MxWEQ7Z5ySpimI+'/'+jsINZ1EbOvtS7o0+'.m3u8'
			if ItpjaAnZOhUEluJQiMm9zGo2v8Dw=='FULL_EPG': Tca7NsYPkIRWtBpFgxLZbSmCi('link',oYkzVLIgyjNpsiTbZSBQ+yHAD9oVfdieMNhC,gvWBYqV3zbRahrCO5IcUs,9999,EoMKR2biY0,'','','',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('video',oYkzVLIgyjNpsiTbZSBQ+yHAD9oVfdieMNhC,gvWBYqV3zbRahrCO5IcUs,715,EoMKR2biY0,'','','',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
		ttCaYMOIjP.append(yHAD9oVfdieMNhC)
	if ItpjaAnZOhUEluJQiMm9zGo2v8Dw=='SHORT_EPG' and ttCaYMOIjP: ftK9bQvj7XPpZclWN3Ua5eM = JZ83rVRIumz4KGT(ttCaYMOIjP)
	return ttCaYMOIjP
def UMPvFx2RpQTh3LfNYlqSyZz(fTLHoIGS2JMYV3jKh7DuW0ke):
	if not KHWOFrzptwybYx(fTLHoIGS2JMYV3jKh7DuW0ke,True): return
	lBeGVXTt0qD,oNtZdsy79vzERYi4,rrxJeOaK4dA = '',0,0
	Q4o2IDnNJzcYe,VzPym8fW6lKD1bpeZGnRCBs,MnAvyj3DZthLSIo = FhYAZG1ur2sQRtTX9DlOcx3WILv(fTLHoIGS2JMYV3jKh7DuW0ke,False)
	if Q4o2IDnNJzcYe:
		lLmqPQIs0MX5b2t9Bfo = W2wvbMy1zCOsHLnoX4BSJfq9(VzPym8fW6lKD1bpeZGnRCBs)
		oNtZdsy79vzERYi4 = eLsVYNQShdAc0mapgIFbu34l(lLmqPQIs0MX5b2t9Bfo[0],int(MnAvyj3DZthLSIo))
		sEyDZTBxj9l = cHa5JRAQ3ZKku7(fTLHoIGS2JMYV3jKh7DuW0ke,'LIVE_GROUPED')
		EETCAlxZ1nfYG4DjKkVBReU8pFu2yX = NUauTXxKLAoqQtJkglSFRWE(sEyDZTBxj9l,'list','LIVE_GROUPED')
		bb2Wi1TrnXpSA4wgfszMvcxd0O3mL = NUauTXxKLAoqQtJkglSFRWE(sEyDZTBxj9l,'list','LIVE_GROUPED',EETCAlxZ1nfYG4DjKkVBReU8pFu2yX[1])
		gC2hO80boRyM7TBGqD = bb2Wi1TrnXpSA4wgfszMvcxd0O3mL[0][2]
		YNH1Vsv7MuA9cpTjRzox = ZXFs0mEPR8qI2zj.findall('://(.*?)/',gC2hO80boRyM7TBGqD,ZXFs0mEPR8qI2zj.DOTALL)
		YNH1Vsv7MuA9cpTjRzox = YNH1Vsv7MuA9cpTjRzox[0]
		if ':' in YNH1Vsv7MuA9cpTjRzox: Fnjfv2NXGMk15sQmeDAZxKc0Tzq,BDvMt1r7xFXOWa = YNH1Vsv7MuA9cpTjRzox.split(':')
		else: Fnjfv2NXGMk15sQmeDAZxKc0Tzq,BDvMt1r7xFXOWa = YNH1Vsv7MuA9cpTjRzox,'80'
		w80J6USRmacdgtb = W2wvbMy1zCOsHLnoX4BSJfq9(Fnjfv2NXGMk15sQmeDAZxKc0Tzq)
		rrxJeOaK4dA = eLsVYNQShdAc0mapgIFbu34l(w80J6USRmacdgtb[0],int(BDvMt1r7xFXOWa))
	if oNtZdsy79vzERYi4 and rrxJeOaK4dA:
		LaX1QCyeIJ = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		LaX1QCyeIJ += '\n\n'+'وقت ضائع في السيرفر الأصلي'+'\n'+str(int(rrxJeOaK4dA*1000))+' ملي ثانية'
		LaX1QCyeIJ += '\n\n'+'وقت ضائع في السيرفر البديل'+'\n'+str(int(oNtZdsy79vzERYi4*1000))+' ملي ثانية'
		Bkab1Avo3fYG9s6lZcOITDXd4MFi = OxCB4medn1('center','السيرفر الأصلي','السيرفر الأسرع','رسالة من المبرمج',LaX1QCyeIJ)
		if Bkab1Avo3fYG9s6lZcOITDXd4MFi==1 and oNtZdsy79vzERYi4<rrxJeOaK4dA: lBeGVXTt0qD = VzPym8fW6lKD1bpeZGnRCBs+':'+MnAvyj3DZthLSIo
	else: HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','البرنامج لم يجد السيرفر البديل')
	j2agIU0xsLS6c7T.setSetting('av.m3u.server_'+fTLHoIGS2JMYV3jKh7DuW0ke,lBeGVXTt0qD)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(fTLHoIGS2JMYV3jKh7DuW0ke,gC2hO80boRyM7TBGqD,RGDQbxHAi1UpIuNveqTFXSw9gZjc4):
	u5b39JYiNdS8ejFzt4ch = j2agIU0xsLS6c7T.getSetting('av.m3u.useragent_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	vvePnQc9hCHO6zKwpjk1byRSF = j2agIU0xsLS6c7T.getSetting('av.m3u.referer_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	if u5b39JYiNdS8ejFzt4ch or vvePnQc9hCHO6zKwpjk1byRSF:
		gC2hO80boRyM7TBGqD += '|'
		if u5b39JYiNdS8ejFzt4ch: gC2hO80boRyM7TBGqD += '&User-Agent='+u5b39JYiNdS8ejFzt4ch
		if vvePnQc9hCHO6zKwpjk1byRSF: gC2hO80boRyM7TBGqD += '&Referer='+vvePnQc9hCHO6zKwpjk1byRSF
		gC2hO80boRyM7TBGqD = gC2hO80boRyM7TBGqD.replace('|&','|')
	w3hq0Xp8D9rZJ(gC2hO80boRyM7TBGqD,LBtjHDg8yZz69QOp,RGDQbxHAi1UpIuNveqTFXSw9gZjc4)
	return
def MQ0WAOIYobmyxS6akuziJG(fTLHoIGS2JMYV3jKh7DuW0ke):
	HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـUser-Agent خاص')
	u5b39JYiNdS8ejFzt4ch = j2agIU0xsLS6c7T.getSetting('av.m3u.useragent_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	klxDtdGLjS2Qv0ymBXMeziC = OxCB4medn1('center','استخدام الأصلي','تعديل القديم',u5b39JYiNdS8ejFzt4ch,'هذا هو ـUser-Agent المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if klxDtdGLjS2Qv0ymBXMeziC==1: u5b39JYiNdS8ejFzt4ch = CjyEnpfQ23o0PYwDtLId('أكتب ـM3U User-Agent جديد',u5b39JYiNdS8ejFzt4ch,True)
	else: u5b39JYiNdS8ejFzt4ch = 'Unknown'
	if u5b39JYiNdS8ejFzt4ch==' ':
		HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	klxDtdGLjS2Qv0ymBXMeziC = OxCB4medn1('center','','',u5b39JYiNdS8ejFzt4ch,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if klxDtdGLjS2Qv0ymBXMeziC!=1:
		HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','تم الإلغاء')
		return
	j2agIU0xsLS6c7T.setSetting('av.m3u.useragent_'+fTLHoIGS2JMYV3jKh7DuW0ke,u5b39JYiNdS8ejFzt4ch)
	m8mDHu2eZKoJCMXw3bPrUz(fTLHoIGS2JMYV3jKh7DuW0ke)
	return
def sYyPU0CzeIgLmG7pjBq4uDJO(fTLHoIGS2JMYV3jKh7DuW0ke):
	HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـReferer خاص')
	vvePnQc9hCHO6zKwpjk1byRSF = j2agIU0xsLS6c7T.getSetting('av.m3u.referer_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	klxDtdGLjS2Qv0ymBXMeziC = OxCB4medn1('center','استخدام الأصلي','تعديل القديم',vvePnQc9hCHO6zKwpjk1byRSF,'هذا هو ـReferer المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if klxDtdGLjS2Qv0ymBXMeziC==1: vvePnQc9hCHO6zKwpjk1byRSF = CjyEnpfQ23o0PYwDtLId('أكتب ـM3U Referer جديد',vvePnQc9hCHO6zKwpjk1byRSF,True)
	else: vvePnQc9hCHO6zKwpjk1byRSF = ''
	if vvePnQc9hCHO6zKwpjk1byRSF==' ':
		HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	klxDtdGLjS2Qv0ymBXMeziC = OxCB4medn1('center','','',vvePnQc9hCHO6zKwpjk1byRSF,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if klxDtdGLjS2Qv0ymBXMeziC!=1:
		HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','تم الإلغاء')
		return
	j2agIU0xsLS6c7T.setSetting('av.m3u.referer_'+fTLHoIGS2JMYV3jKh7DuW0ke,vvePnQc9hCHO6zKwpjk1byRSF)
	m8mDHu2eZKoJCMXw3bPrUz(fTLHoIGS2JMYV3jKh7DuW0ke)
	return
def gmcELYbTJS(fTLHoIGS2JMYV3jKh7DuW0ke,FjaLDpm2VQIB5iUeZ7GlS3W9rchONT=''):
	if not gq2OBZAR3L0Gdv: gq2OBZAR3L0Gdv = j2agIU0xsLS6c7T.getSetting('av.m3u.url_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	lBeGVXTt0qD = d78KRnJmBWscGua0XMk(gq2OBZAR3L0Gdv,'url')
	v1IzDVTBhweb3tRr6YCyoNK = ZXFs0mEPR8qI2zj.findall('username=(.*?)&',gq2OBZAR3L0Gdv+'&',ZXFs0mEPR8qI2zj.DOTALL)
	LX35qsjfcIWaDT8S462 = ZXFs0mEPR8qI2zj.findall('password=(.*?)&',gq2OBZAR3L0Gdv+'&',ZXFs0mEPR8qI2zj.DOTALL)
	if not v1IzDVTBhweb3tRr6YCyoNK or not LX35qsjfcIWaDT8S462:
		HHTzVhiY079bvdluNkFQ4wCMpe('','','فحص اشتراك M3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		return '','','','',''
	v1IzDVTBhweb3tRr6YCyoNK = v1IzDVTBhweb3tRr6YCyoNK[0]
	LX35qsjfcIWaDT8S462 = LX35qsjfcIWaDT8S462[0]
	LLmOgfvERFwWp9DQMoBHS36rd = lBeGVXTt0qD+'/player_api.php?username='+v1IzDVTBhweb3tRr6YCyoNK+'&password='+LX35qsjfcIWaDT8S462
	fUSnuQTRBwOtFhZz36k9y = lBeGVXTt0qD+'/get.php?username='+v1IzDVTBhweb3tRr6YCyoNK+'&password='+LX35qsjfcIWaDT8S462+'&type=m3u_plus'
	return LLmOgfvERFwWp9DQMoBHS36rd,fUSnuQTRBwOtFhZz36k9y,lBeGVXTt0qD,v1IzDVTBhweb3tRr6YCyoNK,LX35qsjfcIWaDT8S462
def Dmvykqd62HxYAFnOE359U(fTLHoIGS2JMYV3jKh7DuW0ke,bilOMVBfCKYU0a4Fqs3HX9hA=''):
	L69Ll5ObZkDPewd = bilOMVBfCKYU0a4Fqs3HX9hA.replace('/','_').replace(':','_').replace('.','_')
	L69Ll5ObZkDPewd = L69Ll5ObZkDPewd.replace('?','_').replace('=','_').replace('&','_')
	L69Ll5ObZkDPewd = hhHq8m5vauKG9dl.path.join(mATvU6VbxOXNFhz8lK5WGrfQ,L69Ll5ObZkDPewd).strip('.m3u')+'.m3u'
	return L69Ll5ObZkDPewd
def gmfoXnU7hlQ5qL9euC(fTLHoIGS2JMYV3jKh7DuW0ke,VqryRlBf2mx8n5oYOIH6SDp4zXb3):
	mOYxwokQAF = j2agIU0xsLS6c7T.getSetting('av.m3u.url_'+fTLHoIGS2JMYV3jKh7DuW0ke+'_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3)
	wBC16NmY2nRFuctZJxAGTEl0 = True
	if mOYxwokQAF:
		klxDtdGLjS2Qv0ymBXMeziC = A0iaw7hK4Qmc2EeHXZB('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:','[COLOR FFC89008]'+mOYxwokQAF+'[/COLOR]'+'\n\n هذا هو رابط M3U المسجل في البرنامج .. هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if klxDtdGLjS2Qv0ymBXMeziC==-1: return
		elif klxDtdGLjS2Qv0ymBXMeziC==0: mOYxwokQAF = ''
		elif klxDtdGLjS2Qv0ymBXMeziC==2:
			klxDtdGLjS2Qv0ymBXMeziC = OxCB4medn1('center','','','رسالة من المبرمج','هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if klxDtdGLjS2Qv0ymBXMeziC in [-1,0]: return
			HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','تم مسح الرابط')
			wBC16NmY2nRFuctZJxAGTEl0 = False
			QAEmT521BwXp4aKNniFURcgqVb = ''
	if wBC16NmY2nRFuctZJxAGTEl0:
		QAEmT521BwXp4aKNniFURcgqVb = CjyEnpfQ23o0PYwDtLId('اكتب رابط M3U كاملا',mOYxwokQAF)
		QAEmT521BwXp4aKNniFURcgqVb = QAEmT521BwXp4aKNniFURcgqVb.strip(' ')
		if not QAEmT521BwXp4aKNniFURcgqVb:
			klxDtdGLjS2Qv0ymBXMeziC = OxCB4medn1('center','','','رسالة من المبرمج','لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if klxDtdGLjS2Qv0ymBXMeziC in [-1,0]: return
			HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','تم مسح الرابط')
		else:
			LaX1QCyeIJ = 'هذه المعلومات تم أخذها من رابط ـM3U الذي انت كتبته . هل تريد استخدامها ؟!\n'
			klxDtdGLjS2Qv0ymBXMeziC = OxCB4medn1('','','','الرابط الجديد هو:','[COLOR FFC89008]'+QAEmT521BwXp4aKNniFURcgqVb+'[/COLOR]'+'\n\n'+LaX1QCyeIJ)
			if klxDtdGLjS2Qv0ymBXMeziC!=1:
				HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','تم الإلغاء')
				return
	j2agIU0xsLS6c7T.setSetting('av.m3u.url_'+fTLHoIGS2JMYV3jKh7DuW0ke+'_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3,QAEmT521BwXp4aKNniFURcgqVb)
	u5b39JYiNdS8ejFzt4ch = j2agIU0xsLS6c7T.getSetting('av.m3u.useragent_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	if not u5b39JYiNdS8ejFzt4ch: j2agIU0xsLS6c7T.setSetting('av.m3u.useragent_'+fTLHoIGS2JMYV3jKh7DuW0ke,'Unknown')
	m8mDHu2eZKoJCMXw3bPrUz(fTLHoIGS2JMYV3jKh7DuW0ke)
	return
def Wc9NgOYMzATtBHIGyQKswJj(dUkqersWvMoJ964,DG5RtsncgN,Czpk8MuF2DoYdHfLb,jTG1aFtB8HM4zLXoUQygVu0RcOhv,D1kz5HhyWldovxibLINCm4603,ood6Gh9mLZIcrSUO0zVERjsikg7x,fUSnuQTRBwOtFhZz36k9y):
	bb2Wi1TrnXpSA4wgfszMvcxd0O3mL,HqPjEyicVxGJ7QuvaT = [],[]
	YUdNZBwpuE0AC8grQ57mj2 = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for FFhKw05es4jgM in dUkqersWvMoJ964:
		if ood6Gh9mLZIcrSUO0zVERjsikg7x%473==0:
			b8bEl0XjyR4hACKcYkJVP2oBavnGm1(jTG1aFtB8HM4zLXoUQygVu0RcOhv,40+int(10*ood6Gh9mLZIcrSUO0zVERjsikg7x/D1kz5HhyWldovxibLINCm4603),'قراءة الفيديوهات','الفيديو رقم:-',str(ood6Gh9mLZIcrSUO0zVERjsikg7x)+' / '+str(D1kz5HhyWldovxibLINCm4603))
			if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
				jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
				return None,None,None
		gC2hO80boRyM7TBGqD = ZXFs0mEPR8qI2zj.findall('^(.*?)\n+((http|https|rtmp).*?)$',FFhKw05es4jgM,ZXFs0mEPR8qI2zj.DOTALL)
		if gC2hO80boRyM7TBGqD:
			FFhKw05es4jgM,gC2hO80boRyM7TBGqD,vWK3cmrB9SsT4dLwU = gC2hO80boRyM7TBGqD[0]
			gC2hO80boRyM7TBGqD = gC2hO80boRyM7TBGqD.replace('\n','')
			FFhKw05es4jgM = FFhKw05es4jgM.replace('\n','')
		else:
			HqPjEyicVxGJ7QuvaT.append({'line':FFhKw05es4jgM})
			continue
		BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y,dGlmU8JqW5yFAtcsg,aBXgWuYGwdyS8k0jF4efM5QOcDL,yHAD9oVfdieMNhC,RGDQbxHAi1UpIuNveqTFXSw9gZjc4,HtQJpWPblFaZ92EwsGkYoIVD70KBrm = {},'','','','',False
		try:
			FFhKw05es4jgM,yHAD9oVfdieMNhC = FFhKw05es4jgM.rsplit('",',1)
			FFhKw05es4jgM = FFhKw05es4jgM+'"'
		except:
			try: FFhKw05es4jgM,yHAD9oVfdieMNhC = FFhKw05es4jgM.rsplit('1,',1)
			except: yHAD9oVfdieMNhC = ''
		BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['url'] = gC2hO80boRyM7TBGqD
		jHuDViB2aPTFc9UOn3m7foJyER = ZXFs0mEPR8qI2zj.findall(' (.*?)="(.*?)"',FFhKw05es4jgM,ZXFs0mEPR8qI2zj.DOTALL)
		for JDv1uYxBEPcFGwrmlfzSOC,pnhqzFt6AOer1xoR4jUJ in jHuDViB2aPTFc9UOn3m7foJyER:
			JDv1uYxBEPcFGwrmlfzSOC = JDv1uYxBEPcFGwrmlfzSOC.replace('"','').strip(' ')
			BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y[JDv1uYxBEPcFGwrmlfzSOC] = pnhqzFt6AOer1xoR4jUJ.strip(' ')
		ELVFhdrW0OgAu94cJXl = list(BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y.keys())
		if not yHAD9oVfdieMNhC:
			if 'name' in ELVFhdrW0OgAu94cJXl and BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['name']: yHAD9oVfdieMNhC = BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['name']
		BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['title'] = yHAD9oVfdieMNhC.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'logo' in ELVFhdrW0OgAu94cJXl:
			BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['img'] = BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['logo']
			del BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['logo']
		else: BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['img'] = ''
		if 'group' in ELVFhdrW0OgAu94cJXl and BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['group']: aBXgWuYGwdyS8k0jF4efM5QOcDL = BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['group']
		if any(AARNPWHjQU9dEmDI in gC2hO80boRyM7TBGqD.lower() for AARNPWHjQU9dEmDI in YUdNZBwpuE0AC8grQ57mj2):
			HtQJpWPblFaZ92EwsGkYoIVD70KBrm = True if 'm3u' not in gC2hO80boRyM7TBGqD else False
		if HtQJpWPblFaZ92EwsGkYoIVD70KBrm or '__SERIES__' in aBXgWuYGwdyS8k0jF4efM5QOcDL or '__MOVIES__' in aBXgWuYGwdyS8k0jF4efM5QOcDL:
			RGDQbxHAi1UpIuNveqTFXSw9gZjc4 = 'VOD'
			if '__SERIES__' in aBXgWuYGwdyS8k0jF4efM5QOcDL: RGDQbxHAi1UpIuNveqTFXSw9gZjc4 = RGDQbxHAi1UpIuNveqTFXSw9gZjc4+'_SERIES'
			elif '__MOVIES__' in aBXgWuYGwdyS8k0jF4efM5QOcDL: RGDQbxHAi1UpIuNveqTFXSw9gZjc4 = RGDQbxHAi1UpIuNveqTFXSw9gZjc4+'_MOVIES'
			else: RGDQbxHAi1UpIuNveqTFXSw9gZjc4 = RGDQbxHAi1UpIuNveqTFXSw9gZjc4+'_UNKNOWN'
			aBXgWuYGwdyS8k0jF4efM5QOcDL = aBXgWuYGwdyS8k0jF4efM5QOcDL.replace('__SERIES__','').replace('__MOVIES__','')
		else:
			RGDQbxHAi1UpIuNveqTFXSw9gZjc4 = 'LIVE'
			if yHAD9oVfdieMNhC in DG5RtsncgN: dGlmU8JqW5yFAtcsg = dGlmU8JqW5yFAtcsg+'_EPG'
			if yHAD9oVfdieMNhC in Czpk8MuF2DoYdHfLb: dGlmU8JqW5yFAtcsg = dGlmU8JqW5yFAtcsg+'_ARCHIVED'
			if not aBXgWuYGwdyS8k0jF4efM5QOcDL: RGDQbxHAi1UpIuNveqTFXSw9gZjc4 = RGDQbxHAi1UpIuNveqTFXSw9gZjc4+'_UNKNOWN'
			else: RGDQbxHAi1UpIuNveqTFXSw9gZjc4 = RGDQbxHAi1UpIuNveqTFXSw9gZjc4+dGlmU8JqW5yFAtcsg
		aBXgWuYGwdyS8k0jF4efM5QOcDL = aBXgWuYGwdyS8k0jF4efM5QOcDL.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'LIVE_UNKNOWN' in RGDQbxHAi1UpIuNveqTFXSw9gZjc4: aBXgWuYGwdyS8k0jF4efM5QOcDL = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in RGDQbxHAi1UpIuNveqTFXSw9gZjc4: aBXgWuYGwdyS8k0jF4efM5QOcDL = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in RGDQbxHAi1UpIuNveqTFXSw9gZjc4:
			w9wrRhtS84cAoKGx735W = ZXFs0mEPR8qI2zj.findall('(.*?) [Ss]\d+ +[Ee]\d+',BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['title'],ZXFs0mEPR8qI2zj.DOTALL)
			if w9wrRhtS84cAoKGx735W: w9wrRhtS84cAoKGx735W = w9wrRhtS84cAoKGx735W[0]
			else: w9wrRhtS84cAoKGx735W = '!!__UNKNOWN_SERIES__!!'
			aBXgWuYGwdyS8k0jF4efM5QOcDL = aBXgWuYGwdyS8k0jF4efM5QOcDL+'__SERIES__'+w9wrRhtS84cAoKGx735W
		if 'id' in ELVFhdrW0OgAu94cJXl: del BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['id']
		if 'ID' in ELVFhdrW0OgAu94cJXl: del BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['ID']
		if 'name' in ELVFhdrW0OgAu94cJXl: del BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['name']
		yHAD9oVfdieMNhC = BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['title']
		yHAD9oVfdieMNhC = WhJe7bGx5XackTwOIZVLC8ut(yHAD9oVfdieMNhC)
		yHAD9oVfdieMNhC = lCTNoZzaXywGWeLQ(yHAD9oVfdieMNhC)
		KfCRA3emhxGI4YTNBl98pUju21,aBXgWuYGwdyS8k0jF4efM5QOcDL = EliFfhxjYr37VyDC(aBXgWuYGwdyS8k0jF4efM5QOcDL)
		yAS92Iz54TLMZagtYjd,yHAD9oVfdieMNhC = EliFfhxjYr37VyDC(yHAD9oVfdieMNhC)
		BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['type'] = RGDQbxHAi1UpIuNveqTFXSw9gZjc4
		BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['context'] = dGlmU8JqW5yFAtcsg
		BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['group'] = aBXgWuYGwdyS8k0jF4efM5QOcDL.upper()
		BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['title'] = yHAD9oVfdieMNhC.upper()
		BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['country'] = yAS92Iz54TLMZagtYjd.upper()
		BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['language'] = KfCRA3emhxGI4YTNBl98pUju21.upper()
		bb2Wi1TrnXpSA4wgfszMvcxd0O3mL.append(BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y)
		ood6Gh9mLZIcrSUO0zVERjsikg7x += 1
	return bb2Wi1TrnXpSA4wgfszMvcxd0O3mL,ood6Gh9mLZIcrSUO0zVERjsikg7x,HqPjEyicVxGJ7QuvaT
def lCTNoZzaXywGWeLQ(yHAD9oVfdieMNhC):
	yHAD9oVfdieMNhC = yHAD9oVfdieMNhC.replace('  ',' ').replace('  ',' ').replace('  ',' ')
	yHAD9oVfdieMNhC = yHAD9oVfdieMNhC.replace('||','|').replace('___',':').replace('--','-')
	yHAD9oVfdieMNhC = yHAD9oVfdieMNhC.replace('[[','[').replace(']]',']')
	yHAD9oVfdieMNhC = yHAD9oVfdieMNhC.replace('((','(').replace('))',')')
	yHAD9oVfdieMNhC = yHAD9oVfdieMNhC.replace('<<','<').replace('>>','>')
	yHAD9oVfdieMNhC = yHAD9oVfdieMNhC.strip(' ')
	return yHAD9oVfdieMNhC
def a1djBECx0zOTRkKAtI(TuVNhRcQHgtwDbMqE53FJz,jTG1aFtB8HM4zLXoUQygVu0RcOhv,VqryRlBf2mx8n5oYOIH6SDp4zXb3):
	ggVZAItpXbPW6cq = {}
	for ffaXcwQevDRLGm2 in FJLMxd8alBC7QbDKU9Onu2fw: ggVZAItpXbPW6cq[ffaXcwQevDRLGm2+'_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3] = []
	D1kz5HhyWldovxibLINCm4603 = len(TuVNhRcQHgtwDbMqE53FJz)
	GpFnKA1stoN = str(D1kz5HhyWldovxibLINCm4603)
	ood6Gh9mLZIcrSUO0zVERjsikg7x = 0
	HqPjEyicVxGJ7QuvaT = []
	for BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y in TuVNhRcQHgtwDbMqE53FJz:
		if ood6Gh9mLZIcrSUO0zVERjsikg7x%873==0:
			b8bEl0XjyR4hACKcYkJVP2oBavnGm1(jTG1aFtB8HM4zLXoUQygVu0RcOhv,50+int(5*ood6Gh9mLZIcrSUO0zVERjsikg7x/D1kz5HhyWldovxibLINCm4603),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(ood6Gh9mLZIcrSUO0zVERjsikg7x)+' / '+GpFnKA1stoN)
			if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
				jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
				return None,None
		aBXgWuYGwdyS8k0jF4efM5QOcDL,dGlmU8JqW5yFAtcsg,yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0 = BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['group'],BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['context'],BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['title'],BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['url'],BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['img']
		yAS92Iz54TLMZagtYjd,KfCRA3emhxGI4YTNBl98pUju21,ffaXcwQevDRLGm2 = BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['country'],BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['language'],BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['type']
		IY8dOXtURSM5Eb23mW7vK = (aBXgWuYGwdyS8k0jF4efM5QOcDL,dGlmU8JqW5yFAtcsg,yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0)
		pUCIzcEWGZJy = False
		if 'LIVE' in ffaXcwQevDRLGm2:
			if 'UNKNOWN' in ffaXcwQevDRLGm2: ggVZAItpXbPW6cq['LIVE_UNKNOWN_GROUPED_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3].append(IY8dOXtURSM5Eb23mW7vK)
			elif 'LIVE' in ffaXcwQevDRLGm2: ggVZAItpXbPW6cq['LIVE_GROUPED_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3].append(IY8dOXtURSM5Eb23mW7vK)
			else: pUCIzcEWGZJy = True
			ggVZAItpXbPW6cq['LIVE_ORIGINAL_GROUPED_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3].append(IY8dOXtURSM5Eb23mW7vK)
		elif 'VOD' in ffaXcwQevDRLGm2:
			if 'UNKNOWN' in ffaXcwQevDRLGm2: ggVZAItpXbPW6cq['VOD_UNKNOWN_GROUPED_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3].append(IY8dOXtURSM5Eb23mW7vK)
			elif 'MOVIES' in ffaXcwQevDRLGm2: ggVZAItpXbPW6cq['VOD_MOVIES_GROUPED_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3].append(IY8dOXtURSM5Eb23mW7vK)
			elif 'SERIES' in ffaXcwQevDRLGm2: ggVZAItpXbPW6cq['VOD_SERIES_GROUPED_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3].append(IY8dOXtURSM5Eb23mW7vK)
			else: pUCIzcEWGZJy = True
			ggVZAItpXbPW6cq['VOD_ORIGINAL_GROUPED_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3].append(IY8dOXtURSM5Eb23mW7vK)
		else: pUCIzcEWGZJy = True
		if pUCIzcEWGZJy: HqPjEyicVxGJ7QuvaT.append(BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y)
		ood6Gh9mLZIcrSUO0zVERjsikg7x += 1
	GA5F6vnyTmDV0YkQihUexNH9a7 = sorted(TuVNhRcQHgtwDbMqE53FJz,reverse=False,key=lambda JDv1uYxBEPcFGwrmlfzSOC: JDv1uYxBEPcFGwrmlfzSOC['title'].lower())
	del TuVNhRcQHgtwDbMqE53FJz
	GpFnKA1stoN = str(D1kz5HhyWldovxibLINCm4603)
	ood6Gh9mLZIcrSUO0zVERjsikg7x = 0
	for BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y in GA5F6vnyTmDV0YkQihUexNH9a7:
		ood6Gh9mLZIcrSUO0zVERjsikg7x += 1
		if ood6Gh9mLZIcrSUO0zVERjsikg7x%873==0:
			b8bEl0XjyR4hACKcYkJVP2oBavnGm1(jTG1aFtB8HM4zLXoUQygVu0RcOhv,55+int(5*ood6Gh9mLZIcrSUO0zVERjsikg7x/D1kz5HhyWldovxibLINCm4603),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(ood6Gh9mLZIcrSUO0zVERjsikg7x)+' / '+GpFnKA1stoN)
			if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
				jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
				return None,None
		ffaXcwQevDRLGm2 = BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['type']
		aBXgWuYGwdyS8k0jF4efM5QOcDL,dGlmU8JqW5yFAtcsg,yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0 = BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['group'],BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['context'],BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['title'],BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['url'],BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['img']
		yAS92Iz54TLMZagtYjd,KfCRA3emhxGI4YTNBl98pUju21 = BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['country'],BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['language']
		bVn51h8cWPYdlgUEX7x0F = (aBXgWuYGwdyS8k0jF4efM5QOcDL,dGlmU8JqW5yFAtcsg+'_TIMESHIFT',yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0)
		IY8dOXtURSM5Eb23mW7vK = (aBXgWuYGwdyS8k0jF4efM5QOcDL,dGlmU8JqW5yFAtcsg,yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0)
		JZDK54z8nWILhONyiamXbMcRAu = (yAS92Iz54TLMZagtYjd,dGlmU8JqW5yFAtcsg,yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0)
		RSoIZcnu3Ah8HWw4QeJ1ytpNlm = (KfCRA3emhxGI4YTNBl98pUju21,dGlmU8JqW5yFAtcsg,yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0)
		if 'LIVE' in ffaXcwQevDRLGm2:
			if 'UNKNOWN' in ffaXcwQevDRLGm2: ggVZAItpXbPW6cq['LIVE_UNKNOWN_GROUPED_SORTED_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3].append(IY8dOXtURSM5Eb23mW7vK)
			else: ggVZAItpXbPW6cq['LIVE_GROUPED_SORTED_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3].append(IY8dOXtURSM5Eb23mW7vK)
			if 'EPG'		in ffaXcwQevDRLGm2: ggVZAItpXbPW6cq['LIVE_EPG_GROUPED_SORTED_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3].append(IY8dOXtURSM5Eb23mW7vK)
			if 'ARCHIVED'	in ffaXcwQevDRLGm2: ggVZAItpXbPW6cq['LIVE_ARCHIVED_GROUPED_SORTED_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3].append(IY8dOXtURSM5Eb23mW7vK)
			if 'ARCHIVED'	in ffaXcwQevDRLGm2: ggVZAItpXbPW6cq['LIVE_TIMESHIFT_GROUPED_SORTED_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3].append(bVn51h8cWPYdlgUEX7x0F)
			ggVZAItpXbPW6cq['LIVE_FROM_NAME_SORTED_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3].append(JZDK54z8nWILhONyiamXbMcRAu)
			ggVZAItpXbPW6cq['LIVE_FROM_GROUP_SORTED_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3].append(RSoIZcnu3Ah8HWw4QeJ1ytpNlm)
		elif 'VOD' in ffaXcwQevDRLGm2:
			if   'UNKNOWN'	in ffaXcwQevDRLGm2: ggVZAItpXbPW6cq['VOD_UNKNOWN_GROUPED_SORTED_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3].append(IY8dOXtURSM5Eb23mW7vK)
			elif 'MOVIES'	in ffaXcwQevDRLGm2: ggVZAItpXbPW6cq['VOD_MOVIES_GROUPED_SORTED_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3].append(IY8dOXtURSM5Eb23mW7vK)
			elif 'SERIES'	in ffaXcwQevDRLGm2: ggVZAItpXbPW6cq['VOD_SERIES_GROUPED_SORTED_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3].append(IY8dOXtURSM5Eb23mW7vK)
			ggVZAItpXbPW6cq['VOD_FROM_NAME_SORTED_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3].append(JZDK54z8nWILhONyiamXbMcRAu)
			ggVZAItpXbPW6cq['VOD_FROM_GROUP_SORTED_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3].append(RSoIZcnu3Ah8HWw4QeJ1ytpNlm)
	return ggVZAItpXbPW6cq,HqPjEyicVxGJ7QuvaT
def EliFfhxjYr37VyDC(yHAD9oVfdieMNhC):
	if len(yHAD9oVfdieMNhC)<3: return yHAD9oVfdieMNhC,yHAD9oVfdieMNhC
	HcvA9eyxq5NFhmTbDQIrJkz,MfPyeLVc0xGvqmtHjSrQ3Xd = '',''
	ORxu01XoaQE = yHAD9oVfdieMNhC
	nWgflw9FRa8m6IbDqTExc0Kdp = yHAD9oVfdieMNhC[:1]
	IVJef2ab9yZmpPwkcLFsQKzju7MnCt = yHAD9oVfdieMNhC[1:]
	if   nWgflw9FRa8m6IbDqTExc0Kdp=='(': MfPyeLVc0xGvqmtHjSrQ3Xd = ')'
	elif nWgflw9FRa8m6IbDqTExc0Kdp=='[': MfPyeLVc0xGvqmtHjSrQ3Xd = ']'
	elif nWgflw9FRa8m6IbDqTExc0Kdp=='<': MfPyeLVc0xGvqmtHjSrQ3Xd = '>'
	elif nWgflw9FRa8m6IbDqTExc0Kdp=='|': MfPyeLVc0xGvqmtHjSrQ3Xd = '|'
	if MfPyeLVc0xGvqmtHjSrQ3Xd and (MfPyeLVc0xGvqmtHjSrQ3Xd in IVJef2ab9yZmpPwkcLFsQKzju7MnCt):
		jy4k3KNeqg,W4Ph97dVtuTblCI1ZEjLY = IVJef2ab9yZmpPwkcLFsQKzju7MnCt.split(MfPyeLVc0xGvqmtHjSrQ3Xd,1)
		HcvA9eyxq5NFhmTbDQIrJkz = jy4k3KNeqg
		ORxu01XoaQE = nWgflw9FRa8m6IbDqTExc0Kdp+jy4k3KNeqg+MfPyeLVc0xGvqmtHjSrQ3Xd+' '+W4Ph97dVtuTblCI1ZEjLY
	elif yHAD9oVfdieMNhC.count('|')>=2:
		jy4k3KNeqg,W4Ph97dVtuTblCI1ZEjLY = yHAD9oVfdieMNhC.split('|',1)
		HcvA9eyxq5NFhmTbDQIrJkz = jy4k3KNeqg
		ORxu01XoaQE = jy4k3KNeqg+' |'+W4Ph97dVtuTblCI1ZEjLY
	else:
		MfPyeLVc0xGvqmtHjSrQ3Xd = ZXFs0mEPR8qI2zj.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',yHAD9oVfdieMNhC,ZXFs0mEPR8qI2zj.DOTALL)
		if not MfPyeLVc0xGvqmtHjSrQ3Xd: MfPyeLVc0xGvqmtHjSrQ3Xd = ZXFs0mEPR8qI2zj.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',yHAD9oVfdieMNhC,ZXFs0mEPR8qI2zj.DOTALL)
		if not MfPyeLVc0xGvqmtHjSrQ3Xd: MfPyeLVc0xGvqmtHjSrQ3Xd = ZXFs0mEPR8qI2zj.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',yHAD9oVfdieMNhC,ZXFs0mEPR8qI2zj.DOTALL)
		if MfPyeLVc0xGvqmtHjSrQ3Xd:
			jy4k3KNeqg,W4Ph97dVtuTblCI1ZEjLY = yHAD9oVfdieMNhC.split(MfPyeLVc0xGvqmtHjSrQ3Xd[0],1)
			HcvA9eyxq5NFhmTbDQIrJkz = jy4k3KNeqg
			ORxu01XoaQE = jy4k3KNeqg+' '+MfPyeLVc0xGvqmtHjSrQ3Xd[0]+' '+W4Ph97dVtuTblCI1ZEjLY
	ORxu01XoaQE = ORxu01XoaQE.replace('   ',' ').replace('  ',' ')
	HcvA9eyxq5NFhmTbDQIrJkz = HcvA9eyxq5NFhmTbDQIrJkz.replace('  ',' ')
	if not HcvA9eyxq5NFhmTbDQIrJkz: HcvA9eyxq5NFhmTbDQIrJkz = '!!__UNKNOWN__!!'
	HcvA9eyxq5NFhmTbDQIrJkz = HcvA9eyxq5NFhmTbDQIrJkz.strip(' ')
	ORxu01XoaQE = ORxu01XoaQE.strip(' ')
	return HcvA9eyxq5NFhmTbDQIrJkz,ORxu01XoaQE
def poTRFiyNCYwsO8dhMBHZ2lAIvL1(fTLHoIGS2JMYV3jKh7DuW0ke):
	Mm7XCRohg3iUSfJKdWsIqx = {}
	u5b39JYiNdS8ejFzt4ch = j2agIU0xsLS6c7T.getSetting('av.m3u.useragent_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	if u5b39JYiNdS8ejFzt4ch: Mm7XCRohg3iUSfJKdWsIqx['User-Agent'] = u5b39JYiNdS8ejFzt4ch
	vvePnQc9hCHO6zKwpjk1byRSF = j2agIU0xsLS6c7T.getSetting('av.m3u.referer_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	if vvePnQc9hCHO6zKwpjk1byRSF: Mm7XCRohg3iUSfJKdWsIqx['Referer'] = vvePnQc9hCHO6zKwpjk1byRSF
	return Mm7XCRohg3iUSfJKdWsIqx
def OERZgyI3M0aDAXLvSiTpdjh1Q(fTLHoIGS2JMYV3jKh7DuW0ke,VqryRlBf2mx8n5oYOIH6SDp4zXb3):
	global jTG1aFtB8HM4zLXoUQygVu0RcOhv,ggVZAItpXbPW6cq,dybj5sgEH6RqTJYm2W0,mQtbwgnGcTakM2BZAvjNO907WRV,lnzB93tKLeDabv,EETCAlxZ1nfYG4DjKkVBReU8pFu2yX,VpnQLGFdJ07EIbDlaXi6,YEl7NKbSXQHT,xJLE9wZQa6
	fUSnuQTRBwOtFhZz36k9y = j2agIU0xsLS6c7T.getSetting('av.m3u.url_'+fTLHoIGS2JMYV3jKh7DuW0ke+'_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3)
	u5b39JYiNdS8ejFzt4ch = j2agIU0xsLS6c7T.getSetting('av.m3u.useragent_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	Mm7XCRohg3iUSfJKdWsIqx = {'User-Agent':u5b39JYiNdS8ejFzt4ch}
	L69Ll5ObZkDPewd = kyZdMcbuHrEwf.replace('___','_'+fTLHoIGS2JMYV3jKh7DuW0ke+'_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3)
	if 1:
		Q4o2IDnNJzcYe,VzPym8fW6lKD1bpeZGnRCBs,MnAvyj3DZthLSIo = True,'',''
		if not Q4o2IDnNJzcYe:
			HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','فشل بسحب ملفات ـM3U . أحتمال رابط ـM3U غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـM3U الموجودة بهذا البرنامج')
			if not fUSnuQTRBwOtFhZz36k9y: tr24ZoudmqvxfYCw('ERROR_LINES',RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+'   No M3U URL found to download M3U files')
			else: tr24ZoudmqvxfYCw('ERROR_LINES',RGSFZ7ls3nO(LBtjHDg8yZz69QOp)+'   Failed to download M3U files')
			return
		LLGEyx4As9aCmlR6OwWcFqKtrphSkn = L41Ku9Nxqcsw(fUSnuQTRBwOtFhZz36k9y,Mm7XCRohg3iUSfJKdWsIqx,True)
		if not LLGEyx4As9aCmlR6OwWcFqKtrphSkn: return
		open(L69Ll5ObZkDPewd,'wb').write(LLGEyx4As9aCmlR6OwWcFqKtrphSkn)
	else: LLGEyx4As9aCmlR6OwWcFqKtrphSkn = open(L69Ll5ObZkDPewd,'rb').read()
	if VYMZsxRpcQHPgkaiDKjyoh and LLGEyx4As9aCmlR6OwWcFqKtrphSkn: LLGEyx4As9aCmlR6OwWcFqKtrphSkn = LLGEyx4As9aCmlR6OwWcFqKtrphSkn.decode('utf8')
	jTG1aFtB8HM4zLXoUQygVu0RcOhv = a6Nd4etSry0P1W()
	jTG1aFtB8HM4zLXoUQygVu0RcOhv.create('جلب ملفات M3U جديدة','')
	b8bEl0XjyR4hACKcYkJVP2oBavnGm1(jTG1aFtB8HM4zLXoUQygVu0RcOhv,15,'تنظيف الملف الرئيسي','')
	LLGEyx4As9aCmlR6OwWcFqKtrphSkn = LLGEyx4As9aCmlR6OwWcFqKtrphSkn.replace('"tvg-','" tvg-')
	LLGEyx4As9aCmlR6OwWcFqKtrphSkn = LLGEyx4As9aCmlR6OwWcFqKtrphSkn.replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
	LLGEyx4As9aCmlR6OwWcFqKtrphSkn = LLGEyx4As9aCmlR6OwWcFqKtrphSkn.replace('ّ','').replace('ِ','').replace('ٍ','').replace('ْ','')
	LLGEyx4As9aCmlR6OwWcFqKtrphSkn = LLGEyx4As9aCmlR6OwWcFqKtrphSkn.replace('group-title=','group=').replace('tvg-','')
	Czpk8MuF2DoYdHfLb,DG5RtsncgN = [],[]
	LLGEyx4As9aCmlR6OwWcFqKtrphSkn = LLGEyx4As9aCmlR6OwWcFqKtrphSkn.replace('\r','\n')
	dUkqersWvMoJ964 = ZXFs0mEPR8qI2zj.findall('NF:(.+?)'+'#'+'EXTI',LLGEyx4As9aCmlR6OwWcFqKtrphSkn+'\n+'+'#'+'EXTINF:',ZXFs0mEPR8qI2zj.DOTALL)
	if not dUkqersWvMoJ964:
		tr24ZoudmqvxfYCw('ERROR_LINES',RGSFZ7ls3nO(LBtjHDg8yZz69QOp)+'   Folder:'+fTLHoIGS2JMYV3jKh7DuW0ke+'  Sequence:'+VqryRlBf2mx8n5oYOIH6SDp4zXb3+'   No video links found in M3U file')
		HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','رابط ـM3U الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـM3U غير صحيح'+'\n'+'[COLOR FFFFFF00]'+'مجلد رقم '+fTLHoIGS2JMYV3jKh7DuW0ke+'      رابط رقم '+VqryRlBf2mx8n5oYOIH6SDp4zXb3+'[/COLOR]')
		jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
		return
	JDPKM4T1dGiLCyfbhlUHQ0Nanc8 = []
	for FFhKw05es4jgM in dUkqersWvMoJ964:
		JAGqcTbInBXvLtCpWaV = FFhKw05es4jgM.lower()
		if 'adult' in JAGqcTbInBXvLtCpWaV: continue
		if 'xxx' in JAGqcTbInBXvLtCpWaV: continue
		JDPKM4T1dGiLCyfbhlUHQ0Nanc8.append(FFhKw05es4jgM)
	dUkqersWvMoJ964 = JDPKM4T1dGiLCyfbhlUHQ0Nanc8
	del JDPKM4T1dGiLCyfbhlUHQ0Nanc8
	if 'iptv-org' in fUSnuQTRBwOtFhZz36k9y:
		JDPKM4T1dGiLCyfbhlUHQ0Nanc8,Qkub8aVJqdcjxn9h4lFO3PH1 = [],[]
		for FFhKw05es4jgM in dUkqersWvMoJ964:
			EETCAlxZ1nfYG4DjKkVBReU8pFu2yX = ZXFs0mEPR8qI2zj.findall('group="(.*?)"',FFhKw05es4jgM,ZXFs0mEPR8qI2zj.DOTALL)
			if EETCAlxZ1nfYG4DjKkVBReU8pFu2yX:
				EETCAlxZ1nfYG4DjKkVBReU8pFu2yX = EETCAlxZ1nfYG4DjKkVBReU8pFu2yX[0]
				K4uRaScPJY7I5W1tGpUf = EETCAlxZ1nfYG4DjKkVBReU8pFu2yX.split(';')
				if 'region' in fUSnuQTRBwOtFhZz36k9y: KJEW6UhMIYb0nd5DRCLNs1a9io3GS = '1_'
				elif 'category' in fUSnuQTRBwOtFhZz36k9y: KJEW6UhMIYb0nd5DRCLNs1a9io3GS = '2_'
				elif 'language' in fUSnuQTRBwOtFhZz36k9y: KJEW6UhMIYb0nd5DRCLNs1a9io3GS = '3_'
				elif 'country' in fUSnuQTRBwOtFhZz36k9y: KJEW6UhMIYb0nd5DRCLNs1a9io3GS = '4_'
				else: KJEW6UhMIYb0nd5DRCLNs1a9io3GS = '5_'
				FziD54hrsAIRw9qB87tCMkmvPdjTGb = FFhKw05es4jgM.replace('group="'+EETCAlxZ1nfYG4DjKkVBReU8pFu2yX+'"','group="'+KJEW6UhMIYb0nd5DRCLNs1a9io3GS+'~[COLOR FFC89008] ===== ===== ===== [/COLOR]'+'"')
				JDPKM4T1dGiLCyfbhlUHQ0Nanc8.append(FziD54hrsAIRw9qB87tCMkmvPdjTGb)
				for aBXgWuYGwdyS8k0jF4efM5QOcDL in K4uRaScPJY7I5W1tGpUf:
					FziD54hrsAIRw9qB87tCMkmvPdjTGb = FFhKw05es4jgM.replace('group="'+EETCAlxZ1nfYG4DjKkVBReU8pFu2yX+'"','group="'+KJEW6UhMIYb0nd5DRCLNs1a9io3GS+aBXgWuYGwdyS8k0jF4efM5QOcDL+'"')
					JDPKM4T1dGiLCyfbhlUHQ0Nanc8.append(FziD54hrsAIRw9qB87tCMkmvPdjTGb)
			else: JDPKM4T1dGiLCyfbhlUHQ0Nanc8.append(FFhKw05es4jgM)
		dUkqersWvMoJ964 = JDPKM4T1dGiLCyfbhlUHQ0Nanc8
		del JDPKM4T1dGiLCyfbhlUHQ0Nanc8,Qkub8aVJqdcjxn9h4lFO3PH1
	vvRNy2W0HAbgqdI8SzXuKpa = 1024*1024
	WWwaUpEfzidu3H9APtLcT = 1+len(LLGEyx4As9aCmlR6OwWcFqKtrphSkn)//vvRNy2W0HAbgqdI8SzXuKpa//10
	del LLGEyx4As9aCmlR6OwWcFqKtrphSkn
	cc8fs6kiRnpx7VIU = len(dUkqersWvMoJ964)
	Qkub8aVJqdcjxn9h4lFO3PH1 = UUG3k64wyPDtOszK728Vx1Ql(dUkqersWvMoJ964,WWwaUpEfzidu3H9APtLcT)
	del dUkqersWvMoJ964
	for tdpTaMcz6ZfOUAvx0ByPnLrJob in range(WWwaUpEfzidu3H9APtLcT):
		b8bEl0XjyR4hACKcYkJVP2oBavnGm1(jTG1aFtB8HM4zLXoUQygVu0RcOhv,35+int(5*tdpTaMcz6ZfOUAvx0ByPnLrJob/WWwaUpEfzidu3H9APtLcT),'تقطيع الملف الرئيسي','الجزء رقم:-',str(tdpTaMcz6ZfOUAvx0ByPnLrJob+1)+' / '+str(WWwaUpEfzidu3H9APtLcT))
		if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
			jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
			return
		fqbcTAz7ngSu2 = str(Qkub8aVJqdcjxn9h4lFO3PH1[tdpTaMcz6ZfOUAvx0ByPnLrJob])
		if VYMZsxRpcQHPgkaiDKjyoh: fqbcTAz7ngSu2 = fqbcTAz7ngSu2.encode('utf8')
		open(L69Ll5ObZkDPewd+'.00'+str(tdpTaMcz6ZfOUAvx0ByPnLrJob),'wb').write(fqbcTAz7ngSu2)
	del Qkub8aVJqdcjxn9h4lFO3PH1,fqbcTAz7ngSu2
	xTWV5UvXqpMD7yO,TuVNhRcQHgtwDbMqE53FJz,ood6Gh9mLZIcrSUO0zVERjsikg7x = [],[],0
	for tdpTaMcz6ZfOUAvx0ByPnLrJob in range(WWwaUpEfzidu3H9APtLcT):
		if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
			jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
			return
		fqbcTAz7ngSu2 = open(L69Ll5ObZkDPewd+'.00'+str(tdpTaMcz6ZfOUAvx0ByPnLrJob),'rb').read()
		luMHeSgCBaPrb9KvUjNFqcR.sleep(1)
		try: hhHq8m5vauKG9dl.remove(L69Ll5ObZkDPewd+'.00'+str(tdpTaMcz6ZfOUAvx0ByPnLrJob))
		except: pass
		if VYMZsxRpcQHPgkaiDKjyoh: fqbcTAz7ngSu2 = fqbcTAz7ngSu2.decode('utf8')
		Xs4IR3fzvBN1mkSPpgiEhG7btFJd = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('list',fqbcTAz7ngSu2)
		del fqbcTAz7ngSu2
		bb2Wi1TrnXpSA4wgfszMvcxd0O3mL,ood6Gh9mLZIcrSUO0zVERjsikg7x,HqPjEyicVxGJ7QuvaT = Wc9NgOYMzATtBHIGyQKswJj(Xs4IR3fzvBN1mkSPpgiEhG7btFJd,DG5RtsncgN,Czpk8MuF2DoYdHfLb,jTG1aFtB8HM4zLXoUQygVu0RcOhv,cc8fs6kiRnpx7VIU,ood6Gh9mLZIcrSUO0zVERjsikg7x,fUSnuQTRBwOtFhZz36k9y)
		if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
			jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
			return
		if not bb2Wi1TrnXpSA4wgfszMvcxd0O3mL:
			jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
			return
		TuVNhRcQHgtwDbMqE53FJz += bb2Wi1TrnXpSA4wgfszMvcxd0O3mL
		xTWV5UvXqpMD7yO += HqPjEyicVxGJ7QuvaT
	del Xs4IR3fzvBN1mkSPpgiEhG7btFJd,bb2Wi1TrnXpSA4wgfszMvcxd0O3mL
	ggVZAItpXbPW6cq,HqPjEyicVxGJ7QuvaT = a1djBECx0zOTRkKAtI(TuVNhRcQHgtwDbMqE53FJz,jTG1aFtB8HM4zLXoUQygVu0RcOhv,VqryRlBf2mx8n5oYOIH6SDp4zXb3)
	if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
		jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
		return
	xTWV5UvXqpMD7yO += HqPjEyicVxGJ7QuvaT
	del TuVNhRcQHgtwDbMqE53FJz,HqPjEyicVxGJ7QuvaT
	mQtbwgnGcTakM2BZAvjNO907WRV,lnzB93tKLeDabv,EETCAlxZ1nfYG4DjKkVBReU8pFu2yX,VpnQLGFdJ07EIbDlaXi6,YEl7NKbSXQHT = {},{},{},0,0
	ZvbkCIpHAMOPDy0mBSVsxE = list(ggVZAItpXbPW6cq.keys())
	xJLE9wZQa6 = len(ZvbkCIpHAMOPDy0mBSVsxE)*3
	if 1:
		pYszTMCOeWg = {}
		for dMu4F8L5Azo6IJ2aleywBmb in ZvbkCIpHAMOPDy0mBSVsxE:
			pYszTMCOeWg[dMu4F8L5Azo6IJ2aleywBmb] = c3cgVjNv1rde.Thread(target=km43rqTRescAwyH89,args=(dMu4F8L5Azo6IJ2aleywBmb,))
			pYszTMCOeWg[dMu4F8L5Azo6IJ2aleywBmb].start()
		for dMu4F8L5Azo6IJ2aleywBmb in ZvbkCIpHAMOPDy0mBSVsxE:
			pYszTMCOeWg[dMu4F8L5Azo6IJ2aleywBmb].join()
		if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
			jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
			return
	else:
		for dMu4F8L5Azo6IJ2aleywBmb in ZvbkCIpHAMOPDy0mBSVsxE:
			km43rqTRescAwyH89(dMu4F8L5Azo6IJ2aleywBmb)
			if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
				jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
				return
	Xjs93SRJtwqc(fTLHoIGS2JMYV3jKh7DuW0ke,VqryRlBf2mx8n5oYOIH6SDp4zXb3,False)
	ZvbkCIpHAMOPDy0mBSVsxE = list(mQtbwgnGcTakM2BZAvjNO907WRV.keys())
	dybj5sgEH6RqTJYm2W0 = 0
	if 1:
		pYszTMCOeWg = {}
		for dMu4F8L5Azo6IJ2aleywBmb in ZvbkCIpHAMOPDy0mBSVsxE:
			pYszTMCOeWg[dMu4F8L5Azo6IJ2aleywBmb] = c3cgVjNv1rde.Thread(target=IIkGRs2DZjSTwozNq739adpAgy8bOJ,args=(fTLHoIGS2JMYV3jKh7DuW0ke,dMu4F8L5Azo6IJ2aleywBmb))
			pYszTMCOeWg[dMu4F8L5Azo6IJ2aleywBmb].start()
		for dMu4F8L5Azo6IJ2aleywBmb in ZvbkCIpHAMOPDy0mBSVsxE:
			pYszTMCOeWg[dMu4F8L5Azo6IJ2aleywBmb].join()
		if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
			jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
			return
	else:
		for dMu4F8L5Azo6IJ2aleywBmb in ZvbkCIpHAMOPDy0mBSVsxE:
			IIkGRs2DZjSTwozNq739adpAgy8bOJ(fTLHoIGS2JMYV3jKh7DuW0ke,dMu4F8L5Azo6IJ2aleywBmb)
			if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
				jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
				return
	tdpTaMcz6ZfOUAvx0ByPnLrJob = 0
	RIpkMOAGTFo4tdSCw5c2NV = len(xTWV5UvXqpMD7yO)
	sEyDZTBxj9l = cHa5JRAQ3ZKku7(fTLHoIGS2JMYV3jKh7DuW0ke,'IGNORED')
	for ZzT9UxXGbMAm2OSdgcNBet in xTWV5UvXqpMD7yO:
		if tdpTaMcz6ZfOUAvx0ByPnLrJob%27==0:
			b8bEl0XjyR4hACKcYkJVP2oBavnGm1(jTG1aFtB8HM4zLXoUQygVu0RcOhv,95+int(5*tdpTaMcz6ZfOUAvx0ByPnLrJob//RIpkMOAGTFo4tdSCw5c2NV),'تخزين المهملة','الفيديو رقم:-',str(tdpTaMcz6ZfOUAvx0ByPnLrJob)+' / '+str(RIpkMOAGTFo4tdSCw5c2NV))
			if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
				jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
				return
		Qc96YoCZJOsKUB8yImw034(sEyDZTBxj9l,'IGNORED_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3,str(ZzT9UxXGbMAm2OSdgcNBet),'',iKYM8NdkGHmBcr)
		tdpTaMcz6ZfOUAvx0ByPnLrJob += 1
	Qc96YoCZJOsKUB8yImw034(sEyDZTBxj9l,'IGNORED_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3,'__COUNT__',str(RIpkMOAGTFo4tdSCw5c2NV),iKYM8NdkGHmBcr)
	jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
	luMHeSgCBaPrb9KvUjNFqcR.sleep(1)
	m8mDHu2eZKoJCMXw3bPrUz(fTLHoIGS2JMYV3jKh7DuW0ke)
	return
def km43rqTRescAwyH89(dMu4F8L5Azo6IJ2aleywBmb):
	global jTG1aFtB8HM4zLXoUQygVu0RcOhv,ggVZAItpXbPW6cq,dybj5sgEH6RqTJYm2W0,mQtbwgnGcTakM2BZAvjNO907WRV,lnzB93tKLeDabv,EETCAlxZ1nfYG4DjKkVBReU8pFu2yX,VpnQLGFdJ07EIbDlaXi6,YEl7NKbSXQHT,xJLE9wZQa6
	mQtbwgnGcTakM2BZAvjNO907WRV[dMu4F8L5Azo6IJ2aleywBmb] = {}
	Byw52HLiV0Udkbv,yAV0WlZbRGt2I6frq = {},[]
	KUfLbM1cG3qgQri8duHCemWwyVth = len(ggVZAItpXbPW6cq[dMu4F8L5Azo6IJ2aleywBmb])
	mQtbwgnGcTakM2BZAvjNO907WRV[dMu4F8L5Azo6IJ2aleywBmb]['__COUNT__'] = KUfLbM1cG3qgQri8duHCemWwyVth
	if KUfLbM1cG3qgQri8duHCemWwyVth>0:
		lWDe5hsb1S7YncVG9XdI,SA6DdjwRMGgV2bY8B7,HaNDwlWYbucd3P0Vptisqg,tPZ6I7v5Lc8gMRN4EGkQA1JKuf,EATmh7WH4cQzjZdiRyVUG3g = zip(*ggVZAItpXbPW6cq[dMu4F8L5Azo6IJ2aleywBmb])
		del SA6DdjwRMGgV2bY8B7,HaNDwlWYbucd3P0Vptisqg,tPZ6I7v5Lc8gMRN4EGkQA1JKuf
		K4uRaScPJY7I5W1tGpUf = list(set(lWDe5hsb1S7YncVG9XdI))
		for aBXgWuYGwdyS8k0jF4efM5QOcDL in K4uRaScPJY7I5W1tGpUf:
			Byw52HLiV0Udkbv[aBXgWuYGwdyS8k0jF4efM5QOcDL] = ''
			mQtbwgnGcTakM2BZAvjNO907WRV[dMu4F8L5Azo6IJ2aleywBmb][aBXgWuYGwdyS8k0jF4efM5QOcDL] = []
		b8bEl0XjyR4hACKcYkJVP2oBavnGm1(jTG1aFtB8HM4zLXoUQygVu0RcOhv,60+int(15*YEl7NKbSXQHT//xJLE9wZQa6),'تصنيع القوائم','الجزء رقم:-',str(YEl7NKbSXQHT)+' / '+str(xJLE9wZQa6))
		if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled(): return
		YEl7NKbSXQHT += 1
		dCZ2MWGRFUpjQo5 = len(K4uRaScPJY7I5W1tGpUf)
		del K4uRaScPJY7I5W1tGpUf
		yAV0WlZbRGt2I6frq = list(set(zip(lWDe5hsb1S7YncVG9XdI,EATmh7WH4cQzjZdiRyVUG3g)))
		del lWDe5hsb1S7YncVG9XdI,EATmh7WH4cQzjZdiRyVUG3g
		for aBXgWuYGwdyS8k0jF4efM5QOcDL,ggOIGYi4nEAJ2c8hvFufLRBq in yAV0WlZbRGt2I6frq:
			if not Byw52HLiV0Udkbv[aBXgWuYGwdyS8k0jF4efM5QOcDL] and ggOIGYi4nEAJ2c8hvFufLRBq: Byw52HLiV0Udkbv[aBXgWuYGwdyS8k0jF4efM5QOcDL] = ggOIGYi4nEAJ2c8hvFufLRBq
		b8bEl0XjyR4hACKcYkJVP2oBavnGm1(jTG1aFtB8HM4zLXoUQygVu0RcOhv,60+int(15*YEl7NKbSXQHT//xJLE9wZQa6),'تصنيع القوائم','الجزء رقم:-',str(YEl7NKbSXQHT)+' / '+str(xJLE9wZQa6))
		if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled(): return
		YEl7NKbSXQHT += 1
		Kvt7yrA3i2ZaFPJgISGhndxfl = list(Byw52HLiV0Udkbv.keys())
		i3iT2QvqWcfHxoMbrykj = list(Byw52HLiV0Udkbv.values())
		del Byw52HLiV0Udkbv
		yAV0WlZbRGt2I6frq = list(zip(Kvt7yrA3i2ZaFPJgISGhndxfl,i3iT2QvqWcfHxoMbrykj))
		del Kvt7yrA3i2ZaFPJgISGhndxfl,i3iT2QvqWcfHxoMbrykj
		yAV0WlZbRGt2I6frq = sorted(yAV0WlZbRGt2I6frq)
	else: YEl7NKbSXQHT += 2
	mQtbwgnGcTakM2BZAvjNO907WRV[dMu4F8L5Azo6IJ2aleywBmb]['__GROUPS__'] = yAV0WlZbRGt2I6frq
	del yAV0WlZbRGt2I6frq
	for aBXgWuYGwdyS8k0jF4efM5QOcDL,dGlmU8JqW5yFAtcsg,yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0 in ggVZAItpXbPW6cq[dMu4F8L5Azo6IJ2aleywBmb]:
		mQtbwgnGcTakM2BZAvjNO907WRV[dMu4F8L5Azo6IJ2aleywBmb][aBXgWuYGwdyS8k0jF4efM5QOcDL].append((dGlmU8JqW5yFAtcsg,yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0))
	b8bEl0XjyR4hACKcYkJVP2oBavnGm1(jTG1aFtB8HM4zLXoUQygVu0RcOhv,60+int(15*YEl7NKbSXQHT//xJLE9wZQa6),'تصنيع القوائم','الجزء رقم:-',str(YEl7NKbSXQHT)+' / '+str(xJLE9wZQa6))
	if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled(): return
	YEl7NKbSXQHT += 1
	del ggVZAItpXbPW6cq[dMu4F8L5Azo6IJ2aleywBmb]
	EETCAlxZ1nfYG4DjKkVBReU8pFu2yX[dMu4F8L5Azo6IJ2aleywBmb] = list(mQtbwgnGcTakM2BZAvjNO907WRV[dMu4F8L5Azo6IJ2aleywBmb].keys())
	lnzB93tKLeDabv[dMu4F8L5Azo6IJ2aleywBmb] = len(EETCAlxZ1nfYG4DjKkVBReU8pFu2yX[dMu4F8L5Azo6IJ2aleywBmb])
	VpnQLGFdJ07EIbDlaXi6 += lnzB93tKLeDabv[dMu4F8L5Azo6IJ2aleywBmb]
	return
def IIkGRs2DZjSTwozNq739adpAgy8bOJ(fTLHoIGS2JMYV3jKh7DuW0ke,dMu4F8L5Azo6IJ2aleywBmb):
	global jTG1aFtB8HM4zLXoUQygVu0RcOhv,ggVZAItpXbPW6cq,dybj5sgEH6RqTJYm2W0,mQtbwgnGcTakM2BZAvjNO907WRV,lnzB93tKLeDabv,EETCAlxZ1nfYG4DjKkVBReU8pFu2yX,VpnQLGFdJ07EIbDlaXi6,YEl7NKbSXQHT,xJLE9wZQa6
	sEyDZTBxj9l = cHa5JRAQ3ZKku7(fTLHoIGS2JMYV3jKh7DuW0ke,dMu4F8L5Azo6IJ2aleywBmb)
	for ood6Gh9mLZIcrSUO0zVERjsikg7x in range(1+lnzB93tKLeDabv[dMu4F8L5Azo6IJ2aleywBmb]//273):
		ym2HqhLuGcgRr = []
		eI0DEGAQmw3MspaUNdY7 = EETCAlxZ1nfYG4DjKkVBReU8pFu2yX[dMu4F8L5Azo6IJ2aleywBmb][0:273]
		for aBXgWuYGwdyS8k0jF4efM5QOcDL in eI0DEGAQmw3MspaUNdY7:
			ym2HqhLuGcgRr.append(mQtbwgnGcTakM2BZAvjNO907WRV[dMu4F8L5Azo6IJ2aleywBmb][aBXgWuYGwdyS8k0jF4efM5QOcDL])
		Qc96YoCZJOsKUB8yImw034(sEyDZTBxj9l,dMu4F8L5Azo6IJ2aleywBmb,eI0DEGAQmw3MspaUNdY7,ym2HqhLuGcgRr,iKYM8NdkGHmBcr,True)
		dybj5sgEH6RqTJYm2W0 += len(eI0DEGAQmw3MspaUNdY7)
		b8bEl0XjyR4hACKcYkJVP2oBavnGm1(jTG1aFtB8HM4zLXoUQygVu0RcOhv,75+int(20*dybj5sgEH6RqTJYm2W0//VpnQLGFdJ07EIbDlaXi6),'تخزين القوائم','القائمة رقم:-',str(dybj5sgEH6RqTJYm2W0)+' / '+str(VpnQLGFdJ07EIbDlaXi6))
		if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled(): return
		del EETCAlxZ1nfYG4DjKkVBReU8pFu2yX[dMu4F8L5Azo6IJ2aleywBmb][0:273]
	del mQtbwgnGcTakM2BZAvjNO907WRV[dMu4F8L5Azo6IJ2aleywBmb],EETCAlxZ1nfYG4DjKkVBReU8pFu2yX[dMu4F8L5Azo6IJ2aleywBmb],lnzB93tKLeDabv[dMu4F8L5Azo6IJ2aleywBmb]
	return
def KcRikAv9Zbmerd4W6Pp7j5TQ(fTLHoIGS2JMYV3jKh7DuW0ke,VqryRlBf2mx8n5oYOIH6SDp4zXb3,CaiGWx9HlMhRznyFDm1=True):
	v5OBhbICnwmWA8J2MzX7D = 'عدد فيديوهات جميع الروابط'
	to9lNhTbJRyLfzwv21Yina7sZrPC = cHa5JRAQ3ZKku7(fTLHoIGS2JMYV3jKh7DuW0ke,'LIVE_ORIGINAL_GROUPED')
	ezcN4709H8LoyRfIv2mb = cHa5JRAQ3ZKku7(fTLHoIGS2JMYV3jKh7DuW0ke,'VOD_ORIGINAL_GROUPED')
	if VqryRlBf2mx8n5oYOIH6SDp4zXb3:
		v5OBhbICnwmWA8J2MzX7D = 'عدد فيديوهات رابط '+KnGrOQsDgfB8Raj9C2AZJuYcTxP[int(VqryRlBf2mx8n5oYOIH6SDp4zXb3)]
		VqryRlBf2mx8n5oYOIH6SDp4zXb3 = '_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3
	RIpkMOAGTFo4tdSCw5c2NV = NUauTXxKLAoqQtJkglSFRWE(to9lNhTbJRyLfzwv21Yina7sZrPC,'int','IGNORED'+VqryRlBf2mx8n5oYOIH6SDp4zXb3,'__COUNT__')
	bRNq9uInalF82HKkweQfzs = NUauTXxKLAoqQtJkglSFRWE(to9lNhTbJRyLfzwv21Yina7sZrPC,'int','LIVE_ORIGINAL_GROUPED'+VqryRlBf2mx8n5oYOIH6SDp4zXb3,'__COUNT__')
	vnIcKWtFLACM4OHBalRuZmpX5P = NUauTXxKLAoqQtJkglSFRWE(ezcN4709H8LoyRfIv2mb,'int','VOD_ORIGINAL_GROUPED'+VqryRlBf2mx8n5oYOIH6SDp4zXb3,'__COUNT__')
	l5EGTb7pWO8BjvhCFaZK = NUauTXxKLAoqQtJkglSFRWE(to9lNhTbJRyLfzwv21Yina7sZrPC,'int','LIVE_GROUPED'+VqryRlBf2mx8n5oYOIH6SDp4zXb3,'__COUNT__')
	awQnMZS7z4Ed2 = NUauTXxKLAoqQtJkglSFRWE(to9lNhTbJRyLfzwv21Yina7sZrPC,'int','LIVE_UNKNOWN_GROUPED'+VqryRlBf2mx8n5oYOIH6SDp4zXb3,'__COUNT__')
	k0NjVb59KEIFxqCW4twTSgp = NUauTXxKLAoqQtJkglSFRWE(to9lNhTbJRyLfzwv21Yina7sZrPC,'int','VOD_MOVIES_GROUPED'+VqryRlBf2mx8n5oYOIH6SDp4zXb3,'__COUNT__')
	WLVxGpM6g3dk2vhq7fu4OrHnNsKP = NUauTXxKLAoqQtJkglSFRWE(ezcN4709H8LoyRfIv2mb,'int','VOD_SERIES_GROUPED'+VqryRlBf2mx8n5oYOIH6SDp4zXb3,'__COUNT__')
	EwGZL0Q7YhWNmdoO3MCfIjVK = NUauTXxKLAoqQtJkglSFRWE(to9lNhTbJRyLfzwv21Yina7sZrPC,'int','VOD_UNKNOWN_GROUPED'+VqryRlBf2mx8n5oYOIH6SDp4zXb3,'__COUNT__')
	EETCAlxZ1nfYG4DjKkVBReU8pFu2yX = NUauTXxKLAoqQtJkglSFRWE(ezcN4709H8LoyRfIv2mb,'list','VOD_SERIES_GROUPED'+VqryRlBf2mx8n5oYOIH6SDp4zXb3,'__GROUPS__')
	RQdB3OJPA7w1oT2i068Yb = []
	for aBXgWuYGwdyS8k0jF4efM5QOcDL,EoMKR2biY0 in EETCAlxZ1nfYG4DjKkVBReU8pFu2yX:
		VHDr1lgxBdwSPJy3KaTzRWcAhF = aBXgWuYGwdyS8k0jF4efM5QOcDL.split('__SERIES__')[1]
		RQdB3OJPA7w1oT2i068Yb.append(VHDr1lgxBdwSPJy3KaTzRWcAhF)
	fcDINanAQd2Lg = len(RQdB3OJPA7w1oT2i068Yb)
	Nkx1U6BAd2ClyzDqW0noOPj3h = int(k0NjVb59KEIFxqCW4twTSgp)+int(WLVxGpM6g3dk2vhq7fu4OrHnNsKP)+int(EwGZL0Q7YhWNmdoO3MCfIjVK)+int(awQnMZS7z4Ed2)+int(l5EGTb7pWO8BjvhCFaZK)
	GNjM8ZTxXRayUKe6qQ013p = ''
	GNjM8ZTxXRayUKe6qQ013p += 'قنوات: '+str(l5EGTb7pWO8BjvhCFaZK)
	GNjM8ZTxXRayUKe6qQ013p += '   .   أفلام: '+str(k0NjVb59KEIFxqCW4twTSgp)
	GNjM8ZTxXRayUKe6qQ013p += '\nمسلسلات: '+str(fcDINanAQd2Lg)
	GNjM8ZTxXRayUKe6qQ013p += '   .   حلقات: '+str(WLVxGpM6g3dk2vhq7fu4OrHnNsKP)
	GNjM8ZTxXRayUKe6qQ013p += '\nقنوات مجهولة: '+str(awQnMZS7z4Ed2)
	GNjM8ZTxXRayUKe6qQ013p += '   .   فيدوهات مجهولة: '+str(EwGZL0Q7YhWNmdoO3MCfIjVK)
	GNjM8ZTxXRayUKe6qQ013p += '\nمجموع القنوات: '+str(bRNq9uInalF82HKkweQfzs)
	GNjM8ZTxXRayUKe6qQ013p += '   .   مجموع الفيديوهات: '+str(vnIcKWtFLACM4OHBalRuZmpX5P)
	GNjM8ZTxXRayUKe6qQ013p += '\n\nمجموع المضافة: '+str(Nkx1U6BAd2ClyzDqW0noOPj3h)
	GNjM8ZTxXRayUKe6qQ013p += '   .   مجموع المهملة: '+str(RIpkMOAGTFo4tdSCw5c2NV)
	if CaiGWx9HlMhRznyFDm1: HHTzVhiY079bvdluNkFQ4wCMpe('center','',v5OBhbICnwmWA8J2MzX7D,GNjM8ZTxXRayUKe6qQ013p)
	eFfsirVWaXjT0EY21hG3 = GNjM8ZTxXRayUKe6qQ013p.replace('\n\n','\n')
	if not VqryRlBf2mx8n5oYOIH6SDp4zXb3: VqryRlBf2mx8n5oYOIH6SDp4zXb3 = 'All'
	else: VqryRlBf2mx8n5oYOIH6SDp4zXb3 = VqryRlBf2mx8n5oYOIH6SDp4zXb3[1]
	tr24ZoudmqvxfYCw('NOTICE','.  Counts of M3U videos   Folder: '+fTLHoIGS2JMYV3jKh7DuW0ke+'   Sequence: '+VqryRlBf2mx8n5oYOIH6SDp4zXb3+'\n'+eFfsirVWaXjT0EY21hG3)
	return GNjM8ZTxXRayUKe6qQ013p
def Xjs93SRJtwqc(fTLHoIGS2JMYV3jKh7DuW0ke,VqryRlBf2mx8n5oYOIH6SDp4zXb3,CaiGWx9HlMhRznyFDm1=True):
	if CaiGWx9HlMhRznyFDm1:
		Bkab1Avo3fYG9s6lZcOITDXd4MFi = OxCB4medn1('center','','','مسح ملفات M3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if Bkab1Avo3fYG9s6lZcOITDXd4MFi!=1: return
		Rt4WbmOnQpL = kyZdMcbuHrEwf.replace('___','_'+fTLHoIGS2JMYV3jKh7DuW0ke+'_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3)
		try: hhHq8m5vauKG9dl.remove(Rt4WbmOnQpL)
		except: pass
	sEyDZTBxj9l = cHa5JRAQ3ZKku7(fTLHoIGS2JMYV3jKh7DuW0ke,'')
	if VqryRlBf2mx8n5oYOIH6SDp4zXb3:
		s2sRHoSXwdf6JyKv5cNhlIxMLi1 = []
		for jTiMKWYxJDaOpzotgLq9 in FJLMxd8alBC7QbDKU9Onu2fw:
			s2sRHoSXwdf6JyKv5cNhlIxMLi1.append(jTiMKWYxJDaOpzotgLq9+'_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3)
		ibdKZ0sMlyrDcaJgPFV(sEyDZTBxj9l,'LINK_'+VqryRlBf2mx8n5oYOIH6SDp4zXb3)
	else:
		s2sRHoSXwdf6JyKv5cNhlIxMLi1 = FJLMxd8alBC7QbDKU9Onu2fw
		ibdKZ0sMlyrDcaJgPFV(sEyDZTBxj9l,'DUMMY')
		ibdKZ0sMlyrDcaJgPFV(sEyDZTBxj9l,'GROUPS')
		ibdKZ0sMlyrDcaJgPFV(sEyDZTBxj9l,'ITEMS')
		ibdKZ0sMlyrDcaJgPFV(sEyDZTBxj9l,'SEARCH')
	ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,'SECTIONS_M3U','SECTIONS_M3U_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	for dMu4F8L5Azo6IJ2aleywBmb in s2sRHoSXwdf6JyKv5cNhlIxMLi1:
		ibdKZ0sMlyrDcaJgPFV(sEyDZTBxj9l,dMu4F8L5Azo6IJ2aleywBmb)
	MCAInGyaz6mZwUx4gjqBb(False)
	m8mDHu2eZKoJCMXw3bPrUz(fTLHoIGS2JMYV3jKh7DuW0ke)
	if CaiGWx9HlMhRznyFDm1: HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
	return
def KHWOFrzptwybYx(fTLHoIGS2JMYV3jKh7DuW0ke='',CaiGWx9HlMhRznyFDm1=True):
	if fTLHoIGS2JMYV3jKh7DuW0ke:
		sEyDZTBxj9l = cHa5JRAQ3ZKku7(str(fTLHoIGS2JMYV3jKh7DuW0ke),'DUMMY')
		vWK3cmrB9SsT4dLwU = NUauTXxKLAoqQtJkglSFRWE(sEyDZTBxj9l,'str','DUMMY','__DUMMY__')
		if vWK3cmrB9SsT4dLwU: return True
	else:
		fTLHoIGS2JMYV3jKh7DuW0ke = '1'
		for r0djYXtTGD6HhniSkCp in range(1,SS2ZAHCRpu8QxIao7BMq+1):
			sEyDZTBxj9l = cHa5JRAQ3ZKku7(str(r0djYXtTGD6HhniSkCp),'DUMMY')
			vWK3cmrB9SsT4dLwU = NUauTXxKLAoqQtJkglSFRWE(sEyDZTBxj9l,'str','DUMMY','__DUMMY__')
			if vWK3cmrB9SsT4dLwU: return True
	if CaiGWx9HlMhRznyFDm1:
		t1meFNi6GvSy74xW = 'https://iptv-org.github.io/iptv/index.region.m3u'
		ff7Rbq2JAcFVzP = 'https://iptv-org.github.io/iptv/index.category.m3u'
		A2A7Bdm8paiofx6VsGPC4guXcTqZ = 'https://iptv-org.github.io/iptv/index.language.m3u'
		CCoFgQLE2JvP = 'https://iptv-org.github.io/iptv/index.country.m3u'
		JJrMeOz7VQ = t1meFNi6GvSy74xW+'\n'+ff7Rbq2JAcFVzP+'\n'+A2A7Bdm8paiofx6VsGPC4guXcTqZ+'\n'+CCoFgQLE2JvP
		Bkab1Avo3fYG9s6lZcOITDXd4MFi = OxCB4medn1('','','','رسالة من المبرمج','هذا الجزء من البرنامج يحتاج رابط فيديوهات نوعه M3U ومتوفر في الإنترنت مجانا وأيضا ممكن شراءه من الشركات المختصة . الموقع أدناه فيه روابط مجانية وهي ليست ملك المبرمج (صاحب هذا البرنامج) . ولا علاقة للمبرمج بمحتوياتها . والمبرمج لا يتحمل أي مسؤولية بسبب استخدام أي روابط مجانية أو غير مجانية\n [COLOR FFC89008]http://github.com/iptv-org/iptv[/COLOR]\nالروابط أدناه مجانية ومأخوذة من الموقع أعلاه هل تريد استخدامها\n [COLOR FFC89008]'+JJrMeOz7VQ+'[/COLOR]',profile='confirm_mediumfont')
		if Bkab1Avo3fYG9s6lZcOITDXd4MFi==1:
			j2agIU0xsLS6c7T.setSetting('av.m3u.url_'+str(fTLHoIGS2JMYV3jKh7DuW0ke)+'_1',t1meFNi6GvSy74xW)
			j2agIU0xsLS6c7T.setSetting('av.m3u.url_'+str(fTLHoIGS2JMYV3jKh7DuW0ke)+'_2',ff7Rbq2JAcFVzP)
			j2agIU0xsLS6c7T.setSetting('av.m3u.url_'+str(fTLHoIGS2JMYV3jKh7DuW0ke)+'_3',A2A7Bdm8paiofx6VsGPC4guXcTqZ)
			j2agIU0xsLS6c7T.setSetting('av.m3u.url_'+str(fTLHoIGS2JMYV3jKh7DuW0ke)+'_4',CCoFgQLE2JvP)
			Bkab1Avo3fYG9s6lZcOITDXd4MFi = OxCB4medn1('','','','رسالة من المبرمج','للاستفادة من روابط M3U التي أنت أضفتها للبرنامج .. أنت بحاجة إلى جلب ملفات هذه الروابط الجديدة .. هل تريد الآن جلب ملفات روابط M3U التي أنت أضفتها للبرنامج ؟!')
			if Bkab1Avo3fYG9s6lZcOITDXd4MFi==1:
				gQhs4bzO9lU = kV5DSBWMJ2ItamTpFd9PRNKsCGxc(fTLHoIGS2JMYV3jKh7DuW0ke)
				return gQhs4bzO9lU
		else:
			v5OBhbICnwmWA8J2MzX7D = 'إضافة وتغيير رابط '+KnGrOQsDgfB8Raj9C2AZJuYcTxP[1]+' (مجلد '+KnGrOQsDgfB8Raj9C2AZJuYcTxP[int(fTLHoIGS2JMYV3jKh7DuW0ke)]+')'
			Bkab1Avo3fYG9s6lZcOITDXd4MFi = OxCB4medn1('','','',v5OBhbICnwmWA8J2MzX7D,'لإضافة رابط M3U .. أولا أفتح قائمة M3U .. وثانيا أنقر على إضافة رابط أو اشتراك M3U .. وثالثا أنقر على جلب ملفات ـM3U \n\n هل تريد إضافة أو تغيير رابط M3U الآن ؟!')
			if Bkab1Avo3fYG9s6lZcOITDXd4MFi==1: gmfoXnU7hlQ5qL9euC(fTLHoIGS2JMYV3jKh7DuW0ke,'1')
	return False
def ZQTkpw4se6EOaIrgNLn(roQvPeSDl4p,fTLHoIGS2JMYV3jKh7DuW0ke='',dMu4F8L5Azo6IJ2aleywBmb='',uVGD6ZCHboELna3i7hKM4YPNS=''):
	if not uVGD6ZCHboELna3i7hKM4YPNS: uVGD6ZCHboELna3i7hKM4YPNS = '1'
	GlveBZnj3sLDrPIpJ64oi2aYW,xdWIA3KvVbtMaszgNPyZEn9fQ,CaiGWx9HlMhRznyFDm1 = XDzpr8RxgZhT(roQvPeSDl4p)
	if not KHWOFrzptwybYx(fTLHoIGS2JMYV3jKh7DuW0ke,CaiGWx9HlMhRznyFDm1): return
	if not GlveBZnj3sLDrPIpJ64oi2aYW:
		GlveBZnj3sLDrPIpJ64oi2aYW = CjyEnpfQ23o0PYwDtLId()
		if not GlveBZnj3sLDrPIpJ64oi2aYW: return
	JMrSWYaUBF = ['','LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not dMu4F8L5Azo6IJ2aleywBmb:
		if not CaiGWx9HlMhRznyFDm1:
			if   '_M3U-LIVE_' in xdWIA3KvVbtMaszgNPyZEn9fQ: dMu4F8L5Azo6IJ2aleywBmb = JMrSWYaUBF[1]
			elif '_M3U-MOVIES' in xdWIA3KvVbtMaszgNPyZEn9fQ: dMu4F8L5Azo6IJ2aleywBmb = JMrSWYaUBF[2]
			elif '_M3U-SERIES' in xdWIA3KvVbtMaszgNPyZEn9fQ: dMu4F8L5Azo6IJ2aleywBmb = JMrSWYaUBF[3]
			else: dMu4F8L5Azo6IJ2aleywBmb = JMrSWYaUBF[0]
		else:
			LhCbIcgYFi7 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			PTQimzWJpkrt6H = F2yZPukcUh09sqCI8nYw7e('أختر البحث المناسب', LhCbIcgYFi7)
			if PTQimzWJpkrt6H==-1: return
			dMu4F8L5Azo6IJ2aleywBmb = JMrSWYaUBF[PTQimzWJpkrt6H]
	GlveBZnj3sLDrPIpJ64oi2aYW = GlveBZnj3sLDrPIpJ64oi2aYW+'_NODIALOGS_'
	if fTLHoIGS2JMYV3jKh7DuW0ke: NBoCjHK6ITwgY5OxeuALPlZ(GlveBZnj3sLDrPIpJ64oi2aYW,fTLHoIGS2JMYV3jKh7DuW0ke,dMu4F8L5Azo6IJ2aleywBmb,uVGD6ZCHboELna3i7hKM4YPNS)
	else:
		for fTLHoIGS2JMYV3jKh7DuW0ke in range(1,SS2ZAHCRpu8QxIao7BMq+1):
			NBoCjHK6ITwgY5OxeuALPlZ(GlveBZnj3sLDrPIpJ64oi2aYW,str(fTLHoIGS2JMYV3jKh7DuW0ke),dMu4F8L5Azo6IJ2aleywBmb,uVGD6ZCHboELna3i7hKM4YPNS)
		OWasmQ27g3Dbljpo[:] = sorted(OWasmQ27g3Dbljpo,reverse=False,key=lambda JDv1uYxBEPcFGwrmlfzSOC: JDv1uYxBEPcFGwrmlfzSOC[1].lower())
	return
def NBoCjHK6ITwgY5OxeuALPlZ(roQvPeSDl4p,fTLHoIGS2JMYV3jKh7DuW0ke,dMu4F8L5Azo6IJ2aleywBmb='',uVGD6ZCHboELna3i7hKM4YPNS=''):
	if not uVGD6ZCHboELna3i7hKM4YPNS: uVGD6ZCHboELna3i7hKM4YPNS = '1'
	GlveBZnj3sLDrPIpJ64oi2aYW,xdWIA3KvVbtMaszgNPyZEn9fQ,CaiGWx9HlMhRznyFDm1 = XDzpr8RxgZhT(roQvPeSDl4p)
	if not fTLHoIGS2JMYV3jKh7DuW0ke: return
	if not KHWOFrzptwybYx(fTLHoIGS2JMYV3jKh7DuW0ke,CaiGWx9HlMhRznyFDm1): return
	if not GlveBZnj3sLDrPIpJ64oi2aYW:
		GlveBZnj3sLDrPIpJ64oi2aYW = CjyEnpfQ23o0PYwDtLId()
		if not GlveBZnj3sLDrPIpJ64oi2aYW: return
	JMrSWYaUBF = ['','LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not dMu4F8L5Azo6IJ2aleywBmb:
		if not CaiGWx9HlMhRznyFDm1:
			if   '_M3U-LIVE_' in xdWIA3KvVbtMaszgNPyZEn9fQ: dMu4F8L5Azo6IJ2aleywBmb = JMrSWYaUBF[1]
			elif '_M3U-MOVIES' in xdWIA3KvVbtMaszgNPyZEn9fQ: dMu4F8L5Azo6IJ2aleywBmb = JMrSWYaUBF[2]
			elif '_M3U-SERIES' in xdWIA3KvVbtMaszgNPyZEn9fQ: dMu4F8L5Azo6IJ2aleywBmb = JMrSWYaUBF[3]
			else: dMu4F8L5Azo6IJ2aleywBmb = JMrSWYaUBF[0]
		else:
			LhCbIcgYFi7 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			PTQimzWJpkrt6H = F2yZPukcUh09sqCI8nYw7e('أختر البحث المناسب', LhCbIcgYFi7)
			if PTQimzWJpkrt6H==-1: return
			dMu4F8L5Azo6IJ2aleywBmb = JMrSWYaUBF[PTQimzWJpkrt6H]
	MMdlOKoGAkNF1itxR = GlveBZnj3sLDrPIpJ64oi2aYW.lower()
	sEyDZTBxj9l = cHa5JRAQ3ZKku7(fTLHoIGS2JMYV3jKh7DuW0ke,'SEARCH')
	RqIMxSdNAFb7P = NUauTXxKLAoqQtJkglSFRWE(sEyDZTBxj9l,'list','SEARCH',(dMu4F8L5Azo6IJ2aleywBmb,MMdlOKoGAkNF1itxR))
	if not RqIMxSdNAFb7P:
		FFaATEPXyBgc1HGjhsfxu6pvRo9iQ2,W62w1knf98T43jsRYliCxr7q = [],[]
		if not dMu4F8L5Azo6IJ2aleywBmb: KocR8xBazfgkq = [1,2,3,4,5]
		else: KocR8xBazfgkq = [JMrSWYaUBF.index(dMu4F8L5Azo6IJ2aleywBmb)]
		for tdpTaMcz6ZfOUAvx0ByPnLrJob in KocR8xBazfgkq:
			if tdpTaMcz6ZfOUAvx0ByPnLrJob!=3:
				bb2Wi1TrnXpSA4wgfszMvcxd0O3mL = NUauTXxKLAoqQtJkglSFRWE(sEyDZTBxj9l,'dict',JMrSWYaUBF[tdpTaMcz6ZfOUAvx0ByPnLrJob])
				del bb2Wi1TrnXpSA4wgfszMvcxd0O3mL['__COUNT__']
				del bb2Wi1TrnXpSA4wgfszMvcxd0O3mL['__GROUPS__']
				del bb2Wi1TrnXpSA4wgfszMvcxd0O3mL['__SEQUENCED_COLUMNS__']
				EETCAlxZ1nfYG4DjKkVBReU8pFu2yX = list(bb2Wi1TrnXpSA4wgfszMvcxd0O3mL.keys())
				for aBXgWuYGwdyS8k0jF4efM5QOcDL in EETCAlxZ1nfYG4DjKkVBReU8pFu2yX:
					for dGlmU8JqW5yFAtcsg,yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0 in bb2Wi1TrnXpSA4wgfszMvcxd0O3mL[aBXgWuYGwdyS8k0jF4efM5QOcDL]:
						if MMdlOKoGAkNF1itxR in yHAD9oVfdieMNhC.lower(): W62w1knf98T43jsRYliCxr7q.append((yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0))
					del bb2Wi1TrnXpSA4wgfszMvcxd0O3mL[aBXgWuYGwdyS8k0jF4efM5QOcDL]
				del bb2Wi1TrnXpSA4wgfszMvcxd0O3mL
			else: EETCAlxZ1nfYG4DjKkVBReU8pFu2yX = NUauTXxKLAoqQtJkglSFRWE(sEyDZTBxj9l,'list',JMrSWYaUBF[tdpTaMcz6ZfOUAvx0ByPnLrJob],'__GROUPS__')
			for aBXgWuYGwdyS8k0jF4efM5QOcDL in EETCAlxZ1nfYG4DjKkVBReU8pFu2yX:
				try: aBXgWuYGwdyS8k0jF4efM5QOcDL,EoMKR2biY0 = aBXgWuYGwdyS8k0jF4efM5QOcDL
				except: EoMKR2biY0 = ''
				if MMdlOKoGAkNF1itxR in aBXgWuYGwdyS8k0jF4efM5QOcDL.lower():
					if tdpTaMcz6ZfOUAvx0ByPnLrJob!=3: uk96yvYDlRS7nMt0WeQ = aBXgWuYGwdyS8k0jF4efM5QOcDL
					else:
						Tu82Ar7n6YRQmGw1xze95jdKXy,O8o4wEI93GfiX7qCyKbe0BUF2 = aBXgWuYGwdyS8k0jF4efM5QOcDL.split('__SERIES__')
						if MMdlOKoGAkNF1itxR in Tu82Ar7n6YRQmGw1xze95jdKXy.lower(): uk96yvYDlRS7nMt0WeQ = Tu82Ar7n6YRQmGw1xze95jdKXy
						else: uk96yvYDlRS7nMt0WeQ = O8o4wEI93GfiX7qCyKbe0BUF2
					FFaATEPXyBgc1HGjhsfxu6pvRo9iQ2.append((aBXgWuYGwdyS8k0jF4efM5QOcDL,uk96yvYDlRS7nMt0WeQ,JMrSWYaUBF[tdpTaMcz6ZfOUAvx0ByPnLrJob],EoMKR2biY0))
			del EETCAlxZ1nfYG4DjKkVBReU8pFu2yX
		FFaATEPXyBgc1HGjhsfxu6pvRo9iQ2 = set(FFaATEPXyBgc1HGjhsfxu6pvRo9iQ2)
		W62w1knf98T43jsRYliCxr7q = set(W62w1knf98T43jsRYliCxr7q)
		FFaATEPXyBgc1HGjhsfxu6pvRo9iQ2 = sorted(FFaATEPXyBgc1HGjhsfxu6pvRo9iQ2,reverse=False,key=lambda JDv1uYxBEPcFGwrmlfzSOC: JDv1uYxBEPcFGwrmlfzSOC[1])
		W62w1knf98T43jsRYliCxr7q = sorted(W62w1knf98T43jsRYliCxr7q,reverse=False,key=lambda JDv1uYxBEPcFGwrmlfzSOC: JDv1uYxBEPcFGwrmlfzSOC[0])
		Qc96YoCZJOsKUB8yImw034(sEyDZTBxj9l,'SEARCH',(dMu4F8L5Azo6IJ2aleywBmb,MMdlOKoGAkNF1itxR),(FFaATEPXyBgc1HGjhsfxu6pvRo9iQ2,W62w1knf98T43jsRYliCxr7q),iKYM8NdkGHmBcr)
	else: FFaATEPXyBgc1HGjhsfxu6pvRo9iQ2,W62w1knf98T43jsRYliCxr7q = RqIMxSdNAFb7P
	EETCAlxZ1nfYG4DjKkVBReU8pFu2yX = len(FFaATEPXyBgc1HGjhsfxu6pvRo9iQ2)
	gBRxQhWFMtC7e6IHkAzG = len(W62w1knf98T43jsRYliCxr7q)
	NznapDvCteQPx = int(uVGD6ZCHboELna3i7hKM4YPNS)
	Q26QEy7iFXO = max(0,(NznapDvCteQPx-1)*100)
	uue4azx0AkgOTZH7hCItNbGVo = max(0,NznapDvCteQPx*100)
	vTOM0LeKpio8Sh5t = max(0,Q26QEy7iFXO-EETCAlxZ1nfYG4DjKkVBReU8pFu2yX)
	S7ysGgp0hKaqn2bWF = max(0,uue4azx0AkgOTZH7hCItNbGVo-EETCAlxZ1nfYG4DjKkVBReU8pFu2yX)
	for aBXgWuYGwdyS8k0jF4efM5QOcDL,uk96yvYDlRS7nMt0WeQ,aCQ7VGjZ6q5ry1ek,EoMKR2biY0 in FFaATEPXyBgc1HGjhsfxu6pvRo9iQ2[Q26QEy7iFXO:uue4azx0AkgOTZH7hCItNbGVo]:
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+uk96yvYDlRS7nMt0WeQ,aCQ7VGjZ6q5ry1ek,714,EoMKR2biY0,'1',aBXgWuYGwdyS8k0jF4efM5QOcDL,'',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
	del FFaATEPXyBgc1HGjhsfxu6pvRo9iQ2
	for yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0 in W62w1knf98T43jsRYliCxr7q[vTOM0LeKpio8Sh5t:S7ysGgp0hKaqn2bWF]:
		RRftazgYLTOxoBsZlhrwWq8 = fDEdQSsq1uPoU(gC2hO80boRyM7TBGqD)
		RGDQbxHAi1UpIuNveqTFXSw9gZjc4 = 'live'
		if '.mkv' in RRftazgYLTOxoBsZlhrwWq8 or 'VOD' in dMu4F8L5Azo6IJ2aleywBmb: RGDQbxHAi1UpIuNveqTFXSw9gZjc4 = 'video'
		Tca7NsYPkIRWtBpFgxLZbSmCi(RGDQbxHAi1UpIuNveqTFXSw9gZjc4,oYkzVLIgyjNpsiTbZSBQ+yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,715,EoMKR2biY0,'','','',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
	del W62w1knf98T43jsRYliCxr7q
	dlU0EksuLjrBaq(fTLHoIGS2JMYV3jKh7DuW0ke,uVGD6ZCHboELna3i7hKM4YPNS,dMu4F8L5Azo6IJ2aleywBmb,719,EETCAlxZ1nfYG4DjKkVBReU8pFu2yX+gBRxQhWFMtC7e6IHkAzG,GlveBZnj3sLDrPIpJ64oi2aYW+'_NODIALOGS_')
	return
def dlU0EksuLjrBaq(fTLHoIGS2JMYV3jKh7DuW0ke,uVGD6ZCHboELna3i7hKM4YPNS,dMu4F8L5Azo6IJ2aleywBmb,nnPsf4XLIJ7RWF,Nkx1U6BAd2ClyzDqW0noOPj3h,uHGMxiZfcoErOyXghvnWUK):
	if not uVGD6ZCHboELna3i7hKM4YPNS: uVGD6ZCHboELna3i7hKM4YPNS = '1'
	if uVGD6ZCHboELna3i7hKM4YPNS!='1': Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'صفحة '+str(1),dMu4F8L5Azo6IJ2aleywBmb,nnPsf4XLIJ7RWF,'',str(1),uHGMxiZfcoErOyXghvnWUK,'',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
	if not Nkx1U6BAd2ClyzDqW0noOPj3h: Nkx1U6BAd2ClyzDqW0noOPj3h = 0
	Ivhba2zeGcCo5NBDn7Fm0Zk9xY = int(Nkx1U6BAd2ClyzDqW0noOPj3h/100)+1
	for NznapDvCteQPx in range(2,Ivhba2zeGcCo5NBDn7Fm0Zk9xY):
		wjNixHdgWLyZS59I = (NznapDvCteQPx%10==0 or int(uVGD6ZCHboELna3i7hKM4YPNS)-4<NznapDvCteQPx<int(uVGD6ZCHboELna3i7hKM4YPNS)+4)
		p2pHPMV4sadmf8qJBOZb0 = (wjNixHdgWLyZS59I and int(uVGD6ZCHboELna3i7hKM4YPNS)-40<NznapDvCteQPx<int(uVGD6ZCHboELna3i7hKM4YPNS)+40)
		if str(NznapDvCteQPx)!=uVGD6ZCHboELna3i7hKM4YPNS and (NznapDvCteQPx%100==0 or p2pHPMV4sadmf8qJBOZb0):
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'صفحة '+str(NznapDvCteQPx),dMu4F8L5Azo6IJ2aleywBmb,nnPsf4XLIJ7RWF,'',str(NznapDvCteQPx),uHGMxiZfcoErOyXghvnWUK,'',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
	if str(Ivhba2zeGcCo5NBDn7Fm0Zk9xY)!=uVGD6ZCHboELna3i7hKM4YPNS: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'أخر صفحة '+str(Ivhba2zeGcCo5NBDn7Fm0Zk9xY),dMu4F8L5Azo6IJ2aleywBmb,nnPsf4XLIJ7RWF,'',str(Ivhba2zeGcCo5NBDn7Fm0Zk9xY),uHGMxiZfcoErOyXghvnWUK,'',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
	return
def cHa5JRAQ3ZKku7(fTLHoIGS2JMYV3jKh7DuW0ke,dMu4F8L5Azo6IJ2aleywBmb):
	sEyDZTBxj9l = n4ngaxMs3OK.replace('___','_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	return sEyDZTBxj9l
def kV5DSBWMJ2ItamTpFd9PRNKsCGxc(fTLHoIGS2JMYV3jKh7DuW0ke):
	sEyDZTBxj9l = cHa5JRAQ3ZKku7(fTLHoIGS2JMYV3jKh7DuW0ke,'')
	Bkab1Avo3fYG9s6lZcOITDXd4MFi = OxCB4medn1('center','','','رسالة من المبرمج','جلب ملفات M3U جديدة قد تحتاج عدة دقائق .. هل تريد أن تجلب الملفات الآن ؟!')
	if Bkab1Avo3fYG9s6lZcOITDXd4MFi!=1: return False
	MQ8XEa9BOq0cp6jwsZuxYoA(fTLHoIGS2JMYV3jKh7DuW0ke,False)
	QQ97UKAlijL0DEWMfmYVoONvdFzkSq = [0]
	for hcVjpT7mOqX in range(1,t7HERlKxBJpPfILviq9Y2Ge3d+1):
		bilOMVBfCKYU0a4Fqs3HX9hA = j2agIU0xsLS6c7T.getSetting('av.m3u.url_'+fTLHoIGS2JMYV3jKh7DuW0ke+'_'+str(hcVjpT7mOqX))
		if bilOMVBfCKYU0a4Fqs3HX9hA: OERZgyI3M0aDAXLvSiTpdjh1Q(fTLHoIGS2JMYV3jKh7DuW0ke,str(hcVjpT7mOqX))
		QQ97UKAlijL0DEWMfmYVoONvdFzkSq.append(0)
	for dMu4F8L5Azo6IJ2aleywBmb in FJLMxd8alBC7QbDKU9Onu2fw:
		QyJSYNRkZBqrF4Eu90s7bXM,lT6Vy8fUuJk,bge6Jao1P73ZvSpAXxwyf48,nY9HfTlN2dAW,Byw52HLiV0Udkbv = 0,{},[],[],[]
		for hcVjpT7mOqX in range(1,t7HERlKxBJpPfILviq9Y2Ge3d+1):
			aCQ7VGjZ6q5ry1ek = dMu4F8L5Azo6IJ2aleywBmb+'_'+str(hcVjpT7mOqX)
			ggVZAItpXbPW6cq = NUauTXxKLAoqQtJkglSFRWE(sEyDZTBxj9l,'dict',aCQ7VGjZ6q5ry1ek)
			try:
				l2qF5VtPwcMd7OGHh4XyDxi8Sk1RaZ = ggVZAItpXbPW6cq['__GROUPS__']
				AiP7CnItTsZS02c4vogWrVw = ggVZAItpXbPW6cq['__COUNT__']
			except: l2qF5VtPwcMd7OGHh4XyDxi8Sk1RaZ,AiP7CnItTsZS02c4vogWrVw = [],'0'
			for eqvRtVhybo0dLCFcuGIiQ8WTA in l2qF5VtPwcMd7OGHh4XyDxi8Sk1RaZ:
				aBXgWuYGwdyS8k0jF4efM5QOcDL,ggOIGYi4nEAJ2c8hvFufLRBq = eqvRtVhybo0dLCFcuGIiQ8WTA
				bb2Wi1TrnXpSA4wgfszMvcxd0O3mL = ggVZAItpXbPW6cq[aBXgWuYGwdyS8k0jF4efM5QOcDL]
				if aBXgWuYGwdyS8k0jF4efM5QOcDL not in nY9HfTlN2dAW:
					nY9HfTlN2dAW.append(aBXgWuYGwdyS8k0jF4efM5QOcDL)
					Byw52HLiV0Udkbv.append(eqvRtVhybo0dLCFcuGIiQ8WTA)
					lT6Vy8fUuJk[aBXgWuYGwdyS8k0jF4efM5QOcDL] = []
				lT6Vy8fUuJk[aBXgWuYGwdyS8k0jF4efM5QOcDL] += bb2Wi1TrnXpSA4wgfszMvcxd0O3mL
			ibdKZ0sMlyrDcaJgPFV(sEyDZTBxj9l,aCQ7VGjZ6q5ry1ek)
			Qc96YoCZJOsKUB8yImw034(sEyDZTBxj9l,aCQ7VGjZ6q5ry1ek,'__COUNT__',AiP7CnItTsZS02c4vogWrVw,iKYM8NdkGHmBcr)
			QQ97UKAlijL0DEWMfmYVoONvdFzkSq[hcVjpT7mOqX] += int(AiP7CnItTsZS02c4vogWrVw)
		for aBXgWuYGwdyS8k0jF4efM5QOcDL in nY9HfTlN2dAW:
			bb2Wi1TrnXpSA4wgfszMvcxd0O3mL = list(set(lT6Vy8fUuJk[aBXgWuYGwdyS8k0jF4efM5QOcDL]))
			if 'SORTED' in dMu4F8L5Azo6IJ2aleywBmb: bb2Wi1TrnXpSA4wgfszMvcxd0O3mL = sorted(bb2Wi1TrnXpSA4wgfszMvcxd0O3mL,reverse=False,key=lambda key: key[1].lower())
			QyJSYNRkZBqrF4Eu90s7bXM += len(bb2Wi1TrnXpSA4wgfszMvcxd0O3mL)
			bge6Jao1P73ZvSpAXxwyf48.append(bb2Wi1TrnXpSA4wgfszMvcxd0O3mL)
		Qc96YoCZJOsKUB8yImw034(sEyDZTBxj9l,dMu4F8L5Azo6IJ2aleywBmb,'__COUNT__',str(QyJSYNRkZBqrF4Eu90s7bXM),iKYM8NdkGHmBcr)
		Qc96YoCZJOsKUB8yImw034(sEyDZTBxj9l,dMu4F8L5Azo6IJ2aleywBmb,'__GROUPS__',Byw52HLiV0Udkbv,iKYM8NdkGHmBcr)
		Qc96YoCZJOsKUB8yImw034(sEyDZTBxj9l,dMu4F8L5Azo6IJ2aleywBmb,nY9HfTlN2dAW,bge6Jao1P73ZvSpAXxwyf48,iKYM8NdkGHmBcr,True)
	LLuW6KVoTPiBg2xY97JdkUaZeySQzq = False
	for hcVjpT7mOqX in range(1,t7HERlKxBJpPfILviq9Y2Ge3d+1):
		if int(QQ97UKAlijL0DEWMfmYVoONvdFzkSq[hcVjpT7mOqX])>0:
			bilOMVBfCKYU0a4Fqs3HX9hA = j2agIU0xsLS6c7T.getSetting('av.m3u.url_'+fTLHoIGS2JMYV3jKh7DuW0ke+'_'+str(hcVjpT7mOqX))
			Qc96YoCZJOsKUB8yImw034(sEyDZTBxj9l,'LINK_'+str(hcVjpT7mOqX),'__LINK__',bilOMVBfCKYU0a4Fqs3HX9hA,iKYM8NdkGHmBcr)
			LLuW6KVoTPiBg2xY97JdkUaZeySQzq = True
	Qc96YoCZJOsKUB8yImw034(sEyDZTBxj9l,'DUMMY','__DUMMY__','DUMMY',iKYM8NdkGHmBcr)
	if not LLuW6KVoTPiBg2xY97JdkUaZeySQzq:
		HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','فشل بسحب ملفات M3U .. أحتمال روابط M3U التي أنت أضفتها للبرنامج غير صحيحة .. علما أن هذه الخدمة تحتاج منك أن تضيف الرابط بنفسك للبرنامج باستخدام قائمة M3U الموجودة في هذا البرنامج')
		return False
	HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','تم جلب ملفات M3U جديدة')
	opD4a2icuhtnm9l6fMQqFbTv(fTLHoIGS2JMYV3jKh7DuW0ke)
	cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin('Container.Refresh')
	return True
def opD4a2icuhtnm9l6fMQqFbTv(fTLHoIGS2JMYV3jKh7DuW0ke):
	sEyDZTBxj9l = cHa5JRAQ3ZKku7(fTLHoIGS2JMYV3jKh7DuW0ke,'')
	if not KHWOFrzptwybYx(fTLHoIGS2JMYV3jKh7DuW0ke,True): return
	for hcVjpT7mOqX in range(1,t7HERlKxBJpPfILviq9Y2Ge3d+1):
		bilOMVBfCKYU0a4Fqs3HX9hA = NUauTXxKLAoqQtJkglSFRWE(sEyDZTBxj9l,'str','LINK_'+str(hcVjpT7mOqX),'__LINK__')
		if bilOMVBfCKYU0a4Fqs3HX9hA: GNjM8ZTxXRayUKe6qQ013p = KcRikAv9Zbmerd4W6Pp7j5TQ(fTLHoIGS2JMYV3jKh7DuW0ke,str(hcVjpT7mOqX))
	KcRikAv9Zbmerd4W6Pp7j5TQ(fTLHoIGS2JMYV3jKh7DuW0ke,'')
	return
def MQ8XEa9BOq0cp6jwsZuxYoA(fTLHoIGS2JMYV3jKh7DuW0ke,CaiGWx9HlMhRznyFDm1):
	if CaiGWx9HlMhRznyFDm1:
		Bkab1Avo3fYG9s6lZcOITDXd4MFi = OxCB4medn1('center','','','مسح ملفات ـM3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if Bkab1Avo3fYG9s6lZcOITDXd4MFi!=1: return
	sEyDZTBxj9l = cHa5JRAQ3ZKku7(fTLHoIGS2JMYV3jKh7DuW0ke,'')
	try: hhHq8m5vauKG9dl.remove(sEyDZTBxj9l)
	except: pass
	for hcVjpT7mOqX in range(1,t7HERlKxBJpPfILviq9Y2Ge3d+1):
		SSkZRKCX07 = kyZdMcbuHrEwf.replace('___','_'+fTLHoIGS2JMYV3jKh7DuW0ke+'_'+str(hcVjpT7mOqX))
		hEJiT97HuGl24LBAMfZdKe = hhHq8m5vauKG9dl.path.join(mATvU6VbxOXNFhz8lK5WGrfQ,SSkZRKCX07)
		try: hhHq8m5vauKG9dl.remove(hEJiT97HuGl24LBAMfZdKe)
		except: pass
	ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,'SECTIONS_M3U','SECTIONS_M3U_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	if CaiGWx9HlMhRznyFDm1:
		HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
		cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin('Container.Refresh')
	return
def m8mDHu2eZKoJCMXw3bPrUz(fTLHoIGS2JMYV3jKh7DuW0ke):
	EE27SGLBYTbWeywqmkVl61Hj = j2agIU0xsLS6c7T.getSetting('av.language.provider')
	OdLxAVyvHi5X1kq = j2agIU0xsLS6c7T.getSetting('av.language.code')
	ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,'MENUS_CACHE_'+EE27SGLBYTbWeywqmkVl61Hj+'_'+OdLxAVyvHi5X1kq,'%_MU'+fTLHoIGS2JMYV3jKh7DuW0ke+'_%')
	return
g4jfWB8sx6JrMONm2nKqGXluZw1Abc = {
		 'AF':'Afghanistan'
		,'AL':'Albania'
		,'DZ':'Algeria'
		,'AS':'American Samoa'
		,'AD':'Andorra'
		,'AO':'Angola'
		,'AI':'Anguilla'
		,'AQ':'Antarctica'
		,'AG':'Antigua and Barbuda'
		,'AR':'Argentina'
		,'AM':'Armenia'
		,'AW':'Aruba'
		,'AU':'Australia'
		,'AT':'Austria'
		,'AZ':'Azerbaijan'
		,'BS':'Bahamas'
		,'BH':'Bahrain'
		,'BD':'Bangladesh'
		,'BB':'Barbados'
		,'BY':'Belarus'
		,'BE':'Belgium'
		,'BZ':'Belize'
		,'BJ':'Benin'
		,'BM':'Bermuda'
		,'BT':'Bhutan'
		,'BO':'Bolivia'
		,'BQ':'Bonaire'
		,'BA':'Bosnia and Herzegovina'
		,'BW':'Botswana'
		,'BV':'Bouvet Island'
		,'BR':'Brazil'
		,'IO':'British Indian Ocean Territory'
		,'VG':'British Virgin Islands'
		,'BN':'Brunei'
		,'BG':'Bulgaria'
		,'BF':'Burkina Faso'
		,'BI':'Burundi'
		,'KH':'Cambodia'
		,'CM':'Cameroon'
		,'CA':'Canada'
		,'CV':'Cape Verde'
		,'KY':'Cayman Islands'
		,'CF':'Central African Republic'
		,'TD':'Chad'
		,'CL':'Chile'
		,'CN':'China'
		,'CX':'Christmas Island'
		,'CC':'Cocos (Keeling) Islands'
		,'CO':'Colombia'
		,'KM':'Comoros'
		,'CK':'Cook Islands'
		,'CR':'Costa Rica'
		,'HR':'Croatia'
		,'CU':'Cuba'
		,'CW':'Curacao'
		,'CY':'Cyprus'
		,'CZ':'Czech Republic'
		,'CD':'Democratic Republic of the Congo'
		,'DK':'Denmark'
		,'DJ':'Djibouti'
		,'DM':'Dominica'
		,'DO':'Dominican Republic'
		,'TL':'East Timor'
		,'EC':'Ecuador'
		,'EG':'Egypt'
		,'SV':'El Salvador'
		,'GQ':'Equatorial Guinea'
		,'ER':'Eritrea'
		,'EE':'Estonia'
		,'ET':'Ethiopia'
		,'FK':'Falkland Islands'
		,'FO':'Faroe Islands'
		,'FJ':'Fiji'
		,'FI':'Finland'
		,'FR':'France'
		,'GF':'French Guiana'
		,'PF':'French Polynesia'
		,'TF':'French Southern Territories'
		,'GA':'Gabon'
		,'GM':'Gambia'
		,'GE':'Georgia'
		,'DE':'Germany'
		,'GH':'Ghana'
		,'GI':'Gibraltar'
		,'GR':'Greece'
		,'GL':'Greenland'
		,'GD':'Grenada'
		,'GP':'Guadeloupe'
		,'GU':'Guam'
		,'GT':'Guatemala'
		,'GG':'Guernsey'
		,'GN':'Guinea'
		,'GW':'Guinea-Bissau'
		,'GY':'Guyana'
		,'HT':'Haiti'
		,'HM':'Heard Island and McDonald Islands'
		,'HN':'Honduras'
		,'HK':'Hong Kong'
		,'HU':'Hungary'
		,'IS':'Iceland'
		,'IN':'India'
		,'ID':'Indonesia'
		,'IR':'Iran'
		,'IQ':'Iraq'
		,'IE':'Ireland'
		,'IM':'Isle of Man'
		,'IL':'Israel'
		,'IT':'Italy'
		,'CI':'Ivory Coast'
		,'JM':'Jamaica'
		,'JP':'Japan'
		,'JE':'Jersey'
		,'JO':'Jordan'
		,'KZ':'Kazakhstan'
		,'KE':'Kenya'
		,'KI':'Kiribati'
		,'XK':'Kosovo'
		,'KW':'Kuwait'
		,'KG':'Kyrgyzstan'
		,'LA':'Laos'
		,'LV':'Latvia'
		,'LB':'Lebanon'
		,'LS':'Lesotho'
		,'LR':'Liberia'
		,'LY':'Libya'
		,'LI':'Liechtenstein'
		,'LT':'Lithuania'
		,'LU':'Luxembourg'
		,'MO':'Macao'
		,'MG':'Madagascar'
		,'MW':'Malawi'
		,'MY':'Malaysia'
		,'MV':'Maldives'
		,'ML':'Mali'
		,'MT':'Malta'
		,'MH':'Marshall Islands'
		,'MQ':'Martinique'
		,'MR':'Mauritania'
		,'MU':'Mauritius'
		,'YT':'Mayotte'
		,'MX':'Mexico'
		,'FM':'Micronesia'
		,'MD':'Moldova'
		,'MC':'Monaco'
		,'MN':'Mongolia'
		,'ME':'Montenegro'
		,'MS':'Montserrat'
		,'MA':'Morocco'
		,'MZ':'Mozambique'
		,'MM':'Myanmar (Burma)'
		,'NA':'Namibia'
		,'NR':'Nauru'
		,'NP':'Nepal'
		,'NL':'Netherlands'
		,'NC':'New Caledonia'
		,'NZ':'New Zealand'
		,'NI':'Nicaragua'
		,'NE':'Niger'
		,'NG':'Nigeria'
		,'NU':'Niue'
		,'NF':'Norfolk Island'
		,'KP':'North Korea'
		,'MK':'North Macedonia'
		,'MP':'Northern Mariana Islands'
		,'NO':'Norway'
		,'OM':'Oman'
		,'PK':'Pakistan'
		,'PW':'Palau'
		,'PS':'Palestine'
		,'PA':'Panama'
		,'PG':'Papua New Guinea'
		,'PY':'Paraguay'
		,'PE':'Peru'
		,'PH':'Philippines'
		,'PN':'Pitcairn Islands'
		,'PL':'Poland'
		,'PT':'Portugal'
		,'PR':'Puerto Rico'
		,'QA':'Qatar'
		,'CG':'Republic of the Congo'
		,'RO':'Romania'
		,'RU':'Russia'
		,'RW':'Rwanda'
		,'RE':'Réunion'
		,'BL':'Saint Barthélemy'
		,'SH':'Saint Helena'
		,'KN':'Saint Kitts and Nevis'
		,'LC':'Saint Lucia'
		,'MF':'Saint Martin'
		,'PM':'Saint Pierre and Miquelon'
		,'VC':'Saint Vincent and the Grenadines'
		,'WS':'Samoa'
		,'SM':'San Marino'
		,'SA':'Saudi Arabia'
		,'SN':'Senegal'
		,'RS':'Serbia'
		,'SC':'Seychelles'
		,'SL':'Sierra Leone'
		,'SG':'Singapore'
		,'SX':'Sint Maarten'
		,'SK':'Slovakia'
		,'SI':'Slovenia'
		,'SB':'Solomon Islands'
		,'SO':'Somalia'
		,'ZA':'South Africa'
		,'GS':'South Georgia and the South Sandwich Islands'
		,'KR':'South Korea'
		,'SS':'South Sudan'
		,'ES':'Spain'
		,'LK':'Sri Lanka'
		,'SD':'Sudan'
		,'SR':'Suriname'
		,'SJ':'Svalbard and Jan Mayen'
		,'SZ':'Swaziland'
		,'SE':'Sweden'
		,'CH':'Switzerland'
		,'SY':'Syria'
		,'ST':'São Tomé and Príncipe'
		,'TW':'Taiwan'
		,'TJ':'Tajikistan'
		,'TZ':'Tanzania'
		,'TH':'Thailand'
		,'TG':'Togo'
		,'TK':'Tokelau'
		,'TO':'Tonga'
		,'TT':'Trinidad and Tobago'
		,'TN':'Tunisia'
		,'TR':'Turkey'
		,'TM':'Turkmenistan'
		,'TC':'Turks and Caicos Islands'
		,'TV':'Tuvalu'
		,'UM':'U.S. Minor Outlying Islands'
		,'VI':'U.S. Virgin Islands'
		,'UG':'Uganda'
		,'UA':'Ukraine'
		,'AE':'United Arab Emirates'
		,'UK':'United Kingdom'
		,'US':'United States'
		,'UY':'Uruguay'
		,'UZ':'Uzbekistan'
		,'VU':'Vanuatu'
		,'VA':'Vatican City'
		,'VE':'Venezuela'
		,'VN':'Vietnam'
		,'WF':'Wallis and Futuna'
		,'EH':'Western Sahara'
		,'YE':'Yemen'
		,'ZM':'Zambia'
		,'ZW':'Zimbabwe'
		,'AX':'Åland'
		}
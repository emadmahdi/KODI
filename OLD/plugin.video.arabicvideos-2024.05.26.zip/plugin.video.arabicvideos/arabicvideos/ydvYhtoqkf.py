# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'FABRAKA'
W74fAyGxODoLPs5vMX2l8C93R = '_FBK_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
SmgoEYJ7uyL = ['الصفحة الرئيسية','Sign in']
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==620: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==621: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,text)
	elif mode==622: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==623: HkKfQCS7RIa4xi3houjvl = O3lxqtGmRwku(url,text)
	elif mode==624: HkKfQCS7RIa4xi3houjvl = yPzYJU5Wup8(url)
	elif mode==629: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	pp5vX2CWHBtwOPzdq0Junij7,url,wpFmEA3z8JR = UUNdIkbzF3lKquAsr4Q9TJnHM8tYOf(KxirmCLT6Gw,'GET',JJTrn6SEtYZV31eyR97,'fabraka','فبركة azureedge.net','كافة الحقوق محفوظة')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',629,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'جديد الحلقات',pp5vX2CWHBtwOPzdq0Junij7,621,'','','new_episodes')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'جديد الأفلام',pp5vX2CWHBtwOPzdq0Junij7,621,'','','new_movies')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'المسلسلات المميزة',pp5vX2CWHBtwOPzdq0Junij7,621,'','','featured_series')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"navslide-wrap"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not IZGcQbePXxwAoyYR1n:
		HHTzVhiY079bvdluNkFQ4wCMpe('','','موقع فبركة','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?</i>(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title in items:
		if title in SmgoEYJ7uyL: continue
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,624)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('/category.php">(.*?)"navslide-divider"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall("'dropdown-menu'(.*?)</ul>",QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	for i9jtofq4JrV in IZGcQbePXxwAoyYR1n: bdq4e6Wr2gslnSiA38 = bdq4e6Wr2gslnSiA38.replace(i9jtofq4JrV,'')
	items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title in items:
		if title in SmgoEYJ7uyL: continue
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,624)
	return
def yPzYJU5Wup8(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','FABRAKA-SUBMENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	Wgapb9wyGrVHo0 = ZXFs0mEPR8qI2zj.findall('"caret"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if Wgapb9wyGrVHo0:
		bdq4e6Wr2gslnSiA38 = Wgapb9wyGrVHo0[0]
		bdq4e6Wr2gslnSiA38 = bdq4e6Wr2gslnSiA38.replace('"presentation"','</ul>')
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if not IZGcQbePXxwAoyYR1n: IZGcQbePXxwAoyYR1n = [('',bdq4e6Wr2gslnSiA38)]
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] فرز أو فلتر أو ترتيب [/COLOR]','',9999)
		for VVDYC348bI1XgdZoh6QiuKEPL9,bdq4e6Wr2gslnSiA38 in IZGcQbePXxwAoyYR1n:
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			if VVDYC348bI1XgdZoh6QiuKEPL9: VVDYC348bI1XgdZoh6QiuKEPL9 = VVDYC348bI1XgdZoh6QiuKEPL9+': '
			for RRucmYBaXegTtNOdGHMQ,title in items:
				title = VVDYC348bI1XgdZoh6QiuKEPL9+title
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,621)
	CCqaV18lM0OL = ZXFs0mEPR8qI2zj.findall('"pm-category-subcats"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if CCqaV18lM0OL:
		bdq4e6Wr2gslnSiA38 = CCqaV18lM0OL[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if len(items)<30:
			Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			for RRucmYBaXegTtNOdGHMQ,title in items:
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,621)
	if not Wgapb9wyGrVHo0 and not CCqaV18lM0OL: RxAy5lEFQ1chv0BrdU4p6Pt2(url)
	return
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,l3UpyxrXZ2=''):
	if l3UpyxrXZ2=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'POST',url,data,headers,'','','FABRAKA-TITLES-1st')
	else:
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','FABRAKA-TITLES-2nd')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	bdq4e6Wr2gslnSiA38,items = '',[]
	pp5vX2CWHBtwOPzdq0Junij7 = d78KRnJmBWscGua0XMk(url,'url')
	if l3UpyxrXZ2=='ajax-search':
		bdq4e6Wr2gslnSiA38 = QstumvzTIEUMXCcx06aD4y8nSqH
		kYoiqbhP2AfzOHWmjxS69sNdM = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in kYoiqbhP2AfzOHWmjxS69sNdM: items.append(('',RRucmYBaXegTtNOdGHMQ,title))
	elif l3UpyxrXZ2=='featured':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"pm-video-watch-featured"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n: bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	elif l3UpyxrXZ2=='new_episodes':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"row pm-ul-browse-videos(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n: bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	elif l3UpyxrXZ2=='new_movies':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"row pm-ul-browse-videos(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if len(IZGcQbePXxwAoyYR1n)>1: bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[1]
	elif l3UpyxrXZ2=='featured_series':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n: bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		kYoiqbhP2AfzOHWmjxS69sNdM = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in kYoiqbhP2AfzOHWmjxS69sNdM: items.append(('',RRucmYBaXegTtNOdGHMQ,title))
	else:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('(data-echo=".*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n: bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	if bdq4e6Wr2gslnSiA38 and not items: items = ZXFs0mEPR8qI2zj.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	if not items: return
	FF1TYf6O5KENr8R72LUVievClmudxD = []
	QK2N8Bn0lLVdsURIgufJ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for CrGO63LT7j2UxniW,RRucmYBaXegTtNOdGHMQ,title in items:
		LqYKJ36CBG = ZXFs0mEPR8qI2zj.findall('(.*?) (الحلقة|حلقة).\d+',title,ZXFs0mEPR8qI2zj.DOTALL)
		if any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in QK2N8Bn0lLVdsURIgufJ):
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,622,CrGO63LT7j2UxniW)
		elif l3UpyxrXZ2=='new_episodes':
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,622,CrGO63LT7j2UxniW)
		elif LqYKJ36CBG:
			title = '_MOD_' + LqYKJ36CBG[0][0]
			if title not in FF1TYf6O5KENr8R72LUVievClmudxD:
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,623,CrGO63LT7j2UxniW)
				FF1TYf6O5KENr8R72LUVievClmudxD.append(title)
		else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,623,CrGO63LT7j2UxniW)
	if 1:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"pagination(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title in items:
				if RRucmYBaXegTtNOdGHMQ=='#': continue
				RRucmYBaXegTtNOdGHMQ = pp5vX2CWHBtwOPzdq0Junij7+'/'+RRucmYBaXegTtNOdGHMQ.strip('/')
				title = qpob7TvxHSs4fEzO6(title)
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,RRucmYBaXegTtNOdGHMQ,621)
	return
def O3lxqtGmRwku(url,xnu0LVmQHZEUyd9re8oKficb7):
	pp5vX2CWHBtwOPzdq0Junij7 = d78KRnJmBWscGua0XMk(url,'url')
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','FABRAKA-EPISODES-2nd')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	Wgapb9wyGrVHo0 = ZXFs0mEPR8qI2zj.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	ttiasLcTXGvgqb41nC7DRF = ZXFs0mEPR8qI2zj.findall('"series-header".*?src="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if ttiasLcTXGvgqb41nC7DRF: CrGO63LT7j2UxniW = ttiasLcTXGvgqb41nC7DRF[0]
	else: CrGO63LT7j2UxniW = ''
	items = []
	xeb5AvBIX0fTi4OKoEGdNW2M6L71Qn = False
	if Wgapb9wyGrVHo0 and not xnu0LVmQHZEUyd9re8oKficb7:
		bdq4e6Wr2gslnSiA38 = Wgapb9wyGrVHo0[0]
		items = ZXFs0mEPR8qI2zj.findall('''onclick="openCity\(event, '(.*?)'\)">(.*?)</button>''',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for xnu0LVmQHZEUyd9re8oKficb7,title in items:
			xnu0LVmQHZEUyd9re8oKficb7 = xnu0LVmQHZEUyd9re8oKficb7.strip('#')
			if len(items)>1: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,623,CrGO63LT7j2UxniW,'',xnu0LVmQHZEUyd9re8oKficb7)
			else: xeb5AvBIX0fTi4OKoEGdNW2M6L71Qn = True
	else: xeb5AvBIX0fTi4OKoEGdNW2M6L71Qn = True
	CCqaV18lM0OL = ZXFs0mEPR8qI2zj.findall('id="'+xnu0LVmQHZEUyd9re8oKficb7+'"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if CCqaV18lM0OL and xeb5AvBIX0fTi4OKoEGdNW2M6L71Qn:
		bdq4e6Wr2gslnSiA38 = CCqaV18lM0OL[0]
		kYoiqbhP2AfzOHWmjxS69sNdM = ZXFs0mEPR8qI2zj.findall('''href=['"](.*?)['"]><li><em>(.*?)</span>''',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		items = []
		for RRucmYBaXegTtNOdGHMQ,title in kYoiqbhP2AfzOHWmjxS69sNdM: items.append((RRucmYBaXegTtNOdGHMQ,title,CrGO63LT7j2UxniW))
		if not items: items = ZXFs0mEPR8qI2zj.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title,CrGO63LT7j2UxniW in items:
			RRucmYBaXegTtNOdGHMQ = pp5vX2CWHBtwOPzdq0Junij7+'/'+RRucmYBaXegTtNOdGHMQ.strip('/')
			title = title.replace('</em><span>',' ')
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,622,CrGO63LT7j2UxniW)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	yf608hE5KeRG1DscunvrU = []
	url = url.replace('watch.php','see.php')
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','FABRAKA-PLAY-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"WatchList"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('embed-url="(.*?)".*?<strong>(.*?)</strong>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+title+'__watch'
			yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ)
	RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall('<iframe src="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if RRucmYBaXegTtNOdGHMQ:
		RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ[0]+'?named='+title+'__embed'
		yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"downloadlist"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('download-url="(.*?)".*?<strong>(.*?)</strong>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+title+'__download'
			yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(yf608hE5KeRG1DscunvrU,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	search = search.replace(' ','+')
	url = JJTrn6SEtYZV31eyR97+'/search.php?keywords='+search
	pp5vX2CWHBtwOPzdq0Junij7,lQHXdV9Nzf6BLqS8D,qShkDLtUac9u = UUNdIkbzF3lKquAsr4Q9TJnHM8tYOf(KxirmCLT6Gw,'GET',url,'fabraka','فبركة azureedge.net','كافة الحقوق محفوظة')
	RxAy5lEFQ1chv0BrdU4p6Pt2(lQHXdV9Nzf6BLqS8D,'search')
	return
﻿# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'ALMAAREF'
headers = {'User-Agent':''}
W74fAyGxODoLPs5vMX2l8C93R = '_MRF_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
SmgoEYJ7uyL = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def OVQIAezo6U1NSTl4L(mode,url,text,wwNtFTLK2IqAszYBDV9J):
	if   mode==40: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==41: HkKfQCS7RIa4xi3houjvl = RRDqBGVHKunaeLk5hcsSvYr()
	elif mode==42: HkKfQCS7RIa4xi3houjvl = xxoh4fUtaG(text,wwNtFTLK2IqAszYBDV9J)
	elif mode==43: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==44: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(text,wwNtFTLK2IqAszYBDV9J)
	elif mode==49: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',49)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('live',W74fAyGxODoLPs5vMX2l8C93R+'البث الحي لقناة المعارف','',41)
	xxoh4fUtaG('','1')
	return
def jjNVJPRhKId1HO(Y9RKmgsxBefkFcuIj2GULDHy3,RSvuptrw51lZXB40fJNOWjbs9mUL):
	search,sort,iw2lpIWmKXrEnuayVe0xb,p8pgXONsjY,Iw5Ayziau6TSs8YmZb = '',[],[],[],[]
	vfLGDU1N0e8c,nS1HsV934UZ = hGMVvHBuPC014(Y9RKmgsxBefkFcuIj2GULDHy3)
	for Z7ZzgCTMBsNlVi9 in list(nS1HsV934UZ.keys()):
		AARNPWHjQU9dEmDI = nS1HsV934UZ[Z7ZzgCTMBsNlVi9]
		if not AARNPWHjQU9dEmDI: continue
		if   Z7ZzgCTMBsNlVi9=='sort': sort = [AARNPWHjQU9dEmDI]
		elif Z7ZzgCTMBsNlVi9=='series': iw2lpIWmKXrEnuayVe0xb = [AARNPWHjQU9dEmDI]
		elif Z7ZzgCTMBsNlVi9=='search': search = AARNPWHjQU9dEmDI
		elif Z7ZzgCTMBsNlVi9=='category': p8pgXONsjY = [AARNPWHjQU9dEmDI]
		elif Z7ZzgCTMBsNlVi9=='specialist': Iw5Ayziau6TSs8YmZb = [AARNPWHjQU9dEmDI]
	VbZ1Pig043uIGYQ = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":p8pgXONsjY,"specialist":Iw5Ayziau6TSs8YmZb,"series":iw2lpIWmKXrEnuayVe0xb,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(RSvuptrw51lZXB40fJNOWjbs9mUL)}}
	import json as VmSKvRtTw5WBYDI
	VbZ1Pig043uIGYQ = VmSKvRtTw5WBYDI.dumps(VbZ1Pig043uIGYQ)
	RRucmYBaXegTtNOdGHMQ = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'POST',RRucmYBaXegTtNOdGHMQ,VbZ1Pig043uIGYQ,'','','','ALMAAREF-REQUEST_DATA_PAGE-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	data = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('dict',QstumvzTIEUMXCcx06aD4y8nSqH)
	return data
def xxoh4fUtaG(Y9RKmgsxBefkFcuIj2GULDHy3,level):
	n5nyDgxTuHbY0LNV4cWvoBtp = jjNVJPRhKId1HO(Y9RKmgsxBefkFcuIj2GULDHy3,'1')
	bdq4e6Wr2gslnSiA38 = n5nyDgxTuHbY0LNV4cWvoBtp['facets']
	if level=='1':
		bdq4e6Wr2gslnSiA38 = bdq4e6Wr2gslnSiA38['video_categories']
		items = ZXFs0mEPR8qI2zj.findall('<div(.*?)/div>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for q8BXZlN9sU1fP2JAxH7W in items:
			p3pw6HeVfqXcFnT = ZXFs0mEPR8qI2zj.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',q8BXZlN9sU1fP2JAxH7W+'<',ZXFs0mEPR8qI2zj.DOTALL)
			if not p3pw6HeVfqXcFnT: p3pw6HeVfqXcFnT = ZXFs0mEPR8qI2zj.findall('data-value=\\"(.*?)\\">(.*?)<',q8BXZlN9sU1fP2JAxH7W+'<',ZXFs0mEPR8qI2zj.DOTALL)
			p8pgXONsjY,title = p3pw6HeVfqXcFnT[0]
			if not Y9RKmgsxBefkFcuIj2GULDHy3: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,'',42,'','2','?category='+p8pgXONsjY)
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,'',42,'','2',Y9RKmgsxBefkFcuIj2GULDHy3+'&category='+p8pgXONsjY)
	if level=='2':
		bdq4e6Wr2gslnSiA38 = bdq4e6Wr2gslnSiA38['specialist']
		items = ZXFs0mEPR8qI2zj.findall('value="(.*?)".*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for Iw5Ayziau6TSs8YmZb,title in items:
			if not Iw5Ayziau6TSs8YmZb: title = title = 'الجميع'
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,'',42,'','3',Y9RKmgsxBefkFcuIj2GULDHy3+'&specialist='+Iw5Ayziau6TSs8YmZb)
	elif level=='3':
		bdq4e6Wr2gslnSiA38 = bdq4e6Wr2gslnSiA38['series']
		items = ZXFs0mEPR8qI2zj.findall('value="(.*?)".*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for iw2lpIWmKXrEnuayVe0xb,title in items:
			if not iw2lpIWmKXrEnuayVe0xb: title = title = 'الجميع'
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,'',42,'','4',Y9RKmgsxBefkFcuIj2GULDHy3+'&series='+iw2lpIWmKXrEnuayVe0xb)
	elif level=='4':
		bdq4e6Wr2gslnSiA38 = bdq4e6Wr2gslnSiA38['sort_video']
		items = ZXFs0mEPR8qI2zj.findall('value="(.*?)".*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for sort,title in items:
			if not sort: continue
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,'',44,'','1',Y9RKmgsxBefkFcuIj2GULDHy3+'&sort='+sort)
	return
def RxAy5lEFQ1chv0BrdU4p6Pt2(Y9RKmgsxBefkFcuIj2GULDHy3,RSvuptrw51lZXB40fJNOWjbs9mUL):
	n5nyDgxTuHbY0LNV4cWvoBtp = jjNVJPRhKId1HO(Y9RKmgsxBefkFcuIj2GULDHy3,RSvuptrw51lZXB40fJNOWjbs9mUL)
	bdq4e6Wr2gslnSiA38 = n5nyDgxTuHbY0LNV4cWvoBtp['template']
	items = ZXFs0mEPR8qI2zj.findall('src="(.*?)".*?href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for CrGO63LT7j2UxniW,RRucmYBaXegTtNOdGHMQ,title in items:
		Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,43,CrGO63LT7j2UxniW)
	bdq4e6Wr2gslnSiA38 = n5nyDgxTuHbY0LNV4cWvoBtp['facets']['pagination']
	items = ZXFs0mEPR8qI2zj.findall('data-page="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for wwNtFTLK2IqAszYBDV9J,title in items:
		if RSvuptrw51lZXB40fJNOWjbs9mUL==wwNtFTLK2IqAszYBDV9J: continue
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,'',44,'',wwNtFTLK2IqAszYBDV9J,Y9RKmgsxBefkFcuIj2GULDHy3)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','ALMAAREF-PLAY-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall('<video src="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall('youtube_url.*?(http.*?)&',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	yf608hE5KeRG1DscunvrU = []
	if RRucmYBaXegTtNOdGHMQ:
		RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ[0].replace('\/','/')
		yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(yf608hE5KeRG1DscunvrU,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def RRDqBGVHKunaeLk5hcsSvYr():
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',JJTrn6SEtYZV31eyR97+'/بث-مباشر','','','','','ALMAAREF-LIVE-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	url = ZXFs0mEPR8qI2zj.findall('"svpPlayer".*?(http.*?)&',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	url = url[0].replace('\\','')
	w3hq0Xp8D9rZJ(url,ll6f2wvU4FdqL3MJyDxORESCK197i,'live')
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	O6PRYtegxX1Nn7TdIq = False
	if search=='':
		search = CjyEnpfQ23o0PYwDtLId()
		O6PRYtegxX1Nn7TdIq = True
	if search=='': return
	if not O6PRYtegxX1Nn7TdIq: RxAy5lEFQ1chv0BrdU4p6Pt2('?search='+search,'1')
	else: xxoh4fUtaG('?search='+search,'1')
	return
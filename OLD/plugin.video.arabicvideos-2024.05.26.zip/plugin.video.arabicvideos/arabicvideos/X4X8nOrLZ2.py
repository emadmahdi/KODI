# -*- coding: utf-8 -*-
import sys as ddABnr3K9Xv8e71CzcN0Pxt
NLQaPokgt7Zi = ddABnr3K9Xv8e71CzcN0Pxt.version_info [0] == 2
QzcRNkipwA1WPJu6ZoTnxrjBlqe2 = 2048
Y07K8pBzWtXncO9rUdsw1MTgAyFS = 7
def pFM6HfGd7Urbxto45vSNLniWA (gKVwro2lTJQEp):
	global AUQrTjaXt8K
	UUhFMplXo8RaCwxnEz5Hm7r = ord (gKVwro2lTJQEp [-1])
	slDu7whZzrU2b3oCYREig1L65F9HK = gKVwro2lTJQEp [:-1]
	Ha7jrvByPJYSIiRoXm5ThCOWc = UUhFMplXo8RaCwxnEz5Hm7r % len (slDu7whZzrU2b3oCYREig1L65F9HK)
	E5JVTBFqvjCN2Sc = slDu7whZzrU2b3oCYREig1L65F9HK [:Ha7jrvByPJYSIiRoXm5ThCOWc] + slDu7whZzrU2b3oCYREig1L65F9HK [Ha7jrvByPJYSIiRoXm5ThCOWc:]
	if NLQaPokgt7Zi:
		lK9D8U71rY = unicode () .join ([unichr (ord (ysjIJ8PTAQv5copxFkLUXrRwf) - QzcRNkipwA1WPJu6ZoTnxrjBlqe2 - (WutIpGj5YChbO + UUhFMplXo8RaCwxnEz5Hm7r) % Y07K8pBzWtXncO9rUdsw1MTgAyFS) for WutIpGj5YChbO, ysjIJ8PTAQv5copxFkLUXrRwf in enumerate (E5JVTBFqvjCN2Sc)])
	else:
		lK9D8U71rY = str () .join ([chr (ord (ysjIJ8PTAQv5copxFkLUXrRwf) - QzcRNkipwA1WPJu6ZoTnxrjBlqe2 - (WutIpGj5YChbO + UUhFMplXo8RaCwxnEz5Hm7r) % Y07K8pBzWtXncO9rUdsw1MTgAyFS) for WutIpGj5YChbO, ysjIJ8PTAQv5copxFkLUXrRwf in enumerate (E5JVTBFqvjCN2Sc)])
	return eval (lK9D8U71rY)
OVmSuf8tpd,LmcNhzY6fQPd2JyCGslkSr,J3OCAmZVcn=pFM6HfGd7Urbxto45vSNLniWA,pFM6HfGd7Urbxto45vSNLniWA,pFM6HfGd7Urbxto45vSNLniWA
eeIL1TfgFQJaKqVD8hGNPEZ,aFQoGfmYKyqLU6X8libw9k3ncW5,m6b7CoBk4EQ=J3OCAmZVcn,LmcNhzY6fQPd2JyCGslkSr,OVmSuf8tpd
ZSJVq5XDrRot,yTMWeCgUROcvtsblfK85L62xPk,AAgpHN0nMZ=m6b7CoBk4EQ,aFQoGfmYKyqLU6X8libw9k3ncW5,eeIL1TfgFQJaKqVD8hGNPEZ
XogUJZEijT7KWbxeO6,FhcnOB9t3frzvXb,aVLSn1xw5cK=AAgpHN0nMZ,yTMWeCgUROcvtsblfK85L62xPk,ZSJVq5XDrRot
ffCSGrTJYPsxgVQWKLtHU3iMwB,EDPaWgMt1SwNn8o,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg=aVLSn1xw5cK,FhcnOB9t3frzvXb,XogUJZEijT7KWbxeO6
Ej67fFyoqW8kbV2HdSK,kmdSKeBIwViM9t3,fR68jBGWCzUsFXdlTKPOScugm=PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg,EDPaWgMt1SwNn8o,ffCSGrTJYPsxgVQWKLtHU3iMwB
bdhQDyjm3nPwToFHkprvCzBLUGR,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r,wwyUWMFAsO=fR68jBGWCzUsFXdlTKPOScugm,kmdSKeBIwViM9t3,Ej67fFyoqW8kbV2HdSK
kRYWcNuAazr4jtmBoxFVS19Z6,pEo8g7riWVL014KaRtzQ,sArCMRngQNmXkBoKv=wwyUWMFAsO,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r,bdhQDyjm3nPwToFHkprvCzBLUGR
JMLhEyaBWmskovGHTrVCxQ08,MM2BQ7xrAfNivgenXPytGYOs0DEHRC,hjNP5w9srJz2QpVISxBfndbD4CkXvl=sArCMRngQNmXkBoKv,pEo8g7riWVL014KaRtzQ,kRYWcNuAazr4jtmBoxFVS19Z6
xuYvdJpOEyQKTLNwb,jYaM5vilgZdFx6QHbApwVXO8et,DLSVmlyBbCK=hjNP5w9srJz2QpVISxBfndbD4CkXvl,MM2BQ7xrAfNivgenXPytGYOs0DEHRC,JMLhEyaBWmskovGHTrVCxQ08
gnfv8UtZ3daGqpjzk,gSmqZU0plur2xKPJwQA,c4QSTnPiWUCjhrLlwGB=DLSVmlyBbCK,jYaM5vilgZdFx6QHbApwVXO8et,xuYvdJpOEyQKTLNwb
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = Ej67fFyoqW8kbV2HdSK(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
W74fAyGxODoLPs5vMX2l8C93R = xuYvdJpOEyQKTLNwb(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
ZxeyGAhgkw0 = hhHq8m5vauKG9dl.path.join(hWu2yd5fRP,MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
QW6SAqUaPfvZ5ND09BsMymXklc = hhHq8m5vauKG9dl.path.join(hWu2yd5fRP,ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
KiPpU9e6jqygN = hhHq8m5vauKG9dl.path.join(D2DYfsvFSG5CnV,c4QSTnPiWUCjhrLlwGB(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),gnfv8UtZ3daGqpjzk(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
BqI7y2Pf3CQgox0OTK1YRiZ6c = doZD3UL95pTEIiOkMXquRa
OOJZgqAMWb59 = pEo8g7riWVL014KaRtzQ(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
EAXn7k80C1csJFb6PlmZzG4dtYL = AAgpHN0nMZ(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
zz4JPswpn5lhEoxV = JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
v0On1zMHQiakguDJb6y = FhcnOB9t3frzvXb(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
Omy4KepldgXFP2saw7v = xuYvdJpOEyQKTLNwb(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
HwkAXq0Ss2 = pEo8g7riWVL014KaRtzQ(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
def OVQIAezo6U1NSTl4L(nnPsf4XLIJ7RWF):
	if   nnPsf4XLIJ7RWF==MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠹࠷࠴ࣉ"): HkKfQCS7RIa4xi3houjvl = YXfbyAx0eHNd3kScTVln()
	elif nnPsf4XLIJ7RWF==yTMWeCgUROcvtsblfK85L62xPk(u"࠺࠸࠶࣊"): HkKfQCS7RIa4xi3houjvl = Eux3w7MylkQfiBa6pvJO0FWTNbr(ZxeyGAhgkw0,jYaM5vilgZdFx6QHbApwVXO8et(u"ࡖࡵࡹࡪࣳ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࡖࡵࡹࡪࣳ"))
	elif nnPsf4XLIJ7RWF==MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠻࠹࠸࣋"): HkKfQCS7RIa4xi3houjvl = Eux3w7MylkQfiBa6pvJO0FWTNbr(QW6SAqUaPfvZ5ND09BsMymXklc,J3OCAmZVcn(u"ࡗࡶࡺ࡫ࣴ"),J3OCAmZVcn(u"ࡗࡶࡺ࡫ࣴ"))
	elif nnPsf4XLIJ7RWF==OVmSuf8tpd(u"࠼࠺࠳࣌"): HkKfQCS7RIa4xi3houjvl = Eux3w7MylkQfiBa6pvJO0FWTNbr(KiPpU9e6jqygN,gnfv8UtZ3daGqpjzk(u"ࡋࡧ࡬ࡴࡧࣶ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࡘࡷࡻࡥࣵ"))
	elif nnPsf4XLIJ7RWF==fR68jBGWCzUsFXdlTKPOScugm(u"࠽࠴࠵࣍"): HkKfQCS7RIa4xi3houjvl = o2VN9fiMqevhbFUEG(BqI7y2Pf3CQgox0OTK1YRiZ6c,JMLhEyaBWmskovGHTrVCxQ08(u"࡚ࡲࡶࡧࣷ"))
	elif nnPsf4XLIJ7RWF==Ej67fFyoqW8kbV2HdSK(u"࠷࠵࠷࣎"): HkKfQCS7RIa4xi3houjvl = z6TslkcXBbAEvaHNZ0ymR4i3h9(Ej67fFyoqW8kbV2HdSK(u"ࡔࡳࡷࡨࣸ"))
	elif nnPsf4XLIJ7RWF==FhcnOB9t3frzvXb(u"࠸࠷࠳࣏"): HkKfQCS7RIa4xi3houjvl = LalpMevruRgiKVnH3FUs0CJw6h41N()
	elif nnPsf4XLIJ7RWF==ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠹࠸࠵࣐"): HkKfQCS7RIa4xi3houjvl = Eux3w7MylkQfiBa6pvJO0FWTNbr(OOJZgqAMWb59,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࡈࡤࡰࡸ࡫ࣺ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࡕࡴࡸࡩࣹ"))
	elif nnPsf4XLIJ7RWF==OVmSuf8tpd(u"࠺࠹࠷࣑"): HkKfQCS7RIa4xi3houjvl = Eux3w7MylkQfiBa6pvJO0FWTNbr(EAXn7k80C1csJFb6PlmZzG4dtYL,bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࡊࡦࡲࡳࡦࣼ"),OVmSuf8tpd(u"ࡗࡶࡺ࡫ࣻ"))
	elif nnPsf4XLIJ7RWF==MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠻࠺࠹࣒"): HkKfQCS7RIa4xi3houjvl = Eux3w7MylkQfiBa6pvJO0FWTNbr(zz4JPswpn5lhEoxV,aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࡌࡡ࡭ࡵࡨࣾ"),LmcNhzY6fQPd2JyCGslkSr(u"࡙ࡸࡵࡦࣽ"))
	elif nnPsf4XLIJ7RWF==hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠼࠻࠴࣓"): HkKfQCS7RIa4xi3houjvl = Eux3w7MylkQfiBa6pvJO0FWTNbr(v0On1zMHQiakguDJb6y,gSmqZU0plur2xKPJwQA(u"ࡇࡣ࡯ࡷࡪऀ"),c4QSTnPiWUCjhrLlwGB(u"ࡔࡳࡷࡨࣿ"))
	elif nnPsf4XLIJ7RWF==DLSVmlyBbCK(u"࠽࠵࠶ࣔ"): HkKfQCS7RIa4xi3houjvl = Eux3w7MylkQfiBa6pvJO0FWTNbr(Omy4KepldgXFP2saw7v,kmdSKeBIwViM9t3(u"ࡉࡥࡱࡹࡥं"),ZSJVq5XDrRot(u"ࡖࡵࡹࡪँ"))
	elif nnPsf4XLIJ7RWF==gnfv8UtZ3daGqpjzk(u"࠷࠶࠸ࣕ"): HkKfQCS7RIa4xi3houjvl = Eux3w7MylkQfiBa6pvJO0FWTNbr(HwkAXq0Ss2,FhcnOB9t3frzvXb(u"ࡋࡧ࡬ࡴࡧऄ"),gSmqZU0plur2xKPJwQA(u"ࡘࡷࡻࡥः"))
	elif nnPsf4XLIJ7RWF==JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠸࠷࠺ࣖ"): HkKfQCS7RIa4xi3houjvl = ZYf5z3Psk948FH6gU(ZSJVq5XDrRot(u"࡚ࡲࡶࡧअ"))
	elif nnPsf4XLIJ7RWF==aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠹࠸࠼ࣗ"): HkKfQCS7RIa4xi3houjvl = l8y5QqEFRO2()
	else: HkKfQCS7RIa4xi3houjvl = m6b7CoBk4EQ(u"ࡆࡢ࡮ࡶࡩआ")
	return HkKfQCS7RIa4xi3houjvl
def YXfbyAx0eHNd3kScTVln():
	BFKLMWgzZhj0i7t,Uk2PHe9VtRvqBow7WM5cL41xsDZuY = dgXJVae1Tc3bs(ZxeyGAhgkw0)
	CxUZlS792TABDNbHosYWr0hztLpd,aw04q9uSlR2gZ1TdAkBh = dgXJVae1Tc3bs(QW6SAqUaPfvZ5ND09BsMymXklc)
	q8nAflcNhVOo74YeG3mdv,Ez0rFvaBj2xGqAbQ = dgXJVae1Tc3bs(KiPpU9e6jqygN)
	wEM5RNTuhApG6Y0KQXtb,hbNZwxCUVDX5yAEd = ssIxDJ3iKeVqBUvFYW4r(BqI7y2Pf3CQgox0OTK1YRiZ6c)
	wEM5RNTuhApG6Y0KQXtb -= EDPaWgMt1SwNn8o(u"࠶࠺࠽࠼࠴ࣘ")
	hbNZwxCUVDX5yAEd -= AAgpHN0nMZ(u"࠵ࣙ")
	oDhA56fLa0XZSWc3rzV = JMLhEyaBWmskovGHTrVCxQ08(u"ࠩࠣࠬࠬࠌ")+dUzYcBq3sJTS8MlV5u1jGmKwrNf(BFKLMWgzZhj0i7t)+ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠪࠤ࠲ࠦࠧࠍ")+str(Uk2PHe9VtRvqBow7WM5cL41xsDZuY)+xuYvdJpOEyQKTLNwb(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠎ")
	Qg3B18PfKv7kTZe = FhcnOB9t3frzvXb(u"ࠬࠦࠨࠨࠏ")+dUzYcBq3sJTS8MlV5u1jGmKwrNf(CxUZlS792TABDNbHosYWr0hztLpd)+gSmqZU0plur2xKPJwQA(u"࠭ࠠ࠮ࠢࠪࠐ")+str(aw04q9uSlR2gZ1TdAkBh)+ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠑ")
	qvmFG30k1AwZBY2uRSpWjI7xXsfdQD = yTMWeCgUROcvtsblfK85L62xPk(u"ࠨࠢࠫࠫࠒ")+dUzYcBq3sJTS8MlV5u1jGmKwrNf(q8nAflcNhVOo74YeG3mdv)+fR68jBGWCzUsFXdlTKPOScugm(u"ࠩࠣ࠱ࠥ࠭ࠓ")+str(Ez0rFvaBj2xGqAbQ)+c4QSTnPiWUCjhrLlwGB(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠔ")
	ZRKXMjwCptG = J3OCAmZVcn(u"ࠫࠥ࠮ࠧࠕ")+dUzYcBq3sJTS8MlV5u1jGmKwrNf(wEM5RNTuhApG6Y0KQXtb)+ZSJVq5XDrRot(u"ࠬ࠯ࠧࠖ")
	BiTmIq4QuGXHdOfwD9r = BFKLMWgzZhj0i7t+CxUZlS792TABDNbHosYWr0hztLpd+q8nAflcNhVOo74YeG3mdv+wEM5RNTuhApG6Y0KQXtb
	AiP7CnItTsZS02c4vogWrVw = Uk2PHe9VtRvqBow7WM5cL41xsDZuY+aw04q9uSlR2gZ1TdAkBh+Ez0rFvaBj2xGqAbQ+hbNZwxCUVDX5yAEd
	uHGMxiZfcoErOyXghvnWUK = PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭ࠠࠩࠩࠗ")+dUzYcBq3sJTS8MlV5u1jGmKwrNf(BiTmIq4QuGXHdOfwD9r)+FhcnOB9t3frzvXb(u"ࠧࠡ࠯ࠣࠫ࠘")+str(AiP7CnItTsZS02c4vogWrVw)+JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠙")
	Tca7NsYPkIRWtBpFgxLZbSmCi(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩ࡯࡭ࡳࡱࠧࠚ"),W74fAyGxODoLPs5vMX2l8C93R+aVLSn1xw5cK(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࠛ")+uHGMxiZfcoErOyXghvnWUK,Ej67fFyoqW8kbV2HdSK(u"ࠫࠬࠜ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠼࠺࠵ࣚ"))
	Tca7NsYPkIRWtBpFgxLZbSmCi(DLSVmlyBbCK(u"ࠬࡲࡩ࡯࡭ࠪࠝ"),c4QSTnPiWUCjhrLlwGB(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨࠞ"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠧࠨࠟ"),J3OCAmZVcn(u"࠿࠹࠺࠻ࣛ"))
	Tca7NsYPkIRWtBpFgxLZbSmCi(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨ࡮࡬ࡲࡰ࠭ࠠ"),W74fAyGxODoLPs5vMX2l8C93R+jYaM5vilgZdFx6QHbApwVXO8et(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠨࠡ")+oDhA56fLa0XZSWc3rzV,eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠪࠫࠢ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠷࠵࠳ࣜ"))
	Tca7NsYPkIRWtBpFgxLZbSmCi(J3OCAmZVcn(u"ࠫࡱ࡯࡮࡬ࠩࠣ"),W74fAyGxODoLPs5vMX2l8C93R+EDPaWgMt1SwNn8o(u"๋ࠬำฮࠢส่๊๊แศฬࠣห้๋ึ฻ฺ๊อࠬࠤ")+Qg3B18PfKv7kTZe,wwyUWMFAsO(u"࠭ࠧࠥ"),FhcnOB9t3frzvXb(u"࠸࠶࠵ࣝ"))
	Tca7NsYPkIRWtBpFgxLZbSmCi(JMLhEyaBWmskovGHTrVCxQ08(u"ࠧ࡭࡫ࡱ࡯ࠬࠦ"),W74fAyGxODoLPs5vMX2l8C93R+gnfv8UtZ3daGqpjzk(u"ࠨ็ึัࠥอไึ๊ิࠤฬ๊โะ์่อࠬࠧ")+qvmFG30k1AwZBY2uRSpWjI7xXsfdQD,jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩࠪࠨ"),DLSVmlyBbCK(u"࠹࠷࠷ࣞ"))
	Tca7NsYPkIRWtBpFgxLZbSmCi(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠪࡰ࡮ࡴ࡫ࠨࠩ"),W74fAyGxODoLPs5vMX2l8C93R+MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠫฯ็ั๋฼้้ࠣ็ࠠึ๊ิࠤฬ๊ลืษไหฯ࠭ࠪ")+ZRKXMjwCptG,c4QSTnPiWUCjhrLlwGB(u"ࠬ࠭ࠫ"),AAgpHN0nMZ(u"࠺࠸࠹ࣟ"))
	j2agIU0xsLS6c7T.setSetting(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࠬ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧࠨ࠭"))
	return
def LalpMevruRgiKVnH3FUs0CJw6h41N():
	lewSA0HM8D5BcohLZOYXGN = Ej67fFyoqW8kbV2HdSK(u"ࡖࡵࡹࡪई") if hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠨ࠱ࠪ࠮") in D2DYfsvFSG5CnV else ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࡇࡣ࡯ࡷࡪइ")
	if not lewSA0HM8D5BcohLZOYXGN:
		HHTzVhiY079bvdluNkFQ4wCMpe(yTMWeCgUROcvtsblfK85L62xPk(u"ࠩࠪ࠯"),FhcnOB9t3frzvXb(u"ࠪࠫ࠰"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ࠱"),gSmqZU0plur2xKPJwQA(u"ࠬ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣห้า็ศิ้ࠣฯ๎แาหࠣๅ็฽ࠠๅลฯ๋ืฯ๋๊้ࠠ็ุࠦ࠮࠯๋ࠢะ์อาไࠢ็๎ุࠦๅ็้ࠢ์฾๊้่ࠦๆืࠬ࠲"))
		return
	nnF1VOMIkrqi2ojXux6UPHGyEf7Kg = j2agIU0xsLS6c7T.getSetting(wwyUWMFAsO(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪ࠳"))
	if not nnF1VOMIkrqi2ojXux6UPHGyEf7Kg: l8y5QqEFRO2()
	BFKLMWgzZhj0i7t,Uk2PHe9VtRvqBow7WM5cL41xsDZuY = dgXJVae1Tc3bs(OOJZgqAMWb59)
	CxUZlS792TABDNbHosYWr0hztLpd,aw04q9uSlR2gZ1TdAkBh = dgXJVae1Tc3bs(EAXn7k80C1csJFb6PlmZzG4dtYL)
	q8nAflcNhVOo74YeG3mdv,Ez0rFvaBj2xGqAbQ = dgXJVae1Tc3bs(zz4JPswpn5lhEoxV)
	wEM5RNTuhApG6Y0KQXtb,hbNZwxCUVDX5yAEd = dgXJVae1Tc3bs(v0On1zMHQiakguDJb6y)
	x3SJ2aqHj6T,v9fgDr6kX4BZH8WA3CVb = dgXJVae1Tc3bs(Omy4KepldgXFP2saw7v)
	JRQzAXOHqKY5mcpj68nh,DVOCYMZiuT7Uh9SljABsf5 = dgXJVae1Tc3bs(HwkAXq0Ss2)
	oDhA56fLa0XZSWc3rzV = wwyUWMFAsO(u"ࠧࠡࠪࠪ࠴")+dUzYcBq3sJTS8MlV5u1jGmKwrNf(BFKLMWgzZhj0i7t)+FhcnOB9t3frzvXb(u"ࠨࠢ࠰ࠤࠬ࠵")+str(Uk2PHe9VtRvqBow7WM5cL41xsDZuY)+JMLhEyaBWmskovGHTrVCxQ08(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪ࠶")
	Qg3B18PfKv7kTZe = sArCMRngQNmXkBoKv(u"ࠪࠤ࠭࠭࠷")+dUzYcBq3sJTS8MlV5u1jGmKwrNf(CxUZlS792TABDNbHosYWr0hztLpd)+yTMWeCgUROcvtsblfK85L62xPk(u"ࠫࠥ࠳ࠠࠨ࠸")+str(aw04q9uSlR2gZ1TdAkBh)+sArCMRngQNmXkBoKv(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭࠹")
	qvmFG30k1AwZBY2uRSpWjI7xXsfdQD = XogUJZEijT7KWbxeO6(u"࠭ࠠࠩࠩ࠺")+dUzYcBq3sJTS8MlV5u1jGmKwrNf(q8nAflcNhVOo74YeG3mdv)+XogUJZEijT7KWbxeO6(u"ࠧࠡ࠯ࠣࠫ࠻")+str(Ez0rFvaBj2xGqAbQ)+pEo8g7riWVL014KaRtzQ(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠼")
	ZRKXMjwCptG = PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࠣࠬࠬ࠽")+dUzYcBq3sJTS8MlV5u1jGmKwrNf(wEM5RNTuhApG6Y0KQXtb)+JMLhEyaBWmskovGHTrVCxQ08(u"ࠪࠤ࠲ࠦࠧ࠾")+str(hbNZwxCUVDX5yAEd)+LmcNhzY6fQPd2JyCGslkSr(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬ࠿")
	HIe86yEGc91k0frQMsFmlTvhRD = AAgpHN0nMZ(u"ࠬࠦࠨࠨࡀ")+dUzYcBq3sJTS8MlV5u1jGmKwrNf(x3SJ2aqHj6T)+JMLhEyaBWmskovGHTrVCxQ08(u"࠭ࠠ࠮ࠢࠪࡁ")+str(v9fgDr6kX4BZH8WA3CVb)+ZSJVq5XDrRot(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࡂ")
	VV7qOYakwU8JshLeD34Rf2P = yTMWeCgUROcvtsblfK85L62xPk(u"ࠨࠢࠫࠫࡃ")+dUzYcBq3sJTS8MlV5u1jGmKwrNf(JRQzAXOHqKY5mcpj68nh)+wwyUWMFAsO(u"ࠩࠣ࠱ࠥ࠭ࡄ")+str(DVOCYMZiuT7Uh9SljABsf5)+kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡅ")
	BiTmIq4QuGXHdOfwD9r = BFKLMWgzZhj0i7t+CxUZlS792TABDNbHosYWr0hztLpd+q8nAflcNhVOo74YeG3mdv+wEM5RNTuhApG6Y0KQXtb+x3SJ2aqHj6T+JRQzAXOHqKY5mcpj68nh
	AiP7CnItTsZS02c4vogWrVw = Uk2PHe9VtRvqBow7WM5cL41xsDZuY+aw04q9uSlR2gZ1TdAkBh+Ez0rFvaBj2xGqAbQ+hbNZwxCUVDX5yAEd+v9fgDr6kX4BZH8WA3CVb+DVOCYMZiuT7Uh9SljABsf5
	uHGMxiZfcoErOyXghvnWUK = gSmqZU0plur2xKPJwQA(u"ࠫࠥ࠮ࠧࡆ")+dUzYcBq3sJTS8MlV5u1jGmKwrNf(BiTmIq4QuGXHdOfwD9r)+hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠬࠦ࠭ࠡࠩࡇ")+str(AiP7CnItTsZS02c4vogWrVw)+jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࡈ")
	Tca7NsYPkIRWtBpFgxLZbSmCi(Ej67fFyoqW8kbV2HdSK(u"ࠧ࡭࡫ࡱ࡯ࠬࡉ"),W74fAyGxODoLPs5vMX2l8C93R+eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨว฼฻ฬวࠠาะุอ่ࠥัศรฬࠤํ้สศสฬࠫࡊ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࠪࡋ"),Ej67fFyoqW8kbV2HdSK(u"࠻࠺࠾࣠"))
	Tca7NsYPkIRWtBpFgxLZbSmCi(EDPaWgMt1SwNn8o(u"ࠪࡰ࡮ࡴ࡫ࠨࡌ"),W74fAyGxODoLPs5vMX2l8C93R+kRYWcNuAazr4jtmBoxFVS19Z6(u"ู๊ࠫอࠡษ็ะ๊๐ูࠨࡍ")+uHGMxiZfcoErOyXghvnWUK,FhcnOB9t3frzvXb(u"ࠬ࠭ࡎ"),OVmSuf8tpd(u"࠼࠻࠷࣡"))
	Tca7NsYPkIRWtBpFgxLZbSmCi(AAgpHN0nMZ(u"࠭࡬ࡪࡰ࡮ࠫࡏ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࡐ"),kmdSKeBIwViM9t3(u"ࠨࠩࡑ"),ZSJVq5XDrRot(u"࠿࠹࠺࠻࣢"))
	Tca7NsYPkIRWtBpFgxLZbSmCi(ZSJVq5XDrRot(u"ࠩ࡯࡭ࡳࡱࠧࡒ"),W74fAyGxODoLPs5vMX2l8C93R+kRYWcNuAazr4jtmBoxFVS19Z6(u"ุ้ࠪำࠠๆๆไหฯࠦࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠪࡓ")+oDhA56fLa0XZSWc3rzV,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠫࠬࡔ"),xuYvdJpOEyQKTLNwb(u"࠷࠶࠳ࣣ"))
	Tca7NsYPkIRWtBpFgxLZbSmCi(DLSVmlyBbCK(u"ࠬࡲࡩ࡯࡭ࠪࡕ"),W74fAyGxODoLPs5vMX2l8C93R+sArCMRngQNmXkBoKv(u"࠭ๅิฯ้้ࠣ็วหࠢࡧࡶࡴࡶࡢࡰࡺࠪࡖ")+Qg3B18PfKv7kTZe,JMLhEyaBWmskovGHTrVCxQ08(u"ࠧࠨࡗ"),fR68jBGWCzUsFXdlTKPOScugm(u"࠸࠷࠵ࣤ"))
	Tca7NsYPkIRWtBpFgxLZbSmCi(aVLSn1xw5cK(u"ࠨ࡮࡬ࡲࡰ࠭ࡘ"),W74fAyGxODoLPs5vMX2l8C93R+wwyUWMFAsO(u"่ࠩืาࠦๅๅใสฮࠥࡺ࡯࡮ࡤࡶࡸࡴࡴࡥࡴ࡙ࠩ")+qvmFG30k1AwZBY2uRSpWjI7xXsfdQD,bdhQDyjm3nPwToFHkprvCzBLUGR(u"࡚ࠪࠫ"),pEo8g7riWVL014KaRtzQ(u"࠹࠸࠷ࣥ"))
	Tca7NsYPkIRWtBpFgxLZbSmCi(JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࡱ࡯࡮࡬࡛ࠩ"),W74fAyGxODoLPs5vMX2l8C93R+gSmqZU0plur2xKPJwQA(u"๋ࠬำฮ่่ࠢๆอสࠡ࡮ࡲ࡫࡬࡫ࡲࠨ࡜")+ZRKXMjwCptG,bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࠧ࡝"),eeIL1TfgFQJaKqVD8hGNPEZ(u"࠺࠹࠹ࣦ"))
	Tca7NsYPkIRWtBpFgxLZbSmCi(gnfv8UtZ3daGqpjzk(u"ࠧ࡭࡫ࡱ࡯ࠬ࡞"),W74fAyGxODoLPs5vMX2l8C93R+sArCMRngQNmXkBoKv(u"ࠨ็ึั๋ࠥไโษอࠤࡱࡵࡧࠨ࡟")+HIe86yEGc91k0frQMsFmlTvhRD,m6b7CoBk4EQ(u"ࠩࠪࡠ"),J3OCAmZVcn(u"࠻࠺࠻ࣧ"))
	Tca7NsYPkIRWtBpFgxLZbSmCi(aVLSn1xw5cK(u"ࠪࡰ࡮ࡴ࡫ࠨࡡ"),W74fAyGxODoLPs5vMX2l8C93R+kmdSKeBIwViM9t3(u"ู๊ࠫอࠡ็็ๅฬะࠠࡢࡰࡵࠫࡢ")+VV7qOYakwU8JshLeD34Rf2P,bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠬ࠭ࡣ"),kmdSKeBIwViM9t3(u"࠼࠻࠶ࣨ"))
	j2agIU0xsLS6c7T.setSetting(Ej67fFyoqW8kbV2HdSK(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࡤ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠧࠨࡥ"))
	return
def l8y5QqEFRO2():
	YYkEu4IL0sTa = OxCB4medn1(ZSJVq5XDrRot(u"ࠨࠩࡦ"),aVLSn1xw5cK(u"ࠩࠪࡧ"),aVLSn1xw5cK(u"ࠪࠫࡨ"),OVmSuf8tpd(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࡩ"),DLSVmlyBbCK(u"๊ࠬใ๋ࠢํ฽๊๊ࠠศๆอ๊฽๐แࠡ฻้ำ่ࠦ࠮࠯ࠢหี๋อๅอࠢ฼้ฬีࠠษฯสะฮࠦลๅ๋ࠣษ฾฽วยࠢิาฺฯࠠศๆๅีฬวษ๊ࠡส่่ะวษห่้๋ࠣไโษอࠤํอไๆฮ็ำฬะࠠศๆอ๎ู่ࠥโࠢํุ้ำ็ศࠢส่อืๆศ็ฯࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡว฼฻ฬว่ࠠา๊ࠤฬ๊ัฯืฬࠤฬ๊ย็ࠢยࠥࠬࡪ"))
	if YYkEu4IL0sTa==-fR68jBGWCzUsFXdlTKPOScugm(u"࠷ࣩ"): return
	if YYkEu4IL0sTa:
		import subprocess as a8ARByYenzNJF3COjZmdlMiS9h
		try:
			a8ARByYenzNJF3COjZmdlMiS9h.Popen(DLSVmlyBbCK(u"࠭ࡳࡶࠩ࡫"))
			GpwOQ0j4DkWLCnHriYP = Ej67fFyoqW8kbV2HdSK(u"ࡗࡶࡺ࡫उ")
		except: GpwOQ0j4DkWLCnHriYP = pEo8g7riWVL014KaRtzQ(u"ࡊࡦࡲࡳࡦऊ")
		if GpwOQ0j4DkWLCnHriYP:
			t6j2Vgzmr1nebEda3iB0C = OOJZgqAMWb59+hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧࠡࠩ࡬")+EAXn7k80C1csJFb6PlmZzG4dtYL+EDPaWgMt1SwNn8o(u"ࠨࠢࠪ࡭")+zz4JPswpn5lhEoxV+fR68jBGWCzUsFXdlTKPOScugm(u"ࠩࠣࠫ࡮")+v0On1zMHQiakguDJb6y+c4QSTnPiWUCjhrLlwGB(u"ࠪࠤࠬ࡯")+Omy4KepldgXFP2saw7v+OVmSuf8tpd(u"ࠫࠥ࠭ࡰ")+HwkAXq0Ss2
			naJTqyMAXxQPLmZUiKGSd1DH = a8ARByYenzNJF3COjZmdlMiS9h.Popen(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠬࡹࡵࠡ࠯ࡦࠤࠧࡩࡨ࡮ࡱࡧࠤ࠲ࡘࠠ࠱࠹࠺࠻ࠥ࠭ࡱ")+t6j2Vgzmr1nebEda3iB0C+EDPaWgMt1SwNn8o(u"࠭ࠢࠨࡲ"),shell=hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࡙ࡸࡵࡦऋ"),stdin=a8ARByYenzNJF3COjZmdlMiS9h.PIPE,stdout=a8ARByYenzNJF3COjZmdlMiS9h.PIPE,stderr=a8ARByYenzNJF3COjZmdlMiS9h.PIPE)
			HHTzVhiY079bvdluNkFQ4wCMpe(XogUJZEijT7KWbxeO6(u"ࠧࠨࡳ"),LmcNhzY6fQPd2JyCGslkSr(u"ࠨࠩࡴ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡵ"),OVmSuf8tpd(u"๊ࠪัำสࠡ฻่่๏ฯࠠฦ฻ฺหฦࠦวๅำัูฮ࠭ࡶ"))
			j2agIU0xsLS6c7T.setSetting(yTMWeCgUROcvtsblfK85L62xPk(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨࡷ"),wwyUWMFAsO(u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨࡸ"))
			cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(Ej67fFyoqW8kbV2HdSK(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪࡹ"))
		else: HHTzVhiY079bvdluNkFQ4wCMpe(EDPaWgMt1SwNn8o(u"ࠧࠨࡺ"),Ej67fFyoqW8kbV2HdSK(u"ࠨࠩࡻ"),XogUJZEijT7KWbxeO6(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡼ"),ZSJVq5XDrRot(u"ࠪ฽๊๊๊สࠢศ฽฼อมࠡำัูฮࠦวๅไิหฦฯ้ࠠษ็็ฯอศสࠢอัฯอฬࠡสิ๊ฬ๋ฬࠡࠢࡵࡳࡴࡺࠠࠡล๋ࠤࠥࡹࡵࡱࡧࡵࡹࡸ࡫ࡲࠡࠢฦ์ࠥࠦࡳࡶࠢࠣ์ัํวำๅ่ࠣฬ๊้ࠦฮาࠤๆ๐็้ࠡำหࠥอไษำ้ห๊าࠠ࠯࠰ࠣวํࠦใ้ัํࠤ฿๐ัࠡไสำึูࠦๅ๋ࠣหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠪࡽ"))
	return
def dUzYcBq3sJTS8MlV5u1jGmKwrNf(BiTmIq4QuGXHdOfwD9r):
	for s9DIkYgQhV8dAR in [EDPaWgMt1SwNn8o(u"ࠫࡇ࠭ࡾ"),gSmqZU0plur2xKPJwQA(u"ࠬࡑࡂࠨࡿ"),JMLhEyaBWmskovGHTrVCxQ08(u"࠭ࡍࡃࠩࢀ"),sArCMRngQNmXkBoKv(u"ࠧࡈࡄࠪࢁ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࡖࡅࠫࢂ")]:
		if BiTmIq4QuGXHdOfwD9r<aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠱࠱࠴࠷࣪"): break
		else: BiTmIq4QuGXHdOfwD9r /= hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠲࠲࠵࠸࠳࠶࣫")
	uHGMxiZfcoErOyXghvnWUK = aVLSn1xw5cK(u"ࠤࠨ࠷࠳࠷ࡦࠡࠧࡶࠦࢃ")%(BiTmIq4QuGXHdOfwD9r,s9DIkYgQhV8dAR)
	return uHGMxiZfcoErOyXghvnWUK
def dgXJVae1Tc3bs(uc9SVH5ChP8yn47MOkQzD=aVLSn1xw5cK(u"ࠪ࠲ࠬࢄ")):
	global ra7vkgAJEMuF,f42fXbxnw1Ei8tY6IOcsDZ0uykov
	ra7vkgAJEMuF,f42fXbxnw1Ei8tY6IOcsDZ0uykov = DLSVmlyBbCK(u"࠲࣬"),DLSVmlyBbCK(u"࠲࣬")
	def ylO0qA97SV(uc9SVH5ChP8yn47MOkQzD):
		global ra7vkgAJEMuF,f42fXbxnw1Ei8tY6IOcsDZ0uykov
		if hhHq8m5vauKG9dl.path.exists(uc9SVH5ChP8yn47MOkQzD):
			if LmcNhzY6fQPd2JyCGslkSr(u"࠳࣭") and JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࡸࡩࡡ࡯ࡦ࡬ࡶࠬࢅ") in dir(hhHq8m5vauKG9dl):
				for cQRN456Du2qP3lK in hhHq8m5vauKG9dl.scandir(uc9SVH5ChP8yn47MOkQzD):
					if cQRN456Du2qP3lK.is_dir(follow_symlinks=XogUJZEijT7KWbxeO6(u"ࡌࡡ࡭ࡵࡨऌ")):
						ylO0qA97SV(cQRN456Du2qP3lK.path)
					elif cQRN456Du2qP3lK.is_file(follow_symlinks=EDPaWgMt1SwNn8o(u"ࡆࡢ࡮ࡶࡩऍ")):
						ra7vkgAJEMuF += cQRN456Du2qP3lK.stat().st_size
						f42fXbxnw1Ei8tY6IOcsDZ0uykov += XogUJZEijT7KWbxeO6(u"࠵࣮")
			else:
				for cQRN456Du2qP3lK in hhHq8m5vauKG9dl.listdir(uc9SVH5ChP8yn47MOkQzD):
					x2B7p6d5qXaW8wnluf1jKeVZcENI = hhHq8m5vauKG9dl.path.abspath(hhHq8m5vauKG9dl.path.join(uc9SVH5ChP8yn47MOkQzD,cQRN456Du2qP3lK))
					if hhHq8m5vauKG9dl.path.isdir(x2B7p6d5qXaW8wnluf1jKeVZcENI):
						ylO0qA97SV(x2B7p6d5qXaW8wnluf1jKeVZcENI)
					elif hhHq8m5vauKG9dl.path.isfile(x2B7p6d5qXaW8wnluf1jKeVZcENI):
						BiTmIq4QuGXHdOfwD9r,AiP7CnItTsZS02c4vogWrVw = ssIxDJ3iKeVqBUvFYW4r(x2B7p6d5qXaW8wnluf1jKeVZcENI)
						ra7vkgAJEMuF += BiTmIq4QuGXHdOfwD9r
						f42fXbxnw1Ei8tY6IOcsDZ0uykov += AiP7CnItTsZS02c4vogWrVw
		return
	try: ylO0qA97SV(uc9SVH5ChP8yn47MOkQzD)
	except: pass
	return ra7vkgAJEMuF,f42fXbxnw1Ei8tY6IOcsDZ0uykov
def lLw9xF0vuYsQGS1VJdz2yMgUTfbXC5(ixSThkcrAXvD60ZBGPjLmN5f,showDialogs):
	if showDialogs:
		YYkEu4IL0sTa = OxCB4medn1(gSmqZU0plur2xKPJwQA(u"ࠬ࠭ࢆ"),DLSVmlyBbCK(u"࠭ࠧࢇ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࠨ࢈"),gnfv8UtZ3daGqpjzk(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࢉ"),ixSThkcrAXvD60ZBGPjLmN5f+gnfv8UtZ3daGqpjzk(u"ࠩ࡟ࡲࡡࡴࠧࢊ")+jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่่ๆࠦฟࠢ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢋ"))
		if YYkEu4IL0sTa!=aVLSn1xw5cK(u"࠶࣯"): return
	ASQ7g4cylNwRY3baIWunCpJ = OVmSuf8tpd(u"ࡇࡣ࡯ࡷࡪऎ")
	if hhHq8m5vauKG9dl.path.exists(ixSThkcrAXvD60ZBGPjLmN5f):
		try: hhHq8m5vauKG9dl.remove(ixSThkcrAXvD60ZBGPjLmN5f)
		except Exception as qqSysvtkjrMVYn0d:
			if showDialogs: HHTzVhiY079bvdluNkFQ4wCMpe(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫࠬࢌ"),ZSJVq5XDrRot(u"ࠬ࠭ࢍ"),sArCMRngQNmXkBoKv(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢎ"),str(qqSysvtkjrMVYn0d))
			ASQ7g4cylNwRY3baIWunCpJ = fR68jBGWCzUsFXdlTKPOScugm(u"ࡖࡵࡹࡪए")
	if showDialogs and not ASQ7g4cylNwRY3baIWunCpJ:
		HHTzVhiY079bvdluNkFQ4wCMpe(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧࠨ࢏"),Ej67fFyoqW8kbV2HdSK(u"ࠨࠩ࢐"),EDPaWgMt1SwNn8o(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࢑"),aVLSn1xw5cK(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫ࢒"))
		j2agIU0xsLS6c7T.setSetting(kmdSKeBIwViM9t3(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨ࢓"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨ࢔"))
		cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(XogUJZEijT7KWbxeO6(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ࢕"))
	return
def z6TslkcXBbAEvaHNZ0ymR4i3h9(showDialogs):
	if showDialogs:
		YYkEu4IL0sTa = OxCB4medn1(sArCMRngQNmXkBoKv(u"ࠧࠨ࢖"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨࠩࢗ"),pEo8g7riWVL014KaRtzQ(u"ࠩࠪ࢘"),AAgpHN0nMZ(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࢙࠭"),OVmSuf8tpd(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ็ๅࠢอี๏ีࠠๆีะ࢚ࠫ")+aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬࡢ࡮ࠨ࢛")+JMLhEyaBWmskovGHTrVCxQ08(u"࠭ๅอๆาࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮࠦ࠮࠯๋้ࠢั๊ฯࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠤ࠳࠴้ࠠ็ฯ่ิࠦวๅื๋ีࠥอไใัํ้ฮࠦ࠮࠯๋ࠢฮๆื๊฻่่ࠢๆࠦี้ำࠣห้หึศใสฮࠬ࢜")+ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧ࡝ࡰࠪ࢝")+PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠨมࠤࠥࠬ࢞")+c4QSTnPiWUCjhrLlwGB(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࢟"))
		if YYkEu4IL0sTa!=pEo8g7riWVL014KaRtzQ(u"࠷ࣰ"): return
	Eux3w7MylkQfiBa6pvJO0FWTNbr(ZxeyGAhgkw0,m6b7CoBk4EQ(u"ࡘࡷࡻࡥऑ"),FhcnOB9t3frzvXb(u"ࡉࡥࡱࡹࡥऐ"))
	Eux3w7MylkQfiBa6pvJO0FWTNbr(QW6SAqUaPfvZ5ND09BsMymXklc,jYaM5vilgZdFx6QHbApwVXO8et(u"࡚ࡲࡶࡧओ"),gnfv8UtZ3daGqpjzk(u"ࡋࡧ࡬ࡴࡧऒ"))
	Eux3w7MylkQfiBa6pvJO0FWTNbr(KiPpU9e6jqygN,AAgpHN0nMZ(u"ࡆࡢ࡮ࡶࡩऔ"),AAgpHN0nMZ(u"ࡆࡢ࡮ࡶࡩऔ"))
	o2VN9fiMqevhbFUEG(BqI7y2Pf3CQgox0OTK1YRiZ6c,J3OCAmZVcn(u"ࡇࡣ࡯ࡷࡪक"))
	if showDialogs:
		HHTzVhiY079bvdluNkFQ4wCMpe(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠪࠫࢠ"),m6b7CoBk4EQ(u"ࠫࠬࢡ"),gSmqZU0plur2xKPJwQA(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࢢ"),kmdSKeBIwViM9t3(u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧࢣ"))
		j2agIU0xsLS6c7T.setSetting(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫࢤ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࡕࡒࡑࡊ࡚ࡈࡊࡐࡊࠫࢥ"))
		cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(Ej67fFyoqW8kbV2HdSK(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭ࢦ"))
	return
def ZYf5z3Psk948FH6gU(showDialogs):
	if showDialogs:
		YYkEu4IL0sTa = OxCB4medn1(m6b7CoBk4EQ(u"ࠪࠫࢧ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫࠬࢨ"),LmcNhzY6fQPd2JyCGslkSr(u"ࠬ࠭ࢩ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢪ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๊่ࠥะั๋ัุ้ࠣำࠠๆๆไหฯ࠭ࢫ")+JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠨ࡞ࡱࠫࢬ")+eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠩࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸࠦ࠮࠯ࠢࡧࡶࡴࡶࡢࡰࡺࠣ࠲࠳ࠦࡴࡰ࡯ࡥࡷࡹࡵ࡮ࡦࡵࠣ࠲࠳ࠦ࡬ࡰࡩࡪࡩࡷࠦ࠮࠯ࠢ࡯ࡳ࡬ࠦ࠮࠯ࠢࡤࡲࡷ࠭ࢭ")+aVLSn1xw5cK(u"ࠪࡠࡳ࠭ࢮ")+kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫࡄࠧࠡࠨࢯ")+jYaM5vilgZdFx6QHbApwVXO8et(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࢰ"))
		if YYkEu4IL0sTa!=c4QSTnPiWUCjhrLlwGB(u"࠱ࣱ"): return
	Eux3w7MylkQfiBa6pvJO0FWTNbr(OOJZgqAMWb59,J3OCAmZVcn(u"ࡈࡤࡰࡸ࡫ख"),J3OCAmZVcn(u"ࡈࡤࡰࡸ࡫ख"))
	Eux3w7MylkQfiBa6pvJO0FWTNbr(EAXn7k80C1csJFb6PlmZzG4dtYL,yTMWeCgUROcvtsblfK85L62xPk(u"ࡉࡥࡱࡹࡥग"),yTMWeCgUROcvtsblfK85L62xPk(u"ࡉࡥࡱࡹࡥग"))
	Eux3w7MylkQfiBa6pvJO0FWTNbr(zz4JPswpn5lhEoxV,bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࡊࡦࡲࡳࡦघ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࡊࡦࡲࡳࡦघ"))
	Eux3w7MylkQfiBa6pvJO0FWTNbr(v0On1zMHQiakguDJb6y,yTMWeCgUROcvtsblfK85L62xPk(u"ࡋࡧ࡬ࡴࡧङ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࡋࡧ࡬ࡴࡧङ"))
	Eux3w7MylkQfiBa6pvJO0FWTNbr(Omy4KepldgXFP2saw7v,m6b7CoBk4EQ(u"ࡌࡡ࡭ࡵࡨच"),m6b7CoBk4EQ(u"ࡌࡡ࡭ࡵࡨच"))
	Eux3w7MylkQfiBa6pvJO0FWTNbr(HwkAXq0Ss2,eeIL1TfgFQJaKqVD8hGNPEZ(u"ࡆࡢ࡮ࡶࡩछ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࡆࡢ࡮ࡶࡩछ"))
	if showDialogs:
		HHTzVhiY079bvdluNkFQ4wCMpe(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭ࠧࢱ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠧࠨࢲ"),XogUJZEijT7KWbxeO6(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࢳ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪࢴ"))
		j2agIU0xsLS6c7T.setSetting(ZSJVq5XDrRot(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧࢵ"),LmcNhzY6fQPd2JyCGslkSr(u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧࢶ"))
		cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(LmcNhzY6fQPd2JyCGslkSr(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩࢷ"))
	return
def o2VN9fiMqevhbFUEG(tP325FYWofVAzLGEuSQN6ZHk1dIq,showDialogs):
	if showDialogs:
		YYkEu4IL0sTa = OxCB4medn1(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭ࠧࢸ"),J3OCAmZVcn(u"ࠧࠨࢹ"),pEo8g7riWVL014KaRtzQ(u"ࠨࠩࢺ"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࢻ"),EDPaWgMt1SwNn8o(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ้ࠣาะ่๋ษอࠤ๊๊แࠡื๋ีࠥอไอๆาࠤฤࠧࠡࠨࢼ")+m6b7CoBk4EQ(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࢽ"))
		if YYkEu4IL0sTa!=kmdSKeBIwViM9t3(u"࠲ࣲ"): return
	m5h4wdsHCKLvPu9V6rEFi2q = esvtXhdikb2GDJm5Arc.connect(tP325FYWofVAzLGEuSQN6ZHk1dIq)
	m5h4wdsHCKLvPu9V6rEFi2q.text_factory = str
	nRseEAQwXo4jC21gmqPzIihfUc = m5h4wdsHCKLvPu9V6rEFi2q.cursor()
	nRseEAQwXo4jC21gmqPzIihfUc.execute(J3OCAmZVcn(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡴࡦࡺࡨ࠼ࠩࢾ"))
	nRseEAQwXo4jC21gmqPzIihfUc.execute(xuYvdJpOEyQKTLNwb(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡸ࡯ࡺࡦࡵ࠾ࠫࢿ"))
	nRseEAQwXo4jC21gmqPzIihfUc.execute(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡺࡥࡹࡶࡸࡶࡪࡁࠧࣀ"))
	m5h4wdsHCKLvPu9V6rEFi2q.commit()
	nRseEAQwXo4jC21gmqPzIihfUc.execute(wwyUWMFAsO(u"ࠨࡘࡄࡇ࡚࡛ࡍ࠼ࠩࣁ"))
	m5h4wdsHCKLvPu9V6rEFi2q.close()
	if showDialogs:
		HHTzVhiY079bvdluNkFQ4wCMpe(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩࠪࣂ"),LmcNhzY6fQPd2JyCGslkSr(u"ࠪࠫࣃ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࣄ"),aVLSn1xw5cK(u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ࣅ"))
		j2agIU0xsLS6c7T.setSetting(gnfv8UtZ3daGqpjzk(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࣆ"),AAgpHN0nMZ(u"ࠧࡔࡑࡐࡉ࡙ࡎࡉࡏࡉࠪࣇ"))
		cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(pEo8g7riWVL014KaRtzQ(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬࣈ"))
	return
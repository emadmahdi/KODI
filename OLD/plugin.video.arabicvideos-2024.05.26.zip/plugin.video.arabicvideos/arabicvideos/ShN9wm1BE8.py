# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'EGYBEST4'
W74fAyGxODoLPs5vMX2l8C93R = '_EB4_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
SmgoEYJ7uyL = ['ايجي بست','اتصل بنا','ايجي بست الاصلي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست']
def OVQIAezo6U1NSTl4L(mode,url,wwNtFTLK2IqAszYBDV9J,text):
	if   mode==800: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==801: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,wwNtFTLK2IqAszYBDV9J)
	elif mode==802: HkKfQCS7RIa4xi3houjvl = yPzYJU5Wup8(url)
	elif mode==803: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==804: HkKfQCS7RIa4xi3houjvl = pkFycSeY2Efgd(url)
	elif mode==806: HkKfQCS7RIa4xi3houjvl = DFjzy4r8hXNtR0(url,wwNtFTLK2IqAszYBDV9J)
	elif mode==809: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',809,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فلتر',JJTrn6SEtYZV31eyR97+'/trending',804,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',JJTrn6SEtYZV31eyR97,'','','','','EGYBEST4-MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('nav-categories(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			title = title.strip(' ')
			if any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in SmgoEYJ7uyL): continue
			if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,801)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('mainContent(.*?)<footer>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('mainTitle.*?href="(.*?)".*?title="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			title = title.strip(' ')
			if any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in SmgoEYJ7uyL): continue
			if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,801,'','mainmenu')
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('main-menu(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			title = title.strip(' ')
			if any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in SmgoEYJ7uyL): continue
			if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,801)
	return QstumvzTIEUMXCcx06aD4y8nSqH
def DFjzy4r8hXNtR0(url,type=''):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','EGYBEST4-SEASONS_EPISODES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('mainTitle.*?>(.*?)<(.*?)pageContent',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		HEplfjN5wBxeYtD4ds6FvA38rK0U,xvWJR3VCAcyLZ,items = '','',[]
		for name,bdq4e6Wr2gslnSiA38 in IZGcQbePXxwAoyYR1n:
			if 'حلقات' in name: xvWJR3VCAcyLZ = bdq4e6Wr2gslnSiA38
			if 'مواسم' in name: HEplfjN5wBxeYtD4ds6FvA38rK0U = bdq4e6Wr2gslnSiA38
		if HEplfjN5wBxeYtD4ds6FvA38rK0U and not type:
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',HEplfjN5wBxeYtD4ds6FvA38rK0U,ZXFs0mEPR8qI2zj.DOTALL)
			if len(items)>1:
				for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,806,CrGO63LT7j2UxniW,'season')
		if xvWJR3VCAcyLZ and len(items)<2:
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',xvWJR3VCAcyLZ,ZXFs0mEPR8qI2zj.DOTALL)
			if items:
				for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
					Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,803,CrGO63LT7j2UxniW)
			else:
				items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',xvWJR3VCAcyLZ,ZXFs0mEPR8qI2zj.DOTALL)
				for RRucmYBaXegTtNOdGHMQ,title in items:
					Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,803)
	return
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,type=''):
	zMgjU0c1p3xke7GQEJqWv,start,DOVwrFbPi1kIm8n,select,rOd2abCI1hSegBuqP6G = 0,0,'','',''
	if 'pagination' in type:
		GOuBcLdJk31zseN7xQFn4vjq5ptWYg,BTMputsaqV = url.split('?next=page&')
		obS4TpHeV3digGC = {'Content-Type':'application/x-www-form-urlencoded'}
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'POST',GOuBcLdJk31zseN7xQFn4vjq5ptWYg,BTMputsaqV,obS4TpHeV3digGC,'','','EGYBEST4-TITLES-1st')
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		XgMyLUkfvP4uKVpQsY8RiWZz6N50O = 'secContent'+QstumvzTIEUMXCcx06aD4y8nSqH+'<footer>'
	else:
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','EGYBEST4-TITLES-2nd')
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		XgMyLUkfvP4uKVpQsY8RiWZz6N50O = QstumvzTIEUMXCcx06aD4y8nSqH
	items,rzc5pxXnS1eFdMg,zIpQyOG78Nvreijwa = [],False,False
	if not type and '/collections' not in url:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('mainContent(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?</i>(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title in items:
				title = title.strip(' ')
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,801,'','submenu')
				rzc5pxXnS1eFdMg = True
	if not rzc5pxXnS1eFdMg:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('secContent(.*?)mainContent',XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
				RRucmYBaXegTtNOdGHMQ = ejBOu2WXwvb4YpITdsLF16(RRucmYBaXegTtNOdGHMQ)
				CrGO63LT7j2UxniW = CrGO63LT7j2UxniW.strip('\n')
				title = qpob7TvxHSs4fEzO6(title)
				if '/series/' in RRucmYBaXegTtNOdGHMQ and type=='season': Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,806,CrGO63LT7j2UxniW,'season')
				elif '/series/' in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,806,CrGO63LT7j2UxniW)
				elif '/seasons/' in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,801,CrGO63LT7j2UxniW,'season')
				elif '/collections' in url: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,801,CrGO63LT7j2UxniW,'collections')
				else: Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,803,CrGO63LT7j2UxniW)
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('loadMoreParams = (.*?);',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			s8nZN31lf7OUr2J = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('dict',bdq4e6Wr2gslnSiA38)
			rOd2abCI1hSegBuqP6G = s8nZN31lf7OUr2J['ajaxurl']
			jMD8RBfTGUlQwJCk = int(s8nZN31lf7OUr2J['current_page'])+1
			yqlQVcrOpEogiG3nkANX9 = int(s8nZN31lf7OUr2J['max_page'])
			za2QhlsBdLJt0X6yiZwKTEe7 = s8nZN31lf7OUr2J['posts'].replace('False','false').replace('True','true').replace('None','null')
			if jMD8RBfTGUlQwJCk<yqlQVcrOpEogiG3nkANX9:
				BTMputsaqV = 'action=loadmore&query='+cD1AgYCl0qZI8(za2QhlsBdLJt0X6yiZwKTEe7,'')+'&page='+str(jMD8RBfTGUlQwJCk)
				lQHXdV9Nzf6BLqS8D = rOd2abCI1hSegBuqP6G+'?next=page&'+BTMputsaqV
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'جلب المزيد',lQHXdV9Nzf6BLqS8D,801,'','pagination_'+type)
		elif '?next=page&' in url:
			BTMputsaqV,BbEFSkYKicqaW = BTMputsaqV.rsplit('=',1)
			BbEFSkYKicqaW = int(BbEFSkYKicqaW)+1
			lQHXdV9Nzf6BLqS8D = GOuBcLdJk31zseN7xQFn4vjq5ptWYg+'?next=page&'+BTMputsaqV+'='+str(BbEFSkYKicqaW)
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'جلب المزيد',lQHXdV9Nzf6BLqS8D,801,'','pagination_'+type)
	return
def pkFycSeY2Efgd(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','EGYBEST4-FILTERS-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('sub_nav(.*?)secContent ',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		n5nyDgxTuHbY0LNV4cWvoBtp = ZXFs0mEPR8qI2zj.findall('"current_opt">(.*?)<(.*?)</div>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for name,bdq4e6Wr2gslnSiA38 in n5nyDgxTuHbY0LNV4cWvoBtp:
			if 'التصنيف' in name: continue
			name = name.strip(' ')
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,AARNPWHjQU9dEmDI in items:
				title = name+':  '+AARNPWHjQU9dEmDI
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,801,'','filter')
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	wpFmEA3z8JR = A6F71g3cqN4(KxirmCLT6Gw,'GET',url,'','','','','EGYBEST4-PLAY-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	z4O2HXsQyg = ZXFs0mEPR8qI2zj.findall('<td>التصنيف</td>.*?">(.*?)<',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if z4O2HXsQyg and GBC7yanr9WNYIKXSHRxgP(ll6f2wvU4FdqL3MJyDxORESCK197i,url,z4O2HXsQyg): return
	yf608hE5KeRG1DscunvrU,B1lkJKt2wS4EHFLuayQvAN9X0gxf = [],[]
	lMLE6SRw8PVHoyAhvrNp1TKYkO = ZXFs0mEPR8qI2zj.findall('postEmbed.*?post=(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if lMLE6SRw8PVHoyAhvrNp1TKYkO:
		R28S4pFmAojEW7CGnx = EGTVgQoSu6ZsD.b64decode(lMLE6SRw8PVHoyAhvrNp1TKYkO[0])
		if VYMZsxRpcQHPgkaiDKjyoh: R28S4pFmAojEW7CGnx = R28S4pFmAojEW7CGnx.decode('utf8')
		R28S4pFmAojEW7CGnx = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('dict',R28S4pFmAojEW7CGnx)
		R28S4pFmAojEW7CGnx = list(R28S4pFmAojEW7CGnx.values())
		for RRucmYBaXegTtNOdGHMQ in R28S4pFmAojEW7CGnx:
			if RRucmYBaXegTtNOdGHMQ not in B1lkJKt2wS4EHFLuayQvAN9X0gxf:
				B1lkJKt2wS4EHFLuayQvAN9X0gxf.append(RRucmYBaXegTtNOdGHMQ)
				NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(RRucmYBaXegTtNOdGHMQ,'name')
				yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ+'?named='+NGmuWwXdLQ6nMltx39FYECohJ+'__watch')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('pageContentDown(.*?)</table>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('<tr>.*?<td>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</td>.*?href="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for PHUqTNVJ0ErRSwibn5gD,RRucmYBaXegTtNOdGHMQ in items:
			if RRucmYBaXegTtNOdGHMQ not in B1lkJKt2wS4EHFLuayQvAN9X0gxf:
				if '/?url=' in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.split('/?url=')[1]
				B1lkJKt2wS4EHFLuayQvAN9X0gxf.append(RRucmYBaXegTtNOdGHMQ)
				NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(RRucmYBaXegTtNOdGHMQ,'name')
				yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ+'?named='+NGmuWwXdLQ6nMltx39FYECohJ+'__download____'+PHUqTNVJ0ErRSwibn5gD)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(yf608hE5KeRG1DscunvrU,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if not search: search = CjyEnpfQ23o0PYwDtLId()
	if not search: return
	H9IMP4eTVW8dji3EXnS7w = search.replace(' ','+')
	url = JJTrn6SEtYZV31eyR97+'/?s='+H9IMP4eTVW8dji3EXnS7w
	RxAy5lEFQ1chv0BrdU4p6Pt2(url,'search')
	return
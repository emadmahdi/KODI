# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'SHOOFMAX'
W74fAyGxODoLPs5vMX2l8C93R = '_SHM_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
dJSW5LrBmHfxeu = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][1]
GD7tZ81nNvWm2cB9uqHgYP5hAOadjs = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][2]
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==50: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==51: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url)
	elif mode==52: HkKfQCS7RIa4xi3houjvl = pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	elif mode==53: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==55: HkKfQCS7RIa4xi3houjvl = Ie2nO9WkZG7N5sC8Q()
	elif mode==56: HkKfQCS7RIa4xi3houjvl = zTgfx7peOUHIucCXMJBQ2VRwSimNhy()
	elif mode==57: HkKfQCS7RIa4xi3houjvl = pkFycSeY2Efgd(url,1)
	elif mode==58: HkKfQCS7RIa4xi3houjvl = pkFycSeY2Efgd(url,2)
	elif mode==59: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',59,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'المسلسلات','',56)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'الافلام','',55)
	return ''
def Ie2nO9WkZG7N5sC8Q():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'أفلام مرتبة بسنة الإنتاج',JJTrn6SEtYZV31eyR97+'/movie/1/yop',57)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'أفلام مرتبة بالأفضل تقييم',JJTrn6SEtYZV31eyR97+'/movie/1/review',57)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'أفلام مرتبة بالأكثر مشاهدة',JJTrn6SEtYZV31eyR97+'/movie/1/views',57)
	return
def zTgfx7peOUHIucCXMJBQ2VRwSimNhy():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مسلسلات مرتبة بسنة الإنتاج',JJTrn6SEtYZV31eyR97+'/series/1/yop',57)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مسلسلات مرتبة بالأفضل تقييم',JJTrn6SEtYZV31eyR97+'/series/1/review',57)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مسلسلات مرتبة بالأكثر مشاهدة',JJTrn6SEtYZV31eyR97+'/series/1/views',57)
	return
def RxAy5lEFQ1chv0BrdU4p6Pt2(url):
	if '?' in url:
		mcEHCT3jSM = url.split('?')
		url = mcEHCT3jSM[0]
		filter = '?' + cD1AgYCl0qZI8(mcEHCT3jSM[1],'=&:/%')
	else: filter = ''
	type,wwNtFTLK2IqAszYBDV9J,sort = url.split('/')[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': kpM5lOCec20mrw6hV7ILBd='فيلم'
		elif type=='series': kpM5lOCec20mrw6hV7ILBd='مسلسل'
		url = JJTrn6SEtYZV31eyR97 + '/genre/filter/' + cD1AgYCl0qZI8(kpM5lOCec20mrw6hV7ILBd) + '/' + wwNtFTLK2IqAszYBDV9J + '/' + sort + filter
		QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,url,'','','','SHOOFMAX-TITLES-1st')
		items = ZXFs0mEPR8qI2zj.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		DLwsumndBlcP5Y36Ue7a1RjkVCxS=0
		for id,title,dfQSlj04RWwkGyTpxYavh,CrGO63LT7j2UxniW in items:
			DLwsumndBlcP5Y36Ue7a1RjkVCxS += 1
			CrGO63LT7j2UxniW = GD7tZ81nNvWm2cB9uqHgYP5hAOadjs + '/v2/img/program/main/' + CrGO63LT7j2UxniW + '-2.jpg'
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97 + '/program/' + id
			if type=='movie': Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,53,CrGO63LT7j2UxniW)
			if type=='series': Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مسلسل '+title,RRucmYBaXegTtNOdGHMQ+'?ep='+dfQSlj04RWwkGyTpxYavh+'='+title+'='+CrGO63LT7j2UxniW,52,CrGO63LT7j2UxniW)
	else:
		if type=='movie': kpM5lOCec20mrw6hV7ILBd='movies'
		elif type=='series': kpM5lOCec20mrw6hV7ILBd='series'
		url = dJSW5LrBmHfxeu + '/json/selected/' + sort + '-' + kpM5lOCec20mrw6hV7ILBd + '-WW.json'
		QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,url,'','','','SHOOFMAX-TITLES-2nd')
		items = ZXFs0mEPR8qI2zj.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		DLwsumndBlcP5Y36Ue7a1RjkVCxS=0
		for id,dfQSlj04RWwkGyTpxYavh,CrGO63LT7j2UxniW,title in items:
			DLwsumndBlcP5Y36Ue7a1RjkVCxS += 1
			CrGO63LT7j2UxniW = dJSW5LrBmHfxeu + '/img/program/' + CrGO63LT7j2UxniW + '-2.jpg'
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97 + '/program/' + id
			if type=='movie': Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,53,CrGO63LT7j2UxniW)
			elif type=='series': Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مسلسل '+title,RRucmYBaXegTtNOdGHMQ+'?ep='+dfQSlj04RWwkGyTpxYavh+'='+title+'='+CrGO63LT7j2UxniW,52,CrGO63LT7j2UxniW)
	title='صفحة '
	if DLwsumndBlcP5Y36Ue7a1RjkVCxS==16:
		for LH7kPtRnx2rzGuZiXFWV in range(1,13) :
			if not wwNtFTLK2IqAszYBDV9J==str(LH7kPtRnx2rzGuZiXFWV):
				url = JJTrn6SEtYZV31eyR97+'/genre/filter/'+type+'/'+str(LH7kPtRnx2rzGuZiXFWV)+'/'+sort+filter
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title+str(LH7kPtRnx2rzGuZiXFWV),url,51)
	return
def pqx0gStI9ojGFP2rWhwRfkVCNX(url):
	mcEHCT3jSM = url.split('=')
	dfQSlj04RWwkGyTpxYavh = int(mcEHCT3jSM[1])
	name = ejBOu2WXwvb4YpITdsLF16(mcEHCT3jSM[2])
	name = name.replace('_MOD_مسلسل ','')
	CrGO63LT7j2UxniW = mcEHCT3jSM[3]
	url = url.split('?')[0]
	if dfQSlj04RWwkGyTpxYavh==0:
		QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,url,'','','','SHOOFMAX-EPISODES-1st')
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('<select(.*?)</select>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('option value="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		dfQSlj04RWwkGyTpxYavh = int(items[-1])
	for LqYKJ36CBG in range(dfQSlj04RWwkGyTpxYavh,0,-1):
		RRucmYBaXegTtNOdGHMQ = url + '?ep=' + str(LqYKJ36CBG)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(LqYKJ36CBG)
		Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,53,CrGO63LT7j2UxniW)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,url,'','','','SHOOFMAX-PLAY-1st')
	h6qFTRbsOaNPgIX5 = ZXFs0mEPR8qI2zj.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if h6qFTRbsOaNPgIX5:
		luMHeSgCBaPrb9KvUjNFqcR = h6qFTRbsOaNPgIX5[1].replace('T','    ')
		HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+'\n'+luMHeSgCBaPrb9KvUjNFqcR)
		return
	N5WF1BydjmKTZhQkg2e3ouXnprO7DV,kkSAP4WHqCv0chVRr = [],[]
	f7BVMFgkQc0W23Y4KX51sNJTlq6ZC = ZXFs0mEPR8qI2zj.findall('var origin_link = "(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)[0]
	GbZWXaSJOTdQuVC3t2 = ZXFs0mEPR8qI2zj.findall('var backup_origin_link = "(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)[0]
	R28S4pFmAojEW7CGnx = ZXFs0mEPR8qI2zj.findall('hls: (.*?)_link\+"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	for NGmuWwXdLQ6nMltx39FYECohJ,RRucmYBaXegTtNOdGHMQ in R28S4pFmAojEW7CGnx:
		if 'backup' in NGmuWwXdLQ6nMltx39FYECohJ:
			NGmuWwXdLQ6nMltx39FYECohJ = 'backup server'
			url = GbZWXaSJOTdQuVC3t2 + RRucmYBaXegTtNOdGHMQ
		else:
			NGmuWwXdLQ6nMltx39FYECohJ = 'main server'
			url = f7BVMFgkQc0W23Y4KX51sNJTlq6ZC + RRucmYBaXegTtNOdGHMQ
		if '.m3u8' in url:
			N5WF1BydjmKTZhQkg2e3ouXnprO7DV.append(url)
			kkSAP4WHqCv0chVRr.append('m3u8  '+NGmuWwXdLQ6nMltx39FYECohJ)
	R28S4pFmAojEW7CGnx = ZXFs0mEPR8qI2zj.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	R28S4pFmAojEW7CGnx += ZXFs0mEPR8qI2zj.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	for NGmuWwXdLQ6nMltx39FYECohJ,RRucmYBaXegTtNOdGHMQ in R28S4pFmAojEW7CGnx:
		filename = RRucmYBaXegTtNOdGHMQ.split('/')[-1]
		filename = filename.replace('fallback','')
		filename = filename.replace('.mp4','')
		filename = filename.replace('-','')
		if 'backup' in NGmuWwXdLQ6nMltx39FYECohJ:
			NGmuWwXdLQ6nMltx39FYECohJ = 'backup server'
			url = GbZWXaSJOTdQuVC3t2 + RRucmYBaXegTtNOdGHMQ
		else:
			NGmuWwXdLQ6nMltx39FYECohJ = 'main server'
			url = f7BVMFgkQc0W23Y4KX51sNJTlq6ZC + RRucmYBaXegTtNOdGHMQ
		N5WF1BydjmKTZhQkg2e3ouXnprO7DV.append(url)
		kkSAP4WHqCv0chVRr.append('mp4  '+NGmuWwXdLQ6nMltx39FYECohJ+'  '+filename)
	jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e('Select Video Quality:', kkSAP4WHqCv0chVRr)
	if jQ6w8xOrgYhSHIRpUqzL == -1 : return
	url = N5WF1BydjmKTZhQkg2e3ouXnprO7DV[jQ6w8xOrgYhSHIRpUqzL]
	w3hq0Xp8D9rZJ(url,ll6f2wvU4FdqL3MJyDxORESCK197i,'video')
	return
def pkFycSeY2Efgd(url,type):
	if 'series' in url: lQHXdV9Nzf6BLqS8D = JJTrn6SEtYZV31eyR97 + '/genre/مسلسل'
	else: lQHXdV9Nzf6BLqS8D = JJTrn6SEtYZV31eyR97 + '/genre/فيلم'
	lQHXdV9Nzf6BLqS8D = cD1AgYCl0qZI8(lQHXdV9Nzf6BLqS8D)
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,lQHXdV9Nzf6BLqS8D,'','','','SHOOFMAX-FILTERS-1st')
	if type==1: IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('subgenre(.*?)div',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	elif type==2: IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('country(.*?)div',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('option value="(.*?)">(.*?)</option',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	if type==1:
		for dF3rPUQpNbMjiIf,title in items:
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url+'?subgenre='+dF3rPUQpNbMjiIf,58)
	elif type==2:
		url,dF3rPUQpNbMjiIf = url.split('?')
		for SvVD2AkXlf17EFnY,title in items:
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url+'?country='+SvVD2AkXlf17EFnY+'&'+dF3rPUQpNbMjiIf,51)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if not search: search = CjyEnpfQ23o0PYwDtLId()
	if not search: return
	H9IMP4eTVW8dji3EXnS7w = search.replace(' ','%20')
	url = JJTrn6SEtYZV31eyR97+'/search?q='+H9IMP4eTVW8dji3EXnS7w
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','',True,'','SHOOFMAX-SEARCH-2nd')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('general-body(.*?)search-bottom-padding',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	if items:
		for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
			url = JJTrn6SEtYZV31eyR97 + RRucmYBaXegTtNOdGHMQ
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+cD1AgYCl0qZI8(title)+'='+CrGO63LT7j2UxniW
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,52,CrGO63LT7j2UxniW)
				else:
					title = '_MOD_فيلم '+title
					Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,url,53,CrGO63LT7j2UxniW)
	return
# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'RANDOMS'
W74fAyGxODoLPs5vMX2l8C93R = '_LST_'
qQSzNI6W8e5UVg = 4
IKECSaksPMbul7piHfT06oYc = 10
def OVQIAezo6U1NSTl4L(nnPsf4XLIJ7RWF,url,uHGMxiZfcoErOyXghvnWUK,wwNtFTLK2IqAszYBDV9J,B0BjfWuVKkht7gPaNqFsTJOdcHbw):
	try: koJDb5cLtesTaQ1OM = str(B0BjfWuVKkht7gPaNqFsTJOdcHbw['folder'])
	except: koJDb5cLtesTaQ1OM = ''
	if   nnPsf4XLIJ7RWF==160: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif nnPsf4XLIJ7RWF==161: HkKfQCS7RIa4xi3houjvl = u2ebaw5JSZ8GUP(uHGMxiZfcoErOyXghvnWUK)
	elif nnPsf4XLIJ7RWF==162: HkKfQCS7RIa4xi3houjvl = DNKZsYdrCwX75zLTJEcgPi3Wa(uHGMxiZfcoErOyXghvnWUK,162)
	elif nnPsf4XLIJ7RWF==163: HkKfQCS7RIa4xi3houjvl = DNKZsYdrCwX75zLTJEcgPi3Wa(uHGMxiZfcoErOyXghvnWUK,163)
	elif nnPsf4XLIJ7RWF==164: HkKfQCS7RIa4xi3houjvl = FMdvIPJKbouL8z1(uHGMxiZfcoErOyXghvnWUK)
	elif nnPsf4XLIJ7RWF==165: HkKfQCS7RIa4xi3houjvl = pisXmafYF8M1PyBdCGRA9I0Vw(url,uHGMxiZfcoErOyXghvnWUK)
	elif nnPsf4XLIJ7RWF==166: HkKfQCS7RIa4xi3houjvl = cCBU1prbDT4sjMx7JgF9Oh(url,uHGMxiZfcoErOyXghvnWUK)
	elif nnPsf4XLIJ7RWF==167: HkKfQCS7RIa4xi3houjvl = OrA8vTeKXI0FHdCanl(url,uHGMxiZfcoErOyXghvnWUK)
	elif nnPsf4XLIJ7RWF==168: HkKfQCS7RIa4xi3houjvl = DFl1GJWUQrAKTM(url,uHGMxiZfcoErOyXghvnWUK)
	elif nnPsf4XLIJ7RWF==761: HkKfQCS7RIa4xi3houjvl = P8P6L7nfTIM9VmFC()
	elif nnPsf4XLIJ7RWF==762: HkKfQCS7RIa4xi3houjvl = SDzVs0WJUEYvOQjglhL8NxHn4Iq()
	elif nnPsf4XLIJ7RWF==763: HkKfQCS7RIa4xi3houjvl = VTuWg4bAOecJmL9jt7H(koJDb5cLtesTaQ1OM,uHGMxiZfcoErOyXghvnWUK,wwNtFTLK2IqAszYBDV9J)
	elif nnPsf4XLIJ7RWF==764: HkKfQCS7RIa4xi3houjvl = qedf9QcP15KVgE(koJDb5cLtesTaQ1OM,uHGMxiZfcoErOyXghvnWUK)
	elif nnPsf4XLIJ7RWF==765: HkKfQCS7RIa4xi3houjvl = E7AM6ixem3cC4(koJDb5cLtesTaQ1OM,uHGMxiZfcoErOyXghvnWUK)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','قنوات تلفزيون عشوائية','',161,'','','_LIVETV__RANDOM__REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','قسم عشوائي','',162,'','','_SITES__REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','فيديوهات عشوائية','',163,'','','_SITES__RANDOM__REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','فيديوهات بحث عشوائي','',164,'','','_SITES__RANDOM__REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','فيديوهات عشوائية من قسم','',763,'','','_SITES__RANDOM_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','قنوات M3U عشوائية','',163,'','','_M3U__LIVE__RANDOM__REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','فيديوهات M3U عشوائية','',163,'','','_M3U__VOD__RANDOM__REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','قسم قنوات M3U عشوائي','',162,'','','_M3U__LIVE__REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','قسم فيديو M3U عشوائي','',162,'','','_M3U__VOD__REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','فيديوهات M3U بحث عشوائي','',164,'','','_M3U__RANDOM__REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','فيديوهات M3U عشوائية من قسم','',765,'','','_M3U__RANDOM__REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','قنوات IPTV عشوائية','',163,'','','_IPTV__LIVE__RANDOM__REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','فيديوهات IPTV عشوائية','',163,'','','_IPTV__VOD__RANDOM__REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','قسم قنوات IPTV عشوائي','',162,'','','_IPTV__LIVE__REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','قسم فيديو IPTV عشوائي','',162,'','','_IPTV__VOD__REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','فيديوهات IPTV بحث عشوائي','',164,'','','_IPTV__RANDOM__REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','فيديوهات IPTV عشوائية من قسم','',764,'','','_IPTV__RANDOM__REMEMBERRESULTS_')
	return
def P8P6L7nfTIM9VmFC():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_IPT_'+'فيديوهات جميع IPTV','',764)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for koJDb5cLtesTaQ1OM in range(1,SS2ZAHCRpu8QxIao7BMq+1):
		W74fAyGxODoLPs5vMX2l8C93R = '_IP'+str(koJDb5cLtesTaQ1OM)+'_'
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+' فيديوهات مجلد '+KnGrOQsDgfB8Raj9C2AZJuYcTxP[koJDb5cLtesTaQ1OM],'',764,'','','','',{'folder':koJDb5cLtesTaQ1OM})
	return
def SDzVs0WJUEYvOQjglhL8NxHn4Iq():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_M3U_'+'فيديوهات جميع M3U','',765)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for koJDb5cLtesTaQ1OM in range(1,SS2ZAHCRpu8QxIao7BMq+1):
		W74fAyGxODoLPs5vMX2l8C93R = '_MU'+str(koJDb5cLtesTaQ1OM)+'_'
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+' فيديوهات مجلد '+KnGrOQsDgfB8Raj9C2AZJuYcTxP[koJDb5cLtesTaQ1OM],'',765,'','','','',{'folder':koJDb5cLtesTaQ1OM})
	return
def HzsJAW4OZgu6FCl9whxV5fRjNKTm(ji1dGuYnsFNKe):
	global vDz1bqf0igN,JMQ2Ia6iDuGn
	terDuEzAxwJBMfij2Z3VTyOn5bU,hRXOg9EUnHF,dGbUpZ6N7WX52BLmR4vfz = Cqb7Pp23AvmRTwQhjroY68uKE4ye(ji1dGuYnsFNKe)
	try:
		if 'IFILM' in ji1dGuYnsFNKe: terDuEzAxwJBMfij2Z3VTyOn5bU(ji1dGuYnsFNKe)
		else: terDuEzAxwJBMfij2Z3VTyOn5bU()
		g4Fps2bzUkPYi9BoLVu = False
	except:
		jTB4IzGRvbPxCgq2Y()
		g4Fps2bzUkPYi9BoLVu = True
	ji1dGuYnsFNKe = Po4CyOusDaWq6pbIjYV(ji1dGuYnsFNKe)
	if g4Fps2bzUkPYi9BoLVu:
		NLVM3HAtxQOSvJf6kd78K1o(ji1dGuYnsFNKe,'فشل للأسف',luMHeSgCBaPrb9KvUjNFqcR=2000)
		vDz1bqf0igN += 1
		JMQ2Ia6iDuGn += ' '+ji1dGuYnsFNKe
	else: NLVM3HAtxQOSvJf6kd78K1o(ji1dGuYnsFNKe,'',luMHeSgCBaPrb9KvUjNFqcR=1000)
	return
def AonkNcMhIFEX(MBcaenG62OH=True):
	global vDz1bqf0igN,JMQ2Ia6iDuGn
	if not MBcaenG62OH:
		global YLg3diKrRb61pkP08hJBZNEsXlvA
		HkKfQCS7RIa4xi3houjvl = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,'dict','SECTIONS_SITES','SECTIONS_SITES_ALL')
		if HkKfQCS7RIa4xi3houjvl:
			YLg3diKrRb61pkP08hJBZNEsXlvA = HkKfQCS7RIa4xi3houjvl
			return
	YYkEu4IL0sTa = OxCB4medn1('center','','','رسالة من المبرمج','لكي تملئ هذه القائمة . البرنامج يحتاج أن يفحص جميع مواقع الفيديو التي في البرنامج لكي يستخرج منها فقط الأقسام الرئيسية . ثم يقوم البرنامج بخزن هذه الأقسام حتى لا تحتاج أن تملئها مرة أخرى . عملية ملئ جميع الأقسام تحتاج عادة أقل من 3 دقائق . هل تريد أن تجمع قائمة الأقسام الآن ؟')
	if YYkEu4IL0sTa!=1: return
	K18gduYeq29CsrQN(False,False,False)
	aa1DYmOQUFVvBbg = OWasmQ27g3Dbljpo
	vDz1bqf0igN,JMQ2Ia6iDuGn,threads = 0,'',{}
	for ji1dGuYnsFNKe in bEY9tdnqgQAaB1L4VeNlDZ:
		luMHeSgCBaPrb9KvUjNFqcR.sleep(0.75)
		threads[ji1dGuYnsFNKe] = c3cgVjNv1rde.Thread(target=HzsJAW4OZgu6FCl9whxV5fRjNKTm,args=(ji1dGuYnsFNKe,))
		threads[ji1dGuYnsFNKe].start()
		if vDz1bqf0igN>=IKECSaksPMbul7piHfT06oYc: break
	else:
		for ji1dGuYnsFNKe in list(threads.keys()):
			threads[ji1dGuYnsFNKe].join()
	OWasmQ27g3Dbljpo[:] = aa1DYmOQUFVvBbg
	if vDz1bqf0igN>=IKECSaksPMbul7piHfT06oYc: HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','لديك مشكلة في '+str(vDz1bqf0igN)+' مواقع من مواقع البرنامج ... وسببها قد يكون عدم وجود إنترنيت في جهازك وهي:'+JMQ2Ia6iDuGn)
	else:
		Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,'SECTIONS_SITES','SECTIONS_SITES_ALL',YLg3diKrRb61pkP08hJBZNEsXlvA,iKYM8NdkGHmBcr)
		HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','تم جلب جميع الأقسام المتوفرة في البرنامج')
	K18gduYeq29CsrQN('','','')
	iiysxZ8dOaA('Exit to apply new sections menus')
	return
def twNrW3IEAZYVDqbnvT(koJDb5cLtesTaQ1OM,xdWIA3KvVbtMaszgNPyZEn9fQ):
	pxc6J0d9LuvQ1tPWfTD4bn = False
	NhUOepvot52f = OWasmQ27g3Dbljpo
	OWasmQ27g3Dbljpo[:] = []
	if pxc6J0d9LuvQ1tPWfTD4bn and '_CREATENEW_' not in xdWIA3KvVbtMaszgNPyZEn9fQ:
		HkKfQCS7RIa4xi3houjvl = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,'list','SECTIONS_IPTV','SECTIONS_IPTV_'+koJDb5cLtesTaQ1OM)
	elif '_LIVE_' not in xdWIA3KvVbtMaszgNPyZEn9fQ or '_VOD_' not in xdWIA3KvVbtMaszgNPyZEn9fQ:
		import uu80ZYa2sG
		LaX1QCyeIJ = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in xdWIA3KvVbtMaszgNPyZEn9fQ:
			try: uu80ZYa2sG.Ovdoig1sAc(koJDb5cLtesTaQ1OM,'VOD_UNKNOWN_GROUPED_SORTED','','',xdWIA3KvVbtMaszgNPyZEn9fQ+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: HHTzVhiY079bvdluNkFQ4wCMpe('','','موقع ـIPTV للفيديوهات',LaX1QCyeIJ)
			try: uu80ZYa2sG.Ovdoig1sAc(koJDb5cLtesTaQ1OM,'VOD_MOVIES_GROUPED_SORTED','','',xdWIA3KvVbtMaszgNPyZEn9fQ+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: HHTzVhiY079bvdluNkFQ4wCMpe('','','موقع ـIPTV للفيديوهات',LaX1QCyeIJ)
			try: uu80ZYa2sG.Ovdoig1sAc(koJDb5cLtesTaQ1OM,'VOD_SERIES_GROUPED_SORTED','','',xdWIA3KvVbtMaszgNPyZEn9fQ+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: HHTzVhiY079bvdluNkFQ4wCMpe('','','موقع ـIPTV للفيديوهات',LaX1QCyeIJ)
		if '_VOD_' not in xdWIA3KvVbtMaszgNPyZEn9fQ:
			try: uu80ZYa2sG.Ovdoig1sAc(koJDb5cLtesTaQ1OM,'LIVE_UNKNOWN_GROUPED_SORTED','','',xdWIA3KvVbtMaszgNPyZEn9fQ+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: HHTzVhiY079bvdluNkFQ4wCMpe('','','موقع ـIPTV للقنوات',LaX1QCyeIJ)
			try: uu80ZYa2sG.Ovdoig1sAc(koJDb5cLtesTaQ1OM,'LIVE_GROUPED_SORTED','','',xdWIA3KvVbtMaszgNPyZEn9fQ+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: HHTzVhiY079bvdluNkFQ4wCMpe('','','موقع ـIPTV للقنوات',LaX1QCyeIJ)
		HkKfQCS7RIa4xi3houjvl = OWasmQ27g3Dbljpo
		if pxc6J0d9LuvQ1tPWfTD4bn: Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,'SECTIONS_IPTV','SECTIONS_IPTV_'+koJDb5cLtesTaQ1OM,HkKfQCS7RIa4xi3houjvl,iKYM8NdkGHmBcr)
	OWasmQ27g3Dbljpo[:] = NhUOepvot52f
	return HkKfQCS7RIa4xi3houjvl
def GS1qYXdDVy(koJDb5cLtesTaQ1OM,xdWIA3KvVbtMaszgNPyZEn9fQ):
	pxc6J0d9LuvQ1tPWfTD4bn = False
	NhUOepvot52f = OWasmQ27g3Dbljpo
	OWasmQ27g3Dbljpo[:] = []
	if pxc6J0d9LuvQ1tPWfTD4bn and '_CREATENEW_' not in xdWIA3KvVbtMaszgNPyZEn9fQ:
		HkKfQCS7RIa4xi3houjvl = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,'list','SECTIONS_M3U','SECTIONS_M3U_'+koJDb5cLtesTaQ1OM)
	elif '_LIVE_' not in xdWIA3KvVbtMaszgNPyZEn9fQ or '_VOD_' not in xdWIA3KvVbtMaszgNPyZEn9fQ:
		import Yj2oWQg6sb
		LaX1QCyeIJ = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in xdWIA3KvVbtMaszgNPyZEn9fQ:
			try: Yj2oWQg6sb.Ovdoig1sAc(koJDb5cLtesTaQ1OM,'VOD_UNKNOWN_GROUPED_SORTED','','',xdWIA3KvVbtMaszgNPyZEn9fQ+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: HHTzVhiY079bvdluNkFQ4wCMpe('','','موقع ـM3U للفيديوهات',LaX1QCyeIJ)
			try: Yj2oWQg6sb.Ovdoig1sAc(koJDb5cLtesTaQ1OM,'VOD_MOVIES_GROUPED_SORTED','','',xdWIA3KvVbtMaszgNPyZEn9fQ+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: HHTzVhiY079bvdluNkFQ4wCMpe('','','موقع ـM3U للفيديوهات',LaX1QCyeIJ)
			try: Yj2oWQg6sb.Ovdoig1sAc(koJDb5cLtesTaQ1OM,'VOD_SERIES_GROUPED_SORTED','','',xdWIA3KvVbtMaszgNPyZEn9fQ+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: HHTzVhiY079bvdluNkFQ4wCMpe('','','موقع ـM3U للفيديوهات',LaX1QCyeIJ)
		if '_VOD_' not in xdWIA3KvVbtMaszgNPyZEn9fQ:
			try: Yj2oWQg6sb.Ovdoig1sAc(koJDb5cLtesTaQ1OM,'LIVE_UNKNOWN_GROUPED_SORTED','','',xdWIA3KvVbtMaszgNPyZEn9fQ+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: HHTzVhiY079bvdluNkFQ4wCMpe('','','موقع ـM3U للقنوات',LaX1QCyeIJ)
			try: Yj2oWQg6sb.Ovdoig1sAc(koJDb5cLtesTaQ1OM,'LIVE_GROUPED_SORTED','','',xdWIA3KvVbtMaszgNPyZEn9fQ+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: HHTzVhiY079bvdluNkFQ4wCMpe('','','موقع ـM3U للقنوات',LaX1QCyeIJ)
		HkKfQCS7RIa4xi3houjvl = OWasmQ27g3Dbljpo
		if pxc6J0d9LuvQ1tPWfTD4bn: Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,'SECTIONS_M3U','SECTIONS_M3U_'+koJDb5cLtesTaQ1OM,HkKfQCS7RIa4xi3houjvl,iKYM8NdkGHmBcr)
	OWasmQ27g3Dbljpo[:] = NhUOepvot52f
	return HkKfQCS7RIa4xi3houjvl
def VTuWg4bAOecJmL9jt7H(koJDb5cLtesTaQ1OM,xdWIA3KvVbtMaszgNPyZEn9fQ,mYtTs29lUKiOehBxC8cAWQJrkfqSw1):
	if '_CREATENEW_' in xdWIA3KvVbtMaszgNPyZEn9fQ and mYtTs29lUKiOehBxC8cAWQJrkfqSw1=='': AonkNcMhIFEX(True)
	elif mYtTs29lUKiOehBxC8cAWQJrkfqSw1: AonkNcMhIFEX(False)
	yyPoNegS5ROQfTlLm = xdWIA3KvVbtMaszgNPyZEn9fQ.replace('_CREATENEW_','').replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	if not mYtTs29lUKiOehBxC8cAWQJrkfqSw1:
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','تحديث هذه القائمة','',763,'','','_CREATENEW_'+yyPoNegS5ROQfTlLm,'',{'folder':koJDb5cLtesTaQ1OM})
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	r61opKn9hFObkY = ['أفلام','مسلسلات','مسرحيات','برامج','أطفال وكرتون','رمضان','أحدث-أخر','سلاسل','موسيقى','أشهر-أكثر','الآن','ضحك','رياضة','نيتفلكس','ممثلين','بث حي','دينية','سنوات','أخرى']
	R6hVPQM3n87 = ['افلام','movie','فيلم','فلم']
	ZZ8Stq1IfWp7BHAQePTKy0JVFc = ['مسلسل','series']
	h8Q0YjqSyxmDeALT2RIoJWVt4bU = ['مسارح','مسرحيات']
	TGnv6iyD0CeSb2kr3ONht = ['برامج','show','تلفزيون','تليفزيون']
	LA8oQReEzHvuyNiTl3hIOcM = ['انمي','كرتون','كارتون','kids','طفل','اطفال']
	EoR08gLBFy = ['رمضان']
	vyM5CbgVYS = ['احدث','اخر','موخر','جديد','مضاف','حديث']
	AybEaL9FwBcvZRoT = ['سلاسل','سلسله']
	zSxQaZdhCDpnwY6 = ['اغاني','موسيقى','كليب','حفل','music']
	Tak6DpBXVYEKm = ['اكثر','اشهر','مميزه','اعلى','مختاره','مختارات','اقوى']
	ElPmhAJVqUIcRf30tiZbKy2eMNY = ['الان','حالي','مثبت','رائج']
	JJEH05sutzpnqolye4USb = ['ضحك','كوميدي']
	shkH0QNxTIK = ['رياضه','كوره','مصارعه','شوت','رياضة']
	WTKQJedr6sYv7x = ['نيتفلكس','netflix','نيتفليكس']
	nbNgfrCcQ1auG8mU5 = ['ممثلين','اشخاص','نجوم']
	RRDqBGVHKunaeLk5hcsSvYr = ['بث حي','live','قناه','قنوات']
	n6sS8iGXYxPgT = ['دين','ادعيه','زيارات','لطميات','دعاء','قران','قصائد','رثاء','مرجعيه','اذان','اسلام','تواشيح','خطب','حوزوي','عتبات','مواليد','نواعي','عقائد','اناشيد']
	lptCW0acShz2Lm698 = ['19','20','21','22','23','24','25','26']
	if not mYtTs29lUKiOehBxC8cAWQJrkfqSw1:
		mYtTs29lUKiOehBxC8cAWQJrkfqSw1 = 0
		for jjhqwBOK0A1yMU in r61opKn9hFObkY:
			mYtTs29lUKiOehBxC8cAWQJrkfqSw1 += 1
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+jjhqwBOK0A1yMU,'',763,'',str(mYtTs29lUKiOehBxC8cAWQJrkfqSw1),yyPoNegS5ROQfTlLm,'',{'folder':koJDb5cLtesTaQ1OM})
	else:
		for aaYDh2EzJ5ky in sorted(list(YLg3diKrRb61pkP08hJBZNEsXlvA.keys())):
			Ym8DlVPuqS1tJb = aaYDh2EzJ5ky.lower()
			p8pgXONsjY = []
			if any(AARNPWHjQU9dEmDI in Ym8DlVPuqS1tJb for AARNPWHjQU9dEmDI in R6hVPQM3n87): p8pgXONsjY.append(1)
			if any(AARNPWHjQU9dEmDI in Ym8DlVPuqS1tJb for AARNPWHjQU9dEmDI in ZZ8Stq1IfWp7BHAQePTKy0JVFc): p8pgXONsjY.append(2)
			if any(AARNPWHjQU9dEmDI in Ym8DlVPuqS1tJb for AARNPWHjQU9dEmDI in h8Q0YjqSyxmDeALT2RIoJWVt4bU): p8pgXONsjY.append(3)
			if any(AARNPWHjQU9dEmDI in Ym8DlVPuqS1tJb for AARNPWHjQU9dEmDI in TGnv6iyD0CeSb2kr3ONht): p8pgXONsjY.append(4)
			if any(AARNPWHjQU9dEmDI in Ym8DlVPuqS1tJb for AARNPWHjQU9dEmDI in LA8oQReEzHvuyNiTl3hIOcM): p8pgXONsjY.append(5)
			if any(AARNPWHjQU9dEmDI in Ym8DlVPuqS1tJb for AARNPWHjQU9dEmDI in EoR08gLBFy): p8pgXONsjY.append(6)
			if any(AARNPWHjQU9dEmDI in Ym8DlVPuqS1tJb for AARNPWHjQU9dEmDI in vyM5CbgVYS) and Ym8DlVPuqS1tJb not in ['اخرى']: p8pgXONsjY.append(7)
			if any(AARNPWHjQU9dEmDI in Ym8DlVPuqS1tJb for AARNPWHjQU9dEmDI in AybEaL9FwBcvZRoT): p8pgXONsjY.append(8)
			if any(AARNPWHjQU9dEmDI in Ym8DlVPuqS1tJb for AARNPWHjQU9dEmDI in zSxQaZdhCDpnwY6): p8pgXONsjY.append(9)
			if any(AARNPWHjQU9dEmDI in Ym8DlVPuqS1tJb for AARNPWHjQU9dEmDI in Tak6DpBXVYEKm): p8pgXONsjY.append(10)
			if any(AARNPWHjQU9dEmDI in Ym8DlVPuqS1tJb for AARNPWHjQU9dEmDI in ElPmhAJVqUIcRf30tiZbKy2eMNY): p8pgXONsjY.append(11)
			if any(AARNPWHjQU9dEmDI in Ym8DlVPuqS1tJb for AARNPWHjQU9dEmDI in JJEH05sutzpnqolye4USb): p8pgXONsjY.append(12)
			if any(AARNPWHjQU9dEmDI in Ym8DlVPuqS1tJb for AARNPWHjQU9dEmDI in shkH0QNxTIK): p8pgXONsjY.append(13)
			if any(AARNPWHjQU9dEmDI in Ym8DlVPuqS1tJb for AARNPWHjQU9dEmDI in WTKQJedr6sYv7x): p8pgXONsjY.append(14)
			if any(AARNPWHjQU9dEmDI in Ym8DlVPuqS1tJb for AARNPWHjQU9dEmDI in nbNgfrCcQ1auG8mU5): p8pgXONsjY.append(15)
			if any(AARNPWHjQU9dEmDI in Ym8DlVPuqS1tJb for AARNPWHjQU9dEmDI in RRDqBGVHKunaeLk5hcsSvYr): p8pgXONsjY.append(16)
			if any(AARNPWHjQU9dEmDI in Ym8DlVPuqS1tJb for AARNPWHjQU9dEmDI in n6sS8iGXYxPgT): p8pgXONsjY.append(17)
			if any(AARNPWHjQU9dEmDI in Ym8DlVPuqS1tJb for AARNPWHjQU9dEmDI in lptCW0acShz2Lm698): p8pgXONsjY.append(18)
			if not p8pgXONsjY: p8pgXONsjY = [19]
			for puIXjKCJxFEUHneaq48dPGNYTS7 in p8pgXONsjY:
				if str(puIXjKCJxFEUHneaq48dPGNYTS7)==mYtTs29lUKiOehBxC8cAWQJrkfqSw1:
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+aaYDh2EzJ5ky,aaYDh2EzJ5ky,166,'','',yyPoNegS5ROQfTlLm+'_REMEMBERRESULTS_')
	return
def qedf9QcP15KVgE(koJDb5cLtesTaQ1OM,xdWIA3KvVbtMaszgNPyZEn9fQ):
	pxc6J0d9LuvQ1tPWfTD4bn = False
	if pxc6J0d9LuvQ1tPWfTD4bn:
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','تحديث هذه القائمة','',764,'','','_CREATENEW_','',{'folder':koJDb5cLtesTaQ1OM})
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	NhUOepvot52f = OWasmQ27g3Dbljpo[:]
	import uu80ZYa2sG
	if koJDb5cLtesTaQ1OM:
		if not uu80ZYa2sG.KHWOFrzptwybYx(koJDb5cLtesTaQ1OM,True): return
		jurgh5v0iFwk = twNrW3IEAZYVDqbnvT(koJDb5cLtesTaQ1OM,xdWIA3KvVbtMaszgNPyZEn9fQ)
		usLWRwnPVIOzf8JeGj = sorted(jurgh5v0iFwk,reverse=False,key=lambda key: key[1].lower())
	else:
		if not uu80ZYa2sG.KHWOFrzptwybYx('',True): return
		if pxc6J0d9LuvQ1tPWfTD4bn and '_CREATENEW_' not in xdWIA3KvVbtMaszgNPyZEn9fQ:
			usLWRwnPVIOzf8JeGj = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,'list','SECTIONS_IPTV','SECTIONS_IPTV_ALL')
		else:
			xD3flyFNPGB,usLWRwnPVIOzf8JeGj,jurgh5v0iFwk = [],[],[]
			for ol0ntbUOAWgwP8mdLvFHTKfDXa7 in range(1,SS2ZAHCRpu8QxIao7BMq+1):
				usLWRwnPVIOzf8JeGj += twNrW3IEAZYVDqbnvT(str(ol0ntbUOAWgwP8mdLvFHTKfDXa7),xdWIA3KvVbtMaszgNPyZEn9fQ)
			for type,aaYDh2EzJ5ky,url,nnPsf4XLIJ7RWF,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,uHGMxiZfcoErOyXghvnWUK,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw in usLWRwnPVIOzf8JeGj:
				if uHGMxiZfcoErOyXghvnWUK not in xD3flyFNPGB:
					xD3flyFNPGB.append(uHGMxiZfcoErOyXghvnWUK)
					qNaV3yBg6TY15jMDFbk9ISC = type,aaYDh2EzJ5ky,uHGMxiZfcoErOyXghvnWUK,165,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,xdWIA3KvVbtMaszgNPyZEn9fQ,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw
					jurgh5v0iFwk.append(qNaV3yBg6TY15jMDFbk9ISC)
			usLWRwnPVIOzf8JeGj = sorted(jurgh5v0iFwk,reverse=False,key=lambda key: key[1].lower())
			if pxc6J0d9LuvQ1tPWfTD4bn: Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,'SECTIONS_IPTV','SECTIONS_IPTV_ALL',usLWRwnPVIOzf8JeGj,iKYM8NdkGHmBcr)
	OWasmQ27g3Dbljpo[:] = NhUOepvot52f+usLWRwnPVIOzf8JeGj
	cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin('Container.Refresh')
	return
def E7AM6ixem3cC4(koJDb5cLtesTaQ1OM,xdWIA3KvVbtMaszgNPyZEn9fQ):
	pxc6J0d9LuvQ1tPWfTD4bn = False
	if pxc6J0d9LuvQ1tPWfTD4bn:
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','تحديث هذه القائمة','',765,'','','_CREATENEW_','',{'folder':koJDb5cLtesTaQ1OM})
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	NhUOepvot52f = OWasmQ27g3Dbljpo[:]
	import Yj2oWQg6sb
	if koJDb5cLtesTaQ1OM:
		if not Yj2oWQg6sb.KHWOFrzptwybYx(koJDb5cLtesTaQ1OM,True): return
		jurgh5v0iFwk = GS1qYXdDVy(koJDb5cLtesTaQ1OM,xdWIA3KvVbtMaszgNPyZEn9fQ)
		usLWRwnPVIOzf8JeGj = sorted(jurgh5v0iFwk,reverse=False,key=lambda key: key[1].lower())
	else:
		if not Yj2oWQg6sb.KHWOFrzptwybYx('',True): return
		if pxc6J0d9LuvQ1tPWfTD4bn and '_CREATENEW_' not in xdWIA3KvVbtMaszgNPyZEn9fQ:
			usLWRwnPVIOzf8JeGj = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,'list','SECTIONS_M3U','SECTIONS_M3U_ALL')
		else:
			xD3flyFNPGB,usLWRwnPVIOzf8JeGj,jurgh5v0iFwk = [],[],[]
			for ol0ntbUOAWgwP8mdLvFHTKfDXa7 in range(1,SS2ZAHCRpu8QxIao7BMq+1):
				usLWRwnPVIOzf8JeGj += GS1qYXdDVy(str(ol0ntbUOAWgwP8mdLvFHTKfDXa7),xdWIA3KvVbtMaszgNPyZEn9fQ)
			for type,aaYDh2EzJ5ky,url,nnPsf4XLIJ7RWF,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,uHGMxiZfcoErOyXghvnWUK,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw in usLWRwnPVIOzf8JeGj:
				if uHGMxiZfcoErOyXghvnWUK not in xD3flyFNPGB:
					xD3flyFNPGB.append(uHGMxiZfcoErOyXghvnWUK)
					qNaV3yBg6TY15jMDFbk9ISC = type,aaYDh2EzJ5ky,uHGMxiZfcoErOyXghvnWUK,165,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,xdWIA3KvVbtMaszgNPyZEn9fQ,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw
					jurgh5v0iFwk.append(qNaV3yBg6TY15jMDFbk9ISC)
			usLWRwnPVIOzf8JeGj = sorted(jurgh5v0iFwk,reverse=False,key=lambda key: key[1].lower())
			if pxc6J0d9LuvQ1tPWfTD4bn: Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,'SECTIONS_M3U','SECTIONS_M3U_ALL',usLWRwnPVIOzf8JeGj,iKYM8NdkGHmBcr)
	OWasmQ27g3Dbljpo[:] = NhUOepvot52f+usLWRwnPVIOzf8JeGj
	cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin('Container.Refresh')
	return
def pisXmafYF8M1PyBdCGRA9I0Vw(group,xdWIA3KvVbtMaszgNPyZEn9fQ):
	pxc6J0d9LuvQ1tPWfTD4bn = False
	HkKfQCS7RIa4xi3houjvl = []
	bbBXwTKNcgVn7ljS2dGJ9 = '_IPTV_' if 'IPTV' in xdWIA3KvVbtMaszgNPyZEn9fQ else '_M3U_'
	if pxc6J0d9LuvQ1tPWfTD4bn: HkKfQCS7RIa4xi3houjvl = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,'list','SECTIONS'+bbBXwTKNcgVn7ljS2dGJ9[:-1],group)
	if not HkKfQCS7RIa4xi3houjvl:
		for koJDb5cLtesTaQ1OM in range(1,SS2ZAHCRpu8QxIao7BMq+1):
			if pxc6J0d9LuvQ1tPWfTD4bn: HkKfQCS7RIa4xi3houjvl += NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,'list','SECTIONS'+bbBXwTKNcgVn7ljS2dGJ9[:-1],'SECTIONS'+bbBXwTKNcgVn7ljS2dGJ9+str(koJDb5cLtesTaQ1OM))
			elif bbBXwTKNcgVn7ljS2dGJ9=='_IPTV_': HkKfQCS7RIa4xi3houjvl += twNrW3IEAZYVDqbnvT(str(koJDb5cLtesTaQ1OM),'_CREATENEW_')
			elif bbBXwTKNcgVn7ljS2dGJ9=='_M3U_': HkKfQCS7RIa4xi3houjvl += GS1qYXdDVy(str(koJDb5cLtesTaQ1OM),'_CREATENEW_')
		for type,aaYDh2EzJ5ky,url,nnPsf4XLIJ7RWF,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,uHGMxiZfcoErOyXghvnWUK,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw in HkKfQCS7RIa4xi3houjvl:
			if uHGMxiZfcoErOyXghvnWUK==group: II41hWgEXR7wfsmJCZocYqKA8BdzHQ(type,aaYDh2EzJ5ky,url,nnPsf4XLIJ7RWF,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,uHGMxiZfcoErOyXghvnWUK,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw)
		items,kYoiqbhP2AfzOHWmjxS69sNdM = [],[]
		for type,aaYDh2EzJ5ky,url,nnPsf4XLIJ7RWF,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,uHGMxiZfcoErOyXghvnWUK,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw in OWasmQ27g3Dbljpo:
			rrc9HRI5OA8oKfiDbw = type,aaYDh2EzJ5ky[4:],url,nnPsf4XLIJ7RWF,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,uHGMxiZfcoErOyXghvnWUK,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,''
			if rrc9HRI5OA8oKfiDbw not in kYoiqbhP2AfzOHWmjxS69sNdM:
				kYoiqbhP2AfzOHWmjxS69sNdM.append(rrc9HRI5OA8oKfiDbw)
				q8BXZlN9sU1fP2JAxH7W = type,aaYDh2EzJ5ky,url,nnPsf4XLIJ7RWF,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,uHGMxiZfcoErOyXghvnWUK,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw
				items.append(q8BXZlN9sU1fP2JAxH7W)
		HkKfQCS7RIa4xi3houjvl = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if pxc6J0d9LuvQ1tPWfTD4bn: Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,'SECTIONS'+bbBXwTKNcgVn7ljS2dGJ9[:-1],group,HkKfQCS7RIa4xi3houjvl,iKYM8NdkGHmBcr)
	if '_RANDOM_' in xdWIA3KvVbtMaszgNPyZEn9fQ and len(HkKfQCS7RIa4xi3houjvl)>qQSzNI6W8e5UVg:
		OWasmQ27g3Dbljpo[:] = []
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder','[[COLOR FFC89008]'+group+'[/COLOR] :القسم]',group,165,'','',bbBXwTKNcgVn7ljS2dGJ9+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder','إعادة الطلب العشوائي من نفس القسم',group,165,'','',bbBXwTKNcgVn7ljS2dGJ9+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		HkKfQCS7RIa4xi3houjvl = OWasmQ27g3Dbljpo+bnPo1W52UVMRs7Lw6kfG9QdO.sample(HkKfQCS7RIa4xi3houjvl,qQSzNI6W8e5UVg)
	OWasmQ27g3Dbljpo[:] = HkKfQCS7RIa4xi3houjvl
	cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin('Container.Refresh')
	return
def u2ebaw5JSZ8GUP(xdWIA3KvVbtMaszgNPyZEn9fQ):
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','إعادة طلب قنوات عشوائية','',161,'','','_FORGETRESULTS__REMEMBERRESULTS__LIVETV__RANDOM_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	hNujdHURy0GF2xJgLMz45 = OWasmQ27g3Dbljpo[:]
	OWasmQ27g3Dbljpo[:] = []
	import DDPe9NIFqf
	DDPe9NIFqf.J2K0qdYZMhG('0',False)
	DDPe9NIFqf.J2K0qdYZMhG('1',False)
	DDPe9NIFqf.J2K0qdYZMhG('2',False)
	if '_RANDOM_' in xdWIA3KvVbtMaszgNPyZEn9fQ:
		OWasmQ27g3Dbljpo[:] = JJcIpBtEKMfmYC(OWasmQ27g3Dbljpo)
		if len(OWasmQ27g3Dbljpo)>qQSzNI6W8e5UVg: OWasmQ27g3Dbljpo[:] = bnPo1W52UVMRs7Lw6kfG9QdO.sample(OWasmQ27g3Dbljpo,qQSzNI6W8e5UVg)
	OWasmQ27g3Dbljpo[:] = hNujdHURy0GF2xJgLMz45+OWasmQ27g3Dbljpo
	return
def FMdvIPJKbouL8z1(xdWIA3KvVbtMaszgNPyZEn9fQ):
	xdWIA3KvVbtMaszgNPyZEn9fQ = xdWIA3KvVbtMaszgNPyZEn9fQ.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	headers = { 'User-Agent' : '' }
	url = 'https://www.bestrandoms.com/random-arabic-words'
	data = {'quantity':'50'}
	data = XapnozmJWluEb8fdYye0SR6QxqZL(data)
	wpFmEA3z8JR = A6F71g3cqN4(RwhaLmQ4cpyvfxsPUJVA0DtM,'GET',url,data,headers,'','','RANDOMS-RANDOM_VIDEOS_FROM_WORDS-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="content"(.*?)class="clearfix"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('<span>(.*?)</span>.*?<span>(.*?)</span>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	criHomEtLMbaqJvGBKsRQ,yXWtoNkbwmTAJDlVs = list(zip(*items))
	RbJ1ZBMLHjtoPT6Gihdnm = []
	cYWN5AHo7km9UKCxP = [' ','"','`',',','.',':',';',"'",'-']
	CCxIMpPODhXoWA3Fikt7R6JzVbYv1g = yXWtoNkbwmTAJDlVs+criHomEtLMbaqJvGBKsRQ
	for OlhiToKQA9Ey6Jwz4Y in CCxIMpPODhXoWA3Fikt7R6JzVbYv1g:
		if OlhiToKQA9Ey6Jwz4Y in yXWtoNkbwmTAJDlVs: CCLO0m6F52Dn = 2
		if OlhiToKQA9Ey6Jwz4Y in criHomEtLMbaqJvGBKsRQ: CCLO0m6F52Dn = 4
		GJlfrpZweWNTyX4BO8sCuE1xtbcmDI = [xxFhvt275i8MdUVuPkSXzmbT in OlhiToKQA9Ey6Jwz4Y for xxFhvt275i8MdUVuPkSXzmbT in cYWN5AHo7km9UKCxP]
		if any(GJlfrpZweWNTyX4BO8sCuE1xtbcmDI):
			LcnYtXvRpST3U = GJlfrpZweWNTyX4BO8sCuE1xtbcmDI.index(True)
			Arhp6ZXQ7W1l0efYSoqC2MNw4gyGb = cYWN5AHo7km9UKCxP[LcnYtXvRpST3U]
			mprB7ijDHLCaqU = ''
			if OlhiToKQA9Ey6Jwz4Y.count(Arhp6ZXQ7W1l0efYSoqC2MNw4gyGb)>1: bL02J5sK6gVWSfPrCi,URbDPdn9OgFG0lZk,mprB7ijDHLCaqU = OlhiToKQA9Ey6Jwz4Y.split(Arhp6ZXQ7W1l0efYSoqC2MNw4gyGb,2)
			else: bL02J5sK6gVWSfPrCi,URbDPdn9OgFG0lZk = OlhiToKQA9Ey6Jwz4Y.split(Arhp6ZXQ7W1l0efYSoqC2MNw4gyGb,1)
			if len(bL02J5sK6gVWSfPrCi)>CCLO0m6F52Dn: RbJ1ZBMLHjtoPT6Gihdnm.append(bL02J5sK6gVWSfPrCi.lower())
			if len(URbDPdn9OgFG0lZk)>CCLO0m6F52Dn: RbJ1ZBMLHjtoPT6Gihdnm.append(URbDPdn9OgFG0lZk.lower())
			if len(mprB7ijDHLCaqU)>CCLO0m6F52Dn: RbJ1ZBMLHjtoPT6Gihdnm.append(mprB7ijDHLCaqU.lower())
		elif len(OlhiToKQA9Ey6Jwz4Y)>CCLO0m6F52Dn: RbJ1ZBMLHjtoPT6Gihdnm.append(OlhiToKQA9Ey6Jwz4Y.lower())
	for xxFhvt275i8MdUVuPkSXzmbT in range(9): bnPo1W52UVMRs7Lw6kfG9QdO.shuffle(RbJ1ZBMLHjtoPT6Gihdnm)
	if '_SITES_' in xdWIA3KvVbtMaszgNPyZEn9fQ:
		d7JKXi2eVWxmYwpkSnf3Rg1 = ujqHb6gv3ZcKmJazCy2
	elif '_IPTV_' in xdWIA3KvVbtMaszgNPyZEn9fQ:
		d7JKXi2eVWxmYwpkSnf3Rg1 = ['IPTV']
		import uu80ZYa2sG
		if not uu80ZYa2sG.KHWOFrzptwybYx('',True): return
	elif '_M3U_' in xdWIA3KvVbtMaszgNPyZEn9fQ:
		d7JKXi2eVWxmYwpkSnf3Rg1 = ['M3U']
		import Yj2oWQg6sb
		if not Yj2oWQg6sb.KHWOFrzptwybYx('',True): return
	count,sOWr1TiLvnQ4 = 0,0
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','[  ] :البحث عن','',164,'','','_FORGETRESULTS__REMEMBERRESULTS_'+xdWIA3KvVbtMaszgNPyZEn9fQ)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','إعادة البحث العشوائي','',164,'','','_FORGETRESULTS__REMEMBERRESULTS_'+xdWIA3KvVbtMaszgNPyZEn9fQ)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	LlYu8sX3qtUhQr7J = OWasmQ27g3Dbljpo[:]
	OWasmQ27g3Dbljpo[:] = []
	vvEBlUD0HwXyf6dVLTSq8Nn9AM = []
	for OlhiToKQA9Ey6Jwz4Y in RbJ1ZBMLHjtoPT6Gihdnm:
		URbDPdn9OgFG0lZk = ZXFs0mEPR8qI2zj.findall('[ \,\;\:\-\+\=\"\'\[\]\(\)\{\}\!\@'+'#'+'\$\%\^\&\*\_\<\>]',OlhiToKQA9Ey6Jwz4Y,ZXFs0mEPR8qI2zj.DOTALL)
		if URbDPdn9OgFG0lZk: OlhiToKQA9Ey6Jwz4Y = OlhiToKQA9Ey6Jwz4Y.split(URbDPdn9OgFG0lZk[0],1)[0]
		Z4hn8Q6tdg7 = OlhiToKQA9Ey6Jwz4Y.replace('ّ','').replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
		Z4hn8Q6tdg7 = Z4hn8Q6tdg7.replace('ِ','').replace('ٍ','').replace('ْ','').replace('،','').replace('ـ','')
		if Z4hn8Q6tdg7: vvEBlUD0HwXyf6dVLTSq8Nn9AM.append(Z4hn8Q6tdg7)
	QvmhFDJPYq = []
	for OeT2Jo0sp6h1mGdqfFw in range(0,20):
		search = bnPo1W52UVMRs7Lw6kfG9QdO.sample(vvEBlUD0HwXyf6dVLTSq8Nn9AM,1)[0]
		if search in QvmhFDJPYq: continue
		QvmhFDJPYq.append(search)
		ji1dGuYnsFNKe = bnPo1W52UVMRs7Lw6kfG9QdO.sample(d7JKXi2eVWxmYwpkSnf3Rg1,1)[0]
		tr24ZoudmqvxfYCw('NOTICE',RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+'   Random Video Search   site:'+str(ji1dGuYnsFNKe)+'  search:'+search)
		terDuEzAxwJBMfij2Z3VTyOn5bU,hRXOg9EUnHF,dGbUpZ6N7WX52BLmR4vfz = Cqb7Pp23AvmRTwQhjroY68uKE4ye(ji1dGuYnsFNKe)
		hRXOg9EUnHF(search+'_NODIALOGS_')
		if len(OWasmQ27g3Dbljpo)>0: break
	search = search.replace('_MOD_','')
	LlYu8sX3qtUhQr7J[0][1] = '[[COLOR FFC89008]'+search+'[/COLOR] :بحث عن]'
	OWasmQ27g3Dbljpo[:] = JJcIpBtEKMfmYC(OWasmQ27g3Dbljpo)
	if len(OWasmQ27g3Dbljpo)>qQSzNI6W8e5UVg: OWasmQ27g3Dbljpo[:] = bnPo1W52UVMRs7Lw6kfG9QdO.sample(OWasmQ27g3Dbljpo,qQSzNI6W8e5UVg)
	OWasmQ27g3Dbljpo[:] = LlYu8sX3qtUhQr7J+OWasmQ27g3Dbljpo
	return
def cCBU1prbDT4sjMx7JgF9Oh(kc4jalKOmfPrERTWNpxeq7uw8Lgd,xdWIA3KvVbtMaszgNPyZEn9fQ):
	kc4jalKOmfPrERTWNpxeq7uw8Lgd = kc4jalKOmfPrERTWNpxeq7uw8Lgd.replace('_MOD_','')
	xdWIA3KvVbtMaszgNPyZEn9fQ = xdWIA3KvVbtMaszgNPyZEn9fQ.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	AonkNcMhIFEX(False)
	if YLg3diKrRb61pkP08hJBZNEsXlvA=={}: return
	if '_RANDOM_' in xdWIA3KvVbtMaszgNPyZEn9fQ:
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder','[[COLOR FFC89008]'+kc4jalKOmfPrERTWNpxeq7uw8Lgd+'[/COLOR] :القسم]',kc4jalKOmfPrERTWNpxeq7uw8Lgd,166,'','','_FORGETRESULTS__REMEMBERRESULTS_'+xdWIA3KvVbtMaszgNPyZEn9fQ)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder','إعادة الطلب العشوائي من نفس القسم',kc4jalKOmfPrERTWNpxeq7uw8Lgd,166,'','','_FORGETRESULTS__REMEMBERRESULTS_'+xdWIA3KvVbtMaszgNPyZEn9fQ)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for website in sorted(list(YLg3diKrRb61pkP08hJBZNEsXlvA[kc4jalKOmfPrERTWNpxeq7uw8Lgd].keys())):
		type,aaYDh2EzJ5ky,url,fFDoUS4V8iHqBvQdJCk3,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,uHGMxiZfcoErOyXghvnWUK,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw = YLg3diKrRb61pkP08hJBZNEsXlvA[kc4jalKOmfPrERTWNpxeq7uw8Lgd][website]
		if '_RANDOM_' in xdWIA3KvVbtMaszgNPyZEn9fQ or len(YLg3diKrRb61pkP08hJBZNEsXlvA[kc4jalKOmfPrERTWNpxeq7uw8Lgd])==1:
			II41hWgEXR7wfsmJCZocYqKA8BdzHQ(type,'',url,fFDoUS4V8iHqBvQdJCk3,'',wwNtFTLK2IqAszYBDV9J,uHGMxiZfcoErOyXghvnWUK,'','')
			OWasmQ27g3Dbljpo[:] = JJcIpBtEKMfmYC(OWasmQ27g3Dbljpo)
			NhUOepvot52f,usLWRwnPVIOzf8JeGj = OWasmQ27g3Dbljpo[:3],OWasmQ27g3Dbljpo[3:]
			for xxFhvt275i8MdUVuPkSXzmbT in range(9): bnPo1W52UVMRs7Lw6kfG9QdO.shuffle(usLWRwnPVIOzf8JeGj)
			if '_RANDOM_' in xdWIA3KvVbtMaszgNPyZEn9fQ: OWasmQ27g3Dbljpo[:] = NhUOepvot52f+usLWRwnPVIOzf8JeGj[:qQSzNI6W8e5UVg]
			else: OWasmQ27g3Dbljpo[:] = NhUOepvot52f+usLWRwnPVIOzf8JeGj
		elif '_SITES_' in xdWIA3KvVbtMaszgNPyZEn9fQ: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',website,url,fFDoUS4V8iHqBvQdJCk3,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,uHGMxiZfcoErOyXghvnWUK,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw)
	return
def DNKZsYdrCwX75zLTJEcgPi3Wa(xdWIA3KvVbtMaszgNPyZEn9fQ,nnPsf4XLIJ7RWF):
	xdWIA3KvVbtMaszgNPyZEn9fQ = xdWIA3KvVbtMaszgNPyZEn9fQ.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	aaYDh2EzJ5ky,jYQF2HJxvOAWD08 = '',[]
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','[[COLOR FFC89008]'+aaYDh2EzJ5ky+'[/COLOR] :القسم]','',nnPsf4XLIJ7RWF,'','','_FORGETRESULTS__REMEMBERRESULTS_'+xdWIA3KvVbtMaszgNPyZEn9fQ)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','إعادة طلب قسم عشوائي','',nnPsf4XLIJ7RWF,'','','_FORGETRESULTS__REMEMBERRESULTS_'+xdWIA3KvVbtMaszgNPyZEn9fQ)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	NhUOepvot52f = OWasmQ27g3Dbljpo[:]
	OWasmQ27g3Dbljpo[:] = []
	HkKfQCS7RIa4xi3houjvl = []
	if '_SITES_' in xdWIA3KvVbtMaszgNPyZEn9fQ:
		AonkNcMhIFEX(False)
		if YLg3diKrRb61pkP08hJBZNEsXlvA=={}: return
		VJmCTk2lNPF0 = list(YLg3diKrRb61pkP08hJBZNEsXlvA.keys())
		kc4jalKOmfPrERTWNpxeq7uw8Lgd = bnPo1W52UVMRs7Lw6kfG9QdO.sample(VJmCTk2lNPF0,1)[0]
		RbJ1ZBMLHjtoPT6Gihdnm = list(YLg3diKrRb61pkP08hJBZNEsXlvA[kc4jalKOmfPrERTWNpxeq7uw8Lgd].keys())
		website = bnPo1W52UVMRs7Lw6kfG9QdO.sample(RbJ1ZBMLHjtoPT6Gihdnm,1)[0]
		type,aaYDh2EzJ5ky,url,fFDoUS4V8iHqBvQdJCk3,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,uHGMxiZfcoErOyXghvnWUK,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw = YLg3diKrRb61pkP08hJBZNEsXlvA[kc4jalKOmfPrERTWNpxeq7uw8Lgd][website]
		tr24ZoudmqvxfYCw('NOTICE',RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+'   Random Category   website: '+website+'   name: '+aaYDh2EzJ5ky+'   url: '+url+'   mode: '+str(fFDoUS4V8iHqBvQdJCk3))
	elif '_IPTV_' in xdWIA3KvVbtMaszgNPyZEn9fQ:
		import uu80ZYa2sG
		if not uu80ZYa2sG.KHWOFrzptwybYx('',True): return
		for koJDb5cLtesTaQ1OM in range(1,SS2ZAHCRpu8QxIao7BMq+1):
			HkKfQCS7RIa4xi3houjvl += twNrW3IEAZYVDqbnvT(str(koJDb5cLtesTaQ1OM),xdWIA3KvVbtMaszgNPyZEn9fQ)
		if not HkKfQCS7RIa4xi3houjvl: return
		type,aaYDh2EzJ5ky,url,fFDoUS4V8iHqBvQdJCk3,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,uHGMxiZfcoErOyXghvnWUK,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw = bnPo1W52UVMRs7Lw6kfG9QdO.sample(HkKfQCS7RIa4xi3houjvl,1)[0]
		tr24ZoudmqvxfYCw('NOTICE',RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+'   Random Category   name: '+aaYDh2EzJ5ky+'   url: '+url+'   mode: '+str(fFDoUS4V8iHqBvQdJCk3))
	elif '_M3U_' in xdWIA3KvVbtMaszgNPyZEn9fQ:
		import Yj2oWQg6sb
		if not Yj2oWQg6sb.KHWOFrzptwybYx('',True): return
		for koJDb5cLtesTaQ1OM in range(1,SS2ZAHCRpu8QxIao7BMq+1):
			HkKfQCS7RIa4xi3houjvl += GS1qYXdDVy(str(koJDb5cLtesTaQ1OM),xdWIA3KvVbtMaszgNPyZEn9fQ)
		if not HkKfQCS7RIa4xi3houjvl: return
		type,aaYDh2EzJ5ky,url,fFDoUS4V8iHqBvQdJCk3,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,uHGMxiZfcoErOyXghvnWUK,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw = bnPo1W52UVMRs7Lw6kfG9QdO.sample(HkKfQCS7RIa4xi3houjvl,1)[0]
		tr24ZoudmqvxfYCw('NOTICE',RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+'   Random Category   name: '+aaYDh2EzJ5ky+'   url: '+url+'   mode: '+str(fFDoUS4V8iHqBvQdJCk3))
	B7rvlzqJwtFKPxNmA1H8G4kD9Wnia = aaYDh2EzJ5ky
	HEKG64nraAizchv9emqy8FTdYuUs = []
	for xxFhvt275i8MdUVuPkSXzmbT in range(0,10):
		if xxFhvt275i8MdUVuPkSXzmbT>0: tr24ZoudmqvxfYCw('NOTICE',RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+'   Random Category   name: '+aaYDh2EzJ5ky+'   url: '+url+'   mode: '+str(fFDoUS4V8iHqBvQdJCk3))
		OWasmQ27g3Dbljpo[:] = []
		if fFDoUS4V8iHqBvQdJCk3==234 and '__IPTVSeries__' in uHGMxiZfcoErOyXghvnWUK: fFDoUS4V8iHqBvQdJCk3 = 233
		if fFDoUS4V8iHqBvQdJCk3==714 and '__M3USeries__' in uHGMxiZfcoErOyXghvnWUK: fFDoUS4V8iHqBvQdJCk3 = 713
		if fFDoUS4V8iHqBvQdJCk3==144: fFDoUS4V8iHqBvQdJCk3 = 291
		vfLGDU1N0e8c = II41hWgEXR7wfsmJCZocYqKA8BdzHQ(type,aaYDh2EzJ5ky,url,fFDoUS4V8iHqBvQdJCk3,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,uHGMxiZfcoErOyXghvnWUK,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw)
		if '_IPTV_' in xdWIA3KvVbtMaszgNPyZEn9fQ and fFDoUS4V8iHqBvQdJCk3==167: del OWasmQ27g3Dbljpo[:3]
		if '_M3U_' in xdWIA3KvVbtMaszgNPyZEn9fQ and fFDoUS4V8iHqBvQdJCk3==168: del OWasmQ27g3Dbljpo[:3]
		jYQF2HJxvOAWD08[:] = JJcIpBtEKMfmYC(OWasmQ27g3Dbljpo)
		if HEKG64nraAizchv9emqy8FTdYuUs and PPMg73d1CAKIZS2hvHc5pLmXt4Fsez(u'حلقة') in str(jYQF2HJxvOAWD08) or PPMg73d1CAKIZS2hvHc5pLmXt4Fsez(u'حلقه') in str(jYQF2HJxvOAWD08):
			aaYDh2EzJ5ky = B7rvlzqJwtFKPxNmA1H8G4kD9Wnia
			jYQF2HJxvOAWD08[:] = HEKG64nraAizchv9emqy8FTdYuUs
			break
		B7rvlzqJwtFKPxNmA1H8G4kD9Wnia = aaYDh2EzJ5ky
		HEKG64nraAizchv9emqy8FTdYuUs = jYQF2HJxvOAWD08
		if str(jYQF2HJxvOAWD08).count('video')>0: break
		if str(jYQF2HJxvOAWD08).count('live')>0: break
		if fFDoUS4V8iHqBvQdJCk3==233: break
		if fFDoUS4V8iHqBvQdJCk3==713: break
		if fFDoUS4V8iHqBvQdJCk3==291: break
		if jYQF2HJxvOAWD08: type,aaYDh2EzJ5ky,url,fFDoUS4V8iHqBvQdJCk3,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,uHGMxiZfcoErOyXghvnWUK,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw = bnPo1W52UVMRs7Lw6kfG9QdO.sample(jYQF2HJxvOAWD08,1)[0]
	if not aaYDh2EzJ5ky: aaYDh2EzJ5ky = '....'
	elif aaYDh2EzJ5ky.count('_')>1: aaYDh2EzJ5ky = aaYDh2EzJ5ky.split('_',2)[2]
	aaYDh2EzJ5ky = aaYDh2EzJ5ky.replace('UNKNOWN: ','')
	aaYDh2EzJ5ky = aaYDh2EzJ5ky.replace('_MOD_','')
	NhUOepvot52f[0][1] = '[[COLOR FFC89008]'+aaYDh2EzJ5ky+'[/COLOR] :القسم]'
	for xxFhvt275i8MdUVuPkSXzmbT in range(9): bnPo1W52UVMRs7Lw6kfG9QdO.shuffle(jYQF2HJxvOAWD08)
	if '_RANDOM_' in xdWIA3KvVbtMaszgNPyZEn9fQ: OWasmQ27g3Dbljpo[:] = NhUOepvot52f+jYQF2HJxvOAWD08[:qQSzNI6W8e5UVg]
	else: OWasmQ27g3Dbljpo[:] = NhUOepvot52f+jYQF2HJxvOAWD08
	return
def OrA8vTeKXI0FHdCanl(VVv3G9Hwjbul67XYa,xeT50Po3bNBFqshLAMRD9aGX41):
	xeT50Po3bNBFqshLAMRD9aGX41 = xeT50Po3bNBFqshLAMRD9aGX41.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	ShbkgRNDWFHszm7lLT6e0ZJaroYjOA = xeT50Po3bNBFqshLAMRD9aGX41
	if '__IPTVSeries__' in xeT50Po3bNBFqshLAMRD9aGX41:
		ShbkgRNDWFHszm7lLT6e0ZJaroYjOA = xeT50Po3bNBFqshLAMRD9aGX41.split('__IPTVSeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in VVv3G9Hwjbul67XYa: type = ',VIDEOS: '
	elif 'LIVE' in VVv3G9Hwjbul67XYa: type = ',LIVE: '
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','[[COLOR FFC89008]'+type+ShbkgRNDWFHszm7lLT6e0ZJaroYjOA+'[/COLOR] :القسم]',VVv3G9Hwjbul67XYa,167,'','','_FORGETRESULTS__REMEMBERRESULTS_'+xeT50Po3bNBFqshLAMRD9aGX41)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','إعادة الطلب العشوائي من نفس القسم',VVv3G9Hwjbul67XYa,167,'','','_FORGETRESULTS__REMEMBERRESULTS_'+xeT50Po3bNBFqshLAMRD9aGX41)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	import uu80ZYa2sG
	for koJDb5cLtesTaQ1OM in range(1,SS2ZAHCRpu8QxIao7BMq+1):
		if '__IPTVSeries__' in xeT50Po3bNBFqshLAMRD9aGX41: uu80ZYa2sG.Ovdoig1sAc(str(koJDb5cLtesTaQ1OM),VVv3G9Hwjbul67XYa,xeT50Po3bNBFqshLAMRD9aGX41,'',False)
		else: uu80ZYa2sG.J2K0qdYZMhG(str(koJDb5cLtesTaQ1OM),VVv3G9Hwjbul67XYa,xeT50Po3bNBFqshLAMRD9aGX41,'',False)
	OWasmQ27g3Dbljpo[:] = JJcIpBtEKMfmYC(OWasmQ27g3Dbljpo)
	if len(OWasmQ27g3Dbljpo)>(qQSzNI6W8e5UVg+3): OWasmQ27g3Dbljpo[:] = OWasmQ27g3Dbljpo[:3]+bnPo1W52UVMRs7Lw6kfG9QdO.sample(OWasmQ27g3Dbljpo[3:],qQSzNI6W8e5UVg)
	return
def DFl1GJWUQrAKTM(VVv3G9Hwjbul67XYa,xeT50Po3bNBFqshLAMRD9aGX41):
	xeT50Po3bNBFqshLAMRD9aGX41 = xeT50Po3bNBFqshLAMRD9aGX41.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	ShbkgRNDWFHszm7lLT6e0ZJaroYjOA = xeT50Po3bNBFqshLAMRD9aGX41
	if '__M3USeries__' in xeT50Po3bNBFqshLAMRD9aGX41:
		ShbkgRNDWFHszm7lLT6e0ZJaroYjOA = xeT50Po3bNBFqshLAMRD9aGX41.split('__M3USeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in VVv3G9Hwjbul67XYa: type = ',VIDEOS: '
	elif 'LIVE' in VVv3G9Hwjbul67XYa: type = ',LIVE: '
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','[[COLOR FFC89008]'+type+ShbkgRNDWFHszm7lLT6e0ZJaroYjOA+'[/COLOR] :القسم]',VVv3G9Hwjbul67XYa,168,'','','_FORGETRESULTS__REMEMBERRESULTS_'+xeT50Po3bNBFqshLAMRD9aGX41)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','إعادة الطلب العشوائي من نفس القسم',VVv3G9Hwjbul67XYa,168,'','','_FORGETRESULTS__REMEMBERRESULTS_'+xeT50Po3bNBFqshLAMRD9aGX41)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	import Yj2oWQg6sb
	for koJDb5cLtesTaQ1OM in range(1,SS2ZAHCRpu8QxIao7BMq+1):
		if '__M3USeries__' in xeT50Po3bNBFqshLAMRD9aGX41: Yj2oWQg6sb.Ovdoig1sAc(str(koJDb5cLtesTaQ1OM),VVv3G9Hwjbul67XYa,xeT50Po3bNBFqshLAMRD9aGX41,'',False)
		else: Yj2oWQg6sb.J2K0qdYZMhG(str(koJDb5cLtesTaQ1OM),VVv3G9Hwjbul67XYa,xeT50Po3bNBFqshLAMRD9aGX41,'',False)
	OWasmQ27g3Dbljpo[:] = JJcIpBtEKMfmYC(OWasmQ27g3Dbljpo)
	if len(OWasmQ27g3Dbljpo)>(qQSzNI6W8e5UVg+3): OWasmQ27g3Dbljpo[:] = OWasmQ27g3Dbljpo[:3]+bnPo1W52UVMRs7Lw6kfG9QdO.sample(OWasmQ27g3Dbljpo[3:],qQSzNI6W8e5UVg)
	return
def JJcIpBtEKMfmYC(OWasmQ27g3Dbljpo):
	jYQF2HJxvOAWD08 = []
	for type,aaYDh2EzJ5ky,url,nnPsf4XLIJ7RWF,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,uHGMxiZfcoErOyXghvnWUK,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw in OWasmQ27g3Dbljpo:
		if 'صفحة' in aaYDh2EzJ5ky or 'صفحه' in aaYDh2EzJ5ky or 'page' in aaYDh2EzJ5ky.lower(): continue
		jYQF2HJxvOAWD08.append([type,aaYDh2EzJ5ky,url,nnPsf4XLIJ7RWF,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,uHGMxiZfcoErOyXghvnWUK,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw])
	return jYQF2HJxvOAWD08
# -*- coding: utf-8 -*-
from j3x780FpaM import *
import bs4 as quQHOVM9o4YXzDt1iFymTdbBlfjU
ll6f2wvU4FdqL3MJyDxORESCK197i = 'ELCINEMA'
W74fAyGxODoLPs5vMX2l8C93R = '_ELC_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
headers = {'Referer':JJTrn6SEtYZV31eyR97}
SmgoEYJ7uyL = []
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==510: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==511: HkKfQCS7RIa4xi3houjvl = rmp42u9HFcBskbY(url)
	elif mode==512: HkKfQCS7RIa4xi3houjvl = eoFn6ScbAR0aQNJZq1vIWmP(url)
	elif mode==513: HkKfQCS7RIa4xi3houjvl = n78nb9VSjUlCtDuw0YEm(url)
	elif mode==514: HkKfQCS7RIa4xi3houjvl = GKlfHuPOgLEW8Y6qSm(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: HkKfQCS7RIa4xi3houjvl = GKlfHuPOgLEW8Y6qSm(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: HkKfQCS7RIa4xi3houjvl = sZmzvGOCjUyHIR5dfpJMVuB2S(text)
	elif mode==517: HkKfQCS7RIa4xi3houjvl = DpPMsVZcEWuTG(url)
	elif mode==518: HkKfQCS7RIa4xi3houjvl = MQefyGY3d46FUuBE(url)
	elif mode==519: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	elif mode==520: HkKfQCS7RIa4xi3houjvl = jQYJbzTCBSioyLvDe(url)
	elif mode==521: HkKfQCS7RIa4xi3houjvl = UZ9BNQJFflbnyvqi3A5I(url)
	elif mode==522: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==523: HkKfQCS7RIa4xi3houjvl = WuVCBopcYK8EIrn6y2(text)
	elif mode==524: HkKfQCS7RIa4xi3houjvl = b3EJQPrF9aihcMNl()
	elif mode==525: HkKfQCS7RIa4xi3houjvl = WWUY5Ja7sj0bKuEpfov24P9X()
	elif mode==526: HkKfQCS7RIa4xi3houjvl = vAFsVuz5UNblEP4j1Ow9hiH0()
	elif mode==527: HkKfQCS7RIa4xi3houjvl = dUqo9HKBnclr64D82OAZsCF0p()
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث بموسوعة السينما','',519)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'موسوعة الأعمال','',525)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'موسوعة الأشخاص','',526)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'موسوعة المصنفات','',527)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'موسوعة المنوعات','',524)
	return
def b3EJQPrF9aihcMNl():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+' فيديوهات - خاصة',JJTrn6SEtYZV31eyR97+'/video',520)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فيديوهات - أحدث',JJTrn6SEtYZV31eyR97+'/video/latest',521)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فيديوهات - أقدم',JJTrn6SEtYZV31eyR97+'/video/oldest',521)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فيديوهات - أكثر مشاهدة',JJTrn6SEtYZV31eyR97+'/video/views',521)
	return
def WWUY5Ja7sj0bKuEpfov24P9X():
	Y58mseFlXnVZMd9Of = JJTrn6SEtYZV31eyR97+'/lineup?utf8=%E2%9C%93'
	NZGd7qFAuiM4RQKsvwHbho1 = Y58mseFlXnVZMd9Of+'&type=2&category=1&foreign=false&tag='
	Quej8GtyC1RB5i9JOXho = Y58mseFlXnVZMd9Of+'&type=2&category=3&foreign=false&tag='
	zzuH6jTisWh27I0dQCxS = Y58mseFlXnVZMd9Of+'&type=2&category=1&foreign=true&tag='
	HHwvo2AaRC7FYKdtXrLfT5iGJ3EZ = Y58mseFlXnVZMd9Of+'&type=2&category=3&foreign=true&tag='
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مصنفات أفلام عربي',NZGd7qFAuiM4RQKsvwHbho1,511)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مصنفات مسلسلات عربي',Quej8GtyC1RB5i9JOXho,511)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مصنفات أفلام اجنبي',zzuH6jTisWh27I0dQCxS,511)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مصنفات مسلسلات اجنبي',HHwvo2AaRC7FYKdtXrLfT5iGJ3EZ,511)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فهرس أعمال أبجدي',JJTrn6SEtYZV31eyR97+'/index/work/alphabet',517)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فهرس  بلد الإنتاج',JJTrn6SEtYZV31eyR97+'/index/work/country',517)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فهرس اللغة',JJTrn6SEtYZV31eyR97+'/index/work/language',517)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فهرس مصنفات العمل',JJTrn6SEtYZV31eyR97+'/index/work/genre',517)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فهرس سنة الإصدار',JJTrn6SEtYZV31eyR97+'/index/work/release_year',517)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مواسم - فلتر محدد',JJTrn6SEtYZV31eyR97+'/seasonals',515)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مواسم - فلتر كامل',JJTrn6SEtYZV31eyR97+'/seasonals',514)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مصنفات - فلتر محدد',JJTrn6SEtYZV31eyR97+'/lineup',515)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مصنفات - فلتر كامل',JJTrn6SEtYZV31eyR97+'/lineup',514)
	return
def dUqo9HKBnclr64D82OAZsCF0p():
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',JJTrn6SEtYZV31eyR97+'/lineup','',headers,'','','ELCINEMA-MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	ppsJmR6GFKL8TVtoiDCwr9aSY = quQHOVM9o4YXzDt1iFymTdbBlfjU.BeautifulSoup(QstumvzTIEUMXCcx06aD4y8nSqH,'html.parser',multi_valued_attributes=None)
	bdq4e6Wr2gslnSiA38 = ppsJmR6GFKL8TVtoiDCwr9aSY.find('select',attrs={'name':'tag'})
	Y9RKmgsxBefkFcuIj2GULDHy3 = bdq4e6Wr2gslnSiA38.find_all('option')
	for Z7ZzgCTMBsNlVi9 in Y9RKmgsxBefkFcuIj2GULDHy3:
		AARNPWHjQU9dEmDI = Z7ZzgCTMBsNlVi9.get('value')
		if not AARNPWHjQU9dEmDI: continue
		title = Z7ZzgCTMBsNlVi9.text
		if Yd6t3PjlLKk:
			title = title.encode('utf8')
			AARNPWHjQU9dEmDI = AARNPWHjQU9dEmDI.encode('utf8')
		RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+AARNPWHjQU9dEmDI
		title = title.replace('قائمة ','')
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,511)
	return
def vAFsVuz5UNblEP4j1Ow9hiH0():
	Y58mseFlXnVZMd9Of = JJTrn6SEtYZV31eyR97+'/lineup?utf8=%E2%9C%93'
	VU4pXAJPwhNeyQ9IG = Y58mseFlXnVZMd9Of+'&type=1&category=&foreign=&tag='
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مصنفات أشخاص',VU4pXAJPwhNeyQ9IG,511)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فهرس أشخاص أبجدي',JJTrn6SEtYZV31eyR97+'/index/person/alphabet',517)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فهرس موطن',JJTrn6SEtYZV31eyR97+'/index/person/nationality',517)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فهرس  تاريخ الميلاد',JJTrn6SEtYZV31eyR97+'/index/person/birth_year',517)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فهرس  تاريخ الوفاة',JJTrn6SEtYZV31eyR97+'/index/person/death_year',517)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مصنفات - فلتر محدد',JJTrn6SEtYZV31eyR97+'/lineup',515)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مصنفات - فلتر كامل',JJTrn6SEtYZV31eyR97+'/lineup',514)
	return
def rmp42u9HFcBskbY(url):
	if '/seasonals' in url: LcnYtXvRpST3U = 0
	elif '/lineup' in url: LcnYtXvRpST3U = 1
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',url,'',headers,'','','ELCINEMA-LISTS-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	ppsJmR6GFKL8TVtoiDCwr9aSY = quQHOVM9o4YXzDt1iFymTdbBlfjU.BeautifulSoup(QstumvzTIEUMXCcx06aD4y8nSqH,'html.parser',multi_valued_attributes=None)
	n5nyDgxTuHbY0LNV4cWvoBtp = ppsJmR6GFKL8TVtoiDCwr9aSY.find_all(class_='jumbo-theater clearfix')
	for bdq4e6Wr2gslnSiA38 in n5nyDgxTuHbY0LNV4cWvoBtp:
		title = bdq4e6Wr2gslnSiA38.find_all('a')[LcnYtXvRpST3U].text
		RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+bdq4e6Wr2gslnSiA38.find_all('a')[LcnYtXvRpST3U].get('href')
		if Yd6t3PjlLKk:
			title = title.encode('utf8')
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.encode('utf8')
		if not n5nyDgxTuHbY0LNV4cWvoBtp:
			eoFn6ScbAR0aQNJZq1vIWmP(RRucmYBaXegTtNOdGHMQ)
			return
		else:
			title = title.replace('قائمة ','')
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,512)
	dlU0EksuLjrBaq(ppsJmR6GFKL8TVtoiDCwr9aSY,511)
	return
def dlU0EksuLjrBaq(ppsJmR6GFKL8TVtoiDCwr9aSY,mode):
	bdq4e6Wr2gslnSiA38 = ppsJmR6GFKL8TVtoiDCwr9aSY.find(class_='pagination')
	if bdq4e6Wr2gslnSiA38:
		E2EI9ztHSOcdhADX1LGCnYZr = bdq4e6Wr2gslnSiA38.find_all('a')
		denj4Y7Spzg1lWsXKUcRMHPLmGi0Zr = bdq4e6Wr2gslnSiA38.find_all('li')
		q2EF1wcaM5bvzCJLBu = list(zip(E2EI9ztHSOcdhADX1LGCnYZr,denj4Y7Spzg1lWsXKUcRMHPLmGi0Zr))
		OeT2Jo0sp6h1mGdqfFw = -1
		aCjFiMNJDG = len(q2EF1wcaM5bvzCJLBu)
		for BbEFSkYKicqaW,OO5lB3MFyYp8GVxDeXI1iASu9T in q2EF1wcaM5bvzCJLBu:
			OeT2Jo0sp6h1mGdqfFw += 1
			OO5lB3MFyYp8GVxDeXI1iASu9T = OO5lB3MFyYp8GVxDeXI1iASu9T['class']
			if 'unavailable' in OO5lB3MFyYp8GVxDeXI1iASu9T or 'current' in OO5lB3MFyYp8GVxDeXI1iASu9T: continue
			Ym8DlVPuqS1tJb = BbEFSkYKicqaW.text
			oKqQr8Ij0btxZ9SDm6h3Nd = JJTrn6SEtYZV31eyR97+BbEFSkYKicqaW.get('href')
			if Yd6t3PjlLKk:
				Ym8DlVPuqS1tJb = Ym8DlVPuqS1tJb.encode('utf8')
				oKqQr8Ij0btxZ9SDm6h3Nd = oKqQr8Ij0btxZ9SDm6h3Nd.encode('utf8')
			if   OeT2Jo0sp6h1mGdqfFw==0: Ym8DlVPuqS1tJb = 'أولى'
			elif OeT2Jo0sp6h1mGdqfFw==1: Ym8DlVPuqS1tJb = 'سابقة'
			elif OeT2Jo0sp6h1mGdqfFw==aCjFiMNJDG-2: Ym8DlVPuqS1tJb = 'لاحقة'
			elif OeT2Jo0sp6h1mGdqfFw==aCjFiMNJDG-1: Ym8DlVPuqS1tJb = 'أخيرة'
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+Ym8DlVPuqS1tJb,oKqQr8Ij0btxZ9SDm6h3Nd,mode)
	return
def eoFn6ScbAR0aQNJZq1vIWmP(url):
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',url,'',headers,'','','ELCINEMA-TITLES1-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	ppsJmR6GFKL8TVtoiDCwr9aSY = quQHOVM9o4YXzDt1iFymTdbBlfjU.BeautifulSoup(QstumvzTIEUMXCcx06aD4y8nSqH,'html.parser',multi_valued_attributes=None)
	n5nyDgxTuHbY0LNV4cWvoBtp = ppsJmR6GFKL8TVtoiDCwr9aSY.find_all(class_='row')
	items,Fl9VDzobcU = [],True
	for bdq4e6Wr2gslnSiA38 in n5nyDgxTuHbY0LNV4cWvoBtp:
		if not bdq4e6Wr2gslnSiA38.find(class_='thumbnail-wrapper'): continue
		if Fl9VDzobcU: Fl9VDzobcU = False ; continue
		KKzW45oYjtdrT1se0XLymEZwivD2A = []
		UU3mPwbfpOCnvVMshEBXTH12AQDer = bdq4e6Wr2gslnSiA38.find_all(class_=['censorship red','censorship purple'])
		for CWP5EAOmfuHigXDNlj4I in UU3mPwbfpOCnvVMshEBXTH12AQDer:
			zzIWR9wx8MXvqNC3 = CWP5EAOmfuHigXDNlj4I.find_all('li')[1].text
			if Yd6t3PjlLKk:
				zzIWR9wx8MXvqNC3 = zzIWR9wx8MXvqNC3.encode('utf8')
			KKzW45oYjtdrT1se0XLymEZwivD2A.append(zzIWR9wx8MXvqNC3)
		if not GBC7yanr9WNYIKXSHRxgP(ll6f2wvU4FdqL3MJyDxORESCK197i,'',KKzW45oYjtdrT1se0XLymEZwivD2A,False):
			ttiasLcTXGvgqb41nC7DRF = bdq4e6Wr2gslnSiA38.find('img').get('data-src')
			title = bdq4e6Wr2gslnSiA38.find('h3')
			name = title.find('a').text
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+title.find('a').get('href')
			OON1dUjRbkgYlcIMPt35xn = bdq4e6Wr2gslnSiA38.find(class_='no-margin')
			uBT3Y5ZKxDQ2glE = bdq4e6Wr2gslnSiA38.find(class_='legend')
			if OON1dUjRbkgYlcIMPt35xn: OON1dUjRbkgYlcIMPt35xn = OON1dUjRbkgYlcIMPt35xn.text
			if uBT3Y5ZKxDQ2glE: uBT3Y5ZKxDQ2glE = uBT3Y5ZKxDQ2glE.text
			if Yd6t3PjlLKk:
				ttiasLcTXGvgqb41nC7DRF = ttiasLcTXGvgqb41nC7DRF.encode('utf8')
				name = name.encode('utf8')
				RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.encode('utf8')
				if OON1dUjRbkgYlcIMPt35xn: OON1dUjRbkgYlcIMPt35xn = OON1dUjRbkgYlcIMPt35xn.encode('utf8')
			B0BjfWuVKkht7gPaNqFsTJOdcHbw = {}
			if uBT3Y5ZKxDQ2glE: B0BjfWuVKkht7gPaNqFsTJOdcHbw['stars'] = uBT3Y5ZKxDQ2glE
			if OON1dUjRbkgYlcIMPt35xn:
				OON1dUjRbkgYlcIMPt35xn = OON1dUjRbkgYlcIMPt35xn.replace('\n',' .. ')
				B0BjfWuVKkht7gPaNqFsTJOdcHbw['plot'] = OON1dUjRbkgYlcIMPt35xn.replace('...اقرأ المزيد','')
			if '/work/' in RRucmYBaXegTtNOdGHMQ:
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+name,RRucmYBaXegTtNOdGHMQ,516,ttiasLcTXGvgqb41nC7DRF,'',name,'',B0BjfWuVKkht7gPaNqFsTJOdcHbw)
			elif '/person/' in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+name,RRucmYBaXegTtNOdGHMQ,513,ttiasLcTXGvgqb41nC7DRF,'',name,'',B0BjfWuVKkht7gPaNqFsTJOdcHbw)
	dlU0EksuLjrBaq(ppsJmR6GFKL8TVtoiDCwr9aSY,512)
	return
def n78nb9VSjUlCtDuw0YEm(url):
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',url,'',headers,'','','ELCINEMA-TITLES2-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	ppsJmR6GFKL8TVtoiDCwr9aSY = quQHOVM9o4YXzDt1iFymTdbBlfjU.BeautifulSoup(QstumvzTIEUMXCcx06aD4y8nSqH,'html.parser',multi_valued_attributes=None)
	n5nyDgxTuHbY0LNV4cWvoBtp = ppsJmR6GFKL8TVtoiDCwr9aSY.find_all('li')
	dmBJGMLH1U7,items = [],[]
	for bdq4e6Wr2gslnSiA38 in n5nyDgxTuHbY0LNV4cWvoBtp:
		if not bdq4e6Wr2gslnSiA38.find(class_='thumbnail-wrapper'): continue
		if not bdq4e6Wr2gslnSiA38.find(class_=['unstyled','unstyled text-center']): continue
		if bdq4e6Wr2gslnSiA38.find(class_='hide'): continue
		title = bdq4e6Wr2gslnSiA38.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in dmBJGMLH1U7: continue
		dmBJGMLH1U7.append(name)
		RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+title.find('a').get('href')
		if '/search/work/' in url: ttiasLcTXGvgqb41nC7DRF = bdq4e6Wr2gslnSiA38.find('img').get('src')
		elif '/search/person/' in url: ttiasLcTXGvgqb41nC7DRF = bdq4e6Wr2gslnSiA38.find('img').get('data-src')
		elif '/search/video/' in url: ttiasLcTXGvgqb41nC7DRF = bdq4e6Wr2gslnSiA38.find('img').get('data-src')
		else: ttiasLcTXGvgqb41nC7DRF = bdq4e6Wr2gslnSiA38.find('img').get('src')
		if Yd6t3PjlLKk:
			name = name.encode('utf8')
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.encode('utf8')
			ttiasLcTXGvgqb41nC7DRF = ttiasLcTXGvgqb41nC7DRF.encode('utf8')
		name = name.strip(' ')
		items.append((name,RRucmYBaXegTtNOdGHMQ,ttiasLcTXGvgqb41nC7DRF))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,RRucmYBaXegTtNOdGHMQ,ttiasLcTXGvgqb41nC7DRF in items:
		if '/search/video/' in url: Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+name,RRucmYBaXegTtNOdGHMQ,522,ttiasLcTXGvgqb41nC7DRF)
		elif '/search/person/' in url: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+name,RRucmYBaXegTtNOdGHMQ,513,ttiasLcTXGvgqb41nC7DRF,'',name)
		else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+name,RRucmYBaXegTtNOdGHMQ,516,ttiasLcTXGvgqb41nC7DRF,'',name)
	return
def sZmzvGOCjUyHIR5dfpJMVuB2S(text):
	text = text.replace('الإعلان','').replace('لفيلم','').replace('الرسمي','')
	text = text.replace('إعلان','').replace('فيلم','').replace('البرومو','')
	text = text.replace('التشويقي','').replace('لمسلسل','').replace('مسلسل','')
	text = text.replace(':','').replace(')','').replace('(','').replace(',','')
	text = text.replace('_','').replace(';','').replace('-','').replace('.','')
	text = text.replace('\'','').replace('\"','')
	text = text.replace('    ',' ').replace('   ',' ').replace('  ',' ')
	text = text.strip(' ')
	kzwida8SnZHDT9KfPymgL0lov5xOhG = text.count(' ')+1
	if kzwida8SnZHDT9KfPymgL0lov5xOhG==1:
		WuVCBopcYK8EIrn6y2(text)
		return
	Tca7NsYPkIRWtBpFgxLZbSmCi('link',W74fAyGxODoLPs5vMX2l8C93R+'[COLOR FFC89008]==== كلمات للبحث ====[/COLOR]','',9999)
	PY6rhFspfv3I = text.split(' ')
	c6cN4PpDtarxmWGIZHeudRb = pow(2,kzwida8SnZHDT9KfPymgL0lov5xOhG)
	wpZFv8L72Ir = []
	def Fx1ZuT5bXVIE6(t1XqvOW7h3IDQRuErCjyg,NNegALBo7uywU2CbGQczXpa1):
		if t1XqvOW7h3IDQRuErCjyg=='1': return NNegALBo7uywU2CbGQczXpa1
		return ''
	for OeT2Jo0sp6h1mGdqfFw in range(c6cN4PpDtarxmWGIZHeudRb,0,-1):
		vOpbZm7TP2oExS8JlqdKGIjFi0C = list(kzwida8SnZHDT9KfPymgL0lov5xOhG*'0'+bin(OeT2Jo0sp6h1mGdqfFw)[2:])[-kzwida8SnZHDT9KfPymgL0lov5xOhG:]
		vOpbZm7TP2oExS8JlqdKGIjFi0C = reversed(vOpbZm7TP2oExS8JlqdKGIjFi0C)
		FaLTw4gN9ZCSkJeqObQPu870o = map(Fx1ZuT5bXVIE6,vOpbZm7TP2oExS8JlqdKGIjFi0C,PY6rhFspfv3I)
		title = ' '.join(filter(None,FaLTw4gN9ZCSkJeqObQPu870o))
		if Yd6t3PjlLKk: Wu4CadwRTJfkbXMUVxO3jQ2 = title.decode('utf8')
		else: Wu4CadwRTJfkbXMUVxO3jQ2 = title
		if len(Wu4CadwRTJfkbXMUVxO3jQ2)>2 and title not in wpZFv8L72Ir:
			wpZFv8L72Ir.append(title)
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,'',523,'','',title)
	return
def WuVCBopcYK8EIrn6y2(C7i9Byuo4DsraGHAjKJE0nzk5q):
	if Yd6t3PjlLKk:
		C7i9Byuo4DsraGHAjKJE0nzk5q = C7i9Byuo4DsraGHAjKJE0nzk5q.decode('utf8')
		import arabic_reshaper as x5A2JcgkRl78yafIoMZCWD
		C7i9Byuo4DsraGHAjKJE0nzk5q = x5A2JcgkRl78yafIoMZCWD.ArabicReshaper().reshape(C7i9Byuo4DsraGHAjKJE0nzk5q)
		C7i9Byuo4DsraGHAjKJE0nzk5q = hBvy1ernIGgsxCc4bSJMEjQXuLU.get_display(C7i9Byuo4DsraGHAjKJE0nzk5q)
	import HzOyl02xJf
	C7i9Byuo4DsraGHAjKJE0nzk5q = CjyEnpfQ23o0PYwDtLId(yj4nE0cZHBgXfbT2xM5ovmF3AJN=C7i9Byuo4DsraGHAjKJE0nzk5q)
	HzOyl02xJf.F6OgHwYPRiX10tJEv8r(C7i9Byuo4DsraGHAjKJE0nzk5q)
	return
def DpPMsVZcEWuTG(url):
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',url,'',headers,'','','ELCINEMA-INDEXES_LISTS-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	ppsJmR6GFKL8TVtoiDCwr9aSY = quQHOVM9o4YXzDt1iFymTdbBlfjU.BeautifulSoup(QstumvzTIEUMXCcx06aD4y8nSqH,'html.parser',multi_valued_attributes=None)
	bdq4e6Wr2gslnSiA38 = ppsJmR6GFKL8TVtoiDCwr9aSY.find(class_='list-separator list-title')
	mwXy4HaY1uWtlvbZVcN7 = bdq4e6Wr2gslnSiA38.find_all('a')
	items = []
	for title in mwXy4HaY1uWtlvbZVcN7:
		name = title.text
		RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+title.get('href')
		if Yd6t3PjlLKk:
			name = name.encode('utf8')
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.encode('utf8')
		if '#' not in RRucmYBaXegTtNOdGHMQ: items.append((name,RRucmYBaXegTtNOdGHMQ))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for q8BXZlN9sU1fP2JAxH7W in items:
		name,RRucmYBaXegTtNOdGHMQ = q8BXZlN9sU1fP2JAxH7W
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+name,RRucmYBaXegTtNOdGHMQ,518)
	return
def MQefyGY3d46FUuBE(url):
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',url,'',headers,'','','ELCINEMA-INDEXES_TITLES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	ppsJmR6GFKL8TVtoiDCwr9aSY = quQHOVM9o4YXzDt1iFymTdbBlfjU.BeautifulSoup(QstumvzTIEUMXCcx06aD4y8nSqH,'html.parser',multi_valued_attributes=None)
	n5nyDgxTuHbY0LNV4cWvoBtp = ppsJmR6GFKL8TVtoiDCwr9aSY.find(class_='expand').find_all('tr')
	for bdq4e6Wr2gslnSiA38 in n5nyDgxTuHbY0LNV4cWvoBtp:
		A1D7uO29os3zKHJF = bdq4e6Wr2gslnSiA38.find_all('a')
		if not A1D7uO29os3zKHJF: continue
		ttiasLcTXGvgqb41nC7DRF = bdq4e6Wr2gslnSiA38.find('img').get('data-src')
		name = A1D7uO29os3zKHJF[1].text
		RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+A1D7uO29os3zKHJF[1].get('href')
		uBT3Y5ZKxDQ2glE = bdq4e6Wr2gslnSiA38.find(class_='legend')
		if uBT3Y5ZKxDQ2glE: uBT3Y5ZKxDQ2glE = uBT3Y5ZKxDQ2glE.text
		if Yd6t3PjlLKk:
			name = name.encode('utf8')
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.encode('utf8')
			ttiasLcTXGvgqb41nC7DRF = ttiasLcTXGvgqb41nC7DRF.encode('utf8')
		B0BjfWuVKkht7gPaNqFsTJOdcHbw = {}
		if uBT3Y5ZKxDQ2glE: B0BjfWuVKkht7gPaNqFsTJOdcHbw['stars'] = uBT3Y5ZKxDQ2glE
		if '/work/' in RRucmYBaXegTtNOdGHMQ:
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+name,RRucmYBaXegTtNOdGHMQ,516,ttiasLcTXGvgqb41nC7DRF,'',name,'',B0BjfWuVKkht7gPaNqFsTJOdcHbw)
		elif '/person/' in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+name,RRucmYBaXegTtNOdGHMQ,513,ttiasLcTXGvgqb41nC7DRF,'',name,'',B0BjfWuVKkht7gPaNqFsTJOdcHbw)
	dlU0EksuLjrBaq(ppsJmR6GFKL8TVtoiDCwr9aSY,518)
	return
def jQYJbzTCBSioyLvDe(url):
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',url,'',headers,'','','ELCINEMA-VIDEOS_LISTS-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	ppsJmR6GFKL8TVtoiDCwr9aSY = quQHOVM9o4YXzDt1iFymTdbBlfjU.BeautifulSoup(QstumvzTIEUMXCcx06aD4y8nSqH,'html.parser',multi_valued_attributes=None)
	mwXy4HaY1uWtlvbZVcN7 = ppsJmR6GFKL8TVtoiDCwr9aSY.find_all(class_='section-title inline')
	R28S4pFmAojEW7CGnx = ppsJmR6GFKL8TVtoiDCwr9aSY.find_all(class_='button green small right')
	items = zip(mwXy4HaY1uWtlvbZVcN7,R28S4pFmAojEW7CGnx)
	for title,RRucmYBaXegTtNOdGHMQ in items:
		title = title.text
		RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ.get('href')
		if Yd6t3PjlLKk:
			title = title.encode('utf8')
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.encode('utf8')
		title = title.replace('    ',' ').replace('   ',' ').replace('  ',' ')
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,521)
	return
def UZ9BNQJFflbnyvqi3A5I(url):
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',url,'',headers,'','','ELCINEMA-VIDEOS_TITLES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	ppsJmR6GFKL8TVtoiDCwr9aSY = quQHOVM9o4YXzDt1iFymTdbBlfjU.BeautifulSoup(QstumvzTIEUMXCcx06aD4y8nSqH,'html.parser',multi_valued_attributes=None)
	Ak48vVe3LnGfJKowPYN = ppsJmR6GFKL8TVtoiDCwr9aSY.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	n5nyDgxTuHbY0LNV4cWvoBtp = Ak48vVe3LnGfJKowPYN.find_all('li')
	for bdq4e6Wr2gslnSiA38 in n5nyDgxTuHbY0LNV4cWvoBtp:
		title = bdq4e6Wr2gslnSiA38.find(class_='title').text
		RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+bdq4e6Wr2gslnSiA38.find('a').get('href')
		ttiasLcTXGvgqb41nC7DRF = bdq4e6Wr2gslnSiA38.find('img').get('data-src')
		UombAD0Kk4XqOrYLB = bdq4e6Wr2gslnSiA38.find(class_='duration').text
		if Yd6t3PjlLKk:
			title = title.encode('utf8')
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.encode('utf8')
			ttiasLcTXGvgqb41nC7DRF = ttiasLcTXGvgqb41nC7DRF.encode('utf8')
			UombAD0Kk4XqOrYLB = UombAD0Kk4XqOrYLB.encode('utf8')
		UombAD0Kk4XqOrYLB = UombAD0Kk4XqOrYLB.replace('\n','').strip(' ')
		Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,522,ttiasLcTXGvgqb41nC7DRF,UombAD0Kk4XqOrYLB)
	dlU0EksuLjrBaq(ppsJmR6GFKL8TVtoiDCwr9aSY,521)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',url,'',headers,'','','ELCINEMA-PLAY-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	ppsJmR6GFKL8TVtoiDCwr9aSY = quQHOVM9o4YXzDt1iFymTdbBlfjU.BeautifulSoup(QstumvzTIEUMXCcx06aD4y8nSqH,'html.parser',multi_valued_attributes=None)
	RRucmYBaXegTtNOdGHMQ = ppsJmR6GFKL8TVtoiDCwr9aSY.find(class_='flex-video').find('iframe').get('src')
	if Yd6t3PjlLKk: RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.encode('utf8')
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs([RRucmYBaXegTtNOdGHMQ],ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	search = search.replace(' ','%20')
	url = JJTrn6SEtYZV31eyR97+'/search/?q='+search
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',url,'',headers,'','','ELCINEMA-SEARCH-1st')
	if not wpFmEA3z8JR.succeeded:
		VU4pXAJPwhNeyQ9IG = JJTrn6SEtYZV31eyR97+'/search_entity/?q='+search+'&entity=work'
		oKqQr8Ij0btxZ9SDm6h3Nd = JJTrn6SEtYZV31eyR97+'/search_entity/?q='+search+'&entity=person'
		hiyL1a8Adr30sbTv65WNKtlYGmwnj = JJTrn6SEtYZV31eyR97+'/search_entity/?q='+search+'&entity=video'
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث عن أعمال',VU4pXAJPwhNeyQ9IG,513,'',search)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث عن أشخاص',oKqQr8Ij0btxZ9SDm6h3Nd,513,'',search)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث عن فيديوهات',hiyL1a8Adr30sbTv65WNKtlYGmwnj,513,'',search)
		return
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	ppsJmR6GFKL8TVtoiDCwr9aSY = quQHOVM9o4YXzDt1iFymTdbBlfjU.BeautifulSoup(QstumvzTIEUMXCcx06aD4y8nSqH,'html.parser',multi_valued_attributes=None)
	n5nyDgxTuHbY0LNV4cWvoBtp = ppsJmR6GFKL8TVtoiDCwr9aSY.find_all(class_='section-title left')
	for bdq4e6Wr2gslnSiA38 in n5nyDgxTuHbY0LNV4cWvoBtp:
		title = bdq4e6Wr2gslnSiA38.text
		if Yd6t3PjlLKk:
			title = title.encode('utf8')
		title = title.split('(',1)[0].strip(' ')
		if   'أعمال' in title: RRucmYBaXegTtNOdGHMQ = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: RRucmYBaXegTtNOdGHMQ = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: RRucmYBaXegTtNOdGHMQ = url.replace('/search/','/search/video/')
		else: continue
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,513)
	return
def GKlfHuPOgLEW8Y6qSm(url,text):
	global E0tDmCreab3BWYTcdIupkU46v,t1tvAd5EPXM
	if '/seasonals' in url:
		E0tDmCreab3BWYTcdIupkU46v = ['seasonal','year','category']
		t1tvAd5EPXM = ['seasonal','year','category']
	elif '/lineup' in url:
		E0tDmCreab3BWYTcdIupkU46v = ['category','foreign','type']
		t1tvAd5EPXM = ['category','foreign','type']
	nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,text)
	return
def VB2O0ktvjpGqC4JrTKlu9EWsIM(url):
	url = url.split('/smartemadfilter?')[0]
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',url,'',headers,'','','ELCINEMA-GET_FILTERS_BLOCKS-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('form action="/(.*?)</form>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	jNFqoOewYB2mG = ZXFs0mEPR8qI2zj.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	return jNFqoOewYB2mG
def ZsvjUo8dVL0cPGRIqD5iEgN67COr(bdq4e6Wr2gslnSiA38):
	items = ZXFs0mEPR8qI2zj.findall('<option value="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	return items
def mMV5WYge1qZDd3oU7QcP(url):
	ZFcjgy5Kb1GuRlmeCqY0vT = url.split('/smartemadfilter?')[0]
	SSybMXta8gxTFKrUZDwNLWPcoHfEQ = d78KRnJmBWscGua0XMk(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def TPlV8LkHBjoZyJK7w3Xg0dWec(t9NhYxrZKcBf4u,url):
	KMUEN9cD1OByji = l0mO1GdhAtb(t9NhYxrZKcBf4u,'all_filters')
	aaIn3XlQKJ6zSfkmjuCyM = url+'/smartemadfilter?'+KMUEN9cD1OByji
	aaIn3XlQKJ6zSfkmjuCyM = mMV5WYge1qZDd3oU7QcP(aaIn3XlQKJ6zSfkmjuCyM)
	return aaIn3XlQKJ6zSfkmjuCyM
def nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': SFbYEzoech4wU1,kXR5NJaOcQUd47zugHqCAvjGoLmW = '',''
	else: SFbYEzoech4wU1,kXR5NJaOcQUd47zugHqCAvjGoLmW = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if E0tDmCreab3BWYTcdIupkU46v[0]+'=' not in SFbYEzoech4wU1: p8pgXONsjY = E0tDmCreab3BWYTcdIupkU46v[0]
		for xxFhvt275i8MdUVuPkSXzmbT in range(len(E0tDmCreab3BWYTcdIupkU46v[0:-1])):
			if E0tDmCreab3BWYTcdIupkU46v[xxFhvt275i8MdUVuPkSXzmbT]+'=' in SFbYEzoech4wU1: p8pgXONsjY = E0tDmCreab3BWYTcdIupkU46v[xxFhvt275i8MdUVuPkSXzmbT+1]
		vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&'+p8pgXONsjY+'=0'
		t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&'+p8pgXONsjY+'=0'
		tt6AbxYRgQ3aC4O = vX5qmpr1hSAszGE.strip('&')+'___'+t9NhYxrZKcBf4u.strip('&')
		KMUEN9cD1OByji = l0mO1GdhAtb(kXR5NJaOcQUd47zugHqCAvjGoLmW,'modified_filters')
		lQHXdV9Nzf6BLqS8D = url+'/smartemadfilter?'+KMUEN9cD1OByji
	elif type=='ALL_ITEMS_FILTER':
		cOM2mQXqbrRyiKasDz = l0mO1GdhAtb(SFbYEzoech4wU1,'modified_values')
		cOM2mQXqbrRyiKasDz = ejBOu2WXwvb4YpITdsLF16(cOM2mQXqbrRyiKasDz)
		if kXR5NJaOcQUd47zugHqCAvjGoLmW!='': kXR5NJaOcQUd47zugHqCAvjGoLmW = l0mO1GdhAtb(kXR5NJaOcQUd47zugHqCAvjGoLmW,'modified_filters')
		if kXR5NJaOcQUd47zugHqCAvjGoLmW=='': lQHXdV9Nzf6BLqS8D = url
		else: lQHXdV9Nzf6BLqS8D = url+'/smartemadfilter?'+kXR5NJaOcQUd47zugHqCAvjGoLmW
		lQHXdV9Nzf6BLqS8D = mMV5WYge1qZDd3oU7QcP(lQHXdV9Nzf6BLqS8D)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'أظهار قائمة الفيديو التي تم اختيارها ',lQHXdV9Nzf6BLqS8D,511)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+' [[   '+cOM2mQXqbrRyiKasDz+'   ]]',lQHXdV9Nzf6BLqS8D,511)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	jNFqoOewYB2mG = VB2O0ktvjpGqC4JrTKlu9EWsIM(url)
	dict = {}
	for name,Lm4n6ZMXPrWpo,bdq4e6Wr2gslnSiA38 in jNFqoOewYB2mG:
		name = name.replace('--','')
		items = ZsvjUo8dVL0cPGRIqD5iEgN67COr(bdq4e6Wr2gslnSiA38)
		if '=' not in lQHXdV9Nzf6BLqS8D: lQHXdV9Nzf6BLqS8D = url
		if type=='SPECIFIED_FILTER':
			if Lm4n6ZMXPrWpo not in E0tDmCreab3BWYTcdIupkU46v: continue
			if p8pgXONsjY!=Lm4n6ZMXPrWpo: continue
			elif len(items)<2:
				if Lm4n6ZMXPrWpo==E0tDmCreab3BWYTcdIupkU46v[-1]:
					url = mMV5WYge1qZDd3oU7QcP(url)
					eoFn6ScbAR0aQNJZq1vIWmP(url)
				else: nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(lQHXdV9Nzf6BLqS8D,'SPECIFIED_FILTER___'+tt6AbxYRgQ3aC4O)
				return
			else:
				lQHXdV9Nzf6BLqS8D = mMV5WYge1qZDd3oU7QcP(lQHXdV9Nzf6BLqS8D)
				if Lm4n6ZMXPrWpo==E0tDmCreab3BWYTcdIupkU46v[-1]: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع',lQHXdV9Nzf6BLqS8D,511)
				else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع',lQHXdV9Nzf6BLqS8D,515,'','',tt6AbxYRgQ3aC4O)
		elif type=='ALL_ITEMS_FILTER':
			if Lm4n6ZMXPrWpo not in t1tvAd5EPXM: continue
			vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&'+Lm4n6ZMXPrWpo+'=0'
			t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&'+Lm4n6ZMXPrWpo+'=0'
			tt6AbxYRgQ3aC4O = vX5qmpr1hSAszGE+'___'+t9NhYxrZKcBf4u
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع: '+name,lQHXdV9Nzf6BLqS8D,514,'','',tt6AbxYRgQ3aC4O)
		dict[Lm4n6ZMXPrWpo] = {}
		for AARNPWHjQU9dEmDI,Z7ZzgCTMBsNlVi9 in items:
			if Z7ZzgCTMBsNlVi9 in SmgoEYJ7uyL: continue
			if 'مصنفات أخرى' in Z7ZzgCTMBsNlVi9: continue
			if 'الكل' in Z7ZzgCTMBsNlVi9: continue
			if 'اللغة' in Z7ZzgCTMBsNlVi9: continue
			Z7ZzgCTMBsNlVi9 = Z7ZzgCTMBsNlVi9.replace('قائمة ','')
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[Lm4n6ZMXPrWpo][AARNPWHjQU9dEmDI] = Z7ZzgCTMBsNlVi9
			vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&'+Lm4n6ZMXPrWpo+'='+Z7ZzgCTMBsNlVi9
			t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&'+Lm4n6ZMXPrWpo+'='+AARNPWHjQU9dEmDI
			WYXmvw9l3jToq6rui1SCs = vX5qmpr1hSAszGE+'___'+t9NhYxrZKcBf4u
			if name: title = Z7ZzgCTMBsNlVi9+' :'+name
			else: title = Z7ZzgCTMBsNlVi9
			if type=='ALL_ITEMS_FILTER': Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,514,'','',WYXmvw9l3jToq6rui1SCs)
			elif type=='SPECIFIED_FILTER' and E0tDmCreab3BWYTcdIupkU46v[-2]+'=' in SFbYEzoech4wU1:
				aaIn3XlQKJ6zSfkmjuCyM = TPlV8LkHBjoZyJK7w3Xg0dWec(t9NhYxrZKcBf4u,url)
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,aaIn3XlQKJ6zSfkmjuCyM,511)
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,515,'','',WYXmvw9l3jToq6rui1SCs)
	return
def l0mO1GdhAtb(zIpQyOG78Nvreijwa,mode):
	zIpQyOG78Nvreijwa = zIpQyOG78Nvreijwa.replace('=&','=0&')
	zIpQyOG78Nvreijwa = zIpQyOG78Nvreijwa.strip('&')
	JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p = {}
	if '=' in zIpQyOG78Nvreijwa:
		items = zIpQyOG78Nvreijwa.split('&')
		for q8BXZlN9sU1fP2JAxH7W in items:
			cfMR9TgeL2hx6Wnq4liDX,AARNPWHjQU9dEmDI = q8BXZlN9sU1fP2JAxH7W.split('=')
			JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p[cfMR9TgeL2hx6Wnq4liDX] = AARNPWHjQU9dEmDI
	rXLaWluDjvi4xMwpOSF91JB7 = ''
	for key in t1tvAd5EPXM:
		if key in list(JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p.keys()): AARNPWHjQU9dEmDI = JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p[key]
		else: AARNPWHjQU9dEmDI = '0'
		if '%' not in AARNPWHjQU9dEmDI: AARNPWHjQU9dEmDI = cD1AgYCl0qZI8(AARNPWHjQU9dEmDI)
		if mode=='modified_values' and AARNPWHjQU9dEmDI!='0': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+' + '+AARNPWHjQU9dEmDI
		elif mode=='modified_filters' and AARNPWHjQU9dEmDI!='0': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+'&'+key+'='+AARNPWHjQU9dEmDI
		elif mode=='all_filters': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+'&'+key+'='+AARNPWHjQU9dEmDI
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.strip(' + ')
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.strip('&')
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.replace('=0','=')
	return rXLaWluDjvi4xMwpOSF91JB7
E0tDmCreab3BWYTcdIupkU46v = []
t1tvAd5EPXM = []
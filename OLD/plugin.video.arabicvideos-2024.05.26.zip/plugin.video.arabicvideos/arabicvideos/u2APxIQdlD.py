# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'CIMACLUB'
W74fAyGxODoLPs5vMX2l8C93R = '_CCB_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
SmgoEYJ7uyL = ['عروض المصارعه','للكبار فقط +18','الرئيسية','افلام للكبار فقط','DMCA','مصارعة حرة']
def OVQIAezo6U1NSTl4L(mode,url,wwNtFTLK2IqAszYBDV9J,text):
	if   mode==820: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==821: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,wwNtFTLK2IqAszYBDV9J)
	elif mode==822: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==823: HkKfQCS7RIa4xi3houjvl = DFjzy4r8hXNtR0(url,text)
	elif mode==824: HkKfQCS7RIa4xi3houjvl = nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,'FULL_FILTER___'+text)
	elif mode==825: HkKfQCS7RIa4xi3houjvl = nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,'DEFINED_FILTER___'+text)
	elif mode==829: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',JJTrn6SEtYZV31eyR97,'','','','','CIMACLUB-MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	NGmuWwXdLQ6nMltx39FYECohJ = wpFmEA3z8JR.url
	if Yd6t3PjlLKk: NGmuWwXdLQ6nMltx39FYECohJ = NGmuWwXdLQ6nMltx39FYECohJ.encode('utf8')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع',NGmuWwXdLQ6nMltx39FYECohJ,829,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'المميزة',NGmuWwXdLQ6nMltx39FYECohJ,821,'','featured','_REMEMBERRESULTS_')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"Tabs"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('get="(.*?)".*?<span>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for data,title in items:
			RRucmYBaXegTtNOdGHMQ = NGmuWwXdLQ6nMltx39FYECohJ+'/getposts?type=one&data='+data
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,821,'','highest')
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('navigation-menu(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			if '/' not in RRucmYBaXegTtNOdGHMQ: continue
			if '=' in RRucmYBaXegTtNOdGHMQ: continue
			if title in SmgoEYJ7uyL: continue
			if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = NGmuWwXdLQ6nMltx39FYECohJ+RRucmYBaXegTtNOdGHMQ
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,821)
	return
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,type=''):
	NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(url,'url')
	bdq4e6Wr2gslnSiA38,items = '',[]
	if type=='featured':
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','CIMACLUB-TITLES-1st')
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('home-slider(.*?)page-content',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n: bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	elif type=='highest':
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','CIMACLUB-TITLES-2nd')
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	else:
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','CIMACLUB-TITLES-3rd')
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('page-content(.*?)footer-menu',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n: bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	if not bdq4e6Wr2gslnSiA38: bdq4e6Wr2gslnSiA38 = QstumvzTIEUMXCcx06aD4y8nSqH
	if not items: items = ZXFs0mEPR8qI2zj.findall('content-box.*?href="(.*?)".*?src="(.*?)".*?<h3>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	wpZFv8L72Ir = []
	for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
		RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.replace('\/','/')
		if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = NGmuWwXdLQ6nMltx39FYECohJ+RRucmYBaXegTtNOdGHMQ
		CrGO63LT7j2UxniW = CrGO63LT7j2UxniW.replace('\/','/')
		RRucmYBaXegTtNOdGHMQ = WhJe7bGx5XackTwOIZVLC8ut(RRucmYBaXegTtNOdGHMQ)
		title = WhJe7bGx5XackTwOIZVLC8ut(title)
		LqYKJ36CBG = ZXFs0mEPR8qI2zj.findall('(.*?) (حلقة|الحلقة)',title,ZXFs0mEPR8qI2zj.DOTALL)
		if LqYKJ36CBG: title = '_MOD_'+LqYKJ36CBG[0][0]
		if title in wpZFv8L72Ir: continue
		wpZFv8L72Ir.append(title)
		if LqYKJ36CBG: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,823,CrGO63LT7j2UxniW)
		else: Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,822,CrGO63LT7j2UxniW)
	if type!='featured':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"paginate"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title in items:
				title = qpob7TvxHSs4fEzO6(title)
				if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = NGmuWwXdLQ6nMltx39FYECohJ+RRucmYBaXegTtNOdGHMQ
				if title: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,RRucmYBaXegTtNOdGHMQ,821)
	return
def DFjzy4r8hXNtR0(url,xnu0LVmQHZEUyd9re8oKficb7):
	NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(url,'url')
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','CIMACLUB-SEASONS_EPISODES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	CrGO63LT7j2UxniW = ZXFs0mEPR8qI2zj.findall('poster-image.*?url\((.*?)\)',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	CrGO63LT7j2UxniW = CrGO63LT7j2UxniW[0] if CrGO63LT7j2UxniW else ''
	items = []
	if not xnu0LVmQHZEUyd9re8oKficb7:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"Seasons"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('<li.*?data-season="(.*?)" data-S="(.*?)" data-B="(.*?)".*?title="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			if len(items)>1:
				for xnu0LVmQHZEUyd9re8oKficb7,d5CKulNTntk49qh2UmQiP,vXDQRxjGJb,title in items:
					title = title.replace('  ',' ')
					RRucmYBaXegTtNOdGHMQ = NGmuWwXdLQ6nMltx39FYECohJ+'/ajaxCenter?_action=GetSeasonEp&_season='+xnu0LVmQHZEUyd9re8oKficb7+'&_S='+d5CKulNTntk49qh2UmQiP+'&_B='+vXDQRxjGJb
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,823,CrGO63LT7j2UxniW,'',xnu0LVmQHZEUyd9re8oKficb7)
	if len(items)<2:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('episodes-ul"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n: EMtDTaSOYV0mCx3cUjyBobgzp,bdq4e6Wr2gslnSiA38 = '',IZGcQbePXxwAoyYR1n[0]
		else: EMtDTaSOYV0mCx3cUjyBobgzp,bdq4e6Wr2gslnSiA38 = 'موسم '+xnu0LVmQHZEUyd9re8oKficb7,QstumvzTIEUMXCcx06aD4y8nSqH
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,LqYKJ36CBG in items:
			if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = NGmuWwXdLQ6nMltx39FYECohJ+RRucmYBaXegTtNOdGHMQ
			title = RRucmYBaXegTtNOdGHMQ.split('/',3)[3]
			title = ejBOu2WXwvb4YpITdsLF16(title).strip('/').replace('-',' ').replace('مسلسل ','').replace('مشاهدة ','')
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,822,CrGO63LT7j2UxniW)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	url = url+'/see'
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','CIMACLUB-PLAY-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	yf608hE5KeRG1DscunvrU,B1lkJKt2wS4EHFLuayQvAN9X0gxf = [],[]
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="serverWatch(.*?)class="embed"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('data-embed="(.*?)".*?">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			title = title.strip(' ')
			if RRucmYBaXegTtNOdGHMQ not in B1lkJKt2wS4EHFLuayQvAN9X0gxf:
				B1lkJKt2wS4EHFLuayQvAN9X0gxf.append(RRucmYBaXegTtNOdGHMQ)
				yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ+'?named='+title+'__watch')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('data-tab="downloads"(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?<span>(.*?)</span>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			if RRucmYBaXegTtNOdGHMQ not in B1lkJKt2wS4EHFLuayQvAN9X0gxf:
				B1lkJKt2wS4EHFLuayQvAN9X0gxf.append(RRucmYBaXegTtNOdGHMQ)
				title = title.strip(' ')
				yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ+'?named='+title+'__download')
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(yf608hE5KeRG1DscunvrU,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if not search: search = CjyEnpfQ23o0PYwDtLId()
	if not search: return
	search = search.replace(' ','+')
	url = JJTrn6SEtYZV31eyR97+'/?s='+search
	RxAy5lEFQ1chv0BrdU4p6Pt2(url,'search')
	return
def VB2O0ktvjpGqC4JrTKlu9EWsIM(url):
	url = url.split('/smartemadfilter?')[0]
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',url,'','','','','CIMACLUB-GET_FILTERS_BLOCKS-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	jNFqoOewYB2mG = []
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('advanced-search(.*?)</form>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		jNFqoOewYB2mG = ZXFs0mEPR8qI2zj.findall('select-menu">.*?">(.*?)<.*?data-tax="(.*?)"(.*?)</ul>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		dmBJGMLH1U7,PQqDFYUwuCO0,n5nyDgxTuHbY0LNV4cWvoBtp = zip(*jNFqoOewYB2mG)
		jNFqoOewYB2mG = zip(dmBJGMLH1U7,PQqDFYUwuCO0,n5nyDgxTuHbY0LNV4cWvoBtp)
	return jNFqoOewYB2mG
def ZsvjUo8dVL0cPGRIqD5iEgN67COr(bdq4e6Wr2gslnSiA38):
	items = ZXFs0mEPR8qI2zj.findall('cat="(.*?)".*?bold">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	return items
def eYPc6TvD40LHE7(url):
	NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(url,'url')
	if '/smartemadfilter?' in url:
		url,zIpQyOG78Nvreijwa = url.split('/smartemadfilter?')
		RRucmYBaXegTtNOdGHMQ = NGmuWwXdLQ6nMltx39FYECohJ+'/getposts?'+zIpQyOG78Nvreijwa
	else: RRucmYBaXegTtNOdGHMQ = NGmuWwXdLQ6nMltx39FYECohJ
	return RRucmYBaXegTtNOdGHMQ
ZZNgtFYdW3MTeRKb7 = ['category','release-year','genre','quality']
P3QLjTBhF70tmHuA64DJknIXO = ['category','release-year','genre']
def nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': SFbYEzoech4wU1,kXR5NJaOcQUd47zugHqCAvjGoLmW = '',''
	else: SFbYEzoech4wU1,kXR5NJaOcQUd47zugHqCAvjGoLmW = filter.split('___')
	if type=='DEFINED_FILTER':
		if P3QLjTBhF70tmHuA64DJknIXO[0]+'=' not in SFbYEzoech4wU1: p8pgXONsjY = P3QLjTBhF70tmHuA64DJknIXO[0]
		for xxFhvt275i8MdUVuPkSXzmbT in range(len(P3QLjTBhF70tmHuA64DJknIXO[0:-1])):
			if P3QLjTBhF70tmHuA64DJknIXO[xxFhvt275i8MdUVuPkSXzmbT]+'=' in SFbYEzoech4wU1: p8pgXONsjY = P3QLjTBhF70tmHuA64DJknIXO[xxFhvt275i8MdUVuPkSXzmbT+1]
		vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&'+p8pgXONsjY+'=0'
		t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&'+p8pgXONsjY+'=0'
		tt6AbxYRgQ3aC4O = vX5qmpr1hSAszGE.strip('&')+'___'+t9NhYxrZKcBf4u.strip('&')
		KMUEN9cD1OByji = l0mO1GdhAtb(kXR5NJaOcQUd47zugHqCAvjGoLmW,'modified_filters')
		lQHXdV9Nzf6BLqS8D = url+'/smartemadfilter?'+KMUEN9cD1OByji
	elif type=='FULL_FILTER':
		cOM2mQXqbrRyiKasDz = l0mO1GdhAtb(SFbYEzoech4wU1,'modified_values')
		cOM2mQXqbrRyiKasDz = ejBOu2WXwvb4YpITdsLF16(cOM2mQXqbrRyiKasDz)
		if kXR5NJaOcQUd47zugHqCAvjGoLmW: kXR5NJaOcQUd47zugHqCAvjGoLmW = l0mO1GdhAtb(kXR5NJaOcQUd47zugHqCAvjGoLmW,'modified_filters')
		if not kXR5NJaOcQUd47zugHqCAvjGoLmW: lQHXdV9Nzf6BLqS8D = url
		else: lQHXdV9Nzf6BLqS8D = url+'/smartemadfilter?'+kXR5NJaOcQUd47zugHqCAvjGoLmW
		aaIn3XlQKJ6zSfkmjuCyM = eYPc6TvD40LHE7(lQHXdV9Nzf6BLqS8D)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'أظهار قائمة الفيديو التي تم اختيارها ',aaIn3XlQKJ6zSfkmjuCyM,821,'','filter')
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+' [[   '+cOM2mQXqbrRyiKasDz+'   ]]',aaIn3XlQKJ6zSfkmjuCyM,821,'','filter')
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	jNFqoOewYB2mG = VB2O0ktvjpGqC4JrTKlu9EWsIM(url)
	dict = {}
	for name,Lm4n6ZMXPrWpo,bdq4e6Wr2gslnSiA38 in jNFqoOewYB2mG:
		name = name.replace('كل ','')
		items = ZsvjUo8dVL0cPGRIqD5iEgN67COr(bdq4e6Wr2gslnSiA38)
		if '=' not in lQHXdV9Nzf6BLqS8D: lQHXdV9Nzf6BLqS8D = url
		if type=='DEFINED_FILTER':
			if p8pgXONsjY!=Lm4n6ZMXPrWpo: continue
			elif len(items)<2:
				if Lm4n6ZMXPrWpo==P3QLjTBhF70tmHuA64DJknIXO[-1]:
					aaIn3XlQKJ6zSfkmjuCyM = eYPc6TvD40LHE7(lQHXdV9Nzf6BLqS8D)
					RxAy5lEFQ1chv0BrdU4p6Pt2(aaIn3XlQKJ6zSfkmjuCyM,'filter')
				else: nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(lQHXdV9Nzf6BLqS8D,'DEFINED_FILTER___'+tt6AbxYRgQ3aC4O)
				return
			else:
				if Lm4n6ZMXPrWpo==P3QLjTBhF70tmHuA64DJknIXO[-1]:
					aaIn3XlQKJ6zSfkmjuCyM = eYPc6TvD40LHE7(lQHXdV9Nzf6BLqS8D)
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع ',aaIn3XlQKJ6zSfkmjuCyM,821,'','filter')
				else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع ',lQHXdV9Nzf6BLqS8D,825,'','',tt6AbxYRgQ3aC4O)
		elif type=='FULL_FILTER':
			vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&'+Lm4n6ZMXPrWpo+'=0'
			t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&'+Lm4n6ZMXPrWpo+'=0'
			tt6AbxYRgQ3aC4O = vX5qmpr1hSAszGE+'___'+t9NhYxrZKcBf4u
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع :'+name,lQHXdV9Nzf6BLqS8D,824,'','',tt6AbxYRgQ3aC4O)
		dict[Lm4n6ZMXPrWpo] = {}
		for AARNPWHjQU9dEmDI,Z7ZzgCTMBsNlVi9 in items:
			if not AARNPWHjQU9dEmDI: continue
			if Z7ZzgCTMBsNlVi9 in SmgoEYJ7uyL: continue
			dict[Lm4n6ZMXPrWpo][AARNPWHjQU9dEmDI] = Z7ZzgCTMBsNlVi9
			vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&'+Lm4n6ZMXPrWpo+'='+Z7ZzgCTMBsNlVi9
			t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&'+Lm4n6ZMXPrWpo+'='+AARNPWHjQU9dEmDI
			WYXmvw9l3jToq6rui1SCs = vX5qmpr1hSAszGE+'___'+t9NhYxrZKcBf4u
			title = Z7ZzgCTMBsNlVi9+' :'#+dict[Lm4n6ZMXPrWpo]['0']
			title = Z7ZzgCTMBsNlVi9+' :'+name
			if type=='FULL_FILTER': Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,824,'','',WYXmvw9l3jToq6rui1SCs)
			elif type=='DEFINED_FILTER' and P3QLjTBhF70tmHuA64DJknIXO[-2]+'=' in SFbYEzoech4wU1:
				KMUEN9cD1OByji = l0mO1GdhAtb(t9NhYxrZKcBf4u,'modified_filters')
				lQHXdV9Nzf6BLqS8D = url+'/smartemadfilter?'+KMUEN9cD1OByji
				aaIn3XlQKJ6zSfkmjuCyM = eYPc6TvD40LHE7(lQHXdV9Nzf6BLqS8D)
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,aaIn3XlQKJ6zSfkmjuCyM,821,'','filter')
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,825,'','',WYXmvw9l3jToq6rui1SCs)
	return
def l0mO1GdhAtb(zIpQyOG78Nvreijwa,mode):
	zIpQyOG78Nvreijwa = zIpQyOG78Nvreijwa.replace('=&','=0&')
	zIpQyOG78Nvreijwa = zIpQyOG78Nvreijwa.strip('&')
	JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p = {}
	if '=' in zIpQyOG78Nvreijwa:
		items = zIpQyOG78Nvreijwa.split('&')
		for q8BXZlN9sU1fP2JAxH7W in items:
			cfMR9TgeL2hx6Wnq4liDX,AARNPWHjQU9dEmDI = q8BXZlN9sU1fP2JAxH7W.split('=')
			JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p[cfMR9TgeL2hx6Wnq4liDX] = AARNPWHjQU9dEmDI
	rXLaWluDjvi4xMwpOSF91JB7 = ''
	for key in ZZNgtFYdW3MTeRKb7:
		if key in list(JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p.keys()): AARNPWHjQU9dEmDI = JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p[key]
		else: AARNPWHjQU9dEmDI = '0'
		if '%' not in AARNPWHjQU9dEmDI: AARNPWHjQU9dEmDI = cD1AgYCl0qZI8(AARNPWHjQU9dEmDI)
		if mode=='modified_values' and AARNPWHjQU9dEmDI!='0': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+' + '+AARNPWHjQU9dEmDI
		elif mode=='modified_filters' and AARNPWHjQU9dEmDI!='0': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+'&'+key+'='+AARNPWHjQU9dEmDI
		elif mode=='all': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+'&'+key+'='+AARNPWHjQU9dEmDI
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.strip(' + ')
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.strip('&')
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.replace('=0','=')
	return rXLaWluDjvi4xMwpOSF91JB7
# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'ALKAWTHAR'
Yc0eBRLpbCkm4gK7OqyzuHwU = '_KWT_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
def HgQCVwFx2Br(mode,url,tsMKaFVh1ZN2BIXEcvTejxR5DP,text):
	if   mode==130: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==131: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url)
	elif mode==132: s4Bng5iAZQSTtpDw9 = LXNEU45IzZpCdYcay(url)
	elif mode==133: s4Bng5iAZQSTtpDw9 = btd6ag2XYUkHixqy5J7o9RfLu1MScm(url,tsMKaFVh1ZN2BIXEcvTejxR5DP)
	elif mode==134: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==135: s4Bng5iAZQSTtpDw9 = EvpYWVrnUQA()
	elif mode==139: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text,url)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',139,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,tle5V6jgvRfE,'','',True,'ALKAWTHAR-MENU-1st')
	TIkiozSLCv6werb97mHQ0q4y3=E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('dropdown-menu(.*?)dropdown-toggle',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[1]
	items=E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		if '/conductor' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: continue
		title = title.strip(' ')
		url = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		if '/category/' in url: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,132)
		else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,131)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'المسلسلات',tle5V6jgvRfE+'/category/543',132,'','1')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'الأفلام',tle5V6jgvRfE+'/category/628',132,'','1')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'برامج الصغار والشباب',tle5V6jgvRfE+'/category/517',132,'','1')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'ابرز البرامج',tle5V6jgvRfE+'/category/1763',132,'','1')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'المحاضرات',tle5V6jgvRfE+'/category/943',132,'','1')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'عاشوراء',tle5V6jgvRfE+'/category/1353',132,'','1')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'البرامج الاجتماعية',tle5V6jgvRfE+'/category/501',132,'','1')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'البرامج الدينية',tle5V6jgvRfE+'/category/509',132,'','1')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'البرامج الوثائقية',tle5V6jgvRfE+'/category/553',132,'','1')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'البرامج السياسية',tle5V6jgvRfE+'/category/545',132,'','1')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'كتب',tle5V6jgvRfE+'/category/291',132,'','1')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'تعلم الفارسية',tle5V6jgvRfE+'/category/88',132,'','1')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'أرشيف البرامج',tle5V6jgvRfE+'/category/1279',132,'','1')
	return
def uyt3pAHZk4(url):
	eLxZPjV8OyEFn3sUw0pITaMoHYGrh = ['/religious','/social','/political','/films','/series']
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,url,'','',True,'ALKAWTHAR-TITLES-1st')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('titlebar(.*?)titlebar',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in url for hht0cpXxWw2OzFS1jnUGebkJLBd85 in eLxZPjV8OyEFn3sUw0pITaMoHYGrh):
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("src='(.*?)'.*?href='(.*?)'.*?>(.*?)<",ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for Q2qmuDRrC9ikcaJK7gtUHXNW,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			title = title.strip(' ')
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE + ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,133,Q2qmuDRrC9ikcaJK7gtUHXNW,'1')
	elif '/docs' in url:
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("src='(.*?)'.*?<h2>(.*?)</h2>.*?href='(.*?)'",ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for Q2qmuDRrC9ikcaJK7gtUHXNW,title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
			title = title.strip(' ')
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE + ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,133,Q2qmuDRrC9ikcaJK7gtUHXNW,'1')
	return
def LXNEU45IzZpCdYcay(url):
	cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = url.split('/')[-1]
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,url,'','',True,'ALKAWTHAR-CATEGORIES-1st')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('parentcat(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not TIkiozSLCv6werb97mHQ0q4y3:
		btd6ag2XYUkHixqy5J7o9RfLu1MScm(url,'1')
		return
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("href='(.*?)'.*?>(.*?)<",ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		title = title.strip(' ')
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE + ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,132,'','1')
	return
def btd6ag2XYUkHixqy5J7o9RfLu1MScm(url,tsMKaFVh1ZN2BIXEcvTejxR5DP):
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,url,'','',True,'ALKAWTHAR-EPISODES-1st')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('totalpagecount=[\'"](.*?)[\'"]',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not items:
		url = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="news-detail-body".*?href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		url = url[0]
		title = '_MOD_' + 'ملف التشغيل'
		if url: tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,134)
		else: tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','لا يوجد حاليا ملفات فيديو في هذا الفرع')
		return
	bb0L9KmiaWV = int(items[0])
	name = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('main-title.*?</a> >(.*?)<',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if name: name = name[0].strip(' ')
	else: name = oos8ymFi9CN2z1jXcR.getInfoLabel('ListItem.Label')
	if '/category/' in url or 'search?q=' in url:
		cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = url.split('/')[-1]
		if tsMKaFVh1ZN2BIXEcvTejxR5DP=='': M08MPGgsh4n5rKe = url
		else: M08MPGgsh4n5rKe = tle5V6jgvRfE + '/category/' + cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo + '/' + tsMKaFVh1ZN2BIXEcvTejxR5DP
		flARjI3NM9CQnWY1xk7 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,M08MPGgsh4n5rKe,'','',True,'ALKAWTHAR-EPISODES-2nd')
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('currentpagenumber(.*?)pagination',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('src="(.*?)".*?full(.*?)>.*?href="(.*?)".*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for Q2qmuDRrC9ikcaJK7gtUHXNW,type,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			if 'video' not in type: continue
			if 'مسلسل' in title and 'حلقة' not in title: continue
			title = title.replace('\r\n','')
			title = title.strip(' ')
			if 'مسلسل' in name and 'حلقة' in title and 'مسلسل' not in title:
				title = '_MOD_' + name + ' - ' + title
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE + ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			if cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo=='628': tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,133,Q2qmuDRrC9ikcaJK7gtUHXNW,'1')
			else: tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,134,Q2qmuDRrC9ikcaJK7gtUHXNW)
	elif '/episode/' in url:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('playlist(.*?)col-md-12',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3:
			ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("video-track-text.*?loadVideo\('(.*?)','(.*?)'.*?>(.*?)<",ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title in items:
				title = title.strip(' ')
				tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,134,Q2qmuDRrC9ikcaJK7gtUHXNW)
		elif '/category/628' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2:
				title = '_MOD_' + 'ملف التشغيل'
				tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,134)
		else:
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('id="Categories.*?href=\'(.*?)\'',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = items[0].split('/')[-1]
			url = tle5V6jgvRfE + '/category/' + cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo
			LXNEU45IzZpCdYcay(url)
			return
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('pagination(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		gIrQwuNX0S4GL9TcmxEvjFet8hf = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)">(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in gIrQwuNX0S4GL9TcmxEvjFet8hf:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.replace('&amp;','&')
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,133)
	return
def dlropqS0vO9K7W4z(url):
	if '/news/' in url or '/episode/' in url:
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,url,'','',True,'ALKAWTHAR-PLAY-1st')
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("mobilevideopath.*?value='(.*?)'",M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if items: url = items[0]
	pSAuLjYqhgc9brWFKs7Pa4J(url,r1NChsk39OMvT82YemDQnl5,'video')
	return
def EvpYWVrnUQA():
	url = tle5V6jgvRfE+'/live'
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,url,'','',True,'ALKAWTHAR-LIVE-1st')
	M08MPGgsh4n5rKe = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('live-container.*?src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	M08MPGgsh4n5rKe = M08MPGgsh4n5rKe[0]
	TC7fWv2a1gLJGiAtN8 = {'Referer':tle5V6jgvRfE}
	WcPEG7nehsCwig809NyHMZ = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,'GET',M08MPGgsh4n5rKe,'',TC7fWv2a1gLJGiAtN8,'',True,'ALKAWTHAR-LIVE-2nd')
	flARjI3NM9CQnWY1xk7 = WcPEG7nehsCwig809NyHMZ.content
	wr9ZDoyjmK5gxci083G = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('csrf-token" content="(.*?)"',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	wr9ZDoyjmK5gxci083G = wr9ZDoyjmK5gxci083G[0]
	Y3oDiWN9eR = SLMTm6RQ34ic7v5s9rBG(M08MPGgsh4n5rKe,'url')
	TW6JIBgC971tjOE = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("playUrl = '(.*?)'",flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	TW6JIBgC971tjOE = Y3oDiWN9eR+TW6JIBgC971tjOE[0]
	RRt4TH2wLFbY = {'X-CSRF-TOKEN':wr9ZDoyjmK5gxci083G}
	CqivWrSdG8cOo2DtkgV01 = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,'POST',TW6JIBgC971tjOE,'',RRt4TH2wLFbY,False,True,'ALKAWTHAR-LIVE-3rd')
	JS5g7NP38QO26ho = CqivWrSdG8cOo2DtkgV01.content
	FF976NUWy3wVxBvP = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"(.*?)"',JS5g7NP38QO26ho,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	FF976NUWy3wVxBvP = FF976NUWy3wVxBvP[0].replace('\/','/')
	pSAuLjYqhgc9brWFKs7Pa4J(FF976NUWy3wVxBvP,r1NChsk39OMvT82YemDQnl5,'live')
	return
def Xwa7vgzTeb3Zy(search,url=''):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if url=='':
		if search=='': search = UIf35nZEj1wylmq()
		if search=='': return
		search = TaEr2nR3f5e8oXzpy(search)
		url = tle5V6jgvRfE+'/search?q='+search
		btd6ag2XYUkHixqy5J7o9RfLu1MScm(url,'')
		return
# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'EGYBESTVIP'
Yc0eBRLpbCkm4gK7OqyzuHwU = '_EGV_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
def HgQCVwFx2Br(mode,url,tsMKaFVh1ZN2BIXEcvTejxR5DP,text):
	if   mode==220: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==221: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url,tsMKaFVh1ZN2BIXEcvTejxR5DP)
	elif mode==222: s4Bng5iAZQSTtpDw9 = AJDL0Mp13fQkRH5c(url)
	elif mode==223: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==224: s4Bng5iAZQSTtpDw9 = L1FsQxw6Afb7pcCe9Tr3qizXZ(url)
	elif mode==229: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',229,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',tle5V6jgvRfE,'','','','','EGYBEST-MENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="i i-home"(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)"(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,222)
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="ba(.*?)<script',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,221)
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			if 'html' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: continue
			if not ZCimQhV5lovgspAYzHq1Ef27u8ja4R.endswith('/'): tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,221)
	return M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
def AJDL0Mp13fQkRH5c(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',url,'','','','','EGYBESTVIP-SUBMENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="rs_scroll"(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?</i>(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,224)
	return
def L1FsQxw6Afb7pcCe9Tr3qizXZ(url):
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع',url,221)
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,url,'','','','EGYBESTVIP-FILTERS_MENU-1st')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="sub_nav(.*?)id="movies',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".+?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			if ZCimQhV5lovgspAYzHq1Ef27u8ja4R=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,221)
	else: uyt3pAHZk4(url)
	return
def uyt3pAHZk4(url,tsMKaFVh1ZN2BIXEcvTejxR5DP='1'):
	if tsMKaFVh1ZN2BIXEcvTejxR5DP=='': tsMKaFVh1ZN2BIXEcvTejxR5DP = '1'
	if '/search' in url or '?' in url: M08MPGgsh4n5rKe = url + '&'
	else: M08MPGgsh4n5rKe = url + '?'
	M08MPGgsh4n5rKe = M08MPGgsh4n5rKe + 'page=' + tsMKaFVh1ZN2BIXEcvTejxR5DP
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,M08MPGgsh4n5rKe,'','','','EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		TIkiozSLCv6werb97mHQ0q4y3=E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="pda"(.*?)div',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[-1]
	elif '/series/' in url:
		TIkiozSLCv6werb97mHQ0q4y3=E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="owl-carousel owl-carousel(.*?)div',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	else:
		TIkiozSLCv6werb97mHQ0q4y3=E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('id="movies(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[-1]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title in items:
		title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
		if '/movie/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R or '/episode' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R.rstrip('/'),223,Q2qmuDRrC9ikcaJK7gtUHXNW)
		else:
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,221,Q2qmuDRrC9ikcaJK7gtUHXNW)
	if len(items)>=16:
		O4ubVEql0PNCMWtf1XoUS = ['/movies','/tv','/search','/trending']
		tsMKaFVh1ZN2BIXEcvTejxR5DP = int(tsMKaFVh1ZN2BIXEcvTejxR5DP)
		if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in url for hht0cpXxWw2OzFS1jnUGebkJLBd85 in O4ubVEql0PNCMWtf1XoUS):
			for x2xJmiZAjKblaSWhsFre6yg5kVO in range(0,1000,100):
				if int(tsMKaFVh1ZN2BIXEcvTejxR5DP/100)*100==x2xJmiZAjKblaSWhsFre6yg5kVO:
					for AudBQkLFsrHKicIogThZyv in range(x2xJmiZAjKblaSWhsFre6yg5kVO,x2xJmiZAjKblaSWhsFre6yg5kVO+100,10):
						if int(tsMKaFVh1ZN2BIXEcvTejxR5DP/10)*10==AudBQkLFsrHKicIogThZyv:
							for Jaw7m25SqebdnZrKAOi8QGTy in range(AudBQkLFsrHKicIogThZyv,AudBQkLFsrHKicIogThZyv+10,1):
								if not tsMKaFVh1ZN2BIXEcvTejxR5DP==Jaw7m25SqebdnZrKAOi8QGTy and Jaw7m25SqebdnZrKAOi8QGTy!=0:
									tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+str(Jaw7m25SqebdnZrKAOi8QGTy),url,221,'',str(Jaw7m25SqebdnZrKAOi8QGTy))
						elif AudBQkLFsrHKicIogThZyv!=0: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+str(AudBQkLFsrHKicIogThZyv),url,221,'',str(AudBQkLFsrHKicIogThZyv))
						else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+str(1),url,221,'',str(1))
				elif x2xJmiZAjKblaSWhsFre6yg5kVO!=0: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+str(x2xJmiZAjKblaSWhsFre6yg5kVO),url,221,'',str(x2xJmiZAjKblaSWhsFre6yg5kVO))
				else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+str(1),url,221)
	return
def dlropqS0vO9K7W4z(url):
	da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = [],[]
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,url,'','','','EGYBESTVIP-PLAY-1st')
	VnK1wPrcHoN8ex2Bl0pLS = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<td>التصنيف</td>.*?">(.*?)<',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if VnK1wPrcHoN8ex2Bl0pLS and Y1Yz6bZMLDaGjpxK3fSXm7TurCnHwo(r1NChsk39OMvT82YemDQnl5,url,VnK1wPrcHoN8ex2Bl0pLS): return
	ff5ARFBW6NpbUkhgLyYa9mC3lu,xxeLpucQImd6E1bK0kPFtgR2f5sWN = '',''
	Eb9l6hdcu03f4jo8Y1q,CnDskbEecO5U3j6L1RS9mxQ = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
	ii2HD5AgoChPt6alUdIRscGjvYq = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('show_dl api" href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if ii2HD5AgoChPt6alUdIRscGjvYq:
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R in ii2HD5AgoChPt6alUdIRscGjvYq:
			if '/watch/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ff5ARFBW6NpbUkhgLyYa9mC3lu = ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			elif '/download/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: xxeLpucQImd6E1bK0kPFtgR2f5sWN = ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		if ff5ARFBW6NpbUkhgLyYa9mC3lu!='': Eb9l6hdcu03f4jo8Y1q = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,ff5ARFBW6NpbUkhgLyYa9mC3lu,'','','','EGYBESTVIP-PLAY-2nd')
		if xxeLpucQImd6E1bK0kPFtgR2f5sWN!='': CnDskbEecO5U3j6L1RS9mxQ = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,xxeLpucQImd6E1bK0kPFtgR2f5sWN,'','','','EGYBESTVIP-PLAY-3rd')
	ydj0EAvFOeinxhPsW7 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('id="video".*?data-src="(.*?)"',Eb9l6hdcu03f4jo8Y1q,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if ydj0EAvFOeinxhPsW7:
		M08MPGgsh4n5rKe = ydj0EAvFOeinxhPsW7[0]
		if M08MPGgsh4n5rKe!='' and 'uploaded.egybest.download' in M08MPGgsh4n5rKe and '/?id=_' not in M08MPGgsh4n5rKe:
			flARjI3NM9CQnWY1xk7 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,M08MPGgsh4n5rKe,'','','','EGYBESTVIP-PLAY-4th')
			iQFMwu7NW53PxIsnAqacv = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('source src="(.*?)" title="(.*?)"',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if iQFMwu7NW53PxIsnAqacv:
				for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,LjG8y1rb9AgJF2I3i64ZDtCXMa7n in iQFMwu7NW53PxIsnAqacv:
					jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named=ed.egybest.do__watch__mp4__'+LjG8y1rb9AgJF2I3i64ZDtCXMa7n)
			else:
				vMSQsdJ0gCrh7ztnR96yDXqOYaj = M08MPGgsh4n5rKe.split('/')[2]
				jVMHRouKgQFAESmd7B8ObTYy.append(M08MPGgsh4n5rKe+'?named='+vMSQsdJ0gCrh7ztnR96yDXqOYaj+'__watch')
		elif M08MPGgsh4n5rKe!='':
			vMSQsdJ0gCrh7ztnR96yDXqOYaj = M08MPGgsh4n5rKe.split('/')[2]
			jVMHRouKgQFAESmd7B8ObTYy.append(M08MPGgsh4n5rKe+'?named='+vMSQsdJ0gCrh7ztnR96yDXqOYaj+'__watch')
	WOwM8TPCbGdESY27a = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<table class="dls_table(.*?)</table>',CnDskbEecO5U3j6L1RS9mxQ,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if WOwM8TPCbGdESY27a:
		WOwM8TPCbGdESY27a = WOwM8TPCbGdESY27a[0]
		qsRmryI3zx42UGneVbNWgHEAO = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',WOwM8TPCbGdESY27a,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if qsRmryI3zx42UGneVbNWgHEAO:
			for LjG8y1rb9AgJF2I3i64ZDtCXMa7n,ZCimQhV5lovgspAYzHq1Ef27u8ja4R in qsRmryI3zx42UGneVbNWgHEAO:
				if 'myegyvip' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: continue
				if ZCimQhV5lovgspAYzHq1Ef27u8ja4R.count('/')>=2:
					vMSQsdJ0gCrh7ztnR96yDXqOYaj = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('/')[2]
					jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+vMSQsdJ0gCrh7ztnR96yDXqOYaj+'__download__mp4__'+LjG8y1rb9AgJF2I3i64ZDtCXMa7n)
	S85FOrQ2sZNmT = []
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R in jVMHRouKgQFAESmd7B8ObTYy:
		S85FOrQ2sZNmT.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	import JYR902sfml
	JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt(S85FOrQ2sZNmT,r1NChsk39OMvT82YemDQnl5,'video',url)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if search=='': search = UIf35nZEj1wylmq()
	if search=='': return
	DbEfLQSBFCTt2mMqvrsIVnjJ6 = search.replace(' ','+')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(jEPuRTVbZg4MCimJxzf3I6wFa,tle5V6jgvRfE,'','','','EGYBESTVIP-SEARCH-1st')
	wr9ZDoyjmK5gxci083G = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('name="_token" value="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if wr9ZDoyjmK5gxci083G:
		url = tle5V6jgvRfE+'/search?_token='+wr9ZDoyjmK5gxci083G[0]+'&q='+DbEfLQSBFCTt2mMqvrsIVnjJ6
		uyt3pAHZk4(url)
	return
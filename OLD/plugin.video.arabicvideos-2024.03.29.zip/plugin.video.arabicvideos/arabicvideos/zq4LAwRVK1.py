# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'CIMA4U'
headers = {'User-Agent':''}
Yc0eBRLpbCkm4gK7OqyzuHwU = '_C4U_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
ZLKHfqMEUdRupD = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def HgQCVwFx2Br(mode,url,text):
	if   mode==420: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==421: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url,text)
	elif mode==422: s4Bng5iAZQSTtpDw9 = PPrel9jScTR0ONpCwHb3vkfFsA(url)
	elif mode==423: s4Bng5iAZQSTtpDw9 = btd6ag2XYUkHixqy5J7o9RfLu1MScm(url)
	elif mode==424: s4Bng5iAZQSTtpDw9 = L1FsQxw6Afb7pcCe9Tr3qizXZ(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: s4Bng5iAZQSTtpDw9 = L1FsQxw6Afb7pcCe9Tr3qizXZ(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==427: s4Bng5iAZQSTtpDw9 = tYF4DlHR6rqVmb2i8Px5B(url)
	elif mode==429: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',tle5V6jgvRfE,'','','','','CIMA4U-MENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	dkgwyUKEpTtPeMxs68aib = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	dkgwyUKEpTtPeMxs68aib = dkgwyUKEpTtPeMxs68aib[0].strip('/')
	dkgwyUKEpTtPeMxs68aib = SLMTm6RQ34ic7v5s9rBG(dkgwyUKEpTtPeMxs68aib,'url')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',429,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فلتر محدد',dkgwyUKEpTtPeMxs68aib,425)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فلتر كامل',dkgwyUKEpTtPeMxs68aib,424)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'الرئيسية',dkgwyUKEpTtPeMxs68aib,421)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('NavigationMenu(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="*(.*?)"*>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		if title in ZLKHfqMEUdRupD: continue
		if '/actors' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: title = 'أفلام النجوم'
		elif '/netflix' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: title = 'أفلام ومسلسلات نيتفلكس'
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,421)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'قائمة تفصيلية',dkgwyUKEpTtPeMxs68aib,427)
	return
def tYF4DlHR6rqVmb2i8Px5B(website=''):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',tle5V6jgvRfE,'','','','','CIMA4U-MENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('FilteringTitle(.*?)PageTitle',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo,id,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		if title in ZLKHfqMEUdRupD: continue
		if 'netflix-movies' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: title = 'مسلسلات نيتفلكس'
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,421,'','',cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo+'|'+id)
	return
def uyt3pAHZk4(url,S7Ra6OGtw1gBkDhrPsozc5Ku=''):
	if '/HomepageLoader/' in url: url = url.strip('/')+'/mpaa/family/'
	items = []
	dkgwyUKEpTtPeMxs68aib = SLMTm6RQ34ic7v5s9rBG(url,'url')
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'',headers,'','','CIMA4U-TITLES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	if not S7Ra6OGtw1gBkDhrPsozc5Ku or '|' in S7Ra6OGtw1gBkDhrPsozc5Ku:
		if '|' not in S7Ra6OGtw1gBkDhrPsozc5Ku: U1OfPCrTtj7IMeuQ9RE = ''
		else: U1OfPCrTtj7IMeuQ9RE = '/archive/'+S7Ra6OGtw1gBkDhrPsozc5Ku
		ZDu46maUtgrHn7Pcj = False
		if 'PinSlider' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2:
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'المميزة',url,421,'','','featured')
			ZDu46maUtgrHn7Pcj = True
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('PageTitle(.*?)PageContent',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3:
			f9AzGuXj0qgcNTy1 = TIkiozSLCv6werb97mHQ0q4y3[0]
			HKE5ebjfkuy = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-tab="(.*?)".*?<span>(.*?)<',f9AzGuXj0qgcNTy1,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for wQIH8p40J52OaeATBm,neZQycYAFqxLzkPhEWvM in HKE5ebjfkuy:
				VktWBN6gn8zSUpesvfCyia2Ajm = dkgwyUKEpTtPeMxs68aib+'/ajaxcenter/action/HomepageLoader/tab/'+wQIH8p40J52OaeATBm+U1OfPCrTtj7IMeuQ9RE+'/'
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+neZQycYAFqxLzkPhEWvM,VktWBN6gn8zSUpesvfCyia2Ajm,421)
				ZDu46maUtgrHn7Pcj = True
		if ZDu46maUtgrHn7Pcj: tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	if S7Ra6OGtw1gBkDhrPsozc5Ku=='featured':
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('PinSlider(.*?)MultiFilter',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if not TIkiozSLCv6werb97mHQ0q4y3: TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('PinSlider(.*?)PageTitle',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3: ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		else: ziJLDVT8NM2QcgIpmE9A = ''
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		ziJLDVT8NM2QcgIpmE9A = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
	elif '/filter/' in url:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('PageContent(.*?)class="*pagination"*',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	elif '/actors' in url:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('PageContent(.*?)class="*pagination"*',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	else:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('Cima4uBlocks(.*?)</li></ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3: ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		else: ziJLDVT8NM2QcgIpmE9A = ''
	if not items: items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not items: items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	jjR8ftoEXpPxVF6JerbHZuzv7ic = []
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title in items:
		if not title: continue
		if '?news=' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: continue
		title = title.replace('مشاهدة ','')
		title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
		EQw62xjXSJmzrRt = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(.*?) حلقة \d+',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if EQw62xjXSJmzrRt and 'حلقة' in title:
			title = '_MOD_' + EQw62xjXSJmzrRt[0]
			if title not in jjR8ftoEXpPxVF6JerbHZuzv7ic:
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,422,Q2qmuDRrC9ikcaJK7gtUHXNW)
				jjR8ftoEXpPxVF6JerbHZuzv7ic.append(title)
		elif '/actor/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,421,Q2qmuDRrC9ikcaJK7gtUHXNW)
		else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,422,Q2qmuDRrC9ikcaJK7gtUHXNW)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('pagination(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3 and S7Ra6OGtw1gBkDhrPsozc5Ku!='featured':
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
			title = title.replace('الصفحة ','')
			if title!='': tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,421)
	rrpPgGwmLCnJeEDdXs0NlfUb9R5 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('</li><a href="(.*?)".*?>(.*?)<',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if rrpPgGwmLCnJeEDdXs0NlfUb9R5:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title = rrpPgGwmLCnJeEDdXs0NlfUb9R5[0]
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,421)
	return
def PPrel9jScTR0ONpCwHb3vkfFsA(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','CIMA4U-SEASONS-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="WatchNow".*?href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		url = TIkiozSLCv6werb97mHQ0q4y3[0]
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','CIMA4U-SEASONS-2nd')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('SeasonsSections(.*?)</div></div></div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if '/tag/' in url or '/actor' in url:
		uyt3pAHZk4(url)
	elif TIkiozSLCv6werb97mHQ0q4y3:
		Q2qmuDRrC9ikcaJK7gtUHXNW = oos8ymFi9CN2z1jXcR.getInfoLabel('ListItem.Thumb')
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("href='(.*?)'>(.*?)<",ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		fWD23ekIACvQaMyVrTlihBwNbHPG = ['مسلسل','موسم','برنامج','حلقة']
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title for hht0cpXxWw2OzFS1jnUGebkJLBd85 in fWD23ekIACvQaMyVrTlihBwNbHPG):
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,423,Q2qmuDRrC9ikcaJK7gtUHXNW)
			else: tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,426,Q2qmuDRrC9ikcaJK7gtUHXNW)
	else: btd6ag2XYUkHixqy5J7o9RfLu1MScm(url)
	return
def btd6ag2XYUkHixqy5J7o9RfLu1MScm(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','CIMA4U-EPISODES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	Q2qmuDRrC9ikcaJK7gtUHXNW = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"background-image:url\((.*?)\)',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if Q2qmuDRrC9ikcaJK7gtUHXNW: Q2qmuDRrC9ikcaJK7gtUHXNW = Q2qmuDRrC9ikcaJK7gtUHXNW[0]
	else: Q2qmuDRrC9ikcaJK7gtUHXNW = ''
	X2log1R5aufxyPQJTCwGq8Wb = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('EpisodesSection(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if X2log1R5aufxyPQJTCwGq8Wb:
		ziJLDVT8NM2QcgIpmE9A = X2log1R5aufxyPQJTCwGq8Wb[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,EQw62xjXSJmzrRt in items:
			title = title+' '+EQw62xjXSJmzrRt
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,426,Q2qmuDRrC9ikcaJK7gtUHXNW)
	else: tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+'رابط التشغيل',url,426,Q2qmuDRrC9ikcaJK7gtUHXNW)
	return
def dlropqS0vO9K7W4z(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'',headers,'','','CIMA4U-PLAY-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	w8EieuN1qK4QMYHtWyd7Pha = aQniqUlZk8.url
	if vciEXHThAPto76QIR2pK: w8EieuN1qK4QMYHtWyd7Pha = w8EieuN1qK4QMYHtWyd7Pha.encode('utf8')
	dkgwyUKEpTtPeMxs68aib = SLMTm6RQ34ic7v5s9rBG(w8EieuN1qK4QMYHtWyd7Pha,'url')
	jVMHRouKgQFAESmd7B8ObTYy = []
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('WatchSection(.*?)</div></div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-link="(.*?)".*? />(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for YusKpP58ZyhOD,title in items:
			title = title.strip(' ')
			if 'myvid' in title.lower(): title = 'خاص '+title
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = dkgwyUKEpTtPeMxs68aib+'/structure/server.php?id='+YusKpP58ZyhOD+'?named='+title+'__watch'
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.replace('\r','')
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('DownloadServers(.*?)</div></div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*? />(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			title = title.strip(' ')
			if 'myvid' in title.lower(): neZQycYAFqxLzkPhEWvM = '__خاص'
			else: neZQycYAFqxLzkPhEWvM = ''
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+title+'__download'+neZQycYAFqxLzkPhEWvM
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.replace('\r','')
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	import JYR902sfml
	JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt(jVMHRouKgQFAESmd7B8ObTYy,r1NChsk39OMvT82YemDQnl5,'video',url)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if search=='': search = UIf35nZEj1wylmq()
	if search=='': return
	search = search.replace(' ','+')
	url = tle5V6jgvRfE+'/Search?q='+search
	uyt3pAHZk4(url,'search')
	return
def UdqXh8aClcxJAEVSFKy9PnjuGW(url):
	if 'smartemadfilter' not in url: url = SLMTm6RQ34ic7v5s9rBG(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','CIMA4U-GET_FILTERS_BLOCKS-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('MultiFilter(.*?)PageTitle',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	H8n4oVq07uvJjCOwgzbyf6XR9Fs = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	return H8n4oVq07uvJjCOwgzbyf6XR9Fs
def HOgJ4cadx6GAE(ziJLDVT8NM2QcgIpmE9A):
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-id="(.*?)".*?</div>(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	return items
def VUJ0sTjSZ36wgnRh2bWzK(url):
	bBac0ZnqRLiYT6x93vJyFjQ = url.split('/smartemadfilter?')[0]
	kFlE9TNexjg76 = SLMTm6RQ34ic7v5s9rBG(url,'url')
	url = url.replace(bBac0ZnqRLiYT6x93vJyFjQ,kFlE9TNexjg76)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=','/').replace('&','/')
	url = url+'/'
	return url
tpH7FYXLyz4UJdcC31OQ0Phwg = ['category','types','release-year']
bxa9Gj5p3oElwmngHJRKP7CtqS = ['Quality','release-year','types','category']
def L1FsQxw6Afb7pcCe9Tr3qizXZ(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': ydL2RstfT9BA3Hpe1SZIq,l3Uo4ThenPyJMua = '',''
	else: ydL2RstfT9BA3Hpe1SZIq,l3Uo4ThenPyJMua = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global tpH7FYXLyz4UJdcC31OQ0Phwg
			tpH7FYXLyz4UJdcC31OQ0Phwg = tpH7FYXLyz4UJdcC31OQ0Phwg[1:]
		if tpH7FYXLyz4UJdcC31OQ0Phwg[0]+'=' not in ydL2RstfT9BA3Hpe1SZIq: cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = tpH7FYXLyz4UJdcC31OQ0Phwg[0]
		for AudBQkLFsrHKicIogThZyv in range(len(tpH7FYXLyz4UJdcC31OQ0Phwg[0:-1])):
			if tpH7FYXLyz4UJdcC31OQ0Phwg[AudBQkLFsrHKicIogThZyv]+'=' in ydL2RstfT9BA3Hpe1SZIq: cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = tpH7FYXLyz4UJdcC31OQ0Phwg[AudBQkLFsrHKicIogThZyv+1]
		rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&'+cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo+'=0'
		SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&'+cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo+'=0'
		hOSk91jGqtHsfwU2ExCV4YB = rrsgSnC5AFkbEvDPm6pyaRizM8.strip('&')+'___'+SWxX6Q3CgwV7F.strip('&')
		Rdgr0aTSzE5chex9W = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(l3Uo4ThenPyJMua,'modified_filters')
		M08MPGgsh4n5rKe = url+'/smartemadfilter?'+Rdgr0aTSzE5chex9W
	elif type=='ALL_ITEMS_FILTER':
		jyRzHeOYXAW4oDrUS = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(ydL2RstfT9BA3Hpe1SZIq,'modified_values')
		jyRzHeOYXAW4oDrUS = BUTSkzgFC7(jyRzHeOYXAW4oDrUS)
		if l3Uo4ThenPyJMua!='': l3Uo4ThenPyJMua = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(l3Uo4ThenPyJMua,'modified_filters')
		if l3Uo4ThenPyJMua=='': M08MPGgsh4n5rKe = url
		else: M08MPGgsh4n5rKe = url+'/smartemadfilter?'+l3Uo4ThenPyJMua
		M08MPGgsh4n5rKe = VUJ0sTjSZ36wgnRh2bWzK(M08MPGgsh4n5rKe)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'أظهار قائمة الفيديو التي تم اختيارها ',M08MPGgsh4n5rKe,421,'','','filter')
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+' [[   '+jyRzHeOYXAW4oDrUS+'   ]]',M08MPGgsh4n5rKe,421,'','','filter')
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	H8n4oVq07uvJjCOwgzbyf6XR9Fs = UdqXh8aClcxJAEVSFKy9PnjuGW(url)
	dict = {}
	for name,ziJLDVT8NM2QcgIpmE9A,eFmOUji0173K in H8n4oVq07uvJjCOwgzbyf6XR9Fs:
		if '/category/' in url and eFmOUji0173K=='category': continue
		name = name.replace('--','')
		items = HOgJ4cadx6GAE(ziJLDVT8NM2QcgIpmE9A)
		if '=' not in M08MPGgsh4n5rKe: M08MPGgsh4n5rKe = url
		if type=='SPECIFIED_FILTER':
			if cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo!=eFmOUji0173K: continue
			elif len(items)<2:
				if eFmOUji0173K==tpH7FYXLyz4UJdcC31OQ0Phwg[-1]:
					url = VUJ0sTjSZ36wgnRh2bWzK(url)
					uyt3pAHZk4(url)
				else: L1FsQxw6Afb7pcCe9Tr3qizXZ(M08MPGgsh4n5rKe,'SPECIFIED_FILTER___'+hOSk91jGqtHsfwU2ExCV4YB)
				return
			else:
				M08MPGgsh4n5rKe = VUJ0sTjSZ36wgnRh2bWzK(M08MPGgsh4n5rKe)
				if eFmOUji0173K==tpH7FYXLyz4UJdcC31OQ0Phwg[-1]: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع',M08MPGgsh4n5rKe,421,'','','filter')
				else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع',M08MPGgsh4n5rKe,425,'','',hOSk91jGqtHsfwU2ExCV4YB)
		elif type=='ALL_ITEMS_FILTER':
			rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&'+eFmOUji0173K+'=0'
			SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&'+eFmOUji0173K+'=0'
			hOSk91jGqtHsfwU2ExCV4YB = rrsgSnC5AFkbEvDPm6pyaRizM8+'___'+SWxX6Q3CgwV7F
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع :'+name,M08MPGgsh4n5rKe,424,'','',hOSk91jGqtHsfwU2ExCV4YB)
		dict[eFmOUji0173K] = {}
		for hht0cpXxWw2OzFS1jnUGebkJLBd85,e0i4nPhusqdTaG in items:
			if hht0cpXxWw2OzFS1jnUGebkJLBd85=='196533': e0i4nPhusqdTaG = 'أفلام نيتفلكس'
			elif hht0cpXxWw2OzFS1jnUGebkJLBd85=='196531': e0i4nPhusqdTaG = 'مسلسلات نيتفلكس'
			if e0i4nPhusqdTaG in ZLKHfqMEUdRupD: continue
			dict[eFmOUji0173K][hht0cpXxWw2OzFS1jnUGebkJLBd85] = e0i4nPhusqdTaG
			rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&'+eFmOUji0173K+'='+e0i4nPhusqdTaG
			SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&'+eFmOUji0173K+'='+hht0cpXxWw2OzFS1jnUGebkJLBd85
			RtPpz8FAEjIxU = rrsgSnC5AFkbEvDPm6pyaRizM8+'___'+SWxX6Q3CgwV7F
			title = e0i4nPhusqdTaG+' :'#+dict[eFmOUji0173K]['0']
			title = e0i4nPhusqdTaG+' :'+name
			if type=='ALL_ITEMS_FILTER': tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,424,'','',RtPpz8FAEjIxU)
			elif type=='SPECIFIED_FILTER' and tpH7FYXLyz4UJdcC31OQ0Phwg[-2]+'=' in ydL2RstfT9BA3Hpe1SZIq:
				Rdgr0aTSzE5chex9W = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(SWxX6Q3CgwV7F,'modified_filters')
				TW6JIBgC971tjOE = url+'/smartemadfilter?'+Rdgr0aTSzE5chex9W
				TW6JIBgC971tjOE = VUJ0sTjSZ36wgnRh2bWzK(TW6JIBgC971tjOE)
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,TW6JIBgC971tjOE,421,'','','filter')
			else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,425,'','',RtPpz8FAEjIxU)
	return
def l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(dY1a0xA6PKm7TOJSERt3sHU9Qp,mode):
	dY1a0xA6PKm7TOJSERt3sHU9Qp = dY1a0xA6PKm7TOJSERt3sHU9Qp.replace('=&','=0&')
	dY1a0xA6PKm7TOJSERt3sHU9Qp = dY1a0xA6PKm7TOJSERt3sHU9Qp.strip('&')
	nvNkgT7iGQOyed = {}
	if '=' in dY1a0xA6PKm7TOJSERt3sHU9Qp:
		items = dY1a0xA6PKm7TOJSERt3sHU9Qp.split('&')
		for hh4gUqS5JWf1saRZPXHD in items:
			DHcrLNnqExKjM8uvVlBhWd,hht0cpXxWw2OzFS1jnUGebkJLBd85 = hh4gUqS5JWf1saRZPXHD.split('=')
			nvNkgT7iGQOyed[DHcrLNnqExKjM8uvVlBhWd] = hht0cpXxWw2OzFS1jnUGebkJLBd85
	UJzegYmlGML35rasDAIx17Rhnk = ''
	for key in bxa9Gj5p3oElwmngHJRKP7CtqS:
		if key in list(nvNkgT7iGQOyed.keys()): hht0cpXxWw2OzFS1jnUGebkJLBd85 = nvNkgT7iGQOyed[key]
		else: hht0cpXxWw2OzFS1jnUGebkJLBd85 = '0'
		if '%' not in hht0cpXxWw2OzFS1jnUGebkJLBd85: hht0cpXxWw2OzFS1jnUGebkJLBd85 = TaEr2nR3f5e8oXzpy(hht0cpXxWw2OzFS1jnUGebkJLBd85)
		if mode=='modified_values' and hht0cpXxWw2OzFS1jnUGebkJLBd85!='0': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+' + '+hht0cpXxWw2OzFS1jnUGebkJLBd85
		elif mode=='modified_filters' and hht0cpXxWw2OzFS1jnUGebkJLBd85!='0': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+'&'+key+'='+hht0cpXxWw2OzFS1jnUGebkJLBd85
		elif mode=='all': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+'&'+key+'='+hht0cpXxWw2OzFS1jnUGebkJLBd85
	UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk.strip(' + ')
	UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk.strip('&')
	UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk.replace('=0','=')
	return UJzegYmlGML35rasDAIx17Rhnk
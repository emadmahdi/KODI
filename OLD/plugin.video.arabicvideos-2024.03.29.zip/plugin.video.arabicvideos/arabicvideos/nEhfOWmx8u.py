# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'ARBLIONZ'
headers = { 'User-Agent' : '' }
Yc0eBRLpbCkm4gK7OqyzuHwU = '_ARL_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
ZLKHfqMEUdRupD = ['عروض المصارعة','الكل','الرئيسية','العاب','برامج كمبيوتر','موبايل و جوال','القسم الاسلامي']
def HgQCVwFx2Br(mode,url,text):
	if   mode==200: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==201: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url)
	elif mode==202: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==203: s4Bng5iAZQSTtpDw9 = btd6ag2XYUkHixqy5J7o9RfLu1MScm(url)
	elif mode==204: s4Bng5iAZQSTtpDw9 = L1FsQxw6Afb7pcCe9Tr3qizXZ(url,'FILTERS___'+text)
	elif mode==205: s4Bng5iAZQSTtpDw9 = L1FsQxw6Afb7pcCe9Tr3qizXZ(url,'CATEGORIES___'+text)
	elif mode==209: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',209,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فلتر محدد',tle5V6jgvRfE,205)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فلتر كامل',tle5V6jgvRfE,204)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'مميزة',tle5V6jgvRfE+'??trending',201)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'أفلام مميزة',tle5V6jgvRfE+'??trending_movies',201)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'مسلسلات مميزة',tle5V6jgvRfE+'??trending_series',201)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'الصفحة الرئيسية',tle5V6jgvRfE+'??mainpage',201)
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',tle5V6jgvRfE,'',headers,True,'','ARBLIONZ-MENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('categories-tabs(.*?)MainRow',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-get="(.*?)".*?<h3>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for filter,title in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/ajax/home/more?filter='+filter
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,201)
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('navigation-menu(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		title = title.strip(' ')
		if not any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title for hht0cpXxWw2OzFS1jnUGebkJLBd85 in ZLKHfqMEUdRupD):
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,201)
	return M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
def uyt3pAHZk4(url):
	if '??' in url: url,type = url.split('??')
	else: type = ''
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'',headers,True,'','ARBLIONZ-TITLES-2nd')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content.encode('utf8')
	if 'getposts' in url: TIkiozSLCv6werb97mHQ0q4y3 = [M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2]
	elif type=='trending':
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('MasterSlider(.*?)</div>\n *</div>\n *</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	elif type=='trending_movies':
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('Slider_1(.*?)</div>.</div>.</div>.</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	elif type=='trending_series':
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('Slider_2(.*?)</div>.</div>.</div>.</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	elif type=='111mainpage':
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="container page-content"(.*?)class="tabs"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	else:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('page-content(.*?)main-footer',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not TIkiozSLCv6werb97mHQ0q4y3: return
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	cFEX1lI9Wg2 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('content-box".*?src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not items:
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('SliderItem".*?href="(.*?)".*?image: url\((.*?)\).*?<h2>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		cc0O1M4e5jtfoq,PojQU9ySuCMbW,GReTJrIxo2dzbapy = zip(*items)
		items = zip(PojQU9ySuCMbW,cc0O1M4e5jtfoq,GReTJrIxo2dzbapy)
	jjR8ftoEXpPxVF6JerbHZuzv7ic = []
	for Q2qmuDRrC9ikcaJK7gtUHXNW,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		if '/series/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: continue
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.strip('/')
		title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
		title = title.strip(' ')
		if '/film/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R or any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title for hht0cpXxWw2OzFS1jnUGebkJLBd85 in cFEX1lI9Wg2):
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,202,Q2qmuDRrC9ikcaJK7gtUHXNW)
		elif '/episode/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R and 'الحلقة' in title:
			EQw62xjXSJmzrRt = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(.*?) الحلقة \d+',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if EQw62xjXSJmzrRt:
				title = '_MOD_' + EQw62xjXSJmzrRt[0]
				if title not in jjR8ftoEXpPxVF6JerbHZuzv7ic:
					tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,203,Q2qmuDRrC9ikcaJK7gtUHXNW)
					jjR8ftoEXpPxVF6JerbHZuzv7ic.append(title)
		elif '/pack/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'/films',201,Q2qmuDRrC9ikcaJK7gtUHXNW)
		else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,203,Q2qmuDRrC9ikcaJK7gtUHXNW)
	if type in ['','mainpage']:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="pagination(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3:
			ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href=["\'](http.*?)["\'].*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = nnGHa80rMphqe1ukFtIRvAPs6W(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
				title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
				title = title.replace('الصفحة ','')
				if 'search?s=' in url:
					VBXGfJEctQxd85KFSTOy4 = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('page=')[1]
					FXikAZgdlsLDJrUVw6ItqyH1C4S = url.split('page=')[1]
					ZCimQhV5lovgspAYzHq1Ef27u8ja4R = url.replace('page='+FXikAZgdlsLDJrUVw6ItqyH1C4S,'page='+VBXGfJEctQxd85KFSTOy4)
				if title!='': tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,201)
	return
def btd6ag2XYUkHixqy5J7o9RfLu1MScm(url):
	zfwcXQbhNaBT8,items,gzjIKdLQR8Gu = -1,[],[]
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'',headers,True,'','ARBLIONZ-EPISODES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content.encode('utf8')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('ti-list-numbered(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		gzjIKdLQR8Gu = []
		cz4e6sNTj53E09xtaArJLKDg = ''.join(TIkiozSLCv6werb97mHQ0q4y3)
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)"',cz4e6sNTj53E09xtaArJLKDg,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	items.append(url)
	items = set(items)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.strip('/')
		title = '_MOD_' + ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('/')[-1].replace('-',' ')
		mbGei9dIvrTohtJ = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('الحلقة-(\d+)',ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('/')[-1],E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if mbGei9dIvrTohtJ: mbGei9dIvrTohtJ = mbGei9dIvrTohtJ[0]
		else: mbGei9dIvrTohtJ = '0'
		gzjIKdLQR8Gu.append([ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,mbGei9dIvrTohtJ])
	items = sorted(gzjIKdLQR8Gu, reverse=False, key=lambda key: int(key[2]))
	MnpVClumZUBTXe0r2i5jcQGokw = str(items).count('/season/')
	zfwcXQbhNaBT8 = str(items).count('/episode/')
	if MnpVClumZUBTXe0r2i5jcQGokw>1 and zfwcXQbhNaBT8>0 and '/season/' not in url:
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,mbGei9dIvrTohtJ in items:
			if '/season/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,203)
	else:
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,mbGei9dIvrTohtJ in items:
			if '/season/' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
				title = BUTSkzgFC7(title)
				tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,202)
	return
def dlropqS0vO9K7W4z(url):
	jVMHRouKgQFAESmd7B8ObTYy = []
	oBzGqDUAi7KaL8vFdZtP9XIcf = url.split('/')
	Vayhmgs0IzR4P58eGJFUQvtX = tle5V6jgvRfE
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',url,'',headers,True,True,'ARBLIONZ-PLAY-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content.encode('utf8')
	id = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('postId:"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not id: id = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('post_id=(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not id: id = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('post-id="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if id: id = id[0]
	if '/watch/' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2:
		M08MPGgsh4n5rKe = url.replace(oBzGqDUAi7KaL8vFdZtP9XIcf[3],'watch')
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',M08MPGgsh4n5rKe,'',headers,True,True,'ARBLIONZ-PLAY-2nd')
		flARjI3NM9CQnWY1xk7 = aQniqUlZk8.content.encode('utf8')
		lIbvAeNOzFmgJUiMPyYqBr = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-embedd="(.*?)".*?alt="(.*?)"',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		HKE5ebjfkuy = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-embedd=".*?(http.*?)("|&quot;)',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		jomKtf9UYh7ZipIsvQMydS = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('src=&quot;(.*?)&quot;.*?>(.*?)<',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.IGNORECASE)
		YYNLohXT3J = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-embedd="(.*?)">\n*.*?server_image">\n(.*?)\n',flARjI3NM9CQnWY1xk7)
		JVTjFE7PkBL0YQqydGOe5M = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('src=&quot;(.*?)&quot;.*?alt="(.*?)"',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.IGNORECASE)
		puE0xVhWtHX = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('server="(.*?)".*?<span>(.*?)<',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.IGNORECASE)
		items = lIbvAeNOzFmgJUiMPyYqBr+HKE5ebjfkuy+jomKtf9UYh7ZipIsvQMydS+YYNLohXT3J+JVTjFE7PkBL0YQqydGOe5M+puE0xVhWtHX
		if not items:
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<span>(.*?)</span>.*?src="(.*?)"',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.IGNORECASE)
			items = [(UjqZ5K6eQu4VPy0SvhBzYsLITpH,d810OLzfxyr) for d810OLzfxyr,UjqZ5K6eQu4VPy0SvhBzYsLITpH in items]
		for vMSQsdJ0gCrh7ztnR96yDXqOYaj,title in items:
			if '.png' in vMSQsdJ0gCrh7ztnR96yDXqOYaj: continue
			if '.jpg' in vMSQsdJ0gCrh7ztnR96yDXqOYaj: continue
			if '&quot;' in vMSQsdJ0gCrh7ztnR96yDXqOYaj: continue
			LjG8y1rb9AgJF2I3i64ZDtCXMa7n = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('\d\d\d+',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if LjG8y1rb9AgJF2I3i64ZDtCXMa7n:
				LjG8y1rb9AgJF2I3i64ZDtCXMa7n = LjG8y1rb9AgJF2I3i64ZDtCXMa7n[0]
				if LjG8y1rb9AgJF2I3i64ZDtCXMa7n in title: title = title.replace(LjG8y1rb9AgJF2I3i64ZDtCXMa7n+'p','').replace(LjG8y1rb9AgJF2I3i64ZDtCXMa7n,'').strip(' ')
				LjG8y1rb9AgJF2I3i64ZDtCXMa7n = '____'+LjG8y1rb9AgJF2I3i64ZDtCXMa7n
			else: LjG8y1rb9AgJF2I3i64ZDtCXMa7n = ''
			if vMSQsdJ0gCrh7ztnR96yDXqOYaj.isdigit():
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = Vayhmgs0IzR4P58eGJFUQvtX+'/?postid='+id+'&serverid='+vMSQsdJ0gCrh7ztnR96yDXqOYaj+'?named='+title+'__watch'+LjG8y1rb9AgJF2I3i64ZDtCXMa7n
			else:
				if 'http' not in vMSQsdJ0gCrh7ztnR96yDXqOYaj: vMSQsdJ0gCrh7ztnR96yDXqOYaj = 'http:'+vMSQsdJ0gCrh7ztnR96yDXqOYaj
				LjG8y1rb9AgJF2I3i64ZDtCXMa7n = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('\d\d\d+',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
				if LjG8y1rb9AgJF2I3i64ZDtCXMa7n: LjG8y1rb9AgJF2I3i64ZDtCXMa7n = '____'+LjG8y1rb9AgJF2I3i64ZDtCXMa7n[0]
				else: LjG8y1rb9AgJF2I3i64ZDtCXMa7n = ''
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = vMSQsdJ0gCrh7ztnR96yDXqOYaj+'?named=__watch'+LjG8y1rb9AgJF2I3i64ZDtCXMa7n
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	if 'DownloadNow' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2:
		TC7fWv2a1gLJGiAtN8 = { 'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8' }
		M08MPGgsh4n5rKe = url+'/download'
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',M08MPGgsh4n5rKe,'',TC7fWv2a1gLJGiAtN8,True,'','ARBLIONZ-PLAY-3rd')
		flARjI3NM9CQnWY1xk7 = aQniqUlZk8.content.encode('utf8')
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<ul class="download-items(.*?)</ul>',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ziJLDVT8NM2QcgIpmE9A in TIkiozSLCv6werb97mHQ0q4y3:
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(http.*?)".*?<span>(.*?)<.*?<p>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,name,LjG8y1rb9AgJF2I3i64ZDtCXMa7n in items:
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+name+'__download'+'____'+LjG8y1rb9AgJF2I3i64ZDtCXMa7n
				jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	elif '/download/' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2:
		TC7fWv2a1gLJGiAtN8 = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' }
		M08MPGgsh4n5rKe = Vayhmgs0IzR4P58eGJFUQvtX + '/ajaxCenter?_action=getdownloadlinks&postId='+id
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',M08MPGgsh4n5rKe,'',TC7fWv2a1gLJGiAtN8,True,True,'ARBLIONZ-PLAY-4th')
		flARjI3NM9CQnWY1xk7 = aQniqUlZk8.content.encode('utf8')
		if 'download-btns' in flARjI3NM9CQnWY1xk7:
			jomKtf9UYh7ZipIsvQMydS = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)"',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for TW6JIBgC971tjOE in jomKtf9UYh7ZipIsvQMydS:
				if '/page/' not in TW6JIBgC971tjOE and 'http' in TW6JIBgC971tjOE:
					TW6JIBgC971tjOE = TW6JIBgC971tjOE+'?named=__download'
					jVMHRouKgQFAESmd7B8ObTYy.append(TW6JIBgC971tjOE)
				elif '/page/' in TW6JIBgC971tjOE:
					LjG8y1rb9AgJF2I3i64ZDtCXMa7n = ''
					aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',TW6JIBgC971tjOE,'',headers,True,True,'ARBLIONZ-PLAY-5th')
					aWdL2PCYx39r7E5nGg4BiHXQbmu8 = aQniqUlZk8.content.encode('utf8')
					cz4e6sNTj53E09xtaArJLKDg = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(<strong>.*?)-----',aWdL2PCYx39r7E5nGg4BiHXQbmu8,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
					for OAX4sLSpyMDq in cz4e6sNTj53E09xtaArJLKDg:
						nnsZpqc0JaulVMB = ''
						YYNLohXT3J = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<strong>(.*?)</strong>',OAX4sLSpyMDq,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
						for WWoD8IVMtKwujLxUqrZhO2FN in YYNLohXT3J:
							hh4gUqS5JWf1saRZPXHD = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('\d\d\d+',WWoD8IVMtKwujLxUqrZhO2FN,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
							if hh4gUqS5JWf1saRZPXHD:
								LjG8y1rb9AgJF2I3i64ZDtCXMa7n = '____'+hh4gUqS5JWf1saRZPXHD[0]
								break
						for WWoD8IVMtKwujLxUqrZhO2FN in reversed(YYNLohXT3J):
							hh4gUqS5JWf1saRZPXHD = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('\w\w+',WWoD8IVMtKwujLxUqrZhO2FN,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
							if hh4gUqS5JWf1saRZPXHD:
								nnsZpqc0JaulVMB = hh4gUqS5JWf1saRZPXHD[0]
								break
						JVTjFE7PkBL0YQqydGOe5M = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)"',OAX4sLSpyMDq,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
						for OCspMr7yq2iXx in JVTjFE7PkBL0YQqydGOe5M:
							OCspMr7yq2iXx = OCspMr7yq2iXx+'?named='+nnsZpqc0JaulVMB+'__download'+LjG8y1rb9AgJF2I3i64ZDtCXMa7n
							jVMHRouKgQFAESmd7B8ObTYy.append(OCspMr7yq2iXx)
		elif 'slow-motion' in flARjI3NM9CQnWY1xk7:
			flARjI3NM9CQnWY1xk7 = flARjI3NM9CQnWY1xk7.replace('<h6 ','==END== ==START==')+'==END=='
			flARjI3NM9CQnWY1xk7 = flARjI3NM9CQnWY1xk7.replace('<h3 ','==END== ==START==')+'==END=='
			DKCw4HYtMWofmn = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('==START==(.*?)==END==',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if DKCw4HYtMWofmn:
				for OAX4sLSpyMDq in DKCw4HYtMWofmn:
					if 'href=' not in OAX4sLSpyMDq: continue
					yyrv0HVlhAesd = ''
					YYNLohXT3J = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('slow-motion">(.*?)<',OAX4sLSpyMDq,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
					for WWoD8IVMtKwujLxUqrZhO2FN in YYNLohXT3J:
						hh4gUqS5JWf1saRZPXHD = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('\d\d\d+',WWoD8IVMtKwujLxUqrZhO2FN,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
						if hh4gUqS5JWf1saRZPXHD:
							yyrv0HVlhAesd = '____'+hh4gUqS5JWf1saRZPXHD[0]
							break
					YYNLohXT3J = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<td>(.*?)</td>.*?href="(http.*?)"',OAX4sLSpyMDq,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
					if YYNLohXT3J:
						for nnsZpqc0JaulVMB,CCRSQTKfB16v9nkVcom7FUgdEN in YYNLohXT3J:
							CCRSQTKfB16v9nkVcom7FUgdEN = CCRSQTKfB16v9nkVcom7FUgdEN+'?named='+nnsZpqc0JaulVMB+'__download'+yyrv0HVlhAesd
							jVMHRouKgQFAESmd7B8ObTYy.append(CCRSQTKfB16v9nkVcom7FUgdEN)
					else:
						YYNLohXT3J = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?http.*?)".*?name">(.*?)<',OAX4sLSpyMDq,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
						for CCRSQTKfB16v9nkVcom7FUgdEN,nnsZpqc0JaulVMB in YYNLohXT3J:
							CCRSQTKfB16v9nkVcom7FUgdEN = CCRSQTKfB16v9nkVcom7FUgdEN.strip(' ')+'?named='+nnsZpqc0JaulVMB+'__download'+yyrv0HVlhAesd
							jVMHRouKgQFAESmd7B8ObTYy.append(CCRSQTKfB16v9nkVcom7FUgdEN)
			else:
				YYNLohXT3J = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?>(\w+)<',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
				for CCRSQTKfB16v9nkVcom7FUgdEN,nnsZpqc0JaulVMB in YYNLohXT3J:
					CCRSQTKfB16v9nkVcom7FUgdEN = CCRSQTKfB16v9nkVcom7FUgdEN.strip(' ')+'?named='+nnsZpqc0JaulVMB+'__download'
					jVMHRouKgQFAESmd7B8ObTYy.append(CCRSQTKfB16v9nkVcom7FUgdEN)
	import JYR902sfml
	JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt(jVMHRouKgQFAESmd7B8ObTYy,r1NChsk39OMvT82YemDQnl5,'video',url)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if search=='': search = UIf35nZEj1wylmq()
	if search=='': return
	search = search.replace(' ','+')
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',tle5V6jgvRfE+'/alz','',headers,True,'','ARBLIONZ-SEARCH-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content.encode('utf8')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('chevron-select(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if showDialogs and TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('value="(.*?)".*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		WWrz2TVFs1OLRk4f,KEeG7unfTsxbjdkHI = [],[]
		for cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo,title in items:
			WWrz2TVFs1OLRk4f.append(cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo)
			KEeG7unfTsxbjdkHI.append(title)
		NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql('اختر الفلتر المناسب:', KEeG7unfTsxbjdkHI)
		if NljOosKT8WJBpch == -1 : return
		cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = WWrz2TVFs1OLRk4f[NljOosKT8WJBpch]
	else: cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = ''
	url = tle5V6jgvRfE + '/search?s='+search+'&category='+cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo+'&page=1'
	uyt3pAHZk4(url)
	return
def L1FsQxw6Afb7pcCe9Tr3qizXZ(url,filter):
	tpH7FYXLyz4UJdcC31OQ0Phwg = ['category','release-year','genre','Quality']
	if '?' in url: url = url.split('/getposts?')[0]
	type,filter = filter.split('___',1)
	if filter=='': ydL2RstfT9BA3Hpe1SZIq,l3Uo4ThenPyJMua = '',''
	else: ydL2RstfT9BA3Hpe1SZIq,l3Uo4ThenPyJMua = filter.split('___')
	if type=='CATEGORIES':
		if tpH7FYXLyz4UJdcC31OQ0Phwg[0]+'=' not in ydL2RstfT9BA3Hpe1SZIq: cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = tpH7FYXLyz4UJdcC31OQ0Phwg[0]
		for AudBQkLFsrHKicIogThZyv in range(len(tpH7FYXLyz4UJdcC31OQ0Phwg[0:-1])):
			if tpH7FYXLyz4UJdcC31OQ0Phwg[AudBQkLFsrHKicIogThZyv]+'=' in ydL2RstfT9BA3Hpe1SZIq: cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = tpH7FYXLyz4UJdcC31OQ0Phwg[AudBQkLFsrHKicIogThZyv+1]
		rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&'+cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo+'=0'
		SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&'+cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo+'=0'
		hOSk91jGqtHsfwU2ExCV4YB = rrsgSnC5AFkbEvDPm6pyaRizM8.strip('&')+'___'+SWxX6Q3CgwV7F.strip('&')
		Rdgr0aTSzE5chex9W = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(l3Uo4ThenPyJMua,'modified_filters')
		M08MPGgsh4n5rKe = url+'/getposts?'+Rdgr0aTSzE5chex9W
	elif type=='FILTERS':
		jyRzHeOYXAW4oDrUS = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(ydL2RstfT9BA3Hpe1SZIq,'modified_values')
		jyRzHeOYXAW4oDrUS = BUTSkzgFC7(jyRzHeOYXAW4oDrUS)
		if l3Uo4ThenPyJMua!='': l3Uo4ThenPyJMua = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(l3Uo4ThenPyJMua,'modified_filters')
		if l3Uo4ThenPyJMua=='': M08MPGgsh4n5rKe = url
		else: M08MPGgsh4n5rKe = url+'/getposts?'+l3Uo4ThenPyJMua
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'أظهار قائمة الفيديو التي تم اختيارها ',M08MPGgsh4n5rKe,201)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+' [[   '+jyRzHeOYXAW4oDrUS+'   ]]',M08MPGgsh4n5rKe,201)
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,url+'/alz','',headers,'','ARBLIONZ-FILTERS_MENU-1st')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('AjaxFilteringData(.*?)FilterWord',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	H8n4oVq07uvJjCOwgzbyf6XR9Fs = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('</i>(.*?)<.*?data-forTax="(.*?)"(.*?)<h2',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	dict = {}
	for name,eFmOUji0173K,ziJLDVT8NM2QcgIpmE9A in H8n4oVq07uvJjCOwgzbyf6XR9Fs:
		name = name.replace('اختيار ','')
		name = name.replace('سنة الإنتاج','السنة')
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('value="(.*?)".*?</div>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if '=' not in M08MPGgsh4n5rKe: M08MPGgsh4n5rKe = url
		if type=='CATEGORIES':
			if cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo!=eFmOUji0173K: continue
			elif len(items)<=1:
				if eFmOUji0173K==tpH7FYXLyz4UJdcC31OQ0Phwg[-1]: uyt3pAHZk4(M08MPGgsh4n5rKe)
				else: L1FsQxw6Afb7pcCe9Tr3qizXZ(M08MPGgsh4n5rKe,'CATEGORIES___'+hOSk91jGqtHsfwU2ExCV4YB)
				return
			else:
				if eFmOUji0173K==tpH7FYXLyz4UJdcC31OQ0Phwg[-1]: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع ',M08MPGgsh4n5rKe,201)
				else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع ',M08MPGgsh4n5rKe,205,'','',hOSk91jGqtHsfwU2ExCV4YB)
		elif type=='FILTERS':
			rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&'+eFmOUji0173K+'=0'
			SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&'+eFmOUji0173K+'=0'
			hOSk91jGqtHsfwU2ExCV4YB = rrsgSnC5AFkbEvDPm6pyaRizM8+'___'+SWxX6Q3CgwV7F
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع :'+name,M08MPGgsh4n5rKe,204,'','',hOSk91jGqtHsfwU2ExCV4YB)
		dict[eFmOUji0173K] = {}
		for hht0cpXxWw2OzFS1jnUGebkJLBd85,e0i4nPhusqdTaG in items:
			e0i4nPhusqdTaG = e0i4nPhusqdTaG.replace('\n','')
			if e0i4nPhusqdTaG in ZLKHfqMEUdRupD: continue
			dict[eFmOUji0173K][hht0cpXxWw2OzFS1jnUGebkJLBd85] = e0i4nPhusqdTaG
			rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&'+eFmOUji0173K+'='+e0i4nPhusqdTaG
			SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&'+eFmOUji0173K+'='+hht0cpXxWw2OzFS1jnUGebkJLBd85
			RtPpz8FAEjIxU = rrsgSnC5AFkbEvDPm6pyaRizM8+'___'+SWxX6Q3CgwV7F
			title = e0i4nPhusqdTaG+' :'#+dict[eFmOUji0173K]['0']
			title = e0i4nPhusqdTaG+' :'+name
			if type=='FILTERS': tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,204,'','',RtPpz8FAEjIxU)
			elif type=='CATEGORIES' and tpH7FYXLyz4UJdcC31OQ0Phwg[-2]+'=' in ydL2RstfT9BA3Hpe1SZIq:
				Rdgr0aTSzE5chex9W = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(SWxX6Q3CgwV7F,'modified_filters')
				TW6JIBgC971tjOE = url+'/getposts?'+Rdgr0aTSzE5chex9W
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,TW6JIBgC971tjOE,201)
			else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,205,'','',RtPpz8FAEjIxU)
	return
def l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(dY1a0xA6PKm7TOJSERt3sHU9Qp,mode):
	dY1a0xA6PKm7TOJSERt3sHU9Qp = dY1a0xA6PKm7TOJSERt3sHU9Qp.replace('=&','=0&')
	dY1a0xA6PKm7TOJSERt3sHU9Qp = dY1a0xA6PKm7TOJSERt3sHU9Qp.strip('&')
	nvNkgT7iGQOyed = {}
	if '=' in dY1a0xA6PKm7TOJSERt3sHU9Qp:
		items = dY1a0xA6PKm7TOJSERt3sHU9Qp.split('&')
		for hh4gUqS5JWf1saRZPXHD in items:
			DHcrLNnqExKjM8uvVlBhWd,hht0cpXxWw2OzFS1jnUGebkJLBd85 = hh4gUqS5JWf1saRZPXHD.split('=')
			nvNkgT7iGQOyed[DHcrLNnqExKjM8uvVlBhWd] = hht0cpXxWw2OzFS1jnUGebkJLBd85
	UJzegYmlGML35rasDAIx17Rhnk = ''
	bxa9Gj5p3oElwmngHJRKP7CtqS = ['category','release-year','genre','Quality']
	for key in bxa9Gj5p3oElwmngHJRKP7CtqS:
		if key in list(nvNkgT7iGQOyed.keys()): hht0cpXxWw2OzFS1jnUGebkJLBd85 = nvNkgT7iGQOyed[key]
		else: hht0cpXxWw2OzFS1jnUGebkJLBd85 = '0'
		if '%' not in hht0cpXxWw2OzFS1jnUGebkJLBd85: hht0cpXxWw2OzFS1jnUGebkJLBd85 = TaEr2nR3f5e8oXzpy(hht0cpXxWw2OzFS1jnUGebkJLBd85)
		if mode=='modified_values' and hht0cpXxWw2OzFS1jnUGebkJLBd85!='0': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+' + '+hht0cpXxWw2OzFS1jnUGebkJLBd85
		elif mode=='modified_filters' and hht0cpXxWw2OzFS1jnUGebkJLBd85!='0': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+'&'+key+'='+hht0cpXxWw2OzFS1jnUGebkJLBd85
		elif mode=='all': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+'&'+key+'='+hht0cpXxWw2OzFS1jnUGebkJLBd85
	UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk.strip(' + ')
	UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk.strip('&')
	UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk.replace('=0','=')
	UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk.replace('Quality','quality')
	return UJzegYmlGML35rasDAIx17Rhnk
# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'IFILM'
Yc0eBRLpbCkm4gK7OqyzuHwU = '_IFL_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
PLmnJkAzt8 = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][1]
VAolO02vjbQ = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][2]
yWQwqBjudmkxNaFcG7Z = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][3]
def HgQCVwFx2Br(mode,url,tsMKaFVh1ZN2BIXEcvTejxR5DP,text):
	if   mode==20: s4Bng5iAZQSTtpDw9 = hnsQrzqTK85dIcRLm1()
	elif mode==21: s4Bng5iAZQSTtpDw9 = Or15mUj4By(url)
	elif mode==22: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url,tsMKaFVh1ZN2BIXEcvTejxR5DP)
	elif mode==23: s4Bng5iAZQSTtpDw9 = btd6ag2XYUkHixqy5J7o9RfLu1MScm(url,tsMKaFVh1ZN2BIXEcvTejxR5DP)
	elif mode==24: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url,text)
	elif mode==25: s4Bng5iAZQSTtpDw9 = fuYdr2j5RHBo709TG(url)
	elif mode==27: s4Bng5iAZQSTtpDw9 = EvpYWVrnUQA(url)
	elif mode==28: s4Bng5iAZQSTtpDw9 = LHvAGC01R5hrDoilmPwz26x()
	elif mode==29: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def hnsQrzqTK85dIcRLm1():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'عربي',tle5V6jgvRfE,21,'','101')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'English',PLmnJkAzt8,21,'','101')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فارسى',VAolO02vjbQ,21,'','101')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فارسى 2',yWQwqBjudmkxNaFcG7Z,21,'','101')
	return
def LHvAGC01R5hrDoilmPwz26x():
	tBq8fTGUWJY9zvbgXD0EAloPO('live',Yc0eBRLpbCkm4gK7OqyzuHwU+'عربي',tle5V6jgvRfE,27)
	tBq8fTGUWJY9zvbgXD0EAloPO('live',Yc0eBRLpbCkm4gK7OqyzuHwU+'English',PLmnJkAzt8,27)
	tBq8fTGUWJY9zvbgXD0EAloPO('live',Yc0eBRLpbCkm4gK7OqyzuHwU+'فارسى',VAolO02vjbQ,27)
	tBq8fTGUWJY9zvbgXD0EAloPO('live',Yc0eBRLpbCkm4gK7OqyzuHwU+'فارسى 2',yWQwqBjudmkxNaFcG7Z,27)
	return
def Or15mUj4By(Eezbf4d51WaB2ZA8MTLYFOkNhs):
	r1NChsk39OMvT82YemDQnl5 = Eezbf4d51WaB2ZA8MTLYFOkNhs
	if Eezbf4d51WaB2ZA8MTLYFOkNhs=='IFILM-ARABIC': Eezbf4d51WaB2ZA8MTLYFOkNhs = tle5V6jgvRfE
	elif Eezbf4d51WaB2ZA8MTLYFOkNhs=='IFILM-ENGLISH': Eezbf4d51WaB2ZA8MTLYFOkNhs = PLmnJkAzt8
	else: r1NChsk39OMvT82YemDQnl5 = ''
	JpOKtD7egn = gGSxJBiPDAn2(Eezbf4d51WaB2ZA8MTLYFOkNhs)
	if JpOKtD7egn=='ar' or r1NChsk39OMvT82YemDQnl5=='IFILM-ARABIC':
		G7EWAatkHV36By = 'بحث في الموقع'
		O4KxfYcQGenF = 'مسلسلات - حالية'
		SSJLGwYsC5qz3bnku9IpyfX = 'مسلسلات - أحدث'
		Yli5pV0Tyo9z6Ns = 'مسلسلات - أبجدي'
		LL8FbhUQYj = 'بث حي آي فيلم'
		P6azwl971HyKZeAp2ok0Ycn4bqEBXf = 'أفلام'
		rXJ9ua8x2sLdomzE3VhfGyb = 'موسيقى'
		i7iZDk4EQKrUCqvxJHmL9XV = 'برامج'
	elif JpOKtD7egn=='en' or r1NChsk39OMvT82YemDQnl5=='IFILM-ENGLISH':
		G7EWAatkHV36By = 'Search in site'
		O4KxfYcQGenF = 'Series - Current'
		SSJLGwYsC5qz3bnku9IpyfX = 'Series - Latest'
		Yli5pV0Tyo9z6Ns = 'Series - Alphabet'
		LL8FbhUQYj = 'Live iFilm channel'
		P6azwl971HyKZeAp2ok0Ycn4bqEBXf = 'Movies'
		rXJ9ua8x2sLdomzE3VhfGyb = 'Music'
		i7iZDk4EQKrUCqvxJHmL9XV = 'Shows'
	elif JpOKtD7egn in ['fa','fa2']:
		G7EWAatkHV36By = 'جستجو در سایت'
		O4KxfYcQGenF = 'سريال - جاری'
		SSJLGwYsC5qz3bnku9IpyfX = 'سريال - آخرین'
		Yli5pV0Tyo9z6Ns = 'سريال - الفبا'
		LL8FbhUQYj = 'پخش زنده اي فيلم'
		P6azwl971HyKZeAp2ok0Ycn4bqEBXf = 'فيلم'
		rXJ9ua8x2sLdomzE3VhfGyb = 'موسيقى'
		i7iZDk4EQKrUCqvxJHmL9XV = 'برنامه ها'
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+G7EWAatkHV36By,Eezbf4d51WaB2ZA8MTLYFOkNhs,29,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('live',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+LL8FbhUQYj,Eezbf4d51WaB2ZA8MTLYFOkNhs,27)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	BYK4n5WxXhCpQ7N = ['Series','Program','Music']
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,Eezbf4d51WaB2ZA8MTLYFOkNhs+'/home','','','','IFILM-MENU-1st')
	TIkiozSLCv6werb97mHQ0q4y3=E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('button-menu(.*?)/Contact',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in ZCimQhV5lovgspAYzHq1Ef27u8ja4R for hht0cpXxWw2OzFS1jnUGebkJLBd85 in BYK4n5WxXhCpQ7N):
				url = Eezbf4d51WaB2ZA8MTLYFOkNhs+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
				if 'Series' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
					tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+O4KxfYcQGenF,url,22,'','100')
					tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+SSJLGwYsC5qz3bnku9IpyfX,url,22,'','101')
					tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+Yli5pV0Tyo9z6Ns,url,22,'','201')
				elif 'Film' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+P6azwl971HyKZeAp2ok0Ycn4bqEBXf,url,22,'','100')
				elif 'Music' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+rXJ9ua8x2sLdomzE3VhfGyb,url,25,'','101')
				elif 'Program' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+i7iZDk4EQKrUCqvxJHmL9XV,url,22,'','101')
	return M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
def fuYdr2j5RHBo709TG(url):
	Eezbf4d51WaB2ZA8MTLYFOkNhs = IgF5z7i4oaPHCepq2AjZ3UtbsT(url)
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,url,'','','','IFILM-MUSIC_MENU-1st')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('Music-tools-header(.*?)Music-body',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	title = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<p>(.*?)</p>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)[0]
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,22,'','101')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = Eezbf4d51WaB2ZA8MTLYFOkNhs + ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,23,'','101')
	return
def uyt3pAHZk4(url,tsMKaFVh1ZN2BIXEcvTejxR5DP):
	Eezbf4d51WaB2ZA8MTLYFOkNhs = IgF5z7i4oaPHCepq2AjZ3UtbsT(url)
	JpOKtD7egn = gGSxJBiPDAn2(url)
	type = url.split('/')[-1]
	ddyQAUtpenRZHPEGj5W = str(int(tsMKaFVh1ZN2BIXEcvTejxR5DP)//100)
	tsMKaFVh1ZN2BIXEcvTejxR5DP = str(int(tsMKaFVh1ZN2BIXEcvTejxR5DP)%100)
	if type=='Series' and tsMKaFVh1ZN2BIXEcvTejxR5DP=='0':
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,url,'','','','IFILM-TITLES-1st')
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('serial-body(.*?)class="row',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title in items:
			title = zKGXT5sJeRq(title)
			title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = Eezbf4d51WaB2ZA8MTLYFOkNhs + ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			Q2qmuDRrC9ikcaJK7gtUHXNW = Eezbf4d51WaB2ZA8MTLYFOkNhs + TaEr2nR3f5e8oXzpy(Q2qmuDRrC9ikcaJK7gtUHXNW)
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,23,Q2qmuDRrC9ikcaJK7gtUHXNW,ddyQAUtpenRZHPEGj5W+'01')
	Y4yjgJ5EhX3DFs1Cn6mkUcld=0
	if type=='Series': cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo='3'
	if type=='Film': cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo='5'
	if type=='Program': cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo='7'
	if type in ['Series','Program','Film'] and tsMKaFVh1ZN2BIXEcvTejxR5DP!='0':
		M08MPGgsh4n5rKe = Eezbf4d51WaB2ZA8MTLYFOkNhs+'/Home/PageingItem?category='+cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo+'&page='+tsMKaFVh1ZN2BIXEcvTejxR5DP+'&size=30&orderby='+ddyQAUtpenRZHPEGj5W
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,M08MPGgsh4n5rKe,'','','','IFILM-TITLES-2nd')
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for id,title,Q2qmuDRrC9ikcaJK7gtUHXNW in items:
			title = zKGXT5sJeRq(title)
			title = title.replace('\\','')
			title = title.replace('"','')
			Y4yjgJ5EhX3DFs1Cn6mkUcld += 1
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = Eezbf4d51WaB2ZA8MTLYFOkNhs + '/' + type + '/Content/' + id
			Q2qmuDRrC9ikcaJK7gtUHXNW = Eezbf4d51WaB2ZA8MTLYFOkNhs + TaEr2nR3f5e8oXzpy(Q2qmuDRrC9ikcaJK7gtUHXNW)
			if type=='Film': tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,24,Q2qmuDRrC9ikcaJK7gtUHXNW,ddyQAUtpenRZHPEGj5W+'01')
			else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,23,Q2qmuDRrC9ikcaJK7gtUHXNW,ddyQAUtpenRZHPEGj5W+'01')
	if type=='Music':
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,Eezbf4d51WaB2ZA8MTLYFOkNhs+'/Music/Index?page='+tsMKaFVh1ZN2BIXEcvTejxR5DP,'','','','IFILM-TITLES-3rd')
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('pagination-demo(.*?)pagination-demo',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title in items:
			Y4yjgJ5EhX3DFs1Cn6mkUcld += 1
			Q2qmuDRrC9ikcaJK7gtUHXNW = Eezbf4d51WaB2ZA8MTLYFOkNhs + Q2qmuDRrC9ikcaJK7gtUHXNW
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = Eezbf4d51WaB2ZA8MTLYFOkNhs + ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,23,Q2qmuDRrC9ikcaJK7gtUHXNW,'101')
	if Y4yjgJ5EhX3DFs1Cn6mkUcld>20:
		title='صفحة '
		if JpOKtD7egn=='en': title = 'Page '
		if JpOKtD7egn=='fa': title = 'صفحه '
		if JpOKtD7egn=='fa2': title = 'صفحه '
		for qq4r6dcPDb in range(1,11) :
			if not tsMKaFVh1ZN2BIXEcvTejxR5DP==str(qq4r6dcPDb):
				sCgcyH0zOF31a2LjbBIUJnqNSD5 = '0'+str(qq4r6dcPDb)
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title+str(qq4r6dcPDb),url,22,'',ddyQAUtpenRZHPEGj5W+sCgcyH0zOF31a2LjbBIUJnqNSD5[-2:])
	return
def btd6ag2XYUkHixqy5J7o9RfLu1MScm(url,tsMKaFVh1ZN2BIXEcvTejxR5DP):
	if not tsMKaFVh1ZN2BIXEcvTejxR5DP: tsMKaFVh1ZN2BIXEcvTejxR5DP = 0
	Eezbf4d51WaB2ZA8MTLYFOkNhs = IgF5z7i4oaPHCepq2AjZ3UtbsT(url)
	GowEgKmITalyMQHbZkt = IgF5z7i4oaPHCepq2AjZ3UtbsT(url)
	JpOKtD7egn = gGSxJBiPDAn2(url)
	oBzGqDUAi7KaL8vFdZtP9XIcf = url.split('/')
	id,type = oBzGqDUAi7KaL8vFdZtP9XIcf[-1],oBzGqDUAi7KaL8vFdZtP9XIcf[3]
	ddyQAUtpenRZHPEGj5W = str(int(tsMKaFVh1ZN2BIXEcvTejxR5DP)//100)
	tsMKaFVh1ZN2BIXEcvTejxR5DP = str(int(tsMKaFVh1ZN2BIXEcvTejxR5DP)%100)
	Y4yjgJ5EhX3DFs1Cn6mkUcld = 0
	if type=='Series':
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,url,'','','','IFILM-EPISODES-1st')
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		title = ' - الحلقة '
		if JpOKtD7egn=='en': title = ' - Episode '
		if JpOKtD7egn=='fa': title = ' - قسمت '
		if JpOKtD7egn=='fa2': title = ' - قسمت '
		if JpOKtD7egn=='fa': cM4WIJqi3mfnQ7Sl50oKFLPV = ''
		else: cM4WIJqi3mfnQ7Sl50oKFLPV = JpOKtD7egn
		qq1Xgr0F6TDi8lSHeWyZnab = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for name,count,Q2qmuDRrC9ikcaJK7gtUHXNW,ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
			for EQw62xjXSJmzrRt in range(int(count),0,-1):
				ZcakWjU409rIGVNfzh = Q2qmuDRrC9ikcaJK7gtUHXNW + cM4WIJqi3mfnQ7Sl50oKFLPV + id + '/' + str(EQw62xjXSJmzrRt) + '.png'
				O4KxfYcQGenF = name + title + str(EQw62xjXSJmzrRt)
				O4KxfYcQGenF = nnGHa80rMphqe1ukFtIRvAPs6W(O4KxfYcQGenF)
				tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+O4KxfYcQGenF,url,24,ZcakWjU409rIGVNfzh,'',str(EQw62xjXSJmzrRt))
	elif type=='Program':
		M08MPGgsh4n5rKe = Eezbf4d51WaB2ZA8MTLYFOkNhs+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+tsMKaFVh1ZN2BIXEcvTejxR5DP+'&size=30&orderby=1'
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,M08MPGgsh4n5rKe,'','','','IFILM-EPISODES-2nd')
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		title = ' - الحلقة '
		if JpOKtD7egn=='en': title = ' - Episode '
		if JpOKtD7egn=='fa': title = ' - قسمت '
		if JpOKtD7egn=='fa2': title = ' - قسمت '
		for EQw62xjXSJmzrRt,Q2qmuDRrC9ikcaJK7gtUHXNW,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,H5dNcbwuQfOj,name in items:
			Y4yjgJ5EhX3DFs1Cn6mkUcld += 1
			ZcakWjU409rIGVNfzh = GowEgKmITalyMQHbZkt + TaEr2nR3f5e8oXzpy(Q2qmuDRrC9ikcaJK7gtUHXNW)
			name = zKGXT5sJeRq(name)
			O4KxfYcQGenF = name + title + str(EQw62xjXSJmzrRt)
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+O4KxfYcQGenF,M08MPGgsh4n5rKe,24,ZcakWjU409rIGVNfzh,'',str(Y4yjgJ5EhX3DFs1Cn6mkUcld))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			M08MPGgsh4n5rKe = Eezbf4d51WaB2ZA8MTLYFOkNhs+'/Music/GetTracksBy?id='+str(id)+'&page='+tsMKaFVh1ZN2BIXEcvTejxR5DP+'&size=30&type=0'
			M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,M08MPGgsh4n5rKe,'','','','IFILM-EPISODES-3rd')
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for Q2qmuDRrC9ikcaJK7gtUHXNW,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,name,title in items:
				Y4yjgJ5EhX3DFs1Cn6mkUcld += 1
				ZcakWjU409rIGVNfzh = GowEgKmITalyMQHbZkt + TaEr2nR3f5e8oXzpy(Q2qmuDRrC9ikcaJK7gtUHXNW)
				O4KxfYcQGenF = name + ' - ' + title
				O4KxfYcQGenF = O4KxfYcQGenF.strip(' ')
				O4KxfYcQGenF = zKGXT5sJeRq(O4KxfYcQGenF)
				tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+O4KxfYcQGenF,M08MPGgsh4n5rKe,24,ZcakWjU409rIGVNfzh,'',str(Y4yjgJ5EhX3DFs1Cn6mkUcld))
		elif 'Clips' in url:
			M08MPGgsh4n5rKe = Eezbf4d51WaB2ZA8MTLYFOkNhs+'/Music/GetTracksBy?id=0&page='+tsMKaFVh1ZN2BIXEcvTejxR5DP+'&size=30&type=15'
			M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,M08MPGgsh4n5rKe,'','','','IFILM-EPISODES-4th')
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for Q2qmuDRrC9ikcaJK7gtUHXNW,title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
				Y4yjgJ5EhX3DFs1Cn6mkUcld += 1
				ZcakWjU409rIGVNfzh = GowEgKmITalyMQHbZkt + TaEr2nR3f5e8oXzpy(Q2qmuDRrC9ikcaJK7gtUHXNW)
				O4KxfYcQGenF = title.strip(' ')
				O4KxfYcQGenF = zKGXT5sJeRq(O4KxfYcQGenF)
				tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+O4KxfYcQGenF,M08MPGgsh4n5rKe,24,ZcakWjU409rIGVNfzh,'',str(Y4yjgJ5EhX3DFs1Cn6mkUcld))
		elif 'category' in url:
			if 'category=6' in url:
				M08MPGgsh4n5rKe = Eezbf4d51WaB2ZA8MTLYFOkNhs+'/Music/GetTracksBy?id=0&page='+tsMKaFVh1ZN2BIXEcvTejxR5DP+'&size=30&type=6'
				M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,M08MPGgsh4n5rKe,'','','','IFILM-EPISODES-5th')
			elif 'category=4' in url:
				M08MPGgsh4n5rKe = Eezbf4d51WaB2ZA8MTLYFOkNhs+'/Music/GetTracksBy?id=0&page='+tsMKaFVh1ZN2BIXEcvTejxR5DP+'&size=30&type=4'
				M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,M08MPGgsh4n5rKe,'','','','IFILM-EPISODES-6th')
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for Q2qmuDRrC9ikcaJK7gtUHXNW,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,name,title in items:
				Y4yjgJ5EhX3DFs1Cn6mkUcld += 1
				ZcakWjU409rIGVNfzh = GowEgKmITalyMQHbZkt + TaEr2nR3f5e8oXzpy(Q2qmuDRrC9ikcaJK7gtUHXNW)
				O4KxfYcQGenF = name + ' - ' + title
				O4KxfYcQGenF = O4KxfYcQGenF.strip(' ')
				O4KxfYcQGenF = zKGXT5sJeRq(O4KxfYcQGenF)
				tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+O4KxfYcQGenF,M08MPGgsh4n5rKe,24,ZcakWjU409rIGVNfzh,'',str(Y4yjgJ5EhX3DFs1Cn6mkUcld))
	if type=='Music' or type=='Program':
		if Y4yjgJ5EhX3DFs1Cn6mkUcld>25:
			title='صفحة '
			if JpOKtD7egn=='en': title = ' Page '
			if JpOKtD7egn=='fa': title = ' صفحه '
			if JpOKtD7egn=='fa2': title = ' صفحه '
			for qq4r6dcPDb in range(1,11):
				if not tsMKaFVh1ZN2BIXEcvTejxR5DP==str(qq4r6dcPDb):
					sCgcyH0zOF31a2LjbBIUJnqNSD5 = '0'+str(qq4r6dcPDb)
					tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title+str(qq4r6dcPDb),url,23,'',ddyQAUtpenRZHPEGj5W+sCgcyH0zOF31a2LjbBIUJnqNSD5[-2:])
	return
def dlropqS0vO9K7W4z(url,EQw62xjXSJmzrRt):
	GowEgKmITalyMQHbZkt = IgF5z7i4oaPHCepq2AjZ3UtbsT(url)
	da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = [],[]
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,url,'','','','IFILM-PLAY-1st')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if items:
		JpOKtD7egn = gGSxJBiPDAn2(url)
		oBzGqDUAi7KaL8vFdZtP9XIcf = url.split('/')
		id,type = oBzGqDUAi7KaL8vFdZtP9XIcf[-1],oBzGqDUAi7KaL8vFdZtP9XIcf[3]
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = items[0][0]+JpOKtD7egn+id+'/,'+EQw62xjXSJmzrRt+','+EQw62xjXSJmzrRt+'_'+items[0][2]
		da6IAnqQ7oV2Hx13F5gbBT4.append('m3u8')
		jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if items:
		JpOKtD7egn = gGSxJBiPDAn2(url)
		oBzGqDUAi7KaL8vFdZtP9XIcf = url.split('/')
		id,type = oBzGqDUAi7KaL8vFdZtP9XIcf[-1],oBzGqDUAi7KaL8vFdZtP9XIcf[3]
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = items[0][0]+JpOKtD7egn+id+'/'+EQw62xjXSJmzrRt+items[0][2]
		da6IAnqQ7oV2Hx13F5gbBT4.append('mp4 url')
		jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('source src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.replace('//','/')
		da6IAnqQ7oV2Hx13F5gbBT4.append('mp4 src')
		jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('VideoAddress":"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if items:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = items[int(EQw62xjXSJmzrRt)-1]
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = GowEgKmITalyMQHbZkt+TaEr2nR3f5e8oXzpy(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
		da6IAnqQ7oV2Hx13F5gbBT4.append('mp4 address')
		jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('VoiceAddress":"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if items:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = items[int(EQw62xjXSJmzrRt)-1]
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = GowEgKmITalyMQHbZkt+TaEr2nR3f5e8oXzpy(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
		da6IAnqQ7oV2Hx13F5gbBT4.append('mp3 address')
		jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	if len(jVMHRouKgQFAESmd7B8ObTYy)==1: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = jVMHRouKgQFAESmd7B8ObTYy[0]
	else:
		NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql('اختر الفيديو المناسب:', da6IAnqQ7oV2Hx13F5gbBT4)
		if NljOosKT8WJBpch == -1 : return
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = jVMHRouKgQFAESmd7B8ObTYy[NljOosKT8WJBpch]
	pSAuLjYqhgc9brWFKs7Pa4J(ZCimQhV5lovgspAYzHq1Ef27u8ja4R,r1NChsk39OMvT82YemDQnl5,'video')
	return
def IgF5z7i4oaPHCepq2AjZ3UtbsT(url):
	if tle5V6jgvRfE in url: VewOrPR4kX = tle5V6jgvRfE
	elif PLmnJkAzt8 in url: VewOrPR4kX = PLmnJkAzt8
	elif VAolO02vjbQ in url: VewOrPR4kX = VAolO02vjbQ
	elif yWQwqBjudmkxNaFcG7Z in url: VewOrPR4kX = yWQwqBjudmkxNaFcG7Z
	else: VewOrPR4kX = ''
	return VewOrPR4kX
def gGSxJBiPDAn2(url):
	if   tle5V6jgvRfE in url: JpOKtD7egn = 'ar'
	elif PLmnJkAzt8 in url: JpOKtD7egn = 'en'
	elif VAolO02vjbQ in url: JpOKtD7egn = 'fa'
	elif yWQwqBjudmkxNaFcG7Z in url: JpOKtD7egn = 'fa2'
	else: JpOKtD7egn = ''
	return JpOKtD7egn
def EvpYWVrnUQA(url):
	JpOKtD7egn = gGSxJBiPDAn2(url)
	M08MPGgsh4n5rKe = url + '/Home/Live'
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',M08MPGgsh4n5rKe,'','','','','IFILM-LIVE-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('source src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	TW6JIBgC971tjOE = items[0]
	pSAuLjYqhgc9brWFKs7Pa4J(TW6JIBgC971tjOE,r1NChsk39OMvT82YemDQnl5,'live')
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if not search:
		search = UIf35nZEj1wylmq()
		if not search: return
	DbEfLQSBFCTt2mMqvrsIVnjJ6 = search.replace(' ','+')
	if showDialogs:
		Kygp5N1s2R48xrFHJ6Pfm = [ tle5V6jgvRfE , PLmnJkAzt8 , VAolO02vjbQ , yWQwqBjudmkxNaFcG7Z ]
		JHO207wRUyXeK = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql('اختر اللغة المناسبة:', JHO207wRUyXeK)
		if NljOosKT8WJBpch == -1 : return
		website = Kygp5N1s2R48xrFHJ6Pfm[NljOosKT8WJBpch]
	else:
		if '_IFILM-ARABIC_' in dNlVai6Obj1e: website = tle5V6jgvRfE
		elif '_IFILM-ENGLISH_' in dNlVai6Obj1e: website = PLmnJkAzt8
		else: website = ''
	if not website: return
	JpOKtD7egn = gGSxJBiPDAn2(website)
	M08MPGgsh4n5rKe = website + "/Home/Search?searchstring=" + DbEfLQSBFCTt2mMqvrsIVnjJ6
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,M08MPGgsh4n5rKe,'','','','IFILM-SEARCH-1st')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"ImageAddress_S":"(.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if items:
		for Q2qmuDRrC9ikcaJK7gtUHXNW,cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo,id,title in items:
			if cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo in ['3','7']:
				title = title.replace('\\','')
				title = title.replace('"','')
				if cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo=='3':
					type = 'Series'
					if JpOKtD7egn=='ar': name = 'مسلسل : '
					elif JpOKtD7egn=='en': name = 'Series : '
					elif JpOKtD7egn=='fa': name = 'سريال ها : '
					elif JpOKtD7egn=='fa2': name = 'سريال ها : '
				elif cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo=='5':
					type = 'Film'
					if JpOKtD7egn=='ar': name = 'فيلم : '
					elif JpOKtD7egn=='en': name = 'Movie : '
					elif JpOKtD7egn=='fa': name = 'فيلم : '
					elif JpOKtD7egn=='fa2': name = 'فلم ها : '
				elif cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo=='7':
					type = 'Program'
					if JpOKtD7egn=='ar': name = 'برنامج : '
					elif JpOKtD7egn=='en': name = 'Program : '
					elif JpOKtD7egn=='fa': name = 'برنامه ها : '
					elif JpOKtD7egn=='fa2': name = 'برنامه ها : '
				title = name + title
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = website + '/' + type + '/Content/' + id
				Q2qmuDRrC9ikcaJK7gtUHXNW = TaEr2nR3f5e8oXzpy(Q2qmuDRrC9ikcaJK7gtUHXNW)
				Q2qmuDRrC9ikcaJK7gtUHXNW = website+Q2qmuDRrC9ikcaJK7gtUHXNW
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,23,Q2qmuDRrC9ikcaJK7gtUHXNW,'101')
	return
# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
PCY2LJwTgIfan = 'IPTV'
E6M5YUL1m4a0JDVtwcdzqovGR = '_IPT_'
mVgfp8N2qHKACYF74eRkJ5s9U = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_ARCHIVED_GROUPED_SORTED','LIVE_EPG_GROUPED_SORTED','LIVE_TIMESHIFT_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
def N0NXgq1LxMG5zdr3ZDfho497lyI(n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,d7on6sKDqkNY,RxgdTHfDar8EXt,s8Oimqou2fZD,eWICxFNw73mJnSToUiR,UrmJVLMKYwNQFS4XBP):
	global E6M5YUL1m4a0JDVtwcdzqovGR
	try:
		L96HvDd3sfBiCSRT = str(UrmJVLMKYwNQFS4XBP['folder'])
		E6M5YUL1m4a0JDVtwcdzqovGR = '_IP'+L96HvDd3sfBiCSRT+'_'
	except: L96HvDd3sfBiCSRT = ''
	if   n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==230: RbtUmf6lI3nFS8agCeNWGDcK4Z0 = K7b5Rysh2FMzQvdi9pk4JojX8lwtVm()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==231: RbtUmf6lI3nFS8agCeNWGDcK4Z0 = Hv5aEwmrNiyA8WpG4l(L96HvDd3sfBiCSRT)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==232: RbtUmf6lI3nFS8agCeNWGDcK4Z0 = sazIx9C3N72Tqf(L96HvDd3sfBiCSRT)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==233: RbtUmf6lI3nFS8agCeNWGDcK4Z0 = ddvQlFmprDb(L96HvDd3sfBiCSRT,d7on6sKDqkNY,RxgdTHfDar8EXt,eWICxFNw73mJnSToUiR)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==234: RbtUmf6lI3nFS8agCeNWGDcK4Z0 = Hb39UqlX2fZDpc(L96HvDd3sfBiCSRT,d7on6sKDqkNY,RxgdTHfDar8EXt,eWICxFNw73mJnSToUiR)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==235: RbtUmf6lI3nFS8agCeNWGDcK4Z0 = dlropqS0vO9K7W4z(L96HvDd3sfBiCSRT,d7on6sKDqkNY,s8Oimqou2fZD)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==236: RbtUmf6lI3nFS8agCeNWGDcK4Z0 = IIyUEG1AogvkF0zM(L96HvDd3sfBiCSRT,True)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==237: RbtUmf6lI3nFS8agCeNWGDcK4Z0 = EnxyPA8u9MYFKtcbkrIV43QG7Tq5j(L96HvDd3sfBiCSRT,True)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==238: RbtUmf6lI3nFS8agCeNWGDcK4Z0 = bjmMGta9AnVxoYQRi4(L96HvDd3sfBiCSRT,d7on6sKDqkNY,RxgdTHfDar8EXt)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==239: RbtUmf6lI3nFS8agCeNWGDcK4Z0 = AWOymv5wMZT16cEk9xin(RxgdTHfDar8EXt,L96HvDd3sfBiCSRT,d7on6sKDqkNY,eWICxFNw73mJnSToUiR)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==280: RbtUmf6lI3nFS8agCeNWGDcK4Z0 = EEP8u4SqXOtmnR(L96HvDd3sfBiCSRT,True)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==281: RbtUmf6lI3nFS8agCeNWGDcK4Z0 = hdFbXSLxsgc0PwrzvyD9kqW8(L96HvDd3sfBiCSRT)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==282: RbtUmf6lI3nFS8agCeNWGDcK4Z0 = RRmWyG6qhNS7TK8BYwgiCjsU(L96HvDd3sfBiCSRT)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==283: RbtUmf6lI3nFS8agCeNWGDcK4Z0 = ooXTiKU1v7(L96HvDd3sfBiCSRT)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==285: RbtUmf6lI3nFS8agCeNWGDcK4Z0 = lN8OQBfxW9uPj0cqp7vETM2Cr(L96HvDd3sfBiCSRT,d7on6sKDqkNY,RxgdTHfDar8EXt)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==286: RbtUmf6lI3nFS8agCeNWGDcK4Z0 = FyTSX7Lb2cvirxWEzwZkugNJjo(L96HvDd3sfBiCSRT)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==289: RbtUmf6lI3nFS8agCeNWGDcK4Z0 = CGSAfh0J78uolWtjD5(RxgdTHfDar8EXt,L96HvDd3sfBiCSRT,d7on6sKDqkNY,eWICxFNw73mJnSToUiR)
	else: RbtUmf6lI3nFS8agCeNWGDcK4Z0 = False
	return RbtUmf6lI3nFS8agCeNWGDcK4Z0
def K7b5Rysh2FMzQvdi9pk4JojX8lwtVm():
	for L96HvDd3sfBiCSRT in range(1,qHwLO4cGVh+1):
		E6M5YUL1m4a0JDVtwcdzqovGR = '_IP'+str(L96HvDd3sfBiCSRT)+'_'
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'قائمة مجلد '+qjvurmMCnxdktlp6Ii2ZhJb74y[L96HvDd3sfBiCSRT],'',280,'','','','',{'folder':L96HvDd3sfBiCSRT})
	return
def EEP8u4SqXOtmnR(L96HvDd3sfBiCSRT='',yt3K6SfQFkPNlIiWbjOCJHDh5Vpr=''):
	if L96HvDd3sfBiCSRT:
		kyUZXioHb5 = {'folder':L96HvDd3sfBiCSRT}
		XUNjtI8O0qcfE7Z2dvegwh6pboYa4 = ''
	else:
		kyUZXioHb5 = ''
		XUNjtI8O0qcfE7Z2dvegwh6pboYa4 = ''
	LWGdY6tAU8VTkqCluaopm7be = RwN5lZjvPsLCW7gz9c0ab1x(L96HvDd3sfBiCSRT,yt3K6SfQFkPNlIiWbjOCJHDh5Vpr)
	if not LWGdY6tAU8VTkqCluaopm7be:
		tBq8fTGUWJY9zvbgXD0EAloPO('link',E6M5YUL1m4a0JDVtwcdzqovGR+'[COLOR FFFFFF00] إضافة أو تغيير اشتراك'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4+' [/COLOR]','',231,'','','','',kyUZXioHb5)
		tBq8fTGUWJY9zvbgXD0EAloPO('link',E6M5YUL1m4a0JDVtwcdzqovGR+'[COLOR FFFFFF00] جلب ملفات'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4+' [/COLOR]','',232,'','','','',kyUZXioHb5)
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	else:
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'بحث في الملفات'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'',289,'','','_REMEMBERRESULTS_','',kyUZXioHb5)
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'قنوات بدون جلب ملفات','XTREAM_LIVE_GROUPS',285,'','','','',kyUZXioHb5)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'قنوات مصنفة مرتبة'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'LIVE_GROUPED_SORTED',233,'','','','',kyUZXioHb5)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'قنوات مصنفة من القسم'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'LIVE_FROM_GROUP_SORTED',233,'','','','',kyUZXioHb5)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'قنوات مصنفة من الاسم'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'LIVE_FROM_NAME_SORTED',233,'','','','',kyUZXioHb5)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'قنوات مصنفة بلا ترتيب'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'LIVE_GROUPED',233,'','','','',kyUZXioHb5)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'قنوات بلا ترتيب'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'LIVE_ORIGINAL_GROUPED',233,'','','','',kyUZXioHb5)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'قنوات مجهولة مرتبة'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'LIVE_UNKNOWN_GROUPED_SORTED',233,'','','','',kyUZXioHb5)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'قنوات مجهولة بلا ترتيب'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'LIVE_UNKNOWN_GROUPED',233,'','','','',kyUZXioHb5)
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'أفلام بدون جلب ملفات','XTREAM_VOD_GROUPS',285,'','','','',kyUZXioHb5)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'أفلام مصنفة بلا ترتيب'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'VOD_MOVIES_GROUPED',233,'','','','',kyUZXioHb5)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'أفلام مصنفة مرتبة'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'VOD_MOVIES_GROUPED_SORTED',233,'','','','',kyUZXioHb5)
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'مسلسلات بدون جلب ملفات','XTREAM_SERIES_GROUPS',285,'','','','',kyUZXioHb5)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'مسلسلات مصنفة بلا ترتيب'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'VOD_SERIES_GROUPED',233,'','','','',kyUZXioHb5)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'مسلسلات مصنفة مرتبة'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'VOD_SERIES_GROUPED_SORTED',233,'','','','',kyUZXioHb5)
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'فيديوهات بلا ترتيب'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'VOD_ORIGINAL_GROUPED',233,'','','','',kyUZXioHb5)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'فيديوهات مصنفة من القسم'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'VOD_FROM_GROUP_SORTED',233,'','','','',kyUZXioHb5)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'فيديوهات مصنفة من الاسم'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'VOD_FROM_NAME_SORTED',233,'','','','',kyUZXioHb5)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'فيديوهات مجهولة بلا ترتيب'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'VOD_UNKNOWN_GROUPED',233,'','','','',kyUZXioHb5)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'فيديوهات مجهولة مرتبة'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'VOD_UNKNOWN_GROUPED_SORTED',233,'','','','',kyUZXioHb5)
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'برامج القنوات (جدول فقط)'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'LIVE_EPG_GROUPED_SORTED',233,'','','','',kyUZXioHb5)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'أرشيف القنوات للأيام الماضية'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'LIVE_TIMESHIFT_GROUPED_SORTED',233,'','','','',kyUZXioHb5)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'أرشيف برامج القنوات للأيام الماضية'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'LIVE_ARCHIVED_GROUPED_SORTED',233,'','','','',kyUZXioHb5)
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('link',E6M5YUL1m4a0JDVtwcdzqovGR+'إضافة أو تغيير اشتراك'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'',231,'','','','',kyUZXioHb5)
	tBq8fTGUWJY9zvbgXD0EAloPO('link',E6M5YUL1m4a0JDVtwcdzqovGR+'جلب ملفات'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'',232,'','','','',kyUZXioHb5)
	tBq8fTGUWJY9zvbgXD0EAloPO('link',E6M5YUL1m4a0JDVtwcdzqovGR+'مسح ملفات'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'',237,'','','','',kyUZXioHb5)
	tBq8fTGUWJY9zvbgXD0EAloPO('link',E6M5YUL1m4a0JDVtwcdzqovGR+'فحص اشتراك'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'',236,'','','','',kyUZXioHb5)
	tBq8fTGUWJY9zvbgXD0EAloPO('link',E6M5YUL1m4a0JDVtwcdzqovGR+'عدد فيديوهات'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'',281,'','','','',kyUZXioHb5)
	tBq8fTGUWJY9zvbgXD0EAloPO('link',E6M5YUL1m4a0JDVtwcdzqovGR+'Referer تغيير'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'',286,'','','','',kyUZXioHb5)
	tBq8fTGUWJY9zvbgXD0EAloPO('link',E6M5YUL1m4a0JDVtwcdzqovGR+'User-Agent تغيير'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'',283,'','','','',kyUZXioHb5)
	tBq8fTGUWJY9zvbgXD0EAloPO('link',E6M5YUL1m4a0JDVtwcdzqovGR+'استخدم السيرفر الأسرع'+XUNjtI8O0qcfE7Z2dvegwh6pboYa4,'',282,'','','','',kyUZXioHb5)
	return
def IIyUEG1AogvkF0zM(L96HvDd3sfBiCSRT,yt3K6SfQFkPNlIiWbjOCJHDh5Vpr=True):
	dOYWNS6kcKr5mMsFuh3T,kQgGCeMh2D0RJjT = False,''
	b9j4niYADepUc28WXuSJV,hQkH6GzJPnm0fSNlKLyiwCrR43Fa5 = '',''
	UBc3wC6Sx0AlO,f9MB4sy57lnC0Hrc,t3tPaSeRm48gpYcl,szmuUXHkrIyBZY,KKGXLutpaj9yWwBJ4Tmgfq2ShYlZDO = H4HNRVUbi5(L96HvDd3sfBiCSRT)
	if szmuUXHkrIyBZY=='': return False,'',''
	UZbaV6FlwAM0uNvdS1mcIPypC = vrpfxzlAKcTZiUaRgudtsmOPEL(L96HvDd3sfBiCSRT)
	if UBc3wC6Sx0AlO:
		pPvgKtqo5IAzadVRZsCGU = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,'GET',UBc3wC6Sx0AlO,'',UZbaV6FlwAM0uNvdS1mcIPypC,False,'','IPTV-CHECK_ACCOUNT-1st')
		kDQZoFnLUTYc8G45u21ye = pPvgKtqo5IAzadVRZsCGU.content
		if pPvgKtqo5IAzadVRZsCGU.succeeded:
			ebPA68iy34NgOzSCT9umHrIoFqQ,PQ5AFaC3yvs0MrTIc,WMEmKCSJrDnc0uZlYi38O,XIiEWNPDtUSy4xGj51A3,qwKjvWCF3NVOtYya59iLPfM1zIJQ = 0,0,'','',''
			try:
				d4Re9mNuVo2 = GVQAnvYCT3dS('dict',kDQZoFnLUTYc8G45u21ye)
				kQgGCeMh2D0RJjT = d4Re9mNuVo2['user_info']['status']
				dOYWNS6kcKr5mMsFuh3T = True
				WMEmKCSJrDnc0uZlYi38O = d4Re9mNuVo2['server_info']['time_now']
			except: pass
			if WMEmKCSJrDnc0uZlYi38O:
				try:
					L4ojbVRaXY1 = w6vebiEZtpCjJcILP8Skx5rHn.strptime(WMEmKCSJrDnc0uZlYi38O,'%Y.%m.%d %H:%M:%S')
					ebPA68iy34NgOzSCT9umHrIoFqQ = int(w6vebiEZtpCjJcILP8Skx5rHn.mktime(L4ojbVRaXY1))
					PQ5AFaC3yvs0MrTIc = int(eOYicX68ruMjpN0dKtWP5QTSE-ebPA68iy34NgOzSCT9umHrIoFqQ)
					PQ5AFaC3yvs0MrTIc = int((PQ5AFaC3yvs0MrTIc+900)/1800)*1800
				except: pass
				try:
					L4ojbVRaXY1 = w6vebiEZtpCjJcILP8Skx5rHn.localtime(int(d4Re9mNuVo2['user_info']['created_at']))
					XIiEWNPDtUSy4xGj51A3 = w6vebiEZtpCjJcILP8Skx5rHn.strftime('%Y.%m.%d %H:%M:%S',L4ojbVRaXY1)
				except: pass
				try:
					L4ojbVRaXY1 = w6vebiEZtpCjJcILP8Skx5rHn.localtime(int(d4Re9mNuVo2['user_info']['exp_date']))
					qwKjvWCF3NVOtYya59iLPfM1zIJQ = w6vebiEZtpCjJcILP8Skx5rHn.strftime('%Y.%m.%d %H:%M:%S',L4ojbVRaXY1)
				except: pass
			if2qpOxlZd8MBGeo5uNIyLEsz.setSetting('av.iptv.timestamp_'+L96HvDd3sfBiCSRT,str(eOYicX68ruMjpN0dKtWP5QTSE))
			if2qpOxlZd8MBGeo5uNIyLEsz.setSetting('av.iptv.timediff_'+L96HvDd3sfBiCSRT,str(PQ5AFaC3yvs0MrTIc))
			try:
				KIJoxawO5eDB0zYfP = '"server_info":'+kDQZoFnLUTYc8G45u21ye.split('"server_info":')[1]
				KIJoxawO5eDB0zYfP = KIJoxawO5eDB0zYfP.replace(':',': ').replace(',',', ').replace('}}','}')
				TsFitGVJQL6XYAc = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"url": "(.*?)", "port": "(.*?)"',KIJoxawO5eDB0zYfP,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
				b9j4niYADepUc28WXuSJV,hQkH6GzJPnm0fSNlKLyiwCrR43Fa5 = TsFitGVJQL6XYAc[0]
			except: dOYWNS6kcKr5mMsFuh3T = False
			if dOYWNS6kcKr5mMsFuh3T and yt3K6SfQFkPNlIiWbjOCJHDh5Vpr:
				max = d4Re9mNuVo2['user_info']['max_connections']
				i21xKwFpzGoSu3I8 = d4Re9mNuVo2['user_info']['active_cons']
				VdaUyLFTEktnz5CKmMe1 = d4Re9mNuVo2['user_info']['is_trial']
				KKmNhcrEDoHvMyOn01Wfe4IzgsCZq = UBc3wC6Sx0AlO.split('?',1)
				maCNIYkc0HOiEGpL3g = 'URL:  [COLOR FFC89008]'+UBc3wC6Sx0AlO+'[/COLOR]'
				maCNIYkc0HOiEGpL3g += '\n\nStatus:  '+'[COLOR FFC89008]'+kQgGCeMh2D0RJjT+'[/COLOR]'
				maCNIYkc0HOiEGpL3g += '\nTrial:    '+'[COLOR FFC89008]'+str(VdaUyLFTEktnz5CKmMe1=='1')+'[/COLOR]'
				maCNIYkc0HOiEGpL3g += '\nCreated  At:  '+'[COLOR FFC89008]'+XIiEWNPDtUSy4xGj51A3+'[/COLOR]'
				maCNIYkc0HOiEGpL3g += '\nExpiry Date:  '+'[COLOR FFC89008]'+qwKjvWCF3NVOtYya59iLPfM1zIJQ+'[/COLOR]'
				maCNIYkc0HOiEGpL3g += '\nConnections   ( Active / Maximum ) :  '+'[COLOR FFC89008]'+i21xKwFpzGoSu3I8+' / '+max+'[/COLOR]'
				maCNIYkc0HOiEGpL3g += '\nAllowed Outputs:   '+'[COLOR FFC89008]'+" , ".join(d4Re9mNuVo2['user_info']['allowed_output_formats'])+'[/COLOR]'
				maCNIYkc0HOiEGpL3g += '\n\n'+KIJoxawO5eDB0zYfP
				if kQgGCeMh2D0RJjT=='Active': pIq1ZYkhw0L93('الاشتراك يعمل بدون مشاكل',maCNIYkc0HOiEGpL3g)
				else: pIq1ZYkhw0L93('يبدو أن هناك مشكلة في الاشتراك',maCNIYkc0HOiEGpL3g)
	if UBc3wC6Sx0AlO and dOYWNS6kcKr5mMsFuh3T and kQgGCeMh2D0RJjT=='Active':
		y75wQavkVSLUb2MZf9qo('NOTICE','.  Checking IPTV URL   [ IPTV account is OK ]   [ '+UBc3wC6Sx0AlO+' ]')
		agX9nom53W = True
	else:
		y75wQavkVSLUb2MZf9qo('ERROR_LINES','Checking IPTV URL   [ Does not work ]   [ '+UBc3wC6Sx0AlO+' ]')
		if yt3K6SfQFkPNlIiWbjOCJHDh5Vpr: tehb3k5a2PufGOdBIUw8j('','','فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		agX9nom53W = False
	return agX9nom53W,b9j4niYADepUc28WXuSJV,hQkH6GzJPnm0fSNlKLyiwCrR43Fa5
def Hb39UqlX2fZDpc(L96HvDd3sfBiCSRT,jeS4FEdVxGPhtakofC1yzm,RgXOq491d8il03VuzDLnHjxCy,euK4mQzpdF6fay,yt3K6SfQFkPNlIiWbjOCJHDh5Vpr=True):
	if not euK4mQzpdF6fay: euK4mQzpdF6fay = '1'
	if not RwN5lZjvPsLCW7gz9c0ab1x(L96HvDd3sfBiCSRT,yt3K6SfQFkPNlIiWbjOCJHDh5Vpr): return
	Mm3aBo2VsXjZ4QD = GT29iAgzfL8kt63(L96HvDd3sfBiCSRT,jeS4FEdVxGPhtakofC1yzm)
	tjIyR9ML3FVQuzmsn7h = vsmQSl1ZDENy69BXJhWYF(Mm3aBo2VsXjZ4QD,'list',jeS4FEdVxGPhtakofC1yzm,RgXOq491d8il03VuzDLnHjxCy)
	fBD10G45rxzjQwdh7C = int(euK4mQzpdF6fay)*100
	DknNRL79Cr = fBD10G45rxzjQwdh7C-100
	for tiIc9lDHrUd,NqFXMA4Rr9cWzm,d7on6sKDqkNY,aPjqOy9703c4voXh1Dz65mMLRZf in tjIyR9ML3FVQuzmsn7h[DknNRL79Cr:fBD10G45rxzjQwdh7C]:
		sXPYFy6hlLKRdfU7CAG5 = ('GROUPED' in jeS4FEdVxGPhtakofC1yzm or jeS4FEdVxGPhtakofC1yzm=='ALL')
		L7R6exXuwvhzdJUE1FOs2 = ('GROUPED' not in jeS4FEdVxGPhtakofC1yzm and jeS4FEdVxGPhtakofC1yzm!='ALL')
		if sXPYFy6hlLKRdfU7CAG5 or L7R6exXuwvhzdJUE1FOs2:
			if   'ARCHIVED'  in jeS4FEdVxGPhtakofC1yzm: muPDGHvJwFieQYCW62bB.append(['folder',E6M5YUL1m4a0JDVtwcdzqovGR+NqFXMA4Rr9cWzm,d7on6sKDqkNY,238,aPjqOy9703c4voXh1Dz65mMLRZf,'','ARCHIVED','',{'folder':L96HvDd3sfBiCSRT}])
			elif 'EPG' 		 in jeS4FEdVxGPhtakofC1yzm: muPDGHvJwFieQYCW62bB.append(['folder',E6M5YUL1m4a0JDVtwcdzqovGR+NqFXMA4Rr9cWzm,d7on6sKDqkNY,238,aPjqOy9703c4voXh1Dz65mMLRZf,'','FULL_EPG','',{'folder':L96HvDd3sfBiCSRT}])
			elif 'TIMESHIFT' in jeS4FEdVxGPhtakofC1yzm: muPDGHvJwFieQYCW62bB.append(['folder',E6M5YUL1m4a0JDVtwcdzqovGR+NqFXMA4Rr9cWzm,d7on6sKDqkNY,238,aPjqOy9703c4voXh1Dz65mMLRZf,'','TIMESHIFT','',{'folder':L96HvDd3sfBiCSRT}])
			elif 'LIVE' 	 in jeS4FEdVxGPhtakofC1yzm: muPDGHvJwFieQYCW62bB.append(['live',E6M5YUL1m4a0JDVtwcdzqovGR+NqFXMA4Rr9cWzm,d7on6sKDqkNY,235,aPjqOy9703c4voXh1Dz65mMLRZf,'','',tiIc9lDHrUd,{'folder':L96HvDd3sfBiCSRT}])
			else: muPDGHvJwFieQYCW62bB.append(['video',E6M5YUL1m4a0JDVtwcdzqovGR+NqFXMA4Rr9cWzm,d7on6sKDqkNY,235,aPjqOy9703c4voXh1Dz65mMLRZf,'','','',{'folder':L96HvDd3sfBiCSRT}])
	TvJjOnMcDXu = len(tjIyR9ML3FVQuzmsn7h)
	sLYp6gD8wbEejm(L96HvDd3sfBiCSRT,euK4mQzpdF6fay,jeS4FEdVxGPhtakofC1yzm,234,TvJjOnMcDXu,RgXOq491d8il03VuzDLnHjxCy)
	return
def WbjYo9ZVxOtnIyQ0wCRkM(OijVK5A01fPTr4):
	tBq8fTGUWJY9zvbgXD0EAloPO('link',OijVK5A01fPTr4+'هذه القائمة إما فارغة أو غير موجودة','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('link',OijVK5A01fPTr4+'أو الخدمة غير موجودة في اشتراكك','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('link',OijVK5A01fPTr4+'أو رابط IPTVـ الذي أنت أضفته غير صحيح','',9999)
	return
def ddvQlFmprDb(L96HvDd3sfBiCSRT,jeS4FEdVxGPhtakofC1yzm,RgXOq491d8il03VuzDLnHjxCy,euK4mQzpdF6fay,TdfYz2Sk371p5ijoW9='',yt3K6SfQFkPNlIiWbjOCJHDh5Vpr=True):
	if not euK4mQzpdF6fay: euK4mQzpdF6fay = '1'
	OijVK5A01fPTr4 = E6M5YUL1m4a0JDVtwcdzqovGR
	if not RwN5lZjvPsLCW7gz9c0ab1x(L96HvDd3sfBiCSRT,yt3K6SfQFkPNlIiWbjOCJHDh5Vpr): return False
	if '__SERIES__' in RgXOq491d8il03VuzDLnHjxCy: W7ULMsxCNGBa,G5Gk4CxWcE1ajMqpN8XV7oLhu = RgXOq491d8il03VuzDLnHjxCy.split('__SERIES__')
	else: W7ULMsxCNGBa,G5Gk4CxWcE1ajMqpN8XV7oLhu = RgXOq491d8il03VuzDLnHjxCy,''
	Mm3aBo2VsXjZ4QD = GT29iAgzfL8kt63(L96HvDd3sfBiCSRT,jeS4FEdVxGPhtakofC1yzm)
	Zg2f4qCtQ03iKUoO9v6w = vsmQSl1ZDENy69BXJhWYF(Mm3aBo2VsXjZ4QD,'list',jeS4FEdVxGPhtakofC1yzm,'__GROUPS__')
	if not Zg2f4qCtQ03iKUoO9v6w: return False
	mXbIRFShuEPGV8Mie = []
	for U7j9Sy3I4rcVE1XZ,aPjqOy9703c4voXh1Dz65mMLRZf in Zg2f4qCtQ03iKUoO9v6w:
		if TdfYz2Sk371p5ijoW9:
			if '__SERIES__' in U7j9Sy3I4rcVE1XZ: OijVK5A01fPTr4 = 'SERIES'
			elif '!!__UNKNOWN__!!' in U7j9Sy3I4rcVE1XZ: OijVK5A01fPTr4 = 'UNKNOWN'
			elif 'LIVE' in jeS4FEdVxGPhtakofC1yzm: OijVK5A01fPTr4 = 'LIVE'
			else: OijVK5A01fPTr4 = 'VIDEOS'
			OijVK5A01fPTr4 = ',[COLOR FFC89008]'+OijVK5A01fPTr4+': [/COLOR]'
		if '__SERIES__' in U7j9Sy3I4rcVE1XZ: xXFmVQCIfTz78iyOq3Y59PvSDM,MuSZ0xnLjsmYcd9FPCJ = U7j9Sy3I4rcVE1XZ.split('__SERIES__')
		else: xXFmVQCIfTz78iyOq3Y59PvSDM,MuSZ0xnLjsmYcd9FPCJ = U7j9Sy3I4rcVE1XZ,''
		if not RgXOq491d8il03VuzDLnHjxCy:
			if xXFmVQCIfTz78iyOq3Y59PvSDM in mXbIRFShuEPGV8Mie: continue
			mXbIRFShuEPGV8Mie.append(xXFmVQCIfTz78iyOq3Y59PvSDM)
			if 'RANDOM' in TdfYz2Sk371p5ijoW9: tBq8fTGUWJY9zvbgXD0EAloPO('folder',OijVK5A01fPTr4+xXFmVQCIfTz78iyOq3Y59PvSDM,jeS4FEdVxGPhtakofC1yzm,167,'','1',U7j9Sy3I4rcVE1XZ,'',{'folder':L96HvDd3sfBiCSRT})
			elif '__SERIES__' in U7j9Sy3I4rcVE1XZ: tBq8fTGUWJY9zvbgXD0EAloPO('folder',OijVK5A01fPTr4+xXFmVQCIfTz78iyOq3Y59PvSDM,jeS4FEdVxGPhtakofC1yzm,233,'','1',U7j9Sy3I4rcVE1XZ,'',{'folder':L96HvDd3sfBiCSRT})
			else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',OijVK5A01fPTr4+xXFmVQCIfTz78iyOq3Y59PvSDM,jeS4FEdVxGPhtakofC1yzm,234,'','1',U7j9Sy3I4rcVE1XZ,'',{'folder':L96HvDd3sfBiCSRT})
		elif '__SERIES__' in U7j9Sy3I4rcVE1XZ and xXFmVQCIfTz78iyOq3Y59PvSDM==W7ULMsxCNGBa:
			if MuSZ0xnLjsmYcd9FPCJ in mXbIRFShuEPGV8Mie: continue
			mXbIRFShuEPGV8Mie.append(MuSZ0xnLjsmYcd9FPCJ)
			if 'RANDOM' in TdfYz2Sk371p5ijoW9: tBq8fTGUWJY9zvbgXD0EAloPO('folder',OijVK5A01fPTr4+MuSZ0xnLjsmYcd9FPCJ,jeS4FEdVxGPhtakofC1yzm,167,'','1',U7j9Sy3I4rcVE1XZ,'',{'folder':L96HvDd3sfBiCSRT})
			else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',OijVK5A01fPTr4+MuSZ0xnLjsmYcd9FPCJ,jeS4FEdVxGPhtakofC1yzm,234,aPjqOy9703c4voXh1Dz65mMLRZf,'1',U7j9Sy3I4rcVE1XZ,'',{'folder':L96HvDd3sfBiCSRT})
	muPDGHvJwFieQYCW62bB[:] = sorted(muPDGHvJwFieQYCW62bB,reverse=False,key=lambda VFuy0zn89rNPLdt: VFuy0zn89rNPLdt[1].lower())
	if not TdfYz2Sk371p5ijoW9:
		fBD10G45rxzjQwdh7C = int(euK4mQzpdF6fay)*100
		DknNRL79Cr = fBD10G45rxzjQwdh7C-100
		TvJjOnMcDXu = len(KzMJGACDTt3VujnRZiSNI4ar)
		KzMJGACDTt3VujnRZiSNI4ar[:] = muPDGHvJwFieQYCW62bB[DknNRL79Cr:fBD10G45rxzjQwdh7C]
		sLYp6gD8wbEejm(L96HvDd3sfBiCSRT,euK4mQzpdF6fay,jeS4FEdVxGPhtakofC1yzm,233,TvJjOnMcDXu,RgXOq491d8il03VuzDLnHjxCy)
	return True
def bjmMGta9AnVxoYQRi4(L96HvDd3sfBiCSRT,d7on6sKDqkNY,vxRQy9zZuwoHLTYkbqG):
	if not RwN5lZjvPsLCW7gz9c0ab1x(L96HvDd3sfBiCSRT,True): return
	UZbaV6FlwAM0uNvdS1mcIPypC = vrpfxzlAKcTZiUaRgudtsmOPEL(L96HvDd3sfBiCSRT)
	ebPA68iy34NgOzSCT9umHrIoFqQ = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.iptv.timestamp_'+L96HvDd3sfBiCSRT)
	if not ebPA68iy34NgOzSCT9umHrIoFqQ or eOYicX68ruMjpN0dKtWP5QTSE-int(ebPA68iy34NgOzSCT9umHrIoFqQ)>24*X6q8xOh3QUvB5D1dZJnmRC9TzauGrL:
		agX9nom53W,b9j4niYADepUc28WXuSJV,hQkH6GzJPnm0fSNlKLyiwCrR43Fa5 = IIyUEG1AogvkF0zM(L96HvDd3sfBiCSRT,False)
		if not agX9nom53W: return
	PQ5AFaC3yvs0MrTIc = int(if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.iptv.timediff_'+L96HvDd3sfBiCSRT))
	t3tPaSeRm48gpYcl = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.iptv.server_'+L96HvDd3sfBiCSRT)
	szmuUXHkrIyBZY = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.iptv.username_'+L96HvDd3sfBiCSRT)
	KKGXLutpaj9yWwBJ4Tmgfq2ShYlZDO = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.iptv.password_'+L96HvDd3sfBiCSRT)
	QnVEyT0XDSxjIculad = d7on6sKDqkNY.split('/')
	SmAEDTQCldoJsf672kX = QnVEyT0XDSxjIculad[-1].replace('.ts','').replace('.m3u8','')
	if vxRQy9zZuwoHLTYkbqG=='SHORT_EPG': rXS9kQ76bJFxh0s2aWdtgZ1LKMy = 'get_short_epg'
	else: rXS9kQ76bJFxh0s2aWdtgZ1LKMy = 'get_simple_data_table'
	UBc3wC6Sx0AlO,f9MB4sy57lnC0Hrc,t3tPaSeRm48gpYcl,szmuUXHkrIyBZY,KKGXLutpaj9yWwBJ4Tmgfq2ShYlZDO = H4HNRVUbi5(L96HvDd3sfBiCSRT)
	if not szmuUXHkrIyBZY: return
	ykBj2TLpeORdCli46 = UBc3wC6Sx0AlO+'&action='+rXS9kQ76bJFxh0s2aWdtgZ1LKMy+'&stream_id='+SmAEDTQCldoJsf672kX
	kDQZoFnLUTYc8G45u21ye = lMJtxR8d2sk(MMLimtJ8xTFAq9Z012nroaju3de,ykBj2TLpeORdCli46,'',UZbaV6FlwAM0uNvdS1mcIPypC,'','IPTV-EPG_ITEMS-2nd')
	mt6MX5ignHDlbKL34Pq = GVQAnvYCT3dS('dict',kDQZoFnLUTYc8G45u21ye)
	TP7RvViKHc9gBts3rSCFl2eZMf = mt6MX5ignHDlbKL34Pq['epg_listings']
	KkuplQmLYc = []
	if vxRQy9zZuwoHLTYkbqG in ['ARCHIVED','TIMESHIFT']:
		for d4Re9mNuVo2 in TP7RvViKHc9gBts3rSCFl2eZMf:
			if d4Re9mNuVo2['has_archive']==1:
				KkuplQmLYc.append(d4Re9mNuVo2)
				if vxRQy9zZuwoHLTYkbqG in ['TIMESHIFT']: break
		if not KkuplQmLYc: return
		tBq8fTGUWJY9zvbgXD0EAloPO('link',E6M5YUL1m4a0JDVtwcdzqovGR+'[COLOR FFC89008]الملفات الأولي بهذه القائمة قد لا تعمل[/COLOR]','',9999)
		if vxRQy9zZuwoHLTYkbqG in ['TIMESHIFT']:
			DqUSVyHkC2vm7or = 2
			sLTlOKV6Wh4zAfmUiv0PYa8 = DqUSVyHkC2vm7or*X6q8xOh3QUvB5D1dZJnmRC9TzauGrL
			KkuplQmLYc = []
			mGtqFbWje0fXa9SAV5gl6dycnNR = int(int(d4Re9mNuVo2['start_timestamp'])/sLTlOKV6Wh4zAfmUiv0PYa8)*sLTlOKV6Wh4zAfmUiv0PYa8
			D6ZI4TRNik2GE5Ppj0l1wn9K87F = eOYicX68ruMjpN0dKtWP5QTSE+sLTlOKV6Wh4zAfmUiv0PYa8
			ue34jlS2wg1ac = int((D6ZI4TRNik2GE5Ppj0l1wn9K87F-mGtqFbWje0fXa9SAV5gl6dycnNR)/X6q8xOh3QUvB5D1dZJnmRC9TzauGrL)
			for R4oBgUCylG6aZKI5DxncdN1bLqTHSw in range(ue34jlS2wg1ac):
				if R4oBgUCylG6aZKI5DxncdN1bLqTHSw>=6:
					if R4oBgUCylG6aZKI5DxncdN1bLqTHSw%DqUSVyHkC2vm7or!=0: continue
					Oluz7EJeXZC = sLTlOKV6Wh4zAfmUiv0PYa8
				else: Oluz7EJeXZC = sLTlOKV6Wh4zAfmUiv0PYa8//2
				bv890HODWsFj6hI2zN = mGtqFbWje0fXa9SAV5gl6dycnNR+R4oBgUCylG6aZKI5DxncdN1bLqTHSw*X6q8xOh3QUvB5D1dZJnmRC9TzauGrL
				d4Re9mNuVo2 = {}
				d4Re9mNuVo2['title'] = ''
				L4ojbVRaXY1 = w6vebiEZtpCjJcILP8Skx5rHn.localtime(bv890HODWsFj6hI2zN-PQ5AFaC3yvs0MrTIc-X6q8xOh3QUvB5D1dZJnmRC9TzauGrL)
				d4Re9mNuVo2['start'] = w6vebiEZtpCjJcILP8Skx5rHn.strftime('%Y.%m.%d %H:%M:%S',L4ojbVRaXY1)
				d4Re9mNuVo2['start_timestamp'] = str(bv890HODWsFj6hI2zN)
				d4Re9mNuVo2['stop_timestamp'] = str(bv890HODWsFj6hI2zN+Oluz7EJeXZC)
				KkuplQmLYc.append(d4Re9mNuVo2)
	elif vxRQy9zZuwoHLTYkbqG in ['SHORT_EPG','FULL_EPG']: KkuplQmLYc = TP7RvViKHc9gBts3rSCFl2eZMf
	if vxRQy9zZuwoHLTYkbqG=='FULL_EPG' and len(KkuplQmLYc)>0:
		tBq8fTGUWJY9zvbgXD0EAloPO('link',E6M5YUL1m4a0JDVtwcdzqovGR+'[COLOR FFC89008]هذه قائمة برامج القنوات (جدول فقط)ـ[/COLOR]','',9999)
	ZeQVltu6KhajRf9 = []
	aPjqOy9703c4voXh1Dz65mMLRZf = oos8ymFi9CN2z1jXcR.getInfoLabel('ListItem.Icon')
	for d4Re9mNuVo2 in KkuplQmLYc:
		NqFXMA4Rr9cWzm = SSNcdhMguvEw0RY.b64decode(d4Re9mNuVo2['title'])
		if wvkR1es6d0SrjxKt5FZTMUWz7a: NqFXMA4Rr9cWzm = NqFXMA4Rr9cWzm.decode('utf8')
		bv890HODWsFj6hI2zN = int(d4Re9mNuVo2['start_timestamp'])
		pYVjXGlHMdZB = int(d4Re9mNuVo2['stop_timestamp'])
		t8rF3qCbMW = str(int((pYVjXGlHMdZB-bv890HODWsFj6hI2zN+59)/60))
		wpZQXz3qiOa7LT2gJNfjGc4nk8Se = d4Re9mNuVo2['start'].replace(' ',':')
		L4ojbVRaXY1 = w6vebiEZtpCjJcILP8Skx5rHn.localtime(bv890HODWsFj6hI2zN-X6q8xOh3QUvB5D1dZJnmRC9TzauGrL)
		FFdtSr7cLWjiP8EVw0aJz2b = w6vebiEZtpCjJcILP8Skx5rHn.strftime('%H:%M',L4ojbVRaXY1)
		sEVwBOPk9xe2M = w6vebiEZtpCjJcILP8Skx5rHn.strftime('%a',L4ojbVRaXY1)
		if vxRQy9zZuwoHLTYkbqG=='SHORT_EPG': NqFXMA4Rr9cWzm = '[COLOR FFFFFF00]'+FFdtSr7cLWjiP8EVw0aJz2b+' ـ '+NqFXMA4Rr9cWzm+'[/COLOR]'
		elif vxRQy9zZuwoHLTYkbqG=='TIMESHIFT': NqFXMA4Rr9cWzm = sEVwBOPk9xe2M+' '+FFdtSr7cLWjiP8EVw0aJz2b+' ('+t8rF3qCbMW+'min)'
		else: NqFXMA4Rr9cWzm = sEVwBOPk9xe2M+' '+FFdtSr7cLWjiP8EVw0aJz2b+' ('+t8rF3qCbMW+'min)   '+NqFXMA4Rr9cWzm+' ـ'
		if vxRQy9zZuwoHLTYkbqG in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			BMnNC4FZ3pLEDI0xj7GoR8AezaQ5 = t3tPaSeRm48gpYcl+'/timeshift/'+szmuUXHkrIyBZY+'/'+KKGXLutpaj9yWwBJ4Tmgfq2ShYlZDO+'/'+t8rF3qCbMW+'/'+wpZQXz3qiOa7LT2gJNfjGc4nk8Se+'/'+SmAEDTQCldoJsf672kX+'.m3u8'
			if vxRQy9zZuwoHLTYkbqG=='FULL_EPG': tBq8fTGUWJY9zvbgXD0EAloPO('link',E6M5YUL1m4a0JDVtwcdzqovGR+NqFXMA4Rr9cWzm,BMnNC4FZ3pLEDI0xj7GoR8AezaQ5,9999,aPjqOy9703c4voXh1Dz65mMLRZf,'','','',{'folder':L96HvDd3sfBiCSRT})
			else: tBq8fTGUWJY9zvbgXD0EAloPO('video',E6M5YUL1m4a0JDVtwcdzqovGR+NqFXMA4Rr9cWzm,BMnNC4FZ3pLEDI0xj7GoR8AezaQ5,235,aPjqOy9703c4voXh1Dz65mMLRZf,'','','',{'folder':L96HvDd3sfBiCSRT})
		ZeQVltu6KhajRf9.append(NqFXMA4Rr9cWzm)
	if vxRQy9zZuwoHLTYkbqG=='SHORT_EPG' and ZeQVltu6KhajRf9: CyrJ6N7xOh5qoHmUgRlPATdvYztVL = QjswkAMfpr9602HKBZ(ZeQVltu6KhajRf9)
	return ZeQVltu6KhajRf9
def RRmWyG6qhNS7TK8BYwgiCjsU(L96HvDd3sfBiCSRT):
	if not RwN5lZjvPsLCW7gz9c0ab1x(L96HvDd3sfBiCSRT,True): return
	t3tPaSeRm48gpYcl,n8Ld39F0qykGwgpDuJ2j,nN7oTAGf2FQycbY1tS9Ux = '',0,0
	agX9nom53W,b9j4niYADepUc28WXuSJV,hQkH6GzJPnm0fSNlKLyiwCrR43Fa5 = IIyUEG1AogvkF0zM(L96HvDd3sfBiCSRT,False)
	if agX9nom53W:
		tyKHm7O3xljrM = RePNIXDAy4GifxQqKg(b9j4niYADepUc28WXuSJV)
		n8Ld39F0qykGwgpDuJ2j = WKFu3v5hQIdXNp1Bg0ZxRLk2G(tyKHm7O3xljrM[0],int(hQkH6GzJPnm0fSNlKLyiwCrR43Fa5))
		Mm3aBo2VsXjZ4QD = GT29iAgzfL8kt63(L96HvDd3sfBiCSRT,'LIVE_GROUPED')
		OkInE9XxvNzaWM = vsmQSl1ZDENy69BXJhWYF(Mm3aBo2VsXjZ4QD,'list','LIVE_GROUPED')
		tjIyR9ML3FVQuzmsn7h = vsmQSl1ZDENy69BXJhWYF(Mm3aBo2VsXjZ4QD,'list','LIVE_GROUPED',OkInE9XxvNzaWM[1])
		d7on6sKDqkNY = tjIyR9ML3FVQuzmsn7h[0][2]
		VkfxrYuaPTU9M5F7zp = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('://(.*?)/',d7on6sKDqkNY,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		VkfxrYuaPTU9M5F7zp = VkfxrYuaPTU9M5F7zp[0]
		if ':' in VkfxrYuaPTU9M5F7zp: hAupr1IfMY2dZ,c7k6WiRHlv0e2Ng58FKs9qmBLEST3M = VkfxrYuaPTU9M5F7zp.split(':')
		else: hAupr1IfMY2dZ,c7k6WiRHlv0e2Ng58FKs9qmBLEST3M = VkfxrYuaPTU9M5F7zp,'80'
		cgKms5NFZa3tuV7rPO20ynf = RePNIXDAy4GifxQqKg(hAupr1IfMY2dZ)
		nN7oTAGf2FQycbY1tS9Ux = WKFu3v5hQIdXNp1Bg0ZxRLk2G(cgKms5NFZa3tuV7rPO20ynf[0],int(c7k6WiRHlv0e2Ng58FKs9qmBLEST3M))
	if n8Ld39F0qykGwgpDuJ2j and nN7oTAGf2FQycbY1tS9Ux:
		maCNIYkc0HOiEGpL3g = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		maCNIYkc0HOiEGpL3g += '\n\n'+'وقت ضائع في السيرفر الأصلي'+'\n'+str(int(nN7oTAGf2FQycbY1tS9Ux*1000))+' ملي ثانية'
		maCNIYkc0HOiEGpL3g += '\n\n'+'وقت ضائع في السيرفر البديل'+'\n'+str(int(n8Ld39F0qykGwgpDuJ2j*1000))+' ملي ثانية'
		Bh7kXZnFibK8x = eINt5FlUT0oO('center','السيرفر الأصلي','السيرفر الأسرع','رسالة من المبرمج',maCNIYkc0HOiEGpL3g)
		if Bh7kXZnFibK8x==1 and n8Ld39F0qykGwgpDuJ2j<nN7oTAGf2FQycbY1tS9Ux: t3tPaSeRm48gpYcl = b9j4niYADepUc28WXuSJV+':'+hQkH6GzJPnm0fSNlKLyiwCrR43Fa5
	else: tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','البرنامج لم يجد السيرفر البديل')
	if2qpOxlZd8MBGeo5uNIyLEsz.setSetting('av.iptv.server_'+L96HvDd3sfBiCSRT,t3tPaSeRm48gpYcl)
	return
def dlropqS0vO9K7W4z(L96HvDd3sfBiCSRT,d7on6sKDqkNY,s8Oimqou2fZD):
	EhqOy4X5jB = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.iptv.useragent_'+L96HvDd3sfBiCSRT)
	YG2zapHhkE1r4oIdtCm = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.iptv.referer_'+L96HvDd3sfBiCSRT)
	if EhqOy4X5jB or YG2zapHhkE1r4oIdtCm:
		d7on6sKDqkNY += '|'
		if EhqOy4X5jB: d7on6sKDqkNY += '&User-Agent='+EhqOy4X5jB
		if YG2zapHhkE1r4oIdtCm: d7on6sKDqkNY += '&Referer='+YG2zapHhkE1r4oIdtCm
		d7on6sKDqkNY = d7on6sKDqkNY.replace('|&','|')
	lEBVNdtj9WYfOmL30u8DKJCeGSI1nv = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.iptv.server_'+L96HvDd3sfBiCSRT)
	if lEBVNdtj9WYfOmL30u8DKJCeGSI1nv:
		wosZ6pOT1xNkX2G49U = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('://(.*?)/',d7on6sKDqkNY,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		d7on6sKDqkNY = d7on6sKDqkNY.replace(wosZ6pOT1xNkX2G49U[0],lEBVNdtj9WYfOmL30u8DKJCeGSI1nv)
	pSAuLjYqhgc9brWFKs7Pa4J(d7on6sKDqkNY,PCY2LJwTgIfan,s8Oimqou2fZD)
	return
def ooXTiKU1v7(L96HvDd3sfBiCSRT):
	tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـUser-Agent خاص')
	EhqOy4X5jB = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.iptv.useragent_'+L96HvDd3sfBiCSRT)
	C2WAgE7hQVb = eINt5FlUT0oO('center','استخدام الأصلي','تعديل القديم',EhqOy4X5jB,'هذا هو ـUser-Agent المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if C2WAgE7hQVb==1: EhqOy4X5jB = UIf35nZEj1wylmq('أكتب ـIPTV User-Agent جديد',EhqOy4X5jB,True)
	else: EhqOy4X5jB = 'Unknown'
	if EhqOy4X5jB==' ':
		tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	C2WAgE7hQVb = eINt5FlUT0oO('center','','',EhqOy4X5jB,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if C2WAgE7hQVb!=1:
		tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','تم الإلغاء')
		return
	if2qpOxlZd8MBGeo5uNIyLEsz.setSetting('av.iptv.useragent_'+L96HvDd3sfBiCSRT,EhqOy4X5jB)
	NBFq8XbcxOSPCAG0UYIgVkr2zutQH(L96HvDd3sfBiCSRT)
	return
def FyTSX7Lb2cvirxWEzwZkugNJjo(L96HvDd3sfBiCSRT):
	tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـReferer خاص')
	YG2zapHhkE1r4oIdtCm = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.iptv.referer_'+L96HvDd3sfBiCSRT)
	C2WAgE7hQVb = eINt5FlUT0oO('center','استخدام الأصلي','تعديل القديم',YG2zapHhkE1r4oIdtCm,'هذا هو ـReferer المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if C2WAgE7hQVb==1: YG2zapHhkE1r4oIdtCm = UIf35nZEj1wylmq('أكتب ـIPTV Referer جديد',YG2zapHhkE1r4oIdtCm,True)
	else: YG2zapHhkE1r4oIdtCm = ''
	if YG2zapHhkE1r4oIdtCm==' ':
		tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	C2WAgE7hQVb = eINt5FlUT0oO('center','','',YG2zapHhkE1r4oIdtCm,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if C2WAgE7hQVb!=1:
		tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','تم الإلغاء')
		return
	if2qpOxlZd8MBGeo5uNIyLEsz.setSetting('av.iptv.referer_'+L96HvDd3sfBiCSRT,YG2zapHhkE1r4oIdtCm)
	NBFq8XbcxOSPCAG0UYIgVkr2zutQH(L96HvDd3sfBiCSRT)
	return
def H4HNRVUbi5(L96HvDd3sfBiCSRT,KYSPcEUGnAyiewqVas=''):
	if not KYSPcEUGnAyiewqVas: KYSPcEUGnAyiewqVas = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.iptv.url_'+L96HvDd3sfBiCSRT)
	t3tPaSeRm48gpYcl = SLMTm6RQ34ic7v5s9rBG(KYSPcEUGnAyiewqVas,'url')
	szmuUXHkrIyBZY = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('username=(.*?)&',KYSPcEUGnAyiewqVas+'&',E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	KKGXLutpaj9yWwBJ4Tmgfq2ShYlZDO = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('password=(.*?)&',KYSPcEUGnAyiewqVas+'&',E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not szmuUXHkrIyBZY or not KKGXLutpaj9yWwBJ4Tmgfq2ShYlZDO:
		tehb3k5a2PufGOdBIUw8j('','','فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		return '','','','',''
	szmuUXHkrIyBZY = szmuUXHkrIyBZY[0]
	KKGXLutpaj9yWwBJ4Tmgfq2ShYlZDO = KKGXLutpaj9yWwBJ4Tmgfq2ShYlZDO[0]
	UBc3wC6Sx0AlO = t3tPaSeRm48gpYcl+'/player_api.php?username='+szmuUXHkrIyBZY+'&password='+KKGXLutpaj9yWwBJ4Tmgfq2ShYlZDO
	f9MB4sy57lnC0Hrc = t3tPaSeRm48gpYcl+'/get.php?username='+szmuUXHkrIyBZY+'&password='+KKGXLutpaj9yWwBJ4Tmgfq2ShYlZDO+'&type=m3u_plus'
	return UBc3wC6Sx0AlO,f9MB4sy57lnC0Hrc,t3tPaSeRm48gpYcl,szmuUXHkrIyBZY,KKGXLutpaj9yWwBJ4Tmgfq2ShYlZDO
def ay73wUqOlnbI9tEVkgD6LHiX(L96HvDd3sfBiCSRT,TJ3HVj9LcnOKf5E=''):
	FeTMB4Uty3AY5zuCvo0L2mh69dlV8 = TJ3HVj9LcnOKf5E.replace('/','_').replace(':','_').replace('.','_')
	FeTMB4Uty3AY5zuCvo0L2mh69dlV8 = FeTMB4Uty3AY5zuCvo0L2mh69dlV8.replace('?','_').replace('=','_').replace('&','_')
	FeTMB4Uty3AY5zuCvo0L2mh69dlV8 = K3hFytImeYMkJBC.path.join(llrbyaFHOt9e,FeTMB4Uty3AY5zuCvo0L2mh69dlV8).strip('.m3u')+'.m3u'
	return FeTMB4Uty3AY5zuCvo0L2mh69dlV8
def Hv5aEwmrNiyA8WpG4l(L96HvDd3sfBiCSRT):
	XcyWGkvFgse2w5PVD = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.iptv.url_'+L96HvDd3sfBiCSRT)
	jzgZaIlniWEQeN0xYTPRBm8 = True
	if XcyWGkvFgse2w5PVD:
		C2WAgE7hQVb = m5NUYqBzGynIOeAg8('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:','[COLOR FFC89008]'+XcyWGkvFgse2w5PVD+'[/COLOR]'+'\n\n هذا هو رابط ـIPTV المسجل في البرنامج ... هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if C2WAgE7hQVb==-1: return
		elif C2WAgE7hQVb==0: XcyWGkvFgse2w5PVD = ''
		elif C2WAgE7hQVb==2:
			C2WAgE7hQVb = eINt5FlUT0oO('center','','','رسالة من المبرمج','هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if C2WAgE7hQVb in [-1,0]: return
			tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','تم مسح الرابط')
			jzgZaIlniWEQeN0xYTPRBm8 = False
			BvMKobRzpeZaLUrT5D2hOqYiCHVJj = ''
	if jzgZaIlniWEQeN0xYTPRBm8:
		BvMKobRzpeZaLUrT5D2hOqYiCHVJj = UIf35nZEj1wylmq('اكتب رابط ـIPTV كاملا',XcyWGkvFgse2w5PVD)
		BvMKobRzpeZaLUrT5D2hOqYiCHVJj = BvMKobRzpeZaLUrT5D2hOqYiCHVJj.strip(' ')
		if not BvMKobRzpeZaLUrT5D2hOqYiCHVJj:
			C2WAgE7hQVb = eINt5FlUT0oO('center','','','رسالة من المبرمج','لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if C2WAgE7hQVb in [-1,0]: return
			tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','تم مسح الرابط')
	else:
		UBc3wC6Sx0AlO,f9MB4sy57lnC0Hrc,t3tPaSeRm48gpYcl,szmuUXHkrIyBZY,KKGXLutpaj9yWwBJ4Tmgfq2ShYlZDO = H4HNRVUbi5(L96HvDd3sfBiCSRT,BvMKobRzpeZaLUrT5D2hOqYiCHVJj)
		if not szmuUXHkrIyBZY: return
		maCNIYkc0HOiEGpL3g = 'هذه المعلومات تم أخذها من رابط ـIPTV الذي انت كتبته . هل تريد استخدامها ؟!\n'
		maCNIYkc0HOiEGpL3g += '\n[COLOR FFFFFF00]'+t3tPaSeRm48gpYcl+'[/COLOR]عنوان السيرفر: '
		maCNIYkc0HOiEGpL3g += '\n[COLOR FFFFFF00]'+szmuUXHkrIyBZY+'[/COLOR]اسم المستخدم: '
		maCNIYkc0HOiEGpL3g += '\n[COLOR FFFFFF00]'+KKGXLutpaj9yWwBJ4Tmgfq2ShYlZDO+'[/COLOR]كلمة السر: '
		C2WAgE7hQVb = eINt5FlUT0oO('right','','','الرابط الجديد هو:','[COLOR FFC89008]'+BvMKobRzpeZaLUrT5D2hOqYiCHVJj+'[/COLOR]'+'\n\n'+maCNIYkc0HOiEGpL3g)
		if C2WAgE7hQVb!=1:
			tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','تم الإلغاء')
			return
	if2qpOxlZd8MBGeo5uNIyLEsz.setSetting('av.iptv.url_'+L96HvDd3sfBiCSRT,BvMKobRzpeZaLUrT5D2hOqYiCHVJj)
	if2qpOxlZd8MBGeo5uNIyLEsz.setSetting('av.iptv.timestamp_'+L96HvDd3sfBiCSRT,'')
	if2qpOxlZd8MBGeo5uNIyLEsz.setSetting('av.iptv.timediff_'+L96HvDd3sfBiCSRT,'')
	EhqOy4X5jB = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.iptv.useragent_'+L96HvDd3sfBiCSRT)
	if not EhqOy4X5jB: if2qpOxlZd8MBGeo5uNIyLEsz.setSetting('av.iptv.useragent_'+L96HvDd3sfBiCSRT,'Unknown')
	OdqM6PpXRumkH = eINt5FlUT0oO('center','','','',BvMKobRzpeZaLUrT5D2hOqYiCHVJj+'\n\nتم تغير رابط اشتراك ـIPTV إلى هذا الرابط الجديد ... هل تريد فحص هذا الرابط الآن ؟')
	if OdqM6PpXRumkH==1: agX9nom53W,b9j4niYADepUc28WXuSJV,hQkH6GzJPnm0fSNlKLyiwCrR43Fa5 = IIyUEG1AogvkF0zM(L96HvDd3sfBiCSRT,True)
	NBFq8XbcxOSPCAG0UYIgVkr2zutQH(L96HvDd3sfBiCSRT)
	return
def gYnmDNSZbQXHResPzFG5kq4(HCFix1cLXj9R6e87BqZ,ggKSkjFiJZYsp5R90AEdbxoB,ILWfPt8kBpjYK56iDhluSU,PovBQZpbSea,NRTxwWEFc6SzytV0G3vMb2YOsjl,p4kmOV7v1QdLMoKASIq9gUhxG20,f9MB4sy57lnC0Hrc):
	tjIyR9ML3FVQuzmsn7h,ziDAZdtxKw = [],[]
	LPOg0zXbnVqNHMfjYrpts1RDm9 = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for gH6oMIGUWO1sA4aYBbfChRw5yN in HCFix1cLXj9R6e87BqZ:
		if p4kmOV7v1QdLMoKASIq9gUhxG20%473==0:
			aayBzF9OcXn1kYqRhDNm7gTZ(PovBQZpbSea,40+int(10*p4kmOV7v1QdLMoKASIq9gUhxG20/NRTxwWEFc6SzytV0G3vMb2YOsjl),'قراءة الفيديوهات','الفيديو رقم:-',str(p4kmOV7v1QdLMoKASIq9gUhxG20)+' / '+str(NRTxwWEFc6SzytV0G3vMb2YOsjl))
			if PovBQZpbSea.iscanceled():
				PovBQZpbSea.close()
				return None,None,None
		d7on6sKDqkNY = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('^(.*?)\n+((http|https|rtmp).*?)$',gH6oMIGUWO1sA4aYBbfChRw5yN,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if d7on6sKDqkNY:
			gH6oMIGUWO1sA4aYBbfChRw5yN,d7on6sKDqkNY,HXj9St07uNI6JBACMxcPqsvO8KVw = d7on6sKDqkNY[0]
			d7on6sKDqkNY = d7on6sKDqkNY.replace('\n','')
			gH6oMIGUWO1sA4aYBbfChRw5yN = gH6oMIGUWO1sA4aYBbfChRw5yN.replace('\n','')
		else:
			ziDAZdtxKw.append({'line':gH6oMIGUWO1sA4aYBbfChRw5yN})
			continue
		HC6rndQ4wxNzUc,tiIc9lDHrUd,U7j9Sy3I4rcVE1XZ,NqFXMA4Rr9cWzm,s8Oimqou2fZD,SSHI2cf1JuAVTgWEl34jkNODPynhiG = {},'','','','',False
		try:
			gH6oMIGUWO1sA4aYBbfChRw5yN,NqFXMA4Rr9cWzm = gH6oMIGUWO1sA4aYBbfChRw5yN.rsplit('",',1)
			gH6oMIGUWO1sA4aYBbfChRw5yN = gH6oMIGUWO1sA4aYBbfChRw5yN+'"'
		except:
			try: gH6oMIGUWO1sA4aYBbfChRw5yN,NqFXMA4Rr9cWzm = gH6oMIGUWO1sA4aYBbfChRw5yN.rsplit('1,',1)
			except: NqFXMA4Rr9cWzm = ''
		HC6rndQ4wxNzUc['url'] = d7on6sKDqkNY
		m8T6Iy1z5GRHwAPESJr0tMX9OQlUhF = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(' (.*?)="(.*?)"',gH6oMIGUWO1sA4aYBbfChRw5yN,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for VFuy0zn89rNPLdt,VKuD93XbUeArRdyjgzPt in m8T6Iy1z5GRHwAPESJr0tMX9OQlUhF:
			VFuy0zn89rNPLdt = VFuy0zn89rNPLdt.replace('"','').strip(' ')
			HC6rndQ4wxNzUc[VFuy0zn89rNPLdt] = VKuD93XbUeArRdyjgzPt.strip(' ')
		Mi2REH5Qb89GyIZ = list(HC6rndQ4wxNzUc.keys())
		if not NqFXMA4Rr9cWzm:
			if 'name' in Mi2REH5Qb89GyIZ and HC6rndQ4wxNzUc['name']: NqFXMA4Rr9cWzm = HC6rndQ4wxNzUc['name']
		HC6rndQ4wxNzUc['title'] = NqFXMA4Rr9cWzm.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'logo' in Mi2REH5Qb89GyIZ:
			HC6rndQ4wxNzUc['img'] = HC6rndQ4wxNzUc['logo']
			del HC6rndQ4wxNzUc['logo']
		else: HC6rndQ4wxNzUc['img'] = ''
		if 'group' in Mi2REH5Qb89GyIZ and HC6rndQ4wxNzUc['group']: U7j9Sy3I4rcVE1XZ = HC6rndQ4wxNzUc['group']
		if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in d7on6sKDqkNY.lower() for hht0cpXxWw2OzFS1jnUGebkJLBd85 in LPOg0zXbnVqNHMfjYrpts1RDm9):
			SSHI2cf1JuAVTgWEl34jkNODPynhiG = True if 'm3u' not in d7on6sKDqkNY else False
		if SSHI2cf1JuAVTgWEl34jkNODPynhiG or '__SERIES__' in U7j9Sy3I4rcVE1XZ or '__MOVIES__' in U7j9Sy3I4rcVE1XZ:
			s8Oimqou2fZD = 'VOD'
			if '__SERIES__' in U7j9Sy3I4rcVE1XZ: s8Oimqou2fZD = s8Oimqou2fZD+'_SERIES'
			elif '__MOVIES__' in U7j9Sy3I4rcVE1XZ: s8Oimqou2fZD = s8Oimqou2fZD+'_MOVIES'
			else: s8Oimqou2fZD = s8Oimqou2fZD+'_UNKNOWN'
			U7j9Sy3I4rcVE1XZ = U7j9Sy3I4rcVE1XZ.replace('__SERIES__','').replace('__MOVIES__','')
		else:
			s8Oimqou2fZD = 'LIVE'
			if NqFXMA4Rr9cWzm in ggKSkjFiJZYsp5R90AEdbxoB: tiIc9lDHrUd = tiIc9lDHrUd+'_EPG'
			if NqFXMA4Rr9cWzm in ILWfPt8kBpjYK56iDhluSU: tiIc9lDHrUd = tiIc9lDHrUd+'_ARCHIVED'
			if not U7j9Sy3I4rcVE1XZ: s8Oimqou2fZD = s8Oimqou2fZD+'_UNKNOWN'
			else: s8Oimqou2fZD = s8Oimqou2fZD+tiIc9lDHrUd
		U7j9Sy3I4rcVE1XZ = U7j9Sy3I4rcVE1XZ.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'LIVE_UNKNOWN' in s8Oimqou2fZD: U7j9Sy3I4rcVE1XZ = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in s8Oimqou2fZD: U7j9Sy3I4rcVE1XZ = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in s8Oimqou2fZD:
			Ulud6JWDv4rnymESVg = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(.*?) [Ss]\d+ +[Ee]\d+',HC6rndQ4wxNzUc['title'],E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if Ulud6JWDv4rnymESVg: Ulud6JWDv4rnymESVg = Ulud6JWDv4rnymESVg[0]
			else: Ulud6JWDv4rnymESVg = '!!__UNKNOWN_SERIES__!!'
			U7j9Sy3I4rcVE1XZ = U7j9Sy3I4rcVE1XZ+'__SERIES__'+Ulud6JWDv4rnymESVg
		if 'id' in Mi2REH5Qb89GyIZ: del HC6rndQ4wxNzUc['id']
		if 'ID' in Mi2REH5Qb89GyIZ: del HC6rndQ4wxNzUc['ID']
		if 'name' in Mi2REH5Qb89GyIZ: del HC6rndQ4wxNzUc['name']
		NqFXMA4Rr9cWzm = HC6rndQ4wxNzUc['title']
		NqFXMA4Rr9cWzm = zKGXT5sJeRq(NqFXMA4Rr9cWzm)
		NqFXMA4Rr9cWzm = UlOPLcVJeqQgw(NqFXMA4Rr9cWzm)
		PPcKmIxajUOue16,U7j9Sy3I4rcVE1XZ = SSDb6UXEmOwiYjpuK0t8vL4V(U7j9Sy3I4rcVE1XZ)
		Bdvejubzikl4PyCY2Q6,NqFXMA4Rr9cWzm = SSDb6UXEmOwiYjpuK0t8vL4V(NqFXMA4Rr9cWzm)
		HC6rndQ4wxNzUc['type'] = s8Oimqou2fZD
		HC6rndQ4wxNzUc['context'] = tiIc9lDHrUd
		HC6rndQ4wxNzUc['group'] = U7j9Sy3I4rcVE1XZ.upper()
		HC6rndQ4wxNzUc['title'] = NqFXMA4Rr9cWzm.upper()
		HC6rndQ4wxNzUc['country'] = Bdvejubzikl4PyCY2Q6.upper()
		HC6rndQ4wxNzUc['language'] = PPcKmIxajUOue16.upper()
		tjIyR9ML3FVQuzmsn7h.append(HC6rndQ4wxNzUc)
		p4kmOV7v1QdLMoKASIq9gUhxG20 += 1
	return tjIyR9ML3FVQuzmsn7h,p4kmOV7v1QdLMoKASIq9gUhxG20,ziDAZdtxKw
def UlOPLcVJeqQgw(NqFXMA4Rr9cWzm):
	NqFXMA4Rr9cWzm = NqFXMA4Rr9cWzm.replace('  ',' ').replace('  ',' ').replace('  ',' ')
	NqFXMA4Rr9cWzm = NqFXMA4Rr9cWzm.replace('||','|').replace('___',':').replace('--','-')
	NqFXMA4Rr9cWzm = NqFXMA4Rr9cWzm.replace('[[','[').replace(']]',']')
	NqFXMA4Rr9cWzm = NqFXMA4Rr9cWzm.replace('((','(').replace('))',')')
	NqFXMA4Rr9cWzm = NqFXMA4Rr9cWzm.replace('<<','<').replace('>>','>')
	NqFXMA4Rr9cWzm = NqFXMA4Rr9cWzm.strip(' ')
	return NqFXMA4Rr9cWzm
def Cc4TANZ8OKV3S(YNxSgUEzuhyVPcidAeHw76Tv,PovBQZpbSea):
	V3vKlHO1rBN2W = {}
	for Lvi4A8JFMGf3bmI2odxlg5Tcq in mVgfp8N2qHKACYF74eRkJ5s9U: V3vKlHO1rBN2W[Lvi4A8JFMGf3bmI2odxlg5Tcq] = []
	NRTxwWEFc6SzytV0G3vMb2YOsjl = len(YNxSgUEzuhyVPcidAeHw76Tv)
	TTOixNreYJD9uId = str(NRTxwWEFc6SzytV0G3vMb2YOsjl)
	p4kmOV7v1QdLMoKASIq9gUhxG20 = 0
	ziDAZdtxKw = []
	for HC6rndQ4wxNzUc in YNxSgUEzuhyVPcidAeHw76Tv:
		if p4kmOV7v1QdLMoKASIq9gUhxG20%873==0:
			aayBzF9OcXn1kYqRhDNm7gTZ(PovBQZpbSea,50+int(5*p4kmOV7v1QdLMoKASIq9gUhxG20/NRTxwWEFc6SzytV0G3vMb2YOsjl),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(p4kmOV7v1QdLMoKASIq9gUhxG20)+' / '+TTOixNreYJD9uId)
			if PovBQZpbSea.iscanceled():
				PovBQZpbSea.close()
				return None,None
		U7j9Sy3I4rcVE1XZ,tiIc9lDHrUd,NqFXMA4Rr9cWzm,d7on6sKDqkNY,aPjqOy9703c4voXh1Dz65mMLRZf = HC6rndQ4wxNzUc['group'],HC6rndQ4wxNzUc['context'],HC6rndQ4wxNzUc['title'],HC6rndQ4wxNzUc['url'],HC6rndQ4wxNzUc['img']
		Bdvejubzikl4PyCY2Q6,PPcKmIxajUOue16,Lvi4A8JFMGf3bmI2odxlg5Tcq = HC6rndQ4wxNzUc['country'],HC6rndQ4wxNzUc['language'],HC6rndQ4wxNzUc['type']
		vlLDdQmH97cUWYEoiTIABknKb = (U7j9Sy3I4rcVE1XZ,tiIc9lDHrUd,NqFXMA4Rr9cWzm,d7on6sKDqkNY,aPjqOy9703c4voXh1Dz65mMLRZf)
		WsLvJfn0heGmjFrx3TD9H8zMlaSw = False
		if 'LIVE' in Lvi4A8JFMGf3bmI2odxlg5Tcq:
			if 'UNKNOWN' in Lvi4A8JFMGf3bmI2odxlg5Tcq: V3vKlHO1rBN2W['LIVE_UNKNOWN_GROUPED'].append(vlLDdQmH97cUWYEoiTIABknKb)
			elif 'LIVE' in Lvi4A8JFMGf3bmI2odxlg5Tcq: V3vKlHO1rBN2W['LIVE_GROUPED'].append(vlLDdQmH97cUWYEoiTIABknKb)
			else: WsLvJfn0heGmjFrx3TD9H8zMlaSw = True
			V3vKlHO1rBN2W['LIVE_ORIGINAL_GROUPED'].append(vlLDdQmH97cUWYEoiTIABknKb)
		elif 'VOD' in Lvi4A8JFMGf3bmI2odxlg5Tcq:
			if 'UNKNOWN' in Lvi4A8JFMGf3bmI2odxlg5Tcq: V3vKlHO1rBN2W['VOD_UNKNOWN_GROUPED'].append(vlLDdQmH97cUWYEoiTIABknKb)
			elif 'MOVIES' in Lvi4A8JFMGf3bmI2odxlg5Tcq: V3vKlHO1rBN2W['VOD_MOVIES_GROUPED'].append(vlLDdQmH97cUWYEoiTIABknKb)
			elif 'SERIES' in Lvi4A8JFMGf3bmI2odxlg5Tcq: V3vKlHO1rBN2W['VOD_SERIES_GROUPED'].append(vlLDdQmH97cUWYEoiTIABknKb)
			else: WsLvJfn0heGmjFrx3TD9H8zMlaSw = True
			V3vKlHO1rBN2W['VOD_ORIGINAL_GROUPED'].append(vlLDdQmH97cUWYEoiTIABknKb)
		else: WsLvJfn0heGmjFrx3TD9H8zMlaSw = True
		if WsLvJfn0heGmjFrx3TD9H8zMlaSw: ziDAZdtxKw.append(HC6rndQ4wxNzUc)
		p4kmOV7v1QdLMoKASIq9gUhxG20 += 1
	hsTCuFvQk0 = sorted(YNxSgUEzuhyVPcidAeHw76Tv,reverse=False,key=lambda VFuy0zn89rNPLdt: VFuy0zn89rNPLdt['title'].lower())
	del YNxSgUEzuhyVPcidAeHw76Tv
	TTOixNreYJD9uId = str(NRTxwWEFc6SzytV0G3vMb2YOsjl)
	p4kmOV7v1QdLMoKASIq9gUhxG20 = 0
	for HC6rndQ4wxNzUc in hsTCuFvQk0:
		p4kmOV7v1QdLMoKASIq9gUhxG20 += 1
		if p4kmOV7v1QdLMoKASIq9gUhxG20%873==0:
			aayBzF9OcXn1kYqRhDNm7gTZ(PovBQZpbSea,55+int(5*p4kmOV7v1QdLMoKASIq9gUhxG20/NRTxwWEFc6SzytV0G3vMb2YOsjl),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(p4kmOV7v1QdLMoKASIq9gUhxG20)+' / '+TTOixNreYJD9uId)
			if PovBQZpbSea.iscanceled():
				PovBQZpbSea.close()
				return None,None
		Lvi4A8JFMGf3bmI2odxlg5Tcq = HC6rndQ4wxNzUc['type']
		U7j9Sy3I4rcVE1XZ,tiIc9lDHrUd,NqFXMA4Rr9cWzm,d7on6sKDqkNY,aPjqOy9703c4voXh1Dz65mMLRZf = HC6rndQ4wxNzUc['group'],HC6rndQ4wxNzUc['context'],HC6rndQ4wxNzUc['title'],HC6rndQ4wxNzUc['url'],HC6rndQ4wxNzUc['img']
		Bdvejubzikl4PyCY2Q6,PPcKmIxajUOue16 = HC6rndQ4wxNzUc['country'],HC6rndQ4wxNzUc['language']
		fWh5Ayp9zNBsPl2G = (U7j9Sy3I4rcVE1XZ,tiIc9lDHrUd+'_TIMESHIFT',NqFXMA4Rr9cWzm,d7on6sKDqkNY,aPjqOy9703c4voXh1Dz65mMLRZf)
		vlLDdQmH97cUWYEoiTIABknKb = (U7j9Sy3I4rcVE1XZ,tiIc9lDHrUd,NqFXMA4Rr9cWzm,d7on6sKDqkNY,aPjqOy9703c4voXh1Dz65mMLRZf)
		DB2meFkVu9ylgdQU5ZTSi = (Bdvejubzikl4PyCY2Q6,tiIc9lDHrUd,NqFXMA4Rr9cWzm,d7on6sKDqkNY,aPjqOy9703c4voXh1Dz65mMLRZf)
		UUckz7BuqeFYlXobwCpDATyv6x = (PPcKmIxajUOue16,tiIc9lDHrUd,NqFXMA4Rr9cWzm,d7on6sKDqkNY,aPjqOy9703c4voXh1Dz65mMLRZf)
		if 'LIVE' in Lvi4A8JFMGf3bmI2odxlg5Tcq:
			if 'UNKNOWN' in Lvi4A8JFMGf3bmI2odxlg5Tcq: V3vKlHO1rBN2W['LIVE_UNKNOWN_GROUPED_SORTED'].append(vlLDdQmH97cUWYEoiTIABknKb)
			else: V3vKlHO1rBN2W['LIVE_GROUPED_SORTED'].append(vlLDdQmH97cUWYEoiTIABknKb)
			if 'EPG'		in Lvi4A8JFMGf3bmI2odxlg5Tcq: V3vKlHO1rBN2W['LIVE_EPG_GROUPED_SORTED'].append(vlLDdQmH97cUWYEoiTIABknKb)
			if 'ARCHIVED'	in Lvi4A8JFMGf3bmI2odxlg5Tcq: V3vKlHO1rBN2W['LIVE_ARCHIVED_GROUPED_SORTED'].append(vlLDdQmH97cUWYEoiTIABknKb)
			if 'ARCHIVED'	in Lvi4A8JFMGf3bmI2odxlg5Tcq: V3vKlHO1rBN2W['LIVE_TIMESHIFT_GROUPED_SORTED'].append(fWh5Ayp9zNBsPl2G)
			V3vKlHO1rBN2W['LIVE_FROM_NAME_SORTED'].append(DB2meFkVu9ylgdQU5ZTSi)
			V3vKlHO1rBN2W['LIVE_FROM_GROUP_SORTED'].append(UUckz7BuqeFYlXobwCpDATyv6x)
		elif 'VOD' in Lvi4A8JFMGf3bmI2odxlg5Tcq:
			if   'UNKNOWN'	in Lvi4A8JFMGf3bmI2odxlg5Tcq: V3vKlHO1rBN2W['VOD_UNKNOWN_GROUPED_SORTED'].append(vlLDdQmH97cUWYEoiTIABknKb)
			elif 'MOVIES'	in Lvi4A8JFMGf3bmI2odxlg5Tcq: V3vKlHO1rBN2W['VOD_MOVIES_GROUPED_SORTED'].append(vlLDdQmH97cUWYEoiTIABknKb)
			elif 'SERIES'	in Lvi4A8JFMGf3bmI2odxlg5Tcq: V3vKlHO1rBN2W['VOD_SERIES_GROUPED_SORTED'].append(vlLDdQmH97cUWYEoiTIABknKb)
			V3vKlHO1rBN2W['VOD_FROM_NAME_SORTED'].append(DB2meFkVu9ylgdQU5ZTSi)
			V3vKlHO1rBN2W['VOD_FROM_GROUP_SORTED'].append(UUckz7BuqeFYlXobwCpDATyv6x)
	return V3vKlHO1rBN2W,ziDAZdtxKw
def SSDb6UXEmOwiYjpuK0t8vL4V(NqFXMA4Rr9cWzm):
	if len(NqFXMA4Rr9cWzm)<3: return NqFXMA4Rr9cWzm,NqFXMA4Rr9cWzm
	abelkTxywN3z1ImLGD8fYEjZ74SX9t,mxiwOMcREYhjb3f = '',''
	F1a7fgYXOvVwA6j9mZoy0LpHrI = NqFXMA4Rr9cWzm
	uLyTFc8YHg = NqFXMA4Rr9cWzm[:1]
	XO6SVrvPUG8Yp0fd2wTCqExaJ = NqFXMA4Rr9cWzm[1:]
	if   uLyTFc8YHg=='(': mxiwOMcREYhjb3f = ')'
	elif uLyTFc8YHg=='[': mxiwOMcREYhjb3f = ']'
	elif uLyTFc8YHg=='<': mxiwOMcREYhjb3f = '>'
	elif uLyTFc8YHg=='|': mxiwOMcREYhjb3f = '|'
	if mxiwOMcREYhjb3f and (mxiwOMcREYhjb3f in XO6SVrvPUG8Yp0fd2wTCqExaJ):
		AAmQl2L9TWg,Z1ZTqd2IGwgQuVta = XO6SVrvPUG8Yp0fd2wTCqExaJ.split(mxiwOMcREYhjb3f,1)
		abelkTxywN3z1ImLGD8fYEjZ74SX9t = AAmQl2L9TWg
		F1a7fgYXOvVwA6j9mZoy0LpHrI = uLyTFc8YHg+AAmQl2L9TWg+mxiwOMcREYhjb3f+' '+Z1ZTqd2IGwgQuVta
	elif NqFXMA4Rr9cWzm.count('|')>=2:
		AAmQl2L9TWg,Z1ZTqd2IGwgQuVta = NqFXMA4Rr9cWzm.split('|',1)
		abelkTxywN3z1ImLGD8fYEjZ74SX9t = AAmQl2L9TWg
		F1a7fgYXOvVwA6j9mZoy0LpHrI = AAmQl2L9TWg+' |'+Z1ZTqd2IGwgQuVta
	else:
		mxiwOMcREYhjb3f = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',NqFXMA4Rr9cWzm,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if not mxiwOMcREYhjb3f: mxiwOMcREYhjb3f = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',NqFXMA4Rr9cWzm,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if not mxiwOMcREYhjb3f: mxiwOMcREYhjb3f = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',NqFXMA4Rr9cWzm,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if mxiwOMcREYhjb3f:
			AAmQl2L9TWg,Z1ZTqd2IGwgQuVta = NqFXMA4Rr9cWzm.split(mxiwOMcREYhjb3f[0],1)
			abelkTxywN3z1ImLGD8fYEjZ74SX9t = AAmQl2L9TWg
			F1a7fgYXOvVwA6j9mZoy0LpHrI = AAmQl2L9TWg+' '+mxiwOMcREYhjb3f[0]+' '+Z1ZTqd2IGwgQuVta
	F1a7fgYXOvVwA6j9mZoy0LpHrI = F1a7fgYXOvVwA6j9mZoy0LpHrI.replace('   ',' ').replace('  ',' ')
	abelkTxywN3z1ImLGD8fYEjZ74SX9t = abelkTxywN3z1ImLGD8fYEjZ74SX9t.replace('  ',' ')
	if not abelkTxywN3z1ImLGD8fYEjZ74SX9t: abelkTxywN3z1ImLGD8fYEjZ74SX9t = '!!__UNKNOWN__!!'
	abelkTxywN3z1ImLGD8fYEjZ74SX9t = abelkTxywN3z1ImLGD8fYEjZ74SX9t.strip(' ')
	F1a7fgYXOvVwA6j9mZoy0LpHrI = F1a7fgYXOvVwA6j9mZoy0LpHrI.strip(' ')
	return abelkTxywN3z1ImLGD8fYEjZ74SX9t,F1a7fgYXOvVwA6j9mZoy0LpHrI
def vrpfxzlAKcTZiUaRgudtsmOPEL(L96HvDd3sfBiCSRT):
	UZbaV6FlwAM0uNvdS1mcIPypC = {}
	EhqOy4X5jB = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.iptv.useragent_'+L96HvDd3sfBiCSRT)
	if EhqOy4X5jB: UZbaV6FlwAM0uNvdS1mcIPypC['User-Agent'] = EhqOy4X5jB
	YG2zapHhkE1r4oIdtCm = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.iptv.referer_'+L96HvDd3sfBiCSRT)
	if YG2zapHhkE1r4oIdtCm: UZbaV6FlwAM0uNvdS1mcIPypC['Referer'] = YG2zapHhkE1r4oIdtCm
	return UZbaV6FlwAM0uNvdS1mcIPypC
def sazIx9C3N72Tqf(L96HvDd3sfBiCSRT):
	global PovBQZpbSea,V3vKlHO1rBN2W,k04RBf2Yni,f3nxJY7A12ID,O5OFVHadoW7sI0g8Dih,OkInE9XxvNzaWM,FFmAoeySjsu5W,mKFn83DXCYcoUg6Aj4,k94JYEejKV2NdWTpoygQGAL7mDahB0
	UBc3wC6Sx0AlO,f9MB4sy57lnC0Hrc,t3tPaSeRm48gpYcl,szmuUXHkrIyBZY,KKGXLutpaj9yWwBJ4Tmgfq2ShYlZDO = H4HNRVUbi5(L96HvDd3sfBiCSRT)
	if not szmuUXHkrIyBZY: return
	UZbaV6FlwAM0uNvdS1mcIPypC = vrpfxzlAKcTZiUaRgudtsmOPEL(L96HvDd3sfBiCSRT)
	Bh7kXZnFibK8x = eINt5FlUT0oO('center','','','رسالة من المبرمج','جلب ملفات ـIPTV جديدة قد تحتاج عدة دقائق . هل تريد أن تجلب الملفات الآن ؟')
	if Bh7kXZnFibK8x!=1: return
	FeTMB4Uty3AY5zuCvo0L2mh69dlV8 = MMOw5jW0bU4yEtFnZTLNcHzYQ.replace('___','_'+L96HvDd3sfBiCSRT)
	if 1:
		agX9nom53W,b9j4niYADepUc28WXuSJV,hQkH6GzJPnm0fSNlKLyiwCrR43Fa5 = IIyUEG1AogvkF0zM(L96HvDd3sfBiCSRT,False)
		if not agX9nom53W:
			tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','فشل بسحب ملفات ـIPTV . أحتمال رابط ـIPTV غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـIPTV الموجودة بهذا البرنامج')
			if not f9MB4sy57lnC0Hrc: y75wQavkVSLUb2MZf9qo('ERROR_LINES',Mnm2HRoJ9p6e(PCY2LJwTgIfan)+'   No IPTV URL found to download IPTV files')
			else: y75wQavkVSLUb2MZf9qo('ERROR_LINES',Mnm2HRoJ9p6e(PCY2LJwTgIfan)+'   Failed to download IPTV files')
			return
		FTjzgmZYPDefC2BnNJy = vym8kYdTF2Opjn6wrKa(f9MB4sy57lnC0Hrc,UZbaV6FlwAM0uNvdS1mcIPypC,True)
		if not FTjzgmZYPDefC2BnNJy: return
		open(FeTMB4Uty3AY5zuCvo0L2mh69dlV8,'wb').write(FTjzgmZYPDefC2BnNJy)
	else: FTjzgmZYPDefC2BnNJy = open(FeTMB4Uty3AY5zuCvo0L2mh69dlV8,'rb').read()
	if wvkR1es6d0SrjxKt5FZTMUWz7a and FTjzgmZYPDefC2BnNJy: FTjzgmZYPDefC2BnNJy = FTjzgmZYPDefC2BnNJy.decode('utf8')
	PovBQZpbSea = ARxKazncryd6Ij2OGtCD5eEihuB8m()
	PovBQZpbSea.create('جلب ملفات ـIPTV جديدة','')
	aayBzF9OcXn1kYqRhDNm7gTZ(PovBQZpbSea,15,'تنظيف الملف الرئيسي','')
	FTjzgmZYPDefC2BnNJy = FTjzgmZYPDefC2BnNJy.replace('"tvg-','" tvg-')
	FTjzgmZYPDefC2BnNJy = FTjzgmZYPDefC2BnNJy.replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
	FTjzgmZYPDefC2BnNJy = FTjzgmZYPDefC2BnNJy.replace('ّ','').replace('ِ','').replace('ٍ','').replace('ْ','')
	FTjzgmZYPDefC2BnNJy = FTjzgmZYPDefC2BnNJy.replace('group-title=','group=').replace('tvg-','')
	ILWfPt8kBpjYK56iDhluSU,ggKSkjFiJZYsp5R90AEdbxoB = [],[]
	aayBzF9OcXn1kYqRhDNm7gTZ(PovBQZpbSea,20,'جلب الملفات الثانوية','الملف رقم:-','1 / 3')
	if PovBQZpbSea.iscanceled():
		PovBQZpbSea.close()
		return
	d7on6sKDqkNY = UBc3wC6Sx0AlO+'&action=get_series_categories'
	pPvgKtqo5IAzadVRZsCGU = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',d7on6sKDqkNY,'',UZbaV6FlwAM0uNvdS1mcIPypC,'','','IPTV-CREATE_STREAMS-1st')
	kDQZoFnLUTYc8G45u21ye = pPvgKtqo5IAzadVRZsCGU.content
	kDQZoFnLUTYc8G45u21ye = zKGXT5sJeRq(kDQZoFnLUTYc8G45u21ye)
	WzKikhHRgGFO = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('category_name":"(.*?)"',kDQZoFnLUTYc8G45u21ye,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	del kDQZoFnLUTYc8G45u21ye
	for U7j9Sy3I4rcVE1XZ in WzKikhHRgGFO:
		U7j9Sy3I4rcVE1XZ = U7j9Sy3I4rcVE1XZ.replace('\/','/')
		if vciEXHThAPto76QIR2pK: U7j9Sy3I4rcVE1XZ = U7j9Sy3I4rcVE1XZ.decode('utf8').encode('utf8')
		FTjzgmZYPDefC2BnNJy = FTjzgmZYPDefC2BnNJy.replace('group="'+U7j9Sy3I4rcVE1XZ+'"','group="__SERIES__'+U7j9Sy3I4rcVE1XZ+'"')
	del WzKikhHRgGFO
	aayBzF9OcXn1kYqRhDNm7gTZ(PovBQZpbSea,25,'جلب الملفات الثانوية','الملف رقم:-','2 / 3')
	if PovBQZpbSea.iscanceled():
		PovBQZpbSea.close()
		return
	d7on6sKDqkNY = UBc3wC6Sx0AlO+'&action=get_vod_categories'
	pPvgKtqo5IAzadVRZsCGU = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',d7on6sKDqkNY,'',UZbaV6FlwAM0uNvdS1mcIPypC,'','','IPTV-CREATE_STREAMS-2nd')
	kDQZoFnLUTYc8G45u21ye = pPvgKtqo5IAzadVRZsCGU.content
	kDQZoFnLUTYc8G45u21ye = zKGXT5sJeRq(kDQZoFnLUTYc8G45u21ye)
	m52noRWqJrdMc3KbVe4Y = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('category_name":"(.*?)"',kDQZoFnLUTYc8G45u21ye,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	del kDQZoFnLUTYc8G45u21ye
	for U7j9Sy3I4rcVE1XZ in m52noRWqJrdMc3KbVe4Y:
		U7j9Sy3I4rcVE1XZ = U7j9Sy3I4rcVE1XZ.replace('\/','/')
		if vciEXHThAPto76QIR2pK: U7j9Sy3I4rcVE1XZ = U7j9Sy3I4rcVE1XZ.decode('utf8').encode('utf8')
		FTjzgmZYPDefC2BnNJy = FTjzgmZYPDefC2BnNJy.replace('group="'+U7j9Sy3I4rcVE1XZ+'"','group="__MOVIES__'+U7j9Sy3I4rcVE1XZ+'"')
	del m52noRWqJrdMc3KbVe4Y
	aayBzF9OcXn1kYqRhDNm7gTZ(PovBQZpbSea,30,'جلب الملفات الثانوية','الملف رقم:-','3 / 3')
	if PovBQZpbSea.iscanceled():
		PovBQZpbSea.close()
		return
	d7on6sKDqkNY = UBc3wC6Sx0AlO+'&action=get_live_streams'
	pPvgKtqo5IAzadVRZsCGU = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',d7on6sKDqkNY,'',UZbaV6FlwAM0uNvdS1mcIPypC,'','','IPTV-CREATE_STREAMS-3rd')
	kDQZoFnLUTYc8G45u21ye = pPvgKtqo5IAzadVRZsCGU.content
	kDQZoFnLUTYc8G45u21ye = zKGXT5sJeRq(kDQZoFnLUTYc8G45u21ye)
	ttNWGyTi39v1npMK7fqPjIemd = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"name":"(.*?)".*?"tv_archive":(.*?),',kDQZoFnLUTYc8G45u21ye,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for GG9zmPqulYDyJCtWwkE8,Uz0XERacw7r in ttNWGyTi39v1npMK7fqPjIemd:
		if Uz0XERacw7r=='1': ILWfPt8kBpjYK56iDhluSU.append(GG9zmPqulYDyJCtWwkE8)
	del ttNWGyTi39v1npMK7fqPjIemd
	d8xQKPBbeifWrlSHUToa = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"name":"(.*?)".*?"epg_channel_id":(.*?),',kDQZoFnLUTYc8G45u21ye,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	del kDQZoFnLUTYc8G45u21ye
	for GG9zmPqulYDyJCtWwkE8,DV9rKJ84OWx7anS3Udme in d8xQKPBbeifWrlSHUToa:
		if DV9rKJ84OWx7anS3Udme!='null': ggKSkjFiJZYsp5R90AEdbxoB.append(GG9zmPqulYDyJCtWwkE8)
	del d8xQKPBbeifWrlSHUToa
	FTjzgmZYPDefC2BnNJy = FTjzgmZYPDefC2BnNJy.replace('\r','\n')
	HCFix1cLXj9R6e87BqZ = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('NF:(.+?)'+'#'+'EXTI',FTjzgmZYPDefC2BnNJy+'\n+'+'#'+'EXTINF:',E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not HCFix1cLXj9R6e87BqZ:
		y75wQavkVSLUb2MZf9qo('ERROR_LINES',Mnm2HRoJ9p6e(PCY2LJwTgIfan)+'   Folder:'+L96HvDd3sfBiCSRT+'   No video links found in IPTV file')
		tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','رابط ـIPTV الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـIPTV غير صحيح'+'\n'+'[COLOR FFFFFF00]'+'مجلد رقم '+L96HvDd3sfBiCSRT)
		PovBQZpbSea.close()
		return
	YkrCBMF93zLTDKAG6y0nt7SW5bE1v = []
	for gH6oMIGUWO1sA4aYBbfChRw5yN in HCFix1cLXj9R6e87BqZ:
		OisZTg9XNMWE84mC6tP2G7dHcJAq = gH6oMIGUWO1sA4aYBbfChRw5yN.lower()
		if 'adult' in OisZTg9XNMWE84mC6tP2G7dHcJAq: continue
		if 'xxx' in OisZTg9XNMWE84mC6tP2G7dHcJAq: continue
		YkrCBMF93zLTDKAG6y0nt7SW5bE1v.append(gH6oMIGUWO1sA4aYBbfChRw5yN)
	HCFix1cLXj9R6e87BqZ = YkrCBMF93zLTDKAG6y0nt7SW5bE1v
	del YkrCBMF93zLTDKAG6y0nt7SW5bE1v
	oJsSZFxjkIO0A8utX7Q6VYdiHcvahU = 1024*1024
	x4g8kUYqZAR5hP0aH2y = 1+len(FTjzgmZYPDefC2BnNJy)//oJsSZFxjkIO0A8utX7Q6VYdiHcvahU//10
	del FTjzgmZYPDefC2BnNJy
	R9MmXACpv2iO = len(HCFix1cLXj9R6e87BqZ)
	gJWaqVUe2OYXbSo6rl9K8fc0x = oURBK4OhLeDr9YpgSxskTJV0ZWyP(HCFix1cLXj9R6e87BqZ,x4g8kUYqZAR5hP0aH2y)
	del HCFix1cLXj9R6e87BqZ
	for JF9iBfWwDE1GNjeS4HtOsgk7 in range(x4g8kUYqZAR5hP0aH2y):
		aayBzF9OcXn1kYqRhDNm7gTZ(PovBQZpbSea,35+int(5*JF9iBfWwDE1GNjeS4HtOsgk7/x4g8kUYqZAR5hP0aH2y),'تقطيع الملف الرئيسي','الجزء رقم:-',str(JF9iBfWwDE1GNjeS4HtOsgk7+1)+' / '+str(x4g8kUYqZAR5hP0aH2y))
		if PovBQZpbSea.iscanceled():
			PovBQZpbSea.close()
			return
		hd7mAvJPLMjCNe2ETUqYKc5S = str(gJWaqVUe2OYXbSo6rl9K8fc0x[JF9iBfWwDE1GNjeS4HtOsgk7])
		if wvkR1es6d0SrjxKt5FZTMUWz7a: hd7mAvJPLMjCNe2ETUqYKc5S = hd7mAvJPLMjCNe2ETUqYKc5S.encode('utf8')
		open(FeTMB4Uty3AY5zuCvo0L2mh69dlV8+'.00'+str(JF9iBfWwDE1GNjeS4HtOsgk7),'wb').write(hd7mAvJPLMjCNe2ETUqYKc5S)
	del gJWaqVUe2OYXbSo6rl9K8fc0x,hd7mAvJPLMjCNe2ETUqYKc5S
	e2enGd6ViIlWgkPK3UDs8,YNxSgUEzuhyVPcidAeHw76Tv,p4kmOV7v1QdLMoKASIq9gUhxG20 = [],[],0
	for JF9iBfWwDE1GNjeS4HtOsgk7 in range(x4g8kUYqZAR5hP0aH2y):
		if PovBQZpbSea.iscanceled():
			PovBQZpbSea.close()
			return
		hd7mAvJPLMjCNe2ETUqYKc5S = open(FeTMB4Uty3AY5zuCvo0L2mh69dlV8+'.00'+str(JF9iBfWwDE1GNjeS4HtOsgk7),'rb').read()
		w6vebiEZtpCjJcILP8Skx5rHn.sleep(1)
		try: K3hFytImeYMkJBC.remove(FeTMB4Uty3AY5zuCvo0L2mh69dlV8+'.00'+str(JF9iBfWwDE1GNjeS4HtOsgk7))
		except: pass
		if wvkR1es6d0SrjxKt5FZTMUWz7a: hd7mAvJPLMjCNe2ETUqYKc5S = hd7mAvJPLMjCNe2ETUqYKc5S.decode('utf8')
		VaQktTC75wEriyz9Zj = GVQAnvYCT3dS('list',hd7mAvJPLMjCNe2ETUqYKc5S)
		del hd7mAvJPLMjCNe2ETUqYKc5S
		tjIyR9ML3FVQuzmsn7h,p4kmOV7v1QdLMoKASIq9gUhxG20,ziDAZdtxKw = gYnmDNSZbQXHResPzFG5kq4(VaQktTC75wEriyz9Zj,ggKSkjFiJZYsp5R90AEdbxoB,ILWfPt8kBpjYK56iDhluSU,PovBQZpbSea,R9MmXACpv2iO,p4kmOV7v1QdLMoKASIq9gUhxG20,f9MB4sy57lnC0Hrc)
		if PovBQZpbSea.iscanceled():
			PovBQZpbSea.close()
			return
		if not tjIyR9ML3FVQuzmsn7h:
			PovBQZpbSea.close()
			return
		YNxSgUEzuhyVPcidAeHw76Tv += tjIyR9ML3FVQuzmsn7h
		e2enGd6ViIlWgkPK3UDs8 += ziDAZdtxKw
	del VaQktTC75wEriyz9Zj,tjIyR9ML3FVQuzmsn7h
	V3vKlHO1rBN2W,ziDAZdtxKw = Cc4TANZ8OKV3S(YNxSgUEzuhyVPcidAeHw76Tv,PovBQZpbSea)
	if PovBQZpbSea.iscanceled():
		PovBQZpbSea.close()
		return
	e2enGd6ViIlWgkPK3UDs8 += ziDAZdtxKw
	del YNxSgUEzuhyVPcidAeHw76Tv,ziDAZdtxKw
	f3nxJY7A12ID,O5OFVHadoW7sI0g8Dih,OkInE9XxvNzaWM,FFmAoeySjsu5W,mKFn83DXCYcoUg6Aj4 = {},{},{},0,0
	D293JbLQXk = list(V3vKlHO1rBN2W.keys())
	k94JYEejKV2NdWTpoygQGAL7mDahB0 = len(D293JbLQXk)*3
	if 1:
		vv0j9xfSqC3IeNl2tV1 = {}
		for jeS4FEdVxGPhtakofC1yzm in D293JbLQXk:
			vv0j9xfSqC3IeNl2tV1[jeS4FEdVxGPhtakofC1yzm] = mZHwnlsXWDfV3ri4M.Thread(target=xAEGHuO9cK2ft0zNITV,args=(jeS4FEdVxGPhtakofC1yzm,))
			vv0j9xfSqC3IeNl2tV1[jeS4FEdVxGPhtakofC1yzm].start()
		for jeS4FEdVxGPhtakofC1yzm in D293JbLQXk:
			vv0j9xfSqC3IeNl2tV1[jeS4FEdVxGPhtakofC1yzm].join()
		if PovBQZpbSea.iscanceled():
			PovBQZpbSea.close()
			return
	else:
		for jeS4FEdVxGPhtakofC1yzm in D293JbLQXk:
			xAEGHuO9cK2ft0zNITV(jeS4FEdVxGPhtakofC1yzm)
			if PovBQZpbSea.iscanceled():
				PovBQZpbSea.close()
				return
	EnxyPA8u9MYFKtcbkrIV43QG7Tq5j(L96HvDd3sfBiCSRT,False)
	D293JbLQXk = list(f3nxJY7A12ID.keys())
	k04RBf2Yni = 0
	if 1:
		vv0j9xfSqC3IeNl2tV1 = {}
		for jeS4FEdVxGPhtakofC1yzm in D293JbLQXk:
			vv0j9xfSqC3IeNl2tV1[jeS4FEdVxGPhtakofC1yzm] = mZHwnlsXWDfV3ri4M.Thread(target=triYQSVJklI3,args=(L96HvDd3sfBiCSRT,jeS4FEdVxGPhtakofC1yzm))
			vv0j9xfSqC3IeNl2tV1[jeS4FEdVxGPhtakofC1yzm].start()
		for jeS4FEdVxGPhtakofC1yzm in D293JbLQXk:
			vv0j9xfSqC3IeNl2tV1[jeS4FEdVxGPhtakofC1yzm].join()
		if PovBQZpbSea.iscanceled():
			PovBQZpbSea.close()
			return
	else:
		for jeS4FEdVxGPhtakofC1yzm in D293JbLQXk:
			triYQSVJklI3(L96HvDd3sfBiCSRT,jeS4FEdVxGPhtakofC1yzm)
			if PovBQZpbSea.iscanceled():
				PovBQZpbSea.close()
				return
	JF9iBfWwDE1GNjeS4HtOsgk7 = 0
	z0w8tukqpWxNCEAhbL = len(e2enGd6ViIlWgkPK3UDs8)
	Mm3aBo2VsXjZ4QD = GT29iAgzfL8kt63(L96HvDd3sfBiCSRT,'IGNORED')
	for PF1lnopQSif in e2enGd6ViIlWgkPK3UDs8:
		if JF9iBfWwDE1GNjeS4HtOsgk7%27==0:
			aayBzF9OcXn1kYqRhDNm7gTZ(PovBQZpbSea,95+int(5*JF9iBfWwDE1GNjeS4HtOsgk7//z0w8tukqpWxNCEAhbL),'تخزين المهملة','الفيديو رقم:-',str(JF9iBfWwDE1GNjeS4HtOsgk7)+' / '+str(z0w8tukqpWxNCEAhbL))
			if PovBQZpbSea.iscanceled():
				PovBQZpbSea.close()
				return
		kkNiXj3oTnqxQPvLMCfSKOm58F(Mm3aBo2VsXjZ4QD,'IGNORED',str(PF1lnopQSif),'',D0vjfyxKZuP7pXknq62MwFYU)
		JF9iBfWwDE1GNjeS4HtOsgk7 += 1
	kkNiXj3oTnqxQPvLMCfSKOm58F(Mm3aBo2VsXjZ4QD,'IGNORED','__COUNT__',str(z0w8tukqpWxNCEAhbL),D0vjfyxKZuP7pXknq62MwFYU)
	kkNiXj3oTnqxQPvLMCfSKOm58F(Mm3aBo2VsXjZ4QD,'DUMMY','__DUMMY__','1',D0vjfyxKZuP7pXknq62MwFYU)
	PovBQZpbSea.close()
	w6vebiEZtpCjJcILP8Skx5rHn.sleep(1)
	vApts2uOBgQ5YlihyId = hdFbXSLxsgc0PwrzvyD9kqW8(L96HvDd3sfBiCSRT,False)
	tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','[COLOR FFFFFF00]'+'تم جلب ملفات ـIPTV جديدة'+'[/COLOR]'+'\n\n'+vApts2uOBgQ5YlihyId)
	oos8ymFi9CN2z1jXcR.executebuiltin('Container.Refresh')
	NBFq8XbcxOSPCAG0UYIgVkr2zutQH(L96HvDd3sfBiCSRT)
	return
def xAEGHuO9cK2ft0zNITV(jeS4FEdVxGPhtakofC1yzm):
	global PovBQZpbSea,V3vKlHO1rBN2W,k04RBf2Yni,f3nxJY7A12ID,O5OFVHadoW7sI0g8Dih,OkInE9XxvNzaWM,FFmAoeySjsu5W,mKFn83DXCYcoUg6Aj4,k94JYEejKV2NdWTpoygQGAL7mDahB0
	f3nxJY7A12ID[jeS4FEdVxGPhtakofC1yzm] = {}
	Gr7XNzCZF3ghqsQbwk,WBLFg2TibJEr3oxm = {},[]
	fXwpGxceDLECMP7jAYZk = len(V3vKlHO1rBN2W[jeS4FEdVxGPhtakofC1yzm])
	f3nxJY7A12ID[jeS4FEdVxGPhtakofC1yzm]['__COUNT__'] = fXwpGxceDLECMP7jAYZk
	if fXwpGxceDLECMP7jAYZk>0:
		pFPyojb7rGSZnx3V8udzaAO,eTPOEzWljqc,ggraNSqWejHAbzloPk,hozfsxLgYH,OwBbDS6rRN13pmoC2vVtkWG5TsJ = zip(*V3vKlHO1rBN2W[jeS4FEdVxGPhtakofC1yzm])
		del eTPOEzWljqc,ggraNSqWejHAbzloPk,hozfsxLgYH
		eMn3HFKiD2uRqUxgh14IvZ = list(set(pFPyojb7rGSZnx3V8udzaAO))
		for U7j9Sy3I4rcVE1XZ in eMn3HFKiD2uRqUxgh14IvZ:
			Gr7XNzCZF3ghqsQbwk[U7j9Sy3I4rcVE1XZ] = ''
			f3nxJY7A12ID[jeS4FEdVxGPhtakofC1yzm][U7j9Sy3I4rcVE1XZ] = []
		aayBzF9OcXn1kYqRhDNm7gTZ(PovBQZpbSea,60+int(15*mKFn83DXCYcoUg6Aj4//k94JYEejKV2NdWTpoygQGAL7mDahB0),'تصنيع القوائم','الجزء رقم:-',str(mKFn83DXCYcoUg6Aj4)+' / '+str(k94JYEejKV2NdWTpoygQGAL7mDahB0))
		if PovBQZpbSea.iscanceled(): return
		mKFn83DXCYcoUg6Aj4 += 1
		g2gMFGhOABUjNfmyKt = len(eMn3HFKiD2uRqUxgh14IvZ)
		del eMn3HFKiD2uRqUxgh14IvZ
		WBLFg2TibJEr3oxm = list(set(zip(pFPyojb7rGSZnx3V8udzaAO,OwBbDS6rRN13pmoC2vVtkWG5TsJ)))
		del pFPyojb7rGSZnx3V8udzaAO,OwBbDS6rRN13pmoC2vVtkWG5TsJ
		for U7j9Sy3I4rcVE1XZ,zKHPsDVeYF in WBLFg2TibJEr3oxm:
			if not Gr7XNzCZF3ghqsQbwk[U7j9Sy3I4rcVE1XZ] and zKHPsDVeYF: Gr7XNzCZF3ghqsQbwk[U7j9Sy3I4rcVE1XZ] = zKHPsDVeYF
		aayBzF9OcXn1kYqRhDNm7gTZ(PovBQZpbSea,60+int(15*mKFn83DXCYcoUg6Aj4//k94JYEejKV2NdWTpoygQGAL7mDahB0),'تصنيع القوائم','الجزء رقم:-',str(mKFn83DXCYcoUg6Aj4)+' / '+str(k94JYEejKV2NdWTpoygQGAL7mDahB0))
		if PovBQZpbSea.iscanceled(): return
		mKFn83DXCYcoUg6Aj4 += 1
		TVWS3uKFLtAn6s2zQJRwxbf = list(Gr7XNzCZF3ghqsQbwk.keys())
		du41jVWPUhmLHostQ59cr = list(Gr7XNzCZF3ghqsQbwk.values())
		del Gr7XNzCZF3ghqsQbwk
		WBLFg2TibJEr3oxm = list(zip(TVWS3uKFLtAn6s2zQJRwxbf,du41jVWPUhmLHostQ59cr))
		del TVWS3uKFLtAn6s2zQJRwxbf,du41jVWPUhmLHostQ59cr
		WBLFg2TibJEr3oxm = sorted(WBLFg2TibJEr3oxm)
	else: mKFn83DXCYcoUg6Aj4 += 2
	f3nxJY7A12ID[jeS4FEdVxGPhtakofC1yzm]['__GROUPS__'] = WBLFg2TibJEr3oxm
	del WBLFg2TibJEr3oxm
	for U7j9Sy3I4rcVE1XZ,tiIc9lDHrUd,NqFXMA4Rr9cWzm,d7on6sKDqkNY,aPjqOy9703c4voXh1Dz65mMLRZf in V3vKlHO1rBN2W[jeS4FEdVxGPhtakofC1yzm]:
		f3nxJY7A12ID[jeS4FEdVxGPhtakofC1yzm][U7j9Sy3I4rcVE1XZ].append((tiIc9lDHrUd,NqFXMA4Rr9cWzm,d7on6sKDqkNY,aPjqOy9703c4voXh1Dz65mMLRZf))
	aayBzF9OcXn1kYqRhDNm7gTZ(PovBQZpbSea,60+int(15*mKFn83DXCYcoUg6Aj4//k94JYEejKV2NdWTpoygQGAL7mDahB0),'تصنيع القوائم','الجزء رقم:-',str(mKFn83DXCYcoUg6Aj4)+' / '+str(k94JYEejKV2NdWTpoygQGAL7mDahB0))
	if PovBQZpbSea.iscanceled(): return
	mKFn83DXCYcoUg6Aj4 += 1
	del V3vKlHO1rBN2W[jeS4FEdVxGPhtakofC1yzm]
	OkInE9XxvNzaWM[jeS4FEdVxGPhtakofC1yzm] = list(f3nxJY7A12ID[jeS4FEdVxGPhtakofC1yzm].keys())
	O5OFVHadoW7sI0g8Dih[jeS4FEdVxGPhtakofC1yzm] = len(OkInE9XxvNzaWM[jeS4FEdVxGPhtakofC1yzm])
	FFmAoeySjsu5W += O5OFVHadoW7sI0g8Dih[jeS4FEdVxGPhtakofC1yzm]
	return
def triYQSVJklI3(L96HvDd3sfBiCSRT,jeS4FEdVxGPhtakofC1yzm):
	global PovBQZpbSea,V3vKlHO1rBN2W,k04RBf2Yni,f3nxJY7A12ID,O5OFVHadoW7sI0g8Dih,OkInE9XxvNzaWM,FFmAoeySjsu5W,mKFn83DXCYcoUg6Aj4,k94JYEejKV2NdWTpoygQGAL7mDahB0
	Mm3aBo2VsXjZ4QD = GT29iAgzfL8kt63(L96HvDd3sfBiCSRT,jeS4FEdVxGPhtakofC1yzm)
	for p4kmOV7v1QdLMoKASIq9gUhxG20 in range(1+O5OFVHadoW7sI0g8Dih[jeS4FEdVxGPhtakofC1yzm]//273):
		vFqVcjR5Z6Ibzl1 = []
		kdgo6WeQjpI = OkInE9XxvNzaWM[jeS4FEdVxGPhtakofC1yzm][0:273]
		for U7j9Sy3I4rcVE1XZ in kdgo6WeQjpI:
			vFqVcjR5Z6Ibzl1.append(f3nxJY7A12ID[jeS4FEdVxGPhtakofC1yzm][U7j9Sy3I4rcVE1XZ])
		kkNiXj3oTnqxQPvLMCfSKOm58F(Mm3aBo2VsXjZ4QD,jeS4FEdVxGPhtakofC1yzm,kdgo6WeQjpI,vFqVcjR5Z6Ibzl1,D0vjfyxKZuP7pXknq62MwFYU,True)
		k04RBf2Yni += len(kdgo6WeQjpI)
		aayBzF9OcXn1kYqRhDNm7gTZ(PovBQZpbSea,75+int(20*k04RBf2Yni//FFmAoeySjsu5W),'تخزين القوائم','القائمة رقم:-',str(k04RBf2Yni)+' / '+str(FFmAoeySjsu5W))
		if PovBQZpbSea.iscanceled(): return
		del OkInE9XxvNzaWM[jeS4FEdVxGPhtakofC1yzm][0:273]
	del f3nxJY7A12ID[jeS4FEdVxGPhtakofC1yzm],OkInE9XxvNzaWM[jeS4FEdVxGPhtakofC1yzm],O5OFVHadoW7sI0g8Dih[jeS4FEdVxGPhtakofC1yzm]
	return
def hdFbXSLxsgc0PwrzvyD9kqW8(L96HvDd3sfBiCSRT,yt3K6SfQFkPNlIiWbjOCJHDh5Vpr=True):
	if not RwN5lZjvPsLCW7gz9c0ab1x(L96HvDd3sfBiCSRT,yt3K6SfQFkPNlIiWbjOCJHDh5Vpr): return
	QhOm9EP0Bkt2jTrMYc7Dg = 'رسالة من المبرمج'
	H1zvXKln3Eft = GT29iAgzfL8kt63(L96HvDd3sfBiCSRT,'LIVE_ORIGINAL_GROUPED')
	ZZgQTlqU9rme = GT29iAgzfL8kt63(L96HvDd3sfBiCSRT,'VOD_ORIGINAL_GROUPED')
	z0w8tukqpWxNCEAhbL = vsmQSl1ZDENy69BXJhWYF(H1zvXKln3Eft,'int','IGNORED','__COUNT__')
	j0RvQyVSMHYsmTEOA = vsmQSl1ZDENy69BXJhWYF(H1zvXKln3Eft,'int','LIVE_ORIGINAL_GROUPED','__COUNT__')
	CK7m5EGthlHPFO1TDzx0Wc = vsmQSl1ZDENy69BXJhWYF(ZZgQTlqU9rme,'int','VOD_ORIGINAL_GROUPED','__COUNT__')
	VFUQ60SXiJhBTzA5yIOeCfk = vsmQSl1ZDENy69BXJhWYF(H1zvXKln3Eft,'int','LIVE_GROUPED','__COUNT__')
	IeLcrflqyQoiBM41v = vsmQSl1ZDENy69BXJhWYF(H1zvXKln3Eft,'int','LIVE_UNKNOWN_GROUPED','__COUNT__')
	hXtF6DZ5N4uM8UEAlrf0KV1HGOCe = vsmQSl1ZDENy69BXJhWYF(H1zvXKln3Eft,'int','VOD_MOVIES_GROUPED','__COUNT__')
	M46pUWlJIFVxut1XGeOEj7aD0 = vsmQSl1ZDENy69BXJhWYF(ZZgQTlqU9rme,'int','VOD_SERIES_GROUPED','__COUNT__')
	ytIw6mJZMDYLR7l1UVnodvO = vsmQSl1ZDENy69BXJhWYF(H1zvXKln3Eft,'int','VOD_UNKNOWN_GROUPED','__COUNT__')
	OkInE9XxvNzaWM = vsmQSl1ZDENy69BXJhWYF(ZZgQTlqU9rme,'list','VOD_SERIES_GROUPED','__GROUPS__')
	dasxwkAvmuYS1o8N4zXZr5UIObRJTK = []
	for U7j9Sy3I4rcVE1XZ,aPjqOy9703c4voXh1Dz65mMLRZf in OkInE9XxvNzaWM:
		BIkJOQfbhFsKX5rcLa4zp8Cyg = U7j9Sy3I4rcVE1XZ.split('__SERIES__')[1]
		dasxwkAvmuYS1o8N4zXZr5UIObRJTK.append(BIkJOQfbhFsKX5rcLa4zp8Cyg)
	ZJ5vHUl8eRNaticoyG90 = len(dasxwkAvmuYS1o8N4zXZr5UIObRJTK)
	TvJjOnMcDXu = int(hXtF6DZ5N4uM8UEAlrf0KV1HGOCe)+int(M46pUWlJIFVxut1XGeOEj7aD0)+int(ytIw6mJZMDYLR7l1UVnodvO)+int(IeLcrflqyQoiBM41v)+int(VFUQ60SXiJhBTzA5yIOeCfk)
	vApts2uOBgQ5YlihyId = ''
	vApts2uOBgQ5YlihyId += 'قنوات: '+str(VFUQ60SXiJhBTzA5yIOeCfk)
	vApts2uOBgQ5YlihyId += '   .   أفلام: '+str(hXtF6DZ5N4uM8UEAlrf0KV1HGOCe)
	vApts2uOBgQ5YlihyId += '\nمسلسلات: '+str(ZJ5vHUl8eRNaticoyG90)
	vApts2uOBgQ5YlihyId += '   .   حلقات: '+str(M46pUWlJIFVxut1XGeOEj7aD0)
	vApts2uOBgQ5YlihyId += '\nقنوات مجهولة: '+str(IeLcrflqyQoiBM41v)
	vApts2uOBgQ5YlihyId += '   .   فيدوهات مجهولة: '+str(ytIw6mJZMDYLR7l1UVnodvO)
	vApts2uOBgQ5YlihyId += '\nمجموع القنوات: '+str(j0RvQyVSMHYsmTEOA)
	vApts2uOBgQ5YlihyId += '   .   مجموع الفيديوهات: '+str(CK7m5EGthlHPFO1TDzx0Wc)
	vApts2uOBgQ5YlihyId += '\n\nمجموع المضافة: '+str(TvJjOnMcDXu)
	vApts2uOBgQ5YlihyId += '   .   مجموع المهملة: '+str(z0w8tukqpWxNCEAhbL)
	if yt3K6SfQFkPNlIiWbjOCJHDh5Vpr: tehb3k5a2PufGOdBIUw8j('center','',QhOm9EP0Bkt2jTrMYc7Dg,vApts2uOBgQ5YlihyId)
	iXcHKMugB8ZzJbv1CQs6APEF = vApts2uOBgQ5YlihyId.replace('\n\n','\n')
	y75wQavkVSLUb2MZf9qo('NOTICE','.  Counts of IPTV videos   Folder: '+L96HvDd3sfBiCSRT+'\n'+iXcHKMugB8ZzJbv1CQs6APEF)
	return vApts2uOBgQ5YlihyId
def EnxyPA8u9MYFKtcbkrIV43QG7Tq5j(L96HvDd3sfBiCSRT,yt3K6SfQFkPNlIiWbjOCJHDh5Vpr=True):
	if yt3K6SfQFkPNlIiWbjOCJHDh5Vpr:
		Bh7kXZnFibK8x = eINt5FlUT0oO('center','','','مسح ملفات ـIPTV','تستطيع في أي وقت الدخول إلى قائمة ـIPTV وجلب ملفات ـIPTV جديدة .. هل تريد الآن مسح الملفات القديمة المخزنة في البرنامج ؟!')
		if Bh7kXZnFibK8x!=1: return
		nkmQD7wBH2MIj4ReT = MMOw5jW0bU4yEtFnZTLNcHzYQ.replace('___','_'+L96HvDd3sfBiCSRT)
		try: K3hFytImeYMkJBC.remove(nkmQD7wBH2MIj4ReT)
		except: pass
	nkmQD7wBH2MIj4ReT = fnaV5QejFsr0.replace('___','_'+L96HvDd3sfBiCSRT)
	try: K3hFytImeYMkJBC.remove(nkmQD7wBH2MIj4ReT)
	except: pass
	nkmQD7wBH2MIj4ReT = wSMteKN1DXjAa.replace('___','_'+L96HvDd3sfBiCSRT)
	try: K3hFytImeYMkJBC.remove(nkmQD7wBH2MIj4ReT)
	except: pass
	QQvOnYi9sJMwp7dIxeck8DRASWuBt(WSgQvHLx9uOKTksaCt2JchldRj,'SECTIONS_IPTV','SECTIONS_IPTV_'+L96HvDd3sfBiCSRT)
	QQvOnYi9sJMwp7dIxeck8DRASWuBt(WSgQvHLx9uOKTksaCt2JchldRj,'SECTIONS_IPTV','SECTIONS_IPTV_ALL')
	Jc19dpOeUMyLXG5PVrf0SlZmHntx(False)
	NBFq8XbcxOSPCAG0UYIgVkr2zutQH(L96HvDd3sfBiCSRT)
	if yt3K6SfQFkPNlIiWbjOCJHDh5Vpr:
		tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','تم مسح جميع ملفات ـIPTV')
		oos8ymFi9CN2z1jXcR.executebuiltin('Container.Refresh')
	return
def RwN5lZjvPsLCW7gz9c0ab1x(L96HvDd3sfBiCSRT='',yt3K6SfQFkPNlIiWbjOCJHDh5Vpr=True):
	if L96HvDd3sfBiCSRT:
		Mm3aBo2VsXjZ4QD = GT29iAgzfL8kt63(str(L96HvDd3sfBiCSRT),'DUMMY')
		HXj9St07uNI6JBACMxcPqsvO8KVw = vsmQSl1ZDENy69BXJhWYF(Mm3aBo2VsXjZ4QD,'str','DUMMY','__DUMMY__')
		if HXj9St07uNI6JBACMxcPqsvO8KVw: return True
	else:
		L96HvDd3sfBiCSRT = '1'
		for XUNjtI8O0qcfE7Z2dvegwh6pboYa4 in range(1,qHwLO4cGVh+1):
			Mm3aBo2VsXjZ4QD = GT29iAgzfL8kt63(str(XUNjtI8O0qcfE7Z2dvegwh6pboYa4),'DUMMY')
			HXj9St07uNI6JBACMxcPqsvO8KVw = vsmQSl1ZDENy69BXJhWYF(Mm3aBo2VsXjZ4QD,'str','DUMMY','__DUMMY__')
			if HXj9St07uNI6JBACMxcPqsvO8KVw: return True
	if yt3K6SfQFkPNlIiWbjOCJHDh5Vpr:
		tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','هذا الجزء من البرنامج يحتاج اشتراك IPTV مدفوع من شركة IPTV .. ونوع الرابط المطلوب هو  m3u .. وهذا مثال لتوضيح شكل الرابط المطلوب في هذا البرنامج  [COLOR FFC89008] \n\nhttp://xyz.xyz/get.php?username=xyz&password=xyz&type=m3u_plus [/COLOR]')
		QhOm9EP0Bkt2jTrMYc7Dg = 'إضافة وتغيير رابط '+qjvurmMCnxdktlp6Ii2ZhJb74y[1]+' (مجلد '+qjvurmMCnxdktlp6Ii2ZhJb74y[int(L96HvDd3sfBiCSRT)]+')'
		Bh7kXZnFibK8x = eINt5FlUT0oO('','','',QhOm9EP0Bkt2jTrMYc7Dg,'لإضافة رابط IPTV .. أولا أفتح قائمة IPTV .. وثانيا أنقر على إضافة رابط أو اشتراك ـIPTV .. وثالثا أنقر على جلب ملفات ـIPTV \n\n هل تريد إضافة أو تغيير رابط IPTV الآن ؟!')
		if Bh7kXZnFibK8x==1: Hv5aEwmrNiyA8WpG4l(L96HvDd3sfBiCSRT)
	return False
def AWOymv5wMZT16cEk9xin(uuHDZJL6s7hPdojrO0mQ,L96HvDd3sfBiCSRT='',jeS4FEdVxGPhtakofC1yzm='',euK4mQzpdF6fay=''):
	if not euK4mQzpdF6fay: euK4mQzpdF6fay = '1'
	v4krFwHQLNUB,VGPNayc6DgkReH1xC9BE3uFO475bf,yt3K6SfQFkPNlIiWbjOCJHDh5Vpr = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(uuHDZJL6s7hPdojrO0mQ)
	if not RwN5lZjvPsLCW7gz9c0ab1x(L96HvDd3sfBiCSRT,yt3K6SfQFkPNlIiWbjOCJHDh5Vpr): return
	if not v4krFwHQLNUB:
		v4krFwHQLNUB = UIf35nZEj1wylmq()
		if not v4krFwHQLNUB: return
	OndSFo84vG = ['','LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not jeS4FEdVxGPhtakofC1yzm:
		if not yt3K6SfQFkPNlIiWbjOCJHDh5Vpr:
			if   '_IPTV-LIVE_' in VGPNayc6DgkReH1xC9BE3uFO475bf: jeS4FEdVxGPhtakofC1yzm = OndSFo84vG[1]
			elif '_IPTV-MOVIES' in VGPNayc6DgkReH1xC9BE3uFO475bf: jeS4FEdVxGPhtakofC1yzm = OndSFo84vG[2]
			elif '_IPTV-SERIES' in VGPNayc6DgkReH1xC9BE3uFO475bf: jeS4FEdVxGPhtakofC1yzm = OndSFo84vG[3]
			else: jeS4FEdVxGPhtakofC1yzm = OndSFo84vG[0]
		else:
			ee6d9IljKqxiUmhPD0y = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			A4rSxVHK9Dfieob8B7 = pYRLgOuVTAUM4wKJchdbkzfBql('أختر البحث المناسب', ee6d9IljKqxiUmhPD0y)
			if A4rSxVHK9Dfieob8B7==-1: return
			jeS4FEdVxGPhtakofC1yzm = OndSFo84vG[A4rSxVHK9Dfieob8B7]
	v4krFwHQLNUB = v4krFwHQLNUB+'_NODIALOGS_'
	if L96HvDd3sfBiCSRT: CGSAfh0J78uolWtjD5(v4krFwHQLNUB,L96HvDd3sfBiCSRT,jeS4FEdVxGPhtakofC1yzm,euK4mQzpdF6fay)
	else:
		for L96HvDd3sfBiCSRT in range(1,qHwLO4cGVh+1):
			CGSAfh0J78uolWtjD5(v4krFwHQLNUB,str(L96HvDd3sfBiCSRT),jeS4FEdVxGPhtakofC1yzm,euK4mQzpdF6fay)
		muPDGHvJwFieQYCW62bB[:] = sorted(muPDGHvJwFieQYCW62bB,reverse=False,key=lambda VFuy0zn89rNPLdt: VFuy0zn89rNPLdt[1].lower())
	return
def CGSAfh0J78uolWtjD5(uuHDZJL6s7hPdojrO0mQ,L96HvDd3sfBiCSRT,jeS4FEdVxGPhtakofC1yzm='',euK4mQzpdF6fay=''):
	if not euK4mQzpdF6fay: euK4mQzpdF6fay = '1'
	v4krFwHQLNUB,VGPNayc6DgkReH1xC9BE3uFO475bf,yt3K6SfQFkPNlIiWbjOCJHDh5Vpr = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(uuHDZJL6s7hPdojrO0mQ)
	if not L96HvDd3sfBiCSRT: return
	if not RwN5lZjvPsLCW7gz9c0ab1x(L96HvDd3sfBiCSRT,yt3K6SfQFkPNlIiWbjOCJHDh5Vpr): return
	if not v4krFwHQLNUB:
		v4krFwHQLNUB = UIf35nZEj1wylmq()
		if not v4krFwHQLNUB: return
	OndSFo84vG = ['','LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not jeS4FEdVxGPhtakofC1yzm:
		if not yt3K6SfQFkPNlIiWbjOCJHDh5Vpr:
			if   '_IPTV-LIVE_' in VGPNayc6DgkReH1xC9BE3uFO475bf: jeS4FEdVxGPhtakofC1yzm = OndSFo84vG[1]
			elif '_IPTV-MOVIES' in VGPNayc6DgkReH1xC9BE3uFO475bf: jeS4FEdVxGPhtakofC1yzm = OndSFo84vG[2]
			elif '_IPTV-SERIES' in VGPNayc6DgkReH1xC9BE3uFO475bf: jeS4FEdVxGPhtakofC1yzm = OndSFo84vG[3]
			else: jeS4FEdVxGPhtakofC1yzm = OndSFo84vG[0]
		else:
			ee6d9IljKqxiUmhPD0y = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			A4rSxVHK9Dfieob8B7 = pYRLgOuVTAUM4wKJchdbkzfBql('أختر البحث المناسب', ee6d9IljKqxiUmhPD0y)
			if A4rSxVHK9Dfieob8B7==-1: return
			jeS4FEdVxGPhtakofC1yzm = OndSFo84vG[A4rSxVHK9Dfieob8B7]
	pbsQGcCqW0oi94Fld = v4krFwHQLNUB.lower()
	Mm3aBo2VsXjZ4QD = GT29iAgzfL8kt63(L96HvDd3sfBiCSRT,'SEARCH')
	RbtUmf6lI3nFS8agCeNWGDcK4Z0 = vsmQSl1ZDENy69BXJhWYF(Mm3aBo2VsXjZ4QD,'list','SEARCH',(jeS4FEdVxGPhtakofC1yzm,pbsQGcCqW0oi94Fld))
	if not RbtUmf6lI3nFS8agCeNWGDcK4Z0:
		HKR92jFU0fWAI4,tRChFd18HB7oT5pEvMO = [],[]
		if not jeS4FEdVxGPhtakofC1yzm: pqES59bLRfNGleg6coZ = [1,2,3,4,5]
		else: pqES59bLRfNGleg6coZ = [OndSFo84vG.index(jeS4FEdVxGPhtakofC1yzm)]
		for JF9iBfWwDE1GNjeS4HtOsgk7 in pqES59bLRfNGleg6coZ:
			Mm3aBo2VsXjZ4QD = GT29iAgzfL8kt63(L96HvDd3sfBiCSRT,OndSFo84vG[JF9iBfWwDE1GNjeS4HtOsgk7])
			if JF9iBfWwDE1GNjeS4HtOsgk7!=3:
				tjIyR9ML3FVQuzmsn7h = vsmQSl1ZDENy69BXJhWYF(Mm3aBo2VsXjZ4QD,'dict',OndSFo84vG[JF9iBfWwDE1GNjeS4HtOsgk7])
				del tjIyR9ML3FVQuzmsn7h['__COUNT__']
				del tjIyR9ML3FVQuzmsn7h['__GROUPS__']
				del tjIyR9ML3FVQuzmsn7h['__SEQUENCED_COLUMNS__']
				OkInE9XxvNzaWM = list(tjIyR9ML3FVQuzmsn7h.keys())
				for U7j9Sy3I4rcVE1XZ in OkInE9XxvNzaWM:
					for tiIc9lDHrUd,NqFXMA4Rr9cWzm,d7on6sKDqkNY,aPjqOy9703c4voXh1Dz65mMLRZf in tjIyR9ML3FVQuzmsn7h[U7j9Sy3I4rcVE1XZ]:
						if pbsQGcCqW0oi94Fld in NqFXMA4Rr9cWzm.lower(): tRChFd18HB7oT5pEvMO.append((NqFXMA4Rr9cWzm,d7on6sKDqkNY,aPjqOy9703c4voXh1Dz65mMLRZf))
					del tjIyR9ML3FVQuzmsn7h[U7j9Sy3I4rcVE1XZ]
				del tjIyR9ML3FVQuzmsn7h
			else: OkInE9XxvNzaWM = vsmQSl1ZDENy69BXJhWYF(Mm3aBo2VsXjZ4QD,'list',OndSFo84vG[JF9iBfWwDE1GNjeS4HtOsgk7],'__GROUPS__')
			for U7j9Sy3I4rcVE1XZ in OkInE9XxvNzaWM:
				try: U7j9Sy3I4rcVE1XZ,aPjqOy9703c4voXh1Dz65mMLRZf = U7j9Sy3I4rcVE1XZ
				except: aPjqOy9703c4voXh1Dz65mMLRZf = ''
				if pbsQGcCqW0oi94Fld in U7j9Sy3I4rcVE1XZ.lower():
					if JF9iBfWwDE1GNjeS4HtOsgk7!=3: XLSmeFcrgBJ43DuaKGUyOtsqR2zWQI = U7j9Sy3I4rcVE1XZ
					else:
						xXFmVQCIfTz78iyOq3Y59PvSDM,MuSZ0xnLjsmYcd9FPCJ = U7j9Sy3I4rcVE1XZ.split('__SERIES__')
						if pbsQGcCqW0oi94Fld in xXFmVQCIfTz78iyOq3Y59PvSDM.lower(): XLSmeFcrgBJ43DuaKGUyOtsqR2zWQI = xXFmVQCIfTz78iyOq3Y59PvSDM
						else: XLSmeFcrgBJ43DuaKGUyOtsqR2zWQI = MuSZ0xnLjsmYcd9FPCJ
					HKR92jFU0fWAI4.append((U7j9Sy3I4rcVE1XZ,XLSmeFcrgBJ43DuaKGUyOtsqR2zWQI,OndSFo84vG[JF9iBfWwDE1GNjeS4HtOsgk7],aPjqOy9703c4voXh1Dz65mMLRZf))
			del OkInE9XxvNzaWM
		HKR92jFU0fWAI4 = set(HKR92jFU0fWAI4)
		tRChFd18HB7oT5pEvMO = set(tRChFd18HB7oT5pEvMO)
		HKR92jFU0fWAI4 = sorted(HKR92jFU0fWAI4,reverse=False,key=lambda VFuy0zn89rNPLdt: VFuy0zn89rNPLdt[1])
		tRChFd18HB7oT5pEvMO = sorted(tRChFd18HB7oT5pEvMO,reverse=False,key=lambda VFuy0zn89rNPLdt: VFuy0zn89rNPLdt[0])
		kkNiXj3oTnqxQPvLMCfSKOm58F(Mm3aBo2VsXjZ4QD,'SEARCH',(jeS4FEdVxGPhtakofC1yzm,pbsQGcCqW0oi94Fld),(HKR92jFU0fWAI4,tRChFd18HB7oT5pEvMO),D0vjfyxKZuP7pXknq62MwFYU)
	else: HKR92jFU0fWAI4,tRChFd18HB7oT5pEvMO = RbtUmf6lI3nFS8agCeNWGDcK4Z0
	OkInE9XxvNzaWM = len(HKR92jFU0fWAI4)
	ll5xYzhH3nvAyfur = len(tRChFd18HB7oT5pEvMO)
	eWICxFNw73mJnSToUiR = int(euK4mQzpdF6fay)
	fM9BaZwKItJkUg1j7 = max(0,(eWICxFNw73mJnSToUiR-1)*100)
	Lg5aZuJjU1zYhnXp9w7GTiH3M = max(0,eWICxFNw73mJnSToUiR*100)
	ULbt5qC76MsJm = max(0,fM9BaZwKItJkUg1j7-OkInE9XxvNzaWM)
	cr3uEkCsbQJn5gjBiPOqRFDSdfpGV = max(0,Lg5aZuJjU1zYhnXp9w7GTiH3M-OkInE9XxvNzaWM)
	for U7j9Sy3I4rcVE1XZ,XLSmeFcrgBJ43DuaKGUyOtsqR2zWQI,i4CX7dQtuvpwq,aPjqOy9703c4voXh1Dz65mMLRZf in HKR92jFU0fWAI4[fM9BaZwKItJkUg1j7:Lg5aZuJjU1zYhnXp9w7GTiH3M]:
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+XLSmeFcrgBJ43DuaKGUyOtsqR2zWQI,i4CX7dQtuvpwq,234,aPjqOy9703c4voXh1Dz65mMLRZf,'1',U7j9Sy3I4rcVE1XZ,'',{'folder':L96HvDd3sfBiCSRT})
	del HKR92jFU0fWAI4
	for NqFXMA4Rr9cWzm,d7on6sKDqkNY,aPjqOy9703c4voXh1Dz65mMLRZf in tRChFd18HB7oT5pEvMO[ULbt5qC76MsJm:cr3uEkCsbQJn5gjBiPOqRFDSdfpGV]:
		pTlx0AgFMJUPScnQ = SU82u7LfcMslH3e0Bzihn6x(d7on6sKDqkNY)
		s8Oimqou2fZD = 'live'
		if '.mkv' in pTlx0AgFMJUPScnQ or 'VOD' in jeS4FEdVxGPhtakofC1yzm: s8Oimqou2fZD = 'video'
		tBq8fTGUWJY9zvbgXD0EAloPO(s8Oimqou2fZD,E6M5YUL1m4a0JDVtwcdzqovGR+NqFXMA4Rr9cWzm,d7on6sKDqkNY,235,aPjqOy9703c4voXh1Dz65mMLRZf,'','','',{'folder':L96HvDd3sfBiCSRT})
	del tRChFd18HB7oT5pEvMO
	sLYp6gD8wbEejm(L96HvDd3sfBiCSRT,euK4mQzpdF6fay,jeS4FEdVxGPhtakofC1yzm,239,OkInE9XxvNzaWM+ll5xYzhH3nvAyfur,v4krFwHQLNUB+'_NODIALOGS_')
	return
def sLYp6gD8wbEejm(L96HvDd3sfBiCSRT,euK4mQzpdF6fay,jeS4FEdVxGPhtakofC1yzm,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,TvJjOnMcDXu,RxgdTHfDar8EXt):
	if euK4mQzpdF6fay!='1': tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'صفحة '+str(1),jeS4FEdVxGPhtakofC1yzm,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,'',str(1),RxgdTHfDar8EXt,'',{'folder':L96HvDd3sfBiCSRT})
	if not TvJjOnMcDXu: TvJjOnMcDXu = 0
	outiEcB52gl9ZKJ3jzpfRN = int(TvJjOnMcDXu/100)+1
	for eWICxFNw73mJnSToUiR in range(2,outiEcB52gl9ZKJ3jzpfRN):
		sXPYFy6hlLKRdfU7CAG5 = (eWICxFNw73mJnSToUiR%10==0 or int(euK4mQzpdF6fay)-4<eWICxFNw73mJnSToUiR<int(euK4mQzpdF6fay)+4)
		L7R6exXuwvhzdJUE1FOs2 = (sXPYFy6hlLKRdfU7CAG5 and int(euK4mQzpdF6fay)-40<eWICxFNw73mJnSToUiR<int(euK4mQzpdF6fay)+40)
		if str(eWICxFNw73mJnSToUiR)!=euK4mQzpdF6fay and (eWICxFNw73mJnSToUiR%100==0 or L7R6exXuwvhzdJUE1FOs2):
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'صفحة '+str(eWICxFNw73mJnSToUiR),jeS4FEdVxGPhtakofC1yzm,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,'',str(eWICxFNw73mJnSToUiR),RxgdTHfDar8EXt,'',{'folder':L96HvDd3sfBiCSRT})
	if str(outiEcB52gl9ZKJ3jzpfRN)!=euK4mQzpdF6fay: tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+'أخر صفحة '+str(outiEcB52gl9ZKJ3jzpfRN),jeS4FEdVxGPhtakofC1yzm,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,'',str(outiEcB52gl9ZKJ3jzpfRN),RxgdTHfDar8EXt,'',{'folder':L96HvDd3sfBiCSRT})
	return
def GT29iAgzfL8kt63(L96HvDd3sfBiCSRT,jeS4FEdVxGPhtakofC1yzm):
	if 'SERIES' in jeS4FEdVxGPhtakofC1yzm or 'VOD_ORIGINAL' in jeS4FEdVxGPhtakofC1yzm: Mm3aBo2VsXjZ4QD = wSMteKN1DXjAa
	else: Mm3aBo2VsXjZ4QD = fnaV5QejFsr0
	Mm3aBo2VsXjZ4QD = Mm3aBo2VsXjZ4QD.replace('___','_'+L96HvDd3sfBiCSRT)
	return Mm3aBo2VsXjZ4QD
def lN8OQBfxW9uPj0cqp7vETM2Cr(L96HvDd3sfBiCSRT,jeS4FEdVxGPhtakofC1yzm,RgXOq491d8il03VuzDLnHjxCy):
	UBc3wC6Sx0AlO,f9MB4sy57lnC0Hrc,t3tPaSeRm48gpYcl,szmuUXHkrIyBZY,KKGXLutpaj9yWwBJ4Tmgfq2ShYlZDO = H4HNRVUbi5(L96HvDd3sfBiCSRT)
	if not szmuUXHkrIyBZY: return
	UZbaV6FlwAM0uNvdS1mcIPypC = vrpfxzlAKcTZiUaRgudtsmOPEL(L96HvDd3sfBiCSRT)
	if   jeS4FEdVxGPhtakofC1yzm=='XTREAM_LIVE_GROUPS': d7on6sKDqkNY = UBc3wC6Sx0AlO+'&action=get_live_categories'
	elif jeS4FEdVxGPhtakofC1yzm=='XTREAM_VOD_GROUPS': d7on6sKDqkNY = UBc3wC6Sx0AlO+'&action=get_vod_categories'
	elif jeS4FEdVxGPhtakofC1yzm=='XTREAM_SERIES_GROUPS': d7on6sKDqkNY = UBc3wC6Sx0AlO+'&action=get_series_categories'
	elif jeS4FEdVxGPhtakofC1yzm=='XTREAM_LIVE_ITEMS': d7on6sKDqkNY = UBc3wC6Sx0AlO+'&action=get_live_streams&category_id='+RgXOq491d8il03VuzDLnHjxCy
	elif jeS4FEdVxGPhtakofC1yzm=='XTREAM_VOD_ITEMS': d7on6sKDqkNY = UBc3wC6Sx0AlO+'&action=get_vod_streams&category_id='+RgXOq491d8il03VuzDLnHjxCy
	elif jeS4FEdVxGPhtakofC1yzm=='XTREAM_SERIES_ITEMS': d7on6sKDqkNY = UBc3wC6Sx0AlO+'&action=get_series&category_id='+RgXOq491d8il03VuzDLnHjxCy
	elif jeS4FEdVxGPhtakofC1yzm=='XTREAM_EPISODES': d7on6sKDqkNY = UBc3wC6Sx0AlO+'&action=get_series_info&series_id='+RgXOq491d8il03VuzDLnHjxCy
	else: return
	pPvgKtqo5IAzadVRZsCGU = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',d7on6sKDqkNY,'',UZbaV6FlwAM0uNvdS1mcIPypC,'','','IPTV-XTREAM_MENUS-1st')
	kDQZoFnLUTYc8G45u21ye = pPvgKtqo5IAzadVRZsCGU.content
	if vciEXHThAPto76QIR2pK: kDQZoFnLUTYc8G45u21ye = kDQZoFnLUTYc8G45u21ye.decode('utf8').encode('utf8')
	eJn2CDKlHXP = GVQAnvYCT3dS('list',kDQZoFnLUTYc8G45u21ye)
	if 'GROUPS' in jeS4FEdVxGPhtakofC1yzm:
		jeS4FEdVxGPhtakofC1yzm = jeS4FEdVxGPhtakofC1yzm.replace('_GROUPS','_ITEMS')
		eJn2CDKlHXP = sorted(eJn2CDKlHXP,reverse=False,key=lambda VFuy0zn89rNPLdt: VFuy0zn89rNPLdt['category_name'].lower())
		for U7j9Sy3I4rcVE1XZ in eJn2CDKlHXP:
			rXUEaoIJm08MKt5hdgBzH = U7j9Sy3I4rcVE1XZ['category_id']
			NqFXMA4Rr9cWzm = U7j9Sy3I4rcVE1XZ['category_name']
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+NqFXMA4Rr9cWzm,jeS4FEdVxGPhtakofC1yzm,285,'','',str(rXUEaoIJm08MKt5hdgBzH),'',{'folder':L96HvDd3sfBiCSRT})
	elif jeS4FEdVxGPhtakofC1yzm=='XTREAM_SERIES_ITEMS':
		eJn2CDKlHXP = sorted(eJn2CDKlHXP,reverse=False,key=lambda VFuy0zn89rNPLdt: VFuy0zn89rNPLdt['name'].lower())
		for XXqY1QhR4N in eJn2CDKlHXP:
			NqFXMA4Rr9cWzm = XXqY1QhR4N['name']
			zKHPsDVeYF = XXqY1QhR4N['cover']
			rXUEaoIJm08MKt5hdgBzH = XXqY1QhR4N['series_id']
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',E6M5YUL1m4a0JDVtwcdzqovGR+NqFXMA4Rr9cWzm,'XTREAM_EPISODES',285,zKHPsDVeYF,'',str(rXUEaoIJm08MKt5hdgBzH),'',{'folder':L96HvDd3sfBiCSRT})
	elif jeS4FEdVxGPhtakofC1yzm=='XTREAM_EPISODES':
		zKHPsDVeYF = eJn2CDKlHXP['info']['cover']
		GG9zmPqulYDyJCtWwkE8 = eJn2CDKlHXP['info']['name']
		hhpZPdYJS8EwGF5Kljzxc7OU2 = eJn2CDKlHXP['episodes']
		for yyX9uKhp8EfYZLqc4ojTliFNgP in hhpZPdYJS8EwGF5Kljzxc7OU2:
			C2z5G17bJtZVI6XanxFLU = hhpZPdYJS8EwGF5Kljzxc7OU2[yyX9uKhp8EfYZLqc4ojTliFNgP]
			for cfJ0ZM4xshK7TEC6 in C2z5G17bJtZVI6XanxFLU:
				NqFXMA4Rr9cWzm = cfJ0ZM4xshK7TEC6['title']
				SO6hl4pdXDeAmnGjLHt91fqg2W = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('\d+.(S\d+E\d+)',NqFXMA4Rr9cWzm,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
				if SO6hl4pdXDeAmnGjLHt91fqg2W: NqFXMA4Rr9cWzm = GG9zmPqulYDyJCtWwkE8+' '+SO6hl4pdXDeAmnGjLHt91fqg2W[0]
				rXUEaoIJm08MKt5hdgBzH = cfJ0ZM4xshK7TEC6['id']
				yjd0KaPIhJLTXmqGNrOe = cfJ0ZM4xshK7TEC6['container_extension']
				d7on6sKDqkNY = UBc3wC6Sx0AlO.split('/player_api.php')[0]+'/series/'+szmuUXHkrIyBZY+'/'+KKGXLutpaj9yWwBJ4Tmgfq2ShYlZDO+'/'+str(rXUEaoIJm08MKt5hdgBzH)+'.'+yjd0KaPIhJLTXmqGNrOe
				tBq8fTGUWJY9zvbgXD0EAloPO('video',E6M5YUL1m4a0JDVtwcdzqovGR+NqFXMA4Rr9cWzm,d7on6sKDqkNY,235,zKHPsDVeYF,'','','',{'folder':L96HvDd3sfBiCSRT})
	elif 'ITEMS' in jeS4FEdVxGPhtakofC1yzm:
		s8Oimqou2fZD = 'live' if 'LIVE' in jeS4FEdVxGPhtakofC1yzm else 'video'
		eJn2CDKlHXP = sorted(eJn2CDKlHXP,reverse=False,key=lambda VFuy0zn89rNPLdt: VFuy0zn89rNPLdt['name'].lower())
		for DpOQ90ej4k in eJn2CDKlHXP:
			NqFXMA4Rr9cWzm = DpOQ90ej4k['name']
			zKHPsDVeYF = DpOQ90ej4k['stream_icon']
			rXUEaoIJm08MKt5hdgBzH = DpOQ90ej4k['stream_id']
			try:
				yjd0KaPIhJLTXmqGNrOe = DpOQ90ej4k['container_extension']
				if yjd0KaPIhJLTXmqGNrOe: yjd0KaPIhJLTXmqGNrOe = '.'+yjd0KaPIhJLTXmqGNrOe
			except: yjd0KaPIhJLTXmqGNrOe = ''
			if DpOQ90ej4k['stream_type']=='live': Lvi4A8JFMGf3bmI2odxlg5Tcq,KmUGAljhpcV3iJbCnd5FItgef2X0Z = '','live'
			elif DpOQ90ej4k['stream_type']=='movie': Lvi4A8JFMGf3bmI2odxlg5Tcq,KmUGAljhpcV3iJbCnd5FItgef2X0Z = 'movie/','video'
			d7on6sKDqkNY = UBc3wC6Sx0AlO.split('/player_api.php')[0]+'/'+Lvi4A8JFMGf3bmI2odxlg5Tcq+szmuUXHkrIyBZY+'/'+KKGXLutpaj9yWwBJ4Tmgfq2ShYlZDO+'/'+str(rXUEaoIJm08MKt5hdgBzH)+yjd0KaPIhJLTXmqGNrOe
			tBq8fTGUWJY9zvbgXD0EAloPO(s8Oimqou2fZD,E6M5YUL1m4a0JDVtwcdzqovGR+NqFXMA4Rr9cWzm,d7on6sKDqkNY,235,zKHPsDVeYF,'','','',{'folder':L96HvDd3sfBiCSRT})
	return
def NBFq8XbcxOSPCAG0UYIgVkr2zutQH(L96HvDd3sfBiCSRT):
	yLhu2x01UkCdMjnGf7PZzK4 = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.language.provider')
	GLzgtpD2bm7icFokafJe = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.language.code')
	QQvOnYi9sJMwp7dIxeck8DRASWuBt(WSgQvHLx9uOKTksaCt2JchldRj,'MENUS_CACHE_'+yLhu2x01UkCdMjnGf7PZzK4+'_'+GLzgtpD2bm7icFokafJe,'%_IP'+L96HvDd3sfBiCSRT+'_%')
	return
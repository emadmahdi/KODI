# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'SHIAVOICE'
Yc0eBRLpbCkm4gK7OqyzuHwU = '_SHV_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
headers = {'User-Agent':None}
def HgQCVwFx2Br(mode,url,text):
	if   mode==310: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==311: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url)
	elif mode==312: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==313: s4Bng5iAZQSTtpDw9 = zlXQwAcO9mZPN4hMuBvIojW8iSER(url)
	elif mode==314: s4Bng5iAZQSTtpDw9 = QDvSPAW6cY(text)
	elif mode==319: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',319,'','','_REMEMBERRESULTS_')
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',tle5V6jgvRfE,'','','','','SHIAVOICE-MENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('id="menulinks"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<h5>(.*?)</h5>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.IGNORECASE)
	for iHnuAqRYNm in range(len(items)):
		title = items[iHnuAqRYNm].strip(' ')
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,tle5V6jgvRfE,314,'','',str(iHnuAqRYNm+1))
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'مقاطع شهر',tle5V6jgvRfE,314,'','','0')
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?<B>(.*?)</B>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,311)
	return M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
def QDvSPAW6cY(iHnuAqRYNm):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',tle5V6jgvRfE,'','','','','SHIAVOICE-LATEST-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	if iHnuAqRYNm=='0':
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="tab-content"(.*?)</table>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,name,title in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			title = title.strip(' ')
			name = name.strip(' ')
			title = title+' ('+name+')'
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,312)
	elif iHnuAqRYNm in ['1','2','3']:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(<h5>.*?)<div class="col-lg',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		cc89S3hUmrOEaRlW5z = int(iHnuAqRYNm)-1
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[cc89S3hUmrOEaRlW5z]
		if iHnuAqRYNm=='1': items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		else: items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title,name in items:
			Q2qmuDRrC9ikcaJK7gtUHXNW = tle5V6jgvRfE+'/'+Q2qmuDRrC9ikcaJK7gtUHXNW
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			title = title.strip(' ')
			name = name.strip(' ')
			title = title+' ('+name+')'
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,311,Q2qmuDRrC9ikcaJK7gtUHXNW)
	elif iHnuAqRYNm in ['4','5','6']:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(<h5>.*?)</table>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		iHnuAqRYNm = int(iHnuAqRYNm)-4
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[iHnuAqRYNm]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for Q2qmuDRrC9ikcaJK7gtUHXNW,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,O4KxfYcQGenF,title,SSJLGwYsC5qz3bnku9IpyfX in items:
			Q2qmuDRrC9ikcaJK7gtUHXNW = tle5V6jgvRfE+'/'+Q2qmuDRrC9ikcaJK7gtUHXNW
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			title = title.strip(' ')
			O4KxfYcQGenF = O4KxfYcQGenF.strip(' ')
			SSJLGwYsC5qz3bnku9IpyfX = SSJLGwYsC5qz3bnku9IpyfX.strip(' ')
			if O4KxfYcQGenF: name = O4KxfYcQGenF
			else: name = SSJLGwYsC5qz3bnku9IpyfX
			title = title+' ('+name+')'
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,312,Q2qmuDRrC9ikcaJK7gtUHXNW)
	return
def uyt3pAHZk4(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','SHIAVOICE-TITLES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('ibox-heading"(.*?)class="float-right',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	if 'catsum-mobile' in ziJLDVT8NM2QcgIpmE9A:
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if items:
			for Q2qmuDRrC9ikcaJK7gtUHXNW,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,count in items:
				Q2qmuDRrC9ikcaJK7gtUHXNW = tle5V6jgvRfE+'/'+Q2qmuDRrC9ikcaJK7gtUHXNW
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
				count = count.replace(' الصوتية: ',':')
				title = title.strip(' ')
				title = title+' ('+count+')'
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,311,Q2qmuDRrC9ikcaJK7gtUHXNW)
	else:
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,nnVHREfvQMKwyb,s6z12JQXUyK5Wn4Bf7LYiDIP9F in items:
			if title=='' or nnVHREfvQMKwyb=='': continue
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			title = title+' ('+s6z12JQXUyK5Wn4Bf7LYiDIP9F+')'
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,312)
	if not items: btd6ag2XYUkHixqy5J7o9RfLu1MScm(M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2)
	return
def btd6ag2XYUkHixqy5J7o9RfLu1MScm(M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2):
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="ibox-content"(.*?)class="pagination',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,name,count,s6z12JQXUyK5Wn4Bf7LYiDIP9F in items:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		title = title.strip(' ')
		name = name.strip(' ')
		title = title+' ('+name+')'
		tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,312,'',s6z12JQXUyK5Wn4Bf7LYiDIP9F)
	return
def zlXQwAcO9mZPN4hMuBvIojW8iSER(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','SHIAVOICE-SEARCH_ITEMS-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="ibox-content p-1"(.*?)class="ibox-content"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not TIkiozSLCv6werb97mHQ0q4y3:
		uyt3pAHZk4(url)
		return
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?<strong>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		title = title.strip(' ')
		if '/play-' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,312)
		else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,311)
	return
def dlropqS0vO9K7W4z(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',url,'','','','','SHIAVOICE-PLAY-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<audio.*?src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<video.*?src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]
	pSAuLjYqhgc9brWFKs7Pa4J(ZCimQhV5lovgspAYzHq1Ef27u8ja4R,r1NChsk39OMvT82YemDQnl5,'video')
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if search=='': search = UIf35nZEj1wylmq()
	if search=='': return
	search = search.replace(' ','+')
	qqFi2p9dEHCGOxhtrDczvfAL = ['&t=a','&t=c','&t=s']
	if showDialogs:
		w1bAhj5aTGRsND84YBVkoF3Jxe = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql('موقع صوت الشيعة - أختر البحث', w1bAhj5aTGRsND84YBVkoF3Jxe)
		if NljOosKT8WJBpch == -1: return
	elif '_SHIAVOICE-PERSONS_' in dNlVai6Obj1e: NljOosKT8WJBpch = 0
	elif '_SHIAVOICE-ALBUMS_' in dNlVai6Obj1e: NljOosKT8WJBpch = 1
	elif '_SHIAVOICE-AUDIOS_' in dNlVai6Obj1e: NljOosKT8WJBpch = 2
	else: return
	type = qqFi2p9dEHCGOxhtrDczvfAL[NljOosKT8WJBpch]
	url = tle5V6jgvRfE+'/search.php?q='+search+type
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','SHIAVOICE-SEARCH-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="ibox-content"(.*?)class="ibox-content"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		if NljOosKT8WJBpch in [0,1]:
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title,name in items:
				title = title.strip(' ')
				name = name.strip(' ')
				title = title+' ('+name+')'
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,313,Q2qmuDRrC9ikcaJK7gtUHXNW)
		elif NljOosKT8WJBpch==2:
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,name in items:
				title = title.strip(' ')
				name = name.strip(' ')
				title = title+' ('+name+')'
				tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,312)
	return
# -*- coding: utf-8 -*-
import sys as EAPND6zHKrMRuBc91tInYohsl0ywa
ttRJUcM0Tbr7gXN5x = EAPND6zHKrMRuBc91tInYohsl0ywa.version_info [0] == 2
Z2h7adALoKv4UPc1y = 2048
K2KPeD6VyEaQ = 7
def dC3HqaFgt6QYG4 (jZYXLbSUsQp5uk1tyzBAN7Hm):
	global ZeIJ6GDodMSzFut4jc05AK3OlhETR
	HY5UkLeNComBIMQPASnxph7 = ord (jZYXLbSUsQp5uk1tyzBAN7Hm [-1])
	PlVdbOK5hqks = jZYXLbSUsQp5uk1tyzBAN7Hm [:-1]
	prvC9qsF5RtBXHiaT3PwdJ = HY5UkLeNComBIMQPASnxph7 % len (PlVdbOK5hqks)
	LQB6POHcivdw87pk09ts2XMyf1IVEh = PlVdbOK5hqks [:prvC9qsF5RtBXHiaT3PwdJ] + PlVdbOK5hqks [prvC9qsF5RtBXHiaT3PwdJ:]
	if ttRJUcM0Tbr7gXN5x:
		Gn0XReKiJFMEsUxN531yAlI7S = unicode () .join ([unichr (ord (AitBMapzjZGc4u) - Z2h7adALoKv4UPc1y - (KQsX4n7jEogiLuJz + HY5UkLeNComBIMQPASnxph7) % K2KPeD6VyEaQ) for KQsX4n7jEogiLuJz, AitBMapzjZGc4u in enumerate (LQB6POHcivdw87pk09ts2XMyf1IVEh)])
	else:
		Gn0XReKiJFMEsUxN531yAlI7S = str () .join ([chr (ord (AitBMapzjZGc4u) - Z2h7adALoKv4UPc1y - (KQsX4n7jEogiLuJz + HY5UkLeNComBIMQPASnxph7) % K2KPeD6VyEaQ) for KQsX4n7jEogiLuJz, AitBMapzjZGc4u in enumerate (LQB6POHcivdw87pk09ts2XMyf1IVEh)])
	return eval (Gn0XReKiJFMEsUxN531yAlI7S)
I7N2lHpGfLPkwKxbOu6raYUgc5,QmoEjB3hLIw,WbM6qAjrn7fEXGZw=dC3HqaFgt6QYG4,dC3HqaFgt6QYG4,dC3HqaFgt6QYG4
bbqAtUz36RPGVTvCkejpJXQB,MM564HfnUV0XIR,YDC9i52g6e8XL7GxvIFnSKWsolpr=WbM6qAjrn7fEXGZw,QmoEjB3hLIw,I7N2lHpGfLPkwKxbOu6raYUgc5
YZFXwtrfK8uhzV4LlMEqgnCQyO9,tmcuvd397wjGXeWoDHMNpFB5h2VK,Ox8k6IdtuPaG3NlApQK52oYwM=YDC9i52g6e8XL7GxvIFnSKWsolpr,MM564HfnUV0XIR,bbqAtUz36RPGVTvCkejpJXQB
GGCQK6OAtZUXRhvkgJm,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6,Gk98CL5nXZEN=Ox8k6IdtuPaG3NlApQK52oYwM,tmcuvd397wjGXeWoDHMNpFB5h2VK,YZFXwtrfK8uhzV4LlMEqgnCQyO9
dEUYJjrhsaPXNo,wx18CTJPZ5,cWfQ64kVCqxhwvSy5P7irHI1oes3=Gk98CL5nXZEN,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6,GGCQK6OAtZUXRhvkgJm
qFRrj7ayBKbOsHGSXz,SIDG7cnzAaUpkwmNde19ZsBqQ3Hh,tOdiG2HWFRBXg1sUh=cWfQ64kVCqxhwvSy5P7irHI1oes3,wx18CTJPZ5,dEUYJjrhsaPXNo
smpniPDOhfwI3H4v7c6TG,CIcPowhneWs5tN3,zxwIDBrPiXjKlsYkfg0AGaUZSyW2co=tOdiG2HWFRBXg1sUh,SIDG7cnzAaUpkwmNde19ZsBqQ3Hh,qFRrj7ayBKbOsHGSXz
r6juULGQtnExAko38BZ5Y,NNmirJKPp5nWjfC,FeyZbj8tDil0nSHzTwfsUJ9=zxwIDBrPiXjKlsYkfg0AGaUZSyW2co,CIcPowhneWs5tN3,smpniPDOhfwI3H4v7c6TG
S26SnaqcM9XwK8PVphJDv5,CgPbwXm1RilpJUSGHLhy,NxsKJnLFEZ9OHXf1h=FeyZbj8tDil0nSHzTwfsUJ9,NNmirJKPp5nWjfC,r6juULGQtnExAko38BZ5Y
Kwl07iYTtDLN3zP,uAl3gHavMJZL4xmNe62nDiBoQ,ta478EuZQJIWhgBnsf6iU=NxsKJnLFEZ9OHXf1h,CgPbwXm1RilpJUSGHLhy,S26SnaqcM9XwK8PVphJDv5
EAw9bg4rT3Bd8tjSkO,ItgK5FqGDz2Rf7mAJkbT,FFVuCHLxhZmkEGJQDitreaygc2f4AS=ta478EuZQJIWhgBnsf6iU,uAl3gHavMJZL4xmNe62nDiBoQ,Kwl07iYTtDLN3zP
from JnFs5LSwMp import *
r1NChsk39OMvT82YemDQnl5 = YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠧࡊࡐࡌࡘࠬૢ")
y75wQavkVSLUb2MZf9qo(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠨࡐࡒࡘࡎࡉࡅࠨૣ"),smpniPDOhfwI3H4v7c6TG(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠩ૤"))
zPEbGfWv2ehc1Akr4tiR = VVuCNFHGiUftREgnP4Aw(mpUuAaIVfPRoQEligGywDYz1)
Rl48v7kIh3cgF1fzOS6mQ9,TDmqAUj2Mfyir0PvS,pAeIhbuLSFw7j49qxtcg8dDrmKO,sBjdZmqit76bCRPyFLaQ5V1v,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,hfNZTDrYABwyVcJQlqPS48xpHIi7s,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH = zPEbGfWv2ehc1Akr4tiR
jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU = int(sBjdZmqit76bCRPyFLaQ5V1v)
JNuHrgRwE8K0hcdMBtQl = oos8ymFi9CN2z1jXcR.getInfoLabel(tOdiG2HWFRBXg1sUh(u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫ૥"))
JNuHrgRwE8K0hcdMBtQl = JNuHrgRwE8K0hcdMBtQl.replace(W3oZ8vhLnsOdIaDp6qeN214kcJCVz,cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠫࠬ૦")).replace(HwksZdFnbNg3Pr,MM564HfnUV0XIR(u"ࠬ࠭૧"))
if jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU==EAw9bg4rT3Bd8tjSkO(u"࠵࠺࠵ଏ"): EiMsPpS3O1Ba = FeyZbj8tDil0nSHzTwfsUJ9(u"࡙࠭ࠠࠡࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࡠࠦࠧ૨")+VnhK9wvHBGuo1fei8DXQ02yFZtsWE+YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠧࠡ࡟ࠣࠤࠥࡑ࡯ࡥ࡫࠽ࠤࡠࠦࠧ૩")+iAqf1sZuQ0wXEndaG+Kwl07iYTtDLN3zP(u"ࠨࠢࡠࠫ૪")
else:
	S9TJ4Oajtv1VeZChKRMNycwxWupY = BUTSkzgFC7(mpUuAaIVfPRoQEligGywDYz1).replace(WbM6qAjrn7fEXGZw(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ૫"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠪࠫ૬")).replace(bbqAtUz36RPGVTvCkejpJXQB(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ૭"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠬ࠭૮"))
	S9TJ4Oajtv1VeZChKRMNycwxWupY = S9TJ4Oajtv1VeZChKRMNycwxWupY.replace(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ૯"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠧࠨ૰")).strip(ta478EuZQJIWhgBnsf6iU(u"ࠨࠢࠪ૱"))
	S9TJ4Oajtv1VeZChKRMNycwxWupY = S9TJ4Oajtv1VeZChKRMNycwxWupY.replace(NxsKJnLFEZ9OHXf1h(u"ࠩࠣࠤࠥࠦࠧ૲"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠪࠤࠬ૳")).replace(CgPbwXm1RilpJUSGHLhy(u"ࠫࠥࠦࠠࠨ૴"),r6juULGQtnExAko38BZ5Y(u"ࠬࠦࠧ૵")).replace(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠭ࠠࠡࠩ૶"),CgPbwXm1RilpJUSGHLhy(u"ࠧࠡࠩ૷"))
	EiMsPpS3O1Ba = SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠨࠢࠣࠤࡑࡧࡢࡦ࡮࠽ࠤࡠࠦࠧ૸")+JNuHrgRwE8K0hcdMBtQl+tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠩࠣࡡࠥࠦࠠࡎࡱࡧࡩ࠿࡛ࠦࠡࠩૹ")+sBjdZmqit76bCRPyFLaQ5V1v+GGCQK6OAtZUXRhvkgJm(u"ࠪࠤࡢࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪૺ")+S9TJ4Oajtv1VeZChKRMNycwxWupY+zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠫࠥࡣࠧૻ")
y75wQavkVSLUb2MZf9qo(CgPbwXm1RilpJUSGHLhy(u"ࠬࡔࡏࡕࡋࡆࡉࠬૼ"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+EiMsPpS3O1Ba)
V8VRKYUXlcz = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(Kwl07iYTtDLN3zP(u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪ૽"))
l4lTvZF0Uy1dn = dEUYJjrhsaPXNo(u"ࡈࡤࡰࡸ࡫କ") if V8VRKYUXlcz==VnhK9wvHBGuo1fei8DXQ02yFZtsWE else ta478EuZQJIWhgBnsf6iU(u"ࡕࡴࡸࡩଔ")
if not l4lTvZF0Uy1dn and jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU in [ta478EuZQJIWhgBnsf6iU(u"࠶࠸࠻ଐ"),wx18CTJPZ5(u"࠼࠷࠵଑")]:
	FcTdplGwy7AZV1bosj = str(zSPVUW1XDt2Ba6ZkAH[YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ૾")])
	r1NChsk39OMvT82YemDQnl5 = wx18CTJPZ5(u"ࠨ࡫ࡳࡸࡻ࠭૿") if jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU==wx18CTJPZ5(u"࠸࠳࠶଒") else tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠩࡰ࠷ࡺ࠭଀")
	PPGUinpWfm6Xw9NLtbcax53IQ = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(ItgK5FqGDz2Rf7mAJkbT(u"ࠪࡥࡻ࠴ࠧଁ")+r1NChsk39OMvT82YemDQnl5+zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠫ࠳ࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡠࠩଂ")+FcTdplGwy7AZV1bosj)
	Etp7WHcwVuXo51k2KPLzMamIQySxfZ = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(Gk98CL5nXZEN(u"ࠬࡧࡶ࠯ࠩଃ")+r1NChsk39OMvT82YemDQnl5+NxsKJnLFEZ9OHXf1h(u"࠭࠮ࡳࡧࡩࡩࡷ࡫ࡲࡠࠩ଄")+FcTdplGwy7AZV1bosj)
	if PPGUinpWfm6Xw9NLtbcax53IQ or Etp7WHcwVuXo51k2KPLzMamIQySxfZ:
		pAeIhbuLSFw7j49qxtcg8dDrmKO += cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠧࡽࠩଅ")
		if PPGUinpWfm6Xw9NLtbcax53IQ: pAeIhbuLSFw7j49qxtcg8dDrmKO += NxsKJnLFEZ9OHXf1h(u"ࠨࠨࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧଆ")+PPGUinpWfm6Xw9NLtbcax53IQ
		if Etp7WHcwVuXo51k2KPLzMamIQySxfZ: pAeIhbuLSFw7j49qxtcg8dDrmKO += r6juULGQtnExAko38BZ5Y(u"ࠩࠩࡖࡪ࡬ࡥࡳࡧࡵࡁࠬଇ")+Etp7WHcwVuXo51k2KPLzMamIQySxfZ
		pAeIhbuLSFw7j49qxtcg8dDrmKO = pAeIhbuLSFw7j49qxtcg8dDrmKO.replace(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠪࢀࠫ࠭ଈ"),GGCQK6OAtZUXRhvkgJm(u"ࠫࢁ࠭ଉ"))
	P3PIO7cyqYgVpXvwimaeHLzx2CftJ = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(tOdiG2HWFRBXg1sUh(u"ࠬࡧࡶ࠯ࠩଊ")+r1NChsk39OMvT82YemDQnl5+CgPbwXm1RilpJUSGHLhy(u"࠭࠮ࡴࡧࡵࡺࡪࡸ࡟ࠨଋ")+FcTdplGwy7AZV1bosj)
	if P3PIO7cyqYgVpXvwimaeHLzx2CftJ:
		JrXckv13Egz2uC = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(Kwl07iYTtDLN3zP(u"ࠧ࠻࠱࠲ࠬ࠳࠰࠿ࠪ࠱ࠪଌ"),pAeIhbuLSFw7j49qxtcg8dDrmKO,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		pAeIhbuLSFw7j49qxtcg8dDrmKO = pAeIhbuLSFw7j49qxtcg8dDrmKO.replace(JrXckv13Egz2uC[r6juULGQtnExAko38BZ5Y(u"࠰ଓ")],P3PIO7cyqYgVpXvwimaeHLzx2CftJ)
	r1NChsk39OMvT82YemDQnl5 = r1NChsk39OMvT82YemDQnl5.upper()
	pSAuLjYqhgc9brWFKs7Pa4J(pAeIhbuLSFw7j49qxtcg8dDrmKO,r1NChsk39OMvT82YemDQnl5,Rl48v7kIh3cgF1fzOS6mQ9)
else:
	from zbUtu6IvKA import YyexoUV8ZWpMXsRir1wAm69QPJKnN,mmPvBhbOdr3z9QcwqJCE8euftpxZML,knv97FU12sdyuZXGCa
	jbDMGZeVf2RyJ8OxFA94Emu3pgo0St = GGCQK6OAtZUXRhvkgJm(u"ࠨࠩ଍")
	YyexoUV8ZWpMXsRir1wAm69QPJKnN(FeyZbj8tDil0nSHzTwfsUJ9(u"ࠩࡶࡸࡦࡸࡴࠨ଎"))
	try: mmPvBhbOdr3z9QcwqJCE8euftpxZML(zPEbGfWv2ehc1Akr4tiR,JNuHrgRwE8K0hcdMBtQl)
	except Exception as E9IA4lBOyNJf: jbDMGZeVf2RyJ8OxFA94Emu3pgo0St = oo5q9yuEdbCeOSxfzJcw.format_exc()
	knv97FU12sdyuZXGCa(jbDMGZeVf2RyJ8OxFA94Emu3pgo0St)
# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'SHAHIDNEWS'
Yc0eBRLpbCkm4gK7OqyzuHwU = '_SHN_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
ZLKHfqMEUdRupD = ['قنوات فضائية','فارسكو','Show more']
def HgQCVwFx2Br(mode,url,text):
	if   mode==580: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==581: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url,text)
	elif mode==582: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==583: s4Bng5iAZQSTtpDw9 = btd6ag2XYUkHixqy5J7o9RfLu1MScm(url,text)
	elif mode==584: s4Bng5iAZQSTtpDw9 = AJDL0Mp13fQkRH5c(url)
	elif mode==589: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',tle5V6jgvRfE,'','','','','SHAHIDNEWS-MENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',589,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('/category.php">(.*?)"navslide-divider"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("'dropdown-menu'(.*?)</ul>",M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for f9AzGuXj0qgcNTy1 in TIkiozSLCv6werb97mHQ0q4y3: ziJLDVT8NM2QcgIpmE9A = ziJLDVT8NM2QcgIpmE9A.replace(f9AzGuXj0qgcNTy1,'')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?>(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		if title in ZLKHfqMEUdRupD: continue
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,584)
	return
def AJDL0Mp13fQkRH5c(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','SHAHIDNEWS-SUBMENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	rrNex9MVQDgqIW4kFoSyslw = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"caret"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if rrNex9MVQDgqIW4kFoSyslw:
		ziJLDVT8NM2QcgIpmE9A = rrNex9MVQDgqIW4kFoSyslw[0]
		ziJLDVT8NM2QcgIpmE9A = ziJLDVT8NM2QcgIpmE9A.replace('"presentation"','</ul>')
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if not TIkiozSLCv6werb97mHQ0q4y3: TIkiozSLCv6werb97mHQ0q4y3 = [('',ziJLDVT8NM2QcgIpmE9A)]
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] فرز أو فلتر أو ترتيب [/COLOR]','',9999)
		for Pym8Gxuq1VJE3Yrk,ziJLDVT8NM2QcgIpmE9A in TIkiozSLCv6werb97mHQ0q4y3:
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?>(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if Pym8Gxuq1VJE3Yrk: Pym8Gxuq1VJE3Yrk = Pym8Gxuq1VJE3Yrk+': '
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
				title = Pym8Gxuq1VJE3Yrk+title
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,581)
	rNQC9lGIxW3d0oB6AjUfD5LbRF = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"pm-category-subcats"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if rNQC9lGIxW3d0oB6AjUfD5LbRF:
		ziJLDVT8NM2QcgIpmE9A = rNQC9lGIxW3d0oB6AjUfD5LbRF[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)">(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if len(items)<30:
			tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,581)
	if not rrNex9MVQDgqIW4kFoSyslw and not rNQC9lGIxW3d0oB6AjUfD5LbRF: uyt3pAHZk4(url)
	return
def uyt3pAHZk4(url,VWi2dTb46v3eOryuspKBF9L=''):
	dkgwyUKEpTtPeMxs68aib = SLMTm6RQ34ic7v5s9rBG(url,'url')
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','SHAHIDNEWS-TITLES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	items = []
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(data-echo=".*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not TIkiozSLCv6werb97mHQ0q4y3: TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"BlocksList"(.*?)"titleSectionCon"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not TIkiozSLCv6werb97mHQ0q4y3: TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('id="pm-grid"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not TIkiozSLCv6werb97mHQ0q4y3: TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('id="pm-related"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not TIkiozSLCv6werb97mHQ0q4y3: return
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	if not items: items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not items: items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	jjR8ftoEXpPxVF6JerbHZuzv7ic = []
	G1ezKuLr3SlXd9OVkMNQs6FWvf8Aip = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for Q2qmuDRrC9ikcaJK7gtUHXNW,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = BUTSkzgFC7(ZCimQhV5lovgspAYzHq1Ef27u8ja4R).strip('/')
		if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = dkgwyUKEpTtPeMxs68aib+'/'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R.strip('/')
		if 'http' not in Q2qmuDRrC9ikcaJK7gtUHXNW: Q2qmuDRrC9ikcaJK7gtUHXNW = dkgwyUKEpTtPeMxs68aib+'/'+Q2qmuDRrC9ikcaJK7gtUHXNW.strip('/')
		EQw62xjXSJmzrRt = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(.*?) الحلقة \d+',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title for hht0cpXxWw2OzFS1jnUGebkJLBd85 in G1ezKuLr3SlXd9OVkMNQs6FWvf8Aip):
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,582,Q2qmuDRrC9ikcaJK7gtUHXNW)
		elif EQw62xjXSJmzrRt and 'الحلقة' in title:
			title = '_MOD_' + EQw62xjXSJmzrRt[0]
			if title not in jjR8ftoEXpPxVF6JerbHZuzv7ic:
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,583,Q2qmuDRrC9ikcaJK7gtUHXNW)
				jjR8ftoEXpPxVF6JerbHZuzv7ic.append(title)
		elif '/movseries/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,581,Q2qmuDRrC9ikcaJK7gtUHXNW)
		else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,583,Q2qmuDRrC9ikcaJK7gtUHXNW)
	if VWi2dTb46v3eOryuspKBF9L not in ['featured_movies','featured_series']:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"pagination(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3:
			ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?>(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
				if ZCimQhV5lovgspAYzHq1Ef27u8ja4R=='#': continue
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = dkgwyUKEpTtPeMxs68aib+'/'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R.strip('/')
				title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,581)
		rrpPgGwmLCnJeEDdXs0NlfUb9R5 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('showmore" href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if rrpPgGwmLCnJeEDdXs0NlfUb9R5:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = rrpPgGwmLCnJeEDdXs0NlfUb9R5[0]
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مشاهدة المزيد',ZCimQhV5lovgspAYzHq1Ef27u8ja4R,581)
	return
def btd6ag2XYUkHixqy5J7o9RfLu1MScm(url,aS2RYLwdgkBue5t7HPs9VMf):
	dkgwyUKEpTtPeMxs68aib = SLMTm6RQ34ic7v5s9rBG(url,'url')
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','SHAHIDNEWS-EPISODES-2nd')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	rrNex9MVQDgqIW4kFoSyslw = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('nav-seasons"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	items = []
	jl1QvRLFeBXH5qn0wxZc = False
	if rrNex9MVQDgqIW4kFoSyslw and not aS2RYLwdgkBue5t7HPs9VMf:
		ziJLDVT8NM2QcgIpmE9A = rrNex9MVQDgqIW4kFoSyslw[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)">(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for aS2RYLwdgkBue5t7HPs9VMf,title in items:
			aS2RYLwdgkBue5t7HPs9VMf = aS2RYLwdgkBue5t7HPs9VMf.strip('#')
			if len(items)>1: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,583,'','',aS2RYLwdgkBue5t7HPs9VMf)
			else: jl1QvRLFeBXH5qn0wxZc = True
	else: jl1QvRLFeBXH5qn0wxZc = True
	rNQC9lGIxW3d0oB6AjUfD5LbRF = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('id="'+aS2RYLwdgkBue5t7HPs9VMf+'"(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if rNQC9lGIxW3d0oB6AjUfD5LbRF and jl1QvRLFeBXH5qn0wxZc:
		ziJLDVT8NM2QcgIpmE9A = rNQC9lGIxW3d0oB6AjUfD5LbRF[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?">(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if items:
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = dkgwyUKEpTtPeMxs68aib+'/'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R.strip('/')
				tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,582)
		else:
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,Q2qmuDRrC9ikcaJK7gtUHXNW in items:
				if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = dkgwyUKEpTtPeMxs68aib+'/'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R.strip('/')
				tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,582)
	return
def dlropqS0vO9K7W4z(url):
	dkgwyUKEpTtPeMxs68aib = SLMTm6RQ34ic7v5s9rBG(url,'url')
	jVMHRouKgQFAESmd7B8ObTYy = []
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','SHAHIDNEWS-PLAY-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"Playerholder".*?href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]
	if ZCimQhV5lovgspAYzHq1Ef27u8ja4R and 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = 'http:'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
	hash = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('hash=')[1]
	oBzGqDUAi7KaL8vFdZtP9XIcf = hash.split('__')
	F8LcPevGNgTVtjWJZy50Sqszhk = []
	for SSk6vDuLd9TRarA1elm in oBzGqDUAi7KaL8vFdZtP9XIcf:
		try:
			SSk6vDuLd9TRarA1elm = SSNcdhMguvEw0RY.b64decode(SSk6vDuLd9TRarA1elm+'=')
			if wvkR1es6d0SrjxKt5FZTMUWz7a: SSk6vDuLd9TRarA1elm = SSk6vDuLd9TRarA1elm.decode('utf8')
			F8LcPevGNgTVtjWJZy50Sqszhk.append(SSk6vDuLd9TRarA1elm)
		except: pass
	cc0O1M4e5jtfoq = '>'.join(F8LcPevGNgTVtjWJZy50Sqszhk)
	cc0O1M4e5jtfoq = cc0O1M4e5jtfoq.splitlines()
	if 'farsol' not in str(cc0O1M4e5jtfoq):
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R in cc0O1M4e5jtfoq:
			title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split(' => ')
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+title+'__watch'
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
		import JYR902sfml
		JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt(jVMHRouKgQFAESmd7B8ObTYy,r1NChsk39OMvT82YemDQnl5,'video',url)
	else:
		title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R = cc0O1M4e5jtfoq[0].split(' => ')
		tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','هذا الفيديو غير متوفر الآن'+'\n'+'يرجى المحاولة لاحقا'+'\n\n'+title)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if search=='': search = UIf35nZEj1wylmq()
	if search=='': return
	search = search.replace(' ','+')
	url = tle5V6jgvRfE+'/search.php?keywords='+search
	uyt3pAHZk4(url)
	return
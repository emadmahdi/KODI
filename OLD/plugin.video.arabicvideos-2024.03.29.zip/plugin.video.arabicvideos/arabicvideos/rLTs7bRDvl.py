# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'CIMAFANS'
headers = { 'User-Agent' : '' }
Yc0eBRLpbCkm4gK7OqyzuHwU = '_CMF_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
def HgQCVwFx2Br(mode,url,text):
	if   mode==90: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==91: s4Bng5iAZQSTtpDw9 = Hb39UqlX2fZDpc(url)
	elif mode==92: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==94: s4Bng5iAZQSTtpDw9 = QDvSPAW6cY()
	elif mode==95: s4Bng5iAZQSTtpDw9 = btd6ag2XYUkHixqy5J7o9RfLu1MScm(url)
	elif mode==99: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',99,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'المضاف حديثا','',94)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'الأحدث',tle5V6jgvRfE+'/?type=latest',91)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'الأعلى تقيماً',tle5V6jgvRfE+'/?type=imdb',91)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'الأكثر مشاهدة',tle5V6jgvRfE+'/?type=view',91)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'المثبت',tle5V6jgvRfE+'/?type=pin',91)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'جديد الأفلام',tle5V6jgvRfE+'/?type=newMovies',91)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'جديد الحلقات',tle5V6jgvRfE+'/?type=newEpisodes',91)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,tle5V6jgvRfE,'',headers,'','CIMAFANS-MENU-1st')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="mainmenu(.*?)nav',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<li><a href="(.*?)".*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ZLKHfqMEUdRupD = ['افلام للكبار فقط']
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		title = title.strip(' ')
		if not any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title for hht0cpXxWw2OzFS1jnUGebkJLBd85 in ZLKHfqMEUdRupD):
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,91)
	return M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
def Hb39UqlX2fZDpc(url):
	if '/search.php' in url:
		url,search = url.split('?t=')
		headers = { 'User-Agent' : '' , 'Content-Type' : 'application/x-www-form-urlencoded' }
		data = { 't' : search }
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'POST',url,data,headers,'','','CIMAFANS-ITEMS-1st')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	else:
		headers = { 'User-Agent' : '' }
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,url,'',headers,'','CIMAFANS-ITEMS-2nd')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('id="movies-items(.*?)class="listfoot"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3: ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	else: ziJLDVT8NM2QcgIpmE9A = ''
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('background-image:url\((.*?)\).*?href="(.*?)".*?movie-title">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	jjR8ftoEXpPxVF6JerbHZuzv7ic = []
	for Q2qmuDRrC9ikcaJK7gtUHXNW,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		if 'الحلقة' in title and '/c/' not in url and '/cat/' not in url:
			EQw62xjXSJmzrRt = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(.*?) الحلقة [0-9]+',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if EQw62xjXSJmzrRt:
				title = '_MOD_'+EQw62xjXSJmzrRt[0]
				if title not in jjR8ftoEXpPxVF6JerbHZuzv7ic:
					tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,95,Q2qmuDRrC9ikcaJK7gtUHXNW)
					jjR8ftoEXpPxVF6JerbHZuzv7ic.append(title)
		elif '/video/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,92,Q2qmuDRrC9ikcaJK7gtUHXNW)
		else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,91,Q2qmuDRrC9ikcaJK7gtUHXNW)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="pagination(.*?)div',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<a href="(.*?)".*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
			title = title.replace('الصفحة ','')
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,91)
	return
def btd6ag2XYUkHixqy5J7o9RfLu1MScm(url):
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,url,'',headers,'','CIMAFANS-EPISODES-1st')
	Q2qmuDRrC9ikcaJK7gtUHXNW = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('img src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	Q2qmuDRrC9ikcaJK7gtUHXNW = Q2qmuDRrC9ikcaJK7gtUHXNW[0]
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('id="episodes-panel(.*?)div',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		name = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('itemprop="title">(.*?)<',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if name: name = name[1]
		else:
			name = oos8ymFi9CN2z1jXcR.getInfoLabel('ListItem.Label')
			if '[/COLOR]' in name: name = name.split('[/COLOR]',1)[1]
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?name">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+name+' - '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,92,Q2qmuDRrC9ikcaJK7gtUHXNW)
	else:
		e1ebv6pD8mUitJkPXqwnjr = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="movietitle"><a href="(.*?)">(.*?)<',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if e1ebv6pD8mUitJkPXqwnjr: ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title = e1ebv6pD8mUitJkPXqwnjr[0]
		else: ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title = url,name
		tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,92,Q2qmuDRrC9ikcaJK7gtUHXNW)
	return
def dlropqS0vO9K7W4z(url):
	jVMHRouKgQFAESmd7B8ObTYy,Kygp5N1s2R48xrFHJ6Pfm = [],[]
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,url,'',headers,'','CIMAFANS-PLAY-1st')
	VnK1wPrcHoN8ex2Bl0pLS = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('text-shadow: none;">(.*?)<',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if VnK1wPrcHoN8ex2Bl0pLS and Y1Yz6bZMLDaGjpxK3fSXm7TurCnHwo(r1NChsk39OMvT82YemDQnl5,url,VnK1wPrcHoN8ex2Bl0pLS): return
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('id="links-panel(.*?)div',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?__download'
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('nav-tabs"(.*?)video-panel-more',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('id="(.*?)".*?embed src="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for id,ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
			title = 'سيرفر '+id
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+title+'__watch'
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-server-src="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
			if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = 'http:'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = BUTSkzgFC7(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	import JYR902sfml
	JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt(jVMHRouKgQFAESmd7B8ObTYy,r1NChsk39OMvT82YemDQnl5,'video',url)
	return
def QDvSPAW6cY():
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,tle5V6jgvRfE,'',headers,'','CIMAFANS-LATEST-1st')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('id="index-last-movie(.*?)id="index-slider-movie',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('src="(.*?)".*?href="(.*?)" title="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for Q2qmuDRrC9ikcaJK7gtUHXNW,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		if '/video/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,92,Q2qmuDRrC9ikcaJK7gtUHXNW)
		else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,91,Q2qmuDRrC9ikcaJK7gtUHXNW)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if search=='': search = UIf35nZEj1wylmq()
	if search=='': return
	search = search.replace(' ','+')
	url = tle5V6jgvRfE + '/search.php?t='+search
	Hb39UqlX2fZDpc(url)
	return
# -*- coding: utf-8 -*-
import sys as EAPND6zHKrMRuBc91tInYohsl0ywa
ttRJUcM0Tbr7gXN5x = EAPND6zHKrMRuBc91tInYohsl0ywa.version_info [0] == 2
Z2h7adALoKv4UPc1y = 2048
K2KPeD6VyEaQ = 7
def dC3HqaFgt6QYG4 (jZYXLbSUsQp5uk1tyzBAN7Hm):
	global ZeIJ6GDodMSzFut4jc05AK3OlhETR
	HY5UkLeNComBIMQPASnxph7 = ord (jZYXLbSUsQp5uk1tyzBAN7Hm [-1])
	PlVdbOK5hqks = jZYXLbSUsQp5uk1tyzBAN7Hm [:-1]
	prvC9qsF5RtBXHiaT3PwdJ = HY5UkLeNComBIMQPASnxph7 % len (PlVdbOK5hqks)
	LQB6POHcivdw87pk09ts2XMyf1IVEh = PlVdbOK5hqks [:prvC9qsF5RtBXHiaT3PwdJ] + PlVdbOK5hqks [prvC9qsF5RtBXHiaT3PwdJ:]
	if ttRJUcM0Tbr7gXN5x:
		Gn0XReKiJFMEsUxN531yAlI7S = unicode () .join ([unichr (ord (AitBMapzjZGc4u) - Z2h7adALoKv4UPc1y - (KQsX4n7jEogiLuJz + HY5UkLeNComBIMQPASnxph7) % K2KPeD6VyEaQ) for KQsX4n7jEogiLuJz, AitBMapzjZGc4u in enumerate (LQB6POHcivdw87pk09ts2XMyf1IVEh)])
	else:
		Gn0XReKiJFMEsUxN531yAlI7S = str () .join ([chr (ord (AitBMapzjZGc4u) - Z2h7adALoKv4UPc1y - (KQsX4n7jEogiLuJz + HY5UkLeNComBIMQPASnxph7) % K2KPeD6VyEaQ) for KQsX4n7jEogiLuJz, AitBMapzjZGc4u in enumerate (LQB6POHcivdw87pk09ts2XMyf1IVEh)])
	return eval (Gn0XReKiJFMEsUxN531yAlI7S)
I7N2lHpGfLPkwKxbOu6raYUgc5,QmoEjB3hLIw,WbM6qAjrn7fEXGZw=dC3HqaFgt6QYG4,dC3HqaFgt6QYG4,dC3HqaFgt6QYG4
bbqAtUz36RPGVTvCkejpJXQB,MM564HfnUV0XIR,YDC9i52g6e8XL7GxvIFnSKWsolpr=WbM6qAjrn7fEXGZw,QmoEjB3hLIw,I7N2lHpGfLPkwKxbOu6raYUgc5
YZFXwtrfK8uhzV4LlMEqgnCQyO9,tmcuvd397wjGXeWoDHMNpFB5h2VK,Ox8k6IdtuPaG3NlApQK52oYwM=YDC9i52g6e8XL7GxvIFnSKWsolpr,MM564HfnUV0XIR,bbqAtUz36RPGVTvCkejpJXQB
GGCQK6OAtZUXRhvkgJm,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6,Gk98CL5nXZEN=Ox8k6IdtuPaG3NlApQK52oYwM,tmcuvd397wjGXeWoDHMNpFB5h2VK,YZFXwtrfK8uhzV4LlMEqgnCQyO9
dEUYJjrhsaPXNo,wx18CTJPZ5,cWfQ64kVCqxhwvSy5P7irHI1oes3=Gk98CL5nXZEN,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6,GGCQK6OAtZUXRhvkgJm
qFRrj7ayBKbOsHGSXz,SIDG7cnzAaUpkwmNde19ZsBqQ3Hh,tOdiG2HWFRBXg1sUh=cWfQ64kVCqxhwvSy5P7irHI1oes3,wx18CTJPZ5,dEUYJjrhsaPXNo
smpniPDOhfwI3H4v7c6TG,CIcPowhneWs5tN3,zxwIDBrPiXjKlsYkfg0AGaUZSyW2co=tOdiG2HWFRBXg1sUh,SIDG7cnzAaUpkwmNde19ZsBqQ3Hh,qFRrj7ayBKbOsHGSXz
r6juULGQtnExAko38BZ5Y,NNmirJKPp5nWjfC,FeyZbj8tDil0nSHzTwfsUJ9=zxwIDBrPiXjKlsYkfg0AGaUZSyW2co,CIcPowhneWs5tN3,smpniPDOhfwI3H4v7c6TG
S26SnaqcM9XwK8PVphJDv5,CgPbwXm1RilpJUSGHLhy,NxsKJnLFEZ9OHXf1h=FeyZbj8tDil0nSHzTwfsUJ9,NNmirJKPp5nWjfC,r6juULGQtnExAko38BZ5Y
Kwl07iYTtDLN3zP,uAl3gHavMJZL4xmNe62nDiBoQ,ta478EuZQJIWhgBnsf6iU=NxsKJnLFEZ9OHXf1h,CgPbwXm1RilpJUSGHLhy,S26SnaqcM9XwK8PVphJDv5
EAw9bg4rT3Bd8tjSkO,ItgK5FqGDz2Rf7mAJkbT,FFVuCHLxhZmkEGJQDitreaygc2f4AS=ta478EuZQJIWhgBnsf6iU,uAl3gHavMJZL4xmNe62nDiBoQ,Kwl07iYTtDLN3zP
from JnFs5LSwMp import *
import bidi.algorithm as C5KxErBjfN7HzJbdPmAciQT,bidi.mirror as w8Y6TU3WLkjlcQfe2Fn4CgOI9N,base64 as SSNcdhMguvEw0RY,requests as jR02vwUAu7Xs8mefybaHiJ
r1NChsk39OMvT82YemDQnl5 = WbM6qAjrn7fEXGZw(u"ࠧࡍࡋࡅࡗ࡙࡝ࡏࠨ౱")
FEzkPuAaomBVKvS4pfx8 = {}
muPDGHvJwFieQYCW62bB = []
if wvkR1es6d0SrjxKt5FZTMUWz7a:
	QQmPxURvYeXl2r8IOb = G158kjAPyw7CSHxKlO0Fn.translatePath(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡽࡨ࡭ࡤࠩ౲"))
	qKHs0b1SC2v3EZ9xfOluQ = G158kjAPyw7CSHxKlO0Fn.translatePath(ta478EuZQJIWhgBnsf6iU(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴࡮࡯࡮ࡧࠪ౳"))
	lAySnIgmVF8wzdkXMHirsP = G158kjAPyw7CSHxKlO0Fn.translatePath(CIcPowhneWs5tN3(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵࡬ࡰࡩࡳࡥࡹ࡮ࠧ౴"))
	wmrN7GxQWCAD9PzM3Tj = K3hFytImeYMkJBC.path.join(qKHs0b1SC2v3EZ9xfOluQ,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭౵"),r6juULGQtnExAko38BZ5Y(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ౶"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠭ࡁࡥࡦࡲࡲࡸ࠹࠳࠯ࡦࡥࠫ౷"))
	Aq1lkJOX8SKmpGZ = K3hFytImeYMkJBC.path.join(qKHs0b1SC2v3EZ9xfOluQ,S26SnaqcM9XwK8PVphJDv5(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ౸"),smpniPDOhfwI3H4v7c6TG(u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ౹"),bbqAtUz36RPGVTvCkejpJXQB(u"࡙ࠩ࡭ࡪࡽࡍࡰࡦࡨࡷ࠻࠴ࡤࡣࠩ౺"))
	tEA4o6NZmLDR15XjHW = K3hFytImeYMkJBC.path.join(qKHs0b1SC2v3EZ9xfOluQ,YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ౻"),Gk98CL5nXZEN(u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭౼"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࡚ࠬࡥࡹࡶࡸࡶࡪࡹ࠱࠴࠰ࡧࡦࠬ౽"))
	mtrqOcwh5Ux4aD7S9JQfE = YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࡻࠧ࡝ࡷ࠳࠶ࡩ࠷ࠧ౾")
	from urllib.parse import quote as _j8zQmKbWeUoEOiLwMg72Tv10usdq
else:
	QQmPxURvYeXl2r8IOb = oos8ymFi9CN2z1jXcR.translatePath(EAw9bg4rT3Bd8tjSkO(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡼࡧࡳࡣࠨ౿"))
	qKHs0b1SC2v3EZ9xfOluQ = oos8ymFi9CN2z1jXcR.translatePath(QmoEjB3hLIw(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳࡭ࡵ࡭ࡦࠩಀ"))
	lAySnIgmVF8wzdkXMHirsP = oos8ymFi9CN2z1jXcR.translatePath(Gk98CL5nXZEN(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡲ࡯ࡨࡲࡤࡸ࡭࠭ಁ"))
	wmrN7GxQWCAD9PzM3Tj = K3hFytImeYMkJBC.path.join(qKHs0b1SC2v3EZ9xfOluQ,CgPbwXm1RilpJUSGHLhy(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬಂ"),ItgK5FqGDz2Rf7mAJkbT(u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭ಃ"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠬࡇࡤࡥࡱࡱࡷ࠷࠽࠮ࡥࡤࠪ಄"))
	Aq1lkJOX8SKmpGZ = K3hFytImeYMkJBC.path.join(qKHs0b1SC2v3EZ9xfOluQ,zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨಅ"),wx18CTJPZ5(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩಆ"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠨࡘ࡬ࡩࡼࡓ࡯ࡥࡧࡶ࠺࠳ࡪࡢࠨಇ"))
	tEA4o6NZmLDR15XjHW = K3hFytImeYMkJBC.path.join(qKHs0b1SC2v3EZ9xfOluQ,WbM6qAjrn7fEXGZw(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫಈ"),NxsKJnLFEZ9OHXf1h(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬಉ"),bbqAtUz36RPGVTvCkejpJXQB(u"࡙ࠫ࡫ࡸࡵࡷࡵࡩࡸ࠷࠳࠯ࡦࡥࠫಊ"))
	mtrqOcwh5Ux4aD7S9JQfE = qFRrj7ayBKbOsHGSXz(u"ࡺ࠭࡜ࡶ࠲࠵ࡨ࠶࠭ಋ").encode(I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠭ࡵࡵࡨ࠻ࠫಌ"))
	from urllib import quote as _j8zQmKbWeUoEOiLwMg72Tv10usdq
g0gdkA6VTy9mGtLch = K3hFytImeYMkJBC.path.join(lAySnIgmVF8wzdkXMHirsP,FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠧ࡬ࡱࡧ࡭࠳ࡲ࡯ࡨࠩ಍"))
kk2pAdfSq8i7jmH6VhtgFLsGzYM = K3hFytImeYMkJBC.path.join(lAySnIgmVF8wzdkXMHirsP,QmoEjB3hLIw(u"ࠨ࡭ࡲࡨ࡮࠴࡯࡭ࡦ࠱ࡰࡴ࡭ࠧಎ"))
fnaV5QejFsr0 = K3hFytImeYMkJBC.path.join(llrbyaFHOt9e,zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠩ࡬ࡴࡹࡼ࠱ࡥࡣࡷࡥࡤࡥ࡟࠯ࡦࡥࠫಏ"))
wSMteKN1DXjAa = K3hFytImeYMkJBC.path.join(llrbyaFHOt9e,uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠪ࡭ࡵࡺࡶ࠳ࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬಐ"))
QryHWBUAPjqMKcpwaZmY3XVSORnDs = K3hFytImeYMkJBC.path.join(llrbyaFHOt9e,tOdiG2HWFRBXg1sUh(u"ࠫࡲ࠹ࡵࡥࡣࡷࡥࡤࡥ࡟࠯ࡦࡥࠫ಑"))
LkNCuYDaeV576vtyI = K3hFytImeYMkJBC.path.join(llrbyaFHOt9e,GGCQK6OAtZUXRhvkgJm(u"ࠬ࡬ࡡࡷࡱࡸࡶ࡮ࡺࡥࡴ࠰ࡧࡥࡹ࠭ಒ"))
MMOw5jW0bU4yEtFnZTLNcHzYQ = K3hFytImeYMkJBC.path.join(llrbyaFHOt9e,Gk98CL5nXZEN(u"࠭ࡩࡱࡶࡹࡪ࡮ࡲࡥࡠࡡࡢ࠲ࡩࡧࡴࠨಓ"))
ccpr3BP1dOTtCHXUyERh = K3hFytImeYMkJBC.path.join(llrbyaFHOt9e,I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠧ࡮࠵ࡸࡪ࡮ࡲࡥࡠࡡࡢ࠲ࡩࡧࡴࠨಔ"))
urI4Umothli03k1Ee = K3hFytImeYMkJBC.path.join(llrbyaFHOt9e,CgPbwXm1RilpJUSGHLhy(u"ࠨ࡫ࡰࡥ࡬࡫ࡳࠨಕ"))
xGYKLPqQHNlVoU8feW1S2Ad7ujC = K3hFytImeYMkJBC.path.join(urI4Umothli03k1Ee,EAw9bg4rT3Bd8tjSkO(u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡵࠪಖ"))
WHrbZo7z9DYcEtS = K3hFytImeYMkJBC.path.join(xGYKLPqQHNlVoU8feW1S2Ad7ujC,qFRrj7ayBKbOsHGSXz(u"ࠪࡨ࡮ࡧ࡬ࡰࡩࡢ࠴࠵࠶࠰ࡠ࠰ࡳࡲ࡬࠭ಗ"))
U0AdbxBVqaQOwTJIcSgN1z9iM7r = qH2TpnmA46PMCfY5dsr.Addon().getAddonInfo(tOdiG2HWFRBXg1sUh(u"ࠫࡵࡧࡴࡩࠩಘ"))
Ov6ePJ4YgS0ZEy7KGskfn9uA = K3hFytImeYMkJBC.path.join(U0AdbxBVqaQOwTJIcSgN1z9iM7r,cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠬ࡯ࡣࡰࡰ࠱ࡴࡳ࡭ࠧಙ"))
Ok4BhX2lTIwpFy6d5Zct7Qvm = K3hFytImeYMkJBC.path.join(U0AdbxBVqaQOwTJIcSgN1z9iM7r,wx18CTJPZ5(u"࠭ࡴࡩࡷࡰࡦ࠳ࡶ࡮ࡨࠩಚ"))
ZZPCfGy9aigprj = K3hFytImeYMkJBC.path.join(U0AdbxBVqaQOwTJIcSgN1z9iM7r,ta478EuZQJIWhgBnsf6iU(u"ࠧࡧࡣࡱࡥࡷࡺ࠮ࡱࡰࡪࠫಛ"))
ZZwjcIqs1SRnx7QYLvODC6lemuK = K3hFytImeYMkJBC.path.join(U0AdbxBVqaQOwTJIcSgN1z9iM7r,uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠨࡤࡤࡲࡳ࡫ࡲ࠯ࡲࡱ࡫ࠬಜ"))
zFO6DZpRhQkEr20c7VXCM = K3hFytImeYMkJBC.path.join(U0AdbxBVqaQOwTJIcSgN1z9iM7r,wx18CTJPZ5(u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩ࠳ࡶ࡮ࡨࠩಝ"))
p9dyN1MRF5jQxEXW = K3hFytImeYMkJBC.path.join(U0AdbxBVqaQOwTJIcSgN1z9iM7r,FeyZbj8tDil0nSHzTwfsUJ9(u"ࠪࡴࡴࡹࡴࡦࡴ࠱ࡴࡳ࡭ࠧಞ"))
GYZaukqHSCJL7T = K3hFytImeYMkJBC.path.join(U0AdbxBVqaQOwTJIcSgN1z9iM7r,CgPbwXm1RilpJUSGHLhy(u"ࠫࡨࡲࡥࡢࡴ࡯ࡳ࡬ࡵ࠮ࡱࡰࡪࠫಟ"))
FZpKODWb38QCUhf2TGjy0 = K3hFytImeYMkJBC.path.join(U0AdbxBVqaQOwTJIcSgN1z9iM7r,S26SnaqcM9XwK8PVphJDv5(u"ࠬࡩ࡬ࡦࡣࡵࡥࡷࡺ࠮ࡱࡰࡪࠫಠ"))
hhZm4DjnkHfv = K3hFytImeYMkJBC.path.join(U0AdbxBVqaQOwTJIcSgN1z9iM7r,ta478EuZQJIWhgBnsf6iU(u"࠭࡭ࡦࡰࡸ࠲ࡵࡴࡧࠨಡ"))
C5D0bhw4lqvi2kzSBOnXH6myR8Zt7 = K3hFytImeYMkJBC.path.join(U0AdbxBVqaQOwTJIcSgN1z9iM7r,I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠧࡤࡪࡤࡲ࡬࡫࡬ࡰࡩ࠱ࡸࡽࡺࠧಢ"))
URY8OguPqdXfkFB1oWiaGr = K3hFytImeYMkJBC.path.join(qKHs0b1SC2v3EZ9xfOluQ,MM564HfnUV0XIR(u"ࠨࡣࡧࡨࡴࡴࡳࠨಣ"))
whvA2b4mnJBjlICZ6ipPeHuD = K3hFytImeYMkJBC.path.join(qKHs0b1SC2v3EZ9xfOluQ,NxsKJnLFEZ9OHXf1h(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫತ"),tOdiG2HWFRBXg1sUh(u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧಥ"),aZhcuMGisIkl4npqDoJSrWy5fExX,uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪದ"))
r9b5CT7SU6WkiL3dEFJfNZOo0M = K3hFytImeYMkJBC.path.join(QQmPxURvYeXl2r8IOb,NxsKJnLFEZ9OHXf1h(u"ࠬࡳࡥࡥ࡫ࡤࠫಧ"),GGCQK6OAtZUXRhvkgJm(u"࠭ࡆࡰࡰࡷࡷࠬನ"),GGCQK6OAtZUXRhvkgJm(u"ࠧࡢࡴ࡬ࡥࡱ࠴ࡴࡵࡨࠪ಩"))
qHwLO4cGVh = ta478EuZQJIWhgBnsf6iU(u"࠵ᒞ")
qjvurmMCnxdktlp6Ii2ZhJb74y = [YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠨืไีࠬಪ"),GGCQK6OAtZUXRhvkgJm(u"ࠩฦ์้࠭ಫ"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠪฯฬ์๊ࠨಬ"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠫะอไฬࠩಭ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠬืวษ฻ࠪಮ"),smpniPDOhfwI3H4v7c6TG(u"࠭ฮศ็ึࠫಯ"),Gk98CL5nXZEN(u"ࠧิษาืࠬರ"),EAw9bg4rT3Bd8tjSkO(u"ࠨีสฬ฾࠭ಱ"),WbM6qAjrn7fEXGZw(u"ࠩฮห๊์ࠧಲ"),MM564HfnUV0XIR(u"ࠪฮฬููࠨಳ"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࠫ฾อิาࠩ಴")]
YGxJtc2ePh83jfZoWN1 = GGCQK6OAtZUXRhvkgJm(u"ࠬ⹁ࠠ⼞ࠢ⸭ࠤ⹀࠭ವ")
dJLne9pmQku = [zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬಶ")]
DDXuirUoJpORl316kjE8Td7KszW = [YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛ࠩಷ"),QmoEjB3hLIw(u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕࠫಸ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠭ಹ"),WbM6qAjrn7fEXGZw(u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫ಺"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊࠧ಻"),WbM6qAjrn7fEXGZw(u"ࠬࡓࡏࡗࡕ࠷಼࡙ࠬ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭ಽ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠧࡍࡃࡕࡓ࡟ࡇࠧಾ"),GGCQK6OAtZUXRhvkgJm(u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋࠪಿ"),QmoEjB3hLIw(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶ࠫೀ")]
DDXuirUoJpORl316kjE8Td7KszW += [bbqAtUz36RPGVTvCkejpJXQB(u"ࠪࡌࡊࡒࡁࡍࠩು"),NxsKJnLFEZ9OHXf1h(u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊࠪೂ"),Kwl07iYTtDLN3zP(u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓࠧೃ"),qFRrj7ayBKbOsHGSXz(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࠧೄ"),ta478EuZQJIWhgBnsf6iU(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑࠩ೅"),Gk98CL5nXZEN(u"ࠨࡇࡊ࡝ࡓࡕࡗࠨೆ"),Gk98CL5nXZEN(u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒࠫೇ"),dEUYJjrhsaPXNo(u"ࠪࡔࡆࡔࡅࡕࠩೈ"),EAw9bg4rT3Bd8tjSkO(u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ೉"),NxsKJnLFEZ9OHXf1h(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࡗࡐࡔࡎࠫೊ")]
suoHRhyl2GJ8r0bnLXDMkdvBajq = [YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠭ࡉࡑࡖ࡙ࠫೋ"),smpniPDOhfwI3H4v7c6TG(u"ࠧࡊࡒࡗ࡚࠲ࡒࡉࡗࡇࠪೌ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠨࡋࡓࡘ࡛࠳ࡍࡐࡘࡌࡉࡘ್࠭"),Kwl07iYTtDLN3zP(u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧ೎")]
suoHRhyl2GJ8r0bnLXDMkdvBajq += [I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠪࡑ࠸࡛ࠧ೏"),CgPbwXm1RilpJUSGHLhy(u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭೐"),CgPbwXm1RilpJUSGHLhy(u"ࠬࡓ࠳ࡖ࠯ࡐࡓ࡛ࡏࡅࡔࠩ೑"),NxsKJnLFEZ9OHXf1h(u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪ೒")]
suoHRhyl2GJ8r0bnLXDMkdvBajq += [GGCQK6OAtZUXRhvkgJm(u"ࠧࡊࡈࡌࡐࡒ࠭೓"),GGCQK6OAtZUXRhvkgJm(u"ࠨࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉࠧ೔"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡑࡋࡑࡏࡓࡉࠩೕ")]
suoHRhyl2GJ8r0bnLXDMkdvBajq += [Gk98CL5nXZEN(u"ࠪࡅࡑࡇࡒࡂࡄࠪೖ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠫࡆࡑࡗࡂࡏࠪ೗"),tOdiG2HWFRBXg1sUh(u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧ೘"),dEUYJjrhsaPXNo(u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨ೙"),CIcPowhneWs5tN3(u"ࠧࡂࡍࡒࡅࡒ࠭೚"),MM564HfnUV0XIR(u"ࠨࡍࡄࡘࡐࡕࡔࡕࡘࠪ೛")]
suoHRhyl2GJ8r0bnLXDMkdvBajq += [WbM6qAjrn7fEXGZw(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ೜"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠪࡆࡔࡑࡒࡂࠩೝ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭ೞ"),tOdiG2HWFRBXg1sUh(u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕࠪ೟"),GGCQK6OAtZUXRhvkgJm(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨೠ"),qFRrj7ayBKbOsHGSXz(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳ࠩೡ")]
cl4IbvCQhWLMFjA28 = [smpniPDOhfwI3H4v7c6TG(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩೢ"),qFRrj7ayBKbOsHGSXz(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࠪೣ"),CgPbwXm1RilpJUSGHLhy(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ೤"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ೥")]
cl4IbvCQhWLMFjA28 += [SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ೦"),FeyZbj8tDil0nSHzTwfsUJ9(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡛ࡏࡄࡆࡑࡖࠫ೧"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ೨"),dEUYJjrhsaPXNo(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ೩"),S26SnaqcM9XwK8PVphJDv5(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡕࡑࡓࡍࡈ࡙ࠧ೪"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡎࡌ࡚ࡊ࡙ࠧ೫")]
ZtLSghu1xCopHkJseGQRVl4W6Dm2n = [zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ೬"),NxsKJnLFEZ9OHXf1h(u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭೭"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧ೮"),NNmirJKPp5nWjfC(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ೯"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗࠬ೰")]
ZtLSghu1xCopHkJseGQRVl4W6Dm2n += [qFRrj7ayBKbOsHGSXz(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫೱ"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠪࡘ࡛ࡌࡕࡏࠩೲ"),wx18CTJPZ5(u"ࠫ࡜ࡋࡃࡊࡏࡄࠫೳ"),CgPbwXm1RilpJUSGHLhy(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ೴")]
yaWcERmZOMeC12Al3wx4YL = [NxsKJnLFEZ9OHXf1h(u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨ೵"),CgPbwXm1RilpJUSGHLhy(u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩ೶"),qFRrj7ayBKbOsHGSXz(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫ೷"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠩࡉࡓࡘ࡚ࡁࠨ೸"),tOdiG2HWFRBXg1sUh(u"ࠪࡅࡍ࡝ࡁࡌࠩ೹"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬ೺")]
yaWcERmZOMeC12Al3wx4YL += [NxsKJnLFEZ9OHXf1h(u"࡙ࠬࡈࡐࡈࡋࡅࠬ೻"),Ox8k6IdtuPaG3NlApQK52oYwM(u"࠭ࡂࡓࡕࡗࡉࡏ࠭೼"),qFRrj7ayBKbOsHGSXz(u"࡚ࠧࡃࡔࡓ࡙࠭೽"),smpniPDOhfwI3H4v7c6TG(u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩ೾"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪ೿"),CIcPowhneWs5tN3(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬഀ"),NNmirJKPp5nWjfC(u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭ഁ")]
ttbuWUACFmZSzJ7  = [NxsKJnLFEZ9OHXf1h(u"ࠬࡇࡋࡘࡃࡐࠫം"),NxsKJnLFEZ9OHXf1h(u"࠭ࡁࡍࡃࡕࡅࡇ࠭ഃ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩഄ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠨࡄࡒࡏࡗࡇࠧഅ"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࠩࡄࡏࡔࡇࡍࠨആ"),WbM6qAjrn7fEXGZw(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬഇ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭ഈ"),smpniPDOhfwI3H4v7c6TG(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭ഉ")]
ttbuWUACFmZSzJ7 += [I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨഊ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪഋ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩഌ"),qFRrj7ayBKbOsHGSXz(u"࡚ࠩࡉࡈࡏࡍࡂࠩ഍"),EAw9bg4rT3Bd8tjSkO(u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧഎ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠫࡋࡕࡓࡕࡃࠪഏ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠬࡇࡈࡘࡃࡎࠫഐ")]
ttbuWUACFmZSzJ7 += [dEUYJjrhsaPXNo(u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩ഑"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪഒ"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪഓ"),smpniPDOhfwI3H4v7c6TG(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠵ࠫഔ"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬക"),ta478EuZQJIWhgBnsf6iU(u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭ഖ")]
ttbuWUACFmZSzJ7 += [FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭ഗ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨഘ"),r6juULGQtnExAko38BZ5Y(u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩങ"),QmoEjB3hLIw(u"ࠨࡖ࡙ࡊ࡚ࡔࠧച"),dEUYJjrhsaPXNo(u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫഛ"),S26SnaqcM9XwK8PVphJDv5(u"ࠪࡗࡍࡕࡆࡉࡃࠪജ")]
ttbuWUACFmZSzJ7 += [bbqAtUz36RPGVTvCkejpJXQB(u"ࠫࡇࡘࡓࡕࡇࡍࠫഝ"),QmoEjB3hLIw(u"ࠬ࡟ࡁࡒࡑࡗࠫഞ"),QmoEjB3hLIw(u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧട"),ta478EuZQJIWhgBnsf6iU(u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨഠ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭ഡ"),QmoEjB3hLIw(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫഢ"),CIcPowhneWs5tN3(u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚ࠬണ")]
DLpOQX5VtJP2jqoMFreuTU  = [FeyZbj8tDil0nSHzTwfsUJ9(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࡙ࡍࡉࡋࡏࡔࠩത"),smpniPDOhfwI3H4v7c6TG(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭ഥ"),qFRrj7ayBKbOsHGSXz(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭ദ"),ItgK5FqGDz2Rf7mAJkbT(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡚ࡏࡑࡋࡆࡗࠬധ"),ta478EuZQJIWhgBnsf6iU(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡌࡊࡘࡈࡗࠬന")]
DLpOQX5VtJP2jqoMFreuTU += [wx18CTJPZ5(u"ࠩࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࠨഩ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࠪപ")]
DLpOQX5VtJP2jqoMFreuTU += [tOdiG2HWFRBXg1sUh(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲࡜ࡉࡅࡇࡒࡗࠬഫ"),CIcPowhneWs5tN3(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩബ"),NxsKJnLFEZ9OHXf1h(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩഭ")]
DLpOQX5VtJP2jqoMFreuTU += [NNmirJKPp5nWjfC(u"ࠧࡊࡒࡗ࡚࠲ࡒࡉࡗࡇࠪമ"),r6juULGQtnExAko38BZ5Y(u"ࠨࡋࡓࡘ࡛࠳ࡍࡐࡘࡌࡉࡘ࠭യ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧര")]
DLpOQX5VtJP2jqoMFreuTU += [GGCQK6OAtZUXRhvkgJm(u"ࠪࡑ࠸࡛࠭ࡍࡋ࡙ࡉࠬറ"),wx18CTJPZ5(u"ࠫࡒ࠹ࡕ࠮ࡏࡒ࡚ࡎࡋࡓࠨല"),NNmirJKPp5nWjfC(u"ࠬࡓ࠳ࡖ࠯ࡖࡉࡗࡏࡅࡔࠩള")]
UoNXjHS9Lwn1RycAWZeYhOVKl = [YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠭ࡍ࠴ࡗࠪഴ"),tOdiG2HWFRBXg1sUh(u"ࠧࡊࡒࡗ࡚ࠬവ"),r6juULGQtnExAko38BZ5Y(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭ശ"),CIcPowhneWs5tN3(u"ࠩࡌࡊࡎࡒࡍࠨഷ"),WbM6qAjrn7fEXGZw(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫസ")]
kpHmD5AvWYE2l = ttbuWUACFmZSzJ7+DLpOQX5VtJP2jqoMFreuTU
VV7Iv9cSholtn1MJsrXTjRLGy4ie = ttbuWUACFmZSzJ7+UoNXjHS9Lwn1RycAWZeYhOVKl
Obhnuk3f67 = ttbuWUACFmZSzJ7+DLpOQX5VtJP2jqoMFreuTU
TJsfnrDICj2WSVNtR = suoHRhyl2GJ8r0bnLXDMkdvBajq+ZtLSghu1xCopHkJseGQRVl4W6Dm2n+yaWcERmZOMeC12Al3wx4YL+cl4IbvCQhWLMFjA28
pxVtCSf8jbGmMoLEkW = [
						QmoEjB3hLIw(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭ഹ")
						,ta478EuZQJIWhgBnsf6iU(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠶ࡳࡪࠧഺ")
						,smpniPDOhfwI3H4v7c6TG(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐ࡙ࡑ࡚ࡉࡠ࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺ഻ࠧ")
						]
GImcXg9OBxnZFlj4qe = [
						CIcPowhneWs5tN3(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡕࡈࡒࡉࡥࡁࡏࡃࡏ࡝࡙ࡏࡃࡔࡡࡈ࡚ࡊࡔࡔ࠮࠳ࡶࡸ഼ࠬ")
						,Kwl07iYTtDLN3zP(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡈ࡜࡙ࡘࡁࡄࡖࡢࡑ࠸࡛࠸࠮࠳ࡶࡸࠬഽ")
						,wx18CTJPZ5(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡆࡔࡄࡐࡏࡢ࡙ࡘࡋࡒࡂࡉࡈࡒ࡙࠳࠱ࡴࡶࠪാ")
						,WbM6qAjrn7fEXGZw(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡒࡕࡓ࡝ࡏࡅࡔࡡࡏࡍࡘ࡚࠭࠲ࡵࡷࠫി")
						,FeyZbj8tDil0nSHzTwfsUJ9(u"ࠫࡎࡖࡔࡗ࠯ࡆࡌࡊࡉࡋࡠࡃࡆࡇࡔ࡛ࡎࡕ࠯࠴ࡷࡹ࠭ീ")
						,YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡑࡏࡓࡈࡇࡔࡊࡑࡑ࠱࠶ࡹࡴࠨു")
						,YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠱ࡴࡶࠪൂ")
						,FeyZbj8tDil0nSHzTwfsUJ9(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠴ࡴࡧࠫൃ")
						,uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡉࡆࡊ࡟ࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌ࠮࠳ࡶࡸࠬൄ")
						,qFRrj7ayBKbOsHGSXz(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕ࠯࠴ࡷࡹ࠭൅")
						,smpniPDOhfwI3H4v7c6TG(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠳ࡳࡦࠪെ")
						,EAw9bg4rT3Bd8tjSkO(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠶ࡶ࡫ࠫേ")
						,Gk98CL5nXZEN(u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫൈ")
						]
suRUkfjKA2BcL = GImcXg9OBxnZFlj4qe+[
				 NNmirJKPp5nWjfC(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡑࡔࡒ࡜࡞ࡥࡔࡆࡕࡗ࠱࠶ࡹࡴࠨ൉")
				,qFRrj7ayBKbOsHGSXz(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡋࡘ࡙ࡖࡓࡑࡔࡒ࡜ࡎࡋࡓ࠮࠳ࡶࡸࠬൊ")
				,ta478EuZQJIWhgBnsf6iU(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛ࡍࡊ࡙࠭࠲ࡵࡷࠫോ")
				,cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜ࡎࡋࡓ࠮࠴ࡱࡨࠬൌ")
				,YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤ࡝ࡅࡃࡒࡕࡓ࡝࡟ࡔࡐ࠯࠴ࡷࡹ്࠭")
				,NxsKJnLFEZ9OHXf1h(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞࡙ࡕࡑ࠰࠶ࡳࡪࠧൎ")
				,YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠵ࡸࡺࠧ൏")
				,CgPbwXm1RilpJUSGHLhy(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡍࡓࡖࡔ࡞࡙ࡄࡑࡐ࠱࠷ࡴࡤࠨ൐")
				,NxsKJnLFEZ9OHXf1h(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡎࡔࡗࡕࡘ࡚ࡅࡒࡑ࠲࠹ࡲࡥࠩ൑")
				,WbM6qAjrn7fEXGZw(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡆࡌࡊࡉࡋࡠࡊࡗࡘࡕ࡙࡟ࡑࡔࡒ࡜ࡎࡋࡓ࠮࠳ࡶࡸࠬ൒")
				,tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡍ࡚ࡔࡑࡕࡢࡘࡊ࡙ࡔ࠮࠳ࡶࡸࠬ൓")
				,ItgK5FqGDz2Rf7mAJkbT(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡚ࡅࡔࡖࡢࡅࡑࡒ࡟ࡘࡇࡅࡗࡎ࡚ࡅࡔ࠯࠴ࡷࡹ࠭ൔ")
				,CIcPowhneWs5tN3(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡔࡆࡕࡗࡣࡆࡒࡌࡠ࡙ࡈࡆࡘࡏࡔࡆࡕ࠰࠶ࡳࡪࠧൕ")
				,YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡖࡕࡄࡋࡊࡥࡒࡆࡒࡒࡖ࡙࠳࠱ࡴࡶࠪൖ")
				,tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡕࡔࡄࡒࡘࡒࡁࡕࡇ࠰࠵ࡸࡺࠧൗ")
				,dEUYJjrhsaPXNo(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈ࡚ࡊࡘࡓࡐࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩ൘")
				]
y4Be6ljV9o7DNAdFO0aQtWpY = [YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠨ࠺࠱࠼࠳࠾࠮࠹ࠩ൙"),MM564HfnUV0XIR(u"ࠩ࠴࠲࠶࠴࠱࠯࠳ࠪ൚"),MM564HfnUV0XIR(u"ࠪ࠵࠳࠶࠮࠱࠰࠴ࠫ൛"),GGCQK6OAtZUXRhvkgJm(u"ࠫ࠽࠴࠸࠯࠶࠱࠸ࠬ൜"),MM564HfnUV0XIR(u"ࠬ࠸࠰࠹࠰࠹࠻࠳࠸࠲࠳࠰࠵࠶࠷࠭൝"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠭࠲࠱࠺࠱࠺࠼࠴࠲࠳࠲࠱࠶࠷࠶ࠧ൞")]
mR20sONyKIlV = {
			 NxsKJnLFEZ9OHXf1h(u"ࠧࡂࡍࡒࡅࡒ࠭ൟ")		:[Kwl07iYTtDLN3zP(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯࠳ࡹࡶ࠰ࡱ࡯ࡨࠬൠ")]
			,Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠩࡄࡌ࡜ࡇࡋࠨൡ")		:[CIcPowhneWs5tN3(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡹ࠮ࡢࡪࡺࡥࡰࡺࡶ࠯ࡰࡨࡸࠬൢ")]
			,tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠫࡆࡑࡗࡂࡏࠪൣ")		:[GGCQK6OAtZUXRhvkgJm(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡬࠰ࡶࡺࠬ൤")]
			,YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠭ࡁࡍࡃࡕࡅࡇ࠭൥")		:[FeyZbj8tDil0nSHzTwfsUJ9(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡸࡲࡨ࠳ࡧ࡬ࡢࡴࡤࡦ࠳ࡩ࡯࡮ࠩ൦")]
			,r6juULGQtnExAko38BZ5Y(u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋࠪ൧")		:[I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡰ࡫ࡧࡴࡪ࡯࡬࠲ࡹࡼࠧ൨")]
			,S26SnaqcM9XwK8PVphJDv5(u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬ൩")		:[tOdiG2HWFRBXg1sUh(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡬࡮ࡣࡤࡶࡪ࡬࠮ࡤࡪࠪ൪")]
			,S26SnaqcM9XwK8PVphJDv5(u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕࠪ൫")	:[S26SnaqcM9XwK8PVphJDv5(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡥࡷࡧࡢࡪࡥ࠰ࡸࡴࡵ࡮ࡴ࠰ࡦࡳࡲ࠭൬")]
			,smpniPDOhfwI3H4v7c6TG(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ൭")		:[ta478EuZQJIWhgBnsf6iU(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡦࡨࡳࡦࡧࡧ࠲ࡳ࡫ࡴࠨ൮")]
			,Kwl07iYTtDLN3zP(u"ࠩࡅࡓࡐࡘࡁࠨ൯")		:[smpniPDOhfwI3H4v7c6TG(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷ࡭ࡵ࡯ࡧࡸࡲࡨ࠳ࡩ࡯࡮ࠩ൰")]
			,cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠫࡇࡘࡓࡕࡇࡍࠫ൱")		:[FeyZbj8tDil0nSHzTwfsUJ9(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡢࡳࡵࡷࡩ࡯࠴ࡣࡰ࡯ࠪ൲")]
			,tOdiG2HWFRBXg1sUh(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧ൳")		:[dEUYJjrhsaPXNo(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠺࠰࠱࠰ࡦࡳࡲ࠭൴")]
			,CIcPowhneWs5tN3(u"ࠨࡅࡌࡑࡆ࠺ࡕࠨ൵")		:[bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࠵ࡨ࡯࡭ࡢ࠶ࡸ࠲ࡨࡵ࡭ࠨ൶")]
			,r6juULGQtnExAko38BZ5Y(u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬ൷")		:[YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣ࠶ࡦࡩࡵ࠮ࡤࡱࡰࠫ൸")]
			,smpniPDOhfwI3H4v7c6TG(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ൹")		:[QmoEjB3hLIw(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥࡨࡲࡵࡣ࠰ࡶ࡯࡮ࡴࠧൺ")]
			,S26SnaqcM9XwK8PVphJDv5(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭ൻ")	:[S26SnaqcM9XwK8PVphJDv5(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷࡺࡻ࠴ࡣࡪ࡯ࡤࡧࡱࡻࡢ࠯ࡵ࡫ࡳࡵ࠭ർ")]
			,YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫൽ")		:[r6juULGQtnExAko38BZ5Y(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡥ࡬ࡱࡦ࡬ࡡ࡯ࡵ࠱ࡧࡴࡳࠧൾ")]
			,tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧൿ")	:[YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷ࠳࠸࠱ࡱࡾ࠳ࡣࡪ࡯ࡤ࠲ࡳ࡫ࡴࠨ඀")]
			,tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧඁ")		:[GGCQK6OAtZUXRhvkgJm(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦࡴ࡯ࡸ࠰ࡦࡧࠬං")]
			,MM564HfnUV0XIR(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭ඃ")	:[Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠳ࡩ࡯࡮ࠩ඄"),tOdiG2HWFRBXg1sUh(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬ࡸࡡࡱࡪࡴࡰ࠳ࡧࡰࡪ࠰ࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠮ࡤࡱࡰࠫඅ")]
			,ta478EuZQJIWhgBnsf6iU(u"ࠫࡉࡘࡁࡎࡃࡖ࠻ࠬආ")		:[NNmirJKPp5nWjfC(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡤ࠰ࡧࡶࡦࡳࡡࡴ࠹࠱ࡧࡴࡳࠧඇ")]
			,GGCQK6OAtZUXRhvkgJm(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨඈ")		:[ta478EuZQJIWhgBnsf6iU(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡰ࠰ࡩ࡬ࡿ࠮ࡣࡧࡶࡸࠬඉ")]
			,QmoEjB3hLIw(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴ࠪඊ")		:[WbM6qAjrn7fEXGZw(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡦࡩࡴࡰࡴࠪඋ")]
			,CgPbwXm1RilpJUSGHLhy(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷ࠬඌ")		:[NxsKJnLFEZ9OHXf1h(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡯ࡥࡨࡻࡥࡩࡸࡺ࠮ࡣ࡫ࡧࠫඍ")]
			,NxsKJnLFEZ9OHXf1h(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧඎ")		:[I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼ࠱ࡧ࡫ࡳࡵ࠰ࡱࡩࡹ࠭ඏ")]
			,Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨඐ")		:[tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾࡪࡥࡢࡦ࠱ࡰ࡮ࡼࡥࠨඑ")]
			,uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄࠫඒ")		:[CIcPowhneWs5tN3(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡲࡣࡪࡰࡨࡱࡦ࠴ࡣࡰ࡯ࠪඓ")]
			,cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬඔ")		:[YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢࡤࡵ࡯ࡦ࠴ࡣࡰ࡯ࠪඕ")]
			,Ox8k6IdtuPaG3NlApQK52oYwM(u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩඖ")	:[smpniPDOhfwI3H4v7c6TG(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤ࡮ࡪࡸ࠮ࡴࡪࡲࡻࠬ඗")]
			,uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ඘")		:[bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡧࡣࡶࡩࡱ࡮ࡤ࠯࡮࡬ࡲࡰ࠭඙")]
			,MM564HfnUV0XIR(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶ࠬක")		:[ItgK5FqGDz2Rf7mAJkbT(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡳ࡭ࡣ࠱ࡪࡦࡹࡥ࡭ࡪࡧ࠲ࡨࡲ࡯ࡶࡦࠪඛ")]
			,qFRrj7ayBKbOsHGSXz(u"ࠬࡌࡏࡔࡖࡄࠫග")		:[tOdiG2HWFRBXg1sUh(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹ࡭࠲࡫ࡵࡳࡵࡣ࠰ࡸࡻ࠴࡮ࡦࡶࠪඝ")]
			,uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩඞ")		:[NNmirJKPp5nWjfC(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡫ࡥࡱࡧࡣࡪ࡯ࡤ࠲ࡲ࡫ࡤࡪࡣࠪඟ")]
			,Kwl07iYTtDLN3zP(u"ࠩࡌࡊࡎࡒࡍࠨච")		:[EAw9bg4rT3Bd8tjSkO(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸ࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫඡ"),NxsKJnLFEZ9OHXf1h(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡮࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬජ"),GGCQK6OAtZUXRhvkgJm(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢ࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭ඣ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣ࠵࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨඤ"),wx18CTJPZ5(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠺࠵࠱࠵࠾࠶࠮࠳࠶࠱࠵࠷࠸ࠧඥ")]
			,MM564HfnUV0XIR(u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫඦ")	:[r6juULGQtnExAko38BZ5Y(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡦࡸࡢࡢ࡮ࡤ࠱ࡹࡼ࠮ࡪࡳࠪට")]
			,FeyZbj8tDil0nSHzTwfsUJ9(u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚ࠬඨ")		:[qFRrj7ayBKbOsHGSXz(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡭࡯ࡰ࠰࡮࡭ࡹࡱ࡯ࡵ࠰ࡷࡺࠬඩ")]
			,smpniPDOhfwI3H4v7c6TG(u"ࠬࡑࡏࡅࡋࡈࡑࡆࡊ࡟ࡂࡒࡓࠫඪ")	:[FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡵ࡫ࡱࡽ࠳ࡩࡣ࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦࠪණ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠸࠰࠲࠺࠱ࡪࡼࡹ࠮ࡴࡶࡲࡶࡪ࠭ඬ")]
			,ta478EuZQJIWhgBnsf6iU(u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩත")		:[QmoEjB3hLIw(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡰࡴࡪࡹ࡯ࡧࡷ࠲ࡨࡧ࡭ࠨථ")]
			,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠪࡔࡆࡔࡅࡕࠩද")		:[QmoEjB3hLIw(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡲࡤࡲࡪࡺ࠮ࡤࡱ࠱࡭ࡱ࠭ධ")]
			,GGCQK6OAtZUXRhvkgJm(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧන")		:[FeyZbj8tDil0nSHzTwfsUJ9(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡤࡥ࠳ࡩࡡ࡮ࠩ඲")]
			,FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫඳ")	:[r6juULGQtnExAko38BZ5Y(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࠲ࡸ࡮࠴ࡶ࠰ࡱࡩࡼࡹࠧප")]
			,YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠩࡖࡌࡔࡌࡈࡂࠩඵ")		:[NxsKJnLFEZ9OHXf1h(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻ࡯ࡤ࠯ࡵ࡫ࡳ࡫࡮ࡡ࠯ࡶࡹࠫබ")]
			,tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭භ")		:[uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡥࡲࡱࠬම"),QmoEjB3hLIw(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡶࡤࡸ࡮ࡩ࠮ࡴࡪࡲࡳ࡫ࡳࡡࡹ࠰ࡦࡳࡲ࠭ඹ"),S26SnaqcM9XwK8PVphJDv5(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫ࡳࡴ࡬࡭ࡢࡺ࠱ࡥࡿࡻࡲࡦࡧࡧ࡫ࡪ࠴࡮ࡦࡶࠪය")]
			,FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠨࡖ࡙ࡊ࡚ࡔࠧර")		:[NNmirJKPp5nWjfC(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࠳ࡺࡶࡧࡷࡱ࠲ࡲ࡫ࠧ඼")]
			,S26SnaqcM9XwK8PVphJDv5(u"࡛ࠪࡊࡉࡉࡎࡃࠪල")		:[CIcPowhneWs5tN3(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡾ࡮࠮࠯࠰࠱࠲࠳࡮ࡻࡧࡥࡧࡦ࠻ࡧࡥ࠹ࡲࡨࡪ࠶ࡢࡪࡩ࡯࡬࠳ࡳࡹࡤ࡫࡬ࡱࡦ࠳ࡷࡦࡥ࡬࡭ࡲࡧ࠮ࡴࡪࡲࡴࠬ඾")]
			,wx18CTJPZ5(u"ࠬ࡟ࡁࡒࡑࡗࠫ඿")		:[GGCQK6OAtZUXRhvkgJm(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡺ࠰ࡼࡥࡶࡵࡴ࠯ࡶࡹࠫව")]
			,uAl3gHavMJZL4xmNe62nDiBoQ(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨශ")		:[S26SnaqcM9XwK8PVphJDv5(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰࠫෂ")]
			,CIcPowhneWs5tN3(u"ࠩࡕࡉࡕࡕࡓࠨස")		:[NxsKJnLFEZ9OHXf1h(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪහ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠱࠹࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠻࠲ࡽࡳ࡬ࠨළ"),CIcPowhneWs5tN3(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠲࠻࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠽࠳ࡾ࡭࡭ࠩෆ")]
			,NxsKJnLFEZ9OHXf1h(u"࠭ࡒࡆࡒࡒࡗࡤࡈࡋࡑࠩ෇")	:[I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡸ࡯࠳ࡺ࡯࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬ෈"),tOdiG2HWFRBXg1sUh(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰ࠱ࡄࡈࡉࡕࡎࡔ࠳࠻࠳ࡦࡪࡤࡰࡰࡶ࠵࠽࠴ࡸ࡮࡮ࠪ෉"),wx18CTJPZ5(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠴࠽࠴ࡧࡤࡥࡱࡱࡷ࠶࠿࠮ࡹ࡯࡯්ࠫ")]
			,smpniPDOhfwI3H4v7c6TG(u"ࠪࡗࡔ࡛ࡒࡄࡇࡖࠫ෋")		:[YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵࡫ࡰࡦ࡬ࠫ෌"),MM564HfnUV0XIR(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡵࡸࡶ࡬࡫࠮ࡴࡪࠪ෍"),uAl3gHavMJZL4xmNe62nDiBoQ(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶ࠯ࡌࡑࡇࡍࡗࡋࡐࡐࠩ෎")]
			}
if FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠲ᒟ"):
	mR20sONyKIlV[Kwl07iYTtDLN3zP(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧා")] = [smpniPDOhfwI3H4v7c6TG(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪැ"),qFRrj7ayBKbOsHGSXz(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧෑ"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭ි"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩී"),Kwl07iYTtDLN3zP(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩු"),CIcPowhneWs5tN3(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ෕"),qFRrj7ayBKbOsHGSXz(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨූ"),qFRrj7ayBKbOsHGSXz(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡥࡤࡴࡹࡩࡨࡢࠩ෗"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪෘ")]
	mR20sONyKIlV[YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖࠧෙ")] = [cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧේ"),qFRrj7ayBKbOsHGSXz(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫෛ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪො"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭ෝ"),NNmirJKPp5nWjfC(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭ෞ"),Gk98CL5nXZEN(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩෟ"),CIcPowhneWs5tN3(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬ෠"),qFRrj7ayBKbOsHGSXz(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭෡"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧ෢")]
else:
	mR20sONyKIlV[r6juULGQtnExAko38BZ5Y(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭෣")] = [SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ෤"),CgPbwXm1RilpJUSGHLhy(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ෥"),WbM6qAjrn7fEXGZw(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭෦"),QmoEjB3hLIw(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ෧"),ta478EuZQJIWhgBnsf6iU(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩ෨"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ෩"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ෪"),Kwl07iYTtDLN3zP(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡥࡤࡴࡹࡩࡨࡢࠩ෫"),NNmirJKPp5nWjfC(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪ෬")]
	mR20sONyKIlV[smpniPDOhfwI3H4v7c6TG(u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠭෭")] = [bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭෮"),tOdiG2HWFRBXg1sUh(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ෯"),EAw9bg4rT3Bd8tjSkO(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ෰"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬ෱"),NxsKJnLFEZ9OHXf1h(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬෲ"),qFRrj7ayBKbOsHGSXz(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨෳ"),qFRrj7ayBKbOsHGSXz(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫ෴"),GGCQK6OAtZUXRhvkgJm(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬ෵"),QmoEjB3hLIw(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭෶")]
ANjhxR3Z6pBcJ = [NNmirJKPp5nWjfC(u"ࠬࡒࡉࡔࡖࡓࡐࡆ࡟ࠧ෷"),QmoEjB3hLIw(u"࠭ࡒࡆࡒࡒࡖ࡙࡙ࠧ෸"),EAw9bg4rT3Bd8tjSkO(u"ࠧࡆࡏࡄࡍࡑ࡙ࠧ෹"),qFRrj7ayBKbOsHGSXz(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪ෺"),QmoEjB3hLIw(u"ࠩࡌࡗࡑࡇࡍࡊࡅࡖࠫ෻"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭෼"),Gk98CL5nXZEN(u"ࠫࡐࡔࡏࡘࡐࡈࡖࡗࡕࡒࡔࠩ෽"),tOdiG2HWFRBXg1sUh(u"ࠬࡉࡁࡑࡖࡆࡌࡆ࠭෾"),Gk98CL5nXZEN(u"࠭ࡔࡆࡕࡗࡍࡓࡍࠧ෿")]
qHUNxQG27zhe8LI05O = [Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠧࡂࡆࡇࡓࡓ࡙ࠧ฀"),tOdiG2HWFRBXg1sUh(u"ࠨࡃࡇࡈࡔࡔࡓ࠲࠺ࠪก"),QmoEjB3hLIw(u"ࠩࡄࡈࡉࡕࡎࡔ࠳࠼ࠫข")]
class I4IrWekvPaCdsZYwont(HDSs6LB1wArQcd):
	def __init__(dzWrsHbBhvmJM1G0fu7E,*aargs,**kkwargs):
		dzWrsHbBhvmJM1G0fu7E.choiceID = -CIcPowhneWs5tN3(u"࠳ᒠ")
	def onClick(dzWrsHbBhvmJM1G0fu7E,p623sLj7wIhifRq0Y):
		if p623sLj7wIhifRq0Y>=SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠼࠴࠶࠶ᒡ"): dzWrsHbBhvmJM1G0fu7E.choiceID = p623sLj7wIhifRq0Y-SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠼࠴࠶࠶ᒡ")
		dzWrsHbBhvmJM1G0fu7E.t6tugqvD8w9KJ42zfh13()
	def hQ0kHW1raxc5pTZ6y9DswgBGFfSECi(dzWrsHbBhvmJM1G0fu7E,*aargs):
		dzWrsHbBhvmJM1G0fu7E.button0,dzWrsHbBhvmJM1G0fu7E.button1,dzWrsHbBhvmJM1G0fu7E.button2 = aargs[WbM6qAjrn7fEXGZw(u"࠵ᒣ")],aargs[wx18CTJPZ5(u"࠵ᒢ")],aargs[NxsKJnLFEZ9OHXf1h(u"࠸ᒤ")]
		dzWrsHbBhvmJM1G0fu7E.header,dzWrsHbBhvmJM1G0fu7E.text = aargs[CIcPowhneWs5tN3(u"࠳ᒥ")],aargs[Kwl07iYTtDLN3zP(u"࠵ᒦ")]
		dzWrsHbBhvmJM1G0fu7E.profile,dzWrsHbBhvmJM1G0fu7E.direction = aargs[dEUYJjrhsaPXNo(u"࠷ᒧ")],aargs[QmoEjB3hLIw(u"࠹ᒨ")]
		dzWrsHbBhvmJM1G0fu7E.buttonstimeout,dzWrsHbBhvmJM1G0fu7E.closetimeout = aargs[Kwl07iYTtDLN3zP(u"࠼ᒪ")],aargs[bbqAtUz36RPGVTvCkejpJXQB(u"࠼ᒩ")]
		if dzWrsHbBhvmJM1G0fu7E.buttonstimeout>GGCQK6OAtZUXRhvkgJm(u"࠶ᒫ") or dzWrsHbBhvmJM1G0fu7E.closetimeout>GGCQK6OAtZUXRhvkgJm(u"࠶ᒫ"): dzWrsHbBhvmJM1G0fu7E.enable_progressbar = uAl3gHavMJZL4xmNe62nDiBoQ(u"࡙ࡸࡵࡦᛨ")
		else: dzWrsHbBhvmJM1G0fu7E.enable_progressbar = uAl3gHavMJZL4xmNe62nDiBoQ(u"ࡌࡡ࡭ࡵࡨᛩ")
		dzWrsHbBhvmJM1G0fu7E.image_filename = WHrbZo7z9DYcEtS.replace(wx18CTJPZ5(u"ࠪࡣ࠵࠶࠰࠱ࡡࠪฃ"),ItgK5FqGDz2Rf7mAJkbT(u"ࠫࡤ࠭ค")+str(w6vebiEZtpCjJcILP8Skx5rHn.time())+Kwl07iYTtDLN3zP(u"ࠬࡥࠧฅ"))
		dzWrsHbBhvmJM1G0fu7E.image_filename = dzWrsHbBhvmJM1G0fu7E.image_filename.replace(bbqAtUz36RPGVTvCkejpJXQB(u"࠭࡜࡝ࠩฆ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠧ࡝࡞࡟ࡠࠬง")).replace(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠨ࠱࠲ࠫจ"),CIcPowhneWs5tN3(u"ࠩ࠲࠳࠴࠵ࠧฉ"))
		dzWrsHbBhvmJM1G0fu7E.image_height = ttLMqzgZbm(dzWrsHbBhvmJM1G0fu7E.button0,dzWrsHbBhvmJM1G0fu7E.button1,dzWrsHbBhvmJM1G0fu7E.button2,dzWrsHbBhvmJM1G0fu7E.header,dzWrsHbBhvmJM1G0fu7E.text,dzWrsHbBhvmJM1G0fu7E.profile,dzWrsHbBhvmJM1G0fu7E.direction,dzWrsHbBhvmJM1G0fu7E.enable_progressbar,dzWrsHbBhvmJM1G0fu7E.image_filename)
		dzWrsHbBhvmJM1G0fu7E.show()
		dzWrsHbBhvmJM1G0fu7E.getControl(S26SnaqcM9XwK8PVphJDv5(u"࠹࠱࠷࠳ᒬ")).setImage(dzWrsHbBhvmJM1G0fu7E.image_filename)
		dzWrsHbBhvmJM1G0fu7E.getControl(Gk98CL5nXZEN(u"࠺࠲࠸࠴ᒭ")).setHeight(dzWrsHbBhvmJM1G0fu7E.image_height)
		if not dzWrsHbBhvmJM1G0fu7E.button1 and dzWrsHbBhvmJM1G0fu7E.button0 and dzWrsHbBhvmJM1G0fu7E.button2: dzWrsHbBhvmJM1G0fu7E.getControl(QmoEjB3hLIw(u"࠼࠴࠶࠸ᒯ")).setPosition(-tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠶࠷࠶ᒰ"),GGCQK6OAtZUXRhvkgJm(u"࠲ᒮ"))
		return dzWrsHbBhvmJM1G0fu7E.image_filename,dzWrsHbBhvmJM1G0fu7E.image_height
	def aa4M6bvOuDSYynI(dzWrsHbBhvmJM1G0fu7E):
		if dzWrsHbBhvmJM1G0fu7E.buttonstimeout:
			dzWrsHbBhvmJM1G0fu7E.th1 = mZHwnlsXWDfV3ri4M.Thread(target=dzWrsHbBhvmJM1G0fu7E.U2ozPhV9lIigbGX1,args=())
			dzWrsHbBhvmJM1G0fu7E.th1.start()
		else: dzWrsHbBhvmJM1G0fu7E.v8xCiJ76wAORNrUlmajpnK0HQc()
	def U2ozPhV9lIigbGX1(dzWrsHbBhvmJM1G0fu7E):
		dzWrsHbBhvmJM1G0fu7E.getControl(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠾࠶࠲࠱ᒱ")).setEnabled(ItgK5FqGDz2Rf7mAJkbT(u"ࡔࡳࡷࡨᛪ"))
		for Deiz7ocWQjVnIg in range(cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠷ᒲ"),dzWrsHbBhvmJM1G0fu7E.buttonstimeout+cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠷ᒲ")):
			w6vebiEZtpCjJcILP8Skx5rHn.sleep(Gk98CL5nXZEN(u"࠱ᒳ"))
			Z3WnicHVOBDzGoC = int(GGCQK6OAtZUXRhvkgJm(u"࠲࠲࠳ᒴ")*Deiz7ocWQjVnIg/dzWrsHbBhvmJM1G0fu7E.buttonstimeout)
			dzWrsHbBhvmJM1G0fu7E.Ak7xSELcWryKGQT8fPM6HdUmeOJVB(Z3WnicHVOBDzGoC)
			if dzWrsHbBhvmJM1G0fu7E.choiceID>zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠲ᒵ"): break
		dzWrsHbBhvmJM1G0fu7E.v8xCiJ76wAORNrUlmajpnK0HQc()
	def YRaTw5UX8vluj(dzWrsHbBhvmJM1G0fu7E):
		if dzWrsHbBhvmJM1G0fu7E.closetimeout:
			dzWrsHbBhvmJM1G0fu7E.th2 = mZHwnlsXWDfV3ri4M.Thread(target=dzWrsHbBhvmJM1G0fu7E.KAuW5cQHPrJ3xbwogflZy760sFRME,args=())
			dzWrsHbBhvmJM1G0fu7E.th2.start()
		else: dzWrsHbBhvmJM1G0fu7E.v8xCiJ76wAORNrUlmajpnK0HQc()
	def KAuW5cQHPrJ3xbwogflZy760sFRME(dzWrsHbBhvmJM1G0fu7E):
		dzWrsHbBhvmJM1G0fu7E.getControl(tOdiG2HWFRBXg1sUh(u"࠼࠴࠷࠶ᒶ")).setEnabled(wx18CTJPZ5(u"ࡕࡴࡸࡩ᛫"))
		w6vebiEZtpCjJcILP8Skx5rHn.sleep(dzWrsHbBhvmJM1G0fu7E.buttonstimeout)
		for Deiz7ocWQjVnIg in range(dzWrsHbBhvmJM1G0fu7E.closetimeout-GGCQK6OAtZUXRhvkgJm(u"࠵ᒷ"),-GGCQK6OAtZUXRhvkgJm(u"࠵ᒷ"),-GGCQK6OAtZUXRhvkgJm(u"࠵ᒷ")):
			w6vebiEZtpCjJcILP8Skx5rHn.sleep(CIcPowhneWs5tN3(u"࠶ᒸ"))
			Z3WnicHVOBDzGoC = int(Gk98CL5nXZEN(u"࠷࠰࠱ᒹ")*Deiz7ocWQjVnIg/dzWrsHbBhvmJM1G0fu7E.closetimeout)
			dzWrsHbBhvmJM1G0fu7E.Ak7xSELcWryKGQT8fPM6HdUmeOJVB(Z3WnicHVOBDzGoC)
			if dzWrsHbBhvmJM1G0fu7E.choiceID>Gk98CL5nXZEN(u"࠰ᒺ"): break
		if dzWrsHbBhvmJM1G0fu7E.closetimeout>CIcPowhneWs5tN3(u"࠱ᒻ"): dzWrsHbBhvmJM1G0fu7E.choiceID = FeyZbj8tDil0nSHzTwfsUJ9(u"࠳࠳ᒼ")
		dzWrsHbBhvmJM1G0fu7E.t6tugqvD8w9KJ42zfh13()
	def Ak7xSELcWryKGQT8fPM6HdUmeOJVB(dzWrsHbBhvmJM1G0fu7E,Z3WnicHVOBDzGoC):
		dzWrsHbBhvmJM1G0fu7E.precent = Z3WnicHVOBDzGoC
		dzWrsHbBhvmJM1G0fu7E.getControl(Ox8k6IdtuPaG3NlApQK52oYwM(u"࠼࠴࠷࠶ᒽ")).setPercent(dzWrsHbBhvmJM1G0fu7E.precent)
	def v8xCiJ76wAORNrUlmajpnK0HQc(dzWrsHbBhvmJM1G0fu7E):
		if dzWrsHbBhvmJM1G0fu7E.button0: dzWrsHbBhvmJM1G0fu7E.getControl(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠽࠵࠷࠰ᒾ")).setEnabled(ItgK5FqGDz2Rf7mAJkbT(u"ࡖࡵࡹࡪ᛬"))
		if dzWrsHbBhvmJM1G0fu7E.button1: dzWrsHbBhvmJM1G0fu7E.getControl(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠾࠶࠱࠲ᒿ")).setEnabled(CIcPowhneWs5tN3(u"ࡗࡶࡺ࡫᛭"))
		if dzWrsHbBhvmJM1G0fu7E.button2: dzWrsHbBhvmJM1G0fu7E.getControl(smpniPDOhfwI3H4v7c6TG(u"࠿࠰࠲࠴ᓀ")).setEnabled(S26SnaqcM9XwK8PVphJDv5(u"ࡘࡷࡻࡥᛮ"))
	def t6tugqvD8w9KJ42zfh13(dzWrsHbBhvmJM1G0fu7E):
		dzWrsHbBhvmJM1G0fu7E.close()
		try: K3hFytImeYMkJBC.remove(dzWrsHbBhvmJM1G0fu7E.image_filename)
		except: pass
class MrpuQ4b0AfZ6scLH():
	def __init__(dzWrsHbBhvmJM1G0fu7E,showDialogs=bbqAtUz36RPGVTvCkejpJXQB(u"ࡌࡡ࡭ࡵࡨᛰ"),logErrors=CgPbwXm1RilpJUSGHLhy(u"࡙ࡸࡵࡦᛯ")):
		dzWrsHbBhvmJM1G0fu7E.showDialogs = showDialogs
		dzWrsHbBhvmJM1G0fu7E.logErrors = logErrors
		dzWrsHbBhvmJM1G0fu7E.finishedLIST,dzWrsHbBhvmJM1G0fu7E.failedLIST = [],[]
		dzWrsHbBhvmJM1G0fu7E.statusDICT,dzWrsHbBhvmJM1G0fu7E.resultsDICT = {},{}
		dzWrsHbBhvmJM1G0fu7E.processesLIST = []
		dzWrsHbBhvmJM1G0fu7E.starttimeDICT,dzWrsHbBhvmJM1G0fu7E.finishtimeDICT,dzWrsHbBhvmJM1G0fu7E.elpasedtimeDICT = {},{},{}
	def mMKyiSHEPNWT5q80It1RBDokZ(dzWrsHbBhvmJM1G0fu7E,N0DKTmwQprlGkE,nnsCqZoJDxrvfdByul,*aargs):
		N0DKTmwQprlGkE = str(N0DKTmwQprlGkE)
		dzWrsHbBhvmJM1G0fu7E.statusDICT[N0DKTmwQprlGkE] = WbM6qAjrn7fEXGZw(u"ࠪࡶࡺࡴ࡮ࡪࡰࡪࠫช")
		if dzWrsHbBhvmJM1G0fu7E.showDialogs: xa60ce2znAlyL5Z8ESXhO(WbM6qAjrn7fEXGZw(u"ࠫࠬซ"),N0DKTmwQprlGkE)
		jrPdVsRK795LBq20U = mZHwnlsXWDfV3ri4M.Thread(target=dzWrsHbBhvmJM1G0fu7E.UgxW8r9a14OmkqI6ieZuHo0NMhETFP,args=(N0DKTmwQprlGkE,nnsCqZoJDxrvfdByul,aargs))
		dzWrsHbBhvmJM1G0fu7E.processesLIST.append(jrPdVsRK795LBq20U)
		return jrPdVsRK795LBq20U
	def RLX07K6brEf(dzWrsHbBhvmJM1G0fu7E,N0DKTmwQprlGkE,nnsCqZoJDxrvfdByul,*aargs):
		jrPdVsRK795LBq20U = dzWrsHbBhvmJM1G0fu7E.mMKyiSHEPNWT5q80It1RBDokZ(N0DKTmwQprlGkE,nnsCqZoJDxrvfdByul,*aargs)
		jrPdVsRK795LBq20U.start()
	def UgxW8r9a14OmkqI6ieZuHo0NMhETFP(dzWrsHbBhvmJM1G0fu7E,N0DKTmwQprlGkE,nnsCqZoJDxrvfdByul,aargs):
		N0DKTmwQprlGkE = str(N0DKTmwQprlGkE)
		dzWrsHbBhvmJM1G0fu7E.starttimeDICT[N0DKTmwQprlGkE] = w6vebiEZtpCjJcILP8Skx5rHn.time()
		try:
			dzWrsHbBhvmJM1G0fu7E.resultsDICT[N0DKTmwQprlGkE] = nnsCqZoJDxrvfdByul(*aargs)
			if WbM6qAjrn7fEXGZw(u"ࠬࡕࡐࡆࡐࡘࡖࡑ࠭ฌ") in str(nnsCqZoJDxrvfdByul) and not dzWrsHbBhvmJM1G0fu7E.resultsDICT[N0DKTmwQprlGkE].succeeded:
				X5LD1xAj8Nuas3b4pFHC(ta478EuZQJIWhgBnsf6iU(u"࠭ࡆࡰࡴࡦࡩࡩࠦࡥࡹ࡫ࡷࠤࡩࡻࡥࠡࡶࡲࠤࡹ࡮ࡲࡦࡣࡧࡩࡩࠦࡏࡑࡇࡑ࡙ࡗࡒࠠࡧࡣ࡬ࡰࠬญ"))
			dzWrsHbBhvmJM1G0fu7E.finishedLIST.append(N0DKTmwQprlGkE)
			dzWrsHbBhvmJM1G0fu7E.statusDICT[N0DKTmwQprlGkE] = MM564HfnUV0XIR(u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࠩฎ")
		except Exception as y1y3DkdhK8aFYEwMnqZRzi:
			if dzWrsHbBhvmJM1G0fu7E.logErrors:
				jbDMGZeVf2RyJ8OxFA94Emu3pgo0St = oo5q9yuEdbCeOSxfzJcw.format_exc()
				if jbDMGZeVf2RyJ8OxFA94Emu3pgo0St!=I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠨࡐࡲࡲࡪ࡚ࡹࡱࡧ࠽ࠤࡓࡵ࡮ࡦ࡞ࡱࠫฏ"): EAPND6zHKrMRuBc91tInYohsl0ywa.stderr.write(jbDMGZeVf2RyJ8OxFA94Emu3pgo0St)
			dzWrsHbBhvmJM1G0fu7E.failedLIST.append(N0DKTmwQprlGkE)
			dzWrsHbBhvmJM1G0fu7E.statusDICT[N0DKTmwQprlGkE] = MM564HfnUV0XIR(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩฐ")
		dzWrsHbBhvmJM1G0fu7E.finishtimeDICT[N0DKTmwQprlGkE] = w6vebiEZtpCjJcILP8Skx5rHn.time()
		dzWrsHbBhvmJM1G0fu7E.elpasedtimeDICT[N0DKTmwQprlGkE] = dzWrsHbBhvmJM1G0fu7E.finishtimeDICT[N0DKTmwQprlGkE] - dzWrsHbBhvmJM1G0fu7E.starttimeDICT[N0DKTmwQprlGkE]
	def bbhBiokOZwDt4AIfy7X(dzWrsHbBhvmJM1G0fu7E):
		for NNYZQOnG5TjRqAxuVMX in dzWrsHbBhvmJM1G0fu7E.processesLIST:
			NNYZQOnG5TjRqAxuVMX.start()
	def r8RWC4G9yOvn6Tm(dzWrsHbBhvmJM1G0fu7E):
		while wx18CTJPZ5(u"ࠪࡶࡺࡴ࡮ࡪࡰࡪࠫฑ") in list(dzWrsHbBhvmJM1G0fu7E.statusDICT.values()): w6vebiEZtpCjJcILP8Skx5rHn.sleep(Kwl07iYTtDLN3zP(u"࠱࠯࠲࠳࠴ᓁ"))
def csf9ixjMQK4TPEVXt():
	V8VRKYUXlcz = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(FeyZbj8tDil0nSHzTwfsUJ9(u"ࠫࡦࡼ࠮ࡷࡧࡵࡷ࡮ࡵ࡮ࠨฒ"))
	if V8VRKYUXlcz==VnhK9wvHBGuo1fei8DXQ02yFZtsWE:
		oeFcwEfY2DGXyiBOm,l4lTvZF0Uy1dn = SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠬࡔࡏࡠࡗࡓࡈࡆ࡚ࡅࠨณ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࡆࡢ࡮ࡶࡩᛱ")
		return oeFcwEfY2DGXyiBOm,l4lTvZF0Uy1dn
	try: K3hFytImeYMkJBC.makedirs(llrbyaFHOt9e)
	except: pass
	oeFcwEfY2DGXyiBOm,l4lTvZF0Uy1dn = Gk98CL5nXZEN(u"࠭ࡆࡖࡎࡏࡣ࡚ࡖࡄࡂࡖࡈࠫด"),CIcPowhneWs5tN3(u"ࡕࡴࡸࡩᛲ")
	GfTJgS87ZicYr = [bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠧ࠹࠰࠸࠲࠵࠭ต"),dEUYJjrhsaPXNo(u"ࠨ࠴࠳࠶࠶࠴࠱࠱࠰࠴࠽ࠬถ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠩ࠵࠴࠷࠷࠮࠲࠳࠱࠶࠹ࡧࠧท"),CIcPowhneWs5tN3(u"ࠪ࠶࠵࠸࠱࠯࠳࠵࠲࠸࠶ࠧธ"),CgPbwXm1RilpJUSGHLhy(u"ࠫ࠷࠶࠲࠳࠰࠳࠶࠳࠶࠲ࠨน"),NNmirJKPp5nWjfC(u"ࠬ࠸࠰࠳࠴࠱࠵࠵࠴࠲࠳ࠩบ"),qFRrj7ayBKbOsHGSXz(u"࠭࠲࠱࠴࠶࠲࠵࠹࠮࠱࠸ࠪป"),MM564HfnUV0XIR(u"ࠧ࠳࠲࠵࠷࠳࠶࠵࠯࠳࠹ࠫผ"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠨ࠴࠳࠶࠸࠴࠰࠷࠰࠳࠺ࠬฝ"),GGCQK6OAtZUXRhvkgJm(u"ࠩ࠵࠴࠷࠹࠮࠲࠲࠱࠶࠽࠭พ"),dEUYJjrhsaPXNo(u"ࠪ࠶࠵࠸࠴࠯࠲࠴࠲࠶࠺ࠧฟ")]
	y3qvsJCr7o6F = GfTJgS87ZicYr[-MM564HfnUV0XIR(u"࠲ᓂ")]
	ckn4Y23w58f0svtDLQq = bd6QCIZMsF(y3qvsJCr7o6F)
	GGVdfWs8Y2uSbQXP6pEqgmAH = bd6QCIZMsF(VnhK9wvHBGuo1fei8DXQ02yFZtsWE)
	if GGVdfWs8Y2uSbQXP6pEqgmAH>ckn4Y23w58f0svtDLQq:
		oeFcwEfY2DGXyiBOm = Kwl07iYTtDLN3zP(u"ࠫࡘࡏࡍࡑࡎࡈࡣ࡚ࡖࡄࡂࡖࡈࠫภ")
	return oeFcwEfY2DGXyiBOm,l4lTvZF0Uy1dn
def X380EO7vgk5TN4ql():
	if tOdiG2HWFRBXg1sUh(u"࠳ᓃ"):
		UZ7FfVqrujTA4O91GvxhXE6 = SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠳ᓄ")
		for Msi7IDTbr26VuqQaBmokt1,MJGD1hrpubksVo087YFLHSln,kgVoUd0vCNj in K3hFytImeYMkJBC.walk(urI4Umothli03k1Ee,topdown=Ox8k6IdtuPaG3NlApQK52oYwM(u"ࡈࡤࡰࡸ࡫ᛳ")):
			UZ7FfVqrujTA4O91GvxhXE6 += len(kgVoUd0vCNj)
	if UZ7FfVqrujTA4O91GvxhXE6>WbM6qAjrn7fEXGZw(u"࠹࠵࠶࠰ᓅ"): oFHcGJSy62KieOMmZv4f0l(urI4Umothli03k1Ee,wx18CTJPZ5(u"ࡘࡷࡻࡥᛵ"),Gk98CL5nXZEN(u"ࡉࡥࡱࡹࡥᛴ"))
	return
def mmPvBhbOdr3z9QcwqJCE8euftpxZML(zPEbGfWv2ehc1Akr4tiR,JNuHrgRwE8K0hcdMBtQl):
	VZHWjJTrAPKG1eLEsxpYo2tS5,SSx5lkVehYXsZ4p,IPmK78wxkEHyUb91YLJrOGMp = YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࡚ࡲࡶࡧᛷ"),Kwl07iYTtDLN3zP(u"ࡋࡧ࡬ࡴࡧᛶ"),Kwl07iYTtDLN3zP(u"ࡋࡧ࡬ࡴࡧᛶ")
	Rl48v7kIh3cgF1fzOS6mQ9,TDmqAUj2Mfyir0PvS,Bf5QkcruZNX4SU6IeEvGj,sBjdZmqit76bCRPyFLaQ5V1v,Dj4rSONYXVbF8f9Hd0oWBp,t2zEwrA80WRjLel5NSvXyHd,hfNZTDrYABwyVcJQlqPS48xpHIi7s,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH = zPEbGfWv2ehc1Akr4tiR
	h7XHZRM89fpIJvWu = Rl48v7kIh3cgF1fzOS6mQ9,TDmqAUj2Mfyir0PvS,Bf5QkcruZNX4SU6IeEvGj,sBjdZmqit76bCRPyFLaQ5V1v,Dj4rSONYXVbF8f9Hd0oWBp,t2zEwrA80WRjLel5NSvXyHd,hfNZTDrYABwyVcJQlqPS48xpHIi7s,Gk98CL5nXZEN(u"ࠬ࠭ม"),zSPVUW1XDt2Ba6ZkAH
	jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU = int(sBjdZmqit76bCRPyFLaQ5V1v)
	qAgtV4FmX2EJTwkd1ioNsIlWMGbjy = int(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU%NNmirJKPp5nWjfC(u"࠶࠶ᓆ"))
	gHRCjEDhqTldIzKO8VFiMp3yA14 = int(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU/bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠷࠰ᓇ"))
	pcynmtuZQY = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(Ox8k6IdtuPaG3NlApQK52oYwM(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭ย"))
	if not pcynmtuZQY: if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(NNmirJKPp5nWjfC(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫ࠧร"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࠨࡃࡘࡘࡔ࠭ฤ"))
	d0xM1X9yNYQ2TinaGrLO,l4lTvZF0Uy1dn = csf9ixjMQK4TPEVXt()
	if l4lTvZF0Uy1dn:
		tehb3k5a2PufGOdBIUw8j(NxsKJnLFEZ9OHXf1h(u"ࠩࠪล"),qFRrj7ayBKbOsHGSXz(u"ࠪࠫฦ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧว"),tOdiG2HWFRBXg1sUh(u"ࠬะๅࠡฬะำ๏ัࠠศๆหี๋อๅอࠢไ๎ࠥา็ศิๆࡠࡳหไ๊ࠢส่ส฻ฯศำࠣี็๋࠺࡝ࡰ࡟ࡲࠬศ")+VnhK9wvHBGuo1fei8DXQ02yFZtsWE)
		QQvOnYi9sJMwp7dIxeck8DRASWuBt(WSgQvHLx9uOKTksaCt2JchldRj,SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩษ"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪส"))
		QQvOnYi9sJMwp7dIxeck8DRASWuBt(WSgQvHLx9uOKTksaCt2JchldRj,bbqAtUz36RPGVTvCkejpJXQB(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫห"),qFRrj7ayBKbOsHGSXz(u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪฬ"))
		QQvOnYi9sJMwp7dIxeck8DRASWuBt(WSgQvHLx9uOKTksaCt2JchldRj,qFRrj7ayBKbOsHGSXz(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭อ"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠫࡘࡏࡔࡆࡕࡢࡒࡆࡓࡅࡔࠩฮ"))
		QQvOnYi9sJMwp7dIxeck8DRASWuBt(WSgQvHLx9uOKTksaCt2JchldRj,r6juULGQtnExAko38BZ5Y(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨฯ"),ta478EuZQJIWhgBnsf6iU(u"࠭ࡓࡊࡖࡈࡗࡤࡉࡈࡆࡅࡎࠫะ"))
		QQvOnYi9sJMwp7dIxeck8DRASWuBt(WSgQvHLx9uOKTksaCt2JchldRj,SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪั"),Gk98CL5nXZEN(u"ࠨࡕࡌࡘࡊ࡙࡟ࡗࡇࡕࡍࡋ࡟ࠧา"))
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(Gk98CL5nXZEN(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡪࡴࡹࡴࡢࠩำ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠪࠫิ"))
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(QmoEjB3hLIw(u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࡬ࡡࡣࡴࡤ࡯ࡦ࠭ี"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠬ࠭ึ"))
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(CgPbwXm1RilpJUSGHLhy(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩื"),Gk98CL5nXZEN(u"ࠧࠨุ"))
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡩࡥࡸ࡫࡬ࡩࡦ࠴ูࠫ"),wx18CTJPZ5(u"ฺࠩࠪ"))
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷࠬ฻"),r6juULGQtnExAko38BZ5Y(u"ࠫࠬ฼"))
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠬࡧࡶ࠯ࡲࡨࡶ࡮ࡵࡤ࠯࡫ࡱࡪࡴࡹࠧ฽"),QmoEjB3hLIw(u"࠭ࠧ฾"))
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡬ࡰࡰࡪࠫ฿"),S26SnaqcM9XwK8PVphJDv5(u"ࠨࠩเ"))
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(r6juULGQtnExAko38BZ5Y(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡴࡨ࡫ࡺࡲࡡࡳࠩแ"),EAw9bg4rT3Bd8tjSkO(u"ࠪࠫโ"))
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(EAw9bg4rT3Bd8tjSkO(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡱࡪࡹࡳࡢࡩࡨࡷࠬใ"),MM564HfnUV0XIR(u"ࠬ࠭ไ"))
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(Ox8k6IdtuPaG3NlApQK52oYwM(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨๅ"),NxsKJnLFEZ9OHXf1h(u"ࠧࠨๆ"))
		import m4OhBzk7o2
		if d0xM1X9yNYQ2TinaGrLO==wx18CTJPZ5(u"ࠨࡕࡌࡑࡕࡒࡅࡠࡗࡓࡈࡆ࡚ࡅࠨ็"):
			y75wQavkVSLUb2MZf9qo(Gk98CL5nXZEN(u"ࠩࡑࡓ࡙ࡏࡃࡆ่ࠩ"),EAw9bg4rT3Bd8tjSkO(u"ࠪ࠲ࠥࠦࡁࡳࡣࡥ࡭ࡨ࡜ࡩࡥࡧࡲࡷ࡛ࠥࡰࡥࡣࡷࡩ࡚ࠥࡹࡱࡧ࠽ࠤ࡙ࠥࡉࡎࡒࡏࡉ࡛ࠥࡐࡅࡃࡗࡉࠥࠦࠠࡑࡣࡷ࡬࠿้࡛ࠦࠡࠩ")+mpUuAaIVfPRoQEligGywDYz1+FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠫࠥࡣ๊ࠧ"))
			QQvOnYi9sJMwp7dIxeck8DRASWuBt(WSgQvHLx9uOKTksaCt2JchldRj,dEUYJjrhsaPXNo(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘ๋࠭"))
			QQvOnYi9sJMwp7dIxeck8DRASWuBt(WSgQvHLx9uOKTksaCt2JchldRj,FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛࠭์"))
			QQvOnYi9sJMwp7dIxeck8DRASWuBt(WSgQvHLx9uOKTksaCt2JchldRj,wx18CTJPZ5(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚࠭ํ"))
			cLVWgMwAhBrbx2Jfltk4Y96opmv5UH(I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࡔࡳࡷࡨᛸ"),[WSgQvHLx9uOKTksaCt2JchldRj])
		else:
			y75wQavkVSLUb2MZf9qo(dEUYJjrhsaPXNo(u"ࠨࡐࡒࡘࡎࡉࡅࠨ๎"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠩ࠱ࠤࠥࡇࡲࡢࡤ࡬ࡧ࡛࡯ࡤࡦࡱࡶࠤ࡚ࡶࡤࡢࡶࡨࠤ࡙ࡿࡰࡦ࠼ࠣࠤࡋ࡛ࡌࡍࠢࡘࡔࡉࡇࡔࡆࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭๏")+mpUuAaIVfPRoQEligGywDYz1+Kwl07iYTtDLN3zP(u"ࠪࠤࡢ࠭๐"))
			tehb3k5a2PufGOdBIUw8j(GGCQK6OAtZUXRhvkgJm(u"ࠫࠬ๑"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠬ࠭๒"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ๓"),WbM6qAjrn7fEXGZw(u"ࠧห็ࠣฮะฮ๊หࠢฦ์ࠥะอะ์ฮࠤฬ๊ลึัสีࠥอไอัํำ๊ࠥศา่ส้ัࠦวๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠤ࠳ࠦร้ࠢอ้๋ࠥำฮࠢๆหูࠦวๅสิ๊ฬ๋ฬࠡ࡞ࡱࡠࡳࠦำ๋ไ๋้ࠥอไร่ࠣห้ฮั็ษ่ะࠥฮศฺุࠣห้็อ้ืสฮ๊ࠥึๆษ้ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣฬฺ๎ัสุࠢั๏ำษ๊่ࠡฮ่อๅๅหࠪ๔"))
			cLVWgMwAhBrbx2Jfltk4Y96opmv5UH(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࡇࡣ࡯ࡷࡪ᛹"),[])
			Jc19dpOeUMyLXG5PVrf0SlZmHntx(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࡈࡤࡰࡸ࡫᛺"))
			m4OhBzk7o2.EEqzDPROnos2aIiyCm0hSlVJdKv8()
			m4OhBzk7o2.ouxXRO0IqbTFQE5e6rD97(bbqAtUz36RPGVTvCkejpJXQB(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ๕"),ta478EuZQJIWhgBnsf6iU(u"ࡉࡥࡱࡹࡥ᛻"))
			m4OhBzk7o2.ouxXRO0IqbTFQE5e6rD97(NxsKJnLFEZ9OHXf1h(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡳࡶࡰࡴࠬ๖"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࡊࡦࡲࡳࡦ᛼"))
			m4OhBzk7o2.cQBJYm17zMNC6XjOfIdReLs4qwxo(CIcPowhneWs5tN3(u"ࡋࡧ࡬ࡴࡧ᛽"))
			m4OhBzk7o2.C6D50ht2eI(MM564HfnUV0XIR(u"ࡌࡡ࡭ࡵࡨ᛾"))
			m4OhBzk7o2.oq2rsGRg6kHh4YiFfudMDnwEJ(CIcPowhneWs5tN3(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ๗"),CIcPowhneWs5tN3(u"ࠫࡪࡴࡡࡣ࡮ࡨࠫ๘"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࡆࡢ࡮ࡶࡩ᛿"))
			try:
				EKDak3uU9Axd4IFitBclOvChRz = K3hFytImeYMkJBC.path.join(qKHs0b1SC2v3EZ9xfOluQ,bbqAtUz36RPGVTvCkejpJXQB(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ๙"),MM564HfnUV0XIR(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ๚"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫ๛"),ta478EuZQJIWhgBnsf6iU(u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧ๜"))
				mLudpCwo6IZVXjlxE5Qv = qH2TpnmA46PMCfY5dsr.Addon(id=I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭๝"))
				mLudpCwo6IZVXjlxE5Qv.setSetting(QmoEjB3hLIw(u"ࠪࡥࡻ࠴ࡡࡶࡶࡲࡣࡵ࡯ࡣ࡬ࠩ๞"),NNmirJKPp5nWjfC(u"ࠫ࡫ࡧ࡬ࡴࡧࠪ๟"))
			except: pass
			try:
				EKDak3uU9Axd4IFitBclOvChRz = K3hFytImeYMkJBC.path.join(qKHs0b1SC2v3EZ9xfOluQ,tOdiG2HWFRBXg1sUh(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ๠"),MM564HfnUV0XIR(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ๡"),MM564HfnUV0XIR(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡶ࠰ࡨࡱࡶࠧ๢"),CIcPowhneWs5tN3(u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧ๣"))
				mLudpCwo6IZVXjlxE5Qv = qH2TpnmA46PMCfY5dsr.Addon(id=FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡼࡸ࠲ࡪ࡬ࡱࠩ๤"))
				mLudpCwo6IZVXjlxE5Qv.setSetting(MM564HfnUV0XIR(u"ࠪࡥࡻ࠴ࡶࡪࡦࡨࡳࡤࡷࡵࡢ࡮࡬ࡸࡾ࠭๥"),r6juULGQtnExAko38BZ5Y(u"ࠫ࠸࠭๦"))
			except: pass
			try:
				EKDak3uU9Axd4IFitBclOvChRz = K3hFytImeYMkJBC.path.join(qKHs0b1SC2v3EZ9xfOluQ,FeyZbj8tDil0nSHzTwfsUJ9(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ๧"),tOdiG2HWFRBXg1sUh(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ๨"),CgPbwXm1RilpJUSGHLhy(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ๩"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧ๪"))
				mLudpCwo6IZVXjlxE5Qv = qH2TpnmA46PMCfY5dsr.Addon(id=SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ๫"))
				mLudpCwo6IZVXjlxE5Qv.setSetting(qFRrj7ayBKbOsHGSXz(u"ࠪࡥࡻ࠴ࡓࡕࡔࡈࡅࡒ࡙ࡅࡍࡇࡆࡘࡎࡕࡎࠨ๬"),WbM6qAjrn7fEXGZw(u"ࠫ࠷࠭๭"))
			except: pass
		YReuIJ67GDs8NwEiZOAh4xPMb = v3vOJa64yzBGcdQZ0oPrhNF9L(D5q7g8N0XowOn2Q)
		YReuIJ67GDs8NwEiZOAh4xPMb = v3vOJa64yzBGcdQZ0oPrhNF9L(LkNCuYDaeV576vtyI)
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠬࡧࡶ࠯ࡸࡨࡶࡸ࡯࡯࡯ࠩ๮"),VnhK9wvHBGuo1fei8DXQ02yFZtsWE)
		m4OhBzk7o2.Nkv860iJXz5DB9lVd7u2nT(FeyZbj8tDil0nSHzTwfsUJ9(u"ࡇࡣ࡯ࡷࡪᜀ"))
		return
	DzRqxnIrNLUgj4PYXFkZJc = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(FeyZbj8tDil0nSHzTwfsUJ9(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪ๯"))
	Wc8Brs0aYfD9U = zVi6a89ZyBcjwfkF(JNuHrgRwE8K0hcdMBtQl)
	ECwgo4qVaZAzx9eS = zVi6a89ZyBcjwfkF(TDmqAUj2Mfyir0PvS)
	R5Dm28fAC4oWHv1 = [bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠰ᓏ"),CIcPowhneWs5tN3(u"࠲࠷ᓉ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠳࠺ᓊ"),ta478EuZQJIWhgBnsf6iU(u"࠴࠽ᓋ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠲࠷ᓈ"),ItgK5FqGDz2Rf7mAJkbT(u"࠹࠴ᓎ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠹࠵ᓌ"),bbqAtUz36RPGVTvCkejpJXQB(u"࠺࠹ᓍ")]
	pp2MO6h3HxJVojm8S = [GGCQK6OAtZUXRhvkgJm(u"࠱ᓗ"),WbM6qAjrn7fEXGZw(u"࠳࠸ᓑ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠴࠻ᓒ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠵࠾ᓓ"),FeyZbj8tDil0nSHzTwfsUJ9(u"࠳࠸ᓐ"),r6juULGQtnExAko38BZ5Y(u"࠳࠵ᓖ"),S26SnaqcM9XwK8PVphJDv5(u"࠺࠶ᓔ"),WbM6qAjrn7fEXGZw(u"࠻࠳ᓕ")]
	GAKlFdoCHS = gHRCjEDhqTldIzKO8VFiMp3yA14 not in pp2MO6h3HxJVojm8S
	ggefmh1sPWODcaUJyt4u = gHRCjEDhqTldIzKO8VFiMp3yA14 in [smpniPDOhfwI3H4v7c6TG(u"࠷࠹ᓛ"),FeyZbj8tDil0nSHzTwfsUJ9(u"࠴࠻ᓘ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠻࠶ᓚ"),MM564HfnUV0XIR(u"࠺࠶ᓙ")]
	QQG3VI16jS5OkDafMFN2 = jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU in [FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠲࠷࠷ᓝ"),qFRrj7ayBKbOsHGSXz(u"࠸࠷࠱ᓜ")]
	ccJlYqC6ASZaMbfvKt = (GAKlFdoCHS or ggefmh1sPWODcaUJyt4u) and not QQG3VI16jS5OkDafMFN2
	LnvElPfF0ZNp = DzRqxnIrNLUgj4PYXFkZJc!=FeyZbj8tDil0nSHzTwfsUJ9(u"ࠧࡓࡇࡉࡖࡊ࡙ࡈࡆࡆࠪ๰") and (DzRqxnIrNLUgj4PYXFkZJc or not HHa1QbqG07ZPXko5fR)
	C3V0QMYvDhyOpk6s5Bb1 = YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠨࡶࡼࡴࡪࡃࠧ๱") in DzRqxnIrNLUgj4PYXFkZJc
	M5PXpC6USK = jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU in [Kwl07iYTtDLN3zP(u"࠵࠻࠷ᓨ"),MM564HfnUV0XIR(u"࠶࠼࠲ᓩ"),CgPbwXm1RilpJUSGHLhy(u"࠷࠶࠴ᓪ"),S26SnaqcM9XwK8PVphJDv5(u"࠱࠷࠶ᓤ"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠲࠸࠸ᓥ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠳࠹࠺ᓦ"),smpniPDOhfwI3H4v7c6TG(u"࠴࠺࠼ᓧ"),WbM6qAjrn7fEXGZw(u"࠷࠶࠹ᓣ"),NxsKJnLFEZ9OHXf1h(u"࠺࠺࠶ᓠ"),GGCQK6OAtZUXRhvkgJm(u"࠸࠸࠵ᓞ"),S26SnaqcM9XwK8PVphJDv5(u"࠹࠹࠷ᓟ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠻࠻࠺ᓡ"),smpniPDOhfwI3H4v7c6TG(u"࠼࠼࠵ᓢ")]
	Xwa7vgzTeb3Zy = qAgtV4FmX2EJTwkd1ioNsIlWMGbjy==YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠹ᓫ") or jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU in [SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠳࠷࠹ᓭ"),tOdiG2HWFRBXg1sUh(u"࠹࠶࠼ᓯ"),NNmirJKPp5nWjfC(u"࠸࠶࠸ᓮ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠵࠷ᓬ")]
	ksySLAHZ3b = not M5PXpC6USK
	yYWBt5vskDuTaGqX9blzIHj2hxUKAL = not Xwa7vgzTeb3Zy
	ovpbDfBjxP = Wc8Brs0aYfD9U in [ItgK5FqGDz2Rf7mAJkbT(u"ࠩࠪ๲"),r6juULGQtnExAko38BZ5Y(u"ࠪ࠲࠳࠭๳")]
	Krmt8wf4ILMCuT2YG6 = ovpbDfBjxP or ksySLAHZ3b
	UHvmRN0zG3 = ovpbDfBjxP or yYWBt5vskDuTaGqX9blzIHj2hxUKAL or C3V0QMYvDhyOpk6s5Bb1
	dYVlrjm3oqti7WaUTA6BnefOxQhR = jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU not in [qFRrj7ayBKbOsHGSXz(u"࠴࠹࠴ᓴ"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠷࠼࠱ᓰ"),tOdiG2HWFRBXg1sUh(u"࠵࠺࠺ᓵ"),FeyZbj8tDil0nSHzTwfsUJ9(u"࠲࠸࠲ᓲ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠹࠳࠱ᓱ"),FeyZbj8tDil0nSHzTwfsUJ9(u"࠶࠶࠳ᓳ")]
	if pcynmtuZQY==EAw9bg4rT3Bd8tjSkO(u"ࠫࡘ࡚ࡏࡑࠩ๴"): q1PYRlkbf74GoauUHvAjn = Xwa7vgzTeb3Zy or M5PXpC6USK
	else: q1PYRlkbf74GoauUHvAjn = SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࡖࡵࡹࡪᜁ")
	yrcQbxljTi = gHRCjEDhqTldIzKO8VFiMp3yA14 in [tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠼࠺ᓷ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠻࠺ᓶ")]
	wfIu8QUTz3 = jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU in [smpniPDOhfwI3H4v7c6TG(u"࠸࠸࠱ᓸ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠷࠳࠲ᓹ")]
	uAXkwJ1CrMQ9EU0jh8S = not yrcQbxljTi and not wfIu8QUTz3
	m7n1JBRAPrq = Krmt8wf4ILMCuT2YG6 and UHvmRN0zG3 and dYVlrjm3oqti7WaUTA6BnefOxQhR and q1PYRlkbf74GoauUHvAjn and uAXkwJ1CrMQ9EU0jh8S
	aolHyRWdJF0MUxVvX = dYVlrjm3oqti7WaUTA6BnefOxQhR and q1PYRlkbf74GoauUHvAjn and uAXkwJ1CrMQ9EU0jh8S
	tkg1hFNoVDl8Tv0u2xLe7y = aolHyRWdJF0MUxVvX
	tvw2ounREL = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(MM564HfnUV0XIR(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡴࡷࡵࡶࡪࡦࡨࡶࠬ๵"))
	qGuHTJ8f9OaBnt2v7PlFQiC5ExdXc = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(wx18CTJPZ5(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡨࡵࡤࡦࠩ๶"))
	if SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠲ᓺ") and LnvElPfF0ZNp and m7n1JBRAPrq:
		ZFSmledaL8OTxhuGC4nopYfWcjk = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,S26SnaqcM9XwK8PVphJDv5(u"ࠧ࡭࡫ࡶࡸࠬ๷"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧ๸")+tvw2ounREL+FeyZbj8tDil0nSHzTwfsUJ9(u"ࠩࡢࠫ๹")+qGuHTJ8f9OaBnt2v7PlFQiC5ExdXc,h7XHZRM89fpIJvWu)
		if ZFSmledaL8OTxhuGC4nopYfWcjk:
			y75wQavkVSLUb2MZf9qo(CgPbwXm1RilpJUSGHLhy(u"ࠪࠫ๺"),wx18CTJPZ5(u"ࠫ࠳ࠦࠠࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭๻")+tvw2ounREL+ta478EuZQJIWhgBnsf6iU(u"ࠬࡥࠧ๼")+qGuHTJ8f9OaBnt2v7PlFQiC5ExdXc+zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠭ࠠࠡࠢࡏࡳࡦࡪࡩ࡯ࡩࠣࡱࡪࡴࡵࠡࡨࡵࡳࡲࠦࡣࡢࡥ࡫ࡩࠬ๽"))
			if cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠳ᓻ") and C3V0QMYvDhyOpk6s5Bb1:
				XYw0Lv3fFimckZOURDKadBtbpq6rP = []
				from Uyonvur1IK import xxy3PEYHQp0eDUtRjr1quwl7ioaCT
				from S8VCsPpcIU import h0WgvJjBRGy,dF9PbrkHwI
				k8PLAZouq5zhJGYcUHIXmO4rbsl = xxy3PEYHQp0eDUtRjr1quwl7ioaCT
				ZXq0IvJg61D9fsA5Fek2VnWB = h0WgvJjBRGy()
				DoUqgKa7nYx38Wd0tvAJT6VXN1 = DzRqxnIrNLUgj4PYXFkZJc
				RRuswO84nzLvaxXl2gU6PY,mmL7wBIRx1Gg0o4ikhEZAacMHYNO,wxKkOYrPef6FnEh,Iku3erwUcOdt8VyzlQ6K2xaG,pHxJFnK8VrDqI4twTiXbBWc2M,GF4wvUCoLW8YfPimtAeSDVq,NwJ4EG1ShmWIT,DSBsmZFpvJCMyi3XxGQIf69o42ra1R,fK723zNrEBvexLmyVqOQi9cpUFaPMI = VVuCNFHGiUftREgnP4Aw(DoUqgKa7nYx38Wd0tvAJT6VXN1)
				xx3tkiLZGwAepSYCu1zTrq2mEj = RRuswO84nzLvaxXl2gU6PY,mmL7wBIRx1Gg0o4ikhEZAacMHYNO,wxKkOYrPef6FnEh,Iku3erwUcOdt8VyzlQ6K2xaG,pHxJFnK8VrDqI4twTiXbBWc2M,GF4wvUCoLW8YfPimtAeSDVq,NwJ4EG1ShmWIT,Kwl07iYTtDLN3zP(u"ࠧࠨ๾"),fK723zNrEBvexLmyVqOQi9cpUFaPMI
				for pODN9BjAKW3nkoEPy7Vd in ZFSmledaL8OTxhuGC4nopYfWcjk:
					wYozDiyWhUcERFI214vfOkd = pODN9BjAKW3nkoEPy7Vd[Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠨ࡯ࡨࡲࡺࡏࡴࡦ࡯ࠪ๿")]
					if wYozDiyWhUcERFI214vfOkd==xx3tkiLZGwAepSYCu1zTrq2mEj or pODN9BjAKW3nkoEPy7Vd[bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠩࡰࡳࡩ࡫ࠧ຀")] in [NxsKJnLFEZ9OHXf1h(u"࠶࠻࠻ᓽ"),Ox8k6IdtuPaG3NlApQK52oYwM(u"࠵࠻࠵ᓼ")]:
						pODN9BjAKW3nkoEPy7Vd = Ze3U0adCsoVBclmExu5fOy6n(wYozDiyWhUcERFI214vfOkd,k8PLAZouq5zhJGYcUHIXmO4rbsl,ZXq0IvJg61D9fsA5Fek2VnWB)
						if pODN9BjAKW3nkoEPy7Vd[bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠪࡪࡦࡼ࡯ࡳ࡫ࡷࡩࡸ࠭ກ")]:
							G5XZdkhgftUIHY0AqNvoSsxD3wR = dF9PbrkHwI(ZXq0IvJg61D9fsA5Fek2VnWB,wYozDiyWhUcERFI214vfOkd,pODN9BjAKW3nkoEPy7Vd[NxsKJnLFEZ9OHXf1h(u"ࠫࡳ࡫ࡷࡱࡣࡷ࡬ࠬຂ")])
							pODN9BjAKW3nkoEPy7Vd[I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠬࡩ࡯࡯ࡶࡨࡼࡹࡥ࡭ࡦࡰࡸࠫ຃")] = G5XZdkhgftUIHY0AqNvoSsxD3wR+pODN9BjAKW3nkoEPy7Vd[NNmirJKPp5nWjfC(u"࠭ࡣࡰࡰࡷࡩࡽࡺ࡟࡮ࡧࡱࡹࠬຄ")]
					XYw0Lv3fFimckZOURDKadBtbpq6rP.append(pODN9BjAKW3nkoEPy7Vd)
				if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(Kwl07iYTtDLN3zP(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫ຅"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠨࠩຆ"))
				if Rl48v7kIh3cgF1fzOS6mQ9==EAw9bg4rT3Bd8tjSkO(u"ࠩࡩࡳࡱࡪࡥࡳࠩງ"): kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,Gk98CL5nXZEN(u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩຈ")+tvw2ounREL+r6juULGQtnExAko38BZ5Y(u"ࠫࡤ࠭ຉ")+qGuHTJ8f9OaBnt2v7PlFQiC5ExdXc,h7XHZRM89fpIJvWu,XYw0Lv3fFimckZOURDKadBtbpq6rP,Yv7e6ixHfZIPrmMOy3ozwJu2)
			else: XYw0Lv3fFimckZOURDKadBtbpq6rP = ZFSmledaL8OTxhuGC4nopYfWcjk
			if Rl48v7kIh3cgF1fzOS6mQ9==bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬຊ") and Wc8Brs0aYfD9U!=NxsKJnLFEZ9OHXf1h(u"࠭࠮࠯ࠩ຋") and ccJlYqC6ASZaMbfvKt: bhzrQ2wcHVodXEvneLqsMm9WF()
			CsNtMbrAmo7x = UNXgiou9B5DGq2nFsh(h7XHZRM89fpIJvWu,XYw0Lv3fFimckZOURDKadBtbpq6rP,VZHWjJTrAPKG1eLEsxpYo2tS5,SSx5lkVehYXsZ4p,IPmK78wxkEHyUb91YLJrOGMp)
			return
	elif Rl48v7kIh3cgF1fzOS6mQ9==uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧຌ") and DzRqxnIrNLUgj4PYXFkZJc==bbqAtUz36RPGVTvCkejpJXQB(u"ࠨࡔࡈࡊࡗࡋࡓࡉࡇࡇࠫຍ") and aolHyRWdJF0MUxVvX:
		QQvOnYi9sJMwp7dIxeck8DRASWuBt(WSgQvHLx9uOKTksaCt2JchldRj,qFRrj7ayBKbOsHGSXz(u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨຎ")+tvw2ounREL+smpniPDOhfwI3H4v7c6TG(u"ࠪࡣࠬຏ")+qGuHTJ8f9OaBnt2v7PlFQiC5ExdXc,h7XHZRM89fpIJvWu)
	if HHa1QbqG07ZPXko5fR:
		if CgPbwXm1RilpJUSGHLhy(u"ࠫࡤ࠭ຐ") in HHa1QbqG07ZPXko5fR: TlRZcqhOHr,d7dExzqFNgLZuyAGTiK = HHa1QbqG07ZPXko5fR.split(Gk98CL5nXZEN(u"ࠬࡥࠧຑ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠶ᓾ"))
		else: TlRZcqhOHr,d7dExzqFNgLZuyAGTiK = HHa1QbqG07ZPXko5fR,YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠭ࠧຒ")
		if TlRZcqhOHr in [Gk98CL5nXZEN(u"ࠧ࠲ࠩຓ"),qFRrj7ayBKbOsHGSXz(u"ࠨ࠴ࠪດ"),WbM6qAjrn7fEXGZw(u"ࠩ࠶ࠫຕ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠪ࠸ࠬຖ"),ItgK5FqGDz2Rf7mAJkbT(u"ࠫ࠺࠭ທ")] and d7dExzqFNgLZuyAGTiK:
			from S8VCsPpcIU import gsHW8vED4ji
			gsHW8vED4ji(HHa1QbqG07ZPXko5fR)
			if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(Kwl07iYTtDLN3zP(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩຘ"),mpUuAaIVfPRoQEligGywDYz1)
			oos8ymFi9CN2z1jXcR.executebuiltin(ItgK5FqGDz2Rf7mAJkbT(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪນ"))
			return
		elif TlRZcqhOHr==SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠧ࠷ࠩບ"):
			if d7dExzqFNgLZuyAGTiK==cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪປ"): xa60ce2znAlyL5Z8ESXhO(GGCQK6OAtZUXRhvkgJm(u"ࠩํีั๏ࠠศๆส๊ฯ฾วาࠩຜ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠪะฬื๊ࠡใะู๋ࠥไโࠢส่ฯำๅ๋ๆࠪຝ"))
			elif d7dExzqFNgLZuyAGTiK==r6juULGQtnExAko38BZ5Y(u"ࠫࡉࡋࡌࡆࡖࡈࠫພ"): jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU = Ox8k6IdtuPaG3NlApQK52oYwM(u"࠹࠳࠵ᓿ")
			s4Bng5iAZQSTtpDw9 = l2G4xA1VXjbpud(Rl48v7kIh3cgF1fzOS6mQ9,ECwgo4qVaZAzx9eS,Bf5QkcruZNX4SU6IeEvGj,jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,Dj4rSONYXVbF8f9Hd0oWBp,t2zEwrA80WRjLel5NSvXyHd,hfNZTDrYABwyVcJQlqPS48xpHIi7s,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH)
			oos8ymFi9CN2z1jXcR.executebuiltin(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩຟ"))
			return
		elif HHa1QbqG07ZPXko5fR==FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠭࠷ࠨຠ"):
			from MMHzE6r0uI import OLf6ESZRwzsg1GVpyk8quBA
			OLf6ESZRwzsg1GVpyk8quBA()
			oos8ymFi9CN2z1jXcR.executebuiltin(qFRrj7ayBKbOsHGSXz(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫມ"))
			return
		elif HHa1QbqG07ZPXko5fR==r6juULGQtnExAko38BZ5Y(u"ࠨ࠺ࠪຢ"):
			oos8ymFi9CN2z1jXcR.executebuiltin(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨຣ")+aZhcuMGisIkl4npqDoJSrWy5fExX+zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠪࡃࡲࡵࡤࡦ࠿ࠪ຤")+str(sBjdZmqit76bCRPyFLaQ5V1v)+tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠫࠫࡺࡹࡱࡧࡀࡪࡴࡲࡤࡦࡴࠬࠫລ"))
			return
		elif HHa1QbqG07ZPXko5fR==r6juULGQtnExAko38BZ5Y(u"ࠬ࠿ࠧ຦"):
			if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(FeyZbj8tDil0nSHzTwfsUJ9(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪວ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡆࡆࠪຨ"))
			oos8ymFi9CN2z1jXcR.executebuiltin(uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬຩ"))
			return
	if if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨສ")) not in [qFRrj7ayBKbOsHGSXz(u"ࠪࡅ࡚࡚ࡏࠨຫ"),NNmirJKPp5nWjfC(u"ࠫࡘ࡚ࡏࡑࠩຬ"),dEUYJjrhsaPXNo(u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭ອ")]:
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(FeyZbj8tDil0nSHzTwfsUJ9(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬຮ"),NNmirJKPp5nWjfC(u"ࠧࡂࡗࡗࡓࠬຯ"))
	if not if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(CIcPowhneWs5tN3(u"ࠨࡣࡹ࠲ࡩࡴࡳࠨະ")): if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠩࡤࡺ࠳ࡪ࡮ࡴࠩັ"),y4Be6ljV9o7DNAdFO0aQtWpY[YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠰ᔀ")])
	qqXSGVsp8bZYTtE = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(EAw9bg4rT3Bd8tjSkO(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡵࡩ࡬ࡻ࡬ࡢࡴࠪາ"))
	qqXSGVsp8bZYTtE = QmoEjB3hLIw(u"࠱ᔁ") if not qqXSGVsp8bZYTtE else int(qqXSGVsp8bZYTtE)
	if not qqXSGVsp8bZYTtE or not Ox8k6IdtuPaG3NlApQK52oYwM(u"࠲ᔂ")<=eOYicX68ruMjpN0dKtWP5QTSE-qqXSGVsp8bZYTtE<=Yv7e6ixHfZIPrmMOy3ozwJu2:
		jrPdVsRK795LBq20U = mZHwnlsXWDfV3ri4M.Thread(target=X380EO7vgk5TN4ql)
		jrPdVsRK795LBq20U.start()
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡶࡪ࡭ࡵ࡭ࡣࡵࠫຳ"),str(eOYicX68ruMjpN0dKtWP5QTSE))
	ufqiD3Nt5MaG = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(Gk98CL5nXZEN(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡱࡵ࡮ࡨࠩິ"))
	ufqiD3Nt5MaG = Ox8k6IdtuPaG3NlApQK52oYwM(u"࠳ᔃ") if not ufqiD3Nt5MaG else int(ufqiD3Nt5MaG)
	if not ufqiD3Nt5MaG or not smpniPDOhfwI3H4v7c6TG(u"࠴ᔄ")<=eOYicX68ruMjpN0dKtWP5QTSE-ufqiD3Nt5MaG<=xgFTDVS7lf5Us6aj:
		import m4OhBzk7o2
		m4OhBzk7o2.NcRCDvgHBAS0(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࡊࡦࡲࡳࡦᜃ"),S26SnaqcM9XwK8PVphJDv5(u"ࡗࡶࡺ࡫ᜂ"))
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(CIcPowhneWs5tN3(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡲ࡯࡯ࡩࠪີ"),str(eOYicX68ruMjpN0dKtWP5QTSE))
	ppogfFlCH6MkJEihLAUY = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(bbqAtUz36RPGVTvCkejpJXQB(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡹࡳࡢࡩࡨࡷࠬຶ"))
	MMpxjK9if0s5nuZrz31 = tGdhVg9jniercWDYB(if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(wx18CTJPZ5(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩື")))
	MMpxjK9if0s5nuZrz31 = tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠵ᔅ") if not MMpxjK9if0s5nuZrz31 else int(MMpxjK9if0s5nuZrz31)
	if ppogfFlCH6MkJEihLAUY in [dEUYJjrhsaPXNo(u"ຸࠩࠪ"),wx18CTJPZ5(u"ࠪࡉࡗࡘࡏࡓູࠩ")] or not MMpxjK9if0s5nuZrz31 or not NxsKJnLFEZ9OHXf1h(u"࠶ᔆ")<=eOYicX68ruMjpN0dKtWP5QTSE-MMpxjK9if0s5nuZrz31<=jEPuRTVbZg4MCimJxzf3I6wFa:
		jIAuMSaQXw5o46 = qmcQKkuhliSZRJUC(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࡋࡧ࡬ࡴࡧᜄ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࡋࡧ࡬ࡴࡧᜄ"))
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(EAw9bg4rT3Bd8tjSkO(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡱࡪࡹࡳࡢࡩࡨࡷ຺ࠬ"),NfjyEgxeHGwpbu7QK3O1D(eOYicX68ruMjpN0dKtWP5QTSE))
		if jIAuMSaQXw5o46:
			xa60ce2znAlyL5Z8ESXhO(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠬาัษ่ࠢีฮࠦรฯำ์ࠫົ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠭ࡔࡳࡻࠣࡥ࡬ࡧࡩ࡯ࠩຼ"),w6vebiEZtpCjJcILP8Skx5rHn=WbM6qAjrn7fEXGZw(u"࠱࠱࠲࠳ᔇ"))
			return
	Evu7nWr5zofh9s2j6GeTRyC = tGdhVg9jniercWDYB(if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(FeyZbj8tDil0nSHzTwfsUJ9(u"ࠧࡢࡸ࠱ࡴࡪࡸࡩࡰࡦ࠱࡭ࡳ࡬࡯ࡴࠩຽ")))
	Evu7nWr5zofh9s2j6GeTRyC = NxsKJnLFEZ9OHXf1h(u"࠱ᔈ") if not Evu7nWr5zofh9s2j6GeTRyC else int(Evu7nWr5zofh9s2j6GeTRyC)
	JCth30cOMQ4dNYUX9vE = tGdhVg9jniercWDYB(if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ຾")))
	JCth30cOMQ4dNYUX9vE = Ox8k6IdtuPaG3NlApQK52oYwM(u"࠲ᔉ") if not JCth30cOMQ4dNYUX9vE else int(JCth30cOMQ4dNYUX9vE)
	if not Evu7nWr5zofh9s2j6GeTRyC or not JCth30cOMQ4dNYUX9vE or not qFRrj7ayBKbOsHGSXz(u"࠳ᔊ")<=eOYicX68ruMjpN0dKtWP5QTSE-JCth30cOMQ4dNYUX9vE<=Evu7nWr5zofh9s2j6GeTRyC:
		GGPm1SBKgW6CtRsLch5OueAjIdp0 = dEUYJjrhsaPXNo(u"࠵ᔋ")
		rShBmlIaDRo6piEe1c85fU2bdn = smpniPDOhfwI3H4v7c6TG(u"ࡆࡢ࡮ࡶࡩᜆ") if hPfgMmZC19lRiKwpN(I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠩࡒࡘ࠶࠿ࡊࡖ࠲ࡻࡆ࡙࡛࡬ࡅ࡚ࠪ຿")) else r6juULGQtnExAko38BZ5Y(u"࡚ࡲࡶࡧᜅ")
		if rShBmlIaDRo6piEe1c85fU2bdn:
			WmSFUq5gTRr13 = ORXquBZQ8x2wnWveHtYdCTyU(Ox8k6IdtuPaG3NlApQK52oYwM(u"ࡕࡴࡸࡩᜇ"))
			if len(WmSFUq5gTRr13)>bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠶ᔌ"):
				y75wQavkVSLUb2MZf9qo(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪເ"),tOdiG2HWFRBXg1sUh(u"ࠫ࠳ࠦࠠࡔࡪࡲࡻ࡮ࡴࡧࠡࡓࡸࡩࡸࡺࡩࡰࡰࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧແ")+mpUuAaIVfPRoQEligGywDYz1+wx18CTJPZ5(u"ࠬࠦ࡝ࠨໂ"))
				N0DKTmwQprlGkE,gg6VwuY0xOi7,yTJXbEc9LjmfVRD0N2F,gqf9tEKLQN2J6bAUr0ivHIOSD,n8g9KIdWMyTi2JDkvEfBA6,rreason = WmSFUq5gTRr13[qFRrj7ayBKbOsHGSXz(u"࠶ᔍ")]
				hhybuQfnOXm,EUYp7Rs8FNn3eokvSx4h = gqf9tEKLQN2J6bAUr0ivHIOSD.split(S26SnaqcM9XwK8PVphJDv5(u"࠭࡜࡯࠽࠾ࠫໃ"))
				del WmSFUq5gTRr13[Gk98CL5nXZEN(u"࠰ᔎ")]
				Y7uMbrRLqnAGDT = BBioyg7XVR.sample(WmSFUq5gTRr13,S26SnaqcM9XwK8PVphJDv5(u"࠲ᔏ"))
				N0DKTmwQprlGkE,gg6VwuY0xOi7,yTJXbEc9LjmfVRD0N2F,gqf9tEKLQN2J6bAUr0ivHIOSD,n8g9KIdWMyTi2JDkvEfBA6,rreason = Y7uMbrRLqnAGDT[qFRrj7ayBKbOsHGSXz(u"࠲ᔐ")]
				yTJXbEc9LjmfVRD0N2F = CIcPowhneWs5tN3(u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠡ࠼ࠣࠫໄ")+N0DKTmwQprlGkE+Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ໅")+yTJXbEc9LjmfVRD0N2F
				n8g9KIdWMyTi2JDkvEfBA6 = NxsKJnLFEZ9OHXf1h(u"ࠩศีุอไࠡำึห้ฯࠠๅๆ่ฬึ๋ฬࠨໆ")
				YGxJtc2ePh83jfZoWN1 = NxsKJnLFEZ9OHXf1h(u"ࠪห้ะศา฻สฮࠬ໇")
				button0,button1 = gqf9tEKLQN2J6bAUr0ivHIOSD,n8g9KIdWMyTi2JDkvEfBA6
				eLPtaRj5khXC2MEF9Dd3bgKpm1f7rV = [button0,button1,YGxJtc2ePh83jfZoWN1]
				eJtKxcMUmqXz = tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠴ᔑ") if hPfgMmZC19lRiKwpN(bbqAtUz36RPGVTvCkejpJXQB(u"ࠫ࡜࡙ࡕࡓࡈࡗ࠵࠾ࡗࡔࡆࡈ࡝࡜່ࠬ")) else EAw9bg4rT3Bd8tjSkO(u"࠵࠵ᔒ")
				JJ94bQazqrY1wS = -bbqAtUz36RPGVTvCkejpJXQB(u"࠾ᔓ")
				while JJ94bQazqrY1wS<tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠶ᔔ"):
					Q0jlXJuxzeS = BBioyg7XVR.sample(eLPtaRj5khXC2MEF9Dd3bgKpm1f7rV,YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠳ᔕ"))
					JJ94bQazqrY1wS = m5NUYqBzGynIOeAg8(CgPbwXm1RilpJUSGHLhy(u"້ࠬ࠭"),Q0jlXJuxzeS[Gk98CL5nXZEN(u"࠲ᔗ")],Q0jlXJuxzeS[bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠲ᔖ")],Q0jlXJuxzeS[YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠵ᔘ")],hhybuQfnOXm,yTJXbEc9LjmfVRD0N2F,bbqAtUz36RPGVTvCkejpJXQB(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ໊"),eJtKxcMUmqXz,smpniPDOhfwI3H4v7c6TG(u"࠺࠵ᔙ"))
					if JJ94bQazqrY1wS==bbqAtUz36RPGVTvCkejpJXQB(u"࠶࠶ᔚ"): break
					from m4OhBzk7o2 import oOmLC8y1REg,ALWQsFjmi7zIw8b
					if JJ94bQazqrY1wS>=Kwl07iYTtDLN3zP(u"࠰ᔜ") and Q0jlXJuxzeS[JJ94bQazqrY1wS]==eLPtaRj5khXC2MEF9Dd3bgKpm1f7rV[uAl3gHavMJZL4xmNe62nDiBoQ(u"࠷ᔛ")]:
						oOmLC8y1REg()
						if JJ94bQazqrY1wS>=dEUYJjrhsaPXNo(u"࠲ᔞ"): JJ94bQazqrY1wS = -smpniPDOhfwI3H4v7c6TG(u"࠺ᔝ")
					elif JJ94bQazqrY1wS>=zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠳ᔟ") and Q0jlXJuxzeS[JJ94bQazqrY1wS]==eLPtaRj5khXC2MEF9Dd3bgKpm1f7rV[MM564HfnUV0XIR(u"࠶ᔠ")]:
						ALWQsFjmi7zIw8b(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࡈࡤࡰࡸ࡫ᜈ"))
					if JJ94bQazqrY1wS==-NxsKJnLFEZ9OHXf1h(u"࠶ᔡ"): tehb3k5a2PufGOdBIUw8j(NxsKJnLFEZ9OHXf1h(u"ࠧࠨ໋"),MM564HfnUV0XIR(u"ࠨࠩ໌"),CgPbwXm1RilpJUSGHLhy(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬໍ"),WbM6qAjrn7fEXGZw(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢิั้ฮࠣา฼ษ࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ่้ࠣิั้ฮࠣห้฻อ๋ฯࠣวำะั๊ࠡสัิࠦๅ็ࠢส่ศา่ษหࠣห้๋ส้ใิอࠬ໎"))
				GGPm1SBKgW6CtRsLch5OueAjIdp0 = r6juULGQtnExAko38BZ5Y(u"࠷ᔢ")
			else: GGPm1SBKgW6CtRsLch5OueAjIdp0 = uAl3gHavMJZL4xmNe62nDiBoQ(u"࠰ᔣ")
		kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,CIcPowhneWs5tN3(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ໏"),tOdiG2HWFRBXg1sUh(u"࡙ࠬࡉࡕࡇࡖࡣࡓࡇࡍࡆࡕࠪ໐"),GGPm1SBKgW6CtRsLch5OueAjIdp0,D0vjfyxKZuP7pXknq62MwFYU)
	s4Bng5iAZQSTtpDw9 = l2G4xA1VXjbpud(Rl48v7kIh3cgF1fzOS6mQ9,ECwgo4qVaZAzx9eS,Bf5QkcruZNX4SU6IeEvGj,sBjdZmqit76bCRPyFLaQ5V1v,Dj4rSONYXVbF8f9Hd0oWBp,t2zEwrA80WRjLel5NSvXyHd,hfNZTDrYABwyVcJQlqPS48xpHIi7s,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH)
	if bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ໑") in hfNZTDrYABwyVcJQlqPS48xpHIi7s: SSx5lkVehYXsZ4p = dEUYJjrhsaPXNo(u"ࡗࡶࡺ࡫ᜉ")
	if Rl48v7kIh3cgF1fzOS6mQ9==I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ໒"):
		if Wc8Brs0aYfD9U!=YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠨ࠰࠱ࠫ໓") and ccJlYqC6ASZaMbfvKt: bhzrQ2wcHVodXEvneLqsMm9WF()
		if KKtWUT6l8S>-FeyZbj8tDil0nSHzTwfsUJ9(u"࠲ᔤ"):
			if (vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,wx18CTJPZ5(u"ࠩ࡬ࡲࡹ࠭໔"),S26SnaqcM9XwK8PVphJDv5(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭໕"),EAw9bg4rT3Bd8tjSkO(u"ࠫࡘࡏࡔࡆࡕࡢࡒࡆࡓࡅࡔࠩ໖")) or jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU not in R5Dm28fAC4oWHv1) and not hPfgMmZC19lRiKwpN(I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠬࡉࡔࡆ࠻ࡇࡗ࠶࠿ࡖࡖ࠲࡙ࡗ࡝࠭໗")):
				from Uyonvur1IK import xxy3PEYHQp0eDUtRjr1quwl7ioaCT
				ZFSmledaL8OTxhuGC4nopYfWcjk = EoLBOMxkziXqCPDZsp0jn(xxy3PEYHQp0eDUtRjr1quwl7ioaCT)
				CsNtMbrAmo7x = UNXgiou9B5DGq2nFsh(h7XHZRM89fpIJvWu,ZFSmledaL8OTxhuGC4nopYfWcjk,VZHWjJTrAPKG1eLEsxpYo2tS5,SSx5lkVehYXsZ4p,IPmK78wxkEHyUb91YLJrOGMp)
				if WbM6qAjrn7fEXGZw(u"࠳ᔥ") and ZFSmledaL8OTxhuGC4nopYfWcjk and tkg1hFNoVDl8Tv0u2xLe7y:
					kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,FeyZbj8tDil0nSHzTwfsUJ9(u"࠭ࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࡣࠬ໘")+tvw2ounREL+wx18CTJPZ5(u"ࠧࡠࠩ໙")+qGuHTJ8f9OaBnt2v7PlFQiC5ExdXc,h7XHZRM89fpIJvWu,ZFSmledaL8OTxhuGC4nopYfWcjk,Yv7e6ixHfZIPrmMOy3ozwJu2)
			else:
				I9AOhSdTGW4rX1yPc3oKQHnkJEe.addDirectoryItem(KKtWUT6l8S,I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫ໚")+aZhcuMGisIkl4npqDoJSrWy5fExX+zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿࡯࡭ࡳࡱࠦ࡮ࡱࡧࡩࡂ࠻࠰࠱ࠩ໛"),ZuEAJR1lNHkUf0.ListItem(ta478EuZQJIWhgBnsf6iU(u"่ࠪิ๐ใࠡ็ื็้ฯࠠๆ่ࠣะ์อาไࠩໜ")))
				I9AOhSdTGW4rX1yPc3oKQHnkJEe.addDirectoryItem(KKtWUT6l8S,YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧໝ")+aZhcuMGisIkl4npqDoJSrWy5fExX+ItgK5FqGDz2Rf7mAJkbT(u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡲࡩ࡯࡭ࠩࡱࡴࡪࡥ࠾࠷࠳࠴ࠬໞ"),ZuEAJR1lNHkUf0.ListItem(Kwl07iYTtDLN3zP(u"࠭รโฬะࠤ้ะโาลࠣห้ะแศืํ่ࠬໟ")))
			I9AOhSdTGW4rX1yPc3oKQHnkJEe.endOfDirectory(KKtWUT6l8S,VZHWjJTrAPKG1eLEsxpYo2tS5,SSx5lkVehYXsZ4p,IPmK78wxkEHyUb91YLJrOGMp)
	return
def l2G4xA1VXjbpud(Rl48v7kIh3cgF1fzOS6mQ9,TDmqAUj2Mfyir0PvS,pAeIhbuLSFw7j49qxtcg8dDrmKO,sBjdZmqit76bCRPyFLaQ5V1v,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,hfNZTDrYABwyVcJQlqPS48xpHIi7s,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH):
	jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU = int(sBjdZmqit76bCRPyFLaQ5V1v)
	gHRCjEDhqTldIzKO8VFiMp3yA14 = int(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU//SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠴࠴ᔦ"))
	if   gHRCjEDhqTldIzKO8VFiMp3yA14==YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠴ᔧ"):  from m4OhBzk7o2 		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==qFRrj7ayBKbOsHGSXz(u"࠶ᔨ"):  from d2VTKM9FXz 		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==uAl3gHavMJZL4xmNe62nDiBoQ(u"࠸ᔩ"):  from wwZI3KVCYg 			import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,tsMKaFVh1ZN2BIXEcvTejxR5DP,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==bbqAtUz36RPGVTvCkejpJXQB(u"࠳ᔪ"):  from kogpcfNu7J 			import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,tsMKaFVh1ZN2BIXEcvTejxR5DP,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠵ᔫ"):  from UR1hcZsCLr 		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s,tsMKaFVh1ZN2BIXEcvTejxR5DP)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==MM564HfnUV0XIR(u"࠷ᔬ"):  from c7KQ0lWkAi 		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==NxsKJnLFEZ9OHXf1h(u"࠹ᔭ"):  from H1DloyNq5C 		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==GGCQK6OAtZUXRhvkgJm(u"࠻ᔮ"):  from fxd9jQipFC 			import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠽ᔯ"):  from QQE3oVh6qc 		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==WbM6qAjrn7fEXGZw(u"࠿ᔰ"):  from rLTs7bRDvl		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==FeyZbj8tDil0nSHzTwfsUJ9(u"࠱࠱ᔱ"): from n2YezkX8vr 		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠲࠳ᔲ"): from UBlEgwVT6y 		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==NxsKJnLFEZ9OHXf1h(u"࠳࠵ᔳ"): from M0Iwvgie2s 		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,tsMKaFVh1ZN2BIXEcvTejxR5DP,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠴࠷ᔴ"): from v9cAHL6Itd		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,tsMKaFVh1ZN2BIXEcvTejxR5DP,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==ItgK5FqGDz2Rf7mAJkbT(u"࠵࠹ᔵ"): from dULi8YwfV6 		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s,Rl48v7kIh3cgF1fzOS6mQ9,tsMKaFVh1ZN2BIXEcvTejxR5DP,TDmqAUj2Mfyir0PvS,OHMhVx5cw76slynUDdF24jgbkNG)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==GGCQK6OAtZUXRhvkgJm(u"࠶࠻ᔶ"): from m4OhBzk7o2 		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==WbM6qAjrn7fEXGZw(u"࠷࠶ᔷ"): from M5PXpC6USK		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s,tsMKaFVh1ZN2BIXEcvTejxR5DP,zSPVUW1XDt2Ba6ZkAH)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==bbqAtUz36RPGVTvCkejpJXQB(u"࠱࠸ᔸ"): from m4OhBzk7o2 		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠲࠺ᔹ"): from ke4lX91cHF		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==tOdiG2HWFRBXg1sUh(u"࠳࠼ᔺ"): from m4OhBzk7o2 		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==WbM6qAjrn7fEXGZw(u"࠵࠴ᔻ"): from nEhfOWmx8u		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==S26SnaqcM9XwK8PVphJDv5(u"࠶࠶ᔼ"): from HHTr7ZpI8R	import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==smpniPDOhfwI3H4v7c6TG(u"࠷࠸ᔽ"): from KiUAwWYdC3		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,tsMKaFVh1ZN2BIXEcvTejxR5DP,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==smpniPDOhfwI3H4v7c6TG(u"࠸࠳ᔾ"): from XTA49cQUuV	import N0NXgq1LxMG5zdr3ZDfho497lyI	; s4Bng5iAZQSTtpDw9 = N0NXgq1LxMG5zdr3ZDfho497lyI(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s,Rl48v7kIh3cgF1fzOS6mQ9,tsMKaFVh1ZN2BIXEcvTejxR5DP,zSPVUW1XDt2Ba6ZkAH)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==CIcPowhneWs5tN3(u"࠲࠵ᔿ"): from JJjPSnbr9G 			import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==smpniPDOhfwI3H4v7c6TG(u"࠳࠷ᕀ"): from AOiTe7sQSc 		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==ta478EuZQJIWhgBnsf6iU(u"࠴࠹ᕁ"): from Uyonvur1IK 			import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==EAw9bg4rT3Bd8tjSkO(u"࠵࠻ᕂ"): from S8VCsPpcIU	import N0NXgq1LxMG5zdr3ZDfho497lyI	; s4Bng5iAZQSTtpDw9 = N0NXgq1LxMG5zdr3ZDfho497lyI(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,HHa1QbqG07ZPXko5fR)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠶࠽ᕃ"): from XTA49cQUuV	import N0NXgq1LxMG5zdr3ZDfho497lyI	; s4Bng5iAZQSTtpDw9 = N0NXgq1LxMG5zdr3ZDfho497lyI(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s,Rl48v7kIh3cgF1fzOS6mQ9,tsMKaFVh1ZN2BIXEcvTejxR5DP,zSPVUW1XDt2Ba6ZkAH)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠷࠿ᕄ"): from esC5MfzSOi	import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,tsMKaFVh1ZN2BIXEcvTejxR5DP,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠹࠰ᕅ"): from qqQlJH0SDK		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠳࠲ᕆ"): from FyYKCMczkr		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==ItgK5FqGDz2Rf7mAJkbT(u"࠴࠴ᕇ"): from uugUkRhyC5		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==QmoEjB3hLIw(u"࠵࠶ᕈ"): from EA7YdxohlC		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==r6juULGQtnExAko38BZ5Y(u"࠶࠸ᕉ"): from m4OhBzk7o2 		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠷࠺ᕊ"): from PFo6yw8eGk		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠸࠼ᕋ"): from s0atThLKQ2			import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠹࠷ᕌ"): from OOGxT27leJ			import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==WbM6qAjrn7fEXGZw(u"࠳࠹ᕍ"): from GuD5gHAba8 		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠴࠻ᕎ"): from IsuUz5pLN1		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==CIcPowhneWs5tN3(u"࠶࠳ᕏ"): from p4kPMX2AEO	import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s,Rl48v7kIh3cgF1fzOS6mQ9,tsMKaFVh1ZN2BIXEcvTejxR5DP)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==smpniPDOhfwI3H4v7c6TG(u"࠷࠵ᕐ"): from p4kPMX2AEO	import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s,Rl48v7kIh3cgF1fzOS6mQ9,tsMKaFVh1ZN2BIXEcvTejxR5DP)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==qFRrj7ayBKbOsHGSXz(u"࠸࠷ᕑ"): from zq4LAwRVK1			import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==r6juULGQtnExAko38BZ5Y(u"࠹࠹ᕒ"): from xbY0T1dei7			import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==ItgK5FqGDz2Rf7mAJkbT(u"࠺࠴ᕓ"): from dGvsHt378O		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==GGCQK6OAtZUXRhvkgJm(u"࠴࠶ᕔ"): from ii7t01MNKq		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠵࠸ᕕ"): from q278pzF9eZ			import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠶࠺ᕖ"): from MQ3pKzOWqD		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠷࠼ᕗ"): from MMivyuf1F0		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==bbqAtUz36RPGVTvCkejpJXQB(u"࠸࠾ᕘ"): from wMuFlHxfKr		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==Kwl07iYTtDLN3zP(u"࠺࠶ᕙ"): from m4OhBzk7o2 		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==r6juULGQtnExAko38BZ5Y(u"࠻࠱ᕚ"): from qqW9tE0SQj 		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==Ox8k6IdtuPaG3NlApQK52oYwM(u"࠵࠳ᕛ"): from qqW9tE0SQj 		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠶࠵ᕜ"): from Uyonvur1IK 			import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==smpniPDOhfwI3H4v7c6TG(u"࠷࠷ᕝ"): from MMHzE6r0uI	import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s,tsMKaFVh1ZN2BIXEcvTejxR5DP)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠸࠹ᕞ"): from fVoSDTZypM 		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠹࠻ᕟ"): from CJ2q9lUhtG			import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==uAl3gHavMJZL4xmNe62nDiBoQ(u"࠺࠽ᕠ"): from wwu1o5empx		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠻࠸ᕡ"): from Ao76Nzcea0		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==wx18CTJPZ5(u"࠵࠺ᕢ"): from or56Zw7FbD		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠷࠲ᕣ"): from wBQq6lICYj			import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==WbM6qAjrn7fEXGZw(u"࠸࠴ᕤ"): from Q9EYujcbqT			import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==tOdiG2HWFRBXg1sUh(u"࠹࠶ᕥ"): from PQoCcuxB7j		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠺࠸ᕦ"): from fn1aeOjp2J	import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠻࠺ᕧ"): from v14AE0Bi5Z			import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==r6juULGQtnExAko38BZ5Y(u"࠼࠵ᕨ"): from wtINk5Eb9R			import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠶࠷ᕩ"): from xxA7UYVTSw			import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==GGCQK6OAtZUXRhvkgJm(u"࠷࠹ᕪ"): from PaGwrUkK2f		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==r6juULGQtnExAko38BZ5Y(u"࠸࠻ᕫ"): from Mr3v146emc		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==GGCQK6OAtZUXRhvkgJm(u"࠹࠽ᕬ"): from T4yzVo7xcj		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==NxsKJnLFEZ9OHXf1h(u"࠻࠵ᕭ"): from s2AFN4bBWv			import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠼࠷ᕮ"): from ytYp4ZnKL3	import N0NXgq1LxMG5zdr3ZDfho497lyI	; s4Bng5iAZQSTtpDw9 = N0NXgq1LxMG5zdr3ZDfho497lyI(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s,Rl48v7kIh3cgF1fzOS6mQ9,tsMKaFVh1ZN2BIXEcvTejxR5DP,zSPVUW1XDt2Ba6ZkAH)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==GGCQK6OAtZUXRhvkgJm(u"࠽࠲ᕯ"): from ytYp4ZnKL3	import N0NXgq1LxMG5zdr3ZDfho497lyI	; s4Bng5iAZQSTtpDw9 = N0NXgq1LxMG5zdr3ZDfho497lyI(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s,Rl48v7kIh3cgF1fzOS6mQ9,tsMKaFVh1ZN2BIXEcvTejxR5DP,zSPVUW1XDt2Ba6ZkAH)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==GGCQK6OAtZUXRhvkgJm(u"࠷࠴ᕰ"): from XlPutyixBV	import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠸࠶ᕱ"): from yrcQbxljTi		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==WbM6qAjrn7fEXGZw(u"࠹࠸ᕲ"): from yrcQbxljTi		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠺࠺ᕳ"): from M5PXpC6USK		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s,tsMKaFVh1ZN2BIXEcvTejxR5DP,zSPVUW1XDt2Ba6ZkAH)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==smpniPDOhfwI3H4v7c6TG(u"࠻࠼ᕴ"): from EyjK7UelOR 		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,tsMKaFVh1ZN2BIXEcvTejxR5DP,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==Gk98CL5nXZEN(u"࠼࠾ᕵ"): from QVwCf5FUju 		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,tsMKaFVh1ZN2BIXEcvTejxR5DP,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠽࠹ᕶ"): from kD3ofOX7xb 		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,tsMKaFVh1ZN2BIXEcvTejxR5DP,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==FeyZbj8tDil0nSHzTwfsUJ9(u"࠸࠱ᕷ"): from z75zMfBnES 		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,tsMKaFVh1ZN2BIXEcvTejxR5DP,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==bbqAtUz36RPGVTvCkejpJXQB(u"࠹࠳ᕸ"): from qSD1mfn4Ep 		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	elif gHRCjEDhqTldIzKO8VFiMp3yA14==MM564HfnUV0XIR(u"࠺࠵ᕹ"): from qF7TNgxJXU		import HgQCVwFx2Br	; s4Bng5iAZQSTtpDw9 = HgQCVwFx2Br(jjnQ0VI9EdeuoTlOt81rMpk5KsGfCU,pAeIhbuLSFw7j49qxtcg8dDrmKO,tsMKaFVh1ZN2BIXEcvTejxR5DP,hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	else: s4Bng5iAZQSTtpDw9 = None
	return s4Bng5iAZQSTtpDw9
def CCKZ1FbAdeyQIn6B9(G4KzAhcON3gwns1o5rIbai2FDJEXmy,rreason,dIsZG1fHm5YVkU6Puzq,showDialogs):
	PPsSFilbkTxQZDJY9ML5uVNO6 = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨ໠"))
	if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(GGCQK6OAtZUXRhvkgJm(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩ໡"),r6juULGQtnExAko38BZ5Y(u"ࠩࠪ໢"))
	if MM564HfnUV0XIR(u"ࠪ࠱ࠬ໣") in dIsZG1fHm5YVkU6Puzq: VewOrPR4kX = dIsZG1fHm5YVkU6Puzq.split(bbqAtUz36RPGVTvCkejpJXQB(u"ࠫ࠲࠭໤"),QmoEjB3hLIw(u"࠴ᕺ"))[zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠴ᕻ")]
	else: VewOrPR4kX = dIsZG1fHm5YVkU6Puzq
	ebQK9Wdv61h = G4KzAhcON3gwns1o5rIbai2FDJEXmy in [YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠸ᕿ"),Kwl07iYTtDLN3zP(u"࠷࠱࠱࠲࠴ᕽ"),CgPbwXm1RilpJUSGHLhy(u"࠶࠷࠰࠱࠴ᕼ"),wx18CTJPZ5(u"࠱࠱࠲࠸࠸ᕾ")]
	BkwLy4oHNTvdir = rreason.lower()
	ssTigXu0hxm5bAS2dRDBvqjz8 = G4KzAhcON3gwns1o5rIbai2FDJEXmy in [zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠲ᖀ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠶࠶࠴ᖃ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠴࠴࠵࠼࠱ᖁ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠵࠶࠷ᖂ")]
	Vqn9kWuHe4g0AJEI3 = Gk98CL5nXZEN(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪ࠭໥") in BkwLy4oHNTvdir
	lVRanfBwMCrGHqLOTIm = ta478EuZQJIWhgBnsf6iU(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣ࠹ࠥࡹࡥࡤࡱࡱࡨࡸࠦࡢࡳࡱࡺࡷࡪࡸࠠࡤࡪࡨࡧࡰ࠭໦") in BkwLy4oHNTvdir
	kQ5gChMc8moJGZOaNEK2SY64bwpiHR = YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧࠧ໧") in BkwLy4oHNTvdir
	HMQWqviFTcB = qFRrj7ayBKbOsHGSXz(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠢࡶࡩࡨࡻࡲࡪࡶࡼࠤࡨ࡮ࡥࡤ࡭ࠪ໨") in BkwLy4oHNTvdir
	fLjePgi96lUbn = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(MM564HfnUV0XIR(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧ໩"))
	jQdbDoanq4SyCYI916 = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(EAw9bg4rT3Bd8tjSkO(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭໪"))
	MMGBExRiaI0 = tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠫๆฺไࠡใํࠤุำศࠡษ็ูๆำษࠡ็้ࠤฬ๊ล็ฬิ๊ฯ࠭໫")
	trPdybWv2ShoQA4fG = GGCQK6OAtZUXRhvkgJm(u"ࠬࡋࡲࡳࡱࡵࠤࠬ໬")+str(G4KzAhcON3gwns1o5rIbai2FDJEXmy)+NNmirJKPp5nWjfC(u"࠭࠺ࠡࠩ໭")+rreason
	trPdybWv2ShoQA4fG = BUTSkzgFC7(trPdybWv2ShoQA4fG)
	if ssTigXu0hxm5bAS2dRDBvqjz8 or Vqn9kWuHe4g0AJEI3 or lVRanfBwMCrGHqLOTIm or kQ5gChMc8moJGZOaNEK2SY64bwpiHR or HMQWqviFTcB:
		MMGBExRiaI0 += YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠧࠡ࠰ࠣห้๋่ใ฻ࠣๅ๏ํࠠฮฮหࠤ฻ีࠠไ๊า๎๋ࠥีะำ๊ࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูࠥฮใࠡล๋ࠤออไๆ๊ๅ฽ࡡࡴࠧ໮")
	if ebQK9Wdv61h: MMGBExRiaI0 += wx18CTJPZ5(u"ࠨࠢ࠱ࠤ้ี๊ไࠢั฻ศࠦࡄࡏࡕࠣ์๊฿ๆศ้ࠣฮ฾ึัࠡฬิะ๊ฯࠠศี่ࠤฬ๊ๅ้ไ฼ࠤส๊้ࠡำๅ้์ࡢ࡮ࠨ໯")
	trPdybWv2ShoQA4fG = WbM6qAjrn7fEXGZw(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ໰")+trPdybWv2ShoQA4fG+Gk98CL5nXZEN(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ໱")
	if fLjePgi96lUbn==smpniPDOhfwI3H4v7c6TG(u"ࠫࡆ࡙ࡋࠨ໲") or jQdbDoanq4SyCYI916==YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠬࡇࡓࡌࠩ໳"):
		MMGBExRiaI0 += NNmirJKPp5nWjfC(u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠ๋้ࠦสา์าࠤศ์๋ࠠฯส์้ࠦวๅสิ๊ฬ๋ฬࠡวุ่ฬำࠠศๆุ่่๊ษࠡ࠰࠱ࠤศ๋ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣวํࠦฮุลࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡมࠤࠥࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭໴")
	Fncr184vpwJUPQt = wx18CTJPZ5(u"ࡊࡦࡲࡳࡦᜊ")
	if showDialogs and dIsZG1fHm5YVkU6Puzq not in GImcXg9OBxnZFlj4qe:
		if fLjePgi96lUbn==Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠧࡂࡕࡎࠫ໵") or jQdbDoanq4SyCYI916==Kwl07iYTtDLN3zP(u"ࠨࡃࡖࡏࠬ໶"):
			JJ94bQazqrY1wS = m5NUYqBzGynIOeAg8(CgPbwXm1RilpJUSGHLhy(u"ࠩࡦࡩࡳࡺࡥࡳࠩ໷"),tOdiG2HWFRBXg1sUh(u"ࠪาึ๎ฬࠨ໸"),NNmirJKPp5nWjfC(u"ࠫสืำศๆࠣีุอไสࠢ็่๊ฮัๆฮࠪ໹"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠬหีๅษะࠤฬ๊ๅีๅ็อࠬ໺"),VewOrPR4kX+bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠭ࠠࠡࠢࠪ໻")+NNbLf2d3Slq6pV(VewOrPR4kX),MMGBExRiaI0+uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠧ࡝ࡰࠪ໼")+trPdybWv2ShoQA4fG)
			if JJ94bQazqrY1wS==I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠷ᖄ"):
				from m4OhBzk7o2 import oOmLC8y1REg
				oOmLC8y1REg()
			elif JJ94bQazqrY1wS==QmoEjB3hLIw(u"࠲ᖅ"): Fncr184vpwJUPQt = YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࡙ࡸࡵࡦᜋ")
		else: tehb3k5a2PufGOdBIUw8j(bbqAtUz36RPGVTvCkejpJXQB(u"ࠨࠩ໽"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠩࠪ໾"),VewOrPR4kX+ta478EuZQJIWhgBnsf6iU(u"ࠪࠤࠥࠦࠧ໿")+NNbLf2d3Slq6pV(VewOrPR4kX),MMGBExRiaI0,trPdybWv2ShoQA4fG)
	if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(NxsKJnLFEZ9OHXf1h(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬༀ"),PPsSFilbkTxQZDJY9ML5uVNO6)
	return Fncr184vpwJUPQt
def cLVWgMwAhBrbx2Jfltk4Y96opmv5UH(QF0Gd7aIH9TWzB=QmoEjB3hLIw(u"ࡌࡡ࡭ࡵࡨᜌ"),DDmgN2PrQb04pS3KTk68sXOw1=[]):
	LzIeX6oqt7KrgsWfNuw3 = [D5q7g8N0XowOn2Q,LkNCuYDaeV576vtyI]+DDmgN2PrQb04pS3KTk68sXOw1
	for dkL0Qy5ZolhseOuCRKMrABV8Uzp in K3hFytImeYMkJBC.listdir(llrbyaFHOt9e):
		if QF0Gd7aIH9TWzB and (dkL0Qy5ZolhseOuCRKMrABV8Uzp.startswith(wx18CTJPZ5(u"ࠬ࡯ࡰࡵࡸࠪ༁")) or dkL0Qy5ZolhseOuCRKMrABV8Uzp.startswith(S26SnaqcM9XwK8PVphJDv5(u"࠭࡭࠴ࡷࠪ༂"))): continue
		if dkL0Qy5ZolhseOuCRKMrABV8Uzp.startswith(CgPbwXm1RilpJUSGHLhy(u"ࠧࡧ࡫࡯ࡩࡤ࠭༃")): continue
		sb1RGtoOKZdSz2jiefPBn4WgH9 = K3hFytImeYMkJBC.path.join(llrbyaFHOt9e,dkL0Qy5ZolhseOuCRKMrABV8Uzp)
		if sb1RGtoOKZdSz2jiefPBn4WgH9 in LzIeX6oqt7KrgsWfNuw3: continue
		try: K3hFytImeYMkJBC.remove(sb1RGtoOKZdSz2jiefPBn4WgH9)
		except: pass
	if urI4Umothli03k1Ee not in LzIeX6oqt7KrgsWfNuw3: oFHcGJSy62KieOMmZv4f0l(urI4Umothli03k1Ee,MM564HfnUV0XIR(u"ࡕࡴࡸࡩᜎ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࡆࡢ࡮ࡶࡩᜍ"))
	w6vebiEZtpCjJcILP8Skx5rHn.sleep(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠲ᖆ"))
	return
def d5nFc0OjTBtlG8uXzxwKiqaYI(DDoZ3udHfetg,VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF,pAeIhbuLSFw7j49qxtcg8dDrmKO,YReuIJ67GDs8NwEiZOAh4xPMb,XzfkYQBICVuSjcL5G0pgy9T16xv,N1N2sUZu9QXRLj6rFeHEKg,showDialogs,dIsZG1fHm5YVkU6Puzq,kQ36atvU4rpcWoH7MGdE8yCezZD1=S26SnaqcM9XwK8PVphJDv5(u"ࡖࡵࡹࡪᜏ"),zcGCKESFR0Yt=S26SnaqcM9XwK8PVphJDv5(u"ࡖࡵࡹࡪᜏ")):
	pAeIhbuLSFw7j49qxtcg8dDrmKO = pAeIhbuLSFw7j49qxtcg8dDrmKO+GGCQK6OAtZUXRhvkgJm(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨ༄")+DDoZ3udHfetg
	Il5iAWS8vkNBe4Xf = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF,pAeIhbuLSFw7j49qxtcg8dDrmKO,YReuIJ67GDs8NwEiZOAh4xPMb,XzfkYQBICVuSjcL5G0pgy9T16xv,N1N2sUZu9QXRLj6rFeHEKg,showDialogs,dIsZG1fHm5YVkU6Puzq,kQ36atvU4rpcWoH7MGdE8yCezZD1,zcGCKESFR0Yt)
	if pAeIhbuLSFw7j49qxtcg8dDrmKO in Il5iAWS8vkNBe4Xf.content: Il5iAWS8vkNBe4Xf.succeeded = uAl3gHavMJZL4xmNe62nDiBoQ(u"ࡉࡥࡱࡹࡥᜐ")
	if not Il5iAWS8vkNBe4Xf.succeeded:
		X5LD1xAj8Nuas3b4pFHC(CIcPowhneWs5tN3(u"ࠩࡋࡘ࡙ࡖࠠࡓࡧࡴࡹࡪࡹࡴࠡࡈࡤ࡭ࡱࡻࡲࡦࠩ༅"))
	return Il5iAWS8vkNBe4Xf
def HBavqJCPtNgsnU(pAeIhbuLSFw7j49qxtcg8dDrmKO):
	Il5iAWS8vkNBe4Xf = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,qFRrj7ayBKbOsHGSXz(u"ࠪࡋࡊ࡚ࠧ༆"),pAeIhbuLSFw7j49qxtcg8dDrmKO,qFRrj7ayBKbOsHGSXz(u"ࠫࠬ༇"),GGCQK6OAtZUXRhvkgJm(u"ࠬ࠭༈"),wx18CTJPZ5(u"࡙ࡸࡵࡦᜒ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠭ࠧ༉"),NxsKJnLFEZ9OHXf1h(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡘࡤࡖࡒࡐ࡚ࡌࡉࡘࡥࡌࡊࡕࡗ࠱࠶ࡹࡴࠨ༊"),wx18CTJPZ5(u"࡙ࡸࡵࡦᜒ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࡊࡦࡲࡳࡦᜑ"))
	KPogc8TrDdR4BkJZtM9sFwbC = []
	if Il5iAWS8vkNBe4Xf.succeeded:
		TcPFsujHEQG3vBwCt = Il5iAWS8vkNBe4Xf.content
		hhWZKiTvROMbFszXLayAe9mElwVtj = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(WbM6qAjrn7fEXGZw(u"ࠨࠢࠫ࠲࠯ࡅࠩࠡ࡞ࡧࡿ࠶࠲࠳ࡾ࡯ࡶࠫ་"),TcPFsujHEQG3vBwCt)
		if hhWZKiTvROMbFszXLayAe9mElwVtj: TcPFsujHEQG3vBwCt = wx18CTJPZ5(u"ࠩ࡟ࡲࠬ༌").join(hhWZKiTvROMbFszXLayAe9mElwVtj)
		hSYAxPLswHz8JlvK = TcPFsujHEQG3vBwCt.replace(NxsKJnLFEZ9OHXf1h(u"ࠪࡠࡷ࠭།"),smpniPDOhfwI3H4v7c6TG(u"ࠫࠬ༎")).strip(r6juULGQtnExAko38BZ5Y(u"ࠬࡢ࡮ࠨ༏")).split(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠭࡜࡯ࠩ༐"))
		KPogc8TrDdR4BkJZtM9sFwbC = []
		for DDoZ3udHfetg in hSYAxPLswHz8JlvK:
			if DDoZ3udHfetg.count(CgPbwXm1RilpJUSGHLhy(u"ࠧ࠯ࠩ༑"))==SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠵ᖇ"): KPogc8TrDdR4BkJZtM9sFwbC.append(DDoZ3udHfetg)
	return KPogc8TrDdR4BkJZtM9sFwbC
def PoxF3Z7ifK2h8O(*aargs):
	sIxPmUawpW362tvCnkioE9hj = r6juULGQtnExAko38BZ5Y(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡴ࡮࠴ࡰࡳࡱࡻࡽࡸࡩࡲࡢࡲࡨ࠲ࡨࡵ࡭࠰ࡸ࠵࠳ࡄࡸࡥࡲࡷࡨࡷࡹࡃࡤࡪࡵࡳࡰࡦࡿࡰࡳࡱࡻ࡭ࡪࡹࠦࡱࡴࡲࡼࡾࡺࡹࡱࡧࡀ࡬ࡹࡺࡰࠧࡶ࡬ࡱࡪࡵࡵࡵ࠿࠴࠴࠵࠶࠰ࠧࡵࡶࡰࡂࡿࡥࡴࠨ࡯࡭ࡲ࡯ࡴ࠾࠳࠳ࠪࡨࡵࡵ࡯ࡶࡵࡽࡂࡔࡌ࠭ࡄࡈ࠰ࡉࡋࠬࡇࡔ࠯ࡋࡇ࠲ࡔࡓࠩ༒")
	EBmXcUP8TdKFCvAH = WbM6qAjrn7fEXGZw(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡶࡦࡽ࠮ࡨ࡫ࡷ࡬ࡺࡨࡵࡴࡧࡵࡧࡴࡴࡴࡦࡰࡷ࠲ࡨࡵ࡭࠰ࡴࡲࡳࡸࡺࡥࡳ࡭࡬ࡨ࠴ࡵࡰࡦࡰࡳࡶࡴࡾࡹ࡭࡫ࡶࡸ࠴ࡳࡡࡪࡰ࠲ࡌ࡙࡚ࡐࡔ࠰ࡷࡼࡹ࠭༓")
	UImJe9EGdyn = HBavqJCPtNgsnU(EBmXcUP8TdKFCvAH)
	KPogc8TrDdR4BkJZtM9sFwbC = HBavqJCPtNgsnU(sIxPmUawpW362tvCnkioE9hj)
	LsJi74VkCnmPqo = UImJe9EGdyn+KPogc8TrDdR4BkJZtM9sFwbC
	y75wQavkVSLUb2MZf9qo(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ༔"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+ta478EuZQJIWhgBnsf6iU(u"ࠫࠥࠦࠠࡈࡱࡷࠤࡵࡸ࡯ࡹ࡫ࡨࡷࠥࡲࡩࡴࡶࠣࠤࠥ࠷ࡳࡵ࠭࠵ࡲࡩࡀࠠ࡜ࠢࠪ༕")+str(len(UImJe9EGdyn))+CIcPowhneWs5tN3(u"ࠬ࠱ࠧ༖")+str(len(KPogc8TrDdR4BkJZtM9sFwbC))+MM564HfnUV0XIR(u"࠭ࠠ࡞ࠩ༗"))
	DDoZ3udHfetg = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺ༘ࠧ"))
	Il5iAWS8vkNBe4Xf = bbWis1pMJaqDek()
	if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨ༙"),dEUYJjrhsaPXNo(u"ࠩࠪ༚"))
	if DDoZ3udHfetg or LsJi74VkCnmPqo:
		N0DKTmwQprlGkE,mze2PWBb1idXw9Z0Hh = S26SnaqcM9XwK8PVphJDv5(u"࠳ᖈ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠵࠵ᖉ")
		cc5ONBwyG2zC0W6qlF3vZ8bshV = len(LsJi74VkCnmPqo)
		T3M2uhNjB7 = mze2PWBb1idXw9Z0Hh
		if cc5ONBwyG2zC0W6qlF3vZ8bshV>T3M2uhNjB7: JJfti3jNGogdzq0EnbP6cVyr = T3M2uhNjB7
		else: JJfti3jNGogdzq0EnbP6cVyr = cc5ONBwyG2zC0W6qlF3vZ8bshV
		MXj7Vxek5Un0HhQ4YNWo = BBioyg7XVR.sample(LsJi74VkCnmPqo,JJfti3jNGogdzq0EnbP6cVyr)
		if DDoZ3udHfetg: MXj7Vxek5Un0HhQ4YNWo = [DDoZ3udHfetg]+MXj7Vxek5Un0HhQ4YNWo
		wL8xMBJXtcE4vUTGNS = MrpuQ4b0AfZ6scLH(dEUYJjrhsaPXNo(u"ࡌࡡ࡭ࡵࡨᜓ"),dEUYJjrhsaPXNo(u"ࡌࡡ࡭ࡵࡨᜓ"))
		LRtXWQ1zyFBCbP7SUhZ20a = w6vebiEZtpCjJcILP8Skx5rHn.time()
		while w6vebiEZtpCjJcILP8Skx5rHn.time()-LRtXWQ1zyFBCbP7SUhZ20a<=mze2PWBb1idXw9Z0Hh and not wL8xMBJXtcE4vUTGNS.finishedLIST:
			if N0DKTmwQprlGkE<JJfti3jNGogdzq0EnbP6cVyr:
				DDoZ3udHfetg = MXj7Vxek5Un0HhQ4YNWo[N0DKTmwQprlGkE]
				wL8xMBJXtcE4vUTGNS.RLX07K6brEf(N0DKTmwQprlGkE,d5nFc0OjTBtlG8uXzxwKiqaYI,DDoZ3udHfetg,*aargs)
			w6vebiEZtpCjJcILP8Skx5rHn.sleep(WbM6qAjrn7fEXGZw(u"࠶ᖊ"))
			N0DKTmwQprlGkE += S26SnaqcM9XwK8PVphJDv5(u"࠷ᖋ")
			y75wQavkVSLUb2MZf9qo(bbqAtUz36RPGVTvCkejpJXQB(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ༛"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+Kwl07iYTtDLN3zP(u"ࠫࠥࠦࠠࡕࡴࡼ࡭ࡳ࡭࠺ࠡࠢࠣࡔࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭༜")+DDoZ3udHfetg+zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠬࠦ࡝ࠨ༝"))
		finishedLIST = wL8xMBJXtcE4vUTGNS.finishedLIST
		if finishedLIST:
			resultsDICT = wL8xMBJXtcE4vUTGNS.resultsDICT
			rhSiYHIaPJGkpNR2A7CO3vzfUZyeX = finishedLIST[EAw9bg4rT3Bd8tjSkO(u"࠰ᖌ")]
			Il5iAWS8vkNBe4Xf = resultsDICT[rhSiYHIaPJGkpNR2A7CO3vzfUZyeX]
			DDoZ3udHfetg = MXj7Vxek5Un0HhQ4YNWo[int(rhSiYHIaPJGkpNR2A7CO3vzfUZyeX)]
			if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯࡮ࡤࡷࡹ࠭༞"),DDoZ3udHfetg)
			if rhSiYHIaPJGkpNR2A7CO3vzfUZyeX!=NxsKJnLFEZ9OHXf1h(u"࠱ᖍ"): y75wQavkVSLUb2MZf9qo(Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭༟"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+GGCQK6OAtZUXRhvkgJm(u"ࠨࠢࠣࠤࡘࡻࡣࡤࡧࡶࡷ࠿ࠦࠠࠡࡒࡵࡳࡽࡿ࠺ࠡ࡝ࠣࠫ༠")+DDoZ3udHfetg+tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠩࠣࡡࠬ༡"))
			else: y75wQavkVSLUb2MZf9qo(I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ༢"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+QmoEjB3hLIw(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪࡹࡳ࠻ࠢࠣࠤࡘࡧࡶࡦࡦࠣࡴࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭༣")+DDoZ3udHfetg+NxsKJnLFEZ9OHXf1h(u"ࠬࠦ࡝ࠨ༤"))
	return Il5iAWS8vkNBe4Xf
def nnMOiPSwU3Qapj501X8Co2YJB(hhGodXVgTLpC92yOM3D,lbzUsDZE3MntmwucgjKa):
	GXDlkY35uAHBnmhJfK1jIyLEZVg = hhGodXVgTLpC92yOM3D.create_connection
	def SP6YuUMweptXovlsa890bqLJWBidQK(qCfuLOasxdz6kDl1PWgnVK,*aargs,**kkwargs):
		IIOrTgqjuxv,s7ECqbiagkSBKfPLYOMpFxo = qCfuLOasxdz6kDl1PWgnVK
		ip = RePNIXDAy4GifxQqKg(IIOrTgqjuxv,lbzUsDZE3MntmwucgjKa)
		if ip: IIOrTgqjuxv = ip[CgPbwXm1RilpJUSGHLhy(u"࠲ᖎ")]
		else:
			if lbzUsDZE3MntmwucgjKa in y4Be6ljV9o7DNAdFO0aQtWpY: y4Be6ljV9o7DNAdFO0aQtWpY.remove(lbzUsDZE3MntmwucgjKa)
			if y4Be6ljV9o7DNAdFO0aQtWpY:
				yKAN6UqEpYR8c1MDOPXS0xbQlu = y4Be6ljV9o7DNAdFO0aQtWpY[Gk98CL5nXZEN(u"࠳ᖏ")]
				ip = RePNIXDAy4GifxQqKg(IIOrTgqjuxv,yKAN6UqEpYR8c1MDOPXS0xbQlu)
				if ip: IIOrTgqjuxv = ip[YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠴ᖐ")]
		qCfuLOasxdz6kDl1PWgnVK = (IIOrTgqjuxv,s7ECqbiagkSBKfPLYOMpFxo)
		return GXDlkY35uAHBnmhJfK1jIyLEZVg(qCfuLOasxdz6kDl1PWgnVK,*aargs,**kkwargs)
	hhGodXVgTLpC92yOM3D.create_connection = SP6YuUMweptXovlsa890bqLJWBidQK
	return GXDlkY35uAHBnmhJfK1jIyLEZVg
def mt4bz6jBf1oANia0n8(pAeIhbuLSFw7j49qxtcg8dDrmKO):
	Qds8UyvFZXJSKc9oVl1Aa36t,xyVmG0YM5KgiRneOdFfNvW = pAeIhbuLSFw7j49qxtcg8dDrmKO.split(smpniPDOhfwI3H4v7c6TG(u"࠭࠯ࠨ༥"))[FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠸ᖒ")],QmoEjB3hLIw(u"࠽࠶ᖑ")
	if zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠧ࠻ࠩ༦") in Qds8UyvFZXJSKc9oVl1Aa36t: Qds8UyvFZXJSKc9oVl1Aa36t,xyVmG0YM5KgiRneOdFfNvW = Qds8UyvFZXJSKc9oVl1Aa36t.split(smpniPDOhfwI3H4v7c6TG(u"ࠨ࠼ࠪ༧"))
	Sq4inwoX6RaO32Jk9jTuMFlNtK0IYc = NxsKJnLFEZ9OHXf1h(u"ࠩ࠲ࠫ༨")+Kwl07iYTtDLN3zP(u"ࠪ࠳ࠬ༩").join(pAeIhbuLSFw7j49qxtcg8dDrmKO.split(CgPbwXm1RilpJUSGHLhy(u"ࠫ࠴࠭༪"))[WbM6qAjrn7fEXGZw(u"࠳ᖓ"):])
	VWi2dTb46v3eOryuspKBF9L = r6juULGQtnExAko38BZ5Y(u"ࠬࡍࡅࡕࠢࠪ༫")+Sq4inwoX6RaO32Jk9jTuMFlNtK0IYc+YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠭ࠠࡉࡖࡗࡔ࠴࠷࠮࠲࡞ࡵࡠࡳ࠭༬")
	VWi2dTb46v3eOryuspKBF9L += Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠧࡉࡱࡶࡸ࠿ࠦࠧ༭")+Qds8UyvFZXJSKc9oVl1Aa36t+FeyZbj8tDil0nSHzTwfsUJ9(u"ࠨ࡞ࡵࡠࡳ࠭༮")
	VWi2dTb46v3eOryuspKBF9L += YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠩ࡟ࡶࡡࡴࠧ༯")
	from socket import socket as UnVKvhfHwd6pYx37Wk,AF_INET as c7kgPIzjmT,SOCK_STREAM as b0jWpJLRsD4omGnBXefT38yM
	try:
		ddl8bF9SJv = UnVKvhfHwd6pYx37Wk(c7kgPIzjmT,b0jWpJLRsD4omGnBXefT38yM)
		ddl8bF9SJv.connect((Qds8UyvFZXJSKc9oVl1Aa36t,xyVmG0YM5KgiRneOdFfNvW))
		ddl8bF9SJv.send(VWi2dTb46v3eOryuspKBF9L.encode(Kwl07iYTtDLN3zP(u"ࠪࡹࡹ࡬࠸ࠨ༰")))
		BfEhFOcXNgRykCY0 = ddl8bF9SJv.recv(NNmirJKPp5nWjfC(u"࠶࠳࠽࠻ᖕ")*ItgK5FqGDz2Rf7mAJkbT(u"࠲࠲࠵࠸ᖔ"))
		TcPFsujHEQG3vBwCt = repr(BfEhFOcXNgRykCY0)
	except: TcPFsujHEQG3vBwCt = bbqAtUz36RPGVTvCkejpJXQB(u"ࠫࠬ༱")
	return TcPFsujHEQG3vBwCt
def SLMTm6RQ34ic7v5s9rBG(Hzywg9LuXC0reKT3D8h6WI,Rl48v7kIh3cgF1fzOS6mQ9):
	if NxsKJnLFEZ9OHXf1h(u"ࠬ࠴ࠧ༲") not in Hzywg9LuXC0reKT3D8h6WI: return Hzywg9LuXC0reKT3D8h6WI
	Hzywg9LuXC0reKT3D8h6WI = Hzywg9LuXC0reKT3D8h6WI+qFRrj7ayBKbOsHGSXz(u"࠭࠯ࠨ༳")
	mBPiLjG93dxUAt4XgIMR7YV,Nd5c6sS0XKMhg4Wab9G = Hzywg9LuXC0reKT3D8h6WI.split(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠧ࠯ࠩ༴"),tOdiG2HWFRBXg1sUh(u"࠴ᖖ"))
	GzMCZDQReaFrqL7SIYnpu1,RrdfVcuAEBThb = Nd5c6sS0XKMhg4Wab9G.split(cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠨ࠱༵ࠪ"),EAw9bg4rT3Bd8tjSkO(u"࠵ᖗ"))
	qy8WbkjXRIeghUPdFM41aHBxo5tc = mBPiLjG93dxUAt4XgIMR7YV+cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠩ࠱ࠫ༶")+GzMCZDQReaFrqL7SIYnpu1
	if Rl48v7kIh3cgF1fzOS6mQ9 in [S26SnaqcM9XwK8PVphJDv5(u"ࠪ࡬ࡴࡹࡴࠨ༷"),WbM6qAjrn7fEXGZw(u"ࠫࡳࡧ࡭ࡦࠩ༸")] and cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠬ࠵༹ࠧ") in qy8WbkjXRIeghUPdFM41aHBxo5tc: qy8WbkjXRIeghUPdFM41aHBxo5tc = qy8WbkjXRIeghUPdFM41aHBxo5tc.rsplit(dEUYJjrhsaPXNo(u"࠭࠯ࠨ༺"),bbqAtUz36RPGVTvCkejpJXQB(u"࠶ᖘ"))[bbqAtUz36RPGVTvCkejpJXQB(u"࠶ᖘ")]
	if Rl48v7kIh3cgF1fzOS6mQ9==NNmirJKPp5nWjfC(u"ࠧ࡯ࡣࡰࡩࠬ༻") and GGCQK6OAtZUXRhvkgJm(u"ࠨ࠰ࠪ༼") in qy8WbkjXRIeghUPdFM41aHBxo5tc:
		xkEPSiMdJqRKLUHseQjDt3O8avN = qy8WbkjXRIeghUPdFM41aHBxo5tc.split(S26SnaqcM9XwK8PVphJDv5(u"ࠩ࠱ࠫ༽"))
		P6e9iLTvguIDEVpSwj2CGmkhlob73 = len(xkEPSiMdJqRKLUHseQjDt3O8avN)
		if P6e9iLTvguIDEVpSwj2CGmkhlob73<=S26SnaqcM9XwK8PVphJDv5(u"࠲ᖚ") or wx18CTJPZ5(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨ༾") in qy8WbkjXRIeghUPdFM41aHBxo5tc: xkEPSiMdJqRKLUHseQjDt3O8avN = xkEPSiMdJqRKLUHseQjDt3O8avN[SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠶ᖙ")]
		elif P6e9iLTvguIDEVpSwj2CGmkhlob73>=MM564HfnUV0XIR(u"࠵ᖜ"): xkEPSiMdJqRKLUHseQjDt3O8avN = xkEPSiMdJqRKLUHseQjDt3O8avN[tOdiG2HWFRBXg1sUh(u"࠲ᖛ")]
		if len(xkEPSiMdJqRKLUHseQjDt3O8avN)>GGCQK6OAtZUXRhvkgJm(u"࠴ᖝ"): qy8WbkjXRIeghUPdFM41aHBxo5tc = xkEPSiMdJqRKLUHseQjDt3O8avN
	return qy8WbkjXRIeghUPdFM41aHBxo5tc
def UjfpeA9CkYxt8XV(aasM6Lfz71BivCK2XxGhupm0dyo9):
	ZyGVYEBf6x72Dr1Uklj9 = repr(aasM6Lfz71BivCK2XxGhupm0dyo9.encode(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠫࡺࡺࡦ࠹ࠩ༿"))).replace(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠧ࠭ࠢཀ"),GGCQK6OAtZUXRhvkgJm(u"࠭ࠧཁ"))
	return ZyGVYEBf6x72Dr1Uklj9
def UdhlykB6XfC5NZVqORE0IQY(zR9HPQnULScXoalZgYj3v0):
	iHmGuDhq4vZoFKzQ7s6ja = FeyZbj8tDil0nSHzTwfsUJ9(u"ࠧࠨག")
	if vciEXHThAPto76QIR2pK: zR9HPQnULScXoalZgYj3v0 = zR9HPQnULScXoalZgYj3v0.decode(uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠨࡷࡷࡪ࠽࠭གྷ"))
	from unicodedata import decomposition as MUz2LypR7GhOecTZ56CakbwdF
	for O9FQ4z3u0RaTXx8 in zR9HPQnULScXoalZgYj3v0:
		if   O9FQ4z3u0RaTXx8==ItgK5FqGDz2Rf7mAJkbT(u"ࡷࠪฦࠬང"): ta62KwvS9NBiEfWG8VdL4rC = zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠪࡠࡡࡻ࠰࠷࠴࠵ࠫཅ")
		elif O9FQ4z3u0RaTXx8==I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࡹࠬษࠧཆ"): ta62KwvS9NBiEfWG8VdL4rC = bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠬࡢ࡜ࡶ࠲࠹࠶࠸࠭ཇ")
		elif O9FQ4z3u0RaTXx8==YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࡻࠧลࠩ཈"): ta62KwvS9NBiEfWG8VdL4rC = GGCQK6OAtZUXRhvkgJm(u"ࠧ࡝࡞ࡸ࠴࠻࠸࠴ࠨཉ")
		elif O9FQ4z3u0RaTXx8==I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࡶࠩศࠫཊ"): ta62KwvS9NBiEfWG8VdL4rC = I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠩ࡟ࡠࡺ࠶࠶࠳࠷ࠪཋ")
		elif O9FQ4z3u0RaTXx8==bbqAtUz36RPGVTvCkejpJXQB(u"ࡸࠫห࠭ཌ"): ta62KwvS9NBiEfWG8VdL4rC = ItgK5FqGDz2Rf7mAJkbT(u"ࠫࡡࡢࡵ࠱࠸࠵࠺ࠬཌྷ")
		else:
			yDas8cGmpMoAPU5xNX67W = MUz2LypR7GhOecTZ56CakbwdF(O9FQ4z3u0RaTXx8)
			if S26SnaqcM9XwK8PVphJDv5(u"ࠬࠦࠧཎ") in yDas8cGmpMoAPU5xNX67W: ta62KwvS9NBiEfWG8VdL4rC = NNmirJKPp5nWjfC(u"࠭࡜࡝ࡷࠪཏ")+yDas8cGmpMoAPU5xNX67W.split(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠧࠡࠩཐ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠵ᖞ"))[SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠵ᖞ")]
			else:
				ta62KwvS9NBiEfWG8VdL4rC = bbqAtUz36RPGVTvCkejpJXQB(u"ࠨ࠲࠳࠴࠵࠭ད")+hex(ord(O9FQ4z3u0RaTXx8)).replace(ta478EuZQJIWhgBnsf6iU(u"ࠩ࠳ࡼࠬདྷ"),qFRrj7ayBKbOsHGSXz(u"ࠪࠫན"))
				ta62KwvS9NBiEfWG8VdL4rC = bbqAtUz36RPGVTvCkejpJXQB(u"ࠫࡡࡢࡵࠨཔ")+ta62KwvS9NBiEfWG8VdL4rC[-FeyZbj8tDil0nSHzTwfsUJ9(u"࠹ᖟ"):]
		iHmGuDhq4vZoFKzQ7s6ja += ta62KwvS9NBiEfWG8VdL4rC
	iHmGuDhq4vZoFKzQ7s6ja = iHmGuDhq4vZoFKzQ7s6ja.replace(r6juULGQtnExAko38BZ5Y(u"ࠬࡢ࡜ࡶ࠲࠹ࡇࡈ࠭ཕ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"࠭࡜࡝ࡷ࠳࠺࠹࠿ࠧབ"))
	if vciEXHThAPto76QIR2pK: iHmGuDhq4vZoFKzQ7s6ja = iHmGuDhq4vZoFKzQ7s6ja.decode(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨབྷ")).encode(qFRrj7ayBKbOsHGSXz(u"ࠨࡷࡷࡪ࠽࠭མ"))
	else: iHmGuDhq4vZoFKzQ7s6ja = iHmGuDhq4vZoFKzQ7s6ja.encode(Kwl07iYTtDLN3zP(u"ࠩࡸࡸ࡫࠾ࠧཙ")).decode(dEUYJjrhsaPXNo(u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫཚ"))
	return iHmGuDhq4vZoFKzQ7s6ja
def UIf35nZEj1wylmq(header=bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"้ࠫ๎อสࠢส่๊็วห์ะࠫཛ"),default=Gk98CL5nXZEN(u"ࠬ࠭ཛྷ"),UT0FG57uXfeLQcK4Vn=NNmirJKPp5nWjfC(u"ࡆࡢ࡮ࡶࡩ᜔"),source=cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠭ࠧཝ")):
	hfNZTDrYABwyVcJQlqPS48xpHIi7s = eRaEQKo9kIjLpgnvtZGP15Sm8Wy(header,default,type=ZuEAJR1lNHkUf0.INPUT_ALPHANUM)
	hfNZTDrYABwyVcJQlqPS48xpHIi7s = hfNZTDrYABwyVcJQlqPS48xpHIi7s.replace(ta478EuZQJIWhgBnsf6iU(u"ࠧࠡࠢࠪཞ"),ItgK5FqGDz2Rf7mAJkbT(u"ࠨࠢࠪཟ")).replace(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠩࠣࠤࠬའ"),MM564HfnUV0XIR(u"ࠪࠤࠬཡ")).replace(r6juULGQtnExAko38BZ5Y(u"ࠫࠥࠦࠧར"),r6juULGQtnExAko38BZ5Y(u"ࠬࠦࠧལ"))
	if not hfNZTDrYABwyVcJQlqPS48xpHIi7s and not UT0FG57uXfeLQcK4Vn:
		y75wQavkVSLUb2MZf9qo(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ཤ"),CIcPowhneWs5tN3(u"ࠧ࠯ࠢࠣࡏࡪࡿࡢࡰࡣࡵࡨࠥ࡫࡮ࡵࡴࡼࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡀࠠࠡࠢࠥࠫཥ")+hfNZTDrYABwyVcJQlqPS48xpHIi7s+smpniPDOhfwI3H4v7c6TG(u"ࠨࠤࠪས"))
		tehb3k5a2PufGOdBIUw8j(MM564HfnUV0XIR(u"ࠩࠪཧ"),GGCQK6OAtZUXRhvkgJm(u"ࠪࠫཨ"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧཀྵ"),EAw9bg4rT3Bd8tjSkO(u"ࠬะๅࠡว็฾ฬวࠠศๆศำำอไࠨཪ"))
		return bbqAtUz36RPGVTvCkejpJXQB(u"࠭ࠧཫ")
	if hfNZTDrYABwyVcJQlqPS48xpHIi7s not in [tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠧࠨཬ"),tOdiG2HWFRBXg1sUh(u"ࠨࠢࠪ཭")]:
		hfNZTDrYABwyVcJQlqPS48xpHIi7s = hfNZTDrYABwyVcJQlqPS48xpHIi7s.strip(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠩࠣࠫ཮"))
		hfNZTDrYABwyVcJQlqPS48xpHIi7s = UdhlykB6XfC5NZVqORE0IQY(hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	if source!=WbM6qAjrn7fEXGZw(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗࠬ཯") and Y1Yz6bZMLDaGjpxK3fSXm7TurCnHwo(I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠫࡐࡋ࡙ࡃࡑࡄࡖࡉ࠭཰"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ཱࠬ࠭"),[hfNZTDrYABwyVcJQlqPS48xpHIi7s],ta478EuZQJIWhgBnsf6iU(u"ࡇࡣ࡯ࡷࡪ᜕")):
		y75wQavkVSLUb2MZf9qo(tOdiG2HWFRBXg1sUh(u"࠭ࡎࡐࡖࡌࡇࡊི࠭"),Gk98CL5nXZEN(u"ࠧ࠯ࠢࠣࡏࡪࡿࡢࡰࡣࡵࡨࠥ࡫࡮ࡵࡴࡼࠤࡧࡲ࡯ࡤ࡭ࡨࡨ࠿ࠦࠠࠡࠤཱིࠪ")+hfNZTDrYABwyVcJQlqPS48xpHIi7s+NNmirJKPp5nWjfC(u"ࠨࠤུࠪ"))
		tehb3k5a2PufGOdBIUw8j(r6juULGQtnExAko38BZ5Y(u"ཱུࠩࠪ"),QmoEjB3hLIw(u"ࠪࠫྲྀ"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧཷ"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠬอๆหࠢๆฮอะࠠไๆ่อࠥษ่ࠡำๅ้๊ࠥ็ࠡ฻็ห็ฯࠠษลไ่ฬ๋ࠠๅๆๆฬฬืࠠโไฺࠤ࠳࠴้้ࠠำหࠥอไษำ้ห๊าࠠๅษࠣ๎ุ๋อࠡสสืฯิฯศ็๋่ࠣึวࠡๅ็้ฬะࠧླྀ"))
		return dEUYJjrhsaPXNo(u"࠭ࠧཹ")
	y75wQavkVSLUb2MZf9qo(S26SnaqcM9XwK8PVphJDv5(u"ࠧࡏࡑࡗࡍࡈࡋེࠧ"),GGCQK6OAtZUXRhvkgJm(u"ࠨ࠰ࠣࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡧ࡬࡭ࡱࡺࡩࡩࡀཻࠠࠡࠢࠥࠫ")+hfNZTDrYABwyVcJQlqPS48xpHIi7s+QmoEjB3hLIw(u"ོࠩࠥࠫ"))
	return hfNZTDrYABwyVcJQlqPS48xpHIi7s
def nPVJZWtkEb27UQ9AK(M08MPGgsh4n5rKe,TC7fWv2a1gLJGiAtN8={}):
	pAeIhbuLSFw7j49qxtcg8dDrmKO,d6wM5NY2ARK0eqHGpo87Wj,RRt4TH2wLFbY,VaCeSQbgYu5yTqB = M08MPGgsh4n5rKe,{},{},Ox8k6IdtuPaG3NlApQK52oYwM(u"ཽࠪࠫ")
	if QmoEjB3hLIw(u"ࠫࢁ࠭ཾ") in M08MPGgsh4n5rKe: pAeIhbuLSFw7j49qxtcg8dDrmKO,d6wM5NY2ARK0eqHGpo87Wj = NHyOSR4BdqaXfCpK0EU8vroiDJ2T(M08MPGgsh4n5rKe,EAw9bg4rT3Bd8tjSkO(u"ࠬࢂࠧཿ"))
	QWEcMUynwog1KCisf9I3 = list(set(list(TC7fWv2a1gLJGiAtN8.keys())+list(d6wM5NY2ARK0eqHGpo87Wj.keys())))
	for u8u3ZiaBy9SIqnPsAV in QWEcMUynwog1KCisf9I3:
		if u8u3ZiaBy9SIqnPsAV in list(d6wM5NY2ARK0eqHGpo87Wj.keys()): RRt4TH2wLFbY[u8u3ZiaBy9SIqnPsAV] = d6wM5NY2ARK0eqHGpo87Wj[u8u3ZiaBy9SIqnPsAV]
		else: RRt4TH2wLFbY[u8u3ZiaBy9SIqnPsAV] = TC7fWv2a1gLJGiAtN8[u8u3ZiaBy9SIqnPsAV]
	if I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶྀࠪ") not in QWEcMUynwog1KCisf9I3: RRt4TH2wLFbY[ta478EuZQJIWhgBnsf6iU(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷཱྀࠫ")] = FY2qK6eHVBl4D0pEut8IgkTczyG()
	if uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩྂ") not in QWEcMUynwog1KCisf9I3: RRt4TH2wLFbY[WbM6qAjrn7fEXGZw(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪྃ")] = SLMTm6RQ34ic7v5s9rBG(pAeIhbuLSFw7j49qxtcg8dDrmKO,YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠪࡹࡷࡲ྄ࠧ"))
	for u8u3ZiaBy9SIqnPsAV in list(RRt4TH2wLFbY.keys()): VaCeSQbgYu5yTqB += bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠫࠫ࠭྅")+u8u3ZiaBy9SIqnPsAV+qFRrj7ayBKbOsHGSXz(u"ࠬࡃࠧ྆")+RRt4TH2wLFbY[u8u3ZiaBy9SIqnPsAV]
	if VaCeSQbgYu5yTqB: VaCeSQbgYu5yTqB = FeyZbj8tDil0nSHzTwfsUJ9(u"࠭ࡼࠨ྇")+VaCeSQbgYu5yTqB[smpniPDOhfwI3H4v7c6TG(u"࠷ᖠ"):]
	Il5iAWS8vkNBe4Xf = OOA8T7f5Cl9WPgvoItykRc3M(RvKQX7HgZ6faBueLsMjxGtPobTd0,Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠧࡈࡇࡗࠫྈ"),pAeIhbuLSFw7j49qxtcg8dDrmKO,WbM6qAjrn7fEXGZw(u"ࠨࠩྉ"),RRt4TH2wLFbY,CgPbwXm1RilpJUSGHLhy(u"ࠩࠪྊ"),smpniPDOhfwI3H4v7c6TG(u"ࠪࠫྋ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡕࡔࡄࡇ࡙ࡥࡍ࠴ࡗ࠻࠱࠶ࡹࡴࠨྌ"),wx18CTJPZ5(u"ࡈࡤࡰࡸ࡫᜖"),wx18CTJPZ5(u"ࡈࡤࡰࡸ࡫᜖"))
	TcPFsujHEQG3vBwCt = Il5iAWS8vkNBe4Xf.content
	if FeyZbj8tDil0nSHzTwfsUJ9(u"࡙ࠬࡔࡓࡇࡄࡑ࠲ࡏࡎࡇࠩྍ") not in TcPFsujHEQG3vBwCt: return [SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠭࠭࠲ࠩྎ")],[pAeIhbuLSFw7j49qxtcg8dDrmKO+VaCeSQbgYu5yTqB]
	if FeyZbj8tDil0nSHzTwfsUJ9(u"ࠧࡕ࡛ࡓࡉࡂࡇࡕࡅࡋࡒࠫྏ") in TcPFsujHEQG3vBwCt: return [CIcPowhneWs5tN3(u"ࠨ࠯࠴ࠫྐ")],[pAeIhbuLSFw7j49qxtcg8dDrmKO+VaCeSQbgYu5yTqB]
	if WbM6qAjrn7fEXGZw(u"ࠩࡗ࡝ࡕࡋ࠽ࡗࡋࡇࡉࡔ࠭ྑ") in TcPFsujHEQG3vBwCt: return [FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠪ࠱࠶࠭ྒ")],[pAeIhbuLSFw7j49qxtcg8dDrmKO+VaCeSQbgYu5yTqB]
	da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy,xFXpz4TRVPWoJGvSldsZOywaM9,ciozqpM14TtGa = [],[],[],[]
	Zvm7qOC8GUAFB = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(CIcPowhneWs5tN3(u"ࠫࠨࡋࡘࡕ࠯࡛࠱ࡘ࡚ࡒࡆࡃࡐ࠱ࡎࡔࡆ࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱ࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯ࠬྒྷ"),TcPFsujHEQG3vBwCt+CgPbwXm1RilpJUSGHLhy(u"ࠬࡢ࡮ࠨྔ"),E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not Zvm7qOC8GUAFB: return [NNmirJKPp5nWjfC(u"࠭࠭࠲ࠩྕ")],[pAeIhbuLSFw7j49qxtcg8dDrmKO+VaCeSQbgYu5yTqB]
	for XpCOM0t9ZcL8WvBE2xDb3yeonKhQ,Hzywg9LuXC0reKT3D8h6WI in Zvm7qOC8GUAFB:
		IErXTqA1ywmYkDtRJW24Z,rqY7pLRMaPTsxV3eCtlIo1A4,LjG8y1rb9AgJF2I3i64ZDtCXMa7n = {},-NxsKJnLFEZ9OHXf1h(u"࠱ᖡ"),-NxsKJnLFEZ9OHXf1h(u"࠱ᖡ")
		eCUd5uAY8EpM72ylvORn = NNmirJKPp5nWjfC(u"ࠧࠨྖ")
		xxNRKDfAlti = XpCOM0t9ZcL8WvBE2xDb3yeonKhQ.split(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠨ࠮ࠪྗ"))
		for DUacmNFpbwv13uylo in xxNRKDfAlti:
			if bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠩࡀࠫ྘") in DUacmNFpbwv13uylo:
				u8u3ZiaBy9SIqnPsAV,A9QIaSVqt0g4b = DUacmNFpbwv13uylo.split(wx18CTJPZ5(u"ࠪࡁࠬྙ"),MM564HfnUV0XIR(u"࠲ᖢ"))
				IErXTqA1ywmYkDtRJW24Z[u8u3ZiaBy9SIqnPsAV.lower()] = A9QIaSVqt0g4b
		if cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠫࡦࡼࡥࡳࡣࡪࡩ࠲ࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨࠨྚ") in XpCOM0t9ZcL8WvBE2xDb3yeonKhQ.lower():
			rqY7pLRMaPTsxV3eCtlIo1A4 = int(IErXTqA1ywmYkDtRJW24Z[EAw9bg4rT3Bd8tjSkO(u"ࠬࡧࡶࡦࡴࡤ࡫ࡪ࠳ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩྛ")])//Gk98CL5nXZEN(u"࠳࠳࠶࠹ᖣ")
			eCUd5uAY8EpM72ylvORn += str(rqY7pLRMaPTsxV3eCtlIo1A4)+zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠭࡫ࡣࡲࡶࠤࠥ࠭ྜ")
		elif uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠧࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪྜྷ") in XpCOM0t9ZcL8WvBE2xDb3yeonKhQ.lower():
			rqY7pLRMaPTsxV3eCtlIo1A4 = int(IErXTqA1ywmYkDtRJW24Z[I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠨࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫྞ")])//uAl3gHavMJZL4xmNe62nDiBoQ(u"࠴࠴࠷࠺ᖤ")
			eCUd5uAY8EpM72ylvORn += str(rqY7pLRMaPTsxV3eCtlIo1A4)+QmoEjB3hLIw(u"ࠩ࡮ࡦࡵࡹࠠࠡࠩྟ")
		if dEUYJjrhsaPXNo(u"ࠪࡶࡪࡹ࡯࡭ࡷࡷ࡭ࡴࡴࠧྠ") in XpCOM0t9ZcL8WvBE2xDb3yeonKhQ.lower():
			LjG8y1rb9AgJF2I3i64ZDtCXMa7n = int(IErXTqA1ywmYkDtRJW24Z[NNmirJKPp5nWjfC(u"ࠫࡷ࡫ࡳࡰ࡮ࡸࡸ࡮ࡵ࡮ࠨྡ")].split(qFRrj7ayBKbOsHGSXz(u"ࠬࡾࠧྡྷ"))[uAl3gHavMJZL4xmNe62nDiBoQ(u"࠵ᖥ")])
			eCUd5uAY8EpM72ylvORn += str(LjG8y1rb9AgJF2I3i64ZDtCXMa7n)+NNmirJKPp5nWjfC(u"࠭ࠠࠡࠩྣ")
		eCUd5uAY8EpM72ylvORn = eCUd5uAY8EpM72ylvORn.strip(CgPbwXm1RilpJUSGHLhy(u"ࠧࠡࠢࠪྤ"))
		if not eCUd5uAY8EpM72ylvORn: eCUd5uAY8EpM72ylvORn = wx18CTJPZ5(u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩྥ")
		if not Hzywg9LuXC0reKT3D8h6WI.startswith(ItgK5FqGDz2Rf7mAJkbT(u"ࠩ࡫ࡸࡹࡶࠧྦ")):
			if Hzywg9LuXC0reKT3D8h6WI.startswith(I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠪ࠳࠴࠭ྦྷ")): Hzywg9LuXC0reKT3D8h6WI = pAeIhbuLSFw7j49qxtcg8dDrmKO.split(ta478EuZQJIWhgBnsf6iU(u"ࠫ࠿࠭ྨ"),EAw9bg4rT3Bd8tjSkO(u"࠶ᖦ"))[EAw9bg4rT3Bd8tjSkO(u"࠶ᖧ")]+bbqAtUz36RPGVTvCkejpJXQB(u"ࠬࡀࠧྩ")+Hzywg9LuXC0reKT3D8h6WI
			elif Hzywg9LuXC0reKT3D8h6WI.startswith(wx18CTJPZ5(u"࠭࠯ࠨྪ")): Hzywg9LuXC0reKT3D8h6WI = SLMTm6RQ34ic7v5s9rBG(pAeIhbuLSFw7j49qxtcg8dDrmKO,SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠧࡶࡴ࡯ࠫྫ"))+Hzywg9LuXC0reKT3D8h6WI
			else: Hzywg9LuXC0reKT3D8h6WI = pAeIhbuLSFw7j49qxtcg8dDrmKO.rsplit(EAw9bg4rT3Bd8tjSkO(u"ࠨ࠱ࠪྫྷ"),tOdiG2HWFRBXg1sUh(u"࠱ᖨ"))[r6juULGQtnExAko38BZ5Y(u"࠱ᖩ")]+FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠩ࠲ࠫྭ")+Hzywg9LuXC0reKT3D8h6WI
		if uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠪࡴࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥ࠮ࡷࡵ࡭ࠬྮ") in list(IErXTqA1ywmYkDtRJW24Z.keys()):
			VktWBN6gn8zSUpesvfCyia2Ajm = IErXTqA1ywmYkDtRJW24Z[bbqAtUz36RPGVTvCkejpJXQB(u"ࠫࡵࡸ࡯ࡨࡴࡨࡷࡸ࡯ࡶࡦ࠯ࡸࡶ࡮࠭ྯ")]
			VktWBN6gn8zSUpesvfCyia2Ajm = VktWBN6gn8zSUpesvfCyia2Ajm.replace(QmoEjB3hLIw(u"ࠬࠨࠧྰ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠭ࠧྱ")).replace(FeyZbj8tDil0nSHzTwfsUJ9(u"ࠢࠨࠤྲ"),QmoEjB3hLIw(u"ࠨࠩླ")).split(FeyZbj8tDil0nSHzTwfsUJ9(u"ࠩࠦࠫྴ"),ta478EuZQJIWhgBnsf6iU(u"࠳ᖪ"))[YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠳ᖫ")]
			Pu43YtENBjiyp2KoFQWqHTw6XOlk = SU82u7LfcMslH3e0Bzihn6x(VktWBN6gn8zSUpesvfCyia2Ajm)
			if Pu43YtENBjiyp2KoFQWqHTw6XOlk: neZQycYAFqxLzkPhEWvM = eCUd5uAY8EpM72ylvORn+FeyZbj8tDil0nSHzTwfsUJ9(u"ࠪࠤࠥ࠭ྵ")+Pu43YtENBjiyp2KoFQWqHTw6XOlk
			else: neZQycYAFqxLzkPhEWvM = eCUd5uAY8EpM72ylvORn
			neZQycYAFqxLzkPhEWvM = neZQycYAFqxLzkPhEWvM+tOdiG2HWFRBXg1sUh(u"ࠫࠥࠦࡐࡳࡱࡪࡶࡪࡹࡳࡪࡸࡨࠫྶ")
			neZQycYAFqxLzkPhEWvM = neZQycYAFqxLzkPhEWvM+Gk98CL5nXZEN(u"ࠬࠦࠠࠨྷ")+SLMTm6RQ34ic7v5s9rBG(VktWBN6gn8zSUpesvfCyia2Ajm,Gk98CL5nXZEN(u"࠭࡮ࡢ࡯ࡨࠫྸ"))
			da6IAnqQ7oV2Hx13F5gbBT4.append(neZQycYAFqxLzkPhEWvM)
			jVMHRouKgQFAESmd7B8ObTYy.append(VktWBN6gn8zSUpesvfCyia2Ajm)
			xFXpz4TRVPWoJGvSldsZOywaM9.append(LjG8y1rb9AgJF2I3i64ZDtCXMa7n)
			ciozqpM14TtGa.append(rqY7pLRMaPTsxV3eCtlIo1A4)
		Hzywg9LuXC0reKT3D8h6WI = Hzywg9LuXC0reKT3D8h6WI.split(ta478EuZQJIWhgBnsf6iU(u"ࠧࠤࠩྐྵ"),CgPbwXm1RilpJUSGHLhy(u"࠵ᖬ"))[FeyZbj8tDil0nSHzTwfsUJ9(u"࠵ᖭ")]
		Pu43YtENBjiyp2KoFQWqHTw6XOlk = SU82u7LfcMslH3e0Bzihn6x(Hzywg9LuXC0reKT3D8h6WI)
		if Pu43YtENBjiyp2KoFQWqHTw6XOlk: eCUd5uAY8EpM72ylvORn = eCUd5uAY8EpM72ylvORn+wx18CTJPZ5(u"ࠨࠢࠣࠫྺ")+Pu43YtENBjiyp2KoFQWqHTw6XOlk
		eCUd5uAY8EpM72ylvORn = eCUd5uAY8EpM72ylvORn+GGCQK6OAtZUXRhvkgJm(u"ࠩࠣࠤࠬྻ")+SLMTm6RQ34ic7v5s9rBG(Hzywg9LuXC0reKT3D8h6WI,GGCQK6OAtZUXRhvkgJm(u"ࠪࡲࡦࡳࡥࠨྼ"))
		da6IAnqQ7oV2Hx13F5gbBT4.append(eCUd5uAY8EpM72ylvORn)
		jVMHRouKgQFAESmd7B8ObTYy.append(Hzywg9LuXC0reKT3D8h6WI)
		xFXpz4TRVPWoJGvSldsZOywaM9.append(LjG8y1rb9AgJF2I3i64ZDtCXMa7n)
		ciozqpM14TtGa.append(rqY7pLRMaPTsxV3eCtlIo1A4)
	Jvz4r1LbjumknXHpeRxDVP5W2 = list(zip(da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy,xFXpz4TRVPWoJGvSldsZOywaM9,ciozqpM14TtGa))
	Jvz4r1LbjumknXHpeRxDVP5W2 = sorted(Jvz4r1LbjumknXHpeRxDVP5W2, reverse=tOdiG2HWFRBXg1sUh(u"ࡗࡶࡺ࡫᜗"), key=lambda key: key[Ox8k6IdtuPaG3NlApQK52oYwM(u"࠹ᖮ")])
	da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy,xFXpz4TRVPWoJGvSldsZOywaM9,ciozqpM14TtGa = list(zip(*Jvz4r1LbjumknXHpeRxDVP5W2))
	da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = list(da6IAnqQ7oV2Hx13F5gbBT4),list(jVMHRouKgQFAESmd7B8ObTYy)
	FQLIlWJODoV26NSpzgjb3Yu = []
	for Hzywg9LuXC0reKT3D8h6WI in jVMHRouKgQFAESmd7B8ObTYy: FQLIlWJODoV26NSpzgjb3Yu.append(Hzywg9LuXC0reKT3D8h6WI+VaCeSQbgYu5yTqB)
	return da6IAnqQ7oV2Hx13F5gbBT4,FQLIlWJODoV26NSpzgjb3Yu
def RePNIXDAy4GifxQqKg(IIOrTgqjuxv,lbzUsDZE3MntmwucgjKa=zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠫࠬ྽")):
	if not lbzUsDZE3MntmwucgjKa: lbzUsDZE3MntmwucgjKa = y4Be6ljV9o7DNAdFO0aQtWpY[ta478EuZQJIWhgBnsf6iU(u"࠰ᖯ")]
	if IIOrTgqjuxv.replace(Gk98CL5nXZEN(u"ࠬ࠴ࠧ྾"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠭ࠧ྿")).isdigit(): return [IIOrTgqjuxv]
	from struct import pack as Y0wq6zpFM1m7kPbrDCRcJ,unpack_from as Z1yJeT5qhz7PwYpFRXlf
	from socket import socket as UnVKvhfHwd6pYx37Wk,AF_INET as c7kgPIzjmT,SOCK_DGRAM as ZDgJb6ASKeRtfHz
	try:
		PFaNWIpsOxTAVj10b9BGEhck8Zde = Y0wq6zpFM1m7kPbrDCRcJ(CgPbwXm1RilpJUSGHLhy(u"ࠢ࠿ࡊࠥ࿀"), YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠲࠴࠳࠸࠾ᖰ"))
		PFaNWIpsOxTAVj10b9BGEhck8Zde += Y0wq6zpFM1m7kPbrDCRcJ(QmoEjB3hLIw(u"ࠣࡀࡋࠦ࿁"), bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠴࠸࠺ᖱ"))
		PFaNWIpsOxTAVj10b9BGEhck8Zde += Y0wq6zpFM1m7kPbrDCRcJ(WbM6qAjrn7fEXGZw(u"ࠤࡁࡌࠧ࿂"), r6juULGQtnExAko38BZ5Y(u"࠴ᖲ"))
		PFaNWIpsOxTAVj10b9BGEhck8Zde += Y0wq6zpFM1m7kPbrDCRcJ(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠥࡂࡍࠨ࿃"), CgPbwXm1RilpJUSGHLhy(u"࠴ᖳ"))
		PFaNWIpsOxTAVj10b9BGEhck8Zde += Y0wq6zpFM1m7kPbrDCRcJ(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠦࡃࡎࠢ࿄"), CgPbwXm1RilpJUSGHLhy(u"࠵ᖴ"))
		PFaNWIpsOxTAVj10b9BGEhck8Zde += Y0wq6zpFM1m7kPbrDCRcJ(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠧࡄࡈࠣ࿅"), MM564HfnUV0XIR(u"࠶ᖵ"))
		if wvkR1es6d0SrjxKt5FZTMUWz7a: pEy7cUNvFTfn6Z5A3HsqrPMXeR = IIOrTgqjuxv.split(CgPbwXm1RilpJUSGHLhy(u"࠭࠮ࠨ࿆"))
		else: pEy7cUNvFTfn6Z5A3HsqrPMXeR = IIOrTgqjuxv.decode(I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠧࡶࡶࡩ࠼ࠬ࿇")).split(CgPbwXm1RilpJUSGHLhy(u"ࠨ࠰ࠪ࿈"))
		for SiK8NQdHpysqYOrI in pEy7cUNvFTfn6Z5A3HsqrPMXeR:
			mrLKVlY9qv = SiK8NQdHpysqYOrI.encode(dEUYJjrhsaPXNo(u"ࠩࡸࡸ࡫࠾ࠧ࿉"))
			PFaNWIpsOxTAVj10b9BGEhck8Zde += Y0wq6zpFM1m7kPbrDCRcJ(I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠥࡆࠧ࿊"), len(SiK8NQdHpysqYOrI))
			for YfbBH7rZXVocOslxLFNv in SiK8NQdHpysqYOrI:
				PFaNWIpsOxTAVj10b9BGEhck8Zde += Y0wq6zpFM1m7kPbrDCRcJ(NxsKJnLFEZ9OHXf1h(u"ࠦࡨࠨ࿋"), YfbBH7rZXVocOslxLFNv.encode(qFRrj7ayBKbOsHGSXz(u"ࠬࡻࡴࡧ࠺ࠪ࿌")))
		PFaNWIpsOxTAVj10b9BGEhck8Zde += Y0wq6zpFM1m7kPbrDCRcJ(CgPbwXm1RilpJUSGHLhy(u"ࠨࡂࠣ࿍"), FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠰ᖶ"))
		PFaNWIpsOxTAVj10b9BGEhck8Zde += Y0wq6zpFM1m7kPbrDCRcJ(smpniPDOhfwI3H4v7c6TG(u"ࠢ࠿ࡊࠥ࿎"), tOdiG2HWFRBXg1sUh(u"࠲ᖷ"))
		PFaNWIpsOxTAVj10b9BGEhck8Zde += Y0wq6zpFM1m7kPbrDCRcJ(dEUYJjrhsaPXNo(u"ࠣࡀࡋࠦ࿏"), ta478EuZQJIWhgBnsf6iU(u"࠳ᖸ"))
		tgBAOHox9r8NFYbfXwzUcpueJiMD = UnVKvhfHwd6pYx37Wk(c7kgPIzjmT,ZDgJb6ASKeRtfHz)
		tgBAOHox9r8NFYbfXwzUcpueJiMD.sendto(bytes(PFaNWIpsOxTAVj10b9BGEhck8Zde), (lbzUsDZE3MntmwucgjKa, Kwl07iYTtDLN3zP(u"࠸࠷ᖹ")))
		tgBAOHox9r8NFYbfXwzUcpueJiMD.settimeout(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠺ᖺ"))
		YReuIJ67GDs8NwEiZOAh4xPMb, WWoOjpH0n43csCkXNbwLJV8i = tgBAOHox9r8NFYbfXwzUcpueJiMD.recvfrom(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠶࠶࠲࠵ᖻ"))
		tgBAOHox9r8NFYbfXwzUcpueJiMD.close()
		VY9T4ziklrhvcd3ws5fEJoFUupDxP = Z1yJeT5qhz7PwYpFRXlf(dEUYJjrhsaPXNo(u"ࠤࡁࡌࡍࡎࡈࡉࡊࠥ࿐"), YReuIJ67GDs8NwEiZOAh4xPMb, Kwl07iYTtDLN3zP(u"࠶ᖼ"))
		IS0G7uD8MxpFCVBU16KAXq5ERgQ = VY9T4ziklrhvcd3ws5fEJoFUupDxP[Ox8k6IdtuPaG3NlApQK52oYwM(u"࠳ᖽ")]
		uslAYGE6TS1Kk7ca0OBCprHi = len(IIOrTgqjuxv)+wx18CTJPZ5(u"࠲࠺ᖾ")
		gqf9tEKLQN2J6bAUr0ivHIOSD = []
		for _U9gKSbHA8YwCEzMldIvVZuJ6G in range(IS0G7uD8MxpFCVBU16KAXq5ERgQ):
			dPD610VFWnxroaBkNJvhgwYeG5 = uslAYGE6TS1Kk7ca0OBCprHi
			zz6eu7JFfr3Y0PKShlZMx = CgPbwXm1RilpJUSGHLhy(u"࠳ᖿ")
			OQnlqwgW8J43YRI = ta478EuZQJIWhgBnsf6iU(u"ࡊࡦࡲࡳࡦ᜘")
			while uAl3gHavMJZL4xmNe62nDiBoQ(u"࡙ࡸࡵࡦ᜙"):
				YfbBH7rZXVocOslxLFNv = Z1yJeT5qhz7PwYpFRXlf(FeyZbj8tDil0nSHzTwfsUJ9(u"ࠥࡂࡇࠨ࿑"), YReuIJ67GDs8NwEiZOAh4xPMb, dPD610VFWnxroaBkNJvhgwYeG5)[S26SnaqcM9XwK8PVphJDv5(u"࠳ᗀ")]
				if YfbBH7rZXVocOslxLFNv == tOdiG2HWFRBXg1sUh(u"࠴ᗁ"):
					dPD610VFWnxroaBkNJvhgwYeG5 += dEUYJjrhsaPXNo(u"࠶ᗂ")
					break
				if YfbBH7rZXVocOslxLFNv >= FeyZbj8tDil0nSHzTwfsUJ9(u"࠷࠹࠳ᗃ"):
					AQVcXaBNJEIys3TKCzFlPni5tDj2L7 = Z1yJeT5qhz7PwYpFRXlf(Gk98CL5nXZEN(u"ࠦࡃࡈࠢ࿒"), YReuIJ67GDs8NwEiZOAh4xPMb, dPD610VFWnxroaBkNJvhgwYeG5 + qFRrj7ayBKbOsHGSXz(u"࠱ᗄ"))[NNmirJKPp5nWjfC(u"࠱ᗅ")]
					dPD610VFWnxroaBkNJvhgwYeG5 = ((YfbBH7rZXVocOslxLFNv << bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠻ᗇ")) + AQVcXaBNJEIys3TKCzFlPni5tDj2L7 - 0xc000) - NNmirJKPp5nWjfC(u"࠳ᗆ")
					OQnlqwgW8J43YRI = uAl3gHavMJZL4xmNe62nDiBoQ(u"࡚ࡲࡶࡧ᜚")
				dPD610VFWnxroaBkNJvhgwYeG5 += FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠵ᗈ")
				if OQnlqwgW8J43YRI == S26SnaqcM9XwK8PVphJDv5(u"ࡆࡢ࡮ࡶࡩ᜛"): zz6eu7JFfr3Y0PKShlZMx += NNmirJKPp5nWjfC(u"࠶ᗉ")
			if OQnlqwgW8J43YRI == dEUYJjrhsaPXNo(u"ࡕࡴࡸࡩ᜜"): zz6eu7JFfr3Y0PKShlZMx += bbqAtUz36RPGVTvCkejpJXQB(u"࠷ᗊ")
			uslAYGE6TS1Kk7ca0OBCprHi = uslAYGE6TS1Kk7ca0OBCprHi + zz6eu7JFfr3Y0PKShlZMx
			POlmuJMrHzaSN = Z1yJeT5qhz7PwYpFRXlf(Gk98CL5nXZEN(u"ࠧࡄࡈࡉࡋࡋࠦ࿓"), YReuIJ67GDs8NwEiZOAh4xPMb, uslAYGE6TS1Kk7ca0OBCprHi)
			uslAYGE6TS1Kk7ca0OBCprHi = uslAYGE6TS1Kk7ca0OBCprHi + YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠱࠱ᗋ")
			CQexTUup6FhjrMfYcB4v = POlmuJMrHzaSN[tOdiG2HWFRBXg1sUh(u"࠱ᗌ")]
			xxQcNhJP4oY0RKCW96vetO = POlmuJMrHzaSN[S26SnaqcM9XwK8PVphJDv5(u"࠵ᗍ")]
			if CQexTUup6FhjrMfYcB4v == FeyZbj8tDil0nSHzTwfsUJ9(u"࠴ᗎ"):
				QZkCOq8uAK5G4R1wTDySn3dtz = Z1yJeT5qhz7PwYpFRXlf(smpniPDOhfwI3H4v7c6TG(u"ࠨ࠾ࠣ࿔")+tOdiG2HWFRBXg1sUh(u"ࠢࡃࠤ࿕")*xxQcNhJP4oY0RKCW96vetO, YReuIJ67GDs8NwEiZOAh4xPMb, uslAYGE6TS1Kk7ca0OBCprHi)
				ip = r6juULGQtnExAko38BZ5Y(u"ࠨࠩ࿖")
				for YfbBH7rZXVocOslxLFNv in QZkCOq8uAK5G4R1wTDySn3dtz: ip += str(YfbBH7rZXVocOslxLFNv) + dEUYJjrhsaPXNo(u"ࠩ࠱ࠫ࿗")
				ip = ip[QmoEjB3hLIw(u"࠵ᗐ"):-smpniPDOhfwI3H4v7c6TG(u"࠵ᗏ")]
				gqf9tEKLQN2J6bAUr0ivHIOSD.append(ip)
			if CQexTUup6FhjrMfYcB4v in [YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠲ᗓ"),ta478EuZQJIWhgBnsf6iU(u"࠴ᗔ"),wx18CTJPZ5(u"࠸ᗕ"),tOdiG2HWFRBXg1sUh(u"࠺ᗖ"),NNmirJKPp5nWjfC(u"࠷࠵ᗑ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠲࠹ᗒ")]: uslAYGE6TS1Kk7ca0OBCprHi = uslAYGE6TS1Kk7ca0OBCprHi + xxQcNhJP4oY0RKCW96vetO
	except: gqf9tEKLQN2J6bAUr0ivHIOSD = []
	if not gqf9tEKLQN2J6bAUr0ivHIOSD: y75wQavkVSLUb2MZf9qo(bbqAtUz36RPGVTvCkejpJXQB(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ࿘"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+QmoEjB3hLIw(u"ࠫࠥࠦࠠࡅࡐࡖࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡊࡲࡷࡹࡀࠠ࡜ࠢࠪ࿙")+IIOrTgqjuxv+SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠬࠦ࡝ࠨ࿚"))
	return gqf9tEKLQN2J6bAUr0ivHIOSD
def Y1Yz6bZMLDaGjpxK3fSXm7TurCnHwo(r1NChsk39OMvT82YemDQnl5,pAeIhbuLSFw7j49qxtcg8dDrmKO,VnK1wPrcHoN8ex2Bl0pLS,showDialogs=qFRrj7ayBKbOsHGSXz(u"ࡖࡵࡹࡪ᜝")):
	if VnK1wPrcHoN8ex2Bl0pLS:
		JXNMS45e0iub = [MM564HfnUV0XIR(u"࠭ใษษิࠫ࿛"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠧษษ็฾ࠬ࿜"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࠨࡣࡧࡹࡱࡺࠧ࿝"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࠩࡻࡼࠬ࿞"),smpniPDOhfwI3H4v7c6TG(u"ࠪࡷࡪࡾࠧ࿟")]
		if r1NChsk39OMvT82YemDQnl5!=YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠫࡇࡕࡋࡓࡃࠪ࿠"):
			JXNMS45e0iub += [tOdiG2HWFRBXg1sUh(u"ࠬࡸ࠺ࠨ࿡"),WbM6qAjrn7fEXGZw(u"࠭ࡲ࠮ࠩ࿢"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠧ࠮࡯ࡤࠫ࿣")]
			JXNMS45e0iub += [bbqAtUz36RPGVTvCkejpJXQB(u"ࠨ࠼ࡵࠫ࿤"),NxsKJnLFEZ9OHXf1h(u"ࠩ࠰ࡶࠬ࿥"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠪࡱࡦ࠳ࠧ࿦")]
		for i6SOtrU0NZmTexChcaVwvI in VnK1wPrcHoN8ex2Bl0pLS:
			if r6juULGQtnExAko38BZ5Y(u"ࠫ࡬࡫ࡴ࠯ࡲ࡫ࡴࡄ࠭࿧") in i6SOtrU0NZmTexChcaVwvI: continue
			if Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠬำไใหࠪ࿨") in i6SOtrU0NZmTexChcaVwvI: continue
			i6SOtrU0NZmTexChcaVwvI = i6SOtrU0NZmTexChcaVwvI.lower()
			if vciEXHThAPto76QIR2pK: i6SOtrU0NZmTexChcaVwvI = i6SOtrU0NZmTexChcaVwvI.decode(MM564HfnUV0XIR(u"࠭ࡵࡵࡨ࠻ࠫ࿩")).encode(bbqAtUz36RPGVTvCkejpJXQB(u"ࠧࡶࡶࡩ࠼ࠬ࿪"))
			i6SOtrU0NZmTexChcaVwvI = i6SOtrU0NZmTexChcaVwvI.replace(tOdiG2HWFRBXg1sUh(u"ࠨ࠼ࠪ࿫"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠩࠪ࿬"))
			a6aVq8jKRcCQshE04JuUWlpvDkXrYd = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(tOdiG2HWFRBXg1sUh(u"ࠪࠬ࠶ࡡ࠵࠮࠻ࡠ࠯ࢁ࠸࡛࠱࠯࠶ࡡ࠰࠯ࠧ࿭"),i6SOtrU0NZmTexChcaVwvI,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			T8Xwm1FxSEDMq2goz3sfUPcYk = I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࡉࡥࡱࡹࡥ᜞")
			for c0ntPAZxkaz9XifE in a6aVq8jKRcCQshE04JuUWlpvDkXrYd:
				if len(c0ntPAZxkaz9XifE)==wx18CTJPZ5(u"࠷ᗗ"):
					T8Xwm1FxSEDMq2goz3sfUPcYk = YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࡘࡷࡻࡥᜟ")
					break
			if tOdiG2HWFRBXg1sUh(u"ࠫࡳࡵࡴࠡࡴࡤࡸࡪࡪࠧ࿮") in i6SOtrU0NZmTexChcaVwvI: continue
			elif ItgK5FqGDz2Rf7mAJkbT(u"ࠬࡻ࡮ࡳࡣࡷࡩࡩ࠭࿯") in i6SOtrU0NZmTexChcaVwvI: continue
			elif zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ฺ๋࠭ำฺ้ࠣ์แࠨ࿰") in i6SOtrU0NZmTexChcaVwvI: continue
			elif hPfgMmZC19lRiKwpN(Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠧࡃࡖࡈࡼࡕ࡜࠱࠺ࡕࡕ࡚ࡓ࡛ࡕ࡭ࡘࡇ࡚ࡊ࡜ࡅ࡙ࠩ࿱")): continue
			elif i6SOtrU0NZmTexChcaVwvI in [tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠨࡴࠪ࿲")] or T8Xwm1FxSEDMq2goz3sfUPcYk or any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in i6SOtrU0NZmTexChcaVwvI for hht0cpXxWw2OzFS1jnUGebkJLBd85 in JXNMS45e0iub):
				y75wQavkVSLUb2MZf9qo(ItgK5FqGDz2Rf7mAJkbT(u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ࿳"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠪࠤࠥࠦࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡢࡦࡸࡰࡹࡹࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ࿴")+pAeIhbuLSFw7j49qxtcg8dDrmKO+YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠫࠥࡣࠧ࿵"))
				if showDialogs: xa60ce2znAlyL5Z8ESXhO(ItgK5FqGDz2Rf7mAJkbT(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࿶"),GGCQK6OAtZUXRhvkgJm(u"࠭วๅใํำ๏๎ࠠๅๆๆฬฬืࠠโไฺࠤํษๆศ่๊ࠢ฾ะ็ࠨ࿷"))
				return ItgK5FqGDz2Rf7mAJkbT(u"࡙ࡸࡵࡦᜠ")
	return tOdiG2HWFRBXg1sUh(u"ࡌࡡ࡭ࡵࡨᜡ")
def tehb3k5a2PufGOdBIUw8j(*aargs,**kkwargs):
	if aargs:
		direction = aargs[FeyZbj8tDil0nSHzTwfsUJ9(u"࠶ᗘ")]
		RRX4eq8OrYakug = aargs[Gk98CL5nXZEN(u"࠱ᗙ")]
		if not direction: direction = NxsKJnLFEZ9OHXf1h(u"ࠧࡤࡧࡱࡸࡪࡸࠧ࿸")
		if not RRX4eq8OrYakug: RRX4eq8OrYakug = CgPbwXm1RilpJUSGHLhy(u"ࠨษึฮ๊ืวาࠩ࿹")
		x8K9qLvDznQN23fwG = aargs[CgPbwXm1RilpJUSGHLhy(u"࠳ᗚ")]
		hfNZTDrYABwyVcJQlqPS48xpHIi7s = tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠩ࡟ࡲࠬ࿺").join(aargs[r6juULGQtnExAko38BZ5Y(u"࠵ᗛ"):])
	else: direction,RRX4eq8OrYakug,x8K9qLvDznQN23fwG,hfNZTDrYABwyVcJQlqPS48xpHIi7s = GGCQK6OAtZUXRhvkgJm(u"ࠪࠫ࿻"),Gk98CL5nXZEN(u"ࠫࡔࡑࠧ࿼"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠬ࠭࿽"),QmoEjB3hLIw(u"࠭ࠧ࿾")
	m5NUYqBzGynIOeAg8(direction,tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠧࠨ࿿"),RRX4eq8OrYakug,MM564HfnUV0XIR(u"ࠨࠩက"),x8K9qLvDznQN23fwG,hfNZTDrYABwyVcJQlqPS48xpHIi7s,**kkwargs)
	return
def eINt5FlUT0oO(*aargs,**kkwargs):
	direction = aargs[I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠳ᗜ")]
	SkdZjBUlbQVDNr1egTa0XhxOvPs = aargs[NNmirJKPp5nWjfC(u"࠵ᗝ")]
	uwOxdUIQLtEsoMPh4l = aargs[ta478EuZQJIWhgBnsf6iU(u"࠷ᗞ")]
	if uwOxdUIQLtEsoMPh4l or SkdZjBUlbQVDNr1egTa0XhxOvPs: NNpduC8EfW3gH016GIT = GGCQK6OAtZUXRhvkgJm(u"ࡔࡳࡷࡨᜢ")
	else: NNpduC8EfW3gH016GIT = tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࡇࡣ࡯ࡷࡪᜣ")
	x8K9qLvDznQN23fwG = aargs[tOdiG2HWFRBXg1sUh(u"࠹ᗟ")]
	hfNZTDrYABwyVcJQlqPS48xpHIi7s = aargs[r6juULGQtnExAko38BZ5Y(u"࠴ᗠ")]
	if not direction: direction = CIcPowhneWs5tN3(u"ࠩࡦࡩࡳࡺࡥࡳࠩခ")
	if not SkdZjBUlbQVDNr1egTa0XhxOvPs: SkdZjBUlbQVDNr1egTa0XhxOvPs = r6juULGQtnExAko38BZ5Y(u"ࠪ็้อࠠࠡࡐࡲࠫဂ")
	if not uwOxdUIQLtEsoMPh4l: uwOxdUIQLtEsoMPh4l = FeyZbj8tDil0nSHzTwfsUJ9(u"๋ࠫ฿ๅࠡࠢ࡜ࡩࡸ࠭ဃ")
	if len(aargs)>=ta478EuZQJIWhgBnsf6iU(u"࠸ᗢ"): hfNZTDrYABwyVcJQlqPS48xpHIi7s += tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠬࡢ࡮ࠨင")+aargs[tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠶ᗡ")]
	if len(aargs)>=tOdiG2HWFRBXg1sUh(u"࠺ᗣ"): hfNZTDrYABwyVcJQlqPS48xpHIi7s += ta478EuZQJIWhgBnsf6iU(u"࠭࡜࡯ࠩစ")+aargs[qFRrj7ayBKbOsHGSXz(u"࠺ᗤ")]
	JJ94bQazqrY1wS = m5NUYqBzGynIOeAg8(direction,SkdZjBUlbQVDNr1egTa0XhxOvPs,r6juULGQtnExAko38BZ5Y(u"ࠧࠨဆ"),uwOxdUIQLtEsoMPh4l,x8K9qLvDznQN23fwG,hfNZTDrYABwyVcJQlqPS48xpHIi7s,**kkwargs)
	if JJ94bQazqrY1wS==-EAw9bg4rT3Bd8tjSkO(u"࠶ᗥ") and NNpduC8EfW3gH016GIT: JJ94bQazqrY1wS = -EAw9bg4rT3Bd8tjSkO(u"࠶ᗥ")
	elif JJ94bQazqrY1wS==-YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠷ᗦ") and not NNpduC8EfW3gH016GIT: JJ94bQazqrY1wS = CgPbwXm1RilpJUSGHLhy(u"ࡈࡤࡰࡸ࡫ᜤ")
	elif JJ94bQazqrY1wS==CgPbwXm1RilpJUSGHLhy(u"࠰ᗧ"): JJ94bQazqrY1wS = QmoEjB3hLIw(u"ࡉࡥࡱࡹࡥᜥ")
	elif JJ94bQazqrY1wS==CIcPowhneWs5tN3(u"࠳ᗨ"): JJ94bQazqrY1wS = smpniPDOhfwI3H4v7c6TG(u"ࡘࡷࡻࡥᜦ")
	return JJ94bQazqrY1wS
def pYRLgOuVTAUM4wKJchdbkzfBql(*aargs,**kkwargs):
	return ZuEAJR1lNHkUf0.Dialog().select(*aargs,**kkwargs)
def xa60ce2znAlyL5Z8ESXhO(*aargs,**kkwargs):
	x8K9qLvDznQN23fwG = aargs[cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠲ᗩ")]
	hfNZTDrYABwyVcJQlqPS48xpHIi7s = aargs[r6juULGQtnExAko38BZ5Y(u"࠴ᗪ")]
	if NxsKJnLFEZ9OHXf1h(u"ࠨࡶ࡬ࡱࡪ࠭ဇ") in list(kkwargs.keys()): bb46G0wyqXpNUmZVEMCFH32gfTzt = kkwargs[SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠩࡷ࡭ࡲ࡫ࠧဈ")]
	else: bb46G0wyqXpNUmZVEMCFH32gfTzt = cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠵࠵࠶࠰ᗫ")
	if len(aargs)>I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠷ᗬ") and SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠪࡸ࡮ࡳࡥࠨဉ") not in aargs[I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠷ᗬ")]: profile = aargs[I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠷ᗬ")]
	else: profile = r6juULGQtnExAko38BZ5Y(u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࠪည")
	VdGSkwvXryE6H = HDSs6LB1wArQcd(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡓࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡌࡱࡦ࡭ࡥ࠯ࡺࡰࡰࠬဋ"),U0AdbxBVqaQOwTJIcSgN1z9iM7r,YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧဌ"),CgPbwXm1RilpJUSGHLhy(u"ࠧ࠸࠴࠳ࡴࠬဍ"))
	image_filename = WHrbZo7z9DYcEtS.replace(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠨࡡ࠳࠴࠵࠶࡟ࠨဎ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠩࡢࠫဏ")+str(w6vebiEZtpCjJcILP8Skx5rHn.time())+cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠪࡣࠬတ"))
	image_filename = image_filename.replace(Kwl07iYTtDLN3zP(u"ࠫࡡࡢࠧထ"),MM564HfnUV0XIR(u"ࠬࡢ࡜࡝࡞ࠪဒ")).replace(WbM6qAjrn7fEXGZw(u"࠭࠯࠰ࠩဓ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠧ࠰࠱࠲࠳ࠬန"))
	image_height = ttLMqzgZbm(ItgK5FqGDz2Rf7mAJkbT(u"ࠨࠩပ"),ta478EuZQJIWhgBnsf6iU(u"ࠩࠪဖ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠪࠫဗ"),x8K9qLvDznQN23fwG,hfNZTDrYABwyVcJQlqPS48xpHIi7s,profile,CgPbwXm1RilpJUSGHLhy(u"ࠫࡱ࡫ࡦࡵࠩဘ"),tOdiG2HWFRBXg1sUh(u"ࡋࡧ࡬ࡴࡧᜧ"),image_filename)
	VdGSkwvXryE6H.show()
	if profile==r6juULGQtnExAko38BZ5Y(u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡣࡹࡽ࡯ࡩࡣ࡯ࡪࡸ࠭မ"):
		VdGSkwvXryE6H.getControl(CgPbwXm1RilpJUSGHLhy(u"࠹࠱࠶࠳ᗮ")).setHeight(QmoEjB3hLIw(u"࠸࠱࠶ᗭ"))
		VdGSkwvXryE6H.getControl(QmoEjB3hLIw(u"࠼࠴࠹࠶ᗱ")).setPosition(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠶࠷ᗯ"),-bbqAtUz36RPGVTvCkejpJXQB(u"࠺࠳ᗰ"))
		VdGSkwvXryE6H.getControl(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠽࠵࠻࠰ᗲ")).setPosition(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠶࠸࠰ᗳ"),-tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠼࠰ᗴ"))
		VdGSkwvXryE6H.getControl(Kwl07iYTtDLN3zP(u"࠶࠳࠴ᗷ")).setPosition(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠹࠱ᗵ"),-NxsKJnLFEZ9OHXf1h(u"࠴࠷ᗶ"))
	VdGSkwvXryE6H.getControl(bbqAtUz36RPGVTvCkejpJXQB(u"࠷࠴࠶ᗸ")).setVisible(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࡌࡡ࡭ࡵࡨᜨ"))
	VdGSkwvXryE6H.getControl(MM564HfnUV0XIR(u"࠸࠵࠸ᗹ")).setVisible(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࡆࡢ࡮ࡶࡩᜩ"))
	VdGSkwvXryE6H.getControl(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠾࠶࠵࠱ᗺ")).setImage(image_filename)
	VdGSkwvXryE6H.getControl(Ox8k6IdtuPaG3NlApQK52oYwM(u"࠿࠰࠶࠲ᗻ")).setHeight(image_height)
	jrPdVsRK795LBq20U = mZHwnlsXWDfV3ri4M.Thread(target=BgrlKAZMbY34O,args=(VdGSkwvXryE6H,image_filename,bb46G0wyqXpNUmZVEMCFH32gfTzt))
	jrPdVsRK795LBq20U.start()
	return
def BgrlKAZMbY34O(VdGSkwvXryE6H,image_filename,bb46G0wyqXpNUmZVEMCFH32gfTzt):
	w6vebiEZtpCjJcILP8Skx5rHn.sleep(bb46G0wyqXpNUmZVEMCFH32gfTzt//tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠱࠱࠲࠳࠲࠵ᗼ"))
	w6vebiEZtpCjJcILP8Skx5rHn.sleep(NNmirJKPp5nWjfC(u"࠱࠰࠴࠴࠵ᗽ"))
	if K3hFytImeYMkJBC.path.exists(image_filename):
		try: K3hFytImeYMkJBC.remove(image_filename)
		except: pass
	return
def pIq1ZYkhw0L93(*aargs,**kkwargs):
	x8K9qLvDznQN23fwG,hfNZTDrYABwyVcJQlqPS48xpHIi7s,profile,direction = S26SnaqcM9XwK8PVphJDv5(u"࠭ࠧယ"),CgPbwXm1RilpJUSGHLhy(u"ࠧࠨရ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩလ"),S26SnaqcM9XwK8PVphJDv5(u"ࠩ࡯ࡩ࡫ࡺࠧဝ")
	if len(aargs)>=tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠳ᗾ"): x8K9qLvDznQN23fwG = aargs[Kwl07iYTtDLN3zP(u"࠳ᗿ")]
	if len(aargs)>=wx18CTJPZ5(u"࠷ᘁ"): hfNZTDrYABwyVcJQlqPS48xpHIi7s = aargs[CIcPowhneWs5tN3(u"࠵ᘀ")]
	if len(aargs)>=YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠹ᘂ"): profile = aargs[I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠲ᘃ")]
	if len(aargs)>=Kwl07iYTtDLN3zP(u"࠶ᘅ"): direction = aargs[Ox8k6IdtuPaG3NlApQK52oYwM(u"࠴ᘄ")]
	return Dkp5YTLQijOEKF(direction,x8K9qLvDznQN23fwG,hfNZTDrYABwyVcJQlqPS48xpHIi7s,profile)
def QjswkAMfpr9602HKBZ(*aargs,**kkwargs):
	return ZuEAJR1lNHkUf0.Dialog().contextmenu(*aargs,**kkwargs)
def Xco6Lu8qJF1lTyanQp3D(*aargs,**kkwargs):
	return ZuEAJR1lNHkUf0.Dialog().browseSingle(*aargs,**kkwargs)
def eRaEQKo9kIjLpgnvtZGP15Sm8Wy(*aargs,**kkwargs):
	return ZuEAJR1lNHkUf0.Dialog().input(*aargs,**kkwargs)
def ARxKazncryd6Ij2OGtCD5eEihuB8m(*aargs,**kkwargs):
	return ZuEAJR1lNHkUf0.DialogProgress(*aargs,**kkwargs)
def YyexoUV8ZWpMXsRir1wAm69QPJKnN(KV7Ss4zP1CBfauxFIZ0GHUTREiv):
	if wH3qxmuXBTeak>r6juULGQtnExAko38BZ5Y(u"࠴࠻࠳࠿࠹ᘆ"): VdGSkwvXryE6H = wx18CTJPZ5(u"ࠪࡦࡺࡹࡹࡥ࡫ࡤࡰࡴ࡭࡮ࡰࡥࡤࡲࡨ࡫࡬ࠨသ")
	else: VdGSkwvXryE6H = Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠫࡧࡻࡳࡺࡦ࡬ࡥࡱࡵࡧࠨဟ")
	KV7Ss4zP1CBfauxFIZ0GHUTREiv = KV7Ss4zP1CBfauxFIZ0GHUTREiv.lower()
	if KV7Ss4zP1CBfauxFIZ0GHUTREiv==QmoEjB3hLIw(u"ࠬࡹࡴࡢࡴࡷࠫဠ"): oos8ymFi9CN2z1jXcR.executebuiltin(dEUYJjrhsaPXNo(u"࠭ࡁࡤࡶ࡬ࡺࡦࡺࡥࡘ࡫ࡱࡨࡴࡽࠨࠨအ")+VdGSkwvXryE6H+wx18CTJPZ5(u"ࠧࠪࠩဢ"))
	elif KV7Ss4zP1CBfauxFIZ0GHUTREiv==WbM6qAjrn7fEXGZw(u"ࠨࡵࡷࡳࡵ࠭ဣ"): oos8ymFi9CN2z1jXcR.executebuiltin(bbqAtUz36RPGVTvCkejpJXQB(u"ࠩࡇ࡭ࡦࡲ࡯ࡨ࠰ࡆࡰࡴࡹࡥࠩࠩဤ")+VdGSkwvXryE6H+ta478EuZQJIWhgBnsf6iU(u"ࠪ࠭ࠬဥ"))
	return
def m5NUYqBzGynIOeAg8(direction,button0=bbqAtUz36RPGVTvCkejpJXQB(u"ࠫࠬဦ"),button1=I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠬ࠭ဧ"),button2=WbM6qAjrn7fEXGZw(u"࠭ࠧဨ"),x8K9qLvDznQN23fwG=FeyZbj8tDil0nSHzTwfsUJ9(u"ࠧࠨဩ"),hfNZTDrYABwyVcJQlqPS48xpHIi7s=dEUYJjrhsaPXNo(u"ࠨࠩဪ"),profile=uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫါ"),pLkTXvKOwEYVuItRQMbac=NNmirJKPp5nWjfC(u"࠴ᘇ"),cfMt0wqEiZ=NNmirJKPp5nWjfC(u"࠴ᘇ")):
	if not direction: direction = SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠪࡧࡪࡴࡴࡦࡴࠪာ")
	VdGSkwvXryE6H = I4IrWekvPaCdsZYwont(NNmirJKPp5nWjfC(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡇࡴࡴࡦࡪࡴࡰࡘ࡭ࡸࡥࡦࡄࡸࡸࡹࡵ࡮ࡴ࠰ࡻࡱࡱ࠭ိ"),U0AdbxBVqaQOwTJIcSgN1z9iM7r,YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭ီ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠭࠷࠳࠲ࡳࠫု"))
	VdGSkwvXryE6H.hQ0kHW1raxc5pTZ6y9DswgBGFfSECi(button0,button1,button2,x8K9qLvDznQN23fwG,hfNZTDrYABwyVcJQlqPS48xpHIi7s,profile,direction,pLkTXvKOwEYVuItRQMbac,cfMt0wqEiZ)
	if pLkTXvKOwEYVuItRQMbac>S26SnaqcM9XwK8PVphJDv5(u"࠵ᘈ"): VdGSkwvXryE6H.aa4M6bvOuDSYynI()
	if cfMt0wqEiZ>CgPbwXm1RilpJUSGHLhy(u"࠶ᘉ"): VdGSkwvXryE6H.YRaTw5UX8vluj()
	if pLkTXvKOwEYVuItRQMbac==bbqAtUz36RPGVTvCkejpJXQB(u"࠰ᘊ") and cfMt0wqEiZ==bbqAtUz36RPGVTvCkejpJXQB(u"࠰ᘊ"): VdGSkwvXryE6H.v8xCiJ76wAORNrUlmajpnK0HQc()
	VdGSkwvXryE6H.doModal()
	JJ94bQazqrY1wS = VdGSkwvXryE6H.choiceID
	return JJ94bQazqrY1wS
def Dkp5YTLQijOEKF(direction,x8K9qLvDznQN23fwG,hfNZTDrYABwyVcJQlqPS48xpHIi7s,profile=r6juULGQtnExAko38BZ5Y(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨူ")):
	if not direction: direction = Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠨ࡮ࡨࡪࡹ࠭ေ")
	VdGSkwvXryE6H = HDSs6LB1wArQcd(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡖࡨࡼࡹ࡜ࡩࡦࡹࡨࡶࡋࡻ࡬࡭ࡕࡦࡶࡪ࡫࡮࠯ࡺࡰࡰࠬဲ"),U0AdbxBVqaQOwTJIcSgN1z9iM7r,qFRrj7ayBKbOsHGSXz(u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫဳ"),MM564HfnUV0XIR(u"ࠫ࠼࠸࠰ࡱࠩဴ"))
	image_filename = WHrbZo7z9DYcEtS.replace(smpniPDOhfwI3H4v7c6TG(u"ࠬࡥ࠰࠱࠲࠳ࡣࠬဵ"),S26SnaqcM9XwK8PVphJDv5(u"࠭࡟ࠨံ")+str(w6vebiEZtpCjJcILP8Skx5rHn.time())+YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠧࡠ့ࠩ"))
	image_filename = image_filename.replace(ItgK5FqGDz2Rf7mAJkbT(u"ࠨ࡞࡟ࠫး"),NxsKJnLFEZ9OHXf1h(u"ࠩ࡟ࡠࡡࡢ္ࠧ")).replace(cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠪ࠳࠴်࠭"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠫ࠴࠵࠯࠰ࠩျ"))
	image_height = ttLMqzgZbm(cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠬ࠭ြ"),dEUYJjrhsaPXNo(u"࠭ࠧွ"),Gk98CL5nXZEN(u"ࠧࠨှ"),x8K9qLvDznQN23fwG,hfNZTDrYABwyVcJQlqPS48xpHIi7s,profile,direction,cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࡇࡣ࡯ࡷࡪᜪ"),image_filename)
	VdGSkwvXryE6H.show()
	VdGSkwvXryE6H.getControl(r6juULGQtnExAko38BZ5Y(u"࠺࠲࠸࠴ᘋ")).setHeight(image_height)
	VdGSkwvXryE6H.getControl(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠻࠳࠹࠵ᘌ")).setImage(image_filename)
	ZZgB3EFfmntaRwlIzeKuA = VdGSkwvXryE6H.doModal()
	try: K3hFytImeYMkJBC.remove(image_filename)
	except: pass
	return ZZgB3EFfmntaRwlIzeKuA
def FY2qK6eHVBl4D0pEut8IgkTczyG(rr39tgpCxv4bmPuWZheBn=tOdiG2HWFRBXg1sUh(u"ࡖࡵࡹࡪᜫ")):
	if rr39tgpCxv4bmPuWZheBn:
		PPGUinpWfm6Xw9NLtbcax53IQ = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,smpniPDOhfwI3H4v7c6TG(u"ࠨࡵࡷࡶࠬဿ"),GGCQK6OAtZUXRhvkgJm(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ၀"),NNmirJKPp5nWjfC(u"࡙ࠪࡘࡋࡒࡂࡉࡈࡒ࡙࠭၁"))
		if PPGUinpWfm6Xw9NLtbcax53IQ: return PPGUinpWfm6Xw9NLtbcax53IQ
	hfNZTDrYABwyVcJQlqPS48xpHIi7s = YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠫࠬ၂")
	if QmoEjB3hLIw(u"࠳ᘍ") and Il5iAWS8vkNBe4Xf.succeeded:
		TcPFsujHEQG3vBwCt = Il5iAWS8vkNBe4Xf.content
		GG5hd4btHaJZ6uYWiXEoPFU3Of = TcPFsujHEQG3vBwCt.count(EAw9bg4rT3Bd8tjSkO(u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠭၃"))
		if GG5hd4btHaJZ6uYWiXEoPFU3Of>EAw9bg4rT3Bd8tjSkO(u"࠼࠵ᘎ"):
			hfNZTDrYABwyVcJQlqPS48xpHIi7s = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(MM564HfnUV0XIR(u"࠭ࡧࡦࡶ࠰ࡸ࡭࡫࠭࡭࡫ࡶࡸ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ၄"),TcPFsujHEQG3vBwCt,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			hfNZTDrYABwyVcJQlqPS48xpHIi7s = hfNZTDrYABwyVcJQlqPS48xpHIi7s[bbqAtUz36RPGVTvCkejpJXQB(u"࠵ᘏ")]
	if not hfNZTDrYABwyVcJQlqPS48xpHIi7s:
		cc0vVFSRdZ = K3hFytImeYMkJBC.path.join(U0AdbxBVqaQOwTJIcSgN1z9iM7r,bbqAtUz36RPGVTvCkejpJXQB(u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭၅"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠨࡷࡶࡩࡷࡧࡧࡦࡰࡷࡷ࠳ࡺࡸࡵࠩ၆"))
		hfNZTDrYABwyVcJQlqPS48xpHIi7s = open(cc0vVFSRdZ,NNmirJKPp5nWjfC(u"ࠩࡵࡦࠬ၇")).read()
		if wvkR1es6d0SrjxKt5FZTMUWz7a: hfNZTDrYABwyVcJQlqPS48xpHIi7s = hfNZTDrYABwyVcJQlqPS48xpHIi7s.decode(S26SnaqcM9XwK8PVphJDv5(u"ࠪࡹࡹ࡬࠸ࠨ၈"))
		hfNZTDrYABwyVcJQlqPS48xpHIi7s = hfNZTDrYABwyVcJQlqPS48xpHIi7s.replace(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠫࡡࡸࠧ၉"),smpniPDOhfwI3H4v7c6TG(u"ࠬ࠭၊"))
	raHUJXBzOg3voeqnGFs28S7ujN6C = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(CgPbwXm1RilpJUSGHLhy(u"࠭ࠨࡎࡱࡽ࡭ࡱࡲࡡ࠯ࠬࡂ࠭ࡡࡴࠧ။"),hfNZTDrYABwyVcJQlqPS48xpHIi7s,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	H8HtDgzckRhLeKia = []
	for XpCOM0t9ZcL8WvBE2xDb3yeonKhQ in raHUJXBzOg3voeqnGFs28S7ujN6C:
		ccqHrK1JUmhkCbNvTB2xIwd8Pi7 = XpCOM0t9ZcL8WvBE2xDb3yeonKhQ.lower()
		if smpniPDOhfwI3H4v7c6TG(u"ࠧࡢࡰࡧࡶࡴ࡯ࡤࠨ၌") in ccqHrK1JUmhkCbNvTB2xIwd8Pi7: continue
		if bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠨࡷࡥࡹࡳࡺࡵࠨ၍") in ccqHrK1JUmhkCbNvTB2xIwd8Pi7: continue
		if wx18CTJPZ5(u"ࠩ࡬ࡴ࡭ࡵ࡮ࡦࠩ၎") in ccqHrK1JUmhkCbNvTB2xIwd8Pi7: continue
		if SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠪࡧࡷࡵࡳࠨ၏") in ccqHrK1JUmhkCbNvTB2xIwd8Pi7: continue
		H8HtDgzckRhLeKia.append(XpCOM0t9ZcL8WvBE2xDb3yeonKhQ)
	PPGUinpWfm6Xw9NLtbcax53IQ = BBioyg7XVR.sample(H8HtDgzckRhLeKia,r6juULGQtnExAko38BZ5Y(u"࠷ᘐ"))
	PPGUinpWfm6Xw9NLtbcax53IQ = PPGUinpWfm6Xw9NLtbcax53IQ[cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠰ᘑ")]
	kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,S26SnaqcM9XwK8PVphJDv5(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧၐ"),dEUYJjrhsaPXNo(u"࡛ࠬࡓࡆࡔࡄࡋࡊࡔࡔࠨၑ"),PPGUinpWfm6Xw9NLtbcax53IQ,Yv7e6ixHfZIPrmMOy3ozwJu2)
	return PPGUinpWfm6Xw9NLtbcax53IQ
def TTvq7ZIFQGf(jbDMGZeVf2RyJ8OxFA94Emu3pgo0St=ta478EuZQJIWhgBnsf6iU(u"࠭ࠧၒ")):
	if not jbDMGZeVf2RyJ8OxFA94Emu3pgo0St: jbDMGZeVf2RyJ8OxFA94Emu3pgo0St = oo5q9yuEdbCeOSxfzJcw.format_exc()
	if jbDMGZeVf2RyJ8OxFA94Emu3pgo0St!=uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠧࡏࡱࡱࡩ࡙ࡿࡰࡦ࠼ࠣࡒࡴࡴࡥ࡝ࡰࠪၓ"): EAPND6zHKrMRuBc91tInYohsl0ywa.stderr.write(jbDMGZeVf2RyJ8OxFA94Emu3pgo0St)
	Zvm7qOC8GUAFB = jbDMGZeVf2RyJ8OxFA94Emu3pgo0St.splitlines()
	E9IA4lBOyNJf = Zvm7qOC8GUAFB[-YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠲ᘒ")]
	YYI49WCOivMu0Jamx = open(g0gdkA6VTy9mGtLch,tOdiG2HWFRBXg1sUh(u"ࠨࡴࡥࠫၔ")).read()
	if wvkR1es6d0SrjxKt5FZTMUWz7a: YYI49WCOivMu0Jamx = YYI49WCOivMu0Jamx.decode(CIcPowhneWs5tN3(u"ࠩࡸࡸ࡫࠾ࠧၕ"))
	YYI49WCOivMu0Jamx = YYI49WCOivMu0Jamx[-I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠺࠳࠴࠵ᘓ"):]
	ZDu46maUtgrHn7Pcj = MM564HfnUV0XIR(u"ࠪࡁࠬၖ")*YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠴࠴࠵ᘔ")
	if ZDu46maUtgrHn7Pcj in YYI49WCOivMu0Jamx: YYI49WCOivMu0Jamx = YYI49WCOivMu0Jamx.rsplit(ZDu46maUtgrHn7Pcj,FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠵ᘕ"))[FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠵ᘕ")]
	if E9IA4lBOyNJf in YYI49WCOivMu0Jamx: YYI49WCOivMu0Jamx = YYI49WCOivMu0Jamx.rsplit(E9IA4lBOyNJf,SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠶ᘖ"))[GGCQK6OAtZUXRhvkgJm(u"࠶ᘗ")]
	uNKYQwvJB79esVxfSTClWg = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(Gk98CL5nXZEN(u"࡙ࠫ࠭࡯ࡶࡴࡦࡩࢁࡓ࡯ࡥࡧࠬ࠾ࠥࡢ࡛ࠡࠪ࠱࠮ࡄ࠯ࠠ࡝࡟ࠪၗ"),YYI49WCOivMu0Jamx,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for QNmX0fIqtGYDKg1a7rRb3wxs9o,dIsZG1fHm5YVkU6Puzq in reversed(uNKYQwvJB79esVxfSTClWg):
		if dIsZG1fHm5YVkU6Puzq: break
	else: dIsZG1fHm5YVkU6Puzq = WbM6qAjrn7fEXGZw(u"ࠬࡔࡏࡕࠢࡖࡔࡊࡉࡉࡇࡋࡈࡈࠬၘ")
	KIFHwWd5396VAiyepGrPNYsck0znB,XpCOM0t9ZcL8WvBE2xDb3yeonKhQ,nnsCqZoJDxrvfdByul = r6juULGQtnExAko38BZ5Y(u"࠭ࠧၙ"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠧࠨၚ"),wx18CTJPZ5(u"ࠨࠩၛ")
	HHZjl51cJR4zN7QGVWsAxF2 = ta478EuZQJIWhgBnsf6iU(u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่ำ฽ร࠻ࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬၜ")+E9IA4lBOyNJf
	VGtuhdKLHN = bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้๋ีะำ࠽ࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧၝ")+dIsZG1fHm5YVkU6Puzq
	for QBAz9LV2TXydlI3qjOZ in reversed(Zvm7qOC8GUAFB):
		if SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠫࡋ࡯࡬ࡦࠢࠥࠫၞ") in QBAz9LV2TXydlI3qjOZ and dEUYJjrhsaPXNo(u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫၟ") in QBAz9LV2TXydlI3qjOZ: break
	QBAz9LV2TXydlI3qjOZ = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠭ࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࠬࠦࡡ࠲ࠠ࡭࡫ࡱࡩࠥ࠮࠮ࠫࡁࠬࡠ࠱ࠦࡩ࡯ࠢࠫ࠲࠯ࡅࠩࠥࠩၠ"),QBAz9LV2TXydlI3qjOZ,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if QBAz9LV2TXydlI3qjOZ:
		KIFHwWd5396VAiyepGrPNYsck0znB,XpCOM0t9ZcL8WvBE2xDb3yeonKhQ,nnsCqZoJDxrvfdByul = QBAz9LV2TXydlI3qjOZ[dEUYJjrhsaPXNo(u"࠰ᘘ")]
		if r6juULGQtnExAko38BZ5Y(u"ࠧ࠰ࠩၡ") in KIFHwWd5396VAiyepGrPNYsck0znB: KIFHwWd5396VAiyepGrPNYsck0znB = KIFHwWd5396VAiyepGrPNYsck0znB.rsplit(ItgK5FqGDz2Rf7mAJkbT(u"ࠨ࠱ࠪၢ"),Gk98CL5nXZEN(u"࠲ᘙ"))[Gk98CL5nXZEN(u"࠲ᘙ")]
		else: KIFHwWd5396VAiyepGrPNYsck0znB = KIFHwWd5396VAiyepGrPNYsck0znB.rsplit(Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠩ࡟ࡠࠬၣ"),EAw9bg4rT3Bd8tjSkO(u"࠳ᘚ"))[EAw9bg4rT3Bd8tjSkO(u"࠳ᘚ")]
		TUtsFf6I3yzX = YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้๋ไโ࠼ࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ၤ")+KIFHwWd5396VAiyepGrPNYsck0znB
		hDjZQGIfr89bqtF5024XLeTlCoN = CIcPowhneWs5tN3(u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ำุำ࠽ࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧၥ")+XpCOM0t9ZcL8WvBE2xDb3yeonKhQ
		PPbehln4F59cq6B = cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไๆๅส๊࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩၦ")+nnsCqZoJDxrvfdByul
		StlUWn57HmvPsgqQd84ZDO = TUtsFf6I3yzX+WbM6qAjrn7fEXGZw(u"࠭࡜࡯ࠩၧ")+hDjZQGIfr89bqtF5024XLeTlCoN+GGCQK6OAtZUXRhvkgJm(u"ࠧ࡝ࡰࠪၨ")+PPbehln4F59cq6B+MM564HfnUV0XIR(u"ࠨ࡞ࡱࠫၩ")+VGtuhdKLHN+qFRrj7ayBKbOsHGSXz(u"ࠩ࡟ࡲࠬၪ")+HHZjl51cJR4zN7QGVWsAxF2
		KslYwhUobJD03GfXzeBVL = hDjZQGIfr89bqtF5024XLeTlCoN+Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠪࡠࡳ࠭ၫ")+VGtuhdKLHN+FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠫࡡࡴࠧၬ")+HHZjl51cJR4zN7QGVWsAxF2+smpniPDOhfwI3H4v7c6TG(u"ࠬࡢ࡮ࠨၭ")+TUtsFf6I3yzX+QmoEjB3hLIw(u"࠭࡜࡯ࠩၮ")+PPbehln4F59cq6B
		Kr9J6yfash8Z = hDjZQGIfr89bqtF5024XLeTlCoN+tOdiG2HWFRBXg1sUh(u"ࠧ࡝ࡰࠪၯ")+HHZjl51cJR4zN7QGVWsAxF2+CIcPowhneWs5tN3(u"ࠨ࡞ࡱࠫၰ")+TUtsFf6I3yzX+tOdiG2HWFRBXg1sUh(u"ࠩ࡟ࡲࠬၱ")+PPbehln4F59cq6B
	else:
		TUtsFf6I3yzX,hDjZQGIfr89bqtF5024XLeTlCoN,PPbehln4F59cq6B = wx18CTJPZ5(u"ࠪࠫၲ"),ta478EuZQJIWhgBnsf6iU(u"ࠫࠬၳ"),NNmirJKPp5nWjfC(u"ࠬ࠭ၴ")
		StlUWn57HmvPsgqQd84ZDO = VGtuhdKLHN+FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠭࡜࡯࡞ࡱࠫၵ")+HHZjl51cJR4zN7QGVWsAxF2
		KslYwhUobJD03GfXzeBVL = VGtuhdKLHN+CgPbwXm1RilpJUSGHLhy(u"ࠧ࡝ࡰ࡟ࡲࠬၶ")+HHZjl51cJR4zN7QGVWsAxF2
		Kr9J6yfash8Z = HHZjl51cJR4zN7QGVWsAxF2
	XyZ8TV12OsWj = bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠨฯาฯࠥิืฤࠢ฽๎ึࠦๅใื๋ำࠬၷ")+smpniPDOhfwI3H4v7c6TG(u"ࠩ࡟ࡲࠬၸ")
	QPv4JFmspDgMyNcb0kB7lex = PX0Mt4892Q()
	EIPZL5Rj4ayYOGfkDUiW = []
	s4Bng5iAZQSTtpDw9 = QPv4JFmspDgMyNcb0kB7lex[smpniPDOhfwI3H4v7c6TG(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨၹ")]
	GGVdfWs8Y2uSbQXP6pEqgmAH = bd6QCIZMsF(VnhK9wvHBGuo1fei8DXQ02yFZtsWE)
	if smpniPDOhfwI3H4v7c6TG(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩၺ") in list(QPv4JFmspDgMyNcb0kB7lex.keys()):
		for V8VRKYUXlcz,HDswF4rzbgNJSh,xp0hHwTVo6 in s4Bng5iAZQSTtpDw9: EIPZL5Rj4ayYOGfkDUiW = max(EIPZL5Rj4ayYOGfkDUiW,HDswF4rzbgNJSh)
		if GGVdfWs8Y2uSbQXP6pEqgmAH<EIPZL5Rj4ayYOGfkDUiW:
			x8K9qLvDznQN23fwG = FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"่ࠬๅࠡสอัิ๐หࠡษ็ฬึ์วๆฮࠣๆอ๊ࠠฦำึห้ࠦวๅลั฻ฬวࠠๅๆ่ฬึ๋ฬࠨၻ")
			JJ94bQazqrY1wS = m5NUYqBzGynIOeAg8(r6juULGQtnExAko38BZ5Y(u"࠭ࡲࡪࡩ࡫ࡸࠬၼ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠧฦำึห้ࠦลๅ๋ࠣห้๋ศา็ฯࠫၽ"),dEUYJjrhsaPXNo(u"ࠨฬะำ๏ัࠧၾ"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠩัีําࠧၿ"),XyZ8TV12OsWj+x8K9qLvDznQN23fwG,StlUWn57HmvPsgqQd84ZDO)
			if JJ94bQazqrY1wS==NxsKJnLFEZ9OHXf1h(u"࠳ᘛ"):
				A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(QmoEjB3hLIw(u"ࠪࡧࡪࡴࡴࡦࡴࠪႀ"),ta478EuZQJIWhgBnsf6iU(u"ࠫำื่อࠩႁ"),qFRrj7ayBKbOsHGSXz(u"ࠬะอะ์ฮࠫႂ"),wx18CTJPZ5(u"࠭ࠧႃ"),x8K9qLvDznQN23fwG)
				if A5vgi1F6qVunZMas2Nf==uAl3gHavMJZL4xmNe62nDiBoQ(u"࠵ᘜ"): JJ94bQazqrY1wS = uAl3gHavMJZL4xmNe62nDiBoQ(u"࠵ᘜ")
			if JJ94bQazqrY1wS==NNmirJKPp5nWjfC(u"࠶ᘝ"):
				import m4OhBzk7o2
				m4OhBzk7o2.NcRCDvgHBAS0(NNmirJKPp5nWjfC(u"ࡗࡶࡺ࡫ᜬ"),NNmirJKPp5nWjfC(u"ࡗࡶࡺ࡫ᜬ"))
			return
	r6rcNvQ8zZULpbhsAykg4 = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠧ࡭࡫ࡶࡸࠬႄ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫႅ"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠩࡄࡐࡑࡥࡓࡆࡐࡗࡣࡊࡘࡒࡐࡔࡖࠫႆ"))
	if not r6rcNvQ8zZULpbhsAykg4: r6rcNvQ8zZULpbhsAykg4 = []
	KslYwhUobJD03GfXzeBVL = KslYwhUobJD03GfXzeBVL.replace(CIcPowhneWs5tN3(u"ࠪࡠࡳ࠭ႇ"),smpniPDOhfwI3H4v7c6TG(u"ࠫࡡࡢ࡮ࠨႈ")).replace(Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠬࡡࡒࡕࡎࡠࠫႉ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠭ࠧႊ")).replace(EAw9bg4rT3Bd8tjSkO(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪႋ"),MM564HfnUV0XIR(u"ࠨࠩႌ")).replace(WbM6qAjrn7fEXGZw(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠႍࠫ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠪࠫႎ"))
	Kr9J6yfash8Z = Kr9J6yfash8Z.replace(NNmirJKPp5nWjfC(u"ࠫࡡࡴࠧႏ"),dEUYJjrhsaPXNo(u"ࠬࡢ࡜࡯ࠩ႐")).replace(MM564HfnUV0XIR(u"࡛࠭ࡓࡖࡏࡡࠬ႑"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠧࠨ႒")).replace(wx18CTJPZ5(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ႓"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠩࠪ႔")).replace(Kwl07iYTtDLN3zP(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ႕"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠫࠬ႖"))
	qD5IL7m8KoEy = VnhK9wvHBGuo1fei8DXQ02yFZtsWE+FeyZbj8tDil0nSHzTwfsUJ9(u"ࠬࡀ࠺ࠨ႗")+Kr9J6yfash8Z
	if qD5IL7m8KoEy in r6rcNvQ8zZULpbhsAykg4:
		x8K9qLvDznQN23fwG = qFRrj7ayBKbOsHGSXz(u"࠭ไใัࠣๆ๊ะࠠศ่อࠤุอศใษࠣฬสืำศๆ๋ࠣีอࠠศๆั฻ศࠦลๅ๋ࠣห้๋ศา็ฯࠫ႘")
		tehb3k5a2PufGOdBIUw8j(NNmirJKPp5nWjfC(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭႙"),EAw9bg4rT3Bd8tjSkO(u"ࠨࠩႚ"),XyZ8TV12OsWj+x8K9qLvDznQN23fwG,StlUWn57HmvPsgqQd84ZDO)
		return
	s2Tzg6kL7m3XlZcv = str(wH3qxmuXBTeak).split(GGCQK6OAtZUXRhvkgJm(u"ࠩ࠱ࠫႛ"))[CIcPowhneWs5tN3(u"࠶ᘞ")]
	pAeIhbuLSFw7j49qxtcg8dDrmKO = mR20sONyKIlV[SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪႜ")][r6juULGQtnExAko38BZ5Y(u"࠶ᘟ")]
	Il5iAWS8vkNBe4Xf = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,Gk98CL5nXZEN(u"ࠫࡕࡕࡓࡕࠩႝ"),pAeIhbuLSFw7j49qxtcg8dDrmKO,SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠬ࠭႞"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠭ࠧ႟"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠧࠨႠ"),dEUYJjrhsaPXNo(u"ࠨࠩႡ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡍࡕࡗࡠࡇ࡛ࡍ࡙ࡥࡅࡓࡔࡒࡖࡘ࠳࠱ࡴࡶࠪႢ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࡊࡦࡲࡳࡦᜭ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࡊࡦࡲࡳࡦᜭ"))
	TcPFsujHEQG3vBwCt = Il5iAWS8vkNBe4Xf.content
	q3VRHbPns9m6pDSFAGLNk5u2CgoT = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(CgPbwXm1RilpJUSGHLhy(u"ࠪࡗ࡙ࡇࡒࡕ࠼࠽ࡗ࡙ࡇࡒࡕ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬࡇࡑࡈ࠿ࡀࡅࡏࡆࠪႣ"),TcPFsujHEQG3vBwCt,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for qfGNv703xL25,ATLSvyj5kxJpItlFiGQg1XUsur6W0,qonkXRG9sEezplS13MfLvFxB,jew2zrMZkbgHTmUnVJia9 in q3VRHbPns9m6pDSFAGLNk5u2CgoT:
		qfGNv703xL25 = qfGNv703xL25.split(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠫ࠰࠭Ⴄ"))
		qonkXRG9sEezplS13MfLvFxB = qonkXRG9sEezplS13MfLvFxB.split(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠬ࠱ࠧႥ"))
		jew2zrMZkbgHTmUnVJia9 = jew2zrMZkbgHTmUnVJia9.split(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠭ࠫࠨႦ"))
		if XpCOM0t9ZcL8WvBE2xDb3yeonKhQ in qfGNv703xL25 and E9IA4lBOyNJf==ATLSvyj5kxJpItlFiGQg1XUsur6W0 and VnhK9wvHBGuo1fei8DXQ02yFZtsWE in qonkXRG9sEezplS13MfLvFxB and s2Tzg6kL7m3XlZcv in jew2zrMZkbgHTmUnVJia9:
			x8K9qLvDznQN23fwG = QmoEjB3hLIw(u"่ࠧาสࠤฬ๊ฮุล้ࠣ฾ื่โ๋ࠢื๏฿วๅฮࠣฬฬ๊ลึัสีࠥอไใษา้ࠬႧ")
			A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(r6juULGQtnExAko38BZ5Y(u"ࠨࡴ࡬࡫࡭ࡺࠧႨ"),wx18CTJPZ5(u"ࠩัีําࠧႩ"),tOdiG2HWFRBXg1sUh(u"ࠪษึูวๅࠢศ่๎ࠦวๅ็หี๊าࠧႪ"),XyZ8TV12OsWj+x8K9qLvDznQN23fwG,StlUWn57HmvPsgqQd84ZDO)
			if A5vgi1F6qVunZMas2Nf==FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠲ᘠ"): tehb3k5a2PufGOdBIUw8j(Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫႫ"),ItgK5FqGDz2Rf7mAJkbT(u"ࠬ࠭Ⴌ"),r6juULGQtnExAko38BZ5Y(u"࠭ࠧႭ"),x8K9qLvDznQN23fwG)
			return
	x8K9qLvDznQN23fwG = ta478EuZQJIWhgBnsf6iU(u"ࠧศๆิะฬวࠠฦำึห้ࠦ็ัษࠣห้ิืฤࠢศ่๎ࠦวๅ็หี๊าࠧႮ")
	tehb3k5a2PufGOdBIUw8j(ta478EuZQJIWhgBnsf6iU(u"ࠨࡴ࡬࡫࡭ࡺࠧႯ"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠩศีุอไࠡว็ํࠥอไๆสิ้ั࠭Ⴐ"),XyZ8TV12OsWj+x8K9qLvDznQN23fwG,StlUWn57HmvPsgqQd84ZDO)
	A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(GGCQK6OAtZUXRhvkgJm(u"ࠪࡧࡪࡴࡴࡦࡴࠪႱ"),r6juULGQtnExAko38BZ5Y(u"ࠫࠬႲ"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࠬ࠭Ⴓ"),r6juULGQtnExAko38BZ5Y(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩႴ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠧิ๊ไࠤ๏ะๅࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢศ่๎ࠦวๅ็หี๊าࠠๅๅํࠤ๏฿ัโࠢส่๊ฮัๆฮࠣว๏์้ࠠ็อํࠥ๎ใ๋ใࠣ์้๋วัษࠣัฺ๊ส้ࠡำ๋ࠥอไๆึๆ่ฮࠦไฤ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠤํ๊วࠡ์ึฮ฼๐ูࠡษุ่ฬำࠠๆึๆ่ฮ่่๊่ࠦࠣฬฺ๊ࠦำไࠤ่๐แฺ๊ࠡีฯ่ࠦๅ็สิฬุ่ࠦำอࠤํ๋ส๊ࠢ฻๋ึะ่ࠠา๊ࠤฬ๊ๅีๅ็อࠥ࠴่ࠠๆࠣฮึ๐ฯࠡลิืฬ๊ࠠศๆึะ้ࠦฟࠨႵ"))
	if A5vgi1F6qVunZMas2Nf==r6juULGQtnExAko38BZ5Y(u"࠳ᘡ"): B0MZ9n3zypJ = zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࠫႶ")
	else:
		tehb3k5a2PufGOdBIUw8j(dEUYJjrhsaPXNo(u"ࠩࡦࡩࡳࡺࡥࡳࠩႷ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠪࠫႸ"),CgPbwXm1RilpJUSGHLhy(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧႹ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ห็ࠣษ้เวยࠢศีุอไࠡษ็า฼ษ࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ็ว๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮ้ࠠๆสࠤ๏ูสุ์฼ࠤส฻ไศฯࠣห้ิืฤࠢหำํ์ࠠิฮ็ࠤฬ๊รฯูสลࠥอไั์้่ࠣะ่ษࠢไ๎์ࠦฬๆ์฼ࠤฯ็วึ์็ࠤ์ึวࠡษ็า฼ษ้ࠠ฼ํี์ࠦๅ็ࠢส่ศิืศรࠪႺ"))
		return
	EiMsPpS3O1Ba = KslYwhUobJD03GfXzeBVL
	from m4OhBzk7o2 import ucjsDynE7aJ
	VZHWjJTrAPKG1eLEsxpYo2tS5 = ucjsDynE7aJ(S26SnaqcM9XwK8PVphJDv5(u"࠭ࡅࡳࡴࡲࡶࡸ࠭Ⴛ"),EiMsPpS3O1Ba,Ox8k6IdtuPaG3NlApQK52oYwM(u"࡙ࡸࡵࡦᜮ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠧࠨႼ"),CIcPowhneWs5tN3(u"ࠨࡇࡐࡅࡎࡒ࠭ࡇࡔࡒࡑ࠲࡙ࡈࡐ࡙ࡢࡉ࡝ࡏࡔࡠࡇࡕࡖࡔࡘࡓࠨႽ"),B0MZ9n3zypJ)
	if VZHWjJTrAPKG1eLEsxpYo2tS5 and B0MZ9n3zypJ:
		r6rcNvQ8zZULpbhsAykg4.append(qD5IL7m8KoEy)
		kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,CgPbwXm1RilpJUSGHLhy(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬႾ"),Gk98CL5nXZEN(u"ࠪࡅࡑࡒ࡟ࡔࡇࡑࡘࡤࡋࡒࡓࡑࡕࡗࠬႿ"),r6rcNvQ8zZULpbhsAykg4,D0vjfyxKZuP7pXknq62MwFYU)
	return
def M9V2Ya5NXlQSJWbCco8h(YReuIJ67GDs8NwEiZOAh4xPMb):
	if wvkR1es6d0SrjxKt5FZTMUWz7a: YReuIJ67GDs8NwEiZOAh4xPMb = YReuIJ67GDs8NwEiZOAh4xPMb.encode(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠫࡺࡺࡦ࠹ࠩჀ"))
	dkL0Qy5ZolhseOuCRKMrABV8Uzp = cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠬࡹ࠺࡝࡞࠳࠴࠵࠶ࡥ࡮ࡣࡧࡣࠬჁ")+str(w6vebiEZtpCjJcILP8Skx5rHn.time())+smpniPDOhfwI3H4v7c6TG(u"࠭࠮ࡥࡣࡷࠫჂ")
	open(dkL0Qy5ZolhseOuCRKMrABV8Uzp,FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠧࡸࡤࠪჃ")).write(YReuIJ67GDs8NwEiZOAh4xPMb)
	return
def ORXquBZQ8x2wnWveHtYdCTyU(nHKoSC1PiDe8RFambXd7wGf):
	if nHKoSC1PiDe8RFambXd7wGf:
		WmSFUq5gTRr13 = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,NxsKJnLFEZ9OHXf1h(u"ࠨ࡮࡬ࡷࡹ࠭Ⴤ"),ItgK5FqGDz2Rf7mAJkbT(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬჅ"),ItgK5FqGDz2Rf7mAJkbT(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭჆"))
		if WmSFUq5gTRr13: return WmSFUq5gTRr13
	pAeIhbuLSFw7j49qxtcg8dDrmKO = mR20sONyKIlV[Kwl07iYTtDLN3zP(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫჇ")][MM564HfnUV0XIR(u"࠸ᘢ")]
	gg6VwuY0xOi7 = zVw5tvmZRX(EAw9bg4rT3Bd8tjSkO(u"࠷࠷ᘣ"),nHKoSC1PiDe8RFambXd7wGf)
	he9GovI4XHNf = E8NciTDyFBuIm()
	ir0ULhG6nfRXJHkpAgbF = he9GovI4XHNf.split(NxsKJnLFEZ9OHXf1h(u"ࠬ࠲ࠧ჈"))[MM564HfnUV0XIR(u"࠷ᘤ")]
	tmYNEwjFyAIa6MblD8dTvU9hi7zCKg = K3hFytImeYMkJBC.path.join(U0AdbxBVqaQOwTJIcSgN1z9iM7r,NxsKJnLFEZ9OHXf1h(u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ჉"))
	csz2tAlr5vL48YSZJH1piqhP = zzmlkvSWEbVijTJy()
	A2UWHt59mrMSJdpXNb63hRxq = {tOdiG2HWFRBXg1sUh(u"ࠧࡶࡵࡨࡶࠬ჊"):gg6VwuY0xOi7,dEUYJjrhsaPXNo(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩ჋"):VnhK9wvHBGuo1fei8DXQ02yFZtsWE,I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪ჌"):ir0ULhG6nfRXJHkpAgbF,qFRrj7ayBKbOsHGSXz(u"ࠪ࡭ࡩࡹࠧჍ"):NfjyEgxeHGwpbu7QK3O1D(csz2tAlr5vL48YSZJH1piqhP)}
	Il5iAWS8vkNBe4Xf = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,ItgK5FqGDz2Rf7mAJkbT(u"ࠫࡕࡕࡓࡕࠩ჎"),pAeIhbuLSFw7j49qxtcg8dDrmKO,A2UWHt59mrMSJdpXNb63hRxq,Gk98CL5nXZEN(u"ࠬ࠭჏"),Gk98CL5nXZEN(u"࠭ࠧა"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠧࠨბ"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉ࡙ࡥࡑࡖࡇࡖࡘࡎࡕࡎࡔ࠯࠴ࡷࡹ࠭გ"))
	WmSFUq5gTRr13 = []
	if Il5iAWS8vkNBe4Xf.succeeded:
		TcPFsujHEQG3vBwCt = Il5iAWS8vkNBe4Xf.content
		WmSFUq5gTRr13 = TcPFsujHEQG3vBwCt.replace(EAw9bg4rT3Bd8tjSkO(u"ࠩ࡟ࡠࡷ࠭დ"),dEUYJjrhsaPXNo(u"ࠪࡠࡳ࠭ე")).replace(CgPbwXm1RilpJUSGHLhy(u"ࠫࡡࡢ࡮ࠨვ"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࠬࡢ࡮ࠨზ")).replace(dEUYJjrhsaPXNo(u"࠭࡜ࡳ࡞ࡱࠫთ"),Gk98CL5nXZEN(u"ࠧ࡝ࡰࠪი")).replace(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠨ࡞ࡵࠫკ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠩ࡟ࡲࠬლ"))
		WmSFUq5gTRr13 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(tOdiG2HWFRBXg1sUh(u"ࠪࡗ࡙ࡇࡒࡕ࠼࠽ࡗ࡙ࡇࡒࡕ࠼࠽ࠬࡡࡪࠫࠪ࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲࡊࡔࡄ࠻࠼ࡈࡒࡉ࠭მ"),WmSFUq5gTRr13,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if WmSFUq5gTRr13:
			WmSFUq5gTRr13 = sorted(WmSFUq5gTRr13,reverse=bbqAtUz36RPGVTvCkejpJXQB(u"ࡌࡡ࡭ࡵࡨᜯ"),key=lambda key: int(key[ta478EuZQJIWhgBnsf6iU(u"࠶ᘥ")]))
			N0DKTmwQprlGkE,gg6VwuY0xOi7,yTJXbEc9LjmfVRD0N2F,gqf9tEKLQN2J6bAUr0ivHIOSD,n8g9KIdWMyTi2JDkvEfBA6,rreason = WmSFUq5gTRr13[wx18CTJPZ5(u"࠰ᘦ")]
			A8JWDqoxi2QEONt = rreason if hPfgMmZC19lRiKwpN(NNmirJKPp5nWjfC(u"ࠫࡒ࡚࠰࠶ࡊ࡛࠴ࡱ࡚ࡔࡆࡈࡑࡗ࡚ࡔࡦࡖࡇ࡙ࡗࡘ࡛࠹ࡆ࡚ࠪნ")) else yTJXbEc9LjmfVRD0N2F
			if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(QmoEjB3hLIw(u"ࠬࡧࡶ࠯ࡲࡨࡶ࡮ࡵࡤ࠯࡫ࡱࡪࡴࡹࠧო"),A8JWDqoxi2QEONt)
			kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,ta478EuZQJIWhgBnsf6iU(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩპ"),NNmirJKPp5nWjfC(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪჟ"),WmSFUq5gTRr13,Yv7e6ixHfZIPrmMOy3ozwJu2)
			if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪრ"),NfjyEgxeHGwpbu7QK3O1D(eOYicX68ruMjpN0dKtWP5QTSE))
	return WmSFUq5gTRr13
def oURBK4OhLeDr9YpgSxskTJV0ZWyP(xxNRKDfAlti,zowkeND7d9=MM564HfnUV0XIR(u"࠱ᘧ"),LyqWkMJPoITGSOHQ=MM564HfnUV0XIR(u"࠱ᘧ")):
	if zowkeND7d9 and not LyqWkMJPoITGSOHQ: LyqWkMJPoITGSOHQ = len(xxNRKDfAlti)//zowkeND7d9
	VazG0KchdxBnAvufpiHIEPL19jgs,Deiz7ocWQjVnIg,loAFL391p7qDWU8mTed0PgJ = [],-tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠳ᘨ"),CgPbwXm1RilpJUSGHLhy(u"࠳ᘩ")
	for DUacmNFpbwv13uylo in xxNRKDfAlti:
		if loAFL391p7qDWU8mTed0PgJ%LyqWkMJPoITGSOHQ==dEUYJjrhsaPXNo(u"࠴ᘪ"):
			Deiz7ocWQjVnIg += ItgK5FqGDz2Rf7mAJkbT(u"࠶ᘫ")
			VazG0KchdxBnAvufpiHIEPL19jgs.append([])
		VazG0KchdxBnAvufpiHIEPL19jgs[Deiz7ocWQjVnIg].append(DUacmNFpbwv13uylo)
		loAFL391p7qDWU8mTed0PgJ += zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠷ᘬ")
	return VazG0KchdxBnAvufpiHIEPL19jgs
def bCP7cRFqftIlyusOLUog(dkL0Qy5ZolhseOuCRKMrABV8Uzp,YReuIJ67GDs8NwEiZOAh4xPMb):
	H8Aa4UyvRWTCjk = K3hFytImeYMkJBC.path.join(llrbyaFHOt9e,dkL0Qy5ZolhseOuCRKMrABV8Uzp)
	if NxsKJnLFEZ9OHXf1h(u"࠱ᘭ") or bbqAtUz36RPGVTvCkejpJXQB(u"ࠩࡌࡔ࡙࡜࡟ࠨს") not in dkL0Qy5ZolhseOuCRKMrABV8Uzp or S26SnaqcM9XwK8PVphJDv5(u"ࠪࡑ࠸࡛࡟ࠨტ") not in dkL0Qy5ZolhseOuCRKMrABV8Uzp: hfNZTDrYABwyVcJQlqPS48xpHIi7s = str(YReuIJ67GDs8NwEiZOAh4xPMb)
	else:
		VazG0KchdxBnAvufpiHIEPL19jgs = oURBK4OhLeDr9YpgSxskTJV0ZWyP(YReuIJ67GDs8NwEiZOAh4xPMb,tOdiG2HWFRBXg1sUh(u"࠹ᘮ"))
		hfNZTDrYABwyVcJQlqPS48xpHIi7s = NxsKJnLFEZ9OHXf1h(u"ࠫࠬუ")
		for AMjsTQpqYXtJRiCrcFx in VazG0KchdxBnAvufpiHIEPL19jgs:
			hfNZTDrYABwyVcJQlqPS48xpHIi7s += str(AMjsTQpqYXtJRiCrcFx)+NNmirJKPp5nWjfC(u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫფ")
		hfNZTDrYABwyVcJQlqPS48xpHIi7s = hfNZTDrYABwyVcJQlqPS48xpHIi7s.strip(smpniPDOhfwI3H4v7c6TG(u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬქ"))
	JK8VSmQEqXAwuZIvhP = LPeE7ZjVag6xWTydcwQb.compress(hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	open(H8Aa4UyvRWTCjk,wx18CTJPZ5(u"ࠧࡸࡤࠪღ")).write(JK8VSmQEqXAwuZIvhP)
	return
def iFXta7HnrBexY4(fq8wviaxCU,dkL0Qy5ZolhseOuCRKMrABV8Uzp):
	if fq8wviaxCU==Kwl07iYTtDLN3zP(u"ࠨࡦ࡬ࡧࡹ࠭ყ"): YReuIJ67GDs8NwEiZOAh4xPMb = {}
	elif fq8wviaxCU==EAw9bg4rT3Bd8tjSkO(u"ࠩ࡯࡭ࡸࡺࠧშ"): YReuIJ67GDs8NwEiZOAh4xPMb = []
	elif fq8wviaxCU==qFRrj7ayBKbOsHGSXz(u"ࠪࡷࡹࡸࠧჩ"): YReuIJ67GDs8NwEiZOAh4xPMb = FeyZbj8tDil0nSHzTwfsUJ9(u"ࠫࠬც")
	elif fq8wviaxCU==dEUYJjrhsaPXNo(u"ࠬ࡯࡮ࡵࠩძ"): YReuIJ67GDs8NwEiZOAh4xPMb = dEUYJjrhsaPXNo(u"࠲ᘯ")
	else: YReuIJ67GDs8NwEiZOAh4xPMb = None
	H8Aa4UyvRWTCjk = K3hFytImeYMkJBC.path.join(llrbyaFHOt9e,dkL0Qy5ZolhseOuCRKMrABV8Uzp)
	JK8VSmQEqXAwuZIvhP = open(H8Aa4UyvRWTCjk,S26SnaqcM9XwK8PVphJDv5(u"࠭ࡲࡣࠩწ")).read()
	hfNZTDrYABwyVcJQlqPS48xpHIi7s = LPeE7ZjVag6xWTydcwQb.decompress(JK8VSmQEqXAwuZIvhP)
	if NNmirJKPp5nWjfC(u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭ჭ") not in hfNZTDrYABwyVcJQlqPS48xpHIi7s: YReuIJ67GDs8NwEiZOAh4xPMb = eval(hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	else:
		VazG0KchdxBnAvufpiHIEPL19jgs = hfNZTDrYABwyVcJQlqPS48xpHIi7s.split(ta478EuZQJIWhgBnsf6iU(u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧხ"))
		del hfNZTDrYABwyVcJQlqPS48xpHIi7s
		YReuIJ67GDs8NwEiZOAh4xPMb = []
		TD0rXSCp4qxMwfEAPFLc = MrpuQ4b0AfZ6scLH()
		N0DKTmwQprlGkE = CgPbwXm1RilpJUSGHLhy(u"࠳ᘰ")
		for AMjsTQpqYXtJRiCrcFx in VazG0KchdxBnAvufpiHIEPL19jgs:
			TD0rXSCp4qxMwfEAPFLc.mMKyiSHEPNWT5q80It1RBDokZ(str(N0DKTmwQprlGkE),eval,AMjsTQpqYXtJRiCrcFx)
			N0DKTmwQprlGkE += S26SnaqcM9XwK8PVphJDv5(u"࠵ᘱ")
		del VazG0KchdxBnAvufpiHIEPL19jgs
		TD0rXSCp4qxMwfEAPFLc.bbhBiokOZwDt4AIfy7X()
		TD0rXSCp4qxMwfEAPFLc.r8RWC4G9yOvn6Tm()
		LTkZzdnK7l = list(TD0rXSCp4qxMwfEAPFLc.resultsDICT.keys())
		yk9xC3V8cDq = sorted(LTkZzdnK7l,reverse=Kwl07iYTtDLN3zP(u"ࡆࡢ࡮ࡶࡩᜰ"),key=lambda key: int(key))
		for N0DKTmwQprlGkE in yk9xC3V8cDq:
			YReuIJ67GDs8NwEiZOAh4xPMb += TD0rXSCp4qxMwfEAPFLc.resultsDICT[N0DKTmwQprlGkE]
	return YReuIJ67GDs8NwEiZOAh4xPMb
def UdlXbLPJmQZMT16rRkuNivfYICtgA(aZhcuMGisIkl4npqDoJSrWy5fExX):
	efqX8VyvA9mHtdr62Kb = K3hFytImeYMkJBC.path.join(qKHs0b1SC2v3EZ9xfOluQ,smpniPDOhfwI3H4v7c6TG(u"ࠩࡤࡨࡩࡵ࡮ࡴࠩჯ"),aZhcuMGisIkl4npqDoJSrWy5fExX,Kwl07iYTtDLN3zP(u"ࠪࡥࡩࡪ࡯࡯࠰ࡻࡱࡱ࠭ჰ"))
	try: UjWlcbd5FqPx = open(efqX8VyvA9mHtdr62Kb,wx18CTJPZ5(u"ࠫࡷࡨࠧჱ")).read()
	except:
		MgSY3oC1OrytX = K3hFytImeYMkJBC.path.join(QQmPxURvYeXl2r8IOb,YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠬࡧࡤࡥࡱࡱࡷࠬჲ"),aZhcuMGisIkl4npqDoJSrWy5fExX,wx18CTJPZ5(u"࠭ࡡࡥࡦࡲࡲ࠳ࡾ࡭࡭ࠩჳ"))
		try: UjWlcbd5FqPx = open(MgSY3oC1OrytX,smpniPDOhfwI3H4v7c6TG(u"ࠧࡳࡤࠪჴ")).read()
		except: return GGCQK6OAtZUXRhvkgJm(u"ࠨࠩჵ"),[]
	if wvkR1es6d0SrjxKt5FZTMUWz7a: UjWlcbd5FqPx = UjWlcbd5FqPx.decode(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠩࡸࡸ࡫࠾ࠧჶ"))
	QAg5whs4z2Nouy7dFYCaSe0qclxM = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(CIcPowhneWs5tN3(u"ࠪ࡭ࡩࡃ࠮ࠫࡁࡹࡩࡷࡹࡩࡰࡰࡀ࡟ࡡࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅࠩ࡜࡞ࠥࡠࠬࡣࠧჷ"),UjWlcbd5FqPx,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.IGNORECASE)
	if not QAg5whs4z2Nouy7dFYCaSe0qclxM: return r6juULGQtnExAko38BZ5Y(u"ࠫࠬჸ"),[]
	lOWcMUFZwsvgRX8SiBVkhDpAqEY1T,m2U3ePDdAN = QAg5whs4z2Nouy7dFYCaSe0qclxM[CgPbwXm1RilpJUSGHLhy(u"࠵ᘲ")],bd6QCIZMsF(QAg5whs4z2Nouy7dFYCaSe0qclxM[CgPbwXm1RilpJUSGHLhy(u"࠵ᘲ")])
	return lOWcMUFZwsvgRX8SiBVkhDpAqEY1T,m2U3ePDdAN
def PX0Mt4892Q():
	IIt5nPXrkmCgZuG = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,qFRrj7ayBKbOsHGSXz(u"ࠬࡪࡩࡤࡶࠪჹ"),qFRrj7ayBKbOsHGSXz(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩჺ"),qFRrj7ayBKbOsHGSXz(u"ࠧࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌࠨ჻"))
	if IIt5nPXrkmCgZuG: return IIt5nPXrkmCgZuG
	QPv4JFmspDgMyNcb0kB7lex,IIt5nPXrkmCgZuG = {},{}
	uNKYQwvJB79esVxfSTClWg = [mR20sONyKIlV[CgPbwXm1RilpJUSGHLhy(u"ࠨࡔࡈࡔࡔ࡙ࠧჼ")][GGCQK6OAtZUXRhvkgJm(u"࠶ᘳ")]]
	if wH3qxmuXBTeak>NNmirJKPp5nWjfC(u"࠲࠹࠱࠽࠾ᘵ"): uNKYQwvJB79esVxfSTClWg.append(mR20sONyKIlV[CIcPowhneWs5tN3(u"ࠩࡕࡉࡕࡕࡓࠨჽ")][EAw9bg4rT3Bd8tjSkO(u"࠱ᘴ")])
	if wvkR1es6d0SrjxKt5FZTMUWz7a: uNKYQwvJB79esVxfSTClWg.append(mR20sONyKIlV[CgPbwXm1RilpJUSGHLhy(u"ࠪࡖࡊࡖࡏࡔࠩჾ")][bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠴ᘶ")])
	for GLXf70lMiJzWCIbrtepQ4oknEh in uNKYQwvJB79esVxfSTClWg:
		Il5iAWS8vkNBe4Xf = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,tOdiG2HWFRBXg1sUh(u"ࠫࡌࡋࡔࠨჿ"),GLXf70lMiJzWCIbrtepQ4oknEh,Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠬ࠭ᄀ"),dEUYJjrhsaPXNo(u"࠭ࠧᄁ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠧࠨᄂ"),NNmirJKPp5nWjfC(u"ࠨࠩᄃ"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊࡇࡄࡠࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍ࠯࠴ࡷࡹ࠭ᄄ"))
		if Il5iAWS8vkNBe4Xf.succeeded:
			TcPFsujHEQG3vBwCt = Il5iAWS8vkNBe4Xf.content
			OYN1R6izsE3uvT4L2H9PX = GLXf70lMiJzWCIbrtepQ4oknEh.rsplit(bbqAtUz36RPGVTvCkejpJXQB(u"ࠪ࠳ࠬᄅ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"࠴ᘷ"))[Gk98CL5nXZEN(u"࠴ᘸ")]
			Ug1JH9F7Y5Zw3buf = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(ItgK5FqGDz2Rf7mAJkbT(u"ࠫ࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡺࡪࡸࡳࡪࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᄆ"),TcPFsujHEQG3vBwCt,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.IGNORECASE)
			for aZhcuMGisIkl4npqDoJSrWy5fExX,KPBvfar6mGu3QxURTc15Wl2z in Ug1JH9F7Y5Zw3buf:
				LLxPgR6yHWfSkAr3CsndqzaUJ0Fc = OYN1R6izsE3uvT4L2H9PX+CgPbwXm1RilpJUSGHLhy(u"ࠬ࠵ࠧᄇ")+aZhcuMGisIkl4npqDoJSrWy5fExX+dEUYJjrhsaPXNo(u"࠭࠯ࠨᄈ")+aZhcuMGisIkl4npqDoJSrWy5fExX+ta478EuZQJIWhgBnsf6iU(u"ࠧ࠮ࠩᄉ")+KPBvfar6mGu3QxURTc15Wl2z+tOdiG2HWFRBXg1sUh(u"ࠨ࠰ࡽ࡭ࡵ࠭ᄊ")
				if aZhcuMGisIkl4npqDoJSrWy5fExX not in list(QPv4JFmspDgMyNcb0kB7lex.keys()):
					QPv4JFmspDgMyNcb0kB7lex[aZhcuMGisIkl4npqDoJSrWy5fExX] = []
					IIt5nPXrkmCgZuG[aZhcuMGisIkl4npqDoJSrWy5fExX] = []
				JtczT7kyou8p0PNamBCFGUE2b = bd6QCIZMsF(KPBvfar6mGu3QxURTc15Wl2z)
				QPv4JFmspDgMyNcb0kB7lex[aZhcuMGisIkl4npqDoJSrWy5fExX].append((KPBvfar6mGu3QxURTc15Wl2z,JtczT7kyou8p0PNamBCFGUE2b,LLxPgR6yHWfSkAr3CsndqzaUJ0Fc))
	for aZhcuMGisIkl4npqDoJSrWy5fExX in list(QPv4JFmspDgMyNcb0kB7lex.keys()):
		IIt5nPXrkmCgZuG[aZhcuMGisIkl4npqDoJSrWy5fExX] = sorted(QPv4JFmspDgMyNcb0kB7lex[aZhcuMGisIkl4npqDoJSrWy5fExX],reverse=QmoEjB3hLIw(u"ࡕࡴࡸࡩᜱ"),key=lambda key: key[wx18CTJPZ5(u"࠶ᘹ")])
	kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,S26SnaqcM9XwK8PVphJDv5(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬᄋ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫᄌ"),IIt5nPXrkmCgZuG,Yv7e6ixHfZIPrmMOy3ozwJu2)
	return IIt5nPXrkmCgZuG
def bd6QCIZMsF(KPBvfar6mGu3QxURTc15Wl2z):
	JtczT7kyou8p0PNamBCFGUE2b = []
	DkKbsdfSBXhcmyJMpoY3RvjwxiL86t = KPBvfar6mGu3QxURTc15Wl2z.split(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠫ࠳࠭ᄍ"))
	for ge5HWnZiL8DlzvCPMfBquE3TKFV in DkKbsdfSBXhcmyJMpoY3RvjwxiL86t:
		mrLKVlY9qv = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(S26SnaqcM9XwK8PVphJDv5(u"ࠬࡢࡤࠬࡾ࡞ࡠ࠰ࡢ࠭ࡢ࠯ࡽࡅ࠲ࡠ࡝ࠬࠩᄎ"),ge5HWnZiL8DlzvCPMfBquE3TKFV,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		F8LcPevGNgTVtjWJZy50Sqszhk = []
		for SiK8NQdHpysqYOrI in mrLKVlY9qv:
			if SiK8NQdHpysqYOrI.isdigit(): SiK8NQdHpysqYOrI = int(SiK8NQdHpysqYOrI)
			F8LcPevGNgTVtjWJZy50Sqszhk.append(SiK8NQdHpysqYOrI)
		JtczT7kyou8p0PNamBCFGUE2b.append(F8LcPevGNgTVtjWJZy50Sqszhk)
	return JtczT7kyou8p0PNamBCFGUE2b
def PCSampDGVNfI(JtczT7kyou8p0PNamBCFGUE2b):
	KPBvfar6mGu3QxURTc15Wl2z = I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠭ࠧᄏ")
	for ge5HWnZiL8DlzvCPMfBquE3TKFV in JtczT7kyou8p0PNamBCFGUE2b:
		for SiK8NQdHpysqYOrI in ge5HWnZiL8DlzvCPMfBquE3TKFV: KPBvfar6mGu3QxURTc15Wl2z += str(SiK8NQdHpysqYOrI)
		KPBvfar6mGu3QxURTc15Wl2z += ItgK5FqGDz2Rf7mAJkbT(u"ࠧ࠯ࠩᄐ")
	KPBvfar6mGu3QxURTc15Wl2z = KPBvfar6mGu3QxURTc15Wl2z.strip(tOdiG2HWFRBXg1sUh(u"ࠨ࠰ࠪᄑ"))
	return KPBvfar6mGu3QxURTc15Wl2z
def jNVelpUxiIn(qtR29xU7mNlXukJOreDSj8L5):
	HUiL4nsdTt = {}
	QPv4JFmspDgMyNcb0kB7lex = PX0Mt4892Q()
	ErUlzyaM3YmCPfv427B60nW = c1vMDuaLtS(qtR29xU7mNlXukJOreDSj8L5)
	for aZhcuMGisIkl4npqDoJSrWy5fExX in qtR29xU7mNlXukJOreDSj8L5:
		if aZhcuMGisIkl4npqDoJSrWy5fExX not in list(QPv4JFmspDgMyNcb0kB7lex.keys()): continue
		IIt5nPXrkmCgZuG = QPv4JFmspDgMyNcb0kB7lex[aZhcuMGisIkl4npqDoJSrWy5fExX]
		C2rjw74RBD8L0zOvhginu1YtZFlxby,GGh3LDvKWu5wEZtUOCbxF,x7rbId06SLUf = IIt5nPXrkmCgZuG[qFRrj7ayBKbOsHGSXz(u"࠶ᘺ")]
		lQhSugcZUPELJwenXvD,ffiTAgp5y6PKzH1qcIvEjDL = UdlXbLPJmQZMT16rRkuNivfYICtgA(aZhcuMGisIkl4npqDoJSrWy5fExX)
		H7u1l9ACwOnDixXzaeZYb,c0c1aMKrELlHykpZB8QO3Xsd = ErUlzyaM3YmCPfv427B60nW[aZhcuMGisIkl4npqDoJSrWy5fExX]
		tKkWS3qf5dZNY9FCaLz0U = GGh3LDvKWu5wEZtUOCbxF>ffiTAgp5y6PKzH1qcIvEjDL and H7u1l9ACwOnDixXzaeZYb
		gKMqlA19hi = qFRrj7ayBKbOsHGSXz(u"ࡖࡵࡹࡪᜲ")
		if not H7u1l9ACwOnDixXzaeZYb: eetZUaRN8h2CJ = S26SnaqcM9XwK8PVphJDv5(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪᄒ")
		elif not c0c1aMKrELlHykpZB8QO3Xsd: eetZUaRN8h2CJ = cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬᄓ")
		elif tKkWS3qf5dZNY9FCaLz0U: eetZUaRN8h2CJ = tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠫࡴࡲࡤࠨᄔ")
		else:
			eetZUaRN8h2CJ = bbqAtUz36RPGVTvCkejpJXQB(u"ࠬ࡭࡯ࡰࡦࠪᄕ")
			gKMqlA19hi = Gk98CL5nXZEN(u"ࡉࡥࡱࡹࡥᜳ")
		HUiL4nsdTt[aZhcuMGisIkl4npqDoJSrWy5fExX] = (gKMqlA19hi,lQhSugcZUPELJwenXvD,ffiTAgp5y6PKzH1qcIvEjDL,C2rjw74RBD8L0zOvhginu1YtZFlxby,GGh3LDvKWu5wEZtUOCbxF,eetZUaRN8h2CJ,x7rbId06SLUf)
	return HUiL4nsdTt
def aayBzF9OcXn1kYqRhDNm7gTZ(ZUNMvsVnGde0mpQxb9ID8aKRkFtJg,ggtaSNQWKjrXG6VfyM15RL7E,pzCvJF58SjUxwPD4GfodE03WX1OR=WbM6qAjrn7fEXGZw(u"࠭ࠧᄖ"),hDjZQGIfr89bqtF5024XLeTlCoN=Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠧࠨᄗ"),qfGNv703xL25=wx18CTJPZ5(u"ࠨࠩᄘ")):
	if vciEXHThAPto76QIR2pK: ZUNMvsVnGde0mpQxb9ID8aKRkFtJg.update(ggtaSNQWKjrXG6VfyM15RL7E,pzCvJF58SjUxwPD4GfodE03WX1OR,hDjZQGIfr89bqtF5024XLeTlCoN,qfGNv703xL25)
	else: ZUNMvsVnGde0mpQxb9ID8aKRkFtJg.update(ggtaSNQWKjrXG6VfyM15RL7E,pzCvJF58SjUxwPD4GfodE03WX1OR+Kwl07iYTtDLN3zP(u"ࠩ࡟ࡲࠬᄙ")+hDjZQGIfr89bqtF5024XLeTlCoN+tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠪࡠࡳ࠭ᄚ")+qfGNv703xL25)
	return
def lboxWJEBsiKdO1FTz(HJ1sEm6TVP):
	def RFwk7pltYuAm48Bb5dIvDV1aNePE(BlS9AVoWxw,UjqZ5K6eQu4VPy0SvhBzYsLITpH,CoP0prRQkwinBv3D4UEcVbYKFdl=bbqAtUz36RPGVTvCkejpJXQB(u"ࠦ࠵࠷࠲࠴࠶࠸࠺࠼࠾࠹ࡢࡤࡦࡨࡪ࡬ࡧࡩ࡫࡭࡯ࡱࡳ࡮ࡰࡲࡴࡶࡸࡺࡵࡷࡹࡻࡽࡿࡇࡂࡄࡆࡈࡊࡌࡎࡉࡋࡍࡏࡑࡓࡕࡐࡒࡔࡖࡘ࡚࡜ࡗ࡙࡛࡝ࠦᄛ")):
		return ((BlS9AVoWxw == QmoEjB3hLIw(u"࠰ᘻ")) and CoP0prRQkwinBv3D4UEcVbYKFdl[QmoEjB3hLIw(u"࠰ᘻ")]) or (RFwk7pltYuAm48Bb5dIvDV1aNePE(BlS9AVoWxw // UjqZ5K6eQu4VPy0SvhBzYsLITpH, UjqZ5K6eQu4VPy0SvhBzYsLITpH, CoP0prRQkwinBv3D4UEcVbYKFdl).lstrip(CoP0prRQkwinBv3D4UEcVbYKFdl[QmoEjB3hLIw(u"࠰ᘻ")]) + CoP0prRQkwinBv3D4UEcVbYKFdl[BlS9AVoWxw % UjqZ5K6eQu4VPy0SvhBzYsLITpH])
	def zK2XkAhDT6G(RRcrs2aJ1EgbN, d810OLzfxyr, f2zRBWtqK0EXauIpD36, Uy5gmKdj6wZADzrf7Hqvh4, Mup4EWQfyw3o5R2Ycb1idrG=None, zfy8eg4oWEQNBIUblPYZhp=None, h1MyGNOmVRW2iKuxs8fl4SnIv3Z5Lq=None):
		while (f2zRBWtqK0EXauIpD36):
			f2zRBWtqK0EXauIpD36-=qFRrj7ayBKbOsHGSXz(u"࠲ᘼ")
			if (Uy5gmKdj6wZADzrf7Hqvh4[f2zRBWtqK0EXauIpD36]): RRcrs2aJ1EgbN = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.sub(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠧࡢ࡜ࡣࠤᄜ") + RFwk7pltYuAm48Bb5dIvDV1aNePE(f2zRBWtqK0EXauIpD36, d810OLzfxyr) + Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠨ࡜࡝ࡤࠥᄝ"),  Uy5gmKdj6wZADzrf7Hqvh4[f2zRBWtqK0EXauIpD36], RRcrs2aJ1EgbN)
		return RRcrs2aJ1EgbN
	HJ1sEm6TVP = HJ1sEm6TVP.split(CgPbwXm1RilpJUSGHLhy(u"ࠧࡾࠪࠪᄞ"))[wx18CTJPZ5(u"࠳ᘽ")]
	HJ1sEm6TVP = HJ1sEm6TVP.rsplit(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠨࡵࡳࡰ࡮ࡺࠧᄟ"))[Ox8k6IdtuPaG3NlApQK52oYwM(u"࠳ᘾ")]+r6juULGQtnExAko38BZ5Y(u"ࠤࡶࡴࡱ࡯ࡴࠩࠩࡿࠫ࠮࠯ࠢᄠ")
	OTdKGIE4Ms6hJjkFwoXyfrU = eval(smpniPDOhfwI3H4v7c6TG(u"ࠪࡹࡳࡶࡡࡤ࡭ࠫࠫᄡ")+HJ1sEm6TVP,{MM564HfnUV0XIR(u"ࠫࡧࡧࡳࡦࡐࠪᄢ"):RFwk7pltYuAm48Bb5dIvDV1aNePE,Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠬࡻ࡮ࡱࡣࡦ࡯ࠬᄣ"):zK2XkAhDT6G})
	return OTdKGIE4Ms6hJjkFwoXyfrU
def Iv3sJjTSEi9e25(pAeIhbuLSFw7j49qxtcg8dDrmKO,aYshwrj9Sb=ItgK5FqGDz2Rf7mAJkbT(u"࠭ࠧᄤ")):
	if aYshwrj9Sb==wx18CTJPZ5(u"ࠧ࡭ࡱࡺࡩࡷ࠭ᄥ"): pAeIhbuLSFw7j49qxtcg8dDrmKO = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.sub(qFRrj7ayBKbOsHGSXz(u"ࡳࠩࠨ࡟࠵࠳࠹ࡂ࠯࡝ࡡࢀ࠸ࡽࠨᄦ"),lambda SSavCOxFMh1rjW0Q: SSavCOxFMh1rjW0Q.group(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠴ᘿ")).lower(),pAeIhbuLSFw7j49qxtcg8dDrmKO)
	elif aYshwrj9Sb==NxsKJnLFEZ9OHXf1h(u"ࠩࡸࡴࡵ࡫ࡲࠨᄧ"): pAeIhbuLSFw7j49qxtcg8dDrmKO = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.sub(MM564HfnUV0XIR(u"ࡵࠫࠪࡡ࠰࠮࠻ࡤ࠱ࡿࡣࡻ࠳ࡿࠪᄨ"),lambda SSavCOxFMh1rjW0Q: SSavCOxFMh1rjW0Q.group(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠵ᙀ")).upper(),pAeIhbuLSFw7j49qxtcg8dDrmKO)
	return pAeIhbuLSFw7j49qxtcg8dDrmKO
def c1vMDuaLtS(qtR29xU7mNlXukJOreDSj8L5):
	xVcwzjoK8aTULihb5,bGAKH7S24YqtREwpUysIm8X = FeyZbj8tDil0nSHzTwfsUJ9(u"ࡊࡦࡲࡳࡦ᜴"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࡊࡦࡲࡳࡦ᜴")
	md59xZUEq3IOnPp2 = iZv4fPkF5Trx1L8EsVHC2S.connect(wmrN7GxQWCAD9PzM3Tj)
	md59xZUEq3IOnPp2.text_factory = str
	ngBDPjZshKvdX6 = md59xZUEq3IOnPp2.cursor()
	if len(qtR29xU7mNlXukJOreDSj8L5)==r6juULGQtnExAko38BZ5Y(u"࠷ᙁ"): r8E3B2w1RgtLWfCMxNnsz4U0GFTb9 = I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠫ࠭ࠨࠧᄩ")+qtR29xU7mNlXukJOreDSj8L5[GGCQK6OAtZUXRhvkgJm(u"࠰ᙂ")]+FeyZbj8tDil0nSHzTwfsUJ9(u"ࠬࠨࠩࠨᄪ")
	else: r8E3B2w1RgtLWfCMxNnsz4U0GFTb9 = str(tuple(qtR29xU7mNlXukJOreDSj8L5))
	ngBDPjZshKvdX6.execute(QmoEjB3hLIw(u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࡡࡥࡦࡲࡲࡎࡊࠬࡦࡰࡤࡦࡱ࡫ࡤࠡࡈࡕࡓࡒࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡌࡒࠥ࠭ᄫ")+r8E3B2w1RgtLWfCMxNnsz4U0GFTb9+CIcPowhneWs5tN3(u"ࠧࠡ࠽ࠪᄬ"))
	MRDAU8alpIbtNPn1Y95WJK2d6mr3E = ngBDPjZshKvdX6.fetchall()
	ErUlzyaM3YmCPfv427B60nW = {}
	for aZhcuMGisIkl4npqDoJSrWy5fExX in qtR29xU7mNlXukJOreDSj8L5: ErUlzyaM3YmCPfv427B60nW[aZhcuMGisIkl4npqDoJSrWy5fExX] = (CgPbwXm1RilpJUSGHLhy(u"ࡋࡧ࡬ࡴࡧ᜵"),CgPbwXm1RilpJUSGHLhy(u"ࡋࡧ࡬ࡴࡧ᜵"))
	for aZhcuMGisIkl4npqDoJSrWy5fExX,bGAKH7S24YqtREwpUysIm8X in MRDAU8alpIbtNPn1Y95WJK2d6mr3E:
		xVcwzjoK8aTULihb5 = EAw9bg4rT3Bd8tjSkO(u"࡚ࡲࡶࡧ᜶")
		bGAKH7S24YqtREwpUysIm8X = bGAKH7S24YqtREwpUysIm8X==tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠲ᙃ")
		ErUlzyaM3YmCPfv427B60nW[aZhcuMGisIkl4npqDoJSrWy5fExX] = (xVcwzjoK8aTULihb5,bGAKH7S24YqtREwpUysIm8X)
	md59xZUEq3IOnPp2.close()
	return ErUlzyaM3YmCPfv427B60nW
def v3vOJa64yzBGcdQZ0oPrhNF9L(KIFHwWd5396VAiyepGrPNYsck0znB):
	s4Bng5iAZQSTtpDw9 = GGCQK6OAtZUXRhvkgJm(u"ࠨࠩᄭ")
	if K3hFytImeYMkJBC.path.exists(KIFHwWd5396VAiyepGrPNYsck0znB):
		xxMqmzh3YOFKHbyCQtUwjL2slZV = open(KIFHwWd5396VAiyepGrPNYsck0znB,EAw9bg4rT3Bd8tjSkO(u"ࠩࡵࡦࠬᄮ")).read()
		if wvkR1es6d0SrjxKt5FZTMUWz7a: xxMqmzh3YOFKHbyCQtUwjL2slZV = xxMqmzh3YOFKHbyCQtUwjL2slZV.decode(QmoEjB3hLIw(u"ࠪࡹࡹ࡬࠸ࠨᄯ"))
		ZmyqQ194hxOk = GVQAnvYCT3dS(MM564HfnUV0XIR(u"ࠫࡩ࡯ࡣࡵࠩᄰ"),xxMqmzh3YOFKHbyCQtUwjL2slZV)
		if ZmyqQ194hxOk:
			s4Bng5iAZQSTtpDw9 = {}
			for u8u3ZiaBy9SIqnPsAV in ZmyqQ194hxOk.keys():
				s4Bng5iAZQSTtpDw9[u8u3ZiaBy9SIqnPsAV] = []
				for H8zngayoSde in ZmyqQ194hxOk[u8u3ZiaBy9SIqnPsAV]:
					Rl48v7kIh3cgF1fzOS6mQ9,TDmqAUj2Mfyir0PvS,pAeIhbuLSFw7j49qxtcg8dDrmKO,sBjdZmqit76bCRPyFLaQ5V1v,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,hfNZTDrYABwyVcJQlqPS48xpHIi7s,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH = ItgK5FqGDz2Rf7mAJkbT(u"ࠬ࠭ᄱ"),MM564HfnUV0XIR(u"࠭ࠧᄲ"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠧࠨᄳ"),WbM6qAjrn7fEXGZw(u"ࠨࠩᄴ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠩࠪᄵ"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠪࠫᄶ"),Kwl07iYTtDLN3zP(u"ࠫࠬᄷ"),Gk98CL5nXZEN(u"ࠬ࠭ᄸ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠭ࠧᄹ")
					Rl48v7kIh3cgF1fzOS6mQ9 = H8zngayoSde[wx18CTJPZ5(u"࠲ᙄ")]
					TDmqAUj2Mfyir0PvS = H8zngayoSde[MM564HfnUV0XIR(u"࠴ᙅ")]
					TDmqAUj2Mfyir0PvS = zVi6a89ZyBcjwfkF(TDmqAUj2Mfyir0PvS)
					pAeIhbuLSFw7j49qxtcg8dDrmKO = H8zngayoSde[I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠶ᙆ")]
					sBjdZmqit76bCRPyFLaQ5V1v = H8zngayoSde[bbqAtUz36RPGVTvCkejpJXQB(u"࠸ᙇ")]
					OHMhVx5cw76slynUDdF24jgbkNG = H8zngayoSde[S26SnaqcM9XwK8PVphJDv5(u"࠺ᙈ")]
					tsMKaFVh1ZN2BIXEcvTejxR5DP = H8zngayoSde[S26SnaqcM9XwK8PVphJDv5(u"࠵ᙉ")]
					if len(H8zngayoSde)>bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠷ᙊ"): hfNZTDrYABwyVcJQlqPS48xpHIi7s = H8zngayoSde[bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠷ᙊ")]
					if len(H8zngayoSde)>tOdiG2HWFRBXg1sUh(u"࠹ᙋ"): HHa1QbqG07ZPXko5fR = H8zngayoSde[tOdiG2HWFRBXg1sUh(u"࠹ᙋ")]
					if len(H8zngayoSde)>SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠻ᙌ"): zSPVUW1XDt2Ba6ZkAH = H8zngayoSde[SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠻ᙌ")]
					if KIFHwWd5396VAiyepGrPNYsck0znB==LkNCuYDaeV576vtyI: gqymln87WJpM95ZO0zDPdBf1 = Rl48v7kIh3cgF1fzOS6mQ9,TDmqAUj2Mfyir0PvS,pAeIhbuLSFw7j49qxtcg8dDrmKO,sBjdZmqit76bCRPyFLaQ5V1v,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,hfNZTDrYABwyVcJQlqPS48xpHIi7s,YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠧࠨᄺ"),zSPVUW1XDt2Ba6ZkAH
					else: gqymln87WJpM95ZO0zDPdBf1 = Rl48v7kIh3cgF1fzOS6mQ9,TDmqAUj2Mfyir0PvS,pAeIhbuLSFw7j49qxtcg8dDrmKO,sBjdZmqit76bCRPyFLaQ5V1v,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,hfNZTDrYABwyVcJQlqPS48xpHIi7s,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH
					s4Bng5iAZQSTtpDw9[u8u3ZiaBy9SIqnPsAV].append(gqymln87WJpM95ZO0zDPdBf1)
		zQLoZxqihtkKVUmnJYEMu4OwI6Cal = str(s4Bng5iAZQSTtpDw9)
		if wvkR1es6d0SrjxKt5FZTMUWz7a: zQLoZxqihtkKVUmnJYEMu4OwI6Cal = zQLoZxqihtkKVUmnJYEMu4OwI6Cal.encode(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠨࡷࡷࡪ࠽࠭ᄻ"))
		open(KIFHwWd5396VAiyepGrPNYsck0znB,bbqAtUz36RPGVTvCkejpJXQB(u"ࠩࡺࡦࠬᄼ")).write(zQLoZxqihtkKVUmnJYEMu4OwI6Cal)
	return s4Bng5iAZQSTtpDw9
def zzPTrDE4vhj2Bl8qFmiyWec(VewOrPR4kX):
	BnjPJuSwWfbve3IYLh8DCt = VewOrPR4kX.split(dEUYJjrhsaPXNo(u"ࠪ࠱ࠬᄽ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠵ᙍ"))[FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠵ᙎ")]
	HmcsWL3qzIatv,jRreTXMs4JNBbt0Y,nROJXLEM6K = NNmirJKPp5nWjfC(u"ࠫࠬᄾ"),ItgK5FqGDz2Rf7mAJkbT(u"ࠬ࠭ᄿ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠭ࠧᅀ")
	if   BnjPJuSwWfbve3IYLh8DCt==NNmirJKPp5nWjfC(u"ࠧࡂࡊ࡚ࡅࡐ࠭ᅁ")		:	from Q9EYujcbqT			import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==qFRrj7ayBKbOsHGSXz(u"ࠨࡃࡎࡓࡆࡓࠧᅂ")		:	from fxd9jQipFC			import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐࠫᅃ")	:	from PFo6yw8eGk		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==qFRrj7ayBKbOsHGSXz(u"ࠪࡅࡐ࡝ࡁࡎࠩᅄ")		:	from JJjPSnbr9G			import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==tOdiG2HWFRBXg1sUh(u"ࠫࡆࡒࡁࡓࡃࡅࠫᅅ")	:	from d2VTKM9FXz			import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==MM564HfnUV0XIR(u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏࠧᅆ")	:	from H1DloyNq5C		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==Gk98CL5nXZEN(u"࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓࠩᅇ")	: 	from v9cAHL6Itd		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==wx18CTJPZ5(u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇࠩᅈ")	:	from UR1hcZsCLr		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==WbM6qAjrn7fEXGZw(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭ᅉ"):	from XlPutyixBV	import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==Gk98CL5nXZEN(u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫᅊ")	:	from AOiTe7sQSc		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==EAw9bg4rT3Bd8tjSkO(u"ࠪࡆࡔࡑࡒࡂࠩᅋ")		:	from OOGxT27leJ			import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==MM564HfnUV0XIR(u"ࠫࡇࡘࡓࡕࡇࡍࠫᅌ")	:	from wtINk5Eb9R			import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==WbM6qAjrn7fEXGZw(u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭ᅍ")	:	from T4yzVo7xcj		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==S26SnaqcM9XwK8PVphJDv5(u"࠭ࡃࡊࡏࡄ࠸࡚࠭ᅎ")	:	from zq4LAwRVK1			import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==Gk98CL5nXZEN(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩᅏ")	:	from fVoSDTZypM		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࡚ࡓࡗࡑࠧᅐ"):	from fn1aeOjp2J	import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==S26SnaqcM9XwK8PVphJDv5(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫᅑ"):		from qF7TNgxJXU		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==bbqAtUz36RPGVTvCkejpJXQB(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔࠬᅒ")	:	from wMuFlHxfKr		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭ᅓ")	:	from rLTs7bRDvl		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==r6juULGQtnExAko38BZ5Y(u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨᅔ")	:	from MQ3pKzOWqD		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==r6juULGQtnExAko38BZ5Y(u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧᅕ")	:	from qqQlJH0SDK		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==GGCQK6OAtZUXRhvkgJm(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬᅖ"):	from p4kPMX2AEO	import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==EAw9bg4rT3Bd8tjSkO(u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩᅗ")	:	from Mr3v146emc		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖࠪᅘ")	:	from M0Iwvgie2s		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬᅙ")	:	from EyjK7UelOR		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==tOdiG2HWFRBXg1sUh(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭ᅚ")	:	from QVwCf5FUju		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==bbqAtUz36RPGVTvCkejpJXQB(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧᅛ")	:	from kD3ofOX7xb		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==wx18CTJPZ5(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴ࠨᅜ")	:	from z75zMfBnES		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==smpniPDOhfwI3H4v7c6TG(u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨᅝ")	:	from dGvsHt378O		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==NxsKJnLFEZ9OHXf1h(u"ࠨࡇࡊ࡝ࡓࡕࡗࠨᅞ")	:	from xbY0T1dei7			import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==dEUYJjrhsaPXNo(u"ࠩࡉࡅࡇࡘࡁࡌࡃࠪᅟ")	:	from PQoCcuxB7j		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==wx18CTJPZ5(u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭ᅠ")	:	from IsuUz5pLN1		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==CIcPowhneWs5tN3(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭ᅡ")	:	from wwu1o5empx		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==Kwl07iYTtDLN3zP(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸ࠧᅢ")	:	from or56Zw7FbD		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==S26SnaqcM9XwK8PVphJDv5(u"࠭ࡆࡐࡕࡗࡅࠬᅣ")		:	from wBQq6lICYj			import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==WbM6qAjrn7fEXGZw(u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩᅤ")	:	from QQE3oVh6qc		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==S26SnaqcM9XwK8PVphJDv5(u"ࠨࡋࡉࡍࡑࡓࠧᅥ")		:	from wwZI3KVCYg			import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==Gk98CL5nXZEN(u"ࠩࡌࡔ࡙࡜ࠧᅦ")		:	from XTA49cQUuV	import EEP8u4SqXOtmnR as HmcsWL3qzIatv,AWOymv5wMZT16cEk9xin as jRreTXMs4JNBbt0Y,E6M5YUL1m4a0JDVtwcdzqovGR as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==tOdiG2HWFRBXg1sUh(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭ᅧ")	:	from uugUkRhyC5		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭ᅨ")	:	from qSD1mfn4Ep		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==FeyZbj8tDil0nSHzTwfsUJ9(u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋࠧᅩ")	:	from PaGwrUkK2f		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==FeyZbj8tDil0nSHzTwfsUJ9(u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭ᅪ")	:	from s2AFN4bBWv			import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨᅫ")	:	from ii7t01MNKq		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠨࡏ࠶࡙ࠬᅬ")		:	from ytYp4ZnKL3	import EEP8u4SqXOtmnR as HmcsWL3qzIatv,AWOymv5wMZT16cEk9xin as jRreTXMs4JNBbt0Y,E6M5YUL1m4a0JDVtwcdzqovGR as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==Gk98CL5nXZEN(u"ࠩࡐࡓ࡛࡙࠴ࡖࠩᅭ")	:	from GuD5gHAba8			import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠪࡑ࡞ࡉࡉࡎࡃࠪᅮ")	:	from s0atThLKQ2			import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠫࡕࡇࡎࡆࡖࠪᅯ")		:	from kogpcfNu7J			import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==S26SnaqcM9XwK8PVphJDv5(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧᅰ")	:	from UBlEgwVT6y		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==Kwl07iYTtDLN3zP(u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪᅱ"):	from Ao76Nzcea0		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==dEUYJjrhsaPXNo(u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇࠪᅲ")	:	from FyYKCMczkr		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==WbM6qAjrn7fEXGZw(u"ࠨࡕࡋࡓࡋࡎࡁࠨᅳ")	:	from v14AE0Bi5Z			import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫᅴ")	:	from c7KQ0lWkAi		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==smpniPDOhfwI3H4v7c6TG(u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓࠬᅵ")	:	from MMivyuf1F0		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==WbM6qAjrn7fEXGZw(u"࡙ࠫ࡜ࡆࡖࡐࠪᅶ")		:	from q278pzF9eZ			import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==r6juULGQtnExAko38BZ5Y(u"ࠬ࡝ࡅࡄࡋࡐࡅࠬᅷ")	:	from CJ2q9lUhtG			import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==CIcPowhneWs5tN3(u"࡙࠭ࡂࡓࡒࡘࠬᅸ")		:	from xxA7UYVTSw			import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==uAl3gHavMJZL4xmNe62nDiBoQ(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨᅹ")	:	from dULi8YwfV6		import Or15mUj4By as HmcsWL3qzIatv,Xwa7vgzTeb3Zy as jRreTXMs4JNBbt0Y,Yc0eBRLpbCkm4gK7OqyzuHwU as nROJXLEM6K
	elif BnjPJuSwWfbve3IYLh8DCt==Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠨ࡛ࡗࡆࡤࡉࡈࡂࡐࡑࡉࡑ࡙ࠧᅺ"):	from esC5MfzSOi	import Or15mUj4By as HmcsWL3qzIatv
	return HmcsWL3qzIatv,jRreTXMs4JNBbt0Y,nROJXLEM6K
def vym8kYdTF2Opjn6wrKa(cu4NGSYJMOstXq7xhg,XzfkYQBICVuSjcL5G0pgy9T16xv,showDialogs):
	y75wQavkVSLUb2MZf9qo(CIcPowhneWs5tN3(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩᅻ"),S26SnaqcM9XwK8PVphJDv5(u"ࠪ࠲ࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪ࠾ࠥࡡࠠࠨᅼ")+cu4NGSYJMOstXq7xhg+cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧᅽ")+str(XzfkYQBICVuSjcL5G0pgy9T16xv)+QmoEjB3hLIw(u"ࠬࠦ࡝ࠨᅾ"))
	ZUNMvsVnGde0mpQxb9ID8aKRkFtJg = ARxKazncryd6Ij2OGtCD5eEihuB8m()
	ZUNMvsVnGde0mpQxb9ID8aKRkFtJg.create(I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᅿ"),Gk98CL5nXZEN(u"๋ࠧฮิ๎ࠥอไร่ࠣๅา฻ࠠศๆ่่ๆࠦวๅ็ฺ่ํฮࠠหฯ่๎้ํ้ࠠส฼ำ์อࠠิ๊ไࠤฯฮฯฤࠢ฼้้๐ษࠡฮ็ฬࠥอไๆๆไࠤ๊์ࠠศๆศ๊ฯืๆหࠩᆀ"))
	lIMQ6Oc8teSXWpnjx7R = FeyZbj8tDil0nSHzTwfsUJ9(u"࠷࠰࠳࠶ᙏ")*FeyZbj8tDil0nSHzTwfsUJ9(u"࠷࠰࠳࠶ᙏ")
	y1UgXQCV3NAEOHfZ7 = r6juULGQtnExAko38BZ5Y(u"࠱ᙐ")*lIMQ6Oc8teSXWpnjx7R
	Il5iAWS8vkNBe4Xf = jR02vwUAu7Xs8mefybaHiJ.get(cu4NGSYJMOstXq7xhg,stream=cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࡔࡳࡷࡨ᜷"),headers=XzfkYQBICVuSjcL5G0pgy9T16xv)
	jHRdhv8tiuTMaOq7WnI1kC0KN = Il5iAWS8vkNBe4Xf.headers
	Il5iAWS8vkNBe4Xf.close()
	Lo7Ce9tg25sA3QfahEWd4z = bytes()
	if not jHRdhv8tiuTMaOq7WnI1kC0KN:
		if showDialogs: tehb3k5a2PufGOdBIUw8j(dEUYJjrhsaPXNo(u"ࠨࠩᆁ"),GGCQK6OAtZUXRhvkgJm(u"ࠩࠪᆂ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᆃ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠫฬ๊ศา่ส้ัࠦไๆࠢํฮ๊้ๆࠡ็้ࠤฯำๅ๋ๆࠣห้๋ไโࠢส่๊฽ไ้สࠣ์ฬ๊ำษสࠣๆิ๊ࠦไ๊้ࠤ฾์ฯไุ่่๊ࠢษࠡใํࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูࠥฮใࠡ࠰ࠣะึฮࠠหฯ่๎้ࠦวๅ็็ๅ๋ࠥัสࠢฦาึ๏ࠧᆄ"))
		ZUNMvsVnGde0mpQxb9ID8aKRkFtJg.close()
	else:
		if cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡌࡦࡰࡪࡸ࡭࠭ᆅ") not in list(jHRdhv8tiuTMaOq7WnI1kC0KN.keys()): VxyUI2K9QJgZ1lfOi4eMTFtbzA = I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠱ᙑ")
		else: VxyUI2K9QJgZ1lfOi4eMTFtbzA = int(jHRdhv8tiuTMaOq7WnI1kC0KN[bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡍࡧࡱ࡫ࡹ࡮ࠧᆆ")])
		RT4tyj3FlcPEI5UvGw = str(int(Gk98CL5nXZEN(u"࠴࠴࠵࠶ᙓ")*VxyUI2K9QJgZ1lfOi4eMTFtbzA/lIMQ6Oc8teSXWpnjx7R)/SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠳࠳࠴࠵࠴࠰ᙒ"))
		t9nULlEcz8dJCT1vk5 = int(VxyUI2K9QJgZ1lfOi4eMTFtbzA/y1UgXQCV3NAEOHfZ7)+Kwl07iYTtDLN3zP(u"࠵ᙔ")
		if smpniPDOhfwI3H4v7c6TG(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡔࡤࡲ࡬࡫ࠧᆇ") in list(jHRdhv8tiuTMaOq7WnI1kC0KN.keys()) and VxyUI2K9QJgZ1lfOi4eMTFtbzA>lIMQ6Oc8teSXWpnjx7R:
			UU6yrRjHPAeN = Gk98CL5nXZEN(u"ࡕࡴࡸࡩ᜸")
			MaUs3wNd9TvVXZD2EBSxkQjCgimqh = []
			FFmcHDZIpPt = S26SnaqcM9XwK8PVphJDv5(u"࠶࠶ᙕ")
			MaUs3wNd9TvVXZD2EBSxkQjCgimqh.append(str(MM564HfnUV0XIR(u"࠰ᙗ")*VxyUI2K9QJgZ1lfOi4eMTFtbzA//FFmcHDZIpPt)+EAw9bg4rT3Bd8tjSkO(u"ࠨ࠯ࠪᆈ")+str(NNmirJKPp5nWjfC(u"࠷ᙖ")*VxyUI2K9QJgZ1lfOi4eMTFtbzA//FFmcHDZIpPt-NNmirJKPp5nWjfC(u"࠷ᙖ")))
			MaUs3wNd9TvVXZD2EBSxkQjCgimqh.append(str(Ox8k6IdtuPaG3NlApQK52oYwM(u"࠲ᙘ")*VxyUI2K9QJgZ1lfOi4eMTFtbzA//FFmcHDZIpPt)+CIcPowhneWs5tN3(u"ࠩ࠰ࠫᆉ")+str(bbqAtUz36RPGVTvCkejpJXQB(u"࠴ᙙ")*VxyUI2K9QJgZ1lfOi4eMTFtbzA//FFmcHDZIpPt-Ox8k6IdtuPaG3NlApQK52oYwM(u"࠲ᙘ")))
			MaUs3wNd9TvVXZD2EBSxkQjCgimqh.append(str(ta478EuZQJIWhgBnsf6iU(u"࠷ᙜ")*VxyUI2K9QJgZ1lfOi4eMTFtbzA//FFmcHDZIpPt)+NNmirJKPp5nWjfC(u"ࠪ࠱ࠬᆊ")+str(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠷ᙛ")*VxyUI2K9QJgZ1lfOi4eMTFtbzA//FFmcHDZIpPt-I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠴ᙚ")))
			MaUs3wNd9TvVXZD2EBSxkQjCgimqh.append(str(dEUYJjrhsaPXNo(u"࠳ᙞ")*VxyUI2K9QJgZ1lfOi4eMTFtbzA//FFmcHDZIpPt)+WbM6qAjrn7fEXGZw(u"ࠫ࠲࠭ᆋ")+str(NxsKJnLFEZ9OHXf1h(u"࠵ᙟ")*VxyUI2K9QJgZ1lfOi4eMTFtbzA//FFmcHDZIpPt-GGCQK6OAtZUXRhvkgJm(u"࠷ᙝ")))
			MaUs3wNd9TvVXZD2EBSxkQjCgimqh.append(str(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠸ᙢ")*VxyUI2K9QJgZ1lfOi4eMTFtbzA//FFmcHDZIpPt)+ItgK5FqGDz2Rf7mAJkbT(u"ࠬ࠳ࠧᆌ")+str(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠸ᙡ")*VxyUI2K9QJgZ1lfOi4eMTFtbzA//FFmcHDZIpPt-dEUYJjrhsaPXNo(u"࠳ᙠ")))
			MaUs3wNd9TvVXZD2EBSxkQjCgimqh.append(str(Ox8k6IdtuPaG3NlApQK52oYwM(u"࠻ᙤ")*VxyUI2K9QJgZ1lfOi4eMTFtbzA//FFmcHDZIpPt)+tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠭࠭ࠨᆍ")+str(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠶ᙥ")*VxyUI2K9QJgZ1lfOi4eMTFtbzA//FFmcHDZIpPt-MM564HfnUV0XIR(u"࠶ᙣ")))
			MaUs3wNd9TvVXZD2EBSxkQjCgimqh.append(str(I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠹ᙨ")*VxyUI2K9QJgZ1lfOi4eMTFtbzA//FFmcHDZIpPt)+tOdiG2HWFRBXg1sUh(u"ࠧ࠮ࠩᆎ")+str(QmoEjB3hLIw(u"࠹ᙧ")*VxyUI2K9QJgZ1lfOi4eMTFtbzA//FFmcHDZIpPt-Kwl07iYTtDLN3zP(u"࠲ᙦ")))
			MaUs3wNd9TvVXZD2EBSxkQjCgimqh.append(str(NxsKJnLFEZ9OHXf1h(u"࠽ᙫ")*VxyUI2K9QJgZ1lfOi4eMTFtbzA//FFmcHDZIpPt)+r6juULGQtnExAko38BZ5Y(u"ࠨ࠯ࠪᆏ")+str(I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠽ᙪ")*VxyUI2K9QJgZ1lfOi4eMTFtbzA//FFmcHDZIpPt-EAw9bg4rT3Bd8tjSkO(u"࠵ᙩ")))
			MaUs3wNd9TvVXZD2EBSxkQjCgimqh.append(str(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠹᙭")*VxyUI2K9QJgZ1lfOi4eMTFtbzA//FFmcHDZIpPt)+Gk98CL5nXZEN(u"ࠩ࠰ࠫᆐ")+str(ta478EuZQJIWhgBnsf6iU(u"࠹ᙬ")*VxyUI2K9QJgZ1lfOi4eMTFtbzA//FFmcHDZIpPt-smpniPDOhfwI3H4v7c6TG(u"࠳᙮")))
			MaUs3wNd9TvVXZD2EBSxkQjCgimqh.append(str(Ox8k6IdtuPaG3NlApQK52oYwM(u"࠼ᙯ")*VxyUI2K9QJgZ1lfOi4eMTFtbzA//FFmcHDZIpPt)+ta478EuZQJIWhgBnsf6iU(u"ࠪ࠱ࠬᆑ"))
			QMkeURzWKXFZgv = float(t9nULlEcz8dJCT1vk5)/FFmcHDZIpPt
			F0nQXy5qRwplc2HBCUeTzhSagtf = QMkeURzWKXFZgv/int(WbM6qAjrn7fEXGZw(u"࠵ᙰ")+QMkeURzWKXFZgv)
		else:
			UU6yrRjHPAeN = qFRrj7ayBKbOsHGSXz(u"ࡈࡤࡰࡸ࡫᜹")
			FFmcHDZIpPt = MM564HfnUV0XIR(u"࠶ᙱ")
			F0nQXy5qRwplc2HBCUeTzhSagtf = Gk98CL5nXZEN(u"࠷ᙲ")
		y75wQavkVSLUb2MZf9qo(Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠫࡓࡕࡔࡊࡅࡈࠫᆒ"),MM564HfnUV0XIR(u"ࠬ࠴ࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡹࡸ࡯࡮ࡨࠢࡵࡥࡳ࡭ࡥࡴ࠼ࠣ࡟ࠥ࠭ᆓ")+str(UU6yrRjHPAeN)+zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠭ࠠ࡞ࠢࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨᆔ")+str(VxyUI2K9QJgZ1lfOi4eMTFtbzA)+FeyZbj8tDil0nSHzTwfsUJ9(u"ࠧࠡ࡟ࠪᆕ"))
		Deiz7ocWQjVnIg,CWEcSUnwxXqLy25 = FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠰ᙳ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠰ᙳ")
		for loAFL391p7qDWU8mTed0PgJ in range(FFmcHDZIpPt):
			TC7fWv2a1gLJGiAtN8 = XzfkYQBICVuSjcL5G0pgy9T16xv.copy()
			if UU6yrRjHPAeN: TC7fWv2a1gLJGiAtN8[zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠨࡔࡤࡲ࡬࡫ࠧᆖ")] = WbM6qAjrn7fEXGZw(u"ࠩࡥࡽࡹ࡫ࡳ࠾ࠩᆗ")+MaUs3wNd9TvVXZD2EBSxkQjCgimqh[loAFL391p7qDWU8mTed0PgJ]
			Il5iAWS8vkNBe4Xf = jR02vwUAu7Xs8mefybaHiJ.get(cu4NGSYJMOstXq7xhg,stream=ta478EuZQJIWhgBnsf6iU(u"ࡗࡶࡺ࡫᜺"),headers=TC7fWv2a1gLJGiAtN8,timeout=tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠴࠲࠳ᙴ"))
			for O60JVvEgRkfhHY7C in Il5iAWS8vkNBe4Xf.iter_content(chunk_size=y1UgXQCV3NAEOHfZ7):
				if ZUNMvsVnGde0mpQxb9ID8aKRkFtJg.iscanceled():
					y75wQavkVSLUb2MZf9qo(tOdiG2HWFRBXg1sUh(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪᆘ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠫ࠳ࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡆࡥࡳࡩࡥ࡭ࡧࡧࠫᆙ"))
					break
				Deiz7ocWQjVnIg += F0nQXy5qRwplc2HBCUeTzhSagtf
				Lo7Ce9tg25sA3QfahEWd4z += O60JVvEgRkfhHY7C
				if not CWEcSUnwxXqLy25: CWEcSUnwxXqLy25 = len(O60JVvEgRkfhHY7C)
				if VxyUI2K9QJgZ1lfOi4eMTFtbzA: aayBzF9OcXn1kYqRhDNm7gTZ(ZUNMvsVnGde0mpQxb9ID8aKRkFtJg,Gk98CL5nXZEN(u"࠳࠳࠴ᙵ")*Deiz7ocWQjVnIg//t9nULlEcz8dJCT1vk5,zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠬาไษࠢส่๊๊แ࠻࠯ࠣห้าายࠢิๆ๊࠭ᆚ"),str(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠴࠴࠵࠴࠰ᙶ")*CWEcSUnwxXqLy25*Deiz7ocWQjVnIg//y1UgXQCV3NAEOHfZ7//YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠴࠴࠵࠴࠰ᙶ"))+zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠭ࠠ࠰ࠢࠪᆛ")+RT4tyj3FlcPEI5UvGw+tOdiG2HWFRBXg1sUh(u"ࠧࠡࡏࡅࠫᆜ"))
				else: aayBzF9OcXn1kYqRhDNm7gTZ(ZUNMvsVnGde0mpQxb9ID8aKRkFtJg,CWEcSUnwxXqLy25*Deiz7ocWQjVnIg//y1UgXQCV3NAEOHfZ7,NNmirJKPp5nWjfC(u"ࠨฮ็ฬࠥอไๆๆไ࠾࠲࠭ᆝ"),str(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠵࠵࠶࠮࠱ᙷ")*CWEcSUnwxXqLy25*Deiz7ocWQjVnIg//y1UgXQCV3NAEOHfZ7//FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠵࠵࠶࠮࠱ᙷ"))+r6juULGQtnExAko38BZ5Y(u"ࠩࠣࡑࡇ࠭ᆞ"))
			Il5iAWS8vkNBe4Xf.close()
		ZUNMvsVnGde0mpQxb9ID8aKRkFtJg.close()
		if len(Lo7Ce9tg25sA3QfahEWd4z)<VxyUI2K9QJgZ1lfOi4eMTFtbzA and VxyUI2K9QJgZ1lfOi4eMTFtbzA>WbM6qAjrn7fEXGZw(u"࠵ᙸ"):
			y75wQavkVSLUb2MZf9qo(r6juULGQtnExAko38BZ5Y(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪᆟ"),S26SnaqcM9XwK8PVphJDv5(u"ࠫ࠳ࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡩࡥ࡮ࡲࡥࡥࠢࡲࡶࠥࡩࡡ࡯ࡥࡨࡰࡪࡪࠠࡢࡶ࠽ࠤࡠࠦࠧᆠ")+str(len(Lo7Ce9tg25sA3QfahEWd4z)//lIMQ6Oc8teSXWpnjx7R)+ItgK5FqGDz2Rf7mAJkbT(u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡳࡱࡰࠤࡹࡵࡴࡢ࡮ࠣࡳ࡫ࡀࠠ࡜ࠢࠪᆡ")+RT4tyj3FlcPEI5UvGw+cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠭ࠠࡎࡄࠣࡡࠬᆢ"))
			JJ94bQazqrY1wS = m5NUYqBzGynIOeAg8(EAw9bg4rT3Bd8tjSkO(u"ࠧࠨᆣ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠨว็฾ฬว้ࠠะิ์ั࠭ᆤ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠩสืฯิฯศ็ࠣห้๋ไโࠢส่๋อโึࠩᆥ"),S26SnaqcM9XwK8PVphJDv5(u"ࠪษ฾อฯสࠢฯ่อࠦวๅ็็ๅࠬᆦ"),Kwl07iYTtDLN3zP(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᆧ"),Gk98CL5nXZEN(u"ࠬ็ิๅࠢไ๎ࠥาไษࠢส่๊๊แࠡ࡞ࡱࠤ้๊ริใࠣัิัࠠฯูฦࠤๆ๐ࠠหฯ่๎้ࠦวๅ็็ๅࠥࡢ࡮ࠡฬ่ࠤั๊ศࠡࠩᆨ")+str(len(Lo7Ce9tg25sA3QfahEWd4z)//lIMQ6Oc8teSXWpnjx7R)+tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠭ࠠๆ์฽หออ๊ห่๊๋ࠢࠥฬๆ๊฼ࠤࠬᆩ")+RT4tyj3FlcPEI5UvGw+Kwl07iYTtDLN3zP(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣࡠࡳࠦฬาสࠣะ้ฮࠠศๆ่่ๆࠦๅาหࠣวำื้ࠡ࡞ࡱࠤ์๊ࠠหำํำࠥอำหะาห๊ࠦวๅ็็ๅࠥอไ็ษๅูࠥลࠡࠢࠩᆪ"))
			if JJ94bQazqrY1wS==wx18CTJPZ5(u"࠸ᙹ"): Lo7Ce9tg25sA3QfahEWd4z = vym8kYdTF2Opjn6wrKa(cu4NGSYJMOstXq7xhg,XzfkYQBICVuSjcL5G0pgy9T16xv,showDialogs)
			elif JJ94bQazqrY1wS==I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠱ᙺ"): y75wQavkVSLUb2MZf9qo(EAw9bg4rT3Bd8tjSkO(u"ࠨࡐࡒࡘࡎࡉࡅࠨᆫ"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠩ࠱ࠤࠥࡔ࡯ࡵࠢࡦࡳࡲࡶ࡬ࡦࡶࡨࡨࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡥࡥࠢࡩ࡭ࡱ࡫ࠠࡪࡵࠣࡥࡨࡩࡥࡱࡶࡨࡨࠥࡧ࡮ࡥࠢࡺ࡭ࡱࡲࠠࡣࡧࠣࡹࡸ࡫ࡤࠨᆬ"))
			else: return wx18CTJPZ5(u"ࠪࠫᆭ")
			if not Lo7Ce9tg25sA3QfahEWd4z: return ItgK5FqGDz2Rf7mAJkbT(u"ࠫࠬᆮ")
		else: y75wQavkVSLUb2MZf9qo(NNmirJKPp5nWjfC(u"ࠬࡔࡏࡕࡋࡆࡉࠬᆯ"),EAw9bg4rT3Bd8tjSkO(u"࠭࠮ࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡘࡻࡣࡤࡧࡨࡨࡪࡪ࠮ࠡࠢࠣࡊ࡮ࡲࡥࠡࡕ࡬ࡾࡪࡀࠠ࡜ࠢࠪᆰ")+RT4tyj3FlcPEI5UvGw+WbM6qAjrn7fEXGZw(u"ࠧࠡࡏࡅࠤࡢ࠭ᆱ"))
	return Lo7Ce9tg25sA3QfahEWd4z
def ccbdV5hfM8toKa6wO3WQeIJX(r1NChsk39OMvT82YemDQnl5):
	return Il5iAWS8vkNBe4Xf
def E8NciTDyFBuIm(ip=dEUYJjrhsaPXNo(u"ࠨࠩᆲ")):
	uSWzaMHkNwAeopVFsjEr9Q7d5OxBLt,ir0ULhG6nfRXJHkpAgbF,NqS9Jws84ogpy,QtXr5IwNbfy8V,LOzXZgJVj4q8,qRmeMfvtzA = Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠩࠪᆳ"),wx18CTJPZ5(u"ࠪࠫᆴ"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠫࠬᆵ"),CgPbwXm1RilpJUSGHLhy(u"ࠬ࠭ᆶ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠭ࠧᆷ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠧࠨᆸ")
	pAeIhbuLSFw7j49qxtcg8dDrmKO = tOdiG2HWFRBXg1sUh(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡫ࡳࡻ࡭ࡵ࠮ࡪࡵ࠲ࠫᆹ")+ip+FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠩࡂࡳࡺࡺࡰࡶࡶࡀ࡮ࡸࡵ࡮ࠧࡨ࡬ࡩࡱࡪࡳ࠾࡫ࡳ࠰ࡨࡵ࡮ࡵ࡫ࡱࡩࡳࡺࠬࡤࡱࡸࡲࡹࡸࡹ࠭ࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫ࠬࡳࡧࡪ࡭ࡴࡴࠬࡤ࡫ࡷࡽ࠱ࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧᆺ")
	XzfkYQBICVuSjcL5G0pgy9T16xv = {dEUYJjrhsaPXNo(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᆻ"):Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠫࠬᆼ")}
	Il5iAWS8vkNBe4Xf = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,smpniPDOhfwI3H4v7c6TG(u"ࠬࡍࡅࡕࠩᆽ"),pAeIhbuLSFw7j49qxtcg8dDrmKO,YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠭ࠧᆾ"),XzfkYQBICVuSjcL5G0pgy9T16xv,ta478EuZQJIWhgBnsf6iU(u"ࠧࠨᆿ"),S26SnaqcM9XwK8PVphJDv5(u"ࠨࠩᇀ"),EAw9bg4rT3Bd8tjSkO(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊࡕࡌࡐࡅࡄࡘࡎࡕࡎ࠮࠳ࡶࡸࠬᇁ"))
	if not Il5iAWS8vkNBe4Xf.succeeded: he9GovI4XHNf = ip+tOdiG2HWFRBXg1sUh(u"ࠪ࠰ࠬᇂ")+uSWzaMHkNwAeopVFsjEr9Q7d5OxBLt+WbM6qAjrn7fEXGZw(u"ࠫ࠱࠭ᇃ")+ir0ULhG6nfRXJHkpAgbF+bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠬ࠲ࠧᇄ")+QtXr5IwNbfy8V+FeyZbj8tDil0nSHzTwfsUJ9(u"࠭ࠬࠨᇅ")+LOzXZgJVj4q8+Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠧ࠭ࠩᇆ")+qRmeMfvtzA
	else:
		TcPFsujHEQG3vBwCt = Il5iAWS8vkNBe4Xf.content
		TcPFsujHEQG3vBwCt = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(CIcPowhneWs5tN3(u"ࠨ࡞ࡾ࠲࠯ࡅ࡜ࡾ࡞ࢀࠫᇇ"),TcPFsujHEQG3vBwCt,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TcPFsujHEQG3vBwCt:
			TcPFsujHEQG3vBwCt = TcPFsujHEQG3vBwCt[r6juULGQtnExAko38BZ5Y(u"࠱ᙻ")]
			TTNqxouBzXcwHQAIhUYysWZO1nj = GVQAnvYCT3dS(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠩࡧ࡭ࡨࡺࠧᇈ"),TcPFsujHEQG3vBwCt)
			ihwYS7MBcDXU = list(TTNqxouBzXcwHQAIhUYysWZO1nj.keys())
			if dEUYJjrhsaPXNo(u"ࠪ࡭ࡵ࠭ᇉ") in ihwYS7MBcDXU: ip = TTNqxouBzXcwHQAIhUYysWZO1nj[NxsKJnLFEZ9OHXf1h(u"ࠫ࡮ࡶࠧᇊ")]
			if dEUYJjrhsaPXNo(u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴࠨᇋ") in ihwYS7MBcDXU: uSWzaMHkNwAeopVFsjEr9Q7d5OxBLt = TTNqxouBzXcwHQAIhUYysWZO1nj[YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠭ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵࠩᇌ")]
			if S26SnaqcM9XwK8PVphJDv5(u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨᇍ") in ihwYS7MBcDXU: ir0ULhG6nfRXJHkpAgbF = TTNqxouBzXcwHQAIhUYysWZO1nj[I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩᇎ")]
			if I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠩࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥࠨᇏ") in ihwYS7MBcDXU: NqS9Jws84ogpy = TTNqxouBzXcwHQAIhUYysWZO1nj[MM564HfnUV0XIR(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦࠩᇐ")]
			if WbM6qAjrn7fEXGZw(u"ࠫࡷ࡫ࡧࡪࡱࡱࠫᇑ") in ihwYS7MBcDXU: QtXr5IwNbfy8V = TTNqxouBzXcwHQAIhUYysWZO1nj[NxsKJnLFEZ9OHXf1h(u"ࠬࡸࡥࡨ࡫ࡲࡲࠬᇒ")]
			if r6juULGQtnExAko38BZ5Y(u"࠭ࡣࡪࡶࡼࠫᇓ") in ihwYS7MBcDXU: LOzXZgJVj4q8 = TTNqxouBzXcwHQAIhUYysWZO1nj[EAw9bg4rT3Bd8tjSkO(u"ࠧࡤ࡫ࡷࡽࠬᇔ")]
			if dEUYJjrhsaPXNo(u"ࠨࡶ࡬ࡱࡪࢀ࡯࡯ࡧࠪᇕ") in ihwYS7MBcDXU:
				qRmeMfvtzA = TTNqxouBzXcwHQAIhUYysWZO1nj[dEUYJjrhsaPXNo(u"ࠩࡷ࡭ࡲ࡫ࡺࡰࡰࡨࠫᇖ")][smpniPDOhfwI3H4v7c6TG(u"ࠪࡹࡹࡩࠧᇗ")]
				if qRmeMfvtzA[Gk98CL5nXZEN(u"࠲ᙼ")] not in [FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠫ࠲࠭ᇘ"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠬ࠱ࠧᇙ")]: qRmeMfvtzA = cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠭ࠫࠨᇚ")+qRmeMfvtzA
			he9GovI4XHNf = ip+tOdiG2HWFRBXg1sUh(u"ࠧ࠭ࠩᇛ")+uSWzaMHkNwAeopVFsjEr9Q7d5OxBLt+FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠨ࠮ࠪᇜ")+ir0ULhG6nfRXJHkpAgbF+FeyZbj8tDil0nSHzTwfsUJ9(u"ࠩ࠯ࠫᇝ")+QtXr5IwNbfy8V+CIcPowhneWs5tN3(u"ࠪ࠰ࠬᇞ")+LOzXZgJVj4q8+qFRrj7ayBKbOsHGSXz(u"ࠫ࠱࠭ᇟ")+qRmeMfvtzA
			if wvkR1es6d0SrjxKt5FZTMUWz7a: he9GovI4XHNf = he9GovI4XHNf.encode(r6juULGQtnExAko38BZ5Y(u"ࠬࡻࡴࡧ࠺ࠪᇠ")).decode(CIcPowhneWs5tN3(u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧᇡ"))
	he9GovI4XHNf = zKGXT5sJeRq(he9GovI4XHNf)
	return he9GovI4XHNf
def Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(vVQJ95C4PxAynwLdzYSkZ6alc1G):
	q94aE5feCPnoOHW,showDialogs = NxsKJnLFEZ9OHXf1h(u"ࠧࠨᇢ"),Kwl07iYTtDLN3zP(u"ࡘࡷࡻࡥ᜻")
	if vVQJ95C4PxAynwLdzYSkZ6alc1G.count(MM564HfnUV0XIR(u"ࠨࡡࠪᇣ"))>=Gk98CL5nXZEN(u"࠵ᙽ"):
		vVQJ95C4PxAynwLdzYSkZ6alc1G,q94aE5feCPnoOHW = vVQJ95C4PxAynwLdzYSkZ6alc1G.split(ta478EuZQJIWhgBnsf6iU(u"ࠩࡢࠫᇤ"),tOdiG2HWFRBXg1sUh(u"࠵ᙾ"))
		q94aE5feCPnoOHW = dEUYJjrhsaPXNo(u"ࠪࡣࠬᇥ")+q94aE5feCPnoOHW
		if wx18CTJPZ5(u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩᇦ") in q94aE5feCPnoOHW: showDialogs = YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࡋࡧ࡬ࡴࡧ᜼")
		else: showDialogs = Gk98CL5nXZEN(u"࡚ࡲࡶࡧ᜽")
	return vVQJ95C4PxAynwLdzYSkZ6alc1G,q94aE5feCPnoOHW,showDialogs
def zzmlkvSWEbVijTJy():
	tmYNEwjFyAIa6MblD8dTvU9hi7zCKg = K3hFytImeYMkJBC.path.join(U0AdbxBVqaQOwTJIcSgN1z9iM7r,tOdiG2HWFRBXg1sUh(u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫᇧ"))
	csz2tAlr5vL48YSZJH1piqhP = YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠵ᙿ")
	if K3hFytImeYMkJBC.path.exists(tmYNEwjFyAIa6MblD8dTvU9hi7zCKg):
		for dkL0Qy5ZolhseOuCRKMrABV8Uzp in K3hFytImeYMkJBC.listdir(tmYNEwjFyAIa6MblD8dTvU9hi7zCKg):
			if r6juULGQtnExAko38BZ5Y(u"࠭࠮ࡱࡻࡲࠫᇨ") in dkL0Qy5ZolhseOuCRKMrABV8Uzp: continue
			if FeyZbj8tDil0nSHzTwfsUJ9(u"ࠧࡠࡡࡳࡽࡨࡧࡣࡩࡧࡢࡣࠬᇩ") in dkL0Qy5ZolhseOuCRKMrABV8Uzp: continue
			RIWv8gqFNC36frUHQuM = K3hFytImeYMkJBC.path.join(tmYNEwjFyAIa6MblD8dTvU9hi7zCKg,dkL0Qy5ZolhseOuCRKMrABV8Uzp)
			eQwMcWNSyixhHtmoVG64A8JrTjDqRs,GG5hd4btHaJZ6uYWiXEoPFU3Of = Jy1ZPox93TVNYnKLzHvka(RIWv8gqFNC36frUHQuM)
			csz2tAlr5vL48YSZJH1piqhP += eQwMcWNSyixhHtmoVG64A8JrTjDqRs
	return csz2tAlr5vL48YSZJH1piqhP
def qmcQKkuhliSZRJUC(nHKoSC1PiDe8RFambXd7wGf,showDialogs):
	oIUDVRbpZM5GwK6zcJX89gkd = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(smpniPDOhfwI3H4v7c6TG(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭ᇪ"))
	Am9QqDJ0xeIPd = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠩࡶࡸࡷ࠭ᇫ"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ᇬ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭ᇭ"))
	MBEmczVbLDr91esQ3toTJOZAw8hp,Qvf8cFOlIbm0Np4U = oIUDVRbpZM5GwK6zcJX89gkd,Am9QqDJ0xeIPd
	tBbU6e5z18DucTh,noAlvUC5rLtg = dEUYJjrhsaPXNo(u"ࠬ࠭ᇮ"),CgPbwXm1RilpJUSGHLhy(u"࠭ࠧᇯ")
	if not nHKoSC1PiDe8RFambXd7wGf or not Am9QqDJ0xeIPd or oIUDVRbpZM5GwK6zcJX89gkd in [Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠧࠨᇰ"),wx18CTJPZ5(u"ࠨࡇࡕࡖࡔࡘࠧᇱ")]:
		pAeIhbuLSFw7j49qxtcg8dDrmKO = mR20sONyKIlV[GGCQK6OAtZUXRhvkgJm(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩᇲ")][zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠹ ")]
		gg6VwuY0xOi7 = zVw5tvmZRX(dEUYJjrhsaPXNo(u"࠳࠳ᚁ"),nHKoSC1PiDe8RFambXd7wGf)
		he9GovI4XHNf = E8NciTDyFBuIm()
		ir0ULhG6nfRXJHkpAgbF = he9GovI4XHNf.split(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠪ࠰ࠬᇳ"))[bbqAtUz36RPGVTvCkejpJXQB(u"࠳ᚂ")]
		csz2tAlr5vL48YSZJH1piqhP = zzmlkvSWEbVijTJy()
		A2UWHt59mrMSJdpXNb63hRxq = {smpniPDOhfwI3H4v7c6TG(u"ࠫࡺࡹࡥࡳࠩᇴ"):gg6VwuY0xOi7,I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭ᇵ"):VnhK9wvHBGuo1fei8DXQ02yFZtsWE,NNmirJKPp5nWjfC(u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧᇶ"):ir0ULhG6nfRXJHkpAgbF,GGCQK6OAtZUXRhvkgJm(u"ࠧࡪࡦࡶࠫᇷ"):NfjyEgxeHGwpbu7QK3O1D(csz2tAlr5vL48YSZJH1piqhP)}
		Il5iAWS8vkNBe4Xf = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,ItgK5FqGDz2Rf7mAJkbT(u"ࠨࡒࡒࡗ࡙࠭ᇸ"),pAeIhbuLSFw7j49qxtcg8dDrmKO,A2UWHt59mrMSJdpXNb63hRxq,FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠩࠪᇹ"),GGCQK6OAtZUXRhvkgJm(u"ࠪࠫᇺ"),WbM6qAjrn7fEXGZw(u"ࠫࠬᇻ"),qFRrj7ayBKbOsHGSXz(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡑࡊ࡙ࡓࡂࡉࡈࡗ࠲࠷ࡳࡵࠩᇼ"))
		if not Il5iAWS8vkNBe4Xf.succeeded: MBEmczVbLDr91esQ3toTJOZAw8hp = S26SnaqcM9XwK8PVphJDv5(u"࠭ࡅࡓࡔࡒࡖࠬᇽ")
		else:
			iiDFCqAsGhyv3gctx = Il5iAWS8vkNBe4Xf.content
			iiDFCqAsGhyv3gctx = GVQAnvYCT3dS(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠧ࡭࡫ࡶࡸࠬᇾ"),iiDFCqAsGhyv3gctx)
			iiDFCqAsGhyv3gctx = sorted(iiDFCqAsGhyv3gctx,reverse=qFRrj7ayBKbOsHGSXz(u"ࡔࡳࡷࡨ᜾"),key=lambda key: int(key[YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠲ᚃ")]))
			noAlvUC5rLtg,Qvf8cFOlIbm0Np4U = S26SnaqcM9XwK8PVphJDv5(u"ࠨࠩᇿ"),Gk98CL5nXZEN(u"ࠩࠪሀ")
			for grQvaCNWz1nsD2,xFS6tHwBXz,EiMsPpS3O1Ba in iiDFCqAsGhyv3gctx:
				if grQvaCNWz1nsD2==uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠪ࠴ࠬሁ"):
					noAlvUC5rLtg += EiMsPpS3O1Ba+Kwl07iYTtDLN3zP(u"ࠫ࠿ࡀࠧሂ")
					continue
				if Qvf8cFOlIbm0Np4U: Qvf8cFOlIbm0Np4U += ta478EuZQJIWhgBnsf6iU(u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࡠࡳ࠭ሃ")
				ykdrsNlHw48CajgMiWc0YSuvXB2UTz = EiMsPpS3O1Ba.split(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠭࡜࡯ࠩሄ"))[GGCQK6OAtZUXRhvkgJm(u"࠳ᚄ")]
				obOAneMB9Xw4HKcaNEipqt = ItgK5FqGDz2Rf7mAJkbT(u"ࠧาีส่ฮࠦฮศืฬࠤ้้ࠠโไฺࠫህ") if xFS6tHwBXz else QmoEjB3hLIw(u"ࠨࠩሆ")
				Qvf8cFOlIbm0Np4U += EiMsPpS3O1Ba.replace(ykdrsNlHw48CajgMiWc0YSuvXB2UTz,uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬሇ")+ykdrsNlHw48CajgMiWc0YSuvXB2UTz+obOAneMB9Xw4HKcaNEipqt+cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬለ"))+cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠫࡡࡴࠧሉ")
			Qvf8cFOlIbm0Np4U = wx18CTJPZ5(u"ࠬࡢ࡮ࠨሊ")+Qvf8cFOlIbm0Np4U+uAl3gHavMJZL4xmNe62nDiBoQ(u"࠭࡜࡯࡞ࡱࠫላ")
			noAlvUC5rLtg = noAlvUC5rLtg.strip(I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠧ࠻࠼ࠪሌ"))
			tBbU6e5z18DucTh = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠨࡣࡹ࠲ࡵࡸࡩࡷࡵࠪል"))
			if Qvf8cFOlIbm0Np4U!=Am9QqDJ0xeIPd or oIUDVRbpZM5GwK6zcJX89gkd in [tOdiG2HWFRBXg1sUh(u"ࠩࠪሎ"),qFRrj7ayBKbOsHGSXz(u"ࠪࡉࡗࡘࡏࡓࠩሏ")]: MBEmczVbLDr91esQ3toTJOZAw8hp = MM564HfnUV0XIR(u"ࠫࡓࡋࡗࠨሐ")
			kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨሑ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨሒ"),Qvf8cFOlIbm0Np4U,D0vjfyxKZuP7pXknq62MwFYU)
			if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(ItgK5FqGDz2Rf7mAJkbT(u"ࠧࡢࡸ࠱ࡴࡷ࡯ࡶࡴࠩሓ"),noAlvUC5rLtg)
			if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(Gk98CL5nXZEN(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩሔ"),NfjyEgxeHGwpbu7QK3O1D(eOYicX68ruMjpN0dKtWP5QTSE))
	if showDialogs:
		if MBEmczVbLDr91esQ3toTJOZAw8hp==FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠩࡈࡖࡗࡕࡒࠨሕ"):
			tehb3k5a2PufGOdBIUw8j(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠪࠫሖ"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠫࠬሗ"),S26SnaqcM9XwK8PVphJDv5(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨመ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠭็็ษๆࠤฺ๊ใๅหࠣๅ๏ࠦฬ่ษี็ࠥ๎็๋ࠢ็๎ุะࠠๆ่ࠣห้ฮั็ษ่ะࠥ࠴࠮้ࠡำ๋ࠥอไๆึๆ่ฮࠦโะࠢํ็ํ์ࠠิสห๋ฬࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅࠣวํࠦวๅำส์ฯืࠠศๆัหฺࠦศไࠢฦ์๋ࠥิไๆฬࠤๆ๐ࠠศๆฦื้อใࠡ฻้ำ่࠭ሙ"))
		else:
			Dkp5YTLQijOEKF(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ሚ"),EAw9bg4rT3Bd8tjSkO(u"ࠨำึหห๊ࠠๆ่ࠣห้๋ศา็ฯࠤส๊้ࠡ็ึฮำีๅ๋ࠢส่อืๆศ็ฯࠫማ"),Qvf8cFOlIbm0Np4U,Gk98CL5nXZEN(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪሜ"))
			MBEmczVbLDr91esQ3toTJOZAw8hp = dEUYJjrhsaPXNo(u"ࠪࡓࡑࡊࠧም")
	if MBEmczVbLDr91esQ3toTJOZAw8hp!=oIUDVRbpZM5GwK6zcJX89gkd:
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩሞ"),MBEmczVbLDr91esQ3toTJOZAw8hp)
		oos8ymFi9CN2z1jXcR.executebuiltin(dEUYJjrhsaPXNo(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩሟ"))
	jIAuMSaQXw5o46 = I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࡖࡵࡹࡪᝀ") if noAlvUC5rLtg!=tBbU6e5z18DucTh else zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࡇࡣ࡯ࡷࡪ᜿")
	return jIAuMSaQXw5o46
def WKFu3v5hQIdXNp1Bg0ZxRLk2G(IIOrTgqjuxv,s7ECqbiagkSBKfPLYOMpFxo):
	from socket import socket as UnVKvhfHwd6pYx37Wk,AF_INET as c7kgPIzjmT,SOCK_STREAM as b0jWpJLRsD4omGnBXefT38yM
	tgBAOHox9r8NFYbfXwzUcpueJiMD = UnVKvhfHwd6pYx37Wk(c7kgPIzjmT,b0jWpJLRsD4omGnBXefT38yM)
	tgBAOHox9r8NFYbfXwzUcpueJiMD.settimeout(dEUYJjrhsaPXNo(u"࠵ᚅ"))
	vhYA8y52BjF6DuEkWUqpaNsitZ,NOYn5tlTZoMaw4pfDsmzq = dEUYJjrhsaPXNo(u"ࡗࡶࡺ࡫ᝁ"),Kwl07iYTtDLN3zP(u"࠵ᚆ")
	LRtXWQ1zyFBCbP7SUhZ20a = w6vebiEZtpCjJcILP8Skx5rHn.time()
	try: tgBAOHox9r8NFYbfXwzUcpueJiMD.connect((IIOrTgqjuxv,s7ECqbiagkSBKfPLYOMpFxo))
	except: vhYA8y52BjF6DuEkWUqpaNsitZ = NNmirJKPp5nWjfC(u"ࡊࡦࡲࡳࡦᝂ")
	oFqyDxT4J95HCw3 = w6vebiEZtpCjJcILP8Skx5rHn.time()
	if vhYA8y52BjF6DuEkWUqpaNsitZ: NOYn5tlTZoMaw4pfDsmzq = oFqyDxT4J95HCw3-LRtXWQ1zyFBCbP7SUhZ20a
	return NOYn5tlTZoMaw4pfDsmzq
def Jc19dpOeUMyLXG5PVrf0SlZmHntx(showDialogs):
	if showDialogs:
		A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠭ࠧሠ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠧࠨሡ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠨࠩሢ"),dEUYJjrhsaPXNo(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬሣ"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠪืํ็๋ࠠไ๋้ࠥอไษำ้ห๊าࠠศๆล๊ࠥฮลึๆสัࠥ๎ส็ฺํๅࠥาๅ๋฻ࠣๆํอูะࠢส่อ๐ว็ษอࠤํอไไษืࠤฬ๊ๅิฬัำ๊ฯࠠโ์ࠣห้ฮั็ษ่ะࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢอุ฿๐ไࠡ฻่่๏ฯࠠศๆอ๊฽๐แࠡษ็ฦ๋ࠦฟࠢࠩሤ"))
	else: A5vgi1F6qVunZMas2Nf = WbM6qAjrn7fEXGZw(u"࡙ࡸࡵࡦᝃ")
	if A5vgi1F6qVunZMas2Nf==tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠷ᚇ"):
		for dkL0Qy5ZolhseOuCRKMrABV8Uzp in K3hFytImeYMkJBC.listdir(llrbyaFHOt9e):
			if dkL0Qy5ZolhseOuCRKMrABV8Uzp.endswith(CIcPowhneWs5tN3(u"ࠫ࠳ࡪࡢࠨሥ")) and FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠬࡪࡡࡵࡣࠪሦ") in dkL0Qy5ZolhseOuCRKMrABV8Uzp:
				AM9JTc4kHQBwve0Xh6i1 = K3hFytImeYMkJBC.path.join(llrbyaFHOt9e,dkL0Qy5ZolhseOuCRKMrABV8Uzp)
				try: md59xZUEq3IOnPp2,ngBDPjZshKvdX6 = N5JUy4M8AKmjBZgL(AM9JTc4kHQBwve0Xh6i1)
				except: return
				ngBDPjZshKvdX6.execute(ta478EuZQJIWhgBnsf6iU(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡩ࡯ࡶࡨ࡫ࡷ࡯ࡴࡺࡡࡦ࡬ࡪࡩ࡫࠼ࠩሧ"))
				ngBDPjZshKvdX6.execute(uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡰࡲࡷ࡭ࡲ࡯ࡺࡦ࠽ࠪረ"))
				ngBDPjZshKvdX6.execute(ItgK5FqGDz2Rf7mAJkbT(u"ࠨࡘࡄࡇ࡚࡛ࡍ࠼ࠩሩ"))
				md59xZUEq3IOnPp2.commit()
				md59xZUEq3IOnPp2.close()
		if showDialogs:
			tehb3k5a2PufGOdBIUw8j(I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠩࠪሪ"),NNmirJKPp5nWjfC(u"ࠪࠫራ"),tOdiG2HWFRBXg1sUh(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧሬ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠬะๅหࠢห๊ัออࠡ฻่่๏ฯࠠฦื็หา่ࠦห่฻๎ๆࠦฬๆ์฼ࠤ็๎วฺัࠣห้ฮ๊ศ่สฮࠥ๎วๅๅสุࠥอไๆีอาิ๋ษࠡใํࠤฬ๊ศา่ส้ั࠭ር"))
	return
def UyZEGdfW50X3Rbpzmh1CnYOuDlsk4q(bbSpDeaIACF9TPz3ldyjqVnk4xR6Y,Y6lwBrzPucqRHfbkxFKQ,showDialogs):
	if bbSpDeaIACF9TPz3ldyjqVnk4xR6Y!=None:
		global Xsc8MuwaDLKOr9tUFkAzWbIo
		Xsc8MuwaDLKOr9tUFkAzWbIo = bbSpDeaIACF9TPz3ldyjqVnk4xR6Y
	if Y6lwBrzPucqRHfbkxFKQ!=None:
		global rRbfYNV4JKD83dho
		rRbfYNV4JKD83dho = Y6lwBrzPucqRHfbkxFKQ
	if showDialogs!=None:
		global Ib1gDFzE0sTaRSiJ2AueUQ
		Ib1gDFzE0sTaRSiJ2AueUQ = showDialogs
	return
Xsc8MuwaDLKOr9tUFkAzWbIo,rRbfYNV4JKD83dho,Ib1gDFzE0sTaRSiJ2AueUQ = I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠭ࠧሮ"),qFRrj7ayBKbOsHGSXz(u"ࠧࠨሯ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠨࠩሰ")
def wxZf9B2mrgOaqpK83FQIy65W(VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF,pAeIhbuLSFw7j49qxtcg8dDrmKO,YReuIJ67GDs8NwEiZOAh4xPMb,XzfkYQBICVuSjcL5G0pgy9T16xv,N1N2sUZu9QXRLj6rFeHEKg,showDialogs,dIsZG1fHm5YVkU6Puzq,kQ36atvU4rpcWoH7MGdE8yCezZD1=qFRrj7ayBKbOsHGSXz(u"ࠩࠪሱ"),zcGCKESFR0Yt=bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠪࠫሲ")):
	global mR20sONyKIlV
	if showDialogs==WbM6qAjrn7fEXGZw(u"ࠫࠬሳ"): showDialogs = YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࡚ࡲࡶࡧᝄ") if Ib1gDFzE0sTaRSiJ2AueUQ==smpniPDOhfwI3H4v7c6TG(u"ࠬ࠭ሴ") else Ib1gDFzE0sTaRSiJ2AueUQ
	if zcGCKESFR0Yt==FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠭ࠧስ"): zcGCKESFR0Yt = MM564HfnUV0XIR(u"ࡔࡳࡷࡨᝅ") if rRbfYNV4JKD83dho==WbM6qAjrn7fEXGZw(u"ࠧࠨሶ") else rRbfYNV4JKD83dho
	if kQ36atvU4rpcWoH7MGdE8yCezZD1==CgPbwXm1RilpJUSGHLhy(u"ࠨࠩሷ"): kQ36atvU4rpcWoH7MGdE8yCezZD1 = bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࡕࡴࡸࡩᝆ") if Xsc8MuwaDLKOr9tUFkAzWbIo==NxsKJnLFEZ9OHXf1h(u"ࠩࠪሸ") else Xsc8MuwaDLKOr9tUFkAzWbIo
	if N1N2sUZu9QXRLj6rFeHEKg==YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠪࠫሹ"): nYOIqyZKWhm6a8RdPN40HfB = bbqAtUz36RPGVTvCkejpJXQB(u"ࡖࡵࡹࡪᝇ")
	else: nYOIqyZKWhm6a8RdPN40HfB = N1N2sUZu9QXRLj6rFeHEKg
	if YReuIJ67GDs8NwEiZOAh4xPMb==None: bhfgckoLVtsA2DXv = None
	elif YReuIJ67GDs8NwEiZOAh4xPMb==ta478EuZQJIWhgBnsf6iU(u"ࠫࠬሺ"): bhfgckoLVtsA2DXv = {}
	else: bhfgckoLVtsA2DXv = YReuIJ67GDs8NwEiZOAh4xPMb
	if XzfkYQBICVuSjcL5G0pgy9T16xv==None: TC7fWv2a1gLJGiAtN8 = None
	elif XzfkYQBICVuSjcL5G0pgy9T16xv==S26SnaqcM9XwK8PVphJDv5(u"ࠬ࠭ሻ"): TC7fWv2a1gLJGiAtN8 = {}
	else: TC7fWv2a1gLJGiAtN8 = XzfkYQBICVuSjcL5G0pgy9T16xv
	QTarMuz7CZO9l0w = list(TC7fWv2a1gLJGiAtN8.keys())
	if FeyZbj8tDil0nSHzTwfsUJ9(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪሼ") not in QTarMuz7CZO9l0w: TC7fWv2a1gLJGiAtN8[MM564HfnUV0XIR(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫሽ")] = wx18CTJPZ5(u"ࠨࡂࡃࡄࡘࡑࡉࡑࡡࡋࡉࡆࡊࡅࡓࡂࡃࡄࠬሾ")
	M08MPGgsh4n5rKe,LO2kNuoIli,p9ug8BqHR1ih7yWmNsDVGf3TUrk,UkVahO6eMJNDwImjBo1L7 = mXQV431NeJRFtUPEnia(pAeIhbuLSFw7j49qxtcg8dDrmKO)
	lbzUsDZE3MntmwucgjKa = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(wx18CTJPZ5(u"ࠩࡤࡺ࠳ࡪ࡮ࡴࠩሿ"))
	jQdbDoanq4SyCYI916 = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(bbqAtUz36RPGVTvCkejpJXQB(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ቀ"))
	fLjePgi96lUbn = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩቁ"))
	cfF8HEW13OGobVvsDCwJdM = (LO2kNuoIli==None and p9ug8BqHR1ih7yWmNsDVGf3TUrk==None)
	Q9RSxKJ45e = mR20sONyKIlV[WbM6qAjrn7fEXGZw(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬቂ")]
	k2QxbgNTiLlUBp8GjD = M08MPGgsh4n5rKe in Q9RSxKJ45e
	eiU4PdYHEngVrhcITXyO7QpKlZFs = mR20sONyKIlV[uAl3gHavMJZL4xmNe62nDiBoQ(u"࠭ࡒࡆࡒࡒࡗࠬቃ")]
	CCvp2H3Tr1J = M08MPGgsh4n5rKe in eiU4PdYHEngVrhcITXyO7QpKlZFs
	XlqJRsTwj0L = k2QxbgNTiLlUBp8GjD or CCvp2H3Tr1J
	if cfF8HEW13OGobVvsDCwJdM and XlqJRsTwj0L:
		if k2QxbgNTiLlUBp8GjD:
			fIgCAsJjo93HL = Q9RSxKJ45e.index(M08MPGgsh4n5rKe)
			coFltERwvrg = mR20sONyKIlV[FeyZbj8tDil0nSHzTwfsUJ9(u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓࠫቄ")][fIgCAsJjo93HL]
			gS3Nu4F7UJH25GqyxP6pcRaM8i = ANjhxR3Z6pBcJ[fIgCAsJjo93HL]
		elif CCvp2H3Tr1J:
			fIgCAsJjo93HL = eiU4PdYHEngVrhcITXyO7QpKlZFs.index(M08MPGgsh4n5rKe)
			coFltERwvrg = mR20sONyKIlV[bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠨࡔࡈࡔࡔ࡙࡟ࡃࡍࡓࠫቅ")][fIgCAsJjo93HL]
			gS3Nu4F7UJH25GqyxP6pcRaM8i = qHUNxQG27zhe8LI05O[fIgCAsJjo93HL]
	if p9ug8BqHR1ih7yWmNsDVGf3TUrk==tOdiG2HWFRBXg1sUh(u"ࠩࠪቆ"): p9ug8BqHR1ih7yWmNsDVGf3TUrk = lbzUsDZE3MntmwucgjKa
	elif p9ug8BqHR1ih7yWmNsDVGf3TUrk==None and jQdbDoanq4SyCYI916 in [tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠪࡅ࡚࡚ࡏࠨቇ"),qFRrj7ayBKbOsHGSXz(u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭ቈ")] and kQ36atvU4rpcWoH7MGdE8yCezZD1: p9ug8BqHR1ih7yWmNsDVGf3TUrk = lbzUsDZE3MntmwucgjKa
	RBeo10SQWCx3VkGy6v = M08MPGgsh4n5rKe==mR20sONyKIlV[I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ቉")][QmoEjB3hLIw(u"࠷ᚈ")]
	qTC2t90VSKWy4s7QDkUXNe3R1p = LO2kNuoIli and CIcPowhneWs5tN3(u"࠭ࡳࡤࡴࡤࡴࡪ࠭ቊ") in LO2kNuoIli
	if qTC2t90VSKWy4s7QDkUXNe3R1p: mze2PWBb1idXw9Z0Hh = smpniPDOhfwI3H4v7c6TG(u"࠷࠲ᚉ")
	elif k2QxbgNTiLlUBp8GjD or CCvp2H3Tr1J: mze2PWBb1idXw9Z0Hh = bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠳࠸ᚊ")
	elif dIsZG1fHm5YVkU6Puzq in GImcXg9OBxnZFlj4qe: mze2PWBb1idXw9Z0Hh = YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠴࠴ᚋ")
	elif dIsZG1fHm5YVkU6Puzq==ta478EuZQJIWhgBnsf6iU(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈ࡚ࡊࡘࡓࡐࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩቋ"): mze2PWBb1idXw9Z0Hh = FeyZbj8tDil0nSHzTwfsUJ9(u"࠶࠵ᚌ")
	elif dIsZG1fHm5YVkU6Puzq==EAw9bg4rT3Bd8tjSkO(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩቌ"): mze2PWBb1idXw9Z0Hh = bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠷࠶ᚍ")
	elif qFRrj7ayBKbOsHGSXz(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡘࡃࡐࠫቍ") in dIsZG1fHm5YVkU6Puzq: mze2PWBb1idXw9Z0Hh = NNmirJKPp5nWjfC(u"࠽࠰ᚎ")
	elif uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠪࡗࡍࡕࡆࡉࡃࠪ቎") in dIsZG1fHm5YVkU6Puzq: mze2PWBb1idXw9Z0Hh = EAw9bg4rT3Bd8tjSkO(u"࠷࠶ᚏ")
	elif ta478EuZQJIWhgBnsf6iU(u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ቏") in dIsZG1fHm5YVkU6Puzq: mze2PWBb1idXw9Z0Hh = WbM6qAjrn7fEXGZw(u"࠳࠷ᚐ")
	elif smpniPDOhfwI3H4v7c6TG(u"ࠬࡇࡈࡘࡃࡎࠫቐ") in dIsZG1fHm5YVkU6Puzq: mze2PWBb1idXw9Z0Hh = qFRrj7ayBKbOsHGSXz(u"࠴࠳ᚑ")
	elif r6juULGQtnExAko38BZ5Y(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩቑ") in dIsZG1fHm5YVkU6Puzq: mze2PWBb1idXw9Z0Hh = NxsKJnLFEZ9OHXf1h(u"࠵࠴ᚒ")
	elif qFRrj7ayBKbOsHGSXz(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭ቒ") in dIsZG1fHm5YVkU6Puzq: mze2PWBb1idXw9Z0Hh = YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠷࠵ᚓ")
	elif EAw9bg4rT3Bd8tjSkO(u"ࠨࡃࡎࡓࡆࡓࠧቓ") in dIsZG1fHm5YVkU6Puzq: mze2PWBb1idXw9Z0Hh = Gk98CL5nXZEN(u"࠷࠻ᚔ")
	elif GGCQK6OAtZUXRhvkgJm(u"ࠩࡄࡏ࡜ࡇࡍࠨቔ") in dIsZG1fHm5YVkU6Puzq: mze2PWBb1idXw9Z0Hh = SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠹࠰ᚕ")
	elif ItgK5FqGDz2Rf7mAJkbT(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬቕ") in dIsZG1fHm5YVkU6Puzq: mze2PWBb1idXw9Z0Hh = CgPbwXm1RilpJUSGHLhy(u"࠲࠱ᚖ")
	elif GGCQK6OAtZUXRhvkgJm(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠭ቖ") in dIsZG1fHm5YVkU6Puzq: mze2PWBb1idXw9Z0Hh = ItgK5FqGDz2Rf7mAJkbT(u"࠷࠲ᚗ")
	else: mze2PWBb1idXw9Z0Hh = I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠳࠸ᚘ")
	if tOdiG2HWFRBXg1sUh(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ቗") in dIsZG1fHm5YVkU6Puzq and not bhfgckoLVtsA2DXv and CgPbwXm1RilpJUSGHLhy(u"࠭ࠦࠨቘ") not in M08MPGgsh4n5rKe and CgPbwXm1RilpJUSGHLhy(u"ࠧࡀࠩ቙") not in M08MPGgsh4n5rKe: M08MPGgsh4n5rKe = M08MPGgsh4n5rKe.rstrip(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠨ࠱ࠪቚ"))+Gk98CL5nXZEN(u"ࠩ࠲ࠫቛ")
	FDy6VSa3Br4e2bi = (LO2kNuoIli!=None)
	HQd7gc45U9rEx = (p9ug8BqHR1ih7yWmNsDVGf3TUrk!=None and jQdbDoanq4SyCYI916!=smpniPDOhfwI3H4v7c6TG(u"ࠪࡗ࡙ࡕࡐࠨቜ"))
	if FDy6VSa3Br4e2bi and not qTC2t90VSKWy4s7QDkUXNe3R1p: xa60ce2znAlyL5Z8ESXhO(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠫฯ็ู๋ๆࠣฬึ๎ใิ์ࠣี็๋ࠧቝ"),LO2kNuoIli)
	elif HQd7gc45U9rEx: xa60ce2znAlyL5Z8ESXhO(Gk98CL5nXZEN(u"ࠬะแฺ์็ࠤࡉࡔࡓࠡำๅ้ࠬ቞"),p9ug8BqHR1ih7yWmNsDVGf3TUrk)
	if FDy6VSa3Br4e2bi:
		hSYAxPLswHz8JlvK = {Kwl07iYTtDLN3zP(u"ࠨࡨࡵࡶࡳࠦ቟"):LO2kNuoIli,zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠢࡩࡶࡷࡴࡸࠨበ"):LO2kNuoIli}
		gU9kom76BzGMwapY25RXZCe = LO2kNuoIli
	else: hSYAxPLswHz8JlvK,gU9kom76BzGMwapY25RXZCe = {},Kwl07iYTtDLN3zP(u"ࠨࠩቡ")
	if HQd7gc45U9rEx:
		import urllib3.util.connection as hhGodXVgTLpC92yOM3D
		GXDlkY35uAHBnmhJfK1jIyLEZVg = nnMOiPSwU3Qapj501X8Co2YJB(hhGodXVgTLpC92yOM3D,lbzUsDZE3MntmwucgjKa)
	xSPjY2hg1aTMVDu4IQw8mRdALy,VGtuhdKLHN,BCrgPhcKutUENdZ4em,c1I4h2Zj8PgCrDQHv9n5,RWo7XAcSnv2L943DfK0eHlPzpdJxNg,verify = nYOIqyZKWhm6a8RdPN40HfB,dIsZG1fHm5YVkU6Puzq,VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF,tOdiG2HWFRBXg1sUh(u"ࡉࡥࡱࡹࡥᝈ"),tOdiG2HWFRBXg1sUh(u"ࡉࡥࡱࡹࡥᝈ"),UkVahO6eMJNDwImjBo1L7
	if RBeo10SQWCx3VkGy6v: RWo7XAcSnv2L943DfK0eHlPzpdJxNg = WbM6qAjrn7fEXGZw(u"ࡘࡷࡻࡥᝉ")
	if XlqJRsTwj0L or nYOIqyZKWhm6a8RdPN40HfB: xSPjY2hg1aTMVDu4IQw8mRdALy = cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࡋࡧ࡬ࡴࡧᝊ")
	if k2QxbgNTiLlUBp8GjD: BCrgPhcKutUENdZ4em = NNmirJKPp5nWjfC(u"ࠩࡓࡓࡘ࡚ࠧቢ")
	G4KzAhcON3gwns1o5rIbai2FDJEXmy,rreason = -CIcPowhneWs5tN3(u"࠴ᚙ"),Kwl07iYTtDLN3zP(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤࡊࡸࡲࡰࡴࠪባ")
	for Deiz7ocWQjVnIg in range(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠽ᚚ")):
		QCY7DTAN2OoUpB8Z9 = uAl3gHavMJZL4xmNe62nDiBoQ(u"࡚ࡲࡶࡧᝋ")
		VZHWjJTrAPKG1eLEsxpYo2tS5 = wx18CTJPZ5(u"ࡆࡢ࡮ࡶࡩᝌ")
		try:
			if Deiz7ocWQjVnIg: VGtuhdKLHN = Gk98CL5nXZEN(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓ࠮࠳ࡶࡸࠬቤ")
			if qTC2t90VSKWy4s7QDkUXNe3R1p or not FDy6VSa3Br4e2bi: ynWephC0J6VPiHcqmrg8d(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠬࡘࡅࡒࡗࡈࡗ࡙࡙ࠠࠡࡑࡓࡉࡓࡥࡕࡓࡎࠪብ"),M08MPGgsh4n5rKe,bhfgckoLVtsA2DXv,TC7fWv2a1gLJGiAtN8,VGtuhdKLHN,BCrgPhcKutUENdZ4em)
			try: Il5iAWS8vkNBe4Xf.close()
			except: pass
			TW6JIBgC971tjOE = M08MPGgsh4n5rKe
			Il5iAWS8vkNBe4Xf = jR02vwUAu7Xs8mefybaHiJ.request(BCrgPhcKutUENdZ4em,M08MPGgsh4n5rKe,data=bhfgckoLVtsA2DXv,headers=TC7fWv2a1gLJGiAtN8,verify=verify,allow_redirects=xSPjY2hg1aTMVDu4IQw8mRdALy,timeout=mze2PWBb1idXw9Z0Hh,proxies=hSYAxPLswHz8JlvK)
			if FeyZbj8tDil0nSHzTwfsUJ9(u"࠸࠶࠰᚛")<=Il5iAWS8vkNBe4Xf.status_code<=cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠹࠹࠺᚜"):
				if not c1I4h2Zj8PgCrDQHv9n5:
					DDeA4y3O6xNw5bg = list(Il5iAWS8vkNBe4Xf.headers.keys())
					if Ox8k6IdtuPaG3NlApQK52oYwM(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨቦ") in DDeA4y3O6xNw5bg: M08MPGgsh4n5rKe = Il5iAWS8vkNBe4Xf.headers[YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩቧ")]
					elif WbM6qAjrn7fEXGZw(u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠪቨ") in DDeA4y3O6xNw5bg: M08MPGgsh4n5rKe = Il5iAWS8vkNBe4Xf.headers[YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠩ࡯ࡳࡨࡧࡴࡪࡱࡱࠫቩ")]
					else: c1I4h2Zj8PgCrDQHv9n5 = zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࡕࡴࡸࡩᝍ")
					if not c1I4h2Zj8PgCrDQHv9n5: M08MPGgsh4n5rKe = M08MPGgsh4n5rKe.encode(dEUYJjrhsaPXNo(u"ࠪࡰࡦࡺࡩ࡯࠯࠴ࠫቪ"),ItgK5FqGDz2Rf7mAJkbT(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫቫ")).decode(MM564HfnUV0XIR(u"ࠬࡻࡴࡧ࠺ࠪቬ"),S26SnaqcM9XwK8PVphJDv5(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ቭ"))
					if XlqJRsTwj0L and Il5iAWS8vkNBe4Xf.status_code==tOdiG2HWFRBXg1sUh(u"࠳࠱࠹᚝"):
						xSPjY2hg1aTMVDu4IQw8mRdALy = nYOIqyZKWhm6a8RdPN40HfB
						BCrgPhcKutUENdZ4em = VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF
						c1I4h2Zj8PgCrDQHv9n5 = ta478EuZQJIWhgBnsf6iU(u"ࡖࡵࡹࡪᝎ")
						Zf9CWHydpPoLVb1GUaEF50A3v2Nj
				if not c1I4h2Zj8PgCrDQHv9n5 or nYOIqyZKWhm6a8RdPN40HfB:
					if dEUYJjrhsaPXNo(u"ࠧࡩࡶࡷࡴࠬቮ") not in M08MPGgsh4n5rKe:
						qy8WbkjXRIeghUPdFM41aHBxo5tc = SLMTm6RQ34ic7v5s9rBG(TW6JIBgC971tjOE,I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠨࡷࡵࡰࠬቯ"))
						M08MPGgsh4n5rKe = qy8WbkjXRIeghUPdFM41aHBxo5tc+WbM6qAjrn7fEXGZw(u"ࠩ࠲ࠫተ")+M08MPGgsh4n5rKe.lstrip(dEUYJjrhsaPXNo(u"ࠪ࠳ࠬቱ"))
				if not c1I4h2Zj8PgCrDQHv9n5 and nYOIqyZKWhm6a8RdPN40HfB and not SU82u7LfcMslH3e0Bzihn6x(M08MPGgsh4n5rKe): TTtRypxIELuGPk42arz5bOe
			elif dEUYJjrhsaPXNo(u"࠷࠸࠴᚟")<=Il5iAWS8vkNBe4Xf.status_code<=smpniPDOhfwI3H4v7c6TG(u"࠶࠻࠼᚞"):
				Il5iAWS8vkNBe4Xf.rreason = Il5iAWS8vkNBe4Xf.content
				RWo7XAcSnv2L943DfK0eHlPzpdJxNg = Ox8k6IdtuPaG3NlApQK52oYwM(u"ࡗࡶࡺ࡫ᝏ")
			TW6JIBgC971tjOE = Il5iAWS8vkNBe4Xf.url
			G4KzAhcON3gwns1o5rIbai2FDJEXmy = Il5iAWS8vkNBe4Xf.status_code
			rreason = Il5iAWS8vkNBe4Xf.reason
			Il5iAWS8vkNBe4Xf.raise_for_status()
			VZHWjJTrAPKG1eLEsxpYo2tS5 = YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࡘࡷࡻࡥᝐ")
		except jR02vwUAu7Xs8mefybaHiJ.exceptions.HTTPError as y1y3DkdhK8aFYEwMnqZRzi:
			pass
		except jR02vwUAu7Xs8mefybaHiJ.exceptions.Timeout as y1y3DkdhK8aFYEwMnqZRzi:
			if vciEXHThAPto76QIR2pK: rreason = str(y1y3DkdhK8aFYEwMnqZRzi.message).split(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠫ࠿ࠦࠧቲ"))[SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠴ᚠ")]
			else: rreason = str(y1y3DkdhK8aFYEwMnqZRzi).split(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠬࡀࠠࠨታ"))[SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠵ᚡ")]
		except jR02vwUAu7Xs8mefybaHiJ.exceptions.ConnectionError as y1y3DkdhK8aFYEwMnqZRzi:
			try:
				E9IA4lBOyNJf = y1y3DkdhK8aFYEwMnqZRzi.message[EAw9bg4rT3Bd8tjSkO(u"࠵ᚢ")]
				rreason = E9IA4lBOyNJf
				if WbM6qAjrn7fEXGZw(u"࠭ࡅࡳࡴࡱࡳࠬቴ") in E9IA4lBOyNJf: G4KzAhcON3gwns1o5rIbai2FDJEXmy,rreason = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(tOdiG2HWFRBXg1sUh(u"ࠢ࡝࡝ࡈࡶࡷࡴ࡯ࠡࠪ࡟ࡨ࠰࠯࡜࡞ࠢࠫ࠲࠯ࡅࠩࠨࠤት"),E9IA4lBOyNJf)[CgPbwXm1RilpJUSGHLhy(u"࠶ᚣ")]
				elif tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠨ࠮ࠣࡩࡷࡸ࡯ࡳࠪࠪቶ") in E9IA4lBOyNJf: G4KzAhcON3gwns1o5rIbai2FDJEXmy,rreason = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠤ࠯ࠤࡪࡸࡲࡰࡴ࡟ࠬ࠭ࡢࡤࠬࠫ࠯ࠤࠬ࠮࠮ࠫࡁࠬࠫࠧቷ"),E9IA4lBOyNJf)[FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠰ᚤ")]
				elif E9IA4lBOyNJf.count(tOdiG2HWFRBXg1sUh(u"ࠪ࠾ࠬቸ"))>=YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠴ᚦ"): rreason,G4KzAhcON3gwns1o5rIbai2FDJEXmy = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(dEUYJjrhsaPXNo(u"ࠫ࠿ࠦࠨ࠯ࠬࡂ࠭࠿࠴ࠪࡀࠪ࡟ࡨ࠰࠯ࠧቹ"),E9IA4lBOyNJf)[tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠱ᚥ")]
			except: pass
		except jR02vwUAu7Xs8mefybaHiJ.exceptions.RequestException as y1y3DkdhK8aFYEwMnqZRzi:
			if vciEXHThAPto76QIR2pK: rreason = y1y3DkdhK8aFYEwMnqZRzi.message
			else: rreason = str(y1y3DkdhK8aFYEwMnqZRzi)
		except:
			QCY7DTAN2OoUpB8Z9 = WbM6qAjrn7fEXGZw(u"ࡋࡧ࡬ࡴࡧᝑ")
			try: G4KzAhcON3gwns1o5rIbai2FDJEXmy = Il5iAWS8vkNBe4Xf.status_code
			except: pass
			try: rreason = Il5iAWS8vkNBe4Xf.reason
			except: pass
		rreason = str(rreason)
		y75wQavkVSLUb2MZf9qo(uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠬࡔࡏࡕࡋࡆࡉࠬቺ"),Ox8k6IdtuPaG3NlApQK52oYwM(u"࠭࠮ࠡࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠥࠦࡒࡆࡕࡓࡓࡓ࡙ࡅࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫቻ")+str(G4KzAhcON3gwns1o5rIbai2FDJEXmy)+YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩቼ")+rreason+EAw9bg4rT3Bd8tjSkO(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪች")+dIsZG1fHm5YVkU6Puzq+tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨቾ")+pAeIhbuLSFw7j49qxtcg8dDrmKO+Kwl07iYTtDLN3zP(u"ࠪࠤࡢ࠭ቿ"))
		if cfF8HEW13OGobVvsDCwJdM and XlqJRsTwj0L and QCY7DTAN2OoUpB8Z9 and not RWo7XAcSnv2L943DfK0eHlPzpdJxNg and G4KzAhcON3gwns1o5rIbai2FDJEXmy!=tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠵࠴࠵ᚧ"):
			M08MPGgsh4n5rKe = coFltERwvrg
			RWo7XAcSnv2L943DfK0eHlPzpdJxNg = YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࡚ࡲࡶࡧᝒ")
			continue
		if QCY7DTAN2OoUpB8Z9: break
	if p9ug8BqHR1ih7yWmNsDVGf3TUrk!=None and jQdbDoanq4SyCYI916!=ItgK5FqGDz2Rf7mAJkbT(u"ࠫࡘ࡚ࡏࡑࠩኀ"): hhGodXVgTLpC92yOM3D.create_connection = GXDlkY35uAHBnmhJfK1jIyLEZVg
	if jQdbDoanq4SyCYI916==bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠬࡇࡌࡘࡃ࡜ࡗࠬኁ") and kQ36atvU4rpcWoH7MGdE8yCezZD1: p9ug8BqHR1ih7yWmNsDVGf3TUrk = None
	if not VZHWjJTrAPKG1eLEsxpYo2tS5 and LO2kNuoIli==None and dIsZG1fHm5YVkU6Puzq not in GImcXg9OBxnZFlj4qe:
		jbDMGZeVf2RyJ8OxFA94Emu3pgo0St = oo5q9yuEdbCeOSxfzJcw.format_exc()
		if jbDMGZeVf2RyJ8OxFA94Emu3pgo0St!=QmoEjB3hLIw(u"࠭ࡎࡰࡰࡨࡘࡾࡶࡥ࠻ࠢࡑࡳࡳ࡫࡜࡯ࠩኂ"): EAPND6zHKrMRuBc91tInYohsl0ywa.stderr.write(jbDMGZeVf2RyJ8OxFA94Emu3pgo0St)
	WcPEG7nehsCwig809NyHMZ = bbWis1pMJaqDek()
	WcPEG7nehsCwig809NyHMZ.url = TW6JIBgC971tjOE
	try: fflYxStLuhed5 = Il5iAWS8vkNBe4Xf.content
	except: fflYxStLuhed5 = GGCQK6OAtZUXRhvkgJm(u"ࠧࠨኃ")
	try: RRt4TH2wLFbY = Il5iAWS8vkNBe4Xf.headers
	except: RRt4TH2wLFbY = {}
	try: PPhDxN9efz30T = Il5iAWS8vkNBe4Xf.cookies.get_dict()
	except: PPhDxN9efz30T = {}
	try: Il5iAWS8vkNBe4Xf.close()
	except: pass
	if wvkR1es6d0SrjxKt5FZTMUWz7a:
		try: fflYxStLuhed5 = fflYxStLuhed5.decode(CgPbwXm1RilpJUSGHLhy(u"ࠨࡷࡷࡪ࠽࠭ኄ"))
		except: pass
	G4KzAhcON3gwns1o5rIbai2FDJEXmy = int(G4KzAhcON3gwns1o5rIbai2FDJEXmy)
	WcPEG7nehsCwig809NyHMZ.code = G4KzAhcON3gwns1o5rIbai2FDJEXmy
	WcPEG7nehsCwig809NyHMZ.reason = rreason
	WcPEG7nehsCwig809NyHMZ.content = fflYxStLuhed5
	WcPEG7nehsCwig809NyHMZ.headers = RRt4TH2wLFbY
	WcPEG7nehsCwig809NyHMZ.cookies = PPhDxN9efz30T
	WcPEG7nehsCwig809NyHMZ.succeeded = VZHWjJTrAPKG1eLEsxpYo2tS5
	if vciEXHThAPto76QIR2pK or isinstance(WcPEG7nehsCwig809NyHMZ.content,str): BGYbo5RwcMunHJP6Kqp4rymTdf7v = WcPEG7nehsCwig809NyHMZ.content.lower()
	else: BGYbo5RwcMunHJP6Kqp4rymTdf7v = Gk98CL5nXZEN(u"ࠩࠪኅ")
	m9Pun8rTb4patA3 = (smpniPDOhfwI3H4v7c6TG(u"ࠪࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧኆ") in BGYbo5RwcMunHJP6Kqp4rymTdf7v or uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࠫኇ") in BGYbo5RwcMunHJP6Kqp4rymTdf7v) and BGYbo5RwcMunHJP6Kqp4rymTdf7v.count(wx18CTJPZ5(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡࠨኈ"))>S26SnaqcM9XwK8PVphJDv5(u"࠶ᚨ") and NNmirJKPp5nWjfC(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨ኉") not in dIsZG1fHm5YVkU6Puzq and smpniPDOhfwI3H4v7c6TG(u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠰ࡸࡴࡱࡥ࡯ࠩኊ") not in BGYbo5RwcMunHJP6Kqp4rymTdf7v and not qTC2t90VSKWy4s7QDkUXNe3R1p
	if G4KzAhcON3gwns1o5rIbai2FDJEXmy==I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠷࠶࠰ᚩ") and m9Pun8rTb4patA3: WcPEG7nehsCwig809NyHMZ.succeeded = SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࡆࡢ࡮ࡶࡩᝓ")
	if WcPEG7nehsCwig809NyHMZ.succeeded and cfF8HEW13OGobVvsDCwJdM and XlqJRsTwj0L:
		if RBeo10SQWCx3VkGy6v: gS3Nu4F7UJH25GqyxP6pcRaM8i = YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠨࡅࡄࡔ࡙ࡉࡈࡂࠩኋ")+bhfgckoLVtsA2DXv[Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠩ࡭ࡳࡧ࠭ኌ")].upper().replace(r6juULGQtnExAko38BZ5Y(u"ࠪࡋࡊ࡚ࠧኍ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠫࠬ኎"))
		CqivWrSdG8cOo2DtkgV01 = YQqPDl7UoC53sKbO(gS3Nu4F7UJH25GqyxP6pcRaM8i)
	if not WcPEG7nehsCwig809NyHMZ.succeeded and cfF8HEW13OGobVvsDCwJdM:
		YvEXMDTpuV417e = (r6juULGQtnExAko38BZ5Y(u"ࠬࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩ኏") in BGYbo5RwcMunHJP6Kqp4rymTdf7v and r6juULGQtnExAko38BZ5Y(u"࠭ࡲࡢࡻࠣ࡭ࡩࡀࠠࠨነ") in BGYbo5RwcMunHJP6Kqp4rymTdf7v)
		uTds4vfw7Bl = (cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠧ࠶ࠢࡶࡩࡨ࠭ኑ") in BGYbo5RwcMunHJP6Kqp4rymTdf7v and CgPbwXm1RilpJUSGHLhy(u"ࠨࡤࡵࡳࡼࡹࡥࡳࠩኒ") in BGYbo5RwcMunHJP6Kqp4rymTdf7v)
		D7dfFGH0AkWUp1csN4 = (G4KzAhcON3gwns1o5rIbai2FDJEXmy in [QmoEjB3hLIw(u"࠺࠰࠴ᚪ")] and CIcPowhneWs5tN3(u"ࠩࡨࡶࡷࡵࡲࠡࡥࡲࡨࡪࡀࠠ࠲࠲࠵࠴ࠬና") in BGYbo5RwcMunHJP6Kqp4rymTdf7v)
		x0A1m79EZGwWNKgCafQpRX4oVdPu = (smpniPDOhfwI3H4v7c6TG(u"ࠪࡣࡨ࡬࡟ࡤࡪ࡯ࡣࠬኔ") in BGYbo5RwcMunHJP6Kqp4rymTdf7v and qFRrj7ayBKbOsHGSXz(u"ࠫࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࠭ࠨን") in BGYbo5RwcMunHJP6Kqp4rymTdf7v)
		if   m9Pun8rTb4patA3: rreason = bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡵࡩࡨࡧࡰࡵࡥ࡫ࡥࠬኖ")
		elif YvEXMDTpuV417e: rreason = FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧኗ")
		elif uTds4vfw7Bl: rreason = NNmirJKPp5nWjfC(u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤ࠺ࠦࡳࡦࡥࡲࡲࡩࡹࠠࡣࡴࡲࡻࡸ࡫ࡲࠡࡥ࡫ࡩࡨࡱࠧኘ")
		elif D7dfFGH0AkWUp1csN4: rreason = YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠢࡤࡧࡨ࡫ࡳࡴࠢࡧࡩࡳ࡯ࡥࡥࠩኙ")
		elif x0A1m79EZGwWNKgCafQpRX4oVdPu: rreason = Kwl07iYTtDLN3zP(u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠣࡷࡪࡩࡵࡳ࡫ࡷࡽࠥࡩࡨࡦࡥ࡮ࠫኚ")
		else: rreason = str(rreason)
		if dIsZG1fHm5YVkU6Puzq in pxVtCSf8jbGmMoLEkW: pass
		elif dIsZG1fHm5YVkU6Puzq in GImcXg9OBxnZFlj4qe:
			y75wQavkVSLUb2MZf9qo(WbM6qAjrn7fEXGZw(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩኛ"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠫࠥࠦࡄࡪࡴࡨࡧࡹࠦࡣࡰࡰࡱࡩࡨࡺࡩࡰࡰࠣࡪࡦ࡯࡬ࡦࡦࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧኜ")+str(G4KzAhcON3gwns1o5rIbai2FDJEXmy)+Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠬࠦ࡝ࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭ኝ")+rreason+tOdiG2HWFRBXg1sUh(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨኞ")+dIsZG1fHm5YVkU6Puzq+cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ኟ")+M08MPGgsh4n5rKe+tOdiG2HWFRBXg1sUh(u"ࠨࠢࡠࠫአ"))
		else: y75wQavkVSLUb2MZf9qo(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧኡ"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+CgPbwXm1RilpJUSGHLhy(u"ࠪࠤࠥࠦࡄࡪࡴࡨࡧࡹࠦࡣࡰࡰࡱࡩࡨࡺࡩࡰࡰࠣࡪࡦ࡯࡬ࡦࡦࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧኢ")+str(G4KzAhcON3gwns1o5rIbai2FDJEXmy)+MM564HfnUV0XIR(u"ࠫࠥࡣࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬኣ")+rreason+ItgK5FqGDz2Rf7mAJkbT(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧኤ")+dIsZG1fHm5YVkU6Puzq+MM564HfnUV0XIR(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬእ")+M08MPGgsh4n5rKe+FeyZbj8tDil0nSHzTwfsUJ9(u"ࠧࠡ࡟ࠪኦ"))
		ineTI6azGF3c5XEAqj4uSJgdP8p = BUTSkzgFC7(M08MPGgsh4n5rKe)
		if vciEXHThAPto76QIR2pK and isinstance(ineTI6azGF3c5XEAqj4uSJgdP8p,unicode): ineTI6azGF3c5XEAqj4uSJgdP8p = ineTI6azGF3c5XEAqj4uSJgdP8p.encode(WbM6qAjrn7fEXGZw(u"ࠨࡷࡷࡪ࠽࠭ኧ"))
		if XlqJRsTwj0L: ineTI6azGF3c5XEAqj4uSJgdP8p = ineTI6azGF3c5XEAqj4uSJgdP8p.split(S26SnaqcM9XwK8PVphJDv5(u"ࠩ࠲ࠫከ"))[-NxsKJnLFEZ9OHXf1h(u"࠱ᚫ")]
		jskHuiKL8IYRpTdSXhNmExClPOcvG = rreason
		rreason = str(rreason)+FeyZbj8tDil0nSHzTwfsUJ9(u"ࠪࡠࡳ࠮ࠠࠨኩ")+ineTI6azGF3c5XEAqj4uSJgdP8p+tOdiG2HWFRBXg1sUh(u"ࠫࠥ࠯ࠧኪ")
		if m9Pun8rTb4patA3 or YvEXMDTpuV417e or uTds4vfw7Bl or D7dfFGH0AkWUp1csN4 or x0A1m79EZGwWNKgCafQpRX4oVdPu:
			G4KzAhcON3gwns1o5rIbai2FDJEXmy = -CgPbwXm1RilpJUSGHLhy(u"࠳ᚬ")
			WcPEG7nehsCwig809NyHMZ.code = G4KzAhcON3gwns1o5rIbai2FDJEXmy
			WcPEG7nehsCwig809NyHMZ.reason = rreason
			if zcGCKESFR0Yt:
				y75wQavkVSLUb2MZf9qo(ItgK5FqGDz2Rf7mAJkbT(u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫካ"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+Ox8k6IdtuPaG3NlApQK52oYwM(u"࠭ࠠࠡࠢࠣࡘࡷࡿࡩ࡯ࡩࠣࡦࡾࡶࡡࡴࡵࠣࡷࡪࡩࡵࡳ࡫ࡷࡽࠥࡩࡨࡦࡥ࡮ࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨኬ")+str(G4KzAhcON3gwns1o5rIbai2FDJEXmy)+CgPbwXm1RilpJUSGHLhy(u"ࠧࠡ࡟ࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨክ")+jskHuiKL8IYRpTdSXhNmExClPOcvG+uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪኮ")+dIsZG1fHm5YVkU6Puzq+bbqAtUz36RPGVTvCkejpJXQB(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨኯ")+M08MPGgsh4n5rKe+dEUYJjrhsaPXNo(u"ࠪࠤࡢ࠭ኰ"))
				xa60ce2znAlyL5Z8ESXhO(NNmirJKPp5nWjfC(u"๊ࠫำว้ๆฬࠤฯาว้ิࠣห้็อึࠢส่ศ๋ๆ๋ࠩ኱"),EAw9bg4rT3Bd8tjSkO(u"ࠬ࠭ኲ"),w6vebiEZtpCjJcILP8Skx5rHn=SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠳࠸࠴࠵ᚭ"))
				LniTbXC0PK2x = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥࡥࡱ࠴ࠫኳ"))
				WXZARvOi43f = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(EAw9bg4rT3Bd8tjSkO(u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡦࡦࡲ࠶ࠬኴ"))
				LniTbXC0PK2x = SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠼࠽࠾࠿ᚮ") if not LniTbXC0PK2x else int(LniTbXC0PK2x)
				WXZARvOi43f = EAw9bg4rT3Bd8tjSkO(u"࠽࠾࠿࠹ᚯ") if not WXZARvOi43f else int(WXZARvOi43f)
				SSaVXbRmEoihcGe0yOYf = []
				if LniTbXC0PK2x>cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠷࠰ᚱ"): SSaVXbRmEoihcGe0yOYf.append(smpniPDOhfwI3H4v7c6TG(u"࠶ᚰ"))
				if WXZARvOi43f>QmoEjB3hLIw(u"࠱࠱ᚲ"): SSaVXbRmEoihcGe0yOYf.append(NxsKJnLFEZ9OHXf1h(u"࠳ᚳ"))
				SSaVXbRmEoihcGe0yOYf.append(ta478EuZQJIWhgBnsf6iU(u"࠵ᚴ"))
				U5ZuMg9qvXHd2CpfyxB7ToaRs = BBioyg7XVR.sample(SSaVXbRmEoihcGe0yOYf,qFRrj7ayBKbOsHGSXz(u"࠴ᚵ"))[bbqAtUz36RPGVTvCkejpJXQB(u"࠴ᚶ")]
				if U5ZuMg9qvXHd2CpfyxB7ToaRs==r6juULGQtnExAko38BZ5Y(u"࠶ᚷ"):
					e1AmZsUS9HY3Gv74PuVf = ta478EuZQJIWhgBnsf6iU(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡥࡦ࠶࠻࠹ࡡࡣ࠳ࡨ࠹࠵࠺࠴ࡥ࠴ࡦࡥ࠺ࡪ࠵ࡥ࠵ࡩ࠽ࡪ࠹ࡣ࠴࠺࠹ࡩࡨࡧ࠱࠲࠲࠻࠷࠽࠿ࡡ࠸࠵࠽ࡄࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱࡧ࠱ࡨࡴࡀ࠸࠱࠺࠳ࠫኵ")
					FF976NUWy3wVxBvP = M08MPGgsh4n5rKe+ItgK5FqGDz2Rf7mAJkbT(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩ኶")+e1AmZsUS9HY3Gv74PuVf+WbM6qAjrn7fEXGZw(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪ኷")
					B3swpfRvj2 = wxZf9B2mrgOaqpK83FQIy65W(VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF,FF976NUWy3wVxBvP,YReuIJ67GDs8NwEiZOAh4xPMb,XzfkYQBICVuSjcL5G0pgy9T16xv,N1N2sUZu9QXRLj6rFeHEKg,FeyZbj8tDil0nSHzTwfsUJ9(u"ࡇࡣ࡯ࡷࡪ᝔"),wx18CTJPZ5(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓ࠮࠴ࡱࡨࠬኸ"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࡇࡣ࡯ࡷࡪ᝔"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࡇࡣ࡯ࡷࡪ᝔"))
				elif U5ZuMg9qvXHd2CpfyxB7ToaRs==CgPbwXm1RilpJUSGHLhy(u"࠸ᚸ"):
					e1AmZsUS9HY3Gv74PuVf = Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷ࡣ࠴ࡦ࠶ࡥࡪ࠷࠸࠶ࡦࡩ࠸ࡧ࡬࠶ࡢࡨ࠸࠷࠸ࡩ࠷࠱࠶࠳ࡦ࠸࠺࠷ࡤ࠻ࡨ࠽࠾ࡨࡥ࠵࠸࠹ࡥࡪ࠿࠺ࡁࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫࠮ࡥࡱ࠽࠼࠵࠾࠰ࠨኹ")
					FF976NUWy3wVxBvP = M08MPGgsh4n5rKe+Kwl07iYTtDLN3zP(u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭ኺ")+e1AmZsUS9HY3Gv74PuVf+qFRrj7ayBKbOsHGSXz(u"ࠧࡽࡾࡑࡳ࡛࡫ࡲࡪࡨࡼࡗࡘࡒࠧኻ")
					B3swpfRvj2 = wxZf9B2mrgOaqpK83FQIy65W(VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF,FF976NUWy3wVxBvP,YReuIJ67GDs8NwEiZOAh4xPMb,XzfkYQBICVuSjcL5G0pgy9T16xv,N1N2sUZu9QXRLj6rFeHEKg,Ox8k6IdtuPaG3NlApQK52oYwM(u"ࡈࡤࡰࡸ࡫᝕"),ItgK5FqGDz2Rf7mAJkbT(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗ࠲࠹ࡲࡥࠩኼ"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࡈࡤࡰࡸ࡫᝕"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࡈࡤࡰࡸ࡫᝕"))
				elif U5ZuMg9qvXHd2CpfyxB7ToaRs==Ox8k6IdtuPaG3NlApQK52oYwM(u"࠳ᚹ"):
					e1AmZsUS9HY3Gv74PuVf = MM564HfnUV0XIR(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡧࡷࡧࡰࡦࡴࡤࡴ࡮ࡀ࠷࠷ࡤ࠷ࡪࡨ࠹࠴ࡧࡥࡧ࠵࠾ࡪ࠹ࡤ࠷࠸ࡥ࠶࠻ࡦ࠴࠸࠳࠸ࡨࡪ࠹࠲࠶ࡦࡄࡵࡸ࡯ࡹࡻ࠰ࡷࡪࡸࡶࡦࡴ࠱ࡷࡨࡸࡡࡱࡧࡵࡥࡵ࡯࠮ࡤࡱࡰ࠾࠽࠶࠰࠲ࠩኽ")
					FF976NUWy3wVxBvP = M08MPGgsh4n5rKe+smpniPDOhfwI3H4v7c6TG(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪኾ")+e1AmZsUS9HY3Gv74PuVf+cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫ኿")
					B3swpfRvj2 = wxZf9B2mrgOaqpK83FQIy65W(VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF,FF976NUWy3wVxBvP,YReuIJ67GDs8NwEiZOAh4xPMb,XzfkYQBICVuSjcL5G0pgy9T16xv,N1N2sUZu9QXRLj6rFeHEKg,showDialogs,smpniPDOhfwI3H4v7c6TG(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࠯࠷ࡸ࡭࠭ዀ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࡉࡥࡱࡹࡥ᝖"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࡉࡥࡱࡹࡥ᝖"))
				else: B3swpfRvj2 = WcPEG7nehsCwig809NyHMZ
				G4KzAhcON3gwns1o5rIbai2FDJEXmy,rreason = B3swpfRvj2.code,B3swpfRvj2.reason
				if not B3swpfRvj2.succeeded:
					y75wQavkVSLUb2MZf9qo(NxsKJnLFEZ9OHXf1h(u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ዁"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+S26SnaqcM9XwK8PVphJDv5(u"ࠧࠡࠢࠣࠤࡋࡧࡩ࡭ࡧࡧࠤࡧࡿࡰࡢࡵࡶࠤࡸ࡫ࡣࡶࡴ࡬ࡸࡾࠦࡣࡩࡧࡦ࡯ࠥࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩዂ")+str(G4KzAhcON3gwns1o5rIbai2FDJEXmy)+bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠨࠢࡠࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩዃ")+rreason+NNmirJKPp5nWjfC(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫዄ")+dIsZG1fHm5YVkU6Puzq+Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩዅ")+FF976NUWy3wVxBvP+FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠫࠥࡣࠧ዆"))
					xa60ce2znAlyL5Z8ESXhO(S26SnaqcM9XwK8PVphJDv5(u"๊ࠬไฤีไࠤๆฺไࠡษ็ๅา฻ࠠศๆฦ้๋๐ࠧ዇"),ta478EuZQJIWhgBnsf6iU(u"࠭ฬาส้ࠣึฯࠠฤะิํࠬወ"),w6vebiEZtpCjJcILP8Skx5rHn=NxsKJnLFEZ9OHXf1h(u"࠳࠲࠳࠴ᚺ"))
				else:
					y75wQavkVSLUb2MZf9qo(tOdiG2HWFRBXg1sUh(u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭ዉ"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+ItgK5FqGDz2Rf7mAJkbT(u"ࠨࠢࠣࡗࡺࡩࡣࡦࡧࡧࡩࡩࠦࡢࡺࡲࡤࡷࡸࠦࡳࡦࡥࡸࡶ࡮ࡺࡹࠡࡥ࡫ࡩࡨࡱࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ዊ")+dIsZG1fHm5YVkU6Puzq+QmoEjB3hLIw(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨዋ")+FF976NUWy3wVxBvP+cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠪࠤࡢ࠭ዌ"))
					if U5ZuMg9qvXHd2CpfyxB7ToaRs in [Ox8k6IdtuPaG3NlApQK52oYwM(u"࠳ᚻ"),Kwl07iYTtDLN3zP(u"࠵ᚼ")]:
						PWYFla2xpTLRoEgzeQs = B3swpfRvj2.headers[Kwl07iYTtDLN3zP(u"ࠫࡘࡩࡲࡢࡲࡨ࠲ࡩࡵ࠭ࡓࡧࡰࡥ࡮ࡴࡩ࡯ࡩ࠰ࡇࡷ࡫ࡤࡪࡶࡶࠫው")]
						if U5ZuMg9qvXHd2CpfyxB7ToaRs==zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠵ᚽ"): if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(EAw9bg4rT3Bd8tjSkO(u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫ࡤࡰ࠳ࠪዎ"),PWYFla2xpTLRoEgzeQs)
						if U5ZuMg9qvXHd2CpfyxB7ToaRs==uAl3gHavMJZL4xmNe62nDiBoQ(u"࠷ᚾ"): if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(S26SnaqcM9XwK8PVphJDv5(u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥࡥࡱ࠵ࠫዏ"),PWYFla2xpTLRoEgzeQs)
					xa60ce2znAlyL5Z8ESXhO(I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠧ็ฮะࠤฬ๊แฮืࠣห้ษๅ็์ࠪዐ"),ta478EuZQJIWhgBnsf6iU(u"ࠨࡕࡸࡧࡨ࡫ࡳࡴࠩዑ"),w6vebiEZtpCjJcILP8Skx5rHn=dEUYJjrhsaPXNo(u"࠸࠰࠱࠲ᚿ"))
					return B3swpfRvj2
		A5vgi1F6qVunZMas2Nf = zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࡘࡷࡻࡥ᝗")
		if (jQdbDoanq4SyCYI916==NNmirJKPp5nWjfC(u"ࠩࡄࡗࡐ࠭ዒ") or fLjePgi96lUbn==Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠪࡅࡘࡑࠧዓ")) and (kQ36atvU4rpcWoH7MGdE8yCezZD1 or zcGCKESFR0Yt):
			A5vgi1F6qVunZMas2Nf = CCKZ1FbAdeyQIn6B9(G4KzAhcON3gwns1o5rIbai2FDJEXmy,rreason,dIsZG1fHm5YVkU6Puzq,showDialogs)
			if A5vgi1F6qVunZMas2Nf and jQdbDoanq4SyCYI916==I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠫࡆ࡙ࡋࠨዔ"): jQdbDoanq4SyCYI916 = FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧዕ")
			else: jQdbDoanq4SyCYI916 = ItgK5FqGDz2Rf7mAJkbT(u"࠭ࡒࡆࡌࡈࡇ࡙ࡋࡄࠨዖ")
			if A5vgi1F6qVunZMas2Nf and fLjePgi96lUbn==dEUYJjrhsaPXNo(u"ࠧࡂࡕࡎࠫ዗"): fLjePgi96lUbn = QmoEjB3hLIw(u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪዘ")
			else: fLjePgi96lUbn = bbqAtUz36RPGVTvCkejpJXQB(u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫዙ")
			if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(ta478EuZQJIWhgBnsf6iU(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ዚ"),jQdbDoanq4SyCYI916)
			if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(S26SnaqcM9XwK8PVphJDv5(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩዛ"),fLjePgi96lUbn)
		if A5vgi1F6qVunZMas2Nf:
			IpsrW2LyCVdk0cjnJH6ZhT = zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࡙ࡸࡵࡦ᝘")
			if G4KzAhcON3gwns1o5rIbai2FDJEXmy==ItgK5FqGDz2Rf7mAJkbT(u"࠸ᛀ") and YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠬ࡮ࡴࡵࡲࡶࠫዜ") in M08MPGgsh4n5rKe and IpsrW2LyCVdk0cjnJH6ZhT:
				if showDialogs: xa60ce2znAlyL5Z8ESXhO(QmoEjB3hLIw(u"࠭สโ฻ํ่ࠥ็อึࠢื๋ฬีษࠡษ็ฮู็๊าࠢࡖࡗࡑ࠭ዝ"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩዞ"),w6vebiEZtpCjJcILP8Skx5rHn=FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠳࠲࠳࠴ᛁ"))
				TW6JIBgC971tjOE = M08MPGgsh4n5rKe+bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠨࡾࡿࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨዟ")
				CqivWrSdG8cOo2DtkgV01 = wxZf9B2mrgOaqpK83FQIy65W(VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF,TW6JIBgC971tjOE,YReuIJ67GDs8NwEiZOAh4xPMb,XzfkYQBICVuSjcL5G0pgy9T16xv,N1N2sUZu9QXRLj6rFeHEKg,showDialogs,EAw9bg4rT3Bd8tjSkO(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠳࠵ࡵࡪࠪዠ"))
				if CqivWrSdG8cOo2DtkgV01.succeeded:
					WcPEG7nehsCwig809NyHMZ = CqivWrSdG8cOo2DtkgV01
					y75wQavkVSLUb2MZf9qo(NNmirJKPp5nWjfC(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩዡ"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+EAw9bg4rT3Bd8tjSkO(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪ࡫ࡤࡦࡦࠣࡹࡸ࡯࡮ࡨࠢࡖࡗࡑࡀࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ዢ")+dIsZG1fHm5YVkU6Puzq+tOdiG2HWFRBXg1sUh(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫዣ")+pAeIhbuLSFw7j49qxtcg8dDrmKO+ta478EuZQJIWhgBnsf6iU(u"࠭ࠠ࡞ࠩዤ"))
					if showDialogs: xa60ce2znAlyL5Z8ESXhO(uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠧ็ฮสัࠥฮวิฬัำฬ๋ࠠࡔࡕࡏࠫዥ"),tOdiG2HWFRBXg1sUh(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪዦ"),w6vebiEZtpCjJcILP8Skx5rHn=ta478EuZQJIWhgBnsf6iU(u"࠴࠳࠴࠵ᛂ"))
				else:
					y75wQavkVSLUb2MZf9qo(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧዧ"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠪࠤࠥࠦࡆࡢ࡫࡯ࡩࡩࠦࡵࡴ࡫ࡱ࡫࡙ࠥࡓࡍ࠼ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩየ")+dIsZG1fHm5YVkU6Puzq+MM564HfnUV0XIR(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪዩ")+pAeIhbuLSFw7j49qxtcg8dDrmKO+qFRrj7ayBKbOsHGSXz(u"ࠬࠦ࡝ࠨዪ"))
					if showDialogs: xa60ce2znAlyL5Z8ESXhO(Ox8k6IdtuPaG3NlApQK52oYwM(u"࠭แีๆࠣฬฬูสฯัส้࡙ࠥࡓࡍࠩያ"),ta478EuZQJIWhgBnsf6iU(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩዬ"),w6vebiEZtpCjJcILP8Skx5rHn=bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠵࠴࠵࠶ᛃ"))
			if not WcPEG7nehsCwig809NyHMZ.succeeded and fLjePgi96lUbn in [WbM6qAjrn7fEXGZw(u"ࠨࡃࡘࡘࡔ࠭ይ"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠩࡄࡇࡈࡋࡐࡕࡇࡇࠫዮ")] and zcGCKESFR0Yt:
				if showDialogs: xa60ce2znAlyL5Z8ESXhO(GGCQK6OAtZUXRhvkgJm(u"ࠪฮๆ฿๊ๅࠢึ๎ึ็ัศฬࠣฬึ๎ใิ์ࠪዯ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ደ"),w6vebiEZtpCjJcILP8Skx5rHn=qFRrj7ayBKbOsHGSXz(u"࠶࠵࠶࠰ᛄ"))
				CqivWrSdG8cOo2DtkgV01 = PoxF3Z7ifK2h8O(VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF,M08MPGgsh4n5rKe,YReuIJ67GDs8NwEiZOAh4xPMb,XzfkYQBICVuSjcL5G0pgy9T16xv,N1N2sUZu9QXRLj6rFeHEKg,showDialogs,I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࠯࠹ࡸ࡭࠭ዱ"))
				if CqivWrSdG8cOo2DtkgV01.succeeded:
					WcPEG7nehsCwig809NyHMZ = CqivWrSdG8cOo2DtkgV01
					y75wQavkVSLUb2MZf9qo(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬዲ"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+r6juULGQtnExAko38BZ5Y(u"ࠧࠡࠢࠣࡔࡷࡵࡸࡪࡧࡶࠤࡸࡻࡣࡤࡧࡨࡨࡪࡪ࠺ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧዳ")+dIsZG1fHm5YVkU6Puzq+QmoEjB3hLIw(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧዴ")+pAeIhbuLSFw7j49qxtcg8dDrmKO+SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠩࠣࡡࠬድ"))
					if showDialogs: xa60ce2znAlyL5Z8ESXhO(Ox8k6IdtuPaG3NlApQK52oYwM(u"๊ࠪัออࠡีํีๆืวหࠢหีํ้ำ๋ࠩዶ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ዷ"),w6vebiEZtpCjJcILP8Skx5rHn=NNmirJKPp5nWjfC(u"࠷࠶࠰࠱ᛅ"))
				else:
					y75wQavkVSLUb2MZf9qo(r6juULGQtnExAko38BZ5Y(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪዸ"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+wx18CTJPZ5(u"࠭ࠠࠡࠢࡓࡶࡴࡾࡩࡦࡵࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪዹ")+dIsZG1fHm5YVkU6Puzq+FeyZbj8tDil0nSHzTwfsUJ9(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ዺ")+pAeIhbuLSFw7j49qxtcg8dDrmKO+YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠨࠢࡠࠫዻ"))
					if showDialogs: xa60ce2znAlyL5Z8ESXhO(QmoEjB3hLIw(u"ࠩไุ้ࠦำ๋ำไีฬะࠠษำ๋็ุ๐ࠧዼ"),qFRrj7ayBKbOsHGSXz(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬዽ"),w6vebiEZtpCjJcILP8Skx5rHn=I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠸࠰࠱࠲ᛆ"))
			if not WcPEG7nehsCwig809NyHMZ.succeeded and jQdbDoanq4SyCYI916 in [MM564HfnUV0XIR(u"ࠫࡆ࡛ࡔࡐࠩዾ"),ta478EuZQJIWhgBnsf6iU(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧዿ")] and kQ36atvU4rpcWoH7MGdE8yCezZD1:
				if showDialogs: xa60ce2znAlyL5Z8ESXhO(ta478EuZQJIWhgBnsf6iU(u"࠭สโ฻ํู่๊ࠥาใิࠤࡉࡔࡓࠨጀ"),dEUYJjrhsaPXNo(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩጁ"),w6vebiEZtpCjJcILP8Skx5rHn=qFRrj7ayBKbOsHGSXz(u"࠲࠱࠲࠳ᛇ"))
				TW6JIBgC971tjOE = M08MPGgsh4n5rKe+bbqAtUz36RPGVTvCkejpJXQB(u"ࠨࡾࡿࡑࡾࡊࡎࡔࡗࡵࡰࡂ࠭ጂ")
				CqivWrSdG8cOo2DtkgV01 = wxZf9B2mrgOaqpK83FQIy65W(VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF,TW6JIBgC971tjOE,YReuIJ67GDs8NwEiZOAh4xPMb,XzfkYQBICVuSjcL5G0pgy9T16xv,N1N2sUZu9QXRLj6rFeHEKg,showDialogs,MM564HfnUV0XIR(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠳࠷ࡵࡪࠪጃ"))
				if CqivWrSdG8cOo2DtkgV01.succeeded:
					WcPEG7nehsCwig809NyHMZ = CqivWrSdG8cOo2DtkgV01
					y75wQavkVSLUb2MZf9qo(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩጄ"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+WbM6qAjrn7fEXGZw(u"ࠫࠥࠦࠠࡅࡐࡖࠤࡸࡻࡣࡤࡧࡨࡨࡪࡪ࠺ࠡࠢࠣࡈࡓ࡙࠺ࠡ࡝ࠣࠫጅ")+lbzUsDZE3MntmwucgjKa+Kwl07iYTtDLN3zP(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧጆ")+dIsZG1fHm5YVkU6Puzq+wx18CTJPZ5(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬጇ")+pAeIhbuLSFw7j49qxtcg8dDrmKO+FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠧࠡ࡟ࠪገ"))
					if showDialogs: xa60ce2znAlyL5Z8ESXhO(WbM6qAjrn7fEXGZw(u"ࠨ่ฯหาࠦำ๋ำไีࠥࡊࡎࡔࠩጉ"),r6juULGQtnExAko38BZ5Y(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫጊ"),w6vebiEZtpCjJcILP8Skx5rHn=zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠳࠲࠳࠴ᛈ"))
				else:
					y75wQavkVSLUb2MZf9qo(GGCQK6OAtZUXRhvkgJm(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨጋ"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠫࠥࠦࠠࡅࡐࡖࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠠࡅࡐࡖ࠾ࠥࡡࠠࠨጌ")+lbzUsDZE3MntmwucgjKa+GGCQK6OAtZUXRhvkgJm(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧግ")+dIsZG1fHm5YVkU6Puzq+Gk98CL5nXZEN(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬጎ")+pAeIhbuLSFw7j49qxtcg8dDrmKO+qFRrj7ayBKbOsHGSXz(u"ࠧࠡ࡟ࠪጏ"))
					if showDialogs: xa60ce2znAlyL5Z8ESXhO(ta478EuZQJIWhgBnsf6iU(u"ࠨใืู่๊ࠥาใิࠤࡉࡔࡓࠨጐ"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ጑"),w6vebiEZtpCjJcILP8Skx5rHn=ta478EuZQJIWhgBnsf6iU(u"࠴࠳࠴࠵ᛉ"))
		if fLjePgi96lUbn==Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠪࡖࡊࡐࡅࡄࡖࡈࡈࠬጒ") or jQdbDoanq4SyCYI916==ta478EuZQJIWhgBnsf6iU(u"ࠫࡗࡋࡊࡆࡅࡗࡉࡉ࠭ጓ"): showDialogs = I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࡌࡡ࡭ࡵࡨ᝙")
		if not WcPEG7nehsCwig809NyHMZ.succeeded:
			if showDialogs: Fncr184vpwJUPQt = CCKZ1FbAdeyQIn6B9(G4KzAhcON3gwns1o5rIbai2FDJEXmy,rreason,dIsZG1fHm5YVkU6Puzq,showDialogs)
			if G4KzAhcON3gwns1o5rIbai2FDJEXmy!=tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠵࠴࠵ᛊ") and dIsZG1fHm5YVkU6Puzq not in suRUkfjKA2BcL and QmoEjB3hLIw(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࠩጔ") not in dIsZG1fHm5YVkU6Puzq:
				X5LD1xAj8Nuas3b4pFHC(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠭ࡆࡰࡴࡦࡩࡩࠦࡥࡹ࡫ࡷࠤࡩࡻࡥࠡࡶࡲࠤࡳ࡫ࡴࡸࡱࡵ࡯ࠥ࡯ࡳࡴࡷࡨࡷࠥࡽࡩࡵࡪ࠽ࠤࠬጕ")+dIsZG1fHm5YVkU6Puzq)
	if if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(CIcPowhneWs5tN3(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪ጖")) not in [NNmirJKPp5nWjfC(u"ࠨࡃࡘࡘࡔ࠭጗"),ItgK5FqGDz2Rf7mAJkbT(u"ࠩࡖࡘࡔࡖࠧጘ"),GGCQK6OAtZUXRhvkgJm(u"ࠪࡅࡘࡑࠧጙ")]: if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(bbqAtUz36RPGVTvCkejpJXQB(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧጚ"),GGCQK6OAtZUXRhvkgJm(u"ࠬࡇࡓࡌࠩጛ"))
	if if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(WbM6qAjrn7fEXGZw(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫጜ")) not in [QmoEjB3hLIw(u"ࠧࡂࡗࡗࡓࠬጝ"),tOdiG2HWFRBXg1sUh(u"ࠨࡕࡗࡓࡕ࠭ጞ"),GGCQK6OAtZUXRhvkgJm(u"ࠩࡄࡗࡐ࠭ጟ")]: if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(CgPbwXm1RilpJUSGHLhy(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨጠ"),smpniPDOhfwI3H4v7c6TG(u"ࠫࡆ࡙ࡋࠨጡ"))
	return WcPEG7nehsCwig809NyHMZ
def OOA8T7f5Cl9WPgvoItykRc3M(A2UGrN4JhjOEXKF3CmIogxRLtaBHye,VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF,pAeIhbuLSFw7j49qxtcg8dDrmKO,YReuIJ67GDs8NwEiZOAh4xPMb,XzfkYQBICVuSjcL5G0pgy9T16xv,N1N2sUZu9QXRLj6rFeHEKg,showDialogs,dIsZG1fHm5YVkU6Puzq,kQ36atvU4rpcWoH7MGdE8yCezZD1=I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠬ࠭ጢ"),zcGCKESFR0Yt=CgPbwXm1RilpJUSGHLhy(u"࠭ࠧጣ")):
	M08MPGgsh4n5rKe,LO2kNuoIli,p9ug8BqHR1ih7yWmNsDVGf3TUrk,UkVahO6eMJNDwImjBo1L7 = mXQV431NeJRFtUPEnia(pAeIhbuLSFw7j49qxtcg8dDrmKO)
	DUacmNFpbwv13uylo = VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF,M08MPGgsh4n5rKe,YReuIJ67GDs8NwEiZOAh4xPMb,XzfkYQBICVuSjcL5G0pgy9T16xv,N1N2sUZu9QXRLj6rFeHEKg
	if A2UGrN4JhjOEXKF3CmIogxRLtaBHye:
		Il5iAWS8vkNBe4Xf = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩጤ"),MM564HfnUV0XIR(u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࠫጥ"),DUacmNFpbwv13uylo)
		if Il5iAWS8vkNBe4Xf.succeeded:
			ynWephC0J6VPiHcqmrg8d(bbqAtUz36RPGVTvCkejpJXQB(u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡖࠤࠥࡘࡅࡂࡆࡢࡇࡆࡉࡈࡆࠩጦ"),M08MPGgsh4n5rKe,YReuIJ67GDs8NwEiZOAh4xPMb,XzfkYQBICVuSjcL5G0pgy9T16xv,dIsZG1fHm5YVkU6Puzq,VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF)
			return Il5iAWS8vkNBe4Xf
	Il5iAWS8vkNBe4Xf = wxZf9B2mrgOaqpK83FQIy65W(VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF,pAeIhbuLSFw7j49qxtcg8dDrmKO,YReuIJ67GDs8NwEiZOAh4xPMb,XzfkYQBICVuSjcL5G0pgy9T16xv,N1N2sUZu9QXRLj6rFeHEKg,showDialogs,dIsZG1fHm5YVkU6Puzq,kQ36atvU4rpcWoH7MGdE8yCezZD1,zcGCKESFR0Yt)
	if Il5iAWS8vkNBe4Xf.succeeded:
		if CgPbwXm1RilpJUSGHLhy(u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫጧ") in dIsZG1fHm5YVkU6Puzq: Il5iAWS8vkNBe4Xf.content = K9hUtLagkSbDiwM1(Il5iAWS8vkNBe4Xf.content)
		if A2UGrN4JhjOEXKF3CmIogxRLtaBHye: kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,WbM6qAjrn7fEXGZw(u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙ࠧጨ"),DUacmNFpbwv13uylo,Il5iAWS8vkNBe4Xf,A2UGrN4JhjOEXKF3CmIogxRLtaBHye)
	return Il5iAWS8vkNBe4Xf
def MQeSPGrtXET1ahZjnwVmcxfF32(A2UGrN4JhjOEXKF3CmIogxRLtaBHye,pAeIhbuLSFw7j49qxtcg8dDrmKO,YReuIJ67GDs8NwEiZOAh4xPMb,XzfkYQBICVuSjcL5G0pgy9T16xv,showDialogs,dIsZG1fHm5YVkU6Puzq):
	if not YReuIJ67GDs8NwEiZOAh4xPMb or isinstance(YReuIJ67GDs8NwEiZOAh4xPMb,dict): VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF = cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠬࡍࡅࡕࠩጩ")
	else:
		VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF = CIcPowhneWs5tN3(u"࠭ࡐࡐࡕࡗࠫጪ")
		YReuIJ67GDs8NwEiZOAh4xPMb = BUTSkzgFC7(YReuIJ67GDs8NwEiZOAh4xPMb)
		jY8XDGpZRFOBkmA2KJbgExf7ilLedH,YReuIJ67GDs8NwEiZOAh4xPMb = NHyOSR4BdqaXfCpK0EU8vroiDJ2T(YReuIJ67GDs8NwEiZOAh4xPMb)
	Il5iAWS8vkNBe4Xf = OOA8T7f5Cl9WPgvoItykRc3M(A2UGrN4JhjOEXKF3CmIogxRLtaBHye,VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF,pAeIhbuLSFw7j49qxtcg8dDrmKO,YReuIJ67GDs8NwEiZOAh4xPMb,XzfkYQBICVuSjcL5G0pgy9T16xv,ItgK5FqGDz2Rf7mAJkbT(u"ࡔࡳࡷࡨ᝚"),showDialogs,dIsZG1fHm5YVkU6Puzq)
	TcPFsujHEQG3vBwCt = Il5iAWS8vkNBe4Xf.content
	TcPFsujHEQG3vBwCt = str(TcPFsujHEQG3vBwCt)
	return TcPFsujHEQG3vBwCt
def mXQV431NeJRFtUPEnia(pAeIhbuLSFw7j49qxtcg8dDrmKO):
	m0TWKkH468YLUXe2fzn3hpOJMbEagD = pAeIhbuLSFw7j49qxtcg8dDrmKO.split(ta478EuZQJIWhgBnsf6iU(u"ࠧࡽࡾࠪጫ"))
	M08MPGgsh4n5rKe,LO2kNuoIli,p9ug8BqHR1ih7yWmNsDVGf3TUrk,UkVahO6eMJNDwImjBo1L7 = m0TWKkH468YLUXe2fzn3hpOJMbEagD[dEUYJjrhsaPXNo(u"࠴ᛋ")],None,None,ta478EuZQJIWhgBnsf6iU(u"ࡕࡴࡸࡩ᝛")
	for DUacmNFpbwv13uylo in m0TWKkH468YLUXe2fzn3hpOJMbEagD:
		if cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠨࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭ጬ") in DUacmNFpbwv13uylo: LO2kNuoIli = DUacmNFpbwv13uylo.split(cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠩࡀࠫጭ"))[EAw9bg4rT3Bd8tjSkO(u"࠶ᛌ")]
		elif I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠪࡑࡾࡊࡎࡔࡗࡵࡰࡂ࠭ጮ") in DUacmNFpbwv13uylo: p9ug8BqHR1ih7yWmNsDVGf3TUrk = DUacmNFpbwv13uylo.split(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠫࡂ࠭ጯ"))[qFRrj7ayBKbOsHGSXz(u"࠷ᛍ")]
		elif bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠬࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪጰ") in DUacmNFpbwv13uylo: UkVahO6eMJNDwImjBo1L7 = wx18CTJPZ5(u"ࡈࡤࡰࡸ࡫᝜")
	return M08MPGgsh4n5rKe,LO2kNuoIli,p9ug8BqHR1ih7yWmNsDVGf3TUrk,UkVahO6eMJNDwImjBo1L7
def zVi6a89ZyBcjwfkF(TDmqAUj2Mfyir0PvS):
	goT6LXmwakYMNQqbRO0pv,VewOrPR4kX,AD9qpVnfkYeU052aNlF = FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠭ࠧጱ"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࠧࠨጲ"),NNmirJKPp5nWjfC(u"ࠨࠩጳ")
	TDmqAUj2Mfyir0PvS = TDmqAUj2Mfyir0PvS.replace(W3oZ8vhLnsOdIaDp6qeN214kcJCVz,NxsKJnLFEZ9OHXf1h(u"ࠩࠪጴ")).replace(HwksZdFnbNg3Pr,S26SnaqcM9XwK8PVphJDv5(u"ࠪࠫጵ"))
	e1ebv6pD8mUitJkPXqwnjr = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠫ࠭࠴ࠩ࡝࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺࡟ࡡ࠭ࡢࡷ࡝ࡹ࡟ࡻ࠮ࠦࠫ࡝࡝࡟࠳ࡈࡕࡌࡐࡔ࡟ࡡ࠭࠴ࠪࡀࠫࠧࠫጶ"),TDmqAUj2Mfyir0PvS,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if e1ebv6pD8mUitJkPXqwnjr: goT6LXmwakYMNQqbRO0pv,VewOrPR4kX,TDmqAUj2Mfyir0PvS = e1ebv6pD8mUitJkPXqwnjr[tOdiG2HWFRBXg1sUh(u"࠰ᛎ")]
	if goT6LXmwakYMNQqbRO0pv not in [CIcPowhneWs5tN3(u"ࠬࠦࠧጷ"),MM564HfnUV0XIR(u"࠭ࠬࠨጸ"),dEUYJjrhsaPXNo(u"ࠧࠨጹ")]: AD9qpVnfkYeU052aNlF = NNmirJKPp5nWjfC(u"ࠨࡡࡐࡓࡉࡥࠧጺ")
	if VewOrPR4kX: VewOrPR4kX = dEUYJjrhsaPXNo(u"ࠩࡢࠫጻ")+VewOrPR4kX+MM564HfnUV0XIR(u"ࠪࡣࠬጼ")
	TDmqAUj2Mfyir0PvS = VewOrPR4kX+AD9qpVnfkYeU052aNlF+TDmqAUj2Mfyir0PvS
	return TDmqAUj2Mfyir0PvS
def n4shroLZX1NF5yAzVqtJWGk(A2UGrN4JhjOEXKF3CmIogxRLtaBHye,VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF,pAeIhbuLSFw7j49qxtcg8dDrmKO,xZv2dKnAX17P,UZ7cH6L5efV,MqLjKgAlkOnQom,XzfkYQBICVuSjcL5G0pgy9T16xv=FeyZbj8tDil0nSHzTwfsUJ9(u"ࠫࠬጽ")):
	DEIQ14CTRt5wUSZaA7gG3ydiJPph = SLMTm6RQ34ic7v5s9rBG(pAeIhbuLSFw7j49qxtcg8dDrmKO,QmoEjB3hLIw(u"ࠬࡻࡲ࡭ࠩጾ"))
	OOQ8Kp1tByMuUr5qAeI6xoaYsFgTh = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(ItgK5FqGDz2Rf7mAJkbT(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨጿ")+xZv2dKnAX17P)
	if DEIQ14CTRt5wUSZaA7gG3ydiJPph==OOQ8Kp1tByMuUr5qAeI6xoaYsFgTh: if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(dEUYJjrhsaPXNo(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩፀ")+xZv2dKnAX17P,bbqAtUz36RPGVTvCkejpJXQB(u"ࠨࠩፁ"))
	if OOQ8Kp1tByMuUr5qAeI6xoaYsFgTh: TW6JIBgC971tjOE = pAeIhbuLSFw7j49qxtcg8dDrmKO.replace(DEIQ14CTRt5wUSZaA7gG3ydiJPph,OOQ8Kp1tByMuUr5qAeI6xoaYsFgTh)
	else:
		TW6JIBgC971tjOE = pAeIhbuLSFw7j49qxtcg8dDrmKO
		OOQ8Kp1tByMuUr5qAeI6xoaYsFgTh = DEIQ14CTRt5wUSZaA7gG3ydiJPph
	CqivWrSdG8cOo2DtkgV01 = OOA8T7f5Cl9WPgvoItykRc3M(A2UGrN4JhjOEXKF3CmIogxRLtaBHye,VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF,TW6JIBgC971tjOE,FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠩࠪፂ"),XzfkYQBICVuSjcL5G0pgy9T16xv,Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠪࠫፃ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠫࠬፄ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠷ࡳࡵࠩፅ"))
	TcPFsujHEQG3vBwCt = CqivWrSdG8cOo2DtkgV01.content
	if wvkR1es6d0SrjxKt5FZTMUWz7a:
		try: TcPFsujHEQG3vBwCt = TcPFsujHEQG3vBwCt.decode(NNmirJKPp5nWjfC(u"࠭ࡵࡵࡨ࠻ࠫፆ"),r6juULGQtnExAko38BZ5Y(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧፇ"))
		except: pass
	G4KzAhcON3gwns1o5rIbai2FDJEXmy = CqivWrSdG8cOo2DtkgV01.code
	if G4KzAhcON3gwns1o5rIbai2FDJEXmy!=-EAw9bg4rT3Bd8tjSkO(u"࠳ᛏ") and (not CqivWrSdG8cOo2DtkgV01.succeeded or MqLjKgAlkOnQom not in TcPFsujHEQG3vBwCt):
		UZ7cH6L5efV = UZ7cH6L5efV.replace(r6juULGQtnExAko38BZ5Y(u"ࠨࠢࠪፈ"),QmoEjB3hLIw(u"ࠩ࠮ࠫፉ"))
		M08MPGgsh4n5rKe = CIcPowhneWs5tN3(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡩࡲࡳ࡬ࡲࡥ࠯ࡥࡲࡱ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡷ࠽ࠨፊ")+UZ7cH6L5efV
		TC7fWv2a1gLJGiAtN8 = {GGCQK6OAtZUXRhvkgJm(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨፋ"):uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠬ࠭ፌ")}
		WcPEG7nehsCwig809NyHMZ = OOA8T7f5Cl9WPgvoItykRc3M(A2UGrN4JhjOEXKF3CmIogxRLtaBHye,VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF,M08MPGgsh4n5rKe,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠭ࠧፍ"),TC7fWv2a1gLJGiAtN8,CgPbwXm1RilpJUSGHLhy(u"ࠧࠨፎ"),Gk98CL5nXZEN(u"ࠨࠩፏ"),dEUYJjrhsaPXNo(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠵ࡲࡩ࠭ፐ"))
		if WcPEG7nehsCwig809NyHMZ.succeeded:
			TcPFsujHEQG3vBwCt = WcPEG7nehsCwig809NyHMZ.content
			if wvkR1es6d0SrjxKt5FZTMUWz7a:
				try: TcPFsujHEQG3vBwCt = TcPFsujHEQG3vBwCt.decode(Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠪࡹࡹ࡬࠸ࠨፑ"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫፒ"))
				except: pass
			cc0O1M4e5jtfoq = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢ࠰࡞ࡺ࠮ࡡࡅ࠮ࠫࡁࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠭ፓ"),TcPFsujHEQG3vBwCt,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			Iko3pfi1y84 = [OOQ8Kp1tByMuUr5qAeI6xoaYsFgTh]
			j4LnI1JKSZgvQT = [NNmirJKPp5nWjfC(u"࠭ࡡࡱ࡭ࠪፔ"),S26SnaqcM9XwK8PVphJDv5(u"ࠧࡨࡱࡲ࡫ࡱ࡫ࠧፕ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠨࡶࡺ࡭ࡹࡺࡥࡳࠩፖ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪፗ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠪࡪࡦࡩࡥࡣࡱࡲ࡯ࠬፘ"),tOdiG2HWFRBXg1sUh(u"ࠫࡵ࡮ࡰࠨፙ"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠬࡧࡴ࡭ࡣࡴࠫፚ"),EAw9bg4rT3Bd8tjSkO(u"࠭ࡳࡪࡶࡨ࡭ࡳࡪࡩࡤࡧࡶࠫ፛"),CgPbwXm1RilpJUSGHLhy(u"ࠧࡴࡷࡵ࠲ࡱࡿࠧ፜"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠨࡤ࡯ࡳ࡬ࡹࡰࡰࡶࠪ፝"),ItgK5FqGDz2Rf7mAJkbT(u"ࠩ࡬ࡲ࡫ࡵࡲ࡮ࡧࡵࠫ፞"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠪࡷ࡮ࡺࡥ࡭࡫࡮ࡩࠬ፟"),wx18CTJPZ5(u"ࠫ࡮ࡴࡳࡵࡣࡪࡶࡦࡳࠧ፠"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠬࡹ࡮ࡢࡲࡦ࡬ࡦࡺࠧ፡"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠭ࡨࡵࡶࡳ࠱ࡪࡷࡵࡪࡸࠪ።"),wx18CTJPZ5(u"ࠧࡧࡣࡶࡩࡱࡶ࡬ࡶࡵࠪ፣")]
			for Hzywg9LuXC0reKT3D8h6WI in cc0O1M4e5jtfoq:
				if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in Hzywg9LuXC0reKT3D8h6WI for hht0cpXxWw2OzFS1jnUGebkJLBd85 in j4LnI1JKSZgvQT): continue
				OOQ8Kp1tByMuUr5qAeI6xoaYsFgTh = SLMTm6RQ34ic7v5s9rBG(Hzywg9LuXC0reKT3D8h6WI,cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠨࡷࡵࡰࠬ፤"))
				if OOQ8Kp1tByMuUr5qAeI6xoaYsFgTh in Iko3pfi1y84: continue
				if len(Iko3pfi1y84)==dEUYJjrhsaPXNo(u"࠻ᛐ"):
					y75wQavkVSLUb2MZf9qo(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ፥"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+bbqAtUz36RPGVTvCkejpJXQB(u"ࠪࠤࠥࠦࡇࡰࡱࡪࡰࡪࠦࡤࡪࡦࠣࡲࡴࡺࠠࡧ࡫ࡱࡨࠥࡧࠠ࡯ࡧࡺࠤ࡭ࡵࡳࡵࡰࡤࡱࡪࠦࠠࠡࡕ࡬ࡸࡪࡀࠠ࡜ࠢࠪ፦")+xZv2dKnAX17P+I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠫࠥࡣࠠࠡࡑ࡯ࡨ࠿࡛ࠦࠡࠩ፧")+DEIQ14CTRt5wUSZaA7gG3ydiJPph+zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠬࠦ࡝ࠨ፨"))
					if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨ፩")+xZv2dKnAX17P,ta478EuZQJIWhgBnsf6iU(u"ࠧࠨ፪"))
					break
				Iko3pfi1y84.append(OOQ8Kp1tByMuUr5qAeI6xoaYsFgTh)
				TW6JIBgC971tjOE = pAeIhbuLSFw7j49qxtcg8dDrmKO.replace(DEIQ14CTRt5wUSZaA7gG3ydiJPph,OOQ8Kp1tByMuUr5qAeI6xoaYsFgTh)
				CqivWrSdG8cOo2DtkgV01 = OOA8T7f5Cl9WPgvoItykRc3M(A2UGrN4JhjOEXKF3CmIogxRLtaBHye,VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF,TW6JIBgC971tjOE,Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠨࠩ፫"),XzfkYQBICVuSjcL5G0pgy9T16xv,tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠩࠪ፬"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠪࠫ፭"),WbM6qAjrn7fEXGZw(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤࡔࡅࡘࡡࡋࡓࡘ࡚ࡎࡂࡏࡈ࠱࠸ࡸࡤࠨ፮"))
				TcPFsujHEQG3vBwCt = CqivWrSdG8cOo2DtkgV01.content
				if CqivWrSdG8cOo2DtkgV01.succeeded and MqLjKgAlkOnQom in TcPFsujHEQG3vBwCt:
					y75wQavkVSLUb2MZf9qo(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ፯"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+CIcPowhneWs5tN3(u"࠭ࠠࠡࠢࡊࡳࡴ࡭࡬ࡦࠢࡩࡳࡺࡴࡤࠡࡣࠣࡲࡪࡽࠠࡩࡱࡶࡸࡳࡧ࡭ࡦࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭፰")+xZv2dKnAX17P+tOdiG2HWFRBXg1sUh(u"ࠧࠡ࡟ࠣࠤࠥࡔࡥࡸ࠼ࠣ࡟ࠥ࠭፱")+OOQ8Kp1tByMuUr5qAeI6xoaYsFgTh+EAw9bg4rT3Bd8tjSkO(u"ࠨࠢࡠࠤࠥࡕ࡬ࡥ࠼ࠣ࡟ࠥ࠭፲")+DEIQ14CTRt5wUSZaA7gG3ydiJPph+uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠩࠣࡡࠬ፳"))
					if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(NNmirJKPp5nWjfC(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࠬ፴")+xZv2dKnAX17P,OOQ8Kp1tByMuUr5qAeI6xoaYsFgTh)
					break
	return OOQ8Kp1tByMuUr5qAeI6xoaYsFgTh,TW6JIBgC971tjOE,CqivWrSdG8cOo2DtkgV01
def NNbLf2d3Slq6pV(hfNZTDrYABwyVcJQlqPS48xpHIi7s):
	yZ4oQEOmj5P2HST = {
	 smpniPDOhfwI3H4v7c6TG(u"ࠫࡴࡲࡤࠨ፵")			:ta478EuZQJIWhgBnsf6iU(u"่ࠬฯ๋็ࠪ፶")
	,bbqAtUz36RPGVTvCkejpJXQB(u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࡤࠨ፷")		:CgPbwXm1RilpJUSGHLhy(u"ࠧๆฬ๋ๆๆ࠭፸")
	,CIcPowhneWs5tN3(u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩ፹")		:tmcuvd397wjGXeWoDHMNpFB5h2VK(u"่ࠩๅ็๎ฯࠨ፺")
	,uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠪ࡫ࡴࡵࡤࠨ፻")			:EAw9bg4rT3Bd8tjSkO(u"ࠫั๐ฯࠨ፼")
	,ItgK5FqGDz2Rf7mAJkbT(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ፽")		:NxsKJnLFEZ9OHXf1h(u"࠭แีๆࠪ፾")
	,dEUYJjrhsaPXNo(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ፿")		:NNmirJKPp5nWjfC(u"ࠨ็ฯ่ิ࠭ᎀ")
	,tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠩࡹ࡭ࡩ࡫࡯ࠨᎁ")		:S26SnaqcM9XwK8PVphJDv5(u"ࠪๅ๏ี๊้ࠩᎂ")
	,wx18CTJPZ5(u"ࠫࡱ࡯ࡶࡦࠩᎃ")			:MM564HfnUV0XIR(u"่ࠬๆศหࠪᎄ")
	,FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠭ࡡ࡬ࡱࡤࡱࠬᎅ")		:EAw9bg4rT3Bd8tjSkO(u"ࠧๆ๊ๅ฽ࠥษใ้ษ่ࠤฬ๊โะ์่ࠫᎆ")
	,ItgK5FqGDz2Rf7mAJkbT(u"ࠨࡣ࡮ࡻࡦࡳࠧᎇ")		:qFRrj7ayBKbOsHGSXz(u"่ࠩ์็฿ࠠฤๅ๋ห๊ࠦวๅฮา๎ิ࠭ᎈ")
	,I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠪࡥࡰࡵࡡ࡮ࡥࡤࡱࠬᎉ")		:MM564HfnUV0XIR(u"๊ࠫ๎โฺࠢฦ็ํอๅࠡๅส้ࠬᎊ")
	,r6juULGQtnExAko38BZ5Y(u"ࠬࡧ࡬ࡢࡴࡤࡦࠬᎋ")		:NNmirJKPp5nWjfC(u"࠭ๅ้ไ฼ࠤ่๊ࠠศๆ฼ีอ࠭ᎌ")
	,ItgK5FqGDz2Rf7mAJkbT(u"ࠧࡢ࡮ࡩࡥࡹ࡯࡭ࡪࠩᎍ")		:YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠨ็๋ๆ฾ࠦวๅ็้ฬึࠦวๅใส฻๊๐ࠧᎎ")
	,qFRrj7ayBKbOsHGSXz(u"ࠩࡤࡰࡰࡧࡷࡵࡪࡤࡶࠬᎏ")	:CIcPowhneWs5tN3(u"้ࠪํู่ࠡไ้หฮࠦวๅๅ๋ฯึ࠭᎐")
	,WbM6qAjrn7fEXGZw(u"ࠫࡦࡲ࡭ࡢࡣࡵࡩ࡫࠭᎑")		:bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"๋่ࠬใ฻ࠣๆ๋อษࠡษ็้฾อัโࠩ᎒")
	,zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠭ࡡࡳࡤ࡯࡭ࡴࡴࡺࠨ᎓")		:smpniPDOhfwI3H4v7c6TG(u"ࠧๆ๊ๅ฽ࠥ฿ัษࠢ็๎ํ์าࠨ᎔")
	,FeyZbj8tDil0nSHzTwfsUJ9(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࡸ࡬ࡴࠬ᎕")	:I7N2lHpGfLPkwKxbOu6raYUgc5(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣࡺ࡮ࡶࠧ᎖")
	,YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠪࡩࡱࡩࡩ࡯ࡧࡰࡥࠬ᎗")		:bbqAtUz36RPGVTvCkejpJXQB(u"๊ࠫ๎โฺࠢสุ่๐ๆๆษࠪ᎘")
	,YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠬ࡮ࡥ࡭ࡣ࡯ࠫ᎙")		:uAl3gHavMJZL4xmNe62nDiBoQ(u"࠭ๅ้ไ฼ࠤ์๊วๅࠢํ์ฯ๐่ษࠩ᎚")
	,dEUYJjrhsaPXNo(u"ࠧࡤ࡫ࡰࡥ࡫ࡧ࡮ࡴࠩ᎛")		:GGCQK6OAtZUXRhvkgJm(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤๆอๆำࠩ᎜")
	,CIcPowhneWs5tN3(u"ࠩࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫ᎝")		:NNmirJKPp5nWjfC(u"้ࠪํู่ࠡึส๋ิࠦแ้ำํ์ࠬ᎞")
	,YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠫࡸ࡮࡯ࡰࡨࡰࡥࡽ࠭᎟")		:GGCQK6OAtZUXRhvkgJm(u"๋่ࠬใ฻ุࠣํ็ࠠๆษๆืࠬᎠ")
	,GGCQK6OAtZUXRhvkgJm(u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨᎡ")		:SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠧๆ๊ๅ฽ࠥ฿ัษࠢึ๎๏ีࠧᎢ")
	,NxsKJnLFEZ9OHXf1h(u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩᎣ")		:WbM6qAjrn7fEXGZw(u"่ࠩ์็฿ࠠิ์่หࠥ์ว้ࠩᎤ")
	,dEUYJjrhsaPXNo(u"ࠪ࡯ࡦࡸࡢࡢ࡮ࡤࡸࡻ࠭Ꭵ")	:WbM6qAjrn7fEXGZw(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠไำห่ฬวࠧᎦ")
	,EAw9bg4rT3Bd8tjSkO(u"ࠬࡿࡴࡣࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫᎧ")	:FeyZbj8tDil0nSHzTwfsUJ9(u"࠭ๅ้ษๅ฽ࠥ๐่ห์๋ฬࠬᎨ")
	,zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠧ࡮ࡻࡦ࡭ࡲࡧࠧᎩ")		:I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠨ็๋ๆ฾ࠦๅศ์ࠣื๏๋วࠨᎪ")
	,bbqAtUz36RPGVTvCkejpJXQB(u"ࠩࡺࡩࡨ࡯࡭ࡢࠩᎫ")		:bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"้ࠪํู่๊ࠡํࠤุ๐ๅศࠩᎬ")
	,smpniPDOhfwI3H4v7c6TG(u"ࠫ࡫ࡧࡳࡦ࡮࡫ࡨ࠶࠭Ꭽ")		:QmoEjB3hLIw(u"๋่ࠬใ฻ࠣๅฬ฻ไࠡษ็วํ๊ࠧᎮ")
	,bbqAtUz36RPGVTvCkejpJXQB(u"࠭ࡦࡢࡵࡨࡰ࡭ࡪ࠲ࠨᎯ")		:NxsKJnLFEZ9OHXf1h(u"ࠧๆ๊ๅ฽ࠥ็วึๆࠣห้ัว็์ࠪᎰ")
	,QmoEjB3hLIw(u"ࠨࡤࡲ࡯ࡷࡧࠧᎱ")		:zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"่ࠩ์็฿ࠠษๅิหࠬᎲ")
	,EAw9bg4rT3Bd8tjSkO(u"ࠪࡧ࡮ࡳࡡࡢࡤࡧࡳࠬᎳ")		:I7N2lHpGfLPkwKxbOu6raYUgc5(u"๊ࠫ๎โฺࠢึ๎๊อฺࠠสา์ࠬᎴ")
	,Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠬࡲࡩࡷࡧࡷࡺࠬᎵ")		:YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠭ๅๅใࠪᎶ")
	,ta478EuZQJIWhgBnsf6iU(u"ࠧ࡭࡫ࡥࡶࡦࡸࡹࠨᎷ")		:wx18CTJPZ5(u"ࠨ็็ๅࠬᎸ")
	,SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠩࡰࡳࡻࡹ࠴ࡶࠩᎹ")		:SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"้ࠪํู่ࠡ็๋ๅืࠦแ้ำํ์ࠬᎺ")
	,I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠫ࡫ࡧࡪࡦࡴࡶ࡬ࡴࡽࠧᎻ")	:Kwl07iYTtDLN3zP(u"๋่ࠬใ฻ࠣๅัืࠠี๊ࠪᎼ")
	,ItgK5FqGDz2Rf7mAJkbT(u"࠭ࡥࡨࡻࡥࡩࡸࡺࠧᎽ")		:Kwl07iYTtDLN3zP(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠨᎾ")
	,bbqAtUz36RPGVTvCkejpJXQB(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠳ࠪᎿ")		:S26SnaqcM9XwK8PVphJDv5(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠵ࠬᏀ")
	,Gk98CL5nXZEN(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠶ࠬᏁ")		:ta478EuZQJIWhgBnsf6iU(u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠸ࠧᏂ")
	,GGCQK6OAtZUXRhvkgJm(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠹ࠧᏃ")		:QmoEjB3hLIw(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠴ࠩᏄ")
	,Gk98CL5nXZEN(u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠵ࠩᏅ")		:uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠷ࠫᏆ")
	,r6juULGQtnExAko38BZ5Y(u"ࠩࡦ࡭ࡲࡧ࠴ࡶࠩᏇ")		:qFRrj7ayBKbOsHGSXz(u"้ࠪํู่ࠡีํ้ฬࠦแ้ำํ์ࠬᏈ")
	,SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠫࡪ࡭ࡹ࡯ࡱࡺࠫᏉ")		:Kwl07iYTtDLN3zP(u"๋่ࠬใ฻ࠣษ๏า๊่ࠡส์ࠬᏊ")
	,Kwl07iYTtDLN3zP(u"࠭ࡥࡨࡻࡧࡩࡦࡪࠧᏋ")		:qFRrj7ayBKbOsHGSXz(u"ࠧๆ๊ๅ฽ࠥห๊อ์ࠣำ๏ีࠧᏌ")
	,S26SnaqcM9XwK8PVphJDv5(u"ࠨࡪࡤࡰࡦࡩࡩ࡮ࡣࠪᏍ")		:FeyZbj8tDil0nSHzTwfsUJ9(u"่ࠩ์็฿่ࠠๆสࠤุ๐ๅศࠩᏎ")
	,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠪࡰࡴࡪࡹ࡯ࡧࡷࠫᏏ")		:QmoEjB3hLIw(u"๊ࠫ๎โฺࠢ็์ิ๐ࠠ็ฬࠪᏐ")
	,tOdiG2HWFRBXg1sUh(u"ࠬࡺࡶࡧࡷࡱࠫᏑ")		:YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠭ๅ้ไ฼ࠤฯ๐แ๋ࠢไห๋࠭Ꮢ")
	,ta478EuZQJIWhgBnsf6iU(u"ࠧࡤ࡫ࡰࡥࡱ࡯ࡧࡩࡶࠪᏓ")	:YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ้อ๊หࠩᏔ")
	,qFRrj7ayBKbOsHGSXz(u"ࠩࡶ࡬ࡦ࡮ࡩࡥࡰࡨࡻࡸ࠭Ꮥ")	:NxsKJnLFEZ9OHXf1h(u"้ࠪํู่ࠡึส๋ิࠦๆ๋๊ีࠫᏖ")
	,FeyZbj8tDil0nSHzTwfsUJ9(u"ࠫ࡫ࡵࡳࡵࡣࠪᏗ")		:YDC9i52g6e8XL7GxvIFnSKWsolpr(u"๋่ࠬใ฻ࠣๅํูสศࠩᏘ")
	,Kwl07iYTtDLN3zP(u"࠭ࡡࡩࡹࡤ࡯ࠬᏙ")		:Kwl07iYTtDLN3zP(u"ࠧๆ๊ๅ฽ࠥษ็้ษๆࠤฯ๐แ๋ࠩᏚ")
	,NxsKJnLFEZ9OHXf1h(u"ࠨࡨࡤࡦࡷࡧ࡫ࡢࠩᏛ")		:WbM6qAjrn7fEXGZw(u"่ࠩ์็฿ࠠโสิ็ฮ࠭Ꮬ")
	,smpniPDOhfwI3H4v7c6TG(u"ࠪࡧ࡮ࡳࡡࡤ࡮ࡸࡦࡼࡵࡲ࡬ࠩᏝ")	:FeyZbj8tDil0nSHzTwfsUJ9(u"๊ࠫ๎โฺࠢึ๎๊อࠠไๆ๋ฬࠥ฿ๅๅࠩᏞ")
	,qFRrj7ayBKbOsHGSXz(u"ࠬࡩࡩ࡮ࡣࡦࡰࡺࡨࠧᏟ")		:CgPbwXm1RilpJUSGHLhy(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢๆ่ํฮࠧᏠ")
	,NxsKJnLFEZ9OHXf1h(u"ࠧࡴࡪࡲࡪ࡭ࡧࠧᏡ")		:r6juULGQtnExAko38BZ5Y(u"ࠨ็๋ๆ฾ࠦิ้ใ๊หࠥะ๊โ์ࠪᏢ")
	,Gk98CL5nXZEN(u"ࠩࡥࡶࡸࡺࡥ࡫ࠩᏣ")		:SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"้ࠪํู่ࠡสิืฯ๐ฬࠨᏤ")
	,zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠫࡨ࡯࡭ࡢ࠶࠳࠴ࠬᏥ")		:bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"๋่ࠬใ฻ࠣื๏๋วࠡ࠶࠳࠴ࠬᏦ")
	,zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠭࡬ࡢࡴࡲࡾࡦ࠭Ꮷ")		:qFRrj7ayBKbOsHGSXz(u"ࠧๆ๊ๅ฽๊ࠥวา๊ีหࠬᏨ")
	,wx18CTJPZ5(u"ࠨࡻࡤࡵࡴࡺࠧᏩ")		:uAl3gHavMJZL4xmNe62nDiBoQ(u"่ࠩ์็฿๋ࠠษๅ์ฯ࠭Ꮺ")
	,MM564HfnUV0XIR(u"ࠪ࡯ࡦࡺ࡫ࡰࡷࡷࡩࠬᏫ")		:uAl3gHavMJZL4xmNe62nDiBoQ(u"๊ࠫ๎โฺࠢๆฮ่๎สࠨᏬ")
	,CIcPowhneWs5tN3(u"ࠬࡱࡡࡵ࡭ࡲࡸࡹࡼࠧᏭ")		:tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠭ๅ้ไ฼ࠤ่ะใ้ฬࠣฮ๏็๊ࠨᏮ")
	,YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠧࡢࡴࡤࡦ࡮ࡩࡴࡰࡱࡱࡷࠬᏯ")	:uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠨ็๋ๆ฾ࠦส้่ีࠤ฾ืศ๋หࠪᏰ")
	,FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠩࡧࡶࡦࡳࡡࡴ࠹ࠪᏱ")		:CIcPowhneWs5tN3(u"้ࠪํู่ࠡัิห๊อࠠึฯࠪᏲ")
	,SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠫࡸ࡮࡯ࡰࡨࡳࡶࡴ࠭Ᏻ")		:FeyZbj8tDil0nSHzTwfsUJ9(u"๋่ࠬใ฻ุࠣํ็ࠠษำ๋ࠫᏴ")
	,ta478EuZQJIWhgBnsf6iU(u"࠭ࡩࡧ࡫࡯ࡱࠬᏵ")				:tOdiG2HWFRBXg1sUh(u"ࠧๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠫ᏶")
	,QmoEjB3hLIw(u"ࠨ࡫ࡩ࡭ࡱࡳ࠭ࡢࡴࡤࡦ࡮ࡩࠧ᏷")			:Kwl07iYTtDLN3zP(u"่ࠩ์็฿ࠠใ่สอࠥศ๊ࠡใํู่๊ࠦาสํࠫᏸ")
	,tOdiG2HWFRBXg1sUh(u"ࠪ࡭࡫࡯࡬࡮࠯ࡨࡲ࡬ࡲࡩࡴࡪࠪᏹ")		:bbqAtUz36RPGVTvCkejpJXQB(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠡษ้ะ้๐า๋ࠩᏺ")
	,CgPbwXm1RilpJUSGHLhy(u"ࠬࡶࡡ࡯ࡧࡷࠫᏻ")				:r6juULGQtnExAko38BZ5Y(u"࠭ๅ้ไ฼ࠤออๆ๋ฬࠪᏼ")
	,qFRrj7ayBKbOsHGSXz(u"ࠧࡱࡣࡱࡩࡹ࠳࡭ࡰࡸ࡬ࡩࡸ࠭ᏽ")			:SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠨ็๋ๆ฾ࠦศศ่ํฮࠥอแๅษ่ࠫ᏾")
	,Gk98CL5nXZEN(u"ࠩࡳࡥࡳ࡫ࡴ࠮ࡵࡨࡶ࡮࡫ࡳࠨ᏿")			:QmoEjB3hLIw(u"้ࠪํู่ࠡสส๊๏ะࠠๆี็ื้อสࠨ᐀")
	,YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬᐁ")				:cWfQ64kVCqxhwvSy5P7irHI1oes3(u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠪᐂ")
	,Kwl07iYTtDLN3zP(u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠧᐃ")		:Gk98CL5nXZEN(u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠥ็๊ะ์๋๋ฬะࠧᐄ")
	,FeyZbj8tDil0nSHzTwfsUJ9(u"ࠨࡻࡲࡹࡹࡻࡢࡦ࠯ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬᐅ")	:ItgK5FqGDz2Rf7mAJkbT(u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠใ๊สส๊࠭ᐆ")
	,SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠱ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ᐇ")		:Gk98CL5nXZEN(u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢๅ๊ํอสࠨᐈ")
	,ta478EuZQJIWhgBnsf6iU(u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥࠨᐉ")			:YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠨᐊ")
	,cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠧࡴࡪ࡬ࡥࡻࡵࡩࡤࡧ࠰ࡴࡪࡸࡳࡰࡰࡶࠫᐋ")	:r6juULGQtnExAko38BZ5Y(u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠣๆฬืฦࠨᐌ")
	,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠩࡶ࡬࡮ࡧࡶࡰ࡫ࡦࡩ࠲ࡧ࡬ࡣࡷࡰࡷࠬᐍ")		:SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠥอไษ๊่ࠫᐎ")
	,ta478EuZQJIWhgBnsf6iU(u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫࠭ࡢࡷࡧ࡭ࡴࡹࠧᐏ")		:CgPbwXm1RilpJUSGHLhy(u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠠึ๊อ๎ฬะࠧᐐ")
	,r6juULGQtnExAko38BZ5Y(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫᐑ")			:EAw9bg4rT3Bd8tjSkO(u"ࠧๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠨᐒ")
	,tOdiG2HWFRBXg1sUh(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡶࡪࡦࡨࡳࡸ࠭ᐓ")	:I7N2lHpGfLPkwKxbOu6raYUgc5(u"่ࠩ์็฿ࠠะ์็๎๋่ࠥี่ࠣๅ๏ี๊้้สฮࠬᐔ")
	,ItgK5FqGDz2Rf7mAJkbT(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫᐕ"):FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"๊ࠫ๎โฺࠢา๎้๐ࠠๆ๊ื๊่่ࠥศศ่ࠫᐖ")
	,wx18CTJPZ5(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬᐗ")	:CIcPowhneWs5tN3(u"࠭ๅ้ไ฼ࠤิ๐ไ๋่ࠢ์ู์ࠠใ่๋หฯ࠭ᐘ")
	,S26SnaqcM9XwK8PVphJDv5(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡺ࡯ࡱ࡫ࡦࡷࠬᐙ")	:zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠨ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็่ࠢ์ฬ฼ฺ๊ࠩᐚ")
	,zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠩ࡬ࡴࡹࡼࠧᐛ")					:MM564HfnUV0XIR(u"ࠪࡍࡕ࡚ࡖࠨᐜ")
	,dEUYJjrhsaPXNo(u"ࠫ࡮ࡶࡴࡷ࠯࡯࡭ࡻ࡫ࠧᐝ")			:CIcPowhneWs5tN3(u"ࠬࡏࡐࡕࡘࠣๆ๋๎วหࠩᐞ")
	,CIcPowhneWs5tN3(u"࠭ࡩࡱࡶࡹ࠱ࡲࡵࡶࡪࡧࡶࠫᐟ")			:CgPbwXm1RilpJUSGHLhy(u"ࠧࡊࡒࡗ࡚ࠥษแๅษ่ࠫᐠ")
	,Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠨ࡫ࡳࡸࡻ࠳ࡳࡦࡴ࡬ࡩࡸ࠭ᐡ")			:tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠩࡌࡔ࡙࡜ࠠๆี็ื้อสࠨᐢ")
	,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠪࡱ࠸ࡻࠧᐣ")					:tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠫࡒ࠹ࡕࠨᐤ")
	,CgPbwXm1RilpJUSGHLhy(u"ࠬࡳ࠳ࡶ࠯࡯࡭ࡻ࡫ࠧᐥ")				:NNmirJKPp5nWjfC(u"࠭ࡍ࠴ࡗࠣๆ๋๎วหࠩᐦ")
	,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠧ࡮࠵ࡸ࠱ࡲࡵࡶࡪࡧࡶࠫᐧ")			:cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠨࡏ࠶࡙ࠥษแๅษ่ࠫᐨ")
	,S26SnaqcM9XwK8PVphJDv5(u"ࠩࡰ࠷ࡺ࠳ࡳࡦࡴ࡬ࡩࡸ࠭ᐩ")			:Gk98CL5nXZEN(u"ࠪࡑ࠸࡛ࠠๆี็ื้อสࠨᐪ")
	}
	try: ZZgB3EFfmntaRwlIzeKuA = yZ4oQEOmj5P2HST[hfNZTDrYABwyVcJQlqPS48xpHIi7s.lower()]
	except: ZZgB3EFfmntaRwlIzeKuA = CIcPowhneWs5tN3(u"ࠫࠬᐫ")
	return ZZgB3EFfmntaRwlIzeKuA
def X5LD1xAj8Nuas3b4pFHC(EiMsPpS3O1Ba=smpniPDOhfwI3H4v7c6TG(u"ࠬ࠭ᐬ")):
	knv97FU12sdyuZXGCa()
	if not EiMsPpS3O1Ba: EiMsPpS3O1Ba = bbqAtUz36RPGVTvCkejpJXQB(u"࠭ࡆࡰࡴࡦࡩࡩࠦࡅࡹ࡫ࡷࠫᐭ")
	y75wQavkVSLUb2MZf9qo(tOdiG2HWFRBXg1sUh(u"ࠧࠨᐮ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠨ࡞ࡱࠫᐯ")+EiMsPpS3O1Ba+smpniPDOhfwI3H4v7c6TG(u"ࠩ࡟ࡲࠬᐰ"))
	try: EAPND6zHKrMRuBc91tInYohsl0ywa.exit()
	except: pass
	return
def TaEr2nR3f5e8oXzpy(pAeIhbuLSFw7j49qxtcg8dDrmKO,OtQFhVx1KLq0wI7narm2Dc8=uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠪ࠾࠴࠭ᐱ")):
	return _j8zQmKbWeUoEOiLwMg72Tv10usdq(pAeIhbuLSFw7j49qxtcg8dDrmKO,OtQFhVx1KLq0wI7narm2Dc8)
def O4sq9fkURyuirp(MU6wfmO0k1qVxcoPB2NuWKe7D):
	if MU6wfmO0k1qVxcoPB2NuWKe7D in [bbqAtUz36RPGVTvCkejpJXQB(u"ࠫࠬᐲ"),tOdiG2HWFRBXg1sUh(u"ࠬ࠶ࠧᐳ"),tOdiG2HWFRBXg1sUh(u"࠳ᛑ")]: return Kwl07iYTtDLN3zP(u"࠭ࠧᐴ")
	MU6wfmO0k1qVxcoPB2NuWKe7D = int(MU6wfmO0k1qVxcoPB2NuWKe7D)
	rmIyRwADzZKOP5X = MU6wfmO0k1qVxcoPB2NuWKe7D^xgFTDVS7lf5Us6aj
	AAh9UpQ5JKxRLBac = MU6wfmO0k1qVxcoPB2NuWKe7D^Yv7e6ixHfZIPrmMOy3ozwJu2
	ahJVN4nZfeqg6CiL2ovHkwy = MU6wfmO0k1qVxcoPB2NuWKe7D^jEPuRTVbZg4MCimJxzf3I6wFa
	ZZgB3EFfmntaRwlIzeKuA = str(rmIyRwADzZKOP5X)+str(AAh9UpQ5JKxRLBac)+str(ahJVN4nZfeqg6CiL2ovHkwy)
	return ZZgB3EFfmntaRwlIzeKuA
def KKZCu9jkSDPnJzl3bT1(MU6wfmO0k1qVxcoPB2NuWKe7D):
	if MU6wfmO0k1qVxcoPB2NuWKe7D in [NNmirJKPp5nWjfC(u"ࠧࠨᐵ"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࠨ࠲ࠪᐶ"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠴ᛒ")]: return QmoEjB3hLIw(u"ࠩࠪᐷ")
	MU6wfmO0k1qVxcoPB2NuWKe7D = str(MU6wfmO0k1qVxcoPB2NuWKe7D)
	ZZgB3EFfmntaRwlIzeKuA = tOdiG2HWFRBXg1sUh(u"ࠪࠫᐸ")
	if len(MU6wfmO0k1qVxcoPB2NuWKe7D)==YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠶࠻ᛓ"):
		rmIyRwADzZKOP5X,AAh9UpQ5JKxRLBac,ahJVN4nZfeqg6CiL2ovHkwy = MU6wfmO0k1qVxcoPB2NuWKe7D[Kwl07iYTtDLN3zP(u"࠰ᛕ"):CIcPowhneWs5tN3(u"࠵ᛖ")],MU6wfmO0k1qVxcoPB2NuWKe7D[CIcPowhneWs5tN3(u"࠵ᛖ"):Kwl07iYTtDLN3zP(u"࠿ᛔ")],MU6wfmO0k1qVxcoPB2NuWKe7D[Kwl07iYTtDLN3zP(u"࠿ᛔ"):]
		rmIyRwADzZKOP5X = int(rmIyRwADzZKOP5X)^jEPuRTVbZg4MCimJxzf3I6wFa
		AAh9UpQ5JKxRLBac = int(AAh9UpQ5JKxRLBac)^Yv7e6ixHfZIPrmMOy3ozwJu2
		ahJVN4nZfeqg6CiL2ovHkwy = int(ahJVN4nZfeqg6CiL2ovHkwy)^xgFTDVS7lf5Us6aj
		if rmIyRwADzZKOP5X==AAh9UpQ5JKxRLBac==ahJVN4nZfeqg6CiL2ovHkwy: ZZgB3EFfmntaRwlIzeKuA = str(rmIyRwADzZKOP5X*Kwl07iYTtDLN3zP(u"࠸࠳ᛗ"))
	return ZZgB3EFfmntaRwlIzeKuA
def NfjyEgxeHGwpbu7QK3O1D(MU6wfmO0k1qVxcoPB2NuWKe7D,ih2cQR8eHaZMsbEz0JrUwBToGC3=Kwl07iYTtDLN3zP(u"ࠫ࠻࠹࠸࠵࠳࠻࠶࠸࠭ᐹ")):
	if MU6wfmO0k1qVxcoPB2NuWKe7D==CIcPowhneWs5tN3(u"ࠬ࠭ᐺ"): return CgPbwXm1RilpJUSGHLhy(u"࠭ࠧᐻ")
	MU6wfmO0k1qVxcoPB2NuWKe7D = int(MU6wfmO0k1qVxcoPB2NuWKe7D)+int(ih2cQR8eHaZMsbEz0JrUwBToGC3)
	rmIyRwADzZKOP5X = MU6wfmO0k1qVxcoPB2NuWKe7D^xgFTDVS7lf5Us6aj
	AAh9UpQ5JKxRLBac = MU6wfmO0k1qVxcoPB2NuWKe7D^Yv7e6ixHfZIPrmMOy3ozwJu2
	ahJVN4nZfeqg6CiL2ovHkwy = MU6wfmO0k1qVxcoPB2NuWKe7D^jEPuRTVbZg4MCimJxzf3I6wFa
	ZZgB3EFfmntaRwlIzeKuA = str(rmIyRwADzZKOP5X)+str(AAh9UpQ5JKxRLBac)+str(ahJVN4nZfeqg6CiL2ovHkwy)
	return ZZgB3EFfmntaRwlIzeKuA
def tGdhVg9jniercWDYB(MU6wfmO0k1qVxcoPB2NuWKe7D,ih2cQR8eHaZMsbEz0JrUwBToGC3=CgPbwXm1RilpJUSGHLhy(u"ࠧ࠷࠵࠻࠸࠶࠾࠲࠴ࠩᐼ")):
	if MU6wfmO0k1qVxcoPB2NuWKe7D==S26SnaqcM9XwK8PVphJDv5(u"ࠨࠩᐽ"): return dEUYJjrhsaPXNo(u"ࠩࠪᐾ")
	MU6wfmO0k1qVxcoPB2NuWKe7D = str(MU6wfmO0k1qVxcoPB2NuWKe7D)
	P6e9iLTvguIDEVpSwj2CGmkhlob73 = int(len(MU6wfmO0k1qVxcoPB2NuWKe7D)/r6juULGQtnExAko38BZ5Y(u"࠶ᛘ"))
	rmIyRwADzZKOP5X = int(MU6wfmO0k1qVxcoPB2NuWKe7D[ta478EuZQJIWhgBnsf6iU(u"࠴ᛙ"):P6e9iLTvguIDEVpSwj2CGmkhlob73])^xgFTDVS7lf5Us6aj
	AAh9UpQ5JKxRLBac = int(MU6wfmO0k1qVxcoPB2NuWKe7D[P6e9iLTvguIDEVpSwj2CGmkhlob73:smpniPDOhfwI3H4v7c6TG(u"࠷ᛚ")*P6e9iLTvguIDEVpSwj2CGmkhlob73])^Yv7e6ixHfZIPrmMOy3ozwJu2
	ahJVN4nZfeqg6CiL2ovHkwy = int(MU6wfmO0k1qVxcoPB2NuWKe7D[bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠲ᛜ")*P6e9iLTvguIDEVpSwj2CGmkhlob73:zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠹ᛛ")*P6e9iLTvguIDEVpSwj2CGmkhlob73])^jEPuRTVbZg4MCimJxzf3I6wFa
	ZZgB3EFfmntaRwlIzeKuA = CgPbwXm1RilpJUSGHLhy(u"ࠪࠫᐿ")
	if rmIyRwADzZKOP5X==AAh9UpQ5JKxRLBac==ahJVN4nZfeqg6CiL2ovHkwy: ZZgB3EFfmntaRwlIzeKuA = str(int(rmIyRwADzZKOP5X)-int(ih2cQR8eHaZMsbEz0JrUwBToGC3))
	return ZZgB3EFfmntaRwlIzeKuA
def jtzHRewuAVZ9WqomsIT5(HH9KDT0pyc):
	mukXoR2tE1jwIfzrLKdpFc6lNh = mR20sONyKIlV[Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫᑀ")][YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠹ᛝ")]
	def9smkOjiY28Fpwo = zVw5tvmZRX(dEUYJjrhsaPXNo(u"࠵࠵ᛞ"))
	h2hFVPH8avo0UyYwB1NJLjQ64Tmfl = K3hFytImeYMkJBC.path.join(U0AdbxBVqaQOwTJIcSgN1z9iM7r,I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠬࡸࡥࡴࡱࡸࡶࡨ࡫ࡳࠨᑁ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠭ࡳ࡬࡫ࡱࡷࠬᑂ"),Kwl07iYTtDLN3zP(u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨᑃ"),CgPbwXm1RilpJUSGHLhy(u"ࠨ࠹࠵࠴ࡵ࠭ᑄ"),dEUYJjrhsaPXNo(u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡅࡲࡲ࡫࡯ࡲ࡮ࡖ࡫ࡶࡪ࡫ࡂࡶࡶࡷࡳࡳࡹ࠮ࡹ࡯࡯ࠫᑅ"))
	zg4VPluaFR,cNwURZ0uTY2aQhxnDekK8lAIdmM5qr = Jy1ZPox93TVNYnKLzHvka(h2hFVPH8avo0UyYwB1NJLjQ64Tmfl)
	zg4VPluaFR = NfjyEgxeHGwpbu7QK3O1D(zg4VPluaFR,smpniPDOhfwI3H4v7c6TG(u"ࠪ࠵࠷࠷࠸࠴࠳࠻࠹࠸࠭ᑆ"))
	FJDBhwkld356XIWLeQHaEV = {ItgK5FqGDz2Rf7mAJkbT(u"ࠫ࡮ࡪࡳࠨᑇ"):QmoEjB3hLIw(u"ࠬࡊࡉࡂࡎࡒࡋࠬᑈ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠭ࡵࡴࡴࠪᑉ"):def9smkOjiY28Fpwo,zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠧࡷࡧࡵࠫᑊ"):VnhK9wvHBGuo1fei8DXQ02yFZtsWE,I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠨࡵࡦࡶࠬᑋ"):HH9KDT0pyc,tOdiG2HWFRBXg1sUh(u"ࠩࡶ࡭ࡿ࠭ᑌ"):zg4VPluaFR}
	eCjl1T4WImYG = {I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩᑍ"):cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪᑎ")}
	MjBq1mdFL4roaN0lycpf = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,FeyZbj8tDil0nSHzTwfsUJ9(u"ࠬࡖࡏࡔࡖࠪᑏ"),mukXoR2tE1jwIfzrLKdpFc6lNh,FJDBhwkld356XIWLeQHaEV,eCjl1T4WImYG,tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠭ࠧᑐ"),ItgK5FqGDz2Rf7mAJkbT(u"ࠧࠨᑑ"),MM564HfnUV0XIR(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡌࡔ࡝࡟ࡑࡎࡄ࡝ࡤࡊࡉࡂࡎࡒࡋ࠲࠷ࡳࡵࠩᑒ"))
	uZYVpr34oy8QIx7EU6mD2h = MjBq1mdFL4roaN0lycpf.content
	try:
		if not uZYVpr34oy8QIx7EU6mD2h: AAFx5NMYupJv43riTWQ
		S4SAleTdNaB6FsXrWJp = GVQAnvYCT3dS(ItgK5FqGDz2Rf7mAJkbT(u"ࠩࡧ࡭ࡨࡺࠧᑓ"),uZYVpr34oy8QIx7EU6mD2h)
		t5iX42sWBbj = S4SAleTdNaB6FsXrWJp[I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠪࡱࡸ࡭ࠧᑔ")]
		RO9tHjAYrZBI = S4SAleTdNaB6FsXrWJp[Gk98CL5nXZEN(u"ࠫࡸ࡫ࡣࠨᑕ")]
		PGDAdHMZ5L1p4rgTKJS9qVtwxIfX = S4SAleTdNaB6FsXrWJp[bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠬࡹࡴࡱࠩᑖ")]
		RO9tHjAYrZBI = int(tGdhVg9jniercWDYB(RO9tHjAYrZBI,I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠭࠱࠳࠳࠻࠷࠶࠾࠵࠴ࠩᑗ")))
		PGDAdHMZ5L1p4rgTKJS9qVtwxIfX = int(tGdhVg9jniercWDYB(PGDAdHMZ5L1p4rgTKJS9qVtwxIfX,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠧ࠲࠴࠴࠼࠸࠷࠸࠶࠵ࠪᑘ")))
		for ssbJk9LBK51xCpwifS7XYTG in range(RO9tHjAYrZBI,ta478EuZQJIWhgBnsf6iU(u"࠳ᛟ"),-PGDAdHMZ5L1p4rgTKJS9qVtwxIfX):
			if not eval(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠨࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯࡫ࡶࡔࡱࡧࡹࡪࡰࡪ࡚࡮ࡪࡥࡰࠪࠬࠫᑙ"),{YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠩࡻࡦࡲࡩࠧᑚ"):oos8ymFi9CN2z1jXcR}): AAFx5NMYupJv43riTWQ
			xa60ce2znAlyL5Z8ESXhO(wx18CTJPZ5(u"ࠪฬฬ่๊ࠡๆ็ฮัืศส๋ࠢห้็อึࠩᑛ"),str(ssbJk9LBK51xCpwifS7XYTG)+smpniPDOhfwI3H4v7c6TG(u"ࠫࠥࠦหศ่ํอࠬᑜ"),w6vebiEZtpCjJcILP8Skx5rHn=I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠷࠵࠶ᛠ")*PGDAdHMZ5L1p4rgTKJS9qVtwxIfX)
			oos8ymFi9CN2z1jXcR.sleep(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠶࠶࠰࠱ᛡ")*PGDAdHMZ5L1p4rgTKJS9qVtwxIfX)
		if eval(Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳࡯ࡳࡑ࡮ࡤࡽ࡮ࡴࡧࡗ࡫ࡧࡩࡴ࠮ࠩࠨᑝ"),{ItgK5FqGDz2Rf7mAJkbT(u"࠭ࡸࡣ࡯ࡦࠫᑞ"):oos8ymFi9CN2z1jXcR}):
			t5iX42sWBbj = t5iX42sWBbj.replace(qFRrj7ayBKbOsHGSXz(u"ࠧ࡝ࡰࠪᑟ"),Gk98CL5nXZEN(u"ࠨ࡞࡟ࡲࠬᑠ")).replace(dEUYJjrhsaPXNo(u"ࠩ࡟ࡶࠬᑡ"),NNmirJKPp5nWjfC(u"ࠪࡠࡡࡸࠧᑢ"))
			tehb3k5a2PufGOdBIUw8j(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠫࠬᑣ"),NNmirJKPp5nWjfC(u"ࠬิั้ฮࠪᑤ"),ta478EuZQJIWhgBnsf6iU(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᑥ"),t5iX42sWBbj)
		AAFx5NMYupJv43riTWQ
	except: exec(I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠧࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡴࡶࡲࡴ࠭࠯ࠧᑦ"),{QmoEjB3hLIw(u"ࠨࡺࡥࡱࡨ࠭ᑧ"):oos8ymFi9CN2z1jXcR})
	return
def IxG5DTtZj4bC0fJRl8():
	exec(GGCQK6OAtZUXRhvkgJm(u"ࠩࠪࠫࠒࠐࡴࡳࡻ࠽ࠑࠏࠏࡷࡪࡰࡧࡳࡼ࠷࠲࠴ࠢࡀࠤࡽࡨ࡭ࡤࡩࡸ࡭࠳࡝ࡩ࡯ࡦࡲࡻ࠭࠷࠰࠱࠴࠸࠭ࠒࠐࠉࡸࡪ࡬ࡰࡪࠦࡔࡳࡷࡨ࠾ࠒࠐࠉࠊࡺࡥࡱࡨ࠴ࡳ࡭ࡧࡨࡴ࠭࠷࠰࠱࠲ࠬࠑࠏࠏࠉࡵࡴࡼ࠾ࠥࡽࡩ࡯ࡦࡲࡻ࠶࠸࠳࠯ࡩࡨࡸࡋࡵࡣࡶࡵࠫ࠵࠵࠶࠲࠶ࠫࠐࠎࠎࠏࡥࡹࡥࡨࡴࡹࡀࠠࡣࡴࡨࡥࡰࠓࠊࠊࡼࡦࡶࡪࡧࡴࡦࡡࡨࡶࡴࡸࡲࠎࠌࡨࡼࡨ࡫ࡰࡵ࠼ࠣࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱ࡷࡹࡵࡰࠩࠫࠐࠎࠬ࠭ࠧᑨ"),{Gk98CL5nXZEN(u"ࠪࡼࡧࡳࡣࡨࡷ࡬ࠫᑩ"):ZuEAJR1lNHkUf0,uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠫࡽࡨ࡭ࡤࠩᑪ"):oos8ymFi9CN2z1jXcR})
	return
def Jy1ZPox93TVNYnKLzHvka(KIFHwWd5396VAiyepGrPNYsck0znB):
	eQwMcWNSyixhHtmoVG64A8JrTjDqRs,GG5hd4btHaJZ6uYWiXEoPFU3Of = zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠶ᛢ"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠶ᛢ")
	if K3hFytImeYMkJBC.path.exists(KIFHwWd5396VAiyepGrPNYsck0znB):
		try: eQwMcWNSyixhHtmoVG64A8JrTjDqRs = K3hFytImeYMkJBC.path.getsize(KIFHwWd5396VAiyepGrPNYsck0znB)
		except: pass
		if not eQwMcWNSyixhHtmoVG64A8JrTjDqRs:
			try: eQwMcWNSyixhHtmoVG64A8JrTjDqRs = K3hFytImeYMkJBC.stat(KIFHwWd5396VAiyepGrPNYsck0znB).st_size
			except: pass
		if not eQwMcWNSyixhHtmoVG64A8JrTjDqRs:
			try:
				from pathlib import Path as Fy2ixLlMz1oGT
				eQwMcWNSyixhHtmoVG64A8JrTjDqRs = Fy2ixLlMz1oGT(KIFHwWd5396VAiyepGrPNYsck0znB).stat().st_size
			except: pass
		if eQwMcWNSyixhHtmoVG64A8JrTjDqRs: GG5hd4btHaJZ6uYWiXEoPFU3Of = QmoEjB3hLIw(u"࠱ᛣ")
	return eQwMcWNSyixhHtmoVG64A8JrTjDqRs,GG5hd4btHaJZ6uYWiXEoPFU3Of
def oFHcGJSy62KieOMmZv4f0l(GBDHbTjC2I4d,NNb9rcQeglfBpys,showDialogs):
	if showDialogs:
		A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(EAw9bg4rT3Bd8tjSkO(u"ࠬ࠭ᑫ"),wx18CTJPZ5(u"࠭ࠧᑬ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠧࠨᑭ"),MM564HfnUV0XIR(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᑮ"),GBDHbTjC2I4d+WbM6qAjrn7fEXGZw(u"ࠩ࡟ࡲࡡࡴࠧᑯ")+S26SnaqcM9XwK8PVphJDv5(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่ะ้ีࠠภࠣ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᑰ"))
		if A5vgi1F6qVunZMas2Nf!=I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠲ᛤ"): return
	E9IA4lBOyNJf = ItgK5FqGDz2Rf7mAJkbT(u"ࡉࡥࡱࡹࡥ᝝")
	if K3hFytImeYMkJBC.path.exists(GBDHbTjC2I4d):
		for Msi7IDTbr26VuqQaBmokt1,MJGD1hrpubksVo087YFLHSln,kgVoUd0vCNj in K3hFytImeYMkJBC.walk(GBDHbTjC2I4d,topdown=QmoEjB3hLIw(u"ࡊࡦࡲࡳࡦ᝞")):
			for KIFHwWd5396VAiyepGrPNYsck0znB in kgVoUd0vCNj:
				H8Aa4UyvRWTCjk = K3hFytImeYMkJBC.path.join(Msi7IDTbr26VuqQaBmokt1,KIFHwWd5396VAiyepGrPNYsck0znB)
				try: K3hFytImeYMkJBC.remove(H8Aa4UyvRWTCjk)
				except Exception as y1y3DkdhK8aFYEwMnqZRzi:
					if showDialogs and not E9IA4lBOyNJf: tehb3k5a2PufGOdBIUw8j(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠫࠬᑱ"),dEUYJjrhsaPXNo(u"ࠬ࠭ᑲ"),EAw9bg4rT3Bd8tjSkO(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᑳ"),str(y1y3DkdhK8aFYEwMnqZRzi))
					E9IA4lBOyNJf = GGCQK6OAtZUXRhvkgJm(u"࡙ࡸࡵࡦ᝟")
			if NNb9rcQeglfBpys:
				for dir in MJGD1hrpubksVo087YFLHSln:
					mJqsN3cxH4rUGMiyXB8hdzO1D = K3hFytImeYMkJBC.path.join(Msi7IDTbr26VuqQaBmokt1,dir)
					try: K3hFytImeYMkJBC.rmdir(mJqsN3cxH4rUGMiyXB8hdzO1D)
					except: pass
		if NNb9rcQeglfBpys:
			try: K3hFytImeYMkJBC.rmdir(Msi7IDTbr26VuqQaBmokt1)
			except: pass
	if showDialogs and not E9IA4lBOyNJf:
		tehb3k5a2PufGOdBIUw8j(WbM6qAjrn7fEXGZw(u"ࠧࠨᑴ"),NxsKJnLFEZ9OHXf1h(u"ࠨࠩᑵ"),CgPbwXm1RilpJUSGHLhy(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᑶ"),QmoEjB3hLIw(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫᑷ"))
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(dEUYJjrhsaPXNo(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨᑸ"),ta478EuZQJIWhgBnsf6iU(u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨᑹ"))
		oos8ymFi9CN2z1jXcR.executebuiltin(smpniPDOhfwI3H4v7c6TG(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪᑺ"))
	return
def knv97FU12sdyuZXGCa(jbDMGZeVf2RyJ8OxFA94Emu3pgo0St=FeyZbj8tDil0nSHzTwfsUJ9(u"ࠧࠨᑻ")):
	YyexoUV8ZWpMXsRir1wAm69QPJKnN(NxsKJnLFEZ9OHXf1h(u"ࠨࡵࡷࡳࡵ࠭ᑼ"))
	if jbDMGZeVf2RyJ8OxFA94Emu3pgo0St:
		PPsSFilbkTxQZDJY9ML5uVNO6 = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(r6juULGQtnExAko38BZ5Y(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪᑽ"))
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(qFRrj7ayBKbOsHGSXz(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫᑾ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠫࠬᑿ"))
		TTvq7ZIFQGf(jbDMGZeVf2RyJ8OxFA94Emu3pgo0St)
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(ta478EuZQJIWhgBnsf6iU(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭ᒀ"),PPsSFilbkTxQZDJY9ML5uVNO6)
	DzRqxnIrNLUgj4PYXFkZJc = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(QmoEjB3hLIw(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪᒁ"))
	if DzRqxnIrNLUgj4PYXFkZJc==NNmirJKPp5nWjfC(u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡆࡆࠪᒂ"): if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬᒃ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡈࡈࠬᒄ"))
	elif DzRqxnIrNLUgj4PYXFkZJc==CIcPowhneWs5tN3(u"ࠪࡖࡊࡌࡒࡆࡕࡋࡉࡉ࠭ᒅ"): if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(GGCQK6OAtZUXRhvkgJm(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨᒆ"),smpniPDOhfwI3H4v7c6TG(u"ࠬ࠭ᒇ"))
	if if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩᒈ")) not in [EAw9bg4rT3Bd8tjSkO(u"ࠧࡂࡗࡗࡓࠬᒉ"),qFRrj7ayBKbOsHGSXz(u"ࠨࡕࡗࡓࡕ࠭ᒊ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠩࡄࡗࡐ࠭ᒋ")]: if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(Kwl07iYTtDLN3zP(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ᒌ"),r6juULGQtnExAko38BZ5Y(u"ࠫࡆ࡙ࡋࠨᒍ"))
	if if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪᒎ")) not in [ItgK5FqGDz2Rf7mAJkbT(u"࠭ࡁࡖࡖࡒࠫᒏ"),ta478EuZQJIWhgBnsf6iU(u"ࠧࡔࡖࡒࡔࠬᒐ"),CIcPowhneWs5tN3(u"ࠨࡃࡖࡏࠬᒑ")]: if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(Kwl07iYTtDLN3zP(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧᒒ"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠪࡅࡘࡑࠧᒓ"))
	EgsRLOdXKSNoTaDFW0k6 = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠫࡦࡼ࠮࡮ࡻࡶ࡯࡮ࡴ࠮ࡷ࡫ࡨࡻࡲࡵࡤࡦࠩᒔ"))
	FQB3ikd1X6fsx8PhZKvUL9nq7GbCED = oos8ymFi9CN2z1jXcR.executeJSONRPC(r6juULGQtnExAko38BZ5Y(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨᒕ"))
	if ItgK5FqGDz2Rf7mAJkbT(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬᒖ") in str(FQB3ikd1X6fsx8PhZKvUL9nq7GbCED) and EgsRLOdXKSNoTaDFW0k6 in [WbM6qAjrn7fEXGZw(u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪᒗ"),NxsKJnLFEZ9OHXf1h(u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧᒘ")]:
		w6vebiEZtpCjJcILP8Skx5rHn.sleep(S26SnaqcM9XwK8PVphJDv5(u"࠲࠱࠵࠵࠶ᛥ"))
		oos8ymFi9CN2z1jXcR.executebuiltin(QmoEjB3hLIw(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡙ࡥࡵࡘ࡬ࡩࡼࡓ࡯ࡥࡧࠫ࠴࠮࠭ᒙ"))
	if SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠴ᛧ") and KKtWUT6l8S>-NNmirJKPp5nWjfC(u"࠴ᛦ"):
		I9AOhSdTGW4rX1yPc3oKQHnkJEe.setResolvedUrl(KKtWUT6l8S,Kwl07iYTtDLN3zP(u"ࡌࡡ࡭ࡵࡨᝠ"),ZuEAJR1lNHkUf0.ListItem())
		VZHWjJTrAPKG1eLEsxpYo2tS5,SSx5lkVehYXsZ4p,IPmK78wxkEHyUb91YLJrOGMp = WbM6qAjrn7fEXGZw(u"ࡆࡢ࡮ࡶࡩᝡ"),WbM6qAjrn7fEXGZw(u"ࡆࡢ࡮ࡶࡩᝡ"),WbM6qAjrn7fEXGZw(u"ࡆࡢ࡮ࡶࡩᝡ")
		I9AOhSdTGW4rX1yPc3oKQHnkJEe.endOfDirectory(KKtWUT6l8S,VZHWjJTrAPKG1eLEsxpYo2tS5,SSx5lkVehYXsZ4p,IPmK78wxkEHyUb91YLJrOGMp)
	return
def iCJsfmvcK9Z7RIjFdopH31hMW(A2UGrN4JhjOEXKF3CmIogxRLtaBHye,VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF,pAeIhbuLSFw7j49qxtcg8dDrmKO,YReuIJ67GDs8NwEiZOAh4xPMb,XzfkYQBICVuSjcL5G0pgy9T16xv,dIsZG1fHm5YVkU6Puzq):
	M08MPGgsh4n5rKe,LO2kNuoIli,p9ug8BqHR1ih7yWmNsDVGf3TUrk,UkVahO6eMJNDwImjBo1L7 = mXQV431NeJRFtUPEnia(pAeIhbuLSFw7j49qxtcg8dDrmKO)
	DUacmNFpbwv13uylo = VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF,M08MPGgsh4n5rKe,YReuIJ67GDs8NwEiZOAh4xPMb,XzfkYQBICVuSjcL5G0pgy9T16xv
	if A2UGrN4JhjOEXKF3CmIogxRLtaBHye:
		TcPFsujHEQG3vBwCt = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,NNmirJKPp5nWjfC(u"ࠪࡷࡹࡸࠧᒚ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤ࡛ࡒࡍࡎࡌࡆࠬᒛ"),DUacmNFpbwv13uylo)
		if TcPFsujHEQG3vBwCt:
			ynWephC0J6VPiHcqmrg8d(I7N2lHpGfLPkwKxbOu6raYUgc5(u"࡛ࠬࡒࡍࡎࡌࡆࠥࠦࡒࡆࡃࡇࡣࡈࡇࡃࡉࡇࠪᒜ"),pAeIhbuLSFw7j49qxtcg8dDrmKO,YReuIJ67GDs8NwEiZOAh4xPMb,XzfkYQBICVuSjcL5G0pgy9T16xv,dIsZG1fHm5YVkU6Puzq,VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF)
			return TcPFsujHEQG3vBwCt
	TcPFsujHEQG3vBwCt = V4RQISWvYd8XhJ2s(VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF,pAeIhbuLSFw7j49qxtcg8dDrmKO,YReuIJ67GDs8NwEiZOAh4xPMb,XzfkYQBICVuSjcL5G0pgy9T16xv,dIsZG1fHm5YVkU6Puzq)
	if TcPFsujHEQG3vBwCt and A2UGrN4JhjOEXKF3CmIogxRLtaBHye: kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,r6juULGQtnExAko38BZ5Y(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡖࡔࡏࡐࡎࡈࠧᒝ"),DUacmNFpbwv13uylo,TcPFsujHEQG3vBwCt,A2UGrN4JhjOEXKF3CmIogxRLtaBHye)
	return TcPFsujHEQG3vBwCt
from HrkC1WB0qQ import *
# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'YOUTUBE'
Yc0eBRLpbCkm4gK7OqyzuHwU = '_YUT_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
def HgQCVwFx2Br(mode,url,text,type,tsMKaFVh1ZN2BIXEcvTejxR5DP):
	if	 mode==140: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==143: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url,type)
	elif mode==144: s4Bng5iAZQSTtpDw9 = Hb39UqlX2fZDpc(url,text,tsMKaFVh1ZN2BIXEcvTejxR5DP)
	elif mode==145: s4Bng5iAZQSTtpDw9 = r2i5GM9gVSh0b4DLoYd8PB(url)
	elif mode==146: s4Bng5iAZQSTtpDw9 = V21UqNomRIXOYjpk8d970(url)
	elif mode==147: s4Bng5iAZQSTtpDw9 = YRM5UzTFPfouJAe()
	elif mode==148: s4Bng5iAZQSTtpDw9 = KbIx4ATeylYoXs6L8Qd()
	elif mode==149: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',149,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+'_YTC_'+'مواقع اختارها المبرمج','',290)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'مواقع اختارها يوتيوب',tle5V6jgvRfE+'/feed/guide_builder',144)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'الصفحة الرئيسية',tle5V6jgvRfE,144,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'المحتوى الرائج',tle5V6jgvRfE+'/feed/trending',146)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث: قنوات عربية','',147)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث: قنوات أجنبية','',148)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث: افلام عربية',tle5V6jgvRfE+'/results?search_query=فيلم',144)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث: افلام اجنبية',tle5V6jgvRfE+'/results?search_query=movie',144)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث: مسرحيات عربية',tle5V6jgvRfE+'/results?search_query=مسرحية',144)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث: مسلسلات عربية',tle5V6jgvRfE+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث: مسلسلات اجنبية',tle5V6jgvRfE+'/results?search_query=series&sp=EgIQAw==',144)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث: مسلسلات كارتون',tle5V6jgvRfE+'/results?search_query=كارتون&sp=EgIQAw==',144)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث: خطبة المرجعية',tle5V6jgvRfE+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def YRM5UzTFPfouJAe():
	Hb39UqlX2fZDpc(tle5V6jgvRfE+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def KbIx4ATeylYoXs6L8Qd():
	Hb39UqlX2fZDpc(tle5V6jgvRfE+'/results?search_query=tv&sp=EgJAAQ==')
	return
def dlropqS0vO9K7W4z(url,type):
	import JYR902sfml
	JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt([url],r1NChsk39OMvT82YemDQnl5,type,url)
	return
def V21UqNomRIXOYjpk8d970(url):
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,ngBDPjZshKvdX6,data = htfj5BngX2PKymacbAU(url)
	euaZA8iJvNjO1dT6w9HtGxncY4kRF = ngBDPjZshKvdX6['contents']['twoColumnBrowseResultsRenderer']['tabs']
	for Deiz7ocWQjVnIg in range(len(euaZA8iJvNjO1dT6w9HtGxncY4kRF)):
		hh4gUqS5JWf1saRZPXHD = euaZA8iJvNjO1dT6w9HtGxncY4kRF[Deiz7ocWQjVnIg]
		VVbxwKtN5Crkjl2UJGqB(hh4gUqS5JWf1saRZPXHD,url,str(Deiz7ocWQjVnIg))
	H7VaUAr0NB9l1qeFwyd5PvnXiEtWT = euaZA8iJvNjO1dT6w9HtGxncY4kRF[0]['tabRenderer']['content']['sectionListRenderer']['contents']
	XD87UYMtHBzsL2IcaV1xAEThWNF = 0
	for Deiz7ocWQjVnIg in range(len(H7VaUAr0NB9l1qeFwyd5PvnXiEtWT)):
		hh4gUqS5JWf1saRZPXHD = H7VaUAr0NB9l1qeFwyd5PvnXiEtWT[Deiz7ocWQjVnIg]['itemSectionRenderer']['contents'][0]
		if list(hh4gUqS5JWf1saRZPXHD['shelfRenderer']['content'].keys())[0]=='horizontalListRenderer': continue
		agX9nom53W,title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,count,s6z12JQXUyK5Wn4Bf7LYiDIP9F,FLhVt9Jz2QU4kH51SjTIaspnrO,sRBqTxW3h1SmibclZuYADFj = NmvKPbfOFJRk3AyUE1a(hh4gUqS5JWf1saRZPXHD)
		if not title:
			XD87UYMtHBzsL2IcaV1xAEThWNF += 1
			title = 'فيديوهات رائجة '+str(XD87UYMtHBzsL2IcaV1xAEThWNF)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,144,'',str(Deiz7ocWQjVnIg))
	key = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"innertubeApiKey":"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	M08MPGgsh4n5rKe = 'https://www.youtube.com/youtubei/v1/guide?key='+key[0]
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,ngBDPjZshKvdX6,bhfgckoLVtsA2DXv = htfj5BngX2PKymacbAU(M08MPGgsh4n5rKe)
	for loAFL391p7qDWU8mTed0PgJ in range(3,4):
		euaZA8iJvNjO1dT6w9HtGxncY4kRF = ngBDPjZshKvdX6['items'][loAFL391p7qDWU8mTed0PgJ]['guideSectionRenderer']['items']
		for Deiz7ocWQjVnIg in range(len(euaZA8iJvNjO1dT6w9HtGxncY4kRF)):
			hh4gUqS5JWf1saRZPXHD = euaZA8iJvNjO1dT6w9HtGxncY4kRF[Deiz7ocWQjVnIg]
			if 'YouTube Premium' in str(hh4gUqS5JWf1saRZPXHD): continue
			VVbxwKtN5Crkjl2UJGqB(hh4gUqS5JWf1saRZPXHD)
	return
def Hb39UqlX2fZDpc(url,data='',index=0):
	global if2qpOxlZd8MBGeo5uNIyLEsz
	if not data: data = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.youtube.data')
	if index: index = int(index)
	else: index = 0
	data = data.replace('_REMEMBERRESULTS_','')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,ngBDPjZshKvdX6,bhfgckoLVtsA2DXv = htfj5BngX2PKymacbAU(url,data)
	fbGVEUQotnT0M4Fw1sYNI6zj,NFVIQc0Wh9fYK = '',''
	qAdI4N6keMiRcjVQEHbrv0hlgGJ = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"ownerName".*?":"(.*?)".*?"url":"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not qAdI4N6keMiRcjVQEHbrv0hlgGJ: qAdI4N6keMiRcjVQEHbrv0hlgGJ = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"videoOwner".*?"text":"(.*?)".*?"url":"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not qAdI4N6keMiRcjVQEHbrv0hlgGJ: qAdI4N6keMiRcjVQEHbrv0hlgGJ = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"channelMetadataRenderer":\{"title":"(.*?)".*?"ownerUrls":\["(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if qAdI4N6keMiRcjVQEHbrv0hlgGJ:
		fbGVEUQotnT0M4Fw1sYNI6zj = '[COLOR FFC89008]'+qAdI4N6keMiRcjVQEHbrv0hlgGJ[0][0]+'[/COLOR]'
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = qAdI4N6keMiRcjVQEHbrv0hlgGJ[0][1]
		if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		if 'list=' in url: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+fbGVEUQotnT0M4Fw1sYNI6zj,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,144)
	xuphYFsyn6H5kBjZe8DdQbgo0V = ['/search','/videos','/channels','/playlists','/featured','ss=','ctoken=','key=','bp=','shelf_id=']
	Aes4vBYMQRNnu95pI = not any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in url for hht0cpXxWw2OzFS1jnUGebkJLBd85 in xuphYFsyn6H5kBjZe8DdQbgo0V)
	if Aes4vBYMQRNnu95pI and fbGVEUQotnT0M4Fw1sYNI6zj:
		RwcFvrfJ2ANZSizC6bqKeEo1UDdIQ = 'البحث'
		neZQycYAFqxLzkPhEWvM = 'قوائم التشغيل'
		XxVw0cbRer6ZoqF = 'الفيديوهات'
		FwPBebDCNTi9H3gkc7V2M85lytJ = 'القنوات'
		tBq8fTGUWJY9zvbgXD0EAloPO('link',Yc0eBRLpbCkm4gK7OqyzuHwU+fbGVEUQotnT0M4Fw1sYNI6zj,url,9999)
		if '"title":"بحث"' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+RwcFvrfJ2ANZSizC6bqKeEo1UDdIQ,url,145,'','','_REMEMBERRESULTS_')
		if '"title":"قوائم التشغيل"' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+neZQycYAFqxLzkPhEWvM,url+'/playlists',144)
		if '"title":"الفيديوهات"' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+XxVw0cbRer6ZoqF,url+'/videos',144)
		if '"title":"القنوات"' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+FwPBebDCNTi9H3gkc7V2M85lytJ,url+'/channels',144)
		if '"title":"Search"' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+RwcFvrfJ2ANZSizC6bqKeEo1UDdIQ,url,145,'','','_REMEMBERRESULTS_')
		if '"title":"Playlists"' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+neZQycYAFqxLzkPhEWvM,url+'/playlists',144)
		if '"title":"Videos"' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+XxVw0cbRer6ZoqF,url+'/videos',144)
		if '"title":"Channels"' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+FwPBebDCNTi9H3gkc7V2M85lytJ,url+'/channels',144)
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	if 'search_query' in url:
		euaZA8iJvNjO1dT6w9HtGxncY4kRF = ngBDPjZshKvdX6['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']
		aHUdA27mn1s8jgfrEOFXiJSMphcD = 0
		for AudBQkLFsrHKicIogThZyv in range(len(euaZA8iJvNjO1dT6w9HtGxncY4kRF)):
			if 'itemSectionRenderer' in list(euaZA8iJvNjO1dT6w9HtGxncY4kRF[AudBQkLFsrHKicIogThZyv].keys()):
				kGIhXOrgPL8bBJy = euaZA8iJvNjO1dT6w9HtGxncY4kRF[AudBQkLFsrHKicIogThZyv]['itemSectionRenderer']
				srwIfqXmPivbBLxGKC = len(str(kGIhXOrgPL8bBJy))
				if srwIfqXmPivbBLxGKC>aHUdA27mn1s8jgfrEOFXiJSMphcD:
					aHUdA27mn1s8jgfrEOFXiJSMphcD = srwIfqXmPivbBLxGKC
					NFVIQc0Wh9fYK = kGIhXOrgPL8bBJy
		if aHUdA27mn1s8jgfrEOFXiJSMphcD==0: return
	elif '&list=' in url or '/search?key=' in url or '/browse?key=' in url or 'ctoken=' in url or '/search' in url or url==tle5V6jgvRfE:
		P5irnaYtSdNHyRBWsj6vEA = []
		P5irnaYtSdNHyRBWsj6vEA.append("cc['onResponseReceivedCommands'][0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']")
		P5irnaYtSdNHyRBWsj6vEA.append("cc['onResponseReceivedActions'][0]['appendContinuationItemsAction']['continuationItems']")
		P5irnaYtSdNHyRBWsj6vEA.append("cc[1]['response']['continuationContents']['sectionListContinuation']")
		P5irnaYtSdNHyRBWsj6vEA.append("cc[1]['response']['continuationContents']['gridContinuation']['items']")
		P5irnaYtSdNHyRBWsj6vEA.append("cc[1]['response']['continuationContents']['playlistVideoListContinuation']")
		P5irnaYtSdNHyRBWsj6vEA.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][-1]['expandableTabRenderer']['content']['sectionListRenderer']")
		P5irnaYtSdNHyRBWsj6vEA.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']")
		P5irnaYtSdNHyRBWsj6vEA.append("cc['contents']['twoColumnWatchNextResults']['playlist']['playlist']")
		T2f0KjFcQB,NFVIQc0Wh9fYK = x1iKYowH3MqVu7esyUz5C(ngBDPjZshKvdX6,'',P5irnaYtSdNHyRBWsj6vEA)
	if not NFVIQc0Wh9fYK:
		try:
			euaZA8iJvNjO1dT6w9HtGxncY4kRF = ngBDPjZshKvdX6['contents']['twoColumnBrowseResultsRenderer']['tabs']
			m9Pun8rTb4patA3 = '/videos' in url or '/playlists' in url or '/channels' in url
			xT54I98pywD30o1a7GOKZdrf = '"title":"الفيديوهات"' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 or '"title":"قوائم التشغيل"' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 or '"title":"القنوات"' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
			FJtUjWNZIu57R = '"title":"Videos"' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 or '"title":"Playlists"' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 or '"title":"Channels"' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
			if m9Pun8rTb4patA3 and (xT54I98pywD30o1a7GOKZdrf or FJtUjWNZIu57R):
				for Deiz7ocWQjVnIg in range(len(euaZA8iJvNjO1dT6w9HtGxncY4kRF)):
					if 'tabRenderer' not in list(euaZA8iJvNjO1dT6w9HtGxncY4kRF[Deiz7ocWQjVnIg].keys()): continue
					H7VaUAr0NB9l1qeFwyd5PvnXiEtWT = euaZA8iJvNjO1dT6w9HtGxncY4kRF[Deiz7ocWQjVnIg]['tabRenderer']
					try: vH0zmjaThBpGIy5KVb3d = H7VaUAr0NB9l1qeFwyd5PvnXiEtWT['content']['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems'][Deiz7ocWQjVnIg]
					except: vH0zmjaThBpGIy5KVb3d = H7VaUAr0NB9l1qeFwyd5PvnXiEtWT
					try: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = vH0zmjaThBpGIy5KVb3d['endpoint']['commandMetadata']['webCommandMetadata']['url']
					except: continue
					if   '/videos'		in ZCimQhV5lovgspAYzHq1Ef27u8ja4R	and '/videos'		in url: H7VaUAr0NB9l1qeFwyd5PvnXiEtWT = euaZA8iJvNjO1dT6w9HtGxncY4kRF[Deiz7ocWQjVnIg] ; break
					elif '/playlists'	in ZCimQhV5lovgspAYzHq1Ef27u8ja4R	and '/playlists'	in url: H7VaUAr0NB9l1qeFwyd5PvnXiEtWT = euaZA8iJvNjO1dT6w9HtGxncY4kRF[Deiz7ocWQjVnIg] ; break
					elif '/channels'	in ZCimQhV5lovgspAYzHq1Ef27u8ja4R	and '/channels'		in url: H7VaUAr0NB9l1qeFwyd5PvnXiEtWT = euaZA8iJvNjO1dT6w9HtGxncY4kRF[Deiz7ocWQjVnIg] ; break
					else: H7VaUAr0NB9l1qeFwyd5PvnXiEtWT = euaZA8iJvNjO1dT6w9HtGxncY4kRF[0]
			elif 'bp=' in url: H7VaUAr0NB9l1qeFwyd5PvnXiEtWT = euaZA8iJvNjO1dT6w9HtGxncY4kRF[index]
			else: H7VaUAr0NB9l1qeFwyd5PvnXiEtWT = euaZA8iJvNjO1dT6w9HtGxncY4kRF[0]
			NFVIQc0Wh9fYK = H7VaUAr0NB9l1qeFwyd5PvnXiEtWT['tabRenderer']['content']
		except: pass
	if not NFVIQc0Wh9fYK: return
	P5irnaYtSdNHyRBWsj6vEA = []
	P5irnaYtSdNHyRBWsj6vEA.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	P5irnaYtSdNHyRBWsj6vEA.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	P5irnaYtSdNHyRBWsj6vEA.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	P5irnaYtSdNHyRBWsj6vEA.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	P5irnaYtSdNHyRBWsj6vEA.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['cards']")
	P5irnaYtSdNHyRBWsj6vEA.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	P5irnaYtSdNHyRBWsj6vEA.append("ff['sectionListRenderer']['contents'][int(index)]['richSectionRenderer']['content']")
	if 'view=' not in url: P5irnaYtSdNHyRBWsj6vEA.append("ff['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems']")
	P5irnaYtSdNHyRBWsj6vEA.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	P5irnaYtSdNHyRBWsj6vEA.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	P5irnaYtSdNHyRBWsj6vEA.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	P5irnaYtSdNHyRBWsj6vEA.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	P5irnaYtSdNHyRBWsj6vEA.append("ff['sectionListRenderer']['contents']")
	P5irnaYtSdNHyRBWsj6vEA.append("ff['sectionListRenderer']")
	P5irnaYtSdNHyRBWsj6vEA.append("ff['richGridRenderer']['contents']")
	P5irnaYtSdNHyRBWsj6vEA.append("ff['contents']")
	P5irnaYtSdNHyRBWsj6vEA.append("ff")
	aasM6Lfz71BivCK2XxGhupm0dyo9 = UjfpeA9CkYxt8XV(u'كل قوائم التشغيل')
	ZyGVYEBf6x72Dr1Uklj9 = UjfpeA9CkYxt8XV(u'كل الفيديوهات')
	JinSP1fD2u3MxmCAKdqROw = UjfpeA9CkYxt8XV(u'كل القنوات')
	bvoEJOIiT3A4jg9WPUxn7ykw = [aasM6Lfz71BivCK2XxGhupm0dyo9,ZyGVYEBf6x72Dr1Uklj9,JinSP1fD2u3MxmCAKdqROw,'All playlists','All videos','All channels']
	mL5Cql8InkuaErY1V,vH0zmjaThBpGIy5KVb3d = x1iKYowH3MqVu7esyUz5C(NFVIQc0Wh9fYK,index,P5irnaYtSdNHyRBWsj6vEA)
	if 'list' in str(type(vH0zmjaThBpGIy5KVb3d)) and any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in str(vH0zmjaThBpGIy5KVb3d[0]) for hht0cpXxWw2OzFS1jnUGebkJLBd85 in bvoEJOIiT3A4jg9WPUxn7ykw): del vH0zmjaThBpGIy5KVb3d[0]
	for touxMg0JaXDE2Y3kjnSw86VH in range(len(vH0zmjaThBpGIy5KVb3d)):
		P5irnaYtSdNHyRBWsj6vEA = []
		P5irnaYtSdNHyRBWsj6vEA.append("gg[index2]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
		P5irnaYtSdNHyRBWsj6vEA.append("gg[index2]['itemSectionRenderer']['header']")
		P5irnaYtSdNHyRBWsj6vEA.append("gg[index2]['horizontalCardListRenderer']['header']")
		P5irnaYtSdNHyRBWsj6vEA.append("gg[index2]['itemSectionRenderer']['contents'][0]")
		P5irnaYtSdNHyRBWsj6vEA.append("gg[index2]['richSectionRenderer']['content']")
		P5irnaYtSdNHyRBWsj6vEA.append("gg[index2]['richItemRenderer']['content']")
		P5irnaYtSdNHyRBWsj6vEA.append("gg[index2]['gameCardRenderer']['game']")
		P5irnaYtSdNHyRBWsj6vEA.append("gg[index2]")
		T2f0KjFcQB,hh4gUqS5JWf1saRZPXHD = x1iKYowH3MqVu7esyUz5C(vH0zmjaThBpGIy5KVb3d,touxMg0JaXDE2Y3kjnSw86VH,P5irnaYtSdNHyRBWsj6vEA)
		VVbxwKtN5Crkjl2UJGqB(hh4gUqS5JWf1saRZPXHD,url,str(touxMg0JaXDE2Y3kjnSw86VH))
		if T2f0KjFcQB=='4':
			try:
				eHFmj2B783OvTV40ZuRM = hh4gUqS5JWf1saRZPXHD['shelfRenderer']['content']['horizontalMovieListRenderer']['items']
				for LLRJe9dn0lGAVcrivg7p in range(len(eHFmj2B783OvTV40ZuRM)):
					lPyILjaMAsurTgEK6VdFGcBpY35Q = eHFmj2B783OvTV40ZuRM[LLRJe9dn0lGAVcrivg7p]
					VVbxwKtN5Crkjl2UJGqB(lPyILjaMAsurTgEK6VdFGcBpY35Q)
			except: pass
	D0DRUnSrGF8mA9ZqQLwcuz2 = False
	if 'view=' not in url and mL5Cql8InkuaErY1V=='8': D0DRUnSrGF8mA9ZqQLwcuz2 = True
	if ':::' in bhfgckoLVtsA2DXv: U5kReAbc8Xy,key,AQoZGVrYDj79F1K35wXgTaypvHzu,JxZNwtprqPl48vfDyi75gmzTuoG,wr9ZDoyjmK5gxci083G,tpknRgBLJClIEd50WKmqG = bhfgckoLVtsA2DXv.split(':::')
	else: U5kReAbc8Xy,key,AQoZGVrYDj79F1K35wXgTaypvHzu,JxZNwtprqPl48vfDyi75gmzTuoG,wr9ZDoyjmK5gxci083G,tpknRgBLJClIEd50WKmqG = '','','','','',''
	M08MPGgsh4n5rKe,SSgRAKD3NBqJ97ojTnL5kpFafHdU = '',''
	if muPDGHvJwFieQYCW62bB:
		YBdXuSmWUbaMJG1 = str(muPDGHvJwFieQYCW62bB[-1][1])
		if   Yc0eBRLpbCkm4gK7OqyzuHwU+'CHNL' in YBdXuSmWUbaMJG1: SSgRAKD3NBqJ97ojTnL5kpFafHdU = 'CHANNELS'
		elif Yc0eBRLpbCkm4gK7OqyzuHwU+'USER' in YBdXuSmWUbaMJG1: SSgRAKD3NBqJ97ojTnL5kpFafHdU = 'CHANNELS'
		elif Yc0eBRLpbCkm4gK7OqyzuHwU+'LIST' in YBdXuSmWUbaMJG1: SSgRAKD3NBqJ97ojTnL5kpFafHdU = 'PLAYLISTS'
	if '"continuations"' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 and '&list=' not in url and not D0DRUnSrGF8mA9ZqQLwcuz2 and 'shelf_id' not in url:
		M08MPGgsh4n5rKe = tle5V6jgvRfE+'/browse_ajax?ctoken='+AQoZGVrYDj79F1K35wXgTaypvHzu
	elif '"token"' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 and 'bp=' not in url and 'search_query' in url or 'search?key=' in url:
		M08MPGgsh4n5rKe = tle5V6jgvRfE+'/youtubei/v1/search?key='+key
	elif '"token"' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 and 'bp=' not in url:
		M08MPGgsh4n5rKe = tle5V6jgvRfE+'/youtubei/v1/browse?key='+key
	if M08MPGgsh4n5rKe: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة أخرى',M08MPGgsh4n5rKe,144,SSgRAKD3NBqJ97ojTnL5kpFafHdU,'',bhfgckoLVtsA2DXv)
	return
def x1iKYowH3MqVu7esyUz5C(xvj7ObtqTw1IU3fQuLDC,asSviLeQ41YWRC5,VYsQ2nbf3dM58cLXGga4ZUeKEwq):
	ngBDPjZshKvdX6 = xvj7ObtqTw1IU3fQuLDC
	NFVIQc0Wh9fYK,index = xvj7ObtqTw1IU3fQuLDC,asSviLeQ41YWRC5
	vH0zmjaThBpGIy5KVb3d,touxMg0JaXDE2Y3kjnSw86VH = xvj7ObtqTw1IU3fQuLDC,asSviLeQ41YWRC5
	hh4gUqS5JWf1saRZPXHD,KIQlBP4pEUoCJRZi = xvj7ObtqTw1IU3fQuLDC,asSviLeQ41YWRC5
	count = len(VYsQ2nbf3dM58cLXGga4ZUeKEwq)
	for Deiz7ocWQjVnIg in range(count):
		try:
			qVm6CTx7Ji1 = eval(VYsQ2nbf3dM58cLXGga4ZUeKEwq[Deiz7ocWQjVnIg])
			return str(Deiz7ocWQjVnIg+1),qVm6CTx7Ji1
		except: pass
	return '',''
def NmvKPbfOFJRk3AyUE1a(hh4gUqS5JWf1saRZPXHD):
	try: l6lTuOoEUCmy09IQsi4kJapWzSf2D = list(hh4gUqS5JWf1saRZPXHD.keys())[0]
	except: return False,'','','','','','',''
	agX9nom53W,title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,count,s6z12JQXUyK5Wn4Bf7LYiDIP9F,FLhVt9Jz2QU4kH51SjTIaspnrO,sRBqTxW3h1SmibclZuYADFj = False,'','','','','','',''
	KIQlBP4pEUoCJRZi = hh4gUqS5JWf1saRZPXHD[l6lTuOoEUCmy09IQsi4kJapWzSf2D]
	P5irnaYtSdNHyRBWsj6vEA = []
	P5irnaYtSdNHyRBWsj6vEA.append("render['unplayableText']['simpleText']")
	P5irnaYtSdNHyRBWsj6vEA.append("render['formattedTitle']['simpleText']")
	P5irnaYtSdNHyRBWsj6vEA.append("render['title']['simpleText']")
	P5irnaYtSdNHyRBWsj6vEA.append("render['title']['runs'][0]['text']")
	P5irnaYtSdNHyRBWsj6vEA.append("render['text']['simpleText']")
	P5irnaYtSdNHyRBWsj6vEA.append("render['text']['runs'][0]['text']")
	P5irnaYtSdNHyRBWsj6vEA.append("render['title']")
	P5irnaYtSdNHyRBWsj6vEA.append("item['title']")
	T2f0KjFcQB,title = x1iKYowH3MqVu7esyUz5C(hh4gUqS5JWf1saRZPXHD,KIQlBP4pEUoCJRZi,P5irnaYtSdNHyRBWsj6vEA)
	P5irnaYtSdNHyRBWsj6vEA = []
	P5irnaYtSdNHyRBWsj6vEA.append("render['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	P5irnaYtSdNHyRBWsj6vEA.append("render['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	P5irnaYtSdNHyRBWsj6vEA.append("render['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	P5irnaYtSdNHyRBWsj6vEA.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	T2f0KjFcQB,ZCimQhV5lovgspAYzHq1Ef27u8ja4R = x1iKYowH3MqVu7esyUz5C(hh4gUqS5JWf1saRZPXHD,KIQlBP4pEUoCJRZi,P5irnaYtSdNHyRBWsj6vEA)
	P5irnaYtSdNHyRBWsj6vEA = []
	P5irnaYtSdNHyRBWsj6vEA.append("render['thumbnail']['thumbnails'][0]['url']")
	P5irnaYtSdNHyRBWsj6vEA.append("render['thumbnails'][0]['thumbnails'][0]['url']")
	T2f0KjFcQB,Q2qmuDRrC9ikcaJK7gtUHXNW = x1iKYowH3MqVu7esyUz5C(hh4gUqS5JWf1saRZPXHD,KIQlBP4pEUoCJRZi,P5irnaYtSdNHyRBWsj6vEA)
	P5irnaYtSdNHyRBWsj6vEA = []
	P5irnaYtSdNHyRBWsj6vEA.append("render['videoCount']")
	P5irnaYtSdNHyRBWsj6vEA.append("render['videoCountText']['runs'][0]['text']")
	P5irnaYtSdNHyRBWsj6vEA.append("render['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	T2f0KjFcQB,count = x1iKYowH3MqVu7esyUz5C(hh4gUqS5JWf1saRZPXHD,KIQlBP4pEUoCJRZi,P5irnaYtSdNHyRBWsj6vEA)
	P5irnaYtSdNHyRBWsj6vEA = []
	P5irnaYtSdNHyRBWsj6vEA.append("render['lengthText']['simpleText']")
	P5irnaYtSdNHyRBWsj6vEA.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	P5irnaYtSdNHyRBWsj6vEA.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	T2f0KjFcQB,s6z12JQXUyK5Wn4Bf7LYiDIP9F = x1iKYowH3MqVu7esyUz5C(hh4gUqS5JWf1saRZPXHD,KIQlBP4pEUoCJRZi,P5irnaYtSdNHyRBWsj6vEA)
	if 'LIVE' in s6z12JQXUyK5Wn4Bf7LYiDIP9F: s6z12JQXUyK5Wn4Bf7LYiDIP9F,FLhVt9Jz2QU4kH51SjTIaspnrO = '','LIVE:  '
	if 'مباشر' in s6z12JQXUyK5Wn4Bf7LYiDIP9F: s6z12JQXUyK5Wn4Bf7LYiDIP9F,FLhVt9Jz2QU4kH51SjTIaspnrO = '','LIVE:  '
	if 'badges' in list(KIQlBP4pEUoCJRZi.keys()):
		jjATmG13q5N2FYtJUBZ = str(KIQlBP4pEUoCJRZi['badges'])
		if 'Free with Ads' in jjATmG13q5N2FYtJUBZ: sRBqTxW3h1SmibclZuYADFj = '$:'
		if 'LIVE NOW' in jjATmG13q5N2FYtJUBZ: FLhVt9Jz2QU4kH51SjTIaspnrO = 'LIVE:  '
		if 'Buy' in jjATmG13q5N2FYtJUBZ or 'Rent' in jjATmG13q5N2FYtJUBZ: sRBqTxW3h1SmibclZuYADFj = '$$:'
		if UjfpeA9CkYxt8XV(u'مباشر') in jjATmG13q5N2FYtJUBZ: FLhVt9Jz2QU4kH51SjTIaspnrO = 'LIVE:  '
		if UjfpeA9CkYxt8XV(u'شراء') in jjATmG13q5N2FYtJUBZ: sRBqTxW3h1SmibclZuYADFj = '$$:'
		if UjfpeA9CkYxt8XV(u'استئجار') in jjATmG13q5N2FYtJUBZ: sRBqTxW3h1SmibclZuYADFj = '$$:'
		if UjfpeA9CkYxt8XV(u'إعلانات') in jjATmG13q5N2FYtJUBZ: sRBqTxW3h1SmibclZuYADFj = '$:'
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = zKGXT5sJeRq(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	if ZCimQhV5lovgspAYzHq1Ef27u8ja4R and 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
	Q2qmuDRrC9ikcaJK7gtUHXNW = Q2qmuDRrC9ikcaJK7gtUHXNW.split('?')[0]
	if  Q2qmuDRrC9ikcaJK7gtUHXNW and 'http' not in Q2qmuDRrC9ikcaJK7gtUHXNW: Q2qmuDRrC9ikcaJK7gtUHXNW = 'https:'+Q2qmuDRrC9ikcaJK7gtUHXNW
	title = zKGXT5sJeRq(title)
	if sRBqTxW3h1SmibclZuYADFj: title = sRBqTxW3h1SmibclZuYADFj+'  '+title
	s6z12JQXUyK5Wn4Bf7LYiDIP9F = s6z12JQXUyK5Wn4Bf7LYiDIP9F.replace(',','')
	count = count.replace(',','')
	count = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('\d+',count)
	if count: count = count[0]
	else: count = ''
	return True,title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,count,s6z12JQXUyK5Wn4Bf7LYiDIP9F,FLhVt9Jz2QU4kH51SjTIaspnrO,sRBqTxW3h1SmibclZuYADFj
def VVbxwKtN5Crkjl2UJGqB(hh4gUqS5JWf1saRZPXHD,url='',index=''):
	agX9nom53W,title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,count,s6z12JQXUyK5Wn4Bf7LYiDIP9F,FLhVt9Jz2QU4kH51SjTIaspnrO,sRBqTxW3h1SmibclZuYADFj = NmvKPbfOFJRk3AyUE1a(hh4gUqS5JWf1saRZPXHD)
	if not agX9nom53W: return
	elif 'continuationItemRenderer' in str(hh4gUqS5JWf1saRZPXHD): return
	elif 'searchPyvRenderer' in str(hh4gUqS5JWf1saRZPXHD): return
	elif not ZCimQhV5lovgspAYzHq1Ef27u8ja4R and 'search_query' in url: return
	elif title and not ZCimQhV5lovgspAYzHq1Ef27u8ja4R and ('search_query' in url or 'horizontalMovieListRenderer' in str(hh4gUqS5JWf1saRZPXHD) or url==tle5V6jgvRfE):
		title = '=== '+title+' ==='
		tBq8fTGUWJY9zvbgXD0EAloPO('link',Yc0eBRLpbCkm4gK7OqyzuHwU+title,'',9999)
	elif title and 'messageRenderer' in str(hh4gUqS5JWf1saRZPXHD):
		tBq8fTGUWJY9zvbgXD0EAloPO('link',Yc0eBRLpbCkm4gK7OqyzuHwU+title,'',9999)
	elif '/feed/trending' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,144,Q2qmuDRrC9ikcaJK7gtUHXNW,index)
	elif not title: return
	elif FLhVt9Jz2QU4kH51SjTIaspnrO: tBq8fTGUWJY9zvbgXD0EAloPO('live',Yc0eBRLpbCkm4gK7OqyzuHwU+FLhVt9Jz2QU4kH51SjTIaspnrO+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,143,Q2qmuDRrC9ikcaJK7gtUHXNW)
	elif 'watch?v=' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R or '/shorts/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
		if '&list=' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R and 'index=' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
			iEwgHJI7sm = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('&list=',1)[1]
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/playlist?list='+iEwgHJI7sm
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'LIST'+count+':  '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,144,Q2qmuDRrC9ikcaJK7gtUHXNW)
		else:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('&list=',1)[0]
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,143,Q2qmuDRrC9ikcaJK7gtUHXNW,s6z12JQXUyK5Wn4Bf7LYiDIP9F)
	else:
		type = ''
		if not ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = url
		elif not any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in ZCimQhV5lovgspAYzHq1Ef27u8ja4R for hht0cpXxWw2OzFS1jnUGebkJLBd85 in ['/videos','/playlists','/channels','/featured','ss=','bp=']):
			if '/channel/'	in ZCimQhV5lovgspAYzHq1Ef27u8ja4R or '/c/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: type = 'CHNL'+count+':  '
			if '/user/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: type = 'USER'+count+':  '
			index,a3cAIEyK0PfnjQD = '',''
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+type+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,144,Q2qmuDRrC9ikcaJK7gtUHXNW,index)
	return
def htfj5BngX2PKymacbAU(url,data='',VWi2dTb46v3eOryuspKBF9L=''):
	global if2qpOxlZd8MBGeo5uNIyLEsz
	if not data: data = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.youtube.data')
	if VWi2dTb46v3eOryuspKBF9L=='': VWi2dTb46v3eOryuspKBF9L = 'ytInitialData'
	PPGUinpWfm6Xw9NLtbcax53IQ = FY2qK6eHVBl4D0pEut8IgkTczyG()
	TC7fWv2a1gLJGiAtN8 = {'User-Agent':PPGUinpWfm6Xw9NLtbcax53IQ,'Cookie':'PREF=hl=ar'}
	if ':::' in data: U5kReAbc8Xy,key,AQoZGVrYDj79F1K35wXgTaypvHzu,JxZNwtprqPl48vfDyi75gmzTuoG,wr9ZDoyjmK5gxci083G,tpknRgBLJClIEd50WKmqG = data.split(':::')
	else: U5kReAbc8Xy,key,AQoZGVrYDj79F1K35wXgTaypvHzu,JxZNwtprqPl48vfDyi75gmzTuoG,wr9ZDoyjmK5gxci083G,tpknRgBLJClIEd50WKmqG = '','','','','',''
	if 'guide?key=' in url:
		bhfgckoLVtsA2DXv = {}
		bhfgckoLVtsA2DXv['context'] = {"client":{"hl":"ar","clientName":"WEB","clientVersion":JxZNwtprqPl48vfDyi75gmzTuoG}}
		bhfgckoLVtsA2DXv = str(bhfgckoLVtsA2DXv)
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'POST',url,bhfgckoLVtsA2DXv,TC7fWv2a1gLJGiAtN8,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif 'key=' in url and U5kReAbc8Xy:
		bhfgckoLVtsA2DXv = {'continuation':wr9ZDoyjmK5gxci083G}
		bhfgckoLVtsA2DXv['context'] = {"client":{"visitorData":U5kReAbc8Xy,"clientName":"WEB","clientVersion":JxZNwtprqPl48vfDyi75gmzTuoG}}
		bhfgckoLVtsA2DXv = str(bhfgckoLVtsA2DXv)
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'POST',url,bhfgckoLVtsA2DXv,TC7fWv2a1gLJGiAtN8,True,True,'YOUTUBE-GET_PAGE_DATA-2nd')
	elif 'ctoken=' in url and tpknRgBLJClIEd50WKmqG:
		TC7fWv2a1gLJGiAtN8.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':JxZNwtprqPl48vfDyi75gmzTuoG})
		TC7fWv2a1gLJGiAtN8.update({'Cookie':'VISITOR_INFO1_LIVE='+tpknRgBLJClIEd50WKmqG})
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',url,'',TC7fWv2a1gLJGiAtN8,'','','YOUTUBE-GET_PAGE_DATA-3rd')
	else:
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',url,'',TC7fWv2a1gLJGiAtN8,'','','YOUTUBE-GET_PAGE_DATA-4th')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	lwHJhfqkYN4WxMbmvnaKoU50 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"innertubeApiKey".*?"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.I)
	if lwHJhfqkYN4WxMbmvnaKoU50: key = lwHJhfqkYN4WxMbmvnaKoU50[0]
	lwHJhfqkYN4WxMbmvnaKoU50 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"cver".*?"value".*?"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.I)
	if lwHJhfqkYN4WxMbmvnaKoU50: JxZNwtprqPl48vfDyi75gmzTuoG = lwHJhfqkYN4WxMbmvnaKoU50[0]
	lwHJhfqkYN4WxMbmvnaKoU50 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"token".*?"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.I)
	if lwHJhfqkYN4WxMbmvnaKoU50: wr9ZDoyjmK5gxci083G = lwHJhfqkYN4WxMbmvnaKoU50[0]
	lwHJhfqkYN4WxMbmvnaKoU50 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"visitorData".*?"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.I)
	if lwHJhfqkYN4WxMbmvnaKoU50: U5kReAbc8Xy = lwHJhfqkYN4WxMbmvnaKoU50[0]
	lwHJhfqkYN4WxMbmvnaKoU50 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"continuation".*?"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.I)
	if lwHJhfqkYN4WxMbmvnaKoU50: AQoZGVrYDj79F1K35wXgTaypvHzu = lwHJhfqkYN4WxMbmvnaKoU50[0]
	cookies = aQniqUlZk8.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): tpknRgBLJClIEd50WKmqG = cookies['VISITOR_INFO1_LIVE']
	data = U5kReAbc8Xy+':::'+key+':::'+AQoZGVrYDj79F1K35wXgTaypvHzu+':::'+JxZNwtprqPl48vfDyi75gmzTuoG+':::'+wr9ZDoyjmK5gxci083G+':::'+tpknRgBLJClIEd50WKmqG
	if VWi2dTb46v3eOryuspKBF9L=='ytInitialData' and 'ytInitialData' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2:
		QQrmjN6z9AvTGlqipZ2cK = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('window\["ytInitialData"\] = ({.*?});',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if not QQrmjN6z9AvTGlqipZ2cK: QQrmjN6z9AvTGlqipZ2cK = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('var ytInitialData = ({.*?});',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		bwCMA2NdaBJc = GVQAnvYCT3dS('str',QQrmjN6z9AvTGlqipZ2cK[0])
	elif VWi2dTb46v3eOryuspKBF9L=='ytInitialGuideData' and 'ytInitialGuideData' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2:
		QQrmjN6z9AvTGlqipZ2cK = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('var ytInitialGuideData = ({.*?});',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		bwCMA2NdaBJc = GVQAnvYCT3dS('str',QQrmjN6z9AvTGlqipZ2cK[0])
	elif '</script>' not in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2: bwCMA2NdaBJc = GVQAnvYCT3dS('str',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2)
	else: bwCMA2NdaBJc = ''
	if2qpOxlZd8MBGeo5uNIyLEsz.setSetting('av.youtube.data',data)
	return M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,bwCMA2NdaBJc,data
def r2i5GM9gVSh0b4DLoYd8PB(url):
	search = UIf35nZEj1wylmq()
	if not search: return
	search = search.replace(' ','+')
	M08MPGgsh4n5rKe = url+'/search?query='+search
	Hb39UqlX2fZDpc(M08MPGgsh4n5rKe)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if not search:
		search = UIf35nZEj1wylmq()
		if not search: return
	search = search.replace(' ','+')
	M08MPGgsh4n5rKe = tle5V6jgvRfE+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in dNlVai6Obj1e: JHV2A134Gcdkqfhe8jSTN = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in dNlVai6Obj1e: JHV2A134Gcdkqfhe8jSTN = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in dNlVai6Obj1e: JHV2A134Gcdkqfhe8jSTN = '&sp=EgIQAg%253D%253D'
		TW6JIBgC971tjOE = M08MPGgsh4n5rKe+JHV2A134Gcdkqfhe8jSTN
	else:
		GfmuyVWZ4SHhINE6AbRFdiQ,DJCZ5K2bfyNjtgW9zQT13sAi4mS,neZQycYAFqxLzkPhEWvM = [],[],''
		Xigwu6GWCSfy0e4dAQYx = ['بدون ترتيب','ترتيب حسب مدى الصلة','ترتيب حسب تاريخ التحميل','ترتيب حسب عدد المشاهدات','ترتيب حسب التقييم']
		ts017yVrFBiaUqCWhc = ['','&sp=CAA%253D','&sp=CAI%253D','&sp=CAM%253D','&sp=CAE%253D']
		KmgHSckEoXNDwWtqj9pJ3aisb8v45 = pYRLgOuVTAUM4wKJchdbkzfBql('موقع يوتيوب - اختر الترتيب',Xigwu6GWCSfy0e4dAQYx)
		if KmgHSckEoXNDwWtqj9pJ3aisb8v45 == -1: return
		yw9guiXa6RkIhJHPL2zdFm5l = ts017yVrFBiaUqCWhc[KmgHSckEoXNDwWtqj9pJ3aisb8v45]
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,f2zRBWtqK0EXauIpD36,data = htfj5BngX2PKymacbAU(M08MPGgsh4n5rKe+yw9guiXa6RkIhJHPL2zdFm5l)
		if f2zRBWtqK0EXauIpD36:
			zfy8eg4oWEQNBIUblPYZhp = f2zRBWtqK0EXauIpD36['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
			for j4oPqsvRg6X0HDNT2LFbhyIaBJu in range(len(zfy8eg4oWEQNBIUblPYZhp)):
				group = zfy8eg4oWEQNBIUblPYZhp[j4oPqsvRg6X0HDNT2LFbhyIaBJu]['searchFilterGroupRenderer']['filters']
				for LLmET7aiA0WkRMChzVfqlKdGQUc9y in range(len(group)):
					KIQlBP4pEUoCJRZi = group[LLmET7aiA0WkRMChzVfqlKdGQUc9y]['searchFilterRenderer']
					if 'navigationEndpoint' in list(KIQlBP4pEUoCJRZi.keys()):
						ZCimQhV5lovgspAYzHq1Ef27u8ja4R = KIQlBP4pEUoCJRZi['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
						ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.replace('\u0026','&')
						title = KIQlBP4pEUoCJRZi['tooltip']
						title = title.replace('البحث عن ','')
						if 'إزالة الفلتر' in title: continue
						if 'قائمة تشغيل' in title:
							title = 'جيد للمسلسلات '+title
							neZQycYAFqxLzkPhEWvM = title
							VktWBN6gn8zSUpesvfCyia2Ajm = ZCimQhV5lovgspAYzHq1Ef27u8ja4R
						if 'ترتيب حسب' in title: continue
						title = title.replace('Search for ','')
						if 'Remove' in title: continue
						if 'Playlist' in title:
							title = 'جيد للمسلسلات '+title
							neZQycYAFqxLzkPhEWvM = title
							VktWBN6gn8zSUpesvfCyia2Ajm = ZCimQhV5lovgspAYzHq1Ef27u8ja4R
						if 'Sort by' in title: continue
						GfmuyVWZ4SHhINE6AbRFdiQ.append(zKGXT5sJeRq(title))
						DJCZ5K2bfyNjtgW9zQT13sAi4mS.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
		if not neZQycYAFqxLzkPhEWvM: krUhYxnVptb9 = ''
		else:
			GfmuyVWZ4SHhINE6AbRFdiQ = ['بدون فلتر',neZQycYAFqxLzkPhEWvM]+GfmuyVWZ4SHhINE6AbRFdiQ
			DJCZ5K2bfyNjtgW9zQT13sAi4mS = ['',VktWBN6gn8zSUpesvfCyia2Ajm]+DJCZ5K2bfyNjtgW9zQT13sAi4mS
			u5cH24GQrUiEpBYTgw = pYRLgOuVTAUM4wKJchdbkzfBql('موقع يوتيوب - اختر الفلتر',GfmuyVWZ4SHhINE6AbRFdiQ)
			if u5cH24GQrUiEpBYTgw == -1: return
			krUhYxnVptb9 = DJCZ5K2bfyNjtgW9zQT13sAi4mS[u5cH24GQrUiEpBYTgw]
		if krUhYxnVptb9: TW6JIBgC971tjOE = tle5V6jgvRfE+krUhYxnVptb9
		elif yw9guiXa6RkIhJHPL2zdFm5l: TW6JIBgC971tjOE = M08MPGgsh4n5rKe+yw9guiXa6RkIhJHPL2zdFm5l
		else: TW6JIBgC971tjOE = M08MPGgsh4n5rKe
	Hb39UqlX2fZDpc(TW6JIBgC971tjOE)
	return
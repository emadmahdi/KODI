# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'EGYDEAD'
Yc0eBRLpbCkm4gK7OqyzuHwU = '_EGD_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
ZLKHfqMEUdRupD = ['مصارعة','احدث البرامج','احدث الالعاب','الرئيسية','احدث الاغانى']
def HgQCVwFx2Br(mode,url,text):
	if   mode==440: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==441: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url,text)
	elif mode==442: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==443: s4Bng5iAZQSTtpDw9 = btd6ag2XYUkHixqy5J7o9RfLu1MScm(url)
	elif mode==449: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',tle5V6jgvRfE,'','','','','EGYDEAD-MENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	dkgwyUKEpTtPeMxs68aib = SLMTm6RQ34ic7v5s9rBG(tle5V6jgvRfE,'url')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',449,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'الرئيسية',tle5V6jgvRfE,441)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="title_menu_right"(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)">(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		if title in ZLKHfqMEUdRupD: continue
		if ZCimQhV5lovgspAYzHq1Ef27u8ja4R=='#': continue
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,441)
	return
def uyt3pAHZk4(url,mbGei9dIvrTohtJ=''):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','EGYDEAD-TITLES-2nd')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="list-related"(.*?)class="pagination"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<li>.*?href="(.*?)".*?<h1>(.*?)</h1>.*?src="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,Q2qmuDRrC9ikcaJK7gtUHXNW in items:
		if '/url/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: continue
		elif '/season/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,443,Q2qmuDRrC9ikcaJK7gtUHXNW)
		elif '/episode/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,443,Q2qmuDRrC9ikcaJK7gtUHXNW)
		else: tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,442,Q2qmuDRrC9ikcaJK7gtUHXNW)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="pagination"(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,441)
	return
def btd6ag2XYUkHixqy5J7o9RfLu1MScm(url):
	data = {'View':1}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'POST',url,data,headers,'','','EGYDEAD-EPISODES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	rrNex9MVQDgqIW4kFoSyslw = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"seasons-list"(.*?)</div>.</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	rNQC9lGIxW3d0oB6AjUfD5LbRF = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"episodes-list"(.*?)</div>.</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if rrNex9MVQDgqIW4kFoSyslw:
		ziJLDVT8NM2QcgIpmE9A = rrNex9MVQDgqIW4kFoSyslw[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,Q2qmuDRrC9ikcaJK7gtUHXNW in items:
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,443,Q2qmuDRrC9ikcaJK7gtUHXNW)
	elif rNQC9lGIxW3d0oB6AjUfD5LbRF:
		Q2qmuDRrC9ikcaJK7gtUHXNW = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"og:image" content="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		Q2qmuDRrC9ikcaJK7gtUHXNW = Q2qmuDRrC9ikcaJK7gtUHXNW[0]
		ziJLDVT8NM2QcgIpmE9A = rNQC9lGIxW3d0oB6AjUfD5LbRF[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			title = title.replace('\n','').strip(' ')
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,442,Q2qmuDRrC9ikcaJK7gtUHXNW)
	return
def dlropqS0vO9K7W4z(url):
	data = {'View':1}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'POST',url,data,headers,'','','EGYDEAD-PLAY-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	jVMHRouKgQFAESmd7B8ObTYy = []
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"watchAreaMaster"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-link="(.*?)".*?<p>(.*?)</p>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			title = title.replace('\n','').strip(' ')
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+title+'__watch'
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"donwload-servers-list"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"ser-name">(.*?)</span>.*?<em>(.*?)</em>.*?href="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for title,LjG8y1rb9AgJF2I3i64ZDtCXMa7n,ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.replace('\n','')
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+title+'__download'+'____'+LjG8y1rb9AgJF2I3i64ZDtCXMa7n
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	import JYR902sfml
	JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt(jVMHRouKgQFAESmd7B8ObTYy,r1NChsk39OMvT82YemDQnl5,'video',url)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if search=='': search = UIf35nZEj1wylmq()
	if search=='': return
	search = search.replace(' ','+')
	url = tle5V6jgvRfE+'/?s='+search
	uyt3pAHZk4(url)
	return
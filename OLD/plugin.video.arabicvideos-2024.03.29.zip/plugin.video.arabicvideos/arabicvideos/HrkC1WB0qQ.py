# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
from PIL import ImageDraw as P5j9asqbcBpmurZ184noVh3I,ImageFont as c7kgPIzjmT,Image as b0jWpJLRsD4omGnBXefT38yM
from arabic_reshaper import ArabicReshaper as MUz2LypR7GhOecTZ56CakbwdF
PCY2LJwTgIfan = 'EXCLUDES'
def qYbFUezndJt6NaZyBH3LckPm9S8(GG9zmPqulYDyJCtWwkE8,lXbFJn6ZWvDofqEdAMuLzprUtV7):
	lXbFJn6ZWvDofqEdAMuLzprUtV7 = lXbFJn6ZWvDofqEdAMuLzprUtV7.replace('[COLOR FFC89008]','').replace(' [/COLOR]','')[1:]
	WWQSqKucO9nDih3kRVEAL = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('[a-zA-Z]',GG9zmPqulYDyJCtWwkE8,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if 'بحث IPTV - ' in GG9zmPqulYDyJCtWwkE8: GG9zmPqulYDyJCtWwkE8 = GG9zmPqulYDyJCtWwkE8.replace('بحث IPTV - ',HwksZdFnbNg3Pr+'بحث IPTV - '+HwksZdFnbNg3Pr)
	elif ' IPTV' in GG9zmPqulYDyJCtWwkE8 and lXbFJn6ZWvDofqEdAMuLzprUtV7=='IPT': GG9zmPqulYDyJCtWwkE8 = HwksZdFnbNg3Pr+GG9zmPqulYDyJCtWwkE8
	elif 'بحث M3U - ' in GG9zmPqulYDyJCtWwkE8: GG9zmPqulYDyJCtWwkE8 = GG9zmPqulYDyJCtWwkE8.replace('بحث M3U - ',HwksZdFnbNg3Pr+'بحث M3U - '+HwksZdFnbNg3Pr)
	elif ' M3U' in GG9zmPqulYDyJCtWwkE8 and lXbFJn6ZWvDofqEdAMuLzprUtV7=='M3U': GG9zmPqulYDyJCtWwkE8 = HwksZdFnbNg3Pr+GG9zmPqulYDyJCtWwkE8
	elif 'بحث ' in GG9zmPqulYDyJCtWwkE8 and ' - ' in GG9zmPqulYDyJCtWwkE8: GG9zmPqulYDyJCtWwkE8 = HwksZdFnbNg3Pr+GG9zmPqulYDyJCtWwkE8
	elif not WWQSqKucO9nDih3kRVEAL:
		vxi2WQmesLpz = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('^( *?)(.*?)( *?)$',GG9zmPqulYDyJCtWwkE8)
		gsISZFUKVjyrXfT,cOjCK34AG2zU1n,nDLdRYE6BmicCAT1U3Hq = vxi2WQmesLpz[0]
		rbvnlp498i3qUm2sue = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('^([!-~])',cOjCK34AG2zU1n)
		if rbvnlp498i3qUm2sue: GG9zmPqulYDyJCtWwkE8 = gsISZFUKVjyrXfT+W3oZ8vhLnsOdIaDp6qeN214kcJCVz+cOjCK34AG2zU1n+nDLdRYE6BmicCAT1U3Hq
		else: GG9zmPqulYDyJCtWwkE8 = nDLdRYE6BmicCAT1U3Hq+HwksZdFnbNg3Pr+cOjCK34AG2zU1n+gsISZFUKVjyrXfT
	else:
		if 1:
			b5BZtudeyr = GG9zmPqulYDyJCtWwkE8
			Ni59sIzYTE4tOu = C5KxErBjfN7HzJbdPmAciQT.get_display(GG9zmPqulYDyJCtWwkE8,base_dir='L')
			if vciEXHThAPto76QIR2pK: b5BZtudeyr = b5BZtudeyr.decode('utf8')
			if vciEXHThAPto76QIR2pK: Ni59sIzYTE4tOu = Ni59sIzYTE4tOu.decode('utf8')
			yEiLxmS9CfanKUvXcobJ6WDVuG = b5BZtudeyr.split(' ')
			qbDAmN7ik0t2asCV = Ni59sIzYTE4tOu.split(' ')
			ss7loCJSKcex4F,uhZo9K0EWpmdxMU8CQ7v6FNGzPLI,nxmLy1jWc03fS4T5gEzMQ2G,AAO7igKbat0Uq1hDGe = [],[],'',''
			ra0gPByAjzEbKx8iT9QFt216fCLMn = zip(yEiLxmS9CfanKUvXcobJ6WDVuG,qbDAmN7ik0t2asCV)
			for EtBQb1iod4HWNGOnhL,BRLmhng4OMu9Zk5DpJS8Hr7iVYzxs in ra0gPByAjzEbKx8iT9QFt216fCLMn:
				if EtBQb1iod4HWNGOnhL==BRLmhng4OMu9Zk5DpJS8Hr7iVYzxs=='' and AAO7igKbat0Uq1hDGe:
					nxmLy1jWc03fS4T5gEzMQ2G += ' '
					continue
				if EtBQb1iod4HWNGOnhL==BRLmhng4OMu9Zk5DpJS8Hr7iVYzxs:
					abelkTxywN3z1ImLGD8fYEjZ74SX9t = 'EN'
					if AAO7igKbat0Uq1hDGe==abelkTxywN3z1ImLGD8fYEjZ74SX9t: nxmLy1jWc03fS4T5gEzMQ2G += ' '+EtBQb1iod4HWNGOnhL
					elif EtBQb1iod4HWNGOnhL:
						if nxmLy1jWc03fS4T5gEzMQ2G:
							uhZo9K0EWpmdxMU8CQ7v6FNGzPLI.append(nxmLy1jWc03fS4T5gEzMQ2G)
							ss7loCJSKcex4F.append('')
						nxmLy1jWc03fS4T5gEzMQ2G = EtBQb1iod4HWNGOnhL
				else:
					abelkTxywN3z1ImLGD8fYEjZ74SX9t = 'AR'
					if AAO7igKbat0Uq1hDGe==abelkTxywN3z1ImLGD8fYEjZ74SX9t: nxmLy1jWc03fS4T5gEzMQ2G += ' '+EtBQb1iod4HWNGOnhL
					elif EtBQb1iod4HWNGOnhL:
						if nxmLy1jWc03fS4T5gEzMQ2G:
							ss7loCJSKcex4F.append(nxmLy1jWc03fS4T5gEzMQ2G)
							uhZo9K0EWpmdxMU8CQ7v6FNGzPLI.append('')
						nxmLy1jWc03fS4T5gEzMQ2G = EtBQb1iod4HWNGOnhL
				AAO7igKbat0Uq1hDGe = abelkTxywN3z1ImLGD8fYEjZ74SX9t
			if abelkTxywN3z1ImLGD8fYEjZ74SX9t=='EN':
				ss7loCJSKcex4F.append(nxmLy1jWc03fS4T5gEzMQ2G)
				uhZo9K0EWpmdxMU8CQ7v6FNGzPLI.append('')
			else:
				uhZo9K0EWpmdxMU8CQ7v6FNGzPLI.append(nxmLy1jWc03fS4T5gEzMQ2G)
				ss7loCJSKcex4F.append('')
			BYNCkpTDLQanX0JVd = ''
			ra0gPByAjzEbKx8iT9QFt216fCLMn = zip(ss7loCJSKcex4F,uhZo9K0EWpmdxMU8CQ7v6FNGzPLI)
			for uumpFeGXan,eOl6YZVBhIjRUsfqtzEpmaSDr in ra0gPByAjzEbKx8iT9QFt216fCLMn:
				if uumpFeGXan: BYNCkpTDLQanX0JVd += ' '+uumpFeGXan
				else:
					rbvnlp498i3qUm2sue = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('([!-~]) *$',eOl6YZVBhIjRUsfqtzEpmaSDr)
					if rbvnlp498i3qUm2sue:
						rbvnlp498i3qUm2sue = rbvnlp498i3qUm2sue[0]
						try:
							NMbwWBKfheFQHrX7ROViUm5nyY0 = w8Y6TU3WLkjlcQfe2Fn4CgOI9N.MIRRORED[rbvnlp498i3qUm2sue]
							vxi2WQmesLpz = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('^( *?)(.*?)( *?)$',eOl6YZVBhIjRUsfqtzEpmaSDr)
							if vxi2WQmesLpz: gsISZFUKVjyrXfT,eOl6YZVBhIjRUsfqtzEpmaSDr,nDLdRYE6BmicCAT1U3Hq = vxi2WQmesLpz[0]
							eOl6YZVBhIjRUsfqtzEpmaSDr = gsISZFUKVjyrXfT+NMbwWBKfheFQHrX7ROViUm5nyY0+eOl6YZVBhIjRUsfqtzEpmaSDr[:-1]+nDLdRYE6BmicCAT1U3Hq
						except: pass
					BYNCkpTDLQanX0JVd += ' '+eOl6YZVBhIjRUsfqtzEpmaSDr
			GG9zmPqulYDyJCtWwkE8 = BYNCkpTDLQanX0JVd[1:]
			if vciEXHThAPto76QIR2pK: GG9zmPqulYDyJCtWwkE8 = GG9zmPqulYDyJCtWwkE8.encode('utf8')
		else:
			if vciEXHThAPto76QIR2pK: GG9zmPqulYDyJCtWwkE8 = GG9zmPqulYDyJCtWwkE8.decode('utf8')
			GG9zmPqulYDyJCtWwkE8 = C5KxErBjfN7HzJbdPmAciQT.get_display(GG9zmPqulYDyJCtWwkE8)
			b5BZtudeyr,Ni59sIzYTE4tOu = GG9zmPqulYDyJCtWwkE8,GG9zmPqulYDyJCtWwkE8
			if 1:
				AAO7igKbat0Uq1hDGe,AytqemVZfTNdagciCbrnLvR7YMIXGu = '',[]
				h8hnR6u2X1Er3YaJkDpCPOB7 = GG9zmPqulYDyJCtWwkE8.split(' ')
				for nly59fsP8vTpOAXDFC7 in h8hnR6u2X1Er3YaJkDpCPOB7:
					if not nly59fsP8vTpOAXDFC7:
						if AytqemVZfTNdagciCbrnLvR7YMIXGu: AytqemVZfTNdagciCbrnLvR7YMIXGu[-1] += ' '
						else: AytqemVZfTNdagciCbrnLvR7YMIXGu.append('')
						continue
					xKjvSsztIXfJO = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('[!-~]',nly59fsP8vTpOAXDFC7[0])
					if xKjvSsztIXfJO==AAO7igKbat0Uq1hDGe and AytqemVZfTNdagciCbrnLvR7YMIXGu: AytqemVZfTNdagciCbrnLvR7YMIXGu[-1] += ' '+nly59fsP8vTpOAXDFC7
					else:
						if AytqemVZfTNdagciCbrnLvR7YMIXGu:
							ux7FCLU6ZPhv9MpHk4qrJS1Wb = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('[^!-~]',AytqemVZfTNdagciCbrnLvR7YMIXGu[-1])
							if ux7FCLU6ZPhv9MpHk4qrJS1Wb:
								AytqemVZfTNdagciCbrnLvR7YMIXGu[-1] = C5KxErBjfN7HzJbdPmAciQT.get_display(AytqemVZfTNdagciCbrnLvR7YMIXGu[-1])
								y3jolBq7xIE8AHuMWZGb4fYnDzsN = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('^ +',AytqemVZfTNdagciCbrnLvR7YMIXGu[-1])
								if y3jolBq7xIE8AHuMWZGb4fYnDzsN: AytqemVZfTNdagciCbrnLvR7YMIXGu[-1] = AytqemVZfTNdagciCbrnLvR7YMIXGu[-1].lstrip(' ')+y3jolBq7xIE8AHuMWZGb4fYnDzsN[0]
						AytqemVZfTNdagciCbrnLvR7YMIXGu.append(nly59fsP8vTpOAXDFC7)
					AAO7igKbat0Uq1hDGe = xKjvSsztIXfJO
				if AytqemVZfTNdagciCbrnLvR7YMIXGu: AytqemVZfTNdagciCbrnLvR7YMIXGu[-1] = C5KxErBjfN7HzJbdPmAciQT.get_display(AytqemVZfTNdagciCbrnLvR7YMIXGu[-1])
				GG9zmPqulYDyJCtWwkE8 = ' '.join(AytqemVZfTNdagciCbrnLvR7YMIXGu)
			if vciEXHThAPto76QIR2pK: GG9zmPqulYDyJCtWwkE8 = GG9zmPqulYDyJCtWwkE8.encode('utf8')
	return GG9zmPqulYDyJCtWwkE8
def Ze3U0adCsoVBclmExu5fOy6n(ffwWImDLJGFoQkUvi0Mg3Cz8S,u3854IJEng7HUmA,D6iGJsZVmjC14yU):
	s8Oimqou2fZD,GG9zmPqulYDyJCtWwkE8,d7on6sKDqkNY,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,zKHPsDVeYF,n9f5Gd7kZBXip8W,BcDrToCazSQusH10ilL,tiIc9lDHrUd,UrmJVLMKYwNQFS4XBP = ffwWImDLJGFoQkUvi0Mg3Cz8S
	n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw = int(n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw)
	MUbBir1El9sKaxj0 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',GG9zmPqulYDyJCtWwkE8,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if MUbBir1El9sKaxj0:
		MUbBir1El9sKaxj0,dpoz63MXQBNf1RxacO2I,FFIjQeyNEqa1Ap = MUbBir1El9sKaxj0[0]
		GG9zmPqulYDyJCtWwkE8 = GG9zmPqulYDyJCtWwkE8.replace(MUbBir1El9sKaxj0,'')
	eF5dlZMCcL29nJBEaKNj7 = GG9zmPqulYDyJCtWwkE8
	lXbFJn6ZWvDofqEdAMuLzprUtV7 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('^_(\w\w\w)_(.*?)$',GG9zmPqulYDyJCtWwkE8,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if lXbFJn6ZWvDofqEdAMuLzprUtV7:
		lXbFJn6ZWvDofqEdAMuLzprUtV7,GG9zmPqulYDyJCtWwkE8 = lXbFJn6ZWvDofqEdAMuLzprUtV7[0]
		AAEbh2eY8oRd = '_MOD_' in GG9zmPqulYDyJCtWwkE8
		L96HvDd3sfBiCSRT = s8Oimqou2fZD=='folder'
		if AAEbh2eY8oRd and L96HvDd3sfBiCSRT: DknNRL79Cr = ';'
		elif AAEbh2eY8oRd and not L96HvDd3sfBiCSRT: DknNRL79Cr = mtrqOcwh5Ux4aD7S9JQfE
		elif not AAEbh2eY8oRd and L96HvDd3sfBiCSRT: DknNRL79Cr = ','
		elif not AAEbh2eY8oRd and not L96HvDd3sfBiCSRT: DknNRL79Cr = ' '
		GG9zmPqulYDyJCtWwkE8 = GG9zmPqulYDyJCtWwkE8.replace('_MOD_','')
		lXbFJn6ZWvDofqEdAMuLzprUtV7 = DknNRL79Cr+'[COLOR FFC89008]'+lXbFJn6ZWvDofqEdAMuLzprUtV7+' [/COLOR]'
	else: lXbFJn6ZWvDofqEdAMuLzprUtV7 = ''
	if MUbBir1El9sKaxj0:
		if vciEXHThAPto76QIR2pK:
			MUbBir1El9sKaxj0 = '[COLOR FFFFFF00]'+dpoz63MXQBNf1RxacO2I+' '+FFIjQeyNEqa1Ap+'[/COLOR]'
			if lXbFJn6ZWvDofqEdAMuLzprUtV7: GG9zmPqulYDyJCtWwkE8 = MUbBir1El9sKaxj0+' '+HwksZdFnbNg3Pr+lXbFJn6ZWvDofqEdAMuLzprUtV7+GG9zmPqulYDyJCtWwkE8
			else: GG9zmPqulYDyJCtWwkE8 = MUbBir1El9sKaxj0+HwksZdFnbNg3Pr+GG9zmPqulYDyJCtWwkE8+' '
		elif wvkR1es6d0SrjxKt5FZTMUWz7a:
			if lXbFJn6ZWvDofqEdAMuLzprUtV7:
				MUbBir1El9sKaxj0 = '[COLOR FFFFFF00]'+dpoz63MXQBNf1RxacO2I+' '+FFIjQeyNEqa1Ap+'[/COLOR]'
				GG9zmPqulYDyJCtWwkE8 = MUbBir1El9sKaxj0+' '+lXbFJn6ZWvDofqEdAMuLzprUtV7+GG9zmPqulYDyJCtWwkE8
			else:
				MUbBir1El9sKaxj0 = '[COLOR FFFFFF00]'+FFIjQeyNEqa1Ap+' '+dpoz63MXQBNf1RxacO2I+'[/COLOR]'
				GG9zmPqulYDyJCtWwkE8 = GG9zmPqulYDyJCtWwkE8+' '+HwksZdFnbNg3Pr+MUbBir1El9sKaxj0
	elif lXbFJn6ZWvDofqEdAMuLzprUtV7:
		GG9zmPqulYDyJCtWwkE8 = qYbFUezndJt6NaZyBH3LckPm9S8(GG9zmPqulYDyJCtWwkE8,lXbFJn6ZWvDofqEdAMuLzprUtV7)
		GG9zmPqulYDyJCtWwkE8 = lXbFJn6ZWvDofqEdAMuLzprUtV7+GG9zmPqulYDyJCtWwkE8
	ffwWImDLJGFoQkUvi0Mg3Cz8S = s8Oimqou2fZD,eF5dlZMCcL29nJBEaKNj7,d7on6sKDqkNY,str(n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw),zKHPsDVeYF,n9f5Gd7kZBXip8W,BcDrToCazSQusH10ilL,tiIc9lDHrUd,UrmJVLMKYwNQFS4XBP
	nny4D1cVZ2EQp3 = {'type':'','mode':'','url':'','text':'','page':'','name':'','image':'','context':'','infodict':''}
	nny4D1cVZ2EQp3['name'] = TaEr2nR3f5e8oXzpy(eF5dlZMCcL29nJBEaKNj7)
	nny4D1cVZ2EQp3['type'] = s8Oimqou2fZD.strip(' ')
	nny4D1cVZ2EQp3['mode'] = str(n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw).strip(' ')
	if s8Oimqou2fZD=='folder' and n9f5Gd7kZBXip8W: nny4D1cVZ2EQp3['page'] = TaEr2nR3f5e8oXzpy(n9f5Gd7kZBXip8W.strip(' '))
	if tiIc9lDHrUd: nny4D1cVZ2EQp3['context'] = tiIc9lDHrUd.strip(' ')
	if BcDrToCazSQusH10ilL: nny4D1cVZ2EQp3['text'] = TaEr2nR3f5e8oXzpy(BcDrToCazSQusH10ilL.strip(' '))
	if zKHPsDVeYF: nny4D1cVZ2EQp3['image'] = TaEr2nR3f5e8oXzpy(zKHPsDVeYF.strip(' '))
	if UrmJVLMKYwNQFS4XBP:
		UrmJVLMKYwNQFS4XBP = str(UrmJVLMKYwNQFS4XBP)
		nny4D1cVZ2EQp3['infodict'] = TaEr2nR3f5e8oXzpy(UrmJVLMKYwNQFS4XBP.strip(' '))
		UrmJVLMKYwNQFS4XBP = eval(UrmJVLMKYwNQFS4XBP)
	else: UrmJVLMKYwNQFS4XBP = {}
	if d7on6sKDqkNY: nny4D1cVZ2EQp3['url'] = TaEr2nR3f5e8oXzpy(d7on6sKDqkNY.strip(' '))
	Sc6EmN24pYi = {'name':'','context_menu':'','plot':'','stars':'','image':'','type':'','isFolder':'','newpath':'','duration':''}
	t3y5GoPprKTBC0NWu29 = []
	fFk6KGpmNHWXyM1uicslRD2t8jr4e = 'plugin://'+aZhcuMGisIkl4npqDoJSrWy5fExX+'/?type='+nny4D1cVZ2EQp3['type']+'&mode='+nny4D1cVZ2EQp3['mode']
	if nny4D1cVZ2EQp3['page']: fFk6KGpmNHWXyM1uicslRD2t8jr4e += '&page='+nny4D1cVZ2EQp3['page']
	if nny4D1cVZ2EQp3['name']: fFk6KGpmNHWXyM1uicslRD2t8jr4e += '&name='+nny4D1cVZ2EQp3['name']
	if nny4D1cVZ2EQp3['text']: fFk6KGpmNHWXyM1uicslRD2t8jr4e += '&text='+nny4D1cVZ2EQp3['text']
	if nny4D1cVZ2EQp3['infodict']: fFk6KGpmNHWXyM1uicslRD2t8jr4e += '&infodict='+nny4D1cVZ2EQp3['infodict']
	if nny4D1cVZ2EQp3['image']: fFk6KGpmNHWXyM1uicslRD2t8jr4e += '&image='+nny4D1cVZ2EQp3['image']
	if nny4D1cVZ2EQp3['url']: fFk6KGpmNHWXyM1uicslRD2t8jr4e += '&url='+nny4D1cVZ2EQp3['url']
	if n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw!=265: Sc6EmN24pYi['favorites'] = True
	else: Sc6EmN24pYi['favorites'] = False
	if nny4D1cVZ2EQp3['context']: fFk6KGpmNHWXyM1uicslRD2t8jr4e += '&context='+nny4D1cVZ2EQp3['context']
	if n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw in [235,238] and s8Oimqou2fZD=='live' and 'EPG' in tiIc9lDHrUd:
		l0npdjazro7A5tq = 'plugin://'+aZhcuMGisIkl4npqDoJSrWy5fExX+'?mode=238&text=SHORT_EPG&url='+d7on6sKDqkNY
		j6LJuziRqZAPgNpQhx = '[COLOR FFFFFF00]البرامج القادمة[/COLOR]'
		fUgOGCw31LlSer2NIphQBH9 = (j6LJuziRqZAPgNpQhx,'RunPlugin('+l0npdjazro7A5tq+')')
		t3y5GoPprKTBC0NWu29.append(fUgOGCw31LlSer2NIphQBH9)
	if n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==265:
		NRTxwWEFc6SzytV0G3vMb2YOsjl = u3854IJEng7HUmA(BcDrToCazSQusH10ilL,True)
		if NRTxwWEFc6SzytV0G3vMb2YOsjl>0:
			l0npdjazro7A5tq = 'plugin://'+aZhcuMGisIkl4npqDoJSrWy5fExX+'?mode=266&text='+BcDrToCazSQusH10ilL
			j6LJuziRqZAPgNpQhx = '[COLOR FFFFFF00]مسح قائمة آخر 50 '+NNbLf2d3Slq6pV(BcDrToCazSQusH10ilL)+'[/COLOR]'
			fUgOGCw31LlSer2NIphQBH9 = (j6LJuziRqZAPgNpQhx,'RunPlugin('+l0npdjazro7A5tq+')')
			t3y5GoPprKTBC0NWu29.append(fUgOGCw31LlSer2NIphQBH9)
	if s8Oimqou2fZD=='video' and n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw!=331:
		l0npdjazro7A5tq = fFk6KGpmNHWXyM1uicslRD2t8jr4e+'&context=6_DOWNLOAD'
		j6LJuziRqZAPgNpQhx = '[COLOR FFFFFF00]تحميل ملف الفيديو[/COLOR]'
		fUgOGCw31LlSer2NIphQBH9 = (j6LJuziRqZAPgNpQhx,'RunPlugin('+l0npdjazro7A5tq+')')
		t3y5GoPprKTBC0NWu29.append(fUgOGCw31LlSer2NIphQBH9)
	if n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==331:
		l0npdjazro7A5tq = fFk6KGpmNHWXyM1uicslRD2t8jr4e+'&context=6_DELETE'
		j6LJuziRqZAPgNpQhx = '[COLOR FFFFFF00]حذف ملف الفيديو[/COLOR]'
		fUgOGCw31LlSer2NIphQBH9 = (j6LJuziRqZAPgNpQhx,'RunPlugin('+l0npdjazro7A5tq+')')
		t3y5GoPprKTBC0NWu29.append(fUgOGCw31LlSer2NIphQBH9)
	if s8Oimqou2fZD=='folder' and n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==540:
		zlImL2qOfwSiRcj = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,'list','GLOBALSEARCH_SITES')
		if zlImL2qOfwSiRcj:
			l0npdjazro7A5tq = 'plugin://'+aZhcuMGisIkl4npqDoJSrWy5fExX+'?context=7'
			j6LJuziRqZAPgNpQhx = '[COLOR FFFFFF00]مسح جميع كلمات البحث[/COLOR]'
			fUgOGCw31LlSer2NIphQBH9 = (j6LJuziRqZAPgNpQhx,'RunPlugin('+l0npdjazro7A5tq+')')
			t3y5GoPprKTBC0NWu29.append(fUgOGCw31LlSer2NIphQBH9)
	JmtgEGniIZfK = [9990,2,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,540,710,719,761,762]
	if n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw not in JmtgEGniIZfK:
		l0npdjazro7A5tq = 'plugin://'+aZhcuMGisIkl4npqDoJSrWy5fExX+'?context=8&mode=260'
		j6LJuziRqZAPgNpQhx = '[COLOR FFFFFF00]ذهاب للقائمة الرئيسية[/COLOR]'
		fUgOGCw31LlSer2NIphQBH9 = (j6LJuziRqZAPgNpQhx,'RunPlugin('+l0npdjazro7A5tq+')')
		t3y5GoPprKTBC0NWu29.append(fUgOGCw31LlSer2NIphQBH9)
	yLaiYW7RdFswtfJho = [0,150,160,170,190,260,280,330,340,410,500,520,530,560,760]
	if n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw%10 and n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw!=9990:
		Ewuj4lL9QI6nY7 = n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw-n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw%10
		if Ewuj4lL9QI6nY7==280: Ewuj4lL9QI6nY7 = 230
		if Ewuj4lL9QI6nY7==410: Ewuj4lL9QI6nY7 = 400
		if Ewuj4lL9QI6nY7==520: Ewuj4lL9QI6nY7 = 510
		if Ewuj4lL9QI6nY7 not in yLaiYW7RdFswtfJho:
			l0npdjazro7A5tq = 'plugin://'+aZhcuMGisIkl4npqDoJSrWy5fExX+'?context=8&mode='+str(Ewuj4lL9QI6nY7)
			j6LJuziRqZAPgNpQhx = '[COLOR FFFFFF00]ذهاب لبداية الموقع[/COLOR]'
			fUgOGCw31LlSer2NIphQBH9 = (j6LJuziRqZAPgNpQhx,'RunPlugin('+l0npdjazro7A5tq+')')
			t3y5GoPprKTBC0NWu29.append(fUgOGCw31LlSer2NIphQBH9)
	l0npdjazro7A5tq = fFk6KGpmNHWXyM1uicslRD2t8jr4e+'&context=9'
	j6LJuziRqZAPgNpQhx = '[COLOR FFFFFF00]تحديث القائمة الحالية[/COLOR]'
	fUgOGCw31LlSer2NIphQBH9 = (j6LJuziRqZAPgNpQhx,'RunPlugin('+l0npdjazro7A5tq+')')
	t3y5GoPprKTBC0NWu29.append(fUgOGCw31LlSer2NIphQBH9)
	if s8Oimqou2fZD in ['link','video','live']: qS2t96WCoHhifT3En = False
	elif s8Oimqou2fZD=='folder': qS2t96WCoHhifT3En = True
	Sc6EmN24pYi['name'] = GG9zmPqulYDyJCtWwkE8
	Sc6EmN24pYi['context_menu'] = t3y5GoPprKTBC0NWu29
	if 'plot' in list(UrmJVLMKYwNQFS4XBP.keys()): Sc6EmN24pYi['plot'] = UrmJVLMKYwNQFS4XBP['plot']
	if 'stars' in list(UrmJVLMKYwNQFS4XBP.keys()): Sc6EmN24pYi['stars'] = UrmJVLMKYwNQFS4XBP['stars']
	if zKHPsDVeYF: Sc6EmN24pYi['image'] = zKHPsDVeYF
	if s8Oimqou2fZD=='video' and n9f5Gd7kZBXip8W:
		Oluz7EJeXZC = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('[\d:]+',n9f5Gd7kZBXip8W,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if Oluz7EJeXZC:
			Oluz7EJeXZC = '0:0:0:0:0:'+Oluz7EJeXZC[0]
			HXj9St07uNI6JBACMxcPqsvO8KVw,A58xkvaFp16Qh,SSKurH2gALFicx7Gm,sngrUtL9vd7wB8ij1oDN4TpA05KO,C4VMh3yJzb5D6 = Oluz7EJeXZC.rsplit(':',4)
			q3kN8hDBeL = int(A58xkvaFp16Qh)*24*X6q8xOh3QUvB5D1dZJnmRC9TzauGrL+int(SSKurH2gALFicx7Gm)*X6q8xOh3QUvB5D1dZJnmRC9TzauGrL+int(sngrUtL9vd7wB8ij1oDN4TpA05KO)*60+int(C4VMh3yJzb5D6)
			Sc6EmN24pYi['duration'] = q3kN8hDBeL
	Sc6EmN24pYi['type'] = s8Oimqou2fZD
	Sc6EmN24pYi['isFolder'] = qS2t96WCoHhifT3En
	Sc6EmN24pYi['newpath'] = fFk6KGpmNHWXyM1uicslRD2t8jr4e
	Sc6EmN24pYi['menuItem'] = ffwWImDLJGFoQkUvi0Mg3Cz8S
	Sc6EmN24pYi['mode'] = n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw
	return Sc6EmN24pYi
def EoLBOMxkziXqCPDZsp0jn(u3854IJEng7HUmA):
	g1lNFWk5E6mw8xcA = []
	from S8VCsPpcIU import h0WgvJjBRGy,dF9PbrkHwI
	D6iGJsZVmjC14yU = h0WgvJjBRGy()
	for ffwWImDLJGFoQkUvi0Mg3Cz8S in muPDGHvJwFieQYCW62bB:
		Sc6EmN24pYi = Ze3U0adCsoVBclmExu5fOy6n(ffwWImDLJGFoQkUvi0Mg3Cz8S,u3854IJEng7HUmA,D6iGJsZVmjC14yU)
		if Sc6EmN24pYi['favorites']:
			dFGTILifkw6Xesjvo5ER = dF9PbrkHwI(D6iGJsZVmjC14yU,Sc6EmN24pYi['menuItem'],Sc6EmN24pYi['newpath'])
			Sc6EmN24pYi['context_menu'] = dFGTILifkw6Xesjvo5ER+Sc6EmN24pYi['context_menu']
		g1lNFWk5E6mw8xcA.append(Sc6EmN24pYi)
	return g1lNFWk5E6mw8xcA
def xF7DZvCiAq5J3rO6b8cHtuXj9(HCFix1cLXj9R6e87BqZ):
	DknNRL79Cr,Ctd4FZqKDyeVX81TP75kRHib2uz, = [],''
	for gH6oMIGUWO1sA4aYBbfChRw5yN in HCFix1cLXj9R6e87BqZ:
		if not gH6oMIGUWO1sA4aYBbfChRw5yN: DknNRL79Cr.append('')
		else: break
	HCFix1cLXj9R6e87BqZ = HCFix1cLXj9R6e87BqZ[len(DknNRL79Cr):]
	RxgdTHfDar8EXt = '\n\n\n\n'.join(HCFix1cLXj9R6e87BqZ)
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('===== ===== =====','000001')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('[COLOR FFC89008]','000002')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('[COLOR FFFFFF00]','000003')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('[/COLOR]','000004')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('[RIGHT]','000005')
	FZVOMyRXpio = 100000
	ccVZdQClUzNFa1fjDLJ = {}
	EEIOWjlTxXAe470bVPcKHvsJ3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('http.*?[\r\n ]',RxgdTHfDar8EXt,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for YNAurzsFiWTEO4wcVt in EEIOWjlTxXAe470bVPcKHvsJ3:
		FZVOMyRXpio += 1
		RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace(YNAurzsFiWTEO4wcVt,str(FZVOMyRXpio))
		ccVZdQClUzNFa1fjDLJ[str(FZVOMyRXpio)] = YNAurzsFiWTEO4wcVt
	for JF9iBfWwDE1GNjeS4HtOsgk7 in range(0,len(RxgdTHfDar8EXt),4800):
		I7IMQtPhRU8YHpVrJvE9zofSOX = RxgdTHfDar8EXt[JF9iBfWwDE1GNjeS4HtOsgk7:JF9iBfWwDE1GNjeS4HtOsgk7+4800]
		GLzgtpD2bm7icFokafJe = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.language.code')
		d7on6sKDqkNY = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+GLzgtpD2bm7icFokafJe
		UZbaV6FlwAM0uNvdS1mcIPypC = {'Content-Type':'text/plain'}
		mmaHZ8luVhQDj9w = I7IMQtPhRU8YHpVrJvE9zofSOX.encode('utf8')
		pPvgKtqo5IAzadVRZsCGU = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,'POST',d7on6sKDqkNY,mmaHZ8luVhQDj9w,UZbaV6FlwAM0uNvdS1mcIPypC,'','','LIBRARY-GLOSBE_TRANSLATE-1st')
		if pPvgKtqo5IAzadVRZsCGU.succeeded:
			kDQZoFnLUTYc8G45u21ye = pPvgKtqo5IAzadVRZsCGU.content
			VlmGaE5jFzUJtAei = GVQAnvYCT3dS('str',kDQZoFnLUTYc8G45u21ye)
			if VlmGaE5jFzUJtAei:
				VlmGaE5jFzUJtAei = VlmGaE5jFzUJtAei['translation']
				VlmGaE5jFzUJtAei = zKGXT5sJeRq(VlmGaE5jFzUJtAei)
				for p4kmOV7v1QdLMoKASIq9gUhxG20 in range(len(VlmGaE5jFzUJtAei)):
					Ctd4FZqKDyeVX81TP75kRHib2uz += VlmGaE5jFzUJtAei[p4kmOV7v1QdLMoKASIq9gUhxG20][0]
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.replace('000001','===== ===== =====')
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.replace('000002','[COLOR FFC89008]')
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.replace('000003','[COLOR FFFFFF00]')
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.replace('000004','[/COLOR]')
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.replace('000005','[RIGHT]')
	for FZVOMyRXpio in list(ccVZdQClUzNFa1fjDLJ.keys()):
		YNAurzsFiWTEO4wcVt = ccVZdQClUzNFa1fjDLJ[FZVOMyRXpio]
		Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.replace(FZVOMyRXpio,YNAurzsFiWTEO4wcVt)
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.split('\n\n\n\n')
	return DknNRL79Cr+Ctd4FZqKDyeVX81TP75kRHib2uz
def JxeEgfrVTY(HCFix1cLXj9R6e87BqZ):
	DknNRL79Cr,Ctd4FZqKDyeVX81TP75kRHib2uz, = [],''
	for gH6oMIGUWO1sA4aYBbfChRw5yN in HCFix1cLXj9R6e87BqZ:
		if not gH6oMIGUWO1sA4aYBbfChRw5yN: DknNRL79Cr.append('')
		else: break
	HCFix1cLXj9R6e87BqZ = HCFix1cLXj9R6e87BqZ[len(DknNRL79Cr):]
	RxgdTHfDar8EXt = '\\n\\n\\n\\n'.join(HCFix1cLXj9R6e87BqZ)
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('كلا','no')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('استمرار','continue')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('===== ===== =====','000001')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('[COLOR FFC89008]','000002')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('[COLOR FFFFFF00]','000003')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('[/COLOR]','000004')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('[RIGHT]','000005')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('[CENTER]','000006')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('[RTL]','000007')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace("'","\\\\\\'")
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('"','\\\\\\"')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('\n','\\n')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('\r','\\\\r')
	for JF9iBfWwDE1GNjeS4HtOsgk7 in range(0,len(RxgdTHfDar8EXt),4800):
		I7IMQtPhRU8YHpVrJvE9zofSOX = RxgdTHfDar8EXt[JF9iBfWwDE1GNjeS4HtOsgk7:JF9iBfWwDE1GNjeS4HtOsgk7+4800]
		d7on6sKDqkNY = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		UZbaV6FlwAM0uNvdS1mcIPypC = {'Content-Type':'application/x-www-form-urlencoded'}
		GLzgtpD2bm7icFokafJe = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.language.code')
		mmaHZ8luVhQDj9w = 'f.req='+TaEr2nR3f5e8oXzpy('[[["MkEWBc","[[\\"'+I7IMQtPhRU8YHpVrJvE9zofSOX+'\\",\\"ar\\",\\"'+GLzgtpD2bm7icFokafJe+'\\",1],[]]",null,"generic"]]]','')
		mmaHZ8luVhQDj9w = mmaHZ8luVhQDj9w.replace('%5Cn','%5C%5Cn')
		pPvgKtqo5IAzadVRZsCGU = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,'POST',d7on6sKDqkNY,mmaHZ8luVhQDj9w,UZbaV6FlwAM0uNvdS1mcIPypC,'','','LIBRARY-GOOGLE_TRANSLATE-1st')
		if pPvgKtqo5IAzadVRZsCGU.succeeded:
			kDQZoFnLUTYc8G45u21ye = pPvgKtqo5IAzadVRZsCGU.content
			kDQZoFnLUTYc8G45u21ye = kDQZoFnLUTYc8G45u21ye.split('\n')[-1]
			VlmGaE5jFzUJtAei = GVQAnvYCT3dS('str',kDQZoFnLUTYc8G45u21ye)[0][2]
			if VlmGaE5jFzUJtAei:
				VlmGaE5jFzUJtAei = GVQAnvYCT3dS('str',VlmGaE5jFzUJtAei)[1][0][0][5]
				VlmGaE5jFzUJtAei = zKGXT5sJeRq(VlmGaE5jFzUJtAei)
				for p4kmOV7v1QdLMoKASIq9gUhxG20 in range(len(VlmGaE5jFzUJtAei)):
					Ctd4FZqKDyeVX81TP75kRHib2uz += VlmGaE5jFzUJtAei[p4kmOV7v1QdLMoKASIq9gUhxG20][0]
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.replace('00000','0000').replace('0000','000')
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.replace('0001','===== ===== =====')
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.replace('0002','[COLOR FFC89008]')
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.replace('0003','[COLOR FFFFFF00]')
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.replace('0004','[/COLOR]')
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.replace('0005','[RIGHT]')
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.replace('0006','[CENTER]')
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.replace('0007','[RTL]')
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.split('\n\n\n\n')
	return DknNRL79Cr+Ctd4FZqKDyeVX81TP75kRHib2uz
def TW4u5nQLz8NfVMXy7FqPiRDZAd(HCFix1cLXj9R6e87BqZ):
	DknNRL79Cr,DRnmEzhVxa3CjW = [],[]
	for gH6oMIGUWO1sA4aYBbfChRw5yN in HCFix1cLXj9R6e87BqZ:
		if not gH6oMIGUWO1sA4aYBbfChRw5yN: DknNRL79Cr.append('')
		else: break
	HCFix1cLXj9R6e87BqZ = HCFix1cLXj9R6e87BqZ[len(DknNRL79Cr):]
	RxgdTHfDar8EXt = '\n\n\n\n'.join(HCFix1cLXj9R6e87BqZ)
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('كلا','no')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('استمرار','continue')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('أدناه','below')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('[COLOR FFC89008]','00001')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('[COLOR FFFFFF00]','00002')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('[/COLOR]','00003')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('=====','00004')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace(',','00005')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('[RTL]','00009')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('[CENTER]','0000A')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('\r','0000B')
	HCFix1cLXj9R6e87BqZ = RxgdTHfDar8EXt.split('\n')
	RxgdTHfDar8EXt,Ctd4FZqKDyeVX81TP75kRHib2uz = '',''
	for gH6oMIGUWO1sA4aYBbfChRw5yN in HCFix1cLXj9R6e87BqZ:
		if len(RxgdTHfDar8EXt+gH6oMIGUWO1sA4aYBbfChRw5yN)<1800: RxgdTHfDar8EXt += '\n'+gH6oMIGUWO1sA4aYBbfChRw5yN
		else:
			DRnmEzhVxa3CjW.append(RxgdTHfDar8EXt)
			RxgdTHfDar8EXt = gH6oMIGUWO1sA4aYBbfChRw5yN
	DRnmEzhVxa3CjW.append(RxgdTHfDar8EXt)
	from json import dumps as Y0wq6zpFM1m7kPbrDCRcJ
	for gH6oMIGUWO1sA4aYBbfChRw5yN in DRnmEzhVxa3CjW:
		UZbaV6FlwAM0uNvdS1mcIPypC = {'Content-Type':'application/json','User-Agent':''}
		d7on6sKDqkNY = 'https://api.reverso.net/translate/v1/translation'
		GLzgtpD2bm7icFokafJe = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.language.code')
		mmaHZ8luVhQDj9w = {"format":"text","from":"ara","to":GLzgtpD2bm7icFokafJe,"input":gH6oMIGUWO1sA4aYBbfChRw5yN,"options":{"sentenceSplitter":True,"origin":"translation.web","contextResults":False,"languageDetection":False}}
		mmaHZ8luVhQDj9w = Y0wq6zpFM1m7kPbrDCRcJ(mmaHZ8luVhQDj9w)
		pPvgKtqo5IAzadVRZsCGU = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,'POST',d7on6sKDqkNY,mmaHZ8luVhQDj9w,UZbaV6FlwAM0uNvdS1mcIPypC,'','','LIBRARY-REVERSO_TRANSLATE-1st')
		if pPvgKtqo5IAzadVRZsCGU.succeeded:
			kDQZoFnLUTYc8G45u21ye = pPvgKtqo5IAzadVRZsCGU.content
			kDQZoFnLUTYc8G45u21ye = GVQAnvYCT3dS('dict',kDQZoFnLUTYc8G45u21ye)
			Ctd4FZqKDyeVX81TP75kRHib2uz += '\n'+''.join(kDQZoFnLUTYc8G45u21ye['translation'])
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz[2:]
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.replace('000000','00000').replace('00000','0000').replace('0000','000')
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.replace('0001','[COLOR FFC89008]')
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.replace('0002','[COLOR FFFFFF00]')
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.replace('0003','[/COLOR]')
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.replace('0004','=====')
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.replace('0005',',')
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.replace('0009','[RTL]')
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.replace('000A','[CENTER]')
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.replace('000B','\r')
	Ctd4FZqKDyeVX81TP75kRHib2uz = Ctd4FZqKDyeVX81TP75kRHib2uz.split('\n\n\n\n')
	return DknNRL79Cr+Ctd4FZqKDyeVX81TP75kRHib2uz
def xvgaJ2CtisWRSfXq7uToKmkEMIP(HCFix1cLXj9R6e87BqZ):
	nZHAcj40I5EgdWvR8GeTrioNb92 = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.language.translate')
	if not nZHAcj40I5EgdWvR8GeTrioNb92 or not HCFix1cLXj9R6e87BqZ: return HCFix1cLXj9R6e87BqZ
	yLhu2x01UkCdMjnGf7PZzK4 = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.language.provider')
	GLzgtpD2bm7icFokafJe = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.language.code')
	nn30wpDd6b9zgTPUyKC = GLzgtpD2bm7icFokafJe+'__'+str(HCFix1cLXj9R6e87BqZ)
	if2qpOxlZd8MBGeo5uNIyLEsz.setSetting('av.language.translate','')
	Ctd4FZqKDyeVX81TP75kRHib2uz = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,'list','TRANSLATE_'+yLhu2x01UkCdMjnGf7PZzK4,nn30wpDd6b9zgTPUyKC)
	if not Ctd4FZqKDyeVX81TP75kRHib2uz:
		if yLhu2x01UkCdMjnGf7PZzK4=='GOOGLE': Ctd4FZqKDyeVX81TP75kRHib2uz = JxeEgfrVTY(HCFix1cLXj9R6e87BqZ)
		elif yLhu2x01UkCdMjnGf7PZzK4=='REVERSO': Ctd4FZqKDyeVX81TP75kRHib2uz = TW4u5nQLz8NfVMXy7FqPiRDZAd(HCFix1cLXj9R6e87BqZ)
		elif yLhu2x01UkCdMjnGf7PZzK4=='GLOSBE': Ctd4FZqKDyeVX81TP75kRHib2uz = xF7DZvCiAq5J3rO6b8cHtuXj9(HCFix1cLXj9R6e87BqZ)
		if len(HCFix1cLXj9R6e87BqZ)==len(Ctd4FZqKDyeVX81TP75kRHib2uz):
			kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,'TRANSLATE_'+yLhu2x01UkCdMjnGf7PZzK4,nn30wpDd6b9zgTPUyKC,Ctd4FZqKDyeVX81TP75kRHib2uz,WA14geuaxzJQ0ND3q8f2hdbk)
		else:
			Ctd4FZqKDyeVX81TP75kRHib2uz = HCFix1cLXj9R6e87BqZ
			xa60ce2znAlyL5Z8ESXhO('الترجمة فشلت','Translation Failed')
	if2qpOxlZd8MBGeo5uNIyLEsz.setSetting('av.language.translate','1')
	return Ctd4FZqKDyeVX81TP75kRHib2uz
def UNXgiou9B5DGq2nFsh(ffwWImDLJGFoQkUvi0Mg3Cz8S,g1lNFWk5E6mw8xcA,agX9nom53W,KKXJlt8NeHzvuDUBMCgrOax,WwhN9ZqFP5nK3UcALM4x):
	s8Oimqou2fZD,GG9zmPqulYDyJCtWwkE8,d7on6sKDqkNY,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,zKHPsDVeYF,eWICxFNw73mJnSToUiR,RxgdTHfDar8EXt,tiIc9lDHrUd,UrmJVLMKYwNQFS4XBP = ffwWImDLJGFoQkUvi0Mg3Cz8S
	gWErdVLqa6J1hiuUf = []
	nZHAcj40I5EgdWvR8GeTrioNb92 = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.language.translate')
	if nZHAcj40I5EgdWvR8GeTrioNb92:
		cs3rb6xAkdLaEQue4lJtUORMhY,VtAUP9f5EWc28F6OSgT1yL7Q,RTYhiaQ6HsDuZk3lXJNUpzwKynSt8d = [],[],[]
		if not gWErdVLqa6J1hiuUf:
			for Sc6EmN24pYi in g1lNFWk5E6mw8xcA:
				GG9zmPqulYDyJCtWwkE8 = Sc6EmN24pYi['name'].replace(HwksZdFnbNg3Pr,'').replace(W3oZ8vhLnsOdIaDp6qeN214kcJCVz,'')
				MUbBir1El9sKaxj0 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',GG9zmPqulYDyJCtWwkE8,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
				if MUbBir1El9sKaxj0:
					DknNRL79Cr,dpoz63MXQBNf1RxacO2I,FFIjQeyNEqa1Ap,fBD10G45rxzjQwdh7C,GG9zmPqulYDyJCtWwkE8 = MUbBir1El9sKaxj0[0]
					MUbBir1El9sKaxj0 = DknNRL79Cr+dpoz63MXQBNf1RxacO2I+' '+FFIjQeyNEqa1Ap+fBD10G45rxzjQwdh7C+' '
				else:
					MUbBir1El9sKaxj0 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',GG9zmPqulYDyJCtWwkE8,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
					if MUbBir1El9sKaxj0:
						GG9zmPqulYDyJCtWwkE8,DknNRL79Cr,FFIjQeyNEqa1Ap,dpoz63MXQBNf1RxacO2I,fBD10G45rxzjQwdh7C = MUbBir1El9sKaxj0[0]
						MUbBir1El9sKaxj0 = DknNRL79Cr+dpoz63MXQBNf1RxacO2I+' '+FFIjQeyNEqa1Ap+fBD10G45rxzjQwdh7C+' '
					else: MUbBir1El9sKaxj0 = ''
				lXbFJn6ZWvDofqEdAMuLzprUtV7 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('^(.\[COLOR FFC89008\]\w\w\w \[/COLOR\])(.*?)$',GG9zmPqulYDyJCtWwkE8,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
				if lXbFJn6ZWvDofqEdAMuLzprUtV7: lXbFJn6ZWvDofqEdAMuLzprUtV7,GG9zmPqulYDyJCtWwkE8 = lXbFJn6ZWvDofqEdAMuLzprUtV7[0]
				else: lXbFJn6ZWvDofqEdAMuLzprUtV7 = ''
				cs3rb6xAkdLaEQue4lJtUORMhY.append(MUbBir1El9sKaxj0+lXbFJn6ZWvDofqEdAMuLzprUtV7)
				VtAUP9f5EWc28F6OSgT1yL7Q.append(GG9zmPqulYDyJCtWwkE8)
			RTYhiaQ6HsDuZk3lXJNUpzwKynSt8d = xvgaJ2CtisWRSfXq7uToKmkEMIP(VtAUP9f5EWc28F6OSgT1yL7Q)
			if RTYhiaQ6HsDuZk3lXJNUpzwKynSt8d:
				for JF9iBfWwDE1GNjeS4HtOsgk7 in range(len(g1lNFWk5E6mw8xcA)):
					Sc6EmN24pYi = g1lNFWk5E6mw8xcA[JF9iBfWwDE1GNjeS4HtOsgk7]
					Sc6EmN24pYi['name'] = cs3rb6xAkdLaEQue4lJtUORMhY[JF9iBfWwDE1GNjeS4HtOsgk7]+RTYhiaQ6HsDuZk3lXJNUpzwKynSt8d[JF9iBfWwDE1GNjeS4HtOsgk7]
					gWErdVLqa6J1hiuUf.append(Sc6EmN24pYi)
	if gWErdVLqa6J1hiuUf: g1lNFWk5E6mw8xcA = gWErdVLqa6J1hiuUf
	RA9q5KL34tMNlSuDXsg1Opm70ZfY,G1FfAUBndiCTjqVcLNzPwD8,uALNzhcoaPZJFx = [],0,0
	Ir6F4UgC8zRb372EhW = K3hFytImeYMkJBC.path.join(urI4Umothli03k1Ee,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw)
	try: soU97CePbDczKu8IkMrO5ilLWv = K3hFytImeYMkJBC.listdir(Ir6F4UgC8zRb372EhW)
	except:
		try: K3hFytImeYMkJBC.makedirs(Ir6F4UgC8zRb372EhW)
		except: pass
		soU97CePbDczKu8IkMrO5ilLWv = []
	qiXr4slWZOEJYk1QV8hK9Gnpj06aub = yESdCNQlxJs0GvVpL4F('menu_item')
	for Sc6EmN24pYi in g1lNFWk5E6mw8xcA:
		GG9zmPqulYDyJCtWwkE8 = Sc6EmN24pYi['name']
		t3y5GoPprKTBC0NWu29 = Sc6EmN24pYi['context_menu']
		TSaUALIVmoBHu = Sc6EmN24pYi['plot']
		myRNqDVj5BXGo41cT = Sc6EmN24pYi['stars']
		zKHPsDVeYF = Sc6EmN24pYi['image']
		s8Oimqou2fZD = Sc6EmN24pYi['type']
		Oluz7EJeXZC = Sc6EmN24pYi['duration']
		qS2t96WCoHhifT3En = Sc6EmN24pYi['isFolder']
		fFk6KGpmNHWXyM1uicslRD2t8jr4e = Sc6EmN24pYi['newpath']
		AAPw0koadgv48peuhHSybRYnGq = ZuEAJR1lNHkUf0.ListItem(GG9zmPqulYDyJCtWwkE8)
		AAPw0koadgv48peuhHSybRYnGq.addContextMenuItems(t3y5GoPprKTBC0NWu29)
		if zKHPsDVeYF: AAPw0koadgv48peuhHSybRYnGq.setArt({'icon':zKHPsDVeYF,'thumb':zKHPsDVeYF,'fanart':zKHPsDVeYF,'banner':zKHPsDVeYF,'clearart':zKHPsDVeYF,'poster':zKHPsDVeYF,'clearlogo':zKHPsDVeYF,'landscape':zKHPsDVeYF})
		else:
			GG9zmPqulYDyJCtWwkE8 = sTYDZCo483UAX5IvLGag2ezmR(GG9zmPqulYDyJCtWwkE8)
			GG9zmPqulYDyJCtWwkE8 = dlVCoGwxEZt376mrbaKJ(GG9zmPqulYDyJCtWwkE8)
			SPRut4v7d2oQ9ZchEsIlUAzxeXq = GG9zmPqulYDyJCtWwkE8+'.png'
			default = True
			if SPRut4v7d2oQ9ZchEsIlUAzxeXq in soU97CePbDczKu8IkMrO5ilLWv:
				jk6govEWO5HVFISufYeRhbQZXrPM4 = K3hFytImeYMkJBC.path.join(Ir6F4UgC8zRb372EhW,SPRut4v7d2oQ9ZchEsIlUAzxeXq)
				AAPw0koadgv48peuhHSybRYnGq.setArt({'icon':jk6govEWO5HVFISufYeRhbQZXrPM4,'thumb':jk6govEWO5HVFISufYeRhbQZXrPM4,'fanart':jk6govEWO5HVFISufYeRhbQZXrPM4,'banner':jk6govEWO5HVFISufYeRhbQZXrPM4,'clearart':jk6govEWO5HVFISufYeRhbQZXrPM4,'poster':jk6govEWO5HVFISufYeRhbQZXrPM4,'clearlogo':jk6govEWO5HVFISufYeRhbQZXrPM4,'landscape':jk6govEWO5HVFISufYeRhbQZXrPM4})
				default = False
			elif G1FfAUBndiCTjqVcLNzPwD8<60 and uALNzhcoaPZJFx<5:
				jk6govEWO5HVFISufYeRhbQZXrPM4 = K3hFytImeYMkJBC.path.join(Ir6F4UgC8zRb372EhW,SPRut4v7d2oQ9ZchEsIlUAzxeXq)
				try:
					hvLaCg0l6MOpn = C8WFqwgezo7sA(qiXr4slWZOEJYk1QV8hK9Gnpj06aub,'','','','',GG9zmPqulYDyJCtWwkE8,'menu_item','center',False,jk6govEWO5HVFISufYeRhbQZXrPM4)
					AAPw0koadgv48peuhHSybRYnGq.setArt({'icon':jk6govEWO5HVFISufYeRhbQZXrPM4,'thumb':jk6govEWO5HVFISufYeRhbQZXrPM4,'fanart':jk6govEWO5HVFISufYeRhbQZXrPM4,'banner':jk6govEWO5HVFISufYeRhbQZXrPM4,'clearart':jk6govEWO5HVFISufYeRhbQZXrPM4,'poster':jk6govEWO5HVFISufYeRhbQZXrPM4,'clearlogo':jk6govEWO5HVFISufYeRhbQZXrPM4,'landscape':jk6govEWO5HVFISufYeRhbQZXrPM4})
					G1FfAUBndiCTjqVcLNzPwD8 += 1
					default = False
				except: uALNzhcoaPZJFx += 1
			if default: AAPw0koadgv48peuhHSybRYnGq.setArt({'icon':Ov6ePJ4YgS0ZEy7KGskfn9uA,'thumb':Ok4BhX2lTIwpFy6d5Zct7Qvm,'fanart':ZZPCfGy9aigprj,'banner':ZZwjcIqs1SRnx7QYLvODC6lemuK,'clearart':FZpKODWb38QCUhf2TGjy0,'poster':p9dyN1MRF5jQxEXW,'clearlogo':GYZaukqHSCJL7T,'landscape':zFO6DZpRhQkEr20c7VXCM})
		if wH3qxmuXBTeak<20:
			if TSaUALIVmoBHu: AAPw0koadgv48peuhHSybRYnGq.setInfo('video',{'Plot':TSaUALIVmoBHu,'PlotOutline':TSaUALIVmoBHu})
			if myRNqDVj5BXGo41cT: AAPw0koadgv48peuhHSybRYnGq.setInfo('video',{'Rating':myRNqDVj5BXGo41cT})
			if not zKHPsDVeYF:
				AAPw0koadgv48peuhHSybRYnGq.setInfo('video',{'Title':GG9zmPqulYDyJCtWwkE8})
			if s8Oimqou2fZD=='video':
				AAPw0koadgv48peuhHSybRYnGq.setInfo('video',{'mediatype':'movie'})
				if Oluz7EJeXZC: AAPw0koadgv48peuhHSybRYnGq.setInfo('video',{'duration':Oluz7EJeXZC})
				AAPw0koadgv48peuhHSybRYnGq.setProperty('IsPlayable','true')
		else:
			DDLEjoaQCN = AAPw0koadgv48peuhHSybRYnGq.getVideoInfoTag()
			if myRNqDVj5BXGo41cT: DDLEjoaQCN.setRating(float(myRNqDVj5BXGo41cT))
			if not zKHPsDVeYF:
				DDLEjoaQCN.setTitle(GG9zmPqulYDyJCtWwkE8)
			if s8Oimqou2fZD=='video':
				DDLEjoaQCN.setMediaType('tvshow')
				if Oluz7EJeXZC: DDLEjoaQCN.setDuration(Oluz7EJeXZC)
				AAPw0koadgv48peuhHSybRYnGq.setProperty('IsPlayable','true')
		RA9q5KL34tMNlSuDXsg1Opm70ZfY.append((fFk6KGpmNHWXyM1uicslRD2t8jr4e,AAPw0koadgv48peuhHSybRYnGq,qS2t96WCoHhifT3En))
	I9AOhSdTGW4rX1yPc3oKQHnkJEe.setContent(KKtWUT6l8S,'tvshows')
	VUH4ZXuRDBpW1KjYqC2vL = I9AOhSdTGW4rX1yPc3oKQHnkJEe.addDirectoryItems(KKtWUT6l8S,RA9q5KL34tMNlSuDXsg1Opm70ZfY)
	I9AOhSdTGW4rX1yPc3oKQHnkJEe.endOfDirectory(KKtWUT6l8S,agX9nom53W,KKXJlt8NeHzvuDUBMCgrOax,WwhN9ZqFP5nK3UcALM4x)
	return VUH4ZXuRDBpW1KjYqC2vL
def tBq8fTGUWJY9zvbgXD0EAloPO(s8Oimqou2fZD,GG9zmPqulYDyJCtWwkE8,d7on6sKDqkNY,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,zKHPsDVeYF='',eWICxFNw73mJnSToUiR='',RxgdTHfDar8EXt='',tiIc9lDHrUd='',UrmJVLMKYwNQFS4XBP={}):
	GG9zmPqulYDyJCtWwkE8 = GG9zmPqulYDyJCtWwkE8.replace('\r','').replace('\n','').replace('\t','')
	d7on6sKDqkNY = d7on6sKDqkNY.replace('\r','').replace('\n','').replace('\t','')
	if '_SCRIPT_' in GG9zmPqulYDyJCtWwkE8: PCY2LJwTgIfan,GG9zmPqulYDyJCtWwkE8 = GG9zmPqulYDyJCtWwkE8.split('_SCRIPT_',1)
	else: PCY2LJwTgIfan,GG9zmPqulYDyJCtWwkE8 = '',GG9zmPqulYDyJCtWwkE8
	if PCY2LJwTgIfan:
		uaRvx3qohP0QOw1ybCY = GG9zmPqulYDyJCtWwkE8
		if not uaRvx3qohP0QOw1ybCY: uaRvx3qohP0QOw1ybCY = '....'
		elif uaRvx3qohP0QOw1ybCY.count('_')>1: uaRvx3qohP0QOw1ybCY = uaRvx3qohP0QOw1ybCY.split('_',2)[2]
		uaRvx3qohP0QOw1ybCY = uaRvx3qohP0QOw1ybCY.replace(' ','')
		uaRvx3qohP0QOw1ybCY = uaRvx3qohP0QOw1ybCY.replace('ـ','').replace('ة','ه').replace('ؤ','و')
		uaRvx3qohP0QOw1ybCY = uaRvx3qohP0QOw1ybCY.replace('أ','ا').replace('إ','ا').replace('آ','ا')
		uaRvx3qohP0QOw1ybCY = uaRvx3qohP0QOw1ybCY.replace('لأ','لا').replace('لإ','لا').replace('لآ','لا')
		uaRvx3qohP0QOw1ybCY = uaRvx3qohP0QOw1ybCY.replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
		uaRvx3qohP0QOw1ybCY = uaRvx3qohP0QOw1ybCY.replace('ِ','').replace('ٍ','').replace('ْ','').replace('ّ','')
		uaRvx3qohP0QOw1ybCY = uaRvx3qohP0QOw1ybCY.replace('|','').replace('~','')
		uaRvx3qohP0QOw1ybCY = uaRvx3qohP0QOw1ybCY.replace('اون لاين','').replace('سيما لايت','')
		jaGZrmCoSP2nJIV = ['العاب','خيال','البوم','الان','اطفال','حاليه','الغاز','صالح','الدين','مواليد','العالم','اعمال']
		if not any(VKuD93XbUeArRdyjgzPt in uaRvx3qohP0QOw1ybCY for VKuD93XbUeArRdyjgzPt in jaGZrmCoSP2nJIV): uaRvx3qohP0QOw1ybCY = uaRvx3qohP0QOw1ybCY.replace('ال','')
		uaRvx3qohP0QOw1ybCY = uaRvx3qohP0QOw1ybCY.replace('اخري','اخرى').replace('اجنبى','اجنبي').replace('عائليه','عائلي')
		uaRvx3qohP0QOw1ybCY = uaRvx3qohP0QOw1ybCY.replace('اجنبيه','اجنبي').replace('عربيه','عربي').replace('رومانسيه','رومانسي')
		uaRvx3qohP0QOw1ybCY = uaRvx3qohP0QOw1ybCY.replace('غربيه','غربي').replace('و مسلسلات','مسلسلات').replace('اغانى','اغاني')
		uaRvx3qohP0QOw1ybCY = uaRvx3qohP0QOw1ybCY.replace('تاريخي','تاريخ').replace('خيال علمي','خيال').replace('موسيقيه','موسيقى')
		uaRvx3qohP0QOw1ybCY = uaRvx3qohP0QOw1ybCY.replace('هندى','هندي').replace('هنديه','هندي').replace('وثائقيه','وثائقي')
		uaRvx3qohP0QOw1ybCY = uaRvx3qohP0QOw1ybCY.replace('تليفزيونيه','تلفزيون').replace('تلفزيونيه','تلفزيون').replace('و كرتون','وكرتون')
		uaRvx3qohP0QOw1ybCY = uaRvx3qohP0QOw1ybCY.replace('الحاليه','حاليه').replace('موسیقي','موسيقى').replace('الانمي','انمي')
		uaRvx3qohP0QOw1ybCY = uaRvx3qohP0QOw1ybCY.replace('المسلسلات','مسلسلات').replace('البرامج','برامج').replace('كارتون','كرتون')
		uaRvx3qohP0QOw1ybCY = uaRvx3qohP0QOw1ybCY.replace('حروب','حرب').replace('الاناشيد','اناشيد').replace('اسيويه','اسيوي')
		uaRvx3qohP0QOw1ybCY = uaRvx3qohP0QOw1ybCY.replace('عربى','عربي').replace('تركى','تركي').replace('تركيه','تركي')
		uaRvx3qohP0QOw1ybCY = uaRvx3qohP0QOw1ybCY.replace('رياضي','رياضة').replace('رياضه','رياضة').replace('اسيويه','اسيوي')
		uaRvx3qohP0QOw1ybCY = uaRvx3qohP0QOw1ybCY.replace('كوميدى','كوميدي').replace('كوميديه','كوميدي').replace('انيمي','انمي')
		uaRvx3qohP0QOw1ybCY = uaRvx3qohP0QOw1ybCY.replace('انيميشن','انميشن').replace('انمى','انميشن').replace('انمي','انميشن')
		uaRvx3qohP0QOw1ybCY = uaRvx3qohP0QOw1ybCY.replace('انميشنشن','انميشن').replace('الانميشن','انميشن').replace('افلام مسلسلات','افلام ومسلسلات')
		uaRvx3qohP0QOw1ybCY = uaRvx3qohP0QOw1ybCY.replace('  ',' ').strip(' ')
		PCY2LJwTgIfan = '_LST_'+NNbLf2d3Slq6pV(PCY2LJwTgIfan)
		if uaRvx3qohP0QOw1ybCY not in list(FEzkPuAaomBVKvS4pfx8.keys()): FEzkPuAaomBVKvS4pfx8[uaRvx3qohP0QOw1ybCY] = {}
		FEzkPuAaomBVKvS4pfx8[uaRvx3qohP0QOw1ybCY][PCY2LJwTgIfan] = [s8Oimqou2fZD,GG9zmPqulYDyJCtWwkE8,d7on6sKDqkNY,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,zKHPsDVeYF,eWICxFNw73mJnSToUiR,RxgdTHfDar8EXt,tiIc9lDHrUd,UrmJVLMKYwNQFS4XBP]
	muPDGHvJwFieQYCW62bB.append([s8Oimqou2fZD,GG9zmPqulYDyJCtWwkE8,d7on6sKDqkNY,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,zKHPsDVeYF,eWICxFNw73mJnSToUiR,RxgdTHfDar8EXt,tiIc9lDHrUd,UrmJVLMKYwNQFS4XBP])
	return
def nnGHa80rMphqe1ukFtIRvAPs6W(Hi4Upj0lBEvrTMJ7Pb5Vz2kN):
	if wvkR1es6d0SrjxKt5FZTMUWz7a: from html import unescape as _m6OfLDS2uGPZlwhIzYc
	else:
		from HTMLParser import HTMLParser as NVrncTFLxfi7BKmPp
		_m6OfLDS2uGPZlwhIzYc = NVrncTFLxfi7BKmPp().unescape
	if '&' in Hi4Upj0lBEvrTMJ7Pb5Vz2kN and ';' in Hi4Upj0lBEvrTMJ7Pb5Vz2kN:
		if vciEXHThAPto76QIR2pK: Hi4Upj0lBEvrTMJ7Pb5Vz2kN = Hi4Upj0lBEvrTMJ7Pb5Vz2kN.decode('utf8')
		Hi4Upj0lBEvrTMJ7Pb5Vz2kN = _m6OfLDS2uGPZlwhIzYc(Hi4Upj0lBEvrTMJ7Pb5Vz2kN)
		if vciEXHThAPto76QIR2pK: Hi4Upj0lBEvrTMJ7Pb5Vz2kN = Hi4Upj0lBEvrTMJ7Pb5Vz2kN.encode('utf8')
	return Hi4Upj0lBEvrTMJ7Pb5Vz2kN
def zKGXT5sJeRq(Hi4Upj0lBEvrTMJ7Pb5Vz2kN):
	if '\\u' in Hi4Upj0lBEvrTMJ7Pb5Vz2kN:
		if vciEXHThAPto76QIR2pK: Hi4Upj0lBEvrTMJ7Pb5Vz2kN = Hi4Upj0lBEvrTMJ7Pb5Vz2kN.decode('unicode_escape','ignore').encode('utf8')
		elif wvkR1es6d0SrjxKt5FZTMUWz7a: Hi4Upj0lBEvrTMJ7Pb5Vz2kN = Hi4Upj0lBEvrTMJ7Pb5Vz2kN.encode('utf8').decode('unicode_escape','ignore')
	return Hi4Upj0lBEvrTMJ7Pb5Vz2kN
def ttLMqzgZbm(ihNrUSqEjLQ1cp2Xl8,ZjhkCTt8zQ,QTFd4VHmiynh5t2Pbrk6xMvN3cg,oaRnsdu51OUNlyte2VHDQ,RxgdTHfDar8EXt,g10XlKAU3eZmoW,ddCzeZIiE9jMkqngv76S,JaANmEwRc0K9ybkhgDvxtZ2FL6,tImG3DQuxfcdiH5A6Uea4v):
	vvASl6aZp2QMbExmBoy0InY = yESdCNQlxJs0GvVpL4F(g10XlKAU3eZmoW)
	hvLaCg0l6MOpn = C8WFqwgezo7sA(vvASl6aZp2QMbExmBoy0InY,ihNrUSqEjLQ1cp2Xl8,ZjhkCTt8zQ,QTFd4VHmiynh5t2Pbrk6xMvN3cg,oaRnsdu51OUNlyte2VHDQ,RxgdTHfDar8EXt,g10XlKAU3eZmoW,ddCzeZIiE9jMkqngv76S,JaANmEwRc0K9ybkhgDvxtZ2FL6,tImG3DQuxfcdiH5A6Uea4v)
	return hvLaCg0l6MOpn
def yESdCNQlxJs0GvVpL4F(g10XlKAU3eZmoW):
	ppiS9TnFhzmRElLKyxb7A8VuHW2Cc = 5
	r6rxSgMfhdELZ = 20
	LlM7BPaVJc9 = 20
	bFXUPo9DEzjwafug46RVmrY7HCWpk = 0
	UymxT524ouLqaH = 'center'
	uFV9JYz6WbNqk0Bf23hvTyML = 0
	izW9rU37DgBx8EaPqwthYKj = 19
	wLOqdGiArgk2yBc0vhu1XWZ = 30
	eXbUjZVu5BwEOq61Mzy0irs = 8
	jW1FP9GCdK6sOxv07Ub = True
	WWPJug8SaskjXEd3C9AnhTpv = 375
	QfNePub1MgzR = 410
	FedwZutLQOkHP1GbW6qzv9KJgB78Xr = 50
	uroAURVIcW3x1DjXlighQ7Y5 = 280
	sq6zprhXYlD0NBgidVOC98APZJQvj = 28
	KR2PeBjGZbCaMyw79fTHg = 5
	JD6QaBWNInRdyKVwie = 0
	E2EbOutmGPeLJC9najDQMUc = 31
	ZGPnKCxDqc7QsJfuHbW2jRNU = [36,32,28]
	if g10XlKAU3eZmoW in ['notification','notification_twohalfs']:
		if g10XlKAU3eZmoW=='notification_twohalfs':
			pZiIARJPLhn5QVaXyKHNkf7Yo,jy6zM7QGwKv4k = 'UPPER',720
			UymxT524ouLqaH = 'right'
			jW1FP9GCdK6sOxv07Ub = True
			bFXUPo9DEzjwafug46RVmrY7HCWpk = 10
		else:
			pZiIARJPLhn5QVaXyKHNkf7Yo,jy6zM7QGwKv4k = 97+20,720
			UymxT524ouLqaH = 'left'
			jW1FP9GCdK6sOxv07Ub = False
		ZGPnKCxDqc7QsJfuHbW2jRNU = [33,33,33]
		LlM7BPaVJc9 = 20
		r6rxSgMfhdELZ = 0
		wLOqdGiArgk2yBc0vhu1XWZ = 20
		izW9rU37DgBx8EaPqwthYKj = 25+10
	elif g10XlKAU3eZmoW=='menu_item':
		ZGPnKCxDqc7QsJfuHbW2jRNU,pZiIARJPLhn5QVaXyKHNkf7Yo,jy6zM7QGwKv4k = [48,44,40],200,400
		wLOqdGiArgk2yBc0vhu1XWZ,izW9rU37DgBx8EaPqwthYKj,r6rxSgMfhdELZ = 0,0,-16
		ieR60HxTSb9Lfd1MuIsgk3o = b0jWpJLRsD4omGnBXefT38yM.open(hhZm4DjnkHfv)
		yZzdIwMOVnqtE3Hx7K = b0jWpJLRsD4omGnBXefT38yM.new('RGBA',(200,200),(255,0,0,255))
	elif g10XlKAU3eZmoW=='confirm_smallfont': ZGPnKCxDqc7QsJfuHbW2jRNU,pZiIARJPLhn5QVaXyKHNkf7Yo,jy6zM7QGwKv4k = [28,24,20],500,900
	elif g10XlKAU3eZmoW=='confirm_mediumfont': ZGPnKCxDqc7QsJfuHbW2jRNU,pZiIARJPLhn5QVaXyKHNkf7Yo,jy6zM7QGwKv4k = [32,28,24],500,900
	elif g10XlKAU3eZmoW=='confirm_bigfont': ZGPnKCxDqc7QsJfuHbW2jRNU,pZiIARJPLhn5QVaXyKHNkf7Yo,jy6zM7QGwKv4k = [36,32,28],500,900
	elif g10XlKAU3eZmoW=='textview_bigfont': pZiIARJPLhn5QVaXyKHNkf7Yo,jy6zM7QGwKv4k = 740,1270
	elif g10XlKAU3eZmoW=='textview_bigfont_long': pZiIARJPLhn5QVaXyKHNkf7Yo,jy6zM7QGwKv4k = 'UPPER',1270
	elif g10XlKAU3eZmoW=='textview_smallfont': ZGPnKCxDqc7QsJfuHbW2jRNU,pZiIARJPLhn5QVaXyKHNkf7Yo,jy6zM7QGwKv4k = [28,23,18],740,1270
	elif g10XlKAU3eZmoW=='textview_smallfont_long': ZGPnKCxDqc7QsJfuHbW2jRNU,pZiIARJPLhn5QVaXyKHNkf7Yo,jy6zM7QGwKv4k = [28,23,18],'UPPER',1270
	sdTcBvXMwYVIh = ZGPnKCxDqc7QsJfuHbW2jRNU[0]
	HO59MSFv4idYoc = ZGPnKCxDqc7QsJfuHbW2jRNU[1]
	weQHz6WgMBbr9KStnq = ZGPnKCxDqc7QsJfuHbW2jRNU[2]
	jnrCl4bhTD8OYsZt = c7kgPIzjmT.truetype(r9b5CT7SU6WkiL3dEFJfNZOo0M,size=sdTcBvXMwYVIh)
	ojU3h2CVOk4aGR6Zmcs = c7kgPIzjmT.truetype(r9b5CT7SU6WkiL3dEFJfNZOo0M,size=HO59MSFv4idYoc)
	ojTaDMJS3OwQUcgYhXsztd0VEPl = c7kgPIzjmT.truetype(r9b5CT7SU6WkiL3dEFJfNZOo0M,size=weQHz6WgMBbr9KStnq)
	VVbupl6GdexsDcX = b0jWpJLRsD4omGnBXefT38yM.new('RGBA',(100,100),(255,255,255,0))
	ACK5zyj0hpWSrlfQ2vUZebH4n = P5j9asqbcBpmurZ184noVh3I.Draw(VVbupl6GdexsDcX)
	rEoCcKPXviA5,RRwb8ZhBpN5ACKTkq0xMDLHWnJGQ = ACK5zyj0hpWSrlfQ2vUZebH4n.textsize('HHH BBB 888 000',font=ojU3h2CVOk4aGR6Zmcs)
	Akc9QWYU8yT,Ru61loWZrgsE5PLqDjcT2wKmGdySO = ACK5zyj0hpWSrlfQ2vUZebH4n.textsize('HHH BBB 888 000',font=jnrCl4bhTD8OYsZt)
	ppefZNEBv5PaAg6Kj = {'delete_harakat':False,'support_ligatures':True,'ARABIC LIGATURE ALLAH':False}
	FFfne1XIhaD6GiQVCB = MUz2LypR7GhOecTZ56CakbwdF(configuration=ppefZNEBv5PaAg6Kj)
	vvASl6aZp2QMbExmBoy0InY = {}
	iZSHtPJ4Xj3fz81AgKex0VbNaGwCv = locals()
	for VFuy0zn89rNPLdt in iZSHtPJ4Xj3fz81AgKex0VbNaGwCv: vvASl6aZp2QMbExmBoy0InY[VFuy0zn89rNPLdt] = iZSHtPJ4Xj3fz81AgKex0VbNaGwCv[VFuy0zn89rNPLdt]
	return vvASl6aZp2QMbExmBoy0InY
def C8WFqwgezo7sA(vvASl6aZp2QMbExmBoy0InY,ihNrUSqEjLQ1cp2Xl8,ZjhkCTt8zQ,QTFd4VHmiynh5t2Pbrk6xMvN3cg,oaRnsdu51OUNlyte2VHDQ,RxgdTHfDar8EXt,g10XlKAU3eZmoW,ddCzeZIiE9jMkqngv76S,JaANmEwRc0K9ybkhgDvxtZ2FL6,tImG3DQuxfcdiH5A6Uea4v):
	for VFuy0zn89rNPLdt in vvASl6aZp2QMbExmBoy0InY: globals()[VFuy0zn89rNPLdt] = vvASl6aZp2QMbExmBoy0InY[VFuy0zn89rNPLdt]
	global sq6zprhXYlD0NBgidVOC98APZJQvj,KR2PeBjGZbCaMyw79fTHg
	nZHAcj40I5EgdWvR8GeTrioNb92 = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.language.translate')
	if nZHAcj40I5EgdWvR8GeTrioNb92:
		if ihNrUSqEjLQ1cp2Xl8=='نعم  Yes': ihNrUSqEjLQ1cp2Xl8 = 'Yes'
		elif ihNrUSqEjLQ1cp2Xl8=='كلا  No': ihNrUSqEjLQ1cp2Xl8 = 'No'
		if ZjhkCTt8zQ=='نعم  Yes': ZjhkCTt8zQ = 'Yes'
		elif ZjhkCTt8zQ=='كلا  No': ZjhkCTt8zQ = 'No'
		if QTFd4VHmiynh5t2Pbrk6xMvN3cg=='نعم  Yes': QTFd4VHmiynh5t2Pbrk6xMvN3cg = 'Yes'
		elif QTFd4VHmiynh5t2Pbrk6xMvN3cg=='كلا  No': QTFd4VHmiynh5t2Pbrk6xMvN3cg = 'No'
		RbtUmf6lI3nFS8agCeNWGDcK4Z0 = xvgaJ2CtisWRSfXq7uToKmkEMIP([ihNrUSqEjLQ1cp2Xl8,ZjhkCTt8zQ,QTFd4VHmiynh5t2Pbrk6xMvN3cg,oaRnsdu51OUNlyte2VHDQ,RxgdTHfDar8EXt])
		if RbtUmf6lI3nFS8agCeNWGDcK4Z0: ihNrUSqEjLQ1cp2Xl8,ZjhkCTt8zQ,QTFd4VHmiynh5t2Pbrk6xMvN3cg,oaRnsdu51OUNlyte2VHDQ,RxgdTHfDar8EXt = RbtUmf6lI3nFS8agCeNWGDcK4Z0
	if vciEXHThAPto76QIR2pK:
		RxgdTHfDar8EXt = RxgdTHfDar8EXt.decode('utf8')
		oaRnsdu51OUNlyte2VHDQ = oaRnsdu51OUNlyte2VHDQ.decode('utf8')
		ihNrUSqEjLQ1cp2Xl8 = ihNrUSqEjLQ1cp2Xl8.decode('utf8')
		ZjhkCTt8zQ = ZjhkCTt8zQ.decode('utf8')
		QTFd4VHmiynh5t2Pbrk6xMvN3cg = QTFd4VHmiynh5t2Pbrk6xMvN3cg.decode('utf8')
	RIDZ5CO7z9EhfF6u = oaRnsdu51OUNlyte2VHDQ.count('\n')+1
	GPx5EmzeZN4pvAoTfcDVlMwR = r6rxSgMfhdELZ+RIDZ5CO7z9EhfF6u*(Ru61loWZrgsE5PLqDjcT2wKmGdySO+bFXUPo9DEzjwafug46RVmrY7HCWpk)-bFXUPo9DEzjwafug46RVmrY7HCWpk
	if RxgdTHfDar8EXt:
		NldAUeavJ6GzQb9B3D2xo7hnsfLXOR = jy6zM7QGwKv4k-wLOqdGiArgk2yBc0vhu1XWZ*2
		NjlS2OyIpAf4s9divrVT7aZ = RRwb8ZhBpN5ACKTkq0xMDLHWnJGQ+eXbUjZVu5BwEOq61Mzy0irs
		Ms8mvFCU4kHpQ2zV3j75cTxBEY = FFfne1XIhaD6GiQVCB.reshape(RxgdTHfDar8EXt)
		if jW1FP9GCdK6sOxv07Ub:
			JOoBCK58nx0PSlRqVuyLaz = uuVB2XvFKbm3yloWnODAPh(Ms8mvFCU4kHpQ2zV3j75cTxBEY,HO59MSFv4idYoc,NldAUeavJ6GzQb9B3D2xo7hnsfLXOR,NjlS2OyIpAf4s9divrVT7aZ)
			faYEvQRBw1FG0cX = OGuSMLsqmQEBCH8dNT95kgPli(JOoBCK58nx0PSlRqVuyLaz)
			dv6CrOo5qjG24FkNpfZUQ = faYEvQRBw1FG0cX.count('\n')+1
			if dv6CrOo5qjG24FkNpfZUQ<6:
				vwxQh2b4gjqfiFmkOyRPW1 = NldAUeavJ6GzQb9B3D2xo7hnsfLXOR
				JOoBCK58nx0PSlRqVuyLaz = uuVB2XvFKbm3yloWnODAPh(Ms8mvFCU4kHpQ2zV3j75cTxBEY,HO59MSFv4idYoc,vwxQh2b4gjqfiFmkOyRPW1,NjlS2OyIpAf4s9divrVT7aZ)
				faYEvQRBw1FG0cX = OGuSMLsqmQEBCH8dNT95kgPli(JOoBCK58nx0PSlRqVuyLaz)
				dv6CrOo5qjG24FkNpfZUQ = faYEvQRBw1FG0cX.count('\n')+1
			UmNGJu9xl6QPYEI7 = izW9rU37DgBx8EaPqwthYKj+dv6CrOo5qjG24FkNpfZUQ*NjlS2OyIpAf4s9divrVT7aZ-eXbUjZVu5BwEOq61Mzy0irs
		else:
			UmNGJu9xl6QPYEI7 = izW9rU37DgBx8EaPqwthYKj+RRwb8ZhBpN5ACKTkq0xMDLHWnJGQ
			faYEvQRBw1FG0cX = Ms8mvFCU4kHpQ2zV3j75cTxBEY.split('\n')[0]
			JOoBCK58nx0PSlRqVuyLaz = Ms8mvFCU4kHpQ2zV3j75cTxBEY.split('\n')[0]
	else: UmNGJu9xl6QPYEI7 = izW9rU37DgBx8EaPqwthYKj
	n5p86FWALdNfaebPYuMt4ZxUKR1 = JD6QaBWNInRdyKVwie+E2EbOutmGPeLJC9najDQMUc
	if JaANmEwRc0K9ybkhgDvxtZ2FL6:
		Sy3lNn7tqgIKaBUoCb5u0WR8 = QfNePub1MgzR-WWPJug8SaskjXEd3C9AnhTpv
		n5p86FWALdNfaebPYuMt4ZxUKR1 += Sy3lNn7tqgIKaBUoCb5u0WR8
	else: Sy3lNn7tqgIKaBUoCb5u0WR8 = 0
	if ihNrUSqEjLQ1cp2Xl8 or ZjhkCTt8zQ or QTFd4VHmiynh5t2Pbrk6xMvN3cg: n5p86FWALdNfaebPYuMt4ZxUKR1 += FedwZutLQOkHP1GbW6qzv9KJgB78Xr
	if pZiIARJPLhn5QVaXyKHNkf7Yo!='UPPER': hvLaCg0l6MOpn = pZiIARJPLhn5QVaXyKHNkf7Yo
	else: hvLaCg0l6MOpn = GPx5EmzeZN4pvAoTfcDVlMwR+UmNGJu9xl6QPYEI7+n5p86FWALdNfaebPYuMt4ZxUKR1
	d1Ea7wsiVWkqOyXBG5YMN = hvLaCg0l6MOpn-GPx5EmzeZN4pvAoTfcDVlMwR-n5p86FWALdNfaebPYuMt4ZxUKR1-izW9rU37DgBx8EaPqwthYKj
	VVbupl6GdexsDcX = b0jWpJLRsD4omGnBXefT38yM.new('RGBA',(jy6zM7QGwKv4k,hvLaCg0l6MOpn),(255,255,255,0))
	ACK5zyj0hpWSrlfQ2vUZebH4n = P5j9asqbcBpmurZ184noVh3I.Draw(VVbupl6GdexsDcX)
	if not ZjhkCTt8zQ and ihNrUSqEjLQ1cp2Xl8 and QTFd4VHmiynh5t2Pbrk6xMvN3cg:
		sq6zprhXYlD0NBgidVOC98APZJQvj += 105
		KR2PeBjGZbCaMyw79fTHg -= 110
	if oaRnsdu51OUNlyte2VHDQ:
		j3rmNdTh1wZ8aDWE4RoiFpk9bPA2e = r6rxSgMfhdELZ
		oaRnsdu51OUNlyte2VHDQ = C5KxErBjfN7HzJbdPmAciQT.get_display(FFfne1XIhaD6GiQVCB.reshape(oaRnsdu51OUNlyte2VHDQ))
		HCFix1cLXj9R6e87BqZ = oaRnsdu51OUNlyte2VHDQ.splitlines()
		for gH6oMIGUWO1sA4aYBbfChRw5yN in HCFix1cLXj9R6e87BqZ:
			if gH6oMIGUWO1sA4aYBbfChRw5yN:
				bhU1nFOXQf2wpZi,ttzMGR2Hvg1UWuk0ny = ACK5zyj0hpWSrlfQ2vUZebH4n.textsize(gH6oMIGUWO1sA4aYBbfChRw5yN,font=jnrCl4bhTD8OYsZt)
				if UymxT524ouLqaH=='center': uNQhE3sGMzaYoJgKkDpyv = ppiS9TnFhzmRElLKyxb7A8VuHW2Cc+(jy6zM7QGwKv4k-bhU1nFOXQf2wpZi)/2
				elif UymxT524ouLqaH=='right': uNQhE3sGMzaYoJgKkDpyv = ppiS9TnFhzmRElLKyxb7A8VuHW2Cc+jy6zM7QGwKv4k-bhU1nFOXQf2wpZi-LlM7BPaVJc9
				elif UymxT524ouLqaH=='left': uNQhE3sGMzaYoJgKkDpyv = ppiS9TnFhzmRElLKyxb7A8VuHW2Cc+LlM7BPaVJc9
				ACK5zyj0hpWSrlfQ2vUZebH4n.text((uNQhE3sGMzaYoJgKkDpyv,j3rmNdTh1wZ8aDWE4RoiFpk9bPA2e),gH6oMIGUWO1sA4aYBbfChRw5yN,font=jnrCl4bhTD8OYsZt,fill='yellow')
			j3rmNdTh1wZ8aDWE4RoiFpk9bPA2e += sdTcBvXMwYVIh+bFXUPo9DEzjwafug46RVmrY7HCWpk
	if ihNrUSqEjLQ1cp2Xl8 or ZjhkCTt8zQ or QTFd4VHmiynh5t2Pbrk6xMvN3cg:
		lj5fYr4AupVeCxzkRsyo6tnWHBm9bS = GPx5EmzeZN4pvAoTfcDVlMwR+d1Ea7wsiVWkqOyXBG5YMN+izW9rU37DgBx8EaPqwthYKj+Sy3lNn7tqgIKaBUoCb5u0WR8+JD6QaBWNInRdyKVwie
		if ihNrUSqEjLQ1cp2Xl8:
			ihNrUSqEjLQ1cp2Xl8 = C5KxErBjfN7HzJbdPmAciQT.get_display(FFfne1XIhaD6GiQVCB.reshape(ihNrUSqEjLQ1cp2Xl8))
			aaj8fnzJuNXm,iQDye1wqk6KGMzbJN2O = ACK5zyj0hpWSrlfQ2vUZebH4n.textsize(ihNrUSqEjLQ1cp2Xl8,font=ojTaDMJS3OwQUcgYhXsztd0VEPl)
			dNOtgKzA1U = sq6zprhXYlD0NBgidVOC98APZJQvj+0*(KR2PeBjGZbCaMyw79fTHg+uroAURVIcW3x1DjXlighQ7Y5)+(uroAURVIcW3x1DjXlighQ7Y5-aaj8fnzJuNXm)/2
			ACK5zyj0hpWSrlfQ2vUZebH4n.text((dNOtgKzA1U,lj5fYr4AupVeCxzkRsyo6tnWHBm9bS),ihNrUSqEjLQ1cp2Xl8,font=ojTaDMJS3OwQUcgYhXsztd0VEPl,fill='yellow')
		if ZjhkCTt8zQ:
			ZjhkCTt8zQ = C5KxErBjfN7HzJbdPmAciQT.get_display(FFfne1XIhaD6GiQVCB.reshape(ZjhkCTt8zQ))
			f2fWE7Ue8czOl1XqD6VjdT,NphR9YS4F7bfxVKevjAJztOyTMaI = ACK5zyj0hpWSrlfQ2vUZebH4n.textsize(ZjhkCTt8zQ,font=ojTaDMJS3OwQUcgYhXsztd0VEPl)
			diDxBTJubpnlCYzSRP3XL = sq6zprhXYlD0NBgidVOC98APZJQvj+1*(KR2PeBjGZbCaMyw79fTHg+uroAURVIcW3x1DjXlighQ7Y5)+(uroAURVIcW3x1DjXlighQ7Y5-f2fWE7Ue8czOl1XqD6VjdT)/2
			ACK5zyj0hpWSrlfQ2vUZebH4n.text((diDxBTJubpnlCYzSRP3XL,lj5fYr4AupVeCxzkRsyo6tnWHBm9bS),ZjhkCTt8zQ,font=ojTaDMJS3OwQUcgYhXsztd0VEPl,fill='yellow')
		if QTFd4VHmiynh5t2Pbrk6xMvN3cg:
			QTFd4VHmiynh5t2Pbrk6xMvN3cg = C5KxErBjfN7HzJbdPmAciQT.get_display(FFfne1XIhaD6GiQVCB.reshape(QTFd4VHmiynh5t2Pbrk6xMvN3cg))
			wQXyTGUq5agCj8e9FcYAO,Wi1vjzXZUkRa0MmLSBxNE = ACK5zyj0hpWSrlfQ2vUZebH4n.textsize(QTFd4VHmiynh5t2Pbrk6xMvN3cg,font=ojTaDMJS3OwQUcgYhXsztd0VEPl)
			b9svi3EP5gu8w = sq6zprhXYlD0NBgidVOC98APZJQvj+2*(KR2PeBjGZbCaMyw79fTHg+uroAURVIcW3x1DjXlighQ7Y5)+(uroAURVIcW3x1DjXlighQ7Y5-wQXyTGUq5agCj8e9FcYAO)/2
			ACK5zyj0hpWSrlfQ2vUZebH4n.text((b9svi3EP5gu8w,lj5fYr4AupVeCxzkRsyo6tnWHBm9bS),QTFd4VHmiynh5t2Pbrk6xMvN3cg,font=ojTaDMJS3OwQUcgYhXsztd0VEPl,fill='yellow')
	if RxgdTHfDar8EXt:
		aBMxGzgVdN4XRU3,i4iNH5bFTOodAmBcEgsLhj76D = [],[]
		JOoBCK58nx0PSlRqVuyLaz = Vx9DeK5ZOrtTi0mvSunJUbfBL3(JOoBCK58nx0PSlRqVuyLaz)
		M8M0KhuSzsXkL6Owf3G = JOoBCK58nx0PSlRqVuyLaz.split('_sss__newline_')
		for SIwp9H2r3BV in M8M0KhuSzsXkL6Owf3G:
			YjNqdaOLmhlA8wBfbGKWpR2x9U = ddCzeZIiE9jMkqngv76S
			if   '_sss__lineleft_' in SIwp9H2r3BV: YjNqdaOLmhlA8wBfbGKWpR2x9U = 'left'
			elif '_sss__lineright_' in SIwp9H2r3BV: YjNqdaOLmhlA8wBfbGKWpR2x9U = 'right'
			elif '_sss__linecenter_' in SIwp9H2r3BV: YjNqdaOLmhlA8wBfbGKWpR2x9U = 'center'
			zkLBXoH1ISvti4eaK3GUQx9gP = SIwp9H2r3BV
			kSu2otwUa1bHG = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('_sss__.*?_',SIwp9H2r3BV,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for rkjiuGtWIaH3XZEMVU8Dw in kSu2otwUa1bHG: zkLBXoH1ISvti4eaK3GUQx9gP = zkLBXoH1ISvti4eaK3GUQx9gP.replace(rkjiuGtWIaH3XZEMVU8Dw,'')
			if zkLBXoH1ISvti4eaK3GUQx9gP=='': bhU1nFOXQf2wpZi,ttzMGR2Hvg1UWuk0ny = 0,NjlS2OyIpAf4s9divrVT7aZ
			else: bhU1nFOXQf2wpZi,ttzMGR2Hvg1UWuk0ny = ACK5zyj0hpWSrlfQ2vUZebH4n.textsize(zkLBXoH1ISvti4eaK3GUQx9gP,font=ojU3h2CVOk4aGR6Zmcs)
			if   YjNqdaOLmhlA8wBfbGKWpR2x9U=='left': BGsnLNEADp15t = uFV9JYz6WbNqk0Bf23hvTyML+wLOqdGiArgk2yBc0vhu1XWZ
			elif YjNqdaOLmhlA8wBfbGKWpR2x9U=='right': BGsnLNEADp15t = uFV9JYz6WbNqk0Bf23hvTyML+wLOqdGiArgk2yBc0vhu1XWZ+NldAUeavJ6GzQb9B3D2xo7hnsfLXOR-bhU1nFOXQf2wpZi
			elif YjNqdaOLmhlA8wBfbGKWpR2x9U=='center': BGsnLNEADp15t = uFV9JYz6WbNqk0Bf23hvTyML+wLOqdGiArgk2yBc0vhu1XWZ+(NldAUeavJ6GzQb9B3D2xo7hnsfLXOR-bhU1nFOXQf2wpZi)/2
			if BGsnLNEADp15t<wLOqdGiArgk2yBc0vhu1XWZ: BGsnLNEADp15t = uFV9JYz6WbNqk0Bf23hvTyML+wLOqdGiArgk2yBc0vhu1XWZ
			aBMxGzgVdN4XRU3.append(BGsnLNEADp15t)
			i4iNH5bFTOodAmBcEgsLhj76D.append(bhU1nFOXQf2wpZi)
		BGsnLNEADp15t = aBMxGzgVdN4XRU3[0]
		ijGqYubUhp7C8yxEKraS1 = JOoBCK58nx0PSlRqVuyLaz.split('_sss_')
		Jds0opEwYC8bAn4f = (255,255,255,255)
		zEAJaWonsvwcPX = Jds0opEwYC8bAn4f
		WSnVwrQutF8ZLN0D,ODgqh5dycFAXS17wZ2Puo = 0,0
		NNVi36SBGIaUWv = False
		p6pDTMb0oOaWmN = 0
		P28tpary1K0sGOQZ7MN3Je = GPx5EmzeZN4pvAoTfcDVlMwR+izW9rU37DgBx8EaPqwthYKj/2
		if UmNGJu9xl6QPYEI7<(d1Ea7wsiVWkqOyXBG5YMN+izW9rU37DgBx8EaPqwthYKj):
			IZxvphrWFoJtDqzdjLe8HKU = (d1Ea7wsiVWkqOyXBG5YMN+izW9rU37DgBx8EaPqwthYKj-UmNGJu9xl6QPYEI7)/2
			P28tpary1K0sGOQZ7MN3Je = GPx5EmzeZN4pvAoTfcDVlMwR+izW9rU37DgBx8EaPqwthYKj+IZxvphrWFoJtDqzdjLe8HKU-RRwb8ZhBpN5ACKTkq0xMDLHWnJGQ/2
		for gH6oMIGUWO1sA4aYBbfChRw5yN in ijGqYubUhp7C8yxEKraS1:
			if not gH6oMIGUWO1sA4aYBbfChRw5yN or (gH6oMIGUWO1sA4aYBbfChRw5yN and ord(gH6oMIGUWO1sA4aYBbfChRw5yN[0])==65279): continue
			UbYPOZXr8TM = gH6oMIGUWO1sA4aYBbfChRw5yN.split('_newline_',1)
			N1byGPnFk9Mx2m7q0QKSZ8V = gH6oMIGUWO1sA4aYBbfChRw5yN.split('_newcolor',1)
			hpFo1cQwS24n = gH6oMIGUWO1sA4aYBbfChRw5yN.split('_endcolor_',1)
			CsF8IHDjAqWkSKamw2lzZ = gH6oMIGUWO1sA4aYBbfChRw5yN.split('_linertl_',1)
			G14cJQP6TptDI0rH38V = gH6oMIGUWO1sA4aYBbfChRw5yN.split('_lineleft_',1)
			uogJjmHKpa = gH6oMIGUWO1sA4aYBbfChRw5yN.split('_lineright_',1)
			Xg7ISD2uTBAQfjNxeJznVyCaYZ3 = gH6oMIGUWO1sA4aYBbfChRw5yN.split('_linecenter_',1)
			if len(UbYPOZXr8TM)>1:
				p6pDTMb0oOaWmN += 1
				gH6oMIGUWO1sA4aYBbfChRw5yN = UbYPOZXr8TM[1]
				WSnVwrQutF8ZLN0D = 0
				BGsnLNEADp15t = aBMxGzgVdN4XRU3[p6pDTMb0oOaWmN]
				ODgqh5dycFAXS17wZ2Puo += NjlS2OyIpAf4s9divrVT7aZ
				NNVi36SBGIaUWv = False
			elif len(N1byGPnFk9Mx2m7q0QKSZ8V)>1:
				gH6oMIGUWO1sA4aYBbfChRw5yN = N1byGPnFk9Mx2m7q0QKSZ8V[1]
				zEAJaWonsvwcPX = gH6oMIGUWO1sA4aYBbfChRw5yN[0:8]
				zEAJaWonsvwcPX = '#'+zEAJaWonsvwcPX[2:]
				gH6oMIGUWO1sA4aYBbfChRw5yN = gH6oMIGUWO1sA4aYBbfChRw5yN[9:]
			elif len(hpFo1cQwS24n)>1:
				gH6oMIGUWO1sA4aYBbfChRw5yN = hpFo1cQwS24n[1]
				zEAJaWonsvwcPX = Jds0opEwYC8bAn4f
			elif len(CsF8IHDjAqWkSKamw2lzZ)>1:
				gH6oMIGUWO1sA4aYBbfChRw5yN = CsF8IHDjAqWkSKamw2lzZ[1]
				NNVi36SBGIaUWv = True
				WSnVwrQutF8ZLN0D = i4iNH5bFTOodAmBcEgsLhj76D[p6pDTMb0oOaWmN]
			elif len(G14cJQP6TptDI0rH38V)>1: gH6oMIGUWO1sA4aYBbfChRw5yN = G14cJQP6TptDI0rH38V[1]
			elif len(uogJjmHKpa)>1: gH6oMIGUWO1sA4aYBbfChRw5yN = uogJjmHKpa[1]
			elif len(Xg7ISD2uTBAQfjNxeJznVyCaYZ3)>1: gH6oMIGUWO1sA4aYBbfChRw5yN = Xg7ISD2uTBAQfjNxeJznVyCaYZ3[1]
			if gH6oMIGUWO1sA4aYBbfChRw5yN:
				rMoaCgW7eZXvbikGLph = P28tpary1K0sGOQZ7MN3Je+ODgqh5dycFAXS17wZ2Puo
				gH6oMIGUWO1sA4aYBbfChRw5yN = C5KxErBjfN7HzJbdPmAciQT.get_display(gH6oMIGUWO1sA4aYBbfChRw5yN)
				bhU1nFOXQf2wpZi,ttzMGR2Hvg1UWuk0ny = ACK5zyj0hpWSrlfQ2vUZebH4n.textsize(gH6oMIGUWO1sA4aYBbfChRw5yN,font=ojU3h2CVOk4aGR6Zmcs)
				if NNVi36SBGIaUWv: WSnVwrQutF8ZLN0D -= bhU1nFOXQf2wpZi
				SW2wtc6mMVxadLze = BGsnLNEADp15t+WSnVwrQutF8ZLN0D
				ACK5zyj0hpWSrlfQ2vUZebH4n.text((SW2wtc6mMVxadLze,rMoaCgW7eZXvbikGLph),gH6oMIGUWO1sA4aYBbfChRw5yN,font=ojU3h2CVOk4aGR6Zmcs,fill=zEAJaWonsvwcPX)
				if g10XlKAU3eZmoW=='menu_item':
					ACK5zyj0hpWSrlfQ2vUZebH4n.text((SW2wtc6mMVxadLze+1,rMoaCgW7eZXvbikGLph+1),gH6oMIGUWO1sA4aYBbfChRw5yN,font=ojU3h2CVOk4aGR6Zmcs,fill=zEAJaWonsvwcPX)
				if not NNVi36SBGIaUWv: WSnVwrQutF8ZLN0D += bhU1nFOXQf2wpZi
				if rMoaCgW7eZXvbikGLph>d1Ea7wsiVWkqOyXBG5YMN+NjlS2OyIpAf4s9divrVT7aZ: break
	if g10XlKAU3eZmoW=='menu_item':
		VVbupl6GdexsDcX = VVbupl6GdexsDcX.resize((200,200))
		YWR3gOHMPeA19VcjtakQwI = ieR60HxTSb9Lfd1MuIsgk3o.copy()
		YWR3gOHMPeA19VcjtakQwI.paste(yZzdIwMOVnqtE3Hx7K,(0,0),mask=VVbupl6GdexsDcX)
	else: YWR3gOHMPeA19VcjtakQwI = VVbupl6GdexsDcX
	if vciEXHThAPto76QIR2pK: tImG3DQuxfcdiH5A6Uea4v = tImG3DQuxfcdiH5A6Uea4v.decode('utf8')
	try: YWR3gOHMPeA19VcjtakQwI.save(tImG3DQuxfcdiH5A6Uea4v)
	except:
		B3uHyLbp97oCRwt = K3hFytImeYMkJBC.path.dirname(tImG3DQuxfcdiH5A6Uea4v)
		try: K3hFytImeYMkJBC.makedirs(B3uHyLbp97oCRwt)
		except: pass
		YWR3gOHMPeA19VcjtakQwI.save(tImG3DQuxfcdiH5A6Uea4v)
	return hvLaCg0l6MOpn
def uuVB2XvFKbm3yloWnODAPh(mkhnM5PyOzdST,mUj0ElBd8LZ6Qxhb1SMk,Frmp6kghBWUwGO4CQjNRKM9db,AL6lGgQZFmjiNBH1htCvyo2pJ8w):
	Vc1Q4x5Xpr7,kkr57zPCFD,Orgij7BtpK1XfY0w = '',0,15000
	mkhnM5PyOzdST = mkhnM5PyOzdST.replace('[COLOR ','[COLOR:::')
	XXkwbWuHC142G78ISctv6fQDRYnr = c7kgPIzjmT.truetype(r9b5CT7SU6WkiL3dEFJfNZOo0M,size=mUj0ElBd8LZ6Qxhb1SMk)
	Frmp6kghBWUwGO4CQjNRKM9db -= mUj0ElBd8LZ6Qxhb1SMk*2
	VVbupl6GdexsDcX = b0jWpJLRsD4omGnBXefT38yM.new('RGBA',(Frmp6kghBWUwGO4CQjNRKM9db,99),(255,255,255,0))
	ACK5zyj0hpWSrlfQ2vUZebH4n = P5j9asqbcBpmurZ184noVh3I.Draw(VVbupl6GdexsDcX)
	for rCKyU06MFhmt in mkhnM5PyOzdST.splitlines():
		kkr57zPCFD += AL6lGgQZFmjiNBH1htCvyo2pJ8w
		sIugZBAXqHhdOfMwoVYkvxmca1lyJW,QUDRAldh6iM7pZqTG15Ig4mcVNW = 0,''
		for nly59fsP8vTpOAXDFC7 in rCKyU06MFhmt.split(' '):
			nJP3boAp9TOzQ7ySBRtdavwMX2hY = OGuSMLsqmQEBCH8dNT95kgPli(' '+nly59fsP8vTpOAXDFC7)
			RTQFsB6q8o,n7KOub2xHjYwpfRIv = ACK5zyj0hpWSrlfQ2vUZebH4n.textsize(nJP3boAp9TOzQ7ySBRtdavwMX2hY,font=XXkwbWuHC142G78ISctv6fQDRYnr)
			if sIugZBAXqHhdOfMwoVYkvxmca1lyJW+RTQFsB6q8o<Frmp6kghBWUwGO4CQjNRKM9db:
				if not QUDRAldh6iM7pZqTG15Ig4mcVNW: QUDRAldh6iM7pZqTG15Ig4mcVNW += nly59fsP8vTpOAXDFC7
				else: QUDRAldh6iM7pZqTG15Ig4mcVNW += ' '+nly59fsP8vTpOAXDFC7
				sIugZBAXqHhdOfMwoVYkvxmca1lyJW += RTQFsB6q8o
			else:
				if RTQFsB6q8o<Frmp6kghBWUwGO4CQjNRKM9db:
					QUDRAldh6iM7pZqTG15Ig4mcVNW += '\n '+nly59fsP8vTpOAXDFC7
					kkr57zPCFD += AL6lGgQZFmjiNBH1htCvyo2pJ8w
					sIugZBAXqHhdOfMwoVYkvxmca1lyJW = RTQFsB6q8o
				else:
					while RTQFsB6q8o>Frmp6kghBWUwGO4CQjNRKM9db:
						for JF9iBfWwDE1GNjeS4HtOsgk7 in range(1,len(' '+nly59fsP8vTpOAXDFC7),1):
							Pgfj5AS1eZqD6rU0kvo89cRQ3a = ' '+nly59fsP8vTpOAXDFC7[:JF9iBfWwDE1GNjeS4HtOsgk7]
							ffreQy2KsH5i = nly59fsP8vTpOAXDFC7[JF9iBfWwDE1GNjeS4HtOsgk7:]
							Ago806DyhBed9cF71YnLH2KfWb5SER = OGuSMLsqmQEBCH8dNT95kgPli(Pgfj5AS1eZqD6rU0kvo89cRQ3a)
							Byl3zhXrwdR78t2MHA,jmBxnOFV2RbDhz3 = ACK5zyj0hpWSrlfQ2vUZebH4n.textsize(Ago806DyhBed9cF71YnLH2KfWb5SER,font=XXkwbWuHC142G78ISctv6fQDRYnr)
							if sIugZBAXqHhdOfMwoVYkvxmca1lyJW+Byl3zhXrwdR78t2MHA>Frmp6kghBWUwGO4CQjNRKM9db:
								E9M6bnjBWgzhmukaYLARyrV = RTQFsB6q8o-Byl3zhXrwdR78t2MHA
								QUDRAldh6iM7pZqTG15Ig4mcVNW += Pgfj5AS1eZqD6rU0kvo89cRQ3a+'\n'
								kkr57zPCFD += AL6lGgQZFmjiNBH1htCvyo2pJ8w
								RTQFsB6q8o = E9M6bnjBWgzhmukaYLARyrV
								if E9M6bnjBWgzhmukaYLARyrV>Frmp6kghBWUwGO4CQjNRKM9db:
									sIugZBAXqHhdOfMwoVYkvxmca1lyJW = 0
									nly59fsP8vTpOAXDFC7 = ffreQy2KsH5i
								else:
									sIugZBAXqHhdOfMwoVYkvxmca1lyJW = E9M6bnjBWgzhmukaYLARyrV
									QUDRAldh6iM7pZqTG15Ig4mcVNW += ffreQy2KsH5i
								break
				if kkr57zPCFD>Orgij7BtpK1XfY0w: break
		Vc1Q4x5Xpr7 += '\n'+QUDRAldh6iM7pZqTG15Ig4mcVNW
		if kkr57zPCFD>Orgij7BtpK1XfY0w: break
	Vc1Q4x5Xpr7 = Vc1Q4x5Xpr7[1:]
	Vc1Q4x5Xpr7 = Vc1Q4x5Xpr7.replace('[COLOR:::','[COLOR ')
	return Vc1Q4x5Xpr7
def OGuSMLsqmQEBCH8dNT95kgPli(nly59fsP8vTpOAXDFC7):
	if '[' in nly59fsP8vTpOAXDFC7 and ']' in nly59fsP8vTpOAXDFC7:
		kSu2otwUa1bHG = ['[/COLOR]','[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		Vf3W698BopArh4zqEHQyRScKg5 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('\[COLOR .*?\]',nly59fsP8vTpOAXDFC7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		CMLd5SlpifgaBRN3VX0KZQzvt4u8G = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('\[COLOR:::.*?\]',nly59fsP8vTpOAXDFC7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		oYlfRPWv3XLdp = kSu2otwUa1bHG+Vf3W698BopArh4zqEHQyRScKg5+CMLd5SlpifgaBRN3VX0KZQzvt4u8G
		for rkjiuGtWIaH3XZEMVU8Dw in oYlfRPWv3XLdp: nly59fsP8vTpOAXDFC7 = nly59fsP8vTpOAXDFC7.replace(rkjiuGtWIaH3XZEMVU8Dw,'')
	return nly59fsP8vTpOAXDFC7
def Vx9DeK5ZOrtTi0mvSunJUbfBL3(RxgdTHfDar8EXt):
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('\n','_sss__newline_')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('[RTL]','_sss__linertl_')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('[LEFT]','_sss__lineleft_')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('[RIGHT]','_sss__lineright_')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('[CENTER]','_sss__linecenter_')
	RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('[/COLOR]','_sss__endcolor_')
	mmfjZ4XM3K = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('\[COLOR (.*?)\]',RxgdTHfDar8EXt,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for TZU7fSucxlqM1ND5KjPIEa9htnQR6 in mmfjZ4XM3K: RxgdTHfDar8EXt = RxgdTHfDar8EXt.replace('[COLOR '+TZU7fSucxlqM1ND5KjPIEa9htnQR6+']','_sss__newcolor'+TZU7fSucxlqM1ND5KjPIEa9htnQR6+'_')
	return RxgdTHfDar8EXt
def sTYDZCo483UAX5IvLGag2ezmR(GG9zmPqulYDyJCtWwkE8=''):
	if not GG9zmPqulYDyJCtWwkE8: GG9zmPqulYDyJCtWwkE8 = oos8ymFi9CN2z1jXcR.getInfoLabel('ListItem.Label')
	GG9zmPqulYDyJCtWwkE8 = GG9zmPqulYDyJCtWwkE8.replace('[/COLOR]','')
	GG9zmPqulYDyJCtWwkE8 = GG9zmPqulYDyJCtWwkE8.replace('    ',' ').replace('   ',' ').replace('  ',' ').strip(' ')
	GG9zmPqulYDyJCtWwkE8 = GG9zmPqulYDyJCtWwkE8.replace('[COLOR FFFFFF00]','').replace('[COLOR FFC89008]','')
	SO6hl4pdXDeAmnGjLHt91fqg2W = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('\d\d:\d\d ',GG9zmPqulYDyJCtWwkE8,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if SO6hl4pdXDeAmnGjLHt91fqg2W: GG9zmPqulYDyJCtWwkE8 = GG9zmPqulYDyJCtWwkE8.split(SO6hl4pdXDeAmnGjLHt91fqg2W[0],1)[1]
	if not GG9zmPqulYDyJCtWwkE8: GG9zmPqulYDyJCtWwkE8 = 'Main Menu'
	return GG9zmPqulYDyJCtWwkE8
def dlVCoGwxEZt376mrbaKJ(eqfixnjLl5h):
	M9zqnWDRCi7NA1shBSIy = ''.join(JF9iBfWwDE1GNjeS4HtOsgk7 for JF9iBfWwDE1GNjeS4HtOsgk7 in eqfixnjLl5h if JF9iBfWwDE1GNjeS4HtOsgk7 not in '\/":*?<>|'+mtrqOcwh5Ux4aD7S9JQfE)
	return M9zqnWDRCi7NA1shBSIy
def K9hUtLagkSbDiwM1(eWICxFNw73mJnSToUiR):
	mmaHZ8luVhQDj9w = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("adilbo_HTML_encoder(.*?)/g.....(.*?)\)",eWICxFNw73mJnSToUiR,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.S)
	if mmaHZ8luVhQDj9w:
		fPtiMJT16RoHk0mq,yyMB0qRWSjaVhs6kCFHOZf9NT4ne = mmaHZ8luVhQDj9w[0]
		fPtiMJT16RoHk0mq = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("=[\r\n\s\t]+'(.*?)';", fPtiMJT16RoHk0mq, E1E4YjPysoQMVdlu39mSTcWKFkpa7v.S)[0]
		if fPtiMJT16RoHk0mq and yyMB0qRWSjaVhs6kCFHOZf9NT4ne:
			svB6tqzaxMHQehrP1UwjZcKR = fPtiMJT16RoHk0mq.replace("'",'').replace("+",'').replace("\n",'').replace("\r",'')
			kkqEyNwC1hP7GpoF9lWnfrZebHt = svB6tqzaxMHQehrP1UwjZcKR.split('.')
			eWICxFNw73mJnSToUiR = ''
			for ZdRKPiuqMs2wFg0AtHQkI4Oh in kkqEyNwC1hP7GpoF9lWnfrZebHt:
				DDIaOLxEyZVRG0NJMcuKkpW9Ftdb5 = SSNcdhMguvEw0RY.b64decode(ZdRKPiuqMs2wFg0AtHQkI4Oh+'==').decode('utf8')
				hiSQXfu843d2rIPqRcVM = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('\d+', DDIaOLxEyZVRG0NJMcuKkpW9Ftdb5, E1E4YjPysoQMVdlu39mSTcWKFkpa7v.S)
				if hiSQXfu843d2rIPqRcVM:
					Ao1bJPlqI8xFgOrUH6 = int(hiSQXfu843d2rIPqRcVM[0])
					Ao1bJPlqI8xFgOrUH6 += int(yyMB0qRWSjaVhs6kCFHOZf9NT4ne)
					eWICxFNw73mJnSToUiR = eWICxFNw73mJnSToUiR + chr(Ao1bJPlqI8xFgOrUH6)
			if wvkR1es6d0SrjxKt5FZTMUWz7a: eWICxFNw73mJnSToUiR = eWICxFNw73mJnSToUiR.encode('iso-8859-1').decode('utf8')
	return eWICxFNw73mJnSToUiR
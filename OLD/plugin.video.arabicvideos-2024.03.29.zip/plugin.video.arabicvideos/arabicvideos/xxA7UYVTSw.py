# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'YAQOT'
Yc0eBRLpbCkm4gK7OqyzuHwU = '_YQT_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
ZLKHfqMEUdRupD = ['الصفحة الرئيسية','Sign in','تسجيل','تسجيل الدخول','عرض المزيد']
def HgQCVwFx2Br(mode,url,text):
	if   mode==660: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==661: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url,text)
	elif mode==662: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==663: s4Bng5iAZQSTtpDw9 = ZZAqcFboiaevmz0SHYgW5RG(url,text)
	elif mode==664: s4Bng5iAZQSTtpDw9 = AJDL0Mp13fQkRH5c(url)
	elif mode==669: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',tle5V6jgvRfE,'','','','','YAQOT-MENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',669,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'المضاف حديثا',tle5V6jgvRfE,661,'','','new_episodes')
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('/category.php">(.*?)"navslide-divider"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("'dropdown-menu'(.*?)</ul>",M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for f9AzGuXj0qgcNTy1 in TIkiozSLCv6werb97mHQ0q4y3: ziJLDVT8NM2QcgIpmE9A = ziJLDVT8NM2QcgIpmE9A.replace(f9AzGuXj0qgcNTy1,'')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?>(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		title = title.replace('<b>','').replace('</b>','').replace('<b class="caret">','').replace('<b>','').strip(' ')
		if title in ZLKHfqMEUdRupD: continue
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,664)
	return
def AJDL0Mp13fQkRH5c(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','YAQOT-SUBMENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	rrNex9MVQDgqIW4kFoSyslw = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<span class="caret"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if rrNex9MVQDgqIW4kFoSyslw:
		ziJLDVT8NM2QcgIpmE9A = rrNex9MVQDgqIW4kFoSyslw[0]
		ziJLDVT8NM2QcgIpmE9A = ziJLDVT8NM2QcgIpmE9A.replace('"presentation"','</ul>')
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if not TIkiozSLCv6werb97mHQ0q4y3: TIkiozSLCv6werb97mHQ0q4y3 = [('',ziJLDVT8NM2QcgIpmE9A)]
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] فرز أو فلتر أو ترتيب [/COLOR]','',9999)
		for Pym8Gxuq1VJE3Yrk,ziJLDVT8NM2QcgIpmE9A in TIkiozSLCv6werb97mHQ0q4y3:
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?>(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if Pym8Gxuq1VJE3Yrk: Pym8Gxuq1VJE3Yrk = Pym8Gxuq1VJE3Yrk+': '
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
				title = Pym8Gxuq1VJE3Yrk+title
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,661)
	rNQC9lGIxW3d0oB6AjUfD5LbRF = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"pm-category-subcats"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if rNQC9lGIxW3d0oB6AjUfD5LbRF:
		ziJLDVT8NM2QcgIpmE9A = rNQC9lGIxW3d0oB6AjUfD5LbRF[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)">(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if len(items)<30:
			tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,661)
	if not rrNex9MVQDgqIW4kFoSyslw and not rNQC9lGIxW3d0oB6AjUfD5LbRF: uyt3pAHZk4(url)
	return
def uyt3pAHZk4(url,VWi2dTb46v3eOryuspKBF9L=''):
	if VWi2dTb46v3eOryuspKBF9L=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'POST',url,data,headers,'','','YAQOT-TITLES-1st')
	else:
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','YAQOT-TITLES-2nd')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	ziJLDVT8NM2QcgIpmE9A,items = '',[]
	dkgwyUKEpTtPeMxs68aib = SLMTm6RQ34ic7v5s9rBG(url,'url')
	if VWi2dTb46v3eOryuspKBF9L=='ajax-search':
		ziJLDVT8NM2QcgIpmE9A = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
		HKE5ebjfkuy = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)">(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in HKE5ebjfkuy: items.append(('',ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title))
	elif VWi2dTb46v3eOryuspKBF9L=='featured':
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"pm-video-watch-featured"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3: ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	elif VWi2dTb46v3eOryuspKBF9L=='new_episodes':
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"row pm-ul-browse-videos(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3: ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	elif VWi2dTb46v3eOryuspKBF9L=='new_movies':
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"row pm-ul-browse-videos(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if len(TIkiozSLCv6werb97mHQ0q4y3)>1: ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[1]
	elif VWi2dTb46v3eOryuspKBF9L=='featured_series':
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3: ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		HKE5ebjfkuy = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)">(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in HKE5ebjfkuy: items.append(('',ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title))
	else:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(data-echo=".*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3: ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	if ziJLDVT8NM2QcgIpmE9A and not items: items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not items: return
	jjR8ftoEXpPxVF6JerbHZuzv7ic = []
	G1ezKuLr3SlXd9OVkMNQs6FWvf8Aip = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for Q2qmuDRrC9ikcaJK7gtUHXNW,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		title = title.replace('اون لاين ','').replace('اونلاين ','').replace('مشاهدة ','')
		EQw62xjXSJmzrRt = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(.*?) (الحلقة|حلقة).\d+',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title for hht0cpXxWw2OzFS1jnUGebkJLBd85 in G1ezKuLr3SlXd9OVkMNQs6FWvf8Aip):
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,662,Q2qmuDRrC9ikcaJK7gtUHXNW)
		elif VWi2dTb46v3eOryuspKBF9L=='new_episodes':
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,662,Q2qmuDRrC9ikcaJK7gtUHXNW)
		elif EQw62xjXSJmzrRt:
			title = '_MOD_' + EQw62xjXSJmzrRt[0][0]
			if title not in jjR8ftoEXpPxVF6JerbHZuzv7ic:
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,663,Q2qmuDRrC9ikcaJK7gtUHXNW)
				jjR8ftoEXpPxVF6JerbHZuzv7ic.append(title)
		else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,663,Q2qmuDRrC9ikcaJK7gtUHXNW)
	if 1:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"pagination(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3:
			ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?>(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
				if ZCimQhV5lovgspAYzHq1Ef27u8ja4R=='#': continue
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = dkgwyUKEpTtPeMxs68aib+'/'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R.strip('/')
				title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,661)
	return
def ZZAqcFboiaevmz0SHYgW5RG(url,aS2RYLwdgkBue5t7HPs9VMf):
	dkgwyUKEpTtPeMxs68aib = SLMTm6RQ34ic7v5s9rBG(url,'url')
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','SHOFHA-EPISODES-2nd')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	rrNex9MVQDgqIW4kFoSyslw = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	OHMhVx5cw76slynUDdF24jgbkNG = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"series-header".*?src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if OHMhVx5cw76slynUDdF24jgbkNG: Q2qmuDRrC9ikcaJK7gtUHXNW = OHMhVx5cw76slynUDdF24jgbkNG[0]
	else: Q2qmuDRrC9ikcaJK7gtUHXNW = ''
	items = []
	jl1QvRLFeBXH5qn0wxZc = False
	if rrNex9MVQDgqIW4kFoSyslw and not aS2RYLwdgkBue5t7HPs9VMf:
		ziJLDVT8NM2QcgIpmE9A = rrNex9MVQDgqIW4kFoSyslw[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-serie="(.*?)".*?>(.*?)</li>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for aS2RYLwdgkBue5t7HPs9VMf,title in items:
			aS2RYLwdgkBue5t7HPs9VMf = aS2RYLwdgkBue5t7HPs9VMf.strip('#')
			if len(items)>1: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,663,Q2qmuDRrC9ikcaJK7gtUHXNW,'',aS2RYLwdgkBue5t7HPs9VMf)
			else: jl1QvRLFeBXH5qn0wxZc = True
	else: jl1QvRLFeBXH5qn0wxZc = True
	rNQC9lGIxW3d0oB6AjUfD5LbRF = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"SeasonsEpisodesMain.*?data-serie="'+aS2RYLwdgkBue5t7HPs9VMf+'"(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if rNQC9lGIxW3d0oB6AjUfD5LbRF and jl1QvRLFeBXH5qn0wxZc:
		ziJLDVT8NM2QcgIpmE9A = rNQC9lGIxW3d0oB6AjUfD5LbRF[0]
		HKE5ebjfkuy = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?<em>(.*?)</span>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		items = []
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in HKE5ebjfkuy: items.append((ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,Q2qmuDRrC9ikcaJK7gtUHXNW))
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,Q2qmuDRrC9ikcaJK7gtUHXNW in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = dkgwyUKEpTtPeMxs68aib+'/'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R.strip('./')
			title = title.replace('</em><span>',' ')
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,662,Q2qmuDRrC9ikcaJK7gtUHXNW)
	return
def dlropqS0vO9K7W4z(url):
	jVMHRouKgQFAESmd7B8ObTYy,JHO207wRUyXeK,zcBjFq4VQlp20ZekGO = [],[],[]
	M08MPGgsh4n5rKe = url.replace('/video.php','/play.php')
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',M08MPGgsh4n5rKe,'','','','','YAQOT-PLAY-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('id="Playerholder"(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<iframe src="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]
			JHO207wRUyXeK.append('?named=__embed')
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('id="player"(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		cc0O1M4e5jtfoq = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('''data-embed=["'](.*?)["'].*?</span>(.*?)</button>''',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in cc0O1M4e5jtfoq:
			if ZCimQhV5lovgspAYzHq1Ef27u8ja4R not in jVMHRouKgQFAESmd7B8ObTYy:
				JHO207wRUyXeK.append('?named='+title+'__watch')
				jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	Jvz4r1LbjumknXHpeRxDVP5W2 = zip(jVMHRouKgQFAESmd7B8ObTYy,JHO207wRUyXeK)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,name in Jvz4r1LbjumknXHpeRxDVP5W2: zcBjFq4VQlp20ZekGO.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R+name)
	import JYR902sfml
	JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt(zcBjFq4VQlp20ZekGO,r1NChsk39OMvT82YemDQnl5,'video',url)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if search=='': search = UIf35nZEj1wylmq()
	if search=='': return
	search = search.replace(' ','+')
	url = tle5V6jgvRfE+'/search.php?keywords='+search
	uyt3pAHZk4(url,'search')
	return
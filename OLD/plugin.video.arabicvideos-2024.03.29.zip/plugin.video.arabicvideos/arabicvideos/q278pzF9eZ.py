# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'TVFUN'
Yc0eBRLpbCkm4gK7OqyzuHwU = '_TVF_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
ZLKHfqMEUdRupD = ['بث مباشر']
def HgQCVwFx2Br(mode,url,text):
	if   mode==460: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==461: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url,text)
	elif mode==462: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==463: s4Bng5iAZQSTtpDw9 = btd6ag2XYUkHixqy5J7o9RfLu1MScm(url)
	elif mode==469: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',tle5V6jgvRfE,'','','','','TVFUN-MENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',469,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"menu-btn"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?<span>(.*?)</span>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			if title=='الرئيسية': title = 'جديد حلقات تيفي فان'
			if title in ZLKHfqMEUdRupD: continue
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,461)
	return
def uyt3pAHZk4(url,S7Ra6OGtw1gBkDhrPsozc5Ku=''):
	items = []
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','TVFUN-TITLES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="head-title"(.*?)id="footer"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		jjR8ftoEXpPxVF6JerbHZuzv7ic = []
		G1ezKuLr3SlXd9OVkMNQs6FWvf8Aip = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title in items:
			if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = BUTSkzgFC7(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			EQw62xjXSJmzrRt = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(.*?) الحلقة \d+',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title for hht0cpXxWw2OzFS1jnUGebkJLBd85 in G1ezKuLr3SlXd9OVkMNQs6FWvf8Aip):
				tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,462,Q2qmuDRrC9ikcaJK7gtUHXNW)
			elif EQw62xjXSJmzrRt and 'الحلقة' in title:
				title = '_MOD_' + EQw62xjXSJmzrRt[0]
				if title not in jjR8ftoEXpPxVF6JerbHZuzv7ic:
					tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,463,Q2qmuDRrC9ikcaJK7gtUHXNW)
					jjR8ftoEXpPxVF6JerbHZuzv7ic.append(title)
			else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,463,Q2qmuDRrC9ikcaJK7gtUHXNW)
	if S7Ra6OGtw1gBkDhrPsozc5Ku!='latest':
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"pagination"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3:
			ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<a href="(.*?)".*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.strip(' ')
				if ZCimQhV5lovgspAYzHq1Ef27u8ja4R=="": continue
				if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
				if title!='': tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,461)
	return
def btd6ag2XYUkHixqy5J7o9RfLu1MScm(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','TVFUN-EPISODES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="head-title"(.*?)id="footer"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title in items:
			if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,462,Q2qmuDRrC9ikcaJK7gtUHXNW)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"pagination"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.strip(' ')
			if ZCimQhV5lovgspAYzHq1Ef27u8ja4R=="": continue
			if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			if title!='': tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,463)
	return
def dlropqS0vO9K7W4z(url):
	jVMHRouKgQFAESmd7B8ObTYy = []
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','TVFUN-PLAY-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	PLBauUiVtdnlFh5r3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"embedUrl": "(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if PLBauUiVtdnlFh5r3:
		PLBauUiVtdnlFh5r3 = PLBauUiVtdnlFh5r3[0]
		if 'http' not in PLBauUiVtdnlFh5r3:
			if '//' in PLBauUiVtdnlFh5r3: PLBauUiVtdnlFh5r3 = 'http:'+PLBauUiVtdnlFh5r3
			else: PLBauUiVtdnlFh5r3 = tle5V6jgvRfE+PLBauUiVtdnlFh5r3
		PLBauUiVtdnlFh5r3 = PLBauUiVtdnlFh5r3+'?named=__embed'
		jVMHRouKgQFAESmd7B8ObTYy.append(PLBauUiVtdnlFh5r3)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('VideoServers"(.*?)"Play"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		cc0O1M4e5jtfoq = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('''setVideo\('(.*?)'\).*?">(.*?)<''',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for BnGromdt41zgSwhaE3eNFH5ckq79,name in cc0O1M4e5jtfoq:
			BnGromdt41zgSwhaE3eNFH5ckq79 = BnGromdt41zgSwhaE3eNFH5ckq79[2:]
			if vciEXHThAPto76QIR2pK: BnGromdt41zgSwhaE3eNFH5ckq79 = BnGromdt41zgSwhaE3eNFH5ckq79.decode('utf8')
			BnGromdt41zgSwhaE3eNFH5ckq79 = SSNcdhMguvEw0RY.b64decode(BnGromdt41zgSwhaE3eNFH5ckq79)
			if wvkR1es6d0SrjxKt5FZTMUWz7a: BnGromdt41zgSwhaE3eNFH5ckq79 = BnGromdt41zgSwhaE3eNFH5ckq79.decode('utf8')
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('src="(.*?)"',BnGromdt41zgSwhaE3eNFH5ckq79,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]
			if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
				if '//' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = 'http:'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
				else: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+name+'__watch'
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	import JYR902sfml
	JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt(jVMHRouKgQFAESmd7B8ObTYy,r1NChsk39OMvT82YemDQnl5,'video',url)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if not search:
		search = UIf35nZEj1wylmq()
		if not search: return
	if ' ' in search:
		if showDialogs: tehb3k5a2PufGOdBIUw8j('','','TVFUN موقع تيفي فان','للأسف البحث في هذا الموقع لا يعمل عند طلب أكثر من كلمة واحدة ... يرجى البحث عن كلمة واحدة فقط')
		return
	url = tle5V6jgvRfE+'/q/'+search+'/'
	uyt3pAHZk4(url)
	return
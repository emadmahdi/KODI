# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'BOKRA'
Yc0eBRLpbCkm4gK7OqyzuHwU = '_BKR_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
headers = {'User-Agent':''}
ZLKHfqMEUdRupD = ['افلام للكبار','بكرا TV']
def HgQCVwFx2Br(mode,url,text):
	if   mode==370: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==371: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url,text)
	elif mode==372: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==374: s4Bng5iAZQSTtpDw9 = vmg8jIaZp0n5ESlz(url)
	elif mode==375: s4Bng5iAZQSTtpDw9 = zz2Qmc9ujVOFLskZEKfx0J8yBNtPY(url)
	elif mode==376: s4Bng5iAZQSTtpDw9 = SUTJl0dEgQmB1M7xZc(0,url)
	elif mode==377: s4Bng5iAZQSTtpDw9 = SUTJl0dEgQmB1M7xZc(1,url)
	elif mode==379: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',tle5V6jgvRfE,'','','','','BOKRA-MENU-1st')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',379,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('right-side(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			if not any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title for hht0cpXxWw2OzFS1jnUGebkJLBd85 in ZLKHfqMEUdRupD):
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,371)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'المميزة',tle5V6jgvRfE,375)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'الأحدث',tle5V6jgvRfE,376)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'قائمة الممثلين',tle5V6jgvRfE,374)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="container"(.*?)top-menu',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items[7:]:
			title = title.strip(' ')
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			if not any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title for hht0cpXxWw2OzFS1jnUGebkJLBd85 in ZLKHfqMEUdRupD):
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,371)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items[0:7]:
			title = title.strip(' ')
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			if not any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title for hht0cpXxWw2OzFS1jnUGebkJLBd85 in ZLKHfqMEUdRupD):
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,371)
	return
def vmg8jIaZp0n5ESlz(website=''):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',tle5V6jgvRfE,'','','','','BOKRA-ACTORSMENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="row cat Tags"(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)" title="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			if 'http' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: continue
			else: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			if not any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title for hht0cpXxWw2OzFS1jnUGebkJLBd85 in ZLKHfqMEUdRupD):
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,371)
	return
def zz2Qmc9ujVOFLskZEKfx0J8yBNtPY(website=''):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',tle5V6jgvRfE,'','','','','BOKRA-FEATURED-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"MainContent"(.*?)main-title2',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			if not any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title for hht0cpXxWw2OzFS1jnUGebkJLBd85 in ZLKHfqMEUdRupD):
				Q2qmuDRrC9ikcaJK7gtUHXNW = Q2qmuDRrC9ikcaJK7gtUHXNW.replace('://',':///').replace('//','/').replace(' ','%20')
				tBq8fTGUWJY9zvbgXD0EAloPO('video',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,372,Q2qmuDRrC9ikcaJK7gtUHXNW)
	return
def SUTJl0dEgQmB1M7xZc(id,website=''):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',tle5V6jgvRfE,'','','','','BOKRA-WATCHINGNOW-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('main-title2(.*?)class="row',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[id]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			if not any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title for hht0cpXxWw2OzFS1jnUGebkJLBd85 in ZLKHfqMEUdRupD):
				Q2qmuDRrC9ikcaJK7gtUHXNW = Q2qmuDRrC9ikcaJK7gtUHXNW.replace('://',':///').replace('//','/').replace(' ','%20')
				tBq8fTGUWJY9zvbgXD0EAloPO('video',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,372,Q2qmuDRrC9ikcaJK7gtUHXNW)
	return
def uyt3pAHZk4(url,EDOvRaS4gn2U7ZJ63oI5Mu=''):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','BOKRA-TITLES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	if 'vidpage_' in url:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(/Album-.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]
			uyt3pAHZk4(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			return
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class=" subcats"(.*?)class="col-md-3',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if EDOvRaS4gn2U7ZJ63oI5Mu=='' and TIkiozSLCv6werb97mHQ0q4y3 and TIkiozSLCv6werb97mHQ0q4y3[0].count('href')>1:
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع',url,371,'','','titles')
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)" title="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			title = title.strip(' ')
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,371)
	else:
		jjR8ftoEXpPxVF6JerbHZuzv7ic = []
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="col-md-3(.*?)col-xs-12',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if not TIkiozSLCv6werb97mHQ0q4y3: TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="col-sm-8"(.*?)col-xs-12',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3:
			ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title in items:
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
				title = title.strip(' ')
				Q2qmuDRrC9ikcaJK7gtUHXNW = Q2qmuDRrC9ikcaJK7gtUHXNW.replace('://',':///').replace('//','/').replace(' ','%20')
				if '/al_' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
					tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,371,Q2qmuDRrC9ikcaJK7gtUHXNW)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					EQw62xjXSJmzrRt = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(.*?) - +الحلقة +\d+',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
					if EQw62xjXSJmzrRt: title = '_MOD_مسلسل '+EQw62xjXSJmzrRt[0]
					if title not in jjR8ftoEXpPxVF6JerbHZuzv7ic:
						jjR8ftoEXpPxVF6JerbHZuzv7ic.append(title)
						tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,371,Q2qmuDRrC9ikcaJK7gtUHXNW)
				else: tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,372,Q2qmuDRrC9ikcaJK7gtUHXNW)
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="pagination(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3:
			ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="".*?href="(.*?)">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
				title = 'صفحة '+nnGHa80rMphqe1ukFtIRvAPs6W(title)
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,371,'','','titles')
	return
def dlropqS0vO9K7W4z(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',url,'','','','','BOKRA-PLAY-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	VnK1wPrcHoN8ex2Bl0pLS = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('label-success mrg-btm-5 ">(.*?)<',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if VnK1wPrcHoN8ex2Bl0pLS and Y1Yz6bZMLDaGjpxK3fSXm7TurCnHwo(r1NChsk39OMvT82YemDQnl5,url,VnK1wPrcHoN8ex2Bl0pLS): return
	TW6JIBgC971tjOE = ''
	M08MPGgsh4n5rKe = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('var url = "(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if M08MPGgsh4n5rKe: M08MPGgsh4n5rKe = M08MPGgsh4n5rKe[0]
	else: M08MPGgsh4n5rKe = url.replace('/vidpage_','/Play/')
	if 'http' not in M08MPGgsh4n5rKe: M08MPGgsh4n5rKe = tle5V6jgvRfE+M08MPGgsh4n5rKe
	M08MPGgsh4n5rKe = M08MPGgsh4n5rKe.strip('-')
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',M08MPGgsh4n5rKe,'','','','','BOKRA-PLAY-2nd')
	flARjI3NM9CQnWY1xk7 = aQniqUlZk8.content
	TW6JIBgC971tjOE = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('src="(.*?)"',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TW6JIBgC971tjOE:
		TW6JIBgC971tjOE = TW6JIBgC971tjOE[-1]
		if 'http' not in TW6JIBgC971tjOE: TW6JIBgC971tjOE = 'http:'+TW6JIBgC971tjOE
		if '/PLAY/' not in M08MPGgsh4n5rKe:
			if 'embed.min.js' in TW6JIBgC971tjOE:
				gsikxnrNI2Z8O3E = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
				if gsikxnrNI2Z8O3E:
					PxEdTN8OK2XgmWFV9Yy5Mq, ooctO57lEjdrPsXYU6TGfykN = gsikxnrNI2Z8O3E[0]
					TW6JIBgC971tjOE = SLMTm6RQ34ic7v5s9rBG(TW6JIBgC971tjOE,'url')+'/v2/'+PxEdTN8OK2XgmWFV9Yy5Mq+'/config/'+ooctO57lEjdrPsXYU6TGfykN+'.json'
		import JYR902sfml
		JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt([TW6JIBgC971tjOE],r1NChsk39OMvT82YemDQnl5,'video',url)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if search=='': search = UIf35nZEj1wylmq()
	if search=='': return
	search = search.replace(' ','+')
	url = tle5V6jgvRfE+'/Search/'+search
	uyt3pAHZk4(url)
	return
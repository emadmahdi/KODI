﻿# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'ALMAAREF'
headers = {'User-Agent':''}
Yc0eBRLpbCkm4gK7OqyzuHwU = '_MRF_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
ZLKHfqMEUdRupD = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def HgQCVwFx2Br(mode,url,text,tsMKaFVh1ZN2BIXEcvTejxR5DP):
	if   mode==40: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==41: s4Bng5iAZQSTtpDw9 = EvpYWVrnUQA()
	elif mode==42: s4Bng5iAZQSTtpDw9 = SSbwmeph1XrWo(text,tsMKaFVh1ZN2BIXEcvTejxR5DP)
	elif mode==43: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==44: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(text,tsMKaFVh1ZN2BIXEcvTejxR5DP)
	elif mode==49: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	tBq8fTGUWJY9zvbgXD0EAloPO('live',Yc0eBRLpbCkm4gK7OqyzuHwU+'البث الحي لقناة المعارف','',41)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',49)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	SSbwmeph1XrWo('','1')
	return
def kZQthTfDOs(dNlVai6Obj1e,KLFBY9fHoxA5iR7):
	search,sort,Xt1ErNwZWQBHvC5mhKo,cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo,HDhlo3BZ7kdPWXbRjfATQOFce12qx = '',[],[],[],[]
	aQ0kNq9gnYBKJ5yV6oRhXZ7ImfwreT,jlZ1FHdqup2LAVgi3SaoxIhnfERW4 = NHyOSR4BdqaXfCpK0EU8vroiDJ2T(dNlVai6Obj1e)
	for e0i4nPhusqdTaG in list(jlZ1FHdqup2LAVgi3SaoxIhnfERW4.keys()):
		hht0cpXxWw2OzFS1jnUGebkJLBd85 = jlZ1FHdqup2LAVgi3SaoxIhnfERW4[e0i4nPhusqdTaG]
		if not hht0cpXxWw2OzFS1jnUGebkJLBd85: continue
		if   e0i4nPhusqdTaG=='sort': sort = [hht0cpXxWw2OzFS1jnUGebkJLBd85]
		elif e0i4nPhusqdTaG=='series': Xt1ErNwZWQBHvC5mhKo = [hht0cpXxWw2OzFS1jnUGebkJLBd85]
		elif e0i4nPhusqdTaG=='search': search = hht0cpXxWw2OzFS1jnUGebkJLBd85
		elif e0i4nPhusqdTaG=='category': cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = [hht0cpXxWw2OzFS1jnUGebkJLBd85]
		elif e0i4nPhusqdTaG=='specialist': HDhlo3BZ7kdPWXbRjfATQOFce12qx = [hht0cpXxWw2OzFS1jnUGebkJLBd85]
	VVNkoRCUm96MbtuqgrOe = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo,"specialist":HDhlo3BZ7kdPWXbRjfATQOFce12qx,"series":Xt1ErNwZWQBHvC5mhKo,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(KLFBY9fHoxA5iR7)}}
	import json as tbfuYvJU0e4
	VVNkoRCUm96MbtuqgrOe = tbfuYvJU0e4.dumps(VVNkoRCUm96MbtuqgrOe)
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'POST',ZCimQhV5lovgspAYzHq1Ef27u8ja4R,VVNkoRCUm96MbtuqgrOe,'','','','ALMAAREF-REQUEST_DATA_PAGE-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	data = GVQAnvYCT3dS('dict',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2)
	return data
def SSbwmeph1XrWo(dNlVai6Obj1e,level):
	cz4e6sNTj53E09xtaArJLKDg = kZQthTfDOs(dNlVai6Obj1e,'1')
	ziJLDVT8NM2QcgIpmE9A = cz4e6sNTj53E09xtaArJLKDg['facets']
	if level=='1':
		ziJLDVT8NM2QcgIpmE9A = ziJLDVT8NM2QcgIpmE9A['video_categories']
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<div(.*?)/div>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for hh4gUqS5JWf1saRZPXHD in items:
			e1ebv6pD8mUitJkPXqwnjr = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',hh4gUqS5JWf1saRZPXHD+'<',E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if not e1ebv6pD8mUitJkPXqwnjr: e1ebv6pD8mUitJkPXqwnjr = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-value=\\"(.*?)\\">(.*?)<',hh4gUqS5JWf1saRZPXHD+'<',E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo,title = e1ebv6pD8mUitJkPXqwnjr[0]
			if not dNlVai6Obj1e: tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,'',42,'','2','?category='+cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo)
			else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,'',42,'','2',dNlVai6Obj1e+'&category='+cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo)
	if level=='2':
		ziJLDVT8NM2QcgIpmE9A = ziJLDVT8NM2QcgIpmE9A['specialist']
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('value="(.*?)".*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for HDhlo3BZ7kdPWXbRjfATQOFce12qx,title in items:
			if not HDhlo3BZ7kdPWXbRjfATQOFce12qx: title = title = 'الجميع'
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,'',42,'','3',dNlVai6Obj1e+'&specialist='+HDhlo3BZ7kdPWXbRjfATQOFce12qx)
	elif level=='3':
		ziJLDVT8NM2QcgIpmE9A = ziJLDVT8NM2QcgIpmE9A['series']
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('value="(.*?)".*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for Xt1ErNwZWQBHvC5mhKo,title in items:
			if not Xt1ErNwZWQBHvC5mhKo: title = title = 'الجميع'
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,'',42,'','4',dNlVai6Obj1e+'&series='+Xt1ErNwZWQBHvC5mhKo)
	elif level=='4':
		ziJLDVT8NM2QcgIpmE9A = ziJLDVT8NM2QcgIpmE9A['sort_video']
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('value="(.*?)".*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for sort,title in items:
			if not sort: continue
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,'',44,'','1',dNlVai6Obj1e+'&sort='+sort)
	return
def uyt3pAHZk4(dNlVai6Obj1e,KLFBY9fHoxA5iR7):
	cz4e6sNTj53E09xtaArJLKDg = kZQthTfDOs(dNlVai6Obj1e,KLFBY9fHoxA5iR7)
	ziJLDVT8NM2QcgIpmE9A = cz4e6sNTj53E09xtaArJLKDg['template']
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('src="(.*?)".*?href="(.*?)">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for Q2qmuDRrC9ikcaJK7gtUHXNW,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,43,Q2qmuDRrC9ikcaJK7gtUHXNW)
	ziJLDVT8NM2QcgIpmE9A = cz4e6sNTj53E09xtaArJLKDg['facets']['pagination']
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-page="(.*?)">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for tsMKaFVh1ZN2BIXEcvTejxR5DP,title in items:
		if KLFBY9fHoxA5iR7==tsMKaFVh1ZN2BIXEcvTejxR5DP: continue
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+title,'',44,'',tsMKaFVh1ZN2BIXEcvTejxR5DP,dNlVai6Obj1e)
	return
def dlropqS0vO9K7W4z(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','ALMAAREF-PLAY-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<video src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('youtube_url.*?(http.*?)&',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	zcBjFq4VQlp20ZekGO = []
	if ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0].replace('\/','/')
		zcBjFq4VQlp20ZekGO.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	import JYR902sfml
	JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt(zcBjFq4VQlp20ZekGO,r1NChsk39OMvT82YemDQnl5,'video',url)
	return
def EvpYWVrnUQA():
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',tle5V6jgvRfE+'/بث-مباشر','','','','','ALMAAREF-LIVE-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('source src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	url = BUTSkzgFC7(items[0])
	pSAuLjYqhgc9brWFKs7Pa4J(url,r1NChsk39OMvT82YemDQnl5,'live')
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	XitkYcwPqh = False
	if search=='':
		search = UIf35nZEj1wylmq()
		XitkYcwPqh = True
	if search=='': return
	if not XitkYcwPqh: uyt3pAHZk4('?search='+search,'1')
	else: SSbwmeph1XrWo('?search='+search,'1')
	return
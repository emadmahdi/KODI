# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'DAILYMOTION'
Yc0eBRLpbCkm4gK7OqyzuHwU = '_DLM_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
PLmnJkAzt8 = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][1]
def HgQCVwFx2Br(mode,url,text,type,tsMKaFVh1ZN2BIXEcvTejxR5DP):
	if	 mode==400: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==401: s4Bng5iAZQSTtpDw9 = FVaO2wKUcIm4JGxb0pCsB76(url,text)
	elif mode==402: s4Bng5iAZQSTtpDw9 = kXYy5ECFOUzePmxq04DI7Gra963B(url,text)
	elif mode==403: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url,text)
	elif mode==404: s4Bng5iAZQSTtpDw9 = X1XTUBrKMbS(text,tsMKaFVh1ZN2BIXEcvTejxR5DP)
	elif mode==405: s4Bng5iAZQSTtpDw9 = FUQVvJ9RB73GefES(text,tsMKaFVh1ZN2BIXEcvTejxR5DP)
	elif mode==406: s4Bng5iAZQSTtpDw9 = dfr9bYuwT5IzRQNV8(text,tsMKaFVh1ZN2BIXEcvTejxR5DP)
	elif mode==407: s4Bng5iAZQSTtpDw9 = XxvPY8KLIzGHt1i49aVRZ3uBMk2Npd(url,tsMKaFVh1ZN2BIXEcvTejxR5DP)
	elif mode==408: s4Bng5iAZQSTtpDw9 = KRmyzxSYusqH(url,tsMKaFVh1ZN2BIXEcvTejxR5DP)
	elif mode==409: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text,tsMKaFVh1ZN2BIXEcvTejxR5DP)
	elif mode==411: s4Bng5iAZQSTtpDw9 = KyQeOMtmpiqN0(url,text)
	elif mode==412: s4Bng5iAZQSTtpDw9 = S4Y3fqADFNzsJpvEr5nk(text,tsMKaFVh1ZN2BIXEcvTejxR5DP)
	elif mode==413: s4Bng5iAZQSTtpDw9 = XnOJzEifpUMQN8mltxjV2dav9uo(url,tsMKaFVh1ZN2BIXEcvTejxR5DP)
	elif mode==414: s4Bng5iAZQSTtpDw9 = YRoeKn9fVzHb70OmguxlkjQvs5hW(text)
	elif mode==415: s4Bng5iAZQSTtpDw9 = yKLepPFJaWx90RMs7Z5z2(text,tsMKaFVh1ZN2BIXEcvTejxR5DP)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الرئيسية','',414)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',409,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث عن فيديوهات','',409,'','videos?sortBy=','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث عن آخر الفيديوهات','',409,'','videos?sortBy=RECENT','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث عن الفيديوهات الأكثر مشاهدة','',409,'','videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث عن قوائم التشغيل','',409,'','playlists','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث عن قنوات','',409,'','channels','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث عن مواضيع','',409,'','topics','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث عن بث حي','',409,'','lives','_REMEMBERRESULTS_')
	return
def kXYy5ECFOUzePmxq04DI7Gra963B(url,fbGVEUQotnT0M4Fw1sYNI6zj):
	if '/dm_' in url:
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',url,'','',False,'','DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = aQniqUlZk8.headers
		if 'Location' in list(headers.keys()): url = tle5V6jgvRfE+headers['Location']
	fbGVEUQotnT0M4Fw1sYNI6zj = '[COLOR FFC89008]'+fbGVEUQotnT0M4Fw1sYNI6zj+'[/COLOR]'
	fbGVEUQotnT0M4Fw1sYNI6zj = TTW982Z60G7Opdeg3(fbGVEUQotnT0M4Fw1sYNI6zj)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+':: بث حي',url,411,'','','channel_lives_now')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+':: آخر الفيديوهات',url+'/videos',408)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+':: المميزة',url,411,'','','channel_featured_videos')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+':: قوائم التشغيل',url+'/playlists',407)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+':: قنوات ذات صلة',url,411,'','','channel_related_channel')
	return
def TTW982Z60G7Opdeg3(title):
	title = title.rstrip('\\').strip(' ').replace('\\\\','\\')
	title = zKGXT5sJeRq(title)
	return title
def dlropqS0vO9K7W4z(url,qAdI4N6keMiRcjVQEHbrv0hlgGJ):
	import JYR902sfml
	JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt([url],r1NChsk39OMvT82YemDQnl5,'video',url)
	return
def X1XTUBrKMbS(search,tsMKaFVh1ZN2BIXEcvTejxR5DP=''):
	if tsMKaFVh1ZN2BIXEcvTejxR5DP=='': tsMKaFVh1ZN2BIXEcvTejxR5DP = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = ''
	search = search.split('/videos')[0]
	VWi2dTb46v3eOryuspKBF9L = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mysearchwords',search)
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mypagelimit','40')
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mypagenumber',tsMKaFVh1ZN2BIXEcvTejxR5DP)
	if sort=='': VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mysortmethod','')
	else: VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = tle5V6jgvRfE+'/search/'+search+'/videos'
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = TWb34O5tejoAlJCFRfV6q(VWi2dTb46v3eOryuspKBF9L)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"videos"(.*?)"VideoConnection"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"node".*?"xid":"(.*?)","title":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for id,title,pwEnASF1RUhjDO,fbGVEUQotnT0M4Fw1sYNI6zj,s6z12JQXUyK5Wn4Bf7LYiDIP9F,Q2qmuDRrC9ikcaJK7gtUHXNW in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in Q2qmuDRrC9ikcaJK7gtUHXNW: Q2qmuDRrC9ikcaJK7gtUHXNW = Q2qmuDRrC9ikcaJK7gtUHXNW.replace('"','')
			if '"' in s6z12JQXUyK5Wn4Bf7LYiDIP9F: s6z12JQXUyK5Wn4Bf7LYiDIP9F = s6z12JQXUyK5Wn4Bf7LYiDIP9F.replace('"','')
			if '"' in pwEnASF1RUhjDO: pwEnASF1RUhjDO = pwEnASF1RUhjDO.replace('"','')
			if '"' in fbGVEUQotnT0M4Fw1sYNI6zj: fbGVEUQotnT0M4Fw1sYNI6zj = fbGVEUQotnT0M4Fw1sYNI6zj.replace('"','')
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/video/'+id
			title = TTW982Z60G7Opdeg3(title)
			qAdI4N6keMiRcjVQEHbrv0hlgGJ = pwEnASF1RUhjDO+'::'+fbGVEUQotnT0M4Fw1sYNI6zj
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,403,Q2qmuDRrC9ikcaJK7gtUHXNW,s6z12JQXUyK5Wn4Bf7LYiDIP9F,qAdI4N6keMiRcjVQEHbrv0hlgGJ)
		if '"hasNextPage":true' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2:
			tsMKaFVh1ZN2BIXEcvTejxR5DP = str(int(tsMKaFVh1ZN2BIXEcvTejxR5DP)+1)
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+tsMKaFVh1ZN2BIXEcvTejxR5DP,url,404,'',tsMKaFVh1ZN2BIXEcvTejxR5DP,search)
	return
def FUQVvJ9RB73GefES(search,tsMKaFVh1ZN2BIXEcvTejxR5DP=''):
	if tsMKaFVh1ZN2BIXEcvTejxR5DP=='': tsMKaFVh1ZN2BIXEcvTejxR5DP = '1'
	VWi2dTb46v3eOryuspKBF9L = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mysearchwords',search)
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mypagelimit','40')
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mypagenumber',tsMKaFVh1ZN2BIXEcvTejxR5DP)
	url = tle5V6jgvRfE+'/search/'+search+'/playlists'
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = TWb34O5tejoAlJCFRfV6q(VWi2dTb46v3eOryuspKBF9L)
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)".*?"total":(.*?),',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for id,name,R1R6jckeWZfBqh29lF,pwEnASF1RUhjDO,fbGVEUQotnT0M4Fw1sYNI6zj,Q2qmuDRrC9ikcaJK7gtUHXNW,count in items:
		if '"' in R1R6jckeWZfBqh29lF: R1R6jckeWZfBqh29lF = R1R6jckeWZfBqh29lF.replace('"','')
		if '"' in pwEnASF1RUhjDO: pwEnASF1RUhjDO = pwEnASF1RUhjDO.replace('"','')
		if '"' in fbGVEUQotnT0M4Fw1sYNI6zj: fbGVEUQotnT0M4Fw1sYNI6zj = fbGVEUQotnT0M4Fw1sYNI6zj.replace('"','')
		if '"' in id: id = id.replace('"','')
		if '"' in name: name = name.replace('"','')
		if '"' in Q2qmuDRrC9ikcaJK7gtUHXNW: Q2qmuDRrC9ikcaJK7gtUHXNW = Q2qmuDRrC9ikcaJK7gtUHXNW.replace('"','')
		if '"' in count: count = count.replace('"','')
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = TTW982Z60G7Opdeg3(title)
		qAdI4N6keMiRcjVQEHbrv0hlgGJ = pwEnASF1RUhjDO+'::'+fbGVEUQotnT0M4Fw1sYNI6zj
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,401,Q2qmuDRrC9ikcaJK7gtUHXNW,'',qAdI4N6keMiRcjVQEHbrv0hlgGJ)
	if '"hasNextPage":true' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2:
		tsMKaFVh1ZN2BIXEcvTejxR5DP = str(int(tsMKaFVh1ZN2BIXEcvTejxR5DP)+1)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+tsMKaFVh1ZN2BIXEcvTejxR5DP,url,405,'',tsMKaFVh1ZN2BIXEcvTejxR5DP,search)
	return
def dfr9bYuwT5IzRQNV8(search,tsMKaFVh1ZN2BIXEcvTejxR5DP=''):
	if tsMKaFVh1ZN2BIXEcvTejxR5DP=='': tsMKaFVh1ZN2BIXEcvTejxR5DP = '1'
	VWi2dTb46v3eOryuspKBF9L = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mysearchwords',search)
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mypagelimit','40')
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mypagenumber',tsMKaFVh1ZN2BIXEcvTejxR5DP)
	url = tle5V6jgvRfE+'/search/'+search+'/channels'
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = TWb34O5tejoAlJCFRfV6q(VWi2dTb46v3eOryuspKBF9L)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"channels"(.*?)"ChannelConnection"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"node".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for id,name,Q2qmuDRrC9ikcaJK7gtUHXNW in items:
			if '"' in id: id = id.replace('"','')
			if '"' in name: name = name.replace('"','')
			if '"' in Q2qmuDRrC9ikcaJK7gtUHXNW: Q2qmuDRrC9ikcaJK7gtUHXNW = Q2qmuDRrC9ikcaJK7gtUHXNW.replace('"','')
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/'+id
			title = 'CHNL:  '+name
			title = TTW982Z60G7Opdeg3(title)
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,402,Q2qmuDRrC9ikcaJK7gtUHXNW,'',name)
		if '"hasNextPage":true' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2:
			tsMKaFVh1ZN2BIXEcvTejxR5DP = str(int(tsMKaFVh1ZN2BIXEcvTejxR5DP)+1)
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+tsMKaFVh1ZN2BIXEcvTejxR5DP,url,406,'',tsMKaFVh1ZN2BIXEcvTejxR5DP,search)
	return
def YRoeKn9fVzHb70OmguxlkjQvs5hW(RoNn2BTMEXFbhAq0):
	VWi2dTb46v3eOryuspKBF9L = '{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  thumbnail: coverURL(size: \"x532\")\n  coverURL: coverURL(size: \"x532\")\n  isFollowed\n  whitelistStatus {\n    id\n    isWhitelisted\n    __typename\n  }\n  __typename\n}\n\nquery HOME_QUERY($space: String!) {\n  home: views {\n    id\n    neon {\n      id\n      sections(space: $space) {\n        edges {\n          node {\n            id\n            name\n            title\n            description\n            groupingType\n            type\n            relatedComponent {\n              __typename\n              ... on Collection {\n                id\n                xid\n                __typename\n              }\n              ... on Channel {\n                id\n                xid\n                name\n                displayName\n                logoURL(size: \"x60\")\n                __typename\n              }\n              ... on Topic {\n                id\n                __typename\n                ...TOPIC_BASE_FRAG\n              }\n            }\n            components {\n              edges {\n                node {\n                  __typename\n                  ... on Video {\n                    id\n                    xid\n                    title\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx360: thumbnailURL(size: \"x360\")\n                    thumbnailx480: thumbnailURL(size: \"x480\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    aspectRatio\n                    createdAt\n                    channel {\n                      id\n                      xid\n                      name\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      accountType\n                      __typename\n                    }\n                    description\n                    duration\n                    __typename\n                  }\n                  ... on Live {\n                    id\n                    xid\n                    title\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx360: thumbnailURL(size: \"x360\")\n                    thumbnailx480: thumbnailURL(size: \"x480\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    aspectRatio\n                    createdAt\n                    channel {\n                      id\n                      xid\n                      name\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      accountType\n                      __typename\n                    }\n                    startAt\n                    __typename\n                  }\n                }\n                __typename\n              }\n              __typename\n            }\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	GrSazPw083KDJY6c7Hvt5NEqkhWQuV = TWb34O5tejoAlJCFRfV6q(VWi2dTb46v3eOryuspKBF9L)
	if GrSazPw083KDJY6c7Hvt5NEqkhWQuV:
		ouwd74xgVZU = GVQAnvYCT3dS('dict',GrSazPw083KDJY6c7Hvt5NEqkhWQuV)
		WtMavhYpkGLE6N14qZPuxecJ2 = ouwd74xgVZU['data']['home']['neon']['sections']['edges']
		if not RoNn2BTMEXFbhAq0:
			kRI7Uqxl246 = []
			for A8i9qZE0SsIchLtUXWdKr6TGVCR1 in WtMavhYpkGLE6N14qZPuxecJ2:
				ge5HWnZiL8DlzvCPMfBquE3TKFV = A8i9qZE0SsIchLtUXWdKr6TGVCR1['node']['title']
				if ge5HWnZiL8DlzvCPMfBquE3TKFV not in kRI7Uqxl246: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+ge5HWnZiL8DlzvCPMfBquE3TKFV,'',414,'','',ge5HWnZiL8DlzvCPMfBquE3TKFV)
				kRI7Uqxl246.append(ge5HWnZiL8DlzvCPMfBquE3TKFV)
		else:
			for A8i9qZE0SsIchLtUXWdKr6TGVCR1 in WtMavhYpkGLE6N14qZPuxecJ2:
				ge5HWnZiL8DlzvCPMfBquE3TKFV = A8i9qZE0SsIchLtUXWdKr6TGVCR1['node']['title']
				if ge5HWnZiL8DlzvCPMfBquE3TKFV==RoNn2BTMEXFbhAq0:
					o7vypS2G1rkLYzR = A8i9qZE0SsIchLtUXWdKr6TGVCR1['node']['components']['edges']
					for zEuRpqAmrdO9kb6NB4SLXKe in o7vypS2G1rkLYzR:
						s6z12JQXUyK5Wn4Bf7LYiDIP9F = str(zEuRpqAmrdO9kb6NB4SLXKe['node']['duration'])
						title = zKGXT5sJeRq(zEuRpqAmrdO9kb6NB4SLXKe['node']['title'])
						title = title.replace('\/','/')
						GQj4JyzWO9ubTD6n7dgH = zEuRpqAmrdO9kb6NB4SLXKe['node']['xid']
						Q2qmuDRrC9ikcaJK7gtUHXNW = zEuRpqAmrdO9kb6NB4SLXKe['node']['thumbnailx480']
						Q2qmuDRrC9ikcaJK7gtUHXNW = Q2qmuDRrC9ikcaJK7gtUHXNW.replace('\/','/')
						ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/video/'+GQj4JyzWO9ubTD6n7dgH
						tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,403,Q2qmuDRrC9ikcaJK7gtUHXNW,s6z12JQXUyK5Wn4Bf7LYiDIP9F)
	return
def yKLepPFJaWx90RMs7Z5z2(search,tsMKaFVh1ZN2BIXEcvTejxR5DP=''):
	if tsMKaFVh1ZN2BIXEcvTejxR5DP=='': tsMKaFVh1ZN2BIXEcvTejxR5DP = '1'
	VWi2dTb46v3eOryuspKBF9L = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  aspectRatio\n  __typename\n}\n\nfragment VIDEO_FAVORITES_FRAGMENT on Media {\n  __typename\n  ... on Video {\n    id\n    viewerEngagement {\n      id\n      favorited\n      __typename\n    }\n    __typename\n  }\n  ... on Live {\n    id\n    viewerEngagement {\n      id\n      favorited\n      __typename\n    }\n    __typename\n  }\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  videos(sort: \"recent\", first: 5) {\n    pageInfo {\n      hasNextPage\n      nextPage\n      __typename\n    }\n    edges {\n      node {\n        id\n        ...VIDEO_BASE_FRAGMENT\n        ...VIDEO_FAVORITES_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(\n      query: $query\n      first: $limit\n      page: $page\n      sort: $sortByVideos\n      durationMin: $durationMinVideos\n      durationMax: $durationMaxVideos\n      createdAfter: $createdAfterVideos\n    ) @include(if: $shouldIncludeVideos) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_FAVORITES_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          xid\n          title\n          thumbnail: thumbnailURL(size: \"x240\")\n          thumbnailx60: thumbnailURL(size: \"x60\")\n          thumbnailx120: thumbnailURL(size: \"x120\")\n          thumbnailx240: thumbnailURL(size: \"x240\")\n          thumbnailx720: thumbnailURL(size: \"x720\")\n          audienceCount\n          aspectRatio\n          isOnAir\n          channel {\n            id\n            xid\n            name\n            displayName\n            accountType\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...TOPIC_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mysearchwords',search)
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mypagelimit','40')
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mypagenumber',tsMKaFVh1ZN2BIXEcvTejxR5DP)
	url = tle5V6jgvRfE+'/search/'+search+'/lives'
	GrSazPw083KDJY6c7Hvt5NEqkhWQuV = TWb34O5tejoAlJCFRfV6q(VWi2dTb46v3eOryuspKBF9L)
	if GrSazPw083KDJY6c7Hvt5NEqkhWQuV:
		ouwd74xgVZU = GVQAnvYCT3dS('dict',GrSazPw083KDJY6c7Hvt5NEqkhWQuV)
		try: WtMavhYpkGLE6N14qZPuxecJ2 = ouwd74xgVZU['data']['search']['lives']['edges']
		except: WtMavhYpkGLE6N14qZPuxecJ2 = []
		for A8i9qZE0SsIchLtUXWdKr6TGVCR1 in WtMavhYpkGLE6N14qZPuxecJ2:
			name = A8i9qZE0SsIchLtUXWdKr6TGVCR1['node']['title']
			GQj4JyzWO9ubTD6n7dgH = A8i9qZE0SsIchLtUXWdKr6TGVCR1['node']['xid']
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/video/'+GQj4JyzWO9ubTD6n7dgH
			tBq8fTGUWJY9zvbgXD0EAloPO('live',Yc0eBRLpbCkm4gK7OqyzuHwU+'LIVE: '+name,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,403)
		if '"hasNextPage":true' in GrSazPw083KDJY6c7Hvt5NEqkhWQuV:
			tsMKaFVh1ZN2BIXEcvTejxR5DP = str(int(tsMKaFVh1ZN2BIXEcvTejxR5DP)+1)
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+tsMKaFVh1ZN2BIXEcvTejxR5DP,url,415,'',tsMKaFVh1ZN2BIXEcvTejxR5DP,search)
	return
def S4Y3fqADFNzsJpvEr5nk(search,tsMKaFVh1ZN2BIXEcvTejxR5DP=''):
	if tsMKaFVh1ZN2BIXEcvTejxR5DP=='': tsMKaFVh1ZN2BIXEcvTejxR5DP = '1'
	VWi2dTb46v3eOryuspKBF9L = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  aspectRatio\n  __typename\n}\n\nfragment VIDEO_FAVORITES_FRAGMENT on Media {\n  __typename\n  ... on Video {\n    id\n    isInWatchLater\n    __typename\n  }\n  ... on Live {\n    id\n    isInWatchLater\n    __typename\n  }\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  videos(sort: \"recent\", first: 5) {\n    pageInfo {\n      hasNextPage\n      nextPage\n      __typename\n    }\n    edges {\n      node {\n        id\n        ...VIDEO_BASE_FRAGMENT\n        ...VIDEO_FAVORITES_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(\n      query: $query\n      first: $limit\n      page: $page\n      sort: $sortByVideos\n      durationMin: $durationMinVideos\n      durationMax: $durationMaxVideos\n      createdAfter: $createdAfterVideos\n    ) @include(if: $shouldIncludeVideos) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_FAVORITES_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...TOPIC_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mysearchwords',search)
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mypagelimit','40')
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mypagenumber',tsMKaFVh1ZN2BIXEcvTejxR5DP)
	url = tle5V6jgvRfE+'/search/'+search+'/topics'
	GrSazPw083KDJY6c7Hvt5NEqkhWQuV = TWb34O5tejoAlJCFRfV6q(VWi2dTb46v3eOryuspKBF9L)
	if GrSazPw083KDJY6c7Hvt5NEqkhWQuV:
		ouwd74xgVZU = GVQAnvYCT3dS('dict',GrSazPw083KDJY6c7Hvt5NEqkhWQuV)
		try: WtMavhYpkGLE6N14qZPuxecJ2 = ouwd74xgVZU['data']['search']['topics']['edges']
		except: WtMavhYpkGLE6N14qZPuxecJ2 = []
		for A8i9qZE0SsIchLtUXWdKr6TGVCR1 in WtMavhYpkGLE6N14qZPuxecJ2:
			name = A8i9qZE0SsIchLtUXWdKr6TGVCR1['node']['name']
			GQj4JyzWO9ubTD6n7dgH = A8i9qZE0SsIchLtUXWdKr6TGVCR1['node']['xid']
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/topic/'+GQj4JyzWO9ubTD6n7dgH
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'TOPIC: '+name,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,413)
		if '"hasNextPage":true' in GrSazPw083KDJY6c7Hvt5NEqkhWQuV:
			tsMKaFVh1ZN2BIXEcvTejxR5DP = str(int(tsMKaFVh1ZN2BIXEcvTejxR5DP)+1)
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+tsMKaFVh1ZN2BIXEcvTejxR5DP,url,412,'',tsMKaFVh1ZN2BIXEcvTejxR5DP,search)
	return
def XnOJzEifpUMQN8mltxjV2dav9uo(url,tsMKaFVh1ZN2BIXEcvTejxR5DP=''):
	if tsMKaFVh1ZN2BIXEcvTejxR5DP=='': tsMKaFVh1ZN2BIXEcvTejxR5DP = '1'
	GQj4JyzWO9ubTD6n7dgH = url.split('/')[-1]
	VWi2dTb46v3eOryuspKBF9L = '{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  duration\n  isLiked\n  isInWatchLater\n  isCreatedForKids\n  createdAt\n  isExplicit\n  videoHeight: height\n  videoWidth: width\n  category\n  channel {\n    id\n    xid\n    name\n    displayName\n    logoURLx25: logoURL(size: \"x25\")\n    logoURL(size: \"x60\")\n    accountType\n    __typename\n  }\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  language {\n    id\n    codeAlpha2\n    __typename\n  }\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  bestAvailableQuality\n  aspectRatio\n  isPublished\n  __typename\n}\n\nquery DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {\n  topic(xid: $xid) {\n    id\n    xid\n    name\n    videos(sort: \"recent\", first: 30, page: $page) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          ...TOPIC_VIDEO_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mytopicid',GQj4JyzWO9ubTD6n7dgH)
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mypagenumber',tsMKaFVh1ZN2BIXEcvTejxR5DP)
	GrSazPw083KDJY6c7Hvt5NEqkhWQuV = TWb34O5tejoAlJCFRfV6q(VWi2dTb46v3eOryuspKBF9L)
	if GrSazPw083KDJY6c7Hvt5NEqkhWQuV:
		ouwd74xgVZU = GVQAnvYCT3dS('dict',GrSazPw083KDJY6c7Hvt5NEqkhWQuV)
		WtMavhYpkGLE6N14qZPuxecJ2 = ouwd74xgVZU['data']['topic']['videos']['edges']
		for A8i9qZE0SsIchLtUXWdKr6TGVCR1 in WtMavhYpkGLE6N14qZPuxecJ2:
			s6z12JQXUyK5Wn4Bf7LYiDIP9F = str(A8i9qZE0SsIchLtUXWdKr6TGVCR1['node']['duration'])
			title = zKGXT5sJeRq(A8i9qZE0SsIchLtUXWdKr6TGVCR1['node']['title'])
			title = title.replace('\/','/')
			GQj4JyzWO9ubTD6n7dgH = A8i9qZE0SsIchLtUXWdKr6TGVCR1['node']['xid']
			Q2qmuDRrC9ikcaJK7gtUHXNW = A8i9qZE0SsIchLtUXWdKr6TGVCR1['node']['thumbnailx480']
			Q2qmuDRrC9ikcaJK7gtUHXNW = Q2qmuDRrC9ikcaJK7gtUHXNW.replace('\/','/')
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/video/'+GQj4JyzWO9ubTD6n7dgH
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,403,Q2qmuDRrC9ikcaJK7gtUHXNW,s6z12JQXUyK5Wn4Bf7LYiDIP9F)
		if '"hasNextPage":true' in GrSazPw083KDJY6c7Hvt5NEqkhWQuV:
			tsMKaFVh1ZN2BIXEcvTejxR5DP = str(int(tsMKaFVh1ZN2BIXEcvTejxR5DP)+1)
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+tsMKaFVh1ZN2BIXEcvTejxR5DP,url,413,'',tsMKaFVh1ZN2BIXEcvTejxR5DP)
	return
def FVaO2wKUcIm4JGxb0pCsB76(url,qAdI4N6keMiRcjVQEHbrv0hlgGJ):
	id = url.split('/')[-1]
	pwEnASF1RUhjDO,fbGVEUQotnT0M4Fw1sYNI6zj = qAdI4N6keMiRcjVQEHbrv0hlgGJ.split('::',1)
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/'+pwEnASF1RUhjDO
	fbGVEUQotnT0M4Fw1sYNI6zj = TTW982Z60G7Opdeg3(fbGVEUQotnT0M4Fw1sYNI6zj)
	title = '[COLOR FFC89008]OWNER:  '+fbGVEUQotnT0M4Fw1sYNI6zj+'[/COLOR]'
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,402,'','',fbGVEUQotnT0M4Fw1sYNI6zj)
	VWi2dTb46v3eOryuspKBF9L = '{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {\n  views {\n    id\n    neon {\n      id\n      sections(device: $device, space: \"watching\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {\n        edges {\n          node {\n            id\n            name\n            groupingType\n            relatedComponent {\n              ... on Channel {\n                __typename\n                id\n                xid\n                name\n                displayName\n                logoURL(size: \"x60\")\n                logoURLx25: logoURL(size: \"x25\")\n              }\n              ... on Topic {\n                __typename\n                id\n                xid\n                name\n                names {\n                  edges {\n                    node {\n                      id\n                      name\n                      language {\n                        id\n                        codeAlpha2\n                        __typename\n                      }\n                      __typename\n                    }\n                    __typename\n                  }\n                  __typename\n                }\n              }\n              ... on Collection {\n                __typename\n                id\n                xid\n                name\n              }\n              __typename\n            }\n            components(first: $videoCountPerSection) {\n              metadata {\n                algorithm {\n                  name\n                  version\n                  uuid\n                  __typename\n                }\n                __typename\n              }\n              edges {\n                node {\n                  ... on Video {\n                    __typename\n                    id\n                    xid\n                    title\n                    duration\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    channel {\n                      id\n                      xid\n                      accountType\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      logoURL(size: \"x60\")\n                      __typename\n                    }\n                  }\n                  ... on Channel {\n                    __typename\n                    id\n                    xid\n                    name\n                    displayName\n                    accountType\n                    logoURL(size: \"x60\")\n                  }\n                  __typename\n                }\n                __typename\n              }\n              __typename\n            }\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('myplaylistid',id)
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = TWb34O5tejoAlJCFRfV6q(VWi2dTb46v3eOryuspKBF9L)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"collection_videos"(.*?)"SectionEdge"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)".*?"xid":"(.*?)".*?"displayName":"(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for id,title,s6z12JQXUyK5Wn4Bf7LYiDIP9F,Q2qmuDRrC9ikcaJK7gtUHXNW,pwEnASF1RUhjDO,fbGVEUQotnT0M4Fw1sYNI6zj in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in Q2qmuDRrC9ikcaJK7gtUHXNW: Q2qmuDRrC9ikcaJK7gtUHXNW = Q2qmuDRrC9ikcaJK7gtUHXNW.replace('"','')
			if '"' in s6z12JQXUyK5Wn4Bf7LYiDIP9F: s6z12JQXUyK5Wn4Bf7LYiDIP9F = s6z12JQXUyK5Wn4Bf7LYiDIP9F.replace('"','')
			if '"' in pwEnASF1RUhjDO: pwEnASF1RUhjDO = pwEnASF1RUhjDO.replace('"','')
			if '"' in fbGVEUQotnT0M4Fw1sYNI6zj: fbGVEUQotnT0M4Fw1sYNI6zj = fbGVEUQotnT0M4Fw1sYNI6zj.replace('"','')
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/video/'+id
			title = TTW982Z60G7Opdeg3(title)
			qAdI4N6keMiRcjVQEHbrv0hlgGJ = pwEnASF1RUhjDO+'::'+fbGVEUQotnT0M4Fw1sYNI6zj
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,403,Q2qmuDRrC9ikcaJK7gtUHXNW,s6z12JQXUyK5Wn4Bf7LYiDIP9F,qAdI4N6keMiRcjVQEHbrv0hlgGJ)
	return
def KRmyzxSYusqH(url,tsMKaFVh1ZN2BIXEcvTejxR5DP=''):
	if tsMKaFVh1ZN2BIXEcvTejxR5DP=='': tsMKaFVh1ZN2BIXEcvTejxR5DP = '1'
	gUmrWFV3dB6Q1b02wuHq5 = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	VWi2dTb46v3eOryuspKBF9L = '{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  isFollowed\n  accountType\n  __typename\n}\n\nfragment CHANNEL_IMAGES_FRAGMENT on Channel {\n  id\n  coverURLx375: coverURL(size: \"x375\")\n  __typename\n}\n\nfragment CHANNEL_UPDATED_FRAGMENT on Channel {\n  id\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_COMPLETE_FRAGMENT on Channel {\n  id\n  ...CHANNEL_BASE_FRAGMENT\n  ...CHANNEL_IMAGES_FRAGMENT\n  ...CHANNEL_UPDATED_FRAGMENT\n  description\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  externalLinks {\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  viewCount\n  duration\n  createdAt\n  isInWatchLater\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  thumbURLx240: thumbnailURL(size: \"x240\")\n  thumbURLx360: thumbnailURL(size: \"x360\")\n  thumbURLx480: thumbnailURL(size: \"x480\")\n  thumbURLx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nquery CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {\n  channel(xid: $channel_xid) {\n    id\n    ...CHANNEL_COMPLETE_FRAGMENT\n    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          ...VIDEO_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mychannelid',gUmrWFV3dB6Q1b02wuHq5)
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mypagelimit','40')
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mypagenumber',tsMKaFVh1ZN2BIXEcvTejxR5DP)
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mysortmethod',sort)
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = TWb34O5tejoAlJCFRfV6q(VWi2dTb46v3eOryuspKBF9L)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbURLx240":"(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for id,title,s6z12JQXUyK5Wn4Bf7LYiDIP9F,pwEnASF1RUhjDO,fbGVEUQotnT0M4Fw1sYNI6zj,Q2qmuDRrC9ikcaJK7gtUHXNW in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in Q2qmuDRrC9ikcaJK7gtUHXNW: Q2qmuDRrC9ikcaJK7gtUHXNW = Q2qmuDRrC9ikcaJK7gtUHXNW.replace('"','')
			if '"' in s6z12JQXUyK5Wn4Bf7LYiDIP9F: s6z12JQXUyK5Wn4Bf7LYiDIP9F = s6z12JQXUyK5Wn4Bf7LYiDIP9F.replace('"','')
			if '"' in pwEnASF1RUhjDO: pwEnASF1RUhjDO = pwEnASF1RUhjDO.replace('"','')
			if '"' in fbGVEUQotnT0M4Fw1sYNI6zj: fbGVEUQotnT0M4Fw1sYNI6zj = fbGVEUQotnT0M4Fw1sYNI6zj.replace('"','')
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/video/'+id
			title = TTW982Z60G7Opdeg3(title)
			qAdI4N6keMiRcjVQEHbrv0hlgGJ = pwEnASF1RUhjDO+'::'+fbGVEUQotnT0M4Fw1sYNI6zj
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,403,Q2qmuDRrC9ikcaJK7gtUHXNW,s6z12JQXUyK5Wn4Bf7LYiDIP9F,qAdI4N6keMiRcjVQEHbrv0hlgGJ)
		if '"hasNextPage":true' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2:
			tsMKaFVh1ZN2BIXEcvTejxR5DP = str(int(tsMKaFVh1ZN2BIXEcvTejxR5DP)+1)
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+tsMKaFVh1ZN2BIXEcvTejxR5DP,url,408,'',tsMKaFVh1ZN2BIXEcvTejxR5DP)
	return
def XxvPY8KLIzGHt1i49aVRZ3uBMk2Npd(url,tsMKaFVh1ZN2BIXEcvTejxR5DP=''):
	if tsMKaFVh1ZN2BIXEcvTejxR5DP=='': tsMKaFVh1ZN2BIXEcvTejxR5DP = '1'
	gUmrWFV3dB6Q1b02wuHq5 = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	VWi2dTb46v3eOryuspKBF9L = '{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  isFollowed\n  accountType\n  __typename\n}\n\nfragment CHANNEL_IMAGES_FRAGMENT on Channel {\n  id\n  coverURLx375: coverURL(size: \"x375\")\n  __typename\n}\n\nfragment CHANNEL_UPDATED_FRAGMENT on Channel {\n  id\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_COMPLETE_FRAGMENT on Channel {\n  id\n  ...CHANNEL_BASE_FRAGMENT\n  ...CHANNEL_IMAGES_FRAGMENT\n  ...CHANNEL_UPDATED_FRAGMENT\n  description\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  externalLinks {\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {\n  channel(xid: $channel_xid) {\n    id\n    ...CHANNEL_COMPLETE_FRAGMENT\n    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          xid\n          updatedAt\n          name\n          description\n          thumbURLx240: thumbnailURL(size: \"x240\")\n          thumbURLx360: thumbnailURL(size: \"x360\")\n          thumbURLx480: thumbnailURL(size: \"x480\")\n          stats {\n            videos {\n              total\n              __typename\n            }\n            __typename\n          }\n          channel {\n            id\n            ...CHANNEL_FRAGMENT\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mychannelid',gUmrWFV3dB6Q1b02wuHq5)
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mypagelimit','40')
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mypagenumber',tsMKaFVh1ZN2BIXEcvTejxR5DP)
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mysortmethod',sort)
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = TWb34O5tejoAlJCFRfV6q(VWi2dTb46v3eOryuspKBF9L)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"thumbURLx240":"(.*?)".*?"total":(.*?),.*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for id,name,Q2qmuDRrC9ikcaJK7gtUHXNW,count,R1R6jckeWZfBqh29lF,pwEnASF1RUhjDO,fbGVEUQotnT0M4Fw1sYNI6zj in items:
			if '"' in id: id = id.replace('"','')
			if '"' in name: name = name.replace('"','')
			if '"' in Q2qmuDRrC9ikcaJK7gtUHXNW: Q2qmuDRrC9ikcaJK7gtUHXNW = Q2qmuDRrC9ikcaJK7gtUHXNW.replace('"','')
			if '"' in count: count = count.replace('"','')
			if '"' in R1R6jckeWZfBqh29lF: R1R6jckeWZfBqh29lF = R1R6jckeWZfBqh29lF.replace('"','')
			if '"' in pwEnASF1RUhjDO: pwEnASF1RUhjDO = pwEnASF1RUhjDO.replace('"','')
			if '"' in fbGVEUQotnT0M4Fw1sYNI6zj: fbGVEUQotnT0M4Fw1sYNI6zj = fbGVEUQotnT0M4Fw1sYNI6zj.replace('"','')
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = TTW982Z60G7Opdeg3(title)
			qAdI4N6keMiRcjVQEHbrv0hlgGJ = pwEnASF1RUhjDO+'::'+fbGVEUQotnT0M4Fw1sYNI6zj
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,401,Q2qmuDRrC9ikcaJK7gtUHXNW,'',qAdI4N6keMiRcjVQEHbrv0hlgGJ)
		if '"hasNextPage":true' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2:
			tsMKaFVh1ZN2BIXEcvTejxR5DP = str(int(tsMKaFVh1ZN2BIXEcvTejxR5DP)+1)
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+tsMKaFVh1ZN2BIXEcvTejxR5DP,url,407,'',tsMKaFVh1ZN2BIXEcvTejxR5DP)
	return
def KyQeOMtmpiqN0(url,Al6xT3OvrgtPja5Ki9BfbQuzVE):
	gUmrWFV3dB6Q1b02wuHq5 = url.split('/')[3]
	VWi2dTb46v3eOryuspKBF9L = '{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    followers {\n      id\n      total\n      __typename\n    }\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment LIVE_FRAGMENT on Live {\n  id\n  xid\n  title\n  startAt\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  __typename\n}\n\nfragment VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  viewCount\n  duration\n  createdAt\n  isInWatchLater\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment CHANNEL_MAIN_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  description\n  accountType\n  isArtist\n  logoURL(size: \"x60\")\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  isFollowed\n  tagline\n  country {\n    id\n    codeAlpha2\n    __typename\n  }\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    followers {\n      id\n      total\n      __typename\n    }\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  externalLinks {\n    id\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    pinterestURL\n    __typename\n  }\n  channel_lives_now: lives(first: 4, isOnAir: true) {\n    edges {\n      node {\n        id\n        ...LIVE_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_lives_scheduled: lives(first: 4, startIn: 7200) {\n    edges {\n      node {\n        id\n        ...LIVE_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_featured_videos: videos(first: 4, isFeatured: true) {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_all_videos: videos(first: 4) {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_most_viewed: videos(first: 4, sort: \"visited\") {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_collections: collections(first: 4) {\n    edges {\n      node {\n        id\n        xid\n        name\n        description\n        stats {\n          id\n          videos {\n            id\n            total\n            __typename\n          }\n          __typename\n        }\n        thumbnailx240: thumbnailURL(size: \"x240\")\n        thumbnailx360: thumbnailURL(size: \"x360\")\n        thumbnailx480: thumbnailURL(size: \"x480\")\n        channel {\n          id\n          ...CHANNEL_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_related_channel: networkChannels(\n    hasPublicVideos: true\n    first: $relatedChannels\n  ) {\n    edges {\n      node {\n        id\n        ...CHANNEL_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {\n  channel(name: $channel_name) {\n    id\n    ...CHANNEL_MAIN_FRAGMENT\n    __typename\n  }\n}\n"}'
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('mychannelid',gUmrWFV3dB6Q1b02wuHq5)
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = TWb34O5tejoAlJCFRfV6q(VWi2dTb46v3eOryuspKBF9L)
	import json as tbfuYvJU0e4
	ekgcVNF5HSj0yb = tbfuYvJU0e4.loads(M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2)
	try: items = ekgcVNF5HSj0yb['data']['channel'][Al6xT3OvrgtPja5Ki9BfbQuzVE]['edges']
	except: items = []
	if not items: tBq8fTGUWJY9zvbgXD0EAloPO('link',Yc0eBRLpbCkm4gK7OqyzuHwU+'لا توجد نتائج','',9999)
	else:
		for hh4gUqS5JWf1saRZPXHD in items:
			eewMLuT6dA8EPX3vYnmZoBzyUaVK = hh4gUqS5JWf1saRZPXHD['node']
			GQj4JyzWO9ubTD6n7dgH = eewMLuT6dA8EPX3vYnmZoBzyUaVK['xid']
			keys = list(eewMLuT6dA8EPX3vYnmZoBzyUaVK.keys())
			OMcnPl0Lp397iJ4dNjgRxAHTUY8fu = eewMLuT6dA8EPX3vYnmZoBzyUaVK['__typename'].lower()
			if OMcnPl0Lp397iJ4dNjgRxAHTUY8fu=='channel':
				name = eewMLuT6dA8EPX3vYnmZoBzyUaVK['name']
				xawDLBUgEvhSHATFVeqnc0r2 = eewMLuT6dA8EPX3vYnmZoBzyUaVK['displayName']
				title = 'CHNL:  '+xawDLBUgEvhSHATFVeqnc0r2
				Q2qmuDRrC9ikcaJK7gtUHXNW = eewMLuT6dA8EPX3vYnmZoBzyUaVK['coverURLx375']
			else:
				name = eewMLuT6dA8EPX3vYnmZoBzyUaVK['channel']['name']
				xawDLBUgEvhSHATFVeqnc0r2 = eewMLuT6dA8EPX3vYnmZoBzyUaVK['channel']['displayName']
				title = eewMLuT6dA8EPX3vYnmZoBzyUaVK['title']
				Q2qmuDRrC9ikcaJK7gtUHXNW = eewMLuT6dA8EPX3vYnmZoBzyUaVK['thumbnailx360']
				if OMcnPl0Lp397iJ4dNjgRxAHTUY8fu=='live': title = 'LIVE:  '+title
			title = TTW982Z60G7Opdeg3(title)
			qAdI4N6keMiRcjVQEHbrv0hlgGJ = name+'::'+xawDLBUgEvhSHATFVeqnc0r2
			if vciEXHThAPto76QIR2pK:
				title = title.encode('utf8')
				qAdI4N6keMiRcjVQEHbrv0hlgGJ = qAdI4N6keMiRcjVQEHbrv0hlgGJ.encode('utf8')
			if OMcnPl0Lp397iJ4dNjgRxAHTUY8fu=='channel':
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/'+GQj4JyzWO9ubTD6n7dgH
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,402,Q2qmuDRrC9ikcaJK7gtUHXNW,'',qAdI4N6keMiRcjVQEHbrv0hlgGJ)
			else:
				if OMcnPl0Lp397iJ4dNjgRxAHTUY8fu=='video': s6z12JQXUyK5Wn4Bf7LYiDIP9F = str(eewMLuT6dA8EPX3vYnmZoBzyUaVK['duration'])
				else: s6z12JQXUyK5Wn4Bf7LYiDIP9F = ''
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/video/'+GQj4JyzWO9ubTD6n7dgH
				tBq8fTGUWJY9zvbgXD0EAloPO(OMcnPl0Lp397iJ4dNjgRxAHTUY8fu,Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,403,Q2qmuDRrC9ikcaJK7gtUHXNW,s6z12JQXUyK5Wn4Bf7LYiDIP9F,qAdI4N6keMiRcjVQEHbrv0hlgGJ)
	return
def TWb34O5tejoAlJCFRfV6q(VWi2dTb46v3eOryuspKBF9L):
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace(' \"',' \\"')
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('\", ','\\", ')
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('\n','\\n')
	VWi2dTb46v3eOryuspKBF9L = VWi2dTb46v3eOryuspKBF9L.replace('")','\\")')
	rfi1bFwjK0mL8MdIns = S7tLByPMr5dHvaXU()
	headers = {"Authorization":rfi1bFwjK0mL8MdIns,"Origin":tle5V6jgvRfE}
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'POST',PLmnJkAzt8,VWi2dTb46v3eOryuspKBF9L,headers,'','','DAILYMOTION-GET_PAGEDATA-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	return M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
def S7tLByPMr5dHvaXU():
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',tle5V6jgvRfE,'','','','','DAILYMOTION-GET_AUTHINTICATION-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	hu6Ov8HpVCXg7k3mr2jwMc = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('var r="(.*?)",o="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	j8U6lnAh7e5,V9QxlktAmsqBy = hu6Ov8HpVCXg7k3mr2jwMc[-1]
	Wu3aNhKXP7ERd4mflc = 'https://graphql.api.dailymotion.com/oauth/token'
	M57PBbI8aCKXy63Ssot0wqV4Y1nNxO = 'client_credentials'
	data = {'client_id':j8U6lnAh7e5,'client_secret':V9QxlktAmsqBy,'grant_type':M57PBbI8aCKXy63Ssot0wqV4Y1nNxO}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'POST',Wu3aNhKXP7ERd4mflc,data,headers,'','','DAILYMOTION-GET_AUTHINTICATION-2nd')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	hu6Ov8HpVCXg7k3mr2jwMc = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	uKMl6yGvHZbx,jHYa7yme5SsA4 = hu6Ov8HpVCXg7k3mr2jwMc[0]
	rfi1bFwjK0mL8MdIns = jHYa7yme5SsA4+" "+uKMl6yGvHZbx
	return rfi1bFwjK0mL8MdIns
def Xwa7vgzTeb3Zy(search,type=''):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if not type and showDialogs:
		gQGtZ93UCWmNkEJi8wYIaqvOXH = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن قنوات','بحث عن مواضيع','بحث عن بث حي']
		NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql('موقع ديلي موشن - اختر البحث',gQGtZ93UCWmNkEJi8wYIaqvOXH)
		if NljOosKT8WJBpch==-1: return
		elif NljOosKT8WJBpch==0: type = 'videos?sortBy='
		elif NljOosKT8WJBpch==1: type = 'videos?sortBy=RECENT'
		elif NljOosKT8WJBpch==2: type = 'videos?sortBy=VIEW_COUNT'
		elif NljOosKT8WJBpch==3: type = 'playlists'
		elif NljOosKT8WJBpch==4: type = 'channels'
		elif NljOosKT8WJBpch==5: type = 'topics'
		elif NljOosKT8WJBpch==6: type = 'lives'
	elif '_DAILYMOTION-VIDEOS_' in dNlVai6Obj1e: type = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in dNlVai6Obj1e: type = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in dNlVai6Obj1e: type = 'channels'
	elif '_DAILYMOTION-TOPICS_' in dNlVai6Obj1e: type = 'topics'
	elif '_DAILYMOTION-LIVES_' in dNlVai6Obj1e: type = 'lives'
	if not search:
		search = UIf35nZEj1wylmq()
		if not search: return
	if wvkR1es6d0SrjxKt5FZTMUWz7a: search = search.encode('utf8').decode('raw_unicode_escape')
	if 'videos' in type: X1XTUBrKMbS(search+'/'+type)
	elif 'playlists' in type: FUQVvJ9RB73GefES(search)
	elif 'channels' in type: dfr9bYuwT5IzRQNV8(search)
	elif 'topics' in type: S4Y3fqADFNzsJpvEr5nk(search)
	elif 'lives' in type: yKLepPFJaWx90RMs7Z5z2(search)
	return
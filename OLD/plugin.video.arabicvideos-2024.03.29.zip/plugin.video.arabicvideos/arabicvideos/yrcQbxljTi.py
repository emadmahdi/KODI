# -*- coding: utf-8 -*-
import sys as EAPND6zHKrMRuBc91tInYohsl0ywa
ttRJUcM0Tbr7gXN5x = EAPND6zHKrMRuBc91tInYohsl0ywa.version_info [0] == 2
Z2h7adALoKv4UPc1y = 2048
K2KPeD6VyEaQ = 7
def dC3HqaFgt6QYG4 (jZYXLbSUsQp5uk1tyzBAN7Hm):
	global ZeIJ6GDodMSzFut4jc05AK3OlhETR
	HY5UkLeNComBIMQPASnxph7 = ord (jZYXLbSUsQp5uk1tyzBAN7Hm [-1])
	PlVdbOK5hqks = jZYXLbSUsQp5uk1tyzBAN7Hm [:-1]
	prvC9qsF5RtBXHiaT3PwdJ = HY5UkLeNComBIMQPASnxph7 % len (PlVdbOK5hqks)
	LQB6POHcivdw87pk09ts2XMyf1IVEh = PlVdbOK5hqks [:prvC9qsF5RtBXHiaT3PwdJ] + PlVdbOK5hqks [prvC9qsF5RtBXHiaT3PwdJ:]
	if ttRJUcM0Tbr7gXN5x:
		Gn0XReKiJFMEsUxN531yAlI7S = unicode () .join ([unichr (ord (AitBMapzjZGc4u) - Z2h7adALoKv4UPc1y - (KQsX4n7jEogiLuJz + HY5UkLeNComBIMQPASnxph7) % K2KPeD6VyEaQ) for KQsX4n7jEogiLuJz, AitBMapzjZGc4u in enumerate (LQB6POHcivdw87pk09ts2XMyf1IVEh)])
	else:
		Gn0XReKiJFMEsUxN531yAlI7S = str () .join ([chr (ord (AitBMapzjZGc4u) - Z2h7adALoKv4UPc1y - (KQsX4n7jEogiLuJz + HY5UkLeNComBIMQPASnxph7) % K2KPeD6VyEaQ) for KQsX4n7jEogiLuJz, AitBMapzjZGc4u in enumerate (LQB6POHcivdw87pk09ts2XMyf1IVEh)])
	return eval (Gn0XReKiJFMEsUxN531yAlI7S)
I7N2lHpGfLPkwKxbOu6raYUgc5,QmoEjB3hLIw,WbM6qAjrn7fEXGZw=dC3HqaFgt6QYG4,dC3HqaFgt6QYG4,dC3HqaFgt6QYG4
bbqAtUz36RPGVTvCkejpJXQB,MM564HfnUV0XIR,YDC9i52g6e8XL7GxvIFnSKWsolpr=WbM6qAjrn7fEXGZw,QmoEjB3hLIw,I7N2lHpGfLPkwKxbOu6raYUgc5
YZFXwtrfK8uhzV4LlMEqgnCQyO9,tmcuvd397wjGXeWoDHMNpFB5h2VK,Ox8k6IdtuPaG3NlApQK52oYwM=YDC9i52g6e8XL7GxvIFnSKWsolpr,MM564HfnUV0XIR,bbqAtUz36RPGVTvCkejpJXQB
GGCQK6OAtZUXRhvkgJm,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6,Gk98CL5nXZEN=Ox8k6IdtuPaG3NlApQK52oYwM,tmcuvd397wjGXeWoDHMNpFB5h2VK,YZFXwtrfK8uhzV4LlMEqgnCQyO9
dEUYJjrhsaPXNo,wx18CTJPZ5,cWfQ64kVCqxhwvSy5P7irHI1oes3=Gk98CL5nXZEN,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6,GGCQK6OAtZUXRhvkgJm
qFRrj7ayBKbOsHGSXz,SIDG7cnzAaUpkwmNde19ZsBqQ3Hh,tOdiG2HWFRBXg1sUh=cWfQ64kVCqxhwvSy5P7irHI1oes3,wx18CTJPZ5,dEUYJjrhsaPXNo
smpniPDOhfwI3H4v7c6TG,CIcPowhneWs5tN3,zxwIDBrPiXjKlsYkfg0AGaUZSyW2co=tOdiG2HWFRBXg1sUh,SIDG7cnzAaUpkwmNde19ZsBqQ3Hh,qFRrj7ayBKbOsHGSXz
r6juULGQtnExAko38BZ5Y,NNmirJKPp5nWjfC,FeyZbj8tDil0nSHzTwfsUJ9=zxwIDBrPiXjKlsYkfg0AGaUZSyW2co,CIcPowhneWs5tN3,smpniPDOhfwI3H4v7c6TG
S26SnaqcM9XwK8PVphJDv5,CgPbwXm1RilpJUSGHLhy,NxsKJnLFEZ9OHXf1h=FeyZbj8tDil0nSHzTwfsUJ9,NNmirJKPp5nWjfC,r6juULGQtnExAko38BZ5Y
Kwl07iYTtDLN3zP,uAl3gHavMJZL4xmNe62nDiBoQ,ta478EuZQJIWhgBnsf6iU=NxsKJnLFEZ9OHXf1h,CgPbwXm1RilpJUSGHLhy,S26SnaqcM9XwK8PVphJDv5
EAw9bg4rT3Bd8tjSkO,ItgK5FqGDz2Rf7mAJkbT,FFVuCHLxhZmkEGJQDitreaygc2f4AS=ta478EuZQJIWhgBnsf6iU,uAl3gHavMJZL4xmNe62nDiBoQ,Kwl07iYTtDLN3zP
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = smpniPDOhfwI3H4v7c6TG(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
Yc0eBRLpbCkm4gK7OqyzuHwU = QmoEjB3hLIw(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
yOxvakdzi5EPC = K3hFytImeYMkJBC.path.join(URY8OguPqdXfkFB1oWiaGr,tOdiG2HWFRBXg1sUh(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
yzBoLjwENd2t7qiF = K3hFytImeYMkJBC.path.join(URY8OguPqdXfkFB1oWiaGr,dEUYJjrhsaPXNo(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
RcMypj5Cr1TEVfi = K3hFytImeYMkJBC.path.join(qKHs0b1SC2v3EZ9xfOluQ,zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
yc5K08JA9fmPbEQTCzeBUWg = tEA4o6NZmLDR15XjHW
qYex5Llt4hXyW2dGk = Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
eqxzrcsOhiBJZ = smpniPDOhfwI3H4v7c6TG(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
D8PXilyeW9 = wx18CTJPZ5(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
nJsHdSgUyaWOpTQ49IZb = wx18CTJPZ5(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
UHRdW9DjhOXg2Gva7 = I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
qHnb3z6vI8gE5U0uFyQcmTBKGMDf9P = ta478EuZQJIWhgBnsf6iU(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
def HgQCVwFx2Br(mode):
	if   n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==Gk98CL5nXZEN(u"࠹࠷࠴ࣉ"): s4Bng5iAZQSTtpDw9 = G6mpBlQ0sziJ4yI7WMDZXvcOwN5t1()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==CgPbwXm1RilpJUSGHLhy(u"࠺࠸࠶࣊"): s4Bng5iAZQSTtpDw9 = oFHcGJSy62KieOMmZv4f0l(yOxvakdzi5EPC,NxsKJnLFEZ9OHXf1h(u"ࡖࡵࡹࡪࣳ"),NxsKJnLFEZ9OHXf1h(u"ࡖࡵࡹࡪࣳ"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==ItgK5FqGDz2Rf7mAJkbT(u"࠻࠹࠸࣋"): s4Bng5iAZQSTtpDw9 = oFHcGJSy62KieOMmZv4f0l(yzBoLjwENd2t7qiF,I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࡗࡶࡺ࡫ࣴ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࡗࡶࡺ࡫ࣴ"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠼࠺࠳࣌"): s4Bng5iAZQSTtpDw9 = oFHcGJSy62KieOMmZv4f0l(RcMypj5Cr1TEVfi,NNmirJKPp5nWjfC(u"ࡋࡧ࡬ࡴࡧࣶ"),CgPbwXm1RilpJUSGHLhy(u"ࡘࡷࡻࡥࣵ"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==GGCQK6OAtZUXRhvkgJm(u"࠽࠴࠵࣍"): s4Bng5iAZQSTtpDw9 = sJo5I4fgnmk(yc5K08JA9fmPbEQTCzeBUWg,MM564HfnUV0XIR(u"࡚ࡲࡶࡧࣷ"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==Kwl07iYTtDLN3zP(u"࠷࠵࠷࣎"): s4Bng5iAZQSTtpDw9 = Jo2KUpIhrVHRTvOe(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࡔࡳࡷࡨࣸ"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==dEUYJjrhsaPXNo(u"࠸࠷࠳࣏"): s4Bng5iAZQSTtpDw9 = iVNfgzEDl92()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠹࠸࠵࣐"): s4Bng5iAZQSTtpDw9 = oFHcGJSy62KieOMmZv4f0l(qYex5Llt4hXyW2dGk,ta478EuZQJIWhgBnsf6iU(u"ࡈࡤࡰࡸ࡫ࣺ"),NNmirJKPp5nWjfC(u"ࡕࡴࡸࡩࣹ"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠺࠹࠷࣑"): s4Bng5iAZQSTtpDw9 = oFHcGJSy62KieOMmZv4f0l(eqxzrcsOhiBJZ,FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࡊࡦࡲࡳࡦࣼ"),dEUYJjrhsaPXNo(u"ࡗࡶࡺ࡫ࣻ"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==ItgK5FqGDz2Rf7mAJkbT(u"࠻࠺࠹࣒"): s4Bng5iAZQSTtpDw9 = oFHcGJSy62KieOMmZv4f0l(D8PXilyeW9,Kwl07iYTtDLN3zP(u"ࡌࡡ࡭ࡵࡨࣾ"),Kwl07iYTtDLN3zP(u"࡙ࡸࡵࡦࣽ"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==ItgK5FqGDz2Rf7mAJkbT(u"࠼࠻࠴࣓"): s4Bng5iAZQSTtpDw9 = oFHcGJSy62KieOMmZv4f0l(nJsHdSgUyaWOpTQ49IZb,CgPbwXm1RilpJUSGHLhy(u"ࡇࡣ࡯ࡷࡪऀ"),dEUYJjrhsaPXNo(u"ࡔࡳࡷࡨࣿ"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==GGCQK6OAtZUXRhvkgJm(u"࠽࠵࠶ࣔ"): s4Bng5iAZQSTtpDw9 = oFHcGJSy62KieOMmZv4f0l(UHRdW9DjhOXg2Gva7,wx18CTJPZ5(u"ࡉࡥࡱࡹࡥं"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࡖࡵࡹࡪँ"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==NNmirJKPp5nWjfC(u"࠷࠶࠸ࣕ"): s4Bng5iAZQSTtpDw9 = oFHcGJSy62KieOMmZv4f0l(qHnb3z6vI8gE5U0uFyQcmTBKGMDf9P,uAl3gHavMJZL4xmNe62nDiBoQ(u"ࡋࡧ࡬ࡴࡧऄ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࡘࡷࡻࡥः"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==r6juULGQtnExAko38BZ5Y(u"࠸࠷࠺ࣖ"): s4Bng5iAZQSTtpDw9 = aPHUvmxZnjG(NxsKJnLFEZ9OHXf1h(u"࡚ࡲࡶࡧअ"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠹࠸࠼ࣗ"): s4Bng5iAZQSTtpDw9 = rqFTlPIOSh3xVnoKuWzg0e2M19Z8wC()
	else: s4Bng5iAZQSTtpDw9 = bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࡆࡢ࡮ࡶࡩआ")
	return s4Bng5iAZQSTtpDw9
def G6mpBlQ0sziJ4yI7WMDZXvcOwN5t1():
	pihb9G36lWqmOnS2eIPHcwuC7FJN,Q5vj6sJXBRNUeig7F = hlE1gLuaSWzRYj2(yOxvakdzi5EPC)
	FGRehpaf4gPjTy2UtSw3WQz7MJ5q8u,LBVbNjJdYz18XKICRsAliSu2Ta5gEF = hlE1gLuaSWzRYj2(yzBoLjwENd2t7qiF)
	XsDvN92mBEq,X6y8hVTAPOf30E = hlE1gLuaSWzRYj2(RcMypj5Cr1TEVfi)
	nnE84jAb32czGfTO5FJ1sk,XU2lyZ0cqM5YxkeP4bIh7pSQj = Jy1ZPox93TVNYnKLzHvka(yc5K08JA9fmPbEQTCzeBUWg)
	nnE84jAb32czGfTO5FJ1sk -= CIcPowhneWs5tN3(u"࠶࠺࠽࠼࠴ࣘ")
	XU2lyZ0cqM5YxkeP4bIh7pSQj -= CgPbwXm1RilpJUSGHLhy(u"࠵ࣙ")
	LL3z8KnCGTFi7lAVaIBvEZMc = bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠩࠣࠬࠬࠌ")+fgLwAQMoiS9ztyK5xIpFV7j41Chc2D(pihb9G36lWqmOnS2eIPHcwuC7FJN)+uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠪࠤ࠲ࠦࠧࠍ")+str(Q5vj6sJXBRNUeig7F)+Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠎ")
	qum4VoYNQsc21iMZ76LzRtp = Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠬࠦࠨࠨࠏ")+fgLwAQMoiS9ztyK5xIpFV7j41Chc2D(FGRehpaf4gPjTy2UtSw3WQz7MJ5q8u)+NxsKJnLFEZ9OHXf1h(u"࠭ࠠ࠮ࠢࠪࠐ")+str(LBVbNjJdYz18XKICRsAliSu2Ta5gEF)+WbM6qAjrn7fEXGZw(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠑ")
	nNFHSrwfEmU9PIKbx = NNmirJKPp5nWjfC(u"ࠨࠢࠫࠫࠒ")+fgLwAQMoiS9ztyK5xIpFV7j41Chc2D(XsDvN92mBEq)+YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠩࠣ࠱ࠥ࠭ࠓ")+str(X6y8hVTAPOf30E)+Kwl07iYTtDLN3zP(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠔ")
	y8pGgqb4tBYShJL = I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠫࠥ࠮ࠧࠕ")+fgLwAQMoiS9ztyK5xIpFV7j41Chc2D(nnE84jAb32czGfTO5FJ1sk)+tOdiG2HWFRBXg1sUh(u"ࠬ࠯ࠧࠖ")
	cqJU1Ywk4I = pihb9G36lWqmOnS2eIPHcwuC7FJN+FGRehpaf4gPjTy2UtSw3WQz7MJ5q8u+XsDvN92mBEq+nnE84jAb32czGfTO5FJ1sk
	R4oBgUCylG6aZKI5DxncdN1bLqTHSw = Q5vj6sJXBRNUeig7F+LBVbNjJdYz18XKICRsAliSu2Ta5gEF+X6y8hVTAPOf30E+XU2lyZ0cqM5YxkeP4bIh7pSQj
	RxgdTHfDar8EXt = cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠭ࠠࠩࠩࠗ")+fgLwAQMoiS9ztyK5xIpFV7j41Chc2D(cqJU1Ywk4I)+qFRrj7ayBKbOsHGSXz(u"ࠧࠡ࠯ࠣࠫ࠘")+str(R4oBgUCylG6aZKI5DxncdN1bLqTHSw)+NNmirJKPp5nWjfC(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠙")
	tBq8fTGUWJY9zvbgXD0EAloPO(MM564HfnUV0XIR(u"ࠩ࡯࡭ࡳࡱࠧࠚ"),Yc0eBRLpbCkm4gK7OqyzuHwU+FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࠛ")+RxgdTHfDar8EXt,tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠫࠬࠜ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠼࠺࠵ࣚ"))
	tBq8fTGUWJY9zvbgXD0EAloPO(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠬࡲࡩ࡯࡭ࠪࠝ"),CIcPowhneWs5tN3(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨࠞ"),QmoEjB3hLIw(u"ࠧࠨࠟ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠿࠹࠺࠻ࣛ"))
	tBq8fTGUWJY9zvbgXD0EAloPO(GGCQK6OAtZUXRhvkgJm(u"ࠨ࡮࡬ࡲࡰ࠭ࠠ"),Yc0eBRLpbCkm4gK7OqyzuHwU+S26SnaqcM9XwK8PVphJDv5(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠨࠡ")+LL3z8KnCGTFi7lAVaIBvEZMc,CIcPowhneWs5tN3(u"ࠪࠫࠢ"),FeyZbj8tDil0nSHzTwfsUJ9(u"࠷࠵࠳ࣜ"))
	tBq8fTGUWJY9zvbgXD0EAloPO(S26SnaqcM9XwK8PVphJDv5(u"ࠫࡱ࡯࡮࡬ࠩࠣ"),Yc0eBRLpbCkm4gK7OqyzuHwU+SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"๋ࠬำฮࠢส่๊๊แศฬࠣห้๋ึ฻ฺ๊อࠬࠤ")+qum4VoYNQsc21iMZ76LzRtp,YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠭ࠧࠥ"),CIcPowhneWs5tN3(u"࠸࠶࠵ࣝ"))
	tBq8fTGUWJY9zvbgXD0EAloPO(FeyZbj8tDil0nSHzTwfsUJ9(u"ࠧ࡭࡫ࡱ࡯ࠬࠦ"),Yc0eBRLpbCkm4gK7OqyzuHwU+tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠨ็ึัࠥอไึ๊ิࠤฬ๊โะ์่อࠬࠧ")+nNFHSrwfEmU9PIKbx,ta478EuZQJIWhgBnsf6iU(u"ࠩࠪࠨ"),Gk98CL5nXZEN(u"࠹࠷࠷ࣞ"))
	tBq8fTGUWJY9zvbgXD0EAloPO(uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠪࡰ࡮ࡴ࡫ࠨࠩ"),Yc0eBRLpbCkm4gK7OqyzuHwU+uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠫฯ็ั๋฼้้ࠣ็ࠠึ๊ิࠤฬ๊ลืษไหฯ࠭ࠪ")+y8pGgqb4tBYShJL,ItgK5FqGDz2Rf7mAJkbT(u"ࠬ࠭ࠫ"),FeyZbj8tDil0nSHzTwfsUJ9(u"࠺࠸࠹ࣟ"))
	if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(bbqAtUz36RPGVTvCkejpJXQB(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࠬ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠧࠨ࠭"))
	return
def iVNfgzEDl92():
	oVRbBYPFKxc75fOEqIpiZynCzd6w = tOdiG2HWFRBXg1sUh(u"ࡖࡵࡹࡪई") if Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠨ࠱ࠪ࠮") in qKHs0b1SC2v3EZ9xfOluQ else ta478EuZQJIWhgBnsf6iU(u"ࡇࡣ࡯ࡷࡪइ")
	if not oVRbBYPFKxc75fOEqIpiZynCzd6w:
		tehb3k5a2PufGOdBIUw8j(Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠩࠪ࠯"),Gk98CL5nXZEN(u"ࠪࠫ࠰"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ࠱"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠬ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣห้า็ศิ้ࠣฯ๎แาหࠣๅ็฽ࠠๅลฯ๋ืฯ๋๊้ࠠ็ุࠦ࠮࠯๋ࠢะ์อาไࠢ็๎ุࠦๅ็้ࠢ์฾๊้่ࠦๆืࠬ࠲"))
		return
	DzRqxnIrNLUgj4PYXFkZJc = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪ࠳"))
	if not DzRqxnIrNLUgj4PYXFkZJc: rqFTlPIOSh3xVnoKuWzg0e2M19Z8wC()
	pihb9G36lWqmOnS2eIPHcwuC7FJN,Q5vj6sJXBRNUeig7F = hlE1gLuaSWzRYj2(qYex5Llt4hXyW2dGk)
	FGRehpaf4gPjTy2UtSw3WQz7MJ5q8u,LBVbNjJdYz18XKICRsAliSu2Ta5gEF = hlE1gLuaSWzRYj2(eqxzrcsOhiBJZ)
	XsDvN92mBEq,X6y8hVTAPOf30E = hlE1gLuaSWzRYj2(D8PXilyeW9)
	nnE84jAb32czGfTO5FJ1sk,XU2lyZ0cqM5YxkeP4bIh7pSQj = hlE1gLuaSWzRYj2(nJsHdSgUyaWOpTQ49IZb)
	GFnutsEfvymW9Q0wLz5A,LgeItmZdE3MC0NDUwvQ6PX = hlE1gLuaSWzRYj2(UHRdW9DjhOXg2Gva7)
	ggqOT0AoVWfir,y6HXJj9eZdpCOV08h = hlE1gLuaSWzRYj2(qHnb3z6vI8gE5U0uFyQcmTBKGMDf9P)
	LL3z8KnCGTFi7lAVaIBvEZMc = tOdiG2HWFRBXg1sUh(u"ࠧࠡࠪࠪ࠴")+fgLwAQMoiS9ztyK5xIpFV7j41Chc2D(pihb9G36lWqmOnS2eIPHcwuC7FJN)+tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠨࠢ࠰ࠤࠬ࠵")+str(Q5vj6sJXBRNUeig7F)+I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪ࠶")
	qum4VoYNQsc21iMZ76LzRtp = zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠪࠤ࠭࠭࠷")+fgLwAQMoiS9ztyK5xIpFV7j41Chc2D(FGRehpaf4gPjTy2UtSw3WQz7MJ5q8u)+CgPbwXm1RilpJUSGHLhy(u"ࠫࠥ࠳ࠠࠨ࠸")+str(LBVbNjJdYz18XKICRsAliSu2Ta5gEF)+I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭࠹")
	nNFHSrwfEmU9PIKbx = Ox8k6IdtuPaG3NlApQK52oYwM(u"࠭ࠠࠩࠩ࠺")+fgLwAQMoiS9ztyK5xIpFV7j41Chc2D(XsDvN92mBEq)+CIcPowhneWs5tN3(u"ࠧࠡ࠯ࠣࠫ࠻")+str(X6y8hVTAPOf30E)+EAw9bg4rT3Bd8tjSkO(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠼")
	y8pGgqb4tBYShJL = S26SnaqcM9XwK8PVphJDv5(u"ࠩࠣࠬࠬ࠽")+fgLwAQMoiS9ztyK5xIpFV7j41Chc2D(nnE84jAb32czGfTO5FJ1sk)+SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠪࠤ࠲ࠦࠧ࠾")+str(XU2lyZ0cqM5YxkeP4bIh7pSQj)+Gk98CL5nXZEN(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬ࠿")
	qmpCanPzljkWFwL3rO = YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠬࠦࠨࠨࡀ")+fgLwAQMoiS9ztyK5xIpFV7j41Chc2D(GFnutsEfvymW9Q0wLz5A)+FeyZbj8tDil0nSHzTwfsUJ9(u"࠭ࠠ࠮ࠢࠪࡁ")+str(LgeItmZdE3MC0NDUwvQ6PX)+qFRrj7ayBKbOsHGSXz(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࡂ")
	NjfsMwSKdZ4l8hDoGFbEJ3egtX9r = dEUYJjrhsaPXNo(u"ࠨࠢࠫࠫࡃ")+fgLwAQMoiS9ztyK5xIpFV7j41Chc2D(ggqOT0AoVWfir)+Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠩࠣ࠱ࠥ࠭ࡄ")+str(y6HXJj9eZdpCOV08h)+GGCQK6OAtZUXRhvkgJm(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡅ")
	cqJU1Ywk4I = pihb9G36lWqmOnS2eIPHcwuC7FJN+FGRehpaf4gPjTy2UtSw3WQz7MJ5q8u+XsDvN92mBEq+nnE84jAb32czGfTO5FJ1sk+GFnutsEfvymW9Q0wLz5A+ggqOT0AoVWfir
	R4oBgUCylG6aZKI5DxncdN1bLqTHSw = Q5vj6sJXBRNUeig7F+LBVbNjJdYz18XKICRsAliSu2Ta5gEF+X6y8hVTAPOf30E+XU2lyZ0cqM5YxkeP4bIh7pSQj+LgeItmZdE3MC0NDUwvQ6PX+y6HXJj9eZdpCOV08h
	RxgdTHfDar8EXt = GGCQK6OAtZUXRhvkgJm(u"ࠫࠥ࠮ࠧࡆ")+fgLwAQMoiS9ztyK5xIpFV7j41Chc2D(cqJU1Ywk4I)+dEUYJjrhsaPXNo(u"ࠬࠦ࠭ࠡࠩࡇ")+str(R4oBgUCylG6aZKI5DxncdN1bLqTHSw)+smpniPDOhfwI3H4v7c6TG(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࡈ")
	tBq8fTGUWJY9zvbgXD0EAloPO(NxsKJnLFEZ9OHXf1h(u"ࠧ࡭࡫ࡱ࡯ࠬࡉ"),Yc0eBRLpbCkm4gK7OqyzuHwU+YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠨว฼฻ฬวࠠาะุอ่ࠥัศรฬࠤํ้สศสฬࠫࡊ"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࠩࠪࡋ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠻࠺࠾࣠"))
	tBq8fTGUWJY9zvbgXD0EAloPO(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠪࡰ࡮ࡴ࡫ࠨࡌ"),Yc0eBRLpbCkm4gK7OqyzuHwU+dEUYJjrhsaPXNo(u"ู๊ࠫอࠡษ็ะ๊๐ูࠨࡍ")+RxgdTHfDar8EXt,dEUYJjrhsaPXNo(u"ࠬ࠭ࡎ"),MM564HfnUV0XIR(u"࠼࠻࠷࣡"))
	tBq8fTGUWJY9zvbgXD0EAloPO(QmoEjB3hLIw(u"࠭࡬ࡪࡰ࡮ࠫࡏ"),tOdiG2HWFRBXg1sUh(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࡐ"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠨࠩࡑ"),qFRrj7ayBKbOsHGSXz(u"࠿࠹࠺࠻࣢"))
	tBq8fTGUWJY9zvbgXD0EAloPO(I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠩ࡯࡭ࡳࡱࠧࡒ"),Yc0eBRLpbCkm4gK7OqyzuHwU+bbqAtUz36RPGVTvCkejpJXQB(u"ุ้ࠪำࠠๆๆไหฯࠦࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠪࡓ")+LL3z8KnCGTFi7lAVaIBvEZMc,FeyZbj8tDil0nSHzTwfsUJ9(u"ࠫࠬࡔ"),ItgK5FqGDz2Rf7mAJkbT(u"࠷࠶࠳ࣣ"))
	tBq8fTGUWJY9zvbgXD0EAloPO(bbqAtUz36RPGVTvCkejpJXQB(u"ࠬࡲࡩ࡯࡭ࠪࡕ"),Yc0eBRLpbCkm4gK7OqyzuHwU+dEUYJjrhsaPXNo(u"࠭ๅิฯ้้ࠣ็วหࠢࡧࡶࡴࡶࡢࡰࡺࠪࡖ")+qum4VoYNQsc21iMZ76LzRtp,dEUYJjrhsaPXNo(u"ࠧࠨࡗ"),smpniPDOhfwI3H4v7c6TG(u"࠸࠷࠵ࣤ"))
	tBq8fTGUWJY9zvbgXD0EAloPO(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠨ࡮࡬ࡲࡰ࠭ࡘ"),Yc0eBRLpbCkm4gK7OqyzuHwU+bbqAtUz36RPGVTvCkejpJXQB(u"่ࠩืาࠦๅๅใสฮࠥࡺ࡯࡮ࡤࡶࡸࡴࡴࡥࡴ࡙ࠩ")+nNFHSrwfEmU9PIKbx,S26SnaqcM9XwK8PVphJDv5(u"࡚ࠪࠫ"),MM564HfnUV0XIR(u"࠹࠸࠷ࣥ"))
	tBq8fTGUWJY9zvbgXD0EAloPO(WbM6qAjrn7fEXGZw(u"ࠫࡱ࡯࡮࡬࡛ࠩ"),Yc0eBRLpbCkm4gK7OqyzuHwU+GGCQK6OAtZUXRhvkgJm(u"๋ࠬำฮ่่ࠢๆอสࠡ࡮ࡲ࡫࡬࡫ࡲࠨ࡜")+y8pGgqb4tBYShJL,qFRrj7ayBKbOsHGSXz(u"࠭ࠧ࡝"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠺࠹࠹ࣦ"))
	tBq8fTGUWJY9zvbgXD0EAloPO(smpniPDOhfwI3H4v7c6TG(u"ࠧ࡭࡫ࡱ࡯ࠬ࡞"),Yc0eBRLpbCkm4gK7OqyzuHwU+wx18CTJPZ5(u"ࠨ็ึั๋ࠥไโษอࠤࡱࡵࡧࠨ࡟")+qmpCanPzljkWFwL3rO,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠩࠪࡠ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠻࠺࠻ࣧ"))
	tBq8fTGUWJY9zvbgXD0EAloPO(NxsKJnLFEZ9OHXf1h(u"ࠪࡰ࡮ࡴ࡫ࠨࡡ"),Yc0eBRLpbCkm4gK7OqyzuHwU+GGCQK6OAtZUXRhvkgJm(u"ู๊ࠫอࠡ็็ๅฬะࠠࡢࡰࡵࠫࡢ")+NjfsMwSKdZ4l8hDoGFbEJ3egtX9r,YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠬ࠭ࡣ"),Kwl07iYTtDLN3zP(u"࠼࠻࠶ࣨ"))
	if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(qFRrj7ayBKbOsHGSXz(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࡤ"),WbM6qAjrn7fEXGZw(u"ࠧࠨࡥ"))
	return
def rqFTlPIOSh3xVnoKuWzg0e2M19Z8wC():
	A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠨࠩࡦ"),Gk98CL5nXZEN(u"ࠩࠪࡧ"),smpniPDOhfwI3H4v7c6TG(u"ࠪࠫࡨ"),CIcPowhneWs5tN3(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࡩ"),tOdiG2HWFRBXg1sUh(u"๊ࠬใ๋ࠢํ฽๊๊ࠠศๆอ๊฽๐แࠡ฻้ำ่ࠦ࠮࠯ࠢหี๋อๅอࠢ฼้ฬีࠠษฯสะฮࠦลๅ๋ࠣษ฾฽วยࠢิาฺฯࠠศๆๅีฬวษ๊ࠡส่่ะวษห่้๋ࠣไโษอࠤํอไๆฮ็ำฬะࠠศๆอ๎ู่ࠥโࠢํุ้ำ็ศࠢส่อืๆศ็ฯࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡว฼฻ฬว่ࠠา๊ࠤฬ๊ัฯืฬࠤฬ๊ย็ࠢยࠥࠬࡪ"))
	if A5vgi1F6qVunZMas2Nf==-SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠷ࣩ"): return
	if A5vgi1F6qVunZMas2Nf:
		import subprocess as Pe6zIpfdbTRDFJlVojc4a
		try:
			Pe6zIpfdbTRDFJlVojc4a.Popen(I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠭ࡳࡶࠩ࡫"))
			hd7D8UlQbzGXagwYuv02kR9 = GGCQK6OAtZUXRhvkgJm(u"ࡗࡶࡺ࡫उ")
		except: hd7D8UlQbzGXagwYuv02kR9 = ItgK5FqGDz2Rf7mAJkbT(u"ࡊࡦࡲࡳࡦऊ")
		if hd7D8UlQbzGXagwYuv02kR9:
			r9WXd08IaBxNvZYh4MAUPtfq1b65p = qYex5Llt4hXyW2dGk+bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠧࠡࠩ࡬")+eqxzrcsOhiBJZ+I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠨࠢࠪ࡭")+D8PXilyeW9+YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠩࠣࠫ࡮")+nJsHdSgUyaWOpTQ49IZb+QmoEjB3hLIw(u"ࠪࠤࠬ࡯")+UHRdW9DjhOXg2Gva7+NxsKJnLFEZ9OHXf1h(u"ࠫࠥ࠭ࡰ")+qHnb3z6vI8gE5U0uFyQcmTBKGMDf9P
			Qv529fH4UMK3sTekRuOrXpqchN = Pe6zIpfdbTRDFJlVojc4a.Popen(CgPbwXm1RilpJUSGHLhy(u"ࠬࡹࡵࠡ࠯ࡦࠤࠧࡩࡨ࡮ࡱࡧࠤ࠲ࡘࠠ࠱࠹࠺࠻ࠥ࠭ࡱ")+r9WXd08IaBxNvZYh4MAUPtfq1b65p+cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠭ࠢࠨࡲ"),shell=FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࡙ࡸࡵࡦऋ"),stdin=Pe6zIpfdbTRDFJlVojc4a.PIPE,stdout=Pe6zIpfdbTRDFJlVojc4a.PIPE,stderr=Pe6zIpfdbTRDFJlVojc4a.PIPE)
			tehb3k5a2PufGOdBIUw8j(smpniPDOhfwI3H4v7c6TG(u"ࠧࠨࡳ"),Gk98CL5nXZEN(u"ࠨࠩࡴ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡵ"),S26SnaqcM9XwK8PVphJDv5(u"๊ࠪัำสࠡ฻่่๏ฯࠠฦ฻ฺหฦࠦวๅำัูฮ࠭ࡶ"))
			if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨࡷ"),ItgK5FqGDz2Rf7mAJkbT(u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨࡸ"))
			oos8ymFi9CN2z1jXcR.executebuiltin(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪࡹ"))
		else: tehb3k5a2PufGOdBIUw8j(ta478EuZQJIWhgBnsf6iU(u"ࠧࠨࡺ"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠨࠩࡻ"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡼ"),ta478EuZQJIWhgBnsf6iU(u"ࠪ฽๊๊๊สࠢศ฽฼อมࠡำัูฮࠦวๅไิหฦฯ้ࠠษ็็ฯอศสࠢอัฯอฬࠡสิ๊ฬ๋ฬࠡࠢࡵࡳࡴࡺࠠࠡล๋ࠤࠥࡹࡵࡱࡧࡵࡹࡸ࡫ࡲࠡࠢฦ์ࠥࠦࡳࡶࠢࠣ์ัํวำๅ่ࠣฬ๊้ࠦฮาࠤๆ๐็้ࠡำหࠥอไษำ้ห๊าࠠ࠯࠰ࠣวํࠦใ้ัํࠤ฿๐ัࠡไสำึูࠦๅ๋ࠣหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠪࡽ"))
	return
def fgLwAQMoiS9ztyK5xIpFV7j41Chc2D(cqJU1Ywk4I):
	for xSNvyd0iTLFe5BVs in [WbM6qAjrn7fEXGZw(u"ࠫࡇ࠭ࡾ"),smpniPDOhfwI3H4v7c6TG(u"ࠬࡑࡂࠨࡿ"),Ox8k6IdtuPaG3NlApQK52oYwM(u"࠭ࡍࡃࠩࢀ"),QmoEjB3hLIw(u"ࠧࡈࡄࠪࢁ"),wx18CTJPZ5(u"ࠨࡖࡅࠫࢂ")]:
		if cqJU1Ywk4I<NxsKJnLFEZ9OHXf1h(u"࠱࠱࠴࠷࣪"): break
		else: cqJU1Ywk4I /= SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠲࠲࠵࠸࠳࠶࣫")
	RxgdTHfDar8EXt = S26SnaqcM9XwK8PVphJDv5(u"ࠤࠨ࠷࠳࠷ࡦࠡࠧࡶࠦࢃ")%(cqJU1Ywk4I,xSNvyd0iTLFe5BVs)
	return RxgdTHfDar8EXt
def hlE1gLuaSWzRYj2(uQjEBKRZ42AhYy6MFPS5tqrVx=dEUYJjrhsaPXNo(u"ࠪ࠲ࠬࢄ")):
	global xBH9ryCZDjidkuT7FbWaQecM6,UZ7FfVqrujTA4O91GvxhXE6
	xBH9ryCZDjidkuT7FbWaQecM6,UZ7FfVqrujTA4O91GvxhXE6 = bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠲࣬"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠲࣬")
	def TSLCPxena2WMigd(uQjEBKRZ42AhYy6MFPS5tqrVx):
		global xBH9ryCZDjidkuT7FbWaQecM6,UZ7FfVqrujTA4O91GvxhXE6
		if K3hFytImeYMkJBC.path.exists(uQjEBKRZ42AhYy6MFPS5tqrVx):
			if qFRrj7ayBKbOsHGSXz(u"࠳࣭") and zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠫࡸࡩࡡ࡯ࡦ࡬ࡶࠬࢅ") in dir(K3hFytImeYMkJBC):
				for z7lp3aMYG1yu0bhmtnv4 in K3hFytImeYMkJBC.scandir(uQjEBKRZ42AhYy6MFPS5tqrVx):
					if z7lp3aMYG1yu0bhmtnv4.is_dir(follow_symlinks=MM564HfnUV0XIR(u"ࡌࡡ࡭ࡵࡨऌ")):
						TSLCPxena2WMigd(z7lp3aMYG1yu0bhmtnv4.path)
					elif z7lp3aMYG1yu0bhmtnv4.is_file(follow_symlinks=dEUYJjrhsaPXNo(u"ࡆࡢ࡮ࡶࡩऍ")):
						xBH9ryCZDjidkuT7FbWaQecM6 += z7lp3aMYG1yu0bhmtnv4.stat().st_size
						UZ7FfVqrujTA4O91GvxhXE6 += ItgK5FqGDz2Rf7mAJkbT(u"࠵࣮")
			else:
				for z7lp3aMYG1yu0bhmtnv4 in K3hFytImeYMkJBC.listdir(uQjEBKRZ42AhYy6MFPS5tqrVx):
					RIWv8gqFNC36frUHQuM = K3hFytImeYMkJBC.path.abspath(K3hFytImeYMkJBC.path.join(uQjEBKRZ42AhYy6MFPS5tqrVx,z7lp3aMYG1yu0bhmtnv4))
					if K3hFytImeYMkJBC.path.isdir(RIWv8gqFNC36frUHQuM):
						TSLCPxena2WMigd(RIWv8gqFNC36frUHQuM)
					elif K3hFytImeYMkJBC.path.isfile(RIWv8gqFNC36frUHQuM):
						cqJU1Ywk4I,R4oBgUCylG6aZKI5DxncdN1bLqTHSw = Jy1ZPox93TVNYnKLzHvka(RIWv8gqFNC36frUHQuM)
						xBH9ryCZDjidkuT7FbWaQecM6 += cqJU1Ywk4I
						UZ7FfVqrujTA4O91GvxhXE6 += R4oBgUCylG6aZKI5DxncdN1bLqTHSw
		return
	try: TSLCPxena2WMigd(uQjEBKRZ42AhYy6MFPS5tqrVx)
	except: pass
	return xBH9ryCZDjidkuT7FbWaQecM6,UZ7FfVqrujTA4O91GvxhXE6
def YvqREialSFU5hLQOdZ0WpB(VRPA1LHZWy,showDialogs):
	if showDialogs:
		A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(FeyZbj8tDil0nSHzTwfsUJ9(u"ࠬ࠭ࢆ"),tOdiG2HWFRBXg1sUh(u"࠭ࠧࢇ"),CIcPowhneWs5tN3(u"ࠧࠨ࢈"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࢉ"),VRPA1LHZWy+wx18CTJPZ5(u"ࠩ࡟ࡲࡡࡴࠧࢊ")+YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่่ๆࠦฟࠢ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢋ"))
		if A5vgi1F6qVunZMas2Nf!=FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠶࣯"): return
	GWJuNcOgLiXjQ = smpniPDOhfwI3H4v7c6TG(u"ࡇࡣ࡯ࡷࡪऎ")
	if K3hFytImeYMkJBC.path.exists(VRPA1LHZWy):
		try: K3hFytImeYMkJBC.remove(VRPA1LHZWy)
		except Exception as a3beYJZdDr89to:
			if showDialogs: tehb3k5a2PufGOdBIUw8j(smpniPDOhfwI3H4v7c6TG(u"ࠫࠬࢌ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠬ࠭ࢍ"),WbM6qAjrn7fEXGZw(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢎ"),str(a3beYJZdDr89to))
			GWJuNcOgLiXjQ = NNmirJKPp5nWjfC(u"ࡖࡵࡹࡪए")
	if showDialogs and not GWJuNcOgLiXjQ:
		tehb3k5a2PufGOdBIUw8j(GGCQK6OAtZUXRhvkgJm(u"ࠧࠨ࢏"),CgPbwXm1RilpJUSGHLhy(u"ࠨࠩ࢐"),NxsKJnLFEZ9OHXf1h(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࢑"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫ࢒"))
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨ࢓"),ta478EuZQJIWhgBnsf6iU(u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨ࢔"))
		oos8ymFi9CN2z1jXcR.executebuiltin(Gk98CL5nXZEN(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ࢕"))
	return
def Jo2KUpIhrVHRTvOe(showDialogs):
	if showDialogs:
		A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠧࠨ࢖"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠨࠩࢗ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠩࠪ࢘"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࢙࠭"),MM564HfnUV0XIR(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ็ๅࠢอี๏ีࠠๆีะ࢚ࠫ")+bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠬࡢ࡮ࠨ࢛")+zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠭ๅอๆาࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮࠦ࠮࠯๋้ࠢั๊ฯࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠤ࠳࠴้ࠠ็ฯ่ิࠦวๅื๋ีࠥอไใัํ้ฮࠦ࠮࠯๋ࠢฮๆื๊฻่่ࠢๆࠦี้ำࠣห้หึศใสฮࠬ࢜")+wx18CTJPZ5(u"ࠧ࡝ࡰࠪ࢝")+Kwl07iYTtDLN3zP(u"ࠨมࠤࠥࠬ࢞")+QmoEjB3hLIw(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࢟"))
		if A5vgi1F6qVunZMas2Nf!=WbM6qAjrn7fEXGZw(u"࠷ࣰ"): return
	oFHcGJSy62KieOMmZv4f0l(yOxvakdzi5EPC,I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࡘࡷࡻࡥऑ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࡉࡥࡱࡹࡥऐ"))
	oFHcGJSy62KieOMmZv4f0l(yzBoLjwENd2t7qiF,tOdiG2HWFRBXg1sUh(u"࡚ࡲࡶࡧओ"),qFRrj7ayBKbOsHGSXz(u"ࡋࡧ࡬ࡴࡧऒ"))
	oFHcGJSy62KieOMmZv4f0l(RcMypj5Cr1TEVfi,Kwl07iYTtDLN3zP(u"ࡆࡢ࡮ࡶࡩऔ"),Kwl07iYTtDLN3zP(u"ࡆࡢ࡮ࡶࡩऔ"))
	sJo5I4fgnmk(yc5K08JA9fmPbEQTCzeBUWg,Ox8k6IdtuPaG3NlApQK52oYwM(u"ࡇࡣ࡯ࡷࡪक"))
	if showDialogs:
		tehb3k5a2PufGOdBIUw8j(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠪࠫࢠ"),qFRrj7ayBKbOsHGSXz(u"ࠫࠬࢡ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࢢ"),r6juULGQtnExAko38BZ5Y(u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧࢣ"))
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(tOdiG2HWFRBXg1sUh(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫࢤ"),Gk98CL5nXZEN(u"ࠨࡕࡒࡑࡊ࡚ࡈࡊࡐࡊࠫࢥ"))
		oos8ymFi9CN2z1jXcR.executebuiltin(bbqAtUz36RPGVTvCkejpJXQB(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭ࢦ"))
	return
def aPHUvmxZnjG(showDialogs):
	if showDialogs:
		A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(smpniPDOhfwI3H4v7c6TG(u"ࠪࠫࢧ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠫࠬࢨ"),Gk98CL5nXZEN(u"ࠬ࠭ࢩ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢪ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๊่ࠥะั๋ัุ้ࠣำࠠๆๆไหฯ࠭ࢫ")+Gk98CL5nXZEN(u"ࠨ࡞ࡱࠫࢬ")+NNmirJKPp5nWjfC(u"ࠩࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸࠦ࠮࠯ࠢࡧࡶࡴࡶࡢࡰࡺࠣ࠲࠳ࠦࡴࡰ࡯ࡥࡷࡹࡵ࡮ࡦࡵࠣ࠲࠳ࠦ࡬ࡰࡩࡪࡩࡷࠦ࠮࠯ࠢ࡯ࡳ࡬ࠦ࠮࠯ࠢࡤࡲࡷ࠭ࢭ")+dEUYJjrhsaPXNo(u"ࠪࡠࡳ࠭ࢮ")+WbM6qAjrn7fEXGZw(u"ࠫࡄࠧࠡࠨࢯ")+FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࢰ"))
		if A5vgi1F6qVunZMas2Nf!=YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠱ࣱ"): return
	oFHcGJSy62KieOMmZv4f0l(qYex5Llt4hXyW2dGk,FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࡈࡤࡰࡸ࡫ख"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࡈࡤࡰࡸ࡫ख"))
	oFHcGJSy62KieOMmZv4f0l(eqxzrcsOhiBJZ,FeyZbj8tDil0nSHzTwfsUJ9(u"ࡉࡥࡱࡹࡥग"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࡉࡥࡱࡹࡥग"))
	oFHcGJSy62KieOMmZv4f0l(D8PXilyeW9,FeyZbj8tDil0nSHzTwfsUJ9(u"ࡊࡦࡲࡳࡦघ"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࡊࡦࡲࡳࡦघ"))
	oFHcGJSy62KieOMmZv4f0l(nJsHdSgUyaWOpTQ49IZb,smpniPDOhfwI3H4v7c6TG(u"ࡋࡧ࡬ࡴࡧङ"),smpniPDOhfwI3H4v7c6TG(u"ࡋࡧ࡬ࡴࡧङ"))
	oFHcGJSy62KieOMmZv4f0l(UHRdW9DjhOXg2Gva7,QmoEjB3hLIw(u"ࡌࡡ࡭ࡵࡨच"),QmoEjB3hLIw(u"ࡌࡡ࡭ࡵࡨच"))
	oFHcGJSy62KieOMmZv4f0l(qHnb3z6vI8gE5U0uFyQcmTBKGMDf9P,WbM6qAjrn7fEXGZw(u"ࡆࡢ࡮ࡶࡩछ"),WbM6qAjrn7fEXGZw(u"ࡆࡢ࡮ࡶࡩछ"))
	if showDialogs:
		tehb3k5a2PufGOdBIUw8j(smpniPDOhfwI3H4v7c6TG(u"࠭ࠧࢱ"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࠧࠨࢲ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࢳ"),QmoEjB3hLIw(u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪࢴ"))
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(FeyZbj8tDil0nSHzTwfsUJ9(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧࢵ"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧࢶ"))
		oos8ymFi9CN2z1jXcR.executebuiltin(ta478EuZQJIWhgBnsf6iU(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩࢷ"))
	return
def sJo5I4fgnmk(AM9JTc4kHQBwve0Xh6i1,showDialogs):
	if showDialogs:
		A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(WbM6qAjrn7fEXGZw(u"࠭ࠧࢸ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠧࠨࢹ"),NNmirJKPp5nWjfC(u"ࠨࠩࢺ"),qFRrj7ayBKbOsHGSXz(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࢻ"),smpniPDOhfwI3H4v7c6TG(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ้ࠣาะ่๋ษอࠤ๊๊แࠡื๋ีࠥอไอๆาࠤฤࠧࠡࠨࢼ")+QmoEjB3hLIw(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࢽ"))
		if A5vgi1F6qVunZMas2Nf!=MM564HfnUV0XIR(u"࠲ࣲ"): return
	md59xZUEq3IOnPp2 = iZv4fPkF5Trx1L8EsVHC2S.connect(AM9JTc4kHQBwve0Xh6i1)
	md59xZUEq3IOnPp2.text_factory = str
	ngBDPjZshKvdX6 = md59xZUEq3IOnPp2.cursor()
	ngBDPjZshKvdX6.execute(QmoEjB3hLIw(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡴࡦࡺࡨ࠼ࠩࢾ"))
	ngBDPjZshKvdX6.execute(wx18CTJPZ5(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡸ࡯ࡺࡦࡵ࠾ࠫࢿ"))
	ngBDPjZshKvdX6.execute(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡺࡥࡹࡶࡸࡶࡪࡁࠧࣀ"))
	md59xZUEq3IOnPp2.commit()
	ngBDPjZshKvdX6.execute(qFRrj7ayBKbOsHGSXz(u"ࠨࡘࡄࡇ࡚࡛ࡍ࠼ࠩࣁ"))
	md59xZUEq3IOnPp2.close()
	if showDialogs:
		tehb3k5a2PufGOdBIUw8j(ItgK5FqGDz2Rf7mAJkbT(u"ࠩࠪࣂ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠪࠫࣃ"),NxsKJnLFEZ9OHXf1h(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࣄ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ࣅ"))
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(GGCQK6OAtZUXRhvkgJm(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࣆ"),CIcPowhneWs5tN3(u"ࠧࡔࡑࡐࡉ࡙ࡎࡉࡏࡉࠪࣇ"))
		oos8ymFi9CN2z1jXcR.executebuiltin(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬࣈ"))
	return
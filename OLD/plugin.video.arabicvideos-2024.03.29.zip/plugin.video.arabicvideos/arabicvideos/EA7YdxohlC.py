# -*- coding: utf-8 -*-
import sys as EAPND6zHKrMRuBc91tInYohsl0ywa
ttRJUcM0Tbr7gXN5x = EAPND6zHKrMRuBc91tInYohsl0ywa.version_info [0] == 2
Z2h7adALoKv4UPc1y = 2048
K2KPeD6VyEaQ = 7
def dC3HqaFgt6QYG4 (jZYXLbSUsQp5uk1tyzBAN7Hm):
	global ZeIJ6GDodMSzFut4jc05AK3OlhETR
	HY5UkLeNComBIMQPASnxph7 = ord (jZYXLbSUsQp5uk1tyzBAN7Hm [-1])
	PlVdbOK5hqks = jZYXLbSUsQp5uk1tyzBAN7Hm [:-1]
	prvC9qsF5RtBXHiaT3PwdJ = HY5UkLeNComBIMQPASnxph7 % len (PlVdbOK5hqks)
	LQB6POHcivdw87pk09ts2XMyf1IVEh = PlVdbOK5hqks [:prvC9qsF5RtBXHiaT3PwdJ] + PlVdbOK5hqks [prvC9qsF5RtBXHiaT3PwdJ:]
	if ttRJUcM0Tbr7gXN5x:
		Gn0XReKiJFMEsUxN531yAlI7S = unicode () .join ([unichr (ord (AitBMapzjZGc4u) - Z2h7adALoKv4UPc1y - (KQsX4n7jEogiLuJz + HY5UkLeNComBIMQPASnxph7) % K2KPeD6VyEaQ) for KQsX4n7jEogiLuJz, AitBMapzjZGc4u in enumerate (LQB6POHcivdw87pk09ts2XMyf1IVEh)])
	else:
		Gn0XReKiJFMEsUxN531yAlI7S = str () .join ([chr (ord (AitBMapzjZGc4u) - Z2h7adALoKv4UPc1y - (KQsX4n7jEogiLuJz + HY5UkLeNComBIMQPASnxph7) % K2KPeD6VyEaQ) for KQsX4n7jEogiLuJz, AitBMapzjZGc4u in enumerate (LQB6POHcivdw87pk09ts2XMyf1IVEh)])
	return eval (Gn0XReKiJFMEsUxN531yAlI7S)
I7N2lHpGfLPkwKxbOu6raYUgc5,QmoEjB3hLIw,WbM6qAjrn7fEXGZw=dC3HqaFgt6QYG4,dC3HqaFgt6QYG4,dC3HqaFgt6QYG4
bbqAtUz36RPGVTvCkejpJXQB,MM564HfnUV0XIR,YDC9i52g6e8XL7GxvIFnSKWsolpr=WbM6qAjrn7fEXGZw,QmoEjB3hLIw,I7N2lHpGfLPkwKxbOu6raYUgc5
YZFXwtrfK8uhzV4LlMEqgnCQyO9,tmcuvd397wjGXeWoDHMNpFB5h2VK,Ox8k6IdtuPaG3NlApQK52oYwM=YDC9i52g6e8XL7GxvIFnSKWsolpr,MM564HfnUV0XIR,bbqAtUz36RPGVTvCkejpJXQB
GGCQK6OAtZUXRhvkgJm,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6,Gk98CL5nXZEN=Ox8k6IdtuPaG3NlApQK52oYwM,tmcuvd397wjGXeWoDHMNpFB5h2VK,YZFXwtrfK8uhzV4LlMEqgnCQyO9
dEUYJjrhsaPXNo,wx18CTJPZ5,cWfQ64kVCqxhwvSy5P7irHI1oes3=Gk98CL5nXZEN,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6,GGCQK6OAtZUXRhvkgJm
qFRrj7ayBKbOsHGSXz,SIDG7cnzAaUpkwmNde19ZsBqQ3Hh,tOdiG2HWFRBXg1sUh=cWfQ64kVCqxhwvSy5P7irHI1oes3,wx18CTJPZ5,dEUYJjrhsaPXNo
smpniPDOhfwI3H4v7c6TG,CIcPowhneWs5tN3,zxwIDBrPiXjKlsYkfg0AGaUZSyW2co=tOdiG2HWFRBXg1sUh,SIDG7cnzAaUpkwmNde19ZsBqQ3Hh,qFRrj7ayBKbOsHGSXz
r6juULGQtnExAko38BZ5Y,NNmirJKPp5nWjfC,FeyZbj8tDil0nSHzTwfsUJ9=zxwIDBrPiXjKlsYkfg0AGaUZSyW2co,CIcPowhneWs5tN3,smpniPDOhfwI3H4v7c6TG
S26SnaqcM9XwK8PVphJDv5,CgPbwXm1RilpJUSGHLhy,NxsKJnLFEZ9OHXf1h=FeyZbj8tDil0nSHzTwfsUJ9,NNmirJKPp5nWjfC,r6juULGQtnExAko38BZ5Y
Kwl07iYTtDLN3zP,uAl3gHavMJZL4xmNe62nDiBoQ,ta478EuZQJIWhgBnsf6iU=NxsKJnLFEZ9OHXf1h,CgPbwXm1RilpJUSGHLhy,S26SnaqcM9XwK8PVphJDv5
EAw9bg4rT3Bd8tjSkO,ItgK5FqGDz2Rf7mAJkbT,FFVuCHLxhZmkEGJQDitreaygc2f4AS=ta478EuZQJIWhgBnsf6iU,uAl3gHavMJZL4xmNe62nDiBoQ,Kwl07iYTtDLN3zP
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = Gk98CL5nXZEN(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪज")
def HgQCVwFx2Br(n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,d7on6sKDqkNY):
	if   n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==WbM6qAjrn7fEXGZw(u"࠷࠸࠶৪"): s4Bng5iAZQSTtpDw9 = DX54iVP81EgyzRsm6r2Kd7()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==FeyZbj8tDil0nSHzTwfsUJ9(u"࠸࠹࠱৫"): s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(d7on6sKDqkNY)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==S26SnaqcM9XwK8PVphJDv5(u"࠹࠳࠳৬"): s4Bng5iAZQSTtpDw9 = aqOmBUFd51hXfw()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠳࠴࠵৭"): s4Bng5iAZQSTtpDw9 = xPEGrH6ozDMpJANLqjtiV0ZR9I()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==qFRrj7ayBKbOsHGSXz(u"࠴࠵࠷৮"): s4Bng5iAZQSTtpDw9 = YvqREialSFU5hLQOdZ0WpB(d7on6sKDqkNY)
	else: s4Bng5iAZQSTtpDw9 = CgPbwXm1RilpJUSGHLhy(u"ࡋࡧ࡬ࡴࡧਜ")
	return s4Bng5iAZQSTtpDw9
def YvqREialSFU5hLQOdZ0WpB(X7ka3EjJ9BDqgCrTYeU0xw4Z):
	try: K3hFytImeYMkJBC.remove(X7ka3EjJ9BDqgCrTYeU0xw4Z.decode(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠩࡸࡸ࡫࠾ࠧझ")))
	except: K3hFytImeYMkJBC.remove(X7ka3EjJ9BDqgCrTYeU0xw4Z)
	return
def dlropqS0vO9K7W4z(d7on6sKDqkNY):
	pSAuLjYqhgc9brWFKs7Pa4J(d7on6sKDqkNY,r1NChsk39OMvT82YemDQnl5,NxsKJnLFEZ9OHXf1h(u"ࠪࡺ࡮ࡪࡥࡰࠩञ"))
	return
def xPEGrH6ozDMpJANLqjtiV0ZR9I():
	maCNIYkc0HOiEGpL3g = WbM6qAjrn7fEXGZw(u"ࠫศึ็ษࠢศ่๎ࠦัศสฺࠤฬ๊แ๋ัํ์ࠥษ่ࠡษ็ูํะࠠโ์ࠣห้๋่ใ฻ࠣห้๋ืๅ๊หࠤะ๋ࠠฤุ฽฻ࠥ฿ไ๊ࠢีีࠥอไใษษ้ฮࠦวๅ์่๎๋ࠦหๆࠢฦาฯอัࠡࠤอั๊๐ไࠡ็็ๅฬะࠠโ์า๎ํࠨࠠฬ็ࠣหำะวาࠢาๆฮࠦวๅื๋ีฮ่ࠦศะอหึࠦๆ้฻้้ࠣ็ࠠศๆุ์ึฯ้ࠠส฼ำ์อࠠิ๊ไࠤ๏ฮฯฤࠢส่ฯำๅ๋ๆࠪट")
	tehb3k5a2PufGOdBIUw8j(ItgK5FqGDz2Rf7mAJkbT(u"ࠬ࠭ठ"),WbM6qAjrn7fEXGZw(u"࠭ࠧड"),r6juULGQtnExAko38BZ5Y(u"ุࠧำํๆฮࠦสฮ็ํ่ࠥอไๆๆไหฯ࠭ढ"),maCNIYkc0HOiEGpL3g)
	return
def DX54iVP81EgyzRsm6r2Kd7():
	tBq8fTGUWJY9zvbgXD0EAloPO(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠨ࡮࡬ࡲࡰ࠭ण"),CgPbwXm1RilpJUSGHLhy(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ฼ื๊ใหࠣฮา๋๊ๅ่่ࠢๆอสࠡษ็ๅ๏ี๊้࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪत"),tOdiG2HWFRBXg1sUh(u"ࠪࠫथ"),dEUYJjrhsaPXNo(u"࠵࠶࠷৯"))
	tBq8fTGUWJY9zvbgXD0EAloPO(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠫࡱ࡯࡮࡬ࠩद"),Kwl07iYTtDLN3zP(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ห฼ํ๎ึࠦๅไษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨध"),S26SnaqcM9XwK8PVphJDv5(u"࠭ࠧन"),bbqAtUz36RPGVTvCkejpJXQB(u"࠶࠷࠷ৰ"))
	tBq8fTGUWJY9zvbgXD0EAloPO(r6juULGQtnExAko38BZ5Y(u"ࠧ࡭࡫ࡱ࡯ࠬऩ"),S26SnaqcM9XwK8PVphJDv5(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪप"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠩࠪफ"),MM564HfnUV0XIR(u"࠽࠾࠿࠹ৱ"))
	BQunhYIH2Nj4gfPsxF69r7KTLXG = wgnefLPOZiXh1Jx468VuF()
	PMq9w36NKtTWFHJkaLbOh = K3hFytImeYMkJBC.stat(BQunhYIH2Nj4gfPsxF69r7KTLXG).st_mtime
	kgVoUd0vCNj = []
	if wvkR1es6d0SrjxKt5FZTMUWz7a: oeyhTAtU3xZ7d4fpsw8i = K3hFytImeYMkJBC.listdir(BQunhYIH2Nj4gfPsxF69r7KTLXG.encode(uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠪࡹࡹ࡬࠸ࠨब")))
	else: oeyhTAtU3xZ7d4fpsw8i = K3hFytImeYMkJBC.listdir(BQunhYIH2Nj4gfPsxF69r7KTLXG.decode(ItgK5FqGDz2Rf7mAJkbT(u"ࠫࡺࡺࡦ࠹ࠩभ")))
	for eqfixnjLl5h in oeyhTAtU3xZ7d4fpsw8i:
		if wvkR1es6d0SrjxKt5FZTMUWz7a: eqfixnjLl5h = eqfixnjLl5h.decode(QmoEjB3hLIw(u"ࠬࡻࡴࡧ࠺ࠪम"))
		if not eqfixnjLl5h.startswith(QmoEjB3hLIw(u"࠭ࡦࡪ࡮ࡨࡣࠬय")): continue
		ddBIr043oqg = K3hFytImeYMkJBC.path.join(BQunhYIH2Nj4gfPsxF69r7KTLXG,eqfixnjLl5h)
		PMq9w36NKtTWFHJkaLbOh = K3hFytImeYMkJBC.path.getmtime(ddBIr043oqg)
		kgVoUd0vCNj.append([eqfixnjLl5h,PMq9w36NKtTWFHJkaLbOh])
	kgVoUd0vCNj = sorted(kgVoUd0vCNj,reverse=zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࡚ࡲࡶࡧਝ"),key=lambda key: key[I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠶৲")])
	for eqfixnjLl5h,PMq9w36NKtTWFHJkaLbOh in kgVoUd0vCNj:
		if vciEXHThAPto76QIR2pK:
			try: eqfixnjLl5h = eqfixnjLl5h.decode(GGCQK6OAtZUXRhvkgJm(u"ࠧࡶࡶࡩ࠼ࠬर"))
			except: pass
			eqfixnjLl5h = eqfixnjLl5h.encode(Kwl07iYTtDLN3zP(u"ࠨࡷࡷࡪ࠽࠭ऱ"))
		ddBIr043oqg = K3hFytImeYMkJBC.path.join(BQunhYIH2Nj4gfPsxF69r7KTLXG,eqfixnjLl5h)
		tBq8fTGUWJY9zvbgXD0EAloPO(FeyZbj8tDil0nSHzTwfsUJ9(u"ࠩࡹ࡭ࡩ࡫࡯ࠨल"),eqfixnjLl5h,ddBIr043oqg,r6juULGQtnExAko38BZ5Y(u"࠹࠳࠲৳"))
	return
def wgnefLPOZiXh1Jx468VuF():
	BQunhYIH2Nj4gfPsxF69r7KTLXG = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(bbqAtUz36RPGVTvCkejpJXQB(u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭ळ"))
	if BQunhYIH2Nj4gfPsxF69r7KTLXG: return BQunhYIH2Nj4gfPsxF69r7KTLXG
	if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(wx18CTJPZ5(u"ࠫࡦࡼ࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧऴ"),llrbyaFHOt9e)
	return llrbyaFHOt9e
def aqOmBUFd51hXfw():
	BQunhYIH2Nj4gfPsxF69r7KTLXG = wgnefLPOZiXh1Jx468VuF()
	AANPGCuUeBtVh = eINt5FlUT0oO(S26SnaqcM9XwK8PVphJDv5(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬव"),tOdiG2HWFRBXg1sUh(u"࠭ࠧश"),qFRrj7ayBKbOsHGSXz(u"ࠧࠨष"),EAw9bg4rT3Bd8tjSkO(u"ࠨ็ๆห๋ࠦสฯิํ๊๋ࠥไโษอࠤฬ๊สฮ็ํ่ࠬस"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬह")+BQunhYIH2Nj4gfPsxF69r7KTLXG+CIcPowhneWs5tN3(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯้ำหࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮา๋ไ่ษࠣห๋ะࠠษษึฮำีวๆ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰๋้ࠣࠦสา์าࠤฯเ๊๋ำࠣห้๋ใศ่ࠣรࠬऺ"))
	if AANPGCuUeBtVh==I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠱৴"):
		DOm5CacoNA2i = Xco6Lu8qJF1lTyanQp3D(smpniPDOhfwI3H4v7c6TG(u"࠴৵"),ta478EuZQJIWhgBnsf6iU(u"๊้ࠫว็ࠢอั๊๐ไࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠨऻ"),S26SnaqcM9XwK8PVphJDv5(u"ࠬࡲ࡯ࡤࡣ࡯़ࠫ"),Gk98CL5nXZEN(u"࠭ࠧऽ"),QmoEjB3hLIw(u"ࡇࡣ࡯ࡷࡪਟ"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࡔࡳࡷࡨਞ"),BQunhYIH2Nj4gfPsxF69r7KTLXG)
		A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(FeyZbj8tDil0nSHzTwfsUJ9(u"ࠧࡤࡧࡱࡸࡪࡸࠧा"),EAw9bg4rT3Bd8tjSkO(u"ࠨࠩि"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠩࠪी"),CgPbwXm1RilpJUSGHLhy(u"้่ࠪอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅฬะ้๏๊ࠧु"),Gk98CL5nXZEN(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧू")+BQunhYIH2Nj4gfPsxF69r7KTLXG+wx18CTJPZ5(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱ๋ีอ่๊ࠠࠣห้๋ใศ่ࠣห้าฯ๋ั่ࠣฯิา๋่้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬะ้้ํวࠡษ้ฮࠥฮวิฬัำฬ๋่ࠠาสࠤฬ๊ศา่ส้ัࠦ࠮้ࠡ็ࠤฯื๊ะࠢสืฯิฯศ็๊ࠤอีไศ่๊ࠢࠥอไๆๅส๊ࠥอไใัํ้ࠥลࠧृ"))
		if A5vgi1F6qVunZMas2Nf==cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠳৶"):
			if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(bbqAtUz36RPGVTvCkejpJXQB(u"࠭ࡡࡷ࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵࡧࡴࡩࠩॄ"),DOm5CacoNA2i)
			tehb3k5a2PufGOdBIUw8j(smpniPDOhfwI3H4v7c6TG(u"ࠧࠨॅ"),Kwl07iYTtDLN3zP(u"ࠨࠩॆ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬे"),GGCQK6OAtZUXRhvkgJm(u"ࠪฮ๊ࠦส฻์ํี๋ࠥใศ่ࠣฮำุ๊็ࠢส่๊๊แศฬࠣห้๋อๆๆฬࠫै"))
	return
def X7TlVUkLztKHwSpC(d7on6sKDqkNY,Pu43YtENBjiyp2KoFQWqHTw6XOlk=ItgK5FqGDz2Rf7mAJkbT(u"ࠫࠬॉ"),website=I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠬ࠭ॊ")):
	y75wQavkVSLUb2MZf9qo(ItgK5FqGDz2Rf7mAJkbT(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ो"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠧࠡࠢࠣࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧौ")+d7on6sKDqkNY+Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠨࠢࡠ्ࠫ"))
	if not Pu43YtENBjiyp2KoFQWqHTw6XOlk: Pu43YtENBjiyp2KoFQWqHTw6XOlk = SU82u7LfcMslH3e0Bzihn6x(d7on6sKDqkNY)
	BQunhYIH2Nj4gfPsxF69r7KTLXG = wgnefLPOZiXh1Jx468VuF()
	Wc8Brs0aYfD9U = sTYDZCo483UAX5IvLGag2ezmR()
	eqfixnjLl5h = Wc8Brs0aYfD9U.replace(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠩࠣࠫॎ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠪࡣࠬॏ"))
	eqfixnjLl5h = dlVCoGwxEZt376mrbaKJ(eqfixnjLl5h)
	eqfixnjLl5h = FeyZbj8tDil0nSHzTwfsUJ9(u"ࠫ࡫࡯࡬ࡦࡡࠪॐ")+str(int(eOYicX68ruMjpN0dKtWP5QTSE))[-r6juULGQtnExAko38BZ5Y(u"࠷৷"):]+GGCQK6OAtZUXRhvkgJm(u"ࠬࡥࠧ॑")+eqfixnjLl5h+Pu43YtENBjiyp2KoFQWqHTw6XOlk
	xGni9OZNv5sjyCQPrHAD2 = K3hFytImeYMkJBC.path.join(BQunhYIH2Nj4gfPsxF69r7KTLXG,eqfixnjLl5h)
	UZbaV6FlwAM0uNvdS1mcIPypC = {}
	UZbaV6FlwAM0uNvdS1mcIPypC[Kwl07iYTtDLN3zP(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ॒")] = wx18CTJPZ5(u"ࠧࠨ॓")
	UZbaV6FlwAM0uNvdS1mcIPypC[FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠨࡃࡦࡧࡪࡶࡴࠨ॔")] = MM564HfnUV0XIR(u"ࠩ࠭࠳࠯࠭ॕ")
	d7on6sKDqkNY = d7on6sKDqkNY.replace(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠪࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡧࡣ࡯ࡷࡪ࠭ॖ"),CgPbwXm1RilpJUSGHLhy(u"ࠫࠬॗ"))
	if smpniPDOhfwI3H4v7c6TG(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪक़") in d7on6sKDqkNY:
		M08MPGgsh4n5rKe,PPGUinpWfm6Xw9NLtbcax53IQ = d7on6sKDqkNY.rsplit(WbM6qAjrn7fEXGZw(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫख़"),wx18CTJPZ5(u"࠵৸"))
		PPGUinpWfm6Xw9NLtbcax53IQ = PPGUinpWfm6Xw9NLtbcax53IQ.replace(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠧࡽࠩग़"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠨࠩज़")).replace(uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠩࠩࠫड़"),qFRrj7ayBKbOsHGSXz(u"ࠪࠫढ़"))
	else: M08MPGgsh4n5rKe,PPGUinpWfm6Xw9NLtbcax53IQ = d7on6sKDqkNY,None
	if not PPGUinpWfm6Xw9NLtbcax53IQ: PPGUinpWfm6Xw9NLtbcax53IQ = FY2qK6eHVBl4D0pEut8IgkTczyG()
	if PPGUinpWfm6Xw9NLtbcax53IQ: UZbaV6FlwAM0uNvdS1mcIPypC[bbqAtUz36RPGVTvCkejpJXQB(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨफ़")] = PPGUinpWfm6Xw9NLtbcax53IQ
	if QmoEjB3hLIw(u"ࠬࡘࡥࡧࡧࡵࡩࡷࡃࠧय़") in M08MPGgsh4n5rKe: M08MPGgsh4n5rKe,Etp7WHcwVuXo51k2KPLzMamIQySxfZ = M08MPGgsh4n5rKe.rsplit(GGCQK6OAtZUXRhvkgJm(u"࠭ࡒࡦࡨࡨࡶࡪࡸ࠽ࠨॠ"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠶৹"))
	else: M08MPGgsh4n5rKe,Etp7WHcwVuXo51k2KPLzMamIQySxfZ = M08MPGgsh4n5rKe,S26SnaqcM9XwK8PVphJDv5(u"ࠧࠨॡ")
	M08MPGgsh4n5rKe = M08MPGgsh4n5rKe.strip(r6juULGQtnExAko38BZ5Y(u"ࠨࡾࠪॢ")).strip(QmoEjB3hLIw(u"ࠩࠩࠫॣ")).strip(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠪࢀࠬ।")).strip(Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠫࠫ࠭॥"))
	Etp7WHcwVuXo51k2KPLzMamIQySxfZ = Etp7WHcwVuXo51k2KPLzMamIQySxfZ.replace(cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠬࢂࠧ०"),wx18CTJPZ5(u"࠭ࠧ१")).replace(NNmirJKPp5nWjfC(u"ࠧࠧࠩ२"),MM564HfnUV0XIR(u"ࠨࠩ३"))
	if Etp7WHcwVuXo51k2KPLzMamIQySxfZ:	UZbaV6FlwAM0uNvdS1mcIPypC[CgPbwXm1RilpJUSGHLhy(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ४")] = Etp7WHcwVuXo51k2KPLzMamIQySxfZ
	y75wQavkVSLUb2MZf9qo(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ५"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠫࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫ࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ६")+M08MPGgsh4n5rKe+r6juULGQtnExAko38BZ5Y(u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨ७")+str(UZbaV6FlwAM0uNvdS1mcIPypC)+YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭८")+xGni9OZNv5sjyCQPrHAD2+tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠧࠡ࡟ࠪ९"))
	lIMQ6Oc8teSXWpnjx7R = I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠷࠰࠳࠶৺")*I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠷࠰࠳࠶৺")
	K9wSL6mHARCY0Igksx5uVozGrT = Kwl07iYTtDLN3zP(u"࠰৻")
	try:
		UUV3Z2ceDdh0zKQyw =	oos8ymFi9CN2z1jXcR.getInfoLabel(MM564HfnUV0XIR(u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡈࡵࡩࡪ࡙ࡰࡢࡥࡨࠫ॰"))
		UUV3Z2ceDdh0zKQyw = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(CIcPowhneWs5tN3(u"ࠩ࡟ࡨ࠰࠭ॱ"),UUV3Z2ceDdh0zKQyw)
		K9wSL6mHARCY0Igksx5uVozGrT = int(UUV3Z2ceDdh0zKQyw[wx18CTJPZ5(u"࠱ৼ")])
	except: pass
	if not K9wSL6mHARCY0Igksx5uVozGrT:
		try:
			IIOTWJhmU8rtuXj0Ao = K3hFytImeYMkJBC.statvfs(BQunhYIH2Nj4gfPsxF69r7KTLXG)
			K9wSL6mHARCY0Igksx5uVozGrT = IIOTWJhmU8rtuXj0Ao.f_frsize*IIOTWJhmU8rtuXj0Ao.f_bavail//lIMQ6Oc8teSXWpnjx7R
		except: pass
	if not K9wSL6mHARCY0Igksx5uVozGrT:
		try:
			IIOTWJhmU8rtuXj0Ao = K3hFytImeYMkJBC.fstatvfs(BQunhYIH2Nj4gfPsxF69r7KTLXG)
			K9wSL6mHARCY0Igksx5uVozGrT = IIOTWJhmU8rtuXj0Ao.f_frsize*IIOTWJhmU8rtuXj0Ao.f_bavail//lIMQ6Oc8teSXWpnjx7R
		except: pass
	if not K9wSL6mHARCY0Igksx5uVozGrT:
		try:
			import shutil as wrJVeovdN3Q
			ZOF4B7NjDE8fQM5rtGLdop,e8gVQbHr0oGLcjP,hhBZORDEsmTwM = wrJVeovdN3Q.disk_usage(BQunhYIH2Nj4gfPsxF69r7KTLXG)
			K9wSL6mHARCY0Igksx5uVozGrT = hhBZORDEsmTwM//lIMQ6Oc8teSXWpnjx7R
		except: pass
	if not K9wSL6mHARCY0Igksx5uVozGrT:
		Dkp5YTLQijOEKF(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠪࡶ࡮࡭ࡨࡵࠩॲ"),r6juULGQtnExAko38BZ5Y(u"ู๊ࠫวฮหࠣห้ะฮำ์้ࠤ๊า็้ๆฬࠫॳ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"๊ࠬไฤีไࠤฬ๊ศา่ส้ัฺ๋ࠦำࠣๆฬีัࠡล้ࠤ๏ำฯะ่ࠢๆิอัࠡ็ึหาฯࠠศๆอาื๐ๆࠡษ็ๅฬืฺสࠢไ๎ࠥา็ศิๆࠤํ฿ไ๋้ࠣๅฬ์ࠠหฯ่๎้ࠦวๅใํำ๏๎็ศฬฺ่๋๊ࠣࠦ็็ࠤ฾์ฯไࠢศ่๎ࠦร็ࠢํๆํ๋ࠠๆสิ้ั๐ࠠษำ้ห๊าࠠไ๊า๎ࠥฮอๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠๅษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠠใัࠣ๎ุฮศࠡษ่ฮ้อมࠡฮ๊หื้ࠠษษ็้้็วห๋๋ࠢีอࠠโ์๊ࠤำ฽่าหࠣ฽้๏ฺࠠ็็ࠤัํวำๅࠣฬฺ๎ัสุࠢั๏ำษ๊ࠡ็๋ีอࠠศๆึฬอࠦโศ็ࠣห้๋ศา็ฯࠤ๊สโหษࠣฬ๊์ูࠡษ็ฬึ์วๆฮ้๋ࠣࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠩॴ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩॵ"))
		y75wQavkVSLUb2MZf9qo(CIcPowhneWs5tN3(u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬॶ"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠨࠢࠣࠤ࡚ࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡥࡧࡷࡩࡷࡳࡩ࡯ࡧࠣࡸ࡭࡫ࠠࡥ࡫ࡶ࡯ࠥ࡬ࡲࡦࡧࠣࡷࡵࡧࡣࡦࠩॷ"))
		return cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࡈࡤࡰࡸ࡫ਠ")
	if Pu43YtENBjiyp2KoFQWqHTw6XOlk==zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨॸ"):
		da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = nPVJZWtkEb27UQ9AK(M08MPGgsh4n5rKe,UZbaV6FlwAM0uNvdS1mcIPypC)
		if len(da6IAnqQ7oV2Hx13F5gbBT4)==CgPbwXm1RilpJUSGHLhy(u"࠲৽"):
			xa60ce2znAlyL5Z8ESXhO(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠪๅู๊ࠠโ์ࠣษ๏าวะ่่ࠢๆࠦวๅฬะ้๏๊ࠧॹ"),NxsKJnLFEZ9OHXf1h(u"ࠫࠬॺ"))
			return ItgK5FqGDz2Rf7mAJkbT(u"ࡉࡥࡱࡹࡥਡ")
		elif len(da6IAnqQ7oV2Hx13F5gbBT4)==SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠴৾"): NljOosKT8WJBpch = Gk98CL5nXZEN(u"࠴৿")
		elif len(da6IAnqQ7oV2Hx13F5gbBT4)>NNmirJKPp5nWjfC(u"࠶਀"):
			NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิสࠪॻ"), da6IAnqQ7oV2Hx13F5gbBT4)
			if NljOosKT8WJBpch == -ta478EuZQJIWhgBnsf6iU(u"࠷ਁ") :
				xa60ce2znAlyL5Z8ESXhO(dEUYJjrhsaPXNo(u"࠭สๆࠢศ่฿อมࠡษ็ฮา๋๊ๅࠩॼ"),Kwl07iYTtDLN3zP(u"ࠧࠨॽ"))
				return QmoEjB3hLIw(u"ࡊࡦࡲࡳࡦਢ")
		M08MPGgsh4n5rKe = jVMHRouKgQFAESmd7B8ObTYy[NljOosKT8WJBpch]
	rAZEy4g2oFcIKYi1svjUVqzaf = bbqAtUz36RPGVTvCkejpJXQB(u"࠰ਂ")
	if Pu43YtENBjiyp2KoFQWqHTw6XOlk==smpniPDOhfwI3H4v7c6TG(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧॾ"):
		xGni9OZNv5sjyCQPrHAD2 = xGni9OZNv5sjyCQPrHAD2.rsplit(Kwl07iYTtDLN3zP(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨॿ"))[MM564HfnUV0XIR(u"࠱ਃ")]+NxsKJnLFEZ9OHXf1h(u"ࠪ࠲ࡲࡶ࠴ࠨঀ")
		pPvgKtqo5IAzadVRZsCGU = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,FeyZbj8tDil0nSHzTwfsUJ9(u"ࠫࡌࡋࡔࠨঁ"),M08MPGgsh4n5rKe,MM564HfnUV0XIR(u"ࠬ࠭ং"),UZbaV6FlwAM0uNvdS1mcIPypC,S26SnaqcM9XwK8PVphJDv5(u"࠭ࠧঃ"),Kwl07iYTtDLN3zP(u"ࠧࠨ঄"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆ࠰ࡈࡔ࡝ࡎࡍࡑࡄࡈࡤ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨঅ"))
		WWwiDr293lJyxcT = pPvgKtqo5IAzadVRZsCGU.content
		cc0O1M4e5jtfoq = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(dEUYJjrhsaPXNo(u"ࠩࠦࡉ࡝࡚ࡉࡏࡈ࠽࠲࠯ࡅ࡛࡝ࡰ࡟ࡶࡢ࠮࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪআ"),WWwiDr293lJyxcT+FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠪࡠࡳࡢࡲࠨই"),E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if not cc0O1M4e5jtfoq:
			y75wQavkVSLUb2MZf9qo(Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩঈ"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+ta478EuZQJIWhgBnsf6iU(u"ࠬࠦࠠࠡࡖ࡫ࡩࠥࡳ࠳ࡶ࠺ࠣࡪ࡮ࡲࡥࠡࡦ࡬ࡨࠥࡴ࡯ࡵࠢ࡫ࡥࡻ࡫ࠠࡵࡪࡨࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࠦ࡬ࡪࡰ࡮ࡷࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨউ")+M08MPGgsh4n5rKe+YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠭ࠠ࡞ࠩঊ"))
			return tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࡋࡧ࡬ࡴࡧਣ")
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = cc0O1M4e5jtfoq[r6juULGQtnExAko38BZ5Y(u"࠲਄")]
		if not ZCimQhV5lovgspAYzHq1Ef27u8ja4R.startswith(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠧࡩࡶࡷࡴࠬঋ")):
			if ZCimQhV5lovgspAYzHq1Ef27u8ja4R.startswith(ta478EuZQJIWhgBnsf6iU(u"ࠨ࠱࠲ࠫঌ")): ZCimQhV5lovgspAYzHq1Ef27u8ja4R = M08MPGgsh4n5rKe.split(GGCQK6OAtZUXRhvkgJm(u"ࠩ࠽ࠫ঍"),ta478EuZQJIWhgBnsf6iU(u"࠴ਅ"))[EAw9bg4rT3Bd8tjSkO(u"࠴ਆ")]+WbM6qAjrn7fEXGZw(u"ࠪ࠾ࠬ঎")+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			elif ZCimQhV5lovgspAYzHq1Ef27u8ja4R.startswith(r6juULGQtnExAko38BZ5Y(u"ࠫ࠴࠭এ")): ZCimQhV5lovgspAYzHq1Ef27u8ja4R = SLMTm6RQ34ic7v5s9rBG(M08MPGgsh4n5rKe,YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠬࡻࡲ࡭ࠩঐ"))+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			else: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = M08MPGgsh4n5rKe.rsplit(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠭࠯ࠨ঑"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠶ਇ"))[Kwl07iYTtDLN3zP(u"࠶ਈ")]+CIcPowhneWs5tN3(u"ࠧ࠰ࠩ঒")+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		pPvgKtqo5IAzadVRZsCGU = jR02vwUAu7Xs8mefybaHiJ.request(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠨࡉࡈࡘࠬও"),ZCimQhV5lovgspAYzHq1Ef27u8ja4R,headers=UZbaV6FlwAM0uNvdS1mcIPypC,verify=Ox8k6IdtuPaG3NlApQK52oYwM(u"ࡌࡡ࡭ࡵࡨਤ"))
		SZflqCXMTKFwxbYa3GiWj = pPvgKtqo5IAzadVRZsCGU.content
		QVpPv1tEjzcRgmbIC8x2GlOLkS3 = len(SZflqCXMTKFwxbYa3GiWj)
		t9nULlEcz8dJCT1vk5 = len(cc0O1M4e5jtfoq)
		rAZEy4g2oFcIKYi1svjUVqzaf = QVpPv1tEjzcRgmbIC8x2GlOLkS3*t9nULlEcz8dJCT1vk5
	else:
		QVpPv1tEjzcRgmbIC8x2GlOLkS3 = MM564HfnUV0XIR(u"࠱ਉ")*lIMQ6Oc8teSXWpnjx7R
		pPvgKtqo5IAzadVRZsCGU = jR02vwUAu7Xs8mefybaHiJ.request(MM564HfnUV0XIR(u"ࠩࡊࡉ࡙࠭ঔ"),M08MPGgsh4n5rKe,headers=UZbaV6FlwAM0uNvdS1mcIPypC,verify=QmoEjB3hLIw(u"ࡇࡣ࡯ࡷࡪਦ"),stream=wx18CTJPZ5(u"ࡔࡳࡷࡨਥ"))
		if tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫক") in pPvgKtqo5IAzadVRZsCGU.headers: rAZEy4g2oFcIKYi1svjUVqzaf = int(pPvgKtqo5IAzadVRZsCGU.headers[GGCQK6OAtZUXRhvkgJm(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬখ")])
		t9nULlEcz8dJCT1vk5 = int(rAZEy4g2oFcIKYi1svjUVqzaf//QVpPv1tEjzcRgmbIC8x2GlOLkS3)
	RT4tyj3FlcPEI5UvGw = int(rAZEy4g2oFcIKYi1svjUVqzaf//lIMQ6Oc8teSXWpnjx7R)+ItgK5FqGDz2Rf7mAJkbT(u"࠲ਊ")
	if rAZEy4g2oFcIKYi1svjUVqzaf<NxsKJnLFEZ9OHXf1h(u"࠴࠴࠴࠵࠶਋"):
		y75wQavkVSLUb2MZf9qo(tOdiG2HWFRBXg1sUh(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪগ"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+Gk98CL5nXZEN(u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡩࡴࠢࡷࡳࡴࠦࡳ࡮ࡣ࡯ࡰࠥࡵࡲࠡ࡫ࡷࠤ࡮ࡹࠠ࡮࠵ࡸ࠼ࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨঘ")+M08MPGgsh4n5rKe+bbqAtUz36RPGVTvCkejpJXQB(u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫঙ")+str(RT4tyj3FlcPEI5UvGw)+Kwl07iYTtDLN3zP(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡄࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧচ")+str(K9wSL6mHARCY0Igksx5uVozGrT)+I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬছ")+xGni9OZNv5sjyCQPrHAD2+FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠪࠤࡢ࠭জ"))
		tehb3k5a2PufGOdBIUw8j(WbM6qAjrn7fEXGZw(u"ࠫࠬঝ"),WbM6qAjrn7fEXGZw(u"ࠬ࠭ঞ"),QmoEjB3hLIw(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩট"),MM564HfnUV0XIR(u"ࠧโึ็ࠤๆ๐ࠠๆ฻ิๅฮࠦออ็้้ࠣ็ࠠศๆไ๎ิ๐่ࠡล๋ࠤฬ๊ๅๅใูࠣ฿๐ัࠡฮาหࠥ๎ไ่าสࠤ้อ๋ࠠ็ๆ๊๊ࠥไษำ้ห๊าࠠหฯ่๎้ࠦ็ัษࠣห้๋ไโࠩঠ"))
		return WbM6qAjrn7fEXGZw(u"ࡈࡤࡰࡸ࡫ਧ")
	cLkgWryeNOJXpjP7a1nDY = bbqAtUz36RPGVTvCkejpJXQB(u"࠷࠴࠵਌")
	yyELmAwRUJQ6q7rdGDcl = K9wSL6mHARCY0Igksx5uVozGrT-RT4tyj3FlcPEI5UvGw
	if yyELmAwRUJQ6q7rdGDcl<cLkgWryeNOJXpjP7a1nDY:
		y75wQavkVSLUb2MZf9qo(cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭ড"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+Kwl07iYTtDLN3zP(u"ࠩࠣࠤࠥࡔ࡯ࡵࠢࡨࡲࡴࡻࡧࡩࠢࡧ࡭ࡸࡱࠠࡴࡲࡤࡧࡪࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡹ࡮ࡥࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨঢ")+M08MPGgsh4n5rKe+CgPbwXm1RilpJUSGHLhy(u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧণ")+str(RT4tyj3FlcPEI5UvGw)+EAw9bg4rT3Bd8tjSkO(u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡇࡶࡢ࡫࡯ࡥࡧࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪত")+str(K9wSL6mHARCY0Igksx5uVozGrT)+EAw9bg4rT3Bd8tjSkO(u"ࠬࠦࡍࡃࠢ࠰ࠤࠬথ")+str(cLkgWryeNOJXpjP7a1nDY)+Ox8k6IdtuPaG3NlApQK52oYwM(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩদ")+xGni9OZNv5sjyCQPrHAD2+Kwl07iYTtDLN3zP(u"ࠧࠡ࡟ࠪধ"))
		tehb3k5a2PufGOdBIUw8j(I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠨࠩন"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠩࠪ঩"),QmoEjB3hLIw(u"่ࠪฬ๊้ࠦฮาࠤู๊วฮหࠣ็ฬ็๊สࠢ็่ฯำๅ๋ๆࠪপ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤฯำๅ๋ๆ๊ࠤาาๅ่ࠢࠪফ")+str(RT4tyj3FlcPEI5UvGw)+tOdiG2HWFRBXg1sUh(u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣࠫব")+str(K9wSL6mHARCY0Igksx5uVozGrT)+YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠭ࠠๆ์฽หออ๊ห๋่้๋ࠢอศใ฻อࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮฯู้่้ࠣอใๅࠢํะอࠦลษไสลࠥ࠭ভ")+str(cLkgWryeNOJXpjP7a1nDY)+YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣๅฬืฺสࠢาหห๋ว๊๊ࠡิฬࠦๅฺ่ส๋ࠥษๆࠡฮ๊หื้ࠠๅษࠣฮําฯࠡใํ๋๋ࠥำศฯฬࠤ่อแ๋ห่ࠣฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡษ็้฼๊่ษࠩম"))
		return FeyZbj8tDil0nSHzTwfsUJ9(u"ࡉࡥࡱࡹࡥਨ")
	A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(Kwl07iYTtDLN3zP(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨয"),dEUYJjrhsaPXNo(u"ࠩࠪর"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠪࠫ঱"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠫ์๊ࠠหำํำࠥะอๆ์็ࠤฬ๊ๅๅใࠣรࠬল"),ta478EuZQJIWhgBnsf6iU(u"ࠬอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥำฬๆ้ࠣฮ็ื๊ษษࠣࠫ঳")+str(RT4tyj3FlcPEI5UvGw)+YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠭ࠠๆ์฽หออ๊ห๋ࠢะ์อาไࠢไ๎์ࠦๅิษะอࠥ็วา฼ฬࠤฯ่ั๋สสࠤࠬ঴")+str(K9wSL6mHARCY0Igksx5uVozGrT)+tOdiG2HWFRBXg1sUh(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์์ึวࠡษ็้้็ࠠใัࠣ๎าะวอࠢห฽฻ࠦวๅ๊ๅฮ๊ࠥไหฯ่๎้ࠦๅ็ࠢส่ส์สา่อࠤส๊้ࠡฮ๊หื้ࠠ࠯๊่ࠢࠥอๆห่ࠢฮศ้ฯ๊ࠡอี๏ีࠠศๆสืฯ๋ัศำࠣฬฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡมࠪ঵"))
	if A5vgi1F6qVunZMas2Nf!=uAl3gHavMJZL4xmNe62nDiBoQ(u"࠵਍"):
		tehb3k5a2PufGOdBIUw8j(GGCQK6OAtZUXRhvkgJm(u"ࠨࠩশ"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠩࠪষ"),ta478EuZQJIWhgBnsf6iU(u"ࠪࠫস"),dEUYJjrhsaPXNo(u"ࠫฯ๋ࠠฦๆ฽หฦูࠦๆๆํอࠥะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩহ"))
		y75wQavkVSLUb2MZf9qo(MM564HfnUV0XIR(u"ࠬࡔࡏࡕࡋࡆࡉࠬ঺"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+Ox8k6IdtuPaG3NlApQK52oYwM(u"࠭ࠠࠡࠢࡘࡷࡪࡸࠠࡳࡧࡩࡹࡸ࡫ࡤࠡࡶࡲࠤࡸࡺࡡࡳࡶࠣࡸ࡭࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡲࡪࠥࡺࡨࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ঻")+M08MPGgsh4n5rKe+MM564HfnUV0XIR(u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠ়ࠦࠧ")+xGni9OZNv5sjyCQPrHAD2+tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠨࠢࡠࠫঽ"))
		return zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࡊࡦࡲࡳࡦ਩")
	y75wQavkVSLUb2MZf9qo(S26SnaqcM9XwK8PVphJDv5(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩা"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵࡷࡥࡷࡺࡥࡥࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹࠨি"))
	ZUNMvsVnGde0mpQxb9ID8aKRkFtJg = ARxKazncryd6Ij2OGtCD5eEihuB8m()
	ZUNMvsVnGde0mpQxb9ID8aKRkFtJg.create(xGni9OZNv5sjyCQPrHAD2,tOdiG2HWFRBXg1sUh(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬী"))
	swF89TuDYLrZcd6URB = CgPbwXm1RilpJUSGHLhy(u"࡙ࡸࡵࡦਪ")
	LRtXWQ1zyFBCbP7SUhZ20a = w6vebiEZtpCjJcILP8Skx5rHn.time()
	if wvkR1es6d0SrjxKt5FZTMUWz7a: nkmQD7wBH2MIj4ReT = open(xGni9OZNv5sjyCQPrHAD2,I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠬࡽࡢࠨু"))
	else: nkmQD7wBH2MIj4ReT = open(xGni9OZNv5sjyCQPrHAD2.decode(Kwl07iYTtDLN3zP(u"࠭ࡵࡵࡨ࠻ࠫূ")),Gk98CL5nXZEN(u"ࠧࡸࡤࠪৃ"))
	if Pu43YtENBjiyp2KoFQWqHTw6XOlk==QmoEjB3hLIw(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧৄ"):
		for Deiz7ocWQjVnIg in range(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠶਎"),t9nULlEcz8dJCT1vk5+zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠶਎")):
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = cc0O1M4e5jtfoq[Deiz7ocWQjVnIg-I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠷ਏ")]
			if not ZCimQhV5lovgspAYzHq1Ef27u8ja4R.startswith(Kwl07iYTtDLN3zP(u"ࠩ࡫ࡸࡹࡶࠧ৅")):
				if ZCimQhV5lovgspAYzHq1Ef27u8ja4R.startswith(WbM6qAjrn7fEXGZw(u"ࠪ࠳࠴࠭৆")): ZCimQhV5lovgspAYzHq1Ef27u8ja4R = M08MPGgsh4n5rKe.split(EAw9bg4rT3Bd8tjSkO(u"ࠫ࠿࠭ে"),r6juULGQtnExAko38BZ5Y(u"࠱ਐ"))[r6juULGQtnExAko38BZ5Y(u"࠱਑")]+EAw9bg4rT3Bd8tjSkO(u"ࠬࡀࠧৈ")+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
				elif ZCimQhV5lovgspAYzHq1Ef27u8ja4R.startswith(NxsKJnLFEZ9OHXf1h(u"࠭࠯ࠨ৉")): ZCimQhV5lovgspAYzHq1Ef27u8ja4R = SLMTm6RQ34ic7v5s9rBG(M08MPGgsh4n5rKe,qFRrj7ayBKbOsHGSXz(u"ࠧࡶࡴ࡯ࠫ৊"))+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
				else: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = M08MPGgsh4n5rKe.rsplit(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠨ࠱ࠪো"),tOdiG2HWFRBXg1sUh(u"࠳਒"))[SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠳ਓ")]+YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠩ࠲ࠫৌ")+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			pPvgKtqo5IAzadVRZsCGU = jR02vwUAu7Xs8mefybaHiJ.request(dEUYJjrhsaPXNo(u"ࠪࡋࡊ্࡚ࠧ"),ZCimQhV5lovgspAYzHq1Ef27u8ja4R,headers=UZbaV6FlwAM0uNvdS1mcIPypC,verify=smpniPDOhfwI3H4v7c6TG(u"ࡌࡡ࡭ࡵࡨਫ"))
			SZflqCXMTKFwxbYa3GiWj = pPvgKtqo5IAzadVRZsCGU.content
			pPvgKtqo5IAzadVRZsCGU.close()
			nkmQD7wBH2MIj4ReT.write(SZflqCXMTKFwxbYa3GiWj)
			oFqyDxT4J95HCw3 = w6vebiEZtpCjJcILP8Skx5rHn.time()
			Jl9xUAa4XGcu = oFqyDxT4J95HCw3-LRtXWQ1zyFBCbP7SUhZ20a
			CKl7YNkISpmeuq2wAROsr3PXJzU1ic = Jl9xUAa4XGcu//Deiz7ocWQjVnIg
			t2bIFRhmPCz7w = CKl7YNkISpmeuq2wAROsr3PXJzU1ic*(t9nULlEcz8dJCT1vk5+tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠵ਔ"))
			ozneYuTm7XAU0NyKOBLZkCWgji = t2bIFRhmPCz7w-Jl9xUAa4XGcu
			aayBzF9OcXn1kYqRhDNm7gTZ(ZUNMvsVnGde0mpQxb9ID8aKRkFtJg,int(MM564HfnUV0XIR(u"࠷࠰࠱ਖ")*Deiz7ocWQjVnIg//(t9nULlEcz8dJCT1vk5+I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠶ਕ"))),S26SnaqcM9XwK8PVphJDv5(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬৎ"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࠬาไษ่่ࠢๆࠦวๅใํำ๏๎࠺࠮ࠢส่ัุมࠡำๅ้ࠬ৏"),str(Deiz7ocWQjVnIg*QVpPv1tEjzcRgmbIC8x2GlOLkS3//lIMQ6Oc8teSXWpnjx7R)+NNmirJKPp5nWjfC(u"࠭࠯ࠨ৐")+str(RT4tyj3FlcPEI5UvGw)+r6juULGQtnExAko38BZ5Y(u"ࠧࠡࡏࡅࠤ้ࠥࠦࠠไอࠤ๊ะศใ์࠽ࠤࠬ৑")+w6vebiEZtpCjJcILP8Skx5rHn.strftime(r6juULGQtnExAko38BZ5Y(u"ࠣࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥ৒"),w6vebiEZtpCjJcILP8Skx5rHn.gmtime(ozneYuTm7XAU0NyKOBLZkCWgji))+Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠩࠣไࠬ৓"))
			if ZUNMvsVnGde0mpQxb9ID8aKRkFtJg.iscanceled():
				swF89TuDYLrZcd6URB = MM564HfnUV0XIR(u"ࡆࡢ࡮ࡶࡩਬ")
				break
	else:
		Deiz7ocWQjVnIg = NNmirJKPp5nWjfC(u"࠰ਗ")
		for SZflqCXMTKFwxbYa3GiWj in pPvgKtqo5IAzadVRZsCGU.iter_content(chunk_size=QVpPv1tEjzcRgmbIC8x2GlOLkS3):
			nkmQD7wBH2MIj4ReT.write(SZflqCXMTKFwxbYa3GiWj)
			Deiz7ocWQjVnIg = Deiz7ocWQjVnIg+qFRrj7ayBKbOsHGSXz(u"࠲ਘ")
			oFqyDxT4J95HCw3 = w6vebiEZtpCjJcILP8Skx5rHn.time()
			Jl9xUAa4XGcu = oFqyDxT4J95HCw3-LRtXWQ1zyFBCbP7SUhZ20a
			CKl7YNkISpmeuq2wAROsr3PXJzU1ic = Jl9xUAa4XGcu/Deiz7ocWQjVnIg
			t2bIFRhmPCz7w = CKl7YNkISpmeuq2wAROsr3PXJzU1ic*(t9nULlEcz8dJCT1vk5+cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠳ਙ"))
			ozneYuTm7XAU0NyKOBLZkCWgji = t2bIFRhmPCz7w-Jl9xUAa4XGcu
			aayBzF9OcXn1kYqRhDNm7gTZ(ZUNMvsVnGde0mpQxb9ID8aKRkFtJg,int(NxsKJnLFEZ9OHXf1h(u"࠵࠵࠶ਛ")*Deiz7ocWQjVnIg/(t9nULlEcz8dJCT1vk5+Gk98CL5nXZEN(u"࠴ਚ"))),NxsKJnLFEZ9OHXf1h(u"ࠪหู้ืาࠢไ์็ࠦ็้่ࠢ็ฬ์ࠠหะี๎๋ࠦๅๅใࠣห้็๊ะ์๋ࠫ৔"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠫั๊ศࠡ็็ๅࠥอไโ์า๎ํࡀ࠭ࠡษ็ะืวࠠาไ่ࠫ৕"),str(Deiz7ocWQjVnIg*QVpPv1tEjzcRgmbIC8x2GlOLkS3//lIMQ6Oc8teSXWpnjx7R)+ta478EuZQJIWhgBnsf6iU(u"ࠬ࠵ࠧ৖")+str(RT4tyj3FlcPEI5UvGw)+ta478EuZQJIWhgBnsf6iU(u"࠭ࠠࡎࡄࠣࠤ่ࠥࠦใฬ้ࠣฯฮโ๋࠼ࠣࠫৗ")+w6vebiEZtpCjJcILP8Skx5rHn.strftime(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠢࠦࡊ࠽ࠩࡒࡀࠥࡔࠤ৘"),w6vebiEZtpCjJcILP8Skx5rHn.gmtime(ozneYuTm7XAU0NyKOBLZkCWgji))+SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠨࠢใࠫ৙"))
			if ZUNMvsVnGde0mpQxb9ID8aKRkFtJg.iscanceled():
				swF89TuDYLrZcd6URB = bbqAtUz36RPGVTvCkejpJXQB(u"ࡇࡣ࡯ࡷࡪਭ")
				break
		pPvgKtqo5IAzadVRZsCGU.close()
	nkmQD7wBH2MIj4ReT.close()
	ZUNMvsVnGde0mpQxb9ID8aKRkFtJg.close()
	if not swF89TuDYLrZcd6URB:
		y75wQavkVSLUb2MZf9qo(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ৚"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+Gk98CL5nXZEN(u"ࠪࠤࠥࠦࡕࡴࡧࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠵ࡩ࡯ࡶࡨࡶࡷࡻࡰࡵࡧࡧࠤࡹ࡮ࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡴࡷࡵࡣࡦࡵࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ৛")+M08MPGgsh4n5rKe+tOdiG2HWFRBXg1sUh(u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫড়")+xGni9OZNv5sjyCQPrHAD2+wx18CTJPZ5(u"ࠬࠦ࡝ࠨঢ়"))
		tehb3k5a2PufGOdBIUw8j(qFRrj7ayBKbOsHGSXz(u"࠭ࠧ৞"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠧࠨয়"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠨࠩৠ"),wx18CTJPZ5(u"ࠩอ้ࠥหไ฻ษฤࠤ฾๋ไ๋หࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧৡ"))
		return smpniPDOhfwI3H4v7c6TG(u"ࡖࡵࡹࡪਮ")
	y75wQavkVSLUb2MZf9qo(Gk98CL5nXZEN(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪৢ"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+smpniPDOhfwI3H4v7c6TG(u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࡩࡵࡷ࡯࡮ࡲࡥࡩ࡫ࡤࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࡱࡿࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪৣ")+M08MPGgsh4n5rKe+FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬ৤")+xGni9OZNv5sjyCQPrHAD2+CIcPowhneWs5tN3(u"࠭ࠠ࡞ࠩ৥"))
	tehb3k5a2PufGOdBIUw8j(MM564HfnUV0XIR(u"ࠧࠨ০"),WbM6qAjrn7fEXGZw(u"ࠨࠩ১"),ItgK5FqGDz2Rf7mAJkbT(u"ࠩࠪ২"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠪฮ๊ࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠣฬ๋าวฮࠩ৩"))
	return YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࡗࡶࡺ࡫ਯ")
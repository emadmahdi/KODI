# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'EGYNOW'
Yc0eBRLpbCkm4gK7OqyzuHwU = '_EGN_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
ZLKHfqMEUdRupD = ['عروض مصارعة','الكل','n/A','المزيد','قصة عشق']
def HgQCVwFx2Br(mode,url,text):
	if   mode==430: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==431: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url,text)
	elif mode==432: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==433: s4Bng5iAZQSTtpDw9 = btd6ag2XYUkHixqy5J7o9RfLu1MScm(url)
	elif mode==434: s4Bng5iAZQSTtpDw9 = L1FsQxw6Afb7pcCe9Tr3qizXZ(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==435: s4Bng5iAZQSTtpDw9 = L1FsQxw6Afb7pcCe9Tr3qizXZ(url,'SPECIFIED_FILTER___'+text)
	elif mode==436: s4Bng5iAZQSTtpDw9 = AJDL0Mp13fQkRH5c(url)
	elif mode==437: s4Bng5iAZQSTtpDw9 = tYF4DlHR6rqVmb2i8Px5B(url)
	elif mode==439: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',tle5V6jgvRfE+'/films','','','','','EGYNOW-MENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	dkgwyUKEpTtPeMxs68aib = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"canonical" href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	dkgwyUKEpTtPeMxs68aib = dkgwyUKEpTtPeMxs68aib[0].strip('/')
	dkgwyUKEpTtPeMxs68aib = SLMTm6RQ34ic7v5s9rBG(dkgwyUKEpTtPeMxs68aib,'url')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',439,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فلتر محدد',dkgwyUKEpTtPeMxs68aib,435)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فلتر كامل',dkgwyUKEpTtPeMxs68aib,434)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'المضاف حديثا',dkgwyUKEpTtPeMxs68aib,431)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'افلام اون لاين',dkgwyUKEpTtPeMxs68aib+'/films1',436)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'مسلسلات اون لاين',dkgwyUKEpTtPeMxs68aib+'/series-all1',436)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'قائمة تفصيلية',dkgwyUKEpTtPeMxs68aib,437)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"SiteNavigation"(.*?)"Search"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		if title in ZLKHfqMEUdRupD: continue
		if title=='الرئيسية': continue
		if 'اون لاين' in title: continue
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,431)
	return
def tYF4DlHR6rqVmb2i8Px5B(website=''):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',website+'/films','','','','','EGYNOW-MENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	dkgwyUKEpTtPeMxs68aib = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"canonical" href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	dkgwyUKEpTtPeMxs68aib = dkgwyUKEpTtPeMxs68aib[0].strip('/')
	dkgwyUKEpTtPeMxs68aib = SLMTm6RQ34ic7v5s9rBG(dkgwyUKEpTtPeMxs68aib,'url')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"ListDroped"(.*?)"SearchingMaster"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-tax="(.*?)" data-term="(.*?)" data-name="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo,hht0cpXxWw2OzFS1jnUGebkJLBd85,title in items:
		if title in ZLKHfqMEUdRupD: continue
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = website+'/explore/?'+cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo+'='+hht0cpXxWw2OzFS1jnUGebkJLBd85
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,431)
	return
def AJDL0Mp13fQkRH5c(url):
	dkgwyUKEpTtPeMxs68aib = SLMTm6RQ34ic7v5s9rBG(url,'url')
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','EGYNOW-SUBMENU-1st')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع',url,431)
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"titleSectionCon"(.*?)</div></div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-key="(.*?)".*?<em>(.*?)</em>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for S7Ra6OGtw1gBkDhrPsozc5Ku,title in items:
		if title in ZLKHfqMEUdRupD: continue
		M08MPGgsh4n5rKe = dkgwyUKEpTtPeMxs68aib+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Movies/Keys.php?key='+S7Ra6OGtw1gBkDhrPsozc5Ku
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,M08MPGgsh4n5rKe,431)
	return
def uyt3pAHZk4(url,VWi2dTb46v3eOryuspKBF9L=''):
	dkgwyUKEpTtPeMxs68aib = SLMTm6RQ34ic7v5s9rBG(url,'url')
	items = []
	if '/Terms.php' in url or '/Get.php' in url or '/Keys.php' in url:
		M08MPGgsh4n5rKe,bhfgckoLVtsA2DXv = NHyOSR4BdqaXfCpK0EU8vroiDJ2T(url)
		TC7fWv2a1gLJGiAtN8 = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'POST',M08MPGgsh4n5rKe,bhfgckoLVtsA2DXv,TC7fWv2a1gLJGiAtN8,'','','EGYNOW-TITLES-1st')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		ziJLDVT8NM2QcgIpmE9A = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
	elif VWi2dTb46v3eOryuspKBF9L=='featured':
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','EGYNOW-TITLES-2nd')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"MainSlider"(.*?)"MatchesTable"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<a href="(.*?)" title="(.*?)".*?image: url\((.*?)\)',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	else:
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','EGYNOW-TITLES-2nd')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"BlocksList"(.*?)"Paginate"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if not TIkiozSLCv6werb97mHQ0q4y3: TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"BlocksList"(.*?)"titleSectionCon"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	if not items: items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<a href="(.*?)" title="(.*?)".*?data-image="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	jjR8ftoEXpPxVF6JerbHZuzv7ic = []
	G1ezKuLr3SlXd9OVkMNQs6FWvf8Aip = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,Q2qmuDRrC9ikcaJK7gtUHXNW in items:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = BUTSkzgFC7(ZCimQhV5lovgspAYzHq1Ef27u8ja4R).strip('/')
		title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
		EQw62xjXSJmzrRt = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(.*?) الحلقة \d+',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title for hht0cpXxWw2OzFS1jnUGebkJLBd85 in G1ezKuLr3SlXd9OVkMNQs6FWvf8Aip):
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,432,Q2qmuDRrC9ikcaJK7gtUHXNW)
		elif EQw62xjXSJmzrRt and 'الحلقة' in title:
			title = '_MOD_' + EQw62xjXSJmzrRt[0]
			if title not in jjR8ftoEXpPxVF6JerbHZuzv7ic:
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,433,Q2qmuDRrC9ikcaJK7gtUHXNW)
				jjR8ftoEXpPxVF6JerbHZuzv7ic.append(title)
		elif '/movseries/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,431,Q2qmuDRrC9ikcaJK7gtUHXNW)
		else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,433,Q2qmuDRrC9ikcaJK7gtUHXNW)
	if VWi2dTb46v3eOryuspKBF9L!='featured':
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"Paginate"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3:
			ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
				if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = dkgwyUKEpTtPeMxs68aib+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = nnGHa80rMphqe1ukFtIRvAPs6W(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
				title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
				if title!='': tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,431)
		rrpPgGwmLCnJeEDdXs0NlfUb9R5 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('showmore" href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if rrpPgGwmLCnJeEDdXs0NlfUb9R5:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = rrpPgGwmLCnJeEDdXs0NlfUb9R5[0]
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مشاهدة المزيد',ZCimQhV5lovgspAYzHq1Ef27u8ja4R,431)
	return
def btd6ag2XYUkHixqy5J7o9RfLu1MScm(url):
	dkgwyUKEpTtPeMxs68aib = SLMTm6RQ34ic7v5s9rBG(url,'url')
	rrNex9MVQDgqIW4kFoSyslw,rNQC9lGIxW3d0oB6AjUfD5LbRF = [],[]
	if 'Episodes.php' in url:
		M08MPGgsh4n5rKe,bhfgckoLVtsA2DXv = NHyOSR4BdqaXfCpK0EU8vroiDJ2T(url)
		TC7fWv2a1gLJGiAtN8 = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'POST',M08MPGgsh4n5rKe,bhfgckoLVtsA2DXv,TC7fWv2a1gLJGiAtN8,'','','EGYNOW-EPISODES-1st')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		rNQC9lGIxW3d0oB6AjUfD5LbRF = [M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2]
	else:
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','EGYNOW-EPISODES-2nd')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		rrNex9MVQDgqIW4kFoSyslw = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"SeasonsList"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		rNQC9lGIxW3d0oB6AjUfD5LbRF = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"EpisodesList"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if rrNex9MVQDgqIW4kFoSyslw:
		Q2qmuDRrC9ikcaJK7gtUHXNW = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"og:image" content="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		Q2qmuDRrC9ikcaJK7gtUHXNW = Q2qmuDRrC9ikcaJK7gtUHXNW[0]
		ziJLDVT8NM2QcgIpmE9A = rrNex9MVQDgqIW4kFoSyslw[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-id="(.*?)".*?data-season="(.*?)".*?">(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for hnezKDdPOMjZ3By,aaiO9BzAIMX,title in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = dkgwyUKEpTtPeMxs68aib+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Episodes.php?'+'season='+aaiO9BzAIMX+'&post_id='+hnezKDdPOMjZ3By
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,433,Q2qmuDRrC9ikcaJK7gtUHXNW)
	elif rNQC9lGIxW3d0oB6AjUfD5LbRF:
		Q2qmuDRrC9ikcaJK7gtUHXNW = oos8ymFi9CN2z1jXcR.getInfoLabel('ListItem.Thumb')
		ziJLDVT8NM2QcgIpmE9A = rNQC9lGIxW3d0oB6AjUfD5LbRF[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?</i>(.*?)<em>(.*?)</em>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,EQw62xjXSJmzrRt in items:
			title = title+' '+EQw62xjXSJmzrRt
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,432,Q2qmuDRrC9ikcaJK7gtUHXNW)
	return
def dlropqS0vO9K7W4z(url):
	M08MPGgsh4n5rKe = url+'/watch/'
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',M08MPGgsh4n5rKe,'','','','','EGYNOW-PLAY-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	jVMHRouKgQFAESmd7B8ObTYy = []
	dkgwyUKEpTtPeMxs68aib = SLMTm6RQ34ic7v5s9rBG(M08MPGgsh4n5rKe,'url')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"container-servers"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		RUglrxzvtWiTOs3KQEq0C8wepH = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-id="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if RUglrxzvtWiTOs3KQEq0C8wepH:
			RUglrxzvtWiTOs3KQEq0C8wepH = RUglrxzvtWiTOs3KQEq0C8wepH[0]
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-server="(.*?)".*?<span>(.*?)</span>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for vMSQsdJ0gCrh7ztnR96yDXqOYaj,title in items:
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = dkgwyUKEpTtPeMxs68aib+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Server.php?server='+vMSQsdJ0gCrh7ztnR96yDXqOYaj+'&post_id='+RUglrxzvtWiTOs3KQEq0C8wepH+'?named='+title+'__watch'
				jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	VNuGLzmvK3ElsCPBoq7YI = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"container-iframe"><iframe src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if VNuGLzmvK3ElsCPBoq7YI:
		VNuGLzmvK3ElsCPBoq7YI = VNuGLzmvK3ElsCPBoq7YI[0].replace('\n','')
		title = SLMTm6RQ34ic7v5s9rBG(VNuGLzmvK3ElsCPBoq7YI,'name')
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = VNuGLzmvK3ElsCPBoq7YI+'?named='+title+'__embed'
		jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"container-download"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?span>(.*?)<.*?em>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,LjG8y1rb9AgJF2I3i64ZDtCXMa7n in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.replace('\n','')
			if LjG8y1rb9AgJF2I3i64ZDtCXMa7n!='': LjG8y1rb9AgJF2I3i64ZDtCXMa7n = '____'+LjG8y1rb9AgJF2I3i64ZDtCXMa7n
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+title+'__download'+LjG8y1rb9AgJF2I3i64ZDtCXMa7n
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	import JYR902sfml
	JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt(jVMHRouKgQFAESmd7B8ObTYy,r1NChsk39OMvT82YemDQnl5,'video',url)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if search=='': search = UIf35nZEj1wylmq()
	if search=='': return
	search = search.replace(' ','%20')
	url = tle5V6jgvRfE+'/?s='+search
	uyt3pAHZk4(url)
	return
def UdqXh8aClcxJAEVSFKy9PnjuGW(url):
	url = url.split('/smartemadfilter?')[0]
	dkgwyUKEpTtPeMxs68aib = SLMTm6RQ34ic7v5s9rBG(url,'url')
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',dkgwyUKEpTtPeMxs68aib,'','','','','EGYNOW-GET_FILTERS_BLOCKS-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('("dropdown-button".*?)"SearchingMaster"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	H8n4oVq07uvJjCOwgzbyf6XR9Fs = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"dropdown-button".*?<em>(.*?)</em>(.*?data-tax="(.*?)".*?</div>)',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	return H8n4oVq07uvJjCOwgzbyf6XR9Fs
def HOgJ4cadx6GAE(ziJLDVT8NM2QcgIpmE9A):
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-term="(\d+)" data-name="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	return items
def VUJ0sTjSZ36wgnRh2bWzK(url):
	bBac0ZnqRLiYT6x93vJyFjQ = url.split('/smartemadfilter?')[0]
	kFlE9TNexjg76 = SLMTm6RQ34ic7v5s9rBG(url,'url')
	url = url.replace(bBac0ZnqRLiYT6x93vJyFjQ,kFlE9TNexjg76)
	url = url.replace('/smartemadfilter?','/explore/?')
	return url
def WWUIQLROJMZFeDhqXNsf2b6H8(SWxX6Q3CgwV7F,url):
	Rdgr0aTSzE5chex9W = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(SWxX6Q3CgwV7F,'modified_filters')
	TW6JIBgC971tjOE = url+'/smartemadfilter?'+Rdgr0aTSzE5chex9W
	TW6JIBgC971tjOE = VUJ0sTjSZ36wgnRh2bWzK(TW6JIBgC971tjOE)
	return TW6JIBgC971tjOE
tpH7FYXLyz4UJdcC31OQ0Phwg = ['category','country','genre','release-year']
bxa9Gj5p3oElwmngHJRKP7CtqS = ['quality','release-year','genre','category','language','country']
def L1FsQxw6Afb7pcCe9Tr3qizXZ(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': ydL2RstfT9BA3Hpe1SZIq,l3Uo4ThenPyJMua = '',''
	else: ydL2RstfT9BA3Hpe1SZIq,l3Uo4ThenPyJMua = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if tpH7FYXLyz4UJdcC31OQ0Phwg[0]+'=' not in ydL2RstfT9BA3Hpe1SZIq: cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = tpH7FYXLyz4UJdcC31OQ0Phwg[0]
		for AudBQkLFsrHKicIogThZyv in range(len(tpH7FYXLyz4UJdcC31OQ0Phwg[0:-1])):
			if tpH7FYXLyz4UJdcC31OQ0Phwg[AudBQkLFsrHKicIogThZyv]+'=' in ydL2RstfT9BA3Hpe1SZIq: cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = tpH7FYXLyz4UJdcC31OQ0Phwg[AudBQkLFsrHKicIogThZyv+1]
		rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&'+cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo+'=0'
		SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&'+cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo+'=0'
		hOSk91jGqtHsfwU2ExCV4YB = rrsgSnC5AFkbEvDPm6pyaRizM8.strip('&')+'___'+SWxX6Q3CgwV7F.strip('&')
		Rdgr0aTSzE5chex9W = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(l3Uo4ThenPyJMua,'modified_filters')
		M08MPGgsh4n5rKe = url+'/smartemadfilter?'+Rdgr0aTSzE5chex9W
	elif type=='ALL_ITEMS_FILTER':
		jyRzHeOYXAW4oDrUS = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(ydL2RstfT9BA3Hpe1SZIq,'modified_values')
		jyRzHeOYXAW4oDrUS = BUTSkzgFC7(jyRzHeOYXAW4oDrUS)
		if l3Uo4ThenPyJMua!='': l3Uo4ThenPyJMua = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(l3Uo4ThenPyJMua,'modified_filters')
		if l3Uo4ThenPyJMua=='': M08MPGgsh4n5rKe = url
		else: M08MPGgsh4n5rKe = url+'/smartemadfilter?'+l3Uo4ThenPyJMua
		M08MPGgsh4n5rKe = VUJ0sTjSZ36wgnRh2bWzK(M08MPGgsh4n5rKe)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'أظهار قائمة الفيديو التي تم اختيارها ',M08MPGgsh4n5rKe,431)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+' [[   '+jyRzHeOYXAW4oDrUS+'   ]]',M08MPGgsh4n5rKe,431)
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	H8n4oVq07uvJjCOwgzbyf6XR9Fs = UdqXh8aClcxJAEVSFKy9PnjuGW(url)
	dict = {}
	for name,ziJLDVT8NM2QcgIpmE9A,eFmOUji0173K in H8n4oVq07uvJjCOwgzbyf6XR9Fs:
		name = name.replace('--','')
		items = HOgJ4cadx6GAE(ziJLDVT8NM2QcgIpmE9A)
		if '=' not in M08MPGgsh4n5rKe: M08MPGgsh4n5rKe = url
		if type=='SPECIFIED_FILTER':
			if cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo!=eFmOUji0173K: continue
			elif len(items)<2:
				if eFmOUji0173K==tpH7FYXLyz4UJdcC31OQ0Phwg[-1]:
					url = VUJ0sTjSZ36wgnRh2bWzK(url)
					uyt3pAHZk4(url)
				else: L1FsQxw6Afb7pcCe9Tr3qizXZ(M08MPGgsh4n5rKe,'SPECIFIED_FILTER___'+hOSk91jGqtHsfwU2ExCV4YB)
				return
			else:
				M08MPGgsh4n5rKe = VUJ0sTjSZ36wgnRh2bWzK(M08MPGgsh4n5rKe)
				if eFmOUji0173K==tpH7FYXLyz4UJdcC31OQ0Phwg[-1]: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع ',M08MPGgsh4n5rKe,431)
				else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع ',M08MPGgsh4n5rKe,435,'','',hOSk91jGqtHsfwU2ExCV4YB)
		elif type=='ALL_ITEMS_FILTER':
			rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&'+eFmOUji0173K+'=0'
			SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&'+eFmOUji0173K+'=0'
			hOSk91jGqtHsfwU2ExCV4YB = rrsgSnC5AFkbEvDPm6pyaRizM8+'___'+SWxX6Q3CgwV7F
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع :'+name,M08MPGgsh4n5rKe,434,'','',hOSk91jGqtHsfwU2ExCV4YB)
		dict[eFmOUji0173K] = {}
		for hht0cpXxWw2OzFS1jnUGebkJLBd85,e0i4nPhusqdTaG in items:
			if hht0cpXxWw2OzFS1jnUGebkJLBd85=='196533': e0i4nPhusqdTaG = 'أفلام نيتفلكس'
			elif hht0cpXxWw2OzFS1jnUGebkJLBd85=='196531': e0i4nPhusqdTaG = 'مسلسلات نيتفلكس'
			if e0i4nPhusqdTaG in ZLKHfqMEUdRupD: continue
			dict[eFmOUji0173K][hht0cpXxWw2OzFS1jnUGebkJLBd85] = e0i4nPhusqdTaG
			rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&'+eFmOUji0173K+'='+e0i4nPhusqdTaG
			SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&'+eFmOUji0173K+'='+hht0cpXxWw2OzFS1jnUGebkJLBd85
			RtPpz8FAEjIxU = rrsgSnC5AFkbEvDPm6pyaRizM8+'___'+SWxX6Q3CgwV7F
			title = e0i4nPhusqdTaG+' :'#+dict[eFmOUji0173K]['0']
			title = e0i4nPhusqdTaG+' :'+name
			if type=='ALL_ITEMS_FILTER': tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,434,'','',RtPpz8FAEjIxU)
			elif type=='SPECIFIED_FILTER' and tpH7FYXLyz4UJdcC31OQ0Phwg[-2]+'=' in ydL2RstfT9BA3Hpe1SZIq:
				TW6JIBgC971tjOE = WWUIQLROJMZFeDhqXNsf2b6H8(SWxX6Q3CgwV7F,url)
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,TW6JIBgC971tjOE,431)
			else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,435,'','',RtPpz8FAEjIxU)
	return
def l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(dY1a0xA6PKm7TOJSERt3sHU9Qp,mode):
	dY1a0xA6PKm7TOJSERt3sHU9Qp = dY1a0xA6PKm7TOJSERt3sHU9Qp.replace('=&','=0&')
	dY1a0xA6PKm7TOJSERt3sHU9Qp = dY1a0xA6PKm7TOJSERt3sHU9Qp.strip('&')
	nvNkgT7iGQOyed = {}
	if '=' in dY1a0xA6PKm7TOJSERt3sHU9Qp:
		items = dY1a0xA6PKm7TOJSERt3sHU9Qp.split('&')
		for hh4gUqS5JWf1saRZPXHD in items:
			DHcrLNnqExKjM8uvVlBhWd,hht0cpXxWw2OzFS1jnUGebkJLBd85 = hh4gUqS5JWf1saRZPXHD.split('=')
			nvNkgT7iGQOyed[DHcrLNnqExKjM8uvVlBhWd] = hht0cpXxWw2OzFS1jnUGebkJLBd85
	UJzegYmlGML35rasDAIx17Rhnk = ''
	for key in bxa9Gj5p3oElwmngHJRKP7CtqS:
		if key in list(nvNkgT7iGQOyed.keys()): hht0cpXxWw2OzFS1jnUGebkJLBd85 = nvNkgT7iGQOyed[key]
		else: hht0cpXxWw2OzFS1jnUGebkJLBd85 = '0'
		if '%' not in hht0cpXxWw2OzFS1jnUGebkJLBd85: hht0cpXxWw2OzFS1jnUGebkJLBd85 = TaEr2nR3f5e8oXzpy(hht0cpXxWw2OzFS1jnUGebkJLBd85)
		if mode=='modified_values' and hht0cpXxWw2OzFS1jnUGebkJLBd85!='0': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+' + '+hht0cpXxWw2OzFS1jnUGebkJLBd85
		elif mode=='modified_filters' and hht0cpXxWw2OzFS1jnUGebkJLBd85!='0': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+'&'+key+'='+hht0cpXxWw2OzFS1jnUGebkJLBd85
		elif mode=='all_filters': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+'&'+key+'='+hht0cpXxWw2OzFS1jnUGebkJLBd85
	UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk.strip(' + ')
	UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk.strip('&')
	UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk.replace('=0','=')
	return UJzegYmlGML35rasDAIx17Rhnk
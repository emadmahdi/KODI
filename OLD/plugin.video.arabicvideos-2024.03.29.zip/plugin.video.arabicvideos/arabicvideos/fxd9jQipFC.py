# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
headers = { 'User-Agent' : '' }
r1NChsk39OMvT82YemDQnl5 = 'AKOAM'
Yc0eBRLpbCkm4gK7OqyzuHwU = '_AKO_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
TTdgJB7NVkC3yv = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def HgQCVwFx2Br(mode,url,text):
	if   mode==70: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==71: s4Bng5iAZQSTtpDw9 = LXNEU45IzZpCdYcay(url)
	elif mode==72: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url,text)
	elif mode==73: s4Bng5iAZQSTtpDw9 = jua0PJCeqQvikoDsNWEAKxzr5tTHL(url)
	elif mode==74: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==79: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',79,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'سلسلة افلام','',79,'','','سلسلة افلام')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'سلاسل منوعة','',79,'','','سلسلة')
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	ZLKHfqMEUdRupD = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,tle5V6jgvRfE,'',headers,'','AKOAM-MENU-1st')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="partions"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			if title not in ZLKHfqMEUdRupD:
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,71)
	return M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
def LXNEU45IzZpCdYcay(url):
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,url,'',headers,'','AKOAM-CATEGORIES-1st')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('sect_parts(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			title = title.strip(' ')
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,72)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'جميع الفروع',url,72)
	else: uyt3pAHZk4(url,'')
	return
def uyt3pAHZk4(url,type):
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,url,'',headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('section_title featured_title(.*?)subjects-crousel',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	elif type=='search':
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('akoam_result(.*?)<script',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	elif type=='more':
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('section_title more_title(.*?)footer_bottom_services',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	else:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('navigation(.*?)<script',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not items and TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace('\n','').strip(' ')
		title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
		if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title for hht0cpXxWw2OzFS1jnUGebkJLBd85 in TTdgJB7NVkC3yv): tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,73,Q2qmuDRrC9ikcaJK7gtUHXNW)
		else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,73,Q2qmuDRrC9ikcaJK7gtUHXNW)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="pagination"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("</li><li >.*?href='(.*?)'>(.*?)<",ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,72,'','',type)
	return
def vRDsgPJT4AxiUj1Oo98M(url):
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,url,'',headers,True,'AKOAM-SECTIONS-2nd')
	M08MPGgsh4n5rKe = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"href","(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	M08MPGgsh4n5rKe = M08MPGgsh4n5rKe[1]
	return M08MPGgsh4n5rKe
def jua0PJCeqQvikoDsNWEAKxzr5tTHL(url):
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,url,'',headers,True,'AKOAM-SECTIONS-1st')
	NoKqWEMb78Pwg6Ur = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"(https*://akwam.net/\w+.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	wJ7BKZy1VdNDh = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"(https*://underurl.com/\w+.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if NoKqWEMb78Pwg6Ur or wJ7BKZy1VdNDh:
		if NoKqWEMb78Pwg6Ur: TW6JIBgC971tjOE = NoKqWEMb78Pwg6Ur[0]
		elif wJ7BKZy1VdNDh: TW6JIBgC971tjOE = vRDsgPJT4AxiUj1Oo98M(wJ7BKZy1VdNDh[0])
		TW6JIBgC971tjOE = BUTSkzgFC7(TW6JIBgC971tjOE)
		import JJjPSnbr9G
		if '/series/' in TW6JIBgC971tjOE or '/shows/' in TW6JIBgC971tjOE: JJjPSnbr9G.btd6ag2XYUkHixqy5J7o9RfLu1MScm(TW6JIBgC971tjOE)
		else: JJjPSnbr9G.dlropqS0vO9K7W4z(TW6JIBgC971tjOE)
		return
	VnK1wPrcHoN8ex2Bl0pLS = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if VnK1wPrcHoN8ex2Bl0pLS and Y1Yz6bZMLDaGjpxK3fSXm7TurCnHwo(r1NChsk39OMvT82YemDQnl5,url,VnK1wPrcHoN8ex2Bl0pLS): return
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,73)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not TIkiozSLCv6werb97mHQ0q4y3:
		xa60ce2znAlyL5Z8ESXhO('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,Q2qmuDRrC9ikcaJK7gtUHXNW,ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	name = name.strip(' ')
	if 'sub_epsiode_title' in ziJLDVT8NM2QcgIpmE9A:
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	else:
		zUEyivmJe1MWlFITh2wN5VQCgbOusA = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('sub_file_title\'>(.*?) - <i>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		items = []
		for filename in zUEyivmJe1MWlFITh2wN5VQCgbOusA:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل','') ]
	count = 0
	da6IAnqQ7oV2Hx13F5gbBT4,E6MfZScAqOH8mYlRTnvW71K2 = [],[]
	size = len(items)
	for title,filename in items:
		dmSj9bwK7C0E = ''
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: dmSj9bwK7C0E = filename.split('.')[-1]
		title = title.replace('\n','').strip(' ')
		da6IAnqQ7oV2Hx13F5gbBT4.append(title)
		E6MfZScAqOH8mYlRTnvW71K2.append(count)
		count += 1
	if size>0:
		if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in name for hht0cpXxWw2OzFS1jnUGebkJLBd85 in TTdgJB7NVkC3yv):
			if size==1:
				NljOosKT8WJBpch = 0
			else:
				NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql('اختر الفيديو المناسب:', da6IAnqQ7oV2Hx13F5gbBT4)
				if NljOosKT8WJBpch == -1: return
			dlropqS0vO9K7W4z(url+'?section='+str(1+E6MfZScAqOH8mYlRTnvW71K2[size-NljOosKT8WJBpch-1]))
		else:
			for AudBQkLFsrHKicIogThZyv in reversed(range(size)):
				title = name + ' - ' + da6IAnqQ7oV2Hx13F5gbBT4[AudBQkLFsrHKicIogThZyv]
				title = title.replace('\n','').strip(' ')
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = url + '?section='+str(size-AudBQkLFsrHKicIogThZyv)
				tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,74,Q2qmuDRrC9ikcaJK7gtUHXNW)
	else:
		tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+'الرابط ليس فيديو','',9999,Q2qmuDRrC9ikcaJK7gtUHXNW)
	return
def dlropqS0vO9K7W4z(url):
	M08MPGgsh4n5rKe,EQw62xjXSJmzrRt = url.split('?section=')
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',M08MPGgsh4n5rKe,'',headers,True,'','AKOAM-PLAY_AKOAM-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	BoKMW0uRd8g4j9F3 = TIkiozSLCv6werb97mHQ0q4y3[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	BoKMW0uRd8g4j9F3 = BoKMW0uRd8g4j9F3 + 'direct_link_box'
	cz4e6sNTj53E09xtaArJLKDg = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('epsoide_box(.*?)direct_link_box',BoKMW0uRd8g4j9F3,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	EQw62xjXSJmzrRt = len(cz4e6sNTj53E09xtaArJLKDg)-int(EQw62xjXSJmzrRt)
	ziJLDVT8NM2QcgIpmE9A = cz4e6sNTj53E09xtaArJLKDg[EQw62xjXSJmzrRt]
	zcBjFq4VQlp20ZekGO = []
	mkozZlwpQa8nbryI7eC0KPgS3J5 = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("class='download_btn.*?href='(.*?)'",ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
		zcBjFq4VQlp20ZekGO.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named=________akoam')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for aZlc0mKFPUOkVeSIL,ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
		aZlc0mKFPUOkVeSIL = aZlc0mKFPUOkVeSIL.split('/')[-1]
		aZlc0mKFPUOkVeSIL = aZlc0mKFPUOkVeSIL.split('.')[0]
		if aZlc0mKFPUOkVeSIL in mkozZlwpQa8nbryI7eC0KPgS3J5:
			zcBjFq4VQlp20ZekGO.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+mkozZlwpQa8nbryI7eC0KPgS3J5[aZlc0mKFPUOkVeSIL]+'________akoam')
		else: zcBjFq4VQlp20ZekGO.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+aZlc0mKFPUOkVeSIL+'________akoam')
	if not zcBjFq4VQlp20ZekGO:
		message = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('sub-no-file.*?\n(.*?)\n',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if message: tehb3k5a2PufGOdBIUw8j('','','رسالة من الموقع الاصلي',message[0])
	else:
		import JYR902sfml
		JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt(zcBjFq4VQlp20ZekGO,r1NChsk39OMvT82YemDQnl5,'video',url)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if search=='': search = UIf35nZEj1wylmq()
	if search=='': return
	DbEfLQSBFCTt2mMqvrsIVnjJ6 = search.replace(' ','%20')
	url = tle5V6jgvRfE + '/search/'+DbEfLQSBFCTt2mMqvrsIVnjJ6
	s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url,'search')
	return
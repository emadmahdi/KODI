# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'KATKOTTV'
Yc0eBRLpbCkm4gK7OqyzuHwU = '_KTV_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
ZLKHfqMEUdRupD = []
def HgQCVwFx2Br(mode,url,text):
	if   mode==810: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==811: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url,text)
	elif mode==812: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==813: s4Bng5iAZQSTtpDw9 = jlfsyC6ZOhFw1PgX9YHzkeBn(url)
	elif mode==819: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',tle5V6jgvRfE,'','','','','KATKOTTV-MENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',819,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"primary-links"(.*?)"most-viewed"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?<span>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		if title in ZLKHfqMEUdRupD: continue
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,811)
	return
def uyt3pAHZk4(url,type=''):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','KATKOTTV-TITLES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"home-content"(.*?)"footer"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"thumb".*?data-src="(.*?)".*?href="(.*?)".*?title="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		jjR8ftoEXpPxVF6JerbHZuzv7ic = []
		for Q2qmuDRrC9ikcaJK7gtUHXNW,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			EQw62xjXSJmzrRt = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(.*?) (الحلقة|حلقة).\d+',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if 'episodes' not in type and EQw62xjXSJmzrRt:
				title = '_MOD_' + EQw62xjXSJmzrRt[0][0]
				title = title.replace('اون لاين','')
				if title not in jjR8ftoEXpPxVF6JerbHZuzv7ic:
					tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,813,Q2qmuDRrC9ikcaJK7gtUHXNW)
					jjR8ftoEXpPxVF6JerbHZuzv7ic.append(title)
			else: tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,812,Q2qmuDRrC9ikcaJK7gtUHXNW)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("'pagination'(.*?)footer",M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)">(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,811,'','',type)
	return
def jlfsyC6ZOhFw1PgX9YHzkeBn(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','KATKOTTV-SERIES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"category".*?href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if ZCimQhV5lovgspAYzHq1Ef27u8ja4R: uyt3pAHZk4(ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0],'episodes')
	return
def dlropqS0vO9K7W4z(url):
	zcBjFq4VQlp20ZekGO = []
	M08MPGgsh4n5rKe = url+'?do=watch'
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',M08MPGgsh4n5rKe,'','','','','KATKOTTV-PLAY-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('" src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]
		zcBjFq4VQlp20ZekGO.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	else:
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','KATKOTTV-PLAY-2nd')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		hnezKDdPOMjZ3By = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('post=(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if hnezKDdPOMjZ3By:
			hnezKDdPOMjZ3By = SSNcdhMguvEw0RY.b64decode(hnezKDdPOMjZ3By[0])
			if wvkR1es6d0SrjxKt5FZTMUWz7a: hnezKDdPOMjZ3By = hnezKDdPOMjZ3By.decode('utf8')
			hnezKDdPOMjZ3By = GVQAnvYCT3dS('dict',hnezKDdPOMjZ3By)
			cc0O1M4e5jtfoq = hnezKDdPOMjZ3By['servers']
			GReTJrIxo2dzbapy = list(cc0O1M4e5jtfoq.keys())
			cc0O1M4e5jtfoq = list(cc0O1M4e5jtfoq.values())
			Jvz4r1LbjumknXHpeRxDVP5W2 = zip(GReTJrIxo2dzbapy,cc0O1M4e5jtfoq)
			for title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R in Jvz4r1LbjumknXHpeRxDVP5W2:
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+title+'__watch'
				zcBjFq4VQlp20ZekGO.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	import JYR902sfml
	JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt(zcBjFq4VQlp20ZekGO,r1NChsk39OMvT82YemDQnl5,'video',url)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if search=='': search = UIf35nZEj1wylmq()
	if search=='': return
	search = search.replace(' ','+')
	url = tle5V6jgvRfE+'/?s='+search
	uyt3pAHZk4(url,'search')
	return
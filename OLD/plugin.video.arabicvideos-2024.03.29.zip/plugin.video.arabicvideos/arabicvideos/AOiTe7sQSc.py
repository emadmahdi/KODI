# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'ARABSEED'
headers = {'User-Agent':FY2qK6eHVBl4D0pEut8IgkTczyG()}
Yc0eBRLpbCkm4gK7OqyzuHwU = '_ARS_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
ZLKHfqMEUdRupD = ['الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def HgQCVwFx2Br(mode,url,text):
	if   mode==250: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==251: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url,text)
	elif mode==252: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==253: s4Bng5iAZQSTtpDw9 = btd6ag2XYUkHixqy5J7o9RfLu1MScm(url)
	elif mode==254: s4Bng5iAZQSTtpDw9 = L1FsQxw6Afb7pcCe9Tr3qizXZ(url,'CATEGORIES___'+text)
	elif mode==255: s4Bng5iAZQSTtpDw9 = L1FsQxw6Afb7pcCe9Tr3qizXZ(url,'FILTERS___'+text)
	elif mode==256: s4Bng5iAZQSTtpDw9 = AJDL0Mp13fQkRH5c(url,text)
	elif mode==259: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',tle5V6jgvRfE+'/main','',headers,'','','ARABSEED-MENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',259,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فلتر محدد',tle5V6jgvRfE+'/category/اخرى',254)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فلتر كامل',tle5V6jgvRfE+'/category/اخرى',255)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'المميزة',tle5V6jgvRfE+'/main',251,'','','featured_main')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'جديد الأفلام',tle5V6jgvRfE+'/main',251,'','','new_movies')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'جديد الحلقات',tle5V6jgvRfE+'/main',251,'','','new_episodes')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'المضاف حديثاً',tle5V6jgvRfE+'/latest',251,'','','lastest')
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	rNQC9lGIxW3d0oB6AjUfD5LbRF = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="MenuHeader"(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	f9AzGuXj0qgcNTy1 = rNQC9lGIxW3d0oB6AjUfD5LbRF[0]
	HKE5ebjfkuy = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?>(.*?)<',f9AzGuXj0qgcNTy1,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in HKE5ebjfkuy:
		title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
		if title not in ZLKHfqMEUdRupD and title!='':
			if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,256)
	return M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
def AJDL0Mp13fQkRH5c(url,type):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'',headers,'','','ARABSEED-SUBMENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	if 'class="SliderInSection' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الأكثر مشاهدة',url,251,'','','most')
	if 'class="MainSlides' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'المميزة',url,251,'','','featured')
	if 'class="LinksList' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="LinksList(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3:
			ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
			if len(TIkiozSLCv6werb97mHQ0q4y3)>1 and type=='new_episodes': ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[1]
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)"(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
				neZQycYAFqxLzkPhEWvM = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('</i>(.*?)<span>(.*?)<',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
				try: LRtXWQ1zyFBCbP7SUhZ20a = neZQycYAFqxLzkPhEWvM[0][0]
				except: LRtXWQ1zyFBCbP7SUhZ20a = ''
				try: W5W8HRkNrtcuAPbz3Kx4saFUDZIw = neZQycYAFqxLzkPhEWvM[0][1]
				except: W5W8HRkNrtcuAPbz3Kx4saFUDZIw = ''
				neZQycYAFqxLzkPhEWvM = LRtXWQ1zyFBCbP7SUhZ20a+W5W8HRkNrtcuAPbz3Kx4saFUDZIw
				neZQycYAFqxLzkPhEWvM = neZQycYAFqxLzkPhEWvM.replace('\n','')
				if '<strong>' in title:
					XxVw0cbRer6ZoqF = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('</i>(.*?)<',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
					if XxVw0cbRer6ZoqF: neZQycYAFqxLzkPhEWvM = XxVw0cbRer6ZoqF[0]
				if not neZQycYAFqxLzkPhEWvM:
					XxVw0cbRer6ZoqF = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('alt="(.*?)"',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
					if XxVw0cbRer6ZoqF: neZQycYAFqxLzkPhEWvM = XxVw0cbRer6ZoqF[0]
				if neZQycYAFqxLzkPhEWvM:
					if 'key=' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: type = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('key=')[1]
					else: type = 'newest'
					neZQycYAFqxLzkPhEWvM = neZQycYAFqxLzkPhEWvM.strip(' ')
					tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+neZQycYAFqxLzkPhEWvM,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,251,'','',type)
	return
def uyt3pAHZk4(url,type):
	rk69B8TYfGvW0swz,data,items = 'GET','',[]
	if type=='filters':
		if '?' in url:
			BCrgPhcKutUENdZ4em,bhfgckoLVtsA2DXv = 'POST',{}
			M08MPGgsh4n5rKe,mpMWiOeDqvsId6 = url.split('?')
			Zvm7qOC8GUAFB = mpMWiOeDqvsId6.split('&')
			for Fj1YUPiHsabvulW30mzZ in Zvm7qOC8GUAFB:
				key,hht0cpXxWw2OzFS1jnUGebkJLBd85 = Fj1YUPiHsabvulW30mzZ.split('=')
				bhfgckoLVtsA2DXv[key] = hht0cpXxWw2OzFS1jnUGebkJLBd85
			if Zvm7qOC8GUAFB: rk69B8TYfGvW0swz,url,data = BCrgPhcKutUENdZ4em,M08MPGgsh4n5rKe,bhfgckoLVtsA2DXv
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,rk69B8TYfGvW0swz,url,data,headers,'','','ARABSEED-TITLES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	if type=='filters': TIkiozSLCv6werb97mHQ0q4y3 = [M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2]
	elif 'featured' in type: TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="MainSlides(.*?)class="LinksList',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	elif type=='new_movies': TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('جديد الافلام.*?class="SliderInSection"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	elif type=='new_episodes': TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('جديد الحلقات.*?class="SliderInSection"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	elif type=='most': TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="SliderInSection(.*?)class="LinksList',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	else: TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="Blocks-UL"(.*?)class="AboElSeed"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if 'featured' in type:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		SSpkVJbD9mXviY7twW4Ox5gLRcsCA = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)" title="(.*?)".*?data-lazy.*? (src|data-image)="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if SSpkVJbD9mXviY7twW4Ox5gLRcsCA:
			jVMHRouKgQFAESmd7B8ObTYy,da6IAnqQ7oV2Hx13F5gbBT4,Tl0FrCuK82m6Jy,npQM6Ok4iYZ5CxUdqtsDe08 = zip(*SSpkVJbD9mXviY7twW4Ox5gLRcsCA)
			items = zip(jVMHRouKgQFAESmd7B8ObTYy,npQM6Ok4iYZ5CxUdqtsDe08,da6IAnqQ7oV2Hx13F5gbBT4)
	else:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('LoadingArea.*? href="(.*?)".*? data-\w{3,5}="(.*?)".*? alt="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	jjR8ftoEXpPxVF6JerbHZuzv7ic = []
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title in items:
		if 'WWE' in title: continue
		title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
		if 'الحلقة' in title:
			EQw62xjXSJmzrRt = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(.*?) الحلقة \d+',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if EQw62xjXSJmzrRt:
				title = '_MOD_' + EQw62xjXSJmzrRt[0]
				if title not in jjR8ftoEXpPxVF6JerbHZuzv7ic:
					jjR8ftoEXpPxVF6JerbHZuzv7ic.append(title)
					tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,253,Q2qmuDRrC9ikcaJK7gtUHXNW)
			else: tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,252,Q2qmuDRrC9ikcaJK7gtUHXNW)
		elif '/selary/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R or 'مسلسل' in title:
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,253,Q2qmuDRrC9ikcaJK7gtUHXNW)
		else:
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,252,Q2qmuDRrC9ikcaJK7gtUHXNW)
	if type in ['newest','best','most']:
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('page-numbers" href="(.*?)">(.*?)<',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = nnGHa80rMphqe1ukFtIRvAPs6W(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,251,'','',type)
	return
def btd6ag2XYUkHixqy5J7o9RfLu1MScm(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'',headers,'','','ARABSEED-EPISODES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2[10000:]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-src="(.*?)".*?alt="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not items: return
	Q2qmuDRrC9ikcaJK7gtUHXNW,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(' ')
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(' ')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="ContainerEpisodesList"(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?<em>(.*?)</em>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,EQw62xjXSJmzrRt in items:
			title = name+' - الحلقة رقم '+EQw62xjXSJmzrRt
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,252,Q2qmuDRrC9ikcaJK7gtUHXNW)
	else: tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+'ملف التشغيل',url,252,Q2qmuDRrC9ikcaJK7gtUHXNW)
	return
def fRF7jUPNHp2kI(title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R):
	neZQycYAFqxLzkPhEWvM = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('[a-zA-Z-]+',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if neZQycYAFqxLzkPhEWvM: title = neZQycYAFqxLzkPhEWvM[0]
	else: title = title+' '+SLMTm6RQ34ic7v5s9rBG(ZCimQhV5lovgspAYzHq1Ef27u8ja4R,'name')
	title = title.replace('عرب سيد','').replace('مباشر','').replace('مشاهدة','')
	title = title.replace('ٍ','')
	title = title.replace('  ',' ').replace('  ',' ')
	return title
def dlropqS0vO9K7W4z(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',url,'',headers,'','','ARABSEED-PLAY-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	M08MPGgsh4n5rKe = aQniqUlZk8.url
	vMSQsdJ0gCrh7ztnR96yDXqOYaj = SLMTm6RQ34ic7v5s9rBG(M08MPGgsh4n5rKe,'url')
	headers['Referer'] = vMSQsdJ0gCrh7ztnR96yDXqOYaj+'/'
	ff5ARFBW6NpbUkhgLyYa9mC3lu,xxeLpucQImd6E1bK0kPFtgR2f5sWN,jVMHRouKgQFAESmd7B8ObTYy = '','',[]
	fFxW5eMJOLBr = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="WatchButtons".*?href="(.*?)" class="(watch.*?)".*?href="(.*?)" class="(download.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if fFxW5eMJOLBr: ff5ARFBW6NpbUkhgLyYa9mC3lu,EDOvRaS4gn2U7ZJ63oI5Mu,xxeLpucQImd6E1bK0kPFtgR2f5sWN,dZqIj4QB0DYuk6M = fFxW5eMJOLBr[0]
	else:
		fFxW5eMJOLBr = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="WatchButtons".*?href="(.*?)" class="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if fFxW5eMJOLBr:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R,EDOvRaS4gn2U7ZJ63oI5Mu = fFxW5eMJOLBr[0]
			if 'watch' in EDOvRaS4gn2U7ZJ63oI5Mu: ff5ARFBW6NpbUkhgLyYa9mC3lu = ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			else: xxeLpucQImd6E1bK0kPFtgR2f5sWN = ZCimQhV5lovgspAYzHq1Ef27u8ja4R
	if ff5ARFBW6NpbUkhgLyYa9mC3lu:
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',ff5ARFBW6NpbUkhgLyYa9mC3lu,'',headers,'','','ARABSEED-PLAY-2nd')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="WatcherArea"(.*?</ul>)',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3:
			SvO0Ifn34gUycWhEjCs = TIkiozSLCv6werb97mHQ0q4y3[0]
			SvO0Ifn34gUycWhEjCs = SvO0Ifn34gUycWhEjCs.replace('</ul>','<h3>')
			SvO0Ifn34gUycWhEjCs = SvO0Ifn34gUycWhEjCs.replace('<h3>','<h3><h3>')
			cz4e6sNTj53E09xtaArJLKDg = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<h3>.*?(\d+)(.*?)<h3>',SvO0Ifn34gUycWhEjCs,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if not cz4e6sNTj53E09xtaArJLKDg: cz4e6sNTj53E09xtaArJLKDg = [('',SvO0Ifn34gUycWhEjCs)]
			for LjG8y1rb9AgJF2I3i64ZDtCXMa7n,ziJLDVT8NM2QcgIpmE9A in cz4e6sNTj53E09xtaArJLKDg:
				if LjG8y1rb9AgJF2I3i64ZDtCXMa7n: LjG8y1rb9AgJF2I3i64ZDtCXMa7n = '____'+LjG8y1rb9AgJF2I3i64ZDtCXMa7n
				items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-link="(.*?)".*?<span>(.*?)</span>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
				for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,name in items:
					if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = 'http:'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
					ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+name+'__watch'+LjG8y1rb9AgJF2I3i64ZDtCXMa7n
					jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
		cc0O1M4e5jtfoq = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if not cc0O1M4e5jtfoq: cc0O1M4e5jtfoq = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="containerIframe".*? SRC="(.*?)".*? HEIGHT="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if cc0O1M4e5jtfoq:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R,LjG8y1rb9AgJF2I3i64ZDtCXMa7n = cc0O1M4e5jtfoq[0]
			name = SLMTm6RQ34ic7v5s9rBG(ZCimQhV5lovgspAYzHq1Ef27u8ja4R,'name')
			if '%' in LjG8y1rb9AgJF2I3i64ZDtCXMa7n: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+name+'__embed__'
			else: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+name+'__embed____'+LjG8y1rb9AgJF2I3i64ZDtCXMa7n
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	if xxeLpucQImd6E1bK0kPFtgR2f5sWN:
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',xxeLpucQImd6E1bK0kPFtgR2f5sWN,'',headers,'','','ARABSEED-PLAY-3rd')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="DownloadArea"(.*?)function',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3:
			ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,LjG8y1rb9AgJF2I3i64ZDtCXMa7n in items:
				if not ZCimQhV5lovgspAYzHq1Ef27u8ja4R: continue
				if 'reviewstation' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: continue
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = BUTSkzgFC7(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+title+'__download____'+LjG8y1rb9AgJF2I3i64ZDtCXMa7n
				jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	VVm91ru5q4S = str(jVMHRouKgQFAESmd7B8ObTYy)
	rzRAq1oMQ7ykFn = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in VVm91ru5q4S for hht0cpXxWw2OzFS1jnUGebkJLBd85 in rzRAq1oMQ7ykFn):
		tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import JYR902sfml
	JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt(jVMHRouKgQFAESmd7B8ObTYy,r1NChsk39OMvT82YemDQnl5,'video',url)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if not search: search = UIf35nZEj1wylmq()
	if not search: return
	search = search.replace(' ','+')
	url = tle5V6jgvRfE+'/find/?find='+search
	uyt3pAHZk4(url,'search')
	return
def L1FsQxw6Afb7pcCe9Tr3qizXZ(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter=='': ydL2RstfT9BA3Hpe1SZIq,l3Uo4ThenPyJMua = '',''
	else: ydL2RstfT9BA3Hpe1SZIq,l3Uo4ThenPyJMua = filter.split('___')
	if type=='CATEGORIES':
		if GKp3oxlZhvX[0]+'==' not in ydL2RstfT9BA3Hpe1SZIq: cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = GKp3oxlZhvX[0]
		for AudBQkLFsrHKicIogThZyv in range(len(GKp3oxlZhvX[0:-1])):
			if GKp3oxlZhvX[AudBQkLFsrHKicIogThZyv]+'==' in ydL2RstfT9BA3Hpe1SZIq: cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = GKp3oxlZhvX[AudBQkLFsrHKicIogThZyv+1]
		rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&&'+cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo+'==0'
		SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&&'+cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo+'==0'
		hOSk91jGqtHsfwU2ExCV4YB = rrsgSnC5AFkbEvDPm6pyaRizM8.strip('&&')+'___'+SWxX6Q3CgwV7F.strip('&&')
		Rdgr0aTSzE5chex9W = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(l3Uo4ThenPyJMua,'modified_filters')
		M08MPGgsh4n5rKe = url+'//getposts??'+Rdgr0aTSzE5chex9W
	elif type=='FILTERS':
		jyRzHeOYXAW4oDrUS = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(ydL2RstfT9BA3Hpe1SZIq,'modified_values')
		jyRzHeOYXAW4oDrUS = BUTSkzgFC7(jyRzHeOYXAW4oDrUS)
		if l3Uo4ThenPyJMua!='': l3Uo4ThenPyJMua = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(l3Uo4ThenPyJMua,'modified_filters')
		if l3Uo4ThenPyJMua=='': M08MPGgsh4n5rKe = url
		else: M08MPGgsh4n5rKe = url+'//getposts??'+l3Uo4ThenPyJMua
		FF976NUWy3wVxBvP = RRpH79m8XhV6Sx4vIuwAyOlj(M08MPGgsh4n5rKe)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'أظهار قائمة الفيديو التي تم اختيارها ',FF976NUWy3wVxBvP,251,'','','filters')
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+' [[   '+jyRzHeOYXAW4oDrUS+'   ]]',FF976NUWy3wVxBvP,251,'','','filters')
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'POST',url,'',headers,'','','ARABSEED-FILTERS_MENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	QbG1BaPD3Ss2Yzj6yIiUFMRHO0N = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	HpAb7WIlejDYBmhTcfz86Gwtxis = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	H8n4oVq07uvJjCOwgzbyf6XR9Fs = QbG1BaPD3Ss2Yzj6yIiUFMRHO0N+HpAb7WIlejDYBmhTcfz86Gwtxis
	dict = {}
	for name,eFmOUji0173K,ziJLDVT8NM2QcgIpmE9A in H8n4oVq07uvJjCOwgzbyf6XR9Fs:
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			HKE5ebjfkuy = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-rate="(.*?)".*?<em>(.*?)</em>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			items = []
			for e0i4nPhusqdTaG,hht0cpXxWw2OzFS1jnUGebkJLBd85 in HKE5ebjfkuy: items.append([e0i4nPhusqdTaG,'',hht0cpXxWw2OzFS1jnUGebkJLBd85])
			eFmOUji0173K = 'rate'
			name = 'التقييم'
		else: eFmOUji0173K = items[0][1]
		if '==' not in M08MPGgsh4n5rKe: M08MPGgsh4n5rKe = url
		if type=='CATEGORIES':
			if cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo!=eFmOUji0173K: continue
			elif len(items)<=1:
				if eFmOUji0173K==GKp3oxlZhvX[-1]: uyt3pAHZk4(M08MPGgsh4n5rKe)
				else: L1FsQxw6Afb7pcCe9Tr3qizXZ(M08MPGgsh4n5rKe,'CATEGORIES___'+hOSk91jGqtHsfwU2ExCV4YB)
				return
			else:
				FF976NUWy3wVxBvP = RRpH79m8XhV6Sx4vIuwAyOlj(M08MPGgsh4n5rKe)
				if eFmOUji0173K==GKp3oxlZhvX[-1]: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع ',FF976NUWy3wVxBvP,251,'','','filters')
				else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع ',M08MPGgsh4n5rKe,254,'','',hOSk91jGqtHsfwU2ExCV4YB)
		elif type=='FILTERS':
			rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&&'+eFmOUji0173K+'==0'
			SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&&'+eFmOUji0173K+'==0'
			hOSk91jGqtHsfwU2ExCV4YB = rrsgSnC5AFkbEvDPm6pyaRizM8+'___'+SWxX6Q3CgwV7F
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع :'+name,M08MPGgsh4n5rKe,255,'','',hOSk91jGqtHsfwU2ExCV4YB)
		dict[eFmOUji0173K] = {}
		for e0i4nPhusqdTaG,aQ0kNq9gnYBKJ5yV6oRhXZ7ImfwreT,hht0cpXxWw2OzFS1jnUGebkJLBd85 in items:
			if e0i4nPhusqdTaG in ZLKHfqMEUdRupD: continue
			if 'الكل' in e0i4nPhusqdTaG: continue
			e0i4nPhusqdTaG = nnGHa80rMphqe1ukFtIRvAPs6W(e0i4nPhusqdTaG)
			RwcFvrfJ2ANZSizC6bqKeEo1UDdIQ,neZQycYAFqxLzkPhEWvM = e0i4nPhusqdTaG,e0i4nPhusqdTaG
			neZQycYAFqxLzkPhEWvM = name+': '+RwcFvrfJ2ANZSizC6bqKeEo1UDdIQ
			dict[eFmOUji0173K][hht0cpXxWw2OzFS1jnUGebkJLBd85] = neZQycYAFqxLzkPhEWvM
			rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&&'+eFmOUji0173K+'=='+RwcFvrfJ2ANZSizC6bqKeEo1UDdIQ
			SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&&'+eFmOUji0173K+'=='+hht0cpXxWw2OzFS1jnUGebkJLBd85
			RtPpz8FAEjIxU = rrsgSnC5AFkbEvDPm6pyaRizM8+'___'+SWxX6Q3CgwV7F
			if type=='FILTERS':
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+neZQycYAFqxLzkPhEWvM,url,255,'','',RtPpz8FAEjIxU)
			elif type=='CATEGORIES' and GKp3oxlZhvX[-2]+'==' in ydL2RstfT9BA3Hpe1SZIq:
				Rdgr0aTSzE5chex9W = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(SWxX6Q3CgwV7F,'modified_filters')
				TW6JIBgC971tjOE = url+'//getposts??'+Rdgr0aTSzE5chex9W
				FF976NUWy3wVxBvP = RRpH79m8XhV6Sx4vIuwAyOlj(TW6JIBgC971tjOE)
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+neZQycYAFqxLzkPhEWvM,FF976NUWy3wVxBvP,251,'','','filters')
			else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+neZQycYAFqxLzkPhEWvM,url,254,'','',RtPpz8FAEjIxU)
	return
GKp3oxlZhvX = ['category','country','release-year']
oQnWHm8MLwx56 = ['category','country','genre','release-year','language','quality','rate']
def RRpH79m8XhV6Sx4vIuwAyOlj(url):
	ESBUC5Mv2F = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',ESBUC5Mv2F)
	url = url.replace('/category/اخرى','')
	if ESBUC5Mv2F not in url: url = url+ESBUC5Mv2F
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(dY1a0xA6PKm7TOJSERt3sHU9Qp,mode):
	dY1a0xA6PKm7TOJSERt3sHU9Qp = dY1a0xA6PKm7TOJSERt3sHU9Qp.strip('&&')
	nvNkgT7iGQOyed,UJzegYmlGML35rasDAIx17Rhnk = {},''
	if '==' in dY1a0xA6PKm7TOJSERt3sHU9Qp:
		items = dY1a0xA6PKm7TOJSERt3sHU9Qp.split('&&')
		for hh4gUqS5JWf1saRZPXHD in items:
			DHcrLNnqExKjM8uvVlBhWd,hht0cpXxWw2OzFS1jnUGebkJLBd85 = hh4gUqS5JWf1saRZPXHD.split('==')
			nvNkgT7iGQOyed[DHcrLNnqExKjM8uvVlBhWd] = hht0cpXxWw2OzFS1jnUGebkJLBd85
	for key in oQnWHm8MLwx56:
		if key in list(nvNkgT7iGQOyed.keys()): hht0cpXxWw2OzFS1jnUGebkJLBd85 = nvNkgT7iGQOyed[key]
		else: hht0cpXxWw2OzFS1jnUGebkJLBd85 = '0'
		if '%' not in hht0cpXxWw2OzFS1jnUGebkJLBd85: hht0cpXxWw2OzFS1jnUGebkJLBd85 = TaEr2nR3f5e8oXzpy(hht0cpXxWw2OzFS1jnUGebkJLBd85)
		if mode=='modified_values' and hht0cpXxWw2OzFS1jnUGebkJLBd85!='0': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+' + '+hht0cpXxWw2OzFS1jnUGebkJLBd85
		elif mode=='modified_filters' and hht0cpXxWw2OzFS1jnUGebkJLBd85!='0': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+'&&'+key+'=='+hht0cpXxWw2OzFS1jnUGebkJLBd85
		elif mode=='all': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+'&&'+key+'=='+hht0cpXxWw2OzFS1jnUGebkJLBd85
	UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk.strip(' + ')
	UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk.strip('&&')
	return UJzegYmlGML35rasDAIx17Rhnk
# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'ALARAB'
headers = {'User-Agent':''}
Yc0eBRLpbCkm4gK7OqyzuHwU = '_KLA_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
def HgQCVwFx2Br(mode,url,text):
	if   mode==10: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==11: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url)
	elif mode==12: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==13: s4Bng5iAZQSTtpDw9 = btd6ag2XYUkHixqy5J7o9RfLu1MScm(url)
	elif mode==14: s4Bng5iAZQSTtpDw9 = QDvSPAW6cY()
	elif mode==15: s4Bng5iAZQSTtpDw9 = RRH7eDlLIr6()
	elif mode==16: s4Bng5iAZQSTtpDw9 = EkydzNVYBr1LigDKe()
	elif mode==19: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',19,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'آخر الإضافات','',14)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'مسلسلات رمضان','',15)
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,tle5V6jgvRfE,'',headers,'','ALARAB-MENU-1st')
	TIkiozSLCv6werb97mHQ0q4y3=E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('id="nav-slider"(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	AwBC6c180SErdjOIXT2uRnh5Z = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?>(.*?)<',AwBC6c180SErdjOIXT2uRnh5Z,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		title = title.strip(' ')
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,11)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('id="navbar"(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	f9AzGuXj0qgcNTy1 = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?>(.*?)<',f9AzGuXj0qgcNTy1,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,11)
	return M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
def RRH7eDlLIr6():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'جميع المسلسلات العربية',tle5V6jgvRfE+'/view-8/مسلسلات-عربية',11)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مسلسلات السنة الأخيرة','',16)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مسلسلات رمضان الأخيرة 1',tle5V6jgvRfE+'/view-8/مسلسلات-رمضان-2022',11)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مسلسلات رمضان الأخيرة 2',tle5V6jgvRfE+'/view-8/مسلسلات-رمضان-2023',11)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مسلسلات رمضان 2023',tle5V6jgvRfE+'/ramadan2023/مصرية',11)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مسلسلات رمضان 2022',tle5V6jgvRfE+'/ramadan2022/مصرية',11)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مسلسلات رمضان 2021',tle5V6jgvRfE+'/ramadan2021/مصرية',11)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مسلسلات رمضان 2020',tle5V6jgvRfE+'/ramadan2020/مصرية',11)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مسلسلات رمضان 2019',tle5V6jgvRfE+'/ramadan2019/مصرية',11)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مسلسلات رمضان 2018',tle5V6jgvRfE+'/ramadan2018/مصرية',11)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مسلسلات رمضان 2017',tle5V6jgvRfE+'/ramadan2017/مصرية',11)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مسلسلات رمضان 2016',tle5V6jgvRfE+'/ramadan2016/مصرية',11)
	return
def QDvSPAW6cY():
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,tle5V6jgvRfE,'',headers,True,'ALARAB-LATEST-1st')
	TIkiozSLCv6werb97mHQ0q4y3=E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('heading-top(.*?)div class=',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]+TIkiozSLCv6werb97mHQ0q4y3[1]
	items=E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title in items:
		url = tle5V6jgvRfE + ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		if 'series' in url: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,11,Q2qmuDRrC9ikcaJK7gtUHXNW)
		else: tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,12,Q2qmuDRrC9ikcaJK7gtUHXNW)
	return
def uyt3pAHZk4(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'',headers,True,True,'ALARAB-TITLES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('video-category(.*?)right_content',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not TIkiozSLCv6werb97mHQ0q4y3: return
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	iiOR3UoleLk = False
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	jjR8ftoEXpPxVF6JerbHZuzv7ic,gzjIKdLQR8Gu = [],[]
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title in items:
		if title=='': title = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('/')[-1].replace('-',' ')
		mbGei9dIvrTohtJ = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(\d+)',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if mbGei9dIvrTohtJ: mbGei9dIvrTohtJ = int(mbGei9dIvrTohtJ[0])
		else: mbGei9dIvrTohtJ = 0
		gzjIKdLQR8Gu.append([Q2qmuDRrC9ikcaJK7gtUHXNW,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,mbGei9dIvrTohtJ])
	gzjIKdLQR8Gu = sorted(gzjIKdLQR8Gu, reverse=True, key=lambda key: key[3])
	for Q2qmuDRrC9ikcaJK7gtUHXNW,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,mbGei9dIvrTohtJ in gzjIKdLQR8Gu:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE + ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي','')
		title = title.replace('عالية على العرب','')
		title = title.replace('مشاهدة مباشرة','')
		title = title.replace('اون لاين','')
		title = title.replace('اونلاين','')
		title = title.replace('بجودة عالية','')
		title = title.replace('جودة عالية','')
		title = title.replace('بدون تحميل','')
		title = title.replace('على العرب','')
		title = title.replace('مباشرة','')
		title = title.strip(' ').replace('  ',' ').replace('  ',' ')
		title = '_MOD_'+title
		neZQycYAFqxLzkPhEWvM = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			EQw62xjXSJmzrRt = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(.*?) الحلقة \d+',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if EQw62xjXSJmzrRt: neZQycYAFqxLzkPhEWvM = EQw62xjXSJmzrRt[0]
		if neZQycYAFqxLzkPhEWvM not in jjR8ftoEXpPxVF6JerbHZuzv7ic:
			jjR8ftoEXpPxVF6JerbHZuzv7ic.append(neZQycYAFqxLzkPhEWvM)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+neZQycYAFqxLzkPhEWvM,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,13,Q2qmuDRrC9ikcaJK7gtUHXNW)
				iiOR3UoleLk = True
			elif 'series' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,11,Q2qmuDRrC9ikcaJK7gtUHXNW)
				iiOR3UoleLk = True
			else:
				tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,12,Q2qmuDRrC9ikcaJK7gtUHXNW)
				iiOR3UoleLk = True
	if iiOR3UoleLk:
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,tsMKaFVh1ZN2BIXEcvTejxR5DP in items:
			url = tle5V6jgvRfE + ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+tsMKaFVh1ZN2BIXEcvTejxR5DP,url,11)
	return
def btd6ag2XYUkHixqy5J7o9RfLu1MScm(url):
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,url,'',headers,True,'ALARAB-EPISODES-1st')
	Xt1ErNwZWQBHvC5mhKo = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(/series.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	M08MPGgsh4n5rKe = tle5V6jgvRfE+Xt1ErNwZWQBHvC5mhKo[0]
	s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(M08MPGgsh4n5rKe)
	return
def dlropqS0vO9K7W4z(url):
	jVMHRouKgQFAESmd7B8ObTYy = []
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(jEPuRTVbZg4MCimJxzf3I6wFa,url,'',headers,True,'ALARAB-PLAY-1st')
	M08MPGgsh4n5rKe = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="resp-iframe" src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if M08MPGgsh4n5rKe:
		M08MPGgsh4n5rKe = M08MPGgsh4n5rKe[0]
		cc0O1M4e5jtfoq = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('^(http.*?)(http.*?)$',M08MPGgsh4n5rKe,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if cc0O1M4e5jtfoq:
			TTGV5OeusamgqYMHj4EZp81nXdbB = cc0O1M4e5jtfoq[0][0]
			b20z5RkMF6GYq9uE8Q4a,ahJVN4nZfeqg6CiL2ovHkwy = cc0O1M4e5jtfoq[0][1].rsplit('/',1)
			TW6JIBgC971tjOE = b20z5RkMF6GYq9uE8Q4a+'?named=__watch'
			jVMHRouKgQFAESmd7B8ObTYy.append(TW6JIBgC971tjOE)
			FF976NUWy3wVxBvP = TTGV5OeusamgqYMHj4EZp81nXdbB+ahJVN4nZfeqg6CiL2ovHkwy
		else:
			flARjI3NM9CQnWY1xk7 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,M08MPGgsh4n5rKe,'',headers,False,'ALARAB-PLAY-2nd')
			M08MPGgsh4n5rKe = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"src": "(.*?)"',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if M08MPGgsh4n5rKe:
				M08MPGgsh4n5rKe = M08MPGgsh4n5rKe[0]+'?named=__watch__m3u8'
				jVMHRouKgQFAESmd7B8ObTYy.append(M08MPGgsh4n5rKe)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('searchBox(.*?)<style>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		M08MPGgsh4n5rKe = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if M08MPGgsh4n5rKe:
			M08MPGgsh4n5rKe = M08MPGgsh4n5rKe[0]+'?named=__watch'
			jVMHRouKgQFAESmd7B8ObTYy.append(M08MPGgsh4n5rKe)
	import JYR902sfml
	JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt(jVMHRouKgQFAESmd7B8ObTYy,r1NChsk39OMvT82YemDQnl5,'video',url)
	return
def EkydzNVYBr1LigDKe():
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,tle5V6jgvRfE,'',headers,True,'ALARAB-RAMADAN-1st')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('id="content_sec"(.*?)id="left_content"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	tt7dqr5nZYvFeMT3Wb = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('/ramadan([0-9]+)/',str(items),E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	tt7dqr5nZYvFeMT3Wb = tt7dqr5nZYvFeMT3Wb[0]
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		url = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		title = title.strip(' ')+' '+tt7dqr5nZYvFeMT3Wb
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,11)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if search=='': search = UIf35nZEj1wylmq()
	if search=='': return
	DbEfLQSBFCTt2mMqvrsIVnjJ6 = search.replace(' ','+')
	url = tle5V6jgvRfE + "/q/" + DbEfLQSBFCTt2mMqvrsIVnjJ6
	s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url)
	return
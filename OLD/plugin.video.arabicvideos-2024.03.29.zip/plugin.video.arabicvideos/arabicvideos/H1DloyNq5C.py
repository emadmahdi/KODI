# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'ALFATIMI'
Yc0eBRLpbCkm4gK7OqyzuHwU = '_FTM_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
nQY70wrcekLWH5 = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
XJH4Wieryg = ['3030','628']
def HgQCVwFx2Br(mode,url,text):
	if   mode==60: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==61: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url,text)
	elif mode==62: s4Bng5iAZQSTtpDw9 = btd6ag2XYUkHixqy5J7o9RfLu1MScm(url)
	elif mode==63: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==64: s4Bng5iAZQSTtpDw9 = JhSPs60GXcE(text)
	elif mode==69: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',69,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'ما يتم مشاهدته الان',tle5V6jgvRfE,64,'','','recent_viewed_vids')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'الاكثر مشاهدة',tle5V6jgvRfE,64,'','','most_viewed_vids')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'اضيفت مؤخرا',tle5V6jgvRfE,64,'','','recently_added_vids')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'فيديو عشوائي',tle5V6jgvRfE,64,'','','random_vids')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'افلام ومسلسلات',tle5V6jgvRfE,61,'','','-1')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'البرامج الدينية',tle5V6jgvRfE,61,'','','-2')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'English Videos',tle5V6jgvRfE,61,'','','-3')
	return ''
def uyt3pAHZk4(url,cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo):
	kUQh3I9xjzn = ''
	if cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo not in ['-1','-2','-3']: kUQh3I9xjzn = '?cat='+cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo
	M08MPGgsh4n5rKe = tle5V6jgvRfE+'/menu_level.php'+kUQh3I9xjzn
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,M08MPGgsh4n5rKe,'','','','ALFATIMI-TITLES-1st')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	PqWVtlH7S4aicEwOrL,iiOR3UoleLk = False,False
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,count in items:
		title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
		title = title.strip(' ')
		if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = 'http:'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		kUQh3I9xjzn = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('cat=(.*?)&',ZCimQhV5lovgspAYzHq1Ef27u8ja4R,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)[0]
		if cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo==kUQh3I9xjzn: PqWVtlH7S4aicEwOrL = True
		elif PqWVtlH7S4aicEwOrL 	or (cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo=='-1' and kUQh3I9xjzn in nQY70wrcekLWH5)  						or (cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo=='-2' and kUQh3I9xjzn not in XJH4Wieryg and kUQh3I9xjzn not in nQY70wrcekLWH5)  						or (cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo=='-3' and kUQh3I9xjzn in XJH4Wieryg):
							if count=='1': tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,63)
							else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,61,'','',kUQh3I9xjzn)
							iiOR3UoleLk = True
	if not iiOR3UoleLk: btd6ag2XYUkHixqy5J7o9RfLu1MScm(url)
	return
def btd6ag2XYUkHixqy5J7o9RfLu1MScm(url):
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,url,'','',True,'ALFATIMI-EPISODES-1st')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('pagination(.*?)id="footer',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ''
	for Q2qmuDRrC9ikcaJK7gtUHXNW,title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
		title = title.replace('Add','').replace('to Quicklist','').strip(' ')
		if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = 'http:'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,63,Q2qmuDRrC9ikcaJK7gtUHXNW)
	TIkiozSLCv6werb97mHQ0q4y3=E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(.*?)div',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A=TIkiozSLCv6werb97mHQ0q4y3[0]
	ziJLDVT8NM2QcgIpmE9A=E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('pagination(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)[0]
	items=E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	M08MPGgsh4n5rKe = url.split('?')[0]
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,u5B7sfGbpTt in items:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = M08MPGgsh4n5rKe + ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		title = nnGHa80rMphqe1ukFtIRvAPs6W(u5B7sfGbpTt)
		title = 'صفحة ' + title
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,62)
	return ZCimQhV5lovgspAYzHq1Ef27u8ja4R
def dlropqS0vO9K7W4z(url):
	if 'videos.php' in url: url = btd6ag2XYUkHixqy5J7o9RfLu1MScm(url)
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,url,'','',True,'ALFATIMI-PLAY-1st')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('playlistfile:"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	pSAuLjYqhgc9brWFKs7Pa4J(url,r1NChsk39OMvT82YemDQnl5,'video')
	return
def JhSPs60GXcE(cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo):
	VVNkoRCUm96MbtuqgrOe = { 'mode' : cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = cswW2KC5FOH64vq97ZkNR(VVNkoRCUm96MbtuqgrOe)
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(jEPuRTVbZg4MCimJxzf3I6wFa,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,Q2qmuDRrC9ikcaJK7gtUHXNW in items:
		title = title.strip(' ')
		if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = 'http:'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,63,Q2qmuDRrC9ikcaJK7gtUHXNW)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if search=='': search = UIf35nZEj1wylmq()
	if search=='': return
	DbEfLQSBFCTt2mMqvrsIVnjJ6 = search.replace(' ','+')
	url = tle5V6jgvRfE + '/search_result.php?query=' + DbEfLQSBFCTt2mMqvrsIVnjJ6
	btd6ag2XYUkHixqy5J7o9RfLu1MScm(url)
	return
# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'YOUTUBE'
Yc0eBRLpbCkm4gK7OqyzuHwU = '_YUT_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
MR7ph2I8fB3KFb0HvrqXm = 0
def HgQCVwFx2Br(mode,url,text,type,tsMKaFVh1ZN2BIXEcvTejxR5DP,name,OHMhVx5cw76slynUDdF24jgbkNG):
	if	 mode==140: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==141: s4Bng5iAZQSTtpDw9 = P69W8pdmFXnUlaQuH(url,name,OHMhVx5cw76slynUDdF24jgbkNG)
	elif mode==143: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url,type)
	elif mode==144: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url,tsMKaFVh1ZN2BIXEcvTejxR5DP,text)
	elif mode==145: s4Bng5iAZQSTtpDw9 = r2i5GM9gVSh0b4DLoYd8PB(url,tsMKaFVh1ZN2BIXEcvTejxR5DP)
	elif mode==147: s4Bng5iAZQSTtpDw9 = YRM5UzTFPfouJAe()
	elif mode==148: s4Bng5iAZQSTtpDw9 = KbIx4ATeylYoXs6L8Qd()
	elif mode==149: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	if 0:
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'قائمة',tle5V6jgvRfE+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'شخص',tle5V6jgvRfE+'/user/TCNofficial',144)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'موقع',tle5V6jgvRfE+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'حساب',tle5V6jgvRfE+'/@TheSocialCTV',144)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'العاب',tle5V6jgvRfE+'/gaming',144)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'افلام',tle5V6jgvRfE+'/feed/storefront',144)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مختارات',tle5V6jgvRfE+'/feed/guide_builder',144)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'قصيرة',tle5V6jgvRfE+'/shorts',144,'','','_REMEMBERRESULTS_')
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'تصفح',tle5V6jgvRfE+'/youtubei/v1/guide?key=',144)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'رئيسية',tle5V6jgvRfE+'',144)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'رائج',tle5V6jgvRfE+'/feed/trending?bp=',144)
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',149,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الرئيسية',tle5V6jgvRfE+'',144)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الرائجة',tle5V6jgvRfE+'/feed/trending',144)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'التصفح',tle5V6jgvRfE+'/youtubei/v1/guide?key=',144)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'القصيرة',tle5V6jgvRfE+'/shorts',144,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مختارات يوتيوب',tle5V6jgvRfE+'/feed/guide_builder',144)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مختارات البرنامج','',290)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث: قنوات عربية','',147)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث: قنوات أجنبية','',148)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث: افلام عربية',tle5V6jgvRfE+'/results?search_query=فيلم',144)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث: افلام اجنبية',tle5V6jgvRfE+'/results?search_query=movie',144)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث: مسرحيات عربية',tle5V6jgvRfE+'/results?search_query=مسرحية',144)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث: مسلسلات عربية',tle5V6jgvRfE+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث: مسلسلات اجنبية',tle5V6jgvRfE+'/results?search_query=series&sp=EgIQAw==',144)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث: مسلسلات كارتون',tle5V6jgvRfE+'/results?search_query=كارتون&sp=EgIQAw==',144)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث: خطبة المرجعية',tle5V6jgvRfE+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def P69W8pdmFXnUlaQuH(url,name,OHMhVx5cw76slynUDdF24jgbkNG):
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'CHNL:  '+name,url,144,OHMhVx5cw76slynUDdF24jgbkNG)
	return
def YRM5UzTFPfouJAe():
	uyt3pAHZk4(tle5V6jgvRfE+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def KbIx4ATeylYoXs6L8Qd():
	uyt3pAHZk4(tle5V6jgvRfE+'/results?search_query=tv&sp=EgJAAQ==')
	return
def dlropqS0vO9K7W4z(url,type):
	url = url.split('&',1)[0]
	import JYR902sfml
	JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt([url],r1NChsk39OMvT82YemDQnl5,type,url)
	return
def DCZT5nlc3Q2FrpSj8e9tf(Y67JdZSKDsTBAmlnag4wGLWRHx53I8,url,EeWNT4ZgLwnchCSIjJKX):
	level,gv4BuAcOEeq9brtYoH5J0d8NF,touxMg0JaXDE2Y3kjnSw86VH,LLRJe9dn0lGAVcrivg7p = EeWNT4ZgLwnchCSIjJKX.split('::')
	P5irnaYtSdNHyRBWsj6vEA,yhLw27cHWpBCJ6jAPseNSVgFG85 = [],[]
	if '/youtubei/v1/browse' in url: P5irnaYtSdNHyRBWsj6vEA.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: P5irnaYtSdNHyRBWsj6vEA.append("yccc['onResponseReceivedCommands']")
	if level=='1': P5irnaYtSdNHyRBWsj6vEA.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	P5irnaYtSdNHyRBWsj6vEA.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	P5irnaYtSdNHyRBWsj6vEA.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	P5irnaYtSdNHyRBWsj6vEA.append("yccc['entries']")
	P5irnaYtSdNHyRBWsj6vEA.append("yccc['items'][3]['guideSectionRenderer']['items']")
	VlHic56zXSJD,tfAWBUFKQ07,DYvV0U5euGQncTt = qaw29IkhU03FpWQesr4Bb(Y67JdZSKDsTBAmlnag4wGLWRHx53I8,'',P5irnaYtSdNHyRBWsj6vEA)
	if level=='1' and VlHic56zXSJD:
		if len(tfAWBUFKQ07)>1 and 'search_query' not in url:
			for SSpkVJbD9mXviY7twW4Ox5gLRcsCA in range(len(tfAWBUFKQ07)):
				gv4BuAcOEeq9brtYoH5J0d8NF = str(SSpkVJbD9mXviY7twW4Ox5gLRcsCA)
				P5irnaYtSdNHyRBWsj6vEA = []
				P5irnaYtSdNHyRBWsj6vEA.append("yddd["+gv4BuAcOEeq9brtYoH5J0d8NF+"]['reloadContinuationItemsCommand']['continuationItems']")
				P5irnaYtSdNHyRBWsj6vEA.append("yddd["+gv4BuAcOEeq9brtYoH5J0d8NF+"]['command']")
				P5irnaYtSdNHyRBWsj6vEA.append("yddd["+gv4BuAcOEeq9brtYoH5J0d8NF+"]")
				VZHWjJTrAPKG1eLEsxpYo2tS5,hh4gUqS5JWf1saRZPXHD,mbGei9dIvrTohtJ = qaw29IkhU03FpWQesr4Bb(tfAWBUFKQ07,'',P5irnaYtSdNHyRBWsj6vEA)
				if VZHWjJTrAPKG1eLEsxpYo2tS5: yhLw27cHWpBCJ6jAPseNSVgFG85.append([hh4gUqS5JWf1saRZPXHD,url,'2::'+gv4BuAcOEeq9brtYoH5J0d8NF+'::0::0'])
			P5irnaYtSdNHyRBWsj6vEA.append("yccc['continuationEndpoint']")
			VZHWjJTrAPKG1eLEsxpYo2tS5,hh4gUqS5JWf1saRZPXHD,mbGei9dIvrTohtJ = qaw29IkhU03FpWQesr4Bb(Y67JdZSKDsTBAmlnag4wGLWRHx53I8,'',P5irnaYtSdNHyRBWsj6vEA)
			if VZHWjJTrAPKG1eLEsxpYo2tS5 and yhLw27cHWpBCJ6jAPseNSVgFG85 and 'continuationCommand' in list(hh4gUqS5JWf1saRZPXHD.keys()):
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/my_main_page_shorts_link'
				yhLw27cHWpBCJ6jAPseNSVgFG85.append([hh4gUqS5JWf1saRZPXHD,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,'1::0::0::0'])
	return tfAWBUFKQ07,VlHic56zXSJD,yhLw27cHWpBCJ6jAPseNSVgFG85,DYvV0U5euGQncTt
def dx12RUvBHJTfXZrwmFhVuCtjE3(Y67JdZSKDsTBAmlnag4wGLWRHx53I8,tfAWBUFKQ07,url,EeWNT4ZgLwnchCSIjJKX):
	level,gv4BuAcOEeq9brtYoH5J0d8NF,touxMg0JaXDE2Y3kjnSw86VH,LLRJe9dn0lGAVcrivg7p = EeWNT4ZgLwnchCSIjJKX.split('::')
	P5irnaYtSdNHyRBWsj6vEA,Gz31aKkXbsMFRCJynocQNm = [],[]
	P5irnaYtSdNHyRBWsj6vEA.append("yddd[0]['itemSectionRenderer']['contents']")
	P5irnaYtSdNHyRBWsj6vEA.append("yddd["+gv4BuAcOEeq9brtYoH5J0d8NF+"]['reloadContinuationItemsCommand']['continuationItems']")
	P5irnaYtSdNHyRBWsj6vEA.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: P5irnaYtSdNHyRBWsj6vEA.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: P5irnaYtSdNHyRBWsj6vEA.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	P5irnaYtSdNHyRBWsj6vEA.append("yddd["+gv4BuAcOEeq9brtYoH5J0d8NF+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		P5irnaYtSdNHyRBWsj6vEA.append("yddd["+gv4BuAcOEeq9brtYoH5J0d8NF+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	P5irnaYtSdNHyRBWsj6vEA.append("yddd["+gv4BuAcOEeq9brtYoH5J0d8NF+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	P5irnaYtSdNHyRBWsj6vEA.append("yddd["+gv4BuAcOEeq9brtYoH5J0d8NF+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	P5irnaYtSdNHyRBWsj6vEA.append("yddd["+gv4BuAcOEeq9brtYoH5J0d8NF+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	P5irnaYtSdNHyRBWsj6vEA.append("yddd["+gv4BuAcOEeq9brtYoH5J0d8NF+"]")
	kiVygoYTldWe5UQ,QNUbZz0aW8k5fco6iv9JTI,i0mTWusC3tSdUN = qaw29IkhU03FpWQesr4Bb(tfAWBUFKQ07,'',P5irnaYtSdNHyRBWsj6vEA)
	if level=='2' and kiVygoYTldWe5UQ:
		if len(QNUbZz0aW8k5fco6iv9JTI)>1:
			for SSpkVJbD9mXviY7twW4Ox5gLRcsCA in range(len(QNUbZz0aW8k5fco6iv9JTI)):
				touxMg0JaXDE2Y3kjnSw86VH = str(SSpkVJbD9mXviY7twW4Ox5gLRcsCA)
				P5irnaYtSdNHyRBWsj6vEA = []
				P5irnaYtSdNHyRBWsj6vEA.append("yeee["+touxMg0JaXDE2Y3kjnSw86VH+"]['richSectionRenderer']['content']")
				P5irnaYtSdNHyRBWsj6vEA.append("yeee["+touxMg0JaXDE2Y3kjnSw86VH+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				P5irnaYtSdNHyRBWsj6vEA.append("yeee["+touxMg0JaXDE2Y3kjnSw86VH+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				P5irnaYtSdNHyRBWsj6vEA.append("yeee["+touxMg0JaXDE2Y3kjnSw86VH+"]['itemSectionRenderer']['contents'][0]")
				P5irnaYtSdNHyRBWsj6vEA.append("yeee["+touxMg0JaXDE2Y3kjnSw86VH+"]['richItemRenderer']['content']")
				P5irnaYtSdNHyRBWsj6vEA.append("yeee["+touxMg0JaXDE2Y3kjnSw86VH+"]")
				VZHWjJTrAPKG1eLEsxpYo2tS5,hh4gUqS5JWf1saRZPXHD,mbGei9dIvrTohtJ = qaw29IkhU03FpWQesr4Bb(QNUbZz0aW8k5fco6iv9JTI,'',P5irnaYtSdNHyRBWsj6vEA)
				if VZHWjJTrAPKG1eLEsxpYo2tS5: Gz31aKkXbsMFRCJynocQNm.append([hh4gUqS5JWf1saRZPXHD,url,'3::'+gv4BuAcOEeq9brtYoH5J0d8NF+'::'+touxMg0JaXDE2Y3kjnSw86VH+'::0'])
			P5irnaYtSdNHyRBWsj6vEA.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			P5irnaYtSdNHyRBWsj6vEA.append("yddd[1]")
			VZHWjJTrAPKG1eLEsxpYo2tS5,hh4gUqS5JWf1saRZPXHD,mbGei9dIvrTohtJ = qaw29IkhU03FpWQesr4Bb(tfAWBUFKQ07,'',P5irnaYtSdNHyRBWsj6vEA)
			if VZHWjJTrAPKG1eLEsxpYo2tS5 and Gz31aKkXbsMFRCJynocQNm and 'continuationItemRenderer' in list(hh4gUqS5JWf1saRZPXHD.keys()):
				Gz31aKkXbsMFRCJynocQNm.append([hh4gUqS5JWf1saRZPXHD,url,'3::0::0::0'])
	return QNUbZz0aW8k5fco6iv9JTI,kiVygoYTldWe5UQ,Gz31aKkXbsMFRCJynocQNm,i0mTWusC3tSdUN
def Gq1ctQVxaLZ8RgwAPMWBTD6yJ(Y67JdZSKDsTBAmlnag4wGLWRHx53I8,QNUbZz0aW8k5fco6iv9JTI,url,EeWNT4ZgLwnchCSIjJKX):
	level,gv4BuAcOEeq9brtYoH5J0d8NF,touxMg0JaXDE2Y3kjnSw86VH,LLRJe9dn0lGAVcrivg7p = EeWNT4ZgLwnchCSIjJKX.split('::')
	P5irnaYtSdNHyRBWsj6vEA,AsGc38CVhDn0QM9WX4Smetf = [],[]
	P5irnaYtSdNHyRBWsj6vEA.append("yeee["+touxMg0JaXDE2Y3kjnSw86VH+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	P5irnaYtSdNHyRBWsj6vEA.append("yeee["+touxMg0JaXDE2Y3kjnSw86VH+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	P5irnaYtSdNHyRBWsj6vEA.append("yeee["+touxMg0JaXDE2Y3kjnSw86VH+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	P5irnaYtSdNHyRBWsj6vEA.append("yeee["+touxMg0JaXDE2Y3kjnSw86VH+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	P5irnaYtSdNHyRBWsj6vEA.append("yeee["+touxMg0JaXDE2Y3kjnSw86VH+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	P5irnaYtSdNHyRBWsj6vEA.append("yeee["+touxMg0JaXDE2Y3kjnSw86VH+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	P5irnaYtSdNHyRBWsj6vEA.append("yeee["+touxMg0JaXDE2Y3kjnSw86VH+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	P5irnaYtSdNHyRBWsj6vEA.append("yeee["+touxMg0JaXDE2Y3kjnSw86VH+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	P5irnaYtSdNHyRBWsj6vEA.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	P5irnaYtSdNHyRBWsj6vEA.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	P5irnaYtSdNHyRBWsj6vEA.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	P5irnaYtSdNHyRBWsj6vEA.append("yeee["+touxMg0JaXDE2Y3kjnSw86VH+"]['reelShelfRenderer']['items']")
	P5irnaYtSdNHyRBWsj6vEA.append("yeee["+touxMg0JaXDE2Y3kjnSw86VH+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	P5irnaYtSdNHyRBWsj6vEA.append("yeee")
	An3vuFf2G1ocPDWlKVHrCk50Nbyemz,HHXSeDVPxB3K29AQ,tCdvOhBreSQGUz = qaw29IkhU03FpWQesr4Bb(QNUbZz0aW8k5fco6iv9JTI,'',P5irnaYtSdNHyRBWsj6vEA)
	if level=='3' and An3vuFf2G1ocPDWlKVHrCk50Nbyemz:
		if len(HHXSeDVPxB3K29AQ)>0:
			for SSpkVJbD9mXviY7twW4Ox5gLRcsCA in range(len(HHXSeDVPxB3K29AQ)):
				LLRJe9dn0lGAVcrivg7p = str(SSpkVJbD9mXviY7twW4Ox5gLRcsCA)
				P5irnaYtSdNHyRBWsj6vEA = []
				P5irnaYtSdNHyRBWsj6vEA.append("yfff["+LLRJe9dn0lGAVcrivg7p+"]['richItemRenderer']['content']")
				P5irnaYtSdNHyRBWsj6vEA.append("yfff["+LLRJe9dn0lGAVcrivg7p+"]['gameCardRenderer']['game']")
				P5irnaYtSdNHyRBWsj6vEA.append("yfff["+LLRJe9dn0lGAVcrivg7p+"]['itemSectionRenderer']['contents'][0]")
				P5irnaYtSdNHyRBWsj6vEA.append("yfff["+LLRJe9dn0lGAVcrivg7p+"]")
				VZHWjJTrAPKG1eLEsxpYo2tS5,hh4gUqS5JWf1saRZPXHD,mbGei9dIvrTohtJ = qaw29IkhU03FpWQesr4Bb(HHXSeDVPxB3K29AQ,'',P5irnaYtSdNHyRBWsj6vEA)
				if VZHWjJTrAPKG1eLEsxpYo2tS5: AsGc38CVhDn0QM9WX4Smetf.append([hh4gUqS5JWf1saRZPXHD,url,'4::'+gv4BuAcOEeq9brtYoH5J0d8NF+'::'+touxMg0JaXDE2Y3kjnSw86VH+'::'+LLRJe9dn0lGAVcrivg7p])
	return HHXSeDVPxB3K29AQ,An3vuFf2G1ocPDWlKVHrCk50Nbyemz,AsGc38CVhDn0QM9WX4Smetf,tCdvOhBreSQGUz
def qaw29IkhU03FpWQesr4Bb(xvj7ObtqTw1IU3fQuLDC,asSviLeQ41YWRC5,VYsQ2nbf3dM58cLXGga4ZUeKEwq):
	Y67JdZSKDsTBAmlnag4wGLWRHx53I8,asSviLeQ41YWRC5 = xvj7ObtqTw1IU3fQuLDC,asSviLeQ41YWRC5
	tfAWBUFKQ07,asSviLeQ41YWRC5 = xvj7ObtqTw1IU3fQuLDC,asSviLeQ41YWRC5
	QNUbZz0aW8k5fco6iv9JTI,asSviLeQ41YWRC5 = xvj7ObtqTw1IU3fQuLDC,asSviLeQ41YWRC5
	HHXSeDVPxB3K29AQ,asSviLeQ41YWRC5 = xvj7ObtqTw1IU3fQuLDC,asSviLeQ41YWRC5
	hh4gUqS5JWf1saRZPXHD,z1rQvuHt9Di3oFb0mOSBfdpW5J = xvj7ObtqTw1IU3fQuLDC,asSviLeQ41YWRC5
	count = len(VYsQ2nbf3dM58cLXGga4ZUeKEwq)
	for Deiz7ocWQjVnIg in range(count):
		try:
			qVm6CTx7Ji1 = eval(VYsQ2nbf3dM58cLXGga4ZUeKEwq[Deiz7ocWQjVnIg])
			return True,qVm6CTx7Ji1,Deiz7ocWQjVnIg+1
		except: pass
	return False,'',0
def uyt3pAHZk4(url,EeWNT4ZgLwnchCSIjJKX='',data=''):
	yhLw27cHWpBCJ6jAPseNSVgFG85,Gz31aKkXbsMFRCJynocQNm,AsGc38CVhDn0QM9WX4Smetf = [],[],[]
	if '::' not in EeWNT4ZgLwnchCSIjJKX: EeWNT4ZgLwnchCSIjJKX = '1::0::0::0'
	level,gv4BuAcOEeq9brtYoH5J0d8NF,touxMg0JaXDE2Y3kjnSw86VH,LLRJe9dn0lGAVcrivg7p = EeWNT4ZgLwnchCSIjJKX.split('::')
	if level=='4': level,gv4BuAcOEeq9brtYoH5J0d8NF,touxMg0JaXDE2Y3kjnSw86VH,LLRJe9dn0lGAVcrivg7p = '1',gv4BuAcOEeq9brtYoH5J0d8NF,touxMg0JaXDE2Y3kjnSw86VH,LLRJe9dn0lGAVcrivg7p
	data = data.replace('_REMEMBERRESULTS_','')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,Y67JdZSKDsTBAmlnag4wGLWRHx53I8,bhfgckoLVtsA2DXv = htfj5BngX2PKymacbAU(url,data)
	EeWNT4ZgLwnchCSIjJKX = level+'::'+gv4BuAcOEeq9brtYoH5J0d8NF+'::'+touxMg0JaXDE2Y3kjnSw86VH+'::'+LLRJe9dn0lGAVcrivg7p
	if level in ['1','2','3']:
		tfAWBUFKQ07,VlHic56zXSJD,yhLw27cHWpBCJ6jAPseNSVgFG85,DYvV0U5euGQncTt = DCZT5nlc3Q2FrpSj8e9tf(Y67JdZSKDsTBAmlnag4wGLWRHx53I8,url,EeWNT4ZgLwnchCSIjJKX)
		if not VlHic56zXSJD: return
		Q5vj6sJXBRNUeig7F = len(yhLw27cHWpBCJ6jAPseNSVgFG85)
		if Q5vj6sJXBRNUeig7F<2:
			if level=='1': level = '2'
			yhLw27cHWpBCJ6jAPseNSVgFG85 = []
	EeWNT4ZgLwnchCSIjJKX = level+'::'+gv4BuAcOEeq9brtYoH5J0d8NF+'::'+touxMg0JaXDE2Y3kjnSw86VH+'::'+LLRJe9dn0lGAVcrivg7p
	if level in ['2','3']:
		QNUbZz0aW8k5fco6iv9JTI,kiVygoYTldWe5UQ,Gz31aKkXbsMFRCJynocQNm,i0mTWusC3tSdUN = dx12RUvBHJTfXZrwmFhVuCtjE3(Y67JdZSKDsTBAmlnag4wGLWRHx53I8,tfAWBUFKQ07,url,EeWNT4ZgLwnchCSIjJKX)
		if not kiVygoYTldWe5UQ: return
		LBVbNjJdYz18XKICRsAliSu2Ta5gEF = len(Gz31aKkXbsMFRCJynocQNm)
		if LBVbNjJdYz18XKICRsAliSu2Ta5gEF<2:
			if level=='2': level = '3'
			Gz31aKkXbsMFRCJynocQNm = []
	EeWNT4ZgLwnchCSIjJKX = level+'::'+gv4BuAcOEeq9brtYoH5J0d8NF+'::'+touxMg0JaXDE2Y3kjnSw86VH+'::'+LLRJe9dn0lGAVcrivg7p
	if level in ['3']:
		HHXSeDVPxB3K29AQ,An3vuFf2G1ocPDWlKVHrCk50Nbyemz,AsGc38CVhDn0QM9WX4Smetf,tCdvOhBreSQGUz = Gq1ctQVxaLZ8RgwAPMWBTD6yJ(Y67JdZSKDsTBAmlnag4wGLWRHx53I8,QNUbZz0aW8k5fco6iv9JTI,url,EeWNT4ZgLwnchCSIjJKX)
		if not An3vuFf2G1ocPDWlKVHrCk50Nbyemz: return
		X6y8hVTAPOf30E = len(AsGc38CVhDn0QM9WX4Smetf)
	for hh4gUqS5JWf1saRZPXHD,url,EeWNT4ZgLwnchCSIjJKX in yhLw27cHWpBCJ6jAPseNSVgFG85+Gz31aKkXbsMFRCJynocQNm+AsGc38CVhDn0QM9WX4Smetf:
		vhYA8y52BjF6DuEkWUqpaNsitZ = VVbxwKtN5Crkjl2UJGqB(hh4gUqS5JWf1saRZPXHD,url,EeWNT4ZgLwnchCSIjJKX)
	return
def VVbxwKtN5Crkjl2UJGqB(hh4gUqS5JWf1saRZPXHD,url='',EeWNT4ZgLwnchCSIjJKX=''):
	if '::' in EeWNT4ZgLwnchCSIjJKX: level,gv4BuAcOEeq9brtYoH5J0d8NF,touxMg0JaXDE2Y3kjnSw86VH,LLRJe9dn0lGAVcrivg7p = EeWNT4ZgLwnchCSIjJKX.split('::')
	else: level,gv4BuAcOEeq9brtYoH5J0d8NF,touxMg0JaXDE2Y3kjnSw86VH,LLRJe9dn0lGAVcrivg7p = '1','0','0','0'
	VZHWjJTrAPKG1eLEsxpYo2tS5,title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,count,s6z12JQXUyK5Wn4Bf7LYiDIP9F,FLhVt9Jz2QU4kH51SjTIaspnrO,sRBqTxW3h1SmibclZuYADFj,eJ2apCRZX4i3kmG = NmvKPbfOFJRk3AyUE1a(hh4gUqS5JWf1saRZPXHD)
	m9Pun8rTb4patA3 = '/videos?' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R or '/streams?' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R or '/playlists?' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R
	YvEXMDTpuV417e = '/channels?' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R or '/shorts?' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R
	if m9Pun8rTb4patA3 or YvEXMDTpuV417e: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = url
	m9Pun8rTb4patA3 = 'watch?v=' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R and '/playlist?list=' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R
	YvEXMDTpuV417e = '/gaming' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R  and '/feed/storefront' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R
	if EeWNT4ZgLwnchCSIjJKX[0:5]=='3::0::' and m9Pun8rTb4patA3 and YvEXMDTpuV417e: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
		level,gv4BuAcOEeq9brtYoH5J0d8NF,touxMg0JaXDE2Y3kjnSw86VH,LLRJe9dn0lGAVcrivg7p = '1','0','0','0'
		EeWNT4ZgLwnchCSIjJKX = ''
	bhfgckoLVtsA2DXv = ''
	if '/youtubei/v1/browse' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R or '/youtubei/v1/search' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R or '/my_main_page_shorts_link' in url:
		data = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.youtube.data')
		if data.count(':::')==4:
			U5kReAbc8Xy,key,JxZNwtprqPl48vfDyi75gmzTuoG,tpknRgBLJClIEd50WKmqG,wr9ZDoyjmK5gxci083G = data.split(':::')
			bhfgckoLVtsA2DXv = U5kReAbc8Xy+':::'+key+':::'+JxZNwtprqPl48vfDyi75gmzTuoG+':::'+tpknRgBLJClIEd50WKmqG+':::'+eJ2apCRZX4i3kmG
			if '/my_main_page_shorts_link' in url and not ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = url
			else: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?key='+key
	if not title:
		global MR7ph2I8fB3KFb0HvrqXm
		MR7ph2I8fB3KFb0HvrqXm += 1
		title = 'فيديوهات '+str(MR7ph2I8fB3KFb0HvrqXm)
		EeWNT4ZgLwnchCSIjJKX = '3'+'::'+gv4BuAcOEeq9brtYoH5J0d8NF+'::'+touxMg0JaXDE2Y3kjnSw86VH+'::'+LLRJe9dn0lGAVcrivg7p
	if not VZHWjJTrAPKG1eLEsxpYo2tS5: return False
	elif 'searchPyvRenderer' in str(hh4gUqS5JWf1saRZPXHD): return False
	elif '/about' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: return False
	elif '/community' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: return False
	elif 'continuationItemRenderer' in list(hh4gUqS5JWf1saRZPXHD.keys()) or 'continuationCommand' in list(hh4gUqS5JWf1saRZPXHD.keys()):
		if int(level)>1: level = str(int(level)-1)
		EeWNT4ZgLwnchCSIjJKX = level+'::'+gv4BuAcOEeq9brtYoH5J0d8NF+'::'+touxMg0JaXDE2Y3kjnSw86VH+'::'+LLRJe9dn0lGAVcrivg7p
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+':: '+'صفحة أخرى',ZCimQhV5lovgspAYzHq1Ef27u8ja4R,144,Q2qmuDRrC9ikcaJK7gtUHXNW,EeWNT4ZgLwnchCSIjJKX,bhfgckoLVtsA2DXv)
	elif '/search' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
		title = ':: '+title
		EeWNT4ZgLwnchCSIjJKX = '3'+'::'+gv4BuAcOEeq9brtYoH5J0d8NF+'::'+touxMg0JaXDE2Y3kjnSw86VH+'::'+LLRJe9dn0lGAVcrivg7p
		url = url.replace('/search','')
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,145,'',EeWNT4ZgLwnchCSIjJKX,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
		EeWNT4ZgLwnchCSIjJKX = '3'+'::'+gv4BuAcOEeq9brtYoH5J0d8NF+'::'+touxMg0JaXDE2Y3kjnSw86VH+'::'+LLRJe9dn0lGAVcrivg7p
		title = ':: '+title
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,144,Q2qmuDRrC9ikcaJK7gtUHXNW,EeWNT4ZgLwnchCSIjJKX,bhfgckoLVtsA2DXv)
	elif '/browse' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R and url==tle5V6jgvRfE:
		title = ':: '+title
		EeWNT4ZgLwnchCSIjJKX = '2::0::0::0'
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,144,Q2qmuDRrC9ikcaJK7gtUHXNW,EeWNT4ZgLwnchCSIjJKX,bhfgckoLVtsA2DXv)
	elif not ZCimQhV5lovgspAYzHq1Ef27u8ja4R and 'horizontalMovieListRenderer' in str(hh4gUqS5JWf1saRZPXHD):
		title = ':: '+title
		EeWNT4ZgLwnchCSIjJKX = '3::0::0::0'
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,144,Q2qmuDRrC9ikcaJK7gtUHXNW,EeWNT4ZgLwnchCSIjJKX)
	elif 'messageRenderer' in str(hh4gUqS5JWf1saRZPXHD):
		tBq8fTGUWJY9zvbgXD0EAloPO('link',Yc0eBRLpbCkm4gK7OqyzuHwU+title,'',9999)
	elif FLhVt9Jz2QU4kH51SjTIaspnrO:
		tBq8fTGUWJY9zvbgXD0EAloPO('live',Yc0eBRLpbCkm4gK7OqyzuHwU+FLhVt9Jz2QU4kH51SjTIaspnrO+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,143,Q2qmuDRrC9ikcaJK7gtUHXNW)
	elif '/playlist?list=' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'LIST'+count+':  '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,144,Q2qmuDRrC9ikcaJK7gtUHXNW,EeWNT4ZgLwnchCSIjJKX)
	elif '/shorts/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('&list=',1)[0]
		tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,143,Q2qmuDRrC9ikcaJK7gtUHXNW,s6z12JQXUyK5Wn4Bf7LYiDIP9F)
	elif '/watch?v=' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
		if '&list=' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R and count:
			iEwgHJI7sm = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('&list=',1)[1]
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/playlist?list='+iEwgHJI7sm
			EeWNT4ZgLwnchCSIjJKX = '3::0::0::0'
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'LIST'+count+':  '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,144,Q2qmuDRrC9ikcaJK7gtUHXNW,EeWNT4ZgLwnchCSIjJKX)
		else:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('&list=',1)[0]
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,143,Q2qmuDRrC9ikcaJK7gtUHXNW,s6z12JQXUyK5Wn4Bf7LYiDIP9F)
	elif '/channel/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R or '/c/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R or ('/@' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R and ZCimQhV5lovgspAYzHq1Ef27u8ja4R.count('/')==3):
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'CHNL'+count+':  '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,144,Q2qmuDRrC9ikcaJK7gtUHXNW,EeWNT4ZgLwnchCSIjJKX)
	elif '/user/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'USER'+count+':  '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,144,Q2qmuDRrC9ikcaJK7gtUHXNW,EeWNT4ZgLwnchCSIjJKX)
	else:
		if not ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = url
		title = ':: '+title
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,144,Q2qmuDRrC9ikcaJK7gtUHXNW,EeWNT4ZgLwnchCSIjJKX,bhfgckoLVtsA2DXv)
	return True
def NmvKPbfOFJRk3AyUE1a(hh4gUqS5JWf1saRZPXHD):
	VZHWjJTrAPKG1eLEsxpYo2tS5,title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,count,s6z12JQXUyK5Wn4Bf7LYiDIP9F,FLhVt9Jz2QU4kH51SjTIaspnrO,sRBqTxW3h1SmibclZuYADFj,wr9ZDoyjmK5gxci083G = False,'','','','','','','',''
	if not isinstance(hh4gUqS5JWf1saRZPXHD,dict): return VZHWjJTrAPKG1eLEsxpYo2tS5,title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,count,s6z12JQXUyK5Wn4Bf7LYiDIP9F,FLhVt9Jz2QU4kH51SjTIaspnrO,sRBqTxW3h1SmibclZuYADFj,wr9ZDoyjmK5gxci083G
	for l6lTuOoEUCmy09IQsi4kJapWzSf2D in list(hh4gUqS5JWf1saRZPXHD.keys()):
		z1rQvuHt9Di3oFb0mOSBfdpW5J = hh4gUqS5JWf1saRZPXHD[l6lTuOoEUCmy09IQsi4kJapWzSf2D]
		if isinstance(z1rQvuHt9Di3oFb0mOSBfdpW5J,dict): break
	P5irnaYtSdNHyRBWsj6vEA = []
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['header']['richListHeaderRenderer']['title']")
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['headline']['simpleText']")
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['unplayableText']['simpleText']")
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['formattedTitle']['simpleText']")
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['title']['simpleText']")
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['title']['runs'][0]['text']")
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['text']['simpleText']")
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['text']['runs'][0]['text']")
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['title']")
	P5irnaYtSdNHyRBWsj6vEA.append("item['title']")
	P5irnaYtSdNHyRBWsj6vEA.append("item['reelWatchEndpoint']['videoId']")
	VZHWjJTrAPKG1eLEsxpYo2tS5,title,mbGei9dIvrTohtJ = qaw29IkhU03FpWQesr4Bb(hh4gUqS5JWf1saRZPXHD,z1rQvuHt9Di3oFb0mOSBfdpW5J,P5irnaYtSdNHyRBWsj6vEA)
	P5irnaYtSdNHyRBWsj6vEA = []
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	P5irnaYtSdNHyRBWsj6vEA.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	P5irnaYtSdNHyRBWsj6vEA.append("item['commandMetadata']['webCommandMetadata']['url']")
	VZHWjJTrAPKG1eLEsxpYo2tS5,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,mbGei9dIvrTohtJ = qaw29IkhU03FpWQesr4Bb(hh4gUqS5JWf1saRZPXHD,z1rQvuHt9Di3oFb0mOSBfdpW5J,P5irnaYtSdNHyRBWsj6vEA)
	P5irnaYtSdNHyRBWsj6vEA = []
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['thumbnail']['thumbnails'][0]['url']")
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	P5irnaYtSdNHyRBWsj6vEA.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	VZHWjJTrAPKG1eLEsxpYo2tS5,Q2qmuDRrC9ikcaJK7gtUHXNW,mbGei9dIvrTohtJ = qaw29IkhU03FpWQesr4Bb(hh4gUqS5JWf1saRZPXHD,z1rQvuHt9Di3oFb0mOSBfdpW5J,P5irnaYtSdNHyRBWsj6vEA)
	P5irnaYtSdNHyRBWsj6vEA = []
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['videoCount']")
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['videoCountText']['runs'][0]['text']")
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	VZHWjJTrAPKG1eLEsxpYo2tS5,count,mbGei9dIvrTohtJ = qaw29IkhU03FpWQesr4Bb(hh4gUqS5JWf1saRZPXHD,z1rQvuHt9Di3oFb0mOSBfdpW5J,P5irnaYtSdNHyRBWsj6vEA)
	P5irnaYtSdNHyRBWsj6vEA = []
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['lengthText']['simpleText']")
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	VZHWjJTrAPKG1eLEsxpYo2tS5,s6z12JQXUyK5Wn4Bf7LYiDIP9F,mbGei9dIvrTohtJ = qaw29IkhU03FpWQesr4Bb(hh4gUqS5JWf1saRZPXHD,z1rQvuHt9Di3oFb0mOSBfdpW5J,P5irnaYtSdNHyRBWsj6vEA)
	P5irnaYtSdNHyRBWsj6vEA = []
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	P5irnaYtSdNHyRBWsj6vEA.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	VZHWjJTrAPKG1eLEsxpYo2tS5,wr9ZDoyjmK5gxci083G,mbGei9dIvrTohtJ = qaw29IkhU03FpWQesr4Bb(hh4gUqS5JWf1saRZPXHD,z1rQvuHt9Di3oFb0mOSBfdpW5J,P5irnaYtSdNHyRBWsj6vEA)
	if 'LIVE' in s6z12JQXUyK5Wn4Bf7LYiDIP9F: s6z12JQXUyK5Wn4Bf7LYiDIP9F,FLhVt9Jz2QU4kH51SjTIaspnrO = '','LIVE:  '
	if 'مباشر' in s6z12JQXUyK5Wn4Bf7LYiDIP9F: s6z12JQXUyK5Wn4Bf7LYiDIP9F,FLhVt9Jz2QU4kH51SjTIaspnrO = '','LIVE:  '
	if 'badges' in list(z1rQvuHt9Di3oFb0mOSBfdpW5J.keys()):
		jjATmG13q5N2FYtJUBZ = str(z1rQvuHt9Di3oFb0mOSBfdpW5J['badges'])
		if 'Free with Ads' in jjATmG13q5N2FYtJUBZ: sRBqTxW3h1SmibclZuYADFj = '$:  '
		if 'LIVE' in jjATmG13q5N2FYtJUBZ: FLhVt9Jz2QU4kH51SjTIaspnrO = 'LIVE:  '
		if 'Buy' in jjATmG13q5N2FYtJUBZ or 'Rent' in jjATmG13q5N2FYtJUBZ: sRBqTxW3h1SmibclZuYADFj = '$$:  '
		if UjfpeA9CkYxt8XV(u'مباشر') in jjATmG13q5N2FYtJUBZ: FLhVt9Jz2QU4kH51SjTIaspnrO = 'LIVE:  '
		if UjfpeA9CkYxt8XV(u'شراء') in jjATmG13q5N2FYtJUBZ: sRBqTxW3h1SmibclZuYADFj = '$$:  '
		if UjfpeA9CkYxt8XV(u'استئجار') in jjATmG13q5N2FYtJUBZ: sRBqTxW3h1SmibclZuYADFj = '$$:  '
		if UjfpeA9CkYxt8XV(u'إعلانات') in jjATmG13q5N2FYtJUBZ: sRBqTxW3h1SmibclZuYADFj = '$:  '
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = zKGXT5sJeRq(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	if ZCimQhV5lovgspAYzHq1Ef27u8ja4R and 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
	Q2qmuDRrC9ikcaJK7gtUHXNW = Q2qmuDRrC9ikcaJK7gtUHXNW.split('?')[0]
	if  Q2qmuDRrC9ikcaJK7gtUHXNW and 'http' not in Q2qmuDRrC9ikcaJK7gtUHXNW: Q2qmuDRrC9ikcaJK7gtUHXNW = 'https:'+Q2qmuDRrC9ikcaJK7gtUHXNW
	title = zKGXT5sJeRq(title)
	if sRBqTxW3h1SmibclZuYADFj: title = sRBqTxW3h1SmibclZuYADFj+title
	s6z12JQXUyK5Wn4Bf7LYiDIP9F = s6z12JQXUyK5Wn4Bf7LYiDIP9F.replace(',','')
	count = count.replace(',','')
	count = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('\d+',count)
	if count: count = count[0]
	else: count = ''
	return True,title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,count,s6z12JQXUyK5Wn4Bf7LYiDIP9F,FLhVt9Jz2QU4kH51SjTIaspnrO,sRBqTxW3h1SmibclZuYADFj,wr9ZDoyjmK5gxci083G
def htfj5BngX2PKymacbAU(url,data='',VWi2dTb46v3eOryuspKBF9L=''):
	if VWi2dTb46v3eOryuspKBF9L=='': VWi2dTb46v3eOryuspKBF9L = 'ytInitialData'
	PPGUinpWfm6Xw9NLtbcax53IQ = FY2qK6eHVBl4D0pEut8IgkTczyG()
	TC7fWv2a1gLJGiAtN8 = {'User-Agent':PPGUinpWfm6Xw9NLtbcax53IQ,'Cookie':'PREF=hl=ar'}
	global if2qpOxlZd8MBGeo5uNIyLEsz
	if not data: data = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.youtube.data')
	if data.count(':::')==4: U5kReAbc8Xy,key,JxZNwtprqPl48vfDyi75gmzTuoG,tpknRgBLJClIEd50WKmqG,wr9ZDoyjmK5gxci083G = data.split(':::')
	else: U5kReAbc8Xy,key,JxZNwtprqPl48vfDyi75gmzTuoG,tpknRgBLJClIEd50WKmqG,wr9ZDoyjmK5gxci083G = '','','','',''
	bhfgckoLVtsA2DXv = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":JxZNwtprqPl48vfDyi75gmzTuoG}}}
	if url==tle5V6jgvRfE+'/shorts' or '/my_main_page_shorts_link' in url:
		url = tle5V6jgvRfE+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		bhfgckoLVtsA2DXv['sequenceParams'] = U5kReAbc8Xy
		bhfgckoLVtsA2DXv = str(bhfgckoLVtsA2DXv)
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'POST',url,bhfgckoLVtsA2DXv,TC7fWv2a1gLJGiAtN8,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = tle5V6jgvRfE+'/youtubei/v1/guide?key='+key
		bhfgckoLVtsA2DXv = str(bhfgckoLVtsA2DXv)
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'POST',url,bhfgckoLVtsA2DXv,TC7fWv2a1gLJGiAtN8,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and U5kReAbc8Xy:
		bhfgckoLVtsA2DXv['continuation'] = wr9ZDoyjmK5gxci083G
		bhfgckoLVtsA2DXv['context']['client']['visitorData'] = U5kReAbc8Xy
		bhfgckoLVtsA2DXv = str(bhfgckoLVtsA2DXv)
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'POST',url,bhfgckoLVtsA2DXv,TC7fWv2a1gLJGiAtN8,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and tpknRgBLJClIEd50WKmqG:
		TC7fWv2a1gLJGiAtN8.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':JxZNwtprqPl48vfDyi75gmzTuoG})
		TC7fWv2a1gLJGiAtN8.update({'Cookie':'VISITOR_INFO1_LIVE='+tpknRgBLJClIEd50WKmqG})
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',url,'',TC7fWv2a1gLJGiAtN8,'','','YOUTUBE-GET_PAGE_DATA-5th')
	else:
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',url,'',TC7fWv2a1gLJGiAtN8,'','','YOUTUBE-GET_PAGE_DATA-6th')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	e1ebv6pD8mUitJkPXqwnjr = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"innertubeApiKey".*?"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.I)
	if e1ebv6pD8mUitJkPXqwnjr: key = e1ebv6pD8mUitJkPXqwnjr[0]
	e1ebv6pD8mUitJkPXqwnjr = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"cver".*?"value".*?"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.I)
	if e1ebv6pD8mUitJkPXqwnjr: JxZNwtprqPl48vfDyi75gmzTuoG = e1ebv6pD8mUitJkPXqwnjr[0]
	e1ebv6pD8mUitJkPXqwnjr = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"visitorData".*?"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.I)
	if e1ebv6pD8mUitJkPXqwnjr: U5kReAbc8Xy = e1ebv6pD8mUitJkPXqwnjr[0]
	cookies = aQniqUlZk8.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): tpknRgBLJClIEd50WKmqG = cookies['VISITOR_INFO1_LIVE']
	mpMWiOeDqvsId6 = U5kReAbc8Xy+':::'+key+':::'+JxZNwtprqPl48vfDyi75gmzTuoG+':::'+tpknRgBLJClIEd50WKmqG+':::'+wr9ZDoyjmK5gxci083G
	if VWi2dTb46v3eOryuspKBF9L=='ytInitialData' and 'ytInitialData' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2:
		QQrmjN6z9AvTGlqipZ2cK = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('window\["ytInitialData"\] = ({.*?});',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if not QQrmjN6z9AvTGlqipZ2cK: QQrmjN6z9AvTGlqipZ2cK = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('var ytInitialData = ({.*?});',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		bwCMA2NdaBJc = GVQAnvYCT3dS('str',QQrmjN6z9AvTGlqipZ2cK[0])
	elif VWi2dTb46v3eOryuspKBF9L=='ytInitialGuideData' and 'ytInitialGuideData' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2:
		QQrmjN6z9AvTGlqipZ2cK = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('var ytInitialGuideData = ({.*?});',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		bwCMA2NdaBJc = GVQAnvYCT3dS('str',QQrmjN6z9AvTGlqipZ2cK[0])
	elif '</script>' not in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2: bwCMA2NdaBJc = GVQAnvYCT3dS('str',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2)
	else: bwCMA2NdaBJc = ''
	if 0:
		Y67JdZSKDsTBAmlnag4wGLWRHx53I8 = str(bwCMA2NdaBJc)
		if wvkR1es6d0SrjxKt5FZTMUWz7a: Y67JdZSKDsTBAmlnag4wGLWRHx53I8 = Y67JdZSKDsTBAmlnag4wGLWRHx53I8.encode('utf8')
		open('S:\\0000emad.dat','wb').write(Y67JdZSKDsTBAmlnag4wGLWRHx53I8)
	if2qpOxlZd8MBGeo5uNIyLEsz.setSetting('av.youtube.data',mpMWiOeDqvsId6)
	return M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,bwCMA2NdaBJc,mpMWiOeDqvsId6
def r2i5GM9gVSh0b4DLoYd8PB(url,EeWNT4ZgLwnchCSIjJKX):
	search = UIf35nZEj1wylmq()
	if not search: return
	search = search.replace(' ','+')
	M08MPGgsh4n5rKe = url+'/search?query='+search
	uyt3pAHZk4(M08MPGgsh4n5rKe,EeWNT4ZgLwnchCSIjJKX)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if not search:
		search = UIf35nZEj1wylmq()
		if not search: return
	search = search.replace(' ','+')
	M08MPGgsh4n5rKe = tle5V6jgvRfE+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in dNlVai6Obj1e: JHV2A134Gcdkqfhe8jSTN = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in dNlVai6Obj1e: JHV2A134Gcdkqfhe8jSTN = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in dNlVai6Obj1e: JHV2A134Gcdkqfhe8jSTN = '&sp=EgIQAg%253D%253D'
		else: JHV2A134Gcdkqfhe8jSTN = ''
		TW6JIBgC971tjOE = M08MPGgsh4n5rKe+JHV2A134Gcdkqfhe8jSTN
	else:
		GfmuyVWZ4SHhINE6AbRFdiQ,DJCZ5K2bfyNjtgW9zQT13sAi4mS,neZQycYAFqxLzkPhEWvM = [],[],''
		Xigwu6GWCSfy0e4dAQYx = ['بدون ترتيب','ترتيب حسب مدى الصلة','ترتيب حسب تاريخ التحميل','ترتيب حسب عدد المشاهدات','ترتيب حسب التقييم']
		ts017yVrFBiaUqCWhc = ['','&sp=CAA%253D','&sp=CAI%253D','&sp=CAM%253D','&sp=CAE%253D']
		KmgHSckEoXNDwWtqj9pJ3aisb8v45 = pYRLgOuVTAUM4wKJchdbkzfBql('موقع يوتيوب - اختر الترتيب',Xigwu6GWCSfy0e4dAQYx)
		if KmgHSckEoXNDwWtqj9pJ3aisb8v45 == -1: return
		yw9guiXa6RkIhJHPL2zdFm5l = ts017yVrFBiaUqCWhc[KmgHSckEoXNDwWtqj9pJ3aisb8v45]
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,f2zRBWtqK0EXauIpD36,data = htfj5BngX2PKymacbAU(M08MPGgsh4n5rKe+yw9guiXa6RkIhJHPL2zdFm5l)
		if f2zRBWtqK0EXauIpD36:
			try:
				zfy8eg4oWEQNBIUblPYZhp = f2zRBWtqK0EXauIpD36['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for j4oPqsvRg6X0HDNT2LFbhyIaBJu in range(len(zfy8eg4oWEQNBIUblPYZhp)):
					group = zfy8eg4oWEQNBIUblPYZhp[j4oPqsvRg6X0HDNT2LFbhyIaBJu]['searchFilterGroupRenderer']['filters']
					for LLmET7aiA0WkRMChzVfqlKdGQUc9y in range(len(group)):
						z1rQvuHt9Di3oFb0mOSBfdpW5J = group[LLmET7aiA0WkRMChzVfqlKdGQUc9y]['searchFilterRenderer']
						if 'navigationEndpoint' in list(z1rQvuHt9Di3oFb0mOSBfdpW5J.keys()):
							ZCimQhV5lovgspAYzHq1Ef27u8ja4R = z1rQvuHt9Di3oFb0mOSBfdpW5J['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.replace('\u0026','&')
							title = z1rQvuHt9Di3oFb0mOSBfdpW5J['tooltip']
							title = title.replace('البحث عن ','')
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								neZQycYAFqxLzkPhEWvM = title
								VktWBN6gn8zSUpesvfCyia2Ajm = ZCimQhV5lovgspAYzHq1Ef27u8ja4R
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ','')
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								neZQycYAFqxLzkPhEWvM = title
								VktWBN6gn8zSUpesvfCyia2Ajm = ZCimQhV5lovgspAYzHq1Ef27u8ja4R
							if 'Sort by' in title: continue
							GfmuyVWZ4SHhINE6AbRFdiQ.append(zKGXT5sJeRq(title))
							DJCZ5K2bfyNjtgW9zQT13sAi4mS.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			except: pass
		if not neZQycYAFqxLzkPhEWvM: krUhYxnVptb9 = ''
		else:
			GfmuyVWZ4SHhINE6AbRFdiQ = ['بدون فلتر',neZQycYAFqxLzkPhEWvM]+GfmuyVWZ4SHhINE6AbRFdiQ
			DJCZ5K2bfyNjtgW9zQT13sAi4mS = ['',VktWBN6gn8zSUpesvfCyia2Ajm]+DJCZ5K2bfyNjtgW9zQT13sAi4mS
			u5cH24GQrUiEpBYTgw = pYRLgOuVTAUM4wKJchdbkzfBql('موقع يوتيوب - اختر الفلتر',GfmuyVWZ4SHhINE6AbRFdiQ)
			if u5cH24GQrUiEpBYTgw == -1: return
			krUhYxnVptb9 = DJCZ5K2bfyNjtgW9zQT13sAi4mS[u5cH24GQrUiEpBYTgw]
		if krUhYxnVptb9: TW6JIBgC971tjOE = tle5V6jgvRfE+krUhYxnVptb9
		elif yw9guiXa6RkIhJHPL2zdFm5l: TW6JIBgC971tjOE = M08MPGgsh4n5rKe+yw9guiXa6RkIhJHPL2zdFm5l
		else: TW6JIBgC971tjOE = M08MPGgsh4n5rKe
	uyt3pAHZk4(TW6JIBgC971tjOE)
	return
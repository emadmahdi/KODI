# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'RANDOMS'
Yc0eBRLpbCkm4gK7OqyzuHwU = '_LST_'
Ca4HNo1bJSUiw35 = 4
seUPafrLW6pcRIxt7v = 10
def HgQCVwFx2Br(n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,url,RxgdTHfDar8EXt,tsMKaFVh1ZN2BIXEcvTejxR5DP,zSPVUW1XDt2Ba6ZkAH):
	try: FcTdplGwy7AZV1bosj = str(zSPVUW1XDt2Ba6ZkAH['folder'])
	except: FcTdplGwy7AZV1bosj = ''
	if   n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==160: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==161: s4Bng5iAZQSTtpDw9 = Q1BqwZiHVfx2oga7e5ObGRCPI(RxgdTHfDar8EXt)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==162: s4Bng5iAZQSTtpDw9 = iPq0FbZ157UDHsSOX(RxgdTHfDar8EXt,162)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==163: s4Bng5iAZQSTtpDw9 = iPq0FbZ157UDHsSOX(RxgdTHfDar8EXt,163)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==164: s4Bng5iAZQSTtpDw9 = mpaJVgkKAxOPo8QIfLv2(RxgdTHfDar8EXt)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==165: s4Bng5iAZQSTtpDw9 = qbwHZvAp5BUcrxPGjmK9LzskaSFX(url,RxgdTHfDar8EXt)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==166: s4Bng5iAZQSTtpDw9 = GyDdU4j8eNbwJKVF9C(url,RxgdTHfDar8EXt)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==167: s4Bng5iAZQSTtpDw9 = awFqpKe2WGNVRzjQ0MtOn(url,RxgdTHfDar8EXt)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==168: s4Bng5iAZQSTtpDw9 = RUAmzjCxcDLqHQKS5bOgFdoXkGB(url,RxgdTHfDar8EXt)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==761: s4Bng5iAZQSTtpDw9 = DCErcenRskqQtYVINoLai6UwW()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==762: s4Bng5iAZQSTtpDw9 = TTVjoxbE5kzDKQmILGshMnSuAcZ()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==763: s4Bng5iAZQSTtpDw9 = WaQug6HloIrk2Am(FcTdplGwy7AZV1bosj,RxgdTHfDar8EXt,tsMKaFVh1ZN2BIXEcvTejxR5DP)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==764: s4Bng5iAZQSTtpDw9 = Qs7GBkjdEF51X(FcTdplGwy7AZV1bosj,RxgdTHfDar8EXt)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==765: s4Bng5iAZQSTtpDw9 = PSkwGBMhxnU3yi0E9u2qFR7NA4l(FcTdplGwy7AZV1bosj,RxgdTHfDar8EXt)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','قنوات تلفزيون عشوائية','',161,'','','_LIVETV__RANDOM__REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','قسم عشوائي','',162,'','','_SITES__REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','فيديوهات عشوائية','',163,'','','_SITES__RANDOM__REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','فيديوهات بحث عشوائي','',164,'','','_SITES__RANDOM__REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','فيديوهات عشوائية من قسم','',763,'','','_SITES__RANDOM_')
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','قنوات M3U عشوائية','',163,'','','_M3U__LIVE__RANDOM__REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','فيديوهات M3U عشوائية','',163,'','','_M3U__VOD__RANDOM__REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','قسم قنوات M3U عشوائي','',162,'','','_M3U__LIVE__REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','قسم فيديو M3U عشوائي','',162,'','','_M3U__VOD__REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','فيديوهات M3U بحث عشوائي','',164,'','','_M3U__RANDOM__REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','فيديوهات M3U عشوائية من قسم','',765,'','','_M3U__RANDOM__REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','قنوات IPTV عشوائية','',163,'','','_IPTV__LIVE__RANDOM__REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','فيديوهات IPTV عشوائية','',163,'','','_IPTV__VOD__RANDOM__REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','قسم قنوات IPTV عشوائي','',162,'','','_IPTV__LIVE__REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','قسم فيديو IPTV عشوائي','',162,'','','_IPTV__VOD__REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','فيديوهات IPTV بحث عشوائي','',164,'','','_IPTV__RANDOM__REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','فيديوهات IPTV عشوائية من قسم','',764,'','','_IPTV__RANDOM__REMEMBERRESULTS_')
	return
def DCErcenRskqQtYVINoLai6UwW():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_IPT_'+'فيديوهات جميع IPTV','',764)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for FcTdplGwy7AZV1bosj in range(1,qHwLO4cGVh+1):
		Yc0eBRLpbCkm4gK7OqyzuHwU = '_IP'+str(FcTdplGwy7AZV1bosj)+'_'
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+' فيديوهات مجلد '+qjvurmMCnxdktlp6Ii2ZhJb74y[FcTdplGwy7AZV1bosj],'',764,'','','','',{'folder':FcTdplGwy7AZV1bosj})
	return
def TTVjoxbE5kzDKQmILGshMnSuAcZ():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_M3U_'+'فيديوهات جميع M3U','',765)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for FcTdplGwy7AZV1bosj in range(1,qHwLO4cGVh+1):
		Yc0eBRLpbCkm4gK7OqyzuHwU = '_MU'+str(FcTdplGwy7AZV1bosj)+'_'
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+' فيديوهات مجلد '+qjvurmMCnxdktlp6Ii2ZhJb74y[FcTdplGwy7AZV1bosj],'',765,'','','','',{'folder':FcTdplGwy7AZV1bosj})
	return
def k8CybYvg5KasV0o67u2jqMAINp(VewOrPR4kX):
	global sbFQ3Liy6RIjqn,rrw47AnJG2gx3YE1qBT
	HmcsWL3qzIatv,jRreTXMs4JNBbt0Y,nROJXLEM6K = zzPTrDE4vhj2Bl8qFmiyWec(VewOrPR4kX)
	try:
		if 'IFILM' in VewOrPR4kX: HmcsWL3qzIatv(VewOrPR4kX)
		else: HmcsWL3qzIatv()
		TZHuayWs2op0nbh = False
	except:
		TTvq7ZIFQGf()
		TZHuayWs2op0nbh = True
	VewOrPR4kX = NNbLf2d3Slq6pV(VewOrPR4kX)
	if TZHuayWs2op0nbh:
		xa60ce2znAlyL5Z8ESXhO(VewOrPR4kX,'فشل للأسف',w6vebiEZtpCjJcILP8Skx5rHn=2000)
		sbFQ3Liy6RIjqn += 1
		rrw47AnJG2gx3YE1qBT += ' '+VewOrPR4kX
	else: xa60ce2znAlyL5Z8ESXhO(VewOrPR4kX,'',w6vebiEZtpCjJcILP8Skx5rHn=1000)
	return
def z3UtB4dqH2WkwMrXZ9hDb(vvg1sfpcxaQE=True):
	global sbFQ3Liy6RIjqn,rrw47AnJG2gx3YE1qBT
	if not vvg1sfpcxaQE:
		global FEzkPuAaomBVKvS4pfx8
		s4Bng5iAZQSTtpDw9 = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,'dict','SECTIONS_SITES','SECTIONS_SITES_ALL')
		if s4Bng5iAZQSTtpDw9:
			FEzkPuAaomBVKvS4pfx8 = s4Bng5iAZQSTtpDw9
			return
	A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO('center','','','رسالة من المبرمج','لكي تملئ هذه القائمة . البرنامج يحتاج أن يفحص جميع مواقع الفيديو التي في البرنامج لكي يستخرج منها فقط الأقسام الرئيسية . ثم يقوم البرنامج بخزن هذه الأقسام حتى لا تحتاج أن تملئها مرة أخرى . عملية ملئ جميع الأقسام تحتاج عادة أقل من 3 دقائق . هل تريد أن تجمع قائمة الأقسام الآن ؟')
	if A5vgi1F6qVunZMas2Nf!=1: return
	UyZEGdfW50X3Rbpzmh1CnYOuDlsk4q(False,False,False)
	CApVaZKjxzf = muPDGHvJwFieQYCW62bB
	sbFQ3Liy6RIjqn,rrw47AnJG2gx3YE1qBT,threads = 0,'',{}
	for VewOrPR4kX in Obhnuk3f67:
		w6vebiEZtpCjJcILP8Skx5rHn.sleep(0.5)
		threads[VewOrPR4kX] = mZHwnlsXWDfV3ri4M.Thread(target=k8CybYvg5KasV0o67u2jqMAINp,args=(VewOrPR4kX,))
		threads[VewOrPR4kX].start()
		if sbFQ3Liy6RIjqn>=seUPafrLW6pcRIxt7v: break
	else:
		for VewOrPR4kX in list(threads.keys()):
			threads[VewOrPR4kX].join()
	muPDGHvJwFieQYCW62bB[:] = CApVaZKjxzf
	if sbFQ3Liy6RIjqn>=seUPafrLW6pcRIxt7v: tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','لديك مشكلة في '+str(sbFQ3Liy6RIjqn)+' مواقع من مواقع البرنامج ... وسببها قد يكون عدم وجود إنترنيت في جهازك وهي:'+rrw47AnJG2gx3YE1qBT)
	else:
		kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,'SECTIONS_SITES','SECTIONS_SITES_ALL',FEzkPuAaomBVKvS4pfx8,D0vjfyxKZuP7pXknq62MwFYU)
		tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','تم جلب جميع الأقسام المتوفرة في البرنامج')
	UyZEGdfW50X3Rbpzmh1CnYOuDlsk4q('','','')
	return
def ziLFAe3mdEZypx0JCXwbfPBHg6(FcTdplGwy7AZV1bosj,VGPNayc6DgkReH1xC9BE3uFO475bf):
	nHKoSC1PiDe8RFambXd7wGf = False
	K8u1V3oUgMvY6Tb2NyaqznRS = muPDGHvJwFieQYCW62bB
	muPDGHvJwFieQYCW62bB[:] = []
	if nHKoSC1PiDe8RFambXd7wGf and '_CREATENEW_' not in VGPNayc6DgkReH1xC9BE3uFO475bf:
		s4Bng5iAZQSTtpDw9 = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,'list','SECTIONS_IPTV','SECTIONS_IPTV_'+FcTdplGwy7AZV1bosj)
	elif '_LIVE_' not in VGPNayc6DgkReH1xC9BE3uFO475bf or '_VOD_' not in VGPNayc6DgkReH1xC9BE3uFO475bf:
		import XTA49cQUuV
		maCNIYkc0HOiEGpL3g = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in VGPNayc6DgkReH1xC9BE3uFO475bf:
			try: XTA49cQUuV.ddvQlFmprDb(FcTdplGwy7AZV1bosj,'VOD_UNKNOWN_GROUPED_SORTED','','',VGPNayc6DgkReH1xC9BE3uFO475bf+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: tehb3k5a2PufGOdBIUw8j('','','موقع ـIPTV للفيديوهات',maCNIYkc0HOiEGpL3g)
			try: XTA49cQUuV.ddvQlFmprDb(FcTdplGwy7AZV1bosj,'VOD_MOVIES_GROUPED_SORTED','','',VGPNayc6DgkReH1xC9BE3uFO475bf+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: tehb3k5a2PufGOdBIUw8j('','','موقع ـIPTV للفيديوهات',maCNIYkc0HOiEGpL3g)
			try: XTA49cQUuV.ddvQlFmprDb(FcTdplGwy7AZV1bosj,'VOD_SERIES_GROUPED_SORTED','','',VGPNayc6DgkReH1xC9BE3uFO475bf+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: tehb3k5a2PufGOdBIUw8j('','','موقع ـIPTV للفيديوهات',maCNIYkc0HOiEGpL3g)
		if '_VOD_' not in VGPNayc6DgkReH1xC9BE3uFO475bf:
			try: XTA49cQUuV.ddvQlFmprDb(FcTdplGwy7AZV1bosj,'LIVE_UNKNOWN_GROUPED_SORTED','','',VGPNayc6DgkReH1xC9BE3uFO475bf+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: tehb3k5a2PufGOdBIUw8j('','','موقع ـIPTV للقنوات',maCNIYkc0HOiEGpL3g)
			try: XTA49cQUuV.ddvQlFmprDb(FcTdplGwy7AZV1bosj,'LIVE_GROUPED_SORTED','','',VGPNayc6DgkReH1xC9BE3uFO475bf+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: tehb3k5a2PufGOdBIUw8j('','','موقع ـIPTV للقنوات',maCNIYkc0HOiEGpL3g)
		s4Bng5iAZQSTtpDw9 = muPDGHvJwFieQYCW62bB
		if nHKoSC1PiDe8RFambXd7wGf: kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,'SECTIONS_IPTV','SECTIONS_IPTV_'+FcTdplGwy7AZV1bosj,s4Bng5iAZQSTtpDw9,D0vjfyxKZuP7pXknq62MwFYU)
	muPDGHvJwFieQYCW62bB[:] = K8u1V3oUgMvY6Tb2NyaqznRS
	return s4Bng5iAZQSTtpDw9
def sIZNM2FUkX(FcTdplGwy7AZV1bosj,VGPNayc6DgkReH1xC9BE3uFO475bf):
	nHKoSC1PiDe8RFambXd7wGf = False
	K8u1V3oUgMvY6Tb2NyaqznRS = muPDGHvJwFieQYCW62bB
	muPDGHvJwFieQYCW62bB[:] = []
	if nHKoSC1PiDe8RFambXd7wGf and '_CREATENEW_' not in VGPNayc6DgkReH1xC9BE3uFO475bf:
		s4Bng5iAZQSTtpDw9 = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,'list','SECTIONS_M3U','SECTIONS_M3U_'+FcTdplGwy7AZV1bosj)
	elif '_LIVE_' not in VGPNayc6DgkReH1xC9BE3uFO475bf or '_VOD_' not in VGPNayc6DgkReH1xC9BE3uFO475bf:
		import ytYp4ZnKL3
		maCNIYkc0HOiEGpL3g = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in VGPNayc6DgkReH1xC9BE3uFO475bf:
			try: ytYp4ZnKL3.ddvQlFmprDb(FcTdplGwy7AZV1bosj,'VOD_UNKNOWN_GROUPED_SORTED','','',VGPNayc6DgkReH1xC9BE3uFO475bf+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: tehb3k5a2PufGOdBIUw8j('','','موقع ـM3U للفيديوهات',maCNIYkc0HOiEGpL3g)
			try: ytYp4ZnKL3.ddvQlFmprDb(FcTdplGwy7AZV1bosj,'VOD_MOVIES_GROUPED_SORTED','','',VGPNayc6DgkReH1xC9BE3uFO475bf+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: tehb3k5a2PufGOdBIUw8j('','','موقع ـM3U للفيديوهات',maCNIYkc0HOiEGpL3g)
			try: ytYp4ZnKL3.ddvQlFmprDb(FcTdplGwy7AZV1bosj,'VOD_SERIES_GROUPED_SORTED','','',VGPNayc6DgkReH1xC9BE3uFO475bf+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: tehb3k5a2PufGOdBIUw8j('','','موقع ـM3U للفيديوهات',maCNIYkc0HOiEGpL3g)
		if '_VOD_' not in VGPNayc6DgkReH1xC9BE3uFO475bf:
			try: ytYp4ZnKL3.ddvQlFmprDb(FcTdplGwy7AZV1bosj,'LIVE_UNKNOWN_GROUPED_SORTED','','',VGPNayc6DgkReH1xC9BE3uFO475bf+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: tehb3k5a2PufGOdBIUw8j('','','موقع ـM3U للقنوات',maCNIYkc0HOiEGpL3g)
			try: ytYp4ZnKL3.ddvQlFmprDb(FcTdplGwy7AZV1bosj,'LIVE_GROUPED_SORTED','','',VGPNayc6DgkReH1xC9BE3uFO475bf+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: tehb3k5a2PufGOdBIUw8j('','','موقع ـM3U للقنوات',maCNIYkc0HOiEGpL3g)
		s4Bng5iAZQSTtpDw9 = muPDGHvJwFieQYCW62bB
		if nHKoSC1PiDe8RFambXd7wGf: kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,'SECTIONS_M3U','SECTIONS_M3U_'+FcTdplGwy7AZV1bosj,s4Bng5iAZQSTtpDw9,D0vjfyxKZuP7pXknq62MwFYU)
	muPDGHvJwFieQYCW62bB[:] = K8u1V3oUgMvY6Tb2NyaqznRS
	return s4Bng5iAZQSTtpDw9
def WaQug6HloIrk2Am(FcTdplGwy7AZV1bosj,VGPNayc6DgkReH1xC9BE3uFO475bf,H8FOXZDGyIEb4):
	if '_CREATENEW_' in VGPNayc6DgkReH1xC9BE3uFO475bf and H8FOXZDGyIEb4=='': z3UtB4dqH2WkwMrXZ9hDb(True)
	elif H8FOXZDGyIEb4: z3UtB4dqH2WkwMrXZ9hDb(False)
	yQGz7kjBW85qAxph = VGPNayc6DgkReH1xC9BE3uFO475bf.replace('_CREATENEW_','').replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	if not H8FOXZDGyIEb4:
		tBq8fTGUWJY9zvbgXD0EAloPO('link','تحديث هذه القائمة','',763,'','','_CREATENEW_'+yQGz7kjBW85qAxph,'',{'folder':FcTdplGwy7AZV1bosj})
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	ttF4jIGbxlz = ['أفلام','مسلسلات','مسرحيات','برامج','أطفال وكرتون','رمضان','أحدث-أخر','سلاسل','موسيقى','أشهر-أكثر','الآن','ضحك','رياضة','نيتفلكس','ممثلين','بث حي','دينية','سنوات','أخرى']
	rhVQLag70XjHeA3NiPGm = ['افلام','movie','فيلم','فلم']
	jlfsyC6ZOhFw1PgX9YHzkeBn = ['مسلسل','series']
	VT8KNCvmhnUl3Sg540jZYGFPi = ['مسارح','مسرحيات']
	isvOVnW94p6r0DEdGmfFLw = ['برامج','show','تلفزيون','تليفزيون']
	DQ5g3enztqCXoNROua = ['انمي','كرتون','كارتون','kids','طفل','اطفال']
	EkydzNVYBr1LigDKe = ['رمضان']
	QDvSPAW6cY = ['احدث','اخر','موخر','جديد','مضاف','حديث']
	Zxez8jY3lCE20NGSbAkXu9 = ['سلاسل','سلسله']
	ruegA5Q9HialS0nckbLWOmsN = ['اغاني','موسيقى','كليب','حفل','music']
	zz2Qmc9ujVOFLskZEKfx0J8yBNtPY = ['اكثر','اشهر','مميزه','اعلى','مختاره','مختارات','اقوى']
	iRxrY9o5pseHgNl = ['الان','حالي','مثبت','رائج']
	yqNSbM2ujcvhxfGzHZ = ['ضحك','كوميدي']
	K9QmTjAYSeENcyX16CsbxGI0tLw = ['رياضه','كوره','مصارعه','شوت','رياضة']
	pWSDAn8vjI5uNd9 = ['نيتفلكس','netflix','نيتفليكس']
	gDINZqCEVz9b3vL7BYcP = ['ممثلين','اشخاص','نجوم']
	EvpYWVrnUQA = ['بث حي','live','قناه','قنوات']
	HHAKexFqUo7BQZvitTPNJwM8LX0 = ['دين','ادعيه','زيارات','لطميات','دعاء','قران','قصائد','رثاء','مرجعيه','اذان','اسلام','تواشيح','خطب','حوزوي','عتبات','مواليد','نواعي','عقائد','اناشيد']
	Rs3znqjvuJbUfOk = ['19','20','21','22','23','24','25','26']
	if not H8FOXZDGyIEb4:
		H8FOXZDGyIEb4 = 0
		for Y3XMiLPc5ykT4sfJmGlbK in ttF4jIGbxlz:
			H8FOXZDGyIEb4 += 1
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+Y3XMiLPc5ykT4sfJmGlbK,'',763,'',str(H8FOXZDGyIEb4),yQGz7kjBW85qAxph,'',{'folder':FcTdplGwy7AZV1bosj})
	else:
		for GG9zmPqulYDyJCtWwkE8 in sorted(list(FEzkPuAaomBVKvS4pfx8.keys())):
			SSJLGwYsC5qz3bnku9IpyfX = GG9zmPqulYDyJCtWwkE8.lower()
			cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = []
			if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in SSJLGwYsC5qz3bnku9IpyfX for hht0cpXxWw2OzFS1jnUGebkJLBd85 in rhVQLag70XjHeA3NiPGm): cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo.append(1)
			if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in SSJLGwYsC5qz3bnku9IpyfX for hht0cpXxWw2OzFS1jnUGebkJLBd85 in jlfsyC6ZOhFw1PgX9YHzkeBn): cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo.append(2)
			if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in SSJLGwYsC5qz3bnku9IpyfX for hht0cpXxWw2OzFS1jnUGebkJLBd85 in VT8KNCvmhnUl3Sg540jZYGFPi): cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo.append(3)
			if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in SSJLGwYsC5qz3bnku9IpyfX for hht0cpXxWw2OzFS1jnUGebkJLBd85 in isvOVnW94p6r0DEdGmfFLw): cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo.append(4)
			if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in SSJLGwYsC5qz3bnku9IpyfX for hht0cpXxWw2OzFS1jnUGebkJLBd85 in DQ5g3enztqCXoNROua): cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo.append(5)
			if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in SSJLGwYsC5qz3bnku9IpyfX for hht0cpXxWw2OzFS1jnUGebkJLBd85 in EkydzNVYBr1LigDKe): cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo.append(6)
			if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in SSJLGwYsC5qz3bnku9IpyfX for hht0cpXxWw2OzFS1jnUGebkJLBd85 in QDvSPAW6cY) and SSJLGwYsC5qz3bnku9IpyfX not in ['اخرى']: cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo.append(7)
			if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in SSJLGwYsC5qz3bnku9IpyfX for hht0cpXxWw2OzFS1jnUGebkJLBd85 in Zxez8jY3lCE20NGSbAkXu9): cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo.append(8)
			if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in SSJLGwYsC5qz3bnku9IpyfX for hht0cpXxWw2OzFS1jnUGebkJLBd85 in ruegA5Q9HialS0nckbLWOmsN): cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo.append(9)
			if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in SSJLGwYsC5qz3bnku9IpyfX for hht0cpXxWw2OzFS1jnUGebkJLBd85 in zz2Qmc9ujVOFLskZEKfx0J8yBNtPY): cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo.append(10)
			if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in SSJLGwYsC5qz3bnku9IpyfX for hht0cpXxWw2OzFS1jnUGebkJLBd85 in iRxrY9o5pseHgNl): cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo.append(11)
			if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in SSJLGwYsC5qz3bnku9IpyfX for hht0cpXxWw2OzFS1jnUGebkJLBd85 in yqNSbM2ujcvhxfGzHZ): cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo.append(12)
			if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in SSJLGwYsC5qz3bnku9IpyfX for hht0cpXxWw2OzFS1jnUGebkJLBd85 in K9QmTjAYSeENcyX16CsbxGI0tLw): cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo.append(13)
			if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in SSJLGwYsC5qz3bnku9IpyfX for hht0cpXxWw2OzFS1jnUGebkJLBd85 in pWSDAn8vjI5uNd9): cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo.append(14)
			if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in SSJLGwYsC5qz3bnku9IpyfX for hht0cpXxWw2OzFS1jnUGebkJLBd85 in gDINZqCEVz9b3vL7BYcP): cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo.append(15)
			if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in SSJLGwYsC5qz3bnku9IpyfX for hht0cpXxWw2OzFS1jnUGebkJLBd85 in EvpYWVrnUQA): cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo.append(16)
			if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in SSJLGwYsC5qz3bnku9IpyfX for hht0cpXxWw2OzFS1jnUGebkJLBd85 in HHAKexFqUo7BQZvitTPNJwM8LX0): cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo.append(17)
			if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in SSJLGwYsC5qz3bnku9IpyfX for hht0cpXxWw2OzFS1jnUGebkJLBd85 in Rs3znqjvuJbUfOk): cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo.append(18)
			if not cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo: cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = [19]
			for kUQh3I9xjzn in cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo:
				if str(kUQh3I9xjzn)==H8FOXZDGyIEb4:
					tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+GG9zmPqulYDyJCtWwkE8,GG9zmPqulYDyJCtWwkE8,166,'','',yQGz7kjBW85qAxph+'_REMEMBERRESULTS_')
	return
def Qs7GBkjdEF51X(FcTdplGwy7AZV1bosj,VGPNayc6DgkReH1xC9BE3uFO475bf):
	nHKoSC1PiDe8RFambXd7wGf = False
	if nHKoSC1PiDe8RFambXd7wGf:
		tBq8fTGUWJY9zvbgXD0EAloPO('link','تحديث هذه القائمة','',764,'','','_CREATENEW_','',{'folder':FcTdplGwy7AZV1bosj})
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	K8u1V3oUgMvY6Tb2NyaqznRS = muPDGHvJwFieQYCW62bB[:]
	import XTA49cQUuV
	if FcTdplGwy7AZV1bosj:
		if not XTA49cQUuV.RwN5lZjvPsLCW7gz9c0ab1x(FcTdplGwy7AZV1bosj,True): return
		mWFGACDMkb3lreHNa5OS0qdgZoy = ziLFAe3mdEZypx0JCXwbfPBHg6(FcTdplGwy7AZV1bosj,VGPNayc6DgkReH1xC9BE3uFO475bf)
		S85FOrQ2sZNmT = sorted(mWFGACDMkb3lreHNa5OS0qdgZoy,reverse=False,key=lambda key: key[1].lower())
	else:
		if not XTA49cQUuV.RwN5lZjvPsLCW7gz9c0ab1x('',True): return
		if nHKoSC1PiDe8RFambXd7wGf and '_CREATENEW_' not in VGPNayc6DgkReH1xC9BE3uFO475bf:
			S85FOrQ2sZNmT = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,'list','SECTIONS_IPTV','SECTIONS_IPTV_ALL')
		else:
			F0YPE4deztmjAhVs2qpXNKfT1uo,S85FOrQ2sZNmT,mWFGACDMkb3lreHNa5OS0qdgZoy = [],[],[]
			for BkbqIDygemnoJuxYZXRiGEKH742S in range(1,qHwLO4cGVh+1):
				S85FOrQ2sZNmT += ziLFAe3mdEZypx0JCXwbfPBHg6(str(BkbqIDygemnoJuxYZXRiGEKH742S),VGPNayc6DgkReH1xC9BE3uFO475bf)
			for type,GG9zmPqulYDyJCtWwkE8,url,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,RxgdTHfDar8EXt,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH in S85FOrQ2sZNmT:
				if RxgdTHfDar8EXt not in F0YPE4deztmjAhVs2qpXNKfT1uo:
					F0YPE4deztmjAhVs2qpXNKfT1uo.append(RxgdTHfDar8EXt)
					GYh0VQFHA5kfP6UzItyWDSji278 = type,GG9zmPqulYDyJCtWwkE8,RxgdTHfDar8EXt,165,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,VGPNayc6DgkReH1xC9BE3uFO475bf,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH
					mWFGACDMkb3lreHNa5OS0qdgZoy.append(GYh0VQFHA5kfP6UzItyWDSji278)
			S85FOrQ2sZNmT = sorted(mWFGACDMkb3lreHNa5OS0qdgZoy,reverse=False,key=lambda key: key[1].lower())
			if nHKoSC1PiDe8RFambXd7wGf: kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,'SECTIONS_IPTV','SECTIONS_IPTV_ALL',S85FOrQ2sZNmT,D0vjfyxKZuP7pXknq62MwFYU)
	muPDGHvJwFieQYCW62bB[:] = K8u1V3oUgMvY6Tb2NyaqznRS+S85FOrQ2sZNmT
	oos8ymFi9CN2z1jXcR.executebuiltin('Container.Refresh')
	return
def PSkwGBMhxnU3yi0E9u2qFR7NA4l(FcTdplGwy7AZV1bosj,VGPNayc6DgkReH1xC9BE3uFO475bf):
	nHKoSC1PiDe8RFambXd7wGf = False
	if nHKoSC1PiDe8RFambXd7wGf:
		tBq8fTGUWJY9zvbgXD0EAloPO('link','تحديث هذه القائمة','',765,'','','_CREATENEW_','',{'folder':FcTdplGwy7AZV1bosj})
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	K8u1V3oUgMvY6Tb2NyaqznRS = muPDGHvJwFieQYCW62bB[:]
	import ytYp4ZnKL3
	if FcTdplGwy7AZV1bosj:
		if not ytYp4ZnKL3.RwN5lZjvPsLCW7gz9c0ab1x(FcTdplGwy7AZV1bosj,True): return
		mWFGACDMkb3lreHNa5OS0qdgZoy = sIZNM2FUkX(FcTdplGwy7AZV1bosj,VGPNayc6DgkReH1xC9BE3uFO475bf)
		S85FOrQ2sZNmT = sorted(mWFGACDMkb3lreHNa5OS0qdgZoy,reverse=False,key=lambda key: key[1].lower())
	else:
		if not ytYp4ZnKL3.RwN5lZjvPsLCW7gz9c0ab1x('',True): return
		if nHKoSC1PiDe8RFambXd7wGf and '_CREATENEW_' not in VGPNayc6DgkReH1xC9BE3uFO475bf:
			S85FOrQ2sZNmT = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,'list','SECTIONS_M3U','SECTIONS_M3U_ALL')
		else:
			F0YPE4deztmjAhVs2qpXNKfT1uo,S85FOrQ2sZNmT,mWFGACDMkb3lreHNa5OS0qdgZoy = [],[],[]
			for BkbqIDygemnoJuxYZXRiGEKH742S in range(1,qHwLO4cGVh+1):
				S85FOrQ2sZNmT += sIZNM2FUkX(str(BkbqIDygemnoJuxYZXRiGEKH742S),VGPNayc6DgkReH1xC9BE3uFO475bf)
			for type,GG9zmPqulYDyJCtWwkE8,url,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,RxgdTHfDar8EXt,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH in S85FOrQ2sZNmT:
				if RxgdTHfDar8EXt not in F0YPE4deztmjAhVs2qpXNKfT1uo:
					F0YPE4deztmjAhVs2qpXNKfT1uo.append(RxgdTHfDar8EXt)
					GYh0VQFHA5kfP6UzItyWDSji278 = type,GG9zmPqulYDyJCtWwkE8,RxgdTHfDar8EXt,165,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,VGPNayc6DgkReH1xC9BE3uFO475bf,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH
					mWFGACDMkb3lreHNa5OS0qdgZoy.append(GYh0VQFHA5kfP6UzItyWDSji278)
			S85FOrQ2sZNmT = sorted(mWFGACDMkb3lreHNa5OS0qdgZoy,reverse=False,key=lambda key: key[1].lower())
			if nHKoSC1PiDe8RFambXd7wGf: kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,'SECTIONS_M3U','SECTIONS_M3U_ALL',S85FOrQ2sZNmT,D0vjfyxKZuP7pXknq62MwFYU)
	muPDGHvJwFieQYCW62bB[:] = K8u1V3oUgMvY6Tb2NyaqznRS+S85FOrQ2sZNmT
	oos8ymFi9CN2z1jXcR.executebuiltin('Container.Refresh')
	return
def qbwHZvAp5BUcrxPGjmK9LzskaSFX(group,VGPNayc6DgkReH1xC9BE3uFO475bf):
	nHKoSC1PiDe8RFambXd7wGf = False
	s4Bng5iAZQSTtpDw9 = []
	Q1IfnmwosapDSROTAtguiK4d8V = '_IPTV_' if 'IPTV' in VGPNayc6DgkReH1xC9BE3uFO475bf else '_M3U_'
	if nHKoSC1PiDe8RFambXd7wGf: s4Bng5iAZQSTtpDw9 = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,'list','SECTIONS'+Q1IfnmwosapDSROTAtguiK4d8V[:-1],group)
	if not s4Bng5iAZQSTtpDw9:
		for FcTdplGwy7AZV1bosj in range(1,qHwLO4cGVh+1):
			if nHKoSC1PiDe8RFambXd7wGf: s4Bng5iAZQSTtpDw9 += vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,'list','SECTIONS'+Q1IfnmwosapDSROTAtguiK4d8V[:-1],'SECTIONS'+Q1IfnmwosapDSROTAtguiK4d8V+str(FcTdplGwy7AZV1bosj))
			elif Q1IfnmwosapDSROTAtguiK4d8V=='_IPTV_': s4Bng5iAZQSTtpDw9 += ziLFAe3mdEZypx0JCXwbfPBHg6(str(FcTdplGwy7AZV1bosj),'_CREATENEW_')
			elif Q1IfnmwosapDSROTAtguiK4d8V=='_M3U_': s4Bng5iAZQSTtpDw9 += sIZNM2FUkX(str(FcTdplGwy7AZV1bosj),'_CREATENEW_')
		for type,GG9zmPqulYDyJCtWwkE8,url,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,RxgdTHfDar8EXt,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH in s4Bng5iAZQSTtpDw9:
			if RxgdTHfDar8EXt==group: l2G4xA1VXjbpud(type,GG9zmPqulYDyJCtWwkE8,url,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,RxgdTHfDar8EXt,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH)
		items,HKE5ebjfkuy = [],[]
		for type,GG9zmPqulYDyJCtWwkE8,url,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,RxgdTHfDar8EXt,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH in muPDGHvJwFieQYCW62bB:
			lPyILjaMAsurTgEK6VdFGcBpY35Q = type,GG9zmPqulYDyJCtWwkE8[4:],url,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,RxgdTHfDar8EXt,HHa1QbqG07ZPXko5fR,''
			if lPyILjaMAsurTgEK6VdFGcBpY35Q not in HKE5ebjfkuy:
				HKE5ebjfkuy.append(lPyILjaMAsurTgEK6VdFGcBpY35Q)
				hh4gUqS5JWf1saRZPXHD = type,GG9zmPqulYDyJCtWwkE8,url,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,RxgdTHfDar8EXt,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH
				items.append(hh4gUqS5JWf1saRZPXHD)
		s4Bng5iAZQSTtpDw9 = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if nHKoSC1PiDe8RFambXd7wGf: kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,'SECTIONS'+Q1IfnmwosapDSROTAtguiK4d8V[:-1],group,s4Bng5iAZQSTtpDw9,D0vjfyxKZuP7pXknq62MwFYU)
	if '_RANDOM_' in VGPNayc6DgkReH1xC9BE3uFO475bf and len(s4Bng5iAZQSTtpDw9)>Ca4HNo1bJSUiw35:
		muPDGHvJwFieQYCW62bB[:] = []
		tBq8fTGUWJY9zvbgXD0EAloPO('folder','[[COLOR FFC89008]'+group+'[/COLOR] :القسم]',group,165,'','',Q1IfnmwosapDSROTAtguiK4d8V+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		tBq8fTGUWJY9zvbgXD0EAloPO('folder','إعادة الطلب العشوائي من نفس القسم',group,165,'','',Q1IfnmwosapDSROTAtguiK4d8V+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		s4Bng5iAZQSTtpDw9 = muPDGHvJwFieQYCW62bB+BBioyg7XVR.sample(s4Bng5iAZQSTtpDw9,Ca4HNo1bJSUiw35)
	muPDGHvJwFieQYCW62bB[:] = s4Bng5iAZQSTtpDw9
	oos8ymFi9CN2z1jXcR.executebuiltin('Container.Refresh')
	return
def Q1BqwZiHVfx2oga7e5ObGRCPI(VGPNayc6DgkReH1xC9BE3uFO475bf):
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','إعادة طلب قنوات عشوائية','',161,'','','_FORGETRESULTS__REMEMBERRESULTS__LIVETV__RANDOM_')
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	g0ymbqnh9F3IAKUBQ = muPDGHvJwFieQYCW62bB[:]
	muPDGHvJwFieQYCW62bB[:] = []
	import n2YezkX8vr
	n2YezkX8vr.Hb39UqlX2fZDpc('0',False)
	n2YezkX8vr.Hb39UqlX2fZDpc('1',False)
	n2YezkX8vr.Hb39UqlX2fZDpc('2',False)
	if '_RANDOM_' in VGPNayc6DgkReH1xC9BE3uFO475bf:
		muPDGHvJwFieQYCW62bB[:] = TjfUYcikI5Px3NLu0zqH(muPDGHvJwFieQYCW62bB)
		if len(muPDGHvJwFieQYCW62bB)>Ca4HNo1bJSUiw35: muPDGHvJwFieQYCW62bB[:] = BBioyg7XVR.sample(muPDGHvJwFieQYCW62bB,Ca4HNo1bJSUiw35)
	muPDGHvJwFieQYCW62bB[:] = g0ymbqnh9F3IAKUBQ+muPDGHvJwFieQYCW62bB
	return
def mpaJVgkKAxOPo8QIfLv2(VGPNayc6DgkReH1xC9BE3uFO475bf):
	VGPNayc6DgkReH1xC9BE3uFO475bf = VGPNayc6DgkReH1xC9BE3uFO475bf.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	headers = { 'User-Agent' : '' }
	url = 'https://www.bestrandoms.com/random-arabic-words'
	data = {'quantity':'50'}
	data = cswW2KC5FOH64vq97ZkNR(data)
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(RvKQX7HgZ6faBueLsMjxGtPobTd0,'GET',url,data,headers,'','','RANDOMS-RANDOM_VIDEOS_FROM_WORDS-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="content"(.*?)class="clearfix"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<span>(.*?)</span>.*?<span>(.*?)</span>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	D0Pw1kj8uzhULEo9VYNInOtvXrGy,CwObG4nmZ5EM3z = list(zip(*items))
	gvmLezoydJk = []
	pWhC35oEX2sj4ta6cVNl = [' ','"','`',',','.',':',';',"'",'-']
	mZnpLi2uEAc9QJ60dY = CwObG4nmZ5EM3z+D0Pw1kj8uzhULEo9VYNInOtvXrGy
	for qqPhMYQnVkNKHD3SuA6GoyZ5 in mZnpLi2uEAc9QJ60dY:
		if qqPhMYQnVkNKHD3SuA6GoyZ5 in CwObG4nmZ5EM3z: bmjZdDPy0SJ = 2
		if qqPhMYQnVkNKHD3SuA6GoyZ5 in D0Pw1kj8uzhULEo9VYNInOtvXrGy: bmjZdDPy0SJ = 4
		fdB8bNoOmUezCnG7FLv6HjsVRpEQ3W = [AudBQkLFsrHKicIogThZyv in qqPhMYQnVkNKHD3SuA6GoyZ5 for AudBQkLFsrHKicIogThZyv in pWhC35oEX2sj4ta6cVNl]
		if any(fdB8bNoOmUezCnG7FLv6HjsVRpEQ3W):
			EeWNT4ZgLwnchCSIjJKX = fdB8bNoOmUezCnG7FLv6HjsVRpEQ3W.index(True)
			BkDAh8LCHoYXIpN9ftFqJPcwSe6 = pWhC35oEX2sj4ta6cVNl[EeWNT4ZgLwnchCSIjJKX]
			G1hHSQ7X2IYAEPTc = ''
			if qqPhMYQnVkNKHD3SuA6GoyZ5.count(BkDAh8LCHoYXIpN9ftFqJPcwSe6)>1: ZO0jfFu2vpB,O0ONcAyFPhziq7M6T95tR4Q,G1hHSQ7X2IYAEPTc = qqPhMYQnVkNKHD3SuA6GoyZ5.split(BkDAh8LCHoYXIpN9ftFqJPcwSe6,2)
			else: ZO0jfFu2vpB,O0ONcAyFPhziq7M6T95tR4Q = qqPhMYQnVkNKHD3SuA6GoyZ5.split(BkDAh8LCHoYXIpN9ftFqJPcwSe6,1)
			if len(ZO0jfFu2vpB)>bmjZdDPy0SJ: gvmLezoydJk.append(ZO0jfFu2vpB.lower())
			if len(O0ONcAyFPhziq7M6T95tR4Q)>bmjZdDPy0SJ: gvmLezoydJk.append(O0ONcAyFPhziq7M6T95tR4Q.lower())
			if len(G1hHSQ7X2IYAEPTc)>bmjZdDPy0SJ: gvmLezoydJk.append(G1hHSQ7X2IYAEPTc.lower())
		elif len(qqPhMYQnVkNKHD3SuA6GoyZ5)>bmjZdDPy0SJ: gvmLezoydJk.append(qqPhMYQnVkNKHD3SuA6GoyZ5.lower())
	for AudBQkLFsrHKicIogThZyv in range(9): BBioyg7XVR.shuffle(gvmLezoydJk)
	if '_SITES_' in VGPNayc6DgkReH1xC9BE3uFO475bf:
		IQlwjAgWCXvy2Ezp9r6sKT1M4nki = VV7Iv9cSholtn1MJsrXTjRLGy4ie
	elif '_IPTV_' in VGPNayc6DgkReH1xC9BE3uFO475bf:
		IQlwjAgWCXvy2Ezp9r6sKT1M4nki = ['IPTV']
		import XTA49cQUuV
		if not XTA49cQUuV.RwN5lZjvPsLCW7gz9c0ab1x('',True): return
	elif '_M3U_' in VGPNayc6DgkReH1xC9BE3uFO475bf:
		IQlwjAgWCXvy2Ezp9r6sKT1M4nki = ['M3U']
		import ytYp4ZnKL3
		if not ytYp4ZnKL3.RwN5lZjvPsLCW7gz9c0ab1x('',True): return
	count,Naowv710En4jRIipd6AS3X = 0,0
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','[  ] :البحث عن','',164,'','','_FORGETRESULTS__REMEMBERRESULTS_'+VGPNayc6DgkReH1xC9BE3uFO475bf)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','إعادة البحث العشوائي','',164,'','','_FORGETRESULTS__REMEMBERRESULTS_'+VGPNayc6DgkReH1xC9BE3uFO475bf)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	NNta4RosKpx2Y6ArZmfizkD = muPDGHvJwFieQYCW62bB[:]
	muPDGHvJwFieQYCW62bB[:] = []
	O2KhSxAi3Ys7zjX4Dp5n = []
	for qqPhMYQnVkNKHD3SuA6GoyZ5 in gvmLezoydJk:
		O0ONcAyFPhziq7M6T95tR4Q = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('[ \,\;\:\-\+\=\"\'\[\]\(\)\{\}\!\@'+'#'+'\$\%\^\&\*\_\<\>]',qqPhMYQnVkNKHD3SuA6GoyZ5,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if O0ONcAyFPhziq7M6T95tR4Q: qqPhMYQnVkNKHD3SuA6GoyZ5 = qqPhMYQnVkNKHD3SuA6GoyZ5.split(O0ONcAyFPhziq7M6T95tR4Q[0],1)[0]
		vvekXuOIhfJHtB1Z0c5Vo3pK7C = qqPhMYQnVkNKHD3SuA6GoyZ5.replace('ّ','').replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
		vvekXuOIhfJHtB1Z0c5Vo3pK7C = vvekXuOIhfJHtB1Z0c5Vo3pK7C.replace('ِ','').replace('ٍ','').replace('ْ','').replace('،','').replace('ـ','')
		if vvekXuOIhfJHtB1Z0c5Vo3pK7C: O2KhSxAi3Ys7zjX4Dp5n.append(vvekXuOIhfJHtB1Z0c5Vo3pK7C)
	Ay7FVXzarQPqkR3HGDuv9L = []
	for Deiz7ocWQjVnIg in range(0,20):
		search = BBioyg7XVR.sample(O2KhSxAi3Ys7zjX4Dp5n,1)[0]
		if search in Ay7FVXzarQPqkR3HGDuv9L: continue
		Ay7FVXzarQPqkR3HGDuv9L.append(search)
		VewOrPR4kX = BBioyg7XVR.sample(IQlwjAgWCXvy2Ezp9r6sKT1M4nki,1)[0]
		y75wQavkVSLUb2MZf9qo('NOTICE',Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+'   Random Video Search   site:'+str(VewOrPR4kX)+'  search:'+search)
		HmcsWL3qzIatv,jRreTXMs4JNBbt0Y,nROJXLEM6K = zzPTrDE4vhj2Bl8qFmiyWec(VewOrPR4kX)
		jRreTXMs4JNBbt0Y(search+'_NODIALOGS_')
		if len(muPDGHvJwFieQYCW62bB)>0: break
	search = search.replace('_MOD_','')
	NNta4RosKpx2Y6ArZmfizkD[0][1] = '[[COLOR FFC89008]'+search+'[/COLOR] :بحث عن]'
	muPDGHvJwFieQYCW62bB[:] = TjfUYcikI5Px3NLu0zqH(muPDGHvJwFieQYCW62bB)
	if len(muPDGHvJwFieQYCW62bB)>Ca4HNo1bJSUiw35: muPDGHvJwFieQYCW62bB[:] = BBioyg7XVR.sample(muPDGHvJwFieQYCW62bB,Ca4HNo1bJSUiw35)
	muPDGHvJwFieQYCW62bB[:] = NNta4RosKpx2Y6ArZmfizkD+muPDGHvJwFieQYCW62bB
	return
def GyDdU4j8eNbwJKVF9C(g43taHjFZGslq,VGPNayc6DgkReH1xC9BE3uFO475bf):
	g43taHjFZGslq = g43taHjFZGslq.replace('_MOD_','')
	VGPNayc6DgkReH1xC9BE3uFO475bf = VGPNayc6DgkReH1xC9BE3uFO475bf.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	z3UtB4dqH2WkwMrXZ9hDb(False)
	if FEzkPuAaomBVKvS4pfx8=={}: return
	if '_RANDOM_' in VGPNayc6DgkReH1xC9BE3uFO475bf:
		tBq8fTGUWJY9zvbgXD0EAloPO('folder','[[COLOR FFC89008]'+g43taHjFZGslq+'[/COLOR] :القسم]',g43taHjFZGslq,166,'','','_FORGETRESULTS__REMEMBERRESULTS_'+VGPNayc6DgkReH1xC9BE3uFO475bf)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder','إعادة الطلب العشوائي من نفس القسم',g43taHjFZGslq,166,'','','_FORGETRESULTS__REMEMBERRESULTS_'+VGPNayc6DgkReH1xC9BE3uFO475bf)
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for website in sorted(list(FEzkPuAaomBVKvS4pfx8[g43taHjFZGslq].keys())):
		type,GG9zmPqulYDyJCtWwkE8,url,gHRCjEDhqTldIzKO8VFiMp3yA14,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,RxgdTHfDar8EXt,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH = FEzkPuAaomBVKvS4pfx8[g43taHjFZGslq][website]
		if '_RANDOM_' in VGPNayc6DgkReH1xC9BE3uFO475bf or len(FEzkPuAaomBVKvS4pfx8[g43taHjFZGslq])==1:
			l2G4xA1VXjbpud(type,'',url,gHRCjEDhqTldIzKO8VFiMp3yA14,'',tsMKaFVh1ZN2BIXEcvTejxR5DP,RxgdTHfDar8EXt,'','')
			muPDGHvJwFieQYCW62bB[:] = TjfUYcikI5Px3NLu0zqH(muPDGHvJwFieQYCW62bB)
			K8u1V3oUgMvY6Tb2NyaqznRS,S85FOrQ2sZNmT = muPDGHvJwFieQYCW62bB[:3],muPDGHvJwFieQYCW62bB[3:]
			for AudBQkLFsrHKicIogThZyv in range(9): BBioyg7XVR.shuffle(S85FOrQ2sZNmT)
			if '_RANDOM_' in VGPNayc6DgkReH1xC9BE3uFO475bf: muPDGHvJwFieQYCW62bB[:] = K8u1V3oUgMvY6Tb2NyaqznRS+S85FOrQ2sZNmT[:Ca4HNo1bJSUiw35]
			else: muPDGHvJwFieQYCW62bB[:] = K8u1V3oUgMvY6Tb2NyaqznRS+S85FOrQ2sZNmT
		elif '_SITES_' in VGPNayc6DgkReH1xC9BE3uFO475bf: tBq8fTGUWJY9zvbgXD0EAloPO('folder',website,url,gHRCjEDhqTldIzKO8VFiMp3yA14,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,RxgdTHfDar8EXt,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH)
	return
def iPq0FbZ157UDHsSOX(VGPNayc6DgkReH1xC9BE3uFO475bf,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw):
	VGPNayc6DgkReH1xC9BE3uFO475bf = VGPNayc6DgkReH1xC9BE3uFO475bf.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	GG9zmPqulYDyJCtWwkE8,Vgfb104hNGU6ct7y2BoCDjQ8 = '',[]
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','[[COLOR FFC89008]'+GG9zmPqulYDyJCtWwkE8+'[/COLOR] :القسم]','',n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,'','','_FORGETRESULTS__REMEMBERRESULTS_'+VGPNayc6DgkReH1xC9BE3uFO475bf)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','إعادة طلب قسم عشوائي','',n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,'','','_FORGETRESULTS__REMEMBERRESULTS_'+VGPNayc6DgkReH1xC9BE3uFO475bf)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	K8u1V3oUgMvY6Tb2NyaqznRS = muPDGHvJwFieQYCW62bB[:]
	muPDGHvJwFieQYCW62bB[:] = []
	s4Bng5iAZQSTtpDw9 = []
	if '_SITES_' in VGPNayc6DgkReH1xC9BE3uFO475bf:
		z3UtB4dqH2WkwMrXZ9hDb(False)
		if FEzkPuAaomBVKvS4pfx8=={}: return
		bvoEJOIiT3A4jg9WPUxn7ykw = list(FEzkPuAaomBVKvS4pfx8.keys())
		g43taHjFZGslq = BBioyg7XVR.sample(bvoEJOIiT3A4jg9WPUxn7ykw,1)[0]
		gvmLezoydJk = list(FEzkPuAaomBVKvS4pfx8[g43taHjFZGslq].keys())
		website = BBioyg7XVR.sample(gvmLezoydJk,1)[0]
		type,GG9zmPqulYDyJCtWwkE8,url,gHRCjEDhqTldIzKO8VFiMp3yA14,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,RxgdTHfDar8EXt,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH = FEzkPuAaomBVKvS4pfx8[g43taHjFZGslq][website]
		y75wQavkVSLUb2MZf9qo('NOTICE',Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+'   Random Category   website: '+website+'   name: '+GG9zmPqulYDyJCtWwkE8+'   url: '+url+'   mode: '+str(gHRCjEDhqTldIzKO8VFiMp3yA14))
	elif '_IPTV_' in VGPNayc6DgkReH1xC9BE3uFO475bf:
		import XTA49cQUuV
		if not XTA49cQUuV.RwN5lZjvPsLCW7gz9c0ab1x('',True): return
		for FcTdplGwy7AZV1bosj in range(1,qHwLO4cGVh+1):
			s4Bng5iAZQSTtpDw9 += ziLFAe3mdEZypx0JCXwbfPBHg6(str(FcTdplGwy7AZV1bosj),VGPNayc6DgkReH1xC9BE3uFO475bf)
		if not s4Bng5iAZQSTtpDw9: return
		type,GG9zmPqulYDyJCtWwkE8,url,gHRCjEDhqTldIzKO8VFiMp3yA14,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,RxgdTHfDar8EXt,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH = BBioyg7XVR.sample(s4Bng5iAZQSTtpDw9,1)[0]
		y75wQavkVSLUb2MZf9qo('NOTICE',Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+'   Random Category   name: '+GG9zmPqulYDyJCtWwkE8+'   url: '+url+'   mode: '+str(gHRCjEDhqTldIzKO8VFiMp3yA14))
	elif '_M3U_' in VGPNayc6DgkReH1xC9BE3uFO475bf:
		import ytYp4ZnKL3
		if not ytYp4ZnKL3.RwN5lZjvPsLCW7gz9c0ab1x('',True): return
		for FcTdplGwy7AZV1bosj in range(1,qHwLO4cGVh+1):
			s4Bng5iAZQSTtpDw9 += sIZNM2FUkX(str(FcTdplGwy7AZV1bosj),VGPNayc6DgkReH1xC9BE3uFO475bf)
		if not s4Bng5iAZQSTtpDw9: return
		type,GG9zmPqulYDyJCtWwkE8,url,gHRCjEDhqTldIzKO8VFiMp3yA14,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,RxgdTHfDar8EXt,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH = BBioyg7XVR.sample(s4Bng5iAZQSTtpDw9,1)[0]
		y75wQavkVSLUb2MZf9qo('NOTICE',Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+'   Random Category   name: '+GG9zmPqulYDyJCtWwkE8+'   url: '+url+'   mode: '+str(gHRCjEDhqTldIzKO8VFiMp3yA14))
	rW3cEIDSeTu4AVgvCmaU7qki9 = GG9zmPqulYDyJCtWwkE8
	OK2JuT8hwdSBsGcEqt = []
	for AudBQkLFsrHKicIogThZyv in range(0,10):
		if AudBQkLFsrHKicIogThZyv>0: y75wQavkVSLUb2MZf9qo('NOTICE',Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+'   Random Category   name: '+GG9zmPqulYDyJCtWwkE8+'   url: '+url+'   mode: '+str(gHRCjEDhqTldIzKO8VFiMp3yA14))
		muPDGHvJwFieQYCW62bB[:] = []
		if gHRCjEDhqTldIzKO8VFiMp3yA14==234 and '__IPTVSeries__' in RxgdTHfDar8EXt: gHRCjEDhqTldIzKO8VFiMp3yA14 = 233
		if gHRCjEDhqTldIzKO8VFiMp3yA14==714 and '__M3USeries__' in RxgdTHfDar8EXt: gHRCjEDhqTldIzKO8VFiMp3yA14 = 713
		if gHRCjEDhqTldIzKO8VFiMp3yA14==144: gHRCjEDhqTldIzKO8VFiMp3yA14 = 291
		aQ0kNq9gnYBKJ5yV6oRhXZ7ImfwreT = l2G4xA1VXjbpud(type,GG9zmPqulYDyJCtWwkE8,url,gHRCjEDhqTldIzKO8VFiMp3yA14,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,RxgdTHfDar8EXt,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH)
		if '_IPTV_' in VGPNayc6DgkReH1xC9BE3uFO475bf and gHRCjEDhqTldIzKO8VFiMp3yA14==167: del muPDGHvJwFieQYCW62bB[:3]
		if '_M3U_' in VGPNayc6DgkReH1xC9BE3uFO475bf and gHRCjEDhqTldIzKO8VFiMp3yA14==168: del muPDGHvJwFieQYCW62bB[:3]
		Vgfb104hNGU6ct7y2BoCDjQ8[:] = TjfUYcikI5Px3NLu0zqH(muPDGHvJwFieQYCW62bB)
		if OK2JuT8hwdSBsGcEqt and UjfpeA9CkYxt8XV(u'حلقة') in str(Vgfb104hNGU6ct7y2BoCDjQ8) or UjfpeA9CkYxt8XV(u'حلقه') in str(Vgfb104hNGU6ct7y2BoCDjQ8):
			GG9zmPqulYDyJCtWwkE8 = rW3cEIDSeTu4AVgvCmaU7qki9
			Vgfb104hNGU6ct7y2BoCDjQ8[:] = OK2JuT8hwdSBsGcEqt
			break
		rW3cEIDSeTu4AVgvCmaU7qki9 = GG9zmPqulYDyJCtWwkE8
		OK2JuT8hwdSBsGcEqt = Vgfb104hNGU6ct7y2BoCDjQ8
		if str(Vgfb104hNGU6ct7y2BoCDjQ8).count('video')>0: break
		if str(Vgfb104hNGU6ct7y2BoCDjQ8).count('live')>0: break
		if gHRCjEDhqTldIzKO8VFiMp3yA14==233: break
		if gHRCjEDhqTldIzKO8VFiMp3yA14==713: break
		if gHRCjEDhqTldIzKO8VFiMp3yA14==291: break
		if Vgfb104hNGU6ct7y2BoCDjQ8: type,GG9zmPqulYDyJCtWwkE8,url,gHRCjEDhqTldIzKO8VFiMp3yA14,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,RxgdTHfDar8EXt,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH = BBioyg7XVR.sample(Vgfb104hNGU6ct7y2BoCDjQ8,1)[0]
	if not GG9zmPqulYDyJCtWwkE8: GG9zmPqulYDyJCtWwkE8 = '....'
	elif GG9zmPqulYDyJCtWwkE8.count('_')>1: GG9zmPqulYDyJCtWwkE8 = GG9zmPqulYDyJCtWwkE8.split('_',2)[2]
	GG9zmPqulYDyJCtWwkE8 = GG9zmPqulYDyJCtWwkE8.replace('UNKNOWN: ','')
	GG9zmPqulYDyJCtWwkE8 = GG9zmPqulYDyJCtWwkE8.replace('_MOD_','')
	K8u1V3oUgMvY6Tb2NyaqznRS[0][1] = '[[COLOR FFC89008]'+GG9zmPqulYDyJCtWwkE8+'[/COLOR] :القسم]'
	for AudBQkLFsrHKicIogThZyv in range(9): BBioyg7XVR.shuffle(Vgfb104hNGU6ct7y2BoCDjQ8)
	if '_RANDOM_' in VGPNayc6DgkReH1xC9BE3uFO475bf: muPDGHvJwFieQYCW62bB[:] = K8u1V3oUgMvY6Tb2NyaqznRS+Vgfb104hNGU6ct7y2BoCDjQ8[:Ca4HNo1bJSUiw35]
	else: muPDGHvJwFieQYCW62bB[:] = K8u1V3oUgMvY6Tb2NyaqznRS+Vgfb104hNGU6ct7y2BoCDjQ8
	return
def awFqpKe2WGNVRzjQ0MtOn(HSdtFzPpEZw4qL16yoDUOau5fNY,yRihq1wjs5GDoIYftSOQdL4re9kXEv):
	yRihq1wjs5GDoIYftSOQdL4re9kXEv = yRihq1wjs5GDoIYftSOQdL4re9kXEv.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	DszcbwlmHC8v9ZF = yRihq1wjs5GDoIYftSOQdL4re9kXEv
	if '__IPTVSeries__' in yRihq1wjs5GDoIYftSOQdL4re9kXEv:
		DszcbwlmHC8v9ZF = yRihq1wjs5GDoIYftSOQdL4re9kXEv.split('__IPTVSeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in HSdtFzPpEZw4qL16yoDUOau5fNY: type = ',VIDEOS: '
	elif 'LIVE' in HSdtFzPpEZw4qL16yoDUOau5fNY: type = ',LIVE: '
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','[[COLOR FFC89008]'+type+DszcbwlmHC8v9ZF+'[/COLOR] :القسم]',HSdtFzPpEZw4qL16yoDUOau5fNY,167,'','','_FORGETRESULTS__REMEMBERRESULTS_'+yRihq1wjs5GDoIYftSOQdL4re9kXEv)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','إعادة الطلب العشوائي من نفس القسم',HSdtFzPpEZw4qL16yoDUOau5fNY,167,'','','_FORGETRESULTS__REMEMBERRESULTS_'+yRihq1wjs5GDoIYftSOQdL4re9kXEv)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	import XTA49cQUuV
	for FcTdplGwy7AZV1bosj in range(1,qHwLO4cGVh+1):
		if '__IPTVSeries__' in yRihq1wjs5GDoIYftSOQdL4re9kXEv: XTA49cQUuV.ddvQlFmprDb(str(FcTdplGwy7AZV1bosj),HSdtFzPpEZw4qL16yoDUOau5fNY,yRihq1wjs5GDoIYftSOQdL4re9kXEv,'',False)
		else: XTA49cQUuV.Hb39UqlX2fZDpc(str(FcTdplGwy7AZV1bosj),HSdtFzPpEZw4qL16yoDUOau5fNY,yRihq1wjs5GDoIYftSOQdL4re9kXEv,'',False)
	muPDGHvJwFieQYCW62bB[:] = TjfUYcikI5Px3NLu0zqH(muPDGHvJwFieQYCW62bB)
	if len(muPDGHvJwFieQYCW62bB)>(Ca4HNo1bJSUiw35+3): muPDGHvJwFieQYCW62bB[:] = muPDGHvJwFieQYCW62bB[:3]+BBioyg7XVR.sample(muPDGHvJwFieQYCW62bB[3:],Ca4HNo1bJSUiw35)
	return
def RUAmzjCxcDLqHQKS5bOgFdoXkGB(HSdtFzPpEZw4qL16yoDUOau5fNY,yRihq1wjs5GDoIYftSOQdL4re9kXEv):
	yRihq1wjs5GDoIYftSOQdL4re9kXEv = yRihq1wjs5GDoIYftSOQdL4re9kXEv.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	DszcbwlmHC8v9ZF = yRihq1wjs5GDoIYftSOQdL4re9kXEv
	if '__M3USeries__' in yRihq1wjs5GDoIYftSOQdL4re9kXEv:
		DszcbwlmHC8v9ZF = yRihq1wjs5GDoIYftSOQdL4re9kXEv.split('__M3USeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in HSdtFzPpEZw4qL16yoDUOau5fNY: type = ',VIDEOS: '
	elif 'LIVE' in HSdtFzPpEZw4qL16yoDUOau5fNY: type = ',LIVE: '
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','[[COLOR FFC89008]'+type+DszcbwlmHC8v9ZF+'[/COLOR] :القسم]',HSdtFzPpEZw4qL16yoDUOau5fNY,168,'','','_FORGETRESULTS__REMEMBERRESULTS_'+yRihq1wjs5GDoIYftSOQdL4re9kXEv)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','إعادة الطلب العشوائي من نفس القسم',HSdtFzPpEZw4qL16yoDUOau5fNY,168,'','','_FORGETRESULTS__REMEMBERRESULTS_'+yRihq1wjs5GDoIYftSOQdL4re9kXEv)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	import ytYp4ZnKL3
	for FcTdplGwy7AZV1bosj in range(1,qHwLO4cGVh+1):
		if '__M3USeries__' in yRihq1wjs5GDoIYftSOQdL4re9kXEv: ytYp4ZnKL3.ddvQlFmprDb(str(FcTdplGwy7AZV1bosj),HSdtFzPpEZw4qL16yoDUOau5fNY,yRihq1wjs5GDoIYftSOQdL4re9kXEv,'',False)
		else: ytYp4ZnKL3.Hb39UqlX2fZDpc(str(FcTdplGwy7AZV1bosj),HSdtFzPpEZw4qL16yoDUOau5fNY,yRihq1wjs5GDoIYftSOQdL4re9kXEv,'',False)
	muPDGHvJwFieQYCW62bB[:] = TjfUYcikI5Px3NLu0zqH(muPDGHvJwFieQYCW62bB)
	if len(muPDGHvJwFieQYCW62bB)>(Ca4HNo1bJSUiw35+3): muPDGHvJwFieQYCW62bB[:] = muPDGHvJwFieQYCW62bB[:3]+BBioyg7XVR.sample(muPDGHvJwFieQYCW62bB[3:],Ca4HNo1bJSUiw35)
	return
def TjfUYcikI5Px3NLu0zqH(muPDGHvJwFieQYCW62bB):
	Vgfb104hNGU6ct7y2BoCDjQ8 = []
	for type,GG9zmPqulYDyJCtWwkE8,url,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,RxgdTHfDar8EXt,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH in muPDGHvJwFieQYCW62bB:
		if 'صفحة' in GG9zmPqulYDyJCtWwkE8 or 'صفحه' in GG9zmPqulYDyJCtWwkE8 or 'page' in GG9zmPqulYDyJCtWwkE8.lower(): continue
		Vgfb104hNGU6ct7y2BoCDjQ8.append([type,GG9zmPqulYDyJCtWwkE8,url,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,RxgdTHfDar8EXt,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH])
	return Vgfb104hNGU6ct7y2BoCDjQ8
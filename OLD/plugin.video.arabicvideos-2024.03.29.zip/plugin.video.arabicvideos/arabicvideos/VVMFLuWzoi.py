﻿# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
def HgQCVwFx2Br(n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,dJWCrb19li6oDKY5V8xBtn):
	if dJWCrb19li6oDKY5V8xBtn=='': return
	if n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==1:
		eCKaqGS2vs7bQ8cTZW = ZuEAJR1lNHkUf0.getCurrentWindowDialogId()
		Yy2HOceDK9u = ZuEAJR1lNHkUf0.Window(eCKaqGS2vs7bQ8cTZW)
		dJWCrb19li6oDKY5V8xBtn = UdhlykB6XfC5NZVqORE0IQY(dJWCrb19li6oDKY5V8xBtn)
		Yy2HOceDK9u.getControl(311).setLabel(dJWCrb19li6oDKY5V8xBtn)
	if n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==0:
		Rl48v7kIh3cgF1fzOS6mQ9='X'
		if wvkR1es6d0SrjxKt5FZTMUWz7a: TEBM5Y478DlKNLq = isinstance(dJWCrb19li6oDKY5V8xBtn,str)
		else: TEBM5Y478DlKNLq = isinstance(dJWCrb19li6oDKY5V8xBtn,unicode)
		if TEBM5Y478DlKNLq==True: Rl48v7kIh3cgF1fzOS6mQ9='U'
		RfTDwyCprlOPiAqSaVbz3=str(type(dJWCrb19li6oDKY5V8xBtn))+' '+dJWCrb19li6oDKY5V8xBtn+' '+Rl48v7kIh3cgF1fzOS6mQ9+' '
		for AudBQkLFsrHKicIogThZyv in range(0,len(dJWCrb19li6oDKY5V8xBtn),1):
			RfTDwyCprlOPiAqSaVbz3 += hex(ord(dJWCrb19li6oDKY5V8xBtn[AudBQkLFsrHKicIogThZyv])).replace('0x','')+' '
		dJWCrb19li6oDKY5V8xBtn = UdhlykB6XfC5NZVqORE0IQY(dJWCrb19li6oDKY5V8xBtn)
		Rl48v7kIh3cgF1fzOS6mQ9='X'
		if wvkR1es6d0SrjxKt5FZTMUWz7a: TEBM5Y478DlKNLq = isinstance(dJWCrb19li6oDKY5V8xBtn, str)
		else: TEBM5Y478DlKNLq = isinstance(dJWCrb19li6oDKY5V8xBtn, unicode)
		if TEBM5Y478DlKNLq==True: Rl48v7kIh3cgF1fzOS6mQ9='U'
		ttCjyIfwUeMoXPOBa45m9bLc=str(type(dJWCrb19li6oDKY5V8xBtn))+' '+dJWCrb19li6oDKY5V8xBtn+' '+Rl48v7kIh3cgF1fzOS6mQ9+' '
		for AudBQkLFsrHKicIogThZyv in range(0,len(dJWCrb19li6oDKY5V8xBtn),1):
			ttCjyIfwUeMoXPOBa45m9bLc += hex(ord(dJWCrb19li6oDKY5V8xBtn[AudBQkLFsrHKicIogThZyv])).replace('0x','')+' '
	return
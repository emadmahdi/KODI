# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'RESOLVERS'
WDZKHfqBRgEcVwF1940j2bCx53 = []
headers = {'User-Agent':''}
wwm83lGzgq = ['AKWAM','SHOOFMAX','IFILM','KARBALATV','ALMAAREF','SHIAVOICE','IPTV','M3U']
def RBVfsOeZQmLIdwiYEUHx7630lt(zcBjFq4VQlp20ZekGO,source,type,url):
	if not zcBjFq4VQlp20ZekGO:
		y75wQavkVSLUb2MZf9qo('ERROR_LINES',Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+'   Failed finding video files    Site: [ '+source+' ]    Type: [ '+type+' ]')
		IAlrPELU7BqeZ = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,'dict','MISC_PERM','SITES_ERRORS')
		A85xaIbUWud1kQDF2XNV4OHmPepBR = w6vebiEZtpCjJcILP8Skx5rHn.strftime('%Y.%m.%d %H:%M',w6vebiEZtpCjJcILP8Skx5rHn.gmtime(eOYicX68ruMjpN0dKtWP5QTSE))
		Fj1YUPiHsabvulW30mzZ = A85xaIbUWud1kQDF2XNV4OHmPepBR,url
		key = source+'    '+VnhK9wvHBGuo1fei8DXQ02yFZtsWE+'    '+str(wH3qxmuXBTeak)
		maCNIYkc0HOiEGpL3g = ''
		if key not in list(IAlrPELU7BqeZ.keys()): IAlrPELU7BqeZ[key] = [Fj1YUPiHsabvulW30mzZ]
		else:
			if url not in str(IAlrPELU7BqeZ[key]): IAlrPELU7BqeZ[key].append(Fj1YUPiHsabvulW30mzZ)
			else: maCNIYkc0HOiEGpL3g = '\n هذا الفيديو موجود في قائمة الفيديوهات التي لم تعمل'
		ZOF4B7NjDE8fQM5rtGLdop = 0
		for key in list(IAlrPELU7BqeZ.keys()):
			IAlrPELU7BqeZ[key] = list(set(IAlrPELU7BqeZ[key]))
			ZOF4B7NjDE8fQM5rtGLdop += len(IAlrPELU7BqeZ[key])
		tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','للأسف البرنامج لم يجد ملفات الفيديو'+maCNIYkc0HOiEGpL3g+'\n\n للعلم البرنامج يقوم بجمع قائمة بالفيديوهات التي لم يجد لها ملفات فيديو وسوف يعرض عليك البرنامج أن ترسل هذه القائمة إلى المبرمج عندما يصبح عددها 5 فيديوهات'+'\n\n'+'عدد الفيديوهات في القائمة الآن هو :  '+str(ZOF4B7NjDE8fQM5rtGLdop))
		if ZOF4B7NjDE8fQM5rtGLdop>=5:
			A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO('','','','رسالة من المبرمج','البرنامج جمع قائمة فيها 5 فيديوهات لم يجد البرنامج لها ملفات فيديو .. سوف يقوم البرنامج الآن بمسح هذه القائمة \n\n هل تريد إرسال هذه القائمة قبل مسحها إلى المبرمج لكي يقوم المبرمج بفحص هذه الفيديوهات ؟!!')
			if A5vgi1F6qVunZMas2Nf==1:
				chj9ifUJu1 = ''
				for key in list(IAlrPELU7BqeZ.keys()):
					chj9ifUJu1 += '\n'+key
					lnAIMt3BCbmFUNkc1DQP = sorted(IAlrPELU7BqeZ[key],reverse=False,key=lambda hsaTjg9W2OybPtcozx: hsaTjg9W2OybPtcozx[0])
					for A85xaIbUWud1kQDF2XNV4OHmPepBR,url in lnAIMt3BCbmFUNkc1DQP:
						chj9ifUJu1 += '\n'+A85xaIbUWud1kQDF2XNV4OHmPepBR+'    '+BUTSkzgFC7(url)
					chj9ifUJu1 += '\n\n'
				import m4OhBzk7o2
				VZHWjJTrAPKG1eLEsxpYo2tS5 = m4OhBzk7o2.ucjsDynE7aJ('Videos','',False,'','RESOLVERS-PLAY_RESOLVERS','',chj9ifUJu1)
				if VZHWjJTrAPKG1eLEsxpYo2tS5: tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','تم الإرسال بنجاح')
				else: tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','فشلت عملية الإرسال')
			if A5vgi1F6qVunZMas2Nf!=-1:
				IAlrPELU7BqeZ = {}
				QQvOnYi9sJMwp7dIxeck8DRASWuBt(WSgQvHLx9uOKTksaCt2JchldRj,'MISC_PERM','SITES_ERRORS')
		if IAlrPELU7BqeZ: kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,'MISC_PERM','SITES_ERRORS',IAlrPELU7BqeZ,D0vjfyxKZuP7pXknq62MwFYU)
		return
	zcBjFq4VQlp20ZekGO = list(set(zcBjFq4VQlp20ZekGO))
	da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = EAWkUPBoYKLQd9zxM0b25GcswH6qg(zcBjFq4VQlp20ZekGO,source)
	qgsu7XLdCkbRHlhf5z23YvJ0Q = str(jVMHRouKgQFAESmd7B8ObTYy).count('__watch')
	lkVxbWU1XLRMfCowP4zaqYv6pD = str(jVMHRouKgQFAESmd7B8ObTYy).count('__download')
	WuPA1x8EvFlTe2q76BhR = len(jVMHRouKgQFAESmd7B8ObTYy)-qgsu7XLdCkbRHlhf5z23YvJ0Q-lkVxbWU1XLRMfCowP4zaqYv6pD
	ecWyBkJjTRhN1m37 = 'مشاهدة:'+str(qgsu7XLdCkbRHlhf5z23YvJ0Q)+'    تحميل:'+str(lkVxbWU1XLRMfCowP4zaqYv6pD)+'    أخرى:'+str(WuPA1x8EvFlTe2q76BhR)
	if not jVMHRouKgQFAESmd7B8ObTYy: ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0,d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5 = 'unresolved',''
	else:
		add = 0
		if not any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in source for hht0cpXxWw2OzFS1jnUGebkJLBd85 in wwm83lGzgq):
			add = 1
			jVMHRouKgQFAESmd7B8ObTYy = ['RESOLVE_ALL_LINKS']+list(jVMHRouKgQFAESmd7B8ObTYy)
			da6IAnqQ7oV2Hx13F5gbBT4 = ['فحص جميع السيرفرات']+list(da6IAnqQ7oV2Hx13F5gbBT4)
		while True:
			d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0 = '',''
			if add and len(jVMHRouKgQFAESmd7B8ObTYy)==2: NljOosKT8WJBpch = 1
			else: NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql(ecWyBkJjTRhN1m37,da6IAnqQ7oV2Hx13F5gbBT4)
			if NljOosKT8WJBpch==-1: ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0 = 'canceled_1st_menu'
			elif add and NljOosKT8WJBpch==0:
				ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0 = 'canceled_2nd_menu'
				s4Bng5iAZQSTtpDw9 = hMcqTzkZnyXVL(da6IAnqQ7oV2Hx13F5gbBT4[add:],jVMHRouKgQFAESmd7B8ObTYy[add:],source)
				if s4Bng5iAZQSTtpDw9:
					pG4QABNF8cOCDvi0wSa = []
					for XxVw0cbRer6ZoqF,EHIKzN5FogkhD,IW14c6VxRTUzCNjfo,jgLikzNPMmbVS7dD,c2qHPlGoas5 in s4Bng5iAZQSTtpDw9:
						if c2qHPlGoas5: pG4QABNF8cOCDvi0wSa.append((XxVw0cbRer6ZoqF,EHIKzN5FogkhD,IW14c6VxRTUzCNjfo,jgLikzNPMmbVS7dD,c2qHPlGoas5))
					if pG4QABNF8cOCDvi0wSa: da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy,errors,GReTJrIxo2dzbapy,cc0O1M4e5jtfoq = zip(*pG4QABNF8cOCDvi0wSa)
					else:
						tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','للأسف لم يتم إيجاد سيرفرات جيدة في هذا الفيديو .. حاول أن تبحث عن هذا الفيديو في مواقع أخرى')
						ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0 = 'failed'
						break
					ecWyBkJjTRhN1m37 = 'السيرفرات الجيدة ( '+str(len(jVMHRouKgQFAESmd7B8ObTYy))+' )'
					add = 0
					continue
			else:
				s4Bng5iAZQSTtpDw9 = hMcqTzkZnyXVL([da6IAnqQ7oV2Hx13F5gbBT4[NljOosKT8WJBpch]],[jVMHRouKgQFAESmd7B8ObTYy[NljOosKT8WJBpch]],source)
				if s4Bng5iAZQSTtpDw9:
					title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,errors,GReTJrIxo2dzbapy,cc0O1M4e5jtfoq = s4Bng5iAZQSTtpDw9[0]
					if not cc0O1M4e5jtfoq and not any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in source for hht0cpXxWw2OzFS1jnUGebkJLBd85 in wwm83lGzgq):
						errors,GReTJrIxo2dzbapy,cc0O1M4e5jtfoq = iobNt1X2aFC9s4KADVP57YRjyBq(ZCimQhV5lovgspAYzHq1Ef27u8ja4R,source)
					if 'سيرفر' in title and '2مجهول2' in title:
						y75wQavkVSLUb2MZf9qo('ERROR_LINES',Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+'   Unknown Selected Server   Server: [ '+title+' ]   Link: [ '+ZCimQhV5lovgspAYzHq1Ef27u8ja4R+' ]')
						import m4OhBzk7o2
						m4OhBzk7o2.YKpOxQe3lcr9aGWTiXA6vqjFd()
						ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0 = 'unresolved'
					else:
						y75wQavkVSLUb2MZf9qo('NOTICE',Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+'   Playing Selected Server   Server: [ '+title+' ]   Link: [ '+ZCimQhV5lovgspAYzHq1Ef27u8ja4R+' ]')
						ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0,d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,FQLIlWJODoV26NSpzgjb3Yu = S60fuiwbe8rT(title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,errors,GReTJrIxo2dzbapy,cc0O1M4e5jtfoq,source,type)
			if ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0 in ['EXIT_RESOLVER','download','playing','testing','canceled_1st_menu'] or len(jVMHRouKgQFAESmd7B8ObTYy)==1+add: break
			elif ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0 in ['failed','timeout','tried']: break
			elif ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0 not in ['canceled_2nd_menu','https']:
				if '\n' in d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5 = '[LEFT]  '+d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5.replace('\n','\n[LEFT]  ')
				tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','السيرفر لم يعمل جرب سيرفر غيره'+'\n'+d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,profile='confirm_mediumfont')
	if ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0=='unresolved' and len(da6IAnqQ7oV2Hx13F5gbBT4)>0: tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','سيرفر هذا الفيديو لم يعمل جرب فيديو غيره'+'\n'+d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,profile='confirm_mediumfont')
	elif ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0 in ['failed','timeout'] and d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5!='': tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج',d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,profile='confirm_mediumfont')
	return ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0
def hMcqTzkZnyXVL(DSkd2Y0zhRKLG,zcBjFq4VQlp20ZekGO,source):
	global NMZ3KR08B9Pe5vrL
	NMZ3KR08B9Pe5vrL,s4Bng5iAZQSTtpDw9,MkabctXOvJ8P1Ix,new = [],[],[],[]
	UyZEGdfW50X3Rbpzmh1CnYOuDlsk4q(False,False,False)
	count = len(zcBjFq4VQlp20ZekGO)
	for M4MgFXU1WRrCEDN in range(count):
		NMZ3KR08B9Pe5vrL.append(None)
		title = DSkd2Y0zhRKLG[M4MgFXU1WRrCEDN]
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = zcBjFq4VQlp20ZekGO[M4MgFXU1WRrCEDN].strip(' ').strip('&').strip('?').strip('/')
		if count>1: xa60ce2znAlyL5Z8ESXhO('فحص سيرفر رقم  '+str(M4MgFXU1WRrCEDN+1),title)
		pjNhB8oGIFsZL2HAEDwi = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('?named=',1)[0]
		Mm6iJDY0ZPQxwIC = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,'list','RESOLVED',pjNhB8oGIFsZL2HAEDwi)
		if Mm6iJDY0ZPQxwIC and 'AKWAM' not in source:
			NMZ3KR08B9Pe5vrL[M4MgFXU1WRrCEDN] = Mm6iJDY0ZPQxwIC
		else:
			p0CKDA15GT = mZHwnlsXWDfV3ri4M.Thread(target=iobNt1X2aFC9s4KADVP57YRjyBq,args=(ZCimQhV5lovgspAYzHq1Ef27u8ja4R,source,M4MgFXU1WRrCEDN))
			p0CKDA15GT.start()
			w6vebiEZtpCjJcILP8Skx5rHn.sleep(0.5)
			MkabctXOvJ8P1Ix.append(p0CKDA15GT)
			new.append(M4MgFXU1WRrCEDN)
	timeout = 60 if source=='AKWAM' else 20
	for p0CKDA15GT in MkabctXOvJ8P1Ix: p0CKDA15GT.join(timeout)
	for M4MgFXU1WRrCEDN in range(count):
		title = DSkd2Y0zhRKLG[M4MgFXU1WRrCEDN]
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = zcBjFq4VQlp20ZekGO[M4MgFXU1WRrCEDN].strip(' ').strip('&').strip('?').strip('/')
		if NMZ3KR08B9Pe5vrL[M4MgFXU1WRrCEDN]: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = NMZ3KR08B9Pe5vrL[M4MgFXU1WRrCEDN]
		else: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = '\nFailed:  Timeout ('+str(timeout)+' seconds)',[],[]
		s4Bng5iAZQSTtpDw9.append([title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy])
		if M4MgFXU1WRrCEDN in new:
			pjNhB8oGIFsZL2HAEDwi = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('?named=',1)[0]
			kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,'RESOLVED',pjNhB8oGIFsZL2HAEDwi,[d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy],Yv7e6ixHfZIPrmMOy3ozwJu2)
	UyZEGdfW50X3Rbpzmh1CnYOuDlsk4q('','','')
	return s4Bng5iAZQSTtpDw9
def iobNt1X2aFC9s4KADVP57YRjyBq(url,source,FZVOMyRXpio=0):
	global NMZ3KR08B9Pe5vrL
	y75wQavkVSLUb2MZf9qo('NOTICE',Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+'   Resolving started   Original: [ '+url+' ]')
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R,i2Kh4D9PuVplHbROYNZmM60ecAnE = url,''
	KXhWVR3bvy8AIY9EnB4uHZUT = 'INTERNAL_RESOLVER'
	d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = oZVHzebFUQMspfv(url,source)
	if d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5=='EXIT_RESOLVER':
		i2Kh4D9PuVplHbROYNZmM60ecAnE = '\nResolver 1:  Exit'
		NMZ3KR08B9Pe5vrL[FZVOMyRXpio] = i2Kh4D9PuVplHbROYNZmM60ecAnE,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
		return i2Kh4D9PuVplHbROYNZmM60ecAnE,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
	elif 'NEED_EXTERNAL_RESOLVERS' in d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5:
		i2Kh4D9PuVplHbROYNZmM60ecAnE = '\nResolver 1:  Need External Resolver'
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = J9JxtVzao8Busgp1IyFCXcENd(jVMHRouKgQFAESmd7B8ObTYy)[0]
		NMZ3KR08B9Pe5vrL[FZVOMyRXpio] = i2Kh4D9PuVplHbROYNZmM60ecAnE,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
		KXhWVR3bvy8AIY9EnB4uHZUT,i2Kh4D9PuVplHbROYNZmM60ecAnE,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = oxn3fOgeAS(i2Kh4D9PuVplHbROYNZmM60ecAnE,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,source,FZVOMyRXpio)
	elif d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5: i2Kh4D9PuVplHbROYNZmM60ecAnE = 'Resolver 1:  '+d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5.replace('\n','').replace('\r','')[:80]
	if jVMHRouKgQFAESmd7B8ObTYy:
		jVMHRouKgQFAESmd7B8ObTYy = J9JxtVzao8Busgp1IyFCXcENd(jVMHRouKgQFAESmd7B8ObTYy)
		y75wQavkVSLUb2MZf9qo('NOTICE',Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+'   Resolving succeeded   Resolver: [ '+KXhWVR3bvy8AIY9EnB4uHZUT+' ]   Original: [ '+url+' ]   Link: [ '+ZCimQhV5lovgspAYzHq1Ef27u8ja4R+' ]   Results: [ '+str(jVMHRouKgQFAESmd7B8ObTYy)+' ]')
	else: y75wQavkVSLUb2MZf9qo('ERROR_LINES',Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+'   Resolving failed   Original: [ '+url+' ]   Link: [ '+ZCimQhV5lovgspAYzHq1Ef27u8ja4R+' ]   Errors: [ '+i2Kh4D9PuVplHbROYNZmM60ecAnE+' ]')
	i2Kh4D9PuVplHbROYNZmM60ecAnE = BUTSkzgFC7(i2Kh4D9PuVplHbROYNZmM60ecAnE)
	NMZ3KR08B9Pe5vrL[FZVOMyRXpio] = i2Kh4D9PuVplHbROYNZmM60ecAnE,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
	return i2Kh4D9PuVplHbROYNZmM60ecAnE,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
def oxn3fOgeAS(i2Kh4D9PuVplHbROYNZmM60ecAnE,url,source,FZVOMyRXpio):
	global NMZ3KR08B9Pe5vrL
	KXhWVR3bvy8AIY9EnB4uHZUT = 'EXTERNAL_RESOLVER_2'
	d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = CeGsjf6Dcd7O(url,source)
	jVMHRouKgQFAESmd7B8ObTYy = J9JxtVzao8Busgp1IyFCXcENd(jVMHRouKgQFAESmd7B8ObTYy)
	NMZ3KR08B9Pe5vrL[FZVOMyRXpio] = i2Kh4D9PuVplHbROYNZmM60ecAnE,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
	if d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5=='EXIT_RESOLVER': return d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
	elif 'Failed:' in d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5:
		i2Kh4D9PuVplHbROYNZmM60ecAnE += '\nResolver 2:  '+d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5.replace('\n','').replace('\r','')[:80]
		KXhWVR3bvy8AIY9EnB4uHZUT = 'EXTERNAL_RESOLVER_3'
		d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = nRzgSD7watXEINBsPO2jh(url,source)
		jVMHRouKgQFAESmd7B8ObTYy = J9JxtVzao8Busgp1IyFCXcENd(jVMHRouKgQFAESmd7B8ObTYy)
		NMZ3KR08B9Pe5vrL[FZVOMyRXpio] = i2Kh4D9PuVplHbROYNZmM60ecAnE,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
		if d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5=='EXIT_RESOLVER': return d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
		elif 'Failed:' in d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5:
			i2Kh4D9PuVplHbROYNZmM60ecAnE += '\nResolver 3:  '+d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5.replace('\n','').replace('\r','')[:80]
			KXhWVR3bvy8AIY9EnB4uHZUT = 'EXTERNAL_RESOLVER_4'
			d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = fF9Z1CashvTgQPHMe7qUwY3EBp(url,source)
			jVMHRouKgQFAESmd7B8ObTYy = J9JxtVzao8Busgp1IyFCXcENd(jVMHRouKgQFAESmd7B8ObTYy)
			NMZ3KR08B9Pe5vrL[FZVOMyRXpio] = i2Kh4D9PuVplHbROYNZmM60ecAnE,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
			if d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5=='EXIT_RESOLVER': return d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
			elif 'Failed:' in d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5:
				i2Kh4D9PuVplHbROYNZmM60ecAnE += '\nResolver 4:  '+d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5.replace('\n','').replace('\r','')[:80]
				KXhWVR3bvy8AIY9EnB4uHZUT = 'EXTERNAL_RESOLVER_5'
				d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = YF21xgwAIDGQReZ5OPntfEqC67z(url,source)
				jVMHRouKgQFAESmd7B8ObTYy = J9JxtVzao8Busgp1IyFCXcENd(jVMHRouKgQFAESmd7B8ObTYy)
				NMZ3KR08B9Pe5vrL[FZVOMyRXpio] = i2Kh4D9PuVplHbROYNZmM60ecAnE,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
				if d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5=='EXIT_RESOLVER': return d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
				elif 'Failed:' in d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5:
					i2Kh4D9PuVplHbROYNZmM60ecAnE += '\nResolver 5:  '+d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5.replace('\n','').replace('\r','')[:80]
	NMZ3KR08B9Pe5vrL[FZVOMyRXpio] = i2Kh4D9PuVplHbROYNZmM60ecAnE,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
	return KXhWVR3bvy8AIY9EnB4uHZUT,i2Kh4D9PuVplHbROYNZmM60ecAnE,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
def S60fuiwbe8rT(title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy,source,type=''):
	if d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5=='EXIT_RESOLVER': return d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
	elif jVMHRouKgQFAESmd7B8ObTYy:
		while True:
			if len(jVMHRouKgQFAESmd7B8ObTYy)==1: NljOosKT8WJBpch = 0
			else: NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql('اختر الملف المناسب:', da6IAnqQ7oV2Hx13F5gbBT4)
			if NljOosKT8WJBpch==-1: ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0 = 'tried'
			else:
				bA0k69W2dcagGMQEFNP5HYn7xJBz = jVMHRouKgQFAESmd7B8ObTYy[NljOosKT8WJBpch]
				title = da6IAnqQ7oV2Hx13F5gbBT4[NljOosKT8WJBpch]
				y75wQavkVSLUb2MZf9qo('NOTICE',Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+'   Playing selected video   Selected: [ '+title+' ]   URL: [ '+str(bA0k69W2dcagGMQEFNP5HYn7xJBz)+' ]')
				if 'moshahda.' in bA0k69W2dcagGMQEFNP5HYn7xJBz and 'download_orig' in bA0k69W2dcagGMQEFNP5HYn7xJBz:
					H9iBG5PVpKun7gjRb2rhFl,ddvlQgiwbjWhyN9Rp6DAYtC,FQLIlWJODoV26NSpzgjb3Yu = zgyD31GX9hbB5OJfWcQEmo(bA0k69W2dcagGMQEFNP5HYn7xJBz)
					if FQLIlWJODoV26NSpzgjb3Yu: bA0k69W2dcagGMQEFNP5HYn7xJBz = FQLIlWJODoV26NSpzgjb3Yu[0]
					else: bA0k69W2dcagGMQEFNP5HYn7xJBz = ''
				if not bA0k69W2dcagGMQEFNP5HYn7xJBz: ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0 = 'unresolved'
				else: ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0 = pSAuLjYqhgc9brWFKs7Pa4J(bA0k69W2dcagGMQEFNP5HYn7xJBz,source,type)
			if ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0 in ['playing','testing','canceled_2nd_menu'] or len(jVMHRouKgQFAESmd7B8ObTYy)==1: break
			elif ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0 in ['failed','timeout','tried']: break
			else: tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','الملف لم يعمل جرب ملف غيره')
	else:
		ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0 = 'unresolved'
		if SU82u7LfcMslH3e0Bzihn6x(ZCimQhV5lovgspAYzHq1Ef27u8ja4R): ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0 = pSAuLjYqhgc9brWFKs7Pa4J(ZCimQhV5lovgspAYzHq1Ef27u8ja4R,source,type)
	return ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0,d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,jVMHRouKgQFAESmd7B8ObTYy
def FQKPgc4DYUojyiX5bd(url,source):
	M08MPGgsh4n5rKe,PJzMroAYIdDf13eWOLi,vMSQsdJ0gCrh7ztnR96yDXqOYaj,PtK08YMFVxiB3DqA1bRGnQyfg,GG9zmPqulYDyJCtWwkE8,type,dmSj9bwK7C0E,LjG8y1rb9AgJF2I3i64ZDtCXMa7n = url,'','','','','','',''
	if '?named=' in url:
		M08MPGgsh4n5rKe,PJzMroAYIdDf13eWOLi = url.split('?named=',1)
		PJzMroAYIdDf13eWOLi = PJzMroAYIdDf13eWOLi+'__'+'__'+'__'+'__'
		PJzMroAYIdDf13eWOLi = PJzMroAYIdDf13eWOLi.lower()
		GG9zmPqulYDyJCtWwkE8,type,dmSj9bwK7C0E,LjG8y1rb9AgJF2I3i64ZDtCXMa7n,VGtuhdKLHN = PJzMroAYIdDf13eWOLi.split('__')[:5]
	if LjG8y1rb9AgJF2I3i64ZDtCXMa7n=='': LjG8y1rb9AgJF2I3i64ZDtCXMa7n = '0'
	else: LjG8y1rb9AgJF2I3i64ZDtCXMa7n = LjG8y1rb9AgJF2I3i64ZDtCXMa7n.replace('p','').replace(' ','')
	M08MPGgsh4n5rKe = M08MPGgsh4n5rKe.strip('?').strip('/').strip('&')
	vMSQsdJ0gCrh7ztnR96yDXqOYaj = SLMTm6RQ34ic7v5s9rBG(M08MPGgsh4n5rKe,'host')
	if GG9zmPqulYDyJCtWwkE8: PtK08YMFVxiB3DqA1bRGnQyfg = GG9zmPqulYDyJCtWwkE8
	else: PtK08YMFVxiB3DqA1bRGnQyfg = vMSQsdJ0gCrh7ztnR96yDXqOYaj
	PtK08YMFVxiB3DqA1bRGnQyfg = SLMTm6RQ34ic7v5s9rBG(PtK08YMFVxiB3DqA1bRGnQyfg,'name')
	GG9zmPqulYDyJCtWwkE8 = GG9zmPqulYDyJCtWwkE8.replace('مباشر','').replace('سيرفر','').replace('ال ',' ').replace('  ',' ')
	PJzMroAYIdDf13eWOLi = PJzMroAYIdDf13eWOLi.replace('مباشر','').replace('سيرفر','').replace('ال ',' ').replace('  ',' ')
	PtK08YMFVxiB3DqA1bRGnQyfg = PtK08YMFVxiB3DqA1bRGnQyfg.replace('مباشر','').replace('سيرفر','').replace('ال ',' ').replace('  ',' ')
	return M08MPGgsh4n5rKe,PJzMroAYIdDf13eWOLi,vMSQsdJ0gCrh7ztnR96yDXqOYaj,PtK08YMFVxiB3DqA1bRGnQyfg,GG9zmPqulYDyJCtWwkE8,type,dmSj9bwK7C0E,LjG8y1rb9AgJF2I3i64ZDtCXMa7n
def dyxj7XG0U8gbzHfIS(url,source):
	CHxKynlBRN5pLzO8FfsQWJaG,GG9zmPqulYDyJCtWwkE8,obOAneMB9Xw4HKcaNEipqt,sQugfAKql9b6j,cKvEDbtVSWTP,jR4Ja5isMmrV8tDFu,KXhWVR3bvy8AIY9EnB4uHZUT = '','',None,None,None,None,None
	M08MPGgsh4n5rKe,PJzMroAYIdDf13eWOLi,vMSQsdJ0gCrh7ztnR96yDXqOYaj,PtK08YMFVxiB3DqA1bRGnQyfg,GG9zmPqulYDyJCtWwkE8,type,dmSj9bwK7C0E,LjG8y1rb9AgJF2I3i64ZDtCXMa7n = FQKPgc4DYUojyiX5bd(url,source)
	if '?named=' in url:
		if   type=='embed': type = ' '+'مفضل'
		elif type=='watch': type = ' '+'%مشاهدة'
		elif type=='both': type = ' '+'%%مشاهدة وتحميل'
		elif type=='download': type = ' '+'%%%تحميل'
		elif type=='': type = ' '+'%%%%'
		if dmSj9bwK7C0E!='':
			if 'mp4' not in dmSj9bwK7C0E: dmSj9bwK7C0E = '%'+dmSj9bwK7C0E
			dmSj9bwK7C0E = ' '+dmSj9bwK7C0E
		if LjG8y1rb9AgJF2I3i64ZDtCXMa7n!='':
			LjG8y1rb9AgJF2I3i64ZDtCXMa7n = '%%%%%%%%%'+LjG8y1rb9AgJF2I3i64ZDtCXMa7n
			LjG8y1rb9AgJF2I3i64ZDtCXMa7n = ' '+LjG8y1rb9AgJF2I3i64ZDtCXMa7n[-9:]
	if   'AKOAM'		in source: jR4Ja5isMmrV8tDFu	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'AKWAM'		in source: obOAneMB9Xw4HKcaNEipqt	= 'akwam'
	elif 'katkoute'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: obOAneMB9Xw4HKcaNEipqt	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'photos.app.g'	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: obOAneMB9Xw4HKcaNEipqt	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'arabseed'		in source: obOAneMB9Xw4HKcaNEipqt	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'alarab'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: obOAneMB9Xw4HKcaNEipqt	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'fasel'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: obOAneMB9Xw4HKcaNEipqt	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 't7meel'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: obOAneMB9Xw4HKcaNEipqt	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'movs4u'		in GG9zmPqulYDyJCtWwkE8:   obOAneMB9Xw4HKcaNEipqt	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'myegyvip'		in GG9zmPqulYDyJCtWwkE8:   obOAneMB9Xw4HKcaNEipqt	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'fajer'		in GG9zmPqulYDyJCtWwkE8:   obOAneMB9Xw4HKcaNEipqt	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'فجر'			in GG9zmPqulYDyJCtWwkE8:   obOAneMB9Xw4HKcaNEipqt	= 'fajer'
	elif 'فلسطين'		in GG9zmPqulYDyJCtWwkE8:   obOAneMB9Xw4HKcaNEipqt	= 'palestine'
	elif 'gdrive'		in M08MPGgsh4n5rKe:   obOAneMB9Xw4HKcaNEipqt	= 'google'
	elif 'mycima'		in GG9zmPqulYDyJCtWwkE8:   obOAneMB9Xw4HKcaNEipqt	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'wecima'		in GG9zmPqulYDyJCtWwkE8:   obOAneMB9Xw4HKcaNEipqt	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'cimanow'		in GG9zmPqulYDyJCtWwkE8:   obOAneMB9Xw4HKcaNEipqt	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'newcima'		in GG9zmPqulYDyJCtWwkE8:   obOAneMB9Xw4HKcaNEipqt	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'dailymotion'	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: obOAneMB9Xw4HKcaNEipqt	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'bokra'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: obOAneMB9Xw4HKcaNEipqt	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'tvfun'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: obOAneMB9Xw4HKcaNEipqt	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'tvksa'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: obOAneMB9Xw4HKcaNEipqt	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'anavidz'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: obOAneMB9Xw4HKcaNEipqt	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'shoofpro'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: obOAneMB9Xw4HKcaNEipqt	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'shahid4u'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: jR4Ja5isMmrV8tDFu	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'shahed4u'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: jR4Ja5isMmrV8tDFu	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'cima4u'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: jR4Ja5isMmrV8tDFu	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'egynow'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: jR4Ja5isMmrV8tDFu	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'halacima'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: jR4Ja5isMmrV8tDFu	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'cimaabdo'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: jR4Ja5isMmrV8tDFu	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'youtu'	 	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: obOAneMB9Xw4HKcaNEipqt	= 'youtube'
	elif 'y2u.be'	 	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: obOAneMB9Xw4HKcaNEipqt	= 'youtube'
	elif 'd.egybest.d'	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: obOAneMB9Xw4HKcaNEipqt	= 'egybestvip'
	elif 'egy.best'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: obOAneMB9Xw4HKcaNEipqt	= 'egybest1'
	elif 'egybest'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: obOAneMB9Xw4HKcaNEipqt	= 'egybest3'
	elif 'moshahda'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: obOAneMB9Xw4HKcaNEipqt	= 'moshahda'
	elif 'facultybooks'	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: obOAneMB9Xw4HKcaNEipqt	= 'facultybooks'
	elif 'inflam.cc'	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: obOAneMB9Xw4HKcaNEipqt	= 'inflam'
	elif 'buzzvrl'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: obOAneMB9Xw4HKcaNEipqt	= 'buzzvrl'
	elif 'arabloads'	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: sQugfAKql9b6j	= 'arabloads'
	elif 'archive'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: sQugfAKql9b6j	= 'archive'
	elif 'catch.is'	 	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: sQugfAKql9b6j	= 'catch'
	elif 'filerio'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: sQugfAKql9b6j	= 'filerio'
	elif 'vidbm'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: sQugfAKql9b6j	= 'vidbm'
	elif 'vidhd'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: jR4Ja5isMmrV8tDFu	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'myvid'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: jR4Ja5isMmrV8tDFu	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'myviid'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: jR4Ja5isMmrV8tDFu	= PtK08YMFVxiB3DqA1bRGnQyfg
	elif 'videobin'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: sQugfAKql9b6j	= 'videobin'
	elif 'govid'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: sQugfAKql9b6j	= 'govid'
	elif 'liivideo' 	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: sQugfAKql9b6j	= 'liivideo'
	elif 'mp4upload'	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: sQugfAKql9b6j	= 'mp4upload'
	elif 'publicvideo'	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: sQugfAKql9b6j	= 'publicvideo'
	elif 'rapidvideo' 	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: sQugfAKql9b6j	= 'rapidvideo'
	elif 'top4top'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: sQugfAKql9b6j	= 'top4top'
	elif 'upp' 			in vMSQsdJ0gCrh7ztnR96yDXqOYaj: sQugfAKql9b6j	= 'upbom'
	elif 'upb' 			in vMSQsdJ0gCrh7ztnR96yDXqOYaj: sQugfAKql9b6j	= 'upbom'
	elif 'uqload' 		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: sQugfAKql9b6j	= 'uqload'
	elif 'vcstream' 	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: sQugfAKql9b6j	= 'vcstream'
	elif 'vidbob'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: sQugfAKql9b6j	= 'vidbob'
	elif 'vidoza' 		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: sQugfAKql9b6j	= 'vidoza'
	elif 'watchvideo' 	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: sQugfAKql9b6j	= 'watchvideo'
	elif 'wintv.live'	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: sQugfAKql9b6j	= 'wintv.live'
	elif 'zippyshare'	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: sQugfAKql9b6j	= 'zippyshare'
	elif 'hd-cdn'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: sQugfAKql9b6j	= 'hd-cdn'
	if   obOAneMB9Xw4HKcaNEipqt:	CHxKynlBRN5pLzO8FfsQWJaG,GG9zmPqulYDyJCtWwkE8 = 'خاص',obOAneMB9Xw4HKcaNEipqt
	elif jR4Ja5isMmrV8tDFu:		CHxKynlBRN5pLzO8FfsQWJaG,GG9zmPqulYDyJCtWwkE8 = '%محدد',jR4Ja5isMmrV8tDFu
	elif sQugfAKql9b6j:		CHxKynlBRN5pLzO8FfsQWJaG,GG9zmPqulYDyJCtWwkE8 = '%%عام معروف',sQugfAKql9b6j
	elif cKvEDbtVSWTP:	CHxKynlBRN5pLzO8FfsQWJaG,GG9zmPqulYDyJCtWwkE8 = '%%%عام خارجي',cKvEDbtVSWTP
	elif KXhWVR3bvy8AIY9EnB4uHZUT:	CHxKynlBRN5pLzO8FfsQWJaG,GG9zmPqulYDyJCtWwkE8 = '%%%%عام خارجي',PtK08YMFVxiB3DqA1bRGnQyfg
	else:			CHxKynlBRN5pLzO8FfsQWJaG,GG9zmPqulYDyJCtWwkE8 = '%%%%%عام مجهول',PtK08YMFVxiB3DqA1bRGnQyfg
	return CHxKynlBRN5pLzO8FfsQWJaG,GG9zmPqulYDyJCtWwkE8,type,dmSj9bwK7C0E,LjG8y1rb9AgJF2I3i64ZDtCXMa7n
def oZVHzebFUQMspfv(url,source):
	M08MPGgsh4n5rKe,jR4Ja5isMmrV8tDFu,vMSQsdJ0gCrh7ztnR96yDXqOYaj,PtK08YMFVxiB3DqA1bRGnQyfg,GG9zmPqulYDyJCtWwkE8,type,dmSj9bwK7C0E,LjG8y1rb9AgJF2I3i64ZDtCXMa7n = FQKPgc4DYUojyiX5bd(url,source)
	if   'AKOAM'		in source: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = fxd9jQipFC(M08MPGgsh4n5rKe,GG9zmPqulYDyJCtWwkE8)
	elif 'AKWAM'		in source: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = JJjPSnbr9G(M08MPGgsh4n5rKe,type,LjG8y1rb9AgJF2I3i64ZDtCXMa7n)
	elif 'FASELHD1'		in source: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = wwu1o5empx(M08MPGgsh4n5rKe)
	elif 'CIMA4U'		in source: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = zq4LAwRVK1(M08MPGgsh4n5rKe)
	elif 'CIMACLUB'		in source: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = qF7TNgxJXU(M08MPGgsh4n5rKe)
	elif 'ARABSEED'		in source: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = AOiTe7sQSc(M08MPGgsh4n5rKe)
	elif 'CIMAABDO'		in source: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = fVoSDTZypM(M08MPGgsh4n5rKe)
	elif 'SHOFHA'		in source: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = v14AE0Bi5Z(M08MPGgsh4n5rKe)
	elif 'katkoute'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = PaGwrUkK2f(M08MPGgsh4n5rKe)
	elif 'akoam.cam'	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = PFo6yw8eGk(M08MPGgsh4n5rKe)
	elif 'alarab'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = VVWjAzLc1RfDxU2pZa3YN4dybknOJX(M08MPGgsh4n5rKe)
	elif 'shahid4u'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = UBlEgwVT6y(M08MPGgsh4n5rKe)
	elif 'shahed4u'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = UBlEgwVT6y(M08MPGgsh4n5rKe)
	elif 'egynow'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = xbY0T1dei7(M08MPGgsh4n5rKe)
	elif 'tvfun'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = q278pzF9eZ(M08MPGgsh4n5rKe)
	elif 'tvksa'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = q278pzF9eZ(M08MPGgsh4n5rKe)
	elif 'tv-f.com'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = q278pzF9eZ(M08MPGgsh4n5rKe)
	elif 'halacima'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = QQE3oVh6qc(M08MPGgsh4n5rKe)
	elif 'shoofpro'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = MMivyuf1F0(M08MPGgsh4n5rKe)
	elif 'myegyvip'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = P2XyuC6jH4(M08MPGgsh4n5rKe)
	elif 'vs4u'			in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = GuD5gHAba8(M08MPGgsh4n5rKe)
	elif 'fajer'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = IsuUz5pLN1(M08MPGgsh4n5rKe)
	elif 'cimanow'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = qqQlJH0SDK(M08MPGgsh4n5rKe)
	elif 'newcima'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = qqQlJH0SDK(M08MPGgsh4n5rKe)
	elif 'cima-light'	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = MQ3pKzOWqD(M08MPGgsh4n5rKe)
	elif 'cimalight'	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = MQ3pKzOWqD(M08MPGgsh4n5rKe)
	elif 'mycima'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = s0atThLKQ2(M08MPGgsh4n5rKe)
	elif 'wecima'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = CJ2q9lUhtG(M08MPGgsh4n5rKe)
	elif 'bokra'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = OOGxT27leJ(M08MPGgsh4n5rKe)
	elif 'dailymotion'	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = p4kPMX2AEO(M08MPGgsh4n5rKe)
	elif 'arblionz'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = nEhfOWmx8u(M08MPGgsh4n5rKe)
	elif 'd.egybest.d'	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = '',[''],[M08MPGgsh4n5rKe]
	elif 'egy.best'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = EyjK7UelOR(url)
	elif 'egybest'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = kD3ofOX7xb(M08MPGgsh4n5rKe)
	elif 'series4watch'	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = HHTr7ZpI8R(M08MPGgsh4n5rKe)
	elif 'upbam' 		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = '',[''],[M08MPGgsh4n5rKe]
	else: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = 'NEED_EXTERNAL_RESOLVERS',[''],[M08MPGgsh4n5rKe]
	return 'Failed:  '+d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
def CeGsjf6Dcd7O(url,source):
	vMSQsdJ0gCrh7ztnR96yDXqOYaj = SLMTm6RQ34ic7v5s9rBG(url,'name')
	jVMHRouKgQFAESmd7B8ObTYy = []
	if   'youtu'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = dULi8YwfV6(url)
	elif 'y2u.be'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = dULi8YwfV6(url)
	elif 'googleuserco' in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = b9mi7NxS3EXWhp4LjeY6zHI(url)
	elif 'photos.app.g'	in url   : d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = xXyKzc7LNsZmhGIlVPTFY02r93BvUf(url)
	elif 'dailymotion'	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = p4kPMX2AEO(url)
	elif 'moshahda'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = zgyD31GX9hbB5OJfWcQEmo(url)
	elif 'faselhd'		in url   : d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = wwu1o5empx(url)
	elif 'arabloads'	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = Dkn3dzZG0BygQbp1e485aFmKC(url)
	elif 'archive'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = m2aNQA3o8PlLe(url)
	elif 'buzzvrl'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = We4bI9coqBRCJQU(url)
	elif 'e5tsar'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = D6zRuTej9r(url)
	elif 'facultybooks'	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = nyCPh492JAetxzm7FZgvQBKL6RGN(url)
	elif 'inflam.cc'	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = nyCPh492JAetxzm7FZgvQBKL6RGN(url)
	elif 'upbam' 		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = '',[''],[url]
	elif 'liivideo' 	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = uI5t48amSd(url)
	elif 'mp4upload'	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = Ig6Ru8NTZvM9L(url)
	elif 'rapidvideo' 	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = qMLJlhSP4YZbKO5m6xjNW9(url)
	elif 'top4top'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = IgA3ZjPzoraTu6ldM0sOh(url)
	elif 'upb' 			in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = JrG4BmKHWNfncQ9zwhbEkZF27S5j(url)
	elif 'upp' 			in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = JrG4BmKHWNfncQ9zwhbEkZF27S5j(url)
	elif 'uqload' 		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = xgEMXw6Pci4tRLDvhyerQdj(url)
	elif 'vcstream' 	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = FmA95zrJoi1kfd7xnCW8c6RMgD2(url)
	elif 'vidbob'		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = JJSqngCYlXG2HwQiWRb(url)
	elif 'vidoza' 		in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = K5N6ch0HEBTCMSpg(url)
	elif 'watchvideo' 	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = a5WH2Xce0kpPo7yCB(url)
	elif 'wintv.live'	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = MUTZEmRLvldcOsr13AtJukwI(url)
	elif 'zippyshare'	in vMSQsdJ0gCrh7ztnR96yDXqOYaj: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = GhRAxgTWjeFosiMdpEmZ9JlavkIb5(url)
	if jVMHRouKgQFAESmd7B8ObTYy: return 'Failed: '+d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
	return 'Failed:  ',[],[]
def QQIkorc4qS(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',url,'','','',False,'RESOLVERS-URL_REDIRECT-1st')
	headers = aQniqUlZk8.headers
	if 'Location' in list(headers.keys()):
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = aQniqUlZk8.headers['Location']
		if SU82u7LfcMslH3e0Bzihn6x(ZCimQhV5lovgspAYzHq1Ef27u8ja4R): return '',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R]
	return 'Failed:  ',[],[]
def nRzgSD7watXEINBsPO2jh(url,source):
	d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = '',[],[]
	if SU82u7LfcMslH3e0Bzihn6x(url): d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = '',[''],[url]
	if not jVMHRouKgQFAESmd7B8ObTYy: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = QQIkorc4qS(url)
	if not jVMHRouKgQFAESmd7B8ObTYy: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = ffdWEztnYD20FImUXKGuJw(url)
	if not jVMHRouKgQFAESmd7B8ObTYy:
		if d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5=='EXIT_RESOLVER': d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5 = ''
		return 'Failed:  '+d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,[],[]
	return d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
def J9JxtVzao8Busgp1IyFCXcENd(RQxVzFYm12C):
	if 'list' in str(type(RQxVzFYm12C)):
		cc0O1M4e5jtfoq = []
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R in RQxVzFYm12C:
			if 'str' in str(type(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)):
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.replace('\r','').replace('\n','').strip(' ')
			cc0O1M4e5jtfoq.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	else: cc0O1M4e5jtfoq = RQxVzFYm12C.replace('\r','').replace('\n','').strip(' ')
	return cc0O1M4e5jtfoq
def EAWkUPBoYKLQd9zxM0b25GcswH6qg(FQLIlWJODoV26NSpzgjb3Yu,source):
	VWo9pg3saueIF8vNSkOUPyjcQh6 = xgFTDVS7lf5Us6aj
	data = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,'list','SERVERS',FQLIlWJODoV26NSpzgjb3Yu)
	if data:
		da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = list(zip(*data))
		return da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
	da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy,UUhseDv0Nba2Bc = [],[],[]
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R in FQLIlWJODoV26NSpzgjb3Yu:
		if '//' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: continue
		CHxKynlBRN5pLzO8FfsQWJaG,GG9zmPqulYDyJCtWwkE8,type,dmSj9bwK7C0E,LjG8y1rb9AgJF2I3i64ZDtCXMa7n = dyxj7XG0U8gbzHfIS(ZCimQhV5lovgspAYzHq1Ef27u8ja4R,source)
		LjG8y1rb9AgJF2I3i64ZDtCXMa7n = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('\d+',LjG8y1rb9AgJF2I3i64ZDtCXMa7n,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if LjG8y1rb9AgJF2I3i64ZDtCXMa7n: LjG8y1rb9AgJF2I3i64ZDtCXMa7n = int(LjG8y1rb9AgJF2I3i64ZDtCXMa7n[0])
		else: LjG8y1rb9AgJF2I3i64ZDtCXMa7n = 0
		vMSQsdJ0gCrh7ztnR96yDXqOYaj = SLMTm6RQ34ic7v5s9rBG(ZCimQhV5lovgspAYzHq1Ef27u8ja4R,'name')
		UUhseDv0Nba2Bc.append([CHxKynlBRN5pLzO8FfsQWJaG,GG9zmPqulYDyJCtWwkE8,type,dmSj9bwK7C0E,LjG8y1rb9AgJF2I3i64ZDtCXMa7n,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,vMSQsdJ0gCrh7ztnR96yDXqOYaj])
	if UUhseDv0Nba2Bc:
		XXoMnisPKdQZLHVtqjgR = sorted(UUhseDv0Nba2Bc,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		KqPIzwrCB47SU8Zvc = []
		for Fj1YUPiHsabvulW30mzZ in XXoMnisPKdQZLHVtqjgR:
			if Fj1YUPiHsabvulW30mzZ not in KqPIzwrCB47SU8Zvc:
				KqPIzwrCB47SU8Zvc.append(Fj1YUPiHsabvulW30mzZ)
		for CHxKynlBRN5pLzO8FfsQWJaG,GG9zmPqulYDyJCtWwkE8,type,dmSj9bwK7C0E,LjG8y1rb9AgJF2I3i64ZDtCXMa7n,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,vMSQsdJ0gCrh7ztnR96yDXqOYaj in KqPIzwrCB47SU8Zvc:
			if LjG8y1rb9AgJF2I3i64ZDtCXMa7n: LjG8y1rb9AgJF2I3i64ZDtCXMa7n = str(LjG8y1rb9AgJF2I3i64ZDtCXMa7n)
			else: LjG8y1rb9AgJF2I3i64ZDtCXMa7n = ''
			title = 'سيرفر'+' '+type+' '+CHxKynlBRN5pLzO8FfsQWJaG+' '+LjG8y1rb9AgJF2I3i64ZDtCXMa7n+' '+dmSj9bwK7C0E+' '+GG9zmPqulYDyJCtWwkE8
			if vMSQsdJ0gCrh7ztnR96yDXqOYaj not in title: title = title+' '+vMSQsdJ0gCrh7ztnR96yDXqOYaj
			title = title.replace('%','').strip(' ').replace('  ',' ').replace('  ',' ').replace('  ',' ')
			if ZCimQhV5lovgspAYzHq1Ef27u8ja4R not in jVMHRouKgQFAESmd7B8ObTYy:
				da6IAnqQ7oV2Hx13F5gbBT4.append(title)
				jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
		if jVMHRouKgQFAESmd7B8ObTYy:
			data = list(zip(da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy))
			if data: kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,'SERVERS',FQLIlWJODoV26NSpzgjb3Yu,data,VWo9pg3saueIF8vNSkOUPyjcQh6)
	return da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
def fF9Z1CashvTgQPHMe7qUwY3EBp(url,source):
	jbDMGZeVf2RyJ8OxFA94Emu3pgo0St = ''
	s4Bng5iAZQSTtpDw9 = False
	try:
		import resolveurl as mChVfU3ucGavqryB8ROStLQJ56XF
		s4Bng5iAZQSTtpDw9 = mChVfU3ucGavqryB8ROStLQJ56XF.resolve(url)
	except Exception as ojBl6y0E82Kkx5AdCh1T9DL: jbDMGZeVf2RyJ8OxFA94Emu3pgo0St = str(ojBl6y0E82Kkx5AdCh1T9DL)
	if not s4Bng5iAZQSTtpDw9:
		if jbDMGZeVf2RyJ8OxFA94Emu3pgo0St=='':
			jbDMGZeVf2RyJ8OxFA94Emu3pgo0St = oo5q9yuEdbCeOSxfzJcw.format_exc()
			if jbDMGZeVf2RyJ8OxFA94Emu3pgo0St!='NoneType: None\n': EAPND6zHKrMRuBc91tInYohsl0ywa.stderr.write(jbDMGZeVf2RyJ8OxFA94Emu3pgo0St)
		d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5 = jbDMGZeVf2RyJ8OxFA94Emu3pgo0St.splitlines()[-1]
		return 'Failed:  '+d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,[],[]
	return '',[''],[s4Bng5iAZQSTtpDw9]
def YF21xgwAIDGQReZ5OPntfEqC67z(url,source):
	jbDMGZeVf2RyJ8OxFA94Emu3pgo0St = ''
	s4Bng5iAZQSTtpDw9 = False
	try:
		import yt_dlp as o3ozB16GhTSUpsHukfX9QIngVmRi0
		jeyzNsCq64x3Q7rHwYM0 = o3ozB16GhTSUpsHukfX9QIngVmRi0.YoutubeDL({'no_color': True})
		s4Bng5iAZQSTtpDw9 = jeyzNsCq64x3Q7rHwYM0.extract_info(url,download=False)
	except Exception as ojBl6y0E82Kkx5AdCh1T9DL: jbDMGZeVf2RyJ8OxFA94Emu3pgo0St = str(ojBl6y0E82Kkx5AdCh1T9DL)
	if not s4Bng5iAZQSTtpDw9 or 'formats' not in list(s4Bng5iAZQSTtpDw9.keys()):
		if jbDMGZeVf2RyJ8OxFA94Emu3pgo0St=='':
			jbDMGZeVf2RyJ8OxFA94Emu3pgo0St = oo5q9yuEdbCeOSxfzJcw.format_exc()
			if jbDMGZeVf2RyJ8OxFA94Emu3pgo0St!='NoneType: None\n': EAPND6zHKrMRuBc91tInYohsl0ywa.stderr.write(jbDMGZeVf2RyJ8OxFA94Emu3pgo0St)
		d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5 = jbDMGZeVf2RyJ8OxFA94Emu3pgo0St.splitlines()[-1]
		return 'Failed:  '+d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,[],[]
	else:
		da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = [],[]
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R in s4Bng5iAZQSTtpDw9['formats']:
			da6IAnqQ7oV2Hx13F5gbBT4.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R['format'])
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R['url'])
		return '',da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
def VVWjAzLc1RfDxU2pZa3YN4dybknOJX(url):
	if '.m3u8' in url:
		da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = nPVJZWtkEb27UQ9AK(url)
		if jVMHRouKgQFAESmd7B8ObTYy: return '',da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
		return 'Error: Resolver Failed M3U8',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def PaGwrUkK2f(url):
	zcBjFq4VQlp20ZekGO,DSkd2Y0zhRKLG = [],[]
	if '/videos.mp4?vid=' in url:
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','',False,'','RESOLVERS-KATKOUTE-1st')
		if 'Location' in aQniqUlZk8.headers:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = aQniqUlZk8.headers['Location']
			zcBjFq4VQlp20ZekGO.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			vMSQsdJ0gCrh7ztnR96yDXqOYaj = SLMTm6RQ34ic7v5s9rBG(ZCimQhV5lovgspAYzHq1Ef27u8ja4R,'name')
			DSkd2Y0zhRKLG.append(vMSQsdJ0gCrh7ztnR96yDXqOYaj)
	elif 'katkoute.com' in url:
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','RESOLVERS-KATKOUTE-2nd')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		HJ1sEm6TVP = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(eval\(function\(p,a,c,k,e,d\).*?\)\)).</script>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if HJ1sEm6TVP:
			HJ1sEm6TVP = HJ1sEm6TVP[0]
			OTdKGIE4Ms6hJjkFwoXyfrU = lboxWJEBsiKdO1FTz(HJ1sEm6TVP)
			uNKYQwvJB79esVxfSTClWg = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('sources:(\[.*?\]),',OTdKGIE4Ms6hJjkFwoXyfrU,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if uNKYQwvJB79esVxfSTClWg:
				uNKYQwvJB79esVxfSTClWg = uNKYQwvJB79esVxfSTClWg[0]
				uNKYQwvJB79esVxfSTClWg = GVQAnvYCT3dS('list',uNKYQwvJB79esVxfSTClWg)
				for dict in uNKYQwvJB79esVxfSTClWg:
					ZCimQhV5lovgspAYzHq1Ef27u8ja4R = dict['file']
					LjG8y1rb9AgJF2I3i64ZDtCXMa7n = dict['label']
					zcBjFq4VQlp20ZekGO.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
					vMSQsdJ0gCrh7ztnR96yDXqOYaj = SLMTm6RQ34ic7v5s9rBG(ZCimQhV5lovgspAYzHq1Ef27u8ja4R,'name')
					DSkd2Y0zhRKLG.append(LjG8y1rb9AgJF2I3i64ZDtCXMa7n+' '+vMSQsdJ0gCrh7ztnR96yDXqOYaj)
		elif 'Location' in aQniqUlZk8.headers:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = aQniqUlZk8.headers['Location']
			zcBjFq4VQlp20ZekGO.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			vMSQsdJ0gCrh7ztnR96yDXqOYaj = SLMTm6RQ34ic7v5s9rBG(ZCimQhV5lovgspAYzHq1Ef27u8ja4R,'name')
			DSkd2Y0zhRKLG.append(vMSQsdJ0gCrh7ztnR96yDXqOYaj)
		if '?url=https://photos.app.goo' in url:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = url.split('?url=')[1]
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('&')[0]
			if ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
				zcBjFq4VQlp20ZekGO.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
				DSkd2Y0zhRKLG.append('photos google')
	else:
		zcBjFq4VQlp20ZekGO.append(url)
		vMSQsdJ0gCrh7ztnR96yDXqOYaj = SLMTm6RQ34ic7v5s9rBG(url,'name')
		DSkd2Y0zhRKLG.append(vMSQsdJ0gCrh7ztnR96yDXqOYaj)
	if not zcBjFq4VQlp20ZekGO: return 'Error: Resolver Failed KATKOUTE',[],[]
	elif len(zcBjFq4VQlp20ZekGO)==1: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = zcBjFq4VQlp20ZekGO[0]
	else:
		NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql('أختر الملف المناسب',DSkd2Y0zhRKLG)
		if NljOosKT8WJBpch==-1: return 'EXIT_RESOLVER',[],[]
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = zcBjFq4VQlp20ZekGO[NljOosKT8WJBpch]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R]
def b9mi7NxS3EXWhp4LjeY6zHI(url):
	headers = {'User-Agent':'Kodi/'+str(wH3qxmuXBTeak)}
	for Deiz7ocWQjVnIg in range(50):
		w6vebiEZtpCjJcILP8Skx5rHn.sleep(0.100)
		aQniqUlZk8 = wxZf9B2mrgOaqpK83FQIy65W('GET',url,'',headers,False,'','RESOLVERS-GOOGLEUSERCONTENT-1st')
		if 'Location' in list(aQniqUlZk8.headers.keys()):
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = aQniqUlZk8.headers['Location']
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'|User-Agent='+headers['User-Agent']
			return '',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R]
		if aQniqUlZk8.code!=429: break
	return 'Error: Resolver Failed GOOGLEUSERCONTENT',[],[]
def xXyKzc7LNsZmhGIlVPTFY02r93BvUf(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','RESOLVERS-PHOTOSGOOGLE-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"(https://video-downloads.*?)",.*?,.*?,(.*?),',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R,LjG8y1rb9AgJF2I3i64ZDtCXMa7n = ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]
		return '',[LjG8y1rb9AgJF2I3i64ZDtCXMa7n],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R]
	return 'Error: Resolver Failed PHOTOSGOOGLE',[],[]
def wwu1o5empx(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',url,'','','','','RESOLVERS-FASELHD1-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = K9hUtLagkSbDiwM1(M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2)
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"file":"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if ZCimQhV5lovgspAYzHq1Ef27u8ja4R: return '',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]]
	return 'Error: Resolver Failed FASELHD1',[],[]
def v14AE0Bi5Z(url):
	if '/down.php' in url:
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',url,'','','','','RESOLVERS-SHOFHA-1st')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('video-wrapper.*?href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		url = ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def zq4LAwRVK1(url):
	if 'server.php' in url:
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',url,'','','','','RESOLVERS-CIMA4U-1st')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]
		if 'http' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: return 'NEED_EXTERNAL_RESOLVERS',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R]
		return 'Error: Resolver Failed CIMA4U',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def xbY0T1dei7(url):
	M08MPGgsh4n5rKe,bhfgckoLVtsA2DXv = NHyOSR4BdqaXfCpK0EU8vroiDJ2T(url)
	TC7fWv2a1gLJGiAtN8 = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'POST',M08MPGgsh4n5rKe,bhfgckoLVtsA2DXv,TC7fWv2a1gLJGiAtN8,'','','RESOLVERS-EGYNOW-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not ZCimQhV5lovgspAYzHq1Ef27u8ja4R: return 'Error: Resolver Failed EGYNOW',[],[]
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R]
def MMivyuf1F0(url):
	headers = {'X-Requested-With':'XMLHttpRequest'}
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'',headers,'','','RESOLVERS-SHOOFPRO-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.IGNORECASE)
	if not ZCimQhV5lovgspAYzHq1Ef27u8ja4R: return 'Error: Resolver Failed SHOOFPRO',[],[]
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R]
def QQE3oVh6qc(url):
	M08MPGgsh4n5rKe,bhfgckoLVtsA2DXv = NHyOSR4BdqaXfCpK0EU8vroiDJ2T(url)
	TC7fWv2a1gLJGiAtN8 = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'POST',M08MPGgsh4n5rKe,bhfgckoLVtsA2DXv,TC7fWv2a1gLJGiAtN8,'','','RESOLVERS-HALACIMA-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('''<iframe src=["'](.*?)["']''',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.IGNORECASE)
	if not ZCimQhV5lovgspAYzHq1Ef27u8ja4R: return 'Error: Resolver Failed HALACIMA',[],[]
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]
	if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = 'http:'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R]
def fVoSDTZypM(url):
	M08MPGgsh4n5rKe,bhfgckoLVtsA2DXv = NHyOSR4BdqaXfCpK0EU8vroiDJ2T(url)
	TC7fWv2a1gLJGiAtN8 = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'POST',M08MPGgsh4n5rKe,bhfgckoLVtsA2DXv,TC7fWv2a1gLJGiAtN8,'','','RESOLVERS-CIMAABDO-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('''<iframe src=["'](.*?)["']''',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.IGNORECASE)
	if ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]
	else: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = url
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R]
def q278pzF9eZ(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','RESOLVERS-TVFUN-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	BnGromdt41zgSwhaE3eNFH5ckq79 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("var fserv =.*?'(.*?)'",M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.IGNORECASE)
	if BnGromdt41zgSwhaE3eNFH5ckq79:
		BnGromdt41zgSwhaE3eNFH5ckq79 = BnGromdt41zgSwhaE3eNFH5ckq79[0][2:]
		BnGromdt41zgSwhaE3eNFH5ckq79 = SSNcdhMguvEw0RY.b64decode(BnGromdt41zgSwhaE3eNFH5ckq79)
		if wvkR1es6d0SrjxKt5FZTMUWz7a: BnGromdt41zgSwhaE3eNFH5ckq79 = BnGromdt41zgSwhaE3eNFH5ckq79.decode('utf8')
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('src="(.*?)"',BnGromdt41zgSwhaE3eNFH5ckq79,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	else: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ''
	if not ZCimQhV5lovgspAYzHq1Ef27u8ja4R: return 'Error: Resolver Failed TVFUN',[],[]
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]
	if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = 'http:'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R]
def P2XyuC6jH4(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',url,'','','','','RESOLVERS-MYEGYVIP-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="col-sm-12".*?href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not ZCimQhV5lovgspAYzHq1Ef27u8ja4R: return 'Error: Resolver Failed MYEGYVIP',[],[]
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R]
def p4kPMX2AEO(url):
	id = url.split('/')[-1]
	if '/embed' in url: url = url.replace('/embed','')
	url = url.replace('.com/','.com/player/metadata/')
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',url,'','','','','RESOLVERS-DAILYMOTION-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5 = 'Error: Resolver Failed DAILYMOTION'
	ojBl6y0E82Kkx5AdCh1T9DL = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"error".*?"messagee":"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if ojBl6y0E82Kkx5AdCh1T9DL: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5 = ojBl6y0E82Kkx5AdCh1T9DL[0]
	url = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('x-mpegURL","url":"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not url and d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5:
		return d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,[],[]
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = url[0].replace('\\','')
	ddvlQgiwbjWhyN9Rp6DAYtC,FQLIlWJODoV26NSpzgjb3Yu = nPVJZWtkEb27UQ9AK(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	qAdI4N6keMiRcjVQEHbrv0hlgGJ = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"owner":{"id":"(.*?)","screenname":"(.*?)","url":"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if qAdI4N6keMiRcjVQEHbrv0hlgGJ: vye9ZcD8xfaXQoAHdibsKt,TOFR3imN6oEGdAH4sQhez27pqrg,IWhoYZNE6QRngj = qAdI4N6keMiRcjVQEHbrv0hlgGJ[0]
	else: vye9ZcD8xfaXQoAHdibsKt,TOFR3imN6oEGdAH4sQhez27pqrg,IWhoYZNE6QRngj = '','',''
	IWhoYZNE6QRngj = IWhoYZNE6QRngj.replace('\/','/')
	TOFR3imN6oEGdAH4sQhez27pqrg = zKGXT5sJeRq(TOFR3imN6oEGdAH4sQhez27pqrg)
	da6IAnqQ7oV2Hx13F5gbBT4 = ['[COLOR FFC89008]OWNER:  '+TOFR3imN6oEGdAH4sQhez27pqrg+'[/COLOR]']+ddvlQgiwbjWhyN9Rp6DAYtC
	jVMHRouKgQFAESmd7B8ObTYy = [IWhoYZNE6QRngj]+FQLIlWJODoV26NSpzgjb3Yu
	NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql('اختر الملف المناسب: ('+str(len(jVMHRouKgQFAESmd7B8ObTYy)-1)+' ملف)',da6IAnqQ7oV2Hx13F5gbBT4)
	if NljOosKT8WJBpch==-1: return 'EXIT_RESOLVER',[],[]
	elif NljOosKT8WJBpch==0:
		Pukd6EFcXBNfYW = EAPND6zHKrMRuBc91tInYohsl0ywa.argv[0]+'?type=folder&mode=402&url='+IWhoYZNE6QRngj+'&textt='+TOFR3imN6oEGdAH4sQhez27pqrg
		oos8ymFi9CN2z1jXcR.executebuiltin("Container.Update("+Pukd6EFcXBNfYW+")")
		return 'EXIT_RESOLVER',[],[]
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R =  jVMHRouKgQFAESmd7B8ObTYy[NljOosKT8WJBpch]
	return '',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R]
def OOGxT27leJ(ZCimQhV5lovgspAYzHq1Ef27u8ja4R):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',ZCimQhV5lovgspAYzHq1Ef27u8ja4R,'','','','','RESOLVERS-BOKRA-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	if '.json' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: url = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"src":"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	else: url = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('source src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not url: return 'Error: Resolver Failed BOKRA',[],[]
	url = url[0]
	if 'http' not in url: url = 'http:'+url
	return '',[''],[url]
def zgyD31GX9hbB5OJfWcQEmo(url):
	headers = { 'User-Agent' : '' }
	if 'op=download_orig' in url:
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(jEPuRTVbZg4MCimJxzf3I6wFa,url,'',headers,'','RESOLVERS-MOSHAHDA-1st')
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('direct link.*?href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if items: return '',[''],[items[0]]
		else:
			maCNIYkc0HOiEGpL3g = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="err">(.*?)<',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if maCNIYkc0HOiEGpL3g:
				tehb3k5a2PufGOdBIUw8j('','','رسالة من الموقع الاصلي',maCNIYkc0HOiEGpL3g[0])
				return 'Error: '+maCNIYkc0HOiEGpL3g[0],[],[]
	else:
		SSJLGwYsC5qz3bnku9IpyfX = 'movizland'
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(jEPuRTVbZg4MCimJxzf3I6wFa,url,'',headers,'','RESOLVERS-MOSHAHDA-2nd')
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('Form method="POST" action=\'(.*?)\'(.*?)div',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if not TIkiozSLCv6werb97mHQ0q4y3: return 'Error: Resolver Failed MOSHAHDA',[],[]
		VktWBN6gn8zSUpesvfCyia2Ajm = TIkiozSLCv6werb97mHQ0q4y3[0][0]
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0][1]
		if '.rar' in ziJLDVT8NM2QcgIpmE9A or '.zip' in ziJLDVT8NM2QcgIpmE9A: return 'Error: MOSHAHDA Not a video file',[],[]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('name="(.*?)".*?value="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		VVNkoRCUm96MbtuqgrOe = {}
		for GG9zmPqulYDyJCtWwkE8,hht0cpXxWw2OzFS1jnUGebkJLBd85 in items:
			VVNkoRCUm96MbtuqgrOe[GG9zmPqulYDyJCtWwkE8] = hht0cpXxWw2OzFS1jnUGebkJLBd85
		data = cswW2KC5FOH64vq97ZkNR(VVNkoRCUm96MbtuqgrOe)
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(jEPuRTVbZg4MCimJxzf3I6wFa,VktWBN6gn8zSUpesvfCyia2Ajm,data,headers,'','RESOLVERS-MOSHAHDA-3rd')
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('Download Video.*?get\(\'(.*?)\'.*?sources:(.*?)image:',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if not TIkiozSLCv6werb97mHQ0q4y3: return 'Error: Resolver Failed MOSHAHDA',[],[]
		download = TIkiozSLCv6werb97mHQ0q4y3[0][0]
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0][1]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('file:"(.*?)"(,label:".*?"|)',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		IkZgaJ0Nxep5T,da6IAnqQ7oV2Hx13F5gbBT4,Si5NesyOAp,jVMHRouKgQFAESmd7B8ObTYy,QxwqL2kMjzGam = [],[],[],[],[]
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			if '.m3u8' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
				IkZgaJ0Nxep5T,Si5NesyOAp = nPVJZWtkEb27UQ9AK(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
				jVMHRouKgQFAESmd7B8ObTYy = jVMHRouKgQFAESmd7B8ObTYy + Si5NesyOAp
				if IkZgaJ0Nxep5T[0]=='-1': da6IAnqQ7oV2Hx13F5gbBT4.append(' سيرفر خاص '+'m3u8 '+SSJLGwYsC5qz3bnku9IpyfX)
				else:
					for title in IkZgaJ0Nxep5T:
						da6IAnqQ7oV2Hx13F5gbBT4.append(' سيرفر خاص '+'m3u8 '+SSJLGwYsC5qz3bnku9IpyfX+' '+title)
			else:
				title = title.replace(',label:"','')
				title = title.strip('"')
				title = ' سيرفر  خاص '+' mp4 '+SSJLGwYsC5qz3bnku9IpyfX+' '+title
				da6IAnqQ7oV2Hx13F5gbBT4.append(title)
				jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = 'http://moshahda.online' + download
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(jEPuRTVbZg4MCimJxzf3I6wFa,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,'',headers,'','RESOLVERS-MOSHAHDA-5th')
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("download_video\('(.*?)','(.*?)','(.*?)'.*?<td>(.*?),",M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for id,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,hash,gy7DjoZdVElL in items:
			title = ' سيرفر تحميل خاص '+' mp4 '+SSJLGwYsC5qz3bnku9IpyfX+' '+gy7DjoZdVElL.split('x')[1]
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = 'http://moshahda.online/dl?op=download_orig&id='+id+'&mode='+n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw+'&hash='+hash
			QxwqL2kMjzGam.append(gy7DjoZdVElL)
			da6IAnqQ7oV2Hx13F5gbBT4.append(title)
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
		QxwqL2kMjzGam = set(QxwqL2kMjzGam)
		Php2JkMBGaO9I57CWYwriS8dyF4Qt,OpcYd1RyJ9VaCo = [],[]
		for title in da6IAnqQ7oV2Hx13F5gbBT4:
			pghcM6meB0SWbXHYtQ = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(" (\d*x|\d*)&&",title+'&&',E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for gy7DjoZdVElL in QxwqL2kMjzGam:
				if pghcM6meB0SWbXHYtQ[0] in gy7DjoZdVElL:
					title = title.replace(pghcM6meB0SWbXHYtQ[0],gy7DjoZdVElL.split('x')[1])
			Php2JkMBGaO9I57CWYwriS8dyF4Qt.append(title)
		for AudBQkLFsrHKicIogThZyv in range(len(jVMHRouKgQFAESmd7B8ObTYy)):
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("&&(.*?)(\d*)&&",'&&'+Php2JkMBGaO9I57CWYwriS8dyF4Qt[AudBQkLFsrHKicIogThZyv]+'&&',E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			OpcYd1RyJ9VaCo.append( [Php2JkMBGaO9I57CWYwriS8dyF4Qt[AudBQkLFsrHKicIogThZyv],jVMHRouKgQFAESmd7B8ObTYy[AudBQkLFsrHKicIogThZyv],items[0][0],items[0][1]] )
		OpcYd1RyJ9VaCo = sorted(OpcYd1RyJ9VaCo, key=lambda xSNvyd0iTLFe5BVs: xSNvyd0iTLFe5BVs[3], reverse=True)
		OpcYd1RyJ9VaCo = sorted(OpcYd1RyJ9VaCo, key=lambda xSNvyd0iTLFe5BVs: xSNvyd0iTLFe5BVs[2], reverse=False)
		da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = [],[]
		for AudBQkLFsrHKicIogThZyv in range(len(OpcYd1RyJ9VaCo)):
			da6IAnqQ7oV2Hx13F5gbBT4.append(OpcYd1RyJ9VaCo[AudBQkLFsrHKicIogThZyv][0])
			jVMHRouKgQFAESmd7B8ObTYy.append(OpcYd1RyJ9VaCo[AudBQkLFsrHKicIogThZyv][1])
	if len(jVMHRouKgQFAESmd7B8ObTYy)==0: return 'Error: Resolver Failed MOSHAHDA',[],[]
	return '',da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
def D6zRuTej9r(url):
	oBzGqDUAi7KaL8vFdZtP9XIcf = url.split('?')
	M08MPGgsh4n5rKe = oBzGqDUAi7KaL8vFdZtP9XIcf[0]
	headers = { 'User-Agent' : '' }
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(jEPuRTVbZg4MCimJxzf3I6wFa,M08MPGgsh4n5rKe,'',headers,'','RESOLVERS-E5TSAR-1st')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('Please wait.*?href=\'(.*?)\'',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	url = items[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def We4bI9coqBRCJQU(url):
	da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = [],[]
	headers = { 'User-Agent' : '' }
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,url,'',headers,'','RESOLVERS-FACULTYBOOKS-1st')
	M08MPGgsh4n5rKe = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('redirect_url.*?href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if M08MPGgsh4n5rKe: return '',[''],[M08MPGgsh4n5rKe[0]]
	else: return 'Error: Resolver Failed BUZZVRL',[],[]
def nyCPh492JAetxzm7FZgvQBKL6RGN(url):
	da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = [],[]
	headers = { 'User-Agent' : '' }
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,url,'',headers,'','RESOLVERS-FACULTYBOOKS-1st')
	M08MPGgsh4n5rKe = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href","(htt.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if M08MPGgsh4n5rKe: return '',[''],[M08MPGgsh4n5rKe[0]]
	else: return 'Error: Resolver Failed FACULTYBOOKS',[],[]
def IsuUz5pLN1(url):
	da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy,errno = [],[],''
	if '/wp-admin/' in url:
		M08MPGgsh4n5rKe,bhfgckoLVtsA2DXv = NHyOSR4BdqaXfCpK0EU8vroiDJ2T(url)
		TC7fWv2a1gLJGiAtN8 = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'POST',M08MPGgsh4n5rKe,bhfgckoLVtsA2DXv,TC7fWv2a1gLJGiAtN8,'','','RESOLVERS-FAJERSHOW-2nd')
		flARjI3NM9CQnWY1xk7 = aQniqUlZk8.content
		if flARjI3NM9CQnWY1xk7.startswith('http'): M08MPGgsh4n5rKe = flARjI3NM9CQnWY1xk7
		else:
			TW6JIBgC971tjOE = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('''src=['"](.*?)['"]''',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if TW6JIBgC971tjOE:
				M08MPGgsh4n5rKe = TW6JIBgC971tjOE[0]
				TW6JIBgC971tjOE = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('source=(.*?)[&$]',M08MPGgsh4n5rKe,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
				if TW6JIBgC971tjOE:
					M08MPGgsh4n5rKe = BUTSkzgFC7(TW6JIBgC971tjOE[0])
					return '',[''],[M08MPGgsh4n5rKe]
	elif '/links/' in url:
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',url,'','',True,'','RESOLVERS-FAJERSHOW-1st')
		flARjI3NM9CQnWY1xk7 = aQniqUlZk8.content
		if 'Location' in list(aQniqUlZk8.headers.keys()): M08MPGgsh4n5rKe = aQniqUlZk8.headers['Location']
		else: M08MPGgsh4n5rKe = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('id="link".*?href="(.*?)"',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)[0]
	if '/v/' in M08MPGgsh4n5rKe or '/f/' in M08MPGgsh4n5rKe:
		M08MPGgsh4n5rKe = M08MPGgsh4n5rKe.replace('/f/','/api/source/')
		M08MPGgsh4n5rKe = M08MPGgsh4n5rKe.replace('/v/','/api/source/')
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'POST',M08MPGgsh4n5rKe,'','','','','RESOLVERS-FAJERSHOW-3rd')
		flARjI3NM9CQnWY1xk7 = aQniqUlZk8.content
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"file":"(.*?)","label":"(.*?)"',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if items:
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.replace('\\','')
				da6IAnqQ7oV2Hx13F5gbBT4.append(title)
				jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
		else:
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"file":"(.*?)"',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if items:
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = items[0]
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.replace('\\','')
				da6IAnqQ7oV2Hx13F5gbBT4.append('')
				jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	else: return 'NEED_EXTERNAL_RESOLVERS',[''],[M08MPGgsh4n5rKe]
	if len(jVMHRouKgQFAESmd7B8ObTYy)==0: return 'Error: Resolver Failed FAJERSHOW',[],[]
	return '',da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
def GuD5gHAba8(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',url,'','','','','RESOLVERS-MOVS4U-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy,errno = [],[],''
	if 'player_embed.php' in url or '/embed/' in url:
		if 'player_embed.php' in url:
			M08MPGgsh4n5rKe = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			M08MPGgsh4n5rKe = M08MPGgsh4n5rKe[0]
		else: M08MPGgsh4n5rKe = url
		if 'movs4u' not in M08MPGgsh4n5rKe: return 'NEED_EXTERNAL_RESOLVERS',[''],[M08MPGgsh4n5rKe]
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',M08MPGgsh4n5rKe,'','','','','RESOLVERS-MOVS4U-2nd')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('id="player"(.*?)videojs',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<source src="(.*?)".*?label="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if items:
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,JNuHrgRwE8K0hcdMBtQl in items:
				da6IAnqQ7oV2Hx13F5gbBT4.append(JNuHrgRwE8K0hcdMBtQl)
				jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	elif 'main_player.php' in url:
		M08MPGgsh4n5rKe = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('url=(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		M08MPGgsh4n5rKe = M08MPGgsh4n5rKe[0]
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',M08MPGgsh4n5rKe,'','','','','RESOLVERS-MOVS4U-3rd')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		TW6JIBgC971tjOE = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"file": "(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		TW6JIBgC971tjOE = TW6JIBgC971tjOE[0]
		da6IAnqQ7oV2Hx13F5gbBT4.append('')
		jVMHRouKgQFAESmd7B8ObTYy.append(TW6JIBgC971tjOE)
	elif 'download_link' in url:
		M08MPGgsh4n5rKe = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<center><a href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if M08MPGgsh4n5rKe:
			M08MPGgsh4n5rKe = M08MPGgsh4n5rKe[0]
			return 'NEED_EXTERNAL_RESOLVERS',[''],[M08MPGgsh4n5rKe]
	if len(jVMHRouKgQFAESmd7B8ObTYy)==0: return 'Error: Resolver Failed MOVS4U',[],[]
	return '',da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
def qF7TNgxJXU(url):
	website = mR20sONyKIlV['CIMACLUB'][0]
	headers = {'Referer':website}
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,'GET',url,'',headers,'','','RESOLVERS-CIMACLUB-2nd')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	vMSQsdJ0gCrh7ztnR96yDXqOYaj = SLMTm6RQ34ic7v5s9rBG(url,'url')
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('download=.*?href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("sources: \['(.*?)'",M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("file:'(.*?)'",M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]+'|Referer='+website
		return '',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R]
	if 'name="Xtoken"' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2:
		vmpAyPF1o89KgqG = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('name="Xtoken" content="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if vmpAyPF1o89KgqG:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = vmpAyPF1o89KgqG[0]
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = SSNcdhMguvEw0RY.b64decode(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			if wvkR1es6d0SrjxKt5FZTMUWz7a: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.decode('utf8','ignore')
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('http.*?(http.*?),',ZCimQhV5lovgspAYzHq1Ef27u8ja4R,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]+'|Referer='+website
				return '',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def EyjK7UelOR(url):
	DSkd2Y0zhRKLG,zcBjFq4VQlp20ZekGO = [],[]
	if '/1/' in url:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = url.replace('/1/','/4/')
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,'GET',ZCimQhV5lovgspAYzHq1Ef27u8ja4R,'','',False,'','RESOLVERS-EGYBEST1-1st')
		flARjI3NM9CQnWY1xk7 = aQniqUlZk8.content
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<video(.*?)</video>',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3:
			ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('src="(.*?)".*?size="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,LjG8y1rb9AgJF2I3i64ZDtCXMa7n in items:
				if ZCimQhV5lovgspAYzHq1Ef27u8ja4R not in zcBjFq4VQlp20ZekGO:
					zcBjFq4VQlp20ZekGO.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
					vMSQsdJ0gCrh7ztnR96yDXqOYaj = SLMTm6RQ34ic7v5s9rBG(ZCimQhV5lovgspAYzHq1Ef27u8ja4R,'name')
					DSkd2Y0zhRKLG.append(vMSQsdJ0gCrh7ztnR96yDXqOYaj+'  '+LjG8y1rb9AgJF2I3i64ZDtCXMa7n)
			return '',DSkd2Y0zhRKLG,zcBjFq4VQlp20ZekGO
	elif '/d/' in url:
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,'GET',url,'','','','','RESOLVERS-EGYBEST1-2nd')
		flARjI3NM9CQnWY1xk7 = aQniqUlZk8.content
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<iframe.*?src="(.*?)"',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0].replace('/1/','/4/')
			aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,'GET',ZCimQhV5lovgspAYzHq1Ef27u8ja4R,'','',False,'','RESOLVERS-EGYBEST1-3rd')
			flARjI3NM9CQnWY1xk7 = aQniqUlZk8.content
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class.*?href="(.*?)"',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if ZCimQhV5lovgspAYzHq1Ef27u8ja4R: return 'NEED_EXTERNAL_RESOLVERS',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]]
	return 'Error: Resolver Failed EGYBEST1',[],[]
def kD3ofOX7xb(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,'GET',url,'','','','','RESOLVERS-EGYBEST3-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	data = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"action".*?value="(.*?)".*?value="(.*?)".*?value="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if data:
		LLWmCoZjcAh56UuyISBaR4J,id,eA6TzM1R9qxsnFBGjcaW3mbpkZS5L7 = data[0]
		data = 'op='+LLWmCoZjcAh56UuyISBaR4J+'&id='+id+'&fname='+eA6TzM1R9qxsnFBGjcaW3mbpkZS5L7
		headers = {'Content-Type':'application/x-www-form-urlencoded'}
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,'POST',url,data,headers,'','','RESOLVERS-EGYBEST3-2nd')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"referer" value="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if ZCimQhV5lovgspAYzHq1Ef27u8ja4R: return 'NEED_EXTERNAL_RESOLVERS',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]]
	return 'Error: Resolver Failed EGYBEST1',[],[]
def M0Iwvgie2s(url):
	M08MPGgsh4n5rKe = url.split('?named=',1)[0].strip('?').strip('/').strip('&')
	da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy,items,TW6JIBgC971tjOE = [],[],[],''
	headers = { 'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' }
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',M08MPGgsh4n5rKe,'',headers,True,'','RESOLVERS-EGYBEST-1st')
	if 'Location' in list(aQniqUlZk8.headers.keys()): TW6JIBgC971tjOE = aQniqUlZk8.headers['Location']
	if 'http' in TW6JIBgC971tjOE:
		if '__watch' in url: TW6JIBgC971tjOE = TW6JIBgC971tjOE.replace('/f/','/v/')
		ggylqj6eHQRkXO5PnYc = M08MPGgsh4n5rKe.split('?PHPSID=')[1]
		headers = { 'User-Agent':headers['User-Agent'] , 'Cookie':'PHPSID='+ggylqj6eHQRkXO5PnYc }
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',TW6JIBgC971tjOE,'',headers,False,'','EGYBEST-PLAY-3rd')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		if '/f/' in TW6JIBgC971tjOE: items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<h2>.*?href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		elif '/v/' in TW6JIBgC971tjOE: items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('id="video".*?src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if items: return [],[''],[ items[0] ]
		elif '<h1>404</h1>' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2:
			return 'Error: سيرفر الفيديو فيه حجب ضد كودي ومصدره من الإنترنت الخاصة بك',[],[]
	else: return 'Error: Resolver Failed EGYBEST',[],[]
def HHTr7ZpI8R(ZCimQhV5lovgspAYzHq1Ef27u8ja4R):
	oBzGqDUAi7KaL8vFdZtP9XIcf = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('postid=(.*?)&serverid=(.*?)&&',ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'&&',E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.IGNORECASE)
	F6iHzDbQXWOje20AuR7t8SrlpKoIU,YusKpP58ZyhOD = oBzGqDUAi7KaL8vFdZtP9XIcf[0]
	url = 'https://series4watch.net/ajaxCenter?_action=getserver&_post_id='+F6iHzDbQXWOje20AuR7t8SrlpKoIU+'&serverid='+YusKpP58ZyhOD
	headers = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' }
	M08MPGgsh4n5rKe = MQeSPGrtXET1ahZjnwVmcxfF32(jEPuRTVbZg4MCimJxzf3I6wFa,url,'',headers,'','RESOLVERS-SERIES4WATCH-1st')
	return 'NEED_EXTERNAL_RESOLVERS',[''],[M08MPGgsh4n5rKe]
def s0atThLKQ2(url):
	vMSQsdJ0gCrh7ztnR96yDXqOYaj = SLMTm6RQ34ic7v5s9rBG(url,'url')
	TC7fWv2a1gLJGiAtN8 = {'Referer':vMSQsdJ0gCrh7ztnR96yDXqOYaj,'Accept-Encoding':'gzip, deflate'}
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(RvKQX7HgZ6faBueLsMjxGtPobTd0,'GET',url,'',TC7fWv2a1gLJGiAtN8,'','','RESOLVERS-MYCIMA-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('player.qualityselector(.*?)formats:',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	M08MPGgsh4n5rKe = ''
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('format: \'(\d.*?)\', src: "(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = [],[]
		for title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
			da6IAnqQ7oV2Hx13F5gbBT4.append(title)
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
		if len(jVMHRouKgQFAESmd7B8ObTYy)==1: M08MPGgsh4n5rKe = jVMHRouKgQFAESmd7B8ObTYy[0]
		elif len(jVMHRouKgQFAESmd7B8ObTYy)>1:
			NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql('أختر الملف المناسب', da6IAnqQ7oV2Hx13F5gbBT4)
			if NljOosKT8WJBpch==-1: return '',[],[]
			M08MPGgsh4n5rKe = jVMHRouKgQFAESmd7B8ObTYy[NljOosKT8WJBpch]
	else:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('source src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3: M08MPGgsh4n5rKe = TIkiozSLCv6werb97mHQ0q4y3[0]
	if not M08MPGgsh4n5rKe: return 'Error: Resolver Failed MYCIMA',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[M08MPGgsh4n5rKe]
def CJ2q9lUhtG(url):
	vMSQsdJ0gCrh7ztnR96yDXqOYaj = SLMTm6RQ34ic7v5s9rBG(url,'url')
	TC7fWv2a1gLJGiAtN8 = {'Referer':vMSQsdJ0gCrh7ztnR96yDXqOYaj,'Accept-Encoding':'gzip, deflate'}
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(RvKQX7HgZ6faBueLsMjxGtPobTd0,'GET',url,'',TC7fWv2a1gLJGiAtN8,'','','RESOLVERS-WECIMA-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('player.qualityselector(.*?)formats:',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	M08MPGgsh4n5rKe = ''
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('format: \'(\d.*?)\', src: "(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = [],[]
		for title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
			da6IAnqQ7oV2Hx13F5gbBT4.append(title)
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
		if len(jVMHRouKgQFAESmd7B8ObTYy)==1: M08MPGgsh4n5rKe = jVMHRouKgQFAESmd7B8ObTYy[0]
		elif len(jVMHRouKgQFAESmd7B8ObTYy)>1:
			NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql('أختر الملف المناسب', da6IAnqQ7oV2Hx13F5gbBT4)
			if NljOosKT8WJBpch==-1: return '',[],[]
			M08MPGgsh4n5rKe = jVMHRouKgQFAESmd7B8ObTYy[NljOosKT8WJBpch]
	if not M08MPGgsh4n5rKe:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('source src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3: M08MPGgsh4n5rKe = TIkiozSLCv6werb97mHQ0q4y3[0]
	if not M08MPGgsh4n5rKe: return 'Error: Resolver Failed WECIMA',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[M08MPGgsh4n5rKe]
def PFo6yw8eGk(ZCimQhV5lovgspAYzHq1Ef27u8ja4R):
	oBzGqDUAi7KaL8vFdZtP9XIcf = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(http.*?)\?postid=(.*?)&serverid=(.*?)&&',ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'&&',E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	url,F6iHzDbQXWOje20AuR7t8SrlpKoIU,YusKpP58ZyhOD = oBzGqDUAi7KaL8vFdZtP9XIcf[0]
	data = {'post_id':F6iHzDbQXWOje20AuR7t8SrlpKoIU,'server':YusKpP58ZyhOD}
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'POST',url,data,'','','','RESOLVERS-AKOAMCAM-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	M08MPGgsh4n5rKe = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('iframe src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[M08MPGgsh4n5rKe]
def MQ3pKzOWqD(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','RESOLVERS-CIMALIGHT-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<iframe.*?src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]
		if ZCimQhV5lovgspAYzHq1Ef27u8ja4R: return 'NEED_EXTERNAL_RESOLVERS',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R]
	return 'Error: Resolver Failed CIMALIGHT',[],[]
def wMuFlHxfKr(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','RESOLVERS-CIMACLUP-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<IFRAME SRC="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R]
def qqQlJH0SDK(url):
	bBac0ZnqRLiYT6x93vJyFjQ = SLMTm6RQ34ic7v5s9rBG(url,'url')
	if 'index=' in url:
		headers = {'Referer':bBac0ZnqRLiYT6x93vJyFjQ}
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'',headers,'','','RESOLVERS-CIMANOW-1st')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		M08MPGgsh4n5rKe = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if M08MPGgsh4n5rKe:
			M08MPGgsh4n5rKe = M08MPGgsh4n5rKe[0]
			if 'cimanow' in M08MPGgsh4n5rKe:
				M08MPGgsh4n5rKe = M08MPGgsh4n5rKe.replace('https://','http://')
				aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',M08MPGgsh4n5rKe,'',headers,'','','RESOLVERS-CIMANOW-2nd')
				flARjI3NM9CQnWY1xk7 = aQniqUlZk8.content
				items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('source src="(.*?)".*?size="(.*?)"',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
				da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = [],[]
				kFlE9TNexjg76 = SLMTm6RQ34ic7v5s9rBG(M08MPGgsh4n5rKe,'url')
				for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,LjG8y1rb9AgJF2I3i64ZDtCXMa7n in reversed(items):
					ZCimQhV5lovgspAYzHq1Ef27u8ja4R = kFlE9TNexjg76+ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'|Referer='+kFlE9TNexjg76
					da6IAnqQ7oV2Hx13F5gbBT4.append(LjG8y1rb9AgJF2I3i64ZDtCXMa7n)
					jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
				return '',da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
			else: return 'NEED_EXTERNAL_RESOLVERS',[''],[M08MPGgsh4n5rKe]
	M08MPGgsh4n5rKe = url+'|Referer='+bBac0ZnqRLiYT6x93vJyFjQ
	return '',[''],[M08MPGgsh4n5rKe]
def DlUr25afzG79hEqC1SdjIXB0(ZCimQhV5lovgspAYzHq1Ef27u8ja4R):
	bBac0ZnqRLiYT6x93vJyFjQ = SLMTm6RQ34ic7v5s9rBG(ZCimQhV5lovgspAYzHq1Ef27u8ja4R,'url')
	if 'postid' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
		oBzGqDUAi7KaL8vFdZtP9XIcf = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(http.*?)\?postid=(.*?)&serverid=(.*?)&&',ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'&&',E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		url,F6iHzDbQXWOje20AuR7t8SrlpKoIU,YusKpP58ZyhOD = oBzGqDUAi7KaL8vFdZtP9XIcf[0]
		data = {'id':F6iHzDbQXWOje20AuR7t8SrlpKoIU,'server':YusKpP58ZyhOD}
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'POST',url,data,'','','','RESOLVERS-CIMANOW-1st')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		M08MPGgsh4n5rKe = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('iframe src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)[0]
		if 'cimanow' in M08MPGgsh4n5rKe:
			headers = {'Referer':bBac0ZnqRLiYT6x93vJyFjQ,'User-Agent':''}
			aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',M08MPGgsh4n5rKe,'',headers,'','','RESOLVERS-CIMANOW-2nd')
			flARjI3NM9CQnWY1xk7 = aQniqUlZk8.content
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('src="(.*?)".*?size="(.*?)"',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = [],[]
			kFlE9TNexjg76 = SLMTm6RQ34ic7v5s9rBG(M08MPGgsh4n5rKe,'url')
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,LjG8y1rb9AgJF2I3i64ZDtCXMa7n in reversed(items):
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = kFlE9TNexjg76+ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'|Referer='+kFlE9TNexjg76
				da6IAnqQ7oV2Hx13F5gbBT4.append(LjG8y1rb9AgJF2I3i64ZDtCXMa7n)
				jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			return '',da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
		else: return 'NEED_EXTERNAL_RESOLVERS',[''],[M08MPGgsh4n5rKe]
	else:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'|Referer='+bBac0ZnqRLiYT6x93vJyFjQ
		return '',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R]
def nEhfOWmx8u(ZCimQhV5lovgspAYzHq1Ef27u8ja4R):
	if 'postid' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
		oBzGqDUAi7KaL8vFdZtP9XIcf = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('postid=(.*?)&serverid=(.*?)&&',ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'&&',E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.IGNORECASE)
		F6iHzDbQXWOje20AuR7t8SrlpKoIU,YusKpP58ZyhOD = oBzGqDUAi7KaL8vFdZtP9XIcf[0]
		NpZVaydoCjGHQnubF0cRw1qWEh = SLMTm6RQ34ic7v5s9rBG(ZCimQhV5lovgspAYzHq1Ef27u8ja4R,'url')
		url = NpZVaydoCjGHQnubF0cRw1qWEh+'/ajaxCenter?_action=getserver&_post_id='+F6iHzDbQXWOje20AuR7t8SrlpKoIU+'&serverid='+YusKpP58ZyhOD
		headers = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' }
		M08MPGgsh4n5rKe = MQeSPGrtXET1ahZjnwVmcxfF32(jEPuRTVbZg4MCimJxzf3I6wFa,url,'',headers,'','RESOLVERS-ARBLIONZ-1st')
		M08MPGgsh4n5rKe = M08MPGgsh4n5rKe.replace('\n','').replace('\r','')
		return 'NEED_EXTERNAL_RESOLVERS',[''],[M08MPGgsh4n5rKe]
	elif '/redirect/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
		VVPq2W7SsGEDkZCo = 0
		while '/redirect/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R and VVPq2W7SsGEDkZCo<5:
			aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',ZCimQhV5lovgspAYzHq1Ef27u8ja4R,'','','','','RESOLVERS-ARBLIONZ-2nd')
			if 'Location' in list(aQniqUlZk8.headers.keys()): ZCimQhV5lovgspAYzHq1Ef27u8ja4R = aQniqUlZk8.headers['Location']
			VVPq2W7SsGEDkZCo += 1
		return '',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R]
	else: return 'Error: Resolver Failed ARBLIONZ',[],[]
def AOiTe7sQSc(url):
	vMSQsdJ0gCrh7ztnR96yDXqOYaj = SLMTm6RQ34ic7v5s9rBG(url,'url')
	headers = {'Referer':vMSQsdJ0gCrh7ztnR96yDXqOYaj,'User-Agent':FY2qK6eHVBl4D0pEut8IgkTczyG()}
	if '/embed-' in url:
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(jEPuRTVbZg4MCimJxzf3I6wFa,url,'',headers,'','RESOLVERS-ARABSEED-2nd')
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<source src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0].replace('https','http')
			return '',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R]
	else:
		ka6e7Fm1il9PBhutD4qOoIdb0Awf = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',url,'',headers,'','','RESOLVERS-ARABSEED-3rd')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = ka6e7Fm1il9PBhutD4qOoIdb0Awf.content
		TC7fWv2a1gLJGiAtN8 = headers.copy()
		if '_lnk_' in str(ka6e7Fm1il9PBhutD4qOoIdb0Awf.cookies):
			cookies = ka6e7Fm1il9PBhutD4qOoIdb0Awf.cookies
			TC7fWv2a1gLJGiAtN8['Cookie'] = BUTSkzgFC7(cswW2KC5FOH64vq97ZkNR(cookies))
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('link.href = "(http.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if not ZCimQhV5lovgspAYzHq1Ef27u8ja4R: return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
		else:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = BUTSkzgFC7(ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0])+'&d=1'
			WcPEG7nehsCwig809NyHMZ = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',ZCimQhV5lovgspAYzHq1Ef27u8ja4R,'',TC7fWv2a1gLJGiAtN8,'','','RESOLVERS-ARABSEED-4th')
			M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = WcPEG7nehsCwig809NyHMZ.content
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('id="btn".*?href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = BUTSkzgFC7(ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0])
				if 'mp4' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R and '/d/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: return '',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R]
				else: return 'NEED_EXTERNAL_RESOLVERS',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R]
	return 'Error: Resolver Failed ARABSEED',[],[]
def UBlEgwVT6y(ZCimQhV5lovgspAYzHq1Ef27u8ja4R):
	if '_action=getserver' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
		headers = {'X-Requested-With':'XMLHttpRequest'}
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',ZCimQhV5lovgspAYzHq1Ef27u8ja4R,'',headers,'','','RESOLVERS-SHAHID4U-1st')
		url = aQniqUlZk8.content
		if url: return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
	else:
		oBzGqDUAi7KaL8vFdZtP9XIcf = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('postid=(.*?)&serverid=(.*?)$',ZCimQhV5lovgspAYzHq1Ef27u8ja4R,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.IGNORECASE)
		if not oBzGqDUAi7KaL8vFdZtP9XIcf: oBzGqDUAi7KaL8vFdZtP9XIcf = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('_post_id=(.*?)&serverid=(.*?)$',ZCimQhV5lovgspAYzHq1Ef27u8ja4R,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.IGNORECASE)
		F6iHzDbQXWOje20AuR7t8SrlpKoIU,YusKpP58ZyhOD = oBzGqDUAi7KaL8vFdZtP9XIcf[0]
		vMSQsdJ0gCrh7ztnR96yDXqOYaj = SLMTm6RQ34ic7v5s9rBG(ZCimQhV5lovgspAYzHq1Ef27u8ja4R,'url')
		url = vMSQsdJ0gCrh7ztnR96yDXqOYaj+'/wp-content/themes/theme/Ajaxat/Single/Server.php'
		data = {'id':F6iHzDbQXWOje20AuR7t8SrlpKoIU,'i':YusKpP58ZyhOD}
		headers = {'X-Requested-With':'XMLHttpRequest','Referer':ZCimQhV5lovgspAYzHq1Ef27u8ja4R}
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'POST',url,data,headers,'','','RESOLVERS-SHAHID4U-2nd')
		flARjI3NM9CQnWY1xk7 = aQniqUlZk8.content
		M08MPGgsh4n5rKe = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('src="(.*?)"',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.IGNORECASE)
		if M08MPGgsh4n5rKe:
			M08MPGgsh4n5rKe = M08MPGgsh4n5rKe[0]
			return 'NEED_EXTERNAL_RESOLVERS',[''],[M08MPGgsh4n5rKe]
	return 'Error: Resolver Failed SHAHID4U',[],[]
def eQpBzfyE4USXD3CLJtknF9c1(KKk93ZeRcqpswnlQVTD4dF0YxXIfv):
	PmokWnO826iQLB = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting('av.akwam.verification')
	headers = {'Cookie':PmokWnO826iQLB} if PmokWnO826iQLB else ''
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',KKk93ZeRcqpswnlQVTD4dF0YxXIfv,'',headers,'','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-1st')
	kWmitrquPTzGNRKDv9AEJ201 = aQniqUlZk8.content
	RRlSg2aCYuhb8W6ntjvc = str(aQniqUlZk8.headers)
	NKdx0lSun7zhqyBJ9LcAvkftFaM2e8 = RRlSg2aCYuhb8W6ntjvc+kWmitrquPTzGNRKDv9AEJ201
	if '.mp4' in NKdx0lSun7zhqyBJ9LcAvkftFaM2e8: iiOR3UoleLk = True
	else:
		gw4mHE9pQaYPJjtuVDhslife5GMc,wr9ZDoyjmK5gxci083G,Z0oylCwSKMX1BGPIbFVLgT,FWKp7dkOXs1nmhwPuf95,iiOR3UoleLk = '','','','',False
		captcha = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('page-redirect.*?action="(.*?)".*?data-sitekey="(.*?)"',kWmitrquPTzGNRKDv9AEJ201,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if captcha: Z0oylCwSKMX1BGPIbFVLgT,FWKp7dkOXs1nmhwPuf95 = captcha[0]
		xE5VGRPypOvh = mR20sONyKIlV['PYTHON'][7]
		gg6VwuY0xOi7 = zVw5tvmZRX(32)
		if 0:
			data = {'user':gg6VwuY0xOi7,'version':VnhK9wvHBGuo1fei8DXQ02yFZtsWE,'url':KKk93ZeRcqpswnlQVTD4dF0YxXIfv,'key':FWKp7dkOXs1nmhwPuf95,'id':'','job':'geturls'}
			aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,'POST',xE5VGRPypOvh,data,'','','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-2nd')
			M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = ''
		if M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2.startswith('URLS='):
			RQxVzFYm12C = GVQAnvYCT3dS('list',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2.split('URLS=',1)[1])
			for VWi2dTb46v3eOryuspKBF9L in RQxVzFYm12C:
				url = VWi2dTb46v3eOryuspKBF9L['url']
				rk69B8TYfGvW0swz = VWi2dTb46v3eOryuspKBF9L['method']
				data = VWi2dTb46v3eOryuspKBF9L['data']
				headers = VWi2dTb46v3eOryuspKBF9L['headers']
				aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,rk69B8TYfGvW0swz,url,data,headers,'','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-3rd')
				kWmitrquPTzGNRKDv9AEJ201 = aQniqUlZk8.content
				if '.mp4' in kWmitrquPTzGNRKDv9AEJ201:
					iiOR3UoleLk = True
					break
				RRlSg2aCYuhb8W6ntjvc = str(aQniqUlZk8.headers)
				NKdx0lSun7zhqyBJ9LcAvkftFaM2e8 = RRlSg2aCYuhb8W6ntjvc+kWmitrquPTzGNRKDv9AEJ201
				gw4mHE9pQaYPJjtuVDhslife5GMc = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(akwamVerification\w+).*?"(eyJ.*?)"',NKdx0lSun7zhqyBJ9LcAvkftFaM2e8,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
				wr9ZDoyjmK5gxci083G = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('recaptcha-token.*?"(03A.*?)"',NKdx0lSun7zhqyBJ9LcAvkftFaM2e8,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
				if wr9ZDoyjmK5gxci083G: wr9ZDoyjmK5gxci083G = wr9ZDoyjmK5gxci083G[0]
				if gw4mHE9pQaYPJjtuVDhslife5GMc or wr9ZDoyjmK5gxci083G: break
		if not iiOR3UoleLk:
			if not gw4mHE9pQaYPJjtuVDhslife5GMc:
				if captcha and not wr9ZDoyjmK5gxci083G:
					if 1: wr9ZDoyjmK5gxci083G = aalYnheZdTrm7V(FWKp7dkOXs1nmhwPuf95,'ar',KKk93ZeRcqpswnlQVTD4dF0YxXIfv)
					else:
						if not M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2.startswith('ID='):
							data = {'user':gg6VwuY0xOi7,'version':VnhK9wvHBGuo1fei8DXQ02yFZtsWE,'url':KKk93ZeRcqpswnlQVTD4dF0YxXIfv,'key':FWKp7dkOXs1nmhwPuf95,'id':'','job':'getid'}
							aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,'POST',xE5VGRPypOvh,data,'','','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-4th')
							M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
						else: M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = 'ID=1234::::TIMEOUT=45'
						if M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2.startswith('ID='):
							eJNWFI2XcutkGLxEKAdhP1ma5rH3Z = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('ID=(.*?)::::TIMEOUT=(.*?)$',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
							gGPBadqmCe,mze2PWBb1idXw9Z0Hh = eJNWFI2XcutkGLxEKAdhP1ma5rH3Z[0]
							maCNIYkc0HOiEGpL3g = 'هذه العملية تحتاج وقت من 10 إلى '+mze2PWBb1idXw9Z0Hh+' ثانية'
							ZUNMvsVnGde0mpQxb9ID8aKRkFtJg = ARxKazncryd6Ij2OGtCD5eEihuB8m()
							ZUNMvsVnGde0mpQxb9ID8aKRkFtJg.create('محاولة تجاوز فحص أنا أنسان ولست برنامج كومبيوتر',maCNIYkc0HOiEGpL3g)
							CMjXrFhGxEfzHiWpV = w6vebiEZtpCjJcILP8Skx5rHn.time()
							wVWo7NKvt2E,xq9un3s6LvBrVafY = 0,0
							while wVWo7NKvt2E<int(mze2PWBb1idXw9Z0Hh):
								aayBzF9OcXn1kYqRhDNm7gTZ(ZUNMvsVnGde0mpQxb9ID8aKRkFtJg,int(wVWo7NKvt2E/int(mze2PWBb1idXw9Z0Hh)*100),maCNIYkc0HOiEGpL3g,'',mze2PWBb1idXw9Z0Hh+' / '+str(int(wVWo7NKvt2E))+'  ثانية')
								if wVWo7NKvt2E>xq9un3s6LvBrVafY+10:
									data = {'user':gg6VwuY0xOi7,'version':VnhK9wvHBGuo1fei8DXQ02yFZtsWE,'url':KKk93ZeRcqpswnlQVTD4dF0YxXIfv,'key':FWKp7dkOXs1nmhwPuf95,'id':gGPBadqmCe,'job':'gettoken'}
									aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,'POST',xE5VGRPypOvh,data,'','','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-5th')
									M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
									if M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2.startswith('TOKEN='):
										wr9ZDoyjmK5gxci083G = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2.split('TOKEN=',1)[1]
										break
									xq9un3s6LvBrVafY = wVWo7NKvt2E
								else: w6vebiEZtpCjJcILP8Skx5rHn.sleep(1)
								wVWo7NKvt2E = w6vebiEZtpCjJcILP8Skx5rHn.time()-CMjXrFhGxEfzHiWpV
							ZUNMvsVnGde0mpQxb9ID8aKRkFtJg.close()
				if wr9ZDoyjmK5gxci083G:
					wYrDVRiftGLlO0Qcb9WjTIU = aQniqUlZk8.cookies
					vxSy1RusNhQ7zoTiF = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('akwam_session=(.*?);',NKdx0lSun7zhqyBJ9LcAvkftFaM2e8,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
					if 'akwam_session' in list(wYrDVRiftGLlO0Qcb9WjTIU.keys()): vxSy1RusNhQ7zoTiF = wYrDVRiftGLlO0Qcb9WjTIU['akwam_session']
					elif vxSy1RusNhQ7zoTiF: vxSy1RusNhQ7zoTiF = vxSy1RusNhQ7zoTiF[0]
					captcha = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('page-redirect.*?action="(.*?)".*?data-sitekey="(.*?)"',kWmitrquPTzGNRKDv9AEJ201,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
					if captcha: Z0oylCwSKMX1BGPIbFVLgT,FWKp7dkOXs1nmhwPuf95 = captcha[0]
					if vxSy1RusNhQ7zoTiF and captcha:
						headers = {'Cookie':'akwam_session='+vxSy1RusNhQ7zoTiF,'Referer':KKk93ZeRcqpswnlQVTD4dF0YxXIfv,'Content-Type':'application/x-www-form-urlencoded'}
						data = 'g-recaptcha-response='+wr9ZDoyjmK5gxci083G
						aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'POST',Z0oylCwSKMX1BGPIbFVLgT,data,headers,False,'','RESOLVERS-BYPASS_AKWAM_CAPTCHA-6th')
						kWmitrquPTzGNRKDv9AEJ201 = aQniqUlZk8.content
						try: cookies = aQniqUlZk8.cookies
						except: cookies = {}
						gw4mHE9pQaYPJjtuVDhslife5GMc = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("'(akwamVerification.*?)': '(.*?)'",str(cookies),E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if gw4mHE9pQaYPJjtuVDhslife5GMc:
				GG9zmPqulYDyJCtWwkE8,gw4mHE9pQaYPJjtuVDhslife5GMc = gw4mHE9pQaYPJjtuVDhslife5GMc[0]
				PmokWnO826iQLB = GG9zmPqulYDyJCtWwkE8+'='+gw4mHE9pQaYPJjtuVDhslife5GMc
				if2qpOxlZd8MBGeo5uNIyLEsz.setSetting('av.akwam.verification',PmokWnO826iQLB)
				tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','نجحت عملية فحص أنا إنسان .. وقام البرنامج بخزن نتائج هذا الفحص لكي يستخدمها لاحقا .. ولا توجد حاجة لإعادة هذا الفحص لعدة أشهر \n\n علما أن هذا الفحص سوف يتكرر في حالة تغير ربط الجهاز بالإنترنت .. أو إطفاء راوتر الإنترنت .. أو فصل سلك الراوتر .. أو استخدام VPN أو بروكسي')
				if '.mp4' not in kWmitrquPTzGNRKDv9AEJ201:
					headers = {'Cookie':PmokWnO826iQLB}
					aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',KKk93ZeRcqpswnlQVTD4dF0YxXIfv,'',headers,'','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-7th')
					kWmitrquPTzGNRKDv9AEJ201 = aQniqUlZk8.content
	if not iiOR3UoleLk and not PmokWnO826iQLB: tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','فشلت عملية فحص أنا أنسان .. حاول إعادة العملية مرة أخرى باستخدام نفس الفيديو أو فيديو غيره من نفس الموقع')
	return kWmitrquPTzGNRKDv9AEJ201
def JJjPSnbr9G(url,type,LjG8y1rb9AgJF2I3i64ZDtCXMa7n):
	zcBjFq4VQlp20ZekGO,DSkd2Y0zhRKLG = [],[]
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',url,'','','','','RESOLVERS-AKWAM-1st')
	flARjI3NM9CQnWY1xk7 = aQniqUlZk8.content
	cz4e6sNTj53E09xtaArJLKDg = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<a href=".*?</a>',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ziJLDVT8NM2QcgIpmE9A in cz4e6sNTj53E09xtaArJLKDg:
		cc0O1M4e5jtfoq = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(http.*?)".*?<span.*?">(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in cc0O1M4e5jtfoq:
			if ZCimQhV5lovgspAYzHq1Ef27u8ja4R in zcBjFq4VQlp20ZekGO: continue
			if '/watch/' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R and '/download/' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: continue
			title = title.replace('</span>','').replace(' - ','').strip(' ').replace('  ',' ')
			zcBjFq4VQlp20ZekGO.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			DSkd2Y0zhRKLG.append(title)
	if len(zcBjFq4VQlp20ZekGO)>1:
		NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql('بعضها يحتاج 60 ثانية',DSkd2Y0zhRKLG)
		if NljOosKT8WJBpch==-1: return 'Error: Resolver Canceled AKWAM',[],[]
	elif len(zcBjFq4VQlp20ZekGO)==1: NljOosKT8WJBpch = 0
	else: return 'Error: Resolver Failed AKWAM',[],[]
	KKk93ZeRcqpswnlQVTD4dF0YxXIfv = zcBjFq4VQlp20ZekGO[NljOosKT8WJBpch]
	kWmitrquPTzGNRKDv9AEJ201 = eQpBzfyE4USXD3CLJtknF9c1(KKk93ZeRcqpswnlQVTD4dF0YxXIfv)
	jVMHRouKgQFAESmd7B8ObTYy,da6IAnqQ7oV2Hx13F5gbBT4 = [],[]
	if type=='download':
		v9vyY3MRdTQ8L4qkrW = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('btn-loader.*?href="(.*?)"',kWmitrquPTzGNRKDv9AEJ201,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if v9vyY3MRdTQ8L4qkrW:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = BUTSkzgFC7(v9vyY3MRdTQ8L4qkrW[0])
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			da6IAnqQ7oV2Hx13F5gbBT4.append(LjG8y1rb9AgJF2I3i64ZDtCXMa7n)
	elif type=='watch':
		cc0O1M4e5jtfoq = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<source.*?src="(.*?)".*?size="(.*?)"',kWmitrquPTzGNRKDv9AEJ201,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,size in cc0O1M4e5jtfoq:
			if not ZCimQhV5lovgspAYzHq1Ef27u8ja4R: continue
			if LjG8y1rb9AgJF2I3i64ZDtCXMa7n in size:
				da6IAnqQ7oV2Hx13F5gbBT4.append(size)
				jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
				break
		if not jVMHRouKgQFAESmd7B8ObTYy:
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,size in cc0O1M4e5jtfoq:
				if not ZCimQhV5lovgspAYzHq1Ef27u8ja4R: continue
				da6IAnqQ7oV2Hx13F5gbBT4.append(size)
				jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	if not jVMHRouKgQFAESmd7B8ObTYy: return 'Error: Resolver Failed AKWAM',[],[]
	return '',da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
def fxd9jQipFC(url,GG9zmPqulYDyJCtWwkE8):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','',True,'','RESOLVERS-AKOAM-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	cookies = aQniqUlZk8.cookies
	if 'golink' in list(cookies.keys()):
		PmokWnO826iQLB = cookies['golink']
		PmokWnO826iQLB = BUTSkzgFC7(zKGXT5sJeRq(PmokWnO826iQLB))
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('route":"(.*?)"',PmokWnO826iQLB,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		M08MPGgsh4n5rKe = items[0].replace('\/','/')
		M08MPGgsh4n5rKe = zKGXT5sJeRq(M08MPGgsh4n5rKe)
	else: M08MPGgsh4n5rKe = url
	if 'catch.is' in M08MPGgsh4n5rKe:
		id = M08MPGgsh4n5rKe.split('%2F')[-1]
		M08MPGgsh4n5rKe = 'http://catch.is/'+id
		return 'NEED_EXTERNAL_RESOLVERS',[''],[M08MPGgsh4n5rKe]
	else:
		website = mR20sONyKIlV['AKOAM'][0]
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',website,'','',True,'','RESOLVERS-AKOAM-2nd')
		mmUkB0GAOVHQPw1NgeFSI = aQniqUlZk8.url
		g5XSZ8V4zpQO7vK6Gsi = M08MPGgsh4n5rKe.split('/')[2]
		LXhmM5dS0xKDrZlItpB = mmUkB0GAOVHQPw1NgeFSI.split('/')[2]
		TW6JIBgC971tjOE = M08MPGgsh4n5rKe.replace(g5XSZ8V4zpQO7vK6Gsi,LXhmM5dS0xKDrZlItpB)
		headers = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' , 'Referer':TW6JIBgC971tjOE }
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'POST', TW6JIBgC971tjOE, '', headers, False,'','RESOLVERS-AKOAM-3rd')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('direct_link":"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.IGNORECASE)
		if not items:
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<iframe.*?src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.IGNORECASE)
			if not items:
				items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<embed.*?src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.IGNORECASE)
		if items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = items[0].replace('\/','/')
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.rstrip('/')
			if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = 'http:' + ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.replace('http://','https://')
			if GG9zmPqulYDyJCtWwkE8=='': d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = '',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R]
			else: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = 'NEED_EXTERNAL_RESOLVERS',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R]
		else: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = 'Error: Resolver Failed AKOAM',[],[]
		return d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
def qMLJlhSP4YZbKO5m6xjNW9(url):
	headers = { 'User-Agent' : '' }
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(jEPuRTVbZg4MCimJxzf3I6wFa,url,'',headers,'','RESOLVERS-RAPIDVIDEO-1st')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<source src="(.*?)".*?label="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy,errno = [],[],''
	if items:
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,JNuHrgRwE8K0hcdMBtQl in items:
			da6IAnqQ7oV2Hx13F5gbBT4.append(JNuHrgRwE8K0hcdMBtQl)
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	if len(jVMHRouKgQFAESmd7B8ObTYy)==0: return 'Error: Resolver Failed RAPIDVIDEO',[],[]
	return '',da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
def xgEMXw6Pci4tRLDvhyerQdj(url):
	headers = {'User-Agent':''}
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(jEPuRTVbZg4MCimJxzf3I6wFa,url,'',headers,'','RESOLVERS-UQLOAD-1st')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('sources: \["(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if items:
		url = items[0]+'|Referer='+url
		return '',[''],[url]
	else: return 'Error: Resolver Failed UQLOAD',[],[]
def FmA95zrJoi1kfd7xnCW8c6RMgD2(url):
	url = url.strip('/')
	if '/embed/' in url: id = url.split('/')[4]
	else: id = url.split('/')[-1]
	url = 'https://vcstream.to/player?fid=' + id
	headers = { 'User-Agent' : '' }
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(jEPuRTVbZg4MCimJxzf3I6wFa,url,'',headers,'','RESOLVERS-VCSTREAM-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2.replace('\\','')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('file":"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if items: return '',[''],[ items[0] ]
	else: return 'Error: Resolver Failed VCSTREAM',[],[]
def K5N6ch0HEBTCMSpg(url):
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(jEPuRTVbZg4MCimJxzf3I6wFa,url,'','','','RESOLVERS-VIDOZA-1st')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('src: "(.*?)".*?label:"(.*?)", res:"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = [],[]
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,JNuHrgRwE8K0hcdMBtQl,pghcM6meB0SWbXHYtQ in items:
		da6IAnqQ7oV2Hx13F5gbBT4.append(JNuHrgRwE8K0hcdMBtQl+' '+pghcM6meB0SWbXHYtQ)
		jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	if len(jVMHRouKgQFAESmd7B8ObTYy)==0: return 'Error: Resolver Failed VIDOZA',[],[]
	return '',da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
def a5WH2Xce0kpPo7yCB(url):
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(jEPuRTVbZg4MCimJxzf3I6wFa,url,'','','','RESOLVERS-WATCHVIDEO-1st')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("download_video\('(.*?)','(.*?)','(.*?)'\)\">(.*?)</a>.*?<td>(.*?),.*?</td>",M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	items = set(items)
	da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = [],[]
	for id,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,hash,JNuHrgRwE8K0hcdMBtQl,pghcM6meB0SWbXHYtQ in items:
		url = 'https://watchvideo.us/dl?op=download_orig&id='+id+'&mode='+n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw+'&hash='+hash
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(jEPuRTVbZg4MCimJxzf3I6wFa,url,'','','','RESOLVERS-WATCHVIDEO-2nd')
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('direct link.*?href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
			da6IAnqQ7oV2Hx13F5gbBT4.append(JNuHrgRwE8K0hcdMBtQl+' '+pghcM6meB0SWbXHYtQ)
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	if len(jVMHRouKgQFAESmd7B8ObTYy)==0: return 'Error: Resolver Failed WATCHVIDEO',[],[]
	return '',da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
def JrG4BmKHWNfncQ9zwhbEkZF27S5j(url):
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ''
	if 1 or 'Key=' not in url:
		M08MPGgsh4n5rKe = url.replace('upbom.live','uppom.live')
		M08MPGgsh4n5rKe = M08MPGgsh4n5rKe.split('/')
		id = M08MPGgsh4n5rKe[3]
		M08MPGgsh4n5rKe = '/'.join(M08MPGgsh4n5rKe[0:4])
		VVNkoRCUm96MbtuqgrOe = {'id':id,'op':'download2','method_free':'Free+Download+%3E%3E'}
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'POST',M08MPGgsh4n5rKe,VVNkoRCUm96MbtuqgrOe,'','','','RESOLVERS-UPBOM-1st')
		if 'Location' in list(aQniqUlZk8.headers.keys()): ZCimQhV5lovgspAYzHq1Ef27u8ja4R = aQniqUlZk8.headers['Location']
		if not ZCimQhV5lovgspAYzHq1Ef27u8ja4R and aQniqUlZk8.succeeded:
			M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('id="direct_link".*?href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]
	else:
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',url,'','','','','RESOLVERS-UPBOM-2nd')
		if 'location' in list(aQniqUlZk8.headers.keys()): ZCimQhV5lovgspAYzHq1Ef27u8ja4R = aQniqUlZk8.headers['location']
	if ZCimQhV5lovgspAYzHq1Ef27u8ja4R: return '',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R]
	return 'Error: Resolver Failed UPBOM',[],[]
def uI5t48amSd(url):
	headers = { 'User-Agent' : '' }
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(jEPuRTVbZg4MCimJxzf3I6wFa,url,'',headers,'','RESOLVERS-LIIVIDEO-1st')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('sources:.*?"(.*?)","(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = [],[]
	if items:
		da6IAnqQ7oV2Hx13F5gbBT4.append('mp4')
		jVMHRouKgQFAESmd7B8ObTYy.append(items[0][1])
		da6IAnqQ7oV2Hx13F5gbBT4.append('m3u8')
		jVMHRouKgQFAESmd7B8ObTYy.append(items[0][0])
		return '',da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
	else: return 'Error: Resolver Failed LIIVIDEO',[],[]
def dULi8YwfV6(url):
	id = url.split('/')[-1]
	id = id.split('&')[0]
	id = id.replace('watch?v=','')
	M08MPGgsh4n5rKe = mR20sONyKIlV['YOUTUBE'][0]+'/watch?v='+id
	vU3B8rIj4Yp = 'http://youtu.be/'+id
	lijgqJd5Bw1RZCVnuhf60m,UPiFr6agVf9sCuzq5T,IdJtKTqbio0O3Hl5uULRha,QTad2JygBrUEulNCsmznbOh = '','','',''
	for Deiz7ocWQjVnIg in range(5):
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,'GET',M08MPGgsh4n5rKe,'','','','','RESOLVERS-YOUTUBE-1st')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		if 'itag' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2: break
		w6vebiEZtpCjJcILP8Skx5rHn.sleep(2)
	GrSazPw083KDJY6c7Hvt5NEqkhWQuV = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('var ytInitialPlayerResponse = (.*?);</script>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if GrSazPw083KDJY6c7Hvt5NEqkhWQuV: GrSazPw083KDJY6c7Hvt5NEqkhWQuV = GrSazPw083KDJY6c7Hvt5NEqkhWQuV[0]
	else: GrSazPw083KDJY6c7Hvt5NEqkhWQuV = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
	GrSazPw083KDJY6c7Hvt5NEqkhWQuV = GrSazPw083KDJY6c7Hvt5NEqkhWQuV.replace('\\u0026','&')
	BkEHpgzhWFOR85 = GVQAnvYCT3dS('dict',GrSazPw083KDJY6c7Hvt5NEqkhWQuV)
	da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = ['بدون ترجمة يوتيوب'],['']
	try:
		JSpKC1jiTcGq0e = BkEHpgzhWFOR85['captions']['playerCaptionsTracklistRenderer']['captionTracks']
		for rkLsmNSIYE in JSpKC1jiTcGq0e:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = rkLsmNSIYE['baseUrl']
			try: title = rkLsmNSIYE['name']['simpleText']
			except: title = rkLsmNSIYE['name']['runs'][0]['textt']
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			da6IAnqQ7oV2Hx13F5gbBT4.append(title)
	except: pass
	if len(da6IAnqQ7oV2Hx13F5gbBT4)>1:
		NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql('اختر الترجمة المناسبة:', da6IAnqQ7oV2Hx13F5gbBT4)
		if NljOosKT8WJBpch==-1: return 'EXIT_RESOLVER',[],[]
		elif NljOosKT8WJBpch!=0:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = jVMHRouKgQFAESmd7B8ObTYy[NljOosKT8WJBpch]+'&'
			POAfw57exYTsmQW = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('&(fmt=.*?)&',ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			if POAfw57exYTsmQW: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.replace(POAfw57exYTsmQW[0],'fmt=vtt')
			else: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'fmt=vtt'
			lijgqJd5Bw1RZCVnuhf60m = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.strip('&')
	zvClxLUqwSOneQ5cuYZ,c41VKjRQzZ,aaHCj0tmUJEKRNngDfeu5zTrvL,xxQgwz6OyafIHs5D,kkxIzCsi3Oyajd = [],[],[],[],[]
	try: UPiFr6agVf9sCuzq5T = BkEHpgzhWFOR85['streamingData']['dashManifestUrl']
	except: pass
	try: IdJtKTqbio0O3Hl5uULRha = BkEHpgzhWFOR85['streamingData']['hlsManifestUrl']
	except: pass
	try: zvClxLUqwSOneQ5cuYZ = BkEHpgzhWFOR85['streamingData']['formats']
	except: pass
	try: c41VKjRQzZ = BkEHpgzhWFOR85['streamingData']['adaptiveFormats']
	except: pass
	WW4XJUeq8MkpELOSyg1Hd2oCFs = zvClxLUqwSOneQ5cuYZ+c41VKjRQzZ
	for dict in WW4XJUeq8MkpELOSyg1Hd2oCFs:
		if 'itag' in list(dict.keys()): dict['itag'] = str(dict['itag'])
		if 'fps' in list(dict.keys()): dict['fps'] = str(dict['fps'])
		if 'mimeType' in list(dict.keys()): dict['type'] = dict['mimeType']
		if 'audioSampleRate' in list(dict.keys()): dict['audio_sample_rate'] = str(dict['audioSampleRate'])
		if 'audioChannels' in list(dict.keys()): dict['audio_channels'] = str(dict['audioChannels'])
		if 'width' in list(dict.keys()): dict['size'] = str(dict['width'])+'x'+str(dict['height'])
		if 'initRange' in list(dict.keys()): dict['init'] = dict['initRange']['start']+'-'+dict['initRange']['end']
		if 'indexRange' in list(dict.keys()): dict['index'] = dict['indexRange']['start']+'-'+dict['indexRange']['end']
		if 'averageBitrate' in list(dict.keys()): dict['bitrate'] = dict['averageBitrate']
		if 'bitrate' in list(dict.keys()) and int(dict['bitrate'])>111222333: del dict['bitrate']
		if 'signatureCipher' in list(dict.keys()):
			MMkbIyDnxYagjz = dict['signatureCipher'].split('&')
			for hh4gUqS5JWf1saRZPXHD in MMkbIyDnxYagjz:
				key,hht0cpXxWw2OzFS1jnUGebkJLBd85 = hh4gUqS5JWf1saRZPXHD.split('=',1)
				dict[key] = BUTSkzgFC7(hht0cpXxWw2OzFS1jnUGebkJLBd85)
		if 'url' in list(dict.keys()): dict['url'] = BUTSkzgFC7(dict['url'])
		aaHCj0tmUJEKRNngDfeu5zTrvL.append(dict)
	YzeBcXMa6TqZAuK = ''
	if 'sp=sig' in GrSazPw083KDJY6c7Hvt5NEqkhWQuV:
		aNKToLFXt4JPGQqgWlcpHu6 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('src="(/s/player/\w*?/player_ias.vflset/en_../base.js)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if aNKToLFXt4JPGQqgWlcpHu6:
			aNKToLFXt4JPGQqgWlcpHu6 = mR20sONyKIlV['YOUTUBE'][0]+aNKToLFXt4JPGQqgWlcpHu6[0]
			aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,'GET',aNKToLFXt4JPGQqgWlcpHu6,'','','','','RESOLVERS-YOUTUBE-2nd')
			YzeBcXMa6TqZAuK = aQniqUlZk8.content
			import youtube_signature.cipher as Fp6MJ4HjXd1A8rwPnmaeiTb,youtube_signature.json_script_engine as wqpNJSh9ICje1
			MMkbIyDnxYagjz = lNEy18wkxAdtDavRmHubUF.MMkbIyDnxYagjz.Cipher()
			MMkbIyDnxYagjz._object_cache = {}
			ubvUmQTpg7GdisHNZ4tRwWx2 = MMkbIyDnxYagjz._load_javascript(YzeBcXMa6TqZAuK)
			rWb1TSG3NnR7BaumXMYQi2J = GVQAnvYCT3dS('str',str(ubvUmQTpg7GdisHNZ4tRwWx2))
			sKP1RCqtvnLIcubUeQ3VT0g = lNEy18wkxAdtDavRmHubUF.KgCDVwtNEHcxAQ.JsonScriptEngine(rWb1TSG3NnR7BaumXMYQi2J)
	for dict in aaHCj0tmUJEKRNngDfeu5zTrvL:
		url = dict['url']
		if 'signature=' in url or url.count('sig=')>1:
			xxQgwz6OyafIHs5D.append(dict)
		elif YzeBcXMa6TqZAuK and 's' in list(dict.keys()) and 'sp' in list(dict.keys()):
			vPxMUXhIqGbVm20prBy = sKP1RCqtvnLIcubUeQ3VT0g.execute(dict['s'])
			if vPxMUXhIqGbVm20prBy!=dict['s']:
				dict['url'] = url+'&'+dict['sp']+'='+vPxMUXhIqGbVm20prBy
				xxQgwz6OyafIHs5D.append(dict)
	for dict in xxQgwz6OyafIHs5D:
		dmSj9bwK7C0E,F7XM3ApGwIxs5Tt6LaUDkEZcmdQu,cGIlZs0QrovdzfmXLO,dZqIj4QB0DYuk6M,M4HknWQhl0XvSrwN3z5t6LVFpa2g,rqY7pLRMaPTsxV3eCtlIo1A4 = 'unknown','unknown','unknown','Unknown','','0'
		try:
			kKsmtwybe6LEAHp35 = dict['type']
			kKsmtwybe6LEAHp35 = kKsmtwybe6LEAHp35.replace('+','')
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(.*?)/(.*?);.*?"(.*?)"',kKsmtwybe6LEAHp35,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			dZqIj4QB0DYuk6M,dmSj9bwK7C0E,M4HknWQhl0XvSrwN3z5t6LVFpa2g = items[0]
			LAPVIRJfhZXlFun4w = M4HknWQhl0XvSrwN3z5t6LVFpa2g.split(',')
			F7XM3ApGwIxs5Tt6LaUDkEZcmdQu = ''
			for hh4gUqS5JWf1saRZPXHD in LAPVIRJfhZXlFun4w: F7XM3ApGwIxs5Tt6LaUDkEZcmdQu += hh4gUqS5JWf1saRZPXHD.split('.')[0]+','
			F7XM3ApGwIxs5Tt6LaUDkEZcmdQu = F7XM3ApGwIxs5Tt6LaUDkEZcmdQu.strip(',')
			if 'bitrate' in list(dict.keys()): rqY7pLRMaPTsxV3eCtlIo1A4 = str(float(dict['bitrate']*10)//1024/10)+'kbps  '
			else: rqY7pLRMaPTsxV3eCtlIo1A4 = ''
			if dZqIj4QB0DYuk6M=='textt': continue
			elif ',' in kKsmtwybe6LEAHp35:
				dZqIj4QB0DYuk6M = 'A+V'
				cGIlZs0QrovdzfmXLO = dmSj9bwK7C0E+'  '+rqY7pLRMaPTsxV3eCtlIo1A4+dict['size'].split('x')[1]
			elif dZqIj4QB0DYuk6M=='video':
				dZqIj4QB0DYuk6M = 'Video'
				cGIlZs0QrovdzfmXLO = rqY7pLRMaPTsxV3eCtlIo1A4+dict['size'].split('x')[1]+'  '+dict['fps']+'fps'+'  '+dmSj9bwK7C0E
			elif dZqIj4QB0DYuk6M=='audio':
				dZqIj4QB0DYuk6M = 'Audio'
				cGIlZs0QrovdzfmXLO = rqY7pLRMaPTsxV3eCtlIo1A4+str(int(dict['audio_sample_rate'])/1000)+'khz  '+dict['audio_channels']+'ch'+'  '+dmSj9bwK7C0E
		except:
			jbDMGZeVf2RyJ8OxFA94Emu3pgo0St = oo5q9yuEdbCeOSxfzJcw.format_exc()
			if jbDMGZeVf2RyJ8OxFA94Emu3pgo0St!='NoneType: None\n': EAPND6zHKrMRuBc91tInYohsl0ywa.stderr.write(jbDMGZeVf2RyJ8OxFA94Emu3pgo0St)
		if 'dur=' in dict['url']: s6z12JQXUyK5Wn4Bf7LYiDIP9F = round(0.5+float(dict['url'].split('dur=',1)[1].split('&',1)[0]))
		elif 'approxDurationMs' in list(dict.keys()): s6z12JQXUyK5Wn4Bf7LYiDIP9F = round(0.5+float(dict['approxDurationMs'])/1000)
		else: s6z12JQXUyK5Wn4Bf7LYiDIP9F = '0'
		if 'bitrate' not in list(dict.keys()): rqY7pLRMaPTsxV3eCtlIo1A4 = dict['size'].split('x')[1]
		else: rqY7pLRMaPTsxV3eCtlIo1A4 = dict['bitrate']
		if 'init' not in list(dict.keys()): dict['init'] = '0-0'
		dict['title'] = dZqIj4QB0DYuk6M+':  '+cGIlZs0QrovdzfmXLO+'  ('+F7XM3ApGwIxs5Tt6LaUDkEZcmdQu+','+dict['itag']+')'
		dict['quality'] = cGIlZs0QrovdzfmXLO.split('  ')[0].split('kbps')[0]
		dict['type2'] = dZqIj4QB0DYuk6M
		dict['filetype'] = dmSj9bwK7C0E
		dict['codecs'] = M4HknWQhl0XvSrwN3z5t6LVFpa2g
		dict['duration'] = s6z12JQXUyK5Wn4Bf7LYiDIP9F
		dict['bitrate'] = rqY7pLRMaPTsxV3eCtlIo1A4
		kkxIzCsi3Oyajd.append(dict)
	lxv6wyU9gnPJehC,H7kCJP0pLOqQuKTUZdwBirx9aEjb,QOGaTyhjA4td0KoRkrliBn,KcD4FmjHPzv6qWt,MOB1aZpod7R5QzWDh9F42gvrlIY = [],[],[],[],[]
	FFLHA7EsKok2aIZ0wQhDlPTBW,KfTu8glZRSiMsxHIk3mV5J0CtE,m0w1iXeJYApoxtOzWVFZnDgTS37l,whrFqGTIEQ2f1gu3LZJ,VrPoxT7G1ikcfalSnNK = [],[],[],[],[]
	if UPiFr6agVf9sCuzq5T:
		dict = {}
		dict['type2'] = 'A+V'
		dict['filetype'] = 'mpd'
		dict['title'] = dict['type2']+':  '+dict['filetype']+'  '+'جودة ذكية'
		dict['url'] = UPiFr6agVf9sCuzq5T
		dict['quality'] = '0'
		dict['bitrate'] = '9876543210'
		kkxIzCsi3Oyajd.append(dict)
	if IdJtKTqbio0O3Hl5uULRha:
		IkZgaJ0Nxep5T,Si5NesyOAp = nPVJZWtkEb27UQ9AK(IdJtKTqbio0O3Hl5uULRha)
		NCVS5Fb3QaX42Mc = list(zip(IkZgaJ0Nxep5T,Si5NesyOAp))
		for title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R in NCVS5Fb3QaX42Mc:
			dict = {}
			dict['type2'] = 'A+V'
			dict['filetype'] = 'm3u8'
			dict['url'] = ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			if 'kbps' in title: dict['bitrate'] = title.split('kbps')[0].rsplit('  ')[-1]
			else: dict['bitrate'] = '10'
			if title.count('  ')>1:
				LjG8y1rb9AgJF2I3i64ZDtCXMa7n = title.rsplit('  ')[-3]
				if LjG8y1rb9AgJF2I3i64ZDtCXMa7n.isdigit(): dict['quality'] = LjG8y1rb9AgJF2I3i64ZDtCXMa7n
				else: dict['quality'] = '0000'
			if title=='-1': dict['title'] = dict['type2']+':  '+dict['filetype']+'  '+'جودة ذكية'
			else: dict['title'] = dict['type2']+':  '+dict['filetype']+'  '+dict['bitrate']+'kbps  '+dict['quality']
			kkxIzCsi3Oyajd.append(dict)
	kkxIzCsi3Oyajd = sorted(kkxIzCsi3Oyajd,reverse=True,key=lambda key: float(key['bitrate']))
	if not kkxIzCsi3Oyajd:
		hwAK5bC7pHoU6VrSdgsvM = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="messagee">(.*?)<',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		cE6OHoADvlhK1gVy2p8rYbWXFmGQ = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"playerErrorMessageRenderer":\{"subreason":\{"runs":\[\{"textt":"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		YOTH54N3yLc9K = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"playerErrorMessageRenderer":\{"reason":{"simpleText":"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		fjvEc6Ayo9UrIXKJLzaBPR12eM = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"playerErrorMessageRenderer":\{"subreason":{"simpleText":"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		try: oofZ02IPyDQ75BFJhRmLpat1eWrOES = BkEHpgzhWFOR85['playabilityStatus']['errorScreen']['confirmDialogRenderer']['title']['runs'][0]['textt']
		except: oofZ02IPyDQ75BFJhRmLpat1eWrOES = ''
		try: yHPU2IF1GkCDbX3vQ75NVnmWAlic = BkEHpgzhWFOR85['playabilityStatus']['errorScreen']['confirmDialogRenderer']['dialogMessages'][0]['runs'][0]['textt']
		except: yHPU2IF1GkCDbX3vQ75NVnmWAlic = ''
		try: LknMrbyesz0SWxgEGpqhdu3cTQiBK = BkEHpgzhWFOR85['playabilityStatus']['reason']
		except: LknMrbyesz0SWxgEGpqhdu3cTQiBK = ''
		if hwAK5bC7pHoU6VrSdgsvM or cE6OHoADvlhK1gVy2p8rYbWXFmGQ or YOTH54N3yLc9K or fjvEc6Ayo9UrIXKJLzaBPR12eM or oofZ02IPyDQ75BFJhRmLpat1eWrOES or yHPU2IF1GkCDbX3vQ75NVnmWAlic or LknMrbyesz0SWxgEGpqhdu3cTQiBK:
			if   hwAK5bC7pHoU6VrSdgsvM: maCNIYkc0HOiEGpL3g = hwAK5bC7pHoU6VrSdgsvM[0]
			elif cE6OHoADvlhK1gVy2p8rYbWXFmGQ: maCNIYkc0HOiEGpL3g = cE6OHoADvlhK1gVy2p8rYbWXFmGQ[0]
			elif YOTH54N3yLc9K: maCNIYkc0HOiEGpL3g = YOTH54N3yLc9K[0]
			elif fjvEc6Ayo9UrIXKJLzaBPR12eM: maCNIYkc0HOiEGpL3g = fjvEc6Ayo9UrIXKJLzaBPR12eM[0]
			elif oofZ02IPyDQ75BFJhRmLpat1eWrOES: maCNIYkc0HOiEGpL3g = oofZ02IPyDQ75BFJhRmLpat1eWrOES
			elif yHPU2IF1GkCDbX3vQ75NVnmWAlic: maCNIYkc0HOiEGpL3g = yHPU2IF1GkCDbX3vQ75NVnmWAlic
			elif LknMrbyesz0SWxgEGpqhdu3cTQiBK: maCNIYkc0HOiEGpL3g = LknMrbyesz0SWxgEGpqhdu3cTQiBK
			LFMn0xPXcVwzZJk97vHWs8bCe = maCNIYkc0HOiEGpL3g.replace('\n','').strip(' ')
			YT7l0MAtcfEjRC9ZyIDBLX8NsJqe = '[COLOR FFC89008]هذا الفيديو فيه مشكلة وقد يكون غير ملائم لبعض المستخدمين أو غير متوفر الآن[/COLOR]'
			tehb3k5a2PufGOdBIUw8j('','','رسالة من الموقع والمبرمج',YT7l0MAtcfEjRC9ZyIDBLX8NsJqe+'\n\n'+LFMn0xPXcVwzZJk97vHWs8bCe)
			return 'Error    : Resolver YOUTUBE Failed: '+LFMn0xPXcVwzZJk97vHWs8bCe,[],[]
		else: return 'Error    : Resolver YOUTUBE Failed',[],[]
	cdGQ8i1vbzaX5FhM3kmPCpI6f9,OIFiAhwElj4dv,rmnfKUwi4FCIktPpWcho2S8JXMqye3 = [],[],[]
	for dict in kkxIzCsi3Oyajd:
		if dict['type2']=='Video':
			lxv6wyU9gnPJehC.append(dict['title'])
			FFLHA7EsKok2aIZ0wQhDlPTBW.append(dict)
		elif dict['type2']=='Audio':
			H7kCJP0pLOqQuKTUZdwBirx9aEjb.append(dict['title'])
			KfTu8glZRSiMsxHIk3mV5J0CtE.append(dict)
		elif dict['filetype']=='mpd':
			title = dict['title'].replace('A+V:  ','')
			if 'bitrate' not in list(dict.keys()): rqY7pLRMaPTsxV3eCtlIo1A4 = '0'
			else: rqY7pLRMaPTsxV3eCtlIo1A4 = dict['bitrate']
			cdGQ8i1vbzaX5FhM3kmPCpI6f9.append([dict,{},title,rqY7pLRMaPTsxV3eCtlIo1A4])
		else:
			title = dict['title'].replace('A+V:  ','')
			if 'bitrate' not in list(dict.keys()): rqY7pLRMaPTsxV3eCtlIo1A4 = '0'
			else: rqY7pLRMaPTsxV3eCtlIo1A4 = dict['bitrate']
			cdGQ8i1vbzaX5FhM3kmPCpI6f9.append([dict,{},title,rqY7pLRMaPTsxV3eCtlIo1A4])
			QOGaTyhjA4td0KoRkrliBn.append(title)
			m0w1iXeJYApoxtOzWVFZnDgTS37l.append(dict)
		fxvA2R1PC897nZo4jg5kTbXDl = True
		if 'codecs' in list(dict.keys()):
			if 'av0' in dict['codecs']: fxvA2R1PC897nZo4jg5kTbXDl = False
			elif wH3qxmuXBTeak<18:
				if 'avc' not in dict['codecs'] and 'mp4a' not in dict['codecs']: fxvA2R1PC897nZo4jg5kTbXDl = False
		if dict['type2']=='Video' and dict['init']!='0-0' and fxvA2R1PC897nZo4jg5kTbXDl==True:
			MOB1aZpod7R5QzWDh9F42gvrlIY.append(dict['title'])
			VrPoxT7G1ikcfalSnNK.append(dict)
		elif dict['type2']=='Audio' and dict['init']!='0-0' and fxvA2R1PC897nZo4jg5kTbXDl==True:
			KcD4FmjHPzv6qWt.append(dict['title'])
			whrFqGTIEQ2f1gu3LZJ.append(dict)
	for FNE4PBQ5XbHO7r1xGVhwYu in whrFqGTIEQ2f1gu3LZJ:
		jaDhORboIryE6Ume = FNE4PBQ5XbHO7r1xGVhwYu['bitrate']
		for GbwkUqRuoTE29iAC in VrPoxT7G1ikcfalSnNK:
			b9sP1rCGhzIqgU4WYwtDX8Re = GbwkUqRuoTE29iAC['bitrate']
			rqY7pLRMaPTsxV3eCtlIo1A4 = b9sP1rCGhzIqgU4WYwtDX8Re+jaDhORboIryE6Ume
			title = GbwkUqRuoTE29iAC['title'].replace('Video:  ','mpd  ')
			title = title.replace(GbwkUqRuoTE29iAC['filetype']+'  ','')
			title = title.replace(str((float(b9sP1rCGhzIqgU4WYwtDX8Re*10)//1024/10))+'kbps',str((float(rqY7pLRMaPTsxV3eCtlIo1A4*10)//1024/10))+'kbps')
			title = title+'('+FNE4PBQ5XbHO7r1xGVhwYu['title'].split('(',1)[1]
			cdGQ8i1vbzaX5FhM3kmPCpI6f9.append([GbwkUqRuoTE29iAC,FNE4PBQ5XbHO7r1xGVhwYu,title,rqY7pLRMaPTsxV3eCtlIo1A4])
	cdGQ8i1vbzaX5FhM3kmPCpI6f9 = sorted(cdGQ8i1vbzaX5FhM3kmPCpI6f9, reverse=True, key=lambda key: float(key[3]))
	for GbwkUqRuoTE29iAC,FNE4PBQ5XbHO7r1xGVhwYu,title,rqY7pLRMaPTsxV3eCtlIo1A4 in cdGQ8i1vbzaX5FhM3kmPCpI6f9:
		OuG9Qqhg6FSBDZKMp3tRWzsdo2 = GbwkUqRuoTE29iAC['filetype']
		if 'filetype' in list(FNE4PBQ5XbHO7r1xGVhwYu.keys()):
			OuG9Qqhg6FSBDZKMp3tRWzsdo2 = 'mpd'
		if OuG9Qqhg6FSBDZKMp3tRWzsdo2 not in rmnfKUwi4FCIktPpWcho2S8JXMqye3:
			rmnfKUwi4FCIktPpWcho2S8JXMqye3.append(OuG9Qqhg6FSBDZKMp3tRWzsdo2)
			OIFiAhwElj4dv.append([GbwkUqRuoTE29iAC,FNE4PBQ5XbHO7r1xGVhwYu,title,rqY7pLRMaPTsxV3eCtlIo1A4])
	fXs1g8eSIv,RXDrxPA3dunahbEH,sIzuT6p3XHf = [],[],0
	TOFR3imN6oEGdAH4sQhez27pqrg,Wuf4aHT5IXgPNhxpco7veFiLq = '',''
	try: TOFR3imN6oEGdAH4sQhez27pqrg = BkEHpgzhWFOR85['videoDetails']['author']
	except: TOFR3imN6oEGdAH4sQhez27pqrg = ''
	try: UQefNgZouIycPrlLKOn42d = BkEHpgzhWFOR85['videoDetails']['channelId']
	except: UQefNgZouIycPrlLKOn42d = ''
	if TOFR3imN6oEGdAH4sQhez27pqrg and UQefNgZouIycPrlLKOn42d:
		sIzuT6p3XHf += 1
		title = '[COLOR FFC89008]OWNER:  '+TOFR3imN6oEGdAH4sQhez27pqrg+'[/COLOR]'
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = mR20sONyKIlV['YOUTUBE'][0]+'/channel/'+UQefNgZouIycPrlLKOn42d
		fXs1g8eSIv.append(title)
		RXDrxPA3dunahbEH.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
		try: Wuf4aHT5IXgPNhxpco7veFiLq = BkEHpgzhWFOR85['videoDetails']['thumbnail']['thumbnails'][-1]['url']
		except: pass
	for GbwkUqRuoTE29iAC,FNE4PBQ5XbHO7r1xGVhwYu,title,rqY7pLRMaPTsxV3eCtlIo1A4 in OIFiAhwElj4dv:
		fXs1g8eSIv.append(title) ; RXDrxPA3dunahbEH.append('highest')
	if QOGaTyhjA4td0KoRkrliBn: fXs1g8eSIv.append('صورة وصوت محددة') ; RXDrxPA3dunahbEH.append('muxed')
	if cdGQ8i1vbzaX5FhM3kmPCpI6f9: fXs1g8eSIv.append('صورة وصوت المتوفر') ; RXDrxPA3dunahbEH.append('all')
	if MOB1aZpod7R5QzWDh9F42gvrlIY: fXs1g8eSIv.append('mpd اختر الصورة والصوت') ; RXDrxPA3dunahbEH.append('mpd')
	if lxv6wyU9gnPJehC: fXs1g8eSIv.append('صورة بدون صوت') ; RXDrxPA3dunahbEH.append('video')
	if H7kCJP0pLOqQuKTUZdwBirx9aEjb: fXs1g8eSIv.append('صوت بدون صورة') ; RXDrxPA3dunahbEH.append('audio')
	eSN5p0RFokEKuLV6sTHWYfib = False
	while True:
		NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql(vU3B8rIj4Yp, fXs1g8eSIv)
		if NljOosKT8WJBpch==-1: return 'EXIT_RESOLVER',[],[]
		elif NljOosKT8WJBpch==0 and TOFR3imN6oEGdAH4sQhez27pqrg:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = RXDrxPA3dunahbEH[NljOosKT8WJBpch]
			Pukd6EFcXBNfYW = EAPND6zHKrMRuBc91tInYohsl0ywa.argv[0]+'?type=folder&mode=141&name='+TaEr2nR3f5e8oXzpy(TOFR3imN6oEGdAH4sQhez27pqrg)+'&url='+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			if Wuf4aHT5IXgPNhxpco7veFiLq: Pukd6EFcXBNfYW = Pukd6EFcXBNfYW+'&image='+TaEr2nR3f5e8oXzpy(Wuf4aHT5IXgPNhxpco7veFiLq)
			oos8ymFi9CN2z1jXcR.executebuiltin("Container.Update("+Pukd6EFcXBNfYW+")")
			return 'EXIT_RESOLVER',[],[]
		A4rSxVHK9Dfieob8B7 = RXDrxPA3dunahbEH[NljOosKT8WJBpch]
		sISLJyVeRiGCxKqtXlPf = fXs1g8eSIv[NljOosKT8WJBpch]
		if A4rSxVHK9Dfieob8B7=='dash':
			QTad2JygBrUEulNCsmznbOh = UPiFr6agVf9sCuzq5T
			break
		elif A4rSxVHK9Dfieob8B7 in ['audio','video','muxed']:
			if A4rSxVHK9Dfieob8B7=='muxed': da6IAnqQ7oV2Hx13F5gbBT4,hvo0UCNezF2ZtuLjGxX79fS = QOGaTyhjA4td0KoRkrliBn,m0w1iXeJYApoxtOzWVFZnDgTS37l
			elif A4rSxVHK9Dfieob8B7=='video': da6IAnqQ7oV2Hx13F5gbBT4,hvo0UCNezF2ZtuLjGxX79fS = lxv6wyU9gnPJehC,FFLHA7EsKok2aIZ0wQhDlPTBW
			elif A4rSxVHK9Dfieob8B7=='audio': da6IAnqQ7oV2Hx13F5gbBT4,hvo0UCNezF2ZtuLjGxX79fS = H7kCJP0pLOqQuKTUZdwBirx9aEjb,KfTu8glZRSiMsxHIk3mV5J0CtE
			NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql('اختر الملف المناسب:', da6IAnqQ7oV2Hx13F5gbBT4)
			if NljOosKT8WJBpch!=-1:
				QTad2JygBrUEulNCsmznbOh = hvo0UCNezF2ZtuLjGxX79fS[NljOosKT8WJBpch]['url']
				sISLJyVeRiGCxKqtXlPf = da6IAnqQ7oV2Hx13F5gbBT4[NljOosKT8WJBpch]
				break
		elif A4rSxVHK9Dfieob8B7=='mpd':
			NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql('اختر جودة الصورة:', MOB1aZpod7R5QzWDh9F42gvrlIY)
			if NljOosKT8WJBpch!=-1:
				sISLJyVeRiGCxKqtXlPf = MOB1aZpod7R5QzWDh9F42gvrlIY[NljOosKT8WJBpch]
				DUHFV27Pgi = VrPoxT7G1ikcfalSnNK[NljOosKT8WJBpch]
				NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql('اختر جودة الصوت:', KcD4FmjHPzv6qWt)
				if NljOosKT8WJBpch!=-1:
					sISLJyVeRiGCxKqtXlPf += ' + '+KcD4FmjHPzv6qWt[NljOosKT8WJBpch]
					bZ9mhpglQLt = whrFqGTIEQ2f1gu3LZJ[NljOosKT8WJBpch]
					eSN5p0RFokEKuLV6sTHWYfib = True
					break
		elif A4rSxVHK9Dfieob8B7=='all':
			P5GZUk4nSjQwi,QQtmRW2pJNdBx,rXn4W7YdjphvJIGONlCQ,WVdIjibywZ28 = list(zip(*cdGQ8i1vbzaX5FhM3kmPCpI6f9))
			NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql('اختر الملف المناسب:', rXn4W7YdjphvJIGONlCQ)
			if NljOosKT8WJBpch!=-1:
				sISLJyVeRiGCxKqtXlPf = rXn4W7YdjphvJIGONlCQ[NljOosKT8WJBpch]
				DUHFV27Pgi = P5GZUk4nSjQwi[NljOosKT8WJBpch]
				if 'mpd' in rXn4W7YdjphvJIGONlCQ[NljOosKT8WJBpch] and DUHFV27Pgi['url']!=UPiFr6agVf9sCuzq5T:
					bZ9mhpglQLt = QQtmRW2pJNdBx[NljOosKT8WJBpch]
					eSN5p0RFokEKuLV6sTHWYfib = True
				else: QTad2JygBrUEulNCsmznbOh = DUHFV27Pgi['url']
				break
		elif A4rSxVHK9Dfieob8B7=='highest':
			P5GZUk4nSjQwi,QQtmRW2pJNdBx,rXn4W7YdjphvJIGONlCQ,WVdIjibywZ28 = list(zip(*OIFiAhwElj4dv))
			DUHFV27Pgi = P5GZUk4nSjQwi[NljOosKT8WJBpch-sIzuT6p3XHf]
			if 'mpd' in rXn4W7YdjphvJIGONlCQ[NljOosKT8WJBpch-sIzuT6p3XHf] and DUHFV27Pgi['url']!=UPiFr6agVf9sCuzq5T:
				bZ9mhpglQLt = QQtmRW2pJNdBx[NljOosKT8WJBpch-sIzuT6p3XHf]
				eSN5p0RFokEKuLV6sTHWYfib = True
			else: QTad2JygBrUEulNCsmznbOh = DUHFV27Pgi['url']
			sISLJyVeRiGCxKqtXlPf = rXn4W7YdjphvJIGONlCQ[NljOosKT8WJBpch-sIzuT6p3XHf]
			break
	if not eSN5p0RFokEKuLV6sTHWYfib: UChgeXHc9KEpIS2b3Y = QTad2JygBrUEulNCsmznbOh
	else: UChgeXHc9KEpIS2b3Y = 'Video: '+DUHFV27Pgi['url']+' + Audio: '+bZ9mhpglQLt['url']
	if eSN5p0RFokEKuLV6sTHWYfib:
		vBJRq5Dst3Tf = int(DUHFV27Pgi['duration'])
		FoGtlyed9nZ4AfKjq5S1xsUE8OmVT = int(bZ9mhpglQLt['duration'])
		s6z12JQXUyK5Wn4Bf7LYiDIP9F = str(max(vBJRq5Dst3Tf,FoGtlyed9nZ4AfKjq5S1xsUE8OmVT))
		r4VX0QjPTe3xOH = DUHFV27Pgi['url'].replace('&','&amp;')
		OmNE3KIAfFR8gbdkutvcSW4hQ27H = bZ9mhpglQLt['url'].replace('&','&amp;')
		mpd = '<?xml version="1.0" encoding="UTF-8"?>\n'
		mpd += '<MPD xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="urn:mpeg:dash:schema:mpd:2011" xmlns:xlink="http://www.w3.org/1999/xlink" xsi:schemaLocation="urn:mpeg:dash:schema:mpd:2011 http://standards.iso.org/ittf/PubliclyAvailableStandards/MPEG-DASH_schema_files/DASH-MPD.xsd" minBufferTime="PT1.5S" mediaPresentationDuration="PT'+s6z12JQXUyK5Wn4Bf7LYiDIP9F+'S" type="static" profiles="urn:mpeg:dash:profile:isoff-main:2011">\n'
		mpd += '<Period>\n'
		mpd += '<AdaptationSet id="0" mimeType="video/'+DUHFV27Pgi['filetype']+'" subsegmentAlignment="true">\n'
		mpd += '<Role schemeIdUri="urn:mpeg:DASH:role:2011" value="main"/>\n'
		mpd += '<Representation id="'+DUHFV27Pgi['itag']+'" codecs="'+DUHFV27Pgi['codecs']+'" startWithSAP="1" bandwidth="'+str(DUHFV27Pgi['bitrate'])+'" width="'+str(DUHFV27Pgi['width'])+'" height="'+str(DUHFV27Pgi['height'])+'" frameRate="'+DUHFV27Pgi['fps']+'">\n'
		mpd += '<BaseURL>'+r4VX0QjPTe3xOH+'</BaseURL>\n'
		mpd += '<SegmentBase indexRange="'+DUHFV27Pgi['index']+'">\n'
		mpd += '<Initialization range="'+DUHFV27Pgi['init']+'" />\n'
		mpd += '</SegmentBase>\n'
		mpd += '</Representation>\n'
		mpd += '</AdaptationSet>\n'
		mpd += '<AdaptationSet id="1" mimeType="audio/'+bZ9mhpglQLt['filetype']+'" subsegmentAlignment="true">\n'
		mpd += '<Role schemeIdUri="urn:mpeg:DASH:role:2011" value="main"/>\n'
		mpd += '<Representation id="'+bZ9mhpglQLt['itag']+'" codecs="'+bZ9mhpglQLt['codecs']+'" bandwidth="130475">\n'
		mpd += '<AudioChannelConfiguration schemeIdUri="urn:mpeg:dash:23003:3:audio_channel_configuration:2011" value="'+bZ9mhpglQLt['audio_channels']+'"/>\n'
		mpd += '<BaseURL>'+OmNE3KIAfFR8gbdkutvcSW4hQ27H+'</BaseURL>\n'
		mpd += '<SegmentBase indexRange="'+bZ9mhpglQLt['index']+'">\n'
		mpd += '<Initialization range="'+bZ9mhpglQLt['init']+'" />\n'
		mpd += '</SegmentBase>\n'
		mpd += '</Representation>\n'
		mpd += '</AdaptationSet>\n'
		mpd += '</Period>\n'
		mpd += '</MPD>\n'
		if wvkR1es6d0SrjxKt5FZTMUWz7a:
			import http.server as Q3QpUFifo1zDSCAseE
			import http.client as uu2TSn6AvbGg59IKOWVx7XcYCeNt
		else:
			import BaseHTTPServer as Q3QpUFifo1zDSCAseE
			import httplib as uu2TSn6AvbGg59IKOWVx7XcYCeNt
		class g4lC8xZHTuy(Q3QpUFifo1zDSCAseE.HTTPServer):
			def __init__(G9kpoeR7yazZx3AUn0m,ip='localhost',port=55055,mpd='<>'):
				G9kpoeR7yazZx3AUn0m.ip = ip
				G9kpoeR7yazZx3AUn0m.port = port
				G9kpoeR7yazZx3AUn0m.mpd = mpd
				Q3QpUFifo1zDSCAseE.HTTPServer.__init__(G9kpoeR7yazZx3AUn0m,(G9kpoeR7yazZx3AUn0m.ip,G9kpoeR7yazZx3AUn0m.port),VcUWj7v5TxROSpI9k3)
				G9kpoeR7yazZx3AUn0m.mpdurl = 'http://'+ip+':'+str(port)+'/youtube.mpd'
			def start(G9kpoeR7yazZx3AUn0m):
				G9kpoeR7yazZx3AUn0m.threads = MrpuQ4b0AfZ6scLH(False)
				G9kpoeR7yazZx3AUn0m.threads.RLX07K6brEf(1,G9kpoeR7yazZx3AUn0m.L8WNImZd1p7EHq9aG)
			def L8WNImZd1p7EHq9aG(G9kpoeR7yazZx3AUn0m):
				G9kpoeR7yazZx3AUn0m.keeprunning = True
				while G9kpoeR7yazZx3AUn0m.keeprunning:
					G9kpoeR7yazZx3AUn0m.handle_request()
			def stop(G9kpoeR7yazZx3AUn0m):
				G9kpoeR7yazZx3AUn0m.keeprunning = False
				G9kpoeR7yazZx3AUn0m.i9ikV41mBsO6S5z2IFEJ3l()
			def fHnbV7hqylwp0xLrZCe8D9AT(G9kpoeR7yazZx3AUn0m):
				G9kpoeR7yazZx3AUn0m.stop()
				G9kpoeR7yazZx3AUn0m.UnVKvhfHwd6pYx37Wk.close()
				G9kpoeR7yazZx3AUn0m.server_close()
			def RlkQaKni2ehxvBuEZjIWfwd6TH(G9kpoeR7yazZx3AUn0m,mpd):
				G9kpoeR7yazZx3AUn0m.mpd = mpd
			def i9ikV41mBsO6S5z2IFEJ3l(G9kpoeR7yazZx3AUn0m):
				md59xZUEq3IOnPp2 = uu2TSn6AvbGg59IKOWVx7XcYCeNt.HTTPConnection(G9kpoeR7yazZx3AUn0m.ip+':'+str(G9kpoeR7yazZx3AUn0m.port))
				md59xZUEq3IOnPp2.request("HEAD", "/")
		class VcUWj7v5TxROSpI9k3(Q3QpUFifo1zDSCAseE.BaseHTTPRequestHandler):
			def pcyJn21QzHESAtrG7dTPDgZ5q6foFe(G9kpoeR7yazZx3AUn0m):
				G9kpoeR7yazZx3AUn0m.send_response(200)
				G9kpoeR7yazZx3AUn0m.send_header('Content-type','textt/plain')
				G9kpoeR7yazZx3AUn0m.end_headers()
				G9kpoeR7yazZx3AUn0m.wfile.write(G9kpoeR7yazZx3AUn0m.vMSQsdJ0gCrh7ztnR96yDXqOYaj.mpd.encode('utf8'))
				w6vebiEZtpCjJcILP8Skx5rHn.sleep(1)
				if G9kpoeR7yazZx3AUn0m.path=='/youtube.mpd': G9kpoeR7yazZx3AUn0m.vMSQsdJ0gCrh7ztnR96yDXqOYaj.fHnbV7hqylwp0xLrZCe8D9AT()
				if G9kpoeR7yazZx3AUn0m.path=='/shutdown': G9kpoeR7yazZx3AUn0m.vMSQsdJ0gCrh7ztnR96yDXqOYaj.fHnbV7hqylwp0xLrZCe8D9AT()
			def eu0x7TiRyYB(G9kpoeR7yazZx3AUn0m):
				G9kpoeR7yazZx3AUn0m.send_response(200)
				G9kpoeR7yazZx3AUn0m.end_headers()
		uRpd9TteE6xkGvj2gyAmqlQoPKCXS = g4lC8xZHTuy('127.0.0.1',55055,mpd)
		QTad2JygBrUEulNCsmznbOh = uRpd9TteE6xkGvj2gyAmqlQoPKCXS.mpdurl
		uRpd9TteE6xkGvj2gyAmqlQoPKCXS.start()
	else: uRpd9TteE6xkGvj2gyAmqlQoPKCXS = ''
	if not QTad2JygBrUEulNCsmznbOh: return 'Error    : Resolver YOUTUBE Failed',[],[]
	return '',[''],[[QTad2JygBrUEulNCsmznbOh,lijgqJd5Bw1RZCVnuhf60m,uRpd9TteE6xkGvj2gyAmqlQoPKCXS]]
def JJSqngCYlXG2HwQiWRb(url):
	headers = { 'User-Agent' : '' }
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(jEPuRTVbZg4MCimJxzf3I6wFa,url,'',headers,'','RESOLVERS-VIDBOB-1st')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('file:"(.*?)"(,label:"(.*?)"|)\}',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	IkZgaJ0Nxep5T,da6IAnqQ7oV2Hx13F5gbBT4,Si5NesyOAp,jVMHRouKgQFAESmd7B8ObTYy = [],[],[],[]
	if not items: return 'Error: Resolver Failed VIDBOB',[],[]
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,aQ0kNq9gnYBKJ5yV6oRhXZ7ImfwreT,JNuHrgRwE8K0hcdMBtQl in items:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.replace('https:','http:')
		if '.m3u8' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
			IkZgaJ0Nxep5T,Si5NesyOAp = nPVJZWtkEb27UQ9AK(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			jVMHRouKgQFAESmd7B8ObTYy = jVMHRouKgQFAESmd7B8ObTYy + Si5NesyOAp
			if IkZgaJ0Nxep5T[0]=='-1': da6IAnqQ7oV2Hx13F5gbBT4.append('سيرفر خاص'+'   m3u8')
			else:
				for title in IkZgaJ0Nxep5T:
					da6IAnqQ7oV2Hx13F5gbBT4.append('سيرفر خاص'+'   '+title)
		else:
			title = 'سيرفر خاص'+'   mp4   '+JNuHrgRwE8K0hcdMBtQl
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			da6IAnqQ7oV2Hx13F5gbBT4.append(title)
	return '',da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
def Nw8sJDKHjdxQ90YOgIb(url,M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2):
	DSkd2Y0zhRKLG,zcBjFq4VQlp20ZekGO,c1cKB8ODC5iNom20GntXuW,fnB1sGSRlHaeu,cc0O1M4e5jtfoq = [],[],[],[],[]
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<video preload.*?src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<source src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('direct_link.*?href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]
		title = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.rsplit('.',1)[1]
		DSkd2Y0zhRKLG.append(title)
		zcBjFq4VQlp20ZekGO.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	else:
		cz4e6sNTj53E09xtaArJLKDg = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('sources: *(\[.*?\])',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if not cz4e6sNTj53E09xtaArJLKDg: cz4e6sNTj53E09xtaArJLKDg = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('var sources = (\{.*?\})',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if not cz4e6sNTj53E09xtaArJLKDg: cz4e6sNTj53E09xtaArJLKDg = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('var jw = (\{.*?\})',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if not cz4e6sNTj53E09xtaArJLKDg: cz4e6sNTj53E09xtaArJLKDg = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('var player = .*?\((\{.*?\})\)',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if cz4e6sNTj53E09xtaArJLKDg:
			cz4e6sNTj53E09xtaArJLKDg = cz4e6sNTj53E09xtaArJLKDg[0]
			eB4hZ9p6oX8scHAk = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('[,\{] *(\w+):',cz4e6sNTj53E09xtaArJLKDg,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for key in list(set(eB4hZ9p6oX8scHAk)): cz4e6sNTj53E09xtaArJLKDg = cz4e6sNTj53E09xtaArJLKDg.replace(key+':','"'+key+'":')
			cz4e6sNTj53E09xtaArJLKDg = eval(cz4e6sNTj53E09xtaArJLKDg)
			if isinstance(cz4e6sNTj53E09xtaArJLKDg,dict): cz4e6sNTj53E09xtaArJLKDg = [cz4e6sNTj53E09xtaArJLKDg]
			for ziJLDVT8NM2QcgIpmE9A in cz4e6sNTj53E09xtaArJLKDg:
				if isinstance(ziJLDVT8NM2QcgIpmE9A,dict):
					keys = list(ziJLDVT8NM2QcgIpmE9A.keys())
					if 'file' in keys: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ziJLDVT8NM2QcgIpmE9A['file']
					elif 'hls' in keys: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ziJLDVT8NM2QcgIpmE9A['hls']
					if 'label' in keys: title = str(ziJLDVT8NM2QcgIpmE9A['label'])
					elif 'video_height' in keys: title = str(ziJLDVT8NM2QcgIpmE9A['video_height'])
					else: title = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.rsplit('.',1)[1]
				elif isinstance(ziJLDVT8NM2QcgIpmE9A,str):
					ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ziJLDVT8NM2QcgIpmE9A
					title = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.rsplit('.',1)[1]
				DSkd2Y0zhRKLG.append(title)
				zcBjFq4VQlp20ZekGO.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in zip(zcBjFq4VQlp20ZekGO,DSkd2Y0zhRKLG):
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.replace('\\/','/')
		Etp7WHcwVuXo51k2KPLzMamIQySxfZ = SLMTm6RQ34ic7v5s9rBG(url,'url')
		PPGUinpWfm6Xw9NLtbcax53IQ = FY2qK6eHVBl4D0pEut8IgkTczyG()
		if '.m3u8' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
			headers = {'User-Agent':PPGUinpWfm6Xw9NLtbcax53IQ,'Referer':Etp7WHcwVuXo51k2KPLzMamIQySxfZ}
			HHnLo5rSZ9TudlOgQachjbPU,ltPWF7w1jMgaVO2Drcm9Gq4EUf = nPVJZWtkEb27UQ9AK(ZCimQhV5lovgspAYzHq1Ef27u8ja4R,headers)
			fnB1sGSRlHaeu += ltPWF7w1jMgaVO2Drcm9Gq4EUf
			c1cKB8ODC5iNom20GntXuW += HHnLo5rSZ9TudlOgQachjbPU
		else:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'|User-Agent='+PPGUinpWfm6Xw9NLtbcax53IQ+'&Referer='+Etp7WHcwVuXo51k2KPLzMamIQySxfZ
			fnB1sGSRlHaeu.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			c1cKB8ODC5iNom20GntXuW.append(title)
	d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,DSkd2Y0zhRKLG,zcBjFq4VQlp20ZekGO = '',[],[]
	if fnB1sGSRlHaeu: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,DSkd2Y0zhRKLG,zcBjFq4VQlp20ZekGO = '',c1cKB8ODC5iNom20GntXuW,fnB1sGSRlHaeu
	else:
		if '<' not in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 and len(M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2)<100 and M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5 = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
		else:
			msg = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<div style=".*?">(File.*?)<',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if not msg: msg = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<div class="vp_video_stub_txt">(.*?)<',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if not msg: msg = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<h2>(Sorry.*?)<',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if msg: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5 = msg[0]
	return d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,DSkd2Y0zhRKLG,zcBjFq4VQlp20ZekGO
def SKRIvgcJkYMTleb9wN7iFCHs(Q1KHi7xSWO,url):
	global WJqjptncmx6lhoKLOA8PIHBE4Qy75
	url = url.strip('/')
	OTdKGIE4Ms6hJjkFwoXyfrU,VVNkoRCUm96MbtuqgrOe = '',{}
	headers = {'User-Agent':FY2qK6eHVBl4D0pEut8IgkTczyG(),'Accept-Language':'en-US,en;q=0.9','Sec-Fetch-Dest':'iframe'}
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',url,'',headers,'',False,'RESOLVERS-XSHARING-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	oLWgT6wSEyi = aQniqUlZk8.code
	if not isinstance(M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,str): M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2.decode('utf8','ignore')
	if 'function(p,a,c,k,e,' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2:
		HJ1sEm6TVP = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(eval\(function\(p,a,c,k,e,[dr].*?)</script>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if HJ1sEm6TVP:
			try: OTdKGIE4Ms6hJjkFwoXyfrU = lboxWJEBsiKdO1FTz(HJ1sEm6TVP[0])
			except: OTdKGIE4Ms6hJjkFwoXyfrU = ''
	flARjI3NM9CQnWY1xk7 = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2+OTdKGIE4Ms6hJjkFwoXyfrU
	if '"id2"' in flARjI3NM9CQnWY1xk7 or '"id"' in flARjI3NM9CQnWY1xk7:
		LlUQVvGa3bjHJ91s8Zid0enfBAuqwT = url.split('/')[3].replace('embed-','').replace('.html','')
		if '"id2"' in flARjI3NM9CQnWY1xk7: VVNkoRCUm96MbtuqgrOe = {'id2':LlUQVvGa3bjHJ91s8Zid0enfBAuqwT,'op':'download2'}
		elif '"id"' in flARjI3NM9CQnWY1xk7: VVNkoRCUm96MbtuqgrOe = {'id':LlUQVvGa3bjHJ91s8Zid0enfBAuqwT,'op':'download2'}
		TC7fWv2a1gLJGiAtN8 = headers.copy()
		TC7fWv2a1gLJGiAtN8['Content-Type'] = 'application/x-www-form-urlencoded'
		WcPEG7nehsCwig809NyHMZ = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'POST',url,VVNkoRCUm96MbtuqgrOe,TC7fWv2a1gLJGiAtN8,'',False,'RESOLVERS-XSHARING-2nd')
		flARjI3NM9CQnWY1xk7 = WcPEG7nehsCwig809NyHMZ.content
	BdrpuYe1z3R,SqfDRWbG1wXFrAT67nl,GNny4A6jHbl3RQd = Nw8sJDKHjdxQ90YOgIb(url,flARjI3NM9CQnWY1xk7)
	WJqjptncmx6lhoKLOA8PIHBE4Qy75[Q1KHi7xSWO] = BdrpuYe1z3R,SqfDRWbG1wXFrAT67nl,GNny4A6jHbl3RQd,oLWgT6wSEyi
	return
WJqjptncmx6lhoKLOA8PIHBE4Qy75,HhBrwT1DlYsNc06oJmbXZ = {},0
def ffdWEztnYD20FImUXKGuJw(url):
	global WJqjptncmx6lhoKLOA8PIHBE4Qy75,HhBrwT1DlYsNc06oJmbXZ
	cc0O1M4e5jtfoq,threads = [],[]
	HhBrwT1DlYsNc06oJmbXZ += 100
	JVXAK9qtdmlMYnfjEryz = HhBrwT1DlYsNc06oJmbXZ
	cc0O1M4e5jtfoq.append([1,url])
	WJqjptncmx6lhoKLOA8PIHBE4Qy75[JVXAK9qtdmlMYnfjEryz+1] = [None,None,None,None]
	LVzvcwfZIQqTWu = mZHwnlsXWDfV3ri4M.Thread(target=SKRIvgcJkYMTleb9wN7iFCHs,args=(JVXAK9qtdmlMYnfjEryz+1,url))
	LVzvcwfZIQqTWu.start()
	LVzvcwfZIQqTWu.join(10)
	if not WJqjptncmx6lhoKLOA8PIHBE4Qy75[JVXAK9qtdmlMYnfjEryz+1][2]:
		M08MPGgsh4n5rKe = url.replace('/embed-','/')
		oBzGqDUAi7KaL8vFdZtP9XIcf = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('^(.*?://.*?)/(.*?)/(.*?)$',M08MPGgsh4n5rKe+'/',E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		start,wCgIq9ai3v2l87ZGMOPne,end = oBzGqDUAi7KaL8vFdZtP9XIcf[0]
		end = end.strip('/')
		czymXJ3doETAhPBNHGK5gjw = len(wCgIq9ai3v2l87ZGMOPne)<4 or wCgIq9ai3v2l87ZGMOPne in ['file','video','videoembed']
		if not czymXJ3doETAhPBNHGK5gjw: cc0O1M4e5jtfoq.append([2,start+'/embed-'+wCgIq9ai3v2l87ZGMOPne+'/'+end])
		if end: cc0O1M4e5jtfoq.append([3,start+'/'+wCgIq9ai3v2l87ZGMOPne+'/embed-'+end])
		if '.html' in wCgIq9ai3v2l87ZGMOPne:
			hLGtjuqcDkSJQ = wCgIq9ai3v2l87ZGMOPne.replace('.html','')
			cc0O1M4e5jtfoq.append([4,start+'/'+hLGtjuqcDkSJQ+'/'+end])
			cc0O1M4e5jtfoq.append([5,start+'/embed-'+hLGtjuqcDkSJQ+'/'+end])
			if end: cc0O1M4e5jtfoq.append([6,start+'/'+hLGtjuqcDkSJQ+'/embed-'+end])
		elif '.html' in end:
			s1IlG4qEdeXvmCQWFThY6n = end.replace('.html','')
			cc0O1M4e5jtfoq.append([7,start+'/'+wCgIq9ai3v2l87ZGMOPne+'/'+s1IlG4qEdeXvmCQWFThY6n])
			if not czymXJ3doETAhPBNHGK5gjw: cc0O1M4e5jtfoq.append([8,start+'/embed-'+wCgIq9ai3v2l87ZGMOPne+'/'+s1IlG4qEdeXvmCQWFThY6n])
			cc0O1M4e5jtfoq.append([9,start+'/'+wCgIq9ai3v2l87ZGMOPne+'/embed-'+s1IlG4qEdeXvmCQWFThY6n])
		else:
			if not czymXJ3doETAhPBNHGK5gjw: cc0O1M4e5jtfoq.append([10,start+'/'+wCgIq9ai3v2l87ZGMOPne+'.html'])
			if not czymXJ3doETAhPBNHGK5gjw: cc0O1M4e5jtfoq.append([11,start+'/embed-'+wCgIq9ai3v2l87ZGMOPne+'.html'])
			if end: cc0O1M4e5jtfoq.append([12,start+'/'+wCgIq9ai3v2l87ZGMOPne+'/'+end+'.html'])
			if end: cc0O1M4e5jtfoq.append([13,start+'/'+wCgIq9ai3v2l87ZGMOPne+'/embed-'+end+'.html'])
		if czymXJ3doETAhPBNHGK5gjw and end:
			end = end.replace('/embed-','/')
			cc0O1M4e5jtfoq.append([14,start+'/'+end])
			cc0O1M4e5jtfoq.append([15,start+'/embed-'+end])
			if '.html' in end:
				s1IlG4qEdeXvmCQWFThY6n = end.replace('.html','')
				cc0O1M4e5jtfoq.append([16,start+'/'+s1IlG4qEdeXvmCQWFThY6n])
				cc0O1M4e5jtfoq.append([17,start+'/embed-'+s1IlG4qEdeXvmCQWFThY6n])
			else:
				cc0O1M4e5jtfoq.append([18,start+'/'+end+'.html'])
				cc0O1M4e5jtfoq.append([19,start+'/embed-'+end+'.html'])
		for gUmrWFV3dB6Q1b02wuHq5,ZCimQhV5lovgspAYzHq1Ef27u8ja4R in cc0O1M4e5jtfoq[1:]:
			WJqjptncmx6lhoKLOA8PIHBE4Qy75[JVXAK9qtdmlMYnfjEryz+gUmrWFV3dB6Q1b02wuHq5] = [None,None,None,None]
			LVzvcwfZIQqTWu = mZHwnlsXWDfV3ri4M.Thread(target=SKRIvgcJkYMTleb9wN7iFCHs,args=(JVXAK9qtdmlMYnfjEryz+gUmrWFV3dB6Q1b02wuHq5,ZCimQhV5lovgspAYzHq1Ef27u8ja4R))
			LVzvcwfZIQqTWu.start()
			w6vebiEZtpCjJcILP8Skx5rHn.sleep(0.5)
			threads.append(LVzvcwfZIQqTWu)
		for LVzvcwfZIQqTWu in threads: LVzvcwfZIQqTWu.join(10)
	d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = '',[],[]
	bBypFGV0ljh7MQxs = []
	for gUmrWFV3dB6Q1b02wuHq5,ZCimQhV5lovgspAYzHq1Ef27u8ja4R in cc0O1M4e5jtfoq:
		NM4xl58THs1d2aDVR,FwPBebDCNTi9H3gkc7V2M85lytJ,CCRSQTKfB16v9nkVcom7FUgdEN,rplLKPEd83 = WJqjptncmx6lhoKLOA8PIHBE4Qy75[JVXAK9qtdmlMYnfjEryz+gUmrWFV3dB6Q1b02wuHq5]
		if not jVMHRouKgQFAESmd7B8ObTYy and CCRSQTKfB16v9nkVcom7FUgdEN: da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = FwPBebDCNTi9H3gkc7V2M85lytJ,CCRSQTKfB16v9nkVcom7FUgdEN
		if not d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5 and NM4xl58THs1d2aDVR: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5 = NM4xl58THs1d2aDVR
		if rplLKPEd83: bBypFGV0ljh7MQxs.append(rplLKPEd83)
	bBypFGV0ljh7MQxs = list(set(bBypFGV0ljh7MQxs))
	if not d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5 and len(bBypFGV0ljh7MQxs)==1:
		oLWgT6wSEyi = bBypFGV0ljh7MQxs[0]
		if oLWgT6wSEyi!=200:
			if oLWgT6wSEyi<0: d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5 = 'Video page/server is not accessible'
			else:
				d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5 = 'HTTP Error: '+str(oLWgT6wSEyi)
				if wvkR1es6d0SrjxKt5FZTMUWz7a: import http.client as uu2TSn6AvbGg59IKOWVx7XcYCeNt
				else: import httplib as uu2TSn6AvbGg59IKOWVx7XcYCeNt
				d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5 += ' ( '+uu2TSn6AvbGg59IKOWVx7XcYCeNt.responses[oLWgT6wSEyi]+' )'
	w6vebiEZtpCjJcILP8Skx5rHn.sleep(1)
	return d1kLibpHYwBCUxq0Wcj7N2Ks69FIv5,da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy
class XnjmpNgEOdHvyJIR3hfcQD(ZuEAJR1lNHkUf0.WindowDialog):
	def __init__(G9kpoeR7yazZx3AUn0m, *args, **I1IXUNMaAYb9osu):
		yKwp1FPzRZ3Dmb9val = K3hFytImeYMkJBC.path.join(U0AdbxBVqaQOwTJIcSgN1z9iM7r, 'resources', 'recaptcha2', 'dialogbg.png')
		RRe5x96mqIgzkJnFc = K3hFytImeYMkJBC.path.join(U0AdbxBVqaQOwTJIcSgN1z9iM7r, 'resources', 'recaptcha2', 'selected.png')
		bbUEwM6ZuNFAi8onCf = K3hFytImeYMkJBC.path.join(U0AdbxBVqaQOwTJIcSgN1z9iM7r, 'resources', 'recaptcha2', 'buttonfo.png')
		oDcULgFyYBGmuZMIQdvEPa = K3hFytImeYMkJBC.path.join(U0AdbxBVqaQOwTJIcSgN1z9iM7r, 'resources', 'recaptcha2', 'buttonnf.png')
		iN8swIaJVGCkj1fodQRWHrXY3 = K3hFytImeYMkJBC.path.join(U0AdbxBVqaQOwTJIcSgN1z9iM7r, 'resources', 'recaptcha2', 'buttonbg.png')
		G9kpoeR7yazZx3AUn0m.cancelled = False
		G9kpoeR7yazZx3AUn0m.chk = [0] * 9
		G9kpoeR7yazZx3AUn0m.chkbutton = [0] * 9
		G9kpoeR7yazZx3AUn0m.chkstate = [False] * 9
		NN1TsFgniLHatD3xr2v4MS, SsoRpct7EZVr8GvBuTj30W4zbl6yY, wxSMtfeJWQl, pHFPbJ2xfymQZXgcT6WKYGwvk = 250, 0, 700, 760
		zL8GPWO1vnMCkqZ5sESXelr9Itw2xu = NN1TsFgniLHatD3xr2v4MS+wxSMtfeJWQl//2
		QD3TLfN7m2Ez15JvFhPGOxA90HbZ8, gmOyU9MVoNp6SGq2wt4fHCQ8E, eJvG1LR7f4Fst3aTMPuiwBAUZxmjW, xzEMeLwgdcn6q82AaSQWU0jTi = 355, 120, 500, 500
		WbdSqN0f9MkwZ = QD3TLfN7m2Ez15JvFhPGOxA90HbZ8+eJvG1LR7f4Fst3aTMPuiwBAUZxmjW//2
		G2G6QX5t1qCRldOTgaUwsVMfrDeEhz, QTM3GPIEoklWuKym4, cSeT6gm4u5yQvIAhJ39kEO, RhzwksAZNd9uPIeCx4XJfQB = 100, 655, 150, 50
		jTLYy8aft9Szo2r4DJQXh05GkF = zL8GPWO1vnMCkqZ5sESXelr9Itw2xu-cSeT6gm4u5yQvIAhJ39kEO-G2G6QX5t1qCRldOTgaUwsVMfrDeEhz//2
		jU2DEu8v6lJVHIyLCMFBzfd7wpR = zL8GPWO1vnMCkqZ5sESXelr9Itw2xu+G2G6QX5t1qCRldOTgaUwsVMfrDeEhz//2
		FFGxRmdoMtpjI8LkX3Yry, ysVwO8rISLxfPMAt, YvbDupQCkTORWUetMA7iZ, BJ6C2tZAr9OVuDKSsm = 355, 30, 500, 50
		ooywLIEP1OBqW3e, FiVwj64JRorSPqkQt, MGlpmWS7wzKPc5D, hDUtz516sARVj3TqZ = 355, 70, 500, 50
		gPkQBNDqHMc9GvzxV4630FSbpW = 0.9
		NN1TsFgniLHatD3xr2v4MS, SsoRpct7EZVr8GvBuTj30W4zbl6yY, wxSMtfeJWQl, pHFPbJ2xfymQZXgcT6WKYGwvk = int(NN1TsFgniLHatD3xr2v4MS*gPkQBNDqHMc9GvzxV4630FSbpW), int(SsoRpct7EZVr8GvBuTj30W4zbl6yY*gPkQBNDqHMc9GvzxV4630FSbpW), int(wxSMtfeJWQl*gPkQBNDqHMc9GvzxV4630FSbpW), int(pHFPbJ2xfymQZXgcT6WKYGwvk*gPkQBNDqHMc9GvzxV4630FSbpW)
		QD3TLfN7m2Ez15JvFhPGOxA90HbZ8, gmOyU9MVoNp6SGq2wt4fHCQ8E, eJvG1LR7f4Fst3aTMPuiwBAUZxmjW, xzEMeLwgdcn6q82AaSQWU0jTi = int(QD3TLfN7m2Ez15JvFhPGOxA90HbZ8*gPkQBNDqHMc9GvzxV4630FSbpW), int(gmOyU9MVoNp6SGq2wt4fHCQ8E*gPkQBNDqHMc9GvzxV4630FSbpW), int(eJvG1LR7f4Fst3aTMPuiwBAUZxmjW*gPkQBNDqHMc9GvzxV4630FSbpW), int(xzEMeLwgdcn6q82AaSQWU0jTi*gPkQBNDqHMc9GvzxV4630FSbpW)
		jTLYy8aft9Szo2r4DJQXh05GkF, XobGRwW32j76YUTq, MAr7Ipy4P5XfqumCLYinDxGaW9, xp2Pm7rqy4stNeH = int(jTLYy8aft9Szo2r4DJQXh05GkF*gPkQBNDqHMc9GvzxV4630FSbpW), int(QTM3GPIEoklWuKym4*gPkQBNDqHMc9GvzxV4630FSbpW), int(cSeT6gm4u5yQvIAhJ39kEO*gPkQBNDqHMc9GvzxV4630FSbpW), int(RhzwksAZNd9uPIeCx4XJfQB*gPkQBNDqHMc9GvzxV4630FSbpW)
		jU2DEu8v6lJVHIyLCMFBzfd7wpR, PEY1HRwbFe, Y2hoXck7x5fyQNdqv3GZb, VKqzYx3GnCUP = int(jU2DEu8v6lJVHIyLCMFBzfd7wpR*gPkQBNDqHMc9GvzxV4630FSbpW), int(QTM3GPIEoklWuKym4*gPkQBNDqHMc9GvzxV4630FSbpW), int(cSeT6gm4u5yQvIAhJ39kEO*gPkQBNDqHMc9GvzxV4630FSbpW), int(RhzwksAZNd9uPIeCx4XJfQB*gPkQBNDqHMc9GvzxV4630FSbpW)
		FFGxRmdoMtpjI8LkX3Yry, ysVwO8rISLxfPMAt, YvbDupQCkTORWUetMA7iZ, BJ6C2tZAr9OVuDKSsm = int(FFGxRmdoMtpjI8LkX3Yry*gPkQBNDqHMc9GvzxV4630FSbpW), int(ysVwO8rISLxfPMAt*gPkQBNDqHMc9GvzxV4630FSbpW), int(YvbDupQCkTORWUetMA7iZ*gPkQBNDqHMc9GvzxV4630FSbpW), int(BJ6C2tZAr9OVuDKSsm*gPkQBNDqHMc9GvzxV4630FSbpW)
		ooywLIEP1OBqW3e, FiVwj64JRorSPqkQt, MGlpmWS7wzKPc5D, hDUtz516sARVj3TqZ = int(ooywLIEP1OBqW3e*gPkQBNDqHMc9GvzxV4630FSbpW), int(FiVwj64JRorSPqkQt*gPkQBNDqHMc9GvzxV4630FSbpW), int(MGlpmWS7wzKPc5D*gPkQBNDqHMc9GvzxV4630FSbpW), int(hDUtz516sARVj3TqZ*gPkQBNDqHMc9GvzxV4630FSbpW)
		HtC3K27dS5ObqXUWGNMZzumr = ZuEAJR1lNHkUf0.ControlImage(NN1TsFgniLHatD3xr2v4MS, SsoRpct7EZVr8GvBuTj30W4zbl6yY, wxSMtfeJWQl, pHFPbJ2xfymQZXgcT6WKYGwvk, yKwp1FPzRZ3Dmb9val)
		G9kpoeR7yazZx3AUn0m.addControl(HtC3K27dS5ObqXUWGNMZzumr)
		G9kpoeR7yazZx3AUn0m.iteration = I1IXUNMaAYb9osu.get('iteration')
		xM2Vwqk0amTK7cDEACJf18p9IYHL = '[COLOR FFFFFF00]'+'فحص أنا إنسان ولست روبوت         '+'المحاولة رقم  '+str(G9kpoeR7yazZx3AUn0m.iteration)+'[/COLOR]'
		G9kpoeR7yazZx3AUn0m.strActionInfo = ZuEAJR1lNHkUf0.ControlLabel(FFGxRmdoMtpjI8LkX3Yry, ysVwO8rISLxfPMAt, YvbDupQCkTORWUetMA7iZ, BJ6C2tZAr9OVuDKSsm, xM2Vwqk0amTK7cDEACJf18p9IYHL, 'font13')
		G9kpoeR7yazZx3AUn0m.addControl(G9kpoeR7yazZx3AUn0m.strActionInfo)
		Q2qmuDRrC9ikcaJK7gtUHXNW = ZuEAJR1lNHkUf0.ControlImage(QD3TLfN7m2Ez15JvFhPGOxA90HbZ8, gmOyU9MVoNp6SGq2wt4fHCQ8E, eJvG1LR7f4Fst3aTMPuiwBAUZxmjW, xzEMeLwgdcn6q82AaSQWU0jTi, I1IXUNMaAYb9osu.get('captcha'))
		G9kpoeR7yazZx3AUn0m.addControl(Q2qmuDRrC9ikcaJK7gtUHXNW)
		Kzl0uHe2AqBZ4 = '[COLOR FFFFFF00]'+I1IXUNMaAYb9osu.get('msg')+'[/COLOR]'
		G9kpoeR7yazZx3AUn0m.strActionInfo = ZuEAJR1lNHkUf0.ControlLabel(ooywLIEP1OBqW3e, FiVwj64JRorSPqkQt, MGlpmWS7wzKPc5D, hDUtz516sARVj3TqZ, Kzl0uHe2AqBZ4, 'font13')
		G9kpoeR7yazZx3AUn0m.addControl(G9kpoeR7yazZx3AUn0m.strActionInfo)
		text = '[COLOR FFFFFF00]'+'خروج'+'[/COLOR]'
		G9kpoeR7yazZx3AUn0m.cancelbutton = ZuEAJR1lNHkUf0.ControlButton(jTLYy8aft9Szo2r4DJQXh05GkF, XobGRwW32j76YUTq, MAr7Ipy4P5XfqumCLYinDxGaW9, xp2Pm7rqy4stNeH, text, focusTexture=iN8swIaJVGCkj1fodQRWHrXY3, noFocusTexture=bbUEwM6ZuNFAi8onCf, alignment=2)
		text = '[COLOR FFFFFF00]'+'استمرار'+'[/COLOR]'
		G9kpoeR7yazZx3AUn0m.okbutton = ZuEAJR1lNHkUf0.ControlButton(jU2DEu8v6lJVHIyLCMFBzfd7wpR, PEY1HRwbFe, Y2hoXck7x5fyQNdqv3GZb, VKqzYx3GnCUP, text, focusTexture=iN8swIaJVGCkj1fodQRWHrXY3, noFocusTexture=bbUEwM6ZuNFAi8onCf, alignment=2)
		G9kpoeR7yazZx3AUn0m.addControl(G9kpoeR7yazZx3AUn0m.okbutton)
		G9kpoeR7yazZx3AUn0m.addControl(G9kpoeR7yazZx3AUn0m.cancelbutton)
		tb73KoXLSAm2gTDaIhrQG1ViN, nnuea51UjQwc0Bg = xzEMeLwgdcn6q82AaSQWU0jTi//3, eJvG1LR7f4Fst3aTMPuiwBAUZxmjW//3
		for AudBQkLFsrHKicIogThZyv in range(9):
			MUfusbjiETQleL = AudBQkLFsrHKicIogThZyv // 3
			vZTGdw7NzmWsMyeqc0Jj = AudBQkLFsrHKicIogThZyv % 3
			Ci3MVkPSQWcAB8L = QD3TLfN7m2Ez15JvFhPGOxA90HbZ8 + (nnuea51UjQwc0Bg * vZTGdw7NzmWsMyeqc0Jj)
			llcEgJA6QLNSpHPz2q1xaZtrVeKI = gmOyU9MVoNp6SGq2wt4fHCQ8E + (tb73KoXLSAm2gTDaIhrQG1ViN * MUfusbjiETQleL)
			G9kpoeR7yazZx3AUn0m.chk[AudBQkLFsrHKicIogThZyv] = ZuEAJR1lNHkUf0.ControlImage(Ci3MVkPSQWcAB8L, llcEgJA6QLNSpHPz2q1xaZtrVeKI, nnuea51UjQwc0Bg, tb73KoXLSAm2gTDaIhrQG1ViN, RRe5x96mqIgzkJnFc)
			G9kpoeR7yazZx3AUn0m.addControl(G9kpoeR7yazZx3AUn0m.chk[AudBQkLFsrHKicIogThZyv])
			G9kpoeR7yazZx3AUn0m.chk[AudBQkLFsrHKicIogThZyv].setVisible(False)
			G9kpoeR7yazZx3AUn0m.chkbutton[AudBQkLFsrHKicIogThZyv] = ZuEAJR1lNHkUf0.ControlButton(Ci3MVkPSQWcAB8L, llcEgJA6QLNSpHPz2q1xaZtrVeKI, nnuea51UjQwc0Bg, tb73KoXLSAm2gTDaIhrQG1ViN, str(AudBQkLFsrHKicIogThZyv + 1), font='font13', focusTexture=bbUEwM6ZuNFAi8onCf, noFocusTexture=oDcULgFyYBGmuZMIQdvEPa)
			G9kpoeR7yazZx3AUn0m.addControl(G9kpoeR7yazZx3AUn0m.chkbutton[AudBQkLFsrHKicIogThZyv])
		for AudBQkLFsrHKicIogThZyv in range(9):
			vQrBR4D3MU7els = (AudBQkLFsrHKicIogThZyv // 3) * 3
			fT7lW3vJzXoKjap = vQrBR4D3MU7els + (AudBQkLFsrHKicIogThZyv + 1) % 3
			MMK7zwp3j6XB0oyZ8mL1aWhPxnJHvs = vQrBR4D3MU7els + (AudBQkLFsrHKicIogThZyv - 1) % 3
			uIDTyNGwKtnxia = (AudBQkLFsrHKicIogThZyv - 3) % 9
			xdHzmSuCkoTNKUtlDe9812BPRGghX = (AudBQkLFsrHKicIogThZyv + 3) % 9
			G9kpoeR7yazZx3AUn0m.chkbutton[AudBQkLFsrHKicIogThZyv].controlRight(G9kpoeR7yazZx3AUn0m.chkbutton[fT7lW3vJzXoKjap])
			G9kpoeR7yazZx3AUn0m.chkbutton[AudBQkLFsrHKicIogThZyv].controlLeft(G9kpoeR7yazZx3AUn0m.chkbutton[MMK7zwp3j6XB0oyZ8mL1aWhPxnJHvs])
			if AudBQkLFsrHKicIogThZyv <= 2:
				G9kpoeR7yazZx3AUn0m.chkbutton[AudBQkLFsrHKicIogThZyv].controlUp(G9kpoeR7yazZx3AUn0m.okbutton)
			else:
				G9kpoeR7yazZx3AUn0m.chkbutton[AudBQkLFsrHKicIogThZyv].controlUp(G9kpoeR7yazZx3AUn0m.chkbutton[uIDTyNGwKtnxia])
			if AudBQkLFsrHKicIogThZyv >= 6:
				G9kpoeR7yazZx3AUn0m.chkbutton[AudBQkLFsrHKicIogThZyv].controlDown(G9kpoeR7yazZx3AUn0m.okbutton)
			else:
				G9kpoeR7yazZx3AUn0m.chkbutton[AudBQkLFsrHKicIogThZyv].controlDown(G9kpoeR7yazZx3AUn0m.chkbutton[xdHzmSuCkoTNKUtlDe9812BPRGghX])
		G9kpoeR7yazZx3AUn0m.okbutton.controlLeft(G9kpoeR7yazZx3AUn0m.cancelbutton)
		G9kpoeR7yazZx3AUn0m.okbutton.controlRight(G9kpoeR7yazZx3AUn0m.cancelbutton)
		G9kpoeR7yazZx3AUn0m.cancelbutton.controlLeft(G9kpoeR7yazZx3AUn0m.okbutton)
		G9kpoeR7yazZx3AUn0m.cancelbutton.controlRight(G9kpoeR7yazZx3AUn0m.okbutton)
		G9kpoeR7yazZx3AUn0m.okbutton.controlDown(G9kpoeR7yazZx3AUn0m.chkbutton[2])
		G9kpoeR7yazZx3AUn0m.okbutton.controlUp(G9kpoeR7yazZx3AUn0m.chkbutton[8])
		G9kpoeR7yazZx3AUn0m.cancelbutton.controlDown(G9kpoeR7yazZx3AUn0m.chkbutton[0])
		G9kpoeR7yazZx3AUn0m.cancelbutton.controlUp(G9kpoeR7yazZx3AUn0m.chkbutton[6])
		G9kpoeR7yazZx3AUn0m.setFocus(G9kpoeR7yazZx3AUn0m.okbutton)
	def get(G9kpoeR7yazZx3AUn0m):
		G9kpoeR7yazZx3AUn0m.doModal()
		G9kpoeR7yazZx3AUn0m.close()
		if not G9kpoeR7yazZx3AUn0m.cancelled:
			return [AudBQkLFsrHKicIogThZyv for AudBQkLFsrHKicIogThZyv in range(9) if G9kpoeR7yazZx3AUn0m.chkstate[AudBQkLFsrHKicIogThZyv]]
	def onControl(G9kpoeR7yazZx3AUn0m, k69NKW5MeDx):
		if k69NKW5MeDx.getId() == G9kpoeR7yazZx3AUn0m.okbutton.getId() and any(G9kpoeR7yazZx3AUn0m.chkstate):
			G9kpoeR7yazZx3AUn0m.close()
		elif k69NKW5MeDx.getId() == G9kpoeR7yazZx3AUn0m.cancelbutton.getId():
			G9kpoeR7yazZx3AUn0m.cancelled = True
			G9kpoeR7yazZx3AUn0m.close()
		else:
			JNuHrgRwE8K0hcdMBtQl = k69NKW5MeDx.getLabel()
			if JNuHrgRwE8K0hcdMBtQl.isnumeric():
				index = int(JNuHrgRwE8K0hcdMBtQl) - 1
				G9kpoeR7yazZx3AUn0m.chkstate[index] = not G9kpoeR7yazZx3AUn0m.chkstate[index]
				G9kpoeR7yazZx3AUn0m.chk[index].setVisible(G9kpoeR7yazZx3AUn0m.chkstate[index])
	def onAction(G9kpoeR7yazZx3AUn0m, WWhwSdqskjBOAet0a5l73gXYPrvQ):
		if WWhwSdqskjBOAet0a5l73gXYPrvQ == 10:
			G9kpoeR7yazZx3AUn0m.cancelled = True
			G9kpoeR7yazZx3AUn0m.close()
def aalYnheZdTrm7V(key,JpOKtD7egn,url):
	headers = {'Referer':url,'Accept-Language':JpOKtD7egn}
	CIhUklX8Qj = 'http://www.google.com/recaptcha/api/fallback?k='+key
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',CIhUklX8Qj,'',headers,'','','RESOLVERS-GET_RECAPTCHA2_TOKEN-1st')
	wr9ZDoyjmK5gxci083G,iteration = '',0
	while True:
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		VVNkoRCUm96MbtuqgrOe = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"(/recaptcha/api2/payload[^"]+)', M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2)
		iteration += 1
		message = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<label[^>]+class="fbc-imageselect-message-text"[^>]*>(.*?)</label>', M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2)
		if not message: message = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<div[^>]+class="fbc-imageselect-message-error">(.*?)</div>', M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2)
		if not message:
			wr9ZDoyjmK5gxci083G = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('readonly>(.*?)<', M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2)[0]
			break
		else:
			message = message[0]
			VVNkoRCUm96MbtuqgrOe = VVNkoRCUm96MbtuqgrOe[0]
		iEqfCLPx5KysH = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(r'name="c"\s+value="([^"]+)', M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2)[0]
		G5DeSAzQyVt0IZE2h = 'https://www.google.com%s' % (VVNkoRCUm96MbtuqgrOe.replace('&amp;', '&'))
		message = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.sub('</?(div|strong)[^>]*>', '', message)
		bYHeqnx1NRGz4QiJcaB2fU = XnjmpNgEOdHvyJIR3hfcQD(captcha=G5DeSAzQyVt0IZE2h, msg=message, iteration=iteration)
		aapVrfsgRtTKHYWGb9hx0MS = bYHeqnx1NRGz4QiJcaB2fU.get()
		if not aapVrfsgRtTKHYWGb9hx0MS: break
		data = {'c': iEqfCLPx5KysH, 'response': aapVrfsgRtTKHYWGb9hx0MS}
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'POST',CIhUklX8Qj,data,headers,'','','RESOLVERS-GET_RECAPTCHA2_TOKEN-2nd')
	return wr9ZDoyjmK5gxci083G
def Dkn3dzZG0BygQbp1e485aFmKC(url):
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(jEPuRTVbZg4MCimJxzf3I6wFa,url,'','','','RESOLVERS-ARABLOADS-1st')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('color="red">(.*?)<',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if items: return '',[''],[ items[0] ]
	else: return 'Error: Resolver Failed ARABLOADS',[],[]
def IgA3ZjPzoraTu6ldM0sOh(url):
	return '',[''],[ url ]
def GhRAxgTWjeFosiMdpEmZ9JlavkIb5(url):
	vMSQsdJ0gCrh7ztnR96yDXqOYaj = url.split('/')
	HQiUY8GJW7l1TuwN = '/'.join(vMSQsdJ0gCrh7ztnR96yDXqOYaj[0:3])
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(jEPuRTVbZg4MCimJxzf3I6wFa,url,'','','','RESOLVERS-ZIPPYSHARE-1st')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('dlbutton\'\).href = "(.*?)" \+ \((.*?) \% (.*?) \+ (.*?) \% (.*?)\) \+ "(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if items:
		xvj7ObtqTw1IU3fQuLDC,asSviLeQ41YWRC5,iiF5czHqt6bpwKY7Alh3S1MeV,yRp0Ob7YtxSfco4C1JDFMHlWUGwzn,UE2B6Vq1xoyNhfRTi,bhkXsZQjnLKzyg8cxTlMu5mqrCfw6 = items[0]
		DHcrLNnqExKjM8uvVlBhWd = int(asSviLeQ41YWRC5) % int(iiF5czHqt6bpwKY7Alh3S1MeV) + int(yRp0Ob7YtxSfco4C1JDFMHlWUGwzn) % int(UE2B6Vq1xoyNhfRTi)
		url = HQiUY8GJW7l1TuwN + xvj7ObtqTw1IU3fQuLDC + str(DHcrLNnqExKjM8uvVlBhWd) + bhkXsZQjnLKzyg8cxTlMu5mqrCfw6
		return '',[''],[url]
	else: return 'Error: Resolver Failed ZIPPYSHARE',[],[]
def Ig6Ru8NTZvM9L(url):
	id = url.split('/')[-1]
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	VVNkoRCUm96MbtuqgrOe = { "id":id , "op":"download2" }
	VWi2dTb46v3eOryuspKBF9L = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'POST', url, VVNkoRCUm96MbtuqgrOe, headers, '','','RESOLVERS-MP4UPLOAD-1st')
	if 'Location' in list(VWi2dTb46v3eOryuspKBF9L.headers.keys()): ZCimQhV5lovgspAYzHq1Ef27u8ja4R = VWi2dTb46v3eOryuspKBF9L.headers['Location']
	else: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = url
	if ZCimQhV5lovgspAYzHq1Ef27u8ja4R: return '',[''],[ZCimQhV5lovgspAYzHq1Ef27u8ja4R]
	else: return 'Error: Resolver Failed MP4UPLOAD',[],[]
def MUTZEmRLvldcOsr13AtJukwI(url):
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(jEPuRTVbZg4MCimJxzf3I6wFa,url,'','','','RESOLVERS-WINTVLIVE-1st')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('mp4: \[\'(.*?)\'',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if items: return '',[''],[ items[0] ]
	else: return 'Error: Resolver Failed WINTVLIVE',[],[]
def m2aNQA3o8PlLe(url):
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(jEPuRTVbZg4MCimJxzf3I6wFa,url,'','','','RESOLVERS-ARCHIVE-1st')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('source src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if items:
		url = url = 'https://archive.org' + items[0]
		return '',[''],[ url ]
	else: return 'Error: Resolver Failed ARCHIVE',[],[]
def XeaFN8KkxSzuDtq6L4CsvIW(url):
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(jEPuRTVbZg4MCimJxzf3I6wFa,url,'','','','RESOLVERS-ESTREAM-1st')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('video preload.*?src=.*?src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if items: return '',[''],[ items[0] ]
	else: return 'Error: Resolver Failed ESTREAM',[],[]
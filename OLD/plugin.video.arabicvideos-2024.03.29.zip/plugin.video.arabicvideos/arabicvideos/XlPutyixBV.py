# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'ARABICTOONS'
Yc0eBRLpbCkm4gK7OqyzuHwU = '_ART_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
def HgQCVwFx2Br(mode,url,text):
	if   mode==730: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==731: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url)
	elif mode==732: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==733: s4Bng5iAZQSTtpDw9 = btd6ag2XYUkHixqy5J7o9RfLu1MScm(url)
	elif mode==734: s4Bng5iAZQSTtpDw9 = FCS7s5WogGAwa0l89TOdeh2EvnpU(url)
	elif mode==735: s4Bng5iAZQSTtpDw9 = sE5IFyqwPrHlgK4YdMzuT09aCpjR(url)
	elif mode==739: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',739,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'مسلسلات مميزة',tle5V6jgvRfE+'/top.php',735)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'مسلسلات',tle5V6jgvRfE+'/cartoon.php',734)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'افلام',tle5V6jgvRfE+'/movies.php',731)
	return
def FCS7s5WogGAwa0l89TOdeh2EvnpU(url):
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الكل',url,731)
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','ARABICTOONS-SERIES_SUBMENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('label="navigation"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("href='(.*?)'>(.*?)</a>",ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			title = 'حرف '+title
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,731)
	return
def sE5IFyqwPrHlgK4YdMzuT09aCpjR(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','ARABICTOONS-SERIES_FEATURED-2nd')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="slider"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			Q2qmuDRrC9ikcaJK7gtUHXNW = tle5V6jgvRfE+'/'+Q2qmuDRrC9ikcaJK7gtUHXNW
			title = title.strip(' ')
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,733,Q2qmuDRrC9ikcaJK7gtUHXNW)
	return
def uyt3pAHZk4(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','ARABICTOONS-TITLES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("class='moviesBlocks(.*?)navigation",M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="movie".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title in items:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		Q2qmuDRrC9ikcaJK7gtUHXNW = tle5V6jgvRfE+'/'+Q2qmuDRrC9ikcaJK7gtUHXNW
		title = title.strip(' ')
		if 'movies.php' in url: tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,732,Q2qmuDRrC9ikcaJK7gtUHXNW)
		else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,733,Q2qmuDRrC9ikcaJK7gtUHXNW)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"pagination(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[-1]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?>(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			title = title.strip(' ')
			title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,731)
	return
def btd6ag2XYUkHixqy5J7o9RfLu1MScm(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','ARABICTOONS-EPISODES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("class='moviesBlocks(.*?)script",M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="movie".*?title="(.*?)".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,MU6wfmO0k1qVxcoPB2NuWKe7D in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			Q2qmuDRrC9ikcaJK7gtUHXNW = tle5V6jgvRfE+'/'+Q2qmuDRrC9ikcaJK7gtUHXNW
			title = title.strip(' ')
			title = title+' '+MU6wfmO0k1qVxcoPB2NuWKe7D.strip(' ')
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,732,Q2qmuDRrC9ikcaJK7gtUHXNW)
	return
def dlropqS0vO9K7W4z(url):
	zcBjFq4VQlp20ZekGO = []
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','ARABICTOONS-PLAY-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	cc0O1M4e5jtfoq = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('source src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if cc0O1M4e5jtfoq:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = cc0O1M4e5jtfoq[0]
		if 'Referer=' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'|Referer=https://www.arabic-toons.com'
		zcBjFq4VQlp20ZekGO.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named=__embed')
	import JYR902sfml
	JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt(zcBjFq4VQlp20ZekGO,r1NChsk39OMvT82YemDQnl5,'video',url)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if search=='': search = UIf35nZEj1wylmq()
	if search=='': return
	search = search.replace(' ','%20')
	jVMHRouKgQFAESmd7B8ObTYy = ['','m']
	JHO207wRUyXeK = ['مسلسلات','افلام']
	if showDialogs:
		NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql('اختر النوع المطلوب:', JHO207wRUyXeK)
		if NljOosKT8WJBpch==-1: return
	else: NljOosKT8WJBpch = 0
	type = jVMHRouKgQFAESmd7B8ObTYy[NljOosKT8WJBpch]
	url = tle5V6jgvRfE+'/livesearch.php?'+type+'&q='+search
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','ARABICTOONS-SEARCH-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)">(.*?)<',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		title = title.strip(' ')
		if type=='m': tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,732)
		else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,733)
	return
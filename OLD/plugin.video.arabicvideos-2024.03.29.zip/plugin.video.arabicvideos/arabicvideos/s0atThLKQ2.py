# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'MYCIMA'
headers = {'User-Agent':''}
Yc0eBRLpbCkm4gK7OqyzuHwU = '_MCM_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
ZLKHfqMEUdRupD = ['مصارعة حرة','wwe']
def HgQCVwFx2Br(mode,url,text):
	if   mode==360: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==361: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url,text)
	elif mode==362: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==363: s4Bng5iAZQSTtpDw9 = btd6ag2XYUkHixqy5J7o9RfLu1MScm(url,text)
	elif mode==364: s4Bng5iAZQSTtpDw9 = L1FsQxw6Afb7pcCe9Tr3qizXZ(url,'CATEGORIES___'+text)
	elif mode==365: s4Bng5iAZQSTtpDw9 = L1FsQxw6Afb7pcCe9Tr3qizXZ(url,'FILTERS___'+text)
	elif mode==366: s4Bng5iAZQSTtpDw9 = AJDL0Mp13fQkRH5c(url)
	elif mode==369: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text,url)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع',tle5V6jgvRfE,369,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فلتر محدد',tle5V6jgvRfE+'/AjaxCenter/RightBar',364)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فلتر كامل',tle5V6jgvRfE+'/AjaxCenter/RightBar',365)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',tle5V6jgvRfE,'','','','','MYCIMA-MENU-2nd')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="NavigationMenu"(.*?)class="ProductionsListButton"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="menu-item.*?href="(.*?)">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			if title=='': continue
			if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title.lower() for hht0cpXxWw2OzFS1jnUGebkJLBd85 in ZLKHfqMEUdRupD): continue
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,366)
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('hoverable activable(.*?)hoverable activable',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?url\((.*?)\).*?span>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title in items:
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,366,Q2qmuDRrC9ikcaJK7gtUHXNW)
	return M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
def AJDL0Mp13fQkRH5c(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',url,'','','','','MYCIMA-SUBMENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	if 'class="Slider--Grid"' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2:
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'المميزة',url,361,'','','featured')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="list--Tabsui"(.*?)div',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?i>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,361)
	return
def uyt3pAHZk4(wxKkOYrPef6FnEh,type=''):
	if '::' in wxKkOYrPef6FnEh:
		TW6JIBgC971tjOE,url = wxKkOYrPef6FnEh.split('::')
		vMSQsdJ0gCrh7ztnR96yDXqOYaj = SLMTm6RQ34ic7v5s9rBG(TW6JIBgC971tjOE,'url')
		url = vMSQsdJ0gCrh7ztnR96yDXqOYaj+url
	else: url,TW6JIBgC971tjOE = wxKkOYrPef6FnEh,wxKkOYrPef6FnEh
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','MYCIMA-TITLES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	if type=='featured':
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="Slider--Grid"(.*?)class="list--Tabsui"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	elif type=='filters':
		TIkiozSLCv6werb97mHQ0q4y3 = [M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2.replace('\\/','/').replace('\\"','"')]
	else:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="Grid--MycimaPosts"(.*?)</li></ul></div></div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	jjR8ftoEXpPxVF6JerbHZuzv7ic = []
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('GridItem"><a href="(.*?)" title="(.*?)".*?url\((.*?)\)',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,Q2qmuDRrC9ikcaJK7gtUHXNW in items:
			if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title.lower() for hht0cpXxWw2OzFS1jnUGebkJLBd85 in ZLKHfqMEUdRupD): continue
			Q2qmuDRrC9ikcaJK7gtUHXNW = zKGXT5sJeRq(Q2qmuDRrC9ikcaJK7gtUHXNW)
			title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
			title = zKGXT5sJeRq(title)
			title = title.replace('مشاهدة ','')
			if '/series/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,363,Q2qmuDRrC9ikcaJK7gtUHXNW)
			elif 'حلقة' in title:
				EQw62xjXSJmzrRt = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(.*?) +حلقة +\d+',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
				if EQw62xjXSJmzrRt: title = '_MOD_' + EQw62xjXSJmzrRt[0]
				if title not in jjR8ftoEXpPxVF6JerbHZuzv7ic:
					jjR8ftoEXpPxVF6JerbHZuzv7ic.append(title)
					tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,363,Q2qmuDRrC9ikcaJK7gtUHXNW)
			else:
				tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,362,Q2qmuDRrC9ikcaJK7gtUHXNW)
		if type=='filters':
			SSgRAKD3NBqJ97ojTnL5kpFafHdU = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"more_button_page":(.*?),',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if SSgRAKD3NBqJ97ojTnL5kpFafHdU:
				count = SSgRAKD3NBqJ97ojTnL5kpFafHdU[0]
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = url+'/offset/'+count
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة أخرى',ZCimQhV5lovgspAYzHq1Ef27u8ja4R,361,'','','filters')
		elif type=='':
			TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="pagination(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if TIkiozSLCv6werb97mHQ0q4y3:
				ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
				items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
				for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
					title = 'صفحة '+nnGHa80rMphqe1ukFtIRvAPs6W(title)
					tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,361)
	return
def btd6ag2XYUkHixqy5J7o9RfLu1MScm(url,type=''):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','MYCIMA-EPISODES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = BUTSkzgFC7(M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2)
	name = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('itemprop="item" href=".*?/series/(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if name: name = name[-1].replace('-',' ').strip('/')
	if 'موسم' in name and type=='':
		name = name.split('موسم')[0]
		name = name.replace('مشاهدة','').strip(' ')
	elif 'حلقة' in name:
		name = name.split('حلقة')[0]
		name = name.replace('مشاهدة','').strip(' ')
	else: name = name
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="Seasons--Episodes"(.*?)</singlesection',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		if type=='':
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)">(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
				if 'class' in title: continue
				if 'episode' in title: continue
				title = name+' - '+title
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,363,'','','episodes')
		if len(muPDGHvJwFieQYCW62bB)==0:
			f9AzGuXj0qgcNTy1 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="Episodes--Seasons--Episodes"(.*?)&&',ziJLDVT8NM2QcgIpmE9A+'&&',E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if f9AzGuXj0qgcNTy1: ziJLDVT8NM2QcgIpmE9A = f9AzGuXj0qgcNTy1[0]
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?<episodeTitle>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
				title = title.strip(' ')
				title = name+' - '+title
				tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,362)
	if len(muPDGHvJwFieQYCW62bB)==0:
		title = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<title>(.*?)<',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if title: title = title[0].replace(' - ماي سيما','').replace('مشاهدة ','')
		else: title = 'ملف التشغيل'
		tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,362)
	return
def dlropqS0vO9K7W4z(url):
	jVMHRouKgQFAESmd7B8ObTYy = []
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',url,'','','','','MYCIMA-PLAY-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	VnK1wPrcHoN8ex2Bl0pLS = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<span>التصنيف<.*?<a.*?">(.*?)<.*?">(.*?)<',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if VnK1wPrcHoN8ex2Bl0pLS:
		VnK1wPrcHoN8ex2Bl0pLS = [VnK1wPrcHoN8ex2Bl0pLS[0][0],VnK1wPrcHoN8ex2Bl0pLS[0][1]]
		if VnK1wPrcHoN8ex2Bl0pLS and Y1Yz6bZMLDaGjpxK3fSXm7TurCnHwo(r1NChsk39OMvT82YemDQnl5,url,VnK1wPrcHoN8ex2Bl0pLS): return
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="WatchServersList"(.*?)class="WatchServersEmbed"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-url="(.*?)".*?strong>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,name in items:
			if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			if name=='سيرفر ماي سيما': name = 'mycima'
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+name+'__watch'
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="List--Download(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?</i>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,LjG8y1rb9AgJF2I3i64ZDtCXMa7n in items:
			if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			LjG8y1rb9AgJF2I3i64ZDtCXMa7n = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('\d\d\d+',LjG8y1rb9AgJF2I3i64ZDtCXMa7n,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if LjG8y1rb9AgJF2I3i64ZDtCXMa7n: LjG8y1rb9AgJF2I3i64ZDtCXMa7n = '____'+LjG8y1rb9AgJF2I3i64ZDtCXMa7n[0]
			else: LjG8y1rb9AgJF2I3i64ZDtCXMa7n = ''
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named=mycima'+'__download'+LjG8y1rb9AgJF2I3i64ZDtCXMa7n
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	import JYR902sfml
	JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt(jVMHRouKgQFAESmd7B8ObTYy,r1NChsk39OMvT82YemDQnl5,'video',url)
	return
def Xwa7vgzTeb3Zy(search,Vayhmgs0IzR4P58eGJFUQvtX=''):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if search=='': search = UIf35nZEj1wylmq()
	if search=='': return
	search = search.replace(' ','+')
	jVMHRouKgQFAESmd7B8ObTYy = ['/list','/','/list/series','/list/anime','/list/tv']
	JHO207wRUyXeK = ['الكل','الأفلام','المسلسلات','الانيمي و الكرتون','البرامج تليفزيونية']
	if showDialogs:
		NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql('اختر النوع المطلوب:', JHO207wRUyXeK)
		if NljOosKT8WJBpch==-1: return
	else: NljOosKT8WJBpch = 0
	if Vayhmgs0IzR4P58eGJFUQvtX=='':
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',tle5V6jgvRfE,'','',False,'','MYCIMA-SEARCH-1st')
		Vayhmgs0IzR4P58eGJFUQvtX = aQniqUlZk8.headers['Location']
		Vayhmgs0IzR4P58eGJFUQvtX = Vayhmgs0IzR4P58eGJFUQvtX.strip('/')
	M08MPGgsh4n5rKe = Vayhmgs0IzR4P58eGJFUQvtX+'/search/'+search+jVMHRouKgQFAESmd7B8ObTYy[NljOosKT8WJBpch]
	uyt3pAHZk4(M08MPGgsh4n5rKe)
	return
def L1FsQxw6Afb7pcCe9Tr3qizXZ(wxKkOYrPef6FnEh,filter):
	if '??' in wxKkOYrPef6FnEh: url = wxKkOYrPef6FnEh.split('//getposts??')[0]
	else: url = wxKkOYrPef6FnEh
	filter = filter.replace('_FORGETRESULTS_','')
	type,filter = filter.split('___',1)
	if filter=='': ydL2RstfT9BA3Hpe1SZIq,l3Uo4ThenPyJMua = '',''
	else: ydL2RstfT9BA3Hpe1SZIq,l3Uo4ThenPyJMua = filter.split('___')
	if type=='CATEGORIES':
		if GKp3oxlZhvX[0]+'==' not in ydL2RstfT9BA3Hpe1SZIq: cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = GKp3oxlZhvX[0]
		for AudBQkLFsrHKicIogThZyv in range(len(GKp3oxlZhvX[0:-1])):
			if GKp3oxlZhvX[AudBQkLFsrHKicIogThZyv]+'==' in ydL2RstfT9BA3Hpe1SZIq: cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = GKp3oxlZhvX[AudBQkLFsrHKicIogThZyv+1]
		rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&&'+cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo+'==0'
		SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&&'+cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo+'==0'
		hOSk91jGqtHsfwU2ExCV4YB = rrsgSnC5AFkbEvDPm6pyaRizM8.strip('&&')+'___'+SWxX6Q3CgwV7F.strip('&&')
		Rdgr0aTSzE5chex9W = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(l3Uo4ThenPyJMua,'modified_filters')
		M08MPGgsh4n5rKe = url+'//getposts??'+Rdgr0aTSzE5chex9W
	elif type=='FILTERS':
		jyRzHeOYXAW4oDrUS = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(ydL2RstfT9BA3Hpe1SZIq,'modified_values')
		jyRzHeOYXAW4oDrUS = BUTSkzgFC7(jyRzHeOYXAW4oDrUS)
		if l3Uo4ThenPyJMua!='': l3Uo4ThenPyJMua = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(l3Uo4ThenPyJMua,'modified_filters')
		if l3Uo4ThenPyJMua=='': M08MPGgsh4n5rKe = url
		else: M08MPGgsh4n5rKe = url+'//getposts??'+l3Uo4ThenPyJMua
		FF976NUWy3wVxBvP = RRpH79m8XhV6Sx4vIuwAyOlj(M08MPGgsh4n5rKe,wxKkOYrPef6FnEh)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'أظهار قائمة الفيديو التي تم اختيارها ',FF976NUWy3wVxBvP,361,'','','filters')
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+' [[   '+jyRzHeOYXAW4oDrUS+'   ]]',FF976NUWy3wVxBvP,361,'','','filters')
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',url,'','','','','MYCIMA-FILTERS_MENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2.replace('\\"','"').replace('\\/','/')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<mycima--filter(.*?)</mycima--filter>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not TIkiozSLCv6werb97mHQ0q4y3: return
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	H8n4oVq07uvJjCOwgzbyf6XR9Fs = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('taxonomy="(.*?)".*?<span>(.*?)<(.*?)<filterbox',ziJLDVT8NM2QcgIpmE9A+'<filterbox',E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	dict = {}
	for eFmOUji0173K,name,ziJLDVT8NM2QcgIpmE9A in H8n4oVq07uvJjCOwgzbyf6XR9Fs:
		name = zKGXT5sJeRq(name)
		if 'interest' in eFmOUji0173K: continue
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-term="(.*?)".*?<txt>(.*?)</txt>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if '==' not in M08MPGgsh4n5rKe: M08MPGgsh4n5rKe = url
		if type=='CATEGORIES':
			if cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo!=eFmOUji0173K: continue
			elif len(items)<=1:
				if eFmOUji0173K==GKp3oxlZhvX[-1]: uyt3pAHZk4(M08MPGgsh4n5rKe)
				else: L1FsQxw6Afb7pcCe9Tr3qizXZ(M08MPGgsh4n5rKe,'CATEGORIES___'+hOSk91jGqtHsfwU2ExCV4YB)
				return
			else:
				FF976NUWy3wVxBvP = RRpH79m8XhV6Sx4vIuwAyOlj(M08MPGgsh4n5rKe,wxKkOYrPef6FnEh)
				if eFmOUji0173K==GKp3oxlZhvX[-1]:
					tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع',FF976NUWy3wVxBvP,361,'','','filters')
				else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع',M08MPGgsh4n5rKe,364,'','',hOSk91jGqtHsfwU2ExCV4YB)
		elif type=='FILTERS':
			rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&&'+eFmOUji0173K+'==0'
			SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&&'+eFmOUji0173K+'==0'
			hOSk91jGqtHsfwU2ExCV4YB = rrsgSnC5AFkbEvDPm6pyaRizM8+'___'+SWxX6Q3CgwV7F
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+name+': الجميع',M08MPGgsh4n5rKe,365,'','',hOSk91jGqtHsfwU2ExCV4YB+'_FORGETRESULTS_')
		dict[eFmOUji0173K] = {}
		for hht0cpXxWw2OzFS1jnUGebkJLBd85,e0i4nPhusqdTaG in items:
			name = zKGXT5sJeRq(name)
			e0i4nPhusqdTaG = zKGXT5sJeRq(e0i4nPhusqdTaG)
			if hht0cpXxWw2OzFS1jnUGebkJLBd85=='r' or hht0cpXxWw2OzFS1jnUGebkJLBd85=='nc-17': continue
			if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in e0i4nPhusqdTaG.lower() for hht0cpXxWw2OzFS1jnUGebkJLBd85 in ZLKHfqMEUdRupD): continue
			if 'http' in e0i4nPhusqdTaG: continue
			if 'الكل' in e0i4nPhusqdTaG: continue
			if 'n-a' in hht0cpXxWw2OzFS1jnUGebkJLBd85: continue
			if e0i4nPhusqdTaG=='': e0i4nPhusqdTaG = hht0cpXxWw2OzFS1jnUGebkJLBd85
			RwcFvrfJ2ANZSizC6bqKeEo1UDdIQ = e0i4nPhusqdTaG
			O4KxfYcQGenF = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<name>(.*?)</name>',e0i4nPhusqdTaG,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if O4KxfYcQGenF: RwcFvrfJ2ANZSizC6bqKeEo1UDdIQ = O4KxfYcQGenF[0]
			neZQycYAFqxLzkPhEWvM = name+': '+RwcFvrfJ2ANZSizC6bqKeEo1UDdIQ
			dict[eFmOUji0173K][hht0cpXxWw2OzFS1jnUGebkJLBd85] = neZQycYAFqxLzkPhEWvM
			rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&&'+eFmOUji0173K+'=='+RwcFvrfJ2ANZSizC6bqKeEo1UDdIQ
			SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&&'+eFmOUji0173K+'=='+hht0cpXxWw2OzFS1jnUGebkJLBd85
			RtPpz8FAEjIxU = rrsgSnC5AFkbEvDPm6pyaRizM8+'___'+SWxX6Q3CgwV7F
			if type=='FILTERS':
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+neZQycYAFqxLzkPhEWvM,url,365,'','',RtPpz8FAEjIxU+'_FORGETRESULTS_')
			elif type=='CATEGORIES' and GKp3oxlZhvX[-2]+'==' in ydL2RstfT9BA3Hpe1SZIq:
				Rdgr0aTSzE5chex9W = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(SWxX6Q3CgwV7F,'modified_filters')
				TW6JIBgC971tjOE = url+'//getposts??'+Rdgr0aTSzE5chex9W
				FF976NUWy3wVxBvP = RRpH79m8XhV6Sx4vIuwAyOlj(TW6JIBgC971tjOE,wxKkOYrPef6FnEh)
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+neZQycYAFqxLzkPhEWvM,FF976NUWy3wVxBvP,361,'','','filters')
			else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+neZQycYAFqxLzkPhEWvM,url,364,'','',RtPpz8FAEjIxU)
	return
GKp3oxlZhvX = ['genre','release-year','nation']
oQnWHm8MLwx56 = ['mpaa','genre','release-year','category','Quality','interest','nation','language']
def RRpH79m8XhV6Sx4vIuwAyOlj(M08MPGgsh4n5rKe,TW6JIBgC971tjOE):
	if '/AjaxCenter/RightBar' in M08MPGgsh4n5rKe: M08MPGgsh4n5rKe = M08MPGgsh4n5rKe.replace('/AjaxCenter/RightBar','/AjaxCenter/Filtering')
	M08MPGgsh4n5rKe = M08MPGgsh4n5rKe.replace('//getposts??','::/AjaxCenter/Filtering/')
	M08MPGgsh4n5rKe = M08MPGgsh4n5rKe.replace('==','/')
	M08MPGgsh4n5rKe = M08MPGgsh4n5rKe.replace('&&','/')
	return M08MPGgsh4n5rKe
def l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(dY1a0xA6PKm7TOJSERt3sHU9Qp,mode):
	dY1a0xA6PKm7TOJSERt3sHU9Qp = dY1a0xA6PKm7TOJSERt3sHU9Qp.strip('&&')
	nvNkgT7iGQOyed,UJzegYmlGML35rasDAIx17Rhnk = {},''
	if '==' in dY1a0xA6PKm7TOJSERt3sHU9Qp:
		items = dY1a0xA6PKm7TOJSERt3sHU9Qp.split('&&')
		for hh4gUqS5JWf1saRZPXHD in items:
			DHcrLNnqExKjM8uvVlBhWd,hht0cpXxWw2OzFS1jnUGebkJLBd85 = hh4gUqS5JWf1saRZPXHD.split('==')
			nvNkgT7iGQOyed[DHcrLNnqExKjM8uvVlBhWd] = hht0cpXxWw2OzFS1jnUGebkJLBd85
	for key in oQnWHm8MLwx56:
		if key in list(nvNkgT7iGQOyed.keys()): hht0cpXxWw2OzFS1jnUGebkJLBd85 = nvNkgT7iGQOyed[key]
		else: hht0cpXxWw2OzFS1jnUGebkJLBd85 = '0'
		if '%' not in hht0cpXxWw2OzFS1jnUGebkJLBd85: hht0cpXxWw2OzFS1jnUGebkJLBd85 = TaEr2nR3f5e8oXzpy(hht0cpXxWw2OzFS1jnUGebkJLBd85)
		if mode=='modified_values' and hht0cpXxWw2OzFS1jnUGebkJLBd85!='0': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+' + '+hht0cpXxWw2OzFS1jnUGebkJLBd85
		elif mode=='modified_filters' and hht0cpXxWw2OzFS1jnUGebkJLBd85!='0': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+'&&'+key+'=='+hht0cpXxWw2OzFS1jnUGebkJLBd85
		elif mode=='all': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+'&&'+key+'=='+hht0cpXxWw2OzFS1jnUGebkJLBd85
	UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk.strip(' + ')
	UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk.strip('&&')
	return UJzegYmlGML35rasDAIx17Rhnk
# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'MOVIZLAND'
headers = { 'User-Agent' : '' }
Yc0eBRLpbCkm4gK7OqyzuHwU = '_MVZ_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
PLmnJkAzt8 = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][1]
def HgQCVwFx2Br(mode,url,text):
	if   mode==180: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==181: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url,text)
	elif mode==182: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==183: s4Bng5iAZQSTtpDw9 = btd6ag2XYUkHixqy5J7o9RfLu1MScm(url)
	elif mode==188: s4Bng5iAZQSTtpDw9 = qi6HK0RYD9G1ufo4Q3lNePB()
	elif mode==189: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def qi6HK0RYD9G1ufo4Q3lNePB():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج',message)
	return
def Or15mUj4By():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',189,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'بوكس اوفيس موفيز لاند',tle5V6jgvRfE,181,'','','box-office')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'أحدث الافلام',tle5V6jgvRfE,181,'','','latest-movies')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'تليفزيون موفيز لاند',tle5V6jgvRfE,181,'','','tv')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'الاكثر مشاهدة',tle5V6jgvRfE,181,'','','top-views')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'أقوى الافلام الحالية',tle5V6jgvRfE,181,'','','top-movies')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,tle5V6jgvRfE,'',headers,'','MOVIZLAND-MENU-1st')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<h2><a href="(.*?)".*?">(.*?)<',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,181)
	return M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
def uyt3pAHZk4(url,type=''):
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,url,'',headers,'','MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': ziJLDVT8NM2QcgIpmE9A = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)[0]
	elif type=='box-office': ziJLDVT8NM2QcgIpmE9A = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)[0]
	elif type=='top-movies': ziJLDVT8NM2QcgIpmE9A = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('btn-2-overlay(.*?)<style>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)[0]
	elif type=='top-views': ziJLDVT8NM2QcgIpmE9A = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)[0]
	elif type=='tv': ziJLDVT8NM2QcgIpmE9A = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)[0]
	else: ziJLDVT8NM2QcgIpmE9A = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
	if type in ['top-views','top-movies']:
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	else: items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	jjR8ftoEXpPxVF6JerbHZuzv7ic = []
	cFEX1lI9Wg2 = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for Q2qmuDRrC9ikcaJK7gtUHXNW,xvj7ObtqTw1IU3fQuLDC,asSviLeQ41YWRC5,iiF5czHqt6bpwKY7Alh3S1MeV in items:
		if type in ['top-views','top-movies']:
			Q2qmuDRrC9ikcaJK7gtUHXNW,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,VktWBN6gn8zSUpesvfCyia2Ajm,title = Q2qmuDRrC9ikcaJK7gtUHXNW,xvj7ObtqTw1IU3fQuLDC,asSviLeQ41YWRC5,iiF5czHqt6bpwKY7Alh3S1MeV
		else: Q2qmuDRrC9ikcaJK7gtUHXNW,title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,VktWBN6gn8zSUpesvfCyia2Ajm = Q2qmuDRrC9ikcaJK7gtUHXNW,xvj7ObtqTw1IU3fQuLDC,asSviLeQ41YWRC5,iiF5czHqt6bpwKY7Alh3S1MeV
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = BUTSkzgFC7(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.replace('?view=true','')
		title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ','').replace('بجوده ','')
		title = title.strip(' ')
		if 'الحلقة' in title or 'الحلقه' in title:
			EQw62xjXSJmzrRt = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(.*?) (الحلقة|الحلقه) \d+',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if EQw62xjXSJmzrRt:
				title = '_MOD_' + EQw62xjXSJmzrRt[0][0]
				if title not in jjR8ftoEXpPxVF6JerbHZuzv7ic:
					tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,183,Q2qmuDRrC9ikcaJK7gtUHXNW)
					jjR8ftoEXpPxVF6JerbHZuzv7ic.append(title)
		elif any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title for hht0cpXxWw2OzFS1jnUGebkJLBd85 in cFEX1lI9Wg2):
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R + '?servers=' + VktWBN6gn8zSUpesvfCyia2Ajm
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,182,Q2qmuDRrC9ikcaJK7gtUHXNW)
		else:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R + '?servers=' + VktWBN6gn8zSUpesvfCyia2Ajm
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,183,Q2qmuDRrC9ikcaJK7gtUHXNW)
	if type=='':
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('\n<li><a href="(.*?)".*?>(.*?)<',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
			title = title.replace('الصفحة ','')
			if title!='':
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,181)
	return
def btd6ag2XYUkHixqy5J7o9RfLu1MScm(url):
	M08MPGgsh4n5rKe = url.split('?servers=')[0]
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,M08MPGgsh4n5rKe,'',headers,'','MOVIZLAND-EPISODES-1st')
	ziJLDVT8NM2QcgIpmE9A = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	title,aQ0kNq9gnYBKJ5yV6oRhXZ7ImfwreT,Q2qmuDRrC9ikcaJK7gtUHXNW = ziJLDVT8NM2QcgIpmE9A[0]
	name = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="episodesNumbers"(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = BUTSkzgFC7(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			title = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(الحلقة|الحلقه)-([0-9]+)',ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('/')[-2],E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if not title: title = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('()-([0-9]+)',ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('/')[-2],E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if title: title = ' ' + title[0][1]
			else: title = ''
			title = name + ' - ' + 'الحلقة' + title
			title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,182,Q2qmuDRrC9ikcaJK7gtUHXNW)
	if not items:
		title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ','').replace('بجوده ','')
		tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,182,Q2qmuDRrC9ikcaJK7gtUHXNW)
	return
def dlropqS0vO9K7W4z(url):
	RQxVzFYm12C = url.split('?servers=')
	M08MPGgsh4n5rKe = RQxVzFYm12C[0]
	del RQxVzFYm12C[0]
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,M08MPGgsh4n5rKe,'',headers,'','MOVIZLAND-PLAY-1st')
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('font-size: 25px;" href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)[0]
	if ZCimQhV5lovgspAYzHq1Ef27u8ja4R not in RQxVzFYm12C: RQxVzFYm12C.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	jVMHRouKgQFAESmd7B8ObTYy = []
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R in RQxVzFYm12C:
		if '://moshahda.' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
			hPYHB1Jfxn0yrMbmA = ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			jVMHRouKgQFAESmd7B8ObTYy.append(hPYHB1Jfxn0yrMbmA+'?named=Main')
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R in RQxVzFYm12C:
		if '://vb.movizland.' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
			M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,'',headers,'','MOVIZLAND-PLAY-2nd')
			M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2.decode('windows-1256').encode('utf8')
			M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if TIkiozSLCv6werb97mHQ0q4y3:
				ddvlQgiwbjWhyN9Rp6DAYtC,FQLIlWJODoV26NSpzgjb3Yu = [],[]
				if len(TIkiozSLCv6werb97mHQ0q4y3)==1:
					title = ''
					ziJLDVT8NM2QcgIpmE9A = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
				else:
					for ziJLDVT8NM2QcgIpmE9A in TIkiozSLCv6werb97mHQ0q4y3:
						f9AzGuXj0qgcNTy1 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
						if f9AzGuXj0qgcNTy1: ziJLDVT8NM2QcgIpmE9A = 'src="/uploads/13721411411.png"  \n  ' + f9AzGuXj0qgcNTy1[0][1]
						f9AzGuXj0qgcNTy1 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
						if f9AzGuXj0qgcNTy1: ziJLDVT8NM2QcgIpmE9A = 'src="/uploads/13721411411.png"  \n  ' + f9AzGuXj0qgcNTy1[0]
						f9AzGuXj0qgcNTy1 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
						if f9AzGuXj0qgcNTy1: ziJLDVT8NM2QcgIpmE9A = f9AzGuXj0qgcNTy1[0] + '  \n  src="/uploads/13721411411.png"'
						zXAgsZtfLIdox35pGqKb0cj1HY = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<(.*?)http://up.movizland.(online|com)/uploads/',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
						title = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('> *([^<>]+) *<',zXAgsZtfLIdox35pGqKb0cj1HY[0][0],E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
						title = ' '.join(title)
						title = title.strip(' ')
						title = title.replace('  ',' ').replace('  ',' ').replace('  ',' ').replace('  ',' ').replace('  ',' ')
						ddvlQgiwbjWhyN9Rp6DAYtC.append(title)
					NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql('أختر الفيديو المطلوب:', ddvlQgiwbjWhyN9Rp6DAYtC)
					if NljOosKT8WJBpch == -1 : return
					title = ddvlQgiwbjWhyN9Rp6DAYtC[NljOosKT8WJBpch]
					ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[NljOosKT8WJBpch]
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(http://moshahda\..*?/\w+.html)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
				sSAYLUzt8cEdqPVpm2 = ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]
				jVMHRouKgQFAESmd7B8ObTYy.append(sSAYLUzt8cEdqPVpm2+'?named=Forum')
				ziJLDVT8NM2QcgIpmE9A = ziJLDVT8NM2QcgIpmE9A.replace('ـ','')
				ziJLDVT8NM2QcgIpmE9A = ziJLDVT8NM2QcgIpmE9A.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				ziJLDVT8NM2QcgIpmE9A = ziJLDVT8NM2QcgIpmE9A.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				ziJLDVT8NM2QcgIpmE9A = ziJLDVT8NM2QcgIpmE9A.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				ziJLDVT8NM2QcgIpmE9A = ziJLDVT8NM2QcgIpmE9A.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				ziJLDVT8NM2QcgIpmE9A = ziJLDVT8NM2QcgIpmE9A.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				ziJLDVT8NM2QcgIpmE9A = ziJLDVT8NM2QcgIpmE9A.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				d34Jw8a5GBDFn = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
				for M6Muej2U9Tg3bZSRnQt8cIDvrHmEJ in d34Jw8a5GBDFn:
					type = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(' typetype="(.*?)" ',M6Muej2U9Tg3bZSRnQt8cIDvrHmEJ)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = ''
					items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',M6Muej2U9Tg3bZSRnQt8cIDvrHmEJ,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
					for LGrAUaPm3tC4S76kH9XWvc,ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
						title = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(\w+[ \w]*)<',LGrAUaPm3tC4S76kH9XWvc)
						title = title[-1]
						ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R + '?named=' + title + type
						jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	TW6JIBgC971tjOE = M08MPGgsh4n5rKe.replace(tle5V6jgvRfE,PLmnJkAzt8)
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,TW6JIBgC971tjOE,'',headers,'','MOVIZLAND-PLAY-3rd')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('" href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if items:
		lL9FKdpUiaBO = items[-1]
		jVMHRouKgQFAESmd7B8ObTYy.append(lL9FKdpUiaBO+'?named=Mobile')
	import JYR902sfml
	JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt(jVMHRouKgQFAESmd7B8ObTYy,r1NChsk39OMvT82YemDQnl5,'video',url)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if search=='': search = UIf35nZEj1wylmq()
	if search=='': return
	search = search.replace(' ','+')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,tle5V6jgvRfE,'',headers,'','MOVIZLAND-SEARCH-1st')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<option value="(.*?)">(.*?)</option>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	WWrz2TVFs1OLRk4f = [ '' ]
	KEeG7unfTsxbjdkHI = [ 'الكل وبدون فلتر' ]
	for cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo,title in items:
		WWrz2TVFs1OLRk4f.append(cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo)
		KEeG7unfTsxbjdkHI.append(title)
	if cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo:
		NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql('اختر الفلتر المناسب:', KEeG7unfTsxbjdkHI)
		if NljOosKT8WJBpch == -1 : return
		cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = WWrz2TVFs1OLRk4f[NljOosKT8WJBpch]
	else: cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = ''
	url = tle5V6jgvRfE + '/?s='+search+'&mcat='+cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo
	uyt3pAHZk4(url)
	return
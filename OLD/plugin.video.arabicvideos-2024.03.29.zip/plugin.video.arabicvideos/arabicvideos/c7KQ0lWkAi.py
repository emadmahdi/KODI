# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'SHOOFMAX'
Yc0eBRLpbCkm4gK7OqyzuHwU = '_SHM_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
PLmnJkAzt8 = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][1]
VAolO02vjbQ = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][2]
def HgQCVwFx2Br(mode,url,text):
	if   mode==50: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==51: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url)
	elif mode==52: s4Bng5iAZQSTtpDw9 = btd6ag2XYUkHixqy5J7o9RfLu1MScm(url)
	elif mode==53: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==55: s4Bng5iAZQSTtpDw9 = pfywBg3R6d8Jio4rCce0q1()
	elif mode==56: s4Bng5iAZQSTtpDw9 = lI7S3ibEzxO()
	elif mode==57: s4Bng5iAZQSTtpDw9 = BZvf1TM8A7tGPuoUznF(url,1)
	elif mode==58: s4Bng5iAZQSTtpDw9 = BZvf1TM8A7tGPuoUznF(url,2)
	elif mode==59: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',59,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'المسلسلات','',56)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'الافلام','',55)
	return ''
def pfywBg3R6d8Jio4rCce0q1():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'احدث الافلام',tle5V6jgvRfE+'/movie/1/newest',51)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'افلام رائجة',tle5V6jgvRfE+'/movie/1/popular',51)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'اخر اضافات الافلام',tle5V6jgvRfE+'/movie/1/latest',51)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'افلام كلاسيكية',tle5V6jgvRfE+'/movie/1/classic',51)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'اختيار افلام مرتبة بسنة الانتاج',tle5V6jgvRfE+'/movie/1/yop',57)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'اختيار افلام مرتبة بالافضل تقييم',tle5V6jgvRfE+'/movie/1/review',57)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'اختيار افلام مرتبة بالاكثر مشاهدة',tle5V6jgvRfE+'/movie/1/views',57)
	return
def lI7S3ibEzxO():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'احدث المسلسلات',tle5V6jgvRfE+'/series/1/newest',51)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مسلسلات رائجة',tle5V6jgvRfE+'/series/1/popular',51)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'اخر اضافات المسلسلات',tle5V6jgvRfE+'/series/1/latest',51)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مسلسلات كلاسيكية',tle5V6jgvRfE+'/series/1/classic',51)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'اختيار مسلسلات مرتبة بسنة الانتاج',tle5V6jgvRfE+'/series/1/yop',57)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'اختيار مسلسلات مرتبة بالافضل تقييم',tle5V6jgvRfE+'/series/1/review',57)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'اختيار مسلسلات مرتبة بالاكثر مشاهدة',tle5V6jgvRfE+'/series/1/views',57)
	return
def uyt3pAHZk4(url):
	if '?' in url:
		oBzGqDUAi7KaL8vFdZtP9XIcf = url.split('?')
		url = oBzGqDUAi7KaL8vFdZtP9XIcf[0]
		filter = '?' + TaEr2nR3f5e8oXzpy(oBzGqDUAi7KaL8vFdZtP9XIcf[1],'=&:/%')
	else: filter = ''
	oBzGqDUAi7KaL8vFdZtP9XIcf = url.split('/')
	sort,tsMKaFVh1ZN2BIXEcvTejxR5DP,type = oBzGqDUAi7KaL8vFdZtP9XIcf[-1],oBzGqDUAi7KaL8vFdZtP9XIcf[-2],oBzGqDUAi7KaL8vFdZtP9XIcf[-3]
	if sort in ['yop','review','views']:
		if type=='movie': EDOvRaS4gn2U7ZJ63oI5Mu='فيلم'
		elif type=='series': EDOvRaS4gn2U7ZJ63oI5Mu='مسلسل'
		url = tle5V6jgvRfE + '/genre/filter/' + TaEr2nR3f5e8oXzpy(EDOvRaS4gn2U7ZJ63oI5Mu) + '/' + tsMKaFVh1ZN2BIXEcvTejxR5DP + '/' + sort + filter
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,url,'','','','SHOOFMAX-TITLES-1st')
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		Y4yjgJ5EhX3DFs1Cn6mkUcld=0
		for id,title,HnLUaxz3YuctPlDdrKiW,Q2qmuDRrC9ikcaJK7gtUHXNW in items:
			Y4yjgJ5EhX3DFs1Cn6mkUcld += 1
			Q2qmuDRrC9ikcaJK7gtUHXNW = VAolO02vjbQ + '/v2/img/program/main/' + Q2qmuDRrC9ikcaJK7gtUHXNW + '-2.jpg'
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE + '/program/' + id
			if type=='movie': tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,53,Q2qmuDRrC9ikcaJK7gtUHXNW)
			if type=='series': tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مسلسل '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?ep='+HnLUaxz3YuctPlDdrKiW+'='+title+'='+Q2qmuDRrC9ikcaJK7gtUHXNW,52,Q2qmuDRrC9ikcaJK7gtUHXNW)
	else:
		if type=='movie': EDOvRaS4gn2U7ZJ63oI5Mu='movies'
		elif type=='series': EDOvRaS4gn2U7ZJ63oI5Mu='series'
		url = PLmnJkAzt8 + '/json/selected/' + sort + '-' + EDOvRaS4gn2U7ZJ63oI5Mu + '-WW.json'
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,url,'','','','SHOOFMAX-TITLES-2nd')
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		Y4yjgJ5EhX3DFs1Cn6mkUcld=0
		for id,HnLUaxz3YuctPlDdrKiW,Q2qmuDRrC9ikcaJK7gtUHXNW,title in items:
			Y4yjgJ5EhX3DFs1Cn6mkUcld += 1
			Q2qmuDRrC9ikcaJK7gtUHXNW = PLmnJkAzt8 + '/img/program/' + Q2qmuDRrC9ikcaJK7gtUHXNW + '-2.jpg'
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE + '/program/' + id
			if type=='movie': tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,53,Q2qmuDRrC9ikcaJK7gtUHXNW)
			elif type=='series': tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مسلسل '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?ep='+HnLUaxz3YuctPlDdrKiW+'='+title+'='+Q2qmuDRrC9ikcaJK7gtUHXNW,52,Q2qmuDRrC9ikcaJK7gtUHXNW)
	title='صفحة '
	if Y4yjgJ5EhX3DFs1Cn6mkUcld==16:
		for qq4r6dcPDb in range(1,13) :
			if not tsMKaFVh1ZN2BIXEcvTejxR5DP==str(qq4r6dcPDb):
				url = tle5V6jgvRfE+'/genre/filter/'+type+'/'+str(qq4r6dcPDb)+'/'+sort + filter
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title+str(qq4r6dcPDb),url,51)
	return
def btd6ag2XYUkHixqy5J7o9RfLu1MScm(url):
	oBzGqDUAi7KaL8vFdZtP9XIcf = url.split('=')
	HnLUaxz3YuctPlDdrKiW = int(oBzGqDUAi7KaL8vFdZtP9XIcf[1])
	name = BUTSkzgFC7(oBzGqDUAi7KaL8vFdZtP9XIcf[2])
	name = name.replace('_MOD_مسلسل ','')
	Q2qmuDRrC9ikcaJK7gtUHXNW = oBzGqDUAi7KaL8vFdZtP9XIcf[3]
	url = url.split('?')[0]
	if HnLUaxz3YuctPlDdrKiW==0:
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,url,'','','','SHOOFMAX-EPISODES-1st')
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<select(.*?)</select>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('option value="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		HnLUaxz3YuctPlDdrKiW = int(items[-1])
	for EQw62xjXSJmzrRt in range(HnLUaxz3YuctPlDdrKiW,0,-1):
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = url + '?ep=' + str(EQw62xjXSJmzrRt)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(EQw62xjXSJmzrRt)
		tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,53,Q2qmuDRrC9ikcaJK7gtUHXNW)
	return
def dlropqS0vO9K7W4z(url):
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,url,'','','','SHOOFMAX-PLAY-1st')
	UUxZK2r0L1XzTP = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if UUxZK2r0L1XzTP:
		w6vebiEZtpCjJcILP8Skx5rHn = UUxZK2r0L1XzTP[1].replace('T','    ')
		tehb3k5a2PufGOdBIUw8j('','','رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+'\n'+w6vebiEZtpCjJcILP8Skx5rHn)
		return
	rCUlQ1Dtz07jRwpb6cf,JsPjCpKg30McGi9z8eour = [],[]
	qq0YIKoXjUt3FO = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('var origin_link = "(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)[0]
	ODzdkyBsvnQV14LU6Ww5N = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('var backup_origin_link = "(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)[0]
	cc0O1M4e5jtfoq = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('hls: (.*?)_link\+"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for vMSQsdJ0gCrh7ztnR96yDXqOYaj,ZCimQhV5lovgspAYzHq1Ef27u8ja4R in cc0O1M4e5jtfoq:
		if 'backup' in vMSQsdJ0gCrh7ztnR96yDXqOYaj:
			vMSQsdJ0gCrh7ztnR96yDXqOYaj = 'backup server'
			url = ODzdkyBsvnQV14LU6Ww5N + ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		else:
			vMSQsdJ0gCrh7ztnR96yDXqOYaj = 'main server'
			url = qq0YIKoXjUt3FO + ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		if '.m3u8' in url:
			rCUlQ1Dtz07jRwpb6cf.append(url)
			JsPjCpKg30McGi9z8eour.append('m3u8  '+vMSQsdJ0gCrh7ztnR96yDXqOYaj)
	cc0O1M4e5jtfoq = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	cc0O1M4e5jtfoq += E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for vMSQsdJ0gCrh7ztnR96yDXqOYaj,ZCimQhV5lovgspAYzHq1Ef27u8ja4R in cc0O1M4e5jtfoq:
		filename = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('/')[-1]
		filename = filename.replace('fallback','')
		filename = filename.replace('.mp4','')
		filename = filename.replace('-','')
		if 'backup' in vMSQsdJ0gCrh7ztnR96yDXqOYaj:
			vMSQsdJ0gCrh7ztnR96yDXqOYaj = 'backup server'
			url = ODzdkyBsvnQV14LU6Ww5N + ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		else:
			vMSQsdJ0gCrh7ztnR96yDXqOYaj = 'main server'
			url = qq0YIKoXjUt3FO + ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		rCUlQ1Dtz07jRwpb6cf.append(url)
		JsPjCpKg30McGi9z8eour.append('mp4  '+vMSQsdJ0gCrh7ztnR96yDXqOYaj+'  '+filename)
	NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql('Select Video Quality:', JsPjCpKg30McGi9z8eour)
	if NljOosKT8WJBpch == -1 : return
	url = rCUlQ1Dtz07jRwpb6cf[NljOosKT8WJBpch]
	pSAuLjYqhgc9brWFKs7Pa4J(url,r1NChsk39OMvT82YemDQnl5,'video')
	return
def BZvf1TM8A7tGPuoUznF(url,type):
	if 'series' in url: M08MPGgsh4n5rKe = tle5V6jgvRfE + '/genre/مسلسل'
	else: M08MPGgsh4n5rKe = tle5V6jgvRfE + '/genre/فيلم'
	M08MPGgsh4n5rKe = TaEr2nR3f5e8oXzpy(M08MPGgsh4n5rKe)
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,M08MPGgsh4n5rKe,'','','','SHOOFMAX-FILTERS-1st')
	if type==1: TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('subgenre(.*?)div',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	elif type==2: TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('country(.*?)div',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('option value="(.*?)">(.*?)</option',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if type==1:
		for jjs7J0fgcNowI,title in items:
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url+'?subgenre='+jjs7J0fgcNowI,58)
	elif type==2:
		url,jjs7J0fgcNowI = url.split('?')
		for ir0ULhG6nfRXJHkpAgbF,title in items:
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url+'?country='+ir0ULhG6nfRXJHkpAgbF+'&'+jjs7J0fgcNowI,51)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if not search: search = UIf35nZEj1wylmq()
	if not search: return
	DbEfLQSBFCTt2mMqvrsIVnjJ6 = search.replace(' ','%20')
	url = tle5V6jgvRfE+'/search?q='+DbEfLQSBFCTt2mMqvrsIVnjJ6
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','',True,'','SHOOFMAX-SEARCH-2nd')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('general-body(.*?)search-bottom-padding',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if items:
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title in items:
			url = tle5V6jgvRfE + ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+TaEr2nR3f5e8oXzpy(title)+'='+Q2qmuDRrC9ikcaJK7gtUHXNW
					tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,52,Q2qmuDRrC9ikcaJK7gtUHXNW)
				else:
					title = '_MOD_فيلم '+title
					tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,53,Q2qmuDRrC9ikcaJK7gtUHXNW)
	return
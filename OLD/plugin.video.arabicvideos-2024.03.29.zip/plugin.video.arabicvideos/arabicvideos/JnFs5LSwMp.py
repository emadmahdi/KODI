# -*- coding: utf-8 -*-
import sys as EAPND6zHKrMRuBc91tInYohsl0ywa
ttRJUcM0Tbr7gXN5x = EAPND6zHKrMRuBc91tInYohsl0ywa.version_info [0] == 2
Z2h7adALoKv4UPc1y = 2048
K2KPeD6VyEaQ = 7
def dC3HqaFgt6QYG4 (jZYXLbSUsQp5uk1tyzBAN7Hm):
	global ZeIJ6GDodMSzFut4jc05AK3OlhETR
	HY5UkLeNComBIMQPASnxph7 = ord (jZYXLbSUsQp5uk1tyzBAN7Hm [-1])
	PlVdbOK5hqks = jZYXLbSUsQp5uk1tyzBAN7Hm [:-1]
	prvC9qsF5RtBXHiaT3PwdJ = HY5UkLeNComBIMQPASnxph7 % len (PlVdbOK5hqks)
	LQB6POHcivdw87pk09ts2XMyf1IVEh = PlVdbOK5hqks [:prvC9qsF5RtBXHiaT3PwdJ] + PlVdbOK5hqks [prvC9qsF5RtBXHiaT3PwdJ:]
	if ttRJUcM0Tbr7gXN5x:
		Gn0XReKiJFMEsUxN531yAlI7S = unicode () .join ([unichr (ord (AitBMapzjZGc4u) - Z2h7adALoKv4UPc1y - (KQsX4n7jEogiLuJz + HY5UkLeNComBIMQPASnxph7) % K2KPeD6VyEaQ) for KQsX4n7jEogiLuJz, AitBMapzjZGc4u in enumerate (LQB6POHcivdw87pk09ts2XMyf1IVEh)])
	else:
		Gn0XReKiJFMEsUxN531yAlI7S = str () .join ([chr (ord (AitBMapzjZGc4u) - Z2h7adALoKv4UPc1y - (KQsX4n7jEogiLuJz + HY5UkLeNComBIMQPASnxph7) % K2KPeD6VyEaQ) for KQsX4n7jEogiLuJz, AitBMapzjZGc4u in enumerate (LQB6POHcivdw87pk09ts2XMyf1IVEh)])
	return eval (Gn0XReKiJFMEsUxN531yAlI7S)
I7N2lHpGfLPkwKxbOu6raYUgc5,QmoEjB3hLIw,WbM6qAjrn7fEXGZw=dC3HqaFgt6QYG4,dC3HqaFgt6QYG4,dC3HqaFgt6QYG4
bbqAtUz36RPGVTvCkejpJXQB,MM564HfnUV0XIR,YDC9i52g6e8XL7GxvIFnSKWsolpr=WbM6qAjrn7fEXGZw,QmoEjB3hLIw,I7N2lHpGfLPkwKxbOu6raYUgc5
YZFXwtrfK8uhzV4LlMEqgnCQyO9,tmcuvd397wjGXeWoDHMNpFB5h2VK,Ox8k6IdtuPaG3NlApQK52oYwM=YDC9i52g6e8XL7GxvIFnSKWsolpr,MM564HfnUV0XIR,bbqAtUz36RPGVTvCkejpJXQB
GGCQK6OAtZUXRhvkgJm,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6,Gk98CL5nXZEN=Ox8k6IdtuPaG3NlApQK52oYwM,tmcuvd397wjGXeWoDHMNpFB5h2VK,YZFXwtrfK8uhzV4LlMEqgnCQyO9
dEUYJjrhsaPXNo,wx18CTJPZ5,cWfQ64kVCqxhwvSy5P7irHI1oes3=Gk98CL5nXZEN,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6,GGCQK6OAtZUXRhvkgJm
qFRrj7ayBKbOsHGSXz,SIDG7cnzAaUpkwmNde19ZsBqQ3Hh,tOdiG2HWFRBXg1sUh=cWfQ64kVCqxhwvSy5P7irHI1oes3,wx18CTJPZ5,dEUYJjrhsaPXNo
smpniPDOhfwI3H4v7c6TG,CIcPowhneWs5tN3,zxwIDBrPiXjKlsYkfg0AGaUZSyW2co=tOdiG2HWFRBXg1sUh,SIDG7cnzAaUpkwmNde19ZsBqQ3Hh,qFRrj7ayBKbOsHGSXz
r6juULGQtnExAko38BZ5Y,NNmirJKPp5nWjfC,FeyZbj8tDil0nSHzTwfsUJ9=zxwIDBrPiXjKlsYkfg0AGaUZSyW2co,CIcPowhneWs5tN3,smpniPDOhfwI3H4v7c6TG
S26SnaqcM9XwK8PVphJDv5,CgPbwXm1RilpJUSGHLhy,NxsKJnLFEZ9OHXf1h=FeyZbj8tDil0nSHzTwfsUJ9,NNmirJKPp5nWjfC,r6juULGQtnExAko38BZ5Y
Kwl07iYTtDLN3zP,uAl3gHavMJZL4xmNe62nDiBoQ,ta478EuZQJIWhgBnsf6iU=NxsKJnLFEZ9OHXf1h,CgPbwXm1RilpJUSGHLhy,S26SnaqcM9XwK8PVphJDv5
EAw9bg4rT3Bd8tjSkO,ItgK5FqGDz2Rf7mAJkbT,FFVuCHLxhZmkEGJQDitreaygc2f4AS=ta478EuZQJIWhgBnsf6iU,uAl3gHavMJZL4xmNe62nDiBoQ,Kwl07iYTtDLN3zP
import xbmc as oos8ymFi9CN2z1jXcR,re as E1E4YjPysoQMVdlu39mSTcWKFkpa7v,sys as EAPND6zHKrMRuBc91tInYohsl0ywa,xbmcaddon as qH2TpnmA46PMCfY5dsr,random as BBioyg7XVR,os as K3hFytImeYMkJBC,xbmcvfs as G158kjAPyw7CSHxKlO0Fn,time as w6vebiEZtpCjJcILP8Skx5rHn,pickle as nn7DVGBZsq0,zlib as LPeE7ZjVag6xWTydcwQb,xbmcgui as ZuEAJR1lNHkUf0,xbmcplugin as I9AOhSdTGW4rX1yPc3oKQHnkJEe,sqlite3 as iZv4fPkF5Trx1L8EsVHC2S,traceback as oo5q9yuEdbCeOSxfzJcw,threading as mZHwnlsXWDfV3ri4M
r1NChsk39OMvT82YemDQnl5 = bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠫࡑࡏࡂࡔࡑࡑࡉࠬਰ")
U0AdbxBVqaQOwTJIcSgN1z9iM7r = qH2TpnmA46PMCfY5dsr.Addon().getAddonInfo(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠬࡶࡡࡵࡪࠪ਱"))
fZJr6ayAqiVdEDmQ4FnLczRKxB3W = K3hFytImeYMkJBC.path.join(U0AdbxBVqaQOwTJIcSgN1z9iM7r,r6juULGQtnExAko38BZ5Y(u"࠭ࡰࡢࡥ࡮ࡥ࡬࡫ࡳࠨਲ"))
EAPND6zHKrMRuBc91tInYohsl0ywa.path.append(fZJr6ayAqiVdEDmQ4FnLczRKxB3W)
iAqf1sZuQ0wXEndaG = oos8ymFi9CN2z1jXcR.getInfoLabel(tOdiG2HWFRBXg1sUh(u"ࠢࡔࡻࡶࡸࡪࡳ࠮ࡃࡷ࡬ࡰࡩ࡜ࡥࡳࡵ࡬ࡳࡳࠨਲ਼"))
wH3qxmuXBTeak = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(ta478EuZQJIWhgBnsf6iU(u"ࠨࠪ࡟ࡨࡡࡪ࡜࠯࡞ࡧ࠭ࠬ਴"),iAqf1sZuQ0wXEndaG,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
wH3qxmuXBTeak = float(wH3qxmuXBTeak[uAl3gHavMJZL4xmNe62nDiBoQ(u"࠱௴")])
ASqn1tDiZQwk5CEBFh23eMcGKOxmP7 = oos8ymFi9CN2z1jXcR.Player
HDSs6LB1wArQcd = ZuEAJR1lNHkUf0.WindowXMLDialog
vciEXHThAPto76QIR2pK = wH3qxmuXBTeak<smpniPDOhfwI3H4v7c6TG(u"࠳࠼௵")
wvkR1es6d0SrjxKt5FZTMUWz7a = wH3qxmuXBTeak>QmoEjB3hLIw(u"࠴࠼࠳࠿࠹௶")
if wvkR1es6d0SrjxKt5FZTMUWz7a:
	afzQCi9FIk01jct3s7xML8BNrunop = oos8ymFi9CN2z1jXcR.LOGINFO
	W3oZ8vhLnsOdIaDp6qeN214kcJCVz,HwksZdFnbNg3Pr = qFRrj7ayBKbOsHGSXz(u"ࡷࠪࡠࡺ࠸࠰࠳ࡣࠪਵ"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࡸࠫࡡࡻ࠲࠱࠴ࡥࠫਸ਼")
	T8a2NHqxtncFyRhWp9Mwd = G158kjAPyw7CSHxKlO0Fn.translatePath(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡵࡧࡰࡴࠬ਷"))
	from urllib.parse import unquote as _7W4AdmwTeEB5PRvsixprG3uKchO
else:
	afzQCi9FIk01jct3s7xML8BNrunop = oos8ymFi9CN2z1jXcR.LOGNOTICE
	W3oZ8vhLnsOdIaDp6qeN214kcJCVz,HwksZdFnbNg3Pr = CIcPowhneWs5tN3(u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡦ࠭ਸ").encode(cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠭ࡵࡵࡨ࠻ࠫਹ")),Gk98CL5nXZEN(u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡢࠨ਺").encode(ItgK5FqGDz2Rf7mAJkbT(u"ࠨࡷࡷࡪ࠽࠭਻"))
	T8a2NHqxtncFyRhWp9Mwd = oos8ymFi9CN2z1jXcR.translatePath(Kwl07iYTtDLN3zP(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡺࡥ࡮ࡲ਼ࠪ"))
	from urllib import unquote as _7W4AdmwTeEB5PRvsixprG3uKchO
A91kMODhcab7Cn3KJG4tSeYzBoL = ta478EuZQJIWhgBnsf6iU(u"࠺࠵௷")
X6q8xOh3QUvB5D1dZJnmRC9TzauGrL = YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠻࠶௸")*A91kMODhcab7Cn3KJG4tSeYzBoL
GUtCc6yRsZejIOfo084XnPW = EAw9bg4rT3Bd8tjSkO(u"࠸࠴௹")*X6q8xOh3QUvB5D1dZJnmRC9TzauGrL
HH3aYvhpAzVxZk6oynijNuJ8M = SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠳࠱௺")*GUtCc6yRsZejIOfo084XnPW
MMLimtJ8xTFAq9Z012nroaju3de = qFRrj7ayBKbOsHGSXz(u"࠱௻")
RvKQX7HgZ6faBueLsMjxGtPobTd0 = r6juULGQtnExAko38BZ5Y(u"࠵࠳௼")*A91kMODhcab7Cn3KJG4tSeYzBoL
jEPuRTVbZg4MCimJxzf3I6wFa = GGCQK6OAtZUXRhvkgJm(u"࠵௽")*X6q8xOh3QUvB5D1dZJnmRC9TzauGrL
Yv7e6ixHfZIPrmMOy3ozwJu2 = bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠵࠻௾")*X6q8xOh3QUvB5D1dZJnmRC9TzauGrL
xgFTDVS7lf5Us6aj = tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠸௿")*GUtCc6yRsZejIOfo084XnPW
WA14geuaxzJQ0ND3q8f2hdbk = SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠹࠰ఀ")*GUtCc6yRsZejIOfo084XnPW
D0vjfyxKZuP7pXknq62MwFYU = wx18CTJPZ5(u"࠱࠳ఁ")*HH3aYvhpAzVxZk6oynijNuJ8M
ddEW38kMhf9mZGC6ePnFS = CIcPowhneWs5tN3(u"࠲ం")*X6q8xOh3QUvB5D1dZJnmRC9TzauGrL
aZhcuMGisIkl4npqDoJSrWy5fExX = EAPND6zHKrMRuBc91tInYohsl0ywa.argv[S26SnaqcM9XwK8PVphJDv5(u"࠲ః")].split(S26SnaqcM9XwK8PVphJDv5(u"ࠪ࠳ࠬ਽"))[ItgK5FqGDz2Rf7mAJkbT(u"࠵ఄ")]
KKtWUT6l8S = int(EAPND6zHKrMRuBc91tInYohsl0ywa.argv[cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠵అ")])
mpUuAaIVfPRoQEligGywDYz1 = EAPND6zHKrMRuBc91tInYohsl0ywa.argv[YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠷ఆ")]
YvVkFoEM0pl8JCGaeZ3XU = aZhcuMGisIkl4npqDoJSrWy5fExX.split(QmoEjB3hLIw(u"ࠫ࠳࠭ਾ"))[SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠸ఇ")]
VnhK9wvHBGuo1fei8DXQ02yFZtsWE = oos8ymFi9CN2z1jXcR.getInfoLabel(ta478EuZQJIWhgBnsf6iU(u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡇࡤࡥࡱࡱ࡚ࡪࡸࡳࡪࡱࡱࠬࠬਿ")+aZhcuMGisIkl4npqDoJSrWy5fExX+CgPbwXm1RilpJUSGHLhy(u"࠭ࠩࠨੀ"))
llrbyaFHOt9e = K3hFytImeYMkJBC.path.join(T8a2NHqxtncFyRhWp9Mwd,aZhcuMGisIkl4npqDoJSrWy5fExX)
WSgQvHLx9uOKTksaCt2JchldRj = K3hFytImeYMkJBC.path.join(llrbyaFHOt9e,wx18CTJPZ5(u"ࠧ࡮ࡣ࡬ࡲࡩࡧࡴࡢ࠰ࡧࡦࠬੁ"))
D5q7g8N0XowOn2Q = K3hFytImeYMkJBC.path.join(llrbyaFHOt9e,wx18CTJPZ5(u"ࠨ࡮ࡤࡷࡹࡼࡩࡥࡧࡲࡷ࠳ࡪࡡࡵࠩੂ"))
eOYicX68ruMjpN0dKtWP5QTSE = int(w6vebiEZtpCjJcILP8Skx5rHn.time())
if2qpOxlZd8MBGeo5uNIyLEsz = qH2TpnmA46PMCfY5dsr.Addon(id=aZhcuMGisIkl4npqDoJSrWy5fExX)
def NHyOSR4BdqaXfCpK0EU8vroiDJ2T(pAeIhbuLSFw7j49qxtcg8dDrmKO,ZDu46maUtgrHn7Pcj=WbM6qAjrn7fEXGZw(u"ࠩࡂࠫ੃")):
	if tOdiG2HWFRBXg1sUh(u"ࠪࡁࠬ੄") in pAeIhbuLSFw7j49qxtcg8dDrmKO:
		if ZDu46maUtgrHn7Pcj in pAeIhbuLSFw7j49qxtcg8dDrmKO: M08MPGgsh4n5rKe,yyGKQFwx2Nmt9ZHEuJO4cv8oaTY0 = pAeIhbuLSFw7j49qxtcg8dDrmKO.split(ZDu46maUtgrHn7Pcj,CIcPowhneWs5tN3(u"࠱ఈ"))
		else: M08MPGgsh4n5rKe,yyGKQFwx2Nmt9ZHEuJO4cv8oaTY0 = NxsKJnLFEZ9OHXf1h(u"ࠫࠬ੅"),pAeIhbuLSFw7j49qxtcg8dDrmKO
		yyGKQFwx2Nmt9ZHEuJO4cv8oaTY0 = yyGKQFwx2Nmt9ZHEuJO4cv8oaTY0.split(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠬࠬࠧ੆"))
		bhfgckoLVtsA2DXv = {}
		for EC68L74lHwz59fbTiay3hG1Mn02I in yyGKQFwx2Nmt9ZHEuJO4cv8oaTY0:
			u8u3ZiaBy9SIqnPsAV,A9QIaSVqt0g4b = EC68L74lHwz59fbTiay3hG1Mn02I.split(S26SnaqcM9XwK8PVphJDv5(u"࠭࠽ࠨੇ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠲ఉ"))
			bhfgckoLVtsA2DXv[u8u3ZiaBy9SIqnPsAV] = A9QIaSVqt0g4b
	else: M08MPGgsh4n5rKe,bhfgckoLVtsA2DXv = pAeIhbuLSFw7j49qxtcg8dDrmKO,{}
	return M08MPGgsh4n5rKe,bhfgckoLVtsA2DXv
def BUTSkzgFC7(pAeIhbuLSFw7j49qxtcg8dDrmKO):
	return _7W4AdmwTeEB5PRvsixprG3uKchO(pAeIhbuLSFw7j49qxtcg8dDrmKO)
def VVuCNFHGiUftREgnP4Aw(YIXgQipHscJ):
	XZWGQBxE7cDNUhmK4J8 = {wx18CTJPZ5(u"ࠧࡵࡻࡳࡩࠬੈ"):GGCQK6OAtZUXRhvkgJm(u"ࠨࠩ੉"),tOdiG2HWFRBXg1sUh(u"ࠩࡰࡳࡩ࡫ࠧ੊"):ta478EuZQJIWhgBnsf6iU(u"ࠪࠫੋ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠫࡺࡸ࡬ࠨੌ"):bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"੍ࠬ࠭"),smpniPDOhfwI3H4v7c6TG(u"࠭ࡴࡦࡺࡷࠫ੎"):CIcPowhneWs5tN3(u"ࠧࠨ੏"),Gk98CL5nXZEN(u"ࠨࡲࡤ࡫ࡪ࠭੐"):NNmirJKPp5nWjfC(u"ࠩࠪੑ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠪࡲࡦࡳࡥࠨ੒"):zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠫࠬ੓"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࠬ࡯࡭ࡢࡩࡨࠫ੔"):dEUYJjrhsaPXNo(u"࠭ࠧ੕"),EAw9bg4rT3Bd8tjSkO(u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ੖"):wx18CTJPZ5(u"ࠨࠩ੗"),CIcPowhneWs5tN3(u"ࠩ࡬ࡲ࡫ࡵࡤࡪࡥࡷࠫ੘"):tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠪࠫਖ਼")}
	if MM564HfnUV0XIR(u"ࠫࡄ࠭ਗ਼") in YIXgQipHscJ: YIXgQipHscJ = YIXgQipHscJ.split(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠬࡅࠧਜ਼"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠳ఊ"))[FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠳ఊ")]
	M08MPGgsh4n5rKe,OfhP1UJe6qnBYQlZ40wzoX2 = NHyOSR4BdqaXfCpK0EU8vroiDJ2T(YIXgQipHscJ)
	aargs = dict(list(XZWGQBxE7cDNUhmK4J8.items())+list(OfhP1UJe6qnBYQlZ40wzoX2.items()))
	fDowOUqkis = aargs[ta478EuZQJIWhgBnsf6iU(u"࠭࡭ࡰࡦࡨࠫੜ")]
	Bf5QkcruZNX4SU6IeEvGj = BUTSkzgFC7(aargs[dEUYJjrhsaPXNo(u"ࠧࡶࡴ࡯ࠫ੝")])
	jX4zgTedBkEJlxy9IbSR3vwNU = BUTSkzgFC7(aargs[CIcPowhneWs5tN3(u"ࠨࡶࡨࡼࡹ࠭ਫ਼")])
	t2zEwrA80WRjLel5NSvXyHd = BUTSkzgFC7(aargs[tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠩࡳࡥ࡬࡫ࠧ੟")])
	KVHOBcfFun = BUTSkzgFC7(aargs[QmoEjB3hLIw(u"ࠪࡸࡾࡶࡥࠨ੠")])
	ECwgo4qVaZAzx9eS = BUTSkzgFC7(aargs[NxsKJnLFEZ9OHXf1h(u"ࠫࡳࡧ࡭ࡦࠩ੡")])
	Dj4rSONYXVbF8f9Hd0oWBp = BUTSkzgFC7(aargs[NNmirJKPp5nWjfC(u"ࠬ࡯࡭ࡢࡩࡨࠫ੢")])
	vlntrPLopfSb = aargs[cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ੣")]
	eU9G76lNkSOhxp4ua0H = BUTSkzgFC7(aargs[FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠧࡪࡰࡩࡳࡩ࡯ࡣࡵࠩ੤")])
	if eU9G76lNkSOhxp4ua0H: eU9G76lNkSOhxp4ua0H = eval(eU9G76lNkSOhxp4ua0H)
	else: eU9G76lNkSOhxp4ua0H = {}
	if not fDowOUqkis: KVHOBcfFun = tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ੥") ; fDowOUqkis = r6juULGQtnExAko38BZ5Y(u"ࠩ࠵࠺࠵࠭੦")
	return KVHOBcfFun,ECwgo4qVaZAzx9eS,Bf5QkcruZNX4SU6IeEvGj,fDowOUqkis,Dj4rSONYXVbF8f9Hd0oWBp,t2zEwrA80WRjLel5NSvXyHd,jX4zgTedBkEJlxy9IbSR3vwNU,vlntrPLopfSb,eU9G76lNkSOhxp4ua0H
def Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5):
	EEokACaP8ifuWgcNZF = EAPND6zHKrMRuBc91tInYohsl0ywa._getframe(EAw9bg4rT3Bd8tjSkO(u"࠴ఋ")).f_code.co_name
	if not r1NChsk39OMvT82YemDQnl5 or not EEokACaP8ifuWgcNZF or EEokACaP8ifuWgcNZF==dEUYJjrhsaPXNo(u"ࠪࡀࡲࡵࡤࡶ࡮ࡨࡂࠬ੧"):
		return dEUYJjrhsaPXNo(u"ࠫࡠࠦࠧ੨")+YvVkFoEM0pl8JCGaeZ3XU.upper()+bbqAtUz36RPGVTvCkejpJXQB(u"ࠬ࠳ࠧ੩")+VnhK9wvHBGuo1fei8DXQ02yFZtsWE+ta478EuZQJIWhgBnsf6iU(u"࠭࠭ࠨ੪")+str(wH3qxmuXBTeak)+zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠧࠡ࡟ࠪ੫")
	return GGCQK6OAtZUXRhvkgJm(u"ࠨ࠰ࠣࠤࠬ੬")+EEokACaP8ifuWgcNZF
def y75wQavkVSLUb2MZf9qo(wr2OQVm9JitKPuW65AD0LdXNjIG,EiMsPpS3O1Ba):
	if vciEXHThAPto76QIR2pK: EiMsPpS3O1Ba = EiMsPpS3O1Ba.decode(NxsKJnLFEZ9OHXf1h(u"ࠩࡸࡸ࡫࠾ࠧ੭")).encode(Gk98CL5nXZEN(u"ࠪࡹࡹ࡬࠸ࠨ੮"))
	Bq90dwSnZYG418MQNijO5 = afzQCi9FIk01jct3s7xML8BNrunop
	Zvm7qOC8GUAFB = [dEUYJjrhsaPXNo(u"ࠫࠬ੯"),Kwl07iYTtDLN3zP(u"ࠬ࠭ੰ")]
	if wr2OQVm9JitKPuW65AD0LdXNjIG: EiMsPpS3O1Ba = EiMsPpS3O1Ba.replace(I7N2lHpGfLPkwKxbOu6raYUgc5(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩੱ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠧࠨੲ")).replace(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫੳ"),Gk98CL5nXZEN(u"ࠩࠪੴ")).replace(Gk98CL5nXZEN(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬੵ"),wx18CTJPZ5(u"ࠫࠬ੶"))
	else: wr2OQVm9JitKPuW65AD0LdXNjIG = FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠬࡔࡏࡕࡋࡆࡉࠬ੷")
	mjlVyfxQIRSG728OKes4,ZDu46maUtgrHn7Pcj,sIzuT6p3XHf = YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠭ࠠࠡࠢࠣࠫ੸"),CIcPowhneWs5tN3(u"ࠧࠡࠢࠣࠫ੹"),Gk98CL5nXZEN(u"ࠨࠩ੺")
	if MM564HfnUV0XIR(u"ࠩࡈࡖࡗࡕࡒࠨ੻") in wr2OQVm9JitKPuW65AD0LdXNjIG: Bq90dwSnZYG418MQNijO5 = oos8ymFi9CN2z1jXcR.LOGERROR
	if wr2OQVm9JitKPuW65AD0LdXNjIG==wx18CTJPZ5(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ੼"):
		EiMsPpS3O1Ba = EiMsPpS3O1Ba+ZDu46maUtgrHn7Pcj
		Zvm7qOC8GUAFB = EiMsPpS3O1Ba.split(ZDu46maUtgrHn7Pcj)
		sIzuT6p3XHf = mjlVyfxQIRSG728OKes4
	elif wr2OQVm9JitKPuW65AD0LdXNjIG==uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ੽"):
		EiMsPpS3O1Ba = EiMsPpS3O1Ba.replace(Kwl07iYTtDLN3zP(u"ࠬ࠴ࠧ੾")+ZDu46maUtgrHn7Pcj,ta478EuZQJIWhgBnsf6iU(u"࠭࠮ࠡࠢࠪ੿"))
		Zvm7qOC8GUAFB = EiMsPpS3O1Ba.split(ZDu46maUtgrHn7Pcj)
		Zvm7qOC8GUAFB[cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠵఍")] = FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠧ࠯ࠩ઀")+Zvm7qOC8GUAFB[cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠵఍")][ItgK5FqGDz2Rf7mAJkbT(u"࠵ఌ"):]
		sIzuT6p3XHf = mjlVyfxQIRSG728OKes4+ZDu46maUtgrHn7Pcj
	elif wr2OQVm9JitKPuW65AD0LdXNjIG in [dEUYJjrhsaPXNo(u"ࠨࡐࡒࡘࡎࡉࡅࠨઁ"),ta478EuZQJIWhgBnsf6iU(u"ࠩࡈࡖࡗࡕࡒࠨં")]: Zvm7qOC8GUAFB = EiMsPpS3O1Ba.split(mjlVyfxQIRSG728OKes4)
	sIzuT6p3XHf += I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠼ఎ")*mjlVyfxQIRSG728OKes4
	rgKuAwicfh3N8v5yC9DeBEjZFbGm = CgPbwXm1RilpJUSGHLhy(u"࠳ఏ")*mjlVyfxQIRSG728OKes4
	if wH3qxmuXBTeak>NNmirJKPp5nWjfC(u"࠳࠺࠲࠾࠿఑"): sIzuT6p3XHf += FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠲࠳ఐ")*WbM6qAjrn7fEXGZw(u"ࠪࠤࠬઃ")
	oyH3BTKdDiMhguYnc47NzRLvj = Zvm7qOC8GUAFB[tOdiG2HWFRBXg1sUh(u"࠳ఒ")]
	for XpCOM0t9ZcL8WvBE2xDb3yeonKhQ in Zvm7qOC8GUAFB[smpniPDOhfwI3H4v7c6TG(u"࠵ఓ"):]:
		if MM564HfnUV0XIR(u"ࠫࡡࡴࠧ઄") in XpCOM0t9ZcL8WvBE2xDb3yeonKhQ: XpCOM0t9ZcL8WvBE2xDb3yeonKhQ = XpCOM0t9ZcL8WvBE2xDb3yeonKhQ.replace(QmoEjB3hLIw(u"ࠬࡢ࡮ࠨઅ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"࠭࡜࡯ࠩઆ")+mjlVyfxQIRSG728OKes4+mjlVyfxQIRSG728OKes4)
		rgKuAwicfh3N8v5yC9DeBEjZFbGm += mjlVyfxQIRSG728OKes4
		oyH3BTKdDiMhguYnc47NzRLvj += NxsKJnLFEZ9OHXf1h(u"ࠧ࡝ࡴࠪઇ")+sIzuT6p3XHf+rgKuAwicfh3N8v5yC9DeBEjZFbGm+XpCOM0t9ZcL8WvBE2xDb3yeonKhQ
	oyH3BTKdDiMhguYnc47NzRLvj += smpniPDOhfwI3H4v7c6TG(u"ࠨࠢࡢࠫઈ")
	if FeyZbj8tDil0nSHzTwfsUJ9(u"ࠩࠨࠫઉ") in oyH3BTKdDiMhguYnc47NzRLvj: oyH3BTKdDiMhguYnc47NzRLvj = BUTSkzgFC7(oyH3BTKdDiMhguYnc47NzRLvj)
	oos8ymFi9CN2z1jXcR.log(oyH3BTKdDiMhguYnc47NzRLvj,level=Bq90dwSnZYG418MQNijO5)
	return
def N5JUy4M8AKmjBZgL(AM9JTc4kHQBwve0Xh6i1):
	md59xZUEq3IOnPp2 = iZv4fPkF5Trx1L8EsVHC2S.connect(AM9JTc4kHQBwve0Xh6i1)
	ngBDPjZshKvdX6 = md59xZUEq3IOnPp2.cursor()
	ngBDPjZshKvdX6.execute(uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡥࡺࡺ࡯࡮ࡣࡷ࡭ࡨࡥࡩ࡯ࡦࡨࡼࡂࡴ࡯࠼ࠩઊ"))
	ngBDPjZshKvdX6.execute(uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡫ࡵࡲࡦ࡫ࡪࡲࡤࡱࡥࡺࡵࡀࡲࡴࡁࠧઋ"))
	ngBDPjZshKvdX6.execute(CIcPowhneWs5tN3(u"ࠬࡖࡒࡂࡉࡐࡅࠥ࡯ࡧ࡯ࡱࡵࡩࡤࡩࡨࡦࡥ࡮ࡣࡨࡵ࡮ࡴࡶࡵࡥ࡮ࡴࡴࡴ࠿ࡼࡩࡸࡁࠧઌ"))
	ngBDPjZshKvdX6.execute(cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡪࡰࡷࡵࡲࡦࡲ࡟࡮ࡱࡧࡩࡂࡕࡆࡇ࠽ࠪઍ"))
	ngBDPjZshKvdX6.execute(CgPbwXm1RilpJUSGHLhy(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡵࡧࡰࡴࡤࡹࡴࡰࡴࡨࡁࡒࡋࡍࡐࡔ࡜࠿ࠬ઎"))
	ngBDPjZshKvdX6.execute(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡵࡼࡲࡨ࡮ࡲࡰࡰࡲࡹࡸࡃࡏࡇࡈ࠾ࠫએ"))
	md59xZUEq3IOnPp2.text_factory = str
	return md59xZUEq3IOnPp2,ngBDPjZshKvdX6
def QQvOnYi9sJMwp7dIxeck8DRASWuBt(AM9JTc4kHQBwve0Xh6i1,J8Pasjk3EUBtqIlWOwydvDohGX,oGQVFTZg6rnbE=None):
	try: md59xZUEq3IOnPp2,ngBDPjZshKvdX6 = N5JUy4M8AKmjBZgL(AM9JTc4kHQBwve0Xh6i1)
	except: return
	if oGQVFTZg6rnbE==None: ngBDPjZshKvdX6.execute(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠩࡇࡖࡔࡖࠠࡕࡃࡅࡐࡊࠦࡉࡇࠢࡈ࡜ࡎ࡙ࡔࡔࠢࠥࠫઐ")+J8Pasjk3EUBtqIlWOwydvDohGX+S26SnaqcM9XwK8PVphJDv5(u"ࠪࠦࠥࡁࠧઑ"))
	else:
		ddTp9nAXO35utigMREqaSlU = (str(oGQVFTZg6rnbE),)
		try:
			if ItgK5FqGDz2Rf7mAJkbT(u"ࠫࠪ࠭઒") in oGQVFTZg6rnbE: ngBDPjZshKvdX6.execute(Kwl07iYTtDLN3zP(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬઓ")+J8Pasjk3EUBtqIlWOwydvDohGX+smpniPDOhfwI3H4v7c6TG(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࡭࡫࡮ࡩࠥࡅࠠ࠼ࠩઔ"),ddTp9nAXO35utigMREqaSlU)
			else: ngBDPjZshKvdX6.execute(uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧક")+J8Pasjk3EUBtqIlWOwydvDohGX+dEUYJjrhsaPXNo(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨખ"),ddTp9nAXO35utigMREqaSlU)
		except: pass
	md59xZUEq3IOnPp2.commit()
	md59xZUEq3IOnPp2.close()
	return
class FkarsjNC5p2Gm07zv4AuOg(): pass
class bbWis1pMJaqDek(FkarsjNC5p2Gm07zv4AuOg):
	def __init__(dzWrsHbBhvmJM1G0fu7E):
		dzWrsHbBhvmJM1G0fu7E.url = smpniPDOhfwI3H4v7c6TG(u"ࠩࠪગ")
		dzWrsHbBhvmJM1G0fu7E.code = -Kwl07iYTtDLN3zP(u"࠾࠿ఔ")
		dzWrsHbBhvmJM1G0fu7E.reason = zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠪࠫઘ")
		dzWrsHbBhvmJM1G0fu7E.content = QmoEjB3hLIw(u"ࠫࠬઙ")
		dzWrsHbBhvmJM1G0fu7E.headers = {}
		dzWrsHbBhvmJM1G0fu7E.cookies = {}
		dzWrsHbBhvmJM1G0fu7E.succeeded = ta478EuZQJIWhgBnsf6iU(u"ࡆࡢ࡮ࡶࡩ౜")
def LvJykz3cZIhdCnrwKRABxO(Rl48v7kIh3cgF1fzOS6mQ9):
	if Rl48v7kIh3cgF1fzOS6mQ9==GGCQK6OAtZUXRhvkgJm(u"ࠬࡪࡩࡤࡶࠪચ"): YReuIJ67GDs8NwEiZOAh4xPMb = {}
	elif Rl48v7kIh3cgF1fzOS6mQ9==ItgK5FqGDz2Rf7mAJkbT(u"࠭࡬ࡪࡵࡷࠫછ"): YReuIJ67GDs8NwEiZOAh4xPMb = []
	elif Rl48v7kIh3cgF1fzOS6mQ9==I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠧࡴࡶࡵࠫજ"): YReuIJ67GDs8NwEiZOAh4xPMb = SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠨࠩઝ")
	elif Rl48v7kIh3cgF1fzOS6mQ9==bbqAtUz36RPGVTvCkejpJXQB(u"ࠩ࡬ࡲࡹ࠭ઞ"): YReuIJ67GDs8NwEiZOAh4xPMb = dEUYJjrhsaPXNo(u"࠶క")
	elif Rl48v7kIh3cgF1fzOS6mQ9==FeyZbj8tDil0nSHzTwfsUJ9(u"ࠪࡶࡪࡹࡰࡰࡰࡶࡩࠬટ"): YReuIJ67GDs8NwEiZOAh4xPMb = bbWis1pMJaqDek()
	elif not Rl48v7kIh3cgF1fzOS6mQ9: YReuIJ67GDs8NwEiZOAh4xPMb = None
	else: YReuIJ67GDs8NwEiZOAh4xPMb = None
	return YReuIJ67GDs8NwEiZOAh4xPMb
def hPfgMmZC19lRiKwpN(w8Fjf7g0KGIWLeO):
	from hashlib import md5 as P5j9asqbcBpmurZ184noVh3I
	PlQxCRd3M5qsH = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(FeyZbj8tDil0nSHzTwfsUJ9(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠭ઠ"))
	pNX09rJfkc73GanEFRUsgdOA1SQy = zVw5tvmZRX(I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠳࠳ఖ")).splitlines()
	OK1YbaZUVSvG = QmoEjB3hLIw(u"࠱గ")
	for ZCmVfJKdDkE4tqoBP7jyrXwWv56U8G in [eOYicX68ruMjpN0dKtWP5QTSE,eOYicX68ruMjpN0dKtWP5QTSE-jEPuRTVbZg4MCimJxzf3I6wFa]:
		ObgJC7TAS5Z3kIQtY = str(ZCmVfJKdDkE4tqoBP7jyrXwWv56U8G*WbM6qAjrn7fEXGZw(u"࠵࠵࠶࠰࠱࠲࠱࠴చ")/tOdiG2HWFRBXg1sUh(u"࠷࠷࠷࠶࠰࠱ఙ"))[I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠲ఘ"):Gk98CL5nXZEN(u"࠹ఛ")]
		if ObgJC7TAS5Z3kIQtY!=OK1YbaZUVSvG:
			for OaoBgNnc8xrkQ in pNX09rJfkc73GanEFRUsgdOA1SQy:
				G3GL9xoSK2Ql = zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠬ࡞࠱࠺ࠩડ")+w8Fjf7g0KGIWLeO+QmoEjB3hLIw(u"࠭࠱࠹࠿ࠪઢ")+OaoBgNnc8xrkQ[-CIcPowhneWs5tN3(u"࠸࠴జ"):]+VnhK9wvHBGuo1fei8DXQ02yFZtsWE+ObgJC7TAS5Z3kIQtY
				G3GL9xoSK2Ql = P5j9asqbcBpmurZ184noVh3I(G3GL9xoSK2Ql.encode(CgPbwXm1RilpJUSGHLhy(u"ࠧࡶࡶࡩ࠼ࠬણ"))).hexdigest()[:GGCQK6OAtZUXRhvkgJm(u"࠳࠳ఝ")]
				if G3GL9xoSK2Ql in PlQxCRd3M5qsH: return I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࡕࡴࡸࡩౝ")
			OK1YbaZUVSvG = ObgJC7TAS5Z3kIQtY
	return FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࡈࡤࡰࡸ࡫౞")
def vsmQSl1ZDENy69BXJhWYF(AM9JTc4kHQBwve0Xh6i1,fq8wviaxCU,J8Pasjk3EUBtqIlWOwydvDohGX,oGQVFTZg6rnbE=None):
	YReuIJ67GDs8NwEiZOAh4xPMb = LvJykz3cZIhdCnrwKRABxO(fq8wviaxCU)
	A2UGrN4JhjOEXKF3CmIogxRLtaBHye = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(WbM6qAjrn7fEXGZw(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧત"))
	if J8Pasjk3EUBtqIlWOwydvDohGX!=Kwl07iYTtDLN3zP(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬથ") and AM9JTc4kHQBwve0Xh6i1==WSgQvHLx9uOKTksaCt2JchldRj:
		if A2UGrN4JhjOEXKF3CmIogxRLtaBHye==smpniPDOhfwI3H4v7c6TG(u"ࠪࡗ࡙ࡕࡐࠨદ"): return YReuIJ67GDs8NwEiZOAh4xPMb
		DzRqxnIrNLUgj4PYXFkZJc = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(FeyZbj8tDil0nSHzTwfsUJ9(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨધ"))
		if DzRqxnIrNLUgj4PYXFkZJc==SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠬࡘࡅࡇࡔࡈࡗࡍࡋࡄࠨન"):
			QQvOnYi9sJMwp7dIxeck8DRASWuBt(AM9JTc4kHQBwve0Xh6i1,J8Pasjk3EUBtqIlWOwydvDohGX,oGQVFTZg6rnbE)
			return YReuIJ67GDs8NwEiZOAh4xPMb
	ZoAV3xabtlS6zqf2DMpn = CIcPowhneWs5tN3(u"࠱ఞ")
	if A2UGrN4JhjOEXKF3CmIogxRLtaBHye==FeyZbj8tDil0nSHzTwfsUJ9(u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧ઩"): ZoAV3xabtlS6zqf2DMpn = ddEW38kMhf9mZGC6ePnFS
	try: md59xZUEq3IOnPp2,ngBDPjZshKvdX6 = N5JUy4M8AKmjBZgL(AM9JTc4kHQBwve0Xh6i1)
	except: return YReuIJ67GDs8NwEiZOAh4xPMb
	zC1VuUXBioYqfd9mcvKhTF4M375r = tOdiG2HWFRBXg1sUh(u"ࡗࡶࡺ࡫౟")
	try: ngBDPjZshKvdX6.execute(r6juULGQtnExAko38BZ5Y(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࠣࠩપ")+J8Pasjk3EUBtqIlWOwydvDohGX+I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠨࠤࠣࡐࡎࡓࡉࡕࠢ࠴ࠤࡀ࠭ફ"))
	except: zC1VuUXBioYqfd9mcvKhTF4M375r = Kwl07iYTtDLN3zP(u"ࡊࡦࡲࡳࡦౠ")
	if zC1VuUXBioYqfd9mcvKhTF4M375r:
		if ZoAV3xabtlS6zqf2DMpn: ngBDPjZshKvdX6.execute(MM564HfnUV0XIR(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩબ")+J8Pasjk3EUBtqIlWOwydvDohGX+GGCQK6OAtZUXRhvkgJm(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡪࡾࡰࡪࡴࡼࡂࠬભ")+str(eOYicX68ruMjpN0dKtWP5QTSE+ZoAV3xabtlS6zqf2DMpn)+NxsKJnLFEZ9OHXf1h(u"ࠫࠥࡁࠧમ"))
		md59xZUEq3IOnPp2.commit()
		ngBDPjZshKvdX6.execute(wx18CTJPZ5(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬય")+J8Pasjk3EUBtqIlWOwydvDohGX+FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡦࡺࡳ࡭ࡷࡿ࠼ࠨર")+str(eOYicX68ruMjpN0dKtWP5QTSE)+zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠧࠡ࠽ࠪ઱"))
		md59xZUEq3IOnPp2.commit()
		if oGQVFTZg6rnbE:
			ddTp9nAXO35utigMREqaSlU = (str(oGQVFTZg6rnbE),)
			ngBDPjZshKvdX6.execute(NNmirJKPp5nWjfC(u"ࠨࡕࡈࡐࡊࡉࡔࠡࡦࡤࡸࡦࠦࡆࡓࡑࡐࠤࠧ࠭લ")+J8Pasjk3EUBtqIlWOwydvDohGX+zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡧࡴࡲࡵ࡮ࡰࠣࡁࠥࡅࠠ࠼ࠩળ"),ddTp9nAXO35utigMREqaSlU)
			MRDAU8alpIbtNPn1Y95WJK2d6mr3E = ngBDPjZshKvdX6.fetchall()
			if MRDAU8alpIbtNPn1Y95WJK2d6mr3E:
				try:
					hfNZTDrYABwyVcJQlqPS48xpHIi7s = LPeE7ZjVag6xWTydcwQb.decompress(MRDAU8alpIbtNPn1Y95WJK2d6mr3E[wx18CTJPZ5(u"࠲ట")][wx18CTJPZ5(u"࠲ట")])
					YReuIJ67GDs8NwEiZOAh4xPMb = nn7DVGBZsq0.loads(hfNZTDrYABwyVcJQlqPS48xpHIi7s)
				except: pass
		else:
			ngBDPjZshKvdX6.execute(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡧࡴࡲࡵ࡮ࡰ࠯ࡨࡦࡺࡡࠡࡈࡕࡓࡒࠦࠢࠨ઴")+J8Pasjk3EUBtqIlWOwydvDohGX+CIcPowhneWs5tN3(u"ࠫࠧࠦ࠻ࠨવ"))
			MRDAU8alpIbtNPn1Y95WJK2d6mr3E = ngBDPjZshKvdX6.fetchall()
			if MRDAU8alpIbtNPn1Y95WJK2d6mr3E:
				YReuIJ67GDs8NwEiZOAh4xPMb,pbn6hV9j8TlRQi = {},[]
				for et9XOrbxFvBgqsEiIy21dRufTV7o,bhfgckoLVtsA2DXv in MRDAU8alpIbtNPn1Y95WJK2d6mr3E:
					qum4VoYNQsc21iMZ76LzRtp = LPeE7ZjVag6xWTydcwQb.decompress(bhfgckoLVtsA2DXv)
					bhfgckoLVtsA2DXv = nn7DVGBZsq0.loads(qum4VoYNQsc21iMZ76LzRtp)
					YReuIJ67GDs8NwEiZOAh4xPMb[et9XOrbxFvBgqsEiIy21dRufTV7o] = bhfgckoLVtsA2DXv
					pbn6hV9j8TlRQi.append(et9XOrbxFvBgqsEiIy21dRufTV7o)
				if pbn6hV9j8TlRQi:
					YReuIJ67GDs8NwEiZOAh4xPMb[bbqAtUz36RPGVTvCkejpJXQB(u"ࠬࡥ࡟ࡔࡇࡔ࡙ࡊࡔࡃࡆࡆࡢࡇࡔࡒࡕࡎࡐࡖࡣࡤ࠭શ")] = pbn6hV9j8TlRQi
					if fq8wviaxCU==dEUYJjrhsaPXNo(u"࠭࡬ࡪࡵࡷࠫષ"): YReuIJ67GDs8NwEiZOAh4xPMb = pbn6hV9j8TlRQi
	md59xZUEq3IOnPp2.close()
	return YReuIJ67GDs8NwEiZOAh4xPMb
class JKpA9XiIHv7mVLEoNYFBTP(ASqn1tDiZQwk5CEBFh23eMcGKOxmP7):
	def __init__(dzWrsHbBhvmJM1G0fu7E):
		dzWrsHbBhvmJM1G0fu7E.yy3VY41cIBFOAUZ = hPfgMmZC19lRiKwpN(smpniPDOhfwI3H4v7c6TG(u"ࠧࡄࡖࡈ࠽ࡉ࡙࠱࠺ࡘࡘ࠴࡛࡙ࡘࠨસ"))
		dzWrsHbBhvmJM1G0fu7E.YmHIB9le8jOM3PSk2NvyzqGtRTsQwA = hPfgMmZC19lRiKwpN(Kwl07iYTtDLN3zP(u"ࠨ࡙ࡖ࡙ࡗࡌࡔ࠲࠻ࡔࡘࡊࡌ࡚࡙ࠩહ"))
		dzWrsHbBhvmJM1G0fu7E.x6jJTlK8YypeV0udstUSqarZWPHF = hPfgMmZC19lRiKwpN(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠩࡅࡘࡊࡾࡐࡗ࠳࠼࡙ࡗ࡜ࡎࡖࡕࡘ࠹ࡍ࡞ࠧ઺"))
		dzWrsHbBhvmJM1G0fu7E.PFlaYj0qTWHmCOI5cKtbvQ9wzD = tOdiG2HWFRBXg1sUh(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ઻") if dzWrsHbBhvmJM1G0fu7E.yy3VY41cIBFOAUZ else wx18CTJPZ5(u"઼ࠫࠬ")
	def d7vaEmOX3C6N(dzWrsHbBhvmJM1G0fu7E,HH9KDT0pyc): dzWrsHbBhvmJM1G0fu7E.HH9KDT0pyc = HH9KDT0pyc
	def onPlayBackStopped(dzWrsHbBhvmJM1G0fu7E): dzWrsHbBhvmJM1G0fu7E.PFlaYj0qTWHmCOI5cKtbvQ9wzD = ItgK5FqGDz2Rf7mAJkbT(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬઽ")
	def onPlayBackError(dzWrsHbBhvmJM1G0fu7E): dzWrsHbBhvmJM1G0fu7E.PFlaYj0qTWHmCOI5cKtbvQ9wzD = FeyZbj8tDil0nSHzTwfsUJ9(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ા")
	def onPlayBackEnded(dzWrsHbBhvmJM1G0fu7E): dzWrsHbBhvmJM1G0fu7E.PFlaYj0qTWHmCOI5cKtbvQ9wzD = Kwl07iYTtDLN3zP(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧિ")
	def onPlayBackStarted(dzWrsHbBhvmJM1G0fu7E):
		dzWrsHbBhvmJM1G0fu7E.PFlaYj0qTWHmCOI5cKtbvQ9wzD = bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩી")
		TDnibKRXMENwHaPJAYgxG9LBv = mZHwnlsXWDfV3ri4M.Thread(target=dzWrsHbBhvmJM1G0fu7E.NIiKm52bp9tEdr,args=())
		TDnibKRXMENwHaPJAYgxG9LBv.start()
	def onAVStarted(dzWrsHbBhvmJM1G0fu7E):
		if dzWrsHbBhvmJM1G0fu7E.YmHIB9le8jOM3PSk2NvyzqGtRTsQwA: dzWrsHbBhvmJM1G0fu7E.PFlaYj0qTWHmCOI5cKtbvQ9wzD = Kwl07iYTtDLN3zP(u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪુ")
		else: dzWrsHbBhvmJM1G0fu7E.PFlaYj0qTWHmCOI5cKtbvQ9wzD = bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫૂ")
	def NIiKm52bp9tEdr(dzWrsHbBhvmJM1G0fu7E):
		from zbUtu6IvKA import jtzHRewuAVZ9WqomsIT5,IxG5DTtZj4bC0fJRl8,YyexoUV8ZWpMXsRir1wAm69QPJKnN
		YyexoUV8ZWpMXsRir1wAm69QPJKnN(NNmirJKPp5nWjfC(u"ࠫࡸࡺ࡯ࡱࠩૃ"))
		xHZDbOauMpE8GKVYrzjmX6JQN3W = ta478EuZQJIWhgBnsf6iU(u"࠳ఠ")
		while not eval(GGCQK6OAtZUXRhvkgJm(u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳࡯ࡳࡑ࡮ࡤࡽ࡮ࡴࡧࡗ࡫ࡧࡩࡴ࠮ࠩࠨૄ"),{tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠭ࡸࡣ࡯ࡦࠫૅ"):oos8ymFi9CN2z1jXcR}) and dzWrsHbBhvmJM1G0fu7E.PFlaYj0qTWHmCOI5cKtbvQ9wzD==I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࠨ૆"):
			oos8ymFi9CN2z1jXcR.sleep(wx18CTJPZ5(u"࠵࠵࠶࠰డ"))
			xHZDbOauMpE8GKVYrzjmX6JQN3W += MM564HfnUV0XIR(u"࠶ఢ")
			if xHZDbOauMpE8GKVYrzjmX6JQN3W>dEUYJjrhsaPXNo(u"࠼࠰ణ"): return
		if dzWrsHbBhvmJM1G0fu7E.yy3VY41cIBFOAUZ: dzWrsHbBhvmJM1G0fu7E.PFlaYj0qTWHmCOI5cKtbvQ9wzD = zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠩે")
		elif dzWrsHbBhvmJM1G0fu7E.YmHIB9le8jOM3PSk2NvyzqGtRTsQwA: dzWrsHbBhvmJM1G0fu7E.PFlaYj0qTWHmCOI5cKtbvQ9wzD = zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪૈ")
		elif dzWrsHbBhvmJM1G0fu7E.x6jJTlK8YypeV0udstUSqarZWPHF:
			dzWrsHbBhvmJM1G0fu7E.PFlaYj0qTWHmCOI5cKtbvQ9wzD = Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫૉ")
			HuNmZgOcP0ytUJnIDFh = mZHwnlsXWDfV3ri4M.Thread(target=jtzHRewuAVZ9WqomsIT5,args=(dzWrsHbBhvmJM1G0fu7E.HH9KDT0pyc,))
			HuNmZgOcP0ytUJnIDFh.start()
			llpI5BYgUa3S9L = mZHwnlsXWDfV3ri4M.Thread(target=IxG5DTtZj4bC0fJRl8,args=())
			llpI5BYgUa3S9L.start()
		else: dzWrsHbBhvmJM1G0fu7E.PFlaYj0qTWHmCOI5cKtbvQ9wzD = ta478EuZQJIWhgBnsf6iU(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬ૊")
def TR3dr2pnFsU7I1iozBJvWale6X():
	lSszipXCwHAv5k,K8sEt7Pv30wDQ = YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠬ࠭ો"),smpniPDOhfwI3H4v7c6TG(u"࠭ࠧૌ")
	YpE6FN9xTSOizWqhyCAuRo = oos8ymFi9CN2z1jXcR.getInfoLabel(MM564HfnUV0XIR(u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴ࡬ࡩࡳࡪ࡬ࡺࡐࡤࡱࡪ્࠭"))
	try:
		qAHRuGBCFycoOzxZw4rI = open(Gk98CL5nXZEN(u"ࠨ࠱ࡳࡶࡴࡩ࠯ࡤࡲࡸ࡭ࡳ࡬࡯ࠨ૎"),Kwl07iYTtDLN3zP(u"ࠩࡵࡦࠬ૏")).read()
		if wvkR1es6d0SrjxKt5FZTMUWz7a: qAHRuGBCFycoOzxZw4rI = qAHRuGBCFycoOzxZw4rI.decode(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠪࡹࡹ࡬࠸ࠨૐ"))
		vSfgP9h3c4 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(wx18CTJPZ5(u"ࠫࡘ࡫ࡲࡪࡣ࡯࠲࠯ࡅ࠺ࠡࠪ࠱࠮ࡄ࠯ࠤࠨ૑"),qAHRuGBCFycoOzxZw4rI,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.IGNORECASE)
		if vSfgP9h3c4: lSszipXCwHAv5k = vSfgP9h3c4[CgPbwXm1RilpJUSGHLhy(u"࠰త")]
	except: pass
	try:
		import subprocess as Pe6zIpfdbTRDFJlVojc4a
		NNYZQOnG5TjRqAxuVMX = Pe6zIpfdbTRDFJlVojc4a.Popen(EAw9bg4rT3Bd8tjSkO(u"ࠬࡹࡴࡢࡶࠣ࠱ࡨ࡛ࠦࠢࠡࠧࠤࠧࠦ࠯ࡴࡶࡲࡶࡦ࡭ࡥ࠰ࡧࡰࡹࡱࡧࡴࡦࡦ࠲࠴ࠥࡁࠠࡴࡶࡤࡸࠥ࠳ࡣࠡࠤࠣࠩ࡜ࠦࠢࠡ࠱ࡹࡥࡷ࠵࡬ࡰࡩࠪ૒"),shell=r6juULGQtnExAko38BZ5Y(u"࡙ࡸࡵࡦౡ"),stdin=Pe6zIpfdbTRDFJlVojc4a.PIPE,stdout=Pe6zIpfdbTRDFJlVojc4a.PIPE,stderr=Pe6zIpfdbTRDFJlVojc4a.PIPE)
		g5xirmuB1w9pl2 = NNYZQOnG5TjRqAxuVMX.stdout.read()
		if g5xirmuB1w9pl2:
			if wvkR1es6d0SrjxKt5FZTMUWz7a:
				g5xirmuB1w9pl2 = g5xirmuB1w9pl2.decode(ItgK5FqGDz2Rf7mAJkbT(u"࠭ࡵࡵࡨ࠻ࠫ૓"),NNmirJKPp5nWjfC(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧ૔"))
			LGEbOef4p8ZiA5B0y7I9F = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠨࠢࠫࡠࡩࢁ࠱࠱ࡿࠬࠤࠬ૕"),g5xirmuB1w9pl2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.IGNORECASE)
			if LGEbOef4p8ZiA5B0y7I9F: K8sEt7Pv30wDQ = min(LGEbOef4p8ZiA5B0y7I9F)
	except: pass
	return YpE6FN9xTSOizWqhyCAuRo,lSszipXCwHAv5k,K8sEt7Pv30wDQ
def zVw5tvmZRX(P6e9iLTvguIDEVpSwj2CGmkhlob73,SQnUF3GPwdWfNHqoTs=Ox8k6IdtuPaG3NlApQK52oYwM(u"࡚ࡲࡶࡧౢ")):
	hyfovIQidOqzJgLuZtlEac9Pew1WU = uAl3gHavMJZL4xmNe62nDiBoQ(u"ࡔࡳࡷࡨౣ")
	if SQnUF3GPwdWfNHqoTs:
		B2AQt18NDixWPadSHpCkjZbyzv = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,wx18CTJPZ5(u"ࠩ࡯࡭ࡸࡺࠧ૖"),CIcPowhneWs5tN3(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭૗"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠫࡘࡏࡔࡆࡕࡢࡇࡍࡋࡃࡌࠩ૘"))
		if B2AQt18NDixWPadSHpCkjZbyzv:
			pNX09rJfkc73GanEFRUsgdOA1SQy,ee8Gwy710igbJz,zqAIZWmad2FiJDNvbt,iMOBVG2JFL8b4IEnTsyYuZCkloQP = B2AQt18NDixWPadSHpCkjZbyzv
			hyfovIQidOqzJgLuZtlEac9Pew1WU = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠬࡲࡩࡴࡶࠪ૙"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ૚"),qFRrj7ayBKbOsHGSXz(u"ࠧࡔࡋࡗࡉࡘࡥࡖࡆࡔࡌࡊ࡞࠭૛"))
			if hyfovIQidOqzJgLuZtlEac9Pew1WU: YpE6FN9xTSOizWqhyCAuRo,lSszipXCwHAv5k,K8sEt7Pv30wDQ = hyfovIQidOqzJgLuZtlEac9Pew1WU
			else: YpE6FN9xTSOizWqhyCAuRo,lSszipXCwHAv5k,K8sEt7Pv30wDQ = TR3dr2pnFsU7I1iozBJvWale6X()
			if (ee8Gwy710igbJz,zqAIZWmad2FiJDNvbt,iMOBVG2JFL8b4IEnTsyYuZCkloQP)==(YpE6FN9xTSOizWqhyCAuRo,lSszipXCwHAv5k,K8sEt7Pv30wDQ): return MM564HfnUV0XIR(u"ࠨ࡞ࡱࠫ૜").join(pNX09rJfkc73GanEFRUsgdOA1SQy)
	if hyfovIQidOqzJgLuZtlEac9Pew1WU: YpE6FN9xTSOizWqhyCAuRo,lSszipXCwHAv5k,K8sEt7Pv30wDQ = TR3dr2pnFsU7I1iozBJvWale6X()
	global LIHJQ4M0k2aSRGdmUVNWfxFDBznh,MEuQX1se0S9Rt
	LIHJQ4M0k2aSRGdmUVNWfxFDBznh,MEuQX1se0S9Rt,UEhd0xbAkfH2FYyQeqinL = ta478EuZQJIWhgBnsf6iU(u"ࠩࠪ૝"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠪࠫ૞"),ItgK5FqGDz2Rf7mAJkbT(u"ࠫࠬ૟")
	P6e9iLTvguIDEVpSwj2CGmkhlob73 = P6e9iLTvguIDEVpSwj2CGmkhlob73//SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠳థ")
	mZHwnlsXWDfV3ri4M.Thread(target=hKfGjrBietyz8N7pD).start()
	mZHwnlsXWDfV3ri4M.Thread(target=eUaPQldwVhA).start()
	for Deiz7ocWQjVnIg in range(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠳࠳ద")):
		w6vebiEZtpCjJcILP8Skx5rHn.sleep(FeyZbj8tDil0nSHzTwfsUJ9(u"࠳࠲࠺ధ"))
		if not UEhd0xbAkfH2FYyQeqinL:
			try:
				DXwGmnR5zYkCHhUuL1AKadlj8Og = oos8ymFi9CN2z1jXcR.getInfoLabel(bbqAtUz36RPGVTvCkejpJXQB(u"ࠬࡔࡥࡵࡹࡲࡶࡰ࠴ࡍࡢࡥࡄࡨࡩࡸࡥࡴࡵࠪૠ"))
				if DXwGmnR5zYkCHhUuL1AKadlj8Og.count(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠭࠺ࠨૡ"))==bbqAtUz36RPGVTvCkejpJXQB(u"࠺఩") and DXwGmnR5zYkCHhUuL1AKadlj8Og.count(r6juULGQtnExAko38BZ5Y(u"ࠧ࠱ࠩૢ"))<SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠽న"):
					DXwGmnR5zYkCHhUuL1AKadlj8Og = DXwGmnR5zYkCHhUuL1AKadlj8Og.lower().replace(S26SnaqcM9XwK8PVphJDv5(u"ࠨ࠼ࠪૣ"),Kwl07iYTtDLN3zP(u"ࠩࠪ૤"))
					UEhd0xbAkfH2FYyQeqinL = str(int(DXwGmnR5zYkCHhUuL1AKadlj8Og,I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠷࠶ప")))
			except: pass
		if LIHJQ4M0k2aSRGdmUVNWfxFDBznh and MEuQX1se0S9Rt and UEhd0xbAkfH2FYyQeqinL: break
	TYebvtQSu6xzEm2acrqRX8o9Ik5H = [LIHJQ4M0k2aSRGdmUVNWfxFDBznh,MEuQX1se0S9Rt,UEhd0xbAkfH2FYyQeqinL,QmoEjB3hLIw(u"ࠪࠫ૥"),dEUYJjrhsaPXNo(u"ࠫࠬ૦"),Kwl07iYTtDLN3zP(u"ࠬ࠶࠰࠲࠳࠵࠶࠸࠹࠴࠵࠷࠸࠺࠻࠽࠷ࠨ૧")]
	if lSszipXCwHAv5k or K8sEt7Pv30wDQ:
		from hashlib import md5 as P5j9asqbcBpmurZ184noVh3I
		DDqk7bRWQHaclsoYATdCefyvL = [(cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠵బ"),lSszipXCwHAv5k),(GGCQK6OAtZUXRhvkgJm(u"࠵ఫ"),K8sEt7Pv30wDQ)]
		for u8u3ZiaBy9SIqnPsAV,A9QIaSVqt0g4b in DDqk7bRWQHaclsoYATdCefyvL:
			A9QIaSVqt0g4b = A9QIaSVqt0g4b.strip(ta478EuZQJIWhgBnsf6iU(u"࠭࠰ࠨ૨"))
			if A9QIaSVqt0g4b:
				if wvkR1es6d0SrjxKt5FZTMUWz7a: A9QIaSVqt0g4b = A9QIaSVqt0g4b.encode(MM564HfnUV0XIR(u"ࠧࡶࡶࡩ࠼ࠬ૩"))
				A9QIaSVqt0g4b = str(int(P5j9asqbcBpmurZ184noVh3I(A9QIaSVqt0g4b).hexdigest(),EAw9bg4rT3Bd8tjSkO(u"࠵࠹భ")))
				fsPGqr6Odo5ZwMhxCL8j = [int(A9QIaSVqt0g4b[mjCrKn6Dqy9pRV4wPXbIQJvZ:mjCrKn6Dqy9pRV4wPXbIQJvZ+CgPbwXm1RilpJUSGHLhy(u"࠵࠺య")]) for mjCrKn6Dqy9pRV4wPXbIQJvZ in range(len(A9QIaSVqt0g4b)) if mjCrKn6Dqy9pRV4wPXbIQJvZ%CgPbwXm1RilpJUSGHLhy(u"࠵࠺య")==uAl3gHavMJZL4xmNe62nDiBoQ(u"࠳మ")]
				TYebvtQSu6xzEm2acrqRX8o9Ik5H[u8u3ZiaBy9SIqnPsAV-EAw9bg4rT3Bd8tjSkO(u"࠶ర")] = str(sum(fsPGqr6Odo5ZwMhxCL8j))
	pNX09rJfkc73GanEFRUsgdOA1SQy,n8w9ZDtYGS = [],CgPbwXm1RilpJUSGHLhy(u"ࡇࡣ࡯ࡷࡪ౤")
	for t24Zwa5I7oC9 in range(len(TYebvtQSu6xzEm2acrqRX8o9Ik5H)):
		fsPGqr6Odo5ZwMhxCL8j = TYebvtQSu6xzEm2acrqRX8o9Ik5H[t24Zwa5I7oC9]
		if not fsPGqr6Odo5ZwMhxCL8j: continue
		if n8w9ZDtYGS and fsPGqr6Odo5ZwMhxCL8j==TYebvtQSu6xzEm2acrqRX8o9Ik5H[-ta478EuZQJIWhgBnsf6iU(u"࠷ఱ")]: continue
		n8w9ZDtYGS = SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࡖࡵࡹࡪ౥")
		fsPGqr6Odo5ZwMhxCL8j = P6e9iLTvguIDEVpSwj2CGmkhlob73*WbM6qAjrn7fEXGZw(u"ࠨ࠲ࠪ૪")+fsPGqr6Odo5ZwMhxCL8j
		fsPGqr6Odo5ZwMhxCL8j = fsPGqr6Odo5ZwMhxCL8j[-P6e9iLTvguIDEVpSwj2CGmkhlob73:]
		s43fqH6V1SpcW59Y7APuXzNbCrJdG,cD4F6ebvkN3zHXB7OYl = uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠩࠪ૫"),qFRrj7ayBKbOsHGSXz(u"ࠪࠫ૬")
		QQmGdhBDSciCI5Vz2EawKlt7 = str(int(QmoEjB3hLIw(u"ࠫ࠾࠭૭")*(P6e9iLTvguIDEVpSwj2CGmkhlob73+FeyZbj8tDil0nSHzTwfsUJ9(u"࠱ల")))-int(fsPGqr6Odo5ZwMhxCL8j))[-P6e9iLTvguIDEVpSwj2CGmkhlob73:]
		for M4MgFXU1WRrCEDN in list(range(wx18CTJPZ5(u"࠱ళ"),P6e9iLTvguIDEVpSwj2CGmkhlob73,cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠶ఴ"))):
			bbXEMnomRTOAHKyD7Q1wP20 = QQmGdhBDSciCI5Vz2EawKlt7[M4MgFXU1WRrCEDN:M4MgFXU1WRrCEDN+Gk98CL5nXZEN(u"࠷వ")]
			s43fqH6V1SpcW59Y7APuXzNbCrJdG += bbXEMnomRTOAHKyD7Q1wP20+GGCQK6OAtZUXRhvkgJm(u"ࠬ࠳ࠧ૮")
			cD4F6ebvkN3zHXB7OYl += str(sum(map(int,fsPGqr6Odo5ZwMhxCL8j[M4MgFXU1WRrCEDN:M4MgFXU1WRrCEDN+cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠹ష")]))%CIcPowhneWs5tN3(u"࠵࠵శ"))
		OaoBgNnc8xrkQ = str(t24Zwa5I7oC9)+s43fqH6V1SpcW59Y7APuXzNbCrJdG+cD4F6ebvkN3zHXB7OYl
		pNX09rJfkc73GanEFRUsgdOA1SQy.append(OaoBgNnc8xrkQ)
	kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,dEUYJjrhsaPXNo(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ૯"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠧࡔࡋࡗࡉࡘࡥࡖࡆࡔࡌࡊ࡞࠭૰"),[YpE6FN9xTSOizWqhyCAuRo,lSszipXCwHAv5k,K8sEt7Pv30wDQ],Yv7e6ixHfZIPrmMOy3ozwJu2)
	kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,Kwl07iYTtDLN3zP(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ૱"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠩࡖࡍ࡙ࡋࡓࡠࡅࡋࡉࡈࡑࠧ૲"),[pNX09rJfkc73GanEFRUsgdOA1SQy,YpE6FN9xTSOizWqhyCAuRo,lSszipXCwHAv5k,K8sEt7Pv30wDQ],xgFTDVS7lf5Us6aj)
	return r6juULGQtnExAko38BZ5Y(u"ࠪࡠࡳ࠭૳").join(pNX09rJfkc73GanEFRUsgdOA1SQy)
def ynWephC0J6VPiHcqmrg8d(Rl48v7kIh3cgF1fzOS6mQ9,pAeIhbuLSFw7j49qxtcg8dDrmKO,YReuIJ67GDs8NwEiZOAh4xPMb,XzfkYQBICVuSjcL5G0pgy9T16xv,dIsZG1fHm5YVkU6Puzq,VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF):
	TC7fWv2a1gLJGiAtN8 = str(XzfkYQBICVuSjcL5G0pgy9T16xv)[qFRrj7ayBKbOsHGSXz(u"࠶స"):qFRrj7ayBKbOsHGSXz(u"࠲࠶࠲హ")].replace(I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠫࡡࡴࠧ૴"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠬࡢ࡜࡯ࠩ૵")).replace(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠭࡜ࡳࠩ૶"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠧ࡝࡞ࡵࠫ૷")).replace(WbM6qAjrn7fEXGZw(u"ࠨࠢࠣࠤࠥ࠭૸"),QmoEjB3hLIw(u"ࠩࠣࠫૹ")).replace(smpniPDOhfwI3H4v7c6TG(u"ࠪࠤࠥࠦࠧૺ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠫࠥ࠭ૻ"))
	if len(str(XzfkYQBICVuSjcL5G0pgy9T16xv))>FeyZbj8tDil0nSHzTwfsUJ9(u"࠳࠷࠳఺"): TC7fWv2a1gLJGiAtN8 = TC7fWv2a1gLJGiAtN8+QmoEjB3hLIw(u"ࠬࠦ࠮࠯࠰ࠪૼ")
	bhfgckoLVtsA2DXv = str(YReuIJ67GDs8NwEiZOAh4xPMb)[zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠲఻"):CIcPowhneWs5tN3(u"࠵࠹࠵఼")].replace(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠭࡜࡯ࠩ૽"),GGCQK6OAtZUXRhvkgJm(u"ࠧ࡝࡞ࡱࠫ૾")).replace(cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠨ࡞ࡵࠫ૿"),smpniPDOhfwI3H4v7c6TG(u"ࠩ࡟ࡠࡷ࠭଀")).replace(Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠪࠤࠥࠦࠠࠨଁ"),S26SnaqcM9XwK8PVphJDv5(u"ࠫࠥ࠭ଂ")).replace(Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠬࠦࠠࠡࠩଃ"),bbqAtUz36RPGVTvCkejpJXQB(u"࠭ࠠࠨ଄"))
	if len(str(YReuIJ67GDs8NwEiZOAh4xPMb))>qFRrj7ayBKbOsHGSXz(u"࠶࠺࠶ఽ"): bhfgckoLVtsA2DXv = bhfgckoLVtsA2DXv+uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠧࠡ࠰࠱࠲ࠬଅ")
	y75wQavkVSLUb2MZf9qo(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠨࡐࡒࡘࡎࡉࡅࠨଆ"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠩ࠱ࠤࠥࡕࡐࡆࡐࡘࡖࡑࡥࠧଇ")+Rl48v7kIh3cgF1fzOS6mQ9+NxsKJnLFEZ9OHXf1h(u"ࠪࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ଈ")+pAeIhbuLSFw7j49qxtcg8dDrmKO+YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ଉ")+dIsZG1fHm5YVkU6Puzq+MM564HfnUV0XIR(u"ࠬࠦ࡝ࠡࠢࠣࡑࡪࡺࡨࡰࡦ࠽ࠤࡠࠦࠧଊ")+VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF+YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠭ࠠ࡞ࠢࠣࠤࡍ࡫ࡡࡥࡧࡵࡷ࠿࡛ࠦࠡࠩଋ")+str(TC7fWv2a1gLJGiAtN8)+S26SnaqcM9XwK8PVphJDv5(u"ࠧࠡ࡟ࠣࠤࠥࡊࡡࡵࡣ࠽ࠤࡠࠦࠧଌ")+bhfgckoLVtsA2DXv+wx18CTJPZ5(u"ࠨࠢࡠࠫ଍"))
	return
def hKfGjrBietyz8N7pD():
	global LIHJQ4M0k2aSRGdmUVNWfxFDBznh
	import getmac82 as HFBKfM8ItZhLPcsRQxnYEWjCqU4
	try:
		Xm3oMlDdBxVQ0TF5p8LOavni = HFBKfM8ItZhLPcsRQxnYEWjCqU4.get_mac_address()
		if Xm3oMlDdBxVQ0TF5p8LOavni.count(S26SnaqcM9XwK8PVphJDv5(u"ࠩ࠽ࠫ଎"))==uAl3gHavMJZL4xmNe62nDiBoQ(u"࠻ి") and Xm3oMlDdBxVQ0TF5p8LOavni.count(S26SnaqcM9XwK8PVphJDv5(u"ࠪ࠴ࠬଏ"))<bbqAtUz36RPGVTvCkejpJXQB(u"࠾ా"):
			Xm3oMlDdBxVQ0TF5p8LOavni = Xm3oMlDdBxVQ0TF5p8LOavni.lower().replace(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠫ࠿࠭ଐ"),Gk98CL5nXZEN(u"ࠬ࠭଑"))
			LIHJQ4M0k2aSRGdmUVNWfxFDBznh = str(int(Xm3oMlDdBxVQ0TF5p8LOavni,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠱࠷ీ")))
	except: pass
	return
def eUaPQldwVhA():
	global MEuQX1se0S9Rt
	import getmac94 as yhwEbSQ9sqIdAX
	try:
		PYdJmaErVKGX6uW8ZDMibAhU = yhwEbSQ9sqIdAX.get_mac_address()
		if PYdJmaErVKGX6uW8ZDMibAhU.count(CIcPowhneWs5tN3(u"࠭࠺ࠨ଒"))==WbM6qAjrn7fEXGZw(u"࠷ూ") and PYdJmaErVKGX6uW8ZDMibAhU.count(ItgK5FqGDz2Rf7mAJkbT(u"ࠧ࠱ࠩଓ"))<cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠺ు"):
			PYdJmaErVKGX6uW8ZDMibAhU = PYdJmaErVKGX6uW8ZDMibAhU.lower().replace(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠨ࠼ࠪଔ"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠩࠪକ"))
			MEuQX1se0S9Rt = str(int(PYdJmaErVKGX6uW8ZDMibAhU,WbM6qAjrn7fEXGZw(u"࠴࠺ృ")))
	except: pass
	return
def V4RQISWvYd8XhJ2s(VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF,pAeIhbuLSFw7j49qxtcg8dDrmKO,YReuIJ67GDs8NwEiZOAh4xPMb=MM564HfnUV0XIR(u"ࠪࠫଖ"),XzfkYQBICVuSjcL5G0pgy9T16xv=CgPbwXm1RilpJUSGHLhy(u"ࠫࠬଗ"),dIsZG1fHm5YVkU6Puzq=MM564HfnUV0XIR(u"ࠬ࠭ଘ")):
	ynWephC0J6VPiHcqmrg8d(smpniPDOhfwI3H4v7c6TG(u"࠭ࡕࡓࡎࡏࡍࡇࠦࠠࡐࡒࡈࡒࡤ࡛ࡒࡍࠩଙ"),pAeIhbuLSFw7j49qxtcg8dDrmKO,YReuIJ67GDs8NwEiZOAh4xPMb,XzfkYQBICVuSjcL5G0pgy9T16xv,dIsZG1fHm5YVkU6Puzq,VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF)
	if wvkR1es6d0SrjxKt5FZTMUWz7a: import urllib.request as bjZwl7dCKOgu9
	else: import urllib2 as bjZwl7dCKOgu9
	if not XzfkYQBICVuSjcL5G0pgy9T16xv: XzfkYQBICVuSjcL5G0pgy9T16xv = {FeyZbj8tDil0nSHzTwfsUJ9(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫଚ"):r6juULGQtnExAko38BZ5Y(u"ࠨࠩଛ")}
	if not YReuIJ67GDs8NwEiZOAh4xPMb: YReuIJ67GDs8NwEiZOAh4xPMb = {}
	if VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF==tOdiG2HWFRBXg1sUh(u"ࠩࡊࡉ࡙࠭ଜ"):
		pAeIhbuLSFw7j49qxtcg8dDrmKO = pAeIhbuLSFw7j49qxtcg8dDrmKO+CIcPowhneWs5tN3(u"ࠪࡃࠬଝ")+cswW2KC5FOH64vq97ZkNR(YReuIJ67GDs8NwEiZOAh4xPMb)
		YReuIJ67GDs8NwEiZOAh4xPMb = None
	elif VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF==CIcPowhneWs5tN3(u"ࠫࡕࡕࡓࡕࠩଞ") and MM564HfnUV0XIR(u"ࠬࡰࡳࡰࡰࠪଟ") in str(XzfkYQBICVuSjcL5G0pgy9T16xv):
		from json import dumps as c7kgPIzjmT
		YReuIJ67GDs8NwEiZOAh4xPMb = c7kgPIzjmT(YReuIJ67GDs8NwEiZOAh4xPMb)
		YReuIJ67GDs8NwEiZOAh4xPMb = str(YReuIJ67GDs8NwEiZOAh4xPMb).encode(QmoEjB3hLIw(u"࠭ࡵࡵࡨ࠻ࠫଠ"))
	elif VP0LoYhEfRGIl2A1xB6Mi9dkcmJeF==cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠧࡑࡑࡖࡘࠬଡ"):
		YReuIJ67GDs8NwEiZOAh4xPMb = cswW2KC5FOH64vq97ZkNR(YReuIJ67GDs8NwEiZOAh4xPMb)
		YReuIJ67GDs8NwEiZOAh4xPMb = YReuIJ67GDs8NwEiZOAh4xPMb.encode(wx18CTJPZ5(u"ࠨࡷࡷࡪ࠽࠭ଢ"))
	try:
		gzs2diw9HLqfMU3k8J0oWEjF = bjZwl7dCKOgu9.Request(pAeIhbuLSFw7j49qxtcg8dDrmKO,headers=XzfkYQBICVuSjcL5G0pgy9T16xv,data=YReuIJ67GDs8NwEiZOAh4xPMb)
		Il5iAWS8vkNBe4Xf = bjZwl7dCKOgu9.urlopen(gzs2diw9HLqfMU3k8J0oWEjF)
		TcPFsujHEQG3vBwCt = Il5iAWS8vkNBe4Xf.read()
		G4KzAhcON3gwns1o5rIbai2FDJEXmy,rreason = tOdiG2HWFRBXg1sUh(u"࠶࠵࠶ౄ"),smpniPDOhfwI3H4v7c6TG(u"ࠩࡒࡏࠬଣ")
	except:
		TcPFsujHEQG3vBwCt = bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠪࠫତ")
		G4KzAhcON3gwns1o5rIbai2FDJEXmy,rreason = -dEUYJjrhsaPXNo(u"࠶౅"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥࡋࡲࡳࡱࡵࠫଥ")
	y75wQavkVSLUb2MZf9qo(CIcPowhneWs5tN3(u"ࠬࡔࡏࡕࡋࡆࡉࠬଦ"),qFRrj7ayBKbOsHGSXz(u"࠭࠮ࠡࠢࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄࠣࠤࡗࡋࡓࡑࡑࡑࡗࡊࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩଧ")+str(G4KzAhcON3gwns1o5rIbai2FDJEXmy)+tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩନ")+rreason+Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ଩")+dIsZG1fHm5YVkU6Puzq+FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨପ")+pAeIhbuLSFw7j49qxtcg8dDrmKO+SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠪࠤࡢ࠭ଫ"))
	if TcPFsujHEQG3vBwCt and wvkR1es6d0SrjxKt5FZTMUWz7a: TcPFsujHEQG3vBwCt = TcPFsujHEQG3vBwCt.decode(qFRrj7ayBKbOsHGSXz(u"ࠫࡺࡺࡦ࠹ࠩବ"))
	return TcPFsujHEQG3vBwCt
def YQqPDl7UoC53sKbO(VMKz1jo8R9uHPTCfG6OF2bi5,TI74BWVa16AS3vjRZKcb9p=FeyZbj8tDil0nSHzTwfsUJ9(u"ࠬ࠭ଭ")):
	W1eDt0N92gF = str(BBioyg7XVR.randrange(CIcPowhneWs5tN3(u"࠷࠱࠲࠳࠴࠵࠶࠷࠱࠲࠳࠴ె"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠹࠺࠻࠼࠽࠾࠿࠹࠺࠻࠼࠽ే")))
	XzfkYQBICVuSjcL5G0pgy9T16xv = {wx18CTJPZ5(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬମ"):NNmirJKPp5nWjfC(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡰࡳࡰࡰࠪଯ")}
	IwuEG4WZQa = {	qFRrj7ayBKbOsHGSXz(u"ࠣࡷࡶࡩࡷࡥࡩࡥࠤର"):zVw5tvmZRX(ta478EuZQJIWhgBnsf6iU(u"࠵࠵౉")).splitlines()[r6juULGQtnExAko38BZ5Y(u"࠳ొ")][-I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠳࠶ై"):],
				Kwl07iYTtDLN3zP(u"ࠤࡲࡷࡤࡼࡥࡳࡵ࡬ࡳࡳࠨ଱"):str(wH3qxmuXBTeak),
				Gk98CL5nXZEN(u"ࠥࡥࡵࡶ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠣଲ"):VnhK9wvHBGuo1fei8DXQ02yFZtsWE,
				CIcPowhneWs5tN3(u"ࠦࡩ࡫ࡶࡪࡥࡨࡣ࡫ࡧ࡭ࡪ࡮ࡼࠦଳ"):VnhK9wvHBGuo1fei8DXQ02yFZtsWE,
				bbqAtUz36RPGVTvCkejpJXQB(u"ࠧ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠤ଴"):VMKz1jo8R9uHPTCfG6OF2bi5,
				ta478EuZQJIWhgBnsf6iU(u"ࠨࡰ࡭ࡣࡷࡪࡴࡸ࡭ࠣଵ"): VnhK9wvHBGuo1fei8DXQ02yFZtsWE,
				CIcPowhneWs5tN3(u"ࠢࡤࡣࡵࡶ࡮࡫ࡲࠣଶ"):r6juULGQtnExAko38BZ5Y(u"ࠣࡃࡕࡅࡇࡏࡃࡠࡘࡌࡈࡊࡕࡓࠣଷ"),
				cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠤࡨࡺࡪࡴࡴࡠࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷࠧସ"):{bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠥࡉࡻ࡫࡮ࡵࡡࡑࡥࡲ࡫ࠢହ"):VMKz1jo8R9uHPTCfG6OF2bi5},
				bbqAtUz36RPGVTvCkejpJXQB(u"ࠦࡺࡹࡥࡳࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸࠨ଺"): {ItgK5FqGDz2Rf7mAJkbT(u"࡛ࠧࡳࡦࡴࡢࡉࡻ࡫࡮ࡵࡡࡑࡥࡲ࡫ࠢ଻"):VMKz1jo8R9uHPTCfG6OF2bi5},
				NxsKJnLFEZ9OHXf1h(u"ࠨࠤࡴ࡭࡬ࡴࡤࡻࡳࡦࡴࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹ࡟ࡴࡻࡱࡧ଼ࠧ"):zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࡉࡥࡱࡹࡥ౦"),
				I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠢࡪࡲࠥଽ"): FeyZbj8tDil0nSHzTwfsUJ9(u"ࠣࠦࡵࡩࡲࡵࡴࡦࠤା")
			}
	if not TI74BWVa16AS3vjRZKcb9p: iSBu5mnyrNRzoGM2kL = [IwuEG4WZQa]
	else:
		U7UKiHAW1Ztov2gN8Mq5kTm = IwuEG4WZQa.copy()
		U7UKiHAW1Ztov2gN8Mq5kTm[zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠩࡨࡺࡪࡴࡴࡠࡶࡼࡴࡪ࠭ି")] = TI74BWVa16AS3vjRZKcb9p
		U7UKiHAW1Ztov2gN8Mq5kTm[CgPbwXm1RilpJUSGHLhy(u"ࠪࡩࡻ࡫࡮ࡵࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸ࠭ୀ")] = {cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠦࡊࡼࡥ࡯ࡶࡢࡒࡦࡳࡥࠣୁ"):TI74BWVa16AS3vjRZKcb9p}
		U7UKiHAW1Ztov2gN8Mq5kTm[Gk98CL5nXZEN(u"ࠬࡻࡳࡦࡴࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠧୂ")] = {cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠨࡕࡴࡧࡵࡣࡊࡼࡥ࡯ࡶࡢࡒࡦࡳࡥࠣୃ"):TI74BWVa16AS3vjRZKcb9p}
		iSBu5mnyrNRzoGM2kL = [IwuEG4WZQa,U7UKiHAW1Ztov2gN8Mq5kTm]
	YReuIJ67GDs8NwEiZOAh4xPMb = {ta478EuZQJIWhgBnsf6iU(u"ࠢࡢࡲ࡬ࡣࡰ࡫ࡹࠣୄ"):CgPbwXm1RilpJUSGHLhy(u"ࠨ࠴࠸࠸ࡩࡪ࠳ࡢ࠶࠳࠽ࡩ࠾ࡢ࠷࠺࠴ࡨ࠹࡫࠱࠲࠹ࡨࡩ࠼࠾ࡣࡦࡤࡩ࠶࠾࠭୅"),
			bbqAtUz36RPGVTvCkejpJXQB(u"ࠤ࡬ࡲࡸ࡫ࡲࡵࡡ࡬ࡨࠧ୆"):W1eDt0N92gF,
			smpniPDOhfwI3H4v7c6TG(u"ࠥࡩࡻ࡫࡮ࡵࡵࠥେ"): iSBu5mnyrNRzoGM2kL
		}
	pAeIhbuLSFw7j49qxtcg8dDrmKO = EAw9bg4rT3Bd8tjSkO(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡰࡪ࠴࠱ࡥࡲࡶ࡬ࡪࡶࡸࡨࡪ࠴ࡣࡰ࡯࠲࠶࠴࡮ࡴࡵࡲࡤࡴ࡮࠭ୈ")
	TcPFsujHEQG3vBwCt = V4RQISWvYd8XhJ2s(GGCQK6OAtZUXRhvkgJm(u"ࠬࡖࡏࡔࡖࠪ୉"),pAeIhbuLSFw7j49qxtcg8dDrmKO,YReuIJ67GDs8NwEiZOAh4xPMb,XzfkYQBICVuSjcL5G0pgy9T16xv,Gk98CL5nXZEN(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡇࡑࡈࡤࡇࡎࡂࡎ࡜ࡘࡎࡉࡓࡠࡇ࡙ࡉࡓ࡚࠭࠲ࡵࡷࠫ୊"))
	return TcPFsujHEQG3vBwCt
def GVQAnvYCT3dS(fq8wviaxCU,hfNZTDrYABwyVcJQlqPS48xpHIi7s):
	hfNZTDrYABwyVcJQlqPS48xpHIi7s = hfNZTDrYABwyVcJQlqPS48xpHIi7s.replace(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠧ࡯ࡷ࡯ࡰࠬୋ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠨࡐࡲࡲࡪ࠭ୌ"))
	hfNZTDrYABwyVcJQlqPS48xpHIi7s = hfNZTDrYABwyVcJQlqPS48xpHIi7s.replace(wx18CTJPZ5(u"ࠩࡷࡶࡺ࡫୍ࠧ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠪࡘࡷࡻࡥࠨ୎"))
	hfNZTDrYABwyVcJQlqPS48xpHIi7s = hfNZTDrYABwyVcJQlqPS48xpHIi7s.replace(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠫ࡫ࡧ࡬ࡴࡧࠪ୏"),CgPbwXm1RilpJUSGHLhy(u"ࠬࡌࡡ࡭ࡵࡨࠫ୐"))
	hfNZTDrYABwyVcJQlqPS48xpHIi7s = hfNZTDrYABwyVcJQlqPS48xpHIi7s.replace(ta478EuZQJIWhgBnsf6iU(u"࠭࡜࠰ࠩ୑"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠧ࠰ࠩ୒"))
	try: qum4VoYNQsc21iMZ76LzRtp = eval(hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	except: qum4VoYNQsc21iMZ76LzRtp = LvJykz3cZIhdCnrwKRABxO(fq8wviaxCU)
	return qum4VoYNQsc21iMZ76LzRtp
def bhzrQ2wcHVodXEvneLqsMm9WF():
	Rl48v7kIh3cgF1fzOS6mQ9,TDmqAUj2Mfyir0PvS,pAeIhbuLSFw7j49qxtcg8dDrmKO,sBjdZmqit76bCRPyFLaQ5V1v,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,hfNZTDrYABwyVcJQlqPS48xpHIi7s,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH = VVuCNFHGiUftREgnP4Aw(mpUuAaIVfPRoQEligGywDYz1)
	e1ebv6pD8mUitJkPXqwnjr = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠨ࡞ࡧࡠࡩࡀ࡜ࡥ࡞ࡧࠤࡡࡡ࠯ࡄࡑࡏࡓࡗࡢ࡝ࠨ୓"),TDmqAUj2Mfyir0PvS,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if e1ebv6pD8mUitJkPXqwnjr: TDmqAUj2Mfyir0PvS = TDmqAUj2Mfyir0PvS.split(e1ebv6pD8mUitJkPXqwnjr[Gk98CL5nXZEN(u"࠵ౌ")],tOdiG2HWFRBXg1sUh(u"࠵ో"))[tOdiG2HWFRBXg1sUh(u"࠵ో")]
	A85xaIbUWud1kQDF2XNV4OHmPepBR = w6vebiEZtpCjJcILP8Skx5rHn.strftime(Kwl07iYTtDLN3zP(u"ࠩࡢࠩࡲ࠴ࠥࡥࡡࠨࡌ࠿ࠫࡍࡠࠩ୔"),w6vebiEZtpCjJcILP8Skx5rHn.localtime(eOYicX68ruMjpN0dKtWP5QTSE))
	TDmqAUj2Mfyir0PvS = TDmqAUj2Mfyir0PvS+A85xaIbUWud1kQDF2XNV4OHmPepBR
	zPEbGfWv2ehc1Akr4tiR = Rl48v7kIh3cgF1fzOS6mQ9,TDmqAUj2Mfyir0PvS,pAeIhbuLSFw7j49qxtcg8dDrmKO,sBjdZmqit76bCRPyFLaQ5V1v,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,hfNZTDrYABwyVcJQlqPS48xpHIi7s,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH
	if K3hFytImeYMkJBC.path.exists(D5q7g8N0XowOn2Q):
		xxMqmzh3YOFKHbyCQtUwjL2slZV = open(D5q7g8N0XowOn2Q,smpniPDOhfwI3H4v7c6TG(u"ࠪࡶࡧ࠭୕")).read()
		if wvkR1es6d0SrjxKt5FZTMUWz7a: xxMqmzh3YOFKHbyCQtUwjL2slZV = xxMqmzh3YOFKHbyCQtUwjL2slZV.decode(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠫࡺࡺࡦ࠹ࠩୖ"))
		xxMqmzh3YOFKHbyCQtUwjL2slZV = GVQAnvYCT3dS(MM564HfnUV0XIR(u"ࠬࡪࡩࡤࡶࠪୗ"),xxMqmzh3YOFKHbyCQtUwjL2slZV)
	else: xxMqmzh3YOFKHbyCQtUwjL2slZV = {}
	zQLoZxqihtkKVUmnJYEMu4OwI6Cal = {}
	for NTqV2MKtP7xUnAum0FoysbO4ZjGfXh in list(xxMqmzh3YOFKHbyCQtUwjL2slZV.keys()):
		if NTqV2MKtP7xUnAum0FoysbO4ZjGfXh!=Rl48v7kIh3cgF1fzOS6mQ9: zQLoZxqihtkKVUmnJYEMu4OwI6Cal[NTqV2MKtP7xUnAum0FoysbO4ZjGfXh] = xxMqmzh3YOFKHbyCQtUwjL2slZV[NTqV2MKtP7xUnAum0FoysbO4ZjGfXh]
		else:
			if TDmqAUj2Mfyir0PvS and TDmqAUj2Mfyir0PvS!=cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠭࠮࠯ࠩ୘"):
				oGLmp0EDJvT = xxMqmzh3YOFKHbyCQtUwjL2slZV[NTqV2MKtP7xUnAum0FoysbO4ZjGfXh]
				if zPEbGfWv2ehc1Akr4tiR in oGLmp0EDJvT:
					EeWNT4ZgLwnchCSIjJKX = oGLmp0EDJvT.index(zPEbGfWv2ehc1Akr4tiR)
					del oGLmp0EDJvT[EeWNT4ZgLwnchCSIjJKX]
				S85FOrQ2sZNmT = [zPEbGfWv2ehc1Akr4tiR]+oGLmp0EDJvT
				S85FOrQ2sZNmT = S85FOrQ2sZNmT[:cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠻࠰్")]
				zQLoZxqihtkKVUmnJYEMu4OwI6Cal[NTqV2MKtP7xUnAum0FoysbO4ZjGfXh] = S85FOrQ2sZNmT
			else: zQLoZxqihtkKVUmnJYEMu4OwI6Cal[NTqV2MKtP7xUnAum0FoysbO4ZjGfXh] = xxMqmzh3YOFKHbyCQtUwjL2slZV[NTqV2MKtP7xUnAum0FoysbO4ZjGfXh]
	if Rl48v7kIh3cgF1fzOS6mQ9 not in list(zQLoZxqihtkKVUmnJYEMu4OwI6Cal.keys()): zQLoZxqihtkKVUmnJYEMu4OwI6Cal[Rl48v7kIh3cgF1fzOS6mQ9] = [zPEbGfWv2ehc1Akr4tiR]
	zQLoZxqihtkKVUmnJYEMu4OwI6Cal = str(zQLoZxqihtkKVUmnJYEMu4OwI6Cal)
	if wvkR1es6d0SrjxKt5FZTMUWz7a: zQLoZxqihtkKVUmnJYEMu4OwI6Cal = zQLoZxqihtkKVUmnJYEMu4OwI6Cal.encode(S26SnaqcM9XwK8PVphJDv5(u"ࠧࡶࡶࡩ࠼ࠬ୙"))
	open(D5q7g8N0XowOn2Q,S26SnaqcM9XwK8PVphJDv5(u"ࠨࡹࡥࠫ୚")).write(zQLoZxqihtkKVUmnJYEMu4OwI6Cal)
	return
def kkNiXj3oTnqxQPvLMCfSKOm58F(AM9JTc4kHQBwve0Xh6i1,J8Pasjk3EUBtqIlWOwydvDohGX,oGQVFTZg6rnbE,YReuIJ67GDs8NwEiZOAh4xPMb,VWo9pg3saueIF8vNSkOUPyjcQh6,lvw246bUNu5IPLnJqXFCZHEtzMKQA1=QmoEjB3hLIw(u"ࡊࡦࡲࡳࡦ౧")):
	A2UGrN4JhjOEXKF3CmIogxRLtaBHye = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(EAw9bg4rT3Bd8tjSkO(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨ୛"))
	if A2UGrN4JhjOEXKF3CmIogxRLtaBHye==wx18CTJPZ5(u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫଡ଼") and VWo9pg3saueIF8vNSkOUPyjcQh6>ddEW38kMhf9mZGC6ePnFS: VWo9pg3saueIF8vNSkOUPyjcQh6 = ddEW38kMhf9mZGC6ePnFS
	if lvw246bUNu5IPLnJqXFCZHEtzMKQA1:
		LRtXWQ1zyFBCbP7SUhZ20a,W5W8HRkNrtcuAPbz3Kx4saFUDZIw = [],[]
		for Deiz7ocWQjVnIg in range(len(oGQVFTZg6rnbE)):
			hfNZTDrYABwyVcJQlqPS48xpHIi7s = nn7DVGBZsq0.dumps(YReuIJ67GDs8NwEiZOAh4xPMb[Deiz7ocWQjVnIg])
			ddZApOE0P2bxo3CrNYB5aTMq6nL = LPeE7ZjVag6xWTydcwQb.compress(hfNZTDrYABwyVcJQlqPS48xpHIi7s)
			LRtXWQ1zyFBCbP7SUhZ20a.append((oGQVFTZg6rnbE[Deiz7ocWQjVnIg],))
			W5W8HRkNrtcuAPbz3Kx4saFUDZIw.append((VWo9pg3saueIF8vNSkOUPyjcQh6+eOYicX68ruMjpN0dKtWP5QTSE,str(oGQVFTZg6rnbE[Deiz7ocWQjVnIg]),ddZApOE0P2bxo3CrNYB5aTMq6nL))
	else:
		hfNZTDrYABwyVcJQlqPS48xpHIi7s = nn7DVGBZsq0.dumps(YReuIJ67GDs8NwEiZOAh4xPMb)
		JK8VSmQEqXAwuZIvhP = LPeE7ZjVag6xWTydcwQb.compress(hfNZTDrYABwyVcJQlqPS48xpHIi7s)
	try: md59xZUEq3IOnPp2,ngBDPjZshKvdX6 = N5JUy4M8AKmjBZgL(AM9JTc4kHQBwve0Xh6i1)
	except: return
	while GGCQK6OAtZUXRhvkgJm(u"࡙ࡸࡵࡦ౨"):
		try:
			ngBDPjZshKvdX6.execute(uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠫࡇࡋࡇࡊࡐࠣࡍࡒࡓࡅࡅࡋࡄࡘࡊࠦࡔࡓࡃࡑࡗࡆࡉࡔࡊࡑࡑࠤࡀ࠭ଢ଼"))
			break
		except: w6vebiEZtpCjJcILP8Skx5rHn.sleep(qFRrj7ayBKbOsHGSXz(u"࠰࠯࠷౎"))
	ngBDPjZshKvdX6.execute(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠬࡉࡒࡆࡃࡗࡉ࡚ࠥࡁࡃࡎࡈࠤࡎࡌࠠࡏࡑࡗࠤࡊ࡞ࡉࡔࡖࡖࠤࠧ࠭୞")+J8Pasjk3EUBtqIlWOwydvDohGX+dEUYJjrhsaPXNo(u"࠭ࠢࠡࠪࡨࡼࡵ࡯ࡲࡺ࠮ࡦࡳࡱࡻ࡭࡯࠮ࡧࡥࡹࡧࠩࠡ࠽ࠪୟ"))
	if lvw246bUNu5IPLnJqXFCZHEtzMKQA1:
		ngBDPjZshKvdX6.executemany(dEUYJjrhsaPXNo(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧୠ")+J8Pasjk3EUBtqIlWOwydvDohGX+tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨୡ"),LRtXWQ1zyFBCbP7SUhZ20a)
		ngBDPjZshKvdX6.executemany(ta478EuZQJIWhgBnsf6iU(u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࠣࠩୢ")+J8Pasjk3EUBtqIlWOwydvDohGX+YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠪࠦࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮࠿࠭ࡁ࠯ࡃ࠮ࠦ࠻ࠨୣ"),W5W8HRkNrtcuAPbz3Kx4saFUDZIw)
	else:
		if VWo9pg3saueIF8vNSkOUPyjcQh6:
			ddTp9nAXO35utigMREqaSlU = (str(oGQVFTZg6rnbE),)
			ngBDPjZshKvdX6.execute(Kwl07iYTtDLN3zP(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫ୤")+J8Pasjk3EUBtqIlWOwydvDohGX+tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࠽ࠡࡁࠣ࠿ࠬ୥"),ddTp9nAXO35utigMREqaSlU)
			ddTp9nAXO35utigMREqaSlU = (VWo9pg3saueIF8vNSkOUPyjcQh6+eOYicX68ruMjpN0dKtWP5QTSE,str(oGQVFTZg6rnbE),JK8VSmQEqXAwuZIvhP)
			ngBDPjZshKvdX6.execute(wx18CTJPZ5(u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࠧ࠭୦")+J8Pasjk3EUBtqIlWOwydvDohGX+Gk98CL5nXZEN(u"࡙ࠧࠣࠢࡅࡑ࡛ࡅࡔࠢࠫࡃ࠱ࡅࠬࡀࠫࠣ࠿ࠬ୧"),ddTp9nAXO35utigMREqaSlU)
		else:
			ddTp9nAXO35utigMREqaSlU = (JK8VSmQEqXAwuZIvhP,str(oGQVFTZg6rnbE))
			ngBDPjZshKvdX6.execute(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠨࡗࡓࡈࡆ࡚ࡅࠡࠤࠪ୨")+J8Pasjk3EUBtqIlWOwydvDohGX+smpniPDOhfwI3H4v7c6TG(u"ࠩࠥࠤࡘࡋࡔࠡࡦࡤࡸࡦࠦ࠽ࠡࡁ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨ୩"),ddTp9nAXO35utigMREqaSlU)
	md59xZUEq3IOnPp2.commit()
	md59xZUEq3IOnPp2.close()
	return
def cswW2KC5FOH64vq97ZkNR(YReuIJ67GDs8NwEiZOAh4xPMb):
	if wvkR1es6d0SrjxKt5FZTMUWz7a: import urllib.parse as bbD76POWGTQlxg9VntcqSEyr
	else: import urllib as bbD76POWGTQlxg9VntcqSEyr
	UU5zoLOGY86jl2PHNX9iKhkCr3eVxm = bbD76POWGTQlxg9VntcqSEyr.urlencode(YReuIJ67GDs8NwEiZOAh4xPMb)
	return UU5zoLOGY86jl2PHNX9iKhkCr3eVxm
PFlaYj0qTWHmCOI5cKtbvQ9wzD = bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠪࠫ୪")
def pSAuLjYqhgc9brWFKs7Pa4J(TW6JIBgC971tjOE,GowEgKmITalyMQHbZkt=wx18CTJPZ5(u"ࠫࠬ୫"),KVHOBcfFun=FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠬ࠭୬")):
	yyhDGOU25dw9XjIYZp = GowEgKmITalyMQHbZkt not in [YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠭ࡍ࠴ࡗࠪ୭"),WbM6qAjrn7fEXGZw(u"ࠧࡊࡒࡗ࡚ࠬ୮")]
	global PFlaYj0qTWHmCOI5cKtbvQ9wzD
	if not KVHOBcfFun: KVHOBcfFun = ItgK5FqGDz2Rf7mAJkbT(u"ࠨࡸ࡬ࡨࡪࡵࠧ୯")
	PFlaYj0qTWHmCOI5cKtbvQ9wzD,pzqjL37rV1Z5g,uRpd9TteE6xkGvj2gyAmqlQoPKCXS = bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧ࠴ࠬ୰"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠪࠫୱ"),QmoEjB3hLIw(u"ࠫࠬ୲")
	if len(TW6JIBgC971tjOE)==FeyZbj8tDil0nSHzTwfsUJ9(u"࠴౏"):
		pAeIhbuLSFw7j49qxtcg8dDrmKO,yPNzds8S6pE0mOjUHcZA4,uRpd9TteE6xkGvj2gyAmqlQoPKCXS = TW6JIBgC971tjOE
		if yPNzds8S6pE0mOjUHcZA4: pzqjL37rV1Z5g = NxsKJnLFEZ9OHXf1h(u"ࠬࠦࠠࠡࡕࡸࡦࡹ࡯ࡴ࡭ࡧ࠽ࠤࡠࠦࠧ୳")+yPNzds8S6pE0mOjUHcZA4+uAl3gHavMJZL4xmNe62nDiBoQ(u"࠭ࠠ࡞ࠩ୴")
	else: pAeIhbuLSFw7j49qxtcg8dDrmKO,yPNzds8S6pE0mOjUHcZA4,uRpd9TteE6xkGvj2gyAmqlQoPKCXS = TW6JIBgC971tjOE,WbM6qAjrn7fEXGZw(u"ࠧࠨ୵"),CIcPowhneWs5tN3(u"ࠨࠩ୶")
	pAeIhbuLSFw7j49qxtcg8dDrmKO = pAeIhbuLSFw7j49qxtcg8dDrmKO.replace(WbM6qAjrn7fEXGZw(u"ࠩࠨ࠶࠵࠭୷"),smpniPDOhfwI3H4v7c6TG(u"ࠪࠤࠬ୸"))
	Pu43YtENBjiyp2KoFQWqHTw6XOlk = SU82u7LfcMslH3e0Bzihn6x(pAeIhbuLSFw7j49qxtcg8dDrmKO)
	if GowEgKmITalyMQHbZkt not in [cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭୹"),Kwl07iYTtDLN3zP(u"ࠬࡏࡐࡕࡘࠪ୺")]:
		if GowEgKmITalyMQHbZkt!=FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ୻"): pAeIhbuLSFw7j49qxtcg8dDrmKO = pAeIhbuLSFw7j49qxtcg8dDrmKO.replace(ta478EuZQJIWhgBnsf6iU(u"ࠧࠡࠩ୼"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠨࠧ࠵࠴ࠬ୽"))
		y75wQavkVSLUb2MZf9qo(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ୾"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+MM564HfnUV0XIR(u"ࠪࠤࠥࠦࡐࡳࡧࡳࡥࡷ࡯࡮ࡨࠢࡷࡳࠥࡶ࡬ࡢࡻ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡼࡩࡥࡧࡲࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ୿")+pAeIhbuLSFw7j49qxtcg8dDrmKO+NNmirJKPp5nWjfC(u"ࠫࠥࡣࠧ஀")+pzqjL37rV1Z5g)
		if Pu43YtENBjiyp2KoFQWqHTw6XOlk==uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ஁") and GowEgKmITalyMQHbZkt not in [QmoEjB3hLIw(u"࠭ࡉࡑࡖ࡙ࠫஂ"),Kwl07iYTtDLN3zP(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨஃ")]:
			from zbUtu6IvKA import nPVJZWtkEb27UQ9AK,pYRLgOuVTAUM4wKJchdbkzfBql,xa60ce2znAlyL5Z8ESXhO
			da6IAnqQ7oV2Hx13F5gbBT4,jVMHRouKgQFAESmd7B8ObTYy = nPVJZWtkEb27UQ9AK(pAeIhbuLSFw7j49qxtcg8dDrmKO)
			GG5hd4btHaJZ6uYWiXEoPFU3Of = len(jVMHRouKgQFAESmd7B8ObTYy)
			if GG5hd4btHaJZ6uYWiXEoPFU3Of>CgPbwXm1RilpJUSGHLhy(u"࠳౐"):
				NljOosKT8WJBpch = pYRLgOuVTAUM4wKJchdbkzfBql(cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠠࠩࠩ஄")+str(GG5hd4btHaJZ6uYWiXEoPFU3Of)+YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"้้ࠩࠣ็ࠩࠨஅ"), da6IAnqQ7oV2Hx13F5gbBT4)
				if NljOosKT8WJBpch==-cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠴౑"):
					xa60ce2znAlyL5Z8ESXhO(ItgK5FqGDz2Rf7mAJkbT(u"ࠪฮ๊ࠦลๅ฼สลࠥอไหึ฽๎้࠭ஆ"),tOdiG2HWFRBXg1sUh(u"ࠫࠬஇ"))
					return PFlaYj0qTWHmCOI5cKtbvQ9wzD
			else: NljOosKT8WJBpch = ta478EuZQJIWhgBnsf6iU(u"࠴౒")
			pAeIhbuLSFw7j49qxtcg8dDrmKO = jVMHRouKgQFAESmd7B8ObTYy[NljOosKT8WJBpch]
			if da6IAnqQ7oV2Hx13F5gbBT4[Kwl07iYTtDLN3zP(u"࠵౓")]!=S26SnaqcM9XwK8PVphJDv5(u"ࠬ࠳࠱ࠨஈ"):
				y75wQavkVSLUb2MZf9qo(CgPbwXm1RilpJUSGHLhy(u"࠭ࡎࡐࡖࡌࡇࡊ࠭உ"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡖࡩࡱ࡫ࡣࡵࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡯࡯࡯࠼ࠣ࡟ࠥ࠭ஊ")+da6IAnqQ7oV2Hx13F5gbBT4[NljOosKT8WJBpch]+CgPbwXm1RilpJUSGHLhy(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ஋")+pAeIhbuLSFw7j49qxtcg8dDrmKO+QmoEjB3hLIw(u"ࠩࠣࡡࠬ஌"))
		if ta478EuZQJIWhgBnsf6iU(u"ࠪ࠳࡮࡬ࡩ࡭࡯࠲ࠫ஍") in pAeIhbuLSFw7j49qxtcg8dDrmKO: pAeIhbuLSFw7j49qxtcg8dDrmKO = pAeIhbuLSFw7j49qxtcg8dDrmKO+Gk98CL5nXZEN(u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠩࠫஎ")
		elif YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠬ࡮ࡴࡵࡲࠪஏ") in pAeIhbuLSFw7j49qxtcg8dDrmKO.lower() and FeyZbj8tDil0nSHzTwfsUJ9(u"࠭࠯ࡥࡣࡶ࡬࠴࠭ஐ") not in pAeIhbuLSFw7j49qxtcg8dDrmKO and MM564HfnUV0XIR(u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ஑") not in pAeIhbuLSFw7j49qxtcg8dDrmKO:
			if EAw9bg4rT3Bd8tjSkO(u"ࠨࡸࡨࡶ࡮࡬ࡹࡱࡧࡨࡶࡂ࠭ஒ") not in pAeIhbuLSFw7j49qxtcg8dDrmKO and uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫஓ") in pAeIhbuLSFw7j49qxtcg8dDrmKO.lower():
				if NxsKJnLFEZ9OHXf1h(u"ࠪࢀࠬஔ") not in pAeIhbuLSFw7j49qxtcg8dDrmKO: pAeIhbuLSFw7j49qxtcg8dDrmKO = pAeIhbuLSFw7j49qxtcg8dDrmKO+EAw9bg4rT3Bd8tjSkO(u"ࠫࢁࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࡩࡥࡱࡹࡥࠨக")
				else: pAeIhbuLSFw7j49qxtcg8dDrmKO = pAeIhbuLSFw7j49qxtcg8dDrmKO+EAw9bg4rT3Bd8tjSkO(u"ࠬࠬࡶࡦࡴ࡬ࡪࡾࡶࡥࡦࡴࡀࡪࡦࡲࡳࡦࠩ஖")
			if CIcPowhneWs5tN3(u"࠭ࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࠪ஗") not in pAeIhbuLSFw7j49qxtcg8dDrmKO.lower() and GowEgKmITalyMQHbZkt not in [FeyZbj8tDil0nSHzTwfsUJ9(u"ࠧࡊࡒࡗ࡚ࠬ஘"),dEUYJjrhsaPXNo(u"ࠨࡏ࠶࡙ࠬங")]:
				if smpniPDOhfwI3H4v7c6TG(u"ࠩࡿࠫச") not in pAeIhbuLSFw7j49qxtcg8dDrmKO: pAeIhbuLSFw7j49qxtcg8dDrmKO = pAeIhbuLSFw7j49qxtcg8dDrmKO+bbqAtUz36RPGVTvCkejpJXQB(u"ࠪࢀ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠨࠪ஛")
				else: pAeIhbuLSFw7j49qxtcg8dDrmKO = pAeIhbuLSFw7j49qxtcg8dDrmKO+bbqAtUz36RPGVTvCkejpJXQB(u"࡛ࠫࠫࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠩࠫஜ")
	y75wQavkVSLUb2MZf9qo(MM564HfnUV0XIR(u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ஝"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+qFRrj7ayBKbOsHGSXz(u"࠭ࠠࠡࠢࡊࡳࡹࠦࡦࡪࡰࡤࡰࠥࡻࡲ࡭ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬஞ")+pAeIhbuLSFw7j49qxtcg8dDrmKO+MM564HfnUV0XIR(u"ࠧࠡ࡟ࠪட"))
	tMpPCI8iJva0 = ZuEAJR1lNHkUf0.ListItem()
	KVHOBcfFun,ECwgo4qVaZAzx9eS,Bf5QkcruZNX4SU6IeEvGj,fDowOUqkis,Dj4rSONYXVbF8f9Hd0oWBp,t2zEwrA80WRjLel5NSvXyHd,jX4zgTedBkEJlxy9IbSR3vwNU,vlntrPLopfSb,eU9G76lNkSOhxp4ua0H = VVuCNFHGiUftREgnP4Aw(mpUuAaIVfPRoQEligGywDYz1)
	if GowEgKmITalyMQHbZkt not in [smpniPDOhfwI3H4v7c6TG(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ஠"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠩࡌࡔ࡙࡜ࠧ஡")]:
		if vciEXHThAPto76QIR2pK: d6nQJfK4m5x9VLa = dEUYJjrhsaPXNo(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭ࡢࡦࡧࡳࡳ࠭஢")
		else: d6nQJfK4m5x9VLa = Gk98CL5nXZEN(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮ࠩண")
		tMpPCI8iJva0.setProperty(d6nQJfK4m5x9VLa, SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠬ࠭த"))
		tMpPCI8iJva0.setMimeType(WbM6qAjrn7fEXGZw(u"࠭࡭ࡪ࡯ࡨ࠳ࡽ࠳ࡴࡺࡲࡨࠫ஥"))
		if wH3qxmuXBTeak<tOdiG2HWFRBXg1sUh(u"࠸࠰౔"): tMpPCI8iJva0.setInfo(r6juULGQtnExAko38BZ5Y(u"ࠧࡷ࡫ࡧࡩࡴ࠭஦"),{bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠨ࡯ࡨࡨ࡮ࡧࡴࡺࡲࡨࠫ஧"):uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠩࡰࡳࡻ࡯ࡥࠨந")})
		else:
			DMcnjzXwKk = tMpPCI8iJva0.getVideoInfoTag()
			DMcnjzXwKk.setMediaType(FeyZbj8tDil0nSHzTwfsUJ9(u"ࠪࡱࡴࡼࡩࡦࠩன"))
		tMpPCI8iJva0.setArt({FeyZbj8tDil0nSHzTwfsUJ9(u"ࠫࡹ࡮ࡵ࡮ࡤࠪப"):Dj4rSONYXVbF8f9Hd0oWBp,EAw9bg4rT3Bd8tjSkO(u"ࠬࡶ࡯ࡴࡶࡨࡶࠬ஫"):Dj4rSONYXVbF8f9Hd0oWBp,YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠭ࡢࡢࡰࡱࡩࡷ࠭஬"):Dj4rSONYXVbF8f9Hd0oWBp,Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠧࡧࡣࡱࡥࡷࡺࠧ஭"):Dj4rSONYXVbF8f9Hd0oWBp,I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠨࡥ࡯ࡩࡦࡸࡡࡳࡶࠪம"):Dj4rSONYXVbF8f9Hd0oWBp,cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠩࡦࡰࡪࡧࡲ࡭ࡱࡪࡳࠬய"):Dj4rSONYXVbF8f9Hd0oWBp,YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭ர"):Dj4rSONYXVbF8f9Hd0oWBp,GGCQK6OAtZUXRhvkgJm(u"ࠫ࡮ࡩ࡯࡯ࠩற"):Dj4rSONYXVbF8f9Hd0oWBp})
		if Pu43YtENBjiyp2KoFQWqHTw6XOlk in [YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠬ࠴࡭ࡱࡦࠪல"),ta478EuZQJIWhgBnsf6iU(u"࠭࠮࡮࠵ࡸ࠼ࠬள")]: tMpPCI8iJva0.setContentLookup(cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࡚ࡲࡶࡧ౩"))
		else: tMpPCI8iJva0.setContentLookup(ta478EuZQJIWhgBnsf6iU(u"ࡆࡢ࡮ࡶࡩ౪"))
		from m4OhBzk7o2 import ouxXRO0IqbTFQE5e6rD97
		if tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠧࡳࡶࡰࡴࠬழ") in pAeIhbuLSFw7j49qxtcg8dDrmKO:
			ouxXRO0IqbTFQE5e6rD97(qFRrj7ayBKbOsHGSXz(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫவ"),CIcPowhneWs5tN3(u"ࡇࡣ࡯ࡷࡪ౫"))
		elif Pu43YtENBjiyp2KoFQWqHTw6XOlk==YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠩ࠱ࡱࡵࡪࠧஶ") or dEUYJjrhsaPXNo(u"ࠪ࠳ࡩࡧࡳࡩ࠱ࠪஷ") in pAeIhbuLSFw7j49qxtcg8dDrmKO:
			ouxXRO0IqbTFQE5e6rD97(r6juULGQtnExAko38BZ5Y(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫஸ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࡈࡤࡰࡸ࡫౬"))
			tMpPCI8iJva0.setProperty(d6nQJfK4m5x9VLa,CIcPowhneWs5tN3(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬஹ"))
			tMpPCI8iJva0.setProperty(FeyZbj8tDil0nSHzTwfsUJ9(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠴࡭ࡢࡰ࡬ࡪࡪࡹࡴࡠࡶࡼࡴࡪ࠭஺"),dEUYJjrhsaPXNo(u"ࠧ࡮ࡲࡧࠫ஻"))
		if yPNzds8S6pE0mOjUHcZA4:
			tMpPCI8iJva0.setSubtitles([yPNzds8S6pE0mOjUHcZA4])
	if KVHOBcfFun==YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠨࡸ࡬ࡨࡪࡵࠧ஼") and GowEgKmITalyMQHbZkt==I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ஽"):
		PFlaYj0qTWHmCOI5cKtbvQ9wzD = FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠪࡴࡱࡧࡹࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪா")
		GowEgKmITalyMQHbZkt = tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠫࡕࡒࡁ࡚ࡡࡇࡐࡤࡌࡉࡍࡇࡖࠫி")
	elif KVHOBcfFun==cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠬࡼࡩࡥࡧࡲࠫீ") and vlntrPLopfSb.startswith(ItgK5FqGDz2Rf7mAJkbT(u"࠭࠶ࠨு")):
		PFlaYj0qTWHmCOI5cKtbvQ9wzD = FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩூ")
		GowEgKmITalyMQHbZkt = GowEgKmITalyMQHbZkt+FeyZbj8tDil0nSHzTwfsUJ9(u"ࠨࡡࡇࡐࠬ௃")
	if PFlaYj0qTWHmCOI5cKtbvQ9wzD!=CIcPowhneWs5tN3(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ௄"): bhzrQ2wcHVodXEvneLqsMm9WF()
	vph3Raz1kVZWmTUKG = JKpA9XiIHv7mVLEoNYFBTP()
	if vph3Raz1kVZWmTUKG.PFlaYj0qTWHmCOI5cKtbvQ9wzD: return S26SnaqcM9XwK8PVphJDv5(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ௅")
	vph3Raz1kVZWmTUKG.d7vaEmOX3C6N(GowEgKmITalyMQHbZkt)
	if KVHOBcfFun==NxsKJnLFEZ9OHXf1h(u"ࠫࡻ࡯ࡤࡦࡱࠪெ") and not vlntrPLopfSb.startswith(wx18CTJPZ5(u"ࠬ࠼ࠧே")):
		tMpPCI8iJva0.setPath(pAeIhbuLSFw7j49qxtcg8dDrmKO)
		y75wQavkVSLUb2MZf9qo(FeyZbj8tDil0nSHzTwfsUJ9(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ை"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+smpniPDOhfwI3H4v7c6TG(u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡳࡰࡦࡿࠠࡶࡵ࡬ࡲ࡬ࠦࡳࡦࡶࡕࡩࡸࡵ࡬ࡷࡧࡧ࡙ࡷࡲࠨࠪࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ௉")+pAeIhbuLSFw7j49qxtcg8dDrmKO+bbqAtUz36RPGVTvCkejpJXQB(u"ࠨࠢࡠࠫொ"))
		I9AOhSdTGW4rX1yPc3oKQHnkJEe.setResolvedUrl(KKtWUT6l8S,I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࡗࡶࡺ࡫౭"),tMpPCI8iJva0)
	elif KVHOBcfFun==zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠩ࡯࡭ࡻ࡫ࠧோ"):
		y75wQavkVSLUb2MZf9qo(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪௌ"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠫࠥࠦࠠࡍ࡫ࡹࡩࠥࡶ࡬ࡢࡻࠣࡹࡸ࡯࡮ࡨࠢࡳࡰࡦࡿࠨࠪࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤ்ࠬ")+pAeIhbuLSFw7j49qxtcg8dDrmKO+FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠬࠦ࡝ࠨ௎"))
		vph3Raz1kVZWmTUKG.play(pAeIhbuLSFw7j49qxtcg8dDrmKO,tMpPCI8iJva0)
	VZHWjJTrAPKG1eLEsxpYo2tS5 = cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࡊࡦࡲࡳࡦ౮")
	if PFlaYj0qTWHmCOI5cKtbvQ9wzD==CIcPowhneWs5tN3(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ௏"):
		from EA7YdxohlC import X7TlVUkLztKHwSpC
		VZHWjJTrAPKG1eLEsxpYo2tS5 = X7TlVUkLztKHwSpC(pAeIhbuLSFw7j49qxtcg8dDrmKO,Pu43YtENBjiyp2KoFQWqHTw6XOlk,GowEgKmITalyMQHbZkt)
		if VZHWjJTrAPKG1eLEsxpYo2tS5: bhzrQ2wcHVodXEvneLqsMm9WF()
	else:
		mze2PWBb1idXw9Z0Hh,PFlaYj0qTWHmCOI5cKtbvQ9wzD,hLFGeWOJY4SE,g5JxVZbdcKDmWiASOyFBIkH,zypQ85AcIxS3BO7VPfYZoiKsC4uq = Ox8k6IdtuPaG3NlApQK52oYwM(u"࠰ౕ"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࠧࡵࡴ࡬ࡩࡩ࠭ௐ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࡋࡧ࡬ࡴࡧ౯"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠳࠳࠴࠵౗"),GGCQK6OAtZUXRhvkgJm(u"࠴࠲࠳࠴࠵ౖ")
		if yyhDGOU25dw9XjIYZp: from zbUtu6IvKA import xa60ce2znAlyL5Z8ESXhO
		while mze2PWBb1idXw9Z0Hh<zypQ85AcIxS3BO7VPfYZoiKsC4uq:
			oos8ymFi9CN2z1jXcR.sleep(g5JxVZbdcKDmWiASOyFBIkH)
			mze2PWBb1idXw9Z0Hh += g5JxVZbdcKDmWiASOyFBIkH
			if vph3Raz1kVZWmTUKG.PFlaYj0qTWHmCOI5cKtbvQ9wzD==ItgK5FqGDz2Rf7mAJkbT(u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩ௑") and not hLFGeWOJY4SE:
				if yyhDGOU25dw9XjIYZp: xa60ce2znAlyL5Z8ESXhO(QmoEjB3hLIw(u"้ࠩะาࠦสี฼ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪ௒"),r6juULGQtnExAko38BZ5Y(u"ࠪࠫ௓"),w6vebiEZtpCjJcILP8Skx5rHn=NxsKJnLFEZ9OHXf1h(u"࠺࠹࠵ౘ"))
				y75wQavkVSLUb2MZf9qo(I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ௔"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+CgPbwXm1RilpJUSGHLhy(u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࠤ࡛࡯ࡤࡦࡱࠣࡷࡹࡧࡲࡵࡧࡧࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ௕")+pAeIhbuLSFw7j49qxtcg8dDrmKO+dEUYJjrhsaPXNo(u"࠭ࠠ࡞ࠩ௖")+pzqjL37rV1Z5g)
				hLFGeWOJY4SE = bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࡚ࡲࡶࡧ౰")
			elif vph3Raz1kVZWmTUKG.PFlaYj0qTWHmCOI5cKtbvQ9wzD in [MM564HfnUV0XIR(u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨௗ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠨࡶࡨࡷࡹ࡯࡮ࡨࠩ௘")]:
				y75wQavkVSLUb2MZf9qo(QmoEjB3hLIw(u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ௙"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+NNmirJKPp5nWjfC(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺࡙ࠡࠢ࡭ࡩ࡫࡯ࠡࡲ࡯ࡥࡾ࡯࡮ࡨࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ௚")+pAeIhbuLSFw7j49qxtcg8dDrmKO+QmoEjB3hLIw(u"ࠫࠥࡣࠧ௛")+pzqjL37rV1Z5g)
				break
			elif vph3Raz1kVZWmTUKG.PFlaYj0qTWHmCOI5cKtbvQ9wzD==wx18CTJPZ5(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ௜"):
				y75wQavkVSLUb2MZf9qo(cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ௝"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+dEUYJjrhsaPXNo(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡴࡱࡧࡹࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭௞")+pAeIhbuLSFw7j49qxtcg8dDrmKO+NNmirJKPp5nWjfC(u"ࠨࠢࡠࠫ௟")+pzqjL37rV1Z5g)
				if yyhDGOU25dw9XjIYZp: xa60ce2znAlyL5Z8ESXhO(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠩไุ้ࠦสี฼ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪ௠"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠪࠫ௡"),w6vebiEZtpCjJcILP8Skx5rHn=ta478EuZQJIWhgBnsf6iU(u"࠵࠷࠻࠰ౙ"))
				break
			elif vph3Raz1kVZWmTUKG.PFlaYj0qTWHmCOI5cKtbvQ9wzD==bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬ௢"):
				y75wQavkVSLUb2MZf9qo(Gk98CL5nXZEN(u"ࠬࡋࡒࡓࡑࡕࠫ௣"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠭ࠠࠡࠢࡇࡩࡻ࡯ࡣࡦࠢ࡬ࡷࠥࡨ࡬ࡰࡥ࡮ࡩࡩࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ௤")+pAeIhbuLSFw7j49qxtcg8dDrmKO+wx18CTJPZ5(u"ࠧࠡ࡟ࠪ௥"))
				break
		else:
			if yyhDGOU25dw9XjIYZp: xa60ce2znAlyL5Z8ESXhO(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠨใื่ࠥะิ฻์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩ௦"),QmoEjB3hLIw(u"ࠩࠪ௧"),w6vebiEZtpCjJcILP8Skx5rHn=CgPbwXm1RilpJUSGHLhy(u"࠶࠸࠵࠱ౚ"))
			y75wQavkVSLUb2MZf9qo(CgPbwXm1RilpJUSGHLhy(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ௨"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+Gk98CL5nXZEN(u"ࠫࠥࠦࠠࡕ࡫ࡰࡩࡴࡻࡴ࠻࡙ࠢࠣࡳࡱ࡮ࡰࡹࡱࠤࡵࡸ࡯ࡣ࡮ࡨࡱࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ௩")+pAeIhbuLSFw7j49qxtcg8dDrmKO+qFRrj7ayBKbOsHGSXz(u"ࠬࠦ࡝ࠨ௪")+pzqjL37rV1Z5g)
			PFlaYj0qTWHmCOI5cKtbvQ9wzD = YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ௫")
	if PFlaYj0qTWHmCOI5cKtbvQ9wzD in [I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠧࡱ࡮ࡤࡽࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ௬")] or vph3Raz1kVZWmTUKG.PFlaYj0qTWHmCOI5cKtbvQ9wzD in [NNmirJKPp5nWjfC(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ௭"),CgPbwXm1RilpJUSGHLhy(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪ௮")] or VZHWjJTrAPKG1eLEsxpYo2tS5:
		if vph3Raz1kVZWmTUKG.PFlaYj0qTWHmCOI5cKtbvQ9wzD==Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫ௯"): GowEgKmITalyMQHbZkt = GowEgKmITalyMQHbZkt+EAw9bg4rT3Bd8tjSkO(u"ࠫࡤ࡚ࡓࠨ௰")
		Il5iAWS8vkNBe4Xf = YQqPDl7UoC53sKbO(GowEgKmITalyMQHbZkt)
	else: exec(wx18CTJPZ5(u"ࠬ࡯࡭ࡱࡱࡵࡸࠥࡾࡢ࡮ࡥ࠾ࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱ࡷࡹࡵࡰࠩࠫࠪ௱"))
	return vph3Raz1kVZWmTUKG.PFlaYj0qTWHmCOI5cKtbvQ9wzD
def SU82u7LfcMslH3e0Bzihn6x(pAeIhbuLSFw7j49qxtcg8dDrmKO):
	Pu43YtENBjiyp2KoFQWqHTw6XOlk = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(GGCQK6OAtZUXRhvkgJm(u"࠭ࠨ࡝࠰ࡤࡺ࡮ࢂ࡜࠯ࡶࡶࢀࡡ࠴ࡡࡢࡥࡿࡠ࠳ࡳࡰ࠵ࡾ࡟࠲ࡲ࠹ࡵࡽ࡞࠱ࡱ࠸ࡻ࠸ࡽ࡞࠱ࡱࡵࡪࡼ࡝࠰ࡰ࡯ࡻࢂ࡜࠯ࡨ࡯ࡺࢁࡢ࠮࡮ࡲ࠶ࢀࡡ࠴ࡷࡦࡤࡰ࠭࠭ࢂ࡜ࡀ࠰࠭ࡃࢁ࠵࡜ࡀ࠰࠭ࡃࢁࡢࡼ࠯ࠬࡂ࠭ࠩ࠭௲"),pAeIhbuLSFw7j49qxtcg8dDrmKO.lower(),E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.IGNORECASE)
	Pu43YtENBjiyp2KoFQWqHTw6XOlk = Pu43YtENBjiyp2KoFQWqHTw6XOlk[SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠶౛")][SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠶౛")] if Pu43YtENBjiyp2KoFQWqHTw6XOlk else wx18CTJPZ5(u"ࠧࠨ௳")
	return Pu43YtENBjiyp2KoFQWqHTw6XOlk
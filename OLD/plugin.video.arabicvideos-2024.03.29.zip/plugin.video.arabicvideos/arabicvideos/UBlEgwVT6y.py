# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'SHAHID4U'
headers = ''
Yc0eBRLpbCkm4gK7OqyzuHwU = '_SH4_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
ZLKHfqMEUdRupD = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def HgQCVwFx2Br(mode,url,text):
	if   mode==110: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==111: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url,text)
	elif mode==112: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==113: s4Bng5iAZQSTtpDw9 = btd6ag2XYUkHixqy5J7o9RfLu1MScm(url,True)
	elif mode==114: s4Bng5iAZQSTtpDw9 = L1FsQxw6Afb7pcCe9Tr3qizXZ(url,'FULL_FILTER___'+text)
	elif mode==115: s4Bng5iAZQSTtpDw9 = L1FsQxw6Afb7pcCe9Tr3qizXZ(url,'DEFINED_FILTER___'+text)
	elif mode==116: s4Bng5iAZQSTtpDw9 = btd6ag2XYUkHixqy5J7o9RfLu1MScm(url,False)
	elif mode==119: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	dkgwyUKEpTtPeMxs68aib,url,aQniqUlZk8 = n4shroLZX1NF5yAzVqtJWGk(MMLimtJ8xTFAq9Z012nroaju3de,'GET',tle5V6jgvRfE,'shahid4u','شاهد فوريو - Shahid 4u','facebook.com/shahid4u.net',headers)
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',119,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فلتر محدد',dkgwyUKEpTtPeMxs68aib,115)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فلتر كامل',dkgwyUKEpTtPeMxs68aib,114)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'المميزة',dkgwyUKEpTtPeMxs68aib,111,'','','featured')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('simple-filter(.*?)adv-filter',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not TIkiozSLCv6werb97mHQ0q4y3:
		tehb3k5a2PufGOdBIUw8j('','','موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for filter,Q2qmuDRrC9ikcaJK7gtUHXNW,title in items:
			url = dkgwyUKEpTtPeMxs68aib+filter
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,111,Q2qmuDRrC9ikcaJK7gtUHXNW,'',filter)
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="dropdown"(.*?)<script>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			title = title.replace('\n','').replace('\r','').strip(' ')
			if title in ZLKHfqMEUdRupD: continue
			if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = dkgwyUKEpTtPeMxs68aib+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			if 'netflix' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: title = 'نيتفلكس'
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,111)
	return M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
def uyt3pAHZk4(url,S7Ra6OGtw1gBkDhrPsozc5Ku='',aQniqUlZk8=''):
	if not aQniqUlZk8: aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'',headers,'','','SHAHID4U-TITLES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3,items,jjR8ftoEXpPxVF6JerbHZuzv7ic = [],[],[]
	if S7Ra6OGtw1gBkDhrPsozc5Ku=='featured': TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('glide__slides(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	else: TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('shows-container(.*?)pagination',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not TIkiozSLCv6werb97mHQ0q4y3: return
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	if not items: items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)</h4>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	G1ezKuLr3SlXd9OVkMNQs6FWvf8Aip = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title in items:
		if 'javascript' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: continue
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = BUTSkzgFC7(ZCimQhV5lovgspAYzHq1Ef27u8ja4R).strip('/')
		title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
		title = title.strip(' ')
		EQw62xjXSJmzrRt = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(.*?) الحلقة \d+',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if '/film/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R or 'فيلم' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R or any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title for hht0cpXxWw2OzFS1jnUGebkJLBd85 in G1ezKuLr3SlXd9OVkMNQs6FWvf8Aip):
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,112,Q2qmuDRrC9ikcaJK7gtUHXNW)
		elif EQw62xjXSJmzrRt and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + EQw62xjXSJmzrRt[0]
			if title not in jjR8ftoEXpPxVF6JerbHZuzv7ic:
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,113,Q2qmuDRrC9ikcaJK7gtUHXNW)
				jjR8ftoEXpPxVF6JerbHZuzv7ic.append(title)
		elif '/actor/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,111,Q2qmuDRrC9ikcaJK7gtUHXNW)
		elif '/series/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R and '/list' not in url:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'/list'
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,111,Q2qmuDRrC9ikcaJK7gtUHXNW)
		elif '/list' in url and 'حلقة' in title:
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,112,Q2qmuDRrC9ikcaJK7gtUHXNW)
		else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,113,Q2qmuDRrC9ikcaJK7gtUHXNW)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"pagination"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		if S7Ra6OGtw1gBkDhrPsozc5Ku!='search': items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(updateQuery).*?>(.+?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		else: items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<li>.*?href="(.*?)">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			if S7Ra6OGtw1gBkDhrPsozc5Ku!='search':
				title = title.replace('\n','').replace('\r','')
				if '?' in url: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = url+'&page='+title
				else: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = url+'?page='+title
			title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
			if title: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,111,'','',S7Ra6OGtw1gBkDhrPsozc5Ku)
	return
def btd6ag2XYUkHixqy5J7o9RfLu1MScm(url,Ex9NvJOAT7qpbZRV0SUKnerWi):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'',headers,'','','SHAHID4U-EPISODES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('items d-flex(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if len(TIkiozSLCv6werb97mHQ0q4y3)>1:
		if '/season/' in TIkiozSLCv6werb97mHQ0q4y3[0]: jnfvCpH4PRD3r2BNsc96TAdQoeZ,MRLuZmE4OvnzohQa73cTGWNr = TIkiozSLCv6werb97mHQ0q4y3[0],TIkiozSLCv6werb97mHQ0q4y3[1]
		else: jnfvCpH4PRD3r2BNsc96TAdQoeZ,MRLuZmE4OvnzohQa73cTGWNr = TIkiozSLCv6werb97mHQ0q4y3[1],TIkiozSLCv6werb97mHQ0q4y3[0]
	else: jnfvCpH4PRD3r2BNsc96TAdQoeZ,MRLuZmE4OvnzohQa73cTGWNr = TIkiozSLCv6werb97mHQ0q4y3[0],TIkiozSLCv6werb97mHQ0q4y3[0]
	for Deiz7ocWQjVnIg in range(2):
		if Ex9NvJOAT7qpbZRV0SUKnerWi: mode,type,ziJLDVT8NM2QcgIpmE9A = 116,'folder',jnfvCpH4PRD3r2BNsc96TAdQoeZ
		else: mode,type,ziJLDVT8NM2QcgIpmE9A = 112,'video',MRLuZmE4OvnzohQa73cTGWNr
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if Ex9NvJOAT7qpbZRV0SUKnerWi and len(items)<2:
			Ex9NvJOAT7qpbZRV0SUKnerWi = False
			continue
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,RwcFvrfJ2ANZSizC6bqKeEo1UDdIQ,neZQycYAFqxLzkPhEWvM in items:
			title = RwcFvrfJ2ANZSizC6bqKeEo1UDdIQ+' '+neZQycYAFqxLzkPhEWvM
			tBq8fTGUWJY9zvbgXD0EAloPO(type,Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,mode)
		break
	if not items and '/episodes' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2:
		X2log1R5aufxyPQJTCwGq8Wb = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="breadcrumb"(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if X2log1R5aufxyPQJTCwGq8Wb:
			ziJLDVT8NM2QcgIpmE9A = X2log1R5aufxyPQJTCwGq8Wb[0]
			cc0O1M4e5jtfoq = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if len(cc0O1M4e5jtfoq)>2:
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = cc0O1M4e5jtfoq[2]+'list'
				uyt3pAHZk4(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	return
def dlropqS0vO9K7W4z(url):
	jVMHRouKgQFAESmd7B8ObTYy = []
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',url,'',headers,'','','SHAHID4U-PLAY-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="actions(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not TIkiozSLCv6werb97mHQ0q4y3: return
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	cc0O1M4e5jtfoq = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	sWLt8znODYPrUaxF = '/watch/' in ziJLDVT8NM2QcgIpmE9A
	download = '/download/' in ziJLDVT8NM2QcgIpmE9A
	if   sWLt8znODYPrUaxF and not download: fouBJxOCLgzpa,NeOGdMyISBEmiLlW8Kspg = cc0O1M4e5jtfoq[0],''
	elif not sWLt8znODYPrUaxF and download: fouBJxOCLgzpa,NeOGdMyISBEmiLlW8Kspg = '',cc0O1M4e5jtfoq[0]
	elif sWLt8znODYPrUaxF and download: fouBJxOCLgzpa,NeOGdMyISBEmiLlW8Kspg = cc0O1M4e5jtfoq[0],cc0O1M4e5jtfoq[1]
	else: fouBJxOCLgzpa,NeOGdMyISBEmiLlW8Kspg = '',''
	if sWLt8znODYPrUaxF:
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',fouBJxOCLgzpa,'',headers,'','','SHAHID4U-PLAY-2nd')
		flARjI3NM9CQnWY1xk7 = aQniqUlZk8.content
		rNQC9lGIxW3d0oB6AjUfD5LbRF = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('let servers(.*?)player',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL|E1E4YjPysoQMVdlu39mSTcWKFkpa7v.IGNORECASE)
		if rNQC9lGIxW3d0oB6AjUfD5LbRF:
			f9AzGuXj0qgcNTy1 = rNQC9lGIxW3d0oB6AjUfD5LbRF[0]
			HKE5ebjfkuy = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"name":"(.*?)".*?"url":"(.*?)"',f9AzGuXj0qgcNTy1,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R in HKE5ebjfkuy:
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.replace('\\/','/')
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+title+'__watch'
				jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	if download:
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',NeOGdMyISBEmiLlW8Kspg,'',headers,'','','SHAHID4U-PLAY-3rd')
		flARjI3NM9CQnWY1xk7 = aQniqUlZk8.content
		rNQC9lGIxW3d0oB6AjUfD5LbRF = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"servers"(.*?)info-container',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if rNQC9lGIxW3d0oB6AjUfD5LbRF:
			f9AzGuXj0qgcNTy1 = rNQC9lGIxW3d0oB6AjUfD5LbRF[0]
			HKE5ebjfkuy = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',f9AzGuXj0qgcNTy1,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,LjG8y1rb9AgJF2I3i64ZDtCXMa7n in HKE5ebjfkuy:
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+title+'__download'+'____'+LjG8y1rb9AgJF2I3i64ZDtCXMa7n
				jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	import JYR902sfml
	JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt(jVMHRouKgQFAESmd7B8ObTYy,r1NChsk39OMvT82YemDQnl5,'video',url)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if not search:
		search = UIf35nZEj1wylmq()
		if not search: return
	search = search.replace(' ','+')
	url = tle5V6jgvRfE+'/search?s='+search
	dkgwyUKEpTtPeMxs68aib,M08MPGgsh4n5rKe,WcPEG7nehsCwig809NyHMZ = n4shroLZX1NF5yAzVqtJWGk(MMLimtJ8xTFAq9Z012nroaju3de,'GET',url,'shahid4u','شاهد فوريو - Shahid 4u','facebook.com/shahid4u.net',headers)
	uyt3pAHZk4(M08MPGgsh4n5rKe,'search',WcPEG7nehsCwig809NyHMZ)
	return
def UdqXh8aClcxJAEVSFKy9PnjuGW(url):
	url = url.split('/smartemadfilter?')[0]
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',url,'',headers,'','','SHAHID4U-GET_FILTERS_BLOCKS-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	H8n4oVq07uvJjCOwgzbyf6XR9Fs = []
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('adv-filter(.*?)shows-container',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		H8n4oVq07uvJjCOwgzbyf6XR9Fs = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('''updateQuery\('(.*?)'.*?value>(.*?)<(.*?)</select''',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		n1JT0Ec8K2,If9vObmXl3iaWRxVjnQ4P,cz4e6sNTj53E09xtaArJLKDg = zip(*H8n4oVq07uvJjCOwgzbyf6XR9Fs)
		H8n4oVq07uvJjCOwgzbyf6XR9Fs = zip(If9vObmXl3iaWRxVjnQ4P,n1JT0Ec8K2,cz4e6sNTj53E09xtaArJLKDg)
	return H8n4oVq07uvJjCOwgzbyf6XR9Fs
def HOgJ4cadx6GAE(ziJLDVT8NM2QcgIpmE9A):
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('value="(.*?)".*?>\s*(.*?)\s*<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	return items
def ugZB7sRewr9hnTFHkiAND4vp6jSyf(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	bBac0ZnqRLiYT6x93vJyFjQ = url.split('/smartemadfilter?')[0]
	kFlE9TNexjg76 = SLMTm6RQ34ic7v5s9rBG(url,'url')
	url = url.replace(bBac0ZnqRLiYT6x93vJyFjQ,kFlE9TNexjg76)
	url = url.replace('/smartemadfilter?','/?')
	return url
MvZk1lBHtq45 = ['quality','year','genre','category']
LJpvBwZAWD2cntfuUrexGzQ0goN = ['category','genre','year']
def L1FsQxw6Afb7pcCe9Tr3qizXZ(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': ydL2RstfT9BA3Hpe1SZIq,l3Uo4ThenPyJMua = '',''
	else: ydL2RstfT9BA3Hpe1SZIq,l3Uo4ThenPyJMua = filter.split('___')
	if type=='DEFINED_FILTER':
		if LJpvBwZAWD2cntfuUrexGzQ0goN[0]+'=' not in ydL2RstfT9BA3Hpe1SZIq: cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = LJpvBwZAWD2cntfuUrexGzQ0goN[0]
		for AudBQkLFsrHKicIogThZyv in range(len(LJpvBwZAWD2cntfuUrexGzQ0goN[0:-1])):
			if LJpvBwZAWD2cntfuUrexGzQ0goN[AudBQkLFsrHKicIogThZyv]+'=' in ydL2RstfT9BA3Hpe1SZIq: cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = LJpvBwZAWD2cntfuUrexGzQ0goN[AudBQkLFsrHKicIogThZyv+1]
		rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&'+cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo+'=0'
		SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&'+cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo+'=0'
		hOSk91jGqtHsfwU2ExCV4YB = rrsgSnC5AFkbEvDPm6pyaRizM8.strip('&')+'___'+SWxX6Q3CgwV7F.strip('&')
		Rdgr0aTSzE5chex9W = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(l3Uo4ThenPyJMua,'modified_filters')
		M08MPGgsh4n5rKe = url+'/smartemadfilter?'+Rdgr0aTSzE5chex9W
	elif type=='FULL_FILTER':
		jyRzHeOYXAW4oDrUS = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(ydL2RstfT9BA3Hpe1SZIq,'modified_values')
		jyRzHeOYXAW4oDrUS = BUTSkzgFC7(jyRzHeOYXAW4oDrUS)
		if l3Uo4ThenPyJMua!='': l3Uo4ThenPyJMua = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(l3Uo4ThenPyJMua,'modified_filters')
		if l3Uo4ThenPyJMua=='': M08MPGgsh4n5rKe = url
		else: M08MPGgsh4n5rKe = url+'/smartemadfilter?'+l3Uo4ThenPyJMua
		TW6JIBgC971tjOE = ugZB7sRewr9hnTFHkiAND4vp6jSyf(M08MPGgsh4n5rKe)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'أظهار قائمة الفيديو التي تم اختيارها ',TW6JIBgC971tjOE,111)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+' [[   '+jyRzHeOYXAW4oDrUS+'   ]]',TW6JIBgC971tjOE,111)
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	H8n4oVq07uvJjCOwgzbyf6XR9Fs = UdqXh8aClcxJAEVSFKy9PnjuGW(url)
	dict = {}
	for name,eFmOUji0173K,ziJLDVT8NM2QcgIpmE9A in H8n4oVq07uvJjCOwgzbyf6XR9Fs:
		name = name.replace('كل ','')
		items = HOgJ4cadx6GAE(ziJLDVT8NM2QcgIpmE9A)
		if '=' not in M08MPGgsh4n5rKe: M08MPGgsh4n5rKe = url
		if type=='DEFINED_FILTER':
			if cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo!=eFmOUji0173K: continue
			elif len(items)<2:
				if eFmOUji0173K==LJpvBwZAWD2cntfuUrexGzQ0goN[-1]:
					TW6JIBgC971tjOE = ugZB7sRewr9hnTFHkiAND4vp6jSyf(M08MPGgsh4n5rKe)
					uyt3pAHZk4(TW6JIBgC971tjOE)
				else: L1FsQxw6Afb7pcCe9Tr3qizXZ(M08MPGgsh4n5rKe,'DEFINED_FILTER___'+hOSk91jGqtHsfwU2ExCV4YB)
				return
			else:
				if eFmOUji0173K==LJpvBwZAWD2cntfuUrexGzQ0goN[-1]:
					TW6JIBgC971tjOE = ugZB7sRewr9hnTFHkiAND4vp6jSyf(M08MPGgsh4n5rKe)
					tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع',TW6JIBgC971tjOE,111)
				else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع',M08MPGgsh4n5rKe,115,'','',hOSk91jGqtHsfwU2ExCV4YB)
		elif type=='FULL_FILTER':
			rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&'+eFmOUji0173K+'=0'
			SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&'+eFmOUji0173K+'=0'
			hOSk91jGqtHsfwU2ExCV4YB = rrsgSnC5AFkbEvDPm6pyaRizM8+'___'+SWxX6Q3CgwV7F
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع :'+name,M08MPGgsh4n5rKe,114,'','',hOSk91jGqtHsfwU2ExCV4YB)
		dict[eFmOUji0173K] = {}
		for hht0cpXxWw2OzFS1jnUGebkJLBd85,e0i4nPhusqdTaG in items:
			if hht0cpXxWw2OzFS1jnUGebkJLBd85=='196533': e0i4nPhusqdTaG = 'أفلام نيتفلكس'
			elif hht0cpXxWw2OzFS1jnUGebkJLBd85=='196531': e0i4nPhusqdTaG = 'مسلسلات نيتفلكس'
			if e0i4nPhusqdTaG in ZLKHfqMEUdRupD: continue
			dict[eFmOUji0173K][hht0cpXxWw2OzFS1jnUGebkJLBd85] = e0i4nPhusqdTaG
			rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&'+eFmOUji0173K+'='+e0i4nPhusqdTaG
			SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&'+eFmOUji0173K+'='+hht0cpXxWw2OzFS1jnUGebkJLBd85
			RtPpz8FAEjIxU = rrsgSnC5AFkbEvDPm6pyaRizM8+'___'+SWxX6Q3CgwV7F
			title = e0i4nPhusqdTaG+' :'#+dict[eFmOUji0173K]['0']
			title = e0i4nPhusqdTaG+' :'+name
			if type=='FULL_FILTER': tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,114,'','',RtPpz8FAEjIxU)
			elif type=='DEFINED_FILTER' and LJpvBwZAWD2cntfuUrexGzQ0goN[-2]+'=' in ydL2RstfT9BA3Hpe1SZIq:
				Rdgr0aTSzE5chex9W = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(SWxX6Q3CgwV7F,'modified_filters')
				M08MPGgsh4n5rKe = url+'/smartemadfilter?'+Rdgr0aTSzE5chex9W
				TW6JIBgC971tjOE = ugZB7sRewr9hnTFHkiAND4vp6jSyf(M08MPGgsh4n5rKe)
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,TW6JIBgC971tjOE,111)
			else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,115,'','',RtPpz8FAEjIxU)
	return
def l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(dY1a0xA6PKm7TOJSERt3sHU9Qp,mode):
	dY1a0xA6PKm7TOJSERt3sHU9Qp = dY1a0xA6PKm7TOJSERt3sHU9Qp.replace('=&','=0&')
	dY1a0xA6PKm7TOJSERt3sHU9Qp = dY1a0xA6PKm7TOJSERt3sHU9Qp.strip('&')
	nvNkgT7iGQOyed = {}
	if '=' in dY1a0xA6PKm7TOJSERt3sHU9Qp:
		items = dY1a0xA6PKm7TOJSERt3sHU9Qp.split('&')
		for hh4gUqS5JWf1saRZPXHD in items:
			DHcrLNnqExKjM8uvVlBhWd,hht0cpXxWw2OzFS1jnUGebkJLBd85 = hh4gUqS5JWf1saRZPXHD.split('=')
			nvNkgT7iGQOyed[DHcrLNnqExKjM8uvVlBhWd] = hht0cpXxWw2OzFS1jnUGebkJLBd85
	UJzegYmlGML35rasDAIx17Rhnk = ''
	for key in MvZk1lBHtq45:
		if key in list(nvNkgT7iGQOyed.keys()): hht0cpXxWw2OzFS1jnUGebkJLBd85 = nvNkgT7iGQOyed[key]
		else: hht0cpXxWw2OzFS1jnUGebkJLBd85 = '0'
		if '%' not in hht0cpXxWw2OzFS1jnUGebkJLBd85: hht0cpXxWw2OzFS1jnUGebkJLBd85 = TaEr2nR3f5e8oXzpy(hht0cpXxWw2OzFS1jnUGebkJLBd85)
		if mode=='modified_values' and hht0cpXxWw2OzFS1jnUGebkJLBd85!='0': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+' + '+hht0cpXxWw2OzFS1jnUGebkJLBd85
		elif mode=='modified_filters' and hht0cpXxWw2OzFS1jnUGebkJLBd85!='0': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+'&'+key+'='+hht0cpXxWw2OzFS1jnUGebkJLBd85
		elif mode=='all': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+'&'+key+'='+hht0cpXxWw2OzFS1jnUGebkJLBd85
	UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk.strip(' + ')
	UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk.strip('&')
	UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk.replace('=0','=')
	return UJzegYmlGML35rasDAIx17Rhnk
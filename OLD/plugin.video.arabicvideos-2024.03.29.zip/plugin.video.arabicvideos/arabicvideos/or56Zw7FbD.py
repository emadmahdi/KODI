# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'FASELHD2'
headers = {'User-Agent':''}
Yc0eBRLpbCkm4gK7OqyzuHwU = '_FH2_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
ZLKHfqMEUdRupD = ['wwe']
def HgQCVwFx2Br(mode,url,text):
	if   mode==590: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==591: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url,text)
	elif mode==592: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==593: s4Bng5iAZQSTtpDw9 = q68qDOIufmz7LCRdaBNFiW(url,text)
	elif mode==599: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	dkgwyUKEpTtPeMxs68aib = tle5V6jgvRfE
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',dkgwyUKEpTtPeMxs68aib,'','','','','FASELHD2-MENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع',dkgwyUKEpTtPeMxs68aib,599,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'المميزة',dkgwyUKEpTtPeMxs68aib,591,'','','featured1')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<strong>(.*?)</strong>.*?href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,591,'','','details1')
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('main-menu"(.*?)header-social',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		Abf1DcCavklrtUXiN70wTeoSWYK = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<li (.*?)</li>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for BYK4n5WxXhCpQ7N in Abf1DcCavklrtUXiN70wTeoSWYK:
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?>(.*?)<',BYK4n5WxXhCpQ7N,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
				if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = dkgwyUKEpTtPeMxs68aib+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,591,'','','details2')
	return M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
def uyt3pAHZk4(url,type=''):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','FASELHD2-TITLES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	LtAZORhVFombwvTG1fd = 0
	rNQC9lGIxW3d0oB6AjUfD5LbRF = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"archive-slider(.*?)<h4>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if rNQC9lGIxW3d0oB6AjUfD5LbRF: f9AzGuXj0qgcNTy1 = rNQC9lGIxW3d0oB6AjUfD5LbRF[0]
	else: f9AzGuXj0qgcNTy1 = ''
	if type=='featured1':
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"slider-carousel"(.*?)</container>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(' src="(.*?)".*?"slider-title">(.*?)<.*?<a href="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		PojQU9ySuCMbW,GReTJrIxo2dzbapy,cc0O1M4e5jtfoq = zip(*items)
		items = zip(cc0O1M4e5jtfoq,PojQU9ySuCMbW,GReTJrIxo2dzbapy)
	elif type=='featured2':
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',f9AzGuXj0qgcNTy1,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	elif type=='filters':
		TIkiozSLCv6werb97mHQ0q4y3 = [M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2.replace('\\/','/').replace('\\"','"')]
	elif type=='details2' and 'href' in f9AzGuXj0qgcNTy1:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<h4>(.*?)</h4>(.*?)</container>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مميزة',url,591,'','','featured2')
		title = TIkiozSLCv6werb97mHQ0q4y3[0][0]
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,591,'','','details3')
		return
	else:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<h4>(.*?)</h4>(.*?)</container>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		title,ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	G1ezKuLr3SlXd9OVkMNQs6FWvf8Aip = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	jjR8ftoEXpPxVF6JerbHZuzv7ic = []
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title in items:
		if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title.lower() for hht0cpXxWw2OzFS1jnUGebkJLBd85 in ZLKHfqMEUdRupD): continue
		title = title.strip(' ')
		title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
		EQw62xjXSJmzrRt = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(.*?) (الحلقة|حلقة).\d+',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if '/movseries/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,591,Q2qmuDRrC9ikcaJK7gtUHXNW)
		elif EQw62xjXSJmzrRt and type=='':
			title = '_MOD_'+EQw62xjXSJmzrRt[0][0]
			if title not in jjR8ftoEXpPxVF6JerbHZuzv7ic:
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,593,Q2qmuDRrC9ikcaJK7gtUHXNW)
				jjR8ftoEXpPxVF6JerbHZuzv7ic.append(title)
		elif any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title for hht0cpXxWw2OzFS1jnUGebkJLBd85 in G1ezKuLr3SlXd9OVkMNQs6FWvf8Aip):
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,592,Q2qmuDRrC9ikcaJK7gtUHXNW)
		else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,593,Q2qmuDRrC9ikcaJK7gtUHXNW)
	if type=='filters':
		SSgRAKD3NBqJ97ojTnL5kpFafHdU = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"more_button_page":(.*?),',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if SSgRAKD3NBqJ97ojTnL5kpFafHdU:
			count = SSgRAKD3NBqJ97ojTnL5kpFafHdU[0]
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = url+'/offset/'+count
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة أخرى',ZCimQhV5lovgspAYzHq1Ef27u8ja4R,591,'','','filters')
	elif 'details' in type:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="pagination(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3:
			ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
				title = 'صفحة '+nnGHa80rMphqe1ukFtIRvAPs6W(title)
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,591,'','','details4')
	return
def q68qDOIufmz7LCRdaBNFiW(url,type=''):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','FASELHD2-SEASONS_EPISODES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	jnfvCpH4PRD3r2BNsc96TAdQoeZ = False
	if not type:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<seasons(.*?)</seasons>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3:
			ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3>(.*?)</h3>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if len(items)>1:
				dkgwyUKEpTtPeMxs68aib = SLMTm6RQ34ic7v5s9rBG(url,'url')
				jnfvCpH4PRD3r2BNsc96TAdQoeZ = True
				for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title in items:
					title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
					tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,593,Q2qmuDRrC9ikcaJK7gtUHXNW,'','episodes')
	if type=='episodes' or not jnfvCpH4PRD3r2BNsc96TAdQoeZ:
		OHMhVx5cw76slynUDdF24jgbkNG = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<bkز*?image:url\((.*?)\)"></bk>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if OHMhVx5cw76slynUDdF24jgbkNG: Q2qmuDRrC9ikcaJK7gtUHXNW = OHMhVx5cw76slynUDdF24jgbkNG[0]
		else: Q2qmuDRrC9ikcaJK7gtUHXNW = ''
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<all-episodes(.*?)</all-episodes>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3:
			ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?>(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
				title = title.strip(' ')
				title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
				tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,592,Q2qmuDRrC9ikcaJK7gtUHXNW)
	return
def dlropqS0vO9K7W4z(url):
	zcBjFq4VQlp20ZekGO,zQKxjEJWXoUw,fnB1sGSRlHaeu = [],[],[]
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',url,'','','','','FASELHD2-PLAY-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	dHeVQ1fBl7Zih2 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('العمر :.*?<strong">(.*?)</strong>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if dHeVQ1fBl7Zih2 and Y1Yz6bZMLDaGjpxK3fSXm7TurCnHwo(r1NChsk39OMvT82YemDQnl5,url,dHeVQ1fBl7Zih2): return
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<iframe src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]
		zcBjFq4VQlp20ZekGO.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named=__embed')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<slice-title(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-url="(.*?)".*?</i>(.*?)</li>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,name in items:
			name = name.strip(' ')
			zcBjFq4VQlp20ZekGO.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+name+'__watch')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<downloads(.*?)</downloads>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?</div>(.*?)</div>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,name in items:
			zcBjFq4VQlp20ZekGO.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+name+'__download')
	for P8XCKZhtcNqS in zcBjFq4VQlp20ZekGO:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R,name = P8XCKZhtcNqS.split('?named')
		if ZCimQhV5lovgspAYzHq1Ef27u8ja4R not in zQKxjEJWXoUw:
			zQKxjEJWXoUw.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			fnB1sGSRlHaeu.append(P8XCKZhtcNqS)
	import JYR902sfml
	JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt(fnB1sGSRlHaeu,r1NChsk39OMvT82YemDQnl5,'video',url)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if search=='': search = UIf35nZEj1wylmq()
	if search=='': return
	search = search.replace(' ','+')
	dkgwyUKEpTtPeMxs68aib = tle5V6jgvRfE
	url = dkgwyUKEpTtPeMxs68aib+'/?s='+search
	uyt3pAHZk4(url,'details5')
	return
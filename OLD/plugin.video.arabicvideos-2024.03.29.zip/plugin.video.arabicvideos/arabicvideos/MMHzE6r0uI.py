# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'GLOBALSEARCH'
Yc0eBRLpbCkm4gK7OqyzuHwU = '_GLS_'
def HgQCVwFx2Br(n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,d7on6sKDqkNY,RxgdTHfDar8EXt,tsMKaFVh1ZN2BIXEcvTejxR5DP):
	if   n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==540: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==541: s4Bng5iAZQSTtpDw9 = izRGM4knqdx0bLJjI6UvyPQuZ(RxgdTHfDar8EXt)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==542: s4Bng5iAZQSTtpDw9 = XubEYBDZoGm2qIc(RxgdTHfDar8EXt,d7on6sKDqkNY,tsMKaFVh1ZN2BIXEcvTejxR5DP)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==549: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(RxgdTHfDar8EXt)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','بحث جديد','',549)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008]==== كلمات مخزنة ====[/COLOR]','',9999)
	Psp3YgUkNzh = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,'dict','GLOBALSEARCH_SITES')
	if Psp3YgUkNzh:
		Psp3YgUkNzh = Psp3YgUkNzh['__SEQUENCED_COLUMNS__']
		for v4krFwHQLNUB in reversed(Psp3YgUkNzh):
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',v4krFwHQLNUB,'',549,'','',v4krFwHQLNUB)
	return
def Xwa7vgzTeb3Zy(v4krFwHQLNUB):
	if not v4krFwHQLNUB:
		v4krFwHQLNUB = UIf35nZEj1wylmq()
		if not v4krFwHQLNUB: return
		v4krFwHQLNUB = v4krFwHQLNUB.lower()
	wXW0Y9otuC6PQzpnF2GT = v4krFwHQLNUB.replace(Yc0eBRLpbCkm4gK7OqyzuHwU,'')
	ZIilJc4ND8xHPOn(wXW0Y9otuC6PQzpnF2GT)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','عمل بحث جماعي - '+wXW0Y9otuC6PQzpnF2GT,'search_sites',542,'','',wXW0Y9otuC6PQzpnF2GT)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','نتائج البحث مفصلة - '+wXW0Y9otuC6PQzpnF2GT,'opened_sites',542,'','',wXW0Y9otuC6PQzpnF2GT)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','نتائج البحث مقسمة - '+wXW0Y9otuC6PQzpnF2GT,'listed_sites',542,'','',wXW0Y9otuC6PQzpnF2GT)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','بحث منفرد - '+wXW0Y9otuC6PQzpnF2GT,'',541,'','',wXW0Y9otuC6PQzpnF2GT)
	return
def ZIilJc4ND8xHPOn(hhNnomHYgPcVS):
	gDapyf8eHhCM0EV4xvUPWbIrjzdwZX = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,'list','GLOBALSEARCH_SITES',hhNnomHYgPcVS)
	jGR73qbwzDQVua9yWdg = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,'list','GLOBALSEARCH_SITES',Yc0eBRLpbCkm4gK7OqyzuHwU+hhNnomHYgPcVS)
	QQvOnYi9sJMwp7dIxeck8DRASWuBt(WSgQvHLx9uOKTksaCt2JchldRj,'GLOBALSEARCH_SITES',hhNnomHYgPcVS)
	QQvOnYi9sJMwp7dIxeck8DRASWuBt(WSgQvHLx9uOKTksaCt2JchldRj,'GLOBALSEARCH_SITES',Yc0eBRLpbCkm4gK7OqyzuHwU+hhNnomHYgPcVS)
	BeqAwyTaQl = gDapyf8eHhCM0EV4xvUPWbIrjzdwZX+jGR73qbwzDQVua9yWdg
	if BeqAwyTaQl: hhNnomHYgPcVS = Yc0eBRLpbCkm4gK7OqyzuHwU+hhNnomHYgPcVS
	kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,'GLOBALSEARCH_SITES',hhNnomHYgPcVS,BeqAwyTaQl,WA14geuaxzJQ0ND3q8f2hdbk)
	return
def OLf6ESZRwzsg1GVpyk8quBA():
	A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO('','','','رسالة من المبرمج','هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if A5vgi1F6qVunZMas2Nf!=1: return
	QQvOnYi9sJMwp7dIxeck8DRASWuBt(WSgQvHLx9uOKTksaCt2JchldRj,'GLOBALSEARCH_SITES')
	QQvOnYi9sJMwp7dIxeck8DRASWuBt(WSgQvHLx9uOKTksaCt2JchldRj,'GLOBALSEARCH_OPENED')
	QQvOnYi9sJMwp7dIxeck8DRASWuBt(WSgQvHLx9uOKTksaCt2JchldRj,'GLOBALSEARCH_CLOSED')
	tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def XubEYBDZoGm2qIc(qkMdcGaSbDXT,JfMmQYi0ElaV,VewOrPR4kX=''):
	cVZmHTE6SPfUn,XXNiz5KEVj34ZRkeUq7vIPSHnYwDf,aj7K9uvRfCGwohN,To1wcRHgepUiJA4K,gvKdPYoSlIOAr8WXtzN0R97hM,kkdIBZNV4CitXEWe9PLzw,vv0j9xfSqC3IeNl2tV1 = [],[],[],{},{},{},{}
	if JfMmQYi0ElaV!='search_sites':
		if JfMmQYi0ElaV=='listed_sites': aj7K9uvRfCGwohN = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,'list','GLOBALSEARCH_SITES',Yc0eBRLpbCkm4gK7OqyzuHwU+qkMdcGaSbDXT)
		elif JfMmQYi0ElaV=='opened_sites': aj7K9uvRfCGwohN = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,'list','GLOBALSEARCH_OPENED',qkMdcGaSbDXT)
		elif JfMmQYi0ElaV=='closed_sites': aj7K9uvRfCGwohN = vsmQSl1ZDENy69BXJhWYF(WSgQvHLx9uOKTksaCt2JchldRj,'list','GLOBALSEARCH_CLOSED',(VewOrPR4kX,qkMdcGaSbDXT))
	if not aj7K9uvRfCGwohN:
		hwAK5bC7pHoU6VrSdgsvM = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		cE6OHoADvlhK1gVy2p8rYbWXFmGQ = 'هل تريد الآن البحث في جميع المواقع عن \n "[COLOR FFFFFF00] '+qkMdcGaSbDXT+' [/COLOR]" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if JfMmQYi0ElaV=='search_sites': maCNIYkc0HOiEGpL3g = cE6OHoADvlhK1gVy2p8rYbWXFmGQ
		else: maCNIYkc0HOiEGpL3g = hwAK5bC7pHoU6VrSdgsvM+cE6OHoADvlhK1gVy2p8rYbWXFmGQ
		A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO('','','','رسالة من المبرمج',maCNIYkc0HOiEGpL3g)
		if A5vgi1F6qVunZMas2Nf!=1: return
		UyZEGdfW50X3Rbpzmh1CnYOuDlsk4q(False,False,False)
		y75wQavkVSLUb2MZf9qo('NOTICE',Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+'   Search For: [ '+qkMdcGaSbDXT+' ]')
		ccTSbhAsKiuYOlyEmqUtoaCN6FLpX = 1
		for VewOrPR4kX in kpHmD5AvWYE2l:
			To1wcRHgepUiJA4K[VewOrPR4kX] = []
			VGPNayc6DgkReH1xC9BE3uFO475bf = '_NODIALOGS_'
			if '-' in VewOrPR4kX: VGPNayc6DgkReH1xC9BE3uFO475bf = VGPNayc6DgkReH1xC9BE3uFO475bf+'_REMEMBERRESULTS__'+VewOrPR4kX+'_'
			HmcsWL3qzIatv,jRreTXMs4JNBbt0Y,nROJXLEM6K = zzPTrDE4vhj2Bl8qFmiyWec(VewOrPR4kX)
			if ccTSbhAsKiuYOlyEmqUtoaCN6FLpX:
				w6vebiEZtpCjJcILP8Skx5rHn.sleep(0.5)
				vv0j9xfSqC3IeNl2tV1[VewOrPR4kX] = mZHwnlsXWDfV3ri4M.Thread(target=jRreTXMs4JNBbt0Y,args=(qkMdcGaSbDXT+VGPNayc6DgkReH1xC9BE3uFO475bf,))
				vv0j9xfSqC3IeNl2tV1[VewOrPR4kX].start()
			else: jRreTXMs4JNBbt0Y(qkMdcGaSbDXT+VGPNayc6DgkReH1xC9BE3uFO475bf)
			xa60ce2znAlyL5Z8ESXhO(NNbLf2d3Slq6pV(VewOrPR4kX),'',w6vebiEZtpCjJcILP8Skx5rHn=1000)
		if ccTSbhAsKiuYOlyEmqUtoaCN6FLpX:
			w6vebiEZtpCjJcILP8Skx5rHn.sleep(2)
			for VewOrPR4kX in kpHmD5AvWYE2l:
				vv0j9xfSqC3IeNl2tV1[VewOrPR4kX].join(10)
			w6vebiEZtpCjJcILP8Skx5rHn.sleep(2)
		for VewOrPR4kX in kpHmD5AvWYE2l:
			HmcsWL3qzIatv,jRreTXMs4JNBbt0Y,nROJXLEM6K = zzPTrDE4vhj2Bl8qFmiyWec(VewOrPR4kX)
			for zPEbGfWv2ehc1Akr4tiR in muPDGHvJwFieQYCW62bB:
				s8Oimqou2fZD,GG9zmPqulYDyJCtWwkE8,d7on6sKDqkNY,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,RxgdTHfDar8EXt,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH = zPEbGfWv2ehc1Akr4tiR
				if nROJXLEM6K in GG9zmPqulYDyJCtWwkE8:
					if 'IPTV-' in VewOrPR4kX and (239>=n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw>=230 or 289>=n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw>=280):
						if zPEbGfWv2ehc1Akr4tiR in To1wcRHgepUiJA4K['IPTV-LIVE']: continue
						if zPEbGfWv2ehc1Akr4tiR in To1wcRHgepUiJA4K['IPTV-MOVIES']: continue
						if zPEbGfWv2ehc1Akr4tiR in To1wcRHgepUiJA4K['IPTV-SERIES']: continue
						if 'صفحة' not in GG9zmPqulYDyJCtWwkE8:
							if   s8Oimqou2fZD=='live': VewOrPR4kX = 'IPTV-LIVE'
							elif s8Oimqou2fZD=='video': VewOrPR4kX = 'IPTV-MOVIES'
							elif s8Oimqou2fZD=='folder': VewOrPR4kX = 'IPTV-SERIES'
						else:
							if   'LIVE' in d7on6sKDqkNY: VewOrPR4kX = 'IPTV-LIVE'
							elif 'MOVIES' in d7on6sKDqkNY: VewOrPR4kX = 'IPTV-MOVIES'
							elif 'SERIES' in d7on6sKDqkNY: VewOrPR4kX = 'IPTV-SERIES'
					elif 'M3U-' in VewOrPR4kX and 729>=n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw>=710:
						if zPEbGfWv2ehc1Akr4tiR in To1wcRHgepUiJA4K['M3U-LIVE']: continue
						if zPEbGfWv2ehc1Akr4tiR in To1wcRHgepUiJA4K['M3U-MOVIES']: continue
						if zPEbGfWv2ehc1Akr4tiR in To1wcRHgepUiJA4K['M3U-SERIES']: continue
						if 'صفحة' not in GG9zmPqulYDyJCtWwkE8:
							if   s8Oimqou2fZD=='live': VewOrPR4kX = 'M3U-LIVE'
							elif s8Oimqou2fZD=='video': VewOrPR4kX = 'M3U-MOVIES'
							elif s8Oimqou2fZD=='folder': VewOrPR4kX = 'M3U-SERIES'
						else:
							if   'LIVE' in d7on6sKDqkNY: VewOrPR4kX = 'M3U-LIVE'
							elif 'MOVIES' in d7on6sKDqkNY: VewOrPR4kX = 'M3U-MOVIES'
							elif 'SERIES' in d7on6sKDqkNY: VewOrPR4kX = 'M3U-SERIES'
					elif 'YOUTUBE-' in VewOrPR4kX and 149>=n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw>=140:
						if zPEbGfWv2ehc1Akr4tiR in To1wcRHgepUiJA4K['YOUTUBE-CHANNELS']: continue
						if zPEbGfWv2ehc1Akr4tiR in To1wcRHgepUiJA4K['YOUTUBE-PLAYLISTS']: continue
						if zPEbGfWv2ehc1Akr4tiR in To1wcRHgepUiJA4K['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in GG9zmPqulYDyJCtWwkE8 or ':: ' in GG9zmPqulYDyJCtWwkE8:
							continue
						else:
							if   n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==144 and 'USER' in GG9zmPqulYDyJCtWwkE8: VewOrPR4kX = 'YOUTUBE-CHANNELS'
							elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==144 and 'CHNL' in GG9zmPqulYDyJCtWwkE8: VewOrPR4kX = 'YOUTUBE-CHANNELS'
							elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==144 and 'LIST' in GG9zmPqulYDyJCtWwkE8: VewOrPR4kX = 'YOUTUBE-PLAYLISTS'
							elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==143: VewOrPR4kX = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in VewOrPR4kX and 419>=n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw>=400:
						if zPEbGfWv2ehc1Akr4tiR in To1wcRHgepUiJA4K['DAILYMOTION-PLAYLISTS']: continue
						if zPEbGfWv2ehc1Akr4tiR in To1wcRHgepUiJA4K['DAILYMOTION-CHANNELS']: continue
						if zPEbGfWv2ehc1Akr4tiR in To1wcRHgepUiJA4K['DAILYMOTION-VIDEOS']: continue
						if zPEbGfWv2ehc1Akr4tiR in To1wcRHgepUiJA4K['DAILYMOTION-TOPICS']: continue
						if   n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw in [401,405]: VewOrPR4kX = 'DAILYMOTION-PLAYLISTS'
						elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw in [402,406]: VewOrPR4kX = 'DAILYMOTION-CHANNELS'
						elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw in [404]: VewOrPR4kX = 'DAILYMOTION-VIDEOS'
						elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw in [415]: VewOrPR4kX = 'DAILYMOTION-LIVES'
						elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw in [412,413]: VewOrPR4kX = 'DAILYMOTION-TOPICS'
					elif 'PANET-' in VewOrPR4kX and 39>=n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw>=30:
						if zPEbGfWv2ehc1Akr4tiR in To1wcRHgepUiJA4K['PANET-SERIES']: continue
						if zPEbGfWv2ehc1Akr4tiR in To1wcRHgepUiJA4K['PANET-MOVIES']: continue
						if   n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw in [32,39]: VewOrPR4kX = 'PANET-SERIES'
						elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw in [33,39]: VewOrPR4kX = 'PANET-MOVIES'
					elif 'IFILM-' in VewOrPR4kX and 29>=n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw>=20:
						if zPEbGfWv2ehc1Akr4tiR in To1wcRHgepUiJA4K['IFILM-ARABIC']: continue
						if zPEbGfWv2ehc1Akr4tiR in To1wcRHgepUiJA4K['IFILM-ENGLISH']: continue
						if   '/ar.' in d7on6sKDqkNY: VewOrPR4kX = 'IFILM-ARABIC'
						elif '/en.' in d7on6sKDqkNY: VewOrPR4kX = 'IFILM-ENGLISH'
					To1wcRHgepUiJA4K[VewOrPR4kX].append(zPEbGfWv2ehc1Akr4tiR)
		muPDGHvJwFieQYCW62bB[:] = []
		for VewOrPR4kX in list(To1wcRHgepUiJA4K.keys()):
			gvKdPYoSlIOAr8WXtzN0R97hM[VewOrPR4kX] = []
			kkdIBZNV4CitXEWe9PLzw[VewOrPR4kX] = []
			for s8Oimqou2fZD,GG9zmPqulYDyJCtWwkE8,d7on6sKDqkNY,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,RxgdTHfDar8EXt,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH in To1wcRHgepUiJA4K[VewOrPR4kX]:
				zPEbGfWv2ehc1Akr4tiR = (s8Oimqou2fZD,GG9zmPqulYDyJCtWwkE8,d7on6sKDqkNY,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,RxgdTHfDar8EXt,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH)
				if 'صفحة' in GG9zmPqulYDyJCtWwkE8 and s8Oimqou2fZD=='folder': kkdIBZNV4CitXEWe9PLzw[VewOrPR4kX].append(zPEbGfWv2ehc1Akr4tiR)
				else: gvKdPYoSlIOAr8WXtzN0R97hM[VewOrPR4kX].append(zPEbGfWv2ehc1Akr4tiR)
		eQIRn8i1srtOhlCT7Gf4XK = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157,'','','','','')]
		for VewOrPR4kX in TJsfnrDICj2WSVNtR:
			if VewOrPR4kX==ZtLSghu1xCopHkJseGQRVl4W6Dm2n[0]: eQIRn8i1srtOhlCT7Gf4XK = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة وعامة - كثيرة المشاكل[/COLOR]','',157,'','','','','')]
			elif VewOrPR4kX==yaWcERmZOMeC12Al3wx4YL[0]: eQIRn8i1srtOhlCT7Gf4XK = [('link','[COLOR FFC89008]مواقع سيرفرات عامة - كثيرة المشاكل[/COLOR]','',157,'','','','','')]
			elif VewOrPR4kX==cl4IbvCQhWLMFjA28[0]: eQIRn8i1srtOhlCT7Gf4XK = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157,'','','','','')]
			if VewOrPR4kX not in gvKdPYoSlIOAr8WXtzN0R97hM.keys(): continue
			if gvKdPYoSlIOAr8WXtzN0R97hM[VewOrPR4kX]:
				R0YetPzXIhL = NNbLf2d3Slq6pV(VewOrPR4kX)
				hpWuTlkcmfv8SyZgVDqoQYea6NUGid = [('link','[COLOR FFFFFF00]===== '+R0YetPzXIhL+' =====[/COLOR]','',9999,'','','','','')]
				if 0: AZz5WJFIGVPSsaLr89eEObvg4puUiy = qkMdcGaSbDXT+' - '+'بحث'+' '+R0YetPzXIhL
				else: AZz5WJFIGVPSsaLr89eEObvg4puUiy = 'بحث'+' '+R0YetPzXIhL+' - '+qkMdcGaSbDXT
				if len(gvKdPYoSlIOAr8WXtzN0R97hM[VewOrPR4kX])<8: vXyJe19owUHA4OPV8BE7WdkDucr6 = []
				else:
					Rk3bBtO8DGeMa = '[COLOR FFC89008]'+AZz5WJFIGVPSsaLr89eEObvg4puUiy+'[/COLOR]'
					vXyJe19owUHA4OPV8BE7WdkDucr6 = [('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+Rk3bBtO8DGeMa,'closed_sites',542,'',VewOrPR4kX,qkMdcGaSbDXT,'','')]
				xrjHbeFn1Vw2T9aIyPzu = gvKdPYoSlIOAr8WXtzN0R97hM[VewOrPR4kX]+kkdIBZNV4CitXEWe9PLzw[VewOrPR4kX]
				XXNiz5KEVj34ZRkeUq7vIPSHnYwDf += eQIRn8i1srtOhlCT7Gf4XK+hpWuTlkcmfv8SyZgVDqoQYea6NUGid+xrjHbeFn1Vw2T9aIyPzu[:7]+vXyJe19owUHA4OPV8BE7WdkDucr6
				wwi2eb3RVyHLUpI84B6 = [('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+AZz5WJFIGVPSsaLr89eEObvg4puUiy,'closed_sites',542,'',VewOrPR4kX,qkMdcGaSbDXT,'','')]
				cVZmHTE6SPfUn += eQIRn8i1srtOhlCT7Gf4XK+wwi2eb3RVyHLUpI84B6
				eQIRn8i1srtOhlCT7Gf4XK = []
				kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,'GLOBALSEARCH_CLOSED',(VewOrPR4kX,qkMdcGaSbDXT),xrjHbeFn1Vw2T9aIyPzu,WA14geuaxzJQ0ND3q8f2hdbk)
		kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,'GLOBALSEARCH_OPENED',qkMdcGaSbDXT,XXNiz5KEVj34ZRkeUq7vIPSHnYwDf,WA14geuaxzJQ0ND3q8f2hdbk)
		QQvOnYi9sJMwp7dIxeck8DRASWuBt(WSgQvHLx9uOKTksaCt2JchldRj,'GLOBALSEARCH_SITES',qkMdcGaSbDXT)
		kkNiXj3oTnqxQPvLMCfSKOm58F(WSgQvHLx9uOKTksaCt2JchldRj,'GLOBALSEARCH_SITES',Yc0eBRLpbCkm4gK7OqyzuHwU+qkMdcGaSbDXT,cVZmHTE6SPfUn,WA14geuaxzJQ0ND3q8f2hdbk)
		tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم لكي تستطيع العودة إليها بدون عمل بحث جديد')
		if JfMmQYi0ElaV=='listed_sites' and cVZmHTE6SPfUn: aj7K9uvRfCGwohN = cVZmHTE6SPfUn
		else: aj7K9uvRfCGwohN = XXNiz5KEVj34ZRkeUq7vIPSHnYwDf
	if JfMmQYi0ElaV!='search_sites':
		for s8Oimqou2fZD,GG9zmPqulYDyJCtWwkE8,d7on6sKDqkNY,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,RxgdTHfDar8EXt,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH in aj7K9uvRfCGwohN:
			if JfMmQYi0ElaV in ['listed_sites','opened_sites'] and 'صفحة' in GG9zmPqulYDyJCtWwkE8 and s8Oimqou2fZD=='folder': continue
			tBq8fTGUWJY9zvbgXD0EAloPO(s8Oimqou2fZD,GG9zmPqulYDyJCtWwkE8,d7on6sKDqkNY,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,OHMhVx5cw76slynUDdF24jgbkNG,tsMKaFVh1ZN2BIXEcvTejxR5DP,RxgdTHfDar8EXt,HHa1QbqG07ZPXko5fR,zSPVUW1XDt2Ba6ZkAH)
	UyZEGdfW50X3Rbpzmh1CnYOuDlsk4q('','','')
	return
def izRGM4knqdx0bLJjI6UvyPQuZ(qkMdcGaSbDXT=''):
	v4krFwHQLNUB,VGPNayc6DgkReH1xC9BE3uFO475bf,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(qkMdcGaSbDXT)
	if not v4krFwHQLNUB:
		v4krFwHQLNUB = UIf35nZEj1wylmq()
		if not v4krFwHQLNUB: return
		v4krFwHQLNUB = v4krFwHQLNUB.lower()
	y75wQavkVSLUb2MZf9qo('NOTICE',Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+'   Search For: [ '+v4krFwHQLNUB+' ]')
	DbEfLQSBFCTt2mMqvrsIVnjJ6 = v4krFwHQLNUB+VGPNayc6DgkReH1xC9BE3uFO475bf
	if 0: ppJSD0M5QdEeuX9WcZHGyog,wXW0Y9otuC6PQzpnF2GT = v4krFwHQLNUB+' - ',''
	else: ppJSD0M5QdEeuX9WcZHGyog,wXW0Y9otuC6PQzpnF2GT = '',' - '+v4krFwHQLNUB
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_M3U_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث M3U'+wXW0Y9otuC6PQzpnF2GT,'',719,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_IPT_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث IPTV'+wXW0Y9otuC6PQzpnF2GT,'',239,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_BKR_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع بكرا'+wXW0Y9otuC6PQzpnF2GT,'',379,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_KLA_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع كل العرب'+wXW0Y9otuC6PQzpnF2GT,'',19,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_ART_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع تونز عربية'+wXW0Y9otuC6PQzpnF2GT,'',739,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_KRB_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع قناة كربلاء'+wXW0Y9otuC6PQzpnF2GT,'',329,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_FH1_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع فاصل الأول'+wXW0Y9otuC6PQzpnF2GT,'',579,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_KTV_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع كتكوت تيفي'+wXW0Y9otuC6PQzpnF2GT,'',819,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_EB1_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع ايجي بيست 1'+wXW0Y9otuC6PQzpnF2GT,'',779,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_EB2_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع ايجي بيست 2'+wXW0Y9otuC6PQzpnF2GT,'',789,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_IFL_'+ppJSD0M5QdEeuX9WcZHGyog+'  بحث موقع قناة آي فيلم'+wXW0Y9otuC6PQzpnF2GT+'  ','',29,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_AKO_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع أكوام القديم'+wXW0Y9otuC6PQzpnF2GT,'',79,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_AKW_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع أكوام الجديد'+wXW0Y9otuC6PQzpnF2GT,'',249,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_MRF_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع قناة المعارف'+wXW0Y9otuC6PQzpnF2GT,'',49,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_SHM_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع شوف ماكس'+wXW0Y9otuC6PQzpnF2GT,'',59,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008]مواقع سيرفرات خاصة وعامة - كثيرة المشاكل[/COLOR]','',157)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_FJS_'+ppJSD0M5QdEeuX9WcZHGyog+' بحث موقع فجر شو'+wXW0Y9otuC6PQzpnF2GT+' ','',399,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_TVF_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع تيفي فان'+wXW0Y9otuC6PQzpnF2GT,'',469,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_LDN_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع لودي نت'+wXW0Y9otuC6PQzpnF2GT,'',459,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_CMN_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع سيما ناو'+wXW0Y9otuC6PQzpnF2GT,'',309,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_WCM_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع وي سيما'+wXW0Y9otuC6PQzpnF2GT,'',569,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_SHN_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع شاهد نيوز'+wXW0Y9otuC6PQzpnF2GT,'',589,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6+'_NODIALOGS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_ARS_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع عرب سييد'+wXW0Y9otuC6PQzpnF2GT,'',259,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_CCB_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع سيما كلوب'+wXW0Y9otuC6PQzpnF2GT,'',829,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_SH4_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع شاهد فوريو'+wXW0Y9otuC6PQzpnF2GT,'',119,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6+'_NODIALOGS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_SHT_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع شوفها تيفي'+wXW0Y9otuC6PQzpnF2GT,'',649,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008]مواقع سيرفرات عامة - كثيرة المشاكل[/COLOR]','',157)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_FST_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع فوستا'+wXW0Y9otuC6PQzpnF2GT,'',609,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_FBK_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع فبركة'+wXW0Y9otuC6PQzpnF2GT,'',629,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_YQT_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع ياقوت'+wXW0Y9otuC6PQzpnF2GT,'',669,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_BRS_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع برستيج'+wXW0Y9otuC6PQzpnF2GT,'',659,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_HLC_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع هلا سيما'+wXW0Y9otuC6PQzpnF2GT,'',89,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_DR7_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع دراما صح'+wXW0Y9otuC6PQzpnF2GT,'',689,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_CMF_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع سيما فانز'+wXW0Y9otuC6PQzpnF2GT,'',99,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_CML_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع سيما لايت'+wXW0Y9otuC6PQzpnF2GT,'',479,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_ABD_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع سيما عبدو'+wXW0Y9otuC6PQzpnF2GT,'',559,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_C4H_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع سيما 400'+wXW0Y9otuC6PQzpnF2GT,'',699,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_AHK_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع أهواك تيفي'+wXW0Y9otuC6PQzpnF2GT,'',619,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_EB4_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع ايجي بيست 4'+wXW0Y9otuC6PQzpnF2GT,'',809,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_YUT_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع يوتيوب'+wXW0Y9otuC6PQzpnF2GT,'',149,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_DLM_'+ppJSD0M5QdEeuX9WcZHGyog+'بحث موقع ديلي موشن'+wXW0Y9otuC6PQzpnF2GT,'',409,'','',DbEfLQSBFCTt2mMqvrsIVnjJ6)
	return
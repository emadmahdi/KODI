# -*- coding: utf-8 -*-
import sys as EAPND6zHKrMRuBc91tInYohsl0ywa
ttRJUcM0Tbr7gXN5x = EAPND6zHKrMRuBc91tInYohsl0ywa.version_info [0] == 2
Z2h7adALoKv4UPc1y = 2048
K2KPeD6VyEaQ = 7
def dC3HqaFgt6QYG4 (jZYXLbSUsQp5uk1tyzBAN7Hm):
	global ZeIJ6GDodMSzFut4jc05AK3OlhETR
	HY5UkLeNComBIMQPASnxph7 = ord (jZYXLbSUsQp5uk1tyzBAN7Hm [-1])
	PlVdbOK5hqks = jZYXLbSUsQp5uk1tyzBAN7Hm [:-1]
	prvC9qsF5RtBXHiaT3PwdJ = HY5UkLeNComBIMQPASnxph7 % len (PlVdbOK5hqks)
	LQB6POHcivdw87pk09ts2XMyf1IVEh = PlVdbOK5hqks [:prvC9qsF5RtBXHiaT3PwdJ] + PlVdbOK5hqks [prvC9qsF5RtBXHiaT3PwdJ:]
	if ttRJUcM0Tbr7gXN5x:
		Gn0XReKiJFMEsUxN531yAlI7S = unicode () .join ([unichr (ord (AitBMapzjZGc4u) - Z2h7adALoKv4UPc1y - (KQsX4n7jEogiLuJz + HY5UkLeNComBIMQPASnxph7) % K2KPeD6VyEaQ) for KQsX4n7jEogiLuJz, AitBMapzjZGc4u in enumerate (LQB6POHcivdw87pk09ts2XMyf1IVEh)])
	else:
		Gn0XReKiJFMEsUxN531yAlI7S = str () .join ([chr (ord (AitBMapzjZGc4u) - Z2h7adALoKv4UPc1y - (KQsX4n7jEogiLuJz + HY5UkLeNComBIMQPASnxph7) % K2KPeD6VyEaQ) for KQsX4n7jEogiLuJz, AitBMapzjZGc4u in enumerate (LQB6POHcivdw87pk09ts2XMyf1IVEh)])
	return eval (Gn0XReKiJFMEsUxN531yAlI7S)
I7N2lHpGfLPkwKxbOu6raYUgc5,QmoEjB3hLIw,WbM6qAjrn7fEXGZw=dC3HqaFgt6QYG4,dC3HqaFgt6QYG4,dC3HqaFgt6QYG4
bbqAtUz36RPGVTvCkejpJXQB,MM564HfnUV0XIR,YDC9i52g6e8XL7GxvIFnSKWsolpr=WbM6qAjrn7fEXGZw,QmoEjB3hLIw,I7N2lHpGfLPkwKxbOu6raYUgc5
YZFXwtrfK8uhzV4LlMEqgnCQyO9,tmcuvd397wjGXeWoDHMNpFB5h2VK,Ox8k6IdtuPaG3NlApQK52oYwM=YDC9i52g6e8XL7GxvIFnSKWsolpr,MM564HfnUV0XIR,bbqAtUz36RPGVTvCkejpJXQB
GGCQK6OAtZUXRhvkgJm,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6,Gk98CL5nXZEN=Ox8k6IdtuPaG3NlApQK52oYwM,tmcuvd397wjGXeWoDHMNpFB5h2VK,YZFXwtrfK8uhzV4LlMEqgnCQyO9
dEUYJjrhsaPXNo,wx18CTJPZ5,cWfQ64kVCqxhwvSy5P7irHI1oes3=Gk98CL5nXZEN,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6,GGCQK6OAtZUXRhvkgJm
qFRrj7ayBKbOsHGSXz,SIDG7cnzAaUpkwmNde19ZsBqQ3Hh,tOdiG2HWFRBXg1sUh=cWfQ64kVCqxhwvSy5P7irHI1oes3,wx18CTJPZ5,dEUYJjrhsaPXNo
smpniPDOhfwI3H4v7c6TG,CIcPowhneWs5tN3,zxwIDBrPiXjKlsYkfg0AGaUZSyW2co=tOdiG2HWFRBXg1sUh,SIDG7cnzAaUpkwmNde19ZsBqQ3Hh,qFRrj7ayBKbOsHGSXz
r6juULGQtnExAko38BZ5Y,NNmirJKPp5nWjfC,FeyZbj8tDil0nSHzTwfsUJ9=zxwIDBrPiXjKlsYkfg0AGaUZSyW2co,CIcPowhneWs5tN3,smpniPDOhfwI3H4v7c6TG
S26SnaqcM9XwK8PVphJDv5,CgPbwXm1RilpJUSGHLhy,NxsKJnLFEZ9OHXf1h=FeyZbj8tDil0nSHzTwfsUJ9,NNmirJKPp5nWjfC,r6juULGQtnExAko38BZ5Y
Kwl07iYTtDLN3zP,uAl3gHavMJZL4xmNe62nDiBoQ,ta478EuZQJIWhgBnsf6iU=NxsKJnLFEZ9OHXf1h,CgPbwXm1RilpJUSGHLhy,S26SnaqcM9XwK8PVphJDv5
EAw9bg4rT3Bd8tjSkO,ItgK5FqGDz2Rf7mAJkbT,FFVuCHLxhZmkEGJQDitreaygc2f4AS=ta478EuZQJIWhgBnsf6iU,uAl3gHavMJZL4xmNe62nDiBoQ,Kwl07iYTtDLN3zP
from zbUtu6IvKA import *
xa60ce2znAlyL5Z8ESXhO(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠧࡕࡇࡖࡘࠬ૛"),qFRrj7ayBKbOsHGSXz(u"ࠨࡖࡈࡗ࡙࠭૜"))
cu4NGSYJMOstXq7xhg = uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡬ࡴࡻ࠺࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡷ࡬࡮ࡴ࡫ࡣࡴࡲࡥࡩࡨࡡ࡯ࡦ࠱ࡧࡴࡳ࠯࠲࠲ࡐࡆ࠳ࢀࡩࡱࠩ૝")
cu4NGSYJMOstXq7xhg = FeyZbj8tDil0nSHzTwfsUJ9(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡵ࡫ࡥࡥࡶࡨࡷࡹ࠴ࡦࡵࡲ࠱ࡳࡹ࡫࡮ࡦࡶ࠱࡫ࡷ࠵ࡦࡪ࡮ࡨࡷ࠴ࡺࡥࡴࡶ࠴࠴࠵ࡱ࠮ࡥࡤࠪ૞")
vym8kYdTF2Opjn6wrKa(cu4NGSYJMOstXq7xhg,{},EAw9bg4rT3Bd8tjSkO(u"࡚ࡲࡶࡧૡ"))
d7on6sKDqkNY = zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠫࡈࡀ࡜࡝ࡖࡈࡑࡕࡢ࡜ࡵࡧࡰࡴࡡࡢࡡࡢࠢࡥࡦࡡࡢแฮื࠱ࡱࡵ࠹ࠧ૟")
d7on6sKDqkNY = YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠬࡉ࠺࡝࡞ࡗࡉࡒࡖ࡜࡝ࡶࡨࡱࡵࡢ࡜ࡢࡣࠣࡦࡧࡢ࡜ࡧ࡫࡯ࡩࡤ࠺࠸࠴࠶ࡢࡗࡍ࡜࡟ำ์สีฮࡥวๅำึ์้ࡥวๅล฼฼๊ࡥࠨึࠫࡢࠬศฮวัำࡢห้ำไ้ษฯ๎࠮࠴࡭ࡱ࠵ࠪૠ")
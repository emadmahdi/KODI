# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
PCY2LJwTgIfan = 'FAVORITES'
def N0NXgq1LxMG5zdr3ZDfho497lyI(n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,E3N4HOxSgv):
	if   n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==270: RbtUmf6lI3nFS8agCeNWGDcK4Z0 = EEP8u4SqXOtmnR(E3N4HOxSgv)
	else: RbtUmf6lI3nFS8agCeNWGDcK4Z0 = False
	return RbtUmf6lI3nFS8agCeNWGDcK4Z0
def gsHW8vED4ji(tiIc9lDHrUd):
	if not tiIc9lDHrUd: return
	if '_' in tiIc9lDHrUd: E3N4HOxSgv,Y7SRWpLsZ4XNGV3Jza8jImwHUKhqQT = tiIc9lDHrUd.split('_',1)
	else: E3N4HOxSgv,Y7SRWpLsZ4XNGV3Jza8jImwHUKhqQT = tiIc9lDHrUd,''
	if   Y7SRWpLsZ4XNGV3Jza8jImwHUKhqQT=='UP1'	: CteOZzbof2H3N1qPynDg(E3N4HOxSgv,True,1)
	elif Y7SRWpLsZ4XNGV3Jza8jImwHUKhqQT=='DOWN1'	: CteOZzbof2H3N1qPynDg(E3N4HOxSgv,False,1)
	elif Y7SRWpLsZ4XNGV3Jza8jImwHUKhqQT=='UP4'	: CteOZzbof2H3N1qPynDg(E3N4HOxSgv,True,4)
	elif Y7SRWpLsZ4XNGV3Jza8jImwHUKhqQT=='DOWN4'	: CteOZzbof2H3N1qPynDg(E3N4HOxSgv,False,4)
	elif Y7SRWpLsZ4XNGV3Jza8jImwHUKhqQT=='ADD1'	: QpqSVrjvNtK0m39UlLcnu7kbiHWIDF(E3N4HOxSgv)
	elif Y7SRWpLsZ4XNGV3Jza8jImwHUKhqQT=='REMOVE1': IHMzGLJCar(E3N4HOxSgv)
	elif Y7SRWpLsZ4XNGV3Jza8jImwHUKhqQT=='DELETELIST': dbp2geGXafN5J7HTBjlPEqt(E3N4HOxSgv)
	return
def EEP8u4SqXOtmnR(E3N4HOxSgv):
	S17nxiusU5pEFHCNqjYtRJoy9 = h0WgvJjBRGy()
	if E3N4HOxSgv in list(S17nxiusU5pEFHCNqjYtRJoy9.keys()):
		try:
			bR5FHuzOlmnajxdwkeyWK0EQ8Up3sC = S17nxiusU5pEFHCNqjYtRJoy9[E3N4HOxSgv]
			for s8Oimqou2fZD,GG9zmPqulYDyJCtWwkE8,d7on6sKDqkNY,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,zKHPsDVeYF,eWICxFNw73mJnSToUiR,RxgdTHfDar8EXt,tiIc9lDHrUd,UrmJVLMKYwNQFS4XBP in bR5FHuzOlmnajxdwkeyWK0EQ8Up3sC:
				tBq8fTGUWJY9zvbgXD0EAloPO(s8Oimqou2fZD,GG9zmPqulYDyJCtWwkE8,d7on6sKDqkNY,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,zKHPsDVeYF,eWICxFNw73mJnSToUiR,RxgdTHfDar8EXt,tiIc9lDHrUd,UrmJVLMKYwNQFS4XBP)
		except:
			S17nxiusU5pEFHCNqjYtRJoy9 = v3vOJa64yzBGcdQZ0oPrhNF9L(LkNCuYDaeV576vtyI)
			bR5FHuzOlmnajxdwkeyWK0EQ8Up3sC = S17nxiusU5pEFHCNqjYtRJoy9[E3N4HOxSgv]
			for s8Oimqou2fZD,GG9zmPqulYDyJCtWwkE8,d7on6sKDqkNY,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,zKHPsDVeYF,eWICxFNw73mJnSToUiR,RxgdTHfDar8EXt,tiIc9lDHrUd,UrmJVLMKYwNQFS4XBP in bR5FHuzOlmnajxdwkeyWK0EQ8Up3sC:
				tBq8fTGUWJY9zvbgXD0EAloPO(s8Oimqou2fZD,GG9zmPqulYDyJCtWwkE8,d7on6sKDqkNY,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,zKHPsDVeYF,eWICxFNw73mJnSToUiR,RxgdTHfDar8EXt,tiIc9lDHrUd,UrmJVLMKYwNQFS4XBP)
	return
def QpqSVrjvNtK0m39UlLcnu7kbiHWIDF(E3N4HOxSgv):
	s8Oimqou2fZD,GG9zmPqulYDyJCtWwkE8,d7on6sKDqkNY,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,zKHPsDVeYF,eWICxFNw73mJnSToUiR,RxgdTHfDar8EXt,tiIc9lDHrUd,UrmJVLMKYwNQFS4XBP = VVuCNFHGiUftREgnP4Aw(mpUuAaIVfPRoQEligGywDYz1)
	ffwWImDLJGFoQkUvi0Mg3Cz8S = s8Oimqou2fZD,GG9zmPqulYDyJCtWwkE8,d7on6sKDqkNY,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,zKHPsDVeYF,eWICxFNw73mJnSToUiR,RxgdTHfDar8EXt,'',UrmJVLMKYwNQFS4XBP
	S17nxiusU5pEFHCNqjYtRJoy9 = h0WgvJjBRGy()
	g4KtYb06UIGoi5Xvf2crjEq1HD7LJA = {}
	for XIOCS27h8EVTweDnjg0MB in list(S17nxiusU5pEFHCNqjYtRJoy9.keys()):
		if XIOCS27h8EVTweDnjg0MB!=E3N4HOxSgv: g4KtYb06UIGoi5Xvf2crjEq1HD7LJA[XIOCS27h8EVTweDnjg0MB] = S17nxiusU5pEFHCNqjYtRJoy9[XIOCS27h8EVTweDnjg0MB]
		else:
			if GG9zmPqulYDyJCtWwkE8 and GG9zmPqulYDyJCtWwkE8!='..':
				XKV6OsrwoS = S17nxiusU5pEFHCNqjYtRJoy9[XIOCS27h8EVTweDnjg0MB]
				if ffwWImDLJGFoQkUvi0Mg3Cz8S in XKV6OsrwoS:
					f61TXMLndxra9 = XKV6OsrwoS.index(ffwWImDLJGFoQkUvi0Mg3Cz8S)
					del XKV6OsrwoS[f61TXMLndxra9]
				FVcUmR1SCMJAO9dGbTDyn8joer0Y = XKV6OsrwoS+[ffwWImDLJGFoQkUvi0Mg3Cz8S]
				g4KtYb06UIGoi5Xvf2crjEq1HD7LJA[XIOCS27h8EVTweDnjg0MB] = FVcUmR1SCMJAO9dGbTDyn8joer0Y
			else: g4KtYb06UIGoi5Xvf2crjEq1HD7LJA[XIOCS27h8EVTweDnjg0MB] = S17nxiusU5pEFHCNqjYtRJoy9[XIOCS27h8EVTweDnjg0MB]
	if E3N4HOxSgv not in list(g4KtYb06UIGoi5Xvf2crjEq1HD7LJA.keys()): g4KtYb06UIGoi5Xvf2crjEq1HD7LJA[E3N4HOxSgv] = [ffwWImDLJGFoQkUvi0Mg3Cz8S]
	Oe45Tyi2Ru3ftQ1LYZ9kBaDGcwCMI = str(g4KtYb06UIGoi5Xvf2crjEq1HD7LJA)
	if wvkR1es6d0SrjxKt5FZTMUWz7a: Oe45Tyi2Ru3ftQ1LYZ9kBaDGcwCMI = Oe45Tyi2Ru3ftQ1LYZ9kBaDGcwCMI.encode('utf8')
	open(LkNCuYDaeV576vtyI,'wb').write(Oe45Tyi2Ru3ftQ1LYZ9kBaDGcwCMI)
	return
def IHMzGLJCar(E3N4HOxSgv):
	s8Oimqou2fZD,GG9zmPqulYDyJCtWwkE8,d7on6sKDqkNY,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,zKHPsDVeYF,eWICxFNw73mJnSToUiR,RxgdTHfDar8EXt,tiIc9lDHrUd,UrmJVLMKYwNQFS4XBP = VVuCNFHGiUftREgnP4Aw(mpUuAaIVfPRoQEligGywDYz1)
	ffwWImDLJGFoQkUvi0Mg3Cz8S = s8Oimqou2fZD,GG9zmPqulYDyJCtWwkE8,d7on6sKDqkNY,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,zKHPsDVeYF,eWICxFNw73mJnSToUiR,RxgdTHfDar8EXt,'',UrmJVLMKYwNQFS4XBP
	S17nxiusU5pEFHCNqjYtRJoy9 = h0WgvJjBRGy()
	if E3N4HOxSgv in list(S17nxiusU5pEFHCNqjYtRJoy9.keys()) and ffwWImDLJGFoQkUvi0Mg3Cz8S in S17nxiusU5pEFHCNqjYtRJoy9[E3N4HOxSgv]:
		S17nxiusU5pEFHCNqjYtRJoy9[E3N4HOxSgv].remove(ffwWImDLJGFoQkUvi0Mg3Cz8S)
		if len(S17nxiusU5pEFHCNqjYtRJoy9[E3N4HOxSgv])==0: del S17nxiusU5pEFHCNqjYtRJoy9[E3N4HOxSgv]
		Oe45Tyi2Ru3ftQ1LYZ9kBaDGcwCMI = str(S17nxiusU5pEFHCNqjYtRJoy9)
		if wvkR1es6d0SrjxKt5FZTMUWz7a: Oe45Tyi2Ru3ftQ1LYZ9kBaDGcwCMI = Oe45Tyi2Ru3ftQ1LYZ9kBaDGcwCMI.encode('utf8')
		open(LkNCuYDaeV576vtyI,'wb').write(Oe45Tyi2Ru3ftQ1LYZ9kBaDGcwCMI)
	return
def CteOZzbof2H3N1qPynDg(E3N4HOxSgv,XCGfwdrQMh,mMCO8GrQZNkvc):
	s8Oimqou2fZD,GG9zmPqulYDyJCtWwkE8,d7on6sKDqkNY,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,zKHPsDVeYF,eWICxFNw73mJnSToUiR,RxgdTHfDar8EXt,tiIc9lDHrUd,UrmJVLMKYwNQFS4XBP = VVuCNFHGiUftREgnP4Aw(mpUuAaIVfPRoQEligGywDYz1)
	ffwWImDLJGFoQkUvi0Mg3Cz8S = s8Oimqou2fZD,GG9zmPqulYDyJCtWwkE8,d7on6sKDqkNY,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,zKHPsDVeYF,eWICxFNw73mJnSToUiR,RxgdTHfDar8EXt,'',UrmJVLMKYwNQFS4XBP
	S17nxiusU5pEFHCNqjYtRJoy9 = h0WgvJjBRGy()
	if E3N4HOxSgv in list(S17nxiusU5pEFHCNqjYtRJoy9.keys()):
		XKV6OsrwoS = S17nxiusU5pEFHCNqjYtRJoy9[E3N4HOxSgv]
		if ffwWImDLJGFoQkUvi0Mg3Cz8S not in XKV6OsrwoS: return
		cqJU1Ywk4I = len(XKV6OsrwoS)
		for JF9iBfWwDE1GNjeS4HtOsgk7 in range(0,mMCO8GrQZNkvc):
			K9uVLg1ShMJ73Twyctr5pk4v = XKV6OsrwoS.index(ffwWImDLJGFoQkUvi0Mg3Cz8S)
			if XCGfwdrQMh: FpUr3AQHosaBWY = K9uVLg1ShMJ73Twyctr5pk4v-1
			else: FpUr3AQHosaBWY = K9uVLg1ShMJ73Twyctr5pk4v+1
			if FpUr3AQHosaBWY>=cqJU1Ywk4I: FpUr3AQHosaBWY = FpUr3AQHosaBWY-cqJU1Ywk4I
			if FpUr3AQHosaBWY<0: FpUr3AQHosaBWY = FpUr3AQHosaBWY+cqJU1Ywk4I
			XKV6OsrwoS.insert(FpUr3AQHosaBWY, XKV6OsrwoS.pop(K9uVLg1ShMJ73Twyctr5pk4v))
		S17nxiusU5pEFHCNqjYtRJoy9[E3N4HOxSgv] = XKV6OsrwoS
		Oe45Tyi2Ru3ftQ1LYZ9kBaDGcwCMI = str(S17nxiusU5pEFHCNqjYtRJoy9)
		if wvkR1es6d0SrjxKt5FZTMUWz7a: Oe45Tyi2Ru3ftQ1LYZ9kBaDGcwCMI = Oe45Tyi2Ru3ftQ1LYZ9kBaDGcwCMI.encode('utf8')
		open(LkNCuYDaeV576vtyI,'wb').write(Oe45Tyi2Ru3ftQ1LYZ9kBaDGcwCMI)
	return
def dbp2geGXafN5J7HTBjlPEqt(E3N4HOxSgv):
	Bh7kXZnFibK8x = eINt5FlUT0oO('center','','','رسالة من المبرمج','هل تريد فعلا مسح جميع محتويات قائمة المفضلة '+E3N4HOxSgv+' ؟!')
	if Bh7kXZnFibK8x!=1: return
	S17nxiusU5pEFHCNqjYtRJoy9 = h0WgvJjBRGy()
	if E3N4HOxSgv in list(S17nxiusU5pEFHCNqjYtRJoy9.keys()):
		del S17nxiusU5pEFHCNqjYtRJoy9[E3N4HOxSgv]
		Oe45Tyi2Ru3ftQ1LYZ9kBaDGcwCMI = str(S17nxiusU5pEFHCNqjYtRJoy9)
		if wvkR1es6d0SrjxKt5FZTMUWz7a: Oe45Tyi2Ru3ftQ1LYZ9kBaDGcwCMI = Oe45Tyi2Ru3ftQ1LYZ9kBaDGcwCMI.encode('utf8')
		open(LkNCuYDaeV576vtyI,'wb').write(Oe45Tyi2Ru3ftQ1LYZ9kBaDGcwCMI)
		tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','تم مسح جميع محتويات قائمة المفضلة '+E3N4HOxSgv)
	return
def h0WgvJjBRGy():
	S17nxiusU5pEFHCNqjYtRJoy9 = {}
	if K3hFytImeYMkJBC.path.exists(LkNCuYDaeV576vtyI):
		IIFPdSYMyODx5v3u1qcmzrjnZwK9R = open(LkNCuYDaeV576vtyI,'rb').read()
		if wvkR1es6d0SrjxKt5FZTMUWz7a: IIFPdSYMyODx5v3u1qcmzrjnZwK9R = IIFPdSYMyODx5v3u1qcmzrjnZwK9R.decode('utf8')
		S17nxiusU5pEFHCNqjYtRJoy9 = GVQAnvYCT3dS('dict',IIFPdSYMyODx5v3u1qcmzrjnZwK9R)
	return S17nxiusU5pEFHCNqjYtRJoy9
def dF9PbrkHwI(S17nxiusU5pEFHCNqjYtRJoy9,ffwWImDLJGFoQkUvi0Mg3Cz8S,XXRob1WZGCJnQOA7k):
	s8Oimqou2fZD,GG9zmPqulYDyJCtWwkE8,d7on6sKDqkNY,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,zKHPsDVeYF,eWICxFNw73mJnSToUiR,RxgdTHfDar8EXt,tiIc9lDHrUd,UrmJVLMKYwNQFS4XBP = ffwWImDLJGFoQkUvi0Mg3Cz8S
	if not n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw: s8Oimqou2fZD,n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw = 'folder','260'
	It3s9fSGhRP4,E3N4HOxSgv = [],''
	if 'context=' in mpUuAaIVfPRoQEligGywDYz1:
		SO6hl4pdXDeAmnGjLHt91fqg2W = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('context=(\d+)',mpUuAaIVfPRoQEligGywDYz1,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if SO6hl4pdXDeAmnGjLHt91fqg2W: E3N4HOxSgv = str(SO6hl4pdXDeAmnGjLHt91fqg2W[0])
	if n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw=='270':
		E3N4HOxSgv = tiIc9lDHrUd
		if E3N4HOxSgv in list(S17nxiusU5pEFHCNqjYtRJoy9.keys()):
			It3s9fSGhRP4.append(('مسح قائمة مفضلة '+E3N4HOxSgv,'RunPlugin('+XXRob1WZGCJnQOA7k+'&context='+E3N4HOxSgv+'_DELETELIST'+')'))
	else:
		if E3N4HOxSgv in list(S17nxiusU5pEFHCNqjYtRJoy9.keys()):
			count = len(S17nxiusU5pEFHCNqjYtRJoy9[E3N4HOxSgv])
			if count>1: It3s9fSGhRP4.append(('تحريك 1 للأعلى','RunPlugin('+XXRob1WZGCJnQOA7k+'&context='+E3N4HOxSgv+'_UP1)'))
			if count>4: It3s9fSGhRP4.append(('تحريك 4 للأعلى','RunPlugin('+XXRob1WZGCJnQOA7k+'&context='+E3N4HOxSgv+'_UP4)'))
			if count>1: It3s9fSGhRP4.append(('تحريك 1 للأسفل','RunPlugin('+XXRob1WZGCJnQOA7k+'&context='+E3N4HOxSgv+'_DOWN1)'))
			if count>4: It3s9fSGhRP4.append(('تحريك 4 للأسفل','RunPlugin('+XXRob1WZGCJnQOA7k+'&context='+E3N4HOxSgv+'_DOWN4)'))
		for E3N4HOxSgv in ['1','2','3','4','5']:
			if E3N4HOxSgv in list(S17nxiusU5pEFHCNqjYtRJoy9.keys()) and ffwWImDLJGFoQkUvi0Mg3Cz8S in S17nxiusU5pEFHCNqjYtRJoy9[E3N4HOxSgv]:
				It3s9fSGhRP4.append(('مسح من مفضلة '+E3N4HOxSgv,'RunPlugin('+XXRob1WZGCJnQOA7k+'&context='+E3N4HOxSgv+'_REMOVE1)'))
			else: It3s9fSGhRP4.append(('إضافة إلى مفضلة '+E3N4HOxSgv,'RunPlugin('+XXRob1WZGCJnQOA7k+'&context='+E3N4HOxSgv+'_ADD1)'))
	L9abB7iFWe6QOYwI0HdgfqsR4ZxK = []
	for l3DzxE1YR5,LMhEmG6XiH7Kz4N5qOf9jpx in It3s9fSGhRP4:
		l3DzxE1YR5 = '[COLOR FFFFFF00]'+l3DzxE1YR5+'[/COLOR]'
		L9abB7iFWe6QOYwI0HdgfqsR4ZxK.append((l3DzxE1YR5,LMhEmG6XiH7Kz4N5qOf9jpx,))
	return L9abB7iFWe6QOYwI0HdgfqsR4ZxK
# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
import bs4 as q2qgDtvucx7
r1NChsk39OMvT82YemDQnl5 = 'ELCINEMA'
Yc0eBRLpbCkm4gK7OqyzuHwU = '_ELC_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
headers = {'Referer':tle5V6jgvRfE}
ZLKHfqMEUdRupD = []
def HgQCVwFx2Br(mode,url,text):
	if   mode==510: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==511: s4Bng5iAZQSTtpDw9 = VxkCirwuOUSKDapcntJvoG(url)
	elif mode==512: s4Bng5iAZQSTtpDw9 = rEZnW1uFNRoA(url)
	elif mode==513: s4Bng5iAZQSTtpDw9 = K18eA0mG5xi9ykatDop(url)
	elif mode==514: s4Bng5iAZQSTtpDw9 = eqVfWsOr6I0No5GbMZQAy(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: s4Bng5iAZQSTtpDw9 = eqVfWsOr6I0No5GbMZQAy(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: s4Bng5iAZQSTtpDw9 = YQPrs7LyJ46(text)
	elif mode==517: s4Bng5iAZQSTtpDw9 = PPst6RXjO5AmB1uoLD2w(url)
	elif mode==518: s4Bng5iAZQSTtpDw9 = KxoSc5bCiMT(url)
	elif mode==519: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	elif mode==520: s4Bng5iAZQSTtpDw9 = eK7GLYwst4S3I6Mm(url)
	elif mode==521: s4Bng5iAZQSTtpDw9 = SSANPU3DnRYqGiow(url)
	elif mode==522: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==523: s4Bng5iAZQSTtpDw9 = MMBuDxNOsz9iCbSF5ja24vPU(text)
	elif mode==524: s4Bng5iAZQSTtpDw9 = yaJcn4MZ6DFU()
	elif mode==525: s4Bng5iAZQSTtpDw9 = Fzjd3H5TLUpkcSE2YiVR()
	elif mode==526: s4Bng5iAZQSTtpDw9 = AAkPZHpNvWFGq12Mu9()
	elif mode==527: s4Bng5iAZQSTtpDw9 = G5GX296aTsARlyBILceVF()
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث بموسوعة السينما','',519)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'موسوعة الأعمال','',525)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'موسوعة الأشخاص','',526)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'موسوعة المصنفات','',527)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'موسوعة المنوعات','',524)
	return
def yaJcn4MZ6DFU():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+' فيديوهات - خاصة',tle5V6jgvRfE+'/video',520)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فيديوهات - أحدث',tle5V6jgvRfE+'/video/latest',521)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فيديوهات - أقدم',tle5V6jgvRfE+'/video/oldest',521)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فيديوهات - أكثر مشاهدة',tle5V6jgvRfE+'/video/views',521)
	return
def Fzjd3H5TLUpkcSE2YiVR():
	gZDik5ejwVWadlCzJ49IFx1OnsvBYc = tle5V6jgvRfE+'/lineup?utf8=%E2%9C%93'
	llYdNGE8Kq3uM = gZDik5ejwVWadlCzJ49IFx1OnsvBYc+'&type=2&category=1&foreign=false&tag='
	SrWm5z9Xu6ylasBDUhROtdHoIJY = gZDik5ejwVWadlCzJ49IFx1OnsvBYc+'&type=2&category=3&foreign=false&tag='
	suQ0fqm9iYTb5VcvCAGEhOMxnz = gZDik5ejwVWadlCzJ49IFx1OnsvBYc+'&type=2&category=1&foreign=true&tag='
	t6d4hPByNn9SzHWfvbZxLAq1psjC = gZDik5ejwVWadlCzJ49IFx1OnsvBYc+'&type=2&category=3&foreign=true&tag='
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مصنفات أفلام عربي',llYdNGE8Kq3uM,511)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مصنفات مسلسلات عربي',SrWm5z9Xu6ylasBDUhROtdHoIJY,511)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مصنفات أفلام اجنبي',suQ0fqm9iYTb5VcvCAGEhOMxnz,511)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مصنفات مسلسلات اجنبي',t6d4hPByNn9SzHWfvbZxLAq1psjC,511)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فهرس أعمال أبجدي',tle5V6jgvRfE+'/index/work/alphabet',517)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فهرس  بلد الإنتاج',tle5V6jgvRfE+'/index/work/country',517)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فهرس اللغة',tle5V6jgvRfE+'/index/work/language',517)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فهرس مصنفات العمل',tle5V6jgvRfE+'/index/work/genre',517)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فهرس سنة الإصدار',tle5V6jgvRfE+'/index/work/release_year',517)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مواسم - فلتر محدد',tle5V6jgvRfE+'/seasonals',515)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مواسم - فلتر كامل',tle5V6jgvRfE+'/seasonals',514)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مصنفات - فلتر محدد',tle5V6jgvRfE+'/lineup',515)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مصنفات - فلتر كامل',tle5V6jgvRfE+'/lineup',514)
	return
def G5GX296aTsARlyBILceVF():
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',tle5V6jgvRfE+'/lineup','',headers,'','','ELCINEMA-MENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	xT0bCVBh1NvYc = q2qgDtvucx7.BeautifulSoup(M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,'html.parser',multi_valued_attributes=None)
	ziJLDVT8NM2QcgIpmE9A = xT0bCVBh1NvYc.find('select',attrs={'name':'tag'})
	dNlVai6Obj1e = ziJLDVT8NM2QcgIpmE9A.find_all('option')
	for e0i4nPhusqdTaG in dNlVai6Obj1e:
		hht0cpXxWw2OzFS1jnUGebkJLBd85 = e0i4nPhusqdTaG.get('value')
		if not hht0cpXxWw2OzFS1jnUGebkJLBd85: continue
		title = e0i4nPhusqdTaG.text
		if vciEXHThAPto76QIR2pK:
			title = title.encode('utf8')
			hht0cpXxWw2OzFS1jnUGebkJLBd85 = hht0cpXxWw2OzFS1jnUGebkJLBd85.encode('utf8')
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+hht0cpXxWw2OzFS1jnUGebkJLBd85
		title = title.replace('قائمة ','')
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,511)
	return
def AAkPZHpNvWFGq12Mu9():
	gZDik5ejwVWadlCzJ49IFx1OnsvBYc = tle5V6jgvRfE+'/lineup?utf8=%E2%9C%93'
	ooAn4rYqdV = gZDik5ejwVWadlCzJ49IFx1OnsvBYc+'&type=1&category=&foreign=&tag='
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مصنفات أشخاص',ooAn4rYqdV,511)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فهرس أشخاص أبجدي',tle5V6jgvRfE+'/index/person/alphabet',517)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فهرس موطن',tle5V6jgvRfE+'/index/person/nationality',517)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فهرس  تاريخ الميلاد',tle5V6jgvRfE+'/index/person/birth_year',517)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فهرس  تاريخ الوفاة',tle5V6jgvRfE+'/index/person/death_year',517)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مصنفات - فلتر محدد',tle5V6jgvRfE+'/lineup',515)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'مصنفات - فلتر كامل',tle5V6jgvRfE+'/lineup',514)
	return
def VxkCirwuOUSKDapcntJvoG(url):
	if '/seasonals' in url: EeWNT4ZgLwnchCSIjJKX = 0
	elif '/lineup' in url: EeWNT4ZgLwnchCSIjJKX = 1
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',url,'',headers,'','','ELCINEMA-LISTS-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	xT0bCVBh1NvYc = q2qgDtvucx7.BeautifulSoup(M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,'html.parser',multi_valued_attributes=None)
	cz4e6sNTj53E09xtaArJLKDg = xT0bCVBh1NvYc.find_all(class_='jumbo-theater clearfix')
	for ziJLDVT8NM2QcgIpmE9A in cz4e6sNTj53E09xtaArJLKDg:
		title = ziJLDVT8NM2QcgIpmE9A.find_all('a')[EeWNT4ZgLwnchCSIjJKX].text
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ziJLDVT8NM2QcgIpmE9A.find_all('a')[EeWNT4ZgLwnchCSIjJKX].get('href')
		if vciEXHThAPto76QIR2pK:
			title = title.encode('utf8')
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.encode('utf8')
		if not cz4e6sNTj53E09xtaArJLKDg:
			rEZnW1uFNRoA(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			return
		else:
			title = title.replace('قائمة ','')
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,512)
	sLYp6gD8wbEejm(xT0bCVBh1NvYc,511)
	return
def sLYp6gD8wbEejm(xT0bCVBh1NvYc,mode):
	ziJLDVT8NM2QcgIpmE9A = xT0bCVBh1NvYc.find(class_='pagination')
	if ziJLDVT8NM2QcgIpmE9A:
		gIrQwuNX0S4GL9TcmxEvjFet8hf = ziJLDVT8NM2QcgIpmE9A.find_all('a')
		u4cRIBkEJMtxWPDGrsLOHQ8bfgo = ziJLDVT8NM2QcgIpmE9A.find_all('li')
		SqX2fieBRMAPslyG8t6D543aZLK = list(zip(gIrQwuNX0S4GL9TcmxEvjFet8hf,u4cRIBkEJMtxWPDGrsLOHQ8bfgo))
		Deiz7ocWQjVnIg = -1
		srwIfqXmPivbBLxGKC = len(SqX2fieBRMAPslyG8t6D543aZLK)
		for u5B7sfGbpTt,xparOPqVIAkGBgTDM in SqX2fieBRMAPslyG8t6D543aZLK:
			Deiz7ocWQjVnIg += 1
			xparOPqVIAkGBgTDM = xparOPqVIAkGBgTDM['class']
			if 'unavailable' in xparOPqVIAkGBgTDM or 'current' in xparOPqVIAkGBgTDM: continue
			SSJLGwYsC5qz3bnku9IpyfX = u5B7sfGbpTt.text
			VktWBN6gn8zSUpesvfCyia2Ajm = tle5V6jgvRfE+u5B7sfGbpTt.get('href')
			if vciEXHThAPto76QIR2pK:
				SSJLGwYsC5qz3bnku9IpyfX = SSJLGwYsC5qz3bnku9IpyfX.encode('utf8')
				VktWBN6gn8zSUpesvfCyia2Ajm = VktWBN6gn8zSUpesvfCyia2Ajm.encode('utf8')
			if   Deiz7ocWQjVnIg==0: SSJLGwYsC5qz3bnku9IpyfX = 'أولى'
			elif Deiz7ocWQjVnIg==1: SSJLGwYsC5qz3bnku9IpyfX = 'سابقة'
			elif Deiz7ocWQjVnIg==srwIfqXmPivbBLxGKC-2: SSJLGwYsC5qz3bnku9IpyfX = 'لاحقة'
			elif Deiz7ocWQjVnIg==srwIfqXmPivbBLxGKC-1: SSJLGwYsC5qz3bnku9IpyfX = 'أخيرة'
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+SSJLGwYsC5qz3bnku9IpyfX,VktWBN6gn8zSUpesvfCyia2Ajm,mode)
	return
def rEZnW1uFNRoA(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',url,'',headers,'','','ELCINEMA-TITLES1-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	xT0bCVBh1NvYc = q2qgDtvucx7.BeautifulSoup(M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,'html.parser',multi_valued_attributes=None)
	cz4e6sNTj53E09xtaArJLKDg = xT0bCVBh1NvYc.find_all(class_='row')
	items,TTGV5OeusamgqYMHj4EZp81nXdbB = [],True
	for ziJLDVT8NM2QcgIpmE9A in cz4e6sNTj53E09xtaArJLKDg:
		if not ziJLDVT8NM2QcgIpmE9A.find(class_='thumbnail-wrapper'): continue
		if TTGV5OeusamgqYMHj4EZp81nXdbB: TTGV5OeusamgqYMHj4EZp81nXdbB = False ; continue
		EE4tqDJSLKzIk1TX3CoVRO = []
		DDyETNcsBw = ziJLDVT8NM2QcgIpmE9A.find_all(class_=['censorship red','censorship purple'])
		for MyTbLfp4cS8lxsad615iYB in DDyETNcsBw:
			i6SOtrU0NZmTexChcaVwvI = MyTbLfp4cS8lxsad615iYB.find_all('li')[1].text
			if vciEXHThAPto76QIR2pK:
				i6SOtrU0NZmTexChcaVwvI = i6SOtrU0NZmTexChcaVwvI.encode('utf8')
			EE4tqDJSLKzIk1TX3CoVRO.append(i6SOtrU0NZmTexChcaVwvI)
		if not Y1Yz6bZMLDaGjpxK3fSXm7TurCnHwo(r1NChsk39OMvT82YemDQnl5,'',EE4tqDJSLKzIk1TX3CoVRO,False):
			OHMhVx5cw76slynUDdF24jgbkNG = ziJLDVT8NM2QcgIpmE9A.find('img').get('data-src')
			title = ziJLDVT8NM2QcgIpmE9A.find('h3')
			name = title.find('a').text
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+title.find('a').get('href')
			Npm1KItEBcoUT0OR = ziJLDVT8NM2QcgIpmE9A.find(class_='no-margin')
			K45wC2ZFjODzXMkJBlof067EH = ziJLDVT8NM2QcgIpmE9A.find(class_='legend')
			if Npm1KItEBcoUT0OR: Npm1KItEBcoUT0OR = Npm1KItEBcoUT0OR.text
			if K45wC2ZFjODzXMkJBlof067EH: K45wC2ZFjODzXMkJBlof067EH = K45wC2ZFjODzXMkJBlof067EH.text
			if vciEXHThAPto76QIR2pK:
				OHMhVx5cw76slynUDdF24jgbkNG = OHMhVx5cw76slynUDdF24jgbkNG.encode('utf8')
				name = name.encode('utf8')
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.encode('utf8')
				if Npm1KItEBcoUT0OR: Npm1KItEBcoUT0OR = Npm1KItEBcoUT0OR.encode('utf8')
			zSPVUW1XDt2Ba6ZkAH = {}
			if K45wC2ZFjODzXMkJBlof067EH: zSPVUW1XDt2Ba6ZkAH['stars'] = K45wC2ZFjODzXMkJBlof067EH
			if Npm1KItEBcoUT0OR:
				Npm1KItEBcoUT0OR = Npm1KItEBcoUT0OR.replace('\n',' .. ')
				zSPVUW1XDt2Ba6ZkAH['plot'] = Npm1KItEBcoUT0OR.replace('...اقرأ المزيد','')
			if '/work/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+name,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,516,OHMhVx5cw76slynUDdF24jgbkNG,'',name,'',zSPVUW1XDt2Ba6ZkAH)
			elif '/person/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+name,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,513,OHMhVx5cw76slynUDdF24jgbkNG,'',name,'',zSPVUW1XDt2Ba6ZkAH)
	sLYp6gD8wbEejm(xT0bCVBh1NvYc,512)
	return
def K18eA0mG5xi9ykatDop(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',url,'',headers,'','','ELCINEMA-TITLES2-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	xT0bCVBh1NvYc = q2qgDtvucx7.BeautifulSoup(M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,'html.parser',multi_valued_attributes=None)
	cz4e6sNTj53E09xtaArJLKDg = xT0bCVBh1NvYc.find_all('li')
	If9vObmXl3iaWRxVjnQ4P,items = [],[]
	for ziJLDVT8NM2QcgIpmE9A in cz4e6sNTj53E09xtaArJLKDg:
		if not ziJLDVT8NM2QcgIpmE9A.find(class_='thumbnail-wrapper'): continue
		if not ziJLDVT8NM2QcgIpmE9A.find(class_=['unstyled','unstyled text-center']): continue
		if ziJLDVT8NM2QcgIpmE9A.find(class_='hide'): continue
		title = ziJLDVT8NM2QcgIpmE9A.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in If9vObmXl3iaWRxVjnQ4P: continue
		If9vObmXl3iaWRxVjnQ4P.append(name)
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+title.find('a').get('href')
		if '/search/work/' in url: OHMhVx5cw76slynUDdF24jgbkNG = ziJLDVT8NM2QcgIpmE9A.find('img').get('src')
		elif '/search/person/' in url: OHMhVx5cw76slynUDdF24jgbkNG = ziJLDVT8NM2QcgIpmE9A.find('img').get('data-src')
		elif '/search/video/' in url: OHMhVx5cw76slynUDdF24jgbkNG = ziJLDVT8NM2QcgIpmE9A.find('img').get('data-src')
		else: OHMhVx5cw76slynUDdF24jgbkNG = ziJLDVT8NM2QcgIpmE9A.find('img').get('src')
		if vciEXHThAPto76QIR2pK:
			name = name.encode('utf8')
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.encode('utf8')
			OHMhVx5cw76slynUDdF24jgbkNG = OHMhVx5cw76slynUDdF24jgbkNG.encode('utf8')
		name = name.strip(' ')
		items.append((name,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,OHMhVx5cw76slynUDdF24jgbkNG))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,OHMhVx5cw76slynUDdF24jgbkNG in items:
		if '/search/video/' in url: tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+name,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,522,OHMhVx5cw76slynUDdF24jgbkNG)
		elif '/search/person/' in url: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+name,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,513,OHMhVx5cw76slynUDdF24jgbkNG,'',name)
		else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+name,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,516,OHMhVx5cw76slynUDdF24jgbkNG,'',name)
	return
def YQPrs7LyJ46(text):
	text = text.replace('الإعلان','').replace('لفيلم','').replace('الرسمي','')
	text = text.replace('إعلان','').replace('فيلم','').replace('البرومو','')
	text = text.replace('التشويقي','').replace('لمسلسل','').replace('مسلسل','')
	text = text.replace(':','').replace(')','').replace('(','').replace(',','')
	text = text.replace('_','').replace(';','').replace('-','').replace('.','')
	text = text.replace('\'','').replace('\"','')
	text = text.replace('    ',' ').replace('   ',' ').replace('  ',' ')
	text = text.strip(' ')
	Xa4dewBY1QyCiTm8DKW3IHglJMR = text.count(' ')+1
	if Xa4dewBY1QyCiTm8DKW3IHglJMR==1:
		MMBuDxNOsz9iCbSF5ja24vPU(text)
		return
	tBq8fTGUWJY9zvbgXD0EAloPO('link',Yc0eBRLpbCkm4gK7OqyzuHwU+'[COLOR FFC89008]==== كلمات للبحث ====[/COLOR]','',9999)
	pRvNEkWmgA = text.split(' ')
	uVohkacEmCdTG9v25WOR6xbs = pow(2,Xa4dewBY1QyCiTm8DKW3IHglJMR)
	JKk2cBlnsPjuNzHXyamGiZOTR5I = []
	def ah8NgxvM2noCJUZmKGc0zL9ywrtIOj(d810OLzfxyr,UjqZ5K6eQu4VPy0SvhBzYsLITpH):
		if d810OLzfxyr=='1': return UjqZ5K6eQu4VPy0SvhBzYsLITpH
		return ''
	for Deiz7ocWQjVnIg in range(uVohkacEmCdTG9v25WOR6xbs,0,-1):
		oJHOx8Z0k7g = list(Xa4dewBY1QyCiTm8DKW3IHglJMR*'0'+bin(Deiz7ocWQjVnIg)[2:])[-Xa4dewBY1QyCiTm8DKW3IHglJMR:]
		oJHOx8Z0k7g = reversed(oJHOx8Z0k7g)
		ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0 = map(ah8NgxvM2noCJUZmKGc0zL9ywrtIOj,oJHOx8Z0k7g,pRvNEkWmgA)
		title = ' '.join(filter(None,ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0))
		if vciEXHThAPto76QIR2pK: neZQycYAFqxLzkPhEWvM = title.decode('utf8')
		else: neZQycYAFqxLzkPhEWvM = title
		if len(neZQycYAFqxLzkPhEWvM)>2 and title not in JKk2cBlnsPjuNzHXyamGiZOTR5I:
			JKk2cBlnsPjuNzHXyamGiZOTR5I.append(title)
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,'',523,'','',title)
	return
def MMBuDxNOsz9iCbSF5ja24vPU(wXW0Y9otuC6PQzpnF2GT):
	if vciEXHThAPto76QIR2pK:
		wXW0Y9otuC6PQzpnF2GT = wXW0Y9otuC6PQzpnF2GT.decode('utf8')
		import arabic_reshaper as jjgI7vFpAtWGiurhEPkmsalBbRJy
		wXW0Y9otuC6PQzpnF2GT = jjgI7vFpAtWGiurhEPkmsalBbRJy.ArabicReshaper().reshape(wXW0Y9otuC6PQzpnF2GT)
		wXW0Y9otuC6PQzpnF2GT = C5KxErBjfN7HzJbdPmAciQT.get_display(wXW0Y9otuC6PQzpnF2GT)
	import MMHzE6r0uI
	wXW0Y9otuC6PQzpnF2GT = UIf35nZEj1wylmq(default=wXW0Y9otuC6PQzpnF2GT)
	MMHzE6r0uI.Xwa7vgzTeb3Zy(wXW0Y9otuC6PQzpnF2GT)
	return
def PPst6RXjO5AmB1uoLD2w(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',url,'',headers,'','','ELCINEMA-INDEXES_LISTS-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	xT0bCVBh1NvYc = q2qgDtvucx7.BeautifulSoup(M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,'html.parser',multi_valued_attributes=None)
	ziJLDVT8NM2QcgIpmE9A = xT0bCVBh1NvYc.find(class_='list-separator list-title')
	GReTJrIxo2dzbapy = ziJLDVT8NM2QcgIpmE9A.find_all('a')
	items = []
	for title in GReTJrIxo2dzbapy:
		name = title.text
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+title.get('href')
		if vciEXHThAPto76QIR2pK:
			name = name.encode('utf8')
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.encode('utf8')
		if '#' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: items.append((name,ZCimQhV5lovgspAYzHq1Ef27u8ja4R))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for hh4gUqS5JWf1saRZPXHD in items:
		name,ZCimQhV5lovgspAYzHq1Ef27u8ja4R = hh4gUqS5JWf1saRZPXHD
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+name,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,518)
	return
def KxoSc5bCiMT(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',url,'',headers,'','','ELCINEMA-INDEXES_TITLES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	xT0bCVBh1NvYc = q2qgDtvucx7.BeautifulSoup(M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,'html.parser',multi_valued_attributes=None)
	cz4e6sNTj53E09xtaArJLKDg = xT0bCVBh1NvYc.find(class_='expand').find_all('tr')
	for ziJLDVT8NM2QcgIpmE9A in cz4e6sNTj53E09xtaArJLKDg:
		oj1DCIiM6s7fgydeuKNl9rWvFwbz0 = ziJLDVT8NM2QcgIpmE9A.find_all('a')
		if not oj1DCIiM6s7fgydeuKNl9rWvFwbz0: continue
		OHMhVx5cw76slynUDdF24jgbkNG = ziJLDVT8NM2QcgIpmE9A.find('img').get('data-src')
		name = oj1DCIiM6s7fgydeuKNl9rWvFwbz0[1].text
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+oj1DCIiM6s7fgydeuKNl9rWvFwbz0[1].get('href')
		K45wC2ZFjODzXMkJBlof067EH = ziJLDVT8NM2QcgIpmE9A.find(class_='legend')
		if K45wC2ZFjODzXMkJBlof067EH: K45wC2ZFjODzXMkJBlof067EH = K45wC2ZFjODzXMkJBlof067EH.text
		if vciEXHThAPto76QIR2pK:
			name = name.encode('utf8')
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.encode('utf8')
			OHMhVx5cw76slynUDdF24jgbkNG = OHMhVx5cw76slynUDdF24jgbkNG.encode('utf8')
		zSPVUW1XDt2Ba6ZkAH = {}
		if K45wC2ZFjODzXMkJBlof067EH: zSPVUW1XDt2Ba6ZkAH['stars'] = K45wC2ZFjODzXMkJBlof067EH
		if '/work/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+name,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,516,OHMhVx5cw76slynUDdF24jgbkNG,'',name,'',zSPVUW1XDt2Ba6ZkAH)
		elif '/person/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+name,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,513,OHMhVx5cw76slynUDdF24jgbkNG,'',name,'',zSPVUW1XDt2Ba6ZkAH)
	sLYp6gD8wbEejm(xT0bCVBh1NvYc,518)
	return
def eK7GLYwst4S3I6Mm(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',url,'',headers,'','','ELCINEMA-VIDEOS_LISTS-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	xT0bCVBh1NvYc = q2qgDtvucx7.BeautifulSoup(M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,'html.parser',multi_valued_attributes=None)
	GReTJrIxo2dzbapy = xT0bCVBh1NvYc.find_all(class_='section-title inline')
	cc0O1M4e5jtfoq = xT0bCVBh1NvYc.find_all(class_='button green small right')
	items = zip(GReTJrIxo2dzbapy,cc0O1M4e5jtfoq)
	for title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
		title = title.text
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ZCimQhV5lovgspAYzHq1Ef27u8ja4R.get('href')
		if vciEXHThAPto76QIR2pK:
			title = title.encode('utf8')
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.encode('utf8')
		title = title.replace('    ',' ').replace('   ',' ').replace('  ',' ')
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,521)
	return
def SSANPU3DnRYqGiow(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',url,'',headers,'','','ELCINEMA-VIDEOS_TITLES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	xT0bCVBh1NvYc = q2qgDtvucx7.BeautifulSoup(M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,'html.parser',multi_valued_attributes=None)
	EIZXoJfVgNKsL5WanhYvQwCHqDd = xT0bCVBh1NvYc.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	cz4e6sNTj53E09xtaArJLKDg = EIZXoJfVgNKsL5WanhYvQwCHqDd.find_all('li')
	for ziJLDVT8NM2QcgIpmE9A in cz4e6sNTj53E09xtaArJLKDg:
		title = ziJLDVT8NM2QcgIpmE9A.find(class_='title').text
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+ziJLDVT8NM2QcgIpmE9A.find('a').get('href')
		OHMhVx5cw76slynUDdF24jgbkNG = ziJLDVT8NM2QcgIpmE9A.find('img').get('data-src')
		s6z12JQXUyK5Wn4Bf7LYiDIP9F = ziJLDVT8NM2QcgIpmE9A.find(class_='duration').text
		if vciEXHThAPto76QIR2pK:
			title = title.encode('utf8')
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.encode('utf8')
			OHMhVx5cw76slynUDdF24jgbkNG = OHMhVx5cw76slynUDdF24jgbkNG.encode('utf8')
			s6z12JQXUyK5Wn4Bf7LYiDIP9F = s6z12JQXUyK5Wn4Bf7LYiDIP9F.encode('utf8')
		s6z12JQXUyK5Wn4Bf7LYiDIP9F = s6z12JQXUyK5Wn4Bf7LYiDIP9F.replace('\n','').strip(' ')
		tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,522,OHMhVx5cw76slynUDdF24jgbkNG,s6z12JQXUyK5Wn4Bf7LYiDIP9F)
	sLYp6gD8wbEejm(xT0bCVBh1NvYc,521)
	return
def dlropqS0vO9K7W4z(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',url,'',headers,'','','ELCINEMA-PLAY-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	xT0bCVBh1NvYc = q2qgDtvucx7.BeautifulSoup(M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,'html.parser',multi_valued_attributes=None)
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = xT0bCVBh1NvYc.find(class_='flex-video').find('iframe').get('src')
	if vciEXHThAPto76QIR2pK: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.encode('utf8')
	pSAuLjYqhgc9brWFKs7Pa4J(ZCimQhV5lovgspAYzHq1Ef27u8ja4R,r1NChsk39OMvT82YemDQnl5,'video')
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if search=='': search = UIf35nZEj1wylmq()
	if search=='': return
	search = search.replace(' ','%20')
	url = tle5V6jgvRfE+'/search/?q='+search
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',url,'',headers,'','','ELCINEMA-SEARCH-1st')
	if not aQniqUlZk8.succeeded:
		ooAn4rYqdV = tle5V6jgvRfE+'/search_entity/?q='+search+'&entity=work'
		VktWBN6gn8zSUpesvfCyia2Ajm = tle5V6jgvRfE+'/search_entity/?q='+search+'&entity=person'
		EHIKzN5FogkhD = tle5V6jgvRfE+'/search_entity/?q='+search+'&entity=video'
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث عن أعمال',ooAn4rYqdV,513,'',search)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث عن أشخاص',VktWBN6gn8zSUpesvfCyia2Ajm,513,'',search)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث عن فيديوهات',EHIKzN5FogkhD,513,'',search)
		return
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	xT0bCVBh1NvYc = q2qgDtvucx7.BeautifulSoup(M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,'html.parser',multi_valued_attributes=None)
	cz4e6sNTj53E09xtaArJLKDg = xT0bCVBh1NvYc.find_all(class_='section-title left')
	for ziJLDVT8NM2QcgIpmE9A in cz4e6sNTj53E09xtaArJLKDg:
		title = ziJLDVT8NM2QcgIpmE9A.text
		if vciEXHThAPto76QIR2pK:
			title = title.encode('utf8')
		title = title.split('(',1)[0].strip(' ')
		if   'أعمال' in title: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = url.replace('/search/','/search/video/')
		else: continue
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,513)
	return
def eqVfWsOr6I0No5GbMZQAy(url,text):
	global tpH7FYXLyz4UJdcC31OQ0Phwg,bxa9Gj5p3oElwmngHJRKP7CtqS
	if '/seasonals' in url:
		tpH7FYXLyz4UJdcC31OQ0Phwg = ['seasonal','year','category']
		bxa9Gj5p3oElwmngHJRKP7CtqS = ['seasonal','year','category']
	elif '/lineup' in url:
		tpH7FYXLyz4UJdcC31OQ0Phwg = ['category','foreign','type']
		bxa9Gj5p3oElwmngHJRKP7CtqS = ['category','foreign','type']
	L1FsQxw6Afb7pcCe9Tr3qizXZ(url,text)
	return
def UdqXh8aClcxJAEVSFKy9PnjuGW(url):
	url = url.split('/smartemadfilter?')[0]
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',url,'',headers,'','','ELCINEMA-GET_FILTERS_BLOCKS-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('form action="/(.*?)</form>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	H8n4oVq07uvJjCOwgzbyf6XR9Fs = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	return H8n4oVq07uvJjCOwgzbyf6XR9Fs
def HOgJ4cadx6GAE(ziJLDVT8NM2QcgIpmE9A):
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<option value="(.*?)">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	return items
def VUJ0sTjSZ36wgnRh2bWzK(url):
	bBac0ZnqRLiYT6x93vJyFjQ = url.split('/smartemadfilter?')[0]
	kFlE9TNexjg76 = SLMTm6RQ34ic7v5s9rBG(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def iZlSb1tR2Bs(SWxX6Q3CgwV7F,url):
	Rdgr0aTSzE5chex9W = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(SWxX6Q3CgwV7F,'all_filters')
	TW6JIBgC971tjOE = url+'/smartemadfilter?'+Rdgr0aTSzE5chex9W
	TW6JIBgC971tjOE = VUJ0sTjSZ36wgnRh2bWzK(TW6JIBgC971tjOE)
	return TW6JIBgC971tjOE
def L1FsQxw6Afb7pcCe9Tr3qizXZ(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': ydL2RstfT9BA3Hpe1SZIq,l3Uo4ThenPyJMua = '',''
	else: ydL2RstfT9BA3Hpe1SZIq,l3Uo4ThenPyJMua = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if tpH7FYXLyz4UJdcC31OQ0Phwg[0]+'=' not in ydL2RstfT9BA3Hpe1SZIq: cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = tpH7FYXLyz4UJdcC31OQ0Phwg[0]
		for AudBQkLFsrHKicIogThZyv in range(len(tpH7FYXLyz4UJdcC31OQ0Phwg[0:-1])):
			if tpH7FYXLyz4UJdcC31OQ0Phwg[AudBQkLFsrHKicIogThZyv]+'=' in ydL2RstfT9BA3Hpe1SZIq: cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = tpH7FYXLyz4UJdcC31OQ0Phwg[AudBQkLFsrHKicIogThZyv+1]
		rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&'+cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo+'=0'
		SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&'+cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo+'=0'
		hOSk91jGqtHsfwU2ExCV4YB = rrsgSnC5AFkbEvDPm6pyaRizM8.strip('&')+'___'+SWxX6Q3CgwV7F.strip('&')
		Rdgr0aTSzE5chex9W = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(l3Uo4ThenPyJMua,'modified_filters')
		M08MPGgsh4n5rKe = url+'/smartemadfilter?'+Rdgr0aTSzE5chex9W
	elif type=='ALL_ITEMS_FILTER':
		jyRzHeOYXAW4oDrUS = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(ydL2RstfT9BA3Hpe1SZIq,'modified_values')
		jyRzHeOYXAW4oDrUS = BUTSkzgFC7(jyRzHeOYXAW4oDrUS)
		if l3Uo4ThenPyJMua!='': l3Uo4ThenPyJMua = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(l3Uo4ThenPyJMua,'modified_filters')
		if l3Uo4ThenPyJMua=='': M08MPGgsh4n5rKe = url
		else: M08MPGgsh4n5rKe = url+'/smartemadfilter?'+l3Uo4ThenPyJMua
		M08MPGgsh4n5rKe = VUJ0sTjSZ36wgnRh2bWzK(M08MPGgsh4n5rKe)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'أظهار قائمة الفيديو التي تم اختيارها ',M08MPGgsh4n5rKe,511)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+' [[   '+jyRzHeOYXAW4oDrUS+'   ]]',M08MPGgsh4n5rKe,511)
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	H8n4oVq07uvJjCOwgzbyf6XR9Fs = UdqXh8aClcxJAEVSFKy9PnjuGW(url)
	dict = {}
	for name,eFmOUji0173K,ziJLDVT8NM2QcgIpmE9A in H8n4oVq07uvJjCOwgzbyf6XR9Fs:
		name = name.replace('--','')
		items = HOgJ4cadx6GAE(ziJLDVT8NM2QcgIpmE9A)
		if '=' not in M08MPGgsh4n5rKe: M08MPGgsh4n5rKe = url
		if type=='SPECIFIED_FILTER':
			if eFmOUji0173K not in tpH7FYXLyz4UJdcC31OQ0Phwg: continue
			if cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo!=eFmOUji0173K: continue
			elif len(items)<2:
				if eFmOUji0173K==tpH7FYXLyz4UJdcC31OQ0Phwg[-1]:
					url = VUJ0sTjSZ36wgnRh2bWzK(url)
					rEZnW1uFNRoA(url)
				else: L1FsQxw6Afb7pcCe9Tr3qizXZ(M08MPGgsh4n5rKe,'SPECIFIED_FILTER___'+hOSk91jGqtHsfwU2ExCV4YB)
				return
			else:
				M08MPGgsh4n5rKe = VUJ0sTjSZ36wgnRh2bWzK(M08MPGgsh4n5rKe)
				if eFmOUji0173K==tpH7FYXLyz4UJdcC31OQ0Phwg[-1]: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع',M08MPGgsh4n5rKe,511)
				else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع',M08MPGgsh4n5rKe,515,'','',hOSk91jGqtHsfwU2ExCV4YB)
		elif type=='ALL_ITEMS_FILTER':
			if eFmOUji0173K not in bxa9Gj5p3oElwmngHJRKP7CtqS: continue
			rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&'+eFmOUji0173K+'=0'
			SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&'+eFmOUji0173K+'=0'
			hOSk91jGqtHsfwU2ExCV4YB = rrsgSnC5AFkbEvDPm6pyaRizM8+'___'+SWxX6Q3CgwV7F
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع: '+name,M08MPGgsh4n5rKe,514,'','',hOSk91jGqtHsfwU2ExCV4YB)
		dict[eFmOUji0173K] = {}
		for hht0cpXxWw2OzFS1jnUGebkJLBd85,e0i4nPhusqdTaG in items:
			if e0i4nPhusqdTaG in ZLKHfqMEUdRupD: continue
			if 'مصنفات أخرى' in e0i4nPhusqdTaG: continue
			if 'الكل' in e0i4nPhusqdTaG: continue
			if 'اللغة' in e0i4nPhusqdTaG: continue
			e0i4nPhusqdTaG = e0i4nPhusqdTaG.replace('قائمة ','')
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[eFmOUji0173K][hht0cpXxWw2OzFS1jnUGebkJLBd85] = e0i4nPhusqdTaG
			rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&'+eFmOUji0173K+'='+e0i4nPhusqdTaG
			SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&'+eFmOUji0173K+'='+hht0cpXxWw2OzFS1jnUGebkJLBd85
			RtPpz8FAEjIxU = rrsgSnC5AFkbEvDPm6pyaRizM8+'___'+SWxX6Q3CgwV7F
			if name: title = e0i4nPhusqdTaG+' :'+name
			else: title = e0i4nPhusqdTaG
			if type=='ALL_ITEMS_FILTER': tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,514,'','',RtPpz8FAEjIxU)
			elif type=='SPECIFIED_FILTER' and tpH7FYXLyz4UJdcC31OQ0Phwg[-2]+'=' in ydL2RstfT9BA3Hpe1SZIq:
				TW6JIBgC971tjOE = iZlSb1tR2Bs(SWxX6Q3CgwV7F,url)
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,TW6JIBgC971tjOE,511)
			else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,515,'','',RtPpz8FAEjIxU)
	return
def l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(dY1a0xA6PKm7TOJSERt3sHU9Qp,mode):
	dY1a0xA6PKm7TOJSERt3sHU9Qp = dY1a0xA6PKm7TOJSERt3sHU9Qp.replace('=&','=0&')
	dY1a0xA6PKm7TOJSERt3sHU9Qp = dY1a0xA6PKm7TOJSERt3sHU9Qp.strip('&')
	nvNkgT7iGQOyed = {}
	if '=' in dY1a0xA6PKm7TOJSERt3sHU9Qp:
		items = dY1a0xA6PKm7TOJSERt3sHU9Qp.split('&')
		for hh4gUqS5JWf1saRZPXHD in items:
			DHcrLNnqExKjM8uvVlBhWd,hht0cpXxWw2OzFS1jnUGebkJLBd85 = hh4gUqS5JWf1saRZPXHD.split('=')
			nvNkgT7iGQOyed[DHcrLNnqExKjM8uvVlBhWd] = hht0cpXxWw2OzFS1jnUGebkJLBd85
	UJzegYmlGML35rasDAIx17Rhnk = ''
	for key in bxa9Gj5p3oElwmngHJRKP7CtqS:
		if key in list(nvNkgT7iGQOyed.keys()): hht0cpXxWw2OzFS1jnUGebkJLBd85 = nvNkgT7iGQOyed[key]
		else: hht0cpXxWw2OzFS1jnUGebkJLBd85 = '0'
		if '%' not in hht0cpXxWw2OzFS1jnUGebkJLBd85: hht0cpXxWw2OzFS1jnUGebkJLBd85 = TaEr2nR3f5e8oXzpy(hht0cpXxWw2OzFS1jnUGebkJLBd85)
		if mode=='modified_values' and hht0cpXxWw2OzFS1jnUGebkJLBd85!='0': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+' + '+hht0cpXxWw2OzFS1jnUGebkJLBd85
		elif mode=='modified_filters' and hht0cpXxWw2OzFS1jnUGebkJLBd85!='0': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+'&'+key+'='+hht0cpXxWw2OzFS1jnUGebkJLBd85
		elif mode=='all_filters': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+'&'+key+'='+hht0cpXxWw2OzFS1jnUGebkJLBd85
	UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk.strip(' + ')
	UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk.strip('&')
	UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk.replace('=0','=')
	return UJzegYmlGML35rasDAIx17Rhnk
tpH7FYXLyz4UJdcC31OQ0Phwg = []
bxa9Gj5p3oElwmngHJRKP7CtqS = []
# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'SERIES4WATCH'
headers = { 'User-Agent' : '' }
Yc0eBRLpbCkm4gK7OqyzuHwU = '_SFW_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
def HgQCVwFx2Br(mode,url,text):
	if   mode==210: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==211: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url)
	elif mode==212: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==213: s4Bng5iAZQSTtpDw9 = btd6ag2XYUkHixqy5J7o9RfLu1MScm(url)
	elif mode==214: s4Bng5iAZQSTtpDw9 = ZZj6wL5NPeUYuk03p2tAVGHBfm7(url)
	elif mode==215: s4Bng5iAZQSTtpDw9 = e3txH5IipZC(url)
	elif mode==218: s4Bng5iAZQSTtpDw9 = qi6HK0RYD9G1ufo4Q3lNePB()
	elif mode==219: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def qi6HK0RYD9G1ufo4Q3lNePB():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','الموقع تغير بالكامل',message)
	return
def Or15mUj4By():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',219,'','','_REMEMBERRESULTS_')
	url = tle5V6jgvRfE+'/getpostsPin?type=one&data=pin&limit=25'
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'المميزة',url,211)
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,tle5V6jgvRfE,'',headers,'','SERIES4WATCH-MENU-1st')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('FiltersButtons(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-get="(.*?)".*?</i>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		url = tle5V6jgvRfE+'/getposts?type=one&data='+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,211)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('navigation-menu(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(http.*?)">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ZLKHfqMEUdRupD = ['مسلسلات انمي','الرئيسية']
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		title = title.strip(' ')
		if not any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title for hht0cpXxWw2OzFS1jnUGebkJLBd85 in ZLKHfqMEUdRupD):
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,211)
	return M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
def uyt3pAHZk4(url):
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,url,'',headers,'','SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: ziJLDVT8NM2QcgIpmE9A = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
	else:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('MediaGrid"(.*?)class="pagination"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3: ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		else: return
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	jjR8ftoEXpPxVF6JerbHZuzv7ic = []
	cFEX1lI9Wg2 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for Q2qmuDRrC9ikcaJK7gtUHXNW,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		if '/series/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: continue
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = BUTSkzgFC7(ZCimQhV5lovgspAYzHq1Ef27u8ja4R).strip('/')
		title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
		title = title.strip(' ')
		if '/film/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R or any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title for hht0cpXxWw2OzFS1jnUGebkJLBd85 in cFEX1lI9Wg2):
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,212,Q2qmuDRrC9ikcaJK7gtUHXNW)
		elif '/episode/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R and 'الحلقة' in title:
			EQw62xjXSJmzrRt = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(.*?) الحلقة \d+',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if EQw62xjXSJmzrRt:
				title = '_MOD_' + EQw62xjXSJmzrRt[0]
				if title not in jjR8ftoEXpPxVF6JerbHZuzv7ic:
					tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,213,Q2qmuDRrC9ikcaJK7gtUHXNW)
					jjR8ftoEXpPxVF6JerbHZuzv7ic.append(title)
		else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,213,Q2qmuDRrC9ikcaJK7gtUHXNW)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="pagination(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = nnGHa80rMphqe1ukFtIRvAPs6W(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
			title = title.replace('الصفحة ','')
			if title!='': tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,211)
	return
def btd6ag2XYUkHixqy5J7o9RfLu1MScm(url):
	zfwcXQbhNaBT8,items,gzjIKdLQR8Gu = -1,[],[]
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,url,'',headers,'','SERIES4WATCH-EPISODES-1st')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('ti-list-numbered(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		cz4e6sNTj53E09xtaArJLKDg = ''.join(TIkiozSLCv6werb97mHQ0q4y3)
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)"',cz4e6sNTj53E09xtaArJLKDg,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	items.append(url)
	items = set(items)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.strip('/')
		title = '_MOD_' + ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('/')[-1].replace('-',' ')
		mbGei9dIvrTohtJ = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('الحلقة-(\d+)',ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('/')[-1],E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if mbGei9dIvrTohtJ: mbGei9dIvrTohtJ = mbGei9dIvrTohtJ[0]
		else: mbGei9dIvrTohtJ = '0'
		gzjIKdLQR8Gu.append([ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,mbGei9dIvrTohtJ])
	items = sorted(gzjIKdLQR8Gu, reverse=False, key=lambda key: int(key[2]))
	MnpVClumZUBTXe0r2i5jcQGokw = str(items).count('/season/')
	zfwcXQbhNaBT8 = str(items).count('/episode/')
	if MnpVClumZUBTXe0r2i5jcQGokw>1 and zfwcXQbhNaBT8>0 and '/season/' not in url:
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,mbGei9dIvrTohtJ in items:
			if '/season/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,213)
	else:
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,mbGei9dIvrTohtJ in items:
			if '/season/' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,212)
	return
def dlropqS0vO9K7W4z(url):
	jVMHRouKgQFAESmd7B8ObTYy = []
	oBzGqDUAi7KaL8vFdZtP9XIcf = url.split('/')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,url,'',headers,'','SERIES4WATCH-PLAY-1st')
	if '/watch/' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2:
		M08MPGgsh4n5rKe = url.replace(oBzGqDUAi7KaL8vFdZtP9XIcf[3],'watch')
		flARjI3NM9CQnWY1xk7 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,M08MPGgsh4n5rKe,'',headers,'','SERIES4WATCH-PLAY-2nd')
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="servers-list(.*?)</div>',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3:
			ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if items:
				id = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('post_id=(.*?)"',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
				if id:
					gUmrWFV3dB6Q1b02wuHq5 = id[0]
					for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
						ZCimQhV5lovgspAYzHq1Ef27u8ja4R = tle5V6jgvRfE+'/?postid='+gUmrWFV3dB6Q1b02wuHq5+'&serverid='+ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+title+'__watch'
						jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			else:
				items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-embedd=".*?(http.*?)("|&quot;)',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
				for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,aQ0kNq9gnYBKJ5yV6oRhXZ7ImfwreT in items:
					jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	if '/download/' in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2:
		M08MPGgsh4n5rKe = url.replace(oBzGqDUAi7KaL8vFdZtP9XIcf[3],'download')
		flARjI3NM9CQnWY1xk7 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,M08MPGgsh4n5rKe,'',headers,'','SERIES4WATCH-PLAY-3rd')
		id = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('postId:"(.*?)"',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if id:
			gUmrWFV3dB6Q1b02wuHq5 = id[0]
			TC7fWv2a1gLJGiAtN8 = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' }
			M08MPGgsh4n5rKe = tle5V6jgvRfE + '/ajaxCenter?_action=getdownloadlinks&postId='+gUmrWFV3dB6Q1b02wuHq5
			flARjI3NM9CQnWY1xk7 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,M08MPGgsh4n5rKe,'',TC7fWv2a1gLJGiAtN8,'','SERIES4WATCH-PLAY-4th')
			TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<h3.*?(\d+)(.*?)</div>',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if TIkiozSLCv6werb97mHQ0q4y3:
				for gy7DjoZdVElL,ziJLDVT8NM2QcgIpmE9A in TIkiozSLCv6werb97mHQ0q4y3:
					items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<td>(.*?)<.*?href="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
					for name,ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
						jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+name+'__download'+'____'+gy7DjoZdVElL)
			else:
				TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<h6(.*?)</table>',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
				if not TIkiozSLCv6werb97mHQ0q4y3: TIkiozSLCv6werb97mHQ0q4y3 = [flARjI3NM9CQnWY1xk7]
				for ziJLDVT8NM2QcgIpmE9A in TIkiozSLCv6werb97mHQ0q4y3:
					name = ''
					items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(http.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
					for ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
						vMSQsdJ0gCrh7ztnR96yDXqOYaj = '&&' + ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('/')[2].lower() + '&&'
						vMSQsdJ0gCrh7ztnR96yDXqOYaj = vMSQsdJ0gCrh7ztnR96yDXqOYaj.replace('.com&&','').replace('.co&&','')
						vMSQsdJ0gCrh7ztnR96yDXqOYaj = vMSQsdJ0gCrh7ztnR96yDXqOYaj.replace('.net&&','').replace('.org&&','')
						vMSQsdJ0gCrh7ztnR96yDXqOYaj = vMSQsdJ0gCrh7ztnR96yDXqOYaj.replace('.live&&','').replace('.online&&','')
						vMSQsdJ0gCrh7ztnR96yDXqOYaj = vMSQsdJ0gCrh7ztnR96yDXqOYaj.replace('&&hd.','').replace('&&www.','')
						vMSQsdJ0gCrh7ztnR96yDXqOYaj = vMSQsdJ0gCrh7ztnR96yDXqOYaj.replace('&&','')
						ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R + '?named=' + name + vMSQsdJ0gCrh7ztnR96yDXqOYaj + '__download'
						jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	import JYR902sfml
	JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt(jVMHRouKgQFAESmd7B8ObTYy,r1NChsk39OMvT82YemDQnl5,'video',url)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if search=='': search = UIf35nZEj1wylmq()
	if search=='': return
	search = search.replace(' ','+')
	url = tle5V6jgvRfE + '/search?s='+search
	uyt3pAHZk4(url)
	return
# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
headers = { 'User-Agent' : '' }
r1NChsk39OMvT82YemDQnl5 = 'AKOAMCAM'
Yc0eBRLpbCkm4gK7OqyzuHwU = '_AKC_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
ZLKHfqMEUdRupD = ['مصارعة']
def HgQCVwFx2Br(mode,url,text):
	if   mode==350: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==351: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url,text)
	elif mode==352: s4Bng5iAZQSTtpDw9 = btd6ag2XYUkHixqy5J7o9RfLu1MScm(url)
	elif mode==353: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==354: s4Bng5iAZQSTtpDw9 = L1FsQxw6Afb7pcCe9Tr3qizXZ(url,'FILTERS___'+text)
	elif mode==355: s4Bng5iAZQSTtpDw9 = L1FsQxw6Afb7pcCe9Tr3qizXZ(url,'CATEGORIES___'+text)
	elif mode==356: s4Bng5iAZQSTtpDw9 = TQxvkUqc92LSiYbwMn31G(url)
	elif mode==357: s4Bng5iAZQSTtpDw9 = yGe7PnSw52zBWTFRra(url)
	elif mode==359: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	tBq8fTGUWJY9zvbgXD0EAloPO('link',Yc0eBRLpbCkm4gK7OqyzuHwU+'[COLOR FFFFFF00]هذا الموقع مغلق[/COLOR]','',8)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',359,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فلتر محدد',tle5V6jgvRfE,356)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'فلتر كامل',tle5V6jgvRfE,357)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,tle5V6jgvRfE,'',headers,'','AKOAMCAM-MENU-1st')
	M08MPGgsh4n5rKe = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('recently-container.*?href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if M08MPGgsh4n5rKe: M08MPGgsh4n5rKe = M08MPGgsh4n5rKe[0]
	else: M08MPGgsh4n5rKe = tle5V6jgvRfE
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'اضيف حديثا',M08MPGgsh4n5rKe,351)
	M08MPGgsh4n5rKe = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('@id":"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if M08MPGgsh4n5rKe: M08MPGgsh4n5rKe = M08MPGgsh4n5rKe[0]
	else: M08MPGgsh4n5rKe = tle5V6jgvRfE
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'المميزة',M08MPGgsh4n5rKe,351,'','','featured')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('main-categories-list(.*?)main-categories-list',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?class="font.*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			if title not in ZLKHfqMEUdRupD: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,351)
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="categories-box(.*?)<footer',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = nnGHa80rMphqe1ukFtIRvAPs6W(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			if title not in ZLKHfqMEUdRupD: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,351)
	return M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
def TQxvkUqc92LSiYbwMn31G(website=''):
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,tle5V6jgvRfE,'',headers,'','AKOAMCAM-MENU-1st')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="menu(.*?)<nav',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?text">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			if title not in ZLKHfqMEUdRupD:
				title = title+' مصنفة'
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,355)
		if website=='': tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
def yGe7PnSw52zBWTFRra(website=''):
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,tle5V6jgvRfE,'',headers,'','AKOAMCAM-MENU-1st')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="menu(.*?)<nav',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?text">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			if title not in ZLKHfqMEUdRupD:
				title = title+' مفلترة'
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,354)
		if website=='': tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
def uyt3pAHZk4(url,type=''):
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(MMLimtJ8xTFAq9Z012nroaju3de,url,'',headers,True,'AKOAMCAM-TITLES-1st')
	if type=='featured': TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('swiper-container(.*?)swiper-button-prev',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	else: TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="container"(.*?)main-footer',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('xlink:href="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		jjR8ftoEXpPxVF6JerbHZuzv7ic = []
		for Q2qmuDRrC9ikcaJK7gtUHXNW,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
			if 'الحلقة' in title or 'الحلقه' in title:
				EQw62xjXSJmzrRt = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(.*?) (الحلقة|الحلقه) \d+',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
				if EQw62xjXSJmzrRt:
					title = '_MOD_' + EQw62xjXSJmzrRt[0][0]
					if title not in jjR8ftoEXpPxVF6JerbHZuzv7ic:
						tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,352,Q2qmuDRrC9ikcaJK7gtUHXNW)
						jjR8ftoEXpPxVF6JerbHZuzv7ic.append(title)
			elif 'مسلسل' in title:
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,352,Q2qmuDRrC9ikcaJK7gtUHXNW)
			else: tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,353,Q2qmuDRrC9ikcaJK7gtUHXNW)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('pagination(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href=["\'](.*?)["\'].*?>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = nnGHa80rMphqe1ukFtIRvAPs6W(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,351)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if search=='': search = UIf35nZEj1wylmq()
	if search=='': return
	DbEfLQSBFCTt2mMqvrsIVnjJ6 = search.replace(' ','+')
	url = tle5V6jgvRfE + '/?s='+DbEfLQSBFCTt2mMqvrsIVnjJ6
	s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url)
	return
def btd6ag2XYUkHixqy5J7o9RfLu1MScm(url):
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(Yv7e6ixHfZIPrmMOy3ozwJu2,url,'',headers,True,'AKOAMCAM-EPISODES-1st')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('text-white">الحلقات(.*?)<header',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		MRLuZmE4OvnzohQa73cTGWNr = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(http.*?)".*?src="(.*?)".*?alt="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title in MRLuZmE4OvnzohQa73cTGWNr:
			if 'الحلقة' in title or 'الحلقه' in title: tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,353,Q2qmuDRrC9ikcaJK7gtUHXNW)
	else:
		Q2qmuDRrC9ikcaJK7gtUHXNW = oos8ymFi9CN2z1jXcR.getInfoLabel('ListItem.Icon')
		if M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2.count('<title>')>1: title = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<title>(.*?)<',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)[1]
		else: title = 'رابط التشغيل'
		tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,353,Q2qmuDRrC9ikcaJK7gtUHXNW)
	return
def dlropqS0vO9K7W4z(url):
	jVMHRouKgQFAESmd7B8ObTYy,da6IAnqQ7oV2Hx13F5gbBT4 = [],[]
	u2GonLp47A9ckIyUTMjt56l = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',url,'','','','','AKOAMCAM-PLAY-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = u2GonLp47A9ckIyUTMjt56l.content
	F6iHzDbQXWOje20AuR7t8SrlpKoIU = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('post_id=(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if F6iHzDbQXWOje20AuR7t8SrlpKoIU:
		F6iHzDbQXWOje20AuR7t8SrlpKoIU = F6iHzDbQXWOje20AuR7t8SrlpKoIU[0]
		headers = {'User-Agent':'','Content-Type':'application/x-www-form-urlencoded'}
		data = {'post_id':F6iHzDbQXWOje20AuR7t8SrlpKoIU}
		M08MPGgsh4n5rKe = tle5V6jgvRfE+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Watch.php'
		muQN5MiaEnXfPyqBxV = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'POST',M08MPGgsh4n5rKe,data,headers,'','','AKOAMCAM-PLAY-1st')
		flARjI3NM9CQnWY1xk7 = muQN5MiaEnXfPyqBxV.content
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-server="(.*?)".*?class="text">(.*?)<',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for YusKpP58ZyhOD,name in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = 'https://w.akoam.cam/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Server.php'
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?postid='+F6iHzDbQXWOje20AuR7t8SrlpKoIU+'&serverid='+YusKpP58ZyhOD+'?named='+name+'__watch'
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			da6IAnqQ7oV2Hx13F5gbBT4.append(name)
		M08MPGgsh4n5rKe = tle5V6jgvRfE+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Download.php'
		muQN5MiaEnXfPyqBxV = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'POST',M08MPGgsh4n5rKe,data,headers,'','','AKOAMCAM-PLAY-1st')
		flARjI3NM9CQnWY1xk7 = muQN5MiaEnXfPyqBxV.content
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?class="text">(.*?)<',flARjI3NM9CQnWY1xk7,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.strip(' ')
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+title+'__download'
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			da6IAnqQ7oV2Hx13F5gbBT4.append(title)
	import JYR902sfml
	JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt(jVMHRouKgQFAESmd7B8ObTYy,r1NChsk39OMvT82YemDQnl5,'video',url)
	return
def L1FsQxw6Afb7pcCe9Tr3qizXZ(url,filter):
	tpH7FYXLyz4UJdcC31OQ0Phwg = ['cat','genre','release-year','quality','orderby']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter=='': ydL2RstfT9BA3Hpe1SZIq,l3Uo4ThenPyJMua = '',''
	else: ydL2RstfT9BA3Hpe1SZIq,l3Uo4ThenPyJMua = filter.split('___')
	if type=='CATEGORIES':
		if tpH7FYXLyz4UJdcC31OQ0Phwg[0]+'=' not in ydL2RstfT9BA3Hpe1SZIq: cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = tpH7FYXLyz4UJdcC31OQ0Phwg[0]
		for AudBQkLFsrHKicIogThZyv in range(len(tpH7FYXLyz4UJdcC31OQ0Phwg[0:-1])):
			if tpH7FYXLyz4UJdcC31OQ0Phwg[AudBQkLFsrHKicIogThZyv]+'=' in ydL2RstfT9BA3Hpe1SZIq: cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = tpH7FYXLyz4UJdcC31OQ0Phwg[AudBQkLFsrHKicIogThZyv+1]
		rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&'+cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo+'=0'
		SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&'+cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo+'=0'
		hOSk91jGqtHsfwU2ExCV4YB = rrsgSnC5AFkbEvDPm6pyaRizM8.strip('&')+'___'+SWxX6Q3CgwV7F.strip('&')
		Rdgr0aTSzE5chex9W = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(l3Uo4ThenPyJMua,'all')
		M08MPGgsh4n5rKe = url+'?'+Rdgr0aTSzE5chex9W
	elif type=='FILTERS':
		jyRzHeOYXAW4oDrUS = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(ydL2RstfT9BA3Hpe1SZIq,'modified_values')
		jyRzHeOYXAW4oDrUS = BUTSkzgFC7(jyRzHeOYXAW4oDrUS)
		if l3Uo4ThenPyJMua!='': l3Uo4ThenPyJMua = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(l3Uo4ThenPyJMua,'all')
		if l3Uo4ThenPyJMua=='': M08MPGgsh4n5rKe = url
		else: M08MPGgsh4n5rKe = url+'?'+l3Uo4ThenPyJMua
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'أظهار قائمة الفيديو التي تم اختيارها',M08MPGgsh4n5rKe,351,'','1')
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+' [[   '+jyRzHeOYXAW4oDrUS+'   ]]',M08MPGgsh4n5rKe,351,'','1')
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = MQeSPGrtXET1ahZjnwVmcxfF32(xgFTDVS7lf5Us6aj,url,'',headers,True,'AKOAMCAM-FILTERS_MENU-1st')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<form id(.*?)</form>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	H8n4oVq07uvJjCOwgzbyf6XR9Fs = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	dict = {}
	for eFmOUji0173K,name,ziJLDVT8NM2QcgIpmE9A in H8n4oVq07uvJjCOwgzbyf6XR9Fs:
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<option(.*?)>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if '=' not in M08MPGgsh4n5rKe: M08MPGgsh4n5rKe = url
		if type=='CATEGORIES':
			if cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo!=eFmOUji0173K: continue
			elif len(items)<=1:
				if eFmOUji0173K==tpH7FYXLyz4UJdcC31OQ0Phwg[-1]: uyt3pAHZk4(M08MPGgsh4n5rKe)
				else: L1FsQxw6Afb7pcCe9Tr3qizXZ(M08MPGgsh4n5rKe,'CATEGORIES___'+hOSk91jGqtHsfwU2ExCV4YB)
				return
			else:
				if eFmOUji0173K==tpH7FYXLyz4UJdcC31OQ0Phwg[-1]: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع',M08MPGgsh4n5rKe,351,'','1')
				else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع',M08MPGgsh4n5rKe,355,'','',hOSk91jGqtHsfwU2ExCV4YB)
		elif type=='FILTERS':
			rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&'+eFmOUji0173K+'=0'
			SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&'+eFmOUji0173K+'=0'
			hOSk91jGqtHsfwU2ExCV4YB = rrsgSnC5AFkbEvDPm6pyaRizM8+'___'+SWxX6Q3CgwV7F
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع : '+name,M08MPGgsh4n5rKe,354,'','',hOSk91jGqtHsfwU2ExCV4YB)
		dict[eFmOUji0173K] = {}
		for hht0cpXxWw2OzFS1jnUGebkJLBd85,e0i4nPhusqdTaG in items:
			if e0i4nPhusqdTaG in ZLKHfqMEUdRupD: continue
			if 'value' not in hht0cpXxWw2OzFS1jnUGebkJLBd85: hht0cpXxWw2OzFS1jnUGebkJLBd85 = e0i4nPhusqdTaG
			else: hht0cpXxWw2OzFS1jnUGebkJLBd85 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"(.*?)"',hht0cpXxWw2OzFS1jnUGebkJLBd85,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)[0]
			dict[eFmOUji0173K][hht0cpXxWw2OzFS1jnUGebkJLBd85] = e0i4nPhusqdTaG
			rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&'+eFmOUji0173K+'='+e0i4nPhusqdTaG
			SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&'+eFmOUji0173K+'='+hht0cpXxWw2OzFS1jnUGebkJLBd85
			RtPpz8FAEjIxU = rrsgSnC5AFkbEvDPm6pyaRizM8+'___'+SWxX6Q3CgwV7F
			title = e0i4nPhusqdTaG+' : '#+dict[eFmOUji0173K]['0']
			title = e0i4nPhusqdTaG+' : '+name
			if type=='FILTERS': tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,354,'','',RtPpz8FAEjIxU)
			elif type=='CATEGORIES' and tpH7FYXLyz4UJdcC31OQ0Phwg[-2]+'=' in ydL2RstfT9BA3Hpe1SZIq:
				Rdgr0aTSzE5chex9W = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(SWxX6Q3CgwV7F,'all')
				TW6JIBgC971tjOE = url+'?'+Rdgr0aTSzE5chex9W
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,TW6JIBgC971tjOE,351,'','1')
			else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,355,'','',RtPpz8FAEjIxU)
	return
def l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(dY1a0xA6PKm7TOJSERt3sHU9Qp,mode):
	dY1a0xA6PKm7TOJSERt3sHU9Qp = dY1a0xA6PKm7TOJSERt3sHU9Qp.strip('&')
	nvNkgT7iGQOyed = {}
	if '=' in dY1a0xA6PKm7TOJSERt3sHU9Qp:
		items = dY1a0xA6PKm7TOJSERt3sHU9Qp.split('&')
		for hh4gUqS5JWf1saRZPXHD in items:
			DHcrLNnqExKjM8uvVlBhWd,hht0cpXxWw2OzFS1jnUGebkJLBd85 = hh4gUqS5JWf1saRZPXHD.split('=')
			nvNkgT7iGQOyed[DHcrLNnqExKjM8uvVlBhWd] = hht0cpXxWw2OzFS1jnUGebkJLBd85
	UJzegYmlGML35rasDAIx17Rhnk = ''
	bxa9Gj5p3oElwmngHJRKP7CtqS = ['cat','genre','release-year','quality','orderby']
	for key in bxa9Gj5p3oElwmngHJRKP7CtqS:
		if key in list(nvNkgT7iGQOyed.keys()): hht0cpXxWw2OzFS1jnUGebkJLBd85 = nvNkgT7iGQOyed[key]
		else: hht0cpXxWw2OzFS1jnUGebkJLBd85 = '0'
		if mode=='modified_values' and hht0cpXxWw2OzFS1jnUGebkJLBd85!='0': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+' + '+hht0cpXxWw2OzFS1jnUGebkJLBd85
		elif mode=='modified_filters' and hht0cpXxWw2OzFS1jnUGebkJLBd85!='0': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+'&'+key+'='+hht0cpXxWw2OzFS1jnUGebkJLBd85
		elif mode=='all': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+'&'+key+'='+hht0cpXxWw2OzFS1jnUGebkJLBd85
	UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk.strip(' + ')
	UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk.strip('&')
	return UJzegYmlGML35rasDAIx17Rhnk
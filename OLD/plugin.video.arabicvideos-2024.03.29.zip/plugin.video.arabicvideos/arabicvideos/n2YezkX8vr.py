# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'LIVETV'
tle5V6jgvRfE = mR20sONyKIlV['PYTHON'][0]
def HgQCVwFx2Br(mode,url):
	if   mode==100: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==101: s4Bng5iAZQSTtpDw9 = Hb39UqlX2fZDpc('0',True)
	elif mode==102: s4Bng5iAZQSTtpDw9 = Hb39UqlX2fZDpc('1',True)
	elif mode==103: s4Bng5iAZQSTtpDw9 = Hb39UqlX2fZDpc('2',True)
	elif mode==104: s4Bng5iAZQSTtpDw9 = Hb39UqlX2fZDpc('3',True)
	elif mode==105: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==106: s4Bng5iAZQSTtpDw9 = Hb39UqlX2fZDpc('4',True)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_M3U_'+'قوائم فيديوهات M3U','',762)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_IPT_'+'قوائم فيديوهات IPTV','',761)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_TV0_'+'قنوات من مواقعها الأصلية','',101)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_TV4_'+'قنوات مختارة من يوتيوب','',106)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_YUT_'+'قنوات عربية من يوتيوب','',147)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_YUT_'+'قنوات أجنبية من يوتيوب','',148)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ','',28)
	tBq8fTGUWJY9zvbgXD0EAloPO('live','_MRF_'+'قناة المعارف من موقعهم','',41)
	tBq8fTGUWJY9zvbgXD0EAloPO('live','_PNT_'+'قناة هلا من موقع بانيت','',38)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_TV1_'+'قنوات تلفزيونية عامة','',102)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_TV2_'+'قنوات تلفزيونية خاصة','',103)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder','_TV3_'+'قنوات تلفزيونية للفحص','',104)
	return
def Hb39UqlX2fZDpc(BYK4n5WxXhCpQ7N,showDialogs=True):
	Yc0eBRLpbCkm4gK7OqyzuHwU = '_TV'+BYK4n5WxXhCpQ7N+'_'
	gg6VwuY0xOi7 = zVw5tvmZRX(32)
	VVNkoRCUm96MbtuqgrOe = {'id':'','user':gg6VwuY0xOi7,'function':'list','menu':BYK4n5WxXhCpQ7N}
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'POST',tle5V6jgvRfE,VVNkoRCUm96MbtuqgrOe,'','','','LIVETV-ITEMS-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if items:
		for AudBQkLFsrHKicIogThZyv in range(len(items)):
			name = items[AudBQkLFsrHKicIogThZyv][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[AudBQkLFsrHKicIogThZyv] = items[AudBQkLFsrHKicIogThZyv][0],items[AudBQkLFsrHKicIogThZyv][1],items[AudBQkLFsrHKicIogThZyv][2],name,items[AudBQkLFsrHKicIogThZyv][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for dIsZG1fHm5YVkU6Puzq,vMSQsdJ0gCrh7ztnR96yDXqOYaj,gUmrWFV3dB6Q1b02wuHq5,name,Q2qmuDRrC9ikcaJK7gtUHXNW in items:
			if '#' in dIsZG1fHm5YVkU6Puzq: continue
			if dIsZG1fHm5YVkU6Puzq!='URL': name = name+'[COLOR FFC89008]   '+dIsZG1fHm5YVkU6Puzq+'[/COLOR]'
			url = dIsZG1fHm5YVkU6Puzq+';;'+vMSQsdJ0gCrh7ztnR96yDXqOYaj+';;'+gUmrWFV3dB6Q1b02wuHq5+';;'+BYK4n5WxXhCpQ7N
			tBq8fTGUWJY9zvbgXD0EAloPO('live',Yc0eBRLpbCkm4gK7OqyzuHwU+''+name,url,105,Q2qmuDRrC9ikcaJK7gtUHXNW)
	else:
		if showDialogs: tBq8fTGUWJY9zvbgXD0EAloPO('link',Yc0eBRLpbCkm4gK7OqyzuHwU+'هذه الخدمة مخصصة للمبرمج فقط','',9999)
	return
def dlropqS0vO9K7W4z(id):
	dIsZG1fHm5YVkU6Puzq,vMSQsdJ0gCrh7ztnR96yDXqOYaj,gUmrWFV3dB6Q1b02wuHq5,BYK4n5WxXhCpQ7N = id.split(';;')
	url = ''
	gg6VwuY0xOi7 = zVw5tvmZRX(32)
	if dIsZG1fHm5YVkU6Puzq=='URL': url = gUmrWFV3dB6Q1b02wuHq5
	elif dIsZG1fHm5YVkU6Puzq=='YOUTUBE':
		url = mR20sONyKIlV['YOUTUBE'][0]+'/watch?v='+gUmrWFV3dB6Q1b02wuHq5
		import JYR902sfml
		JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt([url],r1NChsk39OMvT82YemDQnl5,'live',url)
		return
	elif dIsZG1fHm5YVkU6Puzq=='GA':
		VVNkoRCUm96MbtuqgrOe = { 'id' : '', 'user' : gg6VwuY0xOi7 , 'function' : 'playGA1' , 'menu' : '' }
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',tle5V6jgvRfE,VVNkoRCUm96MbtuqgrOe,'',False,'','LIVETV-PLAY-1st')
		if not aQniqUlZk8.succeeded:
			tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		cookies = aQniqUlZk8.cookies
		vxSy1RusNhQ7zoTiF = cookies['ASP.NET_SessionId']
		url = aQniqUlZk8.headers['Location']
		VVNkoRCUm96MbtuqgrOe = { 'id' : gUmrWFV3dB6Q1b02wuHq5 , 'user' : gg6VwuY0xOi7 , 'function' : 'playGA2' , 'menu' : '' }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+vxSy1RusNhQ7zoTiF }
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',tle5V6jgvRfE,VVNkoRCUm96MbtuqgrOe,headers,'','','LIVETV-PLAY-2nd')
		if not aQniqUlZk8.succeeded:
			tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		url = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('resp":"(http.*?m3u8)(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = url[0][0]
		FT0SbzeQHD = url[0][1]
		nnRmh3TECbDz81rtM7OP0 = 'http://38.'+vMSQsdJ0gCrh7ztnR96yDXqOYaj+'777/'+gUmrWFV3dB6Q1b02wuHq5+'_HD.m3u8'+FT0SbzeQHD
		SSLn1YjuKUPopTI5wtHsb = nnRmh3TECbDz81rtM7OP0.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		H8vMrN2zYRnCf3U4A5BT0d7 = nnRmh3TECbDz81rtM7OP0.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		da6IAnqQ7oV2Hx13F5gbBT4 = ['HD','SD1','SD2']
		jVMHRouKgQFAESmd7B8ObTYy = [nnRmh3TECbDz81rtM7OP0,SSLn1YjuKUPopTI5wtHsb,H8vMrN2zYRnCf3U4A5BT0d7]
		NljOosKT8WJBpch = 0
		if NljOosKT8WJBpch == -1: return
		else: url = jVMHRouKgQFAESmd7B8ObTYy[NljOosKT8WJBpch]
	elif dIsZG1fHm5YVkU6Puzq=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		VVNkoRCUm96MbtuqgrOe = { 'id' : gUmrWFV3dB6Q1b02wuHq5 , 'user' : gg6VwuY0xOi7 , 'function' : 'playNT' , 'menu' : BYK4n5WxXhCpQ7N }
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'POST', tle5V6jgvRfE, VVNkoRCUm96MbtuqgrOe, headers, False,'','LIVETV-PLAY-3rd')
		if not aQniqUlZk8.succeeded:
			tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		url = aQniqUlZk8.headers['Location']
		url = url.replace('%20',' ')
		url = url.replace('%3D','=')
		if 'Learn' in gUmrWFV3dB6Q1b02wuHq5:
			url = url.replace('NTNNile','')
			url = url.replace('learning1','Learning')
	elif dIsZG1fHm5YVkU6Puzq=='PL':
		VVNkoRCUm96MbtuqgrOe = { 'id' : gUmrWFV3dB6Q1b02wuHq5 , 'user' : gg6VwuY0xOi7 , 'function' : 'playPL' , 'menu' : BYK4n5WxXhCpQ7N }
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'POST', tle5V6jgvRfE, VVNkoRCUm96MbtuqgrOe, '',False,'','LIVETV-PLAY-4th')
		if not aQniqUlZk8.succeeded:
			tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		url = aQniqUlZk8.headers['Location']
		headers = {'Referer':aQniqUlZk8.headers['Referer']}
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,'POST',url, '',headers , '','','LIVETV-PLAY-5th')
		if not aQniqUlZk8.succeeded:
			tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('source src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		url = items[0]
	elif dIsZG1fHm5YVkU6Puzq in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if dIsZG1fHm5YVkU6Puzq=='TA': gUmrWFV3dB6Q1b02wuHq5 = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		VVNkoRCUm96MbtuqgrOe = { 'id' : gUmrWFV3dB6Q1b02wuHq5 , 'user' : gg6VwuY0xOi7 , 'function' : 'play'+dIsZG1fHm5YVkU6Puzq , 'menu' : BYK4n5WxXhCpQ7N }
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'POST',tle5V6jgvRfE,VVNkoRCUm96MbtuqgrOe,headers,'','','LIVETV-PLAY-6th')
		if not aQniqUlZk8.succeeded:
			tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		url = aQniqUlZk8.headers['Location']
		if dIsZG1fHm5YVkU6Puzq=='FM':
			aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,'GET', url, '', '', False,'','LIVETV-PLAY-7th')
			url = aQniqUlZk8.headers['Location']
			url = url.replace('https','http')
	pSAuLjYqhgc9brWFKs7Pa4J(url,r1NChsk39OMvT82YemDQnl5,'live')
	return
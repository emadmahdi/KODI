# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'CIMACLUB'
Yc0eBRLpbCkm4gK7OqyzuHwU = '_CCB_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
ZLKHfqMEUdRupD = ['عروض المصارعه','للكبار فقط +18','الرئيسية','افلام للكبار فقط','DMCA']
def HgQCVwFx2Br(mode,url,tsMKaFVh1ZN2BIXEcvTejxR5DP,text):
	if   mode==820: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==821: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url,tsMKaFVh1ZN2BIXEcvTejxR5DP)
	elif mode==822: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==823: s4Bng5iAZQSTtpDw9 = q68qDOIufmz7LCRdaBNFiW(url,text)
	elif mode==824: s4Bng5iAZQSTtpDw9 = L1FsQxw6Afb7pcCe9Tr3qizXZ(url,'FULL_FILTER___'+text)
	elif mode==825: s4Bng5iAZQSTtpDw9 = L1FsQxw6Afb7pcCe9Tr3qizXZ(url,'DEFINED_FILTER___'+text)
	elif mode==829: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',tle5V6jgvRfE,'','','','','CIMACLUB-MENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	vMSQsdJ0gCrh7ztnR96yDXqOYaj = aQniqUlZk8.url
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع',vMSQsdJ0gCrh7ztnR96yDXqOYaj,829,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+'المميزة',vMSQsdJ0gCrh7ztnR96yDXqOYaj+'/sliderhome.php',821,'','featured','_REMEMBERRESULTS_')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"Tabs"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('get="(.*?)".*?<span>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for data,title in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = vMSQsdJ0gCrh7ztnR96yDXqOYaj+'/getposts?type=one&data='+data
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,821,'','highest')
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('navigation-menu(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			if '/' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: continue
			if title in ZLKHfqMEUdRupD: continue
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = vMSQsdJ0gCrh7ztnR96yDXqOYaj+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,821)
	return
def uyt3pAHZk4(url,type=''):
	vMSQsdJ0gCrh7ztnR96yDXqOYaj = SLMTm6RQ34ic7v5s9rBG(url,'url')
	ziJLDVT8NM2QcgIpmE9A,items = '',[]
	if type=='featured':
		headers = {'Content-Type':'application/x-www-form-urlencoded'}
		VVNkoRCUm96MbtuqgrOe = 'get'
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'POST',url,VVNkoRCUm96MbtuqgrOe,headers,'','','CIMACLUB-TITLES-1st')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"image":"(.*?)".*?"title":"(.*?)".*?"url":"(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		yEvJL1VHPBwp4iUGaDTA9hWdCk,GReTJrIxo2dzbapy,cc0O1M4e5jtfoq = zip(*items)
		items = zip(cc0O1M4e5jtfoq,yEvJL1VHPBwp4iUGaDTA9hWdCk,GReTJrIxo2dzbapy)
	elif type=='highest':
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','CIMACLUB-TITLES-2nd')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	else:
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','CIMACLUB-TITLES-3rd')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('media-block(.*?)footer-menu',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3: ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	if not ziJLDVT8NM2QcgIpmE9A: ziJLDVT8NM2QcgIpmE9A = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
	if not items: items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('content-box.*?href="(.*?)".*?src="(.*?)".*?<h3>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	JKk2cBlnsPjuNzHXyamGiZOTR5I = []
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title in items:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = vMSQsdJ0gCrh7ztnR96yDXqOYaj+ZCimQhV5lovgspAYzHq1Ef27u8ja4R.replace('\/','/')
		Q2qmuDRrC9ikcaJK7gtUHXNW = Q2qmuDRrC9ikcaJK7gtUHXNW.replace('\/','/')
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = zKGXT5sJeRq(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
		title = zKGXT5sJeRq(title)
		if '/episode/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
			Xt1ErNwZWQBHvC5mhKo = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(.*?) (موسم|الموسم)',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if Xt1ErNwZWQBHvC5mhKo: title = Xt1ErNwZWQBHvC5mhKo[0][0]
			else:
				EQw62xjXSJmzrRt = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(.*?) (حلقة|الحلقة)',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
				if EQw62xjXSJmzrRt: title = EQw62xjXSJmzrRt[0][0]
			if title in JKk2cBlnsPjuNzHXyamGiZOTR5I: continue
			JKk2cBlnsPjuNzHXyamGiZOTR5I.append(title)
			title = '_MOD_'+title.strip(' – ')
		if '/episodes' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,821,Q2qmuDRrC9ikcaJK7gtUHXNW)
		elif '/seasons' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,821,Q2qmuDRrC9ikcaJK7gtUHXNW)
		elif '/serie/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,823,Q2qmuDRrC9ikcaJK7gtUHXNW)
		elif '/anime-serie/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,823,Q2qmuDRrC9ikcaJK7gtUHXNW)
		elif '/season/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,823,Q2qmuDRrC9ikcaJK7gtUHXNW)
		elif '/episode/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,823,Q2qmuDRrC9ikcaJK7gtUHXNW)
		else: tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,822,Q2qmuDRrC9ikcaJK7gtUHXNW)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('pagination(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = vMSQsdJ0gCrh7ztnR96yDXqOYaj+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			if title: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,821)
	return
def q68qDOIufmz7LCRdaBNFiW(url,aS2RYLwdgkBue5t7HPs9VMf):
	vMSQsdJ0gCrh7ztnR96yDXqOYaj = SLMTm6RQ34ic7v5s9rBG(url,'url')
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','CIMACLUB-SEASONS_EPISODES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	Q2qmuDRrC9ikcaJK7gtUHXNW = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('poster-image.*?src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	Q2qmuDRrC9ikcaJK7gtUHXNW = Q2qmuDRrC9ikcaJK7gtUHXNW[0] if Q2qmuDRrC9ikcaJK7gtUHXNW else ''
	items = []
	if not aS2RYLwdgkBue5t7HPs9VMf:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"Seasons"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3:
			ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<li.*?data-season="(.*?)" data-S="(.*?)" data-B="(.*?)".*?title="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if len(items)>1:
				for aS2RYLwdgkBue5t7HPs9VMf,Y9Mlf16P5XkjAJxK80m,TUO4GqmDHS3B,title in items:
					title = title.replace('  ',' ')
					ZCimQhV5lovgspAYzHq1Ef27u8ja4R = vMSQsdJ0gCrh7ztnR96yDXqOYaj+'/ajaxCenter?_action=GetSeasonEp&_season='+aS2RYLwdgkBue5t7HPs9VMf+'&_S='+Y9Mlf16P5XkjAJxK80m+'&_B='+TUO4GqmDHS3B
					tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,823,Q2qmuDRrC9ikcaJK7gtUHXNW,'',aS2RYLwdgkBue5t7HPs9VMf)
	if len(items)<2:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"Episodes selected"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3: aaiO9BzAIMX,ziJLDVT8NM2QcgIpmE9A = '',TIkiozSLCv6werb97mHQ0q4y3[0]
		else: aaiO9BzAIMX,ziJLDVT8NM2QcgIpmE9A = 'موسم '+aS2RYLwdgkBue5t7HPs9VMf,M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)" title="(.*?)"><em>(.*?)</em>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title,EQw62xjXSJmzrRt in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = vMSQsdJ0gCrh7ztnR96yDXqOYaj+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			title = aaiO9BzAIMX+' حلقة '+EQw62xjXSJmzrRt.strip(' ')
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,822,Q2qmuDRrC9ikcaJK7gtUHXNW)
	return
def dlropqS0vO9K7W4z(url):
	url = url.replace('/episode/','/watch/').replace('/anime/','/watch/').replace('/movie/','/watch/')
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','CIMACLUB-PLAY-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	zcBjFq4VQlp20ZekGO,C3WJ0MpKcdrw6fjLT7SU5h2klVNu = [],[]
	ZCimQhV5lovgspAYzHq1Ef27u8ja4R = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('player-wraper.*?src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R[0]
		C3WJ0MpKcdrw6fjLT7SU5h2klVNu.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
		vMSQsdJ0gCrh7ztnR96yDXqOYaj = SLMTm6RQ34ic7v5s9rBG(ZCimQhV5lovgspAYzHq1Ef27u8ja4R,'name')
		zcBjFq4VQlp20ZekGO.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+vMSQsdJ0gCrh7ztnR96yDXqOYaj+'__embed')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('servers-tabs(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-embedd="(.*?)".*?<em>(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('&img=',1)[0]
			title = title.strip(' ')
			if ZCimQhV5lovgspAYzHq1Ef27u8ja4R not in C3WJ0MpKcdrw6fjLT7SU5h2klVNu:
				C3WJ0MpKcdrw6fjLT7SU5h2klVNu.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
				zcBjFq4VQlp20ZekGO.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+title+'__watch')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('download-block.*?href="(.*?)".*?<h3>(.*?)</h3>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		if ZCimQhV5lovgspAYzHq1Ef27u8ja4R not in C3WJ0MpKcdrw6fjLT7SU5h2klVNu:
			C3WJ0MpKcdrw6fjLT7SU5h2klVNu.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			title = title.replace('<span>',' ').replace('</span>','').replace('<i>','').replace('</i>',' ')
			title = title.strip(' ')
			zcBjFq4VQlp20ZekGO.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+title+'__download')
	import JYR902sfml
	JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt(zcBjFq4VQlp20ZekGO,r1NChsk39OMvT82YemDQnl5,'video',url)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if not search: search = UIf35nZEj1wylmq()
	if not search: return
	search = search.replace(' ','+')
	url = tle5V6jgvRfE+'/search?s='+search
	uyt3pAHZk4(url,'search')
	return
def UdqXh8aClcxJAEVSFKy9PnjuGW(url):
	url = url.split('/smartemadfilter?')[0]
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',url,'','','','','CIMACLUB-GET_FILTERS_BLOCKS-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	H8n4oVq07uvJjCOwgzbyf6XR9Fs = []
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('advanced-search(.*?)</form>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		H8n4oVq07uvJjCOwgzbyf6XR9Fs = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('select-menu">.*?">(.*?)<.*?data-tax="(.*?)"(.*?)</ul>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		If9vObmXl3iaWRxVjnQ4P,n1JT0Ec8K2,cz4e6sNTj53E09xtaArJLKDg = zip(*H8n4oVq07uvJjCOwgzbyf6XR9Fs)
		H8n4oVq07uvJjCOwgzbyf6XR9Fs = zip(If9vObmXl3iaWRxVjnQ4P,n1JT0Ec8K2,cz4e6sNTj53E09xtaArJLKDg)
	return H8n4oVq07uvJjCOwgzbyf6XR9Fs
def HOgJ4cadx6GAE(ziJLDVT8NM2QcgIpmE9A):
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('cat="(.*?)".*?bold">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	return items
def ugZB7sRewr9hnTFHkiAND4vp6jSyf(url):
	vMSQsdJ0gCrh7ztnR96yDXqOYaj = SLMTm6RQ34ic7v5s9rBG(url,'url')
	if '/smartemadfilter?' in url:
		url,dY1a0xA6PKm7TOJSERt3sHU9Qp = url.split('/smartemadfilter?')
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R = vMSQsdJ0gCrh7ztnR96yDXqOYaj+'/getposts?'+dY1a0xA6PKm7TOJSERt3sHU9Qp
	else: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = vMSQsdJ0gCrh7ztnR96yDXqOYaj
	return ZCimQhV5lovgspAYzHq1Ef27u8ja4R
MvZk1lBHtq45 = ['category','release-year','genre','quality']
LJpvBwZAWD2cntfuUrexGzQ0goN = ['category','release-year','genre']
def L1FsQxw6Afb7pcCe9Tr3qizXZ(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': ydL2RstfT9BA3Hpe1SZIq,l3Uo4ThenPyJMua = '',''
	else: ydL2RstfT9BA3Hpe1SZIq,l3Uo4ThenPyJMua = filter.split('___')
	if type=='DEFINED_FILTER':
		if LJpvBwZAWD2cntfuUrexGzQ0goN[0]+'=' not in ydL2RstfT9BA3Hpe1SZIq: cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = LJpvBwZAWD2cntfuUrexGzQ0goN[0]
		for AudBQkLFsrHKicIogThZyv in range(len(LJpvBwZAWD2cntfuUrexGzQ0goN[0:-1])):
			if LJpvBwZAWD2cntfuUrexGzQ0goN[AudBQkLFsrHKicIogThZyv]+'=' in ydL2RstfT9BA3Hpe1SZIq: cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo = LJpvBwZAWD2cntfuUrexGzQ0goN[AudBQkLFsrHKicIogThZyv+1]
		rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&'+cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo+'=0'
		SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&'+cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo+'=0'
		hOSk91jGqtHsfwU2ExCV4YB = rrsgSnC5AFkbEvDPm6pyaRizM8.strip('&')+'___'+SWxX6Q3CgwV7F.strip('&')
		Rdgr0aTSzE5chex9W = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(l3Uo4ThenPyJMua,'modified_filters')
		M08MPGgsh4n5rKe = url+'/smartemadfilter?'+Rdgr0aTSzE5chex9W
	elif type=='FULL_FILTER':
		jyRzHeOYXAW4oDrUS = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(ydL2RstfT9BA3Hpe1SZIq,'modified_values')
		jyRzHeOYXAW4oDrUS = BUTSkzgFC7(jyRzHeOYXAW4oDrUS)
		if l3Uo4ThenPyJMua: l3Uo4ThenPyJMua = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(l3Uo4ThenPyJMua,'modified_filters')
		if not l3Uo4ThenPyJMua: M08MPGgsh4n5rKe = url
		else: M08MPGgsh4n5rKe = url+'/smartemadfilter?'+l3Uo4ThenPyJMua
		TW6JIBgC971tjOE = ugZB7sRewr9hnTFHkiAND4vp6jSyf(M08MPGgsh4n5rKe)
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'أظهار قائمة الفيديو التي تم اختيارها ',TW6JIBgC971tjOE,821,'','filter')
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+' [[   '+jyRzHeOYXAW4oDrUS+'   ]]',TW6JIBgC971tjOE,821,'','filter')
		tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	H8n4oVq07uvJjCOwgzbyf6XR9Fs = UdqXh8aClcxJAEVSFKy9PnjuGW(url)
	dict = {}
	for name,eFmOUji0173K,ziJLDVT8NM2QcgIpmE9A in H8n4oVq07uvJjCOwgzbyf6XR9Fs:
		name = name.replace('كل ','')
		items = HOgJ4cadx6GAE(ziJLDVT8NM2QcgIpmE9A)
		if '=' not in M08MPGgsh4n5rKe: M08MPGgsh4n5rKe = url
		if type=='DEFINED_FILTER':
			if cQGjuqiUBa4ET7v10ZIrWdm2zwJMxo!=eFmOUji0173K: continue
			elif len(items)<2:
				if eFmOUji0173K==LJpvBwZAWD2cntfuUrexGzQ0goN[-1]:
					TW6JIBgC971tjOE = ugZB7sRewr9hnTFHkiAND4vp6jSyf(M08MPGgsh4n5rKe)
					uyt3pAHZk4(TW6JIBgC971tjOE,'filter')
				else: L1FsQxw6Afb7pcCe9Tr3qizXZ(M08MPGgsh4n5rKe,'DEFINED_FILTER___'+hOSk91jGqtHsfwU2ExCV4YB)
				return
			else:
				if eFmOUji0173K==LJpvBwZAWD2cntfuUrexGzQ0goN[-1]:
					TW6JIBgC971tjOE = ugZB7sRewr9hnTFHkiAND4vp6jSyf(M08MPGgsh4n5rKe)
					tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع ',TW6JIBgC971tjOE,821,'','filter')
				else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع ',M08MPGgsh4n5rKe,825,'','',hOSk91jGqtHsfwU2ExCV4YB)
		elif type=='FULL_FILTER':
			rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&'+eFmOUji0173K+'=0'
			SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&'+eFmOUji0173K+'=0'
			hOSk91jGqtHsfwU2ExCV4YB = rrsgSnC5AFkbEvDPm6pyaRizM8+'___'+SWxX6Q3CgwV7F
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'الجميع :'+name,M08MPGgsh4n5rKe,824,'','',hOSk91jGqtHsfwU2ExCV4YB)
		dict[eFmOUji0173K] = {}
		for hht0cpXxWw2OzFS1jnUGebkJLBd85,e0i4nPhusqdTaG in items:
			if not hht0cpXxWw2OzFS1jnUGebkJLBd85: continue
			if e0i4nPhusqdTaG in ZLKHfqMEUdRupD: continue
			dict[eFmOUji0173K][hht0cpXxWw2OzFS1jnUGebkJLBd85] = e0i4nPhusqdTaG
			rrsgSnC5AFkbEvDPm6pyaRizM8 = ydL2RstfT9BA3Hpe1SZIq+'&'+eFmOUji0173K+'='+e0i4nPhusqdTaG
			SWxX6Q3CgwV7F = l3Uo4ThenPyJMua+'&'+eFmOUji0173K+'='+hht0cpXxWw2OzFS1jnUGebkJLBd85
			RtPpz8FAEjIxU = rrsgSnC5AFkbEvDPm6pyaRizM8+'___'+SWxX6Q3CgwV7F
			title = e0i4nPhusqdTaG+' :'#+dict[eFmOUji0173K]['0']
			title = e0i4nPhusqdTaG+' :'+name
			if type=='FULL_FILTER': tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,824,'','',RtPpz8FAEjIxU)
			elif type=='DEFINED_FILTER' and LJpvBwZAWD2cntfuUrexGzQ0goN[-2]+'=' in ydL2RstfT9BA3Hpe1SZIq:
				Rdgr0aTSzE5chex9W = l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(SWxX6Q3CgwV7F,'modified_filters')
				M08MPGgsh4n5rKe = url+'/smartemadfilter?'+Rdgr0aTSzE5chex9W
				TW6JIBgC971tjOE = ugZB7sRewr9hnTFHkiAND4vp6jSyf(M08MPGgsh4n5rKe)
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,TW6JIBgC971tjOE,821,'','filter')
			else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,825,'','',RtPpz8FAEjIxU)
	return
def l1NrAwKQIuTaSb38cV4Eq6DtPk7e2o(dY1a0xA6PKm7TOJSERt3sHU9Qp,mode):
	dY1a0xA6PKm7TOJSERt3sHU9Qp = dY1a0xA6PKm7TOJSERt3sHU9Qp.replace('=&','=0&')
	dY1a0xA6PKm7TOJSERt3sHU9Qp = dY1a0xA6PKm7TOJSERt3sHU9Qp.strip('&')
	nvNkgT7iGQOyed = {}
	if '=' in dY1a0xA6PKm7TOJSERt3sHU9Qp:
		items = dY1a0xA6PKm7TOJSERt3sHU9Qp.split('&')
		for hh4gUqS5JWf1saRZPXHD in items:
			DHcrLNnqExKjM8uvVlBhWd,hht0cpXxWw2OzFS1jnUGebkJLBd85 = hh4gUqS5JWf1saRZPXHD.split('=')
			nvNkgT7iGQOyed[DHcrLNnqExKjM8uvVlBhWd] = hht0cpXxWw2OzFS1jnUGebkJLBd85
	UJzegYmlGML35rasDAIx17Rhnk = ''
	for key in MvZk1lBHtq45:
		if key in list(nvNkgT7iGQOyed.keys()): hht0cpXxWw2OzFS1jnUGebkJLBd85 = nvNkgT7iGQOyed[key]
		else: hht0cpXxWw2OzFS1jnUGebkJLBd85 = '0'
		if '%' not in hht0cpXxWw2OzFS1jnUGebkJLBd85: hht0cpXxWw2OzFS1jnUGebkJLBd85 = TaEr2nR3f5e8oXzpy(hht0cpXxWw2OzFS1jnUGebkJLBd85)
		if mode=='modified_values' and hht0cpXxWw2OzFS1jnUGebkJLBd85!='0': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+' + '+hht0cpXxWw2OzFS1jnUGebkJLBd85
		elif mode=='modified_filters' and hht0cpXxWw2OzFS1jnUGebkJLBd85!='0': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+'&'+key+'='+hht0cpXxWw2OzFS1jnUGebkJLBd85
		elif mode=='all': UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk+'&'+key+'='+hht0cpXxWw2OzFS1jnUGebkJLBd85
	UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk.strip(' + ')
	UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk.strip('&')
	UJzegYmlGML35rasDAIx17Rhnk = UJzegYmlGML35rasDAIx17Rhnk.replace('=0','=')
	return UJzegYmlGML35rasDAIx17Rhnk
# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'FASELHD1'
headers = {'User-Agent':''}
Yc0eBRLpbCkm4gK7OqyzuHwU = '_FH1_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
ZLKHfqMEUdRupD = ['جوائز الأوسكار','المراجعات','wwe']
def HgQCVwFx2Br(mode,url,text):
	if   mode==570: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==571: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url,text)
	elif mode==572: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==573: s4Bng5iAZQSTtpDw9 = q68qDOIufmz7LCRdaBNFiW(url,text)
	elif mode==576: s4Bng5iAZQSTtpDw9 = ttJs4gyMSxaXnfY0pZ5olwrWumvDO()
	elif mode==579: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	tBq8fTGUWJY9zvbgXD0EAloPO('link',Yc0eBRLpbCkm4gK7OqyzuHwU+'لماذا الموقع بطيء','',576)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	dkgwyUKEpTtPeMxs68aib,url,aQniqUlZk8 = n4shroLZX1NF5yAzVqtJWGk(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',tle5V6jgvRfE,'faselhd1','فاصل إعلاني','dubbed-movies')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع',dkgwyUKEpTtPeMxs68aib,579,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'المميزة',dkgwyUKEpTtPeMxs68aib,571,'','','featured1')
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="h3">(.*?)<.*?href="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not items:
		tehb3k5a2PufGOdBIUw8j('','','موقع فاصل الأول','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	for title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,571,'','','details1')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"menu-primary"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		Abf1DcCavklrtUXiN70wTeoSWYK = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<li (.*?)</li>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		DkKbsdfSBXhcmyJMpoY3RvjwxiL86t = ['','أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		Deiz7ocWQjVnIg = 0
		for BYK4n5WxXhCpQ7N in Abf1DcCavklrtUXiN70wTeoSWYK:
			if Deiz7ocWQjVnIg>0: tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?>(.*?)<',BYK4n5WxXhCpQ7N,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
				if ZCimQhV5lovgspAYzHq1Ef27u8ja4R=='#': continue
				if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = dkgwyUKEpTtPeMxs68aib+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
				if title=='': continue
				if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title.lower() for hht0cpXxWw2OzFS1jnUGebkJLBd85 in ZLKHfqMEUdRupD): continue
				title = DkKbsdfSBXhcmyJMpoY3RvjwxiL86t[Deiz7ocWQjVnIg]+title
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,571,'','','details2')
			Deiz7ocWQjVnIg += 1
	return
def ttJs4gyMSxaXnfY0pZ5olwrWumvDO():
	tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def uyt3pAHZk4(url,type=''):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','FASELHD1-TITLES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	rNQC9lGIxW3d0oB6AjUfD5LbRF = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="h4">(.*?)</div>(.*?)"container"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if not rNQC9lGIxW3d0oB6AjUfD5LbRF: return
	if type=='filters':
		TIkiozSLCv6werb97mHQ0q4y3 = [M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"homeSlide"(.*?)"container"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		PojQU9ySuCMbW,cc0O1M4e5jtfoq,GReTJrIxo2dzbapy = zip(*items)
		items = zip(cc0O1M4e5jtfoq,PojQU9ySuCMbW,GReTJrIxo2dzbapy)
	elif type=='featured2':
		title,ziJLDVT8NM2QcgIpmE9A = rNQC9lGIxW3d0oB6AjUfD5LbRF[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	elif type=='details2' and len(rNQC9lGIxW3d0oB6AjUfD5LbRF)>1:
		title = rNQC9lGIxW3d0oB6AjUfD5LbRF[0][0]
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,571,'','','featured2')
		title = rNQC9lGIxW3d0oB6AjUfD5LbRF[1][0]
		tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,url,571,'','','details3')
		return
	else:
		title,ziJLDVT8NM2QcgIpmE9A = rNQC9lGIxW3d0oB6AjUfD5LbRF[-1]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	jjR8ftoEXpPxVF6JerbHZuzv7ic = []
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title in items:
		if any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title.lower() for hht0cpXxWw2OzFS1jnUGebkJLBd85 in ZLKHfqMEUdRupD): continue
		Q2qmuDRrC9ikcaJK7gtUHXNW = zKGXT5sJeRq(Q2qmuDRrC9ikcaJK7gtUHXNW)
		Q2qmuDRrC9ikcaJK7gtUHXNW = Q2qmuDRrC9ikcaJK7gtUHXNW.split('?resize=')[0]
		title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
		EQw62xjXSJmzrRt = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(.*?) (الحلقة|حلقة).\d+',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if '/collections/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,571,Q2qmuDRrC9ikcaJK7gtUHXNW)
		elif EQw62xjXSJmzrRt and type=='':
			title = '_MOD_'+EQw62xjXSJmzrRt[0][0]
			title = title.strip(' –')
			if title not in jjR8ftoEXpPxVF6JerbHZuzv7ic:
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,573,Q2qmuDRrC9ikcaJK7gtUHXNW)
				jjR8ftoEXpPxVF6JerbHZuzv7ic.append(title)
		elif 'episodes/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R or 'movies/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R or 'hindi/' in ZCimQhV5lovgspAYzHq1Ef27u8ja4R:
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,572,Q2qmuDRrC9ikcaJK7gtUHXNW)
		else: tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,573,Q2qmuDRrC9ikcaJK7gtUHXNW)
	if type=='filters':
		SSgRAKD3NBqJ97ojTnL5kpFafHdU = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"more_button_page":(.*?),',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if SSgRAKD3NBqJ97ojTnL5kpFafHdU:
			count = SSgRAKD3NBqJ97ojTnL5kpFafHdU[0]
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = url+'/offset/'+count
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة أخرى',ZCimQhV5lovgspAYzHq1Ef27u8ja4R,571,'','','filters')
	elif 'details' in type:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("class='pagination(.*?)</div>",M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3:
			ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("href='(.*?)'.*?>(.*?)<",ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
				title = 'صفحة '+nnGHa80rMphqe1ukFtIRvAPs6W(title)
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,571,'','','details4')
	return
def q68qDOIufmz7LCRdaBNFiW(url,type=''):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','FASELHD1-SEASONS_EPISODES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	jnfvCpH4PRD3r2BNsc96TAdQoeZ = False
	if not type:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"seasonList"(.*?)"container"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3:
			ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if len(items)>1:
				dkgwyUKEpTtPeMxs68aib = SLMTm6RQ34ic7v5s9rBG(url,'url')
				jnfvCpH4PRD3r2BNsc96TAdQoeZ = True
				for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,name,title in items:
					name = nnGHa80rMphqe1ukFtIRvAPs6W(name)
					if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = dkgwyUKEpTtPeMxs68aib+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
					title = name+' - '+title
					tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,573,Q2qmuDRrC9ikcaJK7gtUHXNW,'','episodes')
	if type=='episodes' or not jnfvCpH4PRD3r2BNsc96TAdQoeZ:
		OHMhVx5cw76slynUDdF24jgbkNG = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"posterImg".*?src="(.*?)"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if OHMhVx5cw76slynUDdF24jgbkNG: Q2qmuDRrC9ikcaJK7gtUHXNW = OHMhVx5cw76slynUDdF24jgbkNG[0]
		else: Q2qmuDRrC9ikcaJK7gtUHXNW = ''
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"epAll"(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if TIkiozSLCv6werb97mHQ0q4y3:
			ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?>(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
				title = title.strip(' ')
				title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
				tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,572,Q2qmuDRrC9ikcaJK7gtUHXNW)
	return
def dlropqS0vO9K7W4z(url):
	zcBjFq4VQlp20ZekGO,zQKxjEJWXoUw,fnB1sGSRlHaeu = [],[],[]
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',url,'','','','','FASELHD1-PLAY-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	dHeVQ1fBl7Zih2 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('مستوى المشاهدة.*?">(.*?)</span>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if dHeVQ1fBl7Zih2:
		VnK1wPrcHoN8ex2Bl0pLS = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"tag">(.*?)</a>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if VnK1wPrcHoN8ex2Bl0pLS and Y1Yz6bZMLDaGjpxK3fSXm7TurCnHwo(r1NChsk39OMvT82YemDQnl5,url,VnK1wPrcHoN8ex2Bl0pLS): return
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"videoRow"(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('src="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('&img=')[0]
			zcBjFq4VQlp20ZekGO.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named=__embed')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="streamHeader(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall("href = '(.*?)'.*?</i>(.*?)</a>",ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,name in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('&img=')[0]
			name = name.strip(' ')
			zcBjFq4VQlp20ZekGO.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+name+'__watch')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('class="downloadLinks(.*?)blackwindow',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?</span>(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,name in items:
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('&img=')[0]
			zcBjFq4VQlp20ZekGO.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+name+'__download')
	for P8XCKZhtcNqS in zcBjFq4VQlp20ZekGO:
		ZCimQhV5lovgspAYzHq1Ef27u8ja4R,name = P8XCKZhtcNqS.split('?named')
		if ZCimQhV5lovgspAYzHq1Ef27u8ja4R not in zQKxjEJWXoUw:
			zQKxjEJWXoUw.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
			fnB1sGSRlHaeu.append(P8XCKZhtcNqS)
	import JYR902sfml
	JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt(fnB1sGSRlHaeu,r1NChsk39OMvT82YemDQnl5,'video',url)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if search=='': search = UIf35nZEj1wylmq()
	if search=='': return
	search = search.replace(' ','+')
	url = tle5V6jgvRfE+'/?s='+search
	dkgwyUKEpTtPeMxs68aib,M08MPGgsh4n5rKe,WcPEG7nehsCwig809NyHMZ = n4shroLZX1NF5yAzVqtJWGk(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'faselhd1','فاصل إعلاني','dubbed-movies')
	uyt3pAHZk4(M08MPGgsh4n5rKe,'details5')
	return
# -*- coding: utf-8 -*-
import sys as EAPND6zHKrMRuBc91tInYohsl0ywa
ttRJUcM0Tbr7gXN5x = EAPND6zHKrMRuBc91tInYohsl0ywa.version_info [0] == 2
Z2h7adALoKv4UPc1y = 2048
K2KPeD6VyEaQ = 7
def dC3HqaFgt6QYG4 (jZYXLbSUsQp5uk1tyzBAN7Hm):
	global ZeIJ6GDodMSzFut4jc05AK3OlhETR
	HY5UkLeNComBIMQPASnxph7 = ord (jZYXLbSUsQp5uk1tyzBAN7Hm [-1])
	PlVdbOK5hqks = jZYXLbSUsQp5uk1tyzBAN7Hm [:-1]
	prvC9qsF5RtBXHiaT3PwdJ = HY5UkLeNComBIMQPASnxph7 % len (PlVdbOK5hqks)
	LQB6POHcivdw87pk09ts2XMyf1IVEh = PlVdbOK5hqks [:prvC9qsF5RtBXHiaT3PwdJ] + PlVdbOK5hqks [prvC9qsF5RtBXHiaT3PwdJ:]
	if ttRJUcM0Tbr7gXN5x:
		Gn0XReKiJFMEsUxN531yAlI7S = unicode () .join ([unichr (ord (AitBMapzjZGc4u) - Z2h7adALoKv4UPc1y - (KQsX4n7jEogiLuJz + HY5UkLeNComBIMQPASnxph7) % K2KPeD6VyEaQ) for KQsX4n7jEogiLuJz, AitBMapzjZGc4u in enumerate (LQB6POHcivdw87pk09ts2XMyf1IVEh)])
	else:
		Gn0XReKiJFMEsUxN531yAlI7S = str () .join ([chr (ord (AitBMapzjZGc4u) - Z2h7adALoKv4UPc1y - (KQsX4n7jEogiLuJz + HY5UkLeNComBIMQPASnxph7) % K2KPeD6VyEaQ) for KQsX4n7jEogiLuJz, AitBMapzjZGc4u in enumerate (LQB6POHcivdw87pk09ts2XMyf1IVEh)])
	return eval (Gn0XReKiJFMEsUxN531yAlI7S)
I7N2lHpGfLPkwKxbOu6raYUgc5,QmoEjB3hLIw,WbM6qAjrn7fEXGZw=dC3HqaFgt6QYG4,dC3HqaFgt6QYG4,dC3HqaFgt6QYG4
bbqAtUz36RPGVTvCkejpJXQB,MM564HfnUV0XIR,YDC9i52g6e8XL7GxvIFnSKWsolpr=WbM6qAjrn7fEXGZw,QmoEjB3hLIw,I7N2lHpGfLPkwKxbOu6raYUgc5
YZFXwtrfK8uhzV4LlMEqgnCQyO9,tmcuvd397wjGXeWoDHMNpFB5h2VK,Ox8k6IdtuPaG3NlApQK52oYwM=YDC9i52g6e8XL7GxvIFnSKWsolpr,MM564HfnUV0XIR,bbqAtUz36RPGVTvCkejpJXQB
GGCQK6OAtZUXRhvkgJm,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6,Gk98CL5nXZEN=Ox8k6IdtuPaG3NlApQK52oYwM,tmcuvd397wjGXeWoDHMNpFB5h2VK,YZFXwtrfK8uhzV4LlMEqgnCQyO9
dEUYJjrhsaPXNo,wx18CTJPZ5,cWfQ64kVCqxhwvSy5P7irHI1oes3=Gk98CL5nXZEN,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6,GGCQK6OAtZUXRhvkgJm
qFRrj7ayBKbOsHGSXz,SIDG7cnzAaUpkwmNde19ZsBqQ3Hh,tOdiG2HWFRBXg1sUh=cWfQ64kVCqxhwvSy5P7irHI1oes3,wx18CTJPZ5,dEUYJjrhsaPXNo
smpniPDOhfwI3H4v7c6TG,CIcPowhneWs5tN3,zxwIDBrPiXjKlsYkfg0AGaUZSyW2co=tOdiG2HWFRBXg1sUh,SIDG7cnzAaUpkwmNde19ZsBqQ3Hh,qFRrj7ayBKbOsHGSXz
r6juULGQtnExAko38BZ5Y,NNmirJKPp5nWjfC,FeyZbj8tDil0nSHzTwfsUJ9=zxwIDBrPiXjKlsYkfg0AGaUZSyW2co,CIcPowhneWs5tN3,smpniPDOhfwI3H4v7c6TG
S26SnaqcM9XwK8PVphJDv5,CgPbwXm1RilpJUSGHLhy,NxsKJnLFEZ9OHXf1h=FeyZbj8tDil0nSHzTwfsUJ9,NNmirJKPp5nWjfC,r6juULGQtnExAko38BZ5Y
Kwl07iYTtDLN3zP,uAl3gHavMJZL4xmNe62nDiBoQ,ta478EuZQJIWhgBnsf6iU=NxsKJnLFEZ9OHXf1h,CgPbwXm1RilpJUSGHLhy,S26SnaqcM9XwK8PVphJDv5
EAw9bg4rT3Bd8tjSkO,ItgK5FqGDz2Rf7mAJkbT,FFVuCHLxhZmkEGJQDitreaygc2f4AS=ta478EuZQJIWhgBnsf6iU,uAl3gHavMJZL4xmNe62nDiBoQ,Kwl07iYTtDLN3zP
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔࠩᶈ")
def HgQCVwFx2Br(n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw,RxgdTHfDar8EXt=S26SnaqcM9XwK8PVphJDv5(u"ࠨࠩᶉ")):
	if   n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==  MM564HfnUV0XIR(u"࠰৑"): kMcIXRenKqHmT(RxgdTHfDar8EXt)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==  uAl3gHavMJZL4xmNe62nDiBoQ(u"࠳৒"): oOmLC8y1REg(RxgdTHfDar8EXt)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==  Gk98CL5nXZEN(u"࠵৓"): RD1iOIYbcUzlh()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==  tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠷৔"): cQBJYm17zMNC6XjOfIdReLs4qwxo(RxgdTHfDar8EXt)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==  Gk98CL5nXZEN(u"࠹৕"): AxUYsDTCuqQ()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==  SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠻৖"): BDorXLyuqa8S()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==  I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠽ৗ"): NcRCDvgHBAS0(FeyZbj8tDil0nSHzTwfsUJ9(u"ࡘࡷࡻࡥ઄"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࡘࡷࡻࡥ઄"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==  uAl3gHavMJZL4xmNe62nDiBoQ(u"࠸৘"): UZSwdPGszq9nD1()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==  Gk98CL5nXZEN(u"࠺৙"): ggeyjRicDPxKpYrfIz3J()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==smpniPDOhfwI3H4v7c6TG(u"࠳࠸࠴৚"): Pam8HghwFkf9JU1AqDO()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==uAl3gHavMJZL4xmNe62nDiBoQ(u"࠴࠹࠶৛"): ujwJ1cqfeR()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==Kwl07iYTtDLN3zP(u"࠵࠺࠸ড়"): I5IjgLZ0MNOk9fDqRVwyAu1()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==CIcPowhneWs5tN3(u"࠶࠻࠳ঢ়"): f7mt09LAi5XFoxEW4bjcMUNGzH6Bh()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠷࠵࠵৞"): LgJcxdXok5Z()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==CgPbwXm1RilpJUSGHLhy(u"࠱࠶࠷য়"): T9z8cJaA6WsfSKIOeL()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠲࠷࠹ৠ"): YKpOxQe3lcr9aGWTiXA6vqjFd()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==smpniPDOhfwI3H4v7c6TG(u"࠳࠸࠻ৡ"): J9JTLXSQDG()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠴࠹࠽ৢ"): vR2yHBiQON()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==QmoEjB3hLIw(u"࠵࠺࠿ৣ"): TWo2wcXv4eMlqYUnKjHCb6PQJkAyIB(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࡙ࡸࡵࡦઅ"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==Gk98CL5nXZEN(u"࠶࠽࠰৤"): ejJ7V0Z15iNTr()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠷࠷࠲৥"): dufiHAe1WJU3QEMDBPRpCy0GwOmcg()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==Ox8k6IdtuPaG3NlApQK52oYwM(u"࠱࠸࠴০"): IuVorvz1ksJDgSd8wU(RxgdTHfDar8EXt,ItgK5FqGDz2Rf7mAJkbT(u"࡚ࡲࡶࡧઆ"),ItgK5FqGDz2Rf7mAJkbT(u"࡚ࡲࡶࡧઆ"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==EAw9bg4rT3Bd8tjSkO(u"࠲࠹࠶১"): ouxXRO0IqbTFQE5e6rD97(NxsKJnLFEZ9OHXf1h(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩᶊ"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࡔࡳࡷࡨઇ"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==GGCQK6OAtZUXRhvkgJm(u"࠳࠺࠸২"): ouxXRO0IqbTFQE5e6rD97(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡴࡷࡱࡵ࠭ᶋ"),tOdiG2HWFRBXg1sUh(u"ࡕࡴࡸࡩઈ"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠴࠻࠺৩"): r7peTnMuOlaBo6q9zJ()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠵࠼࠼৪"): yNUAfgCMeO0i8YrQWn()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==qFRrj7ayBKbOsHGSXz(u"࠶࠽࠷৫"): ppDvSqemKx9tRhoaInrjGyUkOg(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡷ࡫ࡳࡰ࡮ࡹࡩࡺࡸ࡬ࠨᶌ"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==NxsKJnLFEZ9OHXf1h(u"࠷࠷࠹৬"): ppDvSqemKx9tRhoaInrjGyUkOg(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿࡴ࠮ࡦ࡯ࡴࠬᶍ"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==dEUYJjrhsaPXNo(u"࠱࠸࠻৭"): ppDvSqemKx9tRhoaInrjGyUkOg(Gk98CL5nXZEN(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠭ᶎ"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠲࠻࠳৮"): PxmphrKe7N8oE()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==ta478EuZQJIWhgBnsf6iU(u"࠳࠼࠵৯"): ynvKMVjBsY62fwG5bcTXLEFhuq()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==uAl3gHavMJZL4xmNe62nDiBoQ(u"࠴࠽࠷ৰ"): dpXomkVGErTKOYBz2g()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==r6juULGQtnExAko38BZ5Y(u"࠵࠾࠹ৱ"): KNtfbIlVUmyn0ukZT2LD9iOSEHzR()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠶࠿࠴৲"): OOVb2MN4UHa7v()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==ta478EuZQJIWhgBnsf6iU(u"࠷࠹࠶৳"): d1RljT3DWeMEqxHOIk8()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠱࠺࠸৴"): BWgYxE42vZr()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==GGCQK6OAtZUXRhvkgJm(u"࠲࠻࠺৵"): rejRwiPNUAsGVZYL7tTB()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==Kwl07iYTtDLN3zP(u"࠳࠼࠼৶"): YWMgTwdIhj()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==NNmirJKPp5nWjfC(u"࠴࠽࠾৷"): lNbzoSDBijRItaegyuYEx7hMqm5AsV()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==Kwl07iYTtDLN3zP(u"࠷࠹࠶৸"): ihuLTZmH4vBO5etr2xIob0CpX(RxgdTHfDar8EXt)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠸࠺࠱৹"): EEqzDPROnos2aIiyCm0hSlVJdKv8()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠹࠴࠳৺"): tpqgd0BSAV4LnxEasiUr()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==NxsKJnLFEZ9OHXf1h(u"࠳࠵࠵৻"): dV6hQJU0GSWInHDiv5k7yaMb()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==Ox8k6IdtuPaG3NlApQK52oYwM(u"࠴࠶࠷ৼ"): jMFdvr1ns4NBIYE23Qg(uAl3gHavMJZL4xmNe62nDiBoQ(u"ࡖࡵࡹࡪઉ"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==NxsKJnLFEZ9OHXf1h(u"࠵࠷࠹৽"): xBGISRPJ3kXowclp4Emf()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==tOdiG2HWFRBXg1sUh(u"࠶࠸࠻৾"): ALWQsFjmi7zIw8b(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࡉࡥࡱࡹࡥઊ"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==FeyZbj8tDil0nSHzTwfsUJ9(u"࠷࠹࠽৿"): C6D50ht2eI(tOdiG2HWFRBXg1sUh(u"ࡘࡷࡻࡥઋ"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==Ox8k6IdtuPaG3NlApQK52oYwM(u"࠸࠺࠸਀"): qC2szKJkU6GuZIMLW()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠹࠴࠺ਁ"): pass
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠵࠱࠲ਂ"): VDEdOyPswb()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==tOdiG2HWFRBXg1sUh(u"࠶࠲࠴ਃ"): LCcGPJE9nl01ayAI27SZsjgUY6()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠷࠳࠶਄"): rvlbN3Tnq1Juj(uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ᶏ"),EAw9bg4rT3Bd8tjSkO(u"࡙ࡸࡵࡦઌ"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==tOdiG2HWFRBXg1sUh(u"࠸࠴࠸ਅ"): T2XJv1P9oLwcZCAjaGq5zyg6srxDR(D5q7g8N0XowOn2Q)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠹࠵࠺ਆ"): T2XJv1P9oLwcZCAjaGq5zyg6srxDR(LkNCuYDaeV576vtyI)
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==FeyZbj8tDil0nSHzTwfsUJ9(u"࠺࠶࠵ਇ"): FFYURMbGJI02fgBmKuDSHVWylQEAkp()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==tOdiG2HWFRBXg1sUh(u"࠻࠰࠷ਈ"): Jc19dpOeUMyLXG5PVrf0SlZmHntx(Kwl07iYTtDLN3zP(u"࡚ࡲࡶࡧઍ"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==FeyZbj8tDil0nSHzTwfsUJ9(u"࠵࠱࠹ਉ"): oq2rsGRg6kHh4YiFfudMDnwEJ(RxgdTHfDar8EXt,S26SnaqcM9XwK8PVphJDv5(u"ࠨࠩᶐ"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࡔࡳࡷࡨ઎"))
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==S26SnaqcM9XwK8PVphJDv5(u"࠶࠲࠻ਊ"): khSdoYQ3VOItlx()
	elif n5MyZa4PAX2sYLRiJ6S1EBI8DpKxlw==qFRrj7ayBKbOsHGSXz(u"࠷࠳࠽਋"): Gsw0Lq97p5tx1u8()
	return
def Gsw0Lq97p5tx1u8():
	A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(r6juULGQtnExAko38BZ5Y(u"ࠩࠪᶑ"),CgPbwXm1RilpJUSGHLhy(u"ࠪࠫᶒ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠫࠬᶓ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᶔ"),Kwl07iYTtDLN3zP(u"࠭็ๅࠢอี๏ีࠠโ฻็ห๋ࠥำฮࠢฯ้๏฿ࠠฦ฻าหิอสࠡษ็ฬึ์วๆฮࠣ࠲࠳่ࠦๆีะࠤัฺ๋๊่่ࠢๆอสࠡษ็ฬึ์วๆฮࠣห้่ฯ๋็ฬࠤ࠳࠴ࠠๅๅํࠤ๏฿่ะࠢส่อืๆศ็ฯࠤส๊้ࠡฯส่ฮࠦวๅืไีࠥ࠴࠮ࠡ์฼๊๏ࠦสอัํำࠥอไษำ้ห๊า้ࠠฬุๅ๏ื็ฺ๊๋ࠡ฾ํࠠษฯส่ฮࠦวๅ็ุ๊฾ࠦวๅฬํࠤํ฼ู่ษࠣห้๋ศา็ฯࠤฤࠧࠡࠨᶕ"))
	if A5vgi1F6qVunZMas2Nf:
		jMFdvr1ns4NBIYE23Qg(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࡇࡣ࡯ࡷࡪએ"))
		oFHcGJSy62KieOMmZv4f0l(llrbyaFHOt9e,CgPbwXm1RilpJUSGHLhy(u"ࡗࡶࡺ࡫ઑ"),qFRrj7ayBKbOsHGSXz(u"ࡈࡤࡰࡸ࡫ઐ"))
		tehb3k5a2PufGOdBIUw8j(tOdiG2HWFRBXg1sUh(u"ࠧࠨᶖ"),tOdiG2HWFRBXg1sUh(u"ࠨࠩᶗ"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᶘ"),ItgK5FqGDz2Rf7mAJkbT(u"ࠪฮ๊ࠦๅิฯࠣะ๊๐ูࠡษ็้้็วหࠢส่็ี๊ๆห่้ࠣฮั็ษ่ะࠥ࠴࠮๊ࠡ฼หิࠦวๅสิ๊ฬ๋ฬࠡว็ํࠥ๎ึฺ์ฬࠤฬ๊ีโำࠣ࠲࠳่ࠦื฻ํอࠥอไๆื้฽ࠬᶙ"))
	return
def oq2rsGRg6kHh4YiFfudMDnwEJ(aZhcuMGisIkl4npqDoJSrWy5fExX,tTKBgCwHMmWRk1UO36qY2F,showDialogs):
	md59xZUEq3IOnPp2 = iZv4fPkF5Trx1L8EsVHC2S.connect(wmrN7GxQWCAD9PzM3Tj)
	md59xZUEq3IOnPp2.text_factory = str
	ngBDPjZshKvdX6 = md59xZUEq3IOnPp2.cursor()
	if vciEXHThAPto76QIR2pK: ARHSV5XxT2dzPIvtNYuhjk6eD1 = YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠫࡧࡲࡡࡤ࡭࡯࡭ࡸࡺࠧᶚ")
	else: ARHSV5XxT2dzPIvtNYuhjk6eD1 = QmoEjB3hLIw(u"ࠬࡻࡰࡥࡣࡷࡩࡤࡸࡵ࡭ࡧࡶࠫᶛ")
	ngBDPjZshKvdX6.execute(smpniPDOhfwI3H4v7c6TG(u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࠪࠡࡈࡕࡓࡒࠦࠧᶜ")+ARHSV5XxT2dzPIvtNYuhjk6eD1+Kwl07iYTtDLN3zP(u"࡙ࠧࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬᶝ")+aZhcuMGisIkl4npqDoJSrWy5fExX+ta478EuZQJIWhgBnsf6iU(u"ࠨࠤࠣ࠿ࠬᶞ"))
	MRDAU8alpIbtNPn1Y95WJK2d6mr3E = ngBDPjZshKvdX6.fetchall()
	if MRDAU8alpIbtNPn1Y95WJK2d6mr3E and tTKBgCwHMmWRk1UO36qY2F in [smpniPDOhfwI3H4v7c6TG(u"ࠩࠪᶟ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠪࡩࡳࡧࡢ࡭ࡧࠪᶠ")]:
		A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(CgPbwXm1RilpJUSGHLhy(u"ࠫࠬᶡ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠬ࠭ᶢ"),MM564HfnUV0XIR(u"࠭ࠧᶣ"),NNmirJKPp5nWjfC(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᶤ"),NNmirJKPp5nWjfC(u"ࠨษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆศฺฬ็ษࠡ࡞ࡱࠤࠬᶥ")+aZhcuMGisIkl4npqDoJSrWy5fExX+QmoEjB3hLIw(u"ࠩࠣࡠࡳࡢ࡮ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤ๊ะ่ใใࠣ์้อ๋ࠠ฻่่ࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢอๅ฾๐ไ่ࠢส่ว์ࠠภࠣࠤࠤࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࡜࡯࡞ࡱࠤฯูสุ์฼ࠤส๐โศใ๊ࠤอู็้ๆฬࠤ฾์ฯࠡษ็฽ํีษࠡว็ํࠥํะ่ࠢสู่อิสࠢส่๊๎ฬ้ัฬࠤๆ๐ࠠใษษ้ฮࠦฮะ็สฮࠥฮั็ษ่ะࠥ฿ๅศัࠪᶦ"))
		if A5vgi1F6qVunZMas2Nf!=CIcPowhneWs5tN3(u"࠴਌"): return
		ngBDPjZshKvdX6.execute(ItgK5FqGDz2Rf7mAJkbT(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠩᶧ")+ARHSV5XxT2dzPIvtNYuhjk6eD1+SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠫࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩᶨ")+aZhcuMGisIkl4npqDoJSrWy5fExX+FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠬࠨࠠ࠼ࠩᶩ"))
	elif tTKBgCwHMmWRk1UO36qY2F in [tOdiG2HWFRBXg1sUh(u"࠭ࠧᶪ"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࠨᶫ")]:
		A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(dEUYJjrhsaPXNo(u"ࠨࠩᶬ"),NNmirJKPp5nWjfC(u"ࠩࠪᶭ"),Gk98CL5nXZEN(u"ࠪࠫᶮ"),tOdiG2HWFRBXg1sUh(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᶯ"),Kwl07iYTtDLN3zP(u"ࠬอไหฯา๎ะࠦวๅล๋ฮํ๋วห์ๆ๎๊ࠥลืษไอࠥࡢ࡮ࠡࠩᶰ")+aZhcuMGisIkl4npqDoJSrWy5fExX+MM564HfnUV0XIR(u"࠭ࠠ࡝ࡰ࡟ࡲࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ็ไ฽้่๋ࠦ฻่่ࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢศ๎็อแ่ࠢส่ว์ࠠภࠣࠤࠤࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࡜࡯࡞ࡱࠤฯูสุ์฼ࠤฯ็ู๋ๆ๊ࠤอู็้ๆฬࠤ฾์ฯࠡษ็฽ํีษࠡว็ํࠥํะ่ࠢสู่อิสࠢส่๊๎ฬ้ัฬࠤๆ๐ࠠใษษ้ฮࠦฮะ็สฮࠥฮั็ษ่ะࠥ฿ๅศัࠪᶱ"))
		if A5vgi1F6qVunZMas2Nf!=I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠵਍"): return
		if vciEXHThAPto76QIR2pK: ngBDPjZshKvdX6.execute(Kwl07iYTtDLN3zP(u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥࡨ࡬ࡢࡥ࡮ࡰ࡮ࡹࡴࠡࠪࡤࡨࡩࡵ࡮ࡊࡆࠬࠤ࡛ࡇࡌࡖࡇࡖࠤ࠭ࠨࠧᶲ")+aZhcuMGisIkl4npqDoJSrWy5fExX+NxsKJnLFEZ9OHXf1h(u"ࠨࠤࠬࠤࡀ࠭ᶳ"))
		else: ngBDPjZshKvdX6.execute(NNmirJKPp5nWjfC(u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࡶࡲࡧࡥࡹ࡫࡟ࡳࡷ࡯ࡩࡸࠦࠨࡢࡦࡧࡳࡳࡏࡄ࠭ࡷࡳࡨࡦࡺࡥࡓࡷ࡯ࡩ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩᶴ")+aZhcuMGisIkl4npqDoJSrWy5fExX+Kwl07iYTtDLN3zP(u"ࠪࠦ࠱࠷ࠩࠡ࠽ࠪᶵ"))
	md59xZUEq3IOnPp2.commit()
	md59xZUEq3IOnPp2.close()
	w6vebiEZtpCjJcILP8Skx5rHn.sleep(NxsKJnLFEZ9OHXf1h(u"࠶਎"))
	oos8ymFi9CN2z1jXcR.executebuiltin(WbM6qAjrn7fEXGZw(u"࡚ࠫࡶࡤࡢࡶࡨࡐࡴࡩࡡ࡭ࡃࡧࡨࡴࡴࡳࠨᶶ"))
	w6vebiEZtpCjJcILP8Skx5rHn.sleep(wx18CTJPZ5(u"࠷ਏ"))
	if showDialogs: tehb3k5a2PufGOdBIUw8j(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠬ࠭ᶷ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠭ࠧᶸ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᶹ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠨฬ่ฮࠥอไฺ็็๎ฮࠦศ็ฮสัࠬᶺ"))
	if tTKBgCwHMmWRk1UO36qY2F in [MM564HfnUV0XIR(u"ࠩࠪᶻ"),smpniPDOhfwI3H4v7c6TG(u"ࠪࡩࡳࡧࡢ࡭ࡧࠪᶼ")]: TWo2wcXv4eMlqYUnKjHCb6PQJkAyIB(showDialogs)
	return
def FFYURMbGJI02fgBmKuDSHVWylQEAkp():
	QQvOnYi9sJMwp7dIxeck8DRASWuBt(WSgQvHLx9uOKTksaCt2JchldRj,CIcPowhneWs5tN3(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧᶽ"),CgPbwXm1RilpJUSGHLhy(u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨᶾ"))
	WmSFUq5gTRr13 = ORXquBZQ8x2wnWveHtYdCTyU(r6juULGQtnExAko38BZ5Y(u"ࡊࡦࡲࡳࡦ઒"))
	f2KUvMsYWQdcTirgFoCaeOm = ta478EuZQJIWhgBnsf6iU(u"࠭࡜࡯ࠩᶿ")
	Zu0pDfAUHxaMYmQdCL6vEtosFGT7P = r6juULGQtnExAko38BZ5Y(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠣ࠱࠲࠳࠭࠮ࠢ࠰࠱࠲࠳࠭ࠡ࠯࠰࠱࠲࠳ࠠ࠮࠯࠰࠱࠲ࠦ࠭࠮࠯࠰࠱ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ᷀")
	hYtuDIfQgk645Hzj0ZdXyJR = FeyZbj8tDil0nSHzTwfsUJ9(u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࡡࡴࠧ᷁")
	for id,gg6VwuY0xOi7,yTJXbEc9LjmfVRD0N2F,gqf9tEKLQN2J6bAUr0ivHIOSD,n8g9KIdWMyTi2JDkvEfBA6,reason in reversed(WmSFUq5gTRr13):
		if id==WbM6qAjrn7fEXGZw(u"ࠩ࠳᷂ࠫ"):
			hhybuQfnOXm,EUYp7Rs8FNn3eokvSx4h = gqf9tEKLQN2J6bAUr0ivHIOSD.split(Kwl07iYTtDLN3zP(u"ࠪࡠࡳࡁ࠻ࠨ᷃"))
			continue
		if f2KUvMsYWQdcTirgFoCaeOm!=tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠫࡡࡴࠧ᷄"): f2KUvMsYWQdcTirgFoCaeOm += hYtuDIfQgk645Hzj0ZdXyJR
		hwAK5bC7pHoU6VrSdgsvM = FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭᷅")+id+bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠭ࠠ࠻ࠢࠪ᷆")+smpniPDOhfwI3H4v7c6TG(u"ࠧศๆึศฬ๊ࠠ࠻ࠢࠪ᷇")+wx18CTJPZ5(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ᷈")+yTJXbEc9LjmfVRD0N2F
		cE6OHoADvlhK1gVy2p8rYbWXFmGQ = QmoEjB3hLIw(u"ࠩ࡟ࡲࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ฬ้ษหࠤ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ᷉")+gqf9tEKLQN2J6bAUr0ivHIOSD
		YOTH54N3yLc9K = wx18CTJPZ5(u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้ิืฤࠢ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ᷊࠭")+n8g9KIdWMyTi2JDkvEfBA6
		fjvEc6Ayo9UrIXKJLzaBPR12eM = CIcPowhneWs5tN3(u"ࠫࡡࡴ࡛ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅีหฬࠥࡀࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ᷋")+reason
		f2KUvMsYWQdcTirgFoCaeOm += hwAK5bC7pHoU6VrSdgsvM+cE6OHoADvlhK1gVy2p8rYbWXFmGQ+wx18CTJPZ5(u"ࠬࡢ࡮ࠨ᷌")+Zu0pDfAUHxaMYmQdCL6vEtosFGT7P+Ox8k6IdtuPaG3NlApQK52oYwM(u"࠭࡜࡯ࠩ᷍")+YOTH54N3yLc9K+fjvEc6Ayo9UrIXKJLzaBPR12eM+Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠧ࡝ࡰ᷎ࠪ")
	Dkp5YTLQijOEKF(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠨࡴ࡬࡫࡭ࡺ᷏ࠧ"),EUYp7Rs8FNn3eokvSx4h,f2KUvMsYWQdcTirgFoCaeOm,smpniPDOhfwI3H4v7c6TG(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩ᷐ࠪ"))
	return
def T2XJv1P9oLwcZCAjaGq5zyg6srxDR(file):
	if file==LkNCuYDaeV576vtyI: zTnR49BrMfH = NNmirJKPp5nWjfC(u"ࠪๆํอฦๆࠢส่๊็ึๅหࠪ᷑")
	elif file==D5q7g8N0XowOn2Q: zTnR49BrMfH = cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠫ็๎วว็ࠣฦำืࠠศๆไ๎ิ๐่่ษอࠫ᷒")
	A4rSxVHK9Dfieob8B7 = m5NUYqBzGynIOeAg8(dEUYJjrhsaPXNo(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᷓ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"࠭ๅิฯࠪᷔ"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠧฦื็หา࠭ᷕ"),r6juULGQtnExAko38BZ5Y(u"ࠨะิ์ั࠭ᷖ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᷗ"),S26SnaqcM9XwK8PVphJDv5(u"๋้ࠪࠦสา์าࠤส฻ไศฯ้้ࠣ็ࠠࠨᷘ")+zTnR49BrMfH+cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠫࠥษๅࠡฬิ๎ิࠦๅิฯࠣห้๋ไโࠢยࠫᷙ"))
	if A4rSxVHK9Dfieob8B7==WbM6qAjrn7fEXGZw(u"࠰ਐ"):
		if K3hFytImeYMkJBC.path.exists(file):
			try: K3hFytImeYMkJBC.remove(file)
			except: pass
		tehb3k5a2PufGOdBIUw8j(ItgK5FqGDz2Rf7mAJkbT(u"ࠬ࠭ᷚ"),EAw9bg4rT3Bd8tjSkO(u"࠭ࠧᷛ"),CIcPowhneWs5tN3(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᷜ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠨฬ่ࠤู๊อࠡ็็ๅࠥ࠭ᷝ")+zTnR49BrMfH)
	elif A4rSxVHK9Dfieob8B7==ta478EuZQJIWhgBnsf6iU(u"࠲਑"):
		data = v3vOJa64yzBGcdQZ0oPrhNF9L(file)
		tehb3k5a2PufGOdBIUw8j(wx18CTJPZ5(u"ࠩࠪᷞ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠪࠫᷟ"),qFRrj7ayBKbOsHGSXz(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᷠ"),tOdiG2HWFRBXg1sUh(u"ࠬะๅࠡวุ่ฬำࠠๆๆไࠤࠬᷡ")+zTnR49BrMfH)
	return
def LCcGPJE9nl01ayAI27SZsjgUY6():
	if wH3qxmuXBTeak<qFRrj7ayBKbOsHGSXz(u"࠳࠻਒"):
		maCNIYkc0HOiEGpL3g = r6juULGQtnExAko38BZ5Y(u"࠭ไๅลึๅࠥษๆหࠢอืฯิฯๆࠢศูิอัࠡๅ๋ำ๏ࠦโะ์่ࠤึ่ๅࠡࠩᷢ")+str(wH3qxmuXBTeak)+qFRrj7ayBKbOsHGSXz(u"๊ࠧࠡ็๋ีอࠠศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢ็หࠥะูๆๆࠣ฽๋ีใࠡ࠰๋ࠣีํࠠศๆ่๎ืฯࠠห็ๆ๊่ࠦๅ็ࠢิศ๏ฯࠠใ๊สส๊ࠦวๅใํำ๏๎็ศฬࠣๅ๏ࠦศา่ส้ัูࠦๆษาࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠡ࠰่ࠣส฻ไศฯࠣห้๋ิไๆฬࠤ็๋ࠠษฬะำ๏ัࠠษำ้ห๊าࠠไ๊า๎ࠥหไ๊ࠢศ๎ࠥหีะษิࠤึ่ๅ่ࠢฦ฽้๏ࠠๆ่ࠣ࠵࠽࠴࠰ࠨᷣ")
		tehb3k5a2PufGOdBIUw8j(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠨࠩᷤ"),QmoEjB3hLIw(u"ࠩࠪᷥ"),CgPbwXm1RilpJUSGHLhy(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᷦ"),maCNIYkc0HOiEGpL3g)
		return
	FQB3ikd1X6fsx8PhZKvUL9nq7GbCED = oos8ymFi9CN2z1jXcR.executeJSONRPC(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧᷧ"))
	HUiL4nsdTt = jNVelpUxiIn([SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫᷨ")])
	gKMqlA19hi,k5ke71LMw0yr,wIjgoinbtYHyWqfdREC8p5Qm,kuNhXjnbYKVr,vlioP67cxzsLrENYa40ftgdMFOn,qO8lR2Pi7wN5dBZeU,jIpQYu092ZlmWc = HUiL4nsdTt[S26SnaqcM9XwK8PVphJDv5(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬᷩ")]
	if gKMqlA19hi or wx18CTJPZ5(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ᷪ") not in str(FQB3ikd1X6fsx8PhZKvUL9nq7GbCED):
		tehb3k5a2PufGOdBIUw8j(NxsKJnLFEZ9OHXf1h(u"ࠨࠩᷫ"),Kwl07iYTtDLN3zP(u"ࠩࠪᷬ"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᷭ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠫฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦสฺ็็ࠤๆ่ืࠡ็฼ࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠰๋ࠣีํࠠศๆๅ์ฬฬๅࠡฬ่็๋้ࠠๆ่ࠣีษ๐ษࠡไ๋หห๋ࠠษำ้ห๊าฺࠠ็สำࠥฮิไๆูࠣํืࠠษั็ห๋ࠥๆࠡษ็็ฯอศสࠩᷮ"))
		VZHWjJTrAPKG1eLEsxpYo2tS5 = rvlbN3Tnq1Juj(wx18CTJPZ5(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫᷯ"),tOdiG2HWFRBXg1sUh(u"࡙ࡸࡵࡦઓ"))
		if not VZHWjJTrAPKG1eLEsxpYo2tS5: return
	Nkv860iJXz5DB9lVd7u2nT(r6juULGQtnExAko38BZ5Y(u"࡚ࡲࡶࡧઔ"))
	return
def Nkv860iJXz5DB9lVd7u2nT(showDialogs=tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࡔࡳࡷࡨક")):
	FQB3ikd1X6fsx8PhZKvUL9nq7GbCED = oos8ymFi9CN2z1jXcR.executeJSONRPC(S26SnaqcM9XwK8PVphJDv5(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾࠩᷰ"))
	if FeyZbj8tDil0nSHzTwfsUJ9(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ᷱ") not in str(FQB3ikd1X6fsx8PhZKvUL9nq7GbCED):
		if showDialogs:
			tehb3k5a2PufGOdBIUw8j(NNmirJKPp5nWjfC(u"ࠨࠩᷲ"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠩࠪᷳ"),NNmirJKPp5nWjfC(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᷴ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"้๊ࠫริใࠣะ์อาไࠢ็หࠥ๐ำหะา้ࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦสฺ็็ࠤๆ่ืࠡ็฼ࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠰๋ࠣีํࠠศๆๅ์ฬฬๅࠡฬ่็๋้ࠠๆ่ࠣีษ๐ษࠡไ๋หห๋ࠠษำ้ห๊าฺࠠ็สำࠥฮิไๆูࠣํืࠠษั็ห๋ࠥๆࠡษ็็ฯอศสࠩ᷵"))
		return
	Cok46U7K9Sc = K3hFytImeYMkJBC.path.join(qKHs0b1SC2v3EZ9xfOluQ,ta478EuZQJIWhgBnsf6iU(u"ࠬࡧࡤࡥࡱࡱࡷࠬ᷶"),NNmirJKPp5nWjfC(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈ᷷ࠬ"),ItgK5FqGDz2Rf7mAJkbT(u"ࠧ࠸࠴࠳ࡴ᷸ࠬ"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠨࡏࡼ࡚࡮ࡪࡥࡰࡐࡤࡺ࠳ࡾ࡭࡭᷹ࠩ"))
	if not K3hFytImeYMkJBC.path.exists(Cok46U7K9Sc): return
	xxMqmzh3YOFKHbyCQtUwjL2slZV = open(Cok46U7K9Sc,smpniPDOhfwI3H4v7c6TG(u"ࠩࡵࡦ᷺ࠬ")).read()
	if wvkR1es6d0SrjxKt5FZTMUWz7a: xxMqmzh3YOFKHbyCQtUwjL2slZV = xxMqmzh3YOFKHbyCQtUwjL2slZV.decode(QmoEjB3hLIw(u"ࠪࡹࡹ࡬࠸ࠨ᷻"))
	WcIT4o0dlYC7h5BuKsrADH = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(FeyZbj8tDil0nSHzTwfsUJ9(u"ࠫࡁࡼࡩࡦࡹࡶࡂ࠭ࡢࡤࠬ࠮࡟ࡨ࠰࠲࡜ࡥ࠭ࠬ࠰࠭࠴ࠪࡀࠫ࠿࠳ࡻ࡯ࡥࡸࡵࡁࠫ᷼"),xxMqmzh3YOFKHbyCQtUwjL2slZV,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	WWpKi4yrDnMvAJuo5,ihBMpGc7e6qIC = WcIT4o0dlYC7h5BuKsrADH[wx18CTJPZ5(u"࠳ਓ")]
	VVQA9k14hbiKz6vDdHwnLEq = Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠬࡂࡶࡪࡧࡺࡷࡃ᷽࠭")+WWpKi4yrDnMvAJuo5+r6juULGQtnExAko38BZ5Y(u"࠭ࠬࠨ᷾")+ihBMpGc7e6qIC+EAw9bg4rT3Bd8tjSkO(u"ࠧ࠽࠱ࡹ࡭ࡪࡽࡳ࠿᷿ࠩ")
	if showDialogs:
		vbWnOFyjfeNkt47 = oos8ymFi9CN2z1jXcR.getInfoLabel(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡛࡯ࡥࡸ࡯ࡲࡨࡪ࠭Ḁ"))
		if vbWnOFyjfeNkt47==r6juULGQtnExAko38BZ5Y(u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬḁ"): EgsRLOdXKSNoTaDFW0k6 = S26SnaqcM9XwK8PVphJDv5(u"ࠪๆํอฦๆࠢส่่ะวษหࠪḂ")
		elif vbWnOFyjfeNkt47==tOdiG2HWFRBXg1sUh(u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪḃ"): EgsRLOdXKSNoTaDFW0k6 = tOdiG2HWFRBXg1sUh(u"่่ࠬศศ่ࠤฬ๊ี้ำࠪḄ")
		else: EgsRLOdXKSNoTaDFW0k6 = NxsKJnLFEZ9OHXf1h(u"࠭โ้ษษ้ࠥษฮา๋ࠪḅ")
		A4rSxVHK9Dfieob8B7 = m5NUYqBzGynIOeAg8(Kwl07iYTtDLN3zP(u"ࠧࡤࡧࡱࡸࡪࡸࠧḆ"),wx18CTJPZ5(u"ࠨไ๋หห๋ࠠฤะิํࠬḇ"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࠩๅ์ฬฬๅࠡษ็็ฯอศสࠩḈ"),S26SnaqcM9XwK8PVphJDv5(u"ࠪๆํอฦๆࠢสฺ่๎ัࠨḉ"),S26SnaqcM9XwK8PVphJDv5(u"ࠫฬ์สࠡฯส่๏อࠠหีอาิ๋ࠠࠨḊ")+EgsRLOdXKSNoTaDFW0k6,ta478EuZQJIWhgBnsf6iU(u"ࠬอๆหࠢส่ว์ࠠหีอาิ๋ࠠศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮๊๊ࠡิฬࠦๅฺ่ส๋ࠥอๆไࠢอืฯ฽ฺ๊ࠢสืฯิฯศ็ࠣห้่่ศศ่ࠤฬ๊ๅึ๊ิอࠥฮฯๅษ้๋ࠣࠦโ้ษษ้ࠥอไไฬสฬฮࠦ࠮๊ࠡฦ๎฻อࠠหีอ฻๏฿ࠠฦ์ๅหๆํวࠡใํࠤศ๐้ࠠไอࠤฯฺวยࠢ࡟ࡲࡡࡴࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠣวำะัࠡษ็ฦ๋ࠦๆ้฻ࠣห้่่ศศ่ࠤฬ๊ส๋ࠢอี๏ีࠠฤีอาิอๅ่ษࠣรࠦࡡ࠯ࡄࡑࡏࡓࡗࡣࠧḋ"))
		if A4rSxVHK9Dfieob8B7==MM564HfnUV0XIR(u"࠵ਔ"): n1LIhevdGEMN = CIcPowhneWs5tN3(u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩḌ")
		elif A4rSxVHK9Dfieob8B7==tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠷ਕ"): n1LIhevdGEMN = wx18CTJPZ5(u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭ḍ")
		else: n1LIhevdGEMN = S26SnaqcM9XwK8PVphJDv5(u"ࠨࠩḎ")
	else:
		vbWnOFyjfeNkt47 = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(qFRrj7ayBKbOsHGSXz(u"ࠩࡤࡺ࠳ࡳࡹࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡰࡳࡩ࡫ࠧḏ"))
		if   vbWnOFyjfeNkt47==ta478EuZQJIWhgBnsf6iU(u"ࠪࠫḐ"): A4rSxVHK9Dfieob8B7 = CgPbwXm1RilpJUSGHLhy(u"࠶ਖ")
		elif vbWnOFyjfeNkt47==ItgK5FqGDz2Rf7mAJkbT(u"ࠫࡊࡓࡁࡅࠢࡏ࡭ࡸࡺࠧḑ"): A4rSxVHK9Dfieob8B7 = bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠱ਗ")
		elif vbWnOFyjfeNkt47==YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠬࡋࡍࡂࡆࠣࡋࡦࡲ࡬ࡦࡴࡼࠫḒ"): A4rSxVHK9Dfieob8B7 = r6juULGQtnExAko38BZ5Y(u"࠳ਘ")
		n1LIhevdGEMN = vbWnOFyjfeNkt47
	if   A4rSxVHK9Dfieob8B7==CgPbwXm1RilpJUSGHLhy(u"࠲ਙ"): PmAdhQK9YuCe87kGcOJF5j0 = FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠭࠵࠶࠮࠸࠸࠹࠲࠵࠶࠷ࠪḓ")
	elif A4rSxVHK9Dfieob8B7==bbqAtUz36RPGVTvCkejpJXQB(u"࠴ਚ"): PmAdhQK9YuCe87kGcOJF5j0 = SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠧ࠶࠶࠷࠰࠺࠻࠵࠭࠷࠸ࠫḔ")
	elif A4rSxVHK9Dfieob8B7==YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠶ਛ"): PmAdhQK9YuCe87kGcOJF5j0 = tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠨ࠷࠸࠹࠱࠻࠵࠭࠷࠷࠸ࠬḕ")
	else: return
	if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(S26SnaqcM9XwK8PVphJDv5(u"ࠩࡤࡺ࠳ࡳࡹࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡰࡳࡩ࡫ࠧḖ"),n1LIhevdGEMN)
	ZTEhbYQtBU = Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠪࡀࡻ࡯ࡥࡸࡵࡁࠫḗ")+PmAdhQK9YuCe87kGcOJF5j0+NNmirJKPp5nWjfC(u"ࠫ࠱࠭Ḙ")+ihBMpGc7e6qIC+YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠬࡂ࠯ࡷ࡫ࡨࡻࡸࡄࠧḙ")
	zQLoZxqihtkKVUmnJYEMu4OwI6Cal = xxMqmzh3YOFKHbyCQtUwjL2slZV.replace(VVQA9k14hbiKz6vDdHwnLEq,ZTEhbYQtBU)
	if wvkR1es6d0SrjxKt5FZTMUWz7a: zQLoZxqihtkKVUmnJYEMu4OwI6Cal = zQLoZxqihtkKVUmnJYEMu4OwI6Cal.encode(smpniPDOhfwI3H4v7c6TG(u"࠭ࡵࡵࡨ࠻ࠫḚ"))
	open(Cok46U7K9Sc,cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠧࡸࡤࠪḛ")).write(zQLoZxqihtkKVUmnJYEMu4OwI6Cal)
	y75wQavkVSLUb2MZf9qo(S26SnaqcM9XwK8PVphJDv5(u"ࠨࡐࡒࡘࡎࡉࡅࠨḜ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠩ࠱ࠤ࡙ࠥ࡫ࡪࡰࠣࡈࡪ࡬ࡡࡶ࡮ࡷࠤ࡛࡯ࡥࡸࡵ࠽ࠤࡠࠦࠧḝ")+PmAdhQK9YuCe87kGcOJF5j0+FeyZbj8tDil0nSHzTwfsUJ9(u"ࠪࠤࡢ࠭Ḟ"))
	if showDialogs: oos8ymFi9CN2z1jXcR.executebuiltin(Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠫࡗ࡫࡬ࡰࡣࡧࡗࡰ࡯࡮ࠩࠫࠪḟ"))
	return
def VDEdOyPswb():
	A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(ItgK5FqGDz2Rf7mAJkbT(u"ࠬ࠭Ḡ"),CIcPowhneWs5tN3(u"࠭ࠧḡ"),wx18CTJPZ5(u"ࠧࠨḢ"),EAw9bg4rT3Bd8tjSkO(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫḣ"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠩหี๋อๅอࠢ฼้ฬีࠠโ์๊ࠤฺ๊ใๅหࠣ฽๋ีใࠡ࠰࠱࠲ࠥหๅศࠢฦ่ส฻ฯศำࠣๆิ๐ๅࠡ࠰࠱࠲ࠥษ่ࠡษ้ฮ๋ࠥๅ็๊฼ࠤ๊์ࠠศีอาิอๅࠡษ็ฬึ์วๆฮࠣ࠲࠳࠴ࠠฤ๊่ࠣิ๐ใࠡ็ื็้ฯࠠฤะิํࠥะฮึࠢฯ๋ฬุใࠡล้ฮࠥ๎ไศࠢอาฺࠦศใ์ฬࠤำ๊โࠡษ็่์ࠦ࡜࡯࡞ࡱࠤาอ่ๅࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣวํࠦวหื็ࠤออไๆสิ้ัࠦไๆ฻ิๅฮࠦำษสࠣห้๋ิไๆฬࠤ฾์ฯไࠢ࠱࠲࠳ࠦ็ๅࠢอี๏ีࠠโฯุࠤฬ๊สฮัํฯฬะࠠศๆล๊ࠥลࠧḤ"))
	if A5vgi1F6qVunZMas2Nf==MM564HfnUV0XIR(u"࠶ਜ"): NcRCDvgHBAS0(wx18CTJPZ5(u"ࡕࡴࡸࡩખ"),wx18CTJPZ5(u"ࡕࡴࡸࡩખ"))
	return
def UZSwdPGszq9nD1():
	tehb3k5a2PufGOdBIUw8j(EAw9bg4rT3Bd8tjSkO(u"ࠪࠫḥ"),qFRrj7ayBKbOsHGSXz(u"ࠫࠬḦ"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨḧ"),GGCQK6OAtZUXRhvkgJm(u"࠭็ัษࠣห้๋่ใ฻้ࠣ฿๊โࠡ็้ࠤฬ๊ๅึัิࠤํเ๊า่ࠢ฽ึ๎แࠡ็อ๎ࠥ๐ัอ฻่้ࠣ฿ๅๅࠩḨ"))
	return
def qC2szKJkU6GuZIMLW():
	hwAK5bC7pHoU6VrSdgsvM = qFRrj7ayBKbOsHGSXz(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟อ฽ิอฯࠡึํ฽ฮࠦยๅ่ࠢั๊ีࠠๅี้อࠥ࠸࠰࠳࠳ࠣ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧḩ")
	hwAK5bC7pHoU6VrSdgsvM += Gk98CL5nXZEN(u"ࠨษ็้ํู่ࠡลา๊ฬํࠠโ์๊ࠤสำีศศํอู๊ࠥะัࠣหฺฺ้๊หࠣๅ๏ࠦวๅ฻ส่๊ࠦสๆࠢฯ้฾ํวࠡ็้ࠤัฺ๋๊ࠢส่๊฻วะำࠣห้๋ส้ใิอࠥ็๊ࠡษ็ษ๋ะั็ฬࠣห้่ฯ๋็ฬࠤํอไอัํำฮࠦวๅฯๆ์๊๐ษ๊ࠡส่฿๐ัࠡฯๆ์๊๐ษ๊่๊ࠡࠥาๅ๋฻ࠣำํ๊ࠠศๆ฼ห้๋ࠠฬ็ࠣฮ๊ࠦส้ฯํำ์อ้ࠠฯึหอࠦวๅ็฼ำ้ࠦอิสࠣื่อๆࠡั๋่ࠥอไฺษ็้๊ࠥำ็หࠣ࠶࠵࠸࠱๊๊ࠡ๎ࠥอไฦฯุหห๐ษࠡษ็วาีห๊ࠡส่ศฺๅๅࠢส่ฯ๐ࠠห็ࠣ฽๊๊็ศࠢไ๎ࠥอไิ่๋หฯࠦวๅ฻ืีฮࠦวๅ็สฺ๏ฯࠧḪ")
	hwAK5bC7pHoU6VrSdgsvM += uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࡨࡵࡶࡳࡷ࠿࠵࠯ࡵ࡫ࡱࡽ࠳ࡩࡣ࠰ࡵ࡫࡭ࡦࡩ࡯ࡶࡰࡷ࡟࠴ࡉࡏࡍࡑࡕࡡࠬḫ")
	cE6OHoADvlhK1gVy2p8rYbWXFmGQ = tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢฮั็ษ่ะฺࠥัู๋ࠣห้๋ำๅ็ࠣ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧḬ")
	cE6OHoADvlhK1gVy2p8rYbWXFmGQ += YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠫ์๎ฺࠠสสีฮูࠦ็ࠢหี๋อๅอࠢํ์ๆืࠠๆ฻็์๊อสࠡฯึหอ๐ษࠡๅฮ๎ึฯࠠห้่ࠤัฺ๋๊ࠢสู่๊ไๆ์้ࠤ๊ัไࠡล๋ๆฬะࠠศๆุ่ฬฯ้ࠠล๋ๆฬะࠠศๆๆืํ็้ࠠษ็าุ๎แ๊ࠡื็้ࠦวๅไ่ีࠥ๎ร้ไสฮࠥอไใ็ิࠤํษ๊ืษࠣ๎ํ็ัࠡำว๎ฮࠦวๅ้็ห้ࠦแ๋ࠢฯ้๏฿ࠠะ๊็ࠤฬู๊ศๆ่ࠤํษ๊ืษࠣๅ๏ํࠠหไ๋๎๊ࠦๅ๋ๆสำ๏่่ࠦฮิ๎ࠥ๎แ๋้ࠣว๏฼วࠡสะฯࠥ๎โาษฤอࠥอไใำล๊ࠥ๎รุ๋สࠤๆ๐็ࠡษึฮำอัส๋ࠢฮๆอฤๅ๋ࠢๅ๏ํࠠฤไ๋ห้ࠦๅ็ี๋ฬฮࠦไๅล่หู๊ࠦๅ์ࠣ์ศ๋่าࠢฦาึ๏ࠠห้่ࠤ่๊ࠠๆี็้ࠥ࠴ࠠศๆหี๋อๅอ่ࠢ็ฯ๎ศࠡส็฾ฮࠦฬศใสࠤุ้ัษฬࠣ์๏ูสฯั่ࠤ๋฾วๆ๋ࠢ๎๋ี่ำࠢอัฯࠦศ๋ศฬࠤํ๐ๆะ๊ีࠤ่อฬ๋ฬࠣ์๊ิีึࠢไๆ฼ࠦไฤฮ๊ึฮࠦวๅ๊ํ๊ิ๎าࠡ࠰ࠣห้๋่ใ฻ࠣห้ืำๆ์่้ࠣฮั็ษ่ะࠥํ่ࠨḭ")
	cE6OHoADvlhK1gVy2p8rYbWXFmGQ += tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡲࡻࡳ࡭࡫ࡰࡶࡺࡲࡥࡳ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪḮ")
	maCNIYkc0HOiEGpL3g = FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࡛࠭ࡓࡖࡏࡡࠬḯ")+hwAK5bC7pHoU6VrSdgsvM+YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠧ࡝ࡰ࡟ࡲࡡࡴ࡛ࡓࡖࡏࡡࠬḰ")+cE6OHoADvlhK1gVy2p8rYbWXFmGQ
	Dkp5YTLQijOEKF(S26SnaqcM9XwK8PVphJDv5(u"ࠨࡴ࡬࡫࡭ࡺࠧḱ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠩࠪḲ"),maCNIYkc0HOiEGpL3g)
	return
def ALWQsFjmi7zIw8b(nHKoSC1PiDe8RFambXd7wGf):
	qmcQKkuhliSZRJUC(nHKoSC1PiDe8RFambXd7wGf,I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࡈࡤࡰࡸ࡫ગ"))
	WmSFUq5gTRr13 = ORXquBZQ8x2wnWveHtYdCTyU(nHKoSC1PiDe8RFambXd7wGf)
	id,gg6VwuY0xOi7,yTJXbEc9LjmfVRD0N2F,gqf9tEKLQN2J6bAUr0ivHIOSD,n8g9KIdWMyTi2JDkvEfBA6,reason = WmSFUq5gTRr13[CgPbwXm1RilpJUSGHLhy(u"࠶ਝ")]
	hhybuQfnOXm,EUYp7Rs8FNn3eokvSx4h = gqf9tEKLQN2J6bAUr0ivHIOSD.split(bbqAtUz36RPGVTvCkejpJXQB(u"ࠪࡠࡳࡁ࠻ࠨḳ"))
	cE6OHoADvlhK1gVy2p8rYbWXFmGQ,YOTH54N3yLc9K,fjvEc6Ayo9UrIXKJLzaBPR12eM = n8g9KIdWMyTi2JDkvEfBA6.split(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠫࡡࡴ࠻࠼ࠩḴ"))
	BNTIinZd5mDsMu1wCUxFo3 = EAw9bg4rT3Bd8tjSkO(u"ࡗࡶࡺ࡫ઘ")
	while BNTIinZd5mDsMu1wCUxFo3:
		xSeZLDFIhu6PQ4wgmk3rVqJEvp859 = m5NUYqBzGynIOeAg8(GGCQK6OAtZUXRhvkgJm(u"ࠬ࠭ḵ"),CIcPowhneWs5tN3(u"࠭ฮา๊ฯࠫḶ"),Gk98CL5nXZEN(u"ࠧฦำึห้ࠦัิษ็อ๊ࠥไๆสิ้ั࠭ḷ"),S26SnaqcM9XwK8PVphJDv5(u"ࠨไสส๊ฯࠠศๆอฬึ฿วหࠩḸ"),QmoEjB3hLIw(u"ࠩ็ษ๏่วโࠢส่ส฿ไศ่สฮࠥࡀࠠࠡฬหี฾ࠦร้ࠢสุ้ำࠠศๆหี๋อๅอࠩḹ"),cE6OHoADvlhK1gVy2p8rYbWXFmGQ)
		if xSeZLDFIhu6PQ4wgmk3rVqJEvp859==bbqAtUz36RPGVTvCkejpJXQB(u"࠲ਞ"): D7EuCtGyqXLrknHK = m5NUYqBzGynIOeAg8(GGCQK6OAtZUXRhvkgJm(u"ࠪࠫḺ"),MM564HfnUV0XIR(u"ࠫࠬḻ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠬ฿่ะหࠪḼ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠭ࠧḽ"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠧๆสาวࠥอไหสิ฽ࠥเ๊าࠢๅหอ๊ࠠๅๆ้ๆฬฺࠧḾ"),YOTH54N3yLc9K,NxsKJnLFEZ9OHXf1h(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࠬḿ"))
		elif xSeZLDFIhu6PQ4wgmk3rVqJEvp859==cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠲ਟ"): oOmLC8y1REg()
		else: BNTIinZd5mDsMu1wCUxFo3 = bbqAtUz36RPGVTvCkejpJXQB(u"ࡊࡦࡲࡳࡦઙ")
	oos8ymFi9CN2z1jXcR.executebuiltin(bbqAtUz36RPGVTvCkejpJXQB(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭Ṁ"))
	return
def jMFdvr1ns4NBIYE23Qg(showDialogs):
	A5vgi1F6qVunZMas2Nf = Gk98CL5nXZEN(u"࡙ࡸࡵࡦચ")
	if showDialogs: A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(qFRrj7ayBKbOsHGSXz(u"ࠪࡧࡪࡴࡴࡦࡴࠪṁ"),dEUYJjrhsaPXNo(u"ࠫࠬṂ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠬ࠭ṃ"),CIcPowhneWs5tN3(u"࠭ำลษ็ࠫṄ"),ta478EuZQJIWhgBnsf6iU(u"่ࠧๆࠣว๋ะࠠๆฬฦ็ิ่ࠦหำํำ๋ࠥำฮ๋ࠢฮฺ็๊าࠢฯ้๏฿ࠠฦ฻าหิอสࠡสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠤ࠳ࠦอ๋อࠣฮ฾๎ฯࠡฮ่๎฾ࠦวๅว฼ำฬีวหࠢศ่๎่ࠦื฻ํอࠥะหษ์อࠤฬ๊ศา่ส้ัࠦฟࠨṅ"))
	if A5vgi1F6qVunZMas2Nf:
		VZHWjJTrAPKG1eLEsxpYo2tS5 = uAl3gHavMJZL4xmNe62nDiBoQ(u"࡚ࡲࡶࡧછ")
		if K3hFytImeYMkJBC.path.exists(whvA2b4mnJBjlICZ6ipPeHuD):
			try: K3hFytImeYMkJBC.remove(whvA2b4mnJBjlICZ6ipPeHuD)
			except: VZHWjJTrAPKG1eLEsxpYo2tS5 = GGCQK6OAtZUXRhvkgJm(u"ࡆࡢ࡮ࡶࡩજ")
		if showDialogs:
			if VZHWjJTrAPKG1eLEsxpYo2tS5: tehb3k5a2PufGOdBIUw8j(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠨࠩṆ"),smpniPDOhfwI3H4v7c6TG(u"ࠩࠪṇ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠪࠫṈ"),WbM6qAjrn7fEXGZw(u"ࠫฯ๋ࠠษ่ฯหาࠦๅิฯࠣ์ฯ฻แ๋ำ้้ࠣ็ࠠฦ฻าหิอสࠡสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠫṉ"))
			else: tehb3k5a2PufGOdBIUw8j(Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠬ࠭Ṋ"),FeyZbj8tDil0nSHzTwfsUJ9(u"࠭ࠧṋ"),ItgK5FqGDz2Rf7mAJkbT(u"ࠧࠨṌ"),qFRrj7ayBKbOsHGSXz(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็็ๅࠥอไฦ฻าหิอสࠨṍ"))
	return
def xBGISRPJ3kXowclp4Emf():
	PxmphrKe7N8oE()
	HAi7QRdpO0WXv = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(wx18CTJPZ5(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨṎ"))
	maCNIYkc0HOiEGpL3g = {}
	maCNIYkc0HOiEGpL3g[tOdiG2HWFRBXg1sUh(u"ࠪࡅ࡚࡚ࡏࠨṏ")] = WbM6qAjrn7fEXGZw(u"ࠫฬ๊ใศึࠣห้ะไใษษ๎ࠥ๐ูๆๆࠪṐ")
	maCNIYkc0HOiEGpL3g[NxsKJnLFEZ9OHXf1h(u"࡙ࠬࡔࡐࡒࠪṑ")] = CIcPowhneWs5tN3(u"࠭วๅๅสุ๋ࠥส้ไไࠤฯ๋วๆษࠣ์ออไไษ่่ࠬṒ")
	maCNIYkc0HOiEGpL3g[CIcPowhneWs5tN3(u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨṓ")] = EAw9bg4rT3Bd8tjSkO(u"ࠨๅสุࠥาฯศࠢๅู๏ืࠠศๆ่ำ๎ࠦ࠮ࠡࠩṔ")+str(ddEW38kMhf9mZGC6ePnFS/MM564HfnUV0XIR(u"࠸࠳ਠ"))+CIcPowhneWs5tN3(u"ࠩࠣำ็๐โสࠢไๆ฼࠭ṕ")
	ZWc68NwkfLndI = maCNIYkc0HOiEGpL3g[HAi7QRdpO0WXv]
	A4rSxVHK9Dfieob8B7 = m5NUYqBzGynIOeAg8(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠪࠫṖ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"่ࠫอิࠡࠩṗ")+str(ddEW38kMhf9mZGC6ePnFS/S26SnaqcM9XwK8PVphJDv5(u"࠹࠴ਡ"))+S26SnaqcM9XwK8PVphJDv5(u"ࠬࠦฯใ์ๅอࠬṘ"),r6juULGQtnExAko38BZ5Y(u"࠭สี฼ํ่ࠥะไใษษ๎ࠬṙ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠧฦ์ๅหๆࠦใศ็็ࠫṚ"),ZWc68NwkfLndI,FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠨ้็ࠤฯื๊ะࠢสืฯิฯศ็ࠣห้้วีࠢส่ี้๊ࠡษ็ฮ้่วว์ࠣว๊ࠦสา์าࠤส๐โศใࠣห้้วีࠢหห้้วๆๆࠣว๊ࠦสา์าࠤ่อิࠡ฻่ี์ࠦโึ์ิࠤัีวࠡมࠤࠫṛ"))
	if A4rSxVHK9Dfieob8B7==YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠴ਢ"): qqzNHSoOB9dTR3Mhc = ta478EuZQJIWhgBnsf6iU(u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪṜ")
	elif A4rSxVHK9Dfieob8B7==CIcPowhneWs5tN3(u"࠶ਣ"): qqzNHSoOB9dTR3Mhc = QmoEjB3hLIw(u"ࠪࡅ࡚࡚ࡏࠨṝ")
	elif A4rSxVHK9Dfieob8B7==smpniPDOhfwI3H4v7c6TG(u"࠸ਤ"): qqzNHSoOB9dTR3Mhc = cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠫࡘ࡚ࡏࡑࠩṞ")
	else: qqzNHSoOB9dTR3Mhc = CIcPowhneWs5tN3(u"ࠬ࠭ṟ")
	if qqzNHSoOB9dTR3Mhc:
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(S26SnaqcM9XwK8PVphJDv5(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬṠ"),qqzNHSoOB9dTR3Mhc)
		o5P2DHhvMBQ = maCNIYkc0HOiEGpL3g[qqzNHSoOB9dTR3Mhc]
		tehb3k5a2PufGOdBIUw8j(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠧࠨṡ"),ta478EuZQJIWhgBnsf6iU(u"ࠨࠩṢ"),QmoEjB3hLIw(u"ࠩࠪṣ"),o5P2DHhvMBQ)
	return
def dV6hQJU0GSWInHDiv5k7yaMb():
	maCNIYkc0HOiEGpL3g = {}
	maCNIYkc0HOiEGpL3g[FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠪࡅ࡚࡚ࡏࠨṤ")] = CIcPowhneWs5tN3(u"ุࠫ๐ัโำࠣࡈࡓ࡙ࠠศๆอ่็อฦ๋ࠢํ฽๊๊࠺ࠡࠩṥ")
	maCNIYkc0HOiEGpL3g[smpniPDOhfwI3H4v7c6TG(u"ࠬࡇࡓࡌࠩṦ")] = CgPbwXm1RilpJUSGHLhy(u"࠭ำ๋ำไีࠥࡊࡎࡔࠢึ๎฾๋ไࠡส฼ำࠥอไิ็สั๊ࠥ็࠻ࠢࠪṧ")
	maCNIYkc0HOiEGpL3g[NNmirJKPp5nWjfC(u"ࠧࡔࡖࡒࡔࠬṨ")] = tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠨีํีๆืࠠࡅࡐࡖࠤ๊ะ่ใใࠣฮ๊อๅศ๋ࠢฬฬ๊ใศ็็ࠫṩ")
	ng12yIQNjqdfFiYUBlzaWDpS = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(Gk98CL5nXZEN(u"ࠩࡤࡺ࠳ࡪ࡮ࡴࠩṪ"))
	HAi7QRdpO0WXv = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(ItgK5FqGDz2Rf7mAJkbT(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ṫ"))
	ZWc68NwkfLndI = maCNIYkc0HOiEGpL3g[HAi7QRdpO0WXv]+ng12yIQNjqdfFiYUBlzaWDpS
	A4rSxVHK9Dfieob8B7 = m5NUYqBzGynIOeAg8(WbM6qAjrn7fEXGZw(u"ࠫࠬṬ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠬะิ฻์็ࠤ฾์ฯࠡษ็้ํอแใหࠪṭ"),r6juULGQtnExAko38BZ5Y(u"࠭สี฼ํ่ࠥะไใษษ๎ࠬṮ"),CgPbwXm1RilpJUSGHLhy(u"ࠧฦ์ๅหๆࠦใศ็็ࠫṯ"),ZWc68NwkfLndI,S26SnaqcM9XwK8PVphJDv5(u"ࠨีํีๆืࠠࡅࡐࡖࠤ์๎ࠠอ้สึࠥ็๊ࠡษ็ษ๋ะั็์อࠤ๏่่ๆࠢหฮา๎๊ๅࠢฦื๊อมࠡษ็้ํอโฺ๋ࠢหู้๊าใิหฯࠦลๅ๋ࠣวึ่วๆ๋ࠢ฽๋ีࠠษ฻ูࠤฬ๊ๆศีࠣ๎็๎ๅࠡสะะอ่ࠦๆ่฼ࠤํำึาࠢห฽฻ࠦวๅ็๋ห็฿ࠠ࠯ࠢ็ฮูเ๊ๅࠢึ๎ึ็ัࠡࡆࡑࡗ่ࠥๅࠡสสาฯ๐วาࠢสุ่๐ัโำࠣห้๋ๆศีหࠤศ๎ࠠใ็ࠣฬส๐โศใ๊ࠤออไไษ่่ࠬṰ"))
	if A4rSxVHK9Dfieob8B7==ItgK5FqGDz2Rf7mAJkbT(u"࠰ਥ"): qqzNHSoOB9dTR3Mhc = tOdiG2HWFRBXg1sUh(u"ࠩࡄࡗࡐ࠭ṱ")
	elif A4rSxVHK9Dfieob8B7==dEUYJjrhsaPXNo(u"࠲ਦ"): qqzNHSoOB9dTR3Mhc = cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠪࡅ࡚࡚ࡏࠨṲ")
	elif A4rSxVHK9Dfieob8B7==zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠴ਧ"): qqzNHSoOB9dTR3Mhc = I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠫࡘ࡚ࡏࡑࠩṳ")
	if A4rSxVHK9Dfieob8B7 in [zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠴਩"),qFRrj7ayBKbOsHGSXz(u"࠴ਨ")]:
		A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(S26SnaqcM9XwK8PVphJDv5(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬṴ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠭ำ๋ำไี࠿ࠦࠧṵ")+y4Be6ljV9o7DNAdFO0aQtWpY[QmoEjB3hLIw(u"࠶ਪ")],bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠧิ์ิๅึࡀࠠࠨṶ")+y4Be6ljV9o7DNAdFO0aQtWpY[CgPbwXm1RilpJUSGHLhy(u"࠶ਫ")],S26SnaqcM9XwK8PVphJDv5(u"ࠨࠩṷ"),Gk98CL5nXZEN(u"ࠩฦาฯอัࠡีํีๆืࠠࡅࡐࡖࠤฬ๊ๅ็ษึฬ๊ࠥใࠨṸ"))
		if A5vgi1F6qVunZMas2Nf==SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠱ਬ"): OOQ8Kp1tByMuUr5qAeI6xoaYsFgTh = y4Be6ljV9o7DNAdFO0aQtWpY[tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠱ਭ")]
		else: OOQ8Kp1tByMuUr5qAeI6xoaYsFgTh = y4Be6ljV9o7DNAdFO0aQtWpY[CgPbwXm1RilpJUSGHLhy(u"࠳ਮ")]
	elif A4rSxVHK9Dfieob8B7==I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠵ਯ"): OOQ8Kp1tByMuUr5qAeI6xoaYsFgTh = MM564HfnUV0XIR(u"ࠪࠫṹ")
	else: qqzNHSoOB9dTR3Mhc = Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠫࠬṺ")
	if qqzNHSoOB9dTR3Mhc:
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(dEUYJjrhsaPXNo(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨṻ"),qqzNHSoOB9dTR3Mhc)
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠭ࡡࡷ࠰ࡧࡲࡸ࠭Ṽ"),OOQ8Kp1tByMuUr5qAeI6xoaYsFgTh)
		o5P2DHhvMBQ = maCNIYkc0HOiEGpL3g[qqzNHSoOB9dTR3Mhc]+OOQ8Kp1tByMuUr5qAeI6xoaYsFgTh
		tehb3k5a2PufGOdBIUw8j(EAw9bg4rT3Bd8tjSkO(u"ࠧࠨṽ"),EAw9bg4rT3Bd8tjSkO(u"ࠨࠩṾ"),QmoEjB3hLIw(u"ࠩࠪṿ"),o5P2DHhvMBQ)
	return
def tpqgd0BSAV4LnxEasiUr():
	HAi7QRdpO0WXv = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨẀ"))
	maCNIYkc0HOiEGpL3g = {}
	maCNIYkc0HOiEGpL3g[FeyZbj8tDil0nSHzTwfsUJ9(u"ࠫࡆ࡛ࡔࡐࠩẁ")] = MM564HfnUV0XIR(u"ࠬอไษำ๋็ุ๐ࠠศๆอ่็อฦ๋ࠢฯห์ุࠠๅๆ฼้้࠭Ẃ")
	maCNIYkc0HOiEGpL3g[EAw9bg4rT3Bd8tjSkO(u"࠭ࡁࡔࡍࠪẃ")] = cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠧศๆหีํ้ำ๋ࠢึ๎฾๋ไࠡส฼ำࠥอไิ็สั๊ࠥ็ࠨẄ")
	maCNIYkc0HOiEGpL3g[Kwl07iYTtDLN3zP(u"ࠨࡕࡗࡓࡕ࠭ẅ")] = YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠩส่อื่ไีํࠤ๊ะ่ใใࠣฮ๊อๅศ๋ࠢฬฬ๊ใศ็็ࠫẆ")
	ZWc68NwkfLndI = maCNIYkc0HOiEGpL3g[HAi7QRdpO0WXv]
	A4rSxVHK9Dfieob8B7 = m5NUYqBzGynIOeAg8(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠪࠫẇ"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠫฯฺฺ๋ๆࠣ฽๋ีࠠศๆ่์ฬ็โสࠩẈ"),MM564HfnUV0XIR(u"ࠬะิ฻์็ࠤฯ๊โศศํࠫẉ"),NxsKJnLFEZ9OHXf1h(u"࠭ล๋ไสๅ้ࠥวๆๆࠪẊ"),ZWc68NwkfLndI,YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠧศๆหีํ้ำ๋๊ࠢ์ࠥา็ศิࠣๅ๏ࠦวๅว้ฮึ์๊หࠢํ฽๊๊้ࠠีํ฻ࠥฮ๊็ࠢฯ๋ฬุใ๊ࠡส่ส์สา่ํฮࠥ࠴่๊ࠠࠣ๎ุะไๆฺ่ࠢออสไ๋ࠢ๎็๎ๅࠡสึัอํวࠡสา่ฬࠦๅ็ๅࠣฯ๊๊ࠦษ฻ฮ๋ฬࠦไไࠢ࠱ࠤ์๊ࠠหำํำࠥะิ฻์็ࠤศ๋ࠠฦ์ๅหๆࠦวๅสิ์ู่๊ࠡมࠪẋ"))
	if A4rSxVHK9Dfieob8B7==dEUYJjrhsaPXNo(u"࠴ਰ"): qqzNHSoOB9dTR3Mhc = QmoEjB3hLIw(u"ࠨࡃࡖࡏࠬẌ")
	elif A4rSxVHK9Dfieob8B7==NNmirJKPp5nWjfC(u"࠶਱"): qqzNHSoOB9dTR3Mhc = dEUYJjrhsaPXNo(u"ࠩࡄ࡙࡙ࡕࠧẍ")
	elif A4rSxVHK9Dfieob8B7==bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠸ਲ"): qqzNHSoOB9dTR3Mhc = Kwl07iYTtDLN3zP(u"ࠪࡗ࡙ࡕࡐࠨẎ")
	else: qqzNHSoOB9dTR3Mhc = zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠫࠬẏ")
	if qqzNHSoOB9dTR3Mhc:
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(dEUYJjrhsaPXNo(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪẐ"),qqzNHSoOB9dTR3Mhc)
		o5P2DHhvMBQ = maCNIYkc0HOiEGpL3g[qqzNHSoOB9dTR3Mhc]
		tehb3k5a2PufGOdBIUw8j(GGCQK6OAtZUXRhvkgJm(u"࠭ࠧẑ"),tOdiG2HWFRBXg1sUh(u"ࠧࠨẒ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠨࠩẓ"),o5P2DHhvMBQ)
	return
def khSdoYQ3VOItlx():
	pcynmtuZQY = if2qpOxlZd8MBGeo5uNIyLEsz.getSetting(I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥ࡯ࡷࡶࡧࡦࡩࡨࡦࠩẔ"))
	if pcynmtuZQY==cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠪࡗ࡙ࡕࡐࠨẕ"): header = wx18CTJPZ5(u"ࠫฯิา๋่ࠣห้่่ศศ่ࠤ๊ะ่ใใࠪẖ")
	else: header = NNmirJKPp5nWjfC(u"ࠬะฮำ์้ࠤฬ๊โ้ษษ้๋ࠥแฺๆࠪẗ")
	A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(qFRrj7ayBKbOsHGSXz(u"࠭ࠧẘ"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠧฦ์ๅหๆ࠭ẙ"),wx18CTJPZ5(u"ࠨฬไ฽๏๊ࠧẚ"),header,dEUYJjrhsaPXNo(u"ࠩๅ์ฬฬๅࠡษ็ฬึ์วๆฮࠣ๎ฯ๋ࠠหฯา๎ะํวࠡล๋ฮํ๋วห์ๆ๎ฬࠦศฺัࠣ࠵࠻ࠦำศ฻ฬࠤ๊์ࠠฤ๊็ࠤศูสฯัส้ࠥ࠴࠮๊ࠡศ๎็อแࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠡ์วำ๏ࠦลๅ๋ࠣฮาี๊ฬ้สࠤๆ๐ࠠไๆ้ࠣึฯ๋ࠠฬ่ࠤฬูสฯัส้ࠥอไใ๊สส๊ࠦ࠮࠯๋๋ࠢีอ๋ࠠีหฬࠥฮืวࠢไ๎ࠥ็สฮࠢๅ์ฬฬๅࠡษ็ฬึ์วๆฮ࡟ࡲࡡࡴ่ࠠๆࠣฮึ๐ฯࠡฬไ฽๏๊ࠠฤ็ࠣษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠢยࠥࠦ࠭ẛ"))
	if A5vgi1F6qVunZMas2Nf==-zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠱ਲ਼"): return
	elif A5vgi1F6qVunZMas2Nf:
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(dEUYJjrhsaPXNo(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡨࡧࡣࡩࡧࠪẜ"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࠫࡆ࡛ࡔࡐࠩẝ"))
		tehb3k5a2PufGOdBIUw8j(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠬ࠭ẞ"),QmoEjB3hLIw(u"࠭ࠧẟ"),ta478EuZQJIWhgBnsf6iU(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪẠ"),EAw9bg4rT3Bd8tjSkO(u"ࠨฬ่ࠤฯ็ู๋ๆࠣฮำุ๊็ࠢส่็๎วว็ࠪạ"))
	else:
		if2qpOxlZd8MBGeo5uNIyLEsz.setSetting(Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥ࡯ࡷࡶࡧࡦࡩࡨࡦࠩẢ"),ta478EuZQJIWhgBnsf6iU(u"ࠪࡗ࡙ࡕࡐࠨả"))
		tehb3k5a2PufGOdBIUw8j(Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠫࠬẤ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠬ࠭ấ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩẦ"),GGCQK6OAtZUXRhvkgJm(u"ࠧห็ࠣษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠩầ"))
	return
def kMcIXRenKqHmT(RxgdTHfDar8EXt):
	if RxgdTHfDar8EXt!=QmoEjB3hLIw(u"ࠨࠩẨ"):
		RxgdTHfDar8EXt = UdhlykB6XfC5NZVqORE0IQY(RxgdTHfDar8EXt)
		RxgdTHfDar8EXt = RxgdTHfDar8EXt.decode(CIcPowhneWs5tN3(u"ࠩࡸࡸ࡫࠾ࠧẩ")).encode(cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠪࡹࡹ࡬࠸ࠨẪ"))
		eCKaqGS2vs7bQ8cTZW = QmoEjB3hLIw(u"࠲࠲࠴࠴࠸਴")
		Yy2HOceDK9u = ZuEAJR1lNHkUf0.Window(eCKaqGS2vs7bQ8cTZW)
		Yy2HOceDK9u.getControl(CgPbwXm1RilpJUSGHLhy(u"࠵࠴࠵ਵ")).setLabel(RxgdTHfDar8EXt)
	return
SJbG23Yr8Ag = [
			 NNmirJKPp5nWjfC(u"ࠦࡪࡾࡴࡦࡰࡶ࡭ࡴࡴࠠࠨࠩࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡧࡺࡸࡲࡦࡰࡷࡰࡾࠦࡳࡶࡲࡳࡳࡷࡺࡥࡥࠤẫ")
			,tOdiG2HWFRBXg1sUh(u"ࠬࡉࡨࡦࡥ࡮࡭ࡳ࡭ࠠࡧࡱࡵࠤࡒࡧ࡬ࡪࡥ࡬ࡳࡺࡹࠠࡴࡥࡵ࡭ࡵࡺࡳࠨẬ")
			,YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠭ࡐࡗࡔࠣࡍࡕ࡚ࡖࠡࡕ࡬ࡱࡵࡲࡥࠡࡅ࡯࡭ࡪࡴࡴࠨậ")
			,WbM6qAjrn7fEXGZw(u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡘ࡬ࡨࡪࡵࠠࡊࡰࡩࡳࠥࡑࡥࡺࠩẮ")
			,uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠨࡶ࡫࡭ࡸࠦࡨࡢࡵ࡫ࠤ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࠦࡩࡴࠢࡥࡶࡴࡱࡥ࡯ࠩắ")
			,Gk98CL5nXZEN(u"ࠩࡸࡷࡪࡹࠠࡱ࡮ࡤ࡭ࡳࠦࡈࡕࡖࡓࠤ࡫ࡵࡲࠡࡣࡧࡨ࠲ࡵ࡮ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡶࠫẰ")
			,CIcPowhneWs5tN3(u"ࠪࡥࡩࡼࡡ࡯ࡥࡨࡨ࠲ࡻࡳࡢࡩࡨ࠲࡭ࡺ࡭࡭ࠩằ")+Gk98CL5nXZEN(u"ࠫࠨ࠭Ẳ")+bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠬࡹࡳ࡭࠯ࡺࡥࡷࡴࡩ࡯ࡩࡶࠫẳ")
			,qFRrj7ayBKbOsHGSXz(u"࠭ࡉ࡯ࡵࡨࡧࡺࡸࡥࡓࡧࡴࡹࡪࡹࡴࡘࡣࡵࡲ࡮ࡴࡧ࠭ࠩẴ")
			,YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠧࡆࡴࡵࡳࡷࠦࡧࡦࡶࡷ࡭ࡳ࡭ࠠࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄ࠰ࡁࡰࡳࡩ࡫ࡥ࠾࠲ࠩࡸࡪࡾࡴࡵ࠿ࠪẵ")
			,MM564HfnUV0XIR(u"ࠨࡹࡤࡶࡳ࡯࡮ࡨࡵ࠱ࡻࡦࡸ࡮ࠩࠩẶ")
			,tOdiG2HWFRBXg1sUh(u"ࠩࡡࡢࡣࡤ࡞ࠨặ")
			,uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠪࡐࡴࡧࡤࡪࡰࡪࠤࡸࡱࡩ࡯ࠢࡩ࡭ࡱ࡫࠺ࠨẸ")
			]
def QExlAjIJGByHs6O3wK4nCF0omc(Fj1YUPiHsabvulW30mzZ):
	if S26SnaqcM9XwK8PVphJDv5(u"ࠫࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡹ࡫ࡪࡰࠣࡪ࡮ࡲࡥ࠻ࠩẹ") in Fj1YUPiHsabvulW30mzZ and YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪẺ") in Fj1YUPiHsabvulW30mzZ: return CgPbwXm1RilpJUSGHLhy(u"ࡕࡴࡸࡩઝ")
	for RxgdTHfDar8EXt in SJbG23Yr8Ag:
		if RxgdTHfDar8EXt in Fj1YUPiHsabvulW30mzZ: return cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࡖࡵࡹࡪઞ")
	return GGCQK6OAtZUXRhvkgJm(u"ࡉࡥࡱࡹࡥટ")
def BKLljptvaWgVrc(data):
	data = data.replace(Kwl07iYTtDLN3zP(u"࠭࡜ࡳ࡞ࡱࠫẻ")+tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠸࠵ਸ਼")*S26SnaqcM9XwK8PVphJDv5(u"ࠧࠡࠩẼ")+I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠨ࡞ࡵࡠࡳ࠭ẽ"),S26SnaqcM9XwK8PVphJDv5(u"ࠩ࡟ࡶࡡࡴࠧẾ"))
	data = data.replace(MM564HfnUV0XIR(u"ࠪࡠࡳ࠭ế")+YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠹࠶਷")*r6juULGQtnExAko38BZ5Y(u"ࠫࠥ࠭Ề")+MM564HfnUV0XIR(u"ࠬࡢࡲ࡝ࡰࠪề"),ItgK5FqGDz2Rf7mAJkbT(u"࠭࡜ࡳ࡞ࡱࠫỂ"))
	data = data.replace(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠧ࡝ࡰࠪể")+MM564HfnUV0XIR(u"࠺࠷ਸ")*Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠨࠢࠪỄ")+bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠩ࡟ࡲࠬễ"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠪࡠࡳ࠭Ệ"))
	data = data.replace(I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠫࡡࡴࠧệ")+YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠵࠲਺")*I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠬࠦࠧỈ"),bbqAtUz36RPGVTvCkejpJXQB(u"࠭࡜࡯ࠩỉ")+uAl3gHavMJZL4xmNe62nDiBoQ(u"࠹࠱ਹ")*FeyZbj8tDil0nSHzTwfsUJ9(u"ࠧࠡࠩỊ"))
	data = data.replace(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠨࠢ࠿࡫ࡪࡴࡥࡳࡣ࡯ࡂ࠿ࠦࠧị"),ta478EuZQJIWhgBnsf6iU(u"ࠩ࠽ࠤࠬỌ"))
	bhfgckoLVtsA2DXv = cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠪࠫọ")
	for Fj1YUPiHsabvulW30mzZ in data.splitlines():
		t6tugqvD8w9KJ42zfh13 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠫࠥࠦࠠࠡࠢࡉ࡭ࡱ࡫ࠠࠣࠪ࠱࠮ࡄࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠱࠭ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪỎ"),Fj1YUPiHsabvulW30mzZ,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if t6tugqvD8w9KJ42zfh13: Fj1YUPiHsabvulW30mzZ = Fj1YUPiHsabvulW30mzZ.replace(t6tugqvD8w9KJ42zfh13[wx18CTJPZ5(u"࠱਻")],ta478EuZQJIWhgBnsf6iU(u"ࠬ࠭ỏ"))
		bhfgckoLVtsA2DXv += FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠭࡜࡯ࠩỐ")+Fj1YUPiHsabvulW30mzZ
	return bhfgckoLVtsA2DXv
def ihuLTZmH4vBO5etr2xIob0CpX(VVJbcqLw78FU5E4r6CAz):
	if wx18CTJPZ5(u"ࠧࡐࡎࡇࠫố") in VVJbcqLw78FU5E4r6CAz:
		ZPw9RHgi4al86u5rGOACtnLbMsmhD1 = kk2pAdfSq8i7jmH6VhtgFLsGzYM
		header = CIcPowhneWs5tN3(u"ࠨไิหฦฯࠠศๆึะ้ࠦวๅไา๎๊ࠦฟࠨỒ")
	else:
		ZPw9RHgi4al86u5rGOACtnLbMsmhD1 = g0gdkA6VTy9mGtLch
		header = EAw9bg4rT3Bd8tjSkO(u"ࠩๅีฬวษࠡษ็ืั๊ࠠศๆะห้๐ࠠภࠩồ")
	A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(bbqAtUz36RPGVTvCkejpJXQB(u"ࠪࠫỔ"),smpniPDOhfwI3H4v7c6TG(u"ࠫࠬổ"),Gk98CL5nXZEN(u"ࠬ࠭Ỗ"),header,dEUYJjrhsaPXNo(u"࠭ำอๆࠣห้ษฮุษฤࠤ๏ำส้์ࠣว๏฼วࠡ฻็ํูࠥฬๅࠢส่ฬูสฯัส้ࠥ࠴้ࠠษ็หะ์๊็ูࠢีํื๊สࠢ็้฾ืแสࠢๆ๎ๆࠦอะออࠤฬ๊ๅีๅ็อࠥ๎ๅศ๊ࠢ์ࠥอไๆๅส๊ࠥอไั์ࠣือฮࠠฮั๋ฯࠥอไๆึๆ่ฮࠦ࠮ࠡๅ๋ำ๏๊ࠦฮฬไ฼ࠥฮำอๆํ๊ࠥ࠴ࠠศๆฦ์้ࠦ็้ࠢสุ่าไࠡษ็ัฬ๊๊๊ࠡไ๎์ࠦๅฺๆ๋้ฬะࠠหสาว๋ࠥๆัࠢหำฬ๐ษࠡษ็ฮูเ๊ๅࠢส่าอไ๋ࠢ็ฬึ์วๆฮࠣ็ํี๊๊ࠡส่๎ࠦวๅฤ้ࠤ࠳ࠦรๆษࠣหู้ฬๅࠢส่็ี๊ๆࠢไ๋ํࠦวๅีฯ่ࠥอไิษหๆࠥอไั์ࠣฮ๊ࠦฬๆ฻๊ࠤ๊์ࠠษำ้ห๊าࠠไ๊า๎่ࠥศๅࠢลาึࠦลุใสล๊ࠥ็ࠡ࠰๋้ࠣࠦสา์าࠤฬ๊วิฬ่ีฬืࠠภࠩỗ"))
	if A5vgi1F6qVunZMas2Nf!=Ox8k6IdtuPaG3NlApQK52oYwM(u"࠳਼"): return
	jDopXBZ0k9CisWhbflIr,VVPq2W7SsGEDkZCo = [],SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠳਽")
	size,count = Jy1ZPox93TVNYnKLzHvka(ZPw9RHgi4al86u5rGOACtnLbMsmhD1)
	file = open(ZPw9RHgi4al86u5rGOACtnLbMsmhD1,NNmirJKPp5nWjfC(u"ࠧࡳࡤࠪỘ"))
	if size>ItgK5FqGDz2Rf7mAJkbT(u"࠶࠶࠰࠳࠲࠳ਿ"): file.seek(-NNmirJKPp5nWjfC(u"࠵࠵࠶࠱࠱࠲ਾ"),K3hFytImeYMkJBC.SEEK_END)
	data = file.read()
	file.close()
	if wvkR1es6d0SrjxKt5FZTMUWz7a: data = data.decode(r6juULGQtnExAko38BZ5Y(u"ࠨࡷࡷࡪ࠽࠭ộ"))
	data = BKLljptvaWgVrc(data)
	Zvm7qOC8GUAFB = data.split(ta478EuZQJIWhgBnsf6iU(u"ࠩ࡟ࡲࠬỚ"))
	for Fj1YUPiHsabvulW30mzZ in reversed(Zvm7qOC8GUAFB):
		unVXp2dhIGW6fBR83Y9SeL = QExlAjIJGByHs6O3wK4nCF0omc(Fj1YUPiHsabvulW30mzZ)
		if unVXp2dhIGW6fBR83Y9SeL: continue
		Fj1YUPiHsabvulW30mzZ = Fj1YUPiHsabvulW30mzZ.replace(CgPbwXm1RilpJUSGHLhy(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡣࠬớ"),CIcPowhneWs5tN3(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪỜ"))
		Fj1YUPiHsabvulW30mzZ = Fj1YUPiHsabvulW30mzZ.replace(Gk98CL5nXZEN(u"ࠬࡋࡒࡓࡑࡕ࠾ࠬờ"),NNmirJKPp5nWjfC(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉ࠴࠵࠶࠰࡞ࡇࡕࡖࡔࡘ࠺࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩỞ"))
		BHlqZNGSRbQij8CnFVDoJ = qFRrj7ayBKbOsHGSXz(u"ࠧࠨở")
		B0lmRXOogDJyTLpFwcvNA = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠨࡠࠫࡠࡩ࠱࠭ࠩ࡞ࡧ࠯࠲ࡢࡤࠬࠢ࡟ࡨ࠰ࡀ࡜ࡥ࠭࠽ࡠࡩ࠱࡜࠯࡞ࡧ࠯࠮࠯ࠨࠡࡖ࠽ࡠࡩ࠱ࠩࠨỠ"),Fj1YUPiHsabvulW30mzZ,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if B0lmRXOogDJyTLpFwcvNA:
			Fj1YUPiHsabvulW30mzZ = Fj1YUPiHsabvulW30mzZ.replace(B0lmRXOogDJyTLpFwcvNA[YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠰ੁ")][YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠰ੁ")],B0lmRXOogDJyTLpFwcvNA[YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠰ੁ")][bbqAtUz36RPGVTvCkejpJXQB(u"࠷ੀ")]).replace(B0lmRXOogDJyTLpFwcvNA[YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠰ੁ")][QmoEjB3hLIw(u"࠳ੂ")],MM564HfnUV0XIR(u"ࠩࠪỡ"))
			BHlqZNGSRbQij8CnFVDoJ = B0lmRXOogDJyTLpFwcvNA[bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠳੄")][zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠳੃")]
		else:
			B0lmRXOogDJyTLpFwcvNA = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(wx18CTJPZ5(u"ࠪࡢ࠭ࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪỢ"),Fj1YUPiHsabvulW30mzZ,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if B0lmRXOogDJyTLpFwcvNA:
				Fj1YUPiHsabvulW30mzZ = Fj1YUPiHsabvulW30mzZ.replace(B0lmRXOogDJyTLpFwcvNA[YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠵੆")][FeyZbj8tDil0nSHzTwfsUJ9(u"࠵੅")],bbqAtUz36RPGVTvCkejpJXQB(u"ࠫࠬợ"))
				BHlqZNGSRbQij8CnFVDoJ = B0lmRXOogDJyTLpFwcvNA[NNmirJKPp5nWjfC(u"࠶ੇ")][NNmirJKPp5nWjfC(u"࠶ੇ")]
		if BHlqZNGSRbQij8CnFVDoJ: Fj1YUPiHsabvulW30mzZ = Fj1YUPiHsabvulW30mzZ.replace(BHlqZNGSRbQij8CnFVDoJ,SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨỤ")+BHlqZNGSRbQij8CnFVDoJ+ta478EuZQJIWhgBnsf6iU(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨụ"))
		jDopXBZ0k9CisWhbflIr.append(Fj1YUPiHsabvulW30mzZ)
		if len(str(jDopXBZ0k9CisWhbflIr))>tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠵࠱࠳࠳࠴ੈ"): break
	jDopXBZ0k9CisWhbflIr = reversed(jDopXBZ0k9CisWhbflIr)
	f5fmn0HG12LvdN = CgPbwXm1RilpJUSGHLhy(u"ࠧ࡝ࡰࠪỦ").join(jDopXBZ0k9CisWhbflIr)
	Dkp5YTLQijOEKF(qFRrj7ayBKbOsHGSXz(u"ࠨ࡮ࡨࡪࡹ࠭ủ"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠩลาึࠦริูิࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊࠭Ứ"),f5fmn0HG12LvdN,EAw9bg4rT3Bd8tjSkO(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡹ࡭ࡢ࡮࡯ࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭ứ"))
	return
def lNbzoSDBijRItaegyuYEx7hMqm5AsV():
	fU0TzuXSc6Dx1WJEOBFtGp98QI = open(C5D0bhw4lqvi2kzSBOnXH6myR8Zt7,MM564HfnUV0XIR(u"ࠫࡷࡨࠧỪ")).read()
	if wvkR1es6d0SrjxKt5FZTMUWz7a: fU0TzuXSc6Dx1WJEOBFtGp98QI = fU0TzuXSc6Dx1WJEOBFtGp98QI.decode(GGCQK6OAtZUXRhvkgJm(u"ࠬࡻࡴࡧ࠺ࠪừ"))
	fU0TzuXSc6Dx1WJEOBFtGp98QI = fU0TzuXSc6Dx1WJEOBFtGp98QI.replace(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠭࡜ࡵࠩỬ"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠧࠡࠢࠣࠤࠥࠦࠠࠡࠩử"))
	HUiL4nsdTt = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(FeyZbj8tDil0nSHzTwfsUJ9(u"ࠨࠪࡹࡠࡩ࠴ࠪࡀࠫ࡞ࡠࡳࡢࡲ࡞ࠩỮ"),fU0TzuXSc6Dx1WJEOBFtGp98QI,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for Fj1YUPiHsabvulW30mzZ in HUiL4nsdTt:
		fU0TzuXSc6Dx1WJEOBFtGp98QI = fU0TzuXSc6Dx1WJEOBFtGp98QI.replace(Fj1YUPiHsabvulW30mzZ,CIcPowhneWs5tN3(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬữ")+Fj1YUPiHsabvulW30mzZ+EAw9bg4rT3Bd8tjSkO(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬỰ"))
	pIq1ZYkhw0L93(ItgK5FqGDz2Rf7mAJkbT(u"ࠫฬ๊ส฻์ํีฬะࠠศๆฦา๏ืษࠡใํࠤฬ๊ศาษ่ะࠬự"),fU0TzuXSc6Dx1WJEOBFtGp98QI)
	return
def YWMgTwdIhj():
	hwAK5bC7pHoU6VrSdgsvM = Gk98CL5nXZEN(u"ࠬฮูืࠢส่ศุัศำࠣ฽้๏ࠠศๆิ๎๊๎สࠡๅ๋๊ฯื่ๅࠢอ์ๆืࠠฦ็ๆห๋๐ษࠡฬๅำ๏๋้ࠠฬฦา๏ืࠠศๆไ๎ิ๐่๊๊ࠡิ์ࠦวๅลีีฬื่ࠠ์ࠣห้ษำ่็ࠣ์ฬ๊ราไสู้๋ࠥࠡส฼ฺࠥ๎ใศๆอห้๐ࠧỲ")
	cE6OHoADvlhK1gVy2p8rYbWXFmGQ = tOdiG2HWFRBXg1sUh(u"࠭ไหไา๎๊ࠦวๅใํำ๏๎ࠠศีอาิ๋ࠠศๆึ๋๊ࠦวๅ์่๎๋่ࠦๅฬฦา๏ื็ࠡษึฮำีๅࠡษ็ื์๋ࠠศๆํืฬืࠠ࠯ࠢฦ้ฬูࠦะหࠣหุํๅࠡ็อฮฬ๊๊สࠢไ๋ีํࠠหไ๋้ࠥฮสฮำํ็ࠥอไโ์า๎ํࠦศ้ไอࠤฬ้ศา่๊ࠢࠥ๎โหࠢสุ่ํๅࠡษ็์ฬำฯࠡ࠰ࠣว๊อࠠศๆึ๋๊ࠦวๅล฼่๎่ࠦศๆฦืๆ๊ࠠโ้๋ࠤ๏ำัไࠢส่ๆ๐ฯ๋๊ࠣษ้๏ࠠศๆฦ้ฬ๋ࠠฤ๊ࠣษ้๏ࠠศๆ๋ีฬว้ࠠๆๆ๊ࠥฮโโิฬࠤ่ฮ๊าหࠪỳ")
	YOTH54N3yLc9K = dEUYJjrhsaPXNo(u"ࠧฤ็สࠤฬ๊ราไส้ࠥ็็๋ࠢอืฯิฯๆࠢ็่ฯ่ฯ๋็ࠣ์ฬ๊สฤะํีࠥ๎ไไ่ࠣฬ๊่ฯศำࠣ฽ิีࠠศๆฮ์ฬ์๊๊ࠡส่ิ่ววไࠣ࠲๋ࠥหๅษࠣี็๋ࠠ࠶࠶࠷ࠤฯ฿ๆ๋ࠢ࠸ࠤิ่ววไࠣ์ࠥ࠺࠴ࠡอส๊๏ฯࠠฦๆ์ࠤฬ๊รๆษ่ࠤศ๎ࠠฦๆ์ࠤฬ๊่าษฤࠤอำำษࠢสืฯิฯศ็ๆࠤ้๊ำ่็ࠣห้๐ๅ๋่ࠣวํࠦำ่็ࠣห้๐ำศำࠪỴ")
	maCNIYkc0HOiEGpL3g = hwAK5bC7pHoU6VrSdgsvM+Kwl07iYTtDLN3zP(u"ࠨ࠼ࠣࠫỵ")+cE6OHoADvlhK1gVy2p8rYbWXFmGQ+uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠩࠣ࠲ࠥ࠭Ỷ")+YOTH54N3yLc9K
	Dkp5YTLQijOEKF(QmoEjB3hLIw(u"ࠪࡧࡪࡴࡴࡦࡴࠪỷ"),CgPbwXm1RilpJUSGHLhy(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧỸ"),maCNIYkc0HOiEGpL3g,tOdiG2HWFRBXg1sUh(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨỹ"))
	return
def ucjsDynE7aJ(type,maCNIYkc0HOiEGpL3g,showDialogs=Gk98CL5nXZEN(u"ࡘࡷࡻࡥઠ"),url=smpniPDOhfwI3H4v7c6TG(u"࠭ࠧỺ"),dIsZG1fHm5YVkU6Puzq=bbqAtUz36RPGVTvCkejpJXQB(u"ࠧࠨỻ"),RxgdTHfDar8EXt=bbqAtUz36RPGVTvCkejpJXQB(u"ࠨࠩỼ"),chj9ifUJu1=NxsKJnLFEZ9OHXf1h(u"ࠩࠪỽ")):
	eNxAZ8Ot4P7Uqo = SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࡙ࡸࡵࡦડ")
	if not hPfgMmZC19lRiKwpN(MM564HfnUV0XIR(u"ࠪࡇ࡙ࡋ࠹ࡅࡕ࠴࠽࡛࡛࠰ࡗࡕ࡛ࠫỾ")):
		if showDialogs:
			C8p1G7VPa4E6 = (CgPbwXm1RilpJUSGHLhy(u"ࠫฬ๊ำุำ࠽ࠫỿ") in maCNIYkc0HOiEGpL3g and uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠬอไๆๅส๊࠿࠭ἀ") in maCNIYkc0HOiEGpL3g and smpniPDOhfwI3H4v7c6TG(u"࠭วๅ็็ๅ࠿࠭ἁ") in maCNIYkc0HOiEGpL3g and bbqAtUz36RPGVTvCkejpJXQB(u"ࠧศๆั฻ศ࠭ἂ") in maCNIYkc0HOiEGpL3g and tOdiG2HWFRBXg1sUh(u"ࠨษ็ฺ้ีั࠻ࠩἃ") in maCNIYkc0HOiEGpL3g)
			if not C8p1G7VPa4E6: eNxAZ8Ot4P7Uqo = eINt5FlUT0oO(Kwl07iYTtDLN3zP(u"ࠩࡦࡩࡳࡺࡥࡳࠩἄ"),Gk98CL5nXZEN(u"ࠪࠫἅ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠫࠬἆ"),Gk98CL5nXZEN(u"ࠬํไࠡฬิื้ࠦ็ั้ࠣห้ืำศๆฬࠤส๊้ࠡษ็้อืๅอࠩἇ"),maCNIYkc0HOiEGpL3g.replace(GGCQK6OAtZUXRhvkgJm(u"࠭࡜࡝ࡰࠪἈ"),NNmirJKPp5nWjfC(u"ࠧ࡝ࡰࠪἉ")))
	elif showDialogs:
		maCNIYkc0HOiEGpL3g = dEUYJjrhsaPXNo(u"ࠨ࡞࡟ࡲฯ๋ࠠๆีะࠤฬ๊ัิษ็อࡡࡢ࡮ห็ุ้ࠣำࠠาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไส࡞࡟ࡲฯ๋ࠠๆีะࠤฬ๊ัิษ็อࡡࡢ࡮ห็ุ้ࠣำࠠศๆิืฬ๊ษࠨἊ")
		dNZt0iSnpGJxr9a5 = eINt5FlUT0oO(r6juULGQtnExAko38BZ5Y(u"ࠩࡦࡩࡳࡺࡥࡳࠩἋ"),QmoEjB3hLIw(u"ࠪࠫἌ"),tOdiG2HWFRBXg1sUh(u"ࠫࠬἍ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬἎ")+ta478EuZQJIWhgBnsf6iU(u"࠭ࠠࠡ࠳࠲࠹ࠬἏ"),Gk98CL5nXZEN(u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬἐ"))
		UdBm6PEsvDcb8SQIOJYtiT2xoe10a = eINt5FlUT0oO(ItgK5FqGDz2Rf7mAJkbT(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨἑ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠩࠪἒ"),CgPbwXm1RilpJUSGHLhy(u"ࠪࠫἓ"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫἔ")+zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠬࠦࠠ࠳࠱࠸ࠫἕ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫ἖"))
		vD6V9BomcA308 = eINt5FlUT0oO(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠧࡤࡧࡱࡸࡪࡸࠧ἗"),r6juULGQtnExAko38BZ5Y(u"ࠨࠩἘ"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࠩࠪἙ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪἚ")+wx18CTJPZ5(u"ࠫࠥࠦ࠳࠰࠷ࠪἛ"),wx18CTJPZ5(u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪἜ"))
		QgdNHw7I2XqF5yL9cSKUJrotCnZ = eINt5FlUT0oO(EAw9bg4rT3Bd8tjSkO(u"࠭ࡣࡦࡰࡷࡩࡷ࠭Ἕ"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠧࠨ἞"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠨࠩ἟"),CIcPowhneWs5tN3(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩἠ")+uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠪࠤࠥ࠺࠯࠶ࠩἡ"),wx18CTJPZ5(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩἢ"))
		eNxAZ8Ot4P7Uqo = eINt5FlUT0oO(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬἣ"),r6juULGQtnExAko38BZ5Y(u"࠭ࠧἤ"),r6juULGQtnExAko38BZ5Y(u"ࠧࠨἥ"),smpniPDOhfwI3H4v7c6TG(u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨἦ")+ItgK5FqGDz2Rf7mAJkbT(u"ࠩࠣࠤ࠺࠵࠵ࠨἧ"),S26SnaqcM9XwK8PVphJDv5(u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨἨ"))
	gg6VwuY0xOi7 = zVw5tvmZRX(ItgK5FqGDz2Rf7mAJkbT(u"࠴࠴੉"),ta478EuZQJIWhgBnsf6iU(u"ࡌࡡ࡭ࡵࡨઢ"))
	KYqWTP0eXkQ3vFl9aRwALi7 = FeyZbj8tDil0nSHzTwfsUJ9(u"ࠫࡆ࡜࠺ࠡࠩἩ")+gg6VwuY0xOi7+Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠬ࠳ࠧἪ")+type
	B0MZ9n3zypJ = EAw9bg4rT3Bd8tjSkO(u"ࡕࡴࡸࡩત") if cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩἫ") in RxgdTHfDar8EXt else cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࡆࡢ࡮ࡶࡩણ")
	if not eNxAZ8Ot4P7Uqo:
		if showDialogs: tehb3k5a2PufGOdBIUw8j(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠧࠨἬ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠨࠩἭ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬἮ"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࠪฮ๊ࠦลๅ฼สลࠥอไฦำึห้ࠦศ็ษฤࠤ฾ู๊้ࠡ็ฬ่࠭Ἧ"))
		return bbqAtUz36RPGVTvCkejpJXQB(u"ࡈࡤࡰࡸ࡫થ")
	DAyVabenHcSp6zWdirG52T3qJBRu = oos8ymFi9CN2z1jXcR.getInfoLabel(FeyZbj8tDil0nSHzTwfsUJ9(u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡋࡸࡩࡦࡰࡧࡰࡾࡔࡡ࡮ࡧࠪἰ"))
	maCNIYkc0HOiEGpL3g += wx18CTJPZ5(u"ࠬࠦ࡜࡝ࡰ࡟ࡠࡳࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࠦ࡜࡝ࡰࡄࡨࡩࡵ࡮ࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠫἱ")+VnhK9wvHBGuo1fei8DXQ02yFZtsWE+wx18CTJPZ5(u"࠭ࠠ࠻࡞࡟ࡲࠬἲ")
	maCNIYkc0HOiEGpL3g += smpniPDOhfwI3H4v7c6TG(u"ࠧࡆ࡯ࡤ࡭ࡱࠦࡓࡦࡰࡧࡩࡷࡀࠠࠨἳ")+gg6VwuY0xOi7+S26SnaqcM9XwK8PVphJDv5(u"ࠨࠢ࠽ࡠࡡࡴࡋࡰࡦ࡬ࠤ࡛࡫ࡲࡴ࡫ࡲࡲ࠿ࠦࠧἴ")+iAqf1sZuQ0wXEndaG+S26SnaqcM9XwK8PVphJDv5(u"ࠩࠣ࠾ࡡࡢ࡮ࠨἵ")
	maCNIYkc0HOiEGpL3g += I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠪࡏࡴࡪࡩࠡࡐࡤࡱࡪࡀࠠࠨἶ")+DAyVabenHcSp6zWdirG52T3qJBRu
	he9GovI4XHNf = E8NciTDyFBuIm()
	he9GovI4XHNf = TaEr2nR3f5e8oXzpy(he9GovI4XHNf)
	if he9GovI4XHNf: maCNIYkc0HOiEGpL3g += qFRrj7ayBKbOsHGSXz(u"ࠫࠥࡀ࡜࡝ࡰࡏࡳࡨࡧࡴࡪࡱࡱ࠾ࠥ࠭ἷ")+he9GovI4XHNf
	if url: maCNIYkc0HOiEGpL3g += r6juULGQtnExAko38BZ5Y(u"ࠬࠦ࠺࡝࡞ࡱ࡙ࡗࡒ࠺ࠡࠩἸ")+url
	if dIsZG1fHm5YVkU6Puzq: maCNIYkc0HOiEGpL3g += bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠭ࠠ࠻࡞࡟ࡲࡘࡵࡵࡳࡥࡨ࠾ࠥ࠭Ἱ")+dIsZG1fHm5YVkU6Puzq
	maCNIYkc0HOiEGpL3g += I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠧࠡ࠼࡟ࡠࡳ࠭Ἲ")
	if showDialogs: xa60ce2znAlyL5Z8ESXhO(MM564HfnUV0XIR(u"ࠨฮสี๏ࠦวๅวิืฬ๊ࠧἻ"),CIcPowhneWs5tN3(u"ࠩส่ึาวยࠢส่ฬ์สูษิࠫἼ"))
	if chj9ifUJu1:
		f5fmn0HG12LvdN = chj9ifUJu1
		if wvkR1es6d0SrjxKt5FZTMUWz7a: f5fmn0HG12LvdN = f5fmn0HG12LvdN.encode(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠪࡹࡹ࡬࠸ࠨἽ"))
		f5fmn0HG12LvdN = SSNcdhMguvEw0RY.b64encode(f5fmn0HG12LvdN)
	elif B0MZ9n3zypJ:
		if EAw9bg4rT3Bd8tjSkO(u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࡏࡍࡆࡢࠫἾ") in RxgdTHfDar8EXt: T9ps7Dnjhlxam = kk2pAdfSq8i7jmH6VhtgFLsGzYM
		else: T9ps7Dnjhlxam = g0gdkA6VTy9mGtLch
		if not K3hFytImeYMkJBC.path.exists(T9ps7Dnjhlxam):
			tehb3k5a2PufGOdBIUw8j(NNmirJKPp5nWjfC(u"ࠬ࠭Ἷ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠭ࠧὀ"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪὁ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠨีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣ฾๏ืࠠๆ๊ฯ์ิ࠭ὂ"))
			return dEUYJjrhsaPXNo(u"ࡉࡥࡱࡹࡥદ")
		jDopXBZ0k9CisWhbflIr,VVPq2W7SsGEDkZCo = [],cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠲੊")
		size,count = Jy1ZPox93TVNYnKLzHvka(T9ps7Dnjhlxam)
		file = open(T9ps7Dnjhlxam,tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠩࡵࡦࠬὃ"))
		if size>NNmirJKPp5nWjfC(u"࠶࠺࠶࠲࠱࠲ੌ"): file.seek(-dEUYJjrhsaPXNo(u"࠵࠹࠵࠷࠰࠱ੋ"),K3hFytImeYMkJBC.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(wx18CTJPZ5(u"ࠪࡹࡹ࡬࠸ࠨὄ"))
		data = BKLljptvaWgVrc(data)
		Zvm7qOC8GUAFB = data.splitlines()
		for Fj1YUPiHsabvulW30mzZ in reversed(Zvm7qOC8GUAFB):
			unVXp2dhIGW6fBR83Y9SeL = QExlAjIJGByHs6O3wK4nCF0omc(Fj1YUPiHsabvulW30mzZ)
			if unVXp2dhIGW6fBR83Y9SeL: continue
			B0lmRXOogDJyTLpFwcvNA = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(CgPbwXm1RilpJUSGHLhy(u"ࠫࡣ࠮࡜ࡥ࠭࠰ࠬࡡࡪࠫ࠮࡞ࡧ࠯ࠥࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫὅ"),Fj1YUPiHsabvulW30mzZ,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if B0lmRXOogDJyTLpFwcvNA:
				Fj1YUPiHsabvulW30mzZ = Fj1YUPiHsabvulW30mzZ.replace(B0lmRXOogDJyTLpFwcvNA[zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠶੎")][zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠶੎")],B0lmRXOogDJyTLpFwcvNA[zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠶੎")][YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠶੍")]).replace(B0lmRXOogDJyTLpFwcvNA[zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠶੎")][smpniPDOhfwI3H4v7c6TG(u"࠲੏")],QmoEjB3hLIw(u"ࠬ࠭὆"))
			else:
				B0lmRXOogDJyTLpFwcvNA = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠭࡞ࠩ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠭ࠦࡔ࠻࡞ࡧ࠯࠮࠭὇"),Fj1YUPiHsabvulW30mzZ,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
				if B0lmRXOogDJyTLpFwcvNA: Fj1YUPiHsabvulW30mzZ = Fj1YUPiHsabvulW30mzZ.replace(B0lmRXOogDJyTLpFwcvNA[zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠲ੑ")][wx18CTJPZ5(u"࠲੐")],YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠧࠨὈ"))
			jDopXBZ0k9CisWhbflIr.append(Fj1YUPiHsabvulW30mzZ)
			if len(str(jDopXBZ0k9CisWhbflIr))>YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠴࠶࠶࠶࠰࠱੒"): break
		jDopXBZ0k9CisWhbflIr = reversed(jDopXBZ0k9CisWhbflIr)
		f5fmn0HG12LvdN = tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠨ࡞ࡵࡠࡳ࠭Ὁ").join(jDopXBZ0k9CisWhbflIr)
		f5fmn0HG12LvdN = f5fmn0HG12LvdN.encode(CIcPowhneWs5tN3(u"ࠩࡸࡸ࡫࠾ࠧὊ"))
		f5fmn0HG12LvdN = SSNcdhMguvEw0RY.b64encode(f5fmn0HG12LvdN)
	else: f5fmn0HG12LvdN = WbM6qAjrn7fEXGZw(u"ࠪࠫὋ")
	url = mR20sONyKIlV[Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫὌ")][uAl3gHavMJZL4xmNe62nDiBoQ(u"࠶੓")]
	VVNkoRCUm96MbtuqgrOe = {YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠬࡹࡵࡣ࡬ࡨࡧࡹ࠭Ὅ"):KYqWTP0eXkQ3vFl9aRwALi7,smpniPDOhfwI3H4v7c6TG(u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࡥࠨ὎"):maCNIYkc0HOiEGpL3g,NxsKJnLFEZ9OHXf1h(u"ࠧ࡭ࡱࡪࡪ࡮ࡲࡥࠨ὏"):f5fmn0HG12LvdN}
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,r6juULGQtnExAko38BZ5Y(u"ࠨࡒࡒࡗ࡙࠭ὐ"),url,VVNkoRCUm96MbtuqgrOe,YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠩࠪὑ"),MM564HfnUV0XIR(u"ࠪࠫὒ"),MM564HfnUV0XIR(u"ࠫࠬὓ"),GGCQK6OAtZUXRhvkgJm(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡔࡇࡑࡈࡤࡋࡍࡂࡋࡏ࠱࠶ࡹࡴࠨὔ"))
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	if zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠭ࠢࡴࡷࡦࡧࡪ࡫ࡤࡦࡦࠥ࠾ࠥ࠷ࠬࠨὕ") in M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2: VZHWjJTrAPKG1eLEsxpYo2tS5 = Ox8k6IdtuPaG3NlApQK52oYwM(u"ࡘࡷࡻࡥધ")
	else: VZHWjJTrAPKG1eLEsxpYo2tS5 = QmoEjB3hLIw(u"ࡋࡧ࡬ࡴࡧન")
	if showDialogs:
		if VZHWjJTrAPKG1eLEsxpYo2tS5:
			xa60ce2znAlyL5Z8ESXhO(dEUYJjrhsaPXNo(u"ࠧห็ࠣห้หัิษ็ࠫὖ"),MM564HfnUV0XIR(u"ࠨส้ะฬำࠧὗ"))
			tehb3k5a2PufGOdBIUw8j(FeyZbj8tDil0nSHzTwfsUJ9(u"ࠩࠪ὘"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠪࠫὙ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠫࡒ࡫ࡳࡴࡣࡪࡩࠥࡹࡥ࡯ࡶࠪ὚"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠬะๅࠡวิืฬ๊ࠠศๆิืฬ๊ษࠡส้ะฬำࠧὛ"))
		else:
			xa60ce2znAlyL5Z8ESXhO(smpniPDOhfwI3H4v7c6TG(u"࠭ไๅลึๅࠬ὜"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠧโึ็ࠤๆ๐ࠠศๆศีุอไࠨὝ"))
			tehb3k5a2PufGOdBIUw8j(uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠨࠩ὞"),wx18CTJPZ5(u"ࠩࠪὟ"),GGCQK6OAtZUXRhvkgJm(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ὠ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠫำ฽ร๊ࠡไุ้ࠦแ๋ࠢศีุอไࠡษ็ีุอไสࠩὡ"))
	return VZHWjJTrAPKG1eLEsxpYo2tS5
def ujwJ1cqfeR():
	hwAK5bC7pHoU6VrSdgsvM = CIcPowhneWs5tN3(u"ࠬ࠷࠮ࠡࠢࠣࡍ࡫ࠦࡹࡰࡷࠣ࡬ࡦࡼࡥࠡࡲࡵࡳࡧࡲࡥ࡮ࠢࡺ࡭ࡹ࡮ࠠࡂࡴࡤࡦ࡮ࡩࠠࡵࡧࡻࡸࡹࠦࡴࡩࡧࡱࠤ࡬ࡵࠠࡵࡱࠣࠦࡐࡵࡤࡪࠢࡌࡲࡹ࡫ࡲࡧࡣࡦࡩ࡙ࠥࡥࡵࡶ࡬ࡲ࡬ࡹࠢࠡࡣࡱࡨࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡩࡳࡳࡺࠠࡵࡱࠣࠦࡆࡸࡩࡢ࡮ࠥࠫὢ")
	cE6OHoADvlhK1gVy2p8rYbWXFmGQ = zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠭࠱࠯ࠢࠣࠤสึวࠡๆา๎่ࠦๅีๅ็อࠥ็๊ࠡษ็วาืแࠡษ็฽ึฮ๊สࠢไหีํศࠡว็ํࠥหูะษาหฯ่ࠦศฮ๊อ้่ࠥะ์ࠣฯฺ๊๋ࠦำࠣห้ิืࠡษ็ุ้ะฮะ็ࠣษ้๏ࠠࠣࡃࡵ࡭ࡦࡲࠢࠨὣ")
	tehb3k5a2PufGOdBIUw8j(Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠧࠨὤ"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࠨࠩὥ"),wx18CTJPZ5(u"ࠩࡄࡶࡦࡨࡩࡤࠢࡓࡶࡴࡨ࡬ࡦ࡯ࠪὦ"),hwAK5bC7pHoU6VrSdgsvM+qFRrj7ayBKbOsHGSXz(u"ࠪࡠࡳࡢ࡮ࠨὧ")+cE6OHoADvlhK1gVy2p8rYbWXFmGQ)
	hwAK5bC7pHoU6VrSdgsvM = YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠫ࠷࠴ࠠࠡࠢࡌࡪࠥࡿ࡯ࡶࠢࡦࡥࡳࡢࠧࡵࠢࡩ࡭ࡳࡪࠠࠣࡃࡵ࡭ࡦࡲࠢࠡࡨࡲࡲࡹࠦࡴࡩࡧࡱࠤࡨ࡮ࡡ࡯ࡩࡨࠤࡹ࡮ࡥࠡࡵ࡮࡭ࡳࠦࡡ࡯ࡦࠣࡸ࡭࡫࡮ࠡࡥ࡫ࡥࡳ࡭ࡥࠡࡶ࡫ࡩࠥ࡬࡯࡯ࡶࠪὨ")
	cE6OHoADvlhK1gVy2p8rYbWXFmGQ = Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠬ࠸࠮ࠡࠢࠣษีอࠠๅ็ࠣฮัีࠠศๆั฻ࠥࠨࡁࡳ࡫ࡤࡰࠧࠦแใ็ࠣฬฯเ๊๋ำࠣห้าไะࠢฮ้่ࠥๅࠡสอ฾๏ืࠠศๆั฻ࠥอไๆีอาิ๋ࠠฦๆ์ࠤࠧࡇࡲࡪࡣ࡯ࠦࠬὩ")
	tehb3k5a2PufGOdBIUw8j(tOdiG2HWFRBXg1sUh(u"࠭ࠧὪ"),NxsKJnLFEZ9OHXf1h(u"ࠧࠨὫ"),MM564HfnUV0XIR(u"ࠨࡈࡲࡲࡹࠦࡐࡳࡱࡥࡰࡪࡳࠧὬ"),hwAK5bC7pHoU6VrSdgsvM+Gk98CL5nXZEN(u"ࠩ࡟ࡲࡡࡴࠧὭ")+cE6OHoADvlhK1gVy2p8rYbWXFmGQ)
	hwAK5bC7pHoU6VrSdgsvM = SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠪ࠷࠳ࠦࠠࠡࡋࡩࠤࡾࡵࡵࠡࡦࡲࡲࡡ࠭ࡴࠡࡪࡤࡺࡪࠦࡁࡳࡣࡥ࡭ࡨࠦࡋࡦࡻࡥࡳࡦࡸࡤࠡࡶ࡫ࡩࡳࠦࡧࡰࠢࡷࡳࠥࠨࡋࡰࡦ࡬ࠤࡎࡴࡴࡦࡴࡩࡥࡨ࡫ࠠࡔࡧࡷࡸ࡮ࡴࡧࡴࠤࠣࡥࡳࡪࠠࡤࡪࡤࡲ࡬࡫ࠠࡵࡪࡨࠤࡷ࡫ࡧࡪࡱࡱࡥࡱࠦࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠨὮ")
	cE6OHoADvlhK1gVy2p8rYbWXFmGQ = ta478EuZQJIWhgBnsf6iU(u"ࠫ࠸࠴ࠠࠡࠢศิฬࠦไๆࠢํ็๋ࠦไะ์ๆࠤ้๎อส่ࠢๅฬะ๊ฮࠢ฼ีอ๐ษࠡใสิ์ฮࠠฦๆ์ࠤส฿ฯศัสฮࠥ๎วอ้ฬࠤ่๎ฯ๋ࠢฮ้ࠥเ๊าࠢศ฽ิอฯศฬࠣห้๋ๆุไฬࠤฬ๊ฬ฻ำสๅ๏ฯࠧὯ")
	tehb3k5a2PufGOdBIUw8j(Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠬ࠭ὰ"),CgPbwXm1RilpJUSGHLhy(u"࠭ࠧά"),GGCQK6OAtZUXRhvkgJm(u"ࠧࡇࡱࡱࡸࠥࡖࡲࡰࡤ࡯ࡩࡲ࠭ὲ"),hwAK5bC7pHoU6VrSdgsvM+zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠨ࡞ࡱࡠࡳ࠭έ")+cE6OHoADvlhK1gVy2p8rYbWXFmGQ)
	A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠩࡦࡩࡳࡺࡥࡳࠩὴ"),ta478EuZQJIWhgBnsf6iU(u"ࠪࠫή"),smpniPDOhfwI3H4v7c6TG(u"ࠫࠬὶ"),smpniPDOhfwI3H4v7c6TG(u"ࠬࡌ࡯࡯ࡶࠣࡷࡪࡺࡴࡪࡰࡪࡷࠬί"),GGCQK6OAtZUXRhvkgJm(u"࠭ࡄࡰࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡨࡱࠣࡸࡴࠦࠢࡌࡱࡧ࡭ࠥࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࠡࡕࡨࡸࡹ࡯࡮ࡨࡵࠥࠤࡳࡵࡷࠡࡁࠪὸ")+SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠧ࡝ࡰ࡟ࡲࠬό")+smpniPDOhfwI3H4v7c6TG(u"ࠨ้็ࠤฯื๊ะࠢส่ีํวษࠢศ่๎ࠦไ้ฯฬࠤส฿ฯศัสฮࠥ๎วอ้ฬࠤ่๎ฯ๋ࠢฦ่ว์ฟࠨὺ"))
	if A5vgi1F6qVunZMas2Nf==tOdiG2HWFRBXg1sUh(u"࠶੔"): BDorXLyuqa8S()
	return
def f7mt09LAi5XFoxEW4bjcMUNGzH6Bh():
	tehb3k5a2PufGOdBIUw8j(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠩࠪύ"),ta478EuZQJIWhgBnsf6iU(u"ࠪࠫὼ"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧώ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠬเวๅสสࠤฬ๊ำษส๋ࠣํࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢส่๊เะ๋ࠢ็่อืๆศ็ฯࠤํ๊ไหลๆำ่ࠥๅࠡสอุ฿๐ไࠡษ็ีฬฮืࠡษ็ิ๏ࠦไศࠢํ฽๊๊ࠠฬ็ࠣๆ๊ࠦศฦำึห้ࠦๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮ้๋ࠣࠦวๅไสส๊ฯࠠศๆิส๏ู๊สࠢ็่อืๆศ็ฯࠫ὾"))
	return
def LgJcxdXok5Z():
	maCNIYkc0HOiEGpL3g = NxsKJnLFEZ9OHXf1h(u"࠭็ัษࠣห้ฮั็ษ่ะ๋ࠥฮึืࠣๅ็฽ࠠๅๆ฽อࠥอไฺำห๎ฮ่ࠦๅๅ้ࠤ์ึวࠡๆสࠤ๏๋ๆฺ๋ࠢะํีࠠๆ๊สๆ฾ࠦแ๋้สࠤศ็ไศ็ࠣ์ู๊ไิๆสฮ๋ࠥสาฮ่อࠥษ่ࠡ็าฬ้าษࠡว็ํࠥอไๅ฼ฬࠤฬู๊าสํอࠥ๎วๅ๋่ࠣ฿อสࠡษัี๎่ࠦๅษࠣ๎ําฯࠡีหฬ๊ࠥไหๅิหึ࠭὿")
	tehb3k5a2PufGOdBIUw8j(I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠧࠨᾀ"),QmoEjB3hLIw(u"ࠨࠩᾁ"),r6juULGQtnExAko38BZ5Y(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᾂ"),maCNIYkc0HOiEGpL3g)
	return
def T9z8cJaA6WsfSKIOeL():
	maCNIYkc0HOiEGpL3g = Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠪห้ื่ศสฺࠤฬ๊ศุ์ษอ๊ࠥวࠡ฻็ห็ฯࠠๅ้สࠤออไษำ้ห๊า้ࠠ฼ส่ออࠠศๆึฬอࠦ็้่๊ࠢࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥอไๆ฼ำ๎๊ࠥไษำ้ห๊าࠧᾃ")
	tehb3k5a2PufGOdBIUw8j(Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠫࠬᾄ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠬ࠭ᾅ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᾆ"),maCNIYkc0HOiEGpL3g)
	return
def YKpOxQe3lcr9aGWTiXA6vqjFd():
	maCNIYkc0HOiEGpL3g = qFRrj7ayBKbOsHGSXz(u"่ࠧ์ࠣื๏ืแาษอࠤ้อ๋ࠠีอ฻๏฿ࠠศๆหี๋อๅอࠢสืฯิฯศ็๊หࠥฮำษสࠣ็ํ์็ศ่ࠢั๊๐ษࠡ็้ࠤฬ๊ๅึัิࠤศ๎ࠠษฯสะฮࠦลๅ๋ࠣหูะัศๅࠣีุ๋๊ࠡล๋ࠤัี๊ะหࠣวํࠦไศࠢํ฽ึ็็ศࠢส่อืๆศ็ฯࠫᾇ")
	tehb3k5a2PufGOdBIUw8j(MM564HfnUV0XIR(u"ࠨࠩᾈ"),r6juULGQtnExAko38BZ5Y(u"ࠩࠪᾉ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᾊ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ุࠫ๐ัโำสฮู๊ࠥวหࠣวํࠦๅอ้๋่ฮ࠭ᾋ"),maCNIYkc0HOiEGpL3g)
	return
def J9JTLXSQDG():
	maCNIYkc0HOiEGpL3g = FeyZbj8tDil0nSHzTwfsUJ9(u"ࠬอไิ์ิๅึอสࠡษ็฽ฬ๋ษ้ࠡํࠤุ๐ัโำสฮࠥิวาฮํอࠥ๎ฺ๋ำࠣฮฬฮูสࠢ็่๊๎โฺࠢส่ศ฻ไ๋๋ࠢะ๊๐ูࠡษ็้ํอโฺࠢอืฯิฯๆ้สࠤํ฿วะหࠣฮ่๎ๆࠡ็ฯห๋๐ษุ๊่ࠡฬ้ไ่ษࠣ็ะ๐ัสࠢ็ห๋ࠦวๅใํำ๏๎็ศฬࠣๅ๏ํวࠡว่หࠥฮื๋ศฬࠤศ๎ࠠๆ็้์฾ฯࠠฤ๊้ࠣาึ่โหࠣวํࠦแ๋้สࠤฺ๊ใๅหࠣั็๎โࠡษ็้้้๊ส࡞ࡱࡠࡳࡢ࡮ศๆึ๎ึ็ัศฬࠣห้ิวึห๋ࠣ๏ࠦำ๋ำไีฬะࠠหษห฽ฮࠦไๅ็๋ๆ฾ࠦวๅลุ่๏่ࠦๆีอาิ๋ษࠡใํࠤ๊๎วใ฻ࠣๆ้๐ไสࠢฯำฬฺ่ࠦษาอࠥะใ้่้ࠣิ็ฺ่หࠣห้ษฬาࠢฦ์ࠥ๐ๅๅๅ๊หࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥ๎ไ่าสࠤๆํ๊ࠡฮํำฮࠦๆิสํหࠥ๎ำา์฼อࠥ๎ๅีษๆ่์อࠠใๆํ่ฮࠦฬะษࠪᾌ")
	Dkp5YTLQijOEKF(ta478EuZQJIWhgBnsf6iU(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᾍ"),qFRrj7ayBKbOsHGSXz(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᾎ"),maCNIYkc0HOiEGpL3g,YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫᾏ"))
	return
def vR2yHBiQON():
	hwAK5bC7pHoU6VrSdgsvM = CgPbwXm1RilpJUSGHLhy(u"ࠩสฬฯ฿ฯࠡ฻้ࠤ๊๊แศฬࠣห้ีโสࠢส่฾อไ๋หࠪᾐ")
	cE6OHoADvlhK1gVy2p8rYbWXFmGQ = dEUYJjrhsaPXNo(u"ࠪหอะูะࠢ฼๊๋ࠥไโษอࠤศ๊ࠠ࡮࠵ࡸ࠼ࠬᾑ")
	YOTH54N3yLc9K = dEUYJjrhsaPXNo(u"ࠫฬฮสฺัࠣ฽๋ࠦๅๅใสฮࠥอไหฯ่๎้่ࠦศๆาหํ์ไ้ัࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠬᾒ")
	tehb3k5a2PufGOdBIUw8j(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠬ࠭ᾓ"),MM564HfnUV0XIR(u"࠭ࠧᾔ"),ta478EuZQJIWhgBnsf6iU(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᾕ"),hwAK5bC7pHoU6VrSdgsvM,cE6OHoADvlhK1gVy2p8rYbWXFmGQ,YOTH54N3yLc9K)
	return
def PxmphrKe7N8oE():
	cE6OHoADvlhK1gVy2p8rYbWXFmGQ = wx18CTJPZ5(u"ࠨษ็็ฬฺ่๊้ࠠࠣำุๆࠡ็วๆฯࠦไๅ็฼่ํ๋วหࠢํืฯิฯๆ้ࠣห้ฮั็ษ่ะ๊ࠥฮำู่ࠣๆำวหࠢส่ส์สา่ํฮࠥ๎ั้ษห฻ࠥอไโ์า๎ํํวหࠢ็่ํ฻่ๅࠢศ่๏ํวࠡสึี฾ฯ้ࠠสา์๋ࠦล็ฬิ๊๏ะ้ࠠษ็ฬึ์วๆฮࠣ๎ู๊อ่ษࠣฮ้่วว์สࠤอ฿ฯࠡษ้ฮ์อมࠡ฻่ี์อ้ࠠลํฺฬูࠦ็ัࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤ࠳่่ࠦาสࠤฬ๊ศา่ส้ั๊ࠦิฬัำ๊ࠦำษ฻ฬࠤศ์่ศ฻่ࠣ฾๋ัࠡษ็็ฬฺࠠ࠻ࠩᾖ")
	cE6OHoADvlhK1gVy2p8rYbWXFmGQ += QmoEjB3hLIw(u"ࠩ࡟ࡲࡡࡴࠧᾗ") + Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠪ࠵࠳ࠦหศสอࠤ้๊ีโฯสฮࠥอไห์้ࠣ฾ื่โࠢฦ๊์อࠠๅษࠣฮฯเ๊า้๋ࠢฬฬ๊ศ๋้ࠢิะ็ࠡࠩᾘ") + str(D0vjfyxKZuP7pXknq62MwFYU/I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠼࠰੕")/I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠼࠰੕")/qFRrj7ayBKbOsHGSXz(u"࠲࠵੖")/WbM6qAjrn7fEXGZw(u"࠴࠲੗")) + ItgK5FqGDz2Rf7mAJkbT(u"ฺࠫࠥ็าࠩᾙ")
	cE6OHoADvlhK1gVy2p8rYbWXFmGQ += tOdiG2HWFRBXg1sUh(u"ࠬࡢ࡮ࠨᾚ") + YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠭࠲࠯ࠢฯำฬࠦื้์็ࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ๅโำฺ๋ࠥษๆ่ษ่ࠣฬࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬᾛ") + str(WA14geuaxzJQ0ND3q8f2hdbk/bbqAtUz36RPGVTvCkejpJXQB(u"࠸࠳੘")/bbqAtUz36RPGVTvCkejpJXQB(u"࠸࠳੘")/tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠵࠸ਖ਼")) + MM564HfnUV0XIR(u"ࠧࠡ์๋้ࠬᾜ")
	cE6OHoADvlhK1gVy2p8rYbWXFmGQ += tOdiG2HWFRBXg1sUh(u"ࠨ࡞ࡱࠫᾝ") + uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠩ࠶࠲ࠥ฽่๋ๆࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้ะ๊่ࠡสำึอࠠหฬ฽๎ึ่ࠦๆัอ๋ࠥ࠭ᾞ") + str(xgFTDVS7lf5Us6aj/ItgK5FqGDz2Rf7mAJkbT(u"࠺࠵ਗ਼")/ItgK5FqGDz2Rf7mAJkbT(u"࠺࠵ਗ਼")/cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠷࠺ਜ਼")) + qFRrj7ayBKbOsHGSXz(u"ࠪࠤ๏๎ๅࠨᾟ")
	cE6OHoADvlhK1gVy2p8rYbWXFmGQ += YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠫࡡࡴࠧᾠ") + YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠬ࠺࠮ࠡ็อ์ุ฽ࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎่ࠥฯࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧᾡ") + str(Yv7e6ixHfZIPrmMOy3ozwJu2/CgPbwXm1RilpJUSGHLhy(u"࠼࠰ੜ")/CgPbwXm1RilpJUSGHLhy(u"࠼࠰ੜ")) + bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠭ࠠิษ฼อࠬᾢ")
	cE6OHoADvlhK1gVy2p8rYbWXFmGQ += GGCQK6OAtZUXRhvkgJm(u"ࠧ࡝ࡰࠪᾣ") + S26SnaqcM9XwK8PVphJDv5(u"ࠨ࠷࠱ࠤ็฻๊าࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠหฬ฽๎ึࠦฯศศ่หࠥ๎ๅะฬ๊ࠤࠬᾤ") + str(jEPuRTVbZg4MCimJxzf3I6wFa/smpniPDOhfwI3H4v7c6TG(u"࠶࠱੝")/smpniPDOhfwI3H4v7c6TG(u"࠶࠱੝")) + ta478EuZQJIWhgBnsf6iU(u"ࠩࠣืฬ฿ษࠨᾥ")
	cE6OHoADvlhK1gVy2p8rYbWXFmGQ += zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠪࡠࡳ࠭ᾦ") + ItgK5FqGDz2Rf7mAJkbT(u"ࠫ࠻࠴ࠠอัสࠤ็฻๊าࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠหฬ฽๎ึࠦใฬ์ิหࠥ๎ๅะฬ๊ࠤࠬᾧ") + str(RvKQX7HgZ6faBueLsMjxGtPobTd0/bbqAtUz36RPGVTvCkejpJXQB(u"࠷࠲ਫ਼")) + EAw9bg4rT3Bd8tjSkO(u"ࠬࠦฯใ์ๅอࠬᾨ")
	cE6OHoADvlhK1gVy2p8rYbWXFmGQ += cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠭࡜࡯ࠩᾩ") + Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠧ࠸࠰ࠣฬิ๎ๆࠡๅสุ๊ࠥไึใะหฯࠦวๅฬํࠤฯะฺ๋ำࠣฬุืูส๋้ࠢิะ็ࠡࠩᾪ") + str(MMLimtJ8xTFAq9Z012nroaju3de) + NNmirJKPp5nWjfC(u"ࠨࠢาๆ๏่ษࠨᾫ")
	cE6OHoADvlhK1gVy2p8rYbWXFmGQ += dEUYJjrhsaPXNo(u"ࠩ࡟ࡲࡡࡴࠧᾬ") + FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"้ࠪะ๊ว࠻ุࠢๅาอสࠡไ๋หห๋ࠠศๆฦๅ้อๅ๊ࠡสู่๊ไิๆสฮࠥ๎วๅฯ็ๆฬะฺࠠ็ิ๋ฬࠦࠧᾭ") + str(Yv7e6ixHfZIPrmMOy3ozwJu2/NxsKJnLFEZ9OHXf1h(u"࠸࠳੟")/NxsKJnLFEZ9OHXf1h(u"࠸࠳੟")) + dEUYJjrhsaPXNo(u"ูࠫࠥวฺหࠣ࠲ࠥษๅศࠢๅ์ฬฬๅࠡล้์ฬ฿ࠠศๆไ๎ิ๐่่ษอࠤๆ฿ๅา้สࠤࠬᾮ") + str(xgFTDVS7lf5Us6aj/NxsKJnLFEZ9OHXf1h(u"࠸࠳੟")/NxsKJnLFEZ9OHXf1h(u"࠸࠳੟")/CIcPowhneWs5tN3(u"࠵࠸੠")) + YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠬࠦร๋ษ่ࠤ࠳ࠦรๆษ้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣๅ฾๋ั่ษࠣࠫᾯ") + str(jEPuRTVbZg4MCimJxzf3I6wFa/NxsKJnLFEZ9OHXf1h(u"࠸࠳੟")/NxsKJnLFEZ9OHXf1h(u"࠸࠳੟")) + r6juULGQtnExAko38BZ5Y(u"࠭ࠠิษ฼อࠥ็โุࠢ࠱ࠤศ๋วࠡใะูࠥืโๆࠢส่ส฻ฯศำࠣๅ฾๋ั่ࠢࠪᾰ") + str(RvKQX7HgZ6faBueLsMjxGtPobTd0/NxsKJnLFEZ9OHXf1h(u"࠸࠳੟")) + qFRrj7ayBKbOsHGSXz(u"ࠧࠡัๅ๎็ฯࠠ࠯ࠢฦ้ฬࠦแฮืࠣหูะัศๅࠣไࡎࡖࡔࡗࠢไ฽๊ื็ࠡࠩᾱ") + str(MMLimtJ8xTFAq9Z012nroaju3de) + zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠨࠢาๆ๏่ษࠨᾲ")
	Dkp5YTLQijOEKF(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠩࡵ࡭࡬࡮ࡴࠨᾳ"),NNmirJKPp5nWjfC(u"้ࠪฬࠦ็้ࠢส่่อิࠡษ็ุ้ะฮะ็ࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨᾴ"),cE6OHoADvlhK1gVy2p8rYbWXFmGQ,MM564HfnUV0XIR(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ᾵"))
	return
def ynvKMVjBsY62fwG5bcTXLEFhuq():
	maCNIYkc0HOiEGpL3g = zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠬอไโษุ่ฮࠦสฺ่ํࠤ๊าไะࠢห๊ๆูࠠศี่๋ࠥอไฤื็๎ࠥ๎วๅ่ๅ฻ฮࠦสฺ่ํࠤศ์ࠠศๆสื๊ࠦวๅลุ่๏ࠦสๆࠢอ฽ิ๐ไ่๋ࠢๅฬ฻ไส๋๊ࠢ็฽ษࠡฬ฼๊๎ࠦๅอๆาࠤํะๅࠡฬ฼ำ๏๊ࠠศี่๋ࠥ๎ศะ๊้ࠤ฾๊วๆหࠣฮ฾์๊ࠡ็็ๅࠥฮๆโีࠣหุ๋็ࠡษ็วฺ๊๊ࠨᾶ")
	tehb3k5a2PufGOdBIUw8j(CgPbwXm1RilpJUSGHLhy(u"࠭ࠧᾷ"),qFRrj7ayBKbOsHGSXz(u"ࠧࠨᾸ"),GGCQK6OAtZUXRhvkgJm(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᾹ"),maCNIYkc0HOiEGpL3g)
	return
def dpXomkVGErTKOYBz2g():
	maCNIYkc0HOiEGpL3g = EAw9bg4rT3Bd8tjSkO(u"ࠩศิฬ่ࠦศฮ๊ฮ่ࠦๅีๅ็อࠥ็๊ࠡษ็ุอ้ษ๊ࠡอ้ࠥำไ่ษࠣ࠲࠳࠴ࠠฤ๊ࠣห๋้ࠠหฺ้ࠤศ์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠไษ้ࠤๆ๐็ࠡ็ื็้ฯࠠๆฦๅฮ์่ࠦห็ࠣั้ํวࠡ࠰࠱࠲ࠥ็ลั่ࠣะึฮࠠๆีะࠤ่อิࠡษ็ฬึ์วๆฮ่่ࠣ๐๋ࠠไ๋้ࠥอไษำ้ห๊าࠠษู็ฬࠥอไึใะอࠥอไึฯํัฮ่ࠦหะี๎๋ํวࠡสา่ฬࠦๅ็ࠢสฺ่็อสࠢส่็ี๊ๆหࠪᾺ")
	tehb3k5a2PufGOdBIUw8j(dEUYJjrhsaPXNo(u"ࠪࠫΆ"),QmoEjB3hLIw(u"ࠫࠬᾼ"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ᾽"),maCNIYkc0HOiEGpL3g)
	return
def KNtfbIlVUmyn0ukZT2LD9iOSEHzR():
	maCNIYkc0HOiEGpL3g = NxsKJnLFEZ9OHXf1h(u"࠭วๅ฼ิฺ๋ࠥๆࠡึ๊หิฯࠠศๆอุๆ๐ั้๋ࠡࠤ฻๋ว็ุࠢัฮ่ࠦิำํอࠥอไๆ฻็์๊อสࠡษ็้ฯฮวะๆฬࠤอ๐ๆࠡษ็ฬึ์วๆฮࠣ์ฬ๊ๅ้ไ฼ࠤฬ๊ๅีใิࠤํํะศࠢส่฻๋ว็ࠢ฽๎ึࠦๅุๆ๋ฬࠥ๎ไศࠢะหัฯࠠๅ้ࠣ฽๋ีࠠศๆสฮฺอไࠡษ๋ࠤฬ๊ัษู้ࠣ฾ࠦๅ้ษๅ฽ࠥอไโ์า๎ํํวหࠢสฺ่๊แาหࠪι")
	tehb3k5a2PufGOdBIUw8j(bbqAtUz36RPGVTvCkejpJXQB(u"ࠧࠨ᾿"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠨࠩ῀"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ῁"),maCNIYkc0HOiEGpL3g)
	return
def OOVb2MN4UHa7v():
	tehb3k5a2PufGOdBIUw8j(QmoEjB3hLIw(u"ࠪࠫῂ"),NxsKJnLFEZ9OHXf1h(u"ࠫࠬῃ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨῄ"),S26SnaqcM9XwK8PVphJDv5(u"࠭ไไ์ࠣ๎฾๋ไ้ࠡำหࠥอไ็๊฼ࠤ๊์ࠠศๆไ๎ิ๐่่ษอࠤࡡࡴ๋ࠠฮหࠤฯ็ู๋ๆࠣษ฻อแสࠢสื๊ํวࠡ࡞ࡱࠤ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫ῅"))
	ouxXRO0IqbTFQE5e6rD97(S26SnaqcM9XwK8PVphJDv5(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧῆ"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࡚ࡲࡶࡧ઩"))
	return
def d1RljT3DWeMEqxHOIk8():
	maCNIYkc0HOiEGpL3g  = wx18CTJPZ5(u"ࠨ็วาึอࠠใษ่ฮࠥฮูืࠢืี่อสࠡษ็ษ๋ะั็ฬࠣห้ี่ๅ์ࠣฬํ฼ูࠡ฻สส็ࠦึะࠢส่อืวๆฮ้ࠣะ๊ࠠไ๊า๎๊ࠥสิ็ะࠤๆ่ืࠡๆห฽฻ࠦๅิฬัำ๊๐ࠠศๆ่ฮฺ็อࠡสส่ิิ่ๅࠢ็้ํอโฺࠢส่ๆ๐ฯ๋๊ࠪῇ")
	maCNIYkc0HOiEGpL3g += bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠩࠣ์๋ะ๊อห่ࠣ์ึวࠡษ็฽ฬฬโࠡใส๊์ࠦสใำํฬฬࠦฬๆ์฼ࠤู๊สฯั่๎ࠥฮั็ษ่ะ้่ࠥะ์่ࠣฬ๊ࠦิฬฺ๎฾๎ๆࠡษ็ำำ๎ไࠡๆฯ้๏฿ࠠๆ๊สๆ฾ࠦวๅสิ๊ฬ๋ฬࠡฯอํู๋ࠥࠡษึฮำีวๆࠩῈ")
	maCNIYkc0HOiEGpL3g += wx18CTJPZ5(u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝แ࡚ࠢࠣࡕࡔࠠࠡล๋ࠤࠥࡖࡲࡰࡺࡼࠤࠥษ่ࠡࠢࡇࡒࡘࠦࠠฤ๊ࠣว๏ࠦอๅࠢหื๏฽ࠠระิ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴࠧΈ")
	maCNIYkc0HOiEGpL3g += uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠫࡡࡴไศ่๋ࠣีอࠠๅ่ࠣ๎า๊ࠠศๆุ่่๊ษ๊ࠡศ๊๊อࠠโไฺࠤุ๐โ้็ࠣฬส฻ไศฯࠣฬ฾฼ࠠศๆ่์ฬู่๊ࠡศ฽ฬ่ษࠡ็๋ห็฿ࠠศะิํ้ࠥว็ฬࠣฮ฾๋ไࠡีสฬ็อࠠษั๋๊๋ࠥิศๅ็ࠫῊ")
	Dkp5YTLQijOEKF(ta478EuZQJIWhgBnsf6iU(u"ࠬࡸࡩࡨࡪࡷࠫΉ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩῌ"),maCNIYkc0HOiEGpL3g,S26SnaqcM9XwK8PVphJDv5(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ῍"))
	maCNIYkc0HOiEGpL3g = CgPbwXm1RilpJUSGHLhy(u"ࠨษ็้ํอโฺࠢส่ฯ๐ࠠหลฮีฯࠦศศๆ฼หหฺ่่ࠠาࠤอ฿ึࠡษ็๊ฬู่ࠠ์࠽ࠫ῎")
	maCNIYkc0HOiEGpL3g += Gk98CL5nXZEN(u"ࠩ࡟ࡲࠬ῏")+ta478EuZQJIWhgBnsf6iU(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡧ࡫ࡰࡣࡰࠤࠥ࡫ࡧࡺࡤࡨࡷࡹࠦࠠࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠤࠥࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤࠡࠢࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨࠡࠢࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸ࡟࠴ࡉࡏࡍࡑࡕࡡࠬῐ")
	maCNIYkc0HOiEGpL3g += bbqAtUz36RPGVTvCkejpJXQB(u"ࠫࡡࡴ࡜࡯ࠩῑ")+EAw9bg4rT3Bd8tjSkO(u"ࠬอไะ๊็ࠤฬ๊ส๋ࠢอวะืสࠡสส่฾อฦใࠢ฼๊ิࠦศฺุࠣห้์วิ๊ࠢ๎࠿࠭ῒ")
	maCNIYkc0HOiEGpL3g += uAl3gHavMJZL4xmNe62nDiBoQ(u"࠭࡜࡯ࠩΐ")+qFRrj7ayBKbOsHGSXz(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ู่ึࠦࠠศๆๆ์๏ะࠠࠡล่๎ึ้วࠡࠢๆ๊ิอࠠࠡใิุ๊อࠠࠡษ็๎ํ์ว็ࠢࠣฬึ๐ืศ่ํหࠥอไฦ็สีฬะࠠฤๆ่ห๋๐วࠡำ๋ื๏อࠠศๆํหออๆࠡษ็ื฾๎ฯ๋หࠣีํ๋ว็์สࠤ์๎ไ็ัส࡟࠴ࡉࡏࡍࡑࡕࡡࠬ῔")
	maCNIYkc0HOiEGpL3g += NxsKJnLFEZ9OHXf1h(u"ࠨ࡞ࡱࡠࡳ࠭῕")+Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠩส่๊ฮัๆฮࠣ์ัีุࠠำํๆฮࠦไหฮส์ืࠦวๅ฻สส็่ࠦๅๅ้๋ฬࠦสฮฬสะࠥา็ะࠢๆฬ๏ื้ࠠษ็้อืๅอࠢํ฼๋ࠦวๅ็ื็้ฯࠠึ฼ํีฮ่ࠦๅษࠣฮุะอใࠢส่ฯ฿ศࠡใศิฬࠦไะ์ๆࠤฺ๊ใๅหࠣฬฬ๊ฯฯ๊็ࠤ้ฮูืࠢส่๊๎วใ฻ࠣ์ศ๐ึศࠢ็็๏๊ࠦหุะࠤาาๅࠡษ็ู้้ไสࠢࠪῖ")
	maCNIYkc0HOiEGpL3g += smpniPDOhfwI3H4v7c6TG(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢอัิๆࠣีุอไส่ࠢศิฮษࠡว็ํࠥอไๆสิ้ั่ࠦศๅอฬࠥ็๊่ษࠣหุ๋ࠠษๆา็ࠥ๎ริ็สลࠥอไๆ๊สๆ฾ࠦวๅฬํࠤ้อࠠหีอ฻๏฿ࠠะะ๋่์อ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨῗ")
	Dkp5YTLQijOEKF(bbqAtUz36RPGVTvCkejpJXQB(u"ࠫࡷ࡯ࡧࡩࡶࠪῘ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨῙ"),maCNIYkc0HOiEGpL3g,Gk98CL5nXZEN(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩῚ"))
	return
def BWgYxE42vZr():
	tehb3k5a2PufGOdBIUw8j(uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠧࠨΊ"),dEUYJjrhsaPXNo(u"ࠨࠩ῜"),Kwl07iYTtDLN3zP(u"ࠩฮ่ฬัุࠠำๅࠤ้๊ส้ษุู่๋ࠥࠡษ็้อืๅอࠩ῝"),GGCQK6OAtZUXRhvkgJm(u"ࠪวึูไࠡำึห้ฯࠠฤู๊้้ࠣไส่๊่ࠢࠥวว็ฬࠤำีๅศฬ๋ࠣีอࠠศๆหี๋อๅอ࡞ࡱࡠࡳษ่ࠡสสืฯิฯศ็ࠣห้็๊ิส๋็ࠥษฯ็ษ๊ࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡩࡶࡷࡴ࠿࠵࠯ࡧࡣࡦࡩࡧࡵ࡯࡬࠰ࡦࡳࡲ࠵ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠷࠶࠱࠹࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࡡࡴร้ࠢหหึูวๅࠢส๎๊๐ไࠡษ็ํࠥษฯ็ษ๊ࠤࠥࡢ࡮ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠴࠳࠵࠽ࡆࡧ࡮ࡣ࡬ࡰ࠳ࡩ࡯࡮࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ῞"))
	return
def ggeyjRicDPxKpYrfIz3J():
	PxmphrKe7N8oE()
	A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(r6juULGQtnExAko38BZ5Y(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ῟"),S26SnaqcM9XwK8PVphJDv5(u"ࠬ࠭ῠ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠭ࠧῡ"),EAw9bg4rT3Bd8tjSkO(u"่ࠧๆࠣฮึ๐ฯࠡ็ึัࠥาๅ๋฻ࠣห้้วีࠢยࠫῢ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠨษ็็ฬฺ๋ࠠีิ฽ࠥ฿ๅๅࠢส่อืๆศ็ฯࠤํ๋ำฮ้ࠣ๎฾๐ฯࠡีะฬࠥอไึใะหฯࠦๅ็ࠢส่ส์สา่อࠤ฾์ฯࠡษ็ัฬาษࠡว็๎์อ้ࠠษ็ุ้ำ๋ࠠฬ่ࠤฯ๊โศศํหࠥ฿ๆะࠢส๊ฯํวยࠢ฼้ึࠦวๅืไัฬะ้ࠠษ็ุ้ำࠠๅษࠣ๎฻ื้ࠠ็่็๋๊ࠦฮๆࠣฬ฾฼ࠠศๆุ่ฬ้ไࠨΰ"))
	if A5vgi1F6qVunZMas2Nf==S26SnaqcM9XwK8PVphJDv5(u"࠵੡"):
		cLVWgMwAhBrbx2Jfltk4Y96opmv5UH(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࡔࡳࡷࡨપ"))
		tehb3k5a2PufGOdBIUw8j(EAw9bg4rT3Bd8tjSkO(u"ࠩࠪῤ"),GGCQK6OAtZUXRhvkgJm(u"ࠪࠫῥ"),wx18CTJPZ5(u"ࠫฯ๋ࠠๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠣฬฬ๊ใศ็็ࠫῦ"),Gk98CL5nXZEN(u"ࠬหะศࠢๆห๋ะฺ่ࠠา็๋ࠥิไๆฬࠤๆ๐ࠠศฯาࠤฬ๊ๅ้ษๅ฽ࠥ็ฬาสࠣห้๋่ใ฻ࠣห้ศๆࠡ࠰࠱࠲ࠥ๎รัษࠣห้๋ิไๆฬࠤู๊สๆำฬࠤๆหะ็ࠢสีุ๊ࠠศๆุ่่๊ษࠡว็ํࠥอไๆสิ้ั࠭ῧ"))
	return A5vgi1F6qVunZMas2Nf
def cQBJYm17zMNC6XjOfIdReLs4qwxo(showDialogs=qFRrj7ayBKbOsHGSXz(u"ࡕࡴࡸࡩફ")):
	if not showDialogs: showDialogs = bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࡖࡵࡹࡪબ")
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(MMLimtJ8xTFAq9Z012nroaju3de,NNmirJKPp5nWjfC(u"࠭ࡇࡆࡖࠪῨ"),NNmirJKPp5nWjfC(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡻࡥࡲࡶ࡬ࡦ࠰ࡦࡳࡲ࠭Ῡ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠨࠩῪ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠩࠪΎ"),NNmirJKPp5nWjfC(u"ࡉࡥࡱࡹࡥભ"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࠪࠫῬ"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡈࡕࡖࡓࡗࡤ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧ῭"))
	if not aQniqUlZk8.succeeded:
		IOziZlfvdHwqYM6E7mNXSjcCK = MM564HfnUV0XIR(u"ࡊࡦࡲࡳࡦમ")
		Wc8Brs0aYfD9U = sTYDZCo483UAX5IvLGag2ezmR()
		y75wQavkVSLUb2MZf9qo(FeyZbj8tDil0nSHzTwfsUJ9(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ΅"),Mnm2HRoJ9p6e(r1NChsk39OMvT82YemDQnl5)+tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠭ࠠࠡࠢࡋࡘ࡙ࡖࡓࠡࡈࡤ࡭ࡱ࡫ࡤࠡࠢࠣࡐࡦࡨࡥ࡭࠼࡞ࠫ`")+Wc8Brs0aYfD9U+smpniPDOhfwI3H4v7c6TG(u"ࠧ࡞ࠩ῰"))
		if showDialogs: tehb3k5a2PufGOdBIUw8j(ta478EuZQJIWhgBnsf6iU(u"ࠨࠩ῱"),EAw9bg4rT3Bd8tjSkO(u"ࠩࠪῲ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ῳ"),ItgK5FqGDz2Rf7mAJkbT(u"ࠫๆำีࠡษ็หฯ฻วๅࠢสฺ่๊แาࠢ࠱࠲࠳ࠦๅีๅ็อࠥ࠴࠮࠯ࠢส่ฬะีศๆࠣห้๋ิโำࠣࠬฬ๊ัษูࠣห้๋ิโำࠬࠤ้อ๋ࠠ฻่่ࠥ฿ๆะๅࠣ฽้๏ࠠไ๊า๎ࠥ࠴࠮࠯๋ࠢ฽๋ีใࠡๅ๋ำ๏ฺ๋ࠦำࠣๆฬีัࠡ฻็ํࠥอำหะาห๊ࠦวๅ็๋ห็฿ࠠศๆุ่ๆืษࠨῴ"))
	else:
		IOziZlfvdHwqYM6E7mNXSjcCK = QmoEjB3hLIw(u"࡙ࡸࡵࡦય")
		if showDialogs: tehb3k5a2PufGOdBIUw8j(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠬ࠭῵"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠭ࠧῶ"),smpniPDOhfwI3H4v7c6TG(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪῷ"),QmoEjB3hLIw(u"ࠨฮํำࠥาฯศࠢ࠱࠲࠳ࠦวๅษอูฬ๊ࠠศๆุ่ๆืࠠࠩษ็ีอ฽ࠠศๆุ่ๆืࠩࠡ์฼ู้้ࠦ็ัๆࠤํอไษำ้ห๊าࠠใษาีࠥ฿ไ๊ࠢสืฯิฯศ็ࠣห้๋่ศไ฼ࠤฬ๊ๅีใิอࠬῸ"))
	if not IOziZlfvdHwqYM6E7mNXSjcCK and showDialogs: I5IjgLZ0MNOk9fDqRVwyAu1()
	return IOziZlfvdHwqYM6E7mNXSjcCK
def I5IjgLZ0MNOk9fDqRVwyAu1():
	tehb3k5a2PufGOdBIUw8j(EAw9bg4rT3Bd8tjSkO(u"ࠩࠪΌ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠪࠫῺ"),Gk98CL5nXZEN(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧΏ"),S26SnaqcM9XwK8PVphJDv5(u"ࠬฮูืࠢส่๊๎วใ฻ࠣฮาะวอࠢิฬ฼ࠦๅีใิࠤํ่ฯࠡ์ๆ์๋ࠦฬ่ษี็ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬ๊ัษูࠣห้๋ิโำࠣวํࠦ็็ษๆࠤฺ๊ใๅหࠣๅ๏ࠦิ่ษาอࠥอไหึไ๎ึࠦวๅะสูฮࠦศไ๊า๎ࠥ฿ๆะๅࠣ฽้๋วࠡษ้๋ࠥะๅࠡใะูࠥอไษำ้ห๊าฺࠠๆ์ࠤ่๎ฯ๋ࠢส่ส฻ฯศำสฮࠥࡢ࡮ࠡ࠳࠺࠲࠻ࠦࠠࠧࠢࠣ࠵࠽࠴࡛࠱࠯࠼ࡡࠥࠦࠦࠡࠢ࠴࠽࠳ࡡ࠰࠮࠵ࡠࠫῼ"))
	PMr6a2bdOgFf4t5JjonXEZG93BDSv()
	return
def oOmLC8y1REg(RxgdTHfDar8EXt=NxsKJnLFEZ9OHXf1h(u"࠭ࠧ´")):
	B0MZ9n3zypJ = ItgK5FqGDz2Rf7mAJkbT(u"࡚ࡲࡶࡧર")
	if GGCQK6OAtZUXRhvkgJm(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࠪ῾") not in RxgdTHfDar8EXt:
		B0MZ9n3zypJ = Ox8k6IdtuPaG3NlApQK52oYwM(u"ࡆࡢ࡮ࡶࡩ઱")
		A4rSxVHK9Dfieob8B7 = m5NUYqBzGynIOeAg8(tOdiG2HWFRBXg1sUh(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ῿"),Gk98CL5nXZEN(u"ࠫำื่อࠩࠀ"),EAw9bg4rT3Bd8tjSkO(u"ࠬหัิษ็ࠤฺ๊ใๅหࠪࠁ"),r6juULGQtnExAko38BZ5Y(u"࠭ลาีส่ࠥืำศๆฬࠫࠂ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࠃ"),wx18CTJPZ5(u"ࠨ้็ࠤฯื๊ะࠢฦ๊ࠥะัิๆࠣีุอไสࠢศ่๎ࠦวๅ็หี๊าࠠ࠯࠰ࠣว๊ࠦสา์าࠤศ์ࠠหำึ่๋ࠥิไๆฬࠤ๊๎ฬ้ัฬࠤๆ๐ࠠศๆหี๋อๅอࠢยࠫࠄ"))
		if A4rSxVHK9Dfieob8B7 in [-FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠶੢"),uAl3gHavMJZL4xmNe62nDiBoQ(u"࠶੣")]: return
		elif A4rSxVHK9Dfieob8B7==NNmirJKPp5nWjfC(u"࠱੤"):
			B0MZ9n3zypJ = Gk98CL5nXZEN(u"ࡕࡴࡸࡩલ")
			RxgdTHfDar8EXt = CIcPowhneWs5tN3(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬࠅ")
	if B0MZ9n3zypJ:
		if MM564HfnUV0XIR(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤࡕࡌࡅࡡࠪࠆ") not in RxgdTHfDar8EXt:
			A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫࠇ"),Kwl07iYTtDLN3zP(u"ࠬ࠭ࠈ"),wx18CTJPZ5(u"࠭ࠧࠉ"),bbqAtUz36RPGVTvCkejpJXQB(u"ุ้ࠧ฼ࠤฬ๊ๅีๅ็อࠥ็๊ࠡษ็ืั๊ࠧࠊ"),S26SnaqcM9XwK8PVphJDv5(u"ࠨไห่ࠥหัิษ็ࠤฬ๊ำอๆࠣ฽้๐ใࠡล้ࠤฯ้ัา๊ࠢࠣๆูࠠศๆไ฽้ࠦวๅาํࠤศ฿ืศๅࠣห้๋ิไๆฬࠤ࠳ࠦไไ์ࠣ๎ฯ๋ࠠหีฯ๎้ࠦ็ั้ࠣห้๋ิไๆฬࠤๆ๐ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢ࠱ࠤํฮฯ้่๋ࠣีอࠠศๆอืั๐ไࠡี๋ๅࠥะัิๆ้้ࠣ็ࠠๅษࠣๅฬฬฯส่๊ࠢ์ࠦไฦ่๊ࠤ้อ๋ࠠฯอ์๏ูࠦๅ๋ࠣห้๋ิไๆฬࠤฬ๊ส๋ࠢอี๏ีࠠศ่อࠤฬ๊ลษๆส฾ࠥ฿ๆ่ษࠣ࠲ࠥํไࠡไ่ฮࠥฮสไำสีࠥอไๆึๆ่ฮࠦฟࠨࠋ"))
			if A5vgi1F6qVunZMas2Nf!=SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠲੥"):
				tehb3k5a2PufGOdBIUw8j(Gk98CL5nXZEN(u"ࠩࠪࠌ"),NNmirJKPp5nWjfC(u"ࠪࠫࠍ"),QmoEjB3hLIw(u"ࠫฯ๋ࠠฦๆ฽หฦࠦวๅวิืฬ๊ࠧࠎ"),Kwl07iYTtDLN3zP(u"๊ࠬไฤีไࠤอี่็ࠢอืั๐ไࠡษ็ู้้ไสࠢไ๎ูࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠโษ้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์ึฮ฼๐ูࠡ็฼ีๆฯࠠศๆุ่่๊ษ๊ࠡ็หࠥำไ่ษ่ࠣฬ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศࠨࠏ"))
				return
	tehb3k5a2PufGOdBIUw8j(ta478EuZQJIWhgBnsf6iU(u"࠭ࠧࠐ"),qFRrj7ayBKbOsHGSXz(u"ࠧࠨࠑ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࠒ"),tOdiG2HWFRBXg1sUh(u"ࠩไ๎ࠥอไีษือࠥอไใษา้ฮࠦอศ๊็ࠤศ์ࠠหๅอฬࠥืำศๆฬࠤส๊้ࠡษ็้อืๅอ๋ࠢหูือࠡใํ๋ฬࠦวๅ็ื็้ฯࠠฤ๊ࠣห้๋่ื๊฼ࠤํหะศࠢฦีิะࠠอ๊สฬ๋ࠥๆࠡษ็้อืๅอࠢไษี์ࠠฤๅอฬࠥ฿ๆ้ษ้ࠤอื๊ะๅࠣว้หไไฬิ์๋๐ࠠศๆศ๎๊๐ไ๊ࠡอิ่ื้ࠠๆสࠤฯ์ำ๊ࠢฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ࠭ࠓ"))
	search = UIf35nZEj1wylmq(header=bbqAtUz36RPGVTvCkejpJXQB(u"࡛ࠪࡷ࡯ࡴࡦࠢࡤࠤࡲ࡫ࡳࡴࡣࡪࡩࡪࠦࠠࠡษๆฮอࠦัิษ็อࠬࠔ"),source=r1NChsk39OMvT82YemDQnl5)
	if not search: return
	maCNIYkc0HOiEGpL3g = search
	if B0MZ9n3zypJ: type = bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠫࡕࡸ࡯ࡣ࡮ࡨࡱࠬࠕ")
	else: type = SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠬࡓࡥࡴࡵࡤ࡫ࡪ࠭ࠖ")
	VZHWjJTrAPKG1eLEsxpYo2tS5 = ucjsDynE7aJ(type,maCNIYkc0HOiEGpL3g,S26SnaqcM9XwK8PVphJDv5(u"ࡖࡵࡹࡪળ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠭ࠧࠗ"),ta478EuZQJIWhgBnsf6iU(u"ࠧࡆࡏࡄࡍࡑ࠳ࡆࡓࡑࡐ࠱࡚࡙ࡅࡓࡕࠪ࠘"),RxgdTHfDar8EXt)
	return
def RD1iOIYbcUzlh():
	RxgdTHfDar8EXt = tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠨ้ำหࠥอไษำ้ห๊าࠠๅษࠣ๎ําฯࠡๆ๊ࠤศ๐ࠠิ์ิๅึ๊ࠦิฬู๎ๆࠦร๋่ࠢัฯ๎๊ศฬ࠱ࠤฬ๊ศา่ส้ั๊ࠦิฬัำ๊ࠦั้ษห฻ࠥ๎สื็ํ๊๊ࠥๅฮฬ๋๎ฬะࠠๆำไ์฾ฯฺࠠๆ์ࠤุ๐ัโำสฮࠥิวาฮํอ࠳ࠦวๅสิ๊ฬ๋ฬࠡ฼ํี๋ࠥำล๊็ࠤ฾์ࠠฤ์้ࠣาะ่๋ษอࠤฯ๋ࠠหฯ่๎้ํวࠡ฻็ํู๊ࠥาใิหฯ่ࠦๆ๊สๆ฾ࠦฮศำฯ๎ฮࠦࠢๆ๊สๆ฾ࠦืาใࠣฯฬ๊หࠣ࠰ࠣะ๊๐ูࠡษ็วุ๋วย๋ࠢห้๋วาๅสฮࠥ๎วๅื๋ีࠥ๎วๅ็ุ้ํืวห๊ࠢ๎ࠥิวึหࠣฬฬ฻อศส๊ห࠳ࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏์ส่ๅࠣั็๎โࠡษ็฻อ฿้ࠠษ็ู๊ื้ࠠไส๊ํ์ࠠศๆฦ่ๆ๐ษࠡๆ็้้้๊สࠢส่ึ่ๅ๋หࠣࡈࡒࡉࡁࠡวำห้ࠥว็ࠢ็ำ๏้ࠠีๅ๋ํࠥิวึหࠣฬฬ๊ั้ษห฻ࠥ๎วๅฬูห๊๐ๆࠡษ็าฬืฬ๋หࠣๅฬ๊ัอษฤࠤฬ๊ส้ษุู่๋ࠥࠡวาหึฯ่ࠠา๊ࠤฬ๊ำ๋ำไีฬะ้ࠠษ็้ํอโฺࠢส่ำอัอ์ฬ࠲ࠥํะศࠢส่อืๆศ็ฯࠤ์๎ࠠษสึห฼ฯࠠๆฬุๅาࠦไๆ๊สๆ฾ࠦวๅ๊ํฬࠬ࠙")
	Dkp5YTLQijOEKF(FeyZbj8tDil0nSHzTwfsUJ9(u"ࠩࡵ࡭࡬࡮ࡴࠨࠚ"),S26SnaqcM9XwK8PVphJDv5(u"ࠪั็๎โࠡษ็฻อ฿้ࠠษ็ู๊ื้ࠠไส๊ํ์ࠠศๆฦ่ๆ๐ษࠡๆ็้้้๊สࠢส่ึ่ๅ๋หࠪࠛ"),RxgdTHfDar8EXt,FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧࠜ"))
	RxgdTHfDar8EXt = YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࡚ࠬࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤࡩࡵࡥࡴࠢࡱࡳࡹࠦࡨࡰࡵࡷࠤࡦࡴࡹࠡࡥࡲࡲࡹ࡫࡮ࡵࠢࡲࡲࠥࡧ࡮ࡺࠢࡶࡩࡷࡼࡥࡳ࠰ࠣࡍࡹࠦ࡯࡯࡮ࡼࠤࡺࡹࡥࡴࠢ࡯࡭ࡳࡱࡳࠡࡶࡲࠤࡪࡳࡢࡦࡦࡧࡩࡩࠦࡣࡰࡰࡷࡩࡳࡺࠠࡵࡪࡤࡸࠥࡽࡡࡴࠢࡸࡴࡱࡵࡡࡥࡧࡧࠤࡹࡵࠠࡱࡱࡳࡹࡱࡧࡲࠡࡱࡱࡰ࡮ࡴࡥࠡࡸ࡬ࡨࡪࡵࠠࡩࡱࡶࡸ࡮ࡴࡧࠡࡵ࡬ࡸࡪࡹ࠮ࠡࡃ࡯ࡰࠥࡺࡲࡢࡦࡨࡱࡦࡸ࡫ࡴ࠮ࠣࡺ࡮ࡪࡥࡰࡵ࠯ࠤࡹࡸࡡࡥࡧࠣࡲࡦࡳࡥࡴ࠮ࠣࡷࡪࡸࡶࡪࡥࡨࠤࡲࡧࡲ࡬ࡵ࠯ࠤࡨࡵࡰࡺࡴ࡬࡫࡭ࡺࡥࡥࠢࡺࡳࡷࡱࠬࠡ࡮ࡲ࡫ࡴࡹࠠࡳࡧࡩࡩࡷ࡫࡮ࡤࡧࡧࠤ࡭࡫ࡲࡦ࡫ࡱࠤࡧ࡫࡬ࡰࡰࡪࠤࡹࡵࠠࡵࡪࡨ࡭ࡷࠦࡲࡦࡵࡳࡩࡨࡺࡩࡷࡧࠣࡳࡼࡴࡥࡳࡵࠣ࠳ࠥࡩ࡯࡮ࡲࡤࡲ࡮࡫ࡳ࠯ࠢࡗ࡬ࡪࠦࡰࡳࡱࡪࡶࡦࡳࠠࡪࡵࠣࡲࡴࡺࠠࡳࡧࡶࡴࡴࡴࡳࡪࡤ࡯ࡩࠥ࡬࡯ࡳࠢࡺ࡬ࡦࡺࠠࡰࡶ࡫ࡩࡷࠦࡰࡦࡱࡳࡰࡪࠦࡵࡱ࡮ࡲࡥࡩࠦࡴࡰࠢ࠶ࡶࡩࠦࡰࡢࡴࡷࡽࠥࡹࡩࡵࡧࡶ࠲ࠥ࡝ࡥࠡࡷࡵ࡫ࡪࠦࡡ࡭࡮ࠣࡧࡴࡶࡹࡳ࡫ࡪ࡬ࡹࠦ࡯ࡸࡰࡨࡶࡸ࠲ࠠࡵࡱࠣࡶࡪࡩ࡯ࡨࡰ࡬ࡾࡪࠦࡴࡩࡣࡷࠤࡹ࡮ࡥࠡ࡮࡬ࡲࡰࡹࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡦࠣࡻ࡮ࡺࡨࡪࡰࠣࡸ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢࡤࡶࡪࠦ࡬ࡰࡥࡤࡸࡪࡪࠠࡴࡱࡰࡩࡼ࡮ࡥࡳࡧࠣࡩࡱࡹࡥࠡࡱࡱࠤࡹ࡮ࡥࠡࡹࡨࡦࠥࡵࡲࠡࡸ࡬ࡨࡪࡵࠠࡦ࡯ࡥࡩࡩࡪࡥࡥࠢࡤࡶࡪࠦࡦࡳࡱࡰࠤࡴࡺࡨࡦࡴࠣࡺࡦࡸࡩࡰࡷࡶࠤࡸ࡯ࡴࡦࡵ࠱ࠤࡎ࡬ࠠࡺࡱࡸࠤ࡭ࡧࡶࡦࠢࡤࡲࡾࠦ࡬ࡦࡩࡤࡰࠥ࡯ࡳࡴࡷࡨࡷࠥࡶ࡬ࡦࡣࡶࡩࠥࡩ࡯࡯ࡶࡤࡧࡹࠦࡡࡱࡲࡵࡳࡵࡸࡩࡢࡶࡨࠤࡲ࡫ࡤࡪࡣࠣࡪ࡮ࡲࡥࠡࡱࡺࡲࡪࡸࡳࠡ࠱ࠣ࡬ࡴࡹࡴࡦࡴࡶ࠲࡚ࠥࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤ࡮ࡹࠠࡴ࡫ࡰࡴࡱࡿࠠࡢࠢࡺࡩࡧࠦࡢࡳࡱࡺࡷࡪࡸ࠮ࠨࠝ")
	Dkp5YTLQijOEKF(smpniPDOhfwI3H4v7c6TG(u"࠭࡬ࡦࡨࡷࠫࠞ"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠧࡅ࡫ࡪ࡭ࡹࡧ࡬ࠡࡏ࡬ࡰࡱ࡫࡮࡯࡫ࡸࡱࠥࡉ࡯ࡱࡻࡵ࡭࡬࡮ࡴࠡࡃࡦࡸࠥ࠮ࡄࡎࡅࡄ࠭ࠬࠟ"),RxgdTHfDar8EXt,ta478EuZQJIWhgBnsf6iU(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫࠠ"))
	return
def w7bg3nXdoQlN90CZRTxLtEcW84D(aZhcuMGisIkl4npqDoJSrWy5fExX):
	ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0 = oos8ymFi9CN2z1jXcR.executeJSONRPC(FeyZbj8tDil0nSHzTwfsUJ9(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬࠡ")+aZhcuMGisIkl4npqDoJSrWy5fExX+NNmirJKPp5nWjfC(u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡨࡤࡰࡸ࡫ࡽࡾࠩࠢ"))
	DzRqxnIrNLUgj4PYXFkZJc = tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࡗࡶࡺ࡫઴")
	if DzRqxnIrNLUgj4PYXFkZJc:
		w6vebiEZtpCjJcILP8Skx5rHn.sleep(NxsKJnLFEZ9OHXf1h(u"࠳੦"))
		oos8ymFi9CN2z1jXcR.executebuiltin(smpniPDOhfwI3H4v7c6TG(u"࡚ࠫࡶࡤࡢࡶࡨࡐࡴࡩࡡ࡭ࡃࡧࡨࡴࡴࡳࠨࠣ"))
		w6vebiEZtpCjJcILP8Skx5rHn.sleep(uAl3gHavMJZL4xmNe62nDiBoQ(u"࠴੧"))
	return
def dufiHAe1WJU3QEMDBPRpCy0GwOmcg():
	tehb3k5a2PufGOdBIUw8j(FeyZbj8tDil0nSHzTwfsUJ9(u"ࠬ࠭ࠤ"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠭ࠧࠥ"),tOdiG2HWFRBXg1sUh(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࠦ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠨษ็ฬึ์วๆฮ่ࠣฬ๊ࠦโฯุࠤูํวะหࠣห้ะิโ์ิࠤ฾์ฯࠡษ็หฯ฻วๅࠢหห้๋่ศไ฼ࠤฬ๊ๅีใิอࠥ๎ไ่าสࠤๆ๐ࠠฮษ็ࠤํา่ะࠢื๋ฬีษࠡ฼ํีࠥ฻อ๋ฯฬࠤศ๎ࠠๆ่อ๋๏ฯࠠศๆุ่ฬำ๊สࠢฦ์๋ࠥา๋ใฬࠤๆอๆ้ࠡำห๊ࠥๆࠡ์๋ๆๆࠦวๅำห฻ࠥอไๆึไีࠥ๎ไ็ࠢํ์็็ฺࠠ็็ࠤฬ๊ศา่ส้ั࠭ࠧ"))
	KNtfbIlVUmyn0ukZT2LD9iOSEHzR()
	return
def PMr6a2bdOgFf4t5JjonXEZG93BDSv():
	url = S26SnaqcM9XwK8PVphJDv5(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡰ࡭ࡷࡸ࡯ࡳࡵ࠱࡯ࡴࡪࡩ࠯ࡶࡹ࠳ࡷ࡫࡬ࡦࡣࡶࡩࡸ࠵ࡷࡪࡰࡧࡳࡼࡹ࠯ࡸ࡫ࡱ࠺࠹࠵ࠧࠨ")
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,Gk98CL5nXZEN(u"ࠪࡋࡊ࡚ࠧࠩ"),url,r6juULGQtnExAko38BZ5Y(u"ࠫࠬࠪ"),dEUYJjrhsaPXNo(u"ࠬ࠭ࠫ"),Gk98CL5nXZEN(u"࠭ࠧࠬ"),Gk98CL5nXZEN(u"ࠧࠨ࠭"),smpniPDOhfwI3H4v7c6TG(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡗࡍࡕࡗࡠࡎࡄࡘࡊ࡙ࡔࡠࡍࡒࡈࡎࡥࡖࡆࡔࡖࡍࡔࡔ࠭࠲ࡵࡷࠫ࠮"))
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	RhUc7pqD2x8BzdLTQOEZ9NaA1mXMnH = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall(qFRrj7ayBKbOsHGSXz(u"ࠩࡷ࡭ࡹࡲࡥ࠾ࠤ࡮ࡳࡩ࡯࠭ࠩ࡞ࡧ࠯ࡡ࠴࡜ࡥ࠭࠰࡟ࡦ࠳ࡺࡂ࠯࡝ࡡ࠰࠯࠭ࠨ࠯"),M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	RhUc7pqD2x8BzdLTQOEZ9NaA1mXMnH = RhUc7pqD2x8BzdLTQOEZ9NaA1mXMnH[tOdiG2HWFRBXg1sUh(u"࠴੨")].split(CIcPowhneWs5tN3(u"ࠪ࠱ࠬ࠰"))[tOdiG2HWFRBXg1sUh(u"࠴੨")]
	Kx9heakLRV32MuUg = str(wH3qxmuXBTeak)
	fjvEc6Ayo9UrIXKJLzaBPR12eM = CIcPowhneWs5tN3(u"ࠫࡠࡘࡔࡍ࡟ศูิอัࠡๅ๋ำ๏ࠦวๅลั๎ึࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥ࠭࠱")+dEUYJjrhsaPXNo(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ࠲")+RhUc7pqD2x8BzdLTQOEZ9NaA1mXMnH+Ox8k6IdtuPaG3NlApQK52oYwM(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ࠳")
	fjvEc6Ayo9UrIXKJLzaBPR12eM += MM564HfnUV0XIR(u"ࠧ࡝ࡰ࡟ࡲࠬ࠴")+YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠨ࡝ࡕࡘࡑࡣลึัสี้่ࠥะ์ࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦ็้ࠢ࠽ࠤࠥࠦࠧ࠵")+Kwl07iYTtDLN3zP(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ࠶")+Kx9heakLRV32MuUg+tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ࠷")
	tehb3k5a2PufGOdBIUw8j(wx18CTJPZ5(u"ࠫࠬ࠸"),NxsKJnLFEZ9OHXf1h(u"ࠬ࠭࠹"),bbqAtUz36RPGVTvCkejpJXQB(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ࠺"),fjvEc6Ayo9UrIXKJLzaBPR12eM)
	return
def yNUAfgCMeO0i8YrQWn():
	hwAK5bC7pHoU6VrSdgsvM,cE6OHoADvlhK1gVy2p8rYbWXFmGQ,YOTH54N3yLc9K,fjvEc6Ayo9UrIXKJLzaBPR12eM,qqBeH3CnirSw,uZhGnw1FQYymBEC5AOzMgo,yy6XVA9xcwv2J3gDG = Kwl07iYTtDLN3zP(u"ࠧࠨ࠻"),Kwl07iYTtDLN3zP(u"ࠨࠩ࠼"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࠩࠪ࠽"),dEUYJjrhsaPXNo(u"ࠪࠫ࠾"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠫࠬ࠿"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠬ࠭ࡀ"),ItgK5FqGDz2Rf7mAJkbT(u"࠭ࠧࡁ")
	VVNkoRCUm96MbtuqgrOe,nnEvTodm9kYGiLQZS4NAyVf5,Bm1goPlAYH4KGbwjOqNnReQJ,hdx8HQpRA3lMsGWfzB7vCV4co0qE = {YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠧࡢࠩࡂ"):CgPbwXm1RilpJUSGHLhy(u"ࠨࡣࠪࡃ")},{},[],{}
	url = mR20sONyKIlV[NxsKJnLFEZ9OHXf1h(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩࡄ")][MM564HfnUV0XIR(u"࠶੩")]
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(RvKQX7HgZ6faBueLsMjxGtPobTd0,MM564HfnUV0XIR(u"ࠪࡔࡔ࡙ࡔࠨࡅ"),url,VVNkoRCUm96MbtuqgrOe,YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠫࠬࡆ"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠬ࠭ࡇ"),Gk98CL5nXZEN(u"࠭ࠧࡈ"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡘࡗࡆࡍࡅࡠࡔࡈࡔࡔࡘࡔ࠮࠳ࡶࡸࠬࡉ"))
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2.replace(Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠨࡗࡱ࡭ࡹ࡫ࡤࠡࡕࡷࡥࡹ࡫ࡳࠨࡊ"),smpniPDOhfwI3H4v7c6TG(u"ࠩࡘࡗࡆ࠭ࡋ"))
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2.replace(CgPbwXm1RilpJUSGHLhy(u"࡙ࠪࡳ࡯ࡴࡦࡦࠣࡏ࡮ࡴࡧࡥࡱࡰࠫࡌ"),CgPbwXm1RilpJUSGHLhy(u"࡚ࠫࡑࠧࡍ"))
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2.replace(ta478EuZQJIWhgBnsf6iU(u"࡛ࠬ࡮ࡪࡶࡨࡨࠥࡇࡲࡢࡤࠣࡉࡲ࡯ࡲࡢࡶࡨࡷࠬࡎ"),wx18CTJPZ5(u"࠭ࡕࡂࡇࠪࡏ"))
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2.replace(r6juULGQtnExAko38BZ5Y(u"ࠧࡔࡣࡸࡨ࡮ࠦࡁࡳࡣࡥ࡭ࡦ࠭ࡐ"),tOdiG2HWFRBXg1sUh(u"ࠨࡍࡖࡅࠬࡑ"))
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2.replace(GGCQK6OAtZUXRhvkgJm(u"ࠩࡑࡳࡷࡺࡨࠡࡏࡤࡧࡪࡪ࡯࡯࡫ࡤࠫࡒ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠪࡒ࠳ࡓࡡࡤࡧࡧࡳࡳ࡯ࡡࠨࡓ"))
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2.replace(CgPbwXm1RilpJUSGHLhy(u"ࠫ࡜࡫ࡳࡵࡧࡵࡲ࡙ࠥࡡࡩࡣࡵࡥࠬࡔ"),GGCQK6OAtZUXRhvkgJm(u"ࠬ࡝࠮ࡔࡣ࡫ࡥࡷࡧࠧࡕ"))
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2.replace(NNmirJKPp5nWjfC(u"࠭࡟ࡠࡡࠪࡖ"),ta478EuZQJIWhgBnsf6iU(u"ࠧࠡࠢࠪࡗ"))
	try: vqeDGJziuWPSg = GVQAnvYCT3dS(qFRrj7ayBKbOsHGSXz(u"ࠨ࡮࡬ࡷࡹ࠭ࡘ"),M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2)
	except:
		tehb3k5a2PufGOdBIUw8j(smpniPDOhfwI3H4v7c6TG(u"࡙ࠩࠪ"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࡚ࠪࠫ"),MM564HfnUV0XIR(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊า࡛ࠧ"),WbM6qAjrn7fEXGZw(u"ࠬ็ิๅࠢไ๎ࠥาไษ่ࠢัฯ๎๊ศฬࠣฮ็ื๊าࠢส่ฬูสฯัส้ࠬ࡜"))
		return
	uGUmPrOHVsRy7iY,XYwfavkhFGR5u0ndbS,dUewzokWyxF4V9mP = vqeDGJziuWPSg
	hdx8HQpRA3lMsGWfzB7vCV4co0qE = {}
	i4PxLrdnAGawpChbfSK = [bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠭ࡃࡂࡒࡗࡇࡍࡇࡉࡅࠩ࡝"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠧࡄࡃࡓࡘࡈࡎࡁࡕࡑࡎࡉࡓ࠭࡞")]
	vC1pXNyUx0j5GT2qdnr8LIV3SD = [CIcPowhneWs5tN3(u"ࠨࡃࡏࡐࠬ࡟"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩࡠ"),Gk98CL5nXZEN(u"ࠪࡍࡓ࡙ࡔࡂࡎࡏࠫࡡ"),ta478EuZQJIWhgBnsf6iU(u"ࠫࡒࡋࡔࡓࡑࡓࡓࡑࡏࡓࠨࡢ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠬࡘࡅࡑࡑࡖࠫࡣ")]+i4PxLrdnAGawpChbfSK+ANjhxR3Z6pBcJ+qHUNxQG27zhe8LI05O
	for VewOrPR4kX,boPgh1KvGN5XDcsJCmxuRyV3EY,zLtE1namsTRrp in XYwfavkhFGR5u0ndbS:
		zLtE1namsTRrp = zKGXT5sJeRq(zLtE1namsTRrp)
		zLtE1namsTRrp = zLtE1namsTRrp.strip(GGCQK6OAtZUXRhvkgJm(u"࠭ࠠࠨࡤ")).strip(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠧࠡ࠰ࠪࡥ"))
		fjvEc6Ayo9UrIXKJLzaBPR12eM += bbqAtUz36RPGVTvCkejpJXQB(u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ࡦ")+VewOrPR4kX+GGCQK6OAtZUXRhvkgJm(u"ࠩ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࡧ")+zLtE1namsTRrp+tOdiG2HWFRBXg1sUh(u"ࠪࡠࡳ࠭ࡨ")
		if boPgh1KvGN5XDcsJCmxuRyV3EY.isdigit():
			hdx8HQpRA3lMsGWfzB7vCV4co0qE[VewOrPR4kX] = int(boPgh1KvGN5XDcsJCmxuRyV3EY)
			if int(boPgh1KvGN5XDcsJCmxuRyV3EY)>NNmirJKPp5nWjfC(u"࠷࠰࠱੪"): boPgh1KvGN5XDcsJCmxuRyV3EY = uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠫ࡭࡯ࡧࡩࡷࡶࡥ࡬࡫ࠧࡩ")
			else: boPgh1KvGN5XDcsJCmxuRyV3EY = uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠬࡲ࡯ࡸࡷࡶࡥ࡬࡫ࠧࡪ")
		if VewOrPR4kX not in vC1pXNyUx0j5GT2qdnr8LIV3SD:
			if   boPgh1KvGN5XDcsJCmxuRyV3EY==ta478EuZQJIWhgBnsf6iU(u"࠭ࡨࡪࡩ࡫ࡹࡸࡧࡧࡦࠩ࡫"): hwAK5bC7pHoU6VrSdgsvM += tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠧࠡࠢࠪ࡬")+VewOrPR4kX
			elif boPgh1KvGN5XDcsJCmxuRyV3EY==Kwl07iYTtDLN3zP(u"ࠨ࡮ࡲࡻࡺࡹࡡࡨࡧࠪ࡭"): cE6OHoADvlhK1gVy2p8rYbWXFmGQ += Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠩࠣࠤࠬ࡮")+VewOrPR4kX
	jSNMvgAHLyEVCi761dt5DWT8,a4f02cHpog63kGy9AB5lD,b2dpoyJg4T8 = list(zip(*XYwfavkhFGR5u0ndbS))
	for VewOrPR4kX in sorted(VV7Iv9cSholtn1MJsrXTjRLGy4ie):
		if VewOrPR4kX not in jSNMvgAHLyEVCi761dt5DWT8:
			fjvEc6Ayo9UrIXKJLzaBPR12eM += wx18CTJPZ5(u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ࡯")+VewOrPR4kX+tOdiG2HWFRBXg1sUh(u"ࠫ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨࡰ")+S26SnaqcM9XwK8PVphJDv5(u"๊ࠬวࠡ์๋ะิ࠭ࡱ")+NNmirJKPp5nWjfC(u"࠭࡜࡯࡞ࡱࠫࡲ")
			if VewOrPR4kX not in vC1pXNyUx0j5GT2qdnr8LIV3SD: YOTH54N3yLc9K += WbM6qAjrn7fEXGZw(u"ࠧࠡࠢࠪࡳ")+VewOrPR4kX
	for zLtE1namsTRrp,VVPq2W7SsGEDkZCo in uGUmPrOHVsRy7iY:
		zLtE1namsTRrp = zKGXT5sJeRq(zLtE1namsTRrp)
		qqBeH3CnirSw += zLtE1namsTRrp+NxsKJnLFEZ9OHXf1h(u"ࠨ࠼ࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭ࡴ")+str(VVPq2W7SsGEDkZCo)+bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࠥࠦࠧࡵ")
	hwAK5bC7pHoU6VrSdgsvM = hwAK5bC7pHoU6VrSdgsvM.strip(uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠪࠤࠬࡶ"))
	cE6OHoADvlhK1gVy2p8rYbWXFmGQ = cE6OHoADvlhK1gVy2p8rYbWXFmGQ.strip(Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠫࠥ࠭ࡷ"))
	YOTH54N3yLc9K = YOTH54N3yLc9K.strip(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠬࠦࠧࡸ"))
	yHPU2IF1GkCDbX3vQ75NVnmWAlic = hwAK5bC7pHoU6VrSdgsvM+smpniPDOhfwI3H4v7c6TG(u"࠭ࠠࠡࠩࡹ")+cE6OHoADvlhK1gVy2p8rYbWXFmGQ
	oofZ02IPyDQ75BFJhRmLpat1eWrOES  = QmoEjB3hLIw(u"ࠧๆ๊สๆ฾ࠦๆอฯࠣห้ฮั็ษ่ะࠥฮสี฼ํ่ࠥ็๊ะ์๋๋ฬะࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠫࡺ")+tOdiG2HWFRBXg1sUh(u"ࠨ࡞ࡱࠫࡻ")+GGCQK6OAtZUXRhvkgJm(u"๋๋ࠩีอࠠๆ฻้ห์ࠦลัษ่ࠣิ๐ใࠡ็ื็้ฯࠠโ้ํࠤ้๐ำห่๊ࠢࠥอไษำ้ห๊าࠧࡼ")+cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠪࡠࡳ࠭ࡽ")
	oofZ02IPyDQ75BFJhRmLpat1eWrOES += I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧࡾ")+yHPU2IF1GkCDbX3vQ75NVnmWAlic+Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱࠫࡿ")
	oofZ02IPyDQ75BFJhRmLpat1eWrOES += cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠭ๅ้ษๅ฽๊ࠥๅࠡ์ื฾้ࠦวๅสิ๊ฬ๋ฬࠡ็้๋ฬࠦแ๋ัํ์์อสࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠬࢀ")+r6juULGQtnExAko38BZ5Y(u"ࠧ࡝ࡰࠪࢁ")+r6juULGQtnExAko38BZ5Y(u"ࠨ๊๊ิฬࠦๅฺ่ส๋ࠥออห็ส่้ࠥศ๋ำࠣ์ั๎ฯࠡ็ื็้ฯࠠโ์ࠣห้ฮั็ษ่ะࠬࢂ")+qFRrj7ayBKbOsHGSXz(u"ࠩ࡟ࡲࠬࢃ")
	oofZ02IPyDQ75BFJhRmLpat1eWrOES += Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭ࢄ")+YOTH54N3yLc9K+Gk98CL5nXZEN(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࢅ")
	fE4LzVw0bU,G0nPiIxKB26VNZMpJtT,Q92nRud4CcNZOTrlkJsUK,gg8XQK6BHSvDwPntrisLdWyAhbc = YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠰੫"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠰੫"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠰੫"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠰੫")
	all = hdx8HQpRA3lMsGWfzB7vCV4co0qE[uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠬࡇࡌࡍࠩࢆ")]
	if FeyZbj8tDil0nSHzTwfsUJ9(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ࢇ") in list(hdx8HQpRA3lMsGWfzB7vCV4co0qE.keys()): fE4LzVw0bU = hdx8HQpRA3lMsGWfzB7vCV4co0qE[ta478EuZQJIWhgBnsf6iU(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ࢈")]
	if YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩࢉ") in list(hdx8HQpRA3lMsGWfzB7vCV4co0qE.keys()): G0nPiIxKB26VNZMpJtT = hdx8HQpRA3lMsGWfzB7vCV4co0qE[cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠩࡌࡒࡘ࡚ࡁࡍࡎࠪࢊ")]
	if CgPbwXm1RilpJUSGHLhy(u"ࠪࡑࡊ࡚ࡒࡐࡒࡒࡐࡎ࡙ࠧࢋ") in list(hdx8HQpRA3lMsGWfzB7vCV4co0qE.keys()): Q92nRud4CcNZOTrlkJsUK = hdx8HQpRA3lMsGWfzB7vCV4co0qE[Kwl07iYTtDLN3zP(u"ࠫࡒࡋࡔࡓࡑࡓࡓࡑࡏࡓࠨࢌ")]
	if NNmirJKPp5nWjfC(u"ࠬࡘࡅࡑࡑࡖࠫࢍ") in list(hdx8HQpRA3lMsGWfzB7vCV4co0qE.keys()): gg8XQK6BHSvDwPntrisLdWyAhbc = hdx8HQpRA3lMsGWfzB7vCV4co0qE[tOdiG2HWFRBXg1sUh(u"࠭ࡒࡆࡒࡒࡗࠬࢎ")]
	wmbiq7O5LXJAM2EQ = all-fE4LzVw0bU-G0nPiIxKB26VNZMpJtT-Q92nRud4CcNZOTrlkJsUK-gg8XQK6BHSvDwPntrisLdWyAhbc
	aQ0kNq9gnYBKJ5yV6oRhXZ7ImfwreT,BB1Tg7xYqnhvEc58afzV = dUewzokWyxF4V9mP[Gk98CL5nXZEN(u"࠱੬")]
	aQ0kNq9gnYBKJ5yV6oRhXZ7ImfwreT,JkPpXon1YzHi2yBbjVSZe = dUewzokWyxF4V9mP[WbM6qAjrn7fEXGZw(u"࠳੭")]
	ng97BjVmUofqXxypC = BB1Tg7xYqnhvEc58afzV-JkPpXon1YzHi2yBbjVSZe
	yy6XVA9xcwv2J3gDG += CgPbwXm1RilpJUSGHLhy(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ࢏")+str(JkPpXon1YzHi2yBbjVSZe)+wx18CTJPZ5(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ࢐")+YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠩส่฾ีฯࠡษ็ั็๐โ๋ࠢ็่ศา็ำหࠣ࠾ࠥ࠭࢑")
	yy6XVA9xcwv2J3gDG += Kwl07iYTtDLN3zP(u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ࢒")+str(ng97BjVmUofqXxypC)+smpniPDOhfwI3H4v7c6TG(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭࢓")+NNmirJKPp5nWjfC(u"ࠬฮวิฬัำฬ๋ࠠࡱࡴࡲࡼࡾࠦร้ࠢࡹࡴࡳࠦ࠺ࠡࠩ࢔")
	yy6XVA9xcwv2J3gDG += GGCQK6OAtZUXRhvkgJm(u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ࢕")+str(BB1Tg7xYqnhvEc58afzV)+ItgK5FqGDz2Rf7mAJkbT(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࢖")+YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠨษ็฽ิีࠠศๆๆ่๏ࠦไอ็ํ฽ࠥอไฤฮ๊ึฮࠦ࠺ࠡࠩࢗ")
	yy6XVA9xcwv2J3gDG += bbqAtUz36RPGVTvCkejpJXQB(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ࢘")+str(len(dUewzokWyxF4V9mP[ItgK5FqGDz2Rf7mAJkbT(u"࠵੮"):]))+YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡ࢙ࠬ")+zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠫ฾ีฯࠡษ็ำํ๊ࠠศๆอ๎ࠥ็๊่ษࠣวัําสࠢ࠽ࠤࡡࡴ࡜࡯࢚ࠩ")
	for ir0ULhG6nfRXJHkpAgbF,gg6VwuY0xOi7 in dUewzokWyxF4V9mP[Kwl07iYTtDLN3zP(u"࠶੯"):]:
		ir0ULhG6nfRXJHkpAgbF = zKGXT5sJeRq(ir0ULhG6nfRXJHkpAgbF)
		ir0ULhG6nfRXJHkpAgbF = ir0ULhG6nfRXJHkpAgbF.strip(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࢛ࠬࠦࠧ")).strip(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠭ࠠ࠯ࠩ࢜"))
		yy6XVA9xcwv2J3gDG += ir0ULhG6nfRXJHkpAgbF+qFRrj7ayBKbOsHGSXz(u"ࠧ࠻ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ࢝")+str(gg6VwuY0xOi7)+uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࠤࠥ࠭࢞")
	uZhGnw1FQYymBEC5AOzMgo += tOdiG2HWFRBXg1sUh(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ࢟")+str(wmbiq7O5LXJAM2EQ)+uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࢠ")+ta478EuZQJIWhgBnsf6iU(u"ࠫๆ๐ฯ๋๊๊หฯࠦวีฬ฽่ฯࠦ࠺ࠡࠩࢡ")
	uZhGnw1FQYymBEC5AOzMgo += ItgK5FqGDz2Rf7mAJkbT(u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪࢢ")+str(fE4LzVw0bU)+r6juULGQtnExAko38BZ5Y(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨࢣ")+YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ุࠧๆหหฯࠦำ๋ำไีࠥฮว๋อ๋๊ࠥࡀࠠࠨࢤ")
	uZhGnw1FQYymBEC5AOzMgo += wx18CTJPZ5(u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ࢥ")+str(gg8XQK6BHSvDwPntrisLdWyAhbc)+S26SnaqcM9XwK8PVphJDv5(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࢦ")+GGCQK6OAtZUXRhvkgJm(u"ࠪ฻้ฮวหࠢึ๎ึ็ัࠡษ็ุ้ะ่ะ฻ࠣ࠾ࠥ࠭ࢧ")
	uZhGnw1FQYymBEC5AOzMgo += FeyZbj8tDil0nSHzTwfsUJ9(u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩࢨ")+str(G0nPiIxKB26VNZMpJtT)+CIcPowhneWs5tN3(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࢩ")+WbM6qAjrn7fEXGZw(u"࠭สฬสํฮࠥะืษ์ๅࠤ่๎ฯ๋ࠢ฼้ฬีࠠ࠻ࠢࠪࢪ")
	uZhGnw1FQYymBEC5AOzMgo += cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬࢫ")+str(Q92nRud4CcNZOTrlkJsUK)+r6juULGQtnExAko38BZ5Y(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢬ")+FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠩอฯอ๐สࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥࡀࠠࠨࢭ")
	uZhGnw1FQYymBEC5AOzMgo += Gk98CL5nXZEN(u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨࢮ")+str(len(uGUmPrOHVsRy7iY))+S26SnaqcM9XwK8PVphJDv5(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࢯ")+zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠬี่ๅࠢื฾้ะࠠโ์า๎ํํวหࠢ࠽ࠤࠬࢰ")
	uZhGnw1FQYymBEC5AOzMgo += r6juULGQtnExAko38BZ5Y(u"࠭࡜࡯࡞ࡱࠫࢱ")+qqBeH3CnirSw
	Dkp5YTLQijOEKF(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠧࡤࡧࡱࡸࡪࡸࠧࢲ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠨ฻าำࠥอไฤฮ๊ึฮࠦวๅฬํࠤฬูสฯั่ฮࠥํะศࠢส่อืๆศ็ฯࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠡใํࠤฬู๊ศๆ่ࠤ่๊็ࠨࢳ"),yy6XVA9xcwv2J3gDG,WbM6qAjrn7fEXGZw(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬࢴ"))
	Dkp5YTLQijOEKF(EAw9bg4rT3Bd8tjSkO(u"ࠪࡧࡪࡴࡴࡦࡴࠪࢵ"),qFRrj7ayBKbOsHGSXz(u"ࠫ฾ีฯࠡษ็ๅ๏ี๊้้สฮࠥอไห์ุࠣ฿๊็ศ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠥ็๊ࠡษ็฽ฬ๊ๅࠡๅ็๋ࠬࢶ"),uZhGnw1FQYymBEC5AOzMgo,SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨࢷ"))
	Dkp5YTLQijOEKF(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ࢸ"),EAw9bg4rT3Bd8tjSkO(u"ࠧๆ๊สๆ฾ࠦวีฬ฽่ฯࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠣๅ๏ࠦวๅ฻ส่๊ࠦใๅ้ࠪࢹ"),oofZ02IPyDQ75BFJhRmLpat1eWrOES,bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫࢺ"))
	Dkp5YTLQijOEKF(r6juULGQtnExAko38BZ5Y(u"ࠩ࡯ࡩ࡫ࡺࠧࢻ"),tOdiG2HWFRBXg1sUh(u"ࠪว฾๊้ࠡษ็ำํ๊ࠠศๆอ๎ࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠢสืฯิฯๆฬࠣห้ฮั็ษ่ะࠬࢼ"),fjvEc6Ayo9UrIXKJLzaBPR12eM,qFRrj7ayBKbOsHGSXz(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬࢽ"))
	return
def rejRwiPNUAsGVZYL7tTB():
	maCNIYkc0HOiEGpL3g = NNmirJKPp5nWjfC(u"ࠬํะศࠢส่อืๆศ็ฯࠤ๏฿ๅๅࠢสๅ฻๊ࠠษษึฮำีวๆࠢฯ่ิࠦใ้ัํࠤ࠭ࡑ࡯ࡥ࡫ࠣࡗࡰ࡯࡮ࠪࠢส่ี๐ࠠศี่๋ࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊ࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ࡟ࡲࡡࡴ้ࠠ็่็๋ࠦสฬสํฮ์ࠦศศีอาิอๅࠡ็ึฮํีูࠡ฻่หิࠦࡅࡎࡃࡇࠤࡗ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹࠡล๋ࠤฯำๅ๋ๆ๊ࠤ๊์࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯࡞ࡱࠤ์ึ็ࠡษ็ีุอไส๋ࠢ฾๏ื็ศࠢๆฯ๏ืࠠๆ๊ฯ์ิฯࠠโ์ࠣๆฬฬๅสࠢัำ๊อสࠡษ็ฬึ์วๆฮࠣ์ฬ๊ๅำ์าࠤศ๐ึศ่ࠢ์ั๎ฯࠡใํࠤ็อฦๆหࠣวั๎ศสࠢส่อืๆศ็ฯࠫࢾ")
	Dkp5YTLQijOEKF(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ࢿ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࣀ"),maCNIYkc0HOiEGpL3g,FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫࣁ"))
	return
def EEqzDPROnos2aIiyCm0hSlVJdKv8():
	maCNIYkc0HOiEGpL3g = dEUYJjrhsaPXNo(u"ࠩส่ึอศุ์้ࠤศีๆศ้ࠣๅ๏ํๅศࠢอ฻อ๐โࠡๅ๋ำ๏ูࠦๆษาࠤํํ่ࠡ฻หหึฯฺ่ࠠࠣฮะฮ๊หࠢๆห๊๊ࠠศ๊อ์๊อส๋ๅํࠤ้ฮั็ษ่ะ้่ࠥะ์ࠣ์๊฿็ࠡษูหๆฯฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠣ์๊฿็ࠡษูหๆฯࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤํู๋่ࠢสฺฬ็ษࠡ็ึฮํีูࠡ฻่หิ่ࠦโ์๊ࠤศ๐ึศࠢฯ้๏฿ࠠศ฻าหิะࠠไ๊า๎ࠥอไๆู็์อฯࠠๅ฻่่ࠥฮั็ษ่ะࠥ฿ๅศัࠣ์่๊็ศࠢอฮ๊ࠦว้ฬ๋้ฬะ๊ไ์สࠤํ๊วࠡฬะฮฬาࠠฤ์๊ࠣํ฿ࠠๆ่ࠣห้ิศาหࠣๅ๏ࠦใ้ัํࠤศ๎ࠠศๆัฬึฯࠠโ์ࠣฮะฮ๊หࠢฦฺฬ็วหࠢๆ์ิ๐ࠧࣂ")+GGCQK6OAtZUXRhvkgJm(u"ࠪࡠࡳ࠭ࣃ")+cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧࣄ")+mR20sONyKIlV[QmoEjB3hLIw(u"ࠬࡑࡏࡅࡋࡈࡑࡆࡊ࡟ࡂࡒࡓࠫࣅ")][FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠶ੱ")]+ta478EuZQJIWhgBnsf6iU(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡࠢࠣࠤࠥࠦร้ࠢࠣࠤࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪࣆ")+mR20sONyKIlV[tOdiG2HWFRBXg1sUh(u"ࠧࡌࡑࡇࡍࡊࡓࡁࡅࡡࡄࡔࡕ࠭ࣇ")][YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠶ੰ")]+EAw9bg4rT3Bd8tjSkO(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࣈ")
	maCNIYkc0HOiEGpL3g += NxsKJnLFEZ9OHXf1h(u"ࠩ࡟ࡲࡡࡴ࡜࡯ษ็ีฬฮืࠡลา๊ฬํ่๊ࠠࠣหู้่าีࠣห้ึ๊ࠡ์ะฮฬา็ࠡ็า๎ึࠦๅๅใสฮ้่ࠥะ์่ࠣฯัศ๋ฬࠣฬึ์วๆฮࠣ฽๊อฯࠡสส่฼ื๊ใหࠣห้ะโๅ์า๎ฮࠦวๅไา๎๊ฯ࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫࣉ")+mR20sONyKIlV[wx18CTJPZ5(u"ࠪࡗࡔ࡛ࡒࡄࡇࡖࠫ࣊")][EAw9bg4rT3Bd8tjSkO(u"࠱ੲ")]+qFRrj7ayBKbOsHGSXz(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭࣋")
	maCNIYkc0HOiEGpL3g += CgPbwXm1RilpJUSGHLhy(u"ࠬࡢ࡮࡝ࡰ࡟ࡲัฺ๋๊่่ࠢๆอสࠡ฻่หิࠦๅ้ฮ๋ำฮࠦแ๋ࠢส่๊๎โฺࠢฦำ๋อ็ࠨ࣌")+NxsKJnLFEZ9OHXf1h(u"࠭࡜࡯ࠩ࣍")+GGCQK6OAtZUXRhvkgJm(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ࣎")+mR20sONyKIlV[bbqAtUz36RPGVTvCkejpJXQB(u"ࠨࡕࡒ࡙ࡗࡉࡅࡔ࣏ࠩ")][ItgK5FqGDz2Rf7mAJkbT(u"࠳ੳ")]+zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠ࣐ࠫ")
	Dkp5YTLQijOEKF(r6juULGQtnExAko38BZ5Y(u"ࠪࡧࡪࡴࡴࡦࡴ࣑ࠪ"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠫฬ๊ๅ้ษๅ฽ࠥอไาี่๎ฮࠦไษำ้ห๊าฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋ห࣒ࠪ"),maCNIYkc0HOiEGpL3g,YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ࣓"))
	return
def ppDvSqemKx9tRhoaInrjGyUkOg(ooYJtQ26MV5cETNwsUvKSzDOI4):
	oos8ymFi9CN2z1jXcR.executebuiltin(tOdiG2HWFRBXg1sUh(u"࠭ࡁࡥࡦࡲࡲ࠳ࡕࡰࡦࡰࡖࡩࡹࡺࡩ࡯ࡩࡶࠬࠬࣔ")+ooYJtQ26MV5cETNwsUvKSzDOI4+uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠧࠪࠩࣕ"), Gk98CL5nXZEN(u"ࡘࡷࡻࡥવ"))
	return
def BDorXLyuqa8S():
	YyexoUV8ZWpMXsRir1wAm69QPJKnN(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠨࡵࡷࡳࡵ࠭ࣖ"))
	oos8ymFi9CN2z1jXcR.executebuiltin(qFRrj7ayBKbOsHGSXz(u"ࠤࡄࡧࡹ࡯ࡶࡢࡶࡨ࡛࡮ࡴࡤࡰࡹࠫࡍࡳࡺࡥࡳࡨࡤࡧࡪ࡙ࡥࡵࡶ࡬ࡲ࡬ࡹࠩࠣࣗ"))
	return
def AxUYsDTCuqQ():
	oos8ymFi9CN2z1jXcR.executebuiltin(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠪࡅࡩࡪ࡯࡯࠰ࡒࡴࡪࡴࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠩ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠪࠩࣘ"), bbqAtUz36RPGVTvCkejpJXQB(u"࡙ࡸࡵࡦશ"))
	return
def TWo2wcXv4eMlqYUnKjHCb6PQJkAyIB(showDialogs):
	if not showDialogs: A5vgi1F6qVunZMas2Nf = EAw9bg4rT3Bd8tjSkO(u"࡚ࡲࡶࡧષ")
	else: A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(smpniPDOhfwI3H4v7c6TG(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫࣙ"),r6juULGQtnExAko38BZ5Y(u"ࠬ࠭ࣚ"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠭ࠧࣛ"),S26SnaqcM9XwK8PVphJDv5(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࣜ"),Kwl07iYTtDLN3zP(u"ࠨสิ๊ฬ๋ฬࠡๅ๋ำ๏๊ࠦใ๊่ࠤอ฿ๅๅ์ฬࠤฯำฯ๋อࠣะ๊๐ูࠡษ็ษ฻อแศฬࠣฮ้่วว์สࠤ่๊ࠠ࠳࠶ࠣืฬ฿ษ๊ࠡ็็๋ࠦๅๆๅ้ࠤสาัศร๊หࠥอไร่ࠣ࠲ࠥํไࠡฬิ๎ิࠦสฮัํฯࠥาๅ๋฻ࠣษ฻อแศฬࠣ็ํี๊ࠡษ็ฦ๋ࠦฟࠨࣝ"))
	if A5vgi1F6qVunZMas2Nf==YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠳ੴ"):
		oos8ymFi9CN2z1jXcR.executebuiltin(GGCQK6OAtZUXRhvkgJm(u"ࠩࡘࡴࡩࡧࡴࡦࡃࡧࡨࡴࡴࡒࡦࡲࡲࡷࠬࣞ"))
		if showDialogs: tehb3k5a2PufGOdBIUw8j(CIcPowhneWs5tN3(u"ࠪࠫࣟ"),CIcPowhneWs5tN3(u"ࠫࠬ࣠"),r6juULGQtnExAko38BZ5Y(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࣡"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"࠭สๆࠢศีุอไูࠡ็ฬࠥหไ๊ࠢหี๋อๅอࠢๆ์ิ๐ࠠศๆำ๎ࠥ็๊ࠡฮ๊หื้ࠠๅๅํࠤ๏่่ๆࠢหฮาี๊ฬࠢฯ้๏฿ࠠฦุสๅฬะࠠไ๊า๎ࠥ࠴ࠠษ็สࠤๆ๐็ศࠢอัิ๐ห้ࠡำหࠥอไษำ้ห๊า้ࠠฬะำ๏ัࠠๆีอ์ิ฿ฺࠠ็สำࠥ࠴๋ࠠำฯํࠥหูุษฤࠤ่๎ฯ๋ࠢ࠸ࠤิ่ววไࠣวํࠦรไอิࠤ้้๊ࠡ์้๋๏ูࠦๆๆํอࠥอไหฯา๎ะ࠭࣢"))
		oos8ymFi9CN2z1jXcR.executebuiltin(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࣣࠫ"))
	return
def ejJ7V0Z15iNTr():
	tehb3k5a2PufGOdBIUw8j(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠨࠩࣤ"),EAw9bg4rT3Bd8tjSkO(u"ࠩࠪࣥ"),qFRrj7ayBKbOsHGSXz(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ัࣦ࠭"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"้๋ࠫำฮ่ࠢัฯ๎๊ศฬࠣๆฬฬๅสࠢ࠱ࠤฬึ็ษࠢศ่๎ࠦวๅไสส๊ฯࠠศๆอ๎ࠥะั๋ัุ้ࠣำ็ศ๋่ࠢฬࠦสะะ็ࠤส๊๊่ษࠣ์้้ๆࠡสสืฯิฯศ็ࠣࠦฬ๊ๅศ๊ึࠦࠥษ่ࠡࠤส่ึ๐ๅ้ฬࠥࠤฬ฼ฺุࠢ฼่๎ࠦวๅิิࠤัํษࠡษ็๎๊๐ๆࠡล๋ࠤฬูสฯั่ࠤࠧอไไ์ห์ึี๊ࠢࠡสฺ฿฽ฺࠠๆ์ࠤาืแࠡࠤࡆࠦࠥษ่ࠡ฻็ํࠥอึ฻ูࠣ฽้๏ࠠำำࠣࠦฬ๊โศศ่อࠧࠦวๅาํࠤๆ๐ࠠอ้ฬࠤฬ๊๊ๆ์้ࠫࣧ"))
	return
def Pam8HghwFkf9JU1AqDO():
	tehb3k5a2PufGOdBIUw8j(bbqAtUz36RPGVTvCkejpJXQB(u"ࠬ࠭ࣨ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࣩ࠭ࠧ"),GGCQK6OAtZUXRhvkgJm(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࣪"),QmoEjB3hLIw(u"ࠨๆ็ฮ฾อๅๅ่ࠢ฽ࠥอไๆใู่ฮࠦ࠮ࠡษำ๋อࠦลๅ๋ࠣห้ืวษูࠣห้ึ๊ࠡฬิ๎ิࠦลืษไฮ์ࠦร้่ࠢืาํࠠๆ่ࠣࠤ็อฦๆหࠣห้๋แืๆฬࠤํ๊ใ็ࠢ็หࠥะๆใำࠣ฽้๐็๊ࠡ็หࠥะิ฻ๆ๊ࠤ࠳่ࠦษษึฮำีวๆࠢࠥห้๋ว้ีࠥࠤศ๎ࠠࠣษ็ี๏๋่หࠤࠣห฻เืࠡ฻็ํࠥอไำำࠣะ์ฯࠠศๆํ้๏์ࠠ࠯๋ࠢว๊อࠠษษึฮำีวๆࠢࠥห้้๊ษ๊ิำࠧࠦแศุ฽฻ࠥ฿ไ๊ࠢะีๆࠦࠢࡄࠤࠣวํูࠦๅ๋ࠣึึࠦࠢศๆๅหห๋ษࠣࠢส่ี๐ࠠโ์ࠣะ์ฯࠠศๆํ้๏์ࠠ࠯๋๊ࠢๆูࠠศๆๆ่ฬ๋้ࠠษ็฻ึ๐โสࠢ฼๊ิࠦวๅฬ฼ห๊๊ࠠๆ฻้ࠣาะ่๋ษอࠤ็๎วว็ࠣห้๋แืๆฬࠫ࣫"))
	return
def C6D50ht2eI(showDialogs=YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࡔࡳࡷࡨસ")):
	gV2YeCSWnL7i8fyUZ6EBAP4HIru = [tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲ࡴࡺࡨࡦࡴࡶࠫ࣬"),WbM6qAjrn7fEXGZw(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡧࡨ࣭ࠫ"),NNmirJKPp5nWjfC(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࣮ࠧ"),ItgK5FqGDz2Rf7mAJkbT(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡨ࡫ࡷ࡬ࡺࡨ࣯ࠧ"),QmoEjB3hLIw(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡩ࡬ࡸࡪࡧࣰࠧ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡦࡳࡩ࡫ࡢࡦࡴࡪࣱࠫ")]
	vfATpnhIyO8VZ1bWa = gV2YeCSWnL7i8fyUZ6EBAP4HIru+[GGCQK6OAtZUXRhvkgJm(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࣲࠪ"),NNmirJKPp5nWjfC(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧࣳ"),MM564HfnUV0XIR(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩࣴ"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪࣵ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠬࡹ࡫ࡪࡰ࠱ࡴ࡭࡫࡮ࡰ࡯ࡨࡲࡦࡲࡅࡎࡃࡇࣶࠫ"),GGCQK6OAtZUXRhvkgJm(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪࣷ"),Gk98CL5nXZEN(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡶ࠰ࡨࡱࡶࠧࣸ")]
	HUiL4nsdTt = jNVelpUxiIn([cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࣹࠪ")])
	eO0mdVQigfoqHPFN2 = []
	for aZhcuMGisIkl4npqDoJSrWy5fExX in [CgPbwXm1RilpJUSGHLhy(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࣺࠫ")]:
		if aZhcuMGisIkl4npqDoJSrWy5fExX not in list(HUiL4nsdTt.keys()): continue
		gKMqlA19hi,lQhSugcZUPELJwenXvD,wIjgoinbtYHyWqfdREC8p5Qm,kuNhXjnbYKVr,vlioP67cxzsLrENYa40ftgdMFOn,qO8lR2Pi7wN5dBZeU,jIpQYu092ZlmWc = HUiL4nsdTt[aZhcuMGisIkl4npqDoJSrWy5fExX]
		if not lQhSugcZUPELJwenXvD or (lQhSugcZUPELJwenXvD and gKMqlA19hi): eO0mdVQigfoqHPFN2.append(aZhcuMGisIkl4npqDoJSrWy5fExX)
	zecMN3si8X0m6GL2RpWSytBY = len(eO0mdVQigfoqHPFN2)>smpniPDOhfwI3H4v7c6TG(u"࠳ੵ")
	md59xZUEq3IOnPp2 = iZv4fPkF5Trx1L8EsVHC2S.connect(wmrN7GxQWCAD9PzM3Tj)
	md59xZUEq3IOnPp2.text_factory = str
	ngBDPjZshKvdX6 = md59xZUEq3IOnPp2.cursor()
	pI2F5KwljOBe = []
	for aZhcuMGisIkl4npqDoJSrWy5fExX in gV2YeCSWnL7i8fyUZ6EBAP4HIru:
		ngBDPjZshKvdX6.execute(wx18CTJPZ5(u"ࠪࡗࡊࡒࡅࡄࡖࠣ࠮ࠥࡌࡒࡐࡏࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡗࡉࡇࡕࡉࠥ࡫࡮ࡢࡤ࡯ࡩࡩࠦ࠽ࠡࠤ࠴ࠦࠥࡧ࡮ࡥࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧࣻ")+aZhcuMGisIkl4npqDoJSrWy5fExX+EAw9bg4rT3Bd8tjSkO(u"ࠫࠧࠦ࠻ࠨࣼ"))
		MRDAU8alpIbtNPn1Y95WJK2d6mr3E = ngBDPjZshKvdX6.fetchall()
		if MRDAU8alpIbtNPn1Y95WJK2d6mr3E: pI2F5KwljOBe.append(aZhcuMGisIkl4npqDoJSrWy5fExX)
	kj4R1pcxE9GI2C05JTMbKBULlXD = len(pI2F5KwljOBe)>SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠴੶")
	for aZhcuMGisIkl4npqDoJSrWy5fExX in vfATpnhIyO8VZ1bWa:
		ngBDPjZshKvdX6.execute(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࡙ࠬࡅࡍࡇࡆࡘࠥࡵࡲࡪࡩ࡬ࡲࠥࡌࡒࡐࡏࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪࣽ")+aZhcuMGisIkl4npqDoJSrWy5fExX+bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠭ࠢࠡ࠽ࠪࣾ"))
		ZvpzL8T52wtISjc0e = ngBDPjZshKvdX6.fetchall()
		if ZvpzL8T52wtISjc0e and Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩࣿ") not in str(ZvpzL8T52wtISjc0e): eO0mdVQigfoqHPFN2.append(aZhcuMGisIkl4npqDoJSrWy5fExX)
	rQvh5ESaxB = len(eO0mdVQigfoqHPFN2)>NNmirJKPp5nWjfC(u"࠵੷")
	eO0mdVQigfoqHPFN2 = list(set(eO0mdVQigfoqHPFN2))
	md59xZUEq3IOnPp2.close()
	gKMqlA19hi = SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࡇࡣ࡯ࡷࡪહ")
	if kj4R1pcxE9GI2C05JTMbKBULlXD or rQvh5ESaxB:
		A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(WbM6qAjrn7fEXGZw(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨऀ"),WbM6qAjrn7fEXGZw(u"ࠩࠪँ"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠪࠫं"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧः"),ItgK5FqGDz2Rf7mAJkbT(u"ࠬอไษำ้ห๊า้ࠠฮาࠤฺ๊ใๅหࠣๅ๏ࠦๅิฬ๋ำ฾ูࠦๆษาࠤศ๎ࠠๆึๆ่ฮࠦแ๋ࠢส่ฯำฯ๋อࠣห้ะไใษษ๎๊ࠥลืษไหฯࠦศา่ส้ัูࠦๆษาࠤࡡࡴ࡜࡯ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠥํไࠡฬิ๎ิࠦลึๆสัࠥํะ่ࠢสฺ่๊ใๅหࠣห้ศๆࠡม࡞࠳ࡈࡕࡌࡐࡔࡠࠫऄ"))
		if A5vgi1F6qVunZMas2Nf==qFRrj7ayBKbOsHGSXz(u"࠷੸"):
			CXc21NZtP0i5ruHbapFGwEI8U6JvV = WbM6qAjrn7fEXGZw(u"ࡖࡵࡹࡪ઺")
			if zecMN3si8X0m6GL2RpWSytBY:
				CXc21NZtP0i5ruHbapFGwEI8U6JvV = IuVorvz1ksJDgSd8wU(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨअ"),dEUYJjrhsaPXNo(u"ࡉࡥࡱࡹࡥ઻"),dEUYJjrhsaPXNo(u"ࡉࡥࡱࡹࡥ઻"))
			uzOA3nky1GHt4fgQ0lpZWJxS7dPDI = SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࡘࡷࡻࡥ઼")
			if kj4R1pcxE9GI2C05JTMbKBULlXD:
				for aZhcuMGisIkl4npqDoJSrWy5fExX in pI2F5KwljOBe: w7bg3nXdoQlN90CZRTxLtEcW84D(aZhcuMGisIkl4npqDoJSrWy5fExX)
				uzOA3nky1GHt4fgQ0lpZWJxS7dPDI = tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࡙ࡸࡵࡦઽ")
			CJSyWHf3MtXwDukE5rG92RYI0PnK6 = FeyZbj8tDil0nSHzTwfsUJ9(u"࡚ࡲࡶࡧા")
			if rQvh5ESaxB:
				md59xZUEq3IOnPp2 = iZv4fPkF5Trx1L8EsVHC2S.connect(wmrN7GxQWCAD9PzM3Tj)
				md59xZUEq3IOnPp2.text_factory = str
				ngBDPjZshKvdX6 = md59xZUEq3IOnPp2.cursor()
				for aZhcuMGisIkl4npqDoJSrWy5fExX in eO0mdVQigfoqHPFN2:
					if uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࠪआ") in aZhcuMGisIkl4npqDoJSrWy5fExX: ZvpzL8T52wtISjc0e = aZhcuMGisIkl4npqDoJSrWy5fExX
					else: ZvpzL8T52wtISjc0e = WbM6qAjrn7fEXGZw(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪइ")
					try: ngBDPjZshKvdX6.execute(NNmirJKPp5nWjfC(u"ࠩࡘࡔࡉࡇࡔࡆࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࡙ࠥࡅࡕࠢࡲࡶ࡮࡭ࡩ࡯ࠢࡀࠤࠧ࠭ई")+ZvpzL8T52wtISjc0e+EAw9bg4rT3Bd8tjSkO(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩउ")+aZhcuMGisIkl4npqDoJSrWy5fExX+Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠫࠧࠦ࠻ࠨऊ"))
					except: CJSyWHf3MtXwDukE5rG92RYI0PnK6 = CgPbwXm1RilpJUSGHLhy(u"ࡆࡢ࡮ࡶࡩિ")
				md59xZUEq3IOnPp2.commit()
				md59xZUEq3IOnPp2.close()
			w6vebiEZtpCjJcILP8Skx5rHn.sleep(WbM6qAjrn7fEXGZw(u"࠱੹"))
			oos8ymFi9CN2z1jXcR.executebuiltin(CIcPowhneWs5tN3(u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩऋ"))
			w6vebiEZtpCjJcILP8Skx5rHn.sleep(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠲੺"))
			if CXc21NZtP0i5ruHbapFGwEI8U6JvV or uzOA3nky1GHt4fgQ0lpZWJxS7dPDI or CJSyWHf3MtXwDukE5rG92RYI0PnK6:
				gKMqlA19hi = EAw9bg4rT3Bd8tjSkO(u"ࡇࡣ࡯ࡷࡪી")
				tehb3k5a2PufGOdBIUw8j(tmcuvd397wjGXeWoDHMNpFB5h2VK(u"࠭ࠧऌ"),r6juULGQtnExAko38BZ5Y(u"ࠧࠨऍ"),tOdiG2HWFRBXg1sUh(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫऎ"),smpniPDOhfwI3H4v7c6TG(u"ࠩฯ๎ิࠦ࠮࠯ࠢอ้ࠥฮๆอษะࠤฯ็ู๋ๆࠣ์ส฻ไศฯࠣห้๋ำห๊า฽ࠥ๎วๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢ็ะ๊๐ูࠡวูหๆอสࠡสิ๊ฬ๋ฬࠡ฻่หิ࠭ए"))
			else:
				gKMqlA19hi = NxsKJnLFEZ9OHXf1h(u"ࡖࡵࡹࡪુ")
				tehb3k5a2PufGOdBIUw8j(FeyZbj8tDil0nSHzTwfsUJ9(u"ࠪࠫऐ"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠫࠬऑ"),smpniPDOhfwI3H4v7c6TG(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨऒ"),bbqAtUz36RPGVTvCkejpJXQB(u"࠭ไๅลึๅࠥ࠴࠮ࠡใื่ฯูࠦๆๆํอࠥหีๅษะࠤู๊ส้ั฼ࠤ฾๋วะ๋ࠢษฺ๊วฮࠢส่ฯำฯ๋อࠣห้ะไใษษ๎๊ࠥลืษไหฯࠦศา่ส้ัูࠦๆษาࠫओ"))
	elif showDialogs: tehb3k5a2PufGOdBIUw8j(FeyZbj8tDil0nSHzTwfsUJ9(u"ࠧࠨऔ"),MM564HfnUV0XIR(u"ࠨࠩक"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬख"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠศๆหี๋อๅอࠢ็้ࠥ๐ฬะุ่่๊ࠢษࠡใํࠤู๊ส้ั฼ࠤ฾๋วะࠢฦ์ࠥ็๊ࠡษ็ฮาี๊ฬࠢส่ฯ๊โศศํࠤ้หึศใสฮࠥฮั็ษ่ะࠥ฿ๅศัࠪग"))
	return gKMqlA19hi
def e9eUDCorKp6QZmNn1dTbOuFh4WwlM():
	Wp5claqedPNFJ9,bQtfLmI4qcMupdNv,RtqL5zpCJNw7ikrZVu3gTv4xKHb = YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࡉࡥࡱࡹࡥૂ"),WbM6qAjrn7fEXGZw(u"ࠫࠬघ"),ta478EuZQJIWhgBnsf6iU(u"ࠬ࠭ङ")
	lMVJDNBHmh,T6jsZ3Jb5gqlMie,gYRJMsdymz6VSntbALO4 = Ox8k6IdtuPaG3NlApQK52oYwM(u"ࡊࡦࡲࡳࡦૃ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"࠭ࠧच"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠧࠨछ")
	qtR29xU7mNlXukJOreDSj8L5 = [bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ज"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨझ"),S26SnaqcM9XwK8PVphJDv5(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬञ"),QmoEjB3hLIw(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪट")]
	HUiL4nsdTt = jNVelpUxiIn(qtR29xU7mNlXukJOreDSj8L5)
	for aZhcuMGisIkl4npqDoJSrWy5fExX in qtR29xU7mNlXukJOreDSj8L5:
		if aZhcuMGisIkl4npqDoJSrWy5fExX not in list(HUiL4nsdTt.keys()): continue
		gKMqlA19hi,lQhSugcZUPELJwenXvD,ffiTAgp5y6PKzH1qcIvEjDL,C2rjw74RBD8L0zOvhginu1YtZFlxby,GGh3LDvKWu5wEZtUOCbxF,eetZUaRN8h2CJ,x7rbId06SLUf = HUiL4nsdTt[aZhcuMGisIkl4npqDoJSrWy5fExX]
		if aZhcuMGisIkl4npqDoJSrWy5fExX==tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪठ"):
			lMVJDNBHmh = gKMqlA19hi
			T6jsZ3Jb5gqlMie = FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࠭ࠨࠨड")+lQhSugcZUPELJwenXvD+I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠧࠡࠩढ")+NNbLf2d3Slq6pV(eetZUaRN8h2CJ)+FeyZbj8tDil0nSHzTwfsUJ9(u"ࠨࠫࠪण")
			gYRJMsdymz6VSntbALO4 = C2rjw74RBD8L0zOvhginu1YtZFlxby
		elif aZhcuMGisIkl4npqDoJSrWy5fExX==GGCQK6OAtZUXRhvkgJm(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫत"):
			Wp5claqedPNFJ9 = Wp5claqedPNFJ9 or gKMqlA19hi
			bQtfLmI4qcMupdNv += GGCQK6OAtZUXRhvkgJm(u"ࠪࠤࠥ࠲ࠠࠡࠪࠪथ")+lQhSugcZUPELJwenXvD+NNmirJKPp5nWjfC(u"ࠫࠥ࠭द")+NNbLf2d3Slq6pV(eetZUaRN8h2CJ)+Gk98CL5nXZEN(u"ࠬ࠯ࠧध")
			RtqL5zpCJNw7ikrZVu3gTv4xKHb += NxsKJnLFEZ9OHXf1h(u"࠭ࠠࠡ࠮ࠣࠤࠬन")+C2rjw74RBD8L0zOvhginu1YtZFlxby
		elif aZhcuMGisIkl4npqDoJSrWy5fExX==S26SnaqcM9XwK8PVphJDv5(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ऩ"):
			SUnaMH6Y8myA3 = gKMqlA19hi
			Mm743iq9KoEQVcOhLkAXTpW = ta478EuZQJIWhgBnsf6iU(u"ࠨࠪࠪप")+lQhSugcZUPELJwenXvD+bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠩࠣࠫफ")+NNbLf2d3Slq6pV(eetZUaRN8h2CJ)+FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠪ࠭ࠬब")
			LK2ilP1OIV3b0oqDU9MefJaFy6 = C2rjw74RBD8L0zOvhginu1YtZFlxby
	bQtfLmI4qcMupdNv = bQtfLmI4qcMupdNv.strip(bbqAtUz36RPGVTvCkejpJXQB(u"ࠫࠥࠦࠬࠡࠢࠪभ"))
	RtqL5zpCJNw7ikrZVu3gTv4xKHb = RtqL5zpCJNw7ikrZVu3gTv4xKHb.strip(EAw9bg4rT3Bd8tjSkO(u"ࠬࠦࠠ࠭ࠢࠣࠫम"))
	LL3z8KnCGTFi7lAVaIBvEZMc  = tOdiG2HWFRBXg1sUh(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไฤะํี๊ࠥศา่ส้ัูࠦๆษาࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭य")+gYRJMsdymz6VSntbALO4+NxsKJnLFEZ9OHXf1h(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩर")
	LL3z8KnCGTFi7lAVaIBvEZMc += FeyZbj8tDil0nSHzTwfsUJ9(u"ࠨ࡞ࡱࠫऱ")+S26SnaqcM9XwK8PVphJDv5(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ้ฮั็ษ่ะࠥ฿ๅศั๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ल")+T6jsZ3Jb5gqlMie+NxsKJnLFEZ9OHXf1h(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬळ")
	LL3z8KnCGTFi7lAVaIBvEZMc += Kwl07iYTtDLN3zP(u"ࠫࡡࡴ࡜࡯ࠩऴ")+dEUYJjrhsaPXNo(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊รฯ์ิࠤ้๋ำห๊า฽ࠥ฿ๅศัࠣห้๋ส้ใิࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬव")+RtqL5zpCJNw7ikrZVu3gTv4xKHb+dEUYJjrhsaPXNo(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨश")
	LL3z8KnCGTFi7lAVaIBvEZMc += cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠧ࡝ࡰࠪष")+WbM6qAjrn7fEXGZw(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆู้่๊ࠣส้ั฼ࠤ฾๋วะ๊ࠢ์ࠥࡀࠠࠡࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬस")+bQtfLmI4qcMupdNv+YDC9i52g6e8XL7GxvIFnSKWsolpr(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫह")
	LL3z8KnCGTFi7lAVaIBvEZMc += ItgK5FqGDz2Rf7mAJkbT(u"ࠪࡠࡳࡢ࡮ࠨऺ")+ta478EuZQJIWhgBnsf6iU(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡษ็้ฯ๎แาࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪऻ")+LK2ilP1OIV3b0oqDU9MefJaFy6+uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣ़ࠧ")
	LL3z8KnCGTFi7lAVaIBvEZMc += I7N2lHpGfLPkwKxbOu6raYUgc5(u"࠭࡜࡯ࠩऽ")+ta478EuZQJIWhgBnsf6iU(u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅาํࠤฬ์สࠡฬึฮำีๅ่ࠢ็ะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬี่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪा")+Mm743iq9KoEQVcOhLkAXTpW+bbqAtUz36RPGVTvCkejpJXQB(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪि")
	gKMqlA19hi = (lMVJDNBHmh or Wp5claqedPNFJ9)
	if gKMqlA19hi:
		header = CgPbwXm1RilpJUSGHLhy(u"ࠩส่ึาวยࠢอัิ๐หࠡวูหๆอสࠡๅ๋ำ๏ࠦไฮๆࠣห้๋ิศๅ็ࠫी")
		qum4VoYNQsc21iMZ76LzRtp = Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠪห๋ะࠠษฯสะฮࠦไหฯา๎ะࠦศา่ส้ัูࠦๆษาࠤศ๎ࠠหฯา๎ะࠦๅิฬ๋ำ฾ูࠦๆษาࠫु")
	else:
		header = QmoEjB3hLIw(u"ࠫาอไ๋ษ่ࠣฬ๊้ࠦฮาࠤฯำฯ๋อสฮ๊ࠥศา่ส้ัูࠦๆษาࠤศ๎ࠠๆีอ์ิ฿ฺࠠ็สำࠬू")
		qum4VoYNQsc21iMZ76LzRtp = ta478EuZQJIWhgBnsf6iU(u"ࠬอไาฮสลࠥหศๅษ฽ࠤฬ๊ๅษำ่ะࠥ฿ๆࠡษ็ู้้ไสࠢส่ฯ๐ࠠห๊สะ์้ࠧृ")
	nNFHSrwfEmU9PIKbx = Gk98CL5nXZEN(u"࠭ไไ์ࠣ๎฾๋ไࠡ฻้ำ่ࠦวๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢํะอࠦร็ࠢํ็ํ์ࠠๅัํ็ࠥ็๊ࠡๅ๋ำ๏ࡢ࡮ๆีอ์ิ฿ฺࠠ็สำࠥࡋࡍࡂࡆࠣࡖࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿࠧॄ")
	y8pGgqb4tBYShJL = LL3z8KnCGTFi7lAVaIBvEZMc+CIcPowhneWs5tN3(u"ࠧ࡝ࡰ࡟ࡲࠬॅ")+qum4VoYNQsc21iMZ76LzRtp+FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠨ࡞ࡱࡠࡳ࠭ॆ")+nNFHSrwfEmU9PIKbx
	Dkp5YTLQijOEKF(smpniPDOhfwI3H4v7c6TG(u"ࠩࡵ࡭࡬࡮ࡴࠨे"),header,y8pGgqb4tBYShJL,NxsKJnLFEZ9OHXf1h(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ै"))
	return
def NcRCDvgHBAS0(showDialogs,c3EMeGwkVpQHJR0T):
	QQvOnYi9sJMwp7dIxeck8DRASWuBt(WSgQvHLx9uOKTksaCt2JchldRj,ItgK5FqGDz2Rf7mAJkbT(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧॉ"),EAw9bg4rT3Bd8tjSkO(u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭ॊ"))
	if showDialogs:
		e9eUDCorKp6QZmNn1dTbOuFh4WwlM()
		PMr6a2bdOgFf4t5JjonXEZG93BDSv()
	if c3EMeGwkVpQHJR0T:
		C6D50ht2eI(ItgK5FqGDz2Rf7mAJkbT(u"ࡋࡧ࡬ࡴࡧૄ"))
		bhDUmlW0ekR1nI = [CgPbwXm1RilpJUSGHLhy(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫो"),smpniPDOhfwI3H4v7c6TG(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ौ"),GGCQK6OAtZUXRhvkgJm(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ्ࠪ"),EAw9bg4rT3Bd8tjSkO(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭ॎ"),QmoEjB3hLIw(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡽࡹ࠳ࡤ࡭ࡲࠪॏ")]
		for j3QzD7nRSMNh89av6YCrsA in bhDUmlW0ekR1nI:
			VZHWjJTrAPKG1eLEsxpYo2tS5,XmKpYiktDx,lQhSugcZUPELJwenXvD = IuVorvz1ksJDgSd8wU(j3QzD7nRSMNh89av6YCrsA,Gk98CL5nXZEN(u"ࡔࡳࡷࡨ૆"),S26SnaqcM9XwK8PVphJDv5(u"ࡌࡡ࡭ࡵࡨૅ"))
		TWo2wcXv4eMlqYUnKjHCb6PQJkAyIB(showDialogs)
		oos8ymFi9CN2z1jXcR.executebuiltin(zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨॐ"))
	return
def rvlbN3Tnq1Juj(WY23l8zAkiTj5oGcRDgVNJ01hSdr=FeyZbj8tDil0nSHzTwfsUJ9(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ॑"),showDialogs=tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࡕࡴࡸࡩે")):
	FQB3ikd1X6fsx8PhZKvUL9nq7GbCED = oos8ymFi9CN2z1jXcR.executeJSONRPC(EAw9bg4rT3Bd8tjSkO(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾ॒ࠩ"))
	import json as tbfuYvJU0e4
	data = tbfuYvJU0e4.loads(FQB3ikd1X6fsx8PhZKvUL9nq7GbCED)
	pguxKn8jqBD = data[FeyZbj8tDil0nSHzTwfsUJ9(u"ࠧࡳࡧࡶࡹࡱࡺࠧ॓")][wx18CTJPZ5(u"ࠨࡸࡤࡰࡺ࡫ࠧ॔")]
	if vciEXHThAPto76QIR2pK: pguxKn8jqBD = pguxKn8jqBD.encode(S26SnaqcM9XwK8PVphJDv5(u"ࠩࡸࡸ࡫࠾ࠧॕ"))
	if showDialogs:
		A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(bbqAtUz36RPGVTvCkejpJXQB(u"ࠪࠫॖ"),NxsKJnLFEZ9OHXf1h(u"ࠫࠬॗ"),Kwl07iYTtDLN3zP(u"ࠬ࠭क़"),Ox8k6IdtuPaG3NlApQK52oYwM(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩख़"),smpniPDOhfwI3H4v7c6TG(u"่ࠧๆࠣฮึ๐ฯࠡฬ฽๎๏ืࠠอๆาࠤࠬग़")+pguxKn8jqBD+MM564HfnUV0XIR(u"ࠨࠢส่ี๐ࠠๆีอาิ๋ࠠศๆล๊ࠥ็๊ࠡๅ๋ำ๏ࠦลๅ๋ࠣห้หีะษิࠤฬ๊รฯ์ิࠤ้าไะࠢࠪज़")+WY23l8zAkiTj5oGcRDgVNJ01hSdr+tOdiG2HWFRBXg1sUh(u"ࠩࠣรࠦ࠭ड़"))
		if A5vgi1F6qVunZMas2Nf!=CIcPowhneWs5tN3(u"࠳੻"): return NNmirJKPp5nWjfC(u"ࡈࡤࡰࡸ࡫ૈ")
	VZHWjJTrAPKG1eLEsxpYo2tS5,XmKpYiktDx,gkrtswyWHqnVma1oIl = IuVorvz1ksJDgSd8wU(WY23l8zAkiTj5oGcRDgVNJ01hSdr,ItgK5FqGDz2Rf7mAJkbT(u"ࡉࡥࡱࡹࡥૉ"),ItgK5FqGDz2Rf7mAJkbT(u"ࡉࡥࡱࡹࡥૉ"))
	if VZHWjJTrAPKG1eLEsxpYo2tS5:
		if showDialogs: tehb3k5a2PufGOdBIUw8j(WbM6qAjrn7fEXGZw(u"ࠪࠫढ़"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠫࠬफ़"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨय़"),dEUYJjrhsaPXNo(u"࠭สๆฬࠣ฽๊๊๊สࠢอฯอ๐สࠡษ็ะ้ีࠠศๆฯำ๏ี้้๋ࠠࠤัอ็ำࠢ็่ฬูสฯัส้ࠥ࠴ࠠิ๊ไࠤ๏ะๅࠡษ็ฦ๋ࠦส฻์ํีࠥหูะษาหฯࠦใ้ัํࠤ้้๊ࠡ์ึฮ฾๋ไࠡษ็ะ้ีࠠศๆฯำ๏ีࠠษั็ห๋ࠥๆࠡษ็ๆิ๐ๅࠨॠ"))
		ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0 = oos8ymFi9CN2z1jXcR.executeJSONRPC(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡕࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢ࠭ࠤࡹࡥࡱࡻࡥࠣ࠼ࠥࠫॡ")+WY23l8zAkiTj5oGcRDgVNJ01hSdr+Kwl07iYTtDLN3zP(u"ࠨࠤࢀࢁࠬॢ"))
		if FeyZbj8tDil0nSHzTwfsUJ9(u"ࠩࡒࡏࠬॣ") in ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0: VZHWjJTrAPKG1eLEsxpYo2tS5 = bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࡘࡷࡻࡥ૊")
		w6vebiEZtpCjJcILP8Skx5rHn.sleep(NxsKJnLFEZ9OHXf1h(u"࠴੼"))
		oos8ymFi9CN2z1jXcR.executebuiltin(Gk98CL5nXZEN(u"ࠪࡗࡪࡴࡤࡄ࡮࡬ࡧࡰ࠮࠱࠲ࠫࠪ।"))
	elif showDialogs: tehb3k5a2PufGOdBIUw8j(ItgK5FqGDz2Rf7mAJkbT(u"ࠫࠬ॥"),tOdiG2HWFRBXg1sUh(u"ࠬ࠭०"),smpniPDOhfwI3H4v7c6TG(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ१"),r6juULGQtnExAko38BZ5Y(u"ࠧๅๆฦืๆࠦแีๆอࠤ฾๋ไ๋หࠣฮะฮ๊ห๋ࠢฮๆ฿๊ๅࠢส่ั๊ฯࠡษ็้฼๊่ษࠩ२"))
	return VZHWjJTrAPKG1eLEsxpYo2tS5
def ouxXRO0IqbTFQE5e6rD97(aZhcuMGisIkl4npqDoJSrWy5fExX,showDialogs=QmoEjB3hLIw(u"࡙ࡸࡵࡦો")):
	if showDialogs==r6juULGQtnExAko38BZ5Y(u"ࠨࠩ३"): showDialogs = QmoEjB3hLIw(u"࡚ࡲࡶࡧૌ")
	ErUlzyaM3YmCPfv427B60nW = c1vMDuaLtS([aZhcuMGisIkl4npqDoJSrWy5fExX])
	H7u1l9ACwOnDixXzaeZYb,c0c1aMKrELlHykpZB8QO3Xsd = ErUlzyaM3YmCPfv427B60nW[aZhcuMGisIkl4npqDoJSrWy5fExX]
	if c0c1aMKrELlHykpZB8QO3Xsd:
		VZHWjJTrAPKG1eLEsxpYo2tS5 = Kwl07iYTtDLN3zP(u"ࡔࡳࡷࡨ્")
		if showDialogs: tehb3k5a2PufGOdBIUw8j(Gk98CL5nXZEN(u"ࠩࠪ४"),dEUYJjrhsaPXNo(u"ࠪࠫ५"),FeyZbj8tDil0nSHzTwfsUJ9(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ६"),qFRrj7ayBKbOsHGSXz(u"ࠬ็อึࠢส่ส฼วโหࠣࡠࡳࠦࠧ७")+aZhcuMGisIkl4npqDoJSrWy5fExX+zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"࠭ࠠ࡝ࡰ๋ࠣีํࠠฤๆศฺฬ็ษࠡ฻้ำ่ࠦๅ้ฮ๋ำฮ่ࠦๆใ฼่ฮ่ࠦอษ๊ึฮࠦไๅษึฮำีวๆࠩ८"))
	else:
		VZHWjJTrAPKG1eLEsxpYo2tS5 = GGCQK6OAtZUXRhvkgJm(u"ࡇࡣ࡯ࡷࡪ૎")
		A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(smpniPDOhfwI3H4v7c6TG(u"ࠧࡤࡧࡱࡸࡪࡸࠧ९"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠨࠩ॰"),ta478EuZQJIWhgBnsf6iU(u"ࠩࠪॱ"),wx18CTJPZ5(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ॲ"),Kwl07iYTtDLN3zP(u"ࠫࠬॳ")+aZhcuMGisIkl4npqDoJSrWy5fExX+WbM6qAjrn7fEXGZw(u"ࠬࠦ࡜࡯๊ࠢิ์ࠦรๅวูหๆฯฺ่ࠠา็ࠥเ๊า่ࠢๅ฾๊ษࠡล๋ࠤ฿๐ัࠡ็๋ะํีษࠡ࠰ࠣ๎ัฮࠠหอห๎ฯํว๊ࠡอๅ฾๐ไ่ษ่่ࠣ๐๋ࠠ฻่่ࠥอไษำ้ห๊าฺ่ࠠา็ࠥฮี้ำฬࠤฺำ๊ฮหࠣ࠲ࠥํไࠡฬิ๎ิࠦสฬสํฮࠥ๎สโ฻ํ่ࠥํะ่ࠢส่ส฼วโหࠣห้ศๆࠡมࠪॴ"))
		if A5vgi1F6qVunZMas2Nf==cWfQ64kVCqxhwvSy5P7irHI1oes3(u"࠵੽"):
			oos8ymFi9CN2z1jXcR.executebuiltin(MM564HfnUV0XIR(u"࠭ࡉ࡯ࡵࡷࡥࡱࡲࡁࡥࡦࡲࡲ࠭࠭ॵ")+aZhcuMGisIkl4npqDoJSrWy5fExX+Kwl07iYTtDLN3zP(u"ࠧࠪࠩॶ"))
			w6vebiEZtpCjJcILP8Skx5rHn.sleep(QmoEjB3hLIw(u"࠶੾"))
			oos8ymFi9CN2z1jXcR.executebuiltin(qFRrj7ayBKbOsHGSXz(u"ࠨࡕࡨࡲࡩࡉ࡬ࡪࡥ࡮ࠬ࠶࠷ࠩࠨॷ"))
			w6vebiEZtpCjJcILP8Skx5rHn.sleep(YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠷੿"))
			while oos8ymFi9CN2z1jXcR.getCondVisibility(GGCQK6OAtZUXRhvkgJm(u"࡚ࠩ࡭ࡳࡪ࡯ࡸ࠰ࡌࡷࡆࡩࡴࡪࡸࡨࠬࡵࡸ࡯ࡨࡴࡨࡷࡸࡪࡩࡢ࡮ࡲ࡫࠮࠭ॸ")): w6vebiEZtpCjJcILP8Skx5rHn.sleep(NNmirJKPp5nWjfC(u"࠱઀"))
			ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0 = oos8ymFi9CN2z1jXcR.executeJSONRPC(ItgK5FqGDz2Rf7mAJkbT(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡄࡨࡩࡵ࡮ࡴ࠰ࡖࡩࡹࡇࡤࡥࡱࡱࡉࡳࡧࡢ࡭ࡧࡧࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡤࡨࡩࡵ࡮ࡪࡦࠥ࠾ࠧ࠭ॹ")+aZhcuMGisIkl4npqDoJSrWy5fExX+qFRrj7ayBKbOsHGSXz(u"ࠫࠧ࠲ࠢࡦࡰࡤࡦࡱ࡫ࡤࠣ࠼ࡷࡶࡺ࡫ࡽࡾࠩॺ"))
			if Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠬࡕࡋࠨॻ") in ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0:
				VZHWjJTrAPKG1eLEsxpYo2tS5 = cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࡖࡵࡹࡪ૏")
				if showDialogs: tehb3k5a2PufGOdBIUw8j(ItgK5FqGDz2Rf7mAJkbT(u"࠭ࠧॼ"),zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠧࠨॽ"),SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫॾ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠩอ้ࠥ็อึࠢฦ์ࠥะหษ์อࠤศ๎ࠠหใ฼๎้ࠦร้ࠢอัิ๐หࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠤํํ๊ࠡษ็ฦ๋ࠦฬศ้ีอ๊ࠥไศีอาิอๅࠨॿ"))
			elif showDialogs: tehb3k5a2PufGOdBIUw8j(bbqAtUz36RPGVTvCkejpJXQB(u"ࠪࠫঀ"),dEUYJjrhsaPXNo(u"ࠫࠬঁ"),tOdiG2HWFRBXg1sUh(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨং"),CIcPowhneWs5tN3(u"࠭แีๆࠣๅ๏ࠦสฬสํฮࠥษ่ࠡฬไ฽๏๊ࠠฤ๊ࠣฮาี๊ฬࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠥ࠴้ࠠษ็ั้ࠦ็้ࠢอฯอ๐ส่ษࠣ์ฯ็ู๋ๆ๊ห๋ࠥๆࠡะสีัࠦวๅสิ๊ฬ๋ฬࠨঃ"))
	return VZHWjJTrAPKG1eLEsxpYo2tS5
def bAcfThYHk48qgVo3RS(aZhcuMGisIkl4npqDoJSrWy5fExX,x7rbId06SLUf,showDialogs):
	VZHWjJTrAPKG1eLEsxpYo2tS5 = MM564HfnUV0XIR(u"ࡉࡥࡱࡹࡥૐ")
	if showDialogs:
		A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠧࠨ঄"),qFRrj7ayBKbOsHGSXz(u"ࠨࠩঅ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠩࠪআ"),EAw9bg4rT3Bd8tjSkO(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ই"),WbM6qAjrn7fEXGZw(u"ุࠫ๎แࠡ์อ้ࠥอไร่ࠣะ้ฮࠠศๆ่่ๆࠦวๅ็ู฾ํ฽ࠠๅๆศฺฬ็ษࠡษ็้฼๊่ษห่่ࠣ๐๋ࠠฬ่ࠤฯัศ๋ฬ๊ࠤ฾๊้ࠡๅ๋ำ๏ࠦ࠮ࠡษ็้้็ࠠใัࠣ๎่๎ๆࠡๅห๎ึ่ࠦใัࠣ๎าะวอࠢห฽฻ࠦวๅ๊ๅฮࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬะ้๏๊ࠠศๆ่่ๆࠦวๅฤ้ࠤฤࠧࠧঈ"))
		if A5vgi1F6qVunZMas2Nf!=S26SnaqcM9XwK8PVphJDv5(u"࠲ઁ"): return tOdiG2HWFRBXg1sUh(u"ࡊࡦࡲࡳࡦ૑")
	ydAmUbN3xFJvgHfT124VnOMp0 = vym8kYdTF2Opjn6wrKa(x7rbId06SLUf,{},showDialogs)
	if ydAmUbN3xFJvgHfT124VnOMp0:
		mJqsN3cxH4rUGMiyXB8hdzO1D = K3hFytImeYMkJBC.path.join(URY8OguPqdXfkFB1oWiaGr,aZhcuMGisIkl4npqDoJSrWy5fExX)
		oFHcGJSy62KieOMmZv4f0l(mJqsN3cxH4rUGMiyXB8hdzO1D,Ox8k6IdtuPaG3NlApQK52oYwM(u"࡚ࡲࡶࡧ૓"),CIcPowhneWs5tN3(u"ࡋࡧ࡬ࡴࡧ૒"))
		import zipfile as yp9SHcwBe18GzTkrE,io as Vvjr7DILGxSa84XPk3fb
		zcVKEBWHTGF8py2s = Vvjr7DILGxSa84XPk3fb.BytesIO(ydAmUbN3xFJvgHfT124VnOMp0)
		try:
			JYBCtI7Um1buh4PARlQvN9Seji = yp9SHcwBe18GzTkrE.ZipFile(zcVKEBWHTGF8py2s)
			JYBCtI7Um1buh4PARlQvN9Seji.extractall(URY8OguPqdXfkFB1oWiaGr)
			w6vebiEZtpCjJcILP8Skx5rHn.sleep(Ox8k6IdtuPaG3NlApQK52oYwM(u"࠳ં"))
			oos8ymFi9CN2z1jXcR.executebuiltin(Kwl07iYTtDLN3zP(u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩউ"))
			w6vebiEZtpCjJcILP8Skx5rHn.sleep(EAw9bg4rT3Bd8tjSkO(u"࠵ઃ"))
			ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0 = oos8ymFi9CN2z1jXcR.executeJSONRPC(wx18CTJPZ5(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡇࡤࡥࡱࡱࡷ࠳࡙ࡥࡵࡃࡧࡨࡴࡴࡅ࡯ࡣࡥࡰࡪࡪࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡧࡤࡥࡱࡱ࡭ࡩࠨ࠺ࠣࠩঊ")+aZhcuMGisIkl4npqDoJSrWy5fExX+FeyZbj8tDil0nSHzTwfsUJ9(u"ࠧࠣ࠮ࠥࡩࡳࡧࡢ࡭ࡧࡧࠦ࠿ࡺࡲࡶࡧࢀࢁࠬঋ"))
			if cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠨࡑࡎࠫঌ") in ZbcODnQi2TqFSfGE8hIkrV1ewmYJL0: VZHWjJTrAPKG1eLEsxpYo2tS5 = GGCQK6OAtZUXRhvkgJm(u"ࡔࡳࡷࡨ૔")
			QQvOnYi9sJMwp7dIxeck8DRASWuBt(WSgQvHLx9uOKTksaCt2JchldRj,bbqAtUz36RPGVTvCkejpJXQB(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ঍"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠪࡅࡉࡊࡏࡏࡕࡢࡈࡊ࡚ࡁࡊࡎࡖࠫ঎"))
		except: VZHWjJTrAPKG1eLEsxpYo2tS5 = wx18CTJPZ5(u"ࡇࡣ࡯ࡷࡪ૕")
	if showDialogs:
		if VZHWjJTrAPKG1eLEsxpYo2tS5: tehb3k5a2PufGOdBIUw8j(tOdiG2HWFRBXg1sUh(u"ࠫࠬএ"),Gk98CL5nXZEN(u"ࠬ࠭ঐ"),CIcPowhneWs5tN3(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ঑"),bbqAtUz36RPGVTvCkejpJXQB(u"ࠧห็ࠣฬ๋าวฮࠢอฯอ๐สࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠫ঒"))
		else: tehb3k5a2PufGOdBIUw8j(NNmirJKPp5nWjfC(u"ࠨࠩও"),NxsKJnLFEZ9OHXf1h(u"ࠩࠪঔ"),S26SnaqcM9XwK8PVphJDv5(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ক"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"้๊ࠫริใࠣๅู๊สࠡ฻่่๏ฯࠠหอห๎ฯࠦวๅวูหๆฯࠠศๆ่฻้๎ศสࠩখ"))
	return VZHWjJTrAPKG1eLEsxpYo2tS5
def IuVorvz1ksJDgSd8wU(aZhcuMGisIkl4npqDoJSrWy5fExX,showDialogs,FFHRhE7r23neZSXag1):
	A5vgi1F6qVunZMas2Nf,VZHWjJTrAPKG1eLEsxpYo2tS5,XmKpYiktDx,lQhSugcZUPELJwenXvD = GGCQK6OAtZUXRhvkgJm(u"ࡗࡶࡺ࡫૗"),NxsKJnLFEZ9OHXf1h(u"ࡈࡤࡰࡸ࡫૖"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬগ"),S26SnaqcM9XwK8PVphJDv5(u"࠭ࠧঘ")
	HUiL4nsdTt = jNVelpUxiIn([aZhcuMGisIkl4npqDoJSrWy5fExX])
	if aZhcuMGisIkl4npqDoJSrWy5fExX in list(HUiL4nsdTt.keys()):
		gKMqlA19hi,lQhSugcZUPELJwenXvD,ffiTAgp5y6PKzH1qcIvEjDL,C2rjw74RBD8L0zOvhginu1YtZFlxby,GGh3LDvKWu5wEZtUOCbxF,eetZUaRN8h2CJ,x7rbId06SLUf = HUiL4nsdTt[aZhcuMGisIkl4npqDoJSrWy5fExX]
		if eetZUaRN8h2CJ==Kwl07iYTtDLN3zP(u"ࠧࡨࡱࡲࡨࠬঙ"):
			VZHWjJTrAPKG1eLEsxpYo2tS5,XmKpYiktDx = zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࡘࡷࡻࡥ૘"),Gk98CL5nXZEN(u"ࠨࡰࡲࡸ࡭࡯࡮ࡨࠩচ")
			if FFHRhE7r23neZSXag1: tehb3k5a2PufGOdBIUw8j(FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠩࠪছ"),YZFXwtrfK8uhzV4LlMEqgnCQyO9(u"ࠪࠫজ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧঝ"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢๆ์ิ๐๋ࠠีอาิ๋ࠠฤะิࠤส฻ฯศำ้ࠣฯ๎แาࠢไ๎๋่ࠥศไ฼ࠤู๊ส้ั฼ࠤ฾๋วะࠢ็๋ีํࠠศๆศฺฬ็ษ࡝ࡰ࡟ࡲࠬঞ")+aZhcuMGisIkl4npqDoJSrWy5fExX)
		else:
			if showDialogs:
				if eetZUaRN8h2CJ==NNmirJKPp5nWjfC(u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࡤࠨট"): maCNIYkc0HOiEGpL3g = bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠧๆฬ๋ๆๆฯࠧঠ")
				elif eetZUaRN8h2CJ==zxwIDBrPiXjKlsYkfg0AGaUZSyW2co(u"ࠨࡱ࡯ࡨࠬড"): maCNIYkc0HOiEGpL3g = GGCQK6OAtZUXRhvkgJm(u"ࠩๅำ๏๋ษࠨঢ")
				elif eetZUaRN8h2CJ==SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫণ"): maCNIYkc0HOiEGpL3g = I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠫ฿๐ัࠡ็ฮฬฯฯࠧত")
				A5vgi1F6qVunZMas2Nf = eINt5FlUT0oO(bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠬ࠭থ"),YDC9i52g6e8XL7GxvIFnSKWsolpr(u"࠭ࠧদ"),qFRrj7ayBKbOsHGSXz(u"ࠧࠨধ"),Ox8k6IdtuPaG3NlApQK52oYwM(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫন"),WbM6qAjrn7fEXGZw(u"๊ࠩิ์ࠦวๅวูหๆฯࠠࠨ঩")+maCNIYkc0HOiEGpL3g+CgPbwXm1RilpJUSGHLhy(u"ࠪࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡวุ่ฬำ่ࠠา๊ࠤฬ๊ๅีๅ็อࠥลࠡ࡝ࡰ࡟ࡲࠬপ")+aZhcuMGisIkl4npqDoJSrWy5fExX)
			if not A5vgi1F6qVunZMas2Nf: XmKpYiktDx = wx18CTJPZ5(u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠭ফ")
			else:
				if eetZUaRN8h2CJ==I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧব"):
					s4Bng5iAZQSTtpDw9 = oos8ymFi9CN2z1jXcR.executeJSONRPC(ItgK5FqGDz2Rf7mAJkbT(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡇࡤࡥࡱࡱࡷ࠳࡙ࡥࡵࡃࡧࡨࡴࡴࡅ࡯ࡣࡥࡰࡪࡪࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡧࡤࡥࡱࡱ࡭ࡩࠨ࠺ࠣࠩভ")+aZhcuMGisIkl4npqDoJSrWy5fExX+wx18CTJPZ5(u"ࠧࠣ࠮ࠥࡩࡳࡧࡢ࡭ࡧࡧࠦ࠿ࡺࡲࡶࡧࢀࢁࠬম"))
					if ItgK5FqGDz2Rf7mAJkbT(u"ࠨࡑࡎࠫয") in s4Bng5iAZQSTtpDw9:
						VZHWjJTrAPKG1eLEsxpYo2tS5,XmKpYiktDx = FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"࡙ࡸࡵࡦ૙"),I7N2lHpGfLPkwKxbOu6raYUgc5(u"ࠩࡨࡲࡦࡨ࡬ࡦࡦࠪর")
						if showDialogs: tehb3k5a2PufGOdBIUw8j(bbqAtUz36RPGVTvCkejpJXQB(u"ࠪࠫ঱"),GGCQK6OAtZUXRhvkgJm(u"ࠫࠬল"),NNmirJKPp5nWjfC(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ঳"),S26SnaqcM9XwK8PVphJDv5(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้หึศใฬࠤ่อๆห่ࠢฮํ่แสࠢ࠱࠲ࠥ๎โศ็ࠣห้ฮั็ษ่ะࠥฮสี฼ํ่์อ࡜࡯࡞ࡱࠫ঴")+aZhcuMGisIkl4npqDoJSrWy5fExX)
					elif showDialogs: tehb3k5a2PufGOdBIUw8j(SIDG7cnzAaUpkwmNde19ZsBqQ3Hh(u"ࠧࠨ঵"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠨࠩশ"),Gk98CL5nXZEN(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬষ"),GGCQK6OAtZUXRhvkgJm(u"่้ࠪษำโࠢ࠱࠲ࠥอไฦุสๅฮࠦๅห๊ๅๅฮࠦ࠮࠯๋่๊๊ࠢࠦิฬฺ๎฾ࠦวๅสิ๊ฬ๋ฬࠡฬื฾๏๊็ศ࡞ࡱࡠࡳ࠭স")+aZhcuMGisIkl4npqDoJSrWy5fExX)
				elif eetZUaRN8h2CJ in [MM564HfnUV0XIR(u"ࠫࡴࡲࡤࠨহ"),FFVuCHLxhZmkEGJQDitreaygc2f4AS(u"ࠬࡳࡩࡴࡵ࡬ࡲ࡬࠭঺")]:
					VZHWjJTrAPKG1eLEsxpYo2tS5 = bAcfThYHk48qgVo3RS(aZhcuMGisIkl4npqDoJSrWy5fExX,x7rbId06SLUf,Kwl07iYTtDLN3zP(u"ࡌࡡ࡭ࡵࡨ૚"))
					if VZHWjJTrAPKG1eLEsxpYo2tS5:
						if eetZUaRN8h2CJ==smpniPDOhfwI3H4v7c6TG(u"࠭࡯࡭ࡦࠪ঻"): XmKpYiktDx = ItgK5FqGDz2Rf7mAJkbT(u"ࠧࡶࡲࡧࡥࡹ࡫ࡤࠨ়")
						elif eetZUaRN8h2CJ==MM564HfnUV0XIR(u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩঽ"): XmKpYiktDx = ItgK5FqGDz2Rf7mAJkbT(u"ࠩ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠬা")
						lQhSugcZUPELJwenXvD = C2rjw74RBD8L0zOvhginu1YtZFlxby
						if showDialogs:
							if XmKpYiktDx==CgPbwXm1RilpJUSGHLhy(u"ࠪࡹࡵࡪࡡࡵࡧࡧࠫি"): tehb3k5a2PufGOdBIUw8j(NNmirJKPp5nWjfC(u"ࠫࠬী"),NxsKJnLFEZ9OHXf1h(u"ࠬ࠭ু"),QmoEjB3hLIw(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩূ"),GGCQK6OAtZUXRhvkgJm(u"ࠧอ์าࠤัีวࠡ࠰࠱ࠤฬ๊ลืษไอ้ࠥว็ฬࠣๆิ๐ๅสࠢ࠱࠲ࠥ๎วๅสิ๊ฬ๋ฬࠡไส้ࠥฮสฮัํฯ์อ࡜࡯࡞ࡱࠫৃ")+aZhcuMGisIkl4npqDoJSrWy5fExX)
							elif XmKpYiktDx==FeyZbj8tDil0nSHzTwfsUJ9(u"ࠨ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠫৄ"): tehb3k5a2PufGOdBIUw8j(bbqAtUz36RPGVTvCkejpJXQB(u"ࠩࠪ৅"),bIV4EoOn5U2ZeCcqmFWMiz1KHQh6(u"ࠪࠫ৆"),wx18CTJPZ5(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧে"),wx18CTJPZ5(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢส่ส฼วโห่๊ࠣࠦสไ่้ࠣํา่ะหࠣๅ๏ࠦใ้ัํࠤ࠳࠴้ࠠษ็ฬึ์วๆฮࠣๆฬ๋ࠠษฬฮฬ๏ะ็ศ࡞ࡱࡠࡳ࠭ৈ")+aZhcuMGisIkl4npqDoJSrWy5fExX)
					elif showDialogs: tehb3k5a2PufGOdBIUw8j(Gk98CL5nXZEN(u"࠭ࠧ৉"),NNmirJKPp5nWjfC(u"ࠧࠨ৊"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫো"),cWfQ64kVCqxhwvSy5P7irHI1oes3(u"ࠩ็่ศูแࠡ࠰࠱ࠤฬ๊ศา่ส้ัࠦไๆࠢํืฯ฽ฺ๊ࠢอัิ๐หࠡล๋ࠤฯัศ๋ฬ๋ࠣีํࠠศๆศฺฬ็ษ࡝ࡰ࡟ࡲࠬৌ")+aZhcuMGisIkl4npqDoJSrWy5fExX)
	elif showDialogs: tehb3k5a2PufGOdBIUw8j(S26SnaqcM9XwK8PVphJDv5(u"্ࠪࠫ"),tmcuvd397wjGXeWoDHMNpFB5h2VK(u"ࠫࠬৎ"),uAl3gHavMJZL4xmNe62nDiBoQ(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ৏"),dEUYJjrhsaPXNo(u"࠭ไๅลึๅࠥ࠴࠮้ࠡำ๋ࠥอไฦุสๅฮฺ๋ࠦำ้ࠣํา่ะหࠣๅ๏ࠦๅ้ษๅ฽๋ࠥำห๊า฽ࠥ฿ๅศัࠣ࠲࠳่ࠦๅ้ำห๊ࠥวࠡ์ึฮ฼๐ูࠡษ็ฬึ์วๆฮࠣว๋๊ࠦใ๊่ࠤอะหษ์อࠤ์ึ็ࠡษ็ษ฻อแสࠢฦ์ࠥะอะ์ฮ๋ฬࡢ࡮࡝ࡰࠪ৐")+aZhcuMGisIkl4npqDoJSrWy5fExX)
	return VZHWjJTrAPKG1eLEsxpYo2tS5,XmKpYiktDx,lQhSugcZUPELJwenXvD
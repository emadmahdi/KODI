# -*- coding: utf-8 -*-
from zbUtu6IvKA import *
r1NChsk39OMvT82YemDQnl5 = 'CIMANOW'
Yc0eBRLpbCkm4gK7OqyzuHwU = '_CMN_'
tle5V6jgvRfE = mR20sONyKIlV[r1NChsk39OMvT82YemDQnl5][0]
ZLKHfqMEUdRupD = ['قائمتي']
def HgQCVwFx2Br(mode,url,text):
	if   mode==300: s4Bng5iAZQSTtpDw9 = Or15mUj4By()
	elif mode==301: s4Bng5iAZQSTtpDw9 = AJDL0Mp13fQkRH5c(url)
	elif mode==302: s4Bng5iAZQSTtpDw9 = uyt3pAHZk4(url)
	elif mode==303: s4Bng5iAZQSTtpDw9 = PPrel9jScTR0ONpCwHb3vkfFsA(url)
	elif mode==304: s4Bng5iAZQSTtpDw9 = btd6ag2XYUkHixqy5J7o9RfLu1MScm(url)
	elif mode==305: s4Bng5iAZQSTtpDw9 = dlropqS0vO9K7W4z(url)
	elif mode==306: s4Bng5iAZQSTtpDw9 = ttJs4gyMSxaXnfY0pZ5olwrWumvDO()
	elif mode==309: s4Bng5iAZQSTtpDw9 = Xwa7vgzTeb3Zy(text)
	else: s4Bng5iAZQSTtpDw9 = False
	return s4Bng5iAZQSTtpDw9
def Or15mUj4By():
	tBq8fTGUWJY9zvbgXD0EAloPO('link',Yc0eBRLpbCkm4gK7OqyzuHwU+'لماذا الموقع بطيء','',306)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'بحث في الموقع','',309,'','','_REMEMBERRESULTS_')
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',tle5V6jgvRfE+'/home','','','','','CIMANOW-MENU-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<header>(.*?)</header>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<li><a href="(.*?)">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
		title = title.strip(' ')
		if not any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title for hht0cpXxWw2OzFS1jnUGebkJLBd85 in ZLKHfqMEUdRupD):
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',r1NChsk39OMvT82YemDQnl5+'_SCRIPT_'+Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,301)
	tBq8fTGUWJY9zvbgXD0EAloPO('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	AJDL0Mp13fQkRH5c(tle5V6jgvRfE+'/home',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2)
	return M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2
def ttJs4gyMSxaXnfY0pZ5olwrWumvDO():
	tehb3k5a2PufGOdBIUw8j('','','رسالة من المبرمج','موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def AJDL0Mp13fQkRH5c(url,M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2=''):
	if not M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2:
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(xgFTDVS7lf5Us6aj,'GET',url,'','','','','CIMANOW-SUBMENU-1st')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	iHnuAqRYNm = 0
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(<section>.*?</section>)',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		for ziJLDVT8NM2QcgIpmE9A in TIkiozSLCv6werb97mHQ0q4y3:
			iHnuAqRYNm += 1
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<section>.<span>(.*?)<(.*?)href="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for title,uCrAFxiUaHdg3l1nyStvbP25K6MDY,ZCimQhV5lovgspAYzHq1Ef27u8ja4R in items:
				title = title.strip(' ')
				if title=='': title = 'بووووو'
				if 'em><a' not in uCrAFxiUaHdg3l1nyStvbP25K6MDY:
					if ziJLDVT8NM2QcgIpmE9A.count('/category/')>0:
						ttF4jIGbxlz = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
						for ZCimQhV5lovgspAYzHq1Ef27u8ja4R in ttF4jIGbxlz:
							title = ZCimQhV5lovgspAYzHq1Ef27u8ja4R.split('/')[-2]
							tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,301)
						continue
					else: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = url+'?sequence='+str(iHnuAqRYNm)
				if not any(hht0cpXxWw2OzFS1jnUGebkJLBd85 in title for hht0cpXxWw2OzFS1jnUGebkJLBd85 in ZLKHfqMEUdRupD):
					tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,302)
	else: uyt3pAHZk4(url,M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2)
	return
def uyt3pAHZk4(url,M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2=''):
	if M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2=='':
		aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','CIMANOW-TITLES-1st')
		M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	if '?sequence=' in url:
		url,iHnuAqRYNm = url.split('?sequence=')
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('(<section>.*?</section>)',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[int(iHnuAqRYNm)-1]
	else:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"posts"(.*?)</body>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
	items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	jjR8ftoEXpPxVF6JerbHZuzv7ic = []
	for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,data,Q2qmuDRrC9ikcaJK7gtUHXNW in items:
		title = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if title: title = title[0][2].replace('\n','').strip(' ')
		if not title or title=='':
			title = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('title">.*?</em>(.*?)<',data,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if title: title = title[0].replace('\n','').strip(' ')
			if not title or title=='':
				title = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('title">(.*?)<',data,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
				title = title[0].replace('\n','').strip(' ')
		title = nnGHa80rMphqe1ukFtIRvAPs6W(title)
		if title not in jjR8ftoEXpPxVF6JerbHZuzv7ic:
			jjR8ftoEXpPxVF6JerbHZuzv7ic.append(title)
			f9AzGuXj0qgcNTy1 = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+data+Q2qmuDRrC9ikcaJK7gtUHXNW
			if '/selary/' in f9AzGuXj0qgcNTy1 or 'مسلسل' in f9AzGuXj0qgcNTy1 or '"episode"' in f9AzGuXj0qgcNTy1:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,303,Q2qmuDRrC9ikcaJK7gtUHXNW)
			else: tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,305,Q2qmuDRrC9ikcaJK7gtUHXNW)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"pagination"(.*?)</div>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<li><a href="(.*?)">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+'صفحة '+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,302)
	return
def PPrel9jScTR0ONpCwHb3vkfFsA(url):
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','CIMANOW-SEASONS-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	name = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<title>(.*?)</title>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	name = name[0].replace('| سيما ناو','').replace('Cima Now','').strip(' ').replace('  ',' ')
	name = name.split('الحلقة')[0].strip(' ')
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('<section(.*?)</section>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)">(.*?)<',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		if len(items)>1:
			for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
				title = name+' - '+title.replace('\n','').strip(' ')
				tBq8fTGUWJY9zvbgXD0EAloPO('folder',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,304)
		else: btd6ag2XYUkHixqy5J7o9RfLu1MScm(url)
	return
def btd6ag2XYUkHixqy5J7o9RfLu1MScm(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(Yv7e6ixHfZIPrmMOy3ozwJu2,'GET',url,'','','','','CIMANOW-EPISODES-1st')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	if '/selary/' not in url:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"episodes"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)">(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			title = title.replace('\n','').strip(' ')
			title = 'الحلقة '+title
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,305)
	else:
		TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"details"(.*?)"related"',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,Q2qmuDRrC9ikcaJK7gtUHXNW,title in items:
			title = title.replace('\n','').strip(' ')
			tBq8fTGUWJY9zvbgXD0EAloPO('video',Yc0eBRLpbCkm4gK7OqyzuHwU+title,ZCimQhV5lovgspAYzHq1Ef27u8ja4R,305,Q2qmuDRrC9ikcaJK7gtUHXNW)
	return
def dlropqS0vO9K7W4z(url):
	M08MPGgsh4n5rKe = url+'watching/'
	aQniqUlZk8 = OOA8T7f5Cl9WPgvoItykRc3M(jEPuRTVbZg4MCimJxzf3I6wFa,'GET',M08MPGgsh4n5rKe,'','','','','CIMANOW-PLAY-5th')
	M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2 = aQniqUlZk8.content
	jVMHRouKgQFAESmd7B8ObTYy = []
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"download"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('href="(.*?)".*?</i>(.*?)</a>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R,title in items:
			title = title.replace('\n','').strip(' ')
			LjG8y1rb9AgJF2I3i64ZDtCXMa7n = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('\d\d\d+',title,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			if LjG8y1rb9AgJF2I3i64ZDtCXMa7n:
				LjG8y1rb9AgJF2I3i64ZDtCXMa7n = '____'+LjG8y1rb9AgJF2I3i64ZDtCXMa7n[0]
				title = SLMTm6RQ34ic7v5s9rBG(ZCimQhV5lovgspAYzHq1Ef27u8ja4R,'name')
			else: LjG8y1rb9AgJF2I3i64ZDtCXMa7n = ''
			VktWBN6gn8zSUpesvfCyia2Ajm = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+title+'__download'+LjG8y1rb9AgJF2I3i64ZDtCXMa7n
			jVMHRouKgQFAESmd7B8ObTYy.append(VktWBN6gn8zSUpesvfCyia2Ajm)
	TIkiozSLCv6werb97mHQ0q4y3 = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"watch"(.*?)</ul>',M8wPuaJgVpv7yDZ9m3I1bEfRlGNWr2,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
	if TIkiozSLCv6werb97mHQ0q4y3:
		ziJLDVT8NM2QcgIpmE9A = TIkiozSLCv6werb97mHQ0q4y3[0]
		cc0O1M4e5jtfoq = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('"embed".*?src="(.*?)"',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
		for ZCimQhV5lovgspAYzHq1Ef27u8ja4R in cc0O1M4e5jtfoq:
			if 'http' not in ZCimQhV5lovgspAYzHq1Ef27u8ja4R: ZCimQhV5lovgspAYzHq1Ef27u8ja4R = 'http:'+ZCimQhV5lovgspAYzHq1Ef27u8ja4R
			title = SLMTm6RQ34ic7v5s9rBG(ZCimQhV5lovgspAYzHq1Ef27u8ja4R,'name')
			ZCimQhV5lovgspAYzHq1Ef27u8ja4R = ZCimQhV5lovgspAYzHq1Ef27u8ja4R+'?named='+title+'__embed'
			jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
		cc0O1M4e5jtfoq = [tle5V6jgvRfE+'/wp-content/themes/Cima%20Now%20New/core.php']
		if cc0O1M4e5jtfoq:
			items = E1E4YjPysoQMVdlu39mSTcWKFkpa7v.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',ziJLDVT8NM2QcgIpmE9A,E1E4YjPysoQMVdlu39mSTcWKFkpa7v.DOTALL)
			for EeWNT4ZgLwnchCSIjJKX,id,title in items:
				title = title.replace('\n','').strip(' ')
				ZCimQhV5lovgspAYzHq1Ef27u8ja4R = cc0O1M4e5jtfoq[0]+'?action=switch&index='+EeWNT4ZgLwnchCSIjJKX+'&id='+id+'?named='+title+'__watch'
				jVMHRouKgQFAESmd7B8ObTYy.append(ZCimQhV5lovgspAYzHq1Ef27u8ja4R)
	import JYR902sfml
	JYR902sfml.RBVfsOeZQmLIdwiYEUHx7630lt(jVMHRouKgQFAESmd7B8ObTYy,r1NChsk39OMvT82YemDQnl5,'video',url)
	return
def Xwa7vgzTeb3Zy(search):
	search,dNlVai6Obj1e,showDialogs = Vb5z8GrTJq70LPo12SRhdl6mt4c9Wf(search)
	if search=='': search = UIf35nZEj1wylmq()
	if search=='': return
	search = search.replace(' ','+')
	url = tle5V6jgvRfE + '/?s='+search
	uyt3pAHZk4(url)
	return